/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 16250 ; VA 0x0091a590 ; thunk_FUN_0091a3d0 */

void __fastcall thunk_FUN_0091a3d0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[8];
        if (0xf < uVar6) {
          iVar2 = puVar7[3];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0091a48d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[7] = 0;
        puVar7[8] = 0xf;
        *(undefined *)(puVar7 + 3) = 0;
        FUN_01674ea0(puVar7,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_0091a48d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 16251 ; VA 0x0091a5a0 ; FUN_0091a5a0 */

void __fastcall FUN_0091a5a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar6;
        FUN_00916ab0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16252 ; VA 0x0091a5b0 ; FUN_0091a5b0 */

void __fastcall FUN_0091a5b0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_005f6200(*param_1,param_1[1]);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x28) * 0x28;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 16253 ; VA 0x0091a630 ; FUN_0091a630 */

int __fastcall FUN_0091a630(int *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01679490();
  iVar5 = param_1[0x10];
  if (iVar5 != 0) {
    piVar1 = (int *)(iVar5 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    iVar4 = iVar4 + -1;
    if (iVar4 == 0) {
      iVar4 = FUN_01674ea0(iVar5);
    }
  }
  piVar1 = (int *)param_1[0xd];
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 1;
    iVar5 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar4 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uVar3 = param_1[0xb];
  if (0xf < uVar3) {
    iVar4 = param_1[6];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091a737;
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar3 = param_1[5];
  if (0xf < uVar3) {
    iVar4 = *param_1;
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_0091a737:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 16254 ; VA 0x0091a740 ; FUN_0091a740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_0091a740(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6dd0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Player::vftable;
  FUN_009326f0(0);
  FUN_005e61c0();
  FUN_0091a630();
  piVar2 = (int *)param_1[0x126];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x123];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[0x121];
  if (0xf < uVar3) {
    iVar4 = param_1[0x11c];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x120] = 0;
  param_1[0x121] = 0xf;
  *(undefined *)(param_1 + 0x11c) = 0;
  uVar3 = param_1[0x11b];
  if (0xf < uVar3) {
    iVar4 = param_1[0x116];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x11a] = 0;
  param_1[0x11b] = 0xf;
  *(undefined *)(param_1 + 0x116) = 0;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = param_1[0xf0];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar2 = (int *)param_1[0xde];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xdc];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0091ecd0();
  FUN_01674ea0(param_1[0xd9],0x28);
  piVar2 = (int *)param_1[0xd8];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[0xcc] =
       RBX::
       SizeEnforcedLRUCache<__int64,class_std::shared_ptr<class_RBX::Animation>,struct_boost::hash<__int64>_>
       ::vftable;
  FUN_0091a0f0();
  FUN_0091a4a0();
  FUN_0091a5b0();
  if (param_1[0xb0] != 0) {
    FUN_01674ea0(param_1[0xb0],0x40);
  }
  uVar3 = param_1[0xaf];
  if (0xf < uVar3) {
    iVar4 = param_1[0xaa];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0xae] = 0;
  param_1[0xaf] = 0xf;
  *(undefined *)(param_1 + 0xaa) = 0;
  uVar3 = param_1[0xa9];
  if (0xf < uVar3) {
    iVar4 = param_1[0xa4];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0xa8] = 0;
  param_1[0xa9] = 0xf;
  *(undefined *)(param_1 + 0xa4) = 0;
  uVar3 = param_1[0xa3];
  if (0xf < uVar3) {
    iVar4 = param_1[0x9e];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0xa2] = 0;
  param_1[0xa3] = 0xf;
  *(undefined *)(param_1 + 0x9e) = 0;
  piVar2 = (int *)param_1[0x9c];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[0x96];
  if (0xf < uVar3) {
    iVar4 = param_1[0x91];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x95] = 0;
  param_1[0x96] = 0xf;
  *(undefined *)(param_1 + 0x91) = 0;
  uVar3 = param_1[0x90];
  if (0xf < uVar3) {
    iVar4 = param_1[0x8b];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x8f] = 0;
  param_1[0x90] = 0xf;
  *(undefined *)(param_1 + 0x8b) = 0;
  uVar3 = param_1[0x8a];
  if (0xf < uVar3) {
    iVar4 = param_1[0x85];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x89] = 0;
  param_1[0x8a] = 0xf;
  *(undefined *)(param_1 + 0x85) = 0;
  uVar3 = param_1[0x84];
  if (0xf < uVar3) {
    iVar4 = param_1[0x7f];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x83] = 0;
  param_1[0x84] = 0xf;
  *(undefined *)(param_1 + 0x7f) = 0;
  uVar3 = param_1[0x7e];
  if (0xf < uVar3) {
    iVar4 = param_1[0x79];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x7d] = 0;
  param_1[0x7e] = 0xf;
  *(undefined *)(param_1 + 0x79) = 0;
  uVar3 = param_1[0x78];
  if (0xf < uVar3) {
    iVar4 = param_1[0x73];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x77] = 0;
  param_1[0x78] = 0xf;
  *(undefined *)(param_1 + 0x73) = 0;
  uVar3 = param_1[0x72];
  if (0xf < uVar3) {
    iVar4 = param_1[0x6d];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0091b18c;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x71] = 0;
  param_1[0x72] = 0xf;
  *(undefined *)(param_1 + 0x6d) = 0;
  piVar2 = (int *)param_1[0x6c];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar4 = param_1[0x69];
  piVar2 = param_1 + 0x69;
  uStack_8 = 1;
  FUN_0091d080(*(undefined4 *)(iVar4 + 4));
  uStack_8 = 0xffffffff;
  *(int *)(*piVar2 + 4) = iVar4;
  *(int *)*piVar2 = iVar4;
  *(int *)(*piVar2 + 8) = iVar4;
  param_1[0x6a] = 0;
  FUN_01674ea0(*piVar2,0x38);
  uVar3 = param_1[0x5f];
  if (0xf < uVar3) {
    iVar4 = param_1[0x5a];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_0091b18c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x5e] = 0;
  param_1[0x5f] = 0xf;
  *(undefined *)(param_1 + 0x5a) = 0;
  uVar3 = param_1[0x52];
  uStack_8 = 3;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x54,param_1 + 0x54,2);
      }
    }
    param_1[0x52] = 0;
  }
  uStack_8 = 4;
  FUN_01679490();
  iVar4 = param_1[0x50];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 5;
  FUN_01679490();
  iVar4 = param_1[0x4f];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 6;
  FUN_01679490();
  iVar4 = param_1[0x4e];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 7;
  FUN_01679490();
  iVar4 = param_1[0x4d];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 8;
  FUN_01679490();
  iVar4 = param_1[0x4c];
  if (iVar4 != 0) {
    piVar2 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  FUN_005507b0();
  FUN_005507b0();
  piVar2 = (int *)param_1[0x2e];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[2] + -1;
    piVar2[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = (int *)param_1[0x27];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[2] + -1;
    piVar2[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = (int *)param_1[0x20];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x1e];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x1c];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x1a];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x18];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[2] + -1;
    piVar2[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = (int *)param_1[0x16];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  LOCK();
  _DAT_01ee170c = _DAT_01ee170c + -1;
  UNLOCK();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16255 ; VA 0x0091b1a0 ; FUN_0091b1a0 */

void __fastcall FUN_0091b1a0(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6de8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01675290(DAT_01eea9bc);
  uStack_8 = 1;
  iVar1 = param_1[1];
  if (DAT_01d641e4 != '\0') {
    if (iVar1 != 0) {
      LOCK();
      *(int *)(iVar1 + 8) = *(int *)(iVar1 + 8) + 1;
      UNLOCK();
    }
    FUN_0092af20(*param_1,param_1[1]);
    FUN_0091b256();
    return;
  }
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 8) = *(int *)(iVar1 + 8) + 1;
    UNLOCK();
  }
  FUN_0092b810(*param_1,param_1[1]);
  FUN_0091b256();
  return;
}



/* FUNCTION 16256 ; VA 0x0091b23a ; Catch@0091b23a */

undefined * Catch_0091b23a(void)

{
  int unaff_EBP;
  
  FUN_0086eff0(3,*(undefined4 *)(unaff_EBP + -0x20),*(undefined4 *)(*(int *)(unaff_EBP + -0x14) + 8)
              );
  return &DAT_0091b253;
}



/* FUNCTION 16257 ; VA 0x0091b256 ; FUN_0091b256 */

void FUN_0091b256(void)

{
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -4) = 3;
  FUN_01675290();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 16258 ; VA 0x0091b280 ; FUN_0091b280 */

int __thiscall FUN_0091b280(undefined4 *param_1,int param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_80 [16];
  undefined4 uStack_70;
  undefined4 uStack_58;
  int iStack_54;
  char *pcStack_50;
  int *piStack_4c;
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6e10;
  pvStack_10 = ExceptionList;
  piStack_4c = &iStack_24;
  pcStack_50 = (char *)0x91b2a9;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8 = 0;
  if (iStack_24 != 0) {
    piStack_4c = (int *)iStack_24;
    pcStack_50 = (char *)0x91b2c1;
    iStack_24 = FUN_008f7870();
    iStack_14 = iStack_24;
    if (iStack_24 != 0) {
      if (((param_2 == 0) && (*(int *)(param_3 + 0xc) - 200U < 100)) &&
         (*(int *)(param_3 + 0xc) != 0xca)) {
        uStack_1c = 0;
        uStack_18 = 0;
        piStack_4c = (int *)0x0;
        pcStack_50 = (char *)&uStack_1c;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        iStack_54 = param_3 + 0x40;
        uStack_58 = 0x91b31d;
        cVar2 = FUN_0098f070();
        if (cVar2 != '\0') {
          piStack_4c = (int *)0x9;
          pcStack_50 = "CanManage";
          uStack_2c = 0;
          uStack_28 = 0xf;
          auStack_3c[0] = 0;
          iStack_54 = 0x91b348;
          FUN_005542c0();
          piStack_4c = (int *)auStack_3c;
          pcStack_50 = (char *)&param_2;
          iStack_54 = 0x91b357;
          piVar3 = (int *)FUN_00580040();
          iVar1 = *piVar3;
          piStack_4c = (int *)0x91b361;
          FUN_005507b0();
          if (iVar1 != 0) {
            iVar1 = *(int *)(iVar1 + 0x20);
            piStack_4c = (int *)0x91b36f;
            iVar4 = FUN_0088daf0();
            if (iVar1 == iVar4) {
              piStack_4c = (int *)0x91b37a;
              FUN_00605c60();
            }
          }
        }
        piStack_4c = (int *)0x1;
        uStack_70 = 0;
        FUN_005587b0(param_1);
        FUN_00915820(auStack_80,FUN_00931570);
        FUN_00912cc0();
        uStack_70 = 0x91b3cd;
        FUN_0090ca30();
        piStack_4c = (int *)0x91b3d5;
        iStack_24 = FUN_00550b30();
      }
      else {
        piStack_4c = (int *)0x1;
        uStack_70 = 0;
        if (param_1[1] != 0) {
          LOCK();
          piVar3 = (int *)(param_1[1] + 8);
          *piVar3 = *piVar3 + 1;
          UNLOCK();
        }
        FUN_00915820(auStack_80,FUN_00931570,*param_1,param_1[1],0);
        FUN_00912cc0();
        uStack_70 = 0x91b42a;
        iStack_24 = FUN_0090ca30();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_20 + 1;
    iVar1 = *piVar3;
    iStack_24 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      piStack_4c = (int *)0x91b443;
      iStack_24 = (**(code **)*piStack_20)();
      LOCK();
      piVar3 = piStack_20 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        piStack_4c = (int *)0x91b452;
        iStack_24 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_24;
}



/* FUNCTION 16259 ; VA 0x0091b470 ; FUN_0091b470 */

int FUN_0091b470(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined *apuStack_8c [6];
  undefined4 uStack_74;
  undefined *puStack_70;
  undefined *apuStack_6c [6];
  undefined4 uStack_54;
  int *piStack_50;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  int iStack_1c;
  int iStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6e48;
  pvStack_10 = ExceptionList;
  piStack_50 = &iStack_2c;
  uStack_8 = 0;
  uStack_54 = 0x91b49d;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490();
  uStack_8._0_1_ = 1;
  if ((param_1 != 0) && (iVar4 = iStack_2c, iStack_2c != 0)) {
    piStack_50 = (int *)iStack_2c;
    uStack_54 = 0x91b4bf;
    iVar4 = FUN_008bfff0();
    iStack_1c = iVar4;
    if (iVar4 != 0) {
      puStack_20 = (undefined *)apuStack_6c;
      iStack_18 = param_1;
      puStack_70 = auStack_14;
      auStack_14[0] = 0;
      uStack_74 = 0x91b4e8;
      cVar3 = FUN_00585a40();
      if (cVar3 == '\0') {
        apuStack_6c[0] = &DAT_0193270d;
      }
      else {
        apuStack_6c[0] = (undefined *)0x0;
      }
      puStack_24 = (undefined *)apuStack_8c;
      auStack_14[0] = 0;
      cVar3 = FUN_00585a40();
      if (cVar3 == '\0') {
        apuStack_8c[0] = &DAT_01932705;
      }
      else {
        apuStack_8c[0] = (undefined *)0x0;
      }
      uStack_8._0_1_ = 3;
      FUN_0054ef60();
      uStack_8._0_1_ = 5;
      FUN_00e5faf0(uStack_44,uStack_40,uStack_3c,uStack_38,CONCAT44(uStack_30,uStack_34));
      piStack_50 = (int *)0x91b582;
      iVar4 = FUN_005507b0();
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_28 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_50 = (int *)0x91b598;
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_50 = (int *)0x91b5a8;
        iVar4 = (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_50 = (int *)0x91b5be;
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_50 = (int *)0x91b5cd;
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 16260 ; VA 0x0091b5e0 ; FUN_0091b5e0 */

int FUN_0091b5e0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined *apuStack_8c [6];
  undefined4 uStack_74;
  undefined *puStack_70;
  undefined *apuStack_6c [6];
  undefined4 uStack_54;
  int *piStack_50;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  int iStack_1c;
  int iStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6e48;
  pvStack_10 = ExceptionList;
  piStack_50 = &iStack_2c;
  uStack_8 = 0;
  uStack_54 = 0x91b60d;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490();
  uStack_8._0_1_ = 1;
  if ((param_1 != 0) && (iVar4 = iStack_2c, iStack_2c != 0)) {
    piStack_50 = (int *)iStack_2c;
    uStack_54 = 0x91b62f;
    iVar4 = FUN_008bfff0();
    iStack_1c = iVar4;
    if (iVar4 != 0) {
      puStack_20 = (undefined *)apuStack_6c;
      iStack_18 = param_1;
      puStack_70 = auStack_14;
      auStack_14[0] = 0;
      uStack_74 = 0x91b658;
      cVar3 = FUN_00585a40();
      if (cVar3 == '\0') {
        apuStack_6c[0] = &DAT_01932725;
      }
      else {
        apuStack_6c[0] = (undefined *)0x0;
      }
      puStack_24 = (undefined *)apuStack_8c;
      auStack_14[0] = 0;
      cVar3 = FUN_00585a40();
      if (cVar3 == '\0') {
        apuStack_8c[0] = &DAT_0193271d;
      }
      else {
        apuStack_8c[0] = (undefined *)0x0;
      }
      uStack_8._0_1_ = 3;
      FUN_0054ef60();
      uStack_8._0_1_ = 5;
      FUN_00e5faf0(uStack_44,uStack_40,uStack_3c,uStack_38,CONCAT44(uStack_30,uStack_34));
      piStack_50 = (int *)0x91b6f2;
      iVar4 = FUN_005507b0();
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_28 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_50 = (int *)0x91b708;
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_50 = (int *)0x91b718;
        iVar4 = (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_50 = (int *)0x91b72e;
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_50 = (int *)0x91b73d;
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 16261 ; VA 0x0091b750 ; FUN_0091b750 */

/* WARNING: Removing unreachable block (ram,0x0091b7bd) */
/* WARNING: Removing unreachable block (ram,0x0091b7c9) */
/* WARNING: Removing unreachable block (ram,0x0091b7d7) */

undefined4 __thiscall FUN_0091b750(uint *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6e70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 16262 ; VA 0x0091b810 ; FUN_0091b810 */

/* WARNING: Removing unreachable block (ram,0x0091b862) */
/* WARNING: Removing unreachable block (ram,0x0091b872) */
/* WARNING: Removing unreachable block (ram,0x0091b878) */

void __fastcall FUN_0091b810(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6e90;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16263 ; VA 0x0091b8bb ; Catch@0091b8bb */

undefined * Catch_0091b8bb(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_0091b8cc;
}



/* FUNCTION 16264 ; VA 0x0091b8e0 ; FUN_0091b8e0 */

/* WARNING: Removing unreachable block (ram,0x0091ba0e) */
/* WARNING: Removing unreachable block (ram,0x0091ba1e) */
/* WARNING: Removing unreachable block (ram,0x0091ba24) */

void __thiscall FUN_0091b8e0(int *param_1,int param_2)

{
  uint in_stack_00000018;
  int in_stack_0000001c;
  uint in_stack_00000030;
  int in_stack_00000034;
  uint in_stack_00000048;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6ed8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 5;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_01675290();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000030) {
    if ((0xfff < in_stack_00000030 + 1) &&
       (0x1f < (in_stack_0000001c - *(int *)(in_stack_0000001c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000048) {
    if ((0xfff < in_stack_00000048 + 1) &&
       (0x1f < (in_stack_00000034 - *(int *)(in_stack_00000034 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16265 ; VA 0x0091baad ; Catch@0091baad */

undefined * Catch_0091baad(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x2c));
  return &DAT_0091babe;
}



/* FUNCTION 16266 ; VA 0x0091bae0 ; FUN_0091bae0 */

/* WARNING: Removing unreachable block (ram,0x0091bb7e) */
/* WARNING: Removing unreachable block (ram,0x0091bb8e) */
/* WARNING: Removing unreachable block (ram,0x0091bb94) */

void __thiscall FUN_0091bae0(int *param_1,int param_2)

{
  undefined4 uVar1;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6f08;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290(uVar1);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16267 ; VA 0x0091bbf3 ; Catch@0091bbf3 */

undefined * Catch_0091bbf3(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_0091bc04;
}



/* FUNCTION 16268 ; VA 0x0091bc20 ; FUN_0091bc20 */

/* WARNING: Removing unreachable block (ram,0x0091bc72) */
/* WARNING: Removing unreachable block (ram,0x0091bc82) */
/* WARNING: Removing unreachable block (ram,0x0091bc88) */

void * __thiscall FUN_0091bc20(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6f38;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 16269 ; VA 0x0091bcf3 ; Catch@0091bcf3 */

undefined * Catch_0091bcf3(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_0091bd04;
}



/* FUNCTION 16270 ; VA 0x0091bd20 ; FUN_0091bd20 */

/* WARNING: Removing unreachable block (ram,0x0091bd72) */
/* WARNING: Removing unreachable block (ram,0x0091bd82) */
/* WARNING: Removing unreachable block (ram,0x0091bd88) */

void __fastcall FUN_0091bd20(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6f60;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16271 ; VA 0x0091bdd4 ; Catch@0091bdd4 */

undefined * Catch_0091bdd4(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_0091bde5;
}



/* FUNCTION 16272 ; VA 0x0091be00 ; FUN_0091be00 */

/* WARNING: Removing unreachable block (ram,0x0091be52) */
/* WARNING: Removing unreachable block (ram,0x0091be62) */
/* WARNING: Removing unreachable block (ram,0x0091be68) */

void * __thiscall
FUN_0091be00(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6f90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 16273 ; VA 0x0091bf0a ; Catch@0091bf0a */

undefined * Catch_0091bf0a(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_0091bf1b;
}



/* FUNCTION 16274 ; VA 0x0091bf30 ; FUN_0091bf30 */

/* WARNING: Removing unreachable block (ram,0x0091bfce) */
/* WARNING: Removing unreachable block (ram,0x0091bfde) */
/* WARNING: Removing unreachable block (ram,0x0091bfe4) */

void __thiscall FUN_0091bf30(int *param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int in_stack_00000010;
  uint in_stack_00000024;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6fb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290(uVar1);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  if (0xf < in_stack_00000024) {
    uVar3 = in_stack_00000024 + 1;
    iVar2 = in_stack_00000010;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(in_stack_00000010 + -4);
      uVar3 = in_stack_00000024 + 0x24;
      if (0x1f < (in_stack_00000010 - iVar2) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16275 ; VA 0x0091c038 ; Catch@0091c038 */

undefined * Catch_0091c038(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_0091c049;
}



/* FUNCTION 16276 ; VA 0x0091c070 ; FUN_0091c070 */

/* WARNING: Removing unreachable block (ram,0x0091c0ca) */
/* WARNING: Removing unreachable block (ram,0x0091c0da) */
/* WARNING: Removing unreachable block (ram,0x0091c0e0) */

void __fastcall FUN_0091c070(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6fe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16277 ; VA 0x0091c11f ; Catch@0091c11f */

undefined * Catch_0091c11f(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_0091c130;
}



/* FUNCTION 16278 ; VA 0x0091c150 ; FUN_0091c150 */

void __fastcall FUN_0091c150(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>::
       vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_std::out_of_range>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16279 ; VA 0x0091c1e8 ; FUN_0091c1e8 */

void FUN_0091c1e8(void)

{
  FUN_0091c9a0();
  return;
}



/* FUNCTION 16280 ; VA 0x0091c1f3 ; FUN_0091c1f3 */

void FUN_0091c1f3(void)

{
  FUN_0091c9a0();
  return;
}



/* FUNCTION 16281 ; VA 0x0091c1fb ; FUN_0091c1fb */

void FUN_0091c1fb(void)

{
  FUN_0091c9d0();
  return;
}



/* FUNCTION 16282 ; VA 0x0091c210 ; FUN_0091c210 */

int __thiscall FUN_0091c210(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),0xc);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 16283 ; VA 0x0091c250 ; FUN_0091c250 */

int __thiscall FUN_0091c250(int param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 16284 ; VA 0x0091c2c0 ; FUN_0091c2c0 */

int __thiscall FUN_0091c2c0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),1);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),0xc);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 16285 ; VA 0x0091c310 ; FUN_0091c310 */

int __thiscall FUN_0091c310(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),1);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 16286 ; VA 0x0091c360 ; FUN_0091c360 */

undefined4 * __thiscall FUN_0091c360(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<float>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16287 ; VA 0x0091c390 ; FUN_0091c390 */

int __thiscall FUN_0091c390(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 16288 ; VA 0x0091c3d0 ; FUN_0091c3d0 */

int __thiscall FUN_0091c3d0(int param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 16289 ; VA 0x0091c440 ; FUN_0091c440 */

int __thiscall FUN_0091c440(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),0xc);
  }
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 16290 ; VA 0x0091c490 ; FUN_0091c490 */

undefined4 __thiscall FUN_0091c490(undefined4 param_1,byte param_2)

{
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 16291 ; VA 0x0091c4c0 ; FUN_0091c4c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0091c4c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Player::AvatarContextMenuOption>::vftable;
  _DAT_01ee1ea0 = _DAT_01ee1ea0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 16292 ; VA 0x0091c4f0 ; FUN_0091c4f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0091c4f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Camera::CameraMode>::vftable;
  _DAT_01f07790 = _DAT_01f07790 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 16293 ; VA 0x0091c520 ; FUN_0091c520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0091c520(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode>
             ::vftable;
  _DAT_01ef3668 = _DAT_01ef3668 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 16294 ; VA 0x0091c550 ; FUN_0091c550 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0091c550(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             EnumDesc<enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode>::vftable;
  _DAT_01ef3660 = _DAT_01ef3660 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 16295 ; VA 0x0091c580 ; FUN_0091c580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0091c580(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             EnumDesc<enum_RBX::StarterPlayerService::DeveloperComputerMovementMode>::vftable;
  _DAT_01ef3678 = _DAT_01ef3678 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 16296 ; VA 0x0091c5b0 ; FUN_0091c5b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0091c5b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             EnumDesc<enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode>::vftable;
  _DAT_01ef3658 = _DAT_01ef3658 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 16297 ; VA 0x0091c5e0 ; FUN_0091c5e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0091c5e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::StarterPlayerService::DeveloperTouchMovementMode>::
             vftable;
  _DAT_01ef3670 = _DAT_01ef3670 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 16298 ; VA 0x0091c610 ; FUN_0091c610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0091c610(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::FriendService_FriendStatus>::vftable;
  _DAT_01ef7858 = _DAT_01ef7858 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 16299 ; VA 0x0091c640 ; FUN_0091c640 */

undefined4 * __thiscall FUN_0091c640(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Player::ChatMode>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 16300 ; VA 0x0091c670 ; FUN_0091c670 */

undefined4 * __thiscall FUN_0091c670(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::MembershipType>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 16301 ; VA 0x0091c6a0 ; FUN_0091c6a0 */

undefined4 * __thiscall FUN_0091c6a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16302 ; VA 0x0091c6d0 ; FUN_0091c6d0 */

undefined4 * __thiscall FUN_0091c6d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16303 ; VA 0x0091c700 ; FUN_0091c700 */

undefined4 * __thiscall FUN_0091c700(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16304 ; VA 0x0091c730 ; FUN_0091c730 */

undefined4 * __thiscall FUN_0091c730(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Camera::CameraMode>::GetSet::vftable
  ;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16305 ; VA 0x0091c760 ; FUN_0091c760 */

undefined4 * __thiscall FUN_0091c760(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Player::ChatPrivacyMode>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16306 ; VA 0x0091c790 ; FUN_0091c790 */

undefined4 * __thiscall FUN_0091c790(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16307 ; VA 0x0091c7c0 ; FUN_0091c7c0 */

undefined4 * __thiscall FUN_0091c7c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16308 ; VA 0x0091c7f0 ; FUN_0091c7f0 */

undefined4 * __thiscall FUN_0091c7f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::StarterPlayerService::DeveloperComputerMovementMode>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16309 ; VA 0x0091c820 ; FUN_0091c820 */

undefined4 * __thiscall FUN_0091c820(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16310 ; VA 0x0091c850 ; FUN_0091c850 */

undefined4 * __thiscall FUN_0091c850(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::StarterPlayerService::DeveloperTouchMovementMode>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16311 ; VA 0x0091c880 ; FUN_0091c880 */

undefined4 * __thiscall FUN_0091c880(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::MembershipType>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16312 ; VA 0x0091c8b0 ; FUN_0091c8b0 */

undefined4 * __thiscall FUN_0091c8b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ModelInstance*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16313 ; VA 0x0091c8e0 ; FUN_0091c8e0 */

undefined4 * __thiscall FUN_0091c8e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::SpawnLocation*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16314 ; VA 0x0091c910 ; FUN_0091c910 */

undefined4 * __thiscall FUN_0091c910(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Team*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16315 ; VA 0x0091c940 ; FUN_0091c940 */

undefined4 __thiscall FUN_0091c940(undefined4 param_1,byte param_2)

{
  FUN_0091a0f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 16316 ; VA 0x0091c970 ; FUN_0091c970 */

undefined4 * __thiscall FUN_0091c970(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::
             SizeEnforcedLRUCache<__int64,class_std::shared_ptr<class_RBX::Animation>,struct_boost::hash<__int64>_>
             ::vftable;
  FUN_0091a0f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 16317 ; VA 0x0091c9a0 ; FUN_0091c9a0 */

undefined4 __thiscall FUN_0091c9a0(undefined4 param_1,byte param_2)

{
  FUN_0091c150();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 16318 ; VA 0x0091c9d0 ; FUN_0091c9d0 */

undefined4 * __thiscall FUN_0091c9d0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_std::out_of_range>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16319 ; VA 0x0091ca50 ; FUN_0091ca50 */

undefined4 * __thiscall FUN_0091ca50(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ModelInstance*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16320 ; VA 0x0091ca80 ; FUN_0091ca80 */

undefined4 * __thiscall FUN_0091ca80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::SpawnLocation*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16321 ; VA 0x0091cab0 ; FUN_0091cab0 */

undefined4 * __thiscall FUN_0091cab0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Team*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16322 ; VA 0x0091cae0 ; FUN_0091cae0 */

undefined4 * __thiscall FUN_0091cae0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16323 ; VA 0x0091cb10 ; FUN_0091cb10 */

undefined4 * __thiscall FUN_0091cb10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16324 ; VA 0x0091cb40 ; FUN_0091cb40 */

undefined4 * __thiscall FUN_0091cb40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16325 ; VA 0x0091cb70 ; FUN_0091cb70 */

undefined4 * __thiscall FUN_0091cb70(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Camera::CameraMode>::GetSet::vftable
  ;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16326 ; VA 0x0091cba0 ; FUN_0091cba0 */

undefined4 * __thiscall FUN_0091cba0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Player::ChatMode>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16327 ; VA 0x0091cbd0 ; FUN_0091cbd0 */

undefined4 * __thiscall FUN_0091cbd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Player::ChatPrivacyMode>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16328 ; VA 0x0091cc00 ; FUN_0091cc00 */

undefined4 * __thiscall FUN_0091cc00(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16329 ; VA 0x0091cc30 ; FUN_0091cc30 */

undefined4 * __thiscall FUN_0091cc30(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16330 ; VA 0x0091cc60 ; FUN_0091cc60 */

undefined4 * __thiscall FUN_0091cc60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::StarterPlayerService::DeveloperComputerMovementMode>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16331 ; VA 0x0091cc90 ; FUN_0091cc90 */

undefined4 * __thiscall FUN_0091cc90(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16332 ; VA 0x0091ccc0 ; FUN_0091ccc0 */

undefined4 * __thiscall FUN_0091ccc0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<enum_RBX::StarterPlayerService::DeveloperTouchMovementMode>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16333 ; VA 0x0091ccf0 ; FUN_0091ccf0 */

undefined4 * __thiscall FUN_0091ccf0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::MembershipType>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16334 ; VA 0x0091cd20 ; FUN_0091cd20 */

int * __thiscall FUN_0091cd20(int *param_1,byte param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a980;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00617290(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0xf8);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16335 ; VA 0x0091cda0 ; FUN_0091cda0 */

undefined4 __thiscall FUN_0091cda0(undefined4 param_1,byte param_2)

{
  FUN_0091a740();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x540);
  }
  return param_1;
}



/* FUNCTION 16336 ; VA 0x0091cdd0 ; FUN_0091cdd0 */

void FUN_0091cdd0(uint param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c7c90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_1 != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((param_1 & 0xfffffffe) + 4))(&stack0x0000000c,1);
    uStack_8 = 2;
    if (((param_1 != 0) && ((param_1 & 1) == 0)) &&
       (*(code **)(param_1 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
    }
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 16337 ; VA 0x0091ce60 ; FUN_0091ce60 */

int FUN_0091ce60(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c7cb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_1c != 0) {
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    iVar3 = FUN_0092c330(param_3,param_4);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 16338 ; VA 0x0091cf40 ; FUN_0091cf40 */

void __thiscall FUN_0091cf40(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_6f0ae427a8eed889b213d38f92ccf107>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 16339 ; VA 0x0091cf80 ; FUN_0091cf80 */

void __fastcall FUN_0091cf80(int param_1)

{
  FUN_01674ea0(*(undefined4 *)(param_1 + 0xc),0x20);
  return;
}



/* FUNCTION 16340 ; VA 0x0091cf90 ; FUN_0091cf90 */

void __fastcall FUN_0091cf90(int param_1)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a980;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    iVar2 = *piVar1;
    uStack_8 = 1;
    ExceptionList = &pvStack_10;
    FUN_00617290(*(undefined4 *)(iVar2 + 4));
    *(int *)(*piVar1 + 4) = iVar2;
    *(int *)*piVar1 = iVar2;
    *(int *)(*piVar1 + 8) = iVar2;
    piVar1[1] = 0;
    FUN_01674ea0(*piVar1,0xf8);
    FUN_01674ea0(piVar1,0x10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16341 ; VA 0x0091d010 ; FUN_0091d010 */

void FUN_0091d010(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(param_1,0x18);
  return;
}



/* FUNCTION 16342 ; VA 0x0091d060 ; FUN_0091d060 */

void FUN_0091d060(undefined4 *param_1,undefined4 param_2)

{
  FUN_0091b280(*param_1,param_2);
  return;
}



/* FUNCTION 16343 ; VA 0x0091d080 ; FUN_0091d080 */

void FUN_0091d080(int *param_1)

{
  char cVar1;
  int *piVar2;
  uint uVar3;
  void **ppvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  cVar1 = *(char *)((int)param_1 + 0xd);
  ppvVar4 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar4, cVar1 == '\0') {
    FUN_0091d080(param_1[2]);
    piVar2 = (int *)*param_1;
    uVar3 = param_1[6];
    uStack_8 = 0;
    if (uVar3 != 0) {
      if ((uVar3 & 1) == 0) {
        if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
          (**(code **)(uVar3 & 0xfffffffe))(param_1 + 8,param_1 + 8,2);
        }
      }
      param_1[6] = 0;
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(param_1,0x38);
    ppvVar4 = (void **)ExceptionList;
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16344 ; VA 0x0091d120 ; FUN_0091d120 */

void __thiscall FUN_0091d120(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_6f0ae427a8eed889b213d38f92ccf107>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 16345 ; VA 0x0091d160 ; FUN_0091d160 */

TypeDescriptor * FUN_0091d160(void)

{
  return &<lambda_6f0ae427a8eed889b213d38f92ccf107>::RTTI_Type_Descriptor;
}



/* FUNCTION 16346 ; VA 0x0091d170 ; FUN_0091d170 */

int FUN_0091d170(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c7ce0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    puVar4 = param_1 + 9;
    ExceptionList = &pvStack_10;
    do {
      *(undefined4 *)(param_3 + 0x24) = 0;
      piVar2 = (int *)*puVar4;
      uStack_8 = 1;
      if (piVar2 != (int *)0x0) {
        if (piVar2 == puVar4 + -9) {
          uVar3 = (**(code **)(*piVar2 + 4))(param_3);
          *(undefined4 *)(param_3 + 0x24) = uVar3;
          piVar2 = (int *)*puVar4;
          if (piVar2 == (int *)0x0) goto LAB_0091d1f2;
          (**(code **)(*piVar2 + 0x10))(CONCAT31((int3)((uint)*piVar2 >> 8),piVar2 != puVar4 + -9));
        }
        else {
          *(int **)(param_3 + 0x24) = piVar2;
        }
        *puVar4 = 0;
      }
LAB_0091d1f2:
      param_3 = param_3 + 0x28;
      puVar1 = puVar4 + 1;
      puVar4 = puVar4 + 10;
    } while (puVar1 != param_2);
  }
  uStack_8 = 0;
  FUN_0072a040();
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 16347 ; VA 0x0091d230 ; FUN_0091d230 */

void FUN_0091d230(undefined4 *param_1)

{
  FUN_008a65e0(*param_1,0);
  return;
}



/* FUNCTION 16348 ; VA 0x0091d250 ; FUN_0091d250 */

int * __thiscall FUN_0091d250(undefined4 param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  undefined auStack_f0 [200];
  undefined auStack_28 [8];
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c7d03;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  FUN_008f7870(param_1);
  piVar5 = (int *)*param_2;
  piVar2 = (int *)param_2[1];
  piStack_18 = piVar2;
  if (piVar5 != piVar2) {
    do {
      piVar1 = (int *)*piVar5;
      piVar2 = (int *)FUN_00888530();
      if ((piVar1 != piVar2) && (iVar6 = *piVar5, *(char *)(iVar6 + 0x21) != '\0')) {
        iVar3 = FUN_0088da50();
        if (iVar6 == iVar3) {
          iVar6 = *piVar5;
          iVar3 = FUN_0088da50();
          if (iVar6 != iVar3) {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Variant cast failed");
          }
          piVar2 = piVar5 + 2;
          if (piVar5[1] == 0) {
            piVar2 = (int *)0x0;
          }
          iVar6 = *piVar2;
          iVar3 = piVar2[1];
        }
        else {
          puVar4 = (undefined4 *)piVar5[1];
          if (puVar4 != (undefined4 *)0x0) {
            (*(code *)*puVar4)(piVar5 + 2,auStack_f0);
            puVar4 = (undefined4 *)piVar5[1];
          }
          iStack_8._0_1_ = 1;
          piVar2 = (int *)FUN_0088baa0();
          iVar6 = *piVar2;
          iVar3 = piVar2[1];
          iStack_8._0_1_ = 2;
          if (puVar4 != (undefined4 *)0x0) {
            (*(code *)puVar4[2])(auStack_f0);
          }
          iStack_8 = (uint)iStack_8._1_3_ << 8;
        }
        iStack_20 = iVar6;
        iStack_1c = iVar3;
        piVar2 = (int *)FUN_005e5570(auStack_28,&iStack_20,param_3);
      }
      piVar5 = piVar5 + 0x34;
    } while (piVar5 != piStack_18);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar5 = param_3 + 1;
    iVar6 = *piVar5;
    piVar2 = (int *)*piVar5;
    *piVar5 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      piVar2 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar5 = param_3 + 2;
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        piVar2 = (int *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar2;
}



/* FUNCTION 16349 ; VA 0x0091d3d0 ; FUN_0091d3d0 */

int __thiscall FUN_0091d3d0(int param_1,int param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7d18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 8) != 0) {
    ExceptionList = &pvStack_10;
    FUN_00580040(&param_2,param_2);
    if (param_2 != 0) {
      ExceptionList = pvStack_10;
      return param_2 + 8;
    }
  }
  uVar2 = FUN_0091a050("Unable to find key in unordered_map.");
  uStack_8 = 0;
  FUN_00917680(uVar2);
  pcVar1 = (code *)swi(3);
  iVar3 = (*pcVar1)();
  return iVar3;
}



/* FUNCTION 16350 ; VA 0x0091d440 ; FUN_0091d440 */

int __thiscall FUN_0091d440(int param_1,int param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7d18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 8) != 0) {
    ExceptionList = &pvStack_10;
    FUN_00580040(&param_2,param_2);
    if (param_2 != 0) {
      ExceptionList = pvStack_10;
      return param_2 + 0x20;
    }
  }
  uVar2 = FUN_0091a050("Unable to find key in unordered_map.");
  uStack_8 = 0;
  FUN_00917680(uVar2);
  pcVar1 = (code *)swi(3);
  iVar3 = (*pcVar1)();
  return iVar3;
}



/* FUNCTION 16351 ; VA 0x0091d4b0 ; FUN_0091d4b0 */

int FUN_0091d4b0(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_0091d530(param_2);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 16352 ; VA 0x0091d530 ; FUN_0091d530 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0091d530(int param_1,longlong *param_2)

{
  longlong lVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  longlong *plVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  float fVar9;
  bool bVar10;
  undefined *puStack_f0;
  char *pcStack_ec;
  float *pfStack_e8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  int iStack_54;
  undefined auStack_50 [8];
  undefined auStack_48 [4];
  undefined auStack_44 [4];
  int *piStack_40;
  undefined4 uStack_3c;
  longlong lStack_38;
  float fStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  float fStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7d8e;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_84 = _DAT_018e3fb0;
  uStack_80 = _UNK_018e3fb4;
  uStack_7c = _UNK_018e3fb8;
  uStack_78 = _UNK_018e3fbc;
  uStack_94 = _DAT_018e3fb0;
  uStack_90 = _UNK_018e3fb4;
  uStack_8c = _UNK_018e3fb8;
  uStack_88 = _UNK_018e3fbc;
  uStack_a4 = _DAT_018e3fb0;
  pfStack_e8 = (float *)0x91d58b;
  ExceptionList = &pvStack_10;
  iStack_54 = param_1;
  iVar4 = FUN_00562f00();
  if (iVar4 == 0) {
    if (DAT_01d84e8e != 0) {
      pfStack_e8 = (float *)0x0;
      puStack_f0 = (undefined *)(uint)DAT_01d84e8e;
      pcStack_ec = "Player:calculateNextSpawnLocation - ServiceProvider didn\'t have a Workspace";
      FUN_016774b0();
    }
    pfStack_e8 = (float *)0x1931668;
    pcStack_ec = (char *)0x91da3c;
    FUN_00550130();
    pfStack_e8 = (float *)&DAT_01c17198;
    pcStack_ec = auStack_44;
                    /* WARNING: Subroutine does not return */
    puStack_f0 = &UNK_0091da4a;
    FUN_0170c2a8();
  }
  pfStack_e8 = (float *)0x91d59d;
  piVar5 = (int *)FUN_008e5480();
  iStack_1c = *piVar5;
  if (iStack_1c != 0) {
    bVar10 = *(char *)(param_1 + 0x263) == '\0';
    if (bVar10) {
      pfStack_e8 = (float *)(param_1 + 0x278);
      pcStack_ec = (char *)0x91d5f7;
      puVar7 = (undefined4 *)FUN_0054ef60();
      uStack_8 = 1;
      uStack_14 = 2;
    }
    else {
      pfStack_e8 = (float *)0x0;
      pcStack_ec = "";
      piStack_40 = (int *)0x0;
      uStack_3c = 0xf;
      auStack_50[0] = 0;
      puStack_f0 = (undefined *)0x91d5d4;
      FUN_005542c0();
      puVar7 = (undefined4 *)auStack_50;
      uStack_8 = 0;
      uStack_14 = 1;
    }
    uStack_8 = (uint)bVar10;
    uVar8 = *puVar7;
    puStack_f0 = (undefined *)puVar7[3];
    pcStack_ec = (char *)*(undefined8 *)(puVar7 + 4);
    pfStack_e8 = (float *)((ulonglong)*(undefined8 *)(puVar7 + 4) >> 0x20);
    puVar7[4] = 0;
    puVar7[5] = 0xf;
    *(undefined *)puVar7 = 0;
    iStack_18 = FUN_00e472b0(param_1,uVar8,puVar7[1],puVar7[2]);
    if ((uStack_14 & 2) != 0) {
      uStack_14 = uStack_14 & 0xfffffffd;
      pfStack_e8 = (float *)0x91d660;
      FUN_005507b0();
    }
    uStack_8 = 0xffffffff;
    if ((uStack_14 & 1) != 0) {
      uStack_14 = uStack_14 & 0xfffffffe;
      pfStack_e8 = (float *)0x91d67c;
      FUN_005507b0();
    }
    iVar2 = iStack_18;
    if (iStack_18 != 0) {
      if (*(int *)(param_1 + 0x370) != 0) {
        LOCK();
        piVar5 = (int *)(*(int *)(param_1 + 0x370) + 4);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
      puStack_f0 = *(undefined **)(param_1 + 0x36c);
      pcStack_ec = *(char **)(param_1 + 0x370);
      pfStack_e8 = (float *)iVar4;
      plVar6 = (longlong *)FUN_00927580(auStack_44,iStack_18);
      lStack_38 = *plVar6;
      fStack_30 = *(float *)(plVar6 + 1);
      pfStack_e8 = (float *)0x91d6e6;
      uStack_28 = lStack_38;
      fStack_20 = fStack_30;
      puVar7 = (undefined4 *)FUN_00b077e0();
      pfStack_e8 = (float *)param_2;
      uStack_84 = *puVar7;
      uStack_80 = puVar7[1];
      uStack_7c = puVar7[2];
      uStack_78 = puVar7[3];
      uStack_94 = puVar7[4];
      uStack_90 = puVar7[5];
      uStack_8c = puVar7[6];
      uStack_88 = puVar7[7];
      uStack_a4 = puVar7[8];
      iStack_1c = *(undefined4 *)(iVar2 + 0x108);
      iStack_18 = iVar2 + 0x4c;
      FUN_0060e0c0(&puStack_f0,param_1);
      puStack_2c = (undefined4 *)FUN_00915820(auStack_48,FUN_0091d4b0);
      uStack_8 = 3;
      uVar8 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 4;
      puVar7 = (undefined4 *)FUN_01674e20(0x28);
      if (puVar7 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)0x0;
      }
      else {
        *puVar7 = 0;
        puVar7[1] = 1;
        puVar7[2] = FUN_00923530;
        puVar7[3] = FUN_0057e090;
        puVar7[4] = 0;
        puVar7[5] = iStack_18;
        puVar7[6] = *puStack_2c;
        puVar7[7] = 0;
        puVar7[8] = 0;
        if (puStack_2c[2] != 0) {
          LOCK();
          piVar5 = (int *)(puStack_2c[2] + 8);
          *piVar5 = *piVar5 + 1;
          UNLOCK();
        }
        puVar7[7] = puStack_2c[1];
        puVar7[8] = puStack_2c[2];
        puVar7[9] = puStack_2c[3];
      }
      pcStack_ec = (char *)0x91d7ca;
      pfStack_e8 = (float *)puVar7;
      FUN_016797d0();
      if (puVar7 != (undefined4 *)0x0) {
        LOCK();
        puVar7[1] = puVar7[1] + 1;
        UNLOCK();
      }
      uStack_14 = uStack_14 | 4;
      uStack_8._0_1_ = 5;
      pcStack_ec = (char *)0x91d7eb;
      param_2 = (longlong *)puVar7;
      pfStack_e8 = (float *)uVar8;
      FUN_01675290();
      param_1 = iStack_54;
      pfStack_e8 = (float *)&param_2;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      pcStack_ec = (char *)0x91d804;
      cVar3 = FUN_01679300();
      if (cVar3 != '\0') {
        pfStack_e8 = (float *)0x91d813;
        FUN_01679490();
        pfStack_e8 = (float *)&param_2;
        pcStack_ec = (char *)0x91d822;
        FUN_016791c0();
      }
      if (param_2 != (longlong *)0x0) {
        piVar5 = (int *)((int)param_2 + 4);
        LOCK();
        iVar4 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          pfStack_e8 = (float *)param_2;
          pcStack_ec = (char *)0x91d842;
          FUN_01674ea0();
        }
      }
      uStack_8 = 0xffffffff;
      fVar9 = fStack_30;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        piVar5 = piStack_40 + 2;
        iVar4 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          pfStack_e8 = (float *)0x91d860;
          (**(code **)(*piStack_40 + 4))();
          fVar9 = fStack_30;
        }
      }
      goto LAB_0091d925;
    }
  }
  pfStack_e8 = &fStack_6c;
  pcStack_ec = (char *)0x91d873;
  FUN_008b0280();
  uStack_3c = 0;
  fStack_20 = 0.0;
  lStack_38 = (ulonglong)(uint)DAT_018ce320 << 0x20;
  uStack_28 = (ulonglong)(uint)DAT_018ce320 << 0x20;
  if ((((0.0 < fStack_6c) || (0.0 < fStack_68)) || (0.0 < fStack_64)) ||
     (((fStack_60 < 0.0 || (fStack_5c < 0.0)) || (fStack_58 < 0.0)))) {
    fStack_20 = (fStack_58 + fStack_64) * DAT_018ce2f4 + 0.0;
    uStack_28 = CONCAT44(fStack_68 + DAT_018ce320,(fStack_60 + fStack_6c) * DAT_018ce2f4 + 0.0);
    lStack_38 = uStack_28;
  }
  iStack_1c = 0;
  fVar9 = fStack_20;
LAB_0091d925:
  lVar1 = lStack_38;
  if (DAT_01eaf35c != '\0') {
    pfStack_e8 = (float *)0x0;
    pcStack_ec = (char *)fStack_20;
    puStack_f0 = uStack_28._4_4_;
    FUN_016774d0(DAT_01eaf35c,"next spawn location = (%f,%f,%f)",(undefined4)uStack_28);
  }
  pfStack_e8 = (float *)0x40;
  pcStack_ec = (char *)0x91d984;
  param_2 = (longlong *)FUN_01674e20();
  if (param_2 == (longlong *)0x0) {
    plVar6 = (longlong *)0x0;
  }
  else {
    *param_2 = lStack_38;
    *(float *)(param_2 + 1) = fVar9;
    *(int *)((int)param_2 + 0xc) = iStack_1c;
    *(undefined4 *)(param_2 + 2) = uStack_84;
    *(undefined4 *)((int)param_2 + 0x14) = uStack_80;
    *(undefined4 *)(param_2 + 3) = uStack_7c;
    *(undefined4 *)((int)param_2 + 0x1c) = uStack_78;
    *(undefined4 *)(param_2 + 4) = uStack_94;
    *(undefined4 *)((int)param_2 + 0x24) = uStack_90;
    *(undefined4 *)(param_2 + 5) = uStack_8c;
    *(undefined4 *)((int)param_2 + 0x2c) = uStack_88;
    uStack_a0 = (undefined4)lVar1;
    uStack_9c = (undefined4)((ulonglong)lVar1 >> 0x20);
    *(undefined4 *)(param_2 + 6) = uStack_a4;
    *(undefined4 *)((int)param_2 + 0x34) = uStack_a0;
    *(undefined4 *)(param_2 + 7) = uStack_9c;
    *(float *)((int)param_2 + 0x3c) = fVar9;
    plVar6 = param_2;
  }
  pcStack_ec = *(char **)(param_1 + 0x2c0);
  *(longlong **)(param_1 + 0x2c0) = plVar6;
  if (pcStack_ec != (char *)0x0) {
    pfStack_e8 = (float *)0x40;
    puStack_f0 = (undefined *)0x91d9da;
    FUN_01674ea0();
    plVar6 = *(longlong **)(param_1 + 0x2c0);
  }
  pfStack_e8 = *(float **)(plVar6 + 1);
  puStack_f0 = (undefined *)*plVar6;
  pcStack_ec = (char *)((ulonglong)*plVar6 >> 0x20);
  FUN_0091bd20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16353 ; VA 0x0091da50 ; FUN_0091da50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * __thiscall
FUN_0091da50(int param_1,undefined8 *param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  undefined8 *puVar7;
  undefined4 *puVar8;
  undefined *puVar9;
  undefined4 uVar10;
  undefined4 in_stack_ffffff54;
  undefined4 in_stack_ffffff58;
  undefined4 in_stack_ffffff5c;
  undefined4 in_stack_ffffff60;
  undefined4 in_stack_ffffff64;
  undefined4 uVar11;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined auStack_3c [12];
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined auStack_24 [8];
  undefined8 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c7db0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  uStack_30 = 0;
  uStack_28 = 0;
  uStack_4c = _DAT_018e3fb0;
  uStack_48 = _UNK_018e3fb4;
  uStack_44 = _UNK_018e3fb8;
  uStack_40 = _UNK_018e3fbc;
  uStack_5c = _DAT_018e3fb0;
  uStack_58 = _UNK_018e3fb4;
  uStack_54 = _UNK_018e3fb8;
  uStack_50 = _UNK_018e3fbc;
  uStack_6c = _DAT_018e3fb0;
  ExceptionList = &pvStack_10;
  if (param_1 == 0) {
LAB_0091dd68:
    if (DAT_01d84e8e != '\0') {
      FUN_016774b0(DAT_01d84e8e,"Player:calculateNextSpawnLocation - Player not in the world",0);
    }
    FUN_00550130("calculateNextSpawnLocation can only be called when Player is in the world");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&uStack_30,&DAT_01c17198);
  }
  iStack_14 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  iVar3 = param_1;
  if ((iStack_14 != 0) &&
     (ExceptionList = &pvStack_10, iVar3 = iStack_14, *(int *)(iStack_14 + 0x34) != 0)) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_005c8ac0();
  }
  iStack_14 = iVar3;
  if (((iStack_14 == 0) ||
      (iVar3 = *(int *)(iStack_14 + 0xc), iVar4 = FUN_008a8c30(),
      (uint)*(ushort *)(iVar4 + 0x1da) <
      (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) ||
     (iVar3 = FUN_00562f00(), iStack_14 = iVar3, iVar3 == 0)) goto LAB_0091dd68;
  if ((*(char *)(param_1 + 0x263) == '\0') && (*(char *)(param_1 + 0x266) != '\0')) {
    uStack_4c = *(undefined4 *)(param_1 + 0x2c4);
    uStack_48 = *(undefined4 *)(param_1 + 0x2c8);
    uStack_44 = *(undefined4 *)(param_1 + 0x2cc);
    uStack_40 = *(undefined4 *)(param_1 + 0x2d0);
    uStack_5c = *(undefined4 *)(param_1 + 0x2d4);
    uStack_58 = *(undefined4 *)(param_1 + 0x2d8);
    uStack_54 = *(undefined4 *)(param_1 + 0x2dc);
    uStack_50 = *(undefined4 *)(param_1 + 0x2e0);
    uStack_6c = *(undefined4 *)(param_1 + 0x2e4);
    uStack_28 = *(undefined4 *)(param_1 + 0x2f0);
    uVar2 = *(undefined8 *)(param_1 + 0x2e8);
  }
  else {
    iVar4 = *(int *)(param_1 + 0x34);
    uStack_1c = CONCAT44(iVar4,(undefined4)uStack_1c);
    if (iVar4 == 0) {
      uStack_1c = CONCAT44(param_1,(undefined4)uStack_1c);
      iVar4 = param_1;
    }
    else if (*(int *)(iVar4 + 0x34) != 0) {
      iVar4 = FUN_005c8ac0();
      uStack_1c = CONCAT44(iVar4,(undefined4)uStack_1c);
    }
    if ((iVar4 != 0) &&
       (iVar4 = *(int *)(iVar4 + 0xc), iVar5 = FUN_008a8c30(), iVar3 = iStack_14,
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
       (uint)*(ushort *)(iVar5 + 0x1da))) {
      uVar11 = 0x91dbc2;
      piVar6 = (int *)FUN_008e5480();
      iVar3 = iStack_14;
      if (*piVar6 != 0) {
        FUN_0054ef60(param_3);
        iVar4 = FUN_00e472b0(param_1,in_stack_ffffff54,in_stack_ffffff58,in_stack_ffffff5c,
                             in_stack_ffffff60,in_stack_ffffff64,uVar11);
        iVar3 = iStack_14;
        if (iVar4 != 0) {
          if (DAT_01d6fa14 == '\0') {
            puVar9 = (undefined *)(param_1 + 0x36c);
          }
          else {
            puVar9 = (undefined *)&param_4;
          }
          FUN_00557fc0(puVar9);
          iStack_8._0_1_ = 1;
          FUN_00557fc0(auStack_24);
          puVar7 = (undefined8 *)FUN_00927580(auStack_3c,iVar4);
          uStack_30 = *puVar7;
          uVar11 = *(undefined4 *)(puVar7 + 1);
          uStack_28 = uVar11;
          uStack_1c = uStack_30;
          puVar8 = (undefined4 *)FUN_00b077e0();
          uVar10 = *(undefined4 *)(iVar4 + 0x108);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          uStack_4c = *puVar8;
          uStack_48 = puVar8[1];
          uStack_44 = puVar8[2];
          uStack_40 = puVar8[3];
          uStack_5c = puVar8[4];
          uStack_58 = puVar8[5];
          uStack_54 = puVar8[6];
          uStack_50 = puVar8[7];
          uStack_6c = puVar8[8];
          FUN_00550b30();
          goto LAB_0091dcb2;
        }
      }
    }
    iVar4 = FUN_009168a0(param_1);
    uVar2 = uStack_30;
    if (iVar4 != 0) {
      puVar7 = (undefined8 *)FUN_00e471d0(auStack_3c,iVar3);
      uStack_28 = *(undefined4 *)(puVar7 + 1);
      uVar2 = *puVar7;
    }
  }
  uStack_1c = uVar2;
  uVar10 = 0;
  uVar11 = uStack_28;
  uStack_30 = uStack_1c;
LAB_0091dcb2:
  if (DAT_01eaf35c != '\0') {
    FUN_016774d0(DAT_01eaf35c,"next spawn location = (%f,%f,%f)",(undefined4)uStack_30,
                 uStack_30._4_4_,uStack_28,0);
  }
  piVar6 = param_5;
  *param_2 = uStack_1c;
  *(undefined4 *)(param_2 + 1) = uVar11;
  *(undefined4 *)((int)param_2 + 0xc) = uVar10;
  *(undefined4 *)(param_2 + 2) = uStack_4c;
  *(undefined4 *)((int)param_2 + 0x14) = uStack_48;
  *(undefined4 *)(param_2 + 3) = uStack_44;
  *(undefined4 *)((int)param_2 + 0x1c) = uStack_40;
  *(undefined4 *)(param_2 + 4) = uStack_5c;
  *(undefined4 *)((int)param_2 + 0x24) = uStack_58;
  *(undefined4 *)(param_2 + 5) = uStack_54;
  *(undefined4 *)((int)param_2 + 0x2c) = uStack_50;
  uStack_68 = (undefined4)uStack_1c;
  uStack_64 = (undefined4)((ulonglong)uStack_1c >> 0x20);
  *(undefined4 *)(param_2 + 6) = uStack_6c;
  *(undefined4 *)((int)param_2 + 0x34) = uStack_68;
  *(undefined4 *)(param_2 + 7) = uStack_64;
  *(undefined4 *)((int)param_2 + 0x3c) = uVar11;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16354 ; VA 0x0091dda0 ; FUN_0091dda0 */

undefined __fastcall FUN_0091dda0(int param_1)

{
  return *(undefined *)(param_1 + 0x262);
}



/* FUNCTION 16355 ; VA 0x0091ddb0 ; FUN_0091ddb0 */

void FUN_0091ddb0(undefined4 param_1,code *param_2,undefined4 param_3,uint *param_4,uint *param_5)

{
  uint uVar1;
  uint uStack_244;
  uint uStack_240;
  uint uStack_23c;
  uint uStack_238;
  undefined8 uStack_234;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_160;
  undefined auStack_15c [240];
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7dd0;
  pvStack_10 = ExceptionList;
  uStack_48 = 0;
  uVar1 = *param_5;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    uStack_48 = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_5 + 2;
      uStack_58 = 0x91de22;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_5[2];
      uStack_3c = param_5[3];
      uStack_38 = param_5[4];
      uStack_34 = param_5[5];
      uStack_30 = *(undefined8 *)(param_5 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8 = 0;
  uStack_6c = 0;
  uStack_234 = CONCAT44(0x91de4f,(undefined4)uStack_234);
  uStack_22c = FUN_00888530();
  uStack_228 = 0;
  iStack_8._0_1_ = 1;
  uVar1 = *param_4;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_4 + 2,&uStack_244,0);
    }
    else {
      uStack_244 = param_4[2];
      uStack_240 = param_4[3];
      uStack_23c = param_4[4];
      uStack_238 = param_4[5];
      uStack_234 = *(undefined8 *)(param_4 + 6);
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_008bf820(auStack_15c);
  uStack_160 = 0x91debb;
  FUN_008bd310();
  iStack_8 = 0xffffffff;
  uStack_6c = 0x91dec8;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16356 ; VA 0x0091dee0 ; FUN_0091dee0 */

void FUN_0091dee0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7df0;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee1c34);
  uVar1 = *param_4;
  auStack_6c[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_6c;
  puVar4 = auStack_6c;
  if (uVar2 != 0) {
    auStack_6c[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_6 + 2;
      uStack_7c = 0x91df5f;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_1c;
      puVar4 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_6[2];
      uStack_60 = param_6[3];
      uStack_5c = param_6[4];
      uStack_58 = param_6[5];
      uStack_54 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_6c;
      puVar4 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar4;
  puStack_1c = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_a8 = param_5[2];
      uStack_a4 = param_5[3];
      uStack_a0 = param_5[4];
      uStack_9c = param_5[5];
      uStack_98 = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_00912d50();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0x91e041;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_98 = CONCAT44(0x91e05e,(undefined4)uStack_98);
  uStack_90 = uVar1;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16357 ; VA 0x0091e070 ; FUN_0091e070 */

void FUN_0091e070(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  int *piVar1;
  uint uVar2;
  uint uStack_244;
  uint uStack_240;
  uint uStack_23c;
  uint uStack_238;
  undefined8 uStack_234;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_160;
  undefined auStack_15c [232];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7e10;
  pvStack_10 = ExceptionList;
  uStack_48 = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_48 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_6 + 2;
      uStack_58 = 0x91e0e2;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_6[2];
      uStack_3c = param_6[3];
      uStack_38 = param_6[4];
      uStack_34 = param_6[5];
      uStack_30 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8 = 0;
  uStack_6c = 0;
  uStack_234 = CONCAT44(0x91e10f,(undefined4)uStack_234);
  uStack_22c = FUN_00888530();
  uStack_228 = 0;
  iStack_8._0_1_ = 1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2,&uStack_244,0);
    }
    else {
      uStack_244 = param_5[2];
      uStack_240 = param_5[3];
      uStack_23c = param_5[4];
      uStack_238 = param_5[5];
      uStack_234 = *(undefined8 *)(param_5 + 6);
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_008bf820(auStack_15c);
  uStack_160 = 0x91e17b;
  FUN_008bd310();
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_70 = *param_4;
  uStack_6c = param_4[1];
  iStack_8 = 0xffffffff;
  uStack_74 = 0x91e1b2;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16358 ; VA 0x0091e1d0 ; FUN_0091e1d0 */

void FUN_0091e1d0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7e30;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee1c34);
  uStack_14 = *param_4;
  uVar1 = param_4[1];
  auStack_70[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_6 + 2;
      uStack_80 = 0x91e255;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_6[2];
      uStack_64 = param_6[3];
      uStack_60 = param_6[4];
      uStack_5c = param_6[5];
      uStack_58 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_ac = param_5[2];
      uStack_a8 = param_5[3];
      uStack_a4 = param_5[4];
      uStack_a0 = param_5[5];
      uStack_9c = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_008bd490();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0x91e337;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0x91e357);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16359 ; VA 0x0091e370 ; FUN_0091e370 */

void FUN_0091e370(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7e50;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee1c34);
  uStack_14 = *param_4;
  uVar1 = param_4[1];
  auStack_70[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_6 + 2;
      uStack_80 = 0x91e3f5;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_6[2];
      uStack_64 = param_6[3];
      uStack_60 = param_6[4];
      uStack_5c = param_6[5];
      uStack_58 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_ac = param_5[2];
      uStack_a8 = param_5[3];
      uStack_a4 = param_5[4];
      uStack_a0 = param_5[5];
      uStack_9c = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_008dbe80();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0x91e4d7;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0x91e4f7);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16360 ; VA 0x0091e510 ; FUN_0091e510 */

void FUN_0091e510(undefined4 param_1,code *param_2,undefined4 param_3,undefined8 *param_4,
                 undefined8 *param_5,uint *param_6,uint *param_7)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uStack_27c;
  uint uStack_278;
  uint uStack_274;
  uint uStack_270;
  undefined8 uStack_26c;
  undefined4 uStack_264;
  undefined4 uStack_260;
  undefined4 uStack_198;
  undefined auStack_194 [220];
  undefined4 uStack_b8;
  undefined8 uStack_b4;
  undefined4 uStack_ac;
  ulonglong uStack_a8;
  undefined4 uStack_90;
  uint *puStack_8c;
  uint *puStack_88;
  undefined4 uStack_84;
  uint uStack_80;
  uint uStack_78;
  uint uStack_74;
  uint uStack_70;
  uint uStack_6c;
  undefined8 uStack_68;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017c7e70;
  pvStack_1c = ExceptionList;
  uVar1 = *param_5;
  uVar2 = *param_4;
  uVar3 = *(undefined4 *)(param_4 + 1);
  uStack_80 = 0;
  uVar4 = *param_7;
  ExceptionList = &pvStack_1c;
  if (uVar4 != 0) {
    uStack_80 = uVar4;
    if ((uVar4 & 1) == 0) {
      puStack_88 = &uStack_78;
      uStack_84 = 0;
      puStack_8c = param_7 + 2;
      uStack_90 = 0x91e5b4;
      ExceptionList = &pvStack_1c;
      (**(code **)(uVar4 & 0xfffffffe))();
    }
    else {
      uStack_78 = param_7[2];
      uStack_74 = param_7[3];
      uStack_70 = param_7[4];
      uStack_6c = param_7[5];
      uStack_68 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_1c;
    }
  }
  iStack_14 = 0;
  uStack_a8 = (ulonglong)(uint)uStack_a8;
  uStack_26c = CONCAT44(0x91e5e1,(undefined4)uStack_26c);
  uStack_264 = FUN_00888530();
  uStack_260 = 0;
  iStack_14._0_1_ = 1;
  uVar4 = *param_6;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(param_6 + 2,&uStack_27c,0);
    }
    else {
      uStack_27c = param_6[2];
      uStack_278 = param_6[3];
      uStack_274 = param_6[4];
      uStack_270 = param_6[5];
      uStack_26c = *(undefined8 *)(param_6 + 6);
    }
  }
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_008bf820(auStack_194);
  uStack_198 = 0x91e64d;
  FUN_008bd310();
  iStack_14 = 0xffffffff;
  uStack_b8 = 0x91e679;
  uStack_b4 = uVar2;
  uStack_ac = uVar3;
  uStack_a8 = uVar1;
  (*param_2)();
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 16361 ; VA 0x0091e690 ; FUN_0091e690 */

int __thiscall FUN_0091e690(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined8 uVar8;
  undefined **ppuStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  undefined auStack_4c [20];
  undefined ***pppuStack_38;
  undefined auStack_34 [8];
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7ea8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  iStack_14 = FUN_008f7870(param_1);
  if (iStack_14 == 0) {
    piVar7 = *(int **)(param_2 + 0x24);
    iVar3 = 0;
    if (piVar7 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddc9c();
    }
  }
  else {
    iVar3 = *(int *)(param_1 + 0x304);
    if (iVar3 == 0) {
      iVar3 = *(int *)(param_1 + 0x30c);
      if (*(int *)(param_1 + 0x310) == iVar3) {
        FUN_00913840(iVar3,param_2);
      }
      else {
        *(undefined4 *)(iVar3 + 0x24) = 0;
        uStack_8 = 0;
        iStack_1c = iVar3;
        if (*(undefined4 **)(param_2 + 0x24) != (undefined4 *)0x0) {
          uVar4 = (**(code **)**(undefined4 **)(param_2 + 0x24))(iVar3);
          *(undefined4 *)(iVar3 + 0x24) = uVar4;
        }
        *(int *)(param_1 + 0x30c) = *(int *)(param_1 + 0x30c) + 0x28;
        uStack_8 = 0xffffffff;
      }
      iVar3 = (*(int *)(param_1 + 0x30c) - *(int *)(param_1 + 0x308)) / 0x28;
      if (iVar3 == 1) {
        puVar5 = (undefined4 *)FUN_0060dcd0(auStack_34,param_1);
        piVar7 = (int *)puVar5[1];
        if (piVar7 != (int *)0x0) {
          LOCK();
          piVar7[2] = piVar7[2] + 1;
          UNLOCK();
          piVar7 = (int *)puVar5[1];
        }
        uStack_2c = *puVar5;
        uStack_8 = 1;
        piStack_28 = piVar7;
        iStack_1c = uStack_2c;
        FUN_00550b30();
        FUN_014c9d60(&iStack_24,0);
        uStack_8._0_1_ = 2;
        piVar1 = *(int **)(iStack_14 + 0x43c);
        iVar3 = *piVar1;
        iVar2 = piVar1[1];
        uVar8 = FUN_00928340();
        puVar6 = (undefined4 *)
                 FUN_00f52e50(auStack_4c,uVar8,iVar3 - (int)piVar1,iVar2 - (int)piVar1);
        puVar5 = puVar6 + 4;
        uStack_8._0_1_ = 3;
        if (0xf < (uint)puVar6[5]) {
          puVar6 = (undefined4 *)*puVar6;
        }
        FUN_014cbbc0(puVar6,*puVar5);
        uStack_8._0_1_ = 2;
        FUN_005507b0();
        *(undefined4 *)(iStack_24 + 0xb0) = 0;
        FUN_014cba40();
        FUN_014cb890(1);
        if (piVar7 != (int *)0x0) {
          LOCK();
          piVar7[2] = piVar7[2] + 1;
          UNLOCK();
        }
        uStack_58 = iStack_1c;
        pppuStack_38 = &ppuStack_5c;
        ppuStack_5c = std::
                      _Func_impl_no_alloc<class_<lambda_6f0ae427a8eed889b213d38f92ccf107>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                      ::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        piStack_54 = piVar7;
        iVar3 = FUN_014cb530(pppuStack_38);
        if (pppuStack_38 != (undefined ***)0x0) {
          iVar3 = (*(code *)(*pppuStack_38)[4])(pppuStack_38 != &ppuStack_5c);
        }
        if (piStack_20 != (int *)0x0) {
          LOCK();
          piVar1 = piStack_20 + 1;
          iVar2 = *piVar1;
          iVar3 = *piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            piVar1 = piStack_20 + 2;
            iVar2 = *piVar1;
            iVar3 = *piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              iVar3 = (**(code **)(*piStack_20 + 4))();
            }
          }
        }
        if (piVar7 != (int *)0x0) {
          LOCK();
          piVar1 = piVar7 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            iVar3 = (**(code **)(*piVar7 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar3;
    }
    piVar7 = *(int **)(param_2 + 0x24);
    if (piVar7 == (int *)0x0) {
      iStack_14 = iVar3;
                    /* WARNING: Subroutine does not return */
      FUN_016ddc9c();
    }
  }
  iStack_14 = iVar3;
  iVar3 = (**(code **)(*piVar7 + 8))(&iStack_14);
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 16362 ; VA 0x0091e8e0 ; FUN_0091e8e0 */

void * FUN_0091e8e0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  undefined auStack_28 [4];
  undefined4 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    uStack_24 = 0x91e914;
    ExceptionList = &pvStack_10;
    iVar3 = FUN_0099be20();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4) {
      FUN_0060dcd0(auStack_28,param_1);
      FUN_00935530();
      uStack_24 = 0x91e950;
      pvVar4 = (void *)FUN_01679490();
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_24 = 0x91e969;
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_24 = 0x91e978;
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 16363 ; VA 0x0091e990 ; FUN_0091e990 */

uint __thiscall FUN_0091e990(undefined4 *param_1,float param_2)

{
  float fVar1;
  uint uVar2;
  undefined4 in_EAX;
  int iVar3;
  undefined4 *puVar4;
  float10 fVar6;
  undefined auStack_c [8];
  undefined2 uVar5;
  
  fVar1 = (float)param_1[5];
  uVar5 = (undefined2)((uint)in_EAX >> 0x10);
  iVar3 = (uint)CONCAT21(uVar5,(fVar1 == 0.0) << 6 | NAN(fVar1) << 2 | 2U | fVar1 < 0.0) << 8;
  if (NAN(fVar1) == (fVar1 == 0.0)) {
    fVar1 = (float)param_1[3];
    iVar3 = (uint)CONCAT21(uVar5,(fVar1 == 0.0) << 6 | NAN(fVar1) << 2 | 2U | fVar1 < 0.0) << 8;
    if (NAN(fVar1) == (fVar1 == 0.0)) {
      fVar1 = (float)param_1[4];
      iVar3 = (uint)CONCAT21(uVar5,(fVar1 == 0.0) << 6 | NAN(fVar1) << 2 | 2U | fVar1 < 0.0) << 8;
      if (NAN(fVar1) == (fVar1 == 0.0)) {
        fVar6 = (float10)FUN_009271a0();
        fVar1 = (float)(fVar6 + (float10)param_2);
        if ((float)param_1[3] < fVar1) {
          if (fVar1 <= (float)param_1[4]) {
            param_1[2] = fVar1;
            puVar4 = (undefined4 *)FUN_016830f0(auStack_c);
            *param_1 = *puVar4;
            uVar2 = puVar4[1];
            param_1[1] = uVar2;
            return uVar2 & 0xffffff00;
          }
          param_1[2] = param_1[4];
          puVar4 = (undefined4 *)FUN_016830f0(auStack_c);
          *param_1 = *puVar4;
          uVar2 = puVar4[1];
          param_1[1] = uVar2;
          return uVar2 & 0xffffff00;
        }
        param_1[2] = fVar1;
        puVar4 = (undefined4 *)FUN_016830f0(auStack_c);
        *param_1 = *puVar4;
        iVar3 = puVar4[1];
        param_1[1] = iVar3;
      }
    }
  }
  return CONCAT31((int3)((uint)iVar3 >> 8),1);
}



/* FUNCTION 16364 ; VA 0x0091ea50 ; FUN_0091ea50 */

uint __fastcall FUN_0091ea50(int param_1)

{
  float fVar1;
  uint uVar2;
  undefined4 in_EAX;
  undefined2 extraout_var;
  undefined2 uVar6;
  int iVar3;
  undefined4 *puVar4;
  undefined *puVar5;
  float10 fVar7;
  undefined auStack_1c [4];
  float fStack_18;
  undefined auStack_14 [4];
  float fStack_10;
  undefined auStack_c [4];
  float fStack_8;
  
  fStack_10 = (float)DAT_01ee1b6c;
  fStack_18 = (float)DAT_01ee1b68;
  if (((NAN(fStack_10) || NAN(*(float *)(param_1 + 0x42c))) ==
       (fStack_10 == *(float *)(param_1 + 0x42c))) ||
     (uVar6 = (undefined2)((uint)in_EAX >> 0x10),
     (NAN(fStack_10) || NAN(*(float *)(param_1 + 0x430))) ==
     (fStack_10 == *(float *)(param_1 + 0x430)))) {
    fVar7 = (float10)FUN_009271a0();
    fStack_8 = (float)fVar7;
    if (fStack_10 < fStack_8) {
      *(float *)(param_1 + 0x428) = fStack_10;
    }
    *(float *)(param_1 + 0x430) = fStack_10;
    *(float *)(param_1 + 0x42c) = fStack_10;
    *(float *)(param_1 + 0x434) = fStack_18;
    fVar1 = fStack_18;
    uVar6 = extraout_var;
  }
  else {
    fVar1 = *(float *)(param_1 + 0x434);
  }
  iVar3 = (uint)CONCAT21(uVar6,(fVar1 == 0.0) << 6 | NAN(fVar1) << 2 | 2U | fVar1 < 0.0) << 8;
  if (NAN(fVar1) == (fVar1 == 0.0)) {
    fVar1 = *(float *)(param_1 + 0x42c);
    iVar3 = (uint)CONCAT21(uVar6,(fVar1 == 0.0) << 6 | NAN(fVar1) << 2 | 2U | fVar1 < 0.0) << 8;
    if (NAN(fVar1) == (fVar1 == 0.0)) {
      fVar1 = *(float *)(param_1 + 0x430);
      iVar3 = (uint)CONCAT21(uVar6,(fVar1 == 0.0) << 6 | NAN(fVar1) << 2 | 2U | fVar1 < 0.0) << 8;
      if (NAN(fVar1) == (fVar1 == 0.0)) {
        fVar7 = (float10)FUN_009271a0();
        fStack_18 = (float)(fVar7 + (float10)DAT_018ce2f8);
        if (*(float *)(param_1 + 0x42c) < fStack_18) {
          fVar1 = *(float *)(param_1 + 0x430);
          if (fVar1 < fStack_18) {
            *(float *)(param_1 + 0x428) = fVar1;
            puVar5 = auStack_c;
          }
          else {
            *(float *)(param_1 + 0x428) = fStack_18;
            puVar5 = auStack_14;
          }
          puVar4 = (undefined4 *)FUN_016830f0(puVar5);
          *(undefined4 *)(param_1 + 0x420) = *puVar4;
          uVar2 = puVar4[1];
          *(uint *)(param_1 + 0x424) = uVar2;
          return uVar2 & 0xffffff00;
        }
        *(float *)(param_1 + 0x428) = fStack_18;
        puVar4 = (undefined4 *)FUN_016830f0(auStack_1c);
        *(undefined4 *)(param_1 + 0x420) = *puVar4;
        iVar3 = puVar4[1];
        *(int *)(param_1 + 0x424) = iVar3;
      }
    }
  }
  return CONCAT31((int3)((uint)iVar3 >> 8),1);
}



/* FUNCTION 16365 ; VA 0x0091eb80 ; FUN_0091eb80 */

uint __fastcall FUN_0091eb80(int param_1)

{
  undefined4 in_EAX;
  undefined2 extraout_var;
  undefined2 uVar4;
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  float10 fVar5;
  float10 extraout_ST0;
  float fVar6;
  float fVar7;
  undefined auStack_14 [4];
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fVar6 = *(float *)(param_1 + 0x414);
  fStack_c = (float)DAT_01ee1b60;
  fStack_10 = (float)DAT_01ee1b64;
  if ((NAN(fStack_c) || NAN(fVar6)) != (fStack_c == fVar6)) {
    fVar7 = *(float *)(param_1 + 0x418);
    uVar4 = (undefined2)((uint)in_EAX >> 0x10);
    if ((NAN(fStack_10) || NAN(fVar7)) != (fStack_10 == fVar7)) goto LAB_0091ebfe;
  }
  fVar5 = (float10)FUN_0061f160();
  fStack_8 = (float)fVar5;
  if (*(float *)(param_1 + 0x414) < fStack_8) {
    *(float *)(param_1 + 0x410) = *(float *)(param_1 + 0x414);
  }
  *(float *)(param_1 + 0x414) = fStack_c;
  *(float *)(param_1 + 0x418) = fStack_10;
  fVar6 = fStack_c;
  fVar7 = fStack_10;
  uVar4 = extraout_var;
LAB_0091ebfe:
  iVar1 = (uint)CONCAT21(uVar4,(fVar7 == 0.0) << 6 | NAN(fVar7) << 2 | 2U | fVar7 < 0.0) << 8;
  if ((NAN(fVar7) == (fVar7 == 0.0)) &&
     (iVar1 = (uint)CONCAT21(uVar4,(fVar6 == 0.0) << 6 | NAN(fVar6) << 2 | 2U | fVar6 < 0.0) << 8,
     NAN(fVar6) == (fVar6 == 0.0))) {
    uVar2 = FUN_0061f160();
    fStack_10 = (float)(extraout_ST0 + (float10)DAT_018ce2f8);
    if (*(float *)(param_1 + 0x414) <= fStack_10 && fStack_10 != *(float *)(param_1 + 0x414)) {
      return uVar2 & 0xffffff00;
    }
    *(float *)(param_1 + 0x410) = fStack_10;
    puVar3 = (undefined4 *)FUN_016830f0(auStack_14);
    *(undefined4 *)(param_1 + 0x408) = *puVar3;
    iVar1 = puVar3[1];
    *(int *)(param_1 + 0x40c) = iVar1;
  }
  return CONCAT31((int3)((uint)iVar1 >> 8),1);
}



/* FUNCTION 16366 ; VA 0x0091ec60 ; FUN_0091ec60 */

void __fastcall FUN_0091ec60(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  piVar1 = (int *)*param_1;
  piVar4 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar4 != (int *)*param_1) {
    do {
      piVar1 = (int *)piVar4[6];
      piVar2 = (int *)*piVar4;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[1] + -1;
        piVar1[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar3 = piVar1[2] + -1;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar4,0x20);
      piVar4 = piVar2;
    } while (piVar2 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 16367 ; VA 0x0091ecd0 ; FUN_0091ecd0 */

void __fastcall FUN_0091ecd0(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  piVar3 = (int *)*piVar1;
  ExceptionList = &pvStack_10;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar3 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar3;
      uVar2 = piVar3[2];
      uStack_8 = 0;
      if (uVar2 != 0) {
        if ((uVar2 & 1) == 0) {
          if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar2 & 0xfffffffe))(piVar3 + 4,piVar3 + 4,2);
          }
        }
        piVar3[2] = 0;
      }
      uStack_8 = 0xffffffff;
      FUN_01674ea0(piVar3,0x28);
      piVar3 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16368 ; VA 0x0091ed60 ; FUN_0091ed60 */

void FUN_0091ed60(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined auStack_100 [8];
  undefined4 *puStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  int aiStack_e4 [7];
  undefined4 uStack_c8;
  undefined auStack_c4 [48];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_70;
  undefined *puStack_6c;
  undefined4 *puStack_68;
  undefined4 *puStack_64;
  undefined4 *puStack_60;
  undefined auStack_50 [24];
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c7ee8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puStack_64 = (undefined4 *)0x91ed90;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_008f7870();
  if (puVar5 == (undefined4 *)0x0) {
    puStack_68 = (undefined4 *)0x91edab;
    puStack_64 = puVar5;
    puStack_60 = puVar5;
    FUN_0091b750();
  }
  else {
    uStack_38 = 0;
    piStack_34 = (int *)0x0;
    puStack_60 = (undefined4 *)0x1;
    puStack_64 = &uStack_38;
    uStack_8._0_1_ = 1;
    puStack_68 = &param_1;
    puStack_6c = (undefined *)0x91edd7;
    cVar4 = FUN_00925320();
    if (cVar4 == '\0') {
      if (puVar5 == (undefined4 *)0xfffffff4) {
        uStack_14 = 0;
      }
      else {
        puStack_60 = (undefined4 *)0x91ee49;
        uStack_14 = FUN_005c2760();
      }
      puStack_60 = (undefined4 *)0x91ee5a;
      uVar6 = FUN_008ccd70();
      puVar5 = param_1;
      puStack_60 = (undefined4 *)param_2;
      puStack_68 = (undefined4 *)auStack_50;
      uStack_18 = CONCAT31(uStack_18._1_3_,DAT_01ee1c35);
      uStack_1c = CONCAT31(uStack_1c._1_3_,DAT_01ee1c36);
      puStack_64 = param_1;
      uStack_20 = CONCAT31(uStack_20._1_3_,DAT_01ee1c34);
      puStack_6c = (undefined *)0x91ee8a;
      uStack_28 = FUN_009cc3c0();
      puStack_60 = (undefined4 *)0x1;
      puStack_64 = (undefined4 *)0x3;
      uStack_8._0_1_ = 3;
      puStack_e8 = &param_3;
      uStack_8c = 0;
      piStack_2c = aiStack_e4;
      uStack_ec = 0x91eeb6;
      puStack_68 = (undefined4 *)uVar6;
      FUN_0054f510();
      puStack_e8 = (undefined4 *)uStack_18;
      uStack_8._0_1_ = 4;
      uStack_ec = uStack_1c;
      uStack_f0 = uStack_20;
      uStack_f4 = param_2;
      puStack_f8 = puVar5;
      FUN_0060dcd0(auStack_100,uStack_24);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_00915a00(auStack_c4,FUN_0092eb80);
      uStack_c8 = 0x91eef1;
      FUN_00912fe0();
      uStack_8c = 0x42200000;
      uStack_90 = uStack_28;
      uStack_94 = 0x91ef04;
      FUN_008d0b40();
      puStack_60 = (undefined4 *)0x91ef0c;
      FUN_005507b0();
      piVar1 = piStack_34;
    }
    else {
      puStack_64 = &uStack_30;
      puStack_60 = (undefined4 *)0x3;
      puStack_68 = (undefined4 *)0x91ede9;
      puStack_68 = (undefined4 *)FUN_0089d950();
      puStack_6c = (undefined *)&puStack_64;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      uStack_70 = 0x91edf9;
      FUN_00916f90();
      puStack_68 = (undefined4 *)0x91ee04;
      FUN_0091b750();
      piVar2 = piStack_2c;
      piVar1 = piStack_34;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          puStack_60 = (undefined4 *)0x91ee1d;
          (**(code **)*piStack_2c)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          piVar1 = piStack_34;
          if (iVar3 == 0) {
            puStack_60 = (undefined4 *)0x91ee2d;
            (**(code **)(*piVar2 + 4))();
            piVar1 = piStack_34;
          }
        }
      }
    }
    piStack_34 = piVar1;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        puStack_60 = (undefined4 *)0x91ef25;
        (**(code **)*piVar1)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          puStack_60 = (undefined4 *)0x91ef34;
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  uStack_8 = 5;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_68 = (undefined4 *)&stack0x00000014;
    puStack_60 = (undefined4 *)0x2;
    puStack_6c = (undefined *)0x91ef58;
    puStack_64 = puStack_68;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16369 ; VA 0x0091ef70 ; FUN_0091ef70 */

void FUN_0091ef70(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  uint in_stack_00000018;
  undefined4 *in_stack_0000001c;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined auStack_100 [8];
  undefined4 *puStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  int aiStack_e4 [7];
  undefined4 uStack_c8;
  undefined auStack_c4 [48];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_70;
  undefined *puStack_6c;
  undefined4 *puStack_68;
  undefined4 *puStack_64;
  undefined4 *puStack_60;
  undefined auStack_50 [24];
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017c7f30;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_64 = (undefined4 *)0x91efa0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_008f7870();
  if (puVar5 == (undefined4 *)0x0) {
    puStack_68 = (undefined4 *)0x91efbb;
    puStack_64 = puVar5;
    puStack_60 = puVar5;
    FUN_0091b750();
  }
  else {
    uStack_38 = 0;
    piStack_34 = (int *)0x0;
    puStack_60 = (undefined4 *)0x1;
    puStack_64 = &uStack_38;
    uStack_8._0_1_ = 2;
    puStack_68 = &stack0x0000001c;
    puStack_6c = (undefined *)0x91efe7;
    cVar4 = FUN_00925320();
    if (cVar4 == '\0') {
      if (puVar5 == (undefined4 *)0xfffffff4) {
        uStack_14 = 0;
      }
      else {
        puStack_60 = (undefined4 *)0x91f059;
        uStack_14 = FUN_005c2760();
      }
      puStack_60 = (undefined4 *)0x91f06a;
      uVar6 = FUN_008ccd70();
      puVar5 = in_stack_0000001c;
      puStack_60 = (undefined4 *)in_stack_00000020;
      puStack_68 = (undefined4 *)auStack_50;
      uStack_18 = CONCAT31(uStack_18._1_3_,DAT_01ee1c35);
      uStack_1c = CONCAT31(uStack_1c._1_3_,DAT_01ee1c36);
      puStack_64 = in_stack_0000001c;
      uStack_20 = CONCAT31(uStack_20._1_3_,DAT_01ee1c34);
      puStack_6c = (undefined *)0x91f09a;
      uStack_28 = FUN_009cc3c0();
      puStack_60 = (undefined4 *)0x1;
      puStack_64 = (undefined4 *)0x3;
      uStack_8._0_1_ = 4;
      puStack_e8 = &stack0x00000024;
      uStack_8c = 0;
      piStack_2c = aiStack_e4;
      uStack_ec = 0x91f0c6;
      puStack_68 = (undefined4 *)uVar6;
      FUN_0054f510();
      puStack_e8 = (undefined4 *)uStack_18;
      uStack_8._0_1_ = 5;
      uStack_ec = uStack_1c;
      uStack_f0 = uStack_20;
      uStack_f4 = in_stack_00000020;
      puStack_f8 = puVar5;
      FUN_0060dcd0(auStack_100,uStack_24);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_00915a00(auStack_c4,FUN_0092eb80);
      uStack_c8 = 0x91f101;
      FUN_00912fe0();
      uStack_8c = 0x42200000;
      uStack_90 = uStack_28;
      uStack_94 = 0x91f114;
      FUN_008d0b40();
      puStack_60 = (undefined4 *)0x91f11c;
      FUN_005507b0();
      piVar1 = piStack_34;
    }
    else {
      puStack_64 = &uStack_30;
      puStack_60 = (undefined4 *)0x3;
      puStack_68 = (undefined4 *)0x91eff9;
      puStack_68 = (undefined4 *)FUN_0089d950();
      puStack_6c = (undefined *)&puStack_64;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      uStack_70 = 0x91f009;
      FUN_00916f90();
      puStack_68 = (undefined4 *)0x91f014;
      FUN_0091b750();
      piVar2 = piStack_2c;
      piVar1 = piStack_34;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          puStack_60 = (undefined4 *)0x91f02d;
          (**(code **)*piStack_2c)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          piVar1 = piStack_34;
          if (iVar3 == 0) {
            puStack_60 = (undefined4 *)0x91f03d;
            (**(code **)(*piVar2 + 4))();
            piVar1 = piStack_34;
          }
        }
      }
    }
    piStack_34 = piVar1;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        puStack_60 = (undefined4 *)0x91f135;
        (**(code **)*piVar1)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          puStack_60 = (undefined4 *)0x91f144;
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < in_stack_00000018) {
    puStack_60 = (undefined4 *)(in_stack_00000018 + 1);
    puVar5 = param_1;
    if (0xfff < puStack_60) {
      puVar5 = (undefined4 *)param_1[-1];
      puStack_60 = (undefined4 *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        puStack_60 = (undefined4 *)&UNK_0091f1c9;
        FUN_017167a3();
      }
    }
    puStack_68 = (undefined4 *)0x91f175;
    puStack_64 = puVar5;
    FUN_01674ea0();
  }
  uStack_8 = 6;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    puStack_68 = (undefined4 *)&stack0x0000002c;
    puStack_60 = (undefined4 *)0x2;
    puStack_6c = (undefined *)0x91f1ae;
    puStack_64 = puStack_68;
    (**(code **)(in_stack_00000024 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16370 ; VA 0x0091f1ca ; FUN_0091f1ca */

void FUN_0091f1ca(void)

{
  FUN_0091f1e0();
  return;
}



/* FUNCTION 16371 ; VA 0x0091f1e0 ; FUN_0091f1e0 */

int __fastcall FUN_0091f1e0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7f7b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_01930024;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::out_of_range::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>::
         vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 16372 ; VA 0x0091f300 ; FUN_0091f300 */

undefined4 * __thiscall
FUN_0091f300(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c7fc1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00922680;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16373 ; VA 0x0091f4b0 ; FUN_0091f4b0 */

undefined4 * __thiscall
FUN_0091f4b0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8001;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_009232d0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16374 ; VA 0x0091f650 ; FUN_0091f650 */

undefined4 * __thiscall
FUN_0091f650(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8041;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00922780;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16375 ; VA 0x0091f800 ; FUN_0091f800 */

undefined4 * __thiscall
FUN_0091f800(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8081;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0089f8b0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16376 ; VA 0x0091f9b0 ; FUN_0091f9b0 */

undefined4 * __thiscall
FUN_0091f9b0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a57f1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0068afb0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16377 ; VA 0x0091fb50 ; FUN_0091fb50 */

undefined4 * __thiscall
FUN_0091fb50(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c80c1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_009229b0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16378 ; VA 0x0091fd00 ; FUN_0091fd00 */

undefined4 * __thiscall
FUN_0091fd00(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8101;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00922b20;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16379 ; VA 0x0091feb0 ; FUN_0091feb0 */

undefined4 * __thiscall
FUN_0091feb0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8141;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00922c30;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16380 ; VA 0x00920060 ; FUN_00920060 */

undefined4 * __thiscall
FUN_00920060(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8181;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_009233b0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16381 ; VA 0x00920200 ; FUN_00920200 */

undefined4 * __thiscall
FUN_00920200(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c81c1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00922d80;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16382 ; VA 0x009203b0 ; FUN_009203b0 */

undefined4 * __thiscall
FUN_009203b0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8201;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00922f70;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16383 ; VA 0x00920560 ; FUN_00920560 */

undefined4 * __thiscall
FUN_00920560(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8241;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00923110;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16384 ; VA 0x00920710 ; FUN_00920710 */

undefined4 * __thiscall
FUN_00920710(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8281;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_009231a0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16385 ; VA 0x009208c0 ; FUN_009208c0 */

void __fastcall FUN_009208c0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x24);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    *(undefined8 *)(puVar1 + 6) = 0;
    puVar1[8] = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00916a50(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 16386 ; VA 0x00920920 ; FUN_00920920 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00920920(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00935a60();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ee22ec) {
      FUN_016f3809(&DAT_01ee22ec);
      if (DAT_01ee22ec == -1) {
        _DAT_01ee22e0 = FUN_005c65e0;
        _DAT_01ee22e4 = FUN_005c65e0;
        _DAT_01ee22e8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ee22ec);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01ee22e0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01ee22e0;
  }
  return;
}



/* FUNCTION 16387 ; VA 0x009209e0 ; FUN_009209e0 */

void FUN_009209e0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00935b10();
    *param_2 = uVar3;
    iVar4 = FUN_00935f00();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 16388 ; VA 0x00920a40 ; FUN_00920a40 */

void FUN_00920a40(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00935ba0();
    *param_2 = uVar3;
    iVar4 = FUN_00935f70();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 16389 ; VA 0x00920aa0 ; FUN_00920aa0 */

void FUN_00920aa0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00935c30();
    *param_2 = uVar3;
    iVar4 = FUN_00935ff0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 16390 ; VA 0x00920b00 ; FUN_00920b00 */

void FUN_00920b00(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00935cc0();
    *param_2 = uVar3;
    iVar4 = FUN_00936060();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 16391 ; VA 0x00920b60 ; FUN_00920b60 */

void FUN_00920b60(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00935d50();
    *param_2 = uVar3;
    iVar4 = FUN_009360d0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 16392 ; VA 0x00920bc0 ; FUN_00920bc0 */

void FUN_00920bc0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00935de0();
    *param_2 = uVar3;
    iVar4 = FUN_00936140();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 16393 ; VA 0x00920c20 ; FUN_00920c20 */

void FUN_00920c20(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00935e70();
    *param_2 = uVar3;
    iVar4 = FUN_00936220();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 16394 ; VA 0x00920c80 ; FUN_00920c80 */

undefined * FUN_00920c80(undefined *param_1,undefined4 *param_2)

{
  char cVar1;
  undefined *puVar2;
  char *pcVar3;
  
  puVar2 = PTR_DAT_01d6423c;
  switch(*param_2) {
  case 1:
    FUN_0054eff0(PTR_s_BuildersClub_01d64240);
    return param_1;
  case 2:
    FUN_0054eff0(PTR_s_TurboBuildersClub_01d64244);
    return param_1;
  case 3:
    FUN_0054eff0(PTR_s_OutrageousBuildersClub_01d64248);
    return param_1;
  case 4:
    FUN_0054eff0(PTR_s_Premium_01d6424c);
    return param_1;
  default:
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    pcVar3 = puVar2;
  }
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(puVar2,(int)pcVar3 - (int)(puVar2 + 1));
  return param_1;
}



/* FUNCTION 16395 ; VA 0x00920d30 ; FUN_00920d30 */

void FUN_00920d30(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00935a60();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16396 ; VA 0x00920d70 ; FUN_00920d70 */

void FUN_00920d70(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935b10();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16397 ; VA 0x00920db0 ; FUN_00920db0 */

void FUN_00920db0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935ba0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16398 ; VA 0x00920df0 ; FUN_00920df0 */

void FUN_00920df0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935c30();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16399 ; VA 0x00920e30 ; FUN_00920e30 */

void FUN_00920e30(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935cc0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16400 ; VA 0x00920e70 ; FUN_00920e70 */

void FUN_00920e70(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935d50();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16401 ; VA 0x00920eb0 ; FUN_00920eb0 */

void FUN_00920eb0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935de0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16402 ; VA 0x00920ef0 ; FUN_00920ef0 */

void FUN_00920ef0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00935e70();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16403 ; VA 0x00920f30 ; FUN_00920f30 */

void FUN_00920f30(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  uVar5 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_005d6c30();
  if (iVar3 != 0) {
    do {
      FUN_0089d950(&iStack_18,3);
      uStack_8 = 0;
      if (iStack_18 != 0) {
        FUN_008a65e0(param_2,0);
      }
      piVar2 = piStack_14;
      uStack_8 = 0xffffffff;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_14[1] + -1;
        piStack_14[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      uVar5 = uVar5 + 1;
      uVar4 = FUN_005d6c30();
    } while (uVar5 < uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16404 ; VA 0x00920fe0 ; FUN_00920fe0 */

void FUN_00920fe0(int param_1,undefined4 param_2,char param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  uVar7 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_005d6c30();
  if (iVar4 != 0) {
    do {
      iVar4 = *(int *)(**(int **)(param_1 + 0x2c) + uVar7 * 8);
      if ((((param_3 != '\0') || (iVar4 == 0)) ||
          (iVar2 = *(int *)(iVar4 + 0xc), iVar5 = FUN_00d5e4a0(),
          (uint)*(ushort *)(iVar5 + 0x1da) <
          (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) ||
         (*(char *)(iVar4 + 0x174) != '\0')) {
        FUN_0089d950(&iStack_18,3);
        uStack_8 = 0;
        if (iStack_18 != 0) {
          FUN_008a65e0(param_2,0);
        }
        piVar3 = piStack_14;
        uStack_8 = 0xffffffff;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_14[1] + -1;
          piStack_14[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            piVar1 = piVar3 + 2;
            iVar4 = *piVar1 + -1;
            *piVar1 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
      }
      uVar7 = uVar7 + 1;
      uVar6 = FUN_005d6c30();
    } while (uVar7 < uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16405 ; VA 0x009210d0 ; FUN_009210d0 */

void __thiscall FUN_009210d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_2,param_2);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,&param_2);
  return;
}



/* FUNCTION 16406 ; VA 0x00921100 ; FUN_00921100 */

void __thiscall FUN_00921100(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_34 [48];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_34,param_2);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,auStack_34);
  return;
}



/* FUNCTION 16407 ; VA 0x00921130 ; FUN_00921130 */

void __thiscall FUN_00921130(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_10 [12];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_10,param_2);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,auStack_10);
  return;
}



/* FUNCTION 16408 ; VA 0x00921160 ; FUN_00921160 */

undefined4 * FUN_00921160(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_009164e0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 16409 ; VA 0x009211d0 ; FUN_009211d0 */

int __fastcall FUN_009211d0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8298;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00676db0();
  if ((iVar3 == 0) && (iVar3 = FUN_00983210(param_1), (char)iVar3 == '\0')) {
    FUN_009165a0(auStack_18);
    uStack_8 = 0;
    iVar3 = FUN_008a65e0(param_1,0);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 16410 ; VA 0x00921260 ; FUN_00921260 */

void __thiscall FUN_00921260(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088cb40();
    iStack_1b8 = 0;
    FUN_0054ef60(iVar1);
    iStack_1b8 = FUN_005c9d30();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16411 ; VA 0x00921490 ; FUN_00921490 */

void __thiscall FUN_00921490(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8320;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_006fcaa0(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088ca00();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16412 ; VA 0x00921690 ; FUN_00921690 */

void __thiscall FUN_00921690(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar2 = *(int *)(param_1 + 0x40);
  if (iVar2 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar5 = 2;
  }
  else {
    uStack_1bc = FUN_0088cb40();
    iStack_1b8 = 0;
    FUN_0054ef60(iVar2);
    iStack_1b8 = FUN_005c9d30();
    puStack_18 = &uStack_1bc;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar2 == 0);
  uStack_14 = uVar5;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x44);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    iStack_e8 = FUN_006309e0();
    puVar6 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_e8 != 0)) {
    (**(code **)(iStack_e8 + 8))(&uStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16413 ; VA 0x009218e0 ; FUN_009218e0 */

void __thiscall FUN_009218e0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x44);
  if (puVar2 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_1bc = FUN_0088daf0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar2;
    iStack_1b8 = FUN_005c9ef0();
    puVar6 = &uStack_1bc;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16414 ; VA 0x00921b00 ; FUN_00921b00 */

void __thiscall FUN_00921b00(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 *puVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar1 = *(undefined8 **)(param_1 + 0x40);
  if (puVar1 == (undefined8 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088d870();
    iStack_e8 = 0;
    uStack_e4 = *puVar1;
    uStack_dc = *(undefined4 *)(puVar1 + 1);
    iStack_e8 = FUN_006315b0();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(puVar1 == (undefined8 *)0x0);
  uStack_14 = uVar5;
  uVar3 = FUN_0088d870();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x44);
  if (puVar2 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_1bc = FUN_0088daf0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar2;
    iStack_1b8 = FUN_005c9ef0();
    puVar6 = &uStack_1bc;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16415 ; VA 0x00921d30 ; FUN_00921d30 */

void __thiscall FUN_00921d30(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar1 = *(undefined **)(param_1 + 0x44);
  if (puVar1 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088daf0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar1;
    iStack_1b8 = FUN_005c9ef0();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16416 ; VA 0x00921f60 ; FUN_00921f60 */

void __thiscall FUN_00921f60(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8320;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar1 = *(undefined8 **)(param_1 + 0x40);
  if (puVar1 == (undefined8 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088d870();
    iStack_e8 = 0;
    uStack_e4 = *puVar1;
    uStack_dc = *(undefined4 *)(puVar1 + 1);
    iStack_e8 = FUN_006315b0();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(puVar1 == (undefined8 *)0x0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_006fcaa0(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088ca00();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16417 ; VA 0x00922170 ; FUN_00922170 */

void __fastcall FUN_00922170(int param_1)

{
  if (0 < *(int *)(param_1 + 0x300)) {
    *(int *)(param_1 + 0x300) = *(int *)(param_1 + 0x300) + -1;
  }
  return;
}



/* FUNCTION 16418 ; VA 0x00922190 ; FUN_00922190 */

void __fastcall FUN_00922190(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00916ab0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 16419 ; VA 0x00922240 ; FUN_00922240 */

void __fastcall FUN_00922240(undefined4 param_1)

{
  char cVar1;
  undefined auStack_10 [12];
  
  cVar1 = FUN_00983210(param_1);
  if (cVar1 == '\0') {
    FUN_0089f4c0();
    return;
  }
  FUN_00550130("Cannot Destroy Player");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 16420 ; VA 0x00922280 ; FUN_00922280 */

float10 __thiscall FUN_00922280(int param_1,float param_2,float param_3,float param_4)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  float *pfVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  double dVar8;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 100) != 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0(&DAT_018db5cc,4);
    uStack_8 = 0;
    piVar2 = (int *)FUN_008a0cb0(auStack_28);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar7 = uStack_14 + 1;
      uVar5 = auStack_28[0];
      if (0xfff < uVar7) {
        uVar5 = *(uint *)(auStack_28[0] - 4);
        uVar7 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar7);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (piVar2 != (int *)0x0) {
      iVar1 = piVar2[3];
      iVar3 = FUN_00aff8c0();
      piVar6 = (int *)0x0;
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        piVar6 = piVar2;
      }
      if (piVar6 != (int *)0x0) {
        pfVar4 = (float *)(**(code **)(*piVar6 + 0xd0))();
        dVar8 = (double)((param_3 - pfVar4[1]) * (param_3 - pfVar4[1]) +
                         (param_2 - *pfVar4) * (param_2 - *pfVar4) +
                        (param_4 - pfVar4[2]) * (param_4 - pfVar4[2]));
        FUN_017267a0();
        ExceptionList = pvStack_10;
        return (float10)(float)dVar8;
      }
    }
  }
  ExceptionList = pvStack_10;
  return (float10)0;
}



/* FUNCTION 16421 ; VA 0x009223e0 ; FUN_009223e0 */

void __thiscall FUN_009223e0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined auStack_2c [8];
  undefined4 uStack_24;
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  
  if ((undefined4 *)(param_1 + 0x278) != param_3) {
    iStack_14 = param_3[4];
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    uStack_1c = 0x922407;
    puStack_18 = param_3;
    FUN_005542c0();
  }
  iStack_14 = 0x922411;
  iVar1 = FUN_008e46b0();
  if (iVar1 != 0) {
    puStack_18 = (undefined4 *)0x92241d;
    iStack_14 = param_1;
    FUN_00bdfb90();
  }
  uStack_24 = param_2;
  FUN_0060e0c0(auStack_2c,param_1);
  FUN_00915820(auStack_20,FUN_0091d4b0);
  uStack_24 = 0x92244b;
  FUN_009132c0();
  iStack_14 = param_2;
  puStack_18 = (undefined4 *)0x922453;
  FUN_0091d530();
  return;
}



/* FUNCTION 16422 ; VA 0x00922460 ; FUN_00922460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00922460(int param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  double *pdVar4;
  int iVar5;
  undefined **ppuVar6;
  int *piStack_68;
  undefined *puStack_64;
  undefined4 auStack_60 [2];
  undefined auStack_58 [20];
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  double dStack_20;
  int iStack_18;
  undefined4 *puStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    iVar3 = param_1;
    if ((iVar5 != 0) && (iVar3 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
      uStack_40 = (double)CONCAT44(0x922485,(undefined4)uStack_40);
      iVar3 = FUN_005c8ac0();
    }
    if (iVar3 != 0) {
      iVar5 = *(int *)(iVar3 + 0xc);
      uStack_40 = (double)CONCAT44(0x922499,(undefined4)uStack_40);
      iVar3 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        if ((NAN(*(double *)(param_1 + 0x448)) || NAN(_PTR_018c6f48)) ==
            (*(double *)(param_1 + 0x448) == _PTR_018c6f48)) {
          uStack_40 = (double)CONCAT44(&dStack_20,0x9224d7);
          pdVar4 = (double *)FUN_01682800();
          dStack_20 = *pdVar4 - *(double *)(param_1 + 0x448);
          if (_DAT_01d64250 < dStack_20) {
            uStack_40 = (double)CONCAT44(param_1,0x922500);
            iVar5 = FUN_0064e810();
            if ((iVar5 != 0) && (*(int *)(iVar5 + 0xf4) != 0)) {
              uStack_40 = (double)CONCAT44(1,param_1);
              uStack_44 = 0x922518;
              cVar2 = FUN_00973950();
              if (cVar2 != '\0') {
                uStack_40 = dStack_20;
                uStack_44 = 0x922537;
                FUN_008ec650();
              }
            }
          }
        }
        uStack_40 = (double)CONCAT44(param_1,0x92253d);
        iStack_18 = FUN_00899230();
        if (iStack_18 != 0) {
          puStack_14 = auStack_60;
          uStack_40 = (double)DAT_018ce310;
          FUN_0060dcd0(&piStack_68,param_1);
          FUN_006058b0(&uStack_30,FUN_00922460,0);
          piVar1 = piStack_24;
          uStack_c = uStack_30;
          uStack_10 = uStack_2c;
          if (piStack_24 != (int *)0x0) {
            LOCK();
            piStack_24[1] = piStack_24[1] + 1;
            UNLOCK();
          }
          piStack_8 = piStack_24 + 1;
          auStack_60[0] = 0;
          if (piStack_24 != (int *)0x0) {
            LOCK();
            *piStack_8 = *piStack_8 + 1;
            UNLOCK();
          }
          puStack_64 = auStack_58;
          if (piStack_24 != (int *)0x0) {
            LOCK();
            *piStack_8 = *piStack_8 + 1;
            UNLOCK();
          }
          ppuVar6 = &PTR_FUN_01932614;
          piStack_68 = piStack_24;
          cVar2 = FUN_00605370(uStack_30,uStack_2c,uStack_28);
          if (cVar2 == '\0') {
            ppuVar6 = (undefined **)0x0;
          }
          *puStack_14 = ppuVar6;
          if (piVar1 != (int *)0x0) {
            LOCK();
            iVar5 = *piStack_8;
            *piStack_8 = iVar5 + -1;
            UNLOCK();
            if (iVar5 + -1 == 0) {
              puStack_64 = (undefined *)0x922617;
              (**(code **)*piVar1)();
              LOCK();
              iVar5 = piVar1[2] + -1;
              piVar1[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                puStack_64 = (undefined *)0x922627;
                (**(code **)(*piVar1 + 4))();
              }
            }
            if (piVar1 != (int *)0x0) {
              LOCK();
              iVar5 = piVar1[1] + -1;
              piVar1[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                puStack_64 = (undefined *)0x92263a;
                (**(code **)*piVar1)();
                LOCK();
                iVar5 = piVar1[2] + -1;
                piVar1[2] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  puStack_64 = (undefined *)0x92264a;
                  (**(code **)(*piVar1 + 4))();
                }
              }
            }
          }
          if (piStack_24 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_24[1] + -1;
            piStack_24[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              puStack_64 = (undefined *)0x922663;
              (**(code **)*piStack_24)();
              LOCK();
              piVar1 = piStack_24 + 2;
              iVar5 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar5 == 1) {
                puStack_64 = (undefined *)0x922672;
                (**(code **)(*piStack_24 + 4))();
              }
            }
          }
          puStack_64 = (undefined *)0x92267a;
          FUN_009eef30();
        }
      }
    }
  }
  return;
}



/* FUNCTION 16423 ; VA 0x00922680 ; FUN_00922680 */

void FUN_00922680(int param_1,undefined4 param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_0088c960();
  uStack_ec = 0;
  uStack_e8 = param_2;
  uStack_ec = FUN_00630820();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16424 ; VA 0x00922780 ; FUN_00922780 */

void FUN_00922780(int param_1,uint param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  int in_stack_00000038;
  uint in_stack_0000004c;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8387;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 3;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  FUN_0054ef60(&param_2);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&stack0x00000020);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  FUN_0054ef60(&stack0x00000038);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 6;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,piVar1);
  uStack_8._0_1_ = 7;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 8;
  FUN_00577b20();
  uStack_8._0_1_ = 3;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    uVar6 = param_2;
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(param_2 - 4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000034) {
    uVar5 = in_stack_00000034 + 1;
    uVar6 = in_stack_00000020;
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(in_stack_00000020 - 4);
      uVar5 = in_stack_00000034 + 0x24;
      if (0x1f < (in_stack_00000020 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  if (0xf < in_stack_0000004c) {
    uVar6 = in_stack_0000004c + 1;
    iVar4 = in_stack_00000038;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(in_stack_00000038 + -4);
      uVar6 = in_stack_0000004c + 0x24;
      if (0x1f < (in_stack_00000038 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16425 ; VA 0x009229b0 ; FUN_009229b0 */

void FUN_009229b0(int param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined8 in_stack_00000020;
  undefined4 in_stack_00000028;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined8 uStack_e8;
  undefined4 uStack_e0;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c83dc;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&param_2);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088d870();
  uStack_ec = 0;
  uStack_e8 = in_stack_00000020;
  uStack_e0 = in_stack_00000028;
  uStack_ec = FUN_006315b0();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  uStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16426 ; VA 0x00922b20 ; FUN_00922b20 */

int FUN_00922b20(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_f0 [208];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8421;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_005c1420(&param_2);
  uStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_f0,&uStack_20,piVar3);
  uStack_8._0_1_ = 3;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 4;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_f0,0xd0,1,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 16427 ; VA 0x00922c30 ; FUN_00922c30 */

int FUN_00922c30(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbdd1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_f0 = FUN_0088cdc0();
  uStack_ec = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_2;
  piStack_e4 = param_3;
  uStack_ec = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 3;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 4;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 16428 ; VA 0x00922d80 ; FUN_00922d80 */

int FUN_00922d80(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                int *param_6)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c847f;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_290 = thunk_FUN_00adb7d0();
  uStack_28c = 0;
  uStack_288 = param_2;
  uStack_28c = FUN_00936290();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_008881d0();
  uStack_1bc = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_3;
  piStack_1b4 = param_4;
  uStack_1bc = FUN_0058c000();
  uStack_8._0_1_ = 4;
  uStack_f0 = FUN_0088cdc0();
  uStack_ec = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_5;
  piStack_e4 = param_6;
  uStack_ec = FUN_006309e0();
  uStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,pcVar3);
  uStack_8._0_1_ = 6;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iVar5 = FUN_01675290(uVar4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 16429 ; VA 0x00922f70 ; FUN_00922f70 */

void FUN_00922f70(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000028;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c84d7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_290 = thunk_FUN_00adb7d0();
  uStack_28c = 0;
  uStack_288 = param_2;
  uStack_28c = FUN_00936290();
  uStack_8._0_1_ = 2;
  uStack_1c0 = FUN_0088da50();
  uStack_1b8 = param_3;
  uStack_1bc = 0;
  uStack_1b4 = param_4;
  uStack_1bc = FUN_005c9e80();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  FUN_0054ef60(&param_5);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,piVar1);
  uStack_8._0_1_ = 5;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_01675290(uVar3);
  if (0xf < in_stack_00000028) {
    uVar5 = in_stack_00000028 + 1;
    iVar4 = param_5;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_5 + -4);
      uVar5 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16430 ; VA 0x00923110 ; FUN_00923110 */

void FUN_00923110(int param_1)

{
  undefined4 uVar1;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab320;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_02110da8);
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_14 = uVar1;
  (**(code **)(**(int **)(param_1 + 0x18) + 4))(&uStack_20);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00577b20();
  uStack_8 = 3;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16431 ; VA 0x009231a0 ; FUN_009231a0 */

void FUN_009231a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_0088da50();
  uStack_1b8 = param_2;
  uStack_1bc = 0;
  uStack_1b4 = param_3;
  uStack_1bc = FUN_005c9e80();
  iStack_8._0_1_ = 1;
  uStack_f0 = thunk_FUN_00bfa7a0();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_009361b0();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16432 ; VA 0x009232d0 ; FUN_009232d0 */

void FUN_009232d0(int param_1)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined auStack_f0 [208];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  FUN_006fcaa0(&stack0x00000008);
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16433 ; VA 0x009233b0 ; FUN_009233b0 */

int FUN_009233b0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3c7c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_f0 = thunk_FUN_00935e70();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_00936220();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 4;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 16434 ; VA 0x00923530 ; FUN_00923530 */

void FUN_00923530(int param_1)

{
  (**(code **)(param_1 + 0x18))(param_1 + 0x1c,*(undefined4 *)(param_1 + 0x24));
  return;
}



/* FUNCTION 16435 ; VA 0x00923550 ; FUN_00923550 */

void FUN_00923550(int param_1,undefined4 param_2)

{
  (**(code **)(param_1 + 0x18))(param_2);
  return;
}



/* FUNCTION 16436 ; VA 0x00923570 ; FUN_00923570 */

int FUN_00923570(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  pcVar3 = *(code **)(param_1 + 0x18);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 16437 ; VA 0x00923640 ; FUN_00923640 */

void FUN_00923640(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000028;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8538;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(param_1 + 0x18))(param_2);
  if (0xf < in_stack_00000028) {
    uVar2 = in_stack_00000028 + 1;
    iVar1 = param_5;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_5 + -4);
      uVar2 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16438 ; VA 0x009236c0 ; FUN_009236c0 */

void FUN_009236c0(int param_1,int param_2)

{
  code *pcVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017969d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  pcVar1 = *(code **)(param_1 + 0x18);
  FUN_0054ef60(aiStack_28);
  (*pcVar1)();
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16439 ; VA 0x009237a0 ; FUN_009237a0 */

int FUN_009237a0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                int *param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8560;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)&param_2;
  puStack_18 = (undefined *)&param_3;
  uStack_8 = 1;
  puStack_14 = (undefined *)&param_5;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00913510(param_1,param_1 + 0x18,&puStack_1c,0);
  piVar3 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_6)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 16440 ; VA 0x00923850 ; FUN_00923850 */

int __thiscall FUN_00923850(int param_1,int param_2,int param_3)

{
  float *pfVar1;
  float fVar2;
  uint3 uVar3;
  
  fVar2 = *(float *)(*(int *)(param_1 + 8) + param_2);
  pfVar1 = (float *)(*(int *)(param_1 + 8) + param_3);
  uVar3 = CONCAT21((short)((uint)param_3 >> 0x10),
                   (fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U |
                   fVar2 < *pfVar1);
  if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
    return CONCAT31(uVar3,1);
  }
  return (uint)uVar3 << 8;
}



/* FUNCTION 16441 ; VA 0x00923880 ; FUN_00923880 */

void __thiscall FUN_00923880(int param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar3 = (undefined4 *)(param_3 + *(int *)(param_1 + 8));
  puVar4 = (undefined4 *)(param_2 + *(int *)(param_1 + 8));
  puVar1 = puVar3 + 4;
  if (0xf < (uint)puVar3[5]) {
    puVar3 = (undefined4 *)*puVar3;
  }
  puVar2 = puVar4 + 4;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_0055c360(puVar4,*puVar2,puVar3,*puVar1);
  return;
}



/* FUNCTION 16442 ; VA 0x009238c0 ; FUN_009238c0 */

undefined __fastcall FUN_009238c0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))(aiStack_40);
  uStack_8 = 0;
  puVar5 = (undefined4 *)(**(code **)(param_1 + 8))(auStack_28);
  puVar1 = puVar4 + 4;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  puVar2 = puVar5 + 4;
  if (0xf < (uint)puVar5[5]) {
    puVar5 = (undefined4 *)*puVar5;
  }
  uVar3 = FUN_0055c360(puVar5,*puVar2,puVar4,*puVar1);
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    iVar6 = aiStack_40[0];
    if (0xfff < uVar8) {
      iVar6 = *(int *)(aiStack_40[0] + -4);
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 16443 ; VA 0x009239c0 ; FUN_009239c0 */

bool __fastcall FUN_009239c0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iStack_8;
  
  iStack_8 = param_1;
  piVar1 = (int *)(**(code **)(param_1 + 8))(&stack0x00000004);
  piVar2 = (int *)(**(code **)(param_1 + 8))(&iStack_8);
  return *piVar1 == *piVar2;
}



/* FUNCTION 16444 ; VA 0x00923a00 ; FUN_00923a00 */

undefined4 __fastcall FUN_00923a00(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined auStack_64 [48];
  undefined auStack_34 [48];
  
  iVar2 = (**(code **)(param_1 + 8))(auStack_34);
  iVar3 = (**(code **)(param_1 + 8))(auStack_64);
  if ((NAN(*(float *)(iVar2 + 0x24)) || NAN(*(float *)(iVar3 + 0x24))) !=
      (*(float *)(iVar2 + 0x24) == *(float *)(iVar3 + 0x24))) {
    if ((NAN(*(float *)(iVar2 + 0x28)) || NAN(*(float *)(iVar3 + 0x28))) !=
        (*(float *)(iVar2 + 0x28) == *(float *)(iVar3 + 0x28))) {
      if ((NAN(*(float *)(iVar2 + 0x2c)) || NAN(*(float *)(iVar3 + 0x2c))) !=
          (*(float *)(iVar2 + 0x2c) == *(float *)(iVar3 + 0x2c))) {
        cVar1 = FUN_01160ab0(iVar3);
        if (cVar1 != '\0') {
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 16445 ; VA 0x00923a80 ; FUN_00923a80 */

int __fastcall FUN_00923a80(int param_1)

{
  float *pfVar1;
  float fVar2;
  uint3 uVar3;
  float *pfVar4;
  float *pfVar5;
  int iVar6;
  undefined auStack_1c [12];
  undefined auStack_10 [12];
  undefined2 uVar7;
  
  pfVar4 = (float *)(**(code **)(param_1 + 8))(auStack_10);
  pfVar5 = (float *)(**(code **)(param_1 + 8))(auStack_1c);
  fVar2 = *pfVar4;
  uVar7 = (undefined2)((uint)pfVar5 >> 0x10);
  iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                               fVar2 < *pfVar5) << 8;
  if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
    fVar2 = pfVar4[1];
    pfVar1 = pfVar5 + 1;
    iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U |
                                 fVar2 < *pfVar1) << 8;
    if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
      fVar2 = pfVar4[2];
      pfVar5 = pfVar5 + 2;
      uVar3 = CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                             fVar2 < *pfVar5);
      iVar6 = (uint)uVar3 << 8;
      if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
        return CONCAT31(uVar3,1);
      }
    }
  }
  return iVar6;
}



/* FUNCTION 16446 ; VA 0x00923af0 ; FUN_00923af0 */

void __fastcall FUN_00923af0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar3 = (undefined4 *)(**(code **)(param_1 + 8))();
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))();
  puVar1 = puVar4 + 4;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  puVar2 = puVar3 + 4;
  if (0xf < (uint)puVar3[5]) {
    puVar3 = (undefined4 *)*puVar3;
  }
  FUN_0055c360(puVar3,*puVar2,puVar4,*puVar1);
  return;
}



/* FUNCTION 16447 ; VA 0x00923b40 ; FUN_00923b40 */

int __thiscall FUN_00923b40(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  undefined4 *puVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_005e9db0(param_2);
  iVar5 = *(int *)(param_1 + 0xc);
  piVar1 = *(int **)(param_1 + 4);
  piVar8 = *(int **)(iVar5 + iVar2 * 8);
  iVar2 = iVar2 * 8 + 4;
  piVar6 = piVar8;
  while( true ) {
    piVar3 = piVar1;
    if (piVar8 != piVar1) {
      piVar3 = (int *)**(undefined4 **)(iVar5 + iVar2);
    }
    if (piVar6 == piVar3) goto LAB_00923c06;
    if ((piVar6[2] == *param_2) && (piVar3 = piVar6, piVar6[3] == param_2[1])) break;
    piVar6 = (int *)*piVar6;
  }
  while( true ) {
    piVar4 = piVar1;
    if (piVar8 != piVar1) {
      piVar4 = (int *)**(undefined4 **)(iVar5 + iVar2);
    }
    if (((piVar3 == piVar4) || (*param_2 != piVar3[2])) || (param_2[1] != piVar3[3])) break;
    piVar3 = (int *)*piVar3;
  }
  if (piVar6 == piVar3) {
LAB_00923c06:
    piVar6 = piVar1;
    piVar3 = piVar1;
  }
  iVar2 = 0;
  for (piVar8 = piVar6; piVar8 != piVar3; piVar8 = (int *)*piVar8) {
    iVar2 = iVar2 + 1;
  }
  piVar8 = (int *)*piVar1;
  if ((piVar6 == piVar8) && (piVar3 == piVar1)) {
    *piVar1 = (int)piVar1;
    uStack_8 = 0;
    *(int *)(*(int *)(param_1 + 4) + 4) = *(int *)(param_1 + 4);
    *(undefined4 *)(param_1 + 8) = 0;
    if (piVar8 != *(int **)(param_1 + 4)) {
      do {
        piVar1 = (int *)*piVar8;
        FUN_01674ea0(piVar8,0x10);
        piVar8 = piVar1;
      } while (piVar1 != *(int **)(param_1 + 4));
    }
    FUN_005cb500(8);
  }
  else {
    while (piVar6 != piVar3) {
      piVar1 = (int *)*piVar6;
      iVar5 = FUN_005e9db0(piVar6 + 2);
      puVar7 = (undefined4 *)(*(int *)(param_1 + 0xc) + iVar5 * 8);
      if ((int *)puVar7[1] == piVar6) {
        if ((int *)*puVar7 == piVar6) {
          *puVar7 = *(undefined4 *)(param_1 + 4);
          *(undefined4 *)(iVar5 * 8 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
        }
        else {
          puVar7[1] = piVar6[1];
        }
      }
      else if ((int *)*puVar7 == piVar6) {
        *puVar7 = piVar1;
      }
      *(int *)piVar6[1] = *piVar6;
      *(int *)(*piVar6 + 4) = piVar6[1];
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
      FUN_01674ea0(piVar6,0x10);
      piVar6 = piVar1;
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 16448 ; VA 0x00923cf0 ; FUN_00923cf0 */

void __thiscall FUN_00923cf0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_0091e370(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16449 ; VA 0x00923db0 ; FUN_00923db0 */

void __thiscall FUN_00923db0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint in_stack_0000002c;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_3;
  puStack_c = &LAB_017c858b;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)*param_3)();
  if (iVar3 != 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8._0_1_ = 2;
    cVar2 = (**(code **)(*piVar1 + 4))(1,&uStack_ec);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_00889220();
      uVar5 = *puVar4;
      uStack_8._0_1_ = 3;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8._0_1_ = 1;
      goto LAB_00923e7a;
    }
    uStack_8._0_1_ = 4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8._0_1_ = 1;
  }
  if (*(undefined4 **)(param_1 + 0x40) == (undefined4 *)0x0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  uVar5 = **(undefined4 **)(param_1 + 0x40);
LAB_00923e7a:
  param_3 = (int *)uVar5;
  FUN_0091dee0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&param_3,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16450 ; VA 0x00923f20 ; FUN_00923f20 */

void __thiscall FUN_00923f20(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_0091e1d0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16451 ; VA 0x00923fe0 ; FUN_00923fe0 */

void __thiscall FUN_00923fe0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint in_stack_0000002c;
  undefined4 uStack_f4;
  int iStack_f0;
  undefined auStack_ec [200];
  undefined auStack_24 [4];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c85cb;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)*param_3)();
  if (iVar3 != 0) {
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8._0_1_ = 2;
    uStack_f4 = FUN_00888530();
    iStack_f0 = 0;
    uStack_8._0_1_ = 3;
    cVar2 = (**(code **)(*param_3 + 4))(1,&uStack_f4);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_0088a3d0();
      piVar5 = (int *)puVar4[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)puVar4[1];
      }
      uStack_18 = *puVar4;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      piStack_14 = piVar5;
      if (iStack_f0 != 0) {
        (**(code **)(iStack_f0 + 8))(auStack_ec);
      }
      FUN_00550b30();
      goto LAB_009240f0;
    }
    uStack_8._0_1_ = 5;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(auStack_ec);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00550b30();
  }
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_24,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  piVar5 = (int *)puVar4[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)puVar4[1];
  }
  uStack_18 = *puVar4;
  piStack_14 = piVar5;
LAB_009240f0:
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_0091e070(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar3 = piVar5[1] + -1;
    piVar5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16452 ; VA 0x009241c0 ; FUN_009241c0 */

void __thiscall FUN_009241c0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  undefined8 *puVar4;
  uint in_stack_0000002c;
  undefined4 uVar5;
  undefined4 uStack_f8;
  int iStack_f4;
  undefined auStack_f0 [200];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_1c [4];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8606;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)*param_3)();
  if (uVar2 < 2) {
LAB_009242a6:
    if (*(undefined8 **)(param_1 + 0x44) == (undefined8 *)0x0) {
      uVar5 = 2;
      goto LAB_009243fd;
    }
    uStack_18 = **(undefined8 **)(param_1 + 0x44);
  }
  else {
    cVar1 = (**(code **)(*param_3 + 0x14))(2,&uStack_24);
    if (cVar1 == '\0') {
      uStack_f8 = FUN_00888530();
      iStack_f4 = 0;
      uStack_8._0_1_ = 2;
      cVar1 = (**(code **)(*param_3 + 4))(2,&uStack_f8);
      if (cVar1 == '\0') {
        uStack_8._0_1_ = 4;
        if (iStack_f4 != 0) {
          (**(code **)(iStack_f4 + 8))(auStack_f0);
        }
        uStack_8._0_1_ = 1;
        goto LAB_009242a6;
      }
      puVar4 = (undefined8 *)FUN_008896a0();
      uStack_18 = *puVar4;
      uStack_8._0_1_ = 3;
      if (iStack_f4 != 0) {
        (**(code **)(iStack_f4 + 8))(auStack_f0);
      }
      uStack_8._0_1_ = 1;
    }
    else {
      uStack_18 = CONCAT44(uStack_20,uStack_24);
    }
  }
  iVar3 = (**(code **)*param_3)();
  if (iVar3 != 0) {
    uStack_f8 = FUN_00888530();
    iStack_f4 = 0;
    uStack_8._0_1_ = 5;
    cVar1 = (**(code **)(*param_3 + 4))(1,&uStack_f8);
    if (cVar1 != '\0') {
      puVar4 = (undefined8 *)FUN_0088b880();
      uStack_20 = *(undefined4 *)(puVar4 + 1);
      uStack_28 = (undefined4)*puVar4;
      uStack_24 = (undefined4)((ulonglong)*puVar4 >> 0x20);
      uStack_8._0_1_ = 6;
      if (iStack_f4 != 0) {
        (**(code **)(iStack_f4 + 8))(auStack_f0);
      }
      uStack_8._0_1_ = 1;
      goto LAB_00924372;
    }
    uStack_8._0_1_ = 7;
    if (iStack_f4 != 0) {
      (**(code **)(iStack_f4 + 8))(auStack_f0);
    }
    uStack_8._0_1_ = 1;
  }
  puVar4 = *(undefined8 **)(param_1 + 0x40);
  if (puVar4 == (undefined8 *)0x0) {
    uVar5 = 1;
LAB_009243fd:
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",uVar5);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  uStack_20 = *(undefined4 *)(puVar4 + 1);
  uStack_28 = (undefined4)*puVar4;
  uStack_24 = (undefined4)((ulonglong)*puVar4 >> 0x20);
LAB_00924372:
  FUN_0091e510(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_28,
               &uStack_18,&param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 9;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16453 ; VA 0x00924420 ; FUN_00924420 */

void __thiscall FUN_00924420(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0091ddb0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&param_4,
               &stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16454 ; VA 0x009244c0 ; FUN_009244c0 */

void __thiscall
FUN_009244c0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  code *pcVar1;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined8 uStack_b8;
  undefined4 uStack_b0;
  undefined auStack_ac [28];
  undefined4 uStack_90;
  undefined4 *puStack_8c;
  undefined4 *puStack_88;
  undefined4 uStack_84;
  undefined4 uStack_70;
  undefined4 *puStack_6c;
  undefined4 *puStack_68;
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_24;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_18 = &LAB_017c862e;
  pvStack_1c = ExceptionList;
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_14 = 1;
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01ee1c34);
  uStack_60 = 0;
  ExceptionList = &pvStack_1c;
  if (param_11 != 0) {
    uStack_60 = param_11;
    if ((param_11 & 1) == 0) {
      puStack_68 = &uStack_58;
      uStack_64 = 0;
      puStack_6c = &param_13;
      uStack_70 = 0x924555;
      ExceptionList = &pvStack_1c;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_58 = param_13;
      uStack_54 = param_14;
      uStack_50 = param_15;
      uStack_4c = param_16;
      uStack_48 = param_17;
      ExceptionList = &pvStack_1c;
    }
  }
  uStack_14._0_1_ = 2;
  uStack_84 = 0;
  uStack_b0 = uStack_24;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_c8,0);
    }
    else {
      uStack_c8 = param_6;
      uStack_c4 = param_7;
      uStack_c0 = param_8;
      uStack_bc = param_9;
      uStack_b8 = param_10;
    }
  }
  FUN_008bfbf0(auStack_ac,FUN_008e61f0);
  uStack_b0 = 0x9245c4;
  FUN_008dc4b0();
  uStack_14._0_1_ = 1;
  uStack_84 = 0x9245ce;
  (*pcVar1)();
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_8c = &param_6;
    uStack_84 = 2;
    uStack_90 = 0x9245ef;
    puStack_88 = puStack_8c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_8c = &param_13;
    uStack_84 = 2;
    uStack_90 = 0x92461d;
    puStack_88 = puStack_8c;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 16455 ; VA 0x00924640 ; FUN_00924640 */

void __thiscall
FUN_00924640(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  code *pcVar1;
  undefined8 uVar2;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined4 uStack_b8;
  undefined auStack_b4 [20];
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  undefined4 *puStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_24;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_18 = &LAB_017c865e;
  pvStack_1c = ExceptionList;
  uStack_14 = 1;
  uStack_50 = CONCAT44(param_1 + 0x40,param_3);
  uStack_54 = 0x924686;
  ExceptionList = &pvStack_1c;
  uVar2 = FUN_009269c0();
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01ee1c34);
  uStack_68 = 0;
  if (param_11 != 0) {
    uStack_68 = param_11;
    if ((param_11 & 1) == 0) {
      puStack_70 = &uStack_60;
      uStack_6c = 0;
      puStack_74 = &param_13;
      uStack_78 = 0x9246e8;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_60 = param_13;
      uStack_5c = param_14;
      uStack_58 = param_15;
      uStack_54 = param_16;
      uStack_50 = param_17;
    }
  }
  uStack_14._0_1_ = 2;
  uStack_90._4_4_ = 0;
  uStack_b8 = uStack_24;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_d0,0);
    }
    else {
      uStack_d0 = param_6;
      uStack_cc = param_7;
      uStack_c8 = param_8;
      uStack_c4 = param_9;
      uStack_c0 = param_10;
    }
  }
  FUN_008bfbf0(auStack_b4,FUN_008e61f0);
  uStack_b8 = 0x924757;
  FUN_008dc4b0();
  uStack_14._0_1_ = 1;
  uStack_94 = 0x924767;
  uStack_90 = uVar2;
  (*pcVar1)();
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_9c = &param_6;
    uStack_94 = 2;
    uStack_a0 = 0x924788;
    puStack_98 = puStack_9c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_9c = &param_13;
    uStack_94 = 2;
    uStack_a0 = 0x9247b6;
    puStack_98 = puStack_9c;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 16456 ; VA 0x009247d0 ; FUN_009247d0 */

undefined4 __thiscall FUN_009247d0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_3c [4];
  int *piStack_38;
  code *pcStack_30;
  undefined4 *puStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017c8684;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  puStack_24 = (undefined4 *)
               FUN_009d1340(auStack_3c,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcStack_30 = *(code **)(param_1 + 0x38);
  iStack_14 = 0;
  if (puStack_24[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_24[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = (*pcStack_30)(*puStack_24,puStack_24[1]);
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee225c) {
    FUN_016f3809(&DAT_01ee225c);
    if (DAT_01ee225c == -1) {
      iStack_14._0_1_ = 1;
      FUN_00becc20();
      FUN_016f3654(&LAB_01884a60);
      iStack_14 = (uint)iStack_14._1_3_ << 8;
      FUN_016f37bf(&DAT_01ee225c);
    }
  }
  iVar2 = FUN_009cb050(uVar3);
  if (iVar2 == 0) {
    FUN_01256980(param_3);
  }
  else {
    FUN_00880a00(param_3,iVar2);
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[1] + -1;
    piStack_38[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      piVar1 = piStack_38 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 1;
}



/* FUNCTION 16457 ; VA 0x00924930 ; FUN_00924930 */

void __thiscall FUN_00924930(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined8 *puVar2;
  float10 fVar3;
  undefined auStack_24 [12];
  code *pcStack_18;
  float fStack_14;
  
  iVar1 = FUN_01256300(param_3);
  puVar2 = (undefined8 *)FUN_009d16a0(auStack_24,param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  pcStack_18 = *(code **)(param_1 + 0x38);
  fVar3 = (float10)(*pcStack_18)(*puVar2,*(undefined4 *)(puVar2 + 1));
  fStack_14 = (float)fVar3;
  FUN_009d5680(param_3,fStack_14);
  return;
}



/* FUNCTION 16458 ; VA 0x009249c0 ; FUN_009249c0 */

undefined4 __thiscall FUN_009249c0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  float10 fVar6;
  undefined4 uVar7;
  int iStack_48;
  uint uStack_34;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_01792448;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  iVar4 = param_1 + 0x40;
  iVar2 = iVar2 - param_4;
  uVar7 = 1;
  uVar3 = param_3;
  FUN_009d09d0();
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_14 = 0;
  FUN_0054ef60();
  fVar6 = (float10)(*pcVar1)(uVar3,param_4,uVar7,iVar2,iVar4);
  uVar3 = FUN_009d56b0(param_3,(double)fVar6);
  if (0xf < uStack_34) {
    uVar5 = uStack_34 + 1;
    iVar4 = iStack_48;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iStack_48 + -4);
      uVar5 = uStack_34 + 0x24;
      if (0x1f < (iStack_48 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_1c;
  return uVar3;
}



/* FUNCTION 16459 ; VA 0x00924aa0 ; FUN_00924aa0 */

undefined4 FUN_00924aa0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uStack_80;
  int iStack_7c;
  undefined4 uStack_78;
  int iStack_74;
  int iStack_70;
  undefined4 uStack_6c;
  int aiStack_60 [5];
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined *puStack_30;
  undefined4 uStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017c86a8;
  pvStack_1c = ExceptionList;
  uStack_6c = param_2;
  iStack_70 = 0x924adc;
  ExceptionList = &pvStack_1c;
  iVar1 = FUN_01256300();
  iStack_70 = (int)pcStack_28 + 0x44;
  uStack_78 = 2;
  iStack_7c = param_3;
  uStack_80 = param_2;
  iStack_74 = iVar1 - param_3;
  uStack_2c = FUN_009d09d0(aiStack_60);
  uStack_14 = 0;
  uVar2 = FUN_009d09d0(auStack_48,param_2,param_3,1,iVar1 - param_3,(int)pcStack_28 + 0x40);
  puStack_30 = (undefined *)&uStack_80;
  uStack_14._0_1_ = 1;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  FUN_0054ef60(uStack_2c);
  uStack_14._0_1_ = 2;
  FUN_0054ef60(uVar2);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  (*pcStack_28)();
  if (0xf < uStack_34) {
    uVar3 = uStack_34 + 1;
    uVar4 = auStack_48[0];
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(auStack_48[0] - 4);
      uVar3 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (0xf < uStack_4c) {
    uVar4 = uStack_4c + 1;
    iVar1 = aiStack_60[0];
    if (0xfff < uVar4) {
      iVar1 = *(int *)(aiStack_60[0] + -4);
      uVar4 = uStack_4c + 0x24;
      if (0x1f < (aiStack_60[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar4);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 16460 ; VA 0x00924bf0 ; FUN_00924bf0 */

undefined4 FUN_00924bf0(undefined4 param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  float10 fVar5;
  int aiStack_34 [5];
  uint uStack_20;
  double dStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300();
  fVar5 = (float10)FUN_009d0880(param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x44);
  dStack_1c = (double)fVar5;
  uVar3 = FUN_009d09d0(aiStack_34,param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x40);
  uStack_8 = 0;
  pcVar1 = *(code **)(iStack_14 + 0x38);
  FUN_0054ef60(uVar3);
  (*pcVar1)();
  if (0xf < uStack_20) {
    uVar4 = uStack_20 + 1;
    iVar2 = aiStack_34[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      uVar4 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 16461 ; VA 0x00924cd0 ; FUN_00924cd0 */

undefined4 FUN_00924cd0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c86d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300();
  iVar4 = FUN_009d1340(auStack_1c,param_2,param_3,2,iVar3 - param_3);
  uStack_8 = 0;
  uVar5 = FUN_009d09d0(auStack_34,param_2,param_3,1,iVar3 - param_3,iStack_14 + 0x40);
  pcVar2 = *(code **)(iStack_14 + 0x38);
  if (*(int *)(iVar4 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar4 + 4) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  FUN_0054ef60(uVar5);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  (*pcVar2)();
  if (0xf < uStack_20) {
    uVar7 = uStack_20 + 1;
    uVar6 = auStack_34[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_34[0] - 4);
      uVar7 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 16462 ; VA 0x00924e20 ; FUN_00924e20 */

undefined4 FUN_00924e20(undefined4 param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  FUN_009d1aa0(param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x44);
  uVar3 = FUN_009d09d0(aiStack_2c,param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x40);
  uStack_8 = 0;
  pcVar1 = *(code **)(iStack_14 + 0x38);
  FUN_0054ef60(uVar3);
  (*pcVar1)();
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 16463 ; VA 0x00924ef0 ; FUN_00924ef0 */

undefined4 __thiscall FUN_00924ef0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined auStack_34 [4];
  int *piStack_30;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017c86f8;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  puVar3 = (undefined4 *)FUN_009d11e0(auStack_34,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcStack_28 = *(code **)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcStack_28)(*puVar3,puVar3[1]);
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[1] + -1;
    piStack_30[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piStack_30 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 16464 ; VA 0x00924fd0 ; FUN_00924fd0 */

undefined4 __thiscall FUN_00924fd0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined auStack_34 [4];
  int *piStack_30;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bbe88;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  puVar3 = (undefined4 *)FUN_009d1340(auStack_34,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcStack_28 = *(code **)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcStack_28)(*puVar3,puVar3[1]);
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[1] + -1;
    piStack_30[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piStack_30 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 16465 ; VA 0x009250b0 ; FUN_009250b0 */

undefined4 FUN_009250b0(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined uVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined auStack_14 [12];
  int iStack_8;
  
  iVar2 = FUN_01256300(param_2);
  uVar1 = FUN_009d1aa0(param_2,param_3,2,iVar2 - param_3,iStack_8 + 0x44);
  puVar3 = (undefined8 *)FUN_009d16a0(auStack_14,param_2,param_3,1,iVar2 - param_3,iStack_8 + 0x40);
  (**(code **)(iStack_8 + 0x38))(*puVar3,*(undefined4 *)(puVar3 + 1),uVar1);
  return 0;
}



/* FUNCTION 16466 ; VA 0x00925130 ; FUN_00925130 */

undefined4 FUN_00925130(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c871b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  iVar1 = param_3;
  iVar3 = iVar3 - param_3;
  if (0 < iVar3) {
    uVar4 = FUN_005f32d0();
    cVar2 = FUN_009d1e20(uVar4,param_2,iVar1 + 1,&param_3);
    iVar6 = param_3;
    if (cVar2 != '\0') goto LAB_00925235;
  }
  if (0 < iVar3) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    uStack_8 = 0;
    cVar2 = FUN_009d1bf0(param_2,iVar1 + 1,&uStack_f0,1);
    if (cVar2 != '\0') {
      piVar5 = (int *)FUN_00915df0();
      iVar6 = *piVar5;
      uStack_8 = 1;
      if (iStack_ec != 0) {
        (**(code **)(iStack_ec + 8))(auStack_e8);
      }
      uStack_8 = 0xffffffff;
      goto LAB_00925235;
    }
    uStack_8 = 2;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
    uStack_8 = 0xffffffff;
  }
  if (*(int **)(iStack_14 + 0x40) == (int *)0x0) {
    FUN_016756b0(auStack_20,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  iVar6 = **(int **)(iStack_14 + 0x40);
LAB_00925235:
  (**(code **)(iStack_14 + 0x38))(iVar6);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 16467 ; VA 0x00925280 ; FUN_00925280 */

undefined4 __thiscall FUN_00925280(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined uVar1;
  int iVar2;
  undefined8 uVar3;
  
  iVar2 = FUN_01256300(param_3);
  uVar1 = FUN_009d1aa0(param_3,param_4,2,iVar2 - param_4,param_1 + 0x44);
  uVar3 = FUN_009d1940(param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  (**(code **)(param_1 + 0x38))(uVar3,uVar1);
  return 0;
}



/* FUNCTION 16468 ; VA 0x009252f0 ; FUN_009252f0 */

void __thiscall FUN_009252f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined uVar1;
  
  uVar1 = (**(code **)(param_1 + 0x38))();
  FUN_009d5ac0(param_3,uVar1);
  return;
}



/* FUNCTION 16469 ; VA 0x00925320 ; FUN_00925320 */

undefined4 __thiscall FUN_00925320(int param_1,int *param_2,undefined4 *param_3,char param_4)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  piVar2 = param_2;
  iVar4 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar3 = param_2[1];
  if (((int)uVar3 < 1) && ((int)uVar3 < 0)) {
    uVar3 = ~uVar3;
  }
  FUN_00606ff0(&param_2,(uVar3 >> 2) + uVar3 * 0x40 + *param_2 ^ uVar3,param_2,
               -(uint)(iVar4 != 0) & iVar4 + 1U);
  piVar1 = param_2;
  if (param_2 == (int *)0x0) {
    return 0;
  }
  if (param_4 != '\0') {
    FUN_00929190(&param_4,piVar2);
  }
  if (param_3 != (undefined4 *)0x0) {
    iVar4 = piVar1[4];
    iVar5 = *(int *)(iVar4 + 0x18);
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = *(int *)(iVar4 + 0x18);
    }
    *param_3 = *(undefined4 *)(iVar4 + 0x14);
    piVar2 = (int *)param_3[1];
    param_3[1] = iVar5;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  return 1;
}



/* FUNCTION 16470 ; VA 0x009253f0 ; FUN_009253f0 */

/* WARNING: Removing unreachable block (ram,0x00925549) */
/* WARNING: Removing unreachable block (ram,0x00925555) */
/* WARNING: Removing unreachable block (ram,0x00925563) */

undefined4 FUN_009253f0(int *param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  int iStack_104;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c8769;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uStack_3c = 0;
  uStack_14 = param_2;
  uStack_2c = param_2;
  iStack_20 = param_3;
  iStack_28 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  FUN_00925d30(param_1,param_2,param_3);
  uStack_1c = uStack_14;
  iStack_18 = param_3;
  uStack_2c = 0;
  iStack_28 = 0;
  uStack_8 = 2;
  pcVar1 = *(code **)(*param_1 + 8);
  uStack_110 = FUN_0088cdc0();
  uStack_108 = uStack_14;
  uStack_10c = 0;
  iStack_104 = iStack_20;
  uStack_1c = 0;
  iStack_18 = 0;
  uStack_10c = FUN_006309e0();
  uStack_8 = 3;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  FUN_00687980(&uStack_110,&uStack_40,param_1);
  uStack_8 = 4;
  (*pcVar1)(uStack_24,&uStack_38,&uStack_40);
  uStack_8 = 5;
  FUN_00577b20();
  _uStack_8 = CONCAT31(uStack_7,2);
  uVar2 = FUN_016f32d1(&uStack_110,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 16471 ; VA 0x00925580 ; FUN_00925580 */

/* WARNING: Removing unreachable block (ram,0x00925772) */
/* WARNING: Removing unreachable block (ram,0x0092577b) */
/* WARNING: Removing unreachable block (ram,0x0092578a) */
/* WARNING: Removing unreachable block (ram,0x00925798) */
/* WARNING: Removing unreachable block (ram,0x009257a1) */
/* WARNING: Removing unreachable block (ram,0x009257af) */

undefined4
FUN_00925580(int *param_1,undefined4 param_2,undefined4 param_3,int param_4,undefined4 param_5,
            int param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 uStack_2ac;
  undefined4 uStack_2a8;
  undefined4 uStack_2a4;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  int iStack_1d0;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  int iStack_100;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c87d7;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_6 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_6 + 4) = *(int *)(param_6 + 4) + 1;
    UNLOCK();
  }
  if (param_4 != 0) {
    LOCK();
    *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 1;
    UNLOCK();
  }
  FUN_00925dd0(param_1,param_2,param_3,param_4,param_5,param_6);
  uStack_18 = param_5;
  uStack_30 = param_5;
  iStack_1c = param_6;
  iStack_2c = param_6;
  uStack_28 = param_3;
  iStack_24 = param_4;
  uStack_8._0_1_ = 3;
  pcStack_14 = *(code **)(*param_1 + 8);
  uStack_2ac = thunk_FUN_00adb7d0();
  uStack_2a8 = 0;
  uStack_2a4 = param_2;
  uStack_2a8 = FUN_00936290();
  uStack_8._0_1_ = 4;
  uStack_1dc = FUN_008881d0();
  uStack_1d8 = 0;
  uStack_1d4 = param_3;
  iStack_1d0 = param_4;
  uStack_28 = 0;
  iStack_24 = 0;
  uStack_1d8 = FUN_0058c000();
  uStack_8._0_1_ = 5;
  uStack_10c = FUN_0088cdc0();
  uStack_104 = uStack_18;
  uStack_108 = 0;
  iStack_100 = iStack_1c;
  uStack_30 = 0;
  iStack_2c = 0;
  uStack_108 = FUN_006309e0();
  uStack_8._0_1_ = 6;
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  FUN_00687980(&uStack_2ac,&uStack_3c,param_1);
  uStack_8._0_1_ = 7;
  (*pcStack_14)(uStack_20,&uStack_3c,param_7);
  uStack_8._0_1_ = 8;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uVar1 = FUN_016f32d1(&uStack_2ac,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 16472 ; VA 0x009257d0 ; FUN_009257d0 */

/* WARNING: Removing unreachable block (ram,0x009259ab) */
/* WARNING: Removing unreachable block (ram,0x009259b9) */
/* WARNING: Removing unreachable block (ram,0x009259e5) */
/* WARNING: Removing unreachable block (ram,0x009259c9) */

void FUN_009257d0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,uint param_5
                 ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 param_10)

{
  code *pcVar1;
  undefined4 in_stack_fffffd00;
  undefined4 in_stack_fffffd04;
  undefined4 in_stack_fffffd08;
  undefined4 in_stack_fffffd0c;
  undefined4 in_stack_fffffd10;
  undefined4 in_stack_fffffd14;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  uint uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined8 uStack_128;
  uint uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  uint uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c883f;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  uStack_48 = param_5;
  uStack_44 = param_6;
  uStack_40 = param_7;
  uStack_3c = param_8;
  uStack_2c = 0;
  uStack_38 = CONCAT44(param_10,param_9);
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&uStack_48);
  FUN_00925ec0(param_1,param_2,param_3,param_4,in_stack_fffffd00,in_stack_fffffd04,in_stack_fffffd08
               ,in_stack_fffffd0c,in_stack_fffffd10,in_stack_fffffd14);
  uStack_70 = uStack_48;
  uStack_48 = uStack_48 & 0xffffff00;
  uStack_6c = uStack_44;
  uStack_68 = uStack_40;
  uStack_64 = uStack_3c;
  uStack_60 = uStack_70;
  uStack_5c = uStack_44;
  uStack_58 = uStack_40;
  uStack_54 = uStack_3c;
  uStack_28 = uStack_38;
  uStack_50 = uStack_38;
  uStack_38 = 0xf00000000;
  uStack_8 = 2;
  pcVar1 = *(code **)(*param_1 + 8);
  uStack_2e0 = thunk_FUN_00adb7d0();
  uStack_2dc = 0;
  uStack_2d8 = param_2;
  uStack_2dc = FUN_00936290();
  uStack_8 = 3;
  uStack_210 = FUN_0088da50();
  uStack_20c = 0;
  uStack_208 = param_3;
  uStack_204 = param_4;
  uStack_20c = FUN_005c9e80();
  uStack_8 = 4;
  uStack_140 = FUN_0088cb40();
  uStack_13c = 0;
  uStack_138 = uStack_70;
  uStack_134 = uStack_6c;
  uStack_130 = uStack_68;
  uStack_12c = uStack_64;
  uStack_128 = uStack_28;
  uStack_50 = 0xf00000000;
  uStack_60 = uStack_60 & 0xffffff00;
  uStack_13c = FUN_005c9d30();
  uStack_8 = 5;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_2e0,&uStack_70,param_1);
  uStack_8 = 6;
  (*pcVar1)(uStack_14,&uStack_20,&uStack_30);
  uStack_8 = 7;
  FUN_00577b20();
  _uStack_8 = CONCAT31(uStack_7,2);
  FUN_016f32d1(&uStack_2e0,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16473 ; VA 0x009259f0 ; FUN_009259f0 */

void __fastcall FUN_009259f0(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8858;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x68);
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x68);
  }
  uStack_8 = 0;
  FUN_009253f0(param_1,*(undefined4 *)(param_1 + 100),iVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16474 ; VA 0x00925a60 ; FUN_00925a60 */

void __fastcall FUN_00925a60(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8858;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x68);
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x68);
  }
  uStack_8 = 0;
  FUN_009253f0(param_1,*(undefined4 *)(param_1 + 100),iVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16475 ; VA 0x00925ad0 ; FUN_00925ad0 */

/* WARNING: Removing unreachable block (ram,0x00925c2c) */
/* WARNING: Removing unreachable block (ram,0x00925bea) */
/* WARNING: Removing unreachable block (ram,0x00925ba4) */
/* WARNING: Removing unreachable block (ram,0x00925bb2) */
/* WARNING: Removing unreachable block (ram,0x00925c64) */
/* WARNING: Removing unreachable block (ram,0x00925bc6) */
/* WARNING: Removing unreachable block (ram,0x00925bf8) */
/* WARNING: Removing unreachable block (ram,0x00925c69) */
/* WARNING: Removing unreachable block (ram,0x00925c08) */
/* WARNING: Removing unreachable block (ram,0x00925c3a) */
/* WARNING: Removing unreachable block (ram,0x00925c6e) */
/* WARNING: Removing unreachable block (ram,0x00925c4a) */

void FUN_00925ad0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined4 param_18,undefined4 param_19)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8888;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0091b8e0(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6),param_8,param_9,param_10,
               param_11,CONCAT44(param_13,param_12),param_14,param_15,param_16,param_17,
               CONCAT44(param_19,param_18));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16476 ; VA 0x00925c80 ; FUN_00925c80 */

/* WARNING: Removing unreachable block (ram,0x00925ce8) */
/* WARNING: Removing unreachable block (ram,0x00925cf6) */
/* WARNING: Removing unreachable block (ram,0x00925d20) */
/* WARNING: Removing unreachable block (ram,0x00925d06) */

void FUN_00925c80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006ecaa0(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16477 ; VA 0x00925d30 ; FUN_00925d30 */

/* WARNING: Removing unreachable block (ram,0x00925d8e) */
/* WARNING: Removing unreachable block (ram,0x00925d9a) */
/* WARNING: Removing unreachable block (ram,0x00925da8) */

undefined4 FUN_00925d30(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0089be10(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 16478 ; VA 0x00925dd0 ; FUN_00925dd0 */

/* WARNING: Removing unreachable block (ram,0x00925e61) */
/* WARNING: Removing unreachable block (ram,0x00925e6a) */
/* WARNING: Removing unreachable block (ram,0x00925e79) */
/* WARNING: Removing unreachable block (ram,0x00925e87) */
/* WARNING: Removing unreachable block (ram,0x00925e90) */
/* WARNING: Removing unreachable block (ram,0x00925e9e) */

undefined4
FUN_00925dd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8560;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0091be00(param_2,param_3,param_4,param_5,param_6);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 16479 ; VA 0x00925ec0 ; FUN_00925ec0 */

/* WARNING: Removing unreachable block (ram,0x00925f31) */
/* WARNING: Removing unreachable block (ram,0x00925f3f) */
/* WARNING: Removing unreachable block (ram,0x00925f69) */
/* WARNING: Removing unreachable block (ram,0x00925f4f) */

void FUN_00925ec0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8538;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0091bf30(param_2,param_3,param_4,param_5,param_6,param_7,param_8,CONCAT44(param_10,param_9));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16480 ; VA 0x00925f70 ; FUN_00925f70 */

void FUN_00925f70(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088c960();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0091b810(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16481 ; VA 0x00925fc0 ; FUN_00925fc0 */

void FUN_00925fc0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088ca00();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_008ec650(*(undefined8 *)piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 16482 ; VA 0x00926010 ; FUN_00926010 */

void FUN_00926010(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c88b0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(*param_2 + 0x1a0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cb40();
  if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  iVar1 = *param_2;
  uStack_8 = 0;
  iVar2 = *(int *)(iVar1 + 0xd0);
  iVar3 = FUN_0088cb40();
  if (iVar2 == iVar3) {
    iVar2 = iVar1 + 0xd8;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      iVar2 = 0;
    }
    FUN_0054ef60(iVar2);
    param_2 = (int *)*param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar1 = *param_2;
    iVar2 = FUN_0088cb40();
    if (iVar1 == iVar2) {
      piVar4 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar4 = (int *)0x0;
      }
      FUN_0054ef60(piVar4);
      uStack_8 = 0xffffffff;
      FUN_00925ad0(param_1);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 16483 ; VA 0x00926110 ; FUN_00926110 */

void FUN_00926110(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    FUN_00925c80(param_1);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16484 ; VA 0x00926160 ; FUN_00926160 */

void FUN_00926160(undefined4 param_1,undefined4 param_2)

{
  FUN_009176d0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 16485 ; VA 0x00926180 ; FUN_00926180 */

/* WARNING: Removing unreachable block (ram,0x0092627b) */
/* WARNING: Removing unreachable block (ram,0x00926289) */
/* WARNING: Removing unreachable block (ram,0x009262cc) */
/* WARNING: Removing unreachable block (ram,0x00926299) */

void FUN_00926180(undefined4 param_1,int *param_2)

{
  undefined8 uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined8 *puVar5;
  int iVar6;
  int *piVar7;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a8af8;
  pvStack_1c = ExceptionList;
  iVar2 = *param_2;
  iVar6 = *(int *)(iVar2 + 0xd0);
  ExceptionList = &pvStack_1c;
  iVar4 = FUN_0088d870();
  if (iVar6 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar5 = (undefined8 *)(iVar2 + 0xd8);
  if (*(int *)(iVar2 + 0xd4) == 0) {
    puVar5 = (undefined8 *)0x0;
  }
  uVar1 = *puVar5;
  uVar3 = *(undefined4 *)(puVar5 + 1);
  param_2 = (int *)*param_2;
  iVar2 = *param_2;
  iVar6 = FUN_0088cb40();
  if (iVar2 != iVar6) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar7 = param_2 + 2;
  if (param_2[1] == 0) {
    piVar7 = (int *)0x0;
  }
  FUN_0054ef60(piVar7);
  uStack_14 = 0;
  FUN_0091bae0(uStack_50,uStack_4c,uStack_48,uStack_44,CONCAT44(uStack_3c,uStack_40),uVar1,uVar3);
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 16486 ; VA 0x009262e0 ; FUN_009262e0 */

void FUN_009262e0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795998;
  pvStack_10 = ExceptionList;
  param_2 = (int *)*param_2;
  iVar3 = *param_2;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008882f0();
  if (iVar3 == iVar1) {
    piVar2 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar2 = (int *)0x0;
    }
    iVar3 = piVar2[1];
    if (iVar3 != 0) {
      LOCK();
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      UNLOCK();
      iVar3 = piVar2[1];
    }
    uStack_8 = 0;
    FUN_0091bc20(*piVar2,iVar3);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16487 ; VA 0x00926380 ; FUN_00926380 */

void FUN_00926380(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  param_2 = (int *)*param_2;
  iVar2 = *param_2;
  iVar3 = FUN_0088cdc0();
  if (iVar2 == iVar3) {
    piVar4 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00925d30(param_1,*piVar4,piVar4[1]);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16488 ; VA 0x009263e0 ; FUN_009263e0 */

void FUN_009263e0(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  iVar6 = *param_2;
  iVar4 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = thunk_FUN_00935e70();
  if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar3 = (undefined4 *)(iVar6 + 0xd8);
  param_2 = (int *)*param_2;
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  iVar6 = *param_2;
  uVar1 = *puVar3;
  iVar4 = FUN_0088cdc0();
  if (iVar6 == iVar4) {
    piVar5 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    iVar6 = piVar5[1];
    if (iVar6 != 0) {
      LOCK();
      *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
      UNLOCK();
      iVar6 = piVar5[1];
    }
    uStack_8 = 0;
    FUN_0089bf10(*piVar5,iVar6,uVar1);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16489 ; VA 0x009264b0 ; FUN_009264b0 */

void FUN_009264b0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c88c8;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_2;
  iVar2 = *piVar1;
  ExceptionList = &pvStack_10;
  iVar4 = thunk_FUN_00adb7d0();
  if (iVar2 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  piVar5 = piVar1 + 2;
  iVar2 = *param_2;
  if (piVar1[1] == 0) {
    piVar5 = (int *)0x0;
  }
  iVar4 = *(int *)(iVar2 + 0x1a0);
  iVar3 = *piVar5;
  iVar6 = FUN_0088cdc0();
  if (iVar4 == iVar6) {
    iVar4 = iVar2 + 0x1a8;
    if (*(int *)(iVar2 + 0x1a4) == 0) {
      iVar4 = 0;
    }
    if (*(int *)(iVar4 + 4) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(iVar4 + 4) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    iVar2 = *param_2;
    uStack_8 = 0;
    iVar4 = *(int *)(iVar2 + 0xd0);
    iVar6 = FUN_008881d0();
    if (iVar4 == iVar6) {
      puVar7 = (undefined4 *)(iVar2 + 0xd8);
      if (*(int *)(iVar2 + 0xd4) == 0) {
        puVar7 = (undefined4 *)0x0;
      }
      if (puVar7[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar7[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_8 = 0xffffffff;
      FUN_00925dd0(param_1,iVar3,*puVar7,puVar7[1]);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 16490 ; VA 0x009265d0 ; FUN_009265d0 */

void FUN_009265d0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  
  iVar1 = *param_2;
  iVar7 = *(int *)(iVar1 + 0xd0);
  iVar5 = FUN_0088da50();
  if (iVar7 == iVar5) {
    puVar6 = (undefined4 *)(iVar1 + 0xd8);
    piVar2 = (int *)*param_2;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    iVar1 = *piVar2;
    uVar3 = *puVar6;
    uVar4 = puVar6[1];
    iVar7 = thunk_FUN_00adb7d0();
    if (iVar1 == iVar7) {
      piVar8 = piVar2 + 2;
      iVar1 = *param_2;
      if (piVar2[1] == 0) {
        piVar8 = (int *)0x0;
      }
      iVar7 = *(int *)(iVar1 + 0x1a0);
      iVar5 = *piVar8;
      iVar9 = FUN_0088cb40();
      if (iVar7 == iVar9) {
        iVar7 = iVar1 + 0x1a8;
        if (*(int *)(iVar1 + 0x1a4) == 0) {
          iVar7 = 0;
        }
        FUN_0054ef60(iVar7);
        FUN_00925ec0(param_1,iVar5,uVar3,uVar4);
        return;
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16491 ; VA 0x00926690 ; FUN_00926690 */

void FUN_00926690(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  
  iVar1 = *param_2;
  iVar5 = *(int *)(iVar1 + 0xd0);
  iVar3 = thunk_FUN_00bfa7a0();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar1 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar1 = *param_2;
    uVar2 = *puVar4;
    iVar5 = FUN_0088da50();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      FUN_0091c070(*piVar6,piVar6[1],uVar2);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16492 ; VA 0x00926720 ; FUN_00926720 */

undefined4 * FUN_00926720(undefined4 *param_1,int *param_2,int *param_3)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c88f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = (**(code **)*param_2)();
  if (iVar2 != 0) {
    uStack_18 = 0;
    uStack_14 = 0;
    uStack_8 = 0;
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8._0_1_ = 1;
    cVar1 = (**(code **)(*param_2 + 4))(1,&uStack_ec);
    if (cVar1 != '\0') {
      puVar3 = (undefined4 *)FUN_0088a3d0();
      iVar2 = puVar3[1];
      *param_1 = 0;
      param_1[1] = 0;
      if (iVar2 != 0) {
        LOCK();
        *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
        UNLOCK();
        iVar2 = puVar3[1];
      }
      *param_1 = *puVar3;
      param_1[1] = iVar2;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
    FUN_00550b30();
  }
  puVar3 = (undefined4 *)*param_3;
  if (puVar3 != (undefined4 *)0x0) {
    iVar2 = puVar3[1];
    *param_1 = 0;
    param_1[1] = 0;
    if (iVar2 != 0) {
      LOCK();
      *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
      UNLOCK();
      iVar2 = puVar3[1];
    }
    *param_1 = *puVar3;
    param_1[1] = iVar2;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 16493 ; VA 0x00926890 ; FUN_00926890 */

undefined8 * FUN_00926890(undefined8 *param_1,int *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined8 *puVar4;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)*param_2)();
  if (iVar3 != 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar2 = (**(code **)(*param_2 + 4))(1,&uStack_ec);
    if (cVar2 != '\0') {
      puVar4 = (undefined8 *)FUN_0088b880();
      uVar1 = *(undefined4 *)(puVar4 + 1);
      *param_1 = *puVar4;
      *(undefined4 *)(param_1 + 1) = uVar1;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  puVar4 = (undefined8 *)*param_3;
  if (puVar4 != (undefined8 *)0x0) {
    uVar1 = *(undefined4 *)(puVar4 + 1);
    *param_1 = *puVar4;
    *(undefined4 *)(param_1 + 1) = uVar1;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 16494 ; VA 0x009269c0 ; FUN_009269c0 */

undefined8 FUN_009269c0(int *param_1,int *param_2)

{
  undefined8 uVar1;
  char cVar2;
  int iVar3;
  undefined8 *puVar4;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)*param_1)();
  if (iVar3 != 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar2 = (**(code **)(*param_1 + 4))(1,&uStack_ec);
    if (cVar2 != '\0') {
      puVar4 = (undefined8 *)FUN_0088baa0();
      uVar1 = *puVar4;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  if ((undefined8 *)*param_2 != (undefined8 *)0x0) {
    ExceptionList = pvStack_10;
    return *(undefined8 *)*param_2;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 16495 ; VA 0x00926ad0 ; FUN_00926ad0 */

undefined4 __thiscall FUN_00926ad0(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x54);
  return param_2;
}



/* FUNCTION 16496 ; VA 0x00926b10 ; FUN_00926b10 */

bool __fastcall FUN_00926b10(int param_1)

{
  undefined auStack_10 [12];
  
  if (DAT_01d641dc != '\0') {
    return *(char *)(param_1 + 0xaf) == '\0';
  }
  FUN_00550130("IsUserAvailableForFilteringExperiment is not available");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 16497 ; VA 0x00926ba0 ; FUN_00926ba0 */

undefined4 __thiscall FUN_00926ba0(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x168);
  return param_2;
}



/* FUNCTION 16498 ; VA 0x00926bd0 ; FUN_00926bd0 */

undefined4 __fastcall FUN_00926bd0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x490);
}



/* FUNCTION 16499 ; VA 0x00926be0 ; FUN_00926be0 */

undefined4 __fastcall FUN_00926be0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xf4);
  if ((*(int *)(param_1 + 0xf0) != *(uint *)(param_1 + 0xf8) + 0xaaf55c4e) ||
     (iVar1 != *(int *)(param_1 + 0xfc) - (uint)(*(uint *)(param_1 + 0xf8) < 0x550aa3b2))) {
    FUN_01675310("SecurityViolation",&DAT_018bc9b8);
    iVar1 = *(int *)(param_1 + 0xf4);
  }
  if ((iVar1 < 1) && (iVar1 < 0)) {
    return 0;
  }
  return 1;
}


