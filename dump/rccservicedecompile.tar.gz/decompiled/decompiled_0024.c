/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 6000 ; VA 0x005f3f62 ; Catch_All@005f3f62 */

void Catch_All_005f3f62(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6001 ; VA 0x005f3f80 ; FUN_005f3f80 */

int __thiscall FUN_005f3f80(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c3a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::BadgeService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6002 ; VA 0x005f4052 ; Catch_All@005f4052 */

void Catch_All_005f4052(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6003 ; VA 0x005f4070 ; FUN_005f4070 */

int __thiscall FUN_005f4070(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c3b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ChangeHistoryService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6004 ; VA 0x005f4142 ; Catch_All@005f4142 */

void Catch_All_005f4142(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6005 ; VA 0x005f4160 ; FUN_005f4160 */

int __thiscall FUN_005f4160(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c3c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::LocalizationService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6006 ; VA 0x005f4232 ; Catch_All@005f4232 */

void Catch_All_005f4232(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6007 ; VA 0x005f4250 ; FUN_005f4250 */

int __thiscall FUN_005f4250(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c3d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PackageService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6008 ; VA 0x005f4322 ; Catch_All@005f4322 */

void Catch_All_005f4322(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6009 ; VA 0x005f4340 ; FUN_005f4340 */

int __thiscall FUN_005f4340(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c3e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::RunService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6010 ; VA 0x005f4412 ; Catch_All@005f4412 */

void Catch_All_005f4412(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6011 ; VA 0x005f4460 ; FUN_005f4460 */

undefined4 * __thiscall FUN_005f4460(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar2 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 1;
    puVar2[2] = FUN_005f6c50;
    puVar2[3] = _guard_check_icall;
    puVar2[4] = 0;
    puVar2[5] = param_1;
    puVar2[6] = *param_3;
  }
  FUN_016797d0(puVar2);
  *param_2 = puVar2;
  if (puVar2 != (undefined4 *)0x0) {
    LOCK();
    puVar2[1] = puVar2[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6012 ; VA 0x005f4520 ; FUN_005f4520 */

undefined4 * FUN_005f4520(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c443;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a1a060();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00a1a390();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005f3e90(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6013 ; VA 0x005f45e0 ; FUN_005f45e0 */

int FUN_005f45e0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c458;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea93dc,&LAB_005e5a90);
  uVar2 = FUN_005e5ab0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00a1a140();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005f4520(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea93dc,&LAB_005e5a90);
      uVar2 = FUN_005e5ab0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 6014 ; VA 0x005f4770 ; FUN_005f4770 */

undefined4 * FUN_005f4770(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c4a3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a56630();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xf0);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00a58ac0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005f3f80(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6015 ; VA 0x005f4830 ; FUN_005f4830 */

int FUN_005f4830(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c4b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaad64,&LAB_005f4430);
  uVar2 = FUN_005f5510();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00a56730();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005f4770(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaad64,&LAB_005f4430);
      uVar2 = FUN_005f5510();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 6016 ; VA 0x005f49c0 ; FUN_005f49c0 */

undefined4 * FUN_005f49c0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c503;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a5e070();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xb4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00a5fb90();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005f4070(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6017 ; VA 0x005f4a80 ; FUN_005f4a80 */

int FUN_005f4a80(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaad54,&LAB_005f4440);
  uVar2 = FUN_005f5590();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00a5e170();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005f49c0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaad54,&LAB_005f4440);
      uVar2 = FUN_005f5590();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 6018 ; VA 0x005f4c10 ; FUN_005f4c10 */

undefined4 * FUN_005f4c10(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c563;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a36d80();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x2f8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00a3b3c0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005f4160(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6019 ; VA 0x005f4cd0 ; FUN_005f4cd0 */

int FUN_005f4cd0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c578;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaad5c,&LAB_005f4450);
  uVar2 = FUN_005f5610();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00a36f60();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005f4c10(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaad5c,&LAB_005f4450);
      uVar2 = FUN_005f5610();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 6020 ; VA 0x005f4e60 ; FUN_005f4e60 */

undefined4 * FUN_005f4e60(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c5c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a28710();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x16c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00a2a3a0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005f4250(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6021 ; VA 0x005f4f20 ; FUN_005f4f20 */

int FUN_005f4f20(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c5d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea93d4,&LAB_005e5aa0);
  uVar2 = FUN_005e5b30();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00a287f0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005f4e60(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea93d4,&LAB_005e5aa0);
      uVar2 = FUN_005e5b30();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 6022 ; VA 0x005f50b0 ; FUN_005f50b0 */

undefined4 * FUN_005f50b0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c623;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00995690();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xf0);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009967b0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005f4340(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6023 ; VA 0x005f5170 ; FUN_005f5170 */

int FUN_005f5170(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c638;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
  uVar2 = FUN_00560d40();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00995770();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005f50b0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
      uVar2 = FUN_00560d40();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 6024 ; VA 0x005f5300 ; FUN_005f5300 */

int __fastcall FUN_005f5300(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c658;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00564290();
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    FUN_005eebc0(&iStack_18);
    uStack_8 = 0;
    FUN_008a5700(param_1);
    FUN_005789c0(&DAT_01ea8aa8,&LAB_0055d5b0);
    uVar4 = FUN_00560e40();
    piVar3 = (int *)FUN_008aa140(uVar4);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    *piVar3 = iStack_18;
    piVar1 = (int *)piVar3[1];
    piVar3[1] = (int)piStack_14;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[1] + -1;
      piVar1[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar5 = piVar1[2] + -1;
        piVar1[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    iVar5 = iStack_18;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 6025 ; VA 0x005f53f0 ; FUN_005f53f0 */

void FUN_005f53f0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_2[7];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_2[5];
  if (0xf < uVar3) {
    iVar4 = *param_2;
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 6026 ; VA 0x005f5470 ; FUN_005f5470 */

void FUN_005f5470(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  iVar1 = param_2[6];
  if (iVar1 != 0) {
    uVar3 = param_2[8] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_005f5502;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_2[6] = 0;
    param_2[7] = 0;
    param_2[8] = 0;
  }
  uVar3 = param_2[5];
  if (0xf < uVar3) {
    iVar1 = *param_2;
    uVar4 = uVar3 + 1;
    iVar2 = iVar1;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar4 = uVar3 + 0x24;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_005f5502:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 6027 ; VA 0x005f5510 ; FUN_005f5510 */

undefined4 FUN_005f5510(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c67c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaad80) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaad80);
    if (DAT_01eaad80 == -1) {
      uStack_8 = 0;
      DAT_01eaad7c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eaad80);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eaad7c;
}



/* FUNCTION 6028 ; VA 0x005f5590 ; FUN_005f5590 */

undefined4 FUN_005f5590(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c69c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaad70) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaad70);
    if (DAT_01eaad70 == -1) {
      uStack_8 = 0;
      DAT_01eaad6c = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eaad70);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eaad6c;
}



/* FUNCTION 6029 ; VA 0x005f5610 ; FUN_005f5610 */

undefined4 FUN_005f5610(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c6bc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaad78) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaad78);
    if (DAT_01eaad78 == -1) {
      uStack_8 = 0;
      DAT_01eaad74 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eaad78);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eaad74;
}



/* FUNCTION 6030 ; VA 0x005f5690 ; FUN_005f5690 */

int * FUN_005f5690(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eaad5c,&LAB_005f4450);
  uVar3 = FUN_005f5610();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00a36f60();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 6031 ; VA 0x005f5740 ; FUN_005f5740 */

undefined4 * __fastcall FUN_005f5740(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c6db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[0xf] = 0;
  param_1[0x10] = 0xf;
  *(undefined *)(param_1 + 0xb) = 0;
  uStack_8 = 0;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 1;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  *(undefined2 *)(param_1 + 0x16) = 0x100;
  *(undefined *)((int)param_1 + 0x5a) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6032 ; VA 0x005f5800 ; FUN_005f5800 */

void __fastcall FUN_005f5800(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 8);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        iVar4 = iVar4 + 0xc;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar4) / 0xc) * 0xc;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6033 ; VA 0x005f5890 ; FUN_005f5890 */

void __fastcall FUN_005f5890(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005f6240(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6034 ; VA 0x005f58f0 ; FUN_005f58f0 */

void __fastcall FUN_005f58f0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005f6300(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x34);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6035 ; VA 0x005f5950 ; FUN_005f5950 */

void __fastcall FUN_005f5950(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  iVar1 = param_1[6];
  if (iVar1 != 0) {
    uVar3 = param_1[8] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_005f59dd;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[8] = 0;
  }
  uVar3 = param_1[5];
  if (0xf < uVar3) {
    iVar1 = *param_1;
    uVar4 = uVar3 + 1;
    iVar2 = iVar1;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar4 = uVar3 + 0x24;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_005f59dd:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 6036 ; VA 0x005f59f0 ; FUN_005f59f0 */

void __fastcall FUN_005f59f0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_005f5f30();
        iVar2 = iVar2 + 0x48;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x48) * 0x48;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6037 ; VA 0x005f5a70 ; FUN_005f5a70 */

void __fastcall FUN_005f5a70(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int *piVar4;
  
  piVar3 = (int *)*param_1;
  if (piVar3 != (int *)0x0) {
    piVar4 = (int *)param_1[1];
    if (piVar3 != piVar4) {
      do {
        piVar1 = (int *)piVar3[9];
        if (piVar1 != (int *)0x0) {
          (**(code **)(*piVar1 + 0x10))(piVar1 != piVar3);
          piVar3[9] = 0;
        }
        piVar3 = piVar3 + 10;
      } while (piVar3 != piVar4);
      piVar3 = (int *)*param_1;
    }
    uVar2 = ((param_1[2] - (int)piVar3) / 0x28) * 0x28;
    piVar4 = piVar3;
    if (0xfff < uVar2) {
      piVar4 = (int *)piVar3[-1];
      uVar2 = uVar2 + 0x23;
      if (0x1f < (uint)((int)piVar3 + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar4,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6038 ; VA 0x005f5b10 ; thunk_FUN_01522e10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __fastcall thunk_FUN_01522e10(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::TaskScheduler::Job::vftable;
  if ((DAT_01f754a3 != '\0') &&
     (FUN_016774b0(DAT_01f754a3,"Job Destroyed - this(%p)",param_1), DAT_01f754a3 != '\0')) {
    FUN_01677760(DAT_01f754a3,"JobName(%s)",param_1 + 4);
  }
  iVar4 = FUN_016df150(param_1 + 0x34);
  piVar2 = (int *)param_1[0xb];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[9];
  if (0xf < uVar3) {
    iVar4 = param_1[4];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  param_1[8] = 0;
  param_1[9] = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  LOCK();
  _DAT_01ea8520 = _DAT_01ea8520 + -1;
  UNLOCK();
  piVar2 = (int *)param_1[3];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      iVar4 = (**(code **)(*piVar2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 6039 ; VA 0x005f5b20 ; FUN_005f5b20 */

void __fastcall FUN_005f5b20(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a950;
  pvStack_10 = ExceptionList;
  piVar5 = *(int **)(param_1 + 0xa4);
  ExceptionList = &pvStack_10;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar4 = piVar5[1] + -1;
    ExceptionList = &pvStack_10;
    piVar5[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar4 = piVar5[2] + -1;
      piVar5[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  iVar4 = *(int *)(param_1 + 0x98);
  piVar5 = (int *)(param_1 + 0x98);
  uStack_8 = 0;
  FUN_005f6240(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar5 + 4) = iVar4;
  *(int *)*piVar5 = iVar4;
  *(int *)(*piVar5 + 8) = iVar4;
  *(undefined4 *)(param_1 + 0x9c) = 0;
  FUN_01674ea0(*piVar5,0x30);
  iVar4 = *(int *)(param_1 + 0x90);
  piVar5 = (int *)(param_1 + 0x90);
  uStack_8 = 1;
  FUN_005f6240(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar5 + 4) = iVar4;
  *(int *)*piVar5 = iVar4;
  *(int *)(*piVar5 + 8) = iVar4;
  *(undefined4 *)(param_1 + 0x94) = 0;
  FUN_01674ea0(*piVar5,0x30);
  iVar4 = *(int *)(param_1 + 0x88);
  piVar5 = (int *)(param_1 + 0x88);
  uStack_8 = 2;
  FUN_005f6240(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar5 + 4) = iVar4;
  *(int *)*piVar5 = iVar4;
  *(int *)(*piVar5 + 8) = iVar4;
  *(undefined4 *)(param_1 + 0x8c) = 0;
  FUN_01674ea0(*piVar5,0x30);
  LOCK();
  iVar4 = *(int *)(param_1 + 0x84);
  *(int *)(param_1 + 0x84) = 0;
  UNLOCK();
  if (iVar4 != 0) {
    CloseHandle(iVar4);
  }
  iVar4 = *(int *)(param_1 + 0x78);
  uStack_8 = 3;
  FUN_005f6300(*(undefined4 *)(iVar4 + 4));
  uStack_8 = 0xffffffff;
  *(int *)(*(int *)(param_1 + 0x78) + 4) = iVar4;
  **(int **)(param_1 + 0x78) = iVar4;
  *(int *)(*(int *)(param_1 + 0x78) + 8) = iVar4;
  *(undefined4 *)(param_1 + 0x7c) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x78),0x34);
  iVar4 = *(int *)(param_1 + 0x6c);
  if (iVar4 != 0) {
    iVar7 = *(int *)(param_1 + 0x70);
    if (iVar4 != iVar7) {
      do {
        FUN_005f5f30();
        iVar4 = iVar4 + 0x48;
      } while (iVar4 != iVar7);
      iVar4 = *(int *)(param_1 + 0x6c);
    }
    uVar3 = ((*(int *)(param_1 + 0x74) - iVar4) / 0x48) * 0x48;
    iVar7 = iVar4;
    if (0xfff < uVar3) {
      iVar7 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar7) - 4U) goto LAB_005f5f1e;
    }
    FUN_01674ea0(iVar7,uVar3);
    *(undefined4 *)(param_1 + 0x6c) = 0;
    *(undefined4 *)(param_1 + 0x70) = 0;
    *(undefined4 *)(param_1 + 0x74) = 0;
  }
  piVar5 = *(int **)(param_1 + 0x60);
  if (piVar5 != (int *)0x0) {
    piVar6 = *(int **)(param_1 + 100);
    if (piVar5 != piVar6) {
      do {
        piVar1 = (int *)piVar5[9];
        if (piVar1 != (int *)0x0) {
          (**(code **)(*piVar1 + 0x10))(CONCAT31((int3)((uint)*piVar1 >> 8),piVar1 != piVar5));
          piVar5[9] = 0;
        }
        piVar5 = piVar5 + 10;
      } while (piVar5 != piVar6);
      piVar5 = *(int **)(param_1 + 0x60);
    }
    uVar3 = ((*(int *)(param_1 + 0x68) - (int)piVar5) / 0x28) * 0x28;
    piVar6 = piVar5;
    if (0xfff < uVar3) {
      piVar6 = (int *)piVar5[-1];
      uVar3 = uVar3 + 0x23;
      if (0x1f < (uint)((int)piVar5 + (-4 - (int)piVar6))) goto LAB_005f5f1e;
    }
    FUN_01674ea0(piVar6,uVar3);
    *(undefined4 *)(param_1 + 0x60) = 0;
    *(undefined4 *)(param_1 + 100) = 0;
    *(undefined4 *)(param_1 + 0x68) = 0;
  }
  piVar5 = *(int **)(param_1 + 0x5c);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar4 = piVar5[1] + -1;
    piVar5[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar4 = piVar5[2] + -1;
      piVar5[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uStack_8 = 4;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x50);
  if (iVar4 != 0) {
    piVar5 = (int *)(iVar4 + 4);
    LOCK();
    iVar7 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar7 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = *(int *)(param_1 + 0x40);
  if (iVar4 != 0) {
    iVar7 = *(int *)(param_1 + 0x44);
    if (iVar4 != iVar7) {
      do {
        piVar5 = *(int **)(iVar4 + 4);
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar2 = piVar5[2] + -1;
          piVar5[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
        iVar4 = iVar4 + 8;
      } while (iVar4 != iVar7);
      iVar4 = *(int *)(param_1 + 0x40);
    }
    uVar3 = *(int *)(param_1 + 0x48) - iVar4 & 0xfffffff8;
    iVar7 = iVar4;
    if (0xfff < uVar3) {
      iVar7 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar7) - 4U) goto LAB_005f5f1e;
    }
    FUN_01674ea0(iVar7,uVar3);
    *(undefined4 *)(param_1 + 0x40) = 0;
    *(undefined4 *)(param_1 + 0x44) = 0;
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  iVar4 = *(int *)(param_1 + 0x28);
  if (iVar4 != 0) {
    iVar7 = *(int *)(param_1 + 0x2c);
    if (iVar4 != iVar7) {
      do {
        piVar5 = *(int **)(iVar4 + 8);
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar2 = piVar5[2] + -1;
          piVar5[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
        iVar4 = iVar4 + 0xc;
      } while (iVar4 != iVar7);
      iVar4 = *(int *)(param_1 + 0x28);
    }
    uVar3 = ((*(int *)(param_1 + 0x30) - iVar4) / 0xc) * 0xc;
    iVar7 = iVar4;
    if (0xfff < uVar3) {
      iVar7 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar7) - 4U) {
LAB_005f5f1e:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar3);
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = 0;
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  iVar4 = *(int *)(param_1 + 0x24);
  if ((iVar4 != 0) && (iVar4 != -1)) {
    CloseHandle(iVar4);
  }
  FUN_0056d500();
  LOCK();
  iVar4 = *(int *)(param_1 + 0xc);
  *(int *)(param_1 + 0xc) = 0;
  UNLOCK();
  if (iVar4 != 0) {
    CloseHandle(iVar4);
  }
  LOCK();
  iVar4 = *(int *)(param_1 + 4);
  *(int *)(param_1 + 4) = 0;
  UNLOCK();
  if (iVar4 != 0) {
    CloseHandle(iVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6040 ; VA 0x005f5f30 ; FUN_005f5f30 */

int __fastcall FUN_005f5f30(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 uVar4;
  char cVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar6 = (int *)(param_1 + 8);
  uStack_8 = 0;
  LOCK();
  piVar10 = (int *)(*piVar6 + 0x28);
  iVar1 = *piVar10;
  iVar8 = *piVar10;
  ExceptionList = &pvStack_10;
  *piVar10 = iVar1 + -1;
  UNLOCK();
  if (iVar1 + -1 != 0) goto LAB_005f6041;
  FUN_00585a90();
  uVar4 = DAT_01ea8518;
  EnterCriticalSection(DAT_01ea8518);
  cVar5 = FUN_00578b90(piVar6);
  if (cVar5 != '\0') {
    iVar1 = *piVar6;
    piVar10 = (int *)(-(uint)(iVar1 != 0) & iVar1 + 0x30U);
    piVar6 = (int *)(DAT_01ea8514 + 0x28);
    if (DAT_01ea8514 == -0xc) {
      piVar6 = (int *)0x28;
    }
    *piVar6 = *piVar6 + -1;
    iVar8 = *piVar10;
    puVar2 = (undefined4 *)piVar10[1];
    if (*(int **)(iVar8 + 4) == piVar10) {
      piVar6 = (int *)*puVar2;
      *(undefined4 **)(iVar8 + 4) = puVar2;
      if (piVar6 == piVar10) goto LAB_005f5fe6;
      piVar6 = *(int **)piVar10[1];
    }
    else if ((int *)*puVar2 == piVar10) {
      **(undefined4 **)(iVar8 + 4) = puVar2;
LAB_005f5fe6:
      piVar6 = (int *)piVar10[1];
    }
    else {
      **(undefined4 **)(iVar8 + 4) = 0;
      *(int *)(*piVar10 + 4) = piVar10[1];
      piVar6 = *(int **)piVar10[1];
    }
    *piVar6 = *piVar10;
    uVar3 = *(uint *)(iVar1 + 0x24);
    if (0xf < uVar3) {
      iVar8 = *(int *)(iVar1 + 0x10);
      uVar9 = uVar3 + 1;
      iVar7 = iVar8;
      if (0xfff < uVar9) {
        iVar7 = *(int *)(iVar8 + -4);
        uVar9 = uVar3 + 0x24;
        if (0x1f < (iVar8 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar9);
    }
    *(undefined4 *)(iVar1 + 0x20) = 0;
    *(undefined4 *)(iVar1 + 0x24) = 0xf;
    *(undefined *)(iVar1 + 0x10) = 0;
    FUN_01674ea0(iVar1,0x38);
  }
  iVar8 = LeaveCriticalSection(uVar4);
LAB_005f6041:
  piVar6 = *(int **)(param_1 + 4);
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar10 = piVar6 + 1;
    iVar1 = *piVar10;
    iVar8 = *piVar10;
    *piVar10 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar8 = (**(code **)*piVar6)();
      LOCK();
      piVar10 = piVar6 + 2;
      iVar1 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar8 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 6041 ; VA 0x005f60a0 ; FUN_005f60a0 */

void __fastcall FUN_005f60a0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar3 = *param_1;
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6042 ; VA 0x005f60f0 ; FUN_005f60f0 */

undefined4 __thiscall FUN_005f60f0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x148);
  }
  return param_1;
}



/* FUNCTION 6043 ; VA 0x005f6120 ; FUN_005f6120 */

undefined4 __thiscall FUN_005f6120(undefined4 param_1,byte param_2)

{
  FUN_005f5b20();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xa8);
  }
  return param_1;
}



/* FUNCTION 6044 ; VA 0x005f6150 ; FUN_005f6150 */

int __thiscall FUN_005f6150(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x134);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x138);
  }
  return param_1;
}



/* FUNCTION 6045 ; VA 0x005f61d0 ; FUN_005f61d0 */

void __fastcall FUN_005f61d0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_005f5b20();
    FUN_01674ea0(iVar1,0xa8);
  }
  return;
}



/* FUNCTION 6046 ; VA 0x005f61f0 ; FUN_005f61f0 */

void __fastcall FUN_005f61f0(int param_1)

{
  (*(code *)**(undefined4 **)(param_1 + 0x10))(0);
  return;
}



/* FUNCTION 6047 ; VA 0x005f6200 ; FUN_005f6200 */

void FUN_005f6200(int *param_1,int *param_2)

{
  int *piVar1;
  
  if (param_1 != param_2) {
    do {
      piVar1 = (int *)param_1[9];
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x10))(piVar1 != param_1);
        param_1[9] = 0;
      }
      param_1 = param_1 + 10;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 6048 ; VA 0x005f6240 ; FUN_005f6240 */

void FUN_005f6240(int *param_1)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_005f6240(param_1[2]);
    piVar2 = (int *)param_1[0xb];
    piVar3 = (int *)*param_1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = piVar2[1] + -1;
      piVar2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar5 = piVar2[2] + -1;
        piVar2[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar4 = param_1[9];
    if (0xf < uVar4) {
      iVar5 = param_1[4];
      uVar7 = uVar4 + 1;
      iVar6 = iVar5;
      if (0xfff < uVar7) {
        iVar6 = *(int *)(iVar5 + -4);
        uVar7 = uVar4 + 0x24;
        if (0x1f < (iVar5 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar7);
    }
    param_1[8] = 0;
    param_1[9] = 0xf;
    *(undefined *)(param_1 + 4) = 0;
    FUN_01674ea0(param_1,0x30);
    cVar1 = *(char *)((int)piVar3 + 0xd);
    param_1 = piVar3;
  } while( true );
}



/* FUNCTION 6049 ; VA 0x005f6300 ; FUN_005f6300 */

void FUN_005f6300(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_005f6300(param_1[2]);
    iVar2 = param_1[10];
    piVar3 = (int *)*param_1;
    if (iVar2 != 0) {
      uVar5 = param_1[0xc] - iVar2 & 0xfffffffc;
      iVar4 = iVar2;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar2 + -4);
        uVar5 = uVar5 + 0x23;
        if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_005f63d8;
      }
      FUN_01674ea0(iVar4,uVar5);
      param_1[10] = 0;
      param_1[0xb] = 0;
      param_1[0xc] = 0;
    }
    uVar5 = param_1[9];
    if (0xf < uVar5) {
      iVar2 = param_1[4];
      uVar6 = uVar5 + 1;
      iVar4 = iVar2;
      if (0xfff < uVar6) {
        iVar4 = *(int *)(iVar2 + -4);
        uVar6 = uVar5 + 0x24;
        if (0x1f < (iVar2 - iVar4) - 4U) {
LAB_005f63d8:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar6);
    }
    param_1[8] = 0;
    param_1[9] = 0xf;
    *(undefined *)(param_1 + 4) = 0;
    FUN_01674ea0(param_1,0x34);
    cVar1 = *(char *)((int)piVar3 + 0xd);
    param_1 = piVar3;
  } while( true );
}



/* FUNCTION 6050 ; VA 0x005f63e0 ; FUN_005f63e0 */

void FUN_005f63e0(undefined4 param_1,int param_2)

{
  FUN_005f6430(param_1,param_2);
  if (*(int *)(param_2 + 0x10) != 3) {
    FUN_005f5170();
    FUN_00999b50(1);
  }
  if (DAT_01d5a508 != '\0') {
    FUN_00909d80(1);
  }
  return;
}



/* FUNCTION 6051 ; VA 0x005f6430 ; FUN_005f6430 */

void FUN_005f6430(code *param_1,undefined8 *param_2)

{
  code *pcVar1;
  code *pcVar2;
  int iVar3;
  uint *puVar4;
  undefined8 *puVar5;
  undefined uVar6;
  char cVar7;
  undefined4 uVar8;
  int iVar9;
  int *piVar10;
  undefined4 extraout_ECX;
  uint uVar11;
  code *pcVar12;
  uint uVar13;
  undefined *puVar14;
  uint *puStack_d4;
  uint *puStack_d0;
  uint *puStack_cc;
  uint *puStack_c8;
  undefined8 uStack_c4;
  uint auStack_98 [4];
  undefined4 uStack_88;
  uint uStack_84;
  uint auStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  int iStack_38;
  code *pcStack_34;
  code *pcStack_30;
  int iStack_2c;
  uint auStack_28 [3];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = param_2;
  puVar4 = (uint *)param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c750;
  pvStack_10 = ExceptionList;
  if (*(char *)(*(uint *)param_1 + 0x1dd) == '\0') {
    uStack_c4 = 3.260156859367502e-301;
    ExceptionList = &pvStack_10;
    FUN_00550130();
    uStack_c4 = (double)CONCAT44(&DAT_01c17198,auStack_1c);
                    /* WARNING: Subroutine does not return */
    puStack_c8 = (uint *)0x5f6bee;
    FUN_0170c2a8();
  }
  uStack_c4 = (double)CONCAT44(*(undefined4 *)((int)param_2 + 0x54),
                               *(undefined4 *)((int)param_2 + 4));
  puStack_c8 = *(uint **)param_2;
  puStack_cc = (uint *)0x5f6473;
  ExceptionList = &pvStack_10;
  FUN_0090b030();
  uStack_c4 = (double)puVar5[1];
  puStack_c8 = (uint *)0x5f6480;
  FUN_0090b450();
  uStack_c4 = (double)puVar5[1];
  puStack_c8 = (uint *)0x5f648b;
  FUN_01522650();
  uStack_c4 = (double)CONCAT44(0x5f6498,(undefined4)uStack_c4);
  FUN_005f4a80();
  uStack_c4 = 3.08874081085845e-317;
  FUN_00a653e0();
  FUN_01255470(8,0,0,0);
  FUN_01255490();
  uStack_8 = 0;
  uStack_c4 = (double)CONCAT44(0x5f64cf,(undefined4)uStack_c4);
  iStack_2c = FUN_005f5300();
  uStack_c4 = (double)CONCAT44(0x5f64d7,(undefined4)uStack_c4);
  uVar8 = FUN_0151b370();
  uStack_c4 = (double)CONCAT44(uVar8,auStack_28);
  puStack_c8 = (uint *)0x5f64e1;
  puStack_c8 = (uint *)FUN_0151f2f0();
  puStack_cc = auStack_50;
  uStack_8._0_1_ = 1;
  puStack_d0 = (uint *)0x5f64ef;
  FUN_00936ac0();
  uStack_8._0_1_ = 3;
  uVar6 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if ((code *)0xf < pcStack_14) {
    pcVar12 = pcStack_14 + 1;
    uVar11 = auStack_28[0];
    if ((code *)0xfff < pcVar12) {
      uVar11 = *(uint *)(auStack_28[0] - 4);
      pcVar12 = pcStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar11) - 4) {
        uStack_c4 = (double)CONCAT44(0x5f6bf3,(undefined4)uStack_c4);
        uStack_8._0_1_ = uVar6;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_c4 = (double)CONCAT44(pcVar12,uVar11);
    puStack_c8 = (uint *)0x5f6527;
    FUN_01674ea0();
  }
  uStack_18 = 0;
  uStack_c4 = (double)CONCAT44(&DAT_018c912c,auStack_50);
  puStack_c8 = auStack_98;
  pcStack_14 = (code *)&DAT_0000000f;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  puStack_cc = (uint *)0x5f6551;
  FUN_0151b590();
  puStack_cc = (uint *)0x18c9130;
  puStack_d0 = auStack_50;
  uStack_8._0_1_ = 4;
  puStack_d4 = auStack_68;
  FUN_0151b590();
  uStack_8._0_1_ = 5;
  FUN_0151b590(auStack_80,auStack_50,&DAT_018be4a0);
  DAT_01f6e610 = *(undefined4 *)(puVar5 + 2);
  iVar3 = *(int *)(puVar5 + 2);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar9 = iVar3;
  iStack_38 = iVar3;
  if (iVar3 == 3) {
    uStack_c4 = 1.2744815233274e-313;
    puStack_c8 = (uint *)0x1;
    puStack_cc = (uint *)0x5f65a7;
    FUN_0086edd0();
    uStack_c4 = (double)CONCAT44(0x5f65b2,(undefined4)uStack_c4);
    FUN_00642a80();
    iVar9 = *(int *)(puVar5 + 2);
  }
  if (iVar9 == 4) {
    uStack_c4 = 1.27448152510604e-313;
    puStack_c8 = (uint *)0x1;
    puStack_cc = (uint *)0x5f65c8;
    FUN_0086edd0();
    uStack_c4 = (double)CONCAT44(0x5f65d3,(undefined4)uStack_c4);
    FUN_00642be0();
  }
  uStack_c4 = (double)CONCAT44(0x5f65dd,(undefined4)uStack_c4);
  param_1 = (code *)FUN_0055e560();
  FUN_005f3cd0(&puStack_d4,auStack_50,&DAT_01d59bd8);
  FUN_0098c5b0();
  if (iVar3 == 3) {
    uStack_c4 = (double)CONCAT44(0x5f660e,(undefined4)uStack_c4);
    FUN_005f45e0();
  }
  uStack_c4 = (double)CONCAT44(0x5f6618,(undefined4)uStack_c4);
  FUN_005c2760();
  FUN_00558ce0(&puStack_d4,auStack_50,&DAT_018c36fc);
  FUN_008da0d0();
  if ((*(char *)((int)puVar5 + 0x59) != '\0') && ((DAT_01d59c28 == '\0' || (iStack_38 != 3)))) {
    if (DAT_01d660d0 == '\0') {
      uStack_c4 = (double)CONCAT44(0x5f66ad,(undefined4)uStack_c4);
      FUN_005f4cd0();
      uStack_c4 = (double)(ulonglong)*(uint *)((int)puVar5 + 0xc);
      puStack_c8 = *(uint **)(puVar5 + 1);
      puStack_cc = (uint *)0x5f66bc;
      FUN_00a4d7d0();
    }
    else {
      uStack_c4 = (double)CONCAT44(&uStack_18,0x5f6662);
      FUN_00a53720();
      uStack_c4 = (double)CONCAT44(*(undefined4 *)(puVar5 + 1),*puVar4);
      uStack_8._0_1_ = 7;
      puStack_c8 = (uint *)0x5f6675;
      FUN_00a54230();
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      pcStack_30 = pcStack_14;
      if (pcStack_14 != (code *)0x0) {
        LOCK();
        iVar3 = *(int *)(pcStack_14 + 4) + -1;
        *(int *)(pcStack_14 + 4) = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          uStack_c4 = (double)CONCAT44(0x5f6690,(undefined4)uStack_c4);
          (*(code *)**(undefined4 **)pcStack_14)();
          LOCK();
          iVar3 = *(int *)(pcStack_30 + 8) + -1;
          *(int *)(pcStack_30 + 8) = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            uStack_c4 = (double)CONCAT44(0x5f66a1,(undefined4)uStack_c4);
            (**(code **)(*(int *)pcStack_30 + 4))();
          }
        }
      }
    }
  }
  FUN_005f3cd0(&puStack_d4,auStack_68,&DAT_01d59bf0);
  uVar8 = 0x5f66db;
  FUN_0098c780();
  if (*(int *)((int)puVar5 + 0x3c) != 0) {
    FUN_0054ef60((undefined4 *)((int)puVar5 + 0x2c));
    uVar8 = 0x5f66f8;
    FUN_0090b7f0();
  }
  uStack_c4 = (double)CONCAT44(0x5f6705,(undefined4)uStack_c4);
  FUN_005f4830();
  uStack_c4 = (double)*puVar5;
  puStack_c8 = (uint *)0x5f6711;
  FUN_00a5d660();
  uStack_c4 = *(double *)((int)puVar5 + 0x1c);
  puStack_c8 = *(uint **)(puVar5 + 3);
  puStack_cc = (uint *)0x5f6721;
  FUN_0090a890();
  uStack_c4 = (double)CONCAT44(*(undefined4 *)((int)puVar5 + 0x24),0x5f672b);
  FUN_0090b1c0();
  uStack_c4 = (double)puVar5[9];
  puStack_c8 = (uint *)0x5f6738;
  FUN_0090b8d0();
  pcStack_30 = FUN_005f6ef0;
  uStack_c4 = (double)CONCAT44(&pcStack_30,&pcStack_14);
  puStack_c8 = (uint *)0x5f6755;
  FUN_005f4460();
  if (pcStack_14 != (code *)0x0) {
    pcVar12 = pcStack_14 + 4;
    LOCK();
    iVar3 = *(int *)pcVar12;
    *(int *)pcVar12 = *(int *)pcVar12 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      uStack_c4 = (double)CONCAT44(pcStack_14,0x5f6772);
      FUN_01674ea0();
    }
  }
  param_1 = FUN_005f6fc0;
  uStack_c4 = (double)CONCAT44(&param_1,&pcStack_14);
  puStack_c8 = (uint *)0x5f6792;
  FUN_005f4460();
  if (pcStack_14 != (code *)0x0) {
    pcVar12 = pcStack_14 + 4;
    LOCK();
    iVar3 = *(int *)pcVar12;
    *(int *)pcVar12 = *(int *)pcVar12 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      uStack_c4 = (double)CONCAT44(pcStack_14,0x5f67af);
      FUN_01674ea0();
    }
  }
  uStack_c4 = 1.28152525854628e-316;
  uStack_18 = 0;
  *(undefined *)(iStack_2c + 0x3a4) = 1;
  pcStack_14 = (code *)0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  puStack_c8 = (uint *)0x5f67df;
  FUN_005542c0();
  uStack_8._0_1_ = 8;
  uStack_c4 = (double)CONCAT44(auStack_28,1);
  puStack_c8 = (uint *)0x5f67f0;
  FUN_008ff820();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if ((code *)0xf < pcStack_14) {
    pcVar12 = pcStack_14 + 1;
    uVar11 = auStack_28[0];
    if ((code *)0xfff < pcVar12) {
      uVar11 = *(uint *)(auStack_28[0] - 4);
      pcVar12 = pcStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar11) - 4) {
        uStack_c4 = (double)CONCAT44(0x5f6bf8,(undefined4)uStack_c4);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_c4 = (double)CONCAT44(pcVar12,uVar11);
    puStack_c8 = (uint *)0x5f6825;
    FUN_01674ea0();
  }
  uStack_c4 = (double)CONCAT44(*(undefined4 *)(puVar5 + 5),*(undefined4 *)((int)puVar5 + 4));
  puStack_c8 = *(uint **)puVar5;
  puStack_cc = (undefined4 *)0x5f6837;
  FUN_008ff6c0();
  iVar3 = iStack_38;
  if (iStack_38 == 3) {
    if (DAT_01d661b8 == '\0') {
      uStack_c4 = (double)CONCAT44(0x5f6860,(undefined4)uStack_c4);
      FUN_005f4f20();
      uStack_c4 = (double)CONCAT44(0x5f6867,(undefined4)uStack_c4);
      FUN_00a2e340();
    }
    else {
      uStack_c4 = (double)CONCAT44(0x5f6852,(undefined4)uStack_c4);
      FUN_005f4f20();
      uStack_c4 = (double)CONCAT44(0x5f6859,(undefined4)uStack_c4);
      FUN_00a2e3d0();
    }
    uStack_c4 = (double)CONCAT44(0x5f686e,(undefined4)uStack_c4);
    FUN_0090bb50();
  }
  if (DAT_01d59d40 != '\0') {
    puStack_cc = (uint *)&DAT_01d5b048;
    if (0xf < DAT_01d5b05c) {
      puStack_cc = DAT_01d5b048;
    }
    uStack_c4 = 1.28152525854628e-316;
    puStack_c8 = (uint *)DAT_01d5b058;
    puStack_d0 = (uint *)0x5f689d;
    cVar7 = FUN_0055c360();
    if ((cVar7 == '\0') && (DAT_01eadf3c != 0)) {
      param_1 = (code *)CONCAT31(param_1._1_3_,1);
      goto LAB_005f68b9;
    }
  }
  param_1 = (code *)CONCAT31(param_1._1_3_,*(undefined *)((int)puVar5 + 0x5a));
LAB_005f68b9:
  uStack_c4 = (double)CONCAT44(0x5f68c3,(undefined4)uStack_c4);
  FUN_005f5300();
  uStack_c4 = (double)CONCAT44(param_1,CONCAT31((int3)((uint)extraout_ECX >> 8),
                                                *(undefined *)(puVar5 + 0xb)));
  puStack_c8 = *(uint **)(puVar5 + 10);
  puStack_cc = (uint *)0x5f68d4;
  FUN_0064aa50();
  uStack_c4 = (double)CONCAT44(0x5f68de,(undefined4)uStack_c4);
  FUN_0055ea10();
  uStack_c4 = (double)DAT_01d59b88;
  puStack_c8 = (uint *)0x5f68f9;
  FUN_0095c840();
  if (DAT_01d59c08 != '\0') {
    uStack_c4 = (double)CONCAT44(0x5f6907,(undefined4)uStack_c4);
    FUN_00877170();
  }
  if (DAT_01d59c10 != '\0') {
    uStack_c4 = 4.24708088696437e-314;
    FUN_00a55fb0();
  }
  if (DAT_01d5a508 != '\0') {
    pcStack_14 = (code *)*puVar4;
    param_1 = (code *)((uint)param_1 & 0xffffff00);
    cVar7 = FUN_00585a40(&param_1);
    if (cVar7 == '\0') {
      puVar14 = &DAT_018c921d;
    }
    else {
      puVar14 = (undefined *)0x0;
    }
    FUN_00907e20(puVar14,uVar8);
  }
  if (iVar3 == 3) {
    uStack_c4 = (double)CONCAT44(0x5f696e,(undefined4)uStack_c4);
    piVar10 = (int *)FUN_00564290();
    if ((*piVar10 != 0) && (param_1 = *(code **)(*puVar4 + 0x1b8), param_1 != (code *)0x0)) {
      uStack_c4 = 1.2744815270823e-313;
      puStack_c8 = (uint *)0x1;
      puStack_cc = (uint *)0x5f6998;
      FUN_0086edd0();
      puStack_cc = (uint *)0x148;
      puStack_d0 = (uint *)0x5f69a2;
      pcStack_14 = (code *)FUN_01674e20();
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      if (pcStack_14 == (code *)0x0) {
        pcVar12 = (code *)0x0;
      }
      else {
        uStack_c4 = (double)CONCAT44(puVar4,0x5f69b8);
        pcVar12 = (code *)FUN_005f3b80();
      }
      pcVar1 = pcVar12 + 0x10;
      pcStack_34 = pcVar1;
      pcStack_30 = pcVar12;
      if ((pcVar1 != (code *)0x0) &&
         ((*(int *)(pcVar12 + 0x1c) == 0 || (*(int *)(*(int *)(pcVar12 + 0x1c) + 4) == 0)))) {
        if (pcVar12 != (code *)0x0) {
          LOCK();
          *(int *)(pcVar12 + 4) = *(int *)(pcVar12 + 4) + 1;
          UNLOCK();
          if (pcVar12 != (code *)0x0) {
            LOCK();
            *(int *)(pcVar12 + 8) = *(int *)(pcVar12 + 8) + 1;
            UNLOCK();
          }
        }
        *(code **)(pcVar12 + 0x18) = pcVar1;
        piVar10 = *(int **)(pcVar12 + 0x1c);
        *(code **)(pcVar12 + 0x1c) = pcVar12;
        if (piVar10 != (int *)0x0) {
          LOCK();
          iVar3 = piVar10[2] + -1;
          piVar10[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            uStack_c4 = (double)CONCAT44(0x5f6a06,(undefined4)uStack_c4);
            (**(code **)(*piVar10 + 4))();
          }
        }
        if (pcVar12 != (code *)0x0) {
          LOCK();
          iVar3 = *(int *)(pcVar12 + 4) + -1;
          *(int *)(pcVar12 + 4) = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            uStack_c4 = (double)CONCAT44(0x5f6a19,(undefined4)uStack_c4);
            (*(code *)**(undefined4 **)pcVar12)();
            LOCK();
            pcVar2 = pcVar12 + 8;
            iVar3 = *(int *)pcVar2;
            *(int *)pcVar2 = *(int *)pcVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
              uStack_c4 = (double)CONCAT44(0x5f6a28,(undefined4)uStack_c4);
              (**(code **)(*(int *)pcVar12 + 4))();
            }
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      pcVar2 = pcVar12 + 4;
      if (pcVar12 != (code *)0x0) {
        LOCK();
        *(int *)pcVar2 = *(int *)pcVar2 + 1;
        UNLOCK();
      }
      uStack_c4 = (double)CONCAT44(pcVar12,pcVar1);
      puStack_c8 = (uint *)0x5f6a52;
      FUN_0151d950();
      if (pcVar12 != (code *)0x0) {
        LOCK();
        *(int *)pcVar2 = *(int *)pcVar2 + 1;
        UNLOCK();
      }
      uStack_c4 = (double)CONCAT44(pcVar12,pcVar1);
      puStack_c8 = (uint *)0x5f6a75;
      FUN_008babc0();
      uStack_c4 = 0.0;
      puStack_c8 = (uint *)0x0;
      puStack_cc = (uint *)0x18c91d4;
      puStack_d0 = (uint *)0x18c91e8;
      puStack_d4 = (uint *)&DAT_018c5f98;
      FUN_0087c450();
      uStack_c4 = (double)CONCAT44(0x5f6a9a,(undefined4)uStack_c4);
      FUN_00550b30();
    }
  }
  if (0xf < uStack_6c) {
    uVar13 = uStack_6c + 1;
    uVar11 = auStack_80[0];
    if (0xfff < uVar13) {
      uVar11 = *(uint *)(auStack_80[0] - 4);
      uVar13 = uStack_6c + 0x24;
      if (0x1f < (auStack_80[0] - uVar11) - 4) {
        uStack_c4 = (double)CONCAT44(0x5f6bfd,(undefined4)uStack_c4);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_c4 = (double)CONCAT44(uVar13,uVar11);
    puStack_c8 = (uint *)0x5f6acb;
    FUN_01674ea0();
  }
  uStack_70 = 0;
  uStack_6c = 0xf;
  auStack_80[0] = auStack_80[0] & 0xffffff00;
  if (0xf < uStack_54) {
    uVar13 = uStack_54 + 1;
    uVar11 = auStack_68[0];
    if (0xfff < uVar13) {
      uVar11 = *(uint *)(auStack_68[0] - 4);
      uVar13 = uStack_54 + 0x24;
      if (0x1f < (auStack_68[0] - uVar11) - 4) {
        uStack_c4 = (double)CONCAT44(0x5f6c02,(undefined4)uStack_c4);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_c4 = (double)CONCAT44(uVar13,uVar11);
    puStack_c8 = (uint *)0x5f6b11;
    FUN_01674ea0();
  }
  uStack_58 = 0;
  uStack_54 = 0xf;
  auStack_68[0] = auStack_68[0] & 0xffffff00;
  if (0xf < uStack_84) {
    uVar13 = uStack_84 + 1;
    uVar11 = auStack_98[0];
    if (0xfff < uVar13) {
      uVar11 = *(uint *)(auStack_98[0] - 4);
      uVar13 = uStack_84 + 0x24;
      if (0x1f < (auStack_98[0] - uVar11) - 4) {
        uStack_c4 = (double)CONCAT44(0x5f6c07,(undefined4)uStack_c4);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_c4 = (double)CONCAT44(uVar13,uVar11);
    puStack_c8 = (uint *)0x5f6b5a;
    FUN_01674ea0();
  }
  uStack_88 = 0;
  uStack_84 = 0xf;
  auStack_98[0] = auStack_98[0] & 0xffffff00;
  if (0xf < uStack_3c) {
    uVar13 = uStack_3c + 1;
    uVar11 = auStack_50[0];
    if (0xfff < uVar13) {
      uVar11 = *(uint *)(auStack_50[0] - 4);
      uVar13 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar11) - 4) {
        uStack_c4 = (double)CONCAT44(&UNK_005f6c0c,(undefined4)uStack_c4);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_c4 = (double)CONCAT44(uVar13,uVar11);
    puStack_c8 = (uint *)0x5f6ba2;
    FUN_01674ea0();
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  uStack_c4 = (double)CONCAT44(0x5f6bc2,(undefined4)uStack_c4);
  FUN_01255500();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6052 ; VA 0x005f6c10 ; FUN_005f6c10 */

void FUN_005f6c10(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x28;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 6053 ; VA 0x005f6c50 ; FUN_005f6c50 */

int FUN_005f6c50(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)(param_1 + 0x18))(&param_2);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 6054 ; VA 0x005f6cc0 ; FUN_005f6cc0 */

void __thiscall FUN_005f6cc0(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  void **ppvVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar2 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar2 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005f6240(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar2, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    iVar3 = FUN_00553830(param_3);
    FUN_005f53f0(param_1,iVar3 + 0x10);
    FUN_01674ea0(iVar3,0x30);
    ppvVar2 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6055 ; VA 0x005f6d90 ; FUN_005f6d90 */

void __thiscall FUN_005f6d90(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  void **ppvVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar2 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar2 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005f6300(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar2, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    iVar3 = FUN_00553830(param_3);
    FUN_005f5470(param_1,iVar3 + 0x10);
    FUN_01674ea0(iVar3,0x34);
    ppvVar2 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6056 ; VA 0x005f6e60 ; FUN_005f6e60 */

void FUN_005f6e60(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  FUN_0086f2f0(1,"Entering new Romark phase: %d",param_2);
  uVar1 = FUN_01675100(param_2);
  FUN_0086f2f0(1,"Tracked memory is %zu bytes at the start of Romark phase %d",uVar1);
  return;
}



/* FUNCTION 6057 ; VA 0x005f6e90 ; FUN_005f6e90 */

void FUN_005f6e90(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d95edc);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_1a6aac60853cf667ce8211c1ce45eae3>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 6058 ; VA 0x005f6ef0 ; FUN_005f6ef0 */

void FUN_005f6ef0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c770;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01eadc98);
  uStack_8 = 0;
  uStack_14 = uVar3;
  FUN_00562c90(&iStack_1c,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_1c != 0) {
    if (DAT_01d84e8d != '\0') {
      uVar4 = FUN_00928340();
      FUN_01677520(DAT_01d84e8d,"Player %lld added",uVar4);
    }
    FUN_0092c090();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  uStack_8 = 2;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6059 ; VA 0x005f6fc0 ; FUN_005f6fc0 */

void FUN_005f6fc0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c770;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01eadc98);
  uStack_8 = 0;
  uStack_14 = uVar3;
  FUN_00562c90(&iStack_1c,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_1c != 0) {
    if (DAT_01d84e8d != '\0') {
      uVar4 = FUN_00928340();
      FUN_01677520(DAT_01d84e8d,"Player %lld leaving",uVar4);
    }
    FUN_00931f00();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  uStack_8 = 2;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6060 ; VA 0x005f70a0 ; FUN_005f70a0 */

undefined4 * __fastcall FUN_005f70a0(undefined4 *param_1)

{
  *(undefined2 *)(param_1 + 2) = 0xffff;
  *param_1 = DAT_01d59c60;
  param_1[1] = DAT_01d59c64;
  *(undefined2 *)(param_1 + 2) = DAT_01d59c68;
  return param_1;
}



/* FUNCTION 6061 ; VA 0x005f70d0 ; FUN_005f70d0 */

undefined2 * __thiscall FUN_005f70d0(undefined2 *param_1,undefined2 param_2,char *param_3)

{
  char cVar1;
  undefined2 uVar2;
  char *pcVar3;
  
  *param_1 = param_2;
  if (param_3 == (char *)0x0) {
    *(undefined *)(param_1 + 1) = 0;
  }
  else {
    pcVar3 = param_3;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
      pcVar3[(int)((int)(param_1 + 1) + (-1 - (int)param_3))] = cVar1;
    } while (cVar1 != '\0');
  }
  uVar2 = 2;
  if (DAT_01d5b1e4 != '\0') {
    uVar2 = 0;
  }
  param_1[0x22] = uVar2;
  return param_1;
}



/* FUNCTION 6062 ; VA 0x005f7120 ; FUN_005f7120 */

undefined2 * __fastcall FUN_005f7120(undefined2 *param_1)

{
  undefined2 uVar1;
  
  *param_1 = 0;
  *(undefined *)(param_1 + 1) = 0;
  uVar1 = 2;
  if (DAT_01d5b1e4 != '\0') {
    uVar1 = 0;
  }
  param_1[0x22] = uVar1;
  return param_1;
}



/* FUNCTION 6063 ; VA 0x005f7140 ; FUN_005f7140 */

undefined4 * __fastcall FUN_005f7140(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  *(undefined8 *)(param_1 + 4) = 0;
  param_1[6] = 0;
  *(undefined2 *)param_1 = 2;
  param_1[7] = 0xffff0000;
  return param_1;
}



/* FUNCTION 6064 ; VA 0x005f7170 ; FUN_005f7170 */

undefined4 * __thiscall FUN_005f7170(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_1[6] = param_2[6];
  *(undefined2 *)((int)param_1 + 0x1e) = *(undefined2 *)((int)param_2 + 0x1e);
  *(undefined2 *)(param_1 + 7) = *(undefined2 *)(param_2 + 7);
  return param_1;
}



/* FUNCTION 6065 ; VA 0x005f71b0 ; FUN_005f71b0 */

uint __thiscall FUN_005f71b0(uint *param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = *param_1;
  if ((uVar1 == *param_2) && (uVar1 = param_1[1], uVar1 == param_2[1])) {
    return CONCAT31((int3)(uVar1 >> 8),1);
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 6066 ; VA 0x005f71d0 ; FUN_005f71d0 */

uint __thiscall FUN_005f71d0(ushort *param_1,ushort *param_2)

{
  undefined4 in_EAX;
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uVar4;
  bool bVar5;
  
  uVar1 = CONCAT22((short)((uint)in_EAX >> 0x10),param_1[1]);
  if (param_1[1] == param_2[1]) {
    uVar1 = (uint)*param_1;
    if (DAT_01d5b1e4 == '\0') {
      if ((uVar1 == 2) && (uVar1 = *(uint *)(param_1 + 2), uVar1 == *(uint *)(param_2 + 2))) {
LAB_005f7239:
        return CONCAT31((int3)(uVar1 >> 8),1);
      }
    }
    else if (*param_1 == *param_2) {
      if (uVar1 == 2) {
        uVar1 = *(uint *)(param_1 + 2);
        if (uVar1 == *(uint *)(param_2 + 2)) goto LAB_005f7239;
      }
      else if (uVar1 == 0x17) {
        puVar3 = (uint *)(param_2 + 4);
        uVar4 = 0xc;
        puVar2 = (uint *)(param_1 + 4);
        while (uVar1 = *puVar2, uVar1 == *puVar3) {
          puVar2 = puVar2 + 1;
          puVar3 = puVar3 + 1;
          bVar5 = uVar4 < 4;
          uVar4 = uVar4 - 4;
          if (bVar5) {
            return CONCAT31((int3)(uVar1 >> 8),1);
          }
        }
      }
    }
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 6067 ; VA 0x005f7240 ; FUN_005f7240 */

uint __thiscall FUN_005f7240(uint *param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = *param_1;
  if ((uVar1 == *param_2) && (uVar1 = param_1[1], uVar1 == param_2[1])) {
    return uVar1 & 0xffffff00;
  }
  return CONCAT31((int3)(uVar1 >> 8),1);
}



/* FUNCTION 6068 ; VA 0x005f7260 ; FUN_005f7260 */

byte FUN_005f7260(undefined4 param_1)

{
  byte bVar1;
  
  bVar1 = FUN_005f71d0(param_1);
  return bVar1 ^ 1;
}



/* FUNCTION 6069 ; VA 0x005f7280 ; FUN_005f7280 */

void __thiscall FUN_005f7280(int param_1,int param_2)

{
  *(undefined2 *)(param_1 + 2) = *(undefined2 *)(param_2 + 2);
  *(undefined2 *)(param_1 + 0x1c) = *(undefined2 *)(param_2 + 0x1c);
  return;
}



/* FUNCTION 6070 ; VA 0x005f72a0 ; FUN_005f72a0 */

undefined4 __thiscall FUN_005f72a0(short *param_1,short *param_2)

{
  short sVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  bool bVar5;
  
  sVar1 = *param_1;
  if (DAT_01d5b1e4 == '\0') {
    if ((sVar1 == 2) && (*(int *)(param_1 + 2) == *(int *)(param_2 + 2))) {
      return 1;
    }
  }
  else if (sVar1 == *param_2) {
    if (sVar1 == 2) {
      if (*(int *)(param_1 + 2) == *(int *)(param_2 + 2)) {
        return 1;
      }
    }
    else if (sVar1 == 0x17) {
      piVar3 = (int *)(param_2 + 4);
      uVar4 = 0xc;
      piVar2 = (int *)(param_1 + 4);
      do {
        if (*piVar2 != *piVar3) {
          return 0;
        }
        piVar2 = piVar2 + 1;
        piVar3 = piVar3 + 1;
        bVar5 = 3 < uVar4;
        uVar4 = uVar4 - 4;
      } while (bVar5);
      return 1;
    }
    return 0;
  }
  return 0;
}



/* FUNCTION 6071 ; VA 0x005f7320 ; FUN_005f7320 */

void __thiscall FUN_005f7320(short *param_1,short *param_2)

{
  byte bVar1;
  char cVar2;
  int iVar3;
  byte *pbVar4;
  uint uVar5;
  char *pcVar6;
  byte *pbVar7;
  bool bVar8;
  undefined4 uVar9;
  byte abStack_418 [1028];
  char acStack_14 [16];
  
  acStack_14[0] = '\0';
  acStack_14[1] = '\0';
  acStack_14[2] = '\0';
  acStack_14[3] = '\0';
  acStack_14[4] = '\0';
  acStack_14[5] = '\0';
  acStack_14[6] = '\0';
  acStack_14[7] = '\0';
  acStack_14[8] = '\0';
  acStack_14[9] = '\0';
  acStack_14[10] = '\0';
  acStack_14[0xb] = '\0';
  acStack_14[0xc] = '\0';
  acStack_14[0xd] = '\0';
  acStack_14[0xe] = '\0';
  acStack_14[0xf] = '\0';
  cVar2 = FUN_005f71d0(&DAT_01d59c3c);
  if (cVar2 == '\0') {
    pcVar6 = acStack_14;
    do {
      cVar2 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    iVar3 = 0x401 - ((int)pcVar6 - (int)(acStack_14 + 1));
    if (-1 < iVar3) {
      if (*param_1 == 2) {
        uVar9 = 0x10;
      }
      else {
        uVar9 = 0x1c;
      }
      iVar3 = getnameinfo(param_1,uVar9,abStack_418,iVar3,0,0,2);
      if (iVar3 == 0) goto LAB_005f73a0;
    }
    abStack_418[0] = 0;
  }
  else {
    FUN_0171dd10(abStack_418,"UNASSIGNED_SYSTEM_ADDRESS",0x401);
  }
LAB_005f73a0:
  pbVar4 = abStack_418;
  pbVar7 = PTR_DAT_01d59c34;
  do {
    bVar1 = *pbVar4;
    bVar8 = bVar1 < *pbVar7;
    if (bVar1 != *pbVar7) {
LAB_005f73d0:
      uVar5 = -(uint)bVar8 | 1;
      goto LAB_005f73d5;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar4[1];
    bVar8 = bVar1 < pbVar7[1];
    if (bVar1 != pbVar7[1]) goto LAB_005f73d0;
    pbVar4 = pbVar4 + 2;
    pbVar7 = pbVar7 + 2;
  } while (bVar1 != 0);
  uVar5 = 0;
LAB_005f73d5:
  if (uVar5 == 0) {
    if (DAT_01d5b1e4 == '\0') {
      if (*param_2 != 2) {
        return;
      }
    }
    else if (*param_2 != 2) {
      return;
    }
    FUN_005f7480(PTR_DAT_01d59c38,0,4);
    return;
  }
  pbVar4 = abStack_418;
  pbVar7 = PTR_DAT_01d59c38;
  do {
    bVar1 = *pbVar4;
    bVar8 = bVar1 < *pbVar7;
    if (bVar1 != *pbVar7) {
LAB_005f7440:
      uVar5 = -(uint)bVar8 | 1;
      goto LAB_005f7445;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar4[1];
    bVar8 = bVar1 < pbVar7[1];
    if (bVar1 != pbVar7[1]) goto LAB_005f7440;
    pbVar4 = pbVar4 + 2;
    pbVar7 = pbVar7 + 2;
  } while (bVar1 != 0);
  uVar5 = 0;
LAB_005f7445:
  if (((uVar5 == 0) && (DAT_01d5b1e4 != '\0')) && (*param_2 != 2)) {
    FUN_005f7480(PTR_DAT_01d59c34,0,6);
  }
  return;
}



/* FUNCTION 6072 ; VA 0x005f7480 ; FUN_005f7480 */

undefined4 __thiscall FUN_005f7480(undefined4 *param_1,char *param_2,undefined4 param_3,int param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  undefined2 uVar5;
  char *pcVar6;
  undefined4 uVar7;
  uint uVar8;
  int iVar9;
  char *pcVar10;
  char acStack_88 [68];
  char acStack_44 [32];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  pcVar10 = param_2;
  if (DAT_01d5b1e4 == '\0') {
    FUN_005f78c0(param_2,param_3);
    return 1;
  }
  if (param_2 == (char *)0x0) {
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    *(undefined8 *)(param_1 + 4) = 0;
    param_1[6] = 0;
    *(undefined2 *)param_1 = 2;
    return 1;
  }
  if (DAT_01d59c70 == '\0') {
    iVar9 = 0;
    cVar4 = FUN_005f7880(param_2);
    if (cVar4 == '\0') {
      do {
        cVar4 = pcVar10[iVar9];
        if (((cVar4 == '\0') || (cVar4 == (char)param_3)) ||
           (((((cVar4 < '0' || ('9' < cVar4)) && ((cVar4 < 'a' || ('f' < cVar4)))) &&
             ((cVar4 < 'A' || ('F' < cVar4)))) &&
            ((((cVar4 != '.' && (cVar4 != ':')) && (cVar4 != '%')) &&
             ((cVar4 != '-' && (cVar4 != '/')))))))) break;
        acStack_88[iVar9] = cVar4;
        iVar9 = iVar9 + 1;
      } while (iVar9 < 0x41);
      acStack_88[iVar9] = '\0';
    }
    else {
      FUN_0171dd10(acStack_88,pcVar10,0x41);
      acStack_88[0x40] = 0;
    }
    uVar8 = 0;
    if ((pcVar10[iVar9] == (char)param_3) && ((char)param_3 != '\0')) {
      pcVar6 = pcVar10 + iVar9 + 1;
      do {
        if (*pcVar6 == '\0') break;
        acStack_44[uVar8] = *pcVar6;
        if (pcVar6[1] == '\0') {
          uVar8 = uVar8 + 1;
          break;
        }
        acStack_44[uVar8 + 1] = pcVar6[1];
        if (pcVar6[2] == '\0') {
          uVar8 = uVar8 + 2;
          break;
        }
        acStack_44[uVar8 + 2] = pcVar6[2];
        if (pcVar6[3] == '\0') {
          uVar8 = uVar8 + 3;
          break;
        }
        acStack_44[uVar8 + 3] = pcVar6[3];
        pcVar6 = pcVar6 + 4;
        uVar8 = uVar8 + 4;
      } while (uVar8 < 0x20);
    }
    acStack_44[uVar8] = '\0';
  }
  FUN_006945d0();
  uVar5 = *(undefined2 *)((int)param_1 + 2);
  uStack_24 = 0;
  uStack_18 = 0;
  param_2 = (char *)0x0;
  uStack_14 = 0;
  uStack_10 = 0;
  uStack_c = 0;
  uStack_8 = 0;
  uStack_1c = 2;
  if (DAT_01d5b1e4 == '\0') {
    if (param_4 == 6) {
      uStack_20 = 0x17;
    }
    else {
      uStack_20 = 0;
      if (param_4 == 4) {
        uStack_20 = 2;
      }
    }
    if (DAT_01d59c70 == '\0') {
      pcVar10 = acStack_88;
    }
    getaddrinfo(pcVar10,&DAT_018bc9b8,&uStack_24,&param_2);
    if (param_2 == (char *)0x0) {
      return 0;
    }
    if (*(int *)((int)param_2 + 4) != 2) goto LAB_005f76cb;
  }
  else {
    uStack_24 = 0xc00;
    uStack_20 = 0;
    if (DAT_01d59c70 == '\0') {
      pcVar10 = acStack_88;
    }
    iVar9 = getaddrinfo(pcVar10,&DAT_018bc9b8,&uStack_24,&param_2);
    if ((iVar9 != 0) || (param_2 == (char *)0x0)) {
      return 0;
    }
    if (*(int *)((int)param_2 + 4) != 2) {
LAB_005f76cb:
      *(undefined2 *)param_1 = 0x17;
      puVar1 = *(undefined4 **)((int)param_2 + 0x18);
      uVar7 = puVar1[1];
      uVar2 = puVar1[2];
      uVar3 = puVar1[3];
      *param_1 = *puVar1;
      param_1[1] = uVar7;
      param_1[2] = uVar2;
      param_1[3] = uVar3;
      *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar1 + 4);
      param_1[6] = puVar1[6];
      goto LAB_005f76ec;
    }
    if (param_4 == 6) {
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
      param_1[3] = 0;
      *(undefined8 *)(param_1 + 4) = 0;
      param_1[6] = 0;
      *(undefined2 *)param_1 = 0x17;
      param_1[5] = *(undefined4 *)(*(int *)((int)param_2 + 0x18) + 4);
      goto LAB_005f76ec;
    }
  }
  *(undefined2 *)param_1 = 2;
  puVar1 = *(undefined4 **)((int)param_2 + 0x18);
  uVar7 = puVar1[1];
  uVar2 = puVar1[2];
  uVar3 = puVar1[3];
  *param_1 = *puVar1;
  param_1[1] = uVar7;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
LAB_005f76ec:
  freeaddrinfo(param_2);
  FUN_00694600();
  if ((DAT_01d59c70 == '\0') && (acStack_44[0] != '\0')) {
    uVar7 = FUN_01717832(acStack_44);
    uVar7 = Ordinal_9(uVar7);
    *(short *)((int)param_1 + 2) = (short)uVar7;
    uVar5 = Ordinal_15(uVar7);
    *(undefined2 *)(param_1 + 7) = uVar5;
    return 1;
  }
  *(undefined2 *)((int)param_1 + 2) = uVar5;
  return 1;
}



/* FUNCTION 6073 ; VA 0x005f7750 ; FUN_005f7750 */

undefined __thiscall
FUN_005f7750(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  
  cVar1 = FUN_005f7480(param_2,0,param_4);
  if (cVar1 == '\0') {
    return 0;
  }
  uVar3 = Ordinal_9(param_3);
  *(short *)(param_1 + 2) = (short)uVar3;
  uVar2 = Ordinal_15(uVar3);
  *(undefined2 *)(param_1 + 0x1c) = uVar2;
  return 1;
}



/* FUNCTION 6074 ; VA 0x005f7790 ; FUN_005f7790 */

undefined4 __fastcall FUN_005f7790(int param_1)

{
  return *(undefined4 *)(param_1 + 4);
}



/* FUNCTION 6075 ; VA 0x005f77a0 ; FUN_005f77a0 */

undefined4 __fastcall FUN_005f77a0(short *param_1)

{
  if ((DAT_01d5b1e4 != '\0') && (*param_1 != 2)) {
    return 0x29;
  }
  return 0;
}



/* FUNCTION 6076 ; VA 0x005f77c0 ; FUN_005f77c0 */

undefined4 __fastcall FUN_005f77c0(short *param_1)

{
  uint3 uVar1;
  
  uVar1 = (uint3)(byte)((ushort)*param_1 >> 8);
  if (*param_1 != 2) {
    return CONCAT31(uVar1,6);
  }
  return CONCAT31(uVar1,4);
}



/* FUNCTION 6077 ; VA 0x005f77e0 ; FUN_005f77e0 */

undefined4 __fastcall FUN_005f77e0(short *param_1)

{
  char cVar1;
  
  if (*param_1 == 2) {
    return *(undefined4 *)(param_1 + 2);
  }
  if (*param_1 == 0x17) {
    cVar1 = FUN_005f7830();
    if (cVar1 != '\0') {
      return *(undefined4 *)(param_1 + 10);
    }
  }
  return 0;
}



/* FUNCTION 6078 ; VA 0x005f7810 ; FUN_005f7810 */

void __fastcall FUN_005f7810(int param_1)

{
  Ordinal_15(*(undefined2 *)(param_1 + 2));
  return;
}



/* FUNCTION 6079 ; VA 0x005f7820 ; FUN_005f7820 */

undefined2 __fastcall FUN_005f7820(int param_1)

{
  return *(undefined2 *)(param_1 + 2);
}



/* FUNCTION 6080 ; VA 0x005f7830 ; FUN_005f7830 */

undefined __fastcall FUN_005f7830(int param_1)

{
  if (((((*(char *)(param_1 + 8) == '\0') && (*(char *)(param_1 + 9) == '\0')) &&
       (*(char *)(param_1 + 10) == '\0')) &&
      ((((*(char *)(param_1 + 0xb) == '\0' && (*(char *)(param_1 + 0xc) == '\0')) &&
        ((*(char *)(param_1 + 0xd) == '\0' &&
         ((*(char *)(param_1 + 0xe) == '\0' && (*(char *)(param_1 + 0xf) == '\0')))))) &&
       (*(char *)(param_1 + 0x10) == '\0')))) &&
     (((*(char *)(param_1 + 0x11) == '\0' && (*(char *)(param_1 + 0x12) == -1)) &&
      (*(char *)(param_1 + 0x13) == -1)))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 6081 ; VA 0x005f7880 ; FUN_005f7880 */

uint __fastcall FUN_005f7880(undefined4 param_1,undefined4 param_2,char *param_3)

{
  uint uVar1;
  
  uVar1 = CONCAT31((int3)((uint)param_2 >> 8),*param_3) - 0x30;
  if ((9 < (byte)uVar1) &&
     ((*param_3 != '-' ||
      (uVar1 = CONCAT31((int3)(uVar1 >> 8),param_3[1] - 0x30U), 9 < (byte)(param_3[1] - 0x30U))))) {
    uVar1 = FUN_0170de40(param_3,&DAT_018c3838);
    if (uVar1 == 0) {
      return 1;
    }
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 6082 ; VA 0x005f78c0 ; FUN_005f78c0 */

void __thiscall FUN_005f78c0(int param_1,char *param_2,undefined param_3)

{
  char *pcVar1;
  undefined2 uVar2;
  undefined2 uVar3;
  int iVar4;
  undefined4 uVar5;
  char cVar6;
  uint uVar7;
  int iVar8;
  char *pcVar9;
  char acStack_2c [24];
  char acStack_14 [12];
  int iStack_8;
  
  iStack_8 = param_1;
  if (((byte)(*param_2 - 0x30U) < 10) ||
     (((*param_2 == '-' && ((byte)(param_2[1] - 0x30U) < 10)) ||
      (iVar4 = FUN_0170de40(param_2,&DAT_018c3838), iVar4 != 0)))) {
    iVar4 = 0;
    if (*param_2 != '\0') {
      uVar7 = (uint)CONCAT11(param_3,*param_2);
      pcVar9 = param_2;
      do {
        cVar6 = (char)uVar7;
        if (((cVar6 == (char)(uVar7 >> 8)) || (0x15 < iVar4)) ||
           ((cVar6 != '.' && (9 < (byte)(cVar6 - 0x30U))))) break;
        pcVar9[(int)(acStack_2c + -(int)param_2)] = cVar6;
        iVar4 = iVar4 + 1;
        pcVar1 = pcVar9 + 1;
        uVar7 = CONCAT31((int3)(uVar7 >> 8),*pcVar1);
        pcVar9 = pcVar9 + 1;
      } while (*pcVar1 != '\0');
    }
    cVar6 = param_2[iVar4];
    acStack_2c[iVar4] = '\0';
    acStack_14[0] = '\0';
    if ((cVar6 != '\0') && (param_2[iVar4 + 1] != '\0')) {
      iVar8 = 0;
      do {
        iVar4 = iVar4 + 1;
        cVar6 = param_2[iVar4];
        if (((cVar6 == '\0') || (0x1f < iVar4)) || (9 < (byte)(cVar6 - 0x30U))) break;
        acStack_14[iVar8] = cVar6;
        iVar8 = iVar8 + 1;
      } while (iVar8 < 10);
      acStack_14[iVar8] = '\0';
      param_1 = iStack_8;
    }
    if (acStack_2c[0] != '\0') {
      uVar5 = Ordinal_11(acStack_2c);
      *(undefined4 *)(param_1 + 4) = uVar5;
    }
    if (acStack_14[0] != '\0') {
      uVar5 = FUN_01717832(acStack_14);
      uVar5 = Ordinal_9(uVar5);
      *(short *)(param_1 + 2) = (short)uVar5;
      uVar2 = Ordinal_15(uVar5);
      *(undefined2 *)(param_1 + 0x1c) = uVar2;
    }
  }
  else {
    iVar4 = FUN_01717b91(param_2,&DAT_018bfc3c,9);
    if (iVar4 == 0) {
      uVar5 = Ordinal_11(&DAT_018c92b8);
      *(undefined4 *)(param_1 + 4) = uVar5;
      if (param_2[9] != '\0') {
        uVar2 = FUN_01717832(param_2 + 9);
        uVar3 = Ordinal_9(uVar2);
        *(undefined2 *)(param_1 + 0x1c) = uVar2;
        *(undefined2 *)(param_1 + 2) = uVar3;
        return;
      }
    }
    else {
      iVar4 = FUN_00694af0(param_2);
      if (iVar4 != 0) {
        uVar5 = Ordinal_11(iVar4);
        *(undefined4 *)(param_1 + 4) = uVar5;
        return;
      }
    }
  }
  return;
}



/* FUNCTION 6083 ; VA 0x005f7a40 ; FUN_005f7a40 */

void __thiscall FUN_005f7a40(int param_1,undefined4 param_2)

{
  undefined2 uVar1;
  
  *(short *)(param_1 + 2) = (short)param_2;
  uVar1 = Ordinal_15(param_2);
  *(undefined2 *)(param_1 + 0x1c) = uVar1;
  return;
}



/* FUNCTION 6084 ; VA 0x005f7a60 ; FUN_005f7a60 */

void FUN_005f7a60(char param_1)

{
  if (param_1 == '\x04') {
    FUN_005f7480(PTR_DAT_01d59c38,0,4);
    return;
  }
  FUN_005f7480(PTR_DAT_01d59c34,0,param_1);
  return;
}



/* FUNCTION 6085 ; VA 0x005f7a90 ; FUN_005f7a90 */

void FUN_005f7a90(short *param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_006958c0(param_1 + 1,2,2);
  if ((DAT_01d5b1e4 != '\0') && (*param_1 != 2)) {
    FUN_006958c0(param_1 + 4,0x10,uVar1);
    return;
  }
  FUN_006958c0(param_1 + 2,4,uVar1);
  return;
}



/* FUNCTION 6086 ; VA 0x005f7ae0 ; FUN_005f7ae0 */

undefined * FUN_005f7ae0(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  
  uVar1 = (uint)DAT_01eaad88;
  DAT_01eaad88 = DAT_01eaad88 + 1;
  FUN_005f7b20(param_1,&DAT_01eaad90 + (uVar1 & 7) * 0x401,0x401,param_2);
  return &DAT_01eaad90 + (uVar1 & 7) * 0x401;
}



/* FUNCTION 6087 ; VA 0x005f7b20 ; FUN_005f7b20 */

void __thiscall
FUN_005f7b20(short *param_1,char param_2,undefined *param_3,int param_4,undefined param_5)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  char *pcVar7;
  undefined4 uVar8;
  char acStack_14 [16];
  
  acStack_14[0] = '\0';
  acStack_14[1] = '\0';
  acStack_14[2] = '\0';
  acStack_14[3] = '\0';
  acStack_14[4] = '\0';
  acStack_14[5] = '\0';
  acStack_14[6] = '\0';
  acStack_14[7] = '\0';
  acStack_14[8] = '\0';
  acStack_14[9] = '\0';
  acStack_14[10] = '\0';
  acStack_14[0xb] = '\0';
  acStack_14[0xc] = '\0';
  acStack_14[0xd] = '\0';
  acStack_14[0xe] = '\0';
  acStack_14[0xf] = '\0';
  if (0 < param_4) {
    cVar1 = FUN_005f71d0(&DAT_01d59c3c);
    if (cVar1 == '\0') {
      if (param_2 != '\0') {
        acStack_14[0] = param_5;
        uVar2 = Ordinal_15(param_1[1],acStack_14 + 1,10);
        FUN_00694630(uVar2);
      }
      pcVar4 = acStack_14;
      do {
        cVar1 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar1 != '\0');
      param_4 = param_4 - ((int)pcVar4 - (int)(acStack_14 + 1));
      if (param_4 < 0) {
        *param_3 = 0;
        return;
      }
      if (*param_1 == 2) {
        uVar8 = 0x10;
      }
      else {
        uVar8 = 0x1c;
      }
      iVar3 = getnameinfo(param_1,uVar8,param_3,param_4,0,0,2);
      if (iVar3 != 0) {
        *param_3 = 0;
      }
      if (param_2 != '\0') {
        pcVar4 = acStack_14;
        do {
          cVar1 = *pcVar4;
          pcVar4 = pcVar4 + 1;
        } while (cVar1 != '\0');
        uVar6 = (int)pcVar4 - (int)acStack_14;
        pcVar4 = param_3 + -1;
        do {
          pcVar7 = pcVar4 + 1;
          pcVar4 = pcVar4 + 1;
        } while (*pcVar7 != '\0');
        pcVar7 = acStack_14;
        for (uVar5 = uVar6 >> 2; uVar5 != 0; uVar5 = uVar5 - 1) {
          *(undefined4 *)pcVar4 = *(undefined4 *)pcVar7;
          pcVar7 = pcVar7 + 4;
          pcVar4 = pcVar4 + 4;
        }
        for (uVar6 = uVar6 & 3; uVar6 != 0; uVar6 = uVar6 - 1) {
          *pcVar4 = *pcVar7;
          pcVar7 = pcVar7 + 1;
          pcVar4 = pcVar4 + 1;
        }
      }
    }
    else {
      FUN_0171dd10(param_3,"UNASSIGNED_SYSTEM_ADDRESS",param_4);
      if (param_4 < 0x1a) {
        param_3[param_4 + -1] = 0;
        return;
      }
    }
  }
  return;
}



/* FUNCTION 6088 ; VA 0x005f7c20 ; FUN_005f7c20 */

uint FUN_005f7c20(short *param_1)

{
  undefined *puVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  char *pcVar6;
  undefined4 uVar7;
  char acStack_14 [16];
  
  acStack_14[0] = '\0';
  acStack_14[1] = '\0';
  acStack_14[2] = '\0';
  acStack_14[3] = '\0';
  acStack_14[4] = '\0';
  acStack_14[5] = '\0';
  acStack_14[6] = '\0';
  acStack_14[7] = '\0';
  acStack_14[8] = '\0';
  acStack_14[9] = '\0';
  acStack_14[10] = '\0';
  acStack_14[0xb] = '\0';
  acStack_14[0xc] = '\0';
  acStack_14[0xd] = '\0';
  acStack_14[0xe] = '\0';
  acStack_14[0xf] = '\0';
  puVar1 = &DAT_01eaad90 + (DAT_01eaad88 & 7) * 0x401;
  DAT_01eaad88 = DAT_01eaad88 + 1;
  cVar3 = FUN_005f71d0(&DAT_01d59c3c);
  if (cVar3 == '\0') {
    pcVar6 = acStack_14;
    do {
      cVar3 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar3 != '\0');
    iVar4 = 0x401 - ((int)pcVar6 - (int)(acStack_14 + 1));
    if (-1 < iVar4) {
      if (*param_1 == 2) {
        uVar7 = 0x10;
      }
      else {
        uVar7 = 0x1c;
      }
      iVar4 = getnameinfo(param_1,uVar7,puVar1,iVar4,0,0,2);
      if (iVar4 == 0) goto LAB_005f7cb4;
    }
    *puVar1 = 0;
  }
  else {
    FUN_0171dd10(puVar1,"UNASSIGNED_SYSTEM_ADDRESS",0x401);
  }
LAB_005f7cb4:
  iVar4 = Ordinal_11(puVar1);
  uVar2 = iVar4 + 0x9e3779b9;
  uVar5 = Ordinal_15(param_1[1]);
  return (uVar2 >> 2) + 0x9e3779b9 + (uVar5 & 0xffff) + uVar2 * 0x40 ^ uVar2;
}



/* FUNCTION 6089 ; VA 0x005f7cf0 ; FUN_005f7cf0 */

uint * FUN_005f7cf0(uint param_1)

{
  uint *puVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c7ad;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    return (uint *)0x0;
  }
  uVar2 = -(uint)((int)((ulonglong)param_1 * 8 >> 0x20) != 0) | (uint)((ulonglong)param_1 * 8);
  ExceptionList = &pvStack_10;
  puVar1 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar2) | uVar2 + 4);
  uStack_8 = 0;
  if (puVar1 != (uint *)0x0) {
    *puVar1 = param_1;
    FUN_016f4053(puVar1 + 1,8,param_1,FUN_0054eb90,_guard_check_icall);
    ExceptionList = pvStack_10;
    return puVar1 + 1;
  }
  ExceptionList = pvStack_10;
  return (uint *)0x0;
}



/* FUNCTION 6090 ; VA 0x005f7da0 ; FUN_005f7da0 */

int FUN_005f7da0(uint param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c7e1;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(-(uint)((int)((ulonglong)param_1 * 0x10 >> 0x20) != 0) |
                       (uint)((ulonglong)param_1 * 0x10));
  uStack_8 = 0;
  if (iVar1 != 0) {
    if (param_1 != 0) {
      do {
        FUN_005f8960();
        param_1 = param_1 - 1;
      } while (param_1 != 0);
    }
    ExceptionList = pvStack_10;
    return iVar1;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 6091 ; VA 0x005f7e40 ; FUN_005f7e40 */

uint * FUN_005f7e40(uint param_1)

{
  uint *puVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c81d;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    return (uint *)0x0;
  }
  uVar2 = -(uint)((int)((ulonglong)param_1 * 0x10 >> 0x20) != 0) | (uint)((ulonglong)param_1 * 0x10)
  ;
  ExceptionList = &pvStack_10;
  puVar1 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar2) | uVar2 + 4);
  uStack_8 = 0;
  if (puVar1 != (uint *)0x0) {
    *puVar1 = param_1;
    FUN_016f4053(puVar1 + 1,0x10,param_1,FUN_0054eb90,_guard_check_icall);
    ExceptionList = pvStack_10;
    return puVar1 + 1;
  }
  ExceptionList = pvStack_10;
  return (uint *)0x0;
}



/* FUNCTION 6092 ; VA 0x005f7ef0 ; FUN_005f7ef0 */

uint FUN_005f7ef0(uint *param_1,uint *param_2)

{
  if (*param_1 < *param_2) {
    return 0xffffffff;
  }
  return (uint)(*param_1 != *param_2);
}



/* FUNCTION 6093 ; VA 0x005f7f10 ; FUN_005f7f10 */

undefined4 FUN_005f7f10(undefined4 param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  cVar1 = FUN_005fda50();
  if (cVar1 != '\0') {
    uVar2 = FUN_006a5ae0(param_1,0x10,1);
    return uVar2;
  }
  cVar1 = FUN_006a5ae0(auStack_8,0x10,1);
  if (cVar1 != '\0') {
    FUN_006a5c10(auStack_8,param_1,2);
    return 1;
  }
  return 0;
}



/* FUNCTION 6094 ; VA 0x005f7f70 ; FUN_005f7f70 */

undefined4 FUN_005f7f70(undefined4 param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  cVar1 = FUN_005fda50();
  if (cVar1 != '\0') {
    uVar2 = FUN_006a5ae0(param_1,0x20,1);
    return uVar2;
  }
  cVar1 = FUN_006a5ae0(auStack_8,0x20,1);
  if (cVar1 != '\0') {
    FUN_006a5c10(auStack_8,param_1,4);
    return 1;
  }
  return 0;
}



/* FUNCTION 6095 ; VA 0x005f7fd0 ; FUN_005f7fd0 */

uint __thiscall FUN_005f7fd0(int param_1,undefined *param_2)

{
  undefined uVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x10) - (*(int *)(param_1 + 0x10) - 1U & 7);
  *(int *)(param_1 + 0x10) = iVar4 + 7;
  uVar3 = iVar4 + 0x1f;
  if (*(uint *)(param_1 + 8) < uVar3) {
    return uVar3 & 0xffffff00;
  }
  cVar2 = FUN_005fda50();
  uVar1 = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + *(int *)(param_1 + 0x14));
  if (cVar2 == '\0') {
    *param_2 = uVar1;
    param_2[1] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + 1 + *(int *)(param_1 + 0x14));
    iVar4 = *(int *)(param_1 + 0x14);
    param_2[2] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + 2 + iVar4);
    param_2[3] = 0;
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x18;
    return CONCAT31((int3)((uint)iVar4 >> 8),1);
  }
  param_2[3] = uVar1;
  param_2[2] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + 1 + *(int *)(param_1 + 0x14));
  iVar4 = *(int *)(param_1 + 0x14);
  param_2[1] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + 2 + iVar4);
  *param_2 = 0;
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x18;
  return CONCAT31((int3)((uint)iVar4 >> 8),1);
}



/* FUNCTION 6096 ; VA 0x005f8080 ; FUN_005f8080 */

void FUN_005f8080(undefined4 param_1)

{
  char cVar1;
  undefined auStack_8 [4];
  
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    FUN_006a5c10(param_1,auStack_8,2);
    FUN_006a6060(auStack_8,0x10,1);
    return;
  }
  FUN_006a6060(param_1,0x10,1);
  return;
}



/* FUNCTION 6097 ; VA 0x005f80d0 ; FUN_005f80d0 */

void FUN_005f80d0(undefined4 param_1)

{
  char cVar1;
  undefined auStack_8 [4];
  
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    FUN_006a5c10(param_1,auStack_8,4);
    FUN_006a6060(auStack_8,0x20,1);
    return;
  }
  FUN_006a6060(param_1,0x20,1);
  return;
}



/* FUNCTION 6098 ; VA 0x005f8120 ; FUN_005f8120 */

void __thiscall FUN_005f8120(int param_1,undefined *param_2)

{
  char cVar1;
  undefined uVar2;
  undefined *puVar3;
  
  *(uint *)(param_1 + 8) = (*(int *)(param_1 + 8) - (*(int *)(param_1 + 8) - 1U & 7)) + 7;
  FUN_006a5700(0x18);
  cVar1 = FUN_005fda50();
  puVar3 = (undefined *)((*(uint *)(param_1 + 8) >> 3) + *(int *)(param_1 + 0x14));
  if (cVar1 == '\0') {
    *puVar3 = *param_2;
    *(undefined *)((*(uint *)(param_1 + 8) >> 3) + 1 + *(int *)(param_1 + 0x14)) = param_2[1];
    uVar2 = param_2[2];
  }
  else {
    *puVar3 = param_2[3];
    *(undefined *)((*(uint *)(param_1 + 8) >> 3) + 1 + *(int *)(param_1 + 0x14)) = param_2[2];
    uVar2 = param_2[1];
  }
  *(undefined *)((*(uint *)(param_1 + 8) >> 3) + 2 + *(int *)(param_1 + 0x14)) = uVar2;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 0x18;
  return;
}



/* FUNCTION 6099 ; VA 0x005f81a0 ; FUN_005f81a0 */

void FUN_005f81a0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_00601de0();
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *(undefined4 *)*param_2;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  return;
}



/* FUNCTION 6100 ; VA 0x005f81d0 ; FUN_005f81d0 */

void FUN_005f81d0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  
  uVar4 = 0;
  uVar2 = (uint)((int)param_2 + (3 - (int)param_1)) >> 2;
  if (param_2 < param_1) {
    uVar2 = 0;
  }
  if (uVar2 != 0) {
    puVar5 = param_1;
    if (3 < uVar2) {
      uVar1 = *param_3;
      if ((param_3 < param_1) || (param_1 + (uVar2 - 1) < param_3)) {
        do {
          uVar4 = uVar4 + 4;
        } while (uVar4 != (uVar2 & 0xfffffffc));
        puVar5 = param_1 + (uVar2 & 0xfffffffc);
        for (uVar3 = uVar2 & 0x3ffffffc; uVar3 != 0; uVar3 = uVar3 - 1) {
          *param_1 = uVar1;
          param_1 = param_1 + 1;
        }
      }
    }
    for (; uVar4 != uVar2; uVar4 = uVar4 + 1) {
      *puVar5 = *param_3;
      puVar5 = puVar5 + 1;
    }
  }
  return;
}



/* FUNCTION 6101 ; VA 0x005f8250 ; FUN_005f8250 */

void __thiscall
FUN_005f8250(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0xaaaaaa8 < (uint)param_1[1]) {
    FUN_005f0c20(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_005f8302:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_005f8302;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 6102 ; VA 0x005f83b0 ; FUN_005f83b0 */

undefined4 * __thiscall
FUN_005f83b0(undefined4 *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  undefined *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  bool bVar4;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c830;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_005f8250(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar2 = (int *)*param_1;
  if (param_3 == (int *)*piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_005f8250(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(uint *)(piVar2[2] + 0x10) < *param_4) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_005f8250(param_2,0,piVar2[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    bVar4 = (uint)param_3[4] < *param_4;
    ExceptionList = &pvStack_10;
    puVar1 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar2 = (int *)FUN_0056f560();
      if (*(uint *)(*piVar2 + 0x10) < *param_4) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_005f8250(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_005f8250(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar4 = (uint)param_3[4] < *param_4;
      puVar1 = puStack_14;
    }
    puStack_14 = puVar1;
    if (bVar4) {
      piStack_18 = param_3;
      FUN_00551320();
      if ((piStack_18 == (int *)*param_1) || (*param_4 < (uint)piStack_18[4])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_005f8250(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_005f8250(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)FUN_005f85b0(auStack_20,0,param_4,param_5);
  *param_2 = *puVar3;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6103 ; VA 0x005f859b ; Catch_All@005f859b */

void Catch_All_005f859b(void)

{
  int unaff_EBP;
  
  FUN_005f0c20(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6104 ; VA 0x005f85b0 ; FUN_005f85b0 */

void __thiscall
FUN_005f85b0(int *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  uint *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  bool bVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = param_4;
  puStack_c = &LAB_0179c840;
  pvStack_10 = ExceptionList;
  bVar4 = true;
  puVar3 = (undefined4 *)*param_1;
  uStack_8 = 0;
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    puVar2 = (undefined4 *)puVar3[1];
    do {
      puVar3 = puVar2;
      if (param_3 == '\0') {
        bVar4 = *param_4 < (uint)puVar3[4];
      }
      else {
        bVar4 = *param_4 <= (uint)puVar3[4];
      }
      if (bVar4 == false) {
        puVar2 = (undefined4 *)puVar3[2];
      }
      else {
        puVar2 = (undefined4 *)*puVar3;
      }
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  _param_3 = puVar3;
  if (bVar4 != false) {
    if (puVar3 == *(undefined4 **)*param_1) {
      bVar4 = true;
      ExceptionList = &pvStack_10;
      goto LAB_005f8634;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  puVar2 = _param_3;
  if (*puVar1 <= (uint)_param_3[4]) {
    FUN_01674ea0(param_5,0x18);
    *param_2 = puVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_005f8634:
  puVar3 = (undefined4 *)FUN_005f8250(&param_3,bVar4,puVar3,puVar1,param_5);
  *param_2 = *puVar3;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6105 ; VA 0x005f86a3 ; Catch_All@005f86a3 */

void Catch_All_005f86a3(void)

{
  int unaff_EBP;
  
  FUN_005f0c20(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6106 ; VA 0x005f86c0 ; FUN_005f86c0 */

void __thiscall FUN_005f86c0(int *param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uStack_c;
  
  uVar2 = param_2;
  iVar1 = param_1[1];
  iVar3 = *param_1;
  uVar4 = iVar1 - iVar3 >> 2;
  uStack_c = param_1[2] - iVar3 >> 2;
  if (param_2 <= uStack_c) {
    if (param_2 <= uVar4) {
      if (param_2 != uVar4) {
        param_1[1] = iVar3 + param_2 * 4;
      }
      return;
    }
    iVar3 = (param_2 - uVar4) * 4;
    FUN_0170d1f0(iVar1,0,iVar3);
    param_1[1] = iVar1 + iVar3;
    return;
  }
  if (0x3fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x3fffffff - (uStack_c >> 1) < uStack_c) {
    uStack_c = param_2;
  }
  else {
    uStack_c = (uStack_c >> 1) + uStack_c;
    if (uStack_c < param_2) {
      uStack_c = param_2;
    }
  }
  iVar3 = FUN_00577ed0(uStack_c);
  FUN_0170d1f0(iVar3 + uVar4 * 4,0,(uVar2 - uVar4) * 4);
  iVar1 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(iVar3,iVar1,param_1[1] - iVar1);
  FUN_00601e00(iVar3,uVar2,uStack_c);
  return;
}



/* FUNCTION 6107 ; VA 0x005f87c0 ; FUN_005f87c0 */

void __thiscall FUN_005f87c0(int *param_1,uint param_2,undefined4 param_3,undefined4 *param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uStack_8;
  
  uVar1 = param_2;
  puVar4 = (undefined4 *)param_1[1];
  iVar3 = *param_1;
  uVar5 = (int)puVar4 - iVar3 >> 2;
  uStack_8 = param_1[2] - iVar3 >> 2;
  if (param_2 <= uStack_8) {
    if (uVar5 < param_2) {
      for (iVar3 = param_2 - uVar5; iVar3 != 0; iVar3 = iVar3 + -1) {
        *puVar4 = *param_4;
        puVar4 = puVar4 + 1;
      }
      param_1[1] = (int)puVar4;
      return;
    }
    if (param_2 != uVar5) {
      param_1[1] = iVar3 + param_2 * 4;
    }
    return;
  }
  if (param_2 < 0x40000000) {
    if (0x3fffffff - (uStack_8 >> 1) < uStack_8) {
      uStack_8 = param_2;
    }
    else {
      uStack_8 = (uStack_8 >> 1) + uStack_8;
      if (uStack_8 < param_2) {
        uStack_8 = param_2;
      }
    }
    iVar2 = FUN_00577ed0(uStack_8);
    iVar3 = uVar1 - uVar5;
    puVar4 = (undefined4 *)(iVar2 + uVar5 * 4);
    for (; iVar3 != 0; iVar3 = iVar3 + -1) {
      *puVar4 = *param_4;
      puVar4 = puVar4 + 1;
      uVar1 = param_2;
    }
    iVar3 = *param_1;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar2,iVar3,param_1[1] - iVar3);
    FUN_00601e00(iVar2,uVar1,uStack_8);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 6108 ; VA 0x005f88c0 ; FUN_005f88c0 */

undefined4 * __fastcall FUN_005f88c0(undefined4 *param_1)

{
  param_1[2] = 0;
  *param_1 = 0;
  param_1[1] = 0;
  *(undefined *)(param_1 + 3) = 0;
  return param_1;
}



/* FUNCTION 6109 ; VA 0x005f88f0 ; FUN_005f88f0 */

int __fastcall FUN_005f88f0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c85b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  uStack_8 = 0;
  FUN_005febe0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
               ,0xb6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6110 ; VA 0x005f8960 ; FUN_005f8960 */

undefined4 * __fastcall FUN_005f8960(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  return param_1;
}



/* FUNCTION 6111 ; VA 0x005f8980 ; FUN_005f8980 */

int __fastcall FUN_005f8980(int param_1)

{
  *(undefined4 *)(param_1 + 0x138) = 0;
  *(undefined4 *)(param_1 + 0x13c) = 0;
  *(undefined4 *)(param_1 + 0x140) = 0;
  *(undefined4 *)(param_1 + 0x144) = 0;
  *(undefined4 *)(param_1 + 0x148) = 0;
  *(undefined4 *)(param_1 + 0x14c) = 0;
  *(undefined4 *)(param_1 + 0x150) = 0;
  *(undefined4 *)(param_1 + 0x154) = 0;
  return param_1;
}



/* FUNCTION 6112 ; VA 0x005f89e0 ; FUN_005f89e0 */

undefined4 * __fastcall FUN_005f89e0(undefined4 *param_1)

{
  undefined uVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_0179c9b3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[5] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[0xd] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0x4000;
  param_1[0x16] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0x4000;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  uStack_8 = 6;
  uStack_7 = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  uVar2 = FUN_00601dc0();
  param_1[0x22] = uVar2;
  param_1[0x28] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  *(undefined *)(param_1 + 0x29) = 0;
  param_1[0x34] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x88] = 0;
  param_1[0x89] = 0;
  param_1[0x8a] = 0;
  param_1[0x8b] = 0;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0;
  param_1[0x8f] = 0;
  param_1[0x92] = 0;
  param_1[0x93] = 0;
  param_1[0x94] = 0;
  param_1[0x95] = 0;
  param_1[0x96] = 0;
  param_1[0x97] = 0;
  param_1[0x98] = 0;
  param_1[0x99] = 0;
  param_1[0x9a] = 0;
  param_1[0x9b] = 0;
  param_1[0x9c] = 0;
  param_1[0x9d] = 0;
  param_1[0x9e] = 0;
  param_1[0x9f] = 0;
  param_1[0xa0] = 0;
  param_1[0xa1] = 0;
  _uStack_8 = CONCAT31(uStack_7,9);
  param_1[0xa4] = 0;
  param_1[0xa5] = 0;
  param_1[0xa6] = 0;
  param_1[0xa7] = 0;
  iVar3 = 0x20;
  do {
    FUN_0054eb90();
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  iVar3 = 0x20;
  do {
    FUN_0054eb90();
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  iVar3 = 0x20;
  do {
    FUN_0054eb90();
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  iVar3 = 0x20;
  do {
    FUN_0054eb90();
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  FUN_016f4053(param_1 + 0x128,0x10,0x20,FUN_005f88c0,FUN_005f8f50);
  uStack_8 = 10;
  iVar3 = 0x20;
  do {
    FUN_0054eb90();
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  param_1[0x1cb] = 0;
  param_1[0x1c8] = 0;
  param_1[0x1c9] = 0;
  param_1[0x1ca] = 0;
  param_1[0x1f1] = 0;
  param_1[0x1ef] = 0;
  param_1[0x1f0] = 0;
  param_1[500] = 0;
  param_1[0x1f2] = 0;
  param_1[499] = 0;
  param_1[0x1f7] = 0;
  param_1[0x1f5] = 0;
  param_1[0x1f6] = 0;
  param_1[0x1fa] = 0;
  param_1[0x1f8] = 0;
  param_1[0x1f9] = 0;
  param_1[0x206] = 0;
  param_1[0x204] = 0;
  param_1[0x205] = 0;
  param_1[0x209] = 0;
  param_1[0x207] = 0;
  param_1[0x208] = 0;
  param_1[0x20c] = 0;
  param_1[0x20a] = 0;
  param_1[0x20b] = 0;
  param_1[0x210] = 0;
  param_1[0x211] = 0;
  param_1[0x212] = 0x4000;
  uStack_8 = 0x13;
  FUN_016f4053(param_1 + 0x214,0x20,7,FUN_005f88f0,FUN_005f90e0);
  uStack_8 = 0x14;
  uVar1 = uStack_8;
  uStack_8 = 0x14;
  if (DAT_01d59d10 == '\0') {
    uStack_8 = uVar1;
    iVar3 = FUN_01674e20(0x40);
    _uStack_8 = CONCAT31(uStack_7,0x16);
    if (iVar3 != 0) {
      uVar2 = FUN_006a69e0();
      goto LAB_005f8dee;
    }
  }
  else {
    iVar3 = FUN_01674e20(0x148);
    _uStack_8 = CONCAT31(uStack_7,0x15);
    if (iVar3 != 0) {
      uVar2 = FUN_006a7990();
      goto LAB_005f8dee;
    }
  }
  uVar2 = 0;
LAB_005f8dee:
  param_1[0x1ec] = uVar2;
  _uStack_8 = CONCAT31(uStack_7,0x14);
  FUN_005f86c0(DAT_01d59cbc,param_1 + 0x1d);
  param_1[0x38] = 10000;
  param_1[0x1e7] = 0;
  param_1[0x1e6] = 0;
  *(undefined8 *)(param_1 + 0x1e4) = 0;
  FUN_005fcce0();
  param_1[0x12] = 0x400;
  param_1[0x1c] = 0x740;
  param_1[0x212] = 0x100;
  param_1[0xa2] = 0;
  param_1[0xa3] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6113 ; VA 0x005f8e80 ; FUN_005f8e80 */

undefined4 * __thiscall FUN_005f8e80(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c9c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  uStack_8 = 0;
  *param_1 = RBX::network_stream_exception::vftable;
  FUN_0054ef60(param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6114 ; VA 0x005f8ef0 ; FUN_005f8ef0 */

undefined4 * __thiscall FUN_005f8ef0(undefined4 *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c9c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined8 *)(param_1 + 1) = 0;
  uStack_8 = 0;
  *param_1 = RBX::network_stream_exception::vftable;
  FUN_0054ef60(param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6115 ; VA 0x005f8f50 ; FUN_005f8f50 */

void __fastcall FUN_005f8f50(undefined4 *param_1)

{
  if (param_1[2] != 0) {
    FUN_01674ea0(*param_1);
  }
  return;
}



/* FUNCTION 6116 ; VA 0x005f8f60 ; FUN_005f8f60 */

void FUN_005f8f60(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005f9da0("c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_MemoryPool.h"
               ,0x51);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6117 ; VA 0x005f8fa0 ; FUN_005f8fa0 */

void __fastcall FUN_005f8fa0(undefined4 *param_1)

{
  if (param_1[2] != 0) {
    FUN_01674ea0(*param_1);
    param_1[2] = 0;
    *param_1 = 0;
    param_1[1] = 0;
  }
  return;
}



/* FUNCTION 6118 ; VA 0x005f8fd0 ; FUN_005f8fd0 */

void __fastcall FUN_005f8fd0(undefined4 *param_1)

{
  if (param_1[3] != 0) {
    FUN_01674ea0(*param_1);
  }
  return;
}



/* FUNCTION 6119 ; VA 0x005f8fe0 ; FUN_005f8fe0 */

void __fastcall FUN_005f8fe0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  if ((param_1[3] != 0) && (iVar1 = *param_1, iVar1 != 0)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(iVar1,0x10,*(undefined4 *)(iVar1 + -4),_guard_check_icall);
    FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 0x10 + 4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6120 ; VA 0x005f9040 ; FUN_005f9040 */

void __fastcall FUN_005f9040(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005f9e60();
  if (param_1[2] != 0) {
    iVar1 = *param_1;
    if (iVar1 != 0) {
      uStack_8 = 0;
      FUN_016f32d1(iVar1,8,*(undefined4 *)(iVar1 + -4),_guard_check_icall);
      FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 8 + 4);
    }
    param_1[2] = 0;
    *param_1 = 0;
    param_1[1] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6121 ; VA 0x005f90c0 ; FUN_005f90c0 */

void __fastcall FUN_005f90c0(undefined4 *param_1)

{
  FUN_00601ea0();
  FUN_01674ea0(*param_1,0x18);
  return;
}



/* FUNCTION 6122 ; VA 0x005f90e0 ; FUN_005f90e0 */

void __fastcall FUN_005f90e0(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  if ((*(int *)(param_1 + 0x1c) != 0) && (iVar1 = *(int *)(param_1 + 0x10), iVar1 != 0)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(iVar1,0x10,*(undefined4 *)(iVar1 + -4),_guard_check_icall);
    FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 0x10 + 4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6123 ; VA 0x005f9150 ; FUN_005f9150 */

int __fastcall FUN_005f9150(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005fa800();
  if (*(undefined4 **)(param_1 + 0x7b0) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x7b0))(1);
  }
  FUN_016f32d1(param_1 + 0x850,0x20,7,FUN_005f90e0);
  uStack_8 = 0;
  FUN_005f9da0("c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_MemoryPool.h"
               ,0x51);
  uStack_8 = 0xffffffff;
  FUN_005f9040();
  FUN_005f9040();
  FUN_005f9040();
  if (*(int *)(param_1 + 0x7e8) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x7e0));
  }
  if (*(int *)(param_1 + 0x7dc) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x7d4));
  }
  if (*(int *)(param_1 + 2000) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x7c8));
  }
  if (*(int *)(param_1 + 0x7c4) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x7bc));
  }
  if (*(int *)(param_1 + 0x72c) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x720));
  }
  FUN_016f32d1(param_1 + 0x4a0,0x10,0x20,FUN_005f8f50);
  if (*(int *)(param_1 + 0xd0) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 200));
    *(undefined4 *)(param_1 + 0xd0) = 0;
    *(undefined4 *)(param_1 + 200) = 0;
    *(undefined4 *)(param_1 + 0xcc) = 0;
  }
  if (*(int *)(param_1 + 0xa0) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x98));
  }
  FUN_00601ea0();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x88),0x18);
  iVar3 = *(int *)(param_1 + 0x74);
  if (iVar3 != 0) {
    uVar5 = (*(int *)(param_1 + 0x7c) - iVar3 >> 2) * 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x74) = 0;
    *(undefined4 *)(param_1 + 0x78) = 0;
    *(undefined4 *)(param_1 + 0x7c) = 0;
  }
  uStack_8 = 1;
  FUN_005f9da0("c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_MemoryPool.h"
               ,0x51);
  if (*(int *)(param_1 + 0x58) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x50));
  }
  uStack_8 = 2;
  iVar3 = FUN_005f9da0("c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_MemoryPool.h"
                       ,0x51);
  if (*(int *)(param_1 + 0x34) != 0) {
    iVar3 = FUN_01674ea0(*(undefined4 *)(param_1 + 0x28));
  }
  if (*(int *)(param_1 + 0x14) != 0) {
    iVar3 = FUN_01674ea0(*(undefined4 *)(param_1 + 8));
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar3 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar3 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 6124 ; VA 0x005f93c0 ; FUN_005f93c0 */

void __fastcall FUN_005f93c0(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::network_stream_exception::vftable;
  uVar1 = param_1[8];
  if (0xf < uVar1) {
    iVar2 = param_1[3];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[7] = 0;
  param_1[8] = 0xf;
  *(undefined *)(param_1 + 3) = 0;
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  return;
}



/* FUNCTION 6125 ; VA 0x005f9430 ; FUN_005f9430 */

int __thiscall FUN_005f9430(int *param_1,uint param_2)

{
  code *pcVar1;
  int iVar2;
  
  if (param_2 < (uint)(param_1[1] - *param_1 >> 2)) {
    return *param_1 + param_2 * 4;
  }
  FUN_00577c40();
  pcVar1 = (code *)swi(3);
  iVar2 = (*pcVar1)();
  return iVar2;
}



/* FUNCTION 6126 ; VA 0x005f9460 ; FUN_005f9460 */

int __thiscall FUN_005f9460(int param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x14);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x1c) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
  }
  if (*(int *)(param_1 + 0x10) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 8));
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  return param_1;
}



/* FUNCTION 6127 ; VA 0x005f94e0 ; FUN_005f94e0 */

undefined4 * __thiscall FUN_005f94e0(undefined4 *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::network_stream_exception::vftable;
  uVar1 = param_1[8];
  if (0xf < uVar1) {
    iVar2 = param_1[3];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[7] = 0;
  param_1[8] = 0xf;
  *(undefined *)(param_1 + 3) = 0;
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 6128 ; VA 0x005f9560 ; FUN_005f9560 */

int __thiscall FUN_005f9560(int param_1,uint param_2,uint param_3)

{
  int iVar1;
  uint3 uVar2;
  
  iVar1 = -(uint)(*(uint *)(param_1 + 0x94) < param_2) - param_3;
  uVar2 = (uint3)((uint)iVar1 >> 8);
  if (((iVar1 != 0) || (10000 < *(uint *)(param_1 + 0x94) - param_2)) &&
     ((param_3 != param_2 < *(uint *)(param_1 + 0x94) ||
      (*(uint *)(param_1 + 0xe0) < param_2 - *(uint *)(param_1 + 0x94))))) {
    return CONCAT31(uVar2,1);
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 6129 ; VA 0x005f95b0 ; FUN_005f95b0 */

void __thiscall FUN_005f95b0(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_2 + 0x1c);
  if (((iVar1 == 0) || (iVar1 == 1)) || (iVar1 == 5)) {
    if (*(int *)(param_1 + 0x84) == 0) {
      *(int *)(param_2 + 0x60) = param_2;
      *(int *)(param_2 + 0x5c) = param_2;
      *(int *)(param_1 + 0x84) = param_2;
      return;
    }
    *(int *)(param_2 + 0x60) = *(int *)(param_1 + 0x84);
    iVar1 = *(int *)(*(int *)(param_1 + 0x84) + 0x5c);
    *(int *)(param_2 + 0x5c) = iVar1;
    *(int *)(iVar1 + 0x60) = param_2;
    *(int *)(*(int *)(param_1 + 0x84) + 0x5c) = param_2;
  }
  return;
}



/* FUNCTION 6130 ; VA 0x005f9600 ; FUN_005f9600 */

void __thiscall
FUN_005f9600(int param_1,int param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  *(undefined4 *)(param_2 + 0x3c) = param_5;
  *(undefined4 *)(param_2 + 0x40) = 1;
  if (*param_3 != 0) {
    piVar1 = (int *)(*param_3 + 4);
    *piVar1 = *piVar1 + 1;
    *(int *)(param_2 + 0x44) = *param_3;
    return;
  }
  if (*(int *)(param_1 + 0x840) < 1) {
    piVar1 = (int *)FUN_01674f30(0x14);
    iVar5 = 0;
    *(int **)(param_1 + 0x838) = piVar1;
    if (piVar1 != (int *)0x0) {
      *(undefined4 *)(param_1 + 0x840) = 1;
      uVar2 = *(uint *)(param_1 + 0x848) / 0xc;
      iVar4 = FUN_01674f30(*(uint *)(param_1 + 0x848));
      piVar1[2] = iVar4;
      if (iVar4 != 0) {
        iVar3 = FUN_01674f30(uVar2 << 2);
        iVar4 = piVar1[2];
        *piVar1 = iVar3;
        if (iVar3 != 0) {
          if (uVar2 != 0) {
            do {
              *(int **)(iVar4 + 8) = piVar1;
              *(int *)(iVar3 + iVar5 * 4) = iVar4;
              iVar4 = iVar4 + 0xc;
              iVar5 = iVar5 + 1;
            } while (iVar5 < (int)uVar2);
          }
          piVar1[1] = uVar2;
          piVar1[3] = *(int *)(param_1 + 0x838);
          piVar1[4] = (int)piVar1;
          piVar1 = *(int **)(param_1 + 0x838);
          piVar1[1] = piVar1[1] + -1;
          iVar5 = *(int *)(*piVar1 + piVar1[1] * 4);
          goto LAB_005f972d;
        }
        FUN_01674ea0(iVar4);
      }
      iVar5 = 0;
    }
  }
  else {
    piVar1 = *(int **)(param_1 + 0x838);
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    iVar5 = *(int *)(*piVar1 + iVar4 * 4);
    if (iVar4 == 0) {
      *(int *)(param_1 + 0x840) = *(int *)(param_1 + 0x840) + -1;
      *(int *)(param_1 + 0x838) = piVar1[3];
      *(int *)(piVar1[3] + 0x10) = piVar1[4];
      *(int *)(piVar1[4] + 0xc) = piVar1[3];
      iVar4 = *(int *)(param_1 + 0x844);
      *(int *)(param_1 + 0x844) = iVar4 + 1;
      if (iVar4 == 0) {
        *(int **)(param_1 + 0x83c) = piVar1;
        piVar1[3] = (int)piVar1;
        piVar1[4] = (int)piVar1;
      }
      else {
        piVar1[3] = *(int *)(param_1 + 0x83c);
        piVar1[4] = *(int *)(*(int *)(param_1 + 0x83c) + 0x10);
        *(int **)(*(int *)(*(int *)(param_1 + 0x83c) + 0x10) + 0xc) = piVar1;
        *(int **)(*(int *)(param_1 + 0x83c) + 0x10) = piVar1;
      }
    }
  }
LAB_005f972d:
  *param_3 = iVar5;
  *(undefined4 *)(iVar5 + 4) = 1;
  *(undefined4 *)*param_3 = param_4;
  *(int *)(param_2 + 0x44) = *param_3;
  return;
}



/* FUNCTION 6131 ; VA 0x005f97b0 ; FUN_005f97b0 */

undefined4 __fastcall FUN_005f97b0(int *param_1)

{
  undefined4 uVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  if (param_1[2] < 1) {
    piVar2 = (int *)FUN_01674f30(0x14);
    *param_1 = (int)piVar2;
    if (piVar2 != (int *)0x0) {
      param_1[2] = 1;
      uVar3 = (uint)param_1[4] / 0xc;
      iVar6 = 0;
      iVar5 = FUN_01674f30(param_1[4]);
      piVar2[2] = iVar5;
      if (iVar5 != 0) {
        iVar4 = FUN_01674f30(uVar3 << 2);
        iVar5 = piVar2[2];
        *piVar2 = iVar4;
        if (iVar4 != 0) {
          if (uVar3 != 0) {
            do {
              *(int **)(iVar5 + 8) = piVar2;
              *(int *)(iVar4 + iVar6 * 4) = iVar5;
              iVar5 = iVar5 + 0xc;
              iVar6 = iVar6 + 1;
            } while (iVar6 < (int)uVar3);
          }
          piVar2[1] = uVar3;
          piVar2[3] = *param_1;
          piVar2[4] = (int)piVar2;
          param_1 = (int *)*param_1;
          param_1[1] = param_1[1] + -1;
          return *(undefined4 *)(*param_1 + param_1[1] * 4);
        }
        FUN_01674ea0(iVar5);
      }
    }
    return 0;
  }
  piVar2 = (int *)*param_1;
  iVar5 = piVar2[1] + -1;
  piVar2[1] = iVar5;
  uVar1 = *(undefined4 *)(*piVar2 + iVar5 * 4);
  if (iVar5 == 0) {
    param_1[2] = param_1[2] + -1;
    *param_1 = piVar2[3];
    *(int *)(piVar2[3] + 0x10) = piVar2[4];
    *(int *)(piVar2[4] + 0xc) = piVar2[3];
    iVar5 = param_1[3];
    param_1[3] = iVar5 + 1;
    if (iVar5 == 0) {
      param_1[1] = (int)piVar2;
      piVar2[3] = (int)piVar2;
      piVar2[4] = (int)piVar2;
      return uVar1;
    }
    piVar2[3] = param_1[1];
    piVar2[4] = *(int *)(param_1[1] + 0x10);
    *(int **)(*(int *)(param_1[1] + 0x10) + 0xc) = piVar2;
    *(int **)(param_1[1] + 0x10) = piVar2;
  }
  return uVar1;
}



/* FUNCTION 6132 ; VA 0x005f98f0 ; FUN_005f98f0 */

undefined4 * __fastcall FUN_005f98f0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  
  if (*(int *)(param_1 + 0x68) < 1) {
    piVar1 = (int *)FUN_01674f30(0x14);
    *(int **)(param_1 + 0x60) = piVar1;
    if (piVar1 != (int *)0x0) {
      *(undefined4 *)(param_1 + 0x68) = 1;
      uVar2 = *(uint *)(param_1 + 0x70) / 0xf0;
      iVar6 = 0;
      iVar4 = FUN_01674f30(*(uint *)(param_1 + 0x70));
      piVar1[2] = iVar4;
      if (iVar4 != 0) {
        iVar3 = FUN_01674f30(uVar2 << 2);
        iVar4 = piVar1[2];
        *piVar1 = iVar3;
        if (iVar3 != 0) {
          if (uVar2 != 0) {
            do {
              *(int **)(iVar4 + 0xe8) = piVar1;
              *(int *)(iVar3 + iVar6 * 4) = iVar4;
              iVar4 = iVar4 + 0xf0;
              iVar6 = iVar6 + 1;
            } while (iVar6 < (int)uVar2);
          }
          piVar1[1] = uVar2;
          piVar1[3] = *(int *)(param_1 + 0x60);
          piVar1[4] = (int)piVar1;
          piVar1 = *(int **)(param_1 + 0x60);
          piVar1[1] = piVar1[1] + -1;
          puVar5 = *(undefined4 **)(*piVar1 + piVar1[1] * 4);
          goto LAB_005f99d3;
        }
        FUN_01674ea0(iVar4);
      }
    }
    puVar5 = (undefined4 *)0x0;
  }
  else {
    piVar1 = *(int **)(param_1 + 0x60);
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    puVar5 = *(undefined4 **)(*piVar1 + iVar4 * 4);
    if (iVar4 == 0) {
      *(int *)(param_1 + 0x68) = *(int *)(param_1 + 0x68) + -1;
      *(int *)(param_1 + 0x60) = piVar1[3];
      *(int *)(piVar1[3] + 0x10) = piVar1[4];
      *(int *)(piVar1[4] + 0xc) = piVar1[3];
      iVar4 = *(int *)(param_1 + 0x6c);
      *(int *)(param_1 + 0x6c) = iVar4 + 1;
      if (iVar4 == 0) {
        *(int **)(param_1 + 100) = piVar1;
        piVar1[3] = (int)piVar1;
        piVar1[4] = (int)piVar1;
      }
      else {
        piVar1[3] = *(int *)(param_1 + 100);
        piVar1[4] = *(int *)(*(int *)(param_1 + 100) + 0x10);
        *(int **)(*(int *)(*(int *)(param_1 + 100) + 0x10) + 0xc) = piVar1;
        *(int **)(*(int *)(param_1 + 100) + 0x10) = piVar1;
      }
    }
  }
LAB_005f99d3:
  *puVar5 = 0xffffff;
  *(undefined *)(puVar5 + 9) = 0;
  puVar5[0xc] = 0;
  puVar5[0xd] = 0;
  puVar5[5] = 0;
  puVar5[0x10] = 0;
  puVar5[0xf] = 0;
  *(undefined2 *)(puVar5 + 0x12) = 0;
  *(undefined *)((int)puVar5 + 0x4a) = 0;
  return puVar5;
}



/* FUNCTION 6133 ; VA 0x005f9a60 ; FUN_005f9a60 */

bool __fastcall FUN_005f9a60(int param_1)

{
  return *(int *)(param_1 + 0x820) != 0;
}



/* FUNCTION 6134 ; VA 0x005f9a70 ; FUN_005f9a70 */

undefined4 * FUN_005f9a70(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *unaff_EBX;
  undefined auStack_6c [36];
  undefined auStack_48 [24];
  undefined auStack_30 [28];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c9f0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  uStack_8 = 0;
  if (*(int *)(param_1 + 0x18) - (int)*(int **)(param_1 + 0x14) >> 2 == 0) {
    ExceptionList = &pvStack_10;
    FUN_00577c40();
LAB_005f9d06:
    FUN_00577c40();
  }
  else {
    puVar1 = (undefined4 *)**(int **)(param_1 + 0x14);
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffff88;
    unaff_EBX = (undefined4 *)FUN_005f98f0();
    unaff_EBX[10] = param_2;
    unaff_EBX[6] = 0;
    unaff_EBX[0xb] = param_3;
    unaff_EBX[0xf] = 0;
    unaff_EBX[0xc] = 0;
    unaff_EBX[0xd] = 0;
    unaff_EBX[1] = puVar1[1];
    unaff_EBX[2] = puVar1[2];
    *(undefined *)(unaff_EBX + 3) = *(undefined *)(puVar1 + 3);
    *unaff_EBX = *puVar1;
    unaff_EBX[0x13] = puVar1[0x13];
    unaff_EBX[7] = puVar1[7];
    iVar2 = 0;
    unaff_EBX[6] = 0;
    for (uVar5 = 0; uVar5 < *(uint *)(param_1 + 0x20); uVar5 = uVar5 + 1) {
      if ((uint)(*(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x14) >> 2) <= uVar5)
      goto LAB_005f9d06;
      unaff_EBX[6] = unaff_EBX[6] + *(int *)(*(int *)(*(int *)(param_1 + 0x14) + uVar5 * 4) + 0x18);
      iVar2 = unaff_EBX[6];
    }
    uVar5 = iVar2 + 7U >> 3;
    if (uVar5 <= DAT_01d5b348) {
      uVar4 = FUN_01674f30(uVar5);
      unaff_EBX[0xf] = uVar4;
      iVar2 = 0;
      unaff_EBX[0x10] = 0;
      for (uVar5 = 0; uVar5 < *(uint *)(param_1 + 0x20); uVar5 = uVar5 + 1) {
        if ((uint)(*(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x14) >> 2) <= uVar5) {
          FUN_00577c40();
LAB_005f9d89:
          FUN_00577c40();
          goto LAB_005f9d8e;
        }
        iVar3 = *(int *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
        FUN_0170c6f0((iVar2 + 7U >> 3) + unaff_EBX[0xf],*(undefined4 *)(iVar3 + 0x3c),
                     *(int *)(iVar3 + 0x18) + 7U >> 3);
        if ((uint)(*(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x14) >> 2) <= uVar5)
        goto LAB_005f9d89;
        iVar2 = iVar2 + *(int *)(*(int *)(*(int *)(param_1 + 0x14) + uVar5 * 4) + 0x18);
      }
      for (uVar5 = 0; uVar5 < *(uint *)(param_1 + 0x20); uVar5 = uVar5 + 1) {
        if ((uint)(*(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x14) >> 2) <= uVar5)
        goto LAB_005f9d8e;
        FUN_005fa670(*(undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4),
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                     ,0xcef);
        if ((uint)(*(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x14) >> 2) <= uVar5)
        goto LAB_005f9d93;
        FUN_005fe570(*(undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4));
      }
      iVar2 = *(int *)(param_1 + 0x14);
      if (iVar2 != 0) {
        uVar5 = *(int *)(param_1 + 0x1c) - iVar2 & 0xfffffffc;
        iVar3 = iVar2;
        if (0xfff < uVar5) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar5 = uVar5 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_005f9d98;
        }
        FUN_01674ea0(iVar3,uVar5);
        *(undefined4 *)(param_1 + 0x14) = 0;
        *(undefined4 *)(param_1 + 0x18) = 0;
        *(undefined4 *)(param_1 + 0x1c) = 0;
      }
      if (*(int *)(param_1 + 0x10) != 0) {
        FUN_01674ea0(*(undefined4 *)(param_1 + 8));
      }
      FUN_01674ea0(param_1,0x38);
      ExceptionList = pvStack_10;
      return unaff_EBX;
    }
  }
  FUN_01675640(auStack_30,&DAT_018bed68,*(undefined *)unaff_EBX[0xf]);
  uStack_8._0_1_ = 1;
  uVar4 = FUN_005543f0(0,0,0);
  FUN_0087c450(&DAT_018c5f98,"NetworkPacketSplitCountOverThreshold",uVar4);
  uVar4 = FUN_01675640(auStack_48,"Reconstructed packet too large %u > %u",unaff_EBX[6] + 7 >> 3,
                       DAT_01d5b348);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_005f8ef0(uVar4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_6c,&DAT_01c27108);
LAB_005f9d8e:
  FUN_00577c40();
LAB_005f9d93:
  FUN_00577c40();
LAB_005f9d98:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 6135 ; VA 0x005f9c8b ; Catch@005f9c8b */

undefined * Catch_005f9c8b(void)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int unaff_EBP;
  uint uVar4;
  
  iVar1 = *(int *)(unaff_EBP + 8);
  uVar4 = 0;
  iVar2 = *(int *)(unaff_EBP + -0x14);
  if (*(int *)(iVar1 + 0x20) != 0) {
    do {
      puVar3 = (undefined4 *)FUN_005f9430(uVar4);
      FUN_005fa670(*puVar3,
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                   ,0xcf8);
      puVar3 = (undefined4 *)FUN_005f9430(uVar4);
      FUN_005fe570(*puVar3);
      uVar4 = uVar4 + 1;
    } while (uVar4 < *(uint *)(iVar1 + 0x20));
  }
  FUN_005f9460(1);
  *(undefined *)(iVar2 + 0xdc) = 1;
  return &LAB_005f9cec;
}



/* FUNCTION 6136 ; VA 0x005f9da0 ; FUN_005f9da0 */

void __fastcall FUN_005f9da0(int *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  if (0 < param_1[2]) {
    puVar3 = (undefined4 *)*param_1;
    FUN_01674ea0(*puVar3);
    FUN_01674ea0(puVar3[2]);
    puVar2 = puVar3;
    puVar1 = (undefined4 *)puVar3[3];
    if ((undefined4 *)puVar3[3] != (undefined4 *)*param_1) {
      do {
        puVar3 = puVar1;
        FUN_01674ea0(puVar2);
        FUN_01674ea0(*puVar3);
        FUN_01674ea0(puVar3[2]);
        puVar2 = puVar3;
        puVar1 = (undefined4 *)puVar3[3];
      } while ((undefined4 *)puVar3[3] != (undefined4 *)*param_1);
    }
    FUN_01674ea0(puVar3);
  }
  if (0 < param_1[3]) {
    puVar3 = (undefined4 *)param_1[1];
    FUN_01674ea0(*puVar3);
    FUN_01674ea0(puVar3[2]);
    puVar2 = puVar3;
    puVar1 = (undefined4 *)puVar3[3];
    if ((undefined4 *)puVar3[3] != (undefined4 *)param_1[1]) {
      do {
        puVar3 = puVar1;
        FUN_01674ea0(puVar2);
        FUN_01674ea0(*puVar3);
        FUN_01674ea0(puVar3[2]);
        puVar2 = puVar3;
        puVar1 = (undefined4 *)puVar3[3];
      } while ((undefined4 *)puVar3[3] != (undefined4 *)param_1[1]);
    }
    FUN_01674ea0(puVar3);
  }
  param_1[3] = 0;
  param_1[2] = 0;
  return;
}



/* FUNCTION 6137 ; VA 0x005f9e60 ; FUN_005f9e60 */

void __fastcall FUN_005f9e60(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (param_1[2] != 0) {
    if (0x200 < (uint)param_1[2]) {
      iVar1 = *param_1;
      if (iVar1 != 0) {
        uStack_8 = 0;
        ExceptionList = &pvStack_10;
        FUN_016f32d1(iVar1,8,*(undefined4 *)(iVar1 + -4),_guard_check_icall);
        FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 8 + 4);
      }
      param_1[2] = 0;
      *param_1 = 0;
    }
    param_1[1] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6138 ; VA 0x005f9ef0 ; FUN_005f9ef0 */

void __fastcall FUN_005f9ef0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = 0;
  if (*(int *)(param_1 + 0x7cc) != 0) {
    do {
      if (*(char *)(uVar3 + *(int *)(param_1 + 0x7c8)) != '\0') {
        iVar1 = *(int *)(*(int *)(param_1 + 0x7bc) + uVar3 * 4);
        iVar2 = *(int *)(iVar1 + 0x1c);
        if (((iVar2 == 0) || (iVar2 == 1)) || (iVar2 == 5)) {
          *(undefined4 *)(*(int *)(iVar1 + 0x5c) + 0x60) = *(undefined4 *)(iVar1 + 0x60);
          *(undefined4 *)(*(int *)(iVar1 + 0x60) + 0x5c) = *(undefined4 *)(iVar1 + 0x5c);
          if ((*(int *)(param_1 + 0x84) == iVar1) &&
             (iVar2 = *(int *)(iVar1 + 0x60), *(int *)(param_1 + 0x84) = iVar2, iVar2 == iVar1)) {
            *(undefined4 *)(param_1 + 0x84) = 0;
          }
        }
        FUN_005fa670(*(undefined4 *)(*(int *)(param_1 + 0x7bc) + uVar3 * 4),
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                     ,0xe47);
        FUN_005fe570(*(undefined4 *)(*(int *)(param_1 + 0x7bc) + uVar3 * 4));
      }
      uVar3 = uVar3 + 1;
    } while (uVar3 < *(uint *)(param_1 + 0x7cc));
  }
  if (*(uint *)(param_1 + 2000) != 0) {
    if (0x200 < *(uint *)(param_1 + 2000)) {
      FUN_01674ea0(*(undefined4 *)(param_1 + 0x7c8));
      *(undefined4 *)(param_1 + 2000) = 0;
      *(undefined4 *)(param_1 + 0x7c8) = 0;
    }
    *(undefined4 *)(param_1 + 0x7cc) = 0;
  }
  return;
}



/* FUNCTION 6139 ; VA 0x005f9fe0 ; FUN_005f9fe0 */

undefined4 * FUN_005f9fe0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  ushort auStack_c [3];
  byte bStack_6;
  char cStack_5;
  
  cStack_5 = '\0';
  if ((0x1f < (uint)(*(int *)(param_1 + 8) - *(int *)(param_1 + 0x10))) &&
     (puVar2 = (undefined4 *)FUN_005f98f0(), puVar2 != (undefined4 *)0x0)) {
    puVar2[10] = param_2;
    puVar2[0xb] = param_3;
    *(uint *)(param_1 + 0x10) = (*(int *)(param_1 + 0x10) - (*(int *)(param_1 + 0x10) - 1U & 7)) + 7
    ;
    FUN_006a5ae0(&bStack_6,3,1);
    puVar2[7] = (uint)bStack_6;
    uVar3 = *(uint *)(param_1 + 0x10);
    cVar1 = uVar3 + 1 <= *(uint *)(param_1 + 8);
    if ((bool)cVar1) {
      cStack_5 = (*(byte *)((uVar3 >> 3) + *(int *)(param_1 + 0x14)) &
                 (byte)(0x80 >> ((byte)uVar3 & 7))) != 0;
      uVar3 = uVar3 + 1;
    }
    *(uint *)(param_1 + 0x10) = (uVar3 - (uVar3 - 1 & 7)) + 7;
    FUN_006a5990(auStack_c);
    puVar2[6] = (uint)auStack_c[0];
    iVar4 = puVar2[7];
    if (((iVar4 == 2) || (iVar4 == 4)) || (iVar4 == 3)) {
      FUN_005f7fd0(puVar2);
    }
    else {
      *puVar2 = 0xffffff;
    }
    *(uint *)(param_1 + 0x10) = (*(int *)(param_1 + 0x10) - (*(int *)(param_1 + 0x10) - 1U & 7)) + 7
    ;
    iVar4 = puVar2[7];
    if ((iVar4 == 1) || (iVar4 == 4)) {
      FUN_005f7fd0(puVar2 + 2);
      iVar4 = puVar2[7];
    }
    if (((iVar4 == 1) || (iVar4 == 4)) || ((iVar4 == 3 || (iVar4 == 7)))) {
      FUN_005f7fd0(puVar2 + 1);
      cVar1 = FUN_006a5ab0(puVar2 + 3);
    }
    else {
      *(undefined *)(puVar2 + 3) = 0;
    }
    if (cStack_5 == '\0') {
      puVar2[5] = 0;
    }
    else {
      FUN_006a5a00(puVar2 + 5);
      FUN_006a5990((int)puVar2 + 0xe);
      cVar1 = FUN_006a5a00(puVar2 + 4);
    }
    if ((((((cVar1 != '\0') && (puVar2[6] != 0)) && ((int)puVar2[7] < 8)) &&
         (*(byte *)(puVar2 + 3) < 0x20)) &&
        ((cStack_5 == '\0' || (((uint)puVar2[4] < (uint)puVar2[5] && ((uint)puVar2[5] < 0x7a121)))))
        ) && (uVar3 = puVar2[6] + 7 >> 3, uVar3 <= DAT_01d5b348)) {
      puVar2[0x10] = 0;
      iVar4 = FUN_01674f30(uVar3);
      puVar2[0xf] = iVar4;
      if (iVar4 != 0) {
        *(undefined *)(((puVar2[6] + 7 >> 3) - 1) + iVar4) = 0;
        cVar1 = FUN_006a5930(puVar2[0xf],puVar2[6] + 7 >> 3);
        if (cVar1 != '\0') {
          return puVar2;
        }
        FUN_005fa670(puVar2,
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                     ,0xb4d);
        FUN_005fe570(puVar2);
        return (undefined4 *)0x0;
      }
      FUN_006a35a0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                   ,0xb3d);
    }
    FUN_005fe570(puVar2);
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 6140 ; VA 0x005fa230 ; FUN_005fa230 */

undefined4 __thiscall FUN_005fa230(int *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  undefined *puVar5;
  ushort uVar6;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  ushort auStack_18 [3];
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1[2] != 0) {
    ExceptionList = &pvStack_10;
    if (0x200 < (uint)param_1[2]) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      if (iVar4 != 0) {
        uStack_8 = 0;
        ExceptionList = &pvStack_10;
        FUN_016f32d1(iVar4,8,*(undefined4 *)(iVar4 + -4),_guard_check_icall);
        FUN_01674ea0((int *)(iVar4 + -4),*(int *)(iVar4 + -4) * 8 + 4);
      }
      param_1[2] = 0;
      *param_1 = 0;
    }
    param_1[1] = 0;
  }
  uVar2 = param_2;
  uStack_8 = 0xffffffff;
  *(uint *)(param_2 + 0x10) = (*(int *)(param_2 + 0x10) - (*(int *)(param_2 + 0x10) - 1U & 7)) + 7;
  cVar3 = FUN_005fda50();
  if (cVar3 == '\0') {
    cVar3 = FUN_006a5ae0(&param_2,0x10,1);
    if (cVar3 != '\0') {
      FUN_006a5c10(&param_2,auStack_18,2);
    }
  }
  else {
    FUN_006a5ae0(auStack_18,0x10,1);
  }
  cStack_11 = '\0';
  uVar6 = 0;
  if (auStack_18[0] != 0) {
    do {
      FUN_006a5ae0(&cStack_11,8,1);
      iVar4 = *(int *)(uVar2 + 0x10) - (*(int *)(uVar2 + 0x10) - 1U & 7);
      *(int *)(uVar2 + 0x10) = iVar4 + 7;
      if (*(uint *)(uVar2 + 8) < iVar4 + 0x1fU) {
        ExceptionList = pvStack_10;
        return 0;
      }
      cVar3 = FUN_005fda50();
      uVar1 = *(uint *)(uVar2 + 0x10);
      puVar5 = (undefined *)((uVar1 >> 3) + *(int *)(uVar2 + 0x14));
      if (cVar3 == '\0') {
        param_2 = (uint)CONCAT12(puVar5[2],CONCAT11(puVar5[1],*puVar5));
      }
      else {
        param_2 = (uint)CONCAT21(CONCAT11(*puVar5,puVar5[1]),puVar5[2]) << 8;
      }
      *(uint *)(uVar2 + 0x10) = uVar1 + 0x18;
      if (cStack_11 == '\0') {
        iVar4 = (uVar1 + 0x18) - (uVar1 + 0x17 & 7);
        *(int *)(uVar2 + 0x10) = iVar4 + 7;
        if (*(uint *)(uVar2 + 8) < iVar4 + 0x1fU) {
          ExceptionList = pvStack_10;
          return 0;
        }
        cVar3 = FUN_005fda50();
        puVar5 = (undefined *)((*(uint *)(uVar2 + 0x10) >> 3) + *(int *)(uVar2 + 0x14));
        if (cVar3 == '\0') {
          uStack_1c = (uint)CONCAT12(puVar5[2],CONCAT11(puVar5[1],*puVar5));
        }
        else {
          uStack_1c = (uint)CONCAT21(CONCAT11(*puVar5,puVar5[1]),puVar5[2]) << 8;
        }
        *(uint *)(uVar2 + 0x10) = *(uint *)(uVar2 + 0x10) + 0x18;
        if (uStack_1c < param_2) {
          ExceptionList = pvStack_10;
          return 0;
        }
      }
      else {
        uStack_1c = param_2;
      }
      uStack_24 = param_2;
      uStack_20 = uStack_1c;
      FUN_005fd110(&uStack_24,
                   "c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_RangeList.h"
                   ,0x83);
      uVar6 = uVar6 + 1;
    } while (uVar6 < auStack_18[0]);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 6141 ; VA 0x005fa450 ; FUN_005fa450 */

void __thiscall FUN_005fa450(undefined4 *param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar3 = *(uint *)(param_2 + 0x10);
  uVar2 = *(uint *)(param_2 + 8);
  if (uVar3 + 1 <= uVar2) {
    *(bool *)((int)param_1 + 0x15) =
         (*(byte *)((uVar3 >> 3) + *(int *)(param_2 + 0x14)) & (byte)(0x80 >> ((byte)uVar3 & 7))) !=
         0;
    *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + 1;
    uVar3 = *(uint *)(param_2 + 0x10);
    uVar2 = *(uint *)(param_2 + 8);
  }
  if (uVar3 + 1 <= uVar2) {
    *(bool *)(param_1 + 4) =
         (*(byte *)((uVar3 >> 3) + *(int *)(param_2 + 0x14)) & (byte)(0x80 >> ((byte)uVar3 & 7))) !=
         0;
    *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + 1;
    uVar3 = *(uint *)(param_2 + 0x10);
  }
  if (*(char *)(param_1 + 4) == '\0') {
    if (uVar3 + 1 <= *(uint *)(param_2 + 8)) {
      *(bool *)((int)param_1 + 0x11) =
           (*(byte *)((uVar3 >> 3) + *(int *)(param_2 + 0x14)) & (byte)(0x80 >> ((byte)uVar3 & 7)))
           != 0;
      *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + 1;
      uVar3 = *(uint *)(param_2 + 0x10);
    }
    if (*(char *)((int)param_1 + 0x11) == '\0') {
      uVar4 = *(uint *)(param_2 + 8);
      uVar2 = uVar3 + 1;
      if (uVar2 <= uVar4) {
        *(uint *)(param_2 + 0x10) = uVar2;
        uVar3 = uVar2;
      }
      if (uVar3 + 1 <= uVar4) {
        *(bool *)((int)param_1 + 0x13) =
             (*(byte *)((uVar3 >> 3) + *(int *)(param_2 + 0x14)) & (byte)(0x80 >> ((byte)uVar3 & 7))
             ) != 0;
        *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + 1;
        uVar3 = *(uint *)(param_2 + 0x10);
        uVar4 = *(uint *)(param_2 + 8);
      }
      if (uVar3 + 1 <= uVar4) {
        *(bool *)(param_1 + 5) =
             (*(byte *)((uVar3 >> 3) + *(int *)(param_2 + 0x14)) & (byte)(0x80 >> ((byte)uVar3 & 7))
             ) != 0;
        uVar3 = *(int *)(param_2 + 0x10) + 1;
      }
      *(uint *)(param_2 + 0x10) = (uVar3 - (uVar3 - 1 & 7)) + 7;
      if ((char)param_3 != '\0') {
        FUN_005f7f70(&param_3);
        *param_1 = param_3;
        param_1[1] = 0;
      }
      FUN_005f7fd0(param_1 + 2);
    }
  }
  else {
    *(undefined *)((int)param_1 + 0x11) = 0;
    uVar2 = *(uint *)(param_2 + 0x10);
    uVar3 = *(uint *)(param_2 + 8);
    if (uVar2 + 1 <= uVar3) {
      *(bool *)((int)param_1 + 0x12) =
           (*(byte *)((uVar2 >> 3) + *(int *)(param_2 + 0x14)) & (byte)(0x80 >> ((byte)uVar2 & 7)))
           != 0;
      *(int *)(param_2 + 0x10) = *(int *)(param_2 + 0x10) + 1;
      uVar2 = *(uint *)(param_2 + 0x10);
      uVar3 = *(uint *)(param_2 + 8);
    }
    if (uVar2 + 1 <= uVar3) {
      *(bool *)((int)param_1 + 0x16) =
           (*(byte *)((uVar2 >> 3) + *(int *)(param_2 + 0x14)) & (byte)(0x80 >> ((byte)uVar2 & 7)))
           != 0;
      uVar2 = *(int *)(param_2 + 0x10) + 1;
    }
    *(uint *)(param_2 + 0x10) = (uVar2 - (uVar2 - 1 & 7)) + 7;
    if ((char)param_3 != '\0') {
      FUN_005f7f70(&param_3);
      *param_1 = param_3;
      param_1[1] = 0;
    }
    if (*(char *)((int)param_1 + 0x12) != '\0') {
      cVar1 = FUN_005fda50();
      if (cVar1 != '\0') {
        FUN_006a5ae0(param_1 + 3,0x20,1);
        return;
      }
      cVar1 = FUN_006a5ae0(&param_3,0x20,1);
      if (cVar1 != '\0') {
        FUN_006a5c10(&param_3,param_1 + 3,4);
        return;
      }
    }
  }
  return;
}



/* FUNCTION 6142 ; VA 0x005fa670 ; FUN_005fa670 */

undefined4 * __thiscall FUN_005fa670(int param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *in_EAX;
  undefined4 *puVar3;
  
  if (param_2 != 0) {
    in_EAX = *(undefined4 **)(param_2 + 0x40);
    if (in_EAX == (undefined4 *)0x1) {
      in_EAX = *(undefined4 **)(param_2 + 0x44);
      if (in_EAX != (undefined4 *)0x0) {
        in_EAX[1] = in_EAX[1] + -1;
        in_EAX = *(undefined4 **)(param_2 + 0x44);
        if (in_EAX[1] == 0) {
          FUN_01674ea0(*in_EAX);
          **(undefined4 **)(param_2 + 0x44) = 0;
          iVar1 = *(int *)(param_2 + 0x44);
          puVar2 = *(undefined4 **)(iVar1 + 8);
          if (puVar2[1] != 0) {
            ((int *)*puVar2)[puVar2[1]] = iVar1;
            puVar2[1] = puVar2[1] + 1;
            puVar3 = (undefined4 *)(*(uint *)(param_1 + 0x848) * -0x55555555);
            if ((puVar2[1] == *(uint *)(param_1 + 0x848) / 0xc) && (3 < *(int *)(param_1 + 0x840)))
            {
              if (puVar2 == *(undefined4 **)(param_1 + 0x838)) {
                *(undefined4 *)(param_1 + 0x838) = puVar2[3];
              }
              *(undefined4 *)(puVar2[4] + 0xc) = puVar2[3];
              *(undefined4 *)(puVar2[3] + 0x10) = puVar2[4];
              *(int *)(param_1 + 0x840) = *(int *)(param_1 + 0x840) + -1;
              FUN_01674ea0(*puVar2);
              FUN_01674ea0(puVar2[2]);
              puVar3 = (undefined4 *)FUN_01674ea0(puVar2);
            }
            *(undefined4 *)(param_2 + 0x44) = 0;
            return puVar3;
          }
          *(int *)*puVar2 = iVar1;
          puVar2[1] = puVar2[1] + 1;
          *(int *)(param_1 + 0x844) = *(int *)(param_1 + 0x844) + -1;
          *(undefined4 *)(puVar2[3] + 0x10) = puVar2[4];
          *(undefined4 *)(puVar2[4] + 0xc) = puVar2[3];
          if ((0 < *(int *)(param_1 + 0x844)) && (puVar2 == *(undefined4 **)(param_1 + 0x83c))) {
            *(undefined4 *)(param_1 + 0x83c) = (*(undefined4 **)(param_1 + 0x83c))[3];
          }
          iVar1 = *(int *)(param_1 + 0x840);
          puVar3 = (undefined4 *)(iVar1 + 1);
          *(undefined4 **)(param_1 + 0x840) = puVar3;
          if (iVar1 != 0) {
            puVar2[3] = *(undefined4 *)(param_1 + 0x838);
            puVar2[4] = *(undefined4 *)(*(int *)(param_1 + 0x838) + 0x10);
            *(undefined4 **)(*(int *)(*(int *)(param_1 + 0x838) + 0x10) + 0xc) = puVar2;
            puVar3 = *(undefined4 **)(param_1 + 0x838);
            puVar3[4] = puVar2;
            *(undefined4 *)(param_2 + 0x44) = 0;
            return puVar3;
          }
          *(undefined4 **)(param_1 + 0x838) = puVar2;
          puVar2[3] = puVar2;
          puVar2[4] = puVar2;
          *(undefined4 *)(param_2 + 0x44) = 0;
          return puVar3;
        }
      }
    }
    else {
      if (in_EAX == (undefined4 *)0x0) {
        if (*(int *)(param_2 + 0x3c) == 0) {
          return (undefined4 *)0x0;
        }
        in_EAX = (undefined4 *)FUN_01674ea0(*(int *)(param_2 + 0x3c));
      }
      *(undefined4 *)(param_2 + 0x3c) = 0;
    }
  }
  return in_EAX;
}



/* FUNCTION 6143 ; VA 0x005fa800 ; FUN_005fa800 */

void __fastcall FUN_005fa800(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint *puVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005f9ef0();
  uStack_14 = 0;
  if (*(int *)(param_1 + 0xcc) != 0) {
    do {
      uVar4 = uStack_14;
      iVar8 = *(int *)(param_1 + 200);
      uVar6 = 0;
      if (*(int *)(*(int *)(iVar8 + uStack_14 * 4) + 0xc) != 0) {
        do {
          iVar8 = *(int *)(iVar8 + uVar4 * 4);
          if ((iVar8 == 0) || (iVar3 = *(int *)(*(int *)(iVar8 + 8) + uVar6 * 4), iVar3 == 0)) {
            uVar9 = 0x270;
            iVar3 = *(int *)(*(int *)(iVar8 + 8) + uVar6 * 4);
          }
          else {
            uVar9 = 0x26b;
          }
          FUN_005fa670(iVar3,
                       "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                       ,uVar9);
          FUN_005fe570(*(undefined4 *)
                        (*(int *)(*(int *)(*(int *)(param_1 + 200) + uVar4 * 4) + 8) + uVar6 * 4));
          iVar8 = *(int *)(param_1 + 200);
          uVar6 = uVar6 + 1;
        } while (uVar6 < *(uint *)(*(int *)(iVar8 + uVar4 * 4) + 0xc));
      }
      iVar8 = *(int *)(iVar8 + uVar4 * 4);
      if (iVar8 != 0) {
        iVar3 = *(int *)(iVar8 + 0x14);
        if (iVar3 != 0) {
          uVar6 = (*(int *)(iVar8 + 0x1c) - iVar3 >> 2) * 4;
          iVar1 = iVar3;
          if (0xfff < uVar6) {
            iVar1 = *(int *)(iVar3 + -4);
            uVar6 = uVar6 + 0x23;
            uVar4 = uStack_14;
            if (0x1f < (iVar3 - iVar1) - 4U) goto LAB_005fb176;
          }
          FUN_01674ea0(iVar1,uVar6);
          *(undefined4 *)(iVar8 + 0x14) = 0;
          *(undefined4 *)(iVar8 + 0x18) = 0;
          *(undefined4 *)(iVar8 + 0x1c) = 0;
        }
        if (*(int *)(iVar8 + 0x10) != 0) {
          FUN_01674ea0(*(undefined4 *)(iVar8 + 8));
        }
        FUN_01674ea0(iVar8,0x38);
      }
      uStack_14 = uVar4 + 1;
    } while (uStack_14 < *(uint *)(param_1 + 0xcc));
  }
  if (*(int *)(param_1 + 0xd0) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 200));
    *(undefined4 *)(param_1 + 0xd0) = 0;
    *(undefined4 *)(param_1 + 200) = 0;
    *(undefined4 *)(param_1 + 0xcc) = 0;
  }
  while( true ) {
    uVar4 = *(uint *)(param_1 + 0xc);
    if (*(uint *)(param_1 + 0x10) < uVar4) {
      iVar8 = *(int *)(param_1 + 0x14) - uVar4;
    }
    else {
      iVar8 = -uVar4;
    }
    if (*(uint *)(param_1 + 0x10) + iVar8 == 0) break;
    iVar8 = *(int *)(param_1 + 0x14);
    iVar3 = uVar4 + 1;
    *(int *)(param_1 + 0xc) = iVar3;
    if (iVar3 == iVar8) {
      *(undefined4 *)(param_1 + 0xc) = 0;
      uVar9 = *(undefined4 *)(*(int *)(param_1 + 8) + -4 + iVar8 * 4);
    }
    else if (iVar3 == 0) {
      uVar9 = *(undefined4 *)(*(int *)(param_1 + 8) + -4 + iVar8 * 4);
    }
    else {
      uVar9 = *(undefined4 *)(*(int *)(param_1 + 8) + -4 + iVar3 * 4);
    }
    FUN_005fa670(uVar9,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                 ,0x282);
    FUN_005fe570(uVar9);
  }
  FUN_01674ea0(*(undefined4 *)(param_1 + 8));
  uVar9 = FUN_01674e20(0x80);
  *(undefined4 *)(param_1 + 8) = uVar9;
  *(undefined4 *)(param_1 + 0x14) = 0x20;
  *(undefined4 *)(param_1 + 0xc) = 0;
  puVar7 = (uint *)(param_1 + 0x4a8);
  *(undefined4 *)(param_1 + 0x10) = 0;
  puStack_18 = (undefined4 *)0x20;
  do {
    uStack_14 = 0;
    if (puVar7[-1] != 0) {
      iVar8 = 0;
      do {
        FUN_005fa670(*(undefined4 *)(puVar7[-2] + 8 + iVar8),
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                     ,0x2a4);
        FUN_005fe570(*(undefined4 *)(puVar7[-2] + 8 + iVar8));
        iVar8 = iVar8 + 0x10;
        uStack_14 = uStack_14 + 1;
      } while (uStack_14 < puVar7[-1]);
    }
    puVar5 = puStack_18;
    if (*puVar7 != 0) {
      if (0x200 < *puVar7) {
        FUN_01674ea0(puVar7[-2]);
        *puVar7 = 0;
        puVar7[-2] = 0;
      }
      puVar7[-1] = 0;
    }
    puVar7 = puVar7 + 4;
    puStack_18 = (undefined4 *)((int)puVar5 + -1);
  } while (puStack_18 != (undefined4 *)0x0);
  puVar5 = *(undefined4 **)(param_1 + 0x74);
  uVar6 = *(int *)(param_1 + 0x78) - (int)puVar5 >> 2;
  uVar4 = *(int *)(param_1 + 0x7c) - (int)puVar5 >> 2;
  puStack_18 = (undefined4 *)0x0;
  if (uVar4 < uVar6) {
    if (0x3fffffff < uVar6) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    puStack_18 = (undefined4 *)(uVar4 >> 1);
    uStack_14 = uVar6;
    if ((uVar4 <= 0x3fffffffU - (int)puStack_18) &&
       (uStack_14 = (int)puStack_18 + uVar4, (int)puStack_18 + uVar4 < uVar6)) {
      uStack_14 = uVar6;
    }
    if (puVar5 != (undefined4 *)0x0) {
      uVar4 = uVar4 * 4;
      puVar2 = puVar5;
      if (0xfff < uVar4) {
        puVar2 = (undefined4 *)puVar5[-1];
        uVar4 = uVar4 + 0x23;
        puStack_18 = puVar2;
        if (0x1f < (uint)((int)puVar5 + (-4 - (int)puVar2))) {
LAB_005fb176:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(puVar2,uVar4);
    }
    *(undefined4 *)(param_1 + 0x74) = 0;
    *(undefined4 *)(param_1 + 0x78) = 0;
    *(undefined4 *)(param_1 + 0x7c) = 0;
    if (uStack_14 != 0) {
      if (0x3fffffff < uStack_14) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      uVar9 = FUN_00577ed0(uStack_14);
      *(undefined4 *)(param_1 + 0x74) = uVar9;
      *(undefined4 *)(param_1 + 0x78) = uVar9;
      *(uint *)(param_1 + 0x7c) = *(int *)(param_1 + 0x74) + uStack_14 * 4;
    }
    puVar5 = *(undefined4 **)(param_1 + 0x74);
    uVar4 = uVar6;
    puVar2 = puVar5;
    if (uVar6 != 0) {
      for (; uVar4 != 0; uVar4 = uVar4 - 1) {
        *puVar2 = 0;
        puVar2 = puVar2 + 1;
      }
      puVar5 = puVar5 + uVar6;
    }
    *(undefined4 **)(param_1 + 0x78) = puVar5;
  }
  else {
    FUN_005f81d0(puVar5,puVar5 + uVar6,&puStack_18);
    *(undefined4 **)(param_1 + 0x78) = puVar5 + uVar6;
  }
  *(undefined4 *)(param_1 + 0x1b0) = 0;
  *(undefined4 *)(param_1 + 0x1b8) = 0;
  *(undefined4 *)(param_1 + 0x1bc) = 0;
  iVar8 = *(int *)(param_1 + 0x80);
  if (*(int *)(param_1 + 0x80) != 0) {
    while( true ) {
      if (*(int *)(iVar8 + 0x3c) != 0) {
        FUN_005fa670(iVar8,
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                     ,0x2b7);
      }
      iVar3 = *(int *)(iVar8 + 0x58);
      if (iVar3 == *(int *)(param_1 + 0x80)) break;
      FUN_005fe570(iVar8);
      iVar8 = iVar3;
    }
    FUN_005fe570(iVar8);
    *(undefined4 *)(param_1 + 0x80) = 0;
  }
  if (DAT_01d5aed0 != '\0') {
    puVar5 = *(undefined4 **)(param_1 + 0x88);
    puStack_18 = (undefined4 *)*puVar5;
    while (puStack_18 != puVar5) {
      FUN_005fe570(puStack_18[5]);
      FUN_00551320();
    }
    FUN_00601ea0();
    *(undefined4 *)(param_1 + 0x90) = 0;
  }
  uVar4 = 0;
  *(undefined4 *)(param_1 + 0x7b4) = 0;
  *(undefined4 *)(param_1 + 0x7b8) = 0;
  if (*(int *)(param_1 + 0x9c) != 0) {
    iVar8 = 0;
    do {
      iVar3 = *(int *)(param_1 + 0x98);
      iVar1 = *(int *)(iVar3 + 8 + iVar8);
      if (*(int *)(iVar1 + 0x3c) != 0) {
        FUN_005fa670(iVar1,
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                     ,0x2d2);
        iVar3 = *(int *)(param_1 + 0x98);
      }
      FUN_005fe570(*(undefined4 *)(iVar3 + 8 + iVar8));
      uVar4 = uVar4 + 1;
      iVar8 = iVar8 + 0x10;
    } while (uVar4 < *(uint *)(param_1 + 0x9c));
  }
  if (*(uint *)(param_1 + 0xa0) != 0) {
    if (0x200 < *(uint *)(param_1 + 0xa0)) {
      FUN_01674ea0(*(undefined4 *)(param_1 + 0x98));
      *(undefined4 *)(param_1 + 0xa0) = 0;
      *(undefined4 *)(param_1 + 0x98) = 0;
    }
    *(undefined4 *)(param_1 + 0x9c) = 0;
  }
  if (*(int *)(param_1 + 0x58) != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x50));
    *(undefined4 *)(param_1 + 0x58) = 0;
    *(undefined4 *)(param_1 + 0x50) = 0;
    *(undefined4 *)(param_1 + 0x54) = 0;
  }
  uVar4 = *(uint *)(param_1 + 0x7c4);
  if (uVar4 != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x7bc));
    *(undefined4 *)(param_1 + 0x7c4) = 0;
    *(undefined4 *)(param_1 + 0x7bc) = 0;
    uVar4 = 0;
    *(undefined4 *)(param_1 + 0x7c0) = 0;
  }
  uVar6 = uVar4;
  if (uVar4 == 0) {
    uVar6 = 0x10;
  }
  if (uVar6 < 0x200) {
    do {
      uVar6 = uVar6 * 2;
    } while (uVar6 < 0x200);
    uVar4 = *(uint *)(param_1 + 0x7c4);
  }
  if (uVar4 < uVar6) {
    *(uint *)(param_1 + 0x7c4) = uVar6;
    if (uVar6 == 0) {
      iVar8 = 0;
    }
    else {
      iVar8 = FUN_01674e20(-(uint)((int)((ulonglong)uVar6 * 4 >> 0x20) != 0) |
                           (uint)((ulonglong)uVar6 * 4));
    }
    iVar3 = *(int *)(param_1 + 0x7bc);
    if (iVar3 != 0) {
      uVar4 = 0;
      if (*(int *)(param_1 + 0x7c0) != 0) {
        do {
          *(undefined4 *)(iVar8 + uVar4 * 4) =
               *(undefined4 *)(*(int *)(param_1 + 0x7bc) + uVar4 * 4);
          uVar4 = uVar4 + 1;
        } while (uVar4 < *(uint *)(param_1 + 0x7c0));
        iVar3 = *(int *)(param_1 + 0x7bc);
      }
      FUN_01674ea0(iVar3);
    }
    *(int *)(param_1 + 0x7bc) = iVar8;
  }
  uVar4 = *(uint *)(param_1 + 2000);
  if (uVar4 != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x7c8));
    *(undefined4 *)(param_1 + 2000) = 0;
    *(undefined4 *)(param_1 + 0x7c8) = 0;
    uVar4 = 0;
    *(undefined4 *)(param_1 + 0x7cc) = 0;
  }
  uVar6 = uVar4;
  if (uVar4 == 0) {
    uVar6 = 0x10;
  }
  if (uVar6 < 0x200) {
    do {
      uVar6 = uVar6 * 2;
    } while (uVar6 < 0x200);
    uVar4 = *(uint *)(param_1 + 2000);
  }
  if (uVar4 < uVar6) {
    *(uint *)(param_1 + 2000) = uVar6;
    if (uVar6 == 0) {
      iVar8 = 0;
    }
    else {
      iVar8 = FUN_01674e20(uVar6);
    }
    iVar3 = *(int *)(param_1 + 0x7c8);
    if (iVar3 != 0) {
      uVar4 = 0;
      if (*(int *)(param_1 + 0x7cc) != 0) {
        do {
          *(undefined *)(uVar4 + iVar8) = *(undefined *)(uVar4 + *(int *)(param_1 + 0x7c8));
          uVar4 = uVar4 + 1;
        } while (uVar4 < *(uint *)(param_1 + 0x7cc));
        iVar3 = *(int *)(param_1 + 0x7c8);
      }
      FUN_01674ea0(iVar3);
    }
    *(int *)(param_1 + 0x7c8) = iVar8;
  }
  uVar4 = *(uint *)(param_1 + 0x7dc);
  if (uVar4 != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x7d4));
    *(undefined4 *)(param_1 + 0x7dc) = 0;
    *(undefined4 *)(param_1 + 0x7d4) = 0;
    uVar4 = 0;
    *(undefined4 *)(param_1 + 0x7d8) = 0;
  }
  uVar6 = uVar4;
  if (uVar4 == 0) {
    uVar6 = 0x10;
  }
  if (uVar6 < 0x80) {
    do {
      uVar6 = uVar6 * 2;
    } while (uVar6 < 0x80);
    uVar4 = *(uint *)(param_1 + 0x7dc);
  }
  if (uVar4 < uVar6) {
    *(uint *)(param_1 + 0x7dc) = uVar6;
    if (uVar6 == 0) {
      iVar8 = 0;
    }
    else {
      iVar8 = FUN_01674e20(-(uint)((int)((ulonglong)uVar6 * 4 >> 0x20) != 0) |
                           (uint)((ulonglong)uVar6 * 4));
    }
    iVar3 = *(int *)(param_1 + 0x7d4);
    if (iVar3 != 0) {
      uVar4 = 0;
      if (*(int *)(param_1 + 0x7d8) != 0) {
        do {
          *(undefined4 *)(iVar8 + uVar4 * 4) =
               *(undefined4 *)(*(int *)(param_1 + 0x7d4) + uVar4 * 4);
          uVar4 = uVar4 + 1;
        } while (uVar4 < *(uint *)(param_1 + 0x7d8));
        iVar3 = *(int *)(param_1 + 0x7d4);
      }
      FUN_01674ea0(iVar3);
    }
    *(int *)(param_1 + 0x7d4) = iVar8;
  }
  uVar4 = *(uint *)(param_1 + 0x7e8);
  if (uVar4 != 0) {
    FUN_01674ea0(*(undefined4 *)(param_1 + 0x7e0));
    *(undefined4 *)(param_1 + 0x7e8) = 0;
    *(undefined4 *)(param_1 + 0x7e0) = 0;
    uVar4 = 0;
    *(undefined4 *)(param_1 + 0x7e4) = 0;
  }
  uVar6 = uVar4;
  if (uVar4 == 0) {
    uVar6 = 0x10;
  }
  if (uVar6 < 0x80) {
    do {
      uVar6 = uVar6 * 2;
    } while (uVar6 < 0x80);
    uVar4 = *(uint *)(param_1 + 0x7e8);
  }
  if (uVar4 < uVar6) {
    *(uint *)(param_1 + 0x7e8) = uVar6;
    if (uVar6 == 0) {
      iVar8 = 0;
    }
    else {
      iVar8 = FUN_01674e20(-(uint)((int)((ulonglong)uVar6 * 4 >> 0x20) != 0) |
                           (uint)((ulonglong)uVar6 * 4));
    }
    iVar3 = *(int *)(param_1 + 0x7e0);
    if (iVar3 != 0) {
      uVar4 = 0;
      if (*(int *)(param_1 + 0x7e4) != 0) {
        do {
          *(undefined4 *)(iVar8 + uVar4 * 4) =
               *(undefined4 *)(*(int *)(param_1 + 0x7e0) + uVar4 * 4);
          uVar4 = uVar4 + 1;
        } while (uVar4 < *(uint *)(param_1 + 0x7e4));
        iVar3 = *(int *)(param_1 + 0x7e0);
      }
      FUN_01674ea0(iVar3);
    }
    *(int *)(param_1 + 0x7e0) = iVar8;
  }
  FUN_005f9da0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
               ,0x2e3);
  FUN_005f9da0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
               ,0x2e5);
  while( true ) {
    uVar4 = *(uint *)(param_1 + 0x2c);
    if (*(uint *)(param_1 + 0x30) < uVar4) {
      iVar8 = *(int *)(param_1 + 0x34) - uVar4;
    }
    else {
      iVar8 = -uVar4;
    }
    if (*(uint *)(param_1 + 0x30) + iVar8 == 0) break;
    FUN_005fe6b0(*(undefined4 *)(param_1 + 0x5c));
    *(int *)(param_1 + 0x2c) = *(int *)(param_1 + 0x2c) + 1;
    if (*(int *)(param_1 + 0x2c) == *(int *)(param_1 + 0x34)) {
      *(undefined4 *)(param_1 + 0x2c) = 0;
    }
    *(int *)(param_1 + 0x5c) = *(int *)(param_1 + 0x5c) + 1;
    *(undefined *)(param_1 + 0x5f) = 0;
  }
  FUN_005f9da0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
               ,0x2fa);
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined *)(param_1 + 0x5f) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  if (*(uint *)(param_1 + 0x824) != 0) {
    if (0x200 < *(uint *)(param_1 + 0x824)) {
      iVar8 = *(int *)(param_1 + 0x81c);
      if (iVar8 != 0) {
        uStack_8 = 0;
        FUN_016f32d1(iVar8,8,*(undefined4 *)(iVar8 + -4),_guard_check_icall);
        FUN_01674ea0((int *)(iVar8 + -4),*(int *)(iVar8 + -4) * 8 + 4);
      }
      *(undefined4 *)(param_1 + 0x824) = 0;
      *(undefined4 *)(param_1 + 0x81c) = 0;
    }
    *(undefined4 *)(param_1 + 0x820) = 0;
  }
  if (*(uint *)(param_1 + 0x830) != 0) {
    if (0x200 < *(uint *)(param_1 + 0x830)) {
      iVar8 = *(int *)(param_1 + 0x828);
      if (iVar8 != 0) {
        uStack_8 = 1;
        FUN_016f32d1(iVar8,8,*(undefined4 *)(iVar8 + -4),_guard_check_icall);
        FUN_01674ea0((int *)(iVar8 + -4),*(int *)(iVar8 + -4) * 8 + 4);
      }
      *(undefined4 *)(param_1 + 0x830) = 0;
      *(undefined4 *)(param_1 + 0x828) = 0;
    }
    *(undefined4 *)(param_1 + 0x82c) = 0;
  }
  *(undefined4 *)(param_1 + 0x84) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6144 ; VA 0x005fb190 ; FUN_005fb190 */

void __thiscall FUN_005fb190(int param_1,int *param_2)

{
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  undefined uStack_8;
  
  iStack_10 = 0;
  iStack_20 = 0;
  iStack_1c = 0;
  iStack_18 = 0;
  iStack_14 = 0;
  iStack_c = 0;
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x7b0) + 0x70))(&iStack_20);
  if (iStack_20 < 0) {
    iStack_20 = 0;
  }
  *param_2 = iStack_20;
  if (iStack_1c < 0) {
    iStack_1c = 0;
  }
  param_2[1] = iStack_1c;
  if (iStack_18 < 0) {
    iStack_18 = 0;
  }
  param_2[2] = iStack_18;
  if (iStack_14 < 0) {
    iStack_14 = 0;
  }
  param_2[3] = iStack_14;
  if (iStack_10 < 0) {
    iStack_10 = 0;
  }
  param_2[4] = iStack_10;
  if (iStack_c < 0) {
    iStack_c = 0;
  }
  param_2[5] = iStack_c;
  *(undefined *)(param_2 + 6) = uStack_8;
  return;
}



/* FUNCTION 6145 ; VA 0x005fb220 ; FUN_005fb220 */

int __thiscall FUN_005fb220(int *param_1,undefined4 param_2,undefined *param_3,code *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar1 = param_1[1];
  if (iVar1 == 0) {
    *param_3 = 0;
    return 0;
  }
  iVar4 = iVar1 / 2;
  iVar5 = 0;
  iVar2 = (*param_4)(param_2,*param_1 + iVar4 * 4);
  iVar1 = iVar1 + -1;
  while( true ) {
    if (iVar2 == 0) {
      *param_3 = 1;
      return iVar4;
    }
    if (-1 < iVar2) {
      iVar5 = iVar4 + 1;
    }
    iVar3 = iVar4 + -1;
    if (-1 < iVar2) {
      iVar3 = iVar1;
    }
    iVar4 = (iVar3 - iVar5) / 2 + iVar5;
    if (iVar3 < iVar5) break;
    iVar2 = (*param_4)(param_2,*param_1 + iVar4 * 4);
    iVar1 = iVar3;
  }
  *param_3 = 0;
  return iVar5;
}



/* FUNCTION 6146 ; VA 0x005fb2c0 ; FUN_005fb2c0 */

int __thiscall FUN_005fb2c0(int *param_1,undefined4 param_2,undefined *param_3,code *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar1 = param_1[1];
  if (iVar1 == 0) {
    *param_3 = 0;
    return 0;
  }
  iVar4 = iVar1 / 2;
  iVar5 = 0;
  iVar2 = (*param_4)(param_2,*param_1 + iVar4 * 8);
  iVar1 = iVar1 + -1;
  while( true ) {
    if (iVar2 == 0) {
      *param_3 = 1;
      return iVar4;
    }
    if (-1 < iVar2) {
      iVar5 = iVar4 + 1;
    }
    iVar3 = iVar4 + -1;
    if (-1 < iVar2) {
      iVar3 = iVar1;
    }
    iVar4 = (iVar3 - iVar5) / 2 + iVar5;
    if (iVar3 < iVar5) break;
    iVar2 = (*param_4)(param_2,*param_1 + iVar4 * 8);
    iVar1 = iVar3;
  }
  *param_3 = 0;
  return iVar5;
}



/* FUNCTION 6147 ; VA 0x005fb360 ; FUN_005fb360 */

int __thiscall FUN_005fb360(int *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  
  cVar1 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
  iVar2 = (**(code **)(*(int *)param_1[0x1ec] + 0x5c))();
  iVar2 = (((uint)(cVar1 == '\0') * 4 + -0xd) - param_2) + iVar2;
  if (*param_1 != 0) {
    cVar1 = FUN_00686be0();
    if (cVar1 != '\0') {
      return iVar2 * 8 + -0x90;
    }
  }
  return iVar2 * 8;
}



/* FUNCTION 6148 ; VA 0x005fb3c0 ; FUN_005fb3c0 */

int __thiscall FUN_005fb3c0(int *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  
  cVar1 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
  iVar2 = (**(code **)(*(int *)param_1[0x1ec] + 0x5c))();
  iVar2 = (((uint)(cVar1 == '\0') * 4 + -0xd) - param_2) + iVar2;
  if (*param_1 != 0) {
    cVar1 = FUN_00686be0();
    if (cVar1 != '\0') {
      return iVar2 + -0x12;
    }
  }
  return iVar2;
}



/* FUNCTION 6149 ; VA 0x005fb410 ; FUN_005fb410 */

int FUN_005fb410(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = 0x18;
  if ((((param_1 == 2) || (param_1 == 4)) || (param_1 == 3)) || ((param_1 == 6 || (param_1 == 7))))
  {
    iVar2 = 0x30;
  }
  if ((param_1 == 1) || (param_1 == 4)) {
    iVar2 = iVar2 + 0x18;
  }
  if ((((param_1 == 1) || (param_1 == 4)) || (param_1 == 3)) || (param_1 == 7)) {
    iVar2 = iVar2 + 0x20;
  }
  iVar1 = iVar2 + 0x50;
  if (param_2 < 1) {
    iVar1 = iVar2;
  }
  return iVar1;
}



/* FUNCTION 6150 ; VA 0x005fb470 ; FUN_005fb470 */

undefined4 __thiscall FUN_005fb470(int param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x2c);
  uVar4 = *(uint *)(param_1 + 0x30);
  if ((uVar1 != uVar4) &&
     ((iVar3 = *(int *)(param_1 + 0x5c), iVar3 == param_2 ||
      (0x7ffffe < (iVar3 - param_2 & 0xffffffU))))) {
    uVar2 = param_2 - iVar3 & 0xffffff;
    if (uVar4 < uVar1) {
      iVar3 = *(int *)(param_1 + 0x34) - uVar1;
    }
    else {
      iVar3 = -uVar1;
    }
    if (uVar2 < uVar4 + iVar3) {
      uVar4 = uVar1 + uVar2;
      iVar3 = *(int *)(param_1 + 0x28);
      if (*(uint *)(param_1 + 0x34) <= uVar4) {
        uVar4 = (uVar1 - *(uint *)(param_1 + 0x34)) + uVar2;
      }
      *param_3 = *(undefined4 *)(iVar3 + 8 + uVar4 * 0x10);
      param_3[1] = *(undefined4 *)(iVar3 + 0xc + uVar4 * 0x10);
      uVar1 = *(int *)(param_1 + 0x2c) + uVar2;
      if (uVar1 < *(uint *)(param_1 + 0x34)) {
        return *(undefined4 *)(*(int *)(param_1 + 0x28) + uVar1 * 0x10);
      }
      return *(undefined4 *)
              (*(int *)(param_1 + 0x28) +
              ((*(int *)(param_1 + 0x2c) - *(uint *)(param_1 + 0x34)) + uVar2) * 0x10);
    }
  }
  return 0;
}



/* FUNCTION 6151 ; VA 0x005fb520 ; FUN_005fb520 */

undefined8 __thiscall FUN_005fb520(int param_1,uint param_2)

{
  uint *puVar1;
  uint *puVar2;
  undefined8 uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  puVar1 = (uint *)(param_1 + (param_2 + 0x15) * 8);
  uVar7 = *puVar1;
  uVar6 = puVar1[1];
  uVar3 = *(undefined8 *)puVar1;
  if (*(int *)(param_1 + 0x9c) == 0) {
    *(undefined4 *)(param_1 + 0xa8) = 0;
    *(undefined4 *)(param_1 + 0xac) = 0;
    *(undefined4 *)(param_1 + 0xb0) = 3;
    *(undefined4 *)(param_1 + 0xb4) = 0;
    *(undefined4 *)(param_1 + 0xb8) = 10;
    *(undefined4 *)(param_1 + 0xbc) = 0;
    *(undefined4 *)(param_1 + 0xc0) = 0x1b;
    *(undefined4 *)(param_1 + 0xc4) = 0;
    return uVar3;
  }
  puVar2 = *(uint **)(param_1 + 0x98);
  uVar5 = *(uint *)(puVar2[2] + 0x4c);
  uVar4 = uVar5 << ((byte)uVar5 & 0x1f);
  uVar8 = (uVar5 - uVar4) + *puVar2;
  uVar5 = ((((int)uVar5 >> 0x1f) - ((int)uVar4 >> 0x1f)) - (uint)(uVar5 < uVar4)) + puVar2[1] +
          (uint)CARRY4(uVar5 - uVar4,*puVar2);
  if ((uVar6 <= uVar5) && ((uVar6 < uVar5 || (uVar7 < uVar8)))) {
    uVar6 = param_2 << ((byte)param_2 & 0x1f);
    uVar7 = uVar6 + param_2 + uVar8;
    uVar6 = ((int)uVar6 >> 0x1f) + ((int)param_2 >> 0x1f) + (uint)CARRY4(uVar6,param_2) + uVar5 +
            (uint)CARRY4(uVar6 + param_2,uVar8);
  }
  uVar5 = param_2 + 1 << ((byte)param_2 & 0x1f);
  *puVar1 = uVar5 + param_2 + uVar7;
  puVar1[1] = ((int)uVar5 >> 0x1f) + ((int)param_2 >> 0x1f) + (uint)CARRY4(uVar5,param_2) + uVar6 +
              (uint)CARRY4(uVar5 + param_2,uVar7);
  return CONCAT44(uVar6,uVar7);
}



/* FUNCTION 6152 ; VA 0x005fb630 ; FUN_005fb630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_005fb630(int param_1,undefined4 *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  double dVar6;
  double dVar7;
  longlong lVar8;
  
  FUN_006a6920();
  *(undefined4 *)(param_1 + 0xe8) = *(undefined4 *)(param_1 + 0x858);
  dVar6 = 0.0;
  *(undefined4 *)(param_1 + 0xec) = *(undefined4 *)(param_1 + 0x85c);
  *(undefined4 *)(param_1 + 0x120) = *(undefined4 *)(param_1 + 0x850);
  *(undefined4 *)(param_1 + 0x124) = *(undefined4 *)(param_1 + 0x854);
  *(undefined4 *)(param_1 + 0xf0) = *(undefined4 *)(param_1 + 0x878);
  *(undefined4 *)(param_1 + 0xf4) = *(undefined4 *)(param_1 + 0x87c);
  *(undefined4 *)(param_1 + 0x128) = *(undefined4 *)(param_1 + 0x870);
  *(undefined4 *)(param_1 + 300) = *(undefined4 *)(param_1 + 0x874);
  *(undefined4 *)(param_1 + 0xf8) = *(undefined4 *)(param_1 + 0x898);
  *(undefined4 *)(param_1 + 0xfc) = *(undefined4 *)(param_1 + 0x89c);
  *(undefined4 *)(param_1 + 0x130) = *(undefined4 *)(param_1 + 0x890);
  *(undefined4 *)(param_1 + 0x134) = *(undefined4 *)(param_1 + 0x894);
  *(undefined4 *)(param_1 + 0x100) = *(undefined4 *)(param_1 + 0x8b8);
  *(undefined4 *)(param_1 + 0x104) = *(undefined4 *)(param_1 + 0x8bc);
  *(undefined4 *)(param_1 + 0x138) = *(undefined4 *)(param_1 + 0x8b0);
  *(undefined4 *)(param_1 + 0x13c) = *(undefined4 *)(param_1 + 0x8b4);
  *(undefined4 *)(param_1 + 0x108) = *(undefined4 *)(param_1 + 0x8d8);
  *(undefined4 *)(param_1 + 0x10c) = *(undefined4 *)(param_1 + 0x8dc);
  *(undefined4 *)(param_1 + 0x140) = *(undefined4 *)(param_1 + 0x8d0);
  *(undefined4 *)(param_1 + 0x144) = *(undefined4 *)(param_1 + 0x8d4);
  *(undefined4 *)(param_1 + 0x110) = *(undefined4 *)(param_1 + 0x8f8);
  *(undefined4 *)(param_1 + 0x114) = *(undefined4 *)(param_1 + 0x8fc);
  *(undefined4 *)(param_1 + 0x148) = *(undefined4 *)(param_1 + 0x8f0);
  *(undefined4 *)(param_1 + 0x14c) = *(undefined4 *)(param_1 + 0x8f4);
  *(undefined4 *)(param_1 + 0x118) = *(undefined4 *)(param_1 + 0x918);
  *(undefined4 *)(param_1 + 0x11c) = *(undefined4 *)(param_1 + 0x91c);
  *(undefined4 *)(param_1 + 0x150) = *(undefined4 *)(param_1 + 0x910);
  *(undefined4 *)(param_1 + 0x154) = *(undefined4 *)(param_1 + 0x914);
  puVar4 = (undefined4 *)(param_1 + 0xe8);
  puVar5 = param_2;
  for (iVar2 = 0x58; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar5 = *puVar4;
    puVar4 = puVar4 + 1;
    puVar5 = puVar5 + 1;
  }
  if ((param_2[3] + param_2[5] + (uint)CARRY4(param_2[2],param_2[4]) != 0) ||
     (param_2[2] + param_2[4] != 0)) {
    FUN_016f3fe0();
    dVar7 = dVar6;
    FUN_016f3fe0();
    dVar6 = (double)(ulonglong)(uint)(float)(dVar6 / (dVar7 + dVar6));
  }
  param_2[0x36] = SUB84(dVar6,0);
  param_2[0x37] = 0;
  uVar1 = param_2[0x10];
  iVar2 = uVar1 + param_2[0x12];
  iVar3 = param_2[0x11] + param_2[0x13] + (uint)CARRY4(uVar1,param_2[0x12]);
  if ((iVar2 != 0 || iVar3 != 0) &&
     (lVar8 = FUN_016f3c60(uVar1,param_2[0x11],iVar2,iVar3), lVar8 != 0)) {
    FUN_016f3fe0();
    dVar7 = dVar6;
    FUN_016f3fe0();
    dVar7 = dVar7 + dVar6;
    if ((NAN(dVar7) || NAN(_PTR_018c6f48)) == (dVar7 == _PTR_018c6f48)) {
      param_2[0x37] = (float)(dVar6 / dVar7);
    }
  }
  *(undefined *)(param_2 + 0x1e) = *(undefined *)(param_1 + 0x160);
  param_2[0x20] = *(undefined4 *)(param_1 + 0x168);
  param_2[0x21] = *(undefined4 *)(param_1 + 0x16c);
  *(undefined *)(param_2 + 0x22) = *(undefined *)(param_1 + 0x170);
  param_2[0x24] = *(undefined4 *)(param_1 + 0x178);
  param_2[0x25] = *(undefined4 *)(param_1 + 0x17c);
  return param_2;
}



/* FUNCTION 6153 ; VA 0x005fb8c0 ; FUN_005fb8c0 */

undefined4 __fastcall FUN_005fb8c0(int param_1)

{
  return *(undefined4 *)(param_1 + 0xe0);
}



/* FUNCTION 6154 ; VA 0x005fb8d0 ; FUN_005fb8d0 */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall
FUN_005fb8d0(int *param_1,int *param_2,uint param_3,undefined4 *param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,uint param_8,uint param_9,uint param_10,
            char param_11)

{
  uint *puVar1;
  longlong lVar2;
  char *pcVar3;
  int iVar4;
  char cVar5;
  int iVar6;
  uint uVar7;
  undefined *puVar8;
  int iVar9;
  int iVar10;
  undefined4 *******pppppppuVar11;
  int *piVar12;
  int *piVar13;
  int *piVar14;
  byte bVar15;
  uint uVar16;
  float10 fVar17;
  float10 fVar18;
  undefined8 uVar19;
  uint uStack0000002c;
  undefined auStack_5a4 [1028];
  undefined auStack_1a0 [284];
  undefined4 *******apppppppuStack_84 [5];
  uint uStack_70;
  uint uStack_6c;
  int iStack_68;
  undefined4 uStack_64;
  char cStack_5c;
  char cStack_5b;
  undefined uStack_5a;
  undefined uStack_59;
  undefined uStack_58;
  char cStack_57;
  char cStack_56;
  uint uStack_50;
  int *piStack_4c;
  undefined4 *******apppppppuStack_48 [3];
  int iStack_3c;
  undefined8 uStack_38;
  undefined8 uStack_30;
  uint uStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ca23;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if (DAT_01ee420b != '\0') {
    ExceptionList = &pvStack_10;
    FUN_005f7b20(1,auStack_5a4,0x401);
  }
  puVar1 = (uint *)(param_1 + 0x76);
  uVar16 = *puVar1;
  *puVar1 = *puVar1 + param_3;
  param_1[0x77] = param_1[0x77] + (uint)CARRY4(uVar16,param_3);
  FUN_005fdd50(param_8,param_9,param_3);
  if ((DAT_01eace54 != 0) && (param_11 != '\0')) {
    param_1[0xa4] = param_1[0xa4] + param_3;
    param_1[0xa5] = param_1[0xa5] + 1;
  }
  if ((param_3 < 3) || (param_2 == (int *)0x0)) {
    if (DAT_01ee420b != '\0') {
      FUN_01677520(DAT_01ee420b,
                   "Incoming packet error: length <= 2 || buffer == 0, length=%d, address=%s",
                   param_3 << 3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  iVar6 = FUN_006a6900();
  param_1[0x25] = iVar6;
  if ((*param_1 == 0) || (cVar5 = FUN_00686be0(), cVar5 == '\0')) {
LAB_005fcc81:
    *(undefined *)(param_1 + 0x37) = 1;
    ExceptionList = pvStack_10;
    return 0;
  }
  cVar5 = FUN_006864f0(param_2);
  if (cVar5 == '\0') {
    ExceptionList = pvStack_10;
    return 0;
  }
  iVar6 = param_3 - 0x12;
  if ((((iVar6 == 10) && (*param_2 == DAT_018c94d0)) && (param_2[1] == DAT_018c94d4)) &&
     (param_1 = piStack_14, *(short *)(param_2 + 2) == DAT_018c94d8)) goto LAB_005fcc81;
  FUN_006a5530();
  uStack_8 = 0;
  (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
  FUN_005fa450(auStack_1a0);
  if (cStack_57 == '\0') {
    piVar12 = piStack_20;
    if (DAT_01ee420b != '\0') {
      FUN_01677520(DAT_01ee420b,"Incoming packet error: dhf.isValid==false, length=%d, address=%s",
                   iVar6 * 8);
      FUN_006a5640();
      ExceptionList = pvStack_10;
      return 1;
    }
    goto LAB_005fcc5d;
  }
  if (cStack_5c == '\0') {
    if (cStack_5b == '\0') {
      cVar5 = (**(code **)(*(int *)param_1[0x1ec] + 0x2c))
                        (uStack_64,
                         CONCAT13(cStack_56,CONCAT12(cStack_57,CONCAT11(uStack_58,uStack_59))),
                         param_8,param_9,iVar6);
      piVar12 = piStack_4c;
      if (cVar5 == '\0') {
        piVar12 = piStack_20;
        if (DAT_01ee420b != '\0') {
          FUN_01677520(DAT_01ee420b,
                       "Incoming packet error: congestionManager->OnGotPacket failed, length=%d, address=%s"
                       ,iVar6 * 8);
          FUN_006a5640();
          ExceptionList = pvStack_10;
          return 1;
        }
        goto LAB_005fcc5d;
      }
      for (; piVar12 != (int *)0x0; piVar12 = (int *)((int)piVar12 + -1)) {
        FUN_005fd4b0();
        param_1 = piStack_14;
      }
      *(undefined *)(param_1 + 0x20d) = uStack_58;
      (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
      FUN_005ff3f0();
      piStack_20 = (int *)FUN_005f9fe0();
      if (piStack_20 == (int *)0x0) {
        piStack_1c = (int *)0x0;
        piVar12 = (int *)0x0;
        if (DAT_01ee420b != '\0') {
          piStack_1c = piStack_20;
          FUN_01677520(DAT_01ee420b,
                       "Incoming packet error: CreateInternalPacketFromBitStream failed, length=%d, address=%s"
                       ,iVar6 * 8);
          FUN_006a5640();
          ExceptionList = pvStack_10;
          return 1;
        }
        goto LAB_005fcc5d;
      }
      do {
        piStack_1c = piStack_20;
        if ((DAT_01d5b280 == '\0') && (param_2 = (int *)0x0, param_5[1] != 0)) {
          uVar19 = FUN_016f3c60(param_8,param_9,1000);
          do {
            uStack_50 = (uint)((ulonglong)uVar19 >> 0x20);
            piStack_18 = (int *)uVar19;
            (**(code **)(**(int **)(*param_5 + (int)param_2 * 4) + 0x48))
                      (piStack_1c,param_1[0x1e2],*param_4,param_4[1],param_4[2],param_4[3],
                       param_4[4],param_4[5],param_4[6],param_4[7],piStack_18);
            uVar19 = CONCAT44(uStack_50,piStack_18);
            param_2 = (int *)((int)param_2 + 1);
          } while (param_2 < (uint)param_5[1]);
        }
        piVar12 = piStack_1c;
        if (*(char *)(param_1 + 0x1cd) == '\0') {
          piStack_24 = param_1 + 0x1c8;
        }
        else {
          piStack_24 = param_1 + 0x1c8;
          FUN_01674ea0();
          iVar10 = FUN_01674e20(0x200);
          param_1[0x1c8] = iVar10;
          param_1[0x1cb] = 0x200;
          param_1[0x1c9] = 0;
          param_1[0x1ca] = 0;
          param_1[0x1cc] = 0;
          *(undefined2 *)((int)param_1 + 0x733) = 0;
        }
        piVar14 = piStack_1c;
        iVar10 = piVar12[7];
        if ((((iVar10 == 4) || (iVar10 == 1)) || (iVar10 == 3)) && (0x1f < *(byte *)(piVar12 + 3)))
        {
          if (DAT_01ee420b != '\0') {
            FUN_01677520(DAT_01ee420b,
                         "Incoming packet error: internalPacket->orderingChannel >= NUMBER_OF_ORDERED_STREAMS, length=%d, address=%s"
                         ,iVar6 * 8);
          }
          FUN_005fdd50(param_8,param_9,piVar12[6] + 7U >> 3);
          if ((DAT_01eace54 != 0) && (param_11 != '\0')) {
            param_1[0xa6] = param_1[0xa6] + (piVar12[6] + 7U >> 3);
            param_1[0xa7] = param_1[0xa7] + 1;
          }
          goto LAB_005fcc1b;
        }
        if (((iVar10 == 2) || (iVar10 == 4)) || (iVar10 == 3)) {
          uVar16 = *piVar12 - param_1[0x1cc] & 0xffffff;
          if (uVar16 != 0) {
            if (uVar16 < 0x800000) {
              uVar7 = FUN_005ffa80();
              piVar14 = piStack_14;
              piVar12 = piStack_1c;
              if (uVar16 < uVar7) {
                iVar10 = param_1[0x1c9];
                piVar13 = param_1 + 0x1c8;
                if (iVar10 + uVar16 < (uint)param_1[0x1cb]) {
                  param_2 = (int *)(*piVar13 + iVar10);
                  iVar9 = iVar10 - param_1[0x1cb];
                }
                else {
                  iVar9 = iVar10 - param_1[0x1cb];
                  param_2 = (int *)(*piVar13 + iVar9);
                }
                if (*(char *)((int)param_2 + uVar16) != '\0') {
                  if (iVar10 + uVar16 < (uint)param_1[0x1cb]) {
                    iVar9 = iVar10;
                  }
                  *(undefined *)(iVar9 + *piVar13 + uVar16) = 0;
                  param_1 = piStack_14;
                  goto LAB_005fc760;
                }
                FUN_005fdd50(param_8,param_9,piStack_1c[6] + 7U >> 3);
                param_1 = piVar14;
                if ((DAT_01eace54 != 0) && (param_11 != '\0')) {
                  piVar14[0xa6] = piVar14[0xa6] + (piVar12[6] + 7U >> 3);
                  piVar14[0xa7] = piVar14[0xa7] + 1;
                }
              }
              else {
                if (uVar16 < 0xf4241) {
                  uVar7 = FUN_005ffa80();
                  while (uVar7 < uVar16) {
                    FUN_005fe240();
                    uVar7 = FUN_005ffa80();
                    param_1 = piStack_14;
                  }
                  FUN_005fe240();
                  goto LAB_005fc750;
                }
                if (DAT_01ee420b != '\0') {
                  FUN_01677520(DAT_01ee420b,
                               "Incoming packet error: holeCount > 1000000, length=%d, address=%s",
                               iVar6 * 8);
                }
                piVar12 = piStack_1c;
                FUN_005fdd50(param_8,param_9,piStack_1c[6] + 7U >> 3);
                if ((DAT_01eace54 != 0) && (param_11 != '\0')) {
                  param_1[0xa6] = param_1[0xa6] + (piVar12[6] + 7U >> 3);
                  param_1[0xa7] = param_1[0xa7] + 1;
                }
              }
            }
            else {
              FUN_005fdd50(param_8,param_9,piStack_1c[6] + 7U >> 3);
              if ((DAT_01eace54 != 0) && (param_11 != '\0')) {
                param_1[0xa6] = param_1[0xa6] + (piVar14[6] + 7U >> 3);
                param_1[0xa7] = param_1[0xa7] + 1;
              }
            }
            goto LAB_005fcc1b;
          }
          iVar10 = FUN_005ffa80();
          if (iVar10 != 0) {
            FUN_005fdd20();
          }
          param_1[0x1cc] = param_1[0x1cc] + 1;
          *(undefined *)((int)param_1 + 0x733) = 0;
LAB_005fc750:
          piVar13 = param_1 + 0x1c8;
LAB_005fc760:
          while( true ) {
            uVar16 = param_1[0x1c9];
            if ((uint)param_1[0x1ca] < uVar16) {
              iVar10 = param_1[0x1cb] - uVar16;
            }
            else {
              iVar10 = -uVar16;
            }
            piVar12 = piStack_1c;
            if ((param_1[0x1ca] + iVar10 == 0) || (*(char *)(uVar16 + *piVar13) != '\0')) break;
            param_1[0x1c9] = uVar16 + 1;
            if (uVar16 + 1 == param_1[0x1cb]) {
              param_1[0x1c9] = 0;
            }
            param_1[0x1cc] = param_1[0x1cc] + 1;
            *(undefined *)((int)param_1 + 0x733) = 0;
          }
        }
        if (((0x200 < (uint)param_1[0x1cb]) &&
            (iVar10 = FUN_005ffa80(), (uint)(iVar10 * 3) < (uint)param_1[0x1cb])) &&
           (puVar1 = (uint *)(param_1 + 0x1cb), param_1[0x1cb] != 0)) {
          uStack_28 = 1;
          uVar16 = FUN_005ffa80();
          if (uVar16 == 0) {
LAB_005fc82b:
            piStack_18 = (int *)FUN_01674e20();
          }
          else {
            do {
              uStack_28 = uStack_28 * 2;
            } while (uStack_28 <= uVar16);
            if (uStack_28 != 0) goto LAB_005fc82b;
            piStack_18 = (int *)0x0;
          }
          uStack_50 = 0;
          iVar10 = FUN_005ffa80();
          piVar14 = piStack_24;
          uVar16 = uStack_50;
          if (iVar10 != 0) {
            do {
              *(undefined *)(uVar16 + (int)piStack_18) =
                   *(undefined *)((piVar14[1] + uVar16) % *puVar1 + *piVar14);
              uVar16 = uVar16 + 1;
              uVar7 = FUN_005ffa80();
              piVar12 = piStack_1c;
              param_1 = piStack_14;
            } while (uVar16 < uVar7);
          }
          uVar16 = param_1[0x1c9];
          uVar7 = param_1[0x1ca];
          if (uVar7 < uVar16) {
            iVar10 = (uVar7 - uVar16) + *puVar1;
          }
          else {
            iVar10 = uVar7 - uVar16;
          }
          param_1[0x1ca] = iVar10;
          *puVar1 = uStack_28;
          param_1[0x1c9] = 0;
          FUN_01674ea0();
          param_1[0x1c8] = (int)piStack_18;
        }
        if (piVar12[5] == 0) {
LAB_005fc9a9:
          iVar10 = piVar12[7];
          if (((iVar10 == 4) || (iVar10 == 1)) || (iVar10 == 3)) {
            if (piVar12[1] == param_1[*(byte *)(piVar12 + 3) + 0xe8]) {
              if ((iVar10 == 4) || (iVar10 == 1)) {
                cVar5 = FUN_005fdad0(piVar12[2]);
                if (cVar5 != '\0') goto LAB_005fcc1b;
                param_1[*(byte *)(piVar12 + 3) + 0x108] = piVar12[2];
                goto LAB_005fcb26;
              }
              FUN_005fdd50(param_8,param_9,piVar12[6] + 7U >> 3);
              FUN_005fe020();
              bVar15 = *(byte *)(piVar12 + 3);
              param_1[bVar15 + 0xe8] = param_1[bVar15 + 0xe8] + 1;
              *(undefined *)((int)param_1 + (uint)bVar15 * 4 + 0x3a3) = 0;
              param_1[*(byte *)(piVar12 + 3) + 0x108] = 0;
              bVar15 = *(byte *)(piVar12 + 3);
              iVar10 = param_1[(uint)bVar15 * 4 + 0x129];
              while ((iVar10 != 0 &&
                     (*(int *)(*(int *)(param_1[(bVar15 + 0x4a) * 4] + 8) + 4) ==
                      param_1[bVar15 + 0xe8]))) {
                piVar12 = (int *)FUN_005fdbb0();
                piStack_20 = piVar12;
                FUN_005fdd50(param_8,param_9,piVar12[6] + 7U >> 3);
                FUN_005fe020();
                if (piVar12[7] == 3) {
                  bVar15 = *(byte *)(piVar12 + 3);
                  param_1[bVar15 + 0xe8] = param_1[bVar15 + 0xe8] + 1;
                  *(undefined *)((int)param_1 + (uint)bVar15 * 4 + 0x3a3) = 0;
                }
                else {
                  param_1[*(byte *)(piVar12 + 3) + 0x108] = piVar12[2];
                }
                bVar15 = *(byte *)(piVar12 + 3);
                iVar10 = param_1[(uint)bVar15 * 4 + 0x129];
              }
            }
            else {
              cVar5 = FUN_005fdad0(piVar12[1]);
              if (cVar5 == '\0') {
                bVar15 = *(byte *)(piVar12 + 3);
                uVar16 = (uint)bVar15;
                if (param_1[uVar16 * 4 + 0x129] == 0) {
                  param_1[uVar16 + 0x1a8] = param_1[uVar16 + 0xe8];
                  bVar15 = *(byte *)(piVar12 + 3);
                }
                uStack_50 = (uint)bVar15;
                lVar2 = (ulonglong)(piVar12[1] - param_1[uStack_50 + 0x1a8] & 0xffffff) * 0x100000;
                if ((piVar12[7] == 4) || (piVar12[7] == 1)) {
                  uStack_30 = (double)(lVar2 + (ulonglong)(uint)piVar12[2]);
                }
                else {
                  uStack_30 = (double)(lVar2 + 0xfffff);
                }
                FUN_005fdef0(&uStack_30,&piStack_20,
                             "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                            );
              }
              else {
LAB_005fcc1b:
                FUN_005fa670();
                FUN_005fe570();
              }
            }
          }
          else {
LAB_005fcb26:
            FUN_005fdd50(param_8,param_9,piVar12[6] + 7U >> 3);
            FUN_005fe020();
          }
        }
        else {
          iVar10 = piVar12[7];
          if (((iVar10 != 3) && (iVar10 != 4)) && (iVar10 != 1)) {
            *(undefined *)(piVar12 + 3) = 0xff;
          }
          FUN_005fd650();
          uStack_38 = (ulonglong)CONCAT24(*(undefined2 *)((int)piVar12 + 0xe),(uint)uStack_38);
          piStack_18 = param_1 + 0x32;
          uStack_50 = FUN_005fb220();
          iVar10 = *(int *)(param_1[0x32] + uStack_50 * 4);
          if (*(int *)(iVar10 + 0x20) == *(int *)(iVar10 + 0x2c)) {
            FUN_005feff0(param_7,param_4,param_8,param_9,param_10);
            piVar12 = (int *)FUN_005f9a70();
            param_2 = (int *)param_1[0x33];
            piStack_1c = piVar12;
            if (uStack_50 < param_2) {
              piVar14 = param_1 + 0x32;
              uVar16 = uStack_50;
              if (uStack_50 < (int)param_2 - 1U) {
                do {
                  *(undefined4 *)(*piStack_18 + uVar16 * 4) =
                       *(undefined4 *)(*piStack_18 + 4 + uVar16 * 4);
                  uVar16 = uVar16 + 1;
                  param_2 = (int *)piStack_18[1];
                  piVar14 = piStack_18;
                  param_1 = piStack_14;
                } while (uVar16 < (int)param_2 - 1U);
              }
              piVar14[1] = (int)param_2 - 1;
            }
          }
          else {
            piVar12 = (int *)0x0;
          }
          piStack_20 = piVar12;
          if (piVar12 != (int *)0x0) goto LAB_005fc9a9;
        }
        piStack_20 = (int *)FUN_005f9fe0();
        piStack_1c = piStack_20;
      } while (piStack_20 != (int *)0x0);
    }
    else {
      iStack_3c = 0;
      uStack_38 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      cVar5 = FUN_005fa230();
      if (cVar5 == '\0') {
        if (DAT_01ee420b != '\0') {
          pcVar3 = "Incoming packet error: incomingNAKs.Deserialize failed, length=%d, address=%s";
LAB_005fc249:
          FUN_01677520(DAT_01ee420b,pcVar3,iVar6 * 8);
        }
LAB_005fc255:
        FUN_005f9040();
        goto LAB_005fbf3e;
      }
      _param_11 = 0;
      param_10 = 0;
      iVar10 = iStack_3c;
      if ((uint)uStack_38 != 0) {
        do {
          uStack0000002c = *(uint *)(iVar10 + param_10 * 8);
          uVar16 = *(uint *)(iVar10 + 4 + param_10 * 8);
          if (uVar16 < uStack0000002c) {
            if (DAT_01ee420b == '\0') goto LAB_005fc255;
            pcVar3 = "Incoming packet error: incomingNAKs minIndex>maxIndex, length=%d, address=%s";
            goto LAB_005fc249;
          }
          uVar16 = uVar16 - uStack0000002c & 0xffffff;
          _param_11 = _param_11 + uVar16;
          if (DAT_01d59cc8 < (int)uVar16) {
LAB_005fc218:
            *(undefined *)(param_1 + 0x37) = 1;
            FUN_005f9040();
            goto LAB_005fbf3e;
          }
          if ((DAT_01d59d50 != '\0') &&
             ((uint)(param_1[0x1ee] * DAT_01d59cd0 + _DAT_01d59cd8) < _param_11)) {
            if (DAT_01d59d58 != '\0') {
              FUN_005f7ae0(0);
              FUN_01675640(apppppppuStack_84,"RakNet ACK NAK exploit total NAKs %d address %s",
                           _param_11);
              pppppppuVar11 = apppppppuStack_84;
              if (0xf < uStack_70) {
                pppppppuVar11 = apppppppuStack_84[0];
              }
              uStack_8 = CONCAT31(uStack_8._1_3_,3);
              FUN_0087c6f0("Security","RakNet exploit",pppppppuVar11,0,0,0,3);
              if (DAT_01eacd99 != '\0') {
                FUN_01677650();
              }
              FUN_005507b0();
            }
            if (DAT_01d59d60 != '\0') goto LAB_005fc218;
            goto LAB_005fc255;
          }
          do {
            if (*(uint *)(iVar10 + 4 + param_10 * 8) < uStack0000002c) break;
            (**(code **)(*(int *)param_1[0x1ec] + 0x34))();
            iVar9 = FUN_005fb470(uStack0000002c);
            piVar12 = piStack_14;
            iVar10 = iStack_3c;
            for (; iStack_3c = iVar10, iVar9 != 0; iVar9 = *(int *)(iVar9 + 4)) {
              iVar10 = FUN_005feb30();
              iVar4 = DAT_01eacda0;
              iVar10 = *(int *)(piVar12[0x1d] + iVar10 * 4);
              if (iVar10 != 0) {
                if (*(int *)(iVar10 + 0x30) != 0 || *(int *)(iVar10 + 0x34) != 0) {
                  if (DAT_01eacd9c == 0) {
                    if (DAT_01eacda0 == 0) {
                      *(uint *)(iVar10 + 0x30) = param_8;
                      *(uint *)(iVar10 + 0x34) = param_9;
                    }
                    else {
LAB_005fc0b7:
                      uVar16 = DAT_01eacd9c * 1000;
                      if ((uVar16 == 0) && (0 < DAT_01eacda0)) {
                        fVar17 = (float10)(**(code **)(*(int *)piVar12[0x1ec] + 0x60))();
                        uStack_30 = (double)fVar17;
                        uVar19 = FUN_016f3ec0();
                        uVar19 = FUN_016f39b0(uVar19,iVar4);
                        uVar16 = FUN_016f3c60(uVar19,100);
                        uVar7 = DAT_01eacda4 * 1000;
                        if ((uVar7 != 0) && ((int)uVar7 < (int)uVar16)) {
                          uVar16 = uVar7;
                        }
                      }
                      *(uint *)(iVar10 + 0x30) = uVar16 + param_8;
                      *(uint *)(iVar10 + 0x34) =
                           ((int)uVar16 >> 0x1f) + param_9 + (uint)CARRY4(uVar16,param_8);
                    }
                  }
                  else if (DAT_01eacd9c != -1) goto LAB_005fc0b7;
                }
                if (*(char *)(iVar10 + 0x4a) != '\0') {
                  uVar7 = (*(int *)(iVar10 + 0x38) + 7U >> 3) + (*(int *)(iVar10 + 0x18) + 7U >> 3);
                  puVar1 = (uint *)(piVar12 + 0x86);
                  uVar16 = *puVar1;
                  *puVar1 = *puVar1 + uVar7;
                  piVar12[0x87] = piVar12[0x87] + (uint)CARRY4(uVar16,uVar7);
                }
              }
              param_1 = piStack_14;
              iVar10 = iStack_3c;
            }
            uStack0000002c = uStack0000002c + 1 & 0xffffff;
          } while (*(uint *)(iVar10 + param_10 * 8) <= uStack0000002c);
          param_10 = param_10 + 1;
        } while (param_10 < (uint)uStack_38);
      }
      FUN_005f9040();
    }
  }
  else {
    uStack_30 = 0.0;
    cVar5 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
    if (cVar5 == '\0') {
      uStack0000002c = uStack_30._4_4_;
      param_5 = (int *)(uint)uStack_30;
    }
    else {
      param_5 = (int *)(param_8 - uStack_6c);
      if ((-(uint)(param_8 < uStack_6c) != iStack_68) || (uStack0000002c = 0, 10000000 < param_5)) {
        fVar17 = (float10)(**(code **)(*(int *)param_1[0x1ec] + 0x60))();
        fVar18 = (float10)_DAT_018c9d50;
        uStack_38 = 0;
        uStack_38._4_4_ = 0;
        iVar10 = uStack_38._4_4_;
        if ((fVar18 <= fVar17) && (fVar17 - fVar18 < fVar18)) {
          iVar10 = -0x80000000;
        }
        uVar19 = FUN_016f41c0();
        param_5 = (int *)uVar19;
        uStack0000002c = (int)((ulonglong)uVar19 >> 0x20) + iVar10;
      }
      param_1[0x1d4] = (int)param_5;
      param_1[0x1d5] = uStack0000002c;
    }
    piStack_4c = param_1 + 0x204;
    FUN_005f9e60();
    cVar5 = FUN_005fa230();
    if (cVar5 == '\0') {
      if (DAT_01ee420b != '\0') {
        pcVar3 = "Incoming packet error: incomingAcks.Deserialize failed, length=%d, address=%s";
LAB_005fbf32:
        FUN_01677520(DAT_01ee420b,pcVar3,iVar6 * 8);
      }
LAB_005fbf3e:
      FUN_006a5640();
      ExceptionList = pvStack_10;
      return 0;
    }
    piStack_24 = (int *)0x0;
    if (cStack_56 != '\0') {
      FUN_005f7fd0();
      FUN_005f7fd0();
    }
    piStack_20 = (int *)0x0;
    param_10 = 0;
    piVar12 = param_1 + 0x204;
    if (piStack_14[0x205] != 0) {
      do {
        piVar14 = piStack_14;
        iVar10 = *piVar12;
        uVar16 = *(uint *)(iVar10 + param_10 * 8);
        uVar7 = *(uint *)(iVar10 + 4 + param_10 * 8);
        uStack_28 = uVar16;
        if (uVar7 < uVar16 || uVar7 == 0xffffff) {
          if (DAT_01ee420b == '\0') goto LAB_005fbf3e;
          pcVar3 = "Incoming packet error: incomingAcks minIndex > maxIndex, length=%d, address=%s";
          goto LAB_005fbf32;
        }
        uVar7 = uVar7 - uVar16 & 0xffffff;
        piStack_20 = (int *)((int)piStack_20 + uVar7);
        if (DAT_01d59cc8 < (int)uVar7) {
          *(undefined *)(piStack_14 + 0x37) = 1;
          FUN_006a5640();
          ExceptionList = pvStack_10;
          return 0;
        }
        if ((DAT_01d59d50 != '\0') &&
           ((int *)(piStack_14[0x1ee] * DAT_01d59cd0 + _DAT_01d59cd8) < piStack_20)) {
          if (DAT_01d59d58 != '\0') {
            FUN_005f7ae0(0);
            FUN_01675640(apppppppuStack_48,"RakNet ACK NAK exploit total ACKs %d address %s",
                         piStack_20);
            pppppppuVar11 = apppppppuStack_48;
            if (0xf < uStack_38._4_4_) {
              pppppppuVar11 = apppppppuStack_48[0];
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            FUN_0087c6f0("Security","RakNet exploit",pppppppuVar11,0,0,0,3);
            if (DAT_01eacd99 != '\0') {
              FUN_01677650();
            }
            FUN_005507b0();
          }
          if (DAT_01d59d60 != '\0') {
            *(undefined *)(piStack_14 + 0x37) = 1;
            FUN_006a5640();
            ExceptionList = pvStack_10;
            return 0;
          }
          goto LAB_005fbf3e;
        }
        do {
          uStack_28 = uVar16;
          if (*(uint *)(iVar10 + 4 + param_10 * 8) < uVar16) break;
          uStack_38 = 0;
          if (piVar14[0x15] != 0) {
            _param_11 = 0;
            param_2 = (int *)0x0;
            do {
              if (*(uint *)(piVar14[0x14] + (int)param_2) == uVar16) {
                piStack_18 = (int *)FUN_005f98f0();
                piStack_18[0x10] = 0;
                puVar8 = (undefined *)FUN_01674f30();
                piStack_18[0xf] = (int)puVar8;
                piStack_18[6] = 0x28;
                *puVar8 = 0xe;
                *(undefined4 *)(piStack_18[0xf] + 1) =
                     *(undefined4 *)((int)param_2 + 4 + piVar14[0x14]);
                FUN_005fe020();
                FUN_005fe650();
              }
              else {
                _param_11 = _param_11 + 1;
                param_2 = (int *)((int)param_2 + 0x10);
              }
            } while (_param_11 < (uint)piVar14[0x15]);
          }
          piStack_18 = (int *)FUN_005fb470(uVar16);
          if ((DAT_01d59d20 == '\0') && (piStack_18 != (int *)0x0)) {
LAB_005fbcfb:
            cVar5 = (**(code **)(*(int *)piVar14[0x1ec] + 0x6c))();
            if (cVar5 == '\0') {
              if ((param_9 < uStack_38._4_4_) ||
                 ((param_9 <= uStack_38._4_4_ && (param_8 <= (uint)uStack_38)))) {
                uStack_30 = 0.0;
                _param_11 = 0;
                param_2 = (int *)0x0;
              }
              else {
                param_2 = (int *)(param_8 - (uint)uStack_38);
                _param_11 = (param_9 - uStack_38._4_4_) - (uint)(param_8 < (uint)uStack_38);
              }
            }
            else {
              param_2 = param_5;
              _param_11 = uStack0000002c;
            }
            piStack_1c = (int *)piVar14[0x1ec];
            (**(code **)(*piStack_1c + 0x38))
                      (param_8,param_9,param_2,_param_11,
                       CONCAT13(cStack_57,CONCAT12(uStack_58,CONCAT11(uStack_59,uStack_5a))));
          }
          else if ((uint)uStack_38 != 0 || uStack_38._4_4_ != 0) goto LAB_005fbcfb;
          piVar12 = piStack_18;
          if (piStack_18 != (int *)0x0) {
            do {
              FUN_005fe820(*piVar12,param_8,param_9);
              uVar16 = uStack_28;
              piVar13 = piVar12 + 1;
              piVar12 = (int *)*piVar13;
            } while ((int *)*piVar13 != (int *)0x0);
            FUN_005fe6b0();
          }
          iVar10 = piVar14[0x204];
          uVar16 = uVar16 + 1 & 0xffffff;
          uStack_28 = uVar16;
        } while (*(uint *)(iVar10 + param_10 * 8) <= uVar16);
        param_10 = param_10 + 1;
        piVar12 = piStack_4c;
      } while (param_10 < (uint)piVar14[0x205]);
    }
    (**(code **)(*(int *)piStack_14[0x1ec] + 0x3c))(0);
  }
  piStack_14[0x1e2] = piStack_14[0x1e2] + 1;
  piVar12 = piStack_20;
LAB_005fcc5d:
  piStack_20 = piVar12;
  FUN_006a5640();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 6155 ; VA 0x005fcce0 ; FUN_005fcce0 */

void __fastcall FUN_005fcce0(int param_1)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  uint *puVar4;
  undefined8 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0170d1f0(param_1 + 0x2a0,0,0x200);
  FUN_0170d1f0(param_1 + 0xe8,0,0x160);
  FUN_0170d1f0(param_1 + 0x6a0,0,0x80);
  uVar5 = FUN_006a6920();
  *(undefined8 *)(param_1 + 0x158) = uVar5;
  *(undefined2 *)(param_1 + 0xde) = 0;
  *(undefined4 *)(param_1 + 0x7a0) = 0;
  *(undefined4 *)(param_1 + 0x7a4) = 0;
  *(undefined4 *)(param_1 + 0x780) = 0;
  *(undefined4 *)(param_1 + 0x784) = 0;
  *(undefined4 *)(param_1 + 0xd4) = 0;
  *(undefined *)(param_1 + 0xd7) = 0;
  *(undefined4 *)(param_1 + 0xd8) = 0;
  *(undefined *)(param_1 + 0xdb) = 0;
  *(undefined4 *)(param_1 + 0x808) = 0;
  *(undefined4 *)(param_1 + 0x80c) = 0;
  *(undefined4 *)(param_1 + 0x84) = 0;
  uVar5 = FUN_006a6920();
  *(undefined8 *)(param_1 + 0x738) = uVar5;
  *(undefined *)(param_1 + 0x778) = 0;
  *(undefined4 *)(param_1 + 0x768) = 0;
  *(undefined4 *)(param_1 + 0x76c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x930) = 0;
  *(undefined4 *)(param_1 + 0x934) = 0;
  *(undefined4 *)(param_1 + 0x770) = 0;
  *(undefined4 *)(param_1 + 0x774) = 0;
  *(undefined2 *)(param_1 + 0xdc) = 0;
  *(undefined4 *)(param_1 + 0x800) = 0;
  *(undefined4 *)(param_1 + 0x804) = 0;
  uVar2 = FUN_006a6900();
  *(undefined4 *)(param_1 + 0x94) = uVar2;
  *(undefined4 *)(param_1 + 0x1b0) = 0;
  *(undefined4 *)(param_1 + 0x1b8) = 0;
  *(undefined4 *)(param_1 + 0x1bc) = 0;
  *(undefined4 *)(param_1 + 0x730) = 0;
  *(undefined2 *)(param_1 + 0x733) = 0x100;
  *(undefined4 *)(param_1 + 0x748) = *(undefined4 *)(param_1 + 0x738);
  *(undefined4 *)(param_1 + 0x788) = 0;
  *(undefined4 *)(param_1 + 0x740) = 350000;
  *(undefined4 *)(param_1 + 0x744) = 0;
  *(undefined *)(param_1 + 0x760) = 0;
  *(undefined4 *)(param_1 + 0x758) = 0;
  *(undefined4 *)(param_1 + 0x75c) = 0;
  *(undefined4 *)(param_1 + 0x74c) = *(undefined4 *)(param_1 + 0x73c);
  *(undefined4 *)(param_1 + 0x7b4) = 0;
  *(undefined4 *)(param_1 + 0x7b8) = 0;
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(undefined4 *)(param_1 + 0x90) = 0;
  *(undefined8 *)(param_1 + 0x7f8) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined *)(param_1 + 0x5f) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  puVar4 = (uint *)(param_1 + 0x86c);
  *(undefined4 *)(param_1 + 0xa8) = 0;
  iVar3 = 7;
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 3;
  *(undefined4 *)(param_1 + 0xb4) = 0;
  *(undefined4 *)(param_1 + 0xb8) = 10;
  *(undefined4 *)(param_1 + 0xbc) = 0;
  *(undefined4 *)(param_1 + 0xc0) = 0x1b;
  *(undefined4 *)(param_1 + 0xc4) = 0;
  *(undefined4 *)(param_1 + 0x180) = 0;
  *(undefined4 *)(param_1 + 400) = 0;
  *(undefined4 *)(param_1 + 0x194) = 0;
  *(undefined4 *)(param_1 + 0x198) = 0;
  *(undefined4 *)(param_1 + 0x19c) = 0;
  *(undefined4 *)(param_1 + 0x184) = 0;
  *(undefined4 *)(param_1 + 0x188) = 0;
  *(undefined4 *)(param_1 + 0x1a0) = 0;
  *(undefined4 *)(param_1 + 0x1a4) = 0;
  *(undefined4 *)(param_1 + 0x1a8) = 0;
  *(undefined4 *)(param_1 + 0x1ac) = 0;
  *(undefined4 *)(param_1 + 0x18c) = 0;
  do {
    puVar4[-5] = 0;
    puVar4[-4] = 0;
    puVar4[-7] = 0;
    puVar4[-6] = 0;
    if (*puVar4 != 0) {
      if (0x20 < *puVar4) {
        uVar1 = puVar4[-3];
        if (uVar1 != 0) {
          uStack_8 = 0;
          FUN_016f32d1(uVar1,0x10,*(undefined4 *)(uVar1 - 4),_guard_check_icall);
          FUN_01674ea0((int *)(uVar1 - 4),*(int *)(uVar1 - 4) * 0x10 + 4);
        }
        *puVar4 = 0;
      }
      puVar4[-2] = 0;
      puVar4[-1] = 0;
    }
    puVar4 = puVar4 + 8;
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6156 ; VA 0x005fd010 ; FUN_005fd010 */

void __thiscall
FUN_005fd010(int *param_1,undefined4 *param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar4 = param_1[1];
  iVar3 = param_1[2];
  if (iVar4 == iVar3) {
    if (iVar3 == 0) {
      ExceptionList = &pvStack_10;
      param_1[2] = 0x10;
      iVar3 = 0x10;
    }
    else {
      iVar3 = iVar3 * 2;
      ExceptionList = &pvStack_10;
      param_1[2] = iVar3;
    }
    iVar3 = FUN_005f7cf0(iVar3,param_4,param_5);
    uVar5 = 0;
    if (param_1[1] != 0) {
      do {
        iVar2 = *param_1;
        iVar4 = uVar5 * 8;
        uVar5 = uVar5 + 1;
        *(undefined4 *)(iVar4 + iVar3) = *(undefined4 *)(iVar2 + iVar4);
        *(undefined4 *)(iVar4 + 4 + iVar3) = *(undefined4 *)(iVar2 + 4 + iVar4);
      } while (uVar5 < (uint)param_1[1]);
    }
    iVar4 = *param_1;
    if (iVar4 != 0) {
      uStack_8 = 0;
      FUN_016f32d1(iVar4,8,*(undefined4 *)(iVar4 + -4),_guard_check_icall);
      FUN_01674ea0((int *)(iVar4 + -4),*(int *)(iVar4 + -4) * 8 + 4);
    }
    iVar4 = param_1[1];
    *param_1 = iVar3;
  }
  else {
    iVar3 = *param_1;
  }
  if (iVar4 != param_3) {
    do {
      puVar1 = (undefined4 *)(*param_1 + iVar4 * 8);
      iVar4 = iVar4 + -1;
      *puVar1 = puVar1[-2];
      puVar1[1] = puVar1[-1];
    } while (iVar4 != param_3);
    iVar3 = *param_1;
  }
  *(undefined4 *)(iVar3 + param_3 * 8) = *param_2;
  *(undefined4 *)(iVar3 + 4 + param_3 * 8) = param_2[1];
  param_1[1] = param_1[1] + 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6157 ; VA 0x005fd110 ; FUN_005fd110 */

void __thiscall FUN_005fd110(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar3 = param_1[1];
  iVar2 = param_1[2];
  if (iVar3 == iVar2) {
    if (iVar2 == 0) {
      ExceptionList = &pvStack_10;
      param_1[2] = 0x10;
      iVar2 = 0x10;
    }
    else {
      iVar2 = iVar2 * 2;
      ExceptionList = &pvStack_10;
      param_1[2] = iVar2;
    }
    iVar2 = FUN_005f7cf0(iVar2,param_3,param_4);
    iVar3 = *param_1;
    if (iVar3 != 0) {
      uVar4 = 0;
      if (param_1[1] != 0) {
        do {
          puVar1 = (undefined4 *)(*param_1 + uVar4 * 8);
          *(undefined4 *)(iVar2 + uVar4 * 8) = *puVar1;
          *(undefined4 *)(iVar2 + 4 + uVar4 * 8) = puVar1[1];
          uVar4 = uVar4 + 1;
        } while (uVar4 < (uint)param_1[1]);
        iVar3 = *param_1;
      }
      if (iVar3 != 0) {
        uStack_8 = 0;
        FUN_016f32d1(iVar3,8,*(undefined4 *)(iVar3 + -4),_guard_check_icall);
        FUN_01674ea0((int *)(iVar3 + -4),*(int *)(iVar3 + -4) * 8 + 4);
      }
    }
    iVar3 = param_1[1];
    *param_1 = iVar2;
  }
  else {
    iVar2 = *param_1;
  }
  *(undefined4 *)(iVar2 + iVar3 * 8) = *param_2;
  *(undefined4 *)(iVar2 + 4 + iVar3 * 8) = param_2[1];
  param_1[1] = param_1[1] + 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6158 ; VA 0x005fd1f0 ; FUN_005fd1f0 */

void __thiscall FUN_005fd1f0(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ca51;
  pvStack_10 = ExceptionList;
  iVar7 = param_1[1];
  iVar5 = param_1[2];
  if (iVar7 != iVar5) {
    iStack_14 = *param_1;
    goto LAB_005fd2d9;
  }
  if (iVar5 == 0) {
    ExceptionList = &pvStack_10;
    param_1[2] = 0x10;
    uVar8 = 0x10;
LAB_005fd231:
    iStack_14 = FUN_01674e20(-(uint)((int)((ulonglong)uVar8 * 0x10 >> 0x20) != 0) |
                             (uint)((ulonglong)uVar8 * 0x10));
    uStack_8 = 0;
    if (iStack_14 == 0) {
      iStack_14 = 0;
    }
    else {
      for (; uVar8 != 0; uVar8 = uVar8 - 1) {
        FUN_0054eb90();
      }
    }
    iVar7 = param_1[1];
  }
  else {
    uVar8 = iVar5 * 2;
    ExceptionList = &pvStack_10;
    param_1[2] = uVar8;
    if (uVar8 != 0) goto LAB_005fd231;
    iStack_14 = 0;
  }
  iVar5 = *param_1;
  if (iVar5 != 0) {
    uVar8 = 0;
    if (iVar7 != 0) {
      iVar5 = 0;
      do {
        uVar8 = uVar8 + 1;
        puVar6 = (undefined4 *)(*param_1 + -0x10 + iVar5 + 0x10);
        uVar2 = puVar6[1];
        uVar3 = puVar6[2];
        uVar4 = puVar6[3];
        puVar1 = (undefined4 *)(iVar5 + iStack_14);
        *puVar1 = *puVar6;
        puVar1[1] = uVar2;
        puVar1[2] = uVar3;
        puVar1[3] = uVar4;
        iVar5 = iVar5 + 0x10;
      } while (uVar8 < (uint)param_1[1]);
      iVar5 = *param_1;
    }
    FUN_01674ea0(iVar5);
  }
  *param_1 = iStack_14;
LAB_005fd2d9:
  puVar6 = (undefined4 *)(param_1[1] * 0x10 + iStack_14);
  uVar2 = param_2[1];
  uVar3 = param_2[2];
  uVar4 = param_2[3];
  *puVar6 = *param_2;
  puVar6[1] = uVar2;
  puVar6[2] = uVar3;
  puVar6[3] = uVar4;
  param_1[1] = param_1[1] + 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6159 ; VA 0x005fd300 ; FUN_005fd300 */

uint __thiscall FUN_005fd300(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 in_stack_00000018;
  
  uVar2 = FUN_005fb220(param_2,(int)&stack0x00000018 + 3,in_stack_00000018);
  if (in_stack_00000018._3_1_ != '\0') {
    return 0xffffffff;
  }
  uVar6 = param_1[1];
  uVar3 = param_1[2];
  if (uVar2 < uVar6) {
    if (uVar6 != uVar3) {
      iVar4 = *param_1;
      goto LAB_005fd41d;
    }
    if (uVar3 == 0) {
      param_1[2] = 0x10;
      uVar3 = 0x10;
LAB_005fd3cd:
      iVar4 = FUN_01674e20(-(uint)((int)((ulonglong)uVar3 * 4 >> 0x20) != 0) |
                           (uint)((ulonglong)uVar3 * 4));
      uVar6 = param_1[1];
    }
    else {
      uVar3 = uVar3 * 2;
      param_1[2] = uVar3;
      if (uVar3 != 0) goto LAB_005fd3cd;
      iVar4 = 0;
    }
    uVar3 = 0;
    if (uVar6 != 0) {
      do {
        *(undefined4 *)(iVar4 + uVar3 * 4) = *(undefined4 *)(*param_1 + uVar3 * 4);
        uVar3 = uVar3 + 1;
      } while (uVar3 < (uint)param_1[1]);
    }
    FUN_01674ea0(*param_1);
    uVar6 = param_1[1];
    *param_1 = iVar4;
LAB_005fd41d:
    if (uVar6 != uVar2) {
      do {
        puVar1 = (undefined4 *)(*param_1 + uVar6 * 4);
        uVar6 = uVar6 - 1;
        *puVar1 = puVar1[-1];
      } while (uVar6 != uVar2);
      iVar4 = *param_1;
    }
    *(undefined4 *)(iVar4 + uVar2 * 4) = *param_3;
    param_1[1] = param_1[1] + 1;
    return uVar2;
  }
  if (uVar6 != uVar3) {
    iVar4 = *param_1;
    goto LAB_005fd39e;
  }
  if (uVar3 == 0) {
    param_1[2] = 0x10;
    uVar3 = 0x10;
LAB_005fd34a:
    iVar4 = FUN_01674e20(-(uint)((int)((ulonglong)uVar3 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)uVar3 * 4));
    uVar6 = param_1[1];
  }
  else {
    uVar3 = uVar3 * 2;
    param_1[2] = uVar3;
    if (uVar3 != 0) goto LAB_005fd34a;
    iVar4 = 0;
  }
  iVar5 = *param_1;
  if (iVar5 != 0) {
    uVar2 = 0;
    if (uVar6 != 0) {
      do {
        *(undefined4 *)(iVar4 + uVar2 * 4) = *(undefined4 *)(*param_1 + uVar2 * 4);
        uVar2 = uVar2 + 1;
      } while (uVar2 < (uint)param_1[1]);
      iVar5 = *param_1;
    }
    FUN_01674ea0(iVar5);
  }
  *param_1 = iVar4;
LAB_005fd39e:
  *(undefined4 *)(iVar4 + param_1[1] * 4) = *param_3;
  uVar2 = param_1[1];
  param_1[1] = uVar2 + 1;
  return uVar2;
}



/* FUNCTION 6160 ; VA 0x005fd450 ; FUN_005fd450 */

uint __thiscall
FUN_005fd450(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  
  uVar1 = FUN_005fb2c0(param_2,(int)&param_7 + 3,param_7);
  if (param_7._3_1_ != '\0') {
    return 0xffffffff;
  }
  if (*(uint *)(param_1 + 4) <= uVar1) {
    FUN_005fd110(param_3,param_5,param_6);
    return *(int *)(param_1 + 4) - 1;
  }
  FUN_005fd010(param_3,uVar1,param_5,param_6);
  return uVar1;
}



/* FUNCTION 6161 ; VA 0x005fd4b0 ; FUN_005fd4b0 */

void __thiscall FUN_005fd4b0(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  uint uStack_10;
  uint uStack_c;
  char cStack_5;
  
  if (param_1[1] == 0) {
    uStack_10 = param_2;
    uStack_c = param_2;
    uVar2 = FUN_005fb2c0(&param_2,&cStack_5,FUN_005f7ef0);
    if (cStack_5 == '\0') {
      if (uVar2 < (uint)param_1[1]) {
        FUN_005fd010(&uStack_10,uVar2,
                     "c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_RangeList.h"
                     ,0x96);
        return;
      }
      FUN_005fd110(&uStack_10,
                   "c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_RangeList.h"
                   ,0x96);
      return;
    }
  }
  else {
    uVar2 = FUN_005fb2c0(&param_2,&cStack_5,FUN_005f7ef0);
    puVar4 = (uint *)(*param_1 + uVar2 * 8);
    if (uVar2 == param_1[1]) {
      uVar3 = puVar4[-1] + 1;
      if (param_2 == (uVar3 & 0xffffff)) {
LAB_005fd5c1:
        puVar4[-1] = uVar3;
        *(undefined *)((int)puVar4 + -1) = 0;
        return;
      }
      if (puVar4[-1] < param_2) {
        uStack_10 = param_2;
        uStack_c = param_2;
        FUN_005fd450(&param_2,&uStack_10,1,
                     "c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_RangeList.h"
                     ,0xa3,FUN_005f7ef0);
        return;
      }
    }
    else if ((param_2 < *puVar4) || (puVar4[1] < param_2)) {
      uVar3 = *puVar4 - 1;
      if (param_2 < (uVar3 & 0xffffff)) {
        if (uVar2 != 0) {
          uVar3 = puVar4[-1] + 1;
          if (param_2 <= (uVar3 & 0xffffff)) {
            if (param_2 != (uVar3 & 0xffffff)) {
              return;
            }
            goto LAB_005fd5c1;
          }
        }
        uStack_10 = param_2;
        uStack_c = param_2;
        FUN_005fd010(&uStack_10,uVar2,
                     "c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\DS_RangeList.h"
                     ,0xb6);
        return;
      }
      *puVar4 = uVar3;
      *(undefined *)((int)puVar4 + 3) = 0;
      if ((uVar2 != 0) &&
         (puVar4 = (uint *)(*param_1 + uVar2 * 8), (puVar4[-1] + 1 & 0xffffff) == *puVar4)) {
        puVar4[-1] = puVar4[1];
        uVar3 = param_1[1];
        if (uVar2 < uVar3) {
          if (uVar2 < uVar3 - 1) {
            do {
              puVar1 = (undefined4 *)(*param_1 + uVar2 * 8);
              uVar2 = uVar2 + 1;
              *puVar1 = puVar1[2];
              puVar1[1] = puVar1[3];
              uVar3 = param_1[1];
            } while (uVar2 < uVar3 - 1);
          }
          param_1[1] = uVar3 - 1;
        }
      }
    }
  }
  return;
}



/* FUNCTION 6162 ; VA 0x005fd650 ; FUN_005fd650 */

/* WARNING: Type propagation algorithm not settling */

uint __thiscall FUN_005fd650(uint param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  int iStack_4c;
  int iStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  uint auStack_38 [3];
  int *piStack_2c;
  uint uStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ca70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  auStack_38[2] = param_1;
  piStack_2c = (int *)(param_1 + 200);
  iStack_1c = FUN_005fb220(param_2 + 0xe,&cStack_11,FUN_006001c0);
  piVar7 = (int *)(param_1 + 200);
  if (cStack_11 == '\0') {
    auStack_38[0] = FUN_01674e20(0x38);
    if (auStack_38[0] == 0) {
      uVar3 = 0;
    }
    else {
      *(undefined4 *)(auStack_38[0] + 0x10) = 0;
      *(undefined4 *)(auStack_38[0] + 8) = 0;
      *(undefined4 *)(auStack_38[0] + 0xc) = 0;
      *(undefined4 *)(auStack_38[0] + 0x14) = 0;
      *(undefined4 *)(auStack_38[0] + 0x18) = 0;
      *(undefined4 *)(auStack_38[0] + 0x1c) = 0;
      *(undefined4 *)(auStack_38[0] + 0x20) = 0;
      *(undefined4 *)(auStack_38[0] + 0x24) = 0;
      uVar3 = auStack_38[0];
    }
    *(undefined4 *)(uVar3 + 0x30) = 0;
    uStack_28 = uVar3;
    iStack_1c = FUN_005fd300(param_2 + 0xe,&uStack_28,1,
                             "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                             ,0xc2f,FUN_006001c0);
    uStack_3c = *(uint *)(param_2 + 0x14);
    iStack_4c = 0;
    iStack_48 = 0;
    uStack_44 = 0;
    uStack_8 = 0;
    auStack_38[1] = 0;
    if (0x80000000 < uStack_3c) {
      uStack_3c = 0x80000000;
    }
    FUN_005f87c0(uStack_3c,&iStack_4c,auStack_38 + 1);
    uStack_40 = 0;
    piVar7 = (int *)(uVar3 + 0x14);
    uStack_8 = 1;
    if (piVar7 != &iStack_4c) {
      iStack_18 = iStack_48;
      auStack_38[0] = iStack_48 - iStack_4c;
      iStack_20 = iStack_4c;
      iVar8 = *piVar7;
      uStack_24 = *(int *)(uVar3 + 0x18) - iVar8 >> 2;
      uStack_28 = (int)auStack_38[0] >> 2;
      uVar6 = *(int *)(uVar3 + 0x1c) - iVar8 >> 2;
      if (uVar6 < uStack_28) {
        if (0x3fffffff < uStack_28) {
                    /* WARNING: Subroutine does not return */
          FUN_00577c30();
        }
        uStack_24 = uVar6 >> 1;
        uVar5 = uStack_28;
        if ((uVar6 <= 0x3fffffff - uStack_24) &&
           (uVar5 = uStack_24 + uVar6, uStack_24 + uVar6 < uStack_28)) {
          uVar5 = uStack_28;
        }
        uStack_28 = uVar5;
        if (*piVar7 != 0) {
          FUN_0057d270(*piVar7,uVar6);
        }
        FUN_005d2220(uStack_28);
        iVar8 = *piVar7;
        FUN_0055b6b0(&cStack_11,auStack_38,auStack_38);
        iStack_18 = iStack_18 - iStack_20;
        FUN_0170cc70(iVar8,iStack_20,iStack_18);
        *(int *)(uVar3 + 0x18) = iStack_18 + iVar8;
      }
      else if (uStack_24 < uStack_28) {
        iVar8 = iStack_4c + uStack_24 * 4;
        FUN_0170cc70(*piVar7,iStack_4c,uStack_24 * 4);
        iVar1 = *(int *)(uVar3 + 0x18);
        FUN_0055b6b0(&cStack_11,auStack_38,auStack_38);
        iStack_18 = iStack_18 - iVar8;
        FUN_0170cc70(iVar1,iVar8,iStack_18);
        *(int *)(uVar3 + 0x18) = iStack_18 + iVar1;
      }
      else {
        iVar1 = uStack_28 * 4;
        FUN_0170cc70(iVar8,iStack_4c,auStack_38[0]);
        *(int *)(uVar3 + 0x18) = iVar8 + iVar1;
      }
    }
    *(undefined4 *)(uVar3 + 0x20) = uStack_40;
    *(uint *)(uVar3 + 0x24) = uStack_3c;
    *(uint *)(uVar3 + 0x28) = (uint)*(ushort *)(param_2 + 0xe);
    *(undefined4 *)(uVar3 + 0x2c) = *(undefined4 *)(param_2 + 0x14);
    uStack_8 = 0xffffffff;
    FUN_0056d320();
    piVar7 = piStack_2c;
    param_1 = auStack_38[2];
  }
  iVar8 = *(int *)(*piVar7 + iStack_1c * 4);
  uVar3 = *(uint *)(param_2 + 0x10);
  if ((uVar3 < *(uint *)(iVar8 + 0x24)) && (*(uint *)(param_2 + 0x14) == *(uint *)(iVar8 + 0x24))) {
    if (*(int *)(*(int *)(iVar8 + 0x14) + uVar3 * 4) == 0) {
      *(int *)(iVar8 + 0x20) = *(int *)(iVar8 + 0x20) + 1;
    }
    *(int *)(*(int *)(iVar8 + 0x14) + uVar3 * 4) = param_2;
    puVar2 = *(undefined4 **)(*piVar7 + iStack_1c * 4);
    *puVar2 = param_3;
    puVar2[1] = param_4;
    if (*(int *)(param_2 + 0x10) == 0) {
      *(int *)(*(int *)(*piVar7 + iStack_1c * 4) + 0x30) = param_2;
    }
    uVar6 = *(uint *)(param_1 + 0x18);
    iVar8 = *(int *)(*piVar7 + iStack_1c * 4);
    uVar5 = *(uint *)(iVar8 + 0x20);
    uVar3 = uVar5;
    if ((((uVar6 != 0) && (iVar8 = *(int *)(iVar8 + 0x30), iVar8 != 0)) &&
        (uVar5 != *(uint *)(iVar8 + 0x14))) && (uVar3 = uVar5 / uVar6, uVar5 % uVar6 == 0)) {
      uVar3 = FUN_005f98f0();
      iVar8 = *(int *)(*(int *)(*(int *)(*piVar7 + iStack_1c * 4) + 0x30) + 0x18);
      *(undefined4 *)(uVar3 + 0x40) = 0;
      iVar8 = (iVar8 + 7U >> 3) + 0xd;
      auStack_38[0] = uVar3;
      uVar4 = FUN_01674f30(iVar8);
      *(undefined4 *)(uVar3 + 0x3c) = uVar4;
      *(int *)(uVar3 + 0x18) = iVar8 * 8;
      **(undefined **)(uVar3 + 0x3c) = 0x1e;
      *(uint *)(*(int *)(uVar3 + 0x3c) + 1) = uVar5;
      *(undefined4 *)(*(int *)(uVar3 + 0x3c) + 5) = *(undefined4 *)(param_2 + 0x14);
      *(uint *)(*(int *)(uVar3 + 0x3c) + 9) =
           *(int *)(*(int *)(*(int *)(*piVar7 + iStack_1c * 4) + 0x30) + 0x18) + 7U >> 3;
      iVar8 = *(int *)(*(int *)(*piVar7 + iStack_1c * 4) + 0x30);
      FUN_0170c6f0(*(int *)(uVar3 + 0x3c) + 0xd,*(undefined4 *)(iVar8 + 0x3c),
                   *(int *)(iVar8 + 0x18) + 7U >> 3);
      uVar3 = FUN_005fe020(auStack_38,
                           "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                           ,0xcb6);
      ExceptionList = pvStack_10;
      return uVar3;
    }
  }
  else {
    FUN_005fa670(param_2,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                 ,0xc8f);
    uVar3 = FUN_005fe570(param_2);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 6163 ; VA 0x005fda40 ; FUN_005fda40 */

undefined __fastcall FUN_005fda40(int param_1)

{
  return *(undefined *)(param_1 + 0xdc);
}



/* FUNCTION 6164 ; VA 0x005fda50 ; FUN_005fda50 */

undefined FUN_005fda50(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ca8c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eace34) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eace34);
    if (DAT_01eace34 == -1) {
      uStack_8 = 0;
      DAT_01eace30 = FUN_006a5800();
      FUN_016f37bf(&DAT_01eace34);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eace30;
}



/* FUNCTION 6165 ; VA 0x005fdad0 ; FUN_005fdad0 */

undefined4 FUN_005fdad0(uint param_1,uint param_2)

{
  if (param_2 < 0x800000) {
    if ((param_2 - 0x800000 & 0xffffff) <= param_1) {
      return 1;
    }
  }
  else if (param_1 < (param_2 - 0x7ffffe & 0xffffff)) {
    return 0;
  }
  if (param_1 < param_2) {
    return 1;
  }
  return 0;
}



/* FUNCTION 6166 ; VA 0x005fdb20 ; FUN_005fdb20 */

bool __fastcall FUN_005fdb20(int param_1)

{
  if (*(int *)(param_1 + 0x9c) != 0) {
    return true;
  }
  return *(int *)(param_1 + 0x1b0) != 0;
}



/* FUNCTION 6167 ; VA 0x005fdb40 ; FUN_005fdb40 */

void FUN_005fdb40(int *param_1,int param_2)

{
  int iVar1;
  
  if (*param_1 == 0) {
    *(int *)(param_2 + 0x58) = param_2;
    *(int *)(param_2 + 0x54) = param_2;
    *param_1 = param_2;
    return;
  }
  *(int *)(param_2 + 0x58) = *param_1;
  iVar1 = *(int *)(*param_1 + 0x54);
  *(int *)(param_2 + 0x54) = iVar1;
  *(int *)(iVar1 + 0x58) = param_2;
  *(int *)(*param_1 + 0x54) = param_2;
  return;
}



/* FUNCTION 6168 ; VA 0x005fdb70 ; FUN_005fdb70 */

void FUN_005fdb70(int *param_1,int param_2)

{
  int iVar1;
  
  *(undefined4 *)(*(int *)(param_2 + 0x54) + 0x58) = *(undefined4 *)(param_2 + 0x58);
  *(undefined4 *)(*(int *)(param_2 + 0x58) + 0x54) = *(undefined4 *)(param_2 + 0x54);
  if ((*param_1 == param_2) &&
     (iVar1 = *(int *)(param_2 + 0x58), *param_1 = iVar1, iVar1 == param_2)) {
    *param_1 = 0;
  }
  return;
}



/* FUNCTION 6169 ; VA 0x005fdbb0 ; FUN_005fdbb0 */

undefined4 __thiscall FUN_005fdbb0(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  undefined4 uVar19;
  int iVar20;
  uint uVar21;
  uint *puVar22;
  uint *puVar23;
  uint *puVar24;
  uint uVar25;
  uint uStack_20;
  
  iVar3 = *param_1;
  uVar4 = *(undefined4 *)(iVar3 + 8 + param_2 * 0x10);
  puVar2 = (undefined4 *)(iVar3 + -0x10 + param_1[1] * 0x10);
  uVar8 = puVar2[1];
  uVar9 = puVar2[2];
  uVar10 = puVar2[3];
  puVar1 = (undefined4 *)(iVar3 + param_2 * 0x10);
  *puVar1 = *puVar2;
  puVar1[1] = uVar8;
  puVar1[2] = uVar9;
  puVar1[3] = uVar10;
  uVar5 = *(uint *)(*param_1 + param_2 * 0x10);
  uVar6 = *(uint *)(*param_1 + 4 + param_2 * 0x10);
  param_1[1] = param_1[1] + -1;
  uVar21 = param_2 * 2 + 1;
  uStack_20 = param_1[1];
  if (uVar21 < uStack_20) {
    while( true ) {
      uVar25 = param_2 * 2 + 2;
      iVar3 = *param_1;
      puVar23 = (uint *)(uVar21 * 0x10 + iVar3);
      if (uStack_20 <= uVar25) break;
      if ((uVar6 <= puVar23[1]) && ((uVar6 < puVar23[1] || (uVar5 <= *puVar23)))) {
        uVar7 = *(uint *)(iVar3 + 4 + uVar25 * 0x10);
        if (uVar6 < uVar7) {
          return uVar4;
        }
        if ((uVar6 <= uVar7) && (uVar5 <= *(uint *)(iVar3 + uVar25 * 0x10))) {
          return uVar4;
        }
      }
      iVar20 = param_2 * 0x10;
      puVar22 = (uint *)(uVar25 * 0x10 + iVar3);
      puVar24 = (uint *)(iVar3 + iVar20);
      if ((puVar22[1] < puVar23[1]) || ((puVar22[1] <= puVar23[1] && (*puVar22 <= *puVar23)))) {
        uVar21 = *puVar22;
        uVar7 = puVar22[1];
        uVar11 = puVar22[2];
        uVar12 = puVar22[3];
        uVar13 = puVar24[1];
        uVar14 = puVar24[2];
        uVar15 = puVar24[3];
        *puVar22 = *puVar24;
        puVar22[1] = uVar13;
        puVar22[2] = uVar14;
        puVar22[3] = uVar15;
        puVar23 = (uint *)(*param_1 + iVar20);
        *puVar23 = uVar21;
        puVar23[1] = uVar7;
        puVar23[2] = uVar11;
        puVar23[3] = uVar12;
      }
      else {
        uVar25 = *puVar23;
        uVar7 = puVar23[1];
        uVar11 = puVar23[2];
        uVar12 = puVar23[3];
        uVar13 = puVar24[1];
        uVar14 = puVar24[2];
        uVar15 = puVar24[3];
        *puVar23 = *puVar24;
        puVar23[1] = uVar13;
        puVar23[2] = uVar14;
        puVar23[3] = uVar15;
        puVar23 = (uint *)(*param_1 + iVar20);
        *puVar23 = uVar25;
        puVar23[1] = uVar7;
        puVar23[2] = uVar11;
        puVar23[3] = uVar12;
        uVar25 = uVar21;
      }
      uVar21 = uVar25 * 2 + 1;
      uStack_20 = param_1[1];
      param_2 = uVar25;
      if (uStack_20 <= uVar21) {
        return uVar4;
      }
    }
    if ((puVar23[1] <= uVar6) && ((puVar23[1] < uVar6 || (*puVar23 < uVar5)))) {
      puVar1 = (undefined4 *)(iVar3 + param_2 * 0x10);
      uVar8 = puVar1[1];
      uVar9 = puVar1[2];
      uVar10 = puVar1[3];
      puVar2 = (undefined4 *)(iVar3 + uVar21 * 0x10);
      uVar16 = *puVar2;
      uVar17 = puVar2[1];
      uVar18 = puVar2[2];
      uVar19 = puVar2[3];
      puVar2 = (undefined4 *)(iVar3 + uVar21 * 0x10);
      *puVar2 = *puVar1;
      puVar2[1] = uVar8;
      puVar2[2] = uVar9;
      puVar2[3] = uVar10;
      puVar1 = (undefined4 *)(*param_1 + param_2 * 0x10);
      *puVar1 = uVar16;
      puVar1[1] = uVar17;
      puVar1[2] = uVar18;
      puVar1[3] = uVar19;
    }
  }
  return uVar4;
}



/* FUNCTION 6170 ; VA 0x005fdd20 ; FUN_005fdd20 */

undefined4 __fastcall FUN_005fdd20(int *param_1)

{
  int iVar1;
  undefined3 uVar2;
  
  iVar1 = param_1[1] + 1;
  param_1[1] = iVar1;
  if (iVar1 == param_1[3]) {
    param_1[1] = 0;
    iVar1 = 0;
  }
  uVar2 = (undefined3)((uint)iVar1 >> 8);
  if (iVar1 == 0) {
    return CONCAT31(uVar2,*(undefined *)(*param_1 + -1 + param_1[3]));
  }
  return CONCAT31(uVar2,*(undefined *)(*param_1 + -1 + iVar1));
}



/* FUNCTION 6171 ; VA 0x005fdd50 ; FUN_005fdd50 */

void __thiscall
FUN_005fdd50(uint *param_1,uint param_2,undefined4 *param_3,uint param_4,uint param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179cacd;
  pvStack_10 = ExceptionList;
  if (param_1[7] == 0) {
    ExceptionList = &pvStack_10;
    puVar4 = (undefined4 *)FUN_01674e20(0x104);
    uStack_8 = 0;
    if (puVar4 == (undefined4 *)0x0) {
      puVar5 = (uint *)0x0;
    }
    else {
      *puVar4 = 0x10;
      puVar5 = puVar4 + 1;
      FUN_016f4053(puVar5,0x10,0x10,FUN_0054eb90,_guard_check_icall);
    }
    param_1[4] = (uint)puVar5;
    param_1[5] = 0;
    param_1[6] = 1;
    *puVar5 = param_4;
    puVar5[1] = param_5;
    puVar5[2] = param_2;
    puVar5[3] = (uint)param_3;
    param_1[7] = 0x10;
  }
  else {
    puVar5 = (uint *)(param_1[6] * 0x10 + param_1[4]);
    ExceptionList = &pvStack_10;
    *puVar5 = param_4;
    puVar5[1] = param_5;
    puVar5[2] = param_2;
    puVar5[3] = (uint)param_3;
    uVar6 = param_1[6] + 1;
    param_1[6] = uVar6;
    if (uVar6 == param_1[7]) {
      param_1[6] = 0;
      uVar6 = 0;
    }
    if ((uVar6 == param_1[5]) &&
       (puVar4 = (undefined4 *)
                 FUN_005f7e40(param_1[7] * 2,
                              "c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\ReliabilityLayer.h"
                              ,0x67), puVar4 != (undefined4 *)0x0)) {
      uVar6 = 0;
      param_3 = puVar4;
      if (param_1[7] != 0) {
        do {
          uVar7 = param_1[5] + uVar6;
          uVar6 = uVar6 + 1;
          puVar8 = (undefined4 *)((uVar7 % param_1[7]) * 0x10 + param_1[4]);
          uVar1 = puVar8[1];
          uVar2 = puVar8[2];
          uVar3 = puVar8[3];
          *param_3 = *puVar8;
          param_3[1] = uVar1;
          param_3[2] = uVar2;
          param_3[3] = uVar3;
          param_3 = param_3 + 4;
        } while (uVar6 < param_1[7]);
      }
      param_1[6] = param_1[7];
      param_1[7] = param_1[7] * 2;
      uVar6 = param_1[4];
      param_1[5] = 0;
      if (uVar6 != 0) {
        uStack_8 = 1;
        FUN_016f32d1(uVar6,0x10,*(undefined4 *)(uVar6 - 4),_guard_check_icall);
        FUN_01674ea0((int *)(uVar6 - 4),*(int *)(uVar6 - 4) * 0x10 + 4);
      }
      param_1[4] = (uint)puVar4;
    }
  }
  uVar6 = *param_1;
  *param_1 = *param_1 + param_4;
  param_1[1] = param_1[1] + param_5 + (uint)CARRY4(uVar6,param_4);
  puVar5 = param_1 + 2;
  uVar6 = *puVar5;
  *puVar5 = *puVar5 + param_4;
  param_1[3] = param_1[3] + param_5 + (uint)CARRY4(uVar6,param_4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6172 ; VA 0x005fdef0 ; FUN_005fdef0 */

void __thiscall
FUN_005fdef0(int *param_1,uint *param_2,undefined4 *param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  uint uVar13;
  uint uStack_18;
  uint uStack_14;
  undefined4 uStack_10;
  int *piStack_8;
  
  uVar3 = param_1[1];
  uStack_18 = *param_2;
  uStack_14 = param_2[1];
  uStack_10 = *param_3;
  piStack_8 = param_1;
  FUN_005fd1f0(&uStack_18,param_4,param_5);
  while( true ) {
    if (uVar3 == 0) {
      return;
    }
    uVar13 = uVar3 - 1 >> 1;
    iVar4 = *piStack_8;
    uVar5 = *(uint *)(iVar4 + 4 + uVar13 * 0x10);
    if (uVar5 < param_2[1]) break;
    if ((uVar5 <= param_2[1]) && (*(uint *)(iVar4 + uVar13 * 0x10) <= *param_2)) {
      return;
    }
    puVar1 = (undefined4 *)(iVar4 + uVar13 * 0x10);
    uVar6 = puVar1[1];
    uVar7 = puVar1[2];
    uVar8 = puVar1[3];
    puVar2 = (undefined4 *)(iVar4 + uVar3 * 0x10);
    uVar9 = *puVar2;
    uVar10 = puVar2[1];
    uVar11 = puVar2[2];
    uVar12 = puVar2[3];
    puVar2 = (undefined4 *)(iVar4 + uVar3 * 0x10);
    *puVar2 = *puVar1;
    puVar2[1] = uVar6;
    puVar2[2] = uVar7;
    puVar2[3] = uVar8;
    puVar1 = (undefined4 *)(*piStack_8 + uVar13 * 0x10);
    *puVar1 = uVar9;
    puVar1[1] = uVar10;
    puVar1[2] = uVar11;
    puVar1[3] = uVar12;
    uVar3 = uVar13;
  }
  return;
}



/* FUNCTION 6173 ; VA 0x005fdf80 ; FUN_005fdf80 */

void __thiscall FUN_005fdf80(int *param_1,undefined4 *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = param_1[1];
  iVar2 = param_1[2];
  if (iVar4 != iVar2) {
    *(undefined4 *)(*param_1 + param_1[1] * 4) = *param_2;
    param_1[1] = param_1[1] + 1;
    return;
  }
  if (iVar2 == 0) {
    param_1[2] = 0x10;
    uVar1 = 0x10;
  }
  else {
    uVar1 = iVar2 * 2;
    param_1[2] = uVar1;
    if (uVar1 == 0) {
      iVar2 = 0;
      goto LAB_005fdfbf;
    }
  }
  iVar2 = FUN_01674e20(-(uint)((int)((ulonglong)uVar1 * 4 >> 0x20) != 0) |
                       (uint)((ulonglong)uVar1 * 4));
  iVar4 = param_1[1];
LAB_005fdfbf:
  iVar3 = *param_1;
  if (iVar3 != 0) {
    uVar1 = 0;
    if (iVar4 != 0) {
      do {
        *(undefined4 *)(iVar2 + uVar1 * 4) = *(undefined4 *)(*param_1 + uVar1 * 4);
        uVar1 = uVar1 + 1;
      } while (uVar1 < (uint)param_1[1]);
      iVar3 = *param_1;
    }
    FUN_01674ea0(iVar3);
  }
  *param_1 = iVar2;
  *(undefined4 *)(iVar2 + param_1[1] * 4) = *param_2;
  param_1[1] = param_1[1] + 1;
  return;
}



/* FUNCTION 6174 ; VA 0x005fe020 ; FUN_005fe020 */

void __thiscall FUN_005fe020(int *param_1,undefined4 *param_2)

{
  longlong lVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  
  if (param_1[3] != 0) {
    *(undefined4 *)(*param_1 + param_1[2] * 4) = *param_2;
    param_1[2] = param_1[2] + 1;
    iVar3 = param_1[2];
    if (iVar3 == param_1[3]) {
      param_1[2] = 0;
      iVar3 = 0;
    }
    if (((iVar3 == param_1[1]) && (uVar4 = param_1[3] * 2, uVar4 != 0)) &&
       (lVar1 = (ulonglong)uVar4 * 4,
       iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)lVar1 >> 0x20) != 0) | (uint)lVar1), iVar3 != 0
       )) {
      uVar4 = 0;
      if (param_1[3] != 0) {
        do {
          *(undefined4 *)(iVar3 + uVar4 * 4) =
               *(undefined4 *)(*param_1 + ((param_1[1] + uVar4) % (uint)param_1[3]) * 4);
          uVar4 = uVar4 + 1;
        } while (uVar4 < (uint)param_1[3]);
      }
      param_1[2] = param_1[3];
      param_1[1] = 0;
      param_1[3] = param_1[3] * 2;
      FUN_01674ea0(*param_1);
      *param_1 = iVar3;
    }
    return;
  }
  puVar2 = (undefined4 *)FUN_01674e20(0x40);
  *param_1 = (int)puVar2;
  param_1[1] = 0;
  param_1[2] = 1;
  *puVar2 = *param_2;
  param_1[3] = 0x10;
  return;
}



/* FUNCTION 6175 ; VA 0x005fe0f0 ; FUN_005fe0f0 */

void __thiscall FUN_005fe0f0(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  uint *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  int iVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179cb01;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)(param_1 + 3);
  if (param_1[3] != 0) {
    puVar5 = (undefined4 *)(param_1[2] * 0x10 + *param_1);
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    ExceptionList = &pvStack_10;
    *puVar5 = *param_2;
    puVar5[1] = uVar2;
    puVar5[2] = uVar3;
    puVar5[3] = uVar4;
    param_1[2] = param_1[2] + 1;
    uVar6 = param_1[2];
    if (uVar6 == *puVar1) {
      param_1[2] = 0;
      uVar6 = 0;
    }
    if ((uVar6 == param_1[1]) &&
       (puVar5 = (undefined4 *)FUN_005f7da0(*puVar1 * 2,param_3,param_4),
       puVar5 != (undefined4 *)0x0)) {
      uVar6 = 0;
      param_2 = puVar5;
      if (*puVar1 != 0) {
        do {
          uVar7 = param_1[1] + uVar6;
          uVar6 = uVar6 + 1;
          puVar8 = (undefined4 *)((uVar7 % *puVar1) * 0x10 + *param_1);
          uVar2 = puVar8[1];
          uVar3 = puVar8[2];
          uVar4 = puVar8[3];
          *param_2 = *puVar8;
          param_2[1] = uVar2;
          param_2[2] = uVar3;
          param_2[3] = uVar4;
          param_2 = param_2 + 4;
        } while (uVar6 < *puVar1);
      }
      param_1[2] = *puVar1;
      param_1[1] = 0;
      *puVar1 = *puVar1 * 2;
      FUN_01674ea0(*param_1);
      *param_1 = (int)puVar5;
    }
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_01674e20(0x100);
  uStack_8 = 0;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    iVar9 = 0x10;
    do {
      FUN_005f8960();
      iVar9 = iVar9 + -1;
    } while (iVar9 != 0);
  }
  *param_1 = (int)puVar5;
  param_1[1] = 0;
  param_1[2] = 1;
  uVar2 = param_2[1];
  uVar3 = param_2[2];
  uVar4 = param_2[3];
  *puVar5 = *param_2;
  puVar5[1] = uVar2;
  puVar5[2] = uVar3;
  puVar5[3] = uVar4;
  *puVar1 = 0x10;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6176 ; VA 0x005fe240 ; FUN_005fe240 */

void __thiscall FUN_005fe240(int *param_1,undefined *param_2)

{
  undefined *puVar1;
  int iVar2;
  uint uVar3;
  
  if (param_1[3] != 0) {
    *(undefined *)(param_1[2] + *param_1) = *param_2;
    param_1[2] = param_1[2] + 1;
    iVar2 = param_1[2];
    if (iVar2 == param_1[3]) {
      param_1[2] = 0;
      iVar2 = 0;
    }
    if (((iVar2 == param_1[1]) && (iVar2 = param_1[3] * 2, iVar2 != 0)) &&
       (iVar2 = FUN_01674e20(iVar2), iVar2 != 0)) {
      uVar3 = 0;
      if (param_1[3] != 0) {
        do {
          *(undefined *)(uVar3 + iVar2) =
               *(undefined *)((param_1[1] + uVar3) % (uint)param_1[3] + *param_1);
          uVar3 = uVar3 + 1;
        } while (uVar3 < (uint)param_1[3]);
      }
      param_1[2] = param_1[3];
      param_1[1] = 0;
      param_1[3] = param_1[3] * 2;
      FUN_01674ea0(*param_1);
      *param_1 = iVar2;
    }
    return;
  }
  puVar1 = (undefined *)FUN_01674e20(0x10);
  *param_1 = (int)puVar1;
  param_1[1] = 0;
  param_1[2] = 1;
  *puVar1 = *param_2;
  param_1[3] = 0x10;
  return;
}



/* FUNCTION 6177 ; VA 0x005fe300 ; FUN_005fe300 */

void __thiscall
FUN_005fe300(int param_1,undefined4 param_2,undefined4 param_3,int param_4,byte param_5)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined uStack_5;
  
  uVar5 = (*(int *)(param_4 + 0x18) + 7U & 0xfffffff8) +
          (*(int *)(param_4 + 0x38) + 7U & 0xfffffff8);
  *(int *)(param_1 + 0x7ec) = *(int *)(param_1 + 0x7ec) + uVar5;
  *(int *)(param_1 + 0x7f0) = *(int *)(param_1 + 0x7f0) + uVar5;
  iVar4 = *(int *)(param_1 + 0x7c0);
  iVar2 = *(int *)(param_1 + 0x7c4);
  if (iVar4 == iVar2) {
    if (iVar2 == 0) {
      *(undefined4 *)(param_1 + 0x7c4) = 0x10;
      uVar1 = 0x10;
LAB_005fe34f:
      iVar2 = FUN_01674e20(-(uint)((int)((ulonglong)uVar1 * 4 >> 0x20) != 0) |
                           (uint)((ulonglong)uVar1 * 4));
      iVar4 = *(int *)(param_1 + 0x7c0);
    }
    else {
      uVar1 = iVar2 * 2;
      *(uint *)(param_1 + 0x7c4) = uVar1;
      if (uVar1 != 0) goto LAB_005fe34f;
      iVar2 = 0;
    }
    iVar3 = *(int *)(param_1 + 0x7bc);
    if (iVar3 != 0) {
      uVar1 = 0;
      if (iVar4 != 0) {
        do {
          *(undefined4 *)(iVar2 + uVar1 * 4) =
               *(undefined4 *)(*(int *)(param_1 + 0x7bc) + uVar1 * 4);
          uVar1 = uVar1 + 1;
        } while (uVar1 < *(uint *)(param_1 + 0x7c0));
        iVar3 = *(int *)(param_1 + 0x7bc);
      }
      FUN_01674ea0(iVar3);
    }
    *(int *)(param_1 + 0x7bc) = iVar2;
  }
  else {
    iVar2 = *(int *)(param_1 + 0x7bc);
  }
  *(int *)(iVar2 + *(int *)(param_1 + 0x7c0) * 4) = param_4;
  *(int *)(param_1 + 0x7c0) = *(int *)(param_1 + 0x7c0) + 1;
  iVar4 = *(int *)(param_1 + 0x7cc);
  uStack_5 = param_5 ^ 1;
  iVar2 = *(int *)(param_1 + 2000);
  if (iVar4 == iVar2) {
    if (iVar2 == 0) {
      *(undefined4 *)(param_1 + 2000) = 0x10;
      iVar2 = 0x10;
LAB_005fe3ff:
      iVar2 = FUN_01674e20(iVar2);
      iVar4 = *(int *)(param_1 + 0x7cc);
    }
    else {
      iVar2 = iVar2 * 2;
      *(int *)(param_1 + 2000) = iVar2;
      if (iVar2 != 0) goto LAB_005fe3ff;
      iVar2 = 0;
    }
    iVar3 = *(int *)(param_1 + 0x7c8);
    if (iVar3 != 0) {
      uVar1 = 0;
      if (iVar4 != 0) {
        do {
          *(undefined *)(uVar1 + iVar2) = *(undefined *)(uVar1 + *(int *)(param_1 + 0x7c8));
          uVar1 = uVar1 + 1;
        } while (uVar1 < *(uint *)(param_1 + 0x7cc));
        iVar3 = *(int *)(param_1 + 0x7c8);
      }
      FUN_01674ea0(iVar3);
    }
    *(int *)(param_1 + 0x7c8) = iVar2;
  }
  else {
    iVar2 = *(int *)(param_1 + 0x7c8);
  }
  *(byte *)(iVar2 + *(int *)(param_1 + 0x7cc)) = uStack_5;
  *(int *)(param_1 + 0x7cc) = *(int *)(param_1 + 0x7cc) + 1;
  if (DAT_01d59d28 == '\0') goto LAB_005fe4b1;
  uVar5 = uVar5 >> 3;
  if (*(char *)(param_4 + 0x48) != '\0') {
    *(int *)(param_1 + 0x25c) = *(int *)(param_1 + 0x25c) + 1;
    *(int *)(param_1 + 600) = *(int *)(param_1 + 600) + uVar5;
    goto LAB_005fe4b1;
  }
  if (DAT_01d59d48 == '\0') {
    if (param_5 != 0) goto LAB_005fe4e4;
  }
  else {
    if (param_5 != 0) {
LAB_005fe4e4:
      *(int *)(param_1 + 0x250) = *(int *)(param_1 + 0x250) + uVar5;
      *(int *)(param_1 + 0x254) = *(int *)(param_1 + 0x254) + 1;
      goto LAB_005fe4b1;
    }
    *(int *)(param_1 + 0x260) = *(int *)(param_1 + 0x260) + uVar5;
  }
  *(int *)(param_1 + 0x264) = *(int *)(param_1 + 0x264) + 1;
LAB_005fe4b1:
  (**(code **)(**(int **)(param_1 + 0x7b0) + 0x28))
            (param_2,param_3,
             (*(int *)(param_4 + 0x18) + 7U >> 3) + (*(int *)(param_4 + 0x38) + 7U >> 3));
  return;
}



/* FUNCTION 6178 ; VA 0x005fe500 ; FUN_005fe500 */

undefined4 __thiscall FUN_005fe500(int param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar1 = *(uint *)(param_1 + 0xc);
  if (*(uint *)(param_1 + 0x10) < uVar1) {
    iVar3 = *(int *)(param_1 + 0x14) - uVar1;
  }
  else {
    iVar3 = -uVar1;
  }
  if (*(uint *)(param_1 + 0x10) + iVar3 != 0) {
    iVar3 = uVar1 + 1;
    *(int *)(param_1 + 0xc) = iVar3;
    if (iVar3 == *(int *)(param_1 + 0x14)) {
      *(undefined4 *)(param_1 + 0xc) = 0;
      iVar3 = 0;
    }
    if (iVar3 == 0) {
      iVar3 = *(int *)(*(int *)(param_1 + 8) + -4 + *(int *)(param_1 + 0x14) * 4);
    }
    else {
      iVar3 = *(int *)(*(int *)(param_1 + 8) + -4 + iVar3 * 4);
    }
    *param_2 = *(undefined4 *)(iVar3 + 0x3c);
    uVar2 = *(undefined4 *)(iVar3 + 0x18);
    FUN_005fe570(iVar3);
    return uVar2;
  }
  return 0;
}



/* FUNCTION 6179 ; VA 0x005fe570 ; FUN_005fe570 */

int __thiscall FUN_005fe570(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  piVar1 = *(int **)(param_2 + 0xe8);
  if (piVar1[1] != 0) {
    ((int *)*piVar1)[piVar1[1]] = param_2;
    piVar1[1] = piVar1[1] + 1;
    iVar3 = *(uint *)(param_1 + 0x70) * -0x77777777;
    if ((piVar1[1] == *(uint *)(param_1 + 0x70) / 0xf0) && (3 < *(int *)(param_1 + 0x68))) {
      if (piVar1 == *(int **)(param_1 + 0x60)) {
        *(int *)(param_1 + 0x60) = piVar1[3];
      }
      *(int *)(piVar1[4] + 0xc) = piVar1[3];
      *(int *)(piVar1[3] + 0x10) = piVar1[4];
      *(int *)(param_1 + 0x68) = *(int *)(param_1 + 0x68) + -1;
      FUN_01674ea0(*piVar1);
      FUN_01674ea0(piVar1[2]);
      iVar3 = FUN_01674ea0(piVar1);
    }
    return iVar3;
  }
  *(int *)*piVar1 = param_2;
  piVar1[1] = piVar1[1] + 1;
  *(int *)(param_1 + 0x6c) = *(int *)(param_1 + 0x6c) + -1;
  *(int *)(piVar1[3] + 0x10) = piVar1[4];
  *(int *)(piVar1[4] + 0xc) = piVar1[3];
  if ((0 < *(int *)(param_1 + 0x6c)) && (piVar1 == *(int **)(param_1 + 100))) {
    *(int *)(param_1 + 100) = (*(int **)(param_1 + 100))[3];
  }
  iVar2 = *(int *)(param_1 + 0x68);
  iVar3 = iVar2 + 1;
  *(int *)(param_1 + 0x68) = iVar3;
  if (iVar2 == 0) {
    *(int **)(param_1 + 0x60) = piVar1;
    piVar1[3] = (int)piVar1;
    piVar1[4] = (int)piVar1;
    return iVar3;
  }
  piVar1[3] = *(int *)(param_1 + 0x60);
  piVar1[4] = *(int *)(*(int *)(param_1 + 0x60) + 0x10);
  *(int **)(*(int *)(*(int *)(param_1 + 0x60) + 0x10) + 0xc) = piVar1;
  iVar3 = *(int *)(param_1 + 0x60);
  *(int **)(iVar3 + 0x10) = piVar1;
  return iVar3;
}



/* FUNCTION 6180 ; VA 0x005fe650 ; FUN_005fe650 */

void __thiscall FUN_005fe650(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = param_1[1];
  if (param_2 < uVar2) {
    if (param_2 < uVar2 - 1) {
      iVar3 = param_2 << 4;
      do {
        param_2 = param_2 + 1;
        puVar1 = (undefined4 *)(*param_1 + iVar3);
        iVar3 = iVar3 + 0x10;
        *puVar1 = puVar1[4];
        puVar1[1] = puVar1[5];
        puVar1[2] = puVar1[6];
        puVar1[3] = puVar1[7];
        uVar2 = param_1[1];
      } while (param_2 < uVar2 - 1);
    }
    param_1[1] = uVar2 - 1;
  }
  return;
}



/* FUNCTION 6181 ; VA 0x005fe6b0 ; FUN_005fe6b0 */

void __thiscall FUN_005fe6b0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  
  uVar5 = param_2 - *(int *)(param_1 + 0x5c) & 0xffffff;
  uVar3 = *(int *)(param_1 + 0x2c) + uVar5;
  if (*(uint *)(param_1 + 0x34) <= uVar3) {
    uVar3 = (*(int *)(param_1 + 0x2c) - *(uint *)(param_1 + 0x34)) + uVar5;
  }
  iVar4 = *(int *)(*(int *)(param_1 + 0x28) + uVar3 * 0x10);
  if (iVar4 == 0) {
    if (DAT_01d59d18 != '\0') {
      *(int *)(param_1 + 0x4c) = *(int *)(param_1 + 0x4c) + -1;
    }
  }
  else {
    do {
      piVar1 = *(int **)(iVar4 + 8);
      iVar2 = *(int *)(iVar4 + 4);
      if (piVar1[1] == 0) {
        *(int *)*piVar1 = iVar4;
        piVar1[1] = piVar1[1] + 1;
        *(int *)(param_1 + 0x44) = *(int *)(param_1 + 0x44) + -1;
        *(int *)(piVar1[3] + 0x10) = piVar1[4];
        *(int *)(piVar1[4] + 0xc) = piVar1[3];
        if ((0 < *(int *)(param_1 + 0x44)) && (piVar1 == *(int **)(param_1 + 0x3c))) {
          *(int *)(param_1 + 0x3c) = (*(int **)(param_1 + 0x3c))[3];
        }
        iVar4 = *(int *)(param_1 + 0x40);
        *(int *)(param_1 + 0x40) = iVar4 + 1;
        if (iVar4 == 0) {
          *(int **)(param_1 + 0x38) = piVar1;
          piVar1[3] = (int)piVar1;
          piVar1[4] = (int)piVar1;
        }
        else {
          piVar1[3] = *(int *)(param_1 + 0x38);
          piVar1[4] = *(int *)(*(int *)(param_1 + 0x38) + 0x10);
          *(int **)(*(int *)(*(int *)(param_1 + 0x38) + 0x10) + 0xc) = piVar1;
          *(int **)(*(int *)(param_1 + 0x38) + 0x10) = piVar1;
        }
      }
      else {
        ((int *)*piVar1)[piVar1[1]] = iVar4;
        piVar1[1] = piVar1[1] + 1;
        if ((piVar1[1] == *(uint *)(param_1 + 0x48) / 0xc) && (3 < *(int *)(param_1 + 0x40))) {
          if (piVar1 == *(int **)(param_1 + 0x38)) {
            *(int *)(param_1 + 0x38) = piVar1[3];
          }
          *(int *)(piVar1[4] + 0xc) = piVar1[3];
          *(int *)(piVar1[3] + 0x10) = piVar1[4];
          *(int *)(param_1 + 0x40) = *(int *)(param_1 + 0x40) + -1;
          FUN_01674ea0(*piVar1);
          FUN_01674ea0(piVar1[2]);
          FUN_01674ea0(piVar1);
        }
      }
      iVar4 = iVar2;
    } while (iVar2 != 0);
  }
  uVar3 = *(int *)(param_1 + 0x2c) + uVar5;
  if (uVar3 < *(uint *)(param_1 + 0x34)) {
    *(undefined4 *)(*(int *)(param_1 + 0x28) + uVar3 * 0x10) = 0;
    return;
  }
  *(undefined4 *)
   (*(int *)(param_1 + 0x28) +
   ((*(int *)(param_1 + 0x2c) - *(uint *)(param_1 + 0x34)) + uVar5) * 0x10) = 0;
  return;
}



/* FUNCTION 6182 ; VA 0x005fe820 ; FUN_005fe820 */

undefined4 __thiscall FUN_005fe820(int param_1,uint param_2,uint param_3,int param_4)

{
  uint *puVar1;
  uint uVar2;
  uint *puVar3;
  undefined *puVar4;
  uint *puVar5;
  uint *puVar6;
  int iVar7;
  undefined4 uVar8;
  char cVar9;
  uint uVar10;
  uint *puVar11;
  undefined8 uVar12;
  uint *puStack_c;
  undefined uStack_5;
  
  uVar10 = *(int *)(param_1 + 0x78) - *(int *)(param_1 + 0x74) >> 2;
  if ((uVar10 & uVar10 - 1) == 0) {
    uVar10 = uVar10 - 1 & param_2;
  }
  else {
    uVar10 = param_2 % uVar10;
  }
  puVar1 = *(uint **)(*(int *)(param_1 + 0x74) + uVar10 * 4);
  if ((puVar1 == (uint *)0x0) || (*puVar1 != param_2)) {
    if (DAT_01d5aed0 != '\0') {
      FUN_00601f20(&param_4,&param_2);
      if (param_4 != *(int *)(param_1 + 0x88)) {
        iVar7 = *(int *)(param_4 + 0x14);
        *(char *)(iVar7 + 0x49) = *(char *)(iVar7 + 0x49) + '\x01';
        cVar9 = *(char *)(iVar7 + 0x49);
        if (*(char *)(iVar7 + 0x4a) != '\0') {
          uVar2 = (*(int *)(iVar7 + 0x38) + 7U >> 3) + (*(int *)(iVar7 + 0x18) + 7U >> 3);
          puVar1 = (uint *)(param_1 + 0x210);
          uVar10 = *puVar1;
          *puVar1 = *puVar1 + uVar2;
          *(int *)(param_1 + 0x214) = *(int *)(param_1 + 0x214) + (uint)CARRY4(uVar10,uVar2);
          cVar9 = *(char *)(iVar7 + 0x49);
        }
        if (cVar9 == *(char *)(iVar7 + 0x48)) {
          uVar8 = FUN_00553830(param_4);
          FUN_01674ea0(uVar8,0x18);
          FUN_005fdb70(param_1 + 0x90,iVar7);
          FUN_005fe570(iVar7);
        }
      }
    }
    return 0xffffffff;
  }
  *(char *)((int)puVar1 + 0x49) = *(char *)((int)puVar1 + 0x49) + '\x01';
  if (*(char *)((int)puVar1 + 0x4a) != '\0') {
    *(int *)(param_1 + 0x1e0) = *(int *)(param_1 + 0x1e0) + -1;
  }
  uVar10 = *(int *)(param_1 + 0x78) - *(int *)(param_1 + 0x74) >> 2;
  if ((uVar10 - 1 & uVar10) == 0) {
    uVar10 = uVar10 - 1 & param_2;
  }
  else {
    uVar10 = param_2 % uVar10;
  }
  *(undefined4 *)(*(int *)(param_1 + 0x74) + uVar10 * 4) = 0;
  *(int *)(param_1 + 0x1b0) = *(int *)(param_1 + 0x1b0) + -1;
  uVar2 = puVar1[6] + 7 >> 3;
  puVar3 = (uint *)(param_1 + 0x1b8);
  uVar10 = *puVar3;
  *puVar3 = *puVar3 - uVar2;
  *(int *)(param_1 + 0x1bc) = *(int *)(param_1 + 0x1bc) - (uint)(uVar10 < uVar2);
  if (*(char *)((int)puVar1 + 0x4a) != '\0') {
    uVar2 = (puVar1[0xe] + 7 >> 3) + (puVar1[6] + 7 >> 3);
    puVar3 = (uint *)(param_1 + 0x210);
    uVar10 = *puVar3;
    *puVar3 = *puVar3 + uVar2;
    *(int *)(param_1 + 0x214) = *(int *)(param_1 + 0x214) + (uint)CARRY4(uVar10,uVar2);
  }
  *(double *)(param_1 + 0x7f8) =
       (double)(puVar1[6] + puVar1[0xe] + 7 >> 3) + DAT_018c0d90 + *(double *)(param_1 + 0x7f8);
  uVar10 = puVar1[7];
  if ((5 < (int)uVar10) && ((puVar1[5] == 0 || (puVar1[4] + 1 == puVar1[5])))) {
    puVar3 = (uint *)FUN_005f98f0();
    puVar3[0x10] = 0;
    puStack_c = puVar3;
    puVar4 = (undefined *)FUN_01674f30(5);
    puVar3[0xf] = (uint)puVar4;
    puVar3[6] = 0x28;
    *puVar4 = 0xe;
    *(uint *)(puVar3[0xf] + 1) = puVar1[0x14];
    FUN_005fe020(&puStack_c,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                 ,0xa01);
    uVar10 = puVar1[7];
  }
  if ((((uVar10 == 2) || (uVar10 == 4)) || (uVar10 == 3)) ||
     ((uVar10 == 6 || (puStack_c = (uint *)((uint)puStack_c & 0xffffff00), uVar10 == 7)))) {
    puStack_c = (uint *)CONCAT31(puStack_c._1_3_,1);
  }
  FUN_005feb60(puVar1,puStack_c);
  FUN_005fa670(puVar1,
               "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
               ,0xa0e);
  if ((DAT_01d5aed0 == '\0') || (*(char *)((int)puVar1 + 0x49) == *(char *)(puVar1 + 0x12))) {
    FUN_005fe570(puVar1);
    return 0;
  }
  puVar3 = *(uint **)(param_1 + 0x88);
  puVar11 = puVar3;
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    puVar5 = (uint *)puVar3[1];
    do {
      if (puVar5[4] < *puVar1) {
        puVar6 = (uint *)puVar5[2];
      }
      else {
        puVar6 = (uint *)*puVar5;
        puVar11 = puVar5;
      }
      puVar5 = puVar6;
    } while (*(char *)((int)puVar6 + 0xd) == '\0');
    if ((puVar11 != puVar3) && (puVar11[4] <= *puVar1)) goto LAB_005fea23;
  }
  puStack_c = puVar1;
  iVar7 = FUN_005f81a0(&DAT_018bdeda,&puStack_c,&uStack_5);
  FUN_005f83b0(&puStack_c,puVar11,iVar7 + 0x10,iVar7);
  puVar11 = puStack_c;
LAB_005fea23:
  if (puVar11[5] != 0) {
    FUN_005fdb70(param_1 + 0x90,puVar11[5]);
    FUN_005fe570(puVar11[5]);
  }
  puVar11[5] = (uint)puVar1;
  uVar12 = (**(code **)(**(int **)(param_1 + 0x7b0) + 0x54))();
  uVar10 = (uint)uVar12 * 2;
  puVar1[0xc] = uVar10 + param_3;
  puVar1[0xd] = ((int)((ulonglong)uVar12 >> 0x20) << 1 | (uint)uVar12 >> 0x1f) + param_4 +
                (uint)CARRY4(uVar10,param_3);
  FUN_005fdb40(param_1 + 0x90,puVar1);
  return 0;
}



/* FUNCTION 6183 ; VA 0x005feb30 ; FUN_005feb30 */

uint __thiscall FUN_005feb30(int param_1,uint param_2)

{
  uint uVar1;
  
  uVar1 = *(int *)(param_1 + 0x78) - *(int *)(param_1 + 0x74) >> 2;
  if ((uVar1 & uVar1 - 1) == 0) {
    return uVar1 - 1 & param_2;
  }
  return param_2 % uVar1;
}



/* FUNCTION 6184 ; VA 0x005feb60 ; FUN_005feb60 */

void __thiscall FUN_005feb60(int param_1,int param_2,char param_3)

{
  int iVar1;
  
  *(undefined4 *)(*(int *)(param_2 + 0x54) + 0x58) = *(undefined4 *)(param_2 + 0x58);
  *(undefined4 *)(*(int *)(param_2 + 0x58) + 0x54) = *(undefined4 *)(param_2 + 0x54);
  if ((*(int *)(param_1 + 0x80) == param_2) &&
     (iVar1 = *(int *)(param_2 + 0x58), *(int *)(param_1 + 0x80) = iVar1, iVar1 == param_2)) {
    *(undefined4 *)(param_1 + 0x80) = 0;
  }
  if (param_3 != '\0') {
    *(int *)(param_1 + 0x7b4) =
         *(int *)(param_1 + 0x7b4) -
         ((uint)(*(int *)(param_2 + 0x18) + 7 + *(int *)(param_2 + 0x38)) >> 3);
    if (*(int *)(param_1 + 0x7b8) != 0) {
      *(int *)(param_1 + 0x7b8) = *(int *)(param_1 + 0x7b8) + -1;
    }
  }
  return;
}



/* FUNCTION 6185 ; VA 0x005febe0 ; FUN_005febe0 */

void __fastcall FUN_005febe0(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[2] = 0;
  param_1[3] = 0;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_1[7] != 0) {
    if (0x20 < (uint)param_1[7]) {
      iVar1 = param_1[4];
      if (iVar1 != 0) {
        uStack_8 = 0;
        FUN_016f32d1(iVar1,0x10,*(undefined4 *)(iVar1 + -4),_guard_check_icall);
        FUN_01674ea0((int *)(iVar1 + -4),*(int *)(iVar1 + -4) * 0x10 + 4);
      }
      param_1[7] = 0;
    }
    param_1[5] = 0;
    param_1[6] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6186 ; VA 0x005fec80 ; FUN_005fec80 */

void __thiscall FUN_005fec80(int param_1,char param_2,int param_3)

{
  code *pcVar1;
  undefined8 uVar2;
  
  FUN_005fa800();
  if (param_2 == '\0') {
    if (DAT_01d59d10 == '\0') {
      return;
    }
  }
  else {
    FUN_005fcce0();
  }
  pcVar1 = *(code **)(**(int **)(param_1 + 0x7b0) + 4);
  uVar2 = FUN_006a6920();
  (*pcVar1)(uVar2,param_3 + -0x3a);
  return;
}



/* FUNCTION 6187 ; VA 0x005fecd0 ; FUN_005fecd0 */

void __fastcall FUN_005fecd0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}



/* FUNCTION 6188 ; VA 0x005fed10 ; FUN_005fed10 */

void __fastcall FUN_005fed10(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x005fed20. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x7b0) + 8))();
  return;
}



/* FUNCTION 6189 ; VA 0x005fed30 ; FUN_005fed30 */

undefined4 __thiscall
FUN_005fed30(int param_1,undefined4 param_2,int param_3,int param_4,int param_5,byte param_6,
            char param_7,undefined4 param_8,undefined4 param_9,undefined4 param_10,
            undefined4 param_11,undefined4 param_12,uint param_13)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  byte bStack00000017;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iStack_c = param_5;
  if ((7 < param_5) || (param_5 < 0)) {
    iStack_c = 2;
  }
  param_5 = param_4;
  if ((4 < param_4) || (param_4 < 0)) {
    param_5 = 1;
  }
  bStack00000017 = -(param_6 < 0x20) & param_6;
  uVar11 = param_3 + 7U >> 3;
  if (param_3 == 0) {
    return 0;
  }
  iStack_8 = param_1;
  iVar7 = FUN_005f98f0();
  uVar5 = param_10;
  uVar4 = param_9;
  iStack_10 = iVar7;
  if (iVar7 == 0) {
    FUN_006a35a0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                 ,0x62b);
    return 0;
  }
  if ((char)param_13 != '\0') {
    puVar1 = (uint *)(param_1 + 0x1e8);
    uVar3 = *puVar1;
    *puVar1 = *puVar1 + uVar11;
    *(int *)(param_1 + 0x1ec) = *(int *)(param_1 + 0x1ec) + (uint)CARRY4(uVar3,uVar11);
  }
  puVar1 = (uint *)(param_1 + 0x1c8);
  uVar3 = *puVar1;
  *puVar1 = *puVar1 + uVar11;
  *(int *)(param_1 + 0x1cc) = *(int *)(param_1 + 0x1cc) + (uint)CARRY4(uVar3,uVar11);
  FUN_005fdd50(param_9,param_10,uVar11,0);
  *(undefined4 *)(iVar7 + 0x28) = uVar4;
  *(undefined4 *)(iVar7 + 0x2c) = uVar5;
  if (param_7 == '\0') {
    *(undefined4 *)(iVar7 + 0x40) = 0;
    *(undefined4 *)(iVar7 + 0x3c) = param_2;
  }
  else {
    if (uVar11 < 0x81) {
      *(undefined4 *)(iVar7 + 0x40) = 2;
      iVar8 = iVar7 + 100;
    }
    else {
      *(undefined4 *)(iVar7 + 0x40) = 0;
      iVar8 = FUN_01674f30(uVar11);
    }
    *(int *)(iVar7 + 0x3c) = iVar8;
    FUN_0170c6f0(iVar8,param_2,uVar11);
  }
  iVar6 = iStack_8;
  iVar8 = DAT_01d59d68;
  *(int *)(iVar7 + 0x18) = param_3;
  uVar3 = *(uint *)(iStack_8 + 0xd8);
  *(uint *)(iStack_8 + 0xd8) = uVar3 + 1;
  *(undefined *)(iStack_8 + 0xdb) = 0;
  *(uint *)(iVar7 + 0x20) = uVar3 & 0xffffff;
  *(int *)(iVar7 + 0x4c) = param_5;
  *(int *)(iVar7 + 0x1c) = iStack_c;
  *(undefined4 *)(iVar7 + 0x50) = param_11;
  *(char *)(iVar7 + 0x4a) = (char)param_13;
  iVar9 = FUN_005fb3c0(param_12);
  param_13 = iVar9 - (iVar8 + 7U >> 3);
  if (param_13 < uVar11) {
    iVar8 = *(int *)(iVar7 + 0x1c);
    if (iVar8 == 0) {
      *(undefined4 *)(iVar7 + 0x1c) = 2;
    }
    else if (iVar8 == 5) {
      *(undefined4 *)(iVar7 + 0x1c) = 6;
    }
    else if (iVar8 == 1) {
      *(undefined4 *)(iVar7 + 0x1c) = 4;
    }
  }
  iVar8 = *(int *)(iVar7 + 0x1c);
  if ((iVar8 == 4) || (iVar8 == 1)) {
    uVar10 = (uint)bStack00000017;
    *(byte *)(iVar7 + 0xc) = bStack00000017;
    *(undefined4 *)(iVar7 + 4) = *(undefined4 *)(iVar6 + 0x2a0 + uVar10 * 4);
    uVar3 = *(uint *)(iVar6 + 800 + uVar10 * 4);
    *(uint *)(iVar6 + 800 + uVar10 * 4) = uVar3 + 1;
    *(undefined *)(iVar6 + 0x323 + uVar10 * 4) = 0;
    *(uint *)(iVar7 + 8) = uVar3 & 0xffffff;
  }
  else if ((iVar8 == 3) || (iVar8 == 7)) {
    uVar10 = (uint)bStack00000017;
    *(byte *)(iVar7 + 0xc) = bStack00000017;
    uVar3 = *(uint *)(iVar6 + 0x2a0 + uVar10 * 4);
    *(uint *)(iVar6 + 0x2a0 + uVar10 * 4) = uVar3 + 1;
    *(undefined *)(iVar6 + 0x2a3 + uVar10 * 4) = 0;
    *(uint *)(iVar7 + 4) = uVar3 & 0xffffff;
    *(undefined4 *)(iVar6 + 800 + uVar10 * 4) = 0;
  }
  if (param_13 < uVar11) {
    FUN_005ffd90(iVar7,param_12);
    return 1;
  }
  FUN_005f95b0(iVar7);
  _param_9 = FUN_005fb520(*(undefined4 *)(iVar7 + 0x4c));
  FUN_005fdef0(&param_9,&iStack_10,
               "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
               ,0x694);
  piVar2 = (int *)(iVar6 + 0x180 + *(int *)(iVar7 + 0x4c) * 4);
  *piVar2 = *piVar2 + 1;
  *(double *)(iVar6 + 400 + *(int *)(iVar7 + 0x4c) * 8) =
       (double)(*(int *)(iVar7 + 0x18) + 7U >> 3) + DAT_018c0d90 +
       *(double *)(iVar6 + 400 + *(int *)(iVar7 + 0x4c) * 8);
  return 1;
}



/* FUNCTION 6190 ; VA 0x005feff0 ; FUN_005feff0 */

void __thiscall
FUN_005feff0(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6,int *param_7)

{
  code *pcVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined uVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int iVar8;
  int *piStack_5c;
  undefined auStack_54 [4];
  float fStack_50;
  undefined2 uStack_4c;
  char cStack_4a;
  char cStack_49;
  char cStack_48;
  char cStack_46;
  undefined auStack_44 [8];
  double dStack_3c;
  undefined8 uStack_34;
  undefined8 uStack_2c;
  int *piStack_24;
  undefined4 uStack_20;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  longlong lStack_14;
  int iStack_c;
  char cStack_6;
  char cStack_5;
  
  piStack_24 = param_1;
  if ((DAT_01d59d40 == '\0') || (*param_7 == 0)) {
    lStack_14._0_4_ = 0;
  }
  else {
    lStack_14._0_4_ = FUN_006a6780();
    lStack_14._0_4_ = (uint)lStack_14 & 0xffff;
  }
  cVar4 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
  iStack_c = (**(code **)(*(int *)param_1[0x1ec] + 0x5c))();
  iStack_c = (((uint)(cVar4 == '\0') * 4 + -0xd) - (uint)lStack_14) + iStack_c;
  if ((*param_1 != 0) && (cVar4 = FUN_00686be0(), cVar4 != '\0')) {
    iStack_c = iStack_c + -0x12;
  }
  iStack_c = iStack_c << 3;
  lStack_14 = FUN_006a6920();
  cStack_5 = (**(code **)(*(int *)param_1[0x1ec] + 0x50))(&uStack_34,&uStack_2c);
  piVar3 = param_6;
  if (cStack_5 != '\0') {
    iStack_c = iStack_c + -6;
  }
  iVar2 = param_1[0x208];
  iVar8 = iStack_c;
  while (iVar2 != 0) {
    iStack_c = iVar8;
    FUN_006a5be0();
    if ((DAT_01d59d40 != '\0') && (*param_7 != 0)) {
      FUN_006a67e0(piVar3);
    }
    cStack_46 = cStack_5;
    uStack_4c = 1;
    cVar4 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
    if (cVar4 != '\0') {
      piStack_5c = param_4;
    }
    if (*(char *)(param_1 + 0x20d) == '\0') {
      cStack_4a = '\0';
    }
    else {
      (**(code **)(*(int *)param_1[0x1ec] + 0x44))(param_4,param_5,&cStack_6,auStack_44,&dStack_3c);
      fStack_50 = (float)dStack_3c;
      cStack_4a = cStack_6;
      iVar8 = iStack_c;
    }
    cVar4 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
    if (cVar4 != '\0') {
      piStack_5c = (int *)param_1[0x1ea];
    }
    if (DAT_01d59d40 == '\0') {
      FUN_006a5be0();
    }
    uVar5 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
    param_6 = (int *)CONCAT13(uVar5,param_6._0_3_);
    FUN_006a5d50();
    if ((char)uStack_4c == '\0') {
      if (uStack_4c._1_1_ == '\0') {
        FUN_006a5d20();
        FUN_006a5d20();
        FUN_006a5d20();
        if (cStack_49 == '\0') {
          FUN_006a5d20();
        }
        else {
          FUN_006a5d50();
        }
        if (cStack_48 == '\0') {
          FUN_006a5d20();
        }
        else {
          FUN_006a5d50();
        }
        piVar3[2] = (piVar3[2] - (piVar3[2] - 1U & 7)) + 7;
        if (param_6._3_1_ != '\0') {
          param_6 = piStack_5c;
          cVar4 = FUN_005fda50();
          if (cVar4 == '\0') {
            FUN_006a5c10(&param_6,&uStack_20,4);
            puVar6 = &uStack_20;
          }
          else {
            puVar6 = &param_6;
          }
          FUN_006a6060(puVar6,0x20,1);
        }
        FUN_005f8120(auStack_54);
      }
      else {
        FUN_006a5d20();
        FUN_006a5d50();
      }
    }
    else {
      FUN_006a5d50();
      if (cStack_4a == '\0') {
        FUN_006a5d20();
      }
      else {
        FUN_006a5d50();
      }
      if (cStack_46 == '\0') {
        FUN_006a5d20();
      }
      else {
        FUN_006a5d50();
      }
      piVar3[2] = (piVar3[2] - (piVar3[2] - 1U & 7)) + 7;
      if (param_6._3_1_ != '\0') {
        param_6 = piStack_5c;
        cVar4 = FUN_005fda50();
        if (cVar4 == '\0') {
          FUN_006a5c10(&param_6,&uStack_18,4);
          puVar6 = &uStack_18;
        }
        else {
          puVar6 = &param_6;
        }
        FUN_006a6060(puVar6,0x20,1);
      }
      if (cStack_4a != '\0') {
        cVar4 = FUN_005fda50();
        if (cVar4 == '\0') {
          FUN_006a5c10(&fStack_50,auStack_1c,4);
          FUN_006a6060(auStack_1c,0x20,1);
        }
        else {
          FUN_006a6060(&fStack_50,0x20,1);
        }
      }
    }
    FUN_005ff630(piVar3,iVar8,1);
    if ((cStack_5 != '\0') && (param_1[0x208] == 0)) {
      uStack_34 = lStack_14 - uStack_34;
      uStack_2c = lStack_14 - uStack_2c;
      param_6 = (int *)(uStack_34 + -1);
      if (((int)((ulonglong)(uStack_34 + -1) >> 0x20) == 0) &&
         (((param_6 < (int *)0xffffff && ((int)((ulonglong)(uStack_2c + -1) >> 0x20) == 0)) &&
          ((uint)(uStack_2c + -1) < 0xffffff)))) {
        param_6 = (int *)((uint)uStack_34 & 0xffffff);
        FUN_005f8120(&param_6);
        param_6 = (int *)((uint)uStack_2c & 0xffffff);
        FUN_005f8120(&param_6);
      }
    }
    cStack_5 = '\0';
    FUN_005ff420(param_2,param_3,piVar3,lStack_14,param_7);
    pcVar1 = *(code **)(*(int *)param_1[0x1ec] + 0x48);
    uVar7 = (**(code **)(*piVar3 + 8))();
    (*pcVar1)(lStack_14,uVar7);
    param_1 = piStack_24;
    iVar8 = iStack_c;
    iVar2 = piStack_24[0x208];
  }
  return;
}



/* FUNCTION 6191 ; VA 0x005ff3f0 ; FUN_005ff3f0 */

void __thiscall FUN_005ff3f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  *(undefined4 *)(param_1 + 0x7a8) = param_3;
  *(undefined4 *)(param_1 + 0x7ac) = param_4;
  FUN_005fd4b0(param_2);
  return;
}



/* FUNCTION 6192 ; VA 0x005ff420 ; FUN_005ff420 */

void __thiscall
FUN_005ff420(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            undefined4 param_6,int *param_7)

{
  uint *puVar1;
  uint uVar2;
  code *pcVar3;
  bool bVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  uint uStack_18;
  uint uStack_14;
  int iStack_10;
  uint uStack_c;
  
  uStack_c = (**(code **)(*param_4 + 8))();
  if ((*param_1 == 0) || (cVar5 = FUN_00686be0(), cVar5 == '\0')) {
    bVar4 = false;
    *(undefined *)(param_1 + 0x37) = 1;
  }
  else {
    bVar4 = true;
    iStack_10 = (**(code **)(*param_4 + 4))();
    uStack_14 = uStack_c + 0x12;
    uStack_18 = 0;
    if ((DAT_01d59d40 != '\0') && (*param_7 != 0)) {
      uStack_18 = FUN_006a6780();
      uStack_18 = uStack_18 & 0xffff;
      iStack_10 = iStack_10 + uStack_18;
      uStack_14 = uStack_14 - uStack_18;
    }
    FUN_006a5860(uStack_14);
    if (DAT_01d59d10 != '\0') {
      pcVar3 = *(code **)(*(int *)param_1[0x1ec] + 0x24);
      uVar6 = (**(code **)(*param_4 + 4))();
      (*pcVar3)(param_5,param_6,uVar6,uStack_c,1);
    }
    FUN_006869d0(iStack_10,uStack_14);
    uStack_c = uStack_14;
    if ((DAT_01d59d40 != '\0') && (*param_7 != 0)) {
      uStack_c = uStack_18 + uStack_14;
    }
  }
  FUN_005fdd50(param_5,param_6,uStack_c,0);
  uVar6 = (**(code **)(*param_4 + 4))
                    (uStack_c,param_3,
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                     ,0x974);
  iVar7 = FUN_006952f0(param_2,uVar6);
  if ((DAT_01d59d10 != '\0') && (!bVar4)) {
    pcVar3 = *(code **)(*(int *)param_1[0x1ec] + 0x24);
    uVar6 = (**(code **)(*param_4 + 4))();
    (*pcVar3)(param_5,param_6,uVar6,uStack_c,0);
  }
  if (*(char *)(param_4 + 1) != '\0') {
    puVar1 = (uint *)(param_1 + 0x7c);
    uVar2 = *puVar1;
    *puVar1 = *puVar1 + uStack_c;
    param_1[0x7d] = param_1[0x7d] + (uint)CARRY4(uVar2,uStack_c);
  }
  if (DAT_01d59d28 != '\0') {
    param_1[0x93] = param_1[0x93] + uStack_c;
  }
  if (iVar7 == 2) {
    if (DAT_01d59d08 != '\0') {
      if (DAT_01ee420b != '\0') {
        FUN_016774b0(DAT_01ee420b,"Could not send data to server/client, network/host unreachable!",
                     0);
      }
      *(undefined *)(param_1 + 0x37) = 1;
      return;
    }
  }
  else if (iVar7 == 1) {
    if (DAT_01ee420b == '\0') {
      return;
    }
    FUN_016774b0(DAT_01ee420b,"Could not send data, poor connection?",0);
    return;
  }
  puVar1 = (uint *)(param_1 + 0x74);
  uVar2 = *puVar1;
  *puVar1 = *puVar1 + uStack_c;
  param_1[0x75] = param_1[0x75] + (uint)CARRY4(uVar2,uStack_c);
  return;
}



/* FUNCTION 6193 ; VA 0x005ff630 ; FUN_005ff630 */

uint __thiscall FUN_005ff630(int *param_1,int param_2,uint param_3,char param_4)

{
  int iVar1;
  undefined4 *puVar2;
  char cVar3;
  uint *puVar4;
  undefined uVar5;
  undefined *puVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  undefined auStack_13c [8];
  uint uStack_134;
  int iStack_128;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179cb1b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006a5600();
  uStack_8 = 0;
  uStack_18 = 0;
  uStack_20 = 0;
  if (param_1[1] != 0) {
    uVar10 = 0x51;
    do {
      if (param_3 < uVar10) break;
      iStack_1c = uStack_20 * 8;
      uStack_11 = *(int *)(iStack_1c + *param_1) == ((int *)(iStack_1c + *param_1))[1];
      FUN_006a6060(&uStack_11,8,1);
      puVar6 = (undefined *)(*param_1 + iStack_1c);
      uStack_134 = uStack_134 + (7 - (uStack_134 - 1 & 7));
      FUN_006a5700(0x18);
      cVar3 = FUN_005fda50();
      if (cVar3 == '\0') {
        *(undefined *)((uStack_134 >> 3) + iStack_128) = *puVar6;
        *(undefined *)((uStack_134 >> 3) + 1 + iStack_128) = puVar6[1];
        uVar5 = puVar6[2];
      }
      else {
        *(undefined *)((uStack_134 >> 3) + iStack_128) = puVar6[3];
        *(undefined *)((uStack_134 >> 3) + 1 + iStack_128) = puVar6[2];
        uVar5 = puVar6[1];
      }
      uVar9 = uVar10 + 0x28;
      *(undefined *)((uStack_134 >> 3) + 2 + iStack_128) = uVar5;
      piVar7 = (int *)(iStack_1c + *param_1);
      uVar8 = uStack_134 + 0x18;
      if (*piVar7 != piVar7[1]) {
        uStack_134 = ((uStack_134 + 0x18) - (uStack_134 + 0x17 & 7)) + 7;
        FUN_006a5700(0x18);
        cVar3 = FUN_005fda50();
        if (cVar3 == '\0') {
          *(undefined *)((uStack_134 >> 3) + iStack_128) = *(undefined *)(piVar7 + 1);
          *(undefined *)((uStack_134 >> 3) + 1 + iStack_128) = *(undefined *)((int)piVar7 + 5);
          uVar5 = *(undefined *)((int)piVar7 + 6);
        }
        else {
          *(undefined *)((uStack_134 >> 3) + iStack_128) = *(undefined *)((int)piVar7 + 7);
          *(undefined *)((uStack_134 >> 3) + 1 + iStack_128) = *(undefined *)((int)piVar7 + 6);
          uVar5 = *(undefined *)((int)piVar7 + 5);
        }
        *(undefined *)((uStack_134 >> 3) + 2 + iStack_128) = uVar5;
        uVar9 = uVar10 + 0x48;
        uVar8 = uStack_134 + 0x18;
      }
      uStack_134 = uVar8;
      uStack_18 = uStack_18 + 1;
      uStack_20 = uStack_20 + 1;
      uVar10 = uVar9;
    } while (uStack_20 < (uint)param_1[1]);
  }
  iVar1 = (*(int *)(param_2 + 8) - (*(int *)(param_2 + 8) - 1U & 7)) + 7;
  *(int *)(param_2 + 8) = iVar1;
  cVar3 = FUN_005fda50();
  if (cVar3 == '\0') {
    FUN_006a5c10(&uStack_18,&param_3,2);
    puVar4 = &param_3;
  }
  else {
    puVar4 = &uStack_18;
  }
  FUN_006a6060(puVar4,0x10,1);
  FUN_006a5d90(auStack_13c,uStack_134);
  param_3 = *(int *)(param_2 + 8) - iVar1;
  if ((param_4 != '\0') && ((short)uStack_18 != 0)) {
    uVar10 = param_1[1];
    uVar8 = 0;
    if (uVar10 != (uStack_18 & 0xffff)) {
      do {
        iVar1 = *param_1;
        puVar2 = (undefined4 *)(iVar1 + ((uStack_18 & 0xffff) + uVar8) * 8);
        *(undefined4 *)(iVar1 + uVar8 * 8) = *puVar2;
        *(undefined4 *)(iVar1 + 4 + uVar8 * 8) = puVar2[1];
        uVar8 = uVar8 + 1;
      } while (uVar8 < uVar10 - (uStack_18 & 0xffff));
      uVar10 = param_1[1];
    }
    param_1[1] = uVar10 - (uStack_18 & 0xffff);
  }
  FUN_006a5640();
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 6194 ; VA 0x005ff8f0 ; FUN_005ff8f0 */

void __thiscall FUN_005ff8f0(undefined4 *param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  
  FUN_006a5d50();
  if (*(char *)(param_1 + 4) == '\0') {
    cVar1 = *(char *)((int)param_1 + 0x11);
    FUN_006a5d20();
    if (cVar1 != '\0') {
      FUN_006a5d50();
      return;
    }
    FUN_006a5d20();
    FUN_006a5d20();
    if (*(char *)((int)param_1 + 0x13) == '\0') {
      FUN_006a5d20();
    }
    else {
      FUN_006a5d50();
    }
    if (*(char *)(param_1 + 5) == '\0') {
      FUN_006a5d20();
    }
    else {
      FUN_006a5d50();
    }
    *(uint *)(param_2 + 8) = (*(int *)(param_2 + 8) - (*(int *)(param_2 + 8) - 1U & 7)) + 7;
    if ((char)param_3 != '\0') {
      param_3 = *param_1;
      FUN_005f80d0(&param_3);
    }
    FUN_005f8120(param_1 + 2);
  }
  else {
    FUN_006a5d50();
    if (*(char *)((int)param_1 + 0x12) == '\0') {
      FUN_006a5d20();
    }
    else {
      FUN_006a5d50();
    }
    if (*(char *)((int)param_1 + 0x16) == '\0') {
      FUN_006a5d20();
    }
    else {
      FUN_006a5d50();
    }
    *(uint *)(param_2 + 8) = (*(int *)(param_2 + 8) - (*(int *)(param_2 + 8) - 1U & 7)) + 7;
    if ((char)param_3 != '\0') {
      param_3 = *param_1;
      FUN_005f80d0(&param_3);
    }
    if (*(char *)((int)param_1 + 0x12) != '\0') {
      cVar1 = FUN_005fda50();
      if (cVar1 == '\0') {
        FUN_006a5c10(param_1 + 3,&param_3,4);
        FUN_006a6060(&param_3,0x20,1);
        return;
      }
      FUN_006a6060(param_1 + 3,0x20,1);
      return;
    }
  }
  return;
}



/* FUNCTION 6195 ; VA 0x005ffa40 ; FUN_005ffa40 */

void __thiscall FUN_005ffa40(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x18) = param_2;
  return;
}



/* FUNCTION 6196 ; VA 0x005ffa50 ; FUN_005ffa50 */

void __thiscall FUN_005ffa50(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0xe0) = param_2;
  return;
}



/* FUNCTION 6197 ; VA 0x005ffa60 ; FUN_005ffa60 */

void __thiscall FUN_005ffa60(int param_1,uint param_2)

{
  *(ulonglong *)(param_1 + 0x20) = (ulonglong)param_2 * 1000;
  return;
}



/* FUNCTION 6198 ; VA 0x005ffa80 ; FUN_005ffa80 */

int __fastcall FUN_005ffa80(int param_1)

{
  uint uVar1;
  uint uVar2;
  
  uVar1 = *(uint *)(param_1 + 8);
  uVar2 = *(uint *)(param_1 + 4);
  if (uVar2 <= uVar1) {
    return uVar1 - uVar2;
  }
  return (*(int *)(param_1 + 0xc) - uVar2) + uVar1;
}



/* FUNCTION 6199 ; VA 0x005ffaa0 ; FUN_005ffaa0 */

void __thiscall FUN_005ffaa0(int param_1,int param_2)

{
  int iVar1;
  undefined auStack_28 [14];
  undefined uStack_1a;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x288) != 0) {
    if (999 < (uint)(param_2 - *(int *)(param_1 + 0x288))) {
      ExceptionList = &pvStack_10;
      *(undefined4 *)(param_1 + 0x220) = *(undefined4 *)(param_1 + 0x248);
      *(undefined4 *)(param_1 + 0x224) = *(undefined4 *)(param_1 + 0x24c);
      *(undefined4 *)(param_1 + 0x228) = *(undefined4 *)(param_1 + 0x250);
      *(undefined4 *)(param_1 + 0x22c) = *(undefined4 *)(param_1 + 0x254);
      *(undefined4 *)(param_1 + 0x230) = *(undefined4 *)(param_1 + 600);
      *(undefined4 *)(param_1 + 0x234) = *(undefined4 *)(param_1 + 0x25c);
      *(undefined4 *)(param_1 + 0x238) = *(undefined4 *)(param_1 + 0x260);
      *(undefined4 *)(param_1 + 0x23c) = *(undefined4 *)(param_1 + 0x264);
      if (DAT_01eacda8 != 0) {
        *(int *)(param_1 + 0x268) = *(int *)(param_1 + 0x268) + *(int *)(param_1 + 0x248);
        *(int *)(param_1 + 0x26c) = *(int *)(param_1 + 0x26c) + *(int *)(param_1 + 0x24c);
        *(int *)(param_1 + 0x270) = *(int *)(param_1 + 0x270) + *(int *)(param_1 + 0x250);
        *(int *)(param_1 + 0x274) = *(int *)(param_1 + 0x274) + *(int *)(param_1 + 0x254);
        *(int *)(param_1 + 0x278) = *(int *)(param_1 + 0x278) + *(int *)(param_1 + 600);
        *(int *)(param_1 + 0x27c) = *(int *)(param_1 + 0x27c) + *(int *)(param_1 + 0x25c);
        *(int *)(param_1 + 0x280) = *(int *)(param_1 + 0x280) + *(int *)(param_1 + 0x260);
        *(int *)(param_1 + 0x284) = *(int *)(param_1 + 0x284) + *(int *)(param_1 + 0x264);
        if ((uint)(DAT_01d59ca4 * 1000) <= (uint)(param_2 - *(int *)(param_1 + 0x28c))) {
          FUN_0151f6f0(DAT_01eacda8,0,0);
          uStack_8 = 0;
          FUN_0151fa60("availableCapacityBytes",*(undefined4 *)(param_1 + 0x268));
          FUN_0151fa60("allBytes",*(undefined4 *)(param_1 + 0x26c));
          FUN_0151fa60("reliablePacketBytes",*(undefined4 *)(param_1 + 0x270));
          FUN_0151fa60("reliablePackets",*(undefined4 *)(param_1 + 0x274));
          FUN_0151fa60("reliablePacketBytesRe",*(undefined4 *)(param_1 + 0x278));
          FUN_0151fa60("reliablePacketsRe",*(undefined4 *)(param_1 + 0x27c));
          FUN_0151fa60("unreliablePacketBytes",*(undefined4 *)(param_1 + 0x280));
          FUN_0151fa60("unreliablePackets",*(undefined4 *)(param_1 + 0x284));
          FUN_0151f9c0("collectionDurationInSeconds",DAT_01d59ca4);
          iVar1 = DAT_01eacda8;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          uStack_18 = 0xe;
          FUN_0170cc70(auStack_28,"RccRakPeerTxBw",0xe);
          uStack_1a = 0;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_01520d20(auStack_28,iVar1,0);
          FUN_005507b0();
          FUN_005fecd0();
          *(int *)(param_1 + 0x28c) = param_2;
          uStack_8 = 0xffffffff;
          FUN_0151f7f0();
        }
      }
      *(undefined4 *)(param_1 + 0x248) = 0;
      *(undefined4 *)(param_1 + 0x24c) = 0;
      *(undefined4 *)(param_1 + 0x250) = 0;
      *(undefined4 *)(param_1 + 0x254) = 0;
      *(undefined4 *)(param_1 + 600) = 0;
      *(undefined4 *)(param_1 + 0x25c) = 0;
      *(undefined4 *)(param_1 + 0x260) = 0;
      *(undefined4 *)(param_1 + 0x264) = 0;
      *(int *)(param_1 + 0x288) = param_2;
      if (DAT_01eacd98 != '\0') {
        FUN_01677520(DAT_01eacd98,
                     "TxBwStats : availableCapacity = %d; allBytes = %d; reliablePacketBytes = %d; reliablePackets = %d; reliablePacketBytesRe = %d; reliablePacketsRe = %d; unreliablePacketBytes = %d; unreliablePackets = %d;"
                     ,*(undefined4 *)(param_1 + 0x220),*(undefined4 *)(param_1 + 0x224),
                     *(undefined4 *)(param_1 + 0x228),*(undefined4 *)(param_1 + 0x22c),
                     *(undefined4 *)(param_1 + 0x230),*(undefined4 *)(param_1 + 0x234),
                     *(undefined4 *)(param_1 + 0x238),*(undefined4 *)(param_1 + 0x23c));
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  *(int *)(param_1 + 0x288) = param_2;
  *(int *)(param_1 + 0x28c) = param_2;
  return;
}



/* FUNCTION 6200 ; VA 0x005ffd90 ; FUN_005ffd90 */

/* WARNING: Function: __alloca_probe_16 replaced with injection: alloca_probe */

void __thiscall FUN_005ffd90(int *param_1,undefined4 *param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  undefined8 uVar12;
  undefined8 uStack_44;
  int iStack_3c;
  undefined8 uStack_34;
  int iStack_2c;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  uint uStack_14;
  int iStack_10;
  uint uStack_c;
  int *piStack_8;
  
  param_2[5] = 1;
  uVar12 = FUN_005fb410(param_2[7],1);
  uStack_24 = (undefined4)uVar12;
  uStack_c = *(int *)((int)((ulonglong)uVar12 >> 0x20) + 0x18) + 7U >> 3;
  cVar3 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
  iVar4 = (**(code **)(*(int *)param_1[0x1ec] + 0x5c))();
  iVar4 = (((uint)(cVar3 == '\0') * 4 + -0xd) - param_3) + iVar4;
  if ((*param_1 != 0) && (cVar3 = FUN_00686be0(), cVar3 != '\0')) {
    iVar4 = iVar4 + -0x12;
  }
  uStack_14 = iVar4 - (DAT_01d59d68 + 7U >> 3);
  iVar4 = (uStack_c - 1) / uStack_14 + 1;
  param_2[5] = iVar4;
  uVar5 = iVar4 * 4;
  if (99999 < uVar5) {
    iStack_10 = iVar4;
    piStack_8 = (int *)FUN_01674f30(uVar5);
    iVar4 = param_2[5];
  }
  else {
    piStack_8 = (int *)&stack0xffffffb0;
  }
  iStack_10 = 0;
  if (0 < iVar4) {
    do {
      piVar11 = piStack_8;
      puVar6 = (undefined4 *)FUN_005f98f0();
      piVar11[iStack_10] = (int)puVar6;
      *puVar6 = *param_2;
      puVar6[1] = param_2[1];
      puVar6[2] = param_2[2];
      *(undefined *)(puVar6 + 3) = *(undefined *)(param_2 + 3);
      *(undefined2 *)((int)puVar6 + 0xe) = *(undefined2 *)((int)param_2 + 0xe);
      puVar6[4] = param_2[4];
      puVar6[5] = param_2[5];
      puVar6[6] = param_2[6];
      puVar6[7] = param_2[7];
      puVar6[8] = param_2[8];
      *(undefined *)(puVar6 + 9) = *(undefined *)(param_2 + 9);
      puVar6[10] = param_2[10];
      puVar6[0xb] = param_2[0xb];
      puVar6[0xc] = param_2[0xc];
      puVar6[0xd] = param_2[0xd];
      puVar6[0xe] = param_2[0xe];
      puVar6[0xf] = param_2[0xf];
      puVar6[0x10] = param_2[0x10];
      puVar6[0x11] = param_2[0x11];
      *(undefined *)(puVar6 + 0x12) = *(undefined *)(param_2 + 0x12);
      *(undefined *)((int)puVar6 + 0x49) = *(undefined *)((int)param_2 + 0x49);
      *(undefined *)((int)puVar6 + 0x4a) = *(undefined *)((int)param_2 + 0x4a);
      puVar6[0x13] = param_2[0x13];
      puVar6[0x14] = param_2[0x14];
      puVar6[0x15] = param_2[0x15];
      puVar6[0x16] = param_2[0x16];
      puVar6[0x17] = param_2[0x17];
      puVar6[0x18] = param_2[0x18];
      iVar4 = 0x80;
      puVar8 = puVar6 + 0x19;
      do {
        *(undefined *)puVar8 = *(undefined *)(((int)param_2 - (int)puVar6) + (int)puVar8);
        iVar4 = iVar4 + -1;
        puVar8 = (undefined4 *)((int)puVar8 + 1);
      } while (iVar4 != 0);
      *(undefined *)(piStack_8[iStack_10] + 0x24) = 0;
      if (iStack_10 != 0) {
        uVar10 = param_1[0x36];
        param_1[0x36] = uVar10 + 1;
        *(undefined *)((int)param_1 + 0xdb) = 0;
        param_2[8] = uVar10 & 0xffffff;
      }
      iStack_10 = iStack_10 + 1;
    } while (iStack_10 < (int)param_2[5]);
  }
  uVar10 = 0;
  uStack_18 = 0;
  iStack_10 = 0;
  do {
    uStack_20._4_4_ = uStack_14;
    if ((int)uStack_c <= (int)uStack_14) {
      uStack_20._4_4_ = uStack_c;
    }
    FUN_005f9600(piStack_8[uVar10],&uStack_18,param_2[0xf],iStack_10 + param_2[0xf]);
    if (uStack_20._4_4_ == uStack_14) {
      iVar4 = uStack_20._4_4_ << 3;
    }
    else {
      iVar4 = param_2[6] - uStack_14 * 8 * uVar10;
    }
    iStack_10 = iStack_10 + uStack_14;
    *(int *)(piStack_8[uVar10] + 0x18) = iVar4;
    *(uint *)(piStack_8[uVar10] + 0x10) = uVar10;
    *(undefined2 *)(piStack_8[uVar10] + 0xe) = *(undefined2 *)((int)param_1 + 0xde);
    piVar11 = piStack_8 + uVar10;
    uVar10 = uVar10 + 1;
    *(undefined4 *)(*piVar11 + 0x14) = param_2[5];
    uStack_c = uStack_c - uStack_14;
  } while (uVar10 < (uint)param_2[5]);
  *(short *)((int)param_1 + 0xde) = *(short *)((int)param_1 + 0xde) + 1;
  *(undefined *)(param_1 + 0x29) = 0;
  uStack_14 = 0;
  piVar11 = piStack_8;
  if (0 < (int)param_2[5]) {
    do {
      *(undefined4 *)(*piVar11 + 0x38) = uStack_24;
      iVar4 = *piVar11;
      iVar1 = *(int *)(iVar4 + 0x1c);
      if (((iVar1 == 0) || (iVar1 == 1)) || (iVar1 == 5)) {
        if (param_1[0x21] == 0) {
          *(int *)(iVar4 + 0x60) = iVar4;
          *(int *)(iVar4 + 0x5c) = iVar4;
          param_1[0x21] = iVar4;
        }
        else {
          *(int *)(iVar4 + 0x60) = param_1[0x21];
          iVar1 = *(int *)(param_1[0x21] + 0x5c);
          *(int *)(iVar4 + 0x5c) = iVar1;
          *(int *)(iVar1 + 0x60) = iVar4;
          *(int *)(param_1[0x21] + 0x5c) = iVar4;
        }
      }
      uVar12 = FUN_005fb520(*(undefined4 *)(*piVar11 + 0x4c));
      uVar10 = (uint)((ulonglong)uVar12 >> 0x20);
      uStack_20 = uVar12;
      if (*(char *)(param_1 + 0x29) == '\0') {
        uVar2 = param_1[0x27];
        if ((uVar2 != 0) && (uVar9 = uVar2 - 1 >> 1, uVar9 < uVar2)) {
          puVar7 = (uint *)(uVar9 * 0x10 + param_1[0x26]);
          do {
            if ((uVar10 < puVar7[1]) || ((uVar10 <= puVar7[1] && ((uint)uVar12 < *puVar7)))) {
              FUN_005fdef0(&uStack_20,piVar11,
                           "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                           ,0xc09);
              goto LAB_0060013c;
            }
            uVar9 = uVar9 + 1;
            puVar7 = puVar7 + 4;
          } while (uVar9 < uVar2);
        }
        iStack_2c = *piVar11;
        uStack_34 = uVar12;
        FUN_005fd1f0(&uStack_34,
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                     ,0xc09);
        *(undefined *)(param_1 + 0x29) = 1;
      }
      else {
        iStack_3c = *piVar11;
        uStack_44 = uVar12;
        FUN_005fd1f0(&uStack_44,
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                     ,0xc09);
      }
LAB_0060013c:
      uStack_14 = uStack_14 + 1;
      param_1[*(int *)(*piVar11 + 0x4c) + 0x60] = param_1[*(int *)(*piVar11 + 0x4c) + 0x60] + 1;
      iVar4 = *(int *)(*piVar11 + 0x4c);
      *(double *)(param_1 + iVar4 * 2 + 100) =
           (double)(*(int *)(*piVar11 + 0x18) + 7U >> 3) + DAT_018c0d90 +
           *(double *)(param_1 + iVar4 * 2 + 100);
      piVar11 = piVar11 + 1;
    } while ((int)uStack_14 < (int)param_2[5]);
  }
  FUN_005fe570(param_2);
  if (99999 < uVar5) {
    FUN_01674ea0(piStack_8);
  }
  return;
}



/* FUNCTION 6201 ; VA 0x006001c0 ; FUN_006001c0 */

uint FUN_006001c0(ushort *param_1,int *param_2)

{
  if ((uint)*param_1 < *(uint *)(*param_2 + 0x28)) {
    return 0xffffffff;
  }
  return (uint)((uint)*param_1 != *(uint *)(*param_2 + 0x28));
}



/* FUNCTION 6202 ; VA 0x006001f0 ; FUN_006001f0 */

bool __thiscall
FUN_006001f0(int *param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4,uint *param_5,
            uint *param_6,int param_7,int *param_8,int param_9,int *param_10)

{
  undefined auVar1 [16];
  byte bVar2;
  uint uVar3;
  code *pcVar4;
  undefined auVar5 [16];
  undefined auVar6 [16];
  undefined auVar7 [16];
  undefined auVar8 [16];
  undefined auVar9 [16];
  bool bVar10;
  unkbyte10 Var11;
  longlong lVar12;
  undefined8 uVar13;
  char cVar14;
  undefined uVar15;
  uint *puVar16;
  uint uVar17;
  undefined4 uVar18;
  undefined (*pauVar19) [16];
  undefined *puVar20;
  undefined (*pauVar21) [16];
  int *piVar22;
  undefined4 *puVar23;
  int iVar24;
  uint *puVar25;
  uint uVar26;
  undefined4 *puVar27;
  undefined (*pauVar28) [16];
  int iVar29;
  undefined8 uVar30;
  longlong lVar31;
  undefined4 uVar32;
  undefined2 uStack_be;
  undefined auStack_ac [4];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  uint *puStack_a0;
  uint *puStack_9c;
  uint uStack_98;
  uint uStack_94;
  uint uStack_90;
  undefined4 uStack_8c;
  uint *puStack_88;
  uint *puStack_84;
  undefined4 *puStack_80;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined8 uStack_70;
  undefined4 auStack_68 [2];
  undefined2 uStack_60;
  char cStack_5e;
  undefined4 uStack_5d;
  undefined4 *puStack_54;
  uint uStack_50;
  undefined4 *puStack_4c;
  int *piStack_48;
  undefined (*pauStack_44) [16];
  int *piStack_40;
  undefined (*pauStack_3c) [16];
  undefined (*pauStack_38) [16];
  undefined (*pauStack_34) [16];
  uint *puStack_30;
  undefined (*pauStack_2c) [16];
  undefined (*pauStack_28) [16];
  char cStack_22;
  byte bStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  lVar12 = CONCAT44(param_6,param_5);
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_0179cbb7;
  pvStack_1c = ExceptionList;
  pauStack_38 = (undefined (*) [16])0x0;
  ExceptionList = &pvStack_1c;
  piStack_48 = param_1;
  uVar30 = FUN_016f3c60(param_5,param_6,1000,0);
  puStack_84 = (uint *)((ulonglong)uVar30 >> 0x20);
  piStack_40 = (int *)uVar30;
  puVar16 = (uint *)param_1[0x1ce];
  puVar25 = (uint *)param_1[0x1cf];
  if ((param_6 <= puVar25) && ((param_6 < puVar25 || (param_5 <= puVar16)))) {
    param_1[0x1cf] = (int)param_6;
    param_1[0x1ce] = (int)param_5;
    ExceptionList = pvStack_1c;
    return true;
  }
  if (DAT_01d59d28 != '\0') {
    FUN_005ffaa0(piStack_40);
    uVar30 = CONCAT44(puStack_84,piStack_40);
    puVar16 = (uint *)param_1[0x1ce];
    puVar25 = (uint *)param_1[0x1cf];
  }
  pauStack_3c = (undefined (*) [16])((int)param_5 - (int)puVar16);
  param_1[0x1ce] = (int)param_5;
  param_1[0x1cf] = (int)param_6;
  if (((int)param_6 - (int)puVar25 != (uint)(param_5 < puVar16)) ||
     ((undefined (*) [16])0x186a0 < pauStack_3c)) {
    pauStack_3c = (undefined (*) [16])0x186a0;
  }
  puStack_30 = (uint *)0x0;
  uVar17 = param_1[8];
  if ((param_1[9] != 0) || (uVar17 != 0)) {
    pauVar19 = (undefined (*) [16])param_1[0x202];
    if ((param_1[0x203] == 0) && (pauVar19 <= pauStack_3c)) {
      uVar26 = param_1[0x21];
      if (uVar26 != 0) {
        pauStack_34 = *(undefined (**) [16])(uVar26 + 0x5c);
        puVar25 = (uint *)(*(uint *)(uVar26 + 0x28) + uVar17);
        puVar16 = (uint *)(*(int *)(uVar26 + 0x2c) + param_1[9] +
                          (uint)CARRY4(*(uint *)(uVar26 + 0x28),uVar17));
        if (puVar16 <= param_6) {
          uVar17 = uVar26;
          uVar13 = uVar30;
          if (puVar16 < param_6) goto LAB_00600330;
          while (uVar17 = uVar26, uVar30 = uVar13, puVar25 < param_5) {
LAB_00600330:
            do {
              puStack_84 = (uint *)((ulonglong)uVar13 >> 0x20);
              piStack_40 = (int *)uVar13;
              FUN_005fa670(uVar17,
                           "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                           ,0x702);
              uVar13 = CONCAT44(puStack_84,piStack_40);
              iVar24 = *(int *)(uVar17 + 0x1c);
              uVar26 = *(uint *)(uVar17 + 0x60);
              *(undefined4 *)(uVar17 + 0x3c) = 0;
              if (((iVar24 == 0) || (iVar24 == 1)) || (iVar24 == 5)) {
                *(uint *)(*(int *)(uVar17 + 0x5c) + 0x60) = uVar26;
                *(undefined4 *)(*(int *)(uVar17 + 0x60) + 0x5c) = *(undefined4 *)(uVar17 + 0x5c);
                uVar3 = *(uint *)(uVar17 + 0x60);
                if ((param_1[0x21] == uVar17) && (param_1[0x21] = uVar3, uVar3 == uVar17)) {
                  param_1[0x21] = 0;
                }
              }
              uVar30 = CONCAT44(puStack_84,piStack_40);
              if ((undefined (*) [16])uVar17 == pauStack_34) goto LAB_006003ae;
              puVar25 = (uint *)(*(uint *)(uVar26 + 0x28) + param_1[8]);
              puVar16 = (uint *)(*(int *)(uVar26 + 0x2c) + param_1[9] +
                                (uint)CARRY4(*(uint *)(uVar26 + 0x28),param_1[8]));
              uVar17 = uVar26;
            } while (puVar16 < param_6);
            uVar30 = uVar13;
            if (param_6 < puVar16) break;
          }
        }
      }
LAB_006003ae:
      uVar17 = (uint)param_1[8] >> 1 | param_1[9] << 0x1f;
      uVar26 = (uint)param_1[9] >> 1;
    }
    else {
      uVar17 = (int)pauVar19 - (int)pauStack_3c;
      uVar26 = param_1[0x203] - (uint)(pauVar19 < pauStack_3c);
    }
    param_1[0x203] = uVar26;
    param_1[0x202] = uVar17;
  }
  puStack_84 = (uint *)((ulonglong)uVar30 >> 0x20);
  piStack_40 = (int *)uVar30;
  if (param_1[0x6c] != 0) {
    piVar22 = (int *)param_1[0x25];
    puStack_84 = (uint *)-(uint)(piVar22 < piStack_40);
    if (((puStack_84 != (uint *)0x0) || (10000 < (uint)((int)piVar22 - (int)piStack_40))) &&
       ((piStack_40 < piVar22 || ((uint)param_1[0x38] < (uint)((int)piStack_40 - (int)piVar22))))) {
      if (DAT_01ee420a != '\0') {
        FUN_01677520(DAT_01ee420a,"AckTimeout: Last Packet received time: %d ms",
                     (int)piStack_40 - (int)piVar22);
      }
      *(undefined *)(param_1 + 0x37) = 1;
      ExceptionList = pvStack_1c;
      return true;
    }
  }
  cVar14 = (**(code **)(*(int *)param_1[0x1ec] + 0x18))(param_5,param_6,pauStack_3c,puStack_30);
  if (cVar14 != '\0') {
    FUN_005feff0(param_2,param_3,param_5,param_6,param_9,param_10);
  }
  if ((DAT_01d59d40 == '\0') || (*param_10 == 0)) {
    puStack_4c = (undefined4 *)0x0;
  }
  else {
    uVar17 = FUN_006a6780();
    puStack_4c = (undefined4 *)(uVar17 & 0xffff);
  }
  if (param_1[0x20b] != 0) {
    FUN_006a5be0();
    if ((DAT_01d59d40 != '\0') && (*param_10 != 0)) {
      FUN_006a67e0(param_9);
    }
    uVar15 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
    FUN_005ff8f0(param_9,uVar15);
    uVar32 = 1;
    uVar18 = FUN_005fb360(puStack_4c);
    FUN_005ff630(param_9,uVar18,uVar32);
    FUN_005ff420(param_2,param_3,param_9,param_5,param_6,param_10);
  }
  uVar15 = (**(code **)(*(int *)param_1[0x1ec] + 100))();
  uStack_5d = CONCAT31(CONCAT21(uStack_5d._2_2_,uVar15),*(undefined *)(param_1 + 0x1de));
  *(bool *)(param_1 + 0x1de) = param_1[0x27] != 0;
  if ((param_1[0x20] != 0) ||
     (pauStack_34 = (undefined (*) [16])((uint)pauStack_34 & 0xffffff00), param_1[0x27] != 0)) {
    pauStack_34 = (undefined (*) [16])CONCAT31(pauStack_34._1_3_,1);
  }
  (**(code **)(*(int *)param_1[0x1ec] + 0xc))(param_5,param_6,pauStack_34);
  param_1[0x5f] = 0;
  uStack_94 = param_7 + 7U >> 3;
  param_1[0x5e] = uStack_94;
  uVar30 = (**(code **)(*(int *)param_1[0x1ec] + 0x68))();
  puVar16 = (uint *)(param_1[0x24d] + (uint)(0xfffe795f < (uint)param_1[0x24c]));
  *(undefined8 *)(param_1 + 0x5a) = uVar30;
  if ((puVar16 <= param_6) &&
     ((puVar16 < param_6 || ((uint *)(param_1[0x24c] + 100000U) < param_5)))) {
    param_1 = param_1 + 0x219;
    pauStack_28 = (undefined (*) [16])0x7;
LAB_006005d1:
    do {
      iVar24 = *param_1;
      if (iVar24 == param_1[1]) {
LAB_00600617:
        bVar10 = false;
      }
      else {
        pauStack_38 = (undefined (*) [16])((uint)pauStack_38 | 1);
        auVar1 = *(undefined (*) [16])(iVar24 * 0x10 + param_1[-1]);
        uVar17 = auVar1._8_4_;
        puVar16 = (uint *)(auVar1._12_4_ + (uint)(0xfff0bdbf < uVar17));
        if ((param_6 < puVar16) || ((param_6 <= puVar16 && (param_5 <= (uint *)(uVar17 + 1000000))))
           ) goto LAB_00600617;
        bVar10 = true;
      }
      if (((uint)pauStack_38 & 1) != 0) {
        pauStack_38 = (undefined (*) [16])((uint)pauStack_38 & 0xfffffffe);
      }
      if (bVar10) {
        auVar1 = *(undefined (*) [16])(iVar24 * 0x10 + param_1[-1]);
        uVar26 = auVar1._0_4_;
        puVar16 = (uint *)(param_1 + -3);
        uVar17 = *puVar16;
        *puVar16 = *puVar16 - uVar26;
        param_1[-2] = (param_1[-2] - auVar1._4_4_) - (uint)(uVar17 < uVar26);
        *param_1 = *param_1 + 1;
        if (*param_1 == param_1[2]) {
          *param_1 = 0;
        }
        goto LAB_006005d1;
      }
      param_1 = param_1 + 8;
      pauStack_28 = (undefined (*) [16])((int)pauStack_28 + -1);
    } while (pauStack_28 != (undefined (*) [16])0x0);
    piStack_48[0x24c] = (int)param_5;
    piStack_48[0x24d] = (int)param_6;
    pauStack_28 = (undefined (*) [16])0x0;
    param_1 = piStack_48;
  }
  if (param_1[0x15] != 0) {
    pauStack_28 = (undefined (*) [16])0x0;
    pauStack_38 = (undefined (*) [16])0x0;
    do {
      puVar16 = *(uint **)((int)pauStack_38 + 0xcU + param_1[0x14]);
      if ((param_6 < puVar16) ||
         ((param_6 <= puVar16 && (param_5 <= *(uint **)((int)pauStack_38 + 8U + param_1[0x14]))))) {
        pauStack_28 = (undefined (*) [16])((int)pauStack_28 + 1);
        pauStack_38 = (undefined (*) [16])((int)pauStack_38 + 0x10);
      }
      else {
        pauVar19 = (undefined (*) [16])FUN_005f98f0();
        *(undefined4 *)pauVar19[4] = 0;
        pauStack_2c = pauVar19;
        puVar20 = (undefined *)FUN_01674f30(5);
        *(undefined **)((int)pauVar19[3] + 0xc) = puVar20;
        *(undefined4 *)((int)pauVar19[1] + 8) = 0x28;
        *puVar20 = 0xf;
        *(undefined4 *)(*(int *)((int)pauVar19[3] + 0xc) + 1) =
             *(undefined4 *)((int)pauStack_38 + 4U + param_1[0x14]);
        FUN_005fe020(&pauStack_2c,
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                     ,0x774);
        FUN_005fe650(pauStack_28);
      }
    } while (pauStack_28 < (uint *)param_1[0x15]);
  }
  if (DAT_01d5aed0 != '\0') {
    puVar16 = (uint *)param_1[0x24];
    while (((puVar16 != (uint *)0x0 && ((uint *)puVar16[0xd] <= param_6)) &&
           (((uint *)puVar16[0xd] < param_6 || ((uint *)puVar16[0xc] < param_5))))) {
      pauStack_2c = (undefined (*) [16])param_1[0x22];
      pauVar19 = pauStack_2c;
      if (*(char *)((int)**(undefined (**) [16])((int)*pauStack_2c + 4) + 0xd) == '\0') {
        pauVar21 = pauStack_2c;
        pauVar28 = *(undefined (**) [16])((int)*pauStack_2c + 4);
        do {
          pauVar19 = pauVar28;
          if (*(uint *)pauVar19[1] < *puVar16) {
            pauVar28 = *(undefined (**) [16])((int)*pauVar19 + 8);
            pauVar19 = pauVar21;
          }
          else {
            pauVar28 = *(undefined (**) [16])*pauVar19;
          }
          pauVar21 = pauVar19;
          param_1 = piStack_48;
        } while (*(char *)((int)*pauVar28 + 0xd) == '\0');
      }
      if ((pauVar19 == pauStack_2c) || (*puVar16 < *(uint *)pauVar19[1])) {
        pauVar19 = pauStack_2c;
      }
      uVar18 = FUN_00553830(pauVar19);
      FUN_01674ea0(uVar18,0x18);
      *(uint *)(puVar16[0x15] + 0x58) = puVar16[0x16];
      *(uint *)(puVar16[0x16] + 0x54) = puVar16[0x15];
      puVar25 = (uint *)puVar16[0x16];
      if (((uint *)param_1[0x24] == puVar16) && (param_1[0x24] = (int)puVar25, puVar25 == puVar16))
      {
        param_1[0x24] = 0;
      }
      FUN_005fe570(puVar16);
      puVar16 = (uint *)param_1[0x24];
    }
  }
  if ((char)pauStack_34 != '\x01') {
    iVar24 = param_1[0x27];
    goto LAB_00601c38;
  }
  uStack_60 = 0;
  cStack_5e = '\0';
  if (param_1[0x1f1] != 0) {
    if (0x200 < (uint)param_1[0x1f1]) {
      FUN_01674ea0(param_1[0x1ef]);
      param_1[0x1f1] = 0;
      param_1[0x1ef] = 0;
    }
    param_1[0x1f0] = 0;
  }
  if (param_1[500] != 0) {
    if (0x200 < (uint)param_1[500]) {
      FUN_01674ea0(param_1[0x1f2]);
      param_1[500] = 0;
      param_1[0x1f2] = 0;
    }
    param_1[499] = 0;
  }
  if (param_1[0x1f7] != 0) {
    if (0x200 < (uint)param_1[0x1f7]) {
      FUN_01674ea0(param_1[0x1f5]);
      param_1[0x1f7] = 0;
      param_1[0x1f5] = 0;
    }
    param_1[0x1f6] = 0;
  }
  if (param_1[0x1fa] != 0) {
    if (0x200 < (uint)param_1[0x1fa]) {
      FUN_01674ea0(param_1[0x1f8]);
      param_1[0x1fa] = 0;
      param_1[0x1f8] = 0;
    }
    param_1[0x1f9] = 0;
  }
  param_1[0x1fb] = 0;
  pauStack_38 = (undefined (*) [16])
                (**(code **)(*(int *)param_1[0x1ec] + 0x14))
                          (param_5,param_6,pauStack_3c,puStack_30,param_1[0x1ed],uStack_5d);
  if (DAT_01d59d10 == '\0') {
    pauStack_34 = (undefined (*) [16])(**(code **)(*(int *)param_1[0x1ec] + 0x10))();
  }
  else {
    param_1[0x1fc] = 0;
    pauStack_34 = pauStack_38;
    if ((DAT_01d59d28 != '\0') && (DAT_01d59d38 == '\0')) {
      if (DAT_01d59d30 == '\0') {
        param_1[0x92] = (int)((int)*pauStack_38 + param_1[0x92]);
      }
      else {
        pauVar19 = (undefined (*) [16])0x0;
        if (-1 < (int)pauStack_38) {
          pauVar19 = pauStack_38;
        }
        param_1[0x92] = (int)((int)*pauVar19 + param_1[0x92]);
      }
    }
  }
  if (((int)pauStack_34 < 1) && ((int)pauStack_38 < 1)) {
    *(undefined *)(param_1 + 0x58) = 1;
LAB_00600e52:
    if (((DAT_01d59d10 != '\0') && (DAT_01d59d28 != '\0')) && (DAT_01d59d38 != '\0')) {
      pauVar19 = pauStack_38;
      if ((int)pauStack_38 < 0) {
        pauVar19 = (undefined (*) [16])0x0;
      }
      param_1[0x92] = (int)((int)*pauVar19 + param_1[0x92]);
    }
  }
  else {
    *(undefined *)(param_1 + 0x58) = 0;
    param_1[0x1fc] = 0;
    if (0 < (int)pauStack_34) {
      while( true ) {
        puVar16 = (uint *)param_1[0x20];
        bStack_21 = 0;
        puStack_30 = puVar16;
        if (puVar16 == (uint *)0x0) break;
        do {
          puStack_30 = puVar16;
          if ((param_6 < (uint *)puVar16[0xd]) ||
             ((param_6 <= (uint *)puVar16[0xd] && (param_5 <= (uint *)puVar16[0xc])))) {
            iVar24 = param_1[0x1fb];
joined_r0x00600dbc:
            if (iVar24 != 0) {
              pauStack_2c = (undefined (*) [16])param_1[0x1f0];
              FUN_005fdf80(&pauStack_2c,
                           "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                           ,0xe36);
              pauStack_2c = (undefined (*) [16])(param_1[0x1fb] + 7U >> 3);
              FUN_005fdf80(&pauStack_2c,
                           "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                           ,0xe39);
              param_1[0x1fb] = 0;
            }
            if (bStack_21 == 0) goto LAB_00600e2d;
            break;
          }
          pauStack_2c = (undefined (*) [16])(puVar16[0xe] + puVar16[6]);
          cStack_22 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
          iVar24 = (**(code **)(*(int *)param_1[0x1ec] + 0x5c))();
          pauStack_3c = (undefined (*) [16])
                        (iVar24 + (((uint)(cStack_22 == '\0') * 4 + -0xd) - (int)puStack_4c));
          pauVar19 = pauStack_3c;
          if ((*param_1 != 0) && (cVar14 = FUN_00686be0(), pauVar19 = pauStack_3c, cVar14 != '\0'))
          {
            pauVar19 = (undefined (*) [16])((int)pauStack_3c[-2] + 0xe);
          }
          iVar24 = param_1[0x1fb];
          if ((undefined *)((int)pauVar19 * 8) < (undefined *)((int)*pauStack_2c + iVar24))
          goto joined_r0x00600dbc;
          iVar24 = param_1[0x20];
          *(undefined4 *)(*(int *)(iVar24 + 0x54) + 0x58) = *(undefined4 *)(iVar24 + 0x58);
          *(undefined4 *)(*(int *)(iVar24 + 0x58) + 0x54) = *(undefined4 *)(iVar24 + 0x54);
          iVar29 = *(int *)(iVar24 + 0x58);
          if ((param_1[0x20] == iVar24) && (param_1[0x20] = iVar29, iVar29 == iVar24)) {
            param_1[0x20] = 0;
          }
          pauStack_28 = (undefined (*) [16])(param_1 + 0x22b);
          uStack_8c = 0;
          uStack_90 = puVar16[6] + 7 >> 3;
          puStack_88 = param_5;
          puStack_84 = param_6;
          if (*(uint *)pauStack_28 == 0) {
            pauStack_44 = (undefined (*) [16])&DAT_00000010;
            puStack_54 = (undefined4 *)FUN_01674e20(0x104);
            uStack_14 = 0;
            if (puStack_54 == (undefined4 *)0x0) {
              pauVar19 = (undefined (*) [16])0x0;
            }
            else {
              *puStack_54 = 0x10;
              pauStack_2c = (undefined (*) [16])(puStack_54 + 1);
              FUN_016f4053();
              pauVar19 = pauStack_2c;
            }
            auVar6._4_4_ = uStack_8c;
            auVar6._0_4_ = uStack_90;
            auVar6._8_4_ = puStack_88;
            auVar6._12_4_ = puStack_84;
            param_1[0x228] = (int)pauVar19;
            param_1[0x229] = 0;
            param_1[0x22a] = 1;
            *pauVar19 = auVar6;
            uStack_14 = 0xffffffff;
            *(uint *)pauStack_28 = 0x10;
          }
          else {
            auVar1._4_4_ = 0;
            auVar1._0_4_ = uStack_90;
            auVar1._8_4_ = param_5;
            auVar1._12_4_ = param_6;
            *(undefined (*) [16])(param_1[0x22a] * 0x10 + param_1[0x228]) = auVar1;
            uVar17 = param_1[0x22a] + 1;
            param_1[0x22a] = uVar17;
            if (uVar17 == *(uint *)pauStack_28) {
              param_1[0x22a] = 0;
              uVar17 = 0;
            }
            if ((uVar17 == param_1[0x229]) &&
               (pauStack_2c = (undefined (*) [16])
                              FUN_005f7e40(*(uint *)pauStack_28 * 2,
                                           "c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\ReliabilityLayer.h"
                                           ,0x67), pauStack_2c != (undefined (*) [16])0x0)) {
              uVar17 = 0;
              pauVar19 = pauStack_2c;
              if (*(uint *)pauStack_28 != 0) {
                do {
                  pauStack_3c = pauVar19;
                  uVar26 = param_1[0x229] + uVar17;
                  uVar17 = uVar17 + 1;
                  *pauStack_3c = *(undefined (*) [16])
                                  ((uVar26 % *(uint *)pauStack_28) * 0x10 + param_1[0x228]);
                  pauStack_3c = pauStack_3c + 1;
                  puVar16 = puStack_30;
                  pauVar19 = pauStack_3c;
                } while (uVar17 < *(uint *)pauStack_28);
              }
              param_1[0x229] = 0;
              uVar17 = *(uint *)pauStack_28;
              param_1[0x22a] = uVar17;
              *(uint *)pauStack_28 = uVar17 * 2;
              if (param_1[0x228] != 0) {
                piVar22 = (int *)(param_1[0x228] + -4);
                uStack_14 = 1;
                FUN_016f32d1();
                FUN_01674ea0(piVar22,*piVar22 * 0x10 + 4);
                uStack_14 = 0xffffffff;
                puVar16 = puStack_30;
              }
              param_1[0x228] = (int)pauStack_2c;
            }
          }
          puVar25 = (uint *)(param_1 + 0x224);
          uVar17 = *puVar25;
          *puVar25 = *puVar25 + uStack_90;
          param_1[0x225] = param_1[0x225] + (uint)CARRY4(uVar17,uStack_90);
          puVar25 = (uint *)(param_1 + 0x226);
          uVar17 = *puVar25;
          *puVar25 = *puVar25 + uStack_90;
          param_1[0x227] = param_1[0x227] + (uint)CARRY4(uVar17,uStack_90);
          FUN_005fe300();
          *(char *)(puVar16 + 0x12) = *(char *)(puVar16 + 0x12) + '\x01';
          lVar31 = (**(code **)(*(int *)param_1[0x1ec] + 0x54))();
          *(longlong *)(puVar16 + 0xc) = lVar31 + lVar12;
          (**(code **)(*(int *)param_1[0x1ec] + 0x30))(param_5,param_6);
          bStack_21 = 1;
          if (DAT_01d5b280 == '\0') {
            pauStack_3c = (undefined (*) [16])0x0;
            if (param_8[1] != 0) {
              do {
                pcVar4 = *(code **)(**(int **)(*param_8 + (int)pauStack_3c * 4) + 0x48);
                uStack_a8 = *param_3;
                uStack_a4 = param_3[1];
                puStack_a0 = (uint *)param_3[2];
                puStack_9c = (uint *)param_3[3];
                puStack_80 = (undefined4 *)param_3[4];
                uStack_7c = param_3[5];
                puStack_78 = (uint *)param_3[6];
                puStack_74 = (uint *)param_3[7];
                piVar22 = (int *)(**(code **)(*(int *)piStack_48[0x1ec] + 0x20))(&uStack_50);
                auVar7._4_4_ = uStack_7c;
                auVar7._0_4_ = puStack_80;
                auVar7._8_4_ = puStack_78;
                auVar7._12_4_ = puStack_74;
                (*pcVar4)(puStack_30,piStack_48[0x1f6] + *piVar22,uStack_a8,uStack_a4,puStack_a0,
                          puStack_9c,auVar7,piStack_40,1);
                pauStack_3c = (undefined (*) [16])((int)*pauStack_3c + 1);
                puVar16 = puStack_30;
                param_1 = piStack_48;
              } while (pauStack_3c < (undefined (*) [16])param_8[1]);
            }
          }
          else if (puVar16[5] == 0) {
            param_1[0x90] = param_1[0x90] + 1;
          }
          else {
            param_1[0x91] = param_1[0x91] + 1;
          }
          if (param_1[0x20] == 0) {
            puVar16[0x16] = (uint)puVar16;
            puVar16[0x15] = (uint)puVar16;
            param_1[0x20] = (int)puVar16;
          }
          else {
            puVar16[0x16] = param_1[0x20];
            uVar17 = *(uint *)(param_1[0x20] + 0x54);
            puVar16[0x15] = uVar17;
            *(uint **)(uVar17 + 0x58) = puVar16;
            *(uint **)(param_1[0x20] + 0x54) = puVar16;
          }
          puVar16 = (uint *)param_1[0x20];
          puStack_30 = puVar16;
        } while (puVar16 != (uint *)0x0);
        if ((int)pauStack_34 <= (int)(param_1[0x1fc] + 7U >> 3)) break;
      }
    }
LAB_00600e2d:
    if (DAT_01d59d10 != '\0') {
      iVar24 = param_1[0x1fc];
      param_1[0x1fc] = 0;
      pauStack_38 = (undefined (*) [16])((int)pauStack_38 - (iVar24 + 7U >> 3));
      goto LAB_00600e52;
    }
  }
  if ((int)(param_1[0x1fc] + 7U >> 3) < (int)pauStack_38) {
    param_1[0x1fc] = 0;
LAB_00600ea0:
    uVar17 = param_1[0x1e] - param_1[0x1d] >> 2;
    if ((uVar17 & uVar17 - 1) == 0) {
      uVar17 = uVar17 - 1 & param_1[0x35];
    }
    else {
      uVar17 = (uint)param_1[0x35] % uVar17;
    }
    if ((*(int *)(param_1[0x1d] + uVar17 * 4) == 0) &&
       ((int)(param_1[0x1fc] + 7U >> 3) < (int)pauStack_38)) {
      if ((param_7 == 0) || ((param_1[0x21f] == 0 && ((uint)param_1[0x21e] <= uStack_94)))) {
        uVar15 = 0;
      }
      else {
        uVar15 = 1;
      }
      iVar24 = param_1[0x27];
      *(undefined *)(param_1 + 0x5c) = uVar15;
      do {
        if ((iVar24 == 0) || (*(char *)(param_1 + 0x5c) != '\0')) goto LAB_006015e0;
        puVar16 = *(uint **)(param_1[0x26] + 8);
        puStack_30 = puVar16;
        if (puVar16[0xf] == 0) {
          FUN_005fdbb0(0);
          param_1[puVar16[0x13] + 0x60] = param_1[puVar16[0x13] + 0x60] + -1;
          *(double *)(param_1 + puVar16[0x13] * 2 + 100) =
               *(double *)(param_1 + puVar16[0x13] * 2 + 100) -
               ((double)(puVar16[6] + 7 >> 3) + DAT_018c0d90);
          FUN_005fe570(puVar16);
        }
        else {
          uVar17 = puVar16[7];
          uVar26 = 0x18;
          if ((((uVar17 == 2) || (uVar17 == 4)) || (uVar17 == 3)) ||
             ((uVar17 == 6 || (uVar17 == 7)))) {
            uVar26 = 0x30;
          }
          if ((uVar17 == 1) || (uVar17 == 4)) {
            uVar26 = uVar26 + 0x18;
          }
          if ((((uVar17 == 1) || (uVar17 == 4)) || (uVar17 == 3)) || (uVar17 == 7)) {
            uVar26 = uVar26 + 0x20;
          }
          uVar17 = uVar26 + 0x50;
          if ((int)puVar16[5] < 1) {
            uVar17 = uVar26;
          }
          pauStack_2c = (undefined (*) [16])(puVar16[6] + uVar17);
          puVar16[0xe] = uVar17;
          cStack_22 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
          iVar24 = (**(code **)(*(int *)param_1[0x1ec] + 0x5c))();
          pauStack_34 = (undefined (*) [16])
                        (iVar24 + (((uint)(cStack_22 == '\0') * 4 + -0xd) - (int)puStack_4c));
          pauVar19 = pauStack_34;
          if ((*param_1 != 0) && (cVar14 = FUN_00686be0(), pauVar19 = pauStack_34, cVar14 != '\0'))
          {
            pauVar19 = (undefined (*) [16])((int)pauStack_34[-2] + 0xe);
          }
          if ((undefined *)((int)pauVar19 * 8) < (undefined *)((int)*pauStack_2c + param_1[0x1fb]))
          goto LAB_006015e0;
          uVar17 = puVar16[7];
          if (((uVar17 == 2) || (uVar17 == 4)) ||
             ((uVar17 == 3 ||
              ((uVar17 == 6 ||
               (pauStack_3c = (undefined (*) [16])((uint)pauStack_3c & 0xffffff00), uVar17 == 7)))))
             ) {
            pauStack_3c = (undefined (*) [16])CONCAT31(pauStack_3c._1_3_,1);
          }
          FUN_005fdbb0(0);
          param_1[puVar16[0x13] + 0x60] = param_1[puVar16[0x13] + 0x60] + -1;
          *(double *)(param_1 + puVar16[0x13] * 2 + 100) =
               *(double *)(param_1 + puVar16[0x13] * 2 + 100) -
               ((double)(puVar16[6] + 7 >> 3) + DAT_018c0d90);
          if ((char)pauStack_3c == '\0') {
            if (puVar16[7] == 5) {
              lVar31 = (**(code **)(*(int *)param_1[0x1ec] + 0x54))();
              puStack_54 = (undefined4 *)(lVar31 + lVar12);
              pauStack_44 = (undefined (*) [16])((ulonglong)(lVar31 + lVar12) >> 0x20);
              uStack_50 = puVar16[0x14];
              piVar22 = (int *)(**(code **)(*(int *)param_1[0x1ec] + 0x20))(auStack_ac);
              iVar29 = param_1[0x15];
              iVar24 = param_1[0x16];
              pauStack_34 = (undefined (*) [16])(*piVar22 + param_1[0x1f6] & 0xffffff);
              if (iVar29 == iVar24) {
                if (iVar24 == 0) {
                  param_1[0x16] = 0x10;
                  uVar17 = 0x10;
LAB_00601223:
                  uStack_98 = uVar17;
                  pauStack_28 = (undefined (*) [16])
                                FUN_01674e20(-(uint)((int)((ulonglong)uVar17 * 0x10 >> 0x20) != 0) |
                                             (uint)((ulonglong)uVar17 * 0x10));
                  uStack_14 = 2;
                  pauVar19 = pauStack_28;
                  if (pauStack_28 == (undefined (*) [16])0x0) {
                    pauStack_28 = (undefined (*) [16])0x0;
                  }
                  else {
                    for (; pauStack_2c = pauVar19, uVar17 != 0; uVar17 = uVar17 - 1) {
                      FUN_0054eb90();
                      pauVar19 = pauStack_2c;
                      param_1 = piStack_48;
                    }
                  }
                  iVar29 = param_1[0x15];
                  uStack_14 = 0xffffffff;
                }
                else {
                  uVar17 = iVar24 * 2;
                  param_1[0x16] = uVar17;
                  if (uVar17 != 0) goto LAB_00601223;
                  pauStack_28 = (undefined (*) [16])0x0;
                }
                iVar24 = param_1[0x14];
                if (iVar24 != 0) {
                  uVar17 = 0;
                  if (iVar29 != 0) {
                    puVar23 = (undefined4 *)((int)*pauStack_28 + 8);
                    pauStack_2c = (undefined (*) [16])(-8 - (int)pauStack_28);
                    do {
                      uVar17 = uVar17 + 1;
                      puVar27 = (undefined4 *)
                                ((int)puVar23 + (int)(param_1[0x14] + (int)*pauStack_2c));
                      puVar23[-2] = *puVar27;
                      puVar23[-1] = puVar27[1];
                      *puVar23 = puVar27[2];
                      puVar23[1] = puVar27[3];
                      puVar23 = puVar23 + 4;
                    } while (uVar17 < (uint)param_1[0x15]);
                    iVar24 = param_1[0x14];
                  }
                  FUN_01674ea0(iVar24);
                }
                param_1[0x14] = (int)pauStack_28;
              }
              else {
                pauStack_28 = (undefined (*) [16])param_1[0x14];
              }
              pauStack_28 = pauStack_28 + param_1[0x15];
              *(undefined (**) [16])*pauStack_28 = pauStack_34;
              *(uint *)((int)*pauStack_28 + 4) = uStack_50;
              *(undefined4 **)((int)*pauStack_28 + 8) = puStack_54;
              *(undefined (**) [16])((int)*pauStack_28 + 0xc) = pauStack_44;
              param_1[0x15] = param_1[0x15] + 1;
              puVar16 = puStack_30;
            }
          }
          else {
            *(undefined *)(puVar16 + 9) = 1;
            *puVar16 = param_1[0x35];
            lVar31 = (**(code **)(*(int *)param_1[0x1ec] + 0x54))();
            *(longlong *)(puVar16 + 0xc) = lVar31 + lVar12;
            uVar17 = param_1[0x1e] - param_1[0x1d] >> 2;
            if ((uVar17 & uVar17 - 1) == 0) {
              uVar17 = uVar17 - 1 & *puVar16;
            }
            else {
              uVar17 = *puVar16 % uVar17;
            }
            *(uint **)(param_1[0x1d] + uVar17 * 4) = puVar16;
            if (*(char *)((int)puVar16 + 0x4a) != '\0') {
              param_1[0x78] = param_1[0x78] + 1;
            }
            param_1[0x6c] = param_1[0x6c] + 1;
            uVar26 = puVar16[6] + 7 >> 3;
            puVar25 = (uint *)(param_1 + 0x6e);
            uVar17 = *puVar25;
            *puVar25 = *puVar25 + uVar26;
            param_1[0x6f] = param_1[0x6f] + (uint)CARRY4(uVar17,uVar26);
            param_1[0x1ed] = param_1[0x1ed] + (puVar16[0xe] + 7 + puVar16[6] >> 3);
            if ((uint)param_1[0x1ee] < 0xffffff) {
              param_1[0x1ee] = param_1[0x1ee] + 1;
            }
            if (param_1[0x20] == 0) {
              puVar16[0x16] = (uint)puVar16;
              puVar16[0x15] = (uint)puVar16;
              param_1[0x20] = (int)puVar16;
              param_1[0x35] = param_1[0x35] + 1;
              *(undefined *)((int)param_1 + 0xd7) = 0;
            }
            else {
              puVar16[0x16] = param_1[0x20];
              uVar17 = *(uint *)(param_1[0x20] + 0x54);
              puVar16[0x15] = uVar17;
              *(uint **)(uVar17 + 0x58) = puVar16;
              *(uint **)(param_1[0x20] + 0x54) = puVar16;
              param_1[0x35] = param_1[0x35] + 1;
              *(undefined *)((int)param_1 + 0xd7) = 0;
            }
          }
          pauStack_28 = (undefined (*) [16])(param_1 + 0x223);
          uStack_7c = 0;
          puStack_80 = (undefined4 *)(puVar16[6] + 7 >> 3);
          puStack_78 = param_5;
          puStack_74 = param_6;
          if (*(uint *)pauStack_28 == 0) {
            uStack_98 = 0x10;
            puVar23 = (undefined4 *)FUN_01674e20(0x104);
            uStack_14 = 3;
            if (puVar23 == (undefined4 *)0x0) {
              pauVar19 = (undefined (*) [16])0x0;
            }
            else {
              *puVar23 = 0x10;
              pauStack_44 = (undefined (*) [16])(puVar23 + 1);
              FUN_016f4053();
              pauVar19 = pauStack_44;
            }
            auVar8._4_4_ = uStack_7c;
            auVar8._0_4_ = puStack_80;
            auVar8._8_4_ = puStack_78;
            auVar8._12_4_ = puStack_74;
            param_1[0x220] = (int)pauVar19;
            param_1[0x221] = 0;
            param_1[0x222] = 1;
            *pauVar19 = auVar8;
            uStack_14 = 0xffffffff;
            *(uint *)pauStack_28 = 0x10;
          }
          else {
            auVar9._4_4_ = 0;
            auVar9._0_4_ = puStack_80;
            auVar9._8_4_ = param_5;
            auVar9._12_4_ = param_6;
            *(undefined (*) [16])(param_1[0x222] * 0x10 + param_1[0x220]) = auVar9;
            uVar17 = param_1[0x222] + 1;
            param_1[0x222] = uVar17;
            if (uVar17 == *(uint *)pauStack_28) {
              param_1[0x222] = 0;
              uVar17 = 0;
            }
            if ((uVar17 == param_1[0x221]) &&
               (pauStack_44 = (undefined (*) [16])
                              FUN_005f7e40(*(uint *)pauStack_28 * 2,
                                           "c:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\client\\network\\raknet\\source\\ReliabilityLayer.h"
                                           ,0x67), pauStack_44 != (undefined (*) [16])0x0)) {
              uVar17 = 0;
              pauVar19 = pauStack_44;
              if (*(uint *)pauStack_28 != 0) {
                do {
                  pauStack_34 = pauVar19;
                  uVar26 = param_1[0x221] + uVar17;
                  uVar17 = uVar17 + 1;
                  *pauStack_34 = *(undefined (*) [16])
                                  ((uVar26 % *(uint *)pauStack_28) * 0x10 + param_1[0x220]);
                  pauStack_34 = pauStack_34 + 1;
                  puVar16 = puStack_30;
                  pauVar19 = pauStack_34;
                } while (uVar17 < *(uint *)pauStack_28);
              }
              param_1[0x221] = 0;
              uVar17 = *(uint *)pauStack_28;
              param_1[0x222] = uVar17;
              *(uint *)pauStack_28 = uVar17 * 2;
              if (param_1[0x220] != 0) {
                piVar22 = (int *)(param_1[0x220] + -4);
                uStack_14 = 4;
                FUN_016f32d1();
                FUN_01674ea0(piVar22,*piVar22 * 0x10 + 4);
                uStack_14 = 0xffffffff;
                puVar16 = puStack_30;
              }
              param_1[0x220] = (int)pauStack_44;
            }
          }
          puVar25 = (uint *)(param_1 + 0x21c);
          uVar17 = *puVar25;
          *puVar25 = *puVar25 + (int)puStack_80;
          param_1[0x21d] = param_1[0x21d] + (uint)CARRY4(uVar17,(uint)puStack_80);
          puVar25 = (uint *)(param_1 + 0x21e);
          uVar17 = *puVar25;
          *puVar25 = *puVar25 + (int)puStack_80;
          param_1[0x21f] = param_1[0x21f] + (uint)CARRY4(uVar17,(uint)puStack_80);
          FUN_005fe300();
          *(char *)(puVar16 + 0x12) = *(char *)(puVar16 + 0x12) + '\x01';
          if (DAT_01d5b280 == '\0') {
            pauStack_34 = (undefined (*) [16])0x0;
            if (param_8[1] != 0) {
              do {
                pcVar4 = *(code **)(**(int **)(*param_8 + (int)pauStack_34 * 4) + 0x48);
                uStack_a8 = *param_3;
                uStack_a4 = param_3[1];
                puStack_a0 = (uint *)param_3[2];
                puStack_9c = (uint *)param_3[3];
                Var11 = *(unkbyte10 *)(param_3 + 4);
                uVar18 = param_3[7];
                uStack_be = (undefined2)((uint)param_3[6] >> 0x10);
                piVar22 = (int *)(**(code **)(*(int *)piStack_48[0x1ec] + 0x20))(&puStack_84);
                auVar5._10_2_ = uStack_be;
                auVar5._0_10_ = Var11;
                auVar5._12_4_ = uVar18;
                (*pcVar4)(puStack_30,*piVar22 + piStack_48[0x1f6],uStack_a8,uStack_a4,puStack_a0,
                          puStack_9c,auVar5,piStack_40,1);
                pauStack_34 = (undefined (*) [16])((int)*pauStack_34 + 1);
                param_1 = piStack_48;
              } while (pauStack_34 < (undefined (*) [16])param_8[1]);
            }
          }
          else if (puVar16[5] == 0) {
            param_1[0x90] = param_1[0x90] + 1;
          }
          else {
            param_1[0x91] = param_1[0x91] + 1;
          }
          uVar17 = param_1[0x1e] - param_1[0x1d] >> 2;
          if ((uVar17 - 1 & uVar17) == 0) {
            uVar17 = param_1[0x35] & uVar17 - 1;
          }
          else {
            uVar17 = (uint)param_1[0x35] % uVar17;
          }
          if (*(int *)(param_1[0x1d] + uVar17 * 4) != 0) goto LAB_006015e0;
        }
        iVar24 = param_1[0x27];
      } while( true );
    }
  }
LAB_00601643:
  pauStack_34 = (undefined (*) [16])0x0;
  if (param_1[0x1f6] != 0) {
    do {
      pauVar19 = pauStack_34;
      puStack_4c = (undefined4 *)0x0;
      uVar15 = (char)uStack_5d;
      if (pauStack_34 != (undefined (*) [16])0x0) {
        uVar15 = 1;
      }
      uStack_5d = CONCAT31(uStack_5d._1_3_,uVar15);
      puVar23 = (undefined4 *)(**(code **)(*(int *)param_1[0x1ec] + 0x1c))(&puStack_84);
      auStack_68[0] = *puVar23;
      puVar23 = (undefined4 *)param_1[0x1f5];
      if (pauVar19 == (undefined (*) [16])0x0) {
        pauStack_3c = (undefined (*) [16])*puVar23;
        pauStack_38 = (undefined (*) [16])0x0;
      }
      else {
        pauStack_38 = (undefined (*) [16])puVar23[(int)pauVar19 - 1];
        pauStack_3c = (undefined (*) [16])puVar23[(int)pauStack_34];
      }
      uVar30 = FUN_006a6920();
      puStack_30 = (uint *)((ulonglong)uVar30 >> 0x20);
      pauStack_28 = (undefined (*) [16])uVar30;
      bStack_21 = 0;
      cVar14 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
      uVar30 = uStack_70;
      if (cVar14 != '\0') {
        uVar30 = FUN_006a6920();
      }
      uStack_70 = uVar30;
      FUN_006a5be0();
      if ((DAT_01d59d40 != '\0') && (*param_10 != 0)) {
        FUN_006a67e0(param_9);
      }
      cStack_22 = (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
      FUN_006a5d50();
      if ((char)uStack_60 == '\0') {
        if (uStack_60._1_1_ == '\0') {
          FUN_006a5d20();
          FUN_006a5d20();
          FUN_006a5d20();
          if ((char)uStack_5d == '\0') {
            FUN_006a5d20();
          }
          else {
            FUN_006a5d50();
          }
          if (uStack_5d._1_1_ == '\0') {
            FUN_006a5d20();
          }
          else {
            FUN_006a5d50();
          }
          *(uint *)(param_9 + 8) = (*(int *)(param_9 + 8) - (*(int *)(param_9 + 8) - 1U & 7)) + 7;
          if (cStack_22 != '\0') {
            piStack_40 = (int *)uStack_70;
            cVar14 = FUN_005fda50();
            if (cVar14 == '\0') {
              FUN_006a5c10();
            }
            FUN_006a6060();
          }
          FUN_005f8120(auStack_68);
        }
        else {
          FUN_006a5d20();
          FUN_006a5d50();
        }
      }
      else {
        FUN_006a5d50();
        if (cStack_5e == '\0') {
          FUN_006a5d20();
        }
        else {
          FUN_006a5d50();
        }
        if (uStack_5d._3_1_ == '\0') {
          FUN_006a5d20();
        }
        else {
          FUN_006a5d50();
        }
        *(uint *)(param_9 + 8) = (*(int *)(param_9 + 8) - (*(int *)(param_9 + 8) - 1U & 7)) + 7;
        if (cStack_22 != '\0') {
          piStack_40 = (int *)uStack_70;
          cVar14 = FUN_005fda50();
          if (cVar14 == '\0') {
            FUN_006a5c10();
          }
          FUN_006a6060();
        }
        if (cStack_5e != '\0') {
          cVar14 = FUN_005fda50();
          if (cVar14 == '\0') {
            FUN_006a5c10();
            FUN_006a6060();
          }
          else {
            FUN_006a6060();
          }
        }
      }
      if (pauStack_38 < pauStack_3c) {
        do {
          puVar23 = *(undefined4 **)(param_1[0x1ef] + (int)pauStack_38 * 4);
          iVar24 = puVar23[7];
          if ((iVar24 != 0) && (iVar24 != 1)) {
            uVar18 = *puVar23;
            if (puStack_4c == (undefined4 *)0x0) {
              piStack_40 = param_1 + 10;
              if (DAT_01d59d18 == '\0') {
                uVar17 = param_1[0xb];
                if ((uint)param_1[0xc] < uVar17) {
                  iVar24 = param_1[0xd] - uVar17;
                }
                else {
                  iVar24 = -uVar17;
                }
                if (DAT_01d59cb4 < param_1[0xc] + iVar24) {
                  FUN_005fe6b0(param_1[0x17]);
                  param_1[0xb] = param_1[0xb] + 1;
                  if (param_1[0xb] == param_1[0xd]) {
                    param_1[0xb] = 0;
                  }
LAB_00601972:
                  param_1[0x17] = param_1[0x17] + 1;
                  *(undefined *)((int)param_1 + 0x5f) = 0;
                }
              }
              else {
                uVar17 = param_1[0xb];
                if ((uint)param_1[0xc] < uVar17) {
                  iVar24 = param_1[0xd] - uVar17;
                }
                else {
                  iVar24 = -uVar17;
                }
                if (DAT_01d59cb4 <= param_1[0xc] + iVar24) {
                  if ((uint)param_1[0xd] <= uVar17) {
                    uVar17 = uVar17 - param_1[0xd];
                  }
                  if ((*(int *)(uVar17 * 0x10 + *piStack_40) == 0) ||
                     (DAT_01d59cb4 <= param_1[0x13])) {
                    FUN_005fe6b0(param_1[0x17]);
                    param_1[0xb] = param_1[0xb] + 1;
                    if (param_1[0xb] == param_1[0xd]) {
                      param_1[0xb] = 0;
                    }
                    goto LAB_00601972;
                  }
                }
              }
              puStack_80 = (undefined4 *)
                           FUN_005f97b0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                                        ,0xfc3);
              puStack_80[1] = 0;
              *puStack_80 = uVar18;
              puStack_78 = (uint *)pauStack_28;
              puStack_74 = puStack_30;
              puStack_4c = puStack_80;
              FUN_005fe0f0();
            }
            else {
              puVar23 = (undefined4 *)
                        FUN_005f97b0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
                                     ,0xfdd);
              puStack_4c[1] = puVar23;
              *puVar23 = uVar18;
              *(undefined4 *)(puStack_4c[1] + 4) = 0;
              puStack_4c = (undefined4 *)puStack_4c[1];
            }
          }
          pauVar19 = pauStack_38;
          iVar24 = *(int *)(param_1[0x1ef] + (int)pauStack_38 * 4);
          if (*(char *)(iVar24 + 0x4a) != '\0') {
            bVar2 = *(byte *)(iVar24 + 0x48);
            if (bStack_21 < bVar2) {
              bStack_21 = bVar2;
            }
            uVar17 = (*(int *)(iVar24 + 0x38) + 7U >> 3) + (*(int *)(iVar24 + 0x18) + 7U >> 3);
            if (bVar2 == 1) {
              puVar16 = (uint *)(param_1 + 0x7e);
              uVar26 = *puVar16;
              *puVar16 = *puVar16 + uVar17;
              param_1[0x7f] = param_1[0x7f] + (uint)CARRY4(uVar26,uVar17);
            }
            else {
              puVar16 = (uint *)(param_1 + 0x80);
              uVar26 = *puVar16;
              *puVar16 = *puVar16 + uVar17;
              param_1[0x81] = param_1[0x81] + (uint)CARRY4(uVar26,uVar17);
            }
          }
          FUN_00601c60();
          pauStack_38 = (undefined (*) [16])((int)*pauVar19 + 1);
        } while (pauStack_38 < pauStack_3c);
        if (puStack_4c == (undefined4 *)0x0) goto LAB_00601a75;
      }
      else {
LAB_00601a75:
        if (DAT_01d59d18 == '\0') {
          uVar17 = param_1[0xb];
          if ((uint)param_1[0xc] < uVar17) {
            iVar24 = param_1[0xd] - uVar17;
          }
          else {
            iVar24 = -uVar17;
          }
          if (DAT_01d59cb4 < param_1[0xc] + iVar24) {
            FUN_005fe6b0(param_1[0x17]);
            param_1[0xb] = param_1[0xb] + 1;
            if (param_1[0xb] == param_1[0xd]) {
              param_1[0xb] = 0;
            }
            param_1[0x17] = param_1[0x17] + 1;
            *(undefined *)((int)param_1 + 0x5f) = 0;
          }
        }
        else {
          uVar17 = param_1[0xb];
          if ((uint)param_1[0xc] < uVar17) {
            iVar24 = param_1[0xd] - uVar17;
          }
          else {
            iVar24 = -uVar17;
          }
          if (DAT_01d59cb4 <= param_1[0xc] + iVar24) {
            if ((uint)param_1[0xd] <= uVar17) {
              uVar17 = uVar17 - param_1[0xd];
            }
            if ((*(int *)(uVar17 * 0x10 + param_1[10]) == 0) || (DAT_01d59cb4 <= param_1[0x13])) {
              FUN_005fe6b0(param_1[0x17]);
              param_1[0xb] = param_1[0xb] + 1;
              if (param_1[0xb] == param_1[0xd]) {
                param_1[0xb] = 0;
              }
              param_1[0x17] = param_1[0x17] + 1;
              *(undefined *)((int)param_1 + 0x5f) = 0;
            }
          }
          param_1[0x13] = param_1[0x13] + 1;
        }
        puStack_a0 = (uint *)pauStack_28;
        puStack_9c = puStack_30;
        uStack_a8 = 0;
        FUN_005fe0f0();
      }
      if (*(char *)(param_9 + 4) != '\0') {
        if (bStack_21 == 1) {
          param_1[0x82] = param_1[0x82] + 1;
        }
        else {
          param_1[0x83] = param_1[0x83] + 1;
        }
      }
      pcVar4 = *(code **)(*(int *)param_1[0x1ec] + 0x28);
      (**(code **)(*(int *)param_1[0x1ec] + 0x6c))();
      (*pcVar4)();
      pauVar19 = pauStack_28;
      param_1 = piStack_48;
      FUN_005ff420();
      *(bool *)(param_1 + 0x1de) = param_1[0x27] != 0;
      if (param_1[0x27] == 0) {
        param_1[0x200] = 0;
        param_1[0x201] = 0;
      }
      else {
        param_1[0x200] = (int)pauVar19;
        param_1[0x201] = (int)puStack_30;
      }
      pauStack_34 = (undefined (*) [16])((int)pauStack_34 + 1);
    } while (pauStack_34 < (uint)param_1[0x1f6]);
  }
  FUN_005f9ef0();
  iVar24 = param_1[0x27];
  *(bool *)(param_1 + 0x1de) = iVar24 != 0;
LAB_00601c38:
  ExceptionList = pvStack_1c;
  return iVar24 == 0;
LAB_006015e0:
  if (param_1[0x1fb] == 0) goto LAB_00601643;
  pauStack_44 = (undefined (*) [16])param_1[0x1f0];
  FUN_005fdf80(&pauStack_44,
               "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
               ,0xe36);
  pauStack_44 = (undefined (*) [16])(param_1[0x1fb] + 7U >> 3);
  FUN_005fdf80(&pauStack_44,
               "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\ReliabilityLayer.cpp"
               ,0xe39);
  param_1[0x1fb] = 0;
  goto LAB_00600ea0;
}



/* FUNCTION 6203 ; VA 0x00601c60 ; FUN_00601c60 */

int FUN_00601c60(int param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined uVar4;
  int iVar5;
  
  iVar3 = param_2;
  iVar2 = param_1;
  iVar1 = *(int *)(param_1 + 8);
  *(uint *)(param_1 + 8) = (iVar1 - (iVar1 - 1U & 7)) + 7;
  iVar5 = *(int *)(param_2 + 0x1c);
  if (iVar5 == 5) {
    uVar4 = 0;
  }
  else if (iVar5 == 6) {
    uVar4 = 2;
  }
  else {
    uVar4 = (undefined)iVar5;
    if (iVar5 == 7) {
      uVar4 = 3;
    }
  }
  param_1 = CONCAT13(uVar4,(undefined3)param_1);
  FUN_006a6060((int)&param_1 + 3,3,1);
  if (*(int *)(iVar3 + 0x14) == 0) {
    FUN_006a5d20();
  }
  else {
    FUN_006a5d50();
  }
  *(uint *)(iVar2 + 8) = (*(int *)(iVar2 + 8) - (*(int *)(iVar2 + 8) - 1U & 7)) + 7;
  param_2 = (uint)*(ushort *)(iVar3 + 0x18);
  FUN_006a5f50(&param_2);
  iVar5 = *(int *)(iVar3 + 0x1c);
  if ((((iVar5 == 2) || (iVar5 == 4)) || (iVar5 == 3)) || ((iVar5 == 6 || (iVar5 == 7)))) {
    FUN_005f8120(iVar3);
  }
  *(uint *)(iVar2 + 8) = (*(int *)(iVar2 + 8) - (*(int *)(iVar2 + 8) - 1U & 7)) + 7;
  iVar5 = *(int *)(iVar3 + 0x1c);
  if ((iVar5 == 1) || (iVar5 == 4)) {
    FUN_005f8120(iVar3 + 8);
    iVar5 = *(int *)(iVar3 + 0x1c);
  }
  if ((((iVar5 == 1) || (iVar5 == 4)) || (iVar5 == 3)) || (iVar5 == 7)) {
    FUN_005f8120(iVar3 + 4);
    param_1 = CONCAT13(*(undefined *)(iVar3 + 0xc),(undefined3)param_1);
    FUN_006a6030((int)&param_1 + 3);
  }
  if (*(int *)(iVar3 + 0x14) != 0) {
    FUN_006a5fa0((int *)(iVar3 + 0x14));
    FUN_006a5f50(iVar3 + 0xe);
    FUN_006a5fa0(iVar3 + 0x10);
  }
  FUN_006a5ee0(*(undefined4 *)(iVar3 + 0x3c),*(int *)(iVar3 + 0x18) + 7U >> 3);
  if (*(char *)(iVar3 + 0x4a) != '\0') {
    *(char *)(iVar2 + 4) = *(char *)(iVar3 + 0x4a);
  }
  return *(int *)(iVar2 + 8) - iVar1;
}



/* FUNCTION 6204 ; VA 0x00601dc0 ; FUN_00601dc0 */

void FUN_00601dc0(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x18);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 6205 ; VA 0x00601de0 ; FUN_00601de0 */

void __fastcall FUN_00601de0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x18);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 6206 ; VA 0x00601e00 ; FUN_00601e00 */

void __thiscall FUN_00601e00(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 4;
  param_1[2] = param_2 + param_4 * 4;
  return;
}



/* FUNCTION 6207 ; VA 0x00601e60 ; FUN_00601e60 */

void FUN_00601e60(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00601e60(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_01674ea0(param_1,0x18);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 6208 ; VA 0x00601ea0 ; FUN_00601ea0 */

void __fastcall FUN_00601ea0(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  iVar3 = iVar1;
  piVar4 = *(int **)(iVar1 + 4);
  ExceptionList = &pvStack_10;
  if (*(char *)((int)*(int **)(iVar1 + 4) + 0xd) == '\0') {
    do {
      FUN_00601e60(piVar4[2]);
      piVar2 = (int *)*piVar4;
      FUN_01674ea0(piVar4,0x18);
      piVar4 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar3 = *param_1;
  }
  *(int *)(iVar3 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6209 ; VA 0x00601f20 ; FUN_00601f20 */

void __thiscall FUN_00601f20(int *param_1,int *param_2,uint *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar1 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    puVar2 = (undefined4 *)puVar1[1];
    puVar4 = puVar1;
    do {
      if ((uint)puVar2[4] < *param_3) {
        puVar3 = (undefined4 *)puVar2[2];
      }
      else {
        puVar3 = (undefined4 *)*puVar2;
        puVar4 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
    if ((puVar4 != puVar1) && ((uint)puVar4[4] <= *param_3)) {
      *param_2 = (int)puVar4;
      return;
    }
  }
  *param_2 = (int)puVar1;
  return;
}



/* FUNCTION 6210 ; VA 0x00601f70 ; FUN_00601f70 */

int * __fastcall FUN_00601f70(int param_1)

{
  int *piVar1;
  
  piVar1 = (int *)(param_1 + 0xc);
  if (0xf < *(uint *)(param_1 + 0x20)) {
    piVar1 = (int *)*piVar1;
  }
  return piVar1;
}



/* FUNCTION 6211 ; VA 0x00601f80 ; FUN_00601f80 */

undefined4 * __thiscall FUN_00601f80(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  uint *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cbe8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *(undefined *)(param_1 + 2) = 0;
  uStack_8 = 0;
  uVar8 = FUN_005c9310(*(undefined4 *)(param_3 + 8));
  param_1[4] = 0;
  puVar2 = param_1 + 3;
  *puVar2 = uVar8;
  param_1[5] = *(undefined4 *)(param_3 + 0xc);
  param_1[6] = 0;
  param_1[7] = 0;
  uStack_8._0_1_ = 1;
  if (*(int *)(param_3 + 8) != 0) {
    FUN_005d2b00(uVar8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (*(int *)(param_3 + 8) == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = *(undefined4 **)(*(int *)(param_3 + 0x14) + *(int *)(param_3 + 4) * 4);
    }
    puVar7 = (undefined4 *)(param_1[7] + *puVar2 * 4);
    while (puVar10 != (undefined4 *)0x0) {
      puVar9 = (undefined4 *)FUN_01674e20(0x38);
      *puVar9 = 0;
      puVar9[1] = 0;
      FUN_0170d1f0(puVar9 + 2,0,0x30);
      FUN_0054ef60(puVar10 + 2);
      uVar4 = puVar10[9];
      uVar5 = puVar10[10];
      uVar6 = puVar10[0xb];
      puVar9[8] = puVar10[8];
      puVar9[9] = uVar4;
      puVar9[10] = uVar5;
      puVar9[0xb] = uVar6;
      *(undefined8 *)(puVar9 + 0xc) = *(undefined8 *)(puVar10 + 0xc);
      puVar9[1] = puVar10[1];
      *puVar7 = puVar9;
      param_1[4] = param_1[4] + 1;
      puVar3 = (undefined4 *)*puVar7;
      puVar10 = (undefined4 *)*puVar10;
      puVar9 = (undefined4 *)(param_1[7] + ((uint)puVar3[1] % *puVar2) * 4);
      if (*(int *)(param_1[7] + ((uint)puVar3[1] % *puVar2) * 4) == 0) {
        *puVar9 = puVar7;
        puVar7 = puVar3;
      }
      else {
        *puVar7 = *puVar3;
        *puVar3 = *(undefined4 *)*puVar9;
        *(undefined4 **)*puVar9 = puVar3;
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6212 ; VA 0x00602150 ; FUN_00602150 */

undefined4 * __thiscall FUN_00602150(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined **ppuVar5;
  int *in_stack_00000010;
  int *in_stack_00000018;
  undefined auStack_54 [12];
  int *piStack_48;
  int *piStack_40;
  undefined auStack_34 [12];
  int *piStack_28;
  int *piStack_20;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cc18;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0060e1d0(&stack0x00000004);
  *param_1 = 0;
  FUN_0060e1d0(auStack_54);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0060e1d0(auStack_34);
  ppuVar5 = &PTR_FUN_018ce2e8;
  cVar4 = FUN_006054a0();
  if (cVar4 == '\0') {
    ppuVar5 = (undefined **)0x0;
  }
  *param_1 = ppuVar5;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[2] + -1;
    piStack_20[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_20 + 4))();
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_40[2] + -1;
    piStack_40[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_40 + 4))();
    }
  }
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_48[1] + -1;
    piStack_48[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_48)();
      LOCK();
      iVar2 = piStack_48[2] + -1;
      piStack_48[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_48 + 4))();
      }
    }
  }
  if (in_stack_00000018 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000018[2] + -1;
    in_stack_00000018[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*in_stack_00000018 + 4))();
    }
  }
  piVar3 = in_stack_00000010;
  if (in_stack_00000010 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000010[1] + -1;
    in_stack_00000010[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000010)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6213 ; VA 0x00602290 ; FUN_00602290 */

undefined4 * __thiscall FUN_00602290(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00604750(param_2,param_2);
  return param_1;
}



/* FUNCTION 6214 ; VA 0x006022c0 ; FUN_006022c0 */

undefined4 * __thiscall FUN_006022c0(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006047e0(param_2,param_2);
  return param_1;
}



/* FUNCTION 6215 ; VA 0x006022f0 ; FUN_006022f0 */

undefined4 * __thiscall FUN_006022f0(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined auStack_10 [12];
  
  *param_1 = 0;
  param_1[1] = 0;
  iVar1 = param_2[1];
  if (iVar1 != 0) {
    piVar3 = (int *)(iVar1 + 4);
    iVar1 = *(int *)(iVar1 + 4);
    while (iVar1 != 0) {
      LOCK();
      iVar2 = *piVar3;
      if (iVar1 == iVar2) {
        *piVar3 = iVar1 + 1;
        iVar2 = iVar1;
      }
      UNLOCK();
      if (iVar2 == iVar1) {
        *param_1 = *param_2;
        param_1[1] = param_2[1];
        return param_1;
      }
      iVar1 = *piVar3;
    }
  }
  FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c21d80);
}



/* FUNCTION 6216 ; VA 0x00602370 ; FUN_00602370 */

undefined4 * __thiscall FUN_00602370(undefined4 *param_1,undefined *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = FUN_0088daf0();
  *param_1 = uVar2;
  iVar3 = FUN_005c9ef0();
  iVar1 = param_1[1];
  if (iVar1 == iVar3) {
    *(undefined *)(param_1 + 2) = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  *(undefined *)(param_1 + 2) = *param_2;
  param_1[1] = iVar3;
  return param_1;
}



/* FUNCTION 6217 ; VA 0x006023d0 ; FUN_006023d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_006023d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  float fVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  float10 fVar10;
  uint auStack_24 [2];
  double dStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179cc38;
  pvStack_10 = ExceptionList;
  iVar7 = param_2[1];
  ExceptionList = &pvStack_10;
  if (iVar7 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
    UNLOCK();
    iVar7 = param_2[1];
  }
  *param_1 = *param_2;
  piVar4 = (int *)param_1[1];
  param_1[1] = iVar7;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar7 = piVar4[1] + -1;
    piVar4[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  puStack_14 = param_2 + 2;
  if (param_1 + 2 != puStack_14) {
    fVar3 = (float)param_2[5];
    puVar9 = (undefined4 *)param_1[7];
    param_1[5] = fVar3;
    if (puVar9 == (undefined4 *)0x0) {
      uVar8 = 0;
    }
    else {
      dStack_1c = ((double)(int)param_1[3] + (double)(&DAT_018c0d90)[-((int)param_1[3] >> 0x1f)]) *
                  (double)fVar3;
      fVar10 = (float10)FUN_01725160(dStack_1c);
      dStack_1c = (double)fVar10;
      if (dStack_1c < _DAT_018c4e98) {
        uVar8 = FUN_016f3eb1();
      }
      else {
        uVar8 = 0xffffffff;
      }
    }
    param_1[6] = uVar8;
    if ((param_1[4] != 0) || (puStack_14[2] != 0)) {
      if ((uint)puStack_14[2] < uVar8) {
        puVar2 = puVar9 + param_1[3];
        for (; puVar9 != puVar2; puVar9 = puVar9 + 1) {
          *puVar9 = 0;
        }
      }
      else {
        FUN_005c9310();
        FUN_005d2b00();
      }
      auStack_24[1] = 0;
      uVar6 = SUB84(dStack_1c,0);
      dStack_1c = (double)((ulonglong)dStack_1c & 0xffff0000);
      auStack_24[0] = -(uint)(param_1 != (undefined4 *)0xfffffff5) & (uint)(param_1 + 3);
      if (param_1[4] != 0) {
        uVar5 = *(undefined4 *)(param_1[7] + param_1[3] * 4);
        *(undefined4 *)(param_1[7] + param_1[3] * 4) = 0;
        dStack_1c = (double)(CONCAT44(uVar5,uVar6) & 0xffffffffffff0000);
        param_1[4] = 0;
      }
      uStack_8 = 0;
      if (param_2[4] == 0) {
        uVar6 = 0;
      }
      else {
        uVar6 = *(undefined4 *)(param_2[7] + param_2[3] * 4);
      }
      FUN_00606b70(uVar6,param_1 + 2,auStack_24);
      FUN_00611c70();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6218 ; VA 0x00602590 ; FUN_00602590 */

int * __thiscall FUN_00602590(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = FUN_00630cf0();
  iVar1 = *param_1;
  if (iVar1 == iVar4) {
    if (param_1 + 1 != param_2) {
      FUN_005507b0();
      iVar1 = param_2[1];
      iVar4 = param_2[2];
      iVar2 = param_2[3];
      param_1[1] = *param_2;
      param_1[2] = iVar1;
      param_1[3] = iVar4;
      param_1[4] = iVar2;
      *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 4);
      param_2[4] = 0;
      param_2[5] = 0xf;
      *(undefined *)param_2 = 0;
    }
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[5] = 0;
  param_1[6] = 0;
  iVar1 = param_2[1];
  iVar2 = param_2[2];
  iVar3 = param_2[3];
  param_1[1] = *param_2;
  param_1[2] = iVar1;
  param_1[3] = iVar2;
  param_1[4] = iVar3;
  *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  *param_1 = iVar4;
  return param_1;
}



/* FUNCTION 6219 ; VA 0x00602640 ; FUN_00602640 */

void __thiscall FUN_00602640(uint *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  
  uVar1 = *param_1;
  uVar2 = param_1[1];
  if ((((uVar1 != 0) || (uVar2 != 0x80000000)) && ((uVar1 != 0xffffffff || (uVar2 != 0x7fffffff))))
     && ((uVar1 != 0xfffffffe || (uVar2 != 0x7fffffff)))) {
    uVar4 = *param_3;
    uVar5 = param_3[1];
    if (((uVar4 != 0) || (uVar5 != 0x80000000)) &&
       (((uVar4 != 0xffffffff || (uVar5 != 0x7fffffff)) &&
        ((uVar4 != 0xfffffffe || (uVar5 != 0x7fffffff)))))) goto LAB_00602785;
  }
  if ((uVar1 == 0xfffffffe) && (uVar2 == 0x7fffffff)) {
LAB_0060271c:
    *param_2 = 0xfffffffe;
    param_2[1] = 0x7fffffff;
    return;
  }
  uVar4 = *param_3;
  uVar5 = param_3[1];
  if ((uVar4 == 0xfffffffe) && (uVar5 == 0x7fffffff)) goto LAB_0060271c;
  if ((uVar1 == 0xffffffff) && (uVar2 == 0x7fffffff)) {
    if ((uVar4 == 0xffffffff) && (uVar5 == 0x7fffffff)) goto LAB_0060271c;
  }
  else if ((uVar1 == 0) && (uVar2 == 0x80000000)) {
    if ((uVar4 == 0) && (uVar5 == 0x80000000)) goto LAB_0060271c;
    goto LAB_006026ef;
  }
  if ((uVar1 != 0xffffffff) || (uVar2 != 0x7fffffff)) {
    if ((uVar4 == 0xffffffff) && (uVar5 == 0x7fffffff)) {
      *param_2 = 0;
      param_2[1] = 0x80000000;
      return;
    }
    cVar3 = FUN_00586330(uVar4,uVar5);
    if (cVar3 != '\0') {
      *param_2 = 0xffffffff;
      param_2[1] = 0x7fffffff;
      return;
    }
LAB_00602785:
    param_2[1] = (uVar2 - uVar5) - (uint)(uVar1 < uVar4);
    *param_2 = uVar1 - uVar4;
    return;
  }
LAB_006026ef:
  *param_2 = uVar1;
  param_2[1] = param_1[1];
  return;
}



/* FUNCTION 6220 ; VA 0x006027e0 ; thunk_FUN_00aff8c0 */

undefined * thunk_FUN_00aff8c0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecf4c;
  pvStack_10 = ExceptionList;
  if (DAT_01eedcc4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeded0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eeded0);
      if (DAT_01eeded0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00e70350();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BasePart",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0188d2e0);
        FUN_016f37bf(&DAT_01eeded0);
      }
    }
    DAT_01eedcc4 = &DAT_01eedcc8;
  }
  ExceptionList = pvStack_10;
  return DAT_01eedcc4;
}



/* FUNCTION 6221 ; VA 0x00602800 ; thunk_FUN_00add460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00add460(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ea680;
  pvStack_10 = ExceptionList;
  if (DAT_01eebacc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eebce0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eebce0);
      if (DAT_01eebce0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Sound",0,uStack_20,0,0,0x1b,0,&DAT_01ef904c);
        _DAT_01eebcd8 = RBX::Creator<class_RBX::Soundscape::Sound>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eebad0,&DAT_01eebcd8);
        FUN_016f3654(FUN_0188b850);
        FUN_016f37bf(&DAT_01eebce0);
      }
    }
    DAT_01eebacc = &DAT_01eebad0;
  }
  ExceptionList = pvStack_10;
  return DAT_01eebacc;
}



/* FUNCTION 6222 ; VA 0x00602820 ; thunk_FUN_008aa870 */

undefined * thunk_FUN_008aa870(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc8fc;
  pvStack_10 = ExceptionList;
  if (DAT_01edfc24 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edfe30) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01edfe30);
      if (DAT_01edfe30 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00a93fd0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Workspace",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01881950);
        FUN_016f37bf(&DAT_01edfe30);
      }
    }
    DAT_01edfc24 = &DAT_01edfc28;
  }
  ExceptionList = pvStack_10;
  return DAT_01edfc24;
}



/* FUNCTION 6223 ; VA 0x00602830 ; FUN_00602830 */

void __thiscall FUN_00602830(uint *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  
  uVar1 = ((int)param_3 - (int)param_2) / 0x14;
  uVar7 = *param_1;
  uVar6 = (int)(param_1[1] - uVar7) / 0x14;
  uVar2 = (int)(param_1[2] - uVar7) / 0x14;
  if (uVar2 < uVar1) {
    if (0xccccccc < uVar1) {
LAB_006029ef:
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar6 = uVar1;
    if ((uVar2 <= 0xccccccc - (uVar2 >> 1)) && (uVar6 = uVar2 + (uVar2 >> 1), uVar6 < uVar1)) {
      uVar6 = uVar1;
    }
    if (uVar7 != 0) {
      FUN_0061a460(uVar7,uVar2);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    if (uVar6 != 0) {
      if (0xccccccc < uVar6) goto LAB_006029ef;
      uVar6 = uVar6 * 0x14;
      if (uVar6 < 0x1000) {
        if (uVar6 == 0) {
          uVar7 = 0;
        }
        else {
          uVar7 = FUN_01674e20(uVar6);
        }
      }
      else {
        uVar7 = uVar6 + 0x23;
        if (uVar7 <= uVar6) {
          uVar7 = 0xffffffff;
        }
        iVar8 = FUN_01674e20(uVar7);
        if (iVar8 == 0) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        uVar7 = iVar8 + 0x23U & 0xffffffe0;
        *(int *)(uVar7 - 4) = iVar8;
      }
      *param_1 = uVar7;
      param_1[1] = uVar7;
      param_1[2] = *param_1 + uVar6;
    }
    puVar9 = (undefined4 *)*param_1;
    if (param_2 != param_3) {
      do {
        uVar3 = param_2[1];
        uVar4 = param_2[2];
        uVar5 = param_2[3];
        *puVar9 = *param_2;
        puVar9[1] = uVar3;
        puVar9[2] = uVar4;
        puVar9[3] = uVar5;
        puVar10 = param_2 + 4;
        param_2 = param_2 + 5;
        puVar9[4] = *puVar10;
        puVar9 = puVar9 + 5;
      } while (param_2 != param_3);
      param_1[1] = (uint)puVar9;
      return;
    }
  }
  else {
    if (uVar1 <= uVar6) {
      FUN_00602da0(param_2,param_3,uVar7);
      param_1[1] = uVar7 + uVar1 * 0x14;
      return;
    }
    puVar10 = param_2 + uVar6 * 5;
    FUN_00602da0(param_2,puVar10,uVar7);
    puVar9 = (undefined4 *)param_1[1];
    for (; puVar10 != param_3; puVar10 = puVar10 + 5) {
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *puVar9 = *puVar10;
      puVar9[1] = uVar3;
      puVar9[2] = uVar4;
      puVar9[3] = uVar5;
      puVar9[4] = puVar10[4];
      puVar9 = puVar9 + 5;
    }
  }
  param_1[1] = (uint)puVar9;
  return;
}



/* FUNCTION 6224 ; VA 0x00602a00 ; FUN_00602a00 */

void __thiscall FUN_00602a00(uint *param_1,undefined8 *param_2,undefined8 *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  uint uVar7;
  undefined8 *puVar8;
  
  puVar6 = param_2;
  iVar4 = (int)param_3 - (int)param_2;
  uVar3 = *param_1;
  uVar1 = iVar4 / 0xc;
  uVar7 = (int)(param_1[1] - uVar3) / 0xc;
  uVar2 = (int)(param_1[2] - uVar3) / 0xc;
  if (uVar2 < uVar1) {
    param_2 = (undefined8 *)uVar2;
    if (0x15555555 < uVar1) {
LAB_00602bdc:
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar7 = uVar1;
    if ((uVar2 <= 0x15555555 - (uVar2 >> 1)) && (uVar7 = (uVar2 >> 1) + uVar2, uVar7 < uVar1)) {
      uVar7 = uVar1;
    }
    if (uVar3 != 0) {
      FUN_0061a4e0(uVar3,uVar2);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    if (uVar7 != 0) {
      if (0x15555555 < uVar7) goto LAB_00602bdc;
      uVar7 = uVar7 * 0xc;
      if (uVar7 < 0x1000) {
        if (uVar7 == 0) {
          uVar3 = 0;
        }
        else {
          uVar3 = FUN_01674e20(uVar7);
        }
      }
      else {
        uVar3 = uVar7 + 0x23;
        if (uVar3 <= uVar7) {
          uVar3 = 0xffffffff;
        }
        iVar4 = FUN_01674e20(uVar3);
        if (iVar4 == 0) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        uVar3 = iVar4 + 0x23U & 0xffffffe0;
        *(int *)(uVar3 - 4) = iVar4;
      }
      *param_1 = uVar3;
      param_1[1] = uVar3;
      param_1[2] = *param_1 + uVar7;
    }
    puVar5 = (undefined8 *)*param_1;
    if (puVar6 != param_3) {
      do {
        *puVar5 = *puVar6;
        puVar8 = puVar6 + 1;
        puVar6 = (undefined8 *)((int)puVar6 + 0xc);
        *(undefined4 *)(puVar5 + 1) = *(undefined4 *)puVar8;
        puVar5 = (undefined8 *)((int)puVar5 + 0xc);
      } while (puVar6 != param_3);
      param_1[1] = (uint)puVar5;
      return;
    }
  }
  else {
    if (uVar1 <= uVar7) {
      param_2 = (undefined8 *)uVar2;
      FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
      FUN_0170cc70(uVar3,puVar6,iVar4);
      param_1[1] = uVar3 + uVar1 * 0xc;
      return;
    }
    puVar8 = (undefined8 *)((int)param_2 + uVar7 * 0xc);
    param_2 = (undefined8 *)uVar2;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(uVar3,puVar6,(int)puVar8 - (int)puVar6);
    puVar5 = (undefined8 *)param_1[1];
    for (; puVar8 != param_3; puVar8 = (undefined8 *)((int)puVar8 + 0xc)) {
      *puVar5 = *puVar8;
      *(undefined4 *)(puVar5 + 1) = *(undefined4 *)(puVar8 + 1);
      puVar5 = (undefined8 *)((int)puVar5 + 0xc);
    }
  }
  param_1[1] = (uint)puVar5;
  return;
}



/* FUNCTION 6225 ; VA 0x00602bf0 ; FUN_00602bf0 */

void FUN_00602bf0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  
  iVar1 = FUN_00575b50(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = *param_3;
  return;
}



/* FUNCTION 6226 ; VA 0x00602c10 ; FUN_00602c10 */

int FUN_00602c10(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179cc58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00616d40();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  FUN_0054ef60(*param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar2 = FUN_00888530();
  *(undefined4 *)(iVar1 + 0x28) = uVar2;
  *(undefined4 *)(iVar1 + 0x2c) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 6227 ; VA 0x00602c8a ; Catch_All@00602c8a */

void Catch_All_00602c8a(void)

{
  int unaff_EBP;
  
  FUN_006172e0(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6228 ; VA 0x00602ca0 ; FUN_00602ca0 */

void FUN_00602ca0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined8 *puVar1;
  int iVar2;
  
  iVar2 = FUN_005cb2b0(param_1,param_2);
  puVar1 = (undefined8 *)*param_4;
  *(undefined8 *)(iVar2 + 8) = *puVar1;
  *(undefined4 *)(iVar2 + 0x10) = *(undefined4 *)(puVar1 + 1);
  *(undefined4 *)(iVar2 + 0x14) = 0;
  *(undefined4 *)(iVar2 + 0x18) = 0;
  *(undefined4 *)(iVar2 + 0x1c) = 0;
  return;
}



/* FUNCTION 6229 ; VA 0x00602ce0 ; FUN_00602ce0 */

uint __thiscall FUN_00602ce0(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  uint uVar2;
  undefined4 uVar3;
  uint in_EAX;
  uint *puVar4;
  
  iVar1 = param_2[1];
  if (iVar1 != 0) {
    puVar4 = (uint *)(iVar1 + 4);
    uVar2 = *(uint *)(iVar1 + 4);
    while (uVar2 != 0) {
      LOCK();
      in_EAX = *puVar4;
      if (uVar2 == in_EAX) {
        *puVar4 = uVar2 + 1;
        in_EAX = uVar2;
      }
      UNLOCK();
      if (in_EAX == uVar2) {
        *param_1 = *param_2;
        uVar3 = param_2[1];
        param_1[1] = uVar3;
        return CONCAT31((int3)((uint)uVar3 >> 8),1);
      }
      uVar2 = *puVar4;
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 6230 ; VA 0x00602d30 ; FUN_00602d30 */

undefined4 * FUN_00602d30(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar3 = param_1;
  puVar4 = param_3;
  if (param_1 != param_2) {
    do {
      iVar2 = *(int *)((int)param_1 + (4 - (int)param_3) + (int)puVar4);
      if (iVar2 != 0) {
        LOCK();
        *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
        UNLOCK();
        iVar2 = *(int *)((int)param_1 + (4 - (int)param_3) + (int)puVar4);
      }
      *puVar4 = *puVar3;
      piVar1 = (int *)puVar4[1];
      puVar4[1] = iVar2;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      puVar3 = puVar3 + 2;
      puVar4 = puVar4 + 2;
    } while (puVar3 != param_2);
  }
  return puVar4;
}



/* FUNCTION 6231 ; VA 0x00602da0 ; FUN_00602da0 */

undefined4 * FUN_00602da0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar4 = param_3;
  if (param_1 != param_2) {
    puVar2 = param_1 + 1;
    puVar3 = param_3 + 2;
    do {
      *puVar4 = puVar2[-1];
      puVar4 = puVar4 + 5;
      puVar3[-1] = *puVar2;
      *puVar3 = *(undefined4 *)((int)param_1 + (-0x14 - (int)param_3) + (int)(puVar3 + 5));
      puVar3[1] = puVar2[2];
      puVar3[2] = puVar2[3];
      puVar1 = puVar2 + 4;
      puVar2 = puVar2 + 5;
      puVar3 = puVar3 + 5;
    } while (puVar1 != param_2);
  }
  return puVar4;
}



/* FUNCTION 6232 ; VA 0x00602e00 ; FUN_00602e00 */

void FUN_00602e00(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 8);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      param_1 = param_1 + 0xc;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 6233 ; VA 0x00602e50 ; FUN_00602e50 */

void FUN_00602e50(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    puVar2 = param_1 + 1;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      FUN_01674ea0(*puVar2);
      *puVar2 = 0;
      puVar2[1] = 0;
      puVar1 = puVar2 + 3;
      puVar2[2] = 0;
      puVar2 = puVar2 + 4;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6234 ; VA 0x00602ed0 ; FUN_00602ed0 */

void FUN_00602ed0(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    piVar2 = param_1 + 2;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      if (*piVar2 != 0) {
        (**(code **)(*piVar2 + 8))(piVar2 + 1);
      }
      piVar1 = piVar2 + 0x34;
      piVar2 = piVar2 + 0x36;
    } while (piVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6235 ; VA 0x00602f40 ; FUN_00602f40 */

void FUN_00602f40(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_1 != param_2) {
    piVar3 = param_1 + 1;
    do {
      piVar1 = (int *)piVar3[2];
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = (int *)*piVar3;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = piVar3 + 5;
      piVar3 = piVar3 + 6;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 6236 ; VA 0x00602fc0 ; FUN_00602fc0 */

int __thiscall FUN_00602fc0(int *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  uint uVar8;
  int *piVar9;
  int iVar10;
  int *piVar11;
  
  iVar2 = *param_1;
  iVar10 = (int)param_2 - iVar2 >> 2;
  iVar3 = param_1[1] - iVar2 >> 2;
  if (iVar3 == 0x3fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar4 = iVar3 + 1;
  uVar8 = param_1[2] - iVar2 >> 2;
  uVar5 = uVar4;
  if ((uVar8 <= 0x3fffffff - (uVar8 >> 1)) && (uVar5 = (uVar8 >> 1) + uVar8, uVar5 < uVar4)) {
    uVar5 = uVar4;
  }
  piVar6 = (int *)FUN_00577ed0(uVar5);
  iVar2 = iVar10 * 4;
  iVar3 = *param_3;
  piVar6[iVar10] = iVar3;
  LOCK();
  piVar11 = (int *)(iVar3 + 0x28);
  *piVar11 = *piVar11 + 1;
  UNLOCK();
  piVar11 = (int *)param_1[1];
  piVar7 = (int *)*param_1;
  piVar9 = piVar6;
  if (param_2 == piVar11) {
    for (; piVar7 != piVar11; piVar7 = piVar7 + 1) {
      iVar3 = *piVar7;
      *piVar9 = iVar3;
      LOCK();
      piVar1 = (int *)(iVar3 + 0x28);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      piVar9 = piVar9 + 1;
    }
  }
  else {
    if (piVar7 != param_2) {
      do {
        iVar3 = *piVar7;
        *piVar9 = iVar3;
        LOCK();
        piVar11 = (int *)(iVar3 + 0x28);
        *piVar11 = *piVar11 + 1;
        UNLOCK();
        piVar7 = piVar7 + 1;
        piVar9 = piVar9 + 1;
      } while (piVar7 != param_2);
      piVar11 = (int *)param_1[1];
    }
    if (param_2 != piVar11) {
      iVar3 = iVar2 - (int)param_2;
      do {
        iVar10 = *param_2;
        *(int *)((int)param_2 + (int)piVar6 + iVar3 + 4) = iVar10;
        LOCK();
        piVar7 = (int *)(iVar10 + 0x28);
        *piVar7 = *piVar7 + 1;
        UNLOCK();
        param_2 = param_2 + 1;
      } while (param_2 != piVar11);
    }
  }
  FUN_00616de0(piVar6,uVar4,uVar5);
  return *param_1 + iVar2;
}



/* FUNCTION 6237 ; VA 0x006030d0 ; FUN_006030d0 */

int __thiscall FUN_006030d0(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  
  uVar7 = *param_1;
  iVar8 = param_2 - uVar7;
  iVar2 = (int)(param_1[1] - uVar7) >> 2;
  if (iVar2 == 0x3fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar5 = (int)(param_1[2] - uVar7) >> 2;
  uVar7 = uVar1;
  if ((uVar5 <= 0x3fffffff - (uVar5 >> 1)) && (uVar7 = (uVar5 >> 1) + uVar5, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar5 = uVar7 * 4;
  if (uVar7 < 0x40000000) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_0060313f;
    if (uVar5 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_0060313f:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar3);
    if (iVar2 == 0) goto LAB_00603254;
    uVar7 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar2;
  }
  iVar2 = (iVar8 >> 2) * 4;
  *(undefined4 *)(iVar2 + uVar7) = *param_3;
  uVar3 = param_1[1];
  if (param_2 == uVar3) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(uVar7,*param_1,uVar3 - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(uVar7,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar2 + 4 + uVar7,param_2,param_1[1] - param_2);
  }
  uVar3 = *param_1;
  if (uVar3 != 0) {
    uVar6 = param_1[2] - uVar3 & 0xfffffffc;
    uVar4 = uVar3;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uVar3 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar3 - uVar4) - 4) {
LAB_00603254:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + uVar1 * 4;
  param_1[2] = uVar5 + uVar7;
  return *param_1 + iVar2;
}



/* FUNCTION 6238 ; VA 0x00603260 ; FUN_00603260 */

int __thiscall FUN_00603260(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  
  iVar8 = *param_1;
  iVar9 = param_2 - iVar8 >> 3;
  iVar4 = param_1[1] - iVar8 >> 3;
  if (iVar4 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar6 = param_1[2] - iVar8 >> 3;
  uVar10 = uVar1;
  if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar10 = (uVar6 >> 1) + uVar6, uVar10 < uVar1)) {
    uVar10 = uVar1;
  }
  puVar5 = (undefined4 *)FUN_00578020(uVar10);
  puVar3 = puVar5 + iVar9 * 2;
  *puVar3 = 0;
  puVar3[1] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar2 = (int *)(param_3[1] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  *puVar3 = *param_3;
  puVar3[1] = param_3[1];
  iVar8 = param_1[1];
  iVar4 = *param_1;
  puVar7 = puVar5;
  if (param_2 != iVar8) {
    FUN_005c23f0(*param_1,param_2,puVar5,param_1);
    iVar8 = param_1[1];
    puVar7 = puVar3 + 2;
    iVar4 = param_2;
  }
  FUN_005c23f0(iVar4,iVar8,puVar7,param_1);
  FUN_005c5230(puVar5,uVar1,uVar10);
  return *param_1 + iVar9 * 8;
}



/* FUNCTION 6239 ; VA 0x00603350 ; FUN_00603350 */

int __thiscall FUN_00603350(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined8 *puVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  undefined4 *puVar10;
  uint uVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  int iVar14;
  undefined4 *puVar15;
  
  iVar3 = ((int)param_2 - *param_1) / 0x18;
  iVar9 = (param_1[1] - *param_1) / 0x18;
  if (iVar9 == 0xaaaaaaa) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar9 + 1;
  uVar11 = (param_1[2] - *param_1) / 0x18;
  uVar7 = uVar1;
  if ((uVar11 <= 0xaaaaaaa - (uVar11 >> 1)) && (uVar7 = (uVar11 >> 1) + uVar11, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar11 = uVar7 * 0x18;
  if (uVar7 < 0xaaaaaab) {
    if (0xfff < uVar11) goto LAB_006033eb;
    if (uVar11 == 0) {
      puVar15 = (undefined4 *)0x0;
    }
    else {
      puVar15 = (undefined4 *)FUN_01674e20(uVar11);
    }
  }
  else {
    uVar11 = 0xffffffff;
LAB_006033eb:
    uVar8 = uVar11 + 0x23;
    if (uVar8 <= uVar11) {
      uVar8 = 0xffffffff;
    }
    iVar9 = FUN_01674e20(uVar8);
    if (iVar9 == 0) goto LAB_00603535;
    puVar15 = (undefined4 *)(iVar9 + 0x23U & 0xffffffe0);
    puVar15[-1] = iVar9;
  }
  uVar4 = param_3[1];
  uVar5 = param_3[2];
  uVar6 = param_3[3];
  puVar13 = puVar15 + iVar3 * 6;
  *puVar13 = *param_3;
  puVar13[1] = uVar4;
  puVar13[2] = uVar5;
  puVar13[3] = uVar6;
  *(undefined8 *)(puVar15 + iVar3 * 6 + 4) = *(undefined8 *)(param_3 + 4);
  puVar13 = (undefined4 *)param_1[1];
  puVar10 = (undefined4 *)*param_1;
  puVar12 = puVar15;
  if (param_2 == puVar13) {
    for (; puVar10 != puVar13; puVar10 = puVar10 + 6) {
      uVar4 = puVar10[1];
      uVar5 = puVar10[2];
      uVar6 = puVar10[3];
      *puVar12 = *puVar10;
      puVar12[1] = uVar4;
      puVar12[2] = uVar5;
      puVar12[3] = uVar6;
      *(undefined8 *)(puVar12 + 4) = *(undefined8 *)(puVar10 + 4);
      puVar12 = puVar12 + 6;
    }
  }
  else {
    if (puVar10 != param_2) {
      do {
        uVar4 = puVar10[1];
        uVar5 = puVar10[2];
        uVar6 = puVar10[3];
        *puVar12 = *puVar10;
        puVar12[1] = uVar4;
        puVar12[2] = uVar5;
        puVar12[3] = uVar6;
        puVar2 = (undefined8 *)(puVar10 + 4);
        puVar10 = puVar10 + 6;
        *(undefined8 *)(puVar12 + 4) = *puVar2;
        puVar12 = puVar12 + 6;
      } while (puVar10 != param_2);
      puVar13 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar13) {
      puVar10 = puVar15 + iVar3 * 6 + 6;
      do {
        uVar4 = param_2[1];
        uVar5 = param_2[2];
        uVar6 = param_2[3];
        *puVar10 = *param_2;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar2 = (undefined8 *)(param_2 + 4);
        param_2 = param_2 + 6;
        *(undefined8 *)(puVar10 + 4) = *puVar2;
        puVar10 = puVar10 + 6;
      } while (param_2 != puVar13);
    }
  }
  iVar9 = *param_1;
  if (iVar9 != 0) {
    uVar11 = ((param_1[2] - iVar9) / 0x18) * 0x18;
    iVar14 = iVar9;
    if (0xfff < uVar11) {
      iVar14 = *(int *)(iVar9 + -4);
      uVar11 = uVar11 + 0x23;
      if (0x1f < (iVar9 - iVar14) - 4U) {
LAB_00603535:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar14,uVar11);
  }
  *param_1 = (int)puVar15;
  param_1[1] = (int)(puVar15 + uVar1 * 6);
  param_1[2] = (int)(puVar15 + uVar7 * 6);
  return *param_1 + iVar3 * 0x18;
}



/* FUNCTION 6240 ; VA 0x00603540 ; FUN_00603540 */

int __thiscall FUN_00603540(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  
  uVar8 = *param_1;
  iVar6 = (int)(param_1[1] - uVar8) >> 5;
  if (iVar6 == 0x7ffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar10 = (int)(param_1[2] - uVar8) >> 5;
  uVar12 = uVar1;
  if ((uVar10 <= 0x7ffffff - (uVar10 >> 1)) && (uVar12 = (uVar10 >> 1) + uVar10, uVar12 < uVar1)) {
    uVar12 = uVar1;
  }
  uVar10 = uVar12 * 0x20;
  if (uVar12 < 0x8000000) {
    uVar12 = uVar10;
    if (0xfff < uVar10) goto LAB_006035aa;
    if (uVar10 == 0) {
      uVar12 = 0;
    }
    else {
      uVar12 = FUN_01674e20(uVar10);
    }
  }
  else {
    uVar12 = 0xffffffff;
LAB_006035aa:
    uVar7 = uVar12 + 0x23;
    if (uVar7 <= uVar12) {
      uVar7 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar7);
    if (iVar6 == 0) goto LAB_006036be;
    uVar12 = iVar6 + 0x23U & 0xffffffe0;
    *(int *)(uVar12 - 4) = iVar6;
  }
  uVar11 = param_2 - uVar8 & 0xffffffe0;
  *(undefined4 *)(uVar11 + 0x10 + uVar12) = 0;
  *(undefined4 *)(uVar11 + 0x14 + uVar12) = 0;
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  puVar2 = (undefined4 *)(uVar11 + uVar12);
  *puVar2 = *param_3;
  puVar2[1] = uVar3;
  puVar2[2] = uVar4;
  puVar2[3] = uVar5;
  *(undefined8 *)(uVar11 + 0x10 + uVar12) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  uVar8 = *param_1;
  *(undefined8 *)(uVar11 + 0x18 + uVar12) = *(undefined8 *)(param_3 + 6);
  uVar7 = param_1[1];
  uVar9 = uVar12;
  if (param_2 != uVar7) {
    FUN_0055c650(uVar8,param_2,uVar12,param_1);
    uVar7 = param_1[1];
    uVar9 = uVar11 + 0x20 + uVar12;
    uVar8 = param_2;
  }
  FUN_0055c650(uVar8,uVar7,uVar9,param_1);
  if (*param_1 != 0) {
    FUN_00559500(*param_1,param_1[1],param_1);
    uVar8 = *param_1;
    uVar9 = param_1[2] - uVar8 & 0xffffffe0;
    uVar7 = uVar8;
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(uVar8 - 4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (uVar8 - uVar7) - 4) {
LAB_006036be:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  *param_1 = uVar12;
  param_1[1] = uVar1 * 0x20 + uVar12;
  param_1[2] = uVar10 + uVar12;
  return *param_1 + uVar11;
}



/* FUNCTION 6241 ; VA 0x006036d0 ; FUN_006036d0 */

int __thiscall FUN_006036d0(uint *param_1,uint param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar5 = *param_1;
  iVar3 = (int)(param_1[1] - uVar5) / 0xc;
  if (iVar3 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = iVar3 + 1;
  uVar4 = (int)(param_1[2] - uVar5) / 0xc;
  uVar8 = uVar7;
  if ((uVar4 <= 0x15555555 - (uVar4 >> 1)) && (uVar8 = (uVar4 >> 1) + uVar4, uVar8 < uVar7)) {
    uVar8 = uVar7;
  }
  uVar4 = uVar8 * 0xc;
  if (uVar8 < 0x15555556) {
    uVar8 = uVar4;
    if (0xfff < uVar4) goto LAB_00603767;
    if (uVar4 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_00603767:
    uVar2 = uVar8 + 0x23;
    if (uVar2 <= uVar8) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_0060388f;
    uVar8 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar3;
  }
  uVar1 = *param_3;
  iVar3 = ((int)(param_2 - uVar5) / 0xc) * 0xc;
  *(undefined4 *)(iVar3 + 4 + uVar8) = 0;
  *(undefined4 *)(iVar3 + 8 + uVar8) = 0;
  *(undefined4 *)(iVar3 + uVar8) = uVar1;
  *(undefined4 *)(iVar3 + 4 + uVar8) = param_3[1];
  *(undefined4 *)(iVar3 + 8 + uVar8) = param_3[2];
  param_3[1] = 0;
  param_3[2] = 0;
  uVar2 = param_1[1];
  uVar5 = *param_1;
  uVar6 = uVar8;
  if (param_2 != uVar2) {
    FUN_00604ed0(uVar5,param_2,uVar8,param_1);
    uVar2 = param_1[1];
    uVar6 = iVar3 + 0xc + uVar8;
    uVar5 = param_2;
  }
  FUN_00604ed0(uVar5,uVar2,uVar6,param_1);
  if (*param_1 != 0) {
    FUN_00602e00(*param_1,param_1[1],param_1);
    uVar5 = *param_1;
    uVar6 = ((int)(param_1[2] - uVar5) / 0xc) * 0xc;
    uVar2 = uVar5;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar5 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar5 - uVar2) - 4) {
LAB_0060388f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar8;
  param_1[1] = uVar8 + uVar7 * 0xc;
  param_1[2] = uVar4 + uVar8;
  return *param_1 + iVar3;
}



/* FUNCTION 6242 ; VA 0x006038a0 ; FUN_006038a0 */

int __thiscall FUN_006038a0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  undefined4 *puVar12;
  uint uVar13;
  undefined4 *puVar14;
  undefined4 *puVar15;
  undefined4 *puVar16;
  
  iVar11 = *param_1;
  iVar7 = (int)param_2 - iVar11 >> 4;
  iVar8 = param_1[1] - iVar11 >> 4;
  if (iVar8 == 0xfffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar8 + 1;
  uVar13 = param_1[2] - iVar11 >> 4;
  uVar9 = uVar1;
  if ((uVar13 <= 0xfffffff - (uVar13 >> 1)) && (uVar9 = (uVar13 >> 1) + uVar13, uVar9 < uVar1)) {
    uVar9 = uVar1;
  }
  uVar13 = uVar9 * 0x10;
  if (uVar9 < 0x10000000) {
    if (0xfff < uVar13) goto LAB_00603912;
    if (uVar13 == 0) {
      puVar16 = (undefined4 *)0x0;
    }
    else {
      puVar16 = (undefined4 *)FUN_01674e20(uVar13);
    }
  }
  else {
    uVar13 = 0xffffffff;
LAB_00603912:
    uVar10 = uVar13 + 0x23;
    if (uVar10 <= uVar13) {
      uVar10 = 0xffffffff;
    }
    iVar11 = FUN_01674e20(uVar10);
    if (iVar11 == 0) goto LAB_00603a16;
    puVar16 = (undefined4 *)(iVar11 + 0x23U & 0xffffffe0);
    puVar16[-1] = iVar11;
  }
  puVar2 = puVar16 + iVar7 * 4;
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  *puVar2 = *param_3;
  puVar2[1] = uVar3;
  puVar2[2] = uVar4;
  puVar2[3] = uVar5;
  puVar15 = (undefined4 *)param_1[1];
  puVar12 = (undefined4 *)*param_1;
  puVar14 = puVar16;
  if (param_2 == puVar15) {
    for (; puVar12 != puVar15; puVar12 = puVar12 + 4) {
      uVar3 = puVar12[1];
      uVar4 = puVar12[2];
      uVar5 = puVar12[3];
      *puVar14 = *puVar12;
      puVar14[1] = uVar3;
      puVar14[2] = uVar4;
      puVar14[3] = uVar5;
      puVar14 = puVar14 + 4;
    }
  }
  else {
    if (puVar12 != param_2) {
      do {
        uVar3 = *puVar12;
        uVar4 = puVar12[1];
        uVar5 = puVar12[2];
        uVar6 = puVar12[3];
        puVar12 = puVar12 + 4;
        *puVar14 = uVar3;
        puVar14[1] = uVar4;
        puVar14[2] = uVar5;
        puVar14[3] = uVar6;
        puVar14 = puVar14 + 4;
      } while (puVar12 != param_2);
      puVar15 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar15) {
      do {
        uVar3 = *param_2;
        uVar4 = param_2[1];
        uVar5 = param_2[2];
        uVar6 = param_2[3];
        param_2 = param_2 + 4;
        puVar2[4] = uVar3;
        puVar2[5] = uVar4;
        puVar2[6] = uVar5;
        puVar2[7] = uVar6;
        puVar2 = puVar2 + 4;
      } while (param_2 != puVar15);
    }
  }
  iVar11 = *param_1;
  if (iVar11 != 0) {
    uVar13 = param_1[2] - iVar11 & 0xfffffff0;
    iVar8 = iVar11;
    if (0xfff < uVar13) {
      iVar8 = *(int *)(iVar11 + -4);
      uVar13 = uVar13 + 0x23;
      if (0x1f < (iVar11 - iVar8) - 4U) {
LAB_00603a16:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar13);
  }
  *param_1 = (int)puVar16;
  param_1[1] = (int)(puVar16 + uVar1 * 4);
  param_1[2] = (int)(puVar16 + uVar9 * 4);
  return *param_1 + iVar7 * 0x10;
}



/* FUNCTION 6243 ; VA 0x00603a30 ; FUN_00603a30 */

int __thiscall FUN_00603a30(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  
  iVar7 = *param_1;
  iVar8 = param_2 - iVar7 >> 3;
  iVar3 = param_1[1] - iVar7 >> 3;
  if (iVar3 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar6 = param_1[2] - iVar7 >> 3;
  uVar9 = uVar1;
  if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar9 = (uVar6 >> 1) + uVar6, uVar9 < uVar1)) {
    uVar9 = uVar1;
  }
  puVar4 = (undefined4 *)FUN_00578020(uVar9);
  puVar4[iVar8 * 2] = 0;
  puVar4[iVar8 * 2 + 1] = 0;
  puVar2 = puVar4 + iVar8 * 2;
  *puVar2 = *param_3;
  puVar2[1] = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  iVar3 = param_1[1];
  iVar7 = *param_1;
  puVar5 = puVar4;
  if (param_2 != iVar3) {
    FUN_005c23f0(iVar7,param_2,puVar4,param_1);
    iVar3 = param_1[1];
    puVar5 = puVar2 + 2;
    iVar7 = param_2;
  }
  FUN_005c23f0(iVar7,iVar3,puVar5,param_1);
  FUN_005c5230(puVar4,uVar1,uVar9);
  return *param_1 + iVar8 * 8;
}



/* FUNCTION 6244 ; VA 0x00603b20 ; FUN_00603b20 */

int __thiscall FUN_00603b20(int *param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int iVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179cc78;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  iVar4 = (param_1[1] - iVar2) / 0x58;
  if (iVar4 == 0x2e8ba2e) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar6 = (param_1[2] - iVar2) / 0x58;
  uVar3 = uVar1;
  if ((uVar6 <= 0x2e8ba2e - (uVar6 >> 1)) && (uVar3 = (uVar6 >> 1) + uVar6, uVar3 < uVar1)) {
    uVar3 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_006181a0(uVar3);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar2) / 0x58) * 0x58;
  FUN_0060f060(param_3);
  iVar2 = param_1[1];
  if (param_2 == iVar2) {
    iVar9 = *param_1;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    for (; iVar9 != iVar2; iVar9 = iVar9 + 0x58) {
      FUN_0060f060(iVar9);
    }
  }
  else {
    FUN_00617c30(*param_1,param_2,iVar4);
    FUN_00617c30(param_2,param_1[1],iVar5 + iVar4 + 0x58);
  }
  puVar7 = (undefined4 *)*param_1;
  if (puVar7 != (undefined4 *)0x0) {
    puVar8 = (undefined4 *)param_1[1];
    if (puVar7 != puVar8) {
      do {
        (**(code **)*puVar7)(0);
        puVar7 = puVar7 + 0x16;
      } while (puVar7 != puVar8);
      puVar7 = (undefined4 *)*param_1;
    }
    uVar6 = ((param_1[2] - (int)puVar7) / 0x58) * 0x58;
    puVar8 = puVar7;
    if (0xfff < uVar6) {
      puVar8 = (undefined4 *)puVar7[-1];
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uint)((int)puVar7 + (-4 - (int)puVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar8,uVar6);
  }
  *param_1 = iVar4;
  param_1[1] = uVar1 * 0x58 + iVar4;
  param_1[2] = uVar3 * 0x58 + iVar4;
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 6245 ; VA 0x00603cdb ; Catch_All@00603cdb */

void Catch_All_00603cdb(void)

{
  int unaff_EBP;
  
  FUN_00617010(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x20));
  FUN_0061a4a0(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x18));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6246 ; VA 0x00603d10 ; FUN_00603d10 */

undefined4 FUN_00603d10(undefined4 param_1,undefined4 *param_2)

{
  *param_2 = std::_Generic_error_category::vftable;
  param_2[1] = 3;
  return 1;
}



/* FUNCTION 6247 ; VA 0x00603d30 ; FUN_00603d30 */

void __thiscall FUN_00603d30(float *param_1,float *param_2,int *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  uint uVar3;
  float fVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179cc90;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pfStack_18 = param_1;
  uVar3 = FUN_00a6ce70(param_3);
  uVar3 = (uint)param_1[6] & uVar3;
  fVar4 = param_1[1];
  fVar5 = *(float *)((int)param_1[3] + uVar3 * 8);
  if (fVar4 != fVar5) {
    fVar4 = **(float **)((int)param_1[3] + 4 + uVar3 * 8);
    while (fVar4 != fVar5) {
      fVar4 = *(float *)((int)fVar4 + 4);
      if (((*param_3 == *(int *)((int)fVar4 + 8)) && (param_3[1] == *(int *)((int)fVar4 + 0xc))) &&
         (param_3[2] == *(int *)((int)fVar4 + 0x10))) {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_00612d60();
        FUN_01674ea0(param_4,0x20);
        *param_2 = fVar4;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_1c = param_4;
  fVar5 = *param_4;
  if (fVar4 != fVar5) {
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar4;
    **(undefined4 **)((int)fVar4 + 4) = param_4;
    fVar1 = *(float *)((int)fVar4 + 4);
    *(undefined4 *)((int)fVar4 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar3 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar3 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar3 * 8) = param_4;
  }
  else if (fVar1 == fVar4) {
    *(float **)((int)fVar5 + uVar3 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar3 * 8);
    *(float **)((int)fVar5 + 4 + uVar3 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar3 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar3 * 8) + 4);
    }
  }
  fVar4 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar4 + (double)(&DAT_018c0d90)[-((int)fVar4 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar4 < 0x200) {
      fVar4 = (float)((int)fVar4 << 3);
    }
    else if ((uint)fVar4 < 0x1fffffff) {
      fVar4 = (float)((int)fVar4 * 2);
    }
    FUN_005cb500(fVar4);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar4 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00603d30(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar4);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6248 ; VA 0x00603efc ; Catch_All@00603efc */

void Catch_All_00603efc(void)

{
  int unaff_EBP;
  
  FUN_00617040(*(undefined4 *)(unaff_EBP + 0x10));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6249 ; VA 0x00603f10 ; Catch_All@00603f10 */

void Catch_All_00603f10(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x18));
  FUN_00606a90(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}


