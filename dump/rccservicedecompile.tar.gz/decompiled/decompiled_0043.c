/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 10750 ; VA 0x0075f5b0 ; FUN_0075f5b0 */

void __thiscall
FUN_0075f5b0(int param_1,undefined4 *param_2,undefined4 *param_3,float *param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  char *pcVar7;
  uint uVar8;
  float10 fVar9;
  char acStack_c0 [32];
  undefined auStack_a0 [48];
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  uint uStack_38;
  double dStack_34;
  double dStack_2c;
  int iStack_24;
  double dStack_20;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017adc2e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_24 = param_1;
  FUN_0054ef60();
  uStack_8 = 0;
  FUN_0054ef60();
  uStack_8._0_1_ = 1;
  FUN_0054ef60();
  uStack_50 = 0;
  fStack_70 = *param_4;
  fStack_6c = param_4[1];
  fStack_68 = param_4[2];
  fStack_64 = param_4[3];
  uStack_60 = param_5;
  uStack_5c = param_6;
  uStack_58 = param_7;
  uStack_54 = param_8;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (*(int *)(param_1 + 0x20) == *(int *)(param_1 + 0x1c)) {
    FUN_0075c430(*(int *)(param_1 + 0x1c),auStack_a0);
  }
  else {
    FUN_0075d3e0(param_1 + 0x18);
    *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 0x54;
  }
  FUN_005509f0();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_38) {
    uVar8 = uStack_38 + 1;
    iVar3 = iStack_4c;
    if (0xfff < uVar8) {
      iVar3 = *(int *)(iStack_4c + -4);
      uVar8 = uStack_38 + 0x24;
      if (0x1f < (iStack_4c - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar8);
  }
  FUN_00554150(&DAT_018fa114,3);
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  FUN_00554150(&DAT_018c3838,1);
  puVar1 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_00554150(param_3,*puVar1);
  FUN_00554150(&DAT_018c3838,1);
  dStack_18 = (double)(*param_4 * DAT_018f9980);
  fVar9 = (float10)FUN_01725280(dStack_18);
  dStack_2c = (double)fVar9;
  dStack_18 = (double)(param_4[1] * DAT_018f9980);
  fVar9 = (float10)FUN_01725280(dStack_18);
  dStack_18 = (double)fVar9;
  dStack_20 = (double)(param_4[2] * DAT_018f9980);
  fVar9 = (float10)FUN_01725280(dStack_20);
  dStack_34 = (double)fVar9;
  dStack_20 = (double)(param_4[3] * DAT_018f9980);
  fVar9 = (float10)FUN_01725280(dStack_20);
  dStack_20 = (double)fVar9;
  uVar8 = 0xff;
  if ((int)fVar9 < 0x100) {
    uVar8 = (int)fVar9 & 0xff;
  }
  uVar4 = 0xff;
  if ((int)dStack_2c < 0x100) {
    uVar4 = (int)dStack_2c & 0xff;
  }
  uVar5 = 0xff;
  if ((int)dStack_18 < 0x100) {
    uVar5 = (int)dStack_18 & 0xff;
  }
  uVar6 = 0xff;
  if ((int)dStack_34 < 0x100) {
    uVar6 = (int)dStack_34 & 0xff;
  }
  FUN_005bde90(acStack_c0,&DAT_018fa11c,((uVar8 * 0x100 + uVar4) * 0x100 + uVar5) * 0x100 + uVar6);
  pcVar7 = acStack_c0;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_00554150(acStack_c0,(int)pcVar7 - (int)(acStack_c0 + 1));
  FUN_00554150(&DAT_018bfd94,1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10751 ; VA 0x0075f850 ; FUN_0075f850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_0075f850(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  char acStack_9c [32];
  undefined auStack_7c [48];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017adc58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3);
  uStack_8 = 0;
  FUN_0054ef60(param_2);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(aiStack_28);
  uStack_4c = _DAT_018e0040;
  uStack_48 = _UNK_018e0044;
  uStack_44 = _UNK_018e0048;
  uStack_40 = _UNK_018e004c;
  uStack_2c = param_8;
  uStack_3c = param_4;
  uStack_38 = param_5;
  uStack_34 = param_6;
  uStack_30 = param_7;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (*(int *)(param_1 + 0x20) == *(int *)(param_1 + 0x1c)) {
    FUN_0075c430(*(int *)(param_1 + 0x1c),auStack_7c);
  }
  else {
    FUN_0075d3e0(param_1 + 0x18);
    *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 0x54;
  }
  FUN_005509f0();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    iVar3 = aiStack_28[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  FUN_00554150(&DAT_018fa114,3);
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  FUN_00554150(&DAT_018c3838,1);
  puVar1 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_00554150(param_3,*puVar1);
  FUN_00554150(&DAT_018c3838,1);
  FUN_005bde90(acStack_9c,&DAT_018fa11c,param_8);
  pcVar4 = acStack_9c;
  do {
    cVar2 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar2 != '\0');
  FUN_00554150(acStack_9c,(int)pcVar4 - (int)(acStack_9c + 1));
  FUN_00554150(&DAT_018bfd94,1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10752 ; VA 0x0075f9e0 ; FUN_0075f9e0 */

uint FUN_0075f9e0(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x54;
  if (param_1 < 0x30c30c4) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 10753 ; VA 0x0075fa50 ; FUN_0075fa50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall FUN_0075fa50(int *param_1,int *param_2,int param_3,uint param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  int *piVar12;
  undefined auStack_1b4 [4];
  int *piStack_1b0;
  undefined auStack_1ac [4];
  int *piStack_1a8;
  undefined auStack_1a4 [4];
  int *piStack_1a0;
  undefined auStack_19c [4];
  int *piStack_198;
  uint auStack_194 [4];
  undefined4 uStack_184;
  uint uStack_180;
  undefined auStack_17c [4];
  int *piStack_178;
  char acStack_174 [4];
  undefined4 uStack_170;
  undefined uStack_16c;
  undefined2 auStack_168 [2];
  undefined4 uStack_164;
  undefined2 uStack_160;
  undefined2 auStack_15c [2];
  undefined4 uStack_158;
  undefined2 uStack_154;
  undefined2 auStack_150 [2];
  undefined4 uStack_14c;
  undefined2 uStack_148;
  undefined2 auStack_144 [2];
  undefined4 uStack_140;
  undefined2 uStack_13c;
  undefined2 auStack_138 [2];
  undefined4 uStack_134;
  undefined2 uStack_130;
  undefined2 auStack_12c [2];
  undefined4 uStack_128;
  undefined2 uStack_124;
  undefined2 auStack_120 [2];
  undefined4 uStack_11c;
  undefined2 uStack_118;
  char acStack_114 [4];
  undefined4 uStack_110;
  undefined2 uStack_10c;
  int iStack_108;
  int iStack_104;
  uint uStack_100;
  int *piStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined uStack_c0;
  uint auStack_bc [4];
  undefined4 uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined4 uStack_94;
  uint uStack_90;
  uint uStack_8c;
  undefined4 uStack_7c;
  uint uStack_78;
  int iStack_70;
  int *piStack_6c;
  uint uStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  uint uStack_4c;
  int iStack_48;
  undefined4 uStack_44;
  int iStack_40;
  uint uStack_3c;
  uint uStack_38;
  int iStack_34;
  int iStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017add4f;
  pvStack_10 = ExceptionList;
  uStack_100 = 0;
  uStack_38 = 0;
  iStack_70 = 0;
  piStack_6c = (int *)0x0;
  uStack_68 = 0;
  iStack_64 = 0;
  iStack_60 = _DAT_018fac80;
  iStack_5c = _UNK_018fac84;
  iStack_58 = _UNK_018fac88;
  iStack_54 = _UNK_018fac8c;
  uStack_8 = 0;
  uStack_7 = 0;
  iStack_34 = *(int *)(*param_1 + 0x5a8);
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  iVar4 = FUN_0078f130(param_3,param_5);
  uStack_3c = param_4 >> 1 & 0xffffff01;
  if (((char)param_5 == '\0') || ((param_3 != 0x100 && (param_3 != 0x110)))) {
    bVar3 = false;
  }
  else {
    bVar3 = true;
  }
  if (((char)uStack_3c == '\0') && (!bVar3)) {
    uStack_68 = uStack_68 | 4;
  }
  piStack_fc = (int *)FUN_0078f120(iVar4);
  piVar7 = piStack_14;
  iStack_30 = *piStack_fc;
  if (iStack_30 == 2) {
    iStack_64 = 1;
    if ((param_4 & 0x400) != 0) {
      iStack_30 = 3;
    }
  }
  else if (iStack_30 == 8) {
    iStack_64 = 6;
    if ((char)uStack_3c != '\0') {
      iStack_30 = 9;
    }
  }
  else if (iStack_30 == 10) {
    iStack_64 = 4;
  }
  iStack_108 = iVar4 * 0x3f20 + (param_4 & 0x3f1f);
  if (piStack_14[iStack_108 * 2 + 3] == 0) {
    param_5 = FUN_01674e20(0x28);
    uStack_8 = 1;
    if (param_5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_0078dea0();
    }
    uStack_8 = 0;
    FUN_0075d770(uVar5);
    FUN_00768d80(*piVar7,&iStack_70,iStack_30,param_4);
    uStack_44 = *(undefined4 *)(*piVar7 + 0x4f8);
    iVar4 = *(int *)(*piVar7 + 0x4ec);
    iStack_34 = 0;
    do {
      uStack_4c = 0;
      iStack_104 = iStack_70;
      iVar11 = *(int *)(iStack_34 + iStack_70);
      iVar8 = *(int *)(iStack_34 + 4 + iStack_70) - iVar11;
      iVar2 = iVar8 >> 0x1f;
      if (iVar8 / 0x50 + iVar2 != iVar2) {
        iStack_50 = 0;
        do {
          piVar12 = (int *)(iStack_50 + iVar11);
          iStack_40 = piVar12[1];
          if ((iStack_40 == 0) || (piVar7 = piStack_14, iStack_40 == 6)) {
            iStack_48 = *piVar12;
            acStack_114[1] = 0;
            acStack_114[0] = (iStack_48 != 2) + '\x01';
            uStack_110 = 0;
            uStack_10c = 0;
            uStack_ac = 0;
            uStack_a8 = 0xf;
            auStack_bc[0] = auStack_bc[0] & 0xffffff00;
            uStack_94 = 0;
            uStack_90 = 0xf;
            uStack_a4 = uStack_a4 & 0xffffff00;
            uStack_7c = 0;
            uStack_78 = 0xf;
            uStack_8c = uStack_8c & 0xffffff00;
            uStack_8 = 2;
            uStack_1c = 0;
            uStack_18 = 0xf;
            auStack_2c[0] = auStack_2c[0] & 0xffffff00;
            FUN_005542c0("rbxasset://textures/studs.dds",0x1d);
            uStack_8 = 3;
            FUN_009cbbb0(auStack_2c);
            uStack_8 = 4;
            uVar5 = FUN_00782480(auStack_19c,auStack_2c,2,auStack_bc,0x425c0000,0);
            _uStack_8 = CONCAT31(uStack_7,5);
            FUN_0078e550(0,uVar5,acStack_114);
            piVar7 = piStack_198;
            if (piStack_198 != (int *)0x0) {
              LOCK();
              iVar11 = piStack_198[1] + -1;
              piStack_198[1] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)*piStack_198)();
                LOCK();
                piVar1 = piVar7 + 2;
                iVar11 = *piVar1 + -1;
                *piVar1 = iVar11;
                UNLOCK();
                if (iVar11 == 0) {
                  (**(code **)(*piVar7 + 4))();
                }
              }
            }
            uStack_8 = 2;
            if (0xf < uStack_18) {
              uVar10 = uStack_18 + 1;
              uVar9 = auStack_2c[0];
              if (0xfff < uVar10) {
                uVar9 = *(uint *)(auStack_2c[0] - 4);
                uVar10 = uStack_18 + 0x24;
                if (0x1f < (auStack_2c[0] - uVar9) - 4) goto LAB_00760702;
              }
              FUN_01674ea0(uVar9,uVar10);
            }
            uStack_1c = 0;
            uStack_18 = 0xf;
            auStack_2c[0] = auStack_2c[0] & 0xffffff00;
            uStack_8 = 0;
            if (0xf < uStack_78) {
              uVar10 = uStack_78 + 1;
              uVar9 = uStack_8c;
              if (0xfff < uVar10) {
                uVar9 = *(uint *)(uStack_8c - 4);
                uVar10 = uStack_78 + 0x24;
                if (0x1f < (uStack_8c - uVar9) - 4) goto LAB_00760702;
              }
              FUN_01674ea0(uVar9,uVar10);
            }
            uStack_7c = 0;
            uStack_78 = 0xf;
            uStack_8c = uStack_8c & 0xffffff00;
            if (0xf < uStack_90) {
              uVar10 = uStack_90 + 1;
              uVar9 = uStack_a4;
              if (0xfff < uVar10) {
                uVar9 = *(uint *)(uStack_a4 - 4);
                uVar10 = uStack_90 + 0x24;
                if (0x1f < (uStack_a4 - uVar9) - 4) goto LAB_00760702;
              }
              FUN_01674ea0(uVar9,uVar10);
            }
            uStack_94 = 0;
            uStack_90 = 0xf;
            uStack_a4 = uStack_a4 & 0xffffff00;
            if (0xf < uStack_a8) {
              uVar10 = uStack_a8 + 1;
              uVar9 = auStack_bc[0];
              if (0xfff < uVar10) {
                uVar9 = *(uint *)(auStack_bc[0] - 4);
                uVar10 = uStack_a8 + 0x24;
                if (0x1f < (auStack_bc[0] - uVar9) - 4) goto LAB_00760702;
              }
              FUN_01674ea0(uVar9,uVar10);
            }
            piVar1 = piStack_fc;
            FUN_0078e4a0(2,piStack_fc + 1,0x40);
            switch(iStack_30) {
            case 0:
            case 1:
              auStack_150[0] = 2;
              uStack_14c = 0;
              uStack_148 = 0;
              uStack_ac = 0;
              uStack_a8 = 0xf;
              auStack_bc[0] = auStack_bc[0] & 0xffffff00;
              uStack_94 = 0;
              uStack_90 = 0xf;
              uStack_a4 = uStack_a4 & 0xffffff00;
              uStack_7c = 0;
              uStack_78 = 0xf;
              uStack_8c = uStack_8c & 0xffffff00;
              uStack_8 = 7;
              uStack_1c = 0;
              uStack_18 = 0xf;
              auStack_2c[0] = auStack_2c[0] & 0xffffff00;
              FUN_005542c0("rbxasset://textures/plastic/diffuse.dds",0x27);
              uStack_8 = 8;
              FUN_009cbbb0(auStack_2c);
              uStack_8 = 9;
              uVar5 = FUN_00782480(auStack_1ac,auStack_2c,2,auStack_bc,0x425c0000,0);
              _uStack_8 = CONCAT31(uStack_7,10);
              FUN_0078e550(3,uVar5,auStack_150);
              piVar7 = piStack_1a8;
              if (piStack_1a8 != (int *)0x0) {
                LOCK();
                iVar11 = piStack_1a8[1] + -1;
                piStack_1a8[1] = iVar11;
                UNLOCK();
                if (iVar11 == 0) {
                  (**(code **)*piStack_1a8)();
                  LOCK();
                  piVar12 = piVar7 + 2;
                  iVar11 = *piVar12 + -1;
                  *piVar12 = iVar11;
                  UNLOCK();
                  if (iVar11 == 0) {
                    (**(code **)(*piVar7 + 4))();
                  }
                }
              }
              uStack_8 = 7;
              if (0xf < uStack_18) {
                uVar10 = uStack_18 + 1;
                uVar9 = auStack_2c[0];
                if (0xfff < uVar10) {
                  uVar9 = *(uint *)(auStack_2c[0] - 4);
                  uVar10 = uStack_18 + 0x24;
                  if (0x1f < (auStack_2c[0] - uVar9) - 4) goto LAB_00760702;
                }
                FUN_01674ea0(uVar9,uVar10);
              }
              uStack_1c = 0;
              uStack_18 = 0xf;
              auStack_2c[0] = auStack_2c[0] & 0xffffff00;
              FUN_00637950();
              auStack_15c[0] = 2;
              uStack_158 = 0;
              uStack_154 = 0;
              uStack_ac = 0;
              uStack_a8 = 0xf;
              auStack_bc[0] = auStack_bc[0] & 0xffffff00;
              uStack_94 = 0;
              uStack_90 = 0xf;
              uStack_a4 = uStack_a4 & 0xffffff00;
              uStack_7c = 0;
              uStack_78 = 0xf;
              uStack_8c = uStack_8c & 0xffffff00;
              uStack_8 = 0xb;
              uStack_1c = 0;
              uStack_18 = 0xf;
              auStack_2c[0] = auStack_2c[0] & 0xffffff00;
              FUN_005542c0("rbxasset://textures/plastic/normal.dds",0x26);
              uStack_8 = 0xc;
              FUN_009cbbb0(auStack_2c);
              uStack_8 = 0xd;
              uVar5 = FUN_00782480(auStack_1a4,auStack_2c,5,auStack_bc,0x425c0000,0);
              _uStack_8 = CONCAT31(uStack_7,0xe);
              FUN_0078e550(4,uVar5,auStack_15c);
              piVar7 = piStack_1a0;
              if (piStack_1a0 != (int *)0x0) {
                LOCK();
                iVar11 = piStack_1a0[1] + -1;
                piStack_1a0[1] = iVar11;
                UNLOCK();
                if (iVar11 == 0) {
                  (**(code **)*piStack_1a0)();
                  LOCK();
                  piVar12 = piVar7 + 2;
                  iVar11 = *piVar12 + -1;
                  *piVar12 = iVar11;
                  UNLOCK();
                  if (iVar11 == 0) {
                    (**(code **)(*piVar7 + 4))();
                  }
                }
              }
              uStack_8 = 0xb;
              if (0xf < uStack_18) {
                uVar10 = uStack_18 + 1;
                uVar9 = auStack_2c[0];
                if (0xfff < uVar10) {
                  uVar9 = *(uint *)(auStack_2c[0] - 4);
                  uVar10 = uStack_18 + 0x24;
                  if (0x1f < (auStack_2c[0] - uVar9) - 4) goto LAB_00760702;
                }
                FUN_01674ea0(uVar9,uVar10);
              }
              uStack_1c = 0;
              uStack_18 = 0xf;
              auStack_2c[0] = auStack_2c[0] & 0xffffff00;
              FUN_00637950();
              auStack_168[0] = 1;
              uStack_164 = 0;
              uStack_160 = 0;
              uStack_ac = 0;
              uStack_a8 = 0xf;
              auStack_bc[0] = auStack_bc[0] & 0xffffff00;
              uStack_94 = 0;
              uStack_90 = 0xf;
              uStack_a4 = uStack_a4 & 0xffffff00;
              uStack_7c = 0;
              uStack_78 = 0xf;
              uStack_8c = uStack_8c & 0xffffff00;
              uStack_100 = uStack_38 | 2;
              uStack_8 = 0x10;
              uStack_1c = 0;
              uStack_18 = 0xf;
              auStack_2c[0] = auStack_2c[0] & 0xffffff00;
              uStack_38 = uStack_100;
              FUN_0058a190(DAT_01d60c08 + 0x28);
              FUN_00554150("rbxasset://textures/plastic/normaldetail",0x28);
              puVar6 = &DAT_01d60bf8;
              if (0xf < DAT_01d60c0c) {
                puVar6 = DAT_01d60bf8;
              }
              FUN_00554150(puVar6,DAT_01d60c08);
              FUN_0054ef60(auStack_2c);
              uStack_8 = 0x11;
              FUN_009cbbb0(auStack_194);
              uStack_8 = 0x12;
              uVar5 = FUN_00782480(auStack_1b4,auStack_194,5,auStack_bc,0x425c0000,0);
              _uStack_8 = CONCAT31(uStack_7,0x13);
              FUN_0078e550(8,uVar5,auStack_168);
              piVar7 = piStack_1b0;
              if (piStack_1b0 != (int *)0x0) {
                LOCK();
                iVar11 = piStack_1b0[1] + -1;
                piStack_1b0[1] = iVar11;
                UNLOCK();
                if (iVar11 == 0) {
                  (**(code **)*piStack_1b0)();
                  LOCK();
                  piVar12 = piVar7 + 2;
                  iVar11 = *piVar12 + -1;
                  *piVar12 = iVar11;
                  UNLOCK();
                  if (iVar11 == 0) {
                    (**(code **)(*piVar7 + 4))();
                  }
                }
              }
              uStack_8 = 0x10;
              if (0xf < uStack_180) {
                uVar10 = uStack_180 + 1;
                uVar9 = auStack_194[0];
                if (0xfff < uVar10) {
                  uVar9 = *(uint *)(auStack_194[0] - 4);
                  uVar10 = uStack_180 + 0x24;
                  if (0x1f < (auStack_194[0] - uVar9) - 4) goto LAB_00760702;
                }
                FUN_01674ea0(uVar9,uVar10);
              }
              uStack_38 = uStack_38 & 0xfffffffd;
              uStack_184 = 0;
              uStack_180 = 0xf;
              auStack_194[0] = auStack_194[0] & 0xffffff00;
              uStack_8 = 0xf;
              if (0xf < uStack_18) {
                uVar10 = uStack_18 + 1;
                uVar9 = auStack_2c[0];
                if (0xfff < uVar10) {
                  uVar9 = *(uint *)(auStack_2c[0] - 4);
                  uVar10 = uStack_18 + 0x24;
                  if (0x1f < (auStack_2c[0] - uVar9) - 4) {
LAB_00760702:
                    /* WARNING: Subroutine does not return */
                    FUN_017167a3();
                  }
                }
                FUN_01674ea0(uVar9,uVar10);
              }
              uStack_8 = 0;
              FUN_00637950();
              piVar7 = piStack_14;
              break;
            case 2:
              if ((char)uStack_3c == '\0') {
                uStack_e8 = 0x1000100;
                uStack_ec = 0xf;
                uStack_e4 = 0;
                FUN_0078e480(&uStack_ec);
                piVar7 = piStack_14;
              }
              else {
                uStack_dc = 0x3010304;
                uStack_e0 = 0xf;
                uStack_d8 = 0;
                FUN_0078e480(&uStack_e0);
                piVar7 = piStack_14;
              }
              break;
            case 3:
              piVar7 = piStack_14;
              if ((char)uStack_3c == '\0') {
                uStack_f4 = 0x1000100;
                uStack_f8 = 0xf;
                uStack_f0 = 0;
                FUN_0078e480(&uStack_f8);
                piVar7 = piStack_14;
              }
              break;
            default:
              iStack_40 = 0;
              piVar7 = piStack_14 + 0x147768;
              if (iStack_30 != 5) {
                piVar7 = (int *)0x0;
              }
              if (iStack_48 == 2) {
                FUN_007686a0();
                piVar7 = piStack_14;
              }
              else {
                FUN_00767940(*piStack_14,piVar1,piVar12,param_3,piVar7);
                piVar7 = piStack_14;
              }
              break;
            case 8:
            case 9:
              if ((char)uStack_3c != '\0') {
                uStack_c4 = 0x60400;
                uStack_c8 = 0xf;
                uStack_c0 = 0;
                FUN_0078e480(&uStack_c8);
              }
              piVar7 = piStack_14;
              if (iStack_48 == 0) {
                uStack_cc = 0;
                uStack_d0 = 0x1000100;
                uStack_d4 = 0xf;
                FUN_0078e480(&uStack_d4);
                param_5 = (uint)CONCAT21(0x104,(char)param_5);
                FUN_0078e510((int)&param_5 + 1);
                auStack_120[0] = 1;
                uStack_11c = 0;
                uStack_118 = 0;
                uVar5 = FUN_00798be0();
                FUN_0078e550(9,uVar5,auStack_120);
                auStack_12c[0] = 0x100;
                uStack_128 = 0;
                uStack_124 = 0;
                uVar5 = FUN_00798fd0();
                FUN_0078e550(10,uVar5,auStack_12c);
              }
              else if (iStack_48 == 2) {
                FUN_007686a0(*piStack_14,piVar1,piVar12,0x620,0);
                break;
              }
              piVar7 = piStack_14;
              FUN_00767940(*piStack_14,piVar1,piVar12,0x620,0);
              break;
            case 10:
              auStack_138[0] = 2;
              uStack_134 = 0;
              uStack_130 = 0;
              FUN_007735a0(iVar4 + 0x34,3);
              uStack_8 = 6;
              FUN_0078e550(3,auStack_17c,auStack_138);
              piVar7 = piStack_178;
              uStack_8 = 0;
              if (piStack_178 != (int *)0x0) {
                LOCK();
                iVar11 = piStack_178[1] + -1;
                piStack_178[1] = iVar11;
                UNLOCK();
                if (iVar11 == 0) {
                  (**(code **)*piStack_178)();
                  LOCK();
                  piVar12 = piVar7 + 2;
                  iVar11 = *piVar12 + -1;
                  *piVar12 = iVar11;
                  UNLOCK();
                  if (iVar11 == 0) {
                    (**(code **)(*piVar7 + 4))();
                  }
                }
              }
              acStack_174[1] = 0;
              uStack_170 = 0;
              acStack_174[0] = (iStack_40 != 0) + '\x01';
              uStack_16c = 0;
              FUN_0078e530(acStack_174);
              piVar7 = piStack_14;
              if (iStack_48 == 0) {
                auStack_144[0] = 0x100;
                uStack_140 = 0;
                uStack_13c = 0;
                uVar5 = FUN_00798fd0();
                FUN_0078e550(10,uVar5,auStack_144);
                piVar7 = piStack_14;
              }
            }
          }
          uStack_4c = uStack_4c + 1;
          iStack_50 = iStack_50 + 0x50;
          iVar11 = *(int *)(iStack_34 + iStack_104);
        } while (uStack_4c < (uint)((*(int *)(iStack_34 + 4 + iStack_104) - iVar11) / 0x50));
      }
      iStack_34 = iStack_34 + 0xc;
    } while (iStack_34 < 0x24);
    if (iStack_30 == 10) {
      *(undefined4 *)(iStack_70 + 0x24) = 1;
    }
    if (piStack_6c != (int *)0x0) {
      LOCK();
      piStack_6c[1] = piStack_6c[1] + 1;
      UNLOCK();
    }
    piVar7[iStack_108 * 2 + 3] = iStack_70;
    piVar12 = (int *)piVar7[iStack_108 * 2 + 4];
    piVar7[iStack_108 * 2 + 4] = (int)piStack_6c;
    piVar7 = piStack_6c;
  }
  else {
    piVar7 = (int *)piStack_14[iStack_108 * 2 + 4];
    piVar12 = piStack_6c;
    iStack_70 = piStack_14[iStack_108 * 2 + 3];
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      iStack_70 = piStack_14[iStack_108 * 2 + 3];
      piVar7 = (int *)piStack_14[iStack_108 * 2 + 4];
    }
  }
  piStack_6c = piVar7;
  if (piVar12 != (int *)0x0) {
    LOCK();
    iVar4 = piVar12[1] + -1;
    piVar12[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar12)();
      LOCK();
      piVar7 = piVar12 + 2;
      iVar4 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar12 + 4))();
      }
    }
  }
  param_2[1] = (int)piStack_6c;
  *param_2 = iStack_70;
  param_2[2] = uStack_68;
  param_2[3] = iStack_64;
  param_2[4] = iStack_60;
  param_2[5] = iStack_5c;
  param_2[6] = iStack_58;
  param_2[7] = iStack_54;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10754 ; VA 0x00760730 ; FUN_00760730 */

uint FUN_00760730(uint param_1,int param_2,int *param_3,undefined *param_4,char param_5)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  float10 fVar7;
  
  *param_4 = 0;
  iVar3 = FUN_00b08820();
  if ((param_3 != (int *)0x0) && (*param_3 != 0)) {
    cVar2 = FUN_01154d90(param_2);
    if ((cVar2 != '\0') && (bVar1 = true, iVar3 == 0)) goto LAB_00760770;
  }
  bVar1 = false;
LAB_00760770:
  if ((param_5 == '\0') || (DAT_01eeeba8 != '\0')) {
    uVar4 = 0;
  }
  else {
    uVar4 = 0x1000;
  }
  uVar4 = param_1 & 0xff | uVar4;
  if (param_3 != (int *)0x0) {
    iVar5 = FUN_01154940(param_2);
    if (iVar5 == 0) {
      cVar2 = FUN_01154e00(param_2);
      if (cVar2 != '\0') {
        uVar4 = uVar4 | 0x80;
      }
    }
  }
  if (bVar1) {
    uVar4 = uVar4 | 0x60;
    if (*(int *)(*param_3 + 0x228) == 0) {
      iVar5 = FUN_01154940(param_2);
      if ((iVar5 == 1) && (param_3[0x2b] != 0)) {
        *param_4 = 1;
      }
    }
    iVar5 = FUN_01154940(param_2);
    if (iVar5 == 0) {
      *param_4 = 1;
    }
  }
  if (iVar3 == 0) {
    iVar3 = FUN_00b084e0();
    if (iVar3 == 0x630) {
      uVar4 = uVar4 | 0x800;
    }
  }
  else if (*(int *)(iVar3 + 0xb4) == 1) {
    if (DAT_01d61b8c == '\0') {
      uVar4 = uVar4 | 2;
    }
    else {
      fVar7 = (float10)FUN_00b08910();
      uVar4 = uVar4 | (uint)((float)fVar7 <= 0.0) * 2 + 2;
    }
  }
  fVar7 = (float10)FUN_00b08910();
  if ((float)fVar7 <= 0.0) {
    if (bVar1) {
      uVar4 = uVar4 | 4;
    }
  }
  else {
    uVar4 = uVar4 | 2;
  }
  if (DAT_01d6c814 != '\0') {
    iVar3 = *(int *)(param_2 + 0xc);
    iVar6 = FUN_00cfb1a0();
    iVar5 = 0;
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      iVar5 = param_2;
    }
    if ((iVar5 != 0) && (*(char *)(iVar5 + 0x192) != '\0')) {
      uVar4 = uVar4 | 0x2000;
    }
  }
  return uVar4;
}



/* FUNCTION 10755 ; VA 0x007608c0 ; FUN_007608c0 */

int * FUN_007608c0(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5,
                  int *param_6)

{
  int iVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  int *piVar9;
  undefined auStack_128 [120];
  undefined auStack_b0 [24];
  undefined auStack_98 [24];
  char acStack_80 [4];
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  undefined auStack_6c [8];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined auStack_54 [8];
  int iStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int iStack_3c;
  int *piStack_38;
  int iStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017addeb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_0170d1f0(auStack_128,0,0x78);
  if ((param_5 & 0x40) != 0) {
    FUN_00762fa0(auStack_128,param_4);
  }
  FUN_007635d0(acStack_80,param_3,param_4,auStack_128);
  if (acStack_80[0] == '\0') {
    iStack_4c = 0;
    piStack_48 = (int *)0x0;
    piStack_44 = (int *)0x0;
    piStack_40 = (int *)0x0;
    iStack_3c = 0;
    piStack_38 = (int *)0x0;
    iStack_34 = 0;
    piStack_30 = (int *)0x0;
    FUN_0075d6a0(param_1,&iStack_3c,&iStack_4c);
    goto LAB_00760d97;
  }
  piVar9 = (int *)0x0;
  if (*(int *)(*param_4 + 0x228) == 0) {
    iVar4 = FUN_01154940(param_3);
    if (((iVar4 == 3) || (iVar4 == 2)) || (iVar4 == 1)) {
      piStack_1c = (int *)FUN_01154a00(param_3);
      iVar4 = param_4[0x35];
    }
    else {
      iVar4 = param_4[0x35];
      piStack_1c = (int *)iVar4;
    }
    if (piStack_1c == (int *)iVar4) {
LAB_00760a5e:
      bVar2 = true;
    }
    else {
      if ((piStack_1c != (int *)0x0) && (iVar4 != 0)) {
        uVar5 = FUN_00cff3a0(auStack_b0);
        uStack_8 = 0;
        uStack_18 = 2;
        uVar6 = FUN_00cff3a0(auStack_98);
        uStack_8 = 1;
        uStack_14 = 6;
        uStack_18 = 6;
        cVar3 = FUN_009cbaa0(uVar6,uVar5);
        if (cVar3 != '\0') {
          uVar5 = FUN_00cff560(auStack_54);
          uStack_8 = 2;
          uStack_18 = 0xe;
          uVar6 = FUN_00cff560(auStack_6c);
          uStack_8 = 3;
          uStack_14 = 0x1e;
          uStack_18 = 0x1e;
          cVar3 = FUN_009cbaa0(uVar6,uVar5);
          if (cVar3 != '\0') goto LAB_00760a5e;
        }
      }
      bVar2 = false;
    }
    if ((uStack_14 & 0x10) != 0) {
      uStack_18 = uStack_14 & 0xffffffef;
      uStack_14 = uStack_18;
      FUN_005507b0();
    }
    if ((uStack_14 & 8) != 0) {
      uStack_18 = uStack_14 & 0xfffffff7;
      uStack_14 = uStack_18;
      FUN_005507b0();
    }
    if ((uStack_14 & 4) != 0) {
      uStack_18 = uStack_14 & 0xfffffffb;
      uStack_14 = uStack_18;
      FUN_005507b0();
    }
    uStack_8 = 0xffffffff;
    piVar9 = piStack_1c;
    if ((uStack_14 & 2) != 0) {
      uStack_18 = uStack_14 & 0xfffffffd;
      uStack_14 = uStack_18;
      FUN_005507b0();
      piVar9 = piStack_1c;
    }
LAB_00760ad9:
    if (bVar2) goto LAB_00760ae1;
    piVar9 = (int *)FUN_00760db0(&uStack_64,param_2,param_4,auStack_128,piVar9);
    uVar7 = uStack_14 | 0x40;
  }
  else {
    if (*(int *)(*param_4 + 0x228) != 1) {
      bVar2 = false;
      goto LAB_00760ad9;
    }
    uStack_14 = 0;
LAB_00760ae1:
    if (*param_4 == *param_6) {
      FUN_00779e30(&iStack_2c,param_6 + 1);
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piStack_28[1] = piStack_28[1] + 1;
        UNLOCK();
      }
      piStack_30 = (int *)param_6[2];
      iStack_3c = iStack_2c;
      piStack_38 = piStack_28;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        piStack_30[1] = piStack_30[1] + 1;
        UNLOCK();
        piStack_30 = (int *)param_6[2];
      }
      iStack_34 = param_6[1];
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_28[1] + -1;
        piStack_28[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar9 = piStack_28 + 2;
          iVar4 = *piVar9;
          *piVar9 = *piVar9 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_28 + 4))();
          }
        }
      }
    }
    else {
      FUN_00760db0(&iStack_4c,param_2,param_4,auStack_128,piVar9);
      iStack_24 = *param_4;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        piStack_40[1] = piStack_40[1] + 1;
        UNLOCK();
      }
      piStack_1c = piStack_40;
      iStack_20 = (int)piStack_44;
      FUN_0075c2e0(&iStack_24);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar9 = piStack_1c + 2;
          iVar4 = *piVar9;
          *piVar9 = *piVar9 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      iStack_3c = iStack_4c;
      piStack_38 = piStack_48;
      iStack_34 = (int)piStack_44;
      iStack_4c = 0;
      piStack_48 = (int *)0x0;
      piStack_30 = piStack_40;
      piStack_44 = (int *)0x0;
      piStack_40 = (int *)0x0;
      FUN_0056b650();
    }
    piVar9 = &iStack_3c;
    uVar7 = uStack_14 | 0xa0;
  }
  iVar4 = *piVar9;
  iVar1 = piVar9[1];
  *piVar9 = 0;
  piVar9[1] = 0;
  piStack_44 = (int *)piVar9[2];
  piStack_28 = piStack_44;
  piStack_40 = (int *)piVar9[3];
  piStack_1c = piStack_40;
  piVar9[2] = 0;
  piVar9[3] = 0;
  uStack_8 = 5;
  iStack_4c = iVar4;
  piStack_48 = (int *)iVar1;
  if ((uVar7 & 0x40) != 0) {
    uStack_14 = uVar7 & 0xffffffbf;
    FUN_0056b650();
    uVar7 = uStack_14;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if ((uVar7 & 0x20) != 0) {
    FUN_0056b650();
  }
  iVar8 = FUN_007631f0(param_3,param_4,auStack_128);
  if (((iVar4 == 0) || (*(int *)(iVar4 + 8) != 3)) &&
     ((-1 < iVar8 && (iVar8 = FUN_011548e0(param_3), iVar8 != 0)))) {
    iStack_20 = 0;
    piStack_1c = (int *)0x0;
    iStack_2c = 0;
    piStack_28 = (int *)0x0;
    uStack_64 = 0;
    uStack_60 = 0;
    uStack_5c = 0;
    uStack_58 = 0;
    uVar5 = FUN_0075d710(&iStack_3c,&iStack_2c,&iStack_20);
    FUN_0075d6a0(param_1,uVar5,&uStack_64);
    FUN_0056b650();
    FUN_00550b30();
    FUN_00550b30();
  }
  else {
    *param_1 = 0;
    param_1[1] = 0;
    if (iVar1 != 0) {
      LOCK();
      *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
      UNLOCK();
    }
    *param_1 = iVar4;
    param_1[1] = iVar1;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      *(int *)((int)piStack_1c + 4) = *(int *)((int)piStack_1c + 4) + 1;
      UNLOCK();
    }
    param_1[2] = (int)piStack_28;
    param_1[3] = (int)piStack_1c;
    param_1[4] = iStack_7c;
    param_1[5] = iStack_78;
    param_1[6] = iStack_74;
    param_1[7] = iStack_70;
  }
LAB_00760d97:
  FUN_0056b650();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10756 ; VA 0x00760db0 ; FUN_00760db0 */

undefined4 *
FUN_00760db0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined uVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 ****ppppuVar9;
  uint uVar10;
  uint uVar11;
  undefined auStack_d0 [76];
  uint auStack_84 [4];
  undefined4 uStack_74;
  uint uStack_70;
  undefined auStack_6c [4];
  int *piStack_68;
  undefined4 uStack_64;
  int *piStack_60;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ade4e;
  pvStack_10 = ExceptionList;
  uStack_34 = 0;
  uStack_30 = 0xf;
  apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
  iStack_2c = 0;
  iStack_28 = 0;
  iStack_24 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0058a190(0x400);
  if ((uint)((iStack_24 - iStack_2c) / 0x54) < 0x10) {
    FUN_0075f070(0x10);
  }
  FUN_00554150("TexComp",7);
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(*param_3 + 0x30c);
  uStack_8._0_1_ = 4;
  uVar6 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (*(int *)(*param_3 + 0x228) == 0) {
    uStack_20 = 0x44aaaaab;
    uStack_1c = 0x44000000;
    FUN_007668d0(apppuStack_44,param_3,param_4,param_5);
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = auStack_5c[0] & 0xffffff00;
    FUN_005542c0("Clothes",7);
    uStack_8._0_1_ = 5;
    FUN_00d10320(*param_3,auStack_5c);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (0xf < uStack_48) {
      uVar10 = uStack_48 + 1;
      uVar11 = auStack_5c[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_5c[0] - 4);
        uVar10 = uStack_48 + 0x24;
        if (0x1f < (auStack_5c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = auStack_5c[0] & 0xffffff00;
    puVar7 = (undefined4 *)
             FUN_00778d90(auStack_6c,apppuStack_44,auStack_d0,0x400,0x200,&uStack_20,&iStack_2c,
                          auStack_84);
    piVar1 = piStack_14;
    uStack_18 = *puVar7;
    piVar2 = (int *)puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        puVar7 = (undefined4 *)*piStack_14;
        piStack_14 = piVar2;
        (*(code *)*puVar7)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar3 = *piVar2 + -1;
        *piVar2 = iVar3;
        UNLOCK();
        piVar2 = piStack_14;
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
          piVar2 = piStack_14;
        }
      }
    }
  }
  else {
    iVar3 = iStack_2c;
    iVar4 = iStack_28;
    uStack_8._0_1_ = uVar6;
    if (*(int *)(*param_3 + 0x228) != 1) goto joined_r0x00761090;
    uStack_20 = 0x44800000;
    uStack_1c = 0x44800000;
    FUN_00765150(apppuStack_44,param_3,param_4,param_5);
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = auStack_5c[0] & 0xffffff00;
    FUN_005542c0("Clothes",7);
    uStack_8._0_1_ = 8;
    FUN_00d10320(*param_3,auStack_5c);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    FUN_005507b0();
    uVar8 = FUN_00778d90(auStack_6c,apppuStack_44,auStack_d0,0x400,0x400,&uStack_20,&iStack_2c,
                         auStack_84);
    FUN_005587e0(uVar8);
    piVar2 = piStack_14;
  }
  piStack_14 = piVar2;
  if (piStack_68 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_68[1] + -1;
    piStack_68[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_68)();
      LOCK();
      iVar3 = piStack_68[2] + -1;
      piStack_68[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_68 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 4;
  FUN_00637950();
  iVar3 = iStack_2c;
  iVar4 = iStack_28;
joined_r0x00761090:
  for (; iVar5 = iStack_28, iVar3 != iStack_28; iVar3 = iVar3 + 0x54) {
    iStack_28 = iVar4;
    FUN_009c7190(iVar3);
    FUN_009c71c0(iVar3 + 0x18);
    iVar4 = iStack_28;
    iStack_28 = iVar5;
  }
  iStack_28 = iVar4;
  if ((undefined4 ****)(*param_3 + 0x30c) != apppuStack_44) {
    ppppuVar9 = apppuStack_44;
    if (0xf < uStack_30) {
      ppppuVar9 = (undefined4 ****)apppuStack_44[0];
    }
    FUN_005542c0(ppppuVar9,uStack_34);
  }
  FUN_00779e30(&uStack_64,&uStack_18);
  *param_1 = 0;
  param_1[1] = 0;
  if (piStack_60 != (int *)0x0) {
    LOCK();
    piStack_60[1] = piStack_60[1] + 1;
    UNLOCK();
  }
  *param_1 = uStack_64;
  param_1[1] = piStack_60;
  param_1[2] = 0;
  param_1[3] = 0;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piStack_14[1] = piStack_14[1] + 1;
    UNLOCK();
  }
  param_1[2] = uStack_18;
  param_1[3] = piStack_14;
  if (piStack_60 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_60[1] + -1;
    piStack_60[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_60)();
      LOCK();
      iVar3 = piStack_60[2] + -1;
      piStack_60[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_60 + 4))();
      }
    }
  }
  if (0xf < uStack_70) {
    uVar10 = uStack_70 + 1;
    uVar11 = auStack_84[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_84[0] - 4);
      uVar10 = uStack_70 + 0x24;
      if (0x1f < (auStack_84[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  piVar2 = piStack_14;
  uStack_74 = 0;
  uStack_70 = 0xf;
  auStack_84[0] = auStack_84[0] & 0xffffff00;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0075df00();
  if (0xf < uStack_30) {
    uVar11 = uStack_30 + 1;
    ppppuVar9 = (undefined4 ****)apppuStack_44[0];
    if (0xfff < uVar11) {
      ppppuVar9 = (undefined4 ****)apppuStack_44[0][-1];
      uVar11 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar11);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10757 ; VA 0x00761230 ; FUN_00761230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall
FUN_00761230(int *param_1,undefined4 param_2,int *param_3,uint param_4,int *param_5,uint param_6)

{
  ushort uVar1;
  ushort uVar2;
  ushort uVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  int iVar10;
  int *piStack_158;
  char *pcStack_154;
  int *piStack_150;
  undefined auStack_f8 [32];
  undefined auStack_d8 [16];
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined uStack_c0;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined uStack_a8;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined auStack_8c [8];
  uint uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  int *apiStack_6c [2];
  undefined auStack_64 [8];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int aiStack_4c [4];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [8];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017adedf;
  pvStack_10 = ExceptionList;
  iStack_14 = *(int *)(*param_1 + 0x4ec);
  piStack_18 = param_1;
  if (param_4 != 0) {
    iVar7 = *(int *)(param_4 + 0xc);
    piStack_150 = (int *)0x761275;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00cffd50();
    uVar1 = *(ushort *)(iVar7 + 0x1d8);
    piStack_150 = (int *)DAT_0213cd74;
    uVar2 = *(ushort *)(iVar5 + 0x1d8);
    uVar3 = *(ushort *)(iVar5 + 0x1da);
    pcStack_154 = (char *)param_4;
    piStack_158 = (int *)0x7612ad;
    uVar6 = FUN_00d10320();
    uStack_8 = 0;
    piStack_150 = (int *)(param_6 |
                         (-(uint)((uint)uVar3 < (uint)uVar1 - (uint)uVar2) & 0xfffffff8) + 0x10);
    FUN_00782480(&piStack_158,param_4 + 0x74,4,uVar6,0x425c0000,0);
    FUN_00761f10(param_2,param_4 + 0x74);
    piStack_150 = (int *)0x7612ec;
    FUN_00637950();
    ExceptionList = pvStack_10;
    return param_2;
  }
  piStack_150 = (int *)0x76130a;
  ExceptionList = &pvStack_10;
  piStack_150 = (int *)FUN_00b08820();
  if (piStack_150 != (int *)0x0) {
    pcStack_154 = (char *)param_6;
    piStack_158 = param_3;
    FUN_00761a90(param_2);
    ExceptionList = pvStack_10;
    return param_2;
  }
  param_4 = param_6;
  if ((param_5 != (int *)0x0) && ((param_6 & 0x20) != 0)) {
    piStack_150 = param_1 + 0x147765;
    pcStack_154 = (char *)param_6;
    piStack_158 = param_5;
    FUN_007608c0(apiStack_6c,*param_1,param_3);
    uStack_8 = 1;
    piVar8 = (int *)&DAT_01eb1b04;
    if (apiStack_6c[0] != (int *)0x0) {
      piVar8 = apiStack_6c[0];
    }
    if (*piVar8 != 0) {
      piStack_150 = &uStack_2c;
      pcStack_154 = (char *)0x0;
      piStack_158 = (int *)0x0;
      uStack_1c = 0;
      piStack_18 = (int *)0x0;
      uStack_2c = _DAT_018fac80;
      uStack_28 = _UNK_018fac84;
      uStack_24 = _UNK_018fac88;
      uStack_20 = _UNK_018fac8c;
      FUN_0075dc20(&uStack_1c);
      uStack_8._0_1_ = 2;
      piStack_150 = (int *)0x7613bf;
      FUN_00550b30();
      if (DAT_01d60be0 == '\0') {
LAB_007614ee:
        piStack_150 = (int *)auStack_64;
        pcStack_154 = (char *)0x7614ff;
        uVar6 = FUN_00779e70();
        piStack_150 = (int *)param_6;
        FUN_00557fc0(apiStack_6c);
        piStack_150 = (int *)FUN_00761f10(auStack_f8,uVar6);
        pcStack_154 = (char *)0x76152e;
        FUN_0075e350();
        piStack_150 = (int *)0x761539;
        FUN_00550b30();
      }
      else {
        piStack_150 = (int *)*param_5;
        pcStack_154 = (char *)0x7613d3;
        cVar4 = FUN_00764820();
        if (cVar4 == '\0') goto LAB_007614ee;
        uStack_24 = 0;
        uStack_20 = 0xf;
        auStack_34[0] = 0;
        piStack_150 = (int *)0x0;
        pcStack_154 = "Left";
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        piStack_158 = (int *)0x76140b;
        iVar7 = FUN_0058eea0();
        if (iVar7 == -1) {
          piStack_150 = (int *)0x0;
          pcStack_154 = "Right";
          piStack_158 = (int *)0x761428;
          iVar7 = FUN_0058eea0();
          if (iVar7 != -1) {
            pcStack_154 = "R";
            goto LAB_00761434;
          }
        }
        else {
          pcStack_154 = "L";
LAB_00761434:
          piStack_150 = (int *)0x1;
          piStack_158 = (int *)0x76143c;
          FUN_005542c0();
        }
        piStack_150 = param_3;
        pcStack_154 = (char *)0x761446;
        piStack_150 = (int *)FUN_01154940();
        pcStack_154 = (char *)aiStack_4c;
        piStack_158 = (int *)0x761450;
        pcStack_154 = (char *)FUN_005958a0();
        piStack_150 = *(int **)((int)pcStack_154 + 0x10);
        uStack_8._0_1_ = 4;
        if (0xf < *(uint *)((int)pcStack_154 + 0x14)) {
          pcStack_154 = *(char **)pcStack_154;
        }
        piStack_158 = (int *)0x76146c;
        FUN_00554150();
        uStack_8._0_1_ = 3;
        piStack_150 = (int *)0x761478;
        FUN_005507b0();
        piStack_150 = (int *)auStack_34;
        pcStack_154 = auStack_64;
        piStack_158 = (int *)0x76148d;
        pcStack_154 = (char *)FUN_00779e70();
        piStack_158 = aiStack_4c;
        uVar6 = FUN_005f3cd0();
        piStack_150 = (int *)param_6;
        uStack_8._0_1_ = 5;
        FUN_00557fc0(apiStack_6c);
        piStack_150 = (int *)FUN_00761f10(auStack_f8,uVar6);
        pcStack_154 = (char *)0x7614cd;
        FUN_0075e350();
        piStack_150 = (int *)0x7614d8;
        FUN_00550b30();
        piStack_150 = (int *)0x7614e0;
        FUN_005507b0();
        uStack_8._0_1_ = 2;
        piStack_150 = (int *)0x7614ec;
        FUN_005507b0();
      }
      if (*param_5 != 0) {
        iVar7 = *(int *)(*param_5 + 0x228);
        if (iVar7 == 0) {
          piStack_150 = (int *)param_5[2];
          if (piStack_150 != (int *)0x0) goto LAB_00761579;
          piStack_150 = (int *)param_5[1];
        }
        else {
          if (iVar7 != 1) goto LAB_00761577;
          piStack_150 = (int *)param_5[2];
          if (piStack_150 != (int *)0x0) goto LAB_00761579;
          piStack_150 = (int *)param_5[1];
        }
        if (piStack_150 != (int *)0x0) goto LAB_00761579;
      }
LAB_00761577:
      piStack_150 = (int *)0x0;
LAB_00761579:
      pcStack_154 = (char *)&uStack_1c;
      piStack_158 = (int *)0x761583;
      piStack_150 = (int *)FUN_0060dcd0();
      pcStack_154 = auStack_64;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      piStack_158 = (int *)0x761596;
      FUN_00777fa0();
      piStack_150 = (int *)0x76159e;
      FUN_00550b30();
      piStack_150 = (int *)auStack_8c;
      uStack_84 = uStack_84 | 2;
      uStack_7c = uStack_5c;
      uStack_78 = uStack_58;
      uStack_74 = uStack_54;
      uStack_70 = uStack_50;
      pcStack_154 = (char *)0x7615b9;
      FUN_0075dbd0();
      piStack_150 = (int *)0x7615c4;
      FUN_00550b30();
      piStack_150 = (int *)0x7615cc;
      FUN_0056b650();
      ExceptionList = pvStack_10;
      return param_2;
    }
    uStack_8 = 0xffffffff;
    piStack_150 = (int *)0x7615f0;
    FUN_0056b650();
  }
  piStack_150 = param_3;
  pcStack_154 = (char *)0x7615f9;
  iVar7 = FUN_00d012f0();
  piStack_158 = (int *)0x761602;
  pcStack_154 = (char *)iVar7;
  piVar8 = (int *)FUN_00d01120();
  if (piVar8 != (int *)0x0) {
    if (piVar8[0x24] != 0) {
      piStack_150 = (int *)param_6;
      pcStack_154 = (char *)DAT_0213cf88;
      piStack_158 = piVar8;
      uVar6 = FUN_00d10320();
      uStack_8 = 7;
      FUN_00782480(&piStack_158,piVar8 + 0x20,2,uVar6,0x425c0000,0);
      FUN_00761f10(param_2,piVar8 + 0x20);
      piStack_150 = (int *)0x761729;
      FUN_00637950();
      ExceptionList = pvStack_10;
      return param_2;
    }
    param_4 = param_6 | 0x80;
  }
  iVar5 = param_3[3];
  piStack_150 = (int *)0x761634;
  iVar9 = FUN_00cfb1a0();
  piVar8 = (int *)0x0;
  if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
      (uint)*(ushort *)(iVar9 + 0x1da)) {
    piVar8 = param_3;
  }
  if (piVar8 != (int *)0x0) {
    if ((param_4 & 0x200) != 0) {
      piStack_150 = (int *)0x8;
      pcStack_154 = "Fallback";
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      piStack_158 = (int *)0x761690;
      FUN_005542c0();
      piStack_150 = (int *)param_4;
      uStack_8 = 8;
      FUN_007735a0(iStack_14 + 0x24,3);
      FUN_00761f10(param_2,auStack_34);
      piStack_150 = (int *)0x7616c5;
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
    if (piVar8[0x59] == 0) {
      uStack_c8 = 0;
      uStack_c4 = 0xf;
      auStack_d8[0] = 0;
      uStack_b0 = 0;
      uStack_ac = 0xf;
      uStack_c0 = 0;
      uStack_98 = 0;
      uStack_94 = 0xf;
      uStack_a8 = 0;
      piStack_150 = (int *)0x28;
      pcStack_154 = "rbxasset://textures/meshPartFallback.png";
      uStack_8 = 9;
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      piStack_158 = (int *)0x7617c3;
      FUN_005542c0();
      piStack_150 = (int *)auStack_34;
      uStack_8._0_1_ = 10;
      pcStack_154 = (char *)0x7617d0;
      FUN_009cbbb0();
      piStack_150 = (int *)0x10;
      pcStack_154 = "meshPartFallback";
      uStack_8._0_1_ = 0xb;
      uStack_3c = 0;
      uStack_38 = 0xf;
      aiStack_4c[0]._0_1_ = 0;
      piStack_158 = (int *)0x7617f8;
      FUN_005542c0();
      piStack_150 = (int *)param_4;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      FUN_00782480(&piStack_158,auStack_34,2,auStack_d8,0x425c0000,0);
      FUN_00761f10(param_2,aiStack_4c);
      piStack_150 = (int *)0x76183c;
      FUN_005507b0();
      piStack_150 = (int *)0x761844;
      FUN_005507b0();
      piStack_150 = (int *)0x76184f;
      FUN_00637950();
      ExceptionList = pvStack_10;
      return param_2;
    }
    if (piVar8[0x5f] != 0) {
      piStack_150 = (int *)param_4;
      pcStack_154 = (char *)DAT_01f04f54;
      piStack_158 = piVar8;
      uVar6 = FUN_00d10320();
      uStack_8 = 0xd;
      FUN_00782480(&piStack_158,piVar8 + 0x5b,2,uVar6,0x425c0000,0);
      FUN_00761f10(param_2,piVar8 + 0x5b);
      piStack_150 = (int *)0x7618b6;
      FUN_00637950();
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  if ((char)param_4 < '\0') {
LAB_0076192d:
    piStack_158 = (int *)0x110;
  }
  else {
    if (iVar7 != 0) {
      iVar5 = *(int *)(iVar7 + 0xc);
      piStack_150 = (int *)0x7618dd;
      iVar10 = FUN_00d0f2a0();
      iVar9 = 0;
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8) <=
          (uint)*(ushort *)(iVar10 + 0x1da)) {
        iVar9 = iVar7;
      }
      if ((iVar9 != 0) && (*(int *)(iVar9 + 0xb0) == 0)) goto LAB_0076192d;
    }
    piStack_150 = (int *)0x761911;
    piStack_158 = (int *)FUN_00b084e0();
    if (DAT_018fabd0 < (float)param_3[0x34]) {
      param_3 = (int *)CONCAT31(param_3._1_3_,1);
      goto LAB_00761936;
    }
  }
  param_3 = (int *)((uint)param_3 & 0xffffff00);
LAB_00761936:
  piStack_150 = param_3;
  pcStack_154 = (char *)param_4;
  FUN_0075fa50(param_2);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10758 ; VA 0x00761960 ; FUN_00761960 */

void __thiscall FUN_00761960(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017adeff;
  pvStack_10 = ExceptionList;
  iVar6 = param_1[0x147763];
  piVar2 = param_1 + 0x147763;
  if (iVar6 != 0) {
    iVar5 = param_1[0x147764];
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar6 = *piVar2;
      iVar5 = param_1[0x147764];
    }
    *param_2 = iVar6;
    param_2[1] = iVar5;
    return;
  }
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::_Ref_count_obj<class_RBX::Graphics::Material>::vftable;
    FUN_0078dea0();
  }
  uStack_8 = 0xffffffff;
  *piVar2 = (int)(puVar4 + 3);
  piVar3 = (int *)param_1[0x147764];
  param_1[0x147764] = puVar4;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar6 = piVar3[1] + -1;
    piVar3[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00768d80(*param_1,piVar2,0x10,0);
  iVar6 = param_1[0x147764];
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = param_1[0x147764];
  }
  *param_2 = *piVar2;
  param_2[1] = iVar6;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10759 ; VA 0x00761a90 ; FUN_00761a90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_00761a90(int *param_1,undefined4 param_2,uint param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  byte *pbVar10;
  int iVar11;
  int iStack_8c;
  int *piStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  int aiStack_6c [5];
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined uStack_30;
  byte *pbStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  uint uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar8 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017adf32;
  pvStack_10 = ExceptionList;
  uVar9 = param_3 & 0x3f1f;
  ExceptionList = &pvStack_10;
  FUN_00763960(aiStack_6c,param_4);
  uStack_8 = 0;
  pbStack_2c = (byte *)(piStack_18 + uVar9 * 0xd + 0xfc803);
  pbVar10 = pbStack_2c + *pbStack_2c + 1;
  uVar4 = FUN_0055c740(pbVar10,aiStack_6c);
  FUN_00562fc0(&param_3,uVar4,aiStack_6c,-(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
  iVar7 = _UNK_018fac8c;
  iVar3 = _UNK_018fac88;
  iVar5 = _UNK_018fac84;
  iVar11 = _DAT_018fac80;
  if (param_3 == 0) {
    uStack_50 = 0;
    uStack_4c = 0;
    uStack_48 = 0;
    uStack_54 = 0x3f800000;
    if (*(int *)(param_4 + 0xb4) != 0) {
      uStack_54 = 0;
    }
    param_3 = FUN_01674e20(0x28);
    uStack_8._0_1_ = 1;
    if (param_3 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_0078dea0();
    }
    uStack_8._0_1_ = 0;
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    FUN_0075cd20(uVar4,param_4);
    piVar1 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    iStack_8c = iStack_28;
    piStack_88 = piStack_24;
    iStack_84 = 0;
    iStack_80 = 0;
    iStack_7c = _DAT_018fac80;
    iStack_78 = _UNK_018fac84;
    iStack_74 = _UNK_018fac88;
    iStack_70 = _UNK_018fac8c;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar11 = piStack_24[1] + -1;
      piStack_24[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar11 = *piVar2 + -1;
        *piVar2 = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    if ((DAT_01d61b8c == '\0') || (iStack_20 = 0xf, ((byte)uVar8 & 6) != 4)) {
      iStack_20 = 0xe;
    }
    FUN_00768d80(*piStack_18,&iStack_8c,iStack_20,uVar8);
    iVar11 = 0;
    do {
      iVar3 = iStack_8c;
      uStack_1c = 0;
      iVar7 = *(int *)(iVar11 + 4 + iStack_8c) - *(int *)(iVar11 + iStack_8c);
      iVar5 = iVar7 >> 0x1f;
      if (iVar7 / 0x50 + iVar5 != iVar5) {
        iStack_14 = 0;
        do {
          FUN_0078e4a0(3,&uStack_54,0x10);
          if (iStack_20 == 0xf) {
            piStack_24 = *(int **)(iStack_14 + 4 + *(int *)(iVar11 + iVar3));
            if ((DAT_01d79a48 == '\0') ||
               (iVar5 = (**(code **)(**(int **)(*piStack_18 + 0x3c) + 0x40))(),
               *(char *)(iVar5 + 0x1b) == '\0')) {
              uVar6 = 0;
            }
            else {
              uVar6 = 1;
            }
            if (((DAT_01d60f80 == '\0') && (DAT_01d60f88 == '\0')) || (piStack_24 != (int *)0x3)) {
              if ((piStack_24 == (int *)&DAT_00000006) || (piStack_24 == (int *)0x0)) {
                if ((DAT_01d60f80 != '\0') || (uStack_3c = uVar6, DAT_01d60f88 != '\0')) {
                  uStack_3c = 0;
                }
                uStack_40 = 0x1000100;
                uStack_44 = 0xf;
                FUN_0078e480(&uStack_44);
                if ((DAT_01d60f80 != '\0') || (DAT_01d60f88 != '\0')) {
                  param_3 = (uint)CONCAT21(5,(undefined)param_3);
                  FUN_0078e510((int)&param_3 + 1);
                }
              }
            }
            else {
              uStack_34 = 0x1000100;
              uStack_38 = 0;
              uStack_30 = uVar6;
              FUN_0078e480(&uStack_38);
            }
          }
          uStack_1c = uStack_1c + 1;
          iStack_14 = iStack_14 + 0x50;
        } while (uStack_1c <
                 (uint)((*(int *)(iVar11 + 4 + iVar3) - *(int *)(iVar11 + iVar3)) / 0x50));
      }
      iVar5 = param_4;
      iVar11 = iVar11 + 0xc;
    } while (iVar11 < 0x24);
    FUN_00768a60(&iStack_8c,*(undefined4 *)(*piStack_18 + 0x4ec),
                 *(undefined4 *)(*piStack_18 + 0x550),param_4);
    if (*(int *)(iVar5 + 200) != 0) {
      FUN_00764960(iVar5,&iStack_8c);
    }
    iVar11 = FUN_0075e3c0(aiStack_6c);
    if (piStack_88 != (int *)0x0) {
      LOCK();
      piStack_88[1] = piStack_88[1] + 1;
      UNLOCK();
    }
    *(int *)(iVar11 + 0x18) = iStack_8c;
    piVar1 = *(int **)(iVar11 + 0x1c);
    *(int **)(iVar11 + 0x1c) = piStack_88;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar11 = piVar1[1] + -1;
      piVar1[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar11 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar11 == 1) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    *param_1 = iStack_8c;
    param_1[1] = (int)piStack_88;
    param_1[2] = iStack_84;
    iStack_8c = 0;
    piStack_88 = (int *)0x0;
    param_1[3] = iStack_80;
    param_1[4] = iStack_7c;
    param_1[5] = iStack_78;
    param_1[6] = iStack_74;
    param_1[7] = iStack_70;
    if (uStack_58 < 0x10) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar8 = uStack_58 + 1;
    iVar11 = aiStack_6c[0];
    if (0xfff < uVar8) {
      iVar11 = *(int *)(aiStack_6c[0] + -4);
      uVar8 = uStack_58 + 0x24;
      if (0x1f < (aiStack_6c[0] - iVar11) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    *param_1 = 0;
    param_1[1] = 0;
    if (*(int *)(param_3 + 0x24) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_3 + 0x24) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_1 = *(int *)(param_3 + 0x20);
    param_1[1] = *(int *)(param_3 + 0x24);
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = iVar11;
    param_1[5] = iVar5;
    param_1[6] = iVar3;
    param_1[7] = iVar7;
    if (uStack_58 < 0x10) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar8 = uStack_58 + 1;
    iVar11 = aiStack_6c[0];
    if (0xfff < uVar8) {
      iVar11 = *(int *)(aiStack_6c[0] + -4);
      uVar8 = uStack_58 + 0x24;
      if (0x1f < (aiStack_6c[0] - iVar11) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  FUN_01674ea0(iVar11,uVar8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10760 ; VA 0x00761f10 ; FUN_00761f10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall
FUN_00761f10(undefined4 *param_1,int *param_2,int param_3,int *param_4,int *param_5,uint param_6)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  byte *pbVar7;
  int *piVar8;
  int iVar9;
  int iVar10;
  int *piStack_80;
  int *piStack_7c;
  int iStack_60;
  int *piStack_5c;
  uint uStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  undefined2 auStack_40 [2];
  undefined4 uStack_3c;
  undefined uStack_38;
  undefined uStack_34;
  undefined uStack_33;
  undefined4 uStack_30;
  undefined2 uStack_2c;
  int iStack_28;
  byte *pbStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uVar3 = param_6;
  puStack_c = &LAB_017adf67;
  pvStack_10 = ExceptionList;
  iStack_54 = 0;
  iStack_60 = 0;
  piStack_5c = (int *)0x0;
  uStack_58 = 0;
  iStack_50 = _DAT_018fac80;
  iStack_4c = _UNK_018fac84;
  iStack_48 = _UNK_018fac88;
  iStack_44 = _UNK_018fac8c;
  uStack_8 = 1;
  uStack_7 = 0;
  if (*(int *)(param_3 + 0x10) != 0) {
    uStack_58 = (uint)((param_6 & 0x200) == 0);
  }
  if ((param_6 & 0x800) != 0) {
    iStack_54 = 4;
  }
  pbStack_24 = (byte *)(param_1 + (param_6 & 0x3f1f) * 0xd + 0xfc803);
  pbVar7 = pbStack_24 + *pbStack_24 + 1;
  ExceptionList = &pvStack_10;
  puStack_1c = param_1;
  uVar5 = FUN_0055c740(pbVar7,param_3);
  FUN_00562fc0(&param_6,uVar5,param_3,-(uint)(pbVar7 != (byte *)0x0) & (uint)(pbVar7 + 1));
  if (param_6 != 0) {
    if (*(int *)(param_6 + 0x24) == 0) {
      piVar8 = (int *)0x0;
      iVar10 = 0;
    }
    else {
      LOCK();
      piVar8 = (int *)(*(int *)(param_6 + 0x24) + 4);
      *piVar8 = *piVar8 + 1;
      UNLOCK();
      iVar10 = *(int *)(param_6 + 0x24);
      piVar8 = piStack_5c;
    }
    iStack_60 = *(int *)(param_6 + 0x20);
    piStack_5c = (int *)iVar10;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar10 = piVar8[1] + -1;
      piVar8[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar10 = piVar8[2] + -1;
        piVar8[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    *param_2 = iStack_60;
    param_2[1] = (int)piStack_5c;
    param_2[2] = uStack_58;
    param_2[3] = iStack_54;
    param_2[4] = iStack_50;
    param_2[5] = iStack_4c;
    param_2[6] = iStack_48;
    param_2[7] = iStack_44;
    piVar8 = param_5;
    goto joined_r0x0076230f;
  }
  param_6 = FUN_01674e20(0x28);
  uStack_8 = 2;
  if (param_6 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_0078dea0();
  }
  uStack_8 = 1;
  FUN_0075d770(uVar5);
  uStack_18 = uVar3 >> 3 & 0xffffff01;
  uStack_20 = uVar3 >> 4 & 0xffffff01;
  if ((((uVar3 >> 0xb & 1) == 0) || ((char)uStack_18 != '\0')) || ((char)uStack_20 != '\0')) {
    FUN_00768d80(*puStack_1c,&iStack_60,~(uVar3 >> 1) & 1 | 0xc,uVar3);
    if (((char)uStack_18 == '\0') && ((char)uStack_20 == '\0')) goto LAB_007621aa;
    param_6 = CONCAT13(2,(undefined3)param_6);
  }
  else {
    FUN_0075fa50(&piStack_80,0x630,uVar3,0);
    iVar10 = 0;
    _uStack_8 = CONCAT31(uStack_7,3);
    piVar8 = piStack_80;
    do {
      param_6 = 0;
      iVar9 = piVar8[1] - *piVar8 >> 0x1f;
      if ((piVar8[1] - *piVar8) / 0x50 + iVar9 != iVar9) {
        uStack_14 = 0;
        do {
          FUN_0078e040(uStack_14 + *piVar8,iVar10);
          uStack_14 = uStack_14 + 0x50;
          param_6 = param_6 + 1;
        } while (param_6 < (uint)((piVar8[1] - *piVar8) / 0x50));
      }
      iVar10 = iVar10 + 1;
      piVar8 = piVar8 + 3;
    } while (iVar10 < 3);
    uStack_8 = 1;
    *(int *)(iStack_60 + 0x24) = piStack_80[9];
    if (piStack_7c != (int *)0x0) {
      LOCK();
      iVar10 = piStack_7c[1] + -1;
      piStack_7c[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piStack_7c)();
        LOCK();
        iVar10 = piStack_7c[2] + -1;
        piStack_7c[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piStack_7c + 4))();
          param_6 = CONCAT13(1,(undefined3)param_6);
          goto LAB_007621b4;
        }
      }
    }
LAB_007621aa:
    param_6 = CONCAT13(1,(undefined3)param_6);
  }
LAB_007621b4:
  iVar10 = 0;
  do {
    iStack_28 = iStack_60;
    uStack_14 = 0;
    iVar9 = *(int *)(iVar10 + iStack_60);
    iVar6 = *(int *)(iVar10 + 4 + iStack_60) - iVar9;
    iVar2 = iVar6 >> 0x1f;
    if (iVar6 / 0x50 + iVar2 != iVar2) {
      puStack_1c = (undefined4 *)0x0;
      do {
        puVar4 = puStack_1c;
        piVar8 = (int *)&DAT_01eb1b04;
        if (param_4 != (int *)0x0) {
          piVar8 = param_4;
        }
        if (*piVar8 != 0) {
          uStack_34 = param_6._3_1_;
          uStack_33 = (undefined)uStack_18;
          uStack_30 = 0;
          uStack_2c = 0;
          FUN_0078e550(3,&param_4,&uStack_34);
        }
        if ((*(int *)((int)puVar4 + iVar9 + 4) == 0) &&
           (((char)uStack_18 != '\0' || ((char)uStack_20 != '\0')))) {
          auStack_40[0] = 1;
          uStack_3c = 0x10;
          uStack_38 = 0;
          FUN_0078e530(auStack_40);
        }
        uStack_14 = uStack_14 + 1;
        puStack_1c = puStack_1c + 0x14;
        iVar9 = *(int *)(iVar10 + iStack_28);
      } while (uStack_14 < (uint)((*(int *)(iVar10 + 4 + iStack_28) - iVar9) / 0x50));
    }
    iVar10 = iVar10 + 0xc;
  } while (iVar10 < 0x24);
  iVar10 = FUN_0075e3c0(param_3);
  if (piStack_5c != (int *)0x0) {
    LOCK();
    piStack_5c[1] = piStack_5c[1] + 1;
    UNLOCK();
  }
  *(int *)(iVar10 + 0x18) = iStack_60;
  piVar8 = *(int **)(iVar10 + 0x1c);
  *(int **)(iVar10 + 0x1c) = piStack_5c;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar10 = piVar8[1] + -1;
    piVar8[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar10 = piVar8[2] + -1;
      piVar8[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  *param_2 = iStack_60;
  param_2[1] = (int)piStack_5c;
  param_2[2] = uStack_58;
  param_2[3] = iStack_54;
  param_2[4] = iStack_50;
  param_2[5] = iStack_4c;
  param_2[6] = iStack_48;
  param_2[7] = iStack_44;
  piVar8 = param_5;
joined_r0x0076230f:
  if (piVar8 != (int *)0x0) {
    piStack_5c = (int *)0x0;
    iStack_60 = 0;
    LOCK();
    iVar10 = piVar8[1] + -1;
    piVar8[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      param_5 = piVar8;
      (**(code **)*piVar8)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar10 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10761 ; VA 0x00762350 ; FUN_00762350 */

void FUN_00762350(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x54;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 10762 ; VA 0x00762390 ; FUN_00762390 */

int * __thiscall FUN_00762390(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  
  piVar1 = (int *)*param_3;
  *param_2 = (int)piVar1;
  uVar3 = (uint)param_3[1] % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  for (piVar5 = (int *)*piVar2; piVar5 != param_3; piVar5 = (int *)*piVar5) {
    piVar2 = piVar5;
  }
  do {
    *piVar2 = *piVar5;
    FUN_005f53f0(-(uint)(param_1 != -3) & param_1 + 4U,piVar5 + 2);
    FUN_01674ea0(piVar5,0x28);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    uVar4 = uVar3;
    if (*piVar2 == 0) {
LAB_00762419:
      if (*(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4) = 0;
      }
    }
    else {
      uVar4 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4);
      if (uVar3 != uVar4) {
        *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar2;
        goto LAB_00762419;
      }
    }
    piVar5 = (int *)*piVar2;
    uVar3 = uVar4;
    if (piVar5 == piVar1) {
      return param_2;
    }
  } while( true );
}



/* FUNCTION 10763 ; VA 0x00762450 ; FUN_00762450 */

void __fastcall FUN_00762450(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iStack_8;
  
  iVar3 = param_1 + 0x3f2028;
  iVar4 = 0x3f20;
  iStack_8 = param_1;
  do {
    iVar2 = *(int *)(iVar3 + -0x14);
    if (iVar2 == 0) {
      piVar1 = (int *)0x0;
    }
    else {
      piVar1 = *(int **)(*(int *)(iVar3 + -8) + *(int *)(iVar3 + -0x18) * 4);
    }
    if (piVar1 != (int *)0x0) {
      do {
        if ((piVar1[9] != 0) && (*(int *)(piVar1[9] + 4) == 1)) {
          piVar1 = (int *)FUN_00762390(&iStack_8,piVar1);
        }
        piVar1 = (int *)*piVar1;
      } while (piVar1 != (int *)0x0);
      iVar2 = *(int *)(iVar3 + -0x14);
    }
    *(int *)(iVar3 + -4) = iVar2;
    FUN_005542c0(&DAT_018bc9b8,0);
    iVar3 = iVar3 + 0x34;
    iVar4 = iVar4 + -1;
  } while (iVar4 != 0);
  return;
}



/* FUNCTION 10764 ; VA 0x007624d0 ; FUN_007624d0 */

void __fastcall FUN_007624d0(int param_1)

{
  uint *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint *puVar5;
  uint *puVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  undefined8 uVar10;
  uint auStack_70 [4];
  undefined4 *puStack_60;
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017adfc6;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb18c0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb18c0), DAT_01eb18c0 == -1)) {
    uStack_8 = 0;
    uVar10 = FUN_0152dab0("Render","MaterialGenerator::garbageCollectIncremental",0xffffffff);
    DAT_01eb18bc = (undefined4)((ulonglong)uVar10 >> 0x20);
    DAT_01eb18b8 = (undefined4)uVar10;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb18c0);
  }
  uStack_2c = DAT_01eb18b8;
  uStack_40 = DAT_01eb18b8;
  uStack_28 = DAT_01eb18bc;
  uStack_3c = DAT_01eb18bc;
  uStack_38 = FUN_0152d930(DAT_01eb18b8,DAT_01eb18bc);
  uStack_8 = 1;
  puVar6 = (uint *)(param_1 + 0x3f2028);
  uStack_24 = 0;
  do {
    uVar8 = puVar6[-5];
    if (uVar8 == 0) {
      puVar6[-1] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
    }
    else {
      uVar9 = puVar6[-1];
      uVar4 = uVar9;
      if (uVar9 <= uVar8) {
        uVar4 = uVar8;
      }
      uStack_20 = (uVar4 - uVar9) + 8;
      if (uVar8 <= uStack_20) {
        uStack_20 = uVar8;
      }
      iVar7 = (*(byte *)(puVar6 + -7) - 0x1b) + (int)puVar6;
      uVar2 = FUN_0055c740(iVar7,puVar6);
      FUN_00562fc0(&puStack_18,uVar2,puVar6,-(uint)(iVar7 != 0) & iVar7 + 1U);
      for (uVar8 = uStack_20; uVar8 != 0; uVar8 = uVar8 - 1) {
        puVar3 = puStack_18;
        if (puStack_18 == (undefined4 *)0x0) {
          if (puVar6[-5] == 0) {
            puVar3 = (undefined4 *)0x0;
          }
          else {
            puVar3 = *(undefined4 **)(puVar6[-2] + puVar6[-6] * 4);
          }
        }
        if ((puVar3[9] != 0) && (*(int *)(puVar3[9] + 4) == 1)) {
          puVar3 = (undefined4 *)FUN_00762390(auStack_30,puVar3);
        }
        puStack_18 = (undefined4 *)*puVar3;
      }
      puVar6[-1] = puVar6[-5];
      if (puStack_18 == (undefined4 *)0x0) {
        uStack_5c = 0xf;
        auStack_70[0] = auStack_70[0] & 0xffffff00;
        puStack_60 = puStack_18;
        FUN_005542c0(&DAT_018bc9b8,0);
        uStack_14 = uStack_14 | 1;
        puVar5 = auStack_70;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
      }
      else {
        uStack_20 = puStack_18[6];
        puStack_1c = puStack_18 + 2;
        uStack_48 = 0;
        uStack_44 = 0;
        if (0xf < (uint)puStack_18[7]) {
          puStack_1c = (uint *)*puStack_1c;
        }
        if (uStack_20 < 0x10) {
          uStack_48 = uStack_20;
          uVar8 = 0xf;
          uStack_58 = *puStack_1c;
          uStack_54 = puStack_1c[1];
          uStack_50 = puStack_1c[2];
          uStack_4c = puStack_1c[3];
        }
        else {
          uVar8 = uStack_20 | 0xf;
          if (0x7fffffff < uVar8) {
            uVar8 = 0x7fffffff;
          }
          uVar9 = uVar8 + 1;
          if (uVar9 < 0x1000) {
            if (uVar9 == 0) {
              uStack_58 = 0;
            }
            else {
              uStack_58 = FUN_01674e20(uVar9);
            }
          }
          else {
            uVar4 = uVar8 + 0x24;
            if (uVar4 <= uVar9) {
              uVar4 = 0xffffffff;
            }
            iVar7 = FUN_01674e20(uVar4);
            if (iVar7 == 0) goto LAB_007627da;
            uStack_58 = iVar7 + 0x23U & 0xffffffe0;
            *(int *)(uStack_58 - 4) = iVar7;
          }
          FUN_0170c6f0(uStack_58,puStack_1c,uStack_20 + 1);
          uStack_48 = uStack_20;
        }
        uStack_44 = uVar8;
        uStack_14 = uStack_14 | 2;
        puVar5 = &uStack_58;
        uStack_8 = 3;
        uStack_48 = uStack_20;
      }
      if (puVar6 != puVar5) {
        puVar1 = puVar5 + 4;
        if (0xf < puVar5[5]) {
          puVar5 = (uint *)*puVar5;
        }
        FUN_005542c0(puVar5,*puVar1);
      }
      uStack_8 = 2;
      if (((uStack_14 & 2) != 0) && (uStack_14 = uStack_14 & 0xfffffffd, 0xf < uStack_44)) {
        uVar9 = uStack_44 + 1;
        uVar8 = uStack_58;
        if (0xfff < uVar9) {
          uVar8 = *(uint *)(uStack_58 - 4);
          uVar9 = uStack_44 + 0x24;
          if (0x1f < (uStack_58 - uVar8) - 4) goto LAB_007627da;
        }
        FUN_01674ea0(uVar8,uVar9);
      }
      uStack_8 = 1;
      if (((uStack_14 & 1) != 0) && (uStack_14 = uStack_14 & 0xfffffffe, 0xf < uStack_5c)) {
        uVar9 = uStack_5c + 1;
        uVar8 = auStack_70[0];
        if (0xfff < uVar9) {
          uVar8 = *(uint *)(auStack_70[0] - 4);
          uVar9 = uStack_5c + 0x24;
          if (0x1f < (auStack_70[0] - uVar8) - 4) {
LAB_007627da:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar8,uVar9);
      }
    }
    puVar6 = puVar6 + 0xd;
    uStack_24 = uStack_24 + 1;
    if (0x3f1f < uStack_24) {
      uStack_8 = 4;
      FUN_0152dda0(uStack_2c,uStack_28,uStack_38);
      ExceptionList = pvStack_10;
      return;
    }
  } while( true );
}



/* FUNCTION 10765 ; VA 0x00762840 ; FUN_00762840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00762840(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  char *pcStack_24;
  undefined4 uStack_10;
  int *piStack_c;
  
  if (DAT_01d60bc0 == '\0') {
    _DAT_01eb1138 = "DefaultReflectionVS_";
    pcRam01eb113c = "GridFS_";
    uRam01eb1140 = 0;
    uRam01eb1144 = 0;
  }
  else {
    _DAT_01eb11a8 = "DefaultReflectionVS_";
    pcRam01eb11ac = "GridFS_";
    uRam01eb11b0 = 0;
    uRam01eb11b4 = 0;
  }
  _DAT_01eb1288 = "DefaultHQVS_";
  pcRam01eb128c = "DefaultTransparentHQFS_";
  uRam01eb1290 = 0;
  uRam01eb1294 = 0;
  _DAT_01eb12f8 = "DefaultVS_";
  pcRam01eb12fc = "DefaultTransparentFS";
  uRam01eb1300 = 0;
  uRam01eb1304 = 0;
  _DAT_01eb13d8 = "DefaultHQVS_";
  pcRam01eb13dc = "DefaultOpaqueHQFS_";
  uRam01eb13e0 = 0;
  uRam01eb13e4 = 0;
  _DAT_01eb1448 = "DefaultVS_";
  pcRam01eb144c = "DefaultOpaqueFS";
  uRam01eb1450 = 0;
  uRam01eb1454 = 0;
  _DAT_01eb02c8 = "DefaultSurfaceHQVS_";
  pcRam01eb02cc = "DefaultPlasticHQFS_";
  uRam01eb02d0 = 0;
  uRam01eb02d4 = 0;
  _DAT_01eb0338 = "DefaultVS_";
  pcRam01eb033c = "DefaultPlasticFS";
  uRam01eb0340 = 0;
  uRam01eb0344 = 0;
  _DAT_01eb0418 = "DefaultSurfaceHQVS_";
  pcRam01eb041c = "DefaultPlasticHQFS_";
  uRam01eb0420 = 0;
  uRam01eb0424 = 0;
  _DAT_01eb0488 = "DefaultReflectionVS_";
  pcRam01eb048c = "DefaultPlasticReflectionFS";
  uRam01eb0490 = 0;
  uRam01eb0494 = 0;
  _DAT_01eb0568 = "DefaultHQVS_";
  pcRam01eb056c = "DefaultNeonHQFS_";
  uRam01eb0570 = 0;
  uRam01eb0574 = 0;
  _DAT_01eb05d8 = "DefaultVS_";
  pcRam01eb05dc = "DefaultNeonFS";
  uRam01eb05e0 = 0;
  uRam01eb05e4 = 0;
  _DAT_01eb06b8 = "DefaultHQVS_";
  pcRam01eb06bc = "DefaultNeonHQInGuiFS";
  uRam01eb06c0 = 0;
  uRam01eb06c4 = 0;
  _DAT_01eb0728 = "DefaultVS_";
  pcRam01eb072c = "DefaultNeonInGuiFS";
  uRam01eb0730 = 0;
  uRam01eb0734 = 0;
  _DAT_01eb0d48 = "DefaultSurfaceHQVS_";
  pcRam01eb0d4c = "DefaultGlassHQFS_";
  uRam01eb0d50 = 0;
  uRam01eb0d54 = 0;
  _DAT_01eb0db8 = "GlassVS_";
  pcRam01eb0dbc = "LowQGlassFS";
  uRam01eb0dc0 = 0;
  uRam01eb0dc4 = 0;
  _DAT_01eb0e28 = "DefaultSurfaceHQVS_";
  pcRam01eb0e2c = "DefaultGlassSuperHQFS_";
  uRam01eb0e30 = 0;
  uRam01eb0e34 = 0;
  _DAT_01eb0e98 = "DefaultSurfaceHQVS_";
  pcRam01eb0e9c = "DefaultGlassHQFS_";
  uRam01eb0ea0 = 0;
  uRam01eb0ea4 = 0;
  _DAT_01eb0f08 = "GlassVS_";
  pcRam01eb0f0c = "LowQGlassFS";
  uRam01eb0f10 = 0;
  uRam01eb0f14 = 0;
  _DAT_01eb0ea8 = "DefaultVS_";
  pcRam01eb0eac = "GlassTintFS";
  uRam01eb0eb0 = 0;
  uRam01eb0eb4 = 0;
  _DAT_01eb1058 = "DefaultForceFieldVS_";
  pcRam01eb105c = "DefaultForceFieldFS";
  uRam01eb1060 = 0;
  uRam01eb1064 = 0;
  _DAT_01eb10b8 = "DefaultForceFieldVS_";
  pcRam01eb10bc = "DefaultForceFieldFS";
  uRam01eb10c0 = 0;
  uRam01eb10c4 = 0;
  _DAT_01eb0aa8 = "DefaultSurfaceHQVS_";
  pcRam01eb0aac = "DefaultTiledHideDiffuseRepHQFS_";
  uRam01eb0ab0 = 0;
  uRam01eb0ab4 = 0;
  _DAT_01eb0b18 = "DefaultVS_";
  pcRam01eb0b1c = "LowQMaterialFS";
  uRam01eb0b20 = 0;
  uRam01eb0b24 = 0;
  _DAT_01eb0bf8 = "DefaultSurfaceHQVS_";
  pcRam01eb0bfc = "DefaultTiledHideAllRepHQFS_";
  uRam01eb0c00 = 0;
  uRam01eb0c04 = 0;
  _DAT_01eb0c68 = "DefaultVS_";
  pcRam01eb0c6c = "LowQMaterialFS";
  uRam01eb0c70 = 0;
  uRam01eb0c74 = 0;
  _DAT_01eb0f78 = "DefaultForceFieldHQVS_";
  pcRam01eb0f7c = "DefaultForceFieldSHQFS_";
  uRam01eb0f80 = 0;
  uRam01eb0f84 = 0;
  _DAT_01eb0fe8 = "DefaultForceFieldHQVS_";
  pcRam01eb0fec = "DefaultForceFieldHQFS_";
  uRam01eb0ff0 = 0;
  uRam01eb0ff4 = 0;
  _DAT_01eb0fd8 = "DefaultForceFieldHQVS_";
  pcRam01eb0fdc = "DefaultForceFieldSHQFS_";
  uRam01eb0fe0 = 0;
  uRam01eb0fe4 = 0;
  _DAT_01eb1048 = "DefaultForceFieldHQVS_";
  pcRam01eb104c = "DefaultForceFieldHQFS_";
  uRam01eb1050 = 0;
  uRam01eb1054 = 0;
  _DAT_01eb0808 = "DefaultSurfaceHQVS_";
  pcRam01eb080c = "DefaultTiledHQFS_";
  uRam01eb0810 = 0;
  uRam01eb0814 = 0;
  _DAT_01eb0878 = "DefaultVS_";
  pcRam01eb087c = "LowQMaterialFS";
  uRam01eb0880 = 0;
  uRam01eb0884 = 0;
  _DAT_01eb1528 = "DefaultSurfaceHQVS_";
  pcRam01eb152c = "DefaultSurfaceAppearanceHQFS_";
  uRam01eb1530 = 0;
  uRam01eb1534 = 0;
  _DAT_01eb1598 = "DefaultVS_";
  pcRam01eb159c = "DefaultSurfaceAppearanceFS";
  uRam01eb15a0 = 0;
  uRam01eb15a4 = 0;
  if ((DAT_01d60f80 == '\0') && (DAT_01d60f88 == '\0')) {
    pcRam01eb167c = "DefaultSurfaceAppearanceDitheredHQFS_";
    pcStack_24 = "DefaultSurfaceAppearanceDitheredFS";
  }
  else {
    pcRam01eb167c = "DefaultSurfaceAppearanceHQFS_";
    pcStack_24 = "DefaultSurfaceAppearanceFS";
  }
  _DAT_01eb1678 = "DefaultSurfaceHQVS_";
  uRam01eb1680 = 0;
  uRam01eb1684 = 0;
  _DAT_01eb16e8 = "DefaultVS_";
  pcRam01eb16ec = pcStack_24;
  uRam01eb16f0 = 0;
  uRam01eb16f4 = 0;
  _DAT_01eb1838 = "DefaultModelLodVS";
  pcRam01eb183c = "DefaultModelLodFS";
  uRam01eb1840 = 0;
  uRam01eb1844 = 0;
  piVar1 = (int *)FUN_007910b0(&uStack_10,"DefaultVS_",10,0,"LowQMaterialWangFS",0x12,0);
  iVar3 = *piVar1;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_c[1] + -1;
    piStack_c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piStack_c + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if (iVar3 == 0) {
    pcStack_24 = "LowQMaterialWangFallbackFS";
  }
  else {
    pcStack_24 = "LowQMaterialWangFS";
    _DAT_01eb0958 = "DefaultSurfaceHQVS_";
    pcRam01eb095c = "DefaultWangHQFS_";
    uRam01eb0960 = 0;
    uRam01eb0964 = 0;
  }
  iVar3 = 0;
  if (DAT_01d60bc0 != '\0') {
    iVar3 = 2;
  }
  iVar5 = 0;
  _DAT_01eb09c8 = "DefaultVS_";
  pcRam01eb09cc = pcStack_24;
  uRam01eb09d0 = 0;
  uRam01eb09d4 = 0;
  uStack_10 = 0;
  piStack_c = (int *)0x0;
  do {
    iVar4 = (iVar3 + iVar5 * 3) * 0x70;
    *(char **)(&DAT_01eb0278 + iVar4) = "DefaultShadowGeomVS_";
    *(char **)(iVar4 + 0x1eb027c) = "DefaultShadowFS";
    *(undefined4 *)(iVar4 + 0x1eb0280) = 0;
    *(undefined4 *)(iVar4 + 0x1eb0284) = 0;
    if (iVar5 == 0xf) {
      if ((DAT_01d60f80 != '\0') || (DAT_01d60f88 != '\0')) {
        iVar2 = iVar3 * 0x70;
        *(char **)(&DAT_01eb1638 + iVar2) = "DefaultSurfaceAppearanceDitheredDepthVS_";
        *(char **)(iVar2 + 0x1eb163c) = "DefaultSurfaceAppearanceDitheredDepthFS";
        *(undefined4 *)(iVar2 + 0x1eb1640) = 0;
        *(undefined4 *)(iVar2 + 0x1eb1644) = 0;
      }
    }
    else if (DAT_01d60f78 != '\0') {
      *(char **)(&DAT_01eb0288 + iVar4) = "DefaultDepthVS_";
      *(char **)(iVar4 + 0x1eb028c) = "DefaultDepthFS";
      *(undefined4 *)(iVar4 + 0x1eb0290) = 0;
      *(undefined4 *)(iVar4 + 0x1eb0294) = 0;
    }
    *(char **)(&DAT_01eb02a8 + iVar4) = "DefaultNewShadowVS_";
    *(char **)(iVar4 + 0x1eb02ac) = "DefaultNewShadowFS_";
    *(undefined4 *)(iVar4 + 0x1eb02b0) = uStack_10;
    *(int **)(iVar4 + 0x1eb02b4) = piStack_c;
    *(char **)(&DAT_01eb0298 + iVar4) = "DefaultNewShadowVS_";
    *(char **)(iVar4 + 0x1eb029c) = "DefaultNewShadowFS_";
    *(undefined4 *)(&DAT_01eb02a0 + iVar4) = uStack_10;
    *(int **)(&DAT_01eb02a4 + iVar4) = piStack_c;
    iVar2 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
    if (*(char *)(iVar2 + 10) == '\0') {
      *(undefined4 *)(&DAT_01eb02a0 + iVar4) = 0x40;
      *(undefined4 *)(&DAT_01eb02a4 + iVar4) = 0x40;
    }
    iVar5 = iVar5 + 1;
  } while (iVar5 < 0x11);
  return;
}



/* FUNCTION 10766 ; VA 0x00762f90 ; FUN_00762f90 */

undefined4 __fastcall FUN_00762f90(int param_1)

{
  return *(undefined4 *)(param_1 + 0xb4);
}



/* FUNCTION 10767 ; VA 0x00762fa0 ; FUN_00762fa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00762fa0(undefined8 *param_1,int *param_2)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  undefined8 *puVar7;
  float fVar8;
  float *pfVar9;
  undefined8 *puVar10;
  float *pfVar11;
  uint uVar12;
  float fVar13;
  undefined auStack_28 [4];
  float fStack_24;
  float fStack_1c;
  int iStack_18;
  uint uStack_14;
  uint uStack_10;
  float *pfStack_c;
  uint uStack_8;
  
  if ((DAT_01d60be0 == '\0') || (cVar5 = FUN_00764820(*param_2), cVar5 == '\0')) {
    if (*(int *)(*param_2 + 0x228) == 0) {
      uStack_14 = 4;
    }
    else {
      uStack_14 = 0;
      if (*(int *)(*param_2 + 0x228) == 1) {
        uStack_14 = 10;
      }
    }
    iVar6 = param_2[0x10];
    uVar12 = 0;
    uStack_8 = 0;
    uStack_10 = 0;
    if (param_2[0x11] - iVar6 >> 2 != 0) {
      pfStack_c = (float *)(param_1 + 1);
      do {
        puVar3 = *(undefined4 **)(*(int *)(iVar6 + uStack_10 * 4) + 0x2c);
        if (puVar3 != (undefined4 *)0x0) {
          pfVar9 = (float *)puVar3[1];
          for (pfVar11 = (float *)*puVar3; uVar12 = uStack_8, pfVar11 != pfVar9;
              pfVar11 = pfVar11 + 2) {
            fStack_1c = *pfVar11;
            if (fStack_1c != 0.0) {
              iStack_18 = *(int *)((int)fStack_1c + 0xc);
              iVar6 = FUN_00aff8c0();
              fVar13 = fStack_1c;
              if ((uint)*(ushort *)(iStack_18 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
                  (uint)*(ushort *)(iVar6 + 0x1da)) {
                uVar12 = uStack_8;
                if ((((fStack_1c != 0.0) &&
                     (fVar8 = (float)FUN_00d011a0(fStack_1c), uVar12 = uStack_8, fVar8 != 0.0)) &&
                    (uStack_8 < uStack_14)) && (*(int *)((int)fVar8 + 0x90) != 0)) {
                  pfStack_c[-1] = fVar8;
                  pfStack_c[-2] = fVar13;
                  FUN_00c22d40(auStack_28);
                  pfVar9 = (float *)FUN_00b08320();
                  fVar13 = pfVar9[1];
                  if ((fVar13 * DAT_018ce2f4 - fStack_24 < 0.0) ||
                     ((float)((uint)fStack_24 ^ DAT_018c4ea0) - fVar13 * DAT_018ce2f4 < DAT_018fabf4
                     )) {
                    fVar13 = 0.0;
                  }
                  else {
                    fVar13 = *pfVar9 * pfVar9[2] + *pfVar9 * fVar13 + pfVar9[2] * fVar13;
                  }
                  uStack_8 = uVar12 + 1;
                  *pfStack_c = fVar13;
                  pfStack_c = pfStack_c + 3;
                  uVar12 = uStack_8;
                }
                break;
              }
            }
          }
        }
        uStack_10 = uStack_10 + 1;
        iVar6 = param_2[0x10];
      } while (uStack_10 < (uint)(param_2[0x11] - iVar6 >> 2));
      if (1 < uVar12) {
        puVar1 = (undefined8 *)(uVar12 * 0xc + (int)param_1);
        FUN_0075cdb0(param_1,puVar1,(int)(uVar12 * 0xc) / 0xc,fStack_1c);
        puVar10 = param_1;
        if (param_1 != puVar1) {
          for (puVar7 = (undefined8 *)((int)param_1 + 0xc); puVar7 != puVar1;
              puVar7 = (undefined8 *)((int)puVar7 + 0xc)) {
            if (*(float *)(puVar10 + 1) <= *(float *)(puVar7 + 1) &&
                *(float *)(puVar7 + 1) != *(float *)(puVar10 + 1)) {
              puVar10 = puVar7;
            }
          }
        }
        if (DAT_018ce2f0 < *(float *)(puVar10 + 1)) {
          uVar2 = *param_1;
          uVar4 = *(undefined4 *)(param_1 + 1);
          *param_1 = *puVar10;
          *(undefined4 *)(param_1 + 1) = *(undefined4 *)(puVar10 + 1);
          *puVar10 = uVar2;
          *(undefined4 *)(puVar10 + 1) = uVar4;
        }
      }
    }
  }
  return;
}



/* FUNCTION 10768 ; VA 0x007631f0 ; FUN_007631f0 */

uint FUN_007631f0(int param_1,int *param_2,int *param_3)

{
  uint uVar1;
  int iVar2;
  
  if (*(int *)(*param_2 + 0x228) == 0) {
    iVar2 = FUN_01154940(param_1);
    if (iVar2 == 0) {
      return 4;
    }
    uVar1 = 0;
    do {
      if (*param_3 == param_1) {
        return uVar1;
      }
      uVar1 = uVar1 + 1;
      param_3 = param_3 + 3;
    } while (uVar1 < 4);
  }
  else if (*(int *)(*param_2 + 0x228) == 1) {
    uVar1 = 0;
    do {
      if (*param_3 == param_1) {
        return uVar1;
      }
      uVar1 = uVar1 + 1;
      param_3 = param_3 + 3;
    } while (uVar1 < 10);
    return 0xffffffff;
  }
  return 0xffffffff;
}



/* FUNCTION 10769 ; VA 0x00763260 ; FUN_00763260 */

undefined4 FUN_00763260(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017adfe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_007631f0(param_2,param_3,param_4);
  uVar1 = FUN_01675640(aiStack_28,"rbxasset://avatar/compositing/CompositExtraSlot%d.mesh",uVar1);
  uStack_8 = 0;
  FUN_0054ef60(uVar1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_009cbbb0(param_1);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10770 ; VA 0x00763310 ; FUN_00763310 */

char * FUN_00763310(int param_1)

{
  if (param_1 < 0x371) {
    if (param_1 == 0x370) {
      return "Cobblestone";
    }
    if (param_1 < 0x311) {
      if (param_1 == 0x310) {
        return "Marble";
      }
      if (param_1 < 0x121) {
        if (param_1 == 0x120) {
          return "Neon";
        }
        if ((param_1 != 0x100) && (param_1 == 0x110)) {
          return "SmoothPlastic";
        }
      }
      else {
        if (param_1 == 0x200) {
          return "Wood";
        }
        if (param_1 == 0x210) {
          return "WoodPlanks";
        }
      }
    }
    else {
      switch(param_1) {
      case 800:
        return "Slate";
      case 0x330:
        return "Concrete";
      case 0x340:
        return "Granite";
      case 0x350:
        return "Brick";
      case 0x360:
        return "Pebble";
      }
    }
  }
  else if (param_1 < 0x511) {
    if (param_1 == 0x510) {
      return "Sand";
    }
    switch(param_1) {
    case 0x410:
      return "Rust";
    case 0x420:
      return "Diamondplate";
    case 0x430:
      return "Aluminum";
    case 0x440:
      return "Metal";
    case 0x500:
      return "Grass";
    }
  }
  else if (param_1 < 0x621) {
    if (param_1 == 0x620) {
      return "Glass";
    }
    if (param_1 == 0x520) {
      return "Fabric";
    }
    if (param_1 == 0x600) {
      return "Ice";
    }
  }
  else if (param_1 == 0x630) {
    return "ForceField";
  }
  return "Plastic";
}



/* FUNCTION 10771 ; VA 0x007635c0 ; FUN_007635c0 */

int __fastcall FUN_007635c0(int param_1)

{
  return param_1 + 0x84;
}



/* FUNCTION 10772 ; VA 0x007635d0 ; FUN_007635d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007635d0(undefined *param_1,int param_2,int *param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int extraout_ECX;
  int iVar7;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  if (*(int *)(*param_3 + 0x228) == 0) {
    iVar4 = FUN_01154940(param_2);
    uVar3 = _UNK_018fac7c;
    uVar2 = _UNK_018fac78;
    uVar1 = _UNK_018fac74;
    uVar5 = _DAT_018fac70;
    if (((iVar4 == 3) || (iVar4 == 2)) || (iVar4 == 1)) {
      *param_1 = 1;
      *(undefined4 *)(param_1 + 4) = uVar5;
      *(undefined4 *)(param_1 + 8) = uVar1;
      *(undefined4 *)(param_1 + 0xc) = uVar2;
      *(undefined4 *)(param_1 + 0x10) = uVar3;
      return;
    }
    iVar4 = FUN_007631f0(param_2,param_3,param_4);
    if (-1 < iVar4) {
      iVar4 = iVar4 * 0x10;
      fStack_14 = *(float *)(&DAT_018f9f48 + iVar4) + _DAT_018fabc8;
      fStack_10 = *(float *)(&DAT_018f9f4c + iVar4) + DAT_018e3f7c;
      fStack_c = *(float *)(&DAT_018f9f50 + iVar4) - _DAT_018fabcc;
      fStack_8 = *(float *)(&DAT_018f9f54 + iVar4) - DAT_018fabd4;
      goto LAB_0076367d;
    }
  }
  else if (*(int *)(*param_3 + 0x228) == 1) {
    uVar5 = FUN_011548e0(param_2);
    FUN_00763880(&fStack_14,uVar5);
    if (extraout_ECX == 0) {
      iVar4 = *(int *)(param_2 + 0xc);
      iVar6 = FUN_00cfb1a0();
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        iVar7 = param_2;
      }
      if ((iVar7 == 0) || (DAT_01d64ac8 != '\0')) {
        fStack_14 = fStack_14 + _DAT_018fabc0;
        fStack_10 = fStack_10 + _DAT_018fabc0;
        fStack_c = fStack_c - DAT_018fabc4;
        fStack_8 = fStack_8 - DAT_018fabc4;
      }
    }
    else if (extraout_ECX == -1) {
      iVar4 = FUN_007631f0(param_2,param_3,param_4);
      if (-1 < iVar4) {
        iVar4 = iVar4 * 0x10;
        *param_1 = 1;
        uVar5 = *(undefined4 *)(&UNK_018f9f9c + iVar4);
        uVar1 = *(undefined4 *)(&UNK_018f9fa0 + iVar4);
        uVar2 = *(undefined4 *)(&UNK_018f9fa4 + iVar4);
        *(undefined4 *)(param_1 + 4) = *(undefined4 *)(&DAT_018f9f98 + iVar4);
        *(undefined4 *)(param_1 + 8) = uVar5;
        *(undefined4 *)(param_1 + 0xc) = uVar1;
        *(undefined4 *)(param_1 + 0x10) = uVar2;
        return;
      }
      goto LAB_00763786;
    }
LAB_0076367d:
    *param_1 = 1;
    *(float *)(param_1 + 4) = fStack_14;
    *(float *)(param_1 + 8) = fStack_10;
    *(float *)(param_1 + 0xc) = fStack_c;
    *(float *)(param_1 + 0x10) = fStack_8;
    return;
  }
LAB_00763786:
  *param_1 = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  return;
}



/* FUNCTION 10773 ; VA 0x007637a0 ; FUN_007637a0 */

void FUN_007637a0(float *param_1,undefined4 param_2,undefined4 param_3)

{
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  FUN_00763880(&fStack_14,param_3);
  *param_1 = fStack_14 * DAT_018fabf0;
  fStack_10 = DAT_018ce2f8 - fStack_10;
  param_1[3] = fStack_8;
  param_1[1] = (fStack_10 - fStack_8) * DAT_018fabf0;
  param_1[2] = fStack_c;
  return;
}



/* FUNCTION 10774 ; VA 0x00763800 ; FUN_00763800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00763800(float *param_1,undefined4 param_2,undefined4 param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  FUN_00763880(&fStack_14,param_3);
  fVar1 = _UNK_018fac84 + ((DAT_018ce2f8 - fStack_10) - fStack_8) * DAT_018fabf0 * _UNK_018fac04;
  fVar2 = _UNK_018fac88 + fStack_c * _UNK_018fac08;
  fVar3 = _UNK_018fac8c + fStack_8 * _UNK_018fac0c;
  *param_1 = _DAT_018fac80 + fStack_14 * DAT_018fabf0 * _DAT_018fac00;
  param_1[1] = fVar1;
  param_1[2] = fVar2;
  param_1[3] = fVar3;
  return;
}



/* FUNCTION 10775 ; VA 0x00763880 ; FUN_00763880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00763880(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  
  uVar18 = DAT_01eb0254;
  uVar17 = DAT_01eb0250;
  uVar16 = _DAT_01eb024c;
  uVar15 = DAT_01eb0244;
  uVar14 = DAT_01eb0240;
  uVar13 = _DAT_01eb023c;
  uVar12 = DAT_01eb0234;
  uVar11 = DAT_01eb0230;
  uVar10 = _DAT_01eb022c;
  uVar9 = DAT_01eb0224;
  uVar8 = DAT_01eb0220;
  uVar7 = _DAT_01eb021c;
  uVar6 = DAT_01eb0214;
  uVar5 = DAT_01eb0210;
  uVar4 = _DAT_01eb020c;
  uVar3 = DAT_01eb0204;
  uVar2 = DAT_01eb0200;
  uVar1 = _DAT_01eb01fc;
  switch(param_2) {
  case 0:
    *param_1 = DAT_01eb0248;
    param_1[1] = uVar16;
    param_1[2] = uVar17;
    param_1[3] = uVar18;
    return;
  case 1:
  case 2:
    *param_1 = DAT_01eb01f8;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    return;
  case 3:
  case 4:
  case 7:
    *param_1 = DAT_01eb0208;
    param_1[1] = uVar4;
    param_1[2] = uVar5;
    param_1[3] = uVar6;
    return;
  case 5:
  case 6:
  case 8:
    *param_1 = DAT_01eb0218;
    param_1[1] = uVar7;
    param_1[2] = uVar8;
    param_1[3] = uVar9;
    return;
  case 9:
  case 10:
  case 0xd:
    *param_1 = DAT_01eb0228;
    param_1[1] = uVar10;
    param_1[2] = uVar11;
    param_1[3] = uVar12;
    return;
  case 0xb:
  case 0xc:
  case 0xe:
    *param_1 = DAT_01eb0238;
    param_1[1] = uVar13;
    param_1[2] = uVar14;
    param_1[3] = uVar15;
    return;
  default:
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0x3f800000;
    param_1[3] = 0x3f800000;
    return;
  }
}



/* FUNCTION 10776 ; VA 0x00763960 ; FUN_00763960 */

undefined4 * FUN_00763960(undefined4 *param_1,int param_2)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined *puVar6;
  uint *puVar7;
  int *piVar8;
  undefined4 ****ppppuVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uVar12;
  int *piVar13;
  undefined auStack_11b [3];
  uint auStack_118 [4];
  undefined4 uStack_108;
  uint uStack_104;
  uint uStack_100;
  uint uStack_fc;
  uint uStack_f8;
  uint uStack_f4;
  undefined8 uStack_f0;
  uint uStack_e8;
  uint uStack_e4;
  uint uStack_e0;
  uint uStack_dc;
  undefined8 uStack_d8;
  uint uStack_d0;
  uint uStack_cc;
  uint uStack_c8;
  uint uStack_c4;
  undefined8 uStack_c0;
  uint uStack_b8;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  undefined8 uStack_a8;
  uint uStack_a0;
  uint uStack_9c;
  uint uStack_98;
  uint uStack_94;
  undefined8 uStack_90;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  uint uStack_7c;
  undefined8 uStack_78;
  uint uStack_70;
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  undefined8 uStack_60;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  undefined8 uStack_48;
  undefined4 ***apppuStack_40 [4];
  uint uStack_30;
  uint uStack_2c;
  undefined4 ***pppuStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ae05d;
  pvStack_10 = ExceptionList;
  iVar5 = *(int *)(param_2 + 0xb4);
  if (iVar5 < 0) {
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00591870(auStack_11b,-iVar5);
    *(undefined *)(iVar5 + -1) = 0x2d;
    puVar6 = (undefined *)(iVar5 + -1);
  }
  else {
    ExceptionList = &pvStack_10;
    puVar6 = (undefined *)FUN_00591870(auStack_11b,iVar5);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
  if (puVar6 != auStack_11b) {
    FUN_005542c0(puVar6,(int)auStack_11b - (int)puVar6);
  }
  uStack_8 = 0;
  piVar13 = (int *)(param_2 + 0xb8);
  FUN_00558df0(auStack_118,&DAT_018fa9e0,param_2 + 0x54);
  uStack_8._0_1_ = 1;
  puVar7 = (uint *)FUN_00554150(&DAT_018d1b9c,1);
  uStack_100 = *puVar7;
  uStack_fc = puVar7[1];
  uStack_f8 = puVar7[2];
  uStack_f4 = puVar7[3];
  uStack_f0 = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  piVar8 = (int *)(param_2 + 0x6c);
  uStack_8._0_1_ = 2;
  if (0xf < *(uint *)(param_2 + 0x80)) {
    piVar8 = (int *)*piVar8;
  }
  puVar7 = (uint *)FUN_00554150(piVar8,*(undefined4 *)(param_2 + 0x7c));
  uStack_e8 = *puVar7;
  uStack_e4 = puVar7[1];
  uStack_e0 = puVar7[2];
  uStack_dc = puVar7[3];
  uStack_d8 = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  uStack_8._0_1_ = 3;
  puVar7 = (uint *)FUN_00554150(&DAT_018d1b9c,1);
  uStack_d0 = *puVar7;
  uStack_cc = puVar7[1];
  uStack_c8 = puVar7[2];
  uStack_c4 = puVar7[3];
  uStack_c0 = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  piVar8 = (int *)(param_2 + 0x84);
  uStack_8._0_1_ = 4;
  if (0xf < *(uint *)(param_2 + 0x98)) {
    piVar8 = (int *)*piVar8;
  }
  puVar7 = (uint *)FUN_00554150(piVar8,*(undefined4 *)(param_2 + 0x94));
  uStack_b8 = *puVar7;
  uStack_b4 = puVar7[1];
  uStack_b0 = puVar7[2];
  uStack_ac = puVar7[3];
  uStack_a8 = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  uStack_8._0_1_ = 5;
  puVar7 = (uint *)FUN_00554150(&DAT_018d1b9c,1);
  uStack_a0 = *puVar7;
  uStack_9c = puVar7[1];
  uStack_98 = puVar7[2];
  uStack_94 = puVar7[3];
  uStack_90 = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  piVar8 = (int *)(param_2 + 0x9c);
  uStack_8._0_1_ = 6;
  if (0xf < *(uint *)(param_2 + 0xb0)) {
    piVar8 = (int *)*piVar8;
  }
  puVar7 = (uint *)FUN_00554150(piVar8,*(undefined4 *)(param_2 + 0xac));
  uStack_88 = *puVar7;
  uStack_84 = puVar7[1];
  uStack_80 = puVar7[2];
  uStack_7c = puVar7[3];
  uStack_78 = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  uStack_8._0_1_ = 7;
  puVar7 = (uint *)FUN_00554150(&DAT_018d1b9c,1);
  uStack_70 = *puVar7;
  uStack_6c = puVar7[1];
  uStack_68 = puVar7[2];
  uStack_64 = puVar7[3];
  uStack_60 = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  uStack_8._0_1_ = 8;
  if (0xf < *(uint *)(param_2 + 0xcc)) {
    piVar13 = (int *)*piVar13;
  }
  puVar7 = (uint *)FUN_00554150(piVar13,*(undefined4 *)(param_2 + 200));
  uStack_58 = *puVar7;
  uStack_54 = puVar7[1];
  uStack_50 = puVar7[2];
  uStack_4c = puVar7[3];
  uStack_48 = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  uStack_8._0_1_ = 9;
  piVar8 = (int *)FUN_00554150(&DAT_018d1b9c,1);
  pppuStack_28 = (undefined4 ***)*piVar8;
  iStack_24 = piVar8[1];
  iStack_20 = piVar8[2];
  iStack_1c = piVar8[3];
  uVar1 = *(undefined8 *)(piVar8 + 4);
  piVar8[4] = 0;
  piVar8[5] = 0xf;
  *(undefined *)piVar8 = 0;
  uStack_18._4_4_ = (uint)((ulonglong)uVar1 >> 0x20);
  uStack_18._0_4_ = (uint)uVar1;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  uStack_18 = uVar1;
  if ((uStack_18._4_4_ - (uint)uStack_18 < uStack_30) && ((uint)uStack_18 <= uStack_2c - uStack_30))
  {
    ppppuVar9 = &pppuStack_28;
    if (0xf < uStack_18._4_4_) {
      ppppuVar9 = (undefined4 ****)pppuStack_28;
    }
    uVar11 = (uint)uStack_18;
    puVar10 = (undefined4 *)FUN_00585d40(0,ppppuVar9,uVar11);
  }
  else {
    ppppuVar9 = apppuStack_40;
    if (0xf < uStack_2c) {
      ppppuVar9 = (undefined4 ****)apppuStack_40[0];
    }
    puVar10 = (undefined4 *)FUN_00554150(ppppuVar9,uStack_30);
  }
  param_1[4] = 0;
  param_1[5] = 0;
  uVar2 = puVar10[1];
  uVar3 = puVar10[2];
  uVar4 = puVar10[3];
  *param_1 = *puVar10;
  param_1[1] = uVar2;
  param_1[2] = uVar3;
  param_1[3] = uVar4;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar10 + 4);
  puVar10[4] = 0;
  puVar10[5] = 0xf;
  *(undefined *)puVar10 = 0;
  if (0xf < uStack_18._4_4_) {
    uVar11 = uStack_18._4_4_ + 1;
    ppppuVar9 = (undefined4 ****)pppuStack_28;
    if (0xfff < uVar11) {
      ppppuVar9 = (undefined4 ****)pppuStack_28[-1];
      uVar11 = uStack_18._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_28 + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar11);
  }
  uStack_18 = 0xf00000000;
  pppuStack_28 = (undefined4 ***)((uint)pppuStack_28 & 0xffffff00);
  if (0xf < uStack_48._4_4_) {
    uVar12 = uStack_48._4_4_ + 1;
    uVar11 = uStack_58;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_58 - 4);
      uVar12 = uStack_48._4_4_ + 0x24;
      if (0x1f < (uStack_58 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_48 = 0xf00000000;
  uStack_58 = uStack_58 & 0xffffff00;
  if (0xf < uStack_60._4_4_) {
    uVar12 = uStack_60._4_4_ + 1;
    uVar11 = uStack_70;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_70 - 4);
      uVar12 = uStack_60._4_4_ + 0x24;
      if (0x1f < (uStack_70 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_60 = 0xf00000000;
  uStack_70 = uStack_70 & 0xffffff00;
  if (0xf < uStack_78._4_4_) {
    uVar12 = uStack_78._4_4_ + 1;
    uVar11 = uStack_88;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_88 - 4);
      uVar12 = uStack_78._4_4_ + 0x24;
      if (0x1f < (uStack_88 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_78 = 0xf00000000;
  uStack_88 = uStack_88 & 0xffffff00;
  if (0xf < uStack_90._4_4_) {
    uVar12 = uStack_90._4_4_ + 1;
    uVar11 = uStack_a0;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_a0 - 4);
      uVar12 = uStack_90._4_4_ + 0x24;
      if (0x1f < (uStack_a0 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_90 = 0xf00000000;
  uStack_a0 = uStack_a0 & 0xffffff00;
  if (0xf < uStack_a8._4_4_) {
    uVar12 = uStack_a8._4_4_ + 1;
    uVar11 = uStack_b8;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_b8 - 4);
      uVar12 = uStack_a8._4_4_ + 0x24;
      if (0x1f < (uStack_b8 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_a8 = 0xf00000000;
  uStack_b8 = uStack_b8 & 0xffffff00;
  if (0xf < uStack_c0._4_4_) {
    uVar12 = uStack_c0._4_4_ + 1;
    uVar11 = uStack_d0;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_d0 - 4);
      uVar12 = uStack_c0._4_4_ + 0x24;
      if (0x1f < (uStack_d0 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_c0 = 0xf00000000;
  uStack_d0 = uStack_d0 & 0xffffff00;
  if (0xf < uStack_d8._4_4_) {
    uVar12 = uStack_d8._4_4_ + 1;
    uVar11 = uStack_e8;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_e8 - 4);
      uVar12 = uStack_d8._4_4_ + 0x24;
      if (0x1f < (uStack_e8 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_d8 = 0xf00000000;
  uStack_e8 = uStack_e8 & 0xffffff00;
  if (0xf < uStack_f0._4_4_) {
    uVar12 = uStack_f0._4_4_ + 1;
    uVar11 = uStack_100;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(uStack_100 - 4);
      uVar12 = uStack_f0._4_4_ + 0x24;
      if (0x1f < (uStack_100 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_f0 = 0xf00000000;
  uStack_100 = uStack_100 & 0xffffff00;
  if (0xf < uStack_104) {
    uVar12 = uStack_104 + 1;
    uVar11 = auStack_118[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_118[0] - 4);
      uVar12 = uStack_104 + 0x24;
      if (0x1f < (auStack_118[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_108 = 0;
  uStack_104 = 0xf;
  auStack_118[0] = auStack_118[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar11 = uStack_2c + 1;
    ppppuVar9 = (undefined4 ****)apppuStack_40[0];
    if (0xfff < uVar11) {
      ppppuVar9 = (undefined4 ****)apppuStack_40[0][-1];
      uVar11 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar11);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10777 ; VA 0x00764100 ; FUN_00764100 */

void FUN_00764100(undefined4 *param_1,int param_2)

{
  if (param_2 < 0x371) {
    if (param_2 == 0x370) {
      *param_1 = 0x78;
      return;
    }
    if (param_2 < 0x311) {
      if (param_2 == 0x310) {
        *param_1 = 0x32;
        return;
      }
      if (param_2 < 0x121) {
        if (param_2 == 0x120) {
          *param_1 = 0x92;
          return;
        }
        if (param_2 == 0x100) {
          *param_1 = 0x99;
          return;
        }
        if (param_2 == 0x110) {
          *param_1 = 0x3c;
          return;
        }
      }
      else {
        if (param_2 == 0x200) goto switchD_00764195_caseD_340;
        if (param_2 == 0x210) {
          *param_1 = 0x5a;
          return;
        }
      }
    }
    else {
      switch(param_2) {
      case 800:
        *param_1 = 0xaa;
        return;
      case 0x330:
        *param_1 = 0x8c;
        return;
      case 0x340:
switchD_00764195_caseD_340:
        *param_1 = 100;
        return;
      case 0x350:
        *param_1 = 0xc4;
        return;
      case 0x360:
        *param_1 = 0xb4;
        return;
      }
    }
  }
  else if (param_2 < 0x511) {
    if (param_2 == 0x510) {
      *param_1 = 0xbc;
      return;
    }
    switch(param_2) {
    case 0x410:
      *param_1 = &LAB_00500064;
      return;
    case 0x420:
      *param_1 = 0xff0050;
      return;
    case 0x430:
      *param_1 = 0xff004e;
      return;
    case 0x440:
      *param_1 = 0xff0044;
      return;
    case 0x500:
      *param_1 = 0x6e;
      return;
    }
  }
  else {
    if (param_2 < 0x621) {
      if (param_2 != 0x620) {
        if (param_2 == 0x520) {
          *param_1 = 0xeb;
          return;
        }
        if (param_2 != 0x600) goto switchD_00764195_caseD_321;
      }
      *param_1 = 0x28;
      return;
    }
    if (param_2 == 0x630) {
      *param_1 = 0x55;
      return;
    }
    if (param_2 == 0x700) {
      *param_1 = 1;
      return;
    }
  }
switchD_00764195_caseD_321:
  *param_1 = 0;
  return;
}



/* FUNCTION 10778 ; VA 0x00764410 ; FUN_00764410 */

undefined4 __fastcall FUN_00764410(int *param_1)

{
  if (*param_1 != 0) {
    return *(undefined4 *)(*param_1 + 8);
  }
  return 0;
}



/* FUNCTION 10779 ; VA 0x00764430 ; FUN_00764430 */

uint FUN_00764430(uint param_1)

{
  uint uVar1;
  
  if ((int)param_1 < 0x371) {
    if (param_1 == 0x370) {
      return param_1;
    }
    if (0x310 < (int)param_1) {
      if (0x40 < param_1 - 800) {
        return param_1 - 800;
      }
      uVar1 = (uint)*(byte *)(param_1 + 0x7641fc);
      switch(param_1) {
      case 800:
      case 0x340:
      case 0x360:
        goto switchD_00764498_caseD_320;
      default:
        return uVar1;
      case 0x330:
switchD_00764498_caseD_330:
        return uVar1;
      case 0x350:
        return uVar1;
      }
    }
    if (param_1 == 0x310) {
      return 0x310;
    }
    if ((int)param_1 < 0x121) {
      if (param_1 == 0x120) {
        return 0x120;
      }
      if (param_1 == 0x100) {
        return 0;
      }
      return param_1 - 0x110;
    }
    uVar1 = param_1 - 0x200;
    if (uVar1 != 0) {
      if (param_1 - 0x210 != 0) {
        return param_1 - 0x210;
      }
      return 0;
    }
switchD_007644c3_caseD_420:
    return uVar1;
  }
  uVar1 = param_1;
  if ((int)param_1 < 0x511) {
    if (param_1 == 0x510) {
switchD_00764498_caseD_320:
      return uVar1;
    }
    uVar1 = param_1 - 0x410;
    if (param_1 - 0x410 < 0xf1) {
      uVar1 = (uint)*(byte *)(param_1 + 0x764160);
      switch(param_1) {
      case 0x410:
      case 0x430:
        goto switchD_00764498_caseD_320;
      case 0x420:
      case 0x440:
        goto switchD_007644c3_caseD_420;
      case 0x500:
        goto switchD_00764498_caseD_330;
      }
    }
  }
  else if ((int)param_1 < 0x621) {
    if (param_1 == 0x620) {
      return param_1;
    }
    if (param_1 == 0x520) {
      return 0x520;
    }
    if (param_1 == 0x600) {
      return 0x600;
    }
  }
  else if (param_1 == 0x630) {
    return param_1;
  }
  return uVar1;
}



/* FUNCTION 10780 ; VA 0x00764670 ; FUN_00764670 */

float10 __fastcall FUN_00764670(int param_1)

{
  return (float10)*(float *)(param_1 + 0x94);
}



/* FUNCTION 10781 ; VA 0x00764680 ; FUN_00764680 */

int FUN_00764680(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  uStack_10 = 0;
  uStack_c = 0;
  piStack_8 = (int *)0x0;
  iVar4 = FUN_0075c2e0(&uStack_10);
  piVar3 = piStack_8;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_8 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar4;
}



/* FUNCTION 10782 ; VA 0x007646e0 ; FUN_007646e0 */

/* WARNING: Removing unreachable block (ram,0x007647be) */
/* WARNING: Removing unreachable block (ram,0x007647c7) */
/* WARNING: Removing unreachable block (ram,0x007647d6) */
/* WARNING: Removing unreachable block (ram,0x00764798) */
/* WARNING: Removing unreachable block (ram,0x007647a1) */
/* WARNING: Removing unreachable block (ram,0x007647b0) */
/* WARNING: Removing unreachable block (ram,0x007647e4) */
/* WARNING: Removing unreachable block (ram,0x007647ed) */
/* WARNING: Removing unreachable block (ram,0x007647fb) */

undefined4
FUN_007646e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0075e600(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 10783 ; VA 0x00764820 ; FUN_00764820 */

bool FUN_00764820(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined8 uVar9;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
        uVar3 = FUN_00560c40();
        piVar4 = (int *)FUN_008aa140(uVar3);
        if (*piVar4 == 0) {
          uVar3 = FUN_00961660();
          piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
          iVar1 = *piVar5;
          iVar2 = piVar5[1];
          *piVar5 = 0;
          piVar5[1] = 0;
          *piVar4 = iVar1;
          piVar5 = (int *)piVar4[1];
          piVar4[1] = iVar2;
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar1 = piVar5[1] + -1;
            piVar5[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              iVar1 = piVar5[2] + -1;
              piVar5[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          if (piStack_8 != (int *)0x0) {
            LOCK();
            iVar1 = piStack_8[1] + -1;
            piStack_8[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piStack_8)();
              LOCK();
              piVar5 = piStack_8 + 2;
              iVar1 = *piVar5;
              *piVar5 = *piVar5 + -1;
              UNLOCK();
              if (iVar1 == 1) {
                (**(code **)(*piStack_8 + 4))();
              }
            }
          }
        }
        iVar1 = DAT_01eb01d8;
        if ((*piVar4 != 0) && (*(int *)(*piVar4 + 0xf4) != 0)) {
          uVar9 = FUN_00928340();
          uVar7 = (uint)((ulonglong)uVar9 >> 0x20);
          uVar8 = (int)uVar7 >> 0x1f;
          uVar6 = (uint)uVar9 ^ uVar8;
          iVar2 = FUN_016f4270(uVar6 - uVar8,((uVar7 ^ uVar8) - uVar8) - (uint)(uVar6 < uVar8),100,0
                              );
          return iVar2 < iVar1;
        }
      }
    }
  }
  return false;
}



/* FUNCTION 10784 ; VA 0x00764960 ; FUN_00764960 */

code * FUN_00764960(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined3 uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  code *pcVar7;
  int *piVar8;
  code *apcStack_5c [2];
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ae0ca;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01674e20(0x58);
  uStack_8 = 0;
  iStack_18 = iVar4;
  if (iVar4 == 0) {
    iVar4 = 0;
  }
  else {
    FUN_016dee4c(iVar4,2);
    *(undefined4 *)(iVar4 + 0x30) = 0;
    *(undefined *)(iVar4 + 0x34) = 0;
    *(bool *)(iVar4 + 0x35) = *(int *)(param_1 + 100) != 0;
    *(bool *)(iVar4 + 0x36) = *(int *)(param_1 + 0xb4) == 0;
    *(undefined4 *)(iVar4 + 0x38) = 0;
    *(undefined4 *)(iVar4 + 0x3c) = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar8 = (int *)(param_2[1] + 8);
      *piVar8 = *piVar8 + 1;
      UNLOCK();
    }
    *(undefined4 *)(iVar4 + 0x38) = *param_2;
    *(undefined4 *)(iVar4 + 0x3c) = param_2[1];
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_0054ef60(param_1 + 0xb8);
    if (*(char *)(iVar4 + 0x35) != '\0') {
      *(int *)(iVar4 + 0x30) = *(int *)(iVar4 + 0x30) + 1;
    }
    if (*(int *)(param_1 + 0x7c) != 0) {
      *(int *)(iVar4 + 0x30) = *(int *)(iVar4 + 0x30) + 1;
    }
    if (*(int *)(param_1 + 0x94) != 0) {
      *(int *)(iVar4 + 0x30) = *(int *)(iVar4 + 0x30) + 1;
    }
    if (*(int *)(param_1 + 0xac) != 0) {
      *(int *)(iVar4 + 0x30) = *(int *)(iVar4 + 0x30) + 1;
    }
  }
  uStack_8 = 0xffffffff;
  uStack_24 = 0;
  piStack_20 = (int *)0x0;
  FUN_0075cc00(iVar4,param_1);
  piVar2 = piStack_20;
  piVar8 = *(int **)(iStack_14 + 8);
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[2] = piVar8[2] + 1;
    UNLOCK();
    piVar8 = *(int **)(iStack_14 + 8);
  }
  uVar6 = *(undefined4 *)(iStack_14 + 4);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[1] = piStack_20[1] + 1;
    UNLOCK();
  }
  uStack_3c = uStack_24;
  piStack_38 = piStack_20;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[2] = piVar8[2] + 1;
    UNLOCK();
  }
  iStack_18 = param_1 + 0x54;
  uStack_8._1_3_ = 0;
  uVar3 = uStack_8._1_3_;
  uStack_8._0_1_ = 5;
  uStack_8._1_3_ = 0;
  uStack_34 = uVar6;
  piStack_30 = piVar8;
  uStack_2c = uVar6;
  piStack_28 = piVar8;
  if (*(int *)(param_1 + 100) != 0) {
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[2] = piVar8[2] + 1;
      UNLOCK();
    }
    FUN_0075c1e0(uStack_24,piStack_20,uVar6,piVar8,0);
    uStack_8._0_1_ = 6;
    uVar5 = FUN_008ccda0();
    FUN_008cd330(iStack_18,0x3f800000,apcStack_5c,uVar5,&DAT_01d62f20,0,1);
    uStack_8._0_1_ = 7;
    uVar3 = uStack_8._1_3_;
    if (((apcStack_5c[0] != (code *)0x0) && (((uint)apcStack_5c[0] & 1) == 0)) &&
       (*(code **)((uint)apcStack_5c[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)apcStack_5c[0] & 0xfffffffe))(auStack_54,auStack_54,2);
      uVar3 = uStack_8._1_3_;
    }
  }
  uStack_8._1_3_ = uVar3;
  uStack_8._0_1_ = 5;
  iStack_18 = param_1 + 0x6c;
  if (*(int *)(param_1 + 0x7c) != 0) {
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[2] = piVar8[2] + 1;
      UNLOCK();
    }
    FUN_0075c1e0(uStack_24,piVar2,uVar6,piVar8,0);
    uStack_8._0_1_ = 8;
    uVar5 = FUN_008ccda0();
    FUN_008cd330(iStack_18,0x3f800000,apcStack_5c,uVar5,&DAT_01d62f20,0,1);
    uStack_8._0_1_ = 9;
    if (((apcStack_5c[0] != (code *)0x0) && (((uint)apcStack_5c[0] & 1) == 0)) &&
       (*(code **)((uint)apcStack_5c[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)apcStack_5c[0] & 0xfffffffe))(auStack_54,auStack_54,2);
    }
  }
  uStack_8._0_1_ = 5;
  iStack_18 = param_1 + 0x84;
  if (*(int *)(param_1 + 0x94) != 0) {
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[2] = piVar8[2] + 1;
      UNLOCK();
    }
    FUN_0075c1e0(uStack_24,piVar2,uVar6,piVar8,0);
    uStack_8._0_1_ = 10;
    uVar5 = FUN_008ccda0();
    FUN_008cd330(iStack_18,0x3f800000,apcStack_5c,uVar5,&DAT_01d62f20,0,1);
    uStack_8._0_1_ = 0xb;
    if (((apcStack_5c[0] != (code *)0x0) && (((uint)apcStack_5c[0] & 1) == 0)) &&
       (*(code **)((uint)apcStack_5c[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)apcStack_5c[0] & 0xfffffffe))(auStack_54,auStack_54,2);
    }
  }
  uStack_8._0_1_ = 5;
  pcVar7 = (code *)(param_1 + 0x9c);
  if (*(int *)(param_1 + 0xac) != 0) {
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[2] = piVar8[2] + 1;
      UNLOCK();
    }
    FUN_0075c1e0(uStack_24,piVar2,uVar6,piVar8,0);
    uStack_8._0_1_ = 0xc;
    uVar6 = FUN_008ccda0();
    FUN_008cd330((code *)(param_1 + 0x9c),0x3f800000,apcStack_5c,uVar6,&DAT_01d62f20,0,1);
    uStack_8._0_1_ = 0xd;
    pcVar7 = apcStack_5c[0];
    if (((apcStack_5c[0] != (code *)0x0) && (((uint)apcStack_5c[0] & 1) == 0)) &&
       (pcVar7 = *(code **)((uint)apcStack_5c[0] & 0xfffffffe), pcVar7 != (code *)0x0)) {
      pcVar7 = (code *)(*pcVar7)(auStack_54,auStack_54,2);
    }
  }
  if (piVar8 != (int *)0x0) {
    piVar1 = piVar8 + 2;
    LOCK();
    iVar4 = *piVar1;
    pcVar7 = (code *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      pcVar7 = (code *)(**(code **)(*piVar8 + 4))();
    }
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar4 = *piVar1;
    pcVar7 = (code *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      pcVar7 = (code *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        pcVar7 = (code *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piVar8 != (int *)0x0) {
    piVar1 = piVar8 + 2;
    LOCK();
    iVar4 = *piVar1;
    pcVar7 = (code *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      pcVar7 = (code *)(**(code **)(*piVar8 + 4))();
    }
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar8 = piVar2 + 1;
    iVar4 = *piVar8;
    pcVar7 = (code *)*piVar8;
    *piVar8 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      pcVar7 = (code *)(**(code **)*piVar2)();
      LOCK();
      piVar8 = piVar2 + 2;
      iVar4 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar7 = (code *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar7;
}



/* FUNCTION 10785 ; VA 0x00764e20 ; FUN_00764e20 */

int * FUN_00764e20(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 == 1) {
        piVar4 = (int *)param_1[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            piVar3 = (int *)(**(code **)(*piVar4 + 4))();
          }
        }
        piVar4 = (int *)param_1[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 1;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            piVar3 = (int *)(**(code **)*piVar4)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00764f07. Too many branches */
                    /* WARNING: Treating indirect jump as call */
              piVar3 = (int *)(**(code **)(*piVar4 + 4))();
              return piVar3;
            }
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_0075ed30(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d9f4b0);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_6b108a74a827ec0fc8ea15475243468f>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 10786 ; VA 0x00764f20 ; FUN_00764f20 */

void FUN_00764f20(int *param_1,int param_2,undefined *param_3,undefined4 param_4,undefined4 param_5,
                 char param_6)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  bool bVar4;
  int *piVar5;
  int iVar6;
  undefined *puVar7;
  uint *puVar8;
  undefined2 auStack_64 [2];
  undefined4 uStack_60;
  undefined2 uStack_5c;
  undefined2 auStack_58 [2];
  undefined4 uStack_54;
  undefined2 uStack_50;
  undefined2 auStack_4c [2];
  undefined4 uStack_48;
  undefined2 uStack_44;
  undefined2 auStack_40 [2];
  undefined4 uStack_3c;
  undefined2 uStack_38;
  undefined2 auStack_34 [2];
  undefined4 uStack_30;
  undefined2 uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ae0f9;
  pvStack_10 = ExceptionList;
  bVar4 = false;
  iStack_20 = 3;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  do {
    iVar6 = *param_1;
    uStack_14 = 0;
    iVar3 = param_1[1] - iVar6 >> 0x1f;
    if ((param_1[1] - iVar6) / 0x50 + iVar3 != iVar3) {
      iStack_18 = 0;
      do {
        puVar8 = (uint *)(iVar6 + iStack_18);
        uVar2 = puVar8[1];
        if (((uVar2 == 2) || (uVar2 == 5)) || (uVar2 == 4)) {
          iVar6 = FUN_00764410();
          if (iVar6 != 0) {
            auStack_64[0] = 1;
            uStack_60 = 0;
            uStack_5c = 0;
            puVar7 = param_3;
            if (param_6 != '\0') {
              FUN_007735a0(param_2 + 0x24,3);
              bVar4 = true;
              uStack_8 = 0;
              uStack_1c = 1;
              puVar7 = auStack_28;
            }
            FUN_0078e550(3,puVar7,auStack_64);
            piVar5 = piStack_24;
            uStack_8 = 0xffffffff;
            if (bVar4) {
              bVar4 = false;
              uStack_1c = 0;
              if (piStack_24 != (int *)0x0) {
                LOCK();
                iVar6 = piStack_24[1] + -1;
                piStack_24[1] = iVar6;
                UNLOCK();
                if (iVar6 == 0) {
                  (**(code **)*piStack_24)();
                  LOCK();
                  piVar1 = piVar5 + 2;
                  iVar6 = *piVar1 + -1;
                  *piVar1 = iVar6;
                  UNLOCK();
                  if (iVar6 == 0) {
                    (**(code **)(*piVar5 + 4))();
                  }
                }
              }
            }
          }
        }
        else {
          iVar6 = FUN_00764410();
          if (*puVar8 < 2) {
            if (iVar6 != 0) {
              auStack_40[0] = 2;
              uStack_3c = 0;
              uStack_38 = 0;
              FUN_0078e550(3,param_3,auStack_40);
            }
            iVar6 = FUN_00764410();
            if (iVar6 != 0) {
              auStack_4c[0] = 2;
              uStack_48 = 0;
              uStack_44 = 0;
              FUN_0078e550(4,param_4,auStack_4c);
            }
            iVar6 = FUN_00764410();
            if (iVar6 != 0) {
              auStack_58[0] = 2;
              uStack_54 = 0;
              uStack_50 = 0;
              FUN_0078e550(5,param_5,auStack_58);
            }
          }
          else if (iVar6 != 0) {
            auStack_34[0] = 1;
            uStack_30 = 0;
            uStack_2c = 0;
            FUN_0078e550(3,param_3,auStack_34);
          }
        }
        uStack_14 = uStack_14 + 1;
        iStack_18 = iStack_18 + 0x50;
        iVar6 = *param_1;
      } while (uStack_14 < (uint)((param_1[1] - iVar6) / 0x50));
    }
    param_1 = param_1 + 3;
    iStack_20 = iStack_20 + -1;
  } while (iStack_20 != 0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10787 ; VA 0x00765150 ; FUN_00765150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00765150(undefined4 param_1,int param_2,int param_3)

{
  undefined8 uVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  float *pfVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  float fVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined *puVar15;
  undefined4 uVar16;
  undefined auStack_10c [12];
  float fStack_100;
  undefined4 uStack_fc;
  float fStack_f8;
  float fStack_f4;
  undefined auStack_f0 [16];
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined auStack_d8 [8];
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined auStack_c0 [8];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  int iStack_a8;
  int iStack_a4;
  int iStack_a0;
  int *piStack_9c;
  int *piStack_98;
  float *pfStack_94;
  int iStack_90;
  float fStack_8c;
  undefined8 uStack_88;
  float fStack_80;
  float fStack_7c;
  undefined8 uStack_78;
  float fStack_70;
  int *piStack_6c;
  int *piStack_68;
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  uint auStack_4c [2];
  undefined auStack_44 [8];
  undefined4 uStack_3c;
  uint uStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  char cStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ae2b2;
  pvStack_1c = ExceptionList;
  iStack_a0 = *(int *)(param_2 + 0x10);
  piStack_68 = *(int **)(param_2 + 4);
  if (((iStack_a0 != 0) || (iStack_a0 = *(int *)(param_2 + 0x14), iStack_a0 != 0)) ||
     (iStack_a0 = *(int *)(param_2 + 0x20), ExceptionList = &pvStack_1c, puVar15 = &stack0xfffffffc,
     iStack_a0 != 0)) {
    fStack_7c = DAT_01eb0208 * DAT_018fabf0;
    fStack_70 = DAT_01eb0214;
    uStack_78 = CONCAT44(DAT_01eb0210,((DAT_018ce2f8 - _DAT_01eb020c) - DAT_01eb0214) * DAT_018fabf0
                        );
    ExceptionList = &pvStack_1c;
    uVar3 = FUN_00b06fb0(&uStack_88);
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
    uStack_14 = 0;
    FUN_009cbbb0(auStack_4c);
    uStack_14 = 1;
    FUN_0075f2f0(auStack_4c,uVar3,fStack_7c,(float)uStack_78,uStack_78._4_4_,fStack_70);
    uStack_14 = 0xffffffff;
    puVar15 = puStack_20;
    if (0xf < uStack_38) {
      uVar10 = uStack_38 + 1;
      uVar9 = auStack_4c[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_4c[0] - 4);
        uVar10 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
      puVar15 = puStack_20;
    }
  }
  puStack_20 = puVar15;
  iStack_a4 = *(int *)(param_2 + 0x18);
  if (((iStack_a4 != 0) || (iStack_a4 = *(int *)(param_2 + 0x1c), iStack_a4 != 0)) ||
     (iStack_a4 = *(int *)(param_2 + 0x24), iStack_a4 != 0)) {
    fStack_7c = DAT_01eb0218 * DAT_018fabf0;
    fStack_70 = DAT_01eb0224;
    uStack_78 = CONCAT44(DAT_01eb0220,((DAT_018ce2f8 - _DAT_01eb021c) - DAT_01eb0224) * DAT_018fabf0
                        );
    uVar3 = FUN_00b06fb0(&uStack_88);
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
    uStack_14 = 2;
    FUN_009cbbb0(auStack_4c);
    uStack_14 = 3;
    FUN_0075f2f0(auStack_4c,uVar3,fStack_7c,(float)uStack_78,uStack_78._4_4_,fStack_70);
    uStack_14 = 0xffffffff;
    if (0xf < uStack_38) {
      uVar10 = uStack_38 + 1;
      uVar9 = auStack_4c[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_4c[0] - 4);
        uVar10 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
  }
  iStack_a8 = *(int *)(param_2 + 0x28);
  if (((iStack_a8 != 0) || (iStack_a8 = *(int *)(param_2 + 0x2c), iStack_a8 != 0)) ||
     (iStack_a8 = *(int *)(param_2 + 0x38), iStack_a8 != 0)) {
    fStack_7c = DAT_01eb0228 * DAT_018fabf0;
    fStack_70 = DAT_01eb0234;
    uStack_78 = CONCAT44(DAT_01eb0230,((DAT_018ce2f8 - _DAT_01eb022c) - DAT_01eb0234) * DAT_018fabf0
                        );
    uVar3 = FUN_00b06fb0(&uStack_88);
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
    uStack_14 = 4;
    FUN_009cbbb0(auStack_4c);
    uStack_14 = 5;
    FUN_0075f2f0(auStack_4c,uVar3,fStack_7c,(float)uStack_78,uStack_78._4_4_,fStack_70);
    uStack_14 = 0xffffffff;
    if (0xf < uStack_38) {
      uVar10 = uStack_38 + 1;
      uVar9 = auStack_4c[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_4c[0] - 4);
        uVar10 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
  }
  iStack_90 = *(int *)(param_2 + 0x30);
  if (((iStack_90 != 0) || (iStack_90 = *(int *)(param_2 + 0x34), iStack_90 != 0)) ||
     (iStack_90 = *(int *)(param_2 + 0x3c), iStack_90 != 0)) {
    fStack_7c = DAT_01eb0238 * DAT_018fabf0;
    fStack_70 = DAT_01eb0244;
    uStack_78 = CONCAT44(DAT_01eb0240,((DAT_018ce2f8 - _DAT_01eb023c) - DAT_01eb0244) * DAT_018fabf0
                        );
    uVar3 = FUN_00b06fb0(&uStack_88);
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
    uStack_14 = 6;
    FUN_009cbbb0(auStack_4c);
    uStack_14 = 7;
    FUN_0075f2f0(auStack_4c,uVar3,fStack_7c,(float)uStack_78,uStack_78._4_4_,fStack_70);
    uStack_14 = 0xffffffff;
    if (0xf < uStack_38) {
      uVar10 = uStack_38 + 1;
      uVar9 = auStack_4c[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_4c[0] - 4);
        uVar10 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
  }
  pfStack_94 = *(float **)(param_2 + 8);
  if ((pfStack_94 != (float *)0x0) ||
     (pfStack_94 = *(float **)(param_2 + 0xc), pfStack_94 != (float *)0x0)) {
    fStack_7c = DAT_01eb01f8 * DAT_018fabf0;
    fStack_70 = DAT_01eb0204;
    uStack_78 = CONCAT44(DAT_01eb0200,((DAT_018ce2f8 - _DAT_01eb01fc) - DAT_01eb0204) * DAT_018fabf0
                        );
    uVar3 = FUN_00b06fb0(&uStack_88);
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
    uStack_14 = 8;
    FUN_009cbbb0(auStack_4c);
    uStack_14 = 9;
    FUN_0075f2f0(auStack_4c,uVar3,fStack_7c,(float)uStack_78,uStack_78._4_4_,fStack_70);
    uStack_14 = 0xffffffff;
    if (0xf < uStack_38) {
      uVar10 = uStack_38 + 1;
      uVar9 = auStack_4c[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_4c[0] - 4);
        uVar10 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
  }
  cStack_21 = '\x01';
  if (piStack_68 == (int *)0x0) goto LAB_00765d10;
  iVar8 = piStack_68[3];
  iVar4 = FUN_00cfb1a0();
  fStack_7c = DAT_01eb0248 * DAT_018fabf0;
  fStack_70 = DAT_01eb0254;
  piStack_98 = (int *)0x0;
  if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
      (uint)*(ushort *)(iVar4 + 0x1da)) {
    piStack_98 = piStack_68;
  }
  uStack_78 = CONCAT44(DAT_01eb0250,((DAT_018ce2f8 - _DAT_01eb024c) - DAT_01eb0254) * DAT_018fabf0);
  uVar3 = FUN_00b06fb0(&uStack_88);
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
  uStack_14 = 10;
  FUN_009cbbb0(auStack_4c);
  uStack_14 = 0xb;
  FUN_0075f2f0(auStack_4c,uVar3,fStack_7c,(float)uStack_78,uStack_78._4_4_,fStack_70);
  uStack_14 = 0xffffffff;
  if (0xf < uStack_38) {
    uVar10 = uStack_38 + 1;
    uVar9 = auStack_4c[0];
    if (0xfff < uVar10) {
      uVar9 = *(uint *)(auStack_4c[0] - 4);
      uVar10 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar10);
  }
  if (piStack_98 == (int *)0x0) {
    piStack_6c = (int *)FUN_00d011a0(piStack_68);
    piStack_9c = (int *)FUN_0075d530(piStack_6c);
    if (piStack_9c != (int *)0x0) {
      uStack_54 = 0;
      uStack_50 = 0xf;
      auStack_64[0] = 0;
      FUN_005542c0("NoFace",6);
      puVar15 = auStack_64;
      uStack_14 = 0x10;
      puVar5 = (undefined4 *)FUN_0060dcd0((int)&uStack_88 + 4,piStack_6c,puVar15);
      uStack_14 = CONCAT31(uStack_14._1_3_,0x11);
      uVar3 = *puVar5;
      uVar13 = puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      cVar2 = FUN_00d13c80(uVar3,uVar13,puVar15);
      cStack_21 = cVar2 == '\0';
      FUN_00550b30();
      uStack_14 = 0xffffffff;
      FUN_005507b0();
    }
    if ((piStack_6c != (int *)0x0) && (piStack_9c = piStack_6c + 0x20, piStack_6c[0x24] != 0)) {
      fStack_8c = DAT_01eb0248 * DAT_018fabf0;
      fStack_80 = DAT_01eb0254;
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      uStack_88 = CONCAT44(DAT_01eb0250,
                           ((DAT_018ce2f8 - _DAT_01eb024c) - DAT_01eb0254) * DAT_018fabf0);
      FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
      uStack_14 = 0x12;
      FUN_009cbbb0(auStack_4c);
      uStack_14 = 0x13;
      piVar11 = piStack_9c;
      goto LAB_00765acb;
    }
  }
  else {
    piStack_6c = (int *)FUN_0075d530(piStack_98);
    if (piStack_6c != (int *)0x0) {
      uStack_54 = 0;
      uStack_50 = 0xf;
      auStack_64[0] = 0;
      FUN_005542c0("NoFace",6);
      puVar15 = auStack_64;
      uStack_14 = 0xc;
      puVar5 = (undefined4 *)FUN_0060dcd0((int)&uStack_78 + 4,piStack_98,puVar15);
      uStack_14 = CONCAT31(uStack_14._1_3_,0xd);
      uVar3 = *puVar5;
      uVar13 = puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      cVar2 = FUN_00d13c80(uVar3,uVar13,puVar15);
      cStack_21 = cVar2 == '\0';
      FUN_00550b30();
      uStack_14 = 0xffffffff;
      FUN_005507b0();
    }
    piStack_6c = piStack_98 + 0x5b;
    if (piStack_98[0x5f] != 0) {
      fStack_8c = DAT_01eb0248 * DAT_018fabf0;
      fStack_80 = DAT_01eb0254;
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      uStack_88 = CONCAT44(DAT_01eb0250,
                           ((DAT_018ce2f8 - _DAT_01eb024c) - DAT_01eb0254) * DAT_018fabf0);
      FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
      uStack_14 = 0xe;
      FUN_009cbbb0(auStack_4c);
      uStack_14 = 0xf;
      piVar11 = piStack_6c;
LAB_00765acb:
      FUN_0075f850(auStack_4c,piVar11,fStack_8c,(float)uStack_88,uStack_88._4_4_,fStack_80,0);
      uStack_14 = 0xffffffff;
      FUN_005507b0();
    }
  }
  if (((cStack_21 != '\0') &&
      (piVar11 = (int *)piStack_68[0xb], piStack_68 = piVar11, piVar11 != (int *)0x0)) &&
     (piStack_6c = (int *)(piVar11[1] - *piVar11 >> 3), piStack_6c != (int *)0x0)) {
    do {
      iVar8 = *(int *)(*piVar11 + -8 + (int)piStack_6c * 8);
      if (((iVar8 != 0) &&
          (iVar4 = *(int *)(iVar8 + 0xc), iVar6 = FUN_00cffc50(), piVar11 = piStack_68,
          (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da))) &&
         ((*(int *)(iVar8 + 0x70) == 5 && (*(int *)(iVar8 + 0x84) != 0)))) {
        if (piStack_98 == (int *)0x0) {
          FUN_007637a0(&uStack_b8,param_2,0);
          uVar1 = *(undefined8 *)(iVar8 + 0x9c);
          fStack_28 = DAT_018ce2f8 - *(float *)(iVar8 + 0x94);
          fStack_70 = *(float *)(iVar8 + 0xa4);
          uStack_78._0_4_ = (float)uVar1;
          fStack_34 = (float)uStack_78;
          uStack_78._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
          fStack_30 = uStack_78._4_4_;
          uStack_54 = 0;
          uStack_50 = 0xf;
          auStack_64[0] = 0;
          uStack_78 = uVar1;
          fStack_2c = fStack_70;
          FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
          uStack_14 = 0x16;
          FUN_009cbbb0(auStack_64);
          uStack_14 = 0x17;
          pfVar7 = &fStack_34;
          uVar3 = uStack_b8;
          uVar13 = uStack_b4;
          uVar14 = uStack_b0;
          uVar16 = uStack_ac;
        }
        else {
          puVar5 = (undefined4 *)FUN_007637a0(auStack_44,param_2,0);
          fStack_f4 = DAT_018ce2f8 - *(float *)(iVar8 + 0x94);
          uStack_d0 = *puVar5;
          uStack_cc = puVar5[1];
          uStack_c8 = puVar5[2];
          uStack_c4 = puVar5[3];
          fStack_f8 = *(float *)(iVar8 + 0xa4);
          uVar1 = *(undefined8 *)(iVar8 + 0x9c);
          uStack_88._0_4_ = (float)uVar1;
          fStack_100 = (float)uStack_88;
          uStack_88._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
          uStack_fc = uStack_88._4_4_;
          uStack_54 = 0;
          uStack_50 = 0xf;
          auStack_64[0] = 0;
          uStack_88 = uVar1;
          fStack_80 = fStack_f8;
          FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
          uStack_14 = 0x14;
          FUN_009cbbb0(auStack_64);
          uStack_14 = 0x15;
          pfVar7 = &fStack_100;
          uVar3 = uStack_d0;
          uVar13 = uStack_cc;
          uVar14 = uStack_c8;
          uVar16 = uStack_c4;
        }
        FUN_0075f5b0(auStack_64,iVar8 + 0x74,pfVar7,uVar3,uVar13,uVar14,uVar16);
        uStack_14 = 0xffffffff;
        FUN_005507b0();
        piVar11 = piStack_68;
      }
      piStack_6c = (int *)((int)piStack_6c + -1);
    } while (piStack_6c != (int *)0x0);
    piStack_6c = (int *)0x0;
  }
LAB_00765d10:
  if (*(int *)(param_2 + 0x5c) != 0) {
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    fStack_34 = DAT_01eb01f8 * DAT_018fabf0 + 0.0 + 0.0;
    fStack_30 = ((DAT_018ce2f8 - _DAT_01eb01fc) - DAT_01eb0204) * DAT_018fabf0 + 0.0 + 0.0;
    fStack_2c = (DAT_01eb0200 * 0.0 + DAT_018ce2f8) * 0.0 + DAT_018ce2f8;
    fStack_28 = (DAT_01eb0204 * 0.0 + DAT_018ce2f8) * 0.0 + DAT_018ce2f8;
    FUN_005542c0("rbxasset://avatar/compositing/R15CompositTorsoBase.mesh",0x37);
    uStack_14 = 0x18;
    FUN_009cbbb0(auStack_4c);
    uStack_14 = 0x19;
    FUN_0075f5b0(auStack_4c,param_2 + 0x4c,param_2 + 100,fStack_34,fStack_30,fStack_2c,fStack_28);
    uStack_14 = 0xffffffff;
    if (0xf < uStack_38) {
      uVar10 = uStack_38 + 1;
      uVar9 = auStack_4c[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_4c[0] - 4);
        uVar10 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    fStack_34 = DAT_01eb0238 * DAT_018fabf0 + 0.0 + 0.0;
    fStack_2c = (DAT_01eb0240 * 0.0 + DAT_018ce2f8) * 0.0 + DAT_018ce2f8;
    fStack_28 = (DAT_01eb0244 * 0.0 + DAT_018ce2f8) * 0.0 + DAT_018ce2f8;
    fStack_30 = ((DAT_018ce2f8 - _DAT_01eb023c) - DAT_01eb0244) * DAT_018fabf0 + 0.0 + 0.0;
    FUN_005542c0("rbxasset://avatar/compositing/R15CompositRightArmBase.mesh",0x3a);
    uStack_14 = 0x1a;
    FUN_009cbbb0(auStack_4c);
    uStack_14 = 0x1b;
    FUN_0075f5b0(auStack_4c,param_2 + 0x4c,param_2 + 100,fStack_34,fStack_30,fStack_2c,fStack_28);
    uStack_14 = 0xffffffff;
    if (0xf < uStack_38) {
      uVar10 = uStack_38 + 1;
      uVar9 = auStack_4c[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_4c[0] - 4);
        uVar10 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    pfVar7 = (float *)FUN_00763800(auStack_44,param_2,9);
    fStack_34 = *pfVar7 + 0.0;
    fStack_30 = pfVar7[1] + 0.0;
    fStack_2c = pfVar7[2] * 0.0 + DAT_018ce2f8;
    fStack_28 = pfVar7[3] * 0.0 + DAT_018ce2f8;
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = 0;
    FUN_005542c0("rbxasset://avatar/compositing/R15CompositLeftArmBase.mesh",0x39);
    uStack_14 = 0x1c;
    FUN_009cbbb0(auStack_64);
    uStack_14 = 0x1d;
    FUN_0075f5b0(auStack_64,param_2 + 0x4c,param_2 + 100,fStack_34,fStack_30,fStack_2c,fStack_28);
    uStack_14 = 0xffffffff;
    FUN_005507b0();
  }
  fVar12 = 0.0;
  if (*(int *)(param_2 + 0x84) != 0) {
    pfVar7 = (float *)FUN_00763800(auStack_44,param_2,1);
    fStack_34 = *pfVar7 + fVar12;
    fStack_30 = pfVar7[1] + fVar12;
    fStack_2c = pfVar7[2] * fVar12 + DAT_018ce2f8;
    fStack_28 = pfVar7[3] * fVar12 + DAT_018ce2f8;
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = 0;
    FUN_005542c0("rbxasset://avatar/compositing/R15CompositTorsoBase.mesh",0x37);
    uStack_14 = 0x1e;
    FUN_009cbbb0(auStack_64);
    iVar8 = param_2 + 0x8c;
    uStack_14 = 0x1f;
    FUN_0075f5b0(auStack_64,param_2 + 0x74,iVar8,fStack_34,fStack_30,fStack_2c,fStack_28);
    uStack_14 = 0xffffffff;
    FUN_005507b0();
    pfVar7 = (float *)FUN_00763800(auStack_44,param_2,5);
    fStack_34 = *pfVar7 + 0.0;
    fStack_30 = pfVar7[1] + 0.0;
    fStack_2c = pfVar7[2] * 0.0 + DAT_018ce2f8;
    fStack_28 = pfVar7[3] * 0.0 + DAT_018ce2f8;
    uStack_b0 = 0;
    uStack_ac = 0xf;
    auStack_c0[0] = 0;
    FUN_005542c0("rbxasset://avatar/compositing/R15CompositRightArmBase.mesh",0x3a);
    uStack_14 = 0x20;
    FUN_009cbbb0(auStack_c0);
    uStack_14 = 0x21;
    FUN_0075f5b0(auStack_c0,param_2 + 0x74,iVar8,fStack_34,fStack_30,fStack_2c,fStack_28);
    uStack_14 = 0xffffffff;
    FUN_005507b0();
    pfVar7 = (float *)FUN_00763800(auStack_44,param_2,3);
    fStack_34 = *pfVar7 + 0.0;
    fStack_30 = pfVar7[1] + 0.0;
    fStack_2c = pfVar7[2] * 0.0 + DAT_018ce2f8;
    fStack_28 = pfVar7[3] * 0.0 + DAT_018ce2f8;
    uStack_c8 = 0;
    uStack_c4 = 0xf;
    auStack_d8[0] = 0;
    FUN_005542c0("rbxasset://avatar/compositing/R15CompositLeftArmBase.mesh",0x39);
    uStack_14 = 0x22;
    FUN_009cbbb0(auStack_d8);
    uStack_14 = 0x23;
    FUN_0075f5b0(auStack_d8,param_2 + 0x74,iVar8,fStack_34,fStack_30,fStack_2c,fStack_28);
    uStack_14 = 0xffffffff;
    FUN_005507b0();
  }
  if (*(int *)(param_2 + 0xac) != 0) {
    uStack_54 = 0;
    uStack_b8 = _DAT_01d60be8;
    uStack_b4 = uRam01d60bec;
    uStack_b0 = uRam01d60bf0;
    uStack_ac = uRam01d60bf4;
    uStack_50 = 0xf;
    auStack_64[0] = 0;
    FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
    uStack_14 = 0x24;
    FUN_009cbbb0(auStack_64);
    uStack_14 = 0x25;
    FUN_0075f5b0(auStack_64,param_2 + 0x9c,param_2 + 0xb4,uStack_b8,uStack_b4,uStack_b0,uStack_ac);
    uStack_14 = 0xffffffff;
    FUN_005507b0();
  }
  iVar8 = FUN_00728eb0(iStack_a0);
  if ((iVar8 != 0) && (*(int *)(iVar8 + 0x17c) != 0)) {
    fStack_34 = DAT_01eb0208 * DAT_018fabf0;
    fStack_28 = DAT_01eb0214;
    uStack_54 = 0;
    uStack_50 = 0xf;
    fStack_30 = ((DAT_018ce2f8 - _DAT_01eb020c) - DAT_01eb0214) * DAT_018fabf0;
    auStack_64[0] = 0;
    fStack_2c = DAT_01eb0210;
    FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
    uStack_14 = 0x26;
    FUN_009cbbb0(auStack_64);
    uStack_14 = 0x27;
    FUN_0075f850(auStack_64,iVar8 + 0x16c,fStack_34,fStack_30,fStack_2c,fStack_28,0);
    uStack_14 = 0xffffffff;
    FUN_005507b0();
  }
  iVar8 = FUN_00728eb0(iStack_a4);
  if ((iVar8 != 0) && (*(int *)(iVar8 + 0x17c) != 0)) {
    fStack_34 = DAT_01eb0218 * DAT_018fabf0;
    fStack_28 = DAT_01eb0224;
    uStack_54 = 0;
    uStack_50 = 0xf;
    fStack_30 = ((DAT_018ce2f8 - _DAT_01eb021c) - DAT_01eb0224) * DAT_018fabf0;
    auStack_64[0] = 0;
    fStack_2c = DAT_01eb0220;
    FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
    uStack_14 = 0x28;
    FUN_009cbbb0(auStack_64);
    uStack_14 = 0x29;
    FUN_0075f850(auStack_64,iVar8 + 0x16c,fStack_34,fStack_30,fStack_2c,fStack_28,0);
    uStack_14 = 0xffffffff;
    FUN_005507b0();
  }
  iVar8 = FUN_00728eb0(iStack_a8);
  if ((iVar8 != 0) && (*(int *)(iVar8 + 0x17c) != 0)) {
    fStack_34 = DAT_01eb0228 * DAT_018fabf0;
    fStack_28 = DAT_01eb0234;
    uStack_54 = 0;
    uStack_50 = 0xf;
    fStack_30 = ((DAT_018ce2f8 - _DAT_01eb022c) - DAT_01eb0234) * DAT_018fabf0;
    auStack_64[0] = 0;
    fStack_2c = DAT_01eb0230;
    FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
    uStack_14 = 0x2a;
    FUN_009cbbb0(auStack_64);
    uStack_14 = 0x2b;
    FUN_0075f850(auStack_64,iVar8 + 0x16c,fStack_34,fStack_30,fStack_2c,fStack_28,0);
    uStack_14 = 0xffffffff;
    FUN_005507b0();
  }
  iVar8 = FUN_00728eb0(iStack_90);
  if ((iVar8 != 0) && (*(int *)(iVar8 + 0x17c) != 0)) {
    fStack_34 = DAT_01eb0238 * DAT_018fabf0;
    fStack_28 = DAT_01eb0244;
    uStack_54 = 0;
    uStack_50 = 0xf;
    fStack_30 = ((DAT_018ce2f8 - _DAT_01eb023c) - DAT_01eb0244) * DAT_018fabf0;
    auStack_64[0] = 0;
    fStack_2c = DAT_01eb0240;
    FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
    uStack_14 = 0x2c;
    FUN_009cbbb0(auStack_64);
    uStack_14 = 0x2d;
    FUN_0075f850(auStack_64,iVar8 + 0x16c,fStack_34,fStack_30,fStack_2c,fStack_28,0);
    uStack_14 = 0xffffffff;
    FUN_005507b0();
  }
  iVar8 = FUN_00728eb0(pfStack_94);
  if ((iVar8 != 0) && (*(int *)(iVar8 + 0x17c) != 0)) {
    fStack_34 = DAT_01eb01f8 * DAT_018fabf0;
    fStack_28 = DAT_01eb0204;
    uStack_54 = 0;
    uStack_50 = 0xf;
    fStack_30 = ((DAT_018ce2f8 - _DAT_01eb01fc) - DAT_01eb0204) * DAT_018fabf0;
    auStack_64[0] = 0;
    fStack_2c = DAT_01eb0200;
    FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
    uStack_14 = 0x2e;
    FUN_009cbbb0(auStack_64);
    uStack_14 = 0x2f;
    FUN_0075f850(auStack_64,iVar8 + 0x16c,fStack_34,fStack_30,fStack_2c,fStack_28,0);
    uStack_14 = 0xffffffff;
    FUN_005507b0();
  }
  uStack_e0 = 0;
  uStack_dc = 0xf;
  auStack_f0[0] = 0;
  FUN_005542c0("rbxasset://avatar/compositing/CompositQuad.mesh",0x2f);
  uStack_14 = 0x30;
  FUN_009cbbb0(auStack_f0);
  uStack_14 = 0x31;
  pfStack_94 = (float *)&DAT_018f9f98;
  piVar11 = (int *)(param_3 + 4);
  iStack_90 = 10;
  do {
    if (*piVar11 != 0) {
      fStack_80 = pfStack_94[3];
      fStack_8c = *pfStack_94 * DAT_018fabf0;
      uStack_88 = CONCAT44(pfStack_94[2],((DAT_018ce2f8 - pfStack_94[1]) - fStack_80) * DAT_018fabf0
                          );
      uVar3 = FUN_00b06fb0(auStack_10c);
      FUN_0075f2f0(auStack_f0,uVar3,fStack_8c,(float)uStack_88,uStack_88._4_4_,fStack_80);
      FUN_0075f850(auStack_f0,*piVar11 + 0x80,fStack_8c,(float)uStack_88,uStack_88._4_4_,fStack_80,2
                  );
    }
    pfStack_94 = pfStack_94 + 4;
    piVar11 = piVar11 + 3;
    iStack_90 = iStack_90 + -1;
  } while (iStack_90 != 0);
  FUN_005507b0();
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 10788 ; VA 0x007668d0 ; FUN_007668d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007668d0(int param_1,int param_2,undefined4 *param_3,int param_4)

{
  int *piVar1;
  ulonglong uVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  char cVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int iVar9;
  int iVar10;
  undefined4 ****ppppuVar11;
  byte *pbVar12;
  uint uVar13;
  char *pcVar14;
  uint uVar15;
  char acStack_f4 [32];
  undefined auStack_d4 [24];
  undefined uStack_bc;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  int iStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  int *piStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  int *piStack_74;
  float fStack_70;
  undefined4 ***apppuStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  int iStack_54;
  uint auStack_50 [2];
  int iStack_48;
  undefined8 uStack_44;
  int *piStack_3c;
  int *piStack_38;
  uint uStack_34;
  int iStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ae39b;
  pvStack_10 = ExceptionList;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_2 + 8) != 0) {
    ExceptionList = &pvStack_10;
    uVar7 = FUN_00b06fb0(&uStack_44);
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositTorsoBase.mesh",0x34);
    uStack_8 = 0;
    FUN_009cbbb0(auStack_2c);
    uStack_8 = 1;
    FUN_0075f180(auStack_2c,uVar7);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar15 = uStack_18 + 1;
      uVar13 = auStack_2c[0];
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(auStack_2c[0] - 4);
        uVar15 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
  }
  if (*(int *)(param_2 + 0xc) != 0) {
    uVar7 = FUN_00b06fb0(&uStack_44);
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositLeftArmBase.mesh",0x36);
    uStack_8 = 2;
    FUN_009cbbb0(auStack_2c);
    uStack_8 = 3;
    FUN_0075f180(auStack_2c,uVar7);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar15 = uStack_18 + 1;
      uVar13 = auStack_2c[0];
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(auStack_2c[0] - 4);
        uVar15 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
  }
  if (*(int *)(param_2 + 0x10) != 0) {
    uVar7 = FUN_00b06fb0(&uStack_44);
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositRightArmBase.mesh",0x37);
    uStack_8 = 4;
    FUN_009cbbb0(auStack_2c);
    uStack_8 = 5;
    FUN_0075f180(auStack_2c,uVar7);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar15 = uStack_18 + 1;
      uVar13 = auStack_2c[0];
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(auStack_2c[0] - 4);
        uVar15 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
  }
  if (*(int *)(param_2 + 0x14) != 0) {
    uVar7 = FUN_00b06fb0(&uStack_44);
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositLeftLegBase.mesh",0x36);
    uStack_8 = 6;
    FUN_009cbbb0(auStack_2c);
    uStack_8 = 7;
    FUN_0075f180(auStack_2c,uVar7);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar15 = uStack_18 + 1;
      uVar13 = auStack_2c[0];
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(auStack_2c[0] - 4);
        uVar15 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
  }
  if (*(int *)(param_2 + 0x18) != 0) {
    uVar7 = FUN_00b06fb0(&uStack_44);
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositRightLegBase.mesh",0x37);
    uStack_8 = 8;
    FUN_009cbbb0(auStack_2c);
    uStack_8 = 9;
    FUN_0075f180(auStack_2c,uVar7);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar15 = uStack_18 + 1;
      uVar13 = auStack_2c[0];
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(auStack_2c[0] - 4);
        uVar15 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
  }
  iStack_30 = *(int *)(param_2 + 4);
  if (iStack_30 != 0) {
    cStack_11 = '\x01';
    iStack_54 = FUN_00d011a0(iStack_30);
    FUN_00763260(auStack_2c,iStack_30,param_2,param_3);
    uStack_8 = 10;
    uVar7 = FUN_00b06fb0(&uStack_44);
    FUN_0075f180(auStack_2c,uVar7);
    piStack_38 = (int *)FUN_0075d530(iStack_54);
    if (piStack_38 != (int *)0x0) {
      uStack_5c = 0;
      uStack_58 = 0xf;
      apppuStack_6c[0] = (undefined4 ***)((uint)apppuStack_6c[0] & 0xffffff00);
      FUN_005542c0("NoFace",6);
      ppppuVar11 = apppuStack_6c;
      uStack_8._0_1_ = 0xb;
      puVar8 = (undefined4 *)FUN_0060dcd0((int)&uStack_44 + 4,iStack_54,ppppuVar11);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      uVar7 = *puVar8;
      uVar3 = puVar8[1];
      *puVar8 = 0;
      puVar8[1] = 0;
      cVar6 = FUN_00d13c80(uVar7,uVar3,ppppuVar11);
      piVar5 = piStack_3c;
      cStack_11 = cVar6 == '\0';
      if (piStack_3c != (int *)0x0) {
        LOCK();
        iVar10 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar10 = *piVar1 + -1;
          *piVar1 = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      FUN_005507b0();
    }
    if ((iStack_54 != 0) && (*(int *)(iStack_54 + 0x90) != 0)) {
      FUN_0075f460(auStack_2c,iStack_54 + 0x80);
    }
    if ((cStack_11 != '\0') && (piStack_38 = *(int **)(iStack_30 + 0x2c), piStack_38 != (int *)0x0))
    {
      for (iStack_30 = piStack_38[1] - *piStack_38 >> 3; iStack_30 != 0; iStack_30 = iStack_30 + -1)
      {
        iVar10 = *(int *)(*piStack_38 + -8 + iStack_30 * 8);
        if ((((iVar10 != 0) &&
             (iVar4 = *(int *)(iVar10 + 0xc), iVar9 = FUN_00cffc50(),
             (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
             (uint)*(ushort *)(iVar9 + 0x1da))) && (*(int *)(iVar10 + 0x70) == 5)) &&
           (*(int *)(iVar10 + 0x84) != 0)) {
          piStack_74 = *(int **)(iVar10 + 0xa4);
          uVar2 = *(ulonglong *)(iVar10 + 0x9c);
          fStack_70 = DAT_018ce2f8 - *(float *)(iVar10 + 0x94);
          uStack_44._0_4_ = (undefined4)uVar2;
          uStack_7c = (undefined4)uStack_44;
          uStack_44._4_4_ = (undefined4)(uVar2 >> 0x20);
          uStack_78 = uStack_44._4_4_;
          uStack_44 = uVar2;
          piStack_3c = piStack_74;
          FUN_0075f5b0(auStack_2c,iVar10 + 0x74,&uStack_7c,_DAT_018fac80,_UNK_018fac84,_UNK_018fac88
                       ,_UNK_018fac8c);
        }
      }
      iStack_30 = 0;
    }
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar15 = uStack_18 + 1;
      uVar13 = auStack_2c[0];
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(auStack_2c[0] - 4);
        uVar15 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
  }
  if (param_4 == 0) {
LAB_00766e86:
    cStack_11 = '\0';
  }
  else {
    iVar10 = FUN_00cff3a0(auStack_2c);
    uStack_34 = 1;
    if (*(int *)(iVar10 + 0x10) == 0) goto LAB_00766e86;
    cStack_11 = '\x01';
  }
  if (((uStack_34 & 1) != 0) && (uStack_34 = uStack_34 & 0xfffffffe, 0xf < uStack_18)) {
    uVar15 = uStack_18 + 1;
    uVar13 = auStack_2c[0];
    if (0xfff < uVar15) {
      uVar13 = *(uint *)(auStack_2c[0] - 4);
      uVar15 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar15);
  }
  if (cStack_11 != '\0') {
    uVar7 = FUN_00cff3a0(auStack_2c);
    uStack_8 = 0xd;
    uStack_44 = uStack_44 & 0xffffffff;
    piStack_3c = (int *)0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositFullAtlasBaseTexture.mesh",0x3f);
    uStack_8._0_1_ = 0xe;
    FUN_009cbbb0(auStack_50);
    uStack_8._0_1_ = 0xf;
    FUN_0075f460(auStack_50,uVar7);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    if (0xf < piStack_3c) {
      uVar15 = (int)piStack_3c + 1;
      uVar13 = auStack_50[0];
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(auStack_50[0] - 4);
        uVar15 = (int)piStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
    uStack_44 = uStack_44 & 0xffffffff;
    piStack_3c = (int *)&DAT_0000000f;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar15 = uStack_18 + 1;
      uVar13 = auStack_2c[0];
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(auStack_2c[0] - 4);
        uVar15 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
  }
  if (*(int *)(param_2 + 0x5c) != 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositPantsTemplate.mesh",0x38);
    uStack_8 = 0x10;
    FUN_009cbbb0(auStack_2c);
    uStack_8 = 0x11;
    FUN_0075f5b0(auStack_2c,param_2 + 0x4c,param_2 + 100,_DAT_018fac80,_UNK_018fac84,_UNK_018fac88,
                 _UNK_018fac8c);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar15 = uStack_18 + 1;
      uVar13 = auStack_2c[0];
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(auStack_2c[0] - 4);
        uVar15 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
  }
  if (*(int *)(param_2 + 0x84) != 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositShirtTemplate.mesh",0x38);
    uStack_8 = 0x12;
    FUN_009cbbb0(auStack_2c);
    uStack_8 = 0x13;
    FUN_0075f5b0(auStack_2c,param_2 + 0x74,param_2 + 0x8c,_DAT_018fac80,_UNK_018fac84,_UNK_018fac88,
                 _UNK_018fac8c);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar15 = uStack_18 + 1;
      uVar13 = auStack_2c[0];
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(auStack_2c[0] - 4);
        uVar15 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
  }
  if (*(int *)(param_2 + 0xac) != 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositTShirt.mesh",0x31);
    uStack_8 = 0x14;
    FUN_009cbbb0(auStack_2c);
    uStack_8 = 0x15;
    FUN_0075f5b0(auStack_2c,param_2 + 0x9c,param_2 + 0xb4,_DAT_018fac80,_UNK_018fac84,_UNK_018fac88,
                 _UNK_018fac8c);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar15 = uStack_18 + 1;
      uVar13 = auStack_2c[0];
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(auStack_2c[0] - 4);
        uVar15 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
  }
  uVar13 = uStack_34;
  if (param_4 != 0) {
    iVar10 = FUN_00cff560(auStack_2c);
    uVar13 = uStack_34 | 2;
    if (*(int *)(iVar10 + 0x10) != 0) {
      cStack_11 = '\x01';
      goto LAB_007671c8;
    }
  }
  cStack_11 = '\0';
LAB_007671c8:
  if (((uVar13 & 2) != 0) && (0xf < uStack_18)) {
    uVar15 = uStack_18 + 1;
    uVar13 = auStack_2c[0];
    if (0xfff < uVar15) {
      uVar13 = *(uint *)(auStack_2c[0] - 4);
      uVar15 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar15);
  }
  if (cStack_11 != '\0') {
    uVar7 = FUN_00cff560(auStack_50);
    uStack_8 = 0x16;
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("rbxasset://avatar/compositing/CompositFullAtlasOverlayTexture.mesh",0x42);
    uStack_8._0_1_ = 0x17;
    FUN_009cbbb0(auStack_2c);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
    FUN_0075f460(auStack_2c,uVar7);
    FUN_005507b0();
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  iStack_30 = 4;
  puVar8 = param_3;
  do {
    if (puVar8[1] != 0) {
      FUN_00763260(apppuStack_6c,*puVar8,param_2,param_3);
      uStack_8 = 0x19;
      piStack_38 = (int *)FUN_00b06fb0(&uStack_78);
      piStack_3c = (int *)&DAT_3f800000;
      iStack_48 = *piStack_38;
      uStack_44 = *(ulonglong *)(piStack_38 + 1);
      FUN_0054ef60(apppuStack_6c);
      uStack_ac = 0;
      uStack_a8 = 0xf;
      iStack_a4 = iStack_48;
      uStack_a0 = (undefined4)uStack_44;
      uStack_9c = uStack_44._4_4_;
      piStack_98 = piStack_3c;
      uStack_bc = 0;
      uStack_94 = _DAT_018fac80;
      uStack_90 = _UNK_018fac84;
      uStack_8c = _UNK_018fac88;
      uStack_88 = _UNK_018fac8c;
      uStack_84 = 1;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
      if (*(int *)(param_1 + 0x20) == *(int *)(param_1 + 0x1c)) {
        FUN_0075c430(*(int *)(param_1 + 0x1c),auStack_d4);
      }
      else {
        FUN_0075d3e0(param_1 + 0x18);
        *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 0x54;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
      FUN_005509f0();
      FUN_00554150(&DAT_018fa118,3);
      ppppuVar11 = apppuStack_6c;
      if (0xf < uStack_58) {
        ppppuVar11 = (undefined4 ****)apppuStack_6c[0];
      }
      FUN_00554150(ppppuVar11,uStack_5c);
      FUN_00554150(&DAT_018c3838,1);
      pbVar12 = (byte *)FUN_0073d7b0(piStack_38);
      FUN_005bde90(acStack_f4,&DAT_018fa11c,
                   ((*pbVar12 + 0xff00) * 0x100 + (uint)pbVar12[1]) * 0x100 + (uint)pbVar12[2]);
      pcVar14 = acStack_f4;
      do {
        cVar6 = *pcVar14;
        pcVar14 = pcVar14 + 1;
      } while (cVar6 != '\0');
      FUN_00554150(acStack_f4,(int)pcVar14 - (int)(acStack_f4 + 1));
      FUN_00554150(&DAT_018bfd94,1);
      FUN_0075f850(apppuStack_6c,puVar8[1] + 0x80,_DAT_018fac80,_UNK_018fac84,_UNK_018fac88,
                   _UNK_018fac8c,2);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    puVar8 = puVar8 + 3;
    iStack_30 = iStack_30 + -1;
  } while (iStack_30 != 0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10789 ; VA 0x007674a0 ; FUN_007674a0 */

int __fastcall FUN_007674a0(int *param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  undefined auStack_7c [4];
  int *piStack_78;
  undefined auStack_74 [4];
  int *piStack_70;
  undefined auStack_6c [4];
  int *piStack_68;
  int iStack_64;
  int *piStack_60;
  undefined4 uStack_5c;
  int *piStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  int *piStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017ae3d0;
  pvStack_10 = ExceptionList;
  iStack_64 = 0;
  uStack_1c = *(undefined4 *)(*param_1 + 0x4ec);
  piStack_14 = (int *)0x0;
  piStack_60 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_20 = param_1;
LAB_007674e1:
  do {
    while( true ) {
      do {
        piVar7 = (int *)piStack_20[1];
        puVar1 = (uint *)(piVar7 + 5);
        do {
          LOCK();
          uVar2 = *puVar1;
          *puVar1 = *puVar1 | 1;
          UNLOCK();
        } while ((uVar2 & 1) != 0);
        if (piVar7[4] == 0) {
          *puVar1 = 0;
          iVar5 = 0;
          if (piStack_14 != (int *)0x0) {
            LOCK();
            piVar7 = piStack_14 + 1;
            iVar6 = *piVar7;
            iVar5 = *piVar7;
            *piVar7 = iVar6 + -1;
            UNLOCK();
            if (iVar6 + -1 == 0) {
              iVar5 = (**(code **)*piStack_14)();
              LOCK();
              piVar7 = piStack_14 + 2;
              iVar6 = *piVar7;
              *piVar7 = *piVar7 + -1;
              UNLOCK();
              if (iVar6 == 1) {
                iVar5 = (**(code **)(*piStack_14 + 4))();
              }
            }
          }
          ExceptionList = pvStack_10;
          return iVar5;
        }
        puVar4 = (undefined4 *)*piVar7;
        if (puVar4 != (undefined4 *)0x0) {
          puVar4 = (undefined4 *)*puVar4;
        }
        uVar2 = piVar7[3] & 1;
        iVar5 = *(int *)(puVar4[1] + (puVar4[2] - 1 & (uint)piVar7[3] >> 1) * 4);
        piStack_60 = *(int **)(iVar5 + 4 + uVar2 * 8);
        if (piStack_60 != (int *)0x0) {
          LOCK();
          piStack_60[1] = piStack_60[1] + 1;
          UNLOCK();
          piStack_60 = *(int **)(iVar5 + 4 + uVar2 * 8);
        }
        iStack_64 = *(int *)(iVar5 + uVar2 * 8);
        piStack_24 = piStack_14;
        piStack_2c = piStack_60;
        iStack_28 = iStack_64;
        iStack_18 = iStack_64;
        piVar3 = piStack_60;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_14[1] + -1;
          piStack_14[1] = iVar5;
          UNLOCK();
          piVar3 = piStack_60;
          if (iVar5 == 0) {
            puVar4 = (undefined4 *)*piStack_14;
            piStack_14 = piStack_60;
            (*(code *)*puVar4)();
            LOCK();
            iVar5 = piStack_24[2] + -1;
            piStack_24[2] = iVar5;
            UNLOCK();
            piVar3 = piStack_14;
            if (iVar5 == 0) {
              (**(code **)(*piStack_24 + 4))();
              piVar3 = piStack_14;
            }
          }
        }
        piStack_14 = piVar3;
        piStack_24 = *(int **)(*(int *)(piVar7[1] + (piVar7[2] - 1U & (uint)piVar7[3] >> 1) * 4) + 4
                              + (piVar7[3] & 1U) * 8);
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_24[1] + -1;
          piStack_24[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar5 = piStack_24[2] + -1;
            piStack_24[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
        piVar3 = piVar7 + 4;
        *piVar3 = *piVar3 + -1;
        if (*piVar3 == 0) {
          piVar7[3] = 0;
        }
        else {
          piVar7[3] = piVar7[3] + 1;
        }
        *puVar1 = 0;
        iVar5 = *(int *)(iStack_18 + 0x3c);
      } while (iVar5 == 0);
      iVar6 = *(int *)(iVar5 + 4);
      piVar7 = (int *)(iVar5 + 4);
      if (iVar6 != 0) break;
LAB_007678a0:
      piStack_14 = piStack_60;
    }
    do {
      LOCK();
      iVar5 = *piVar7;
      if (iVar6 == iVar5) {
        *piVar7 = iVar6 + 1;
        iVar5 = iVar6;
      }
      UNLOCK();
      if (iVar5 == iVar6) {
        piStack_24 = *(int **)(iStack_18 + 0x38);
        piVar7 = *(int **)(iStack_18 + 0x3c);
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar5 = piVar7[1] + -1;
          piVar7[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            iVar5 = piVar7[2] + -1;
            piVar7[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        iVar5 = iStack_28;
        if (piStack_24 == (int *)0x0) goto LAB_007678a0;
        uStack_5c = 0;
        piStack_58 = (int *)0x0;
        uStack_54 = 0;
        piStack_50 = (int *)0x0;
        uStack_4c = 0;
        piStack_48 = (int *)0x0;
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        if ((*(char *)(iStack_28 + 0x35) != '\0') && (DAT_01d60bd0 != '\0')) {
          puVar4 = (undefined4 *)FUN_00784300(auStack_6c,iStack_28 + 0x40,1);
          piVar7 = piStack_58;
          uStack_5c = *puVar4;
          piStack_34 = (int *)puVar4[1];
          *puVar4 = 0;
          puVar4[1] = 0;
          piVar3 = piStack_34;
          uStack_30 = uStack_5c;
          if (piStack_58 != (int *)0x0) {
            LOCK();
            iVar6 = piStack_58[1] + -1;
            piStack_58[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              puVar4 = (undefined4 *)*piStack_58;
              piStack_58 = piStack_34;
              (*(code *)*puVar4)();
              LOCK();
              piVar3 = piVar7 + 2;
              iVar6 = *piVar3 + -1;
              *piVar3 = iVar6;
              UNLOCK();
              piVar3 = piStack_58;
              if (iVar6 == 0) {
                (**(code **)(*piVar7 + 4))();
                piVar3 = piStack_58;
              }
            }
          }
          piStack_58 = piVar3;
          piVar7 = piStack_68;
          if (piStack_68 != (int *)0x0) {
            LOCK();
            iVar6 = piStack_68[1] + -1;
            piStack_68[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piStack_68)();
              LOCK();
              piVar3 = piVar7 + 2;
              iVar6 = *piVar3 + -1;
              *piVar3 = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
        }
        puVar4 = (undefined4 *)FUN_00784300(auStack_74,iVar5 + 0x40,2);
        piVar7 = piStack_50;
        uStack_54 = *puVar4;
        piStack_3c = (int *)puVar4[1];
        *puVar4 = 0;
        puVar4[1] = 0;
        piVar3 = piStack_3c;
        uStack_38 = uStack_54;
        if (piStack_50 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_50[1] + -1;
          piStack_50[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            puVar4 = (undefined4 *)*piStack_50;
            piStack_50 = piStack_3c;
            (*(code *)*puVar4)();
            LOCK();
            piVar3 = piVar7 + 2;
            iVar6 = *piVar3 + -1;
            *piVar3 = iVar6;
            UNLOCK();
            piVar3 = piStack_50;
            if (iVar6 == 0) {
              (**(code **)(*piVar7 + 4))();
              piVar3 = piStack_50;
            }
          }
        }
        piStack_50 = piVar3;
        piVar7 = piStack_70;
        if (piStack_70 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_70[1] + -1;
          piStack_70[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_70)();
            LOCK();
            piVar3 = piVar7 + 2;
            iVar6 = *piVar3 + -1;
            *piVar3 = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        puVar4 = (undefined4 *)FUN_00784300(auStack_7c,iVar5 + 0x40,3);
        piVar7 = piStack_48;
        uStack_4c = *puVar4;
        piStack_44 = (int *)puVar4[1];
        *puVar4 = 0;
        puVar4[1] = 0;
        piVar3 = piStack_44;
        uStack_40 = uStack_4c;
        if (piStack_48 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_48[1] + -1;
          piStack_48[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            puVar4 = (undefined4 *)*piStack_48;
            piStack_48 = piStack_44;
            (*(code *)*puVar4)();
            LOCK();
            piVar3 = piVar7 + 2;
            iVar6 = *piVar3 + -1;
            *piVar3 = iVar6;
            UNLOCK();
            piVar3 = piStack_48;
            if (iVar6 == 0) {
              (**(code **)(*piVar7 + 4))();
              piVar3 = piStack_48;
            }
          }
        }
        piStack_48 = piVar3;
        piVar7 = piStack_78;
        if (piStack_78 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_78[1] + -1;
          piStack_78[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_78)();
            LOCK();
            piVar3 = piVar7 + 2;
            iVar6 = *piVar3 + -1;
            *piVar3 = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        FUN_00764f20(piStack_24,uStack_1c,&uStack_5c,&uStack_54,&uStack_4c,
                     *(undefined *)(iVar5 + 0x36));
        piVar7 = piStack_48;
        if (piStack_48 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_48[1] + -1;
          piStack_48[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_48)();
            LOCK();
            piVar3 = piVar7 + 2;
            iVar5 = *piVar3 + -1;
            *piVar3 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        piVar7 = piStack_50;
        if (piStack_50 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_50[1] + -1;
          piStack_50[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_50)();
            LOCK();
            piVar3 = piVar7 + 2;
            iVar5 = *piVar3 + -1;
            *piVar3 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        piVar7 = piStack_58;
        uStack_8 = uStack_8 & 0xffffff00;
        if (piStack_58 == (int *)0x0) goto LAB_007678a0;
        LOCK();
        iVar5 = piStack_58[1] + -1;
        piStack_58[1] = iVar5;
        UNLOCK();
        if (iVar5 != 0) goto LAB_007678a0;
        (**(code **)*piStack_58)();
        LOCK();
        piVar3 = piVar7 + 2;
        iVar5 = *piVar3 + -1;
        *piVar3 = iVar5;
        UNLOCK();
        if (iVar5 != 0) goto LAB_007678a0;
        (**(code **)(*piVar7 + 4))();
        piStack_14 = piStack_60;
        goto LAB_007674e1;
      }
      iVar6 = *piVar7;
    } while (iVar6 != 0);
    piStack_14 = piStack_60;
  } while( true );
}



/* FUNCTION 10790 ; VA 0x00767900 ; FUN_00767900 */

float10 FUN_00767900(short param_1)

{
  return (float10)(DAT_018fabec /
                  (((float)(int)param_1 / DAT_018f9000) * DAT_018f8ff4 *
                  ((float)(int)param_1 / DAT_018f9000)));
}



/* FUNCTION 10791 ; VA 0x00767940 ; FUN_00767940 */

void FUN_00767940(int param_1,int param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined uVar4;
  char *pcVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  char *pcVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  int *piVar13;
  undefined auStack_154 [24];
  int aiStack_13c [5];
  uint uStack_128;
  int aiStack_124 [5];
  uint uStack_110;
  int aiStack_10c [5];
  uint uStack_f8;
  undefined auStack_f4 [16];
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  uint auStack_dc [4];
  undefined4 uStack_cc;
  uint uStack_c8;
  uint auStack_c4 [4];
  undefined4 uStack_b4;
  uint uStack_b0;
  uint auStack_ac [4];
  undefined4 uStack_9c;
  uint uStack_98;
  undefined auStack_94 [16];
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined uStack_7c;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined uStack_64;
  undefined4 uStack_54;
  undefined4 uStack_50;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined2 auStack_24 [2];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ae5bb;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  iVar8 = *(int *)(param_1 + 0x4ec);
  uStack_e4 = 0;
  uStack_e0 = 0xf;
  auStack_f4[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxasset://textures/",0x14);
  uStack_8 = 0;
  pcVar5 = (char *)FUN_00763310(param_4);
  pcVar9 = pcVar5;
  do {
    cVar2 = *pcVar9;
    pcVar9 = pcVar9 + 1;
  } while (cVar2 != '\0');
  FUN_00554150(pcVar5,(int)pcVar9 - (int)(pcVar5 + 1));
  FUN_00554150(&DAT_018c36fc,1);
  uStack_8._0_1_ = 3;
  if (*(int *)(param_2 + 0x58) == 0) {
    uVar6 = FUN_00558ce0(auStack_48,auStack_f4,"diffuse");
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uVar12 = 1;
  }
  else {
    uVar6 = FUN_0054ef60(param_2 + 0x48);
    uStack_8 = 5;
    uVar12 = 2;
  }
  piStack_14 = (int *)uVar12;
  FUN_0054ef60(uVar6);
  uStack_8 = 7;
  if ((uVar12 & 2) != 0) {
    uVar12 = uVar12 & 0xfffffffd;
    piStack_14 = (int *)uVar12;
    if (0xf < uStack_98) {
      uVar10 = uStack_98 + 1;
      uVar11 = auStack_ac[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_ac[0] - 4);
        uVar10 = uStack_98 + 0x24;
        if (0x1f < (auStack_ac[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_9c = 0;
    uStack_98 = 0xf;
    auStack_ac[0] = auStack_ac[0] & 0xffffff00;
  }
  uStack_8._0_1_ = 8;
  if ((uVar12 & 1) != 0) {
    uVar12 = uVar12 & 0xfffffffe;
    piStack_14 = (int *)uVar12;
    if (0xf < uStack_34) {
      uVar10 = uStack_34 + 1;
      uVar11 = auStack_48[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_48[0] - 4);
        uVar10 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
  }
  if (*(int *)(param_2 + 0x70) == 0) {
    uVar6 = FUN_00558ce0(auStack_c4,auStack_f4,"normal");
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    uVar12 = uVar12 | 4;
  }
  else {
    uVar6 = FUN_0054ef60(param_2 + 0x60);
    uStack_8 = 10;
    uVar12 = uVar12 | 8;
  }
  piStack_14 = (int *)uVar12;
  FUN_0054ef60(uVar6);
  uStack_8 = 0xc;
  if ((uVar12 & 8) != 0) {
    uVar12 = uVar12 & 0xfffffff7;
    piStack_14 = (int *)uVar12;
    if (0xf < uStack_1c) {
      uVar10 = uStack_1c + 1;
      uVar11 = uStack_30;
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(uStack_30 - 4);
        uVar10 = uStack_1c + 0x24;
        if (0x1f < (uStack_30 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    uStack_30 = uStack_30 & 0xffffff00;
  }
  uStack_8._0_1_ = 0xd;
  if ((uVar12 & 4) != 0) {
    uVar12 = uVar12 & 0xfffffffb;
    piStack_14 = (int *)uVar12;
    if (0xf < uStack_b0) {
      uVar10 = uStack_b0 + 1;
      uVar11 = auStack_c4[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_c4[0] - 4);
        uVar10 = uStack_b0 + 0x24;
        if (0x1f < (auStack_c4[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_b4 = 0;
    uStack_b0 = 0xf;
    auStack_c4[0] = auStack_c4[0] & 0xffffff00;
  }
  if (*(int *)(param_2 + 0xa0) == 0) {
    uVar6 = FUN_00558ce0(auStack_dc,auStack_f4,"normaldetail");
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    uVar12 = uVar12 | 0x10;
  }
  else {
    uVar6 = FUN_0054ef60(param_2 + 0x90);
    uStack_8 = 0xf;
    uVar12 = uVar12 | 0x20;
  }
  piStack_14 = (int *)uVar12;
  FUN_0054ef60(uVar6);
  uStack_8 = 0x11;
  if ((uVar12 & 0x20) != 0) {
    uVar12 = uVar12 & 0xffffffdf;
    piStack_14 = (int *)uVar12;
    if (0xf < uStack_34) {
      uVar10 = uStack_34 + 1;
      uVar11 = auStack_48[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_48[0] - 4);
        uVar10 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
  }
  uStack_8._0_1_ = 0x12;
  if ((uVar12 & 0x10) != 0) {
    uVar12 = uVar12 & 0xffffffef;
    piStack_14 = (int *)uVar12;
    if (0xf < uStack_c8) {
      uVar10 = uStack_c8 + 1;
      uVar11 = auStack_dc[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_dc[0] - 4);
        uVar10 = uStack_c8 + 0x24;
        if (0x1f < (auStack_dc[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_cc = 0;
    uStack_c8 = 0xf;
    auStack_dc[0] = auStack_dc[0] & 0xffffff00;
  }
  uStack_9c = 0;
  uStack_98 = 0xf;
  auStack_ac[0] = auStack_ac[0] & 0xffffff00;
  FUN_005542c0(&DAT_018fa59c,10);
  uStack_8._0_1_ = 0x13;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x13;
  if (*(int *)(param_2 + 0x88) == 0) {
    uVar6 = FUN_005f3cd0(auStack_c4,auStack_f4,auStack_ac);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
    piVar13 = (int *)(uVar12 | 0x40);
  }
  else {
    uStack_8._0_1_ = uVar4;
    uVar6 = FUN_0054ef60(param_2 + 0x78);
    uStack_8 = 0x15;
    piVar13 = (int *)(uVar12 | 0x80);
  }
  piStack_14 = piVar13;
  FUN_0054ef60(uVar6);
  uStack_8 = 0x17;
  if ((char)piVar13 < '\0') {
    piVar13 = (int *)((uint)piVar13 & 0xffffff7f);
    if (0xf < uStack_c8) {
      uVar11 = uStack_c8 + 1;
      uVar12 = auStack_dc[0];
      if (0xfff < uVar11) {
        uVar12 = *(uint *)(auStack_dc[0] - 4);
        uVar11 = uStack_c8 + 0x24;
        if (0x1f < (auStack_dc[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar11);
    }
    uStack_cc = 0;
    uStack_c8 = 0xf;
    auStack_dc[0] = auStack_dc[0] & 0xffffff00;
  }
  uStack_8._0_1_ = 0x18;
  if (((uint)piVar13 & 0x40) != 0) {
    if (0xf < uStack_b0) {
      uVar11 = uStack_b0 + 1;
      uVar12 = auStack_c4[0];
      if (0xfff < uVar11) {
        uVar12 = *(uint *)(auStack_c4[0] - 4);
        uVar11 = uStack_b0 + 0x24;
        if (0x1f < (auStack_c4[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar11);
    }
    uStack_b4 = 0;
    uStack_b0 = 0xf;
    auStack_c4[0] = auStack_c4[0] & 0xffffff00;
  }
  puVar7 = &DAT_01d60bf8;
  if (0xf < DAT_01d60c0c) {
    puVar7 = DAT_01d60bf8;
  }
  FUN_00554150(puVar7,DAT_01d60c08);
  puVar7 = &DAT_01d60bf8;
  if (0xf < DAT_01d60c0c) {
    puVar7 = DAT_01d60bf8;
  }
  FUN_00554150(puVar7,DAT_01d60c08);
  puVar7 = &DAT_01d60bf8;
  if (0xf < DAT_01d60c0c) {
    puVar7 = DAT_01d60bf8;
  }
  FUN_00554150(puVar7,DAT_01d60c08);
  puVar7 = &DAT_01d60bf8;
  if (0xf < DAT_01d60c0c) {
    puVar7 = DAT_01d60bf8;
  }
  FUN_00554150(puVar7,DAT_01d60c08);
  FUN_005cd7e0(auStack_154);
  FUN_005cd7e0(aiStack_13c);
  FUN_005cd7e0(aiStack_124);
  FUN_005cd7e0(aiStack_10c);
  uStack_20 = 0;
  uStack_1c = uStack_1c & 0xffff0000;
  if (*(char *)(param_2 + 0x44) == '\0') {
    auStack_24[0] = 2;
    uStack_84 = 0;
    uStack_80 = 0xf;
    auStack_94[0] = 0;
    uStack_6c = 0;
    uStack_68 = 0xf;
    uStack_7c = 0;
    uStack_54 = 0;
    uStack_50 = 0xf;
    uStack_64 = 0;
    uStack_8._0_1_ = 0x1a;
    FUN_0054ef60(auStack_154);
    uStack_8._0_1_ = 0x1b;
    FUN_009cbbb0(auStack_48);
    uStack_8._0_1_ = 0x1c;
    uVar6 = FUN_00782480(auStack_18,auStack_48,1,auStack_94,0x425c0000,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
    FUN_0078e550(3,uVar6,auStack_24);
    piVar13 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar13 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar13 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 0x1a;
    if (0xf < uStack_34) {
      uVar11 = uStack_34 + 1;
      uVar12 = auStack_48[0];
      if (0xfff < uVar11) {
        uVar12 = *(uint *)(auStack_48[0] - 4);
        uVar11 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar11);
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    uStack_8._0_1_ = 0x18;
    FUN_00637950();
  }
  else {
    auStack_24[0] = 1;
    FUN_007735a0(iVar8 + 0x24,3);
    uStack_8._0_1_ = 0x19;
    FUN_0078e550(3,auStack_18,auStack_24);
    piVar13 = piStack_14;
    uStack_8._0_1_ = 0x18;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar13 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar13 + 4))();
        }
      }
    }
  }
  uStack_20 = 0;
  uStack_1c = uStack_1c & 0xffff0000;
  if (*(char *)(param_2 + 0x45) == '\0') {
    auStack_24[0] = 2;
    uStack_84 = 0;
    uStack_80 = 0xf;
    auStack_94[0] = 0;
    uStack_6c = 0;
    uStack_68 = 0xf;
    uStack_7c = 0;
    uStack_54 = 0;
    uStack_50 = 0xf;
    uStack_64 = 0;
    uStack_8._0_1_ = 0x1f;
    FUN_0054ef60(aiStack_13c);
    uStack_8._0_1_ = 0x20;
    FUN_009cbbb0(auStack_48);
    uStack_8._0_1_ = 0x21;
    uVar6 = FUN_00782480(auStack_18,auStack_48,5,auStack_94,0x425c0000,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x22);
    FUN_0078e550(4,uVar6,auStack_24);
    piVar13 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_14[1] + -1;
      piStack_14[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar13 + 2;
        iVar8 = *piVar1 + -1;
        *piVar1 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar13 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1f);
    if (0xf < uStack_34) {
      uVar11 = uStack_34 + 1;
      uVar12 = auStack_48[0];
      if (0xfff < uVar11) {
        uVar12 = *(uint *)(auStack_48[0] - 4);
        uVar11 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar11);
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    FUN_00637950();
  }
  else {
    auStack_24[0] = 1;
    FUN_007735a0(iVar8 + 0x44,3);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
    FUN_0078e550(4,auStack_18,auStack_24);
    piVar13 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_14[1] + -1;
      piStack_14[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar13 + 2;
        iVar8 = *piVar1 + -1;
        *piVar1 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar13 + 4))();
        }
      }
    }
  }
  auStack_24[0] = 2;
  uStack_20 = 0;
  uStack_1c = uStack_1c & 0xffff0000;
  uStack_84 = 0;
  uStack_80 = 0xf;
  auStack_94[0] = 0;
  uStack_6c = 0;
  uStack_68 = 0xf;
  uStack_7c = 0;
  uStack_54 = 0;
  uStack_50 = 0xf;
  uStack_64 = 0;
  uStack_8._0_1_ = 0x23;
  FUN_0054ef60(aiStack_124);
  uStack_8._0_1_ = 0x24;
  FUN_009cbbb0(auStack_48);
  uStack_8._0_1_ = 0x25;
  uVar6 = FUN_00782480(auStack_18,auStack_48,5,auStack_94,0x425c0000,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x26);
  FUN_0078e550(8,uVar6,auStack_24);
  piVar13 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_14[1] + -1;
    piStack_14[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar13 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar13 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 0x23;
  if (0xf < uStack_34) {
    uVar11 = uStack_34 + 1;
    uVar12 = auStack_48[0];
    if (0xfff < uVar11) {
      uVar12 = *(uint *)(auStack_48[0] - 4);
      uVar11 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar11);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_00637950();
  auStack_24[0] = 2;
  uStack_20 = 0;
  uStack_1c = uStack_1c & 0xffff0000;
  uStack_84 = 0;
  uStack_80 = 0xf;
  auStack_94[0] = 0;
  uStack_6c = 0;
  uStack_68 = 0xf;
  uStack_7c = 0;
  uStack_54 = 0;
  uStack_50 = 0xf;
  uStack_64 = 0;
  uStack_8._0_1_ = 0x27;
  FUN_0054ef60(aiStack_10c);
  uStack_8._0_1_ = 0x28;
  FUN_009cbbb0(auStack_48);
  uStack_8._0_1_ = 0x29;
  uVar6 = FUN_00782480(auStack_18,auStack_48,3,auStack_94,0x425c0000,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x2a);
  FUN_0078e550(5,uVar6,auStack_24);
  piVar13 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_14[1] + -1;
    piStack_14[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar13 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*piVar13 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 0x27;
  if (0xf < uStack_34) {
    uVar11 = uStack_34 + 1;
    uVar12 = auStack_48[0];
    if (0xfff < uVar11) {
      uVar12 = *(uint *)(auStack_48[0] - 4);
      uVar11 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar11);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  FUN_00637950();
  if (param_5 != 0) {
    auStack_24[0] = 0;
    uStack_20 = 0;
    uStack_1c = uStack_1c & 0xffff0000;
    FUN_0078e550(9,param_5,auStack_24);
  }
  if (0xf < uStack_f8) {
    uVar12 = uStack_f8 + 1;
    iVar8 = aiStack_10c[0];
    if (0xfff < uVar12) {
      iVar8 = *(int *)(aiStack_10c[0] + -4);
      uVar12 = uStack_f8 + 0x24;
      if (0x1f < (aiStack_10c[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar12);
  }
  if (0xf < uStack_98) {
    uVar11 = uStack_98 + 1;
    uVar12 = auStack_ac[0];
    if (0xfff < uVar11) {
      uVar12 = *(uint *)(auStack_ac[0] - 4);
      uVar11 = uStack_98 + 0x24;
      if (0x1f < (auStack_ac[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar11);
  }
  if (0xf < uStack_110) {
    uVar12 = uStack_110 + 1;
    iVar8 = aiStack_124[0];
    if (0xfff < uVar12) {
      iVar8 = *(int *)(aiStack_124[0] + -4);
      uVar12 = uStack_110 + 0x24;
      if (0x1f < (aiStack_124[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar12);
  }
  if (0xf < uStack_128) {
    uVar12 = uStack_128 + 1;
    iVar8 = aiStack_13c[0];
    if (0xfff < uVar12) {
      iVar8 = *(int *)(aiStack_13c[0] + -4);
      uVar12 = uStack_128 + 0x24;
      if (0x1f < (aiStack_13c[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar12);
  }
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10792 ; VA 0x007686a0 ; FUN_007686a0 */

void FUN_007686a0(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  char cVar2;
  char *pcVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  undefined auStack_e8 [16];
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined uStack_d0;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined uStack_b8;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  int aiStack_9c [5];
  uint uStack_88;
  uint auStack_84 [4];
  undefined4 uStack_74;
  uint uStack_70;
  uint uStack_6c;
  undefined4 uStack_5c;
  uint uStack_58;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined2 auStack_1c [2];
  undefined4 uStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ae638;
  pvStack_10 = ExceptionList;
  piStack_20 = (int *)0x0;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxasset://textures/",0x14);
  uStack_8 = 0;
  pcVar3 = (char *)FUN_00763310(param_4);
  pcVar7 = pcVar3;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_00554150(pcVar3,(int)pcVar7 - (int)(pcVar3 + 1));
  FUN_00554150(&DAT_018c36fc,1);
  if (*(int *)(param_2 + 0x58) == 0) {
    uVar4 = FUN_00558ce0(auStack_84,auStack_3c,"diffuse");
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piVar10 = (int *)0x1;
  }
  else {
    uVar4 = FUN_0054ef60(param_2 + 0x48);
    uStack_8 = 2;
    piVar10 = (int *)0x2;
  }
  piStack_20 = piVar10;
  FUN_0054ef60(uVar4);
  uStack_8 = 4;
  if (((uint)piVar10 & 2) != 0) {
    piVar10 = (int *)((uint)piVar10 & 0xfffffffd);
    if (0xf < uStack_58) {
      uVar8 = uStack_58 + 1;
      uVar9 = uStack_6c;
      if (0xfff < uVar8) {
        uVar9 = *(uint *)(uStack_6c - 4);
        uVar8 = uStack_58 + 0x24;
        if (0x1f < (uStack_6c - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar8);
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    uStack_6c = uStack_6c & 0xffffff00;
  }
  uStack_8._0_1_ = 5;
  if (((uint)piVar10 & 1) != 0) {
    if (0xf < uStack_70) {
      uVar8 = uStack_70 + 1;
      uVar9 = auStack_84[0];
      if (0xfff < uVar8) {
        uVar9 = *(uint *)(auStack_84[0] - 4);
        uVar8 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar8);
    }
    uStack_74 = 0;
    uStack_70 = 0xf;
    auStack_84[0] = auStack_84[0] & 0xffffff00;
  }
  puVar5 = &DAT_01d60bf8;
  if (0xf < DAT_01d60c0c) {
    puVar5 = DAT_01d60bf8;
  }
  FUN_00554150(puVar5,DAT_01d60c08);
  FUN_005cd7e0(aiStack_9c);
  auStack_1c[0] = 1;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  auStack_e8[0] = 0;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  uStack_d0 = 0;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  uStack_b8 = 0;
  uStack_8._0_1_ = 6;
  FUN_0054ef60(aiStack_9c);
  uStack_8._0_1_ = 7;
  FUN_009cbbb0(auStack_54);
  uStack_8._0_1_ = 8;
  uVar4 = FUN_00782480(auStack_24,auStack_54,1,auStack_e8,0x425c0000,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_0078e550(3,uVar4,auStack_1c);
  piVar10 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar10 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar10 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 6;
  if (0xf < uStack_40) {
    uVar8 = uStack_40 + 1;
    uVar9 = auStack_54[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_54[0] - 4);
      uVar8 = uStack_40 + 0x24;
      if (0x1f < (auStack_54[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00637950();
  if (param_5 != 0) {
    auStack_1c[0] = 0;
    uStack_18 = 0;
    uStack_14 = 0;
    FUN_0078e550(9,param_5,auStack_1c);
  }
  if (0xf < uStack_88) {
    uVar9 = uStack_88 + 1;
    iVar6 = aiStack_9c[0];
    if (0xfff < uVar9) {
      iVar6 = *(int *)(aiStack_9c[0] + -4);
      uVar9 = uStack_88 + 0x24;
      if (0x1f < (aiStack_9c[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    uVar9 = auStack_3c[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_3c[0] - 4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10793 ; VA 0x00768a60 ; FUN_00768a60 */

int FUN_00768a60(undefined4 *param_1,int param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_7c [16];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined uStack_64;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined uStack_4c;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ae670;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  piStack_1c = (int *)0x0;
  uStack_8 = 2;
  if (*(int *)(param_4 + 100) == 0) {
    iVar5 = param_2 + 0x3c;
    if (*(int *)(param_4 + 0xb4) != 0) {
      iVar5 = param_2 + 0x24;
    }
    ExceptionList = &pvStack_10;
    FUN_007735a0(iVar5,3);
    FUN_005587e0(&uStack_30);
    piVar3 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  else {
    uStack_6c = 0;
    uStack_68 = 0xf;
    auStack_7c[0] = 0;
    uStack_54 = 0;
    uStack_50 = 0xf;
    uStack_64 = 0;
    uStack_3c = 0;
    uStack_38 = 0xf;
    uStack_4c = 0;
    uStack_8 = 3;
    ExceptionList = &pvStack_10;
    puVar4 = (undefined4 *)FUN_00782480(&uStack_30,param_4 + 0x54,2,auStack_7c,0x425c0000,0);
    piVar1 = piStack_14;
    uStack_18 = *puVar4;
    piVar3 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_14[1] + -1;
      piStack_14[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puVar4 = (undefined4 *)*piStack_14;
        piStack_14 = piVar3;
        (*(code *)*puVar4)();
        LOCK();
        piVar3 = piVar1 + 2;
        iVar5 = *piVar3 + -1;
        *piVar3 = iVar5;
        UNLOCK();
        piVar3 = piStack_14;
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
          piVar3 = piStack_14;
        }
      }
    }
    piStack_14 = piVar3;
    piVar3 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00637950();
  }
  FUN_007735a0(param_2 + 0x44,3);
  piVar3 = piStack_24;
  piStack_24 = piStack_2c;
  uStack_28 = uStack_30;
  uStack_30 = 0;
  piStack_2c = (int *)0x0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  FUN_007735a0(param_2 + 0x4c,3);
  piVar3 = piStack_1c;
  piStack_1c = piStack_2c;
  uStack_20 = uStack_30;
  uStack_30 = 0;
  piStack_2c = (int *)0x0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  iVar5 = FUN_00764f20(*param_1,param_2,&uStack_18,&uStack_28,&uStack_20,
                       *(int *)(param_4 + 0xb4) == 0);
  piVar3 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 10794 ; VA 0x00768d80 ; FUN_00768d80 */

void FUN_00768d80(int param_1,undefined4 param_2,int param_3,uint param_4)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  byte *pbVar7;
  char *pcVar8;
  int iVar9;
  char *pcVar10;
  char *pcVar11;
  uint uVar12;
  int iVar13;
  int *piVar14;
  undefined auStack_1ec [4];
  int *piStack_1e8;
  undefined auStack_1e4 [16];
  undefined4 uStack_1d4;
  undefined4 uStack_1d0;
  undefined uStack_1cc;
  int *piStack_1c4;
  int *piStack_1c0;
  char **ppcStack_1bc;
  uint *puStack_1b8;
  undefined4 *puStack_1b4;
  int *piStack_1b0;
  int *piStack_1ac;
  byte *pbStack_1a8;
  char *pcStack_1a4;
  char *pcStack_1a0;
  undefined4 uStack_19c;
  uint auStack_198 [3];
  undefined auStack_18c [4];
  int *piStack_188;
  byte bStack_184;
  undefined uStack_183;
  undefined4 uStack_180;
  undefined uStack_17c;
  undefined2 auStack_178 [2];
  undefined4 uStack_174;
  undefined uStack_170;
  undefined2 auStack_16c [2];
  undefined4 uStack_168;
  undefined uStack_164;
  byte bStack_160;
  undefined uStack_15f;
  undefined4 uStack_15c;
  undefined uStack_158;
  undefined2 auStack_154 [2];
  undefined4 uStack_150;
  undefined uStack_14c;
  undefined auStack_148 [40];
  int *piStack_120;
  int iStack_11c;
  int iStack_118;
  int iStack_114;
  int iStack_110;
  int iStack_10c;
  int iStack_108;
  int iStack_104;
  undefined4 uStack_100;
  int iStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined2 auStack_f0 [2];
  undefined4 uStack_ec;
  undefined2 uStack_e8;
  undefined2 auStack_e4 [2];
  undefined4 uStack_e0;
  undefined2 uStack_dc;
  undefined2 auStack_d8 [2];
  undefined4 uStack_d4;
  undefined2 uStack_d0;
  undefined2 auStack_cc [2];
  undefined4 uStack_c8;
  undefined2 uStack_c4;
  undefined2 auStack_c0 [2];
  undefined4 uStack_bc;
  undefined2 uStack_b8;
  undefined2 auStack_b4 [2];
  undefined4 uStack_b0;
  undefined2 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  int iStack_84;
  int *piStack_80;
  int iStack_7c;
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  int iStack_58;
  char *pcStack_54;
  char *pcStack_50;
  undefined2 uStack_49;
  undefined uStack_47;
  undefined2 uStack_46;
  undefined uStack_44;
  undefined uStack_43;
  undefined uStack_42;
  undefined uStack_41;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  char *pcStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_13;
  byte bStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  uVar4 = param_4;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ae720;
  pvStack_10 = ExceptionList;
  iStack_24 = *(int *)(param_1 + 0x4f8);
  iStack_58 = *(int *)(param_1 + 0x4ec);
  uVar12 = param_4 & 0x100;
  if (uVar12 == 0) {
    if ((param_4 & 1) == 0) {
      pcVar11 = "Static";
    }
    else {
      pcVar11 = "SmoothSkinned";
      if ((param_4 & 0x1000) == 0) {
        pcVar11 = "Skinned";
      }
    }
  }
  else {
    pcVar11 = "Instanced";
  }
  pcVar8 = pcVar11;
  do {
    cVar3 = *pcVar8;
    pcVar8 = pcVar8 + 1;
  } while (cVar3 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(pcVar11,(int)pcVar8 - (int)(pcVar11 + 1));
  iStack_8 = 0;
  bStack_12 = (byte)(uVar4 >> 1) & 1;
  if ((DAT_01d61b8c == '\0') || (cStack_13 = '\x01', (uVar4 & 4) == 0)) {
    cStack_13 = '\0';
  }
  if ((DAT_01d6c814 == '\0') || (cStack_11 = '\x01', (uVar4 & 0x2000) == 0)) {
    cStack_11 = '\0';
  }
  pcStack_50 = (char *)0x0;
  if (uVar12 == 0) {
    if (((uVar4 & 1) != 0) && (pcStack_50 = (char *)0x2, (uVar4 & 0x1000) != 0)) {
      pcStack_50 = &DAT_00000006;
    }
  }
  else {
    pcStack_50 = (char *)0x1;
  }
  iStack_f8 = FUN_0078e450(*(undefined4 *)(param_1 + 0x5c4));
  if (((DAT_01d60f70 != '\0') && (DAT_01d60f78 != '\0')) && (cVar3 = FUN_0078bbb0(), cVar3 != '\0'))
  {
    cVar3 = FUN_0078ba00();
    uStack_78 = 0x418;
    if (cVar3 != '\0') goto LAB_00768edd;
  }
  uStack_78 = 0x18;
LAB_00768edd:
  auStack_198[2] = uStack_78;
  auStack_198[0] = 0;
  auStack_198[1] = 8;
  iStack_1c = 0;
  iStack_7c = param_3 * 3;
  do {
    iStack_18 = 0;
    iVar9 = iStack_1c;
    do {
      iVar13 = ((iStack_7c + iStack_18) * 7 + iVar9) * 0x10;
      piVar14 = (int *)(&DAT_01eb0258 + iVar13);
      if (*piVar14 != 0) {
        iStack_8._0_1_ = 3;
        pcStack_54 = pcStack_50;
        uStack_74 = 0;
        if ((iVar9 == 5) || (pcStack_28 = pcStack_50, iVar9 == 4)) {
          cVar3 = FUN_007ab8c0();
          uVar4 = -(uint)(cVar3 != '\0') & 0x20;
          if ((bStack_12 == 0) && (cStack_13 == '\0')) {
            uVar12 = 0;
          }
          else {
            uVar12 = 0x80;
          }
          pcStack_28 = (char *)((uint)pcStack_54 | uVar4);
          pcStack_54 = pcStack_28;
          uStack_74 = uVar12 | uVar4;
          iVar9 = iStack_1c;
        }
        pcStack_54 = pcStack_28;
        if (DAT_01d60bc0 == '\0') {
          pcVar11 = *(char **)(&DAT_01eb025c + iVar13);
          piStack_1c4 = &iStack_1c;
          piStack_1c0 = &iStack_18;
          uStack_60 = 0;
          ppcStack_1bc = &pcStack_54;
          puStack_1b8 = &uStack_74;
          puStack_1b4 = &param_1;
          uStack_5c = 0xf;
          piStack_1b0 = &iStack_24;
          piStack_1ac = &iStack_58;
          pbStack_1a8 = &bStack_12;
          pcStack_1a4 = &cStack_11;
          pcStack_1a0 = &cStack_13;
          uStack_19c = param_2;
          auStack_70[0] = auStack_70[0] & 0xffffff00;
          pcVar8 = pcVar11;
          do {
            cVar3 = *pcVar8;
            pcVar8 = pcVar8 + 1;
          } while (cVar3 != '\0');
          FUN_005542c0(pcVar11,(int)pcVar8 - (int)(pcVar11 + 1));
          pcVar11 = (char *)*piVar14;
          iStack_8._0_1_ = 0xb;
          uStack_30 = 0;
          uStack_2c = 0xf;
          auStack_40[0] = auStack_40[0] & 0xffffff00;
          pcVar8 = pcVar11;
          do {
            cVar3 = *pcVar8;
            pcVar8 = pcVar8 + 1;
          } while (cVar3 != '\0');
          FUN_005542c0(pcVar11,(int)pcVar8 - (int)(pcVar11 + 1));
          iStack_8._0_1_ = 0xc;
          FUN_0075e830(auStack_40,auStack_70,0,0);
          iStack_8._0_1_ = 0xb;
          if (0xf < uStack_2c) {
            uVar12 = uStack_2c + 1;
            uVar4 = auStack_40[0];
            if (0xfff < uVar12) {
              uVar4 = *(uint *)(auStack_40[0] - 4);
              uVar12 = uStack_2c + 0x24;
              if (0x1f < (auStack_40[0] - uVar4) - 4) goto LAB_00769b95;
            }
            FUN_01674ea0(uVar4,uVar12);
          }
          uStack_30 = 0;
          uStack_2c = 0xf;
          auStack_40[0] = auStack_40[0] & 0xffffff00;
          iStack_8._0_1_ = 3;
          if (0xf < uStack_5c) {
            uVar12 = uStack_5c + 1;
            uVar4 = auStack_70[0];
            if (0xfff < uVar12) {
              uVar4 = *(uint *)(auStack_70[0] - 4);
              uVar12 = uStack_5c + 0x24;
              if (0x1f < (auStack_70[0] - uVar4) - 4) goto LAB_00769b95;
            }
            FUN_01674ea0(uVar4,uVar12);
          }
          if (iStack_18 != 2) {
            pcVar11 = *(char **)(&DAT_01eb025c + iVar13);
            uStack_30 = 0;
            uStack_2c = 0xf;
            auStack_40[0] = auStack_40[0] & 0xffffff00;
            pcVar8 = pcVar11;
            do {
              cVar3 = *pcVar8;
              pcVar8 = pcVar8 + 1;
            } while (cVar3 != '\0');
            FUN_005542c0(pcVar11,(int)pcVar8 - (int)(pcVar11 + 1));
            pcVar11 = (char *)*piVar14;
            iStack_8._0_1_ = 0xd;
            uStack_60 = 0;
            uStack_5c = 0xf;
            auStack_70[0] = auStack_70[0] & 0xffffff00;
            pcVar8 = pcVar11;
            do {
              cVar3 = *pcVar8;
              pcVar8 = pcVar8 + 1;
            } while (cVar3 != '\0');
            FUN_005542c0(pcVar11,(int)pcVar8 - (int)(pcVar11 + 1));
            iStack_8._0_1_ = 0xe;
            FUN_0075e830(auStack_70,auStack_40,1,8);
            FUN_005507b0();
            iStack_8._0_1_ = 3;
            FUN_005507b0();
            cVar3 = FUN_0078ba00();
            if (cVar3 != '\0') {
              pcVar11 = *(char **)(&DAT_01eb025c + iVar13);
              uStack_30 = 0;
              uStack_2c = 0xf;
              auStack_40[0] = auStack_40[0] & 0xffffff00;
              pcVar8 = pcVar11;
              do {
                cVar3 = *pcVar8;
                pcVar8 = pcVar8 + 1;
              } while (cVar3 != '\0');
              FUN_005542c0(pcVar11,(int)pcVar8 - (int)(pcVar11 + 1));
              pcVar11 = (char *)*piVar14;
              iStack_8._0_1_ = 0xf;
              uStack_60 = 0;
              uStack_5c = 0xf;
              auStack_70[0] = auStack_70[0] & 0xffffff00;
              pcVar8 = pcVar11;
              do {
                cVar3 = *pcVar8;
                pcVar8 = pcVar8 + 1;
              } while (cVar3 != '\0');
              FUN_005542c0(pcVar11,(int)pcVar8 - (int)(pcVar11 + 1));
              iStack_8._0_1_ = 0x10;
              FUN_0075e830(auStack_70,auStack_40,2,uStack_78);
              FUN_005507b0();
              FUN_005507b0();
            }
          }
        }
        else {
          iVar5 = iStack_f8;
          if (iStack_18 == 2) {
            iVar5 = 0;
          }
          iStack_20 = 0;
          if ((param_4 & 0x400) == 0) {
            iStack_20 = iVar5;
          }
          uVar4 = 0;
          if (((iVar9 == 0) || (iVar9 == 6)) &&
             ((uVar4 = auStack_198[iStack_20], iStack_18 < 2 && (DAT_01d60bd8 != '\0')))) {
            uVar4 = uVar4 | 0x200;
          }
          pcVar11 = *(char **)(&DAT_01eb025c + iVar13);
          uStack_f4 = *(undefined4 *)(param_1 + 0x4f4);
          uVar12 = (uint)pcStack_28 | uVar4;
          if (pcVar11 == (char *)0x0) {
            iVar9 = 0;
          }
          else {
            pcStack_28 = pcVar11 + 1;
            pcVar8 = pcVar11;
            do {
              cVar3 = *pcVar8;
              pcVar8 = pcVar8 + 1;
            } while (cVar3 != '\0');
            iVar9 = (int)pcVar8 - (int)pcStack_28;
          }
          pcVar8 = (char *)*piVar14;
          if (pcVar8 == (char *)0x0) {
            iVar13 = 0;
          }
          else {
            pcVar10 = pcVar8;
            do {
              cVar3 = *pcVar10;
              pcVar10 = pcVar10 + 1;
            } while (cVar3 != '\0');
            iVar13 = (int)pcVar10 - (int)(pcVar8 + 1);
          }
          FUN_007910b0(&iStack_84,pcVar8,iVar13,uVar12,pcVar11,iVar9,uStack_74 | uVar4);
          piVar14 = piStack_80;
          iStack_8._0_1_ = 4;
          uVar2 = (undefined)iStack_8;
          iStack_8._0_1_ = 4;
          if (iStack_84 == 0) {
            if (piStack_80 != (int *)0x0) {
              LOCK();
              iVar9 = piStack_80[1] + -1;
              piStack_80[1] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)*piStack_80)();
                LOCK();
                piVar1 = piVar14 + 2;
                iVar9 = *piVar1 + -1;
                *piVar1 = iVar9;
                UNLOCK();
                if (iVar9 == 0) {
                  (**(code **)(*piVar14 + 4))();
                }
              }
            }
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            iVar9 = iStack_1c;
            goto LAB_00769b5c;
          }
          iStack_8._0_1_ = uVar2;
          FUN_0078ded0(&iStack_84,iStack_18,iStack_1c);
          iStack_8._0_1_ = 5;
          uVar2 = (undefined)iStack_8;
          iStack_8._0_1_ = 5;
          switch(iStack_1c) {
          case 0:
          case 6:
            if ((iStack_20 == 1) || (iStack_20 == 2)) {
              iVar9 = iStack_24 + 0x474;
            }
            else {
              iVar9 = iStack_24 + 0x46c;
            }
            auStack_b4[0] = 0x101;
            uStack_b0 = 0;
            uStack_ac = 0;
            FUN_0078e550(1,iVar9,auStack_b4);
            auStack_c0[0] = 0x101;
            uStack_bc = 0;
            uStack_b8 = 0;
            FUN_0078e550(2,*(int *)(iStack_24 + 0x44c) + 0x118,auStack_c0);
            auStack_cc[0] = 0x101;
            uStack_c8 = 0;
            uStack_c4 = 0;
            uStack_1d4 = 0;
            uStack_1d0 = 0xf;
            auStack_1e4[0] = 0;
            ppcStack_1bc = (char **)0x0;
            puStack_1b8 = (uint *)&DAT_0000000f;
            uStack_1cc = 0;
            pcStack_1a4 = (char *)0x0;
            pcStack_1a0 = &DAT_0000000f;
            puStack_1b4 = (undefined4 *)((uint)puStack_1b4 & 0xffffff00);
            iStack_8._0_1_ = 6;
            uStack_30 = 0;
            uStack_2c = 0xf;
            auStack_40[0] = auStack_40[0] & 0xffffff00;
            FUN_005542c0("rbxasset://textures/brdfLUT.dds",0x1f);
            iStack_8._0_1_ = 7;
            FUN_009cbbb0(auStack_40);
            iStack_8._0_1_ = 8;
            uVar6 = FUN_00782480(auStack_1ec,auStack_40,1,auStack_1e4,0x425c0000,0);
            iStack_8 = CONCAT31(iStack_8._1_3_,9);
            FUN_0078e550(0xb,uVar6,auStack_cc);
            piVar14 = piStack_1e8;
            if (piStack_1e8 != (int *)0x0) {
              LOCK();
              iVar9 = piStack_1e8[1] + -1;
              piStack_1e8[1] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)*piStack_1e8)();
                LOCK();
                piVar1 = piVar14 + 2;
                iVar9 = *piVar1 + -1;
                *piVar1 = iVar9;
                UNLOCK();
                if (iVar9 == 0) {
                  (**(code **)(*piVar14 + 4))();
                }
              }
            }
            iStack_8._0_1_ = 6;
            if (0xf < uStack_2c) {
              uVar12 = uStack_2c + 1;
              uVar4 = auStack_40[0];
              if (0xfff < uVar12) {
                uVar4 = *(uint *)(auStack_40[0] - 4);
                uVar12 = uStack_2c + 0x24;
                if (0x1f < (auStack_40[0] - uVar4) - 4) goto LAB_00769b95;
              }
              FUN_01674ea0(uVar4,uVar12);
            }
            uStack_30 = 0;
            uStack_2c = 0xf;
            auStack_40[0] = auStack_40[0] & 0xffffff00;
            iStack_8._0_1_ = 5;
            FUN_00637950();
            auStack_d8[0] = 0x101;
            uStack_d4 = 0;
            uStack_d0 = 0;
            FUN_0078e550(0xe,*(int *)(iStack_24 + 0x44c) + 0x94,auStack_d8);
            auStack_e4[0] = 0x101;
            uStack_e0 = 0;
            uStack_dc = 0;
            FUN_0078e550(0xf,*(int *)(iStack_24 + 0x44c) + 0x84,auStack_e4);
            uStack_42 = bStack_12 == 0;
            uStack_43 = 4;
            uStack_41 = 0;
            FUN_0078e510(&uStack_43);
            if (bStack_12 != 0) {
              uStack_8c = 0x60403;
              uStack_90 = 0xf;
              uStack_88 = 0;
              FUN_0078e480(&uStack_90);
            }
            uVar2 = (undefined)iStack_8;
            if (cStack_11 != '\0') {
              auStack_154[0] = 0;
              pbVar7 = (byte *)auStack_154;
              uStack_150 = 0;
              uStack_14c = 0;
              goto LAB_00769654;
            }
            break;
          case 1:
            uStack_49 = 0x104;
            uStack_47 = 0;
            iStack_8._0_1_ = uVar2;
            FUN_0078e510(&uStack_49);
            uStack_a4 = 0x60102;
            uStack_a8 = 0xf;
            uStack_a0 = 0;
            FUN_0078e480(&uStack_a8);
            uVar2 = (undefined)iStack_8;
            if (DAT_01d60bc8 != '\0') {
              auStack_178[0] = 1;
              pbVar7 = (byte *)auStack_178;
              uStack_174 = 0xffffffff;
              uStack_170 = 0;
              goto LAB_00769654;
            }
            break;
          case 2:
            uStack_15f = 0;
            uStack_15c = 0;
            uStack_158 = 0;
            bStack_160 = (cStack_11 != '\0') - 1U & 2;
            pbVar7 = &bStack_160;
            iStack_8._0_1_ = uVar2;
LAB_00769654:
            FUN_0078e530(pbVar7);
            uVar2 = (undefined)iStack_8;
            break;
          case 3:
            uStack_98 = 0x1000100;
            uStack_9c = 0;
            uStack_94 = 0;
            iStack_8._0_1_ = uVar2;
            FUN_0078e480(&uStack_9c);
            uStack_46 = 0x104;
            uStack_44 = 0;
            FUN_0078e510(&uStack_46);
            uVar2 = (undefined)iStack_8;
            if (cStack_11 != '\0') {
              auStack_16c[0] = 0;
              pbVar7 = (byte *)auStack_16c;
              uStack_168 = 0;
              uStack_164 = 0;
              goto LAB_00769654;
            }
            break;
          case 4:
          case 5:
            uStack_183 = 0;
            uStack_180 = 0;
            uStack_17c = 0;
            bStack_184 = (cStack_11 != '\0') - 1U & 2;
            iStack_8._0_1_ = uVar2;
            FUN_0078e530(&bStack_184);
            if ((bStack_12 != 0) || (uVar2 = (undefined)iStack_8, cStack_13 != '\0')) {
              auStack_f0[0] = 1;
              uStack_ec = 0;
              uStack_e8 = 0;
              FUN_007735a0(iStack_58 + 0x24,3);
              iStack_8._0_1_ = 10;
              FUN_0078e550(3,auStack_18c,auStack_f0);
              piVar14 = piStack_188;
              iStack_8._0_1_ = 5;
              uVar2 = (undefined)iStack_8;
              if (piStack_188 != (int *)0x0) {
                LOCK();
                iVar9 = piStack_188[1] + -1;
                piStack_188[1] = iVar9;
                UNLOCK();
                if (iVar9 == 0) {
                  (**(code **)*piStack_188)();
                  LOCK();
                  piVar1 = piVar14 + 2;
                  iVar9 = *piVar1 + -1;
                  *piVar1 = iVar9;
                  UNLOCK();
                  uVar2 = (undefined)iStack_8;
                  if (iVar9 == 0) {
                    (**(code **)(*piVar14 + 4))();
                    uVar2 = (undefined)iStack_8;
                  }
                }
              }
            }
          }
          iStack_8._0_1_ = uVar2;
          FUN_0078e040(auStack_148,iStack_20);
          iStack_8._0_1_ = 4;
          if (iStack_104 != 0) {
            uVar4 = iStack_fc - iStack_104;
            iVar9 = iStack_104;
            if (0xfff < uVar4) {
              iVar9 = *(int *)(iStack_104 + -4);
              uVar4 = uVar4 + 0x23;
              if (0x1f < (iStack_104 - iVar9) - 4U) goto LAB_00769b95;
            }
            FUN_01674ea0(iVar9,uVar4);
            iStack_104 = 0;
            uStack_100 = 0;
            iStack_fc = 0;
          }
          iVar13 = iStack_10c;
          iVar9 = iStack_110;
          if (iStack_110 != 0) {
            for (; iVar9 != iVar13; iVar9 = iVar9 + 0x10) {
              piVar14 = *(int **)(iVar9 + 0xc);
              if (piVar14 != (int *)0x0) {
                LOCK();
                iVar5 = piVar14[1] + -1;
                piVar14[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*piVar14)();
                  LOCK();
                  iVar5 = piVar14[2] + -1;
                  piVar14[2] = iVar5;
                  UNLOCK();
                  if (iVar5 == 0) {
                    (**(code **)(*piVar14 + 4))();
                  }
                }
              }
            }
            uVar4 = iStack_108 - iStack_110 & 0xfffffff0;
            iVar9 = iStack_110;
            if (0xfff < uVar4) {
              iVar9 = *(int *)(iStack_110 + -4);
              uVar4 = uVar4 + 0x23;
              if (0x1f < (iStack_110 - iVar9) - 4U) goto LAB_00769b95;
            }
            FUN_01674ea0(iVar9,uVar4);
            iStack_110 = 0;
            iStack_10c = 0;
            iStack_108 = 0;
          }
          iVar13 = iStack_118;
          iVar9 = iStack_11c;
          if (iStack_11c != 0) {
            for (; iVar9 != iVar13; iVar9 = iVar9 + 0x14) {
              piVar14 = *(int **)(iVar9 + 4);
              if (piVar14 != (int *)0x0) {
                LOCK();
                iVar5 = piVar14[1] + -1;
                piVar14[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*piVar14)();
                  LOCK();
                  iVar5 = piVar14[2] + -1;
                  piVar14[2] = iVar5;
                  UNLOCK();
                  if (iVar5 == 0) {
                    (**(code **)(*piVar14 + 4))();
                  }
                }
              }
            }
            uVar4 = ((iStack_114 - iStack_11c) / 0x14) * 0x14;
            iVar9 = iStack_11c;
            if (0xfff < uVar4) {
              iVar9 = *(int *)(iStack_11c + -4);
              uVar4 = uVar4 + 0x23;
              if (0x1f < (iStack_11c - iVar9) - 4U) {
LAB_00769b95:
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(iVar9,uVar4);
            iStack_11c = 0;
            iStack_118 = 0;
            iStack_114 = 0;
          }
          piVar14 = piStack_120;
          if (piStack_120 != (int *)0x0) {
            LOCK();
            iVar9 = piStack_120[1] + -1;
            piStack_120[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)*piStack_120)();
              LOCK();
              piVar1 = piVar14 + 2;
              iVar9 = *piVar1 + -1;
              *piVar1 = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)(*piVar14 + 4))();
              }
            }
          }
          piVar14 = piStack_80;
          if (piStack_80 != (int *)0x0) {
            LOCK();
            iVar9 = piStack_80[1] + -1;
            piStack_80[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)*piStack_80)();
              LOCK();
              piVar1 = piVar14 + 2;
              iVar9 = *piVar1 + -1;
              *piVar1 = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)(*piVar14 + 4))();
              }
            }
          }
        }
        FUN_005507b0();
        FUN_005507b0();
        FUN_005507b0();
        FUN_005507b0();
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
        FUN_005507b0();
        iVar9 = iStack_1c;
      }
LAB_00769b5c:
      iStack_18 = iStack_18 + 1;
    } while (iStack_18 < 3);
    iStack_1c = iVar9 + 1;
    if (6 < iVar9 + 1) {
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
  } while( true );
}



/* FUNCTION 10795 ; VA 0x00769bc0 ; FUN_00769bc0 */

undefined4 * __thiscall
FUN_00769bc0(undefined4 *param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5)

{
  bool bVar1;
  char cVar2;
  undefined **ppuVar3;
  undefined4 uStack_14;
  int iStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  *param_1 = 0;
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  if (param_5 != 0) {
    LOCK();
    *(int *)(param_5 + 4) = *(int *)(param_5 + 4) + 1;
    UNLOCK();
  }
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  if (param_5 != 0) {
    LOCK();
    *(int *)(param_5 + 4) = *(int *)(param_5 + 4) + 1;
    UNLOCK();
  }
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  iStack_10 = param_3;
  if (param_5 != 0) {
    LOCK();
    *(int *)(param_5 + 4) = *(int *)(param_5 + 4) + 1;
    UNLOCK();
  }
  uStack_c = param_4;
  iStack_8 = param_5;
  cVar2 = FUN_00585a40(&uStack_14);
  if (cVar2 == '\0') {
    if (iStack_10 != 0) {
      LOCK();
      *(int *)(iStack_10 + 4) = *(int *)(iStack_10 + 4) + 1;
      UNLOCK();
    }
    if (iStack_8 != 0) {
      LOCK();
      *(int *)(iStack_8 + 4) = *(int *)(iStack_8 + 4) + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (iStack_10 != 0) {
      LOCK();
      *(int *)(iStack_10 + 4) = *(int *)(iStack_10 + 4) + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = iStack_10;
    param_1[4] = 0;
    param_1[5] = 0;
    if (iStack_8 != 0) {
      LOCK();
      *(int *)(iStack_8 + 4) = *(int *)(iStack_8 + 4) + 1;
      UNLOCK();
    }
    param_1[5] = iStack_8;
    param_1[4] = uStack_c;
    FUN_0056b650();
    bVar1 = true;
  }
  else {
    bVar1 = false;
  }
  FUN_0056b650();
  FUN_0056b650();
  ppuVar3 = &PTR_FUN_018fb52c;
  if (!bVar1) {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  FUN_0056b650();
  FUN_0056b650();
  return param_1;
}



/* FUNCTION 10796 ; VA 0x00769d00 ; FUN_00769d00 */

void __thiscall FUN_00769d00(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ae730;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_rbx::safe_queue<struct_RBX::Graphics::MeshManager::MeshJob>_>::
              vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10797 ; VA 0x00769d6e ; Catch_All@00769d6e */

void Catch_All_00769d6e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_0076cfb0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10798 ; VA 0x00769d90 ; FUN_00769d90 */

int FUN_00769d90(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01ea8ac8,&LAB_0055d550);
  uVar3 = FUN_00560b40();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00938890();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 10799 ; VA 0x00769e50 ; FUN_00769e50 */

void __thiscall FUN_00769e50(int param_1,undefined4 *param_2,uint param_3,int *param_4)

{
  undefined4 *puVar1;
  char cVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  bool bVar8;
  
  uVar5 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar6 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar6 = (int *)0x0;
    }
    else {
      piVar6 = (int *)*puVar1;
    }
    if (piVar6 != (int *)0x0) {
      do {
        if (param_3 == piVar6[1]) {
          if ((((piVar6[2] == *param_4) &&
               (cVar2 = FUN_009cbaa0(piVar6 + 3,param_4 + 1), cVar2 != '\0')) &&
              (piVar6[9] == param_4[7])) && (piVar6[0x14] == param_4[0x12])) {
            piVar4 = param_4 + 0x13;
            uVar7 = 0xc;
            piVar3 = piVar6 + 0x15;
            do {
              if (*piVar3 != *piVar4) goto LAB_00769f67;
              piVar3 = piVar3 + 1;
              piVar4 = piVar4 + 1;
              bVar8 = 3 < uVar7;
              uVar7 = uVar7 - 4;
            } while (bVar8);
            if ((piVar6[0x19] == param_4[0x17]) &&
               (*(short *)(piVar6 + 0x1a) == *(short *)(param_4 + 0x18))) {
              piVar4 = param_4 + 0xe;
              uVar7 = 0xc;
              piVar3 = piVar6 + 0x10;
              do {
                if (*piVar3 != *piVar4) goto LAB_00769f67;
                piVar3 = piVar3 + 1;
                piVar4 = piVar4 + 1;
                bVar8 = 3 < uVar7;
                uVar7 = uVar7 - 4;
              } while (bVar8);
              piVar4 = param_4 + 8;
              piVar3 = piVar6 + 10;
              if (0xf < (uint)param_4[0xd]) {
                piVar4 = (int *)*piVar4;
              }
              if (0xf < (uint)piVar6[0xf]) {
                piVar3 = (int *)*piVar3;
              }
              cVar2 = FUN_0055c360(piVar3,piVar6[0xe],piVar4,param_4[0xc]);
              if (cVar2 != '\0') break;
            }
          }
        }
        else if ((uint)piVar6[1] % *(uint *)(param_1 + 4) != uVar5) {
          *param_2 = 0;
          return;
        }
LAB_00769f67:
        piVar6 = (int *)*piVar6;
        if (piVar6 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar6;
  return;
}



/* FUNCTION 10800 ; VA 0x00769fa0 ; FUN_00769fa0 */

void FUN_00769fa0(uint *param_1,int *param_2,int *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar2 = 0;
  uVar3 = (uint)((int)param_3 + (3 - (int)param_2)) >> 2;
  if (param_3 < param_2) {
    uVar3 = 0;
  }
  if (uVar3 != 0) {
    do {
      uVar2 = uVar2 + 1;
      uVar1 = *param_1;
      *param_1 = *param_2 + uVar1 * 0x40 + (uVar1 >> 2) + -0x61c88647 ^ uVar1;
      param_2 = param_2 + 1;
    } while (uVar2 != uVar3);
  }
  return;
}



/* FUNCTION 10801 ; VA 0x0076a000 ; FUN_0076a000 */

void FUN_0076a000(int *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x38);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<struct_RBX::Graphics::MeshManager::GeomData>::vftable;
    FUN_0170d1f0(puVar1 + 3,0,0x2c);
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    puVar1[10] = 0;
    puVar1[0xb] = 0;
    param_1[1] = (int)puVar1;
    *param_1 = (int)(puVar1 + 3);
    return;
  }
  param_1[1] = 0;
  *param_1 = 0xc;
  return;
}



/* FUNCTION 10802 ; VA 0x0076a0a0 ; FUN_0076a0a0 */

undefined4 * __thiscall FUN_0076a0a0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ae766;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(param_2 + 4);
  uStack_8 = 2;
  FUN_0054ef60(param_2 + 10);
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_0054ef60(param_2 + 0x10);
  param_1[0x16] = param_2[0x16];
  iVar2 = param_2[0x17];
  param_1[0x17] = iVar2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10803 ; VA 0x0076a180 ; FUN_0076a180 */

undefined4 * __thiscall FUN_0076a180(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ae78b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2 + 8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_2 + 0xe);
  param_1[0x14] = param_2[0x14];
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  if (param_2[0x16] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x16] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x15] = param_2[0x15];
  param_1[0x16] = param_2[0x16];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10804 ; VA 0x0076a250 ; FUN_0076a250 */

undefined4 * __thiscall FUN_0076a250(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ae7d1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(param_2 + 4);
  uStack_8 = 2;
  FUN_0054ef60(param_2 + 10);
  uStack_8 = 3;
  FUN_0054ef60(param_2 + 0x10);
  _uStack_8 = CONCAT31(uStack_7,4);
  FUN_0054ef60(param_2 + 0x16);
  param_1[0x1c] = param_2[0x1c];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10805 ; VA 0x0076a330 ; FUN_0076a330 */

undefined4 * __thiscall FUN_0076a330(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ae78b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2 + 8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_2 + 0xe);
  param_1[0x14] = param_2[0x14];
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  if (param_2[0x16] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x16] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x15] = param_2[0x15];
  param_1[0x16] = param_2[0x16];
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  if (param_2[0x18] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x18] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x17] = param_2[0x17];
  param_1[0x18] = param_2[0x18];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10806 ; VA 0x0076a420 ; FUN_0076a420 */

undefined4 * __thiscall FUN_0076a420(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ae811;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(param_2 + 4);
  uStack_8 = 2;
  FUN_0054ef60(param_2 + 10);
  uStack_8 = 3;
  FUN_0054ef60(param_2 + 0x10);
  _uStack_8 = CONCAT31(uStack_7,4);
  FUN_0054ef60(param_2 + 0x16);
  param_1[0x1c] = param_2[0x1c];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10807 ; VA 0x0076a500 ; FUN_0076a500 */

int __thiscall FUN_0076a500(int param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ae833;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2 + 0x30);
  *(undefined4 *)(param_1 + 0x48) = *(undefined4 *)(param_2 + 0x48);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10808 ; VA 0x0076a570 ; FUN_0076a570 */

int * __thiscall FUN_0076a570(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined **ppuVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  char *pcVar7;
  undefined4 uVar8;
  undefined **ppuVar9;
  int iStack_84;
  int iStack_80;
  undefined4 uStack_7c;
  int iStack_78;
  int iStack_74;
  undefined4 uStack_70;
  int iStack_6c;
  int iStack_68;
  undefined8 uStack_64;
  undefined4 uStack_5c;
  int *piStack_54;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ae914;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  *(undefined *)(param_1 + 1) = 0;
  piStack_14 = (int *)0xb;
  piStack_18 = param_1;
  ppuVar3 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_14);
  ppuVar9 = ppuVar3 + -1;
  if (ppuVar3 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar3;
  }
  param_1[2] = (int)*ppuVar9;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  uStack_8 = 0;
  piVar4 = (int *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 1;
  piStack_14 = piVar4;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    *piVar4 = 0;
    piVar4[1] = 0;
    piVar4[2] = 0;
    piVar4[3] = 0;
    piVar4[4] = 0;
    puVar5 = (undefined4 *)FUN_01674e20(8);
    *piVar4 = (int)puVar5;
    *puVar5 = 0;
    puVar5[1] = 0;
    *(int **)*piVar4 = piVar4;
    piVar4[5] = 0;
  }
  uStack_8._0_1_ = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  FUN_00769d00(piVar4,param_2);
  param_1[0x11] = 0;
  param_1[0x12] = 0xf;
  *(undefined *)(param_1 + 0xd) = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0xf;
  *(undefined *)(param_1 + 0x14) = 0;
  uStack_8._0_1_ = 3;
  FUN_016f4053(param_1 + 0x25,8,3,FUN_005502b0,FUN_00550b30);
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  uStack_8._0_1_ = 5;
  FUN_0147c770();
  uStack_8._0_1_ = 6;
  FUN_0147c770();
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  piVar4 = param_1 + 0x3c;
  uStack_8._0_1_ = 8;
  *piVar4 = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  piStack_1c = piVar4;
  iVar6 = FUN_005cb2b0(0,0);
  param_1[0x3d] = iVar6;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  uStack_8._0_1_ = 10;
  *piVar4 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  iVar6 = GetCurrentThreadId();
  param_1[0xb] = iVar6;
  param_1[10] = 0;
  pcVar7 = (char *)(**(uint **)(*param_1 + 0x520) >> 2);
  if (pcVar7 < s___AU___ContinuationTaskHandle_IX_01e84798 + 0x68) {
    pcVar7 = s___AU___ContinuationTaskHandle_IX_01e84798 + 0x68;
  }
  param_1[9] = (int)pcVar7;
  piStack_14 = *(int **)(*param_1 + 0x3c);
  piVar4 = (int *)FUN_0147c1b0(auStack_40,&DAT_01eb1958,5,0x20);
  iVar6 = *piVar4;
  iVar2 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  param_1[0x25] = iVar6;
  piVar4 = (int *)param_1[0x26];
  param_1[0x26] = iVar2;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar6 = piVar4[1] + -1;
    piVar4[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar6 = piVar4[2] + -1;
      piVar4[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_3c;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)FUN_0147c1b0(auStack_40,&DAT_01eb18e0,5,0x28);
  iVar6 = *piVar4;
  iVar2 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  param_1[0x27] = iVar6;
  piVar4 = (int *)param_1[0x28];
  param_1[0x28] = iVar2;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar6 = piVar4[1] + -1;
    piVar4[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar6 = piVar4[2] + -1;
      piVar4[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_3c;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)FUN_0147c1b0(auStack_40,&DAT_01eb19f8,2,8);
  iVar6 = *piVar4;
  iVar2 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  param_1[0x29] = iVar6;
  piVar4 = (int *)param_1[0x2a];
  param_1[0x2a] = iVar2;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar6 = piVar4[1] + -1;
    piVar4[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar6 = piVar4[2] + -1;
      piVar4[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_3c;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)FUN_0147c1b0(auStack_40,&DAT_01eb19bc,3,0x18);
  iVar6 = *piVar4;
  iVar2 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  param_1[0x2b] = iVar6;
  piVar4 = (int *)param_1[0x2c];
  param_1[0x2c] = iVar2;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar6 = piVar4[1] + -1;
    piVar4[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar6 = piVar4[2] + -1;
      piVar4[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_3c;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  iVar6 = (**(code **)(**(int **)(param_2 + 0x3c) + 0x40))();
  if (*(char *)(iVar6 + 5) != '\0') {
    iStack_84 = 0;
    iStack_80 = 0;
    uStack_7c = 0;
    iStack_78 = 0;
    iStack_74 = 0;
    uStack_70 = 0;
    iStack_6c = 0;
    iStack_68 = 0;
    uStack_8._0_1_ = 0xc;
    uStack_64 = 0;
    uStack_5c = 0;
    FUN_00770180(&iStack_84);
    piVar4 = piStack_14;
    (**(code **)(*piStack_14 + 0x3c))(&piStack_30,0,iStack_80 - iStack_84,0x20,0);
    uStack_8._0_1_ = 0xd;
    (**(code **)(*piVar4 + 0x3c))(&piStack_20,1,(iStack_68 - iStack_6c >> 1) * 2,2,0);
    uStack_8._0_1_ = 0xe;
    (**(code **)(*piStack_30 + 0x18))(0,iStack_84,iStack_80 - iStack_84);
    (**(code **)(*piStack_20 + 0x18))(0,iStack_6c,(iStack_68 - iStack_6c >> 1) * 2);
    FUN_0147c0e0(auStack_40,param_1 + 0x25,&piStack_30,&piStack_20);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    uVar8 = FUN_0147c720(auStack_40,0,0,0,iStack_68 - iStack_6c >> 1);
    FUN_0076b300(uVar8);
    piVar4 = piStack_54;
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_54[1] + -1;
      piStack_54[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_54)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    (**(code **)(*piStack_14 + 0x3c))(&piStack_28,0,(iStack_74 - iStack_78) * 0x18,0x18,0);
    uStack_8._0_1_ = 0x10;
    (**(code **)(*piStack_28 + 0x18))(0,iStack_78,iStack_74 - iStack_78);
    FUN_0147c0e0(auStack_38,param_1 + 0x2b,&piStack_28,&piStack_20);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    uVar8 = FUN_0147c720(auStack_38,0,0,0,iStack_68 - iStack_6c >> 1);
    FUN_0076b300(uVar8);
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_54[1] + -1;
      piStack_54[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_54)();
        LOCK();
        iVar6 = piStack_54[2] + -1;
        piStack_54[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_54 + 4))();
        }
      }
    }
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_34[1] + -1;
      piStack_34[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        iVar6 = piStack_34[2] + -1;
        piStack_34[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_24[1] + -1;
      piStack_24[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar6 = piStack_24[2] + -1;
        piStack_24[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_3c[1] + -1;
      piStack_3c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        iVar6 = piStack_3c[2] + -1;
        piStack_3c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_3c + 4))();
        }
      }
    }
    piVar4 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar4 = piStack_2c + 2;
        iVar6 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    FUN_0076b080();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10809 ; VA 0x0076ac50 ; FUN_0076ac50 */

int __fastcall FUN_0076ac50(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  FUN_0056cd30();
  iVar4 = FUN_00637950();
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0076acb3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 10810 ; VA 0x0076acc0 ; FUN_0076acc0 */

int __fastcall FUN_0076acc0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  piVar3 = *(int **)(param_1 + 0x58);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar4 = FUN_00637950();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0076ad1b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 10811 ; VA 0x0076ad30 ; FUN_0076ad30 */

int __fastcall FUN_0076ad30(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = FUN_00637950();
  uVar2 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 0x10);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0076adcd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 10812 ; VA 0x0076ade0 ; FUN_0076ade0 */

int __fastcall FUN_0076ade0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  piVar3 = *(int **)(param_1 + 0x60);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 0x58);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar4 = FUN_00637950();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0076ae61. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 10813 ; VA 0x0076ae70 ; FUN_0076ae70 */

void __fastcall FUN_0076ae70(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    FUN_0056b650();
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x10);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 10814 ; VA 0x0076af30 ; FUN_0076af30 */

void __fastcall FUN_0076af30(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      piVar2 = *(int **)(iVar3 + 0x70);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      FUN_0076b160();
      iVar3 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar3,0x74);
  }
  return;
}



/* FUNCTION 10815 ; VA 0x0076afa0 ; FUN_0076afa0 */

void __fastcall FUN_0076afa0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[0x1c];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_0076b160();
        FUN_01674ea0(puVar7,0x74);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 10816 ; VA 0x0076b060 ; thunk_FUN_0076b160 */

void __fastcall thunk_FUN_0076b160(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x34);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x20);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0076b1e9;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0xf;
  *(undefined *)(param_1 + 0x20) = 0;
  uVar1 = *(uint *)(param_1 + 0x18);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 4);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0076b1e9:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 10817 ; VA 0x0076b070 ; FUN_0076b070 */

void __fastcall FUN_0076b070(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[0x1c];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_0076b160();
        FUN_01674ea0(puVar7,0x74);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 10818 ; VA 0x0076b080 ; FUN_0076b080 */

void __fastcall FUN_0076b080(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[6];
  if (iVar1 != 0) {
    uVar3 = param_1[8] - iVar1 & 0xfffffffe;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_0076b159;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[8] = 0;
  }
  iVar1 = param_1[3];
  if (iVar1 != 0) {
    uVar3 = param_1[5] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_0076b159;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_0076b159:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 10819 ; VA 0x0076b160 ; FUN_0076b160 */

void __fastcall FUN_0076b160(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x34);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x20);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0076b1e9;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0xf;
  *(undefined *)(param_1 + 0x20) = 0;
  uVar1 = *(uint *)(param_1 + 0x18);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 4);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0076b1e9:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 10820 ; VA 0x0076b1f0 ; FUN_0076b1f0 */

void __fastcall FUN_0076b1f0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005cafb0();
  FUN_00577ac0();
  piVar2 = *(int **)(param_1 + 0xd0);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xb8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xb0);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016f32d1(param_1 + 0x94,8,3,FUN_00550b30);
  FUN_0076b160();
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0076afa0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10821 ; VA 0x0076b300 ; FUN_0076b300 */

undefined4 * __thiscall FUN_0076b300(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  
  uVar1 = *param_2;
  uVar2 = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  *param_1 = uVar1;
  piVar3 = (int *)param_1[1];
  param_1[1] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  return param_1;
}



/* FUNCTION 10822 ; VA 0x0076b370 ; FUN_0076b370 */

undefined4 * __thiscall FUN_0076b370(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = param_2[1];
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
    iVar2 = param_2[1];
  }
  *param_1 = *param_2;
  piVar1 = (int *)param_1[1];
  param_1[1] = iVar2;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  return param_1;
}



/* FUNCTION 10823 ; VA 0x0076b3e0 ; FUN_0076b3e0 */

undefined4 * __thiscall FUN_0076b3e0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  
  *param_1 = *param_2;
  piVar1 = param_2 + 1;
  if (param_1 + 1 != piVar1) {
    if (0xf < (uint)param_2[6]) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,param_2[5]);
  }
  param_1[7] = param_2[7];
  piVar1 = param_2 + 8;
  if (param_1 + 8 != piVar1) {
    if (0xf < (uint)param_2[0xd]) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,param_2[0xc]);
  }
  iVar3 = 0x10;
  puVar2 = param_1 + 0xe;
  do {
    *(undefined *)puVar2 = *(undefined *)(((int)param_2 - (int)param_1) + (int)puVar2);
    iVar3 = iVar3 + -1;
    puVar2 = (undefined4 *)((int)puVar2 + 1);
  } while (iVar3 != 0);
  param_1[0x12] = param_2[0x12];
  iVar3 = 0x10;
  puVar2 = param_1 + 0x13;
  do {
    *(undefined *)puVar2 = *(undefined *)((int)puVar2 + ((int)param_2 - (int)param_1));
    iVar3 = iVar3 + -1;
    puVar2 = (undefined4 *)((int)puVar2 + 1);
  } while (iVar3 != 0);
  *(undefined *)(param_1 + 0x17) = *(undefined *)(param_2 + 0x17);
  *(undefined *)((int)param_1 + 0x5d) = *(undefined *)((int)param_2 + 0x5d);
  *(undefined *)((int)param_1 + 0x5e) = *(undefined *)((int)param_2 + 0x5e);
  *(undefined *)((int)param_1 + 0x5f) = *(undefined *)((int)param_2 + 0x5f);
  *(undefined *)(param_1 + 0x18) = *(undefined *)(param_2 + 0x18);
  *(undefined *)((int)param_1 + 0x61) = *(undefined *)((int)param_2 + 0x61);
  return param_1;
}



/* FUNCTION 10824 ; VA 0x0076b4b0 ; FUN_0076b4b0 */

uint * __thiscall FUN_0076b4b0(byte *param_1,uint *param_2)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  uint uStack_8c;
  undefined auStack_88 [24];
  uint uStack_70;
  undefined auStack_6c [24];
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined2 uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puVar1 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ae949;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  piStack_1c = (int *)FUN_0076cdd0(param_2);
  FUN_00769e50(&param_2,piStack_1c,puVar1,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    piStack_24 = (int *)0x0;
    uStack_20 = 0;
    uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
    param_2 = &uStack_8c;
    iStack_8 = 0;
    uStack_8c = *puVar1;
    FUN_0054ef60(puVar1 + 1);
    uStack_70 = puVar1[7];
    iStack_8._0_1_ = 1;
    FUN_0054ef60(puVar1 + 8);
    uStack_54 = puVar1[0xe];
    uStack_50 = puVar1[0xf];
    uStack_4c = puVar1[0x10];
    uStack_48 = puVar1[0x11];
    uStack_44 = puVar1[0x12];
    uStack_30 = puVar1[0x17];
    uStack_40 = puVar1[0x13];
    uStack_3c = puVar1[0x14];
    uStack_38 = puVar1[0x15];
    uStack_34 = puVar1[0x16];
    uStack_2c = *(undefined2 *)(puVar1 + 0x18);
    iStack_8._0_1_ = 2;
    FUN_0076d120();
    piVar2 = piStack_24;
    piStack_18 = piStack_24;
    param_2 = (uint *)(piStack_24 + 2);
    *param_2 = uStack_8c;
    FUN_0054ef60(auStack_88);
    piVar2[9] = uStack_70;
    iStack_8._0_1_ = 3;
    FUN_0054ef60(auStack_6c);
    uStack_20 = CONCAT11(1,(undefined)uStack_20);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    piVar2[0x10] = uStack_54;
    piVar2[0x11] = uStack_50;
    piVar2[0x12] = uStack_4c;
    piVar2[0x13] = uStack_48;
    piVar2[0x14] = uStack_44;
    piVar2[0x15] = uStack_40;
    piVar2[0x16] = uStack_3c;
    piVar2[0x17] = uStack_38;
    piVar2[0x18] = uStack_34;
    piVar2[0x19] = uStack_30;
    *(undefined2 *)(piVar2 + 0x1a) = uStack_2c;
    piVar2[0x1b] = 0;
    piVar2[0x1c] = 0;
    FUN_0076b160();
    uVar4 = *(uint *)(param_1 + 8);
    uVar6 = uVar4 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar6 = FUN_005c9310(uVar6);
      if (uVar6 <= *(uint *)(param_1 + 4)) {
        uVar6 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar6);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar6) {
      param_2 = (uint *)0x1;
      uVar7 = uVar4 >> 1;
      if (uVar4 + (uVar4 >> 1) <= uVar6) {
        uVar7 = 1;
      }
      uVar6 = FUN_005c9310(uVar7 + uVar4);
      puVar1 = (uint *)(param_1 + 4);
      param_2 = puVar1;
      if (uVar6 != *puVar1) {
        FUN_005d2b00(uVar6);
        puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
        puVar5 = (undefined4 *)*puVar8;
        while (puVar5 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar5[1] % *param_2) * 4);
          if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar5[1] % *param_2) * 4) == 0) {
            *piVar2 = (int)puVar8;
            puVar8 = puVar5;
          }
          else {
            *puVar8 = *puVar5;
            *puVar5 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar5;
          }
          param_1 = pbStack_14;
          puVar5 = (undefined4 *)*puVar8;
        }
      }
    }
    piVar2 = piStack_18;
    piStack_24 = (int *)0x0;
    piStack_18[1] = (int)piStack_1c;
    pbStack_14 = *(byte **)(param_1 + 4);
    piStack_1c = (int *)(*(int *)(param_1 + 0x14) + ((uint)piStack_1c % (uint)pbStack_14) * 4);
    if ((int *)*piStack_1c == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + (int)pbStack_14 * 4);
      if (*piVar3 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % (uint)pbStack_14) * 4) =
             piStack_18;
      }
      *piStack_1c = (int)piVar3;
      *piStack_18 = *piVar3;
      *piVar3 = (int)piStack_18;
    }
    else {
      *piStack_18 = *(int *)*piStack_1c;
      *(int **)*piStack_1c = piStack_18;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    FUN_0076af30();
    ExceptionList = pvStack_10;
    return (uint *)(piVar2 + 2);
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 10825 ; VA 0x0076b740 ; FUN_0076b740 */

void __fastcall FUN_0076b740(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined *puVar4;
  int *piVar5;
  int iVar6;
  undefined8 uVar7;
  int iStack_60;
  int iStack_5c;
  undefined4 *puStack_58;
  int iStack_54;
  undefined4 uStack_48;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ae97c;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff6c;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  puVar4 = &stack0xffffff6c;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1a68) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1a68);
    puVar4 = puStack_14;
    if (DAT_01eb1a68 == -1) {
      uStack_8 = 0;
      uVar7 = FUN_0152dab0("Systems","Async_Mesh",0xffffffff);
      DAT_01eb1a64 = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eb1a60 = (undefined4)uVar7;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb1a68);
      puVar4 = puStack_14;
    }
  }
  puStack_14 = puVar4;
  uStack_2c = DAT_01eb1a60;
  uStack_38 = DAT_01eb1a60;
  uStack_28 = DAT_01eb1a64;
  uStack_34 = DAT_01eb1a64;
  uVar7 = FUN_0152d930(DAT_01eb1a60,DAT_01eb1a64);
  iStack_5c = *(int *)(param_1 + 0xc);
  if (iStack_5c != 0) {
    LOCK();
    *(int *)(iStack_5c + 4) = *(int *)(iStack_5c + 4) + 1;
    UNLOCK();
    iStack_5c = *(int *)(param_1 + 0xc);
  }
  iStack_60 = *(int *)(param_1 + 8);
  puStack_58 = (undefined4 *)0x0;
  iStack_54 = 0;
  uStack_8 = 3;
  iStack_24 = iStack_60;
  iStack_20 = FUN_00a33fa0();
  piVar5 = (int *)FUN_0076a000(auStack_40);
  iStack_54 = piVar5[1];
  puVar1 = (undefined4 *)*piVar5;
  *piVar5 = 0;
  piVar5[1] = 0;
  piStack_1c = piStack_3c;
  puStack_58 = puVar1;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      iVar6 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  puVar1[9] = 2;
  puVar1[10] = 8;
  if (*(int *)(iStack_20 + 0x10) == 0) {
    FUN_007303c0();
  }
  else {
    iVar6 = FUN_00730fd0(iStack_20,puVar1,puVar1 + 6);
    if (iVar6 != 0) {
      puVar1[1] = *puVar1;
      puVar1[7] = puVar1[6];
      goto LAB_0076b8c2;
    }
  }
  uVar3 = DAT_018f7860;
  uVar2 = DAT_018ce2f4;
  piStack_3c = (int *)0xbf000000;
  uStack_48 = 0x3f000000;
  *(undefined4 *)(iStack_24 + 0x168) = DAT_018f7860;
  *(undefined4 *)(iStack_24 + 0x16c) = uVar3;
  *(undefined4 *)(iStack_24 + 0x170) = 0xbf000000;
  *(undefined4 *)(iStack_24 + 0x174) = uVar2;
  *(ulonglong *)(iStack_24 + 0x178) = CONCAT44(0x3f000000,uVar2);
LAB_0076b8c2:
  LOCK();
  *(undefined4 *)(*(int *)(param_1 + 8) + 4) = 3;
  UNLOCK();
  FUN_00772ec0(&iStack_60);
  if (DAT_01eb18d8 != '\0') {
    FUN_01677520(DAT_01eb18d8,"Mesh manager: decoded (ModelMesh)");
  }
  FUN_0056b650();
  uStack_8 = 4;
  FUN_0076b9ab(uStack_28,uVar7);
  return;
}



/* FUNCTION 10826 ; VA 0x0076b932 ; Catch@0076b932 */

undefined * Catch_0076b932(void)

{
  int *piVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -0x2c);
  if (DAT_01eafe10 != '\0') {
    uVar2 = (**(code **)(*piVar1 + 4))();
    FUN_01677520(DAT_01eafe10,"MeshManager: adding ModelMesh base exception %s",uVar2);
  }
  uVar2 = (**(code **)(*piVar1 + 4))();
  FUN_00772fb0("error decoding (ModelMesh)",*(int *)(*(int *)(unaff_EBP + -0x14) + 8) + 0xc,uVar2,
               *(int *)(unaff_EBP + -0x14) + 0x10);
  return &DAT_0076b988;
}



/* FUNCTION 10827 ; VA 0x0076b9ab ; FUN_0076b9ab */

void FUN_0076b9ab(void)

{
  int unaff_EBP;
  
  FUN_0152dda0();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 10828 ; VA 0x0076ba20 ; FUN_0076ba20 */

/* WARNING: Type propagation algorithm not settling */

undefined4 * __thiscall
FUN_0076ba20(undefined4 *param_1,int param_2,int *param_3,int *param_4,int param_5,int *param_6,
            int *param_7,int *param_8)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  char *pcVar7;
  undefined auStack_c8 [20];
  int iStack_b4;
  undefined **appuStack_b0 [15];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_64;
  undefined **ppuStack_60;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ae9e2;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((param_5 == 0) && (ExceptionList = &pvStack_10, param_3 != (int *)0x0)) {
    appuStack_b0[0] = &PTR_018be314;
    uStack_8 = 3;
    piStack_14 = (int *)0x1;
    ppuStack_60 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_64 = 0x48;
    ExceptionList = &pvStack_10;
    FUN_00554f20(appuStack_b0 + 1,0);
    uStack_8 = 5;
    *(undefined ***)(appuStack_b0[0][1] + (int)appuStack_b0) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&iStack_b4 + (int)appuStack_b0[0][1]) = appuStack_b0[0][1] + -0x50;
    FUN_0054ee60();
    appuStack_b0[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_74 = 0;
    uStack_70 = 4;
    uStack_8._0_1_ = 6;
    FUN_0056f130(*(undefined4 *)(*(int *)(*param_3 + 4) + 0x38 + (int)param_3));
    uVar4 = FUN_0058c400(auStack_c8);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    uVar4 = FUN_00729170(auStack_18,uVar4);
    FUN_005587e0(uVar4);
    piVar2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_14[1] + -1;
      piStack_14[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00570540();
  }
  if (param_2 == 1) {
    if ((param_5 != 0) && (*(int *)(param_5 + 0x10) != 0)) {
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      if (param_1[1] != 0) {
        LOCK();
        piVar2 = (int *)(param_1[1] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      uVar4 = *param_1;
      uVar3 = param_1[1];
      if (param_1[0x16] != 0) {
        LOCK();
        piVar2 = (int *)(param_1[0x16] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      puVar6 = (undefined4 *)
               FUN_00770e60(param_1[0x15],param_1[0x16],param_1 + 2,uVar4,uVar3,param_5,param_6);
      goto LAB_0076bc71;
    }
    uVar4 = 0;
    iVar5 = param_1[0x15] + 0xc;
    pcVar7 = "http response payload is empty";
  }
  else if (param_7 == (int *)0x0) {
    uVar4 = 0;
    iVar5 = param_1[0x15] + 0xc;
    pcVar7 = "http request failed";
  }
  else {
    uVar4 = (**(code **)(*param_7 + 4))();
    iVar5 = param_1[0x15] + 0xc;
    pcVar7 = "http request failed";
  }
  FUN_00772fb0(pcVar7,iVar5,uVar4,param_1 + 2);
  puVar6 = (undefined4 *)(param_1[0x15] + 4);
  LOCK();
  *puVar6 = 5;
  UNLOCK();
LAB_0076bc71:
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar2 = param_4 + 1;
    iVar5 = *piVar2;
    puVar6 = (undefined4 *)*piVar2;
    *piVar2 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar5 = *piVar2;
      puVar6 = (undefined4 *)*piVar2;
      *piVar2 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        puVar6 = (undefined4 *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar2 = param_6 + 1;
    iVar5 = *piVar2;
    puVar6 = (undefined4 *)*piVar2;
    *piVar2 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar2 = param_6 + 2;
      iVar5 = *piVar2;
      puVar6 = (undefined4 *)*piVar2;
      *piVar2 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        puVar6 = (undefined4 *)(**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar2 = param_8 + 1;
    iVar5 = *piVar2;
    puVar6 = (undefined4 *)*piVar2;
    *piVar2 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      puVar6 = (undefined4 *)(**(code **)*param_8)();
      LOCK();
      piVar2 = param_8 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        puVar6 = (undefined4 *)(**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 10829 ; VA 0x0076bd00 ; FUN_0076bd00 */

void __fastcall FUN_0076bd00(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  undefined4 uStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aea14;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa4;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puVar4 = &stack0xffffffa4;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1a58) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1a58);
    puVar4 = puStack_14;
    if (DAT_01eb1a58 == -1) {
      uStack_8 = 0;
      uVar7 = FUN_0152dab0("Systems","Async_Mesh",0xffffffff);
      DAT_01eb1a54 = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eb1a50 = (undefined4)uVar7;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb1a58);
      puVar4 = puStack_14;
    }
  }
  puStack_14 = puVar4;
  uStack_30 = DAT_01eb1a50;
  uStack_18 = DAT_01eb1a54;
  uStack_2c = DAT_01eb1a54;
  uStack_40 = DAT_01eb1a50;
  uStack_3c = DAT_01eb1a54;
  uStack_38 = FUN_0152d930(DAT_01eb1a50,DAT_01eb1a54);
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  puVar5 = (undefined4 *)FUN_00cfa7a0();
  uVar6 = (**(code **)*puVar5)();
  iStack_28 = 0;
  piStack_24 = (int *)0x0;
  FUN_00727ee0(uVar6,iStack_1c);
  iVar2 = iStack_28;
  uStack_8._0_1_ = 3;
  FUN_00cf9ed0(param_1 + 0x10);
  piVar3 = piStack_24;
  if (*(int *)(iVar2 + 0x10) == *(int *)(iVar2 + 0x14)) {
    LOCK();
    *(undefined4 *)(*(int *)(param_1 + 8) + 4) = 5;
    UNLOCK();
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uStack_8 = 4;
    FUN_0076bf0d(uStack_18,uStack_38);
    return;
  }
  iStack_4c = *(int *)(param_1 + 0xc);
  if (iStack_4c != 0) {
    LOCK();
    *(int *)(iStack_4c + 4) = *(int *)(iStack_4c + 4) + 1;
    UNLOCK();
    iStack_4c = *(int *)(param_1 + 0xc);
  }
  uStack_50 = *(undefined4 *)(param_1 + 8);
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00771120(&uStack_50,iVar2);
  LOCK();
  *(undefined4 *)(*(int *)(param_1 + 8) + 4) = 3;
  UNLOCK();
  FUN_00772ec0(&uStack_50);
  if (DAT_01eb18d8 != '\0') {
    puVar5 = (undefined4 *)(*(int *)(param_1 + 8) + 0xc);
    if (0xf < *(uint *)(*(int *)(param_1 + 8) + 0x20)) {
      puVar5 = (undefined4 *)*puVar5;
    }
    FUN_01677520(DAT_01eb18d8,"Mesh manager: decoded (Studio CSG) \'%s\'",puVar5);
  }
  FUN_0056b650();
  piVar3 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = 6;
  FUN_0076bf0d(uStack_18,uStack_38);
  return;
}



/* FUNCTION 10830 ; VA 0x0076bec0 ; Catch@0076bec0 */

undefined * Catch_0076bec0(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_00772fb0("error decoding (Studio CSG)",*(int *)(*(int *)(unaff_EBP + -0x18) + 8) + 0xc,uVar1,
               *(int *)(unaff_EBP + -0x18) + 0x28);
  return &DAT_0076beea;
}



/* FUNCTION 10831 ; VA 0x0076bf0d ; FUN_0076bf0d */

void FUN_0076bf0d(void)

{
  int unaff_EBP;
  
  FUN_0152dda0();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 10832 ; VA 0x0076bf80 ; FUN_0076bf80 */

undefined4 * __thiscall
FUN_0076bf80(undefined4 *param_1,int param_2,int param_3,int *param_4,int param_5,int *param_6,
            int *param_7,int *param_8)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined auStack_2c0 [100];
  undefined auStack_25c [100];
  undefined auStack_1f8 [100];
  undefined auStack_194 [120];
  int iStack_11c;
  undefined **appuStack_118 [13];
  undefined auStack_e4 [8];
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_cc;
  undefined **ppuStack_c8;
  undefined4 uStack_80;
  int iStack_7c;
  int aiStack_78 [18];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int iStack_24;
  int *piStack_20;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aeade;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined4 *)0x0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((param_5 == 0) && (ExceptionList = &pvStack_10, param_3 != 0)) {
    appuStack_118[0] = &PTR_018be314;
    uStack_8 = 3;
    puStack_14 = (undefined4 *)0x1;
    ppuStack_c8 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_cc = 0x48;
    ExceptionList = &pvStack_10;
    FUN_00554f20();
    uStack_8 = 5;
    *(undefined ***)((int)appuStack_118 + (int)appuStack_118[0][1]) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&iStack_11c + (int)appuStack_118[0][1]) = appuStack_118[0][1] + -0x50;
    FUN_0054ee60();
    appuStack_118[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_dc = 0;
    uStack_d8 = 4;
    uStack_8._0_1_ = 6;
    FUN_0056f130();
    FUN_0058c400();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_00729170();
    FUN_005587e0();
    piVar2 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00570540();
  }
  if (param_2 == 1) {
    if ((param_5 != 0) && (*(int *)(param_5 + 0x10) != 0)) {
      LOCK();
      *(undefined4 *)(param_1[0x15] + 4) = 2;
      UNLOCK();
      iStack_7c = param_1[1];
      puStack_14 = &uStack_80;
      if (iStack_7c != 0) {
        LOCK();
        *(int *)(iStack_7c + 4) = *(int *)(iStack_7c + 4) + 1;
        UNLOCK();
        iStack_7c = param_1[1];
      }
      uStack_80 = *param_1;
      piStack_18 = aiStack_78;
      uStack_8._0_1_ = 8;
      FUN_0054ef60(param_1 + 2);
      uStack_8._0_1_ = 9;
      FUN_0054ef60(param_1 + 8);
      uStack_8._0_1_ = 10;
      FUN_0054ef60(param_1 + 0xe);
      iStack_28 = param_1[0x16];
      uStack_30 = param_1[0x14];
      if (iStack_28 != 0) {
        LOCK();
        *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 1;
        UNLOCK();
        iStack_28 = param_1[0x16];
      }
      uStack_2c = param_1[0x15];
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      iStack_24 = param_5;
      piStack_20 = param_6;
      uStack_8._0_1_ = 0xb;
      FUN_0076a330(&uStack_80);
      uStack_8._0_1_ = 0xc;
      FUN_0076a330(auStack_e4);
      uStack_8._0_1_ = 0xd;
      FUN_0076a330(auStack_2c0);
      uStack_8._0_1_ = 0xe;
      FUN_0076a330(auStack_25c);
      uStack_8._0_1_ = 0xf;
      cVar4 = FUN_00585a40(auStack_194);
      if (cVar4 == '\0') {
        FUN_0076a330(auStack_194);
        uStack_8._0_1_ = 0x10;
        piStack_18 = (int *)FUN_01674e20(100);
        uStack_8._0_1_ = 0x11;
        if (piStack_18 != (int *)0x0) {
          FUN_0076a330(auStack_1f8);
        }
        FUN_0076ade0();
        FUN_0076ade0();
      }
      else {
        FUN_0076ade0();
      }
      FUN_0076ade0();
      FUN_0076ade0();
      FUN_0076ade0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_0076ade0();
      puVar5 = (undefined4 *)FUN_0151ddd0();
      if (DAT_01eb18d8 != '\0') {
        puVar5 = (undefined4 *)FUN_01677520();
      }
      goto LAB_0076c36b;
    }
  }
  else if (param_7 != (int *)0x0) {
    (**(code **)(*param_7 + 4))();
  }
  FUN_00772fb0();
  puVar5 = (undefined4 *)(param_1[0x15] + 4);
  LOCK();
  *puVar5 = 5;
  UNLOCK();
LAB_0076c36b:
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar2 = param_4 + 1;
    iVar3 = *piVar2;
    puVar5 = (undefined4 *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      puVar5 = (undefined4 *)*piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        puVar5 = (undefined4 *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar2 = param_6 + 1;
    iVar3 = *piVar2;
    puVar5 = (undefined4 *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar2 = param_6 + 2;
      iVar3 = *piVar2;
      puVar5 = (undefined4 *)*piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        puVar5 = (undefined4 *)(**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar2 = param_8 + 1;
    iVar3 = *piVar2;
    puVar5 = (undefined4 *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      puVar5 = (undefined4 *)(**(code **)*param_8)();
      LOCK();
      piVar2 = param_8 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puVar5 = (undefined4 *)(**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 10833 ; VA 0x0076c3f0 ; FUN_0076c3f0 */

void __fastcall FUN_0076c3f0(int param_1)

{
  int *piVar1;
  undefined *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  undefined auStack_120 [184];
  undefined auStack_68 [8];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int aiStack_34 [2];
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aeb3f;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffed4;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puVar2 = &stack0xfffffed4;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1a88) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb1a88), puVar2 = puStack_14,
     DAT_01eb1a88 == -1)) {
    uStack_8 = 0;
    uVar5 = FUN_0152dab0("Systems","Async_Mesh",0xffffffff);
    DAT_01eb1a84 = (undefined4)((ulonglong)uVar5 >> 0x20);
    DAT_01eb1a80 = (undefined4)uVar5;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb1a88);
    puVar2 = puStack_14;
  }
  puStack_14 = puVar2;
  uVar4 = DAT_01eb1a80;
  uStack_38 = DAT_01eb1a80;
  uStack_58 = DAT_01eb1a80;
  uStack_18 = DAT_01eb1a84;
  uStack_54 = DAT_01eb1a84;
  uStack_50 = DAT_01eb1a80;
  uStack_4c = DAT_01eb1a84;
  uStack_48 = FUN_0152d930(DAT_01eb1a80,DAT_01eb1a84);
  piVar1 = (int *)(param_1 + 0x54);
  uStack_8._1_3_ = 0;
  switch(*(undefined4 *)(*(int *)(param_1 + 0x54) + 8)) {
  case 0xd:
  case 0xe:
  case 0x12:
    iStack_28 = 0;
    iStack_24 = 0;
    uStack_20 = 0;
    uStack_8._0_1_ = 8;
    FUN_00729510(*(undefined4 *)(param_1 + 0x5c),3,1);
    uStack_8._0_1_ = 9;
    FUN_00a204e0(auStack_120,&iStack_28,0,0);
    if (iStack_28 != iStack_24) {
      FUN_00728ef0(aiStack_34,iStack_28);
      uStack_8._0_1_ = 10;
      if (aiStack_34[0] != 0) {
        puVar3 = (undefined4 *)FUN_00cfa7a0();
        uVar4 = (**(code **)*puVar3)();
        uStack_40 = 0;
        uStack_3c = 0;
        FUN_00727ee0(uVar4,uStack_38);
        uVar4 = uStack_40;
        uStack_8._0_1_ = 0xb;
        FUN_00cf9ed0(aiStack_34[0] + 0x5c);
        FUN_00557fc0(piVar1);
        uStack_60 = 0;
        uStack_5c = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
        FUN_00771120(auStack_68,uVar4);
        LOCK();
        *(undefined4 *)(*piVar1 + 4) = 3;
        UNLOCK();
        FUN_00772ec0(auStack_68);
        if (DAT_01eb18d8 != '\0') {
          puVar3 = (undefined4 *)(*piVar1 + 0xc);
          if (0xf < *(uint *)(*piVar1 + 0x20)) {
            puVar3 = (undefined4 *)*puVar3;
          }
          FUN_01677520(DAT_01eb18d8,"Mesh manager: decoded (CSG Asset) \'%s\'",puVar3);
        }
        FUN_0056b650();
        FUN_00550b30();
        FUN_00550b30();
        FUN_005705c0();
        thunk_FUN_00577ac0();
        uStack_8 = 0xd;
        uVar4 = uStack_38;
        break;
      }
      FUN_00550b30();
    }
    FUN_005705c0();
    thunk_FUN_00577ac0();
  default:
    LOCK();
    *(undefined4 *)(*(int *)(param_1 + 0x54) + 4) = 5;
    UNLOCK();
    uStack_8 = 0xf;
    break;
  case 0xf:
  case 0x10:
  case 0x11:
    iStack_28 = *(int *)(param_1 + 0x58);
    if (iStack_28 != 0) {
      LOCK();
      *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 1;
      UNLOCK();
      iStack_28 = *(int *)(param_1 + 0x58);
    }
    iStack_2c = *piVar1;
    iStack_24 = 0;
    uStack_20 = 0;
    uStack_8._0_1_ = 3;
    FUN_0114fa10(aiStack_34,*(undefined4 *)(param_1 + 0x5c));
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_007716b0(&iStack_2c,aiStack_34[0]);
    LOCK();
    *(undefined4 *)(*piVar1 + 4) = 3;
    UNLOCK();
    FUN_00772ec0(&iStack_2c);
    if (DAT_01eb18d8 != '\0') {
      puVar3 = (undefined4 *)(*piVar1 + 0xc);
      if (0xf < *(uint *)(*piVar1 + 0x20)) {
        puVar3 = (undefined4 *)*puVar3;
      }
      FUN_01677520(DAT_01eb18d8,"Mesh manager: decoded \'%s\'",puVar3);
    }
    FUN_00550b30();
    FUN_0056b650();
    uStack_8 = 5;
  }
  FUN_0152dda0(uVar4,uStack_18,uStack_48);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10834 ; VA 0x0076c532 ; Catch@0076c532 */

undefined * Catch_0076c532(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x68) + 4))();
  FUN_00772fb0("error decoding (Mesh)",*(int *)(*(int *)(unaff_EBP + -0x18) + 0x54) + 0xc,uVar1,
               *(int *)(unaff_EBP + -0x18) + 8);
  return &DAT_0076c727;
}



/* FUNCTION 10835 ; VA 0x0076c55c ; caseD_d */

void switchD_0076c482::caseD_d(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int unaff_EBP;
  int *unaff_ESI;
  int unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -0x24) = 0;
  *(undefined4 *)(unaff_EBP + -0x20) = 0;
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  uVar3 = *(undefined4 *)(unaff_EDI + 0x5c);
  *(undefined *)(unaff_EBP + -4) = 8;
  FUN_00729510(uVar3,3,1);
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_00a204e0(unaff_EBP + -0x11c,unaff_EBP + -0x24,0,0);
  if (*(int *)(unaff_EBP + -0x24) != *(int *)(unaff_EBP + -0x20)) {
    FUN_00728ef0(unaff_EBP + -0x30,*(int *)(unaff_EBP + -0x24));
    iVar1 = *(int *)(unaff_EBP + -0x30);
    *(undefined *)(unaff_EBP + -4) = 10;
    if (iVar1 != 0) {
      puVar2 = (undefined4 *)FUN_00cfa7a0();
      uVar3 = (**(code **)*puVar2)();
      *(undefined4 *)(unaff_EBP + -0x3c) = 0;
      *(undefined4 *)(unaff_EBP + -0x38) = 0;
      FUN_00727ee0(uVar3,*(undefined4 *)(unaff_EBP + -0x34));
      uVar3 = *(undefined4 *)(unaff_EBP + -0x3c);
      *(undefined *)(unaff_EBP + -4) = 0xb;
      FUN_00cf9ed0(iVar1 + 0x5c);
      FUN_00557fc0(unaff_ESI);
      *(undefined4 *)(unaff_EBP + -0x5c) = 0;
      *(undefined4 *)(unaff_EBP + -0x58) = 0;
      *(undefined *)(unaff_EBP + -4) = 0xc;
      FUN_00771120(unaff_EBP + -100,uVar3);
      LOCK();
      *(undefined4 *)(*unaff_ESI + 4) = 3;
      UNLOCK();
      FUN_00772ec0(unaff_EBP + -100);
      if (DAT_01eb18d8 != '\0') {
        puVar2 = (undefined4 *)(*unaff_ESI + 0xc);
        if (0xf < *(uint *)(*unaff_ESI + 0x20)) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_01677520(DAT_01eb18d8,"Mesh manager: decoded (CSG Asset) \'%s\'",puVar2);
      }
      FUN_0056b650();
      FUN_00550b30();
      FUN_00550b30();
      FUN_005705c0();
      thunk_FUN_00577ac0();
      *(undefined4 *)(unaff_EBP + -4) = 0xd;
      goto LAB_0076c6e4;
    }
    FUN_00550b30();
  }
  FUN_005705c0();
  thunk_FUN_00577ac0();
  LOCK();
  *(undefined4 *)(*(int *)(unaff_EDI + 0x54) + 4) = 5;
  UNLOCK();
  *(undefined4 *)(unaff_EBP + -4) = 0xf;
LAB_0076c6e4:
  FUN_0152dda0();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 10836 ; VA 0x0076c6fd ; Catch@0076c6fd */

undefined * Catch_0076c6fd(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x6c) + 4))();
  FUN_00772fb0("error decoding (CSG Asset)",*(int *)(*(int *)(unaff_EBP + -0x18) + 0x54) + 0xc,uVar1
               ,*(int *)(unaff_EBP + -0x18) + 8);
  return &DAT_0076c727;
}



/* FUNCTION 10837 ; VA 0x0076c7a0 ; FUN_0076c7a0 */

void __fastcall FUN_0076c7a0(int param_1)

{
  int *piVar1;
  undefined *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  undefined auStack_120 [184];
  undefined auStack_68 [8];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int aiStack_34 [2];
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aeb9f;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffed4;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puVar2 = &stack0xfffffed4;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1a78) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb1a78), puVar2 = puStack_14,
     DAT_01eb1a78 == -1)) {
    uStack_8 = 0;
    uVar5 = FUN_0152dab0("Systems","Async_Mesh",0xffffffff);
    DAT_01eb1a74 = (undefined4)((ulonglong)uVar5 >> 0x20);
    DAT_01eb1a70 = (undefined4)uVar5;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb1a78);
    puVar2 = puStack_14;
  }
  puStack_14 = puVar2;
  uVar4 = DAT_01eb1a70;
  uStack_38 = DAT_01eb1a70;
  uStack_58 = DAT_01eb1a70;
  uStack_18 = DAT_01eb1a74;
  uStack_54 = DAT_01eb1a74;
  uStack_50 = DAT_01eb1a70;
  uStack_4c = DAT_01eb1a74;
  uStack_48 = FUN_0152d930(DAT_01eb1a70,DAT_01eb1a74);
  piVar1 = (int *)(param_1 + 0x54);
  uStack_8._1_3_ = 0;
  switch(*(undefined4 *)(*(int *)(param_1 + 0x54) + 8)) {
  case 0xd:
  case 0xe:
  case 0x12:
    iStack_28 = 0;
    iStack_24 = 0;
    uStack_20 = 0;
    uStack_8._0_1_ = 8;
    FUN_00729510(*(undefined4 *)(param_1 + 0x5c),3,1);
    uStack_8._0_1_ = 9;
    FUN_00a204e0(auStack_120,&iStack_28,0,0);
    if (iStack_28 != iStack_24) {
      FUN_00728ef0(aiStack_34,iStack_28);
      uStack_8._0_1_ = 10;
      if (aiStack_34[0] != 0) {
        puVar3 = (undefined4 *)FUN_00cfa7a0();
        uVar4 = (**(code **)*puVar3)();
        uStack_40 = 0;
        uStack_3c = 0;
        FUN_00727ee0(uVar4,uStack_38);
        uVar4 = uStack_40;
        uStack_8._0_1_ = 0xb;
        FUN_00cf9ed0(aiStack_34[0] + 0x5c);
        FUN_00557fc0(piVar1);
        uStack_60 = 0;
        uStack_5c = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
        FUN_00771120(auStack_68,uVar4);
        LOCK();
        *(undefined4 *)(*piVar1 + 4) = 3;
        UNLOCK();
        FUN_00772ec0(auStack_68);
        if (DAT_01eb18d8 != '\0') {
          puVar3 = (undefined4 *)(*piVar1 + 0xc);
          if (0xf < *(uint *)(*piVar1 + 0x20)) {
            puVar3 = (undefined4 *)*puVar3;
          }
          FUN_01677520(DAT_01eb18d8,"Mesh manager: decoded (CSG Asset) \'%s\'",puVar3);
        }
        FUN_0056b650();
        FUN_00550b30();
        FUN_00550b30();
        FUN_005705c0();
        thunk_FUN_00577ac0();
        uStack_8 = 0xd;
        uVar4 = uStack_38;
        break;
      }
      FUN_00550b30();
    }
    FUN_005705c0();
    thunk_FUN_00577ac0();
  default:
    LOCK();
    *(undefined4 *)(*(int *)(param_1 + 0x54) + 4) = 5;
    UNLOCK();
    uStack_8 = 0xf;
    break;
  case 0xf:
  case 0x10:
  case 0x11:
    iStack_28 = *(int *)(param_1 + 0x58);
    if (iStack_28 != 0) {
      LOCK();
      *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 1;
      UNLOCK();
      iStack_28 = *(int *)(param_1 + 0x58);
    }
    iStack_2c = *piVar1;
    iStack_24 = 0;
    uStack_20 = 0;
    uStack_8._0_1_ = 3;
    FUN_0114fa10(aiStack_34,*(undefined4 *)(param_1 + 0x5c));
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_007716b0(&iStack_2c,aiStack_34[0]);
    LOCK();
    *(undefined4 *)(*piVar1 + 4) = 3;
    UNLOCK();
    FUN_00772ec0(&iStack_2c);
    if (DAT_01eb18d8 != '\0') {
      puVar3 = (undefined4 *)(*piVar1 + 0xc);
      if (0xf < *(uint *)(*piVar1 + 0x20)) {
        puVar3 = (undefined4 *)*puVar3;
      }
      FUN_01677520(DAT_01eb18d8,"Mesh manager: decoded \'%s\'",puVar3);
    }
    FUN_00550b30();
    FUN_0056b650();
    uStack_8 = 5;
  }
  FUN_0152dda0(uVar4,uStack_18,uStack_48);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10838 ; VA 0x0076c8e2 ; Catch@0076c8e2 */

undefined * Catch_0076c8e2(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x68) + 4))();
  FUN_00772fb0("error decoding (Mesh)",*(int *)(*(int *)(unaff_EBP + -0x18) + 0x54) + 0xc,uVar1,
               *(int *)(unaff_EBP + -0x18) + 8);
  return &DAT_0076cad7;
}



/* FUNCTION 10839 ; VA 0x0076c90c ; caseD_d */

void switchD_0076c832::caseD_d(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int unaff_EBP;
  int *unaff_ESI;
  int unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -0x24) = 0;
  *(undefined4 *)(unaff_EBP + -0x20) = 0;
  *(undefined4 *)(unaff_EBP + -0x1c) = 0;
  uVar3 = *(undefined4 *)(unaff_EDI + 0x5c);
  *(undefined *)(unaff_EBP + -4) = 8;
  FUN_00729510(uVar3,3,1);
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_00a204e0(unaff_EBP + -0x11c,unaff_EBP + -0x24,0,0);
  if (*(int *)(unaff_EBP + -0x24) != *(int *)(unaff_EBP + -0x20)) {
    FUN_00728ef0(unaff_EBP + -0x30,*(int *)(unaff_EBP + -0x24));
    iVar1 = *(int *)(unaff_EBP + -0x30);
    *(undefined *)(unaff_EBP + -4) = 10;
    if (iVar1 != 0) {
      puVar2 = (undefined4 *)FUN_00cfa7a0();
      uVar3 = (**(code **)*puVar2)();
      *(undefined4 *)(unaff_EBP + -0x3c) = 0;
      *(undefined4 *)(unaff_EBP + -0x38) = 0;
      FUN_00727ee0(uVar3,*(undefined4 *)(unaff_EBP + -0x34));
      uVar3 = *(undefined4 *)(unaff_EBP + -0x3c);
      *(undefined *)(unaff_EBP + -4) = 0xb;
      FUN_00cf9ed0(iVar1 + 0x5c);
      FUN_00557fc0(unaff_ESI);
      *(undefined4 *)(unaff_EBP + -0x5c) = 0;
      *(undefined4 *)(unaff_EBP + -0x58) = 0;
      *(undefined *)(unaff_EBP + -4) = 0xc;
      FUN_00771120(unaff_EBP + -100,uVar3);
      LOCK();
      *(undefined4 *)(*unaff_ESI + 4) = 3;
      UNLOCK();
      FUN_00772ec0(unaff_EBP + -100);
      if (DAT_01eb18d8 != '\0') {
        puVar2 = (undefined4 *)(*unaff_ESI + 0xc);
        if (0xf < *(uint *)(*unaff_ESI + 0x20)) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_01677520(DAT_01eb18d8,"Mesh manager: decoded (CSG Asset) \'%s\'",puVar2);
      }
      FUN_0056b650();
      FUN_00550b30();
      FUN_00550b30();
      FUN_005705c0();
      thunk_FUN_00577ac0();
      *(undefined4 *)(unaff_EBP + -4) = 0xd;
      goto LAB_0076ca94;
    }
    FUN_00550b30();
  }
  FUN_005705c0();
  thunk_FUN_00577ac0();
  LOCK();
  *(undefined4 *)(*(int *)(unaff_EDI + 0x54) + 4) = 5;
  UNLOCK();
  *(undefined4 *)(unaff_EBP + -4) = 0xf;
LAB_0076ca94:
  FUN_0152dda0();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 10840 ; VA 0x0076caad ; Catch@0076caad */

undefined * Catch_0076caad(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x6c) + 4))();
  FUN_00772fb0("error decoding (CSG Asset)",*(int *)(*(int *)(unaff_EBP + -0x18) + 0x54) + 0xc,uVar1
               ,*(int *)(unaff_EBP + -0x18) + 8);
  return &DAT_0076cad7;
}



/* FUNCTION 10841 ; VA 0x0076cb50 ; FUN_0076cb50 */

void __fastcall FUN_0076cb50(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  undefined4 uStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aebd4;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa4;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puVar4 = &stack0xffffffa4;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1a48) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb1a48);
    puVar4 = puStack_14;
    if (DAT_01eb1a48 == -1) {
      uStack_8 = 0;
      uVar7 = FUN_0152dab0("Systems","Async_Mesh",0xffffffff);
      DAT_01eb1a44 = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eb1a40 = (undefined4)uVar7;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb1a48);
      puVar4 = puStack_14;
    }
  }
  puStack_14 = puVar4;
  uStack_30 = DAT_01eb1a40;
  uStack_18 = DAT_01eb1a44;
  uStack_2c = DAT_01eb1a44;
  uStack_40 = DAT_01eb1a40;
  uStack_3c = DAT_01eb1a44;
  uStack_38 = FUN_0152d930(DAT_01eb1a40,DAT_01eb1a44);
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  puVar5 = (undefined4 *)FUN_00cfa7a0();
  uVar6 = (**(code **)*puVar5)();
  iStack_28 = 0;
  piStack_24 = (int *)0x0;
  FUN_00727ee0(uVar6,iStack_1c);
  iVar2 = iStack_28;
  uStack_8._0_1_ = 3;
  FUN_00cf9ed0(param_1 + 0x10);
  piVar3 = piStack_24;
  if (*(int *)(iVar2 + 0x10) == *(int *)(iVar2 + 0x14)) {
    LOCK();
    *(undefined4 *)(*(int *)(param_1 + 8) + 4) = 5;
    UNLOCK();
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uStack_8 = 4;
    FUN_0076cd5d(uStack_18,uStack_38);
    return;
  }
  iStack_4c = *(int *)(param_1 + 0xc);
  if (iStack_4c != 0) {
    LOCK();
    *(int *)(iStack_4c + 4) = *(int *)(iStack_4c + 4) + 1;
    UNLOCK();
    iStack_4c = *(int *)(param_1 + 0xc);
  }
  uStack_50 = *(undefined4 *)(param_1 + 8);
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00771120(&uStack_50,iVar2);
  LOCK();
  *(undefined4 *)(*(int *)(param_1 + 8) + 4) = 3;
  UNLOCK();
  FUN_00772ec0(&uStack_50);
  if (DAT_01eb18d8 != '\0') {
    puVar5 = (undefined4 *)(*(int *)(param_1 + 8) + 0xc);
    if (0xf < *(uint *)(*(int *)(param_1 + 8) + 0x20)) {
      puVar5 = (undefined4 *)*puVar5;
    }
    FUN_01677520(DAT_01eb18d8,"Mesh manager: decoded (Studio CSG) \'%s\'",puVar5);
  }
  FUN_0056b650();
  piVar3 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = 6;
  FUN_0076cd5d(uStack_18,uStack_38);
  return;
}



/* FUNCTION 10842 ; VA 0x0076cd10 ; Catch@0076cd10 */

undefined * Catch_0076cd10(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_00772fb0("error decoding (Studio CSG)",*(int *)(*(int *)(unaff_EBP + -0x18) + 8) + 0xc,uVar1,
               *(int *)(unaff_EBP + -0x18) + 0x28);
  return &DAT_0076cd3a;
}



/* FUNCTION 10843 ; VA 0x0076cd5d ; FUN_0076cd5d */

void FUN_0076cd5d(void)

{
  int unaff_EBP;
  
  FUN_0152dda0();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 10844 ; VA 0x0076cdd0 ; FUN_0076cdd0 */

uint FUN_0076cdd0(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  
  piVar1 = param_1;
  uVar3 = *param_1 + 0x9e3779b9;
  iVar2 = FUN_005702d0(param_1 + 1);
  uVar3 = uVar3 * 0x40 + (uVar3 >> 2) + iVar2 + -0x61c88647 ^ uVar3;
  uVar3 = piVar1[7] + -0x61c88647 + uVar3 * 0x40 + (uVar3 >> 2) ^ uVar3;
  iVar2 = FUN_005702d0(piVar1 + 8);
  param_1 = (int *)(iVar2 + uVar3 * 0x40 + (uVar3 >> 2) + 0x9e3779b9 ^ uVar3);
  FUN_00769fa0(&param_1,piVar1 + 0xe,piVar1 + 0x12);
  uVar3 = *(byte *)(piVar1 + 0x12) + 0x9e3779b9 + (int)param_1 * 0x40 + ((uint)param_1 >> 2) ^
          (uint)param_1;
  uVar3 = (uVar3 >> 2) + *(byte *)((int)piVar1 + 0x49) + 0x9e3779b9 + uVar3 * 0x40 ^ uVar3;
  param_1 = (int *)((uVar3 >> 2) + (uint)*(byte *)((int)piVar1 + 0x4a) + uVar3 * 0x40 + -0x61c88647
                   ^ uVar3);
  FUN_00769fa0(&param_1,piVar1 + 0x13,piVar1 + 0x17);
  uVar3 = *(byte *)(piVar1 + 0x17) + 0x9e3779b9 + (int)param_1 * 0x40 + ((uint)param_1 >> 2) ^
          (uint)param_1;
  uVar3 = (uVar3 >> 2) + *(byte *)((int)piVar1 + 0x5d) + 0x9e3779b9 + uVar3 * 0x40 ^ uVar3;
  uVar3 = (uVar3 >> 2) + *(byte *)((int)piVar1 + 0x5e) + 0x9e3779b9 + uVar3 * 0x40 ^ uVar3;
  uVar3 = (uVar3 >> 2) + *(byte *)((int)piVar1 + 0x5f) + 0x9e3779b9 + uVar3 * 0x40 ^ uVar3;
  uVar3 = (uVar3 >> 2) + *(byte *)(piVar1 + 0x18) + 0x9e3779b9 + uVar3 * 0x40 ^ uVar3;
  return (uVar3 >> 2) + 0x9e3779b9 + (uint)*(byte *)((int)piVar1 + 0x61) + uVar3 * 0x40 ^ uVar3;
}



/* FUNCTION 10845 ; VA 0x0076cf60 ; FUN_0076cf60 */

undefined4 __thiscall FUN_0076cf60(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  return param_1;
}



/* FUNCTION 10846 ; VA 0x0076cf80 ; FUN_0076cf80 */

undefined4 __thiscall FUN_0076cf80(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x194);
  }
  return param_1;
}



/* FUNCTION 10847 ; VA 0x0076cfb0 ; FUN_0076cfb0 */

undefined4 __thiscall FUN_0076cfb0(undefined4 param_1,byte param_2)

{
  FUN_0076ae70();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 10848 ; VA 0x0076cfe0 ; FUN_0076cfe0 */

undefined4 * __thiscall FUN_0076cfe0(undefined4 *param_1,byte param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::MeshResource::vftable;
  FUN_016790b0();
  FUN_016f32d1(param_1 + 0x39,0x18,5,FUN_00550b30);
  FUN_016f32d1(param_1 + 0x1b,0x18,5,FUN_00550b30);
  FUN_0076b160();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x188);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10849 ; VA 0x0076d070 ; FUN_0076d070 */

void __fastcall FUN_0076d070(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_0076ae70();
    FUN_01674ea0(iVar1,0x18);
  }
  return;
}



/* FUNCTION 10850 ; VA 0x0076d090 ; FUN_0076d090 */

void FUN_0076d090(void)

{
  FUN_0076b080();
  return;
}



/* FUNCTION 10851 ; VA 0x0076d0a0 ; FUN_0076d0a0 */

void __fastcall FUN_0076d0a0(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iStack_8;
  
  iStack_8 = param_1;
  if (*(int *)(param_1 + 0xc) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puVar3 = *(undefined4 **)(*(int *)(param_1 + 0x18) + *(int *)(param_1 + 8) * 4);
  }
  while (puVar3 != (undefined4 *)0x0) {
    if ((*(int *)(puVar3[0x1b] + 4) == 1) && (iVar1 = puVar3[0x1b], *(int *)(iVar1 + 0x1c) != 0)) {
      if (DAT_01eb18d8 != '\0') {
        puVar2 = (undefined4 *)(iVar1 + 0xc);
        if (0xf < *(uint *)(iVar1 + 0x20)) {
          puVar2 = (undefined4 *)*puVar2;
        }
        FUN_01677520(DAT_01eb18d8,"Mesh manager: \'%s\' (%d) is still pending, canceled",puVar2,
                     *(undefined4 *)(iVar1 + 8));
      }
      puVar3 = (undefined4 *)FUN_0076da20(&iStack_8,puVar3);
      puVar3 = (undefined4 *)*puVar3;
    }
    else {
      puVar3 = (undefined4 *)*puVar3;
    }
  }
  return;
}



/* FUNCTION 10852 ; VA 0x0076d120 ; FUN_0076d120 */

void __fastcall FUN_0076d120(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  
  if (*(int *)(param_1 + 4) != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      piVar2 = *(int **)(*(int *)(param_1 + 4) + 0x70);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      FUN_0076b160();
      *(undefined *)(param_1 + 9) = 0;
    }
    return;
  }
  *(undefined2 *)(param_1 + 8) = 0;
  puVar4 = (undefined4 *)FUN_01674e20(0x74);
  *(undefined4 **)(param_1 + 4) = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  FUN_0170d1f0(puVar4 + 2,0,0x6c);
  *(undefined *)(param_1 + 8) = 1;
  return;
}



/* FUNCTION 10853 ; VA 0x0076d1b0 ; FUN_0076d1b0 */

void FUN_0076d1b0(int param_1,int param_2,int param_3,undefined param_4)

{
  undefined2 *puVar1;
  undefined4 *puVar2;
  
  if (param_3 != 0) {
    puVar1 = (undefined2 *)(param_1 + 0xd);
    puVar2 = (undefined4 *)(param_2 + 0x18);
    do {
      *(undefined8 *)((int)puVar1 + -0xd) = *(undefined8 *)(puVar2 + -6);
      *(undefined4 *)((int)puVar1 + -5) = puVar2[-4];
      *(undefined *)((int)puVar1 + -1) = param_4;
      *puVar1 = 0;
      *(undefined *)(puVar1 + 1) = *(undefined *)((int)puVar2 + 0xf);
      *(undefined4 *)((int)puVar1 + 3) = *puVar2;
      *(undefined4 *)((int)puVar1 + 7) = puVar2[1];
      param_3 = param_3 + -1;
      puVar1 = puVar1 + 0xc;
      puVar2 = puVar2 + 10;
    } while (param_3 != 0);
  }
  return;
}



/* FUNCTION 10854 ; VA 0x0076d210 ; FUN_0076d210 */

void FUN_0076d210(int param_1,int param_2,int param_3,undefined param_4)

{
  undefined2 *puVar1;
  undefined4 *puVar2;
  
  if (param_3 != 0) {
    puVar1 = (undefined2 *)(param_1 + 0xd);
    puVar2 = (undefined4 *)(param_2 + 0x20);
    do {
      *(undefined8 *)((int)puVar1 + -0xd) = *(undefined8 *)(puVar2 + -8);
      *(undefined4 *)((int)puVar1 + -5) = puVar2[-6];
      *(undefined *)((int)puVar1 + -1) = param_4;
      *puVar1 = 0;
      *(undefined *)(puVar1 + 1) = *(undefined *)((int)puVar2 + -5);
      *(undefined4 *)((int)puVar1 + 3) = *puVar2;
      *(undefined4 *)((int)puVar1 + 7) = puVar2[1];
      param_3 = param_3 + -1;
      puVar1 = puVar1 + 0xc;
      puVar2 = puVar2 + 0x15;
    } while (param_3 != 0);
  }
  return;
}



/* FUNCTION 10855 ; VA 0x0076d270 ; FUN_0076d270 */

void FUN_0076d270(int param_1,int param_2,int param_3,undefined param_4,float *param_5)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  undefined *puVar6;
  float *pfVar7;
  float fVar8;
  
  fVar5 = DAT_018fb56c;
  fVar4 = DAT_018ce2f8;
  fVar3 = DAT_018ce2f4;
  fVar2 = *param_5;
  pfVar7 = param_5 + 1;
  pfVar1 = param_5 + 2;
  param_5 = (float *)CONCAT13(0x7f,CONCAT12((char)(int)(*pfVar1 * DAT_018f8ff8 + DAT_018f8ff8),
                                            CONCAT11((char)(int)(*pfVar7 * DAT_018f8ff8 +
                                                                DAT_018f8ff8),
                                                     (char)(int)(fVar2 * DAT_018f8ff8 + DAT_018f8ff8
                                                                ))));
  if (param_3 != 0) {
    puVar6 = (undefined *)(param_1 + 0xd);
    pfVar7 = (float *)(param_2 + 0x10);
    do {
      *(undefined8 *)(puVar6 + -0xd) = *(undefined8 *)(pfVar7 + -4);
      *(float *)(puVar6 + -5) = pfVar7[-2];
      fVar8 = pfVar7[-1] * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      puVar6[-1] = (char)(int)(fVar8 * fVar5 + fVar3);
      fVar8 = *pfVar7 * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      *puVar6 = (char)(int)(fVar8 * fVar5 + fVar3);
      fVar2 = pfVar7[1];
      puVar6[2] = param_4;
      *(float **)(puVar6 + 0xb) = param_5;
      fVar8 = fVar2 * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      puVar6[1] = (char)(int)(fVar8 * fVar5 + fVar3);
      *(float *)(puVar6 + 3) = pfVar7[2];
      *(float *)(puVar6 + 7) = pfVar7[3];
      pfVar1 = pfVar7 + 5;
      pfVar7 = pfVar7 + 10;
      *(float *)(puVar6 + 0xf) = *pfVar1;
      puVar6 = puVar6 + 0x20;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  return;
}



/* FUNCTION 10856 ; VA 0x0076d3c0 ; FUN_0076d3c0 */

void FUN_0076d3c0(int param_1,int param_2,int param_3,undefined param_4)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  undefined *puVar6;
  float *pfVar7;
  float fVar8;
  
  fVar5 = DAT_018fb56c;
  fVar4 = DAT_018ce2f8;
  fVar3 = DAT_018ce2f4;
  if (param_3 != 0) {
    puVar6 = (undefined *)(param_1 + 0xd);
    pfVar7 = (float *)(param_2 + 0x10);
    do {
      *(undefined8 *)(puVar6 + -0xd) = *(undefined8 *)(pfVar7 + -4);
      *(float *)(puVar6 + -5) = pfVar7[-2];
      fVar8 = pfVar7[-1] * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      puVar6[-1] = (char)(int)(fVar8 * fVar5 + fVar3);
      fVar8 = *pfVar7 * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      *puVar6 = (char)(int)(fVar8 * fVar5 + fVar3);
      fVar2 = pfVar7[1];
      puVar6[2] = param_4;
      fVar8 = fVar2 * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      puVar6[1] = (char)(int)(fVar8 * fVar5 + fVar3);
      *(float *)(puVar6 + 3) = pfVar7[4];
      *(float *)(puVar6 + 7) = pfVar7[5];
      fVar8 = pfVar7[10] * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      puVar6[0xb] = (char)(int)(fVar8 * fVar5 + fVar3);
      fVar8 = pfVar7[0xb] * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      puVar6[0xc] = (char)(int)(fVar8 * fVar5 + fVar3);
      fVar2 = pfVar7[0xc];
      puVar6[0xe] = 0x7f;
      fVar8 = fVar2 * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      puVar6[0xd] = (char)(int)(fVar8 * fVar5 + fVar3);
      pfVar1 = pfVar7 + 2;
      pfVar7 = pfVar7 + 0x15;
      *(float *)(puVar6 + 0xf) = *pfVar1;
      puVar6 = puVar6 + 0x20;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  return;
}



/* FUNCTION 10857 ; VA 0x0076d540 ; FUN_0076d540 */

void FUN_0076d540(int param_1,int param_2,int param_3,undefined param_4)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  undefined *puVar6;
  float *pfVar7;
  float fVar8;
  
  fVar5 = DAT_018fb56c;
  fVar4 = DAT_018ce2f8;
  fVar3 = DAT_018ce2f4;
  if (param_3 != 0) {
    puVar6 = (undefined *)(param_1 + 0xd);
    pfVar7 = (float *)(param_2 + 0x10);
    do {
      *(undefined8 *)(puVar6 + -0xd) = *(undefined8 *)(pfVar7 + -4);
      *(float *)(puVar6 + -5) = pfVar7[-2];
      fVar8 = pfVar7[-1] * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      puVar6[-1] = (char)(int)(fVar8 * fVar5 + fVar3);
      fVar8 = *pfVar7 * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      *puVar6 = (char)(int)(fVar8 * fVar5 + fVar3);
      fVar2 = pfVar7[1];
      puVar6[2] = param_4;
      fVar8 = fVar2 * fVar3 + fVar3;
      fVar2 = 0.0;
      if (0.0 <= fVar8) {
        fVar2 = fVar8;
      }
      fVar8 = fVar4;
      if (fVar2 <= fVar4) {
        fVar8 = fVar2;
      }
      puVar6[1] = (char)(int)(fVar8 * fVar5 + fVar3);
      *(float *)(puVar6 + 3) = pfVar7[2];
      *(float *)(puVar6 + 7) = pfVar7[3];
      *(float *)(puVar6 + 0xf) = pfVar7[5];
      pfVar1 = pfVar7 + 4;
      pfVar7 = pfVar7 + 10;
      *(float *)(puVar6 + 0xb) = *pfVar1;
      puVar6 = puVar6 + 0x20;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  return;
}



/* FUNCTION 10858 ; VA 0x0076d640 ; FUN_0076d640 */

int __thiscall FUN_0076d640(int param_1,undefined4 *param_2)

{
  byte *pbVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  
  puVar11 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar11 = (undefined4 *)*param_2;
  }
  uVar9 = 0;
  uVar10 = 0x811c9dc5;
  if (param_2[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar9 + (int)puVar11);
      uVar9 = uVar9 + 1;
      uVar10 = (*pbVar1 ^ uVar10) * 0x1000193;
    } while (uVar9 < (uint)param_2[4]);
  }
  uVar10 = *(uint *)(param_1 + 0x18) & uVar10;
  puVar11 = *(undefined4 **)(param_1 + 4);
  puVar2 = *(undefined4 **)(*(int *)(param_1 + 0xc) + uVar10 * 8);
  puVar4 = (undefined4 *)(uVar10 * 8 + 4 + *(int *)(param_1 + 0xc));
  puVar12 = puVar2;
  while( true ) {
    puVar5 = puVar11;
    if (puVar2 != puVar11) {
      puVar5 = *(undefined4 **)*puVar4;
    }
    if (puVar12 == puVar5) goto LAB_0076d732;
    piVar7 = puVar12 + 2;
    puVar5 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar5 = (undefined4 *)*param_2;
    }
    if (0xf < (uint)puVar12[7]) {
      piVar7 = (int *)*piVar7;
    }
    cVar3 = FUN_0055c360(piVar7,puVar12[6],puVar5,param_2[4]);
    puVar5 = puVar12;
    if (cVar3 != '\0') break;
    puVar12 = (undefined4 *)*puVar12;
  }
  while( true ) {
    puVar6 = puVar11;
    if (puVar2 != puVar11) {
      puVar6 = *(undefined4 **)*puVar4;
    }
    if (puVar5 == puVar6) break;
    piVar7 = puVar5 + 2;
    if (0xf < (uint)puVar5[7]) {
      piVar7 = (int *)*piVar7;
    }
    puVar6 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar6 = (undefined4 *)*param_2;
    }
    cVar3 = FUN_0055c360(puVar6,param_2[4],piVar7,puVar5[6]);
    if (cVar3 == '\0') break;
    puVar5 = (undefined4 *)*puVar5;
  }
  if (puVar12 == puVar5) {
LAB_0076d732:
    puVar5 = puVar11;
    puVar12 = puVar11;
  }
  iVar8 = 0;
  for (; puVar12 != puVar5; puVar12 = (undefined4 *)*puVar12) {
    iVar8 = iVar8 + 1;
  }
  return iVar8;
}



/* FUNCTION 10859 ; VA 0x0076d750 ; FUN_0076d750 */

void FUN_0076d750(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 *puVar9;
  int iVar10;
  int *piStack_40;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aebf0;
  pvStack_10 = ExceptionList;
  uVar8 = param_3 - 1;
  if (5 < uVar8) {
    uVar8 = 5;
  }
  ExceptionList = &pvStack_10;
  *(uint *)(*param_1 + 0x15c) = uVar8;
  *(uint *)(*param_1 + 0x160) = uVar8;
  iVar6 = *param_1;
  uStack_14 = 0;
  if (*(int *)(iVar6 + 0x15c) != 0) {
    param_3 = 0;
    while( true ) {
      iVar2 = *(int *)(param_2 + uStack_14 * 4);
      iVar10 = *(int *)(param_2 + 4 + uStack_14 * 4) - iVar2;
      if ((DAT_01d71770 != '\0') && (iVar10 == 0)) break;
      iStack_1c = iVar2;
      if (DAT_01eb18d8 != '\0') {
        FUN_01677520(DAT_01eb18d8,"Mesh manager: creating batch \'%d\' \'%d\'",iVar2,iVar10);
      }
      uStack_24 = 0;
      piStack_20 = (int *)0x0;
      uStack_8 = 0;
      puVar7 = (undefined4 *)FUN_0147c720(&uStack_24,0,iVar2,0,iVar10);
      uVar3 = *puVar7;
      uVar4 = puVar7[1];
      puStack_18 = (undefined4 *)(*param_1 + 0x6c + param_3);
      *puVar7 = 0;
      puVar7[1] = 0;
      *puStack_18 = uVar3;
      piVar5 = (int *)puStack_18[1];
      puStack_18[1] = uVar4;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar6 = piVar5[1] + -1;
        piVar5[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar6 = piVar5[2] + -1;
          piVar5[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      puStack_18[2] = puVar7[2];
      puStack_18[3] = puVar7[3];
      puStack_18[4] = puVar7[4];
      puStack_18[5] = puVar7[5];
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_40[1] + -1;
        piStack_40[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_40)();
          LOCK();
          iVar6 = piStack_40[2] + -1;
          piStack_40[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_40 + 4))();
          }
        }
      }
      piVar5 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_20[1] + -1;
        piStack_20[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      uStack_2c = 0;
      piStack_28 = (int *)0x0;
      uStack_8 = 1;
      puVar7 = (undefined4 *)FUN_0147c720(&uStack_2c,0,iStack_1c,0,iVar10);
      uVar3 = *puVar7;
      puVar9 = (undefined4 *)(param_3 + 0xe4 + *param_1);
      uVar4 = puVar7[1];
      *puVar7 = 0;
      puVar7[1] = 0;
      *puVar9 = uVar3;
      piVar5 = (int *)puVar9[1];
      puVar9[1] = uVar4;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar6 = piVar5[1] + -1;
        piVar5[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar6 = piVar5[2] + -1;
          piVar5[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      puVar9[2] = puVar7[2];
      puVar9[3] = puVar7[3];
      puVar9[4] = puVar7[4];
      puVar9[5] = puVar7[5];
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_40[1] + -1;
        piStack_40[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_40)();
          LOCK();
          iVar6 = piStack_40[2] + -1;
          piStack_40[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_40 + 4))();
          }
        }
      }
      piVar5 = piStack_28;
      uStack_8 = 0xffffffff;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_28[1] + -1;
        piStack_28[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      uStack_14 = uStack_14 + 1;
      param_3 = param_3 + 0x18;
      iVar6 = *param_1;
      if (*(uint *)(iVar6 + 0x15c) <= uStack_14) {
        ExceptionList = pvStack_10;
        return;
      }
    }
    *(uint *)(iVar6 + 0x15c) = uStack_14;
    *(uint *)(*param_1 + 0x160) = uStack_14;
    if (DAT_01d71798 != '\0') {
      uVar8 = *(uint *)(*param_1 + 0x164);
      if (uStack_14 <= uVar8) {
        uVar8 = uStack_14;
      }
      *(uint *)(*param_1 + 0x164) = uVar8;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10860 ; VA 0x0076da20 ; FUN_0076da20 */

int * __thiscall FUN_0076da20(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uStack_8;
  
  piVar1 = (int *)*param_3;
  *param_2 = (int)piVar1;
  uStack_8 = (uint)param_3[1] % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uStack_8 * 4);
  for (piVar6 = (int *)*piVar2; piVar6 != param_3; piVar6 = (int *)*piVar6) {
    piVar2 = piVar6;
  }
  do {
    *piVar2 = *piVar6;
    piVar3 = (int *)piVar6[0x1c];
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_0076b160();
    FUN_01674ea0(piVar6,0x74);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    uVar5 = uStack_8;
    if (*piVar2 == 0) {
LAB_0076dac2:
      if (*(int **)(*(int *)(param_1 + 0x14) + uStack_8 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + uStack_8 * 4) = 0;
      }
    }
    else {
      uVar5 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4);
      if (uStack_8 != uVar5) {
        *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4) = piVar2;
        goto LAB_0076dac2;
      }
    }
    piVar6 = (int *)*piVar2;
    uStack_8 = uVar5;
    if (piVar6 == piVar1) {
      return param_2;
    }
  } while( true );
}



/* FUNCTION 10861 ; VA 0x0076daf0 ; FUN_0076daf0 */

void __thiscall FUN_0076daf0(int *param_1,undefined4 *param_2)

{
  undefined8 uVar1;
  int iVar2;
  int iVar3;
  bool bVar4;
  bool bVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  uint uVar9;
  int *piVar10;
  int iVar11;
  uint uVar12;
  int *piVar13;
  int iVar14;
  int iStack_100;
  undefined uStack_fc;
  undefined4 uStack_e8;
  undefined uStack_e0;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  int aiStack_9c [7];
  undefined4 uStack_80;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined2 uStack_3c;
  undefined auStack_38 [4];
  int iStack_34;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  int iStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aec13;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  if ((uint)param_1[9] < (uint)param_1[10]) {
    piStack_2c = param_1 + 1;
    iVar14 = (int)param_1 + *(byte *)(param_1 + 1) + 5;
    ExceptionList = &pvStack_10;
    piStack_14 = param_1;
    uVar7 = FUN_0076cdd0(param_1 + 0xc);
    FUN_00769e50(&puStack_1c,uVar7,param_1 + 0xc,-(uint)(iVar14 != 0) & iVar14 + 1U);
    puVar8 = puStack_1c;
    if (puStack_1c == (undefined4 *)0x0) {
      if (param_1[3] == 0) {
        puVar8 = (undefined4 *)0x0;
      }
      else {
        puVar8 = *(undefined4 **)(param_1[6] + param_1[2] * 4);
      }
    }
    iStack_24 = 0;
    uStack_20 = 0;
    puStack_1c = (undefined4 *)0x0;
    if (param_2 != (undefined4 *)0x0) {
      do {
        param_1 = piStack_14;
        if (puVar8 == (undefined4 *)0x0) goto LAB_0076dd37;
        piVar13 = (int *)puVar8[0x1c];
        if ((piVar13 == (int *)0x0) || (piVar13[1] != 1)) {
          puVar8 = (undefined4 *)*puVar8;
        }
        else {
          if (piVar13 != (int *)0x0) {
            LOCK();
            piVar13[1] = piVar13[1] + 1;
            UNLOCK();
            piVar13 = (int *)puVar8[0x1c];
          }
          iStack_34 = puVar8[0x1b];
          uStack_8 = 0;
          piStack_30 = piVar13;
          iStack_28 = iStack_34;
          puVar8 = (undefined4 *)FUN_0076da20(auStack_38,puVar8);
          iStack_24 = iStack_24 + 1;
          puVar8 = (undefined4 *)*puVar8;
          uVar9 = piStack_14[10] - *(int *)(iStack_28 + 0x180);
          piStack_14[10] = uVar9;
          uStack_20 = uStack_20 + *(int *)(iStack_28 + 0x180);
          if (DAT_01eb18d8 != '\0') {
            piStack_18 = (int *)(uVar9 >> 10);
            piVar10 = (int *)(iStack_28 + 0xc);
            if (0xf < *(uint *)(iStack_28 + 0x20)) {
              piVar10 = (int *)*piVar10;
            }
            FUN_01677520(DAT_01eb18d8,"Mesh manager: gc unloaded (%d) \'%s\' (mem %u / %u kb)",
                         *(undefined4 *)(iStack_28 + 8),piVar10,piStack_18,(uint)piStack_14[9] >> 10
                        );
          }
          if (*(int *)(iStack_28 + 8) == 0x13) {
            piVar10 = (int *)(*(int *)(*piStack_14 + 0x524) + 0x90);
            *piVar10 = *piVar10 + -1;
            *(int *)(*(int *)(*piStack_14 + 0x524) + 0x94) =
                 *(int *)(*(int *)(*piStack_14 + 0x524) + 0x94) - *(int *)(iStack_28 + 0x180);
          }
          iStack_34 = 0;
          piStack_30 = (int *)0x0;
          if (piVar13 != (int *)0x0) {
            LOCK();
            iVar14 = piVar13[1] + -1;
            piVar13[1] = iVar14;
            UNLOCK();
            if (iVar14 == 0) {
              (**(code **)*piVar13)();
              LOCK();
              iVar14 = piVar13[2] + -1;
              piVar13[2] = iVar14;
              UNLOCK();
              if (iVar14 == 0) {
                (**(code **)(*piVar13 + 4))();
              }
            }
          }
          uStack_8 = 0xffffffff;
        }
        puStack_1c = (undefined4 *)((int)puStack_1c + 1);
        param_1 = piStack_14;
      } while (puStack_1c != param_2);
    }
    if (puVar8 == (undefined4 *)0x0) {
LAB_0076dd37:
      FUN_0170d1f0(&iStack_100,0,100);
      uStack_e8 = 0xf;
      uStack_fc = 0;
      piVar13 = &iStack_100;
      uStack_d0 = 0;
      bVar5 = false;
      bVar4 = true;
      uStack_cc = 0xf;
      uStack_e0 = 0;
    }
    else {
      aiStack_9c[0] = puVar8[2];
      FUN_0054ef60(puVar8 + 3);
      uStack_80 = puVar8[9];
      uStack_8 = 1;
      FUN_0054ef60(puVar8 + 10);
      piVar13 = aiStack_9c;
      uStack_54 = puVar8[0x14];
      uStack_64 = puVar8[0x10];
      uStack_60 = puVar8[0x11];
      uStack_5c = puVar8[0x12];
      uStack_58 = puVar8[0x13];
      uStack_40 = puVar8[0x19];
      uStack_3c = *(undefined2 *)(puVar8 + 0x1a);
      bVar5 = true;
      bVar4 = false;
      uStack_50 = puVar8[0x15];
      uStack_4c = puVar8[0x16];
      uStack_48 = puVar8[0x17];
      uStack_44 = puVar8[0x18];
      uStack_8 = 0xffffffff;
    }
    piVar10 = param_1 + 0xd;
    param_1[0xc] = *piVar13;
    piStack_18 = piVar13 + 1;
    piStack_14 = piVar13;
    if (piVar10 != piStack_18) {
      uVar9 = param_1[0x12];
      if (0xf < uVar9) {
        iVar14 = *piVar10;
        uVar12 = uVar9 + 1;
        iVar11 = iVar14;
        if (0xfff < uVar12) {
          iVar11 = *(int *)(iVar14 + -4);
          uVar12 = uVar9 + 0x24;
          if (0x1f < (iVar14 - iVar11) - 4U) goto LAB_0076df1b;
        }
        FUN_01674ea0(iVar11,uVar12);
      }
      piVar13 = piStack_14;
      iVar14 = *piStack_18;
      iVar11 = piStack_18[1];
      iVar2 = piStack_18[2];
      iVar3 = piStack_18[3];
      param_1[0x11] = 0;
      param_1[0x12] = 0xf;
      *piVar10 = iVar14;
      param_1[0xe] = iVar11;
      param_1[0xf] = iVar2;
      param_1[0x10] = iVar3;
      uVar1 = *(undefined8 *)(piStack_18 + 4);
      piStack_18[4] = 0;
      piStack_18[5] = 0xf;
      *(undefined8 *)(param_1 + 0x11) = uVar1;
      *(undefined *)piStack_18 = 0;
    }
    piVar10 = param_1 + 0x14;
    param_1[0x13] = piVar13[7];
    piStack_18 = piVar13 + 8;
    if (piVar10 != piVar13 + 8) {
      uVar9 = param_1[0x19];
      if (0xf < uVar9) {
        iVar14 = *piVar10;
        uVar12 = uVar9 + 1;
        iVar11 = iVar14;
        if (0xfff < uVar12) {
          iVar11 = *(int *)(iVar14 + -4);
          uVar12 = uVar9 + 0x24;
          if (0x1f < (iVar14 - iVar11) - 4U) {
LAB_0076df1b:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar11,uVar12);
        piVar13 = piStack_14;
      }
      piVar6 = piStack_18;
      iVar14 = *piStack_18;
      iVar11 = piStack_18[1];
      iVar2 = piStack_18[2];
      iVar3 = piStack_18[3];
      param_1[0x18] = 0;
      param_1[0x19] = 0xf;
      *piVar10 = iVar14;
      param_1[0x15] = iVar11;
      param_1[0x16] = iVar2;
      param_1[0x17] = iVar3;
      uVar1 = *(undefined8 *)(piStack_18 + 4);
      piStack_18[4] = 0;
      piVar6[5] = 0xf;
      *(undefined8 *)(param_1 + 0x18) = uVar1;
      *(undefined *)piVar6 = 0;
    }
    iVar11 = piVar13[0xf];
    iVar2 = piVar13[0x10];
    iVar3 = piVar13[0x11];
    iVar14 = piVar13[0x12];
    param_1[0x1a] = piVar13[0xe];
    param_1[0x1b] = iVar11;
    param_1[0x1c] = iVar2;
    param_1[0x1d] = iVar3;
    param_1[0x1e] = iVar14;
    iVar11 = piVar13[0x14];
    iVar2 = piVar13[0x15];
    iVar3 = piVar13[0x16];
    iVar14 = piVar13[0x17];
    param_1[0x1f] = piVar13[0x13];
    param_1[0x20] = iVar11;
    param_1[0x21] = iVar2;
    param_1[0x22] = iVar3;
    param_1[0x23] = iVar14;
    *(undefined2 *)(param_1 + 0x24) = *(undefined2 *)(piVar13 + 0x18);
    if (bVar4) {
      FUN_0076b160();
    }
    if (bVar5) {
      FUN_0076b160();
    }
    if (DAT_01eb18d8 != '\0') {
      FUN_01677520(DAT_01eb18d8,"Mesh manager: gc killed %u : %u kb (mem %u / %u kb)",iStack_24,
                   uStack_20 >> 10,(uint)param_1[10] >> 10,(uint)param_1[9] >> 10);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10862 ; VA 0x0076df30 ; FUN_0076df30 */

void FUN_0076df30(undefined4 *param_1)

{
  switch(*param_1) {
  case 0xd:
  case 0xe:
  case 0x12:
    FUN_008ccd80();
    return;
  case 0xf:
  case 0x10:
  case 0x11:
    FUN_008ccd50();
    return;
  default:
    FUN_008ccd70();
    return;
  }
}



/* FUNCTION 10863 ; VA 0x0076dfa0 ; FUN_0076dfa0 */

int * __thiscall FUN_0076dfa0(int *param_1,int *param_2,int *param_3)

{
  undefined4 *puVar1;
  bool bVar2;
  undefined4 uVar3;
  undefined uVar4;
  char cVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  undefined auStack_374 [20];
  undefined auStack_360 [96];
  undefined auStack_300 [20];
  undefined auStack_2ec [96];
  undefined auStack_28c [20];
  undefined auStack_278 [96];
  undefined auStack_218 [20];
  undefined auStack_204 [116];
  undefined *puStack_190;
  undefined auStack_18c [20];
  undefined auStack_178 [4];
  int iStack_174;
  int *piStack_170;
  undefined4 auStack_16c [18];
  undefined4 uStack_124;
  undefined4 *puStack_120;
  undefined4 *puStack_11c;
  undefined auStack_118 [24];
  undefined auStack_100 [24];
  undefined auStack_e8 [24];
  undefined4 uStack_d0;
  int iStack_cc;
  int *piStack_c8;
  undefined4 *puStack_c4;
  undefined4 *puStack_c0;
  int iStack_b8;
  int *piStack_b4;
  undefined4 *puStack_b0;
  undefined4 *puStack_ac;
  undefined auStack_a8 [4];
  int aiStack_a4 [17];
  undefined4 uStack_60;
  int iStack_5c;
  int iStack_58;
  int *piStack_54;
  undefined4 *puStack_50;
  undefined4 uStack_4c;
  undefined **ppuStack_48;
  uint auStack_40 [2];
  int iStack_38;
  int *piStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  int *piStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aee80;
  pvStack_10 = ExceptionList;
  piStack_18 = param_1 + 1;
  uStack_4c = *(undefined4 *)(*(int *)(*param_1 + 0x4e4) + 0x14);
  ExceptionList = &pvStack_10;
  piStack_28 = param_1;
  FUN_0076cdd0();
  FUN_00769e50();
  if (iStack_14 != 0) {
    *param_2 = 0;
    param_2[1] = 0;
    if (*(int *)(iStack_14 + 0x70) != 0) {
      LOCK();
      piVar9 = (int *)(*(int *)(iStack_14 + 0x70) + 4);
      *piVar9 = *piVar9 + 1;
      UNLOCK();
    }
    *param_2 = *(int *)(iStack_14 + 0x6c);
    param_2[1] = *(int *)(iStack_14 + 0x70);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar9 = (int *)param_1[8];
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
    piVar9 = (int *)param_1[8];
  }
  iStack_58 = param_1[7];
  uStack_8 = 0;
  puStack_30 = (undefined4 *)0x0;
  puStack_2c = (undefined4 *)0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  piStack_54 = piVar9;
  iStack_14 = iStack_58;
  FUN_005542c0();
  uStack_8._0_1_ = 1;
  FUN_00d10320();
  uStack_8._0_1_ = 3;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < puStack_2c) {
    if ((0xfff < (int)puStack_2c + 1U) && (0x1f < (auStack_40[0] - *(int *)(auStack_40[0] - 4)) - 4)
       ) {
      uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  puStack_30 = (undefined4 *)0x0;
  puStack_2c = (undefined4 *)0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  puVar6 = (undefined4 *)FUN_01674e20();
  puStack_50 = puVar6;
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6[1] = 1;
    puVar6[2] = 1;
    *puVar6 = std::_Ref_count_obj<struct_RBX::Graphics::MeshResource>::vftable;
    piStack_1c = puVar6 + 3;
    FUN_0170d1f0();
    puVar6[3] = RBX::Graphics::MeshResource::vftable;
    puVar6[10] = 0;
    puVar6[0xb] = 0xf;
    *(undefined *)(puVar6 + 6) = 0;
    puVar6[0x11] = 0;
    puVar6[0x12] = 0xf;
    *(undefined *)(puVar6 + 0xd) = 0;
    uStack_8._0_1_ = 5;
    FUN_016f4053();
    uStack_8._0_1_ = 6;
    FUN_016f4053();
    puVar6[0x5a] = 1;
    puVar6[0x5b] = 1;
    puVar6[0x5c] = 1;
    puVar6[0x5d] = 0;
    puVar6[0x5e] = 0;
    puVar6[0x5f] = 0;
    puVar6[0x60] = 0;
    puVar6[0x61] = 0;
    puVar6[0x62] = 0;
    puVar6[100] = 0;
  }
  puVar1 = puVar6 + 3;
  uStack_8._0_1_ = 7;
  puStack_24 = puVar1;
  puStack_20 = puVar6;
  iVar7 = FUN_0076b4b0();
  if (puVar6 != (undefined4 *)0x0) {
    LOCK();
    puVar6[1] = puVar6[1] + 1;
    UNLOCK();
  }
  *(undefined4 **)(iVar7 + 100) = puVar1;
  piStack_18 = *(int **)(iVar7 + 0x68);
  *(undefined4 **)(iVar7 + 0x68) = puVar6;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_18[1] + -1;
    piStack_18[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar7 = piStack_18[2] + -1;
      piStack_18[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = puVar6 + 4;
  LOCK();
  *piStack_18 = 0;
  UNLOCK();
  puStack_50 = puVar6 + 5;
  FUN_0076b3e0();
  iVar7 = *param_3;
  if (iVar7 - 2U < 7) {
    LOCK();
    puVar6[4] = 2;
    UNLOCK();
    if (piVar9 != (int *)0x0) {
      LOCK();
      piVar9[1] = piVar9[1] + 1;
      UNLOCK();
    }
    iStack_38 = iStack_14;
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    if (piVar9 != (int *)0x0) {
      LOCK();
      piVar9[1] = piVar9[1] + 1;
      UNLOCK();
    }
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    piStack_34 = piVar9;
    puStack_30 = puVar1;
    puStack_2c = puVar6;
    FUN_00769bc0(iStack_14,piVar9,puVar1,puVar6,0);
    FUN_0056b650();
    FUN_0151ddd0();
    puStack_24 = (undefined4 *)0x0;
    puStack_20 = (undefined4 *)0x0;
    *param_2 = (int)(puVar6 + 3);
    param_2[1] = (int)puVar6;
    FUN_00550b30();
    FUN_00637950();
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_2;
  }
  if ((iVar7 - 0xfU < 2) && (param_3[5] == 0)) {
    FUN_0076b370();
    FUN_0076b370();
    uVar3 = DAT_018ce2f8;
    puStack_190 = &DAT_bf800000;
    *(ulonglong *)(puVar6 + 0x5d) = CONCAT44(DAT_018f7864,DAT_018f7864);
    puVar6[0x5f] = &DAT_bf800000;
    puStack_2c = (undefined4 *)0x3f800000;
    *(ulonglong *)(puVar6 + 0x60) = CONCAT44(uVar3,uVar3);
    puVar6[0x62] = 0x3f800000;
    puVar6[99] = 1;
    LOCK();
    puVar6[4] = 4;
    UNLOCK();
    FUN_00557f90();
    FUN_00550b30();
    FUN_00637950();
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_2;
  }
  if (((iVar7 != 10) && (iVar7 != 0xb)) && (iVar7 != 0xc)) {
    if (iVar7 == 0x13) {
      LOCK();
      *piStack_18 = 2;
      UNLOCK();
      FUN_00b63e30();
      piVar8 = (int *)FUN_00b4dfd0();
      if (DAT_01eafe10 != '\0') {
        FUN_00a33fa0();
        FUN_01677520();
      }
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
      }
      iStack_b8 = iStack_14;
      if (puVar6 != (undefined4 *)0x0) {
        LOCK();
        puVar6[1] = puVar6[1] + 1;
        UNLOCK();
      }
      puStack_b0 = puVar6 + 3;
      piStack_1c = (int *)auStack_a8;
      uStack_8._0_1_ = 0x24;
      piStack_b4 = piVar9;
      puStack_ac = puVar6;
      FUN_0054ef60(auStack_118);
      uStack_8._0_1_ = 0x25;
      FUN_0054ef60(auStack_100);
      uStack_8._0_1_ = 0x26;
      FUN_0054ef60(auStack_e8);
      uStack_60 = uStack_d0;
      iStack_5c = *piVar8;
      LOCK();
      *(int *)(iStack_5c + 0x28) = *(int *)(iStack_5c + 0x28) + 1;
      UNLOCK();
      uStack_8._0_1_ = 0x27;
      FUN_0076a0a0(&iStack_b8);
      uStack_8._0_1_ = 0x28;
      FUN_0076a0a0(auStack_178);
      uStack_8._0_1_ = 0x29;
      FUN_0076a0a0(auStack_278);
      uStack_8._0_1_ = 0x2a;
      FUN_0076a0a0(auStack_2ec);
      uStack_8._0_1_ = 0x2b;
      cVar5 = FUN_00585a40(auStack_204);
      if (cVar5 == '\0') {
        FUN_0076a0a0(auStack_204);
        uStack_8._0_1_ = 0x2c;
        iVar7 = FUN_01674e20(0x60);
        uStack_8._0_1_ = 0x2d;
        if (iVar7 != 0) {
          FUN_0076a0a0(auStack_360);
        }
        FUN_0076ac50();
        FUN_0076ac50();
      }
      else {
        FUN_0076ac50();
      }
      FUN_0076ac50();
      FUN_0076ac50();
      FUN_0076ac50();
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_0076ac50();
      FUN_0151ddd0();
      FUN_00557f90();
      FUN_00550b30();
      FUN_00637950();
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_2;
    }
    if (DAT_01d60c40 == '\0') {
      if (*(int *)(*piStack_28 + 0x518) != 0) {
        LOCK();
        puVar6[4] = 1;
        UNLOCK();
        piStack_1c = &iStack_174;
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[1] = piVar9[1] + 1;
          UNLOCK();
        }
        iStack_174 = iStack_14;
        piStack_18 = auStack_16c;
        uStack_8._0_1_ = 0x2e;
        piStack_170 = piVar9;
        FUN_0054ef60();
        uStack_8._0_1_ = 0x2f;
        FUN_0054ef60();
        uStack_8._0_1_ = 0x30;
        FUN_0054ef60();
        uStack_124 = uStack_d0;
        if (puVar6 != (undefined4 *)0x0) {
          LOCK();
          puVar6[1] = puVar6[1] + 1;
          UNLOCK();
        }
        uStack_8._0_1_ = 0x31;
        puStack_120 = puVar1;
        puStack_11c = puVar6;
        FUN_0076a180();
        uStack_8._0_1_ = 0x32;
        ppuStack_48 = (undefined **)0x0;
        FUN_0076a180();
        uStack_8._0_1_ = 0x33;
        FUN_0076a180();
        uStack_8._0_1_ = 0x34;
        FUN_0076a180();
        uStack_8._0_1_ = 0x35;
        cVar5 = FUN_00585a40();
        if (cVar5 == '\0') {
          FUN_0076a180();
          uStack_8._0_1_ = 0x36;
          piStack_1c = (int *)FUN_01674e20();
          uStack_8._0_1_ = 0x37;
          if (piStack_1c == (int *)0x0) {
            auStack_40[0] = 0;
          }
          else {
            auStack_40[0] = FUN_0076a180();
          }
          FUN_0076acc0();
          FUN_0076acc0();
          bVar2 = true;
        }
        else {
          FUN_0076acc0();
          bVar2 = false;
        }
        FUN_0076acc0();
        ppuStack_48 = &PTR_FUN_018fb554;
        if (!bVar2) {
          ppuStack_48 = (undefined **)0x0;
        }
        FUN_0076acc0();
        FUN_0076acc0();
        FUN_0076acc0();
        uStack_8._0_1_ = 0x38;
        FUN_0076df30();
        FUN_008cd330();
        uStack_8._0_1_ = 7;
        FUN_00550990();
        if (DAT_01eb18d8 != '\0') {
          FUN_01677520();
        }
      }
    }
    else {
      FUN_00557fc0();
      FUN_00773100();
    }
    FUN_00557f90();
    FUN_00550b30();
    FUN_00637950();
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_2;
  }
  if (DAT_01d67098 == '\0') {
    iVar7 = FUN_00769d90();
    if (iVar7 != 0) {
      FUN_00d17720();
      LOCK();
      puVar6[4] = 2;
      UNLOCK();
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
      }
      iStack_cc = iStack_14;
      if (puVar6 != (undefined4 *)0x0) {
        LOCK();
        puVar6[1] = puVar6[1] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 0x18;
      piStack_c8 = piVar9;
      puStack_c4 = puVar1;
      puStack_c0 = puVar6;
      FUN_0054ef60(auStack_40);
      piStack_1c = aiStack_a4;
      uStack_8._0_1_ = 0x19;
      FUN_0054ef60(auStack_118);
      uStack_8._0_1_ = 0x1a;
      FUN_0054ef60(auStack_100);
      uStack_8._0_1_ = 0x1b;
      FUN_0054ef60(auStack_e8);
      iStack_5c = uStack_d0;
      uStack_8._0_1_ = 0x1c;
      FUN_0076a250(&iStack_cc);
      uStack_8._0_1_ = 0x1d;
      FUN_0076a250(auStack_18c);
      uStack_8._0_1_ = 0x1e;
      FUN_0076a250(auStack_28c);
      uStack_8._0_1_ = 0x1f;
      FUN_0076a250(auStack_300);
      uStack_8._0_1_ = 0x20;
      cVar5 = FUN_00585a40(auStack_218);
      if (cVar5 == '\0') {
        FUN_0076a250(auStack_218);
        uStack_8._0_1_ = 0x21;
        iVar7 = FUN_01674e20(0x74);
        uStack_8._0_1_ = 0x22;
        if (iVar7 != 0) {
          FUN_0076a250(auStack_374);
        }
        FUN_0076ad30();
        FUN_0076ad30();
      }
      else {
        FUN_0076ad30();
      }
      FUN_0076ad30();
      FUN_0076ad30();
      FUN_0076ad30();
      uStack_8._0_1_ = 0x16;
      FUN_0076ad30();
      FUN_0151ddd0();
      FUN_005507b0();
    }
    goto LAB_0076ee41;
  }
  FUN_00b50240();
  FUN_00a33fa0();
  FUN_0054ef60();
  uStack_8._0_1_ = 8;
  if (puStack_30 == (undefined4 *)0x0) {
    iVar7 = FUN_00769d90();
    if (iVar7 != 0) {
      FUN_00d17720();
      uStack_8._0_1_ = 9;
      FUN_00551230();
      uStack_8._0_1_ = 8;
      FUN_005507b0();
      if (puStack_30 != (undefined4 *)0x0) goto LAB_0076e9fc;
    }
  }
  else {
LAB_0076e9fc:
    puStack_c4 = puVar6 + 3;
    LOCK();
    puVar6[4] = 2;
    UNLOCK();
    if (piVar9 != (int *)0x0) {
      LOCK();
      piVar9[1] = piVar9[1] + 1;
      UNLOCK();
    }
    iStack_cc = iStack_14;
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 0xb;
    piStack_c8 = piVar9;
    puStack_c0 = puVar6;
    FUN_0054ef60(auStack_40);
    piStack_1c = aiStack_a4;
    uStack_8._0_1_ = 0xc;
    FUN_0054ef60(auStack_118);
    uStack_8._0_1_ = 0xd;
    FUN_0054ef60(auStack_100);
    uStack_8._0_1_ = 0xe;
    FUN_0054ef60(auStack_e8);
    iStack_5c = uStack_d0;
    uStack_8._0_1_ = 0xf;
    FUN_0076a420(&iStack_cc);
    uStack_8._0_1_ = 0x10;
    FUN_0076a420(auStack_18c);
    uStack_8._0_1_ = 0x11;
    FUN_0076a420(auStack_28c);
    uStack_8._0_1_ = 0x12;
    FUN_0076a420(auStack_300);
    uStack_8._0_1_ = 0x13;
    cVar5 = FUN_00585a40(auStack_218);
    if (cVar5 == '\0') {
      FUN_0076a420(auStack_218);
      uStack_8._0_1_ = 0x14;
      iVar7 = FUN_01674e20(0x74);
      uStack_8._0_1_ = 0x15;
      if (iVar7 != 0) {
        FUN_0076a420(auStack_374);
      }
      FUN_0076ad30();
      FUN_0076ad30();
    }
    else {
      FUN_0076ad30();
    }
    FUN_0076ad30();
    FUN_0076ad30();
    FUN_0076ad30();
    uStack_8._0_1_ = 8;
    FUN_0076ad30();
    FUN_0151ddd0();
  }
  FUN_005507b0();
LAB_0076ee41:
  *param_2 = (int)(puVar6 + 3);
  param_2[1] = (int)puVar6;
  FUN_00637950();
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar7 = piVar9[1] + -1;
    piVar9[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      piVar8 = piVar9 + 2;
      iVar7 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10864 ; VA 0x0076eea0 ; FUN_0076eea0 */

undefined4 __fastcall FUN_0076eea0(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x1c) >> 8),
                  *(int *)(*(int *)(param_1 + 0x1c) + 0x10) != 0);
}



/* FUNCTION 10865 ; VA 0x0076eeb0 ; FUN_0076eeb0 */

void __thiscall FUN_0076eeb0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3)

{
  FUN_0076b3e0(&DAT_01d60c48);
  *param_1 = 2;
  param_1[7] = param_3;
  param_1[0x17] = *param_2;
  *(undefined2 *)(param_1 + 0x18) = *(undefined2 *)(param_2 + 1);
  return;
}



/* FUNCTION 10866 ; VA 0x0076eef0 ; FUN_0076eef0 */

void __thiscall FUN_0076eef0(int *param_1,int *param_2,byte param_3,int param_4)

{
  FUN_0076b3e0(&DAT_01d60c48);
  *param_1 = param_3 + 4;
  param_1[7] = param_4;
  param_1[0x17] = *param_2;
  *(undefined2 *)(param_1 + 0x18) = *(undefined2 *)(param_2 + 1);
  return;
}



/* FUNCTION 10867 ; VA 0x0076ef30 ; FUN_0076ef30 */

void __thiscall FUN_0076ef30(int *param_1,int *param_2,uint param_3)

{
  FUN_0076b3e0(&DAT_01d60c48);
  *param_1 = (param_3 & 0xff) + 0xf;
  if (param_1 + 1 != param_2) {
    FUN_005542c0();
    return;
  }
  return;
}



/* FUNCTION 10868 ; VA 0x0076ef70 ; FUN_0076ef70 */

void __fastcall FUN_0076ef70(undefined4 *param_1)

{
  FUN_0076b3e0(&DAT_01d60c48);
  *param_1 = 0x13;
  FUN_00a33fb0(param_1 + 0x13);
  return;
}



/* FUNCTION 10869 ; VA 0x0076efa0 ; FUN_0076efa0 */

void __thiscall FUN_0076efa0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3)

{
  FUN_0076b3e0(&DAT_01d60c48);
  *param_1 = 3;
  param_1[7] = param_3;
  param_1[0x17] = *param_2;
  *(undefined2 *)(param_1 + 0x18) = *(undefined2 *)(param_2 + 1);
  return;
}



/* FUNCTION 10870 ; VA 0x0076efe0 ; FUN_0076efe0 */

void __thiscall FUN_0076efe0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  FUN_0076b3e0(&DAT_01d60c48);
  *param_1 = 10;
  if (param_1 + 8 != param_2) {
    puVar1 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,*puVar1);
  }
  return;
}



/* FUNCTION 10871 ; VA 0x0076f020 ; FUN_0076f020 */

void __thiscall FUN_0076f020(undefined4 *param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  
  FUN_0076b3e0(&DAT_01d60c48);
  *param_1 = 0xc;
  if (param_1 + 8 != param_2) {
    puVar1 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,*puVar1);
  }
  param_1[7] = param_3;
  return;
}



/* FUNCTION 10872 ; VA 0x0076f060 ; FUN_0076f060 */

void __thiscall FUN_0076f060(int *param_1,int *param_2,byte param_3,int param_4)

{
  FUN_0076b3e0(&DAT_01d60c48);
  *param_1 = param_3 + 7;
  param_1[7] = param_4;
  param_1[0x17] = *param_2;
  *(undefined2 *)(param_1 + 0x18) = *(undefined2 *)(param_2 + 1);
  return;
}



/* FUNCTION 10873 ; VA 0x0076f0a0 ; FUN_0076f0a0 */

/* WARNING: Type propagation algorithm not settling */

void __thiscall FUN_0076f0a0(undefined4 *param_1,int *param_2,int param_3)

{
  undefined uVar1;
  int iVar2;
  float *pfVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 *******pppppppuVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  undefined4 uVar11;
  bool bVar12;
  double dVar13;
  undefined4 *******apppppppuStack_3c [3];
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  undefined4 uStack_24;
  undefined2 uStack_20;
  undefined auStack_1c [4];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aeeb0;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = FUN_00d012f0(param_2);
  if (param_3 == 0) {
    uVar11 = 6;
  }
  else {
    uVar11 = *(undefined4 *)(param_3 + 0x70);
  }
  if (iStack_14 == 0) {
    uVar6 = (**(code **)(*param_2 + 0xb4))();
    switch(uVar6) {
    case 0:
switchD_0076f4a5_caseD_0:
      FUN_00773440(&uStack_24,param_2);
      FUN_0076efa0(&uStack_24,uVar11);
      ExceptionList = pvStack_10;
      return;
    case 1:
switchD_0076f4a5_caseD_1:
      FUN_00773440(&uStack_24,param_2);
switchD_0076f136_caseD_1:
      FUN_0076eeb0(&uStack_24,uVar11);
      ExceptionList = pvStack_10;
      return;
    case 2:
switchD_0076f4a5_caseD_2:
      FUN_00773440(&uStack_24,param_2);
      FUN_0076eef0(&uStack_24,0,uVar11);
      ExceptionList = pvStack_10;
      return;
    case 3:
      if (param_3 == 0) {
        iVar8 = param_2[0x3e];
        FUN_00b08320();
        FUN_01165580();
        FUN_0076b3e0(&DAT_01d60c48);
        *param_1 = 6;
        uVar1 = FUN_016f3cd0();
        *(char *)((int)param_1 + 0x49) = (char)iVar8;
        *(undefined *)(param_1 + 0x12) = uVar1;
        *(undefined *)((int)param_1 + 0x4a) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    default:
switchD_0076f136_caseD_7:
LAB_0076f7bd:
      FUN_0076b3e0(&DAT_01d60c48);
      break;
    case 4:
switchD_0076f4a5_caseD_4:
      FUN_00773440(&uStack_24,param_2);
      FUN_0076f060(&uStack_24,0,uVar11);
      ExceptionList = pvStack_10;
      return;
    case 9:
switchD_0076f4a5_caseD_9:
      FUN_00773440(&uStack_24,param_2);
      FUN_0076f060(&uStack_24,1,uVar11);
      ExceptionList = pvStack_10;
      return;
    case 0xb:
      iVar8 = param_2[3];
      iVar2 = FUN_00b50240();
      piVar10 = (int *)0x0;
      if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        piVar10 = param_2;
      }
      if (piVar10 != (int *)0x0) {
        if (*(char *)(piVar10 + 0x68) != '\0') {
          FUN_0054ef60(piVar10 + 0x69);
          if (param_3 == 0) {
            uStack_8 = 3;
            FUN_0076b3e0(&DAT_01d60c48);
            *param_1 = 0xd;
            if ((undefined4 ********)(param_1 + 1) != apppppppuStack_3c) {
              pppppppuVar7 = apppppppuStack_3c;
              if (0xf < (uint)fStack_28) {
                pppppppuVar7 = apppppppuStack_3c[0];
              }
              FUN_005542c0(pppppppuVar7,fStack_2c);
            }
            FUN_005507b0();
            ExceptionList = pvStack_10;
            return;
          }
          uStack_8 = 2;
          FUN_0076b3e0(&DAT_01d60c48);
          *param_1 = 0x12;
          if ((undefined4 ********)(param_1 + 1) != apppppppuStack_3c) {
            pppppppuVar7 = apppppppuStack_3c;
            if (0xf < (uint)fStack_28) {
              pppppppuVar7 = apppppppuStack_3c[0];
            }
            FUN_005542c0(pppppppuVar7,fStack_2c);
          }
          param_1[7] = uVar11;
          FUN_005507b0();
          ExceptionList = pvStack_10;
          return;
        }
        if ((DAT_01d67098 != '\0') && (iVar8 = FUN_00a33fa0(), *(int *)(iVar8 + 0x10) != 0)) {
          FUN_0076b3e0(&DAT_01d60c48);
          if (param_3 == 0) {
            *param_1 = 10;
            FUN_00a33fb0(param_1 + 0xe);
            ExceptionList = pvStack_10;
            return;
          }
          *param_1 = 0xc;
          FUN_00a33fb0(param_1 + 0xe);
          param_1[7] = uVar11;
          ExceptionList = pvStack_10;
          return;
        }
        if (param_3 == 0) {
          FUN_0076efe0(piVar10 + 0x5a);
          ExceptionList = pvStack_10;
          return;
        }
        FUN_0076f020(piVar10 + 0x5a,uVar11);
        ExceptionList = pvStack_10;
        return;
      }
      break;
    case 0xc:
      iVar8 = param_2[3];
      iVar2 = FUN_00cfb1a0();
      piVar10 = (int *)0x0;
      if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        piVar10 = param_2;
      }
      if (piVar10 != (int *)0x0) {
        iVar8 = FUN_00b08820();
        if (param_3 == 0) {
          if (iVar8 == 0) {
            bVar12 = param_2[0x5f] == 0;
          }
          else {
            bVar12 = false;
          }
          FUN_0076ef30(piVar10 + 0x55,bVar12);
          ExceptionList = pvStack_10;
          return;
        }
        FUN_0076b3e0(&DAT_01d60c48);
        piVar9 = piVar10 + 0x55;
        *param_1 = 0x11;
        if (param_1 + 1 != piVar9) {
          if (0xf < (uint)piVar10[0x5a]) {
            piVar9 = (int *)*piVar9;
          }
          FUN_005542c0(piVar9,piVar10[0x59]);
        }
        param_1[7] = uVar11;
        ExceptionList = pvStack_10;
        return;
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  iVar8 = *(int *)(iStack_14 + 0xc);
  iVar2 = FUN_00d0f2a0();
  iStack_18 = 0;
  if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iStack_18 = iStack_14;
  }
  if (iStack_18 == 0) {
    iVar8 = *(int *)(iStack_14 + 0xc);
    iVar4 = FUN_00d0fc80();
    iVar2 = 0;
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      iVar2 = iStack_14;
    }
    if (iVar2 != 0) {
      FUN_0076b3e0(&DAT_01d60c48);
      puVar5 = (undefined4 *)(iVar2 + 0x98);
      *param_1 = 0xf;
      if (param_1 + 1 == puVar5) {
        ExceptionList = pvStack_10;
        return;
      }
      if (0xf < *(uint *)(iVar2 + 0xac)) {
        puVar5 = (undefined4 *)*puVar5;
      }
      FUN_005542c0(puVar5,*(undefined4 *)(iVar2 + 0xa8));
      ExceptionList = pvStack_10;
      return;
    }
    iVar8 = *(int *)(iStack_14 + 0xc);
    iVar4 = FUN_00d0eec0();
    iVar2 = 0;
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      iVar2 = iStack_14;
    }
    if (iVar2 != 0) {
      FUN_0076b3e0(&DAT_01d60c48);
      param_1[7] = uVar11;
      param_1[0x17] = 0;
      *param_1 = 2;
      *(undefined2 *)(param_1 + 0x18) = 0;
      ExceptionList = pvStack_10;
      return;
    }
    iVar8 = *(int *)(iStack_14 + 0xc);
    iVar4 = FUN_00d0eae0();
    iVar2 = 0;
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      iVar2 = iStack_14;
    }
    if (iVar2 == 0) {
      FUN_0076eeb0(&uStack_24,uVar11);
      ExceptionList = pvStack_10;
      return;
    }
    FUN_0076eef0(&uStack_24,1,uVar11);
    ExceptionList = pvStack_10;
    return;
  }
  switch(*(undefined4 *)(iStack_18 + 0xb0)) {
  case 0:
    pfVar3 = (float *)FUN_00b08320();
    fStack_30 = *pfVar3 * *(float *)(iStack_18 + 0x54);
    fStack_2c = *(float *)(iStack_18 + 0x58) * pfVar3[1];
    fStack_28 = *(float *)(iStack_18 + 0x5c) * pfVar3[2];
    pfVar3 = (float *)FUN_011656d0(auStack_1c);
    dVar13 = (double)(*pfVar3 * *pfVar3 + pfVar3[1] * pfVar3[1]);
    FUN_017267a0();
    if (fStack_2c / (float)dVar13 < DAT_018daf58) {
      fStack_2c = 0.0;
      fStack_28 = 2.10195e-44;
      apppppppuStack_3c[0] = (undefined4 *******)((uint)apppppppuStack_3c[0] & 0xffffff00);
      FUN_005542c0("rbxasset://avatar/heads/head.mesh",0x21);
      uStack_8 = 0;
      FUN_009cbbb0(apppppppuStack_3c);
      uStack_8 = 1;
      FUN_0076ef30(apppppppuStack_3c,0);
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 0) {
      FUN_0076eef0(&uStack_24,1,6);
      ExceptionList = pvStack_10;
      return;
    }
    break;
  case 1:
    goto switchD_0076f136_caseD_1;
  case 2:
    goto switchD_0076f4a5_caseD_4;
  case 3:
    goto switchD_0076f4a5_caseD_0;
  case 4:
    goto switchD_0076f4a5_caseD_2;
  case 5:
    FUN_0076ef30(iStack_18 + 0x98,0);
    ExceptionList = pvStack_10;
    return;
  case 6:
    goto switchD_0076f4a5_caseD_1;
  default:
    goto switchD_0076f136_caseD_7;
  case 0xb:
    goto switchD_0076f4a5_caseD_9;
  }
  goto LAB_0076f7bd;
}



/* FUNCTION 10874 ; VA 0x0076f840 ; FUN_0076f840 */

void __fastcall FUN_0076f840(int *param_1)

{
  byte *pbVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  undefined4 *puVar13;
  undefined8 uVar14;
  undefined auStack_b4 [76];
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  undefined4 *puStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aeee7;
  pvStack_10 = ExceptionList;
  iStack_38 = *(int *)(*param_1 + 0x518);
  if ((iStack_38 != 0) && (param_1[0x3e] != 0)) {
    ExceptionList = &pvStack_10;
    piStack_18 = param_1;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1a28)
       && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb1a28), DAT_01eb1a28 == -1)) {
      uStack_8 = 0;
      uVar14 = FUN_0152dab0("Render","invalidateFailedResource",0xffffffff);
      DAT_01eb1a24 = (undefined4)((ulonglong)uVar14 >> 0x20);
      DAT_01eb1a20 = (undefined4)uVar14;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb1a28);
    }
    uStack_40 = DAT_01eb1a20;
    uStack_50 = DAT_01eb1a20;
    uStack_3c = DAT_01eb1a24;
    uStack_4c = DAT_01eb1a24;
    uStack_48 = FUN_0152d930(DAT_01eb1a20,DAT_01eb1a24);
    uStack_8 = 1;
    if (param_1[3] == 0) {
      puStack_14 = (undefined4 *)0x0;
    }
    else {
      puStack_14 = *(undefined4 **)(param_1[6] + param_1[2] * 4);
    }
    for (; puStack_14 != (undefined4 *)0x0; puStack_14 = (undefined4 *)*puStack_14) {
      puStack_28 = puStack_14 + 3;
      puVar5 = (undefined4 *)FUN_009cc5b0(auStack_68);
      puVar8 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puVar8 = (undefined4 *)*puVar5;
      }
      uVar10 = 0;
      uVar11 = 0x811c9dc5;
      if (puVar5[4] != 0) {
        do {
          pbVar1 = (byte *)(uVar10 + (int)puVar8);
          uVar10 = uVar10 + 1;
          uVar11 = (*pbVar1 ^ uVar11) * 0x1000193;
        } while (uVar10 < (uint)puVar5[4]);
      }
      iStack_20 = piStack_18[0x3f];
      puVar8 = (undefined4 *)piStack_18[0x3d];
      puStack_30 = (undefined4 *)(iStack_20 + (piStack_18[0x42] & uVar11) * 8);
      iStack_24 = (piStack_18[0x42] & uVar11) * 8 + 4;
      puVar13 = (undefined4 *)*puStack_30;
      puStack_2c = puVar5;
      puStack_1c = puVar13;
      while( true ) {
        puVar6 = puVar8;
        if (puStack_1c != puVar8) {
          puVar6 = (undefined4 *)**(undefined4 **)(iStack_24 + iStack_20);
        }
        if (puVar13 == puVar6) goto LAB_0076fa10;
        piVar7 = puVar13 + 2;
        puVar6 = puVar5;
        if (0xf < (uint)puVar5[5]) {
          puVar6 = (undefined4 *)*puVar5;
        }
        if (0xf < (uint)puVar13[7]) {
          piVar7 = (int *)*piVar7;
        }
        cVar4 = FUN_0055c360(piVar7,puVar13[6],puVar6,puVar5[4]);
        puVar6 = puStack_2c;
        puVar2 = puVar13;
        puVar3 = puVar13;
        if (cVar4 != '\0') break;
        puVar13 = (undefined4 *)*puVar13;
      }
      while( true ) {
        puStack_1c = puVar3;
        puStack_34 = puVar2;
        puVar5 = puVar8;
        if ((undefined4 *)*puStack_30 != puVar8) {
          puVar5 = (undefined4 *)**(undefined4 **)(iStack_24 + iStack_20);
        }
        if (puVar13 == puVar5) break;
        piVar7 = puVar13 + 2;
        if (0xf < (uint)puVar13[7]) {
          piVar7 = (int *)*piVar7;
        }
        puVar5 = puVar6;
        if (0xf < (uint)puVar6[5]) {
          puVar5 = (undefined4 *)*puVar6;
        }
        cVar4 = FUN_0055c360(puVar5,puVar6[4],piVar7,puVar13[6]);
        if (cVar4 == '\0') break;
        puVar13 = (undefined4 *)*puVar13;
        puVar2 = puStack_34;
        puVar3 = puStack_1c;
      }
      puVar5 = puStack_34;
      if (puStack_1c == puVar13) {
LAB_0076fa10:
        puVar13 = puVar8;
        puVar5 = puVar8;
      }
      iVar12 = 0;
      for (; puVar5 != puVar13; puVar5 = (undefined4 *)*puVar5) {
        iVar12 = iVar12 + 1;
      }
      if (0xf < uStack_54) {
        uVar11 = uStack_54 + 1;
        uVar10 = auStack_68[0];
        if (0xfff < uVar11) {
          uVar10 = *(uint *)(auStack_68[0] - 4);
          uVar11 = uStack_54 + 0x24;
          if (0x1f < (auStack_68[0] - uVar10) - 4) goto LAB_0076fbc3;
        }
        FUN_01674ea0(uVar10,uVar11);
      }
      if (iVar12 != 0) {
        puVar8 = puStack_28;
        if (0xf < (uint)puStack_28[5]) {
          puVar8 = (undefined4 *)*puStack_28;
        }
        uVar9 = FUN_01675640(auStack_68,"Refresh of asset: %s",puVar8);
        uStack_8._0_1_ = 2;
        FUN_00d102b0(uVar9);
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        if (0xf < uStack_54) {
          uVar11 = uStack_54 + 1;
          uVar10 = auStack_68[0];
          if (0xfff < uVar11) {
            uVar10 = *(uint *)(auStack_68[0] - 4);
            uVar11 = uStack_54 + 0x24;
            if (0x1f < (auStack_68[0] - uVar10) - 4) {
LAB_0076fbc3:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar10,uVar11);
        }
        puVar8 = puStack_14;
        uStack_58 = 0;
        uStack_54 = 0xf;
        auStack_68[0] = auStack_68[0] & 0xffffff00;
        switch(*(undefined4 *)(puStack_14[0x1b] + 8)) {
        case 0xd:
        case 0xe:
        case 0x12:
          uVar9 = FUN_008ccd80();
          break;
        case 0xf:
        case 0x10:
        case 0x11:
          uVar9 = FUN_008ccd50();
          break;
        default:
          uVar9 = FUN_008ccd70();
        }
        FUN_008cefc0(puVar8[0x1b] + 0xc,uVar9,&DAT_01d62f20);
        if (puVar8[0x1c] != 0) {
          LOCK();
          piVar7 = (int *)(puVar8[0x1c] + 4);
          *piVar7 = *piVar7 + 1;
          UNLOCK();
        }
        FUN_00773100(puVar8[0x1b],puVar8[0x1c],auStack_b4,0);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_00637950();
        puStack_14 = puVar8;
      }
    }
    uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_005cb850();
    FUN_005cb500(8);
    uStack_8 = 6;
    FUN_0152dda0(uStack_40,uStack_3c,uStack_48);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10875 ; VA 0x0076fc40 ; FUN_0076fc40 */

void FUN_0076fc40(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined8 uVar4;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 auStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aef24;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1a38) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb1a38), DAT_01eb1a38 == -1)) {
    uStack_8 = 0;
    uVar4 = FUN_0152dab0("Systems","Async_Mesh",0xffffffff);
    DAT_01eb1a34 = (undefined4)((ulonglong)uVar4 >> 0x20);
    DAT_01eb1a30 = (undefined4)uVar4;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb1a38);
  }
  uVar2 = DAT_01eb1a34;
  uVar1 = DAT_01eb1a30;
  uVar4 = FUN_0152d930(DAT_01eb1a30,DAT_01eb1a34);
  iStack_1c = *(int *)(param_1 + 0xc);
  if (iStack_1c != 0) {
    LOCK();
    *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
    UNLOCK();
    iStack_1c = *(int *)(param_1 + 0xc);
  }
  uStack_20 = *(undefined4 *)(param_1 + 8);
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  FUN_0076a000(auStack_18);
  puVar3 = (undefined4 *)(*(int *)(param_1 + 8) + 8);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  switch(*puVar3) {
  case 2:
    FUN_007b77a0(auStack_18[0],puVar3);
    break;
  case 3:
    FUN_007ba480(auStack_18[0],puVar3);
    break;
  case 4:
  case 5:
    FUN_007b86c0(auStack_18[0],puVar3);
    break;
  case 6:
    FUN_007bb400(auStack_18[0],puVar3);
    break;
  case 7:
  case 8:
    FUN_007bb540(auStack_18[0],puVar3);
    break;
  default:
    FUN_0056b650();
    uStack_8 = 4;
    goto LAB_0076fd81;
  }
  LOCK();
  *(undefined4 *)(*(int *)(param_1 + 8) + 4) = 3;
  UNLOCK();
  FUN_00772ec0(&uStack_20);
  if (DAT_01eb18d8 != '\0') {
    FUN_01677520(DAT_01eb18d8,"Mesh manager: generated part type \'%d\'",
                 *(undefined4 *)(*(int *)(param_1 + 8) + 8));
  }
  FUN_0056b650();
  uStack_8 = 5;
LAB_0076fd81:
  FUN_0152dda0(uVar1,uVar2,uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10876 ; VA 0x0076fe20 ; FUN_0076fe20 */

void FUN_0076fe20(void)

{
  FUN_0076b740();
  return;
}



/* FUNCTION 10877 ; VA 0x0076fe30 ; FUN_0076fe30 */

void FUN_0076fe30(void)

{
  FUN_0076bd00();
  return;
}



/* FUNCTION 10878 ; VA 0x0076fe40 ; FUN_0076fe40 */

void FUN_0076fe40(void)

{
  FUN_0076c3f0();
  return;
}



/* FUNCTION 10879 ; VA 0x0076fe50 ; FUN_0076fe50 */

void FUN_0076fe50(void)

{
  FUN_0076c7a0();
  return;
}



/* FUNCTION 10880 ; VA 0x0076fe60 ; FUN_0076fe60 */

void FUN_0076fe60(void)

{
  FUN_0076cb50();
  return;
}



/* FUNCTION 10881 ; VA 0x0076fe70 ; FUN_0076fe70 */

/* WARNING: Removing unreachable block (ram,0x0076ff51) */
/* WARNING: Removing unreachable block (ram,0x0076ff5a) */
/* WARNING: Removing unreachable block (ram,0x0076ff69) */
/* WARNING: Removing unreachable block (ram,0x0076ff2b) */
/* WARNING: Removing unreachable block (ram,0x0076ff34) */
/* WARNING: Removing unreachable block (ram,0x0076ff43) */
/* WARNING: Removing unreachable block (ram,0x0076ff77) */
/* WARNING: Removing unreachable block (ram,0x0076ff80) */
/* WARNING: Removing unreachable block (ram,0x0076ff8e) */

undefined4
FUN_0076fe70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0076ba20(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 10882 ; VA 0x0076ffb0 ; FUN_0076ffb0 */

/* WARNING: Removing unreachable block (ram,0x00770091) */
/* WARNING: Removing unreachable block (ram,0x0077009a) */
/* WARNING: Removing unreachable block (ram,0x007700a9) */
/* WARNING: Removing unreachable block (ram,0x0077006b) */
/* WARNING: Removing unreachable block (ram,0x00770074) */
/* WARNING: Removing unreachable block (ram,0x00770083) */
/* WARNING: Removing unreachable block (ram,0x007700b7) */
/* WARNING: Removing unreachable block (ram,0x007700c0) */
/* WARNING: Removing unreachable block (ram,0x007700ce) */

undefined4
FUN_0076ffb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0076bf80(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 10883 ; VA 0x007700f0 ; FUN_007700f0 */

bool FUN_007700f0(float *param_1,float *param_2)

{
  float *pfVar1;
  double dVar2;
  undefined auStack_1c [8];
  float fStack_14;
  float fStack_10;
  float fStack_c;
  
  fStack_14 = *param_1 * *param_2;
  fStack_10 = param_1[1] * param_2[1];
  fStack_c = param_1[2] * param_2[2];
  pfVar1 = (float *)FUN_011656d0(auStack_1c);
  dVar2 = (double)(*pfVar1 * *pfVar1 + pfVar1[1] * pfVar1[1]);
  FUN_017267a0();
  return DAT_018daf58 <= fStack_10 / (float)dVar2;
}



/* FUNCTION 10884 ; VA 0x00770180 ; FUN_00770180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00770180(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  short sVar4;
  char cVar5;
  undefined2 *puVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined8 *puVar10;
  char *pcVar11;
  undefined8 uStack_fc;
  undefined4 uStack_f4;
  undefined2 uStack_f0;
  char acStack_ee [2];
  undefined4 auStack_ec [28];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  short *psStack_14;
  int *piStack_10;
  int iStack_c;
  undefined2 *puStack_8;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1b00) {
    FUN_016f3809(&DAT_01eb1b00);
    if (DAT_01eb1b00 == -1) {
      _DAT_01eb1aa0 = _DAT_018fb5d0;
      uRam01eb1aa4 = _UNK_018fb5d4;
      uRam01eb1aa8 = _UNK_018fb5d8;
      DAT_01eb1aac._0_4_ = _UNK_018fb5dc;
      DAT_01eb1aac._4_4_ = _DAT_018fb5d0;
      DAT_01eb1ab4 = _UNK_018fb5d4;
      uRam01eb1ab8 = _UNK_018fb5d8;
      uRam01eb1abc = _UNK_018fb5dc;
      _DAT_01eb1ac0 = _DAT_018fb5e0;
      DAT_01eb1ac4._0_4_ = _UNK_018fb5e4;
      DAT_01eb1ac4._4_4_ = _UNK_018fb5e8;
      DAT_01eb1acc = _UNK_018fb5ec;
      _DAT_01eb1ad0 = _DAT_018fb5b0;
      uRam01eb1ad4 = _UNK_018fb5b4;
      uRam01eb1ad8 = _UNK_018fb5b8;
      uRam01eb1adc = _UNK_018fb5bc;
      _DAT_01eb1ae0 = _DAT_018fb5c0;
      uRam01eb1ae4 = _UNK_018fb5c4;
      uRam01eb1ae8 = _UNK_018fb5c8;
      uRam01eb1aec = _UNK_018fb5cc;
      _DAT_01eb1af0 = _DAT_018fb5a0;
      uRam01eb1af4 = _UNK_018fb5a4;
      uRam01eb1af8 = _UNK_018fb5a8;
      uRam01eb1afc = _UNK_018fb5ac;
      FUN_016f37bf(&DAT_01eb1b00);
    }
  }
  FUN_00715060(0x300,param_1);
  FUN_00715060(0x240,param_1 + 3);
  FUN_00727cd0(0x24,param_1 + 6);
  piStack_10 = &DAT_018fb490;
  puStack_1c = (undefined4 *)*param_1;
  puStack_18 = (undefined4 *)param_1[3];
  psStack_14 = (short *)param_1[6];
  iStack_c = 0;
  cVar5 = '\0';
  puStack_8 = &DAT_018fb454;
  do {
    puVar8 = &DAT_018fb46c;
    puVar9 = auStack_ec;
    pcVar11 = (char *)&uStack_70;
    do {
      iVar7 = *piStack_10;
      puVar9[2] = DAT_018fb468;
      pcVar11[1] = '\0';
      pcVar11[2] = '\0';
      pcVar11[3] = -1;
      uVar2 = *(undefined8 *)(&DAT_01eb1aa0 + iVar7 * 0xc);
      uVar3 = *(undefined4 *)(iVar7 * 0xc + 0x1eb1aa8);
      *(undefined8 *)(puVar9 + -4) = uVar2;
      puVar9[-2] = uVar3;
      *puVar9 = *puVar8;
      puVar9[1] = puVar8[1];
      puVar6 = puStack_8;
      *(undefined8 *)(pcVar11 + -0xc) = uVar2;
      *(undefined2 *)(puVar9 + -1) = *puVar6;
      *(undefined *)((int)puVar9 + -2) = *(undefined *)(puStack_8 + 1);
      puVar9[3] = 0xffffffff;
      *(char *)((int)puVar9 + -1) = cVar5;
      *(undefined4 *)(pcVar11 + -4) = *(undefined4 *)(iVar7 * 0xc + 0x1eb1aa8);
      *pcVar11 = cVar5;
      *(undefined4 *)(pcVar11 + 4) = *puVar8;
      puVar1 = puVar8 + 1;
      puVar8 = puVar8 + 2;
      *(undefined4 *)(pcVar11 + 8) = *puVar1;
      piStack_10 = piStack_10 + 1;
      puVar9 = puVar9 + 8;
      pcVar11 = pcVar11 + 0x18;
    } while ((int)puVar8 < 0x18fb48c);
    sVar4 = (short)iStack_c;
    *psStack_14 = sVar4;
    psStack_14[1] = sVar4 + 1;
    psStack_14[2] = sVar4 + 2;
    psStack_14[3] = sVar4 + 2;
    psStack_14[4] = sVar4 + 1;
    psStack_14[5] = sVar4 + 3;
    puVar10 = &uStack_fc;
    puVar9 = puStack_1c;
    for (iVar7 = 0x20; iVar7 != 0; iVar7 = iVar7 + -1) {
      *puVar9 = *(undefined4 *)puVar10;
      puVar10 = (undefined8 *)((int)puVar10 + 4);
      puVar9 = puVar9 + 1;
    }
    psStack_14 = psStack_14 + 6;
    if (puStack_18 != (undefined4 *)0x0) {
      *puStack_18 = uStack_7c;
      puStack_18[1] = uStack_78;
      puStack_18[2] = uStack_74;
      puStack_18[3] = uStack_70;
      puStack_18[4] = uStack_6c;
      puStack_18[5] = uStack_68;
      puStack_18[6] = uStack_64;
      puStack_18[7] = uStack_60;
      puStack_18[8] = uStack_5c;
      puStack_18[9] = uStack_58;
      puStack_18[10] = uStack_54;
      puStack_18[0xb] = uStack_50;
      puStack_18[0xc] = uStack_4c;
      puStack_18[0xd] = uStack_48;
      puStack_18[0xe] = uStack_44;
      puStack_18[0xf] = uStack_40;
      puStack_18[0x10] = uStack_3c;
      puStack_18[0x11] = uStack_38;
      puStack_18[0x12] = uStack_34;
      puStack_18[0x13] = uStack_30;
      puStack_18[0x14] = uStack_2c;
      puStack_18[0x15] = uStack_28;
      puStack_18[0x16] = uStack_24;
      puStack_18[0x17] = uStack_20;
      puStack_18 = puStack_18 + 0x18;
    }
    iStack_c = iStack_c + 4;
    puStack_8 = (undefined2 *)((int)puStack_8 + 3);
    cVar5 = cVar5 + '\x01';
    puStack_1c = puStack_1c + 0x20;
  } while ((int)puStack_8 < 0x18fb466);
  return;
}



/* FUNCTION 10885 ; VA 0x007703e0 ; FUN_007703e0 */

void FUN_007703e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar2 = (int *)(param_1[1] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar2 = (int *)(param_1[3] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      if (param_3 != 1) {
        return;
      }
      FUN_0056b650();
      return;
    }
    if (param_3 == 2) {
      FUN_0056b650();
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9f7c8);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_10af045904f5b1292edb36d6129cc8ee>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 10886 ; VA 0x007704a0 ; FUN_007704a0 */

void FUN_007704a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aef3f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x60);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_0076a0a0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0076ac50();
        FUN_01674ea0(iVar2,0x60);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d9f720);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_1db99633c498332ad25069bf56a7a4da>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 10887 ; VA 0x007705f0 ; FUN_007705f0 */

void FUN_007705f0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aef5f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x5c);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_0076a180(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0076acc0();
        FUN_01674ea0(iVar2,0x5c);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d9f678);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_333c88abaff80aed5e597705d9b72926>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 10888 ; VA 0x00770740 ; FUN_00770740 */

void FUN_00770740(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aef7f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x74);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_0076a250(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0076ad30();
        FUN_01674ea0(iVar2,0x74);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d9f758);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_3ad23e83b370cf8e0bb2f3fdefb47d60>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 10889 ; VA 0x00770890 ; FUN_00770890 */

void FUN_00770890(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aef5f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x5c);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_0076a180(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0076acc0();
        FUN_01674ea0(iVar2,0x5c);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d9f6b0);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_5349be34beba0c21b5532fe9983b3327>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 10890 ; VA 0x007709e0 ; FUN_007709e0 */

void FUN_007709e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aef9f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(100);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_0076a330(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0076ade0();
        FUN_01674ea0(iVar2,100);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d9f640);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_d2d7e86d186dd36e1f653a46336b044e>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 10891 ; VA 0x00770b30 ; FUN_00770b30 */

void FUN_00770b30(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aef9f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(100);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_0076a330(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0076ade0();
        FUN_01674ea0(iVar2,100);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d9f6e8);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_e19d14d3812d97e25e13fa38eb7794ea>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 10892 ; VA 0x00770c80 ; FUN_00770c80 */

void FUN_00770c80(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aef7f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x74);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_0076a420(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0076ad30();
        FUN_01674ea0(iVar2,0x74);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d9f790);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_f6198f459f072d0eaf9c72b89860bff8>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 10893 ; VA 0x00770dd0 ; FUN_00770dd0 */

void FUN_00770dd0(undefined4 param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009cc5b0(aiStack_30);
  uStack_8 = 0;
  FUN_005ca900(auStack_18,uVar1,param_1);
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    iVar2 = aiStack_30[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10894 ; VA 0x00770e60 ; FUN_00770e60 */

int FUN_00770e60(int param_1,int *param_2,int param_3,undefined4 param_4,int *param_5,
                undefined4 param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  int iVar5;
  undefined **ppuVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined auStack_270 [100];
  undefined auStack_20c [100];
  undefined auStack_1a8 [100];
  undefined auStack_144 [100];
  undefined auStack_e0 [100];
  undefined4 uStack_7c;
  int *piStack_78;
  undefined auStack_74 [72];
  undefined4 uStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017af031;
  pvStack_10 = ExceptionList;
  LOCK();
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 4) = 2;
  UNLOCK();
  puStack_14 = &uStack_7c;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_7c = param_4;
  piStack_78 = param_5;
  puStack_18 = auStack_74;
  uStack_8 = 3;
  uStack_7 = 0;
  FUN_0054ef60(param_3);
  uStack_8 = 4;
  FUN_0054ef60(param_3 + 0x18);
  uStack_8 = 5;
  FUN_0054ef60(param_3 + 0x30);
  uStack_2c = *(undefined4 *)(param_3 + 0x48);
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  piStack_24 = param_2;
  iStack_28 = param_1;
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  uStack_20 = param_6;
  piStack_1c = param_7;
  uStack_8 = 6;
  FUN_0076a330(&uStack_7c);
  uStack_8 = 7;
  uVar8 = 0;
  FUN_0076a330(auStack_270);
  uStack_8 = 8;
  FUN_0076a330(auStack_20c);
  uStack_8 = 9;
  FUN_0076a330(auStack_1a8);
  uStack_8 = 10;
  cVar4 = FUN_00585a40(auStack_e0,uVar8);
  if (cVar4 == '\0') {
    FUN_0076a330(auStack_e0);
    uStack_8 = 0xb;
    iVar5 = FUN_01674e20(100);
    uStack_8 = 0xc;
    if (iVar5 != 0) {
      FUN_0076a330(auStack_144);
    }
    FUN_0076ade0();
    FUN_0076ade0();
    bVar3 = true;
  }
  else {
    FUN_0076ade0();
    bVar3 = false;
  }
  FUN_0076ade0();
  ppuVar6 = &PTR_FUN_018fb564;
  if (!bVar3) {
    ppuVar6 = (undefined **)0x0;
  }
  FUN_0076ade0(ppuVar6);
  FUN_0076ade0();
  _uStack_8 = CONCAT31(uStack_7,2);
  FUN_0076ade0();
  iVar5 = FUN_0151ddd0();
  if (DAT_01eb18d8 != '\0') {
    puVar7 = (undefined4 *)(param_1 + 0xc);
    if (0xf < *(uint *)(param_1 + 0x20)) {
      puVar7 = (undefined4 *)*puVar7;
    }
    iVar5 = FUN_01677520(DAT_01eb18d8,"Mesh manager: scheduled for decode \'%s\'",puVar7);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 10895 ; VA 0x00771120 ; FUN_00771120 */

void FUN_00771120(int *param_1,int param_2)

{
  float fVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  float *pfVar5;
  int iVar6;
  float *pfVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  int iStack_94;
  undefined8 uStack_90;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_64;
  undefined auStack_5c [4];
  int *piStack_58;
  uint uStack_54;
  int iStack_50;
  int iStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  int iStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  int iStack_28;
  int iStack_24;
  float fStack_20;
  float fStack_1c;
  int iStack_18;
  int *piStack_14;
  
  uStack_48 = *(undefined4 *)(*param_1 + 8);
  piVar2 = (int *)FUN_0076a000(auStack_5c);
  iVar3 = *piVar2;
  iVar6 = piVar2[1];
  *piVar2 = 0;
  piVar2[1] = 0;
  param_1[2] = iVar3;
  piVar2 = (int *)param_1[3];
  param_1[3] = iVar6;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_58 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_58[1] + -1;
    piStack_58[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_58)();
      LOCK();
      piVar2 = piStack_58 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_58 + 4))();
      }
    }
  }
  fStack_34 = DAT_018fb574;
  fStack_20 = DAT_018fb570;
  piVar2 = (int *)param_1[2];
  piVar2[9] = 0;
  piVar2[10] = 0x20;
  iStack_24 = (*(int *)(param_2 + 0x14) - (int)*(float **)(param_2 + 0x10)) / 0x54;
  pfVar7 = *(float **)(param_2 + 0x10);
  fStack_88 = fStack_20;
  fStack_38 = fStack_20;
  fStack_30 = fStack_34;
  fStack_2c = fStack_34;
  for (iVar3 = iStack_24; iVar3 != 0; iVar3 = iVar3 + -1) {
    fVar12 = *pfVar7;
    fVar13 = pfVar7[1];
    fVar14 = fVar12;
    if (fStack_38 <= fVar12) {
      fVar14 = fStack_38;
    }
    if (fVar12 <= fStack_2c) {
      fVar12 = fStack_2c;
    }
    fVar15 = fVar13;
    if (fStack_20 <= fVar13) {
      fVar15 = fStack_20;
    }
    fVar1 = pfVar7[2];
    if (fVar13 <= fStack_30) {
      fVar13 = fStack_30;
    }
    fVar11 = fVar1;
    if (fVar1 <= fStack_34) {
      fVar11 = fStack_34;
    }
    if (fStack_88 <= fVar1) {
      fVar1 = fStack_88;
    }
    pfVar7 = pfVar7 + 0x15;
    fStack_20 = fVar15;
    fStack_88 = fVar1;
    fStack_38 = fVar14;
    fStack_34 = fVar11;
    fStack_30 = fVar13;
    fStack_2c = fVar12;
  }
  if (fStack_2c - fStack_38 < DAT_018f784c) {
    fStack_2c = fStack_2c + DAT_018f784c;
  }
  if (fStack_30 - fStack_20 < DAT_018f784c) {
    fStack_30 = fStack_30 + DAT_018f784c;
  }
  if (fStack_34 - fStack_88 < DAT_018f784c) {
    fStack_34 = fStack_34 + DAT_018f784c;
  }
  uStack_90 = CONCAT44(fStack_20,fStack_38);
  iVar3 = *param_1;
  *(float *)(iVar3 + 0x168) = fStack_38;
  *(float *)(iVar3 + 0x16c) = fStack_20;
  *(float *)(iVar3 + 0x170) = fStack_88;
  *(float *)(iVar3 + 0x174) = fStack_2c;
  *(ulonglong *)(iVar3 + 0x178) = CONCAT44(fStack_34,fStack_30);
  fStack_84 = fStack_2c;
  fStack_80 = fStack_30;
  fStack_7c = fStack_34;
  fStack_64 = fStack_34;
  piStack_58 = (int *)fStack_88;
  fStack_1c = fStack_88;
  piStack_14 = piVar2;
  switch(uStack_48) {
  case 10:
  case 0xd:
    fStack_38 = *(float *)(param_2 + 0x10);
    uStack_44 = *(int *)(param_2 + 0x28);
    iStack_24 = (*(int *)(param_2 + 0x14) - (int)fStack_38) / 0x54;
    uVar8 = (int)(*(int *)(param_2 + 0x2c) - uStack_44) >> 2;
    uStack_48 = uVar8;
    FUN_00715060(iStack_24 * 0x20,piVar2);
    FUN_00727cd0(uVar8,piVar2 + 6);
    uStack_40 = piVar2[6];
    iVar3 = *piStack_14;
    piVar2 = piStack_14 + 3;
    FUN_00715060(iStack_24 * 0x18,piVar2);
    FUN_0076d210(*piVar2,fStack_38,iStack_24,2);
    FUN_0076d3c0(iVar3,fStack_38,iStack_24,2);
    uVar8 = 0;
    if (uStack_48 != 0) {
      do {
        *(undefined2 *)(uStack_40 + uVar8 * 2) = *(undefined2 *)(uStack_44 + uVar8 * 4);
        uVar8 = uVar8 + 1;
      } while (uVar8 < uStack_48);
    }
    iVar3 = *(int *)(param_2 + 0x34);
    iVar6 = *(int *)(param_2 + 0x38) - iVar3 >> 2;
    if (DAT_01d71798 != '\0') {
      uVar8 = iVar6 - 1;
      uVar9 = 5;
      if (uVar8 < 6) {
        uVar9 = uVar8;
      }
      *(uint *)(*param_1 + 0x164) = uVar9;
    }
    FUN_0076d750(param_1,iVar3,iVar6);
    return;
  case 0xc:
  case 0x12:
    iStack_18 = *(int *)(*param_1 + 0x24);
    iStack_28 = *(int *)(param_2 + 0x10);
    iStack_4c = *(int *)(param_2 + 0x28);
    uVar8 = *(int *)(param_2 + 0x2c) - iStack_4c >> 2;
    uStack_40 = uVar8;
    FUN_00715060(iStack_24 * 0x20,piVar2);
    piVar10 = piStack_14 + 6;
    FUN_00727cd0(uVar8,piVar10);
    uStack_48 = *piStack_14;
    piVar2 = piStack_14 + 3;
    piStack_14 = (int *)*piVar10;
    FUN_00715060(iStack_24 * 0x18,piVar2);
    iVar3 = iStack_18;
    piStack_58 = (int *)*piVar2;
    FUN_0076d210(piStack_58,iStack_28,iStack_24,iStack_18);
    FUN_0076d3c0(uStack_48,iStack_28,iStack_24,iVar3);
    uVar9 = 0;
    iStack_50 = *(int *)(param_2 + 0x34);
    uVar8 = *(int *)(param_2 + 0x38) - iStack_50 >> 2;
    uStack_44 = 6;
    if (uVar8 < 7) {
      uStack_44 = uVar8;
    }
    uVar8 = 0;
    if (uStack_40 != 0) {
      uStack_54 = iStack_18 + 1;
      do {
        iStack_3c = *(int *)(iStack_4c + uVar8 * 4);
        if ((uVar9 < uStack_44) && (uVar8 == *(uint *)(iStack_50 + uVar9 * 4))) {
          *(int *)((int)&uStack_90 + uVar9 * 4) = (int)piStack_14 - *piVar10 >> 1;
          uVar9 = uVar9 + 1;
        }
        if (*(byte *)(iStack_3c * 0x54 + 0x1c + iStack_28) == uStack_54) {
          *(short *)piStack_14 = (short)iStack_3c;
          piStack_14 = (int *)((int)piStack_14 + 2);
        }
        uVar8 = uVar8 + 1;
      } while (uVar8 < uStack_40);
    }
    piVar2 = piStack_14;
    FUN_00727cd0((int)piStack_14 - *piVar10 >> 1,piVar10);
    uVar8 = uStack_44;
    (&iStack_94)[uStack_44] = (int)piVar2 - *piVar10 >> 1;
    if (DAT_01d71798 != '\0') {
      uVar9 = uVar8 - 1;
      uVar4 = 5;
      if (uVar9 < 6) {
        uVar4 = uVar9;
      }
      *(uint *)(*param_1 + 0x164) = uVar4;
    }
    FUN_0076d750(param_1,&uStack_90,uVar8);
    iStack_18 = iStack_18 * 0x20;
    if (iStack_24 != 0) {
      pfVar7 = (float *)((int)piStack_58 + 0x14);
      pfVar5 = (float *)(uStack_48 + 8);
      do {
        fVar13 = (pfVar5[-2] - fStack_38) / (fStack_2c - fStack_38);
        fVar14 = (pfVar5[-1] - fStack_20) / (fStack_30 - fStack_20);
        fVar12 = (*pfVar5 - fStack_1c) / (fStack_34 - fStack_1c);
        fVar15 = *(float *)(&DAT_018fac90 + iStack_18) * fVar13 +
                 *(float *)(&DAT_018fac94 + iStack_18) * fVar14 +
                 *(float *)(&DAT_018fac98 + iStack_18) * fVar12 +
                 *(float *)(&DAT_018fac9c + iStack_18);
        pfVar5[2] = fVar15;
        pfVar5[3] = fVar14 * *(float *)(&DAT_018faca4 + iStack_18) +
                    fVar13 * *(float *)(&DAT_018faca0 + iStack_18) +
                    *(float *)(&DAT_018faca8 + iStack_18) * fVar12 +
                    *(float *)(&DAT_018facac + iStack_18);
        if (piStack_58 != (int *)0x0) {
          pfVar7[-1] = fVar15;
          *pfVar7 = pfVar5[3];
          pfVar7 = pfVar7 + 6;
        }
        pfVar5 = pfVar5 + 8;
        iStack_24 = iStack_24 + -1;
      } while (iStack_24 != 0);
    }
  }
  return;
}



/* FUNCTION 10896 ; VA 0x007716b0 ; FUN_007716b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007716b0(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int *piVar14;
  char cVar15;
  int *piVar16;
  int iVar17;
  uint uVar18;
  int iVar19;
  uint uVar20;
  float *pfVar21;
  float *pfVar22;
  undefined *puVar23;
  undefined auVar24 [16];
  int *piVar25;
  int *piVar26;
  float fVar27;
  int *piVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  undefined8 uStack_90;
  int *piStack_88;
  int *piStack_84;
  int *piStack_80;
  int *piStack_7c;
  undefined auStack_70 [4];
  int aiStack_6c [4];
  undefined auStack_5c [4];
  int *piStack_58;
  undefined auStack_50 [4];
  int *piStack_4c;
  int iStack_48;
  int iStack_44;
  int *piStack_40;
  uint uStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  undefined *puStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  
  piVar16 = (int *)FUN_0076a000(auStack_50);
  iVar19 = *piVar16;
  iVar17 = piVar16[1];
  *piVar16 = 0;
  piVar16[1] = 0;
  param_1[2] = iVar19;
  piVar16 = (int *)param_1[3];
  param_1[3] = iVar17;
  if (piVar16 != (int *)0x0) {
    LOCK();
    iVar19 = piVar16[1] + -1;
    piVar16[1] = iVar19;
    UNLOCK();
    if (iVar19 == 0) {
      (**(code **)*piVar16)();
      LOCK();
      iVar19 = piVar16[2] + -1;
      piVar16[2] = iVar19;
      UNLOCK();
      if (iVar19 == 0) {
        (**(code **)(*piVar16 + 4))();
      }
    }
  }
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar19 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar19;
    UNLOCK();
    if (iVar19 == 0) {
      (**(code **)*piStack_4c)();
      LOCK();
      piVar16 = piStack_4c + 2;
      iVar19 = *piVar16;
      *piVar16 = *piVar16 + -1;
      UNLOCK();
      if (iVar19 == 1) {
        (**(code **)(*piStack_4c + 4))();
      }
    }
  }
  piStack_34 = DAT_018fb574;
  piStack_20 = DAT_018fb570;
  piVar16 = (int *)param_1[2];
  piVar16[9] = 0;
  piVar16[10] = 0x20;
  piStack_2c = (int *)*param_1;
  iStack_28 = *(int *)((int)piStack_2c + 8);
  iVar19 = (param_2[1] - *param_2) / 0x28;
  pfVar22 = (float *)*param_2;
  piStack_88 = piStack_20;
  piStack_38 = piStack_20;
  piStack_18 = piStack_34;
  piStack_30 = piStack_34;
  for (iVar17 = iVar19; iVar17 != 0; iVar17 = iVar17 + -1) {
    piVar28 = (int *)*pfVar22;
    piVar1 = (int *)pfVar22[1];
    piVar2 = (int *)pfVar22[2];
    piVar14 = piVar28;
    if ((float)piStack_38 <= (float)piVar28) {
      piVar14 = piStack_38;
    }
    if ((float)piVar28 <= (float)piStack_30) {
      piVar28 = piStack_30;
    }
    piVar26 = piVar1;
    if ((float)piVar1 <= (float)piStack_18) {
      piVar26 = piStack_18;
    }
    if ((float)piStack_20 <= (float)piVar1) {
      piVar1 = piStack_20;
    }
    piVar25 = piVar2;
    if ((float)piVar2 <= (float)piStack_34) {
      piVar25 = piStack_34;
    }
    if ((float)piStack_88 <= (float)piVar2) {
      piVar2 = piStack_88;
    }
    pfVar22 = pfVar22 + 10;
    piStack_20 = piVar1;
    piStack_88 = piVar2;
    piStack_38 = piVar14;
    piStack_34 = piVar25;
    piStack_18 = piVar26;
    piStack_30 = piVar28;
  }
  if ((float)piStack_30 - (float)piStack_38 < DAT_018f784c) {
    piStack_30 = (int *)((float)piStack_30 + DAT_018f784c);
  }
  if ((float)piStack_18 - (float)piStack_20 < DAT_018f784c) {
    piStack_18 = (int *)((float)piStack_18 + DAT_018f784c);
  }
  if ((float)piStack_34 - (float)piStack_88 < DAT_018f784c) {
    piStack_34 = (int *)((float)piStack_34 + DAT_018f784c);
  }
  uStack_90 = CONCAT44(piStack_20,piStack_38);
  *(int **)((int)piStack_2c + 0x168) = piStack_38;
  *(int **)((int)piStack_2c + 0x16c) = piStack_20;
  *(int **)((int)piStack_2c + 0x170) = piStack_88;
  *(int **)((int)piStack_2c + 0x174) = piStack_30;
  *(ulonglong *)((int)piStack_2c + 0x178) = CONCAT44(piStack_34,piStack_18);
  piStack_84 = piStack_30;
  piStack_80 = piStack_18;
  piStack_7c = piStack_34;
  piStack_58 = piStack_34;
  piStack_4c = piStack_88;
  piStack_1c = piVar16;
  piStack_14 = piStack_88;
  if (iStack_28 != 0xf) {
    if (iStack_28 != 0x10) {
      if (iStack_28 != 0x11) {
        return;
      }
      iVar19 = *(int *)(*param_1 + 0x24);
      iStack_28 = iVar19 * 3;
      puStack_24 = (undefined *)((param_2[iVar19 * 3 + 0x21] - param_2[iVar19 * 3 + 0x20]) / 0x28);
      piStack_2c = (int *)(((param_2[iVar19 * 3 + 0x45] - param_2[iVar19 * 3 + 0x44]) / 0xc) * 3);
      iStack_44 = iVar19;
      if ((DAT_01d71760 == '\0') && (cVar15 = FUN_01151c00(param_2), cVar15 != '\0')) {
        piStack_2c = (int *)(*(int *)(param_2[iStack_28 + 0x68] + 4) * 3);
      }
      piVar16 = piStack_1c;
      FUN_00715060((int)puStack_24 << 5,piStack_1c);
      FUN_00727cd0(piStack_2c,piVar16 + 6);
      piStack_4c = (int *)*piStack_1c;
      piStack_40 = (int *)piVar16[6];
      iStack_48 = param_2[iStack_28 + 0x20];
      uStack_3c = param_2[iStack_28 + 0x44];
      FUN_0076d540(piStack_4c,iStack_48,puStack_24,iVar19);
      uVar20 = 0;
      if (piStack_2c != (int *)0x0) {
        do {
          *(undefined2 *)((int)piStack_40 + uVar20 * 2) = *(undefined2 *)(uStack_3c + uVar20 * 4);
          uVar20 = uVar20 + 1;
          iVar19 = iStack_44;
        } while (uVar20 < piStack_2c);
      }
      piVar16 = piStack_1c + 3;
      FUN_00715060((int)puStack_24 * 0x18,piVar16);
      puVar23 = puStack_24;
      piStack_2c = (int *)*piVar16;
      FUN_0076d1b0(piStack_2c,iStack_48,puStack_24,iVar19);
      iVar19 = iVar19 * 0x20;
      if (puVar23 != (undefined *)0x0) {
        piStack_18 = (int *)((float)piStack_18 - (float)piStack_20);
        pfVar22 = (float *)((int)piStack_2c + 0x14);
        pfVar21 = (float *)(piStack_4c + 2);
        do {
          fVar30 = (pfVar21[-2] - (float)piStack_38) / ((float)piStack_30 - (float)piStack_38);
          fVar27 = (pfVar21[-1] - (float)piStack_20) / (float)piStack_18;
          fVar29 = (*pfVar21 - (float)piStack_14) / ((float)piStack_34 - (float)piStack_14);
          fVar31 = *(float *)(&DAT_018fac90 + iVar19) * fVar30 +
                   *(float *)(&DAT_018fac94 + iVar19) * fVar27 +
                   *(float *)(&DAT_018fac98 + iVar19) * fVar29 + *(float *)(&DAT_018fac9c + iVar19);
          pfVar21[2] = fVar31;
          pfVar21[3] = *(float *)(&DAT_018faca4 + iVar19) * fVar27 +
                       *(float *)(&DAT_018faca0 + iVar19) * fVar30 +
                       *(float *)(&DAT_018faca8 + iVar19) * fVar29 +
                       *(float *)(&DAT_018facac + iVar19);
          if (piStack_2c != (int *)0x0) {
            pfVar22[-1] = fVar31;
            *pfVar22 = pfVar21[3];
            pfVar22 = pfVar22 + 6;
          }
          pfVar21 = pfVar21 + 8;
          puVar23 = (undefined *)((int)puVar23 + -1);
        } while (puVar23 != (undefined *)0x0);
      }
      if (DAT_01d71760 == '\0') {
        return;
      }
      cVar15 = FUN_01151c00(param_2);
      if (cVar15 == '\0') {
        return;
      }
      puVar23 = (undefined *)param_2[iStack_28 + 0x68];
      uVar18 = param_2[iStack_28 + 0x69] - (int)puVar23 >> 2;
      uVar20 = 6;
      if (uVar18 < 7) {
        uVar20 = uVar18;
      }
      uVar18 = 0;
      if (uVar20 != 0) {
        if (((0xf < uVar20) && (1 < DAT_021137e0)) &&
           ((puVar23 + uVar20 * 4 + -4 < aiStack_6c || (auStack_70 + uVar20 * 4 < puVar23)))) {
          do {
            auVar24 = pmulld(*(undefined (*) [16])(puVar23 + uVar18 * 4),_DAT_018fb590);
            *(undefined (*) [16])(aiStack_6c + uVar18) = auVar24;
            auVar24 = pmulld(*(undefined (*) [16])(puVar23 + uVar18 * 4 + 0x10),_DAT_018fb590);
            *(undefined (*) [16])(auStack_5c + uVar18 * 4) = auVar24;
            auVar24 = pmulld(*(undefined (*) [16])(puVar23 + uVar18 * 4 + 0x20),_DAT_018fb590);
            *(undefined (*) [16])(&piStack_4c + uVar18) = auVar24;
            auVar24 = pmulld(*(undefined (*) [16])(puVar23 + uVar18 * 4 + 0x30),_DAT_018fb590);
            *(undefined (*) [16])(&uStack_3c + uVar18) = auVar24;
            uVar18 = uVar18 + 0x10;
          } while (uVar18 < (uVar20 & 0xfffffff0));
        }
        for (; uVar18 < uVar20; uVar18 = uVar18 + 1) {
          aiStack_6c[uVar18] = *(int *)(puVar23 + uVar18 * 4) * 3;
        }
      }
      if (DAT_01d71798 != '\0') {
        uVar18 = (uint)*(byte *)(param_2 + 0x1f);
        if (5 < *(byte *)(param_2 + 0x1f)) {
          uVar18 = 5;
        }
        *(uint *)(*param_1 + 0x164) = uVar18;
      }
      FUN_0076d750(param_1,aiStack_6c,uVar20);
      return;
    }
    if (DAT_01d60c30 != '\0') {
      iVar19 = 0;
    }
    piStack_38 = param_2 + 0x20;
    iVar17 = param_2[0x45];
    iVar3 = param_2[0x44];
    iVar4 = param_2[0x48];
    iVar5 = param_2[0x47];
    iVar6 = param_2[0x4b];
    iVar7 = param_2[0x4a];
    iVar8 = param_2[0x4e];
    iVar9 = param_2[0x4d];
    iVar10 = param_2[0x51];
    iVar11 = param_2[0x50];
    iVar12 = param_2[0x54];
    iVar13 = param_2[0x53];
    piStack_14 = (int *)(iVar19 + (param_2[0x21] - *piStack_38) / 0x28 +
                         (param_2[0x24] - param_2[0x23]) / 0x28 +
                         (param_2[0x27] - param_2[0x26]) / 0x28 +
                         (param_2[0x2a] - param_2[0x29]) / 0x28 +
                         (param_2[0x2d] - param_2[0x2c]) / 0x28 +
                        (param_2[0x30] - param_2[0x2f]) / 0x28);
    FUN_00715060((int)piStack_14 * 0x20,piVar16);
    piStack_30 = (int *)*piVar16;
    piVar16 = piVar16 + 6;
    piStack_2c = piVar16;
    FUN_00727cd0(((iVar12 - iVar13) / 0xc) * 3 +
                 ((iVar10 - iVar11) / 0xc) * 3 +
                 ((iVar8 - iVar9) / 0xc) * 3 +
                 ((iVar6 - iVar7) / 0xc) * 3 +
                 ((iVar4 - iVar5) / 0xc) * 3 + ((iVar17 - iVar3) / 0xc) * 3,piVar16);
    piStack_18 = (int *)*piVar16;
    piVar16 = piStack_1c + 3;
    FUN_00715060((int)piStack_14 * 0x18,piVar16);
    piStack_1c = (int *)*piVar16;
    if ((DAT_01d71760 == '\0') || (cVar15 = FUN_01151c00(param_2), cVar15 == '\0')) {
      iStack_28 = 6;
      iVar19 = 0;
      piStack_20 = (int *)0x0;
      param_2 = param_2 + 0x21;
      piStack_2c = (int *)&DAT_018fad50;
      do {
        if ((DAT_01d60c38 == '\0') ||
           (iVar17 = *param_2 - param_2[-1] >> 0x1f,
           (*param_2 - param_2[-1]) / 0x28 + iVar17 != iVar17)) {
          piStack_38 = (int *)param_2[-1];
          piStack_34 = param_2;
          FUN_0076d270(piStack_30 + iVar19 * 8,piStack_38,(*param_2 - (int)piStack_38) / 0x28,
                       piStack_20,piStack_2c);
          if (piStack_1c != (int *)0x0) {
            FUN_0076d1b0((int)piStack_1c + iVar19 * 0x18,piStack_38,(*param_2 - param_2[-1]) / 0x28,
                         piStack_20);
          }
          iVar17 = param_2[0x23];
          piVar16 = (int *)0x0;
          piStack_40 = (int *)(((param_2[0x24] - iVar17) / 0xc) * 3);
          if (piStack_40 != (int *)0x0) {
            do {
              *(short *)((int)piStack_18 + (int)piVar16 * 2) =
                   *(short *)(iVar17 + (int)piVar16 * 4) + (short)iVar19;
              piVar16 = (int *)((int)piVar16 + 1);
            } while (piVar16 < piStack_40);
            iVar17 = piStack_34[0x23];
            param_2 = piStack_34;
          }
          piStack_18 = (int *)((int)piStack_18 + ((param_2[0x24] - iVar17) / 0xc) * 6);
          iVar19 = iVar19 + (*param_2 - param_2[-1]) / 0x28;
        }
        param_2 = param_2 + 3;
        piStack_20 = (int *)((int)piStack_20 + 1);
        piStack_2c = (int *)((int)piStack_2c + 0xc);
        iStack_28 = iStack_28 + -1;
      } while (iStack_28 != 0);
      return;
    }
    iVar19 = 0;
    iStack_28 = 0;
    piStack_20 = (int *)0x0;
    puStack_24 = &DAT_018fad50;
    piStack_34 = (int *)0x6;
    piVar16 = piStack_38;
    do {
      if ((DAT_01d60c38 == '\0') ||
         (iVar17 = piVar16[1] - *piVar16 >> 0x1f, (piVar16[1] - *piVar16) / 0x28 + iVar17 != iVar17)
         ) {
        piStack_38 = (int *)*piVar16;
        FUN_0076d270(piStack_30 + iVar19 * 8,piStack_38,(piVar16[1] - (int)piStack_38) / 0x28,
                     piStack_20,puStack_24);
        if (piStack_1c != (int *)0x0) {
          FUN_0076d1b0((int)piStack_1c + iVar19 * 0x18,piStack_38,(piVar16[1] - *piVar16) / 0x28,
                       piStack_20);
        }
        iVar19 = iStack_28 + (piVar16[1] - *piVar16) / 0x28;
        iStack_28 = iVar19;
      }
      piVar16 = piVar16 + 3;
      piStack_20 = (int *)((int)piStack_20 + 1);
      puStack_24 = puStack_24 + 0xc;
      piStack_34 = (int *)((int)piStack_34 + -1);
    } while (piStack_34 != (int *)0x0);
    uStack_90 = uStack_90 & 0xffffffff00000000;
    piStack_20 = (int *)0x1;
    uVar18 = param_2[0x1a] - param_2[0x19] >> 2;
    uVar20 = 6;
    if (uVar18 < 7) {
      uVar20 = uVar18;
    }
    piStack_34 = (int *)0x0;
    uStack_3c = uVar20;
    if (1 < uVar20) {
      piStack_40 = param_2 + 0x68;
      piStack_14 = (int *)0x0;
      do {
        uVar20 = uStack_3c;
        iVar19 = 0;
        piStack_1c = (int *)0x0;
        if (DAT_01d60c38 == '\0') {
          iStack_28 = 6;
          piStack_30 = piStack_40;
          do {
            iVar19 = *(int *)((int)piStack_14 + *piStack_30);
            piStack_34 = (int *)(*(int *)(*piStack_30 + (int)piStack_20 * 4) - iVar19);
            puStack_24 = (undefined *)(piStack_30[-0x24] + iVar19 * 0xc);
            piStack_38 = (int *)((int)piStack_34 * 3);
            piVar16 = (int *)0x0;
            if (piStack_38 != (int *)0x0) {
              do {
                *(short *)((int)piStack_18 + (int)piVar16 * 2) =
                     *(short *)(puStack_24 + (int)piVar16 * 4) + (short)piStack_1c;
                piVar16 = (int *)((int)piVar16 + 1);
              } while (piVar16 < piStack_38);
            }
            piVar16 = piStack_30 + -0x47;
            piVar28 = piStack_30 + -0x48;
            piStack_18 = (int *)((int)piStack_18 + (int)piStack_34 * 6);
            piStack_30 = piStack_30 + 3;
            piStack_1c = (int *)((int)piStack_1c + (*piVar16 - *piVar28) / 0x28);
            iStack_28 = iStack_28 + -1;
          } while (iStack_28 != 0);
          iStack_28 = 0;
        }
        else {
          piStack_34 = (int *)0x6;
          piStack_38 = piStack_40;
          do {
            iVar17 = *(int *)((int)piStack_14 + *piStack_38);
            puStack_24 = (undefined *)(*(int *)(*piStack_38 + (int)piStack_20 * 4) - iVar17);
            if (puStack_24 != (undefined *)0x0) {
              iStack_28 = piStack_38[-0x24] + iVar17 * 0xc;
              piVar16 = (int *)0x0;
              piStack_30 = (int *)((int)puStack_24 * 3);
              if (piStack_30 != (int *)0x0) {
                do {
                  *(short *)((int)piStack_18 + (int)piVar16 * 2) =
                       *(short *)(iStack_28 + (int)piVar16 * 4) + (short)iVar19;
                  piVar16 = (int *)((int)piVar16 + 1);
                } while (piVar16 < piStack_30);
              }
              piStack_18 = (int *)((int)piStack_18 + (int)puStack_24 * 6);
              iVar19 = (int)piStack_1c + (piStack_38[-0x47] - piStack_38[-0x48]) / 0x28;
              piStack_1c = (int *)iVar19;
            }
            piStack_38 = piStack_38 + 3;
            piStack_34 = (int *)((int)piStack_34 + -1);
          } while (piStack_34 != (int *)0x0);
          piStack_34 = (int *)0x0;
        }
        *(int *)((int)&uStack_90 + (int)piStack_14 + 4) = (int)piStack_18 - *piStack_2c >> 1;
        piStack_14 = (int *)((int)piStack_14 + 4);
        piStack_20 = (int *)((int)piStack_20 + 1);
      } while (piStack_20 < uVar20);
    }
    if (DAT_01d71798 != '\0') {
      uVar18 = (uint)*(byte *)(param_2 + 0x1f);
      if (5 < *(byte *)(param_2 + 0x1f)) {
        uVar18 = 5;
      }
      *(uint *)(*param_1 + 0x164) = uVar18;
      FUN_0076d750(param_1,&uStack_90,uVar20);
      return;
    }
    FUN_0076d750(param_1,&uStack_90,uVar20);
    return;
  }
  piStack_38 = (int *)*param_2;
  piStack_18 = (int *)((param_2[1] - (int)piStack_38) / 0x28);
  if ((DAT_01d71760 == '\0') && (cVar15 = FUN_01151c00(param_2), cVar15 != '\0')) {
    piStack_18 = (int *)FUN_01151ea0(param_2);
  }
  piVar16 = piStack_1c;
  FUN_00715060((int)piStack_18 << 5,piStack_1c);
  FUN_0076d540(*piVar16,piStack_38,piStack_18,2);
  piVar16 = piVar16 + 3;
  FUN_00715060((int)piStack_18 * 0x18,piVar16);
  FUN_0076d1b0(*piVar16,piStack_38,piStack_18,2);
  piStack_34 = (int *)param_2[6];
  if (DAT_01d71760 == '\0') {
    cVar15 = FUN_01151c00(param_2);
    if (cVar15 != '\0') {
      iVar19 = *(int *)(param_2[0x19] + 4);
      goto LAB_007719a5;
    }
    iVar19 = param_2[7] - param_2[6];
  }
  else {
    iVar19 = param_2[7] - (int)piStack_34;
  }
  iVar19 = iVar19 / 0xc;
LAB_007719a5:
  piStack_38 = (int *)(iVar19 * 3);
  piVar16 = piStack_1c + 6;
  FUN_00727cd0(piStack_38,piVar16);
  uVar20 = 0;
  iVar19 = *piVar16;
  if (piStack_38 != (int *)0x0) {
    do {
      *(undefined2 *)(iVar19 + uVar20 * 2) = *(undefined2 *)((int)piStack_34 + uVar20 * 4);
      uVar20 = uVar20 + 1;
    } while (uVar20 < piStack_38);
  }
  if ((DAT_01d71760 == '\0') || (cVar15 = FUN_01151c00(param_2), cVar15 == '\0')) {
    return;
  }
  puVar23 = (undefined *)param_2[0x19];
  uVar18 = param_2[0x1a] - (int)puVar23 >> 2;
  uVar20 = 6;
  if (uVar18 < 7) {
    uVar20 = uVar18;
  }
  uVar18 = 0;
  if (uVar20 != 0) {
    if (((0xf < uVar20) && (1 < DAT_021137e0)) &&
       ((puVar23 + (uVar20 - 1) * 4 < aiStack_6c || (auStack_70 + uVar20 * 4 < puVar23)))) {
      do {
        auVar24 = pmulld(*(undefined (*) [16])(puVar23 + uVar18 * 4),_DAT_018fb590);
        *(undefined (*) [16])(aiStack_6c + uVar18) = auVar24;
        auVar24 = pmulld(*(undefined (*) [16])(puVar23 + uVar18 * 4 + 0x10),_DAT_018fb590);
        *(undefined (*) [16])(auStack_5c + uVar18 * 4) = auVar24;
        auVar24 = pmulld(*(undefined (*) [16])(puVar23 + uVar18 * 4 + 0x20),_DAT_018fb590);
        *(undefined (*) [16])(&piStack_4c + uVar18) = auVar24;
        auVar24 = pmulld(*(undefined (*) [16])(puVar23 + uVar18 * 4 + 0x30),_DAT_018fb590);
        *(undefined (*) [16])(&uStack_3c + uVar18) = auVar24;
        uVar18 = uVar18 + 0x10;
      } while (uVar18 < (uVar20 & 0xfffffff0));
    }
    for (; uVar18 < uVar20; uVar18 = uVar18 + 1) {
      aiStack_6c[uVar18] = *(int *)(puVar23 + uVar18 * 4) * 3;
    }
  }
  if (DAT_01d71798 != '\0') {
    uVar18 = (uint)*(byte *)(param_2 + 0x1f);
    if (5 < *(byte *)(param_2 + 0x1f)) {
      uVar18 = 5;
    }
    *(uint *)(*param_1 + 0x164) = uVar18;
    FUN_0076d750(param_1,aiStack_6c,uVar20);
    return;
  }
  FUN_0076d750(param_1,aiStack_6c,uVar20);
  return;
}



/* FUNCTION 10897 ; VA 0x007724c0 ; FUN_007724c0 */

/* WARNING: Removing unreachable block (ram,0x007725df) */
/* WARNING: Removing unreachable block (ram,0x007725e9) */
/* WARNING: Removing unreachable block (ram,0x007725f9) */
/* WARNING: Removing unreachable block (ram,0x00772600) */
/* WARNING: Removing unreachable block (ram,0x00772636) */
/* WARNING: Removing unreachable block (ram,0x00772640) */
/* WARNING: Removing unreachable block (ram,0x00772650) */

void __fastcall FUN_007724c0(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  undefined *puVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 uVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  int *piVar11;
  undefined8 uVar12;
  int *piStack_fc;
  int *piStack_e4;
  undefined auStack_c8 [4];
  int *piStack_c4;
  undefined auStack_c0 [4];
  int *piStack_bc;
  int *piStack_b8;
  int *piStack_b4;
  int *piStack_b0;
  int *piStack_ac;
  int *piStack_a8;
  int *piStack_a0;
  int iStack_9c;
  int *piStack_98;
  int iStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined8 uStack_88;
  undefined4 uStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  int *piStack_70;
  int *piStack_6c;
  int *piStack_68;
  int *piStack_64;
  int iStack_60;
  int *piStack_5c;
  uint uStack_58;
  uint uStack_54;
  int iStack_50;
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int iStack_34;
  int *piStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af08f;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffef4;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  puVar3 = &stack0xfffffef4;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1a98) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb1a98), puVar3 = puStack_14,
     DAT_01eb1a98 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","MeshManager::processPendingRequests",0xffffffff);
    DAT_01eb1a94 = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb1a90 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb1a98);
    puVar3 = puStack_14;
  }
  puStack_14 = puVar3;
  uStack_90 = DAT_01eb1a90;
  uStack_8c = DAT_01eb1a94;
  uStack_88 = FUN_0152d930(DAT_01eb1a90,DAT_01eb1a94);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_80 = FUN_01675290(DAT_01eb2f54);
  uStack_58 = 2;
  if (*(char *)(*(int *)(*param_1 + 0x510) + 0x2c) != '\0') {
    uStack_58 = 0x18894;
  }
  uStack_54 = 0;
  do {
    if (uStack_58 <= uStack_54) {
LAB_00772dc1:
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      FUN_01675290(uStack_80);
      uStack_8 = 0xc;
      FUN_0152dda0(uStack_90,uStack_8c,uStack_88);
      ExceptionList = pvStack_10;
      return;
    }
    iStack_50 = 0;
    piStack_4c = (int *)0x0;
    piStack_48 = (int *)0x0;
    piStack_44 = (int *)0x0;
    piVar4 = (int *)param_1[7];
    puVar1 = (uint *)(piVar4 + 5);
    do {
      LOCK();
      uVar8 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar8 & 1) != 0);
    if (piVar4[4] == 0) {
      *puVar1 = 0;
      FUN_0056b650();
      goto LAB_00772dc1;
    }
    puVar5 = (undefined4 *)*piVar4;
    if (puVar5 != (undefined4 *)0x0) {
      puVar5 = (undefined4 *)*puVar5;
    }
    piVar11 = *(int **)(puVar5[1] + (puVar5[2] - 1 & piVar4[3]) * 4);
    piStack_a8 = (int *)piVar11[1];
    if (piStack_a8 != (int *)0x0) {
      LOCK();
      piStack_a8[1] = piStack_a8[1] + 1;
      UNLOCK();
      piStack_a8 = (int *)piVar11[1];
    }
    iStack_7c = *piVar11;
    piStack_b0 = (int *)piVar11[3];
    if (piStack_b0 != (int *)0x0) {
      LOCK();
      piStack_b0[1] = piStack_b0[1] + 1;
      UNLOCK();
      piStack_b0 = (int *)piVar11[3];
    }
    piStack_ac = (int *)piVar11[2];
    iStack_50 = iStack_7c;
    piStack_4c = piStack_a8;
    piStack_48 = piStack_ac;
    piStack_44 = piStack_b0;
    piStack_40 = piStack_a8;
    piStack_24 = piStack_b0;
    piStack_20 = piStack_ac;
    iStack_18 = iStack_7c;
    FUN_0056b650();
    iVar10 = iStack_18;
    piVar2 = piStack_20;
    piVar11 = piVar4 + 4;
    *piVar11 = *piVar11 + -1;
    if (*piVar11 == 0) {
      piVar4[3] = 0;
    }
    else {
      piVar4[3] = piVar4[3] + 1;
    }
    *puVar1 = 0;
    uStack_8._0_1_ = 4;
    iVar9 = piStack_20[1] - *piStack_20;
    piVar4 = *(int **)(*piStack_1c + 0x3c);
    iStack_2c = piStack_20[4] - piStack_20[3];
    iStack_78 = iVar9;
    if (iVar9 == 0) {
      if (DAT_01eb18d8 != '\0') {
        piVar4 = (int *)(iStack_18 + 0xc);
        if (0xf < *(uint *)(iStack_18 + 0x20)) {
          piVar4 = (int *)*piVar4;
        }
        FUN_01677520(DAT_01eb18d8,"Mesh manager: \'%s\' - bad vertex data",piVar4);
      }
      piVar4 = piStack_24;
      LOCK();
      *(undefined4 *)(iVar10 + 4) = 5;
      UNLOCK();
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_24[1] + -1;
        piStack_24[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar11 = piVar4 + 2;
          iVar10 = *piVar11 + -1;
          *piVar11 = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar4 = piStack_40;
      if (piStack_40 == (int *)0x0) goto LAB_00772da4;
      LOCK();
      iVar10 = piStack_40[1] + -1;
      piStack_40[1] = iVar10;
      UNLOCK();
      if (iVar10 != 0) goto LAB_00772da4;
      (**(code **)*piStack_40)();
      LOCK();
      piVar11 = piVar4 + 2;
      iVar10 = *piVar11 + -1;
      *piVar11 = iVar10;
      UNLOCK();
      if (iVar10 != 0) goto LAB_00772da4;
      (**(code **)(*piVar4 + 4))();
      uStack_54 = uStack_54 + 1;
      param_1 = piStack_1c;
    }
    else {
      (**(code **)(*piVar4 + 0x3c))(&piStack_70,0,iVar9,piStack_20[10],0);
      uStack_8._0_1_ = 5;
      (**(code **)(*piStack_70 + 0x18))(0,*piVar2,iVar9);
      piStack_20 = (int *)(iStack_18 + 0xc);
      (**(code **)(*piStack_70 + 0xc))(piStack_20);
      piStack_3c = (int *)0x0;
      piStack_38 = (int *)0x0;
      uStack_8._0_1_ = 6;
      if (iStack_2c != 0) {
        puVar5 = (undefined4 *)(**(code **)(*piVar4 + 0x3c))(auStack_c0,0,iStack_2c,0x18,0);
        piVar11 = piStack_38;
        piStack_b4 = (int *)*puVar5;
        piStack_b8 = (int *)puVar5[1];
        *puVar5 = 0;
        puVar5[1] = 0;
        piStack_3c = piStack_b4;
        piVar6 = piStack_b8;
        if (piStack_38 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_38[1] + -1;
          piStack_38[1] = iVar10;
          UNLOCK();
          piVar6 = piStack_b8;
          if (iVar10 == 0) {
            puVar5 = (undefined4 *)*piStack_38;
            piStack_38 = piStack_b8;
            (*(code *)*puVar5)();
            LOCK();
            piVar6 = piVar11 + 2;
            iVar10 = *piVar6 + -1;
            *piVar6 = iVar10;
            UNLOCK();
            piVar6 = piStack_38;
            if (iVar10 == 0) {
              (**(code **)(*piVar11 + 4))();
              piVar6 = piStack_38;
            }
          }
        }
        piStack_38 = piVar6;
        piVar11 = piStack_bc;
        if (piStack_bc != (int *)0x0) {
          LOCK();
          iVar10 = piStack_bc[1] + -1;
          piStack_bc[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_bc)();
            LOCK();
            piVar6 = piVar11 + 2;
            iVar10 = *piVar6 + -1;
            *piVar6 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar11 + 4))();
            }
          }
        }
        (**(code **)(*piStack_3c + 0x18))(0,piVar2[3],iStack_2c);
        (**(code **)(*piStack_3c + 0xc))(piStack_20);
      }
      iVar10 = piVar2[7] - piVar2[6] >> 1;
      iStack_74 = iVar10 * 2;
      iStack_28 = iVar10;
      if (iStack_74 == 0) {
        if (DAT_01eb18d8 != '\0') {
          piVar4 = piStack_20;
          if (0xf < (uint)piStack_20[5]) {
            piVar4 = (int *)*piStack_20;
          }
          FUN_01677520(DAT_01eb18d8,"Mesh manager: \'%s\' - bad index data",piVar4);
        }
        piVar4 = piStack_38;
        LOCK();
        *(undefined4 *)(iStack_18 + 4) = 5;
        UNLOCK();
        if (piStack_38 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_38[1] + -1;
          piStack_38[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_38)();
            LOCK();
            piVar11 = piVar4 + 2;
            iVar10 = *piVar11 + -1;
            *piVar11 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        piVar4 = piStack_6c;
        if (piStack_6c != (int *)0x0) {
          LOCK();
          iVar10 = piStack_6c[1] + -1;
          piStack_6c[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_6c)();
            LOCK();
            piVar11 = piVar4 + 2;
            iVar10 = *piVar11 + -1;
            *piVar11 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        FUN_0056b650();
        uStack_54 = uStack_54 + 1;
        param_1 = piStack_1c;
      }
      else {
        (**(code **)(*piVar4 + 0x3c))(&piStack_68,1,iStack_74,2,0);
        uStack_8._0_1_ = 7;
        (**(code **)(*piStack_68 + 0x18))(0,piVar2[6],iVar10 * 2);
        (**(code **)(*piStack_68 + 0xc))(piStack_20);
        piVar4 = piStack_1c;
        FUN_0147c0e0(&iStack_60,piStack_1c + piVar2[9] * 2 + 0x25,&piStack_70,&piStack_68);
        iStack_34 = 0;
        piStack_30 = (int *)0x0;
        uStack_8 = CONCAT31(uStack_8._1_3_,9);
        if (iStack_2c != 0) {
          piVar6 = (int *)FUN_0147c0e0(auStack_c8,piVar4 + 0x2b,&piStack_3c,&piStack_68);
          piVar2 = piStack_30;
          iStack_34 = *piVar6;
          piVar11 = (int *)piVar6[1];
          *piVar6 = 0;
          piVar6[1] = 0;
          if (piStack_30 != (int *)0x0) {
            LOCK();
            iVar10 = piStack_30[1] + -1;
            piStack_30[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              puVar5 = (undefined4 *)*piStack_30;
              piStack_30 = piVar11;
              (*(code *)*puVar5)();
              LOCK();
              piVar11 = piVar2 + 2;
              iVar10 = *piVar11 + -1;
              *piVar11 = iVar10;
              UNLOCK();
              piVar11 = piStack_30;
              if (iVar10 == 0) {
                (**(code **)(*piVar2 + 4))();
                piVar11 = piStack_30;
              }
            }
          }
          piStack_30 = piVar11;
          piVar11 = piStack_c4;
          iVar10 = iStack_28;
          if (piStack_c4 != (int *)0x0) {
            LOCK();
            iVar9 = piStack_c4[1] + -1;
            piStack_c4[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)*piStack_c4)();
              LOCK();
              piVar2 = piVar11 + 2;
              iVar9 = *piVar2 + -1;
              *piVar2 = iVar9;
              UNLOCK();
              iVar10 = iStack_28;
              if (iVar9 == 0) {
                (**(code **)(*piVar11 + 4))();
                iVar10 = iStack_28;
              }
            }
          }
        }
        iVar9 = iStack_18;
        if (*(uint *)(iStack_18 + 0x15c) < 2) {
          uVar7 = FUN_0147c720(&iStack_60,0,0,0,iVar10);
          FUN_0076b300(uVar7);
          if (piStack_e4 != (int *)0x0) {
            LOCK();
            iVar10 = piStack_e4[1] + -1;
            piStack_e4[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piStack_e4)();
              LOCK();
              iVar10 = piStack_e4[2] + -1;
              piStack_e4[2] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piStack_e4 + 4))();
              }
            }
          }
          uVar7 = FUN_0147c720(&iStack_34,0,0,0,iStack_28);
          FUN_0076b300(uVar7);
          if (piStack_fc != (int *)0x0) {
            LOCK();
            iVar10 = piStack_fc[1] + -1;
            piStack_fc[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piStack_fc)();
              LOCK();
              iVar10 = piStack_fc[2] + -1;
              piStack_fc[2] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piStack_fc + 4))();
              }
            }
          }
        }
        else {
          uVar8 = 0;
          piVar4 = piStack_1c;
          if (*(uint *)(iStack_18 + 0x15c) != 0) {
            piVar11 = (int *)(iStack_18 + 0xe8);
            do {
              if (piStack_5c != (int *)0x0) {
                LOCK();
                piStack_5c[1] = piStack_5c[1] + 1;
                UNLOCK();
              }
              piVar11[-0x1f] = iStack_60;
              piVar4 = (int *)piVar11[-0x1e];
              iStack_94 = iStack_60;
              piStack_98 = piStack_5c;
              piVar11[-0x1e] = (int)piStack_5c;
              if (piVar4 != (int *)0x0) {
                LOCK();
                iVar10 = piVar4[1] + -1;
                piVar4[1] = iVar10;
                UNLOCK();
                if (iVar10 == 0) {
                  (**(code **)*piVar4)();
                  LOCK();
                  iVar10 = piVar4[2] + -1;
                  piVar4[2] = iVar10;
                  UNLOCK();
                  if (iVar10 == 0) {
                    (**(code **)(*piVar4 + 4))();
                  }
                }
              }
              if (piStack_30 != (int *)0x0) {
                LOCK();
                piStack_30[1] = piStack_30[1] + 1;
                UNLOCK();
              }
              piVar11[-1] = iStack_34;
              piVar4 = (int *)*piVar11;
              iStack_9c = iStack_34;
              piStack_a0 = piStack_30;
              *piVar11 = (int)piStack_30;
              if (piVar4 != (int *)0x0) {
                LOCK();
                iVar10 = piVar4[1] + -1;
                piVar4[1] = iVar10;
                UNLOCK();
                if (iVar10 == 0) {
                  (**(code **)*piVar4)();
                  LOCK();
                  iVar10 = piVar4[2] + -1;
                  piVar4[2] = iVar10;
                  UNLOCK();
                  if (iVar10 == 0) {
                    (**(code **)(*piVar4 + 4))();
                  }
                }
              }
              uVar8 = uVar8 + 1;
              piVar11 = piVar11 + 6;
              piVar4 = piStack_1c;
              iVar9 = iStack_18;
            } while (uVar8 < *(uint *)(iStack_18 + 0x15c));
          }
        }
        iVar10 = iStack_74 + iStack_2c + iStack_78;
        *(int *)(iVar9 + 0x180) = iVar10;
        uVar8 = piVar4[10] + iVar10;
        piVar4[10] = uVar8;
        if (DAT_01eb18d8 != '\0') {
          piVar11 = piStack_20;
          if (0xf < (uint)piStack_20[5]) {
            piVar11 = (int *)*piStack_20;
          }
          FUN_01677520(DAT_01eb18d8,"Mesh manager: uploaded \'%s\' (mem %u / %u kb)",piVar11,
                       uVar8 >> 10,(uint)piVar4[9] >> 10);
          piVar4 = piStack_1c;
        }
        if (*(int *)(iVar9 + 8) == 0x13) {
          piVar11 = (int *)(*(int *)(*piVar4 + 0x524) + 0x90);
          *piVar11 = *piVar11 + 1;
          piVar11 = (int *)(*(int *)(*piVar4 + 0x524) + 0x94);
          *piVar11 = *piVar11 + *(int *)(iVar9 + 0x180);
        }
        LOCK();
        *(undefined4 *)(iVar9 + 4) = 4;
        UNLOCK();
        piVar11 = (int *)piVar4[0x3a];
        if ((int *)piVar4[0x3b] == piVar11) {
          FUN_005c1970(piVar11,&iStack_50);
          piVar4 = piStack_4c;
          piVar11 = piStack_44;
        }
        else {
          *piVar11 = 0;
          piVar11[1] = 0;
          if (piStack_40 != (int *)0x0) {
            LOCK();
            piStack_40[1] = piStack_40[1] + 1;
            UNLOCK();
          }
          *piVar11 = iVar9;
          piVar11[1] = (int)piStack_40;
          piVar4[0x3a] = piVar4[0x3a] + 8;
          piVar4 = piStack_40;
          piVar11 = piStack_24;
        }
        piVar2 = piStack_30;
        if (piStack_30 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_30[1] + -1;
          piStack_30[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_30)();
            LOCK();
            piVar6 = piVar2 + 2;
            iVar10 = *piVar6 + -1;
            *piVar6 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = piStack_5c;
        if (piStack_5c != (int *)0x0) {
          LOCK();
          iVar10 = piStack_5c[1] + -1;
          piStack_5c[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_5c)();
            LOCK();
            piVar6 = piVar2 + 2;
            iVar10 = *piVar6 + -1;
            *piVar6 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = piStack_64;
        if (piStack_64 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_64[1] + -1;
          piStack_64[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_64)();
            LOCK();
            piVar6 = piVar2 + 2;
            iVar10 = *piVar6 + -1;
            *piVar6 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = piStack_38;
        if (piStack_38 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_38[1] + -1;
          piStack_38[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_38)();
            LOCK();
            piVar6 = piVar2 + 2;
            iVar10 = *piVar6 + -1;
            *piVar6 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = piStack_6c;
        if (piStack_6c != (int *)0x0) {
          LOCK();
          iVar10 = piStack_6c[1] + -1;
          piStack_6c[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_6c)();
            LOCK();
            piVar6 = piVar2 + 2;
            iVar10 = *piVar6 + -1;
            *piVar6 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar2 + 4))();
              FUN_00772d53();
              return;
            }
          }
        }
        uStack_8._0_1_ = 3;
        uStack_8._1_3_ = 0;
        if (piVar11 != (int *)0x0) {
          LOCK();
          iVar10 = piVar11[1] + -1;
          piVar11[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar11)();
            LOCK();
            iVar10 = piVar11[2] + -1;
            piVar11[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar11 + 4))();
            }
          }
        }
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar10 = piVar4[1] + -1;
          piVar4[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar10 = piVar4[2] + -1;
            piVar4[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
LAB_00772da4:
        uStack_54 = uStack_54 + 1;
        param_1 = piStack_1c;
      }
    }
  } while( true );
}



/* FUNCTION 10898 ; VA 0x00772d0e ; Catch@00772d0e */

undefined * Catch_00772d0e(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int unaff_EBP;
  
  if (DAT_01eb18d8 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0xa0) + 4))();
    puVar2 = (undefined4 *)(*(int *)(unaff_EBP + -0x78) + 0xc);
    if (0xf < *(uint *)(*(int *)(unaff_EBP + -0x78) + 0x20)) {
      puVar2 = (undefined4 *)*puVar2;
    }
    FUN_01677520(DAT_01eb18d8,"Mesh manager: \'%s\' upload FAILED with \'%s\'",puVar2,uVar1);
  }
  return &DAT_00772d4d;
}



/* FUNCTION 10899 ; VA 0x00772d53 ; FUN_00772d53 */

void FUN_00772d53(void)

{
  uint *puVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  int *unaff_EBX;
  int unaff_EBP;
  int iVar9;
  int iVar10;
  int *piVar11;
  int *unaff_EDI;
  
  do {
    *(undefined4 *)(unaff_EBP + -4) = 3;
    if (unaff_EDI != (int *)0x0) {
      LOCK();
      iVar10 = unaff_EDI[1] + -1;
      unaff_EDI[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*unaff_EDI)();
        LOCK();
        iVar10 = unaff_EDI[2] + -1;
        unaff_EDI[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*unaff_EDI + 4))();
        }
      }
    }
    if (unaff_EBX != (int *)0x0) {
      LOCK();
      iVar10 = unaff_EBX[1] + -1;
      unaff_EBX[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*unaff_EBX)();
        LOCK();
        iVar10 = unaff_EBX[2] + -1;
        unaff_EBX[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*unaff_EBX + 4))();
        }
      }
    }
LAB_00772da4:
    iVar10 = *(int *)(unaff_EBP + -0x18);
    uVar6 = *(int *)(unaff_EBP + -0x50) + 1;
    uVar7 = *(uint *)(unaff_EBP + -0x54);
LAB_00772567:
    *(uint *)(unaff_EBP + -0x50) = uVar6;
    if (uVar7 <= uVar6) {
LAB_00772dc1:
      *(undefined *)(unaff_EBP + -4) = 0xb;
      FUN_01675290(*(undefined4 *)(unaff_EBP + -0x7c));
      *(undefined4 *)(unaff_EBP + -4) = 0xc;
      FUN_0152dda0(*(undefined4 *)(unaff_EBP + -0x8c),*(undefined4 *)(unaff_EBP + -0x88),
                   *(undefined4 *)(unaff_EBP + -0x84),*(undefined4 *)(unaff_EBP + -0x80));
      ExceptionList = *(void **)(unaff_EBP + -0xc);
      return;
    }
    *(undefined4 *)(unaff_EBP + -0x4c) = 0;
    *(undefined4 *)(unaff_EBP + -0x48) = 0;
    *(undefined4 *)(unaff_EBP + -0x44) = 0;
    *(undefined4 *)(unaff_EBP + -0x40) = 0;
    piVar11 = *(int **)(iVar10 + 0x1c);
    puVar1 = (uint *)(piVar11 + 5);
    do {
      LOCK();
      uVar7 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar7 & 1) != 0);
    if (piVar11[4] == 0) {
      *puVar1 = 0;
      FUN_0056b650();
      goto LAB_00772dc1;
    }
    puVar4 = (undefined4 *)*piVar11;
    if (puVar4 != (undefined4 *)0x0) {
      puVar4 = (undefined4 *)*puVar4;
    }
    puVar4 = *(undefined4 **)(puVar4[1] + (puVar4[2] - 1 & piVar11[3]) * 4);
    *(undefined4 **)(unaff_EBP + -0x20) = puVar4;
    iVar10 = puVar4[1];
    *(int *)(unaff_EBP + -0x3c) = iVar10;
    if (iVar10 != 0) {
      LOCK();
      *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + 1;
      UNLOCK();
      iVar10 = puVar4[1];
      *(int *)(unaff_EBP + -0x3c) = iVar10;
    }
    uVar5 = *puVar4;
    piVar8 = *(int **)(unaff_EBP + -0x48);
    *(undefined4 *)(unaff_EBP + -0x14) = uVar5;
    *(undefined4 *)(unaff_EBP + -0x78) = uVar5;
    *(undefined4 *)(unaff_EBP + -0x4c) = uVar5;
    *(int *)(unaff_EBP + -0xa4) = iVar10;
    *(int *)(unaff_EBP + -0x48) = iVar10;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar10 = piVar8[1] + -1;
      piVar8[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar10 = piVar8[2] + -1;
        piVar8[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
        puVar4 = *(undefined4 **)(unaff_EBP + -0x20);
      }
    }
    iVar10 = puVar4[3];
    *(int *)(unaff_EBP + -0x20) = iVar10;
    if (iVar10 != 0) {
      LOCK();
      *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + 1;
      UNLOCK();
      iVar10 = puVar4[3];
      *(int *)(unaff_EBP + -0x20) = iVar10;
    }
    uVar5 = puVar4[2];
    piVar8 = *(int **)(unaff_EBP + -0x40);
    *(undefined4 *)(unaff_EBP + -0x1c) = uVar5;
    *(undefined4 *)(unaff_EBP + -0xa8) = uVar5;
    *(undefined4 *)(unaff_EBP + -0x44) = uVar5;
    *(int *)(unaff_EBP + -0xac) = iVar10;
    *(int *)(unaff_EBP + -0x40) = iVar10;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar10 = piVar8[1] + -1;
      piVar8[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar10 = piVar8[2] + -1;
        piVar8[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    FUN_0056b650();
    piVar8 = piVar11 + 4;
    *piVar8 = *piVar8 + -1;
    if (*piVar8 == 0) {
      piVar11[3] = 0;
    }
    else {
      piVar11[3] = piVar11[3] + 1;
    }
    piVar11 = *(int **)(unaff_EBP + -0x18);
    piVar8 = *(int **)(unaff_EBP + -0x1c);
    *puVar1 = 0;
    *(undefined *)(unaff_EBP + -4) = 4;
    iVar10 = *piVar11;
    iVar9 = piVar8[1] - *piVar8;
    *(int *)(unaff_EBP + -0x74) = iVar9;
    piVar11 = *(int **)(iVar10 + 0x3c);
    *(int *)(unaff_EBP + -0x28) = piVar8[4] - piVar8[3];
    if (iVar9 == 0) {
      iVar10 = *(int *)(unaff_EBP + -0x14);
      if (DAT_01eb18d8 != '\0') {
        piVar11 = (int *)(iVar10 + 0xc);
        if (0xf < *(uint *)(iVar10 + 0x20)) {
          piVar11 = (int *)*piVar11;
        }
        FUN_01677520(DAT_01eb18d8,"Mesh manager: \'%s\' - bad vertex data",piVar11);
      }
      LOCK();
      *(undefined4 *)(iVar10 + 4) = 5;
      UNLOCK();
      piVar11 = *(int **)(unaff_EBP + -0x20);
      if (piVar11 != (int *)0x0) {
        LOCK();
        iVar10 = piVar11[1] + -1;
        piVar11[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar11)();
          LOCK();
          iVar10 = piVar11[2] + -1;
          piVar11[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      piVar11 = *(int **)(unaff_EBP + -0x3c);
      if (piVar11 == (int *)0x0) goto LAB_00772da4;
      LOCK();
      iVar10 = piVar11[1] + -1;
      piVar11[1] = iVar10;
      UNLOCK();
      if (iVar10 != 0) goto LAB_00772da4;
      (**(code **)*piVar11)();
      LOCK();
      iVar10 = piVar11[2] + -1;
      piVar11[2] = iVar10;
      UNLOCK();
      if (iVar10 != 0) goto LAB_00772da4;
      (**(code **)(*piVar11 + 4))();
      iVar10 = *(int *)(unaff_EBP + -0x18);
      uVar6 = *(int *)(unaff_EBP + -0x50) + 1;
      uVar7 = *(uint *)(unaff_EBP + -0x54);
      goto LAB_00772567;
    }
    (**(code **)(*piVar11 + 0x3c))(unaff_EBP + -0x6c,0,iVar9,piVar8[10],0);
    iVar10 = *piVar8;
    *(undefined *)(unaff_EBP + -4) = 5;
    (**(code **)(**(int **)(unaff_EBP + -0x6c) + 0x18))(0,iVar10,iVar9);
    iVar9 = *(int *)(unaff_EBP + -0x14) + 0xc;
    iVar10 = **(int **)(unaff_EBP + -0x6c);
    *(int *)(unaff_EBP + -0x1c) = iVar9;
    (**(code **)(iVar10 + 0xc))(iVar9);
    *(undefined4 *)(unaff_EBP + -0x38) = 0;
    *(undefined4 *)(unaff_EBP + -0x34) = 0;
    *(undefined *)(unaff_EBP + -4) = 6;
    if (*(int *)(unaff_EBP + -0x28) != 0) {
      puVar4 = (undefined4 *)
               (**(code **)(*piVar11 + 0x3c))
                         (unaff_EBP + -0xbc,0,*(int *)(unaff_EBP + -0x28),0x18,0);
      uVar5 = *puVar4;
      uVar2 = puVar4[1];
      *puVar4 = 0;
      puVar4[1] = 0;
      piVar3 = *(int **)(unaff_EBP + -0x34);
      *(undefined4 *)(unaff_EBP + -0xb0) = uVar5;
      *(undefined4 *)(unaff_EBP + -0x38) = uVar5;
      *(undefined4 *)(unaff_EBP + -0xb4) = uVar2;
      *(undefined4 *)(unaff_EBP + -0x34) = uVar2;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar10 = piVar3[1] + -1;
        piVar3[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar10 = piVar3[2] + -1;
          piVar3[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar3 = *(int **)(unaff_EBP + -0xb8);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar10 = piVar3[1] + -1;
        piVar3[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar10 = piVar3[2] + -1;
          piVar3[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      (**(code **)(**(int **)(unaff_EBP + -0x38) + 0x18))
                (0,piVar8[3],*(undefined4 *)(unaff_EBP + -0x28));
      (**(code **)(**(int **)(unaff_EBP + -0x38) + 0xc))(*(undefined4 *)(unaff_EBP + -0x1c));
    }
    iVar10 = piVar8[7] - piVar8[6] >> 1;
    *(int *)(unaff_EBP + -0x24) = iVar10;
    iVar9 = iVar10 * 2;
    *(int *)(unaff_EBP + -0x70) = iVar9;
    if (iVar9 == 0) {
      if (DAT_01eb18d8 != '\0') {
        piVar11 = *(int **)(unaff_EBP + -0x1c);
        if (0xf < (uint)piVar11[5]) {
          piVar11 = (int *)*piVar11;
        }
        FUN_01677520(DAT_01eb18d8,"Mesh manager: \'%s\' - bad index data",piVar11);
      }
      LOCK();
      *(undefined4 *)(*(int *)(unaff_EBP + -0x14) + 4) = 5;
      UNLOCK();
      piVar11 = *(int **)(unaff_EBP + -0x34);
      if (piVar11 != (int *)0x0) {
        LOCK();
        iVar10 = piVar11[1] + -1;
        piVar11[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar11)();
          LOCK();
          iVar10 = piVar11[2] + -1;
          piVar11[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      piVar11 = *(int **)(unaff_EBP + -0x68);
      if (piVar11 != (int *)0x0) {
        LOCK();
        iVar10 = piVar11[1] + -1;
        piVar11[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar11)();
          LOCK();
          iVar10 = piVar11[2] + -1;
          piVar11[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      FUN_0056b650();
      iVar10 = *(int *)(unaff_EBP + -0x18);
      uVar6 = *(int *)(unaff_EBP + -0x50) + 1;
      uVar7 = *(uint *)(unaff_EBP + -0x54);
      goto LAB_00772567;
    }
    (**(code **)(*piVar11 + 0x3c))(unaff_EBP + -100,1,iVar9,2,0);
    iVar9 = piVar8[6];
    *(undefined *)(unaff_EBP + -4) = 7;
    (**(code **)(**(int **)(unaff_EBP + -100) + 0x18))(0,iVar9,iVar10 * 2);
    (**(code **)(**(int **)(unaff_EBP + -100) + 0xc))(*(undefined4 *)(unaff_EBP + -0x1c));
    piVar11 = *(int **)(unaff_EBP + -0x18);
    FUN_0147c0e0(unaff_EBP + -0x5c,piVar11 + piVar8[9] * 2 + 0x25,unaff_EBP + -0x6c,unaff_EBP + -100
                );
    *(undefined4 *)(unaff_EBP + -0x30) = 0;
    *(undefined4 *)(unaff_EBP + -0x2c) = 0;
    *(undefined *)(unaff_EBP + -4) = 9;
    if (*(int *)(unaff_EBP + -0x28) != 0) {
      puVar4 = (undefined4 *)
               FUN_0147c0e0(unaff_EBP + -0xc4,piVar11 + 0x2b,unaff_EBP + -0x38,unaff_EBP + -100);
      uVar5 = *puVar4;
      uVar2 = puVar4[1];
      *puVar4 = 0;
      puVar4[1] = 0;
      piVar8 = *(int **)(unaff_EBP + -0x2c);
      *(undefined4 *)(unaff_EBP + -200) = uVar5;
      *(undefined4 *)(unaff_EBP + -0x30) = uVar5;
      *(undefined4 *)(unaff_EBP + -0xcc) = uVar2;
      *(undefined4 *)(unaff_EBP + -0x2c) = uVar2;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar10 = piVar8[1] + -1;
        piVar8[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar10 = piVar8[2] + -1;
          piVar8[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      piVar8 = *(int **)(unaff_EBP + -0xc0);
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar10 = piVar8[1] + -1;
        piVar8[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar10 = piVar8[2] + -1;
          piVar8[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      iVar10 = *(int *)(unaff_EBP + -0x24);
    }
    iVar9 = *(int *)(unaff_EBP + -0x14);
    if (*(uint *)(iVar9 + 0x15c) < 2) {
      uVar5 = FUN_0147c720(unaff_EBP + -0x5c,0,0,0,iVar10);
      FUN_0076b300(uVar5);
      piVar8 = *(int **)(unaff_EBP + -0xe0);
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar10 = piVar8[1] + -1;
        piVar8[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar10 = piVar8[2] + -1;
          piVar8[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      uVar5 = FUN_0147c720(unaff_EBP + -0x30,0,0,0,*(undefined4 *)(unaff_EBP + -0x24));
      FUN_0076b300(uVar5);
      piVar8 = *(int **)(unaff_EBP + -0xf8);
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar10 = piVar8[1] + -1;
        piVar8[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar10 = piVar8[2] + -1;
          piVar8[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
    }
    else {
      uVar7 = 0;
      if (*(uint *)(iVar9 + 0x15c) != 0) {
        piVar11 = (int *)(iVar9 + 0xe8);
        do {
          if (*(int *)(unaff_EBP + -0x58) != 0) {
            LOCK();
            piVar8 = (int *)(*(int *)(unaff_EBP + -0x58) + 4);
            *piVar8 = *piVar8 + 1;
            UNLOCK();
          }
          iVar10 = *(int *)(unaff_EBP + -0x5c);
          piVar11[-0x1f] = iVar10;
          piVar8 = (int *)piVar11[-0x1e];
          *(int *)(unaff_EBP + -0x90) = iVar10;
          *(int *)(unaff_EBP + -0x94) = *(int *)(unaff_EBP + -0x58);
          piVar11[-0x1e] = *(int *)(unaff_EBP + -0x58);
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar10 = piVar8[1] + -1;
            piVar8[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piVar8)();
              LOCK();
              iVar10 = piVar8[2] + -1;
              piVar8[2] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
          if (*(int *)(unaff_EBP + -0x2c) != 0) {
            LOCK();
            piVar8 = (int *)(*(int *)(unaff_EBP + -0x2c) + 4);
            *piVar8 = *piVar8 + 1;
            UNLOCK();
          }
          iVar10 = *(int *)(unaff_EBP + -0x30);
          piVar11[-1] = iVar10;
          piVar8 = (int *)*piVar11;
          *(int *)(unaff_EBP + -0x98) = iVar10;
          *(int *)(unaff_EBP + -0x9c) = *(int *)(unaff_EBP + -0x2c);
          *piVar11 = *(int *)(unaff_EBP + -0x2c);
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar10 = piVar8[1] + -1;
            piVar8[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piVar8)();
              LOCK();
              iVar10 = piVar8[2] + -1;
              piVar8[2] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
          iVar9 = *(int *)(unaff_EBP + -0x14);
          uVar7 = uVar7 + 1;
          piVar11 = piVar11 + 6;
        } while (uVar7 < *(uint *)(iVar9 + 0x15c));
      }
      piVar11 = *(int **)(unaff_EBP + -0x18);
    }
    iVar10 = *(int *)(unaff_EBP + -0x70) + *(int *)(unaff_EBP + -0x28) + *(int *)(unaff_EBP + -0x74)
    ;
    *(int *)(iVar9 + 0x180) = iVar10;
    uVar7 = piVar11[10] + iVar10;
    piVar11[10] = uVar7;
    if (DAT_01eb18d8 != '\0') {
      piVar8 = *(int **)(unaff_EBP + -0x1c);
      if (0xf < (uint)piVar8[5]) {
        piVar8 = (int *)*piVar8;
      }
      FUN_01677520(DAT_01eb18d8,"Mesh manager: uploaded \'%s\' (mem %u / %u kb)",piVar8,uVar7 >> 10,
                   (uint)piVar11[9] >> 10);
      piVar11 = *(int **)(unaff_EBP + -0x18);
    }
    if (*(int *)(iVar9 + 8) == 0x13) {
      piVar8 = (int *)(*(int *)(*piVar11 + 0x524) + 0x90);
      *piVar8 = *piVar8 + 1;
      piVar8 = (int *)(*(int *)(*piVar11 + 0x524) + 0x94);
      *piVar8 = *piVar8 + *(int *)(iVar9 + 0x180);
    }
    LOCK();
    *(undefined4 *)(iVar9 + 4) = 4;
    UNLOCK();
    piVar8 = (int *)piVar11[0x3a];
    if ((int *)piVar11[0x3b] == piVar8) {
      FUN_005c1970(piVar8,unaff_EBP + -0x4c);
      unaff_EDI = *(int **)(unaff_EBP + -0x40);
      unaff_EBX = *(int **)(unaff_EBP + -0x48);
    }
    else {
      unaff_EBX = *(int **)(unaff_EBP + -0x3c);
      *piVar8 = 0;
      piVar8[1] = 0;
      if (unaff_EBX != (int *)0x0) {
        LOCK();
        unaff_EBX[1] = unaff_EBX[1] + 1;
        UNLOCK();
      }
      *piVar8 = iVar9;
      unaff_EDI = *(int **)(unaff_EBP + -0x20);
      piVar8[1] = (int)unaff_EBX;
      piVar11[0x3a] = piVar11[0x3a] + 8;
    }
    piVar11 = *(int **)(unaff_EBP + -0x2c);
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar10 = piVar11[1] + -1;
      piVar11[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piVar11)();
        LOCK();
        iVar10 = piVar11[2] + -1;
        piVar11[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
    piVar11 = *(int **)(unaff_EBP + -0x58);
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar10 = piVar11[1] + -1;
      piVar11[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piVar11)();
        LOCK();
        iVar10 = piVar11[2] + -1;
        piVar11[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
    piVar11 = *(int **)(unaff_EBP + -0x60);
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar10 = piVar11[1] + -1;
      piVar11[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piVar11)();
        LOCK();
        iVar10 = piVar11[2] + -1;
        piVar11[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
    piVar11 = *(int **)(unaff_EBP + -0x34);
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar10 = piVar11[1] + -1;
      piVar11[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piVar11)();
        LOCK();
        iVar10 = piVar11[2] + -1;
        piVar11[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
    piVar11 = *(int **)(unaff_EBP + -0x68);
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar10 = piVar11[1] + -1;
      piVar11[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piVar11)();
        LOCK();
        iVar10 = piVar11[2] + -1;
        piVar11[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piVar11 + 4))();
          FUN_00772d53();
          return;
        }
      }
    }
  } while( true );
}



/* FUNCTION 10900 ; VA 0x00772e60 ; FUN_00772e60 */

void __fastcall FUN_00772e60(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *(int *)(param_1 + 0xe4);
  puVar1 = (undefined4 *)(param_1 + 0xe4);
  iVar3 = *(int *)(param_1 + 0xe8);
  if (iVar3 - iVar2 >> 3 != 0) {
    if (iVar2 != iVar3) {
      do {
        FUN_006eccd0();
        FUN_016795b0();
        iVar2 = iVar2 + 8;
      } while (iVar2 != iVar3);
      iVar3 = *(int *)(param_1 + 0xe8);
    }
    FUN_005596d0(*puVar1,iVar3,puVar1);
    *(undefined4 *)(param_1 + 0xe8) = *puVar1;
  }
  return;
}



/* FUNCTION 10901 ; VA 0x00772ec0 ; FUN_00772ec0 */

void __thiscall FUN_00772ec0(int param_1,undefined4 *param_2)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4d58;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)(param_1 + 0x14);
  ExceptionList = &pvStack_10;
  do {
    LOCK();
    uVar6 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
    uStack_8 = (uint)((uVar6 & 1) != 0);
  } while (uStack_8 != 0);
  uVar6 = *(uint *)(param_1 + 8);
  if (uVar6 <= *(int *)(param_1 + 0x10) + 1U) {
    FUN_00617300(1);
    uVar6 = *(uint *)(param_1 + 8);
  }
  *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & uVar6 - 1;
  iVar3 = (*(int *)(param_1 + 0x10) + *(int *)(param_1 + 0xc) & *(int *)(param_1 + 8) - 1U) * 4;
  iVar7 = *(int *)(param_1 + 4);
  if (*(int *)(iVar7 + iVar3) == 0) {
    uVar5 = FUN_01674e20(0x10);
    *(undefined4 *)(iVar3 + *(int *)(param_1 + 4)) = uVar5;
    iVar7 = *(int *)(param_1 + 4);
  }
  puVar4 = *(undefined4 **)(iVar3 + iVar7);
  *puVar4 = 0;
  puVar4[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar2 = (int *)(param_2[1] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  *puVar4 = *param_2;
  puVar4[1] = param_2[1];
  puVar4[2] = 0;
  puVar4[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar2 = (int *)(param_2[3] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  puVar4[2] = param_2[2];
  puVar4[3] = param_2[3];
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  *puVar1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10902 ; VA 0x00772fb0 ; FUN_00772fb0 */

void FUN_00772fb0(undefined4 param_1,undefined4 *param_2,char *param_3,int param_4)

{
  undefined4 uVar1;
  char *pcVar2;
  char *pcVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa5a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d62f88 == '\0') {
    pcVar2 = "";
    if ((param_3 == (char *)0x0) || (pcVar3 = ", exception: ", pcVar2 = param_3, *param_3 == '\0'))
    {
      param_3 = pcVar2;
      pcVar3 = "";
    }
    puVar6 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar6 = (undefined4 *)*param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_01675640(auStack_28,"Mesh Manager: %s, contentid: \'%s\'%s%s",param_1,puVar6,pcVar3,param_3)
    ;
    iStack_8 = 0;
    uVar1 = *(undefined4 *)(param_4 + 0x48);
    uVar4 = FUN_00d108b0(auStack_40,param_4);
    iStack_8._0_1_ = 1;
    FUN_0086f010(3,auStack_28,uVar4,uVar1);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_2c) {
      uVar7 = uStack_2c + 1;
      uVar5 = auStack_40[0];
      if (0xfff < uVar7) {
        uVar5 = *(uint *)(auStack_40[0] - 4);
        uVar7 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar7);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    iStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar7 = uStack_14 + 1;
      uVar5 = auStack_28[0];
      if (0xfff < uVar7) {
        uVar5 = *(uint *)(auStack_28[0] - 4);
        uVar7 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar7);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
  }
  FUN_008c8430(param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10903 ; VA 0x00773100 ; FUN_00773100 */

undefined ** __thiscall
FUN_00773100(int *param_1,int param_2,int *param_3,int param_4,undefined4 param_5)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined **ppuVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined auStack_26c [92];
  undefined auStack_210 [92];
  undefined auStack_1b4 [92];
  undefined auStack_158 [92];
  undefined auStack_fc [92];
  int iStack_a0;
  int *piStack_9c;
  undefined auStack_98 [72];
  undefined4 uStack_50;
  int iStack_4c;
  int *piStack_48;
  undefined **appuStack_44 [2];
  undefined4 auStack_3c [6];
  int iStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  int *piStack_18;
  undefined **ppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af124;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ppuVar6 = *(undefined ***)(*param_1 + 0x518);
  ExceptionList = &pvStack_10;
  ppuStack_14 = ppuVar6;
  if (ppuVar6 != (undefined **)0x0) {
    piVar8 = (int *)param_1[8];
    ExceptionList = &pvStack_10;
    if (piVar8 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = (int *)param_1[8];
    }
    iStack_a0 = param_1[7];
    LOCK();
    *(undefined4 *)(param_2 + 4) = 1;
    UNLOCK();
    piStack_18 = &iStack_a0;
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
    }
    puStack_1c = auStack_98;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    piStack_9c = piVar8;
    iStack_24 = iStack_a0;
    piStack_20 = piVar8;
    FUN_0054ef60(param_4);
    uStack_8._0_1_ = 3;
    FUN_0054ef60(param_4 + 0x18);
    uStack_8._0_1_ = 4;
    FUN_0054ef60(param_4 + 0x30);
    uStack_50 = *(undefined4 *)(param_4 + 0x48);
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iStack_4c = param_2;
    piStack_48 = param_3;
    uStack_8._0_1_ = 5;
    FUN_0076a180(&iStack_a0);
    uStack_8._0_1_ = 6;
    appuStack_44[0] = (undefined **)0x0;
    FUN_0076a180(auStack_26c);
    uStack_8._0_1_ = 7;
    FUN_0076a180(auStack_210);
    uStack_8._0_1_ = 8;
    FUN_0076a180(auStack_1b4);
    uStack_8._0_1_ = 9;
    cVar3 = FUN_00585a40(auStack_fc);
    if (cVar3 == '\0') {
      FUN_0076a180(auStack_fc);
      uStack_8._0_1_ = 10;
      iVar4 = FUN_01674e20(0x5c);
      uStack_8._0_1_ = 0xb;
      if (iVar4 == 0) {
        auStack_3c[0] = 0;
      }
      else {
        auStack_3c[0] = FUN_0076a180(auStack_158);
      }
      FUN_0076acc0();
      FUN_0076acc0();
      bVar2 = true;
    }
    else {
      FUN_0076acc0();
      bVar2 = false;
    }
    FUN_0076acc0();
    appuStack_44[0] = &PTR_FUN_018fb55c;
    if (!bVar2) {
      appuStack_44[0] = (undefined **)0x0;
    }
    FUN_0076acc0();
    FUN_0076acc0();
    FUN_0076acc0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    switch(*(undefined4 *)(param_2 + 8)) {
    case 0xd:
    case 0xe:
    case 0x12:
      uVar5 = FUN_008ccd80();
      break;
    case 0xf:
    case 0x10:
    case 0x11:
      uVar5 = FUN_008ccd50();
      break;
    default:
      uVar5 = FUN_008ccd70();
    }
    FUN_008cd330(param_2 + 0xc,0x41a00000,appuStack_44,uVar5,&DAT_01d62f20,0,param_5);
    uStack_8._0_1_ = 0xd;
    ppuVar6 = appuStack_44[0];
    if (((appuStack_44[0] != (undefined **)0x0) && (((uint)appuStack_44[0] & 1) == 0)) &&
       (ppuVar6 = *(undefined ***)((uint)appuStack_44[0] & 0xfffffffe), ppuVar6 != (undefined **)0x0
       )) {
      ppuVar6 = (undefined **)(*(code *)ppuVar6)(auStack_3c,auStack_3c,2);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (DAT_01eb18d8 != '\0') {
      puVar7 = (undefined4 *)(param_2 + 0xc);
      if (0xf < *(uint *)(param_2 + 0x20)) {
        puVar7 = (undefined4 *)*puVar7;
      }
      ppuVar6 = (undefined **)
                FUN_01677520(DAT_01eb18d8,"Mesh manager: requested \'%s\' (t %d  f %d)",puVar7,
                             *(undefined4 *)(param_2 + 8),*(undefined4 *)(param_2 + 0x24));
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar1 = piVar8 + 1;
      iVar4 = *piVar1;
      ppuVar6 = (undefined **)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        piVar1 = piVar8 + 2;
        iVar4 = *piVar1;
        ppuVar6 = (undefined **)*piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          ppuVar6 = (undefined **)(**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar8 = param_3 + 1;
    iVar4 = *piVar8;
    ppuVar6 = (undefined **)*piVar8;
    *piVar8 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      ppuVar6 = (undefined **)(**(code **)*param_3)();
      LOCK();
      piVar8 = param_3 + 2;
      iVar4 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        ppuVar6 = (undefined **)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return ppuVar6;
}



/* FUNCTION 10904 ; VA 0x00773440 ; FUN_00773440 */

void FUN_00773440(int param_1)

{
  undefined uVar1;
  int iVar2;
  uint uVar3;
  
  iVar2 = FUN_00b084e0();
  if ((iVar2 == 0x100) && (iVar2 = FUN_00b08820(), iVar2 == 0)) {
    uVar3 = 0;
    do {
      uVar1 = FUN_00b08890(uVar3);
      *(undefined *)(uVar3 + param_1) = uVar1;
      uVar3 = uVar3 + 1;
    } while (uVar3 < 6);
  }
  return;
}



/* FUNCTION 10905 ; VA 0x00773480 ; FUN_00773480 */

void __thiscall FUN_00773480(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af130;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::Graphics::TextureRef::Data>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10906 ; VA 0x007734ee ; Catch_All@007734ee */

void Catch_All_007734ee(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_007737c0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10907 ; VA 0x00773510 ; FUN_00773510 */

undefined4 * __thiscall
FUN_00773510(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined param_4,
            undefined4 param_5,undefined4 param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_5;
  *(undefined *)(param_1 + 3) = param_4;
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  param_1[4] = param_6;
  param_1[5] = param_7;
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 10908 ; VA 0x007735a0 ; FUN_007735a0 */

int * __thiscall FUN_007735a0(int *param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piStack_c;
  
  puVar3 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = 0;
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[5] = 0;
    puVar3[6] = 0;
    puVar3[7] = 0;
    puVar3[8] = 0;
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[5] = 0;
    *(undefined *)(puVar3 + 6) = 0;
    puVar3[7] = 0;
    puVar3[8] = 0;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00773480(puVar3,param_2);
  if (*param_2 == 0) {
    *(undefined4 *)(*param_1 + 8) = 0;
  }
  else {
    *(undefined4 *)(*param_1 + 8) = param_3;
    FUN_0056ecd0(param_2);
    uVar4 = FUN_00773510(*(undefined4 *)(*param_2 + 0x30),*(undefined4 *)(*param_2 + 0x34),1,0,0,0);
    FUN_007736c0(uVar4);
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[1] + -1;
      piStack_c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar1 = piStack_c + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_c + 4))();
          return param_1;
        }
      }
    }
  }
  return param_1;
}



/* FUNCTION 10909 ; VA 0x007736c0 ; FUN_007736c0 */

undefined4 * __thiscall FUN_007736c0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  *(undefined *)(param_1 + 3) = *(undefined *)(param_2 + 3);
  uVar2 = param_2[4];
  uVar3 = param_2[5];
  param_2[4] = 0;
  param_2[5] = 0;
  param_1[4] = uVar2;
  piVar4 = (int *)param_1[5];
  param_1[5] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 10910 ; VA 0x00773740 ; FUN_00773740 */

undefined4 * __thiscall FUN_00773740(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  *(undefined *)(param_1 + 3) = *(undefined *)(param_2 + 3);
  iVar3 = param_2[5];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = param_2[5];
  }
  param_1[4] = param_2[4];
  piVar2 = (int *)param_1[5];
  param_1[5] = iVar3;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 10911 ; VA 0x007737c0 ; FUN_007737c0 */

int __thiscall FUN_007737c0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 10912 ; VA 0x00773830 ; FUN_00773830 */

void __fastcall FUN_00773830(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *(int *)(param_1 + 0xc);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 0x20);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x24);
  }
  return;
}



/* FUNCTION 10913 ; VA 0x007738a0 ; FUN_007738a0 */

undefined4 * __thiscall FUN_007738a0(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  bool bVar5;
  bool bVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if (*param_1 == 0) {
    piStack_14 = (int *)0x0;
    puVar7 = &uStack_18;
    bVar6 = false;
    bVar5 = true;
    uVar8 = 0;
  }
  else {
    puVar7 = (undefined4 *)FUN_01674e20(0x24);
    if (puVar7 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      puVar3 = (undefined4 *)*param_1;
      *puVar7 = 0;
      puVar7[1] = 0;
      if (puVar3[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar3[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *puVar7 = *puVar3;
      puVar7[1] = puVar3[1];
      puVar7[2] = puVar3[2];
      puVar7[3] = puVar3[3];
      puVar7[4] = puVar3[4];
      puVar7[5] = puVar3[5];
      *(undefined *)(puVar7 + 6) = *(undefined *)(puVar3 + 6);
      puVar7[7] = 0;
      puVar7[8] = 0;
      if (puVar3[8] != 0) {
        LOCK();
        piVar1 = (int *)(puVar3[8] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      puVar7[7] = puVar3[7];
      puVar7[8] = puVar3[8];
    }
    uStack_10 = 0;
    piStack_c = (int *)0x0;
    FUN_00773480(puVar7,param_2);
    puVar7 = &uStack_10;
    bVar6 = true;
    bVar5 = false;
    uVar8 = uStack_10;
  }
  *puVar7 = 0;
  *param_2 = uVar8;
  param_2[1] = puVar7[1];
  puVar7[1] = 0;
  piVar1 = piStack_14;
  if ((bVar5) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2 + -1;
      *piVar2 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = piStack_c;
  if ((bVar6) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_c[1] + -1;
    piStack_c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 10914 ; VA 0x00773a00 ; FUN_00773a00 */

undefined4 * FUN_00773a00(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  
  puVar3 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = 0;
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[5] = 0;
    puVar3[6] = 0;
    puVar3[7] = 0;
    puVar3[8] = 0;
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[5] = 0;
    *(undefined *)(puVar3 + 6) = 0;
    puVar3[7] = 0;
    puVar3[8] = 0;
  }
  puVar3[2] = 1;
  iVar4 = param_2[1];
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = param_2[1];
  }
  *puVar3 = *param_2;
  piVar2 = (int *)puVar3[1];
  puVar3[1] = iVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00773480(puVar3,param_2);
  return param_1;
}



/* FUNCTION 10915 ; VA 0x00773ad0 ; FUN_00773ad0 */

int __thiscall FUN_00773ad0(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  bool bVar6;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined uStack_18;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  iVar5 = param_2[1];
  piVar2 = (int *)*param_1;
  uStack_c = 0;
  if (iVar5 != 0) {
    LOCK();
    *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
    UNLOCK();
    iVar5 = param_2[1];
  }
  *piVar2 = *param_2;
  piVar3 = (int *)piVar2[1];
  piVar2[1] = iVar5;
  piStack_8 = param_1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar5 = *param_2;
  bVar6 = iVar5 == 0;
  if (bVar6) {
    uStack_24 = 0;
    puVar4 = &uStack_24;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
    piStack_10 = (int *)0x0;
  }
  else {
    puVar4 = (undefined4 *)
             FUN_00773510(*(undefined4 *)(iVar5 + 0x30),*(undefined4 *)(iVar5 + 0x34),1,0,0,0);
  }
  iVar5 = FUN_007736c0(puVar4);
  piVar2 = piStack_10;
  if (bVar6) {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_10 + 1;
      iVar1 = *piVar3;
      iVar5 = *piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)*piStack_10)();
        LOCK();
        piVar3 = piVar2 + 2;
        iVar1 = *piVar3;
        iVar5 = *piVar3;
        *piVar3 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          iVar5 = (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if ((!bVar6) && (piStack_28 != (int *)0x0)) {
    LOCK();
    piVar2 = piStack_28 + 1;
    iVar1 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar5 = (**(code **)*piStack_28)();
      LOCK();
      piVar2 = piStack_28 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar5 = (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  return iVar5;
}



/* FUNCTION 10916 ; VA 0x00773c00 ; FUN_00773c00 */

void __fastcall FUN_00773c00(int *param_1)

{
  *(undefined4 *)(*param_1 + 8) = 2;
  return;
}



/* FUNCTION 10917 ; VA 0x00773c10 ; FUN_00773c10 */

int __thiscall FUN_00773c10(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int *piStack_c;
  
  *(undefined4 *)(*param_1 + 8) = 3;
  iVar4 = param_2[1];
  param_1 = (int *)*param_1;
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = param_2[1];
  }
  *param_1 = *param_2;
  piVar2 = (int *)param_1[1];
  param_1[1] = iVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = FUN_00773510(*(undefined4 *)(*param_2 + 0x30),*(undefined4 *)(*param_2 + 0x34),1,0,0,0);
  iVar4 = FUN_007736c0(uVar3);
  if (piStack_c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_c + 1;
    iVar1 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar4 = (**(code **)*piStack_c)();
      LOCK();
      piVar2 = piStack_c + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar4 = (**(code **)(*piStack_c + 4))();
      }
    }
  }
  return iVar4;
}



/* FUNCTION 10918 ; VA 0x00773cd0 ; FUN_00773cd0 */

int __thiscall FUN_00773cd0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  *(undefined4 *)(*param_1 + 8) = 3;
  puVar2 = (undefined4 *)*param_1;
  iVar5 = param_2[1];
  if (iVar5 != 0) {
    LOCK();
    *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
    UNLOCK();
    iVar5 = param_2[1];
  }
  *puVar2 = *param_2;
  piVar3 = (int *)puVar2[1];
  puVar2[1] = iVar5;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar5 = *param_1;
  *(undefined4 *)(iVar5 + 0xc) = *param_3;
  *(undefined4 *)(iVar5 + 0x10) = param_3[1];
  *(undefined4 *)(iVar5 + 0x14) = param_3[2];
  *(undefined *)(iVar5 + 0x18) = *(undefined *)(param_3 + 3);
  iVar6 = param_3[5];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = param_3[5];
  }
  iVar4 = param_3[4];
  *(int *)(iVar5 + 0x1c) = iVar4;
  piVar3 = *(int **)(iVar5 + 0x20);
  *(int *)(iVar5 + 0x20) = iVar6;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar4;
}



/* FUNCTION 10919 ; VA 0x00773d90 ; FUN_00773d90 */

void __fastcall FUN_00773d90(int *param_1)

{
  *(undefined4 *)(*param_1 + 8) = 1;
  return;
}



/* FUNCTION 10920 ; VA 0x00773da0 ; FUN_00773da0 */

void __thiscall FUN_00773da0(uint *param_1,int param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  uVar6 = (param_3 - param_2) / 0x54;
  uVar2 = param_1[1];
  uVar4 = *param_1;
  uVar5 = (int)(uVar2 - uVar4) / 0x54;
  uVar1 = (int)(param_1[2] - uVar4) / 0x54;
  if (uVar6 <= uVar1) {
    if (uVar5 < uVar6) {
      iVar3 = uVar5 * 0x54 + param_2;
      FUN_00773fc0(param_2,iVar3,uVar4);
      uVar2 = FUN_00775c70(iVar3,param_3,param_1[1]);
      param_1[1] = uVar2;
      return;
    }
    FUN_00773fc0(param_2,param_3,uVar4);
    uVar2 = param_1[1];
    uVar4 = uVar6 * 0x54 + uVar4;
    for (uVar6 = uVar4; uVar6 != uVar2; uVar6 = uVar6 + 0x54) {
      FUN_005509f0();
    }
    param_1[1] = uVar4;
    return;
  }
  if (uVar6 < 0x30c30c4) {
    uVar5 = uVar6;
    if ((uVar1 <= 0x30c30c3 - (uVar1 >> 1)) && (uVar5 = (uVar1 >> 1) + uVar1, uVar5 < uVar6)) {
      uVar5 = uVar6;
    }
    if (uVar4 != 0) {
      if (uVar4 != uVar2) {
        do {
          FUN_005509f0();
          uVar4 = uVar4 + 0x54;
        } while (uVar4 != uVar2);
        uVar4 = *param_1;
      }
      FUN_00762350(uVar4,uVar1);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    if (uVar5 != 0) {
      if (0x30c30c3 < uVar5) goto LAB_00773f72;
      uVar5 = uVar5 * 0x54;
      if (uVar5 < 0x1000) {
        if (uVar5 == 0) {
          uVar2 = 0;
        }
        else {
          uVar2 = FUN_01674e20(uVar5);
        }
      }
      else {
        uVar2 = uVar5 + 0x23;
        if (uVar2 <= uVar5) {
          uVar2 = 0xffffffff;
        }
        iVar3 = FUN_01674e20(uVar2);
        if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        uVar2 = iVar3 + 0x23U & 0xffffffe0;
        *(int *)(uVar2 - 4) = iVar3;
      }
      *param_1 = uVar2;
      param_1[1] = uVar2;
      param_1[2] = *param_1 + uVar5;
    }
    uVar2 = FUN_00775c70(param_2,param_3,*param_1);
    param_1[1] = uVar2;
    return;
  }
LAB_00773f72:
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 10921 ; VA 0x00773f80 ; FUN_00773f80 */

int FUN_00773f80(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = FUN_00601de0();
  *(undefined2 *)(iVar2 + 0xc) = 0;
  *(undefined4 *)(iVar2 + 0x10) = 0;
  *(undefined4 *)(iVar2 + 0x14) = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + 0x10) = *param_1;
  *(undefined4 *)(iVar2 + 0x14) = param_1[1];
  return iVar2;
}



/* FUNCTION 10922 ; VA 0x00773fc0 ; FUN_00773fc0 */

uint * FUN_00773fc0(uint *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  uint *puVar5;
  uint *puVar6;
  
  if (param_1 != param_2) {
    puVar6 = param_3 + 0xe;
    puVar5 = param_1 + 0xb;
    do {
      if (param_3 != puVar5 + -0xb) {
        puVar4 = puVar5 + -0xb;
        if (0xf < puVar5[-6]) {
          puVar4 = (uint *)*puVar4;
        }
        FUN_005542c0(puVar4,puVar5[-7]);
      }
      if (puVar6 != puVar5 + 3) {
        puVar4 = puVar5 + -5;
        if (0xf < *puVar5) {
          puVar4 = (uint *)*puVar4;
        }
        FUN_005542c0(puVar4,puVar5[-1]);
      }
      param_3 = param_3 + 0x15;
      puVar6[-2] = puVar5[1];
      puVar6[-1] = puVar5[2];
      *puVar6 = puVar5[3];
      puVar6[1] = puVar5[4];
      uVar1 = puVar5[6];
      uVar2 = puVar5[7];
      uVar3 = puVar5[8];
      puVar6[2] = puVar5[5];
      puVar6[3] = uVar1;
      puVar6[4] = uVar2;
      puVar6[5] = uVar3;
      puVar6[6] = puVar5[9];
      puVar6 = puVar6 + 0x15;
      puVar4 = puVar5 + 10;
      puVar5 = puVar5 + 0x15;
    } while (puVar4 != param_2);
  }
  return param_3;
}



/* FUNCTION 10923 ; VA 0x00774050 ; FUN_00774050 */

void FUN_00774050(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 0x5c);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      FUN_005509f0();
      param_1 = param_1 + 0x60;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 10924 ; VA 0x007740a0 ; FUN_007740a0 */

int __thiscall FUN_007740a0(int *param_1,int param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  
  iVar2 = *param_1;
  iVar3 = param_1[1] - iVar2 >> 3;
  if (iVar3 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar4 = iVar3 + 1;
  uVar7 = param_1[2] - iVar2 >> 3;
  uVar5 = uVar4;
  if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar5 = (uVar7 >> 1) + uVar7, uVar5 < uVar4)) {
    uVar5 = uVar4;
  }
  iVar3 = FUN_00578020(uVar5);
  iVar2 = (param_2 - iVar2 >> 3) * 8;
  *(undefined4 *)(iVar2 + iVar3) = 0;
  *(undefined4 *)(iVar2 + 4 + iVar3) = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + iVar3) = *param_3;
  *(undefined4 *)(iVar2 + 4 + iVar3) = param_3[1];
  iVar8 = param_1[1];
  iVar9 = *param_1;
  iVar6 = iVar3;
  if (param_2 != iVar8) {
    FUN_006cfaf0(iVar9,param_2,iVar3,param_1);
    iVar8 = param_1[1];
    iVar6 = iVar2 + 8 + iVar3;
    iVar9 = param_2;
  }
  FUN_006cfaf0(iVar9,iVar8,iVar6,param_1);
  iVar9 = *param_1;
  if (iVar9 != 0) {
    iVar8 = param_1[1];
    if (iVar9 != iVar8) {
      do {
        piVar1 = *(int **)(iVar9 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar6 = piVar1[2] + -1;
          piVar1[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        iVar9 = iVar9 + 8;
      } while (iVar9 != iVar8);
      iVar9 = *param_1;
    }
    uVar7 = param_1[2] - iVar9 & 0xfffffff8;
    iVar8 = iVar9;
    if (0xfff < uVar7) {
      iVar8 = *(int *)(iVar9 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar9 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar7);
  }
  *param_1 = iVar3;
  param_1[1] = iVar3 + uVar4 * 8;
  param_1[2] = iVar3 + uVar5 * 8;
  return *param_1 + iVar2;
}



/* FUNCTION 10925 ; VA 0x00774200 ; FUN_00774200 */

void FUN_00774200(int *param_1,int *param_2,int *param_3)

{
  float *pfVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  
  iVar6 = *param_1;
  fVar2 = *(float *)(iVar6 + 0x40);
  iVar3 = (int)param_3 - (int)param_1 >> 3;
  if (iVar3 < 0x29) {
    iVar3 = *param_2;
    if (*(float *)(iVar3 + 0x40) <= fVar2 && fVar2 != *(float *)(iVar3 + 0x40)) {
      *param_2 = iVar6;
      *param_1 = iVar3;
      iVar6 = param_2[1];
      param_2[1] = param_1[1];
      param_1[1] = iVar6;
      iVar3 = *param_2;
    }
    iVar6 = *param_3;
    pfVar1 = (float *)(iVar6 + 0x40);
    if (*pfVar1 <= *(float *)(iVar3 + 0x40) && *(float *)(iVar3 + 0x40) != *pfVar1) {
      *param_3 = iVar3;
      *param_2 = iVar6;
      iVar6 = param_3[1];
      param_3[1] = param_2[1];
      param_2[1] = iVar6;
      iVar6 = *param_2;
      fVar2 = *(float *)(*param_1 + 0x40);
      pfVar1 = (float *)(iVar6 + 0x40);
      if (*pfVar1 <= fVar2 && fVar2 != *pfVar1) {
        *param_2 = *param_1;
        *param_1 = iVar6;
        iVar6 = param_2[1];
        param_2[1] = param_1[1];
        param_1[1] = iVar6;
        return;
      }
    }
  }
  else {
    iVar4 = iVar3 + 1 >> 3;
    iVar3 = param_1[iVar4 * 2];
    if (*(float *)(iVar3 + 0x40) <= fVar2 && fVar2 != *(float *)(iVar3 + 0x40)) {
      param_1[iVar4 * 2] = iVar6;
      *param_1 = iVar3;
      iVar6 = param_1[iVar4 * 2 + 1];
      param_1[iVar4 * 2 + 1] = param_1[1];
      param_1[1] = iVar6;
      iVar3 = param_1[iVar4 * 2];
    }
    iVar6 = param_1[iVar4 * 4];
    pfVar1 = (float *)(iVar6 + 0x40);
    if (*pfVar1 <= *(float *)(iVar3 + 0x40) && *(float *)(iVar3 + 0x40) != *pfVar1) {
      param_1[iVar4 * 4] = iVar3;
      param_1[iVar4 * 2] = iVar6;
      iVar6 = param_1[iVar4 * 4 + 1];
      param_1[iVar4 * 4 + 1] = param_1[iVar4 * 2 + 1];
      param_1[iVar4 * 2 + 1] = iVar6;
      iVar6 = param_1[iVar4 * 2];
      fVar2 = *(float *)(*param_1 + 0x40);
      pfVar1 = (float *)(iVar6 + 0x40);
      if (*pfVar1 <= fVar2 && fVar2 != *pfVar1) {
        param_1[iVar4 * 2] = *param_1;
        *param_1 = iVar6;
        iVar6 = param_1[iVar4 * 2 + 1];
        param_1[iVar4 * 2 + 1] = param_1[1];
        param_1[1] = iVar6;
      }
    }
    piVar5 = param_2 + iVar4 * -2;
    iVar6 = *param_2;
    if (*(float *)(iVar6 + 0x40) <= *(float *)(*piVar5 + 0x40) &&
        *(float *)(*piVar5 + 0x40) != *(float *)(iVar6 + 0x40)) {
      *param_2 = *piVar5;
      *piVar5 = iVar6;
      iVar6 = param_2[1];
      param_2[1] = piVar5[1];
      piVar5[1] = iVar6;
      iVar6 = *param_2;
    }
    iVar3 = param_2[iVar4 * 2];
    pfVar1 = (float *)(iVar3 + 0x40);
    if (*pfVar1 <= *(float *)(iVar6 + 0x40) && *(float *)(iVar6 + 0x40) != *pfVar1) {
      param_2[iVar4 * 2] = iVar6;
      *param_2 = iVar3;
      iVar6 = param_2[iVar4 * 2 + 1];
      param_2[iVar4 * 2 + 1] = param_2[1];
      param_2[1] = iVar6;
      iVar6 = *param_2;
      fVar2 = *(float *)(*piVar5 + 0x40);
      pfVar1 = (float *)(iVar6 + 0x40);
      if (*pfVar1 <= fVar2 && fVar2 != *pfVar1) {
        *param_2 = *piVar5;
        *piVar5 = iVar6;
        iVar6 = param_2[1];
        param_2[1] = piVar5[1];
        piVar5[1] = iVar6;
      }
    }
    piVar7 = param_3 + iVar4 * -2;
    piVar5 = param_3 + iVar4 * -4;
    iVar6 = *piVar7;
    fVar2 = *(float *)(*piVar5 + 0x40);
    if (*(float *)(iVar6 + 0x40) <= fVar2 && fVar2 != *(float *)(iVar6 + 0x40)) {
      *piVar7 = *piVar5;
      *piVar5 = iVar6;
      iVar6 = piVar7[1];
      piVar7[1] = piVar5[1];
      piVar5[1] = iVar6;
      iVar6 = *piVar7;
    }
    iVar3 = *param_3;
    pfVar1 = (float *)(iVar3 + 0x40);
    if (*pfVar1 <= *(float *)(iVar6 + 0x40) && *(float *)(iVar6 + 0x40) != *pfVar1) {
      *param_3 = iVar6;
      *piVar7 = iVar3;
      iVar6 = param_3[1];
      param_3[1] = piVar7[1];
      piVar7[1] = iVar6;
      iVar6 = *piVar7;
      fVar2 = *(float *)(*piVar5 + 0x40);
      pfVar1 = (float *)(iVar6 + 0x40);
      if (*pfVar1 <= fVar2 && fVar2 != *pfVar1) {
        *piVar7 = *piVar5;
        *piVar5 = iVar6;
        iVar6 = piVar7[1];
        piVar7[1] = piVar5[1];
        piVar5[1] = iVar6;
      }
    }
    iVar6 = *param_2;
    fVar2 = *(float *)(param_1[iVar4 * 2] + 0x40);
    if (*(float *)(iVar6 + 0x40) <= fVar2 && fVar2 != *(float *)(iVar6 + 0x40)) {
      *param_2 = param_1[iVar4 * 2];
      param_1[iVar4 * 2] = iVar6;
      iVar6 = param_2[1];
      param_2[1] = param_1[iVar4 * 2 + 1];
      param_1[iVar4 * 2 + 1] = iVar6;
      iVar6 = *param_2;
    }
    iVar3 = *piVar7;
    pfVar1 = (float *)(iVar3 + 0x40);
    if (*pfVar1 <= *(float *)(iVar6 + 0x40) && *(float *)(iVar6 + 0x40) != *pfVar1) {
      *piVar7 = iVar6;
      *param_2 = iVar3;
      iVar6 = piVar7[1];
      piVar7[1] = param_2[1];
      param_2[1] = iVar6;
      iVar6 = *param_2;
      fVar2 = *(float *)(param_1[iVar4 * 2] + 0x40);
      pfVar1 = (float *)(iVar6 + 0x40);
      if (*pfVar1 <= fVar2 && fVar2 != *pfVar1) {
        *param_2 = param_1[iVar4 * 2];
        param_1[iVar4 * 2] = iVar6;
        iVar6 = param_2[1];
        param_2[1] = param_1[iVar4 * 2 + 1];
        param_1[iVar4 * 2 + 1] = iVar6;
      }
    }
  }
  return;
}



/* FUNCTION 10926 ; VA 0x00774490 ; FUN_00774490 */

void __thiscall
FUN_00774490(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  if (0xaaaaaa8 < (uint)param_1[1]) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  piVar3 = (int *)FUN_00773f80(param_5);
  param_1[1] = param_1[1] + 1;
  piVar3[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = piVar3;
    *(int **)*param_1 = piVar3;
    iVar4 = *param_1;
  }
  else {
    if (param_3 != '\0') {
      *param_4 = piVar3;
      if (param_4 == *(undefined4 **)*param_1) {
        *(int **)*param_1 = piVar3;
      }
      goto LAB_007744e8;
    }
    param_4[2] = piVar3;
    iVar4 = *param_1;
    if (param_4 != *(undefined4 **)(iVar4 + 8)) goto LAB_007744e8;
  }
  *(int **)(iVar4 + 8) = piVar3;
LAB_007744e8:
  cVar1 = *(char *)(piVar3[1] + 0xc);
  piVar6 = piVar3;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = piVar3;
      return;
    }
    piVar2 = (int *)piVar6[1];
    piVar5 = *(int **)piVar2[1];
    if (piVar2 == piVar5) {
      piVar5 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar5 + 3) == '\0') {
LAB_00774541:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar5 + 3) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        piVar6 = *(int **)(piVar6[1] + 4);
      }
      else {
        if (piVar6 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar6 = piVar2;
        }
        *(undefined *)(piVar6[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar6[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar5 + 3) == '\0') goto LAB_00774541;
      if (piVar6 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar6 = piVar2;
      }
      *(undefined *)(piVar6[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
      iVar4 = *(int *)(piVar6[1] + 4);
      piVar2 = *(int **)(iVar4 + 8);
      *(int *)(iVar4 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar4;
      }
      piVar2[1] = *(int *)(iVar4 + 4);
      if (iVar4 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar5 = *(int **)(iVar4 + 4);
        if (iVar4 == *piVar5) {
          *piVar5 = (int)piVar2;
        }
        else {
          piVar5[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar4;
      *(int **)(iVar4 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar6[1] + 0xc);
  } while( true );
}



/* FUNCTION 10927 ; VA 0x007745f0 ; FUN_007745f0 */

undefined4 * __thiscall
FUN_007745f0(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af140;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_0055a140(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar2 = FUN_00570370(param_4,param_3 + 4);
    if (cVar2 != '\0') {
      FUN_0055a140(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar1 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar2 = FUN_00570370(iVar1 + 0x10,param_4);
    if (cVar2 != '\0') {
      FUN_0055a140(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_00570370(param_4,param_3 + 4);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar2 = FUN_00570370(*piVar3 + 0x10,param_4);
      if (cVar2 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_0055a140(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_0055a140(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar2 = FUN_00570370(param_3 + 4,param_4);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      FUN_00551320();
      piVar3 = piStack_18;
      if ((piStack_18 == (int *)*param_1) ||
         (cVar2 = FUN_00570370(param_4,piStack_18 + 4), cVar2 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_0055a140(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_0055a140(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = (undefined4 *)FUN_00774830(auStack_20,0,param_4,param_5);
  *param_2 = *puVar4;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10928 ; VA 0x00774812 ; Catch_All@00774812 */

void Catch_All_00774812(void)

{
  int unaff_EBP;
  
  FUN_005763d0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10929 ; VA 0x00774830 ; FUN_00774830 */

void __thiscall
FUN_00774830(int *param_1,undefined4 *param_2,char param_3,byte *param_4,undefined4 param_5)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  byte bVar5;
  char cVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  byte *pbVar10;
  byte *pbVar11;
  undefined4 *puVar12;
  bool bVar13;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af150;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar5 = 1;
  puVar9 = (undefined4 *)((undefined4 *)*param_1)[1];
  cVar6 = *(char *)((int)puVar9 + 0xd);
  puVar3 = (undefined4 *)*param_1;
  while (cVar6 == '\0') {
    pbVar10 = (byte *)(puVar9 + 4);
    if (param_3 == '\0') {
      uVar1 = puVar9[8];
      if (0xf < (uint)puVar9[9]) {
        pbVar10 = *(byte **)pbVar10;
      }
      uVar7 = *(uint *)(param_4 + 0x10);
      pbVar11 = param_4;
      if (0xf < *(uint *)(param_4 + 0x14)) {
        pbVar11 = *(byte **)param_4;
      }
      uVar8 = uVar7;
      if (uVar1 < uVar7) {
        uVar8 = uVar1;
      }
      while (uVar2 = uVar8 - 4, 3 < uVar8) {
        if (*(int *)pbVar11 != *(int *)pbVar10) goto LAB_00774966;
        pbVar11 = pbVar11 + 4;
        pbVar10 = pbVar10 + 4;
        uVar8 = uVar2;
      }
      if (uVar2 == 0xfffffffc) {
LAB_0077499a:
        uVar8 = 0;
      }
      else {
LAB_00774966:
        bVar13 = *pbVar11 < *pbVar10;
        if ((*pbVar11 == *pbVar10) &&
           ((uVar2 == 0xfffffffd ||
            ((bVar13 = pbVar11[1] < pbVar10[1], pbVar11[1] == pbVar10[1] &&
             ((uVar2 == 0xfffffffe ||
              ((bVar13 = pbVar11[2] < pbVar10[2], pbVar11[2] == pbVar10[2] &&
               ((uVar2 == 0xffffffff || (bVar13 = pbVar11[3] < pbVar10[3], pbVar11[3] == pbVar10[3])
                ))))))))))) goto LAB_0077499a;
        uVar8 = -(uint)bVar13 | 1;
      }
      if (uVar8 == 0) {
        if (uVar7 < uVar1) {
          uVar8 = 0xffffffff;
        }
        else {
          uVar8 = 0;
        }
      }
      bVar5 = (byte)(uVar8 >> 0x1f);
    }
    else {
      pbVar11 = param_4;
      if (0xf < *(uint *)(param_4 + 0x14)) {
        pbVar11 = *(byte **)param_4;
      }
      uVar1 = puVar9[8];
      if (0xf < (uint)puVar9[9]) {
        pbVar10 = *(byte **)pbVar10;
      }
      uVar7 = uVar1;
      if (*(uint *)(param_4 + 0x10) < uVar1) {
        uVar7 = *(uint *)(param_4 + 0x10);
      }
      while (uVar8 = uVar7 - 4, 3 < uVar7) {
        if (*(int *)pbVar10 != *(int *)pbVar11) goto LAB_007748c6;
        pbVar10 = pbVar10 + 4;
        pbVar11 = pbVar11 + 4;
        uVar7 = uVar8;
      }
      if (uVar8 == 0xfffffffc) {
LAB_007748fa:
        uVar7 = 0;
      }
      else {
LAB_007748c6:
        bVar13 = *pbVar10 < *pbVar11;
        if ((*pbVar10 == *pbVar11) &&
           ((uVar8 == 0xfffffffd ||
            ((bVar13 = pbVar10[1] < pbVar11[1], pbVar10[1] == pbVar11[1] &&
             ((uVar8 == 0xfffffffe ||
              ((bVar13 = pbVar10[2] < pbVar11[2], pbVar10[2] == pbVar11[2] &&
               ((uVar8 == 0xffffffff || (bVar13 = pbVar10[3] < pbVar11[3], pbVar10[3] == pbVar11[3])
                ))))))))))) goto LAB_007748fa;
        uVar7 = -(uint)bVar13 | 1;
      }
      if (uVar7 == 0) {
        if (uVar1 < *(uint *)(param_4 + 0x10)) {
          bVar5 = 0;
          goto LAB_007749b6;
        }
        uVar7 = 0;
      }
      bVar5 = (byte)(uVar7 >> 0x1f) ^ 1;
    }
LAB_007749b6:
    if (bVar5 == 0) {
      puVar12 = (undefined4 *)puVar9[2];
    }
    else {
      puVar12 = (undefined4 *)*puVar9;
    }
    puVar3 = puVar9;
    puVar9 = puVar12;
    cVar6 = *(char *)((int)puVar12 + 0xd);
  }
  ExceptionList = &pvStack_10;
  _param_3 = puVar3;
  if (bVar5 != 0) {
    if (puVar3 == *(undefined4 **)*param_1) {
      bVar5 = 1;
      ExceptionList = &pvStack_10;
      pbVar10 = param_4;
      goto LAB_007749f1;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  pbVar10 = param_4;
  puVar9 = _param_3;
  cVar6 = FUN_00570370(_param_3 + 4,param_4);
  uVar4 = param_5;
  if (cVar6 == '\0') {
    FUN_0056cac0();
    FUN_01674ea0(uVar4,0x30);
    *param_2 = puVar9;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_007749f1:
  puVar9 = (undefined4 *)FUN_0055a140(&param_3,bVar5,puVar3,pbVar10,param_5);
  *param_2 = *puVar9;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10930 ; VA 0x00774a79 ; Catch_All@00774a79 */

void Catch_All_00774a79(void)

{
  int unaff_EBP;
  
  FUN_005763d0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10931 ; VA 0x00774a90 ; FUN_00774a90 */

undefined4 * __thiscall
FUN_00774a90(undefined4 *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  bool bVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af160;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar7 = true;
  piVar2 = (int *)*param_1;
  piVar6 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    piVar5 = (int *)piVar2[1];
    do {
      piVar6 = piVar5;
      if (param_3 == '\0') {
        bVar7 = *param_4 < (uint)piVar6[4];
      }
      else {
        bVar7 = *param_4 <= (uint)piVar6[4];
      }
      if (bVar7 == false) {
        piVar5 = (int *)piVar6[2];
      }
      else {
        piVar5 = (int *)*piVar6;
      }
    } while (*(char *)((int)piVar5 + 0xd) == '\0');
  }
  piVar5 = piVar6;
  if (bVar7 != false) {
    if (piVar6 == (int *)*piVar2) {
      bVar7 = true;
      goto LAB_00774b23;
    }
    if (*(char *)((int)piVar6 + 0xd) == '\0') {
      piVar5 = (int *)*piVar6;
      if (*(char *)((int)piVar5 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar5[2] + 0xd);
        piVar2 = (int *)piVar5[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar5 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar6[1] + 0xd);
        piVar2 = (int *)piVar6[1];
        piVar5 = piVar6;
        while ((piVar3 = piVar2, cVar1 == '\0' && (piVar5 == (int *)*piVar3))) {
          cVar1 = *(char *)(piVar3[1] + 0xd);
          piVar2 = (int *)piVar3[1];
          piVar5 = piVar3;
        }
        if (*(char *)((int)piVar5 + 0xd) == '\0') {
          piVar5 = piVar3;
        }
      }
    }
    else {
      piVar5 = (int *)piVar6[2];
    }
  }
  if (*param_4 <= (uint)piVar5[4]) {
    *param_2 = piVar5;
    *(undefined *)(param_2 + 1) = 0;
    return param_2;
  }
LAB_00774b23:
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_00774490(&param_3,bVar7,piVar6,param_4,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 10932 ; VA 0x00774be0 ; Catch_All@00774be0 */

void Catch_All_00774be0(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10933 ; VA 0x00774bf0 ; FUN_00774bf0 */

void __thiscall FUN_00774bf0(int *param_1,int param_2,int param_3,int param_4)

{
  bool bVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  
  uVar6 = param_4 - param_3 >> 3;
  iVar2 = param_2 - *param_1 >> 3;
  if ((uVar6 == 1) && (param_2 == param_1[1])) {
    bVar1 = true;
  }
  else {
    bVar1 = false;
    if (uVar6 == 0) {
      return;
    }
  }
  iVar9 = param_1[1];
  if (uVar6 <= (uint)(param_1[2] - iVar9 >> 3)) {
    iVar2 = uVar6 * 8 + param_2;
    if (uVar6 < (uint)(iVar9 - param_2 >> 3)) {
      iVar4 = iVar9 + uVar6 * -8;
      iVar5 = FUN_005c23f0(iVar4,iVar9,iVar9,param_1);
      param_1[1] = iVar5;
      FUN_007752e0(param_2,iVar4,iVar9);
      FUN_005596d0(param_2,iVar2,param_1);
    }
    else {
      iVar2 = FUN_005c23f0(param_2,iVar9,iVar2,param_1);
      param_1[1] = iVar2;
      FUN_005596d0(param_2,iVar9,param_1);
    }
    FUN_0055c480(param_3,param_4,param_2);
    return;
  }
  iVar9 = iVar9 - *param_1 >> 3;
  if (uVar6 <= 0x1fffffffU - iVar9) {
    uVar7 = uVar6 + iVar9;
    uVar8 = param_1[2] - *param_1 >> 3;
    uVar3 = uVar7;
    if ((uVar8 <= 0x1fffffff - (uVar8 >> 1)) && (uVar3 = (uVar8 >> 1) + uVar8, uVar3 < uVar7)) {
      uVar3 = uVar7;
    }
    iVar4 = FUN_00578020(uVar3);
    FUN_0055c480(param_3,param_4,iVar4 + iVar2 * 8);
    iVar9 = *param_1;
    iVar5 = iVar4;
    if (!bVar1) {
      FUN_005c23f0(iVar9,param_2,iVar4,param_1);
      iVar5 = iVar4 + (uVar6 + iVar2) * 8;
      iVar9 = param_2;
    }
    FUN_005c23f0(iVar9,param_1[1],iVar5,param_1);
    FUN_005c5230(iVar4,uVar7,uVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 10934 ; VA 0x00774d70 ; FUN_00774d70 */

void __thiscall FUN_00774d70(int *param_1,int param_2,int *param_3,int *param_4)

{
  char cVar1;
  bool bVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  
  uVar11 = 0;
  piVar4 = param_3;
  if (param_3 != param_4) {
    do {
      piVar5 = (int *)piVar4[2];
      uVar11 = uVar11 + 1;
      if (*(char *)((int)piVar5 + 0xd) == '\0') {
        cVar1 = *(char *)(*piVar5 + 0xd);
        piVar4 = (int *)*piVar5;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*piVar4 + 0xd);
          piVar5 = piVar4;
          piVar4 = (int *)*piVar4;
        }
      }
      else {
        cVar1 = *(char *)(piVar4[1] + 0xd);
        piVar3 = (int *)piVar4[1];
        while ((piVar5 = piVar3, cVar1 == '\0' && (piVar4 == (int *)piVar5[2]))) {
          cVar1 = *(char *)(piVar5[1] + 0xd);
          piVar3 = (int *)piVar5[1];
          piVar4 = piVar5;
        }
      }
      piVar4 = piVar5;
    } while (piVar5 != param_4);
  }
  iVar6 = param_2 - *param_1 >> 3;
  if ((uVar11 == 1) && (param_2 == param_1[1])) {
    bVar2 = true;
  }
  else {
    bVar2 = false;
    if (uVar11 == 0) {
      return;
    }
  }
  iVar12 = param_1[1];
  if (uVar11 <= (uint)(param_1[2] - iVar12 >> 3)) {
    iVar6 = param_2 + uVar11 * 8;
    if (uVar11 < (uint)(iVar12 - param_2 >> 3)) {
      iVar8 = iVar12 + uVar11 * -8;
      iVar9 = FUN_005c23f0(iVar8,iVar12,iVar12,param_1);
      param_1[1] = iVar9;
      FUN_007752e0(param_2,iVar8,iVar12);
      FUN_005596d0(param_2,iVar6,param_1);
    }
    else {
      iVar6 = FUN_005c23f0(param_2,iVar12,iVar6,param_1);
      param_1[1] = iVar6;
      FUN_005596d0(param_2,iVar12,param_1);
    }
    FUN_00775d60(param_3,param_4,param_2);
    return;
  }
  iVar12 = iVar12 - *param_1 >> 3;
  if (0x1fffffffU - iVar12 < uVar11) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar13 = iVar12 + uVar11;
  uVar10 = param_1[2] - *param_1 >> 3;
  uVar7 = uVar13;
  if ((uVar10 <= 0x1fffffff - (uVar10 >> 1)) && (uVar7 = (uVar10 >> 1) + uVar10, uVar7 < uVar13)) {
    uVar7 = uVar13;
  }
  iVar8 = FUN_00578020(uVar7);
  FUN_00775d60(param_3,param_4,iVar8 + iVar6 * 8);
  iVar12 = *param_1;
  iVar9 = iVar8;
  if (!bVar2) {
    FUN_005c23f0(iVar12,param_2,iVar8,param_1);
    iVar9 = iVar8 + (uVar11 + iVar6) * 8;
    iVar12 = param_2;
  }
  FUN_005c23f0(iVar12,param_1[1],iVar9,param_1);
  FUN_005c5230(iVar8,uVar13,uVar7);
  return;
}



/* FUNCTION 10935 ; VA 0x00774f50 ; FUN_00774f50 */

int * FUN_00774f50(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  
  if (param_1 != param_2) {
    for (piVar8 = param_1 + 2; piVar8 != param_2; piVar8 = piVar8 + 2) {
      iVar1 = *piVar8;
      iVar2 = piVar8[1];
      *piVar8 = 0;
      piVar8[1] = 0;
      if (*(float *)(*param_1 + 0x40) <= *(float *)(iVar1 + 0x40)) {
        iVar7 = piVar8[-2];
        piVar6 = piVar8;
        piVar5 = piVar8;
        piVar4 = piVar8 + -2;
        if (*(float *)(iVar1 + 0x40) < *(float *)(iVar7 + 0x40)) {
          do {
            piVar6 = piVar4;
            iVar3 = piVar6[1];
            *piVar6 = 0;
            piVar6[1] = 0;
            *piVar5 = iVar7;
            piVar4 = (int *)piVar5[1];
            piVar5[1] = iVar3;
            if (piVar4 != (int *)0x0) {
              LOCK();
              iVar7 = piVar4[1] + -1;
              piVar4[1] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)*piVar4)();
                LOCK();
                iVar7 = piVar4[2] + -1;
                piVar4[2] = iVar7;
                UNLOCK();
                if (iVar7 == 0) {
                  (**(code **)(*piVar4 + 4))();
                }
              }
            }
            iVar7 = piVar6[-2];
            piVar5 = piVar6;
            piVar4 = piVar6 + -2;
          } while (*(float *)(iVar1 + 0x40) <= *(float *)(iVar7 + 0x40) &&
                   *(float *)(iVar7 + 0x40) != *(float *)(iVar1 + 0x40));
        }
        *piVar6 = iVar1;
        piVar5 = (int *)piVar6[1];
        piVar6[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
      }
      else {
        if (piVar8 != param_1) {
          piVar6 = piVar8 + 2;
          piVar5 = piVar8 + -1;
          do {
            iVar7 = piVar5[-1];
            iVar3 = *piVar5;
            piVar5[-1] = 0;
            *piVar5 = 0;
            piVar6[-2] = iVar7;
            piVar4 = (int *)piVar6[-1];
            piVar6[-1] = iVar3;
            if (piVar4 != (int *)0x0) {
              LOCK();
              iVar7 = piVar4[1] + -1;
              piVar4[1] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)*piVar4)();
                LOCK();
                iVar7 = piVar4[2] + -1;
                piVar4[2] = iVar7;
                UNLOCK();
                if (iVar7 == 0) {
                  (**(code **)(*piVar4 + 4))();
                }
              }
            }
            piVar4 = piVar5 + -1;
            piVar6 = piVar6 + -2;
            piVar5 = piVar5 + -2;
          } while (piVar4 != param_1);
        }
        *param_1 = iVar1;
        piVar6 = (int *)param_1[1];
        param_1[1] = iVar2;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar1 = piVar6[1] + -1;
          piVar6[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar1 = piVar6[2] + -1;
            piVar6[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
      }
    }
  }
  return param_2;
}



/* FUNCTION 10936 ; VA 0x00775100 ; FUN_00775100 */

void FUN_00775100(int param_1,int param_2)

{
  float *pfVar1;
  float fVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  
  uVar10 = param_2 - param_1 >> 3;
  iVar9 = param_2 - param_1 >> 4;
  if (0 < iVar9) {
    iVar11 = uVar10 - 1;
    do {
      iVar3 = *(int *)(param_1 + -8 + iVar9 * 8);
      iVar9 = iVar9 + -1;
      uVar4 = *(undefined4 *)(param_1 + 4 + iVar9 * 8);
      *(undefined4 *)(param_1 + iVar9 * 8) = 0;
      *(undefined4 *)(param_1 + 4 + iVar9 * 8) = 0;
      iVar8 = iVar9;
      while (iVar8 < iVar11 >> 1) {
        fVar2 = *(float *)(*(int *)(param_1 + 8 + iVar8 * 0x10) + 0x40);
        pfVar1 = (float *)(*(int *)(param_1 + 0x10 + iVar8 * 0x10) + 0x40);
        iVar12 = iVar8 * 2 + ((*pfVar1 <= fVar2 && fVar2 != *pfVar1) ^ 1) + 1;
        uVar5 = *(undefined4 *)(param_1 + iVar12 * 8);
        uVar6 = *(undefined4 *)(param_1 + 4 + iVar12 * 8);
        *(undefined4 *)(param_1 + iVar12 * 8) = 0;
        *(undefined4 *)(param_1 + 4 + iVar12 * 8) = 0;
        *(undefined4 *)(param_1 + iVar8 * 8) = uVar5;
        piVar7 = *(int **)(param_1 + 4 + iVar8 * 8);
        *(undefined4 *)(param_1 + 4 + iVar8 * 8) = uVar6;
        iVar8 = iVar12;
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar12 = piVar7[1] + -1;
          piVar7[1] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            iVar12 = piVar7[2] + -1;
            piVar7[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
      }
      if ((iVar8 == iVar11 >> 1) && ((uVar10 & 1) == 0)) {
        uVar5 = *(undefined4 *)(param_1 + -8 + uVar10 * 8);
        uVar6 = *(undefined4 *)(param_1 + -4 + uVar10 * 8);
        *(undefined4 *)(param_1 + -8 + uVar10 * 8) = 0;
        *(undefined4 *)(param_1 + -4 + uVar10 * 8) = 0;
        *(undefined4 *)(param_1 + iVar8 * 8) = uVar5;
        piVar7 = *(int **)(param_1 + 4 + iVar8 * 8);
        *(undefined4 *)(param_1 + 4 + iVar8 * 8) = uVar6;
        iVar8 = iVar11;
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar12 = piVar7[1] + -1;
          piVar7[1] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            iVar12 = piVar7[2] + -1;
            piVar7[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
      }
      while (iVar9 < iVar8) {
        iVar13 = iVar8 + -1 >> 1;
        iVar12 = *(int *)(param_1 + iVar13 * 8);
        fVar2 = *(float *)(iVar3 + 0x40);
        pfVar1 = (float *)(iVar12 + 0x40);
        if (fVar2 < *pfVar1 || fVar2 == *pfVar1) break;
        uVar5 = *(undefined4 *)(param_1 + 4 + iVar13 * 8);
        *(undefined4 *)(param_1 + iVar13 * 8) = 0;
        *(undefined4 *)(param_1 + 4 + iVar13 * 8) = 0;
        *(int *)(param_1 + iVar8 * 8) = iVar12;
        piVar7 = *(int **)(param_1 + 4 + iVar8 * 8);
        *(undefined4 *)(param_1 + 4 + iVar8 * 8) = uVar5;
        iVar8 = iVar13;
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar12 = piVar7[1] + -1;
          piVar7[1] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            iVar12 = piVar7[2] + -1;
            piVar7[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
      }
      *(int *)(param_1 + iVar8 * 8) = iVar3;
      piVar7 = *(int **)(param_1 + 4 + iVar8 * 8);
      *(undefined4 *)(param_1 + 4 + iVar8 * 8) = uVar4;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar3 = piVar7[1] + -1;
        piVar7[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar3 = piVar7[2] + -1;
          piVar7[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
    } while (0 < iVar9);
  }
  return;
}



/* FUNCTION 10937 ; VA 0x007752e0 ; FUN_007752e0 */

undefined4 * FUN_007752e0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  if (param_2 != param_1) {
    puVar6 = param_3;
    puVar7 = param_2 + -1;
    do {
      uVar2 = puVar7[-1];
      param_3 = puVar6 + -2;
      uVar3 = *puVar7;
      puVar7[-1] = 0;
      *puVar7 = 0;
      *param_3 = uVar2;
      piVar4 = (int *)puVar6[-1];
      puVar6[-1] = uVar3;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      puVar1 = puVar7 + -1;
      puVar6 = param_3;
      puVar7 = puVar7 + -2;
    } while (puVar1 != param_1);
  }
  return param_3;
}



/* FUNCTION 10938 ; VA 0x00775350 ; FUN_00775350 */

undefined4 * FUN_00775350(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  puVar5 = param_1;
  puVar6 = param_3;
  if (param_1 != param_2) {
    do {
      uVar1 = *puVar5;
      uVar2 = *(undefined4 *)((int)param_1 + (4 - (int)param_3) + (int)puVar6);
      *puVar5 = 0;
      *(undefined4 *)((int)param_1 + (4 - (int)param_3) + (int)puVar6) = 0;
      *puVar6 = uVar1;
      piVar3 = (int *)puVar6[1];
      puVar6[1] = uVar2;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      puVar5 = puVar5 + 2;
      puVar6 = puVar6 + 2;
    } while (puVar5 != param_2);
  }
  return puVar6;
}



/* FUNCTION 10939 ; VA 0x007753d0 ; FUN_007753d0 */

void FUN_007753d0(undefined4 *param_1,int *param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  float fVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piVar7 = param_2 + ((int)param_3 - (int)param_2 >> 4) * 2;
  FUN_00774200(param_2,piVar7,param_3 + -2,param_4);
  piVar6 = piVar7 + 2;
  for (; param_2 < piVar7; piVar7 = piVar7 + -2) {
    if ((*(float *)(piVar7[-2] + 0x40) < *(float *)(*piVar7 + 0x40)) ||
       (*(float *)(*piVar7 + 0x40) < *(float *)(piVar7[-2] + 0x40))) break;
  }
  piVar9 = piVar6;
  piStack_10 = piVar6;
  piStack_8 = piVar6;
  piStack_c = piVar7;
  piVar8 = piVar7;
  if (piVar6 < param_3) {
    do {
      piVar9 = piVar6;
      piStack_10 = piVar6;
      piStack_8 = piVar6;
      if ((*(float *)(*piVar6 + 0x40) < *(float *)(*piVar7 + 0x40)) ||
         (*(float *)(*piVar7 + 0x40) < *(float *)(*piVar6 + 0x40))) break;
      piVar6 = piVar6 + 2;
      piVar9 = piVar6;
      piStack_10 = piVar6;
      piStack_8 = piVar6;
    } while (piVar6 < param_3);
  }
joined_r0x00775472:
  do {
    piVar1 = piStack_c;
    if (param_3 <= piVar9) {
joined_r0x007754bd:
      while (piVar5 = piVar8, piVar4 = piVar7, piVar10 = piVar9, piStack_c = piVar1, piVar8 = piVar5
            , param_2 < piVar4) {
        piVar1 = piVar4 + -2;
        piVar6 = piStack_8;
        piVar7 = piVar1;
        piVar9 = piStack_10;
        if (*(float *)(*piVar5 + 0x40) <= *(float *)(piVar4[-2] + 0x40)) {
          piVar10 = piStack_10;
          piStack_c = piVar4;
          if (*(float *)(*piVar5 + 0x40) < *(float *)(piVar4[-2] + 0x40)) break;
          piVar8 = piVar5 + -2;
          if (piVar8 != piVar4 + -2) {
            iVar3 = *piVar8;
            *piVar8 = *piVar1;
            *piVar1 = iVar3;
            iVar3 = piVar5[-1];
            piVar5[-1] = piVar4[-1];
            piVar4[-1] = iVar3;
          }
        }
      }
      if (piVar4 == param_2) {
        if (piVar10 == param_3) {
          *param_1 = piVar5;
          param_1[1] = piVar6;
          return;
        }
        if (piVar6 != piVar10) {
          iVar3 = *piVar5;
          *piVar5 = *piVar6;
          *piVar6 = iVar3;
          iVar3 = piVar5[1];
          piVar5[1] = piVar6[1];
          piVar6[1] = iVar3;
        }
        iVar3 = *piVar5;
        piVar6 = piVar6 + 2;
        *piVar5 = *piVar10;
        *piVar10 = iVar3;
        iVar3 = piVar5[1];
        piVar5[1] = piVar10[1];
        piVar10[1] = iVar3;
        piVar7 = piVar4;
        piVar9 = piVar10 + 2;
        piStack_10 = piVar10 + 2;
        piStack_8 = piVar6;
        piVar8 = piVar5 + 2;
      }
      else {
        piVar7 = piVar4 + -2;
        piStack_c = piVar7;
        if (piVar10 == param_3) {
          piVar8 = piVar5 + -2;
          if (piVar7 != piVar8) {
            iVar3 = *piVar7;
            *piVar7 = *piVar8;
            *piVar8 = iVar3;
            iVar3 = piVar4[-1];
            piVar4[-1] = piVar5[-1];
            piVar5[-1] = iVar3;
          }
          iVar3 = *piVar8;
          piStack_8 = piVar6 + -2;
          *piVar8 = *piStack_8;
          *piStack_8 = iVar3;
          iVar3 = piVar5[-1];
          piVar5[-1] = piVar6[-1];
          piVar6[-1] = iVar3;
          piVar6 = piStack_8;
          piVar9 = piVar10;
        }
        else {
          iVar3 = *piVar10;
          *piVar10 = *piVar7;
          *piVar7 = iVar3;
          iVar3 = piVar10[1];
          piVar10[1] = piVar4[-1];
          piVar4[-1] = iVar3;
          piVar9 = piVar10 + 2;
          piStack_10 = piVar10 + 2;
        }
      }
      goto joined_r0x00775472;
    }
    fVar2 = *(float *)(*piVar9 + 0x40);
    piVar7 = piStack_c;
    if (fVar2 <= *(float *)(*piVar8 + 0x40)) {
      piStack_8 = piVar6;
      piStack_10 = piVar9;
      if (fVar2 < *(float *)(*piVar8 + 0x40)) goto joined_r0x007754bd;
      if (piVar6 != piVar9) {
        iVar3 = *piVar6;
        *piVar6 = *piVar9;
        *piVar9 = iVar3;
        iVar3 = piVar6[1];
        piVar6[1] = piVar9[1];
        piVar9[1] = iVar3;
      }
      piVar6 = piVar6 + 2;
    }
    piVar9 = piVar9 + 2;
    piStack_10 = piVar9;
    piStack_8 = piVar6;
  } while( true );
}



/* FUNCTION 10940 ; VA 0x007755e0 ; FUN_007755e0 */

int FUN_007755e0(int param_1,int param_2,uint param_3,int *param_4)

{
  float *pfVar1;
  int *piVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  
  iVar7 = (int)(param_3 - 1) >> 1;
  iVar8 = param_2;
  iVar9 = param_2;
  if (param_2 < iVar7) {
    do {
      fVar3 = *(float *)(*(int *)(param_1 + 8 + iVar8 * 0x10) + 0x40);
      pfVar1 = (float *)(*(int *)(param_1 + 0x10 + iVar8 * 0x10) + 0x40);
      iVar9 = iVar8 * 2 + ((*pfVar1 <= fVar3 && fVar3 != *pfVar1) ^ 1) + 1;
      uVar4 = *(undefined4 *)(param_1 + iVar9 * 8);
      uVar5 = *(undefined4 *)(param_1 + 4 + iVar9 * 8);
      *(undefined4 *)(param_1 + iVar9 * 8) = 0;
      *(undefined4 *)(param_1 + 4 + iVar9 * 8) = 0;
      *(undefined4 *)(param_1 + iVar8 * 8) = uVar4;
      piVar6 = *(int **)(param_1 + 4 + iVar8 * 8);
      *(undefined4 *)(param_1 + 4 + iVar8 * 8) = uVar5;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar8 = piVar6[1] + -1;
        piVar6[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar8 = piVar6[2] + -1;
          piVar6[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      iVar8 = iVar9;
    } while (iVar9 < iVar7);
  }
  if ((iVar9 == iVar7) && ((param_3 & 1) == 0)) {
    FUN_005587e0(param_1 + (param_3 - 1) * 8);
    iVar9 = param_3 - 1;
  }
  while (param_2 < iVar9) {
    iVar7 = iVar9 + -1 >> 1;
    iVar8 = *(int *)(param_1 + iVar7 * 8);
    pfVar1 = (float *)(iVar8 + 0x40);
    if (*(float *)(*param_4 + 0x40) < *pfVar1 || *(float *)(*param_4 + 0x40) == *pfVar1) break;
    uVar4 = *(undefined4 *)(param_1 + 4 + iVar7 * 8);
    *(undefined4 *)(param_1 + iVar7 * 8) = 0;
    *(undefined4 *)(param_1 + 4 + iVar7 * 8) = 0;
    *(int *)(param_1 + iVar9 * 8) = iVar8;
    piVar6 = *(int **)(param_1 + 4 + iVar9 * 8);
    *(undefined4 *)(param_1 + 4 + iVar9 * 8) = uVar4;
    iVar9 = iVar7;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar8 = piVar6[1] + -1;
      piVar6[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar8 = piVar6[2] + -1;
        piVar6[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  iVar8 = *param_4;
  iVar7 = param_4[1];
  *param_4 = 0;
  param_4[1] = 0;
  *(int *)(param_1 + iVar9 * 8) = iVar8;
  piVar6 = *(int **)(param_1 + 4 + iVar9 * 8);
  *(int *)(param_1 + 4 + iVar9 * 8) = iVar7;
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar2 = piVar6 + 1;
    iVar9 = *piVar2;
    iVar8 = *piVar2;
    *piVar2 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      iVar8 = (**(code **)*piVar6)();
      LOCK();
      piVar2 = piVar6 + 2;
      iVar9 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        iVar8 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  return iVar8;
}



/* FUNCTION 10941 ; VA 0x00775760 ; FUN_00775760 */

void __thiscall FUN_00775760(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  uint uVar12;
  int iVar13;
  
  iVar7 = param_1[1];
  iVar13 = *param_1;
  uVar12 = iVar7 - iVar13 >> 5;
  uVar8 = param_1[2] - iVar13 >> 5;
  if (param_2 <= uVar8) {
    if (uVar12 < param_2) {
      iVar7 = FUN_00777610(iVar7,param_2 - uVar12);
      param_1[1] = iVar7;
      return;
    }
    if (param_2 != uVar12) {
      iVar13 = param_2 * 0x20 + iVar13;
      FUN_00559500(iVar13,iVar7,param_1);
      param_1[1] = iVar13;
    }
    return;
  }
  if (0x7ffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = param_2;
  if ((uVar8 <= 0x7ffffff - (uVar8 >> 1)) && (uVar5 = (uVar8 >> 1) + uVar8, uVar5 < param_2)) {
    uVar5 = param_2;
  }
  uVar8 = uVar5 * 0x20;
  if (uVar5 < 0x8000000) {
    if (0xfff < uVar8) goto LAB_007757cd;
    if (uVar8 == 0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      puVar9 = (undefined4 *)FUN_01674e20(uVar8);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_007757cd:
    uVar6 = uVar8 + 0x23;
    if (uVar6 <= uVar8) {
      uVar6 = 0xffffffff;
    }
    iVar7 = FUN_01674e20(uVar6);
    if (iVar7 == 0) goto LAB_0077591e;
    puVar9 = (undefined4 *)(iVar7 + 0x23U & 0xffffffe0);
    puVar9[-1] = iVar7;
  }
  FUN_00777610(puVar9 + uVar12 * 8,param_2 - uVar12);
  puVar1 = (undefined4 *)param_1[1];
  puVar11 = puVar9;
  for (puVar10 = (undefined4 *)*param_1; puVar10 != puVar1; puVar10 = puVar10 + 8) {
    puVar11[4] = 0;
    puVar11[5] = 0;
    uVar2 = puVar10[1];
    uVar3 = puVar10[2];
    uVar4 = puVar10[3];
    *puVar11 = *puVar10;
    puVar11[1] = uVar2;
    puVar11[2] = uVar3;
    puVar11[3] = uVar4;
    *(undefined8 *)(puVar11 + 4) = *(undefined8 *)(puVar10 + 4);
    puVar10[4] = 0;
    puVar10[5] = 0xf;
    *(undefined *)puVar10 = 0;
    puVar11[6] = puVar10[6];
    *(undefined *)(puVar11 + 7) = *(undefined *)(puVar10 + 7);
    puVar11 = puVar11 + 8;
  }
  FUN_00559500(puVar11,puVar11,param_1);
  if (*param_1 != 0) {
    FUN_00559500(*param_1,param_1[1],param_1);
    iVar7 = *param_1;
    uVar8 = param_1[2] - iVar7 & 0xffffffe0;
    iVar13 = iVar7;
    if (0xfff < uVar8) {
      iVar13 = *(int *)(iVar7 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar7 - iVar13) - 4U) {
LAB_0077591e:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar13,uVar8);
  }
  *param_1 = (int)puVar9;
  param_1[1] = (int)(puVar9 + param_2 * 8);
  param_1[2] = (int)(puVar9 + uVar5 * 8);
  return;
}



/* FUNCTION 10942 ; VA 0x00775930 ; FUN_00775930 */

void __thiscall FUN_00775930(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af170;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::Graphics::GeometryBatch>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10943 ; VA 0x0077599e ; Catch_All@0077599e */

void Catch_All_0077599e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00777a80(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10944 ; VA 0x007759c0 ; FUN_007759c0 */

void __thiscall FUN_007759c0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af180;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::Graphics::TextureCompositor::Job>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10945 ; VA 0x00775a2e ; Catch_All@00775a2e */

void Catch_All_00775a2e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00777ad0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10946 ; VA 0x00775a50 ; FUN_00775a50 */

void __thiscall FUN_00775a50(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af190;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Graphics::TextureCompositorJob>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10947 ; VA 0x00775abe ; Catch_All@00775abe */

void Catch_All_00775abe(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00777cd0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10948 ; VA 0x00775ae0 ; FUN_00775ae0 */

void FUN_00775ae0(int *param_1,int param_2,int param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iStack_c;
  int *piStack_8;
  
  iVar4 = param_2 - (int)param_1;
  do {
    iVar4 = iVar4 >> 3;
    if (iVar4 < 0x21) {
LAB_00775b63:
      if (1 < iVar4) {
        FUN_00774f50(param_1,param_2,param_4);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar4) {
        FUN_00775100(param_1,param_2,param_4);
        iVar4 = param_2 - (int)param_1 >> 3;
        if (iVar4 < 2) {
          return;
        }
        piVar5 = (int *)(param_2 + -4);
        if (iVar4 < 2) goto LAB_00775c4f;
        do {
          iStack_c = piVar5[-1];
          piVar5[-1] = 0;
          piStack_8 = (int *)*piVar5;
          *piVar5 = 0;
          iVar4 = param_1[1];
          iVar2 = *param_1;
          *param_1 = 0;
          param_1[1] = 0;
          piVar5[-1] = iVar2;
          piVar3 = (int *)*piVar5;
          *piVar5 = iVar4;
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar4 = piVar3[1] + -1;
            piVar3[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              iVar4 = piVar3[2] + -1;
              piVar3[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          FUN_007755e0(param_1,0,(-4 - (int)param_1) + (int)piVar5 >> 3,&iStack_c,param_4);
          piVar3 = piStack_8;
          if (piStack_8 != (int *)0x0) {
            LOCK();
            iVar4 = piStack_8[1] + -1;
            piStack_8[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piStack_8)();
              LOCK();
              piVar1 = piVar3 + 2;
              iVar4 = *piVar1 + -1;
              *piVar1 = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
LAB_00775c4f:
          piVar5 = piVar5 + -2;
        } while (1 < (4 - (int)param_1) + (int)piVar5 >> 3);
        return;
      }
      goto LAB_00775b63;
    }
    FUN_007753d0(&iStack_c,param_1,param_2,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)(iStack_c - (int)param_1 & 0xfffffff8U) < (int)(param_2 - (int)piStack_8 & 0xfffffff8U)
       ) {
      FUN_00775ae0(param_1,iStack_c,param_3,param_4);
      param_1 = piStack_8;
    }
    else {
      FUN_00775ae0(piStack_8,param_2,param_3,param_4);
      param_2 = iStack_c;
    }
    iVar4 = param_2 - (int)param_1;
  } while( true );
}



/* FUNCTION 10949 ; VA 0x00775c70 ; FUN_00775c70 */

int FUN_00775c70(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017af1b0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  if (param_1 != param_2) {
    puVar5 = param_1 + 0xc;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      FUN_0054ef60(puVar5 + -0xc);
      uStack_8 = 1;
      FUN_0054ef60(puVar5 + -6);
      uVar2 = puVar5[1];
      uVar3 = puVar5[2];
      uVar4 = puVar5[3];
      puVar1 = puVar5 + 9;
      *(undefined4 *)(param_3 + 0x30) = *puVar5;
      *(undefined4 *)(param_3 + 0x34) = uVar2;
      *(undefined4 *)(param_3 + 0x38) = uVar3;
      *(undefined4 *)(param_3 + 0x3c) = uVar4;
      uVar2 = puVar5[5];
      uVar3 = puVar5[6];
      uVar4 = puVar5[7];
      *(undefined4 *)(param_3 + 0x40) = puVar5[4];
      *(undefined4 *)(param_3 + 0x44) = uVar2;
      *(undefined4 *)(param_3 + 0x48) = uVar3;
      *(undefined4 *)(param_3 + 0x4c) = uVar4;
      *(undefined4 *)(param_3 + 0x50) = puVar5[8];
      param_3 = param_3 + 0x54;
      puVar5 = puVar5 + 0x15;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 10950 ; VA 0x00775d10 ; FUN_00775d10 */

void FUN_00775d10(int param_1,int param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    param_1 = param_1 - (int)param_3;
    do {
      *param_3 = 0;
      param_3[1] = 0;
      iVar2 = *(int *)(param_1 + 4 + (int)param_3);
      if (iVar2 != 0) {
        LOCK();
        piVar1 = (int *)(iVar2 + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *param_3 = *(undefined4 *)(param_1 + (int)param_3);
      param_3[1] = *(undefined4 *)(param_1 + 4 + (int)param_3);
      param_3 = param_3 + 2;
    } while (param_1 + (int)param_3 != param_2);
  }
  return;
}



/* FUNCTION 10951 ; VA 0x00775d60 ; FUN_00775d60 */

int * __thiscall FUN_00775d60(undefined4 param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  
  if (param_2 != param_3) {
    do {
      *param_4 = 0;
      param_4[1] = 0;
      if (param_2[5] != 0) {
        LOCK();
        piVar1 = (int *)(param_2[5] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *param_4 = param_2[4];
      param_4[1] = param_2[5];
      param_4 = param_4 + 2;
      piVar1 = (int *)param_2[2];
      if (*(char *)((int)piVar1 + 0xd) == '\0') {
        cVar2 = *(char *)(*piVar1 + 0xd);
        param_2 = piVar1;
        piVar1 = (int *)*piVar1;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*piVar1 + 0xd);
          param_2 = piVar1;
          piVar1 = (int *)*piVar1;
        }
      }
      else {
        cVar2 = *(char *)(param_2[1] + 0xd);
        piVar3 = (int *)param_2[1];
        piVar1 = param_2;
        while ((param_2 = piVar3, cVar2 == '\0' && (piVar1 == (int *)param_2[2]))) {
          cVar2 = *(char *)(param_2[1] + 0xd);
          piVar3 = (int *)param_2[1];
          piVar1 = param_2;
        }
      }
    } while (param_2 != param_3);
  }
  FUN_005596d0(param_4,param_4,param_1);
  return param_4;
}



/* FUNCTION 10952 ; VA 0x00775e00 ; FUN_00775e00 */

undefined4 *
FUN_00775e00(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  puVar6 = param_3;
  if (param_1 != param_2) {
    puVar5 = param_1 + 5;
    do {
      puVar6[4] = 0;
      *(undefined4 *)((int)param_3 + (-0x20 - (int)param_1) + (int)(puVar5 + 8)) = 0;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      *puVar6 = puVar5[-5];
      puVar6[1] = uVar2;
      puVar6[2] = uVar3;
      puVar6[3] = uVar4;
      *(undefined8 *)(puVar6 + 4) = *(undefined8 *)(puVar5 + -1);
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      puVar6[6] = puVar5[1];
      *(undefined *)(puVar6 + 7) = *(undefined *)(puVar5 + 2);
      puVar1 = puVar5 + 3;
      puVar6 = puVar6 + 8;
      puVar5 = puVar5 + 8;
    } while (puVar1 != param_2);
  }
  FUN_00559500(puVar6,puVar6,param_4);
  return puVar6;
}



/* FUNCTION 10953 ; VA 0x00775e80 ; FUN_00775e80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_00775e80(int param_1,int param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  void **ppvVar6;
  undefined uVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017af1e0;
  pvStack_10 = ExceptionList;
  iStack_1c = param_1;
  iStack_18 = param_1;
  uStack_14 = param_3;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  ppvVar6 = &pvStack_10;
  if (param_2 != 0) {
    do {
      iVar5 = iStack_18;
      uStack_3c = 0;
      uStack_38 = 0xf;
      auStack_4c[0] = auStack_4c[0] & 0xffffff00;
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = auStack_34[0] & 0xffffff00;
      uStack_8 = 2;
      FUN_0054ef60(auStack_34);
      uStack_8 = 3;
      FUN_0054ef60(auStack_4c);
      uVar4 = _UNK_018fac8c;
      uVar3 = _UNK_018fac88;
      uVar2 = _UNK_018fac84;
      uVar1 = _DAT_018fac80;
      *(undefined4 *)(iVar5 + 0x30) = 0x3f800000;
      *(undefined4 *)(iVar5 + 0x34) = 0x3f800000;
      *(undefined4 *)(iVar5 + 0x38) = 0x3f800000;
      *(undefined4 *)(iVar5 + 0x3c) = 0x3f800000;
      *(undefined4 *)(iVar5 + 0x50) = 0;
      uStack_8 = 1;
      uVar7 = uStack_8;
      uStack_8 = 1;
      *(undefined4 *)(iVar5 + 0x40) = uVar1;
      *(undefined4 *)(iVar5 + 0x44) = uVar2;
      *(undefined4 *)(iVar5 + 0x48) = uVar3;
      *(undefined4 *)(iVar5 + 0x4c) = uVar4;
      if (0xf < uStack_20) {
        uVar9 = uStack_20 + 1;
        uVar8 = auStack_34[0];
        if (0xfff < uVar9) {
          uVar8 = *(uint *)(auStack_34[0] - 4);
          uVar9 = uStack_20 + 0x24;
          if (0x1f < (auStack_34[0] - uVar8) - 4) goto LAB_00775fe4;
        }
        FUN_01674ea0(uVar8,uVar9);
      }
      uStack_8 = 0;
      if (0xf < uStack_38) {
        uVar9 = uStack_38 + 1;
        uVar8 = auStack_4c[0];
        if (0xfff < uVar9) {
          uVar8 = *(uint *)(auStack_4c[0] - 4);
          uVar9 = uStack_38 + 0x24;
          uVar7 = uStack_8;
          if (0x1f < (auStack_4c[0] - uVar8) - 4) {
LAB_00775fe4:
            uStack_8 = uVar7;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar8,uVar9);
      }
      *(undefined4 *)(iVar5 + 0x54) = 0;
      *(undefined4 *)(iVar5 + 0x58) = 0;
      *(undefined4 *)(iVar5 + 0x5c) = 0;
      iStack_18 = iVar5 + 0x60;
      param_2 = param_2 + -1;
      ppvVar6 = (void **)ExceptionList;
    } while (param_2 != 0);
  }
  ExceptionList = ppvVar6;
  iVar5 = iStack_18;
  FUN_00774050(iStack_18,iStack_18,param_3);
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 10954 ; VA 0x00775ff0 ; FUN_00775ff0 */

void FUN_00775ff0(undefined4 *param_1,uint *param_2,uint *param_3,int *param_4)

{
  uint uVar1;
  uint uVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int iVar9;
  uint *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined4 *puStack_14;
  uint *puStack_8;
  
  if (param_2 != param_3) {
    puVar6 = (undefined4 *)*param_4;
    puVar12 = (undefined4 *)puVar6[1];
    puVar7 = puVar12;
    do {
      puVar8 = puVar6;
      puVar11 = puVar6;
      if (*(char *)((int)puVar7 + 0xd) == '\0') {
        puVar5 = puVar7;
        do {
          if ((uint)puVar5[4] < *param_2) {
            puVar4 = (undefined4 *)puVar5[2];
          }
          else {
            if ((*(char *)((int)puVar11 + 0xd) != '\0') && (*param_2 < (uint)puVar5[4])) {
              puVar11 = puVar5;
            }
            puVar4 = (undefined4 *)*puVar5;
            puVar8 = puVar5;
          }
          puVar5 = puVar4;
          puVar7 = puVar12;
        } while (*(char *)((int)puVar4 + 0xd) == '\0');
      }
      if (*(char *)((int)puVar11 + 0xd) == '\0') {
        puVar7 = (undefined4 *)*puVar11;
      }
      if (*(char *)((int)puVar7 + 0xd) == '\0') {
        do {
          if (*param_2 < (uint)puVar7[4]) {
            puVar5 = (undefined4 *)*puVar7;
            puVar11 = puVar7;
          }
          else {
            puVar5 = (undefined4 *)puVar7[2];
          }
          puVar7 = puVar5;
        } while (*(char *)((int)puVar5 + 0xd) == '\0');
      }
      iVar9 = 0;
      if (puVar8 != puVar11) {
        do {
          iVar9 = iVar9 + 1;
          FUN_00551320();
        } while (puVar8 != puVar11);
        if (iVar9 != 0) break;
      }
      param_2 = param_2 + 2;
      puVar7 = (undefined4 *)puVar6[1];
    } while (param_2 != param_3);
    if ((param_2 != param_3) && (puVar10 = param_2 + 2, puStack_8 = param_2, puVar10 != param_3)) {
      do {
        puStack_14 = (undefined4 *)*param_4;
        puVar6 = (undefined4 *)puStack_14[1];
        puVar12 = puStack_14;
        if (*(char *)((int)puVar6 + 0xd) == '\0') {
          puVar7 = puVar6;
          do {
            if ((uint)puVar7[4] < *puVar10) {
              puVar8 = (undefined4 *)puVar7[2];
            }
            else {
              if ((*(char *)((int)puVar12 + 0xd) != '\0') && (*puVar10 < (uint)puVar7[4])) {
                puVar12 = puVar7;
              }
              puVar8 = (undefined4 *)*puVar7;
              puStack_14 = puVar7;
            }
            puVar7 = puVar8;
          } while (*(char *)((int)puVar8 + 0xd) == '\0');
        }
        if (*(char *)((int)puVar12 + 0xd) == '\0') {
          puVar6 = (undefined4 *)*puVar12;
        }
        if (*(char *)((int)puVar6 + 0xd) == '\0') {
          do {
            if (*puVar10 < (uint)puVar6[4]) {
              puVar7 = (undefined4 *)*puVar6;
              puVar12 = puVar6;
            }
            else {
              puVar7 = (undefined4 *)puVar6[2];
            }
            puVar6 = puVar7;
          } while (*(char *)((int)puVar7 + 0xd) == '\0');
        }
        iVar9 = 0;
        if (puStack_14 == puVar12) {
LAB_00776162:
          uVar1 = *puVar10;
          uVar2 = puVar10[1];
          *puVar10 = 0;
          puVar10[1] = 0;
          *puStack_8 = uVar1;
          piVar3 = (int *)puStack_8[1];
          puStack_8[1] = uVar2;
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar9 = piVar3[1] + -1;
            piVar3[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              iVar9 = piVar3[2] + -1;
              piVar3[2] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          puStack_8 = puStack_8 + 2;
        }
        else {
          do {
            iVar9 = iVar9 + 1;
            FUN_00551320();
          } while (puStack_14 != puVar12);
          if (iVar9 == 0) goto LAB_00776162;
        }
        puVar10 = puVar10 + 2;
        if (puVar10 == param_3) {
          *param_1 = puStack_8;
          return;
        }
      } while( true );
    }
  }
  *param_1 = param_2;
  return;
}



/* FUNCTION 10955 ; VA 0x007761e0 ; FUN_007761e0 */

void FUN_007761e0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,int *param_4,
                 float *param_5,float *param_6,undefined4 param_7)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  float *pfVar5;
  char cVar6;
  int iVar7;
  undefined4 *puVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  int iStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af1f8;
  pvStack_10 = ExceptionList;
  puStack_14 = param_3;
  ExceptionList = &pvStack_10;
  FUN_0071ea10(&piStack_18,&param_4);
  if (param_2 != param_3) {
    do {
      cVar6 = FUN_00777660(param_2);
      if (cVar6 != '\0') break;
      param_2 = param_2 + 2;
    } while (param_2 != param_3);
    if ((param_2 != param_3) && (puVar8 = param_2 + 2, puVar8 != puStack_14)) {
      do {
        FUN_00587490(&iStack_1c);
        piVar4 = piStack_18;
        pfVar5 = param_6;
        uStack_8 = 0;
        if (iStack_1c == 0) {
          uStack_8 = 0xffffffff;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar7 = piStack_18[1] + -1;
            piStack_18[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piStack_18)();
              LOCK();
              piVar1 = piVar4 + 2;
              iVar7 = *piVar1 + -1;
              *piVar1 = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          if (DAT_01eb1b24 != '\0') {
            FUN_016774b0(DAT_01eb1b24,"TC Job[%p]: detach instance",param_7);
          }
        }
        else {
          if ((*param_4 == 0) || (*param_4 != *(int *)(iStack_1c + 0x34))) {
            iVar7 = FUN_00b077e0();
            fVar11 = pfVar5[1] - *(float *)(iVar7 + 0x28);
            fVar10 = *pfVar5 - *(float *)(iVar7 + 0x24);
            fVar9 = pfVar5[2] - *(float *)(iVar7 + 0x2c);
            fVar9 = fVar11 * fVar11 + fVar10 * fVar10 + fVar9 * fVar9;
            if (*param_5 <= fVar9) {
              fVar9 = *param_5;
            }
            *param_5 = fVar9;
          }
          else {
            *param_5 = 0.0;
          }
          piVar4 = piStack_18;
          uStack_8 = 0xffffffff;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar7 = piStack_18[1] + -1;
            piStack_18[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piStack_18)();
              LOCK();
              piVar1 = piVar4 + 2;
              iVar7 = *piVar1 + -1;
              *piVar1 = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          uVar2 = *puVar8;
          uVar3 = puVar8[1];
          *puVar8 = 0;
          puVar8[1] = 0;
          *param_2 = uVar2;
          piVar4 = (int *)param_2[1];
          param_2[1] = uVar3;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar7 = piVar4[2] + -1;
            piVar4[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
          param_2 = param_2 + 2;
        }
        puVar8 = puVar8 + 2;
      } while (puVar8 != puStack_14);
    }
  }
  *param_1 = param_2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10956 ; VA 0x007763a0 ; FUN_007763a0 */

uint * __thiscall FUN_007763a0(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af210;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x2aaaaaa < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar4 = param_2 * 0x60;
    if (uVar4 < 0x1000) {
      if (uVar4 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar4);
      }
    }
    else {
      uVar1 = uVar4 + 0x23;
      if (uVar1 <= uVar4) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_2 = param_2 & 0xffffff00;
    param_1[2] = *param_1 + uVar4;
    uStack_8 = 0;
    uVar3 = FUN_00775e80(*param_1,uVar3,param_1,param_2);
    param_1[1] = uVar3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10957 ; VA 0x0077646f ; Catch_All@0077646f */

void Catch_All_0077646f(void)

{
  FUN_00777f20();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 10958 ; VA 0x00776490 ; FUN_00776490 */

int * __thiscall FUN_00776490(int *param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar6 = param_2[1] - *param_2 >> 3;
  if (uVar6 != 0) {
    if (0x1fffffff < uVar6) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar3 = FUN_00578020(uVar6);
    *param_1 = iVar3;
    param_1[1] = iVar3;
    param_1[2] = *param_1 + uVar6 * 8;
    puVar2 = (undefined4 *)param_2[1];
    puVar4 = (undefined4 *)*param_1;
    for (puVar5 = (undefined4 *)*param_2; puVar5 != puVar2; puVar5 = puVar5 + 2) {
      *puVar4 = 0;
      puVar4[1] = 0;
      if (puVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar5[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *puVar4 = *puVar5;
      puVar4[1] = puVar5[1];
      puVar4 = puVar4 + 2;
    }
    param_1[1] = (int)puVar4;
  }
  return param_1;
}



/* FUNCTION 10959 ; VA 0x00776530 ; FUN_00776530 */

int __fastcall FUN_00776530(int param_1)

{
  int iVar1;
  
  FUN_01165ab0();
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0;
  *(undefined4 *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0;
  *(undefined4 *)(param_1 + 0x78) = 0;
  *(undefined4 *)(param_1 + 0x7c) = 0;
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(undefined4 *)(param_1 + 0x84) = 0;
  *(undefined4 *)(param_1 + 0x88) = 0;
  *(undefined4 *)(param_1 + 0x8c) = 0;
  *(undefined4 *)(param_1 + 0x90) = 0;
  *(undefined4 *)(param_1 + 0x94) = 0;
  *(undefined4 *)(param_1 + 0x98) = 0;
  *(undefined4 *)(param_1 + 0x9c) = 0;
  *(undefined4 *)(param_1 + 0xa0) = 0;
  *(undefined4 *)(param_1 + 0xa4) = 0;
  *(undefined4 *)(param_1 + 0xa8) = 0;
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0;
  *(undefined4 *)(param_1 + 0xb4) = 0;
  *(undefined4 *)(param_1 + 0xb8) = 0;
  *(undefined4 *)(param_1 + 0xbc) = 0;
  *(undefined4 *)(param_1 + 0xc0) = 0;
  *(undefined4 *)(param_1 + 0xc4) = 0;
  *(undefined4 *)(param_1 + 200) = 0;
  *(undefined4 *)(param_1 + 0xcc) = 0;
  *(undefined4 *)(param_1 + 0xd0) = 0;
  *(undefined4 *)(param_1 + 0xd4) = 0;
  *(undefined4 *)(param_1 + 0xd8) = 0;
  *(undefined4 *)(param_1 + 0xdc) = 0;
  *(undefined4 *)(param_1 + 0xe0) = 0;
  *(undefined4 *)(param_1 + 0xe4) = 0;
  *(undefined4 *)(param_1 + 0xe8) = 0;
  *(undefined4 *)(param_1 + 0xec) = 0;
  *(undefined4 *)(param_1 + 0xf0) = 0;
  *(undefined4 *)(param_1 + 0xf4) = 0;
  *(undefined4 *)(param_1 + 0xf8) = 0;
  *(undefined4 *)(param_1 + 0xfc) = 0;
  *(undefined4 *)(param_1 + 0x100) = 0;
  *(undefined4 *)(param_1 + 0x104) = 0;
  *(undefined4 *)(param_1 + 0x108) = 0;
  *(undefined4 *)(param_1 + 0x10c) = 0;
  *(undefined4 *)(param_1 + 0x110) = 0;
  *(undefined4 *)(param_1 + 0x114) = 0;
  *(undefined4 *)(param_1 + 0x118) = 0;
  *(undefined4 *)(param_1 + 0x11c) = 0;
  *(undefined4 *)(param_1 + 0x120) = 0;
  *(undefined4 *)(param_1 + 0x124) = 0;
  *(undefined4 *)(param_1 + 0x128) = 0;
  *(undefined4 *)(param_1 + 300) = 0;
  *(undefined4 *)(param_1 + 0x130) = 0;
  *(undefined4 *)(param_1 + 0x134) = 0;
  *(undefined4 *)(param_1 + 0x138) = 0;
  *(undefined4 *)(param_1 + 0x13c) = 0;
  *(undefined4 *)(param_1 + 0x140) = 0;
  *(undefined4 *)(param_1 + 0x144) = 0;
  *(undefined4 *)(param_1 + 0x148) = 0;
  *(undefined4 *)(param_1 + 0x14c) = 0;
  *(undefined4 *)(param_1 + 0x150) = 0;
  *(undefined4 *)(param_1 + 0x154) = 0;
  *(undefined4 *)(param_1 + 0x158) = 0;
  *(undefined4 *)(param_1 + 0x15c) = 0;
  *(undefined4 *)(param_1 + 0x160) = 0;
  *(undefined4 *)(param_1 + 0x164) = 0;
  *(undefined4 *)(param_1 + 0x168) = 0;
  *(undefined4 *)(param_1 + 0x16c) = 0;
  *(undefined4 *)(param_1 + 0x170) = 0;
  *(undefined4 *)(param_1 + 0x174) = 0;
  iVar1 = 0xc;
  *(undefined4 *)(param_1 + 0x178) = 0;
  *(undefined4 *)(param_1 + 0x17c) = 0;
  *(undefined4 *)(param_1 + 0x180) = 0;
  *(undefined4 *)(param_1 + 0x184) = 0;
  *(undefined4 *)(param_1 + 0x188) = 0;
  *(undefined4 *)(param_1 + 0x18c) = 0;
  *(undefined4 *)(param_1 + 400) = 0;
  *(undefined4 *)(param_1 + 0x194) = 0;
  *(undefined4 *)(param_1 + 0x198) = 0;
  *(undefined4 *)(param_1 + 0x19c) = 0;
  *(undefined4 *)(param_1 + 0x1a0) = 0;
  *(undefined4 *)(param_1 + 0x1a4) = 0;
  *(undefined4 *)(param_1 + 0x1a8) = 0;
  *(undefined4 *)(param_1 + 0x1ac) = 0;
  *(undefined4 *)(param_1 + 0x1b0) = 0;
  *(undefined4 *)(param_1 + 0x1b4) = 0;
  *(undefined4 *)(param_1 + 0x1b8) = 0;
  *(undefined4 *)(param_1 + 0x1bc) = 0;
  *(undefined4 *)(param_1 + 0x1c0) = 0;
  *(undefined4 *)(param_1 + 0x1c4) = 0;
  *(undefined4 *)(param_1 + 0x1c8) = 0;
  *(undefined4 *)(param_1 + 0x1cc) = 0;
  do {
    FUN_0060f2c0();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  *(undefined4 *)(param_1 + 0x290) = 0;
  *(undefined4 *)(param_1 + 0x294) = 0;
  *(undefined4 *)(param_1 + 0x298) = 0;
  *(undefined4 *)(param_1 + 0x29c) = 0;
  *(undefined4 *)(param_1 + 0x2a0) = 0;
  *(undefined4 *)(param_1 + 0x2a4) = 0;
  *(undefined4 *)(param_1 + 0x2a8) = 0;
  *(undefined4 *)(param_1 + 0x2ac) = 0;
  *(undefined4 *)(param_1 + 0x2b0) = 0;
  *(undefined4 *)(param_1 + 0x2b4) = 0;
  *(undefined4 *)(param_1 + 0x2b8) = 0;
  *(undefined4 *)(param_1 + 700) = 0;
  *(undefined4 *)(param_1 + 0x2c0) = 0;
  *(undefined4 *)(param_1 + 0x2c4) = 0;
  *(undefined4 *)(param_1 + 0x2c8) = 0;
  *(undefined4 *)(param_1 + 0x2cc) = 0;
  *(undefined4 *)(param_1 + 0x2d0) = 0;
  *(undefined4 *)(param_1 + 0x2d4) = 0;
  *(undefined4 *)(param_1 + 0x2d8) = 0;
  *(undefined4 *)(param_1 + 0x2dc) = 0;
  *(undefined4 *)(param_1 + 0x300) = 0;
  *(undefined4 *)(param_1 + 0x304) = 0;
  *(undefined4 *)(param_1 + 0x308) = 0;
  *(undefined4 *)(param_1 + 0x30c) = 0;
  FUN_01165ab0();
  return param_1;
}



/* FUNCTION 10960 ; VA 0x007769b0 ; FUN_007769b0 */

undefined * __fastcall FUN_007769b0(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0xf;
  param_1[0x44] = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0xf;
  param_1[0x5c] = 0;
  *(undefined4 *)(param_1 + 0x84) = 0;
  *(undefined4 *)(param_1 + 0x88) = 0xf;
  param_1[0x74] = 0;
  *(undefined4 *)(param_1 + 0x90) = 0;
  *(undefined4 *)(param_1 + 0x94) = 0;
  *(undefined4 *)(param_1 + 0x98) = 0;
  *(undefined4 *)(param_1 + 0x9c) = 0;
  *(undefined4 *)(param_1 + 0xa0) = 0;
  *(undefined4 *)(param_1 + 0xa4) = 0;
  *(undefined4 *)(param_1 + 0xa8) = 0;
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0;
  return param_1;
}



/* FUNCTION 10961 ; VA 0x00776aa0 ; FUN_00776aa0 */

undefined4 * __thiscall FUN_00776aa0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  uint uVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  uint uVar9;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af29a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0147cac0(*(undefined4 *)(param_2 + 0x3c));
  *param_1 = RBX::Graphics::TextureCompositor::vftable;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = param_2;
  param_1[0xf] = 0;
  puVar1 = param_1 + 0x10;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  *puVar1 = 0;
  param_1[0x11] = 0;
  piStack_18 = puVar1;
  uVar4 = FUN_00575b10();
  *puVar1 = uVar4;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  uStack_8._0_1_ = 7;
  FUN_01682800(param_1 + 0x1e);
  if (DAT_01eb1b25 == 0) {
    uVar9 = **(uint **)(param_2 + 0x520) / 3;
    uVar5 = 0x800000;
    if (0x800000 < uVar9) {
      uVar5 = uVar9;
    }
  }
  else {
    uVar5 = (uint)DAT_01eb1b25 << 0x14;
  }
  param_1[0xd] = 0x20;
  param_1[0xe] = uVar5;
  piVar6 = (int *)FUN_01674e20(0x24);
  uStack_8._0_1_ = 8;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  piStack_18 = piVar6;
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)0x0;
    uStack_8._0_1_ = uVar3;
  }
  else {
    *piVar6 = param_2;
    piVar6[1] = 0;
    piVar6[2] = 0;
    *(undefined *)(piVar6 + 3) = 0;
    iVar7 = FUN_00588320(0xb);
    piVar6[4] = iVar7;
    piVar6[5] = 0;
    piVar6[6] = 0x3f800000;
    piVar6[7] = 0;
    piVar6[8] = 0;
    uStack_8._0_1_ = 10;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb1b78) {
      FUN_016f3809(&DAT_01eb1b78);
      if (DAT_01eb1b78 == -1) {
        FUN_0147c5c0(0,0,2,0,0);
        FUN_0147c5c0(0,0xc,1,3,0);
        FUN_016f37bf(&DAT_01eb1b78);
      }
    }
    piVar8 = (int *)FUN_0147c1b0(auStack_20,&DAT_01eb1b50,2,0x14);
    iVar7 = *piVar8;
    iVar2 = piVar8[1];
    *piVar8 = 0;
    piVar8[1] = 0;
    piVar6[1] = iVar7;
    piVar8 = (int *)piVar6[2];
    piVar6[2] = iVar2;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar7 = piVar8[1] + -1;
      piVar8[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar7 = piVar8[2] + -1;
        piVar8[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar7 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar7 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  iVar7 = param_1[0xf];
  param_1[0xf] = piVar6;
  if (iVar7 != 0) {
    FUN_0075ddb0();
    piVar6 = *(int **)(iVar7 + 8);
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = piVar6[1] + -1;
      piVar6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        piVar8 = piVar6 + 2;
        iVar2 = *piVar8;
        *piVar8 = *piVar8 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar7,0x24);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10962 ; VA 0x00776d70 ; FUN_00776d70 */

int * __thiscall
FUN_00776d70(int *param_1,int param_2,int *param_3,int *param_4,undefined4 param_5,
            undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  int iVar10;
  undefined4 *puVar11;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar6 = param_4;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af2bb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = *param_3;
  param_1[2] = param_3[1];
  piStack_20 = param_1 + 3;
  piStack_1c = param_1;
  FUN_007763a0((param_4[1] - *param_4) / 0x54,(int)&param_3 + 3);
  param_1[6] = 0;
  iVar10 = *piVar6;
  iVar7 = piVar6[1] - iVar10;
  uStack_8 = 0;
  iVar3 = iVar7 >> 0x1f;
  uStack_18 = 0;
  if (iVar7 / 0x54 + iVar3 != iVar3) {
    param_3 = (int *)0x0;
    iStack_14 = 0;
    do {
      puVar11 = (undefined4 *)(iVar10 + (int)param_3);
      puVar8 = (undefined4 *)(*piStack_20 + iStack_14);
      if (puVar8 != puVar11) {
        puVar5 = puVar11;
        if (0xf < (uint)puVar11[5]) {
          puVar5 = (undefined4 *)*puVar11;
        }
        FUN_005542c0(puVar5,puVar11[4]);
      }
      piVar6 = puVar11 + 6;
      if (puVar8 + 6 != piVar6) {
        if (0xf < (uint)puVar11[0xb]) {
          piVar6 = (int *)*piVar6;
        }
        FUN_005542c0(piVar6,puVar11[10]);
      }
      puVar8[0xc] = puVar11[0xc];
      puVar8[0xd] = puVar11[0xd];
      puVar8[0xe] = puVar11[0xe];
      puVar8[0xf] = puVar11[0xf];
      uVar1 = puVar11[0x11];
      uVar2 = puVar11[0x12];
      uVar4 = puVar11[0x13];
      puVar8[0x10] = puVar11[0x10];
      puVar8[0x11] = uVar1;
      puVar8[0x12] = uVar2;
      puVar8[0x13] = uVar4;
      puVar8[0x14] = puVar11[0x14];
      if (puVar8[10] == 0) {
        FUN_007735a0(*(int *)(param_2 + 0x4ec) + 0x24,3);
        piVar9 = piStack_24;
        puVar8[0x16] = uStack_28;
        piVar6 = (int *)puVar8[0x17];
        uStack_28 = 0;
        piStack_24 = (int *)0x0;
        puVar8[0x17] = piVar9;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar10 = piVar6[1] + -1;
          piVar6[1] = iVar10;
          UNLOCK();
          piVar9 = piStack_24;
          if (iVar10 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar10 = piVar6[2] + -1;
            piVar6[2] = iVar10;
            UNLOCK();
            piVar9 = piStack_24;
            if (iVar10 == 0) {
              (**(code **)(*piVar6 + 4))();
              piVar9 = piStack_24;
            }
          }
          goto LAB_00776f52;
        }
      }
      else {
        puVar11 = (undefined4 *)
                  FUN_00782550(auStack_30,puVar8 + 6,-(DAT_01d60d0c != '\0') & 4,0,param_6,param_5,0
                              );
        uVar1 = *puVar11;
        uVar2 = puVar11[1];
        *puVar11 = 0;
        puVar11[1] = 0;
        puVar8[0x16] = uVar1;
        piVar6 = (int *)puVar8[0x17];
        puVar8[0x17] = uVar2;
        piVar9 = piStack_2c;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar10 = piVar6[1] + -1;
          piVar6[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar10 = piVar6[2] + -1;
            piVar6[2] = iVar10;
            UNLOCK();
            piVar9 = piStack_2c;
            if (iVar10 == 0) {
              (**(code **)(*piVar6 + 4))();
              piVar9 = piStack_2c;
            }
          }
        }
LAB_00776f52:
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar10 = piVar9[1] + -1;
          piVar9[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar10 = piVar9[2] + -1;
            piVar9[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
      }
      iStack_14 = iStack_14 + 0x60;
      uStack_18 = uStack_18 + 1;
      param_3 = (int *)((int)param_3 + 0x54);
      iVar10 = *param_4;
    } while (uStack_18 < (uint)((param_4[1] - iVar10) / 0x54));
  }
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 10963 ; VA 0x00776fd0 ; FUN_00776fd0 */

undefined4 * __thiscall FUN_00776fd0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  param_1[6] = param_2[6];
  *(undefined *)(param_1 + 7) = *(undefined *)(param_2 + 7);
  return param_1;
}



/* FUNCTION 10964 ; VA 0x00777020 ; FUN_00777020 */

void __fastcall FUN_00777020(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        iVar4 = iVar4 + 8;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = param_1[2] - iVar4 & 0xfffffff8;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 10965 ; VA 0x00777030 ; FUN_00777030 */

void __fastcall FUN_00777030(undefined4 *param_1)

{
  FUN_00774050(*param_1,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 10966 ; VA 0x00777050 ; FUN_00777050 */

void __fastcall FUN_00777050(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005766d0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10967 ; VA 0x007770b0 ; FUN_007770b0 */

void __fastcall FUN_007770b0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00777e50(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10968 ; VA 0x00777110 ; FUN_00777110 */

void __fastcall FUN_00777110(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    FUN_0075ddb0();
    piVar3 = *(int **)(iVar2 + 8);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x24);
  }
  return;
}



/* FUNCTION 10969 ; VA 0x00777160 ; thunk_FUN_0075ddb0 */

void __fastcall thunk_FUN_0075ddb0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_005f53f0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 10970 ; VA 0x00777170 ; thunk_FUN_00777f20 */

void __fastcall thunk_FUN_00777f20(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00774050(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x60) * 0x60;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 10971 ; VA 0x00777180 ; FUN_00777180 */

void __fastcall FUN_00777180(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  uVar4 = *(uint *)(param_1 + 0xb0);
  if (0xf < uVar4) {
    iVar1 = *(int *)(param_1 + 0x9c);
    uVar3 = uVar4 + 1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar4 + 0x24;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_007772b3;
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0xf;
  *(undefined *)(param_1 + 0x9c) = 0;
  uVar4 = *(uint *)(param_1 + 0x88);
  if (0xf < uVar4) {
    iVar1 = *(int *)(param_1 + 0x74);
    uVar3 = uVar4 + 1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar4 + 0x24;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_007772b3;
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x84) = 0;
  *(undefined4 *)(param_1 + 0x88) = 0xf;
  *(undefined *)(param_1 + 0x74) = 0;
  uVar4 = *(uint *)(param_1 + 0x60);
  if (0xf < uVar4) {
    iVar1 = *(int *)(param_1 + 0x4c);
    uVar3 = uVar4 + 1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar4 + 0x24;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_007772b3;
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0xf;
  *(undefined *)(param_1 + 0x4c) = 0;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    uVar4 = *(int *)(param_1 + 0x48) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_007772b3:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
    *(undefined4 *)(param_1 + 0x40) = 0;
    *(undefined4 *)(param_1 + 0x44) = 0;
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  return;
}



/* FUNCTION 10972 ; VA 0x007772c0 ; FUN_007772c0 */

undefined4 * __thiscall FUN_007772c0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  iVar3 = param_2[1];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = param_2[1];
  }
  *param_1 = *param_2;
  piVar2 = (int *)param_1[1];
  param_1[1] = iVar3;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = param_2[3];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = param_2[3];
  }
  param_1[2] = param_2[2];
  piVar2 = (int *)param_1[3];
  param_1[3] = iVar3;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[4] = param_2[4];
  return param_1;
}



/* FUNCTION 10973 ; VA 0x00777360 ; FUN_00777360 */

undefined4 * __thiscall FUN_00777360(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  
  if (param_1 != param_2) {
    puVar1 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar1 = (undefined4 *)*param_2;
    }
    FUN_005542c0(puVar1,param_2[4]);
  }
  piVar2 = param_2 + 6;
  if (param_1 + 6 != piVar2) {
    if (0xf < (uint)param_2[0xb]) {
      piVar2 = (int *)*piVar2;
    }
    FUN_005542c0(piVar2,param_2[10]);
  }
  piVar2 = param_2 + 0xc;
  if (param_1 + 0xc != piVar2) {
    if (0xf < (uint)param_2[0x11]) {
      piVar2 = (int *)*piVar2;
    }
    FUN_005542c0(piVar2,param_2[0x10]);
  }
  param_1[0x12] = param_2[0x12];
  return param_1;
}



/* FUNCTION 10974 ; VA 0x007773d0 ; FUN_007773d0 */

int * __thiscall FUN_007773d0(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = (int)param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017af2e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_009cc8a0(param_2);
  FUN_00607080(&param_2,uStack_18,iVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar3 = (int *)FUN_01674e20(0x28);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  piStack_1c = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  *piStack_1c = 0;
  piVar3[3] = 0;
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[8] = 0;
  piVar3[9] = 0;
  piStack_24 = piVar3;
  FUN_0054ef60(aiStack_40);
  piVar3[8] = 0;
  piVar3[9] = 0;
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005d6bb0(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = (uint *)0x1;
    uVar5 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar5 = 1;
    }
    uVar7 = FUN_005d6bb0(uVar5 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar7 != *param_2) {
      FUN_005d2b00(uVar7);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar2 = (undefined4 *)*puVar8;
      while (piVar3 = piStack_24, puVar2 != (undefined4 *)0x0) {
        piVar3 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4) == 0) {
          *piVar3 = (int)puVar8;
          puVar8 = puVar2;
        }
        else {
          *puVar8 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        param_1 = pbStack_14;
        puVar2 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar3[1] = uStack_18;
  uVar7 = *(uint *)(param_1 + 4);
  piVar3 = (int *)(*(int *)(param_1 + 0x14) + (uStack_18 % uVar7) * 4);
  if ((int *)*piVar3 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % uVar7) * 4) = piStack_24;
    }
    *piVar3 = (int)piVar6;
    *piStack_24 = *piVar6;
  }
  else {
    *piStack_24 = *(int *)*piVar3;
    piVar6 = (int *)*piVar3;
  }
  *piVar6 = (int)piStack_24;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 10975 ; VA 0x00777610 ; FUN_00777610 */

undefined4 * __thiscall FUN_00777610(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 uVar1;
  
  uVar1 = *param_1;
  if (param_3 != 0) {
    do {
      *param_2 = 0;
      param_2[1] = 0;
      param_2[2] = 0;
      param_2[3] = 0;
      param_2[4] = 0;
      param_2[5] = 0;
      param_2[6] = 0;
      param_2[7] = 0;
      param_2[4] = 0;
      param_2[5] = 0xf;
      *(undefined *)param_2 = 0;
      param_2 = param_2 + 8;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  FUN_00559500(param_2,param_2,uVar1);
  return param_2;
}



/* FUNCTION 10976 ; VA 0x00777660 ; FUN_00777660 */

uint __fastcall FUN_00777660(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  float *pfVar4;
  undefined3 uVar5;
  undefined3 extraout_var;
  float fVar6;
  float fVar7;
  float fVar8;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    if ((*(int *)*param_1 == 0) || (*(int *)*param_1 != *(int *)(iStack_18 + 0x34))) {
      pfVar4 = (float *)param_1[2];
      iVar3 = FUN_00b077e0();
      fVar8 = pfVar4[1] - *(float *)(iVar3 + 0x28);
      fVar7 = *pfVar4 - *(float *)(iVar3 + 0x24);
      fVar6 = pfVar4[2] - *(float *)(iVar3 + 0x2c);
      pfVar4 = (float *)param_1[1];
      fVar6 = fVar8 * fVar8 + fVar7 * fVar7 + fVar6 * fVar6;
      if (*pfVar4 <= fVar6) {
        fVar6 = *pfVar4;
      }
      *pfVar4 = fVar6;
    }
    else {
      pfVar4 = (float *)param_1[1];
      *pfVar4 = 0.0;
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar3 = *piVar1;
      pfVar4 = (float *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pfVar4 = (float *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pfVar4 = (float *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return (uint)pfVar4 & 0xffffff00;
  }
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  uVar5 = (undefined3)((uint)iVar3 >> 8);
  if (DAT_01eb1b24 != '\0') {
    FUN_016774b0(DAT_01eb1b24,"TC Job[%p]: detach instance",param_1[3]);
    uVar5 = extraout_var;
  }
  ExceptionList = pvStack_10;
  return CONCAT31(uVar5,1);
}



/* FUNCTION 10977 ; VA 0x007777a0 ; FUN_007777a0 */

void __fastcall FUN_007777a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  void **ppvVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  uint uVar10;
  int *piVar11;
  uint uStack_bc;
  uint uStack_b8;
  int iStack_b4;
  uint uStack_b0;
  uint uStack_9c;
  uint uStack_88;
  uint uStack_74;
  uint uStack_60;
  uint uStack_4c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017af303;
  piVar1 = (int *)param_1[1];
  piVar11 = (int *)*param_1;
  ppvVar3 = &pvStack_10;
  pvStack_10 = ExceptionList;
  do {
    ExceptionList = ppvVar3;
    if (piVar11 == piVar1) {
      ExceptionList = pvStack_10;
      return;
    }
    iVar6 = piVar11[1];
    iVar4 = 0;
    piStack_18 = (int *)0x0;
    if (iVar6 != 0) {
      piVar8 = (int *)(iVar6 + 4);
      iVar6 = *(int *)(iVar6 + 4);
      while (iVar6 != 0) {
        LOCK();
        iVar4 = *piVar8;
        if (iVar6 == iVar4) {
          *piVar8 = iVar6 + 1;
          iVar4 = iVar6;
        }
        UNLOCK();
        if (iVar4 == iVar6) {
          iVar4 = *piVar11;
          piStack_18 = (int *)piVar11[1];
          goto LAB_0077780a;
        }
        iVar6 = *piVar8;
      }
      iVar4 = 0;
    }
LAB_0077780a:
    iStack_8 = 0;
    if (iVar4 != 0) {
      if ((*(int *)(iVar4 + 0x34) != 0) &&
         (puVar2 = *(undefined4 **)(*(int *)(iVar4 + 0x34) + 0x2c), puVar2 != (undefined4 *)0x0)) {
        piVar8 = (int *)puVar2[1];
        for (piVar9 = (int *)*puVar2; piVar9 != piVar8; piVar9 = piVar9 + 2) {
          iVar6 = *piVar9;
          if ((iVar6 != 0) &&
             (iVar4 = *(int *)(iVar6 + 0xc), iVar5 = FUN_0099be20(),
             (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
             (uint)*(ushort *)(iVar5 + 0x1da))) goto LAB_00777865;
        }
      }
      iVar6 = 0;
LAB_00777865:
      FUN_01154090(iVar6);
      uVar10 = 0;
      iStack_8._0_1_ = 1;
      uVar7 = (uStack_b8 - uStack_bc) + 3 >> 2;
      if (uStack_b8 < uStack_bc) {
        uVar7 = 0;
      }
      if (uVar7 != 0) {
        do {
          iVar6 = thunk_FUN_00c48580();
          if (iVar6 == 0) {
            piVar8 = (int *)0x0;
          }
          else {
            piVar8 = *(int **)(iVar6 + 0xb0);
          }
          if (piVar8 != (int *)0x0) {
            (**(code **)(*piVar8 + 8))();
          }
          uVar10 = uVar10 + 1;
        } while (uVar10 != uVar7);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_4c) {
        uVar10 = uStack_4c + 1;
        uVar7 = uStack_60;
        if (0xfff < uVar10) {
          uVar7 = *(uint *)(uStack_60 - 4);
          uVar10 = uStack_4c + 0x24;
          if (0x1f < (uStack_60 - uVar7) - 4) goto LAB_00777a6c;
        }
        FUN_01674ea0(uVar7,uVar10);
      }
      uStack_4c = 0xf;
      uStack_60 = uStack_60 & 0xffffff00;
      if (0xf < uStack_74) {
        uVar10 = uStack_74 + 1;
        uVar7 = uStack_88;
        if (0xfff < uVar10) {
          uVar7 = *(uint *)(uStack_88 - 4);
          uVar10 = uStack_74 + 0x24;
          if (0x1f < (uStack_88 - uVar7) - 4) goto LAB_00777a6c;
        }
        FUN_01674ea0(uVar7,uVar10);
      }
      uStack_74 = 0xf;
      uStack_88 = uStack_88 & 0xffffff00;
      if (0xf < uStack_9c) {
        uVar10 = uStack_9c + 1;
        uVar7 = uStack_b0;
        if (0xfff < uVar10) {
          uVar7 = *(uint *)(uStack_b0 - 4);
          uVar10 = uStack_9c + 0x24;
          if (0x1f < (uStack_b0 - uVar7) - 4) goto LAB_00777a6c;
        }
        FUN_01674ea0(uVar7,uVar10);
      }
      uStack_9c = 0xf;
      uStack_b0 = uStack_b0 & 0xffffff00;
      if (uStack_bc != 0) {
        uVar7 = ((int)(iStack_b4 - uStack_bc) >> 2) * 4;
        uVar10 = uStack_bc;
        if (0xfff < uVar7) {
          uVar10 = *(uint *)(uStack_bc - 4);
          uVar7 = uVar7 + 0x23;
          if (0x1f < (uStack_bc - uVar10) - 4) {
LAB_00777a6c:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar10,uVar7);
      }
    }
    iStack_8 = 0xffffffff;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_18[1] + -1;
      piStack_18[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar6 = piStack_18[2] + -1;
        piStack_18[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piVar11 = piVar11 + 2;
    ppvVar3 = (void **)ExceptionList;
  } while( true );
}



/* FUNCTION 10978 ; VA 0x00777a80 ; FUN_00777a80 */

int __thiscall FUN_00777a80(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 10979 ; VA 0x00777ad0 ; FUN_00777ad0 */

int * __thiscall FUN_00777ad0(int *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_1[0x2c];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x2a];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0056b650();
  FUN_00637950();
  FUN_005e6280();
  FUN_0075df00();
  uVar3 = param_1[5];
  if (0xf < uVar3) {
    iVar4 = *param_1;
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb4);
  }
  return param_1;
}



/* FUNCTION 10980 ; VA 0x00777bc0 ; FUN_00777bc0 */

undefined4 * __thiscall FUN_00777bc0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::TextureCompositor::vftable;
  FUN_00577ac0();
  FUN_00577ac0();
  FUN_00577ac0();
  FUN_00577ac0();
  iVar2 = param_1[0x10];
  uStack_8 = 0;
  FUN_005766d0(*(undefined4 *)(iVar2 + 4));
  *(int *)(param_1[0x10] + 4) = iVar2;
  *(int *)param_1[0x10] = iVar2;
  *(int *)(param_1[0x10] + 8) = iVar2;
  param_1[0x11] = 0;
  FUN_01674ea0(param_1[0x10],0x30);
  iVar2 = param_1[0xf];
  if (iVar2 != 0) {
    FUN_0075ddb0();
    piVar3 = *(int **)(iVar2 + 8);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x24);
  }
  piVar3 = (int *)param_1[0xb];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*piVar3 + 4))();
    }
  }
  FUN_0147cba0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10981 ; VA 0x00777cd0 ; FUN_00777cd0 */

undefined4 __thiscall FUN_00777cd0(undefined4 param_1,byte param_2)

{
  FUN_00777f20();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 10982 ; VA 0x00777d00 ; FUN_00777d00 */

void __thiscall FUN_00777d00(int *param_1,int param_2,int param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        iVar4 = iVar4 + 8;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = param_1[2] - iVar4 & 0xfffffff8;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 8;
  param_1[2] = param_2 + param_4 * 8;
  return;
}



/* FUNCTION 10983 ; VA 0x00777d90 ; FUN_00777d90 */

void __fastcall FUN_00777d90(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *(int *)(param_1 + 0xc);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  return;
}



/* FUNCTION 10984 ; VA 0x00777de0 ; FUN_00777de0 */

void __fastcall FUN_00777de0(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_00777ad0(1);
  }
  return;
}



/* FUNCTION 10985 ; VA 0x00777df0 ; FUN_00777df0 */

void __fastcall FUN_00777df0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_00777f20();
    FUN_01674ea0(iVar1,0x1c);
  }
  return;
}



/* FUNCTION 10986 ; VA 0x00777e10 ; FUN_00777e10 */

void FUN_00777e10(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 4);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      param_1 = param_1 + 8;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 10987 ; VA 0x00777e50 ; FUN_00777e50 */

undefined4 __thiscall FUN_00777e50(undefined4 param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  cVar1 = *(char *)((int)param_2 + 0xd);
  while (cVar1 == '\0') {
    FUN_00777e50(param_2[2]);
    piVar2 = (int *)param_2[5];
    piVar3 = (int *)*param_2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(param_2,0x18);
    param_2 = piVar3;
    cVar1 = *(char *)((int)piVar3 + 0xd);
  }
  return param_1;
}



/* FUNCTION 10988 ; VA 0x00777ed0 ; FUN_00777ed0 */

void __thiscall FUN_00777ed0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  uVar3 = FUN_00578020(param_2);
  FUN_005c23f0(*param_1,param_1[1],uVar3,param_1);
  FUN_005c5230(uVar3,iVar1 - iVar2 >> 3,param_2);
  return;
}



/* FUNCTION 10989 ; VA 0x00777f20 ; FUN_00777f20 */

void __fastcall FUN_00777f20(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00774050(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x60) * 0x60;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 10990 ; VA 0x00777fa0 ; FUN_00777fa0 */

int * FUN_00777fa0(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  int aiStack_30 [5];
  uint uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017af320;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)*param_2;
  if (piStack_18 == (int *)0x0) {
    return (int *)0x0;
  }
  piStack_14 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piStack_14[2] = piStack_14[2] + 1;
    UNLOCK();
    piStack_18 = (int *)*param_2;
    piStack_14 = (int *)param_2[1];
  }
  uStack_8 = 0;
  iVar4 = *param_1;
  piVar1 = *(int **)(iVar4 + 0x38);
  piVar2 = *(int **)(iVar4 + 0x34);
  if (piVar2 != piVar1) {
    do {
      if (((int *)piVar2[1] <= piStack_14) && (piStack_14 <= (int *)piVar2[1])) break;
      piVar2 = piVar2 + 2;
    } while (piVar2 != piVar1);
    if (piVar2 != piVar1) goto LAB_007780e0;
  }
  if (*(int **)(iVar4 + 0x3c) == piVar1) {
    FUN_007740a0(piVar1,&piStack_18);
  }
  else {
    *piVar1 = 0;
    piVar1[1] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[2] = piStack_14[2] + 1;
      UNLOCK();
    }
    *piVar1 = (int)piStack_18;
    piVar1[1] = (int)piStack_14;
    *(int *)(iVar4 + 0x38) = *(int *)(iVar4 + 0x38) + 8;
  }
  piVar2 = (int *)(uint)DAT_01eb1b24;
  if ((DAT_01eb1b24 != 0) &&
     (piVar2 = (int *)FUN_01677490(DAT_01eb1b24,"TC Job[%p]: attach instance %p",*param_1,*param_2,0
                                  ), DAT_01eb1b24 != 0)) {
    puVar3 = (undefined4 *)FUN_008a2380(aiStack_30);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    piVar2 = (int *)FUN_01677650(DAT_01eb1b24,"TC Job instance: %s",puVar3);
    if (0xf < uStack_1c) {
      uVar5 = uStack_1c + 1;
      iVar4 = aiStack_30[0];
      if (0xfff < uVar5) {
        iVar4 = *(int *)(aiStack_30[0] + -4);
        uVar5 = uStack_1c + 0x24;
        if (0x1f < (aiStack_30[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      piVar2 = (int *)FUN_01674ea0(iVar4,uVar5);
    }
  }
LAB_007780e0:
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 2;
    iVar4 = *piVar1;
    piVar2 = (int *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      piVar2 = (int *)(**(code **)(*piStack_14 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return piVar2;
}



/* FUNCTION 10991 ; VA 0x00778110 ; FUN_00778110 */

void __fastcall FUN_00778110(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x40);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005766d0(*(undefined4 *)(iVar2 + 4));
  *(int *)(*(int *)(param_1 + 0x40) + 4) = iVar2;
  **(int **)(param_1 + 0x40) = iVar2;
  *(int *)(*(int *)(param_1 + 0x40) + 8) = iVar2;
  puVar1 = (undefined4 *)(param_1 + 0x48);
  *(undefined4 *)(param_1 + 0x44) = 0;
  FUN_005596d0(*puVar1,*(undefined4 *)(param_1 + 0x4c),puVar1);
  *(undefined4 *)(param_1 + 0x4c) = *puVar1;
  puVar1 = (undefined4 *)(param_1 + 0x54);
  FUN_005596d0(*puVar1,*(undefined4 *)(param_1 + 0x58),puVar1);
  *(undefined4 *)(param_1 + 0x58) = *puVar1;
  puVar1 = (undefined4 *)(param_1 + 0x60);
  FUN_005596d0(*puVar1,*(undefined4 *)(param_1 + 100),puVar1);
  *(undefined4 *)(param_1 + 100) = *puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10992 ; VA 0x007781b0 ; FUN_007781b0 */

void __fastcall FUN_007781b0(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = param_1[1];
  iVar4 = *param_1;
  if (iVar4 != iVar1) {
    do {
      piVar2 = *(int **)(iVar4 + 4);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      iVar4 = iVar4 + 8;
    } while (iVar4 != iVar1);
    param_1[1] = *param_1;
    return;
  }
  param_1[1] = iVar4;
  return;
}



/* FUNCTION 10993 ; VA 0x007781f0 ; FUN_007781f0 */

undefined4 FUN_007781f0(undefined4 param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  undefined8 *puVar6;
  undefined4 *puVar7;
  undefined2 *puVar8;
  int iVar9;
  int iVar10;
  undefined auStack_3c [4];
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af350;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_01eb1b4c);
  uStack_8 = 0;
  uStack_18 = uVar4;
  (**(code **)(*param_2 + 0x3c))(&piStack_34,0,((param_3[1] - *param_3) / 0x28) * 0x14,0x14,0);
  uStack_8._0_1_ = 1;
  iStack_1c = (**(code **)(*piStack_34 + 0x10))();
  iVar5 = FUN_01151ea0(param_3);
  iStack_20 = iVar5;
  cVar3 = FUN_01151c00(param_3);
  if (cVar3 == '\0') {
    iStack_14 = (param_3[7] - param_3[6]) / 0xc;
  }
  else {
    iStack_14 = *(int *)(param_3[0x19] + 4);
  }
  if (iVar5 != 0) {
    iVar9 = 0;
    puVar7 = (undefined4 *)(iStack_1c + 0xc);
    iVar5 = iStack_20;
    do {
      puVar6 = (undefined8 *)(*param_3 + iVar9);
      iVar9 = iVar9 + 0x28;
      uVar4 = *(undefined4 *)(puVar6 + 1);
      *(undefined8 *)(puVar7 + -3) = *puVar6;
      puVar7[-1] = uVar4;
      uVar4 = *(undefined4 *)((int)puVar6 + 0x1c);
      *puVar7 = *(undefined4 *)(puVar6 + 3);
      puVar7[1] = uVar4;
      iVar5 = iVar5 + -1;
      puVar7 = puVar7 + 5;
      uVar4 = uStack_18;
    } while (iVar5 != 0);
  }
  (**(code **)(*piStack_34 + 0x14))();
  (**(code **)(*param_2 + 0x3c))(&piStack_2c,1,((param_3[7] - param_3[6]) / 0xc) * 6,2,0);
  uStack_8._0_1_ = 2;
  iVar9 = (**(code **)(*piStack_2c + 0x10))();
  iVar5 = iStack_14;
  if (iStack_14 != 0) {
    iVar10 = 0;
    puVar8 = (undefined2 *)(iVar9 + 4);
    iVar9 = iStack_14;
    do {
      iVar2 = param_3[6];
      iVar10 = iVar10 + 0xc;
      puVar8[-2] = *(undefined2 *)(iVar2 + -0xc + iVar10);
      puVar8[-1] = *(undefined2 *)(iVar2 + -8 + iVar10);
      *puVar8 = *(undefined2 *)(iVar2 + -4 + iVar10);
      iVar9 = iVar9 + -1;
      puVar8 = puVar8 + 3;
      uVar4 = uStack_18;
    } while (iVar9 != 0);
  }
  (**(code **)(*piStack_2c + 0x14))();
  FUN_0147c0e0(auStack_3c,iStack_24 + 4,&piStack_34,&piStack_2c);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0147c720(auStack_3c,0,0,0,iVar5 * 3);
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_38[1] + -1;
    piStack_38[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      iVar5 = piStack_38[2] + -1;
      piStack_38[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_28[1] + -1;
    piStack_28[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar5 = piStack_28[2] + -1;
      piStack_28[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piStack_30 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 10994 ; VA 0x00778470 ; FUN_00778470 */

void __thiscall FUN_00778470(int *param_1,undefined4 *param_2,undefined4 param_3)

{
  (**(code **)(*param_1 + 0x40))(*param_2,param_2[2],param_2[3],param_2[4],param_2[5],param_3);
  return;
}



/* FUNCTION 10995 ; VA 0x00778490 ; FUN_00778490 */

void * FUN_00778490(void)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  void *pvVar4;
  float10 fVar5;
  undefined auStack_c0 [16];
  double dStack_b0;
  undefined auStack_a8 [16];
  double dStack_98;
  undefined auStack_90 [16];
  double dStack_80;
  undefined auStack_78 [16];
  double dStack_68;
  undefined auStack_60 [16];
  double dStack_50;
  undefined auStack_48 [12];
  double dStack_3c;
  undefined auStack_34 [16];
  double dStack_24;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af3a9;
  pvStack_10 = ExceptionList;
  pvVar4 = ExceptionList;
  if (DAT_01d5a210 != '\0') {
    ExceptionList = &pvStack_10;
    fVar5 = (float10)FUN_01683110();
    dStack_3c = (double)fVar5;
    pvVar4 = (void *)FUN_00587490();
    uStack_8 = 0;
    if (iStack_1c != 0) {
      FUN_00776490();
      uStack_8._0_1_ = 1;
      FUN_00776490(auStack_48);
      dStack_b0 = dStack_3c;
      uStack_8._0_1_ = 2;
      FUN_00776490(auStack_c0);
      dStack_98 = dStack_b0;
      uStack_8._0_1_ = 3;
      FUN_00776490(auStack_a8);
      dStack_80 = dStack_98;
      uStack_8._0_1_ = 4;
      FUN_00776490(auStack_90);
      dStack_68 = dStack_80;
      uStack_8._0_1_ = 5;
      FUN_00776490(auStack_78);
      dStack_24 = dStack_68;
      uStack_8._0_1_ = 6;
      cVar3 = FUN_00585a40(auStack_34);
      if (cVar3 == '\0') {
        FUN_00776490(auStack_34);
        dStack_50 = dStack_24;
        uStack_8._0_1_ = 7;
        FUN_00776490(auStack_60);
        FUN_005e6280();
        FUN_005e6280();
      }
      else {
        FUN_005e6280();
      }
      FUN_005e6280();
      FUN_005e6280();
      FUN_005e6280();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_005e6280();
      FUN_0090ca30();
      pvVar4 = (void *)FUN_005e6280();
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 10996 ; VA 0x00778690 ; FUN_00778690 */

void __fastcall FUN_00778690(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puStack_30;
  int *piStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af3c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_0077a0e0();
  uVar6 = *(uint *)(param_1 + 0x44);
  uStack_8 = 0;
  if (uVar6 != 0) {
    if (0x1fffffff < uVar6) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00777ed0(uVar6);
  }
  puStack_30 = (undefined4 *)0x0;
  piVar1 = *(int **)(param_1 + 0x40);
  piVar2 = (int *)*piVar1;
  while (piVar2 != piVar1) {
    if (puStack_30 == (undefined4 *)0x0) {
      FUN_00603260(0,piVar2 + 10);
    }
    else {
      *puStack_30 = 0;
      puStack_30[1] = 0;
      if (piVar2[0xb] != 0) {
        LOCK();
        piVar1 = (int *)(piVar2[0xb] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *puStack_30 = piVar2[10];
      puStack_30[1] = piVar2[0xb];
      puStack_30 = puStack_30 + 2;
    }
    FUN_00551320();
    piVar1 = *(int **)(param_1 + 0x40);
  }
  uVar5 = (int)puStack_30 >> 3;
  FUN_00775ae0(0,puStack_30,uVar5,param_1);
  uVar8 = 0;
  uVar6 = uVar5;
  if (uVar5 != 0) {
    piStack_1c = (int *)&DAT_00000008;
    uStack_14 = 0;
    piStack_18 = (int *)0x0;
    do {
      if (*(int *)(*piStack_18 + 0x90) != 0) {
        if (*(uint *)(*(int *)(*piStack_18 + 0x90) + 0x30) < *(uint *)(*piStack_18 + 0x18)) {
          if (uStack_14 < uVar6) {
            uVar6 = uStack_14;
          }
        }
        else if (uVar8 < uStack_14 + 1) {
          uVar8 = uStack_14 + 1;
        }
      }
      piStack_18 = piStack_1c;
      uStack_14 = uStack_14 + 1;
      piStack_1c = piStack_1c + 2;
    } while (uStack_14 < uVar5);
  }
  if (uVar6 < uVar5) {
    iVar3 = *(int *)(uVar6 * 8);
    puVar9 = (undefined4 *)(uVar6 * 8);
    if (*(uint *)(param_1 + 0x38) <=
        (*(uint *)(param_1 + 0x34) >> 3) * *(int *)(iVar3 + 0x1c) * *(int *)(iVar3 + 0x18) + uVar4)
    goto LAB_0077884d;
    if (DAT_01eb1b24 != '\0') {
      FUN_016774b0(DAT_01eb1b24,"TC Job[%p]: queueing (upsample)",iVar3);
    }
    puVar7 = *(undefined4 **)(param_1 + 0x4c);
    if (*(undefined4 **)(param_1 + 0x50) != puVar7) {
      *puVar7 = 0;
      puVar7[1] = 0;
      if (puVar9[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar9[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *puVar7 = *puVar9;
      puVar7[1] = puVar9[1];
      *(int *)(param_1 + 0x4c) = *(int *)(param_1 + 0x4c) + 8;
      goto LAB_007788b8;
    }
  }
  else {
LAB_0077884d:
    if ((uVar8 == 0) || ((uVar8 = uVar8 - 1, uVar8 < uVar6 && (uVar4 < *(uint *)(param_1 + 0x38)))))
    goto LAB_007788b8;
    if (DAT_01eb1b24 != '\0') {
      FUN_016774b0(DAT_01eb1b24,"TC Job[%p]: queueing (downsample)",*(undefined4 *)(uVar8 * 8));
    }
    puVar7 = *(undefined4 **)(param_1 + 0x4c);
    puVar9 = (undefined4 *)(uVar8 * 8);
    if (*(undefined4 **)(param_1 + 0x50) != puVar7) {
      *puVar7 = 0;
      puVar7[1] = 0;
      if (puVar9[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar9[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *puVar7 = *puVar9;
      puVar7[1] = puVar9[1];
      *(int *)(param_1 + 0x4c) = *(int *)(param_1 + 0x4c) + 8;
      goto LAB_007788b8;
    }
  }
  FUN_00603260(puVar7,puVar9);
LAB_007788b8:
  FUN_00577ac0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 10997 ; VA 0x007788e0 ; FUN_007788e0 */

void __fastcall FUN_007788e0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  uStack_14 = 0;
  uStack_10 = 0;
  uStack_c = 0;
  FUN_0077bcc0(&uStack_14);
  iVar2 = *(int *)(param_1 + 100);
  piVar4 = (int *)(param_1 + 0x60);
  iVar1 = *piVar4;
  uVar3 = 0;
  piStack_8 = piVar4;
  if (iVar2 - iVar1 >> 3 != 0) {
    do {
      iVar2 = *(int *)(iVar1 + uVar3 * 8);
      if (*(int *)(iVar2 + 0x90) != 0) {
        if (DAT_01eb1b24 != '\0') {
          FUN_016774b0(DAT_01eb1b24,"TC Destroy texture %p",*(int *)(iVar2 + 0x90));
        }
        *(undefined4 *)(iVar2 + 0x98) = 0;
        piVar4 = *(int **)(iVar2 + 0x9c);
        *(undefined4 *)(iVar2 + 0x9c) = 0;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar1 = piVar4[1] + -1;
          piVar4[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar1 = piVar4[2] + -1;
            piVar4[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        *(undefined4 *)(iVar2 + 0x90) = 0;
        piVar4 = *(int **)(iVar2 + 0x94);
        *(undefined4 *)(iVar2 + 0x94) = 0;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar1 = piVar4[1] + -1;
          piVar4[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar1 = piVar4[2] + -1;
            piVar4[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        *(undefined4 *)(iVar2 + 0xa0) = 0;
        piVar4 = piStack_8;
      }
      iVar2 = piVar4[1];
      uVar3 = uVar3 + 1;
      iVar1 = *piVar4;
    } while (uVar3 < (uint)(iVar2 - iVar1 >> 3));
  }
  FUN_005596d0(iVar1,iVar2,piVar4);
  piVar4[1] = *piVar4;
  return;
}



/* FUNCTION 10998 ; VA 0x00778a10 ; FUN_00778a10 */

int __fastcall FUN_00778a10(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined4 uVar10;
  int iVar11;
  int *piVar12;
  uint uVar13;
  int iVar14;
  int *piVar15;
  uint uVar16;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af3e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar7 = FUN_0077a0e0();
  piVar12 = (int *)(param_1 + 0x60);
  uVar13 = 0;
  uVar16 = 0;
  iVar8 = *piVar12;
  if (*(int *)(param_1 + 100) - iVar8 >> 3 == 0) {
    iVar11 = *(int *)(param_1 + 100);
  }
  else {
    do {
      iVar8 = *(int *)(*(int *)(iVar8 + uVar16 * 8) + 0x90);
      if (iVar8 == 0) {
        iVar8 = 0;
      }
      else {
        iVar8 = FUN_0147d000(*(undefined4 *)(iVar8 + 0x2c),*(undefined4 *)(iVar8 + 0x30),
                             *(undefined4 *)(iVar8 + 0x34));
      }
      iVar11 = *(int *)(param_1 + 100);
      uVar13 = uVar13 + iVar8;
      iVar8 = *piVar12;
      uVar16 = uVar16 + 1;
    } while (uVar16 < (uint)(iVar11 - iVar8 >> 3));
  }
  uVar16 = *(uint *)(param_1 + 0x38);
  if (uVar16 < uVar7) {
    uVar9 = 0;
  }
  else {
    uVar9 = uVar16 >> 2;
    if (0x2000000 < uVar16 >> 2) {
      uVar9 = 0x2000000;
    }
    if (uVar16 - uVar7 <= uVar9) {
      uVar9 = uVar16 - uVar7;
    }
  }
  if (uVar9 < uVar13) {
    FUN_007158e0(iVar11 - iVar8 >> 3,&uStack_11);
    uVar7 = 0;
    uStack_8 = 0;
    iVar8 = *(int *)(param_1 + 100);
    iVar11 = *(int *)(param_1 + 0x60);
    if (iVar8 - iVar11 >> 3 != 0) {
      do {
        if (uVar9 < uVar13) {
          iVar8 = *(int *)(*(int *)(iVar11 + uVar7 * 8) + 0x90);
          if (iVar8 == 0) {
            iVar8 = 0;
          }
          else {
            iVar8 = FUN_0147d000(*(undefined4 *)(iVar8 + 0x2c),*(undefined4 *)(iVar8 + 0x30),
                                 *(undefined4 *)(iVar8 + 0x34));
          }
          uVar13 = uVar13 - iVar8;
          *(undefined *)(iStack_30 + uVar7) = 1;
        }
        uVar7 = uVar7 + 1;
        iVar8 = *(int *)(param_1 + 100);
        iVar11 = *(int *)(param_1 + 0x60);
      } while (uVar7 < (uint)(iVar8 - iVar11 >> 3));
    }
    iVar14 = 2;
    iVar2 = *(int *)(*(int *)(*(int *)(param_1 + 0x30) + 0x4e4) + 0x24);
    for (iVar8 = iVar8 - iVar11 >> 3; iVar8 != 0; iVar8 = iVar8 + -1) {
      iVar11 = *(int *)(param_1 + 0x60);
      iVar3 = *(int *)(iVar11 + -8 + iVar8 * 8);
      if (((*(int *)(iVar3 + 0x90) != 0) &&
          (*(uint *)(*(int *)(iVar3 + 0x90) + 0x30) < *(uint *)(iVar3 + 0x18))) && (iVar14 != 0)) {
        iVar14 = iVar14 + -1;
        *(undefined *)(iStack_30 + -1 + iVar8) = 0;
      }
      if (((DAT_01d60d04 != '\0') && (*(int *)(iVar3 + 0x90) != 0)) &&
         ((*(int *)(*(int *)(iVar3 + 0x90) + 0x48) == 3 &&
          (iVar2 == *(int *)(*(int *)(iVar11 + iVar8 * 8 + -8) + 0xa0))))) {
        *(undefined *)(iStack_30 + -1 + iVar8) = 0;
      }
    }
    uVar7 = 0;
    if (iStack_2c != iStack_30) {
      do {
        iVar8 = *(int *)(*(int *)(param_1 + 0x60) + uVar7 * 8);
        if ((*(char *)(iStack_30 + uVar7) != '\0') && (iVar11 = *(int *)(iVar8 + 0x90), iVar11 != 0)
           ) {
          if (DAT_01eb1b24 != '\0') {
            FUN_016774b0(DAT_01eb1b24,"TC Destroy texture %p",iVar11);
          }
          *(undefined4 *)(iVar8 + 0x98) = 0;
          piVar15 = *(int **)(iVar8 + 0x9c);
          *(undefined4 *)(iVar8 + 0x9c) = 0;
          if (piVar15 != (int *)0x0) {
            LOCK();
            iVar11 = piVar15[1] + -1;
            piVar15[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*piVar15)();
              LOCK();
              iVar11 = piVar15[2] + -1;
              piVar15[2] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*piVar15 + 4))();
              }
            }
          }
          *(int *)(iVar8 + 0x90) = 0;
          piVar15 = *(int **)(iVar8 + 0x94);
          *(undefined4 *)(iVar8 + 0x94) = 0;
          if (piVar15 != (int *)0x0) {
            LOCK();
            iVar11 = piVar15[1] + -1;
            piVar15[1] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)*piVar15)();
              LOCK();
              iVar11 = piVar15[2] + -1;
              piVar15[2] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)(*piVar15 + 4))();
              }
            }
          }
          *(undefined4 *)(iVar8 + 0xa0) = 0;
        }
        uVar7 = uVar7 + 1;
      } while (uVar7 < (uint)(iStack_2c - iStack_30));
    }
    if (iStack_30 != 0) {
      uVar7 = iStack_28 - iStack_30;
      iVar8 = iStack_30;
      if (0xfff < uVar7) {
        iVar8 = *(int *)(iStack_30 + -4);
        uVar7 = uVar7 + 0x23;
        if (0x1f < (iStack_30 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar7);
    }
  }
  piVar15 = (int *)*piVar12;
  piVar4 = *(int **)(param_1 + 100);
  iVar8 = param_1;
  if (piVar15 != piVar4) {
    do {
      iVar8 = *piVar15;
      if (*(int *)(iVar8 + 0x90) == 0) break;
      piVar15 = piVar15 + 2;
    } while (piVar15 != piVar4);
    piVar6 = piVar15;
    if (piVar15 != piVar4) {
      while (piVar6 = piVar6 + 2, piVar6 != piVar4) {
        iVar11 = *piVar6;
        if (*(int *)(iVar11 + 0x90) != 0) {
          iVar8 = piVar6[1];
          *piVar6 = 0;
          piVar6[1] = 0;
          *piVar15 = iVar11;
          piVar5 = (int *)piVar15[1];
          piVar15[1] = iVar8;
          if (piVar5 != (int *)0x0) {
            LOCK();
            piVar1 = piVar5 + 1;
            iVar11 = *piVar1;
            iVar8 = *piVar1;
            *piVar1 = iVar11 + -1;
            UNLOCK();
            if (iVar11 + -1 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              piVar1 = piVar5 + 2;
              iVar11 = *piVar1;
              iVar8 = *piVar1;
              *piVar1 = iVar11 + -1;
              UNLOCK();
              if (iVar11 + -1 == 0) {
                iVar8 = (**(code **)(*piVar5 + 4))();
              }
            }
          }
          piVar15 = piVar15 + 2;
        }
      }
      if (piVar15 != piVar4) {
        uVar10 = FUN_00775350(piVar4,*(undefined4 *)(param_1 + 100),piVar15);
        iVar8 = FUN_005596d0(uVar10,*(undefined4 *)(param_1 + 100),piVar12);
        *(undefined4 *)(param_1 + 100) = uVar10;
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 10999 ; VA 0x00778d90 ; FUN_00778d90 */

void __thiscall
FUN_00778d90(int param_1,int *param_2,byte *param_3,undefined4 *param_4,int param_5,
            undefined4 param_6,undefined4 *param_7,int *param_8,int *param_9)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  undefined4 ****ppppuVar8;
  int iVar9;
  int iVar10;
  int *piVar11;
  byte *pbVar12;
  byte *pbVar13;
  undefined4 *puVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  byte *pbVar18;
  undefined4 *puVar19;
  bool bVar20;
  float10 fVar21;
  float10 fVar22;
  undefined4 ***apppuStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined8 uStack_34;
  undefined8 uStack_2c;
  undefined8 uStack_24;
  int *piStack_1c;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af408;
  pvStack_10 = ExceptionList;
  uStack_2c = (double)CONCAT44((int *)(param_1 + 0x40),(undefined4)uStack_2c);
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00718820((int)&uStack_24 + 4,param_3);
  iVar9 = uStack_24._4_4_;
  if ((uStack_24._4_4_ == *(int *)(param_1 + 0x40)) ||
     (cVar2 = FUN_00570370(param_3,uStack_24._4_4_ + 0x10), cVar2 != '\0')) {
    uStack_24 = (double)CONCAT44(param_3,(undefined4)uStack_24);
    iVar3 = FUN_00559280(&DAT_018bdeda,(int)&uStack_24 + 4,&uStack_11);
    FUN_007745f0((int)&uStack_24 + 4,iVar9,iVar3 + 0x10,iVar3);
    iVar9 = uStack_24._4_4_;
  }
  iVar3 = *(int *)(iVar9 + 0x28);
  piVar7 = (int *)(iVar9 + 0x28);
  if (iVar3 != 0) {
    iVar10 = *(int *)(iVar9 + 0x2c);
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar10 != 0) {
      LOCK();
      *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + 1;
      UNLOCK();
      iVar3 = *piVar7;
      iVar10 = *(int *)(iVar9 + 0x2c);
    }
    *param_2 = iVar3;
    param_2[1] = iVar10;
    ExceptionList = pvStack_10;
    return;
  }
  uStack_24 = (double)((ulonglong)uStack_24 & 0xffffffff);
  piVar6 = *(int **)(iStack_18 + 0x60);
  uStack_34 = (double)CONCAT44(piVar6,(int)uStack_34);
  piVar11 = piVar6;
  piStack_38 = piVar7;
  if (*(int *)(iStack_18 + 100) - (int)piVar6 >> 3 != 0) {
    do {
      pbVar13 = (byte *)*piVar11;
      pbVar18 = param_3;
      if (0xf < *(uint *)(param_3 + 0x14)) {
        pbVar18 = *(byte **)param_3;
      }
      uVar4 = *(uint *)(pbVar13 + 0x10);
      pbVar12 = pbVar13;
      if (0xf < *(uint *)(pbVar13 + 0x14)) {
        pbVar12 = *(byte **)pbVar13;
      }
      if (uVar4 == *(uint *)(param_3 + 0x10)) {
        while (uVar15 = uVar4 - 4, 3 < uVar4) {
          if (*(int *)pbVar12 != *(int *)pbVar18) goto LAB_00778eab;
          pbVar12 = pbVar12 + 4;
          pbVar18 = pbVar18 + 4;
          uVar4 = uVar15;
        }
        if (uVar15 == 0xfffffffc) {
LAB_00778edf:
          uVar4 = 0;
        }
        else {
LAB_00778eab:
          bVar20 = *pbVar12 < *pbVar18;
          if ((*pbVar12 == *pbVar18) &&
             ((uVar15 == 0xfffffffd ||
              ((bVar20 = pbVar12[1] < pbVar18[1], pbVar12[1] == pbVar18[1] &&
               ((uVar15 == 0xfffffffe ||
                ((bVar20 = pbVar12[2] < pbVar18[2], pbVar12[2] == pbVar18[2] &&
                 ((uVar15 == 0xffffffff ||
                  (bVar20 = pbVar12[3] < pbVar18[3], pbVar12[3] == pbVar18[3]))))))))))))
          goto LAB_00778edf;
          uVar4 = -(uint)bVar20 | 1;
        }
        if ((uVar4 == 0) && (*(int *)(pbVar13 + 0x90) != 0)) {
          piStack_1c = piVar11;
          if (DAT_01eb1b24 != '\0') {
            FUN_016774b0(DAT_01eb1b24,"TC Job[%p]: restoring orphaned job",pbVar13);
          }
          iVar3 = piStack_1c[1];
          if (iVar3 != 0) {
            LOCK();
            *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
            UNLOCK();
            iVar3 = piStack_1c[1];
          }
          *piVar7 = *piStack_1c;
          piVar6 = *(int **)(iVar9 + 0x2c);
          *(int *)(iVar9 + 0x2c) = iVar3;
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar9 = piVar6[1] + -1;
            piVar6[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              iVar9 = piVar6[2] + -1;
              piVar6[2] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
          FUN_007735a0(*piVar7 + 0x90,3);
          piVar11 = piStack_38;
          uVar5 = uStack_3c;
          iVar9 = *piVar7;
          uStack_3c = 0;
          piStack_38 = (int *)0x0;
          *(undefined4 *)(iVar9 + 0xa4) = uVar5;
          piVar6 = *(int **)(iVar9 + 0xa8);
          *(int **)(iVar9 + 0xa8) = piVar11;
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar9 = piVar6[1] + -1;
            piVar6[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              iVar9 = piVar6[2] + -1;
              piVar6[2] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
          piVar6 = piStack_38;
          if (piStack_38 != (int *)0x0) {
            LOCK();
            iVar9 = piStack_38[1] + -1;
            piStack_38[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)*piStack_38)();
              LOCK();
              piVar11 = piVar6 + 2;
              iVar9 = *piVar11 + -1;
              *piVar11 = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
          iVar3 = iStack_18;
          iVar9 = *(int *)(iStack_18 + 0x60) + uStack_24._4_4_ * 8;
          FUN_00775350(iVar9 + 8,*(undefined4 *)(iStack_18 + 100),iVar9);
          piVar6 = *(int **)(*(int *)(iVar3 + 100) + -4);
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar9 = piVar6[1] + -1;
            piVar6[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              piVar11 = piVar6 + 2;
              iVar9 = *piVar11;
              *piVar11 = *piVar11 + -1;
              UNLOCK();
              if (iVar9 == 1) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
          *(int *)(iStack_18 + 100) = *(int *)(iStack_18 + 100) + -8;
          goto LAB_007795dd;
        }
      }
      uVar4 = uStack_24._4_4_ + 1;
      piVar11 = piVar11 + 2;
      uStack_24 = (double)CONCAT44(uVar4,(undefined4)uStack_24);
      piStack_1c = piVar11;
    } while (uVar4 < (uint)(*(int *)(iStack_18 + 100) - (int)piVar6 >> 3));
  }
  iVar3 = FUN_01674e20();
  uStack_34 = (double)CONCAT44(iVar3,(int)uStack_34);
  if (iVar3 == 0) {
    uVar5 = 0;
  }
  else {
    FUN_0170d1f0(iVar3,0,0xb4);
    uVar5 = FUN_007769b0();
  }
  uStack_34 = 0.0;
  FUN_007759c0(uVar5,param_3);
  *piVar7 = (int)uStack_34;
  piVar6 = *(int **)(iVar9 + 0x2c);
  *(int **)(iVar9 + 0x2c) = uStack_34._4_4_;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar9 = piVar6[1] + -1;
    piVar6[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar9 = piVar6[2] + -1;
      piVar6[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  pbVar13 = (byte *)*piVar7;
  if (pbVar13 != param_3) {
    pbVar13 = param_3;
    if (0xf < *(uint *)(param_3 + 0x14)) {
      pbVar13 = *(byte **)param_3;
    }
    FUN_005542c0(pbVar13,*(int *)(param_3 + 0x10));
    pbVar13 = (byte *)*piVar7;
  }
  *(int *)(pbVar13 + 0x18) = param_5;
  *(undefined4 *)(*piVar7 + 0x1c) = param_6;
  iVar9 = *piVar7;
  *(undefined4 *)(iVar9 + 0x20) = *param_7;
  *(undefined4 *)(iVar9 + 0x24) = param_7[1];
  param_7 = (undefined4 *)*piVar7;
  if (param_7 + 10 != param_8) {
    FUN_00773da0(*param_8,param_8[1],param_3);
    param_7 = (undefined4 *)*piVar7;
  }
  puVar19 = param_4;
  if (param_7 + 0x11 != param_4) {
    puVar14 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar14 = (undefined4 *)*param_4;
    }
    FUN_005542c0(puVar14,param_4[4]);
  }
  piVar6 = puVar19 + 6;
  if (param_7 + 0x17 != piVar6) {
    if (0xf < (uint)puVar19[0xb]) {
      piVar6 = (int *)*piVar6;
    }
    FUN_005542c0(piVar6,puVar19[10]);
  }
  piVar6 = puVar19 + 0xc;
  if (param_7 + 0x1d != piVar6) {
    if (0xf < (uint)puVar19[0x11]) {
      piVar6 = (int *)*piVar6;
    }
    FUN_005542c0(piVar6,puVar19[0x10]);
  }
  param_7[0x23] = puVar19[0x12];
  *(undefined4 *)(*piVar7 + 0x40) = 0x7f7fffff;
  if (param_9[4] == 0) {
    puVar19 = (undefined4 *)
              FUN_00773a00(&uStack_34,*(int *)(*(int *)(iStack_18 + 0x30) + 0x4ec) + 0x2c);
    iVar9 = *piVar7;
    uVar5 = *puVar19;
    uVar1 = puVar19[1];
    *puVar19 = 0;
    puVar19[1] = 0;
    *(undefined4 *)(iVar9 + 0xa4) = uVar5;
    piVar6 = *(int **)(iVar9 + 0xa8);
    *(undefined4 *)(iVar9 + 0xa8) = uVar1;
  }
  else {
    FUN_00718820(&param_4,param_9);
    puVar19 = param_4;
    param_7 = (undefined4 *)*uStack_2c._4_4_;
    if ((param_4 == param_7) || (cVar2 = FUN_00570370(param_9,param_4 + 4), cVar2 != '\0')) {
      puVar19 = param_7;
    }
    if ((((puVar19 != param_7) && (iVar9 = *(int *)(puVar19[10] + 0xa4), iVar9 != 0)) &&
        (*(int *)(iVar9 + 8) != 2)) && (*(int *)(iVar9 + 8) != 0)) {
      FUN_00773a00(&uStack_34,iVar9);
      FUN_005587e0();
      goto LAB_007792c7;
    }
    puVar19 = (undefined4 *)
              FUN_00773a00(&uStack_34,*(int *)(*(int *)(iStack_18 + 0x30) + 0x4ec) + 0x2c);
    iVar9 = *piVar7;
    uVar5 = *puVar19;
    uVar1 = puVar19[1];
    *puVar19 = 0;
    puVar19[1] = 0;
    *(undefined4 *)(iVar9 + 0xa4) = uVar5;
    piVar6 = *(int **)(iVar9 + 0xa8);
    *(undefined4 *)(iVar9 + 0xa8) = uVar1;
  }
  param_9 = piVar6;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar9 = piVar6[1] + -1;
    piVar6[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar9 = piVar6[2] + -1;
      piVar6[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
LAB_007792c7:
  piVar6 = uStack_34._4_4_;
  if (uStack_34._4_4_ != (int *)0x0) {
    LOCK();
    iVar9 = uStack_34._4_4_[1] + -1;
    uStack_34._4_4_[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*uStack_34._4_4_)();
      LOCK();
      piVar11 = piVar6 + 2;
      iVar9 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = param_8;
  if ((DAT_01eb1b24 != '\0') &&
     (FUN_016773b0(DAT_01eb1b24,"TC Job[%p]: create %dx%d (%d layers)",*piVar7,param_5,param_6,
                   (param_8[1] - *param_8) / 0x54,0), DAT_01eb1b24 != '\0')) {
    if (0xf < *(uint *)(param_3 + 0x14)) {
      param_3 = *(byte **)param_3;
    }
    FUN_01677650(DAT_01eb1b24,"TC Job texture: %s",param_3);
    piVar6 = param_8;
  }
  iVar9 = *piVar6;
  param_8 = (int *)0x0;
  iVar3 = piVar6[1] - iVar9 >> 0x1f;
  if ((piVar6[1] - iVar9) / 0x54 + iVar3 != iVar3) {
    param_9 = (int *)0x0;
    cVar2 = DAT_01eb1b24;
    do {
      if (cVar2 != '\0') {
        puVar19 = (undefined4 *)(iVar9 + (int)param_9);
        param_6 = puVar19[0x14];
        uStack_34 = (double)(*(float *)(iVar9 + 0x30 + (int)param_9) * DAT_018f9980);
        fVar21 = (float10)FUN_01725280(uStack_34);
        uStack_2c = (double)fVar21;
        uStack_34 = (double)((float)puVar19[0xd] * DAT_018f9980);
        fVar21 = (float10)FUN_01725280(uStack_34);
        uStack_24 = (double)fVar21;
        uStack_34 = (double)((float)puVar19[0xe] * DAT_018f9980);
        fVar21 = (float10)FUN_01725280(uStack_34);
        uStack_34 = (double)((float)puVar19[0xf] * DAT_018f9980);
        fVar22 = (float10)FUN_01725280(uStack_34);
        uStack_34 = (double)fVar22;
        uVar4 = 0xff;
        if ((int)fVar22 < 0x100) {
          uVar4 = (int)fVar22 & 0xff;
        }
        uVar15 = 0xff;
        if ((int)uStack_2c < 0x100) {
          uVar15 = (int)uStack_2c & 0xff;
        }
        uVar16 = 0xff;
        if ((int)uStack_24 < 0x100) {
          uVar16 = (int)uStack_24 & 0xff;
        }
        uVar17 = 0xff;
        if ((int)fVar21 < 0x100) {
          uVar17 = (int)fVar21 & 0xff;
        }
        piVar7 = puVar19 + 6;
        if (0xf < (uint)puVar19[0xb]) {
          piVar7 = (int *)*piVar7;
        }
        if (0xf < (uint)puVar19[5]) {
          puVar19 = (undefined4 *)*puVar19;
        }
        FUN_01675640(apppuStack_54,"L[%s:%s:%08x:%d]",puVar19,piVar7,
                     ((uVar4 * 0x100 + uVar15) * 0x100 + uVar16) * 0x100 + uVar17,param_6);
        uStack_8 = 0;
        ppppuVar8 = apppuStack_54;
        if (0xf < uStack_40) {
          ppppuVar8 = (undefined4 ****)apppuStack_54[0];
        }
        FUN_01677650(DAT_01eb1b24,"TC Job layer: %s",ppppuVar8);
        uStack_8 = 0xffffffff;
        if (0xf < uStack_40) {
          uVar4 = uStack_40 + 1;
          ppppuVar8 = (undefined4 ****)apppuStack_54[0];
          if (0xfff < uVar4) {
            ppppuVar8 = (undefined4 ****)apppuStack_54[0][-1];
            uVar4 = uStack_40 + 0x24;
            if (0x1f < (uint)((int)apppuStack_54[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(ppppuVar8,uVar4);
        }
        iVar9 = *piVar6;
        uStack_44 = 0;
        uStack_40 = 0xf;
        apppuStack_54[0] = (undefined4 ***)((uint)apppuStack_54[0] & 0xffffff00);
        cVar2 = DAT_01eb1b24;
      }
      param_8 = (int *)((int)param_8 + 1);
      param_9 = param_9 + 0x15;
      piVar7 = piStack_38;
    } while (param_8 < (uint)((piVar6[1] - iVar9) / 0x54));
  }
  piVar6 = *(int **)(iStack_18 + 0x4c);
  if (*(int **)(iStack_18 + 0x50) == piVar6) {
    FUN_00603260(piVar6,piVar7);
  }
  else {
    *piVar6 = 0;
    piVar6[1] = 0;
    if (piVar7[1] != 0) {
      LOCK();
      piVar11 = (int *)(piVar7[1] + 4);
      *piVar11 = *piVar11 + 1;
      UNLOCK();
    }
    *piVar6 = *piVar7;
    piVar6[1] = piVar7[1];
    *(int *)(iStack_18 + 0x4c) = *(int *)(iStack_18 + 0x4c) + 8;
  }
  if (DAT_01eb1b24 != '\0') {
    FUN_016774b0(DAT_01eb1b24,"TC Job[%p]: queueing (external request)",*piVar7);
  }
LAB_007795dd:
  iVar9 = piVar7[1];
  param_2[1] = 0;
  *param_2 = 0;
  if (iVar9 != 0) {
    LOCK();
    *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
    UNLOCK();
    iVar9 = piVar7[1];
  }
  *param_2 = *piVar7;
  param_2[1] = iVar9;
  ExceptionList = pvStack_10;
  return;
}


