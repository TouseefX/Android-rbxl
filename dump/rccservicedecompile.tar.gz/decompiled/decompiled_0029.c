/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 7250 ; VA 0x00642210 ; FUN_00642210 */

undefined4 __thiscall FUN_00642210(undefined4 param_1,byte param_2)

{
  FUN_006410e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x4c);
  }
  return param_1;
}



/* FUNCTION 7251 ; VA 0x00642240 ; FUN_00642240 */

int __thiscall FUN_00642240(int param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  
  iVar1 = *(int *)(param_1 + 0x134);
  if (iVar1 != 0) {
    uVar4 = *(int *)(param_1 + 0x13c) - iVar1 & 0xfffffffc;
    iVar3 = iVar1;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
    *(undefined4 *)(param_1 + 0x134) = 0;
    *(undefined4 *)(param_1 + 0x138) = 0;
    *(undefined4 *)(param_1 + 0x13c) = 0;
  }
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = piVar2[2] + -1;
    piVar2[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x168);
  }
  return param_1;
}



/* FUNCTION 7252 ; VA 0x006422e0 ; FUN_006422e0 */

undefined4 __thiscall FUN_006422e0(undefined4 param_1,byte param_2)

{
  FUN_00641320();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x490);
  }
  return param_1;
}



/* FUNCTION 7253 ; VA 0x00642310 ; FUN_00642310 */

undefined4 FUN_00642310(void)

{
  return 1;
}



/* FUNCTION 7254 ; VA 0x00642320 ; FUN_00642320 */

/* WARNING: Removing unreachable block (ram,0x00642657) */
/* WARNING: Removing unreachable block (ram,0x00642660) */
/* WARNING: Removing unreachable block (ram,0x00642670) */

undefined4 __thiscall FUN_00642320(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined uVar4;
  int *piVar5;
  undefined4 uVar6;
  char *pcVar7;
  float10 fVar8;
  undefined **ppuVar9;
  undefined4 uVar10;
  undefined *puStack_f8;
  int *piStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  uint uStack_e8;
  char *pcStack_e4;
  char **ppcStack_e0;
  undefined4 *puStack_dc;
  char *pcStack_d8;
  int *piStack_d4;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  int aiStack_8c [9];
  undefined4 uStack_68;
  int *piStack_64;
  undefined8 uStack_5c;
  char *apcStack_54 [4];
  undefined auStack_44 [4];
  int *piStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int iStack_34;
  undefined8 uStack_2c;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0a06;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff30;
  piStack_d4 = (int *)DAT_01eadc98;
  pcStack_d8 = (char *)0x642354;
  ExceptionList = &pvStack_10;
  iStack_24 = param_1;
  uStack_3c = FUN_01675290();
  if (*(char *)param_2[0xe] != '\x13') {
    uStack_8 = 10;
    pcStack_d8 = (char *)0x6427f6;
    piStack_d4 = (int *)uStack_3c;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return 1;
  }
  iStack_38 = 0;
  iStack_34 = 0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  if (DAT_01ee420a != 0) {
    piStack_d4 = (int *)0x0;
    puStack_dc = (undefined4 *)(uint)DAT_01ee420a;
    pcStack_d8 = "NetworkServer:NewIncomingConnection";
    ppcStack_e0 = (char **)0x6423a5;
    FUN_016774b0();
  }
  if (DAT_01ee4213 != 0) {
    piStack_d4 = (int *)0x6423b6;
    fVar8 = (float10)FUN_01683110();
    uStack_e8 = (uint)DAT_01ee4213;
    uStack_2c = (double)fVar8;
    ppcStack_e0 = (char **)(float)fVar8;
    piStack_d4 = (int *)0x0;
    pcStack_d8 = (char *)0x0;
    puStack_dc = (undefined4 *)0x0;
    pcStack_e4 = "Server::OnReceive new connection @ %f s";
    uStack_ec = 0x6423f4;
    FUN_016774d0();
  }
  if (DAT_01d84e8d != 0) {
    piStack_d4 = (int *)0x7c;
    pcStack_d8 = (char *)0x1;
    puStack_dc = param_2;
    ppcStack_e0 = apcStack_54;
    pcStack_e4 = (char *)0x642410;
    piStack_d4 = (int *)FUN_006b1620();
    uStack_8._0_1_ = 4;
    if (0xf < (uint)piStack_d4[5]) {
      piStack_d4 = (int *)*piStack_d4;
    }
    puStack_dc = (undefined4 *)(uint)DAT_01d84e8d;
    pcStack_d8 = "New connection from %s";
    ppcStack_e0 = (char **)0x642432;
    FUN_01677520();
    uStack_8._0_1_ = 3;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (&DAT_0000000f < piStack_40) {
      piStack_d4 = (int *)((int)piStack_40 + 1);
      pcVar7 = apcStack_54[0];
      if ((int *)0xfff < piStack_d4) {
        pcVar7 = *(char **)(apcStack_54[0] + -4);
        piStack_d4 = piStack_40 + 9;
        if ((char *)0x1f < apcStack_54[0] + (-4 - (int)pcVar7)) {
                    /* WARNING: Subroutine does not return */
          piStack_d4 = (int *)0x642816;
          uStack_8._0_1_ = uVar4;
          FUN_017167a3();
        }
      }
      puStack_dc = (undefined4 *)0x64246a;
      pcStack_d8 = pcVar7;
      FUN_01674ea0();
    }
  }
  aiStack_8c[0] = -1;
  piStack_d4 = (int *)0x642482;
  FUN_005f7140();
  uStack_68 = 0;
  piStack_64 = (int *)0x0;
  piStack_d4 = *(int **)(param_1 + 0xb4);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  *(int *)(param_1 + 0xb4) = (int)piStack_d4 + 1;
  aiStack_8c[0] = (int)piStack_d4;
  if (DAT_01ee420a != 0) {
    puStack_dc = (undefined4 *)(uint)DAT_01ee420a;
    pcStack_d8 = "assigning peer id = %d";
    ppcStack_e0 = (char **)0x6424c1;
    FUN_016774b0();
  }
  piStack_d4 = param_2;
  pcStack_d8 = (char *)0x6424d2;
  FUN_005f7170();
  piVar5 = *(int **)(param_1 + 0x78);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = *(int **)(param_1 + 0x78);
  }
  uStack_68 = *(undefined4 *)(param_1 + 0x74);
  piStack_18 = piStack_64;
  if (piStack_64 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_64[1] + -1;
    piStack_64[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puVar2 = (undefined4 *)*piStack_64;
      piStack_d4 = (int *)0x642503;
      piStack_64 = piVar5;
      (*(code *)*puVar2)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      piVar5 = piStack_64;
      if (iVar3 == 0) {
        piStack_d4 = (int *)0x642514;
        (**(code **)(*piStack_18 + 4))();
        piVar5 = piStack_64;
      }
    }
  }
  piStack_64 = piVar5;
  piStack_d4 = (int *)0x64251f;
  piStack_18 = (int *)FUN_0054db20();
  uStack_f0 = *param_2;
  uStack_ec = param_2[1];
  uStack_e8 = param_2[2];
  pcStack_e4 = (char *)param_2[3];
  ppcStack_e0 = (char **)param_2[4];
  puStack_dc = (undefined4 *)param_2[5];
  pcStack_d8 = (char *)param_2[6];
  piStack_d4 = (int *)param_2[7];
  piStack_f4 = (int *)0x642545;
  uStack_5c = (**(code **)(*piStack_18 + 0x150))();
  iStack_1c = *(undefined4 *)(iStack_24 + 0x354);
  piStack_18 = (int *)(iStack_24 + -0x54);
  piStack_f4 = aiStack_8c;
  puStack_f8 = (undefined *)0x64256f;
  FUN_005ef5c0();
  uStack_8._0_1_ = 6;
  if (DAT_01ead770 == 0) {
    piStack_f4 = (int *)0x64281e;
    piStack_f4 = (int *)FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
                    /* WARNING: Subroutine does not return */
    puStack_f8 = &UNK_00642828;
    FUN_0054e5e0();
  }
  piStack_f4 = (int *)iStack_1c;
  puStack_f8 = (undefined *)piStack_18;
  piVar5 = (int *)(**(code **)((DAT_01ead770 & 0xfffffffe) + 4))
                            (auStack_44,&DAT_01ead778,uStack_c4,uStack_c0,uStack_bc,uStack_b8,
                             uStack_b4,uStack_b0,uStack_ac,uStack_a8,uStack_a4,uStack_a0,uStack_9c);
  iStack_1c = *piVar5;
  iStack_20 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  uStack_2c._4_4_ = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_40[1] + -1;
    piStack_40[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      piStack_f4 = (int *)0x642635;
      (**(code **)*piStack_40)();
      LOCK();
      iVar3 = uStack_2c._4_4_[2] + -1;
      uStack_2c._4_4_[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_f4 = (int *)0x642646;
        (**(code **)(*uStack_2c._4_4_ + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uStack_2c._4_4_ = (int *)0x0;
  iStack_38 = iStack_1c;
  iStack_34 = iStack_20;
  piStack_f4 = (int *)0x64268c;
  piVar5 = (int *)FUN_0054db20();
  ppuVar9 = &puStack_f8;
  uStack_2c = (double)CONCAT44(piVar5,(undefined4)uStack_2c);
  uVar6 = *param_2;
  uVar10 = param_2[2];
  (**(code **)(*piVar5 + 0x158))
            (&puStack_f8,uVar6,param_2[1],uVar10,param_2[3],param_2[4],param_2[5],param_2[6],
             param_2[7]);
  iVar3 = iStack_1c;
  FUN_006307a0(ppuVar9,uVar6);
  if (*(char *)(iVar3 + 0x3860) != '\0') {
    (**(code **)(*(int *)(iVar3 + 0x5c) + 0x20))
              (param_2,param_2[8],param_2[9],param_2[10],param_2[0xb],1);
  }
  FUN_008a5700(piStack_18);
  piVar5 = piStack_64;
  if (piStack_64 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_64[1] + -1;
    piStack_64[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_64)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uVar6 = FUN_006427c8(uVar10);
  return uVar6;
}



/* FUNCTION 7255 ; VA 0x00642728 ; Catch@00642728 */

undefined * Catch_00642728(void)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_EBP;
  int *piVar3;
  
  iVar1 = *(int *)(unaff_EBP + 8);
  if (DAT_01d84e8e == '\0') {
    piVar3 = *(int **)(unaff_EBP + -0x2c);
  }
  else {
    FUN_016774b0(DAT_01d84e8e,"On receive packet %d",**(undefined **)(iVar1 + 0x38));
    piVar3 = *(int **)(unaff_EBP + -0x2c);
    if (DAT_01d84e8e != '\0') {
      uVar2 = (**(code **)(*piVar3 + 4))();
      FUN_01677650(DAT_01d84e8e,"Error %s",uVar2);
    }
  }
  uVar2 = (**(code **)(*piVar3 + 4))();
  FUN_0086f2f0(3,"Server::OnReceive packet %d: %s",**(undefined **)(iVar1 + 0x38),uVar2);
  if (*(int *)(unaff_EBP + -0x34) != 0) {
    *(undefined *)(*(int *)(unaff_EBP + -0x34) + 0x22) = 0;
    FUN_008a65e0(0,0);
  }
  return &DAT_006427bc;
}



/* FUNCTION 7256 ; VA 0x006427c8 ; FUN_006427c8 */

undefined4 __fastcall FUN_006427c8(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int unaff_EBP;
  int unaff_EDI;
  
  if (param_1 != (undefined4 *)0x0) {
    LOCK();
    iVar3 = param_1[1] + unaff_EDI;
    param_1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_1)();
      piVar2 = *(int **)(unaff_EBP + -0x1c);
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + unaff_EDI;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *(undefined4 *)(unaff_EBP + -4) = 9;
  FUN_01675290();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return 1;
}



/* FUNCTION 7257 ; VA 0x00642830 ; FUN_00642830 */

uint __thiscall FUN_00642830(uint *param_1,uint param_2)

{
  uint in_EAX;
  uint uVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return in_EAX & 0xffffff00;
  }
  if (0x7fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (param_2 < 0x1000) {
    uVar1 = FUN_01674e20(param_2);
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + param_2;
    return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
  }
  uVar1 = param_2 + 0x23;
  if (uVar1 <= param_2) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar1 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar1 - 4) = iVar2;
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + param_2;
    return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 7258 ; VA 0x006428d0 ; FUN_006428d0 */

void __fastcall FUN_006428d0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_006410e0();
    FUN_01674ea0(iVar1,0x4c);
  }
  return;
}



/* FUNCTION 7259 ; VA 0x006428f0 ; FUN_006428f0 */

void __fastcall FUN_006428f0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x5c);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 100) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x5c) = 0;
    *(undefined4 *)(param_1 + 0x60) = 0;
    *(undefined4 *)(param_1 + 100) = 0;
  }
  FUN_00613200();
  FUN_00613200();
  return;
}



/* FUNCTION 7260 ; VA 0x00642960 ; FUN_00642960 */

void __fastcall FUN_00642960(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x46) * 0x46;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 7261 ; VA 0x006429d0 ; FUN_006429d0 */

void FUN_006429d0(int *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_1 != param_2) {
    piVar3 = param_3;
    piVar4 = param_1;
    do {
      iVar2 = *piVar4;
      *piVar3 = iVar2;
      LOCK();
      piVar1 = (int *)(iVar2 + 0x28);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      iVar2 = *(int *)((int)param_1 + (4 - (int)param_3) + (int)piVar3);
      piVar3[1] = iVar2;
      LOCK();
      piVar1 = (int *)(iVar2 + 0x28);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      piVar4 = piVar4 + 2;
      piVar3 = piVar3 + 2;
    } while (piVar4 != param_2);
  }
  return;
}



/* FUNCTION 7262 ; VA 0x00642a10 ; FUN_00642a10 */

bool FUN_00642a10(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_005ee350();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_00642a42;
  }
  param_1 = 0;
LAB_00642a42:
  return param_1 != 0;
}



/* FUNCTION 7263 ; VA 0x00642a50 ; FUN_00642a50 */

undefined FUN_00642a50(undefined4 param_1)

{
  char cVar1;
  undefined uVar2;
  
  cVar1 = FUN_008a9600(param_1);
  if (cVar1 != '\0') {
    uVar2 = FUN_005c92d0(param_1);
    return uVar2;
  }
  return 0;
}



/* FUNCTION 7264 ; VA 0x00642a80 ; FUN_00642a80 */

void __fastcall FUN_00642a80(int param_1)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0a20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00973950(param_1,1);
  if (cVar1 == '\0') {
    if (DAT_01d5a4d0 != '\0') {
      if (DAT_01d5a4c0 == '\0') {
        FUN_005f2040();
      }
      piVar2 = (int *)FUN_0054db20();
      puVar4 = &DAT_01d59b00;
      if (0xf < DAT_01d59b14) {
        puVar4 = DAT_01d59b00;
      }
      (**(code **)(*piVar2 + 0x28))(puVar4,DAT_01d59b10);
      *(undefined4 *)(param_1 + 0x124) = 2;
      FUN_006de110();
      FUN_0087c450(&DAT_018c5f98,"Team Create","Server Start",0,0,0);
      if (DAT_01d5a540 != '\0') {
        iVar3 = FUN_00876670();
        if (iVar3 != 0) {
          uStack_3c = 0;
          uStack_38 = 0xf;
          auStack_4c[0] = 0;
          FUN_005542c0(&DAT_018cf4c4,4);
          uStack_8 = 0;
          uStack_24 = 0;
          uStack_20 = 0xf;
          auStack_34[0] = 0;
          FUN_005542c0("rcc_tc_config",0xd);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_00990990(auStack_34,auStack_4c);
          FUN_005507b0();
          FUN_005507b0();
        }
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  FUN_016756b0(auStack_1c,"Can not call server, client is present.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 7265 ; VA 0x00642be0 ; FUN_00642be0 */

void __fastcall FUN_00642be0(int param_1)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0a20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00973950(param_1,1);
  if (cVar1 == '\0') {
    if (DAT_01d5a4d8 != '\0') {
      if (DAT_01d5a4c0 == '\0') {
        FUN_005f2040();
      }
      piVar2 = (int *)FUN_0054db20();
      puVar4 = &DAT_01d59b00;
      if (0xf < DAT_01d59b14) {
        puVar4 = DAT_01d59b00;
      }
      (**(code **)(*piVar2 + 0x28))(puVar4,DAT_01d59b10);
      *(undefined4 *)(param_1 + 0x124) = 1;
      FUN_0087c450(&DAT_018c5f98,"Team Create","Test Server Start",0,0,0);
      if (DAT_01d5a540 != '\0') {
        iVar3 = FUN_00876670();
        if (iVar3 != 0) {
          uStack_3c = 0;
          uStack_38 = 0xf;
          auStack_4c[0] = 0;
          FUN_005542c0("team_test",9);
          uStack_8 = 0;
          uStack_24 = 0;
          uStack_20 = 0xf;
          auStack_34[0] = 0;
          FUN_005542c0("rcc_tc_config",0xd);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_00990990(auStack_34,auStack_4c);
          FUN_005507b0();
          uStack_8 = 0xffffffff;
          FUN_005507b0();
        }
      }
      if (DAT_01ead6a1 != '\0') {
        FUN_016774b0(DAT_01ead6a1,"Finished configuring as team test server",0);
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  FUN_016756b0(auStack_1c,"Cannot call configureAsTeamTestServer() from clients");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 7266 ; VA 0x00642d60 ; FUN_00642d60 */

undefined4 __fastcall FUN_00642d60(longlong *param_1)

{
  char *pcVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  char ****ppppcVar6;
  undefined4 *puVar7;
  uint uVar8;
  longlong lVar9;
  char ***apppcStack_3c [4];
  uint uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined uStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179fe90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_016de181(1);
  uStack_8 = 1;
  piStack_20 = piVar3;
  uVar4 = FUN_016de368();
  cVar2 = FUN_00637e00(uVar4);
  if (cVar2 != '\0') {
    uVar4 = FUN_00645560();
    goto LAB_00642ef0;
  }
  piVar5 = (int *)FUN_00564bf0(auStack_24);
  (**(code **)(*piVar5 + 0x14))(apppcStack_3c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_1c = uStack_2c;
  if (uStack_2c == 0) {
LAB_00642ea0:
    uVar4 = FUN_00645560();
  }
  else {
    ppppcVar6 = apppcStack_3c;
    if (0xf < uStack_28) {
      ppppcVar6 = (char ****)apppcStack_3c[0];
    }
    if (*(char *)ppppcVar6 < '\x01') goto LAB_00642ea0;
    uStack_12 = (**(code **)(*piVar5 + 0x10))();
    uVar8 = 0;
    ppppcVar6 = apppcStack_3c;
    if (0xf < uStack_28) {
      ppppcVar6 = (char ****)apppcStack_3c[0];
    }
    cStack_11 = *(char *)ppppcVar6;
    uStack_18 = CONCAT31((int3)((uint)ppppcVar6 >> 8),cStack_11);
    do {
      if (cStack_11 == '\0') {
        uVar8 = uVar8 + 1;
        if (uVar8 < uStack_1c) {
          ppppcVar6 = apppcStack_3c;
          if (0xf < uStack_28) {
            ppppcVar6 = (char ****)apppcStack_3c[0];
          }
          uStack_18 = (uint)*(byte *)((int)ppppcVar6 + uVar8);
          if ((char)*(byte *)((int)ppppcVar6 + uVar8) < '\x01') {
            uStack_18 = 0x7f;
          }
        }
        *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + -1;
        cStack_11 = (char)uStack_18;
        **(undefined **)(param_1 + 1) = uStack_12;
      }
      *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + -1;
      cStack_11 = cStack_11 + -1;
      pcVar1 = *(char **)(param_1 + 1);
      cVar2 = FUN_016f4330(*(undefined4 *)param_1,*(undefined4 *)((int)param_1 + 4),10,0);
      *pcVar1 = (char)*(undefined4 *)(param_1 + 2) + cVar2;
      lVar9 = FUN_016f3c60(*(undefined4 *)param_1,*(undefined4 *)((int)param_1 + 4),10,0);
      *param_1 = lVar9;
    } while (lVar9 != 0);
    uVar4 = *(undefined4 *)(param_1 + 1);
    piVar3 = piStack_20;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    ppppcVar6 = (char ****)apppcStack_3c[0];
    if (0xfff < uVar8) {
      ppppcVar6 = (char ****)apppcStack_3c[0][-1];
      uVar8 = uStack_28 + 0x24;
      if ((char *)0x1f < (char *)((int)apppcStack_3c[0] + (-4 - (int)ppppcVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppcVar6,uVar8);
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  apppcStack_3c[0] = (char ***)((uint)apppcStack_3c[0] & 0xffffff00);
LAB_00642ef0:
  uStack_8 = 3;
  if ((piVar3 != (int *)0x0) &&
     (puVar7 = (undefined4 *)(**(code **)(*piVar3 + 8))(), puVar7 != (undefined4 *)0x0)) {
    (**(code **)*puVar7)(1);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 7267 ; VA 0x00642f30 ; FUN_00642f30 */

undefined4 FUN_00642f30(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *in_stack_00000030;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c028;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0063f370(param_1,&stack0x00000008,&stack0x00000040,&stack0x00000044);
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7268 ; VA 0x00642fb0 ; FUN_00642fb0 */

void __thiscall FUN_00642fb0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0aa0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c13e0(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c1470(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7269 ; VA 0x00643190 ; FUN_00643190 */

void __thiscall FUN_00643190(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0aa0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c13e0(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c1470(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7270 ; VA 0x00643370 ; FUN_00643370 */

void __fastcall FUN_00643370(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  float10 fVar5;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0ac0;
  pvStack_10 = ExceptionList;
  cStack_14 = '\0';
  puStack_18 = (uint *)(param_1 + 0x460);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  iVar1 = *(int *)(param_1 + 0x468) + -1;
  iStack_8 = 0;
  if (iVar1 < 1) {
    iVar1 = 0;
  }
  *(int *)(param_1 + 0x468) = iVar1;
  fVar5 = (float10)FUN_01683110();
  uStack_20 = 0;
  *(double *)(param_1 + 0x470) = (double)fVar5;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("FloodCheckerRateLimiter_Decremented",0x23);
  iStack_8._0_1_ = 1;
  FUN_008783f0(auStack_30,1,0);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar3 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  iStack_8 = 2;
  if (cStack_14 != '\0') {
    LOCK();
    uVar3 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar3 & 0x40000000) == 0) && (-0x80000000 < (int)uVar3)) {
      LOCK();
      uVar3 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar3 >> 0x1e & 1) == 0) {
        uVar2 = FUN_00554e40();
        SetEvent(uVar2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7271 ; VA 0x006434a0 ; FUN_006434a0 */

void FUN_006434a0(int *param_1,undefined4 param_2)

{
  double *pdVar1;
  int iVar2;
  int iVar3;
  double dVar4;
  bool bVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int *piVar9;
  int iVar10;
  int *piVar11;
  int iVar12;
  char *pcVar13;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int *piStack_8;
  
  piStack_8 = (int *)0xffffffff;
  puStack_c = &LAB_017a0ad8;
  pvStack_10 = ExceptionList;
  iVar12 = *param_1;
  piStack_14 = (int *)0x0;
  ExceptionList = &pvStack_10;
  piVar6 = (int *)FUN_00564290();
  piVar6 = (int *)*piVar6;
  if (piVar6 == (int *)0x0) {
    FUN_005eebc0(&piStack_1c);
    piStack_8 = piVar6;
    FUN_008a5700(iVar12 + 0xc);
    FUN_005789c0(&DAT_01ea8aa8,&LAB_0055d5b0);
    uVar7 = FUN_00560e40();
    puVar8 = (undefined4 *)FUN_008aa140(uVar7);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    *puVar8 = piStack_1c;
    piVar6 = (int *)puVar8[1];
    puVar8[1] = piStack_18;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar12 = piVar6[1] + -1;
      piVar6[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar12 = piVar6[2] + -1;
        piVar6[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    piVar11 = piStack_18;
    piVar6 = piStack_1c;
    piStack_8 = (int *)0xffffffff;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar12 = piStack_18[1] + -1;
      piStack_18[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar9 = piVar11 + 2;
        iVar12 = *piVar9 + -1;
        *piVar9 = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
    piVar11 = piStack_14;
    if (piVar6 != (int *)0x0) goto LAB_0064358a;
  }
  else {
LAB_0064358a:
    piVar9 = (int *)(**(code **)(*piVar6 + 0x40))(&uStack_24);
    piVar11 = (int *)0x1;
    if (*piVar9 != 0) {
      bVar5 = false;
      goto LAB_006435ac;
    }
  }
  bVar5 = true;
LAB_006435ac:
  piVar9 = piStack_20;
  if ((((uint)piVar11 & 1) != 0) && (piStack_20 != (int *)0x0)) {
    LOCK();
    iVar12 = piStack_20[1] + -1;
    piStack_20[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar11 = piVar9 + 2;
      iVar12 = *piVar11 + -1;
      *piVar11 = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (bVar5) {
    pcVar13 = "RoMarkError: Attempted to disconnect but found no server or replicators";
  }
  else {
    iVar12 = 0;
    piVar6 = (int *)(**(code **)(*piVar6 + 0x40))(&uStack_24);
    piVar11 = piStack_20;
    piVar6 = (int *)*piVar6;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar9 = piVar11 + 2;
        iVar3 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
    piVar11 = (int *)piVar6[1];
    piStack_14 = (int *)*piVar6;
    if (piStack_14 != piVar11) {
      do {
        iVar3 = *piStack_14;
        if ((iVar3 != 0) &&
           (iVar2 = *(int *)(iVar3 + 0xc), iVar10 = FUN_005ee350(),
           (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8) <=
           (uint)*(ushort *)(iVar10 + 0x1da))) {
          if (iVar12 != 0) {
            pdVar1 = (double *)(iVar3 + 0x3bc0);
            uStack_24 = *(undefined4 *)pdVar1;
            piStack_20 = *(int **)(iVar3 + 0x3bc4);
            piStack_1c = *(int **)(iVar12 + 0x3bc0);
            piStack_18 = *(int **)(iVar12 + 0x3bc4);
            dVar4 = *(double *)(iVar12 + 0x3bc0);
            if (dVar4 < *pdVar1 || dVar4 == *pdVar1) goto LAB_006436a1;
          }
          if (*(char *)(iVar3 + 0x1db9) == '\0') {
            iVar12 = iVar3;
          }
        }
LAB_006436a1:
        piStack_14 = piStack_14 + 2;
      } while (piStack_14 != piVar11);
      if (iVar12 != 0) {
        FUN_0062b370(param_2);
        ExceptionList = pvStack_10;
        return;
      }
    }
    pcVar13 = "RoMarkError: Attempted to disconnect but found no oldest replicator";
  }
  FUN_0086f2f0(3,pcVar13);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7272 ; VA 0x00643700 ; FUN_00643700 */

bool __thiscall FUN_00643700(int param_1,undefined8 *param_2,int param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined auStack_48 [24];
  undefined auStack_30 [12];
  undefined auStack_24 [4];
  int *piStack_20;
  undefined8 uStack_1c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0b00;
  pvStack_10 = ExceptionList;
  if (-1 < *(int *)(param_1 + 0x458)) {
    iVar2 = *(int *)(param_1 + 0x34);
    iVar4 = param_1;
    ExceptionList = &pvStack_10;
    if ((iVar2 != 0) && (iVar4 = iVar2, ExceptionList = &pvStack_10, *(int *)(iVar2 + 0x34) != 0)) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_005c8ac0();
    }
    if ((iVar4 != 0) &&
       (iVar2 = *(int *)(iVar4 + 0xc), iVar4 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      FUN_005ef030();
    }
    FUN_00569550(2,&uStack_11);
    uStack_8 = 0;
    uStack_1c = (double)param_3 + (double)(&DAT_018c0d90)[-(param_3 >> 0x1f)];
    FUN_0063d540(&uStack_1c);
    uStack_1c = (double)param_4 + (double)(&DAT_018c0d90)[-(param_4 >> 0x1f)];
    FUN_0063d540(&uStack_1c);
    uStack_1c = 0.0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (DAT_01d64500 == '\0') {
      FUN_01255470(2,0,0,0);
      uVar5 = FUN_0094ed20(auStack_24,auStack_48,param_1 + 0x450,"Script",auStack_30);
    }
    else {
      FUN_01255470(2,0,0,0);
      uVar5 = FUN_0094b5d0(auStack_24,auStack_48,param_1 + 0x450,"Script",auStack_30);
    }
    FUN_005587e0(uVar5);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[1] + -1;
      piStack_20[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar2 = piStack_20[2] + -1;
        piStack_20[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    piVar3 = (int *)*(int *)uStack_1c;
    if (piVar3 == (int *)((int *)uStack_1c)[1]) {
      piVar6 = (int *)0x0;
    }
    else {
      iVar2 = *piVar3;
      iVar4 = FUN_0088ca00();
      if (iVar2 == iVar4) {
        piVar6 = piVar3 + 2;
        if (piVar3[1] == 0) {
          piVar6 = (int *)0x0;
        }
      }
      else {
        piVar6 = (int *)0x0;
      }
    }
    if (piVar6 != (int *)0x0) {
      *param_2 = *(undefined8 *)piVar6;
    }
    piVar3 = uStack_1c._4_4_;
    if (uStack_1c._4_4_ != (int *)0x0) {
      LOCK();
      iVar2 = uStack_1c._4_4_[1] + -1;
      uStack_1c._4_4_[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*uStack_1c._4_4_)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uStack_8 = 3;
    FUN_00577b20();
    ExceptionList = pvStack_10;
    return piVar6 != (int *)0x0;
  }
  return false;
}



/* FUNCTION 7273 ; VA 0x00643920 ; FUN_00643920 */

void __thiscall FUN_00643920(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_005f2960(param_2,param_3,param_4,param_1 + 0x448,param_1);
  return;
}



/* FUNCTION 7274 ; VA 0x00643940 ; FUN_00643940 */

void FUN_00643940(void)

{
  FUN_006463c0();
  return;
}



/* FUNCTION 7275 ; VA 0x00643950 ; FUN_00643950 */

void FUN_00643950(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if ((DAT_01d5b2a0 != '\0') && (iVar2 = *(int *)(param_1 + 0x18), *(int *)(iVar2 + 0x10c) != 0)) {
    FUN_0098c810(0);
    FUN_0064b390(1000);
    *(undefined4 *)(iVar2 + 0x10c) = 0;
    piVar3 = *(int **)(iVar2 + 0x110);
    *(undefined4 *)(iVar2 + 0x110) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar2 = piVar3[1] + -1;
      piVar3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x006439c0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (**(code **)(*piVar3 + 4))();
          return;
        }
      }
    }
  }
  return;
}



/* FUNCTION 7276 ; VA 0x006439d0 ; FUN_006439d0 */

int FUN_006439d0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00645950(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 7277 ; VA 0x00643a60 ; FUN_00643a60 */

void __fastcall FUN_00643a60(int param_1)

{
  *(undefined4 *)(param_1 + 0x458) = 0xffffffff;
  return;
}



/* FUNCTION 7278 ; VA 0x00643a70 ; FUN_00643a70 */

undefined * FUN_00643a70(undefined *param_1,undefined4 param_2,int param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0b18;
  pvStack_10 = ExceptionList;
  if (DAT_01d5a0a8 == '\0') {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    return param_1;
  }
  ExceptionList = &pvStack_10;
  FUN_00644d90(&param_3,param_3,param_4);
  uStack_8 = 0;
  if (param_3 == 0) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
  }
  else {
    FUN_00630690(param_1,param_2);
  }
  piVar3 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7279 ; VA 0x00643b30 ; FUN_00643b30 */

undefined4 FUN_00643b30(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined8 uVar4;
  int aiStack_48 [5];
  uint uStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0b40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01256300(param_2);
  uVar4 = FUN_009d1940(param_2,param_3,2,iVar1 - param_3,iStack_14 + 0x44);
  uStack_18 = (undefined4)uVar4;
  uVar2 = FUN_009d09d0(aiStack_48,param_2,param_3,1,iVar1 - param_3,iStack_14 + 0x40);
  uStack_8 = 0;
  uVar2 = (**(code **)(iStack_14 + 0x38))
                    (aiStack_30,uVar2,uStack_18,(int)((ulonglong)uVar4 >> 0x20));
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar2 = FUN_009d5710(param_2,uVar2);
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    iVar1 = aiStack_30[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_30[0] + -4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  if (0xf < uStack_34) {
    uVar3 = uStack_34 + 1;
    iVar1 = aiStack_48[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_48[0] + -4);
      uVar3 = uStack_34 + 0x24;
      if (0x1f < (aiStack_48[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 7280 ; VA 0x00643c50 ; FUN_00643c50 */

void FUN_00643c50(int param_1,undefined4 *param_2)

{
  undefined uVar1;
  uint *puVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int in_stack_00000018;
  uint in_stack_0000001c;
  undefined8 in_stack_00000020;
  char in_stack_00000028;
  undefined4 in_stack_0000002c;
  char in_stack_00000030;
  int aiStack_6c [5];
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined8 uStack_34;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0ba1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  uVar6 = uStack_4c;
  uVar8 = 1;
  uStack_34 = in_stack_00000020;
  uStack_8._0_1_ = 1;
  puVar2 = *(uint **)(param_1 + 4);
  if (*(uint **)(param_1 + 8) == puVar2) {
    FUN_00603540(puVar2,&uStack_4c);
    uVar6 = uStack_38;
  }
  else {
    uStack_4c = uStack_4c & 0xffffff00;
    *puVar2 = uVar6;
    puVar2[1] = uStack_48;
    puVar2[2] = uStack_44;
    puVar2[3] = uStack_40;
    *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_38,uStack_3c);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x20;
    *(undefined8 *)(puVar2 + 6) = in_stack_00000020;
    uVar6 = 0xf;
  }
  uStack_8._0_1_ = 0;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uVar6) {
    uVar5 = uVar6 + 1;
    uVar7 = uStack_4c;
    if (0xfff < uVar5) {
      uVar7 = *(uint *)(uStack_4c - 4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (uStack_4c - uVar7) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar5);
  }
  if (in_stack_00000028 != '\0') {
    FUN_01675640(auStack_2c,"_PlayerTier_%d",in_stack_0000002c);
    puVar3 = &param_2;
    if (0xf < in_stack_0000001c) {
      puVar3 = param_2;
    }
    uStack_8._0_1_ = 2;
    puVar2 = (uint *)FUN_00585d40(0,puVar3,in_stack_00000018);
    uStack_44 = *puVar2;
    uStack_40 = puVar2[1];
    uStack_3c = puVar2[2];
    uStack_38 = puVar2[3];
    uStack_34 = *(undefined8 *)(puVar2 + 4);
    puVar2[4] = 0;
    puVar2[5] = 0xf;
    *(undefined *)puVar2 = 0;
    uStack_8._0_1_ = 4;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_18) {
      uVar8 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar8 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_0054ef60(&uStack_44);
    uVar8 = 7;
    uStack_54 = in_stack_00000020;
    uStack_8._0_1_ = 5;
    FUN_00625cd0(aiStack_6c);
    uStack_8._0_1_ = 4;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_58) {
      uVar6 = uStack_58 + 1;
      iVar4 = aiStack_6c[0];
      if (0xfff < uVar6) {
        iVar4 = *(int *)(aiStack_6c[0] + -4);
        uVar6 = uStack_58 + 0x24;
        if (0x1f < (aiStack_6c[0] - iVar4) - 4U) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar6);
    }
    uStack_8._0_1_ = 0;
    if (0xf < uStack_34._4_4_) {
      uVar7 = uStack_34._4_4_ + 1;
      uVar6 = uStack_44;
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(uStack_44 - 4);
        uVar7 = uStack_34._4_4_ + 0x24;
        if (0x1f < (uStack_44 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  if (in_stack_00000030 != '\0') {
    uStack_8._0_1_ = 6;
    uStack_14 = uVar8 | 8;
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_0058a190(in_stack_00000018 + 7);
    puVar3 = &param_2;
    if (0xf < in_stack_0000001c) {
      puVar3 = param_2;
    }
    FUN_00554150(puVar3,in_stack_00000018);
    FUN_00554150("_Place_",7);
    puVar3 = &DAT_01d7a8e8;
    if (0xf < DAT_01d7a8fc) {
      puVar3 = DAT_01d7a8e8;
    }
    puVar2 = (uint *)FUN_00554150(puVar3,DAT_01d7a8f8);
    uStack_44 = *puVar2;
    uStack_40 = puVar2[1];
    uStack_3c = puVar2[2];
    uStack_38 = puVar2[3];
    uStack_34 = *(undefined8 *)(puVar2 + 4);
    puVar2[4] = 0;
    puVar2[5] = 0xf;
    *(undefined *)puVar2 = 0;
    uStack_8._0_1_ = 8;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_18) {
      uVar8 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar8 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_0054ef60(&uStack_44);
    uStack_54 = in_stack_00000020;
    uStack_8._0_1_ = 9;
    FUN_00625cd0(aiStack_6c);
    if (0xf < uStack_58) {
      uVar6 = uStack_58 + 1;
      iVar4 = aiStack_6c[0];
      if (0xfff < uVar6) {
        iVar4 = *(int *)(aiStack_6c[0] + -4);
        uVar6 = uStack_58 + 0x24;
        if (0x1f < (aiStack_6c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar6);
    }
    if (0xf < uStack_34._4_4_) {
      uVar8 = uStack_34._4_4_ + 1;
      uVar6 = uStack_44;
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(uStack_44 - 4);
        uVar8 = uStack_34._4_4_ + 0x24;
        if (0x1f < (uStack_44 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
  }
  if (0xf < in_stack_0000001c) {
    uVar6 = in_stack_0000001c + 1;
    puVar3 = param_2;
    if (0xfff < uVar6) {
      puVar3 = (undefined4 *)param_2[-1];
      uVar6 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7281 ; VA 0x00644030 ; FUN_00644030 */

undefined4 * FUN_00644030(undefined4 *param_1)

{
  char cVar1;
  short *psVar2;
  uint *puVar3;
  int iVar4;
  char *pcVar5;
  char *pcVar6;
  code *pcVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  undefined auStack_324 [400];
  undefined auStack_194 [256];
  char acStack_94 [68];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined auStack_34 [16];
  int iStack_24;
  undefined4 uStack_20;
  char *pcStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a0bf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  uStack_50 = 1;
  if (DAT_01d5b1e4 == '\0') {
    iVar12 = Ordinal_115(0x101,auStack_324);
    if (((iVar12 == 0) && (iVar12 = Ordinal_57(auStack_194,0xff), iVar12 == 0)) &&
       (iStack_18 = Ordinal_52(auStack_194), iStack_18 != 0)) {
      piVar8 = *(int **)(iStack_18 + 0xc);
      iVar12 = 0;
      if (*piVar8 != 0) {
        iVar4 = 0;
        do {
          pcVar5 = (char *)Ordinal_12(**(undefined4 **)((int)piVar8 + iVar4));
          uStack_3c = 0;
          uStack_38 = 0xf;
          uStack_4c = uStack_4c & 0xffffff00;
          pcStack_1c = pcVar5 + 1;
          pcVar6 = pcVar5;
          do {
            cVar1 = *pcVar6;
            pcVar6 = pcVar6 + 1;
          } while (cVar1 != '\0');
          FUN_005542c0(pcVar5,(int)pcVar6 - (int)pcStack_1c);
          uVar11 = uStack_4c;
          puVar3 = (uint *)param_1[1];
          uStack_8 = 5;
          if ((uint *)param_1[2] == puVar3) {
            FUN_0058d0a0(puVar3,&uStack_4c);
            uVar11 = uStack_38;
          }
          else {
            uStack_4c = uStack_4c & 0xffffff00;
            *puVar3 = uVar11;
            puVar3[1] = uStack_48;
            puVar3[2] = uStack_44;
            puVar3[3] = uStack_40;
            puVar3[4] = uStack_3c;
            puVar3[5] = uStack_38;
            param_1[1] = param_1[1] + 0x18;
            uVar11 = 0xf;
          }
          uStack_8 = uStack_8 & 0xffffff00;
          if (0xf < uVar11) {
            uVar9 = uVar11 + 1;
            uVar10 = uStack_4c;
            if (0xfff < uVar9) {
              uVar10 = *(uint *)(uStack_4c - 4);
              uVar9 = uVar11 + 0x24;
              if (0x1f < (uStack_4c - uVar10) - 4) goto LAB_00644489;
            }
            FUN_01674ea0(uVar10,uVar9);
          }
          iVar12 = iVar12 + 1;
          piVar8 = *(int **)(iStack_18 + 0xc);
          iVar4 = iVar12 * 4;
        } while (piVar8[iVar12] != 0);
      }
    }
    uStack_3c = 0;
    uStack_38 = 0xf;
    uStack_4c = uStack_4c & 0xffffff00;
    FUN_005542c0(&DAT_018c92b8,9);
    puVar3 = (uint *)param_1[1];
    uStack_8 = 6;
    if ((uint *)param_1[2] != puVar3) {
      *puVar3 = uStack_4c;
      puVar3[1] = uStack_48;
      puVar3[2] = uStack_44;
      puVar3[3] = uStack_40;
      *(ulonglong *)(puVar3 + 4) = CONCAT44(uStack_38,uStack_3c);
      param_1[1] = param_1[1] + 0x18;
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_0058d0a0(puVar3,&uStack_4c);
    if (uStack_38 < 0x10) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar10 = uStack_38 + 1;
    uVar11 = uStack_4c;
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(uStack_4c - 4);
      uVar10 = uStack_38 + 0x24;
      if (0x1f < (uStack_4c - uVar11) - 4) {
LAB_00644489:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
    ExceptionList = pvStack_10;
    return param_1;
  }
  iVar12 = 0;
  uVar11 = 0;
  iStack_18 = 15000;
  while ((iStack_14 = FUN_0171e1f2(iStack_18), iStack_14 != 0 &&
         (iVar12 = GetAdaptersAddresses(0,0x10,0,iStack_14,&iStack_18), iVar12 == 0x6f))) {
    FUN_017168b0(iStack_14);
    uVar11 = uVar11 + 1;
    iStack_14 = 0;
    if (2 < uVar11) {
LAB_00644204:
      iStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      FUN_005542c0(&DAT_018c92b8,9);
      uStack_8 = 3;
      FUN_00590440(auStack_34);
      uStack_8 = uStack_8 & 0xffffff00;
      FUN_005507b0();
      iStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      FUN_005542c0(&DAT_018c92b4,3);
      uStack_8 = 4;
      FUN_00590440(auStack_34);
      FUN_005507b0();
LAB_00644281:
      if (iStack_14 == 0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      FUN_017168b0(iStack_14);
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  if (iVar12 == 0) {
    pcVar7 = getnameinfo_exref;
    pcStack_1c = (char *)iStack_14;
    if (iStack_14 == 0) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    do {
      iVar12 = *(int *)((int)pcStack_1c + 0x10);
      if ((iVar12 != 0) && (*(int *)((int)pcStack_1c + 0x44) == 1)) {
        do {
          psVar2 = *(short **)(iVar12 + 0xc);
          if (*psVar2 == 2) {
            iVar4 = (*pcVar7)(psVar2,0x10,&uStack_4c,0x16,0,0,2);
            pcVar7 = getnameinfo_exref;
            if (iVar4 == 0) {
              pcVar6 = (char *)&uStack_4c;
              iStack_24 = iVar4;
              uStack_20 = 0xf;
              auStack_34[0] = 0;
              do {
                cVar1 = *pcVar6;
                pcVar6 = pcVar6 + 1;
              } while (cVar1 != '\0');
              FUN_005542c0(&uStack_4c,(int)pcVar6 - ((int)&uStack_4c + 1));
              uStack_8 = 1;
LAB_006441c6:
              FUN_00590440(auStack_34);
              uStack_8 = uStack_8 & 0xffffff00;
              FUN_005507b0();
              pcVar7 = getnameinfo_exref;
            }
          }
          else if ((DAT_01d5b1e4 != '\0') &&
                  (iVar4 = (*pcVar7)(psVar2,0x1c,acStack_94,0x41,0,0,2), pcVar7 = getnameinfo_exref,
                  iVar4 == 0)) {
            iStack_24 = iVar4;
            auStack_34[0] = 0;
            pcVar6 = acStack_94;
            uStack_20 = 0xf;
            do {
              cVar1 = *pcVar6;
              pcVar6 = pcVar6 + 1;
            } while (cVar1 != '\0');
            FUN_005542c0(acStack_94,(int)pcVar6 - (int)(acStack_94 + 1));
            uStack_8 = 2;
            goto LAB_006441c6;
          }
          iVar12 = *(int *)(iVar12 + 8);
        } while (iVar12 != 0);
      }
      pcStack_1c = *(char **)((int)pcStack_1c + 8);
    } while (pcStack_1c != (char *)0x0);
    pcStack_1c = (char *)0x0;
    goto LAB_00644281;
  }
  goto LAB_00644204;
}



/* FUNCTION 7282 ; VA 0x00644490 ; thunk_FUN_005ee510 */

void thunk_FUN_005ee510(void)

{
  int iVar1;
  
  if (DAT_01ea990c == 0) {
    iVar1 = FUN_005ee250();
    DAT_01ea990c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 7283 ; VA 0x006444a0 ; FUN_006444a0 */

undefined4 __fastcall FUN_006444a0(int param_1)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined auStack_10 [12];
  
  cVar2 = FUN_00973950(param_1,1);
  if (cVar2 != '\0') {
    FUN_016756b0(auStack_10,"Can not call server, client is present.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    uVar3 = FUN_0063ee70(*puVar1,puVar1[1],FUN_006454d0);
    return uVar3;
  }
  return 0;
}



/* FUNCTION 7284 ; VA 0x00644500 ; FUN_00644500 */

void __thiscall FUN_00644500(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x3c5c);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x3c5c);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x3c58);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 7285 ; VA 0x00644540 ; FUN_00644540 */

undefined4 __fastcall FUN_00644540(int param_1)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  float10 fVar9;
  double dVar10;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  double dStack_20;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0c28;
  pvStack_10 = ExceptionList;
  cStack_14 = '\0';
  puStack_18 = (uint *)(param_1 + 0x460);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  iStack_8._0_1_ = 0;
  iStack_8._1_3_ = 0;
  fVar9 = (float10)FUN_01683110();
  dStack_20 = (double)fVar9;
  iVar7 = (int)((dStack_20 - *(double *)(param_1 + 0x470)) / (double)DAT_01d5a7f0);
  if (0 < iVar7) {
    iVar2 = *(int *)(param_1 + 0x468) + iVar7;
    iVar5 = 3;
    if (iVar2 < 3) {
      iVar5 = iVar2;
    }
    *(int *)(param_1 + 0x468) = iVar5;
    dVar10 = (double)(DAT_01d5a7f0 * iVar7) + *(double *)(param_1 + 0x470);
    if (dStack_20 <= dVar10) {
      dVar10 = dStack_20;
    }
    *(double *)(param_1 + 0x470) = dVar10;
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("FloodCheckerRateLimiter_Incremented",0x23);
    iStack_8._0_1_ = 1;
    FUN_008783f0(auStack_38,1,0);
    iStack_8._0_1_ = 0;
    uVar1 = (undefined)iStack_8;
    iStack_8._0_1_ = 0;
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      uVar6 = auStack_38[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_38[0] - 4);
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar6) - 4) {
          iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
  }
  uVar3 = FUN_01675640(auStack_38,"FloodCheckerRateLimiter_RateScaling_%d",
                       *(undefined4 *)(param_1 + 0x468));
  iStack_8._0_1_ = 2;
  FUN_008783f0(uVar3,1,0);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  switch(*(undefined4 *)(param_1 + 0x468)) {
  default:
    uVar3 = 0;
    break;
  case 1:
    uVar3 = 0x3f;
    break;
  case 2:
    uVar3 = 0x7f;
    break;
  case 3:
    uVar3 = 0xff;
  }
  iStack_8 = 3;
  if (cStack_14 != '\0') {
    LOCK();
    uVar6 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar6 & 0x40000000) == 0) && (-0x80000000 < (int)uVar6)) {
      LOCK();
      uVar6 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar6 >> 0x1e & 1) == 0) {
        uVar4 = FUN_00554e40();
        SetEvent(uVar4);
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 7286 ; VA 0x00644760 ; FUN_00644760 */

void __thiscall FUN_00644760(int param_1,char *param_2)

{
  undefined4 uVar1;
  char ****ppppcVar2;
  uint uVar3;
  bool bVar4;
  char ***apppcStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0c48;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x458);
  if (-1 < (int)uVar3) {
    bVar4 = uVar3 < (uint)(*(int *)(param_1 + 0x3bc) - *(int *)(param_1 + 0x3b8) >> 3);
    ExceptionList = &pvStack_10;
    if (bVar4) {
      ExceptionList = &pvStack_10;
      uVar1 = FUN_00a33fa0();
      FUN_0054ef60(uVar1);
    }
    uStack_8 = 0;
    if (*param_2 == '\0') {
      FUN_0054ef60(apppcStack_28);
      *param_2 = '\x01';
    }
    else if ((char ****)(param_2 + 4) != apppcStack_28) {
      ppppcVar2 = apppcStack_28;
      if (0xf < uStack_14) {
        ppppcVar2 = (char ****)apppcStack_28[0];
      }
      FUN_005542c0(ppppcVar2,uStack_18);
    }
    if ((bVar4) && (0xf < uStack_14)) {
      uVar3 = uStack_14 + 1;
      ppppcVar2 = (char ****)apppcStack_28[0];
      if (0xfff < uVar3) {
        ppppcVar2 = (char ****)apppcStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if ((char *)0x1f < (char *)((int)apppcStack_28[0] + (-4 - (int)ppppcVar2))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppcVar2,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7287 ; VA 0x00644850 ; FUN_00644850 */

undefined __fastcall FUN_00644850(int param_1)

{
  char cVar1;
  
  if (DAT_01d5a4c0 == '\0') {
    cVar1 = FUN_005f2470();
    if ((cVar1 != '\0') && (*(char *)(param_1 + 0x3a4) != '\0')) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 7288 ; VA 0x00644880 ; FUN_00644880 */

int __fastcall FUN_00644880(int param_1)

{
  return param_1 + 0x128;
}



/* FUNCTION 7289 ; VA 0x006448a0 ; FUN_006448a0 */

undefined4 __fastcall FUN_006448a0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x114);
}



/* FUNCTION 7290 ; VA 0x006448b0 ; FUN_006448b0 */

int * __thiscall FUN_006448b0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0c8a;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x440);
  if (iVar4 != 0) {
    iVar3 = *(int *)(param_1 + 0x444);
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar3 != 0) {
      LOCK();
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      UNLOCK();
      iVar4 = *(int *)(param_1 + 0x440);
      iVar3 = *(int *)(param_1 + 0x444);
    }
    *param_2 = iVar4;
    param_2[1] = iVar3;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_01674e20(0x74);
  uStack_8 = 0;
  if (piVar2 == (int *)0x0) {
    piVar2 = (int *)0x0;
  }
  else {
    piVar2[1] = 1;
    piVar2[2] = 1;
    *piVar2 = (int)std::_Ref_count_obj<struct_RBX::Network::ServerSchemaInfo>::vftable;
    FUN_006ab530();
    uStack_8._0_1_ = 1;
    FUN_006ab530();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_18 = 0;
    FUN_0060e810(0,&uStack_18,&uStack_11);
    piVar2[0x1a] = 0;
    piVar2[0x1b] = 0;
  }
  uStack_8 = 3;
  FUN_006b54f0(*(undefined4 *)(param_1 + 0x124),piVar2 + 3);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar2[1] = piVar2[1] + 1;
    UNLOCK();
  }
  *(int **)(param_1 + 0x440) = piVar2 + 3;
  piVar1 = *(int **)(param_1 + 0x444);
  *(int **)(param_1 + 0x444) = piVar2;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  iVar4 = *(int *)(param_1 + 0x444);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = *(int *)(param_1 + 0x444);
  }
  *param_2 = *(int *)(param_1 + 0x440);
  param_2[1] = iVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7291 ; VA 0x00644a60 ; FUN_00644a60 */

/* WARNING: Removing unreachable block (ram,0x00644b1d) */
/* WARNING: Removing unreachable block (ram,0x00644b30) */
/* WARNING: Removing unreachable block (ram,0x00644b37) */
/* WARNING: Removing unreachable block (ram,0x00644b3e) */

undefined * __thiscall FUN_00644a60(int param_1,undefined *param_2,int param_3,uint param_4)

{
  uint uVar1;
  int iVar2;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  iVar2 = param_1 + 0x3fd + (uint)*(byte *)(param_1 + 0x3fc);
  uVar1 = param_4;
  if (((int)param_4 < 1) && ((int)param_4 < 0)) {
    uVar1 = -param_4 - 1;
  }
  FUN_00606ff0(&iStack_14,(uVar1 >> 2) + uVar1 * 0x40 + param_3 ^ uVar1,&param_3,
               -(uint)(iVar2 != 0) & iVar2 + 1U);
  *param_2 = 0;
  if (iStack_14 != 0) {
    *(undefined4 *)(param_2 + 4) = *(undefined4 *)(iStack_14 + 0x10);
    *param_2 = 1;
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7292 ; VA 0x00644b60 ; FUN_00644b60 */

undefined4 __fastcall FUN_00644b60(int param_1)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined auStack_10 [12];
  
  cVar2 = FUN_00973950(param_1,1);
  if (cVar2 != '\0') {
    FUN_016756b0(auStack_10,"Can not call server, client is present.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    uVar3 = FUN_0063ee70(*puVar1,puVar1[1],FUN_00645370);
    return uVar3;
  }
  return 0;
}



/* FUNCTION 7293 ; VA 0x00644bc0 ; FUN_00644bc0 */

void __thiscall FUN_00644bc0(int param_1,undefined *param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = param_1 + 0x3c5 + (uint)*(byte *)(param_1 + 0x3c4);
  uVar1 = FUN_00a33fd0(param_3);
  FUN_0063f830(&param_3,uVar1,param_3,-(uint)(iVar2 != 0) & iVar2 + 1U);
  *param_2 = 0;
  if (param_3 != 0) {
    *(undefined4 *)(param_2 + 4) = *(undefined4 *)(param_3 + 0xc);
    *param_2 = 1;
  }
  return;
}



/* FUNCTION 7294 ; VA 0x00644c20 ; FUN_00644c20 */

undefined * FUN_00644c20(undefined *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0ca8;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    iVar2 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar1 = FUN_00b73ae0();
    if ((uint)*(ushort *)(iVar1 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8)) {
      iVar2 = *(int *)(param_2 + 0xc);
      iVar1 = FUN_009ec190();
      if ((uint)*(ushort *)(iVar1 + 0x1da) <
          (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8)) goto LAB_00644d7a;
      iVar2 = FUN_00ae4430();
      if (*(int *)(iVar2 + 0x10) == 0) {
        uVar3 = FUN_009ed300(auStack_18);
        uStack_8 = 0;
        *param_1 = 0;
        FUN_008866a0(uVar3);
        *param_1 = 1;
        FUN_0056cd30();
        FUN_0056cd30();
        ExceptionList = pvStack_10;
        return param_1;
      }
    }
    else {
      iVar2 = FUN_00ae4430();
      if (*(int *)(iVar2 + 0x10) == 0) {
        if (DAT_01d67698 != '\0') {
          uVar3 = FUN_00b74d90();
          *param_1 = 0;
          FUN_008866a0(uVar3);
          *param_1 = 1;
          ExceptionList = pvStack_10;
          return param_1;
        }
        puVar4 = (undefined4 *)FUN_00b74db0();
        uVar3 = *puVar4;
        *param_1 = 0;
        FUN_008866a0(uVar3);
        *param_1 = 1;
        ExceptionList = pvStack_10;
        return param_1;
      }
    }
    uVar3 = FUN_00ae4370();
    *param_1 = 0;
    FUN_008866a0(uVar3);
    *param_1 = 1;
    ExceptionList = pvStack_10;
    return param_1;
  }
LAB_00644d7a:
  *param_1 = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7295 ; VA 0x00644d90 ; FUN_00644d90 */

undefined4 * __thiscall FUN_00644d90(int param_1,undefined4 *param_2,int param_3,uint param_4)

{
  uint uVar1;
  int iVar2;
  int iStack_8;
  
  iVar2 = param_1 + 0x415 + (uint)*(byte *)(param_1 + 0x414);
  uVar1 = param_4;
  if (((int)param_4 < 1) && ((int)param_4 < 0)) {
    uVar1 = ~param_4;
  }
  FUN_00606ff0(&iStack_8,(uVar1 >> 2) + uVar1 * 0x40 + param_3 ^ uVar1,&param_3,
               -(uint)(iVar2 != 0) & iVar2 + 1U);
  if (iStack_8 != 0) {
    FUN_00587490(param_2);
    return param_2;
  }
  *param_2 = 0;
  param_2[1] = 0;
  return param_2;
}



/* FUNCTION 7296 ; VA 0x00644e20 ; FUN_00644e20 */

void __thiscall FUN_00644e20(int param_1,undefined *param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *(int *)(param_1 + 0x3bc);
  iVar3 = *(int *)(param_1 + 0x3b8);
  *param_2 = 0;
  if (param_3 < (uint)(iVar2 - iVar3 >> 3)) {
    iVar2 = *(int *)(iVar3 + 4 + param_3 * 8);
    *(int *)(param_2 + 4) = iVar2;
    LOCK();
    piVar1 = (int *)(iVar2 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    *param_2 = 1;
  }
  return;
}



/* FUNCTION 7297 ; VA 0x00644e70 ; FUN_00644e70 */

undefined4 __fastcall FUN_00644e70(int param_1)

{
  return *(undefined4 *)(param_1 + 0x1b4);
}



/* FUNCTION 7298 ; VA 0x00644e80 ; FUN_00644e80 */

int FUN_00644e80(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
                undefined4 param_5,undefined4 param_6,char *param_7,undefined4 *param_8)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  char *pcVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_ffffffa4;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  uint *puVar11;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  int aiStack_24 [4];
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a0cd8;
  pvStack_10 = ExceptionList;
  aiStack_24[0] = 0;
  aiStack_24[1] = 0;
  aiStack_24[2] = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  uVar8 = 0x644ed3;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_006c5870(param_1,&cStack_11,aiStack_24 + 3,aiStack_24);
  if (cStack_11 == '\0') {
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    pcVar5 = param_7;
    do {
      cVar3 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar3 != '\0');
    FUN_005542c0(param_7,(int)pcVar5 - (int)(param_7 + 1));
    puVar11 = auStack_3c;
    uStack_8 = 2;
    uVar9 = param_4;
    uVar10 = param_5;
    FUN_006400f0(aiStack_24);
    FUN_00642020(in_stack_ffffffa4,uVar8,param_1,uVar9,uVar10,puVar11);
    uStack_8 = 1;
    if (0xf < uStack_28) {
      uVar6 = uStack_28 + 1;
      uVar7 = auStack_3c[0];
      if (0xfff < uVar6) {
        uVar7 = *(uint *)(auStack_3c[0] - 4);
        uVar6 = uStack_28 + 0x24;
        if (0x1f < (auStack_3c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar6);
    }
    if (DAT_01ea946c != 0) {
      uVar8 = FUN_005f7790();
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      FUN_00641f10(aiStack_24,param_2,param_3,param_4,param_5,param_6,param_7,uVar8);
    }
    iVar4 = FUN_006c5950(*param_8,param_8[1],param_8[2],param_8[3],param_8[4],param_8[5],param_8[6],
                         param_8[7],aiStack_24[3]);
  }
  if (aiStack_24[0] != 0) {
    uVar7 = aiStack_24[2] - aiStack_24[0];
    iVar4 = aiStack_24[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_24[0] + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (aiStack_24[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar4,uVar7);
    aiStack_24[0] = 0;
    aiStack_24[1] = 0;
    aiStack_24[2] = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 7299 ; VA 0x00645080 ; FUN_00645080 */

void __fastcall FUN_00645080(uint *param_1)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0cf0;
  pvStack_10 = ExceptionList;
  uVar2 = param_1[0xb];
  uVar4 = param_1[10];
  uVar3 = uVar2;
  uVar5 = uVar2;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    puVar1 = (uint *)(**(code **)((*param_1 & 0xfffffffe) + 4))(auStack_18,param_1 + 2,uVar4,uVar2);
    uVar4 = param_1[10];
    uVar2 = *puVar1;
    uVar3 = puVar1[1];
    uVar5 = param_1[0xb];
  }
  if (((uVar2 == uVar5) && (uVar3 == uVar5)) && (param_1[9] == uVar5)) {
    *(undefined *)(param_1 + 0xc) = 1;
  }
  param_1[10] = uVar3;
  param_1[8] = uVar4;
  param_1[9] = uVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7300 ; VA 0x00645100 ; FUN_00645100 */

undefined4 FUN_00645100(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0063d6c0(param_1,param_3,param_4);
  return param_1;
}



/* FUNCTION 7301 ; VA 0x00645120 ; FUN_00645120 */

void FUN_00645120(undefined4 *param_1)

{
  int *piVar1;
  code *pcVar2;
  
  pcVar2 = (code *)*param_1;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(param_1[1],param_1[2]);
  return;
}



/* FUNCTION 7302 ; VA 0x00645160 ; FUN_00645160 */

int * FUN_00645160(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0d08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00564290();
  if (*piVar3 != 0) {
    piVar3 = (int *)FUN_00644d90(&iStack_18,*param_1,param_1[1]);
    uStack_8 = 0;
    if (iStack_18 != 0) {
      piVar3 = (int *)FUN_006c5a80(param_1 + 2,*(undefined4 *)(iStack_18 + 0x74),
                                   *(undefined4 *)(iStack_18 + 0x78),
                                   *(undefined4 *)(iStack_18 + 0x7c),
                                   *(undefined4 *)(iStack_18 + 0x80),
                                   *(undefined4 *)(iStack_18 + 0x84),
                                   *(undefined4 *)(iStack_18 + 0x88),
                                   *(undefined4 *)(iStack_18 + 0x8c),
                                   *(undefined4 *)(iStack_18 + 0x90),0);
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar3 = (int *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          piVar3 = (int *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 7303 ; VA 0x00645210 ; FUN_00645210 */

void FUN_00645210(undefined4 *param_1,undefined4 *param_2,int *param_3)

{
  undefined4 uVar1;
  
  if (param_3 != (int *)0x0) {
    if (DAT_01ead6a0 != '\0') {
      uVar1 = (**(code **)(*param_3 + 4))();
      FUN_01677520(DAT_01ead6a0,"ReportFeOnStartup response for %lld: Error: %s",*param_1,param_1[1]
                   ,uVar1);
    }
    uVar1 = (**(code **)(*param_3 + 4))();
    FUN_00647000(uVar1);
    return;
  }
  if (param_2 == (undefined4 *)0x0) {
    if (DAT_01ead6a0 != '\0') {
      FUN_01677520(DAT_01ead6a0,"ReportFeOnStartup response for %lld: No error. Null reponse.",
                   *param_1,param_1[1]);
    }
  }
  else if (DAT_01ead6a0 != '\0') {
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_01677520(DAT_01ead6a0,"ReportFeOnStartup response for %lld: %s",*param_1,param_1[1],param_2)
    ;
    return;
  }
  return;
}



/* FUNCTION 7304 ; VA 0x006452c0 ; FUN_006452c0 */

undefined __thiscall FUN_006452c0(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined uVar2;
  int iVar3;
  char acStack_1c [4];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0d28;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00644c20(acStack_1c,param_2);
  uStack_8 = 0;
  if (acStack_1c[0] != '\0') {
    iVar3 = param_1 + 0x3c5 + (uint)*(byte *)(param_1 + 0x3c4);
    uVar1 = FUN_00a33fd0(auStack_18);
    FUN_0063f830(&param_2,uVar1,auStack_18,-(uint)(iVar3 != 0) & iVar3 + 1U);
    if (param_2 == 0) {
      uVar2 = 0;
      goto LAB_00645342;
    }
  }
  uVar2 = 1;
LAB_00645342:
  if (acStack_1c[0] != '\0') {
    FUN_0056cd30();
    FUN_0056cd30();
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 7305 ; VA 0x00645370 ; FUN_00645370 */

undefined FUN_00645370(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  bool bVar3;
  undefined uVar4;
  int *piVar5;
  int *piVar6;
  bool bVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar1 = FUN_005ee350();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      piVar6 = *(int **)(param_1 + 0x3c5c);
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = *(int **)(param_1 + 0x3c5c);
      }
      iVar2 = *(int *)(param_1 + 0x3c58);
      if (iVar2 == 0) {
        bVar7 = true;
        bVar3 = false;
        piVar5 = param_2;
      }
      else {
        piVar5 = piVar6;
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar6[1] = piVar6[1] + 1;
          UNLOCK();
          iVar2 = *(int *)(param_1 + 0x3c58);
          piVar5 = *(int **)(param_1 + 0x3c5c);
        }
        bVar7 = *(char *)(iVar2 + 0x269) == '\0';
        bVar3 = true;
      }
      if ((bVar3) && (piVar5 != (int *)0x0)) {
        LOCK();
        iVar2 = piVar5[1] + -1;
        piVar5[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar2 = piVar5[2] + -1;
          piVar5[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar2 = piVar6[1] + -1;
        piVar6[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar2 = piVar6[2] + -1;
          piVar6[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (((*(char *)(param_1 + 0x3c32) != '\0') || (*(char *)(param_1 + 0x3c31) != '\0')) ||
         (bVar7 || *(char *)(param_1 + 0x3c33) != '\0')) {
        uVar4 = 1;
        goto LAB_00645494;
      }
    }
  }
  uVar4 = 0;
LAB_00645494:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar6 = param_2 + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 7306 ; VA 0x006454d0 ; FUN_006454d0 */

bool FUN_006454d0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_005ee170();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) goto LAB_0064551e;
  }
  param_1 = 0;
LAB_0064551e:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1 != 0;
}



/* FUNCTION 7307 ; VA 0x00645560 ; FUN_00645560 */

undefined4 __fastcall FUN_00645560(longlong *param_1)

{
  char *pcVar1;
  char cVar2;
  longlong lVar3;
  
  do {
    *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + -1;
    pcVar1 = *(char **)(param_1 + 1);
    cVar2 = FUN_016f4330(*(undefined4 *)param_1,*(undefined4 *)((int)param_1 + 4),10,0);
    *pcVar1 = cVar2 + *(char *)(param_1 + 2);
    lVar3 = FUN_016f3c60(*(undefined4 *)param_1,*(undefined4 *)((int)param_1 + 4),10,0);
    *param_1 = lVar3;
  } while (lVar3 != 0);
  return *(undefined4 *)(param_1 + 1);
}



/* FUNCTION 7308 ; VA 0x006455a0 ; FUN_006455a0 */

void FUN_006455a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  
  if (param_3 == 4) {
LAB_0064566e:
    *param_2 = (int)&boost::algorithm::detail::
                     token_finderF<struct_boost::algorithm::detail::is_any_ofF<char>_>::
                     RTTI_Type_Descriptor;
    *(undefined2 *)(param_2 + 1) = 0;
    return;
  }
  if ((param_3 == 0) || (param_3 == 1)) {
    uVar3 = param_1[2];
    param_2[2] = uVar3;
    *param_2 = 0;
    piVar2 = param_2;
    piVar4 = param_1;
    if (8 < uVar3) {
      piVar2 = (int *)FUN_01674e20(uVar3);
      uVar3 = param_2[2];
      *param_2 = (int)piVar2;
      piVar4 = (int *)*param_1;
    }
    FUN_0170c6f0(piVar2,piVar4,uVar3);
    param_2[3] = param_1[3];
    if (((param_3 == 1) && (8 < (uint)param_1[2])) && (*param_1 != 0)) {
      FUN_01674ea0(*param_1);
    }
  }
  else {
    if (param_3 != 2) {
      if (param_3 == 3) {
        iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9794c);
        piVar2 = (int *)0x0;
        if (iVar1 == 0) {
          piVar2 = param_1;
        }
        *param_2 = (int)piVar2;
        return;
      }
      goto LAB_0064566e;
    }
    if ((8 < (uint)param_2[2]) && (*param_2 != 0)) {
      FUN_01674ea0(*param_2);
      return;
    }
  }
  return;
}



/* FUNCTION 7309 ; VA 0x00645680 ; FUN_00645680 */

void FUN_00645680(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d97910);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_51d4fc67445fd4093505c14c21b5122b>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 7310 ; VA 0x006456f0 ; FUN_006456f0 */

void FUN_006456f0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      piVar3 = param_1 + 2;
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      FUN_006400f0(piVar3);
      if ((param_3 == 1) && (iVar1 = *piVar3, iVar1 != 0)) {
        uVar4 = param_1[4] - iVar1;
        iVar2 = iVar1;
        if (0xfff < uVar4) {
          iVar2 = *(int *)(iVar1 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar2,uVar4);
        *piVar3 = 0;
        param_1[3] = 0;
        param_1[4] = 0;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_00642110(0);
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d97830);
      piVar3 = (int *)0x0;
      if (iVar1 == 0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return;
    }
  }
  *param_2 = (int)&<lambda_c538512c52e8325951620872a66bc89f>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 7311 ; VA 0x006457d0 ; FUN_006457d0 */

int * FUN_006457d0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00645882. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0064580e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d9786c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::Network::Server>),class_boost::_bi::list1<class_boost::_bi::value<class_std::weak_ptr<class_RBX::Network::Server>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 7312 ; VA 0x006458a0 ; FUN_006458a0 */

void __fastcall FUN_006458a0(undefined4 param_1)

{
  char cVar1;
  int *piVar2;
  undefined4 *puVar3;
  bool bVar4;
  
  FUN_006c4d40();
  piVar2 = (int *)FUN_0054db20();
  (**(code **)(*piVar2 + 0x1c))(DAT_01d5a400);
  if (DAT_01d5a4c0 != '\0') {
    FUN_005542c0(&DAT_018d069c,4);
  }
  piVar2 = (int *)FUN_0054db20();
  puVar3 = &DAT_01d59b00;
  if (0xf < DAT_01d59b14) {
    puVar3 = DAT_01d59b00;
  }
  (**(code **)(*piVar2 + 0x28))(puVar3,DAT_01d59b10);
  FUN_0063f220(param_1);
  if (DAT_01d5a4c0 == '\0') {
    cVar1 = FUN_00585a40();
    bVar4 = cVar1 == '\0';
  }
  else {
    bVar4 = false;
  }
  piVar2 = (int *)FUN_0054db20();
  (**(code **)(*piVar2 + 0x15c))(bVar4);
  return;
}



/* FUNCTION 7313 ; VA 0x00645950 ; FUN_00645950 */

int FUN_00645950(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  char acStack_20 [4];
  undefined auStack_1c [8];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d78;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01eadc98);
  uStack_8._0_1_ = 1;
  uStack_14 = uVar3;
  FUN_00644c20(acStack_20,param_1);
  uStack_8._0_1_ = 2;
  if (acStack_20[0] != '\0') {
    FUN_00646a30(auStack_1c);
    if (acStack_20[0] != '\0') {
      FUN_0056cd30();
      FUN_0056cd30();
      acStack_20[0] = '\0';
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar4 = FUN_01675290(uVar3);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 7314 ; VA 0x00645a10 ; FUN_00645a10 */

void __thiscall FUN_00645a10(uint param_1,uint *param_2,uint *param_3)

{
  uint *puVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  uint *puVar6;
  int *piVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined4 ****ppppuVar10;
  uint uVar11;
  undefined4 ****ppppuVar12;
  bool bVar13;
  uint *puStack_98;
  uint *puStack_94;
  uint **ppuStack_90;
  uint auStack_7f [9];
  uint *puStack_58;
  uint **ppuStack_54;
  int iStack_50;
  int iStack_4c;
  uint **ppuStack_48;
  undefined uStack_44;
  undefined4 uStack_40;
  undefined4 ***apppuStack_38 [3];
  uint uStack_2c;
  uint *puStack_28;
  uint *puStack_24;
  uint uStack_20;
  uint *puStack_1c;
  uint *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0e2e;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (uint *)0x0) {
    ExceptionList = &pvStack_10;
    if (DAT_01d5b2a0 != '\0') {
      ppuStack_90 = (uint **)0x645a58;
      ExceptionList = &pvStack_10;
      FUN_01679490();
    }
    if (*(int *)(param_1 + 0x118) != 0) {
      LOCK();
      piVar7 = (int *)(*(int *)(param_1 + 0x118) + 4);
      *piVar7 = *piVar7 + 1;
      UNLOCK();
    }
    puStack_94 = *(uint **)(param_1 + 0x114);
    ppuStack_90 = *(uint ***)(param_1 + 0x118);
    puStack_98 = (uint *)0x645a8e;
    FUN_00628870();
    *(undefined4 *)(param_1 + 0x114) = 0;
    piVar7 = *(int **)(param_1 + 0x118);
    *(undefined4 *)(param_1 + 0x118) = 0;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar9 = piVar7[1] + -1;
      piVar7[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        ppuStack_90 = (uint **)0x645abe;
        (**(code **)*piVar7)();
        LOCK();
        iVar9 = piVar7[2] + -1;
        piVar7[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          ppuStack_90 = (uint **)0x645ace;
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    if (DAT_01d5a508 != '\0') {
      if (*(int *)(param_1 + 0x120) != 0) {
        LOCK();
        piVar7 = (int *)(*(int *)(param_1 + 0x120) + 4);
        *piVar7 = *piVar7 + 1;
        UNLOCK();
      }
      puStack_94 = *(uint **)(param_1 + 0x11c);
      ppuStack_90 = *(uint ***)(param_1 + 0x120);
      puStack_98 = (uint *)0x645b0d;
      FUN_00628870();
      *(undefined4 *)(param_1 + 0x11c) = 0;
      piVar7 = *(int **)(param_1 + 0x120);
      *(undefined4 *)(param_1 + 0x120) = 0;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar9 = piVar7[1] + -1;
        piVar7[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          ppuStack_90 = (uint **)0x645b3d;
          (**(code **)*piVar7)();
          LOCK();
          iVar9 = piVar7[2] + -1;
          piVar7[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            ppuStack_90 = (uint **)0x645b4d;
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
    }
    ppuStack_90 = (uint **)0x645b58;
    FUN_006ddde0();
    if (*(int *)(param_1 + 0x10c) != 0) {
      ppuStack_90 = (uint **)0x0;
      puStack_94 = (uint *)0x645b69;
      FUN_0098c810();
      ppuStack_90 = (uint **)0x3e8;
      puStack_94 = (uint *)0x645b75;
      FUN_0064b390();
      *(undefined4 *)(param_1 + 0x10c) = 0;
      piVar7 = *(int **)(param_1 + 0x110);
      *(undefined4 *)(param_1 + 0x110) = 0;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar9 = piVar7[1] + -1;
        piVar7[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          ppuStack_90 = (uint **)0x645ba2;
          (**(code **)*piVar7)();
          LOCK();
          iVar9 = piVar7[2] + -1;
          piVar7[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            ppuStack_90 = (uint **)0x645bb2;
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
    }
    ppuStack_90 = (uint **)0x645bbd;
    FUN_01679490();
    ppuStack_90 = (uint **)0x645bc8;
    FUN_01679490();
    ppuStack_90 = (uint **)0x645bd3;
    FUN_006dfa90();
  }
  puVar6 = param_3;
  if (param_3 != (uint *)0x0) {
    ppuStack_90 = (uint **)0x1;
    puStack_94 = param_3;
    puStack_98 = (uint *)0x645be2;
    cVar5 = FUN_00973950();
    if (cVar5 != '\0') {
      puStack_94 = &uStack_2c;
      ppuStack_90 = (uint **)0x18d06a4;
      puStack_98 = (uint *)0x6463a8;
      FUN_016756b0();
      puStack_94 = &uStack_2c;
      ppuStack_90 = (uint **)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
      puStack_98 = (uint *)&UNK_006463b9;
      FUN_0170c2a8();
    }
  }
  ppuStack_90 = (uint **)puVar6;
  puStack_94 = param_2;
  puStack_98 = (uint *)0x645bf8;
  FUN_006c4db0();
  if (puVar6 != (uint *)0x0) {
    if (DAT_01d5b2a0 != '\0') {
      puStack_18 = puVar6 + 0x1a;
      ppuStack_90 = (uint **)DAT_02110da8;
      iStack_8 = 0;
      puStack_94 = (uint *)0x645c25;
      puVar6 = (uint *)FUN_01675290();
      puStack_94 = (uint *)0x1c;
      iStack_8._0_1_ = 1;
      puStack_98 = (uint *)0x645c35;
      puStack_24 = puVar6;
      puStack_1c = (uint *)FUN_01674e20();
      if (puStack_1c == (uint *)0x0) {
        puStack_1c = (uint *)0x0;
      }
      else {
        *puStack_1c = 0;
        puStack_1c[1] = 1;
        puStack_1c[2] = (uint)FUN_00643950;
        puStack_1c[3] = (uint)_guard_check_icall;
        puStack_1c[4] = 0;
        puStack_1c[5] = (uint)puStack_18;
        puStack_1c[6] = param_1;
      }
      puStack_94 = (uint *)0x645c77;
      ppuStack_90 = (uint **)puStack_1c;
      FUN_016797d0();
      param_2 = puStack_1c;
      if (puStack_1c != (uint *)0x0) {
        LOCK();
        puStack_1c[1] = puStack_1c[1] + 1;
        UNLOCK();
      }
      uStack_14 = 1;
      iStack_8._0_1_ = 2;
      puStack_94 = (uint *)0x645c9e;
      ppuStack_90 = (uint **)puVar6;
      FUN_01675290();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      ppuStack_90 = &param_2;
      puStack_94 = (uint *)0x645cb4;
      cVar5 = FUN_01679300();
      if (cVar5 != '\0') {
        ppuStack_90 = (uint **)0x645cc3;
        FUN_01679490();
        ppuStack_90 = &param_2;
        puStack_94 = (uint *)0x645cd2;
        FUN_016791c0();
      }
      iStack_8 = 0xffffffff;
      puVar6 = param_3;
      if (param_2 != (uint *)0x0) {
        puVar1 = param_2 + 1;
        LOCK();
        uVar11 = *puVar1;
        *puVar1 = *puVar1 - 1;
        UNLOCK();
        if (uVar11 == 1) {
          ppuStack_90 = (uint **)param_2;
          puStack_94 = (uint *)0x645cf6;
          FUN_01674ea0();
          puVar6 = param_3;
        }
      }
    }
    ppuStack_90 = (uint **)0x645d03;
    piVar7 = (int *)FUN_00564080();
    ppuStack_90 = (uint **)*piVar7;
    if ((uint *)*piVar7 == (uint *)0x0) {
      ppuStack_90 = &puStack_28;
      puStack_94 = (uint *)0x645d16;
      FUN_0055e4a0();
      iStack_8 = 3;
      puStack_94 = (uint *)0x645d29;
      ppuStack_90 = (uint **)puVar6;
      FUN_008a5700();
      ppuStack_90 = (uint **)&LAB_0055d570;
      puStack_94 = (uint *)&DAT_01ea8a70;
      puStack_98 = (uint *)0x645d38;
      FUN_005789c0();
      ppuStack_90 = (uint **)0x645d40;
      ppuStack_90 = (uint **)FUN_00560c40();
      puStack_94 = (uint *)0x645d48;
      param_3 = (uint *)FUN_008aa140();
      if (puStack_24 != (uint *)0x0) {
        LOCK();
        puStack_24[1] = puStack_24[1] + 1;
        UNLOCK();
      }
      *param_3 = (uint)puStack_28;
      param_2 = (uint *)((int *)param_3)[1];
      ((int *)param_3)[1] = (int)puStack_24;
      if (param_2 != (uint *)0x0) {
        LOCK();
        iVar9 = ((int *)param_2)[1] + -1;
        ((int *)param_2)[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          ppuStack_90 = (uint **)0x645d7d;
          (**(code **)*param_2)();
          LOCK();
          iVar9 = ((int *)param_2)[2] + -1;
          ((int *)param_2)[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            ppuStack_90 = (uint **)0x645d8e;
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      param_3 = puStack_28;
      iStack_8 = 0xffffffff;
      param_2 = puStack_24;
      ppuStack_90 = (uint **)puStack_28;
      if (puStack_24 != (uint *)0x0) {
        LOCK();
        uVar11 = puStack_24[1] - 1;
        puStack_24[1] = uVar11;
        UNLOCK();
        if (uVar11 == 0) {
          ppuStack_90 = (uint **)0x645db2;
          (**(code **)*puStack_24)();
          LOCK();
          uVar11 = param_2[2] - 1;
          param_2[2] = uVar11;
          UNLOCK();
          ppuStack_90 = (uint **)param_3;
          if (uVar11 == 0) {
            ppuStack_90 = (uint **)0x645dc3;
            (**(code **)(*param_2 + 4))();
            ppuStack_90 = (uint **)param_3;
          }
        }
      }
    }
    puStack_94 = &uStack_20;
    puStack_98 = (uint *)0x645dd0;
    puVar8 = (undefined4 *)FUN_0060dcd0();
    uVar3 = *puVar8;
    uVar4 = puVar8[1];
    *puVar8 = 0;
    puVar8[1] = 0;
    *(undefined4 *)(param_1 + 0x10c) = uVar3;
    param_3 = *(uint **)(param_1 + 0x110);
    *(undefined4 *)(param_1 + 0x110) = uVar4;
    if (param_3 != (uint *)0x0) {
      LOCK();
      iVar9 = ((int *)param_3)[1] + -1;
      ((int *)param_3)[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        ppuStack_90 = (uint **)0x645e0b;
        (**(code **)*param_3)();
        LOCK();
        iVar9 = ((int *)param_3)[2] + -1;
        ((int *)param_3)[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          ppuStack_90 = (uint **)0x645e1c;
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    param_3 = puStack_1c;
    if (puStack_1c != (uint *)0x0) {
      LOCK();
      uVar11 = puStack_1c[1] - 1;
      puStack_1c[1] = uVar11;
      UNLOCK();
      if (uVar11 == 0) {
        ppuStack_90 = (uint **)0x645e33;
        (**(code **)*puStack_1c)();
        LOCK();
        uVar11 = param_3[2] - 1;
        param_3[2] = uVar11;
        UNLOCK();
        if (uVar11 == 0) {
          ppuStack_90 = (uint **)0x645e44;
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    ppuStack_90 = *(uint ***)(param_1 + 200);
    puStack_94 = (uint *)0x645e55;
    FUN_0098c810();
    param_3 = puVar6 + -3;
    ppuStack_90 = (uint **)0x645e62;
    FUN_0063ef90();
    ppuStack_90 = (uint **)0x138;
    puStack_94 = (uint *)0x645e6c;
    param_2 = (uint *)FUN_01674e20();
    iStack_8 = 4;
    if (param_2 == (uint *)0x0) {
      puStack_94 = (uint *)0x0;
    }
    else {
      puStack_98 = puVar6 + -3;
      FUN_005c4330(&puStack_94);
      puStack_98 = (uint *)0x645e97;
      puStack_94 = (uint *)FUN_00713390();
    }
    ppuStack_90 = (uint **)param_3;
    iStack_8 = 0xffffffff;
    puStack_28 = (uint *)0x0;
    puStack_24 = (uint *)0x0;
    puStack_98 = (uint *)0x645ebc;
    FUN_0063e1b0();
    *(uint **)(param_1 + 0x114) = puStack_28;
    param_2 = *(uint **)(param_1 + 0x118);
    *(uint **)(param_1 + 0x118) = puStack_24;
    if (param_2 != (uint *)0x0) {
      LOCK();
      iVar9 = ((int *)param_2)[1] + -1;
      ((int *)param_2)[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        ppuStack_90 = (uint **)0x645ee8;
        (**(code **)*param_2)();
        LOCK();
        iVar9 = ((int *)param_2)[2] + -1;
        ((int *)param_2)[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          ppuStack_90 = (uint **)0x645ef9;
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0x118) != 0) {
      LOCK();
      piVar7 = (int *)(*(int *)(param_1 + 0x118) + 4);
      *piVar7 = *piVar7 + 1;
      UNLOCK();
    }
    puStack_94 = *(uint **)(param_1 + 0x114);
    ppuStack_90 = *(uint ***)(param_1 + 0x118);
    puStack_98 = (uint *)0x645f2f;
    FUN_0151d950();
    if (DAT_01d5a508 != '\0') {
      ppuStack_90 = (uint **)0x168;
      puStack_94 = (uint *)0x645f49;
      param_2 = (uint *)FUN_01674e20();
      iStack_8 = 5;
      if (param_2 == (uint *)0x0) {
        puStack_94 = (uint *)0x0;
      }
      else {
        ppuStack_90 = (uint **)(param_1 + 0x128);
        FUN_005c4330(&puStack_98,puVar6 + -3);
        puStack_94 = (uint *)FUN_006402a0();
      }
      ppuStack_90 = (uint **)param_3;
      iStack_8 = 0xffffffff;
      puStack_28 = (uint *)0x0;
      puStack_24 = (uint *)0x0;
      puStack_98 = (uint *)0x645fa0;
      FUN_0063e2a0();
      *(uint **)(param_1 + 0x11c) = puStack_28;
      param_2 = *(uint **)(param_1 + 0x120);
      *(uint **)(param_1 + 0x120) = puStack_24;
      if (param_2 != (uint *)0x0) {
        LOCK();
        iVar9 = ((int *)param_2)[1] + -1;
        ((int *)param_2)[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          ppuStack_90 = (uint **)0x645fcc;
          (**(code **)*param_2)();
          LOCK();
          iVar9 = ((int *)param_2)[2] + -1;
          ((int *)param_2)[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            ppuStack_90 = (uint **)0x645fdd;
            (**(code **)(*param_2 + 4))();
          }
        }
      }
      if (*(int *)(param_1 + 0x120) != 0) {
        LOCK();
        piVar7 = (int *)(*(int *)(param_1 + 0x120) + 4);
        *piVar7 = *piVar7 + 1;
        UNLOCK();
      }
      puStack_94 = *(uint **)(param_1 + 0x11c);
      ppuStack_90 = *(uint ***)(param_1 + 0x120);
      puStack_98 = (uint *)0x646013;
      FUN_0151d950();
      puStack_98 = puVar6;
      iVar9 = FUN_008f7870();
      puStack_24 = (uint *)((uint)puStack_24 & 0xffffff00);
      piVar7 = *(int **)(iVar9 + 0x43c);
      puStack_1c = (uint *)(piVar7[1] - (int)piVar7);
      uStack_20 = *piVar7 - (int)piVar7;
      puStack_28 = (uint *)(param_1 + 0x3f4);
      ppuStack_90 = (uint **)0x646046;
      FUN_00587410();
      ppuStack_90 = (uint **)&uStack_20;
      iStack_8 = 6;
      puStack_94 = (uint *)0x64605c;
      iVar9 = FUN_00641b10();
      *(undefined4 *)(iVar9 + 8) = 2;
      iStack_8 = 7;
      if ((char)puStack_24 != '\0') {
        LOCK();
        uVar11 = *puStack_28;
        *puStack_28 = *puStack_28 + 0x80000000;
        UNLOCK();
        if (((uVar11 & 0x40000000) == 0) && (-0x80000000 < (int)uVar11)) {
          LOCK();
          uVar11 = *puStack_28;
          *puStack_28 = *puStack_28 | 0x40000000;
          UNLOCK();
          if ((uVar11 >> 0x1e & 1) == 0) {
            ppuStack_90 = (uint **)0x646096;
            ppuStack_90 = (uint **)FUN_00554e40();
            puStack_94 = (uint *)0x64609d;
            SetEvent();
          }
        }
      }
      iStack_8 = 0xffffffff;
    }
    puVar6 = param_3;
    puStack_98 = param_3;
    FUN_005c4330(&puStack_94);
    puStack_98 = (uint *)0x6460c1;
    FUN_006de1a0();
    piVar7 = (int *)puVar6[0x10f];
    iStack_50 = *piVar7 - (int)piVar7;
    iVar9 = piVar7[1] - (int)piVar7;
    iStack_8 = 8;
    puStack_58 = auStack_7f;
    ppuStack_54 = &puStack_58;
    puStack_28 = (uint *)0x0;
    puStack_24 = (uint *)0xf;
    apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
    uStack_14 = 2;
    iStack_4c = iVar9;
    if ((iVar9 < 1) && (iVar9 < 0)) {
      bVar13 = iStack_50 != 0;
      iStack_50 = -iStack_50;
      iStack_4c = -(iVar9 + (uint)bVar13);
    }
    ppuStack_48 = &puStack_58;
    uStack_44 = 0x30;
    uStack_40 = 0x30;
    ppuStack_90 = (uint **)0x646136;
    param_2 = (uint *)FUN_00642d60();
    if ((iVar9 < 1) && (iVar9 < 0)) {
      param_2 = (uint *)((int)param_2 + -1);
      *(undefined *)param_2 = 0x2d;
    }
    ppuStack_54 = &puStack_58;
    ppppuVar10 = apppuStack_38;
    if (0xf < puStack_24) {
      ppppuVar10 = (undefined4 ****)apppuStack_38[0];
    }
    ppppuVar12 = apppuStack_38;
    if (0xf < puStack_24) {
      ppppuVar12 = (undefined4 ****)apppuStack_38[0];
    }
    puStack_98 = (uint *)((int)ppppuVar10 + ((int)puStack_28 - (int)ppppuVar12));
    ppppuVar10 = apppuStack_38;
    if (0xf < puStack_24) {
      ppppuVar10 = (undefined4 ****)apppuStack_38[0];
    }
    ppuStack_90 = (uint **)((int)&puStack_58 - (int)param_2);
    puStack_94 = param_2;
    puStack_58 = param_2;
    FUN_00591430((int)ppppuVar12 - (int)ppppuVar10);
    ppuStack_90 = (uint **)0x0;
    ppppuVar10 = apppuStack_38;
    if (0xf < puStack_24) {
      ppppuVar10 = (undefined4 ****)apppuStack_38[0];
    }
    puStack_94 = (uint *)0x0;
    puStack_98 = (uint *)0x0;
    FUN_0087c450(&DAT_018c5f98,"PlaceID",ppppuVar10);
    uStack_14 = 0;
    iStack_8 = 0xffffffff;
    ppuStack_90 = (uint **)0x6461c9;
    FUN_005507b0();
    piVar7 = (int *)param_3[0x10f];
    if (((int *)*piVar7 == piVar7) && ((int *)piVar7[1] == piVar7)) {
      ppuStack_90 = (uint **)0x6461e8;
      FUN_006463c0();
    }
    else {
      puStack_1c = param_3 + 0x2a;
      ppuStack_90 = (uint **)DAT_02110da8;
      iStack_8 = 9;
      puStack_94 = (uint *)0x646238;
      uVar11 = FUN_01675290();
      puStack_94 = (uint *)0x1c;
      iStack_8._0_1_ = 10;
      puStack_98 = (uint *)0x646248;
      puStack_24 = (uint *)uVar11;
      puStack_18 = (uint *)FUN_01674e20();
      if (puStack_18 == (uint *)0x0) {
        puVar6 = (uint *)0x0;
      }
      else {
        *puStack_18 = 0;
        puStack_18[1] = 1;
        puStack_18[2] = (uint)FUN_00643940;
        puStack_18[3] = (uint)_guard_check_icall;
        puStack_18[4] = 0;
        puStack_18[5] = (uint)puStack_1c;
        puStack_18[6] = param_1;
        puVar6 = puStack_18;
      }
      puStack_94 = (uint *)0x646289;
      ppuStack_90 = (uint **)puVar6;
      FUN_016797d0();
      if (puVar6 != (uint *)0x0) {
        LOCK();
        puVar6[1] = puVar6[1] + 1;
        UNLOCK();
      }
      uStack_14 = 4;
      iStack_8._0_1_ = 0xb;
      puStack_94 = (uint *)0x6462ad;
      param_2 = puVar6;
      ppuStack_90 = (uint **)uVar11;
      FUN_01675290();
      iStack_8 = CONCAT31(iStack_8._1_3_,9);
      ppuStack_90 = &param_2;
      puStack_94 = (uint *)0x6462c3;
      cVar5 = FUN_01679300();
      if (cVar5 != '\0') {
        ppuStack_90 = (uint **)0x6462d2;
        FUN_01679490();
        ppuStack_90 = &param_2;
        puStack_94 = (uint *)0x6462e1;
        FUN_016791c0();
      }
      iStack_8 = 0xffffffff;
      if (param_2 != (uint *)0x0) {
        puVar6 = param_2 + 1;
        LOCK();
        uVar11 = *puVar6;
        *puVar6 = *puVar6 - 1;
        UNLOCK();
        if (uVar11 == 1) {
          ppuStack_90 = (uint **)param_2;
          puStack_94 = (uint *)0x646310;
          FUN_01674ea0();
        }
      }
    }
    ppuStack_90 = (uint **)0x4c;
    uVar11 = param_3[0x113];
    puStack_94 = (uint *)0x6461fb;
    param_2 = (uint *)FUN_01674e20();
    iStack_8 = 0xc;
    if (param_2 == (uint *)0x0) {
      puStack_94 = (uint *)0x0;
    }
    else {
      puStack_94 = (uint *)0x646218;
      ppuStack_90 = (uint **)uVar11;
      puStack_94 = (uint *)FUN_00715b20();
    }
    ppuStack_90 = (uint **)param_3;
    iStack_8 = 0xffffffff;
    puStack_28 = (uint *)0x0;
    puStack_24 = (uint *)0x0;
    puStack_98 = (uint *)0x64633b;
    FUN_0063e0c0();
    *(uint **)(param_1 + 0x42c) = puStack_28;
    piVar7 = *(int **)(param_1 + 0x430);
    *(uint **)(param_1 + 0x430) = puStack_24;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar9 = piVar7[1] + -1;
      piVar7[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        ppuStack_90 = (uint **)0x646366;
        (**(code **)*piVar7)();
        LOCK();
        piVar2 = piVar7 + 2;
        iVar9 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar9 == 1) {
          ppuStack_90 = (uint **)0x646375;
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    ppuStack_90 = (uint **)param_3;
    puStack_94 = (uint *)(param_1 + 0x448);
    puStack_98 = (uint *)0x646384;
    FUN_005f1d60();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7315 ; VA 0x006463c0 ; FUN_006463c0 */

void __fastcall FUN_006463c0(int *param_1)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  undefined auStack_50 [32];
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0e69;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  uVar3 = FUN_01675290(DAT_01eadc98);
  uStack_8 = 0;
  uStack_24 = uVar3;
  if (param_1 != (int *)0x0) {
    piStack_14 = (int *)param_1[0xd];
    piVar4 = param_1;
    if ((piStack_14 != (int *)0x0) && (piVar4 = piStack_14, piStack_14[0xd] != 0)) {
      piVar4 = (int *)FUN_005c8ac0();
    }
    piStack_14 = piVar4;
    if ((piStack_14 != (int *)0x0) &&
       (iVar7 = piStack_14[3], iVar5 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
       (uint)*(ushort *)(iVar5 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8ad8,&LAB_0055d5d0);
      uVar6 = FUN_00560f40();
      piStack_14 = (int *)FUN_008aa140(uVar6);
      if (*piStack_14 == 0) {
        uVar6 = FUN_008aa950();
        piVar4 = (int *)FUN_008a9ba0(auStack_30,uVar6);
        iVar7 = *piVar4;
        iVar5 = piVar4[1];
        *piVar4 = 0;
        piVar4[1] = 0;
        *piStack_14 = iVar7;
        piVar4 = (int *)piStack_14[1];
        piStack_14[1] = iVar5;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar7 = piVar4[1] + -1;
          piVar4[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar7 = piVar4[2] + -1;
            piVar4[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        piVar4 = piStack_2c;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar7 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar7 = *piVar1 + -1;
            *piVar1 = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
      }
      iVar7 = *piStack_14;
      goto LAB_00646510;
    }
  }
  iVar7 = 0;
LAB_00646510:
  if (*(char *)(iVar7 + 0x300) != '\0') {
    FUN_0087c450(&DAT_018c5f98,"NetworkStreamingEnabled",&DAT_018ccd30,0,0,0);
  }
  piStack_18 = (int *)FUN_00a9d3e0();
  if (((piStack_18 != (int *)0x0) &&
      (iVar7 = piStack_18[3], iVar5 = FUN_00af0010(),
      (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
      (uint)*(ushort *)(iVar5 + 0x1da))) && (cVar2 = FUN_00afc8c0(), cVar2 != '\0')) {
    iVar7 = FUN_008f7870(param_1);
    piVar4 = *(int **)(iVar7 + 0x43c);
    FUN_005bde90(auStack_50,&DAT_018bed48,*piVar4 - (int)piVar4,piVar4[1] - (int)piVar4);
    FUN_0087c450(&DAT_018c5f98,"SmoothTerrain",auStack_50,0,0,0);
  }
  if (param_1 != (int *)0x0) {
    piStack_14 = (int *)param_1[0xd];
    piVar4 = param_1;
    if ((piStack_14 != (int *)0x0) && (piVar4 = piStack_14, piStack_14[0xd] != 0)) {
      piVar4 = (int *)FUN_005c8ac0();
    }
    piStack_14 = piVar4;
    if (((piStack_14 != (int *)0x0) &&
        (iVar7 = piStack_14[3], iVar5 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da))) && (iVar7 = FUN_0063f510(), iVar7 != 0)) {
      FUN_00bb4820();
    }
  }
  iVar7 = FUN_008f7870(param_1);
  if (iVar7 != 0) {
    piStack_18 = param_1;
    FUN_0063ffa0(&piStack_18);
    iVar7 = FUN_008a4100();
    piStack_18 = (int *)(iVar7 + 0x10);
    uStack_8._0_1_ = 1;
    uVar6 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 2;
    uStack_28 = uVar6;
    piStack_2c = (int *)FUN_01674e20(0x1c);
    if (piStack_2c == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      *piStack_2c = 0;
      piStack_2c[1] = 1;
      piStack_2c[2] = (int)FUN_006439d0;
      piStack_2c[3] = (int)_guard_check_icall;
      piStack_2c[4] = 0;
      piStack_2c[5] = (int)piStack_18;
      piStack_2c[6] = (int)piStack_1c;
      piVar4 = piStack_2c;
    }
    FUN_016797d0(piVar4);
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
    }
    uStack_20 = 1;
    uStack_8._0_1_ = 3;
    piStack_14 = piVar4;
    FUN_01675290(uVar6);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    cVar2 = FUN_01679300(&piStack_14);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_14);
    }
    if (piStack_14 != (int *)0x0) {
      piVar4 = piStack_14 + 1;
      LOCK();
      iVar7 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(piStack_14);
      }
    }
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7316 ; VA 0x00646740 ; FUN_00646740 */

undefined4 FUN_00646740(int param_1)

{
  return CONCAT31((int3)(param_1 - 0x18U >> 8),param_1 - 0x18U < 0xd);
}



/* FUNCTION 7317 ; VA 0x00646760 ; FUN_00646760 */

void __thiscall FUN_00646760(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 4;
    return;
  }
  FUN_0063d9b0(puVar1,param_2);
  return;
}



/* FUNCTION 7318 ; VA 0x00646790 ; FUN_00646790 */

float10 __fastcall FUN_00646790(double *param_1)

{
  double *pdVar1;
  double dVar2;
  double dVar3;
  undefined auStack_14 [16];
  
  pdVar1 = (double *)FUN_016827a0(auStack_14);
  dVar3 = param_1[4];
  if (((*(char **)(param_1 + 7) == (char *)0x0) || (**(char **)(param_1 + 7) == '\0')) &&
     (dVar3 + dVar3 < *pdVar1 - *param_1)) {
    dVar3 = *pdVar1 - *param_1;
  }
  dVar2 = 0.0;
  if (0.0 < dVar3) {
    dVar2 = DAT_018c0d60 / dVar3;
  }
  return (float10)dVar2;
}



/* FUNCTION 7319 ; VA 0x00646810 ; FUN_00646810 */

void __thiscall FUN_00646810(int param_1,int param_2)

{
  undefined4 uVar1;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined auStack_54 [48];
  undefined auStack_24 [8];
  int iStack_1c;
  undefined auStack_18 [4];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0ea8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa0;
  uStack_8 = 0;
  iStack_1c = param_1;
  if (*(int *)(param_1 + 0x458) < 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_00886c00(auStack_24,&param_2);
    uStack_8._0_1_ = 1;
    FUN_00886840(uVar1);
    uStack_8._0_1_ = 0;
    FUN_0056cd30();
    FUN_0056cd30();
    FUN_00a33c70();
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&param_2);
    uStack_8._0_1_ = 3;
    FUN_00a34170(auStack_54);
    uVar1 = FUN_00646a30(auStack_18);
    *(undefined4 *)(param_1 + 0x458) = uVar1;
    *(undefined4 *)(param_1 + 0x45c) = in_stack_0000001c;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_00643700(&stack0x0000001c,0xffffffff,0xffffffff);
    FUN_0064691e();
    return;
  }
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if ((param_2 - *(int *)(param_2 + -4)) - 4U < 0x20) {
        ExceptionList = &pvStack_10;
        puStack_14 = &stack0xffffffa0;
        FUN_006469f6();
        return;
      }
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffa0;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffa0;
    FUN_01674ea0(param_2,in_stack_00000018 + 1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7320 ; VA 0x00646908 ; Catch_All@00646908 */

undefined * Catch_All_00646908(void)

{
  int unaff_EBP;
  
  *(undefined4 *)(*(int *)(unaff_EBP + -0x18) + 0x458) = 0xffffffff;
  return &DAT_0064691b;
}



/* FUNCTION 7321 ; VA 0x0064691e ; FUN_0064691e */

void FUN_0064691e(void)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  int iVar4;
  uint uVar5;
  char *pcVar6;
  uint uVar7;
  int unaff_EBP;
  int unaff_ESI;
  
  iVar2 = *(int *)(unaff_ESI + 0x458);
  pcVar6 = "DynLua-InitFail";
  *(undefined4 *)(unaff_EBP + -4) = 3;
  if (iVar2 != -1) {
    pcVar6 = "DynLua-InitPass";
  }
  *(undefined4 *)(unaff_EBP + -0x28) = 0;
  *(undefined4 *)(unaff_EBP + -0x24) = 0xf;
  *(undefined *)(unaff_EBP + -0x38) = 0;
  pcVar3 = pcVar6;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar6,(int)pcVar3 - (int)(pcVar6 + 1));
  *(undefined *)(unaff_EBP + -4) = 6;
  FUN_008783f0(unaff_EBP + -0x38,1,0);
  uVar5 = *(uint *)(unaff_EBP + -0x24);
  if (0xf < uVar5) {
    iVar2 = *(int *)(unaff_EBP + -0x38);
    uVar7 = uVar5 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar7) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar7 = uVar5 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar5 = *(uint *)(unaff_EBP + -0x3c);
  if (0xf < uVar5) {
    iVar2 = *(int *)(unaff_EBP + -0x50);
    uVar7 = uVar5 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar7) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar7 = uVar5 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  *(undefined4 *)(unaff_EBP + -0x40) = 0;
  *(undefined4 *)(unaff_EBP + -0x3c) = 0xf;
  *(undefined *)(unaff_EBP + -0x50) = 0;
  FUN_0056cd30();
  if (0xf < *(uint *)(unaff_EBP + 0x1c)) {
    iVar2 = *(int *)(unaff_EBP + 8);
    uVar5 = *(uint *)(unaff_EBP + 0x1c) + 1;
    if (0xfff < uVar5) {
      if ((iVar2 - *(int *)(iVar2 + -4)) - 4U < 0x20) {
        FUN_006469f6();
        return;
      }
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0(iVar2,uVar5);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 7322 ; VA 0x006469f6 ; FUN_006469f6 */

void __fastcall FUN_006469f6(undefined4 param_1,undefined4 param_2)

{
  int unaff_EBP;
  
  FUN_01674ea0(param_1,param_2);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 7323 ; VA 0x00646a30 ; FUN_00646a30 */

int __thiscall FUN_00646a30(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  undefined auStack_4c [24];
  undefined auStack_34 [24];
  undefined8 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0ee0;
  pvStack_10 = ExceptionList;
  iVar7 = param_1 + 0x3c5 + (uint)*(byte *)(param_1 + 0x3c4);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar4 = FUN_00a33fd0(param_2);
  FUN_0063f830(&param_2,uVar4,piVar3,-(uint)(iVar7 != 0) & iVar7 + 1U);
  iVar7 = iStack_14;
  if (param_2 == (int *)0x0) {
    uStack_1c = 0;
    iVar6 = *(int *)(iStack_14 + 0x3bc) - *(int *)(iStack_14 + 0x3b8) >> 3;
    FUN_00a33c70();
    uStack_8 = 0;
    FUN_00a33c70();
    piVar1 = *(int **)(iVar7 + 0x3bc);
    uStack_8 = 1;
    if (*(int **)(iVar7 + 0x3c0) == piVar1) {
      FUN_0063dac0(piVar1,&uStack_1c);
    }
    else {
      *piVar1 = (int)uStack_1c;
      LOCK();
      *(int *)((int)uStack_1c + 0x28) = *(int *)((int)uStack_1c + 0x28) + 1;
      UNLOCK();
      piVar1[1] = uStack_1c._4_4_;
      LOCK();
      *(int *)(uStack_1c._4_4_ + 0x28) = *(int *)(uStack_1c._4_4_ + 0x28) + 1;
      UNLOCK();
      *(int *)(iVar7 + 0x3bc) = *(int *)(iVar7 + 0x3bc) + 8;
    }
    uStack_8 = 0xffffffff;
    FUN_0056cd30();
    FUN_0056cd30();
    iVar7 = *(int *)(iStack_14 + 0x3bc);
    iVar2 = *piVar3;
    LOCK();
    piVar1 = (int *)(iVar2 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    param_2 = *(int **)(iVar7 + -8);
    *(int *)(iVar7 + -8) = iVar2;
    FUN_0056cd30();
    if (*(int *)(iStack_14 + 0x124) == 1) {
      if (DAT_01ead6a1 != '\0') {
        puVar5 = (undefined4 *)FUN_00a33fa0();
        if (0xf < (uint)puVar5[5]) {
          puVar5 = (undefined4 *)*puVar5;
        }
        FUN_01677650(DAT_01ead6a1,"Compiling script: %s",puVar5);
      }
      uVar4 = FUN_00a33fa0(2,0);
      uVar4 = FUN_009edc00(auStack_34,uVar4);
      uStack_8 = 2;
      FUN_00a34170(uVar4);
    }
    else {
      uVar4 = FUN_00a33fa0(0,0);
      uVar4 = FUN_009edc00(auStack_4c,uVar4);
      uStack_8 = 3;
      FUN_00a34170(uVar4);
    }
    uStack_8 = 0xffffffff;
    FUN_005507b0();
    iVar7 = FUN_00641930(piVar3);
    *(int *)(iVar7 + 4) = iVar6;
    ExceptionList = pvStack_10;
    return iVar6;
  }
  ExceptionList = pvStack_10;
  return param_2[3];
}



/* FUNCTION 7324 ; VA 0x00646c10 ; FUN_00646c10 */

/* WARNING: Removing unreachable block (ram,0x00646c6d) */
/* WARNING: Removing unreachable block (ram,0x00646c80) */
/* WARNING: Removing unreachable block (ram,0x00646c87) */
/* WARNING: Removing unreachable block (ram,0x00646c8e) */

void FUN_00646c10(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  iVar1 = FUN_00641b10(&param_1);
  *(undefined4 *)(iVar1 + 8) = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7325 ; VA 0x00646cb0 ; FUN_00646cb0 */

int FUN_00646cb0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar3 = FUN_00641d00(&param_1);
  iVar5 = param_3[1];
  if (iVar5 != 0) {
    LOCK();
    *(int *)(iVar5 + 8) = *(int *)(iVar5 + 8) + 1;
    UNLOCK();
    iVar5 = param_3[1];
  }
  iVar4 = *param_3;
  *(int *)(iVar3 + 8) = iVar4;
  piVar2 = *(int **)(iVar3 + 0xc);
  *(int *)(iVar3 + 0xc) = iVar5;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)(*piVar2 + 4))();
    }
  }
  return iVar4;
}



/* FUNCTION 7326 ; VA 0x00646d00 ; FUN_00646d00 */

void FUN_00646d00(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined1 *puVar9;
  undefined4 ***pppuVar10;
  undefined *puVar11;
  undefined4 ***pppuVar12;
  undefined *puVar13;
  undefined4 uVar14;
  undefined4 ***pppuVar15;
  char *pcVar16;
  char *pcVar17;
  undefined4 ***pppuVar18;
  char *pcVar19;
  undefined auStack_220 [24];
  undefined auStack_208 [96];
  char acStack_1a8 [224];
  undefined auStack_c8 [24];
  undefined auStack_b0 [24];
  undefined auStack_98 [24];
  undefined4 **appuStack_80 [5];
  uint uStack_6c;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined auStack_50 [16];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  char *pcStack_20;
  undefined4 **ppuStack_1c;
  char *pcStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0f52;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01679ce0();
  if ((int)(uVar5 % 10000) < DAT_01ead6a4) {
    if (*(int *)(param_1 + 0x1b8) != 0) {
      piVar2 = *(int **)(param_1 + 0x43c);
      iVar3 = piVar2[1];
      pppuVar12 = (undefined4 ***)(*piVar2 - (int)piVar2);
      cStack_11 = *(char *)(*(int *)(param_1 + 0x1b8) + 0x31b);
      pcStack_20 = (char *)(iVar3 - (int)piVar2);
      puVar6 = (undefined4 *)FUN_0151b370();
      puVar1 = puVar6 + 4;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_0151bda0(auStack_220,puVar6,*puVar1);
      uStack_8 = 0;
      uStack_58 = 0;
      uStack_54 = 0xf;
      auStack_68[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_8._0_1_ = 1;
      uStack_40 = 0;
      uStack_3c = 0xf;
      auStack_50[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_8._0_1_ = 2;
      uVar7 = FUN_01675640(auStack_b0,"/places/%lld/report/metadata",pppuVar12,
                           (char *)(iVar3 - (int)piVar2));
      uStack_8._0_1_ = 3;
      uVar14 = 0x646e12;
      uVar8 = FUN_0151b590(auStack_98,auStack_208,&DAT_018c912c);
      uStack_8._0_1_ = 4;
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      FUN_005542c0("https",5);
      uStack_8._0_1_ = 5;
      puVar11 = auStack_38;
      pcVar16 = acStack_1a8;
      pppuVar15 = (undefined4 ***)0x646e5a;
      FUN_0151bcc0(pcVar16,puVar11,uVar8,uVar7,auStack_50,auStack_68);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      uStack_8._0_1_ = 0xb;
      FUN_005507b0();
      uVar7 = FUN_0151bb70(auStack_c8);
      uStack_8._0_1_ = 0xc;
      FUN_014cc090(uVar7,0,0);
      uStack_8._0_1_ = 0xe;
      FUN_005507b0();
      puVar9 = &DAT_018bdf50;
      if (cStack_11 == '\0') {
        puVar9 = &DAT_018bdf48;
      }
      pppuVar18 = appuStack_80;
      pcVar19 = "{\"FilteringEnabled\": %s}";
      pcVar17 = (char *)0x646ee4;
      FUN_01675640(pppuVar18,"{\"FilteringEnabled\": %s}",puVar9);
      pcStack_18 = pcStack_20;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
      if (DAT_01ead6a0 != 0) {
        pppuVar10 = appuStack_80;
        if (0xf < uStack_6c) {
          pppuVar10 = (undefined4 ***)appuStack_80[0];
        }
        puVar11 = (undefined *)(uint)DAT_01ead6a0;
        pcVar17 = "ReportFeOnStartup: Sending report for %lld: %s";
        pcVar16 = (char *)0x646f14;
        pppuVar18 = pppuVar12;
        pcVar19 = pcStack_20;
        FUN_01677520(puVar11,"ReportFeOnStartup: Sending report for %lld: %s",pppuVar12,pcStack_20,
                     pppuVar10);
      }
      uVar7 = 0;
      ppuStack_1c = pppuVar12;
      cVar4 = FUN_00585a40(&ppuStack_1c);
      if (cVar4 == '\0') {
        puVar13 = &DAT_018d08d1;
        pppuVar15 = (undefined4 ***)ppuStack_1c;
        pcVar16 = pcStack_18;
      }
      else {
        puVar13 = (undefined *)0x0;
      }
      FUN_014cd990(appuStack_80,&DAT_01d79f98,0,puVar13,uVar14,pppuVar15,pcVar16,puVar11,pcVar17,
                   pppuVar18,pcVar19,uVar7);
      FUN_005507b0();
      FUN_0056db40();
      FUN_0056d9d0();
      FUN_0056d9d0();
      ExceptionList = pvStack_10;
      return;
    }
    if (DAT_01ead6a0 != 0) {
      FUN_016774b0(DAT_01ead6a0,"ReportFeOnStartup: No workspace. No report.",0);
    }
    pcVar16 = "No workspace";
  }
  else {
    if (DAT_01ead6a0 != 0) {
      FUN_016774b0(DAT_01ead6a0,"ReportFeOnStartup: Lost lottery. No report.",0);
    }
    pcVar16 = "Lost lottery";
  }
  FUN_00647000(pcVar16);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7327 ; VA 0x00647000 ; FUN_00647000 */

void FUN_00647000(undefined4 param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(DAT_01ead6a8,0,0);
  uStack_8 = 0;
  FUN_0151f850("Message",param_1);
  uVar1 = DAT_01ead6a8;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("ReportFeOnStartupError",0x16);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01520d20(auStack_28,uVar1,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7328 ; VA 0x006470d0 ; FUN_006470d0 */

int FUN_006470d0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  int *piVar3;
  uint *puVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  undefined4 ****ppppuVar10;
  int iVar11;
  float10 fVar12;
  undefined uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  uint uStack_e4;
  uint uStack_e0;
  uint uStack_dc;
  uint uStack_d8;
  undefined8 uStack_d4;
  double dStack_cc;
  undefined4 ***apppuStack_c4 [4];
  undefined4 uStack_b4;
  uint uStack_b0;
  int iStack_ac;
  int *piStack_a8;
  double dStack_a4;
  undefined8 uStack_9c;
  uint uStack_94;
  uint uStack_90;
  uint uStack_8c;
  uint uStack_88;
  undefined8 uStack_84;
  undefined4 ***apppuStack_7c [3];
  int iStack_70;
  int iStack_6c;
  uint uStack_68;
  undefined8 uStack_64;
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined8 uStack_44;
  undefined auStack_3c [12];
  undefined4 uStack_30;
  uint *puStack_2c;
  uint *puStack_28;
  undefined8 uStack_24;
  char cStack_19;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a107c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00587490(&iStack_ac);
  uStack_8._0_1_ = 1;
  if (iStack_ac == 0) goto LAB_00647c4b;
  fVar12 = (float10)FUN_008fc0f0();
  uStack_b4 = 0;
  dStack_a4 = (double)fVar12;
  uStack_b0 = 0xf;
  apppuStack_c4[0] = (undefined4 ***)((uint)apppuStack_c4[0] & 0xffffff00);
  FUN_005542c0("RCCUnthrottledWorldStepFrac",0x1b);
  ppppuVar10 = apppuStack_c4;
  uVar15 = 0;
  uStack_8._0_1_ = 2;
  uVar5 = SUB84(dStack_a4,0);
  uVar14 = (undefined4)((ulonglong)dStack_a4 >> 0x20);
  FUN_00878cf0();
  ppppuVar2 = apppuStack_c4;
  if (0xf < uStack_b0) {
    ppppuVar2 = (undefined4 ****)apppuStack_c4[0];
  }
  FUN_01675640(&uStack_94,"%s_Datacenter_%d",ppppuVar2,DAT_01d7a884,ppppuVar10,uVar5,uVar14,uVar15);
  uStack_8._0_1_ = 3;
  FUN_00878cf0();
  uStack_8._0_1_ = 2;
  if (0xf < uStack_84._4_4_) {
    uVar8 = uStack_84._4_4_ + 1;
    uVar7 = uStack_94;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(uStack_94 - 4);
      uVar8 = uStack_84._4_4_ + 0x24;
      if (0x1f < (uStack_94 - uVar7) - 4) {
LAB_00647c98:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  cStack_19 = (NAN(*(double *)(iStack_ac + 0x3b0)) || NAN(DAT_018ce330)) ==
              (*(double *)(iStack_ac + 0x3b0) == DAT_018ce330);
  iVar1 = FUN_008f7c50();
  uStack_24 = (double)CONCAT44(iVar1 - *(int *)(iStack_ac + 0x3ac),(undefined4)uStack_24);
  *(int *)(iStack_ac + 0x3ac) = iVar1;
  piVar3 = (int *)FUN_00564130();
  uStack_18 = *(double *)(*piVar3 + 0x80) - *(double *)(iStack_ac + 0x3b0);
  *(double *)(iStack_ac + 0x3b0) = *(double *)(*piVar3 + 0x80);
  if (cStack_19 != '\0') {
    if (DAT_01d67c90 == '\0') {
      fVar12 = (float10)FUN_00bb5be0();
      uStack_9c = (double)fVar12;
      uStack_64 = (uStack_9c * (double)(int)uStack_24._4_4_ * DAT_018ce318) / uStack_18;
    }
    else {
      uStack_64 = ((double)*(float *)(*(int *)(*(int *)(param_1 + 0x1b8) + 0x1b4) + 0x610) *
                   (double)(int)uStack_24._4_4_ * DAT_018ce318) / uStack_18;
    }
    uStack_30 = 0;
    puStack_2c = (uint *)0x0;
    puStack_28 = (uint *)0x0;
    uStack_8._0_1_ = 4;
    uStack_24 = uStack_64;
    uStack_18 = uStack_64;
    FUN_00564080();
    uVar13 = 0;
    FUN_005542c0("RCCUnthrottledWorldStepRealTimePerc",0x23);
    FUN_00643c50(&uStack_30,uVar13);
    puVar4 = (uint *)FUN_01675640(&uStack_54,"RCCUnthrottledWorldStepRealTimePerc_Datacenter_%d",
                                  DAT_01d7a884);
    uStack_8._0_1_ = 5;
    if (puStack_28 == puStack_2c) {
      FUN_00633500(puStack_2c,puVar4,&uStack_24);
      uStack_64 = uStack_24;
    }
    else {
      puStack_2c[4] = 0;
      puStack_2c[5] = 0;
      uVar7 = puVar4[1];
      uVar8 = puVar4[2];
      uVar9 = puVar4[3];
      *puStack_2c = *puVar4;
      puStack_2c[1] = uVar7;
      puStack_2c[2] = uVar8;
      puStack_2c[3] = uVar9;
      *(undefined8 *)(puStack_2c + 4) = *(undefined8 *)(puVar4 + 4);
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
      *(double *)(puStack_2c + 6) = uStack_64;
      puStack_2c = puStack_2c + 8;
    }
    uStack_8._0_1_ = 4;
    FUN_005507b0();
    FUN_00874d70(&uStack_30,0);
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8._0_1_ = 6;
    uVar5 = FUN_008fba30();
    FUN_0151f9c0("PlayerCount",uVar5);
    piVar3 = *(int **)(param_1 + 0x43c);
    FUN_0151fbb0("PlaceId",*piVar3 - (int)piVar3,piVar3[1] - (int)piVar3);
    FUN_0151fb00("RCCUnthrottledWorldStepRealTimePerc",SUB84(uStack_64,0),
                 (int)((ulonglong)uStack_64 >> 0x20));
    FUN_0151f950("GameID",&DAT_01d79c68);
    uVar5 = DAT_01ead6ac;
    iStack_6c = 0;
    uStack_68 = 0xf;
    apppuStack_7c[0] = (undefined4 ***)((uint)apppuStack_7c[0] & 0xffffff00);
    FUN_005542c0("RCCPhysicsUnthrottledRealTimePercStat",0x25);
    uStack_8._0_1_ = 7;
    FUN_01520d20(apppuStack_7c,uVar5,0);
    FUN_005507b0();
    FUN_0151f7f0();
    uStack_8._0_1_ = 2;
    FUN_0056d3e0();
  }
  if (*(int *)(param_1 + 0x1b8) != 0) {
    uStack_30 = 0;
    puStack_2c = (uint *)0x0;
    puStack_28 = (uint *)0x0;
    uStack_8._0_1_ = 8;
    FUN_008f7f30(&uStack_9c,(int)&uStack_64 + 4);
    uStack_18 = uStack_9c;
    uStack_4c = 0;
    uStack_48 = 0xf;
    uStack_5c = uStack_5c & 0xffffff00;
    FUN_005542c0("RCCInterpolationAvgFrameTime",0x1c);
    uStack_44 = uStack_18;
    uStack_8._0_1_ = 9;
    FUN_00625cd0(&uStack_5c);
    FUN_005507b0();
    iStack_70 = 0;
    iStack_6c = 0;
    uStack_68 = 0;
    uStack_8._0_1_ = 10;
    FUN_008f7f60(&iStack_70);
    uVar7 = 0;
    uStack_24 = (double)((ulonglong)uStack_24 & 0xffffffff);
    if (iStack_6c - iStack_70 >> 4 != 0) {
      iVar11 = 0;
      iVar1 = iStack_70;
      do {
        if (DAT_01d67c5c < *(uint *)(iVar11 + 8 + iVar1)) {
          uStack_18 = (double)CONCAT44(uVar7,(undefined4)uStack_18);
          FUN_009ee270(&uStack_54,(int)&uStack_18 + 4);
          uStack_8._0_1_ = 0xb;
          puVar4 = (uint *)FUN_00585d40(0,"RCCInterpolationAvgFrameTime_LoadLevel_",0x27);
          uStack_e4 = *puVar4;
          uStack_e0 = puVar4[1];
          uStack_dc = puVar4[2];
          uStack_d8 = puVar4[3];
          uStack_d4 = *(undefined8 *)(puVar4 + 4);
          puVar4[4] = 0;
          puVar4[5] = 0xf;
          *(undefined *)puVar4 = 0;
          dStack_cc = *(double *)(iVar11 + iVar1);
          uStack_84 = 0xf00000000;
          uStack_94 = uStack_e4 & 0xffffff00;
          uStack_8._0_1_ = 0xd;
          uStack_90 = uStack_e0;
          uStack_8c = uStack_dc;
          uStack_88 = uStack_d8;
          if (puStack_28 == puStack_2c) {
            FUN_00603540(puStack_2c,&uStack_e4);
            uVar7 = uStack_d4._4_4_;
          }
          else {
            puStack_2c[4] = 0;
            *puStack_2c = uStack_e4;
            puStack_2c[1] = uStack_e0;
            puStack_2c[2] = uStack_dc;
            puStack_2c[3] = uStack_d8;
            uStack_e4 = uStack_e4 & 0xffffff00;
            *(undefined8 *)(puStack_2c + 4) = uStack_d4;
            *(double *)(puStack_2c + 6) = dStack_cc;
            puStack_2c = puStack_2c + 8;
            uVar7 = 0xf;
          }
          uStack_8._0_1_ = 0xc;
          if (0xf < uVar7) {
            uVar9 = uVar7 + 1;
            uVar8 = uStack_e4;
            if (0xfff < uVar9) {
              uVar8 = *(uint *)(uStack_e4 - 4);
              uVar9 = uVar7 + 0x24;
              if (0x1f < (uStack_e4 - uVar8) - 4) goto LAB_00647c98;
            }
            FUN_01674ea0(uVar8,uVar9);
          }
          uStack_8._0_1_ = 10;
          if (0xf < uStack_44._4_4_) {
            uVar8 = uStack_44._4_4_ + 1;
            uVar7 = uStack_54;
            if (0xfff < uVar8) {
              uVar7 = *(uint *)(uStack_54 - 4);
              uVar8 = uStack_44._4_4_ + 0x24;
              if (0x1f < (uStack_54 - uVar7) - 4) goto LAB_00647c98;
            }
            FUN_01674ea0(uVar7,uVar8);
          }
          uVar7 = (uint)uStack_24._4_4_;
          iVar1 = iStack_70;
        }
        uVar7 = uVar7 + 1;
        uStack_24 = (double)CONCAT44(uVar7,(undefined4)uStack_24);
        iVar11 = iVar11 + 0x10;
      } while (uVar7 < (uint)(iStack_6c - iVar1 >> 4));
    }
    fVar12 = (float10)FUN_008f7ba0();
    uStack_4c = 0;
    uStack_18 = (double)fVar12;
    uStack_48 = 0xf;
    uStack_5c = uStack_5c & 0xffffff00;
    FUN_005542c0("RCCUnthrottledWorldStepDtAverage",0x20);
    uVar7 = uStack_5c;
    uStack_44 = uStack_18;
    uStack_8._0_1_ = 0xe;
    if (puStack_28 == puStack_2c) {
      FUN_00603540(puStack_2c,&uStack_5c);
      uVar7 = uStack_48;
    }
    else {
      puStack_2c[4] = 0;
      uStack_5c = uStack_5c & 0xffffff00;
      *puStack_2c = uVar7;
      puStack_2c[1] = uStack_58;
      puStack_2c[2] = uStack_54;
      puStack_2c[3] = uStack_50;
      *(ulonglong *)(puStack_2c + 4) = CONCAT44(uStack_48,uStack_4c);
      *(double *)(puStack_2c + 6) = uStack_18;
      puStack_2c = puStack_2c + 8;
      uVar7 = 0xf;
    }
    uStack_8._0_1_ = 10;
    uVar13 = (undefined)uStack_8;
    uStack_8._0_1_ = 10;
    if (0xf < uVar7) {
      uVar9 = uVar7 + 1;
      uVar8 = uStack_5c;
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(uStack_5c - 4);
        uVar9 = uVar7 + 0x24;
        if (0x1f < (uStack_5c - uVar8) - 4) {
          uStack_8._0_1_ = uVar13;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    fVar12 = (float10)FUN_008f7ba0();
    uStack_18 = (double)fVar12;
    puVar4 = (uint *)FUN_01675640(&uStack_54,"RCCUnthrottledWorldStepDtAverage_Datacenter_%d",
                                  DAT_01d7a884);
    uStack_e4 = *puVar4;
    uStack_e0 = puVar4[1];
    uStack_dc = puVar4[2];
    uStack_d8 = puVar4[3];
    uStack_d4 = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    dStack_cc = uStack_18;
    uStack_8._0_1_ = 0x10;
    if (puStack_28 == puStack_2c) {
      FUN_00603540(puStack_2c,&uStack_e4);
      uVar7 = uStack_d4._4_4_;
    }
    else {
      puStack_2c[4] = 0;
      *puStack_2c = uStack_e4;
      puStack_2c[1] = uStack_e0;
      puStack_2c[2] = uStack_dc;
      puStack_2c[3] = uStack_d8;
      uStack_e4 = uStack_e4 & 0xffffff00;
      *(undefined8 *)(puStack_2c + 4) = uStack_d4;
      *(double *)(puStack_2c + 6) = uStack_18;
      puStack_2c = puStack_2c + 8;
      uVar7 = 0xf;
    }
    uStack_8._0_1_ = 0xf;
    uVar13 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xf;
    if (0xf < uVar7) {
      uVar9 = uVar7 + 1;
      uVar8 = uStack_e4;
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(uStack_e4 - 4);
        uVar9 = uVar7 + 0x24;
        if (0x1f < (uStack_e4 - uVar8) - 4) {
          uStack_8._0_1_ = uVar13;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_8._0_1_ = 10;
    uVar13 = (undefined)uStack_8;
    uStack_8._0_1_ = 10;
    if (0xf < uStack_44._4_4_) {
      uVar8 = uStack_44._4_4_ + 1;
      uVar7 = uStack_54;
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(uStack_54 - 4);
        uVar8 = uStack_44._4_4_ + 0x24;
        if (0x1f < (uStack_54 - uVar7) - 4) {
          uStack_8._0_1_ = uVar13;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    FUN_00874d70(&uStack_30,0);
    if (DAT_01d5bff8 != '\0') {
      fVar12 = (float10)FUN_008f7b80();
      uStack_18 = (double)fVar12;
      uStack_84 = 0xf00000000;
      uStack_94 = uStack_94 & 0xffffff00;
      FUN_005542c0("RCCUpdateBroadphaseDtAverage",0x1c);
      uStack_8._0_1_ = 0x11;
      FUN_00878cf0();
      uStack_8._0_1_ = 10;
      FUN_005507b0();
      fVar12 = (float10)FUN_008f7b80();
      uStack_18 = (double)fVar12;
      FUN_01675640(&uStack_54,"RCCUpdateBroadphaseDtAverage_Datacenter_%d",DAT_01d7a884);
      uStack_8._0_1_ = 0x12;
      FUN_00878cf0();
      uStack_8._0_1_ = 10;
      FUN_005507b0();
      fVar12 = (float10)FUN_008f7b60();
      uStack_18 = (double)fVar12;
      uStack_84 = 0xf00000000;
      uStack_94 = uStack_94 & 0xffffff00;
      FUN_005542c0("RCCStepContactsDtAverage",0x18);
      uStack_8._0_1_ = 0x13;
      FUN_00878cf0();
      uStack_8._0_1_ = 10;
      FUN_005507b0();
      fVar12 = (float10)FUN_008f7b60();
      uStack_18 = (double)fVar12;
      FUN_01675640(&uStack_54,"RCCStepContactsDtAverage_Datacenter_%d",DAT_01d7a884);
      uStack_8._0_1_ = 0x14;
      FUN_00878cf0();
      FUN_005507b0();
    }
    FUN_00612b00();
    uStack_8._0_1_ = 2;
    FUN_0056d3e0();
  }
  if (DAT_01d5c000 != '\0') {
    piVar3 = *(int **)(param_1 + 0x43c);
    uStack_24 = (double)CONCAT44((float)DAT_01d5bf64 / DAT_018ce320,(undefined4)uStack_24);
    uStack_64 = (double)CONCAT44((float)DAT_01d5bf6c / DAT_018ce320,(undefined4)uStack_64);
    uStack_18 = (double)CONCAT44((float)DAT_01d5bf74 / DAT_018ce320,(undefined4)uStack_18);
    uStack_9c = (double)CONCAT44(piVar3[1] - (int)piVar3,*piVar3 - (int)piVar3);
    FUN_009ee550(apppuStack_7c,&uStack_9c);
    uStack_8._0_1_ = 0x15;
    if ((double)uStack_24._4_4_ <= dStack_a4) {
      if (dStack_a4 < (double)uStack_64._4_4_) {
        FUN_009ee330(&uStack_54,(int)&uStack_64 + 4);
        uStack_8._0_1_ = 0x19;
        ppppuVar10 = apppuStack_7c;
        if (0xf < uStack_68) {
          ppppuVar10 = (undefined4 ****)apppuStack_7c[0];
        }
        uVar5 = FUN_00558ce0(auStack_3c,apppuStack_c4,&DAT_018c6ae4);
        uStack_8._0_1_ = 0x1a;
        puVar6 = (undefined4 *)FUN_00558c20(&uStack_94,uVar5,&uStack_54);
        uStack_8._0_1_ = 0x1b;
        goto LAB_00647bfd;
      }
      if (dStack_a4 < (double)uStack_18._4_4_) {
        FUN_009ee330(&uStack_54,(int)&uStack_18 + 4);
        uStack_8._0_1_ = 0x1c;
        ppppuVar10 = apppuStack_7c;
        if (0xf < uStack_68) {
          ppppuVar10 = (undefined4 ****)apppuStack_7c[0];
        }
        uVar5 = FUN_00558ce0(auStack_3c,apppuStack_c4,&DAT_018c6ae4);
        uStack_8._0_1_ = 0x1d;
        puVar6 = (undefined4 *)FUN_00558c20(&uStack_94,uVar5,&uStack_54);
        uStack_8._0_1_ = 0x1e;
        goto LAB_00647bfd;
      }
    }
    else {
      FUN_009ee330(&uStack_54,(int)&uStack_24 + 4);
      uStack_8._0_1_ = 0x16;
      ppppuVar10 = apppuStack_7c;
      if (0xf < uStack_68) {
        ppppuVar10 = (undefined4 ****)apppuStack_7c[0];
      }
      uVar5 = FUN_00558ce0(auStack_3c,apppuStack_c4,&DAT_018c6ae4);
      uStack_8._0_1_ = 0x17;
      puVar6 = (undefined4 *)FUN_00558c20(&uStack_94,uVar5,&uStack_54);
      uStack_8._0_1_ = 0x18;
LAB_00647bfd:
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_0087c450(&DAT_018c5f98,puVar6,ppppuVar10,0,0,0);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
    }
    FUN_005507b0();
  }
  iVar1 = FUN_005507b0();
LAB_00647c4b:
  if (piStack_a8 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_a8 + 1;
    iVar11 = *piVar3;
    iVar1 = *piVar3;
    *piVar3 = iVar11 + -1;
    UNLOCK();
    if (iVar11 + -1 == 0) {
      (**(code **)*piStack_a8)();
      LOCK();
      piVar3 = piStack_a8 + 2;
      iVar11 = *piVar3;
      iVar1 = *piVar3;
      *piVar3 = iVar11 + -1;
      UNLOCK();
      if (iVar11 + -1 == 0) {
        iVar1 = (**(code **)(*piStack_a8 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 2;
    iVar11 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar11 == 1) {
      iVar1 = (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 7329 ; VA 0x00647cb0 ; FUN_00647cb0 */

void FUN_00647cb0(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  float10 fVar5;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 0;
    uVar2 = FUN_008fba30();
    FUN_0151f9c0("PlayerCount",uVar2);
    piVar1 = *(int **)(param_1 + 0x43c);
    FUN_0151fbb0("PlaceId",*piVar1 - (int)piVar1,piVar1[1] - (int)piVar1);
    FUN_0151f9c0("DataCenterId",*(undefined4 *)(param_1 + 0x44c));
    FUN_0151fbb0("UniverseId",*(undefined4 *)(param_1 + 0x440),*(undefined4 *)(param_1 + 0x444));
    if (*(int *)(param_1 + 0x1b8) != 0) {
      FUN_0151fcf0("StreamingEnabled",*(undefined *)(*(int *)(param_1 + 0x1b8) + 0x300));
    }
    if (param_2 != 0) {
      fVar5 = (float10)FUN_009994d0();
      FUN_0151fb00("InstantHeartbeatRate",(double)fVar5);
      fVar5 = (float10)FUN_00999eb0();
      FUN_0151fb00("SmoothHeartbeatRate",(double)fVar5);
      fVar5 = (float10)FUN_00999e90();
      FUN_0151fb00("PhysicsSmoothFPS",(double)fVar5);
    }
    FUN_0151f950("GameID",&DAT_01d79c68);
    uVar2 = DAT_01ead6ac;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("ReportRCCStat",0xd);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01520d20(auStack_28,uVar2,0);
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      uVar3 = auStack_28[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_28[0] - 4);
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7330 ; VA 0x00647e60 ; FUN_00647e60 */

void FUN_00647e60(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a10b8;
  pvStack_10 = ExceptionList;
  puVar2 = &DAT_01d7a8a0;
  if (0xf < DAT_01d7a8b4) {
    puVar2 = DAT_01d7a8a0;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675640(aiStack_40,"RakNetServerStartupFail_%s",puVar2);
  uStack_8 = 0;
  FUN_008783f0(uVar1,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    iVar3 = aiStack_40[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_40[0] + -4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  puVar2 = &DAT_01d7a8a0;
  if (0xf < DAT_01d7a8b4) {
    puVar2 = DAT_01d7a8a0;
  }
  uVar1 = FUN_01675640(aiStack_40,"RakNetServerStartupFail_%s_Error_%d",puVar2,param_1);
  uStack_8 = 1;
  FUN_008783f0(uVar1,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    iVar3 = aiStack_40[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_40[0] + -4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  puVar2 = &DAT_01d7a8a0;
  if (0xf < DAT_01d7a8b4) {
    puVar2 = DAT_01d7a8a0;
  }
  uVar1 = FUN_01675640(aiStack_40,"RakNetServerStartupFail_%s_Datacenter_%d",puVar2,DAT_01d7a884);
  uStack_8 = 2;
  FUN_008783f0(uVar1,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    iVar3 = aiStack_40[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_40[0] + -4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  if (DAT_01ead6c8 != 0) {
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 3;
    FUN_0151f9c0("ErrorCode",param_1);
    FUN_0151f9c0(&DAT_018cee78,param_2);
    FUN_0151f9c0("Datacenter",DAT_01d7a884);
    iVar3 = DAT_01ead6c8;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("ServerRakNetStartupFailure",0x1a);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_01520d20(auStack_28,iVar3,0);
    if (0xf < uStack_14) {
      uVar5 = uStack_14 + 1;
      uVar4 = auStack_28[0];
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(auStack_28[0] - 4);
        uVar5 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7331 ; VA 0x006480d0 ; FUN_006480d0 */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 ******* FUN_006480d0(double *param_1,int *param_2)

{
  int *piVar1;
  undefined4 *****pppppuVar2;
  undefined4 ****ppppuVar3;
  undefined4 ***pppuVar4;
  undefined4 ***pppuVar5;
  ulonglong uVar6;
  char *pcVar7;
  int *piVar8;
  undefined4 *******pppppppuVar9;
  char cVar10;
  undefined4 *******pppppppuVar11;
  undefined **ppuVar12;
  int iVar13;
  uint uVar14;
  double *pdVar15;
  undefined4 *puVar16;
  int *piVar17;
  undefined4 uVar18;
  undefined3 uVar20;
  int iVar19;
  undefined4 ******ppppppuVar21;
  undefined4 ****ppppuVar22;
  undefined **ppuVar23;
  undefined4 ******ppppppuVar24;
  float10 fVar25;
  float fVar26;
  double dVar27;
  undefined8 uVar29;
  undefined auVar28 [16];
  undefined4 uStack_850;
  char *pcStack_84c;
  undefined4 *puStack_848;
  uint uStack_844;
  undefined1 *puStack_840;
  char *pcStack_83c;
  undefined *puStack_838;
  undefined4 *******pppppppuStack_834;
  double *pdStack_830;
  undefined8 uStack_82c;
  undefined4 *******pppppppuStack_824;
  undefined8 uStack_820;
  double adStack_810 [4];
  undefined auStack_7f0 [32];
  undefined auStack_7d0 [32];
  undefined4 auStack_7b0 [6];
  undefined auStack_798 [24];
  undefined auStack_780 [24];
  undefined auStack_768 [24];
  undefined auStack_750 [24];
  undefined4 auStack_738 [6];
  undefined auStack_720 [24];
  undefined auStack_708 [32];
  undefined auStack_6e8 [32];
  undefined auStack_6c8 [32];
  undefined auStack_6a8 [32];
  undefined auStack_688 [32];
  undefined auStack_668 [32];
  undefined auStack_648 [32];
  undefined auStack_628 [32];
  undefined auStack_608 [32];
  undefined auStack_5e8 [32];
  undefined auStack_5c8 [32];
  undefined auStack_5a8 [32];
  undefined auStack_588 [32];
  undefined auStack_568 [32];
  undefined auStack_548 [32];
  undefined auStack_528 [24];
  double dStack_510;
  undefined auStack_508 [24];
  undefined auStack_4f0 [8];
  undefined auStack_4e8 [8];
  undefined auStack_4e0 [8];
  undefined auStack_4d8 [8];
  undefined auStack_4d0 [8];
  undefined4 uStack_4c8;
  undefined4 uStack_4c4;
  undefined4 uStack_4c0;
  undefined4 uStack_4bc;
  undefined8 uStack_4b8;
  double dStack_4b0;
  undefined auStack_4a8 [24];
  int iStack_490;
  uint uStack_48c;
  undefined4 uStack_488;
  undefined4 uStack_484;
  undefined4 uStack_480;
  undefined8 uStack_47c;
  double dStack_474;
  char *apcStack_46c [2];
  double dStack_464;
  char *apcStack_45c [2];
  double dStack_454;
  char *apcStack_44c [2];
  double dStack_444;
  char *apcStack_43c [2];
  double dStack_434;
  char *apcStack_42c [2];
  double dStack_424;
  char *apcStack_41c [2];
  double dStack_414;
  char *apcStack_40c [2];
  double dStack_404;
  char *apcStack_3fc [2];
  double dStack_3f4;
  char *apcStack_3ec [2];
  double dStack_3e4;
  char *apcStack_3dc [2];
  double dStack_3d4;
  undefined auStack_3cc [16];
  undefined4 uStack_3bc;
  undefined4 uStack_3b8;
  double dStack_3b4;
  undefined auStack_3ac [16];
  undefined4 uStack_39c;
  undefined4 uStack_398;
  double dStack_394;
  undefined auStack_38c [16];
  undefined4 uStack_37c;
  undefined4 uStack_378;
  double dStack_374;
  undefined auStack_36c [16];
  undefined4 uStack_35c;
  undefined4 uStack_358;
  double dStack_354;
  undefined auStack_34c [16];
  undefined4 uStack_33c;
  undefined4 uStack_338;
  double dStack_334;
  undefined auStack_32c [16];
  undefined4 uStack_31c;
  undefined4 uStack_318;
  double dStack_314;
  undefined auStack_30c [16];
  undefined4 uStack_2fc;
  undefined4 uStack_2f8;
  double dStack_2f4;
  undefined auStack_2ec [16];
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined auStack_2d4 [16];
  undefined4 uStack_2c4;
  undefined4 uStack_2c0;
  undefined auStack_2bc [16];
  undefined4 uStack_2ac;
  undefined4 uStack_2a8;
  undefined auStack_2a4 [16];
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined auStack_28c [16];
  undefined4 uStack_27c;
  undefined4 uStack_278;
  undefined auStack_274 [16];
  undefined4 uStack_264;
  undefined4 uStack_260;
  undefined auStack_25c [16];
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 *******apppppppuStack_244 [4];
  int iStack_234;
  uint uStack_230;
  undefined auStack_22c [16];
  undefined4 uStack_21c;
  undefined4 uStack_218;
  undefined auStack_214 [16];
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined auStack_1fc [16];
  undefined4 uStack_1ec;
  undefined4 uStack_1e8;
  undefined auStack_1e4 [4];
  undefined *puStack_1e0;
  int iStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  int iStack_1d0;
  undefined uStack_1cc;
  undefined *puStack_1c8;
  int iStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  int iStack_1b8;
  double dStack_1b4;
  double dStack_1ac;
  double dStack_1a4;
  uint uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  double dStack_184;
  double dStack_17c;
  double dStack_174;
  double dStack_16c;
  double dStack_164;
  double dStack_15c;
  double dStack_154;
  double dStack_14c;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  double dStack_138;
  double dStack_130;
  double dStack_128;
  double dStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  int iStack_10c;
  int *piStack_108;
  double dStack_104;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined8 uStack_f0;
  double dStack_e8;
  double dStack_e0;
  double dStack_d8;
  double dStack_d0;
  double dStack_c8;
  double dStack_c0;
  double dStack_b8;
  double dStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  double dStack_98;
  undefined8 uStack_90;
  undefined8 uStack_88;
  double dStack_80;
  double dStack_78;
  double dStack_70;
  double dStack_68;
  double dStack_60;
  undefined4 ******ppppppuStack_58;
  undefined4 ****ppppuStack_54;
  undefined4 *******pppppppuStack_50;
  undefined4 *******pppppppuStack_4c;
  undefined4 uStack_48;
  undefined **ppuStack_44;
  undefined **ppuStack_40;
  int iStack_3c;
  undefined4 *******pppppppuStack_38;
  undefined4 uStack_34;
  undefined4 ****ppppuStack_30;
  undefined4 ****ppppuStack_2c;
  undefined4 ******ppppppuStack_28;
  undefined4 ****ppppuStack_24;
  undefined4 *****pppppuStack_20;
  double dStack_1c;
  undefined4 ******ppppppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1351;
  pvStack_10 = ExceptionList;
  pppppppuStack_4c = (undefined4 *******)0x0;
  pppppppuStack_38 = (undefined4 *******)0x0;
  uStack_8 = 0;
  uStack_820._4_4_ = (undefined4 ******)&iStack_10c;
  uStack_820._0_4_ = (undefined **)0x64810a;
  ExceptionList = &pvStack_10;
  pppppppuVar11 = (undefined4 *******)FUN_00587490();
  uStack_8._0_1_ = 1;
  if (iStack_10c != 0) {
    uStack_820._4_4_ = (undefined4 ******)iStack_10c;
    uStack_820._0_4_ = (undefined **)0x648125;
    pppppppuVar11 = (undefined4 *******)FUN_008f7870();
    pppppppuStack_50 = pppppppuVar11;
    if (pppppppuVar11 != (undefined4 *******)0x0) {
      uStack_90 = 0.0;
      uStack_a8 = 0.0;
      dStack_60 = 0.0;
      uStack_a0 = 0.0;
      uStack_88 = 0.0;
      dStack_70 = 0.0;
      iStack_3c = 0;
      dStack_120 = 0.0;
      dStack_138 = 0.0;
      dStack_15c = 0.0;
      dStack_130 = 0.0;
      dStack_164 = 0.0;
      dStack_128 = 0.0;
      dStack_80 = 0.0;
      dStack_14c = 0.0;
      dStack_78 = 0.0;
      dStack_154 = 0.0;
      uStack_34 = 0;
      ppppuStack_30 = (undefined4 ****)0x0;
      ppppuStack_2c = (undefined4 ****)0x0;
      uStack_820._4_4_ = (undefined4 ******)&ppppuStack_54;
      uStack_1cc = 0;
      uStack_820._0_4_ = &boost::lock_error::vftable_meta_ptr;
      pppppppuStack_824 = (undefined4 *******)&DAT_018be100;
      ppppuStack_54 = (undefined4 ****)&DAT_0000000b;
      uStack_82c = (double)CONCAT44(0x6481d9,(undefined4)uStack_82c);
      ppuVar12 = (undefined **)FUN_00563d40();
      ppuVar23 = ppuVar12 + -1;
      if (ppuVar12 != &boost::lock_error::vftable_meta_ptr) {
        ppuVar23 = ppuVar12;
      }
      puStack_1c8 = *ppuVar23;
      iStack_1c4 = 0;
      uStack_1c0 = 0x3f800000;
      uStack_1bc = 0;
      iStack_1b8 = 0;
      ppppppuStack_14 = (undefined4 ******)(iStack_10c + 0x2c);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      pppppuVar2 = *ppppppuStack_14;
      auVar28 = ZEXT816(0);
      dStack_17c = 0.0;
      dStack_104 = 0.0;
      dStack_174 = 0.0;
      dStack_16c = 0.0;
      if (pppppuVar2 != (undefined4 *****)0x0) {
        ppppppuVar24 = (undefined4 ******)pppppuVar2[1];
        ppppppuVar21 = (undefined4 ******)*pppppuVar2;
        ppppppuStack_58 = ppppppuVar24;
        ppppppuStack_28 = ppppppuVar21;
        if (ppppppuVar21 != ppppppuVar24) {
          do {
            pppppuStack_20 = *ppppppuVar21;
            if (pppppuStack_20 != (undefined4 *****)0x0) {
              ppppuStack_54 = pppppuStack_20[3];
              uStack_820._4_4_ = (undefined4 ******)0x64826d;
              ppppppuStack_28 = ppppppuVar21;
              iVar13 = FUN_005ee350();
              if ((uint)*(ushort *)(ppppuStack_54 + 0x76) - (uint)*(ushort *)(iVar13 + 0x1d8) <=
                  (uint)*(ushort *)(iVar13 + 0x1da)) {
                dStack_98 = *(double *)(pppppuStack_20 + 0x202) * DAT_018c0d70;
                uStack_820._4_4_ = (undefined4 ******)0x6482ba;
                dStack_1c = dStack_98;
                fVar25 = (float10)FUN_006b0630();
                dStack_1ac = (double)fVar25;
                uStack_820._4_4_ = (undefined4 ******)0x6482ce;
                fVar25 = (float10)FUN_006b0630();
                dStack_1a4 = (double)fVar25;
                uStack_820._4_4_ = (undefined4 ******)0x6482e2;
                fVar25 = (float10)FUN_006b0630();
                dStack_1b4 = (double)fVar25;
                uStack_820._4_4_ = (undefined4 ******)0x6482f6;
                fVar25 = (float10)FUN_006b0630();
                dStack_184 = (double)fVar25;
                if (pppppuStack_20[0x1b] != (undefined4 ****)0x0) {
                  uStack_820._4_4_ = (undefined4 ******)0x64830e;
                  FUN_006b0630();
                }
                dStack_120 = dStack_98 + dStack_120;
                dStack_d8 = dStack_1ac;
                dStack_15c = dStack_1ac + dStack_15c;
                dStack_e0 = dStack_1a4;
                dStack_164 = dStack_1a4 + dStack_164;
                dStack_e8 = dStack_1b4;
                dStack_80 = dStack_1b4 + dStack_80;
                uStack_f0 = dStack_184;
                auVar28._0_8_ = dStack_184 + dStack_78;
                auVar28._8_8_ = 0;
                uStack_820._4_4_ = (undefined4 ******)0x6483a1;
                dStack_78 = auVar28._0_8_;
                uVar14 = FUN_01679ce0();
                uVar6 = (ulonglong)DAT_01d5a428;
                if ((int)((ulonglong)uVar14 % uVar6) == 0) {
                  ppppuStack_54 = ppppuStack_30;
                  if (ppppuStack_2c == ppppuStack_30) {
                    uStack_820._4_4_ = (undefined4 ******)&dStack_1c;
                    uStack_820._0_4_ = (undefined **)0x18cfb2c;
                    pppppppuStack_824 = (undefined4 *******)ppppuStack_30;
                    uStack_82c = (double)CONCAT44(0x648406,(undefined4)uStack_82c);
                    FUN_0063d860();
                    dStack_98 = dStack_1c;
                  }
                  else {
                    ppppuStack_30[4] = (undefined4 ***)0x0;
                    uStack_820._4_4_ = (undefined4 ******)0x2c;
                    ppppuStack_30[4] = (undefined4 ***)0x0;
                    ppppuStack_30[5] = (undefined4 ***)0xf;
                    uStack_820._0_4_ = (undefined **)0x18cfb2c;
                    *(char *)ppppuStack_30 = (char)((ulonglong)uVar14 % uVar6);
                    pppppppuStack_824 = (undefined4 *******)0x6483d9;
                    FUN_005542c0();
                    *(double *)(ppppuStack_54 + 6) = dStack_98;
                    ppppuStack_30 = ppppuStack_30 + 8;
                  }
                  ppppuStack_24 = ppppuStack_30;
                  if (ppppuStack_2c == ppppuStack_30) {
                    uStack_820._4_4_ = (undefined4 ******)&dStack_1ac;
                    uStack_820._0_4_ = (undefined **)0x18cfb5c;
                    uStack_82c = (double)CONCAT44(0x648474,(undefined4)uStack_82c);
                    pppppppuStack_824 = (undefined4 *******)ppppuStack_30;
                    FUN_0063d860();
                    dStack_d8 = dStack_1ac;
                  }
                  else {
                    ppppuStack_30[4] = (undefined4 ***)0x0;
                    uStack_820._4_4_ = (undefined4 ******)0x31;
                    ppppuStack_30[4] = (undefined4 ***)0x0;
                    ppppuStack_30[5] = (undefined4 ***)0xf;
                    uStack_820._0_4_ = (undefined **)0x18cfb5c;
                    *(undefined *)ppppuStack_30 = 0;
                    pppppppuStack_824 = (undefined4 *******)0x648444;
                    FUN_005542c0();
                    *(double *)(ppppuStack_24 + 6) = dStack_d8;
                    ppppuStack_30 = ppppuStack_30 + 8;
                  }
                  ppppuStack_24 = ppppuStack_30;
                  if (ppppuStack_2c == ppppuStack_30) {
                    uStack_820._4_4_ = (undefined4 ******)&dStack_1a4;
                    uStack_820._0_4_ = (undefined **)0x18cfb90;
                    uStack_82c = (double)CONCAT44(0x6484e5,(undefined4)uStack_82c);
                    pppppppuStack_824 = (undefined4 *******)ppppuStack_30;
                    FUN_0063d860();
                    dStack_e0 = dStack_1a4;
                  }
                  else {
                    ppppuStack_30[4] = (undefined4 ***)0x0;
                    uStack_820._4_4_ = (undefined4 ******)0x34;
                    ppppuStack_30[4] = (undefined4 ***)0x0;
                    ppppuStack_30[5] = (undefined4 ***)0xf;
                    uStack_820._0_4_ = (undefined **)0x18cfb90;
                    *(undefined *)ppppuStack_30 = 0;
                    pppppppuStack_824 = (undefined4 *******)0x6484b5;
                    FUN_005542c0();
                    *(double *)(ppppuStack_24 + 6) = dStack_e0;
                    ppppuStack_30 = ppppuStack_30 + 8;
                  }
                  ppppuStack_24 = ppppuStack_30;
                  if (ppppuStack_2c == ppppuStack_30) {
                    uStack_820._4_4_ = (undefined4 ******)&dStack_1b4;
                    uStack_820._0_4_ = (undefined **)0x18cfbc8;
                    uStack_82c = (double)CONCAT44(0x648556,(undefined4)uStack_82c);
                    pppppppuStack_824 = (undefined4 *******)ppppuStack_30;
                    FUN_0063d860();
                    dStack_e8 = dStack_1b4;
                  }
                  else {
                    ppppuStack_30[4] = (undefined4 ***)0x0;
                    uStack_820._4_4_ = (undefined4 ******)0x3b;
                    ppppuStack_30[4] = (undefined4 ***)0x0;
                    ppppuStack_30[5] = (undefined4 ***)0xf;
                    uStack_820._0_4_ = (undefined **)0x18cfbc8;
                    *(undefined *)ppppuStack_30 = 0;
                    pppppppuStack_824 = (undefined4 *******)0x648526;
                    FUN_005542c0();
                    *(double *)(ppppuStack_24 + 6) = dStack_e8;
                    ppppuStack_30 = ppppuStack_30 + 8;
                  }
                  ppppuStack_24 = ppppuStack_30;
                  if (ppppuStack_2c == ppppuStack_30) {
                    uStack_820._4_4_ = (undefined4 ******)&dStack_184;
                    uStack_820._0_4_ = (undefined **)0x18cfc04;
                    uStack_82c = (double)CONCAT44(0x6485c2,(undefined4)uStack_82c);
                    pppppppuStack_824 = (undefined4 *******)ppppuStack_30;
                    FUN_0063d860();
                    auVar28._8_8_ = 0;
                    auVar28._0_8_ = dStack_184;
                    uStack_f0 = dStack_184;
                  }
                  else {
                    ppppuStack_30[4] = (undefined4 ***)0x0;
                    uStack_820._4_4_ = (undefined4 ******)0x34;
                    ppppuStack_30[4] = (undefined4 ***)0x0;
                    ppppuStack_30[5] = (undefined4 ***)0xf;
                    uStack_820._0_4_ = (undefined **)0x18cfc04;
                    *(undefined *)ppppuStack_30 = 0;
                    pppppppuStack_824 = (undefined4 *******)0x648597;
                    FUN_005542c0();
                    auVar28._8_8_ = 0;
                    auVar28._0_8_ = uStack_f0;
                    *(double *)(ppppuStack_24 + 6) = uStack_f0;
                    ppppuStack_30 = ppppuStack_30 + 8;
                  }
                }
                dVar27 = auVar28._0_8_;
                if (DAT_01d5a080 != '\0') {
                  uStack_820._4_4_ = (undefined4 ******)0x6485ed;
                  FUN_006b05f0();
                  uStack_820._4_4_ = (undefined4 ******)0x6485f4;
                  FUN_016f3fe0();
                  dStack_104 = dVar27 + dStack_104;
                  if (dStack_16c < *(double *)(pppppuStack_20 + 0x5e4)) {
                    dStack_16c = *(double *)(pppppuStack_20 + 0x5e4);
                  }
                  auVar28 = ZEXT816(0);
                  pppppuStack_20[0x5e4] = (undefined4 ****)0x0;
                  pppppuStack_20[0x5e5] = (undefined4 ****)0x0;
                  iVar13 = 0x32;
                  do {
                    uStack_820._4_4_ = (undefined4 ******)0x64864b;
                    FUN_006b05f0();
                    uStack_820._4_4_ = (undefined4 ******)0x648652;
                    FUN_016f3fe0();
                    uVar29 = auVar28._8_8_;
                    dVar27 = auVar28._0_8_ + dStack_174;
                    uStack_820._4_4_ = (undefined4 ******)0x648669;
                    dStack_174 = dVar27;
                    FUN_006b05f0();
                    uStack_820._4_4_ = (undefined4 ******)0x648670;
                    FUN_016f3fe0();
                    auVar28._0_8_ = dVar27 + dStack_17c;
                    auVar28._8_8_ = uVar29;
                    iVar13 = iVar13 + -1;
                    ppppppuVar21 = ppppppuStack_28;
                    ppppppuVar24 = ppppppuStack_58;
                    dStack_17c = auVar28._0_8_;
                  } while (iVar13 != 0);
                }
                uStack_820._4_4_ = (undefined4 ******)0x64869b;
                ppppuStack_54 = (undefined4 ****)(*(code *)(*pppppuStack_20)[0x2e])();
                if (ppppuStack_54 != (undefined4 ****)0x0) {
                  uStack_820._4_4_ = (undefined4 ******)0x6486ab;
                  FUN_006a6920();
                  uStack_820._4_4_ = (undefined4 ******)0x6486c1;
                  FUN_016f3fe0();
                  auVar28._0_4_ = (float)auVar28._0_8_ / DAT_018d0938;
                  if (300 < (int)auVar28._0_4_) {
                    uStack_820._4_4_ = (undefined4 ******)auStack_508;
                    uStack_820._0_4_ = (undefined **)0x6486eb;
                    FUN_00927520();
                    uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    uStack_820._4_4_ = (undefined4 ******)auStack_4f0;
                    uStack_90 = *(double *)(pppppuStack_20 + 0x202) + uStack_90;
                    uStack_820._0_4_ = (undefined **)0x648716;
                    pdVar15 = (double *)FUN_016827a0();
                    dStack_1c = *pdVar15 - *(double *)(pppppuStack_20 + 0x206);
                    dStack_b0 = *(double *)(pppppuStack_20 + 0x20e);
                    if (((pppppuStack_20[0x214] == (undefined4 ****)0x0) ||
                        (*(char *)pppppuStack_20[0x214] == '\0')) &&
                       (dStack_b0 + dStack_b0 < dStack_1c)) {
                      dStack_b0 = dStack_1c;
                    }
                    if (dStack_b0 <= 0.0) {
                      dVar27 = 0.0;
                    }
                    else {
                      dVar27 = DAT_018c0d60 / dStack_b0;
                    }
                    uStack_820._4_4_ = (undefined4 ******)auStack_4d0;
                    uStack_a8 = *(double *)(pppppuStack_20 + 0x224) * dVar27 + uStack_a8;
                    uStack_820._0_4_ = (undefined **)0x6487ba;
                    pdVar15 = (double *)FUN_016827a0();
                    dStack_1c = *pdVar15 - *(double *)(pppppuStack_20 + 0x274);
                    dStack_b8 = *(double *)(pppppuStack_20 + 0x27c);
                    if (((pppppuStack_20[0x282] == (undefined4 ****)0x0) ||
                        (*(char *)pppppuStack_20[0x282] == '\0')) &&
                       (dStack_b8 + dStack_b8 < dStack_1c)) {
                      dStack_b8 = dStack_1c;
                    }
                    if (dStack_b8 <= 0.0) {
                      dVar27 = 0.0;
                    }
                    else {
                      dVar27 = DAT_018c0d60 / dStack_b8;
                    }
                    uStack_820._4_4_ = (undefined4 ******)auStack_4d8;
                    dStack_60 = *(double *)(pppppuStack_20 + 0x2a2) * dVar27 + dStack_60;
                    uStack_820._0_4_ = (undefined **)0x648858;
                    pdVar15 = (double *)FUN_016827a0();
                    dStack_1c = *pdVar15 - *(double *)(pppppuStack_20 + 0x2b2);
                    dStack_c0 = *(double *)(pppppuStack_20 + 0x2ba);
                    if (((pppppuStack_20[0x2c0] == (undefined4 ****)0x0) ||
                        (*(char *)pppppuStack_20[0x2c0] == '\0')) &&
                       (dStack_c0 + dStack_c0 < dStack_1c)) {
                      dStack_c0 = dStack_1c;
                    }
                    if (dStack_c0 <= 0.0) {
                      dVar27 = 0.0;
                    }
                    else {
                      dVar27 = DAT_018c0d60 / dStack_c0;
                    }
                    uStack_820._4_4_ = (undefined4 ******)auStack_4e8;
                    uStack_a0 = *(double *)(pppppuStack_20 + 0x2c6) * dVar27 + uStack_a0;
                    uStack_820._0_4_ = (undefined **)0x6488fc;
                    pdVar15 = (double *)FUN_016827a0();
                    dStack_1c = *pdVar15 - *(double *)(pppppuStack_20 + 0x240);
                    dStack_c8 = *(double *)(pppppuStack_20 + 0x248);
                    if (((pppppuStack_20[0x24e] == (undefined4 ****)0x0) ||
                        (*(char *)pppppuStack_20[0x24e] == '\0')) &&
                       (dStack_c8 + dStack_c8 < dStack_1c)) {
                      dStack_c8 = dStack_1c;
                    }
                    if (dStack_c8 <= 0.0) {
                      dVar27 = 0.0;
                    }
                    else {
                      dVar27 = DAT_018c0d60 / dStack_c8;
                    }
                    uStack_88 = *(double *)(pppppuStack_20 + 0x254) * dVar27 + uStack_88;
                    uStack_820._4_4_ = (undefined4 ******)0x64899f;
                    puVar16 = (undefined4 *)FUN_00564080();
                    ppppuStack_24 = (undefined4 ****)*puVar16;
                    if (ppppuStack_24 != (undefined4 ****)0x0) {
                      uStack_820._4_4_ = (undefined4 ******)auStack_4e0;
                      uStack_820._0_4_ = (undefined **)0x6489b8;
                      pdVar15 = (double *)FUN_016827a0();
                      dStack_1c = *pdVar15 - *(double *)(ppppuStack_24 + 0x82);
                      dStack_d0 = *(double *)(ppppuStack_24 + 0x8a);
                      if (((ppppuStack_24[0x90] == (undefined4 ***)0x0) ||
                          (*(char *)ppppuStack_24[0x90] == '\0')) &&
                         (dStack_d0 + dStack_d0 < dStack_1c)) {
                        dStack_d0 = dStack_1c;
                      }
                      if (dStack_d0 <= 0.0) {
                        dVar27 = 0.0;
                      }
                      else {
                        dVar27 = DAT_018c0d60 / dStack_d0;
                      }
                      dStack_70 = *(double *)(ppppuStack_24 + 0x96) * dVar27 + dStack_70;
                    }
                    uStack_820._4_4_ = (undefined4 ******)auStack_508;
                    dStack_138 = dStack_98 + dStack_138;
                    iStack_3c = iStack_3c + 1;
                    dStack_130 = dStack_d8 + dStack_130;
                    dStack_128 = dStack_e0 + dStack_128;
                    dStack_14c = dStack_e8 + dStack_14c;
                    dStack_154 = uStack_f0 + dStack_154;
                    uStack_820._0_4_ = (undefined **)0x648ad7;
                    iVar13 = FUN_00641610();
                    uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    fVar26 = *(float *)(iVar13 + 0x18) + (float)pppppuStack_20[0x38e];
                    auVar28 = ZEXT416((uint)fVar26);
                    *(int *)(iVar13 + 0x1c) = *(int *)(iVar13 + 0x1c) + 1;
                    *(float *)(iVar13 + 0x18) = fVar26;
                    uStack_820._4_4_ = (undefined4 ******)0x648afe;
                    FUN_005507b0();
                  }
                }
              }
            }
            ppppppuVar21 = ppppppuVar21 + 2;
          } while (ppppppuVar21 != ppppppuVar24);
          iVar13 = iStack_3c;
          ppppppuStack_28 = ppppppuVar21;
          if ((NAN(uStack_90) || NAN(_PTR_018c6f48)) == (uStack_90 == _PTR_018c6f48)) {
            uStack_118 = 0;
            uStack_114 = 0;
            uStack_110 = 0;
            uStack_820._4_4_ = (undefined4 ******)0x19;
            uStack_820._0_4_ = (undefined **)0x18cfc3c;
            uStack_8._0_1_ = 5;
            uStack_37c = 0;
            uStack_378 = 0xf;
            auStack_38c[0] = 0;
            pppppppuStack_824 = (undefined4 *******)0x648b75;
            FUN_005542c0();
            dStack_374 = dStack_70;
            uStack_820._4_4_ = (undefined4 ******)auStack_38c;
            uStack_8._0_1_ = 6;
            uStack_820._0_4_ = (undefined **)0x648b98;
            FUN_00625cd0();
            uStack_8._0_1_ = 5;
            uStack_820._4_4_ = (undefined4 ******)0x648ba7;
            FUN_005507b0();
            iVar13 = iStack_3c;
            uStack_820._4_4_ = (undefined4 ******)0x22;
            uStack_820._0_4_ = (undefined **)0x18cfc58;
            uStack_39c = 0;
            uStack_398 = 0xf;
            auStack_3ac[0] = 0;
            dStack_1c = dStack_70 / (double)iStack_3c;
            pppppppuStack_824 = (undefined4 *******)0x648bed;
            FUN_005542c0();
            dStack_394 = dStack_1c;
            uStack_820._4_4_ = (undefined4 ******)auStack_3ac;
            uStack_8._0_1_ = 7;
            uStack_820._0_4_ = (undefined **)0x648c10;
            FUN_00625cd0();
            uStack_8._0_1_ = 5;
            uStack_820._4_4_ = (undefined4 ******)0x648c1f;
            FUN_005507b0();
            uStack_820._4_4_ = (undefined4 ******)0x1e;
            uStack_820._0_4_ = (undefined **)0x18cfc7c;
            uStack_31c = 0;
            uStack_318 = 0xf;
            auStack_32c[0] = 0;
            dStack_60 = dStack_60 + uStack_a8 + uStack_a0 + uStack_88 + dStack_70;
            pppppppuStack_824 = (undefined4 *******)0x648c73;
            FUN_005542c0();
            dStack_314 = dStack_60;
            uStack_820._4_4_ = (undefined4 ******)auStack_32c;
            uStack_8._0_1_ = 8;
            uStack_820._0_4_ = (undefined **)0x648c96;
            FUN_00625cd0();
            uStack_8._0_1_ = 5;
            uStack_820._4_4_ = (undefined4 ******)0x648ca5;
            FUN_005507b0();
            auVar28._0_8_ = (double)iVar13;
            auVar28._8_8_ = 0;
            uStack_820._4_4_ = (undefined4 ******)0x27;
            uStack_35c = 0;
            uStack_358 = 0xf;
            auStack_36c[0] = 0;
            uStack_820._0_4_ = (undefined **)0x18cfc9c;
            dStack_60 = dStack_60 / auVar28._0_8_;
            pppppppuStack_824 = (undefined4 *******)0x648ce8;
            FUN_005542c0();
            dStack_354 = dStack_60;
            uStack_820._4_4_ = (undefined4 ******)auStack_36c;
            uStack_8._0_1_ = 9;
            uStack_820._0_4_ = (undefined **)0x648d0b;
            FUN_00625cd0();
            uStack_8._0_1_ = 5;
            uStack_820._4_4_ = (undefined4 ******)0x648d1a;
            FUN_005507b0();
            uStack_820._0_4_ = (undefined **)&uStack_118;
            uStack_820._4_4_ = (undefined4 ******)0x0;
            pppppppuStack_824 = (undefined4 *******)0x648d28;
            FUN_00874d70();
            uStack_8 = CONCAT31(uStack_8._1_3_,3);
            uStack_820._4_4_ = (undefined4 ******)0x648d3a;
            FUN_0056d3e0();
          }
          ppppuVar3 = ppppuStack_30;
          if (0 < iVar13) {
            if (ppppuStack_2c == ppppuStack_30) {
              uStack_820._4_4_ = (undefined4 ******)&dStack_138;
              uStack_820._0_4_ = (undefined **)0x18cfcc4;
              pppppppuStack_824 = (undefined4 *******)ppppuStack_30;
              uStack_82c = (double)CONCAT44(0x648da4,(undefined4)uStack_82c);
              FUN_0063d860();
            }
            else {
              ppppuStack_30[4] = (undefined4 ***)0x0;
              uStack_820._4_4_ = (undefined4 ******)0x29;
              ppppuStack_30[4] = (undefined4 ***)0x0;
              ppppuStack_30[5] = (undefined4 ***)0xf;
              uStack_820._0_4_ = (undefined **)0x18cfcc4;
              *(undefined *)ppppuStack_30 = 0;
              pppppppuStack_824 = (undefined4 *******)0x648d75;
              FUN_005542c0();
              *(double *)(ppppuVar3 + 6) = dStack_138;
              ppppuStack_30 = ppppuStack_30 + 8;
            }
            ppppuVar3 = ppppuStack_30;
            if (ppppuStack_2c == ppppuStack_30) {
              uStack_820._4_4_ = (undefined4 ******)&dStack_130;
              uStack_820._0_4_ = (undefined **)0x18cfcf0;
              uStack_82c = (double)CONCAT44(0x648dff,(undefined4)uStack_82c);
              pppppppuStack_824 = (undefined4 *******)ppppuStack_30;
              FUN_0063d860();
            }
            else {
              ppppuStack_30[4] = (undefined4 ***)0x0;
              uStack_820._4_4_ = (undefined4 ******)0x2e;
              ppppuStack_30[4] = (undefined4 ***)0x0;
              ppppuStack_30[5] = (undefined4 ***)0xf;
              uStack_820._0_4_ = (undefined **)0x18cfcf0;
              *(undefined *)ppppuStack_30 = 0;
              pppppppuStack_824 = (undefined4 *******)0x648dd2;
              FUN_005542c0();
              *(double *)(ppppuVar3 + 6) = dStack_130;
              ppppuStack_30 = ppppuStack_30 + 8;
            }
            ppppuVar3 = ppppuStack_30;
            if (ppppuStack_2c == ppppuStack_30) {
              uStack_820._4_4_ = (undefined4 ******)&dStack_128;
              uStack_820._0_4_ = (undefined **)0x18cfd20;
              uStack_82c = (double)CONCAT44(0x648e55,(undefined4)uStack_82c);
              pppppppuStack_824 = (undefined4 *******)ppppuStack_30;
              FUN_0063d860();
            }
            else {
              ppppuStack_30[4] = (undefined4 ***)0x0;
              uStack_820._4_4_ = (undefined4 ******)0x31;
              ppppuStack_30[4] = (undefined4 ***)0x0;
              ppppuStack_30[5] = (undefined4 ***)0xf;
              uStack_820._0_4_ = (undefined **)0x18cfd20;
              *(undefined *)ppppuStack_30 = 0;
              pppppppuStack_824 = (undefined4 *******)0x648e2d;
              FUN_005542c0();
              *(double *)(ppppuVar3 + 6) = dStack_128;
              ppppuStack_30 = ppppuStack_30 + 8;
            }
            uStack_820._4_4_ = (undefined4 ******)&dStack_14c;
            uStack_820._0_4_ = (undefined **)0x18cfd54;
            pppppppuStack_824 = (undefined4 *******)0x648e69;
            FUN_0063f780();
            uStack_820._4_4_ = (undefined4 ******)&dStack_154;
            uStack_820._0_4_ = (undefined **)0x18cfd90;
            pppppppuStack_824 = (undefined4 *******)0x648e7d;
            FUN_0063f780();
          }
          if (_PTR_018c6f48 < dStack_120) {
            uStack_820._4_4_ = (undefined4 ******)&dStack_120;
            uStack_820._0_4_ = (undefined **)0x18cfdc4;
            pppppppuStack_824 = (undefined4 *******)0x648ea3;
            FUN_0063f780();
            uStack_820._4_4_ = (undefined4 ******)&dStack_15c;
            uStack_820._0_4_ = (undefined **)0x18cfdf0;
            pppppppuStack_824 = (undefined4 *******)0x648eb7;
            FUN_0063f780();
            uStack_820._4_4_ = (undefined4 ******)&dStack_164;
            uStack_820._0_4_ = (undefined **)0x18cfe20;
            pppppppuStack_824 = (undefined4 *******)0x648ecb;
            FUN_0063f780();
            uStack_820._4_4_ = (undefined4 ******)&dStack_80;
            uStack_820._0_4_ = (undefined **)0x18cfe54;
            pppppppuStack_824 = (undefined4 *******)0x648edc;
            FUN_0063f780();
            uStack_820._4_4_ = (undefined4 ******)&dStack_78;
            uStack_820._0_4_ = (undefined **)0x18cfe90;
            pppppppuStack_824 = (undefined4 *******)0x648eed;
            FUN_0063f780();
          }
        }
      }
      uStack_820._0_4_ = (undefined **)&uStack_34;
      uStack_820._4_4_ = (undefined4 ******)0x0;
      pppppppuStack_824 = (undefined4 *******)0x648ef8;
      FUN_00874d70();
      if (iStack_1c4 == 0) {
        puVar16 = (undefined4 *)0x0;
      }
      else {
        puVar16 = *(undefined4 **)(iStack_1b8 + (int)puStack_1c8 * 4);
      }
      for (; puVar16 != (undefined4 *)0x0; puVar16 = (undefined4 *)*puVar16) {
        piVar17 = puVar16 + 2;
        dStack_1c = (double)((float)puVar16[8] / (float)(int)puVar16[9]);
        pppppppuStack_4c = (undefined4 *******)((uint)pppppppuStack_4c | 1);
        uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
        uStack_8._0_1_ = 10;
        uStack_820._4_4_ = (undefined4 ******)(puVar16[6] + 0x18);
        uStack_1ec = 0;
        uStack_1e8 = 0xf;
        auStack_1fc[0] = 0;
        uStack_820._0_4_ = (undefined **)0x648f79;
        pppppppuStack_38 = pppppppuStack_4c;
        FUN_0058a190();
        uStack_820._4_4_ = (undefined4 ******)0x18;
        uStack_820._0_4_ = (undefined **)0x18cfec4;
        pppppppuStack_824 = (undefined4 *******)0x648f8b;
        FUN_00554150();
        uStack_820._4_4_ = (undefined4 ******)puVar16[6];
        if (0xf < (uint)puVar16[7]) {
          piVar17 = (int *)*piVar17;
        }
        pppppppuStack_824 = (undefined4 *******)0x648fa3;
        uStack_820._0_4_ = (undefined **)piVar17;
        FUN_00554150();
        auVar28._8_8_ = 0;
        auVar28._0_8_ = dStack_1c;
        uStack_820._4_4_ = (undefined4 ******)0x0;
        pppppppuStack_824 = SUB84(dStack_1c,0);
        uStack_820._0_4_ = (undefined **)((ulonglong)dStack_1c >> 0x20);
        uStack_82c = (double)CONCAT44(auStack_1fc,0x648fbe);
        FUN_00878cf0();
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        pppppppuStack_4c = (undefined4 *******)((uint)pppppppuStack_4c & 0xfffffffe);
        uStack_820._4_4_ = (undefined4 ******)0x648fdc;
        pppppppuStack_38 = pppppppuStack_4c;
        FUN_005507b0();
      }
      if (0 < iStack_3c) {
        pppppppuVar11 = (undefined4 *******)(iStack_3c * 10);
        ppppppuVar24 = pppppppuStack_50[0x6e];
        if (ppppppuVar24 != (undefined4 ******)0x0) {
          ppppppuVar21 = pppppppuStack_50[0x10f];
          uStack_820._4_4_ = (undefined4 ******)((int)ppppppuVar21[1] - (int)ppppppuVar21);
          uStack_820._0_4_ = (undefined **)((int)*ppppppuVar21 - (int)ppppppuVar21);
          pppppppuStack_824 = (undefined4 *******)&DAT_018bed48;
          uStack_82c = (double)CONCAT44(auStack_548,0x649025);
          FUN_005bde90();
          uStack_820._4_4_ = (undefined4 ******)0x0;
          if (*(char *)((int)ppppppuVar24 + 0x31b) == '\0') {
            pcVar7 = "NonFeMinutes";
          }
          else {
            pcVar7 = "FeMinutes";
          }
          uStack_82c = (double)CONCAT44(auStack_548,pcVar7);
          pdStack_830 = (double *)&DAT_018c5f98;
          pppppppuStack_834 = (undefined4 *******)0x649055;
          pppppppuStack_824 = pppppppuVar11;
          uStack_820._0_4_ = (undefined **)((int)pppppppuVar11 >> 0x1f);
          FUN_0087c450();
        }
        pppppppuVar9 = pppppppuStack_50;
        if ((DAT_01d5a4e8 != '\0') && (pppppppuStack_50[0x6e] != (undefined4 ******)0x0)) {
          ppppppuVar24 = pppppppuStack_50[0x10f];
          uStack_820._4_4_ = (undefined4 ******)((int)ppppppuVar24[1] - (int)ppppppuVar24);
          uStack_820._0_4_ = (undefined **)((int)*ppppppuVar24 - (int)ppppppuVar24);
          uStack_82c._4_4_ = auStack_7d0;
          pppppppuStack_824 = (undefined4 *******)&DAT_018bed48;
          uStack_82c._0_4_ = 0x64908f;
          FUN_005bde90();
          uStack_82c = (double)(ZEXT48(uStack_82c._4_4_) << 0x20);
          puStack_838 = auStack_7d0;
          pcStack_83c = "PGSSolverMinutes";
          puStack_840 = &DAT_018c5f98;
          uStack_844 = 0x6490ac;
          pppppppuStack_834 = pppppppuVar11;
          pdStack_830 = (double *)((int)pppppppuVar11 >> 0x1f);
          FUN_0087c450();
        }
        uStack_820._4_4_ = (undefined4 ******)0x6490b6;
        cVar10 = FUN_008fc110();
        if (cVar10 != '\0') {
          if (param_2 != (int *)0x0) {
            LOCK();
            param_2[2] = param_2[2] + 1;
            UNLOCK();
          }
          uStack_820._0_4_ = (undefined **)param_1;
          pppppppuStack_824 = pppppppuVar9;
          uStack_820._4_4_ = (undefined4 ******)param_2;
          uStack_82c = (double)CONCAT44(0x6490e8,(undefined4)uStack_82c);
          FUN_006470d0();
        }
        if (DAT_01d67b7c != '\0') {
          ppppuVar3 = pppppppuVar9[0x6e][0x6d][0x1b4];
          if ((DAT_01d67b84 == '\0') ||
             ((*(char *)((int)ppppuVar3 + 0x11) != '\0' &&
              (pppppppuStack_4c = pppppppuStack_38, *(char *)((int)pppppppuVar9 + 0x1df) == '\0'))))
          {
            pppuVar4 = ppppuVar3[5];
            pppuVar5 = ppppuVar3[6];
            ppppuVar3[5] = (undefined4 ***)0x0;
            ppppuVar3[6] = (undefined4 ***)0x0;
            uStack_144 = 0;
            uStack_140 = 0;
            uStack_13c = 0;
            uStack_820._4_4_ = (undefined4 ******)&uStack_88;
            uStack_8._0_1_ = 0xb;
            uStack_88 = (double)CONCAT44(pppuVar4,"RCCMechanismsAddedDuringGameplay");
            uStack_820._0_4_ = (undefined **)0x649194;
            FUN_0063d1d0();
            uStack_820._4_4_ = (undefined4 ******)auStack_568;
            uStack_8._0_1_ = 0xc;
            uStack_820._0_4_ = (undefined **)0x6491aa;
            FUN_00625cd0();
            uStack_8._0_1_ = 0xb;
            uStack_820._4_4_ = (undefined4 ******)0x6491b9;
            FUN_005507b0();
            uStack_820._4_4_ = (undefined4 ******)&uStack_a0;
            uStack_a0 = (double)CONCAT44(pppuVar5,"RCCMechanismsRemovedDuringGameplay");
            uStack_820._0_4_ = (undefined **)0x6491db;
            FUN_0063d1d0();
            uStack_820._4_4_ = (undefined4 ******)auStack_588;
            uStack_8._0_1_ = 0xd;
            uStack_820._0_4_ = (undefined **)0x6491f1;
            FUN_00625cd0();
            uStack_8._0_1_ = 0xb;
            uStack_820._4_4_ = (undefined4 ******)0x649200;
            FUN_005507b0();
            uStack_820._0_4_ = (undefined **)&uStack_144;
            uStack_820._4_4_ = (undefined4 ******)0x0;
            pppppppuStack_824 = (undefined4 *******)0x64920e;
            FUN_00874d70();
            uStack_8 = CONCAT31(uStack_8._1_3_,3);
            uStack_820._4_4_ = (undefined4 ******)0x649220;
            FUN_0056d3e0();
          }
          else {
            ppppuVar3[5] = (undefined4 ***)0x0;
            ppppuVar3[6] = (undefined4 ***)0x0;
            *(undefined *)((int)ppppuVar3 + 0x11) = 1;
          }
        }
        if ((DAT_01d5a4f0 != '\0') && (pppppppuVar9 != (undefined4 *******)0xfffffff4)) {
          uStack_820._4_4_ = (undefined4 ******)&LAB_005c2470;
          uStack_820._0_4_ = (undefined **)&DAT_01ea8c64;
          pppppppuStack_824 = (undefined4 *******)0x649247;
          FUN_005789c0();
          uStack_820._4_4_ = (undefined4 ******)0x64924f;
          uStack_820._4_4_ = (undefined4 ******)FUN_005c3750();
          uStack_820._0_4_ = (undefined **)0x649257;
          piVar17 = (int *)FUN_008aa140();
          if (*piVar17 == 0) {
            uStack_820._4_4_ = (undefined4 ******)0x649263;
            uStack_820._4_4_ = (undefined4 ******)FUN_009e1c40();
            uStack_820._0_4_ = (undefined **)&uStack_f0;
            pppppppuStack_824 = (undefined4 *******)0x649272;
            uStack_820._4_4_ = (undefined4 ******)FUN_008a9ba0();
            uStack_820._0_4_ = (undefined **)0x64927a;
            FUN_005587e0();
            piVar8 = uStack_f0._4_4_;
            if (uStack_f0._4_4_ != (int *)0x0) {
              LOCK();
              iVar13 = uStack_f0._4_4_[1] + -1;
              uStack_f0._4_4_[1] = iVar13;
              UNLOCK();
              if (iVar13 == 0) {
                uStack_820._4_4_ = (undefined4 ******)0x649294;
                (**(code **)*uStack_f0._4_4_)();
                LOCK();
                piVar1 = piVar8 + 2;
                iVar13 = *piVar1 + -1;
                *piVar1 = iVar13;
                UNLOCK();
                if (iVar13 == 0) {
                  uStack_820._4_4_ = (undefined4 ******)0x6492a5;
                  (**(code **)(*piVar8 + 4))();
                }
              }
            }
          }
          if (*piVar17 != 0) {
            uStack_820._4_4_ = (undefined4 ******)&dStack_d0;
            uStack_820._0_4_ = (undefined **)&dStack_d8;
            pppppppuStack_824 = (undefined4 *******)&dStack_e0;
            uStack_82c = (double)CONCAT44(&dStack_e8,0x6492d0);
            FUN_009e7710();
            uStack_fc = 0;
            uStack_f8 = 0;
            uStack_f4 = 0;
            uStack_820._4_4_ = (undefined4 ******)0x1c;
            uStack_820._0_4_ = (undefined **)0x18cff28;
            uStack_8._0_1_ = 0xe;
            dStack_1c = dStack_e8;
            uStack_33c = 0;
            uStack_338 = 0xf;
            auStack_34c[0] = 0;
            pppppppuStack_824 = (undefined4 *******)0x64932c;
            FUN_005542c0();
            dStack_334 = dStack_1c;
            uStack_820._4_4_ = (undefined4 ******)auStack_34c;
            uStack_8._0_1_ = 0xf;
            uStack_820._0_4_ = (undefined **)0x64934f;
            FUN_00625cd0();
            uStack_8._0_1_ = 0xe;
            uStack_820._4_4_ = (undefined4 ******)0x64935e;
            FUN_005507b0();
            uStack_820._4_4_ = (undefined4 ******)0x1c;
            uStack_820._0_4_ = (undefined **)0x18cff48;
            dStack_1c = dStack_e0;
            uStack_2fc = 0;
            uStack_2f8 = 0xf;
            auStack_30c[0] = 0;
            pppppppuStack_824 = (undefined4 *******)0x649398;
            FUN_005542c0();
            dStack_2f4 = dStack_1c;
            uStack_820._4_4_ = (undefined4 ******)auStack_30c;
            uStack_8._0_1_ = 0x10;
            uStack_820._0_4_ = (undefined **)0x6493bb;
            FUN_00625cd0();
            uStack_8._0_1_ = 0xe;
            uStack_820._4_4_ = (undefined4 ******)0x6493ca;
            FUN_005507b0();
            uStack_820._4_4_ = (undefined4 ******)0x1c;
            uStack_820._0_4_ = (undefined **)0x18cff68;
            dStack_1c = dStack_d8;
            uStack_3bc = 0;
            uStack_3b8 = 0xf;
            auStack_3cc[0] = 0;
            pppppppuStack_824 = (undefined4 *******)0x649404;
            FUN_005542c0();
            dStack_3b4 = dStack_1c;
            uStack_820._4_4_ = (undefined4 ******)auStack_3cc;
            uStack_8._0_1_ = 0x11;
            uStack_820._0_4_ = (undefined **)0x649427;
            FUN_00625cd0();
            uStack_8._0_1_ = 0xe;
            uStack_820._4_4_ = (undefined4 ******)0x649436;
            FUN_005507b0();
            uStack_820._4_4_ = (undefined4 ******)apcStack_46c;
            apcStack_46c[0] = "HttpServiceRateFailProbePass";
            dStack_464 = dStack_d0;
            uStack_820._0_4_ = (undefined **)0x649462;
            FUN_0063d230();
            uStack_820._4_4_ = (undefined4 ******)auStack_5a8;
            uStack_8._0_1_ = 0x12;
            uStack_820._0_4_ = (undefined **)0x649478;
            FUN_00625cd0();
            uStack_8._0_1_ = 0xe;
            uStack_820._4_4_ = (undefined4 ******)0x649487;
            FUN_005507b0();
            uStack_820._0_4_ = (undefined **)&uStack_fc;
            uStack_820._4_4_ = (undefined4 ******)0x0;
            pppppppuStack_824 = (undefined4 *******)0x649495;
            FUN_00874d70();
            uStack_8 = CONCAT31(uStack_8._1_3_,3);
            uStack_820._4_4_ = (undefined4 ******)0x6494a7;
            FUN_0056d3e0();
          }
        }
        uStack_820._4_4_ = (undefined4 ******)0x6494b2;
        iVar13 = FUN_00644b60();
        uStack_820._4_4_ = (undefined4 ******)0x12;
        uStack_820._0_4_ = (undefined **)0x18cffa8;
        uStack_264 = 0;
        dStack_1c = (double)iVar13;
        uStack_260 = 0xf;
        auStack_274[0] = 0;
        pppppppuStack_824 = (undefined4 *******)0x6494ec;
        FUN_005542c0();
        auVar28._8_8_ = 0;
        auVar28._0_8_ = dStack_1c;
        uStack_820._4_4_ = (undefined4 ******)0x0;
        uStack_8._0_1_ = 0x13;
        pppppppuStack_824 = SUB84(dStack_1c,0);
        uStack_820._0_4_ = (undefined **)((ulonglong)dStack_1c >> 0x20);
        uStack_82c = (double)CONCAT44(auStack_274,0x64950b);
        FUN_00878cf0();
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        uStack_820._4_4_ = (undefined4 ******)0x64951d;
        FUN_005507b0();
      }
      dVar27 = auVar28._0_8_;
      if (DAT_01d5a500 != '\0') {
        pppppuVar2 = *ppppppuStack_14;
        if (pppppuVar2 != (undefined4 *****)0x0) {
          ppppuVar3 = pppppuVar2[1];
          for (ppppuVar22 = *pppppuVar2; ppppuVar22 != ppppuVar3; ppppuVar22 = ppppuVar22 + 2) {
            pppppppuStack_38 = (undefined4 *******)*ppppuVar22;
            if (pppppppuStack_38 != (undefined4 *******)0x0) {
              ppppppuStack_14 = pppppppuStack_38[3];
              uStack_820._4_4_ = (undefined4 ******)0x64955c;
              iVar13 = FUN_005ee350();
              if ((uint)*(ushort *)(ppppppuStack_14 + 0x76) - (uint)*(ushort *)(iVar13 + 0x1d8) <=
                  (uint)*(ushort *)(iVar13 + 0x1da)) {
                uStack_820._4_4_ = (undefined4 ******)0x64958b;
                iVar13 = (*(code *)(*pppppppuStack_38)[0x2e])();
                if (iVar13 != 0) {
                  uStack_820._4_4_ = (undefined4 ******)0x649598;
                  FUN_006a6920();
                  uStack_820._4_4_ = (undefined4 ******)0x6495ae;
                  FUN_016f3fe0();
                  auVar28._0_4_ = (float)auVar28._0_8_ / DAT_018d0938;
                  if (300 < (int)auVar28._0_4_) {
                    uStack_820._4_4_ = &pppppuStack_20;
                    uStack_820._0_4_ = (undefined **)&ppppuStack_24;
                    ppppppuStack_28 = (undefined4 ******)0x0;
                    pppppppuStack_824 = &ppppppuStack_28;
                    ppppuStack_24 = (undefined4 ****)0x0;
                    pppppuStack_20 = (undefined4 *****)0x0;
                    uStack_82c = (double)CONCAT44(0x6495f2,(undefined4)uStack_82c);
                    FUN_0067c650();
                    uStack_820._4_4_ = (undefined4 ******)&dStack_c8;
                    dStack_c8 = (double)(float)ppppppuStack_28;
                    uStack_820._0_4_ = (undefined **)0x64960e;
                    FUN_017265ed();
                    uStack_820._0_4_ = (undefined **)&dStack_c0;
                    dStack_c0 = (double)(float)ppppuStack_24;
                    pppppppuStack_824 = (undefined4 *******)0x64962a;
                    FUN_017265ed();
                    pppppppuStack_824 = (undefined4 *******)&dStack_b8;
                    auVar28._0_8_ = (double)(float)pppppuStack_20;
                    auVar28._8_8_ = 0;
                    uStack_82c = (double)CONCAT44(0x649646,(undefined4)uStack_82c);
                    dStack_b8 = auVar28._0_8_;
                    FUN_017265ed();
                    uStack_820._4_4_ = (undefined4 ******)0x649654;
                    (*(code *)(*pppppppuStack_38)[0xa3])();
                  }
                }
              }
            }
          }
        }
        uStack_820._4_4_ = (undefined4 ******)0x12;
        uStack_820._0_4_ = (undefined **)0x18cffbc;
        uStack_27c = 0;
        uStack_278 = 0xf;
        auStack_28c[0] = 0;
        pppppppuStack_824 = (undefined4 *******)0x64968c;
        FUN_005542c0();
        uStack_820._4_4_ = (undefined4 ******)0x0;
        uStack_8._0_1_ = 0x14;
        pppppppuStack_824 = (undefined4 *******)0x0;
        uStack_820._0_4_ = (undefined **)0x0;
        uStack_82c = (double)CONCAT44(auStack_28c,0x6496a9);
        FUN_00878cf0();
        uStack_8._0_1_ = 3;
        uStack_820._4_4_ = (undefined4 ******)0x6496bb;
        FUN_005507b0();
        uStack_820._4_4_ = (undefined4 ******)0x13;
        uStack_820._0_4_ = (undefined **)0x18cffd0;
        uStack_24c = 0;
        uStack_248 = 0xf;
        auStack_25c[0] = 0;
        pppppppuStack_824 = (undefined4 *******)0x6496e8;
        FUN_005542c0();
        uStack_820._4_4_ = (undefined4 ******)0x0;
        uStack_8._0_1_ = 0x15;
        pppppppuStack_824 = (undefined4 *******)0x0;
        uStack_820._0_4_ = (undefined **)0x0;
        uStack_82c = (double)CONCAT44(auStack_25c,0x649705);
        FUN_00878cf0();
        uStack_8._0_1_ = 3;
        uStack_820._4_4_ = (undefined4 ******)0x649717;
        FUN_005507b0();
        uStack_820._4_4_ = (undefined4 ******)0x15;
        uStack_820._0_4_ = (undefined **)0x18cffe4;
        uStack_294 = 0;
        uStack_290 = 0xf;
        auStack_2a4[0] = 0;
        pppppppuStack_824 = (undefined4 *******)0x649744;
        FUN_005542c0();
        uStack_820._4_4_ = (undefined4 ******)0x0;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
        dVar27 = 0.0;
        pppppppuStack_824 = (undefined4 *******)0x0;
        uStack_820._0_4_ = (undefined **)0x0;
        uStack_82c = (double)CONCAT44(auStack_2a4,0x649761);
        FUN_00878cf0();
        uStack_820._4_4_ = (undefined4 ******)0x64976f;
        FUN_005507b0();
      }
      uStack_48 = 0;
      ppuStack_44 = (undefined **)0x0;
      ppuStack_40 = (undefined **)0x0;
      uStack_8._0_1_ = 0x17;
      uStack_820._4_4_ = (undefined4 ******)0x64978d;
      FUN_01522960();
      uStack_820._4_4_ = (undefined4 ******)0x649794;
      FUN_016f3fe0();
      dStack_1c = dVar27 * DAT_018d0930;
      uStack_820._4_4_ = (undefined4 ******)auStack_798;
      uStack_820._0_4_ = (undefined **)0x6497ad;
      uStack_820._0_4_ = (undefined **)FUN_01530500();
      uStack_8._0_1_ = 0x18;
      pppppppuStack_824 = (undefined4 *******)0x18cfffc;
      uStack_82c = (double)CONCAT44(auStack_720,0x6497c3);
      puVar16 = (undefined4 *)FUN_00558d90();
      uStack_4c8 = *puVar16;
      uStack_4c4 = puVar16[1];
      uStack_4c0 = puVar16[2];
      uStack_4bc = puVar16[3];
      uStack_4b8 = *(undefined8 *)(puVar16 + 4);
      puVar16[4] = 0;
      puVar16[5] = 0xf;
      *(undefined *)puVar16 = 0;
      dStack_4b0 = dStack_1c;
      uStack_820._4_4_ = (undefined4 ******)&uStack_4c8;
      uStack_8._0_1_ = 0x1a;
      uStack_820._0_4_ = (undefined **)0x64980e;
      FUN_00625cd0();
      uStack_820._4_4_ = (undefined4 ******)0x649819;
      FUN_005507b0();
      uStack_820._4_4_ = (undefined4 ******)0x649824;
      FUN_005507b0();
      uStack_8._0_1_ = 0x17;
      uStack_820._4_4_ = (undefined4 ******)0x649833;
      FUN_005507b0();
      uStack_820._4_4_ = (undefined4 ******)auStack_768;
      uStack_820._0_4_ = (undefined **)0x64983f;
      uStack_820._0_4_ = (undefined **)FUN_01530500();
      uStack_82c._4_4_ = auStack_780;
      uStack_8._0_1_ = 0x1b;
      pppppppuStack_824 = (undefined4 *******)0x18d0008;
      uStack_82c._0_4_ = 0x649855;
      pdStack_830 = (double *)FUN_00558d90();
      uStack_82c = (double)CONCAT44(uStack_82c._4_4_,&DAT_018c6ae4);
      pppppppuStack_834 = apppppppuStack_244;
      uStack_8._0_1_ = 0x1c;
      puStack_838 = (undefined *)0x64986b;
      FUN_00558c80();
      uStack_820._4_4_ = (undefined4 ******)0x649879;
      FUN_005507b0();
      uStack_820._4_4_ = (undefined4 ******)0x649884;
      FUN_005507b0();
      uStack_820._4_4_ = &ppppppuStack_58;
      auStack_1e4[0] = 0;
      uStack_820._0_4_ = &boost::lock_error::vftable_meta_ptr;
      pppppppuStack_824 = (undefined4 *******)&DAT_018be100;
      ppppppuStack_58 = (undefined4 ******)&DAT_0000000b;
      uStack_82c = (double)CONCAT44(0x6498a5,(undefined4)uStack_82c);
      ppuVar12 = (undefined **)FUN_00563d40();
      ppuVar23 = ppuVar12 + -1;
      if (ppuVar12 != &boost::lock_error::vftable_meta_ptr) {
        ppuVar23 = ppuVar12;
      }
      puStack_1e0 = *ppuVar23;
      iStack_1dc = 0;
      uStack_1d8 = 0x3f800000;
      uStack_1d4 = 0;
      iStack_1d0 = 0;
      uStack_8._0_1_ = 0x20;
      uStack_82c = (double)CONCAT44(auStack_1e4,0x6498f0);
      FUN_01533d90();
      pppppppuVar11 = pppppppuStack_4c;
      iVar13 = iStack_3c;
      if (iStack_1dc == 0) {
        puVar16 = (undefined4 *)0x0;
      }
      else {
        puVar16 = *(undefined4 **)(iStack_1d0 + (int)puStack_1e0 * 4);
      }
      for (; iStack_3c = iVar13, puVar16 != (undefined4 *)0x0; puVar16 = (undefined4 *)*puVar16) {
        dStack_1c = ((double)(int)puVar16[8] + (double)(&DAT_018c0d90)[-((int)puVar16[8] >> 0x1f)])
                    * DAT_018d0930;
        pppppppuStack_4c = (undefined4 *******)((uint)pppppppuVar11 | 2);
        uStack_8._0_1_ = 0x21;
        uStack_820._4_4_ = (undefined4 ******)(puVar16[6] + iStack_234);
        uStack_18c = 0;
        uStack_188 = 0xf;
        uStack_19c = uStack_19c & 0xffffff00;
        uStack_820._0_4_ = (undefined **)0x649983;
        pppppppuStack_38 = pppppppuStack_4c;
        FUN_0058a190();
        uStack_820._0_4_ = (undefined **)apppppppuStack_244;
        if (0xf < uStack_230) {
          uStack_820._0_4_ = (undefined **)apppppppuStack_244[0];
        }
        pppppppuStack_824 = (undefined4 *******)0x6499a4;
        FUN_00554150();
        uStack_820._0_4_ = (undefined **)(puVar16 + 2);
        uStack_820._4_4_ = (undefined4 ******)puVar16[6];
        if (0xf < (uint)puVar16[7]) {
          uStack_820._0_4_ = (undefined **)*(undefined **)uStack_820;
        }
        pppppppuStack_824 = (undefined4 *******)0x6499bf;
        FUN_00554150();
        uStack_48c = uStack_19c;
        uStack_19c = uStack_19c & 0xffffff00;
        uStack_488 = uStack_198;
        uStack_484 = uStack_194;
        uStack_480 = uStack_190;
        uStack_47c = CONCAT44(uStack_188,uStack_18c);
        uStack_18c = 0;
        uStack_188 = 0xf;
        dStack_474 = dStack_1c;
        uStack_820._4_4_ = (undefined4 ******)&uStack_48c;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x22);
        uStack_820._0_4_ = ppuStack_44;
        if (ppuStack_40 == ppuStack_44) {
          pppppppuStack_824 = (undefined4 *******)0x649a33;
          FUN_00603540();
        }
        else {
          pppppppuStack_824 = (undefined4 *******)&uStack_48;
          uStack_82c = (double)CONCAT44(0x649a22,(undefined4)uStack_82c);
          FUN_0055d710();
          ppuStack_44 = ppuStack_44 + 8;
        }
        uStack_820._4_4_ = (undefined4 ******)0x649a3e;
        FUN_005507b0();
        pppppppuVar11 = (undefined4 *******)((uint)pppppppuStack_4c & 0xfffffffd);
        uStack_8._0_1_ = 0x20;
        uStack_820._4_4_ = (undefined4 ******)0x649a53;
        FUN_005507b0();
        iVar13 = iStack_3c;
      }
      pppppppuStack_38 = pppppppuStack_50 + 3;
      uStack_820._4_4_ = (undefined4 ******)0x649a70;
      piVar17 = (int *)FUN_00564080();
      if (*piVar17 != 0) {
        piVar17 = *(int **)(*piVar17 + 0xb8);
        iVar13 = piVar17[1] - *piVar17 >> 3;
      }
      if (iVar13 != 0) {
        ppuVar23 = (undefined **)((iVar13 / 0x19) * 0x19);
        uStack_820._4_4_ = (undefined4 ******)0x649aa7;
        piVar17 = (int *)FUN_00564130();
        iVar13 = *piVar17;
        if (iVar13 != 0) {
          ppppppuStack_14 = (undefined4 ******)CONCAT31((int3)((uint)piVar17 >> 8),DAT_01d5a4f8);
          uStack_820._4_4_ = (undefined4 ******)0x649ac0;
          fVar25 = (float10)FUN_00999e90();
          uStack_820._4_4_ = ppppppuStack_14;
          uStack_82c = (double)fVar25;
          pppppppuStack_824 = (undefined4 *******)0x1;
          puStack_848 = (undefined4 *)0xd;
          pppppppuStack_834 = (undefined4 *******)0x0;
          pdStack_830 = (double *)0xf;
          pcStack_84c = "GameSmoothFps";
          uStack_844 = uStack_844 & 0xffffff00;
          uStack_850 = 0x649af6;
          uStack_820._0_4_ = ppuVar23;
          dStack_1c = uStack_82c;
          FUN_005542c0();
          puStack_848 = &uStack_48;
          pcStack_84c = (char *)0x649aff;
          uVar18 = FUN_00643c50();
          ppppppuStack_14 = (undefined4 ******)CONCAT31((int3)((uint)uVar18 >> 8),DAT_01d5a4f8);
          uStack_820._4_4_ = (undefined4 ******)0x649b11;
          fVar25 = (float10)FUN_009994d0();
          uStack_820._4_4_ = ppppppuStack_14;
          uStack_82c = (double)fVar25;
          pppppppuStack_824 = (undefined4 *******)0x1;
          puStack_848 = (undefined4 *)0xd;
          pppppppuStack_834 = (undefined4 *******)0x0;
          pdStack_830 = (double *)0xf;
          pcStack_84c = "GameHeartbeat";
          uStack_844 = uStack_844 & 0xffffff00;
          uStack_850 = 0x649b47;
          uStack_820._0_4_ = ppuVar23;
          dStack_1c = uStack_82c;
          FUN_005542c0();
          puStack_848 = &uStack_48;
          pcStack_84c = (char *)0x649b50;
          uVar18 = FUN_00643c50();
          ppppppuStack_14 = (undefined4 ******)CONCAT31((int3)((uint)uVar18 >> 8),DAT_01d5a4f8);
          uStack_820._4_4_ = (undefined4 ******)0x649b62;
          fVar25 = (float10)FUN_00999eb0();
          uStack_820._4_4_ = ppppppuStack_14;
          uStack_82c = (double)fVar25;
          pppppppuStack_824 = (undefined4 *******)0x1;
          puStack_848 = (undefined4 *)0x13;
          pppppppuStack_834 = (undefined4 *******)0x0;
          pdStack_830 = (double *)&DAT_0000000f;
          pcStack_84c = "GameSmoothHeartBeat";
          uStack_844 = uStack_844 & 0xffffff00;
          uStack_850 = 0x649b98;
          uStack_820._0_4_ = ppuVar23;
          dStack_1c = uStack_82c;
          FUN_005542c0();
          puStack_848 = &uStack_48;
          pcStack_84c = (char *)0x649ba1;
          FUN_00643c50();
        }
        ppppppuStack_58 = pppppppuStack_50[0x6e];
        if (ppppppuStack_58 != (undefined4 ******)0x0) {
          uVar20 = (undefined3)((uint)ppppppuStack_58 >> 8);
          iVar19 = CONCAT31(uVar20,*(char *)(ppppppuStack_58 + 0xc0));
          if (*(char *)(ppppppuStack_58 + 0xc0) == '\0') {
            if (iVar13 != 0) {
              ppppppuStack_14 = (undefined4 ******)CONCAT31(uVar20,DAT_01d5a4f8);
              uStack_820._4_4_ = (undefined4 ******)0x649e4c;
              fVar25 = (float10)FUN_00999e90();
              uStack_820._4_4_ = ppppppuStack_14;
              uStack_82c = (double)fVar25;
              pppppppuStack_824 = (undefined4 *******)0x1;
              puStack_848 = (undefined4 *)0x1d;
              pppppppuStack_834 = (undefined4 *******)0x0;
              pdStack_830 = (double *)0xf;
              pcStack_84c = "SmoothFps_NonStreamingEnabled";
              uStack_844 = uStack_844 & 0xffffff00;
              uStack_850 = 0x649e82;
              uStack_820._0_4_ = ppuVar23;
              dStack_1c = uStack_82c;
              FUN_005542c0();
              puStack_848 = &uStack_48;
              pcStack_84c = (char *)0x649e8b;
              uVar18 = FUN_00643c50();
              ppppppuStack_14 = (undefined4 ******)CONCAT31((int3)((uint)uVar18 >> 8),DAT_01d5a4f8);
              uStack_820._4_4_ = (undefined4 ******)0x649e9d;
              fVar25 = (float10)FUN_009994d0();
              uStack_820._4_4_ = ppppppuStack_14;
              uStack_82c = (double)fVar25;
              pppppppuStack_824 = (undefined4 *******)0x1;
              puStack_848 = (undefined4 *)0x1d;
              pppppppuStack_834 = (undefined4 *******)0x0;
              pdStack_830 = (double *)&DAT_0000000f;
              pcStack_84c = "Heartbeat_NonStreamingEnabled";
              uStack_844 = uStack_844 & 0xffffff00;
              uStack_850 = 0x649ed3;
              uStack_820._0_4_ = ppuVar23;
              dStack_1c = uStack_82c;
              FUN_005542c0();
              puStack_848 = &uStack_48;
              pcStack_84c = (char *)0x649edc;
              iVar19 = FUN_00643c50();
            }
          }
          else {
            uStack_820._4_4_ = (undefined4 ******)&uStack_a8;
            uStack_a8 = (double)CONCAT44(iStack_3c,"PlayerInStreamingEnabledGames");
            uStack_820._0_4_ = (undefined **)0x649beb;
            FUN_0063d170();
            uStack_820._4_4_ = (undefined4 ******)auStack_5c8;
            uStack_8._0_1_ = 0x23;
            uStack_820._0_4_ = (undefined **)0x649bfe;
            FUN_00625cd0();
            uStack_8._0_1_ = 0x20;
            uStack_820._4_4_ = (undefined4 ******)0x649c0d;
            iVar19 = FUN_005507b0();
            if (iVar13 != 0) {
              uStack_820._4_4_ = (undefined4 ******)0x649c1c;
              fVar25 = (float10)FUN_00999e90();
              uStack_820._4_4_ = (undefined4 ******)apcStack_45c;
              apcStack_45c[0] = "SmoothFpsForStreamingEnabledGames";
              dStack_454 = (double)fVar25;
              uStack_820._0_4_ = (undefined **)0x649c4e;
              dStack_b0 = dStack_454;
              FUN_0063d230();
              uStack_820._4_4_ = (undefined4 ******)auStack_5e8;
              uStack_8._0_1_ = 0x24;
              uStack_820._0_4_ = (undefined **)0x649c61;
              FUN_00625cd0();
              uStack_8._0_1_ = 0x20;
              uStack_820._4_4_ = (undefined4 ******)0x649c70;
              FUN_005507b0();
              uStack_820._4_4_ = (undefined4 ******)0x649c77;
              fVar25 = (float10)FUN_009994d0();
              uStack_820._4_4_ = (undefined4 ******)apcStack_40c;
              apcStack_40c[0] = "HeartbeatForStreamingEnabledGames";
              dStack_404 = (double)fVar25;
              uStack_820._0_4_ = (undefined **)0x649ca9;
              dStack_98 = dStack_404;
              FUN_0063d230();
              uStack_820._4_4_ = (undefined4 ******)auStack_608;
              uStack_8._0_1_ = 0x25;
              uStack_820._0_4_ = (undefined **)0x649cbc;
              FUN_00625cd0();
              uStack_8._0_1_ = 0x20;
              uStack_820._4_4_ = (undefined4 ******)0x649ccb;
              iVar19 = FUN_005507b0();
            }
            if (DAT_01d5a048 != '\0') {
              uStack_820._4_4_ = (undefined4 ******)&DAT_01d7a8e8;
              pppppppuStack_824 = (undefined4 *******)auStack_7b0;
              uStack_820._0_4_ = (undefined **)0x18d00b4;
              uStack_82c = (double)CONCAT44(0x649cee,(undefined4)uStack_82c);
              uStack_820._4_4_ = (undefined4 ******)FUN_00558df0();
              uStack_820._0_4_ = (undefined **)0x649cfd;
              FUN_0054ef20();
              iStack_490 = iStack_3c;
              uStack_820._4_4_ = (undefined4 ******)auStack_4a8;
              uStack_820._0_4_ = (undefined **)0x649d18;
              FUN_0054ef20();
              dStack_510 = (double)iStack_490;
              uStack_820._4_4_ = (undefined4 ******)auStack_528;
              uStack_8._0_1_ = 0x28;
              uStack_820._0_4_ = (undefined **)0x649d3f;
              FUN_00625cd0();
              uStack_820._4_4_ = (undefined4 ******)0x649d4a;
              FUN_005507b0();
              uStack_820._4_4_ = (undefined4 ******)0x649d55;
              FUN_005507b0();
              uStack_8._0_1_ = 0x20;
              uStack_820._4_4_ = (undefined4 ******)0x649d64;
              FUN_005507b0();
              uStack_820._4_4_ = (undefined4 ******)0x649d6c;
              piVar17 = (int *)FUN_00564130();
              iVar19 = *piVar17;
              if (iVar19 != 0) {
                uStack_820._4_4_ = (undefined4 ******)0x649d80;
                ppppppuStack_14 = (undefined4 ******)iVar19;
                fVar25 = (float10)FUN_00999e90();
                uStack_820._4_4_ = (undefined4 ******)&DAT_01d7a8e8;
                pppppppuStack_824 = (undefined4 *******)auStack_750;
                uStack_820._0_4_ = (undefined **)0x18d00d4;
                dStack_70 = (double)fVar25;
                uStack_82c = (double)CONCAT44(0x649d99,(undefined4)uStack_82c);
                uVar18 = FUN_00558df0();
                uStack_82c = (double)CONCAT44(&dStack_70,uVar18);
                pdStack_830 = (double *)auStack_7f0;
                pppppppuStack_834 = (undefined4 *******)0x649daa;
                uStack_820._4_4_ = (undefined4 ******)FUN_00607830();
                uStack_8._0_1_ = 0x2a;
                uStack_820._0_4_ = (undefined **)0x649dba;
                FUN_00625cd0();
                uStack_820._4_4_ = (undefined4 ******)0x649dc5;
                FUN_005507b0();
                uStack_8._0_1_ = 0x20;
                uStack_820._4_4_ = (undefined4 ******)0x649dd4;
                FUN_005507b0();
                uStack_820._4_4_ = (undefined4 ******)0x649ddc;
                fVar25 = (float10)FUN_009994d0();
                uStack_820._4_4_ = (undefined4 ******)&DAT_01d7a8e8;
                pppppppuStack_824 = (undefined4 *******)auStack_738;
                uStack_820._0_4_ = (undefined **)0x18d00f8;
                dStack_60 = (double)fVar25;
                uStack_82c = (double)CONCAT44(0x649df5,(undefined4)uStack_82c);
                uVar18 = FUN_00558df0();
                uStack_82c = (double)CONCAT44(&dStack_60,uVar18);
                pdStack_830 = adStack_810;
                pppppppuStack_834 = (undefined4 *******)0x649e06;
                uStack_820._4_4_ = (undefined4 ******)FUN_00607830();
                uStack_8._0_1_ = 0x2c;
                uStack_820._0_4_ = (undefined **)0x649e16;
                FUN_00625cd0();
                uStack_820._4_4_ = (undefined4 ******)0x649e21;
                FUN_005507b0();
                uStack_8._0_1_ = 0x20;
                uStack_820._4_4_ = (undefined4 ******)0x649e30;
                iVar19 = FUN_005507b0();
              }
            }
          }
          ppppppuStack_14 = (undefined4 ******)CONCAT31((int3)((uint)iVar19 >> 8),DAT_01d5a4f8);
          uStack_820._4_4_ = (undefined4 ******)0x649eec;
          fVar25 = (float10)FUN_0151da20();
          uStack_820._4_4_ = ppppppuStack_14;
          uStack_82c = (double)fVar25;
          pppppppuStack_824 = (undefined4 *******)0x1;
          puStack_848 = (undefined4 *)0x13;
          pppppppuStack_834 = (undefined4 *******)0x0;
          pdStack_830 = (double *)0xf;
          pcStack_84c = "ServerFrameTaskTime";
          uStack_844 = uStack_844 & 0xffffff00;
          uStack_850 = 0x649f22;
          uStack_820._0_4_ = ppuVar23;
          dStack_1c = uStack_82c;
          FUN_005542c0();
          puStack_848 = &uStack_48;
          pcStack_84c = (char *)0x649f2b;
          FUN_00643c50();
          if (*(char *)(ppppppuStack_58 + 0xc0) != '\0') {
            ppppppuStack_14 =
                 (undefined4 ******)CONCAT31((int3)((uint)ppppppuStack_58 >> 8),DAT_01d5a4f8);
            uStack_820._4_4_ = (undefined4 ******)0x649f48;
            fVar25 = (float10)FUN_0151da20();
            uStack_820._4_4_ = ppppppuStack_14;
            uStack_82c = (double)fVar25;
            pppppppuStack_824 = (undefined4 *******)0x1;
            puStack_848 = (undefined4 *)0x23;
            pppppppuStack_834 = (undefined4 *******)0x0;
            pdStack_830 = (double *)0xf;
            pcStack_84c = "ServerFrameTaskTime_SteamingEnabled";
            uStack_844 = uStack_844 & 0xffffff00;
            uStack_850 = 0x649f7e;
            uStack_820._0_4_ = ppuVar23;
            dStack_1c = uStack_82c;
            FUN_005542c0();
            puStack_848 = &uStack_48;
            pcStack_84c = (char *)0x649f87;
            FUN_00643c50();
          }
          uStack_820._4_4_ = (undefined4 ******)0x649f92;
          iVar19 = FUN_005ef030();
          if (iVar19 != 0) {
            dStack_80 = *(double *)(iVar19 + 0x248);
            dStack_78 = *(double *)(iVar19 + 0x220);
            uStack_820._4_4_ = (undefined4 ******)0x649fb9;
            fVar25 = (float10)FUN_0151da20();
            uStack_820._4_4_ = (undefined4 ******)(uint)DAT_01d5a4f8;
            pppppppuStack_824 = (undefined4 *******)0x1;
            dStack_1c = (double)fVar25;
            uStack_82c = dStack_80;
            puStack_848 = (undefined4 *)0x19;
            pppppppuStack_834 = (undefined4 *******)0x0;
            pdStack_830 = (double *)0xf;
            pcStack_84c = "ServerFrameTimeScriptPart";
            uStack_844 = uStack_844 & 0xffffff00;
            uStack_850 = 0x649ff4;
            uStack_820._0_4_ = ppuVar23;
            FUN_005542c0();
            puStack_848 = &uStack_48;
            pcStack_84c = (char *)0x649ffd;
            FUN_00643c50();
            uStack_820._4_4_ = (undefined4 ******)(uint)DAT_01d5a4f8;
            pppppppuStack_824 = (undefined4 *******)0x1;
            uStack_82c = dStack_78;
            puStack_848 = (undefined4 *)0x1b;
            pppppppuStack_834 = (undefined4 *******)0x0;
            pdStack_830 = (double *)0xf;
            pcStack_84c = "ServerFrameTimeScriptGcPart";
            uStack_844 = uStack_844 & 0xffffff00;
            uStack_850 = 0x64a038;
            uStack_820._0_4_ = ppuVar23;
            FUN_005542c0();
            puStack_848 = &uStack_48;
            pcStack_84c = (char *)0x64a041;
            FUN_00643c50();
            uStack_820._4_4_ = (undefined4 ******)(uint)DAT_01d5a4f8;
            pppppppuStack_824 = (undefined4 *******)0x1;
            uStack_82c = (dStack_1c - dStack_78) - dStack_80;
            puStack_848 = (undefined4 *)0x16;
            pppppppuStack_834 = (undefined4 *******)0x0;
            pdStack_830 = (double *)0xf;
            pcStack_84c = "ServerFrameTimeCppPart";
            uStack_844 = uStack_844 & 0xffffff00;
            uStack_850 = 0x64a086;
            uStack_820._0_4_ = ppuVar23;
            FUN_005542c0();
            puStack_848 = &uStack_48;
            pcStack_84c = (char *)0x64a08f;
            FUN_00643c50();
            uStack_820._4_4_ = (undefined4 ******)(uint)DAT_01d5a4f8;
            uStack_82c = dStack_78 + dStack_80;
            pppppppuStack_824 = (undefined4 *******)0x1;
            puStack_848 = (undefined4 *)0x1a;
            pppppppuStack_834 = (undefined4 *******)0x0;
            pdStack_830 = (double *)0xf;
            pcStack_84c = "ServerFrameTimeScriptTotal";
            uStack_844 = uStack_844 & 0xffffff00;
            uStack_850 = 0x64a0cf;
            uStack_820._0_4_ = ppuVar23;
            FUN_005542c0();
            puStack_848 = &uStack_48;
            pcStack_84c = (char *)0x64a0d8;
            iVar19 = FUN_00643c50();
          }
          ppppppuStack_14 = (undefined4 ******)CONCAT31((int3)((uint)iVar19 >> 8),DAT_01d5a4f8);
          uStack_820._4_4_ = (undefined4 ******)0x64a0e8;
          fVar25 = (float10)FUN_0151da10();
          uStack_820._4_4_ = ppppppuStack_14;
          uStack_82c = (double)fVar25;
          pppppppuStack_824 = (undefined4 *******)0x1;
          puStack_848 = (undefined4 *)0x12;
          pppppppuStack_834 = (undefined4 *******)0x0;
          pdStack_830 = (double *)&DAT_0000000f;
          pcStack_84c = "ServerMaxFrameTime";
          uStack_844 = uStack_844 & 0xffffff00;
          uStack_850 = 0x64a11e;
          uStack_820._0_4_ = ppuVar23;
          dStack_1c = uStack_82c;
          FUN_005542c0();
          puStack_848 = &uStack_48;
          pcStack_84c = (char *)0x64a127;
          FUN_00643c50();
          if (DAT_01d62d74 != '\0') {
            uStack_820._4_4_ = (undefined4 ******)&LAB_005cf1b0;
            uStack_820._0_4_ = (undefined **)&DAT_01ea8dec;
            pppppppuStack_824 = (undefined4 *******)0x64a146;
            FUN_005789c0();
            uStack_820._4_4_ = (undefined4 ******)0x64a14e;
            uStack_820._4_4_ = (undefined4 ******)FUN_005cf480();
            uStack_820._0_4_ = (undefined **)0x64a159;
            ppppppuStack_14 = (undefined4 ******)FUN_008aa140();
            ppppppuStack_28 = (undefined4 ******)*ppppppuStack_14;
            if (ppppppuStack_28 == (undefined4 ******)0x0) {
              uStack_820._4_4_ = (undefined4 ******)0x64a16a;
              uStack_820._4_4_ = (undefined4 ******)FUN_009fb760();
              uStack_820._0_4_ = (undefined **)&dStack_68;
              pppppppuStack_824 = (undefined4 *******)0x64a176;
              uStack_820._4_4_ = (undefined4 ******)FUN_008a9ba0();
              ppppppuVar24 = ppppppuStack_14;
              uStack_820._0_4_ = (undefined **)0x64a181;
              FUN_005587e0();
              uStack_820._4_4_ = (undefined4 ******)0x64a189;
              FUN_00550b30();
              ppppppuStack_28 = (undefined4 ******)*ppppppuVar24;
              if (ppppppuStack_28 == (undefined4 ******)0x0) goto LAB_0064a4fe;
            }
            uStack_820._4_4_ = (undefined4 ******)0x5;
            uStack_820._0_4_ = (undefined **)0x18d0214;
            uStack_2ac = 0;
            uStack_2a8 = 0xf;
            auStack_2bc[0] = 0;
            pppppppuStack_824 = (undefined4 *******)0x64a1c3;
            FUN_005542c0();
            uStack_820._4_4_ = (undefined4 ******)auStack_2bc;
            uStack_8._0_1_ = 0x2d;
            uStack_820._0_4_ = (undefined **)0x64a1d6;
            iVar19 = FUN_008a1240();
            uStack_8._0_1_ = 0x20;
            uStack_820._4_4_ = (undefined4 ******)0x64a1ea;
            iStack_3c = iVar19;
            FUN_005507b0();
            if (iVar19 != 0) {
              uStack_820._4_4_ = (undefined4 ******)0x17;
              uStack_820._0_4_ = (undefined **)0x18d021c;
              uStack_2c4 = 0;
              uStack_2c0 = 0xf;
              auStack_2d4[0] = 0;
              pppppppuStack_824 = (undefined4 *******)0x64a21f;
              FUN_005542c0();
              uStack_820._4_4_ = (undefined4 ******)auStack_2d4;
              uStack_8._0_1_ = 0x2e;
              uStack_820._0_4_ = (undefined **)0x64a231;
              uStack_820._4_4_ = (undefined4 ******)FUN_008a1240();
              uStack_820._0_4_ = (undefined **)0x64a237;
              piVar17 = (int *)FUN_0063f7f0();
              uStack_8._0_1_ = 0x20;
              uStack_820._4_4_ = (undefined4 ******)0x64a24b;
              FUN_005507b0();
              if (piVar17 != (int *)0x0) {
                uStack_820._4_4_ = (undefined4 ******)0x64a25d;
                (**(code **)(*piVar17 + 0xa4))();
                if (_PTR_018c6f48 < *(double *)(piVar17 + 0x16)) {
                  uStack_820._4_4_ = (undefined4 ******)0x13;
                  uStack_820._0_4_ = (undefined **)0x18d0234;
                  uStack_2dc = 0;
                  uStack_2d8 = 0xf;
                  auStack_2ec[0] = 0;
                  pppppppuStack_824 = (undefined4 *******)0x64a29d;
                  FUN_005542c0();
                  uStack_820._4_4_ = (undefined4 ******)auStack_2ec;
                  uStack_8._0_1_ = 0x2f;
                  uStack_820._0_4_ = (undefined **)0x64a2b0;
                  uStack_820._4_4_ = (undefined4 ******)FUN_008a1240();
                  uStack_820._0_4_ = (undefined **)0x64a2b6;
                  ppppppuStack_28 = (undefined4 ******)FUN_0063f7f0();
                  uStack_8._0_1_ = 0x20;
                  uStack_820._4_4_ = (undefined4 ******)0x64a2cb;
                  FUN_005507b0();
                  if (ppppppuStack_28 != (undefined4 ******)0x0) {
                    uStack_820._4_4_ = (undefined4 ******)0x64a2dc;
                    (*(code *)(*ppppppuStack_28)[0x29])();
                    dStack_68 = *(double *)(ppppppuStack_28 + 0x16);
                    uStack_820._4_4_ = (undefined4 ******)0x64a2f3;
                    (**(code **)(*piVar17 + 0xa4))();
                    uStack_820._4_4_ = (undefined4 ******)apcStack_3ec;
                    apcStack_3ec[0] = "RCCPercentAssembliesSleeping";
                    dStack_3e4 = (double)(float)dStack_68 / *(double *)(piVar17 + 0x16);
                    uStack_820._0_4_ = (undefined **)0x64a328;
                    FUN_0063d230();
                    uStack_820._4_4_ = (undefined4 ******)auStack_628;
                    uStack_8._0_1_ = 0x30;
                    uStack_820._0_4_ = (undefined **)0x64a33b;
                    FUN_00625cd0();
                    uStack_8._0_1_ = 0x20;
                    uStack_820._4_4_ = (undefined4 ******)0x64a34a;
                    FUN_005507b0();
                  }
                  uStack_820._4_4_ = (undefined4 ******)0x19;
                  uStack_820._0_4_ = (undefined **)0x18d0268;
                  uStack_204 = 0;
                  uStack_200 = 0xf;
                  auStack_214[0] = 0;
                  pppppppuStack_824 = (undefined4 *******)0x64a377;
                  FUN_005542c0();
                  uStack_820._4_4_ = (undefined4 ******)auStack_214;
                  uStack_8._0_1_ = 0x31;
                  uStack_820._0_4_ = (undefined **)0x64a38a;
                  uStack_820._4_4_ = (undefined4 ******)FUN_008a1240();
                  uStack_820._0_4_ = (undefined **)0x64a390;
                  ppppppuStack_28 = (undefined4 ******)FUN_0063f7f0();
                  uStack_8._0_1_ = 0x20;
                  uStack_820._4_4_ = (undefined4 ******)0x64a3a5;
                  FUN_005507b0();
                  if (ppppppuStack_28 != (undefined4 ******)0x0) {
                    uStack_820._4_4_ = (undefined4 ******)0x64a3b6;
                    (*(code *)(*ppppppuStack_28)[0x29])();
                    dStack_68 = *(double *)(ppppppuStack_28 + 0x16);
                    uStack_820._4_4_ = (undefined4 ******)0x64a3cd;
                    (**(code **)(*piVar17 + 0xa4))();
                    uStack_820._4_4_ = (undefined4 ******)apcStack_3dc;
                    apcStack_3dc[0] = "RCCPercentAssembliesSleepChecking";
                    dStack_3d4 = (double)(float)dStack_68 / *(double *)(piVar17 + 0x16);
                    uStack_820._0_4_ = (undefined **)0x64a402;
                    FUN_0063d230();
                    uStack_820._4_4_ = (undefined4 ******)auStack_648;
                    uStack_8._0_1_ = 0x32;
                    uStack_820._0_4_ = (undefined **)0x64a415;
                    FUN_00625cd0();
                    uStack_8._0_1_ = 0x20;
                    uStack_820._4_4_ = (undefined4 ******)0x64a424;
                    FUN_005507b0();
                  }
                  uStack_820._4_4_ = (undefined4 ******)0x10;
                  uStack_820._0_4_ = (undefined **)0x18d02a8;
                  uStack_21c = 0;
                  uStack_218 = 0xf;
                  auStack_22c[0] = 0;
                  pppppppuStack_824 = (undefined4 *******)0x64a451;
                  FUN_005542c0();
                  uStack_820._4_4_ = (undefined4 ******)auStack_22c;
                  uStack_8._0_1_ = 0x33;
                  uStack_820._0_4_ = (undefined **)0x64a464;
                  uStack_820._4_4_ = (undefined4 ******)FUN_008a1240();
                  uStack_820._0_4_ = (undefined **)0x64a46a;
                  ppppppuStack_28 = (undefined4 ******)FUN_0063f7f0();
                  uStack_8._0_1_ = 0x20;
                  uStack_820._4_4_ = (undefined4 ******)0x64a47f;
                  FUN_005507b0();
                  if (ppppppuStack_28 != (undefined4 ******)0x0) {
                    uStack_820._4_4_ = (undefined4 ******)0x64a490;
                    (*(code *)(*ppppppuStack_28)[0x29])();
                    dStack_68 = *(double *)(ppppppuStack_28 + 0x16);
                    uStack_820._4_4_ = (undefined4 ******)0x64a4a7;
                    (**(code **)(*piVar17 + 0xa4))();
                    uStack_820._4_4_ = (undefined4 ******)apcStack_41c;
                    apcStack_41c[0] = "RCCPercentAssembliesAwake";
                    dStack_414 = (double)(float)dStack_68 / *(double *)(piVar17 + 0x16);
                    uStack_820._0_4_ = (undefined **)0x64a4dc;
                    FUN_0063d230();
                    uStack_820._4_4_ = (undefined4 ******)auStack_668;
                    uStack_8._0_1_ = 0x34;
                    uStack_820._0_4_ = (undefined **)0x64a4ef;
                    FUN_00625cd0();
                    uStack_8._0_1_ = 0x20;
                    uStack_820._4_4_ = (undefined4 ******)0x64a4fe;
                    FUN_005507b0();
                  }
                }
              }
            }
          }
        }
LAB_0064a4fe:
        uStack_820._4_4_ = (undefined4 ******)0x64a509;
        uVar18 = FUN_00644b60();
        uStack_820._4_4_ = (undefined4 ******)&uStack_90;
        uStack_90 = (double)CONCAT44(uVar18,"AntiBot-FpsBotCount");
        uStack_820._0_4_ = (undefined **)0x64a52b;
        FUN_0063d170();
        uStack_820._4_4_ = (undefined4 ******)auStack_688;
        uStack_8._0_1_ = 0x35;
        uStack_820._0_4_ = (undefined **)0x64a53e;
        FUN_00625cd0();
        uStack_8._0_1_ = 0x20;
        uStack_820._4_4_ = (undefined4 ******)0x64a54d;
        FUN_005507b0();
        uStack_820._0_4_ = (undefined **)pppppppuStack_50;
        pppppppuStack_824 = (undefined4 *******)0x64a556;
        uStack_820._4_4_ = (undefined4 ******)iVar13;
        FUN_00647cb0();
      }
      if (DAT_01d5a080 != '\0') {
        uStack_820._4_4_ = (undefined4 ******)apcStack_42c;
        apcStack_42c[0] = "MaxCoalesceInterval";
        dStack_424 = dStack_16c;
        uStack_820._0_4_ = (undefined **)0x64a595;
        FUN_0063d230();
        uStack_820._4_4_ = (undefined4 ******)auStack_6a8;
        uStack_8._0_1_ = 0x36;
        uStack_820._0_4_ = (undefined **)0x64a5a8;
        FUN_00625cd0();
        uStack_8._0_1_ = 0x20;
        uStack_820._4_4_ = (undefined4 ******)0x64a5b7;
        FUN_005507b0();
        uStack_820._4_4_ = (undefined4 ******)apcStack_43c;
        dStack_434 = dStack_174 + dStack_104;
        apcStack_43c[0] = "TotalPropertyChanges";
        uStack_820._0_4_ = (undefined **)0x64a5eb;
        FUN_0063d230();
        uStack_820._4_4_ = (undefined4 ******)auStack_6c8;
        uStack_8._0_1_ = 0x37;
        uStack_820._0_4_ = (undefined **)0x64a5fe;
        FUN_00625cd0();
        uStack_8._0_1_ = 0x20;
        uStack_820._4_4_ = (undefined4 ******)0x64a60d;
        FUN_005507b0();
        uStack_820._4_4_ = (undefined4 ******)apcStack_44c;
        dStack_444 = dStack_104 + dStack_17c;
        apcStack_44c[0] = "TotalPropertyCoalesces";
        uStack_820._0_4_ = (undefined **)0x64a646;
        dStack_68 = dStack_444;
        FUN_0063d230();
        uStack_820._4_4_ = (undefined4 ******)auStack_6e8;
        uStack_8._0_1_ = 0x38;
        uStack_820._0_4_ = (undefined **)0x64a659;
        FUN_00625cd0();
        uStack_8._0_1_ = 0x20;
        uStack_820._4_4_ = (undefined4 ******)0x64a668;
        FUN_005507b0();
        uStack_820._4_4_ = (undefined4 ******)apcStack_3fc;
        dStack_3f4 = dStack_104 / dStack_68;
        apcStack_3fc[0] = "PreserializationCoalescePercentage";
        uStack_820._0_4_ = (undefined **)0x64a699;
        FUN_0063d230();
        uStack_820._4_4_ = (undefined4 ******)auStack_708;
        uStack_8._0_1_ = 0x39;
        uStack_820._0_4_ = (undefined **)0x64a6ac;
        FUN_00625cd0();
        uStack_8._0_1_ = 0x20;
        uStack_820._4_4_ = (undefined4 ******)0x64a6bb;
        FUN_005507b0();
      }
      uStack_820._0_4_ = (undefined **)&uStack_48;
      uStack_820._4_4_ = (undefined4 ******)0x0;
      pppppppuStack_824 = (undefined4 *******)0x64a6c6;
      FUN_00874d70();
      uStack_820._4_4_ = (undefined4 ******)0x64a6d0;
      FUN_005cf2a0();
      uStack_820 = (double)DAT_01d5a414;
      uStack_844 = 0;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      FUN_0063edb0(&uStack_850,FUN_006480d0,param_1,param_2);
      FUN_0063d3f0();
      uStack_844 = 0x64a734;
      FUN_009eef30();
      uStack_820._4_4_ = (undefined4 ******)0x64a73f;
      FUN_005d1280();
      uStack_820._4_4_ = (undefined4 ******)0x64a74a;
      FUN_005507b0();
      uStack_820._4_4_ = (undefined4 ******)0x64a752;
      FUN_0056d3e0();
      uStack_820._4_4_ = (undefined4 ******)0x64a75d;
      FUN_00640d60();
      uStack_820._4_4_ = (undefined4 ******)0x64a765;
      FUN_0056d3e0();
      uStack_820._4_4_ = (undefined4 ******)0x64a770;
      pppppppuVar11 = (undefined4 *******)FUN_00550b30();
      goto LAB_0064a79e;
    }
  }
  if (piStack_108 != (int *)0x0) {
    LOCK();
    piVar17 = piStack_108 + 1;
    iVar13 = *piVar17;
    pppppppuVar11 = (undefined4 *******)*piVar17;
    *piVar17 = iVar13 + -1;
    UNLOCK();
    if (iVar13 + -1 == 0) {
      uStack_820._4_4_ = (undefined4 ******)0x64a78e;
      (**(code **)*piStack_108)();
      LOCK();
      piVar17 = piStack_108 + 2;
      iVar13 = *piVar17;
      pppppppuVar11 = (undefined4 *******)*piVar17;
      *piVar17 = iVar13 + -1;
      UNLOCK();
      if (iVar13 + -1 == 0) {
        uStack_820._4_4_ = (undefined4 ******)0x64a79e;
        pppppppuVar11 = (undefined4 *******)(**(code **)(*piStack_108 + 4))();
      }
    }
  }
LAB_0064a79e:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar17 = param_2 + 2;
    iVar13 = *piVar17;
    *piVar17 = *piVar17 + -1;
    UNLOCK();
    if (iVar13 == 1) {
      uStack_820._4_4_ = (undefined4 ******)0x64a7b2;
      pppppppuVar11 = (undefined4 *******)(**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pppppppuVar11;
}



/* FUNCTION 7332 ; VA 0x0064a7d0 ; FUN_0064a7d0 */

int FUN_0064a7d0(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iVar4;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_84;
  int iStack_80;
  int *piStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_5c;
  int *piStack_58;
  int aiStack_44 [2];
  int iStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int aiStack_2c [2];
  int iStack_24;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1380;
  pvStack_10 = ExceptionList;
  piStack_58 = &iStack_1c;
  uStack_8 = 0;
  uStack_5c = 0x64a800;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490();
  uStack_8._0_1_ = 1;
  if (iStack_1c != 0) {
    piStack_58 = (int *)0x1;
    piStack_7c = (int *)param_5;
    iStack_80 = 0x64a82f;
    FUN_006400f0();
    uStack_34 = param_3;
    uStack_30 = param_4;
    piStack_7c = aiStack_44;
    uStack_8._0_1_ = 2;
    iStack_80 = 0x64a84b;
    FUN_006400f0();
    puStack_14 = (undefined *)&uStack_90;
    uStack_78 = 0;
    uStack_8._0_1_ = 3;
    uStack_90 = uStack_34;
    uStack_8c = uStack_30;
    FUN_006400f0(aiStack_2c);
    FUN_0063eb20();
    uStack_8._0_1_ = 2;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (aiStack_2c[0] != 0) {
      piStack_7c = (int *)(iStack_24 - aiStack_2c[0]);
      iVar4 = aiStack_2c[0];
      if (0xfff < piStack_7c) {
        iVar4 = *(int *)(aiStack_2c[0] + -4);
        piStack_7c = (int *)((int)piStack_7c + 0x23);
        if (0x1f < (aiStack_2c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          piStack_7c = (int *)0x64a93e;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      uStack_84 = 0x64a8b0;
      iStack_80 = iVar4;
      FUN_01674ea0();
    }
    uStack_8._0_1_ = 1;
    if (aiStack_44[0] != 0) {
      piStack_7c = (int *)(iStack_3c - aiStack_44[0]);
      iVar4 = aiStack_44[0];
      if (0xfff < piStack_7c) {
        iVar4 = *(int *)(aiStack_44[0] + -4);
        piStack_7c = (int *)((int)piStack_7c + 0x23);
        if (0x1f < (aiStack_44[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          piStack_7c = (int *)&UNK_0064a943;
          FUN_017167a3();
        }
      }
      uStack_84 = 0x64a8e4;
      iStack_80 = iVar4;
      FUN_01674ea0();
    }
    piStack_7c = (int *)0x64a8ef;
    iVar4 = FUN_0090ca30();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_58 = (int *)0x64a905;
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_58 = (int *)0x64a915;
        iVar4 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      piStack_58 = (int *)0x64a929;
      iVar4 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 7333 ; VA 0x0064a950 ; FUN_0064a950 */

void * FUN_0064a950(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  undefined8 uVar4;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0d08;
  pvStack_10 = ExceptionList;
  pvVar3 = ExceptionList;
  if (param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar4 = FUN_00928340();
    pvVar3 = (void *)FUN_00644d90(&iStack_18,uVar4);
    uStack_8 = 0;
    if (iStack_18 != 0) {
      pvVar3 = (void *)FUN_006828f0(param_2);
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      pvVar3 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar3 = (void *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar3 = (void *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 7334 ; VA 0x0064a9e0 ; FUN_0064a9e0 */

undefined4 FUN_0064a9e0(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      piVar3 = (int *)FUN_00564290();
      return CONCAT31((int3)((uint)*piVar3 >> 8),*piVar3 != 0);
    }
  }
  return 0;
}



/* FUNCTION 7335 ; VA 0x0064aa50 ; FUN_0064aa50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0064aa50(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  char cVar2;
  int *piVar3;
  undefined4 **ppuVar4;
  uint uVar5;
  int iVar6;
  double *pdVar7;
  int iVar8;
  undefined4 uVar9;
  undefined2 *puVar10;
  undefined4 *puVar11;
  int *piVar12;
  undefined auStack_234 [4];
  undefined4 uStack_230;
  undefined auStack_22c [12];
  undefined4 uStack_220;
  undefined4 uStack_21c;
  int iStack_218;
  undefined4 uStack_214;
  undefined1 *puStack_210;
  char *pcStack_20c;
  int iStack_208;
  code *pcStack_204;
  undefined *puStack_200;
  undefined8 uStack_1fc;
  undefined *puStack_1f4;
  undefined *puStack_1f0;
  uint uStack_1ec;
  undefined2 *puStack_1e8;
  char *pcStack_1e4;
  char *pcStack_1e0;
  undefined2 auStack_1d4 [36];
  undefined2 auStack_18c [36];
  undefined auStack_144 [32];
  undefined auStack_124 [32];
  undefined auStack_104 [24];
  undefined auStack_ec [24];
  undefined auStack_d4 [40];
  int aiStack_ac [5];
  uint uStack_98;
  undefined auStack_94 [8];
  undefined auStack_8c [12];
  undefined auStack_80 [12];
  undefined auStack_74 [12];
  undefined auStack_68 [12];
  undefined auStack_5c [12];
  int *piStack_50;
  int *piStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined2 *puStack_40;
  int iStack_3c;
  undefined4 uStack_34;
  int iStack_30;
  int iStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a13e4;
  pvStack_10 = ExceptionList;
  pcStack_1e0 = (char *)DAT_01eadc98;
  pcStack_1e4 = (char *)0x64aa80;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  uStack_34 = FUN_01675290();
  pcStack_1e4 = (char *)0x1;
  uStack_8 = 0;
  uStack_1ec = 0x64aa92;
  puStack_1e8 = (undefined2 *)param_1;
  cVar2 = FUN_00973950();
  if (cVar2 != '\0') {
    pcStack_1e4 = auStack_5c;
    pcStack_1e0 = "Can not call server, client is present.";
    puStack_1e8 = (undefined2 *)0x64b0ec;
    FUN_016756b0();
    pcStack_1e4 = auStack_5c;
    pcStack_1e0 = "";
                    /* WARNING: Subroutine does not return */
    puStack_1e8 = (undefined2 *)0x64b0fd;
    FUN_0170c2a8();
  }
  if (DAT_01ee420a != 0) {
    pcStack_1e0 = (char *)0x0;
    puStack_1e8 = (undefined2 *)(uint)DAT_01ee420a;
    pcStack_1e4 = "NetworkServer:Start";
    uStack_1ec = 0x64aab6;
    FUN_016774b0();
  }
  if (DAT_01d59d40 != '\0') {
    pcStack_1e0 = (char *)0x64aacd;
    piVar3 = (int *)FUN_0054db20();
    pcStack_1e0 = (char *)param_4;
    pcStack_1e4 = (char *)0x64aadc;
    (**(code **)(*piVar3 + 0x170))();
  }
  puStack_28 = (undefined4 *)0x0;
  puStack_24 = (undefined4 *)0x0;
  puStack_20 = (undefined4 *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (DAT_01d5a538 == '\0') {
    pcStack_1e0 = (char *)0x0;
    pcStack_1e4 = (char *)param_2;
    if (DAT_01d5a530 == '\0') {
      puStack_1e8 = (undefined2 *)0x64ac95;
      FUN_005f70d0();
      pcStack_1e0 = (char *)0x64aca0;
      piVar3 = (int *)FUN_0054db20();
      pcStack_1e0 = (char *)0xfffe7961;
      pcStack_1e4 = (char *)0x1;
      puStack_1e8 = auStack_1d4;
      uStack_1ec = (uint)DAT_01d5a400;
      puStack_1f0 = (undefined *)0x64acbf;
      param_4 = (undefined4 *)(**(code **)(*piVar3 + 4))();
    }
    else {
      puStack_1e8 = (undefined2 *)0x64ac58;
      FUN_005f70d0();
      pcStack_1e0 = (char *)0x64ac63;
      piVar3 = (int *)FUN_0054db20();
      pcStack_1e0 = (char *)0xfffe7961;
      pcStack_1e4 = (char *)0x1;
      puStack_1e8 = auStack_18c;
      uStack_1ec = (uint)DAT_01d5a400;
      puStack_1f0 = (undefined *)0x64ac82;
      param_4 = (undefined4 *)(**(code **)(*piVar3 + 4))();
      param_1 = piStack_18;
    }
  }
  else {
    pcStack_1e0 = auStack_68;
    pcStack_1e4 = (char *)0x64ab0b;
    ppuVar4 = (undefined4 **)FUN_00644030();
    param_4 = (undefined4 *)0x0;
    puStack_14 = (undefined4 *)0x0;
    puVar11 = (undefined4 *)0x0;
    if (&puStack_28 != ppuVar4) {
      pcStack_1e0 = (char *)0x64ab2c;
      FUN_00577a40();
      puStack_24 = ppuVar4[1];
      puVar11 = *ppuVar4;
      puStack_20 = ppuVar4[2];
      *ppuVar4 = (undefined4 *)0x0;
      ppuVar4[1] = (undefined4 *)0x0;
      ppuVar4[2] = (undefined4 *)0x0;
      puStack_28 = puVar11;
      puStack_14 = puStack_24;
    }
    pcStack_1e0 = (char *)0x64ab5f;
    param_4 = puStack_14;
    FUN_00577a40();
    pcStack_1e0 = (char *)((int)&param_4 + 3);
    puVar1 = (undefined4 *)(((int)param_4 - (int)puVar11) / 0x18);
    puStack_1e8 = (undefined2 *)0x64ab82;
    pcStack_1e4 = (char *)puVar1;
    FUN_006401b0();
    uStack_8._0_1_ = 2;
    param_4 = (undefined4 *)0x0;
    if (puVar1 != (undefined4 *)0x0) {
      puStack_14 = (undefined4 *)(((int)puStack_14 - (int)puVar11) / 0x18);
      puVar10 = puStack_40;
      do {
        *puVar10 = (short)param_2;
        pcStack_1e4 = (char *)puVar11;
        if (0xf < (uint)puVar11[5]) {
          pcStack_1e4 = (char *)*puVar11;
        }
        pcStack_1e0 = (char *)0x41;
        puStack_1e8 = puVar10 + 1;
        uStack_1ec = 0x64abcc;
        FUN_0171dd10();
        param_4 = (undefined4 *)((int)param_4 + 1);
        puVar10 = puVar10 + 0x23;
        puVar11 = puVar11 + 6;
      } while (param_4 < puStack_14);
    }
    pcStack_1e0 = (char *)0x64abef;
    piVar3 = (int *)FUN_0054db20();
    pcStack_1e0 = (char *)0xfffe7961;
    uStack_1ec = (uint)DAT_01d5a400;
    pcStack_1e4 = (char *)((iStack_3c - (int)puStack_40) / 0x46);
    puStack_1e8 = puStack_40;
    puStack_1f0 = (undefined *)0x64ac24;
    param_4 = (undefined4 *)(**(code **)(*piVar3 + 4))();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puStack_1f0 = (undefined *)0x64ac33;
    FUN_00642960();
    param_1 = piStack_18;
  }
  if (param_4 != (undefined4 *)0x0) {
    puStack_1f0 = (undefined *)param_2;
    uStack_1fc = (double)CONCAT44(0x64acd0,(undefined4)uStack_1fc);
    puStack_1f4 = (undefined *)param_4;
    FUN_00647e60();
    if (DAT_01d5b140 != '\0') {
      puStack_1f0 = (&PTR_s_RAKNET_STARTED_01d5a468)[(int)param_4];
      puStack_1f4 = (undefined *)param_2;
      uStack_1fc = (double)CONCAT44("Failed to start network server, port:%d, error:%s",auStack_ec);
      puStack_200 = (undefined *)0x64b116;
      puStack_1f0 = (undefined *)FUN_01675640();
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      puStack_1f4 = (undefined *)0x64b126;
      FUN_005500e0();
      puStack_1f0 = &DAT_01c17198;
      puStack_1f4 = auStack_74;
      uStack_1fc = (double)CONCAT44(0x64b134,(undefined4)uStack_1fc);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8();
    }
    puStack_1f0 = (undefined *)param_4;
    puStack_1f4 = (undefined *)param_2;
    uStack_1fc = (double)CONCAT44("Failed to start network server, port:%d, error id:%d",auStack_104
                                 );
    puStack_200 = (undefined *)0x64b147;
    puStack_1f0 = (undefined *)FUN_01675640();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    puStack_1f4 = (undefined *)0x64b157;
    FUN_005500e0();
    puStack_1f0 = &DAT_01c17198;
    puStack_1f4 = auStack_80;
    uStack_1fc = (double)CONCAT44(0x64b165,(undefined4)uStack_1fc);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8();
  }
  puStack_1f0 = (undefined *)0x64acf3;
  piVar3 = (int *)FUN_0054db20();
  puStack_1f0 = (undefined *)0x0;
  puStack_1f4 = auStack_124;
  uStack_1fc = (double)CONCAT44(0x64ad08,(undefined4)uStack_1fc);
  (**(code **)(*piVar3 + 0xbc))();
  uStack_1fc = (double)CONCAT44(0x64ad0f,(undefined4)uStack_1fc);
  uVar5 = FUN_005f7810();
  *(uint *)((int)param_1 + 0x104) = uVar5 & 0xffff;
  if (DAT_01d84e8d != 0) {
    uStack_1fc = (double)CONCAT44(0x64ad30,(undefined4)uStack_1fc);
    piVar3 = (int *)FUN_0054db20();
    uStack_1fc = 2.63127478080188e-312;
    puStack_200 = (undefined *)0x0;
    pcStack_204 = (code *)auStack_144;
    iStack_208 = 0x64ad49;
    puStack_200 = (undefined *)(**(code **)(*piVar3 + 0xbc))();
    pcStack_204 = (code *)aiStack_ac;
    iStack_208 = 0x64ad56;
    puVar11 = (undefined4 *)FUN_006b1620();
    uStack_8._0_1_ = 5;
    if (0xf < (uint)puVar11[5]) {
      puVar11 = (undefined4 *)*puVar11;
    }
    puStack_200 = (undefined *)(uint)DAT_01d84e8d;
    uStack_1fc = (double)CONCAT44(puVar11,"Started network server %s");
    pcStack_204 = (code *)0x64ad78;
    FUN_01677520();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_98) {
      uVar5 = uStack_98 + 1;
      iVar6 = aiStack_ac[0];
      if (0xfff < uVar5) {
        iVar6 = *(int *)(aiStack_ac[0] + -4);
        uVar5 = uStack_98 + 0x24;
        if (0x1f < (aiStack_ac[0] - iVar6) - 4U) {
          uStack_1fc = (double)CONCAT44(0x64b16a,(undefined4)uStack_1fc);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_1fc = (double)CONCAT44(uVar5,iVar6);
      puStack_200 = (undefined *)0x64adb6;
      FUN_01674ea0();
    }
  }
  uStack_1fc._0_4_ = 0x64adbf;
  uStack_1fc._4_4_ = (uint)param_1;
  iVar6 = FUN_008f7870();
  uStack_1fc = (double)CONCAT44(uStack_1fc._4_4_,auStack_94);
  uStack_48 = *(undefined4 *)(iVar6 + 600);
  uStack_44 = *(undefined4 *)(iVar6 + 0x25c);
  puStack_200 = (undefined *)0x64ade2;
  iStack_30 = iVar6;
  pdVar7 = (double *)FUN_016830f0();
  puStack_200 = (undefined *)0x0;
  pcStack_204 = (code *)&DAT_018ccd30;
  iStack_208 = (int)((*pdVar7 - (double)CONCAT44(uStack_44,uStack_48)) * DAT_018c0d70);
  pcStack_20c = "ServerStartTime";
  puStack_210 = &DAT_018c5f98;
  uStack_214 = 0x64ae0e;
  FUN_0087c7b0();
  if (DAT_01d65328 != '\0') {
    uStack_1fc = (double)CONCAT44(0x64ae25,(undefined4)uStack_1fc);
    piVar3 = (int *)FUN_0054db20();
    iStack_218 = 600000;
    uStack_214 = _DAT_01ead6cc;
    puStack_210 = puRam01ead6d0;
    pcStack_20c = pcRam01ead6d4;
    iStack_208 = iRam01ead6d8;
    pcStack_204 = (code *)_DAT_01ead6dc;
    puStack_200 = (undefined *)uRam01ead6e0;
    uStack_1fc = (double)CONCAT44(uRam01ead6e8,uRam01ead6e4);
    uStack_21c = 0x64ae50;
    (**(code **)(*piVar3 + 0xcc))();
  }
  if (*(int *)((int)param_1 + 0x124) == 2) {
    uStack_1fc = (double)CONCAT44(0x64ae64,(undefined4)uStack_1fc);
    piVar3 = (int *)FUN_0054db20();
    iStack_218 = DAT_01d5afc4 * 1000;
    uStack_214 = _DAT_01ead6cc;
    puStack_210 = puRam01ead6d0;
    pcStack_20c = pcRam01ead6d4;
    iStack_208 = iRam01ead6d8;
    pcStack_204 = (code *)_DAT_01ead6dc;
    puStack_200 = (undefined *)uRam01ead6e0;
    uStack_1fc = (double)CONCAT44(uRam01ead6e8,uRam01ead6e4);
    uStack_21c = 0x64ae95;
    (**(code **)(*piVar3 + 0xcc))();
  }
  uStack_1fc = (double)CONCAT44(iVar6,0x64ae9b);
  FUN_00646d00();
  iStack_2c = iVar6 + 0xc;
  uStack_1fc = (double)CONCAT44(0x64aeab,(undefined4)uStack_1fc);
  puVar11 = (undefined4 *)FUN_005cf2a0();
  uStack_1fc = (double)DAT_01d5a40c;
  uStack_220 = 0;
  FUN_0060e0c0(auStack_234,piStack_18);
  FUN_0063edb0(auStack_22c,FUN_006480d0);
  uStack_230 = 0x64aef3;
  FUN_0063d3f0();
  uStack_220 = 0x64aefb;
  FUN_009eef30();
  piVar3 = piStack_18;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  puStack_14 = *(undefined4 **)((int)piVar3 + 0x42c);
  iVar6 = puStack_14[1];
  uStack_1fc._4_4_ = 0;
  if (iVar6 != 0) {
    piVar12 = (int *)(iVar6 + 4);
    iVar6 = *(int *)(iVar6 + 4);
    while (iVar6 != 0) {
      LOCK();
      iVar8 = *piVar12;
      if (iVar6 == iVar8) {
        *piVar12 = iVar6 + 1;
        iVar8 = iVar6;
      }
      UNLOCK();
      if (iVar8 == iVar6) {
        puStack_200 = (undefined *)*puStack_14;
        piVar12 = (int *)puStack_14[1];
        uStack_8._0_1_ = 6;
        if (piVar12 != (int *)0x0) {
          LOCK();
          piVar12[2] = piVar12[2] + 1;
          UNLOCK();
        }
        pcStack_204 = FUN_007190d0;
        uStack_1fc = (double)ZEXT48(piVar12);
        iStack_208 = 0x64af87;
        uStack_1c = puStack_200;
        piStack_18 = piVar12;
        FUN_0063d040();
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        uStack_1fc = (double)CONCAT44(0x64af93,(undefined4)uStack_1fc);
        FUN_016899e0();
        param_4 = puVar11;
        if (puVar11 != (undefined4 *)0x0) {
          LOCK();
          iVar6 = puVar11[1] + -1;
          puVar11[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            uStack_1fc._4_4_ = 0;
            uStack_1fc._0_4_ = 0x64afad;
            (**(code **)*puVar11)();
            uStack_1fc = (double)CONCAT44(uStack_1fc._4_4_,param_4);
            puStack_200 = (undefined *)0x0;
            pcStack_204 = (code *)0x64afb8;
            pcStack_204 = (code *)GetProcessHeap();
            iStack_208 = 0x64afbf;
            HeapFree();
          }
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (piVar12 != (int *)0x0) {
          LOCK();
          iVar6 = piVar12[1] + -1;
          piVar12[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            uStack_1fc = (double)CONCAT44(0x64afd7,(undefined4)uStack_1fc);
            (**(code **)*piVar12)();
            LOCK();
            iVar6 = piVar12[2] + -1;
            piVar12[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              uStack_1fc = (double)CONCAT44(0x64afe8,(undefined4)uStack_1fc);
              (**(code **)(*piVar12 + 4))();
            }
          }
        }
        uStack_1fc = (double)CONCAT44(0x64aff0,(undefined4)uStack_1fc);
        piVar12 = (int *)FUN_00564130();
        iVar6 = iStack_30;
        if (*piVar12 != 0) {
          *(undefined8 *)((int)piVar3 + 0x3b0) = *(undefined8 *)(*piVar12 + 0x80);
        }
        uStack_1fc = (double)CONCAT44(0x64b010,(undefined4)uStack_1fc);
        uVar9 = FUN_008f7c50();
        *(undefined4 *)((int)piVar3 + 0x3ac) = uVar9;
        param_4 = (undefined4 *)((int)piVar3 + 0x128);
        if (*(char *)(*(int *)(iVar6 + 0x1b8) + 0x300) != '\0') {
          uStack_1fc = (double)CONCAT44(iVar6,0x64b037);
          FUN_006d9900();
        }
        uStack_1fc = (double)CONCAT44(&piStack_50,0x64b042);
        FUN_006448b0();
        uStack_8._0_1_ = 8;
        uStack_1fc = (double)CONCAT44(0x64b052,(undefined4)uStack_1fc);
        uVar5 = (**(code **)(*piStack_50 + 8))();
        uStack_1fc = (double)CONCAT44(0x64b05d,(undefined4)uStack_1fc);
        puStack_200 = (undefined *)(**(code **)(*piStack_50 + 4))();
        uStack_1fc = (double)(ulonglong)uVar5;
        pcStack_204 = (code *)0x64b06c;
        FUN_006ab380();
        uStack_8 = CONCAT31(uStack_8._1_3_,9);
        uStack_1fc = (double)CONCAT44(auStack_d4,0x64b07f);
        FUN_006d98e0();
        uStack_1fc = (double)CONCAT44(0x64b08a,(undefined4)uStack_1fc);
        FUN_00613200();
        if (piStack_4c != (int *)0x0) {
          LOCK();
          iVar6 = piStack_4c[1] + -1;
          piStack_4c[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            uStack_1fc = (double)CONCAT44(0x64b0a3,(undefined4)uStack_1fc);
            (**(code **)*piStack_4c)();
            LOCK();
            piVar3 = piStack_4c + 2;
            iVar6 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar6 == 1) {
              uStack_1fc = (double)CONCAT44(0x64b0b2,(undefined4)uStack_1fc);
              (**(code **)(*piStack_4c + 4))();
            }
          }
        }
        uStack_1fc = (double)CONCAT44(0x64b0ba,(undefined4)uStack_1fc);
        FUN_00577a40();
        uStack_8 = 10;
        uStack_1fc = (double)CONCAT44(uStack_34,0x64b0c9);
        FUN_01675290();
        ExceptionList = pvStack_10;
        return;
      }
      iVar6 = *piVar12;
    }
  }
  uStack_1fc._0_4_ = 0x64b175;
  FUN_005c47d0();
  uStack_1fc = (double)CONCAT44(uStack_1fc._4_4_,&DAT_01c21d80);
  puStack_200 = auStack_8c;
                    /* WARNING: Subroutine does not return */
  pcStack_204 = (code *)&UNK_0064b186;
  FUN_0170c2a8();
}



/* FUNCTION 7336 ; VA 0x0064b190 ; FUN_0064b190 */

undefined4 __fastcall FUN_0064b190(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  double *pdVar5;
  int iVar6;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795cf8;
  pvStack_10 = ExceptionList;
  if (DAT_01d5a508 == '\0') {
    return 1;
  }
  if (DAT_01d5a510 == '\0') {
    if ((*(char *)(param_1 + 0x146) == '\0') && (*(char *)(param_1 + 0x147) == '\0')) {
      return 0;
    }
  }
  else if ((*(char *)(param_1 + 0x146) == '\0') && (*(char *)(param_1 + 0x14a) == '\0')) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if ((iStack_18 == 0) || (FUN_0064b600(&iStack_18), DAT_01d5a510 == '\0')) goto LAB_0064b345;
  if (*(char *)(param_1 + 0x148) == '\0') {
    if (*(char *)(param_1 + 0x149) != '\0') {
      pdVar5 = (double *)FUN_01682800(&uStack_20);
      if (((double)DAT_01ead6c0 <= (*pdVar5 - *(double *)(param_1 + 0x158)) * DAT_018c0d70) &&
         (*(int *)(param_1 + 0x160) < DAT_01ead6bc)) {
        iVar2 = *(int *)(*(int *)(param_1 + 0x134) +
                        (*(uint *)(param_1 + 0x140) %
                        (uint)(*(int *)(param_1 + 0x138) - *(int *)(param_1 + 0x134) >> 2)) * 4);
        iVar6 = 0;
        if (0 < iVar2) {
          do {
            FUN_006434a0(&iStack_18,0x11b);
            iVar4 = DAT_01ead6bc;
            iVar3 = *(int *)(param_1 + 0x160);
            *(int *)(param_1 + 0x160) = iVar3 + 1;
            if (iVar4 < iVar3) break;
            iVar6 = iVar6 + 1;
          } while (iVar6 < iVar2);
        }
        *(int *)(param_1 + 0x140) = *(int *)(param_1 + 0x140) + 1;
        FUN_01682800(&uStack_20);
        *(undefined4 *)(param_1 + 0x158) = uStack_20;
        *(undefined4 *)(param_1 + 0x15c) = uStack_1c;
      }
      goto LAB_0064b323;
    }
  }
  else {
LAB_0064b323:
    if (*(char *)(param_1 + 0x149) != '\0') goto LAB_0064b345;
  }
  if (*(char *)(param_1 + 0x14a) != '\0') {
    FUN_006434a0(&iStack_18,0x113);
  }
LAB_0064b345:
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 7337 ; VA 0x0064b390 ; FUN_0064b390 */

void __thiscall FUN_0064b390(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  undefined auStack_10 [12];
  
  cVar3 = FUN_00973950(param_1,1);
  if (cVar3 == '\0') {
    if (DAT_01ee420a != '\0') {
      FUN_016774b0(DAT_01ee420a,"NetworkServer:Stop blockDuration(%d)",param_2);
    }
    puVar4 = *(undefined4 **)(param_1 + 0x2c);
    if (puVar4 != (undefined4 *)0x0) {
      piVar6 = *(int **)(param_1 + 0x30);
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        puVar4 = *(undefined4 **)(param_1 + 0x2c);
        piVar6 = *(int **)(param_1 + 0x30);
      }
      piVar1 = (int *)puVar4[1];
      for (piVar5 = (int *)*puVar4; piVar5 != piVar1; piVar5 = piVar5 + 2) {
        *(undefined *)(*piVar5 + 0x22) = 0;
      }
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar2 = piVar6[1] + -1;
        piVar6[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
    FUN_008a50b0();
    piVar6 = (int *)FUN_0054db20();
    cVar3 = (**(code **)(*piVar6 + 0x38))();
    if (cVar3 != '\0') {
      piVar6 = (int *)FUN_0054db20();
      (**(code **)(*piVar6 + 0x34))(param_2,0,3);
    }
    return;
  }
  FUN_016756b0(auStack_10,"Can not call server, client is present.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 7338 ; VA 0x0064b490 ; FUN_0064b490 */

int * __thiscall FUN_0064b490(int param_1,int param_2,int *param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  bool bVar7;
  int *piVar8;
  int *piStack_8;
  
  bVar7 = false;
  piStack_8 = (int *)0x0;
  iVar4 = param_1 + 0x415 + (uint)*(byte *)(param_1 + 0x414);
  piVar2 = param_3;
  if (((int)param_3 < 1) && ((int)param_3 < 0)) {
    piVar2 = (int *)~(uint)param_3;
  }
  piVar2 = (int *)FUN_00606ff0(&piStack_8,
                               ((uint)piVar2 >> 2) + (int)piVar2 * 0x40 + param_2 ^ (uint)piVar2,
                               &param_2,-(uint)(iVar4 != 0) & iVar4 + 1U);
  piVar1 = piStack_8;
  if (piStack_8 != (int *)0x0) {
    piVar3 = (int *)FUN_00587490(&param_2);
    piVar2 = param_4;
    bVar7 = true;
    param_4 = (int *)CONCAT13(1,param_4._0_3_);
    if (*piVar3 == *piVar2) goto LAB_0064b51d;
  }
  param_4 = (int *)((uint)param_4 & 0xffffff);
LAB_0064b51d:
  piVar3 = param_3;
  if ((bVar7) && (param_3 != (int *)0x0)) {
    LOCK();
    piVar8 = param_3 + 1;
    iVar4 = *piVar8;
    piVar2 = (int *)*piVar8;
    *piVar8 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar8 = piVar3 + 2;
      iVar4 = *piVar8;
      piVar2 = (int *)*piVar8;
      *piVar8 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        piVar2 = (int *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_4._3_1_ != '\0') {
    param_3 = (int *)*piVar1;
    uVar5 = (uint)piVar1[1] % *(uint *)(param_1 + 0x418);
    piVar3 = *(int **)(*(int *)(param_1 + 0x428) + uVar5 * 4);
    for (piVar8 = (int *)*piVar3; piVar8 != piVar1; piVar8 = (int *)*piVar8) {
      piVar3 = piVar8;
    }
    do {
      *piVar3 = *piVar8;
      piVar2 = (int *)piVar8[5];
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      FUN_01674ea0(piVar8,0x18);
      *(int *)(param_1 + 0x41c) = *(int *)(param_1 + 0x41c) + -1;
      uVar6 = uVar5;
      if (*piVar3 == 0) {
LAB_0064b5ce:
        piVar2 = *(int **)(param_1 + 0x428);
        if ((int *)piVar2[uVar5] == piVar3) {
          piVar2[uVar5] = 0;
        }
      }
      else {
        uVar6 = *(uint *)(*piVar3 + 4);
        piVar2 = (int *)(uVar6 / *(uint *)(param_1 + 0x418));
        uVar6 = uVar6 % *(uint *)(param_1 + 0x418);
        if (uVar5 != uVar6) {
          *(int **)(*(int *)(param_1 + 0x428) + uVar6 * 4) = piVar3;
          goto LAB_0064b5ce;
        }
      }
      piVar8 = (int *)*piVar3;
      uVar5 = uVar6;
    } while (piVar8 != param_3);
  }
  return piVar2;
}



/* FUNCTION 7339 ; VA 0x0064b600 ; FUN_0064b600 */

void __fastcall FUN_0064b600(int param_1)

{
  int iVar1;
  double *pdVar2;
  int *piVar3;
  undefined4 uStack_10;
  int *piStack_c;
  int iStack_8;
  
  iStack_8 = 0;
  piStack_c = *(int **)(*(int *)(param_1 + 0x130) + 0x1c0);
  piVar3 = *(int **)(*(int *)(param_1 + 0x130) + 0x1bc);
  if (piVar3 != piStack_c) {
    do {
      if (*(char *)(param_1 + 0x144) != '\0') {
        *(undefined *)(param_1 + 0x144) = 0;
        FUN_00909d80(2);
      }
      if ((*(char *)(param_1 + 0x145) != '\0') && (*(char *)(*piVar3 + 0x18ec) != '\0')) {
        *(undefined *)(param_1 + 0x145) = 0;
        FUN_00909d80(3);
      }
      iVar1 = iStack_8 + 1;
      if (*(char *)(*piVar3 + 0x18ed) == '\0') {
        iVar1 = iStack_8;
      }
      piVar3 = piVar3 + 1;
      iStack_8 = iVar1;
    } while (piVar3 != piStack_c);
  }
  iVar1 = FUN_008fba30();
  if ((*(char *)(param_1 + 0x146) != '\0') && (DAT_01ead6b0 <= iVar1)) {
    *(undefined *)(param_1 + 0x146) = 0;
    FUN_00909d80(4);
  }
  if ((*(char *)(param_1 + 0x147) != '\0') && (DAT_01ead6b4 <= iStack_8)) {
    *(undefined *)(param_1 + 0x147) = 0;
    FUN_00909d80(5);
    FUN_01682800(&uStack_10);
    *(undefined4 *)(param_1 + 0x150) = uStack_10;
    *(int **)(param_1 + 0x154) = piStack_c;
  }
  if (DAT_01d5a510 == '\0') {
    return;
  }
  if (*(char *)(param_1 + 0x147) == '\0') {
    if (*(char *)(param_1 + 0x148) != '\0') {
      pdVar2 = (double *)FUN_01682800(&uStack_10);
      if ((double)DAT_01ead6b8 <= *pdVar2 - *(double *)(param_1 + 0x150)) {
        *(undefined *)(param_1 + 0x148) = 0;
        FUN_00909d80(6);
        FUN_01682800(&uStack_10);
        *(undefined4 *)(param_1 + 0x158) = uStack_10;
        *(int **)(param_1 + 0x15c) = piStack_c;
      }
      goto LAB_0064b770;
    }
LAB_0064b779:
    if (*(char *)(param_1 + 0x149) == '\0') goto LAB_0064b7b1;
    if ((DAT_01ead6bc <= *(int *)(param_1 + 0x160)) && (DAT_01ead6b0 <= iVar1)) {
      *(undefined *)(param_1 + 0x149) = 0;
      FUN_00909d80(7);
    }
  }
  else {
LAB_0064b770:
    if (*(char *)(param_1 + 0x148) == '\0') goto LAB_0064b779;
  }
  if (*(char *)(param_1 + 0x149) != '\0') {
    return;
  }
LAB_0064b7b1:
  if ((*(char *)(param_1 + 0x14a) != '\0') && (iVar1 == 0)) {
    *(undefined *)(param_1 + 0x14a) = 0;
    FUN_00909d80(8);
  }
  return;
}



/* FUNCTION 7340 ; VA 0x0064b7e0 ; FUN_0064b7e0 */

void __thiscall FUN_0064b7e0(undefined4 param_1,undefined4 param_2)

{
  FUN_008aa1e0(param_1,param_2);
  return;
}



/* FUNCTION 7341 ; VA 0x0064b800 ; FUN_0064b800 */

undefined4 * __thiscall
FUN_0064b800(undefined4 *param_1,int param_2,int param_3,undefined4 *param_4,undefined4 param_5,
            uint param_6,undefined4 param_7)

{
  uint uVar1;
  undefined4 uVar2;
  undefined **ppuVar3;
  undefined4 ***pppuVar4;
  undefined *puStack_58;
  undefined4 **ppuStack_54;
  undefined4 **ppuStack_50;
  undefined4 **ppuStack_4c;
  undefined4 **appuStack_3c [2];
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 **appuStack_2c [2];
  uint uStack_24;
  undefined4 uStack_20;
  undefined *puStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_6;
  puStack_c = &LAB_017a1410;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = param_6;
  appuStack_3c[0] = (undefined4 ***)0x0;
  puStack_18 = param_1;
  if (param_6 < 9) {
    ppuStack_54 = appuStack_3c;
    ppuStack_50 = &param_4;
    ExceptionList = &pvStack_10;
  }
  else {
    ppuStack_4c = (undefined4 **)param_6;
    ppuStack_50 = (undefined4 **)0x64b84a;
    ExceptionList = &pvStack_10;
    ppuStack_54 = (undefined4 **)FUN_01674e20();
    ppuStack_50 = (undefined4 **)param_4;
    appuStack_3c[0] = ppuStack_54;
  }
  ppuStack_4c = (undefined4 **)uVar1;
  puStack_58 = (undefined *)0x64b85b;
  FUN_0170c6f0();
  uVar1 = uStack_34;
  uVar2 = param_7;
  uStack_14 = param_7;
  uStack_30 = param_7;
  uStack_8._0_1_ = 1;
  uStack_24 = uStack_34;
  appuStack_2c[0] = (undefined4 ***)0x0;
  if (uStack_34 < 9) {
    ppuStack_54 = appuStack_2c;
    ppuStack_50 = appuStack_3c;
  }
  else {
    ppuStack_4c = (undefined4 **)uStack_34;
    ppuStack_50 = (undefined4 **)0x64b88b;
    ppuStack_54 = (undefined4 **)FUN_01674e20();
    ppuStack_50 = appuStack_3c[0];
    appuStack_2c[0] = ppuStack_54;
  }
  ppuStack_4c = (undefined4 **)uVar1;
  puStack_58 = (undefined *)0x64b89c;
  FUN_0170c6f0();
  uStack_20 = uVar2;
  *param_1 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_1c = (undefined *)&puStack_58;
  ppuVar3 = &puStack_58;
  ppuStack_50 = (undefined4 **)uStack_24;
  puStack_58 = (undefined *)0x0;
  if (uStack_24 < 9) {
    pppuVar4 = appuStack_2c;
    puStack_1c = (undefined *)&puStack_58;
  }
  else {
    ppuVar3 = (undefined **)FUN_01674e20(uStack_24);
    pppuVar4 = (undefined4 ***)appuStack_2c[0];
    puStack_58 = (undefined *)ppuVar3;
  }
  FUN_0170c6f0(ppuVar3,pppuVar4,ppuStack_50);
  ppuStack_4c = (undefined4 **)uStack_14;
  FUN_0064dee0();
  if ((8 < uStack_24) && ((undefined4 ***)appuStack_2c[0] != (undefined4 ***)0x0)) {
    ppuStack_4c = appuStack_2c[0];
    ppuStack_50 = (undefined4 **)0x64b905;
    FUN_01674ea0();
  }
  if ((8 < uVar1) && ((undefined4 ***)appuStack_3c[0] != (undefined4 ***)0x0)) {
    ppuStack_4c = appuStack_3c[0];
    ppuStack_50 = (undefined4 **)0x64b91a;
    FUN_01674ea0();
  }
  param_1[8] = param_2;
  param_1[9] = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  param_1[10] = param_2;
  param_1[0xb] = param_3;
  *(undefined *)(param_1 + 0xc) = 0;
  if (param_2 != param_3) {
    ppuStack_4c = (undefined4 **)0x64b942;
    FUN_00645080();
  }
  if ((8 < param_6) && (param_4 != (undefined4 *)0x0)) {
    ppuStack_4c = (undefined4 **)param_4;
    ppuStack_50 = (undefined4 **)0x64b955;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7342 ; VA 0x0064b970 ; FUN_0064b970 */

undefined4 * __thiscall FUN_0064b970(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_018d4e64;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 7343 ; VA 0x0064baa0 ; FUN_0064baa0 */

undefined4 * __thiscall FUN_0064baa0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 in_stack_000000b4;
  int *in_stack_000000b8;
  undefined auStack_248 [176];
  undefined4 uStack_198;
  int *piStack_194;
  undefined4 *puStack_190;
  undefined auStack_184 [176];
  undefined4 uStack_d4;
  int *piStack_d0;
  undefined auStack_cc [176];
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a143e;
  pvStack_10 = ExceptionList;
  puStack_190 = (undefined4 *)&stack0x00000004;
  uStack_8 = 0;
  piStack_194 = (int *)0x64badb;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00650eb0();
  if (in_stack_000000b8 != (int *)0x0) {
    LOCK();
    in_stack_000000b8[2] = in_stack_000000b8[2] + 1;
    UNLOCK();
  }
  uStack_d4 = in_stack_000000b4;
  piStack_d0 = in_stack_000000b8;
  puStack_190 = (undefined4 *)auStack_184;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  piStack_194 = (int *)0x64bb31;
  FUN_00650eb0();
  if (piStack_d0 != (int *)0x0) {
    LOCK();
    piStack_d0[2] = piStack_d0[2] + 1;
    UNLOCK();
  }
  uStack_1c = uStack_d4;
  piStack_18 = piStack_d0;
  puStack_190 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = (undefined4 *)auStack_248;
  FUN_00650eb0(auStack_cc);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[2] = piStack_18[2] + 1;
    UNLOCK();
  }
  uStack_198 = uStack_1c;
  piStack_194 = piStack_18;
  ppuVar4 = &PTR_FUN_018d4e6c;
  cVar3 = FUN_0064e0b0();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[2] + -1;
    piStack_18[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_190 = (undefined4 *)0x64bbde;
      (**(code **)(*piStack_18 + 4))();
    }
  }
  puStack_190 = (undefined4 *)0x64bbe9;
  FUN_00651d50();
  if (piStack_d0 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_d0[2] + -1;
    piStack_d0[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_190 = (undefined4 *)0x64bc01;
      (**(code **)(*piStack_d0 + 4))();
    }
  }
  puStack_190 = (undefined4 *)0x64bc0c;
  FUN_00651d50();
  if (in_stack_000000b8 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_000000b8 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_190 = (undefined4 *)0x64bc23;
      (**(code **)(*in_stack_000000b8 + 4))();
    }
  }
  puStack_190 = (undefined4 *)0x64bc2b;
  FUN_00651d50();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7344 ; VA 0x0064bc40 ; FUN_0064bc40 */

undefined4 * __thiscall FUN_0064bc40(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0064daf0(param_2,param_2);
  return param_1;
}



/* FUNCTION 7345 ; VA 0x0064bc70 ; FUN_0064bc70 */

void __thiscall FUN_0064bc70(int *param_1,int param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iStack_c;
  undefined uStack_5;
  
  iStack_c = param_3 - param_2;
  iVar1 = *param_1;
  uVar4 = iStack_c >> 2;
  uVar3 = param_1[2] - iVar1 >> 2;
  uVar2 = param_1[1] - iVar1 >> 2;
  if (uVar4 <= uVar3) {
    if (uVar4 <= uVar2) {
      FUN_0170cc70(iVar1,param_2,iStack_c);
      param_1[1] = iVar1 + uVar4 * 4;
      return;
    }
    iVar5 = uVar2 * 4;
    FUN_0170cc70(iVar1,param_2,iVar5);
    iVar1 = param_1[1];
    FUN_0055b6b0(&uStack_5,&iStack_c,&iStack_c);
    param_2 = param_2 + iVar5;
    iVar5 = param_3 - param_2;
    FUN_0170cc70(iVar1,param_2,iVar5);
    param_1[1] = iVar1 + iVar5;
    return;
  }
  if (0x3fffffff < uVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = uVar4;
  if ((uVar3 <= 0x3fffffff - (uVar3 >> 1)) && (uVar2 = (uVar3 >> 1) + uVar3, uVar2 < uVar4)) {
    uVar2 = uVar4;
  }
  if (iVar1 != 0) {
    FUN_0057d270(iVar1,uVar3);
  }
  FUN_005d2220(uVar2);
  iVar1 = *param_1;
  FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
  iVar5 = iStack_c;
  FUN_0170cc70(iVar1,param_2,iStack_c);
  param_1[1] = iVar1 + iVar5;
  return;
}



/* FUNCTION 7346 ; VA 0x0064bd80 ; FUN_0064bd80 */

char * FUN_0064bd80(char *param_1,char *param_2,char *param_3,char *param_4,int param_5,uint param_6
                   )

{
  char cVar1;
  char cVar2;
  char *pcVar3;
  bool bVar4;
  
  pcVar3 = param_1;
  if ((param_6 & 0x100) == 0) {
    if ((param_6 & 0x800) == 0) {
      if (param_1 != param_2) {
        do {
          bVar4 = param_3 == param_4;
          if (bVar4) goto LAB_0064be77;
          cVar1 = *param_3;
          param_3 = param_3 + 1;
          cVar2 = *pcVar3;
          pcVar3 = pcVar3 + 1;
          if (cVar2 != cVar1) {
            return param_1;
          }
        } while (pcVar3 != param_2);
      }
      bVar4 = param_3 == param_4;
LAB_0064be77:
      if (bVar4) {
        param_1 = pcVar3;
      }
      return param_1;
    }
    if (param_1 != param_2) {
      do {
        if (param_3 == param_4) break;
        cVar1 = *param_3;
        param_3 = param_3 + 1;
        cVar2 = *pcVar3;
        pcVar3 = pcVar3 + 1;
        cVar2 = FUN_0066cac0(cVar2);
        cVar1 = FUN_0066cac0(cVar1);
        if (cVar2 != cVar1) {
          return param_1;
        }
      } while (pcVar3 != param_2);
    }
  }
  else if (param_1 != param_2) {
    while (param_3 != param_4) {
      cVar1 = *param_3;
      param_3 = param_3 + 1;
      cVar2 = *pcVar3;
      pcVar3 = pcVar3 + 1;
      cVar1 = (**(code **)(**(int **)(param_5 + 4) + 0x10))(cVar1);
      cVar2 = (**(code **)(**(int **)(param_5 + 4) + 0x10))(cVar2);
      if (cVar2 != cVar1) {
        return param_1;
      }
      if (pcVar3 == param_2) {
        if (param_3 == param_4) {
          param_1 = pcVar3;
        }
        return param_1;
      }
    }
  }
  if (param_3 == param_4) {
    param_1 = pcVar3;
  }
  return param_1;
}



/* FUNCTION 7347 ; VA 0x0064be90 ; FUN_0064be90 */

void __thiscall FUN_0064be90(uint *param_1,undefined *param_2,undefined *param_3)

{
  undefined uVar1;
  uint uVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1450;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  while( true ) {
    while( true ) {
      if (param_2 == param_3) {
        ExceptionList = pvStack_10;
        return;
      }
      uVar2 = param_1[5];
      uVar1 = *param_2;
      uVar6 = param_1[4];
      if (uVar2 <= uVar6) break;
      param_1[4] = uVar6 + 1;
      puVar3 = param_1;
      if (0xf < uVar2) {
        puVar3 = (uint *)*param_1;
      }
      *(undefined *)((int)puVar3 + uVar6) = uVar1;
      *(undefined *)((int)puVar3 + uVar6 + 1) = 0;
      param_2 = param_2 + 1;
    }
    if (uVar6 == 0x7fffffff) break;
    uVar7 = uVar6 + 1 | 0xf;
    if (uVar7 < 0x80000000) {
      if (0x7fffffff - (uVar2 >> 1) < uVar2) {
        uVar7 = 0x7fffffff;
      }
      else {
        uVar8 = (uVar2 >> 1) + uVar2;
        if (uVar7 < uVar8) {
          uVar7 = uVar8;
        }
      }
    }
    else {
      uVar7 = 0x7fffffff;
    }
    uVar8 = uVar7 + 1;
    if (uVar8 < 0x1000) {
      if (uVar8 == 0) {
        uVar8 = 0;
      }
      else {
        uVar8 = FUN_01674e20(uVar8);
      }
    }
    else {
      uVar4 = uVar7 + 0x24;
      if (uVar4 <= uVar8) {
        uVar4 = 0xffffffff;
      }
      iVar5 = FUN_01674e20(uVar4);
      if (iVar5 == 0) goto LAB_0064c02c;
      uVar8 = iVar5 + 0x23U & 0xffffffe0;
      *(int *)(uVar8 - 4) = iVar5;
    }
    param_1[4] = uVar6 + 1;
    param_1[5] = uVar7;
    if (uVar2 < 0x10) {
      FUN_0170c6f0(uVar8,param_1,uVar6);
      *(undefined *)(uVar8 + uVar6) = uVar1;
      param_2 = param_2 + 1;
      *(undefined *)(uVar8 + 1 + uVar6) = 0;
      *param_1 = uVar8;
    }
    else {
      uVar7 = *param_1;
      FUN_0170c6f0(uVar8,uVar7,uVar6);
      uVar4 = uVar2 + 1;
      *(undefined *)(uVar8 + uVar6) = uVar1;
      *(undefined *)(uVar8 + 1 + uVar6) = 0;
      uVar6 = uVar7;
      if (0xfff < uVar4) {
        uVar6 = *(uint *)(uVar7 - 4);
        uVar4 = uVar2 + 0x24;
        if (0x1f < (uVar7 - uVar6) - 4) goto LAB_0064c02c;
      }
      FUN_01674ea0(uVar6,uVar4);
      param_2 = param_2 + 1;
      *param_1 = uVar8;
    }
  }
  FUN_00554040();
LAB_0064c02c:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 7348 ; VA 0x0064c031 ; Catch_All@0064c031 */

void Catch_All_0064c031(void)

{
  FUN_005507b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7349 ; VA 0x0064c050 ; FUN_0064c050 */

int __thiscall FUN_0064c050(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined4 *puVar10;
  
  iVar1 = *param_1;
  iVar9 = (int)param_2 - iVar1 >> 3;
  iVar2 = param_1[1] - iVar1 >> 3;
  if (iVar2 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = iVar2 + 1;
  uVar7 = param_1[2] - iVar1 >> 3;
  uVar4 = uVar3;
  if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar4 = (uVar7 >> 1) + uVar7, uVar4 < uVar3)) {
    uVar4 = uVar3;
  }
  puVar5 = (undefined4 *)FUN_00578020(uVar4);
  iVar1 = iVar9 * 8;
  puVar5[iVar9 * 2] = *param_3;
  (puVar5 + iVar9 * 2)[1] = param_3[1];
  puVar10 = (undefined4 *)param_1[1];
  puVar6 = (undefined4 *)*param_1;
  puVar8 = puVar5;
  if (param_2 == puVar10) {
    for (; puVar6 != puVar10; puVar6 = puVar6 + 2) {
      *puVar8 = *puVar6;
      puVar8[1] = puVar6[1];
      puVar8 = puVar8 + 2;
    }
  }
  else {
    if (puVar6 != param_2) {
      do {
        *puVar8 = *puVar6;
        puVar10 = puVar6 + 1;
        puVar6 = puVar6 + 2;
        puVar8[1] = *puVar10;
        puVar8 = puVar8 + 2;
      } while (puVar6 != param_2);
      puVar10 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar10) {
      iVar2 = iVar1 - (int)param_2;
      do {
        *(undefined4 *)((int)param_2 + (int)puVar5 + iVar2 + 8) = *param_2;
        *(undefined4 *)((int)param_2 + (int)puVar5 + iVar2 + 0xc) = param_2[1];
        param_2 = param_2 + 2;
      } while (param_2 != puVar10);
    }
  }
  FUN_00654980(puVar5,uVar3,uVar4);
  return *param_1 + iVar1;
}



/* FUNCTION 7350 ; VA 0x0064c160 ; FUN_0064c160 */

int __thiscall FUN_0064c160(int *param_1,int param_2,undefined *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  
  iVar4 = *param_1;
  iVar3 = param_2 - iVar4;
  if (param_1[1] - iVar4 == 0x7fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = (param_1[1] - iVar4) + 1;
  uVar7 = param_1[2] - iVar4;
  uVar8 = uVar1;
  if ((uVar7 <= 0x7fffffff - (uVar7 >> 1)) && (uVar8 = (uVar7 >> 1) + uVar7, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  iVar4 = FUN_00554060(uVar8);
  puVar5 = (undefined *)(iVar3 + iVar4);
  *puVar5 = *param_3;
  if (param_2 == param_1[1]) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar4,*param_1,param_1[1] - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar4,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(puVar5 + 1,param_2,param_1[1] - param_2);
  }
  iVar2 = *param_1;
  if (iVar2 != 0) {
    uVar7 = param_1[2] - iVar2;
    iVar6 = iVar2;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar2 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  *param_1 = iVar4;
  param_1[1] = uVar1 + iVar4;
  param_1[2] = iVar4 + uVar8;
  return *param_1 + iVar3;
}



/* FUNCTION 7351 ; VA 0x0064c2a0 ; FUN_0064c2a0 */

int __thiscall FUN_0064c2a0(uint *param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar8 = *param_1;
  iVar1 = (int)(param_1[1] - *param_1) / 0x38;
  if (iVar1 == 0x4924924) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = iVar1 + 1;
  uVar2 = (int)(param_1[2] - *param_1) / 0x38;
  uVar7 = uVar5;
  if ((uVar2 <= 0x4924924 - (uVar2 >> 1)) && (uVar7 = (uVar2 >> 1) + uVar2, uVar7 < uVar5)) {
    uVar7 = uVar5;
  }
  uVar5 = uVar7 * 0x38;
  if (uVar7 < 0x4924925) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_0064c342;
    if (uVar5 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_0064c342:
    uVar2 = uVar7 + 0x23;
    if (uVar2 <= uVar7) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_0064c489;
    uVar7 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar3;
  }
  iVar3 = ((int)(param_2 - uVar8) / 0x38) * 0x38;
  iVar4 = iVar3 + uVar7;
  FUN_0064e2a0(param_1,iVar4,param_3);
  uVar8 = param_1[1];
  uVar2 = *param_1;
  uVar6 = uVar7;
  if (param_2 == uVar8) {
    for (; uVar2 != uVar8; uVar2 = uVar2 + 0x38) {
      FUN_0064e2a0(param_1,uVar6,uVar2);
      uVar6 = uVar6 + 0x38;
    }
  }
  else {
    FUN_006578b0(uVar2,param_2,uVar7);
    FUN_006578b0(param_2,param_1[1],iVar4 + 0x38);
  }
  uVar8 = *param_1;
  if (uVar8 != 0) {
    uVar2 = param_1[1];
    if (uVar8 != uVar2) {
      do {
        FUN_00651cc0();
        uVar8 = uVar8 + 0x38;
      } while (uVar8 != uVar2);
      uVar8 = *param_1;
    }
    uVar6 = ((int)(param_1[2] - uVar8) / 0x38) * 0x38;
    uVar2 = uVar8;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar8 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar8 - uVar2) - 4) {
LAB_0064c489:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + (iVar1 + 1) * 0x38;
  param_1[2] = uVar5 + uVar7;
  return *param_1 + iVar3;
}



/* FUNCTION 7352 ; VA 0x0064c4a0 ; FUN_0064c4a0 */

undefined4 * FUN_0064c4a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1468;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x24);
  *puVar2 = std::
            _Func_impl_no_alloc<class_<lambda_164973690c42fed5077c700689324862>,void,enum_RBX::Player::CanManageStatus>
            ::vftable;
  puVar2[1] = 0;
  puVar2[2] = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[1] = *param_1;
  puVar2[2] = param_1[1];
  uStack_8 = 1;
  FUN_0054ef60(param_1 + 2);
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 7353 ; VA 0x0064c52b ; Catch_All@0064c52b */

void Catch_All_0064c52b(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x24);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7354 ; VA 0x0064c550 ; FUN_0064c550 */

undefined4 * FUN_0064c550(undefined4 *param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1488;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x24);
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_164973690c42fed5077c700689324862>,void,enum_RBX::Player::CanManageStatus>
            ::vftable;
  puVar1[1] = 0;
  puVar1[2] = 0;
  puVar1[1] = *param_1;
  puVar1[2] = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  uStack_8 = 1;
  FUN_0054ef60(param_1 + 2);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 7355 ; VA 0x0064c5dd ; Catch_All@0064c5dd */

void Catch_All_0064c5dd(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x24);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7356 ; VA 0x0064c600 ; FUN_0064c600 */

void __thiscall
FUN_0064c600(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x6666664 < (uint)param_1[1]) {
    FUN_006552a0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_0064c6b2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_0064c6b2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 7357 ; VA 0x0064c760 ; FUN_0064c760 */

undefined4 * __thiscall
FUN_0064c760(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a14a0;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_0064c600(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar2 = FUN_00570370(param_4,param_3 + 4);
    if (cVar2 != '\0') {
      FUN_0064c600(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar1 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar2 = FUN_00570370(iVar1 + 0x10,param_4);
    if (cVar2 != '\0') {
      FUN_0064c600(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_00570370(param_4,param_3 + 4);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar2 = FUN_00570370(*piVar3 + 0x10,param_4);
      if (cVar2 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_0064c600(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_0064c600(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar2 = FUN_00570370(param_3 + 4,param_4);
    if (cVar2 != '\0') {
      piStack_18 = param_3;
      FUN_00551320();
      piVar3 = piStack_18;
      if ((piStack_18 == (int *)*param_1) ||
         (cVar2 = FUN_00570370(param_4,piStack_18 + 4), cVar2 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_0064c600(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_0064c600(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = (undefined4 *)FUN_0064c9a0(auStack_20,0,param_4,param_5);
  *param_2 = *puVar4;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7358 ; VA 0x0064c982 ; Catch_All@0064c982 */

void Catch_All_0064c982(void)

{
  int unaff_EBP;
  
  FUN_006552a0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7359 ; VA 0x0064c9a0 ; FUN_0064c9a0 */

void __thiscall
FUN_0064c9a0(int *param_1,undefined4 *param_2,char param_3,byte *param_4,undefined4 param_5)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  byte bVar4;
  char cVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  byte *pbVar9;
  byte *pbVar10;
  undefined4 *puVar11;
  bool bVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a14b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar4 = 1;
  puVar8 = (undefined4 *)((undefined4 *)*param_1)[1];
  cVar5 = *(char *)((int)puVar8 + 0xd);
  puVar3 = (undefined4 *)*param_1;
  while (cVar5 == '\0') {
    pbVar9 = (byte *)(puVar8 + 4);
    if (param_3 == '\0') {
      uVar1 = puVar8[8];
      if (0xf < (uint)puVar8[9]) {
        pbVar9 = *(byte **)pbVar9;
      }
      uVar6 = *(uint *)(param_4 + 0x10);
      pbVar10 = param_4;
      if (0xf < *(uint *)(param_4 + 0x14)) {
        pbVar10 = *(byte **)param_4;
      }
      uVar7 = uVar6;
      if (uVar1 < uVar6) {
        uVar7 = uVar1;
      }
      while (uVar2 = uVar7 - 4, 3 < uVar7) {
        if (*(int *)pbVar10 != *(int *)pbVar9) goto LAB_0064cad6;
        pbVar10 = pbVar10 + 4;
        pbVar9 = pbVar9 + 4;
        uVar7 = uVar2;
      }
      if (uVar2 == 0xfffffffc) {
LAB_0064cb0a:
        uVar7 = 0;
      }
      else {
LAB_0064cad6:
        bVar12 = *pbVar10 < *pbVar9;
        if ((*pbVar10 == *pbVar9) &&
           ((uVar2 == 0xfffffffd ||
            ((bVar12 = pbVar10[1] < pbVar9[1], pbVar10[1] == pbVar9[1] &&
             ((uVar2 == 0xfffffffe ||
              ((bVar12 = pbVar10[2] < pbVar9[2], pbVar10[2] == pbVar9[2] &&
               ((uVar2 == 0xffffffff || (bVar12 = pbVar10[3] < pbVar9[3], pbVar10[3] == pbVar9[3])))
               ))))))))) goto LAB_0064cb0a;
        uVar7 = -(uint)bVar12 | 1;
      }
      if (uVar7 == 0) {
        if (uVar6 < uVar1) {
          uVar7 = 0xffffffff;
        }
        else {
          uVar7 = 0;
        }
      }
      bVar4 = (byte)(uVar7 >> 0x1f);
    }
    else {
      pbVar10 = param_4;
      if (0xf < *(uint *)(param_4 + 0x14)) {
        pbVar10 = *(byte **)param_4;
      }
      uVar1 = puVar8[8];
      if (0xf < (uint)puVar8[9]) {
        pbVar9 = *(byte **)pbVar9;
      }
      uVar6 = uVar1;
      if (*(uint *)(param_4 + 0x10) < uVar1) {
        uVar6 = *(uint *)(param_4 + 0x10);
      }
      while (uVar7 = uVar6 - 4, 3 < uVar6) {
        if (*(int *)pbVar9 != *(int *)pbVar10) goto LAB_0064ca36;
        pbVar9 = pbVar9 + 4;
        pbVar10 = pbVar10 + 4;
        uVar6 = uVar7;
      }
      if (uVar7 == 0xfffffffc) {
LAB_0064ca6a:
        uVar6 = 0;
      }
      else {
LAB_0064ca36:
        bVar12 = *pbVar9 < *pbVar10;
        if ((*pbVar9 == *pbVar10) &&
           ((uVar7 == 0xfffffffd ||
            ((bVar12 = pbVar9[1] < pbVar10[1], pbVar9[1] == pbVar10[1] &&
             ((uVar7 == 0xfffffffe ||
              ((bVar12 = pbVar9[2] < pbVar10[2], pbVar9[2] == pbVar10[2] &&
               ((uVar7 == 0xffffffff || (bVar12 = pbVar9[3] < pbVar10[3], pbVar9[3] == pbVar10[3])))
               ))))))))) goto LAB_0064ca6a;
        uVar6 = -(uint)bVar12 | 1;
      }
      if (uVar6 == 0) {
        if (uVar1 < *(uint *)(param_4 + 0x10)) {
          bVar4 = 0;
          goto LAB_0064cb26;
        }
        uVar6 = 0;
      }
      bVar4 = (byte)(uVar6 >> 0x1f) ^ 1;
    }
LAB_0064cb26:
    if (bVar4 == 0) {
      puVar11 = (undefined4 *)puVar8[2];
    }
    else {
      puVar11 = (undefined4 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar11;
    cVar5 = *(char *)((int)puVar11 + 0xd);
  }
  ExceptionList = &pvStack_10;
  _param_3 = puVar3;
  if (bVar4 != 0) {
    if (puVar3 == *(undefined4 **)*param_1) {
      bVar4 = 1;
      ExceptionList = &pvStack_10;
      pbVar9 = param_4;
      goto LAB_0064cb61;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  pbVar9 = param_4;
  puVar8 = _param_3;
  cVar5 = FUN_00570370(_param_3 + 4,param_4);
  if (cVar5 == '\0') {
    FUN_006552a0(param_5);
    *param_2 = puVar8;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_0064cb61:
  puVar8 = (undefined4 *)FUN_0064c600(&param_3,bVar4,puVar3,pbVar9,param_5);
  *param_2 = *puVar8;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7360 ; VA 0x0064cbd8 ; Catch_All@0064cbd8 */

void Catch_All_0064cbd8(void)

{
  int unaff_EBP;
  
  FUN_006552a0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7361 ; VA 0x0064cbf0 ; FUN_0064cbf0 */

char * FUN_0064cbf0(char *param_1,char *param_2,uint *param_3)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  char *pcVar4;
  uint uVar5;
  
  if (param_3 != (uint *)0x0) {
    do {
      uVar5 = 0;
      if (param_3[2] != 0) {
        uVar2 = *param_3;
        do {
          uVar3 = 0;
          pcVar4 = param_1;
          if (uVar2 != 0) {
            do {
              cVar1 = *pcVar4;
              pcVar4 = pcVar4 + 1;
              if (cVar1 != *(char *)(param_3[3] + uVar5 + uVar3)) break;
              uVar3 = uVar3 + 1;
            } while (uVar3 < uVar2);
          }
          if (pcVar4 == param_2) {
            return param_2;
          }
          uVar5 = uVar5 + uVar2;
        } while (uVar5 < param_3[2]);
      }
      param_3 = (uint *)param_3[4];
    } while (param_3 != (uint *)0x0);
  }
  return param_1;
}



/* FUNCTION 7362 ; VA 0x0064cc60 ; FUN_0064cc60 */

uint FUN_0064cc60(uint param_1,int param_2)

{
  uint uVar1;
  
  uVar1 = 0;
  if (*(uint *)(param_2 + 4) != 0) {
    do {
      if ((*(byte *)(*(int *)(param_2 + 8) + uVar1) <= param_1) &&
         (param_1 <= *(byte *)(*(int *)(param_2 + 8) + 1 + uVar1))) {
        return CONCAT31((int3)(uVar1 >> 8),1);
      }
      uVar1 = uVar1 + 2;
    } while (uVar1 < *(uint *)(param_2 + 4));
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 7363 ; VA 0x0064cca0 ; FUN_0064cca0 */

undefined __thiscall FUN_0064cca0(undefined4 *param_1,undefined4 *param_2,undefined param_3)

{
  int iVar1;
  char cVar2;
  undefined *puVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  
  if (param_2 == (undefined4 *)0x0) {
    piVar6 = (int *)&DAT_00000008;
  }
  else {
    piVar6 = param_2 + 2;
    *(undefined *)(param_2 + 1) = 1;
    FUN_0064d810(0,piVar6);
  }
  param_1[0x13] = param_1[0x15];
  *param_1 = param_1[0x15];
  FUN_0066b930(param_1[0x1a],0);
  FUN_0064d6d0(param_1[0x1a],param_1 + 5);
  param_1[0x1e] = 10000000;
  param_1[0x1f] = 1000;
  *(undefined *)(param_1 + 0x19) = 0;
  *(bool *)((int)param_1 + 0x65) = param_2 != (undefined4 *)0x0;
  *(undefined *)(param_1 + 0x1d) = param_3;
  cVar2 = FUN_00656c90(param_1[0x16]);
  if (cVar2 != '\0') {
    if (param_2 != (undefined4 *)0x0) {
      FUN_0064d810(param_1[0x1a],piVar6);
      _param_3 = 0;
      if (param_1[0x1a] != 0) {
        iVar5 = 0;
        do {
          puVar3 = (undefined *)(*piVar6 + 8 + iVar5);
          if ((*(uint *)(param_1[9] + (_param_3 >> 5) * 4) & 1 << ((byte)_param_3 & 0x1f)) == 0) {
            *puVar3 = 0;
            *(undefined4 *)(iVar5 + *piVar6) = param_1[0x14];
            uVar4 = param_1[0x14];
          }
          else {
            *puVar3 = 1;
            *(undefined4 *)(iVar5 + *piVar6) = *(undefined4 *)(param_1[0xd] + _param_3 * 8);
            uVar4 = *(undefined4 *)(param_1[0xd] + 4 + _param_3 * 8);
          }
          _param_3 = _param_3 + 1;
          *(undefined4 *)(iVar5 + 4 + *piVar6) = uVar4;
          iVar5 = iVar5 + 0xc;
        } while (_param_3 < (uint)param_1[0x1a]);
      }
      *param_2 = param_1[0x13];
      iVar5 = param_1[0x13];
      param_2[5] = iVar5;
      iVar1 = *(int *)*piVar6;
      param_2[6] = iVar1;
      *(bool *)(param_2 + 7) = iVar5 != iVar1;
      iVar5 = *(int *)(*piVar6 + 4);
      param_2[8] = iVar5;
      iVar1 = param_1[0x14];
      param_2[9] = iVar1;
      *(bool *)(param_2 + 10) = iVar5 != iVar1;
      param_2[0xb] = param_1[0x14];
      param_2[0xc] = param_1[0x14];
    }
    return 1;
  }
  return 0;
}



/* FUNCTION 7364 ; VA 0x0064cdf0 ; FUN_0064cdf0 */

void FUN_0064cdf0(uint *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = *param_2;
  if (uVar3 < *param_1) {
    uVar1 = param_2[1];
    *param_2 = *param_1;
    param_2[1] = param_1[1];
    *param_1 = uVar3;
    param_1[1] = uVar1;
    uVar3 = *param_2;
  }
  uVar1 = *param_3;
  if (uVar1 < uVar3) {
    uVar2 = param_3[1];
    *param_3 = uVar3;
    param_3[1] = param_2[1];
    *param_2 = uVar1;
    param_2[1] = uVar2;
    if (uVar1 < *param_1) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      *param_1 = uVar1;
      param_1[1] = uVar2;
    }
  }
  return;
}



/* FUNCTION 7365 ; VA 0x0064ce50 ; FUN_0064ce50 */

void FUN_0064ce50(undefined4 *param_1,uint *param_2,uint *param_3,uint *param_4)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  int iVar5;
  uint *puVar6;
  uint *puVar7;
  uint *puVar8;
  uint *puVar9;
  uint *puVar10;
  uint uStack_10;
  uint *puStack_c;
  uint *puStack_8;
  
  puVar6 = param_3 + -2;
  puVar7 = param_2 + ((int)param_3 - (int)param_2 >> 4) * 2;
  iVar5 = (int)puVar6 - (int)param_2 >> 3;
  if (iVar5 < 0x29) {
    FUN_0064cdf0(param_2,puVar7,puVar6,param_4);
  }
  else {
    iVar5 = iVar5 + 1 >> 3;
    FUN_0064cdf0(param_2,param_2 + iVar5 * 2,param_2 + iVar5 * 4,param_4);
    FUN_0064cdf0(puVar7 + iVar5 * -2,puVar7,puVar7 + iVar5 * 2,param_4);
    FUN_0064cdf0(puVar6 + iVar5 * -4,puVar6 + iVar5 * -2,puVar6,param_4);
    FUN_0064cdf0(param_2 + iVar5 * 2,puVar7,puVar6 + iVar5 * -2,param_4);
  }
  puVar6 = puVar7 + 2;
  for (; param_2 < puVar7; puVar7 = puVar7 + -2) {
    uVar2 = puVar7[-2];
    uVar1 = *puVar7;
    if ((uVar2 < uVar1) || (uVar2 >= uVar1 && uVar2 != uVar1)) break;
  }
  puVar9 = puVar6;
  puStack_c = puVar6;
  puStack_8 = puVar6;
  param_4 = puVar7;
  if (puVar6 < param_3) {
    uVar1 = *puVar7;
    do {
      uVar2 = *puVar6;
      puVar9 = puVar6;
      puStack_c = puVar6;
      puStack_8 = puVar6;
      if ((uVar2 < uVar1) || (uVar2 >= uVar1 && uVar2 != uVar1)) break;
      puVar6 = puVar6 + 2;
      puVar9 = puVar6;
      puStack_c = puVar6;
      puStack_8 = puVar6;
    } while (puVar6 < param_3);
  }
joined_r0x0064cf42:
  do {
    puVar10 = puVar7;
    if (param_3 <= puVar9) {
joined_r0x0064cf7d:
      while (puVar4 = param_4, puVar7 = puVar10, puVar10 = puVar9, param_2 < puVar4) {
        uVar1 = puVar4[-2];
        param_4 = puVar4 + -2;
        puVar6 = puStack_8;
        puVar10 = puVar7;
        puVar9 = puStack_c;
        if (*puVar7 <= uVar1) {
          puVar10 = puStack_c;
          if (*puVar7 < uVar1) break;
          puVar10 = puVar7 + -2;
          if (puVar10 != puVar4 + -2) {
            uVar2 = *puVar10;
            uVar3 = puVar7[-1];
            *puVar10 = uVar1;
            puVar7[-1] = puVar4[-1];
            puVar4[-1] = uVar3;
            *param_4 = uVar2;
          }
        }
      }
      if (puVar4 == param_2) {
        if (puVar10 == param_3) {
          *param_1 = puVar7;
          param_1[1] = puVar6;
          return;
        }
        if (puVar6 != puVar10) {
          uVar1 = *puVar7;
          uVar2 = puVar7[1];
          *puVar7 = *puVar6;
          puVar7[1] = puVar6[1];
          *puVar6 = uVar1;
          puVar6[1] = uVar2;
        }
        uVar1 = *puVar7;
        puVar6 = puVar6 + 2;
        uVar2 = puVar7[1];
        *puVar7 = *puVar10;
        puVar7[1] = puVar10[1];
        puVar7 = puVar7 + 2;
        *puVar10 = uVar1;
        puVar10[1] = uVar2;
        puVar9 = puVar10 + 2;
        puStack_c = puVar10 + 2;
        puStack_8 = puVar6;
        param_4 = puVar4;
      }
      else {
        param_4 = puVar4 + -2;
        if (puVar10 == param_3) {
          puVar8 = puVar7 + -2;
          if (param_4 == puVar8) {
            uStack_10 = *puVar8;
          }
          else {
            uStack_10 = *param_4;
            uVar1 = puVar4[-1];
            *param_4 = *puVar8;
            puVar4[-1] = puVar7[-1];
            *puVar8 = uStack_10;
            puVar7[-1] = uVar1;
          }
          puStack_8 = puVar6 + -2;
          uVar1 = puVar7[-1];
          *puVar8 = puVar6[-2];
          puVar7[-1] = puVar6[-1];
          *puStack_8 = uStack_10;
          puVar6[-1] = uVar1;
          puVar6 = puStack_8;
          puVar9 = puVar10;
          puVar7 = puVar8;
        }
        else {
          uVar1 = *puVar10;
          uVar2 = puVar10[1];
          *puVar10 = *param_4;
          puVar10[1] = puVar4[-1];
          *param_4 = uVar1;
          puVar4[-1] = uVar2;
          puVar9 = puVar10 + 2;
          puStack_c = puVar10 + 2;
        }
      }
      goto joined_r0x0064cf42;
    }
    uVar1 = *puVar9;
    if (uVar1 <= *puVar7) {
      puStack_8 = puVar6;
      puStack_c = puVar9;
      if (uVar1 < *puVar7) goto joined_r0x0064cf7d;
      if (puVar6 != puVar9) {
        uVar2 = *puVar6;
        uVar3 = puVar6[1];
        *puVar6 = uVar1;
        puVar6[1] = puVar9[1];
        *puVar9 = uVar2;
        puVar9[1] = uVar3;
      }
      puVar6 = puVar6 + 2;
    }
    puVar9 = puVar9 + 2;
    puStack_c = puVar9;
    puStack_8 = puVar6;
  } while( true );
}



/* FUNCTION 7366 ; VA 0x0064d0c0 ; FUN_0064d0c0 */

void FUN_0064d0c0(int param_1,int param_2,uint param_3,uint *param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar3 = (int)(param_3 - 1) >> 1;
  iVar2 = param_2;
  iVar4 = param_2;
  if (param_2 < iVar3) {
    do {
      iVar4 = (2 - (uint)(*(uint *)(param_1 + 0x10 + iVar2 * 0x10) <
                         *(uint *)(param_1 + 8 + iVar2 * 0x10))) + iVar2 * 2;
      *(undefined4 *)(param_1 + iVar2 * 8) = *(undefined4 *)(param_1 + iVar4 * 8);
      *(undefined4 *)(param_1 + 4 + iVar2 * 8) = *(undefined4 *)(param_1 + 4 + iVar4 * 8);
      iVar2 = iVar4;
    } while (iVar4 < iVar3);
  }
  if ((iVar4 == iVar3) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar4 * 8) = *(undefined4 *)(param_1 + -8 + param_3 * 8);
    *(undefined4 *)(param_1 + 4 + iVar4 * 8) = *(undefined4 *)(param_1 + -4 + param_3 * 8);
    iVar4 = param_3 - 1;
  }
  while (param_2 < iVar4) {
    iVar2 = iVar4 + -1 >> 1;
    uVar1 = *(uint *)(param_1 + iVar2 * 8);
    if (*param_4 <= uVar1) break;
    *(uint *)(param_1 + iVar4 * 8) = uVar1;
    *(undefined4 *)(param_1 + 4 + iVar4 * 8) = *(undefined4 *)(param_1 + 4 + iVar2 * 8);
    iVar4 = iVar2;
  }
  *(uint *)(param_1 + iVar4 * 8) = *param_4;
  *(uint *)(param_1 + 4 + iVar4 * 8) = param_4[1];
  return;
}



/* FUNCTION 7367 ; VA 0x0064d160 ; FUN_0064d160 */

void __thiscall FUN_0064d160(int *param_1,int param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar2 = param_3 - param_2;
  if (uVar2 != 0) {
    if (0x7fffffff < uVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar1 = FUN_00554060(uVar2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    param_1[2] = *param_1 + uVar2;
    iVar1 = *param_1;
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar1,param_2,uVar2);
    param_1[1] = iVar1 + uVar2;
  }
  return;
}



/* FUNCTION 7368 ; VA 0x0064d1e0 ; FUN_0064d1e0 */

void __thiscall FUN_0064d1e0(uint *param_1,int param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = param_3 - param_2;
  if (uVar3 != 0) {
    if (0x7fffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    if (uVar3 < 0x1000) {
      uVar1 = FUN_01674e20(uVar3);
    }
    else {
      uVar1 = uVar3 + 0x23;
      if (uVar1 <= uVar3) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar3;
    uVar1 = *param_1;
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(uVar1,param_2,uVar3);
    param_1[1] = uVar1 + uVar3;
  }
  return;
}



/* FUNCTION 7369 ; VA 0x0064d290 ; FUN_0064d290 */

void __thiscall FUN_0064d290(int param_1,uint param_2)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  bool bVar4;
  undefined4 *puVar5;
  bool bVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  int *in_stack_00000024;
  int *in_stack_00000028;
  int *in_stack_0000002c;
  int *in_stack_00000030;
  char in_stack_00000034;
  uint in_stack_00000044;
  int *in_stack_00000064;
  int in_stack_00000068;
  int *in_stack_0000006c;
  int *in_stack_00000070;
  char in_stack_00000074;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined auStack_30 [8];
  int iStack_28;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a14d8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffac;
  uStack_24 = 0;
  uStack_8 = 2;
  piStack_18 = in_stack_0000002c;
  piStack_1c = in_stack_00000028;
  ExceptionList = &pvStack_10;
  iStack_28 = param_1;
LAB_0064d2d8:
  do {
    if ((param_2 == 0) || (in_stack_00000034 != '\0')) {
      bVar6 = true;
    }
    else {
      bVar6 = false;
    }
    uStack_20 = in_stack_00000044;
    if ((in_stack_00000044 == 0) || (in_stack_00000074 != '\0')) {
      bVar4 = true;
    }
    else {
      bVar4 = false;
    }
    if ((bVar6) || (bVar4)) {
      bVar6 = (bool)(bVar4 ^ bVar6 ^ 1);
    }
    else {
      uVar7 = (int)piStack_1c - (int)in_stack_00000024;
      piVar2 = in_stack_00000024;
      piVar3 = in_stack_00000064;
      if (uVar7 == in_stack_00000068 - (int)in_stack_00000064) {
        while (uVar8 = uVar7 - 4, 3 < uVar7) {
          if (*piVar2 != *piVar3) goto LAB_0064d336;
          piVar2 = piVar2 + 1;
          piVar3 = piVar3 + 1;
          uVar7 = uVar8;
        }
        if (uVar8 != 0xfffffffc) {
LAB_0064d336:
          if ((*(char *)piVar2 != *(char *)piVar3) ||
             ((uVar8 != 0xfffffffd &&
              ((*(char *)((int)piVar2 + 1) != *(char *)((int)piVar3 + 1) ||
               ((uVar8 != 0xfffffffe &&
                ((*(char *)((int)piVar2 + 2) != *(char *)((int)piVar3 + 2) ||
                 ((uVar8 != 0xffffffff && (*(char *)((int)piVar2 + 3) != *(char *)((int)piVar3 + 3))
                  ))))))))))) goto LAB_0064d37a;
        }
        if ((piStack_18 == in_stack_0000006c) && (in_stack_00000030 == in_stack_00000070)) {
          bVar6 = true;
          goto LAB_0064d385;
        }
      }
LAB_0064d37a:
      bVar6 = false;
    }
LAB_0064d385:
    in_stack_00000028 = piStack_1c;
    in_stack_0000002c = piStack_18;
    if (bVar6) {
      uStack_8 = 6;
      if (((param_2 != 0) && ((param_2 & 1) == 0)) &&
         (*(code **)(param_2 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(param_2 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
      }
      uStack_8 = 7;
      if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
         (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_00000044 & 0xfffffffe))(&stack0x0000004c,&stack0x0000004c,2);
      }
      ExceptionList = pvStack_10;
      return;
    }
    uStack_48 = uStack_48 & 0xffffff00;
    uStack_38 = 0;
    uStack_34 = 0xf;
    if (in_stack_00000024 != piStack_1c) {
      FUN_005542c0(in_stack_00000024,(int)piStack_1c - (int)in_stack_00000024);
    }
    uVar7 = uStack_48;
    uStack_24 = uStack_24 | 0x1f;
    uStack_8._0_1_ = 4;
    puVar1 = *(uint **)(iStack_28 + 4);
    if (*(uint **)(iStack_28 + 8) == puVar1) {
      FUN_0058d0a0(puVar1,&uStack_48);
      uVar7 = uStack_34;
    }
    else {
      uStack_48 = uStack_48 & 0xffffff00;
      *puVar1 = uVar7;
      puVar1[1] = uStack_44;
      puVar1[2] = uStack_40;
      puVar1[3] = uStack_3c;
      puVar1[4] = uStack_38;
      puVar1[5] = uStack_34;
      *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 0x18;
      uVar7 = 0xf;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uVar7) {
      uVar9 = uVar7 + 1;
      uVar8 = uStack_48;
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(uStack_48 - 4);
        uVar9 = uVar7 + 0x24;
        if (0x1f < (uStack_48 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    if (param_2 == 0) {
      piStack_18 = in_stack_00000030;
      piStack_1c = in_stack_00000030;
    }
    else {
      puVar5 = (undefined4 *)
               (**(code **)((param_2 & 0xfffffffe) + 4))
                         (auStack_30,&stack0x0000000c,in_stack_0000002c,in_stack_00000030);
      piStack_1c = (int *)*puVar5;
      piStack_18 = (int *)puVar5[1];
      if ((piStack_1c != in_stack_00000030) || (piStack_18 != in_stack_00000030)) {
        in_stack_00000024 = in_stack_0000002c;
        goto LAB_0064d2d8;
      }
    }
    in_stack_00000024 = in_stack_0000002c;
    if (in_stack_00000028 == in_stack_00000030) {
      in_stack_00000034 = '\x01';
    }
  } while( true );
}



/* FUNCTION 7370 ; VA 0x0064d527 ; Catch_All@0064d527 */

void Catch_All_0064d527(void)

{
  FUN_00577a40();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7371 ; VA 0x0064d540 ; FUN_0064d540 */

void __thiscall FUN_0064d540(uint *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar2 = param_2;
  uVar4 = param_1[1];
  uVar1 = *param_1;
  uVar7 = (int)(uVar4 - uVar1) >> 3;
  uVar6 = (int)(param_1[2] - uVar1) >> 3;
  if (param_2 <= uVar6) {
    if (param_2 <= uVar7) {
      if (param_2 != uVar7) {
        param_1[1] = uVar1 + param_2 * 8;
      }
      return;
    }
    iVar3 = param_2 - uVar7;
    if (iVar3 != 0) {
      FUN_0170d1f0(uVar4,0,iVar3 * 8);
      uVar4 = uVar4 + iVar3 * 8;
    }
    param_1[1] = uVar4;
    return;
  }
  if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar4 = param_2;
  if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar4 = (uVar6 >> 1) + uVar6, uVar4 < param_2)) {
    uVar4 = param_2;
  }
  uVar1 = uVar4 * 8;
  if (uVar4 < 0x20000000) {
    uVar4 = uVar1;
    if (0xfff < uVar1) goto LAB_0064d5b2;
    if (uVar1 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_01674e20(uVar1);
    }
  }
  else {
    uVar4 = 0xffffffff;
LAB_0064d5b2:
    uVar6 = uVar4 + 0x23;
    if (uVar6 <= uVar4) {
      uVar6 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar6);
    if (iVar3 == 0) goto LAB_0064d6bf;
    uVar4 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar4 - 4) = iVar3;
  }
  iVar3 = uVar2 - uVar7;
  if (iVar3 != 0) {
    FUN_0170d1f0(uVar4 + uVar7 * 8,0,iVar3 * 8);
  }
  uVar6 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(uVar4,uVar6,param_1[1] - uVar6);
  uVar6 = *param_1;
  if (uVar6 != 0) {
    uVar5 = param_1[2] - uVar6 & 0xfffffff8;
    uVar7 = uVar6;
    if (0xfff < uVar5) {
      uVar7 = *(uint *)(uVar6 - 4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uVar6 - uVar7) - 4) {
LAB_0064d6bf:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar5);
  }
  *param_1 = uVar4;
  param_1[1] = uVar4 + uVar2 * 8;
  param_1[2] = uVar1 + uVar4;
  return;
}



/* FUNCTION 7372 ; VA 0x0064d6d0 ; FUN_0064d6d0 */

void __thiscall FUN_0064d6d0(int *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uStack_8;
  
  uVar1 = param_2;
  iVar2 = param_1[1];
  iVar4 = *param_1;
  uVar5 = iVar2 - iVar4 >> 3;
  uStack_8 = param_1[2] - iVar4 >> 3;
  if (param_2 <= uStack_8) {
    if (param_2 <= uVar5) {
      if (param_2 != uVar5) {
        param_1[1] = iVar4 + param_2 * 8;
      }
      return;
    }
    iVar4 = param_2 - uVar5;
    if (iVar4 != 0) {
      FUN_0170d1f0(iVar2,0,iVar4 * 8);
      iVar2 = iVar2 + iVar4 * 8;
    }
    param_1[1] = iVar2;
    return;
  }
  if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x1fffffff - (uStack_8 >> 1) < uStack_8) {
    uStack_8 = param_2;
  }
  else {
    uStack_8 = (uStack_8 >> 1) + uStack_8;
    if (uStack_8 < param_2) {
      uStack_8 = param_2;
    }
  }
  iVar2 = FUN_00578020(uStack_8);
  iVar4 = uVar1 - uVar5;
  if (iVar4 != 0) {
    FUN_0170d1f0(iVar2 + uVar5 * 8,0,iVar4 * 8);
  }
  iVar4 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(iVar2,iVar4,param_1[1] - iVar4);
  iVar4 = *param_1;
  if (iVar4 != 0) {
    uVar5 = param_1[2] - iVar4 & 0xfffffff8;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  *param_1 = iVar2;
  param_1[1] = iVar2 + uVar1 * 8;
  param_1[2] = iVar2 + uStack_8 * 8;
  return;
}



/* FUNCTION 7373 ; VA 0x0064d810 ; FUN_0064d810 */

void __thiscall FUN_0064d810(int *param_1,uint param_2)

{
  undefined8 *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined8 *puVar6;
  uint uVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  undefined4 *puVar11;
  
  puVar11 = (undefined4 *)param_1[1];
  uVar7 = ((int)puVar11 - *param_1) / 0xc;
  uVar5 = (param_1[2] - *param_1) / 0xc;
  if (param_2 <= uVar5) {
    if (uVar7 < param_2) {
      for (iVar4 = param_2 - uVar7; iVar4 != 0; iVar4 = iVar4 + -1) {
        *puVar11 = 0;
        puVar11[1] = 0;
        *(undefined *)(puVar11 + 2) = 0;
        puVar11 = puVar11 + 3;
      }
      param_1[1] = (int)puVar11;
      return;
    }
    if (param_2 != uVar7) {
      param_1[1] = *param_1 + param_2 * 0xc;
    }
    return;
  }
  if (0x15555555 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = param_2;
  if ((uVar5 <= 0x15555555 - (uVar5 >> 1)) && (uVar2 = (uVar5 >> 1) + uVar5, uVar2 < param_2)) {
    uVar2 = param_2;
  }
  uVar5 = uVar2 * 0xc;
  if (uVar2 < 0x15555556) {
    uVar2 = uVar5;
    if (0xfff < uVar5) goto LAB_0064d8a2;
    if (uVar5 == 0) {
      puVar8 = (undefined8 *)0x0;
    }
    else {
      puVar8 = (undefined8 *)FUN_01674e20(uVar5);
    }
  }
  else {
    uVar2 = 0xffffffff;
LAB_0064d8a2:
    uVar3 = uVar2 + 0x23;
    if (uVar3 <= uVar2) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_0064d9f0;
    puVar8 = (undefined8 *)(iVar4 + 0x23U & 0xffffffe0);
    *(int *)((int)puVar8 + -4) = iVar4;
  }
  puVar11 = (undefined4 *)((int)puVar8 + uVar7 * 0xc);
  for (iVar4 = param_2 - uVar7; iVar4 != 0; iVar4 = iVar4 + -1) {
    *puVar11 = 0;
    puVar11[1] = 0;
    *(undefined *)(puVar11 + 2) = 0;
    puVar11 = puVar11 + 3;
  }
  puVar10 = (undefined8 *)param_1[1];
  puVar9 = (undefined8 *)*param_1;
  puVar6 = puVar8;
  if (puVar9 != puVar10) {
    do {
      *puVar6 = *puVar9;
      puVar1 = puVar9 + 1;
      puVar9 = (undefined8 *)((int)puVar9 + 0xc);
      *(undefined4 *)(puVar6 + 1) = *(undefined4 *)puVar1;
      puVar6 = (undefined8 *)((int)puVar6 + 0xc);
    } while (puVar9 != puVar10);
    puVar9 = (undefined8 *)*param_1;
  }
  if (puVar9 != (undefined8 *)0x0) {
    uVar7 = ((param_1[2] - (int)puVar9) / 0xc) * 0xc;
    puVar10 = puVar9;
    if (0xfff < uVar7) {
      puVar10 = *(undefined8 **)((int)puVar9 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uint)((int)puVar9 + (-4 - (int)puVar10))) {
LAB_0064d9f0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar10,uVar7);
  }
  *param_1 = (int)puVar8;
  param_1[1] = (int)puVar8 + param_2 * 0xc;
  param_1[2] = uVar5 + (int)puVar8;
  return;
}



/* FUNCTION 7374 ; VA 0x0064da00 ; FUN_0064da00 */

int __thiscall FUN_0064da00(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a14f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Security::AslrPmcServer>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 4) == 0 || (*(int *)(*(int *)(param_2 + 4) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)param_2 = param_2;
    piVar3 = *(int **)(param_2 + 4);
    *(int **)(param_2 + 4) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7375 ; VA 0x0064dad3 ; Catch_All@0064dad3 */

void Catch_All_0064dad3(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00652ac0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7376 ; VA 0x0064daf0 ; FUN_0064daf0 */

void __thiscall FUN_0064daf0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1500;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Analytics::InfluxDb::Points>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7377 ; VA 0x0064db5e ; Catch_All@0064db5e */

void Catch_All_0064db5e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00652bb0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7378 ; VA 0x0064db80 ; FUN_0064db80 */

int __thiscall FUN_0064db80(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1510;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::Replicator::StreamJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 7379 ; VA 0x0064dc54 ; Catch_All@0064dc54 */

void Catch_All_0064dc54(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7380 ; VA 0x0064dc70 ; FUN_0064dc70 */

void FUN_0064dc70(uint *param_1,uint *param_2,int param_3,undefined4 param_4)

{
  uint *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint *puVar7;
  uint uVar8;
  uint *puVar9;
  uint *puVar10;
  int iVar11;
  uint *puStack_18;
  uint *puStack_14;
  int iStack_10;
  uint uStack_c;
  uint uStack_8;
  
  iVar5 = (int)param_2 - (int)param_1;
  puVar10 = param_2;
  do {
    iVar5 = iVar5 >> 3;
    if (iVar5 < 0x21) {
LAB_0064dcfa:
      if (((1 < iVar5) && (param_1 != puVar10)) && (puVar7 = param_1 + 2, param_1 + 2 != puVar10)) {
        do {
          uVar8 = *puVar7;
          puVar10 = puVar7 + 2;
          uVar3 = puVar7[1];
          if (uVar8 < *param_1) {
            if (puVar7 != param_1) {
              puVar7 = puVar7 + -1;
              puVar9 = puVar10;
              do {
                puVar9[-2] = puVar7[-1];
                puVar9[-1] = *puVar7;
                puVar1 = puVar7 + -1;
                puVar7 = puVar7 + -2;
                puVar9 = puVar9 + -2;
              } while (puVar1 != param_1);
            }
            *param_1 = uVar8;
            param_1[1] = uVar3;
          }
          else {
            uVar4 = puVar7[-2];
            while (uVar8 < uVar4) {
              *puVar7 = uVar4;
              puVar7[1] = puVar7[-1];
              uVar4 = puVar7[-4];
              puVar7 = puVar7 + -2;
            }
            *puVar7 = uVar8;
            puVar7[1] = uVar3;
          }
          puVar7 = puVar10;
        } while (puVar10 != param_2);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar5) {
        uVar8 = (int)puVar10 - (int)param_1 >> 3;
        iVar5 = (int)puVar10 - (int)param_1 >> 4;
        if (0 < iVar5) {
          iVar6 = (int)(uVar8 - 1) >> 1;
          do {
            uStack_c = param_1[iVar5 * 2 + -2];
            iVar5 = iVar5 + -1;
            uVar3 = param_1[iVar5 * 2 + 1];
            iVar2 = iVar5;
            while (iVar2 < iVar6) {
              iVar11 = (2 - (uint)(param_1[iVar2 * 4 + 4] < param_1[iVar2 * 4 + 2])) + iVar2 * 2;
              param_1[iVar2 * 2] = param_1[iVar11 * 2];
              param_1[iVar2 * 2 + 1] = param_1[iVar11 * 2 + 1];
              iVar2 = iVar11;
            }
            if ((iVar2 == iVar6) && ((uVar8 & 1) == 0)) {
              param_1[iVar2 * 2] = param_1[uVar8 * 2 + -2];
              param_1[iVar2 * 2 + 1] = param_1[uVar8 * 2 + -1];
              iVar2 = uVar8 - 1;
            }
            while (iVar5 < iVar2) {
              iVar11 = iVar2 + -1 >> 1;
              if (uStack_c <= param_1[iVar11 * 2]) break;
              param_1[iVar2 * 2] = param_1[iVar11 * 2];
              param_1[iVar2 * 2 + 1] = param_1[iVar11 * 2 + 1];
              iVar2 = iVar11;
            }
            param_1[iVar2 * 2] = uStack_c;
            param_1[iVar2 * 2 + 1] = uVar3;
            iStack_10 = iVar5;
          } while (0 < iVar5);
        }
        if ((int)uVar8 < 2) {
          return;
        }
        param_2 = param_2 + -1;
        uStack_8 = uVar8;
        do {
          if (1 < (int)uVar8) {
            puStack_18 = (uint *)param_2[-1];
            puStack_14 = (uint *)*param_2;
            param_2[-1] = *param_1;
            *param_2 = param_1[1];
            FUN_0064d0c0(param_1,0,(-4 - (int)param_1) + (int)param_2 >> 3,&puStack_18,param_4);
          }
          param_2 = param_2 + -2;
          uVar8 = (4 - (int)param_1) + (int)param_2 >> 3;
        } while (1 < (int)uVar8);
        return;
      }
      goto LAB_0064dcfa;
    }
    FUN_0064ce50(&puStack_18,param_1,puVar10,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)puStack_18 - (int)param_1 & 0xfffffff8U) <
        (int)((int)puVar10 - (int)puStack_14 & 0xfffffff8U)) {
      FUN_0064dc70(param_1,puStack_18,param_3,param_4);
      param_1 = puStack_14;
    }
    else {
      FUN_0064dc70(puStack_14,puVar10,param_3,param_4);
      param_2 = puStack_18;
      puVar10 = puStack_18;
    }
    iVar5 = (int)puVar10 - (int)param_1;
  } while( true );
}



/* FUNCTION 7381 ; VA 0x0064dee0 ; FUN_0064dee0 */

void __thiscall
FUN_0064dee0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,uint param_4,
            undefined4 param_5)

{
  undefined4 *puVar1;
  bool bVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 **ppuVar5;
  char cVar6;
  undefined4 ***pppuVar7;
  undefined4 ***pppuVar8;
  undefined4 *puVar9;
  undefined **ppuVar10;
  undefined4 ***pppuVar11;
  undefined4 **appuStack_48 [2];
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 **appuStack_38 [2];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 **appuStack_28 [2];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = param_4;
  puStack_c = &LAB_017a0410;
  pvStack_10 = ExceptionList;
  puVar1 = param_1 + 2;
  uStack_8 = 0;
  uStack_30 = param_4;
  appuStack_38[0] = (undefined4 ***)0x0;
  puStack_18 = param_1;
  if (param_4 < 9) {
    pppuVar8 = appuStack_38;
    puVar9 = &param_2;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    pppuVar8 = (undefined4 ***)FUN_01674e20(param_4);
    puVar9 = param_2;
    appuStack_38[0] = pppuVar8;
  }
  FUN_0170c6f0(pppuVar8,puVar9,uVar3);
  pppuVar8 = (undefined4 ***)appuStack_38[0];
  uVar4 = param_5;
  uStack_2c = param_5;
  uStack_8._0_1_ = 1;
  uStack_20 = uStack_30;
  appuStack_28[0] = (undefined4 ***)0x0;
  if (uStack_30 < 9) {
    pppuVar7 = appuStack_28;
    pppuVar11 = appuStack_38;
  }
  else {
    pppuVar7 = (undefined4 ***)FUN_01674e20(uStack_30);
    pppuVar11 = pppuVar8;
    appuStack_28[0] = pppuVar7;
  }
  FUN_0170c6f0(pppuVar7,pppuVar11,uStack_20);
  uStack_1c = uVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar6 = FUN_00585a40(appuStack_28);
  uVar3 = uStack_20;
  if (cVar6 == '\0') {
    uStack_40 = uStack_20;
    appuStack_48[0] = (undefined4 ***)0x0;
    if (uStack_20 < 9) {
      pppuVar8 = appuStack_48;
      pppuVar7 = appuStack_28;
    }
    else {
      pppuVar8 = (undefined4 ***)FUN_01674e20(uStack_20);
      pppuVar7 = (undefined4 ***)appuStack_28[0];
      appuStack_48[0] = pppuVar8;
    }
    FUN_0170c6f0(pppuVar8,pppuVar7,uVar3);
    uVar3 = uStack_40;
    ppuVar5 = appuStack_48[0];
    uStack_14 = uStack_1c;
    uStack_3c = uStack_1c;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    param_1[4] = uStack_40;
    *puVar1 = 0;
    if (uStack_40 < 9) {
      puVar9 = puVar1;
      pppuVar8 = appuStack_48;
    }
    else {
      puVar9 = (undefined4 *)FUN_01674e20(uStack_40);
      *puVar1 = puVar9;
      pppuVar8 = (undefined4 ***)ppuVar5;
    }
    FUN_0170c6f0(puVar9,pppuVar8,param_1[4]);
    param_1[5] = uStack_14;
    if ((8 < uVar3) && ((undefined4 ***)ppuVar5 != (undefined4 ***)0x0)) {
      FUN_01674ea0(ppuVar5);
    }
    if ((8 < uStack_20) && ((undefined4 ***)appuStack_28[0] != (undefined4 ***)0x0)) {
      FUN_01674ea0(appuStack_28[0]);
    }
    bVar2 = true;
    pppuVar8 = (undefined4 ***)appuStack_38[0];
  }
  else {
    if ((8 < uStack_20) && ((undefined4 ***)appuStack_28[0] != (undefined4 ***)0x0)) {
      FUN_01674ea0(appuStack_28[0]);
    }
    bVar2 = false;
  }
  if ((8 < uStack_30) && (pppuVar8 != (undefined4 ***)0x0)) {
    FUN_01674ea0(pppuVar8);
  }
  ppuVar10 = &PTR_FUN_018d4e74;
  if (!bVar2) {
    ppuVar10 = (undefined **)0x0;
  }
  *puStack_18 = ppuVar10;
  if ((8 < param_4) && (param_2 != (undefined4 *)0x0)) {
    FUN_01674ea0(param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7382 ; VA 0x0064e0b0 ; FUN_0064e0b0 */

undefined FUN_0064e0b0(void)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined uVar4;
  undefined4 in_stack_000000b4;
  int *in_stack_000000b8;
  int *in_stack_000000bc;
  undefined auStack_184 [176];
  undefined4 uStack_d4;
  int *piStack_d0;
  undefined auStack_cc [176];
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1550;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00650eb0(&stack0x00000004);
  if (in_stack_000000b8 != (int *)0x0) {
    LOCK();
    in_stack_000000b8[2] = in_stack_000000b8[2] + 1;
    UNLOCK();
  }
  uStack_1c = in_stack_000000b4;
  piStack_18 = in_stack_000000b8;
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(auStack_cc);
  if (cVar2 == '\0') {
    FUN_00650eb0(auStack_cc);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_d4 = uStack_1c;
    piStack_d0 = piStack_18;
    uStack_8._0_1_ = 2;
    iVar3 = FUN_01674e20(0xb8);
    uStack_8._0_1_ = 3;
    iStack_14 = iVar3;
    if (iVar3 == 0) {
      iVar3 = 0;
    }
    else {
      FUN_00650eb0(auStack_184);
      *(undefined4 *)(iVar3 + 0xb0) = 0;
      *(undefined4 *)(iVar3 + 0xb4) = 0;
      if (piStack_d0 != (int *)0x0) {
        LOCK();
        piStack_d0[2] = piStack_d0[2] + 1;
        UNLOCK();
      }
      *(undefined4 *)(iVar3 + 0xb0) = uStack_d4;
      *(int **)(iVar3 + 0xb4) = piStack_d0;
    }
    *in_stack_000000bc = iVar3;
    if (piStack_d0 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_d0[2] + -1;
      piStack_d0[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_d0 + 4))();
      }
    }
    FUN_00651d50();
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    FUN_00651d50();
    uVar4 = 1;
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    FUN_00651d50();
    uVar4 = 0;
  }
  if (in_stack_000000b8 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_000000b8 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*in_stack_000000b8 + 4))();
    }
  }
  FUN_00651d50();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 7383 ; VA 0x0064e2a0 ; FUN_0064e2a0 */

void FUN_0064e2a0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  param_2[6] = 0;
  param_2[7] = 0;
  uVar1 = param_3[3];
  uVar2 = param_3[4];
  uVar3 = param_3[5];
  param_2[2] = param_3[2];
  param_2[3] = uVar1;
  param_2[4] = uVar2;
  param_2[5] = uVar3;
  *(undefined8 *)(param_2 + 6) = *(undefined8 *)(param_3 + 6);
  param_3[6] = 0;
  param_3[7] = 0xf;
  *(undefined *)(param_3 + 2) = 0;
  param_2[0xc] = 0;
  param_2[0xd] = 0;
  uVar1 = param_3[9];
  uVar2 = param_3[10];
  uVar3 = param_3[0xb];
  param_2[8] = param_3[8];
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  *(undefined8 *)(param_2 + 0xc) = *(undefined8 *)(param_3 + 0xc);
  param_3[0xc] = 0;
  param_3[0xd] = 0xf;
  *(undefined *)(param_3 + 8) = 0;
  return;
}



/* FUNCTION 7384 ; VA 0x0064e320 ; FUN_0064e320 */

undefined4 FUN_0064e320(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a156c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadc58) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eadc58);
    if (DAT_01eadc58 == -1) {
      uStack_8 = 0;
      DAT_01eadc54 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01eadc58);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01eadc54;
}



/* FUNCTION 7385 ; VA 0x0064e3a0 ; FUN_0064e3a0 */

void __thiscall FUN_0064e3a0(byte *param_1,int *param_2,uint *param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  byte bVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar6 = (int)param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1588;
  pvStack_10 = ExceptionList;
  bVar3 = *param_1;
  ExceptionList = &pvStack_10;
  uVar9 = FUN_005702d0(param_3);
  FUN_00562fc0(&param_3,uVar9,iVar6,
               -(uint)(param_1 + bVar3 + 1 != (byte *)0x0) & (uint)(param_1 + bVar3 + 1 + 1));
  if (param_3 != (uint *)0x0) {
    *param_2 = (int)param_3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
  uStack_8 = 0;
  piVar10 = (int *)FUN_01674e20(0x20);
  *piVar10 = 0;
  piVar10[1] = 0;
  piVar10[2] = 0;
  piVar10[3] = 0;
  piVar10[4] = 0;
  piVar10[5] = 0;
  piVar10[6] = 0;
  piVar10[7] = 0;
  piVar10[6] = 0;
  piVar10[7] = 0;
  iVar6 = param_4[1];
  iVar7 = param_4[2];
  iVar8 = param_4[3];
  piVar10[2] = *param_4;
  piVar10[3] = iVar6;
  piVar10[4] = iVar7;
  piVar10[5] = iVar8;
  *(undefined8 *)(piVar10 + 6) = *(undefined8 *)(param_4 + 4);
  param_4[4] = 0;
  param_4[5] = 0xf;
  *(undefined *)param_4 = 0;
  uVar4 = *(uint *)(param_1 + 8);
  uVar11 = uVar4 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar11 = FUN_005c9310(uVar11);
    if (uVar11 <= *(uint *)(param_1 + 4)) {
      uVar11 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar11);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar11) {
    param_3 = (uint *)0x1;
    uVar12 = uVar4 >> 1;
    if (uVar4 + (uVar4 >> 1) <= uVar11) {
      uVar12 = 1;
    }
    uVar11 = FUN_005c9310(uVar12 + *(int *)(param_1 + 8));
    param_3 = (uint *)(param_1 + 4);
    if (uVar11 != *param_3) {
      FUN_005d2b00(uVar11);
      puVar13 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_3 * 4);
      puVar5 = (undefined4 *)*puVar13;
      while (puVar5 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_3) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *param_3) * 4) == 0) {
          *piVar1 = (int)puVar13;
          puVar13 = puVar5;
        }
        else {
          *puVar13 = *puVar5;
          *puVar5 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar5;
        }
        puVar5 = (undefined4 *)*puVar13;
      }
    }
  }
  piVar10[1] = uVar9;
  uVar11 = *(uint *)(param_1 + 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar9 % uVar11) * 4);
  if ((int *)*piVar1 == (int *)0x0) {
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + uVar11 * 4);
    if (*piVar2 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % uVar11) * 4) = piVar10;
    }
    *piVar1 = (int)piVar2;
    *piVar10 = *piVar2;
    *piVar2 = (int)piVar10;
  }
  else {
    *piVar10 = *(int *)*piVar1;
    *(int **)*piVar1 = piVar10;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = (int)piVar10;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7386 ; VA 0x0064e5b0 ; FUN_0064e5b0 */

void FUN_0064e5b0(char *param_1,char *param_2,int *param_3)

{
  if (param_1 != param_2) {
    do {
      if ((int)*param_1 == *param_3) {
        return;
      }
      param_1 = param_1 + 1;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 7387 ; VA 0x0064e5e0 ; FUN_0064e5e0 */

undefined4 FUN_0064e5e0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      puVar3 = (undefined4 *)FUN_005c4070();
      return *puVar3;
    }
  }
  return 0;
}



/* FUNCTION 7388 ; VA 0x0064e640 ; FUN_0064e640 */

int FUN_0064e640(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eadc4c,&LAB_0064e290);
  uVar3 = FUN_0064e320();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00bc47d0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 7389 ; VA 0x0064e700 ; FUN_0064e700 */

int FUN_0064e700(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01eadc4c,&LAB_0064e290);
      uVar3 = FUN_0064e320();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00bc47d0();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 7390 ; VA 0x0064e810 ; FUN_0064e810 */

int FUN_0064e810(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
      uVar3 = FUN_00560c40();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00961660();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 7391 ; VA 0x0064e920 ; FUN_0064e920 */

int FUN_0064e920(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8aa8,&LAB_0055d5b0);
      uVar3 = FUN_00560e40();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_005ee510();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 7392 ; VA 0x0064ea30 ; FUN_0064ea30 */

undefined4 *
FUN_0064ea30(undefined4 *param_1,char *param_2,char *param_3,undefined4 param_4,int *param_5,
            uint *param_6)

{
  byte *pbVar1;
  char cVar2;
  byte bVar3;
  char *pcVar4;
  int iVar5;
  byte bVar6;
  int iVar7;
  byte bVar8;
  
  if (param_2 != param_3) {
    do {
      while (iVar5 = (int)*param_2, DAT_01d5a958 == iVar5) {
        iVar5 = 0x3e;
LAB_0064eb01:
        param_2 = param_2 + 1;
        cVar2 = (char)iVar5;
        if (param_2 != param_3) {
          while( true ) {
            iVar5 = (int)*param_2;
            if (DAT_01d5a958 == iVar5) {
              iVar5 = 0x3e;
              goto LAB_0064ebac;
            }
            if (DAT_01d5a95c == iVar5) break;
            if ((iVar5 < DAT_01d5a860) || (DAT_01d5a8c4 < iVar5)) {
              if ((iVar5 < DAT_01d5a8c8) || (DAT_01d5a92c < iVar5)) {
                if ((iVar5 < DAT_01d5a930) || (DAT_01d5a954 < iVar5)) {
                  if (iVar5 == 0x3d) {
                    iVar5 = -1;
                    goto LAB_0064ebac;
                  }
                  iVar5 = -2;
                }
                else {
                  iVar5 = (iVar5 - DAT_01d5a930) + 0x34;
                }
              }
              else {
                iVar5 = (iVar5 - DAT_01d5a8c8) + 0x1a;
              }
            }
            else {
              iVar5 = iVar5 - DAT_01d5a860;
            }
            if ((iVar5 != -2) || (param_2 = param_2 + 1, param_2 == param_3)) goto LAB_0064ebac;
          }
          iVar5 = 0x3f;
        }
LAB_0064ebac:
        if (param_2 == param_3) goto LAB_0064eae1;
        if (iVar5 == -1) {
LAB_0064eabc:
          *param_6 = *param_6 | 2;
          *param_1 = param_2;
          return param_1;
        }
        pcVar4 = param_2 + 1;
        bVar6 = (byte)(iVar5 >> 4) & 3 | cVar2 << 2;
        if (pcVar4 == param_3) {
LAB_0064eec5:
          *param_6 = *param_6 | 3;
          *param_1 = pcVar4;
          return param_1;
        }
        while( true ) {
          iVar7 = (int)*pcVar4;
          if (DAT_01d5a958 == iVar7) {
            iVar7 = 0x3e;
            goto LAB_0064ec6f;
          }
          if (DAT_01d5a95c == iVar7) break;
          if ((iVar7 < DAT_01d5a860) || (DAT_01d5a8c4 < iVar7)) {
            if ((iVar7 < DAT_01d5a8c8) || (DAT_01d5a92c < iVar7)) {
              if ((iVar7 < DAT_01d5a930) || (DAT_01d5a954 < iVar7)) {
                if (iVar7 == 0x3d) {
                  iVar7 = -1;
                  goto LAB_0064ec6f;
                }
                iVar7 = -2;
              }
              else {
                iVar7 = (iVar7 - DAT_01d5a930) + 0x34;
              }
            }
            else {
              iVar7 = (iVar7 - DAT_01d5a8c8) + 0x1a;
            }
          }
          else {
            iVar7 = iVar7 - DAT_01d5a860;
          }
          if ((iVar7 != -2) || (pcVar4 = pcVar4 + 1, pcVar4 == param_3)) goto LAB_0064ec6f;
        }
        iVar7 = 0x3f;
LAB_0064ec6f:
        if (pcVar4 == param_3) goto LAB_0064eec5;
        param_2 = pcVar4 + 1;
        if (iVar7 == -1) {
          if (param_2 == param_3) {
            *param_6 = *param_6 | 1;
          }
          else {
            iVar5 = FUN_00577c50((int)*param_2);
            if (iVar5 == -1) {
              param_2 = pcVar4 + 2;
            }
          }
          FUN_0056ec80(bVar6);
          *param_1 = param_2;
          return param_1;
        }
        bVar3 = (byte)(iVar7 >> 2) & 0xf | (char)iVar5 << 4;
        if (param_2 == param_3) {
LAB_0064ee74:
          *param_6 = *param_6 | 1;
          *param_1 = param_2;
          return param_1;
        }
        while( true ) {
          iVar5 = (int)*param_2;
          if (DAT_01d5a958 == iVar5) {
            iVar5 = 0x3e;
            goto LAB_0064ed30;
          }
          if (DAT_01d5a95c == iVar5) break;
          if ((iVar5 < DAT_01d5a860) || (DAT_01d5a8c4 < iVar5)) {
            if ((iVar5 < DAT_01d5a8c8) || (DAT_01d5a92c < iVar5)) {
              if ((iVar5 < DAT_01d5a930) || (DAT_01d5a954 < iVar5)) {
                if (iVar5 == 0x3d) {
                  iVar5 = -1;
                  goto LAB_0064ed30;
                }
                iVar5 = -2;
              }
              else {
                iVar5 = (iVar5 - DAT_01d5a930) + 0x34;
              }
            }
            else {
              iVar5 = (iVar5 - DAT_01d5a8c8) + 0x1a;
            }
          }
          else {
            iVar5 = iVar5 - DAT_01d5a860;
          }
          if ((iVar5 != -2) || (param_2 = param_2 + 1, param_2 == param_3)) goto LAB_0064ed30;
        }
        iVar5 = 0x3f;
LAB_0064ed30:
        if (param_2 == param_3) goto LAB_0064ee74;
        if (iVar5 == -1) {
          FUN_0056ec80(bVar6);
          FUN_0056ec80(bVar3);
          *param_1 = param_2 + 1;
          return param_1;
        }
        bVar8 = (byte)iVar5 & 0x3f | (char)iVar7 << 6;
        if (param_5 != (int *)0x0) {
          if (*(int *)param_5[8] != 0) {
            iVar5 = *(int *)param_5[0xc];
            if (0 < iVar5) {
              *(int *)param_5[0xc] = iVar5 + -1;
              pbVar1 = *(byte **)param_5[8];
              *(byte **)param_5[8] = pbVar1 + 1;
              *pbVar1 = bVar6;
              goto LAB_0064ed98;
            }
          }
          (**(code **)(*param_5 + 0xc))(bVar6);
        }
LAB_0064ed98:
        if (param_5 != (int *)0x0) {
          if (*(int *)param_5[8] != 0) {
            iVar5 = *(int *)param_5[0xc];
            if (0 < iVar5) {
              *(int *)param_5[0xc] = iVar5 + -1;
              pbVar1 = *(byte **)param_5[8];
              *(byte **)param_5[8] = pbVar1 + 1;
              *pbVar1 = bVar3;
              goto LAB_0064ede7;
            }
          }
          (**(code **)(*param_5 + 0xc))(bVar3);
        }
LAB_0064ede7:
        if (param_5 != (int *)0x0) {
          if (*(int *)param_5[8] != 0) {
            iVar5 = *(int *)param_5[0xc];
            if (0 < iVar5) {
              *(int *)param_5[0xc] = iVar5 + -1;
              pbVar1 = *(byte **)param_5[8];
              *(byte **)param_5[8] = pbVar1 + 1;
              *pbVar1 = bVar8;
              goto LAB_0064ee30;
            }
          }
          (**(code **)(*param_5 + 0xc))(bVar8);
        }
LAB_0064ee30:
        param_2 = param_2 + 1;
        if (param_2 == param_3) {
          *param_1 = param_2;
          return param_1;
        }
      }
      if (DAT_01d5a95c == iVar5) {
        iVar5 = 0x3f;
        goto LAB_0064eb01;
      }
      if ((iVar5 < DAT_01d5a860) || (DAT_01d5a8c4 < iVar5)) {
        if ((DAT_01d5a8c8 <= iVar5) && (iVar5 <= DAT_01d5a92c)) {
          iVar5 = (iVar5 - DAT_01d5a8c8) + 0x1a;
          goto LAB_0064eaae;
        }
        if ((DAT_01d5a930 <= iVar5) && (iVar5 <= DAT_01d5a954)) {
          iVar5 = (iVar5 - DAT_01d5a930) + 0x34;
          goto LAB_0064eaae;
        }
        if (iVar5 == 0x3d) goto LAB_0064eabc;
      }
      else {
        iVar5 = iVar5 - DAT_01d5a860;
LAB_0064eaae:
        if ((-1 < iVar5) || (iVar5 != -2)) {
          if (iVar5 == -1) goto LAB_0064eabc;
          goto LAB_0064eb01;
        }
      }
      param_2 = param_2 + 1;
    } while (param_2 != param_3);
LAB_0064eae1:
    *param_6 = *param_6 | 3;
  }
  *param_1 = param_2;
  return param_1;
}



/* FUNCTION 7393 ; VA 0x0064eee0 ; FUN_0064eee0 */

void FUN_0064eee0(uint param_1)

{
  undefined4 uVar1;
  undefined uVar2;
  bool bVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  bool bVar10;
  uint in_stack_00000044;
  undefined auStack_bc [8];
  uint uStack_b4;
  undefined auStack_ac [24];
  int *piStack_94;
  int iStack_90;
  int *piStack_8c;
  int *piStack_88;
  char cStack_84;
  undefined auStack_74 [4];
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined auStack_50 [24];
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  char cStack_28;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a15cb;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00640080(&param_1);
  uStack_8._0_1_ = 2;
  FUN_00640080(&stack0x00000044);
  uStack_8._0_1_ = 3;
  piStack_14 = piStack_30;
LAB_0064ef40:
  do {
    if ((uStack_58 == 0) || (cStack_28 != '\0')) {
      bVar10 = true;
    }
    else {
      bVar10 = false;
    }
    if ((uStack_b4 == 0) || (cStack_84 != '\0')) {
      bVar3 = true;
    }
    else {
      bVar3 = false;
    }
    if ((bVar10) || (bVar3)) {
      bVar10 = (bool)(bVar3 ^ bVar10 ^ 1);
    }
    else {
      uVar6 = (int)piStack_34 - (int)piStack_38;
      piVar9 = piStack_94;
      piVar8 = piStack_38;
      if (uVar6 == iStack_90 - (int)piStack_94) {
        while (uVar7 = uVar6 - 4, 3 < uVar6) {
          if (*piVar8 != *piVar9) goto LAB_0064efa7;
          piVar9 = piVar9 + 1;
          piVar8 = piVar8 + 1;
          uVar6 = uVar7;
        }
        if (uVar7 != 0xfffffffc) {
LAB_0064efa7:
          if ((*(char *)piVar8 != *(char *)piVar9) ||
             ((uVar7 != 0xfffffffd &&
              ((*(char *)((int)piVar8 + 1) != *(char *)((int)piVar9 + 1) ||
               ((uVar7 != 0xfffffffe &&
                ((*(char *)((int)piVar8 + 2) != *(char *)((int)piVar9 + 2) ||
                 ((uVar7 != 0xffffffff && (*(char *)((int)piVar8 + 3) != *(char *)((int)piVar9 + 3))
                  ))))))))))) goto LAB_0064eff4;
        }
        if ((piStack_14 == piStack_8c) && (piStack_2c == piStack_88)) {
          bVar10 = true;
          goto LAB_0064f002;
        }
      }
LAB_0064eff4:
      bVar10 = false;
    }
LAB_0064f002:
    piStack_30 = piStack_14;
    if (bVar10) {
      uStack_8._0_1_ = 6;
      if (uStack_b4 != 0) {
        if (((uStack_b4 & 1) == 0) && (*(code **)(uStack_b4 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(uStack_b4 & 0xfffffffe))(auStack_ac,auStack_ac,2);
        }
        uStack_b4 = 0;
      }
      uStack_8._0_1_ = 7;
      if (uStack_58 != 0) {
        if (((uStack_58 & 1) == 0) && (*(code **)(uStack_58 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(uStack_58 & 0xfffffffe))(auStack_50,auStack_50,2);
        }
        uStack_58 = 0;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      if (param_1 != 0) {
        if (((param_1 & 1) == 0) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
        }
        param_1 = 0;
      }
      uStack_8 = 9;
      if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
         (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_00000044 & 0xfffffffe))(&stack0x0000004c,&stack0x0000004c,2);
      }
      ExceptionList = pvStack_10;
      return;
    }
    auStack_70[0] = auStack_70[0] & 0xffffff00;
    uStack_60 = 0;
    uStack_5c = 0xf;
    if (piStack_38 != piStack_34) {
      FUN_005542c0(piStack_38,(int)piStack_34 - (int)piStack_38);
    }
    uStack_8._0_1_ = 5;
    uVar1 = *puStack_18;
    iVar4 = FUN_00559370(auStack_70);
    FUN_0064c760(auStack_74,uVar1,iVar4 + 0x10,iVar4);
    uStack_8._0_1_ = 3;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_5c) {
      uVar7 = uStack_5c + 1;
      uVar6 = auStack_70[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_70[0] - 4);
        uVar7 = uStack_5c + 0x24;
        if (0x1f < (auStack_70[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    piVar8 = piStack_2c;
    piVar9 = piStack_2c;
    if (uStack_58 == 0) {
LAB_0064f0e4:
      bVar10 = piStack_34 == piStack_2c;
      piStack_38 = piStack_30;
      piStack_34 = piVar9;
      piStack_14 = piVar8;
      if (bVar10) {
        cStack_28 = '\x01';
      }
      goto LAB_0064ef40;
    }
    puVar5 = (undefined4 *)
             (**(code **)((uStack_58 & 0xfffffffe) + 4))
                       (auStack_bc,auStack_50,piStack_30,piStack_2c);
    piVar9 = (int *)*puVar5;
    piVar8 = (int *)puVar5[1];
    if ((piVar9 == piStack_2c) && (piVar8 == piStack_2c)) goto LAB_0064f0e4;
    piStack_38 = piStack_30;
    piStack_34 = piVar9;
    piStack_14 = piVar8;
  } while( true );
}



/* FUNCTION 7394 ; VA 0x0064f1d0 ; FUN_0064f1d0 */

undefined4 * FUN_0064f1d0(undefined4 *param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  undefined4 *puVar3;
  char *pcVar4;
  uint uVar5;
  
  pcVar2 = (char *)*param_2;
  pcVar4 = pcVar2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  uVar5 = (int)pcVar4 - (int)(pcVar2 + 1);
  *param_1 = 0;
  param_1[2] = uVar5;
  puVar3 = param_1;
  if (8 < uVar5) {
    puVar3 = (undefined4 *)FUN_01674e20(uVar5);
    *param_1 = puVar3;
  }
  FUN_0170cc70(puVar3,pcVar2,uVar5);
  FUN_0063e660(puVar3,param_1[2] + (int)puVar3,param_1[2],pcVar2);
  return param_1;
}



/* FUNCTION 7395 ; VA 0x0064f240 ; FUN_0064f240 */

int ** FUN_0064f240(int **param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
                   uint param_5,uint *param_6)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined auStack_1a8 [36];
  undefined4 uStack_184;
  undefined *puStack_180;
  undefined4 *puStack_17c;
  uint uStack_178;
  undefined *puStack_174;
  undefined4 uStack_170;
  uint *puStack_16c;
  uint *puStack_168;
  undefined4 auStack_164 [8];
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined *puStack_134;
  int *piStack_130;
  uint *puStack_12c;
  uint auStack_11c [2];
  undefined auStack_114 [56];
  uint auStack_dc [2];
  undefined auStack_d4 [56];
  uint auStack_9c [2];
  undefined auStack_94 [56];
  uint auStack_5c [2];
  undefined auStack_54 [56];
  undefined *puStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a162c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar4 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar4 = (undefined4 *)*param_2;
  }
  iVar1 = param_2[4];
  puVar5 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar5 = (undefined4 *)*param_2;
  }
  puStack_12c = param_2;
  puStack_1c = (undefined *)&puStack_174;
  puStack_180 = (undefined *)&puStack_174;
  puStack_16c = (uint *)param_5;
  puStack_174 = (undefined *)0x0;
  if (param_5 < 9) {
    puStack_17c = &param_3;
    ExceptionList = &pvStack_10;
    puStack_1c = (undefined *)&puStack_174;
  }
  else {
    uStack_178 = param_5;
    puStack_17c = (undefined4 *)0x64f2b2;
    ExceptionList = &pvStack_10;
    puStack_180 = (undefined *)FUN_01674e20();
    puStack_17c = param_3;
    puStack_174 = puStack_180;
  }
  uStack_184 = 0x64f2c7;
  uStack_178 = (uint)puStack_16c;
  FUN_0170c6f0();
  puStack_168 = param_6;
  puStack_180 = (undefined *)0x64f2da;
  puStack_17c = puVar5;
  uStack_178 = iVar1 + (int)puVar4;
  FUN_0064b800();
  puStack_168 = auStack_11c;
  puStack_16c = (uint *)0x64f2e6;
  FUN_0064f850();
  uStack_8._0_1_ = 1;
  auStack_164[0] = 0;
  uStack_144 = 0;
  uStack_140 = 0;
  uStack_13c = 0;
  uStack_138 = 0;
  puStack_134 = (undefined *)CONCAT31(puStack_134._1_3_,1);
  puStack_168 = auStack_dc;
  puStack_16c = (uint *)0x64f327;
  puStack_12c = auStack_164;
  FUN_0064f850();
  puStack_12c = auStack_dc;
  uStack_8._0_1_ = 2;
  piStack_130 = (int *)0x64f340;
  FUN_00640080();
  puStack_12c = auStack_11c;
  uStack_8._0_1_ = 3;
  piStack_130 = (int *)0x64f353;
  FUN_00640080();
  uStack_8._0_1_ = 5;
  piStack_18 = (int *)0x0;
  piStack_14 = (int *)0x0;
  puStack_12c = (uint *)0x64f36d;
  piStack_18 = (int *)FUN_00575b30();
  puStack_1c = (undefined *)&puStack_168;
  uStack_8._0_1_ = 6;
  puStack_16c = auStack_9c;
  uStack_170 = 0x64f38b;
  FUN_00640080();
  puStack_1c = auStack_1a8;
  uStack_8._0_1_ = 7;
  FUN_00640080(auStack_5c);
  uStack_8._0_1_ = 6;
  FUN_0064eee0();
  uStack_8._0_1_ = 8;
  if (auStack_5c[0] != 0) {
    if (((auStack_5c[0] & 1) == 0) && (*(code **)(auStack_5c[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_134 = auStack_54;
      puStack_12c = (uint *)0x2;
      uStack_138 = 0x64f3cd;
      piStack_130 = (int *)puStack_134;
      (**(code **)(auStack_5c[0] & 0xfffffffe))();
    }
    auStack_5c[0] = 0;
  }
  uStack_8._0_1_ = 9;
  if (((auStack_9c[0] != 0) && ((auStack_9c[0] & 1) == 0)) &&
     (*(code **)(auStack_9c[0] & 0xfffffffe) != (code *)0x0)) {
    puStack_134 = auStack_94;
    puStack_12c = (uint *)0x2;
    uStack_138 = 0x64f3fe;
    piStack_130 = (int *)puStack_134;
    (**(code **)(auStack_9c[0] & 0xfffffffe))();
  }
  if (param_1 != &piStack_18) {
    piVar2 = *param_1;
    *param_1 = piStack_18;
    piVar3 = param_1[1];
    param_1[1] = piStack_14;
    piStack_18 = piVar2;
    piStack_14 = piVar3;
  }
  piVar2 = piStack_18;
  puStack_12c = (uint *)piStack_18[1];
  uStack_8._0_1_ = 10;
  piStack_130 = (int *)0x64f435;
  FUN_00576720();
  puStack_12c = (uint *)0x28;
  piStack_18[1] = (int)piVar2;
  *piStack_18 = (int)piVar2;
  piStack_18[2] = (int)piVar2;
  piStack_130 = piStack_18;
  piStack_14 = (int *)0x0;
  puStack_134 = (undefined *)0x64f457;
  FUN_01674ea0();
  uStack_8._0_1_ = 0xb;
  if (auStack_dc[0] != 0) {
    if (((auStack_dc[0] & 1) == 0) && (*(code **)(auStack_dc[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_134 = auStack_d4;
      puStack_12c = (uint *)0x2;
      uStack_138 = 0x64f481;
      piStack_130 = (int *)puStack_134;
      (**(code **)(auStack_dc[0] & 0xfffffffe))();
    }
    auStack_dc[0] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (auStack_11c[0] != 0) {
    if (((auStack_11c[0] & 1) == 0) && (*(code **)(auStack_11c[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_134 = auStack_114;
      puStack_12c = (uint *)0x2;
      uStack_138 = 0x64f4b5;
      piStack_130 = (int *)puStack_134;
      (**(code **)(auStack_11c[0] & 0xfffffffe))();
    }
    auStack_11c[0] = 0;
  }
  if ((8 < param_5) && (param_3 != (undefined4 *)0x0)) {
    puStack_12c = param_3;
    piStack_130 = (int *)0x64f4d5;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7396 ; VA 0x0064f4f0 ; FUN_0064f4f0 */

undefined4 *
FUN_0064f4f0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            uint param_5,undefined4 param_6)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined auStack_1b0 [40];
  undefined4 uStack_188;
  undefined *puStack_184;
  undefined4 *puStack_180;
  uint uStack_17c;
  undefined *puStack_178;
  uint *puStack_174;
  uint uStack_170;
  uint *puStack_16c;
  undefined4 auStack_168 [8];
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined *puStack_138;
  undefined *puStack_134;
  uint *puStack_130;
  uint auStack_120 [2];
  undefined auStack_118 [56];
  uint auStack_e0 [2];
  undefined auStack_d8 [56];
  uint auStack_a0 [2];
  undefined auStack_98 [56];
  uint auStack_60 [2];
  undefined auStack_58 [56];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1684;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar5 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar5 = (undefined4 *)*param_2;
  }
  iVar1 = param_2[4];
  puVar6 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar6 = (undefined4 *)*param_2;
  }
  puStack_130 = param_2;
  puStack_14 = (undefined *)&puStack_178;
  puStack_184 = (undefined *)&puStack_178;
  uStack_170 = param_5;
  puStack_178 = (undefined *)0x0;
  if (param_5 < 9) {
    puStack_180 = &param_3;
    ExceptionList = &pvStack_10;
    puStack_14 = (undefined *)&puStack_178;
  }
  else {
    uStack_17c = param_5;
    puStack_180 = (undefined4 *)0x64f562;
    ExceptionList = &pvStack_10;
    puStack_184 = (undefined *)FUN_01674e20();
    puStack_180 = param_3;
    puStack_178 = puStack_184;
  }
  uStack_188 = 0x64f577;
  uStack_17c = uStack_170;
  FUN_0170c6f0();
  puStack_16c = (uint *)param_6;
  puStack_184 = (undefined *)0x64f58a;
  puStack_180 = puVar6;
  uStack_17c = iVar1 + (int)puVar5;
  FUN_0064b800();
  puStack_16c = auStack_120;
  uStack_170 = 0x64f596;
  FUN_0064f850();
  uStack_8._0_1_ = 1;
  auStack_168[0] = 0;
  uStack_148 = 0;
  uStack_144 = 0;
  uStack_140 = 0;
  uStack_13c = 0;
  puStack_138 = (undefined *)CONCAT31(puStack_138._1_3_,1);
  puStack_16c = auStack_e0;
  uStack_170 = 0x64f5d7;
  puStack_130 = auStack_168;
  FUN_0064f850();
  puStack_130 = auStack_e0;
  uStack_8._0_1_ = 2;
  puStack_134 = (undefined *)0x64f5f0;
  FUN_00640080();
  puStack_130 = auStack_120;
  uStack_8._0_1_ = 3;
  puStack_134 = (undefined *)0x64f603;
  FUN_00640080();
  puStack_174 = auStack_a0;
  uStack_8._0_1_ = 5;
  puStack_14 = (undefined *)&uStack_170;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  puStack_178 = (undefined *)0x64f636;
  puStack_130 = auStack_168;
  FUN_00640080();
  puStack_14 = auStack_1b0;
  uStack_8._0_1_ = 6;
  FUN_00640080(auStack_60);
  uStack_8._0_1_ = 5;
  FUN_0064d290();
  uStack_8._0_1_ = 7;
  if (auStack_60[0] != 0) {
    if (((auStack_60[0] & 1) == 0) && (*(code **)(auStack_60[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = auStack_58;
      puStack_130 = (uint *)0x2;
      uStack_13c = 0x64f678;
      puStack_134 = puStack_138;
      (**(code **)(auStack_60[0] & 0xfffffffe))();
    }
    auStack_60[0] = 0;
  }
  uStack_8._0_1_ = 8;
  if (((auStack_a0[0] != 0) && ((auStack_a0[0] & 1) == 0)) &&
     (*(code **)(auStack_a0[0] & 0xfffffffe) != (code *)0x0)) {
    puStack_138 = auStack_98;
    puStack_130 = (uint *)0x2;
    uStack_13c = 0x64f6a9;
    puStack_134 = puStack_138;
    (**(code **)(auStack_a0[0] & 0xfffffffe))();
  }
  if (param_1 != &uStack_20) {
    uVar2 = *param_1;
    *param_1 = uStack_20;
    uVar3 = param_1[1];
    param_1[1] = uStack_1c;
    uVar4 = param_1[2];
    param_1[2] = uStack_18;
    uStack_20 = uVar2;
    uStack_1c = uVar3;
    uStack_18 = uVar4;
  }
  puStack_130 = (uint *)0x64f6e0;
  FUN_00577a40();
  uStack_8._0_1_ = 9;
  if (auStack_e0[0] != 0) {
    if (((auStack_e0[0] & 1) == 0) && (*(code **)(auStack_e0[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = auStack_d8;
      puStack_130 = (uint *)0x2;
      uStack_13c = 0x64f707;
      puStack_134 = puStack_138;
      (**(code **)(auStack_e0[0] & 0xfffffffe))();
    }
    auStack_e0[0] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (auStack_120[0] != 0) {
    if (((auStack_120[0] & 1) == 0) && (*(code **)(auStack_120[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_138 = auStack_118;
      puStack_130 = (uint *)0x2;
      uStack_13c = 0x64f73b;
      puStack_134 = puStack_138;
      (**(code **)(auStack_120[0] & 0xfffffffe))();
    }
    auStack_120[0] = 0;
  }
  if ((8 < param_5) && (param_3 != (undefined4 *)0x0)) {
    puStack_130 = param_3;
    puStack_134 = (undefined *)0x64f75b;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7397 ; VA 0x0064f780 ; FUN_0064f780 */

ushort __thiscall FUN_0064f780(int param_1,undefined *param_2,undefined *param_3,char param_4)

{
  undefined uVar1;
  char cVar2;
  char cVar3;
  ushort uVar4;
  int iVar5;
  int iVar6;
  undefined *puVar7;
  undefined *puVar8;
  int iStack_8;
  
  iStack_8 = 0;
  iVar6 = 0;
  if (PTR_s_alnum_018d4e80 != (undefined *)0x0) {
    iVar5 = 0;
    do {
      if ((int)param_3 - (int)param_2 == *(int *)((int)&DAT_018d4e88 + iVar5)) {
        puVar8 = *(undefined **)((int)&PTR_s_alnum_018d4e80 + iVar5);
        iVar6 = iStack_8;
        puVar7 = param_2;
        if (param_2 == param_3) break;
        while( true ) {
          uVar1 = *puVar7;
          cVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x10))(*puVar8);
          cVar3 = (**(code **)(**(int **)(param_1 + 4) + 0x10))(uVar1);
          if (cVar3 != cVar2) break;
          puVar7 = puVar7 + 1;
          puVar8 = puVar8 + 1;
          if (puVar7 == param_3) goto LAB_0064f805;
        }
      }
      iVar6 = iStack_8 + 1;
      iVar5 = iVar6 * 0x10;
      iStack_8 = iVar6;
    } while ((&PTR_s_alnum_018d4e80)[iVar6 * 4] != (undefined *)0x0);
  }
LAB_0064f805:
  uVar4 = 0;
  if ((&PTR_s_alnum_018d4e80)[iVar6 * 4] != (undefined *)0x0) {
    uVar4 = *(ushort *)(&DAT_018d4e8c + iVar6 * 0x10);
  }
  if ((param_4 != '\0') && ((uVar4 & 3) != 0)) {
    uVar4 = uVar4 | 3;
  }
  return uVar4;
}



/* FUNCTION 7398 ; VA 0x0064f850 ; FUN_0064f850 */

undefined4 FUN_0064f850(undefined4 param_1,uint param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1698;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00640080(&param_2);
  uStack_8 = 1;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&stack0x00000010,&stack0x00000010,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7399 ; VA 0x0064f8c0 ; FUN_0064f8c0 */

int * FUN_0064f8c0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eadc4c,&LAB_0064e290);
  uVar3 = FUN_0064e320();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00bc47d0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 7400 ; VA 0x0064f970 ; FUN_0064f970 */

undefined4
FUN_0064f970(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4,
            uint param_5,undefined4 param_6)

{
  undefined **ppuVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined *puStack_3c;
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [8];
  undefined4 uStack_24;
  undefined4 *puStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a16b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_30 = param_6;
  ppuVar1 = &puStack_3c;
  uStack_34 = param_5;
  puStack_3c = (undefined *)0x0;
  if (param_5 < 9) {
    puVar3 = &param_3;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    ppuVar1 = (undefined **)FUN_01674e20(param_5);
    puVar3 = param_3;
    puStack_3c = (undefined *)ppuVar1;
  }
  FUN_0170c6f0(ppuVar1,puVar3,uStack_34);
  FUN_0063fec0(auStack_2c);
  uStack_30 = param_2;
  uStack_34 = param_1;
  uStack_38 = 0x64f9e9;
  uVar2 = FUN_0064f240();
  if ((8 < param_5) && (param_3 != (undefined4 *)0x0)) {
    puStack_20 = param_3;
    uStack_24 = 0x64fa01;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 7401 ; VA 0x0064fa20 ; FUN_0064fa20 */

undefined4
FUN_0064fa20(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4,
            uint param_5,undefined4 param_6)

{
  undefined **ppuVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined *puStack_3c;
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [8];
  undefined4 uStack_24;
  undefined4 *puStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a16b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_30 = param_6;
  ppuVar1 = &puStack_3c;
  uStack_34 = param_5;
  puStack_3c = (undefined *)0x0;
  if (param_5 < 9) {
    puVar3 = &param_3;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    ppuVar1 = (undefined **)FUN_01674e20(param_5);
    puVar3 = param_3;
    puStack_3c = (undefined *)ppuVar1;
  }
  FUN_0170c6f0(ppuVar1,puVar3,uStack_34);
  FUN_0063fec0(auStack_2c);
  uStack_30 = param_2;
  uStack_34 = param_1;
  uStack_38 = 0x64fa99;
  uVar2 = FUN_0064f4f0();
  if ((8 < param_5) && (param_3 != (undefined4 *)0x0)) {
    puStack_20 = param_3;
    uStack_24 = 0x64fab1;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 7402 ; VA 0x0064fad0 ; FUN_0064fad0 */

void FUN_0064fad0(byte *param_1,ushort param_2,undefined4 param_3,int *param_4)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  byte *pbVar5;
  int *piVar6;
  byte *pbVar7;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  ushort uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a16e8;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_4 + 4))(param_2);
  pbVar7 = param_1;
  uStack_8._0_1_ = 0;
  FUN_0064fc40(param_1);
  uStack_12 = param_2;
  uStack_8._0_1_ = 2;
  piStack_18 = param_4;
  (**(code **)(*param_4 + 4))();
  piVar6 = piStack_18;
  pbVar5 = pbVar7;
  if (0xf < *(uint *)(pbVar7 + 0x14)) {
    pbVar5 = *(byte **)pbVar7;
  }
  iVar2 = *(int *)(pbVar7 + 0x10);
  if (0xf < *(uint *)(pbVar7 + 0x14)) {
    pbVar7 = *(byte **)pbVar7;
  }
  uStack_8._0_1_ = 4;
  piStack_1c = piStack_18;
  (**(code **)(*piStack_18 + 4))();
  uStack_8._0_1_ = 5;
  do {
    if (pbVar7 == pbVar5 + iVar2) {
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
LAB_0064fbae:
      puVar4 = (undefined4 *)(**(code **)(*piVar6 + 8))();
      if (puVar4 != (undefined4 *)0x0) {
        (**(code **)*puVar4)(1);
      }
      uStack_8._0_1_ = 3;
      pbVar5 = param_1;
      if (0xf < *(uint *)(param_1 + 0x14)) {
        pbVar5 = *(byte **)param_1;
      }
      FUN_0063a690(&param_1,pbVar5,pbVar7);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      puVar4 = (undefined4 *)(**(code **)(*piVar6 + 8))();
      if (puVar4 != (undefined4 *)0x0) {
        (**(code **)*puVar4)(1);
      }
      uStack_8 = 9;
      if ((param_4 != (int *)0x0) &&
         (puVar4 = (undefined4 *)(**(code **)(*param_4 + 8))(), puVar4 != (undefined4 *)0x0)) {
        (**(code **)*puVar4)(1);
      }
      ExceptionList = pvStack_10;
      return;
    }
    bVar1 = *pbVar7;
    iVar3 = FUN_0054e7d0(auStack_20);
    piVar6 = piStack_18;
    if ((*(ushort *)(*(int *)(iVar3 + 0xc) + (uint)bVar1 * 2) & uStack_12) == 0) {
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      goto LAB_0064fbae;
    }
    pbVar7 = pbVar7 + 1;
  } while( true );
}



/* FUNCTION 7403 ; VA 0x0064fc40 ; FUN_0064fc40 */

void FUN_0064fc40(undefined4 *param_1,ushort param_2,undefined4 param_3,int *param_4)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  ushort uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a1718;
  pvStack_10 = ExceptionList;
  uVar2 = param_1[5];
  puVar5 = param_1;
  if (0xf < uVar2) {
    puVar5 = (undefined4 *)*param_1;
  }
  iVar3 = param_1[4];
  puVar7 = param_1;
  if (0xf < uVar2) {
    puVar7 = (undefined4 *)*param_1;
  }
  puVar7 = (undefined4 *)(iVar3 + (int)puVar7);
  puStack_20 = param_1;
  if (0xf < uVar2) {
    puStack_20 = (undefined4 *)*param_1;
  }
  puVar6 = puStack_20;
  uStack_12 = param_2;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  piStack_18 = param_4;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_4 + 4))();
  uStack_8._0_1_ = 3;
  piStack_24 = piStack_18;
  (**(code **)(*piStack_18 + 4))();
  uStack_8._0_1_ = 4;
  if (puVar7 != puVar6) {
    do {
      bVar1 = *(byte *)((int)puVar7 + -1);
      puVar8 = (undefined4 *)((int)puVar7 + -1);
      puStack_1c = puVar7;
      iVar4 = FUN_0054e7d0(auStack_28);
      piVar9 = piStack_18;
      if ((*(ushort *)(*(int *)(iVar4 + 0xc) + (uint)bVar1 * 2) & uStack_12) == 0) {
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        puVar7 = (undefined4 *)(**(code **)(*piStack_18 + 8))();
        puVar6 = puStack_1c;
        if (puVar7 != (undefined4 *)0x0) {
          (**(code **)*puVar7)(1);
          puVar6 = puStack_1c;
        }
        goto LAB_0064fd3a;
      }
      puVar6 = puStack_20;
      puVar7 = puVar8;
    } while (puVar8 != puStack_20);
  }
  piVar9 = piStack_18;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  puVar7 = (undefined4 *)(**(code **)(*piStack_18 + 8))();
  puStack_1c = puVar6;
  if (puVar7 != (undefined4 *)0x0) {
    (**(code **)*puVar7)(1);
  }
LAB_0064fd3a:
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  puVar7 = (undefined4 *)(**(code **)(*piVar9 + 8))();
  if (puVar7 != (undefined4 *)0x0) {
    (**(code **)*puVar7)(1);
  }
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_0063a690(&puStack_20,puVar6,iVar3 + (int)puVar5);
  uStack_8 = 8;
  if ((param_4 != (int *)0x0) &&
     (puVar5 = (undefined4 *)(**(code **)(*param_4 + 8))(), puVar5 != (undefined4 *)0x0)) {
    (**(code **)*puVar5)(1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7404 ; VA 0x0064fda0 ; FUN_0064fda0 */

int * FUN_0064fda0(int param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_28 [20];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1740;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016dda75(0);
  piVar2 = DAT_01eadc48;
  uStack_8 = 0;
  piStack_14 = DAT_01eadc48;
  if (DAT_01eadc44 == 0) {
    FUN_016dda75(0);
    if (DAT_01eadc44 == 0) {
      DAT_01eadc44 = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eadc44;
    }
    FUN_016ddacd();
  }
  uVar1 = DAT_01eadc44;
  iVar3 = *(int *)(param_1 + 4);
  if (DAT_01eadc44 < *(uint *)(iVar3 + 0xc)) {
    piVar4 = *(int **)(*(int *)(iVar3 + 8) + DAT_01eadc44 * 4);
    if (piVar4 != (int *)0x0) goto LAB_0064fe80;
  }
  else {
    piVar4 = (int *)0x0;
  }
  if (*(char *)(iVar3 + 0x14) == '\0') {
LAB_0064fe40:
    if (piVar4 != (int *)0x0) goto LAB_0064fe80;
  }
  else {
    iVar3 = FUN_016de17b();
    if (uVar1 < *(uint *)(iVar3 + 0xc)) {
      piVar4 = *(int **)(*(int *)(iVar3 + 8) + uVar1 * 4);
      goto LAB_0064fe40;
    }
  }
  piVar4 = piVar2;
  if (piVar2 == (int *)0x0) {
    iVar3 = FUN_006567f0(&piStack_14,param_1);
    piVar4 = piStack_14;
    if (iVar3 == -1) {
      FUN_0054fc60();
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_28,&DAT_01c24924);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_016de14f(piStack_14);
    (**(code **)(*piVar4 + 4))();
    DAT_01eadc48 = piVar4;
  }
LAB_0064fe80:
  FUN_016ddacd();
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 7405 ; VA 0x0064fec0 ; FUN_0064fec0 */

int __thiscall FUN_0064fec0(int param_1,int param_2)

{
  int *piVar1;
  
  FUN_00650eb0(param_2);
  *(undefined4 *)(param_1 + 0xb0) = 0;
  *(undefined4 *)(param_1 + 0xb4) = 0;
  if (*(int *)(param_2 + 0xb4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0xb4) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0xb0) = *(undefined4 *)(param_2 + 0xb0);
  *(undefined4 *)(param_1 + 0xb4) = *(undefined4 *)(param_2 + 0xb4);
  return param_1;
}



/* FUNCTION 7406 ; VA 0x0064ff20 ; FUN_0064ff20 */

int __thiscall
FUN_0064ff20(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,uint param_8)

{
  undefined uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a176e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x50) = param_3;
  *(undefined4 *)(param_1 + 0x54) = param_2;
  *(undefined4 *)(param_1 + 0x5c) = param_7;
  *(int *)(param_1 + 0x58) = param_5;
  *(uint *)(param_1 + 0x60) = param_8;
  *(undefined *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x68) = param_6;
  uStack_8 = 2;
  if (((*(byte *)(param_5 + 8) & 8) == 0) || ((param_8 & 0x10) != 0)) {
    uVar1 = 0;
  }
  else {
    uVar1 = 1;
  }
  *(undefined *)(param_1 + 0x6c) = uVar1;
  *(undefined4 *)(param_1 + 0x70) = param_4;
  FUN_0064d540(*(undefined4 *)(param_5 + 0x18),(undefined4 *)(param_1 + 0x40));
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7407 ; VA 0x00650030 ; FUN_00650030 */

undefined4 * __thiscall
FUN_00650030(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4,
            uint param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1793;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_3;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = 0;
  param_1[4] = 0;
  param_4 = 0;
  FUN_005d0b80(0,&param_4,(int)&param_3 + 3);
  param_1[8] = 0;
  iVar1 = param_1[5];
  if ((param_1[6] - iVar1 >> 2 != 0) && (iVar1 != param_1[6])) {
    param_1[6] = iVar1;
  }
  param_1[8] = 0;
  uStack_8 = 1;
  param_3 = (undefined4 *)FUN_01674e20(0x24);
  if (param_3 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    param_3[1] = 0x14;
    param_3[2] = 0;
    param_3[3] = 0;
    param_3[4] = 0;
    *param_3 = std::_Root_node::vftable;
    param_3[6] = 0;
    param_3[7] = 0;
    param_3[8] = 0;
    puVar2 = param_3;
  }
  param_1[9] = puVar2;
  param_1[10] = puVar2;
  param_1[0xb] = param_5;
  param_1[0xc] = param_2;
  param_1[0xd] = ~(param_5 >> 3) & 0x100;
  param_1[0xe] = ~(param_5 >> 9) & 4;
  param_1[0x10] = param_5;
  uVar4 = param_5 & 0x3f;
  param_1[0xf] = param_2;
  if ((uVar4 == 1) || (uVar4 == 0)) {
    uVar3 = 0x8775dfb;
  }
  else if (uVar4 == 2) {
    uVar3 = 0x6e000300;
  }
  else if (uVar4 == 4) {
    uVar3 = 0x7080001b;
  }
  else if (uVar4 == 8) {
    uVar3 = 0x7181a01b;
  }
  else if (uVar4 == 0x10) {
    uVar3 = 0x6e080304;
  }
  else {
    uVar3 = 0;
    if (uVar4 == 0x20) {
      uVar3 = 0x7088001f;
    }
  }
  param_1[0x14] = uVar3;
  if ((uVar3 & 0x40000000) != 0) {
    *(uint *)(param_1[9] + 8) = *(uint *)(param_1[9] + 8) | 8;
  }
  FUN_006576b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7408 ; VA 0x006501b0 ; FUN_006501b0 */

int * __thiscall FUN_006501b0(int *param_1,char *param_2,undefined4 param_3)

{
  int iVar1;
  char *pcVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  int iStack_78;
  int iStack_70;
  undefined auStack_38 [12];
  int *piStack_2c;
  int *piStack_28;
  int *piStack_20;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a17d1;
  pvStack_10 = ExceptionList;
  piStack_2c = param_1 + 1;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  piStack_14 = param_1 + 3;
  uStack_8 = 0;
  piStack_28 = param_1;
  iVar3 = FUN_016de181(1);
  param_1[4] = iVar3;
  uStack_8 = 1;
  FUN_016dda75(0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  piStack_20 = DAT_01eadc48;
  piStack_18 = DAT_01eadc48;
  if (DAT_01eadc44 == 0) {
    FUN_016dda75(0);
    if (DAT_01eadc44 == 0) {
      DAT_01eadc44 = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eadc44;
    }
    FUN_016ddacd();
  }
  uVar5 = DAT_01eadc44;
  iVar3 = param_1[4];
  if (DAT_01eadc44 < *(uint *)(iVar3 + 0xc)) {
    piVar7 = *(int **)(*(int *)(iVar3 + 8) + DAT_01eadc44 * 4);
    piVar6 = piStack_14;
    if (piVar7 != (int *)0x0) goto LAB_0065026f;
  }
  else {
    piVar7 = (int *)0x0;
  }
  if (*(char *)(iVar3 + 0x14) == '\0') {
LAB_0065033f:
    piVar6 = piStack_14;
    if (piVar7 != (int *)0x0) goto LAB_0065026f;
  }
  else {
    iVar3 = FUN_016de17b();
    if (uVar5 < *(uint *)(iVar3 + 0xc)) {
      piVar7 = *(int **)(*(int *)(iVar3 + 8) + uVar5 * 4);
      goto LAB_0065033f;
    }
  }
  piVar6 = piStack_14;
  piVar7 = piStack_20;
  if (piStack_20 == (int *)0x0) {
    iVar3 = FUN_006567f0(&piStack_18,piStack_14);
    piVar7 = piStack_18;
    if (iVar3 == -1) {
      FUN_0054fc60();
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_38,&DAT_01c24924);
    }
    piStack_20 = piStack_18;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_016de14f(piStack_18);
    (**(code **)(*piVar7 + 4))();
    DAT_01eadc48 = piVar7;
  }
LAB_0065026f:
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_016ddacd();
  param_1[1] = (int)piVar7;
  iVar3 = FUN_0054e7d0(piVar6);
  param_1[2] = iVar3;
  uStack_8 = 4;
  pcVar2 = param_2;
  do {
    pcVar4 = pcVar2;
    pcVar2 = pcVar4 + 1;
  } while (*pcVar4 != '\0');
  FUN_00650030(param_1 + 1,param_2,pcVar4,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar3 = FUN_00655050();
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 0x20) = *(int *)(iVar3 + 0x20) + 1;
    UNLOCK();
  }
  if (*param_1 != 0) {
    LOCK();
    piVar7 = (int *)(*param_1 + 0x20);
    iVar1 = *piVar7 + -1;
    *piVar7 = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      FUN_00655300(*param_1,0);
    }
  }
  *param_1 = iVar3;
  if (iStack_78 != 0) {
    uVar5 = iStack_70 - iStack_78 & 0xfffffffc;
    iVar3 = iStack_78;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iStack_78 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iStack_78 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7409 ; VA 0x006503d0 ; FUN_006503d0 */

int * __thiscall FUN_006503d0(int *param_1,uint param_2,undefined *param_3)

{
  int iVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x7fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar1 = FUN_00554060(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    param_1[2] = *param_1 + param_2;
    iVar1 = *param_1;
    FUN_0170d1f0(iVar1,*param_3,param_2);
    param_1[1] = iVar1 + param_2;
  }
  return param_1;
}



/* FUNCTION 7410 ; VA 0x00650440 ; FUN_00650440 */

int * __thiscall FUN_00650440(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined auStack_10 [4];
  int *piStack_c;
  undefined uStack_5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = param_2[1] - *param_2 >> 2;
  if (uVar3 != 0) {
    piStack_c = param_1;
    if (0x3fffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar2 = FUN_00577ed0(uVar3);
    *param_1 = iVar2;
    param_1[1] = iVar2;
    param_1[2] = *param_1 + uVar3 * 4;
    iVar2 = *param_2;
    iVar1 = *param_1;
    FUN_0055b6b0(&uStack_5,auStack_10,auStack_10);
    iVar4 = param_2[1] - iVar2;
    FUN_0170cc70(iVar1,iVar2,iVar4);
    piStack_c[1] = iVar1 + iVar4;
    param_1 = piStack_c;
  }
  return param_1;
}



/* FUNCTION 7411 ; VA 0x006504d0 ; FUN_006504d0 */

int * __thiscall FUN_006504d0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined auStack_10 [4];
  int *piStack_c;
  undefined uStack_5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = param_2[1] - *param_2 >> 3;
  if (uVar3 != 0) {
    piStack_c = param_1;
    if (0x1fffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar2 = FUN_00578020(uVar3);
    *param_1 = iVar2;
    param_1[1] = iVar2;
    param_1[2] = *param_1 + uVar3 * 8;
    iVar2 = *param_2;
    iVar1 = *param_1;
    FUN_0055b6b0(&uStack_5,auStack_10,auStack_10);
    iVar4 = param_2[1] - iVar2;
    FUN_0170cc70(iVar1,iVar2,iVar4);
    piStack_c[1] = iVar1 + iVar4;
    param_1 = piStack_c;
  }
  return param_1;
}



/* FUNCTION 7412 ; VA 0x00650560 ; FUN_00650560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall
FUN_00650560(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined *param_10,undefined4 param_11,int *param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,uint param_16,
            undefined4 param_17)

{
  byte bVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined uVar7;
  uint uVar8;
  uint uVar9;
  undefined8 *puVar10;
  undefined **ppuVar11;
  undefined4 ****ppppuVar12;
  undefined *puStack_64;
  undefined4 ***pppuStack_60;
  undefined4 **ppuStack_5c;
  undefined *puStack_58;
  undefined4 uStack_54;
  undefined4 ***pppuStack_50;
  undefined *puStack_4c;
  undefined4 ***pppuStack_48;
  undefined4 *puStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  undefined4 ***apppuStack_30 [2];
  uint uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined auStack_18 [4];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1862;
  pvStack_10 = ExceptionList;
  pppuStack_48 = (undefined4 ***)param_17;
  puStack_4c = (undefined *)param_16;
  uStack_8 = 0;
  puStack_64 = param_10;
  ExceptionList = &pvStack_10;
  if (param_12 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_12[1] = param_12[1] + 1;
    UNLOCK();
  }
  pppuStack_60 = (undefined4 ***)param_11;
  ppuStack_5c = (undefined4 **)param_12;
  uStack_54 = param_14;
  pppuStack_50 = (undefined4 ***)param_15;
  puStack_24 = param_1;
  FUN_00677b90(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  *param_1 = RBX::Network::CheatHandlingServerReplicator::vftable;
  param_1[0x17] = RBX::Network::CheatHandlingServerReplicator::vftable;
  param_1[0x19] = RBX::Network::CheatHandlingServerReplicator::vftable;
  param_1[0x1a] = RBX::Network::CheatHandlingServerReplicator::vftable;
  *(undefined2 *)(param_1 + 0xf5c) = 0;
  *(undefined *)((int)param_1 + 0x3d72) = 0;
  param_1[0xf61] = 0;
  param_1[0xf62] = 0xf;
  *(undefined *)(param_1 + 0xf5d) = 0;
  param_1[0xf64] = 0;
  param_1[0xf65] = 0;
  param_1[0xf68] = 0;
  param_1[0xf69] = 0;
  param_1[0xf6a] = 0;
  *(undefined *)(param_1 + 0xf6b) = 0;
  param_1[0xf6c] = 0;
  param_1[0xf6d] = 0;
  param_1[0xf6e] = 0;
  param_1[0xf6f] = 0;
  param_1[0xf70] = 0;
  param_1[0xf71] = 0;
  param_1[0xf72] = 0;
  param_1[0xf73] = 0;
  param_1[0xf74] = 0;
  param_1[0xf75] = 0;
  uStack_8._0_1_ = 4;
  param_1[0xf77] = 0;
  param_1[0xf78] = 0;
  *(undefined *)(param_1 + 0xf79) = 0;
  pppuStack_48 = (undefined4 ***)0x6506ee;
  FUN_00715d10();
  *(undefined8 *)(param_1 + 0xf86) = DAT_018ce330;
  param_1[0xf8c] = 0;
  param_1[0xf8d] = 0xf;
  *(undefined *)(param_1 + 0xf88) = 0;
  param_1[0xf92] = 0;
  param_1[0xf93] = 0xf;
  *(undefined *)(param_1 + 0xf8e) = 0;
  uStack_8._0_1_ = 7;
  *(undefined8 *)(param_1 + 0xf94) = 0;
  *(undefined *)(param_1 + 0xf96) = 0;
  pppuStack_48 = (undefined4 ***)0x65074f;
  uVar8 = FUN_01679ce0();
  uStack_14 = 0x80000000;
  param_1[0xf97] = uVar8 % 10000;
  param_16 = 0;
  puStack_1c = &DAT_01d5a848;
  if (0xf < DAT_01d5a85c) {
    puStack_1c = DAT_01d5a848;
  }
  uVar8 = 0;
  do {
    bVar1 = *(byte *)((int)puStack_1c + uVar8);
    param_17 = CONCAT13(bVar1,(undefined3)param_17);
    if (bVar1 == 0) {
LAB_006507d0:
      param_16 = 0;
      break;
    }
    if (uVar8 % 5 == 4) {
      uVar9 = param_16;
      if (0x37 < bVar1) goto LAB_006507d0;
    }
    else {
      uVar9 = uStack_14 | param_16;
      uStack_14 = uStack_14 >> 1;
      if (bVar1 != 0x2e) {
        uVar9 = param_16;
      }
    }
    param_16 = uVar9;
    uVar8 = uVar8 + 1;
  } while (uVar8 < 0x28);
  pppuStack_48 = (undefined4 ***)~param_16;
  puStack_4c = (undefined *)0x0;
  pppuStack_50 = (undefined4 ***)0x0;
  uStack_54 = 0x6507e4;
  FUN_012556c0();
  pppuStack_48 = (undefined4 ***)0x0;
  puStack_4c = (undefined *)0xffffffff;
  pppuStack_50 = (undefined4 ***)0xffffffff;
  uStack_54 = 0x6507f5;
  FUN_012556c0();
  param_1[0xfa2] = 0;
  param_1[0xfa3] = 0;
  param_1[0xfa4] = 0;
  *(undefined8 *)(param_1 + 0xfaa) = 0;
  pppuStack_48 = (undefined4 ***)0x650823;
  uStack_20 = FUN_006a6900();
  pppuStack_48 = (undefined4 ***)&uStack_20;
  puStack_1c = (undefined4 *)0x0;
  puStack_4c = auStack_18;
  pppuStack_50 = (undefined4 ***)0x65083c;
  puVar10 = (undefined8 *)FUN_00626680();
  *(undefined8 *)(param_1 + 0xfb4) = *puVar10;
  param_1[0xfba] = 0;
  param_1[0xfbb] = 0;
  param_1[0xfbc] = 0;
  param_1[0xfbd] = 0;
  param_1[0xfc1] = 0;
  param_1[0xfc7] = 0;
  param_1[0xfc8] = 0xf;
  *(undefined *)(param_1 + 0xfc3) = 0;
  uVar6 = _UNK_018d509c;
  uVar5 = _UNK_018d5098;
  uVar4 = _UNK_018d5094;
  uVar3 = _DAT_018d5090;
  param_1[0xfc9] = 0;
  param_1[0xfca] = 0;
  param_1[0xfcb] = 0;
  param_1[0xfcc] = 0;
  param_1[0xfcd] = 0;
  param_1[0xfce] = 0xffffff;
  *(undefined2 *)(param_1 + 0xfcf) = 0;
  *(undefined *)((int)param_1 + 0x3f3e) = 0;
  param_1[0xfd0] = 0;
  param_1[0xfd1] = 0;
  param_1[0xfd2] = 0;
  param_1[0xfd3] = 0;
  param_1[0xfd4] = 0;
  *(undefined *)(param_1 + 0xfd5) = 0;
  *(undefined4 *)((int)param_1 + 0x3f56) = 0;
  *(undefined4 *)((int)param_1 + 0x3f5a) = 0;
  *(undefined4 *)((int)param_1 + 0x3f5e) = 0;
  *(undefined4 *)((int)param_1 + 0x3f62) = 0;
  *(undefined2 *)((int)param_1 + 0x3f66) = 0;
  *(undefined *)(param_1 + 0xfda) = 0;
  param_1[0xfdb] = 0;
  *(undefined *)(param_1 + 0xfdc) = 0;
  param_1[0xfdd] = 0;
  param_1[0xfde] = 0;
  param_1[0xfdf] = 0;
  *(undefined *)(param_1 + 0xfe0) = 0;
  param_1[0xfb6] = uVar3;
  param_1[0xfb7] = uVar4;
  param_1[0xfb8] = uVar5;
  param_1[0xfb9] = uVar6;
  puStack_3c = (undefined4 *)0x0;
  iStack_38 = 0;
  uStack_34 = 0;
  pppuStack_48 = (undefined4 ***)0x1;
  pppuStack_50 = apppuStack_30;
  uStack_8._0_1_ = 9;
  puStack_4c = &DAT_018bf378;
  apppuStack_30[0] = (undefined4 ****)0x0;
  uStack_28 = 1;
  uStack_54 = 0x6509cd;
  FUN_0170cc70();
  uStack_54 = param_17;
  ppuStack_5c = (undefined4 **)((int)apppuStack_30 + uStack_28);
  pppuStack_60 = apppuStack_30;
  puStack_58 = (undefined *)((int)ppuStack_5c - (int)pppuStack_60);
  puStack_64 = (undefined *)0x6509e7;
  FUN_0063e660();
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  puStack_58 = (undefined *)0x1;
  ppuVar11 = &puStack_64;
  ppuStack_5c = (undefined4 **)uStack_28;
  puStack_64 = (undefined *)0x0;
  if (uStack_28 < 9) {
    ppppuVar12 = apppuStack_30;
  }
  else {
    ppuVar11 = (undefined **)FUN_01674e20(uStack_28);
    ppppuVar12 = (undefined4 ****)apppuStack_30[0];
    puStack_64 = (undefined *)ppuVar11;
  }
  FUN_0170c6f0(ppuVar11,ppppuVar12,ppuStack_5c);
  FUN_0063fec0(&uStack_54);
  ppuStack_5c = &puStack_3c;
  puStack_58 = &DAT_01d5ab88;
  pppuStack_60 = (undefined4 ***)0x650a45;
  FUN_0063f980();
  if ((8 < uStack_28) && ((undefined4 ****)apppuStack_30[0] != (undefined4 ****)0x0)) {
    pppuStack_48 = apppuStack_30[0];
    puStack_4c = (undefined *)0x650a5b;
    FUN_01674ea0();
  }
  if ((iStack_38 - (int)puStack_3c) - 0x90U < 0x18) {
    pppuStack_48 = (undefined4 ***)puStack_3c;
    if (0xf < (uint)puStack_3c[5]) {
      pppuStack_48 = (undefined4 ***)*puStack_3c;
    }
    puStack_4c = (undefined *)0x650a82;
    uVar7 = FUN_01717832();
    *(undefined *)(param_1 + 0xfce) = uVar7;
    pppuStack_48 = (undefined4 ***)(puStack_3c + 6);
    if (0xf < (uint)puStack_3c[0xb]) {
      pppuStack_48 = (undefined4 ***)*pppuStack_48;
    }
    puStack_4c = (undefined *)0x650a9f;
    uVar7 = FUN_01717832();
    *(undefined *)((int)param_1 + 0x3f39) = uVar7;
    pppuStack_48 = (undefined4 ***)(puStack_3c + 0xc);
    if (0xf < (uint)puStack_3c[0x11]) {
      pppuStack_48 = (undefined4 ***)*pppuStack_48;
    }
    puStack_4c = (undefined *)0x650abc;
    uVar7 = FUN_01717832();
    *(undefined *)((int)param_1 + 0x3f3a) = uVar7;
    pppuStack_48 = (undefined4 ***)(puStack_3c + 0x12);
    if (0xf < (uint)puStack_3c[0x17]) {
      pppuStack_48 = (undefined4 ***)*pppuStack_48;
    }
    puStack_4c = (undefined *)0x650ad9;
    uVar7 = FUN_01717832();
    *(undefined *)((int)param_1 + 0x3f3b) = uVar7;
    pppuStack_48 = (undefined4 ***)(puStack_3c + 0x18);
    if (0xf < (uint)puStack_3c[0x1d]) {
      pppuStack_48 = (undefined4 ***)*pppuStack_48;
    }
    puStack_4c = (undefined *)0x650af6;
    uVar7 = FUN_01717832();
    *(undefined *)(param_1 + 0xfcf) = uVar7;
    pppuStack_48 = (undefined4 ***)(puStack_3c + 0x1e);
    if (0xf < (uint)puStack_3c[0x23]) {
      pppuStack_48 = (undefined4 ***)*pppuStack_48;
    }
    puStack_4c = (undefined *)0x650b13;
    uVar7 = FUN_01717832();
    *(undefined *)((int)param_1 + 0x3f3d) = uVar7;
  }
  pppuStack_48 = (undefined4 ***)0x650b24;
  FUN_00577a40();
  if (param_12 != (int *)0x0) {
    LOCK();
    iVar2 = param_12[1] + -1;
    param_12[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      pppuStack_48 = (undefined4 ***)0x650b3b;
      (**(code **)*param_12)();
      LOCK();
      iVar2 = param_12[2] + -1;
      param_12[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppuStack_48 = (undefined4 ***)0x650b4c;
        (**(code **)(*param_12 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7413 ; VA 0x00650b60 ; FUN_00650b60 */

undefined8 * __thiscall FUN_00650b60(undefined8 *param_1,undefined4 ****param_2)

{
  undefined4 ***pppuVar1;
  code *pcVar2;
  char cVar3;
  undefined **ppuVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  undefined8 *puVar8;
  undefined4 ****ppppuVar9;
  undefined8 uVar10;
  undefined *puStack_60;
  undefined4 ***pppuStack_5c;
  undefined4 ***pppuStack_58;
  undefined4 ***pppuStack_54;
  undefined4 ***pppuStack_50;
  undefined4 ***pppuStack_4c;
  undefined4 ***pppuStack_48;
  undefined4 ***pppuStack_44;
  undefined4 ***pppuStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 ***apppuStack_28 [2];
  uint uStack_20;
  undefined8 uStack_1c;
  undefined8 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a18ae;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)((int)param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  *(undefined4 *)(param_1 + 6) = 0;
  *(undefined4 *)((int)param_1 + 0x34) = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  pppuStack_34 = (undefined4 ****)0x0;
  iStack_30 = 0;
  uStack_2c = 0;
  pppuStack_44 = (undefined4 ***)0x1;
  pppuStack_4c = apppuStack_28;
  uStack_8 = 2;
  uStack_7 = 0;
  pppuStack_48 = (undefined4 ***)&DAT_018bf378;
  apppuStack_28[0] = (undefined4 ****)0x0;
  uStack_20 = 1;
  pppuStack_50 = (undefined4 ***)0x650be5;
  puStack_14 = param_1;
  FUN_0170cc70();
  pppuStack_50 = param_2;
  pppuStack_58 = (undefined4 ***)((int)apppuStack_28 + uStack_20);
  pppuStack_5c = apppuStack_28;
  pppuStack_54 = (undefined4 ***)((int)pppuStack_58 - (int)pppuStack_5c);
  puStack_60 = (undefined *)0x650bff;
  FUN_0063e660();
  uStack_8 = 3;
  pppuStack_54 = (undefined4 ***)0x1;
  ppuVar4 = &puStack_60;
  pppuStack_58 = (undefined4 ***)uStack_20;
  puStack_60 = (undefined *)0x0;
  if (uStack_20 < 9) {
    ppppuVar7 = apppuStack_28;
  }
  else {
    ppuVar4 = (undefined **)FUN_01674e20(uStack_20);
    ppppuVar7 = (undefined4 ****)apppuStack_28[0];
    puStack_60 = (undefined *)ppuVar4;
  }
  FUN_0170c6f0(ppuVar4,ppppuVar7,pppuStack_58);
  FUN_0063fec0(&pppuStack_50);
  pppuStack_58 = &pppuStack_34;
  pppuStack_54 = param_2;
  pppuStack_5c = (undefined4 ***)0x650c58;
  FUN_0064f4f0();
  uStack_8 = 2;
  if ((8 < uStack_20) && ((undefined4 ****)apppuStack_28[0] != (undefined4 ****)0x0)) {
    pppuStack_44 = apppuStack_28[0];
    pppuStack_48 = (undefined4 ****)0x650c72;
    FUN_01674ea0();
  }
  puVar8 = puStack_14;
  if ((iStack_30 - (int)pppuStack_34) / 0x18 != 3) goto LAB_00650e70;
  pppuStack_44 = (undefined4 ***)0x1;
  uStack_8 = 4;
  pppuStack_48 = (undefined4 ***)0x650ca0;
  piVar5 = (int *)FUN_016de181();
  pppuVar1 = pppuStack_34;
  uStack_1c = CONCAT44(piVar5,(undefined4)uStack_1c);
  param_2 = &pppuStack_4c;
  pppuStack_4c = (undefined4 ***)CONCAT22(pppuStack_4c._2_2_,0x48);
  uStack_8 = 6;
  pppuStack_50 = (undefined4 ***)0x650cc6;
  pppuStack_44 = (undefined4 ***)piVar5;
  (**(code **)(*piVar5 + 4))();
  pppuStack_50 = pppuVar1;
  uStack_8 = 5;
  pppuStack_54 = (undefined4 ***)0x650cd0;
  FUN_0064fad0();
  _uStack_8 = CONCAT31(uStack_7,7);
  pppuStack_44 = (undefined4 ***)0x650cde;
  puVar6 = (undefined4 *)(**(code **)(*piVar5 + 8))();
  if (puVar6 != (undefined4 *)0x0) {
    pppuStack_44 = (undefined4 ***)0x1;
    pppuStack_48 = (undefined4 ***)0x650cec;
    (**(code **)*puVar6)();
  }
  pppuStack_44 = (undefined4 ***)0x1;
  uStack_8 = 8;
  pppuStack_48 = (undefined4 ***)0x650cf7;
  piVar5 = (int *)FUN_016de181();
  uStack_1c = CONCAT44(piVar5,(undefined4)uStack_1c);
  param_2 = &pppuStack_4c;
  ppppuVar7 = (undefined4 ****)(pppuStack_34 + 6);
  pppuStack_4c = (undefined4 ***)CONCAT22(pppuStack_4c._2_2_,0x48);
  uStack_8 = 10;
  pppuStack_50 = (undefined4 ***)0x650d1b;
  pppuStack_44 = (undefined4 ***)piVar5;
  (**(code **)(*piVar5 + 4))();
  uStack_8 = 9;
  pppuStack_54 = (undefined4 ***)0x650d25;
  pppuStack_50 = ppppuVar7;
  FUN_0064fad0();
  _uStack_8 = CONCAT31(uStack_7,0xb);
  pppuStack_44 = (undefined4 ***)0x650d33;
  puVar6 = (undefined4 *)(**(code **)(*piVar5 + 8))();
  if (puVar6 != (undefined4 *)0x0) {
    pppuStack_44 = (undefined4 ***)0x1;
    pppuStack_48 = (undefined4 ***)0x650d41;
    (**(code **)*puVar6)();
  }
  pppuStack_44 = (undefined4 ***)0x1;
  uStack_8 = 0xc;
  pppuStack_48 = (undefined4 ***)0x650d4c;
  piVar5 = (int *)FUN_016de181();
  uStack_1c = CONCAT44(piVar5,(undefined4)uStack_1c);
  param_2 = &pppuStack_4c;
  ppppuVar7 = (undefined4 ****)(pppuStack_34 + 0xc);
  pppuStack_4c = (undefined4 ***)CONCAT22(pppuStack_4c._2_2_,0x48);
  uStack_8 = 0xe;
  pppuStack_50 = (undefined4 ***)0x650d70;
  pppuStack_44 = (undefined4 ***)piVar5;
  (**(code **)(*piVar5 + 4))();
  uStack_8 = 0xd;
  pppuStack_54 = (undefined4 ***)0x650d7a;
  pppuStack_50 = ppppuVar7;
  FUN_0064fad0();
  _uStack_8 = CONCAT31(uStack_7,0xf);
  pppuStack_44 = (undefined4 ***)0x650d88;
  puVar6 = (undefined4 *)(**(code **)(*piVar5 + 8))();
  if (puVar6 != (undefined4 *)0x0) {
    pppuStack_44 = (undefined4 ***)0x1;
    pppuStack_48 = (undefined4 ***)0x650d96;
    (**(code **)*puVar6)();
  }
  ppppuVar9 = (undefined4 ****)pppuStack_34;
  uStack_8 = 2;
  pppuVar1 = (undefined4 ***)pppuStack_34[5];
  ppppuVar7 = (undefined4 ****)pppuStack_34[4];
  pppuStack_50 = pppuStack_34;
  if ((undefined4 ***)0xf < pppuVar1) {
    pppuStack_50 = (undefined4 ***)*pppuStack_34;
  }
  pppuStack_44 = (undefined4 ***)0x0;
  pppuStack_48 = (undefined4 ***)&DAT_018bc9b8;
  pppuStack_54 = (undefined4 ****)0x650dba;
  pppuStack_4c = ppppuVar7;
  cVar3 = FUN_0055c360();
  if (cVar3 == '\0') {
    pppuStack_50 = ppppuVar9;
    if ((undefined4 ***)0xf < pppuVar1) {
      pppuStack_50 = *ppppuVar9;
    }
    pppuStack_44 = (undefined4 ***)0x1;
    pppuStack_48 = (undefined4 ***)&DAT_018c0df0;
    pppuStack_54 = (undefined4 ****)0x650dd8;
    pppuStack_4c = ppppuVar7;
    cVar3 = FUN_0055c360();
    if (cVar3 != '\0') goto LAB_00650e1a;
    pppuStack_44 = (undefined4 ***)0x650de4;
    piVar5 = (int *)FUN_0171689d();
    if ((undefined4 ***)0xf < ppppuVar9[5]) {
      ppppuVar9 = (undefined4 ****)*ppppuVar9;
    }
    pppuStack_44 = (undefined4 ***)0xa;
    pppuStack_48 = &param_2;
    *piVar5 = 0;
    pppuStack_50 = (undefined4 ****)0x650e00;
    pppuStack_4c = ppppuVar9;
    uVar10 = FUN_0171d7b1();
    if (ppppuVar9 == param_2) {
      pppuStack_44 = (undefined4 ***)0x18d14ec;
      pppuStack_48 = (undefined4 ***)0x650e97;
      FUN_016ddcb9();
LAB_00650e97:
      pppuStack_44 = (undefined4 ***)0x18d1504;
      pppuStack_48 = (undefined4 ***)0x650ea1;
      FUN_016ddcf9();
      pcVar2 = (code *)swi(3);
      puVar8 = (undefined8 *)(*pcVar2)();
      return puVar8;
    }
    ppppuVar9 = (undefined4 ****)pppuStack_34;
    if (*piVar5 == 0x22) goto LAB_00650e97;
  }
  else {
LAB_00650e1a:
    uStack_1c = 0;
    uVar10 = 0;
  }
  puVar8 = puStack_14;
  ppppuVar7 = ppppuVar9 + 6;
  *puStack_14 = uVar10;
  if ((undefined4 ****)(puStack_14 + 1) != ppppuVar7) {
    pppuStack_44 = ppppuVar9[10];
    if ((undefined4 ***)0xf < ppppuVar9[0xb]) {
      ppppuVar7 = (undefined4 ****)*ppppuVar7;
    }
    pppuStack_4c = (undefined4 ****)0x650e4c;
    pppuStack_48 = ppppuVar7;
    FUN_005542c0();
    ppppuVar9 = (undefined4 ****)pppuStack_34;
  }
  ppppuVar7 = ppppuVar9 + 0xc;
  if ((undefined4 ****)(puVar8 + 4) != ppppuVar7) {
    pppuStack_44 = ppppuVar9[0x10];
    if ((undefined4 ***)0xf < ppppuVar9[0x11]) {
      ppppuVar7 = (undefined4 ****)*ppppuVar7;
    }
    pppuStack_4c = (undefined4 ****)0x650e6b;
    pppuStack_48 = ppppuVar7;
    FUN_005542c0();
  }
LAB_00650e70:
  pppuStack_44 = (undefined4 ***)0x650e78;
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return puVar8;
}



/* FUNCTION 7414 ; VA 0x00650eb0 ; FUN_00650eb0 */

int __thiscall FUN_00650eb0(int param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a18d3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_2 + 0x18);
  *(undefined4 *)(param_1 + 0x1c) = *(undefined4 *)(param_2 + 0x1c);
  *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_2 + 0x20);
  *(undefined4 *)(param_1 + 0x24) = *(undefined4 *)(param_2 + 0x24);
  *(undefined4 *)(param_1 + 0x28) = *(undefined4 *)(param_2 + 0x28);
  *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(param_2 + 0x2c);
  *(undefined *)(param_1 + 0x30) = *(undefined *)(param_2 + 0x30);
  *(undefined *)(param_1 + 0x31) = *(undefined *)(param_2 + 0x31);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x38);
  *(undefined4 *)(param_1 + 0x50) = *(undefined4 *)(param_2 + 0x50);
  *(undefined4 *)(param_1 + 0x54) = *(undefined4 *)(param_2 + 0x54);
  *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_2 + 0x58);
  *(undefined4 *)(param_1 + 0x5c) = *(undefined4 *)(param_2 + 0x5c);
  *(undefined4 *)(param_1 + 0x60) = *(undefined4 *)(param_2 + 0x60);
  *(undefined4 *)(param_1 + 100) = *(undefined4 *)(param_2 + 100);
  *(undefined *)(param_1 + 0x68) = *(undefined *)(param_2 + 0x68);
  *(undefined *)(param_1 + 0x69) = *(undefined *)(param_2 + 0x69);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2 + 0x70);
  *(undefined4 *)(param_1 + 0x88) = *(undefined4 *)(param_2 + 0x88);
  *(undefined4 *)(param_1 + 0x8c) = *(undefined4 *)(param_2 + 0x8c);
  *(undefined4 *)(param_1 + 0x90) = *(undefined4 *)(param_2 + 0x90);
  *(undefined4 *)(param_1 + 0x94) = *(undefined4 *)(param_2 + 0x94);
  *(undefined4 *)(param_1 + 0x98) = *(undefined4 *)(param_2 + 0x98);
  *(undefined4 *)(param_1 + 0x9c) = *(undefined4 *)(param_2 + 0x9c);
  *(undefined *)(param_1 + 0xa0) = *(undefined *)(param_2 + 0xa0);
  *(undefined *)(param_1 + 0xa1) = *(undefined *)(param_2 + 0xa1);
  *(undefined *)(param_1 + 0xa8) = *(undefined *)(param_2 + 0xa8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7415 ; VA 0x00650fe0 ; FUN_00650fe0 */

undefined4 * __thiscall FUN_00650fe0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  *param_1 = DynamicFlagValueList<class_Ipv4CIDR>::vftable;
  FUN_016dee4c(param_1 + 2,2);
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = param_2;
  param_1[0x16] = 0;
  param_1[0x17] = 0xf;
  if (param_3 < 0x3c) {
    param_3 = 0x3c;
  }
  *(undefined *)(param_1 + 0x12) = 0;
  param_1[0x18] = param_3;
  *(undefined8 *)(param_1 + 0x1a) = 0;
  param_1[0x1c] = &DAT_018d1b9c;
  *param_1 = Ipv4CIDRFlagsList::vftable;
  return param_1;
}



/* FUNCTION 7416 ; VA 0x00651060 ; FUN_00651060 */

int * __thiscall FUN_00651060(int *param_1,undefined4 *param_2)

{
  char cVar1;
  int *piVar2;
  char *pcVar3;
  uint uVar4;
  char *pcVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017a18f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  iVar7 = 0;
  iStack_8 = 0;
  pcVar5 = (char *)*param_2;
  puVar8 = param_2;
  piStack_14 = param_1;
  if (*pcVar5 != '\0') {
    do {
      uStack_24 = 0;
      puVar8 = puVar8 + 1;
      uStack_20 = 0xf;
      auStack_34[0] = auStack_34[0] & 0xffffff00;
      pcVar3 = pcVar5;
      do {
        cVar1 = *pcVar3;
        pcVar3 = pcVar3 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(pcVar5,(int)pcVar3 - (int)(pcVar5 + 1));
      iStack_8._0_1_ = 1;
      FUN_006615e0(&iStack_1c,auStack_34);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_20) {
        uVar6 = uStack_20 + 1;
        uVar4 = auStack_34[0];
        if (0xfff < uVar6) {
          uVar4 = *(uint *)(auStack_34[0] - 4);
          uVar6 = uStack_20 + 0x24;
          if (0x1f < (auStack_34[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar6);
      }
      if ((iStack_1c != iStack_18) || (iStack_1c != 0)) {
        piVar2 = (int *)param_1[1];
        if ((int *)param_1[2] == piVar2) {
          FUN_0064c050(piVar2,&iStack_1c);
        }
        else {
          *piVar2 = iStack_1c;
          piVar2[1] = iStack_18;
          param_1[1] = param_1[1] + 8;
        }
      }
      pcVar5 = (char *)*puVar8;
    } while (*pcVar5 != '\0');
    iVar7 = param_1[1];
  }
  FUN_0064dc70(*param_1,iVar7,iVar7 - *param_1 >> 3,param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 7417 ; VA 0x006511a0 ; FUN_006511a0 */

void __fastcall FUN_006511a0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 8);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0065120d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 7418 ; VA 0x00651220 ; FUN_00651220 */

void __fastcall FUN_00651220(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0xb4);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00651d50();
  return;
}



/* FUNCTION 7419 ; VA 0x00651250 ; FUN_00651250 */

void __fastcall FUN_00651250(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = DynamicFlagValueList<struct_ClientIdentity>::vftable;
  uVar1 = param_1[0x17];
  if (0xf < uVar1) {
    iVar2 = param_1[0x12];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x16] = 0;
  param_1[0x17] = 0xf;
  *(undefined *)(param_1 + 0x12) = 0;
  FUN_00651830();
  FUN_016dedfb(param_1 + 2);
  return;
}



/* FUNCTION 7420 ; VA 0x006512c0 ; FUN_006512c0 */

void __fastcall FUN_006512c0(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = DynamicFlagValueList<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::vftable;
  uVar1 = param_1[0x17];
  if (0xf < uVar1) {
    iVar2 = param_1[0x12];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x16] = 0;
  param_1[0x17] = 0xf;
  *(undefined *)(param_1 + 0x12) = 0;
  FUN_00577a40();
  FUN_016dedfb(param_1 + 2);
  return;
}



/* FUNCTION 7421 ; VA 0x00651330 ; FUN_00651330 */

void __fastcall FUN_00651330(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  *param_1 = DynamicFlagValueList<class_Ipv4CIDR>::vftable;
  uVar4 = param_1[0x17];
  if (0xf < uVar4) {
    iVar1 = param_1[0x12];
    uVar3 = uVar4 + 1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar4 + 0x24;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006513d1;
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[0x16] = 0;
  param_1[0x17] = 0xf;
  *(undefined *)(param_1 + 0x12) = 0;
  iVar1 = param_1[0xe];
  if (iVar1 != 0) {
    uVar4 = param_1[0x10] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_006513d1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
    param_1[0xe] = 0;
    param_1[0xf] = 0;
    param_1[0x10] = 0;
  }
  FUN_016dedfb(param_1 + 2);
  return;
}



/* FUNCTION 7422 ; VA 0x006513e0 ; FUN_006513e0 */

void __fastcall FUN_006513e0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xc) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 4) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  return;
}



/* FUNCTION 7423 ; VA 0x00651440 ; FUN_00651440 */

void __fastcall FUN_00651440(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x48) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x40) = 0;
    *(undefined4 *)(param_1 + 0x44) = 0;
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  FUN_00651510();
  FUN_00651510();
  return;
}



/* FUNCTION 7424 ; VA 0x006514b0 ; FUN_006514b0 */

void __fastcall FUN_006514b0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x14);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x1c) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
  }
  return;
}



/* FUNCTION 7425 ; VA 0x00651510 ; FUN_00651510 */

void __fastcall FUN_00651510(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x14);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x1c) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006515a5;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
  }
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xc) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_006515a5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 4) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  return;
}



/* FUNCTION 7426 ; VA 0x006515b0 ; thunk_FUN_00651640 */

void __fastcall thunk_FUN_00651640(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  puVar1 = (undefined4 *)param_1[3];
  do {
    if (puVar1 == (undefined4 *)0x0) {
      iVar4 = param_1[1];
      if (iVar4 != 0) {
        if (*(char *)((int)param_1 + 9) != '\0') {
          FUN_00560a10(*param_1,iVar4 + 8);
          iVar4 = param_1[1];
        }
        FUN_01674ea0(iVar4,0x38);
      }
      return;
    }
    param_1[3] = *puVar1;
    uVar2 = puVar1[0xd];
    if (0xf < uVar2) {
      iVar4 = puVar1[8];
      uVar5 = uVar2 + 1;
      iVar3 = iVar4;
      if (0xfff < uVar5) {
        iVar3 = *(int *)(iVar4 + -4);
        uVar5 = uVar2 + 0x24;
        if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_0065171f;
      }
      FUN_01674ea0(iVar3,uVar5);
    }
    puVar1[0xc] = 0;
    puVar1[0xd] = 0xf;
    *(undefined *)(puVar1 + 8) = 0;
    uVar2 = puVar1[7];
    if (0xf < uVar2) {
      iVar4 = puVar1[2];
      uVar5 = uVar2 + 1;
      iVar3 = iVar4;
      if (0xfff < uVar5) {
        iVar3 = *(int *)(iVar4 + -4);
        uVar5 = uVar2 + 0x24;
        if (0x1f < (iVar4 - iVar3) - 4U) {
LAB_0065171f:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar5);
    }
    puVar1[6] = 0;
    puVar1[7] = 0xf;
    *(undefined *)(puVar1 + 2) = 0;
    FUN_01674ea0(puVar1,0x38);
    puVar1 = (undefined4 *)param_1[3];
  } while( true );
}



/* FUNCTION 7427 ; VA 0x006515c0 ; FUN_006515c0 */

void __fastcall FUN_006515c0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_01674ea0(piVar3,0x14);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x14);
  return;
}



/* FUNCTION 7428 ; VA 0x00651610 ; FUN_00651610 */

void __fastcall FUN_00651610(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_005cf430(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x20);
  }
  return;
}



/* FUNCTION 7429 ; VA 0x00651640 ; FUN_00651640 */

void __fastcall FUN_00651640(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  puVar1 = (undefined4 *)param_1[3];
  do {
    if (puVar1 == (undefined4 *)0x0) {
      iVar4 = param_1[1];
      if (iVar4 != 0) {
        if (*(char *)((int)param_1 + 9) != '\0') {
          FUN_00560a10(*param_1,iVar4 + 8);
          iVar4 = param_1[1];
        }
        FUN_01674ea0(iVar4,0x38);
      }
      return;
    }
    param_1[3] = *puVar1;
    uVar2 = puVar1[0xd];
    if (0xf < uVar2) {
      iVar4 = puVar1[8];
      uVar5 = uVar2 + 1;
      iVar3 = iVar4;
      if (0xfff < uVar5) {
        iVar3 = *(int *)(iVar4 + -4);
        uVar5 = uVar2 + 0x24;
        if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_0065171f;
      }
      FUN_01674ea0(iVar3,uVar5);
    }
    puVar1[0xc] = 0;
    puVar1[0xd] = 0xf;
    *(undefined *)(puVar1 + 8) = 0;
    uVar2 = puVar1[7];
    if (0xf < uVar2) {
      iVar4 = puVar1[2];
      uVar5 = uVar2 + 1;
      iVar3 = iVar4;
      if (0xfff < uVar5) {
        iVar3 = *(int *)(iVar4 + -4);
        uVar5 = uVar2 + 0x24;
        if (0x1f < (iVar4 - iVar3) - 4U) {
LAB_0065171f:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar5);
    }
    puVar1[6] = 0;
    puVar1[7] = 0xf;
    *(undefined *)(puVar1 + 2) = 0;
    FUN_01674ea0(puVar1,0x38);
    puVar1 = (undefined4 *)param_1[3];
  } while( true );
}



/* FUNCTION 7430 ; VA 0x00651730 ; FUN_00651730 */

void __fastcall FUN_00651730(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int **)(param_1 + 0xc) != (int *)0x0) {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0xc) + 8))();
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7431 ; VA 0x00651780 ; FUN_00651780 */

void __fastcall FUN_00651780(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[4];
  if (iVar1 != 0) {
    do {
      iVar1 = iVar1 + -1;
      param_1[4] = iVar1;
    } while (iVar1 != 0);
    param_1[3] = 0;
  }
  iVar1 = param_1[2];
  while (iVar1 != 0) {
    iVar1 = iVar1 + -1;
    iVar2 = *(int *)(param_1[1] + iVar1 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0xc);
    }
  }
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 7432 ; VA 0x00651830 ; FUN_00651830 */

void __fastcall FUN_00651830(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00651cc0();
        iVar2 = iVar2 + 0x38;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x38) * 0x38;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 7433 ; VA 0x006518c0 ; FUN_006518c0 */

void __fastcall FUN_006518c0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  
  piVar2 = *(int **)(param_1 + 0x68);
  piVar5 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*(int *)(param_1 + 0x68) + 4) = *(int *)(param_1 + 0x68);
  *(undefined4 *)(param_1 + 0x6c) = 0;
  piVar2 = *(int **)(param_1 + 0x68);
  if (piVar5 != piVar2) {
    do {
      piVar1 = (int *)*piVar5;
      FUN_01674ea0(piVar5,0x14);
      piVar2 = *(int **)(param_1 + 0x68);
      piVar5 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x14);
  piVar2 = *(int **)(param_1 + 100);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = *(int *)(param_1 + 0x54);
  if (iVar3 != 0) {
    uVar6 = *(int *)(param_1 + 0x5c) - iVar3 & 0xfffffff8;
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00651aba;
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x54) = 0;
    *(undefined4 *)(param_1 + 0x58) = 0;
    *(undefined4 *)(param_1 + 0x5c) = 0;
  }
  iVar3 = *(int *)(param_1 + 0x4c);
  if (iVar3 != 0) {
    do {
      iVar3 = iVar3 + -1;
      *(int *)(param_1 + 0x4c) = iVar3;
    } while (iVar3 != 0);
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  iVar3 = *(int *)(param_1 + 0x44);
  while (iVar3 != 0) {
    iVar3 = iVar3 + -1;
    iVar4 = *(int *)(*(int *)(param_1 + 0x40) + iVar3 * 4);
    if (iVar4 != 0) {
      FUN_01674ea0(iVar4,0xc);
    }
  }
  iVar3 = *(int *)(param_1 + 0x40);
  if (iVar3 != 0) {
    uVar6 = *(int *)(param_1 + 0x44) * 4;
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00651aba;
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x3c),8);
  *(undefined4 *)(param_1 + 0x3c) = 0;
  iVar3 = *(int *)(param_1 + 0x30);
  if (iVar3 != 0) {
    uVar6 = *(int *)(param_1 + 0x38) - iVar3 & 0xfffffff8;
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00651aba;
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x30) = 0;
    *(undefined4 *)(param_1 + 0x34) = 0;
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  uVar6 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar6) {
    iVar3 = *(int *)(param_1 + 0x10);
    uVar7 = uVar6 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar7) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar7 = uVar6 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00651aba:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar5 = piVar2 + 2;
    iVar3 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00651ab3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 7434 ; VA 0x00651ac0 ; FUN_00651ac0 */

void __fastcall FUN_00651ac0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  uVar6 = *(uint *)(param_1 + 0x3f20);
  if (0xf < uVar6) {
    iVar2 = *(int *)(param_1 + 0x3f0c);
    uVar5 = uVar6 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00651cb0;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x3f1c) = 0;
  *(undefined4 *)(param_1 + 0x3f20) = 0xf;
  *(undefined *)(param_1 + 0x3f0c) = 0;
  uVar6 = *(uint *)(param_1 + 0x3e4c);
  if (0xf < uVar6) {
    iVar2 = *(int *)(param_1 + 0x3e38);
    uVar5 = uVar6 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00651cb0;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x3e48) = 0;
  *(undefined4 *)(param_1 + 0x3e4c) = 0xf;
  *(undefined *)(param_1 + 0x3e38) = 0;
  uVar6 = *(uint *)(param_1 + 0x3e34);
  if (0xf < uVar6) {
    iVar2 = *(int *)(param_1 + 0x3e20);
    uVar5 = uVar6 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00651cb0;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x3e30) = 0;
  *(undefined4 *)(param_1 + 0x3e34) = 0xf;
  *(undefined *)(param_1 + 0x3e20) = 0;
  FUN_00651e30();
  piVar3 = *(int **)(param_1 + 0x3dd4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar2 = *(int *)(param_1 + 0x3da0);
  if (iVar2 != 0) {
    uVar6 = *(int *)(param_1 + 0x3da8) - iVar2 & 0xfffffffc;
    iVar4 = iVar2;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00651cb0;
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x3da0) = 0;
    *(undefined4 *)(param_1 + 0x3da4) = 0;
    *(undefined4 *)(param_1 + 0x3da8) = 0;
  }
  uVar6 = *(uint *)(param_1 + 0x3d88);
  if (0xf < uVar6) {
    iVar2 = *(int *)(param_1 + 0x3d74);
    uVar5 = uVar6 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
LAB_00651cb0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x3d84) = 0;
  *(undefined4 *)(param_1 + 0x3d88) = 0xf;
  *(undefined *)(param_1 + 0x3d74) = 0;
  FUN_00678760();
  return;
}



/* FUNCTION 7435 ; VA 0x00651cc0 ; FUN_00651cc0 */

void __fastcall FUN_00651cc0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x34);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x20);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00651d49;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0xf;
  *(undefined *)(param_1 + 0x20) = 0;
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00651d49:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 7436 ; VA 0x00651d50 ; FUN_00651d50 */

void __fastcall FUN_00651d50(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0x21];
  if (0xf < uVar1) {
    iVar2 = param_1[0x1c];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00651e26;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x20] = 0;
  param_1[0x21] = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  uVar1 = param_1[0x13];
  if (0xf < uVar1) {
    iVar2 = param_1[0xe];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00651e26;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x12] = 0;
  param_1[0x13] = 0xf;
  *(undefined *)(param_1 + 0xe) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00651e26:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 7437 ; VA 0x00651e30 ; FUN_00651e30 */

void __fastcall FUN_00651e30(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  LOCK();
  iVar1 = param_1[8];
  param_1[8] = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  iVar1 = param_1[4];
  if (iVar1 != 0) {
    uVar3 = param_1[6] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00651ecf;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[4] = 0;
    param_1[5] = 0;
    param_1[6] = 0;
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00651ecf:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 7438 ; VA 0x00651ee0 ; FUN_00651ee0 */

void __fastcall FUN_00651ee0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int **)(param_1 + 8) != (int *)0x0) {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)(**(code **)(**(int **)(param_1 + 8) + 8))();
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7439 ; VA 0x00651f30 ; FUN_00651f30 */

undefined4 * __thiscall FUN_00651f30(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  uint uVar10;
  int iVar11;
  
  puVar2 = param_2;
  *param_1 = *param_2;
  FUN_006521b0(param_2 + 1);
  piVar9 = puVar2 + 5;
  piVar8 = param_1 + 5;
  if (piVar8 != piVar9) {
    iVar6 = puVar2[6];
    iVar1 = *piVar9;
    param_2 = (undefined4 *)*piVar8;
    iVar11 = iVar6 - iVar1;
    uVar10 = iVar11 >> 3;
    uVar7 = param_1[7] - (int)param_2 >> 3;
    uVar3 = param_1[6] - (int)param_2 >> 3;
    if (uVar7 < uVar10) {
      if (0x1fffffff < uVar10) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      uVar4 = uVar7 >> 1;
      uVar3 = uVar10;
      if ((uVar7 <= 0x1fffffff - uVar4) && (uVar3 = uVar4 + uVar7, uVar4 + uVar7 < uVar10)) {
        uVar3 = uVar10;
      }
      if (param_2 != (undefined4 *)0x0) {
        iVar6 = (int)param_2;
        param_2 = (undefined4 *)uVar4;
        FUN_0057d330(iVar6,uVar7);
        uVar4 = (uint)param_2;
      }
      param_2 = (undefined4 *)uVar4;
      FUN_00616bd0(uVar3);
      iVar6 = *piVar8;
      FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
      FUN_0170cc70(iVar6,iVar1,iVar11);
      param_1[6] = iVar6 + iVar11;
      return param_1;
    }
    if (uVar3 < uVar10) {
      iVar5 = uVar3 * 8;
      iVar11 = iVar5 + iVar1;
      FUN_0170cc70(param_2,iVar1,iVar5);
      iVar1 = param_1[6];
      FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
      iVar6 = iVar6 - iVar11;
      FUN_0170cc70(iVar1,iVar11,iVar6);
      param_1[6] = iVar6 + iVar1;
      return param_1;
    }
    FUN_0170cc70(param_2,iVar1,iVar11);
    param_1[6] = (int)param_2 + uVar10 * 8;
  }
  return param_1;
}



/* FUNCTION 7440 ; VA 0x00652080 ; FUN_00652080 */

int * __thiscall FUN_00652080(int *param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  
  if (param_1 != param_2) {
    iVar5 = param_2[1];
    iVar1 = *param_2;
    param_2 = (int *)*param_1;
    iVar8 = iVar5 - iVar1;
    uVar7 = iVar8 >> 2;
    uVar6 = param_1[2] - (int)param_2 >> 2;
    uVar2 = param_1[1] - (int)param_2 >> 2;
    if (uVar6 < uVar7) {
      if (0x3fffffff < uVar7) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      uVar3 = uVar6 >> 1;
      uVar2 = uVar7;
      if ((uVar6 <= 0x3fffffff - uVar3) && (uVar2 = uVar3 + uVar6, uVar3 + uVar6 < uVar7)) {
        uVar2 = uVar7;
      }
      if (param_2 != (int *)0x0) {
        iVar5 = (int)param_2;
        param_2 = (int *)uVar3;
        FUN_0057d270(iVar5,uVar6);
        uVar3 = (uint)param_2;
      }
      param_2 = (int *)uVar3;
      FUN_005d2220(uVar2);
      iVar5 = *param_1;
      FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
      FUN_0170cc70(iVar5,iVar1,iVar8);
      param_1[1] = iVar5 + iVar8;
      return param_1;
    }
    if (uVar2 < uVar7) {
      iVar4 = uVar2 * 4;
      iVar8 = iVar4 + iVar1;
      FUN_0170cc70(param_2,iVar1,iVar4);
      iVar1 = param_1[1];
      FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
      iVar5 = iVar5 - iVar8;
      FUN_0170cc70(iVar1,iVar8,iVar5);
      param_1[1] = iVar5 + iVar1;
      return param_1;
    }
    FUN_0170cc70(param_2,iVar1,iVar8);
    param_1[1] = (int)param_2 + uVar7 * 4;
  }
  return param_1;
}



/* FUNCTION 7441 ; VA 0x006521b0 ; FUN_006521b0 */

int * __thiscall FUN_006521b0(int *param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iStack_14;
  int iStack_10;
  uint uStack_c;
  undefined uStack_5;
  
  if (param_1 != param_2) {
    uStack_c = param_2[1];
    iStack_10 = *param_2;
    iStack_14 = *param_1;
    iVar5 = uStack_c - iStack_10;
    uVar4 = iVar5 >> 2;
    uVar3 = param_1[2] - iStack_14 >> 2;
    uVar1 = param_1[1] - iStack_14 >> 2;
    if (uVar3 < uVar4) {
      if (0x3fffffff < uVar4) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      uStack_c = uVar3 >> 1;
      uVar1 = uVar4;
      if ((uVar3 <= 0x3fffffff - uStack_c) && (uVar1 = uStack_c + uVar3, uStack_c + uVar3 < uVar4))
      {
        uVar1 = uVar4;
      }
      if (iStack_14 != 0) {
        FUN_0057d270(iStack_14,uVar3);
      }
      FUN_005d2220(uVar1);
      iVar2 = *param_1;
      FUN_0055b6b0(&uStack_5,&iStack_14,&iStack_14);
      FUN_0170cc70(iVar2,iStack_10,iVar5);
      iVar2 = iVar2 + iVar5;
    }
    else if (uVar1 < uVar4) {
      iVar2 = uVar1 * 4;
      iVar5 = iVar2 + iStack_10;
      FUN_0170cc70(iStack_14,iStack_10,iVar2);
      iVar2 = param_1[1];
      FUN_0055b6b0(&uStack_5,&iStack_14,&iStack_14);
      uStack_c = uStack_c - iVar5;
      FUN_0170cc70(iVar2,iVar5,uStack_c);
      iVar2 = uStack_c + iVar2;
    }
    else {
      FUN_0170cc70(iStack_14,iStack_10,iVar5);
      iVar2 = iStack_14 + uVar4 * 4;
    }
    param_1[1] = iVar2;
    param_1[3] = param_2[3];
  }
  return param_1;
}



/* FUNCTION 7442 ; VA 0x006522d0 ; FUN_006522d0 */

undefined4 FUN_006522d0(byte *param_1,uint param_2,byte *param_3,uint param_4)

{
  uint uVar1;
  bool bVar2;
  
  if (param_2 != param_4) {
    return 0;
  }
  if (param_4 == 0) {
    return 1;
  }
  uVar1 = param_4 - 4;
  if (3 < param_4) {
    do {
      if (*(int *)param_1 != *(int *)param_3) goto LAB_00652306;
      param_1 = param_1 + 4;
      param_3 = param_3 + 4;
      bVar2 = 3 < uVar1;
      uVar1 = uVar1 - 4;
    } while (bVar2);
  }
  if (uVar1 != 0xfffffffc) {
LAB_00652306:
    bVar2 = *param_1 < *param_3;
    if ((*param_1 != *param_3) ||
       ((uVar1 != 0xfffffffd &&
        ((bVar2 = param_1[1] < param_3[1], param_1[1] != param_3[1] ||
         ((uVar1 != 0xfffffffe &&
          ((bVar2 = param_1[2] < param_3[2], param_1[2] != param_3[2] ||
           ((uVar1 != 0xffffffff && (bVar2 = param_1[3] < param_3[3], param_1[3] != param_3[3]))))))
         )))))) {
      uVar1 = -(uint)bVar2 | 1;
      goto LAB_0065233c;
    }
  }
  uVar1 = 0;
LAB_0065233c:
  if (uVar1 != 0) {
    return 0;
  }
  return 1;
}



/* FUNCTION 7443 ; VA 0x00652350 ; FUN_00652350 */

void __thiscall FUN_00652350(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  
  uVar1 = param_1[1];
  if ((param_3 < 0) && (uVar1 < (uint)-param_3)) {
    *param_2 = *param_1 + (~(uVar1 + param_3) >> 5) * -4 + -4;
    param_2[1] = uVar1 + param_3 & 0x1f;
    return;
  }
  *param_2 = *param_1 + (uVar1 + param_3 >> 5) * 4;
  param_2[1] = uVar1 + param_3 & 0x1f;
  return;
}



/* FUNCTION 7444 ; VA 0x006523b0 ; FUN_006523b0 */

void * __thiscall FUN_006523b0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  void *pvVar3;
  int iVar4;
  undefined auStack_f8 [16];
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined8 uStack_e0;
  undefined8 uStack_d8;
  undefined8 uStack_d0;
  undefined2 uStack_c8;
  undefined uStack_c0;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined8 uStack_98;
  undefined2 uStack_90;
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined2 uStack_58;
  undefined uStack_50;
  undefined uStack_48;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined uStack_28;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1936;
  pvStack_10 = ExceptionList;
  if ((param_2 == 0) && (*(int *)(param_3 + 0xc) == 200)) {
    ExceptionList = &pvStack_10;
    pvVar3 = (void *)FUN_00587490();
    uStack_8._0_1_ = 3;
    uStack_8._1_3_ = 0;
    if (iStack_30 != 0) {
      uStack_e8 = 0;
      uStack_e4 = 0xf;
      auStack_f8[0] = 0;
      uStack_e0 = 0;
      uStack_d8 = 0;
      uStack_d0 = 0;
      uStack_c8 = 0;
      uStack_b0 = 0;
      uStack_ac = 0xf;
      uStack_c0 = 0;
      uStack_a8 = 0;
      uStack_a0 = 0;
      uStack_98 = 0;
      uStack_90 = 0;
      uStack_78 = 0;
      uStack_74 = 0xf;
      uStack_88 = 0;
      uStack_70 = 0;
      uStack_68 = 0;
      uStack_60 = 0;
      uStack_58 = 0;
      uStack_50 = 0;
      uStack_8._0_1_ = 4;
      uStack_8._1_3_ = 0;
      if (DAT_01d5acf0 != '\0') {
        FUN_005f77e0();
      }
      Ordinal_14();
      cVar2 = FUN_00661920();
      if (cVar2 == '\0') {
        if (DAT_01d5aca0 != '\0') {
          uStack_38 = 0;
          uStack_34 = 0xf;
          uStack_48 = 0;
          FUN_005542c0();
          uStack_8._0_1_ = 5;
          FUN_008783f0();
          FUN_005507b0();
        }
      }
      else {
        iVar4 = FUN_008f7870();
        if (iVar4 != 0) {
          FUN_00650eb0(auStack_f8);
          if (*(int *)(param_1 + 4) != 0) {
            LOCK();
            piVar1 = (int *)(*(int *)(param_1 + 4) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          FUN_0064baa0();
          FUN_0090ca30();
        }
      }
      pvVar3 = (void *)FUN_00651d50();
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_2c + 1;
      iVar4 = *piVar1;
      pvVar3 = (void *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        pvVar3 = (void *)(**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piStack_2c + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          pvVar3 = (void *)(**(code **)(*piStack_2c + 4))();
          ExceptionList = pvStack_10;
          return pvVar3;
        }
      }
    }
  }
  else {
    pvVar3 = ExceptionList;
    ExceptionList = &pvStack_10;
    if (DAT_01ead7a0 != '\0') {
      ExceptionList = &pvStack_10;
      pvVar3 = (void *)FUN_01677520();
    }
    if (DAT_01d5aca0 != '\0') {
      uStack_18 = 0;
      uStack_14 = 0xf;
      uStack_28 = 0;
      FUN_005542c0();
      uStack_8 = 0;
      FUN_008783f0();
      uStack_8 = 0xffffffff;
      pvVar3 = (void *)FUN_005507b0();
    }
    if (DAT_01d5aca8 != '\0') {
      FUN_0151f6f0();
      uStack_8 = 1;
      FUN_0151f850();
      FUN_0151f9c0();
      FUN_0151f9c0();
      if (*(int *)(param_3 + 0x84) != 0) {
        FUN_0151f950();
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      uStack_28 = 0;
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_01520d20();
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      pvVar3 = (void *)FUN_0151f7f0();
    }
    if (DAT_01d5acd0 != '\0') {
      pvVar3 = (void *)FUN_00659e70();
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 7445 ; VA 0x00652780 ; FUN_00652780 */

/* WARNING: Removing unreachable block (ram,0x006527d2) */
/* WARNING: Removing unreachable block (ram,0x006527e2) */
/* WARNING: Removing unreachable block (ram,0x006527e8) */

void * __thiscall FUN_00652780(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1958;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 7446 ; VA 0x00652856 ; Catch@00652856 */

undefined * Catch_00652856(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00652867;
}



/* FUNCTION 7447 ; VA 0x00652880 ; FUN_00652880 */

int * __thiscall FUN_00652880(int *param_1,int param_2)

{
  uint uVar1;
  
  if ((param_2 < 0) && ((uint)param_1[1] < (uint)-param_2)) {
    uVar1 = param_1[1] + param_2;
    param_1[1] = uVar1;
    *param_1 = *param_1 + (~uVar1 >> 5) * -4 + -4;
    param_1[1] = uVar1 & 0x1f;
    return param_1;
  }
  uVar1 = param_1[1] + param_2;
  param_1[1] = uVar1;
  *param_1 = *param_1 + (uVar1 >> 5) * 4;
  param_1[1] = uVar1 & 0x1f;
  return param_1;
}



/* FUNCTION 7448 ; VA 0x006528dc ; FUN_006528dc */

void FUN_006528dc(void)

{
  FUN_00652af0();
  return;
}



/* FUNCTION 7449 ; VA 0x006528e4 ; FUN_006528e4 */

void FUN_006528e4(void)

{
  FUN_00652af0();
  return;
}



/* FUNCTION 7450 ; VA 0x006528ec ; FUN_006528ec */

void FUN_006528ec(void)

{
  FUN_00652af0();
  return;
}



/* FUNCTION 7451 ; VA 0x00652900 ; FUN_00652900 */

undefined4 __thiscall FUN_00652900(undefined4 param_1,byte param_2)

{
  FUN_00651250();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x78);
  }
  return param_1;
}



/* FUNCTION 7452 ; VA 0x00652930 ; FUN_00652930 */

undefined4 __thiscall FUN_00652930(undefined4 param_1,byte param_2)

{
  FUN_006512c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x78);
  }
  return param_1;
}



/* FUNCTION 7453 ; VA 0x00652960 ; FUN_00652960 */

undefined4 __thiscall FUN_00652960(undefined4 param_1,byte param_2)

{
  FUN_00651330();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x78);
  }
  return param_1;
}



/* FUNCTION 7454 ; VA 0x00652990 ; FUN_00652990 */

undefined4 * __thiscall FUN_00652990(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  
  *param_1 = std::_Node_class<char,class_std::regex_traits<char>_>::vftable;
  iVar2 = param_1[5];
  while (iVar2 != 0) {
    iVar1 = *(int *)(iVar2 + 0x10);
    FUN_017168b0(*(undefined4 *)(iVar2 + 0xc));
    FUN_01674ea0(iVar2,0x14);
    iVar2 = iVar1;
  }
  FUN_01674ea0(param_1[6],0x20);
  iVar2 = param_1[7];
  if (iVar2 != 0) {
    FUN_017168b0(*(undefined4 *)(iVar2 + 8));
    FUN_01674ea0(iVar2,0xc);
  }
  iVar2 = param_1[8];
  if (iVar2 != 0) {
    FUN_017168b0(*(undefined4 *)(iVar2 + 8));
    FUN_01674ea0(iVar2,0xc);
  }
  iVar2 = param_1[10];
  while (iVar2 != 0) {
    iVar1 = *(int *)(iVar2 + 0x10);
    FUN_017168b0(*(undefined4 *)(iVar2 + 0xc));
    FUN_01674ea0(iVar2,0x14);
    iVar2 = iVar1;
  }
  *param_1 = std::_Node_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 7455 ; VA 0x00652a50 ; FUN_00652a50 */

undefined4 * __thiscall FUN_00652a50(undefined4 *param_1,byte param_2)

{
  FUN_017168b0(param_1[7]);
  *param_1 = std::_Node_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  return param_1;
}



/* FUNCTION 7456 ; VA 0x00652a80 ; FUN_00652a80 */

undefined4 * __thiscall FUN_00652a80(undefined4 *param_1,byte param_2)

{
  *param_1 = std::collate<char>::vftable;
  FUN_017168b0(param_1[3]);
  *param_1 = std::_Facet_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 7457 ; VA 0x00652ac0 ; FUN_00652ac0 */

undefined4 __thiscall FUN_00652ac0(undefined4 param_1,byte param_2)

{
  FUN_006518c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb8);
  }
  return param_1;
}



/* FUNCTION 7458 ; VA 0x00652af0 ; FUN_00652af0 */

undefined4 __thiscall FUN_00652af0(undefined4 param_1,byte param_2)

{
  FUN_00651ac0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x3f88);
  }
  return param_1;
}



/* FUNCTION 7459 ; VA 0x00652b20 ; FUN_00652b20 */

undefined4 * __thiscall FUN_00652b20(undefined4 *param_1,byte param_2)

{
  *param_1 = ClientBlockRules::vftable;
  FUN_00651250();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x78);
  }
  return param_1;
}



/* FUNCTION 7460 ; VA 0x00652b50 ; FUN_00652b50 */

undefined4 * __thiscall FUN_00652b50(undefined4 *param_1,byte param_2)

{
  *param_1 = ClientCrashRules::vftable;
  FUN_006512c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x78);
  }
  return param_1;
}



/* FUNCTION 7461 ; VA 0x00652b80 ; FUN_00652b80 */

undefined4 * __thiscall FUN_00652b80(undefined4 *param_1,byte param_2)

{
  *param_1 = Ipv4CIDRFlagsList::vftable;
  FUN_00651330();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x78);
  }
  return param_1;
}



/* FUNCTION 7462 ; VA 0x00652bb0 ; FUN_00652bb0 */

undefined4 __thiscall FUN_00652bb0(undefined4 param_1,byte param_2)

{
  FUN_0151f7f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  return param_1;
}



/* FUNCTION 7463 ; VA 0x00652be0 ; FUN_00652be0 */

undefined4 * __thiscall FUN_00652be0(undefined4 *param_1,byte param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  *param_1 = std::_Node_assert::vftable;
  puVar2 = (undefined4 *)param_1[5];
  while (puVar2 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)puVar2[3];
    puVar2[3] = 0;
    (**(code **)*puVar2)(1);
    puVar2 = puVar1;
  }
  *param_1 = std::_Node_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 7464 ; VA 0x00652c30 ; FUN_00652c30 */

undefined4 * __thiscall FUN_00652c30(undefined4 *param_1,byte param_2)

{
  *param_1 = std::_Node_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 7465 ; VA 0x00652c60 ; FUN_00652c60 */

undefined4 * __thiscall FUN_00652c60(undefined4 *param_1,byte param_2)

{
  *param_1 = std::_Node_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 7466 ; VA 0x00652c90 ; FUN_00652c90 */

undefined4 * __thiscall FUN_00652c90(undefined4 *param_1,byte param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  *param_1 = std::_Node_if::vftable;
  puVar3 = (undefined4 *)param_1[6];
  while (puVar3 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)puVar3[6];
    puVar3[6] = 0;
    puVar2 = (undefined4 *)param_1[5];
    puVar4 = puVar3;
    while ((puVar3 = puVar1, puVar4 != puVar2 && (puVar4 != (undefined4 *)0x0))) {
      puVar3 = (undefined4 *)puVar4[3];
      puVar4[3] = 0;
      (**(code **)*puVar4)(1);
      puVar4 = puVar3;
    }
  }
  *param_1 = std::_Node_base::vftable;
  if ((param_2 & 1) == 0) {
    return param_1;
  }
  FUN_01674ea0(param_1,0x1c);
  return param_1;
}



/* FUNCTION 7467 ; VA 0x00652d10 ; FUN_00652d10 */

undefined4 * __thiscall FUN_00652d10(undefined4 *param_1,byte param_2)

{
  *param_1 = std::_Node_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 7468 ; VA 0x00652d40 ; FUN_00652d40 */

undefined4 * __thiscall FUN_00652d40(undefined4 *param_1,byte param_2)

{
  *param_1 = std::_Node_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 7469 ; VA 0x00652d70 ; FUN_00652d70 */

undefined4 __thiscall FUN_00652d70(int param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  double *pdVar3;
  undefined4 *puVar4;
  undefined auStack_40 [36];
  undefined4 uStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1980;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb4;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  uStack_1c = FUN_01675290();
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  cVar1 = FUN_005f7260();
  if (cVar1 != '\0') {
    uVar2 = FUN_00679b60();
    uStack_8 = 2;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return uVar2;
  }
  switch(**(undefined **)(param_2 + 0x38)) {
  case 0x1b:
    if (DAT_01d5aa30 != '\0') {
      FUN_00665820();
    }
    uVar2 = FUN_00679b60();
    uStack_8 = 0xf;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return uVar2;
  default:
    uVar2 = FUN_00679b60();
    uStack_8 = 0x10;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return uVar2;
  case 0x83:
    break;
  case 0x87:
  case 0x88:
  case 0x8b:
  case 0x8c:
    if ((*(char *)(param_1 + 0x3eef) != '\0') && (*(char *)(param_1 + 0x3ee2) != '\x02')) {
      FUN_00668b60();
      uStack_8 = 0xb;
      uVar2 = FUN_0065317c();
      return uVar2;
    }
    uVar2 = FUN_00679b60();
    uStack_8 = 0xc;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return uVar2;
  case 0x89:
    cVar1 = FUN_00657a10();
    if (cVar1 == '\0') {
      uStack_8 = 9;
      uVar2 = FUN_0065317c();
      return uVar2;
    }
    uVar2 = FUN_00679b60();
    uStack_8 = 10;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return uVar2;
  case 0x8a:
    if (*(char *)(param_1 + 0x3eec) != '\0') {
      if (((DAT_01eadc5c & 0x88) != 0) && (*(char *)(param_1 + 0x3f09) == '\0')) {
        FUN_0087c450(&DAT_018c5f98,"NetworkTest","SubmitTicket",0,0,0);
        *(undefined *)(param_1 + 0x3f09) = 1;
      }
      if ((DAT_01eadc5c & 8) != 0) {
        uStack_8 = 3;
        uVar2 = FUN_0065317c();
        return uVar2;
      }
    }
    *(undefined *)(param_1 + 0x3eec) = 1;
    FUN_00666bf0();
    *(undefined *)(param_1 + 0x3dfc) = 1;
    pdVar3 = (double *)FUN_016830f0();
    FUN_0151fb00("ProcessedTicket",*pdVar3 - *(double *)(param_1 + 0x3b64));
    if (DAT_01ee420a != '\0') {
      FUN_016774b0(DAT_01ee420a,"Player authenticated = %d",*(undefined *)(param_1 + 0x3d14));
    }
    uStack_8 = 4;
    uVar2 = FUN_0065317c();
    return uVar2;
  case 0x9b:
    FUN_00663ad0();
    uStack_8 = 0xd;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return 1;
  case 0x9c:
    FUN_00663f10();
    uStack_8 = 0xe;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return 1;
  }
  if (*(char *)(param_1 + 0x3d14) == '\0') {
    if (DAT_01d84e8f != '\0') {
      puVar4 = (undefined4 *)FUN_006b1620(auStack_40,param_2,1,0x7c);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_01677650(DAT_01d84e8f,"Player not authenticated %s",puVar4);
      FUN_005507b0();
    }
    uStack_8 = 6;
    uVar2 = FUN_0065317c();
    return uVar2;
  }
  if ((*(char *)(param_1 + 0x3eef) != '\0') && (*(char *)(param_1 + 0x3ee2) != '\x02')) {
    FUN_00668b60();
    uStack_8 = 7;
    uVar2 = FUN_0065317c();
    return uVar2;
  }
  uVar2 = FUN_00679b60();
  uStack_8 = 8;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 7470 ; VA 0x00653103 ; Catch@00653103 */

undefined * Catch_00653103(void)

{
  char *pcVar1;
  char *pcVar2;
  int unaff_EBP;
  
  pcVar1 = (char *)(**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  pcVar2 = "empty error string";
  if (pcVar1 != (char *)0x0) {
    pcVar2 = pcVar1;
  }
  FUN_0086f2f0(3,"CheatHandlingServerReplicator::OnReceive packet %d: %s",
               **(undefined **)(*(int *)(unaff_EBP + 8) + 0x38),pcVar2);
  if (DAT_01ee420a != '\0') {
    FUN_01677650(DAT_01ee420a,"Error on CheatHandlingServerReplicator::OnReceive: %s",pcVar1);
  }
  (**(code **)(*(int *)(*(int *)(unaff_EBP + -0x14) + -0x5c) + 0x294))(0x104,"PacketError",5,2,0,1);
  return &DAT_00653172;
}



/* FUNCTION 7471 ; VA 0x0065317c ; FUN_0065317c */

undefined4 FUN_0065317c(void)

{
  int unaff_EBP;
  
  FUN_01675290();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return 0;
}



/* FUNCTION 7472 ; VA 0x00653240 ; FUN_00653240 */

void __thiscall
FUN_00653240(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int iVar1;
  undefined4 ***pppuVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piVar8;
  undefined4 ****ppppuVar9;
  char *pcVar10;
  uint uVar11;
  uint uVar12;
  char acStack_8d8 [2048];
  undefined auStack_d8 [104];
  undefined auStack_70 [4];
  int *piStack_6c;
  undefined4 ***apppuStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 ***apppuStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a19c6;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffff71c;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  uVar4 = FUN_01675290(DAT_01eadc98);
  iStack_8 = 0;
  *(undefined4 *)(param_1 + 0x3c24) = 1;
  uStack_1c = uVar4;
  FUN_005c28f0(param_1);
  FUN_008cc950(apppuStack_64);
  iStack_8._0_1_ = 1;
  FUN_0170d1f0(acStack_8d8,0,0x800);
  ppppuVar9 = apppuStack_64;
  if (0xf < uStack_50) {
    ppppuVar9 = (undefined4 ****)apppuStack_64[0];
  }
  FUN_0058ccc0(acStack_8d8,0x800,
               "%suniverses/validate-place-join?originPlaceId=%lld&destinationPlaceId=%lld",
               ppppuVar9,param_2,param_3,param_4,param_5);
  pcVar10 = acStack_8d8;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  do {
    cVar3 = *pcVar10;
    pcVar10 = pcVar10 + 1;
  } while (cVar3 != '\0');
  FUN_005542c0(acStack_8d8,(int)pcVar10 - (int)(acStack_8d8 + 1));
  iStack_8._0_1_ = 3;
  uStack_24 = 0;
  uStack_20 = 0xf;
  apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
  FUN_005542c0(&DAT_018bc9b8,0);
  iVar1 = *(int *)(param_1 + 0x34);
  iStack_8 = CONCAT31(iStack_8._1_3_,4);
  iVar5 = param_1;
  if ((iVar1 != 0) && (iVar5 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
    iVar5 = FUN_005c8ac0();
  }
  if ((iVar5 != 0) &&
     (iVar1 = *(int *)(iVar5 + 0xc), iVar5 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
     (uint)*(ushort *)(iVar5 + 0x1da))) {
    FUN_005789c0(&DAT_01eadc4c,&LAB_0064e290);
    uVar6 = FUN_0064e320();
    piVar7 = (int *)FUN_008aa140(uVar6);
    if (*piVar7 == 0) {
      uVar6 = FUN_00bc47d0();
      piVar8 = (int *)FUN_008a9ba0(auStack_70,uVar6);
      iVar1 = *piVar8;
      iVar5 = piVar8[1];
      *piVar8 = 0;
      piVar8[1] = 0;
      *piVar7 = iVar1;
      piVar8 = (int *)piVar7[1];
      piVar7[1] = iVar5;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar1 = piVar8[1] + -1;
        piVar8[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar1 = piVar8[2] + -1;
          piVar8[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      param_1 = iStack_18;
      if (piStack_6c != (int *)0x0) {
        LOCK();
        iVar1 = piStack_6c[1] + -1;
        piStack_6c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_6c)();
          LOCK();
          piVar8 = piStack_6c + 2;
          iVar1 = *piVar8;
          *piVar8 = *piVar8 + -1;
          UNLOCK();
          param_1 = iStack_18;
          if (iVar1 == 1) {
            (**(code **)(*piStack_6c + 4))();
            param_1 = iStack_18;
          }
        }
      }
    }
    if (*piVar7 != 0) {
      FUN_014cc090(auStack_4c,0,0);
      iStack_8 = CONCAT31(iStack_8._1_3_,5);
      FUN_00bcae80(auStack_d8,2,apppuStack_34);
      goto LAB_00653494;
    }
  }
  FUN_014cc090(auStack_4c,0,0);
  iStack_8 = CONCAT31(iStack_8._1_3_,6);
  FUN_014cd0a0(apppuStack_34,0,0);
LAB_00653494:
  FUN_0056db40();
  pppuVar2 = apppuStack_34[0];
  ppppuVar9 = apppuStack_34;
  if (0xf < uStack_20) {
    ppppuVar9 = (undefined4 ****)apppuStack_34[0];
  }
  cVar3 = FUN_0055c360(ppppuVar9,uStack_24,&DAT_018bdf50,4);
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  *(uint *)(param_1 + 0x3c24) = (cVar3 == '\0') + 2;
  if (uStack_20 < 0x10) {
    iStack_8 = 2;
    FUN_00646c10(param_2,param_3,*(undefined4 *)(param_1 + 0x3c24));
    iStack_8._0_1_ = 1;
    if (0xf < uStack_38) {
      uVar12 = uStack_38 + 1;
      uVar11 = auStack_4c[0];
      if (0xfff < uVar12) {
        uVar11 = *(uint *)(auStack_4c[0] - 4);
        uVar12 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar12);
    }
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_50) {
      uVar11 = uStack_50 + 1;
      ppppuVar9 = (undefined4 ****)apppuStack_64[0];
      if (0xfff < uVar11) {
        ppppuVar9 = (undefined4 ****)apppuStack_64[0][-1];
        uVar11 = uStack_50 + 0x24;
        if (0x1f < (uint)((int)apppuStack_64[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar9,uVar11);
    }
    uStack_54 = 0;
    uStack_50 = 0xf;
    apppuStack_64[0] = (undefined4 ***)((uint)apppuStack_64[0] & 0xffffff00);
    iStack_8 = 8;
    FUN_01675290(uVar4);
    ExceptionList = pvStack_10;
    return;
  }
  uVar11 = uStack_20 + 1;
  ppppuVar9 = (undefined4 ****)pppuVar2;
  if (0xfff < uVar11) {
    ppppuVar9 = (undefined4 ****)pppuVar2[-1];
    uVar11 = uStack_20 + 0x24;
    if (0x1f < (uint)((int)pppuVar2 + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(ppppuVar9,uVar11);
  FUN_0065354d();
  return;
}



/* FUNCTION 7473 ; VA 0x00653508 ; Catch@00653508 */

undefined * Catch_00653508(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -100) + 4))();
  FUN_0086f2f0(3,"Exception in place validation: %s",uVar1);
  if (*(int *)(unaff_EBP + 8) == 0 && *(int *)(unaff_EBP + 0xc) == 0) {
    *(undefined4 *)(*(int *)(unaff_EBP + -0x14) + 0x3c24) = 2;
  }
  else {
    *(undefined4 *)(*(int *)(unaff_EBP + -0x14) + 0x3c24) = 3;
  }
  return &DAT_00653547;
}



/* FUNCTION 7474 ; VA 0x0065354d ; FUN_0065354d */

void FUN_0065354d(void)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int unaff_EBX;
  int unaff_EBP;
  
  uVar1 = *(undefined4 *)(unaff_EBX + 0x3c24);
  *(undefined4 *)(unaff_EBP + -4) = 2;
  FUN_00646c10(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0xc),uVar1);
  uVar2 = *(uint *)(unaff_EBP + -0x34);
  *(undefined *)(unaff_EBP + -4) = 1;
  if (0xf < uVar2) {
    iVar3 = *(int *)(unaff_EBP + -0x48);
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  uVar2 = *(uint *)(unaff_EBP + -0x4c);
  *(undefined4 *)(unaff_EBP + -0x38) = 0;
  *(undefined4 *)(unaff_EBP + -0x34) = 0xf;
  *(undefined *)(unaff_EBP + -0x48) = 0;
  *(undefined *)(unaff_EBP + -4) = 0;
  if (0xf < uVar2) {
    iVar3 = *(int *)(unaff_EBP + -0x60);
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(unaff_EBP + -0x50) = 0;
  *(undefined4 *)(unaff_EBP + -0x4c) = 0xf;
  *(undefined *)(unaff_EBP + -0x60) = 0;
  *(undefined4 *)(unaff_EBP + -4) = 8;
  FUN_01675290();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 7475 ; VA 0x00653630 ; FUN_00653630 */

void __thiscall FUN_00653630(int param_1,undefined4 param_2)

{
  int iVar1;
  code *pcVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  
  if ((*(int *)(*(int *)(param_1 + 4) + 4) != 6) ||
     ((*(byte *)(*(int *)(param_1 + 4) + 8) & 4) != 0)) {
    puVar3 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      puVar3[1] = 6;
      puVar3[2] = 0;
      puVar3[3] = 0;
      puVar3[4] = 0;
      *puVar3 = std::_Node_str<char>::vftable;
      puVar3[5] = 0;
      puVar3[6] = 0;
      puVar3[7] = 0;
    }
    puVar3[4] = *(undefined4 *)(param_1 + 4);
    iVar4 = *(int *)(param_1 + 4);
    if (*(int *)(iVar4 + 0xc) != 0) {
      puVar3[3] = *(int *)(iVar4 + 0xc);
      *(undefined4 **)(*(int *)(*(int *)(param_1 + 4) + 0xc) + 0x10) = puVar3;
      iVar4 = *(int *)(param_1 + 4);
    }
    *(undefined4 **)(iVar4 + 0xc) = puVar3;
    *(undefined4 **)(param_1 + 4) = puVar3;
  }
  if ((*(uint *)(param_1 + 8) & 0x100) == 0) {
    if ((*(uint *)(param_1 + 8) & 0x800) == 0) {
    }
    else {
      param_2._0_1_ = FUN_0066cac0(param_2);
    }
  }
  else {
    param_2._0_1_ = (**(code **)(**(int **)(*(int *)(param_1 + 0xc) + 4) + 0x10))(param_2);
  }
  iVar4 = *(int *)(param_1 + 4);
  if (*(uint *)(iVar4 + 0x14) <= *(uint *)(iVar4 + 0x18)) {
    iVar1 = *(uint *)(iVar4 + 0x18) + 0x10;
    iVar5 = FUN_017268a0(*(undefined4 *)(iVar4 + 0x1c),iVar1);
    if (iVar5 == 0) {
      FUN_010c5e30();
      pcVar2 = (code *)swi(3);
      (*pcVar2)();
      return;
    }
    *(int *)(iVar4 + 0x14) = iVar1;
    *(int *)(iVar4 + 0x1c) = iVar5;
  }
  *(undefined *)(*(int *)(iVar4 + 0x1c) + *(int *)(iVar4 + 0x18)) = (undefined)param_2;
  *(int *)(iVar4 + 0x18) = *(int *)(iVar4 + 0x18) + 1;
  return;
}



/* FUNCTION 7476 ; VA 0x00653740 ; FUN_00653740 */

void __thiscall FUN_00653740(int param_1,uint param_2)

{
  int iVar1;
  byte bVar2;
  undefined4 *puVar3;
  byte *pbVar4;
  
  if ((*(uint *)(param_1 + 8) & 0x100) != 0) {
    bVar2 = (**(code **)(**(int **)(*(int *)(param_1 + 0xc) + 4) + 0x10))(param_2);
    param_2 = (uint)bVar2;
  }
  iVar1 = *(int *)(param_1 + 4);
  puVar3 = *(undefined4 **)(iVar1 + 0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      puVar3[2] = 0;
      puVar3[3] = 0;
      puVar3[4] = 0;
      puVar3[5] = 0;
      puVar3[6] = 0;
      puVar3[7] = 0;
    }
    *(undefined4 **)(iVar1 + 0x18) = puVar3;
  }
  pbVar4 = (byte *)((int)puVar3 + ((param_2 & 0xff) >> 3));
  *pbVar4 = *pbVar4 | (byte)(1 << (param_2 & 7));
  return;
}



/* FUNCTION 7477 ; VA 0x006537b0 ; FUN_006537b0 */

void __fastcall FUN_006537b0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x2c);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 7;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    *puVar1 = std::_Node_class<char,class_std::regex_traits<char>_>::vftable;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    *(undefined2 *)(puVar1 + 9) = 0;
    puVar1[10] = 0;
  }
  puVar1[4] = *(undefined4 *)(param_1 + 4);
  iVar2 = *(int *)(param_1 + 4);
  if (*(int *)(iVar2 + 0xc) != 0) {
    puVar1[3] = *(int *)(iVar2 + 0xc);
    *(undefined4 **)(*(int *)(*(int *)(param_1 + 4) + 0xc) + 0x10) = puVar1;
    iVar2 = *(int *)(param_1 + 4);
  }
  *(undefined4 **)(iVar2 + 0xc) = puVar1;
  *(undefined4 **)(param_1 + 4) = puVar1;
  return;
}



/* FUNCTION 7478 ; VA 0x00653840 ; FUN_00653840 */

void __thiscall FUN_00653840(int param_1,int param_2,uint param_3)

{
  undefined4 ***pppuVar1;
  int iVar2;
  undefined4 uVar3;
  undefined uVar4;
  char cVar5;
  undefined4 ****ppppuVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 ****ppppuVar9;
  uint uVar10;
  byte *pbVar11;
  undefined4 *puVar12;
  int iVar13;
  undefined4 ***pppuStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  uint uStack_64;
  undefined4 ***pppuStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 ***pppuStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  int iStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a1a12;
  pvStack_10 = ExceptionList;
  iStack_24 = *(int *)(param_1 + 4);
  puVar7 = *(undefined4 **)(param_1 + 0xc);
  puVar12 = (undefined4 *)0x1;
  uStack_8 = 0;
  uStack_7 = 0;
  uStack_38 = 0xf00000000;
  pppuStack_48 = (undefined4 ***)((uint)pppuStack_48 & 0xffffff00);
  puStack_18 = (undefined4 *)0x1;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  puStack_1c = puVar7;
  if (param_2 != param_3) {
    iStack_30 = 0;
    uStack_2c = 0;
    iStack_28 = 0;
    ExceptionList = &pvStack_10;
    FUN_0064d160(param_2,param_3,param_2);
    uVar3 = uStack_2c;
    iVar2 = iStack_30;
    uStack_8 = 1;
    (**(code **)(*(int *)puVar7[1] + 0xc))(iStack_30,uStack_2c);
    (**(code **)(*(int *)*puStack_1c + 0x10))(&pppuStack_78,iVar2,uVar3);
    puVar12 = (undefined4 *)0x3;
    FUN_005507b0();
    pppuStack_48 = pppuStack_78;
    pppuStack_78 = (undefined4 ***)((uint)pppuStack_78 & 0xffffff00);
    uStack_44 = uStack_74;
    uStack_40 = uStack_70;
    uStack_3c = uStack_6c;
    uStack_38 = CONCAT44(uStack_64,uStack_68);
    uStack_68 = 0;
    uStack_64 = 0xf;
    FUN_0056d2d0();
  }
  param_3 = 0;
  do {
    puVar7 = *(undefined4 **)(iStack_20 + 0xc);
    uStack_11 = (undefined)param_3;
    uStack_8 = 2;
    puStack_18 = (undefined4 *)((uint)puVar12 | 4);
    uStack_50 = 0xf00000000;
    pppuStack_60 = (undefined4 ***)((uint)pppuStack_60 & 0xffffff00);
    iStack_30 = 0;
    uStack_2c = 0;
    iStack_28 = 0;
    FUN_0064d160(&uStack_11,&pvStack_10,puVar12);
    uVar3 = uStack_2c;
    uStack_8 = 3;
    (**(code **)(*(int *)puVar7[1] + 0xc))(iStack_30,uStack_2c);
    iVar2 = iStack_30;
    (**(code **)(*(int *)*puVar7 + 0x10))(&pppuStack_78,iStack_30,uVar3);
    pppuStack_60 = pppuStack_78;
    puStack_1c = (undefined4 *)((uint)puVar12 | 0xc);
    pppuStack_78 = (undefined4 ***)((uint)pppuStack_78 & 0xffffff00);
    uStack_8 = 2;
    uVar4 = uStack_8;
    uStack_8 = 2;
    uStack_5c = uStack_74;
    uStack_58 = uStack_70;
    uStack_54 = uStack_6c;
    uStack_50._0_4_ = uStack_68;
    uStack_50._4_4_ = uStack_64;
    uStack_68 = 0;
    uStack_64 = 0xf;
    if (iVar2 != 0) {
      uVar8 = iStack_28 - iVar2;
      iVar13 = iVar2;
      if (0xfff < uVar8) {
        iVar13 = *(int *)(iVar2 + -4);
        uVar8 = uVar8 + 0x23;
        if (0x1f < (iVar2 - iVar13) - 4U) goto LAB_00653b2a;
      }
      FUN_01674ea0(iVar13,uVar8);
      iStack_30 = 0;
      uStack_2c = 0;
      iStack_28 = 0;
    }
    uVar8 = uStack_50._4_4_;
    pppuVar1 = pppuStack_60;
    ppppuVar9 = &pppuStack_48;
    if (0xf < uStack_38._4_4_) {
      ppppuVar9 = (undefined4 ****)pppuStack_48;
    }
    ppppuVar6 = &pppuStack_60;
    if (0xf < uStack_50._4_4_) {
      ppppuVar6 = (undefined4 ****)pppuStack_60;
    }
    cVar5 = FUN_0055c360(ppppuVar6,(undefined4)uStack_50,ppppuVar9,(undefined4)uStack_38);
    puStack_1c = (undefined4 *)((uint)puStack_1c & 0xfffffffb);
    uStack_8 = 0;
    puStack_18 = puStack_1c;
    if (0xf < uVar8) {
      uVar10 = uVar8 + 1;
      ppppuVar9 = (undefined4 ****)pppuVar1;
      if (0xfff < uVar10) {
        ppppuVar9 = (undefined4 ****)pppuVar1[-1];
        uVar10 = uVar8 + 0x24;
        uVar4 = uStack_8;
        if (0x1f < (uint)((int)pppuVar1 + (-4 - (int)ppppuVar9))) goto LAB_00653b2a;
      }
      FUN_01674ea0(ppppuVar9,uVar10);
    }
    iVar2 = iStack_24;
    if (cVar5 != '\0') {
      puVar7 = *(undefined4 **)(iStack_24 + 0x18);
      if (puVar7 == (undefined4 *)0x0) {
        puVar7 = (undefined4 *)FUN_01674e20(0x20);
        if (puVar7 == (undefined4 *)0x0) {
          puVar7 = (undefined4 *)0x0;
        }
        else {
          *puVar7 = 0;
          puVar7[1] = 0;
          puVar7[2] = 0;
          puVar7[3] = 0;
          puVar7[4] = 0;
          puVar7[5] = 0;
          puVar7[6] = 0;
          puVar7[7] = 0;
        }
        *(undefined4 **)(iVar2 + 0x18) = puVar7;
      }
      pbVar11 = (byte *)((param_3 >> 3) + (int)puVar7);
      *pbVar11 = *pbVar11 | (byte)(1 << (param_3 & 7));
    }
    param_3 = param_3 + 1;
    puVar12 = puStack_1c;
  } while (param_3 < 0x100);
  if (0xf < uStack_38._4_4_) {
    uVar8 = uStack_38._4_4_ + 1;
    ppppuVar9 = (undefined4 ****)pppuStack_48;
    if (0xfff < uVar8) {
      ppppuVar9 = (undefined4 ****)pppuStack_48[-1];
      uVar8 = uStack_38._4_4_ + 0x24;
      uVar4 = uStack_8;
      if (0x1f < (uint)((int)pppuStack_48 + (-4 - (int)ppppuVar9))) {
LAB_00653b2a:
        uStack_8 = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7479 ; VA 0x00653b30 ; FUN_00653b30 */

void __thiscall FUN_00653b30(int param_1,ushort param_2,char param_3)

{
  int iVar1;
  undefined4 *puVar2;
  byte *pbVar3;
  uint uVar4;
  bool bVar5;
  
  uVar4 = 0;
  iVar1 = *(int *)(param_1 + 4);
  do {
    if (param_2 == 0xffff) {
      if (((char)uVar4 == '_') ||
         ((*(ushort *)(*(int *)(*(int *)(*(int *)(param_1 + 0xc) + 4) + 0xc) + (uVar4 & 0xff) * 2) &
          0x107) != 0)) {
        bVar5 = true;
      }
      else {
        bVar5 = false;
      }
    }
    else {
      bVar5 = (*(ushort *)
                (*(int *)(*(int *)(*(int *)(param_1 + 0xc) + 4) + 0xc) + (uVar4 & 0xff) * 2) &
              param_2) != 0;
    }
    if (bVar5 != (bool)param_3) {
      puVar2 = *(undefined4 **)(iVar1 + 0x18);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)FUN_01674e20(0x20);
        if (puVar2 == (undefined4 *)0x0) {
          puVar2 = (undefined4 *)0x0;
        }
        else {
          *puVar2 = 0;
          puVar2[1] = 0;
          puVar2[2] = 0;
          puVar2[3] = 0;
          puVar2[4] = 0;
          puVar2[5] = 0;
          puVar2[6] = 0;
          puVar2[7] = 0;
        }
        *(undefined4 **)(iVar1 + 0x18) = puVar2;
      }
      pbVar3 = (byte *)((uVar4 >> 3) + (int)puVar2);
      *pbVar3 = *pbVar3 | (byte)(1 << (uVar4 & 7));
    }
    uVar4 = uVar4 + 1;
  } while (uVar4 < 0x100);
  return;
}



/* FUNCTION 7480 ; VA 0x00653bf0 ; FUN_00653bf0 */

void __thiscall FUN_00653bf0(int param_1,uint param_2,uint param_3)

{
  int iVar1;
  code *pcVar2;
  char cVar3;
  undefined uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint *puVar7;
  uint uVar8;
  byte *pbVar9;
  uint uStack_8;
  
  if ((*(uint *)(param_1 + 8) & 0x100) == 0) {
    param_2 = param_2 & 0xff;
    param_3 = param_3 & 0xff;
  }
  else {
    cVar3 = (**(code **)(**(int **)(*(int *)(param_1 + 0xc) + 4) + 0x10))(param_2);
    param_2 = (uint)cVar3;
    cVar3 = (**(code **)(**(int **)(*(int *)(param_1 + 0xc) + 4) + 0x10))(param_3);
    param_3 = (uint)cVar3;
  }
  iVar1 = *(int *)(param_1 + 4);
  if (param_2 <= param_3) {
    while (param_3 < *(uint *)(param_1 + 0x10)) {
      puVar5 = *(undefined4 **)(iVar1 + 0x18);
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)FUN_01674e20(0x20);
        if (puVar5 == (undefined4 *)0x0) {
          puVar5 = (undefined4 *)0x0;
        }
        else {
          *puVar5 = 0;
          puVar5[1] = 0;
          puVar5[2] = 0;
          puVar5[3] = 0;
          puVar5[4] = 0;
          puVar5[5] = 0;
          puVar5[6] = 0;
          puVar5[7] = 0;
        }
        *(undefined4 **)(iVar1 + 0x18) = puVar5;
      }
      uVar6 = param_2 & 7;
      pbVar9 = (byte *)((param_2 >> 3) + (int)puVar5);
      param_2 = param_2 + 1;
      *pbVar9 = *pbVar9 | (byte)(1 << uVar6);
      if (param_3 < param_2) {
        return;
      }
    }
    if (param_3 < param_2) {
      return;
    }
    if (param_3 - param_2 < *(uint *)(param_1 + 0x14)) {
      if (param_3 < param_2) {
        return;
      }
      do {
        uVar4 = (undefined)param_2;
        uStack_8 = param_2 & 0xff;
        if ((*(uint *)(param_1 + 8) & 0x100) != 0) {
          uVar4 = (**(code **)(**(int **)(*(int *)(param_1 + 0xc) + 4) + 0x10))(uStack_8);
        }
        iVar1 = *(int *)(param_1 + 4);
        puVar7 = *(uint **)(iVar1 + 0x1c);
        if (puVar7 == (uint *)0x0) {
          puVar7 = (uint *)FUN_01674e20(0xc);
          if (puVar7 == (uint *)0x0) {
            puVar7 = (uint *)0x0;
          }
          else {
            *puVar7 = 0;
            puVar7[1] = 0;
            puVar7[2] = 0;
          }
          *(uint **)(iVar1 + 0x1c) = puVar7;
        }
        if (*puVar7 <= puVar7[1]) {
          uVar6 = puVar7[1] + 0x10;
          uVar8 = FUN_017268a0(puVar7[2],uVar6);
          if (uVar8 == 0) goto LAB_00653e1b;
          puVar7[2] = uVar8;
          *puVar7 = uVar6;
        }
        param_2 = param_2 + 1;
        *(undefined *)(puVar7[2] + puVar7[1]) = uVar4;
        puVar7[1] = puVar7[1] + 1;
        if (param_3 < param_2) {
          return;
        }
      } while( true );
    }
    puVar7 = *(uint **)(iVar1 + 0x20);
    if (puVar7 == (uint *)0x0) {
      puVar7 = (uint *)FUN_01674e20(0xc);
      if (puVar7 == (uint *)0x0) {
        puVar7 = (uint *)0x0;
        *(undefined4 *)(iVar1 + 0x20) = 0;
      }
      else {
        *puVar7 = 0;
        puVar7[1] = 0;
        puVar7[2] = 0;
        *(uint **)(iVar1 + 0x20) = puVar7;
      }
    }
    if (*puVar7 <= puVar7[1]) {
      uVar6 = puVar7[1] + 0x10;
      uVar8 = FUN_017268a0(puVar7[2],uVar6);
      if (uVar8 == 0) goto LAB_00653e1b;
      puVar7[2] = uVar8;
      *puVar7 = uVar6;
    }
    *(char *)(puVar7[2] + puVar7[1]) = (char)param_2;
    puVar7[1] = puVar7[1] + 1;
    puVar7 = *(uint **)(iVar1 + 0x20);
    if (*puVar7 <= puVar7[1]) {
      uVar8 = puVar7[1] + 0x10;
      uVar6 = FUN_017268a0(puVar7[2],uVar8);
      if (uVar6 == 0) {
LAB_00653e1b:
        FUN_010c5e30();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
      }
      puVar7[2] = uVar6;
      *puVar7 = uVar8;
    }
    *(char *)(puVar7[2] + puVar7[1]) = (char)param_3;
    puVar7[1] = puVar7[1] + 1;
  }
  return;
}



/* FUNCTION 7481 ; VA 0x00653e30 ; FUN_00653e30 */

void __thiscall FUN_00653e30(int *param_1,undefined4 *param_2,int param_3,byte param_4)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  int iStack_8;
  
  iStack_8 = param_1[1];
  if (*(int *)(iStack_8 + 4) == 6) {
    if (*(int *)(iStack_8 + 0x18) != 1) {
      iVar6 = *(int *)(iStack_8 + 0x18) + -1;
      *(int *)(iStack_8 + 0x18) = iVar6;
      FUN_00653630(*(undefined *)(*(int *)(iStack_8 + 0x1c) + iVar6));
      iStack_8 = param_1[1];
    }
  }
  if ((*(int *)(iStack_8 + 4) == 9) || (*(int *)(iStack_8 + 4) == 0xe)) {
    iStack_8 = *(int *)(iStack_8 + 0x14);
  }
  if ((param_2 == (undefined4 *)0x0) && (param_3 == 1)) {
    puVar2 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      puVar2[1] = 0x11;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
      *puVar2 = std::_Node_endif::vftable;
    }
    puVar3 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      puVar3[1] = 0x10;
      puVar3[2] = 0;
      puVar3[3] = 0;
      puVar3[4] = 0;
      *puVar3 = std::_Node_if::vftable;
      puVar3[5] = puVar2;
      puVar3[6] = 0;
    }
    puVar4 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      puVar4[1] = 0x10;
      puVar4[2] = 0;
      puVar4[3] = 0;
      puVar4[4] = 0;
      *puVar4 = std::_Node_if::vftable;
      puVar4[5] = puVar2;
      puVar4[6] = 0;
    }
    param_2 = (undefined4 *)FUN_01674e20(0x14);
    if (param_2 == (undefined4 *)0x0) {
      param_2 = (undefined4 *)0x0;
    }
    else {
      *param_2 = std::_Node_base::vftable;
      param_2[1] = 8;
      param_2[2] = 0;
      param_2[3] = 0;
      param_2[4] = 0;
    }
    puVar5 = (undefined4 *)FUN_01674e20(0x18);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5[1] = 9;
      puVar5[2] = 0;
      puVar5[3] = 0;
      puVar5[4] = 0;
      *puVar5 = std::_Node_end_group::vftable;
      puVar5[5] = param_2;
    }
    puVar4[3] = param_2;
    param_2[3] = puVar5;
    param_2[4] = puVar4;
    puVar5[4] = param_2;
    puVar5[3] = puVar2;
    puVar3[6] = puVar4;
    puVar2[4] = param_1[1];
    iVar6 = param_1[1];
    if (*(int *)(iVar6 + 0xc) != 0) {
      puVar2[3] = *(int *)(iVar6 + 0xc);
      *(undefined4 **)(*(int *)(param_1[1] + 0xc) + 0x10) = puVar2;
      iVar6 = param_1[1];
    }
    *(undefined4 **)(iVar6 + 0xc) = puVar2;
    param_1[1] = (int)puVar2;
    *(undefined4 **)(*(int *)(iStack_8 + 0x10) + 0xc) = puVar3;
    puVar3[4] = *(undefined4 *)(iStack_8 + 0x10);
    *(undefined4 **)(iStack_8 + 0x10) = puVar3;
    puVar3[3] = iStack_8;
    if (param_4 == 0) {
      iVar6 = puVar4[3];
      uVar1 = *(undefined4 *)(iStack_8 + 0x10);
      *(undefined4 *)(iStack_8 + 0x10) = *(undefined4 *)(iVar6 + 0x10);
      *(undefined4 *)(iVar6 + 0x10) = uVar1;
      uVar1 = puVar3[3];
      puVar3[3] = puVar4[3];
      puVar4[3] = uVar1;
      return;
    }
  }
  else {
    puVar2 = (undefined4 *)FUN_01674e20(0x18);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      puVar2[1] = 0x13;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
      *puVar2 = std::_Node_end_rep::vftable;
      puVar2[5] = 0;
    }
    puVar3 = (undefined4 *)FUN_01674e20(0x28);
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      iVar6 = *(int *)(*param_1 + 0x18);
      *(int *)(*param_1 + 0x18) = iVar6 + 1;
      puVar3[2] = (uint)param_4 * 2;
      puVar3[5] = param_2;
      puVar3[8] = iVar6;
      puVar3[1] = 0x12;
      puVar3[3] = 0;
      puVar3[4] = 0;
      *puVar3 = std::_Node_rep::vftable;
      puVar3[6] = param_3;
      puVar3[7] = puVar2;
      puVar3[9] = 0xffffffff;
    }
    puVar2[5] = puVar3;
    puVar2[4] = param_1[1];
    iVar6 = param_1[1];
    if (*(int *)(iVar6 + 0xc) != 0) {
      puVar2[3] = *(int *)(iVar6 + 0xc);
      *(undefined4 **)(*(int *)(param_1[1] + 0xc) + 0x10) = puVar2;
      iVar6 = param_1[1];
    }
    *(undefined4 **)(iVar6 + 0xc) = puVar2;
    param_1[1] = (int)puVar2;
    *(undefined4 **)(*(int *)(iStack_8 + 0x10) + 0xc) = puVar3;
    puVar3[4] = *(undefined4 *)(iStack_8 + 0x10);
    *(undefined4 **)(iStack_8 + 0x10) = puVar3;
    puVar3[3] = iStack_8;
  }
  return;
}



/* FUNCTION 7482 ; VA 0x00654140 ; FUN_00654140 */

undefined4 __fastcall FUN_00654140(undefined4 *param_1)

{
  char *pcVar1;
  code *pcVar2;
  char cVar3;
  char *pcVar4;
  int iVar5;
  undefined4 uVar6;
  undefined uVar7;
  
  uVar7 = 0;
  iVar5 = param_1[0x13];
  do {
    if ((iVar5 == -1) || (iVar5 == 0x7c)) goto LAB_00654355;
    if (iVar5 == 0x29) {
      if (param_1[4] != 0) {
LAB_00654355:
        return CONCAT31((int3)((uint)iVar5 >> 8),uVar7);
      }
      if ((param_1[0x14] & 0x10000000) == 0) goto LAB_00654362;
LAB_0065430c:
      if (iVar5 == 0x7d) {
        if ((param_1[0x14] & 0x10000000) == 0) goto LAB_00654374;
      }
      else if ((iVar5 == 0x5d) && ((param_1[0x14] & 0x10000000) == 0)) {
LAB_0065436b:
        FUN_006567e0(4);
LAB_00654374:
        FUN_006567e0(6);
        pcVar2 = (code *)swi(3);
        uVar6 = (*pcVar2)();
        return uVar6;
      }
      FUN_00653630(*(undefined *)(param_1 + 0x12));
LAB_00654337:
      FUN_006572e0();
LAB_0065433e:
      FUN_00657340();
    }
    else {
      if (iVar5 == 0x2e) {
        FUN_00657270(5);
        pcVar4 = (char *)*param_1;
        if (pcVar4 != (char *)param_1[2]) {
          if (((*pcVar4 == '\\') && (pcVar1 = pcVar4 + 1, pcVar1 != (char *)param_1[2])) &&
             ((((param_1[0x14] & 8) == 0 && ((*pcVar1 == '(' || (*pcVar1 == ')')))) ||
              (((param_1[0x14] & 0x10) == 0 && ((*pcVar1 == '{' || (*pcVar1 == '}')))))))) {
            pcVar4 = pcVar1;
          }
          *param_1 = pcVar4 + 1;
        }
        FUN_006576b0();
        goto LAB_0065433e;
      }
      if (iVar5 == 0x5c) {
        FUN_006572e0();
        if ((*(byte *)(param_1 + 0x14) & 0x80) == 0) {
LAB_0065422b:
          FUN_00654380();
          goto LAB_0065433e;
        }
        if (*(char *)(param_1 + 0x12) == 'b') {
          FUN_00657270(4);
          FUN_006572e0();
        }
        else {
          if (*(char *)(param_1 + 0x12) != 'B') goto LAB_0065422b;
          FUN_00657270(4);
          *(uint *)(param_1[10] + 8) = *(uint *)(param_1[10] + 8) ^ 1;
          FUN_006572e0();
        }
      }
      else {
        if (iVar5 == 0x5b) {
          FUN_006572e0();
          FUN_006537b0();
          iVar5 = param_1[0x13];
          if (iVar5 == 0x5e) {
            *(uint *)(param_1[10] + 8) = *(uint *)(param_1[10] + 8) ^ 1;
            FUN_006572e0();
            iVar5 = param_1[0x13];
          }
          if (((param_1[0x14] & 0x20000000) != 0) && (iVar5 == 0x5d)) {
            FUN_00653740(0x5d);
            FUN_006572e0();
          }
          FUN_00654f20();
          if (param_1[0x13] != 0x5d) goto LAB_0065436b;
          goto LAB_00654337;
        }
        if (iVar5 == 0x28) {
          FUN_006572e0();
          cVar3 = FUN_00657900();
          if (param_1[0x13] != 0x29) {
LAB_00654362:
            FUN_006567e0(5);
            goto LAB_0065436b;
          }
          FUN_006572e0();
          if (cVar3 != '\0') goto LAB_0065433e;
        }
        else if (iVar5 == 0x5e) {
          FUN_00657270(2);
          FUN_006572e0();
        }
        else {
          if (iVar5 != 0x24) {
            if ((((iVar5 != 0x2a) && (iVar5 != 0x2b)) && (iVar5 != 0x3f)) && (iVar5 != 0x7b))
            goto LAB_0065430c;
            FUN_006567e0(10);
            goto LAB_00654362;
          }
          FUN_00657270(3);
          FUN_006572e0();
        }
      }
    }
    iVar5 = param_1[0x13];
    uVar7 = 1;
  } while( true );
}



/* FUNCTION 7483 ; VA 0x00654380 ; FUN_00654380 */

void __fastcall FUN_00654380(int param_1)

{
  uint uVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  
  if (((*(uint *)(param_1 + 0x50) & 0x100) == 0) ||
     (iVar4 = FUN_00655930(10,0x7fffffff), iVar4 == 0x7fffffff)) {
    cVar3 = FUN_00654b20();
    if (cVar3 != '\0') {
      FUN_00653630(*(undefined *)(param_1 + 0x44));
      return;
    }
    if (((*(uint *)(param_1 + 0x50) & 0x20000) != 0) && (cVar3 = FUN_00654aa0(1), cVar3 != '\0')) {
      return;
    }
  }
  else {
    uVar1 = *(uint *)(param_1 + 0x44);
    if (uVar1 != 0) {
      if (((((*(uint *)(param_1 + 0x50) & 0x200) == 0) || (uVar1 < 10)) &&
          (uVar1 <= *(uint *)(param_1 + 0xc))) &&
         ((uVar1 < *(uint *)(param_1 + 0x20) &&
          ((*(uint *)(*(int *)(param_1 + 0x14) + (uVar1 >> 5) * 4) & 1 << ((byte)uVar1 & 0x1f)) != 0
          )))) {
        puVar5 = (undefined4 *)FUN_01674e20(0x18);
        if (puVar5 == (undefined4 *)0x0) {
          puVar5 = (undefined4 *)0x0;
        }
        else {
          puVar5[1] = 0xf;
          puVar5[2] = 0;
          puVar5[3] = 0;
          puVar5[4] = 0;
          *puVar5 = std::_Node_back::vftable;
          puVar5[5] = uVar1;
        }
        puVar5[4] = *(undefined4 *)(param_1 + 0x28);
        iVar4 = *(int *)(param_1 + 0x28);
        if (*(int *)(iVar4 + 0xc) != 0) {
          puVar5[3] = *(int *)(iVar4 + 0xc);
          *(undefined4 **)(*(int *)(*(int *)(param_1 + 0x28) + 0xc) + 0x10) = puVar5;
          iVar4 = *(int *)(param_1 + 0x28);
        }
        *(undefined4 **)(iVar4 + 0xc) = puVar5;
        *(undefined4 **)(param_1 + 0x28) = puVar5;
        return;
      }
      goto LAB_006544b9;
    }
    if ((*(uint *)(param_1 + 0x50) & 0x100000) != 0) {
      FUN_00653630(0);
      return;
    }
  }
  FUN_006567e0(2);
LAB_006544b9:
  FUN_006567e0(3);
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}



/* FUNCTION 7484 ; VA 0x006544d0 ; FUN_006544d0 */

uint __fastcall FUN_006544d0(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(*(int *)(param_1 + 4) + 4);
  if ((((uVar1 != 0x14) && (uVar1 != 8)) && (uVar1 != 0xd)) &&
     ((uVar1 != 2 ||
      (((uVar1 = *(uint *)(*(int *)(*(int *)(param_1 + 4) + 0x10) + 4), uVar1 != 0x14 &&
        (uVar1 != 8)) && (uVar1 != 0xd)))))) {
    return uVar1 & 0xffffff00;
  }
  return CONCAT31((int3)(uVar1 >> 8),1);
}



/* FUNCTION 7485 ; VA 0x00654510 ; FUN_00654510 */

undefined4 * __thiscall FUN_00654510(int param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1a20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[2] = 0;
    puVar1[1] = (param_2 & 0xff) + 10;
    puVar1[3] = 0;
    puVar1[4] = 0;
    *puVar1 = std::_Node_assert::vftable;
    puVar1[5] = 0;
  }
  uStack_8 = 0;
  puVar2 = (undefined4 *)FUN_01674e20(0x14);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = std::_Node_base::vftable;
    puVar2[1] = 1;
    puVar2[2] = 0;
    puVar2[3] = 0;
    puVar2[4] = 0;
  }
  puVar1[4] = *(undefined4 *)(param_1 + 4);
  iVar3 = *(int *)(param_1 + 4);
  if (*(int *)(iVar3 + 0xc) != 0) {
    puVar1[3] = *(int *)(iVar3 + 0xc);
    *(undefined4 **)(*(int *)(*(int *)(param_1 + 4) + 0xc) + 0x10) = puVar1;
    iVar3 = *(int *)(param_1 + 4);
  }
  *(undefined4 **)(iVar3 + 0xc) = puVar1;
  puVar1[5] = puVar2;
  puVar2[4] = puVar1;
  *(undefined4 **)(param_1 + 4) = puVar2;
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 7486 ; VA 0x006545f6 ; Catch_All@006545f6 */

void Catch_All_006545f6(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7487 ; VA 0x00654610 ; FUN_00654610 */

undefined4 * __thiscall FUN_00654610(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 0xd;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    *puVar1 = std::_Node_capture::vftable;
    puVar1[5] = param_2;
  }
  puVar1[4] = *(undefined4 *)(param_1 + 4);
  iVar2 = *(int *)(param_1 + 4);
  if (*(int *)(iVar2 + 0xc) != 0) {
    puVar1[3] = *(int *)(iVar2 + 0xc);
    *(undefined4 **)(*(int *)(*(int *)(param_1 + 4) + 0xc) + 0x10) = puVar1;
    iVar2 = *(int *)(param_1 + 4);
  }
  *(undefined4 **)(iVar2 + 0xc) = puVar1;
  *(undefined4 **)(param_1 + 4) = puVar1;
  return puVar1;
}



/* FUNCTION 7488 ; VA 0x00654690 ; FUN_00654690 */

uint __fastcall FUN_00654690(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined3 uVar4;
  int iVar5;
  uint uVar6;
  
  uVar3 = 0;
  if (*(int *)(param_1 + 0x68) != 0) {
    iVar5 = *(int *)(param_1 + 0x24);
    do {
      uVar6 = 1 << ((byte)uVar3 & 0x1f);
      if (((*(uint *)(iVar5 + (uVar3 >> 5) * 4) & uVar6) != 0) &&
         ((*(uint *)(*(int *)(param_1 + 4) + (uVar3 >> 5) * 4) & uVar6) != 0)) {
        iVar5 = *(int *)(*(int *)(param_1 + 0x34) + uVar3 * 8);
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 8);
        iVar2 = *piVar1;
        uVar4 = (undefined3)(uVar3 >> 8);
        if (iVar5 != iVar2) {
          return CONCAT31(uVar4,iVar5 - *(int *)(param_1 + 0x4c) < iVar2 - *(int *)(param_1 + 0x4c))
          ;
        }
        iVar5 = *(int *)(*(int *)(param_1 + 0x34) + uVar3 * 8 + 4);
        iVar2 = piVar1[1];
        if (iVar5 != iVar2) {
          return CONCAT31(uVar4,iVar5 - *(int *)(param_1 + 0x4c) < iVar2 - *(int *)(param_1 + 0x4c))
          ;
        }
        iVar5 = *(int *)(param_1 + 0x24);
      }
      uVar3 = uVar3 + 1;
    } while (uVar3 < *(uint *)(param_1 + 0x68));
  }
  return uVar3 & 0xffffff00;
}



/* FUNCTION 7489 ; VA 0x00654710 ; FUN_00654710 */

uint __thiscall FUN_00654710(int *param_1,uint param_2)

{
  uint in_EAX;
  int iVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return in_EAX & 0xffffff00;
  }
  if (param_2 < 0x80000000) {
    iVar1 = FUN_00554060(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    param_1[2] = *param_1 + param_2;
    return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 7490 ; VA 0x00654770 ; FUN_00654770 */

void __fastcall FUN_00654770(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_30 [12];
  int *piStack_24;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1a40;
  pvStack_10 = ExceptionList;
  piStack_14 = param_1 + 2;
  ExceptionList = &pvStack_10;
  piStack_24 = param_1;
  FUN_016dda75(0);
  piVar1 = DAT_01eadc48;
  uStack_8 = 0;
  piStack_18 = DAT_01eadc48;
  if (DAT_01eadc44 == 0) {
    FUN_016dda75(0);
    if (DAT_01eadc44 == 0) {
      DAT_01eadc44 = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eadc44;
    }
    FUN_016ddacd();
  }
  uVar2 = DAT_01eadc44;
  iVar3 = param_1[3];
  if (DAT_01eadc44 < *(uint *)(iVar3 + 0xc)) {
    piVar4 = *(int **)(*(int *)(iVar3 + 8) + DAT_01eadc44 * 4);
    piVar5 = piStack_14;
    if (piVar4 != (int *)0x0) goto LAB_00654801;
  }
  else {
    piVar4 = (int *)0x0;
  }
  if (*(char *)(iVar3 + 0x14) == '\0') {
LAB_0065484a:
    piVar5 = piStack_14;
    if (piVar4 != (int *)0x0) goto LAB_00654801;
  }
  else {
    iVar3 = FUN_016de17b();
    if (uVar2 < *(uint *)(iVar3 + 0xc)) {
      piVar4 = *(int **)(*(int *)(iVar3 + 8) + uVar2 * 4);
      goto LAB_0065484a;
    }
  }
  piVar5 = piStack_14;
  piVar4 = piVar1;
  if (piVar1 == (int *)0x0) {
    iVar3 = FUN_006567f0(&piStack_18,piStack_14);
    piVar4 = piStack_18;
    if (iVar3 == -1) {
      FUN_0054fc60();
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_30,&DAT_01c24924);
    }
    piVar1 = piStack_18;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_016de14f(piStack_18);
    (**(code **)(*piVar4 + 4))();
    DAT_01eadc48 = piVar1;
  }
LAB_00654801:
  uStack_8 = 0xffffffff;
  FUN_016ddacd();
  piVar1 = piStack_24;
  *piStack_24 = (int)piVar4;
  iVar3 = FUN_0054e7d0(piVar5);
  piVar1[1] = iVar3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 7491 ; VA 0x006548b0 ; FUN_006548b0 */

void FUN_006548b0(int param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      if (param_1 == 0) {
        return;
      }
      iVar2 = param_3;
      switch(*(undefined4 *)(param_1 + 4)) {
      case 10:
      case 0xb:
        FUN_006548b0(*(undefined4 *)(param_1 + 0x14),0,0);
        break;
      case 0x10:
        if (param_3 != 0) {
          *(undefined4 *)(param_3 + 0x24) = 0;
        }
        for (iVar1 = *(int *)(param_1 + 0x18); iVar1 != 0; iVar1 = *(int *)(iVar1 + 0x18)) {
          FUN_006548b0(*(undefined4 *)(iVar1 + 0xc),*(undefined4 *)(iVar1 + 0x14),param_3);
        }
        break;
      case 0x12:
        iVar2 = param_1;
        if (param_3 != 0) {
          *(undefined4 *)(param_3 + 0x24) = 0;
          *(undefined4 *)(param_1 + 0x24) = 0;
          iVar2 = param_3;
        }
        break;
      case 0x13:
        if (param_3 == *(int *)(param_1 + 0x14)) {
          if (*(int *)(param_3 + 0x24) == -1) {
            *(undefined4 *)(param_3 + 0x24) = 1;
          }
          iVar2 = 0;
        }
      }
      param_1 = *(int *)(param_1 + 0xc);
      param_3 = iVar2;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 7492 ; VA 0x00654980 ; FUN_00654980 */

void __thiscall FUN_00654980(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 8;
  param_1[2] = param_2 + param_4 * 8;
  return;
}



/* FUNCTION 7493 ; VA 0x006549e0 ; FUN_006549e0 */

void FUN_006549e0(undefined *param_1,undefined *param_2,uint param_3,uint *param_4)

{
  undefined uVar1;
  code *pcVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  
  puVar3 = (uint *)*param_4;
  puVar6 = puVar3;
  if (puVar3 != (uint *)0x0) {
    do {
      puVar6 = puVar3;
      if (*puVar3 <= param_3) break;
      puVar6 = (uint *)puVar3[4];
      param_4 = puVar3 + 4;
      puVar3 = puVar6;
    } while (puVar6 != (uint *)0x0);
    if ((puVar6 != (uint *)0x0) && (param_3 == *puVar6)) goto LAB_00654a41;
  }
  puVar3 = (uint *)FUN_01674e20(0x14);
  if (puVar3 == (uint *)0x0) {
    puVar3 = (uint *)0x0;
  }
  else {
    *puVar3 = param_3;
    puVar3[1] = 0;
    puVar3[2] = 0;
    puVar3[3] = 0;
  }
  *param_4 = (uint)puVar3;
  puVar3[4] = (uint)puVar6;
  puVar6 = (uint *)*param_4;
LAB_00654a41:
  if (param_1 != param_2) {
    uVar4 = puVar6[2];
    do {
      uVar1 = *param_1;
      param_1 = param_1 + 1;
      if (puVar6[1] <= uVar4) {
        uVar5 = FUN_017268a0(puVar6[3],uVar4 + 0x10);
        if (uVar5 == 0) {
          FUN_010c5e30();
          pcVar2 = (code *)swi(3);
          (*pcVar2)();
          return;
        }
        puVar6[3] = uVar5;
        puVar6[1] = uVar4 + 0x10;
      }
      *(undefined *)(puVar6[3] + puVar6[2]) = uVar1;
      puVar6[2] = puVar6[2] + 1;
      uVar4 = puVar6[2];
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 7494 ; VA 0x00654aa0 ; FUN_00654aa0 */

undefined4 __thiscall FUN_00654aa0(int *param_1,uint param_2)

{
  int iVar1;
  short sVar2;
  
  iVar1 = *param_1;
  if (iVar1 != param_1[2]) {
    sVar2 = FUN_0064f780(iVar1,iVar1 + 1,(uint)param_1[0x10] >> 8 & 0xffffff01);
    if (sVar2 != 0) {
      if ((char)param_2 != '\0') {
        FUN_006537b0();
      }
      param_2 = CONCAT31(param_2._1_3_,
                         *(undefined *)
                          (*(int *)(*(int *)(param_1[0xf] + 4) + 0xc) +
                          (uint)*(byte *)(param_1 + 0x12) * 2)) & 0xffffff01;
      FUN_00653b30(sVar2,param_2);
      FUN_006572e0();
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 7495 ; VA 0x00654b20 ; FUN_00654b20 */

/* WARNING (jumptable): Unable to track spacebase fully for stack */

bool __fastcall FUN_00654b20(int param_1)

{
  char *pcVar1;
  code *pcVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  short sVar6;
  uint uVar7;
  char *pcVar8;
  int iVar9;
  int *extraout_ECX;
  char cVar10;
  int *piVar11;
  int *unaff_EBX;
  int unaff_EBP;
  undefined4 unaff_EDI;
  int in_GS_OFFSET;
  undefined8 uVar12;
  undefined2 uVar13;
  undefined2 uVar14;
  
  if (*(int *)(param_1 + 0x4c) == -1) goto LAB_00654cac;
  if (((*(uint *)(param_1 + 0x50) & 0x10000) == 0) ||
     (cVar4 = FUN_00655b80(*(undefined *)(param_1 + 0x48)), cVar4 == '\0')) {
    uVar7 = *(uint *)(param_1 + 0x50);
    if ((uVar7 & 0x8000) != 0) {
      if (*(char *)(param_1 + 0x48) == 'a') {
        *(undefined4 *)(param_1 + 0x44) = 7;
        FUN_006572e0();
        goto LAB_00654c3e;
      }
      if (*(char *)(param_1 + 0x48) == 'b') {
        *(undefined4 *)(param_1 + 0x44) = 8;
        goto LAB_00654b77;
      }
    }
    cVar4 = *(char *)(param_1 + 0x48);
    if (cVar4 == 'c') {
      if ((uVar7 & 0x40000) == 0) goto LAB_00654c21;
      FUN_006572e0();
      if ((*(ushort *)
            (*(int *)(*(int *)(*(int *)(param_1 + 0x3c) + 4) + 0xc) +
            (uint)*(byte *)(param_1 + 0x48) * 2) & 0x103) == 0) goto LAB_00654cac;
      uVar7 = (int)(char)*(byte *)(param_1 + 0x48) & 0x8000001f;
      if ((int)uVar7 < 0) {
        uVar7 = (uVar7 - 1 | 0xffffffe0) + 1;
      }
      *(int *)(param_1 + 0x44) = (int)(char)uVar7;
      FUN_006572e0();
    }
    else if (cVar4 == 'x') {
      if ((uVar7 & 0x1000) == 0) {
LAB_00654c21:
        if (((uVar7 & 0x2000) == 0) || (iVar9 = FUN_00655930(8,3), iVar9 == 3)) {
          iVar9 = (int)*(char *)(param_1 + 0x48);
          if ((*(uint *)(param_1 + 0x50) & 0x400000) != 0) {
            switch(iVar9) {
            case 0x44:
            case 0x53:
            case 0x57:
            case 99:
            case 100:
            case 0x73:
            case 0x77:
              goto switchD_00654c70_caseD_44;
            default:
              goto switchD_00654c70_caseD_45;
            }
          }
          switch(iVar9) {
          case 0x22:
          case 0x2f:
            iVar3 = 0x18;
            break;
          default:
            goto switchD_00654c70_caseD_44;
          case 0x24:
          case 0x2a:
          case 0x2e:
          case 0x5b:
          case 0x5c:
          case 0x5e:
          case 0x7c:
            goto switchD_00654c70_caseD_45;
          case 0x28:
          case 0x29:
          case 0x2b:
          case 0x3f:
          case 0x7b:
          case 0x7d:
            iVar3 = 0x17;
          }
          if ((*(uint *)(param_1 + 0x50) >> iVar3 & 1) == 0) {
switchD_00654c70_caseD_44:
            return false;
          }
switchD_00654c70_caseD_45:
          *(int *)(param_1 + 0x44) = iVar9;
          FUN_006572e0();
          return true;
        }
        if (*(int *)(param_1 + 0x44) == 0) goto LAB_00654cac;
      }
      else {
        FUN_006572e0();
        iVar9 = FUN_00655930(0x10,2);
        if (iVar9 != 0) goto LAB_00654cac;
      }
    }
    else {
      if ((cVar4 != 'u') || ((uVar7 & 0x800) == 0)) goto LAB_00654c21;
      FUN_006572e0();
      FUN_006569f0(4);
    }
  }
  else {
LAB_00654b77:
    FUN_006572e0();
  }
LAB_00654c3e:
  if (*(uint *)(param_1 + 0x44) < 0x100) {
    *(int *)(param_1 + 0x44) = (int)(char)*(uint *)(param_1 + 0x44);
    return true;
  }
LAB_00654cac:
  uVar12 = FUN_006567e0(2);
  piVar11 = (int *)((ulonglong)uVar12 >> 0x20);
  pcVar8 = (char *)uVar12;
  pcVar1 = (char *)((int)piVar11 + in_GS_OFFSET + 0x654c);
  *pcVar1 = *pcVar1 + (char)unaff_EBX;
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  cVar4 = (char)uVar12;
  *(char *)extraout_ECX = *(char *)extraout_ECX + cVar4;
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *(char *)extraout_ECX = *(char *)extraout_ECX + cVar4;
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *pcVar8 = *pcVar8 + cVar4;
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  *(char *)extraout_ECX = *(char *)extraout_ECX + cVar4;
  *extraout_ECX = (int)(pcVar8 + *extraout_ECX);
  cVar10 = (char)((ulonglong)uVar12 >> 0x20);
  *(char *)(piVar11 + -0x197fe6ad) = *(char *)(piVar11 + -0x197fe6ad) + cVar10;
  pcVar1 = (char *)(in_GS_OFFSET + unaff_EBP + -0x57ff9ab4);
  *pcVar1 = *pcVar1 + (char)extraout_ECX;
  pcVar8[in_GS_OFFSET] = pcVar8[in_GS_OFFSET] + cVar4;
  iVar9 = CONCAT31((int3)((uint)(pcVar8 + *piVar11 + *unaff_EBX + *extraout_ECX) >> 8),
                   (char)(pcVar8 + *piVar11 + *unaff_EBX + *extraout_ECX) + *(char *)extraout_ECX +
                   *(char *)unaff_EBX) + *extraout_ECX;
  *(char *)unaff_EBX = *(char *)unaff_EBX + (char)iVar9;
  iVar9 = iVar9 + *unaff_EBX + *unaff_EBX + *unaff_EBX + *unaff_EBX + *unaff_EBX + *unaff_EBX +
          *unaff_EBX;
  *extraout_ECX =
       *extraout_ECX +
       CONCAT31((int3)((uint)iVar9 >> 8),(char)iVar9 + *(char *)unaff_EBX) + *unaff_EBX + *unaff_EBX
       + *unaff_EBX + *unaff_EBX + *unaff_EBX + *unaff_EBX + *unaff_EBX + *unaff_EBX + *unaff_EBX +
       *unaff_EBX + *unaff_EBX + *unaff_EBX + *unaff_EBX;
  in((short)CONCAT31((int3)((ulonglong)uVar12 >> 0x28),cVar10 + *(char *)(unaff_EBP + -0x75)));
  uVar14 = SUB42(extraout_ECX,0);
  uVar13 = (undefined2)param_1;
  iVar9 = extraout_ECX[0x13];
  if (iVar9 != 0x5c) {
    if (iVar9 != 0x5b) {
      if ((iVar9 != 0x5d) && (iVar9 != -1)) {
        extraout_ECX[0x11] = (int)*(char *)(extraout_ECX + 0x12);
        FUN_006572e0(unaff_EDI,uVar13,uVar14);
        return true;
      }
      return false;
    }
    FUN_006572e0(unaff_EDI,uVar13,uVar14);
    iVar9 = extraout_ECX[0x13];
    if (((iVar9 != 0x3a) && (iVar9 != 0x3d)) && (iVar9 != 0x2e)) {
      extraout_ECX[0x11] = 0x5b;
      return true;
    }
    FUN_006572e0(unaff_EDI,uVar13,uVar14);
    FUN_00655a10(iVar9);
    return (bool)2;
  }
  FUN_006572e0(unaff_EDI,uVar13,uVar14);
  uVar7 = extraout_ECX[0x14];
  if ((uVar7 & 0x200000) == 0) {
    if ((((uVar7 & 0x10000) == 0) ||
        (cVar4 = FUN_00655b80(*(char *)(extraout_ECX + 0x12)), cVar4 == '\0')) &&
       (((extraout_ECX[0x14] & 0x8000U) == 0 ||
        (cVar4 = FUN_00655bf0(*(char *)(extraout_ECX + 0x12)), cVar4 == '\0')))) {
      extraout_ECX[0x11] = 0x5c;
      return true;
    }
    FUN_006572e0(unaff_EDI,uVar13,uVar14);
    return true;
  }
  if (((uVar7 & 0x4000) == 0) || (*(char *)(extraout_ECX + 0x12) != '\\')) {
    if (((uVar7 & 0x20000) != 0) &&
       ((iVar9 = *extraout_ECX, iVar9 != extraout_ECX[2] &&
        (sVar6 = FUN_0064f780(iVar9,iVar9 + 1,(uint)extraout_ECX[0x10] >> 8 & 0xffffff01),
        sVar6 != 0)))) {
      *(byte *)(unaff_EBP + -4) =
           *(byte *)(*(int *)(*(int *)(extraout_ECX[0xf] + 4) + 0xc) +
                    (uint)*(byte *)(extraout_ECX + 0x12) * 2) & 1;
      FUN_00653b30(sVar6,*(undefined4 *)(unaff_EBP + -4));
      FUN_006572e0(unaff_EDI,uVar13,uVar14);
      return (bool)2;
    }
    iVar9 = FUN_00655930(10,0x7fffffff);
    if (iVar9 == 0x7fffffff) {
      cVar4 = FUN_00654b20();
      return cVar4 != '\0';
    }
    if (extraout_ECX[0x11] != 0) {
      FUN_006567e0(2);
      pcVar2 = (code *)swi(3);
      uVar5 = (*pcVar2)();
      return (bool)uVar5;
    }
  }
  else {
    extraout_ECX[0x11] = 0x5c;
    FUN_006572e0(unaff_EDI,uVar13,uVar14);
  }
  return true;
}



/* FUNCTION 7496 ; VA 0x00654f20 ; FUN_00654f20 */

void __fastcall FUN_00654f20(undefined4 *param_1)

{
  char *pcVar1;
  code *pcVar2;
  char cVar3;
  byte bVar4;
  int iVar5;
  char *pcVar6;
  
  iVar5 = func_0x00654d60();
  if (iVar5 == 0) {
    return;
  }
  do {
    if (iVar5 != 2) {
      if ((param_1[0x11] == 0) && ((param_1[0x14] & 0x100000) == 0)) {
        FUN_006567e0(2);
        goto LAB_00655043;
      }
      if (param_1[0x13] == 0x2d) {
        pcVar6 = (char *)*param_1;
        if (pcVar6 != (char *)param_1[2]) {
          if (((*pcVar6 == '\\') && (pcVar1 = pcVar6 + 1, pcVar1 != (char *)param_1[2])) &&
             ((((param_1[0x14] & 8) == 0 && ((*pcVar1 == '(' || (*pcVar1 == ')')))) ||
              (((param_1[0x14] & 0x10) == 0 && ((*pcVar1 == '{' || (*pcVar1 == '}')))))))) {
            pcVar6 = pcVar1;
          }
          *param_1 = pcVar6 + 1;
        }
        FUN_006576b0();
        bVar4 = *(byte *)(param_1 + 0x11);
        iVar5 = func_0x00654d60();
        if (iVar5 == 0) {
          FUN_00653740(*(undefined *)(param_1 + 0x11));
          FUN_00653740(0x2d);
          return;
        }
        if (iVar5 == 2) {
LAB_00655043:
          FUN_006567e0(8);
          pcVar2 = (code *)swi(3);
          (*pcVar2)();
          return;
        }
        if ((param_1[0x10] & 0x800) != 0) {
          cVar3 = FUN_0066cac0(*(undefined *)(param_1 + 0x11));
          param_1[0x11] = (int)cVar3;
          bVar4 = FUN_0066cac0(bVar4);
        }
        if (*(byte *)(param_1 + 0x11) < bVar4) goto LAB_00655043;
        FUN_00653bf0(bVar4,*(byte *)(param_1 + 0x11));
      }
      else {
        FUN_00653740(param_1[0x11]);
      }
    }
    iVar5 = func_0x00654d60();
    if (iVar5 == 0) {
      return;
    }
  } while( true );
}



/* FUNCTION 7497 ; VA 0x00655050 ; FUN_00655050 */

int __fastcall FUN_00655050(int *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a1a50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00654610(0);
  FUN_00655360();
  if (*param_1 == param_1[2]) {
    FUN_00656740(uVar2);
    FUN_00657270(0x15);
    iVar3 = param_1[9];
    *(int *)(iVar3 + 0x14) = param_1[0x10];
    *(int *)(iVar3 + 0x1c) = param_1[3] + 1;
    FUN_006548b0(iVar3,0,0);
    ExceptionList = pvStack_10;
    return iVar3;
  }
  FUN_006567e0(0xe);
  pcVar1 = (code *)swi(3);
  iVar3 = (*pcVar1)();
  return iVar3;
}



/* FUNCTION 7498 ; VA 0x006550da ; Catch_All@006550da */

void Catch_All_006550da(void)

{
  FUN_00655330();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 7499 ; VA 0x00655100 ; FUN_00655100 */

void __fastcall FUN_00655100(int param_1)

{
  FUN_0064c4a0(param_1 + 4);
  return;
}


