/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 1750 ; VA 0x005056c0 ; FUN_005056c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005056c0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182115c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00db7610();
  FUN_009cb790(uVar1,s_UnbindButton_021420f0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02141fb8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Controller,void___cdecl(enum_RBX::Controller::Button),1>::vftable;
  _DAT_02141ff0 = FUN_00db9850;
  _DAT_02141ff4 = 0;
  DAT_02141ff8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02141fdc = FUN_00888530();
  puVar3 = DAT_02141ff8;
  if (DAT_02141ff8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00db9730();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00db97e0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_00db9730();
  uVar2 = FUN_0086e3d0(s_button_021420d0);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189e6c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1751 ; VA 0x00505860 ; FUN_00505860 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00505860(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182118e;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02141f28;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00db7610(uVar2,&DAT_02141f28);
  FUN_009cb790(uVar1,s_bindButton_021420e4,0,CONCAT44(puVar3,uVar2),0);
  _DAT_02141f70 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Controller,void___cdecl(enum_RBX::Controller::Button,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_02141fa8 = FUN_00db86a0;
  _DAT_02141fac = 0;
  DAT_02141fb0 = 0;
  _DAT_02141fb4 = 0;
  uStack_8 = 2;
  FUN_00db8af0();
  FUN_016f3654(&LAB_0189e6e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1752 ; VA 0x00505920 ; FUN_00505920 */

void FUN_00505920(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00db81f0(FUN_00db90c0,0,s_getButton_0214210c,s_button_021420d0,0,
               CONCAT44(&DAT_02142000,uStack_10),0);
  FUN_016f3654(&LAB_0189e710);
  return;
}



/* FUNCTION 1753 ; VA 0x00505980 ; FUN_00505980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00505980(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_018211c3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00db7610();
  FUN_009cb970(uVar1,s_ButtonChanged_02142118,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021420c4 = 0x7c;
  iStack_8 = 0;
  _DAT_02142090 =
       RBX::Reflection::
       EventDesc<class_RBX::Controller,void___cdecl(enum_RBX::Controller::Button),class_rbx::signal<void___cdecl(enum_RBX::Controller::Button)>,class_rbx::signal<void___cdecl(enum_RBX::Controller::Button)>_RBX::Controller::*>
       ::vftable;
  FUN_0086e3d0(s_button_021420d0);
  FUN_00db9730();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021420b8 = uStack_1c;
  _DAT_021420bc = uStack_18;
  _DAT_021420c0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02142090 =
       RBX::Reflection::
       EventDesc<class_RBX::Controller,void___cdecl(enum_RBX::Controller::Button),class_rbx::signal<void___cdecl(enum_RBX::Controller::Button)>,class_rbx::signal<void___cdecl(enum_RBX::Controller::Button)>_RBX::Controller::*>
       ::vftable;
  FUN_016f3654(&LAB_0189e730);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1754 ; VA 0x00505ad0 ; FUN_00505ad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00505ad0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018211ee;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00db7610(uVar2,0);
  FUN_009cb790(uVar1,s_BindButton_021420d8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02141f28 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Controller,void___cdecl(enum_RBX::Controller::Button,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_02141f60 = FUN_00db86a0;
  _DAT_02141f64 = 0;
  DAT_02141f68 = 0;
  _DAT_02141f6c = 0;
  uStack_8 = 2;
  FUN_00db8af0();
  FUN_016f3654(&LAB_0189e740);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1755 ; VA 0x00505ea0 ; FUN_00505ea0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00505ea0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018215b4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00890320();
  uVar3 = FUN_00dba460();
  FUN_009ca670(uVar3,uVar2,"FaceId",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f13c30 = RBX::Reflection::EnumPropDescriptor<class_RBX::Feature,enum_RBX::NormalId>::vftable
  ;
  _DAT_01f13c64 = uVar2;
  DAT_01f13c68 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f13c68 == (undefined4 *)0x0) {
    DAT_01f13c68 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f13c68 =
         RBX::Reflection::PropDescriptor<class_RBX::Feature,enum_RBX::NormalId>::
         GetSetImpl<enum_RBX::NormalId_(__thiscall_RBX::Feature::*)(void)const_,void_(__thiscall_RBX::Feature::*)(enum_RBX::NormalId)>
         ::vftable;
    DAT_01f13c68[2] = FUN_0074a340;
    DAT_01f13c68[3] = 0;
    DAT_01f13c68[4] = FUN_00dbc150;
    DAT_01f13c68[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f13c6c = FUN_00890320();
  cVar1 = (*(code *)DAT_01f13c30[3])();
  if (cVar1 != '\0') {
    _DAT_01f13c54 = _DAT_01f13c54 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f13c30[2])();
  if (cVar1 != '\0') {
    _DAT_01f13c54 = _DAT_01f13c54 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189e9a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1756 ; VA 0x00505fd0 ; FUN_00505fd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00505fd0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018215e0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f1471c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f1471c,uVar3,0,0,0x1f);
    if (DAT_01f1471c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01f146f8 = RBX::Reflection::RefType<class_RBX::Hole*>::vftable;
      FUN_016f3654(&LAB_0189ebd0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01f1471c);
    }
  }
  uVar2 = FUN_00dba740();
  FUN_009ca670(uVar2,&DAT_01f146f8,&DAT_0198f5ac,&DAT_018dbc3c,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_01f13b48 = RBX::Reflection::RefPropDescriptor<class_RBX::VelocityMotor,class_RBX::Hole>::
                 vftable;
  _DAT_01f13b7c =
       RBX::Reflection::RefPropDescriptor<class_RBX::VelocityMotor,class_RBX::Hole>::vftable;
  DAT_01f13b80 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f13b80 == (undefined4 *)0x0) {
    DAT_01f13b80 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f13b80 =
         RBX::Reflection::PropDescriptor<class_RBX::VelocityMotor,class_RBX::Hole*>::
         GetSetImpl<class_RBX::Hole*_(__thiscall_RBX::VelocityMotor::*)(void)const_,void_(__thiscall_RBX::VelocityMotor::*)(class_RBX::Hole*)>
         ::vftable;
    DAT_01f13b80[2] = FUN_00926d50;
    DAT_01f13b80[3] = 0;
    DAT_01f13b80[4] = FUN_00dbc170;
    DAT_01f13b80[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_01f13b48[3])();
  if (cVar1 != '\0') {
    _DAT_01f13b6c = _DAT_01f13b6c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f13b48[2])();
  if (cVar1 != '\0') {
    _DAT_01f13b6c = _DAT_01f13b6c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189e9c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1757 ; VA 0x00506170 ; FUN_00506170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00506170(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01821604;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dbc6b0();
  uVar3 = FUN_00dba460();
  FUN_009ca670(uVar3,uVar2,"InOut",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f13cf0 = RBX::Reflection::EnumPropDescriptor<class_RBX::Feature,enum_RBX::Feature::InOut>::
                 vftable;
  _DAT_01f13d24 = uVar2;
  DAT_01f13d28 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f13d28 == (undefined4 *)0x0) {
    DAT_01f13d28 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f13d28 =
         RBX::Reflection::PropDescriptor<class_RBX::Feature,enum_RBX::Feature::InOut>::
         GetSetImpl<enum_RBX::Feature::InOut_(__thiscall_RBX::Feature::*)(void)const_,void_(__thiscall_RBX::Feature::*)(enum_RBX::Feature::InOut)>
         ::vftable;
    DAT_01f13d28[2] = FUN_00b5f140;
    DAT_01f13d28[3] = 0;
    DAT_01f13d28[4] = FUN_00dbc380;
    DAT_01f13d28[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f13d2c = FUN_00dbc6b0();
  cVar1 = (*(code *)DAT_01f13cf0[3])();
  if (cVar1 != '\0') {
    _DAT_01f13d14 = _DAT_01f13d14 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f13cf0[2])();
  if (cVar1 != '\0') {
    _DAT_01f13d14 = _DAT_01f13d14 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189e9e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1758 ; VA 0x00506290 ; FUN_00506290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00506290(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01821624;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dbc760();
  uVar3 = FUN_00dba460();
  FUN_009ca670(uVar3,uVar2,"LeftRight",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f13cb0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Feature,enum_RBX::Feature::LeftRight>::vftable;
  _DAT_01f13ce4 = uVar2;
  DAT_01f13ce8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f13ce8 == (undefined4 *)0x0) {
    DAT_01f13ce8 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f13ce8 =
         RBX::Reflection::PropDescriptor<class_RBX::Feature,enum_RBX::Feature::LeftRight>::
         GetSetImpl<enum_RBX::Feature::LeftRight_(__thiscall_RBX::Feature::*)(void)const_,void_(__thiscall_RBX::Feature::*)(enum_RBX::Feature::LeftRight)>
         ::vftable;
    DAT_01f13ce8[2] = FUN_00c0b480;
    DAT_01f13ce8[3] = 0;
    DAT_01f13ce8[4] = FUN_00dbc3a0;
    DAT_01f13ce8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f13cec = FUN_00dbc760();
  cVar1 = (*(code *)DAT_01f13cb0[3])();
  if (cVar1 != '\0') {
    _DAT_01f13cd4 = _DAT_01f13cd4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f13cb0[2])();
  if (cVar1 != '\0') {
    _DAT_01f13cd4 = _DAT_01f13cd4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189ea00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1759 ; VA 0x005063b0 ; FUN_005063b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005063b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01821644;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dbc810();
  uVar3 = FUN_00dba460();
  FUN_009ca670(uVar3,uVar2,"TopBottom",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f13c70 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Feature,enum_RBX::Feature::TopBottom>::vftable;
  _DAT_01f13ca4 = uVar2;
  DAT_01f13ca8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f13ca8 == (undefined4 *)0x0) {
    DAT_01f13ca8 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f13ca8 =
         RBX::Reflection::PropDescriptor<class_RBX::Feature,enum_RBX::Feature::TopBottom>::
         GetSetImpl<enum_RBX::Feature::TopBottom_(__thiscall_RBX::Feature::*)(void)const_,void_(__thiscall_RBX::Feature::*)(enum_RBX::Feature::TopBottom)>
         ::vftable;
    DAT_01f13ca8[2] = FUN_008389e0;
    DAT_01f13ca8[3] = 0;
    DAT_01f13ca8[4] = FUN_00dbc5a0;
    DAT_01f13ca8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f13cac = FUN_00dbc810();
  cVar1 = (*(code *)DAT_01f13c70[3])();
  if (cVar1 != '\0') {
    _DAT_01f13c94 = _DAT_01f13c94 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f13c70[2])();
  if (cVar1 != '\0') {
    _DAT_01f13c94 = _DAT_01f13c94 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189ea20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1760 ; VA 0x00506920 ; FUN_00506920 */

void FUN_00506920(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  DAT_01f14824 = (float)dVar1 * DAT_018ce328;
  return;
}



/* FUNCTION 1761 ; VA 0x00506980 ; FUN_00506980 */

void FUN_00506980(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00dc87b0(FUN_00dc9700,0,s_AddKeyframe_0214241c,s_keyframe_02142410,0,uStack_10,0);
  FUN_016f3654(&LAB_0189eca0);
  return;
}



/* FUNCTION 1762 ; VA 0x005069e0 ; FUN_005069e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005069e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01821d1a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dc60b0(uVar2,0);
  FUN_009cb790(uVar1,s_GetKeyframes_02142400,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02142280 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::KeyframeSequence,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_021422b8 = FUN_00dcbd50;
  _DAT_021422bc = 0;
  _DAT_021422a4 = FUN_0088cc80();
  FUN_016f3654(&LAB_0189ecf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1763 ; VA 0x00506a80 ; FUN_00506a80 */

void FUN_00506a80(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00dc87b0(FUN_00dcc800,0,s_RemoveKeyframe_02142428,s_keyframe_02142410,0,uStack_10,0);
  FUN_016f3654(&LAB_0189ed00);
  return;
}



/* FUNCTION 1764 ; VA 0x00506ae0 ; FUN_00506ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00506ae0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01821d4c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dc60b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::KeyframeSequence,float>::
              GetSetImpl<float_(__thiscall_RBX::KeyframeSequence::*)(void)const_,void_(__thiscall_RBX::KeyframeSequence::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00926b60;
    puVar3[3] = 0;
    puVar3[4] = FUN_00dcc8e0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_AuthoredHipHeight_02142440,&DAT_021197d4,uStack_24,0,0,0x1f,1,1,0);
  DAT_021423c8 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021423fc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_021423ec = _DAT_021423ec & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021423c8[2])();
    if (cVar1 != '\0') {
      _DAT_021423ec = _DAT_021423ec & 0xfffffff3;
    }
  }
  DAT_021423c8 = RBX::Reflection::PropDescriptor<class_RBX::KeyframeSequence,float>::vftable;
  FUN_016f3654(&LAB_0189ed50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1765 ; VA 0x00506c10 ; FUN_00506c10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00506c10(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01821d74;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00aeea60();
  uVar3 = FUN_00dc60b0();
  FUN_009ca670(uVar3,uVar2,s_Priority_0213b47c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02142388 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::KeyframeSequence,enum_RBX::KeyframeSequence::Priority>
                 ::vftable;
  _DAT_021423bc = uVar2;
  DAT_021423c0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021423c0 == (undefined4 *)0x0) {
    DAT_021423c0 = (undefined4 *)0x0;
  }
  else {
    *DAT_021423c0 =
         RBX::Reflection::
         PropDescriptor<class_RBX::KeyframeSequence,enum_RBX::KeyframeSequence::Priority>::
         GetSetImpl<enum_RBX::KeyframeSequence::Priority_(__thiscall_RBX::KeyframeSequence::*)(void)const_,void_(__thiscall_RBX::KeyframeSequence::*)(enum_RBX::KeyframeSequence::Priority)>
         ::vftable;
    DAT_021423c0[2] = FUN_008609e0;
    DAT_021423c0[3] = 0;
    DAT_021423c0[4] = FUN_00dcc930;
    DAT_021423c0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021423c4 = FUN_00aeea60();
  cVar1 = (*(code *)DAT_02142388[3])();
  if (cVar1 != '\0') {
    _DAT_021423ac = _DAT_021423ac & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02142388[2])();
  if (cVar1 != '\0') {
    _DAT_021423ac = _DAT_021423ac & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189ed70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1766 ; VA 0x00506d30 ; FUN_00506d30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00506d30(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01821d9c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dc60b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::KeyframeSequence,bool>::
              GetSetImpl<bool_(__thiscall_RBX::KeyframeSequence::*)(void)const_,void_(__thiscall_RBX::KeyframeSequence::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00aebf50;
    puVar3[3] = 0;
    puVar3[4] = FUN_00dcc910;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,&DAT_02142438,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02142350 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02142384 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02142374 = _DAT_02142374 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02142350[2])();
    if (cVar1 != '\0') {
      _DAT_02142374 = _DAT_02142374 & 0xfffffff3;
    }
  }
  DAT_02142350 = RBX::Reflection::PropDescriptor<class_RBX::KeyframeSequence,bool>::vftable;
  FUN_016f3654(&LAB_0189ed90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1767 ; VA 0x005070f0 ; FUN_005070f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005070f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182208a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dcddb0(uVar2,0);
  FUN_009cb790(uVar1,"ClearInertialScrolling",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01f14e60 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ScrollingFrame,void___cdecl(void),0>::vftable;
  _DAT_01f14e98 = &LAB_00dcea66;
  _DAT_01f14e9c = 0x358;
  _DAT_01f14e84 = FUN_00888530();
  FUN_016f3654(&LAB_0189ee70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1768 ; VA 0x00507190 ; FUN_00507190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507190(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018220aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dcddb0(uVar2,0);
  FUN_009cb790(uVar1,"GetSampledInertialVelocity",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01f14ea0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ScrollingFrame,class_G3D::Vector2___cdecl(void)const_,0>::vftable;
  _DAT_01f14ed8 = FUN_01082ec0;
  _DAT_01f14edc = 0x358;
  _DAT_01f14ec4 = FUN_0088d730();
  FUN_016f3654(&LAB_0189ee80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1769 ; VA 0x00507230 ; FUN_00507230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507230(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018220ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dcddb0(uVar2,0);
  FUN_009cb790(uVar1,"ScrollToTop",5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01f14e20 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ScrollingFrame,void___cdecl(void),0>::vftable;
  _DAT_01f14e58 = FUN_01083300;
  _DAT_01f14e5c = 0x358;
  _DAT_01f14e44 = FUN_00888530();
  FUN_016f3654(&LAB_0189ee90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1770 ; VA 0x005072d0 ; FUN_005072d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005072d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018220f4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c7d060();
  uVar3 = FUN_00dcddb0();
  FUN_009ca670(uVar3,uVar2,"AutomaticCanvasSize","Scrolling",uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f14ae0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::ScrollingFrame,enum_RBX::GuiObject::AutomaticSize>::
                 vftable;
  _DAT_01f14b14 = uVar2;
  DAT_01f14b18 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f14b18 == (undefined4 *)0x0) {
    DAT_01f14b18 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f14b18 =
         RBX::Reflection::
         PropDescriptor<class_RBX::ScrollingFrame,enum_RBX::GuiObject::AutomaticSize>::
         GetSetImpl<enum_RBX::GuiObject::AutomaticSize_(__thiscall_RBX::ScrollingFrame::*)(void)const_,void_(__thiscall_RBX::ScrollingFrame::*)(enum_RBX::GuiObject::AutomaticSize)>
         ::vftable;
    DAT_01f14b18[2] = &LAB_00dcfee0;
    DAT_01f14b18[3] = 0;
    DAT_01f14b18[4] = FUN_00dd3aa0;
    DAT_01f14b18[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f14b1c = FUN_00c7d060();
  cVar1 = (*(code *)DAT_01f14ae0[3])();
  if (cVar1 != '\0') {
    _DAT_01f14b04 = _DAT_01f14b04 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f14ae0[2])();
  if (cVar1 != '\0') {
    _DAT_01f14b04 = _DAT_01f14b04 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189ef20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1771 ; VA 0x00507610 ; FUN_00507610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507610(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182211c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dcddb0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ScrollingFrame,class_RBX::UDim2>::
              GetSetImpl<class_RBX::UDim2_(__thiscall_RBX::ScrollingFrame::*)(void)const_,void_(__thiscall_RBX::ScrollingFrame::*)(class_RBX::UDim2)>
              ::vftable;
    puVar3[2] = FUN_00dcffa0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00dd3c60;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d5f0();
  FUN_009ca670(uVar2,uVar4,"CanvasSize","Scrolling",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f14aa4 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::UDim2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f14ad8 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f14ac8 = _DAT_01f14ac8 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f14aa4[2])();
    if (cVar1 != '\0') {
      _DAT_01f14ac8 = _DAT_01f14ac8 & 0xfffffff3;
    }
  }
  DAT_01f14aa4 = RBX::Reflection::PropDescriptor<class_RBX::ScrollingFrame,class_RBX::UDim2>::
                 vftable;
  FUN_016f3654(&LAB_0189efa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1772 ; VA 0x00507740 ; FUN_00507740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507740(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01822144;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dd4260();
  uVar3 = FUN_00dcddb0();
  FUN_009ca670(uVar3,uVar2,"ElasticBehavior","Scrolling",uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f14de0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::ScrollingFrame,enum_RBX::Scrollable::ElasticBehavior>
                 ::vftable;
  _DAT_01f14e14 = uVar2;
  DAT_01f14e18 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_01f14e18 == (undefined4 *)0x0) {
    DAT_01f14e18 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f14e18 =
         RBX::Reflection::
         PropDescriptor<class_RBX::ScrollingFrame,enum_RBX::Scrollable::ElasticBehavior>::
         GetSetImpl<enum_RBX::Scrollable::ElasticBehavior_(__thiscall_RBX::Scrollable::*)(void)const_,void_(__thiscall_RBX::ScrollingFrame::*)(enum_RBX::Scrollable::ElasticBehavior)>
         ::vftable;
    DAT_01f14e18[1] = FUN_005817e0;
    DAT_01f14e18[2] = FUN_00dd3d30;
    DAT_01f14e18[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f14e1c = FUN_00dd4260();
  cVar1 = (*(code *)DAT_01f14de0[3])();
  if (cVar1 != '\0') {
    _DAT_01f14e04 = _DAT_01f14e04 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f14de0[2])();
  if (cVar1 != '\0') {
    _DAT_01f14e04 = _DAT_01f14e04 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189efc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1773 ; VA 0x005079e0 ; FUN_005079e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005079e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182216c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dcddb0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ScrollingFrame,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::ScrollingFrame::*)(void)const_,void_(__thiscall_RBX::ScrollingFrame::*)(class_G3D::Color3)>
              ::vftable;
    puVar3[2] = FUN_00dd0310;
    puVar3[3] = 0;
    puVar3[4] = FUN_00dd3e50;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,"ScrollBarImageColor3","Scrolling",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f14bc8 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f14bfc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f14bec = _DAT_01f14bec & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f14bc8[2])();
    if (cVar1 != '\0') {
      _DAT_01f14bec = _DAT_01f14bec & 0xfffffff3;
    }
  }
  DAT_01f14bc8 = RBX::Reflection::PropDescriptor<class_RBX::ScrollingFrame,class_G3D::Color3>::
                 vftable;
  FUN_016f3654(&LAB_0189f040);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1774 ; VA 0x00507b10 ; FUN_00507b10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507b10(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182219c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dcddb0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ScrollingFrame,float>::
              GetSetImpl<float_(__thiscall_RBX::ScrollingFrame::*)(void)const_,void_(__thiscall_RBX::ScrollingFrame::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00dd0330;
    puVar3[3] = 0;
    puVar3[4] = FUN_00dd3eb0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,"ScrollBarImageTransparency","Scrolling",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f14c00 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f14c34 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f14c24 = _DAT_01f14c24 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f14c00[2])();
    if (cVar1 != '\0') {
      _DAT_01f14c24 = _DAT_01f14c24 & 0xfffffff3;
    }
  }
  DAT_01f14c00 = RBX::Reflection::PropDescriptor<class_RBX::ScrollingFrame,float>::vftable;
  FUN_016f3654(&LAB_0189f060);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1775 ; VA 0x00507c40 ; FUN_00507c40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507c40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018221cc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dcddb0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ScrollingFrame,int>::
              GetSetImpl<int_(__thiscall_RBX::ScrollingFrame::*)(void)const_,void_(__thiscall_RBX::ScrollingFrame::*)(int)>
              ::vftable;
    puVar3[2] = &LAB_00dd0340;
    puVar3[3] = 0;
    puVar3[4] = FUN_00dd3ef0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,"ScrollBarThickness","Scrolling",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f14b90 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f14bc4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f14bb4 = _DAT_01f14bb4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f14b90[2])();
    if (cVar1 != '\0') {
      _DAT_01f14bb4 = _DAT_01f14bb4 & 0xfffffff3;
    }
  }
  DAT_01f14b90 = RBX::Reflection::PropDescriptor<class_RBX::ScrollingFrame,int>::vftable;
  FUN_016f3654(&LAB_0189f080);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1776 ; VA 0x00507d70 ; FUN_00507d70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507d70(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018221f4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dd43c0();
  uVar3 = FUN_00dcddb0();
  FUN_009ca670(uVar3,uVar2,"ScrollingDirection","Scrolling",uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f14da0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::ScrollingFrame,enum_RBX::Scrollable::ScrollingDirection>
                 ::vftable;
  _DAT_01f14dd4 = uVar2;
  DAT_01f14dd8 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_01f14dd8 == (undefined4 *)0x0) {
    DAT_01f14dd8 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f14dd8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::ScrollingFrame,enum_RBX::Scrollable::ScrollingDirection>::
         GetSetImpl<enum_RBX::Scrollable::ScrollingDirection_(__thiscall_RBX::Scrollable::*)(void)const_,void_(__thiscall_RBX::ScrollingFrame::*)(enum_RBX::Scrollable::ScrollingDirection)>
         ::vftable;
    DAT_01f14dd8[1] = FUN_00615960;
    DAT_01f14dd8[2] = FUN_00dd3f40;
    DAT_01f14dd8[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f14ddc = FUN_00dd43c0();
  cVar1 = (*(code *)DAT_01f14da0[3])();
  if (cVar1 != '\0') {
    _DAT_01f14dc4 = _DAT_01f14dc4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f14da0[2])();
  if (cVar1 != '\0') {
    _DAT_01f14dc4 = _DAT_01f14dc4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189f0a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1777 ; VA 0x00507e90 ; FUN_00507e90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00507e90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182221c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dcddb0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ScrollingFrame,bool>::
              GetSetImpl<bool_(__thiscall_RBX::ScrollingFrame::*)(void)const_,void_(__thiscall_RBX::ScrollingFrame::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00dd0350;
    puVar3[3] = 0;
    puVar3[4] = FUN_00dd3f70;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,"ScrollingEnabled","Scrolling",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f14a6c = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f14aa0 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f14a90 = _DAT_01f14a90 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f14a6c[2])();
    if (cVar1 != '\0') {
      _DAT_01f14a90 = _DAT_01f14a90 & 0xfffffff3;
    }
  }
  DAT_01f14a6c = RBX::Reflection::PropDescriptor<class_RBX::ScrollingFrame,bool>::vftable;
  FUN_016f3654(&LAB_0189f0c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1778 ; VA 0x005080a0 ; FUN_005080a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005080a0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01822244;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dd4470();
  uVar3 = FUN_00dcddb0();
  FUN_009ca670(uVar3,uVar2,"VerticalScrollBarPosition","Scrolling",uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f14c38 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::ScrollingFrame,enum_RBX::ScrollingFrame::VerticalScrollBarPosition>
                 ::vftable;
  _DAT_01f14c6c = uVar2;
  DAT_01f14c70 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f14c70 == (undefined4 *)0x0) {
    DAT_01f14c70 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f14c70 =
         RBX::Reflection::
         PropDescriptor<class_RBX::ScrollingFrame,enum_RBX::ScrollingFrame::VerticalScrollBarPosition>
         ::
         GetSetImpl<enum_RBX::ScrollingFrame::VerticalScrollBarPosition_(__thiscall_RBX::ScrollingFrame::*)(void)const_,void_(__thiscall_RBX::ScrollingFrame::*)(enum_RBX::ScrollingFrame::VerticalScrollBarPosition)>
         ::vftable;
    DAT_01f14c70[2] = &LAB_00c42140;
    DAT_01f14c70[3] = 0;
    DAT_01f14c70[4] = FUN_00dd4230;
    DAT_01f14c70[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f14c74 = FUN_00dd4470();
  cVar1 = (*(code *)DAT_01f14c38[3])();
  if (cVar1 != '\0') {
    _DAT_01f14c5c = _DAT_01f14c5c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f14c38[2])();
  if (cVar1 != '\0') {
    _DAT_01f14c5c = _DAT_01f14c5c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189f120);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1779 ; VA 0x005081f0 ; FUN_005081f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005081f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01822444;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dd5710();
  uVar3 = FUN_00dd4970();
  FUN_009ca670(uVar3,uVar2,"Style",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f153e0 = RBX::Reflection::EnumPropDescriptor<class_RBX::Frame,enum_RBX::Frame::Style>::
                 vftable;
  _DAT_01f15414 = uVar2;
  DAT_01f15418 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f15418 == (undefined4 *)0x0) {
    DAT_01f15418 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f15418 =
         RBX::Reflection::PropDescriptor<class_RBX::Frame,enum_RBX::Frame::Style>::
         GetSetImpl<enum_RBX::Frame::Style_(__thiscall_RBX::Frame::*)(void)const_,void_(__thiscall_RBX::Frame::*)(enum_RBX::Frame::Style)>
         ::vftable;
    DAT_01f15418[2] = &LAB_00dd5030;
    DAT_01f15418[3] = 0;
    DAT_01f15418[4] = FUN_00dd5690;
    DAT_01f15418[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1541c = FUN_00dd5710();
  cVar1 = (*(code *)DAT_01f153e0[3])();
  if (cVar1 != '\0') {
    _DAT_01f15404 = _DAT_01f15404 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f153e0[2])();
  if (cVar1 != '\0') {
    _DAT_01f15404 = _DAT_01f15404 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189f1c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1780 ; VA 0x00508380 ; FUN_00508380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00508380(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0182260e;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dd5b30();
  FUN_009cb970(uVar1,s_DialogChoiceSelected_02142880,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_02142734 = 0xb8;
  iStack_8 = 0;
  _DAT_02142700 =
       RBX::Reflection::
       EventDesc<class_RBX::DialogRoot,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::DialogRoot::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_dialogChoice_02142854);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02142728 = uStack_1c;
  _DAT_0214272c = uStack_18;
  _DAT_02142730 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_02142700 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::DialogRoot,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::DialogRoot::*>
       ::vftable;
  _DAT_02142738 = 1;
  _DAT_0214273c = 1;
  FUN_016f3654(&LAB_0189f480);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1781 ; VA 0x00508510 ; FUN_00508510 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00508510(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182262a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dd5b30(uVar2,0);
  FUN_009cb790(uVar1,s_GetCurrentPlayers_02142824,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02142630 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DialogRoot,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02142668 = FUN_00dd71f0;
  _DAT_0214266c = 0;
  _DAT_02142654 = FUN_0088cc80();
  FUN_016f3654(&LAB_0189f490);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1782 ; VA 0x005085b0 ; FUN_005085b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005085b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182265e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dd5b30(uVar2,0);
  FUN_009cb790(uVar1,s_SetPlayerIsUsing_02142840,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02142670 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DialogRoot,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,bool),2>
       ::vftable;
  _DAT_021426a8 = FUN_00dd7820;
  _DAT_021426ac = 0;
  _DAT_021426b0 = 0;
  _DAT_021426b4 = 0;
  uStack_8 = 2;
  FUN_00dd6970();
  FUN_016f3654(&LAB_0189f4a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1783 ; VA 0x00508670 ; FUN_00508670 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00508670(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182268e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dd5b30(uVar2,0);
  FUN_009cb790(uVar1,s_SignalDialogChoiceSelected_02142864,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021426b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DialogRoot,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_021426f0 = FUN_00dd7d30;
  _DAT_021426f4 = 0;
  _DAT_021426f8 = 0;
  _DAT_021426fc = 0;
  uStack_8 = 2;
  FUN_00dd6700();
  FUN_016f3654(&LAB_0189f4b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1784 ; VA 0x00508730 ; FUN_00508730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00508730(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018226b4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dd7ea0();
  uVar3 = FUN_00dd5b30();
  FUN_009ca670(uVar3,uVar2,s_BehaviorType_021427f4,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02142580 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::DialogRoot,enum_RBX::DialogRoot::DialogBehaviorType>
                 ::vftable;
  _DAT_021425b4 = uVar2;
  DAT_021425b8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021425b8 == (undefined4 *)0x0) {
    DAT_021425b8 = (undefined4 *)0x0;
  }
  else {
    *DAT_021425b8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::DialogRoot,enum_RBX::DialogRoot::DialogBehaviorType>::
         GetSetImpl<enum_RBX::DialogRoot::DialogBehaviorType_(__thiscall_RBX::DialogRoot::*)(void)const_,void_(__thiscall_RBX::DialogRoot::*)(enum_RBX::DialogRoot::DialogBehaviorType)>
         ::vftable;
    DAT_021425b8[2] = FUN_00cb95e0;
    DAT_021425b8[3] = 0;
    DAT_021425b8[4] = FUN_00dd75d0;
    DAT_021425b8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021425bc = FUN_00dd7ea0();
  cVar1 = (*(code *)DAT_02142580[3])();
  if (cVar1 != '\0') {
    _DAT_021425a4 = _DAT_021425a4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02142580[2])();
  if (cVar1 != '\0') {
    _DAT_021425a4 = _DAT_021425a4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189f520);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1785 ; VA 0x005088d0 ; FUN_005088d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005088d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018226d4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dd7f50();
  uVar3 = FUN_00dd5b30();
  FUN_009ca670(uVar3,uVar2,s_Purpose_021427e4,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02142500 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::DialogRoot,enum_RBX::DialogRoot::DialogPurpose>::
                 vftable;
  _DAT_02142534 = uVar2;
  DAT_02142538 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02142538 == (undefined4 *)0x0) {
    DAT_02142538 = (undefined4 *)0x0;
  }
  else {
    *DAT_02142538 =
         RBX::Reflection::PropDescriptor<class_RBX::DialogRoot,enum_RBX::DialogRoot::DialogPurpose>
         ::
         GetSetImpl<enum_RBX::DialogRoot::DialogPurpose_(__thiscall_RBX::DialogRoot::*)(void)const_,void_(__thiscall_RBX::DialogRoot::*)(enum_RBX::DialogRoot::DialogPurpose)>
         ::vftable;
    DAT_02142538[2] = FUN_00b5ece0;
    DAT_02142538[3] = 0;
    DAT_02142538[4] = FUN_00dd7620;
    DAT_02142538[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214253c = FUN_00dd7f50();
  cVar1 = (*(code *)DAT_02142500[3])();
  if (cVar1 != '\0') {
    _DAT_02142524 = _DAT_02142524 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02142500[2])();
  if (cVar1 != '\0') {
    _DAT_02142524 = _DAT_02142524 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189f560);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1786 ; VA 0x00508af0 ; FUN_00508af0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00508af0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018226f4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dd8000();
  uVar3 = FUN_00dd5b30();
  FUN_009ca670(uVar3,uVar2,&DAT_021427ec,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02142540 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::DialogRoot,enum_RBX::DialogRoot::DialogTone>::vftable
  ;
  _DAT_02142574 = uVar2;
  DAT_02142578 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02142578 == (undefined4 *)0x0) {
    DAT_02142578 = (undefined4 *)0x0;
  }
  else {
    *DAT_02142578 =
         RBX::Reflection::PropDescriptor<class_RBX::DialogRoot,enum_RBX::DialogRoot::DialogTone>::
         GetSetImpl<enum_RBX::DialogRoot::DialogTone_(__thiscall_RBX::DialogRoot::*)(void)const_,void_(__thiscall_RBX::DialogRoot::*)(enum_RBX::DialogRoot::DialogTone)>
         ::vftable;
    DAT_02142578[2] = FUN_00c54090;
    DAT_02142578[3] = 0;
    DAT_02142578[4] = FUN_00dd7650;
    DAT_02142578[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214257c = FUN_00dd8000();
  cVar1 = (*(code *)DAT_02142540[3])();
  if (cVar1 != '\0') {
    _DAT_02142564 = _DAT_02142564 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02142540[2])();
  if (cVar1 != '\0') {
    _DAT_02142564 = _DAT_02142564 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189f5c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1787 ; VA 0x00508d60 ; FUN_00508d60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00508d60(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182271c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dd5b30();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::DialogRoot,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_(__thiscall_RBX::DialogRoot::*)(void)const_,void_(__thiscall_RBX::DialogRoot::*)(class_G3D::Vector3)>
              ::vftable;
    puVar3[2] = FUN_00a6bda0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00dd7bc0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,s_TriggerOffset_021428a8,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02142778 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021427ac = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214279c = _DAT_0214279c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02142778[2])();
    if (cVar1 != '\0') {
      _DAT_0214279c = _DAT_0214279c & 0xfffffff3;
    }
  }
  DAT_02142778 = RBX::Reflection::PropDescriptor<class_RBX::DialogRoot,class_G3D::Vector3>::vftable;
  FUN_016f3654(&LAB_0189f640);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1788 ; VA 0x00508ec0 ; FUN_00508ec0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00508ec0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01822a4e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dd8250(uVar2,0);
  FUN_009cb790(uVar1,s_GetMotor_02142a38,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02142998 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HapticService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(enum_RBX::InputObject::UserInputType,enum_RBX::HapticService::VibrationMotor),2>
       ::vftable;
  _DAT_021429d0 = FUN_00dd9fa0;
  _DAT_021429d4 = 0;
  DAT_021429d8 = 0;
  DAT_021429dc = 0;
  uStack_8 = 2;
  FUN_00dd94a0();
  FUN_016f3654(&LAB_0189f6c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1789 ; VA 0x00508f80 ; FUN_00508f80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00508f80(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01822a7e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dd8250(uVar2,0);
  FUN_009cb790(uVar1,s_IsMotorSupported_02142a08,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02142900 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HapticService,bool___cdecl(enum_RBX::InputObject::UserInputType,enum_RBX::HapticService::VibrationMotor),2>
       ::vftable;
  _DAT_02142938 = FUN_00dda090;
  _DAT_0214293c = 0;
  DAT_02142940 = 0;
  DAT_02142944 = 0;
  uStack_8 = 2;
  FUN_00dd9a60();
  FUN_016f3654(&LAB_0189f700);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1790 ; VA 0x00509040 ; FUN_00509040 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00509040(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01822adc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dd8250();
  FUN_009cb790(uVar1,s_IsVibrationSupported_021429e0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021428b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HapticService,bool___cdecl(enum_RBX::InputObject::UserInputType),1>
       ::vftable;
  _DAT_021428f0 = FUN_00dda150;
  _DAT_021428f4 = 0;
  DAT_021428f8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021428dc = FUN_0088daf0();
  puVar3 = DAT_021428f8;
  if (DAT_021428f8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00b84a30();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00b84c10();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00b84a30();
  uVar2 = FUN_0086e3d0(s_inputType_021341d8);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189f740);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1791 ; VA 0x005091e0 ; FUN_005091e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005091e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01822b18;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00dd8250(uVar2,0);
  FUN_009cb790(uVar1,s_SetMotor_02142a2c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02142948 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HapticService,void___cdecl(enum_RBX::InputObject::UserInputType,enum_RBX::HapticService::VibrationMotor,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),3>
       ::vftable;
  _DAT_02142980 = FUN_00dda4c0;
  _DAT_02142984 = 0;
  _DAT_02142988 = 0;
  _DAT_0214298c = 0;
  _DAT_02142990 = 0;
  uStack_8 = 3;
  FUN_00dd96c0(s_inputType_021341d8,s_vibrationMotor_021429f8,s_vibrationValues_02142a1c);
  FUN_016f3654(&LAB_0189f760);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1792 ; VA 0x00509360 ; FUN_00509360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00509360(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01823678;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ddb150(uVar2,0);
  FUN_009cb820(uVar1,s_GetAssetThumbnailAsync_02142dc8,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02142c88 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AssetService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(__int64,class_G3D::Vector2,int),3>
       ::vftable;
  _DAT_02142cc0 = FUN_00de45e0;
  _DAT_02142cc4 = 0;
  DAT_02142cc8 = 0;
  DAT_02142ccc = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  DAT_02142cd0 = (undefined4 *)FUN_01674e20(4);
  if (DAT_02142cd0 == (undefined4 *)0x0) {
    DAT_02142cd0 = (undefined4 *)0x0;
  }
  else {
    *DAT_02142cd0 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00de1e80(s_assetId_0211bf40,s_thumbnailSize_021218f4,s_assetType_0212b8c4);
  FUN_016f3654(&LAB_0189f7f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1793 ; VA 0x00509450 ; FUN_00509450 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00509450(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018236cf;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_0211fa6e;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  uVar2 = FUN_00ddb150();
  FUN_009cb820(uVar2,s_CreatePlaceAsync_02142d14,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02142a90 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AssetService,__int64___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),3>
       ::vftable;
  _DAT_02142ac8 = FUN_00de0c50;
  _DAT_02142acc = 0;
  _DAT_02142ad0 = 0;
  DAT_02142ad4 = 0;
  uStack_8._0_1_ = 3;
  iStack_14 = FUN_01674e20(0x18);
  uStack_8._0_1_ = 4;
  if (iStack_14 == 0) {
    _DAT_02142ad8 = 0;
  }
  else {
    _DAT_02142ad8 = FUN_0054ef60(auStack_38);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00de2270(s_placeName_02142d08,s_templatePlaceID_02142cf8,s_description_0212171c);
  if (0xf < uStack_24) {
    if (0xfff < uStack_24 + 1) {
      if (0x1f < (auStack_38[0] - *(int *)(auStack_38[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_016f3654(&LAB_0189f840);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1794 ; VA 0x005095b0 ; FUN_005095b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005095b0(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01823729;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_0211fa6e;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  uVar2 = FUN_00ddb150();
  FUN_009cb820(uVar2,s_CreatePlaceInPlayerInventoryAsyn_02142d28,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02142ae0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AssetService,__int64___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),4>
       ::vftable;
  _DAT_02142b18 = FUN_00de18b0;
  _DAT_02142b1c = 0;
  _DAT_02142b20 = 0;
  _DAT_02142b24 = 0;
  _DAT_02142b28 = 0;
  uStack_8._0_1_ = 4;
  iStack_14 = FUN_01674e20(0x18);
  uStack_8._0_1_ = 5;
  if (iStack_14 == 0) {
    _DAT_02142b2c = 0;
  }
  else {
    _DAT_02142b2c = FUN_0054ef60(auStack_38);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00de2590(s_player_0211f800,s_placeName_02142d08,s_templatePlaceID_02142cf8,
               s_description_0212171c);
  if (0xf < uStack_24) {
    if (0xfff < uStack_24 + 1) {
      if (0x1f < (auStack_38[0] - *(int *)(auStack_38[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_016f3654(&LAB_0189f880);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1795 ; VA 0x00509720 ; FUN_00509720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00509720(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182378c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ddb150();
  FUN_009cb820(uVar1,s_GetAssetIdsForPackage_02142d80,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02142bb0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AssetService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(__int64),1>
       ::vftable;
  _DAT_02142be8 = FUN_00de4030;
  _DAT_02142bec = 0;
  DAT_02142bf0 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02142bd4 = FUN_008882f0();
  puVar3 = DAT_02142bf0;
  if (DAT_02142bf0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088da50();
    iStack_ec = 0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    iStack_ec = FUN_005c9e80();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(s_packageAssetId_02142d70);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189f890);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1796 ; VA 0x005098d0 ; FUN_005098d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005098d0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined *puStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018237ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  puStack_1c = &DAT_0212afd0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ddb150();
  FUN_009cb820(uVar1,s_GetCreatorAssetID_02142ce4,0,CONCAT44(puStack_1c,uStack_20),0);
  _DAT_02142a48 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::AssetService,__int64___cdecl(__int64),1>::
       vftable;
  _DAT_02142a80 = FUN_00de4f20;
  _DAT_02142a84 = 0;
  DAT_02142a88 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02142a6c = FUN_0088da50();
  puVar3 = DAT_02142a88;
  if (DAT_02142a88 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088da50();
    iStack_ec = 0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    iStack_ec = FUN_005c9e80();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(s_creationID_02142cd8);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189f8b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1797 ; VA 0x00509a80 ; FUN_00509a80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00509a80(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182384c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ddb150();
  FUN_009cb820(uVar1,s_GetBundleDetailsAsync_02142d98,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02142bf8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AssetService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(__int64),1>
       ::vftable;
  _DAT_02142c30 = FUN_00de5740;
  _DAT_02142c34 = 0;
  DAT_02142c38 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02142c1c = FUN_008881d0();
  puVar3 = DAT_02142c38;
  if (DAT_02142c38 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088da50();
    iStack_ec = 0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    iStack_ec = FUN_005c9e80();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(s_bundleId_0212b894);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189f8d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1798 ; VA 0x00509c30 ; FUN_00509c30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00509c30(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018238ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ddb150();
  FUN_009cb790(uVar1,s_GetBundleDetailsSync_02142db0,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02142c40 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AssetService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(__int64),1>
       ::vftable;
  _DAT_02142c78 = FUN_00de6090;
  _DAT_02142c7c = 0;
  DAT_02142c80 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02142c64 = FUN_008881d0();
  puVar3 = DAT_02142c80;
  if (DAT_02142c80 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088da50();
    iStack_ec = 0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    iStack_ec = FUN_005c9e80();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(s_bundleId_0212b894);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189f8f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1799 ; VA 0x00509de0 ; FUN_00509de0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00509de0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018238ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ddb150(uVar2,0);
  FUN_009cb820(uVar1,s_GetGamePlacesAsync_02142d5c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02142b70 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AssetService,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_02142ba8 = FUN_00de6210;
  _DAT_02142bac = 0;
  _DAT_02142b94 = FUN_0088cdc0();
  FUN_016f3654(&LAB_0189f910);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1800 ; VA 0x00509e80 ; FUN_00509e80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00509e80(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018238ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ddb150(uVar2,0);
  FUN_009cb820(uVar1,s_SavePlaceAsync_02142d4c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02142b30 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::AssetService,void___cdecl(void),0>::vftable;
  _DAT_02142b68 = FUN_00de9490;
  _DAT_02142b6c = 0;
  _DAT_02142b54 = FUN_00888530();
  FUN_016f3654(&LAB_0189f920);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1801 ; VA 0x00509f30 ; FUN_00509f30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00509f30(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018244d4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00debc50();
  uVar3 = FUN_00de9720();
  FUN_009ca670(uVar3,uVar2,s_FillDirection_02142fd0,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02142ea8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UIGridStyleLayout,enum_RBX::UIGridStyleLayout::FillDirection>
                 ::vftable;
  _DAT_02142edc = uVar2;
  DAT_02142ee0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02142ee0 == (undefined4 *)0x0) {
    DAT_02142ee0 = (undefined4 *)0x0;
  }
  else {
    *DAT_02142ee0 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UIGridStyleLayout,enum_RBX::UIGridStyleLayout::FillDirection>::
         GetSetImpl<enum_RBX::UIGridStyleLayout::FillDirection_(__thiscall_RBX::UIGridStyleLayout::*)(void)const_,void_(__thiscall_RBX::UIGridStyleLayout::*)(enum_RBX::UIGridStyleLayout::FillDirection)>
         ::vftable;
    DAT_02142ee0[2] = FUN_0074a340;
    DAT_02142ee0[3] = 0;
    DAT_02142ee0[4] = FUN_00deb9d0;
    DAT_02142ee0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02142ee4 = FUN_00debc50();
  cVar1 = (*(code *)DAT_02142ea8[3])();
  if (cVar1 != '\0') {
    _DAT_02142ecc = _DAT_02142ecc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02142ea8[2])();
  if (cVar1 != '\0') {
    _DAT_02142ecc = _DAT_02142ecc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189f960);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1802 ; VA 0x0050a050 ; FUN_0050a050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050a050(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018244f4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00debd00();
  uVar3 = FUN_00de9720();
  FUN_009ca670(uVar3,uVar2,s_HorizontalAlignment_02142fe0,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0
               ,1);
  uStack_8 = 0;
  DAT_02142ee8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UIGridStyleLayout,enum_RBX::UIGridStyleLayout::HorizontalAlignment>
                 ::vftable;
  _DAT_02142f1c = uVar2;
  DAT_02142f20 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02142f20 == (undefined4 *)0x0) {
    DAT_02142f20 = (undefined4 *)0x0;
  }
  else {
    *DAT_02142f20 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UIGridStyleLayout,enum_RBX::UIGridStyleLayout::HorizontalAlignment>
         ::
         GetSetImpl<enum_RBX::UIGridStyleLayout::HorizontalAlignment_(__thiscall_RBX::UIGridStyleLayout::*)(void)const_,void_(__thiscall_RBX::UIGridStyleLayout::*)(enum_RBX::UIGridStyleLayout::HorizontalAlignment)>
         ::vftable;
    DAT_02142f20[2] = FUN_008389e0;
    DAT_02142f20[3] = 0;
    DAT_02142f20[4] = FUN_00deba00;
    DAT_02142f20[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02142f24 = FUN_00debd00();
  cVar1 = (*(code *)DAT_02142ee8[3])();
  if (cVar1 != '\0') {
    _DAT_02142f0c = _DAT_02142f0c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02142ee8[2])();
  if (cVar1 != '\0') {
    _DAT_02142f0c = _DAT_02142f0c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189f980);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1803 ; VA 0x0050a170 ; FUN_0050a170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050a170(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824514;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00debe60();
  uVar3 = FUN_00de9720();
  FUN_009ca670(uVar3,uVar2,s_VerticalAlignment_02142ff4,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,1
              );
  uStack_8 = 0;
  DAT_02142f28 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UIGridStyleLayout,enum_RBX::UIGridStyleLayout::VerticalAlignment>
                 ::vftable;
  _DAT_02142f5c = uVar2;
  DAT_02142f60 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02142f60 == (undefined4 *)0x0) {
    DAT_02142f60 = (undefined4 *)0x0;
  }
  else {
    *DAT_02142f60 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UIGridStyleLayout,enum_RBX::UIGridStyleLayout::VerticalAlignment>
         ::
         GetSetImpl<enum_RBX::UIGridStyleLayout::VerticalAlignment_(__thiscall_RBX::UIGridStyleLayout::*)(void)const_,void_(__thiscall_RBX::UIGridStyleLayout::*)(enum_RBX::UIGridStyleLayout::VerticalAlignment)>
         ::vftable;
    DAT_02142f60[2] = FUN_00c0b480;
    DAT_02142f60[3] = 0;
    DAT_02142f60[4] = FUN_00debc20;
    DAT_02142f60[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02142f64 = FUN_00debe60();
  cVar1 = (*(code *)DAT_02142f28[3])();
  if (cVar1 != '\0') {
    _DAT_02142f4c = _DAT_02142f4c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02142f28[2])();
  if (cVar1 != '\0') {
    _DAT_02142f4c = _DAT_02142f4c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189f9a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1804 ; VA 0x0050a340 ; FUN_0050a340 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050a340(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182452a;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00de9720(uVar2,0);
  FUN_009cb790(uVar1,s_ApplyLayout_02142fb8,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02142e28 =
       RBX::Reflection::BoundFuncDesc<class_RBX::UIGridStyleLayout,void___cdecl(void),0>::vftable;
  _DAT_02142e60 = &LAB_00deab90;
  _DAT_02142e64 = 0;
  _DAT_02142e4c = FUN_00888530();
  FUN_016f3654(&LAB_0189f9c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1805 ; VA 0x0050a3e0 ; FUN_0050a3e0 */

void FUN_0050a3e0(void)

{
  undefined auStack_70 [32];
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined *puStack_44;
  undefined **ppuStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180de78;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  uStack_4c = (ulonglong)uStack_20;
  uStack_3c = 0;
  uStack_50 = 0;
  puStack_44 = (undefined *)0x0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  ppuStack_40 = RBX::Lua::WeakFunctionRef::vftable;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  puStack_14 = auStack_70;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00d88580(&ppuStack_40);
  FUN_00de9800(FUN_00deb960,0,s_SetCustomSortFunction_02142fa0,s_function_0211d1fc);
  puStack_44 = (undefined *)0x50a47b;
  FUN_00d88a30();
  puStack_44 = &LAB_0189f9d0;
  uStack_4c = CONCAT44(0x50a485,(undefined4)uStack_4c);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1806 ; VA 0x0050a4a0 ; FUN_0050a4a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050a4a0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182455c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00de9720();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIGridStyleLayout,class_G3D::Vector2>::
              GetImpl<class_G3D::Vector2_(__thiscall_RBX::UIGridStyleLayout::*)(void)const_>::
              vftable;
    puVar3[2] = FUN_00dea620;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d730();
  FUN_009ca670(uVar2,uVar4,s_AbsoluteContentSize_02143008,&DAT_021197d4,uStack_24,0,0,0x15,0,0,0);
  DAT_02142f68 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02142f9c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02142f8c = _DAT_02142f8c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02142f68[2])();
    if (cVar1 != '\0') {
      _DAT_02142f8c = _DAT_02142f8c & 0xfffffff3;
    }
  }
  DAT_02142f68 = RBX::Reflection::PropDescriptor<class_RBX::UIGridStyleLayout,class_G3D::Vector2>::
                 vftable;
  FUN_016f3654(&LAB_0189fa70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1807 ; VA 0x0050a5c0 ; FUN_0050a5c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050a5c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824584;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00debdb0();
  uVar3 = FUN_00de9720();
  FUN_009ca670(uVar3,uVar2,s_SortOrder_02142fc4,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02142e68 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UIGridStyleLayout,enum_RBX::UIGridStyleLayout::SortOrder>
                 ::vftable;
  _DAT_02142e9c = uVar2;
  DAT_02142ea0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02142ea0 == (undefined4 *)0x0) {
    DAT_02142ea0 = (undefined4 *)0x0;
  }
  else {
    *DAT_02142ea0 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UIGridStyleLayout,enum_RBX::UIGridStyleLayout::SortOrder>::
         GetSetImpl<enum_RBX::UIGridStyleLayout::SortOrder_(__thiscall_RBX::UIGridStyleLayout::*)(void)const_,void_(__thiscall_RBX::UIGridStyleLayout::*)(enum_RBX::UIGridStyleLayout::SortOrder)>
         ::vftable;
    DAT_02142ea0[2] = &LAB_00c777c0;
    DAT_02142ea0[3] = 0;
    DAT_02142ea0[4] = FUN_00deba30;
    DAT_02142ea0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02142ea4 = FUN_00debdb0();
  cVar1 = (*(code *)DAT_02142e68[3])();
  if (cVar1 != '\0') {
    _DAT_02142e8c = _DAT_02142e8c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02142e68[2])();
  if (cVar1 != '\0') {
    _DAT_02142e8c = _DAT_02142e8c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189fa90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1808 ; VA 0x0050a8b0 ; FUN_0050a8b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050a8b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018247fc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dec2d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIGridLayout,int>::
              GetSetImpl<int_(__thiscall_RBX::UIGridLayout::*)(void)const_,void_(__thiscall_RBX::UIGridLayout::*)(int)>
              ::vftable;
    puVar3[2] = &LAB_0074b4e0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00decfe0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_FillDirectionMaxCells_02143178,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0
               ,0,0);
  DAT_02143020 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02143054 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02143044 = _DAT_02143044 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02143020[2])();
    if (cVar1 != '\0') {
      _DAT_02143044 = _DAT_02143044 & 0xfffffff3;
    }
  }
  DAT_02143020 = RBX::Reflection::PropDescriptor<class_RBX::UIGridLayout,int>::vftable;
  FUN_016f3654(&LAB_0189fb60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1809 ; VA 0x0050a9e0 ; FUN_0050a9e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050a9e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824824;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ded0d0();
  uVar3 = FUN_00dec2d0();
  FUN_009ca670(uVar3,uVar2,s_StartCorner_021431a8,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_021430c8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UIGridLayout,enum_RBX::UIGridLayout::StartCorner>::
                 vftable;
  _DAT_021430fc = uVar2;
  DAT_02143100 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02143100 == (undefined4 *)0x0) {
    DAT_02143100 = (undefined4 *)0x0;
  }
  else {
    *DAT_02143100 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UIGridLayout,enum_RBX::UIGridLayout::StartCorner>::
         GetSetImpl<enum_RBX::UIGridLayout::StartCorner_(__thiscall_RBX::UIGridLayout::*)(void)const_,void_(__thiscall_RBX::UIGridLayout::*)(enum_RBX::UIGridLayout::StartCorner)>
         ::vftable;
    DAT_02143100[2] = FUN_00c347d0;
    DAT_02143100[3] = 0;
    DAT_02143100[4] = FUN_00ded050;
    DAT_02143100[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02143104 = FUN_00ded0d0();
  cVar1 = (*(code *)DAT_021430c8[3])();
  if (cVar1 != '\0') {
    _DAT_021430ec = _DAT_021430ec & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021430c8[2])();
  if (cVar1 != '\0') {
    _DAT_021430ec = _DAT_021430ec & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189fb80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1810 ; VA 0x0050ac30 ; FUN_0050ac30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050ac30(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824944;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dee020();
  uVar3 = FUN_00ded2f0();
  FUN_009ca670(uVar3,uVar2,s_MajorAxis_021432fc,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02143288 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UITableLayout,enum_RBX::UITableLayout::TableMajorAxis>
                 ::vftable;
  _DAT_021432bc = uVar2;
  DAT_021432c0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021432c0 == (undefined4 *)0x0) {
    DAT_021432c0 = (undefined4 *)0x0;
  }
  else {
    *DAT_021432c0 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UITableLayout,enum_RBX::UITableLayout::TableMajorAxis>::
         GetSetImpl<enum_RBX::UITableLayout::TableMajorAxis_(__thiscall_RBX::UITableLayout::*)(void)const_,void_(__thiscall_RBX::UITableLayout::*)(enum_RBX::UITableLayout::TableMajorAxis)>
         ::vftable;
    DAT_021432c0[2] = &LAB_00685250;
    DAT_021432c0[3] = 0;
    DAT_021432c0[4] = FUN_00dedf20;
    DAT_021432c0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021432c4 = FUN_00dee020();
  cVar1 = (*(code *)DAT_02143288[3])();
  if (cVar1 != '\0') {
    _DAT_021432ac = _DAT_021432ac & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02143288[2])();
  if (cVar1 != '\0') {
    _DAT_021432ac = _DAT_021432ac & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189fc60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1811 ; VA 0x0050ad50 ; FUN_0050ad50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050ad50(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182496c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ded2f0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UITableLayout,class_RBX::UDim2>::
              GetSetImpl<class_RBX::UDim2_(__thiscall_RBX::UITableLayout::*)(void)const_,void_(__thiscall_RBX::UITableLayout::*)(class_RBX::UDim2)>
              ::vftable;
    puVar3[2] = FUN_00dedcb0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00dedf50;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d5f0();
  FUN_009ca670(uVar2,uVar4,s_Padding_021432c8,s_Appearance_02119800,uStack_24,0,0,0x1f,0,0,0);
  DAT_021431e0 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::UDim2>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02143214 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02143204 = _DAT_02143204 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021431e0[2])();
    if (cVar1 != '\0') {
      _DAT_02143204 = _DAT_02143204 & 0xfffffff3;
    }
  }
  DAT_021431e0 = RBX::Reflection::PropDescriptor<class_RBX::UITableLayout,class_RBX::UDim2>::vftable
  ;
  FUN_016f3654(&LAB_0189fc80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1812 ; VA 0x0050aed0 ; FUN_0050aed0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050aed0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824a5c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00dee150();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UIAspectRatioConstraint,float>::
              GetSetImpl<float_(__thiscall_RBX::UIAspectRatioConstraint::*)(void)const_,void_(__thiscall_RBX::UIAspectRatioConstraint::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00927190;
    puVar3[3] = 0;
    puVar3[4] = FUN_00deec60;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_AspectRatio_021433c0,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,0);
  DAT_02143308 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214333c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214332c = _DAT_0214332c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02143308[2])();
    if (cVar1 != '\0') {
      _DAT_0214332c = _DAT_0214332c & 0xfffffff3;
    }
  }
  DAT_02143308 = RBX::Reflection::PropDescriptor<class_RBX::UIAspectRatioConstraint,float>::vftable;
  FUN_016f3654(&LAB_0189fd40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1813 ; VA 0x0050b000 ; FUN_0050b000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b000(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824a84;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00deedd0();
  uVar3 = FUN_00dee150();
  FUN_009ca670(uVar3,uVar2,s_AspectType_021433cc,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02143340 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UIAspectRatioConstraint,enum_RBX::UIAspectRatioConstraint::AspectType>
                 ::vftable;
  _DAT_02143374 = uVar2;
  DAT_02143378 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02143378 == (undefined4 *)0x0) {
    DAT_02143378 = (undefined4 *)0x0;
  }
  else {
    *DAT_02143378 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UIAspectRatioConstraint,enum_RBX::UIAspectRatioConstraint::AspectType>
         ::
         GetSetImpl<enum_RBX::UIAspectRatioConstraint::AspectType_(__thiscall_RBX::UIAspectRatioConstraint::*)(void)const_,void_(__thiscall_RBX::UIAspectRatioConstraint::*)(enum_RBX::UIAspectRatioConstraint::AspectType)>
         ::vftable;
    DAT_02143378[2] = FUN_00819220;
    DAT_02143378[3] = 0;
    DAT_02143378[4] = FUN_00deecd0;
    DAT_02143378[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214337c = FUN_00deedd0();
  cVar1 = (*(code *)DAT_02143340[3])();
  if (cVar1 != '\0') {
    _DAT_02143364 = _DAT_02143364 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02143340[2])();
  if (cVar1 != '\0') {
    _DAT_02143364 = _DAT_02143364 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189fd60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1814 ; VA 0x0050b120 ; FUN_0050b120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b120(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824aa4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00deee80();
  uVar3 = FUN_00dee150();
  FUN_009ca670(uVar3,uVar2,s_DominantAxis_021433d8,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02143380 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UIAspectRatioConstraint,enum_RBX::UIAspectRatioConstraint::DominantAxis>
                 ::vftable;
  _DAT_021433b4 = uVar2;
  DAT_021433b8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021433b8 == (undefined4 *)0x0) {
    DAT_021433b8 = (undefined4 *)0x0;
  }
  else {
    *DAT_021433b8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UIAspectRatioConstraint,enum_RBX::UIAspectRatioConstraint::DominantAxis>
         ::
         GetSetImpl<enum_RBX::UIAspectRatioConstraint::DominantAxis_(__thiscall_RBX::UIAspectRatioConstraint::*)(void)const_,void_(__thiscall_RBX::UIAspectRatioConstraint::*)(enum_RBX::UIAspectRatioConstraint::DominantAxis)>
         ::vftable;
    DAT_021433b8[2] = FUN_008609e0;
    DAT_021433b8[3] = 0;
    DAT_021433b8[4] = FUN_00deed00;
    DAT_021433b8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021433bc = FUN_00deee80();
  cVar1 = (*(code *)DAT_02143380[3])();
  if (cVar1 != '\0') {
    _DAT_021433a4 = _DAT_021433a4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02143380[2])();
  if (cVar1 != '\0') {
    _DAT_021433a4 = _DAT_021433a4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0189fd80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1815 ; VA 0x0050b2e0 ; FUN_0050b2e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b2e0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01824cf3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00def1c0();
  FUN_009cb970(uVar1,s_Blocked_021437c4,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021436d8 = FUN_00df1d20;
  _DAT_021436dc = 0;
  iStack_8 = 0;
  _DAT_021436a0 =
       RBX::Reflection::
       EventDesc<class_RBX::Path,void___cdecl(int),class_rbx::signal<void___cdecl(int)>,class_rbx::signal<void___cdecl(int)>*_(__thiscall_RBX::Path::*)(bool)>
       ::vftable;
  FUN_0086e3d0(s_blockedWaypointIdx_021437b0);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021436c8 = uStack_1c;
  _DAT_021436cc = uStack_18;
  _DAT_021436d0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_021436a0 =
       RBX::Reflection::
       EventDesc<class_RBX::Path,void___cdecl(int),class_rbx::signal<void___cdecl(int)>,class_rbx::signal<void___cdecl(int)>*_(__thiscall_RBX::Path::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_0189fe00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1816 ; VA 0x0050b440 ; FUN_0050b440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b440(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824d4c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00def1c0();
  FUN_009cb820(uVar1,s_CheckOcclusionAsync_0214379c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02143658 = RBX::Reflection::BoundYieldFuncDesc<class_RBX::Path,int___cdecl(int),1>::vftable;
  _DAT_02143690 = FUN_00df04b0;
  _DAT_02143694 = 0;
  DAT_02143698 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214367c = FUN_0088c8c0();
  puVar3 = DAT_02143698;
  if (DAT_02143698 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c8c0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005c9cc0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(s_start_02143704);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0189fe10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1817 ; VA 0x0050b5e0 ; FUN_0050b5e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b5e0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824d88;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02143430;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00def2a0(uVar2,&DAT_02143430);
  FUN_009cb820(uVar1,s_ComputeRawPathAsync_02143734,0,CONCAT44(puVar3,uVar2),0);
  _DAT_021434b0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::PathfindingService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_G3D::Vector3,class_G3D::Vector3,float),3>
       ::vftable;
  _DAT_021434e8 = FUN_00df0960;
  _DAT_021434ec = 0;
  DAT_021434f0 = 0;
  DAT_021434f4 = 0;
  DAT_021434f8 = 0;
  uStack_8 = 3;
  FUN_00df1250(s_start_02143704,s_finish_021436fc,s_maxDistance_02143728);
  FUN_016f3654(&LAB_0189fe30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1818 ; VA 0x0050b6b0 ; FUN_0050b6b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b6b0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824dc8;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02143430;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00def2a0(uVar2,&DAT_02143430);
  FUN_009cb820(uVar1,s_ComputeSmoothPathAsync_02143748,0,CONCAT44(puVar3,uVar2),0);
  _DAT_02143500 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::PathfindingService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_G3D::Vector3,class_G3D::Vector3,float),3>
       ::vftable;
  _DAT_02143538 = FUN_00df0960;
  _DAT_0214353c = 0;
  DAT_02143540 = 0;
  DAT_02143544 = 0;
  DAT_02143548 = 0;
  uStack_8 = 3;
  FUN_00df1250(s_start_02143704,s_finish_021436fc,s_maxDistance_02143728);
  FUN_016f3654(&LAB_0189fe80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1819 ; VA 0x0050b780 ; FUN_0050b780 */

void FUN_0050b780(void)

{
  uint in_stack_ffffffe4;
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa178;
  pvStack_10 = ExceptionList;
  uVar1 = in_stack_ffffffe4 & 0xffffff00;
  uStack_8 = 0;
  uVar2 = 0;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  FUN_00def990(FUN_00df0d80,0,s_CreatePath_021436f0,s_agentParameters_021436e0,0,0,0,uVar1,0);
  FUN_016f3654(&LAB_0189fed0,uVar1,uVar2,uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1820 ; VA 0x0050b820 ; FUN_0050b820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b820(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824dfe;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00def2a0(uVar2,0);
  FUN_009cb820(uVar1,s_FindPathAsync_0214370c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02143430 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::PathfindingService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_G3D::Vector3,class_G3D::Vector3),2>
       ::vftable;
  _DAT_02143468 = FUN_00df1a00;
  _DAT_0214346c = 0;
  DAT_02143470 = 0;
  DAT_02143474 = 0;
  uStack_8 = 2;
  FUN_00df1070();
  FUN_016f3654(&LAB_0189ff20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1821 ; VA 0x0050b8e0 ; FUN_0050b8e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b8e0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824e1a;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02143590;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00def1c0(uVar2,&DAT_02143590);
  FUN_009cb790(uVar1,s_GetPointCoordinates_02143778,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021435d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Path,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02143608 = FUN_00df1d30;
  _DAT_0214360c = 0;
  _DAT_021435f4 = FUN_008882f0();
  FUN_016f3654(&LAB_0189ff60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1822 ; VA 0x0050b980 ; FUN_0050b980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050b980(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824e3a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00def1c0(uVar2,0);
  FUN_009cb790(uVar1,s_GetWaypoints_02143768,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02143590 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Path,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_021435c8 = FUN_00df1dc0;
  _DAT_021435cc = 0;
  _DAT_021435b4 = FUN_008882f0();
  FUN_016f3654(&LAB_0189ff70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1823 ; VA 0x0050ba20 ; FUN_0050ba20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050ba20(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824e6e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00def1c0(uVar2,0);
  FUN_009cb820(uVar1,s_ComputeAsync_0214378c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02143610 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Path,void___cdecl(class_G3D::Vector3,class_G3D::Vector3),2>::
       vftable;
  _DAT_02143648 = FUN_00df05e0;
  _DAT_0214364c = 0;
  DAT_02143650 = 0;
  DAT_02143654 = 0;
  uStack_8 = 2;
  FUN_00df0e90();
  FUN_016f3654(&LAB_0189ff80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1824 ; VA 0x0050bc20 ; FUN_0050bc20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050bc20(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01824ec4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00df22f0();
  uVar3 = FUN_00def1c0();
  FUN_009ca670(uVar3,uVar2,s_Status_02143760,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02143550 = RBX::Reflection::EnumPropDescriptor<class_RBX::Path,enum_RBX::Path::PathStatus>::
                 vftable;
  _DAT_02143584 = uVar2;
  DAT_02143588 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_02143588 == (undefined4 *)0x0) {
    DAT_02143588 = (undefined4 *)0x0;
  }
  else {
    *DAT_02143588 =
         RBX::Reflection::PropDescriptor<class_RBX::Path,enum_RBX::Path::PathStatus>::
         GetImpl<enum_RBX::Path::PathStatus_(__thiscall_RBX::Path::*)(void)const_>::vftable;
    DAT_02143588[2] = &LAB_00df1d50;
    DAT_02143588[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0214358c = FUN_00df22f0();
  cVar1 = (*(code *)DAT_02143550[3])();
  if (cVar1 != '\0') {
    _DAT_02143574 = _DAT_02143574 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02143550[2])();
  if (cVar1 != '\0') {
    _DAT_02143574 = _DAT_02143574 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a0000);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1825 ; VA 0x0050be00 ; FUN_0050be00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050be00(void)

{
  undefined4 uVar1;
  undefined auStack_38c [864];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01825714;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90();
  FUN_009cb970(uVar1,s_BoundActionAdded_02144210,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02143e64 = 100;
  iStack_8 = 0;
  _DAT_02143e30 =
       RBX::Reflection::
       EventDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,bool),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_...ator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,bool)>_RBX::ContextActionService::*>
       ::vftable;
  FUN_0086e3d0(s_actionAdded_02144204);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_createTouchButton_02143fdc);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_functionInfoTable_021441f0);
  FUN_008881d0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(s_isCore_021441e8);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_38c,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  _DAT_02143e58 = uStack_1c;
  _DAT_02143e5c = uStack_18;
  _DAT_02143e60 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 6;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_38c,0xd8,4,FUN_00688b10);
  _DAT_02143e30 =
       RBX::Reflection::
       EventDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,bool),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_...ator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,bool)>_RBX::ContextActionService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a00b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1826 ; VA 0x0050bfc0 ; FUN_0050bfc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050bfc0(void)

{
  undefined4 uVar1;
  undefined auStack_2b4 [648];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01825759;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90();
  FUN_009cb970(uVar1,s_BoundActionChanged_021441d4,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02143e2c = 0x60;
  iStack_8 = 0;
  _DAT_02143df8 =
       RBX::Reflection::
       EventDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::all...allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::ContextActionService::*>
       ::vftable;
  FUN_0086e3d0(s_actionChanged_021441c4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_changeName_021441b8);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_changeTable_021441ac);
  FUN_008881d0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b4,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02143e20 = uStack_1c;
  _DAT_02143e24 = uStack_18;
  _DAT_02143e28 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b4,0xd8,3,FUN_00688b10);
  _DAT_02143df8 =
       RBX::Reflection::
       EventDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::all...allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::ContextActionService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a00c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1827 ; VA 0x0050c160 ; FUN_0050c160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050c160(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01825793;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90();
  FUN_009cb970(uVar1,s_GetActionButtonEvent_02144248,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02143ed4 = 0x6c;
  iStack_8 = 0;
  _DAT_02143ea0 =
       RBX::Reflection::
       EventDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::ContextActionService::*>
       ::vftable;
  FUN_0086e3d0(s_actionName_02144000);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02143ec8 = uStack_1c;
  _DAT_02143ecc = uStack_18;
  _DAT_02143ed0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02143ea0 =
       RBX::Reflection::
       EventDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::ContextActionService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a00d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1828 ; VA 0x0050c2b0 ; FUN_0050c2b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050c2b0(void)

{
  undefined4 uVar1;
  undefined auStack_2b4 [648];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_018257d9;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90();
  FUN_009cb970(uVar1,s_BoundActionRemoved_02144234,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02143e9c = 0x68;
  iStack_8 = 0;
  _DAT_02143e68 =
       RBX::Reflection::
       EventDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,bool),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RB...ator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,bool)>_RBX::ContextActionService::*>
       ::vftable;
  FUN_0086e3d0(s_actionRemoved_02144224);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_functionInfoTable_021441f0);
  FUN_008881d0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_isCore_021441e8);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b4,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02143e90 = uStack_1c;
  _DAT_02143e94 = uStack_18;
  _DAT_02143e98 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b4,0xd8,3,FUN_00688b10);
  _DAT_02143e68 =
       RBX::Reflection::
       EventDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,bool),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RB...ator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,bool)>_RBX::ContextActionService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a00e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1829 ; VA 0x0050c450 ; FUN_0050c450 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050c450(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182580e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_SetDescription_021440e4,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02143af8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_02143b30 = FUN_00dfdfd0;
  _DAT_02143b34 = 0;
  _DAT_02143b38 = 0;
  _DAT_02143b3c = 0;
  uStack_8 = 2;
  FUN_00921260();
  FUN_016f3654(&LAB_018a00f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1830 ; VA 0x0050c510 ; FUN_0050c510 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050c510(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182583e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_SetImage_021440fc,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02143b40 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_02143b78 = FUN_00dfe130;
  _DAT_02143b7c = 0;
  _DAT_02143b80 = 0;
  _DAT_02143b84 = 0;
  uStack_8 = 2;
  FUN_00921260();
  FUN_016f3654(&LAB_018a0110);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1831 ; VA 0x0050c5d0 ; FUN_0050c5d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050c5d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182586e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_SetTitle_021440d8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02143ab0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_02143ae8 = FUN_00dfe3b0;
  _DAT_02143aec = 0;
  _DAT_02143af0 = 0;
  _DAT_02143af4 = 0;
  uStack_8 = 2;
  FUN_00921260();
  FUN_016f3654(&LAB_018a0130);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1832 ; VA 0x0050c690 ; FUN_0050c690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050c690(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018258b2;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_BindAction_02144048,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02143928 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Lua::WeakFunctionRef,bool,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),4>
       ::vftable;
  _DAT_02143960 = FUN_00df6210;
  _DAT_02143964 = 0;
  _DAT_02143968 = 0;
  _DAT_0214396c = 0;
  _DAT_02143970 = 0;
  _DAT_02143974 = 0;
  uStack_8 = 4;
  FUN_00df9870(s_actionName_02144000,s_functionToBind_02143ff0,s_createTouchButton_02143fdc,
               s_inputTypes_02143fd0);
  FUN_016f3654(&LAB_018a0150);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1833 ; VA 0x0050c770 ; FUN_0050c770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050c770(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182590c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00df2a90();
  FUN_009cb820(uVar2,s_GetButton_02142100,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02143bd0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::ContextActionService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_02143c08 = FUN_00dfcd30;
  _DAT_02143c0c = 0;
  DAT_02143c10 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02143bf4 = FUN_0088cdc0();
  iVar1 = DAT_02143c10;
  if (DAT_02143c10 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_actionName_02144000);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a0160);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1834 ; VA 0x0050c920 ; FUN_0050c920 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050c920(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182593e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_SetPosition_02144108,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02143b88 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::UDim2),2>
       ::vftable;
  _DAT_02143bc0 = FUN_00dfe290;
  _DAT_02143bc4 = 0;
  _DAT_02143bc8 = 0;
  DAT_02143bcc = 0;
  uStack_8 = 2;
  FUN_00df9180();
  FUN_016f3654(&LAB_018a0180);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1835 ; VA 0x0050c9e0 ; FUN_0050c9e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050c9e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182596e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_FireActionButtonFoundSignal_02144270,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02143ed8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_02143f10 = FUN_00dfbd50;
  _DAT_02143f14 = 0;
  _DAT_02143f18 = 0;
  DAT_02143f1c = 0;
  uStack_8 = 2;
  FUN_00df8f70();
  FUN_016f3654(&LAB_018a01b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1836 ; VA 0x0050caa0 ; FUN_0050caa0 */

void FUN_0050caa0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00df3ad0(FUN_00df6f80,0,s_BindActivate_021440b8,s_userInputTypeForActivation_0214409c,
               s_keyCodeForActivation_02144084,0,0,uStack_10,0);
  FUN_016f3654(&LAB_018a0210);
  return;
}



/* FUNCTION 1837 ; VA 0x0050cb10 ; FUN_0050cb10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050cb10(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018259bc;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_BindActionAtPriority_0214406c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021439c8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Lua::WeakFunctionRef,bool,int,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),5>
       ::vftable;
  _DAT_02143a00 = FUN_00df60f0;
  _DAT_02143a04 = 0;
  _DAT_02143a08 = 0;
  _DAT_02143a0c = 0;
  _DAT_02143a10 = 0;
  _DAT_02143a14 = 0;
  _DAT_02143a18 = 0;
  uStack_8 = 5;
  FUN_00df93b0(s_actionName_02144000,s_functionToBind_02143ff0,s_createTouchButton_02143fdc,
               s_priorityLevel_0214401c,s_inputTypes_02143fd0);
  FUN_016f3654(&LAB_018a0250);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1838 ; VA 0x0050cc00 ; FUN_0050cc00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050cc00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01825a02;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_BindCoreAction_0214400c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02143880 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Lua::WeakFunctionRef,bool,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),4>
       ::vftable;
  _DAT_021438b8 = FUN_00df73a0;
  _DAT_021438bc = 0;
  _DAT_021438c0 = 0;
  _DAT_021438c4 = 0;
  _DAT_021438c8 = 0;
  _DAT_021438cc = 0;
  uStack_8 = 4;
  FUN_00df9870(s_actionName_02144000,s_functionToBind_02143ff0,s_createTouchButton_02143fdc,
               s_inputTypes_02143fd0);
  FUN_016f3654(&LAB_018a0260);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1839 ; VA 0x0050cce0 ; FUN_0050cce0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050cce0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01825a4c;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_BindCoreActionAtPriority_0214402c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021438d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Lua::WeakFunctionRef,bool,int,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),5>
       ::vftable;
  _DAT_02143908 = FUN_00df7280;
  _DAT_0214390c = 0;
  _DAT_02143910 = 0;
  _DAT_02143914 = 0;
  _DAT_02143918 = 0;
  _DAT_0214391c = 0;
  _DAT_02143920 = 0;
  uStack_8 = 5;
  FUN_00df93b0(s_actionName_02144000,s_functionToBind_02143ff0,s_createTouchButton_02143fdc,
               s_priorityLevel_0214401c,s_inputTypes_02143fd0);
  FUN_016f3654(&LAB_018a0270);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1840 ; VA 0x0050cdd0 ; FUN_0050cdd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050cdd0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01825a92;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02143928;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,&DAT_02143928);
  FUN_009cb790(uVar1,s_BindActionToInputTypes_02144054,0,CONCAT44(puVar3,uVar2),0);
  _DAT_02143978 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Lua::WeakFunctionRef,bool,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),4>
       ::vftable;
  _DAT_021439b0 = FUN_00df6210;
  _DAT_021439b4 = 0;
  _DAT_021439b8 = 0;
  _DAT_021439bc = 0;
  _DAT_021439c0 = 0;
  _DAT_021439c4 = 0;
  uStack_8 = 4;
  FUN_00df9870(s_actionName_02144000,s_functionToBind_02143ff0,s_createTouchButton_02143fdc,
               s_inputTypes_02143fd0);
  FUN_016f3654(&LAB_018a0280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1841 ; VA 0x0050ceb0 ; FUN_0050ceb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050ceb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01825ac8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_CallFunction_0214428c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02143f20 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::InputObject::UserInputState,class_std::shared_ptr<class_RBX::Instance>),3>
       ::vftable;
  _DAT_02143f58 = FUN_00df7670;
  _DAT_02143f5c = 0;
  _DAT_02143f60 = 0;
  _DAT_02143f64 = 0;
  _DAT_02143f68 = 0;
  uStack_8 = 3;
  FUN_00df8c70(s_actionName_02144000,s_state_02123f08,s_inputObject_0213947c);
  FUN_016f3654(&LAB_018a0290);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1842 ; VA 0x0050cfb0 ; FUN_0050cfb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050cfb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01825aea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_GetAllBoundCoreActionInfo_02144190,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02143db8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02143df0 = FUN_00dfc780;
  _DAT_02143df4 = 0;
  _DAT_02143ddc = FUN_008881d0();
  FUN_016f3654(&LAB_018a02a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1843 ; VA 0x0050d050 ; FUN_0050d050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050d050(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01825b0a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_GetAllBoundActionInfo_02144160,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02143d30 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02143d68 = FUN_00dfc510;
  _DAT_02143d6c = 0;
  _DAT_02143d54 = FUN_008881d0();
  FUN_016f3654(&LAB_018a02b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1844 ; VA 0x0050d0f0 ; FUN_0050d0f0 */

void FUN_0050d0f0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00df37d0(FUN_00dfcb90,0,s_GetBoundCoreActionInfo_02144178,s_actionName_02144000,5,uStack_10,0)
  ;
  FUN_016f3654(&LAB_018a02c0);
  return;
}



/* FUNCTION 1845 ; VA 0x0050d150 ; FUN_0050d150 */

void FUN_0050d150(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00df37d0(FUN_00dfc9f0,0,s_GetBoundActionInfo_0214414c,s_actionName_02144000,0,uStack_10,0);
  FUN_016f3654(&LAB_018a02e0);
  return;
}



/* FUNCTION 1846 ; VA 0x0050d1b0 ; FUN_0050d1b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050d1b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01825b2a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_GetCurrentLocalToolIcon_02143f70,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021437d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContextActionService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_02143808 = FUN_00dfcef0;
  _DAT_0214380c = 0;
  _DAT_021437f4 = FUN_0088cb40();
  FUN_016f3654(&LAB_018a0300);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1847 ; VA 0x0050d250 ; FUN_0050d250 */

void FUN_0050d250(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00df3950(FUN_00dff610,0,s_UnbindAction_02144128,s_actionName_02144000,0,uStack_10,0);
  FUN_016f3654(&LAB_018a0310);
  return;
}



/* FUNCTION 1848 ; VA 0x0050d2b0 ; FUN_0050d2b0 */

void FUN_0050d2b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00df3ad0(FUN_00dff9c0,0,s_UnbindActivate_021440c8,s_userInputTypeForActivation_0214409c,
               s_keyCodeForActivation_02144084,0,0,uStack_10,0);
  FUN_016f3654(&LAB_018a0330);
  return;
}



/* FUNCTION 1849 ; VA 0x0050d320 ; FUN_0050d320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050d320(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01825b4a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00df2a90(uVar2,0);
  FUN_009cb790(uVar1,s_UnbindAllActions_02144138,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02143ca8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ContextActionService,void___cdecl(void),0>::vftable
  ;
  _DAT_02143ce0 = FUN_00dffb90;
  _DAT_02143ce4 = 0;
  _DAT_02143ccc = FUN_00888530();
  FUN_016f3654(&LAB_018a0370);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1850 ; VA 0x0050d3c0 ; FUN_0050d3c0 */

void FUN_0050d3c0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00df3950(FUN_00dffdf0,0,s_UnbindCoreAction_02144114,s_actionName_02144000,5,uStack_10,0);
  FUN_016f3654(&LAB_018a0380);
  return;
}



/* FUNCTION 1851 ; VA 0x0050d5f0 ; FUN_0050d5f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050d5f0(void)

{
  undefined4 uVar1;
  undefined auStack_2b4 [648];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01826ee9;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e03740();
  FUN_009cb970(uVar1,s_Roblox17sConnectionChanged_02144748,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021444a4 = 100;
  iStack_8 = 0;
  _DAT_02144470 =
       RBX::Reflection::
       EventDesc<class_RBX::NotificationService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::NotificationService::*>
       ::vftable;
  FUN_0086e3d0(s_connectionName_02144720);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_connectionState_02144710);
  FUN_00e06c10();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_namespaceSequenceNumbers_021446e4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b4,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02144498 = uStack_1c;
  _DAT_0214449c = uStack_18;
  _DAT_021444a0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b4,0xd8,3,FUN_00688b10);
  _DAT_02144470 =
       RBX::Reflection::
       EventDesc<class_RBX::NotificationService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::NotificationService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a04d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1852 ; VA 0x0050d7c0 ; FUN_0050d7c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050d7c0(void)

{
  undefined4 uVar1;
  undefined auStack_38c [864];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01826f44;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e03740();
  FUN_009cb970(uVar1,s_RobloxConnectionChanged_02144730,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0214446c = 0x5c;
  iStack_8 = 0;
  _DAT_02144438 =
       RBX::Reflection::
       EventDesc<class_RBX::NotificationService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::NotificationService::*>
       ::vftable;
  FUN_0086e3d0(s_connectionName_02144720);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_connectionState_02144710);
  FUN_00e06c10();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_sequenceNumber_02144700);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(s_namespaceSequenceNumbers_021446e4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_38c,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  _DAT_02144460 = uStack_1c;
  _DAT_02144464 = uStack_18;
  _DAT_02144468 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 6;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_38c,0xd8,4,FUN_00688b10);
  _DAT_02144438 =
       RBX::Reflection::
       EventDesc<class_RBX::NotificationService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::NotificationServiceConnection::ConnectionState,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::NotificationService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a04f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1853 ; VA 0x0050d9b0 ; FUN_0050d9b0 */

void FUN_0050d9b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e042d0(FUN_00e04d10,0,s_ActionEnabled_02144764,s_actionType_021372d8,5,uStack_10,0);
  FUN_016f3654(&LAB_018a0510);
  return;
}



/* FUNCTION 1854 ; VA 0x0050da10 ; FUN_0050da10 */

void FUN_0050da10(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e042d0(FUN_00e04d50,0,s_ActionTaken_02144774,s_actionType_021372d8,5,uStack_10,0);
  FUN_016f3654(&LAB_018a0530);
  return;
}



/* FUNCTION 1855 ; VA 0x0050da70 ; FUN_0050da70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050da70(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01826f9c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e03740();
  FUN_009cb790(uVar1,s_CancelAllNotification_02144678,3,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02144338 =
       RBX::Reflection::BoundFuncDesc<class_RBX::NotificationService,void___cdecl(__int64),1>::
       vftable;
  _DAT_02144370 = &LAB_00e05c00;
  _DAT_02144374 = 0;
  DAT_02144378 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214435c = FUN_00888530();
  if (DAT_02144378 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1470(DAT_02144378);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(s_userId_0211fb64);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a0550);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1856 ; VA 0x0050dbf0 ; FUN_0050dbf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050dbf0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01826fce;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e03740(uVar2,0);
  FUN_009cb790(uVar1,s_CancelNotification_02144664,3,CONCAT44(uVar3,uVar2),0);
  _DAT_021442f0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::NotificationService,void___cdecl(__int64,int),2>::
       vftable;
  _DAT_02144328 = &LAB_00e05bf0;
  _DAT_0214432c = 0;
  DAT_02144330 = 0;
  DAT_02144334 = 0;
  uStack_8 = 2;
  FUN_00e055f0();
  FUN_016f3654(&LAB_018a0570);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1857 ; VA 0x0050dcb0 ; FUN_0050dcb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050dcb0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182702c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e03740();
  FUN_009cb820(uVar1,s_GetScheduledNotifications_02144690,3,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02144380 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::NotificationService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(__int64),1>
       ::vftable;
  _DAT_021443b8 = FUN_00e05c10;
  _DAT_021443bc = 0;
  DAT_021443c0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021443a4 = FUN_008882f0();
  if (DAT_021443c0 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1470(DAT_021443c0);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(s_userId_0211fb64);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a05b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1858 ; VA 0x0050de30 ; FUN_0050de30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050de30(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827072;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e03740(uVar2,0);
  FUN_009cb790(uVar1,s_ScheduleNotification_0214464c,3,CONCAT44(uVar3,uVar2),0);
  _DAT_021442a0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::NotificationService,void___cdecl(__int64,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),4>
       ::vftable;
  _DAT_021442d8 = FUN_00e05b80;
  _DAT_021442dc = 0;
  DAT_021442e0 = 0;
  DAT_021442e4 = 0;
  _DAT_021442e8 = 0;
  DAT_021442ec = 0;
  uStack_8 = 4;
  FUN_00e057d0(s_userId_0211fb64,s_alertId_02144644,s_alertMsg_02144638,s_minutesToFire_02144628);
  FUN_016f3654(&LAB_018a05d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1859 ; VA 0x0050df10 ; FUN_0050df10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050df10(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018270cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e03740();
  FUN_009cb790(uVar1,s_SwitchedToAppShellFeature_02144790,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02144538 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::NotificationService,void___cdecl(enum_RBX::AppShellFeature),1>::
       vftable;
  _DAT_02144570 = FUN_00e06e10;
  _DAT_02144574 = 0;
  DAT_02144578 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214455c = FUN_00888530();
  puVar3 = DAT_02144578;
  if (DAT_02144578 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00e06b60();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00e06d30();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_00e06b60();
  uVar2 = FUN_0086e3d0(s_appShellFeature_02144780);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a0620);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1860 ; VA 0x0050e150 ; FUN_0050e150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050e150(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018270fc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e03740();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::NotificationService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::NotificationService::*)(void)const_,void_(__thiscall_RBX::NotificationService::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&)>
              ::vftable;
    puVar3[2] = FUN_00dd7220;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e06a60;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_SelectedTheme_021447d8,s_Behavior_0211a8f8,uStack_24,0,0,0x15,5,5,0);
  DAT_021445f0 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02144624 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02144614 = _DAT_02144614 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021445f0[2])();
    if (cVar1 != '\0') {
      _DAT_02144614 = _DAT_02144614 & 0xfffffff3;
    }
  }
  DAT_021445f0 = RBX::Reflection::
                 PropDescriptor<class_RBX::NotificationService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_018a06e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1861 ; VA 0x0050e2a0 ; FUN_0050e2a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050e2a0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827624;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e08e70();
  uVar3 = FUN_00e071d0();
  FUN_009ca670(uVar3,uVar2,s_PlaybackState_0214499c,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_021448a8 = RBX::Reflection::EnumPropDescriptor<class_RBX::TweenBase,enum_RBX::PlaybackState>::
                 vftable;
  _DAT_021448dc = uVar2;
  DAT_021448e0 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_021448e0 == (undefined4 *)0x0) {
    DAT_021448e0 = (undefined4 *)0x0;
  }
  else {
    *DAT_021448e0 =
         RBX::Reflection::PropDescriptor<class_RBX::TweenBase,enum_RBX::PlaybackState>::
         GetImpl<enum_RBX::PlaybackState_(__thiscall_RBX::TweenBase::*)(void)const_>::vftable;
    DAT_021448e0[2] = &LAB_008b4220;
    DAT_021448e0[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021448e4 = FUN_00e08e70();
  cVar1 = (*(code *)DAT_021448a8[3])();
  if (cVar1 != '\0') {
    _DAT_021448cc = _DAT_021448cc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021448a8[2])();
  if (cVar1 != '\0') {
    _DAT_021448cc = _DAT_021448cc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a0710);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1862 ; VA 0x0050e410 ; FUN_0050e410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050e410(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01827653;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e071d0();
  FUN_009cb970(uVar1,s_Completed_021449bc,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0214491c = 0x7c;
  iStack_8 = 0;
  _DAT_021448e8 =
       RBX::Reflection::
       EventDesc<class_RBX::TweenBase,void___cdecl(enum_RBX::PlaybackState),class_rbx::signal<void___cdecl(enum_RBX::PlaybackState)>,class_rbx::signal<void___cdecl(enum_RBX::PlaybackState)>_RBX::TweenBase::*>
       ::vftable;
  FUN_0086e3d0(s_playbackState_021449ac);
  FUN_00e08e70();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02144910 = uStack_1c;
  _DAT_02144914 = uStack_18;
  _DAT_02144918 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_021448e8 =
       RBX::Reflection::
       EventDesc<class_RBX::TweenBase,void___cdecl(enum_RBX::PlaybackState),class_rbx::signal<void___cdecl(enum_RBX::PlaybackState)>,class_rbx::signal<void___cdecl(enum_RBX::PlaybackState)>_RBX::TweenBase::*>
       ::vftable;
  FUN_016f3654(&LAB_018a0730);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1863 ; VA 0x0050e560 ; FUN_0050e560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050e560(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182766a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e071d0(uVar2,0);
  FUN_009cb790(uVar1,s_Cancel_02144994,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02144868 = RBX::Reflection::BoundFuncDesc<class_RBX::TweenBase,void___cdecl(void),0>::vftable
  ;
  _DAT_021448a0 = &LAB_00a60d2f;
  _DAT_021448a4 = 0;
  _DAT_0214488c = FUN_00888530();
  FUN_016f3654(&LAB_018a0740);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1864 ; VA 0x0050e600 ; FUN_0050e600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050e600(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182768a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e071d0(uVar2,0);
  FUN_009cb790(uVar1,s_Pause_02121eb8,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021447e8 = RBX::Reflection::BoundFuncDesc<class_RBX::TweenBase,void___cdecl(void),0>::vftable
  ;
  _DAT_02144820 = &LAB_008af4eb;
  _DAT_02144824 = 0;
  _DAT_0214480c = FUN_00888530();
  FUN_016f3654(&LAB_018a0750);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1865 ; VA 0x0050e6a0 ; FUN_0050e6a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050e6a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018276aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e071d0(uVar2,0);
  FUN_009cb790(uVar1,&DAT_02128f90,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02144828 = RBX::Reflection::BoundFuncDesc<class_RBX::TweenBase,void___cdecl(void),0>::vftable
  ;
  _DAT_02144860 = &LAB_00a3d6e0;
  _DAT_02144864 = 0;
  _DAT_0214484c = FUN_00888530();
  FUN_016f3654(&LAB_018a0760);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1866 ; VA 0x0050e740 ; FUN_0050e740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050e740(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018276e0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x15;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x15);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00e070d0();
  FUN_009ca670(uVar2,&DAT_01edf850,s_Instance_021449d4,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_02144958 = RBX::Reflection::RefPropDescriptor<class_RBX::Tween,class_RBX::Instance>::vftable;
  _DAT_0214498c = RBX::Reflection::RefPropDescriptor<class_RBX::Tween,class_RBX::Instance>::vftable;
  DAT_02144990 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_02144990 == (undefined4 *)0x0) {
    DAT_02144990 = (undefined4 *)0x0;
  }
  else {
    *DAT_02144990 =
         RBX::Reflection::PropDescriptor<class_RBX::Tween,class_RBX::Instance*>::
         GetImpl<class_RBX::Instance*_(__thiscall_RBX::Tween::*)(void)const_>::vftable;
    DAT_02144990[2] = FUN_00e08430;
    DAT_02144990[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_02144958[3])();
  if (cVar1 != '\0') {
    _DAT_0214497c = _DAT_0214497c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02144958[2])();
  if (cVar1 != '\0') {
    _DAT_0214497c = _DAT_0214497c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a0790);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1867 ; VA 0x0050e8d0 ; FUN_0050e8d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050e8d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182770c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e070d0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Tween,class_RBX::TweenInfo>::
              GetImpl<class_RBX::TweenInfo_(__thiscall_RBX::TweenBase::*)(void)const_>::vftable;
    puVar3[2] = FUN_00e08480;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00da8f20();
  FUN_009ca670(uVar2,uVar4,s_TweenInfo_021449c8,&DAT_021197d4,uStack_24,0,0,0x15,0,0,0);
  DAT_02144920 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::TweenInfo>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02144954 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02144944 = _DAT_02144944 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02144920[2])();
    if (cVar1 != '\0') {
      _DAT_02144944 = _DAT_02144944 & 0xfffffff3;
    }
  }
  DAT_02144920 = RBX::Reflection::PropDescriptor<class_RBX::Tween,class_RBX::TweenInfo>::vftable;
  FUN_016f3654(&LAB_018a07b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1868 ; VA 0x0050ea60 ; FUN_0050ea60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050ea60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018278ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e09790(uVar2,0);
  FUN_009cb790(uVar1,"RenderdocTriggerCapture",0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01f183b0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::RenderingTest,void___cdecl(void),0>::vftable;
  _DAT_01f183e8 = _guard_check_icall;
  _DAT_01f183ec = 0;
  _DAT_01f183d4 = FUN_00888530();
  FUN_016f3654(&LAB_018a08a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1869 ; VA 0x0050eb80 ; FUN_0050eb80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050eb80(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018278e4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0b140();
  uVar3 = FUN_00e09790();
  FUN_009ca670(uVar3,uVar2,"ComparisonMethod","RenderingTest",uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_01f18220 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::RenderingTest,enum_RBX::RenderingTestComparisonMethod>
                 ::vftable;
  _DAT_01f18254 = uVar2;
  DAT_01f18258 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f18258 == (undefined4 *)0x0) {
    DAT_01f18258 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f18258 =
         RBX::Reflection::
         PropDescriptor<class_RBX::RenderingTest,enum_RBX::RenderingTestComparisonMethod>::
         GetSetImpl<enum_RBX::RenderingTestComparisonMethod_(__thiscall_RBX::RenderingTest::*)(void)const_,void_(__thiscall_RBX::RenderingTest::*)(enum_RBX::RenderingTestComparisonMethod)>
         ::vftable;
    DAT_01f18258[2] = &LAB_0097f520;
    DAT_01f18258[3] = 0;
    DAT_01f18258[4] = FUN_00e0aed0;
    DAT_01f18258[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1825c = FUN_00e0b140();
  cVar1 = (*(code *)DAT_01f18220[3])();
  if (cVar1 != '\0') {
    _DAT_01f18244 = _DAT_01f18244 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f18220[2])();
  if (cVar1 != '\0') {
    _DAT_01f18244 = _DAT_01f18244 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a08f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1870 ; VA 0x0050eda0 ; FUN_0050eda0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050eda0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182790c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e09790();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::RenderingTest,class_G3D::CoordinateFrame>::
              GetSetImpl<class_G3D::CoordinateFrame_(__thiscall_RBX::RenderingTest::*)(void)const_,void_(__thiscall_RBX::RenderingTest::*)(class_G3D::CoordinateFrame_const&)>
              ::vftable;
    puVar3[2] = FUN_00e0a0d0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e0aea0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,&DAT_0194e600,"RenderingTest",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f1813c = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f18170 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f18160 = _DAT_01f18160 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f1813c[2])();
    if (cVar1 != '\0') {
      _DAT_01f18160 = _DAT_01f18160 & 0xfffffff3;
    }
  }
  DAT_01f1813c = RBX::Reflection::
                 PropDescriptor<class_RBX::RenderingTest,class_G3D::CoordinateFrame>::vftable;
  FUN_016f3654(&LAB_018a0950);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1871 ; VA 0x0050f0d0 ; FUN_0050f0d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050f0d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182793c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e09790();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::RenderingTest,bool>::
              GetSetImpl<bool_(__thiscall_RBX::RenderingTest::*)(void)const_,void_(__thiscall_RBX::RenderingTest::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00e0a1a0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e0b090;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,"ShouldSkip","RenderingTest",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f18308 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f1833c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f1832c = _DAT_01f1832c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f18308[2])();
    if (cVar1 != '\0') {
      _DAT_01f1832c = _DAT_01f1832c & 0xfffffff3;
    }
  }
  DAT_01f18308 = RBX::Reflection::PropDescriptor<class_RBX::RenderingTest,bool>::vftable;
  FUN_016f3654(&LAB_018a09d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1872 ; VA 0x0050f350 ; FUN_0050f350 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050f350(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827a3c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0b480();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::WrapLayer,bool>::
              GetSetImpl<bool_(__thiscall_RBX::WrapLayer::*)(void)const_,void_(__thiscall_RBX::WrapLayer::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00c76f70;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e0bee0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,"Enabled","Behavior",uStack_24,0,0,0x1f,0,0,0);
  DAT_01f18700 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f18734 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f18724 = _DAT_01f18724 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f18700[2])();
    if (cVar1 != '\0') {
      _DAT_01f18724 = _DAT_01f18724 & 0xfffffff3;
    }
  }
  DAT_01f18700 = RBX::Reflection::PropDescriptor<class_RBX::WrapLayer,bool>::vftable;
  FUN_016f3654(&LAB_018a0ab0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1873 ; VA 0x0050f480 ; FUN_0050f480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050f480(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827a6c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0b480();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::WrapLayer,int>::
              GetSetImpl<int_(__thiscall_RBX::WrapLayer::*)(void)const_,void_(__thiscall_RBX::WrapLayer::*)(int)>
              ::vftable;
    puVar3[2] = &LAB_00d0b590;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e0bf10;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,"Order","Appearance",uStack_24,0,0,0x1f,0,1,0);
  DAT_01f18738 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f1876c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f1875c = _DAT_01f1875c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f18738[2])();
    if (cVar1 != '\0') {
      _DAT_01f1875c = _DAT_01f1875c & 0xfffffff3;
    }
  }
  DAT_01f18738 = RBX::Reflection::PropDescriptor<class_RBX::WrapLayer,int>::vftable;
  FUN_016f3654(&LAB_018a0ad0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1874 ; VA 0x0050f600 ; FUN_0050f600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050f600(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827a9c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0b480();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::WrapLayer,class_RBX::MeshId>::
              GetSetImpl<class_RBX::MeshId_const&_(__thiscall_RBX::WrapLayer::*)(void)const_,void_(__thiscall_RBX::WrapLayer::*)(class_RBX::MeshId_const&)>
              ::vftable;
    puVar3[2] = &LAB_0093a140;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e0bfb0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,"ReferenceMeshId","Appearance",uStack_24,0,0,0x1f,0,1,0);
  DAT_01f18690 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::MeshId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f186c4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f186b4 = _DAT_01f186b4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f18690[2])();
    if (cVar1 != '\0') {
      _DAT_01f186b4 = _DAT_01f186b4 & 0xfffffff3;
    }
  }
  DAT_01f18690 = RBX::Reflection::PropDescriptor<class_RBX::WrapLayer,class_RBX::MeshId>::vftable;
  FUN_016f3654(&LAB_018a0b10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1875 ; VA 0x0050f800 ; FUN_0050f800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050f800(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827acc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0b480();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::WrapLayer,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_const&_(__thiscall_RBX::WrapLayer::*)(void)const_,void_(__thiscall_RBX::WrapLayer::*)(class_G3D::Color3_const&)>
              ::vftable;
    puVar3[2] = &LAB_0076df80;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e0be40;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,&DAT_0194ebd8,"Debug",uStack_24,0,0,1,0,0,0);
  DAT_01f18890 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f188c4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f188b4 = _DAT_01f188b4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f18890[2])();
    if (cVar1 != '\0') {
      _DAT_01f188b4 = _DAT_01f188b4 & 0xfffffff3;
    }
  }
  DAT_01f18890 = RBX::Reflection::PropDescriptor<class_RBX::WrapLayer,class_G3D::Color3>::vftable;
  FUN_016f3654(&LAB_018a0b90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1876 ; VA 0x0050f930 ; FUN_0050f930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050f930(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827afc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0b480();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::WrapLayer,class_G3D::CoordinateFrame>::
              GetImpl<class_G3D::CoordinateFrame_(__thiscall_RBX::WrapLayer::*)(void)const_>::
              vftable;
    puVar3[2] = FUN_00e0bbf0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,"ReferenceOriginWorld",&DAT_018dbc3c,uStack_24,0,0,0x15,0,0,0);
  DAT_01f187a8 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f187dc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f187cc = _DAT_01f187cc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f187a8[2])();
    if (cVar1 != '\0') {
      _DAT_01f187cc = _DAT_01f187cc & 0xfffffff3;
    }
  }
  DAT_01f187a8 = RBX::Reflection::PropDescriptor<class_RBX::WrapLayer,class_G3D::CoordinateFrame>::
                 vftable;
  FUN_016f3654(&LAB_018a0bb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1877 ; VA 0x0050fa50 ; FUN_0050fa50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050fa50(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827b24;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0c140();
  uVar3 = FUN_00e0b480();
  FUN_009ca670(uVar3,uVar2,"DebugMode","Debug",uStack_24,0,0,1,0,0,1);
  uStack_8 = 0;
  DAT_01f18850 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::WrapLayer,enum_RBX::WrapLayerDebugMode>::vftable;
  _DAT_01f18884 = uVar2;
  DAT_01f18888 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f18888 == (undefined4 *)0x0) {
    DAT_01f18888 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f18888 =
         RBX::Reflection::PropDescriptor<class_RBX::WrapLayer,enum_RBX::WrapLayerDebugMode>::
         GetSetImpl<enum_RBX::WrapLayerDebugMode_(__thiscall_RBX::WrapLayer::*)(void)const_,void_(__thiscall_RBX::WrapLayer::*)(enum_RBX::WrapLayerDebugMode)>
         ::vftable;
    DAT_01f18888[2] = FUN_00d0b4e0;
    DAT_01f18888[3] = 0;
    DAT_01f18888[4] = FUN_00e0beb0;
    DAT_01f18888[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f1888c = FUN_00e0c140();
  cVar1 = (*(code *)DAT_01f18850[3])();
  if (cVar1 != '\0') {
    _DAT_01f18874 = _DAT_01f18874 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f18850[2])();
  if (cVar1 != '\0') {
    _DAT_01f18874 = _DAT_01f18874 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a0bd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1878 ; VA 0x0050fb70 ; FUN_0050fb70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050fb70(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827c0c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0c260();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::WrapTarget,float>::
              GetSetImpl<float_(__thiscall_RBX::WrapTarget::*)(void)const_,void_(__thiscall_RBX::WrapTarget::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00d0b6e0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e0c990;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,"Stiffness","Appearance",uStack_24,0,0,0x1f,0,1,0);
  DAT_01f18b68 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f18b9c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f18b8c = _DAT_01f18b8c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f18b68[2])();
    if (cVar1 != '\0') {
      _DAT_01f18b8c = _DAT_01f18b8c & 0xfffffff3;
    }
  }
  DAT_01f18b68 = RBX::Reflection::PropDescriptor<class_RBX::WrapTarget,float>::vftable;
  FUN_016f3654(&LAB_018a0c50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1879 ; VA 0x0050fcd0 ; FUN_0050fcd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050fcd0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827c3c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0c260();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::WrapTarget,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_const&_(__thiscall_RBX::WrapTarget::*)(void)const_,void_(__thiscall_RBX::WrapTarget::*)(class_G3D::Color3_const&)>
              ::vftable;
    puVar3[2] = FUN_00adf5d0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e0c8f0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,&DAT_0194ebd8,"Debug",uStack_24,0,0,1,0,0,0);
  DAT_01f18be0 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f18c14 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f18c04 = _DAT_01f18c04 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f18be0[2])();
    if (cVar1 != '\0') {
      _DAT_01f18c04 = _DAT_01f18c04 & 0xfffffff3;
    }
  }
  DAT_01f18be0 = RBX::Reflection::PropDescriptor<class_RBX::WrapTarget,class_G3D::Color3>::vftable;
  FUN_016f3654(&LAB_018a0c90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1880 ; VA 0x0050fe00 ; FUN_0050fe00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050fe00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827c64;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0ca50();
  uVar3 = FUN_00e0c260();
  FUN_009ca670(uVar3,uVar2,"DebugMode","Debug",uStack_24,0,0,1,0,0,1);
  uStack_8 = 0;
  DAT_01f18ba0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::WrapTarget,enum_RBX::WrapTargetDebugMode>::vftable;
  _DAT_01f18bd4 = uVar2;
  DAT_01f18bd8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01f18bd8 == (undefined4 *)0x0) {
    DAT_01f18bd8 = (undefined4 *)0x0;
  }
  else {
    *DAT_01f18bd8 =
         RBX::Reflection::PropDescriptor<class_RBX::WrapTarget,enum_RBX::WrapTargetDebugMode>::
         GetSetImpl<enum_RBX::WrapTargetDebugMode_(__thiscall_RBX::WrapTarget::*)(void)const_,void_(__thiscall_RBX::WrapTarget::*)(enum_RBX::WrapTargetDebugMode)>
         ::vftable;
    DAT_01f18bd8[2] = &LAB_00d0b4f0;
    DAT_01f18bd8[3] = 0;
    DAT_01f18bd8[4] = FUN_00e0c960;
    DAT_01f18bd8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01f18bdc = FUN_00e0ca50();
  cVar1 = (*(code *)DAT_01f18ba0[3])();
  if (cVar1 != '\0') {
    _DAT_01f18bc4 = _DAT_01f18bc4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01f18ba0[2])();
  if (cVar1 != '\0') {
    _DAT_01f18bc4 = _DAT_01f18bc4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a0cb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1881 ; VA 0x0050ffd0 ; FUN_0050ffd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0050ffd0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827f2a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e0cd60(uVar2,0);
  FUN_009cb790(uVar1,s_Cancel_02144994,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021449e0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::HttpRequestWrapper,void___cdecl(void),0>::vftable;
  _DAT_02144a18 = &LAB_00e0e7b0;
  _DAT_02144a1c = 0;
  _DAT_02144a04 = FUN_00888530();
  FUN_016f3654(&LAB_018a0d30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1882 ; VA 0x00510070 ; FUN_00510070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510070(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01827f8c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0cd60();
  FUN_009cb790(uVar2,s_Start_02144a68,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02144a20 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HttpRequestWrapper,void___cdecl(class_RBX::Lua::WeakFunctionRef),1>
       ::vftable;
  _DAT_02144a58 = FUN_00e0ec70;
  _DAT_02144a5c = 0;
  DAT_02144a60 = 0;
  uStack_8 = 1;
  _DAT_02144a44 = FUN_00888530();
  iVar1 = DAT_02144a60;
  if (DAT_02144a60 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00d88470();
    puStack_ec = (undefined *)0x0;
    FUN_00d88580(iVar1);
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee047c) {
      FUN_016f3809(&DAT_01ee047c);
      if (DAT_01ee047c == -1) {
        _DAT_01ee0470 = FUN_008c9370;
        _DAT_01ee0474 = FUN_008c9370;
        DAT_01ee0478 = FUN_008ca540;
        FUN_016f37bf(&DAT_01ee047c);
      }
    }
    puStack_ec = &DAT_01ee0470;
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_00d88470();
  uVar3 = FUN_0086e3d0(s_callback_02139198);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a0d40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1883 ; VA 0x00510330 ; FUN_00510330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510330(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01828133;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e0edd0();
  FUN_009cb970(uVar1,s_OnBrowserTrackerABTestLoadingSta_02144dd4,3,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02144cb4 = 0x58;
  iStack_8 = 0;
  _DAT_02144c80 =
       RBX::Reflection::
       EventDesc<class_RBX::ABTestService,void___cdecl(enum_RBX::ABTestLoadingStatus),class_rbx::signal<void___cdecl(enum_RBX::ABTestLoadingStatus)>,class_rbx::signal<void___cdecl(enum_RBX::ABTestLoadingStatus)>_RBX::ABTestService::*>
       ::vftable;
  FUN_0086e3d0(s_status_02123f34);
  FUN_00e117d0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02144ca8 = uStack_1c;
  _DAT_02144cac = uStack_18;
  _DAT_02144cb0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02144c80 =
       RBX::Reflection::
       EventDesc<class_RBX::ABTestService,void___cdecl(enum_RBX::ABTestLoadingStatus),class_rbx::signal<void___cdecl(enum_RBX::ABTestLoadingStatus)>,class_rbx::signal<void___cdecl(enum_RBX::ABTestLoadingStatus)>_RBX::ABTestService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a0db0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1884 ; VA 0x00510480 ; FUN_00510480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510480(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0182816e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e0edd0();
  FUN_009cb970(uVar1,s_OnUserABTestLoadingStatusChanged_02144e00,3,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02144cec = 0x5c;
  iStack_8 = 0;
  _DAT_02144cb8 =
       RBX::Reflection::
       EventDesc<class_RBX::ABTestService,void___cdecl(enum_RBX::ABTestLoadingStatus,__int64),class_rbx::signal<void___cdecl(enum_RBX::ABTestLoadingStatus,__int64)>,class_rbx::signal<void___cdecl(enum_RBX::ABTestLoadingStatus,__int64)>_RBX::ABTestService::*>
       ::vftable;
  FUN_0086e3d0(s_status_02123f34);
  FUN_00e117d0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_userId_0211fb64);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02144ce0 = uStack_1c;
  _DAT_02144ce4 = uStack_18;
  _DAT_02144ce8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02144cb8 =
       RBX::Reflection::
       EventDesc<class_RBX::ABTestService,void___cdecl(enum_RBX::ABTestLoadingStatus,__int64),class_rbx::signal<void___cdecl(enum_RBX::ABTestLoadingStatus,__int64)>,class_rbx::signal<void___cdecl(enum_RBX::ABTestLoadingStatus,__int64)>_RBX::ABTestService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a0dc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1885 ; VA 0x005105f0 ; FUN_005105f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005105f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182818a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e0edd0(uVar2,0);
  FUN_009cb790(uVar1,s_ClearUserVariations_02144d5c,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02144b80 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ABTestService,void___cdecl(void),0>::vftable;
  _DAT_02144bb8 = FUN_00e0f900;
  _DAT_02144bbc = 0;
  _DAT_02144ba4 = FUN_00888530();
  FUN_016f3654(&LAB_018a0dd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1886 ; VA 0x00510690 ; FUN_00510690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510690(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018281ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e0edd0();
  FUN_009cb790(uVar2,s_GetVariant_02144d04,3,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02144ab8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ABTestService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
       ::vftable;
  _DAT_02144af0 = FUN_00e10390;
  _DAT_02144af4 = 0;
  DAT_02144af8 = 0;
  uStack_8 = 1;
  _DAT_02144adc = FUN_0088cb40();
  iVar1 = DAT_02144af8;
  if (DAT_02144af8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    puStack_ec = (undefined *)0x0;
    FUN_0054ef60(iVar1);
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c48) {
      FUN_016f3809(&DAT_01ea8c48);
      if (DAT_01ea8c48 == -1) {
        _DAT_01ea8c3c = FUN_005c65f0;
        _DAT_01ea8c40 = FUN_005c93a0;
        DAT_01ea8c44 = FUN_005c77b0;
        FUN_016f37bf(&DAT_01ea8c48);
      }
    }
    puStack_ec = &DAT_01ea8c3c;
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a0de0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1887 ; VA 0x005108a0 ; FUN_005108a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005108a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182820a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e0edd0(uVar2,0);
  FUN_009cb790(uVar1,s_GetBrowserTrackerABTestLoadingSt_02144d70,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02144bc0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ABTestService,enum_RBX::ABTestLoadingStatus___cdecl(void),0>::
       vftable;
  _DAT_02144bf8 = &LAB_00e10320;
  _DAT_02144bfc = 0;
  _DAT_02144be4 = FUN_00e117d0();
  FUN_016f3654(&LAB_018a0e00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1888 ; VA 0x00510940 ; FUN_00510940 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510940(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182822a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e0edd0(uVar2,0);
  FUN_009cb790(uVar1,s_GetPendingOrInitializedUserId_02144db4,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02144c40 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ABTestService,__int64___cdecl(void),0>::vftable;
  _DAT_02144c78 = &LAB_00e10360;
  _DAT_02144c7c = 0;
  _DAT_02144c64 = FUN_0088da50();
  FUN_016f3654(&LAB_018a0e10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1889 ; VA 0x005109e0 ; FUN_005109e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005109e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182824a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e0edd0(uVar2,0);
  FUN_009cb790(uVar1,s_GetUserABTestLoadingStatus_02144d98,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02144c00 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ABTestService,enum_RBX::ABTestLoadingStatus___cdecl(void),0>::
       vftable;
  _DAT_02144c38 = &LAB_00e10370;
  _DAT_02144c3c = 0;
  _DAT_02144c24 = FUN_00e117d0();
  FUN_016f3654(&LAB_018a0e20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1890 ; VA 0x00510a80 ; FUN_00510a80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510a80(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018282ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e0edd0();
  FUN_009cb790(uVar1,s_InitializeForUserId_02144cf0,3,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02144a70 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ABTestService,void___cdecl(__int64),1>::vftable;
  _DAT_02144aa8 = FUN_00e10570;
  _DAT_02144aac = 0;
  DAT_02144ab0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02144a94 = FUN_00888530();
  if (DAT_02144ab0 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1470(DAT_02144ab0);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(s_userId_0211fb64);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a0e30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1891 ; VA 0x00510c00 ; FUN_00510c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510c00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018282ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e0edd0(uVar2,0);
  FUN_009cb820(uVar1,s_WaitUntilBrowserTrackerABTestsIn_02144d10,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02144b00 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::ABTestService,void___cdecl(void),0>::vftable;
  _DAT_02144b38 = FUN_00e118f0;
  _DAT_02144b3c = 0;
  _DAT_02144b24 = FUN_00888530();
  FUN_016f3654(&LAB_018a0e50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1892 ; VA 0x00510ca0 ; FUN_00510ca0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510ca0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018282ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e0edd0(uVar2,0);
  FUN_009cb820(uVar1,s_WaitUntilUserABTestsInitialized_02144d3c,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02144b40 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::ABTestService,void___cdecl(void),0>::vftable;
  _DAT_02144b78 = FUN_00e119c0;
  _DAT_02144b7c = 0;
  _DAT_02144b64 = FUN_00888530();
  FUN_016f3654(&LAB_018a0e60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1893 ; VA 0x00510dc0 ; FUN_00510dc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510dc0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("AESConformToAvatarRules",0x17);
  _DAT_01f194a4 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1894 ; VA 0x00510e70 ; FUN_00510e70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510e70(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("AvatarEditorServiceAnalytics",0x1c);
  _DAT_01f1949c = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1895 ; VA 0x00510f20 ; FUN_00510f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00510f20(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("AvatarEditorService",0x13);
  _DAT_01f19494 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1896 ; VA 0x00511010 ; FUN_00511010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511010(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb970(uVar1,s_OpenAllowInventoryReadAccess_02145a3c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02145454 = 0xc4;
  _DAT_02145420 =
       RBX::Reflection::
       EventDesc<class_RBX::AvatarEditorService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::AvatarEditorService::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_02145448 = 0;
  _DAT_0214544c = 0;
  _DAT_02145450 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_02145420 =
       RBX::Reflection::
       EventDesc<class_RBX::AvatarEditorService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::AvatarEditorService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a0f10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1897 ; VA 0x00511130 ; FUN_00511130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511130(void)

{
  undefined4 uVar1;
  undefined auStack_2b4 [648];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_018291f9;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10();
  FUN_009cb970(uVar1,s_OpenPromptSetFavorite_02145ad4,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0214555c = 0xcc;
  iStack_8 = 0;
  _DAT_02145528 =
       RBX::Reflection::
       EventDesc<class_RBX::AvatarEditorService,void___cdecl(__int64,enum_RBX::AvatarItemType,bool),class_rbx::signal<void___cdecl(__int64,enum_RBX::AvatarItemType,bool)>,class_rbx::signal<void___cdecl(__int64,enum_RBX::AvatarItemType,bool)>_RBX::AvatarEditorService::*>
       ::vftable;
  FUN_0086e3d0(s_itemId_0214579c);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_itemType_02145790);
  FUN_00e2bdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_shouldFavorite_02145a94);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b4,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_02145550 = uStack_1c;
  _DAT_02145554 = uStack_18;
  _DAT_02145558 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b4,0xd8,3,FUN_00688b10);
  _DAT_02145528 =
       RBX::Reflection::
       EventDesc<class_RBX::AvatarEditorService,void___cdecl(__int64,enum_RBX::AvatarItemType,bool),class_rbx::signal<void___cdecl(__int64,enum_RBX::AvatarItemType,bool)>,class_rbx::signal<void___cdecl(__int64,enum_RBX::AvatarItemType,bool)>_RBX::AvatarEditorService::*>
       ::vftable;
  FUN_016f3654(&LAB_018a0f30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1898 ; VA 0x00511360 ; FUN_00511360 */

void FUN_00511360(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e16780(FUN_00e19c70,0,s_CheckApplyDefaultClothing_02145b88,s_humanoidDescription_0211f980,0,
               uStack_10,0);
  FUN_016f3654(&LAB_018a0f70);
  return;
}



/* FUNCTION 1899 ; VA 0x005113c0 ; FUN_005113c0 */

void FUN_005113c0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e16780(FUN_00e1a990,0,s_ConformToAvatarRules_02145b70,s_humanoidDescription_0211f980,5,
               uStack_10,0);
  FUN_016f3654(&LAB_018a0fc0);
  return;
}



/* FUNCTION 1900 ; VA 0x00511420 ; FUN_00511420 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511420(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182921a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb820(uVar1,s_GetAvatarRules_02145780,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02144e28 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AvatarEditorService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02144e60 = FUN_00e1f080;
  _DAT_02144e64 = 0;
  _DAT_02144e4c = FUN_008881d0();
  FUN_016f3654(&LAB_018a1010);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1901 ; VA 0x005114c0 ; FUN_005114c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005114c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182924e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb820(uVar1,s_GetBatchItemDetails_021457bc,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02144eb0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AvatarEditorService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::AvatarItemType),2>
       ::vftable;
  _DAT_02144ee8 = FUN_00e1f420;
  _DAT_02144eec = 0;
  _DAT_02144ef0 = 0;
  _DAT_02144ef4 = 0;
  uStack_8 = 2;
  FUN_00e1cac0();
  FUN_016f3654(&LAB_018a1020);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1902 ; VA 0x00511580 ; FUN_00511580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511580(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182927e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb820(uVar1,s_GetFavorite_02145b64,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021456a8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AvatarEditorService,bool___cdecl(__int64,enum_RBX::AvatarItemType),2>
       ::vftable;
  _DAT_021456e0 = FUN_00e20580;
  _DAT_021456e4 = 0;
  DAT_021456e8 = 0;
  DAT_021456ec = 0;
  uStack_8 = 2;
  FUN_00e1cec0();
  FUN_016f3654(&LAB_018a1030);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1903 ; VA 0x00511640 ; FUN_00511640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511640(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018292dc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10();
  FUN_009cb820(uVar1,s_GetInventory_02145b48,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02145620 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AvatarEditorService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),1>
       ::vftable;
  _DAT_02145658 = FUN_00e20a70;
  _DAT_0214565c = 0;
  DAT_02145660 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02145644 = FUN_0088cdc0();
  if (DAT_02145660 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1420(DAT_02145660);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_008882f0();
  uVar3 = FUN_0086e3d0(s_assetTypes_02145b3c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a1070);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1904 ; VA 0x005117c0 ; FUN_005117c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005117c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182930e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb820(uVar1,s_GetItemDetails_021457a4,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02144e68 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AvatarEditorService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(__int64,enum_RBX::AvatarItemType),2>
       ::vftable;
  _DAT_02144ea0 = FUN_00e211a0;
  _DAT_02144ea4 = 0;
  DAT_02144ea8 = 0;
  DAT_02144eac = 0;
  uStack_8 = 2;
  FUN_00e1c8c0();
  FUN_016f3654(&LAB_018a10c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1905 ; VA 0x00511880 ; FUN_00511880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511880(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182932a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb820(uVar1,s_GetOutfits_02145b58,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02145668 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AvatarEditorService,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_021456a0 = FUN_00e21750;
  _DAT_021456a4 = 0;
  _DAT_0214568c = FUN_0088cdc0();
  FUN_016f3654(&LAB_018a1100);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1906 ; VA 0x00511920 ; FUN_00511920 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511920(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182935e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb820(uVar1,s_GetRecommendedAssets_021457e0,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02144ef8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AvatarEditorService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(enum_RBX::AvatarAssetType,__int64),2>
       ::vftable;
  _DAT_02144f30 = FUN_00e21c40;
  _DAT_02144f34 = 0;
  DAT_02144f38 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  DAT_02144f3c = (undefined4 *)FUN_01674e20(8);
  if (DAT_02144f3c == (undefined4 *)0x0) {
    DAT_02144f3c = (undefined4 *)0x0;
  }
  else {
    *DAT_02144f3c = 0;
    DAT_02144f3c[1] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00e1ccc0();
  FUN_016f3654(&LAB_018a1110);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1907 ; VA 0x00511a00 ; FUN_00511a00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511a00(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018293bc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10();
  FUN_009cb820(uVar1,s_GetRecommendedBundles_021457f8,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02144f40 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AvatarEditorService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(__int64),1>
       ::vftable;
  _DAT_02144f78 = FUN_00e22230;
  _DAT_02144f7c = 0;
  DAT_02144f80 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02144f64 = FUN_008882f0();
  if (DAT_02144f80 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1470(DAT_02144f80);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(s_bundleId_0212b894);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a1150);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1908 ; VA 0x00511b80 ; FUN_00511b80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511b80(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018293ee;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_PerformCreateOutfitWithDescripti_0214597c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02145298 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),2>
       ::vftable;
  _DAT_021452d0 = FUN_00e266e0;
  _DAT_021452d4 = 0;
  DAT_021452d8 = 0;
  _DAT_021452dc = 0;
  uStack_8 = 2;
  FUN_00c9be10();
  FUN_016f3654(&LAB_018a1170);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1909 ; VA 0x00511c40 ; FUN_00511c40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511c40(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182944c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e13a10();
  FUN_009cb790(uVar2,s_PerformCreateOutfit_021459a0,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021452e0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
       ::vftable;
  _DAT_02145318 = FUN_00e26930;
  _DAT_0214531c = 0;
  DAT_02145320 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02145304 = FUN_00888530();
  iVar1 = DAT_02145320;
  if (DAT_02145320 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a11d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1910 ; VA 0x00511df0 ; FUN_00511df0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511df0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01829488;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_PerformSaveAvatarWithDescription_021458a0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02145088 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),3>
       ::vftable;
  _DAT_021450c0 = FUN_00e26b80;
  _DAT_021450c4 = 0;
  _DAT_021450c8 = 0;
  _DAT_021450cc = 0;
  _DAT_021450d0 = 0;
  uStack_8 = 3;
  FUN_00e1c140(s_humanoidDescription_0211f980,s_addedAssets_02145894,s_removedAssets_02145884);
  FUN_016f3654(&LAB_018a11f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1911 ; VA 0x00511ec0 ; FUN_00511ec0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511ec0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018294be;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_PerformSaveAvatarNew_021458c4,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021450d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),2>
       ::vftable;
  _DAT_02145110 = FUN_00e27180;
  _DAT_02145114 = 0;
  _DAT_02145118 = 0;
  _DAT_0214511c = 0;
  uStack_8 = 2;
  FUN_00e1bf60();
  FUN_016f3654(&LAB_018a1200);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1912 ; VA 0x00511fb0 ; FUN_00511fb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00511fb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018294da;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_PerformSaveAvatar_021458dc,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02145120 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(void),0>::vftable;
  _DAT_02145158 = FUN_00e27290;
  _DAT_0214515c = 0;
  _DAT_02145144 = FUN_00888530();
  FUN_016f3654(&LAB_018a1210);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1913 ; VA 0x00512050 ; FUN_00512050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512050(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018294fa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_PerformSetFavorite_02145aec,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02145560 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(void),0>::vftable;
  _DAT_02145598 = FUN_00e27380;
  _DAT_0214559c = 0;
  _DAT_02145584 = FUN_00888530();
  FUN_016f3654(&LAB_018a1220);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1914 ; VA 0x005120f0 ; FUN_005120f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005120f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182951a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_PromptAllowInventoryReadAccess_021459f4,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021453a8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(void),0>::vftable;
  _DAT_021453e0 = FUN_00e28d40;
  _DAT_021453e4 = 0;
  _DAT_021453cc = FUN_00888530();
  FUN_016f3654(&LAB_018a1230);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1915 ; VA 0x00512190 ; FUN_00512190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512190(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182954e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_PromptCreateOutfit_02145934,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021451e0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::HumanoidRigType),2>
       ::vftable;
  _DAT_02145218 = FUN_00e28f60;
  _DAT_0214521c = 0;
  _DAT_02145220 = 0;
  _DAT_02145224 = 0;
  uStack_8 = 2;
  FUN_00e1c3f0();
  FUN_016f3654(&LAB_018a1240);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1916 ; VA 0x00512250 ; FUN_00512250 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512250(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182957e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_PromptSaveAvatar_02145834,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02144fd0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::HumanoidRigType),2>
       ::vftable;
  _DAT_02145008 = FUN_00e29280;
  _DAT_0214500c = 0;
  _DAT_02145010 = 0;
  _DAT_02145014 = 0;
  uStack_8 = 2;
  FUN_00e1c3f0();
  FUN_016f3654(&LAB_018a1250);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1917 ; VA 0x00512310 ; FUN_00512310 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512310(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018295b8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_PromptSetFavorite_02145aa4,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021454a0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(__int64,enum_RBX::AvatarItemType,bool),3>
       ::vftable;
  _DAT_021454d8 = FUN_00e29590;
  _DAT_021454dc = 0;
  DAT_021454e0 = 0;
  DAT_021454e4 = 0;
  DAT_021454e8 = 0;
  uStack_8 = 3;
  FUN_00e1c5f0(s_itemId_0214579c,s_itemType_02145790,s_shouldFavorite_02145a94);
  FUN_016f3654(&LAB_018a1260);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1918 ; VA 0x005123e0 ; FUN_005123e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005123e0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182961c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e13a10();
  FUN_009cb820(uVar2,s_SearchCatalog_02145824,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02144f88 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::AvatarEditorService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_RBX::CatalogSearchParams),1>
       ::vftable;
  _DAT_02144fc0 = FUN_00e2abc0;
  _DAT_02144fc4 = 0;
  DAT_02144fc8 = 0;
  uStack_8 = 1;
  _DAT_02144fac = FUN_0088cdc0();
  iVar1 = DAT_02144fc8;
  if (DAT_02144fc8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00da48e0();
    puStack_ec = (undefined *)0x0;
    FUN_009cf8d0(iVar1);
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4410) {
      FUN_016f3809(&DAT_01ee4410);
      if (DAT_01ee4410 == -1) {
        _DAT_01ee4404 = FUN_009d02c0;
        _DAT_01ee4408 = FUN_009d02c0;
        DAT_01ee440c = FUN_0087f010;
        FUN_016f37bf(&DAT_01ee4410);
      }
    }
    puStack_ec = &DAT_01ee4404;
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_00da48e0();
  uVar3 = FUN_0086e3d0(s_searchParameters_02145810);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a12b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1919 ; VA 0x005125f0 ; FUN_005125f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005125f0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182967c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10();
  FUN_009cb790(uVar1,s_SetAllowInventoryReadAccess_02145a78,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02145458 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(bool),1>::vftable;
  _DAT_02145490 = FUN_00e2b3e0;
  _DAT_02145494 = 0;
  DAT_02145498 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214547c = FUN_00888530();
  if (DAT_02145498 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1510(DAT_02145498);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_inventoryReadAccessGranted_02145a5c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a12e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1920 ; VA 0x00512770 ; FUN_00512770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512770(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182969a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_SignalCreateOutfitFailed_021459d8,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02145368 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(void),0>::vftable;
  _DAT_021453a0 = &LAB_00e2b700;
  _DAT_021453a4 = 0;
  _DAT_0214538c = FUN_00888530();
  FUN_016f3654(&LAB_018a1300);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1921 ; VA 0x00512810 ; FUN_00512810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512810(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018296ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_SignalCreateOutfitPermissionDeni_021459b4,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02145328 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(void),0>::vftable;
  _DAT_02145360 = FUN_00e2b720;
  _DAT_02145364 = 0;
  _DAT_0214534c = FUN_00888530();
  FUN_016f3654(&LAB_018a1310);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1922 ; VA 0x005128b0 ; FUN_005128b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005128b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018296da;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_SignalSaveAvatarFailed_02145914,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021451a0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(void),0>::vftable;
  _DAT_021451d8 = &LAB_00e2b940;
  _DAT_021451dc = 0;
  _DAT_021451c4 = FUN_00888530();
  FUN_016f3654(&LAB_018a1320);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1923 ; VA 0x00512950 ; FUN_00512950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512950(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018296fa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_SignalSaveAvatarPermissionDenied_021458f0,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02145160 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(void),0>::vftable;
  _DAT_02145198 = FUN_00e2b960;
  _DAT_0214519c = 0;
  _DAT_02145184 = FUN_00888530();
  FUN_016f3654(&LAB_018a1330);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1924 ; VA 0x005129f0 ; FUN_005129f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005129f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182971a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_SignalSetFavoriteFailed_02145b24,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021455e0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(void),0>::vftable;
  _DAT_02145618 = &LAB_00e2bb80;
  _DAT_0214561c = 0;
  _DAT_02145604 = FUN_00888530();
  FUN_016f3654(&LAB_018a1340);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1925 ; VA 0x00512a90 ; FUN_00512a90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512a90(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182973a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e13a10(uVar2,0);
  FUN_009cb790(uVar1,s_SignalSetFavoritePermissionDenie_02145b00,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021455a0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AvatarEditorService,void___cdecl(void),0>::vftable;
  _DAT_021455d8 = FUN_00e2bba0;
  _DAT_021455dc = 0;
  _DAT_021455c4 = FUN_00888530();
  FUN_016f3654(&LAB_018a1350);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1926 ; VA 0x00512b80 ; FUN_00512b80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512b80(void)

{
  undefined **ppuVar1;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182af42;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  DAT_01f19a04 = FUN_00588320(0xb);
  DAT_01f19a08 = 0;
  _DAT_01f19a0c = 0x3f800000;
  _DAT_01f19a10 = 0;
  DAT_01f19a14 = 0;
  puStack_1c = &DAT_01f19a04;
  iStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 1;
  FUN_00d80290(&puStack_1c,&DAT_019998ec,&DAT_019998ec,
               &RBX::DescribedCreatable<class_RBX::HumanoidDescription,class_RBX::Instance>::
                vftable_meta_ptr);
  ppuVar1 = (undefined **)&DAT_019998f0;
  do {
    FUN_00d80290(&puStack_1c,ppuVar1,ppuVar1,
                 &RBX::DescribedCreatable<class_RBX::HumanoidDescription,class_RBX::Instance>::
                  vftable_meta_ptr);
    ppuVar1 = ppuVar1 + 1;
  } while (ppuVar1 !=
           &RBX::DescribedCreatable<class_RBX::HumanoidDescription,class_RBX::Instance>::
            vftable_meta_ptr);
  if (iStack_18 != 0) {
    FUN_01674ea0(iStack_18,0xc);
  }
  FUN_016f3654(&LAB_018a1470);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1927 ; VA 0x00512c70 ; FUN_00512c70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512c70(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0182af73;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e2c3f0();
  FUN_009cb970(uVar1,s_EmotesChanged_021468ec,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0214657c = 0x54;
  iStack_8 = 0;
  _DAT_02146548 =
       RBX::Reflection::
       EventDesc<class_RBX::HumanoidDescription,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::HumanoidDescription::*>
       ::vftable;
  FUN_0086e3d0(s_newEmotes_021468e0);
  FUN_008881d0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02146570 = uStack_1c;
  _DAT_02146574 = uStack_18;
  _DAT_02146578 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02146548 =
       RBX::Reflection::
       EventDesc<class_RBX::HumanoidDescription,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::HumanoidDescription::*>
       ::vftable;
  FUN_016f3654(&LAB_018a1480);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1928 ; VA 0x00512dc0 ; FUN_00512dc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512dc0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0182afa3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e2c3f0();
  FUN_009cb970(uVar1,s_EquippedEmotesChanged_02146948,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0214663c = 0x58;
  iStack_8 = 0;
  _DAT_02146608 =
       RBX::Reflection::
       EventDesc<class_RBX::HumanoidDescription,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>_RBX::HumanoidDescription::*>
       ::vftable;
  FUN_0086e3d0(s_newEquippedEmotes_02146934);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02146630 = uStack_1c;
  _DAT_02146634 = uStack_18;
  _DAT_02146638 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02146608 =
       RBX::Reflection::
       EventDesc<class_RBX::HumanoidDescription,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>_RBX::HumanoidDescription::*>
       ::vftable;
  FUN_016f3654(&LAB_018a1490);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1929 ; VA 0x00512f10 ; FUN_00512f10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512f10(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182afce;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e2c3f0(uVar2,0);
  FUN_009cb790(uVar1,s_AddEmote_021468a8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02146430 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HumanoidDescription,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64),2>
       ::vftable;
  _DAT_02146468 = FUN_00e2e4d0;
  _DAT_0214646c = 0;
  _DAT_02146470 = 0;
  DAT_02146474 = 0;
  uStack_8 = 2;
  FUN_00e2f490();
  FUN_016f3654(&LAB_018a14a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1930 ; VA 0x00512fd0 ; FUN_00512fd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00512fd0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182afea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e2c3f0(uVar2,0);
  FUN_009cb790(uVar1,s_GetEmotes_021468c0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021464c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HumanoidDescription,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_021464f8 = FUN_00e302a0;
  _DAT_021464fc = 0;
  _DAT_021464e4 = FUN_008881d0();
  FUN_016f3654(&LAB_018a14d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1931 ; VA 0x00513070 ; FUN_00513070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00513070(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182b00a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e2c3f0(uVar2,0);
  FUN_009cb790(uVar1,s_GetEquippedEmotes_021468fc,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02146580 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HumanoidDescription,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_021465b8 = FUN_00e307a0;
  _DAT_021465bc = 0;
  _DAT_021465a4 = FUN_008882f0();
  FUN_016f3654(&LAB_018a14e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1932 ; VA 0x00513110 ; FUN_00513110 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00513110(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182b06c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e2c3f0();
  FUN_009cb790(uVar2,s_RemoveEmote_021468b4,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02146478 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HumanoidDescription,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_021464b0 = FUN_00e315e0;
  _DAT_021464b4 = 0;
  DAT_021464b8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214649c = FUN_00888530();
  iVar1 = DAT_021464b8;
  if (DAT_021464b8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a14f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1933 ; VA 0x005132c0 ; FUN_005132c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005132c0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182b0cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e2c3f0();
  FUN_009cb790(uVar1,s_SetEmotes_021468d4,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02146500 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HumanoidDescription,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),1>
       ::vftable;
  _DAT_02146538 = FUN_00e32820;
  _DAT_0214653c = 0;
  DAT_02146540 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02146524 = FUN_00888530();
  if (DAT_02146540 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_00687440(DAT_02146540);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_008881d0();
  uVar3 = FUN_0086e3d0(s_emotes_021468cc);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a1510);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1934 ; VA 0x00513440 ; FUN_00513440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00513440(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182b12c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e2c3f0();
  FUN_009cb790(uVar1,s_SetEquippedEmotes_02146920,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021465c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::HumanoidDescription,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),1>
       ::vftable;
  _DAT_021465f8 = FUN_00e332c0;
  _DAT_021465fc = 0;
  DAT_02146600 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021465e4 = FUN_00888530();
  if (DAT_02146600 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1420(DAT_02146600);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_008882f0();
  uVar3 = FUN_0086e3d0(s_equippedEmotes_02146910);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a1560);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1935 ; VA 0x00514470 ; FUN_00514470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00514470(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182b15c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e2c3f0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::HumanoidDescription,int>::
              GetSetImpl<int_(__thiscall_RBX::HumanoidDescription::*)(void)const_,void_(__thiscall_RBX::HumanoidDescription::*)(int)>
              ::vftable;
    puVar3[2] = &LAB_00e31140;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e339f0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_NumberEmotesLoaded_02146960,s_Animation_021467fc,uStack_24,0,0,0x12,5,5
               ,0);
  DAT_02146640 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02146674 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02146664 = _DAT_02146664 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02146640[2])();
    if (cVar1 != '\0') {
      _DAT_02146664 = _DAT_02146664 & 0xfffffff3;
    }
  }
  DAT_02146640 = RBX::Reflection::PropDescriptor<class_RBX::HumanoidDescription,int>::vftable;
  FUN_016f3654(&LAB_018a19d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1936 ; VA 0x005147d0 ; FUN_005147d0 */

void FUN_005147d0(void)

{
  undefined auStack_70 [32];
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined *puStack_44;
  undefined **ppuStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180de78;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_4c = (ulonglong)uStack_20;
  uStack_3c = 0;
  uStack_50 = 5;
  puStack_44 = (undefined *)0x0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  ppuStack_40 = RBX::Lua::WeakFunctionRef::vftable;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  puStack_14 = auStack_70;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00d88580(&ppuStack_40);
  FUN_00e34700(FUN_00e34df0,0,s_CheckForUpdate_02146a08,s_handler_02146a00);
  puStack_44 = (undefined *)0x51486b;
  FUN_00d88a30();
  puStack_44 = &LAB_018a1b10;
  uStack_4c = CONCAT44(0x514875,(undefined4)uStack_4c);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1937 ; VA 0x00514890 ; FUN_00514890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00514890(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182b85a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e34120(uVar2,0);
  FUN_009cb790(uVar1,s_PerformManagedUpdate_02146a18,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021469c0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::AppUpdateService,bool___cdecl(void),0>::vftable;
  _DAT_021469f8 = &LAB_00e35630;
  _DAT_021469fc = 0;
  _DAT_021469e4 = FUN_0088daf0();
  FUN_016f3654(&LAB_018a1b30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1938 ; VA 0x005154e0 ; FUN_005154e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005154e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182be9c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e39980();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PhysicsSettings,double>::
              GetSetImpl<double_(__thiscall_RBX::PhysicsSettings::*)(void)const_,void_(__thiscall_RBX::PhysicsSettings::*)(double)>
              ::vftable;
    puVar3[2] = FUN_00cc2960;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e3a8d0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088ca00();
  FUN_009ca670(uVar2,uVar4,s_ThrottleAdjustTime_02147144,s_Performance_0211d710,uStack_24,0,0,0x1f,0
               ,0,0);
  DAT_02146e98 = RBX::Reflection::TypedPropertyDescriptor<double>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02146ecc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02146ebc = _DAT_02146ebc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02146e98[2])();
    if (cVar1 != '\0') {
      _DAT_02146ebc = _DAT_02146ebc & 0xfffffff3;
    }
  }
  DAT_02146e98 = RBX::Reflection::PropDescriptor<class_RBX::PhysicsSettings,double>::vftable;
  FUN_016f3654(&LAB_018a1f00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1939 ; VA 0x00515610 ; FUN_00515610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00515610(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182bec4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00bc0d60();
  uVar3 = FUN_00e39980();
  FUN_009ca670(uVar3,uVar2,s_PhysicsEnvironmentalThrottle_02133d64,s_Performance_0211d710,uStack_24,
               0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02146e58 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::PhysicsSettings,enum_RBX::EThrottleType>::vftable;
  _DAT_02146e8c = uVar2;
  DAT_02146e90 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02146e90 == (undefined4 *)0x0) {
    DAT_02146e90 = (undefined4 *)0x0;
  }
  else {
    *DAT_02146e90 =
         RBX::Reflection::PropDescriptor<class_RBX::PhysicsSettings,enum_RBX::EThrottleType>::
         GetSetImpl<enum_RBX::EThrottleType_(__thiscall_RBX::PhysicsSettings::*)(void)const_,void_(__thiscall_RBX::PhysicsSettings::*)(enum_RBX::EThrottleType)>
         ::vftable;
    DAT_02146e90[2] = FUN_00e39f60;
    DAT_02146e90[3] = 0;
    DAT_02146e90[4] = FUN_00e3a420;
    DAT_02146e90[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02146e94 = FUN_00bc0d60();
  cVar1 = (*(code *)DAT_02146e58[3])();
  if (cVar1 != '\0') {
    _DAT_02146e7c = _DAT_02146e7c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02146e58[2])();
  if (cVar1 != '\0') {
    _DAT_02146e7c = _DAT_02146e7c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a1f20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1940 ; VA 0x00515890 ; FUN_00515890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00515890(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182bfdc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e3aac0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::DialogChoice,bool>::
              GetSetImpl<bool_(__thiscall_RBX::DialogChoice::*)(void)const_,void_(__thiscall_RBX::DialogChoice::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00ba4f50;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e3b100;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_GoodbyeChoiceActive_021427d0,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02147244 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02147278 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02147268 = _DAT_02147268 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02147244[2])();
    if (cVar1 != '\0') {
      _DAT_02147268 = _DAT_02147268 & 0xfffffff3;
    }
  }
  DAT_02147244 = RBX::Reflection::PropDescriptor<class_RBX::DialogChoice,bool>::vftable;
  FUN_016f3654(&LAB_018a1f90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1941 ; VA 0x00515b50 ; FUN_00515b50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00515b50(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c0dc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e3b390();
  FUN_009cb790(uVar1,s_AxisRotate_0214740c,0,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8 = 0;
  _DAT_02147370 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LuaDragger,void___cdecl(enum_G3D::Vector3::Axis),1>
       ::vftable;
  _DAT_021473a8 = FUN_00e3b980;
  _DAT_021473ac = 0;
  DAT_021473b0 = (undefined4 *)FUN_01674e20(4);
  if (DAT_021473b0 == (undefined4 *)0x0) {
    DAT_021473b0 = (undefined4 *)0x0;
  }
  else {
    *DAT_021473b0 = 0;
  }
  uStack_8._0_1_ = 1;
  _DAT_02147394 = FUN_00888530();
  puVar3 = DAT_021473b0;
  if (DAT_021473b0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00896ba0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_008971f0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00896ba0();
  uVar2 = FUN_0086e3d0(&DAT_02137c40);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a2070);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1942 ; VA 0x00515d10 ; FUN_00515d10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00515d10(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c118;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e3b390(uVar2,0);
  FUN_009cb790(uVar1,s_MouseDown_021473e0,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02147298 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::LuaDragger,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_G3D::Vector3,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>),3>
       ::vftable;
  _DAT_021472d0 = FUN_00e3c8f0;
  _DAT_021472d4 = 0;
  _DAT_021472d8 = 0;
  _DAT_021472dc = 0;
  _DAT_021472e0 = 0;
  uStack_8 = 3;
  FUN_00e3ba50(s_mousePart_021473d4,s_pointOnMousePart_021473c0,s_parts_021473b8);
  FUN_016f3654(&LAB_018a2090);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1943 ; VA 0x00515de0 ; FUN_00515de0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00515de0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c17c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e3b390();
  FUN_009cb790(uVar1,s_MouseMove_021473f8,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021472e8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LuaDragger,void___cdecl(class_RBX::RbxRay),1>::
       vftable;
  _DAT_02147320 = FUN_00e3caa0;
  _DAT_02147324 = 0;
  DAT_02147328 = (undefined4 *)0x0;
  uStack_8 = 1;
  _DAT_0214730c = FUN_00888530();
  puVar3 = DAT_02147328;
  if (DAT_02147328 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088d370();
    puStack_ec = (undefined *)0x0;
    uStack_e8 = *puVar3;
    uStack_e4 = puVar3[1];
    uStack_e0 = puVar3[2];
    uStack_dc = puVar3[3];
    uStack_d8 = *(undefined8 *)(puVar3 + 4);
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead458) {
      FUN_016f3809(&DAT_01ead458);
      if (DAT_01ead458 == -1) {
        _DAT_01ead44c = FUN_00619f80;
        _DAT_01ead450 = FUN_00619f80;
        DAT_01ead454 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead458);
      }
    }
    puStack_ec = &DAT_01ead44c;
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088d370();
  uVar2 = FUN_0086e3d0(s_mouseRay_021473ec);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a20a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1944 ; VA 0x00516000 ; FUN_00516000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516000(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c19a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e3b390(uVar2,0);
  FUN_009cb790(uVar1,s_MouseUp_02147404,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02147330 =
       RBX::Reflection::BoundFuncDesc<class_RBX::LuaDragger,void___cdecl(void),0>::vftable;
  _DAT_02147368 = FUN_00e3cbf0;
  _DAT_0214736c = 0;
  _DAT_02147354 = FUN_00888530();
  FUN_016f3654(&LAB_018a20c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1945 ; VA 0x005160c0 ; FUN_005160c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005160c0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e3f130(FUN_00e3f4a0,0,s_Button1Down_021477c0,s_position_0211fd1c,s_camera_021477a8,
               _DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,
               _UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,3
               ,uStack_10,0);
  FUN_016f3654(&LAB_018a2190);
  return;
}



/* FUNCTION 1946 ; VA 0x00516140 ; FUN_00516140 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516140(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e3f130(FUN_00e3f4e0,0,s_Button1Up_021477cc,s_position_0211fd1c,s_camera_021477a8,
               _DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,
               _UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,3
               ,uStack_10,0);
  FUN_016f3654(&LAB_018a21d0);
  return;
}



/* FUNCTION 1947 ; VA 0x005161c0 ; FUN_005161c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005161c0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e3f130(FUN_00e3f520,0,s_Button2Down_021477e8,s_position_0211fd1c,s_camera_021477a8,
               _DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,
               _UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,3
               ,uStack_10,0);
  FUN_016f3654(&LAB_018a2210);
  return;
}



/* FUNCTION 1948 ; VA 0x00516240 ; FUN_00516240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516240(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e3f130(FUN_00e3f560,0,s_Button2Up_021477f4,s_position_0211fd1c,s_camera_021477a8,
               _DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,
               _UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,3
               ,uStack_10,0);
  FUN_016f3654(&LAB_018a2250);
  return;
}



/* FUNCTION 1949 ; VA 0x005162c0 ; FUN_005162c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005162c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c55a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e3ea70(uVar2,0);
  FUN_009cb790(uVar1,s_CaptureController_0214782c,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02147690 =
       RBX::Reflection::BoundFuncDesc<class_RBX::VirtualUser,void___cdecl(void),0>::vftable;
  _DAT_021476c8 = FUN_00e3f5a0;
  _DAT_021476cc = 0;
  _DAT_021476b4 = FUN_00888530();
  FUN_016f3654(&LAB_018a2290);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1950 ; VA 0x00516360 ; FUN_00516360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516360(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e3f130(FUN_00e3f690,0,s_ClickButton1_021477b0,s_position_0211fd1c,s_camera_021477a8,
               _DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,
               _UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,3
               ,uStack_10,0);
  FUN_016f3654(&LAB_018a22a0);
  return;
}



/* FUNCTION 1951 ; VA 0x005163e0 ; FUN_005163e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005163e0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e3f130(FUN_00e3f700,0,s_ClickButton2_021477d8,s_position_0211fd1c,s_camera_021477a8,
               _DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,
               _UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,3
               ,uStack_10,0);
  FUN_016f3654(&LAB_018a22e0);
  return;
}



/* FUNCTION 1952 ; VA 0x00516460 ; FUN_00516460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516460(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e3f130(FUN_00e40000,0,s_MoveMouse_02147800,s_position_0211fd1c,s_camera_021477a8,
               _DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,
               _UNK_018e3fb8,_UNK_018e3fbc,_DAT_018e3fb0,_UNK_018e3fb4,_UNK_018e3fb8,_UNK_018e3fbc,3
               ,uStack_10,0);
  FUN_016f3654(&LAB_018a2320);
  return;
}



/* FUNCTION 1953 ; VA 0x005164e0 ; FUN_005164e0 */

void FUN_005164e0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e3ef40(FUN_00e400a0,0,s_TypeKey_02147840,&DAT_0211f870,3,uStack_10,0);
  FUN_016f3654(&LAB_018a2360);
  return;
}



/* FUNCTION 1954 ; VA 0x00516540 ; FUN_00516540 */

void FUN_00516540(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e3ef40(FUN_00e403c0,0,s_SetKeyDown_02147848,&DAT_0211f870,3,uStack_10,0);
  FUN_016f3654(&LAB_018a2380);
  return;
}



/* FUNCTION 1955 ; VA 0x005165a0 ; FUN_005165a0 */

void FUN_005165a0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e3ef40(FUN_00e40560,0,s_SetKeyUp_02147854,&DAT_0211f870,3,uStack_10,0);
  FUN_016f3654(&LAB_018a23a0);
  return;
}



/* FUNCTION 1956 ; VA 0x00516600 ; FUN_00516600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516600(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c57a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e3ea70(uVar2,0);
  FUN_009cb790(uVar1,s_StartRecording_0214780c,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02147610 =
       RBX::Reflection::BoundFuncDesc<class_RBX::VirtualUser,void___cdecl(void),0>::vftable;
  _DAT_02147648 = FUN_00e406e0;
  _DAT_0214764c = 0;
  _DAT_02147634 = FUN_00888530();
  FUN_016f3654(&LAB_018a23c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1957 ; VA 0x005166a0 ; FUN_005166a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005166a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c59a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e3ea70(uVar2,0);
  FUN_009cb790(uVar1,s_StopRecording_0214781c,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02147650 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::VirtualUser,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_02147688 = FUN_00e408a0;
  _DAT_0214768c = 0;
  _DAT_02147674 = FUN_0088cb40();
  FUN_016f3654(&LAB_018a23d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1958 ; VA 0x00516740 ; FUN_00516740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516740(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c6ea;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009cb3a0();
  uVar3 = FUN_00e40f60();
  FUN_00684820(uVar3,s_AutoColorCharacters_02147a40,&DAT_021197d4,0);
  uStack_8 = 0;
  DAT_02147908 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::Team>::vftable;
    puVar4[1] = &DAT_02147908;
    puVar4[2] = 0x5d;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_0214793c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0214793c;
    DAT_0214793c = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_0214793c;
  }
  DAT_0214793c = puVar4;
  cVar2 = (*(code *)DAT_02147908[3])();
  if (cVar2 != '\0') {
    _DAT_0214792c = _DAT_0214792c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02147908[2])();
  if (cVar2 != '\0') {
    _DAT_0214792c = _DAT_0214792c & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1959 ; VA 0x005168a0 ; FUN_005168a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005168a0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c71c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e40f60();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Team,class_RBX::BrickColor>::
              GetSetImpl<class_RBX::BrickColor_(__thiscall_RBX::Team::*)(void)const_,void_(__thiscall_RBX::Team::*)(class_RBX::BrickColor)>
              ::vftable;
    puVar3[2] = FUN_00a6bd20;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e41a50;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar2,uVar4,s_TeamColor_0211fd68,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02147898 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021478cc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_021478bc = _DAT_021478bc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02147898[2])();
    if (cVar1 != '\0') {
      _DAT_021478bc = _DAT_021478bc & 0xfffffff3;
    }
  }
  DAT_02147898 = RBX::Reflection::PropDescriptor<class_RBX::Team,class_RBX::BrickColor>::vftable;
  FUN_016f3654(&LAB_018a2480);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1960 ; VA 0x005169e0 ; FUN_005169e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005169e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c73a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e40f60(uVar2,0);
  FUN_009cb790(uVar1,s_GetPlayers_02121500,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02147940 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Team,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02147978 = FUN_00e413f0;
  _DAT_0214797c = 0;
  _DAT_02147964 = FUN_0088cc80();
  FUN_016f3654(&LAB_018a24a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1961 ; VA 0x00516ba0 ; FUN_00516ba0 */

void FUN_00516ba0(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb3a0(auStack_14,0x15);
  FUN_00e40e60(s_Score_02147a28,&DAT_021197d4,&LAB_008b4220,0,FUN_00e41a30,0,*puVar1,puVar1[1],
               puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_018a24f0);
  return;
}



/* FUNCTION 1962 ; VA 0x00516c10 ; FUN_00516c10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516c10(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c8dc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e41bc0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Flag,class_RBX::BrickColor>::
              GetSetImpl<class_RBX::BrickColor_(__thiscall_RBX::Flag::*)(void)const_,void_(__thiscall_RBX::Flag::*)(class_RBX::BrickColor)>
              ::vftable;
    puVar3[2] = FUN_00e425b0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e42980;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar2,uVar4,s_TeamColor_0211fd68,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02147a70 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02147aa4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02147a94 = _DAT_02147a94 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02147a70[2])();
    if (cVar1 != '\0') {
      _DAT_02147a94 = _DAT_02147a94 & 0xfffffff3;
    }
  }
  DAT_02147a70 = RBX::Reflection::PropDescriptor<class_RBX::Flag,class_RBX::BrickColor>::vftable;
  FUN_016f3654(&LAB_018a2570);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1963 ; VA 0x00516d60 ; FUN_00516d60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516d60(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0182cac3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e429a0();
  FUN_009cb970(uVar1,s_FlagCaptured_02147b20,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02147b18 = 0x10c;
  _DAT_02147b1c = 0;
  iStack_8 = 0;
  _DAT_02147ae0 =
       RBX::Reflection::
       EventDesc<class_RBX::FlagStand,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::FlagStand::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02147b08 = uStack_1c;
  _DAT_02147b0c = uStack_18;
  _DAT_02147b10 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02147ae0 =
       RBX::Reflection::
       EventDesc<class_RBX::FlagStand,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::FlagStand::*>
       ::vftable;
  FUN_016f3654(&LAB_018a25f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1964 ; VA 0x00516ec0 ; FUN_00516ec0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00516ec0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182caec;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e429a0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xe43670;
    *(undefined8 *)(puVar3 + 6) = 0xe43eb0;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::FlagStand,class_RBX::BrickColor>::
              GetSetImpl<class_RBX::BrickColor_(__thiscall_RBX::FlagStand::*)(void)const_,void_(__thiscall_RBX::FlagStand::*)(class_RBX::BrickColor)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar2,uVar4,s_TeamColor_0211fd68,&DAT_021197d4,uStack_3c,0,0,0x1f,0,0,0);
  DAT_02147aa8 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02147adc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02147acc = _DAT_02147acc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02147aa8[2])();
    if (cVar1 != '\0') {
      _DAT_02147acc = _DAT_02147acc & 0xfffffff3;
    }
  }
  DAT_02147aa8 = RBX::Reflection::PropDescriptor<class_RBX::FlagStand,class_RBX::BrickColor>::
                 vftable;
  FUN_016f3654(&LAB_018a2600);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1965 ; VA 0x005170b0 ; FUN_005170b0 */

void FUN_005170b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e45c70(FUN_00e45f30,0,s_AddItem_02147c60,&DAT_02147c58,s_lifetime_02147c4c,DAT_018d8a10,0,
               uStack_10,0);
  FUN_016f3654(&LAB_018a2720);
  return;
}



/* FUNCTION 1966 ; VA 0x00517120 ; FUN_00517120 */

void FUN_00517120(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e45c70(FUN_00e45f30,0,s_addItem_02147c68,&DAT_02147c58,s_lifetime_02147c4c,DAT_018d8a10,0,
               uStack_10,0);
  FUN_016f3654(&LAB_018a2730);
  return;
}



/* FUNCTION 1967 ; VA 0x00517190 ; FUN_00517190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00517190(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182ce7c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e45b70();
  FUN_009cb790(uVar2,s_SetLegacyMaxItems_02147c70,3,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02147bf8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::DebrisService,void___cdecl(bool),1>::vftable;
  _DAT_02147c30 = FUN_00e46910;
  _DAT_02147c34 = 0;
  DAT_02147c38 = (undefined *)0x0;
  uStack_8 = 1;
  _DAT_02147c1c = FUN_00888530();
  puVar1 = DAT_02147c38;
  if (DAT_02147c38 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    puStack_ec = (undefined4 *)0x0;
    auStack_e8[0] = *puVar1;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8bf8) {
      FUN_016f3809(&DAT_01ea8bf8);
      if (DAT_01ea8bf8 == -1) {
        DAT_01ea8bec = FUN_005c6640;
        DAT_01ea8bf0 = FUN_005c6640;
        DAT_01ea8bf4 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ea8bf8);
      }
    }
    puStack_ec = &DAT_01ea8bec;
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_enabled_02123dec);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)puStack_ec[2])(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018a2740);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1968 ; VA 0x005173a0 ; FUN_005173a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005173a0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182ceac;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e45b70();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::DebrisService,int>::
              GetSetImpl<int_(__thiscall_RBX::DebrisService::*)(void)const_,void_(__thiscall_RBX::DebrisService::*)(int)>
              ::vftable;
    puVar3[2] = &LAB_00c777c0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e46920;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_MaxItems_02147c40,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02147b30 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02147b64 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02147b54 = _DAT_02147b54 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02147b30[2])();
    if (cVar1 != '\0') {
      _DAT_02147b54 = _DAT_02147b54 & 0xfffffff3;
    }
  }
  DAT_02147b30 = RBX::Reflection::PropDescriptor<class_RBX::DebrisService,int>::vftable;
  FUN_016f3654(&LAB_018a2760);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1969 ; VA 0x005174d0 ; FUN_005174d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005174d0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182d03a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00e469a0();
  FUN_00684820(uVar3,s_AllowTeamChangeOnTouch_02147dbc,s_Teams_02147db4,0);
  uStack_8 = 0;
  DAT_02147cf4 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar4 + 4) = 0xe480e0;
    *puVar4 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::SpawnLocation>::vftable
    ;
    puVar4[1] = &DAT_02147cf4;
    puVar4[2] = 0x105;
    puVar4[3] = 0;
    puVar4[6] = 0;
  }
  if (DAT_02147d28 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02147d28;
    DAT_02147d28 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_02147d28;
  }
  DAT_02147d28 = puVar4;
  cVar2 = (*(code *)DAT_02147cf4[3])();
  if (cVar2 != '\0') {
    _DAT_02147d18 = _DAT_02147d18 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02147cf4[2])();
  if (cVar2 != '\0') {
    _DAT_02147d18 = _DAT_02147d18 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1970 ; VA 0x00517600 ; FUN_00517600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00517600(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182d05a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00e469a0();
  FUN_00684820(uVar3,s_Neutral_0211fd74,s_Teams_02147db4,0);
  uStack_8 = 0;
  DAT_02147cbc = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar4 + 4) = 0;
    *puVar4 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::SpawnLocation>::vftable
    ;
    puVar4[1] = &DAT_02147cbc;
    puVar4[2] = 0x104;
    puVar4[3] = 0;
    puVar4[6] = 0;
  }
  if (DAT_02147cf0 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02147cf0;
    DAT_02147cf0 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_02147cf0;
  }
  DAT_02147cf0 = puVar4;
  cVar2 = (*(code *)DAT_02147cbc[3])();
  if (cVar2 != '\0') {
    _DAT_02147ce0 = _DAT_02147ce0 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02147cbc[2])();
  if (cVar2 != '\0') {
    _DAT_02147ce0 = _DAT_02147ce0 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1971 ; VA 0x00517730 ; FUN_00517730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00517730(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182d096;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00e469a0();
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar3,uVar4,s_Duration_02147da8,s_Forcefield_02147d9c,uStack_24,0,0,0x1f,0,0,0);
  DAT_02147cb8 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_02147c84 = RBX::Reflection::BoundProp<int,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar5 + 4) = 0;
    *puVar5 = RBX::Reflection::BoundProp<int,1>::BoundPropGetSet<class_RBX::SpawnLocation>::vftable;
    puVar5[1] = &DAT_02147c84;
    puVar5[2] = 0x108;
    puVar5[3] = 0;
    puVar5[6] = 0;
  }
  if (DAT_02147cb8 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_02147cb8;
    DAT_02147cb8 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_02147cb8;
  }
  DAT_02147cb8 = puVar5;
  cVar2 = (*(code *)DAT_02147c84[3])();
  if (cVar2 != '\0') {
    _DAT_02147ca8 = _DAT_02147ca8 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_02147c84[2])();
  if (cVar2 != '\0') {
    _DAT_02147ca8 = _DAT_02147ca8 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018a27d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1972 ; VA 0x00517980 ; FUN_00517980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00517980(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182d0bc;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e469a0();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xe47ee0;
    *(undefined8 *)(puVar3 + 6) = 0xe48310;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::SpawnLocation,class_RBX::BrickColor>::
              GetSetImpl<class_RBX::BrickColor_(__thiscall_RBX::SpawnLocation::*)(void)const_,void_(__thiscall_RBX::SpawnLocation::*)(class_RBX::BrickColor)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar2,uVar4,s_TeamColor_0211fd68,s_Teams_02147db4,uStack_3c,0,0,0x1f,0,0,0);
  DAT_02147d2c = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02147d60 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02147d50 = _DAT_02147d50 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02147d2c[2])();
    if (cVar1 != '\0') {
      _DAT_02147d50 = _DAT_02147d50 & 0xfffffff3;
    }
  }
  DAT_02147d2c = RBX::Reflection::PropDescriptor<class_RBX::SpawnLocation,class_RBX::BrickColor>::
                 vftable;
  FUN_016f3654(&LAB_018a2810);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1973 ; VA 0x00517bb0 ; FUN_00517bb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00517bb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182e2ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e49c40(uVar2,0);
  FUN_009cb820(uVar1,s_AdvanceToNextPageAsync_02147eac,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02147e50 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::Pages,void___cdecl(void),0>::vftable;
  _DAT_02147e88 = FUN_00e50cb0;
  _DAT_02147e8c = 0;
  _DAT_02147e74 = FUN_00888530();
  FUN_016f3654(&LAB_018a28a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1974 ; VA 0x00517c50 ; FUN_00517c50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00517c50(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182e2da;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e49c40(uVar2,0);
  FUN_009cb790(uVar1,s_GetCurrentPage_02147e90,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02147dd8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Pages,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02147e10 = FUN_00e54e30;
  _DAT_02147e14 = 0;
  _DAT_02147dfc = FUN_008882f0();
  FUN_016f3654(&LAB_018a28b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1975 ; VA 0x00517cf0 ; FUN_00517cf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00517cf0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182e30c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e49c40();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Pages,bool>::
              GetImpl<bool_(__thiscall_RBX::Pages::*)(void)const_>::vftable;
    puVar3[2] = FUN_00dd7240;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_IsFinished_02147ea0,&DAT_021197d4,uStack_24,0,0,0x15,0,0,0);
  DAT_02147e18 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02147e4c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02147e3c = _DAT_02147e3c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02147e18[2])();
    if (cVar1 != '\0') {
      _DAT_02147e3c = _DAT_02147e3c & 0xfffffff3;
    }
  }
  DAT_02147e18 = RBX::Reflection::PropDescriptor<class_RBX::Pages,bool>::vftable;
  FUN_016f3654(&LAB_018a28c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1976 ; VA 0x00517e20 ; FUN_00517e20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00517e20(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182ee0e;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e58650(uVar2,0);
  FUN_009cb820(uVar1,s_PlayerHasPass_02147f10,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02147ec8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::GamePassService,bool___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64),2>
       ::vftable;
  _DAT_02147f00 = FUN_00e591d0;
  _DAT_02147f04 = 0;
  _DAT_02147f08 = 0;
  _DAT_02147f0c = 0;
  uStack_8 = 2;
  FUN_00e58be0();
  FUN_016f3654(&LAB_018a2920);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1977 ; VA 0x00517f00 ; FUN_00517f00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00517f00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182ef7c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e59550();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::KeyframeMarker,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::KeyframeMarker::*)(void)const_,void_(__thiscall_RBX::KeyframeMarker::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
              ::vftable;
    puVar3[2] = FUN_00926ad0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e59b00;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_Value_021415bc,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02147f20 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02147f54 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02147f44 = _DAT_02147f44 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02147f20[2])();
    if (cVar1 != '\0') {
      _DAT_02147f44 = _DAT_02147f44 & 0xfffffff3;
    }
  }
  DAT_02147f20 = RBX::Reflection::
                 PropDescriptor<class_RBX::KeyframeMarker,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_018a2950);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1978 ; VA 0x00518030 ; FUN_00518030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518030(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  _DAT_01f1d06c = (float)dVar1 * DAT_018ce328;
  return;
}



/* FUNCTION 1979 ; VA 0x00518070 ; FUN_00518070 */

void FUN_00518070(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e59f10(FUN_00db6720,0,s_AddPose_0214813c,&DAT_02141ecc,0,uStack_10,0);
  FUN_016f3654(&LAB_018a29d0);
  return;
}



/* FUNCTION 1980 ; VA 0x005180d0 ; FUN_005180d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005180d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182f09a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e59bc0(uVar2,0);
  FUN_009cb790(uVar1,s_GetPoses_02148130,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02147f58 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Keyframe,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02147f90 = FUN_00e5a3f0;
  _DAT_02147f94 = 0;
  _DAT_02147f7c = FUN_0088cc80();
  FUN_016f3654(&LAB_018a2a20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1981 ; VA 0x00518170 ; FUN_00518170 */

void FUN_00518170(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e59f10(FUN_00db6ea0,0,s_RemovePose_02148144,&DAT_02141ecc,0,uStack_10,0);
  FUN_016f3654(&LAB_018a2a30);
  return;
}



/* FUNCTION 1982 ; VA 0x005181d0 ; FUN_005181d0 */

void FUN_005181d0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e59f10(FUN_00e5a160,0,s_AddMarker_02148164,s_marker_0214815c,0,uStack_10,0);
  FUN_016f3654(&LAB_018a2a80);
  return;
}



/* FUNCTION 1983 ; VA 0x00518230 ; FUN_00518230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518230(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182f0ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e59bc0(uVar2,0);
  FUN_009cb790(uVar1,s_GetMarkers_02148150,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02148028 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Keyframe,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02148060 = FUN_00e5a2e0;
  _DAT_02148064 = 0;
  _DAT_0214804c = FUN_0088cc80();
  FUN_016f3654(&LAB_018a2ad0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1984 ; VA 0x005182d0 ; FUN_005182d0 */

void FUN_005182d0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e59f10(FUN_00e5a5c0,0,s_RemoveMarker_02148170,s_marker_0214815c,0,uStack_10,0);
  FUN_016f3654(&LAB_018a2ae0);
  return;
}



/* FUNCTION 1985 ; VA 0x00518330 ; FUN_00518330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518330(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182f0ec;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e59bc0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Keyframe,float>::
              GetSetImpl<float_(__thiscall_RBX::Keyframe::*)(void)const_,void_(__thiscall_RBX::Keyframe::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00db6cf0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e5a680;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,&DAT_02148180,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_021480f8 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0214812c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0214811c = _DAT_0214811c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021480f8[2])();
    if (cVar1 != '\0') {
      _DAT_0214811c = _DAT_0214811c & 0xfffffff3;
    }
  }
  DAT_021480f8 = RBX::Reflection::PropDescriptor<class_RBX::Keyframe,float>::vftable;
  FUN_016f3654(&LAB_018a2b30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1986 ; VA 0x00518460 ; FUN_00518460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518460(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  _DAT_01f1d290 = (float)dVar1 * DAT_018ce328;
  return;
}



/* FUNCTION 1987 ; VA 0x005184a0 ; FUN_005184a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005184a0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182f92c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e5ae20();
  FUN_009cb820(uVar1,s_GetAnimations_02148428,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02148330 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::KeyframeSequenceProvider,class_std::shared_ptr<class_RBX::Instance>___cdecl(__int64),1>
       ::vftable;
  _DAT_02148368 = FUN_00e5f650;
  _DAT_0214836c = 0;
  DAT_02148370 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02148354 = FUN_0088cdc0();
  if (DAT_02148370 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1470(DAT_02148370);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(s_userId_0211fb64);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a2bb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1988 ; VA 0x00518620 ; FUN_00518620 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518620(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined4 uStack_20;
  undefined *puStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182f98c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  puStack_1c = &DAT_02148218;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e5ae20();
  FUN_009cb790(uVar1,s_GetKeyframeSequence_021483e4,1,CONCAT44(puStack_1c,uStack_20),0);
  _DAT_02148260 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::KeyframeSequenceProvider,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_RBX::ContentId),1>
       ::vftable;
  _DAT_02148298 = FUN_00e5ffd0;
  _DAT_0214829c = 0;
  DAT_021482a0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02148284 = FUN_0088cdc0();
  if (DAT_021482a0 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_008bc760(DAT_021482a0);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088d190();
  uVar3 = FUN_0086e3d0(s_assetId_0211bf40);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a2bd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1989 ; VA 0x005187a0 ; FUN_005187a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005187a0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182f9ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e5ae20();
  FUN_009cb820(uVar1,s_GetKeyframeSequenceAsync_021483c8,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02148218 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::KeyframeSequenceProvider,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_RBX::ContentId),1>
       ::vftable;
  _DAT_02148250 = FUN_00e5faf0;
  _DAT_02148254 = 0;
  DAT_02148258 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214823c = FUN_0088cdc0();
  if (DAT_02148258 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_008bc760(DAT_02148258);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088d190();
  uVar3 = FUN_0086e3d0(s_assetId_0211bf40);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a2bf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1990 ; VA 0x00518920 ; FUN_00518920 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518920(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182fa1e;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02148218;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e5ae20(uVar2,&DAT_02148218);
  FUN_009cb790(uVar1,s_GetKeyframeSequenceById_02148404,1,CONCAT44(puVar3,uVar2),0);
  _DAT_021482a8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::KeyframeSequenceProvider,class_std::shared_ptr<class_RBX::Instance>___cdecl(__int64,bool),2>
       ::vftable;
  _DAT_021482e0 = FUN_00e5fd20;
  _DAT_021482e4 = 0;
  DAT_021482e8 = 0;
  DAT_021482ec = 0;
  uStack_8 = 2;
  FUN_00e5ead0();
  FUN_016f3654(&LAB_018a2c10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1991 ; VA 0x005189e0 ; FUN_005189e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_005189e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182fa3a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e5ae20(uVar2,0);
  FUN_009cb790(uVar1,s_GetMemStats_0214841c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021482f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::KeyframeSequenceProvider,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02148328 = FUN_00e601c0;
  _DAT_0214832c = 0;
  _DAT_02148314 = FUN_008881d0();
  FUN_016f3654(&LAB_018a2c50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1992 ; VA 0x00518a80 ; FUN_00518a80 */

void FUN_00518a80(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e5c040(FUN_00e623c0,0,s_RegisterActiveKeyframeSequence_0214838c,s_keyframeSequence_02148378,
               0,uStack_10,0);
  FUN_016f3654(&LAB_018a2c60);
  return;
}



/* FUNCTION 1993 ; VA 0x00518ae0 ; FUN_00518ae0 */

void FUN_00518ae0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00e5c040(FUN_00e62500,0,s_RegisterKeyframeSequence_021483ac,s_keyframeSequence_02148378,0,
               uStack_10,0);
  FUN_016f3654(&LAB_018a2cb0);
  return;
}



/* FUNCTION 1994 ; VA 0x00518b40 ; FUN_00518b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518b40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183012c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00e63280();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Animation,class_RBX::AnimationId>::
              GetSetImpl<class_RBX::AnimationId_(__thiscall_RBX::Animation::*)(void)const_,void_(__thiscall_RBX::Animation::*)(class_RBX::AnimationId)>
              ::vftable;
    puVar3[2] = FUN_00926ad0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00e63b20;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = thunk_FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,"AnimationId",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,0);
  DAT_01f1d4b0 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::AnimationId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01f1d4e4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01f1d4d4 = _DAT_01f1d4d4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01f1d4b0[2])();
    if (cVar1 != '\0') {
      _DAT_01f1d4d4 = _DAT_01f1d4d4 & 0xfffffff3;
    }
  }
  DAT_01f1d4b0 = RBX::Reflection::PropDescriptor<class_RBX::Animation,class_RBX::AnimationId>::
                 vftable;
  FUN_016f3654(&LAB_018a2d10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1995 ; VA 0x00518c80 ; FUN_00518c80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518c80(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  _DAT_01f1d708 = (float)dVar1 * DAT_018ce328;
  return;
}



/* FUNCTION 1996 ; VA 0x00518cc0 ; FUN_00518cc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518cc0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183023a;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_02129168;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e63c60(uVar2,&DAT_02129168);
  FUN_009cb790(uVar1,s_GetPlayingAnimationTracks_02124190,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02148438 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AnimationController,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_02148470 = FUN_00e64240;
  _DAT_02148474 = 0;
  _DAT_0214845c = FUN_008882f0();
  FUN_016f3654(&LAB_018a2d90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1997 ; VA 0x00518d60 ; FUN_00518d60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518d60(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined4 uStack_20;
  undefined *puStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183029c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  puStack_1c = &DAT_02129120;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e63c60();
  FUN_009cb790(uVar1,s_LoadAnimation_02124170,0,CONCAT44(puStack_1c,uStack_20),0);
  _DAT_02148478 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AnimationController,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_021484b0 = FUN_00e642a0;
  _DAT_021484b4 = 0;
  DAT_021484b8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0214849c = FUN_0088cdc0();
  if (DAT_021484b8 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_006874f0(DAT_021484b8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_animation_02124164);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018a2da0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1998 ; VA 0x00518ee0 ; FUN_00518ee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00518ee0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  undefined4 uStack_2c;
  undefined *puStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_018302d3;
  pvStack_10 = ExceptionList;
  uStack_2c = CONCAT31(uStack_2c._1_3_,1);
  puStack_28 = &DAT_021291a8;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00e63c60();
  FUN_009cb970(uVar1,s_AnimationPlayed_021241bc,0,CONCAT44(puStack_28,uStack_2c),0);
  _DAT_021484f4 = 0x5c;
  iStack_8 = 0;
  _DAT_021484c0 =
       RBX::Reflection::
       EventDesc<class_RBX::AnimationController,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::AnimationController::*>
       ::vftable;
  FUN_0086e3d0(s_animationTrack_021241ac);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_021484e8 = uStack_1c;
  _DAT_021484ec = uStack_18;
  _DAT_021484f0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_021484c0 =
       RBX::Reflection::
       EventDesc<class_RBX::AnimationController,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::AnimationController::*>
       ::vftable;
  FUN_016f3654(&LAB_018a2df0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1999 ; VA 0x00519050 ; FUN_00519050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00519050(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  _DAT_01f1d930 = (float)dVar1 * DAT_018ce328;
  return;
}


