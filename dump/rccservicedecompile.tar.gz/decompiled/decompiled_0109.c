/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 27250 ; VA 0x00c0e1d0 ; FUN_00c0e1d0 */

void FUN_00c0e1d0(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_PlayerHasEmptyApiParameterValue",0x2d);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27251 ; VA 0x00c0e270 ; FUN_00c0e270 */

void FUN_00c0e270(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_SetGetPolicyInfoForPlayerAsyncDelegateError_NotInStudioPlayMode",0x4d)
  ;
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27252 ; VA 0x00c0e310 ; FUN_00c0e310 */

void FUN_00c0e310(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_StoreHttpResponseeError",0x25);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27253 ; VA 0x00c0e3b0 ; FUN_00c0e3b0 */

void FUN_00c0e3b0(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_ParsingError_WrongFormat",0x26);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27254 ; VA 0x00c0e450 ; FUN_00c0e450 */

void FUN_00c0e450(void)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("PolicyService_ParsingError_WrongFormatInStoredJson",0x32);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27255 ; VA 0x00c0e4f0 ; FUN_00c0e4f0 */

int __thiscall FUN_00c0e4f0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_dc [8];
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  int *piStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  int *piStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined auStack_9c [16];
  undefined4 uStack_8c;
  undefined *puStack_88;
  undefined *puStack_84;
  int *piStack_80;
  undefined auStack_70 [16];
  int iStack_60;
  undefined auStack_58 [4];
  int *piStack_54;
  undefined auStack_50 [4];
  int *piStack_4c;
  undefined auStack_48 [4];
  int *piStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined *puStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805bb0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  if (DAT_01d681e0 != '\0') {
    piStack_80 = (int *)0xc0e52e;
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(param_1 + 0x80) + 0x44))();
  }
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    if ((iVar5 != 0) && (param_1 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
      piStack_80 = (int *)0xc0e549;
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar5 = *(int *)(param_1 + 0xc);
      piStack_80 = (int *)0xc0e55f;
      iVar1 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
          (uint)*(ushort *)(iVar1 + 0x1da)) {
        piStack_80 = (int *)&LAB_0064e290;
        puStack_84 = &DAT_01eadc4c;
        puStack_88 = (undefined *)0xc0e58d;
        FUN_005789c0();
        piStack_80 = (int *)0xc0e595;
        piStack_80 = (int *)FUN_0064e320();
        puStack_84 = (undefined *)0xc0e59d;
        piVar2 = (int *)FUN_008aa140();
        piStack_14 = piVar2;
        if (*piVar2 == 0) {
          piStack_80 = (int *)0xc0e5ad;
          piStack_80 = (int *)FUN_00bc47d0();
          puStack_84 = auStack_48;
          puStack_88 = (undefined *)0xc0e5b9;
          piVar3 = (int *)FUN_008a9ba0();
          piVar2 = piStack_14;
          iVar5 = *piVar3;
          iVar1 = piVar3[1];
          *piVar3 = 0;
          piVar3[1] = 0;
          *piStack_14 = iVar5;
          piVar3 = (int *)piStack_14[1];
          piStack_14[1] = iVar1;
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar5 = piVar3[1] + -1;
            piVar3[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              piStack_80 = (int *)0xc0e5e9;
              (**(code **)*piVar3)();
              LOCK();
              iVar5 = piVar3[2] + -1;
              piVar3[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                piStack_80 = (int *)0xc0e5f9;
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          if (piStack_44 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_44[1] + -1;
            piStack_44[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              piStack_80 = (int *)0xc0e60f;
              (**(code **)*piStack_44)();
              LOCK();
              iVar5 = piStack_44[2] + -1;
              piStack_44[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                piStack_80 = (int *)0xc0e61f;
                (**(code **)(*piStack_44 + 4))();
              }
            }
          }
        }
        iVar5 = iStack_20;
        iStack_28 = *piVar2;
        if (iStack_28 != 0) {
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[1] = param_3[1] + 1;
            UNLOCK();
          }
          puStack_84 = (undefined *)param_2;
          piStack_80 = param_3;
          puStack_88 = auStack_70;
          uStack_8c = 0xc0e667;
          FUN_00c0b1a0();
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          if (iStack_60 == 0) {
            piStack_80 = (int *)0x1962508;
                    /* WARNING: Subroutine does not return */
            puStack_84 = &UNK_00c0e852;
            FUN_016757c0();
          }
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[2] = param_3[2] + 1;
            UNLOCK();
          }
          piStack_18 = param_3;
          uStack_24 = param_2;
          uStack_38 = param_2;
          piStack_34 = param_3;
          puStack_84 = auStack_58;
          uStack_8._0_1_ = 2;
          piStack_80 = (int *)iVar5;
          puStack_88 = (undefined *)0xc0e6a3;
          piStack_14 = (int *)FUN_0068f9a0();
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[2] = param_3[2] + 1;
            UNLOCK();
          }
          piStack_1c = param_3;
          uStack_40 = param_2;
          piStack_3c = param_3;
          puStack_84 = auStack_50;
          uStack_8._0_1_ = 4;
          piStack_80 = (int *)iVar5;
          puStack_88 = (undefined *)0xc0e6d4;
          puVar4 = (undefined4 *)FUN_0068f9a0();
          puStack_2c = auStack_9c;
          uStack_38 = 0;
          piStack_34 = (int *)0x0;
          uStack_a0 = 0;
          uStack_b4 = *piStack_14;
          uStack_b0 = piStack_14[1];
          *piStack_14 = 0;
          piStack_14[1] = 0;
          uStack_ac = uStack_24;
          piStack_a8 = piStack_18;
          uStack_a4 = param_4;
          uStack_b8 = 0xc0e739;
          FUN_00c09340();
          uStack_40 = 0;
          piStack_3c = (int *)0x0;
          uStack_c0 = 0;
          uStack_d0 = *puVar4;
          uStack_cc = puVar4[1];
          *puVar4 = 0;
          puVar4[1] = 0;
          uStack_c8 = param_2;
          piStack_c4 = piStack_1c;
          uStack_d4 = 0xc0e78a;
          FUN_00c09480();
          uStack_c0 = 0;
          piStack_c4 = (int *)0x0;
          uStack_8._0_1_ = 7;
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[1] = param_3[1] + 1;
            UNLOCK();
          }
          FUN_00c0b1a0(auStack_dc,param_2,param_3);
          uStack_8 = CONCAT31(uStack_8._1_3_,5);
          FUN_00bcb620();
          if (piStack_4c != (int *)0x0) {
            LOCK();
            iVar5 = piStack_4c[2] + -1;
            piStack_4c[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              piStack_80 = (int *)0xc0e7e9;
              (**(code **)(*piStack_4c + 4))();
            }
          }
          if (piStack_54 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_54[2] + -1;
            piStack_54[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              piStack_80 = (int *)0xc0e7fe;
              (**(code **)(*piStack_54 + 4))();
            }
          }
          piStack_80 = (int *)0xc0e806;
          iVar5 = FUN_005507b0();
          if (param_3 != (int *)0x0) {
            LOCK();
            piVar2 = param_3 + 1;
            iVar1 = *piVar2;
            iVar5 = *piVar2;
            *piVar2 = iVar1 + -1;
            UNLOCK();
            if (iVar1 + -1 == 0) {
              piStack_80 = (int *)0xc0e81c;
              iVar5 = (**(code **)*param_3)();
              LOCK();
              piVar2 = param_3 + 2;
              iVar1 = *piVar2;
              *piVar2 = *piVar2 + -1;
              UNLOCK();
              if (iVar1 == 1) {
                piStack_80 = (int *)0xc0e82b;
                iVar5 = (**(code **)(*param_3 + 4))();
              }
            }
          }
          ExceptionList = pvStack_10;
          return iVar5;
        }
      }
    }
  }
  piStack_80 = (int *)0x1962520;
                    /* WARNING: Subroutine does not return */
  puStack_84 = (undefined *)0xc0e848;
  FUN_016757c0();
}



/* FUNCTION 27256 ; VA 0x00c0e860 ; FUN_00c0e860 */

void __thiscall
FUN_00c0e860(int *param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  char cVar1;
  uint auStack_50 [2];
  undefined auStack_48 [24];
  uint auStack_30 [2];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805bd8;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  FUN_008f7870(param_1);
  cVar1 = FUN_008ff0d0();
  if ((cVar1 == '\0') || (cVar1 = FUN_008ff0a0(), cVar1 != '\0')) {
    if (DAT_01d681e0 == '\0') {
      (**(code **)(*param_1 + 0xd4))();
    }
    else {
      (**(code **)(*(int *)param_1[0x20] + 0x30))();
    }
  }
  else {
    auStack_30[0] = 0;
    if (param_2 != 0) {
      auStack_30[0] = param_2;
      if ((param_2 & 1) == 0) {
        (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_28,0);
      }
      else {
        uStack_28 = param_4;
        uStack_24 = param_5;
        uStack_20 = param_6;
        uStack_1c = param_7;
        uStack_18 = param_8;
      }
    }
    if ((uint *)(param_1 + 0x16) != auStack_30) {
      auStack_50[0] = 0;
      uStack_8._0_1_ = 2;
      FUN_005880d0(auStack_30);
      FUN_005880d0(param_1 + 0x16);
      FUN_005880d0(auStack_50);
      uStack_8._0_1_ = 3;
      if (auStack_50[0] != 0) {
        if (((auStack_50[0] & 1) == 0) && (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
        }
        auStack_50[0] = 0;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (auStack_30[0] != 0) {
      if (((auStack_30[0] & 1) == 0) && (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_30[0] & 0xfffffffe))(&uStack_28,&uStack_28,2);
      }
      auStack_30[0] = 0;
    }
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27257 ; VA 0x00c0e9e0 ; FUN_00c0e9e0 */

void __thiscall FUN_00c0e9e0(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0x7c)) {
    *(int *)(param_1 + 0x7c) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 27258 ; VA 0x00c0ea00 ; FUN_00c0ea00 */

void __thiscall FUN_00c0ea00(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0x78)) {
    *(int *)(param_1 + 0x78) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 27259 ; VA 0x00c0ea20 ; FUN_00c0ea20 */

void __thiscall FUN_00c0ea20(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c0ea70();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27260 ; VA 0x00c0ea70 ; FUN_00c0ea70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c0ea70(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805c06;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8b3c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8b3c);
    if (DAT_01ef8b3c == -1) {
      uStack_8 = 0;
      FUN_009ca470("TriStateBoolean");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef8ad8 = RBX::Reflection::EnumDesc<enum_RBX::TriStateBoolean>::vftable;
      FUN_009caf20(&DAT_01d68208,3);
      FUN_016f3654(&LAB_01893340);
      FUN_016f37bf(&DAT_01ef8b3c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef8ad8;
}



/* FUNCTION 27261 ; VA 0x00c0eb20 ; FUN_00c0eb20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c0eb20(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8b4c) {
    FUN_016f3809(&DAT_01ef8b4c);
    if (DAT_01ef8b4c == -1) {
      _DAT_01ef8b40 = FUN_005c65e0;
      _DAT_01ef8b44 = FUN_005c65e0;
      _DAT_01ef8b48 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef8b4c);
    }
  }
  return &DAT_01ef8b40;
}



/* FUNCTION 27262 ; VA 0x00c0eb90 ; FUN_00c0eb90 */

int FUN_00c0eb90(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int aiStack_4c [4];
  undefined4 uStack_3c;
  undefined *puStack_38;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805c28;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffcc;
  uStack_3c = 0xc0ebba;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008f7870();
  if ((iVar4 == 0) || (*(int *)(iVar4 + 0x4a0) == 1)) {
    puStack_38 = auStack_28;
    uStack_8 = 0;
    uStack_3c = 0xc0ebde;
    FUN_0153ef20();
    piStack_1c = aiStack_4c;
    uStack_8._0_1_ = 1;
    FUN_0054ef60(param_1);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(&DAT_01d681e8);
    uStack_8._0_1_ = 1;
    FUN_01542df0();
    uStack_8._0_1_ = 0;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        puStack_38 = (undefined *)0xc0ec32;
        (**(code **)*piStack_24)();
        LOCK();
        iVar4 = piStack_24[2] + -1;
        piStack_24[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          puStack_38 = (undefined *)0xc0ec42;
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    puStack_38 = auStack_20;
    uStack_3c = 0xc0ec4b;
    FUN_0153ef20();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puStack_38 = (undefined *)0x0;
    iVar4 = FUN_01541260();
    piVar3 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puStack_38 = (undefined *)0xc0ec7b;
        iVar4 = (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          puStack_38 = (undefined *)0xc0ec8a;
          iVar4 = (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 27263 ; VA 0x00c0ec9d ; Catch@00c0ec9d */

undefined4 Catch_00c0ec9d(void)

{
  int unaff_EBP;
  
  if (DAT_01d681e0 == '\0') {
    (**(code **)(**(int **)(unaff_EBP + -0x14) + 0xe0))();
  }
  else {
    (**(code **)(**(int **)(*(int *)(unaff_EBP + -0x14) + 0x80) + 0x3c))();
  }
  return 0xc0ec8a;
}



/* FUNCTION 27264 ; VA 0x00c0ecd0 ; FUN_00c0ecd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c0ecd0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805c60;
  pvStack_10 = ExceptionList;
  if (DAT_01ef8b6c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8d80) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef8d80);
      if (DAT_01ef8d80 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ProximityPromptService",1,uStack_20,0,0,0x1b,0,0);
        _DAT_01ef8d78 = RBX::Creator<class_RBX::ProximityPromptService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef8b70,&DAT_01ef8d78);
        FUN_016f3654(FUN_018934c0);
        FUN_016f37bf(&DAT_01ef8d80);
      }
    }
    DAT_01ef8b6c = &DAT_01ef8b70;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef8b6c;
}



/* FUNCTION 27265 ; VA 0x00c0edd0 ; FUN_00c0edd0 */

void FUN_00c0edd0(void)

{
  int iVar1;
  
  if (DAT_01ef8d84 == 0) {
    iVar1 = FUN_00c0ecd0();
    DAT_01ef8d84 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27266 ; VA 0x00c0edf0 ; FUN_00c0edf0 */

void FUN_00c0edf0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  int iVar1;
  
  iVar1 = FUN_006d3cd0(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = *(undefined4 *)*param_4;
  *(undefined4 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = 0;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  return;
}



/* FUNCTION 27267 ; VA 0x00c0ee30 ; FUN_00c0ee30 */

int __thiscall FUN_00c0ee30(int *param_1,int param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  
  iVar6 = *param_1;
  iVar2 = (param_1[1] - iVar6) / 0xc;
  if (iVar2 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar6) / 0xc;
  uVar10 = uVar7;
  if ((uVar3 <= 0x15555555 - (uVar3 >> 1)) && (uVar10 = (uVar3 >> 1) + uVar3, uVar10 < uVar7)) {
    uVar10 = uVar7;
  }
  iVar4 = FUN_00618050(uVar10);
  uVar1 = *param_3;
  iVar8 = ((param_2 - iVar6) / 0xc) * 0xc;
  *(undefined4 *)(iVar8 + 4 + iVar4) = 0;
  *(undefined4 *)(iVar8 + 8 + iVar4) = 0;
  *(undefined4 *)(iVar8 + iVar4) = uVar1;
  *(undefined4 *)(iVar8 + 4 + iVar4) = param_3[1];
  *(undefined4 *)(iVar8 + 8 + iVar4) = param_3[2];
  param_3[1] = 0;
  param_3[2] = 0;
  iVar9 = param_1[1];
  iVar6 = *param_1;
  iVar5 = iVar4;
  if (param_2 != iVar9) {
    FUN_00604ed0(iVar6,param_2,iVar4,param_1);
    iVar9 = param_1[1];
    iVar5 = iVar8 + 0xc + iVar4;
    iVar6 = param_2;
  }
  FUN_00604ed0(iVar6,iVar9,iVar5,param_1);
  if (*param_1 != 0) {
    FUN_00602e00(*param_1,param_1[1],param_1);
    iVar6 = *param_1;
    uVar7 = ((param_1[2] - iVar6) / 0xc) * 0xc;
    iVar9 = iVar6;
    if (0xfff < uVar7) {
      iVar9 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar7);
  }
  *param_1 = iVar4;
  param_1[1] = iVar4 + (iVar2 * 3 + 3) * 4;
  param_1[2] = iVar4 + uVar10 * 0xc;
  return *param_1 + iVar8;
}



/* FUNCTION 27268 ; VA 0x00c0efc0 ; FUN_00c0efc0 */

void __thiscall FUN_00c0efc0(float *param_1,float *param_2,byte *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  float fVar3;
  uint uVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805c70;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  fVar3 = param_1[1];
  uVar4 = (uint)param_1[6] &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193;
  fVar5 = *(float *)((int)param_1[3] + uVar4 * 8);
  pfStack_1c = param_1;
  if (fVar3 != fVar5) {
    fVar3 = **(float **)((int)param_1[3] + 4 + uVar4 * 8);
    while (fVar3 != fVar5) {
      fVar3 = *(float *)((int)fVar3 + 4);
      if (*(int *)param_3 == *(int *)((int)fVar3 + 8)) {
        ExceptionList = &pvStack_10;
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        puStack_14 = &stack0xffffffd0;
        FUN_006129c0();
        FUN_01674ea0(param_4,0x18);
        *param_2 = fVar3;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  ExceptionList = &pvStack_10;
  if (fVar3 != fVar5) {
    ExceptionList = &pvStack_10;
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar3;
    **(undefined4 **)((int)fVar3 + 4) = param_4;
    fVar1 = *(float *)((int)fVar3 + 4);
    *(undefined4 *)((int)fVar3 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar4 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar4 * 8) = param_4;
  }
  else if (fVar1 == fVar3) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar4 * 8);
    *(float **)((int)fVar5 + 4 + uVar4 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar4 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar4 * 8) + 4);
    }
  }
  fVar3 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar3 + (double)(&DAT_018c0d90)[-((int)fVar3 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar3 < 0x200) {
      fVar3 = (float)((int)fVar3 << 3);
    }
    else if ((uint)fVar3 < 0x1fffffff) {
      fVar3 = (float)((int)fVar3 * 2);
    }
    FUN_005cb500(fVar3);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar3 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00c0efc0(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar3);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27269 ; VA 0x00c0f1a8 ; Catch_All@00c0f1a8 */

void Catch_All_00c0f1a8(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00c0fcd0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27270 ; VA 0x00c0f1d0 ; FUN_00c0f1d0 */

float * FUN_00c0f1d0(float *param_1,float *param_2)

{
  float *pfVar1;
  float *pfVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  int *piVar8;
  float fVar9;
  int iVar10;
  float *pfVar11;
  float *pfVar12;
  float *pfVar13;
  float *pfVar14;
  float *pfVar15;
  float *pfVar16;
  
  if (param_1 == param_2) {
    return param_2;
  }
  pfVar15 = param_1 + 3;
  if (pfVar15 == param_2) {
    return param_2;
  }
  pfVar13 = param_1 + 5;
  do {
    fVar3 = *pfVar15;
    fVar5 = *pfVar13;
    fVar6 = pfVar13[-1];
    fVar4 = *param_1;
    pfVar13[-1] = 0.0;
    *pfVar13 = 0.0;
    if (fVar4 <= fVar3) {
      fVar4 = pfVar13[-5];
      pfVar11 = pfVar13 + -5;
      pfVar12 = pfVar15;
      while (pfVar14 = pfVar11, fVar3 < fVar4) {
        fVar7 = pfVar14[1];
        fVar9 = pfVar14[2];
        pfVar14[1] = 0.0;
        pfVar14[2] = 0.0;
        pfVar12[1] = fVar7;
        piVar8 = (int *)pfVar12[2];
        *pfVar12 = fVar4;
        pfVar12[2] = fVar9;
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar10 = piVar8[1] + -1;
          piVar8[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            iVar10 = piVar8[2] + -1;
            piVar8[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
        pfVar11 = pfVar14 + -3;
        pfVar12 = pfVar14;
        fVar4 = pfVar14[-3];
      }
      pfVar12[1] = fVar6;
      piVar8 = (int *)pfVar12[2];
      *pfVar12 = fVar3;
      pfVar12[2] = fVar5;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar10 = piVar8[1] + -1;
        piVar8[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar10 = piVar8[2] + -1;
          piVar8[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
    }
    else {
      pfVar12 = pfVar13 + 1;
      if (pfVar15 != param_1) {
        pfVar14 = pfVar13 + 3;
        pfVar11 = pfVar13;
        do {
          pfVar16 = pfVar11 + -3;
          pfVar1 = pfVar14 + -3;
          pfVar12 = pfVar12 + -3;
          *pfVar12 = pfVar11[-5];
          fVar4 = pfVar11[-4];
          fVar7 = *pfVar16;
          pfVar11[-4] = 0.0;
          *pfVar16 = 0.0;
          pfVar14[-4] = fVar4;
          piVar8 = (int *)*pfVar1;
          *pfVar1 = fVar7;
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar10 = piVar8[1] + -1;
            piVar8[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piVar8)();
              LOCK();
              iVar10 = piVar8[2] + -1;
              piVar8[2] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
          pfVar2 = pfVar11 + -5;
          pfVar14 = pfVar1;
          pfVar11 = pfVar16;
        } while (pfVar2 != param_1);
      }
      param_1[1] = fVar6;
      piVar8 = (int *)param_1[2];
      *param_1 = fVar3;
      param_1[2] = fVar5;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar10 = piVar8[1] + -1;
        piVar8[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar10 = piVar8[2] + -1;
          piVar8[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
    }
    pfVar13 = pfVar13 + 3;
    pfVar15 = pfVar15 + 3;
  } while (pfVar15 != param_2);
  return param_2;
}



/* FUNCTION 27271 ; VA 0x00c0f3e0 ; FUN_00c0f3e0 */

uint FUN_00c0f3e0(int param_1,int param_2)

{
  uint *puVar1;
  float *pfVar2;
  float fVar3;
  float fVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int *piVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  undefined4 *puVar12;
  int iVar13;
  float fStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  uint uStack_10;
  int iStack_c;
  int iStack_8;
  
  uVar10 = (param_2 - param_1) / 0xc;
  iVar11 = (int)uVar10 >> 1;
  if (0 < iVar11) {
    iStack_14 = uVar10 - 1;
    iStack_8 = iStack_14 >> 1;
    puStack_18 = (undefined4 *)(param_1 + (iVar11 * 3 + 1) * 4);
    uStack_10 = uVar10;
    do {
      uStack_20 = puStack_18[-3];
      puVar12 = puStack_18 + -3;
      iVar11 = iVar11 + -1;
      piStack_1c = (int *)puStack_18[-2];
      fVar3 = (float)puStack_18[-4];
      *puVar12 = 0;
      puStack_18[-2] = 0;
      iVar9 = iVar11;
      fStack_24 = fVar3;
      puStack_18 = puVar12;
      if (iVar11 < iStack_8) {
        do {
          fVar4 = *(float *)(param_1 + 0xc + iVar9 * 0x18);
          pfVar2 = (float *)(param_1 + 0x18 + iVar9 * 0x18);
          iStack_c = iVar9 * 2 + 1 + ((*pfVar2 <= fVar4 && fVar4 != *pfVar2) ^ 1);
          uVar6 = *(undefined4 *)(param_1 + 8 + iStack_c * 0xc);
          *(undefined4 *)(param_1 + iVar9 * 0xc) = *(undefined4 *)(param_1 + iStack_c * 0xc);
          uVar7 = *(undefined4 *)(param_1 + 4 + iStack_c * 0xc);
          *(undefined4 *)(param_1 + 4 + iStack_c * 0xc) = 0;
          *(undefined4 *)(param_1 + 8 + iStack_c * 0xc) = 0;
          *(undefined4 *)(param_1 + 4 + iVar9 * 0xc) = uVar7;
          piVar8 = *(int **)(param_1 + 8 + iVar9 * 0xc);
          *(undefined4 *)(param_1 + 8 + iVar9 * 0xc) = uVar6;
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar9 = piVar8[1] + -1;
            piVar8[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)*piVar8)();
              LOCK();
              iVar9 = piVar8[2] + -1;
              piVar8[2] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
          iVar9 = iStack_c;
        } while (iStack_c < iStack_8);
      }
      if ((iVar9 == iStack_8) && ((uStack_10 & 1) == 0)) {
        FUN_00613d30(param_1 + (uStack_10 * 3 + -3) * 4);
        iVar9 = iStack_14;
      }
      while (iVar11 < iVar9) {
        iVar13 = iVar9 + -1 >> 1;
        fVar4 = *(float *)(param_1 + iVar13 * 0xc);
        if (fVar3 <= fVar4) break;
        uVar6 = *(undefined4 *)(param_1 + 4 + iVar13 * 0xc);
        uVar7 = *(undefined4 *)(param_1 + 8 + iVar13 * 0xc);
        *(undefined4 *)(param_1 + 4 + iVar13 * 0xc) = 0;
        *(undefined4 *)(param_1 + 8 + iVar13 * 0xc) = 0;
        *(undefined4 *)(param_1 + 4 + iVar9 * 0xc) = uVar6;
        piVar8 = *(int **)(param_1 + 8 + iVar9 * 0xc);
        *(float *)(param_1 + iVar9 * 0xc) = fVar4;
        *(undefined4 *)(param_1 + 8 + iVar9 * 0xc) = uVar7;
        iVar9 = iVar13;
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar13 = piVar8[1] + -1;
          piVar8[1] = iVar13;
          UNLOCK();
          if (iVar13 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            iVar13 = piVar8[2] + -1;
            piVar8[2] = iVar13;
            UNLOCK();
            if (iVar13 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
      }
      uVar10 = FUN_00613d30(&fStack_24);
      piVar8 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_1c + 1);
        uVar5 = *puVar1;
        uVar10 = *puVar1;
        *puVar1 = uVar5 - 1;
        UNLOCK();
        if (uVar5 - 1 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          puVar1 = (uint *)(piVar8 + 2);
          uVar5 = *puVar1;
          uVar10 = *puVar1;
          *puVar1 = uVar5 - 1;
          UNLOCK();
          if (uVar5 - 1 == 0) {
            uVar10 = (**(code **)(*piVar8 + 4))();
          }
        }
      }
    } while (0 < iVar11);
  }
  return uVar10;
}



/* FUNCTION 27272 ; VA 0x00c0f5e0 ; FUN_00c0f5e0 */

void FUN_00c0f5e0(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  fVar1 = *param_2;
  fVar5 = *param_1;
  fVar4 = fVar1;
  if ((fVar1 < fVar5) && (param_2 != param_1)) {
    fVar4 = param_2[1];
    param_2[1] = param_1[1];
    param_1[1] = fVar4;
    fVar2 = param_2[2];
    fVar3 = param_1[2];
    *param_2 = fVar5;
    *param_1 = fVar1;
    fVar4 = *param_2;
    param_2[2] = fVar3;
    param_1[2] = fVar2;
    fVar5 = fVar1;
  }
  fVar1 = *param_3;
  if (fVar1 < fVar4) {
    if (param_3 != param_2) {
      fVar5 = param_3[1];
      param_3[1] = param_2[1];
      param_2[1] = fVar5;
      fVar2 = param_3[2];
      fVar3 = param_2[2];
      *param_3 = fVar4;
      *param_2 = fVar1;
      fVar5 = *param_1;
      param_3[2] = fVar3;
      param_2[2] = fVar2;
      fVar4 = fVar1;
    }
    if ((fVar4 < fVar5) && (param_2 != param_1)) {
      fVar1 = param_2[1];
      param_2[1] = param_1[1];
      param_1[1] = fVar1;
      fVar1 = param_2[2];
      fVar2 = param_1[2];
      *param_2 = fVar5;
      param_2[2] = fVar2;
      *param_1 = fVar4;
      param_1[2] = fVar1;
    }
  }
  return;
}



/* FUNCTION 27273 ; VA 0x00c0f690 ; FUN_00c0f690 */

void FUN_00c0f690(uint *param_1,float *param_2,float *param_3,uint param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  float *pfVar5;
  float *pfVar6;
  float *pfVar7;
  float *pfVar8;
  float *pfVar9;
  float *pfVar10;
  float *pfVar11;
  float *pfStack_8;
  
  pfVar9 = param_2 + (((int)param_3 - (int)param_2) / 0xc >> 1) * 3;
  pfVar6 = param_3 + -3;
  pfStack_8 = (float *)(param_4 & 0xff);
  iVar4 = ((int)pfVar6 - (int)param_2) / 0xc;
  if (iVar4 < 0x29) {
    FUN_00c0f5e0(param_2,pfVar9,pfVar6,param_4);
  }
  else {
    iVar4 = iVar4 + 1 >> 3;
    FUN_00c0f5e0(param_2,param_2 + iVar4 * 3,param_2 + iVar4 * 6,param_4);
    FUN_00c0f5e0(pfVar9 + iVar4 * -3,pfVar9,pfVar9 + iVar4 * 3,pfStack_8);
    FUN_00c0f5e0(pfVar6 + iVar4 * -6,pfVar6 + iVar4 * -3,pfVar6,pfStack_8);
    FUN_00c0f5e0(param_2 + iVar4 * 3,pfVar9,pfVar6 + iVar4 * -3,pfStack_8);
  }
  pfVar6 = pfVar9 + 3;
  for (; param_2 < pfVar9; pfVar9 = pfVar9 + -3) {
    if ((pfVar9[-3] < *pfVar9) || (*pfVar9 < pfVar9[-3])) break;
  }
  pfVar5 = pfVar6;
  pfStack_8 = pfVar6;
  pfVar7 = pfVar9;
  if (pfVar6 < param_3) {
    do {
      pfVar5 = pfVar6;
      pfStack_8 = pfVar6;
      if ((*pfVar6 < *pfVar9) || (*pfVar9 < *pfVar6)) break;
      pfVar6 = pfVar6 + 3;
      pfVar5 = pfVar6;
      pfStack_8 = pfVar6;
    } while (pfVar6 < param_3);
  }
joined_r0x00c0f7b2:
  do {
    pfVar11 = pfVar5;
    if (param_3 <= pfVar6) {
LAB_00c0f801:
      pfVar10 = pfVar9;
      if (param_2 < pfVar7) {
        pfVar5 = pfVar7 + -2;
        do {
          fVar1 = pfVar5[-1];
          pfVar10 = pfVar9;
          pfVar6 = pfStack_8;
          if (*pfVar9 <= fVar1) {
            if (*pfVar9 < fVar1) break;
            pfVar10 = pfVar9 + -3;
            if (pfVar10 != pfVar5 + -1) {
              fVar3 = pfVar9[-2];
              fVar2 = *pfVar10;
              pfVar9[-2] = *pfVar5;
              *pfVar5 = fVar3;
              fVar3 = pfVar9[-1];
              pfVar9[-1] = pfVar5[1];
              *pfVar10 = fVar1;
              pfVar5[1] = fVar3;
              pfVar5[-1] = fVar2;
            }
          }
          pfVar7 = pfVar7 + -3;
          pfVar5 = pfVar5 + -3;
          pfVar9 = pfVar10;
        } while (param_2 < pfVar7);
      }
      if (pfVar7 == param_2) {
        if (pfVar6 == param_3) {
          param_1[1] = (uint)pfVar11;
          *param_1 = (uint)pfVar10;
          return;
        }
        if ((pfVar11 != pfVar6) && (pfVar10 != pfVar11)) {
          fVar2 = pfVar10[1];
          fVar1 = *pfVar10;
          *pfVar10 = *pfVar11;
          pfVar10[1] = pfVar11[1];
          pfVar11[1] = fVar2;
          fVar2 = pfVar10[2];
          pfVar10[2] = pfVar11[2];
          *pfVar11 = fVar1;
          pfVar11[2] = fVar2;
        }
        if (pfVar10 != pfVar6) {
          fVar2 = pfVar10[1];
          fVar1 = *pfVar10;
          *pfVar10 = *pfVar6;
          pfVar10[1] = pfVar6[1];
          pfVar6[1] = fVar2;
          fVar2 = pfVar10[2];
          pfVar10[2] = pfVar6[2];
          *pfVar6 = fVar1;
          pfVar6[2] = fVar2;
        }
        pfVar6 = pfVar6 + 3;
        pfVar5 = pfVar11 + 3;
        pfStack_8 = pfVar6;
        pfVar9 = pfVar10 + 3;
      }
      else {
        pfVar8 = pfVar7 + -3;
        if (pfVar6 == param_3) {
          pfVar9 = pfVar10 + -3;
          if (pfVar8 != pfVar9) {
            fVar2 = pfVar7[-2];
            fVar1 = *pfVar8;
            *pfVar8 = *pfVar9;
            pfVar7[-2] = pfVar10[-2];
            pfVar10[-2] = fVar2;
            fVar2 = pfVar7[-1];
            pfVar7[-1] = pfVar10[-1];
            pfVar10[-1] = fVar2;
            *pfVar9 = fVar1;
          }
          pfVar5 = pfVar11 + -3;
          pfVar7 = pfVar8;
          if (pfVar9 != pfVar5) {
            fVar2 = pfVar10[-2];
            fVar1 = *pfVar9;
            *pfVar9 = *pfVar5;
            pfVar10[-2] = pfVar11[-2];
            pfVar11[-2] = fVar2;
            fVar2 = pfVar10[-1];
            pfVar10[-1] = pfVar11[-1];
            pfVar11[-1] = fVar2;
            *pfVar5 = fVar1;
          }
        }
        else {
          if (pfVar6 != pfVar8) {
            fVar2 = pfVar6[1];
            fVar1 = *pfVar6;
            *pfVar6 = *pfVar8;
            pfVar6[1] = pfVar7[-2];
            pfVar7[-2] = fVar2;
            fVar2 = pfVar6[2];
            pfVar6[2] = pfVar7[-1];
            pfVar7[-1] = fVar2;
            *pfVar8 = fVar1;
          }
          pfVar6 = pfVar6 + 3;
          pfVar5 = pfVar11;
          pfStack_8 = pfVar6;
          pfVar9 = pfVar10;
          pfVar7 = pfVar8;
        }
      }
      goto joined_r0x00c0f7b2;
    }
    fVar1 = *pfVar6;
    if (fVar1 <= *pfVar9) {
      pfStack_8 = pfVar6;
      if (fVar1 < *pfVar9) goto LAB_00c0f801;
      if (pfVar11 != pfVar6) {
        fVar3 = pfVar11[1];
        fVar2 = *pfVar11;
        pfVar11[1] = pfVar6[1];
        pfVar6[1] = fVar3;
        fVar3 = pfVar11[2];
        pfVar11[2] = pfVar6[2];
        *pfVar11 = fVar1;
        *pfVar6 = fVar2;
        pfVar6[2] = fVar3;
      }
      pfVar11 = pfVar11 + 3;
    }
    pfVar6 = pfVar6 + 3;
    pfVar5 = pfVar11;
    pfStack_8 = pfVar6;
  } while( true );
}



/* FUNCTION 27274 ; VA 0x00c0f990 ; FUN_00c0f990 */

void FUN_00c0f990(int param_1,int param_2,uint param_3,float *param_4)

{
  float *pfVar1;
  float fVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  iVar7 = (int)(param_3 - 1) >> 1;
  iVar8 = param_2;
  iVar6 = param_2;
  if (param_2 < iVar7) {
    do {
      fVar2 = *(float *)(param_1 + 0xc + iVar8 * 0x18);
      pfVar1 = (float *)(param_1 + 0x18 + iVar8 * 0x18);
      iVar6 = iVar8 * 2 + 1 + ((*pfVar1 <= fVar2 && fVar2 != *pfVar1) ^ 1);
      uVar3 = *(undefined4 *)(param_1 + 8 + iVar6 * 0xc);
      *(undefined4 *)(param_1 + iVar8 * 0xc) = *(undefined4 *)(param_1 + iVar6 * 0xc);
      uVar4 = *(undefined4 *)(param_1 + 4 + iVar6 * 0xc);
      *(undefined4 *)(param_1 + 4 + iVar6 * 0xc) = 0;
      *(undefined4 *)(param_1 + 8 + iVar6 * 0xc) = 0;
      *(undefined4 *)(param_1 + 4 + iVar8 * 0xc) = uVar4;
      piVar5 = *(int **)(param_1 + 8 + iVar8 * 0xc);
      *(undefined4 *)(param_1 + 8 + iVar8 * 0xc) = uVar3;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar8 = piVar5[1] + -1;
        piVar5[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar8 = piVar5[2] + -1;
          piVar5[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      iVar8 = iVar6;
    } while (iVar6 < iVar7);
  }
  if ((iVar6 == iVar7) && ((param_3 & 1) == 0)) {
    FUN_00613d30(param_1 + (param_3 - 1) * 0xc);
    iVar6 = param_3 - 1;
  }
  while (param_2 < iVar6) {
    iVar8 = iVar6 + -1 >> 1;
    fVar2 = *(float *)(param_1 + iVar8 * 0xc);
    if (*param_4 <= fVar2) break;
    uVar3 = *(undefined4 *)(param_1 + 4 + iVar8 * 0xc);
    uVar4 = *(undefined4 *)(param_1 + 8 + iVar8 * 0xc);
    *(undefined4 *)(param_1 + 4 + iVar8 * 0xc) = 0;
    *(undefined4 *)(param_1 + 8 + iVar8 * 0xc) = 0;
    *(undefined4 *)(param_1 + 4 + iVar6 * 0xc) = uVar3;
    piVar5 = *(int **)(param_1 + 8 + iVar6 * 0xc);
    *(float *)(param_1 + iVar6 * 0xc) = fVar2;
    *(undefined4 *)(param_1 + 8 + iVar6 * 0xc) = uVar4;
    iVar6 = iVar8;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar8 = piVar5[1] + -1;
      piVar5[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar8 = piVar5[2] + -1;
        piVar5[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  FUN_00613d30(param_4);
  return;
}



/* FUNCTION 27275 ; VA 0x00c0fb00 ; FUN_00c0fb00 */

void FUN_00c0fb00(int *param_1,int param_2,int param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int iStack_10;
  int iStack_c;
  int *piStack_8;
  
  iVar3 = param_2 - (int)param_1;
  do {
    iVar3 = iVar3 / 0xc;
    if (iVar3 < 0x21) {
LAB_00c0fbc6:
      if (1 < iVar3) {
        FUN_00c0f1d0(param_1,param_2,param_4);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar3) {
        FUN_00c0f3e0(param_1,param_2,param_4);
        iVar3 = (param_2 - (int)param_1) / 0xc;
        if (iVar3 < 2) {
          return;
        }
        piVar4 = (int *)(param_2 + -8);
        if (iVar3 < 2) goto LAB_00c0fca1;
        do {
          iStack_c = *piVar4;
          iStack_10 = piVar4[-1];
          piStack_8 = (int *)piVar4[1];
          *piVar4 = 0;
          piVar4[1] = 0;
          FUN_00613d30(param_1);
          FUN_00c0f990(param_1,0,((-4 - (int)param_1) + (int)piVar4) / 0xc,&iStack_10,param_4);
          piVar2 = piStack_8;
          if (piStack_8 != (int *)0x0) {
            LOCK();
            iVar3 = piStack_8[1] + -1;
            piStack_8[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piStack_8)();
              LOCK();
              piVar1 = piVar2 + 2;
              iVar3 = *piVar1 + -1;
              *piVar1 = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piVar2 + 4))();
              }
            }
          }
LAB_00c0fca1:
          piVar4 = piVar4 + -3;
        } while (1 < ((8 - (int)param_1) + (int)piVar4) / 0xc);
        return;
      }
      goto LAB_00c0fbc6;
    }
    FUN_00c0f690(&iStack_c,param_1,param_2,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((iStack_c - (int)param_1) / 0xc < (param_2 - (int)piStack_8) / 0xc) {
      FUN_00c0fb00(param_1,iStack_c,param_3,param_4);
      param_1 = piStack_8;
    }
    else {
      FUN_00c0fb00(piStack_8,param_2,param_3,param_4);
      param_2 = iStack_c;
    }
    iVar3 = param_2 - (int)param_1;
  } while( true );
}



/* FUNCTION 27276 ; VA 0x00c0fcd0 ; FUN_00c0fcd0 */

void __thiscall FUN_00c0fcd0(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*(byte *)(param_3 + 2) ^ 0x811c9dc5) * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 9))
            * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 10)) * 0x1000193 ^
          (uint)*(byte *)((int)param_3 + 0xb)) * 0x1000193) * 8;
  piVar2 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar2[1] == param_3) {
    if ((int *)*piVar2 == param_3) {
      *piVar2 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar2[1] = param_3[1];
    }
  }
  else if ((int *)*piVar2 == param_3) {
    *piVar2 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_006129c0();
  FUN_01674ea0(param_3,0x18);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 27277 ; VA 0x00c0fd80 ; thunk_FUN_00c12520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00c12520(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805ff6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8df4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8df4);
    if (DAT_01ef8df4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ProximityPromptInputType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef8d90 = RBX::Reflection::EnumDesc<enum_RBX::ProximityPromptInputType>::vftable;
      FUN_009caf20(&DAT_01d68230,3);
      FUN_016f3654(&LAB_018934a0);
      FUN_016f37bf(&DAT_01ef8df4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef8d90;
}



/* FUNCTION 27278 ; VA 0x00c0fd90 ; FUN_00c0fd90 */

undefined4 * FUN_00c0fd90(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  
  param_1[1] = 0;
  *param_1 = *param_2;
  param_1[2] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = *param_3;
  param_1[2] = param_3[1];
  return param_1;
}



/* FUNCTION 27279 ; VA 0x00c0fdd0 ; FUN_00c0fdd0 */

undefined4 * __thiscall
FUN_00c0fdd0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01805cac;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00c0ecd0();
  FUN_009cb970(uVar1,param_3,0,CONCAT44(uStack_28,uStack_2c),0);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ProximityPromptService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::ProximityPromptService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,param_3);
  iStack_8._0_1_ = 3;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ProximityPromptService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::ProximityPromptService::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27280 ; VA 0x00c0ff30 ; FUN_00c0ff30 */

int * __thiscall FUN_00c0ff30(int *param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = (param_2[1] - *param_2) / 0xc;
  if (uVar3 != 0) {
    if (0x15555555 < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar4 = FUN_00618050(uVar3);
    *param_1 = iVar4;
    param_1[1] = iVar4;
    param_1[2] = *param_1 + uVar3 * 0xc;
    puVar2 = (undefined4 *)param_2[1];
    puVar6 = (undefined4 *)*param_1;
    for (puVar5 = (undefined4 *)*param_2; puVar5 != puVar2; puVar5 = puVar5 + 3) {
      *puVar6 = *puVar5;
      puVar6[1] = 0;
      puVar6[2] = 0;
      if (puVar5[2] != 0) {
        LOCK();
        piVar1 = (int *)(puVar5[2] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      puVar6[1] = puVar5[1];
      puVar6[2] = puVar5[2];
      puVar6 = puVar6 + 3;
    }
    FUN_00602e00(puVar6,puVar6,param_1);
    param_1[1] = (int)puVar6;
  }
  return param_1;
}



/* FUNCTION 27281 ; VA 0x00c0ffe0 ; FUN_00c0ffe0 */

undefined4 * __fastcall FUN_00c0ffe0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805d3c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ProximityPromptService,class_RBX::ServiceInstance>::
             vftable;
  uVar1 = FUN_00c0ecd0();
  param_1[3] = uVar1;
  uStack_8 = 1;
  FUN_00f45140();
  *param_1 = RBX::ProximityPromptService::vftable;
  param_1[0x16] = RBX::ProximityPromptService::vftable;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  *(undefined *)(param_1 + 0x1c) = 1;
  param_1[0x1d] = 0x10;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  uStack_8._0_1_ = 9;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("ProximityPromptService",0x16);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27282 ; VA 0x00c10120 ; FUN_00c10120 */

void __fastcall FUN_00c10120(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ProximityPromptService>::vftable;
  uVar1 = FUN_00c0ecd0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27283 ; VA 0x00c10160 ; FUN_00c10160 */

void __fastcall FUN_00c10160(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00c101c0();
  return;
}



/* FUNCTION 27284 ; VA 0x00c101c0 ; FUN_00c101c0 */

void __fastcall FUN_00c101c0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_006129c0();
      FUN_01674ea0(piVar3,0x18);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x18);
  return;
}



/* FUNCTION 27285 ; VA 0x00c10210 ; FUN_00c10210 */

void FUN_00c10210(void)

{
  FUN_006129c0();
  return;
}



/* FUNCTION 27286 ; VA 0x00c10220 ; FUN_00c10220 */

void __fastcall FUN_00c10220(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00c101c0();
  return;
}



/* FUNCTION 27287 ; VA 0x00c10230 ; thunk_FUN_006129c0 */

void __fastcall thunk_FUN_006129c0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00602e00(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0xc) * 0xc;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 27288 ; VA 0x00c10235 ; FUN_00c10235 */

void FUN_00c10235(void)

{
  FUN_00c10270();
  return;
}



/* FUNCTION 27289 ; VA 0x00c10240 ; FUN_00c10240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c10240(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ProximityPromptInputType>::vftable;
  _DAT_01ef8d88 = _DAT_01ef8d88 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 27290 ; VA 0x00c10270 ; FUN_00c10270 */

undefined4 __thiscall FUN_00c10270(undefined4 param_1,byte param_2)

{
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00577ac0();
  FUN_00f45160();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x90);
  }
  return param_1;
}



/* FUNCTION 27291 ; VA 0x00c10300 ; FUN_00c10300 */

undefined4 * __thiscall
FUN_00c10300(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805e51;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c105b0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27292 ; VA 0x00c104a0 ; FUN_00c104a0 */

void FUN_00c104a0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c12520();
    *param_2 = uVar3;
    iVar4 = FUN_00c125d0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 27293 ; VA 0x00c10500 ; FUN_00c10500 */

void FUN_00c10500(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c12520();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27294 ; VA 0x00c10540 ; FUN_00c10540 */

undefined4 * FUN_00c10540(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00672c40(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27295 ; VA 0x00c105b0 ; FUN_00c105b0 */

int FUN_00c105b0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_1c0 [208];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3c7c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_006874f0(&param_2);
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_00c12520();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_00c125d0();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_1c0,&uStack_20,piVar3);
  uStack_8._0_1_ = 4;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 27296 ; VA 0x00c106f0 ; FUN_00c106f0 */

/* WARNING: Removing unreachable block (ram,0x00c1077e) */
/* WARNING: Removing unreachable block (ram,0x00c10787) */
/* WARNING: Removing unreachable block (ram,0x00c10796) */
/* WARNING: Removing unreachable block (ram,0x00c107a4) */
/* WARNING: Removing unreachable block (ram,0x00c107ad) */
/* WARNING: Removing unreachable block (ram,0x00c107bb) */

undefined4
FUN_00c106f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4ed0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0089bce0(param_2,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 27297 ; VA 0x00c107e0 ; FUN_00c107e0 */

void FUN_00c107e0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804a38;
  pvStack_10 = ExceptionList;
  iVar2 = *param_2;
  iVar4 = *(int *)(iVar2 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088cdc0();
  if (iVar4 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar4 = iVar2 + 0xd8;
  if (*(int *)(iVar2 + 0xd4) == 0) {
    iVar4 = 0;
  }
  if (*(int *)(iVar4 + 4) != 0) {
    LOCK();
    piVar5 = (int *)(*(int *)(iVar4 + 4) + 4);
    *piVar5 = *piVar5 + 1;
    UNLOCK();
  }
  param_2 = (int *)*param_2;
  uStack_8 = 0;
  iVar2 = *param_2;
  iVar4 = FUN_0088cdc0();
  if (iVar2 == iVar4) {
    piVar5 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    if (piVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(piVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_8 = 0xffffffff;
    FUN_00c106f0(param_1,*piVar5,piVar5[1]);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27298 ; VA 0x00c108d0 ; FUN_00c108d0 */

void FUN_00c108d0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  
  iVar2 = *param_2;
  iVar5 = *(int *)(iVar2 + 0xd0);
  iVar3 = FUN_00c12520();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar2 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar2 = *param_2;
    uVar7 = *puVar4;
    iVar5 = FUN_0088cdc0(uVar7);
    if (iVar2 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      if (piVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(piVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00b25690(param_1,*piVar6,piVar6[1],uVar7);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27299 ; VA 0x00c10960 ; FUN_00c10960 */

int __thiscall
FUN_00c10960(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805e70;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c106f0(param_1,param_2,param_3,param_4,param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27300 ; VA 0x00c10a40 ; FUN_00c10a40 */

int __thiscall
FUN_00c10a40(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805e70;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c106f0(param_1,param_2,param_3,param_4,param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27301 ; VA 0x00c10b20 ; FUN_00c10b20 */

int __thiscall
FUN_00c10b20(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805e70;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c106f0(param_1,param_2,param_3,param_4,param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27302 ; VA 0x00c10c00 ; FUN_00c10c00 */

int __thiscall
FUN_00c10c00(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805e70;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c106f0(param_1,param_2,param_3,param_4,param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27303 ; VA 0x00c10ce0 ; FUN_00c10ce0 */

int * __thiscall FUN_00c10ce0(int param_1,int *param_2,float param_3,float param_4,float param_5)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  float *pfVar6;
  float **ppfVar7;
  float *pfVar8;
  float *pfVar9;
  uint uVar10;
  float *pfVar11;
  float10 fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  undefined8 uVar16;
  uint in_stack_fffffee4;
  undefined4 in_stack_fffffee8;
  undefined4 *in_stack_fffffeec;
  undefined4 uVar17;
  undefined4 uVar18;
  undefined4 uVar19;
  undefined auStack_f8 [48];
  undefined auStack_c8 [12];
  float *pfStack_bc;
  int *piStack_b8;
  float fStack_b4;
  float *pfStack_b0;
  float *pfStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined8 uStack_a0;
  float fStack_98;
  float *pfStack_94;
  float *pfStack_90;
  undefined4 *puStack_88;
  int *piStack_84;
  undefined4 uStack_80;
  float *pfStack_7c;
  int iStack_78;
  int iStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  float fStack_60;
  float *pfStack_5c;
  float *pfStack_58;
  float *pfStack_54;
  float *pfStack_50;
  undefined4 uStack_4c;
  float *pfStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  undefined uStack_35;
  float *pfStack_34;
  float *pfStack_30;
  float **ppfStack_2c;
  float *pfStack_28;
  uint uStack_24;
  int iStack_20;
  float *pfStack_1c;
  float *pfStack_18;
  float *pfStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805f16;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  iStack_3c = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8b68) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ef8b68), DAT_01ef8b68 == -1)) {
    uStack_8 = 0;
    uVar16 = FUN_0152dab0(&DAT_018fdbdc,"getBestFitProximityPrompts",0xffffffff);
    DAT_01ef8b64 = (undefined4)((ulonglong)uVar16 >> 0x20);
    DAT_01ef8b60 = (undefined4)uVar16;
    in_stack_fffffeec = &DAT_01ef8b68;
    uStack_8 = 0xffffffff;
    in_stack_fffffee8 = 0xc11793;
    FUN_016f37bf(&DAT_01ef8b68);
  }
  uStack_44 = DAT_01ef8b60;
  uStack_a8 = DAT_01ef8b60;
  uStack_40 = DAT_01ef8b64;
  uStack_a4 = DAT_01ef8b64;
  uStack_a0 = FUN_0152d930(DAT_01ef8b60,DAT_01ef8b64);
  uStack_8 = 1;
  uStack_80 = 0;
  pfStack_7c = (float *)0x0;
  iStack_78 = 0;
  uVar17 = 0xc10d88;
  pfStack_7c = (float *)FUN_006d3cd0(0,0);
  iStack_74 = 0;
  uStack_70 = 0;
  uStack_6c = 0;
  uStack_8._0_1_ = 3;
  uStack_80 = 0x3f800000;
  FUN_005cb500(8);
  pfStack_54 = (float *)0x0;
  pfStack_50 = (float *)0x0;
  uStack_4c = 0;
  iStack_20 = 0;
  pfStack_1c = (float *)0x0;
  pfStack_18 = (float *)0x0;
  uStack_8._0_1_ = 6;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    if ((iVar5 != 0) && (param_1 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    uVar2 = (undefined)uStack_8;
    if (param_1 != 0) {
      iVar5 = *(int *)(param_1 + 0xc);
      iVar4 = FUN_008a8c30();
      uVar2 = (undefined)uStack_8;
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        iVar5 = FUN_00899040();
        uVar2 = (undefined)uStack_8;
        if (iVar5 != 0) {
          uVar18 = 0;
          uVar19 = 0xf;
          in_stack_fffffee4 = in_stack_fffffee4 & 0xffffff00;
          FUN_005542c0("ProximityPrompt",0xf);
          FUN_00d130d0(&puStack_88,in_stack_fffffee4,in_stack_fffffee8,in_stack_fffffeec,uVar17,
                       uVar18,uVar19);
          uStack_8 = CONCAT31(uStack_8._1_3_,8);
          if (puStack_88 == (undefined4 *)0x0) {
            iStack_20 = 0;
            pfStack_1c = (float *)0x0;
            param_2[1] = 0;
            param_2[2] = 0;
            *param_2 = 0;
            param_2[1] = 0;
            param_2[2] = 0;
            pfStack_18 = (float *)0x0;
            if (piStack_84 != (int *)0x0) {
              LOCK();
              iVar5 = piStack_84[1] + -1;
              piStack_84[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)*piStack_84)();
                LOCK();
                piVar1 = piStack_84 + 2;
                iVar5 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar5 == 1) {
                  (**(code **)(*piStack_84 + 4))();
                }
              }
            }
            FUN_00577ac0();
            FUN_006129c0();
            FUN_00c10160();
            uStack_8 = 9;
          }
          else {
            pfVar9 = (float *)*puStack_88;
            pfVar6 = (float *)0x0;
            if (pfVar9 != (float *)puStack_88[1]) {
              do {
                if (*pfVar9 == 0.0) {
LAB_00c10f82:
                  ppfVar7 = &pfStack_bc;
                  uVar10 = uStack_24 | 4;
                  piStack_b8 = (int *)0x0;
                  pfStack_14 = (float *)0x0;
                }
                else {
                  iVar5 = *(int *)((int)*pfVar9 + 0xc);
                  iVar4 = FUN_00c51e00();
                  if ((uint)*(ushort *)(iVar4 + 0x1da) <
                      (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))
                  goto LAB_00c10f82;
                  pfStack_ac = (float *)pfVar9[1];
                  pfStack_14 = (float *)*pfVar9;
                  if (pfStack_ac != (float *)0x0) {
                    LOCK();
                    pfStack_ac[1] = (float)((int)pfStack_ac[1] + 1);
                    UNLOCK();
                    pfStack_ac = (float *)pfVar9[1];
                  }
                  uVar10 = uStack_24 | 2;
                  ppfVar7 = &pfStack_b0;
                }
                pfVar6 = ppfVar7[1];
                uStack_24 = uVar10 | 8;
                *ppfVar7 = (float *)0x0;
                ppfVar7[1] = (float *)0x0;
                pfStack_34 = pfStack_14;
                pfStack_30 = pfVar6;
                if (((uVar10 & 4) != 0) &&
                   (uStack_24 = uVar10 & 0xfffffffb | 8, piStack_b8 != (int *)0x0)) {
                  LOCK();
                  iVar5 = piStack_b8[1] + -1;
                  piStack_b8[1] = iVar5;
                  UNLOCK();
                  if (iVar5 == 0) {
                    (**(code **)*piStack_b8)();
                    LOCK();
                    iVar5 = piStack_b8[2] + -1;
                    piStack_b8[2] = iVar5;
                    UNLOCK();
                    if (iVar5 == 0) {
                      (**(code **)(*piStack_b8 + 4))();
                    }
                  }
                }
                if (((uStack_24 & 2) != 0) &&
                   (uStack_24 = uStack_24 & 0xfffffffd, pfStack_ac != (float *)0x0)) {
                  LOCK();
                  fVar13 = (float)((int)pfStack_ac[1] + -1);
                  pfStack_ac[1] = fVar13;
                  UNLOCK();
                  if (fVar13 == 0.0) {
                    (**(code **)*pfStack_ac)();
                    LOCK();
                    fVar13 = (float)((int)pfStack_ac[2] + -1);
                    pfStack_ac[2] = fVar13;
                    UNLOCK();
                    if (fVar13 == 0.0) {
                      (**(code **)((int)*pfStack_ac + 4))();
                    }
                  }
                }
                uStack_8._0_1_ = 10;
                if (pfStack_14 == (float *)0x0) {
                  uStack_8 = CONCAT31(uStack_8._1_3_,8);
                  if (pfVar6 != (float *)0x0) {
                    LOCK();
                    fVar13 = (float)((int)pfVar6[1] + -1);
                    pfVar6[1] = fVar13;
                    UNLOCK();
                    if (fVar13 == 0.0) {
                      (**(code **)*pfVar6)();
                      LOCK();
                      fVar13 = (float)((int)pfVar6[2] + -1);
                      pfVar6[2] = fVar13;
                      UNLOCK();
                      if (fVar13 == 0.0) {
                        (**(code **)((int)*pfVar6 + 4))();
                      }
                    }
                  }
                }
                else if (*(char *)(pfStack_14 + 0x23) == '\0') {
                  uStack_8 = CONCAT31(uStack_8._1_3_,8);
                  if (pfVar6 != (float *)0x0) {
                    LOCK();
                    fVar13 = (float)((int)pfVar6[1] + -1);
                    pfVar6[1] = fVar13;
                    UNLOCK();
                    if (fVar13 == 0.0) {
                      (**(code **)*pfVar6)();
                      LOCK();
                      fVar13 = (float)((int)pfVar6[2] + -1);
                      pfVar6[2] = fVar13;
                      UNLOCK();
                      if (fVar13 == 0.0) {
                        (**(code **)((int)*pfVar6 + 4))();
                      }
                    }
                  }
                }
                else {
                  iVar5 = FUN_00c53ca0(auStack_f8);
                  pfVar8 = pfStack_14;
                  fVar15 = *(float *)(iVar5 + 0x28) - param_4;
                  fVar14 = *(float *)(iVar5 + 0x24) - param_3;
                  fVar13 = *(float *)(iVar5 + 0x2c) - param_5;
                  if (fVar15 * fVar15 + fVar14 * fVar14 + fVar13 * fVar13 <
                      pfStack_14[0x15] * pfStack_14[0x15]) {
                    fVar12 = (float10)FUN_00c53e10();
                    pfStack_14 = (float *)(float)fVar12;
                    if (0.0 <= (float)pfStack_14) {
                      if (pfVar8[0x29] == 2.8026e-45) {
                        uVar17 = FUN_00c0fd90(auStack_c8,&pfStack_14,&pfStack_34);
                        uStack_8._0_1_ = 0xb;
                        FUN_00c12120(uVar17);
                      }
                      else {
                        if (*(int *)(iStack_3c + 0x60) == 1) {
                          pfStack_28 = (float *)pfVar8[0x27];
                        }
                        else {
                          pfStack_28 = (float *)pfVar8[0x26];
                        }
                        if (pfVar8[0x29] == 1.4013e-45) {
                          pfStack_28 = (float *)0x0;
                        }
                        ppfStack_2c = (float **)
                                      (uStack_68 &
                                      (((((uint)pfStack_28 & 0xff ^ 0x811c9dc5) * 0x1000193 ^
                                        (int)pfStack_28 >> 8 & 0xffU) * 0x1000193 ^
                                       (int)pfStack_28 >> 0x10 & 0xffU) * 0x1000193 ^
                                      (int)pfStack_28 >> 0x18 & 0xffU) * 0x1000193);
                        pfVar6 = *(float **)(iStack_74 + (int)ppfStack_2c * 8);
                        while( true ) {
                          pfVar8 = pfStack_7c;
                          if (*(float **)(iStack_74 + (int)ppfStack_2c * 8) != pfStack_7c) {
                            pfVar8 = (float *)**(float **)(iStack_74 + 4 + (int)ppfStack_2c * 8);
                          }
                          if (pfVar6 == pfVar8) goto LAB_00c11238;
                          if ((float *)pfVar6[2] == pfStack_28) break;
                          pfVar6 = (float *)*pfVar6;
                        }
                        if (pfVar6 == pfStack_7c) {
LAB_00c11238:
                          fVar13 = *pfStack_7c;
                          ppfStack_2c = &pfStack_28;
                          pfStack_48 = *(float **)((int)fVar13 + 4);
                          ppfStack_2c = (float **)
                                        FUN_00c0edf0(fVar13,pfStack_48,&DAT_018bdeda,&ppfStack_2c,
                                                     &uStack_35);
                          if (iStack_78 == 0xaaaaaa9) {
                    /* WARNING: Subroutine does not return */
                            FUN_016ddcd9("list<T> too long");
                          }
                          iStack_78 = iStack_78 + 1;
                          *(float ***)((int)fVar13 + 4) = ppfStack_2c;
                          *pfStack_48 = (float)ppfStack_2c;
                          FUN_00c0efc0(&pfStack_5c,(int)*pfStack_7c + 8,*pfStack_7c);
                        }
                        else {
                          pfStack_58 = (float *)((uint)pfStack_58 & 0xffffff00);
                          pfStack_5c = pfVar6;
                          pfStack_48 = pfStack_28;
                        }
                        uVar17 = FUN_00c0fd90(&pfStack_94,&pfStack_14,&pfStack_34);
                        uStack_8._0_1_ = 0xc;
                        FUN_00c12120(uVar17);
                      }
                      FUN_00612e60();
                    }
                    uStack_8 = CONCAT31(uStack_8._1_3_,8);
                    FUN_00550b30();
                  }
                  else {
                    uStack_8 = CONCAT31(uStack_8._1_3_,8);
                    if (pfVar6 != (float *)0x0) {
                      LOCK();
                      fVar13 = (float)((int)pfVar6[1] + -1);
                      pfVar6[1] = fVar13;
                      UNLOCK();
                      if (fVar13 == 0.0) {
                        (**(code **)*pfVar6)();
                        LOCK();
                        fVar13 = (float)((int)pfVar6[2] + -1);
                        pfVar6[2] = fVar13;
                        UNLOCK();
                        if (fVar13 == 0.0) {
                          (**(code **)((int)*pfVar6 + 4))();
                        }
                      }
                    }
                  }
                }
                pfVar9 = pfVar9 + 2;
                pfVar6 = pfStack_1c;
              } while (pfVar9 != (float *)puStack_88[1]);
            }
            pfVar9 = pfStack_54;
            FUN_00c0fb00(pfStack_54,pfStack_50,((int)pfStack_50 - (int)pfStack_54) / 0xc,param_2);
            if (pfVar9 != pfStack_50) {
              pfVar9 = pfVar9 + 2;
              do {
                fStack_b4 = pfVar9[-2];
                pfVar8 = (float *)*pfVar9;
                if (pfVar8 != (float *)0x0) {
                  LOCK();
                  pfVar8[1] = (float)((int)pfVar8[1] + 1);
                  UNLOCK();
                  pfVar8 = (float *)*pfVar9;
                }
                pfStack_b0 = (float *)pfVar9[-1];
                pfStack_ac = pfVar8;
                pfStack_28 = pfStack_b0;
                pfStack_14 = pfVar9;
                if (*(uint *)(iStack_3c + 0x74) <= (uint)((int)pfVar6 - iStack_20 >> 3)) {
                  uStack_8 = CONCAT31(uStack_8._1_3_,8);
                  if (pfVar8 != (float *)0x0) {
                    LOCK();
                    fVar13 = (float)((int)pfVar8[1] + -1);
                    pfVar8[1] = fVar13;
                    UNLOCK();
                    if (fVar13 == 0.0) {
                      (**(code **)*pfVar8)();
                      LOCK();
                      fVar13 = (float)((int)pfVar8[2] + -1);
                      pfVar8[2] = fVar13;
                      UNLOCK();
                      if (fVar13 == 0.0) {
                        (**(code **)((int)*pfVar8 + 4))();
                      }
                    }
                  }
                  break;
                }
                if (pfVar8 != (float *)0x0) {
                  LOCK();
                  pfVar8[1] = (float)((int)pfVar8[1] + 1);
                  UNLOCK();
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
                pfStack_5c = pfStack_b0;
                pfStack_58 = pfVar8;
                cVar3 = FUN_00c52d70();
                pfVar9 = pfVar8;
                if (cVar3 != '\0') {
                  if (pfStack_18 == pfStack_1c) {
                    FUN_00ba09b0(pfStack_1c,&pfStack_5c);
                    pfVar9 = pfStack_58;
                  }
                  else {
                    *pfStack_1c = 0.0;
                    pfStack_1c[1] = 0.0;
                    if (pfVar8 != (float *)0x0) {
                      LOCK();
                      pfVar8[1] = (float)((int)pfVar8[1] + 1);
                      UNLOCK();
                    }
                    *pfStack_1c = (float)pfStack_28;
                    pfStack_1c[1] = (float)pfVar8;
                    pfStack_1c = pfStack_1c + 2;
                  }
                }
                if (pfVar9 != (float *)0x0) {
                  LOCK();
                  fVar13 = (float)((int)pfVar9[1] + -1);
                  pfVar9[1] = fVar13;
                  UNLOCK();
                  if (fVar13 == 0.0) {
                    (**(code **)*pfVar9)();
                    LOCK();
                    fVar13 = (float)((int)pfVar9[2] + -1);
                    pfVar9[2] = fVar13;
                    UNLOCK();
                    if (fVar13 == 0.0) {
                      (**(code **)((int)*pfVar9 + 4))();
                    }
                  }
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,8);
                if (pfVar8 != (float *)0x0) {
                  LOCK();
                  fVar13 = (float)((int)pfVar8[1] + -1);
                  pfVar8[1] = fVar13;
                  UNLOCK();
                  if (fVar13 == 0.0) {
                    (**(code **)*pfVar8)();
                    LOCK();
                    fVar13 = (float)((int)pfVar8[2] + -1);
                    pfVar8[2] = fVar13;
                    UNLOCK();
                    if (fVar13 == 0.0) {
                      (**(code **)((int)*pfVar8 + 4))();
                    }
                  }
                }
                pfVar9 = pfStack_14 + 3;
                pfVar8 = pfStack_14 + 1;
                pfVar6 = pfStack_1c;
                pfStack_14 = pfVar9;
              } while (pfVar8 != pfStack_50);
            }
            pfVar6 = pfStack_7c;
            for (pfVar9 = (float *)*pfStack_7c; pfVar9 != pfVar6; pfVar9 = (float *)*pfVar9) {
              fStack_98 = pfVar9[2];
              FUN_00c0ff30(pfVar9 + 3);
              pfVar8 = pfStack_94;
              uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
              if (*(uint *)(iStack_3c + 0x74) <= (uint)((int)pfStack_1c - iStack_20 >> 3)) {
                FUN_006129c0();
                break;
              }
              FUN_00c0fb00(pfStack_94,pfStack_90,((int)pfStack_90 - (int)pfStack_94) / 0xc,param_2);
              if (pfVar8 != pfStack_90) {
                pfVar8 = pfVar8 + 2;
                do {
                  fStack_60 = pfVar8[-2];
                  pfVar11 = (float *)*pfVar8;
                  if (pfVar11 != (float *)0x0) {
                    LOCK();
                    pfVar11[1] = (float)((int)pfVar11[1] + 1);
                    UNLOCK();
                    pfVar11 = (float *)*pfVar8;
                  }
                  pfStack_5c = (float *)pfVar8[-1];
                  if (pfVar11 != (float *)0x0) {
                    LOCK();
                    pfVar11[1] = (float)((int)pfVar11[1] + 1);
                    UNLOCK();
                  }
                  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
                  pfStack_58 = pfVar11;
                  pfStack_34 = pfStack_5c;
                  pfStack_30 = pfVar11;
                  pfStack_28 = pfStack_5c;
                  pfStack_14 = pfVar8;
                  cVar3 = FUN_00c52d70();
                  if (cVar3 != '\0') {
                    if (pfStack_18 == pfStack_1c) {
                      FUN_00ba09b0(pfStack_1c,&pfStack_34);
                    }
                    else {
                      *pfStack_1c = 0.0;
                      pfStack_1c[1] = 0.0;
                      if (pfVar11 != (float *)0x0) {
                        LOCK();
                        pfVar11[1] = (float)((int)pfVar11[1] + 1);
                        UNLOCK();
                      }
                      *pfStack_1c = (float)pfStack_28;
                      pfStack_1c[1] = (float)pfVar11;
                      pfStack_1c = pfStack_1c + 2;
                    }
                    if (pfStack_30 != (float *)0x0) {
                      LOCK();
                      fVar13 = (float)((int)pfStack_30[1] + -1);
                      pfStack_30[1] = fVar13;
                      UNLOCK();
                      if (fVar13 == 0.0) {
                        (**(code **)*pfStack_30)();
                        LOCK();
                        fVar13 = (float)((int)pfStack_30[2] + -1);
                        pfStack_30[2] = fVar13;
                        UNLOCK();
                        if (fVar13 == 0.0) {
                          (**(code **)((int)*pfStack_30 + 4))();
                        }
                      }
                    }
                    if (pfVar11 != (float *)0x0) {
                      LOCK();
                      fVar13 = (float)((int)pfVar11[1] + -1);
                      pfVar11[1] = fVar13;
                      UNLOCK();
                      if (fVar13 == 0.0) {
                        (**(code **)*pfVar11)();
                        LOCK();
                        fVar13 = (float)((int)pfVar11[2] + -1);
                        pfVar11[2] = fVar13;
                        UNLOCK();
                        if (fVar13 == 0.0) {
                          (**(code **)((int)*pfVar11 + 4))();
                        }
                      }
                    }
                    break;
                  }
                  if (pfVar11 != (float *)0x0) {
                    LOCK();
                    fVar13 = (float)((int)pfVar11[1] + -1);
                    pfVar11[1] = fVar13;
                    UNLOCK();
                    if (fVar13 == 0.0) {
                      (**(code **)*pfVar11)();
                      LOCK();
                      fVar13 = (float)((int)pfVar11[2] + -1);
                      pfVar11[2] = fVar13;
                      UNLOCK();
                      if (fVar13 == 0.0) {
                        (**(code **)((int)*pfVar11 + 4))();
                      }
                    }
                    LOCK();
                    fVar13 = (float)((int)pfVar11[1] + -1);
                    pfVar11[1] = fVar13;
                    UNLOCK();
                    if (fVar13 == 0.0) {
                      (**(code **)*pfVar11)();
                      LOCK();
                      fVar13 = (float)((int)pfVar11[2] + -1);
                      pfVar11[2] = fVar13;
                      UNLOCK();
                      if (fVar13 == 0.0) {
                        (**(code **)((int)*pfVar11 + 4))();
                      }
                    }
                  }
                  pfVar8 = pfStack_14 + 3;
                  pfVar11 = pfStack_14 + 1;
                  pfStack_14 = pfVar8;
                } while (pfVar11 != pfStack_90);
              }
              uStack_8 = CONCAT31(uStack_8._1_3_,8);
              FUN_006129c0();
            }
            iVar5 = iStack_20;
            iStack_20 = 0;
            *param_2 = iVar5;
            param_2[1] = 0;
            param_2[2] = 0;
            param_2[1] = (int)pfStack_1c;
            param_2[2] = (int)pfStack_18;
            pfStack_1c = (float *)0x0;
            pfStack_18 = (float *)0x0;
            if (piStack_84 != (int *)0x0) {
              LOCK();
              iVar5 = piStack_84[1] + -1;
              piStack_84[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)*piStack_84)();
                LOCK();
                piVar1 = piStack_84 + 2;
                iVar5 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar5 == 1) {
                  (**(code **)(*piStack_84 + 4))();
                }
              }
            }
            FUN_00577ac0();
            FUN_006129c0();
            FUN_00c10160();
            uStack_8 = 0x12;
          }
          FUN_0152dda0(uStack_44,uStack_40,uStack_a0);
          ExceptionList = pvStack_10;
          return param_2;
        }
      }
    }
  }
  uStack_8._0_1_ = uVar2;
  iStack_20 = 0;
  pfStack_1c = (float *)0x0;
  pfStack_18 = (float *)0x0;
  param_2[1] = 0;
  param_2[2] = 0;
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  FUN_00577ac0();
  FUN_006129c0();
  FUN_00c10160();
  uStack_8 = 7;
  FUN_0152dda0(uStack_44,uStack_40,uStack_a0);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27304 ; VA 0x00c117b0 ; FUN_00c117b0 */

undefined4 * __thiscall FUN_00c117b0(int param_1,undefined4 *param_2,int param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  
  puVar1 = *(undefined4 **)(param_1 + 100);
  do {
    if (puVar1 == *(undefined4 **)(param_1 + 0x68)) {
      *param_2 = 0;
      param_2[1] = 0;
LAB_00c117e0:
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar3 = param_4[1] + -1;
        param_4[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*param_4)();
          LOCK();
          piVar2 = param_4 + 2;
          iVar3 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*param_4 + 4))();
          }
        }
      }
      return param_2;
    }
    piVar2 = (int *)*puVar1;
    if (*piVar2 == param_3) {
      iVar3 = puVar1[1];
      *param_2 = 0;
      param_2[1] = 0;
      if (iVar3 != 0) {
        LOCK();
        *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
        UNLOCK();
        piVar2 = (int *)*puVar1;
        iVar3 = puVar1[1];
      }
      *param_2 = piVar2;
      param_2[1] = iVar3;
      goto LAB_00c117e0;
    }
    puVar1 = puVar1 + 2;
  } while( true );
}



/* FUNCTION 27305 ; VA 0x00c11850 ; FUN_00c11850 */

int __thiscall FUN_00c11850(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805f30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  piVar5 = &iStack_1c;
  uVar4 = 0xc118a9;
  iVar3 = FUN_00c117b0(piVar5,param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((iStack_1c != 0) && (*(int *)(iStack_1c + 0xc) == 0)) {
    if (NAN(*(float *)(param_2 + 0x58)) == (*(float *)(param_2 + 0x58) == 0.0)) {
      *(undefined4 *)(iStack_1c + 0xc) = 1;
      *(undefined4 *)(iStack_1c + 8) = 0;
      if (DAT_01d68824 == '\0') {
        uVar6 = 0;
        uVar7 = 0;
        FUN_00557fc0(&param_2);
        FUN_00c106f0(param_1,uVar4,piVar5,uVar6,uVar7);
      }
      iVar3 = FUN_00c53a40();
    }
    else {
      FUN_00c55330();
      *(undefined4 *)(iStack_1c + 0xc) = 2;
      iVar3 = iStack_1c;
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_18 + 1;
    iVar2 = *piVar5;
    iVar3 = *piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar5 = piStack_18 + 2;
      iVar2 = *piVar5;
      iVar3 = *piVar5;
      *piVar5 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar5 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27306 ; VA 0x00c11990 ; FUN_00c11990 */

int __thiscall FUN_00c11990(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805f30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00c117b0(&iStack_1c,param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_1c != 0) {
    if (*(int *)(iStack_1c + 0xc) == 1) {
      *(undefined4 *)(iStack_1c + 0xc) = 0;
      *(undefined4 *)(iStack_1c + 8) = 0;
      if (DAT_01d68824 == '\0') {
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        FUN_00c106f0(param_1,param_2,param_3,0,0);
      }
      iStack_1c = FUN_00c53b50();
    }
    else if (*(int *)(iStack_1c + 0xc) == 2) {
      *(undefined4 *)(iStack_1c + 0xc) = 0;
      iStack_1c = FUN_00c55450();
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iStack_1c = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iStack_1c = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iStack_1c = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iStack_1c = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_1c = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_1c = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_1c;
}



/* FUNCTION 27307 ; VA 0x00c11ae0 ; FUN_00c11ae0 */

uint FUN_00c11ae0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c0ecd0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27308 ; VA 0x00c11b00 ; FUN_00c11b00 */

uint FUN_00c11b00(void)

{
  int iVar1;
  
  iVar1 = FUN_00c0ecd0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27309 ; VA 0x00c11b20 ; FUN_00c11b20 */

void FUN_00c11b20(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c12520();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27310 ; VA 0x00c11b60 ; FUN_00c11b60 */

void __thiscall FUN_00c11b60(int *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  float fVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined auStack_30 [12];
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805f60;
  pvStack_10 = ExceptionList;
  if (DAT_01d68228 != '\0') {
    piVar1 = param_1 + -0x16;
    uVar11 = 1;
    uVar10 = 0xc11b9b;
    ExceptionList = &pvStack_10;
    piVar8 = piVar1;
    piStack_18 = param_1;
    cVar3 = FUN_0098c5a0(piVar1,1);
    if (cVar3 == '\0') {
      if (*(char *)(piStack_18 + 6) == '\0') {
        uStack_24 = 0;
        iStack_20 = 0;
        uStack_1c = 0;
        uStack_8 = 0;
        FUN_00709c60(&uStack_24);
        FUN_00c122d0(uVar10,piVar8,uVar11);
      }
      else {
        iStack_14 = piStack_18[2];
        if (piVar1 != (int *)0x0) {
          piVar2 = (int *)param_1[-9];
          piVar4 = piVar1;
          if ((piVar2 != (int *)0x0) && (piVar4 = piVar2, piVar2[0xd] != 0)) {
            uVar11 = 0xc11c09;
            piVar4 = (int *)FUN_005c8ac0();
          }
          if (piVar4 != (int *)0x0) {
            iVar6 = piVar4[3];
            uVar11 = 0xc11c1b;
            iVar5 = FUN_008a8c30();
            if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
                (uint)*(ushort *)(iVar5 + 0x1da)) {
              uVar11 = 0xc11c3d;
              iVar6 = FUN_0085feb0();
              if (iVar6 != 0) {
                uVar11 = 0xc11c48;
                uVar7 = FUN_00b82b00();
                switch(uVar7) {
                case 7:
                  iStack_14 = 2;
                  break;
                case 8:
                  iStack_14 = 0;
                  break;
                case 0xc:
                case 0xd:
                case 0xe:
                case 0xf:
                case 0x10:
                case 0x11:
                case 0x12:
                case 0x13:
                  iStack_14 = 1;
                }
              }
            }
          }
        }
        if (iStack_14 != piStack_18[2]) {
          piStack_18[2] = iStack_14;
          uStack_24 = 0;
          iStack_20 = 0;
          uStack_1c = 0;
          uStack_8 = 1;
          FUN_00709c60(&uStack_24);
          FUN_00c122d0(uVar10,piVar8,uVar11);
          uStack_8 = 0xffffffff;
          FUN_00577ac0();
        }
        uStack_24 = 0;
        iStack_20 = 0;
        uStack_1c = 0;
        iVar6 = FUN_0097bfc0(piVar1);
        if (((iVar6 == 0) || (*(int **)(iVar6 + 100) == (int *)0x0)) ||
           (iVar5 = (**(code **)(**(int **)(iVar6 + 100) + 0xa8))(), iVar5 == 0)) {
          iVar5 = FUN_008f7870(piVar1);
          uVar10 = uStack_1c;
          uVar11 = uStack_24;
          iVar6 = iStack_20;
          if ((iVar5 != 0) && (*(int *)(iVar5 + 0x1b8) != 0)) {
            iVar6 = (**(code **)(*(int *)(*(int *)(iVar5 + 0x1b8) + 0x144) + 4))();
            uVar10 = *(undefined4 *)(iVar6 + 200);
            uVar11 = *(undefined4 *)(iVar6 + 0xc0);
            iVar6 = *(int *)(iVar6 + 0xc4);
          }
        }
        else {
          (**(code **)(**(int **)(iVar6 + 100) + 0xa8))();
          iVar6 = FUN_00b077e0();
          uVar10 = *(undefined4 *)(iVar6 + 0x2c);
          uVar11 = *(undefined4 *)(iVar6 + 0x24);
          iVar6 = *(int *)(iVar6 + 0x28);
        }
        FUN_00c10ce0(auStack_30,uVar11,iVar6,uVar10);
        uStack_8 = 2;
        FUN_00709c60(auStack_30);
        uVar7 = 0xc11d89;
        FUN_00c122d0(uVar11,iVar6,uVar10);
        iVar6 = FUN_008f7870(piVar1);
        if (((iVar6 != 0) && (iVar6 != -0xc)) && (iVar6 = FUN_0085feb0(), iVar6 != 0)) {
          piVar8 = (int *)piStack_18[3];
          piStack_18 = (int *)piStack_18[4];
          if (piVar8 != piStack_18) {
            do {
              if (*(int *)(*piVar8 + 0xc) == 1) {
                FUN_00557fc0(*piVar8);
                iVar6 = *piVar8;
                uStack_8._0_1_ = 3;
                fVar9 = (float)((double)*(float *)(iVar6 + 8) + *(double *)(param_2 + 0x18));
                *(float *)(iVar6 + 8) = fVar9;
                if (*(float *)(iStack_20 + 0x58) <= fVar9 && fVar9 != *(float *)(iStack_20 + 0x58))
                {
                  *(undefined4 *)(iVar6 + 8) = 0;
                  *(undefined4 *)(*piVar8 + 0xc) = 2;
                  if (DAT_01d68824 == '\0') {
                    uVar10 = 0;
                    uVar12 = 0;
                    FUN_00557fc0(&iStack_20);
                    FUN_00c106f0(piVar1,uVar7,uVar11,uVar10,uVar12);
                  }
                  FUN_00c53b50();
                  FUN_00c55330();
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,2);
                FUN_00550b30();
              }
              piVar8 = piVar8 + 2;
            } while (piVar8 != piStack_18);
          }
        }
      }
      FUN_00577ac0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27311 ; VA 0x00c11ec0 ; FUN_00c11ec0 */

void __thiscall FUN_00c11ec0(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void **ppvVar4;
  int *piVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805f80;
  pvStack_10 = ExceptionList;
  ppvVar4 = &pvStack_10;
  if (*(int *)(*param_3 + 0x5c) == 0) {
    piVar1 = *(int **)(param_1 + 0x68);
    ppvVar4 = &pvStack_10;
    for (piVar6 = *(int **)(param_1 + 100); ExceptionList = ppvVar4,
        ppvVar4 = (void **)ExceptionList, piVar6 != piVar1; piVar6 = piVar6 + 2) {
      piVar2 = (int *)*piVar6;
      piVar5 = (int *)piVar2[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)piVar2[1];
      }
      iVar3 = *piVar2;
      uStack_8 = 0;
      if ((*(int *)(*param_3 + 0xa8) == *(int *)(iVar3 + 0x98)) ||
         (*(int *)(*param_3 + 0xa8) == *(int *)(iVar3 + 0x9c))) {
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[1] = piVar5[1] + 1;
          UNLOCK();
        }
        FUN_00c11850(iVar3,piVar5);
      }
      uStack_8 = 0xffffffff;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar3 = piVar5[1] + -1;
        piVar5[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar3 = piVar5[2] + -1;
          piVar5[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      ppvVar4 = (void **)ExceptionList;
    }
  }
  ExceptionList = ppvVar4;
  if (*(int *)(*param_3 + 0x5c) == 2) {
    piVar1 = *(int **)(param_1 + 0x68);
    for (piVar6 = *(int **)(param_1 + 100); piVar6 != piVar1; piVar6 = piVar6 + 2) {
      piVar2 = (int *)*piVar6;
      piVar5 = (int *)piVar2[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)piVar2[1];
      }
      iVar3 = *piVar2;
      uStack_8 = 1;
      if ((*(int *)(*param_3 + 0xa8) == *(int *)(iVar3 + 0x98)) ||
         (*(int *)(*param_3 + 0xa8) == *(int *)(iVar3 + 0x9c))) {
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[1] = piVar5[1] + 1;
          UNLOCK();
        }
        FUN_00c11990(iVar3,piVar5);
      }
      uStack_8 = 0xffffffff;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar3 = piVar5[1] + -1;
        piVar5[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar3 = piVar5[2] + -1;
          piVar5[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27312 ; VA 0x00c12090 ; FUN_00c12090 */

uint __thiscall FUN_00c12090(int param_1,int param_2,int *param_3)

{
  uint *puVar1;
  int *piVar2;
  void **ppvVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01805f98;
  pvStack_10 = ExceptionList;
  uVar6 = 0;
  iVar5 = *(int *)(param_1 + 100);
  uVar4 = *(int *)(param_1 + 0x68) - iVar5 >> 3;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (uVar4 != 0) {
    do {
      if (**(int **)(iVar5 + uVar6 * 8) == param_2) {
        FUN_00c12180(uVar6);
      }
      uVar6 = uVar6 + 1;
      iVar5 = *(int *)(param_1 + 100);
      uVar4 = *(int *)(param_1 + 0x68) - iVar5 >> 3;
      ppvVar3 = (void **)ExceptionList;
    } while (uVar6 < uVar4);
  }
  ExceptionList = ppvVar3;
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar6 = *puVar1;
    uVar4 = *puVar1;
    *puVar1 = uVar6 - 1;
    UNLOCK();
    if (uVar6 - 1 == 0) {
      uVar4 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 27313 ; VA 0x00c12120 ; FUN_00c12120 */

void __thiscall FUN_00c12120(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    puVar1[1] = 0;
    puVar1[2] = 0;
    *puVar1 = *param_2;
    puVar1[1] = param_2[1];
    puVar1[2] = param_2[2];
    param_2[1] = 0;
    param_2[2] = 0;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xc;
    return;
  }
  FUN_00c0ee30(puVar1,param_2);
  return;
}



/* FUNCTION 27314 ; VA 0x00c12180 ; FUN_00c12180 */

int __thiscall FUN_00c12180(int param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  
  piVar5 = (int *)(*(int *)(param_1 + 100) + param_2 * 8);
  if (*(int *)(*piVar5 + 0xc) == 1) {
    if (DAT_01d68824 == '\0') {
      puVar2 = (undefined4 *)*piVar5;
      if (puVar2[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar2[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00c106f0(param_1,*puVar2,puVar2[1],0,0);
    }
    FUN_00c53b50();
  }
  else if (*(int *)(*piVar5 + 0xc) == 2) {
    FUN_00c55450();
  }
  puVar2 = (undefined4 *)*piVar5;
  if (puVar2[1] != 0) {
    LOCK();
    piVar5 = (int *)(puVar2[1] + 4);
    *piVar5 = *piVar5 + 1;
    UNLOCK();
  }
  FUN_00925d30(param_1,*puVar2,puVar2[1]);
  FUN_00c53c60();
  iVar3 = *(int *)(param_1 + 100);
  puVar2 = (undefined4 *)(iVar3 + param_2 * 8);
  iVar3 = iVar3 + (*(int *)(param_1 + 0x68) - iVar3 >> 3) * 8;
  iVar4 = *(int *)(iVar3 + -4);
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = *(int *)(iVar3 + -4);
  }
  *puVar2 = *(undefined4 *)(iVar3 + -8);
  piVar5 = (int *)puVar2[1];
  puVar2[1] = iVar4;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar3 = piVar5[1] + -1;
    piVar5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar3 = piVar5[2] + -1;
      piVar5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  iVar3 = *(int *)(param_1 + 0x68);
  piVar5 = *(int **)(iVar3 + -4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar3 = (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar3 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  *(int *)(param_1 + 0x68) = *(int *)(param_1 + 0x68) + -8;
  return iVar3;
}



/* FUNCTION 27315 ; VA 0x00c122d0 ; FUN_00c122d0 */

void __thiscall FUN_00c122d0(int param_1,int *param_2,int *param_3)

{
  void **ppvVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01805fc8;
  pvStack_10 = ExceptionList;
  piVar8 = (int *)(param_1 + 100);
  iVar3 = *piVar8;
  uVar6 = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  piStack_1c = piVar8;
  iStack_18 = param_1;
  if (*(int *)(param_1 + 0x68) - iVar3 >> 3 != 0) {
    do {
      if (param_2 != param_3) {
        piVar2 = param_2;
        do {
          if (*piVar2 == **(int **)(iVar3 + uVar6 * 8)) {
            if (piVar2 != param_3) goto LAB_00c1233d;
            break;
          }
          piVar2 = piVar2 + 2;
        } while (piVar2 != param_3);
      }
      FUN_00c12180(uVar6);
      uVar6 = uVar6 - 1;
LAB_00c1233d:
      uVar6 = uVar6 + 1;
      iVar3 = *piVar8;
      ppvVar1 = (void **)ExceptionList;
    } while (uVar6 < (uint)(*(int *)(param_1 + 0x68) - iVar3 >> 3));
  }
  ExceptionList = ppvVar1;
  uVar6 = 0;
  if ((int)param_3 - (int)param_2 >> 3 != 0) {
    do {
      puVar4 = (undefined4 *)*piVar8;
      uVar7 = 0;
      uVar5 = piVar8[1] - (int)puVar4 >> 3;
      piStack_14 = param_2;
      if (uVar5 != 0) {
        piStack_20 = (int *)param_2[uVar6 * 2];
        do {
          if ((int *)*(int *)*puVar4 == piStack_20) goto LAB_00c124f0;
          uVar7 = uVar7 + 1;
          puVar4 = puVar4 + 2;
        } while (uVar7 < uVar5);
      }
      piStack_20 = (int *)FUN_01674e20(0x1c);
      if (piStack_20 == (int *)0x0) {
        piVar8 = (int *)0x0;
      }
      else {
        piStack_20[1] = 1;
        piStack_20[2] = 1;
        *piStack_20 = (int)std::_Ref_count_obj<class_RBX::FocusedPromptData>::vftable;
        piStack_20[3] = 0;
        piStack_20[4] = 0;
        piStack_20[5] = 0;
        piStack_20[6] = 0;
        piVar8 = piStack_20;
      }
      piStack_28 = piVar8 + 3;
      iStack_8 = CONCAT31(iStack_8._1_3_,1);
      iVar3 = piStack_14[uVar6 * 2 + 1];
      if (iVar3 != 0) {
        LOCK();
        *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
        UNLOCK();
        iVar3 = piStack_14[uVar6 * 2 + 1];
      }
      *piStack_28 = piStack_14[uVar6 * 2];
      piVar2 = (int *)piVar8[4];
      piVar8[4] = iVar3;
      piStack_24 = piVar8;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      puVar4 = (undefined4 *)piStack_1c[1];
      if ((undefined4 *)piStack_1c[2] == puVar4) {
        FUN_005c1970(puVar4,&piStack_28);
        piVar8 = piStack_24;
      }
      else {
        *puVar4 = 0;
        puVar4[1] = 0;
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
        *puVar4 = piVar8 + 3;
        puVar4[1] = piVar8;
        piStack_1c[1] = piStack_1c[1] + 8;
      }
      piStack_20 = *(int **)(iStack_18 + 0x60);
      iVar3 = piStack_14[uVar6 * 2 + 1];
      if (iVar3 != 0) {
        LOCK();
        *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
        UNLOCK();
        iVar3 = piStack_14[uVar6 * 2 + 1];
      }
      iStack_8._0_1_ = 2;
      FUN_0089bf10(piStack_14[uVar6 * 2],iVar3,piStack_20);
      iStack_8._0_1_ = 1;
      FUN_00c53c70(*(undefined4 *)(iStack_18 + 0x60));
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar3 = piVar8[1] + -1;
        piVar8[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar3 = piVar8[2] + -1;
          piVar8[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
LAB_00c124f0:
      uVar6 = uVar6 + 1;
      piVar8 = piStack_1c;
    } while (uVar6 < (uint)((int)param_3 - (int)param_2 >> 3));
  }
  FUN_00577ac0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27316 ; VA 0x00c12520 ; FUN_00c12520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c12520(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01805ff6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8df4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8df4);
    if (DAT_01ef8df4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ProximityPromptInputType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef8d90 = RBX::Reflection::EnumDesc<enum_RBX::ProximityPromptInputType>::vftable;
      FUN_009caf20(&DAT_01d68230,3);
      FUN_016f3654(&LAB_018934a0);
      FUN_016f37bf(&DAT_01ef8df4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef8d90;
}



/* FUNCTION 27317 ; VA 0x00c125d0 ; FUN_00c125d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c125d0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8e04) {
    FUN_016f3809(&DAT_01ef8e04);
    if (DAT_01ef8e04 == -1) {
      _DAT_01ef8df8 = FUN_005c65e0;
      _DAT_01ef8dfc = FUN_005c65e0;
      _DAT_01ef8e00 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef8e04);
    }
  }
  return &DAT_01ef8df8;
}



/* FUNCTION 27318 ; VA 0x00c12640 ; FUN_00c12640 */

void FUN_00c12640(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  
  if (param_1 != param_2) {
    piVar5 = param_1 + 3;
    do {
      iVar2 = piVar5[-2];
      if (iVar2 != 0) {
        uVar4 = *piVar5 - iVar2 & 0xfffffffc;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[-2] = 0;
        piVar5[-1] = 0;
        *piVar5 = 0;
      }
      piVar1 = piVar5 + 5;
      piVar5 = piVar5 + 8;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 27319 ; VA 0x00c126b0 ; FUN_00c126b0 */

void FUN_00c126b0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  
  if (param_1 != param_2) {
    piVar5 = param_1 + 6;
    do {
      iVar2 = piVar5[-2];
      if (iVar2 != 0) {
        uVar4 = *piVar5 - iVar2 & 0xfffffffc;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[-2] = 0;
        piVar5[-1] = 0;
        *piVar5 = 0;
      }
      piVar1 = piVar5 + 1;
      piVar5 = piVar5 + 7;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 27320 ; VA 0x00c12720 ; thunk_FUN_00b0f780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b0f780(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edd06;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee0fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee0fc);
    if (DAT_01eee0fc == -1) {
      uStack_8 = 0;
      FUN_009ca470("NetworkOwnership");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eee098 = RBX::Reflection::EnumDesc<enum_RBX::NetworkOwnership>::vftable;
      FUN_009caf20(&DAT_01d66c4c,3);
      FUN_016f3654(&LAB_0188d1e0);
      FUN_016f37bf(&DAT_01eee0fc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee098;
}



/* FUNCTION 27321 ; VA 0x00c12730 ; FUN_00c12730 */

char * __thiscall FUN_00c12730(int param_1,char *param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  char *pcVar4;
  undefined4 uVar5;
  char *pcVar6;
  int *piVar7;
  int *piVar8;
  bool bVar9;
  
  piVar1 = (int *)(param_1 + 0x1c);
  if (param_1 == 0) {
    piVar1 = (int *)0x28;
  }
  uVar2 = *piVar1 + 1;
  if (*(uint *)(param_1 + 0x18) < uVar2) {
    uVar5 = 0xffffffff;
    if ((float)(((double)(int)uVar2 + (double)(&DAT_018c0d90)[-((int)uVar2 >> 0x1f)]) /
                (double)*(float *)(param_1 + 0x14) + DAT_018c0d60) < DAT_018c0d80) {
      uVar5 = FUN_016f3cd0();
    }
    FUN_00c19200(uVar5,param_2);
  }
  uVar5 = FUN_01078e00(param_2);
  iVar3 = FUN_008a4250(uVar5,*(undefined4 *)(param_1 + 4));
  piVar1 = (int *)(*(int *)(param_1 + 0x10) + iVar3 * 4);
  piVar7 = (int *)*piVar1;
  while( true ) {
    if (piVar7 == (int *)0x0) {
      pcVar4 = (char *)FUN_00c16a90(param_2,param_3,param_4);
      pcVar6 = (char *)*param_3;
      if (pcVar4 == pcVar6) {
        piVar8 = (int *)(-(uint)(*(int *)(param_1 + -8) != 0) & *(int *)(param_1 + -8) + 0x20U);
        piVar7 = (int *)(-(uint)(pcVar6 != (char *)0x0) & (uint)(pcVar6 + 0x20));
        if ((int *)*piVar1 == (int *)0x0) {
          iVar3 = *piVar8;
          *piVar7 = iVar3;
          piVar7[1] = *(int *)(*piVar8 + 4);
          *(int **)(iVar3 + 4) = piVar1;
          *piVar1 = (int)piVar7;
          *piVar8 = (int)piVar7;
          return pcVar4;
        }
        *piVar7 = *(int *)*piVar1;
        piVar7[1] = *piVar1;
        *piVar1 = (int)piVar7;
        *(int **)piVar7[1] = piVar7;
      }
      return pcVar4;
    }
    pcVar6 = (char *)(-(uint)(piVar7 != (int *)0x0) & (uint)(piVar7 + -8));
    if ((((*param_2 == *pcVar6) &&
         ((NAN(*(float *)(param_2 + 4)) || NAN(*(float *)(pcVar6 + 4))) !=
          (*(float *)(param_2 + 4) == *(float *)(pcVar6 + 4)))) &&
        ((NAN(*(float *)(param_2 + 0xc)) || NAN(*(float *)(pcVar6 + 0xc))) !=
         (*(float *)(param_2 + 0xc) == *(float *)(pcVar6 + 0xc)))) &&
       ((((NAN(*(float *)(param_2 + 8)) || NAN(*(float *)(pcVar6 + 8))) !=
          (*(float *)(param_2 + 8) == *(float *)(pcVar6 + 8)) &&
         ((NAN(*(float *)(param_2 + 0x10)) || NAN(*(float *)(pcVar6 + 0x10))) !=
          (*(float *)(param_2 + 0x10) == *(float *)(pcVar6 + 0x10)))) &&
        ((NAN(*(float *)(param_2 + 0x14)) || NAN(*(float *)(pcVar6 + 0x14))) !=
         (*(float *)(param_2 + 0x14) == *(float *)(pcVar6 + 0x14)))))) break;
    piVar8 = piVar7 + 1;
    bVar9 = *(int **)*piVar8 == piVar7;
    piVar7 = (int *)0x0;
    if (bVar9) {
      piVar7 = (int *)*piVar8;
    }
  }
  return pcVar6;
}



/* FUNCTION 27322 ; VA 0x00c128b0 ; FUN_00c128b0 */

void FUN_00c128b0(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar2 = FUN_00ca1730(param_1);
  iVar3 = FUN_00ca1730(param_2);
  iVar4 = *(int *)(param_1 + 0x1a8);
  if (iVar4 == 0) {
    iVar4 = *(int *)(param_2 + 0x1a8);
  }
  if (DAT_01d69068 == '\0') {
    if ((DAT_01d69070 == '\0') && (DAT_01d66be0 == '\0')) {
      cVar1 = (**(code **)(**(int **)(param_1 + 0x1b0) + 4))();
    }
    else {
      cVar1 = *(char *)(param_1 + 0x224);
    }
  }
  else {
    cVar1 = FUN_00ce7fb0(param_1,param_2);
  }
  if ((cVar1 != '\0') &&
     ((((((iVar2 = *(int *)(iVar2 + 0x40), iVar2 == 3 || (iVar2 == 1)) || (iVar2 == 2)) ||
        ((iVar2 = *(int *)(iVar3 + 0x40), iVar2 == 3 || (iVar2 == 1)))) ||
       ((iVar2 == 2 ||
        ((*(char *)(param_1 + 0x222) != '\0' || (*(char *)(param_2 + 0x222) != '\0')))))) ||
      (iVar4 != 0)))) {
    FUN_00bc0bc0(param_1,param_2,1);
  }
  return;
}



/* FUNCTION 27323 ; VA 0x00c12980 ; FUN_00c12980 */

void FUN_00c12980(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = FUN_00ca1730(param_1);
  iVar3 = FUN_00ca1730(param_2);
  if (DAT_01d69068 == '\0') {
    if ((DAT_01d69070 == '\0') && (DAT_01d66be0 == '\0')) {
      cVar1 = (**(code **)(**(int **)(param_1 + 0x1b0) + 4))();
    }
    else {
      cVar1 = *(char *)(param_1 + 0x224);
    }
  }
  else {
    cVar1 = FUN_00ce7fb0(param_1,param_2);
  }
  if ((cVar1 != '\0') &&
     (((((iVar2 = *(int *)(iVar2 + 0x40), iVar2 == 3 || (iVar2 == 1)) || (iVar2 == 2)) ||
       ((iVar2 = *(int *)(iVar3 + 0x40), iVar2 == 3 || (iVar2 == 1)))) ||
      ((iVar2 == 2 || ((*(char *)(param_1 + 0x222) != '\0' || (*(char *)(param_2 + 0x222) != '\0')))
       ))))) {
    FUN_00bc0bc0(param_1,param_2,0);
  }
  return;
}



/* FUNCTION 27324 ; VA 0x00c12a50 ; FUN_00c12a50 */

void FUN_00c12a50(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,int param_11,int param_12)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 *puStack_38;
  undefined4 *puStack_34;
  uint uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_11;
  puStack_c = &LAB_01806010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != 0) {
    ExceptionList = &pvStack_10;
    if ((param_12 != 1) || (ExceptionList = &pvStack_10, *(int *)(param_11 + 0x1b0) == 0))
    goto LAB_00c12abf;
    uStack_30 = 0xc12a9c;
    ExceptionList = &pvStack_10;
    iVar2 = (**(code **)(**(int **)(param_11 + 0x1ac) + 8))();
    if (iVar2 == 10) goto LAB_00c12abf;
  }
  if (param_1 == 0) {
    uStack_30 = 0xc12b82;
    uStack_30 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    puStack_34 = (undefined4 *)&UNK_00c12b8c;
    FUN_0054e5e0();
  }
  uStack_30 = param_9;
  puStack_38 = &param_3;
  puStack_34 = (undefined4 *)iVar3;
  uStack_3c = 0xc12abc;
  (**(code **)((param_1 & 0xfffffffe) + 4))();
LAB_00c12abf:
  iVar2 = 0;
  if (0 < *(int *)(iVar3 + 0x14)) {
    do {
      iVar3 = *(int *)(*(int *)(iVar3 + 0x10) + iVar2 * 4);
      uVar4 = -(uint)(iVar3 != 0) & iVar3 - 8U;
      puStack_34 = (undefined4 *)0xc12adb;
      uStack_30 = uVar4;
      cVar1 = FUN_00ca1a80();
      if (cVar1 == '\0') {
        uStack_30 = param_12;
        puStack_34 = (undefined4 *)uVar4;
        if (param_1 != 0) {
          if ((param_1 & 1) == 0) {
            (**(code **)(param_1 & 0xfffffffe))(&param_3,&uStack_54,0);
          }
          else {
            uStack_54 = param_3;
            uStack_50 = param_4;
            uStack_4c = param_5;
            uStack_48 = param_6;
            uStack_44 = param_7;
            uStack_40 = param_8;
          }
        }
        uStack_3c = param_9;
        FUN_00c12a50();
      }
      iVar2 = iVar2 + 1;
      iVar3 = param_11;
    } while (iVar2 < *(int *)(param_11 + 0x14));
  }
  uStack_8 = 2;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_38 = &param_3;
    uStack_30 = 2;
    uStack_3c = 0xc12b65;
    puStack_34 = puStack_38;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27325 ; VA 0x00c12b90 ; FUN_00c12b90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00c12b90(undefined4 param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,uint param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined4 param_17,undefined4 param_18,undefined4 param_19,undefined4 *param_20,
            int param_21)

{
  int iVar1;
  uint *puVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  uint auStack_b4 [2];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  uint uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 *puStack_70;
  undefined4 *puStack_6c;
  undefined4 *puStack_68;
  undefined auStack_5c [8];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puVar5 = param_20;
  puStack_c = &LAB_01806040;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  if (param_21 != 0) {
    ExceptionList = &pvStack_10;
    if ((param_21 != 1) || (ExceptionList = &pvStack_10, param_20[0x6c] == 0)) goto LAB_00c12c68;
    puStack_68 = (undefined4 *)0xc12be4;
    ExceptionList = &pvStack_10;
    iVar4 = (**(code **)(*(int *)param_20[0x6b] + 8))();
    if (iVar4 == 10) goto LAB_00c12c68;
  }
  if (param_2 == 0) {
    puStack_68 = (undefined4 *)0xc12d64;
    puStack_68 = (undefined4 *)FUN_0054fda0();
    iStack_8 = CONCAT31(iStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    puStack_6c = (undefined4 *)0xc12d6e;
    FUN_0054e5e0();
  }
  puStack_68 = (undefined4 *)param_19;
  puStack_70 = &param_4;
  puStack_6c = puVar5;
  uStack_74 = 0xc12c04;
  (**(code **)((param_2 & 0xfffffffe) + 4))();
  puStack_68 = (undefined4 *)auStack_5c;
  uStack_54 = _DAT_018c4eb0;
  uStack_50 = _UNK_018c4eb4;
  uStack_4c = _UNK_018c4eb8;
  uStack_48 = _UNK_018c4ebc;
  uStack_44 = 0xff7fffff;
  puStack_6c = puVar5;
  uStack_40 = 0xff7fffff;
  uStack_3c = _DAT_018e0090;
  uStack_38 = _UNK_018e0094;
  uStack_34 = _UNK_018e0098;
  uStack_30 = _UNK_018e009c;
  uStack_2c = 0x80000000;
  uStack_28 = 0x80000000;
  puStack_70 = (undefined4 *)0xc12c46;
  cVar3 = FUN_00ce7620();
  if (cVar3 != '\0') {
    if (param_10 == 0) {
      puStack_68 = (undefined4 *)0xc12d76;
      puStack_68 = (undefined4 *)FUN_0054fda0();
      iStack_8 = CONCAT31(iStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      puStack_6c = (undefined4 *)&UNK_00c12d80;
      FUN_0054e5e0();
    }
    puStack_68 = (undefined4 *)auStack_5c;
    puStack_6c = &param_12;
    puStack_70 = (undefined4 *)0xc12c65;
    (**(code **)((param_10 & 0xfffffffe) + 4))();
  }
LAB_00c12c68:
  iVar4 = 0;
  if (0 < (int)puVar5[5]) {
    do {
      iVar1 = *(int *)(puVar5[4] + iVar4 * 4);
      puVar5 = (undefined4 *)(-(uint)(iVar1 != 0) & iVar1 - 8U);
      puStack_6c = (undefined4 *)0xc12c88;
      puStack_68 = puVar5;
      cVar3 = FUN_00ca1a80();
      if (cVar3 == '\0') {
        puStack_68 = (undefined4 *)param_21;
        puStack_18 = (undefined *)auStack_b4;
        auStack_b4[0] = 0;
        puStack_6c = puVar5;
        puVar2 = auStack_b4;
        if (param_2 != 0) {
          auStack_b4[0] = param_2;
          if ((param_2 & 1) == 0) {
            (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_ac,0);
            puVar2 = (uint *)puStack_18;
          }
          else {
            uStack_ac = param_4;
            uStack_a8 = param_5;
            uStack_a4 = param_6;
            uStack_a0 = param_7;
            uStack_9c = param_8;
            uStack_98 = param_9;
            puVar2 = auStack_b4;
          }
        }
        puStack_18 = (undefined *)puVar2;
        uStack_94 = 0;
        iStack_8._0_1_ = 3;
        if (param_10 != 0) {
          uStack_94 = param_10;
          if ((param_10 & 1) == 0) {
            (**(code **)(param_10 & 0xfffffffe))(&param_12,&uStack_8c,0);
          }
          else {
            uStack_8c = param_12;
            uStack_88 = param_13;
            uStack_84 = param_14;
            uStack_80 = param_15;
            uStack_7c = param_16;
            uStack_78 = param_17;
          }
        }
        uStack_74 = param_18;
        puStack_70 = (undefined4 *)param_19;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_00c12b90();
      }
      iVar4 = iVar4 + 1;
      puVar5 = param_20;
    } while (iVar4 < (int)param_20[5]);
  }
  puStack_68 = (undefined4 *)0xc12d4a;
  FUN_008c3510();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27326 ; VA 0x00c12d90 ; FUN_00c12d90 */

void FUN_00c12d90(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  
  if (((param_3 == 0) ||
      (((param_3 == 1 && (*(int *)(param_2 + 0x1b0) != 0)) &&
       (iVar3 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))(), iVar3 != 10)))) &&
     (FUN_00ca1ae0(param_2,0), DAT_01d69070 == '\0')) {
    FUN_00ce7450(param_2);
  }
  iVar3 = 0;
  if (0 < *(int *)(param_2 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_2 + 0x10) + iVar3 * 4);
      uVar4 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      cVar2 = FUN_00ca1a80(uVar4);
      if (cVar2 == '\0') {
        FUN_00c12d90(param_1,uVar4,param_3);
      }
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_2 + 0x14));
  }
  return;
}



/* FUNCTION 27327 ; VA 0x00c12e20 ; FUN_00c12e20 */

uint * __thiscall FUN_00c12e20(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806058;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  uVar1 = param_2[8];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[8] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
    }
    else {
      uVar1 = param_2[0xb];
      uVar2 = param_2[0xc];
      uVar3 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar1;
      param_1[0xc] = uVar2;
      param_1[0xd] = uVar3;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
    }
  }
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27328 ; VA 0x00c12ef0 ; FUN_00c12ef0 */

int * __thiscall FUN_00c12ef0(int *param_1,undefined4 param_2,int param_3,undefined *param_4)

{
  undefined4 *puVar1;
  undefined **ppuVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  undefined **ppuVar8;
  
  ppuVar8 = (undefined **)&DAT_018be080;
  iVar4 = 0x1c;
  do {
    iVar6 = iVar4 >> 1;
    if (ppuVar8[iVar6] < param_4) {
      ppuVar8 = ppuVar8 + iVar6 + 1;
      iVar6 = iVar4 + (-1 - iVar6);
    }
    iVar4 = iVar6;
  } while (0 < iVar6);
  ppuVar2 = (undefined **)&DAT_018be0ec;
  if (ppuVar8 != &std::basic_ostream<char,struct_std::char_traits<char>_>::vftable_meta_ptr) {
    ppuVar2 = ppuVar8;
  }
  *param_1 = (int)(ppuVar2 + -0x62f820) >> 2;
  uVar3 = *(int *)(&DAT_018be080 + ((int)(ppuVar2 + -0x62f820) >> 2) * 4) + 1;
  param_1[2] = uVar3;
  if (uVar3 == 0) {
LAB_00c12fa8:
    puVar5 = (undefined4 *)0x0;
  }
  else {
    uVar7 = uVar3 * 4;
    if (uVar3 < 0x40000000) {
      if (uVar7 < 0x1000) {
        if (uVar7 != 0) {
          puVar5 = (undefined4 *)FUN_01674e20(uVar7);
          goto LAB_00c12faa;
        }
        goto LAB_00c12fa8;
      }
    }
    else {
      uVar7 = 0xffffffff;
    }
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    puVar5 = (undefined4 *)(iVar4 + 0x23U & 0xffffffe0);
    puVar5[-1] = iVar4;
  }
LAB_00c12faa:
  param_1[3] = (int)puVar5;
  puVar1 = puVar5 + *(int *)(&DAT_018be080 + *param_1 * 4);
  for (; puVar5 != puVar1; puVar5 = puVar5 + 1) {
    *puVar5 = 0;
  }
  *(int *)param_3 = param_3;
  *(int *)(param_1[3] + *(int *)(&DAT_018be080 + *param_1 * 4) * 4) = param_3;
  *(int *)(param_3 + 4) = param_1[3] + *(int *)(&DAT_018be080 + *param_1 * 4) * 4;
  return param_1;
}



/* FUNCTION 27329 ; VA 0x00c13010 ; FUN_00c13010 */

undefined4 * __fastcall FUN_00c13010(undefined4 *param_1)

{
  param_1[4] = 0;
  param_1[6] = 0;
  *param_1 = RBX::Block::vftable;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[10] = 0;
  return param_1;
}



/* FUNCTION 27330 ; VA 0x00c13070 ; FUN_00c13070 */

int * __thiscall FUN_00c13070(int *param_1,int param_2,int param_3)

{
  int iVar1;
  
  param_1[3] = 0;
  iVar1 = param_3;
  if ((int)(*(int *)(param_2 + 0x1d4) - *(int *)(param_2 + 0x1d0) & 0xfffffff8U) <
      (int)(*(int *)(param_3 + 0x1d4) - *(int *)(param_3 + 0x1d0) & 0xfffffff8U)) {
    iVar1 = param_2;
  }
  *param_1 = iVar1;
  if (iVar1 == param_2) {
    param_2 = param_3;
  }
  param_1[1] = param_2;
  param_1[2] = *(int *)(iVar1 + 0x1d4) - *(int *)(iVar1 + 0x1d0) >> 3;
  return param_1;
}



/* FUNCTION 27331 ; VA 0x00c130d0 ; FUN_00c130d0 */

undefined4 * __thiscall FUN_00c130d0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018060d1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::IPipelined::vftable;
  param_1[1] = 0;
  puVar1 = param_1 + 2;
  uStack_8 = 0;
  puStack_18 = puVar1;
  puStack_14 = param_1;
  FUN_01078820();
  *puVar1 = RBX::SpanningNode::vftable;
  param_1[0xb] = 0;
  param_1[0xc] = 0x7fffffff;
  param_1[0xd] = 0x7fffffff;
  param_1[0xe] = 0x7fffffff;
  param_1[0xf] = 0x80000000;
  param_1[0x10] = 0x80000000;
  param_1[0x11] = 0x80000000;
  *(undefined2 *)(param_1 + 0x12) = 0x2ff;
  *(undefined *)((int)param_1 + 0x4a) = 0;
  uStack_8._0_1_ = 2;
  FUN_00f9f610();
  *param_1 = RBX::Primitive::vftable;
  *puVar1 = RBX::Primitive::vftable;
  param_1[0x66] = 0;
  uStack_8._0_1_ = 4;
  *(undefined *)(param_1 + 0x67) = 0;
  param_1[0x68] = 0;
  param_1[0x69] = 0;
  param_1[0x6a] = 0;
  uVar3 = FUN_00c16be0(param_2);
  param_1[0x6b] = uVar3;
  param_1[0x6c] = 0;
  param_1[0x6d] = 0;
  param_1[0x6e] = 0;
  param_1[0x6f] = param_1;
  param_1[0x70] = 0;
  param_1[0x71] = 0;
  param_1[0x72] = 0;
  param_1[0x73] = param_1;
  param_1[0x74] = 0;
  param_1[0x75] = 0;
  param_1[0x76] = 0;
  uStack_8._0_1_ = 6;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadcf4) {
    uStack_8._0_1_ = uVar2;
    FUN_016f3809(&DAT_01eadcf4);
    if (DAT_01eadcf4 == -1) {
      DAT_01eadcf0 = 0xffffffff;
      FUN_016f37bf(&DAT_01eadcf4);
    }
  }
  param_1[0x77] = DAT_01eadcf0;
  param_1[0x78] = 0xffffffff;
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0xffffffff;
  param_1[0x7c] = 0x7f7fffff;
  param_1[0x7d] = 0x7f7fffff;
  param_1[0x7e] = 0x7f7fffff;
  param_1[0x7f] = 0xff7fffff;
  param_1[0x80] = 0xff7fffff;
  param_1[0x81] = 0xff7fffff;
  param_1[0x82] = 0xfffffffe;
  param_1[0x83] = 0;
  param_1[0x84] = 0;
  param_1[0x85] = 0;
  param_1[0x86] = 0x3f400000;
  auStack_30[0] = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  FUN_00c16ad0(param_1 + 0x87,auStack_30);
  param_1[0x88] = 0x100;
  param_1[0x89] = 0x10000;
  param_1[0x8a] = 0x100;
  iVar4 = 6;
  *(undefined2 *)(param_1 + 0x8b) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  *(undefined *)((int)param_1 + 0x22e) = 0;
  do {
    FUN_0054eb90();
    iVar4 = iVar4 + -1;
  } while (iVar4 != 0);
  param_1[0x8e] = 0;
  if (DAT_01ee41fd != '\0') {
    FUN_016774b0(DAT_01ee41fd,"Primitive %p created",param_1);
  }
  *(undefined4 *)((int)param_1 + 0x22f) = 0;
  *(undefined2 *)((int)param_1 + 0x233) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27332 ; VA 0x00c133d0 ; FUN_00c133d0 */

void __fastcall FUN_00c133d0(int *param_1)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  LOCK();
  iVar1 = *(int *)(*param_1 + 0x18) + -1;
  ExceptionList = &pvStack_10;
  *(int *)(*param_1 + 0x18) = iVar1;
  UNLOCK();
  if (iVar1 == 0) {
    FUN_00c16790();
    uVar2 = DAT_01ef8e28;
    EnterCriticalSection(DAT_01ef8e28);
    cVar3 = FUN_0089d8f0(param_1);
    if (cVar3 != '\0') {
      FUN_00c15230(*param_1);
    }
    LeaveCriticalSection(uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27333 ; VA 0x00c13450 ; FUN_00c13450 */

void __fastcall FUN_00c13450(uint param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar1 = *(int *)((-(uint)(param_1 != 0xfffffff4) & param_1) + 4);
  puVar6 = (undefined4 *)(-(uint)(iVar1 != 0) & iVar1 + 0x20U);
  puVar3 = (undefined4 *)*puVar6;
  while (puVar3 != puVar6) {
    puVar2 = (undefined4 *)*puVar3;
    FUN_01674ea0(puVar3 + -8,0x28);
    puVar3 = puVar2;
  }
  if (*(int *)(param_1 + 0x18) != 0) {
    iVar1 = *(int *)(param_1 + 0x1c);
    uVar5 = *(int *)(param_1 + 0x18) * 4;
    iVar4 = iVar1;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar1 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x28);
  return;
}



/* FUNCTION 27334 ; VA 0x00c134d0 ; FUN_00c134d0 */

void __fastcall FUN_00c134d0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = *param_1;
  if (iVar5 != 0) {
    iVar6 = param_1[1];
    if (iVar5 != iVar6) {
      piVar4 = (int *)(iVar5 + 0xc);
      do {
        iVar1 = piVar4[-2];
        if (iVar1 != 0) {
          uVar2 = *piVar4 - iVar1 & 0xfffffffc;
          iVar3 = iVar1;
          if (0xfff < uVar2) {
            iVar3 = *(int *)(iVar1 + -4);
            uVar2 = uVar2 + 0x23;
            if (0x1f < (iVar1 - iVar3) - 4U) goto LAB_00c1358b;
          }
          FUN_01674ea0(iVar3,uVar2);
          piVar4[-2] = 0;
          piVar4[-1] = 0;
          *piVar4 = 0;
        }
        iVar5 = iVar5 + 0x20;
        piVar4 = piVar4 + 8;
      } while (iVar5 != iVar6);
      iVar5 = *param_1;
    }
    uVar2 = param_1[2] - iVar5 & 0xffffffe0;
    iVar6 = iVar5;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
LAB_00c1358b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 27335 ; VA 0x00c135a0 ; FUN_00c135a0 */

void __fastcall FUN_00c135a0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = *param_1;
  if (iVar5 != 0) {
    iVar6 = param_1[1];
    if (iVar5 != iVar6) {
      piVar4 = (int *)(iVar5 + 0x18);
      do {
        iVar1 = piVar4[-2];
        if (iVar1 != 0) {
          uVar2 = *piVar4 - iVar1 & 0xfffffffc;
          iVar3 = iVar1;
          if (0xfff < uVar2) {
            iVar3 = *(int *)(iVar1 + -4);
            uVar2 = uVar2 + 0x23;
            if (0x1f < (iVar1 - iVar3) - 4U) goto LAB_00c1367b;
          }
          FUN_01674ea0(iVar3,uVar2);
          piVar4[-2] = 0;
          piVar4[-1] = 0;
          *piVar4 = 0;
        }
        iVar5 = iVar5 + 0x1c;
        piVar4 = piVar4 + 7;
      } while (iVar5 != iVar6);
      iVar5 = *param_1;
    }
    uVar2 = ((param_1[2] - iVar5) / 0x1c) * 0x1c;
    iVar6 = iVar5;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
LAB_00c1367b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 27336 ; VA 0x00c13690 ; FUN_00c13690 */

void __fastcall FUN_00c13690(int param_1)

{
  *(undefined *)(param_1 + 0x18) = 0xfe;
  return;
}



/* FUNCTION 27337 ; VA 0x00c136a0 ; FUN_00c136a0 */

void __fastcall FUN_00c136a0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xc) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 4) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  return;
}



/* FUNCTION 27338 ; VA 0x00c13700 ; FUN_00c13700 */

void __fastcall FUN_00c13700(undefined4 *param_1)

{
  *param_1 = RBX::Geometry::vftable;
  if ((int *)param_1[4] != (int *)0x0) {
    (**(code **)(*(int *)param_1[4] + 4))(1);
  }
  return;
}



/* FUNCTION 27339 ; VA 0x00c13720 ; FUN_00c13720 */

void __fastcall FUN_00c13720(undefined4 *param_1)

{
  *param_1 = RBX::IPipelined::vftable;
  return;
}



/* FUNCTION 27340 ; VA 0x00c13730 ; FUN_00c13730 */

void FUN_00c13730(void)

{
  FUN_00c134d0();
  FUN_00617bc0();
  FUN_00c135a0();
  return;
}



/* FUNCTION 27341 ; VA 0x00c13750 ; FUN_00c13750 */

void __fastcall FUN_00c13750(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[2] = RBX::Primitive::vftable;
  *param_1 = RBX::Primitive::vftable;
  if ((int *)param_1[0x6b] != (int *)0x0) {
    (**(code **)(*(int *)param_1[0x6b] + 4))(1);
  }
  FUN_01674ea0(param_1[0x8e]);
  if ((int *)param_1[0x69] != (int *)0x0) {
    (**(code **)(*(int *)param_1[0x69] + 4))(1);
  }
  if (DAT_01ee41fd != '\0') {
    FUN_016774b0(DAT_01ee41fd,"Primitive %p destroyed",param_1);
  }
  piVar1 = param_1 + 0x87;
  uStack_8 = 0;
  LOCK();
  iVar2 = *(int *)(*piVar1 + 0x18) + -1;
  *(int *)(*piVar1 + 0x18) = iVar2;
  UNLOCK();
  if (iVar2 == 0) {
    FUN_00c16790();
    uVar3 = DAT_01ef8e28;
    EnterCriticalSection(DAT_01ef8e28);
    cVar4 = FUN_0089d8f0(piVar1);
    if (cVar4 != '\0') {
      FUN_00c15230(*piVar1);
    }
    LeaveCriticalSection(uVar3);
  }
  iVar2 = param_1[0x74];
  if (iVar2 != 0) {
    uVar6 = param_1[0x76] - iVar2 & 0xfffffff8;
    iVar5 = iVar2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar5) - 4U) goto LAB_00c13903;
    }
    FUN_01674ea0(iVar5,uVar6);
    param_1[0x74] = 0;
    param_1[0x75] = 0;
    param_1[0x76] = 0;
  }
  iVar2 = param_1[0x70];
  if (iVar2 != 0) {
    uVar6 = param_1[0x72] - iVar2 & 0xfffffff8;
    iVar5 = iVar2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar5) - 4U) {
LAB_00c13903:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    param_1[0x70] = 0;
    param_1[0x71] = 0;
    param_1[0x72] = 0;
  }
  FUN_016790b0();
  FUN_00f9f7d0();
  *(undefined *)(param_1 + 0x12) = 0xfe;
  param_1[2] = RBX::SpanningNode::vftable;
  FUN_01078870();
  *param_1 = RBX::IPipelined::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27342 ; VA 0x00c13910 ; FUN_00c13910 */

void __fastcall FUN_00c13910(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  piVar1 = *(int **)(param_1 + 0x18);
  if (piVar1 != (int *)0x0) {
    iVar2 = *piVar1;
    if (iVar2 != 0) {
      uVar4 = piVar1[2] - iVar2 & 0xfffffffc;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
      *piVar1 = 0;
      piVar1[1] = 0;
      piVar1[2] = 0;
    }
    FUN_01674ea0(piVar1,0x18);
  }
  return;
}



/* FUNCTION 27343 ; VA 0x00c13980 ; FUN_00c13980 */

void __fastcall FUN_00c13980(undefined4 *param_1)

{
  *param_1 = RBX::SpanningNode::vftable;
  FUN_01078870();
  return;
}



/* FUNCTION 27344 ; VA 0x00c13990 ; FUN_00c13990 */

void __fastcall FUN_00c13990(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    FUN_005789c0(&DAT_01ef8e5c,&LAB_00c18030);
    iVar5 = FUN_00c17ab0();
    puVar1 = (uint *)(iVar5 + 8);
    do {
      LOCK();
      uVar3 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar3 & 1) != 0);
    piVar2 = (int *)(iVar4 + 4);
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      uVar6 = *(undefined4 *)(iVar4 + 8);
      FUN_00551320();
      uVar6 = FUN_00553830(uVar6);
      FUN_01674ea0(uVar6,0x18);
      FUN_00550be0();
      FUN_01674ea0(iVar4,0xc);
    }
    *puVar1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27345 ; VA 0x00c13a40 ; FUN_00c13a40 */

void __fastcall FUN_00c13a40(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    FUN_005789c0(&DAT_01ef8e6c,&LAB_00c18040);
    iVar5 = FUN_00c17b60();
    puVar1 = (uint *)(iVar5 + 8);
    do {
      LOCK();
      uVar3 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar3 & 1) != 0);
    piVar2 = (int *)(iVar4 + 0x60);
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      uVar6 = *(undefined4 *)(iVar4 + 100);
      FUN_00551320();
      uVar6 = FUN_00553830(uVar6);
      FUN_01674ea0(uVar6,0x20);
      FUN_01674ea0(iVar4,0x68);
    }
    *puVar1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27346 ; VA 0x00c13ae0 ; FUN_00c13ae0 */

void __fastcall FUN_00c13ae0(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    FUN_005789c0(&DAT_01ef8e74,&LAB_00c18050);
    iVar5 = FUN_00c17c10();
    puVar1 = (uint *)(iVar5 + 8);
    do {
      LOCK();
      uVar3 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar3 & 1) != 0);
    piVar2 = (int *)(iVar4 + 0x24);
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      uVar6 = *(undefined4 *)(iVar4 + 0x28);
      FUN_00551320();
      uVar6 = FUN_00553830(uVar6);
      FUN_01674ea0(uVar6,0x20);
      FUN_00c134d0();
      FUN_00617bc0();
      FUN_00c135a0();
      FUN_01674ea0(iVar4,0x2c);
    }
    *puVar1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27347 ; VA 0x00c13ba0 ; FUN_00c13ba0 */

void __fastcall FUN_00c13ba0(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    FUN_005789c0(&DAT_01ef8e64,&LAB_00c18060);
    iVar5 = FUN_00c17cc0();
    puVar1 = (uint *)(iVar5 + 8);
    do {
      LOCK();
      uVar3 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar3 & 1) != 0);
    piVar2 = (int *)(iVar4 + 4);
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      uVar6 = *(undefined4 *)(iVar4 + 8);
      FUN_00551320();
      uVar6 = FUN_00553830(uVar6);
      FUN_01674ea0(uVar6,0x20);
      FUN_00550be0();
      FUN_01674ea0(iVar4,0xc);
    }
    *puVar1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27348 ; VA 0x00c13c50 ; FUN_00c13c50 */

void __fastcall FUN_00c13c50(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    FUN_005789c0(&DAT_01ef8e3c,&LAB_00c18070);
    iVar5 = FUN_00c17d70();
    puVar1 = (uint *)(iVar5 + 8);
    do {
      LOCK();
      uVar3 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar3 & 1) != 0);
    piVar2 = (int *)(iVar4 + 4);
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      uVar6 = *(undefined4 *)(iVar4 + 8);
      FUN_00551320();
      uVar6 = FUN_00553830(uVar6);
      FUN_01674ea0(uVar6,0x20);
      FUN_00550be0();
      FUN_01674ea0(iVar4,0xc);
    }
    *puVar1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27349 ; VA 0x00c13d00 ; FUN_00c13d00 */

void __fastcall FUN_00c13d00(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    FUN_005789c0(&DAT_01ef8e4c,&LAB_00c18080);
    iVar5 = FUN_00c17e20();
    puVar1 = (uint *)(iVar5 + 8);
    do {
      LOCK();
      uVar3 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar3 & 1) != 0);
    piVar2 = (int *)(iVar4 + 4);
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      uVar6 = *(undefined4 *)(iVar4 + 8);
      FUN_00551320();
      uVar6 = FUN_00553830(uVar6);
      FUN_01674ea0(uVar6,0x20);
      FUN_00550be0();
      FUN_01674ea0(iVar4,0xc);
    }
    *puVar1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27350 ; VA 0x00c13db0 ; FUN_00c13db0 */

void __fastcall FUN_00c13db0(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    FUN_005789c0(&DAT_01ef8e44,&LAB_00c18090);
    iVar5 = FUN_00c17ed0();
    puVar1 = (uint *)(iVar5 + 8);
    do {
      LOCK();
      uVar3 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar3 & 1) != 0);
    piVar2 = (int *)(iVar4 + 0x30);
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      uVar6 = *(undefined4 *)(iVar4 + 0x34);
      FUN_00551320();
      uVar6 = FUN_00553830(uVar6);
      FUN_01674ea0(uVar6,0x20);
      FUN_00c134d0();
      FUN_00617bc0();
      FUN_00c135a0();
      FUN_01674ea0(iVar4,0x38);
    }
    *puVar1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27351 ; VA 0x00c13e70 ; FUN_00c13e70 */

void __fastcall FUN_00c13e70(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    FUN_005789c0(&DAT_01ef8e54,&LAB_00c180a0);
    iVar5 = FUN_00c17f80();
    puVar1 = (uint *)(iVar5 + 8);
    do {
      LOCK();
      uVar3 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar3 & 1) != 0);
    piVar2 = (int *)(iVar4 + 0x24);
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      uVar6 = *(undefined4 *)(iVar4 + 0x28);
      FUN_00551320();
      uVar6 = FUN_00553830(uVar6);
      FUN_01674ea0(uVar6,0x20);
      FUN_00c134d0();
      FUN_00617bc0();
      FUN_00c135a0();
      FUN_01674ea0(iVar4,0x2c);
    }
    *puVar1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27352 ; VA 0x00c13f30 ; FUN_00c13f30 */

undefined __thiscall FUN_00c13f30(int param_1,int param_2)

{
  char cVar1;
  
  if ((((NAN(*(float *)(param_1 + 0x24)) || NAN(*(float *)(param_2 + 0x24))) !=
        (*(float *)(param_1 + 0x24) == *(float *)(param_2 + 0x24))) &&
      ((NAN(*(float *)(param_1 + 0x28)) || NAN(*(float *)(param_2 + 0x28))) !=
       (*(float *)(param_1 + 0x28) == *(float *)(param_2 + 0x28)))) &&
     ((NAN(*(float *)(param_1 + 0x2c)) || NAN(*(float *)(param_2 + 0x2c))) !=
      (*(float *)(param_1 + 0x2c) == *(float *)(param_2 + 0x2c)))) {
    cVar1 = FUN_01160ab0(param_2);
    if (((((cVar1 != '\0') &&
          ((NAN(*(float *)(param_1 + 0x30)) || NAN(*(float *)(param_2 + 0x30))) !=
           (*(float *)(param_1 + 0x30) == *(float *)(param_2 + 0x30)))) &&
         (((NAN(*(float *)(param_1 + 0x34)) || NAN(*(float *)(param_2 + 0x34))) !=
           (*(float *)(param_1 + 0x34) == *(float *)(param_2 + 0x34)) &&
          (((NAN(*(float *)(param_1 + 0x38)) || NAN(*(float *)(param_2 + 0x38))) !=
            (*(float *)(param_1 + 0x38) == *(float *)(param_2 + 0x38)) &&
           ((NAN(*(float *)(param_1 + 0x3c)) || NAN(*(float *)(param_2 + 0x3c))) !=
            (*(float *)(param_1 + 0x3c) == *(float *)(param_2 + 0x3c)))))))) &&
        ((NAN(*(float *)(param_1 + 0x40)) || NAN(*(float *)(param_2 + 0x40))) !=
         (*(float *)(param_1 + 0x40) == *(float *)(param_2 + 0x40)))) &&
       ((NAN(*(float *)(param_1 + 0x44)) || NAN(*(float *)(param_2 + 0x44))) !=
        (*(float *)(param_1 + 0x44) == *(float *)(param_2 + 0x44)))) {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 27353 ; VA 0x00c13fdf ; FUN_00c13fdf */

void FUN_00c13fdf(void)

{
  FUN_00c141a0();
  return;
}



/* FUNCTION 27354 ; VA 0x00c13ff0 ; FUN_00c13ff0 */

undefined4 * __thiscall FUN_00c13ff0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Ball::vftable;
  FUN_00c13990();
  *param_1 = RBX::Geometry::vftable;
  if ((int *)param_1[4] != (int *)0x0) {
    (**(code **)(*(int *)param_1[4] + 4))(1);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 27355 ; VA 0x00c14030 ; FUN_00c14030 */

undefined4 * __thiscall FUN_00c14030(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Block::vftable;
  FUN_00c13ba0();
  FUN_00c13ae0();
  FUN_00c13a40();
  *param_1 = RBX::Geometry::vftable;
  if ((int *)param_1[4] != (int *)0x0) {
    (**(code **)(*(int *)param_1[4] + 4))(1);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 27356 ; VA 0x00c14080 ; FUN_00c14080 */

undefined4 * __thiscall FUN_00c14080(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Collision::MidPhaseComponentBinding::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 27357 ; VA 0x00c140b0 ; FUN_00c140b0 */

undefined4 * __thiscall FUN_00c140b0(undefined4 *param_1,byte param_2)

{
  FUN_00c13c50();
  FUN_00c13db0();
  *param_1 = RBX::Geometry::vftable;
  if ((int *)param_1[4] != (int *)0x0) {
    (**(code **)(*(int *)param_1[4] + 4))(1);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 27358 ; VA 0x00c14100 ; FUN_00c14100 */

undefined4 * __thiscall FUN_00c14100(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Geometry::vftable;
  if ((int *)param_1[4] != (int *)0x0) {
    (**(code **)(*(int *)param_1[4] + 4))(1);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 27359 ; VA 0x00c14140 ; FUN_00c14140 */

undefined4 * __thiscall FUN_00c14140(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::IPipelined::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 27360 ; VA 0x00c14170 ; FUN_00c14170 */

undefined4 * __thiscall FUN_00c14170(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Collision::MidPhaseComponentBinding::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 27361 ; VA 0x00c141a0 ; FUN_00c141a0 */

undefined4 __thiscall FUN_00c141a0(undefined4 param_1,byte param_2)

{
  FUN_00c13750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x240);
  }
  return param_1;
}



/* FUNCTION 27362 ; VA 0x00c141d0 ; FUN_00c141d0 */

undefined4 * __thiscall FUN_00c141d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Collision::MidPhaseComponentBinding::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 27363 ; VA 0x00c14200 ; FUN_00c14200 */

undefined4 * __thiscall FUN_00c14200(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::SpanningNode::vftable;
  FUN_01078870();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 27364 ; VA 0x00c14230 ; FUN_00c14230 */

undefined4 * __thiscall FUN_00c14230(undefined4 *param_1,byte param_2)

{
  FUN_00c13d00();
  FUN_00c13e70();
  *param_1 = RBX::Geometry::vftable;
  if ((int *)param_1[4] != (int *)0x0) {
    (**(code **)(*(int *)param_1[4] + 4))(1);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 27365 ; VA 0x00c14280 ; FUN_00c14280 */

void __thiscall
FUN_00c14280(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018060f2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x1a0) == 0) {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_01674e20(0x180);
    uStack_8 = 0;
    if (iVar1 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_00f3b670(param_1);
    }
    *(undefined4 *)(param_1 + 0x1a0) = uVar2;
  }
  uStack_8 = 0xffffffff;
  FUN_00f44d30(param_3,param_4,param_5,param_6,param_9);
  FUN_00f44270(param_1,param_2,param_3,1,param_7,param_8);
  if ((*(int *)(param_1 + 0x1a8) != 0) && (*(int *)(*(int *)(param_1 + 0x1a8) + 0x110) != 0)) {
    FUN_00f3c610(param_4,param_5,param_9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27366 ; VA 0x00c14350 ; FUN_00c14350 */

void __fastcall FUN_00c14350(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x1a0);
  if (iVar1 != 0) {
    FUN_00f3bad0();
    FUN_01674ea0(iVar1,0x180);
    *(undefined4 *)(param_1 + 0x1a0) = 0;
  }
  return;
}



/* FUNCTION 27367 ; VA 0x00c14380 ; FUN_00c14380 */

void __fastcall FUN_00c14380(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x1a0);
  if (iVar1 != 0) {
    FUN_00f3bad0();
    FUN_01674ea0(iVar1,0x180);
    *(undefined4 *)(param_1 + 0x1a0) = 0;
  }
  iVar1 = 0;
  if (0 < *(int *)(param_1 + 0x14)) {
    do {
      FUN_00c14380();
      iVar1 = iVar1 + 1;
    } while (iVar1 < *(int *)(param_1 + 0x14));
  }
  return;
}



/* FUNCTION 27368 ; VA 0x00c143e0 ; FUN_00c143e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float * FUN_00c143e0(float *param_1,float *param_2)

{
  float fVar1;
  float10 fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  fVar4 = param_2[2];
  if (DAT_01962c98 <= param_2[2]) {
    fVar4 = DAT_01962c98;
  }
  fVar5 = param_2[1];
  if (DAT_01962c98 <= param_2[1]) {
    fVar5 = DAT_01962c98;
  }
  fVar3 = *param_2;
  if (DAT_01962c98 <= *param_2) {
    fVar3 = DAT_01962c98;
  }
  if (fVar4 <= 0.0) {
    fVar4 = 0.0;
  }
  if (fVar5 <= 0.0) {
    fVar5 = 0.0;
  }
  if (fVar3 <= 0.0) {
    fVar3 = 0.0;
  }
  *param_1 = fVar3;
  param_1[1] = fVar5;
  fVar1 = _DAT_01962c9c;
  param_1[2] = fVar4;
  if (fVar1 < fVar3 * fVar5 * fVar4) {
    fVar2 = (float10)FUN_01725280((double)(DAT_018d0938 / (fVar3 * fVar4)));
    param_1[1] = (float)fVar2;
  }
  return param_1;
}



/* FUNCTION 27369 ; VA 0x00c14490 ; FUN_00c14490 */

bool __thiscall FUN_00c14490(int *param_1,int param_2,float param_3)

{
  float10 fVar1;
  
  fVar1 = (float10)(**(code **)(*param_1 + 0x18))();
  return (float)((float10)*(float *)(param_2 + 0x28) - fVar1) < param_3;
}



/* FUNCTION 27370 ; VA 0x00c144c0 ; FUN_00c144c0 */

float * __thiscall FUN_00c144c0(int param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  code *pcVar7;
  float *pfVar8;
  uint uVar9;
  float fVar10;
  float fVar11;
  undefined8 uStack_58;
  float fStack_50;
  undefined8 uStack_4c;
  float fStack_44;
  undefined8 uStack_40;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  undefined auStack_28 [8];
  float fStack_20;
  float fStack_14;
  ulonglong uStack_10;
  int iStack_8;
  
  *param_2 = 3.4028235e+38;
  param_2[1] = 3.4028235e+38;
  param_2[2] = 3.4028235e+38;
  param_2[3] = -3.4028235e+38;
  param_2[4] = -3.4028235e+38;
  param_2[5] = -3.4028235e+38;
  iStack_8 = param_1;
  if ((DAT_01d69148 != '\0') && (*(char *)(param_1 + 0x19c) != '\0')) {
    FUN_00fa0810();
    pfVar8 = (float *)(**(code **)(**(int **)(iStack_8 + 0x1ac) + 0x58))(auStack_28,param_1 + 0x104)
    ;
    fStack_34 = *(float *)(param_1 + 0x128) + *pfVar8;
    fVar11 = *(float *)(param_1 + 0x128) - *pfVar8;
    fStack_30 = pfVar8[1] + *(float *)(param_1 + 300);
    fVar10 = *(float *)(param_1 + 300) - pfVar8[1];
    uStack_10 = (ulonglong)(uint)fStack_34;
    fStack_2c = pfVar8[2] + *(float *)(param_1 + 0x130);
    fStack_38 = *(float *)(param_1 + 0x130) - pfVar8[2];
    uStack_40 = CONCAT44(fVar10,fVar11);
    *param_2 = fVar11;
    param_2[1] = fVar10;
    param_2[2] = fStack_38;
    param_2[3] = fStack_34;
    *(ulonglong *)(param_2 + 4) = CONCAT44(fStack_2c,fStack_30);
    fStack_20 = fStack_2c;
    fStack_14 = fStack_38;
    pfVar8 = (float *)(**(code **)(**(int **)(iStack_8 + 0x1ac) + 0x58))(&fStack_34,param_1 + 0x14c)
    ;
    fVar10 = *pfVar8 + *(float *)(param_1 + 0x170);
    uStack_10 = (ulonglong)(uint)fVar10;
    fStack_44 = pfVar8[2] + *(float *)(param_1 + 0x178);
    fStack_50 = *(float *)(param_1 + 0x178) - pfVar8[2];
    uStack_58 = CONCAT44(*(float *)(param_1 + 0x174) - pfVar8[1],
                         *(float *)(param_1 + 0x170) - *pfVar8);
    uStack_4c = CONCAT44(pfVar8[1] + *(float *)(param_1 + 0x174),fVar10);
    fStack_20 = fStack_50;
    fStack_14 = fStack_44;
    FUN_007b4260(&uStack_58);
    fVar10 = DAT_01d70298;
    *param_2 = *param_2 - DAT_01d70298;
    param_2[1] = param_2[1] - fVar10;
    param_2[2] = param_2[2] - fVar10;
    param_2[3] = fVar10 + param_2[3];
    param_2[4] = fVar10 + param_2[4];
    param_2[5] = param_2[5] + fVar10;
    return param_2;
  }
  uVar9 = -(uint)(param_1 != 0) & param_1 + 0x50U;
  FUN_00fa07b0();
  pcVar7 = *(code **)(**(int **)(param_1 + 0x1ac) + 0x58);
  FUN_00fa07b0();
  pfVar8 = (float *)(*pcVar7)(&fStack_34,uVar9 + 0xb4);
  fVar10 = *(float *)(uVar9 + 0xd8);
  fVar11 = *(float *)(uVar9 + 0xe0);
  fVar1 = *(float *)(uVar9 + 0xdc);
  fVar2 = *pfVar8;
  fVar3 = pfVar8[1];
  fVar4 = pfVar8[1];
  fVar5 = pfVar8[2];
  fVar6 = pfVar8[2];
  *param_2 = fVar10 - *pfVar8;
  param_2[1] = fVar1 - fVar4;
  param_2[2] = fVar11 - fVar6;
  param_2[3] = fVar10 + fVar2;
  *(ulonglong *)(param_2 + 4) = CONCAT44(fVar11 + fVar5,fVar1 + fVar3);
  fVar10 = DAT_01d70298;
  *param_2 = *param_2 - DAT_01d70298;
  param_2[1] = param_2[1] - fVar10;
  param_2[2] = param_2[2] - fVar10;
  param_2[3] = fVar10 + param_2[3];
  param_2[4] = fVar10 + param_2[4];
  param_2[5] = fVar10 + param_2[5];
  return param_2;
}



/* FUNCTION 27371 ; VA 0x00c147c0 ; FUN_00c147c0 */

undefined8 * __thiscall FUN_00c147c0(int param_1,undefined8 *param_2)

{
  if (*(int *)(param_1 + 0x1a0) != 0) {
    FUN_00f3d9c0(param_2,&stack0x00000008);
    return param_2;
  }
  *param_2 = 0;
  return param_2;
}



/* FUNCTION 27372 ; VA 0x00c14800 ; FUN_00c14800 */

uint __fastcall FUN_00c14800(int param_1)

{
  uint in_EAX;
  uint uVar1;
  
  if (*(char *)(param_1 + 0x222) == '\0') {
    in_EAX = FUN_00ca1730(param_1);
    if (in_EAX != 0) {
      uVar1 = FUN_00ca0f40();
      return uVar1;
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 27373 ; VA 0x00c14820 ; FUN_00c14820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00c14820(undefined4 param_1,char param_2)

{
  int iVar1;
  float fVar2;
  short sStack_c;
  short sStack_a;
  short sStack_8;
  
  FUN_01168d80(param_1);
  if (param_2 != '\0') {
    iVar1 = (int)sStack_c;
    switch(iVar1) {
    case 1:
      return (float10)_DAT_0195c1a8;
    case 2:
      return (float10)_DAT_0195c1b8;
    case 3:
      return (float10)_DAT_0195c1c8;
    case 4:
      return (float10)_DAT_0195c1dc;
    default:
      return (float10)((float)(iVar1 * iVar1 * iVar1) * _DAT_0195c1a4);
    }
  }
  iVar1 = (int)sStack_c;
  if (iVar1 == 1) {
    switch((int)sStack_a) {
    case 1:
      switch((int)sStack_8) {
      case 1:
        return (float10)_DAT_0195c1b4;
      case 2:
        return (float10)_DAT_0195c1bc;
      case 3:
        return (float10)DAT_018daf58;
      case 4:
        return (float10)_DAT_0195c1c0;
      default:
        return (float10)((float)(int)sStack_8 * DAT_0191a25c);
      }
    case 2:
      goto switchD_00c149fe_caseD_2;
    case 3:
      _param_2 = 1.66;
      if (DAT_018fde90 <= (float)(int)sStack_8) {
        _param_2 = 1.18;
      }
      return (float10)(int)sStack_8 * (float10)_param_2;
    case 4:
      _param_2 = 2.26;
      if (DAT_018fde90 <= (float)(int)sStack_8) {
        _param_2 = 1.53;
      }
      return (float10)(int)sStack_8 * (float10)_param_2;
    default:
      return (float10)(((float)(int)sStack_a * DAT_018fde64 + _DAT_0195c1b0) * (float)(int)sStack_8)
      ;
    }
  }
  if (iVar1 != 2) {
    return (float10)((float)((int)sStack_8 * (int)sStack_a * iVar1) * DAT_018e1340);
  }
  iVar1 = (int)sStack_a;
  if (iVar1 == 2) {
    iVar1 = (int)sStack_8;
    if (iVar1 == 2) {
      return (float10)_DAT_0195c1d0;
    }
    if (iVar1 == 3) {
      return (float10)_DAT_0195c1d4;
    }
    if (iVar1 == 4) {
      return (float10)_DAT_0195c1d8;
    }
    _param_2 = 1.9;
    if (DAT_01919f9c <= (float)iVar1) {
      _param_2 = 1.5;
    }
    return (float10)iVar1 * (float10)_param_2;
  }
  if (iVar1 != 3) {
    return (float10)((float)iVar1 * _DAT_0195c1b0 * (float)(int)sStack_8);
  }
  iVar1 = (int)sStack_8;
  if (iVar1 == 3) {
    return (float10)DAT_01919f9c;
  }
  if (iVar1 == 4) {
    return (float10)DAT_0195c1e0;
  }
  fVar2 = (float)iVar1;
  if (DAT_01919f9c <= fVar2) {
    return (float10)(fVar2 * DAT_018df57c);
  }
  return (float10)(fVar2 + fVar2);
switchD_00c149fe_caseD_2:
  iVar1 = (int)sStack_8;
  if (iVar1 == 2) {
    return (float10)_DAT_0191a35c;
  }
  if (iVar1 == 3) {
    return (float10)_DAT_0195c1c4;
  }
  if (iVar1 == 4) {
    return (float10)_DAT_0195c1cc;
  }
  _param_2 = 0.9;
  if (DAT_01919f9c <= (float)iVar1) {
    _param_2 = 0.75;
  }
  return (float10)iVar1 * (float10)_param_2;
}



/* FUNCTION 27374 ; VA 0x00c14bb0 ; FUN_00c14bb0 */

undefined4 * __thiscall
FUN_00c14bb0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  uint uVar9;
  double dVar10;
  undefined4 uVar11;
  float fVar12;
  undefined4 uVar13;
  undefined auStack_124 [72];
  undefined auStack_dc [12];
  undefined auStack_d0 [36];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined8 uStack_1c;
  int iStack_14;
  undefined4 uStack_c;
  float fStack_8;
  
  uVar9 = -(uint)(param_1 != 0) & param_1 + 0x50U;
  iStack_14 = param_1;
  FUN_00fa07b0();
  uVar11 = *(undefined4 *)(uVar9 + 0xb8);
  uVar13 = *(undefined4 *)(uVar9 + 0xbc);
  uVar2 = *(undefined4 *)(uVar9 + 0xc0);
  *param_2 = *(undefined4 *)(uVar9 + 0xb4);
  param_2[1] = uVar11;
  param_2[2] = uVar13;
  param_2[3] = uVar2;
  uVar11 = *(undefined4 *)(uVar9 + 200);
  uVar13 = *(undefined4 *)(uVar9 + 0xcc);
  uVar2 = *(undefined4 *)(uVar9 + 0xd0);
  param_2[4] = *(undefined4 *)(uVar9 + 0xc4);
  param_2[5] = uVar11;
  param_2[6] = uVar13;
  param_2[7] = uVar2;
  uVar11 = *(undefined4 *)(uVar9 + 0xd8);
  uVar13 = *(undefined4 *)(uVar9 + 0xdc);
  uVar2 = *(undefined4 *)(uVar9 + 0xe0);
  param_2[8] = *(undefined4 *)(uVar9 + 0xd4);
  param_2[9] = uVar11;
  param_2[10] = uVar13;
  param_2[0xb] = uVar2;
  *(undefined8 *)(param_2 + 0xc) = *(undefined8 *)(uVar9 + 0xe4);
  param_2[0xe] = *(undefined4 *)(uVar9 + 0xec);
  *(undefined8 *)(param_2 + 0xf) = *(undefined8 *)(uVar9 + 0xf0);
  dVar10 = 0.0;
  param_2[0x11] = *(undefined4 *)(uVar9 + 0xf8);
  iVar1 = *(int *)(param_3 + 0x1a0);
  if ((iVar1 == 0) || (*(char *)(iVar1 + 2) == '\0')) {
    uVar11 = 0;
    uVar13 = 0;
  }
  else {
    uVar11 = *(undefined4 *)(iVar1 + 0xb8);
    uVar13 = *(undefined4 *)(iVar1 + 0xbc);
    uStack_c = uVar11;
    fStack_8 = (float)uVar13;
  }
  iVar1 = *(int *)(iStack_14 + 0x1a0);
  if ((iVar1 != 0) && (*(char *)(iVar1 + 2) != '\0')) {
    uStack_c = *(undefined4 *)(iVar1 + 0xb8);
    fStack_8 = *(float *)(iVar1 + 0xbc);
    dVar10 = *(double *)(iVar1 + 0xb8);
  }
  if ((NAN((double)CONCAT44(uVar13,uVar11)) || NAN(dVar10)) ==
      ((double)CONCAT44(uVar13,uVar11) == dVar10)) {
    FUN_00fa07b0();
    FUN_00fa07b0();
    puVar8 = (undefined4 *)FUN_007213c0(auStack_dc,uVar9 + 0xb4);
    uStack_9c = *puVar8;
    uStack_98 = puVar8[1];
    uStack_94 = puVar8[2];
    uStack_90 = puVar8[3];
    uStack_8c = puVar8[4];
    uStack_88 = puVar8[5];
    uStack_84 = puVar8[6];
    uStack_80 = puVar8[7];
    uStack_7c = puVar8[8];
    uStack_78 = *(undefined8 *)(puVar8 + 9);
    fStack_70 = (float)puVar8[0xb];
    uStack_ac = *(undefined4 *)(uVar9 + 0xe4);
    uStack_a8 = *(undefined4 *)(uVar9 + 0xe8);
    uStack_a4 = *(undefined4 *)(uVar9 + 0xec);
    uStack_a0 = *(undefined4 *)(uVar9 + 0xf0);
    uStack_24 = *(undefined8 *)(uVar9 + 0xf4);
  }
  else {
    FUN_00c15e70(&fStack_6c);
    FUN_00c15e70(auStack_124);
    puVar8 = (undefined4 *)FUN_007213c0(auStack_dc,&fStack_6c);
    uStack_9c = *puVar8;
    uStack_98 = puVar8[1];
    uStack_94 = puVar8[2];
    uStack_90 = puVar8[3];
    uStack_8c = puVar8[4];
    uStack_88 = puVar8[5];
    uStack_84 = puVar8[6];
    uStack_80 = puVar8[7];
    uStack_7c = puVar8[8];
    uStack_78 = *(undefined8 *)(puVar8 + 9);
    fStack_70 = (float)puVar8[0xb];
    uStack_ac = (undefined4)uStack_3c;
    uStack_a8 = uStack_3c._4_4_;
    uStack_a4 = uStack_34;
    uStack_a0 = uStack_30;
    uStack_24 = CONCAT44(uStack_28,uStack_2c);
  }
  uStack_1c = CONCAT44(param_7,param_6);
  uStack_c = param_4;
  fStack_8 = (float)param_5;
  if (*(int *)(param_3 + 0x1a0) == 0) {
    FUN_00fa07b0();
    fStack_6c = *(float *)(param_3 + 0x104);
    fStack_68 = *(float *)(param_3 + 0x108);
    fStack_64 = *(float *)(param_3 + 0x10c);
    fStack_60 = *(float *)(param_3 + 0x110);
    uStack_34 = *(undefined4 *)(param_3 + 0x13c);
    uStack_28 = *(undefined4 *)(param_3 + 0x148);
    fStack_5c = *(float *)(param_3 + 0x114);
    fStack_58 = *(float *)(param_3 + 0x118);
    fStack_54 = *(float *)(param_3 + 0x11c);
    fStack_50 = *(float *)(param_3 + 0x120);
    fStack_4c = *(float *)(param_3 + 0x124);
    fStack_48 = *(float *)(param_3 + 0x128);
    fStack_44 = *(float *)(param_3 + 300);
    fStack_40 = *(float *)(param_3 + 0x130);
    uStack_3c = *(undefined8 *)(param_3 + 0x134);
    uStack_30 = (undefined4)*(undefined8 *)(param_3 + 0x140);
    uStack_2c = (undefined4)((ulonglong)*(undefined8 *)(param_3 + 0x140) >> 0x20);
  }
  else {
    FUN_00f3d2e0(&fStack_6c,param_3,&uStack_1c,&uStack_c,param_8);
  }
  uStack_1c = (ulonglong)
              (uint)(fStack_68 * uStack_78._4_4_ + fStack_6c * (float)uStack_78 +
                     fStack_64 * fStack_70 + fStack_48);
  fVar12 = fStack_5c * uStack_78._4_4_ + fStack_60 * (float)uStack_78 + fStack_58 * fStack_70 +
           fStack_44;
  fStack_8 = fStack_50 * uStack_78._4_4_ + fStack_54 * (float)uStack_78 + fStack_4c * fStack_70 +
             fStack_40;
  puVar8 = (undefined4 *)FUN_01160c20(auStack_d0,&uStack_9c);
  uVar13 = puVar8[1];
  uVar2 = puVar8[2];
  uVar3 = puVar8[3];
  uVar4 = puVar8[4];
  uVar5 = puVar8[5];
  uVar6 = puVar8[6];
  uVar7 = puVar8[7];
  uVar11 = puVar8[8];
  *param_2 = *puVar8;
  param_2[1] = uVar13;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  param_2[4] = uVar4;
  param_2[5] = uVar5;
  param_2[6] = uVar6;
  param_2[7] = uVar7;
  param_2[8] = uVar11;
  param_2[9] = (int)uStack_1c;
  param_2[10] = fVar12;
  param_2[0xb] = fStack_8;
  param_2[0xc] = uStack_ac;
  param_2[0xd] = uStack_a8;
  param_2[0xe] = uStack_a4;
  param_2[0xf] = uStack_a0;
  *(undefined8 *)(param_2 + 0x10) = uStack_24;
  if (*(int *)(iStack_14 + 0x1a0) != 0) {
    *(undefined4 *)(*(int *)(iStack_14 + 0x1a0) + 4) = 0;
  }
  return param_2;
}



/* FUNCTION 27375 ; VA 0x00c14ef0 ; FUN_00c14ef0 */

undefined4 * __thiscall FUN_00c14ef0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 in_stack_00000018;
  
  if (*(int *)(param_1 + 0x1a0) != 0) {
    FUN_00f3d2e0(param_2,param_1,&stack0x00000010,&stack0x00000008,in_stack_00000018);
    return param_2;
  }
  FUN_00fa07b0();
  uVar1 = *(undefined4 *)(param_1 + 0x108);
  uVar2 = *(undefined4 *)(param_1 + 0x10c);
  uVar3 = *(undefined4 *)(param_1 + 0x110);
  *param_2 = *(undefined4 *)(param_1 + 0x104);
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar1 = *(undefined4 *)(param_1 + 0x118);
  uVar2 = *(undefined4 *)(param_1 + 0x11c);
  uVar3 = *(undefined4 *)(param_1 + 0x120);
  param_2[4] = *(undefined4 *)(param_1 + 0x114);
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  uVar1 = *(undefined4 *)(param_1 + 0x128);
  uVar2 = *(undefined4 *)(param_1 + 300);
  uVar3 = *(undefined4 *)(param_1 + 0x130);
  param_2[8] = *(undefined4 *)(param_1 + 0x124);
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  *(undefined8 *)(param_2 + 0xc) = *(undefined8 *)(param_1 + 0x134);
  param_2[0xe] = *(undefined4 *)(param_1 + 0x13c);
  *(undefined8 *)(param_2 + 0xf) = *(undefined8 *)(param_1 + 0x140);
  param_2[0x11] = *(undefined4 *)(param_1 + 0x148);
  return param_2;
}



/* FUNCTION 27376 ; VA 0x00c14f90 ; FUN_00c14f90 */

undefined4 * FUN_00c14f90(undefined4 *param_1,float *param_2,int param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  float fVar29;
  float fVar30;
  float fVar31;
  float fVar32;
  float fVar33;
  float fVar34;
  float fVar35;
  float fVar36;
  float fVar37;
  undefined4 uVar38;
  undefined4 uVar39;
  undefined4 uVar40;
  undefined4 uVar41;
  undefined4 uVar42;
  undefined4 uVar43;
  undefined4 uVar44;
  undefined4 uVar45;
  undefined4 *puVar46;
  float fVar47;
  float fVar48;
  float fVar49;
  float fVar50;
  undefined auStack_74 [100];
  float fStack_10;
  float fStack_8;
  
  fVar1 = *(float *)(param_3 + 0x28);
  fVar2 = *(float *)(param_3 + 0x24);
  fVar3 = *(float *)(param_3 + 0x2c);
  fVar49 = fVar1 * param_2[1] + fVar2 * *param_2 + fVar3 * param_2[2] + param_2[9];
  fVar50 = fVar1 * param_2[4] + fVar2 * param_2[3] + fVar3 * param_2[5] + param_2[10];
  fStack_8 = fVar2 * param_2[6] + fVar1 * param_2[7] + fVar3 * param_2[8] + param_2[0xb];
  fStack_10 = fStack_8;
  puVar46 = (undefined4 *)FUN_01160c20(auStack_74,param_3);
  fVar1 = *(float *)(param_3 + 0x40);
  fVar2 = *(float *)(param_3 + 0x3c);
  uVar39 = puVar46[1];
  uVar40 = puVar46[2];
  uVar41 = puVar46[3];
  fVar3 = *(float *)(param_3 + 0x44);
  fVar4 = *param_2;
  uVar42 = puVar46[4];
  uVar43 = puVar46[5];
  uVar44 = puVar46[6];
  uVar45 = puVar46[7];
  uVar38 = puVar46[8];
  fVar5 = param_2[3];
  fVar6 = param_2[1];
  fVar7 = param_2[6];
  fVar8 = param_2[2];
  fVar9 = param_2[4];
  fVar10 = param_2[7];
  fVar11 = param_2[5];
  fVar12 = param_2[8];
  fVar13 = param_2[0xf];
  fVar14 = param_2[0x10];
  fVar15 = *(float *)(param_3 + 0x34);
  fVar16 = *(float *)(param_3 + 0x38);
  fVar17 = param_2[0xb];
  fVar18 = param_2[6];
  fVar19 = param_2[0x11];
  fVar20 = *(float *)(param_3 + 0x30);
  fVar21 = *param_2;
  fVar22 = param_2[1];
  fVar23 = param_2[3];
  fVar24 = param_2[0x10];
  fVar25 = param_2[2];
  fVar26 = param_2[4];
  fVar27 = param_2[7];
  fVar28 = param_2[5];
  fVar29 = param_2[8];
  fVar47 = fVar49 - param_2[9];
  fVar48 = fVar50 - param_2[10];
  fVar30 = param_2[0x10];
  fVar31 = param_2[0x11];
  fVar32 = param_2[0xf];
  fVar33 = param_2[0xc];
  fVar34 = param_2[0x11];
  fVar35 = param_2[0xf];
  fVar36 = param_2[0xd];
  fVar37 = param_2[0xe];
  *param_1 = *puVar46;
  param_1[1] = uVar39;
  param_1[2] = uVar40;
  param_1[3] = uVar41;
  param_1[4] = uVar42;
  param_1[5] = uVar43;
  param_1[6] = uVar44;
  param_1[7] = uVar45;
  param_1[8] = uVar38;
  param_1[9] = fVar49;
  param_1[10] = fVar50;
  param_1[0xb] = fStack_10;
  *(ulonglong *)(param_1 + 0xc) =
       CONCAT44((fVar47 * fVar34 - (fStack_8 - fVar17) * fVar32) + fVar36 +
                fVar20 * fVar23 + fVar15 * fVar26 + fVar16 * fVar28,
                ((fStack_8 - fVar17) * fVar24 - fVar48 * fVar31) + fVar33 +
                fVar20 * fVar21 + fVar15 * fVar22 + fVar16 * fVar25);
  param_1[0xe] = (fVar48 * fVar35 - fVar47 * fVar30) + fVar37 +
                 fVar18 * fVar20 + fVar15 * fVar27 + fVar16 * fVar29;
  *(ulonglong *)(param_1 + 0xf) =
       CONCAT44(fVar14 + fVar2 * fVar5 + fVar1 * fVar9 + fVar3 * fVar11,
                fVar13 + fVar2 * fVar4 + fVar1 * fVar6 + fVar3 * fVar8);
  param_1[0x11] = fVar19 + fVar7 * fVar2 + fVar1 * fVar10 + fVar3 * fVar12;
  return param_1;
}



/* FUNCTION 27377 ; VA 0x00c15230 ; FUN_00c15230 */

void __thiscall FUN_00c15230(uint param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  piVar4 = (int *)(-(uint)(param_2 != 0) & param_2 + 0x20U);
  piVar3 = (int *)((-(uint)(param_1 != 0xfffffff4) & param_1) + 0x28);
  *piVar3 = *piVar3 + -1;
  puVar1 = (undefined4 *)piVar4[1];
  piVar3 = *(int **)(*piVar4 + 4);
  piVar2 = (int *)*puVar1;
  if (piVar3 == piVar4) {
    *(undefined4 **)(*piVar4 + 4) = puVar1;
    piVar3 = (int *)piVar4[1];
    if (piVar2 != piVar4) {
      piVar3 = (int *)*piVar3;
    }
  }
  else if (piVar2 == piVar4) {
    *piVar3 = (int)puVar1;
    piVar3 = (int *)piVar4[1];
  }
  else {
    *piVar3 = 0;
    *(int *)(*piVar4 + 4) = piVar4[1];
    piVar3 = *(int **)piVar4[1];
  }
  *piVar3 = *piVar4;
  FUN_01674ea0(param_2,0x28);
  return;
}



/* FUNCTION 27378 ; VA 0x00c152a0 ; FUN_00c152a0 */

void __thiscall FUN_00c152a0(int param_1,undefined4 param_2,float *param_3,int param_4)

{
  int iVar1;
  undefined uVar2;
  float *pfVar3;
  undefined4 uVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined auStack_48 [24];
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  undefined auStack_18 [8];
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fStack_8 = (float)DAT_01d68adc / DAT_018ce320;
  pfVar3 = (float *)(**(code **)(**(int **)(*(int *)(param_1 + 0xc) + 0x1ac) + 0x14))(auStack_18);
  iVar1 = *(int *)(param_1 + 0xc);
  fStack_c = *pfVar3 * DAT_018ce2f4 + fStack_8;
  fVar7 = (float)((uint)(*pfVar3 * DAT_018ce2f4) ^ DAT_018c4ea0) - fStack_8;
  fStack_20 = pfVar3[1] * DAT_018ce2f4 + fStack_8;
  fStack_1c = pfVar3[2] * DAT_018ce2f4 + fStack_8;
  fStack_2c = (float)((uint)(pfVar3[1] * DAT_018ce2f4) ^ DAT_018c4ea0) - fStack_8;
  fStack_8 = (float)((uint)(pfVar3[2] * DAT_018ce2f4) ^ DAT_018c4ea0) - fStack_8;
  fStack_24 = (fStack_c - fVar7) * DAT_018daf54;
  fVar6 = (fStack_20 - fStack_2c) * DAT_018daf54;
  fVar5 = (fStack_1c - fStack_8) * DAT_018daf54;
  fStack_2c = fStack_2c - fVar6;
  fStack_30 = fVar7 - fStack_24;
  fStack_28 = fStack_8 - fVar5;
  fStack_20 = fStack_20 + fVar6;
  fStack_1c = fStack_1c + fVar5;
  fStack_24 = fStack_c + fStack_24;
  fStack_8 = fVar7;
  FUN_00fa07b0();
  pfVar3 = (float *)FUN_00c9eef0(auStack_48,(-(uint)(iVar1 != 0) & iVar1 + 0x50U) + 0xb4,param_2);
  fVar5 = param_3[2];
  if (pfVar3[2] <= param_3[2]) {
    fVar5 = pfVar3[2];
  }
  fVar6 = param_3[1];
  if (pfVar3[1] <= param_3[1]) {
    fVar6 = pfVar3[1];
  }
  fVar7 = *param_3;
  if (*pfVar3 <= *param_3) {
    fVar7 = *pfVar3;
  }
  *(ulonglong *)param_3 = CONCAT44(fVar6,fVar7);
  param_3[2] = fVar5;
  fStack_10 = param_3[5];
  if (param_3[5] <= pfVar3[5]) {
    fStack_10 = pfVar3[5];
  }
  fVar5 = param_3[4];
  if (param_3[4] <= pfVar3[4]) {
    fVar5 = pfVar3[4];
  }
  fVar6 = param_3[3];
  if (param_3[3] <= pfVar3[3]) {
    fVar6 = pfVar3[3];
  }
  *(ulonglong *)(param_3 + 3) = CONCAT44(fVar5,fVar6);
  param_3[5] = fStack_10;
  if ((DAT_01d69070 == '\0') && (DAT_01d66be0 == '\0')) {
    uVar2 = (**(code **)(**(int **)(*(int *)(param_1 + 0xc) + 0x1b0) + 4))();
  }
  else {
    uVar2 = *(undefined *)(*(int *)(param_1 + 0xc) + 0x224);
  }
  *(undefined *)(param_4 + 1) = uVar2;
  if ((*(char *)(*(int *)(param_1 + 0xc) + 0x222) == '\0') &&
     (*(char *)(*(int *)(param_1 + 0xc) + 0x225) != '\0')) {
    uVar2 = 0;
  }
  else {
    uVar2 = 1;
  }
  *(undefined *)(param_4 + 2) = uVar2;
  uVar4 = FUN_00bbd8a0(CONCAT31((int3)((uint)*(int *)(param_1 + 0xc) >> 8),
                                *(undefined *)(*(int *)(param_1 + 0xc) + 0x22a)));
  *(undefined4 *)(param_4 + 4) = uVar4;
  if (DAT_01d69068 != '\0') {
    *(undefined *)(param_4 + 3) = *(undefined *)(*(int *)(param_1 + 0xc) + 0x226);
  }
  return;
}



/* FUNCTION 27379 ; VA 0x00c154f0 ; FUN_00c154f0 */

void __fastcall FUN_00c154f0(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_44 [24];
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined8 uStack_1c;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fStack_2c = *(float *)(param_1 + 0x1f0);
  fStack_28 = *(float *)(param_1 + 500);
  fStack_24 = *(float *)(param_1 + 0x1f8);
  fStack_20 = *(float *)(param_1 + 0x1fc);
  uStack_1c = *(undefined8 *)(param_1 + 0x200);
  fStack_14 = fStack_2c;
  fStack_10 = fStack_28;
  fStack_c = fStack_24;
  fStack_8 = fStack_20;
  puVar4 = (undefined4 *)FUN_00c144c0(auStack_44);
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *(undefined4 *)(param_1 + 0x1f0) = *puVar4;
  *(undefined4 *)(param_1 + 500) = uVar1;
  *(undefined4 *)(param_1 + 0x1f8) = uVar2;
  *(undefined4 *)(param_1 + 0x1fc) = uVar3;
  *(undefined8 *)(param_1 + 0x200) = *(undefined8 *)(puVar4 + 4);
  if ((((((NAN(fStack_14) || NAN(*(float *)(param_1 + 0x1f0))) ==
          (fStack_14 == *(float *)(param_1 + 0x1f0))) ||
        ((NAN(fStack_28) || NAN(*(float *)(param_1 + 500))) ==
         (fStack_28 == *(float *)(param_1 + 500)))) ||
       ((NAN(fStack_24) || NAN(*(float *)(param_1 + 0x1f8))) ==
        (fStack_24 == *(float *)(param_1 + 0x1f8)))) ||
      ((((NAN(fStack_20) || NAN(*(float *)(param_1 + 0x1fc))) ==
         (fStack_20 == *(float *)(param_1 + 0x1fc)) ||
        ((NAN((float)uStack_1c) || NAN(*(float *)(param_1 + 0x200))) ==
         ((float)uStack_1c == *(float *)(param_1 + 0x200)))) ||
       ((NAN(uStack_1c._4_4_) || NAN(*(float *)(param_1 + 0x204))) ==
        (uStack_1c._4_4_ == *(float *)(param_1 + 0x204)))))) && (*(int *)(param_1 + 0x1a8) != 0)) {
    FUN_00bbf330(param_1);
  }
  return;
}



/* FUNCTION 27380 ; VA 0x00c155c0 ; FUN_00c155c0 */

void __fastcall FUN_00c155c0(undefined4 param_1)

{
  FUN_00ca1730(param_1);
  return;
}



/* FUNCTION 27381 ; VA 0x00c155d0 ; FUN_00c155d0 */

float10 __fastcall FUN_00c155d0(int param_1)

{
  if (*(int *)(param_1 + 0x1a0) != 0) {
    return (float10)*(float *)(*(int *)(param_1 + 0x1a0) + 0x10);
  }
  return (float10)0.0;
}



/* FUNCTION 27382 ; VA 0x00c15600 ; FUN_00c15600 */

int __fastcall FUN_00c15600(int param_1)

{
  int iVar1;
  uint3 uVar2;
  
  iVar1 = *(int *)(param_1 + 0x1a0);
  uVar2 = (uint3)((uint)iVar1 >> 8);
  if (iVar1 != 0) {
    return CONCAT31(uVar2,*(undefined *)(iVar1 + 3));
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 27383 ; VA 0x00c15620 ; FUN_00c15620 */

float10 __fastcall FUN_00c15620(int param_1)

{
  float10 fVar1;
  float10 fVar2;
  
  fVar1 = (float10)(**(code **)(**(int **)(param_1 + 0x1ac) + 100))();
  fVar2 = (float10)FUN_00f9dd40(param_1);
  return fVar2 * (float10)(float)fVar1;
}



/* FUNCTION 27384 ; VA 0x00c15650 ; FUN_00c15650 */

undefined4 __fastcall FUN_00c15650(int param_1)

{
  undefined *puVar1;
  
  puVar1 = (undefined *)(param_1 + 0x8e);
  if (param_1 == 0) {
    puVar1 = (undefined *)0x3e;
  }
  return CONCAT31((int3)((uint)puVar1 >> 8),*puVar1);
}



/* FUNCTION 27385 ; VA 0x00c15670 ; FUN_00c15670 */

void __thiscall FUN_00c15670(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x14);
  *param_2 = uVar1;
  param_2[1] = uVar1;
  param_2[2] = uVar1;
  return;
}



/* FUNCTION 27386 ; VA 0x00c15690 ; FUN_00c15690 */

void FUN_00c15690(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  return;
}



/* FUNCTION 27387 ; VA 0x00c156b0 ; FUN_00c156b0 */

void __fastcall FUN_00c156b0(undefined4 param_1)

{
  FUN_00ff4d00(param_1);
  return;
}



/* FUNCTION 27388 ; VA 0x00c156c0 ; FUN_00c156c0 */

void __fastcall FUN_00c156c0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c156c8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x1ac) + 0xc))();
  return;
}



/* FUNCTION 27389 ; VA 0x00c156d0 ; FUN_00c156d0 */

undefined4 __thiscall FUN_00c156d0(int param_1,int param_2)

{
  return *(undefined4 *)(*(int *)(param_1 + 0x1d0) + param_2 * 8);
}



/* FUNCTION 27390 ; VA 0x00c156f0 ; FUN_00c156f0 */

void __fastcall FUN_00c156f0(undefined4 param_1)

{
  FUN_00c1a000(param_1);
  return;
}



/* FUNCTION 27391 ; VA 0x00c15700 ; FUN_00c15700 */

undefined4 __fastcall FUN_00c15700(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_00ca1730(param_1);
  if (iVar1 != 0) {
    uVar2 = FUN_00c1a030(param_1);
    return uVar2;
  }
  return 0;
}



/* FUNCTION 27392 ; VA 0x00c15720 ; FUN_00c15720 */

undefined4 __thiscall FUN_00c15720(int param_1,int param_2)

{
  return *(undefined4 *)(*(int *)(param_1 + 0x1c0) + param_2 * 8);
}



/* FUNCTION 27393 ; VA 0x00c15740 ; FUN_00c15740 */

undefined4 FUN_00c15740(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = param_2;
  if ((int)(*(int *)(param_1 + 0x1c4) - *(int *)(param_1 + 0x1c0) & 0xfffffff8U) <
      (int)(*(int *)(param_2 + 0x1c4) - *(int *)(param_2 + 0x1c0) & 0xfffffff8U)) {
    iVar4 = param_1;
  }
  if (iVar4 == param_1) {
    param_1 = param_2;
  }
  iVar2 = 0;
  iVar1 = *(int *)(iVar4 + 0x1c0);
  iVar4 = *(int *)(iVar4 + 0x1c4) - iVar1 >> 3;
  if (0 < iVar4) {
    piVar3 = (int *)(iVar1 + 4);
    do {
      if (*piVar3 == param_1) {
        return *(undefined4 *)(iVar1 + iVar2 * 8);
      }
      iVar2 = iVar2 + 1;
      piVar3 = piVar3 + 2;
    } while (iVar2 < iVar4);
  }
  return 0;
}



/* FUNCTION 27394 ; VA 0x00c157b0 ; FUN_00c157b0 */

int __fastcall FUN_00c157b0(int param_1)

{
  FUN_00fa07b0();
  return (-(uint)(param_1 != 0) & param_1 + 0x50U) + 0xb4;
}



/* FUNCTION 27395 ; VA 0x00c157d0 ; FUN_00c157d0 */

undefined4 __fastcall FUN_00c157d0(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  
  piVar1 = (int *)(param_1 + 0x7c);
  if (param_1 == 0) {
    piVar1 = (int *)0x2c;
  }
  if (*piVar1 == 0) {
    uVar2 = FUN_00f9f8c0();
    return uVar2;
  }
  return *(undefined4 *)(*piVar1 + 0x14);
}



/* FUNCTION 27396 ; VA 0x00c15800 ; FUN_00c15800 */

undefined4 * __thiscall FUN_00c15800(int param_1,undefined4 *param_2,undefined4 param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  float *pfVar9;
  undefined4 *puVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  
  pfVar9 = (float *)FUN_00d6a680(param_3);
  iVar4 = *(int *)(param_1 + 0x1ac);
  fVar11 = *pfVar9 * DAT_018ce2f4;
  fVar1 = *(float *)(iVar4 + 4);
  fVar12 = pfVar9[1] * DAT_018ce2f4;
  fVar2 = *(float *)(iVar4 + 8);
  fVar13 = pfVar9[2] * DAT_018ce2f4;
  fVar3 = *(float *)(iVar4 + 0xc);
  puVar10 = (undefined4 *)FUN_00d6a420(param_3);
  uVar5 = puVar10[1];
  uVar6 = puVar10[2];
  uVar7 = puVar10[3];
  *param_2 = *puVar10;
  param_2[1] = uVar5;
  param_2[2] = uVar6;
  param_2[3] = uVar7;
  uVar6 = puVar10[5];
  uVar7 = puVar10[6];
  uVar8 = puVar10[7];
  uVar5 = puVar10[8];
  param_2[4] = puVar10[4];
  param_2[5] = uVar6;
  param_2[6] = uVar7;
  param_2[7] = uVar8;
  param_2[8] = uVar5;
  *(ulonglong *)(param_2 + 9) = CONCAT44(fVar12 * fVar2,fVar11 * fVar1);
  param_2[0xb] = fVar13 * fVar3;
  return param_2;
}



/* FUNCTION 27397 ; VA 0x00c158a0 ; FUN_00c158a0 */

undefined4 FUN_00c158a0(undefined4 param_1)

{
  return param_1;
}



/* FUNCTION 27398 ; VA 0x00c158b0 ; FUN_00c158b0 */

undefined4 __thiscall FUN_00c158b0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  float fVar2;
  float fVar3;
  undefined auStack_64 [48];
  undefined8 uStack_34;
  uint uStack_2c;
  undefined8 uStack_28;
  float fStack_20;
  float fStack_14;
  uint uStack_8;
  
  iVar1 = *(int *)(param_1 + 0x1ac);
  fStack_20 = *(float *)(iVar1 + 0xc) * DAT_018ce2f4;
  fVar3 = *(float *)(iVar1 + 4) * DAT_018ce2f4;
  fVar2 = *(float *)(iVar1 + 8) * DAT_018ce2f4;
  uStack_2c = (uint)fStack_20 ^ DAT_018c4ea0;
  uStack_34 = CONCAT44((uint)fVar2 ^ DAT_018c4ea0,(uint)fVar3 ^ DAT_018c4ea0);
  uStack_28 = CONCAT44(fVar2,fVar3);
  fStack_14 = fStack_20;
  uStack_8 = uStack_2c;
  FUN_010775d0(auStack_64,&uStack_34,param_3);
  FUN_00fa07b0();
  FUN_01078580(param_2,param_1 + 0x104);
  return param_2;
}



/* FUNCTION 27399 ; VA 0x00c15960 ; FUN_00c15960 */

int __fastcall FUN_00c15960(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_1c [24];
  
  iVar5 = param_1 + 0x50;
  if (DAT_01d69148 == '\0') {
    if (param_1 == 0) {
      iVar5 = 0;
    }
  }
  else if (*(char *)(param_1 + 0x19c) != '\0') {
    FUN_00fa0810();
    goto LAB_00c15997;
  }
  FUN_00fa07b0();
LAB_00c15997:
  iVar5 = *(int *)(iVar5 + 0xb0);
  if (*(int *)(param_1 + 0x208) != iVar5) {
    puVar4 = (undefined4 *)FUN_00c144c0(auStack_1c);
    uVar1 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    *(undefined4 *)(param_1 + 0x1f0) = *puVar4;
    *(undefined4 *)(param_1 + 500) = uVar1;
    *(undefined4 *)(param_1 + 0x1f8) = uVar2;
    *(undefined4 *)(param_1 + 0x1fc) = uVar3;
    *(undefined8 *)(param_1 + 0x200) = *(undefined8 *)(puVar4 + 4);
    *(int *)(param_1 + 0x208) = iVar5;
  }
  return param_1 + 0x1f0;
}



/* FUNCTION 27400 ; VA 0x00c159e0 ; FUN_00c159e0 */

undefined4 __fastcall FUN_00c159e0(int param_1)

{
  if (*(int *)(param_1 + 0x1c4) - (int)*(undefined4 **)(param_1 + 0x1c0) >> 3 != 0) {
    return **(undefined4 **)(param_1 + 0x1c0);
  }
  return 0;
}



/* FUNCTION 27401 ; VA 0x00c15a00 ; FUN_00c15a00 */

undefined4 __fastcall FUN_00c15a00(int param_1)

{
  if ((DAT_01d69070 != '\0') && (*(int *)(param_1 + 0x1a8) != 0)) {
    FUN_00ce1fd0();
    FUN_00ce1fe0();
  }
  if (*(int *)(param_1 + 0x1c4) - (int)*(undefined4 **)(param_1 + 0x1c0) >> 3 != 0) {
    return **(undefined4 **)(param_1 + 0x1c0);
  }
  return 0;
}



/* FUNCTION 27402 ; VA 0x00c15a50 ; FUN_00c15a50 */

undefined4 __fastcall FUN_00c15a50(int param_1)

{
  if (*(int *)(param_1 + 0x1d4) - (int)*(undefined4 **)(param_1 + 0x1d0) >> 3 != 0) {
    return **(undefined4 **)(param_1 + 0x1d0);
  }
  return 0;
}



/* FUNCTION 27403 ; VA 0x00c15a70 ; FUN_00c15a70 */

void __fastcall FUN_00c15a70(int param_1)

{
  if (*(int *)(param_1 + 0x1d4) - (int)*(undefined4 **)(param_1 + 0x1d0) >> 3 != 0) {
    FUN_00c15aa0(**(undefined4 **)(param_1 + 0x1d0));
    return;
  }
  FUN_00c15aa0(0);
  return;
}



/* FUNCTION 27404 ; VA 0x00c15aa0 ; FUN_00c15aa0 */

int * __thiscall FUN_00c15aa0(int param_1,int *param_2)

{
  int iVar1;
  
  if (param_2 != (int *)0x0) {
    do {
      iVar1 = (**(code **)(*param_2 + 0x10))();
      if (iVar1 - 1U < 4) {
        return param_2;
      }
      if (param_1 == param_2[0xb]) {
        iVar1 = param_2[0xd];
      }
      else {
        iVar1 = param_2[0xe];
      }
      if (iVar1 + 1U < (uint)(*(int *)(param_1 + 0x1d4) - *(int *)(param_1 + 0x1d0) >> 3)) {
        param_2 = *(int **)(*(int *)(param_1 + 0x1d0) + (iVar1 + 1U) * 8);
      }
      else {
        param_2 = (int *)0x0;
      }
    } while (param_2 != (int *)0x0);
  }
  return (int *)0x0;
}



/* FUNCTION 27405 ; VA 0x00c15b00 ; FUN_00c15b00 */

int __fastcall FUN_00c15b00(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x1b0) != 0) {
    return *(int *)(param_1 + 0x1b0) + 8;
  }
  if (*(int *)(param_1 + 0x1cc) - (int)*(undefined4 **)(param_1 + 0x1c8) >> 3 != 0) {
    iVar1 = FUN_00c16e80(**(undefined4 **)(param_1 + 0x1c8));
    return iVar1;
  }
  iVar1 = FUN_00c16e80(0);
  return iVar1;
}



/* FUNCTION 27406 ; VA 0x00c15b40 ; FUN_00c15b40 */

undefined4 __fastcall FUN_00c15b40(int param_1)

{
  undefined4 uVar1;
  
  if (*(int **)(param_1 + 0x1ac) != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00c15b4c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(int **)(param_1 + 0x1ac) + 8))();
    return uVar1;
  }
  return 0;
}



/* FUNCTION 27407 ; VA 0x00c15b60 ; FUN_00c15b60 */

int __fastcall FUN_00c15b60(int param_1)

{
  return param_1 + 0x1e0;
}



/* FUNCTION 27408 ; VA 0x00c15b70 ; FUN_00c15b70 */

undefined __fastcall FUN_00c15b70(int param_1)

{
  undefined uVar1;
  
  if ((DAT_01d69070 == '\0') && (DAT_01d66be0 == '\0')) {
                    /* WARNING: Could not recover jumptable at 0x00c15b8d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(int **)(param_1 + 0x1b0) + 4))();
    return uVar1;
  }
  return *(undefined *)(param_1 + 0x224);
}



/* FUNCTION 27409 ; VA 0x00c15ba0 ; FUN_00c15ba0 */

float10 __fastcall FUN_00c15ba0(int param_1)

{
  float10 fVar1;
  
  if (*(int *)(param_1 + 0x1a0) != 0) {
    fVar1 = (float10)FUN_00f41770();
    return fVar1;
  }
  return (float10)1;
}



/* FUNCTION 27410 ; VA 0x00c15bc0 ; FUN_00c15bc0 */

undefined4 __fastcall FUN_00c15bc0(int param_1)

{
  undefined *puVar1;
  
  puVar1 = (undefined *)(param_1 + 0x8c);
  if (param_1 == 0) {
    puVar1 = (undefined *)0x3c;
  }
  return CONCAT31((int3)((uint)puVar1 >> 8),*puVar1);
}



/* FUNCTION 27411 ; VA 0x00c15be0 ; FUN_00c15be0 */

undefined4 FUN_00c15be0(int param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = param_2;
  if ((int)(*(int *)(param_1 + 0x1d4) - *(int *)(param_1 + 0x1d0) & 0xfffffff8U) <
      (int)(*(int *)(param_2 + 0x1d4) - *(int *)(param_2 + 0x1d0) & 0xfffffff8U)) {
    iVar4 = param_1;
  }
  if (iVar4 == param_1) {
    param_1 = param_2;
  }
  iVar5 = 0;
  iVar1 = *(int *)(iVar4 + 0x1d0);
  iVar2 = 0;
  iVar4 = *(int *)(iVar4 + 0x1d4) - iVar1 >> 3;
  if (0 < iVar4) {
    piVar3 = (int *)(iVar1 + 4);
    do {
      if (*piVar3 == param_1) {
        if (iVar5 == param_3) {
          return *(undefined4 *)(iVar1 + iVar2 * 8);
        }
        iVar5 = iVar5 + 1;
      }
      iVar2 = iVar2 + 1;
      piVar3 = piVar3 + 2;
    } while (iVar2 < iVar4);
  }
  return 0;
}



/* FUNCTION 27412 ; VA 0x00c15c60 ; FUN_00c15c60 */

float10 __fastcall FUN_00c15c60(int param_1)

{
  int iVar1;
  float *pfVar2;
  float10 fVar3;
  float fVar4;
  float fVar5;
  undefined8 uStack_2c;
  float fStack_24;
  undefined8 uStack_20;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  
  if (*(char *)(param_1 + 0x229) == '\0') {
    return (float10)*(float *)(param_1 + 0x210);
  }
  iVar1 = (**(code **)(**(int **)(param_1 + 0x1ac) + 8))();
  if (iVar1 == 10) {
    fStack_14 = 4.0;
    pfVar2 = &fStack_14;
    fStack_10 = 4.0;
    fStack_c = 4.0;
  }
  else {
    fStack_18 = (float)*(undefined4 *)(*(int *)(param_1 + 0x1ac) + 0xc);
    pfVar2 = (float *)&uStack_20;
    uStack_20 = *(undefined8 *)(*(int *)(param_1 + 0x1ac) + 4);
  }
  uStack_2c = *(undefined8 *)pfVar2;
  fStack_24 = pfVar2[2];
  if (DAT_01d67c90 != '\0') {
    FUN_00c95580(&fStack_14,&uStack_2c);
    fStack_18 = fStack_c;
    if (fStack_c <= DAT_018ce2f8) {
      fStack_18 = DAT_018ce2f8;
    }
    fVar4 = fStack_10;
    if (fStack_10 <= DAT_018ce2f8) {
      fVar4 = DAT_018ce2f8;
    }
    fVar5 = fStack_14;
    if (fStack_14 <= DAT_018ce2f8) {
      fVar5 = DAT_018ce2f8;
    }
    uStack_20 = CONCAT44(fVar4,fVar5);
    if (*(int **)(param_1 + 0x1ac) == (int *)0x0) {
      iVar1 = 0;
    }
    else {
      iVar1 = (**(code **)(**(int **)(param_1 + 0x1ac) + 8))();
    }
    fVar3 = (float10)FUN_00c14820(&uStack_20,iVar1 == 1);
    if (fStack_14 < DAT_018ce2f8) {
      *(undefined *)(param_1 + 0x229) = 0;
      fVar4 = fStack_14 * (float)fVar3 * DAT_0193775c;
      *(float *)(param_1 + 0x210) = fVar4;
      return (float10)fVar4;
    }
    fVar4 = (float)fVar3 * DAT_0193775c;
    *(undefined *)(param_1 + 0x229) = 0;
    *(float *)(param_1 + 0x210) = fVar4;
    return (float10)fVar4;
  }
  if (*(int **)(param_1 + 0x1ac) == (int *)0x0) {
    iVar1 = 0;
  }
  else {
    iVar1 = (**(code **)(**(int **)(param_1 + 0x1ac) + 8))();
  }
  fVar3 = (float10)FUN_00bb5b40(&uStack_2c,iVar1 == 1);
  *(float *)(param_1 + 0x210) = (float)fVar3;
  *(undefined *)(param_1 + 0x229) = 0;
  return (float10)(float)fVar3;
}



/* FUNCTION 27413 ; VA 0x00c15e20 ; FUN_00c15e20 */

undefined4 FUN_00c15e20(undefined4 param_1)

{
  FUN_0151da60(param_1);
  return param_1;
}



/* FUNCTION 27414 ; VA 0x00c15e40 ; FUN_00c15e40 */

float10 __fastcall FUN_00c15e40(int param_1)

{
  float10 fVar1;
  
  if (*(int *)(param_1 + 0x1a0) != 0) {
    fVar1 = (float10)FUN_00f41380(param_1);
    return (float10)(float)fVar1;
  }
  return (float10)0.0;
}



/* FUNCTION 27415 ; VA 0x00c15e70 ; FUN_00c15e70 */

undefined4 FUN_00c15e70(undefined4 param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_20;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806108;
  pvStack_10 = ExceptionList;
  auStack_30[0] = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_20 = 0;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c15f40(param_1,auStack_30);
  piVar2 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    iVar1 = *piStack_18;
    if (iVar1 != 0) {
      uVar4 = piStack_18[2] - iVar1 & 0xfffffffc;
      iVar3 = iVar1;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar1 + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
      *piVar2 = 0;
      piVar2[1] = 0;
      piVar2[2] = 0;
    }
    FUN_01674ea0(piVar2,0x18);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27416 ; VA 0x00c15f40 ; FUN_00c15f40 */

undefined4 * __thiscall FUN_00c15f40(int param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined auStack_50 [75];
  char cStack_5;
  
  iVar3 = *(int *)(param_1 + 0x1a0);
  if ((iVar3 == 0) || (*(char *)(iVar3 + 2) == '\0')) {
    FUN_00fa07b0();
    uVar6 = *(undefined4 *)(param_1 + 0x108);
    uVar1 = *(undefined4 *)(param_1 + 0x10c);
    uVar2 = *(undefined4 *)(param_1 + 0x110);
    *param_2 = *(undefined4 *)(param_1 + 0x104);
    param_2[1] = uVar6;
    param_2[2] = uVar1;
    param_2[3] = uVar2;
    uVar6 = *(undefined4 *)(param_1 + 0x118);
    uVar1 = *(undefined4 *)(param_1 + 0x11c);
    uVar2 = *(undefined4 *)(param_1 + 0x120);
    param_2[4] = *(undefined4 *)(param_1 + 0x114);
    param_2[5] = uVar6;
    param_2[6] = uVar1;
    param_2[7] = uVar2;
    uVar6 = *(undefined4 *)(param_1 + 0x128);
    uVar1 = *(undefined4 *)(param_1 + 300);
    uVar2 = *(undefined4 *)(param_1 + 0x130);
    param_2[8] = *(undefined4 *)(param_1 + 0x124);
    param_2[9] = uVar6;
    param_2[10] = uVar1;
    param_2[0xb] = uVar2;
    *(undefined8 *)(param_2 + 0xc) = *(undefined8 *)(param_1 + 0x134);
    param_2[0xe] = *(undefined4 *)(param_1 + 0x13c);
    *(undefined8 *)(param_2 + 0xf) = *(undefined8 *)(param_1 + 0x140);
    param_2[0x11] = *(undefined4 *)(param_1 + 0x148);
    return param_2;
  }
  if (*(int *)(iVar3 + 100) == -1) {
    iVar3 = 0;
  }
  else {
    iVar3 = FUN_00bbdd60((int *)(iVar3 + 100));
  }
  cStack_5 = FUN_00f3d020(param_1);
  if (DAT_01d6f4d0 != '\0') {
    if (iVar3 == 0) goto LAB_00c1602e;
    iVar4 = FUN_00ca1730(iVar3);
    if (iVar4 == 0) {
      iVar4 = 0;
    }
    else {
      iVar4 = FUN_00c1a030(iVar3);
    }
    iVar5 = FUN_00ca1730(param_1);
    if (iVar5 == 0) {
      iVar5 = 0;
    }
    else {
      iVar5 = FUN_00c1a030(param_1);
    }
    if (iVar4 == iVar5) {
      uVar6 = FUN_00c157b0();
      FUN_009a3370(uVar6);
      return param_2;
    }
  }
  if ((iVar3 != 0) && (cStack_5 != '\0')) {
    iVar3 = *(int *)(param_1 + 0x1a0);
    uVar6 = FUN_00c15f40(auStack_50,param_3);
    FUN_00c14f90(param_2,uVar6,iVar3 + 0x6c);
    return param_2;
  }
LAB_00c1602e:
  iVar3 = *(int *)(param_1 + 0x1a0);
  uVar6 = *(undefined4 *)(iVar3 + 0x70);
  uVar1 = *(undefined4 *)(iVar3 + 0x74);
  uVar2 = *(undefined4 *)(iVar3 + 0x78);
  *param_2 = *(undefined4 *)(iVar3 + 0x6c);
  param_2[1] = uVar6;
  param_2[2] = uVar1;
  param_2[3] = uVar2;
  uVar6 = *(undefined4 *)(iVar3 + 0x80);
  uVar1 = *(undefined4 *)(iVar3 + 0x84);
  uVar2 = *(undefined4 *)(iVar3 + 0x88);
  param_2[4] = *(undefined4 *)(iVar3 + 0x7c);
  param_2[5] = uVar6;
  param_2[6] = uVar1;
  param_2[7] = uVar2;
  uVar6 = *(undefined4 *)(iVar3 + 0x90);
  uVar1 = *(undefined4 *)(iVar3 + 0x94);
  uVar2 = *(undefined4 *)(iVar3 + 0x98);
  param_2[8] = *(undefined4 *)(iVar3 + 0x8c);
  param_2[9] = uVar6;
  param_2[10] = uVar1;
  param_2[0xb] = uVar2;
  *(undefined8 *)(param_2 + 0xc) = *(undefined8 *)(iVar3 + 0x9c);
  param_2[0xe] = *(undefined4 *)(iVar3 + 0xa4);
  *(undefined8 *)(param_2 + 0xf) = *(undefined8 *)(iVar3 + 0xa8);
  param_2[0x11] = *(undefined4 *)(iVar3 + 0xb0);
  return param_2;
}



/* FUNCTION 27417 ; VA 0x00c160f0 ; FUN_00c160f0 */

undefined4 __fastcall FUN_00c160f0(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_00c1a000(param_1);
  if (iVar1 != 0) {
    uVar2 = FUN_00c1a090();
    return uVar2;
  }
  return 0;
}



/* FUNCTION 27418 ; VA 0x00c16110 ; FUN_00c16110 */

undefined4 FUN_00c16110(undefined4 param_1,undefined4 param_2)

{
  FUN_0107cac0(param_1,param_2);
  return param_1;
}



/* FUNCTION 27419 ; VA 0x00c16130 ; FUN_00c16130 */

undefined4 FUN_00c16130(undefined4 param_1,undefined4 param_2)

{
  FUN_0107ba50(param_1,param_2);
  return param_1;
}



/* FUNCTION 27420 ; VA 0x00c16150 ; FUN_00c16150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c16150(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar4 = DAT_01f30778;
  uVar3 = uRam01f30764;
  uVar2 = uRam01f30760;
  uVar1 = uRam01f3075c;
  *param_1 = _DAT_01f30758;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar3 = uRam01f30774;
  uVar2 = uRam01f30770;
  uVar1 = uRam01f3076c;
  param_1[4] = _DAT_01f30768;
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  param_1[8] = uVar4;
  return;
}



/* FUNCTION 27421 ; VA 0x00c16180 ; FUN_00c16180 */

undefined __fastcall FUN_00c16180(int param_1)

{
  char cVar1;
  
  if (*(char *)(param_1 + 0x228) == '\0') {
    return 0;
  }
  if ((*(int *)(param_1 + 0x1a0) != 0) && (cVar1 = FUN_00f41800(), cVar1 != '\0')) {
    return 0;
  }
  return 1;
}



/* FUNCTION 27422 ; VA 0x00c161b0 ; FUN_00c161b0 */

undefined4 __thiscall FUN_00c161b0(int param_1,int param_2)

{
  int iVar1;
  
  if (param_1 == *(int *)(param_2 + 4)) {
    iVar1 = *(int *)(param_2 + 0x10);
  }
  else {
    iVar1 = *(int *)(param_2 + 0x14);
  }
  if (iVar1 + 1U < (uint)(*(int *)(param_1 + 0x1c4) - *(int *)(param_1 + 0x1c0) >> 3)) {
    return *(undefined4 *)(*(int *)(param_1 + 0x1c0) + (iVar1 + 1U) * 8);
  }
  return 0;
}



/* FUNCTION 27423 ; VA 0x00c161f0 ; FUN_00c161f0 */

undefined4 __fastcall FUN_00c161f0(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  
  iVar4 = param_1[3];
  iVar2 = param_1[2];
  if (iVar4 < iVar2) {
    piVar5 = (int *)(*(int *)(*param_1 + 0x1d0) + iVar4 * 8 + 4);
    do {
      iVar1 = iVar4 + 1;
      if (*piVar5 == param_1[1]) {
        uVar3 = *(undefined4 *)(*(int *)(*param_1 + 0x1d0) + iVar4 * 8);
        param_1[3] = iVar1;
        return uVar3;
      }
      piVar5 = piVar5 + 2;
      iVar4 = iVar1;
    } while (iVar1 < iVar2);
  }
  param_1[3] = iVar2;
  return 0;
}



/* FUNCTION 27424 ; VA 0x00c16250 ; FUN_00c16250 */

undefined4 __thiscall FUN_00c16250(int param_1,int param_2)

{
  int iVar1;
  
  if (param_1 == *(int *)(param_2 + 0x2c)) {
    iVar1 = *(int *)(param_2 + 0x34);
  }
  else {
    iVar1 = *(int *)(param_2 + 0x38);
  }
  if (iVar1 + 1U < (uint)(*(int *)(param_1 + 0x1d4) - *(int *)(param_1 + 0x1d0) >> 3)) {
    return *(undefined4 *)(*(int *)(param_1 + 0x1d0) + (iVar1 + 1U) * 8);
  }
  return 0;
}



/* FUNCTION 27425 ; VA 0x00c16290 ; FUN_00c16290 */

void __thiscall FUN_00c16290(int param_1,int param_2)

{
  int iVar1;
  
  if (param_1 == *(int *)(param_2 + 0x2c)) {
    iVar1 = *(int *)(param_2 + 0x34);
  }
  else {
    iVar1 = *(int *)(param_2 + 0x38);
  }
  if (iVar1 + 1U < (uint)(*(int *)(param_1 + 0x1d4) - *(int *)(param_1 + 0x1d0) >> 3)) {
    FUN_00c15aa0();
    return;
  }
  FUN_00c15aa0();
  return;
}



/* FUNCTION 27426 ; VA 0x00c162e0 ; FUN_00c162e0 */

void __thiscall FUN_00c162e0(int param_1,uint param_2)

{
  int *piVar1;
  int *piVar2;
  
  if ((-(uint)(*(int *)(param_1 + 0x1b0) != 0) & *(int *)(param_1 + 0x1b0) + 8U) == param_2) {
    if (*(int *)(param_1 + 0x1cc) - *(int *)(param_1 + 0x1c8) >> 3 != 0) {
      FUN_00c16e80();
      return;
    }
    FUN_00c16e80();
    return;
  }
  piVar1 = (int *)(param_2 + 0x24);
  if (param_2 == 0) {
    piVar1 = (int *)0x2c;
  }
  if (param_1 + -8 == *piVar1) {
    piVar1 = (int *)(param_2 + 0x2c);
    piVar2 = (int *)&DAT_00000034;
  }
  else {
    piVar1 = (int *)(param_2 + 0x30);
    piVar2 = (int *)0x38;
  }
  if (param_2 == 0) {
    piVar1 = piVar2;
  }
  if (*piVar1 + 1U < (uint)(*(int *)(param_1 + 0x1cc) - *(int *)(param_1 + 0x1c8) >> 3)) {
    FUN_00c16e80();
    return;
  }
  FUN_00c16e80();
  return;
}



/* FUNCTION 27427 ; VA 0x00c16390 ; FUN_00c16390 */

int __fastcall FUN_00c16390(int param_1)

{
  return *(int *)(param_1 + 0x1c4) - *(int *)(param_1 + 0x1c0) >> 3;
}



/* FUNCTION 27428 ; VA 0x00c163a0 ; FUN_00c163a0 */

int __fastcall FUN_00c163a0(int param_1)

{
  if ((DAT_01d69070 != '\0') && (*(int *)(param_1 + 0x1a8) != 0)) {
    FUN_00ce1fd0();
    FUN_00ce1fe0();
  }
  return *(int *)(param_1 + 0x1c4) - *(int *)(param_1 + 0x1c0) >> 3;
}



/* FUNCTION 27429 ; VA 0x00c163f0 ; FUN_00c163f0 */

int __fastcall FUN_00c163f0(int param_1)

{
  return *(int *)(*(int *)(param_1 + 0x18) + 0x1c) - *(int *)(*(int *)(param_1 + 0x18) + 0x18) >> 5;
}



/* FUNCTION 27430 ; VA 0x00c16400 ; FUN_00c16400 */

void __thiscall FUN_00c16400(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0xc);
  *param_2 = *(undefined8 *)(param_1 + 4);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 27431 ; VA 0x00c16420 ; FUN_00c16420 */

int __fastcall FUN_00c16420(int param_1)

{
  undefined *puVar1;
  uint3 uVar2;
  
  puVar1 = *(undefined **)(param_1 + 0x1a0);
  uVar2 = (uint3)((uint)puVar1 >> 8);
  if (puVar1 != (undefined *)0x0) {
    return CONCAT31(uVar2,*puVar1);
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 27432 ; VA 0x00c16430 ; FUN_00c16430 */

undefined4 __thiscall FUN_00c16430(int param_1,int param_2)

{
  if (param_2 == 0) {
    return *(undefined4 *)(param_1 + 4);
  }
  return *(undefined4 *)(param_1 + 8);
}



/* FUNCTION 27433 ; VA 0x00c16450 ; FUN_00c16450 */

void __fastcall FUN_00c16450(int param_1)

{
  undefined4 *puVar1;
  
  if (*(int *)(param_1 + 0x1a4) == 0) {
    puVar1 = (undefined4 *)FUN_01674e20(0x10);
    if (puVar1 != (undefined4 *)0x0) {
      puVar1[3] = param_1;
      puVar1[1] = 0;
      puVar1[2] = 0;
      *puVar1 = RBX::PrimitiveMidPhaseBinding::vftable;
      *(undefined4 **)(param_1 + 0x1a4) = puVar1;
      return;
    }
    *(undefined4 *)(param_1 + 0x1a4) = 0;
  }
  return;
}



/* FUNCTION 27434 ; VA 0x00c164b0 ; FUN_00c164b0 */

void __thiscall FUN_00c164b0(int param_1,int *param_2)

{
  FUN_00fa0810();
  *param_2 = param_1 + 0xfc;
  param_2[1] = param_1 + 0xb4;
  return;
}



/* FUNCTION 27435 ; VA 0x00c164e0 ; FUN_00c164e0 */

void __fastcall FUN_00c164e0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c164eb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x1ac) + 0x18))();
  return;
}



/* FUNCTION 27436 ; VA 0x00c164f0 ; FUN_00c164f0 */

void __fastcall FUN_00c164f0(int param_1)

{
  float fVar1;
  int iVar2;
  float10 fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  if (*(int *)(param_1 + 0x1e8) == 0) {
    iVar2 = *(int *)(param_1 + 0x1ac);
    fVar5 = *(float *)(iVar2 + 4);
    fVar1 = *(float *)(iVar2 + 8);
    fVar6 = *(float *)(iVar2 + 0xc);
    if (fVar1 <= fVar5) {
      fVar4 = fVar5;
      if (fVar6 <= fVar1) {
        fVar6 = fVar1;
      }
    }
    else {
      fVar4 = fVar1;
      if (fVar6 <= fVar5) {
        fVar6 = fVar5;
      }
    }
    fVar3 = (float10)FUN_01725280((double)(fVar4 * fVar6 * DAT_01901d9c));
    fVar5 = (float)fVar3;
    if (fVar5 < DAT_018ce2f0) {
      fVar5 = fVar5 - DAT_018ce2f4;
    }
    else {
      fVar5 = fVar5 + DAT_018ce2f4;
    }
    iVar2 = (int)fVar5;
    switch(*(undefined *)(param_1 + 0x22e)) {
    default:
      *(int *)(param_1 + 0x1e8) = iVar2 + 1;
      break;
    case 1:
      *(int *)(param_1 + 0x1e8) = iVar2 * 5 + 1;
      return;
    case 2:
      *(int *)(param_1 + 0x1e8) = iVar2 * 10 + 1;
      return;
    case 3:
      *(int *)(param_1 + 0x1e8) = iVar2 * 0x14 + 1;
      return;
    }
  }
  return;
}



/* FUNCTION 27437 ; VA 0x00c16600 ; FUN_00c16600 */

float10 __fastcall FUN_00c16600(int param_1)

{
  return (float10)*(float *)(param_1 + 8) * (float10)*(float *)(param_1 + 4) *
         (float10)*(float *)(param_1 + 0xc);
}



/* FUNCTION 27438 ; VA 0x00c16610 ; FUN_00c16610 */

uint __thiscall FUN_00c16610(int param_1,undefined4 param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  uint uVar7;
  uint uVar8;
  float fVar9;
  undefined auStack_1c [24];
  
  uVar8 = -(uint)(param_1 != 0) & param_1 + 0x50U;
  FUN_00fa07b0();
  FUN_01164300(auStack_1c,param_2);
  uVar7 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x68))(auStack_1c,param_3);
  if ((char)uVar7 != '\0') {
    fVar1 = *param_3;
    fVar2 = param_3[1];
    fVar3 = param_3[2];
    fVar9 = *(float *)(uVar8 + 0xd0);
    fVar4 = *(float *)(uVar8 + 0xcc);
    fVar5 = *(float *)(uVar8 + 0xd4);
    fVar6 = *(float *)(uVar8 + 0xe0);
    *(ulonglong *)param_3 =
         CONCAT44(*(float *)(uVar8 + 0xc0) * fVar1 + *(float *)(uVar8 + 0xc4) * fVar2 +
                  *(float *)(uVar8 + 200) * fVar3 + *(float *)(uVar8 + 0xdc),
                  *(float *)(uVar8 + 0xb8) * fVar2 + fVar1 * *(float *)(uVar8 + 0xb4) +
                  *(float *)(uVar8 + 0xbc) * fVar3 + *(float *)(uVar8 + 0xd8));
    param_3[2] = fVar9 * fVar2 + fVar1 * fVar4 + fVar5 * fVar3 + fVar6;
    fVar1 = param_3[3];
    fVar2 = param_3[4];
    fVar3 = param_3[5];
    fVar9 = *(float *)(uVar8 + 0xd0) * fVar2 + fVar1 * *(float *)(uVar8 + 0xcc) +
            *(float *)(uVar8 + 0xd4) * fVar3;
    *(ulonglong *)(param_3 + 3) =
         CONCAT44(*(float *)(uVar8 + 0xc0) * fVar1 + *(float *)(uVar8 + 0xc4) * fVar2 +
                  *(float *)(uVar8 + 200) * fVar3,
                  *(float *)(uVar8 + 0xb8) * fVar2 + fVar1 * *(float *)(uVar8 + 0xb4) +
                  *(float *)(uVar8 + 0xbc) * fVar3);
    param_3[5] = fVar9;
    return CONCAT31((int3)((uint)fVar9 >> 8),1);
  }
  return uVar7 & 0xffffff00;
}



/* FUNCTION 27439 ; VA 0x00c16790 ; FUN_00c16790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00c16790(void)

{
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806137;
  pvStack_10 = ExceptionList;
  if (DAT_01ef8e24 == '\0') {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8f44) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef8f44);
      if (DAT_01ef8f44 == -1) {
        uStack_8 = 0;
        _DAT_01ef8f04 = FUN_01674e20(0x28,&DAT_01ef8f00);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_00c12ef0(&uStack_11,-(uint)(_DAT_01ef8f04 != 0) & _DAT_01ef8f04 + 0x20U,0);
        _DAT_01ef8f20 = 0x3f800000;
        _DAT_01ef8f24 = 0xffffffff;
        if ((float)((double)*(int *)(&DAT_018be080 + DAT_01ef8f10 * 4) +
                   (double)(&DAT_018c0d90)[-(*(int *)(&DAT_018be080 + DAT_01ef8f10 * 4) >> 0x1f)]) <
            DAT_018c0d80) {
          _DAT_01ef8f24 = FUN_016f3cd0();
        }
        _DAT_01ef8f28 = 0;
        InitializeCriticalSection(&DAT_01ef8f2c);
        FUN_016f3654(&LAB_01893520);
        FUN_016f37bf(&DAT_01ef8f44);
      }
    }
    DAT_01ee391c = &DAT_01ef8f00;
    DAT_01ef8e28 = &DAT_01ef8f2c;
    DAT_01ef8e24 = '\x01';
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 27440 ; VA 0x00c168d0 ; FUN_00c168d0 */

void FUN_00c168d0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iStack_c;
  int iStack_8;
  
  iVar4 = *(int *)(param_1 + 4);
  iVar1 = *(int *)(param_1 + 8);
  iVar3 = *(int *)(iVar4 + 0x1c4) - *(int *)(iVar4 + 0x1c0) >> 3;
  if (*(int *)(iVar4 + 0x1bc) == iVar4) {
    *(int *)(param_1 + 0x10) = iVar3;
  }
  else {
    *(int *)(param_1 + 0x14) = iVar3;
  }
  piVar2 = *(int **)(iVar4 + 0x1c4);
  iStack_8 = iVar4;
  if (*(int *)(iVar4 + 0x1bc) == iVar4) {
    iStack_8 = iVar1;
  }
  iStack_c = param_1;
  if (*(int **)(iVar4 + 0x1c8) == piVar2) {
    FUN_00805800(piVar2,&iStack_c);
  }
  else {
    *piVar2 = param_1;
    piVar2[1] = iStack_8;
    *(int *)(iVar4 + 0x1c4) = *(int *)(iVar4 + 0x1c4) + 8;
  }
  iStack_8 = *(int *)(param_1 + 4);
  iVar4 = *(int *)(iVar1 + 0x1c4) - *(int *)(iVar1 + 0x1c0) >> 3;
  if (*(int *)(iVar1 + 0x1bc) == iStack_8) {
    *(int *)(param_1 + 0x10) = iVar4;
  }
  else {
    *(int *)(param_1 + 0x14) = iVar4;
  }
  iStack_c = param_1;
  if (*(int *)(iVar1 + 0x1bc) == iStack_8) {
    iStack_8 = *(int *)(param_1 + 8);
  }
  piVar2 = *(int **)(iVar1 + 0x1c4);
  if (*(int **)(iVar1 + 0x1c8) != piVar2) {
    *piVar2 = param_1;
    piVar2[1] = iStack_8;
    *(int *)(iVar1 + 0x1c4) = *(int *)(iVar1 + 0x1c4) + 8;
    return;
  }
  FUN_00805800(piVar2,&iStack_c);
  return;
}



/* FUNCTION 27441 ; VA 0x00c16990 ; FUN_00c16990 */

void __thiscall FUN_00c16990(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iStack_c;
  int iStack_8;
  
  iStack_8 = *(int *)(param_2 + 0x2c);
  iVar2 = param_1[2] - param_1[1] >> 3;
  if (*param_1 == iStack_8) {
    *(int *)(param_2 + 0x34) = iVar2;
  }
  else {
    *(int *)(param_2 + 0x38) = iVar2;
  }
  iStack_c = param_2;
  if (*param_1 == iStack_8) {
    iStack_8 = *(int *)(param_2 + 0x30);
  }
  piVar1 = (int *)param_1[2];
  if ((int *)param_1[3] != piVar1) {
    *piVar1 = param_2;
    piVar1[1] = iStack_8;
    param_1[2] = param_1[2] + 8;
    return;
  }
  FUN_00805800(piVar1,&iStack_c);
  return;
}



/* FUNCTION 27442 ; VA 0x00c169f0 ; FUN_00c169f0 */

void FUN_00c169f0(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piStack_c;
  int iStack_8;
  
  iVar1 = param_1[0xb];
  iVar2 = param_1[0xc];
  iVar4 = (**(code **)(*param_1 + 0x10))();
  if ((iVar4 == 0x1a) || (iVar4 == 0)) {
    *(int **)(iVar1 + 0x1b8) = param_1;
  }
  else {
    iStack_8 = param_1[0xb];
    iVar4 = *(int *)(iVar1 + 0x1d4) - *(int *)(iVar1 + 0x1d0) >> 3;
    if (*(int *)(iVar1 + 0x1cc) == iStack_8) {
      param_1[0xd] = iVar4;
    }
    else {
      param_1[0xe] = iVar4;
    }
    piStack_c = param_1;
    if (*(int *)(iVar1 + 0x1cc) == iStack_8) {
      iStack_8 = param_1[0xc];
    }
    puVar3 = *(undefined4 **)(iVar1 + 0x1d4);
    if (*(undefined4 **)(iVar1 + 0x1d8) == puVar3) {
      FUN_00805800(puVar3,&piStack_c);
    }
    else {
      *puVar3 = param_1;
      puVar3[1] = iStack_8;
      *(int *)(iVar1 + 0x1d4) = *(int *)(iVar1 + 0x1d4) + 8;
    }
    if (iVar2 != 0) {
      FUN_00c16990(param_1);
      return;
    }
  }
  return;
}



/* FUNCTION 27443 ; VA 0x00c16a90 ; FUN_00c16a90 */

undefined4 FUN_00c16a90(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)FUN_01674e20(0x28);
  *param_2 = puVar4;
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *puVar4 = *param_1;
  puVar4[1] = uVar1;
  puVar4[2] = uVar2;
  puVar4[3] = uVar3;
  *(undefined8 *)(puVar4 + 4) = *(undefined8 *)(param_1 + 4);
  puVar4[6] = 0;
  puVar4[7] = 0;
  return *param_2;
}



/* FUNCTION 27444 ; VA 0x00c16ad0 ; FUN_00c16ad0 */

int * FUN_00c16ad0(int *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00c16790();
  uVar2 = DAT_01ef8e28;
  uStack_1c = 0;
  uStack_34 = *param_2;
  uStack_30 = param_2[1];
  uStack_2c = param_2[2];
  uStack_28 = param_2[3];
  uStack_18 = 0;
  uStack_14 = DAT_01ef8e28;
  uStack_24 = *(undefined8 *)(param_2 + 4);
  EnterCriticalSection(DAT_01ef8e28);
  iVar1 = DAT_01ee391c;
  param_2 = (undefined4 *)0x0;
  uStack_8 = 0;
  iVar3 = FUN_00c12730(&uStack_34,&param_2,0);
  if ((undefined4 *)iVar3 == param_2) {
    piVar4 = (int *)(iVar1 + 0x28);
    if (iVar1 == -0xc) {
      piVar4 = (int *)0x28;
    }
    *piVar4 = *piVar4 + 1;
  }
  *param_1 = iVar3;
  LOCK();
  piVar4 = (int *)(iVar3 + 0x18);
  iVar1 = *piVar4;
  *piVar4 = *piVar4 + 1;
  UNLOCK();
  if (iVar1 == 0) {
    *(int *)(*param_1 + 0x1c) = *(int *)(*param_1 + 0x1c) + 1;
  }
  LeaveCriticalSection(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27445 ; VA 0x00c16ba0 ; FUN_00c16ba0 */

int __thiscall FUN_00c16ba0(uint param_1,uint param_2)

{
  uint3 uVar1;
  
  do {
    param_2 = -(uint)(*(int *)(param_2 + 0xc) != 0) & *(int *)(param_2 + 0xc) - 8U;
    uVar1 = (uint3)(param_2 >> 8);
    if (param_2 == 0) {
      return (uint)uVar1 << 8;
    }
  } while (param_2 != param_1);
  return CONCAT31(uVar1,1);
}



/* FUNCTION 27446 ; VA 0x00c16bd0 ; FUN_00c16bd0 */

void __fastcall FUN_00c16bd0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c16bdb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x1ac) + 0x44))();
  return;
}



/* FUNCTION 27447 ; VA 0x00c16be0 ; FUN_00c16be0 */

undefined4 * __thiscall FUN_00c16be0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018061ab;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01ef8e30);
  uStack_8 = 0;
  switch(param_2) {
  case 1:
    puVar3 = (undefined4 *)FUN_01674e20(0x1c);
    if (puVar3 != (undefined4 *)0x0) {
      puVar3[4] = 0;
      puVar3[1] = 0;
      puVar3[2] = 0;
      puVar3[3] = 0;
      *puVar3 = RBX::Ball::vftable;
      puVar3[5] = 0;
      puVar3[6] = 0;
      goto LAB_00c16e30;
    }
    break;
  case 2:
    iVar2 = FUN_01674e20(0x20);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (iVar2 != 0) {
      puVar3 = (undefined4 *)FUN_0107e5a0();
      goto LAB_00c16e30;
    }
    break;
  case 3:
    iVar2 = FUN_01674e20(0x2c);
    if (iVar2 != 0) {
      puVar3 = (undefined4 *)FUN_00c13010();
      goto LAB_00c16e30;
    }
    break;
  case 4:
    puVar3 = (undefined4 *)FUN_01674e20(0x24);
    if (puVar3 != (undefined4 *)0x0) {
      *puVar3 = 0;
      puVar3[1] = 0;
      puVar3[2] = 0;
      puVar3[3] = 0;
      puVar3[4] = 0;
      puVar3[5] = 0;
      puVar3[6] = 0;
      puVar3[7] = 0;
      puVar3[8] = 0;
      puVar3[4] = 0;
      puVar3[1] = 0;
      puVar3[2] = 0;
      puVar3[3] = 0;
      puVar3[6] = 0;
      *puVar3 = RBX::WedgePoly::vftable;
      puVar3[7] = 0;
      puVar3[8] = 0;
      goto LAB_00c16e30;
    }
    break;
  default:
    puVar3 = (undefined4 *)FUN_01674e20(0x2c);
    if (puVar3 != (undefined4 *)0x0) {
      puVar3[4] = 0;
      puVar3[6] = 0;
      *puVar3 = RBX::Block::vftable;
      puVar3[7] = 0;
      puVar3[8] = 0;
      puVar3[9] = 0;
      puVar3[1] = 0;
      puVar3[2] = 0;
      puVar3[3] = 0;
      puVar3[10] = 0;
      goto LAB_00c16e30;
    }
    break;
  case 9:
    puVar3 = (undefined4 *)FUN_01674e20(0x24);
    if (puVar3 != (undefined4 *)0x0) {
      *puVar3 = 0;
      puVar3[1] = 0;
      puVar3[2] = 0;
      puVar3[3] = 0;
      puVar3[4] = 0;
      puVar3[5] = 0;
      puVar3[6] = 0;
      puVar3[7] = 0;
      puVar3[8] = 0;
      puVar3[4] = 0;
      puVar3[1] = 0;
      puVar3[2] = 0;
      puVar3[3] = 0;
      puVar3[6] = 0;
      *puVar3 = RBX::CornerWedgePoly::vftable;
      puVar3[7] = 0;
      puVar3[8] = 0;
      goto LAB_00c16e30;
    }
    break;
  case 10:
    iVar2 = FUN_01674e20(0x510);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (iVar2 != 0) {
      puVar3 = (undefined4 *)FUN_00fec1a0(param_1);
      goto LAB_00c16e30;
    }
    break;
  case 0xb:
    iVar2 = FUN_01674e20(0x80);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    if (iVar2 != 0) {
      puVar3 = (undefined4 *)FUN_00cc56e0();
      goto LAB_00c16e30;
    }
  }
  puVar3 = (undefined4 *)0x0;
LAB_00c16e30:
  uStack_8 = 0xb;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 27448 ; VA 0x00c16e80 ; FUN_00c16e80 */

int * __thiscall FUN_00c16e80(int param_1,int *param_2)

{
  int iVar1;
  
  if (param_2 != (int *)0x0) {
    do {
      iVar1 = (**(code **)(*param_2 + 0x10))();
      if ((0xd < iVar1 - 0xcU) || ((*(byte *)(param_2 + 0x2b) & 2) != 0)) {
        iVar1 = (**(code **)(*param_2 + 0x10))();
        if (iVar1 - 1U < 6) {
LAB_00c16f0c:
          return param_2 + 2;
        }
        iVar1 = (**(code **)(*param_2 + 0x10))();
        if (iVar1 - 7U < 0x13) goto LAB_00c16f0c;
        iVar1 = (**(code **)(*param_2 + 0x10))();
        if ((iVar1 == 0x1a) || (iVar1 == 0)) goto LAB_00c16f0c;
      }
      if (param_1 == param_2[0xb]) {
        iVar1 = param_2[0xd];
      }
      else {
        iVar1 = param_2[0xe];
      }
      if (iVar1 + 1U < (uint)(*(int *)(param_1 + 0x1d4) - *(int *)(param_1 + 0x1d0) >> 3)) {
        param_2 = *(int **)(*(int *)(param_1 + 0x1d0) + (iVar1 + 1U) * 8);
      }
      else {
        param_2 = (int *)0x0;
      }
    } while (param_2 != (int *)0x0);
  }
  return (int *)0x0;
}



/* FUNCTION 27449 ; VA 0x00c16f20 ; FUN_00c16f20 */

void __fastcall FUN_00c16f20(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c16f2c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x1b0) + 0x10))();
  return;
}



/* FUNCTION 27450 ; VA 0x00c16f30 ; FUN_00c16f30 */

void FUN_00c16f30(undefined4 param_1,undefined4 param_2)

{
  FUN_00c12980(param_1,param_2);
  FUN_00c12980(param_2,param_1);
  return;
}



/* FUNCTION 27451 ; VA 0x00c16f50 ; FUN_00c16f50 */

void FUN_00c16f50(undefined4 param_1,undefined4 param_2)

{
  FUN_00c128b0(param_1,param_2);
  FUN_00c128b0(param_2,param_1);
  return;
}



/* FUNCTION 27452 ; VA 0x00c16f70 ; FUN_00c16f70 */

void FUN_00c16f70(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  return;
}



/* FUNCTION 27453 ; VA 0x00c16f90 ; FUN_00c16f90 */

void FUN_00c16f90(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = *(int *)(param_1 + 4);
  iVar1 = *(int *)(param_1 + 8);
  if (*(int *)(iVar5 + 0x1bc) == iVar5) {
    iVar6 = *(int *)(param_1 + 0x10);
  }
  else {
    iVar6 = *(int *)(param_1 + 0x14);
  }
  iVar2 = *(int *)(*(int *)(iVar5 + 0x1c4) + -8);
  uVar3 = *(undefined4 *)(*(int *)(iVar5 + 0x1c4) + -4);
  iVar4 = *(int *)(iVar5 + 0x1c0);
  *(int *)(iVar4 + iVar6 * 8) = iVar2;
  *(undefined4 *)(iVar4 + 4 + iVar6 * 8) = uVar3;
  *(int *)(iVar5 + 0x1c4) = *(int *)(iVar5 + 0x1c4) + -8;
  if (*(int *)(iVar5 + 0x1bc) == *(int *)(iVar2 + 4)) {
    *(int *)(iVar2 + 0x10) = iVar6;
  }
  else {
    *(int *)(iVar2 + 0x14) = iVar6;
  }
  if (*(int *)(iVar5 + 0x1bc) == *(int *)(param_1 + 4)) {
    *(undefined4 *)(param_1 + 0x10) = 0xffffffff;
  }
  else {
    *(undefined4 *)(param_1 + 0x14) = 0xffffffff;
  }
  if (*(int *)(iVar1 + 0x1bc) == *(int *)(param_1 + 4)) {
    iVar5 = *(int *)(param_1 + 0x10);
  }
  else {
    iVar5 = *(int *)(param_1 + 0x14);
  }
  iVar6 = *(int *)(*(int *)(iVar1 + 0x1c4) + -8);
  uVar3 = *(undefined4 *)(*(int *)(iVar1 + 0x1c4) + -4);
  iVar2 = *(int *)(iVar1 + 0x1c0);
  *(int *)(iVar2 + iVar5 * 8) = iVar6;
  *(undefined4 *)(iVar2 + 4 + iVar5 * 8) = uVar3;
  *(int *)(iVar1 + 0x1c4) = *(int *)(iVar1 + 0x1c4) + -8;
  if (*(int *)(iVar1 + 0x1bc) == *(int *)(iVar6 + 4)) {
    *(int *)(iVar6 + 0x10) = iVar5;
  }
  else {
    *(int *)(iVar6 + 0x14) = iVar5;
  }
  if (*(int *)(iVar1 + 0x1bc) == *(int *)(param_1 + 4)) {
    *(undefined4 *)(param_1 + 0x10) = 0xffffffff;
    return;
  }
  *(undefined4 *)(param_1 + 0x14) = 0xffffffff;
  return;
}



/* FUNCTION 27454 ; VA 0x00c17070 ; FUN_00c17070 */

void __thiscall FUN_00c17070(int *param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  
  if (*param_1 == *(int *)(param_2 + 0x2c)) {
    iVar4 = *(int *)(param_2 + 0x34);
  }
  else {
    iVar4 = *(int *)(param_2 + 0x38);
  }
  iVar1 = *(int *)(param_1[2] + -8);
  uVar2 = *(undefined4 *)(param_1[2] + -4);
  iVar3 = param_1[1];
  *(int *)(iVar3 + iVar4 * 8) = iVar1;
  *(undefined4 *)(iVar3 + 4 + iVar4 * 8) = uVar2;
  param_1[2] = param_1[2] + -8;
  if (*param_1 == *(int *)(iVar1 + 0x2c)) {
    *(int *)(iVar1 + 0x34) = iVar4;
  }
  else {
    *(int *)(iVar1 + 0x38) = iVar4;
  }
  if (*param_1 == *(int *)(param_2 + 0x2c)) {
    *(undefined4 *)(param_2 + 0x34) = 0xffffffff;
    return;
  }
  *(undefined4 *)(param_2 + 0x38) = 0xffffffff;
  return;
}



/* FUNCTION 27455 ; VA 0x00c170d0 ; FUN_00c170d0 */

void FUN_00c170d0(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = param_1[0xb];
  iVar2 = param_1[0xc];
  iVar3 = (**(code **)(*param_1 + 0x10))();
  if ((iVar3 == 0x1a) || (iVar3 == 0)) {
    *(undefined4 *)(iVar1 + 0x1b8) = 0;
  }
  else {
    FUN_00c17070(param_1);
    if (iVar2 != 0) {
      FUN_00c17070(param_1);
      return;
    }
  }
  return;
}



/* FUNCTION 27456 ; VA 0x00c17120 ; FUN_00c17120 */

void __thiscall FUN_00c17120(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined8 uStack_10;
  int iStack_8;
  
  piVar1 = *(int **)(param_1 + 0x1ac);
  uStack_10 = *(undefined8 *)(piVar1 + 1);
  iStack_8 = piVar1[3];
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 4))(1);
  }
  uVar2 = FUN_00c16be0(param_2);
  *(undefined4 *)(param_1 + 0x1ac) = uVar2;
  if (*(int *)(param_1 + 0x1a8) != 0) {
    FUN_00bbf640(param_1);
  }
  FUN_00c18e20(&uStack_10);
  *(undefined *)(param_1 + 0x229) = 1;
  return;
}



/* FUNCTION 27457 ; VA 0x00c17190 ; FUN_00c17190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00c17190(int param_1)

{
  double dVar1;
  undefined auStack_14 [8];
  double dStack_c;
  
  if ((*(int *)(param_1 + 0x1a0) != 0) &&
     (dVar1 = *(double *)(*(int *)(param_1 + 0x1a0) + 0x18),
     (NAN(dVar1) || NAN(_PTR_018c6f48)) == (dVar1 == _PTR_018c6f48))) {
    FUN_0151da60();
    FUN_00f3d9c0(auStack_14,&dStack_c);
    dStack_c = (double)(((float)DAT_01d6f3a0 / DAT_018fde94) *
                       *(float *)(*(int *)(param_1 + 0x1a0) + 0x10));
    FUN_00fa07b0();
    FUN_00f42260(param_1,param_1 + 0x104,auStack_14,dStack_c);
  }
  return;
}



/* FUNCTION 27458 ; VA 0x00c17230 ; FUN_00c17230 */

void __thiscall FUN_00c17230(int param_1,int param_2)

{
  float fVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  float *pfVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  float fVar9;
  double dVar10;
  float fVar11;
  float fVar12;
  undefined auStack_138 [48];
  undefined auStack_108 [72];
  undefined auStack_c0 [48];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  float fStack_58;
  undefined8 uStack_54;
  float fStack_4c;
  float fStack_40;
  float fStack_34;
  ulonglong uStack_30;
  ulonglong uStack_24;
  float fStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar3 = FUN_00ca1730(param_1);
  if ((iVar3 != 0) && (iVar7 = 0, 0 < *(int *)(iVar3 + 0x14))) {
    do {
      iVar4 = FUN_00ca1550();
      if (iVar4 != 0) {
        iVar4 = param_1;
        if (param_2 != 0) {
          iVar4 = param_2;
        }
        FUN_00c17230(iVar4);
      }
      iVar7 = iVar7 + 1;
    } while (iVar7 < *(int *)(iVar3 + 0x14));
  }
  iVar3 = *(int *)(param_1 + 0x1a0);
  if (iVar3 == 0) {
    return;
  }
  if (param_2 != 0) {
    iVar7 = *(int *)(param_2 + 0x1a0);
    uVar8 = 0;
    fVar9 = 0.0;
    if ((iVar7 == 0) || (*(char *)(iVar7 + 2) == '\0')) {
      dVar10 = 0.0;
    }
    else {
      uStack_18 = *(undefined4 *)(iVar7 + 0xb8);
      fStack_14 = *(float *)(iVar7 + 0xbc);
      dVar10 = *(double *)(iVar7 + 0xb8);
    }
    if (*(char *)(iVar3 + 2) != '\0') {
      uVar8 = *(undefined4 *)(iVar3 + 0xb8);
      fVar9 = *(float *)(iVar3 + 0xbc);
      uStack_18 = uVar8;
      fStack_14 = fVar9;
    }
    if ((NAN(dVar10) || NAN((double)CONCAT44(fVar9,uVar8))) ==
        (dVar10 == (double)CONCAT44(fVar9,uVar8))) {
      FUN_00fa07b0();
      pfVar5 = (float *)FUN_00c15e70(auStack_108);
      FUN_00fa07b0();
      FUN_00fa07b0();
      FUN_007213c0(auStack_c0,param_1 + 0x104);
      fVar9 = *(float *)(param_1 + 0x134);
      fVar1 = *(float *)(param_1 + 0x138);
      fVar11 = *(float *)(param_1 + 0x13c);
      fVar12 = *(float *)(param_2 + 0x108) * fVar9 + *(float *)(param_2 + 0x114) * fVar1 +
               *(float *)(param_2 + 0x120) * fVar11;
      fStack_8 = *(float *)(param_2 + 0x104) * fVar9 + *(float *)(param_2 + 0x110) * fVar1 +
                 *(float *)(param_2 + 0x11c) * fVar11;
      fVar2 = *(float *)(param_1 + 0x140);
      fStack_c = *(float *)(param_2 + 0x118) * fVar1 + fVar9 * *(float *)(param_2 + 0x10c) +
                 *(float *)(param_2 + 0x124) * fVar11;
      fVar9 = *(float *)(param_1 + 0x144);
      fVar1 = *(float *)(param_1 + 0x148);
      fStack_1c = *(float *)(param_2 + 0x108) * fVar2 + *(float *)(param_2 + 0x114) * fVar9 +
                  *(float *)(param_2 + 0x120) * fVar1;
      fVar11 = *(float *)(param_2 + 0x104) * fVar2 + *(float *)(param_2 + 0x110) * fVar9 +
               *(float *)(param_2 + 0x11c) * fVar1;
      fVar9 = *(float *)(param_2 + 0x118) * fVar9 + fVar2 * *(float *)(param_2 + 0x10c) +
              *(float *)(param_2 + 0x124) * fVar1;
      uStack_30 = (ulonglong)(uint)(*pfVar5 * fVar11 + pfVar5[1] * fStack_1c + pfVar5[2] * fVar9);
      fStack_14 = pfVar5[3] * fVar11 + pfVar5[4] * fStack_1c + pfVar5[5] * fVar9;
      fStack_40 = pfVar5[7] * fStack_1c + pfVar5[6] * fVar11 + pfVar5[8] * fVar9;
      uStack_24 = (ulonglong)(uint)(fStack_8 * *pfVar5 + fVar12 * pfVar5[1] + fStack_c * pfVar5[2]);
      fStack_10 = fStack_8 * pfVar5[3] + fVar12 * pfVar5[4] + fStack_c * pfVar5[5];
      fStack_34 = fVar12 * pfVar5[7] + fStack_8 * pfVar5[6] + fStack_c * pfVar5[8];
      puVar6 = (undefined4 *)FUN_0071f260(auStack_138,auStack_c0);
      uStack_90 = *puVar6;
      uStack_8c = puVar6[1];
      uStack_88 = puVar6[2];
      uStack_84 = puVar6[3];
      uStack_80 = puVar6[4];
      uStack_7c = puVar6[5];
      uStack_78 = puVar6[6];
      uStack_74 = puVar6[7];
      uStack_70 = puVar6[8];
      uStack_6c = puVar6[9];
      uStack_68 = puVar6[10];
      uStack_64 = puVar6[0xb];
      fStack_58 = fStack_34;
      fStack_4c = fStack_40;
      puVar6 = &uStack_90;
      uStack_60 = CONCAT44(fStack_10,(int)uStack_24);
      uStack_54 = CONCAT44(fStack_14,(int)uStack_30);
      goto LAB_00c175cf;
    }
  }
  puVar6 = (undefined4 *)FUN_00c15e70(auStack_108);
LAB_00c175cf:
  FUN_00c18790(puVar6);
  iVar3 = *(int *)(param_1 + 0x1a0);
  if (iVar3 != 0) {
    FUN_00f3bad0();
    FUN_01674ea0(iVar3,0x180);
    *(undefined4 *)(param_1 + 0x1a0) = 0;
  }
  return;
}



/* FUNCTION 27459 ; VA 0x00c17610 ; FUN_00c17610 */

void FUN_00c17610(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  
  FUN_005789c0(&DAT_01ef8e5c,&LAB_00c18030);
  iVar4 = FUN_00c17ab0();
  puVar1 = (uint *)(iVar4 + 8);
  do {
    LOCK();
    uVar3 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar3 & 1) != 0);
  piVar2 = (int *)(param_1 + 4);
  *piVar2 = *piVar2 + -1;
  if (*piVar2 == 0) {
    uVar5 = *(undefined4 *)(param_1 + 8);
    FUN_00551320();
    uVar5 = FUN_00553830(uVar5);
    FUN_01674ea0(uVar5,0x18);
    FUN_00550be0();
    FUN_01674ea0(param_1,0xc);
    *puVar1 = 0;
    return;
  }
  *puVar1 = 0;
  return;
}



/* FUNCTION 27460 ; VA 0x00c176a0 ; FUN_00c176a0 */

void FUN_00c176a0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  
  FUN_005789c0(&DAT_01ef8e6c,&LAB_00c18040);
  iVar4 = FUN_00c17b60();
  puVar1 = (uint *)(iVar4 + 8);
  do {
    LOCK();
    uVar3 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar3 & 1) != 0);
  piVar2 = (int *)(param_1 + 0x60);
  *piVar2 = *piVar2 + -1;
  if (*piVar2 == 0) {
    uVar5 = *(undefined4 *)(param_1 + 100);
    FUN_00551320();
    uVar5 = FUN_00553830(uVar5);
    FUN_01674ea0(uVar5,0x20);
    FUN_01674ea0(param_1,0x68);
    *puVar1 = 0;
    return;
  }
  *puVar1 = 0;
  return;
}



/* FUNCTION 27461 ; VA 0x00c17720 ; FUN_00c17720 */

void FUN_00c17720(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  
  FUN_005789c0(&DAT_01ef8e74,&LAB_00c18050);
  iVar4 = FUN_00c17c10();
  puVar1 = (uint *)(iVar4 + 8);
  do {
    LOCK();
    uVar3 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar3 & 1) != 0);
  piVar2 = (int *)(param_1 + 0x24);
  *piVar2 = *piVar2 + -1;
  if (*piVar2 == 0) {
    uVar5 = *(undefined4 *)(param_1 + 0x28);
    FUN_00551320();
    uVar5 = FUN_00553830(uVar5);
    FUN_01674ea0(uVar5,0x20);
    FUN_00c134d0();
    FUN_00617bc0();
    FUN_00c135a0();
    FUN_01674ea0(param_1,0x2c);
    *puVar1 = 0;
    return;
  }
  *puVar1 = 0;
  return;
}



/* FUNCTION 27462 ; VA 0x00c177c0 ; FUN_00c177c0 */

void FUN_00c177c0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  
  FUN_005789c0(&DAT_01ef8e64,&LAB_00c18060);
  iVar4 = FUN_00c17cc0();
  puVar1 = (uint *)(iVar4 + 8);
  do {
    LOCK();
    uVar3 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar3 & 1) != 0);
  piVar2 = (int *)(param_1 + 4);
  *piVar2 = *piVar2 + -1;
  if (*piVar2 == 0) {
    uVar5 = *(undefined4 *)(param_1 + 8);
    FUN_00551320();
    uVar5 = FUN_00553830(uVar5);
    FUN_01674ea0(uVar5,0x20);
    FUN_00550be0();
    FUN_01674ea0(param_1,0xc);
    *puVar1 = 0;
    return;
  }
  *puVar1 = 0;
  return;
}



/* FUNCTION 27463 ; VA 0x00c17850 ; FUN_00c17850 */

void FUN_00c17850(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  
  FUN_005789c0(&DAT_01ef8e3c,&LAB_00c18070);
  iVar4 = FUN_00c17d70();
  puVar1 = (uint *)(iVar4 + 8);
  do {
    LOCK();
    uVar3 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar3 & 1) != 0);
  piVar2 = (int *)(param_1 + 4);
  *piVar2 = *piVar2 + -1;
  if (*piVar2 == 0) {
    uVar5 = *(undefined4 *)(param_1 + 8);
    FUN_00551320();
    uVar5 = FUN_00553830(uVar5);
    FUN_01674ea0(uVar5,0x20);
    FUN_00550be0();
    FUN_01674ea0(param_1,0xc);
    *puVar1 = 0;
    return;
  }
  *puVar1 = 0;
  return;
}



/* FUNCTION 27464 ; VA 0x00c178e0 ; FUN_00c178e0 */

void FUN_00c178e0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  
  FUN_005789c0(&DAT_01ef8e4c,&LAB_00c18080);
  iVar4 = FUN_00c17e20();
  puVar1 = (uint *)(iVar4 + 8);
  do {
    LOCK();
    uVar3 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar3 & 1) != 0);
  piVar2 = (int *)(param_1 + 4);
  *piVar2 = *piVar2 + -1;
  if (*piVar2 == 0) {
    uVar5 = *(undefined4 *)(param_1 + 8);
    FUN_00551320();
    uVar5 = FUN_00553830(uVar5);
    FUN_01674ea0(uVar5,0x20);
    FUN_00550be0();
    FUN_01674ea0(param_1,0xc);
    *puVar1 = 0;
    return;
  }
  *puVar1 = 0;
  return;
}



/* FUNCTION 27465 ; VA 0x00c17970 ; FUN_00c17970 */

void FUN_00c17970(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  
  FUN_005789c0(&DAT_01ef8e44,&LAB_00c18090);
  iVar4 = FUN_00c17ed0();
  puVar1 = (uint *)(iVar4 + 8);
  do {
    LOCK();
    uVar3 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar3 & 1) != 0);
  piVar2 = (int *)(param_1 + 0x30);
  *piVar2 = *piVar2 + -1;
  if (*piVar2 == 0) {
    uVar5 = *(undefined4 *)(param_1 + 0x34);
    FUN_00551320();
    uVar5 = FUN_00553830(uVar5);
    FUN_01674ea0(uVar5,0x20);
    FUN_00c134d0();
    FUN_00617bc0();
    FUN_00c135a0();
    FUN_01674ea0(param_1,0x38);
    *puVar1 = 0;
    return;
  }
  *puVar1 = 0;
  return;
}



/* FUNCTION 27466 ; VA 0x00c17a10 ; FUN_00c17a10 */

void FUN_00c17a10(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  
  FUN_005789c0(&DAT_01ef8e54,&LAB_00c180a0);
  iVar4 = FUN_00c17f80();
  puVar1 = (uint *)(iVar4 + 8);
  do {
    LOCK();
    uVar3 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar3 & 1) != 0);
  piVar2 = (int *)(param_1 + 0x24);
  *piVar2 = *piVar2 + -1;
  if (*piVar2 == 0) {
    uVar5 = *(undefined4 *)(param_1 + 0x28);
    FUN_00551320();
    uVar5 = FUN_00553830(uVar5);
    FUN_01674ea0(uVar5,0x20);
    FUN_00c134d0();
    FUN_00617bc0();
    FUN_00c135a0();
    FUN_01674ea0(param_1,0x2c);
    *puVar1 = 0;
    return;
  }
  *puVar1 = 0;
  return;
}



/* FUNCTION 27467 ; VA 0x00c17ab0 ; FUN_00c17ab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_00c17ab0(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018061cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8ec8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8ec8,param_1);
    if (DAT_01ef8ec8 == -1) {
      uStack_8 = 0;
      _DAT_01ef8ebc = 0;
      _DAT_01ef8ec0 = 0;
      _DAT_01ef8ebc = FUN_00601dc0();
      _DAT_01ef8ec4 = 0;
      FUN_016f3654(&LAB_01893540);
      FUN_016f37bf(&DAT_01ef8ec8);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef8ebc;
}



/* FUNCTION 27468 ; VA 0x00c17b60 ; FUN_00c17b60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_00c17b60(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018061ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8ee8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8ee8,param_1);
    if (DAT_01ef8ee8 == -1) {
      uStack_8 = 0;
      _DAT_01ef8edc = 0;
      _DAT_01ef8ee0 = 0;
      _DAT_01ef8edc = FUN_00575ab0();
      _DAT_01ef8ee4 = 0;
      FUN_016f3654(&LAB_01893550);
      FUN_016f37bf(&DAT_01ef8ee8);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef8edc;
}



/* FUNCTION 27469 ; VA 0x00c17c10 ; FUN_00c17c10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_00c17c10(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180620c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8ef8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8ef8,param_1);
    if (DAT_01ef8ef8 == -1) {
      uStack_8 = 0;
      _DAT_01ef8eec = 0;
      _DAT_01ef8ef0 = 0;
      _DAT_01ef8eec = FUN_00575ab0();
      _DAT_01ef8ef4 = 0;
      FUN_016f3654(&LAB_01893560);
      FUN_016f37bf(&DAT_01ef8ef8);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef8eec;
}



/* FUNCTION 27470 ; VA 0x00c17cc0 ; FUN_00c17cc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_00c17cc0(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180622c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8ed8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8ed8,param_1);
    if (DAT_01ef8ed8 == -1) {
      uStack_8 = 0;
      _DAT_01ef8ecc = 0;
      _DAT_01ef8ed0 = 0;
      _DAT_01ef8ecc = FUN_00575ab0();
      _DAT_01ef8ed4 = 0;
      FUN_016f3654(&LAB_01893570);
      FUN_016f37bf(&DAT_01ef8ed8);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef8ecc;
}



/* FUNCTION 27471 ; VA 0x00c17d70 ; FUN_00c17d70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_00c17d70(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180624c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8e88) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8e88,param_1);
    if (DAT_01ef8e88 == -1) {
      uStack_8 = 0;
      _DAT_01ef8e7c = 0;
      _DAT_01ef8e80 = 0;
      _DAT_01ef8e7c = FUN_00575ab0();
      _DAT_01ef8e84 = 0;
      FUN_016f3654(&LAB_01893580);
      FUN_016f37bf(&DAT_01ef8e88);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef8e7c;
}



/* FUNCTION 27472 ; VA 0x00c17e20 ; FUN_00c17e20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_00c17e20(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180626c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8ea8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8ea8,param_1);
    if (DAT_01ef8ea8 == -1) {
      uStack_8 = 0;
      _DAT_01ef8e9c = 0;
      _DAT_01ef8ea0 = 0;
      _DAT_01ef8e9c = FUN_00575ab0();
      _DAT_01ef8ea4 = 0;
      FUN_016f3654(&LAB_01893590);
      FUN_016f37bf(&DAT_01ef8ea8);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef8e9c;
}



/* FUNCTION 27473 ; VA 0x00c17ed0 ; FUN_00c17ed0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_00c17ed0(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180628c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8e98) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8e98,param_1);
    if (DAT_01ef8e98 == -1) {
      uStack_8 = 0;
      _DAT_01ef8e8c = 0;
      _DAT_01ef8e90 = 0;
      _DAT_01ef8e8c = FUN_00575ab0();
      _DAT_01ef8e94 = 0;
      FUN_016f3654(&LAB_018935a0);
      FUN_016f37bf(&DAT_01ef8e98);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef8e8c;
}



/* FUNCTION 27474 ; VA 0x00c17f80 ; FUN_00c17f80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_00c17f80(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018062ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8eb8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef8eb8,param_1);
    if (DAT_01ef8eb8 == -1) {
      uStack_8 = 0;
      _DAT_01ef8eac = 0;
      _DAT_01ef8eb0 = 0;
      _DAT_01ef8eac = FUN_00575ab0();
      _DAT_01ef8eb4 = 0;
      FUN_016f3654(&LAB_018935b0);
      FUN_016f37bf(&DAT_01ef8eb8);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef8eac;
}



/* FUNCTION 27475 ; VA 0x00c180b0 ; FUN_00c180b0 */

void __thiscall FUN_00c180b0(int param_1,undefined4 param_2)

{
  FUN_00c18340(param_2,*(undefined *)(param_1 + 0x222));
  return;
}



/* FUNCTION 27476 ; VA 0x00c180d0 ; FUN_00c180d0 */

void __thiscall FUN_00c180d0(int param_1,undefined4 param_2)

{
  char *pcVar1;
  int iVar2;
  
  pcVar1 = (char *)(param_1 + 0x8e);
  if (param_1 == 0) {
    pcVar1 = (char *)0x3e;
  }
  if (*pcVar1 != (char)param_2) {
    iVar2 = 0;
    if (*(int *)(param_1 + 0x1a8) != 0) {
      iVar2 = FUN_00bbf320(param_1);
    }
    FUN_00fa0040(param_2,param_1 + 0x30);
    if (iVar2 != 0) {
      FUN_00bbf310(iVar2);
    }
  }
  return;
}



/* FUNCTION 27477 ; VA 0x00c18130 ; FUN_00c18130 */

void __thiscall FUN_00c18130(int param_1,char param_2)

{
  if ((DAT_01d69068 != '\0') && (param_2 != *(char *)(param_1 + 0x226))) {
    *(char *)(param_1 + 0x226) = param_2;
    if ((param_2 == '\0') && ((DAT_01d69068 == '\0' && (*(char *)(param_1 + 0x224) != '\0')))) {
      *(undefined *)(param_1 + 0x224) = 0;
    }
    if (*(int *)(param_1 + 0x1a8) != 0) {
      FUN_00bbf650();
      return;
    }
  }
  return;
}



/* FUNCTION 27478 ; VA 0x00c18180 ; FUN_00c18180 */

void __thiscall FUN_00c18180(int param_1,char param_2)

{
  if ((*(char *)(param_1 + 0x22a) != param_2) &&
     (*(char *)(param_1 + 0x22a) = param_2, *(int *)(param_1 + 0x1a8) != 0)) {
    FUN_00bbf650(param_1);
    FUN_00bbf640(param_1);
  }
  return;
}



/* FUNCTION 27479 ; VA 0x00c181c0 ; FUN_00c181c0 */

void __thiscall FUN_00c181c0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  uVar3 = -(uint)(param_1 != 0) & param_1 + 0x50U;
  FUN_00fa07b0();
  uStack_4c = *param_2;
  uStack_48 = param_2[1];
  uStack_44 = param_2[2];
  uStack_40 = param_2[3];
  uStack_3c = param_2[4];
  uStack_38 = param_2[5];
  uStack_34 = param_2[6];
  uStack_30 = param_2[7];
  uStack_2c = param_2[8];
  uStack_28 = param_2[9];
  uStack_24 = param_2[10];
  uStack_20 = param_2[0xb];
  uStack_14 = *(undefined4 *)(uVar3 + 0xec);
  uStack_8 = *(undefined4 *)(uVar3 + 0xf8);
  uStack_1c = *(undefined8 *)(uVar3 + 0xe4);
  uStack_10 = *(undefined8 *)(uVar3 + 0xf0);
  FUN_00c18610(&uStack_4c);
  if ((*(char *)(param_1 + 0x222) != '\0') &&
     (*(int *)(param_1 + 0x1c4) - (int)*(undefined4 **)(param_1 + 0x1c0) >> 3 != 0)) {
    piVar1 = (int *)**(undefined4 **)(param_1 + 0x1c0);
    while (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x28))();
      if (param_1 == piVar1[1]) {
        iVar2 = piVar1[4];
      }
      else {
        iVar2 = piVar1[5];
      }
      if ((uint)(*(int *)(param_1 + 0x1c4) - *(int *)(param_1 + 0x1c0) >> 3) <= iVar2 + 1U) {
        return;
      }
      piVar1 = *(int **)(*(int *)(param_1 + 0x1c0) + (iVar2 + 1U) * 8);
    }
  }
  return;
}



/* FUNCTION 27480 ; VA 0x00c18290 ; FUN_00c18290 */

void __thiscall FUN_00c18290(int param_1,undefined4 param_2)

{
  FUN_00c18340(*(undefined *)(param_1 + 0x223),param_2);
  return;
}



/* FUNCTION 27481 ; VA 0x00c182b0 ; FUN_00c182b0 */

void __thiscall FUN_00c182b0(int param_1,float param_2)

{
  if (((NAN(param_2) || NAN(*(float *)(param_1 + 0x218))) ==
       (param_2 == *(float *)(param_1 + 0x218))) &&
     (*(float *)(param_1 + 0x218) = param_2, *(int *)(param_1 + 0x1a8) != 0)) {
    FUN_00bbf270();
    return;
  }
  return;
}



/* FUNCTION 27482 ; VA 0x00c182f0 ; FUN_00c182f0 */

void __thiscall FUN_00c182f0(int param_1,uint param_2)

{
  int iVar1;
  
  if (*(byte *)(param_1 + 0x22d) != param_2) {
    iVar1 = 0;
    if (*(int *)(param_1 + 0x1a8) != 0) {
      iVar1 = FUN_00bbf320(param_1);
    }
    *(char *)(param_1 + 0x22d) = (char)param_2;
    if (iVar1 != 0) {
      FUN_00bbf310(iVar1);
    }
  }
  return;
}



/* FUNCTION 27483 ; VA 0x00c18340 ; FUN_00c18340 */

void __thiscall FUN_00c18340(int param_1,undefined4 param_2,char param_3)

{
  char cVar1;
  char cVar2;
  
  if ((*(char *)(param_1 + 0x223) == '\0') && (*(char *)(param_1 + 0x222) == '\0')) {
    cVar1 = '\0';
  }
  else {
    cVar1 = '\x01';
  }
  if (((char)param_2 == '\0') && (param_3 == '\0')) {
    cVar2 = '\0';
  }
  else {
    cVar2 = '\x01';
  }
  if ((cVar1 != cVar2) && (*(int *)(param_1 + 0x1a8) != 0)) {
    FUN_00bbf630(param_1);
  }
  *(char *)(param_1 + 0x223) = (char)param_2;
  *(char *)(param_1 + 0x222) = param_3;
  if ((cVar1 != cVar2) && (*(int *)(param_1 + 0x1a8) != 0)) {
    FUN_00bbf620(param_1);
  }
  FUN_00f9ffb0(param_2);
  return;
}



/* FUNCTION 27484 ; VA 0x00c183c0 ; FUN_00c183c0 */

void __thiscall FUN_00c183c0(int param_1,float param_2)

{
  if (((NAN(param_2) || NAN(*(float *)(param_1 + 0x214))) ==
       (param_2 == *(float *)(param_1 + 0x214))) &&
     (*(float *)(param_1 + 0x214) = param_2, *(int *)(param_1 + 0x1a8) != 0)) {
    FUN_00bbf270();
    return;
  }
  return;
}



/* FUNCTION 27485 ; VA 0x00c18400 ; FUN_00c18400 */

void __thiscall FUN_00c18400(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined8 uStack_10;
  int iStack_8;
  
  iVar2 = (**(code **)(**(int **)(param_1 + 0x1ac) + 8))();
  if (iVar2 != param_2) {
    piVar1 = *(int **)(param_1 + 0x1ac);
    uStack_10 = *(undefined8 *)(piVar1 + 1);
    iStack_8 = piVar1[3];
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 4))(1);
    }
    uVar3 = FUN_00c16be0(param_2);
    *(undefined4 *)(param_1 + 0x1ac) = uVar3;
    if (*(int *)(param_1 + 0x1a8) != 0) {
      FUN_00bbf640(param_1);
    }
    FUN_00c18e20(&uStack_10);
    *(undefined *)(param_1 + 0x229) = 1;
  }
  return;
}



/* FUNCTION 27486 ; VA 0x00c18480 ; FUN_00c18480 */

void __thiscall FUN_00c18480(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  *(undefined4 *)(param_1 + 0x1e0) = *param_2;
  *(undefined4 *)(param_1 + 0x1e4) = param_2[1];
  if (DAT_01d69150 != '\0') {
    puVar1 = (undefined4 *)(param_1 + 0x94);
    if (param_1 == 0) {
      puVar1 = (undefined4 *)0x44;
    }
    *puVar1 = param_2[1];
  }
  return;
}



/* FUNCTION 27487 ; VA 0x00c184c0 ; FUN_00c184c0 */

void __thiscall FUN_00c184c0(int param_1,char param_2)

{
  if (((DAT_01d69068 == '\0') || (*(char *)(param_1 + 0x226) != '\0')) &&
     (param_2 != *(char *)(param_1 + 0x224))) {
    *(char *)(param_1 + 0x224) = param_2;
  }
  return;
}



/* FUNCTION 27488 ; VA 0x00c184f0 ; FUN_00c184f0 */

void __thiscall FUN_00c184f0(int param_1,char param_2)

{
  char *pcVar1;
  int iVar2;
  
  pcVar1 = (char *)(param_1 + 0x8c);
  if (param_1 == 0) {
    pcVar1 = (char *)0x3c;
  }
  iVar2 = param_1 + 0x50;
  if (param_2 != *pcVar1) {
    if (param_1 == 0) {
      iVar2 = 0;
    }
    *(char *)(iVar2 + 0x3c) = param_2;
    FUN_00f9fb70();
    if (*(int *)(param_1 + 0x1a8) != 0) {
      FUN_00bbf790(param_1);
    }
  }
  return;
}



/* FUNCTION 27489 ; VA 0x00c18540 ; FUN_00c18540 */

void __thiscall FUN_00c18540(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined auStack_34 [36];
  undefined auStack_10 [12];
  
  FUN_00fa0110(param_2);
  uVar1 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x60))(auStack_34,param_2);
  FUN_00fa0380(uVar1);
  uVar1 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x5c))(auStack_10);
  FUN_00fa0050(uVar1);
  *(undefined *)(param_1 + 0x229) = 1;
  return;
}



/* FUNCTION 27490 ; VA 0x00c185b0 ; FUN_00c185b0 */

void __thiscall FUN_00c185b0(int param_1,char param_2,undefined4 param_3,undefined4 param_4)

{
  if (param_2 != *(char *)(param_1 + 0x228)) {
    *(char *)(param_1 + 0x228) = param_2;
    (**(code **)(**(int **)(param_1 + 0x1b0) + 0xc))(param_3,param_4);
  }
  return;
}



/* FUNCTION 27491 ; VA 0x00c185e0 ; FUN_00c185e0 */

void __thiscall FUN_00c185e0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1b0) = param_2;
  if (DAT_01ee41fd != '\0') {
    FUN_01677490(DAT_01ee41fd,"Owner %p set on primitive %p",param_2,param_2,0);
  }
  return;
}



/* FUNCTION 27492 ; VA 0x00c18610 ; FUN_00c18610 */

void __thiscall FUN_00c18610(int param_1,int param_2)

{
  undefined4 uVar1;
  bool bVar2;
  bool bVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  
  iVar8 = param_1 + 0x50;
  if (param_1 == 0) {
    iVar8 = 0;
  }
  FUN_00fa07b0();
  cVar4 = FUN_00c13f30(iVar8 + 0xb4);
  if (cVar4 == '\0') {
    return;
  }
  iVar5 = *(int *)(*(int *)(param_1 + 0x1ac) + 0x10);
  if (iVar5 != 0) {
    FUN_00fa05c0(iVar5);
  }
  iVar5 = FUN_00ca1730(param_1);
  if (iVar5 == 0) {
LAB_00c1867c:
    bVar2 = false;
  }
  else {
    iVar6 = FUN_00ca1550();
    bVar2 = true;
    if (iVar6 != param_1) goto LAB_00c1867c;
  }
  if ((((NAN(*(float *)(param_2 + 0x24)) || NAN(*(float *)(iVar8 + 0xd8))) !=
        (*(float *)(param_2 + 0x24) == *(float *)(iVar8 + 0xd8))) &&
      ((NAN(*(float *)(param_2 + 0x28)) || NAN(*(float *)(iVar8 + 0xdc))) !=
       (*(float *)(param_2 + 0x28) == *(float *)(iVar8 + 0xdc)))) &&
     ((NAN(*(float *)(param_2 + 0x2c)) || NAN(*(float *)(iVar8 + 0xe0))) !=
      (*(float *)(param_2 + 0x2c) == *(float *)(iVar8 + 0xe0)))) {
    cVar4 = FUN_01160ab0(iVar8 + 0xb4);
    bVar3 = false;
    if (cVar4 != '\0') goto LAB_00c186c4;
  }
  bVar3 = true;
LAB_00c186c4:
  if (bVar2) {
    if ((*(char *)(param_1 + 0x222) == '\0') && (*(char *)(param_1 + 0x223) == '\0')) {
      FUN_00bc1c10(param_1,0);
    }
  }
  else if (iVar5 != 0) {
    return;
  }
  FUN_00fa0400(param_2,param_1 + 0x30);
  if ((iVar5 == 0) && (bVar3)) {
    FUN_00c3e3a0();
  }
  if ((bVar2) && (bVar3)) {
    if (DAT_01d67ba4 != '\0') {
      FUN_00ca1bb0();
    }
    if (((DAT_01d69070 != '\0') && (*(int *)(iVar5 + 0x5c) != 0)) &&
       (*(int *)(*(int *)(iVar5 + 0x5c) + 4) != 0)) {
      FUN_00ce6600(iVar5);
    }
    uVar1 = *(undefined4 *)(*(int *)(param_1 + 0x1a8) + 0x6ac);
    uVar7 = FUN_00ca1550();
    FUN_00c12d90(uVar1,uVar7,0);
    FUN_00ca2570(*(undefined4 *)(param_1 + 0x1a8));
  }
  return;
}



/* FUNCTION 27493 ; VA 0x00c18790 ; FUN_00c18790 */

void __thiscall FUN_00c18790(int param_1,undefined4 param_2)

{
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  if (*(int *)(param_1 + 0x198) != 0) {
    FUN_00fa07b0();
    uStack_4c = *(undefined4 *)(param_1 + 0x104);
    uStack_48 = *(undefined4 *)(param_1 + 0x108);
    uStack_44 = *(undefined4 *)(param_1 + 0x10c);
    uStack_40 = *(undefined4 *)(param_1 + 0x110);
    uStack_14 = *(undefined4 *)(param_1 + 0x13c);
    uStack_3c = *(undefined4 *)(param_1 + 0x114);
    uStack_38 = *(undefined4 *)(param_1 + 0x118);
    uStack_34 = *(undefined4 *)(param_1 + 0x11c);
    uStack_30 = *(undefined4 *)(param_1 + 0x120);
    uStack_8 = *(undefined4 *)(param_1 + 0x148);
    uStack_2c = *(undefined4 *)(param_1 + 0x124);
    uStack_28 = *(undefined4 *)(param_1 + 0x128);
    uStack_24 = *(undefined4 *)(param_1 + 300);
    uStack_20 = *(undefined4 *)(param_1 + 0x130);
    uStack_1c = *(undefined8 *)(param_1 + 0x134);
    uStack_10 = *(undefined8 *)(param_1 + 0x140);
    FUN_00c18610(param_2);
    FUN_0091c070(param_1,&uStack_4c,&uStack_1c);
    return;
  }
  FUN_00c18610(param_2);
  return;
}



/* FUNCTION 27494 ; VA 0x00c18830 ; FUN_00c18830 */

void __thiscall
FUN_00c18830(int param_1,int param_2,uint param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
            uint param_10)

{
  int iVar1;
  char cVar2;
  uint *puVar3;
  uint *puVar4;
  uint in_stack_00000048;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined8 in_stack_00000060;
  uint in_stack_00000068;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined8 uStack_d4;
  int iStack_cc;
  undefined4 *puStack_c8;
  undefined4 *puStack_c4;
  uint *puStack_c0;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  uint uStack_98;
  uint uStack_94;
  uint uStack_90;
  uint uStack_8c;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  uint uStack_7c;
  uint uStack_78;
  undefined8 uStack_74;
  uint auStack_60 [2];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  int iStack_1c;
  uint *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806308;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  puStack_c0 = (uint *)0xc18864;
  ExceptionList = &pvStack_10;
  FUN_00703dc0();
  puVar3 = (uint *)(param_1 + 0x50);
  if (param_1 == 0) {
    puVar3 = (uint *)0x0;
  }
  puStack_c0 = (uint *)0xc18878;
  puStack_18 = puVar3;
  FUN_00fa07b0();
  puVar4 = puVar3 + 0x2d;
  if (*(int *)(param_1 + 0x198) != 0) {
    uStack_b4 = *puVar4;
    uStack_b0 = puVar3[0x2e];
    uStack_ac = puVar3[0x2f];
    uStack_a8 = puVar3[0x30];
    uStack_a4 = puVar3[0x31];
    uStack_a0 = puVar3[0x32];
    uStack_9c = puVar3[0x33];
    uStack_98 = puVar3[0x34];
    uStack_94 = puVar3[0x35];
    uStack_90 = puVar3[0x36];
    uStack_8c = puVar3[0x37];
    uStack_88 = puVar3[0x38];
    uStack_84 = puVar3[0x39];
    uStack_80 = puVar3[0x3a];
    uStack_7c = puVar3[0x3b];
    uStack_78 = puVar3[0x3c];
    uStack_74 = *(undefined8 *)(puVar3 + 0x3d);
    if (param_10 == 0) {
      puStack_c0 = (uint *)0xc18c10;
      puStack_c0 = (uint *)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
      puStack_c4 = (undefined4 *)0xc18c1a;
      FUN_0054e5e0();
    }
    puStack_c0 = &uStack_b4;
    puStack_c8 = (undefined4 *)&stack0x00000030;
    iStack_cc = 0xc188d8;
    puStack_c4 = (undefined4 *)param_1;
    (**(code **)((param_10 & 0xfffffffe) + 4))();
  }
  puStack_c4 = (undefined4 *)0xc188e4;
  puStack_c0 = puVar4;
  cVar2 = FUN_00c13f30();
  if (cVar2 == '\0') goto LAB_00c18b4e;
  puStack_c0 = *(uint **)(*(int *)(param_1 + 0x1ac) + 0x10);
  if (puStack_c0 != (uint *)0x0) {
    puStack_c4 = (undefined4 *)0xc18902;
    FUN_00fa05c0();
  }
  if ((((NAN(*(float *)(param_2 + 0x24)) || NAN((float)puVar3[0x36])) ==
        (*(float *)(param_2 + 0x24) == (float)puVar3[0x36])) ||
      ((NAN(*(float *)(param_2 + 0x28)) || NAN((float)puVar3[0x37])) ==
       (*(float *)(param_2 + 0x28) == (float)puVar3[0x37]))) ||
     ((NAN(*(float *)(param_2 + 0x2c)) || NAN((float)puVar3[0x38])) ==
      (*(float *)(param_2 + 0x2c) == (float)puVar3[0x38]))) {
LAB_00c18940:
    cStack_11 = '\x01';
  }
  else {
    puStack_c4 = (undefined4 *)0xc18938;
    puStack_c0 = puVar4;
    cVar2 = FUN_01160ab0();
    cStack_11 = '\0';
    if (cVar2 == '\0') goto LAB_00c18940;
  }
  puStack_c0 = (uint *)(param_1 + 0x30);
  puStack_c4 = (undefined4 *)param_2;
  puStack_c8 = (undefined4 *)0xc18953;
  FUN_00fa0400();
  if (cStack_11 != '\0') {
    puStack_c0 = (uint *)param_1;
    if (DAT_01d69070 == '\0') {
      iVar1 = *(int *)(*(int *)(param_1 + 0x1a8) + 0x6ac);
      puStack_c4 = (undefined4 *)0xc18a91;
      FUN_00ca1730();
      auStack_60[0] = 0;
      puStack_18 = auStack_60;
      if (param_3 != 0) {
        auStack_60[0] = param_3;
        if ((param_3 & 1) == 0) {
          puStack_c4 = &uStack_58;
          puStack_c0 = (uint *)0x0;
          puStack_c8 = &param_5;
          iStack_cc = 0xc18ad6;
          (**(code **)(param_3 & 0xfffffffe))();
        }
        else {
          uStack_58 = param_5;
          uStack_54 = param_6;
          uStack_50 = param_7;
          uStack_4c = param_8;
          uStack_48 = param_9;
        }
      }
      uStack_8._0_1_ = 8;
      uStack_40 = 0;
      if (in_stack_00000048 != 0) {
        uStack_40 = in_stack_00000048;
        if ((in_stack_00000048 & 1) == 0) {
          puStack_c4 = &uStack_38;
          puStack_c0 = (uint *)0x0;
          puStack_c8 = &stack0x00000050;
          iStack_cc = 0xc18b17;
          (**(code **)(in_stack_00000048 & 0xfffffffe))();
        }
        else {
          uStack_38 = in_stack_00000050;
          uStack_34 = in_stack_00000054;
          uStack_30 = in_stack_00000058;
          uStack_2c = in_stack_0000005c;
          uStack_28 = in_stack_00000060;
        }
      }
      uStack_8._0_1_ = 9;
      puStack_c0 = (uint *)0xc18b2e;
      iStack_20 = iVar1;
      iStack_1c = param_1;
      puStack_c4 = (undefined4 *)FUN_00ca1550();
      puStack_c0 = (uint *)0x0;
      FUN_00c12e20(auStack_60);
      FUN_00c12b90();
      puStack_c0 = (uint *)0xc18b4e;
      FUN_008c3510();
    }
    else {
      puStack_c4 = (undefined4 *)0xc18970;
      puStack_c0 = (uint *)FUN_00ca1730();
      if (in_stack_00000068 == 0) {
        puStack_c0 = (uint *)0xc18c22;
        puStack_c0 = (uint *)FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
                    /* WARNING: Subroutine does not return */
        puStack_c4 = (undefined4 *)&UNK_00c18c2c;
        FUN_0054e5e0();
      }
      puStack_c8 = (undefined4 *)&stack0x00000070;
      iStack_cc = 0xc1899a;
      puStack_c4 = *(undefined4 **)(*(int *)(param_1 + 0x1a8) + 0x6ac);
      (**(code **)((in_stack_00000068 & 0xfffffffe) + 4))();
      uStack_d4 = CONCAT44(0xc189a0,(undefined4)uStack_d4);
      iStack_cc = param_1;
      FUN_00ca1730();
      uStack_40 = 0;
      if (param_3 != 0) {
        uStack_40 = param_3;
        if ((param_3 & 1) == 0) {
          puStack_c4 = &uStack_38;
          puStack_c0 = (uint *)0x0;
          puStack_c8 = &param_5;
          iStack_cc = 0xc189df;
          (**(code **)(param_3 & 0xfffffffe))();
        }
        else {
          uStack_38 = param_5;
          uStack_34 = param_6;
          uStack_30 = param_7;
          uStack_2c = param_8;
          uStack_28 = param_9;
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      puStack_c0 = (uint *)0xc189f0;
      iStack_20 = param_1;
      puStack_c4 = (undefined4 *)FUN_00ca1550();
      puStack_c0 = (uint *)0x0;
      if (uStack_40 != 0) {
        if ((uStack_40 & 1) == 0) {
          (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_e4,0);
        }
        else {
          uStack_e4 = uStack_38;
          uStack_e0 = uStack_34;
          uStack_dc = uStack_30;
          uStack_d8 = uStack_2c;
          uStack_d4 = uStack_28;
        }
      }
      iStack_cc = iStack_20;
      FUN_00c12a50();
      uStack_8._0_1_ = 7;
      if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
         (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
        puStack_c8 = &uStack_38;
        puStack_c0 = (uint *)0x2;
        iStack_cc = 0xc18a75;
        puStack_c4 = puStack_c8;
        (**(code **)(uStack_40 & 0xfffffffe))();
      }
    }
  }
LAB_00c18b4e:
  uStack_8._0_1_ = 10;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_c8 = &param_5;
    puStack_c0 = (uint *)0x2;
    iStack_cc = 0xc18b6f;
    puStack_c4 = puStack_c8;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 0xb;
  if (param_10 != 0) {
    if (((param_10 & 1) == 0) && (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
      puStack_c8 = (undefined4 *)&stack0x00000030;
      puStack_c0 = (uint *)0x2;
      iStack_cc = 0xc18b9a;
      puStack_c4 = puStack_c8;
      (**(code **)(param_10 & 0xfffffffe))();
    }
    param_10 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (in_stack_00000048 != 0) {
    if (((in_stack_00000048 & 1) == 0) &&
       (*(code **)(in_stack_00000048 & 0xfffffffe) != (code *)0x0)) {
      puStack_c8 = &stack0x00000050;
      puStack_c0 = (uint *)0x2;
      iStack_cc = 0xc18bc5;
      puStack_c4 = puStack_c8;
      (**(code **)(in_stack_00000048 & 0xfffffffe))();
    }
    in_stack_00000048 = 0;
  }
  uStack_8 = 0xd;
  if (((in_stack_00000068 != 0) && ((in_stack_00000068 & 1) == 0)) &&
     (*(code **)(in_stack_00000068 & 0xfffffffe) != (code *)0x0)) {
    puStack_c8 = (undefined4 *)&stack0x00000070;
    puStack_c0 = (uint *)0x2;
    iStack_cc = 0xc18bf3;
    puStack_c4 = puStack_c8;
    (**(code **)(in_stack_00000068 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27495 ; VA 0x00c18c30 ; FUN_00c18c30 */

void __thiscall FUN_00c18c30(int param_1,uint param_2)

{
  if ((*(ushort *)(param_1 + 0x220) != param_2) &&
     (*(short *)(param_1 + 0x220) = (short)param_2, *(int *)(param_1 + 0x1a8) != 0)) {
    FUN_00c19d80();
    FUN_00bbf270(param_1);
    FUN_00bbf330(param_1);
  }
  return;
}



/* FUNCTION 27496 ; VA 0x00c18c80 ; FUN_00c18c80 */

void __thiscall FUN_00c18c80(int param_1,char *param_2)

{
  int *piVar1;
  char *pcVar2;
  int iVar3;
  undefined4 uVar4;
  char cVar5;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  pcVar2 = *(char **)(param_1 + 0x21c);
  if ((((*param_2 != *pcVar2) ||
       ((NAN(*(float *)(param_2 + 4)) || NAN(*(float *)(pcVar2 + 4))) ==
        (*(float *)(param_2 + 4) == *(float *)(pcVar2 + 4)))) ||
      ((NAN(*(float *)(param_2 + 0xc)) || NAN(*(float *)(pcVar2 + 0xc))) ==
       (*(float *)(param_2 + 0xc) == *(float *)(pcVar2 + 0xc)))) ||
     ((((NAN(*(float *)(param_2 + 8)) || NAN(*(float *)(pcVar2 + 8))) ==
        (*(float *)(param_2 + 8) == *(float *)(pcVar2 + 8)) ||
       ((NAN(*(float *)(param_2 + 0x10)) || NAN(*(float *)(pcVar2 + 0x10))) ==
        (*(float *)(param_2 + 0x10) == *(float *)(pcVar2 + 0x10)))) ||
      ((NAN(*(float *)(param_2 + 0x14)) || NAN(*(float *)(pcVar2 + 0x14))) ==
       (*(float *)(param_2 + 0x14) == *(float *)(pcVar2 + 0x14)))))) {
    ExceptionList = &pvStack_10;
    iStack_14 = param_1;
    FUN_00c16ad0(&param_2,param_2);
    LOCK();
    *(int *)(param_2 + 0x18) = *(int *)(param_2 + 0x18) + 1;
    UNLOCK();
    iStack_14 = *(int *)(param_1 + 0x21c);
    *(char **)(param_1 + 0x21c) = param_2;
    uStack_8 = 0;
    LOCK();
    iVar3 = *(int *)(iStack_14 + 0x18) + -1;
    *(int *)(iStack_14 + 0x18) = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      FUN_00c16790();
      uVar4 = DAT_01ef8e28;
      EnterCriticalSection(DAT_01ef8e28);
      cVar5 = FUN_0089d8f0(&iStack_14);
      if (cVar5 != '\0') {
        FUN_00c15230(iStack_14);
      }
      LeaveCriticalSection(uVar4);
    }
    uStack_8 = 1;
    LOCK();
    piVar1 = (int *)(param_2 + 0x18);
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_00c16790();
      uVar4 = DAT_01ef8e28;
      EnterCriticalSection(DAT_01ef8e28);
      cVar5 = FUN_0089d8f0(&param_2);
      if (cVar5 != '\0') {
        FUN_00c15230(param_2);
      }
      LeaveCriticalSection(uVar4);
    }
    uStack_8 = 0xffffffff;
    if (*(int *)(param_1 + 0x1a8) != 0) {
      FUN_00c19d80();
      FUN_00bbf270(param_1);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27497 ; VA 0x00c18df0 ; FUN_00c18df0 */

void __thiscall FUN_00c18df0(int param_1,char param_2)

{
  if ((param_2 != *(char *)(param_1 + 0x225)) &&
     (*(char *)(param_1 + 0x225) = param_2, *(int *)(param_1 + 0x1a8) != 0)) {
    FUN_00bbf650();
    return;
  }
  return;
}



/* FUNCTION 27498 ; VA 0x00c18e20 ; FUN_00c18e20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c18e20(int param_1,float *param_2)

{
  float fVar1;
  int iVar2;
  int iVar3;
  float10 fVar4;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  double dStack_10;
  float fStack_8;
  
  fStack_8 = param_2[2];
  if (DAT_01962c98 <= fStack_8) {
    fStack_8 = DAT_01962c98;
  }
  fStack_18 = param_2[1];
  if (DAT_01962c98 <= param_2[1]) {
    fStack_18 = DAT_01962c98;
  }
  param_2 = (float *)*param_2;
  if (DAT_01962c98 <= (float)param_2) {
    param_2 = (float *)DAT_01962c98;
  }
  if (fStack_8 <= 0.0) {
    fStack_8 = 0.0;
  }
  if (fStack_18 <= 0.0) {
    fStack_18 = 0.0;
  }
  if ((float)param_2 <= 0.0) {
    param_2 = (float *)0x0;
  }
  fStack_1c = (float)param_2;
  fStack_14 = fStack_8;
  if (_DAT_01962c9c < (float)param_2 * fStack_18 * fStack_8) {
    dStack_10 = (double)(DAT_018d0938 / ((float)param_2 * fStack_8));
    fVar4 = (float10)FUN_01725280(dStack_10);
    fStack_18 = (float)fVar4;
  }
  iVar2 = *(int *)(param_1 + 0x1ac);
  fVar1 = *(float *)(iVar2 + 4);
  if ((((NAN((float)param_2) || NAN(fVar1)) == ((float)param_2 == fVar1)) ||
      ((NAN(fStack_18) || NAN(*(float *)(iVar2 + 8))) == (fStack_18 == *(float *)(iVar2 + 8)))) ||
     ((NAN(fStack_8) || NAN(*(float *)(iVar2 + 0xc))) == (fStack_8 == *(float *)(iVar2 + 0xc)))) {
    iVar3 = 0;
    if ((*(int *)(param_1 + 0x1a8) != 0) &&
       (((NAN(fVar1) == (fVar1 == 0.0) ||
         (NAN(*(float *)(iVar2 + 8)) == (*(float *)(iVar2 + 8) == 0.0))) ||
        (NAN(*(float *)(iVar2 + 0xc)) == (*(float *)(iVar2 + 0xc) == 0.0))))) {
      iVar3 = FUN_00c164f0();
    }
    LOCK();
    *(undefined4 *)(param_1 + 0x208) = 0xfffffffe;
    UNLOCK();
    (**(code **)(**(int **)(param_1 + 0x1ac) + 0x10))(&fStack_1c);
    iVar2 = *(int *)(param_1 + 0x1a8);
    if (iVar2 != 0) {
      FUN_00c19d80();
      FUN_00bbf330(param_1);
      FUN_00bbf640(param_1);
      iVar2 = *(int *)(param_1 + 0x1a8);
    }
    *(undefined *)(param_1 + 0x229) = 1;
    *(undefined4 *)(param_1 + 0x1e8) = 0;
    if ((iVar2 != 0) && (iVar2 = FUN_00c164f0(), iVar2 != iVar3)) {
      FUN_00bbf790(param_1);
    }
  }
  return;
}



/* FUNCTION 27499 ; VA 0x00c18fe0 ; FUN_00c18fe0 */

void __thiscall FUN_00c18fe0(int param_1,uint param_2)

{
  if (param_2 != *(byte *)(param_1 + 0x22e)) {
    *(char *)(param_1 + 0x22e) = (char)param_2;
    *(undefined4 *)(param_1 + 0x1e8) = 0;
    if (*(int *)(param_1 + 0x1a8) != 0) {
      FUN_00bbf790();
      return;
    }
  }
  return;
}


