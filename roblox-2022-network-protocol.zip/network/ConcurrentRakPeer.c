// ConcurrentRakPeer -- 2022 Studio + full PDB
// tier 3, 10 functions


// Address: 0x1410af7e0 | Name: ??0ConcurrentRakPeer@Network@RBX@@QEAA@PEAVRakPeerInterface@RakNet@@PEAVDataModel@2@@Z
RBX::Network::ConcurrentRakPeer *__fastcall RBX::Network::ConcurrentRakPeer::ConcurrentRakPeer(
        RBX::Network::ConcurrentRakPeer *this,
        RBX::Graphics::TextureVulkan::DownloadBuffer *peer,
        RBX::DataModel *dataModel)
{
  RBX::Network::ConcurrentRakPeer::StatsUpdateJob *updated; // rdi
  std::_Ref_count_base *v7; // rax
  RBX::Time *p_startTime; // rcx
  RBX::Network::ConcurrentRakPeer::PacketJob *v9; // rax
  std::_Ref_count_base *Rep; // rcx
  RBX::Network::ConcurrentRakPeer::PacketJob *v11; // rax
  RBX::Network::ConcurrentRakPeer::StatsUpdateJob *v12; // rax
  std::_Ref_count_base *v13; // rcx
  std::_Ref_count_base *v14; // rcx
  std::_Ref_count_base *v15; // rcx
  std::shared_ptr<RakNet::RakPeerInterface> v17; // [rsp+20h] [rbp-48h] BYREF
  std::shared_ptr<RakNet::RakPeerInterface> v18; // [rsp+30h] [rbp-38h] BYREF
  std::shared_ptr<RBX::TaskScheduler::Job> v19; // [rsp+40h] [rbp-28h] BYREF
  std::shared_ptr<RBX::TaskScheduler::Job> v20; // [rsp+50h] [rbp-18h] BYREF
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> v22; // [rsp+A8h] [rbp+40h] BYREF
  void *v23; // [rsp+B0h] [rbp+48h]

  updated = nullptr; /*0x1410af7fd*/
  this->peer._Ptr = nullptr; /*0x1410af7ff*/
  this->peer._Rep = nullptr; /*0x1410af802*/
  v22._Ptr = peer; /*0x1410af806*/
  __wind /*0xf1c0000000000058*/
  {
    v7 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x1410af80d*/
    v23 = v7; /*0x1410af812*/
    if ( v7 != nullptr ) /*0x1410af819*/
    {
      *v7 = 0; /*0x1410af81e*/
      v7->_Uses = 1; /*0x1410af821*/
      v7->_Weaks = 1; /*0x1410af828*/
      v7->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RakNet::RakPeerInterface>::`vftable'; /*0x1410af836*/
      v7[1].__vftable = (std::_Ref_count_base_vtbl *)peer; /*0x1410af839*/
    }
    else
    {
      v7 = nullptr; /*0x1410af83f*/
    }
    this->peer._Ptr = (RakNet::RakPeerInterface *)peer; /*0x1410af842*/
    this->peer._Rep = v7; /*0x1410af845*/
    this->packetJob._Ptr = nullptr; /*0x1410af849*/
    this->packetJob._Rep = nullptr; /*0x1410af84d*/
    this->statsUpdateJob._Ptr = nullptr; /*0x1410af851*/
    this->statsUpdateJob._Rep = nullptr; /*0x1410af855*/
    this->dataModel = dataModel; /*0x1410af859*/
    this->defaultMeter.count = 0; /*0x1410af85d*/
    p_startTime = &this->defaultMeter.startTime; /*0x1410af861*/
  }
  __unwind
  {
    RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: &v22); /*0xf1c0000000000068*/
  }
  __wind /*0xf1c0000000000070*/
  {
    __wind /*0xf1c0000000000078*/
    {
      __wind /*0xf1c0000000000080*/
      {
        RBX::Time::nowFast(result: p_startTime); /*0x1410af865*/
        v9 = (RBX::Network::ConcurrentRakPeer::PacketJob *)operator new(size: 0x1B0u); /*0x1410af86f*/
        v23 = v9; /*0x1410af877*/
        __wind /*0xf1c000000000004c*/
        {
          if ( v9 != nullptr ) /*0x1410af87e*/
          {
            v17 = 0; /*0x1410af883*/
            Rep = this->peer._Rep; /*0x1410af888*/
            if ( Rep != nullptr ) /*0x1410af88f*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410af891*/
              Rep = this->peer._Rep; /*0x1410af895*/
            }
            v17._Ptr = this->peer._Ptr; /*0x1410af89c*/
            v17._Rep = Rep; /*0x1410af8a0*/
            v11 = RBX::Network::ConcurrentRakPeer::PacketJob::PacketJob(this: v9, peer: &v17, dataModel); /*0x1410af8ae*/
          }
          else
          {
            v11 = nullptr; /*0x1410af8b5*/
          }
        }
        __unwind
        {
          operator delete(ptr: v23); /*0x1431ec5a5*/
        }
        std::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob>::reset<RBX::Network::ConcurrentRakPeer::PacketJob>( /*0x1410af8bf*/
          this: &this->packetJob,
          _Px: v11);
        v12 = (RBX::Network::ConcurrentRakPeer::StatsUpdateJob *)operator new(size: 0x220u); /*0x1410af8c9*/
        v23 = v12; /*0x1410af8d1*/
        __wind /*0xf1c0000000000034*/
        {
          if ( v12 != nullptr ) /*0x1410af8d8*/
          {
            v18 = 0; /*0x1410af8dd*/
            v13 = this->peer._Rep; /*0x1410af8e2*/
            if ( v13 != nullptr ) /*0x1410af8e9*/
            {
              _InterlockedIncrement((volatile signed __int32 *)&v13->_Uses); /*0x1410af8eb*/
              v13 = this->peer._Rep; /*0x1410af8ef*/
            }
            v18._Ptr = this->peer._Ptr; /*0x1410af8f6*/
            v18._Rep = v13; /*0x1410af8fa*/
            updated = RBX::Network::ConcurrentRakPeer::StatsUpdateJob::StatsUpdateJob(this: v12, peer: &v18, dataModel); /*0x1410af90d*/
          }
        }
        __unwind
        {
          operator delete(ptr: v23); /*0x1431ec5c5*/
        }
        std::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob>::reset<RBX::Network::ConcurrentRakPeer::StatsUpdateJob>( /*0x1410af917*/
          this: &this->statsUpdateJob,
          _Px: updated);
        v19 = 0; /*0x1410af91f*/
        v14 = this->packetJob._Rep; /*0x1410af924*/
        if ( v14 != nullptr ) /*0x1410af92b*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v14->_Uses); /*0x1410af92d*/
          v14 = this->packetJob._Rep; /*0x1410af931*/
        }
        v19._Ptr = this->packetJob._Ptr; /*0x1410af939*/
        v19._Rep = v14; /*0x1410af93d*/
        RBX::TaskScheduler::add(job: &v19); /*0x1410af945*/
        v20 = 0; /*0x1410af94d*/
        v15 = this->statsUpdateJob._Rep; /*0x1410af952*/
        if ( v15 != nullptr ) /*0x1410af959*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v15->_Uses); /*0x1410af95b*/
          v15 = this->statsUpdateJob._Rep; /*0x1410af95f*/
        }
        v20._Ptr = this->statsUpdateJob._Ptr; /*0x1410af967*/
        v20._Rep = v15; /*0x1410af96b*/
        RBX::TaskScheduler::add(job: &v20); /*0x1410af973*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->statsUpdateJob); /*0x1431bf0bb*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->packetJob); /*0x14316801b*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>((std::shared_ptr<RBX::File> *)this); /*0xf1c00000000000a8*/
  }
  return this; /*0x1410af97c*/
}

// Address: 0x1410b0240 | Name: ??1ConcurrentRakPeer@Network@RBX@@QEAA@XZ
void __fastcall RBX::Network::ConcurrentRakPeer::~ConcurrentRakPeer(RBX::Network::ConcurrentRakPeer *this)
{
  std::_Ref_count_base *Rep; // rbx
  RBX::Network::ConcurrentRakPeer::PacketJob *Ptr; // rax
  std::_Ref_count_base *v4; // rbx
  RBX::Network::ConcurrentRakPeer::StatsUpdateJob *v5; // rax
  std::_Ref_count_base *v6; // rbx
  std::_Ref_count_base *v7; // rbx
  std::_Ref_count_base *v8; // rbx
  std::shared_ptr<RBX::TaskScheduler::Job> v9; // [rsp+20h] [rbp-A8h] BYREF
  std::shared_ptr<RBX::TaskScheduler::Job> v10; // [rsp+30h] [rbp-98h] BYREF
  std::function<void __cdecl(void)> v11; // [rsp+40h] [rbp-88h] BYREF
  std::function<void __cdecl(void)> v12; // [rsp+80h] [rbp-48h] BYREF

  Rep = this->packetJob._Rep; /*0x1410b0255*/
  if ( Rep != nullptr ) /*0x1410b025c*/
  {
    _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410b025e*/
    Rep = this->packetJob._Rep; /*0x1410b0262*/
  }
  Ptr = this->packetJob._Ptr; /*0x1410b0266*/
  v11._Mystorage._Ptrs[7] = nullptr; /*0x1410b026a*/
  if ( Rep != nullptr ) /*0x1410b0276*/
    _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410b0278*/
  v9._Ptr = Ptr; /*0x1410b027c*/
  v9._Rep = Rep; /*0x1410b0281*/
  RBX::TaskScheduler::remove(job: &v9, joinJob: false, callbackPing: &v11); /*0x1410b0292*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b02ab*/
  {
    Rep->_Destroy(this: Rep); /*0x1410b02b3*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b02bf*/
      Rep->_Delete_this(this: Rep); /*0x1410b02c7*/
  }
  v4 = this->statsUpdateJob._Rep; /*0x1410b02ca*/
  if ( v4 != nullptr ) /*0x1410b02d1*/
  {
    _InterlockedIncrement((volatile signed __int32 *)&v4->_Uses); /*0x1410b02d3*/
    v4 = this->statsUpdateJob._Rep; /*0x1410b02d7*/
  }
  v5 = this->statsUpdateJob._Ptr; /*0x1410b02db*/
  v12._Mystorage._Ptrs[7] = nullptr; /*0x1410b02df*/
  if ( v4 != nullptr ) /*0x1410b02ee*/
    _InterlockedIncrement((volatile signed __int32 *)&v4->_Uses); /*0x1410b02f0*/
  v10._Ptr = v5; /*0x1410b02f4*/
  v10._Rep = v4; /*0x1410b02f9*/
  RBX::TaskScheduler::remove(job: &v10, joinJob: false, callbackPing: &v12); /*0x1410b030d*/
  if ( v4 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b0321*/
  {
    v4->_Destroy(this: v4); /*0x1410b0329*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b0335*/
      v4->_Delete_this(this: v4); /*0x1410b033d*/
  }
  v6 = this->statsUpdateJob._Rep; /*0x1410b0340*/
  if ( v6 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v6->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b0353*/
  {
    v6->_Destroy(this: v6); /*0x1410b035b*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v6->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b0367*/
      v6->_Delete_this(this: v6); /*0x1410b036f*/
  }
  v7 = this->packetJob._Rep; /*0x1410b0372*/
  if ( v7 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b0385*/
  {
    v7->_Destroy(this: v7); /*0x1410b038d*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b0399*/
      v7->_Delete_this(this: v7); /*0x1410b03a1*/
  }
  v8 = this->peer._Rep; /*0x1410b03a4*/
  if ( v8 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v8->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b03b7*/
  {
    v8->_Destroy(this: v8); /*0x1410b03bf*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v8->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b03c9*/
      v8->_Delete_this(this: v8); /*0x1410b03d1*/
  }
}

// Address: 0x1410b05e0 | Name: ??_EPacketJob@ConcurrentRakPeer@Network@RBX@@UEAAPEAXI@Z
RBX::Network::ConcurrentRakPeer::PacketJob *__fastcall RBX::Network::ConcurrentRakPeer::PacketJob::`vector deleting destructor'(
        RBX::Network::ConcurrentRakPeer::PacketJob *this,
        char a2)
{
  std::_Ref_count_base *Rep; // rcx

  Rep = this->peer._Rep; /*0x1410b05ef*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b0608*/
    Rep->_Delete_this(this: Rep); /*0x1410b060d*/
  std::deque<rbx::implementation::timestamped_safe_queue_item<RBX::Network::ConcurrentRakPeer::PacketJob::SendData>>::~deque<rbx::implementation::timestamped_safe_queue_item<RBX::Network::ConcurrentRakPeer::PacketJob::SendData>>(this: &this->sendQueue.queue); /*0x1410b0617*/
  RBX::TaskScheduler::Job::~Job(this); /*0x1410b061f*/
  if ( (a2 & 1) != 0 ) /*0x1410b0628*/
    operator delete(ptr: this); /*0x1410b0632*/
  return this; /*0x1410b063a*/
}

// Address: 0x1410b0650 | Name: ??_EStatsUpdateJob@ConcurrentRakPeer@Network@RBX@@UEAAPEAXI@Z
RBX::Network::ConcurrentRakPeer::StatsUpdateJob *__fastcall RBX::Network::ConcurrentRakPeer::StatsUpdateJob::`vector deleting destructor'(
        RBX::Network::ConcurrentRakPeer::StatsUpdateJob *this,
        char a2)
{
  std::_Ref_count_base *Rep; // rcx
  void *v5; // rcx

  Rep = this->peer._Rep; /*0x1410b065f*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b0678*/
    Rep->_Delete_this(this: Rep); /*0x1410b067d*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,std::function<void (RBX::Network::ConnectionStats const &)>>>,RakNet::SystemAddress,std::function<void (RBX::Network::ConnectionStats const &)>,boost::hash<RakNet::SystemAddress>,std::equal_to<RakNet::SystemAddress>>>::~table<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,std::function<void (RBX::Network::ConnectionStats const &)>>>,RakNet::SystemAddress,std::function<void (RBX::Network::ConnectionStats const &)>,boost::hash<RakNet::SystemAddress>,std::equal_to<RakNet::SystemAddress>>>(this: &this->updateCallbackMap_deprecated.table_); /*0x1410b0687*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>>,RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>>::~table<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>>,RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>>(this: &this->statsMap.table_); /*0x1410b0693*/
  v5 = (void *)_InterlockedExchange64((volatile __int64 *)&this->mapMutex.event, 0); /*0x1410b069a*/
  if ( v5 != nullptr ) /*0x1410b06a4*/
    CloseHandle(hObject: v5); /*0x1410b06a6*/
  RBX::TaskScheduler::Job::~Job(this); /*0x1410b06af*/
  if ( (a2 & 1) != 0 ) /*0x1410b06b8*/
    operator delete(ptr: this); /*0x1410b06c2*/
  return this; /*0x1410b06ca*/
}

// Address: 0x1410b06e0 | Name: ?GetBandwidthExceeded@ConcurrentRakPeer@Network@RBX@@QEAANUSystemAddress@RakNet@@@Z
double __fastcall RBX::Network::ConcurrentRakPeer::GetBandwidthExceeded(
        RBX::Network::ConcurrentRakPeer *this,
        const RakNet::SystemAddress *systemAddress)
{
  RBX::Network::ConcurrentRakPeer::StatsUpdateJob *Ptr; // rbx
  bool v5; // zf
  boost::mutex *p_mapMutex; // rbx
  std::pair<RakNet::SystemAddress const ,RBX::Network::ConnectionStats> *v7; // rax
  double averageValue; // xmm6_8
  signed __int32 v9; // eax
  HANDLE event; // rax
  __int64 v11; // rcx
  double result; // xmm0_8
  const boost::lock_error *v13; // rax
  __int64 v14; // [rsp+0h] [rbp-98h] BYREF
  boost::unique_lock<boost::mutex> lock; // [rsp+20h] [rbp-78h] BYREF
  boost::lock_error v16; // [rsp+30h] [rbp-68h] BYREF

  Ptr = this->statsUpdateJob._Ptr; /*0x1410b06fd*/
  v5 = &Ptr->mapMutex == nullptr; /*0x1410b0701*/
  p_mapMutex = &Ptr->mapMutex; /*0x1410b0701*/
  lock.m = p_mapMutex; /*0x1410b0708*/
  lock.is_locked = false; /*0x1410b070c*/
  if ( v5 ) /*0x1410b0710*/
  {
    v13 = boost::lock_error::lock_error(this: &v16, ev: 1, what_arg: "boost unique_lock has no mutex"); /*0x1410b0797*/
    __wind /*0xf1c0000000000014*/
    {
      boost::throw_exception<boost::lock_error>(e: v13); /*0x1410b07a0*/
    }
    __unwind
    {
      boost::thread_resource_error::~thread_resource_error(this: &v16); /*0xf1c0000000000024*/
    }
  }
  boost::detail::basic_timed_mutex::lock(this: p_mapMutex); /*0x1410b0715*/
  __wind /*0xf1c0000000000038*/
  {
    lock.is_locked = true; /*0x1410b071a*/
    v7 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>>,RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>>::operator[]( /*0x1410b072d*/
           this: &this->statsUpdateJob._Ptr->statsMap.table_,
           k: systemAddress);
  }
  __unwind
  {
    boost::unique_lock<boost::mutex>::~unique_lock<boost::mutex>(this: &lock); /*0xf1c0000000000048*/
  }
  __wind /*0xf1c0000000000050*/
  {
    averageValue = v7->second.averageBandwidthExceeded.averageValue; /*0x1410b0732*/
    v9 = _InterlockedExchangeAdd(&p_mapMutex->active_count, 0x80000000); /*0x1410b073f*/
    if ( (v9 & 0x40000000) == 0 && v9 != 0x80000000 && !_interlockedbittestandset(&p_mapMutex->active_count, 0x1Eu) ) /*0x1410b0755*/
    {
      event = boost::detail::basic_timed_mutex::get_event(this: p_mapMutex); /*0x1410b075a*/
      SetEvent(hEvent: event); /*0x1410b0762*/
    }
    result = averageValue; /*0x1410b0769*/
  }
  __unwind
  {
    __std_terminate(a1: v11, a2: &v14); /*0x142f39fa8*/
  }
  return result; /*0x1410b076c*/
}

// Address: 0x1410b07b0 | Name: ?GetBufferHealth@ConcurrentRakPeer@Network@RBX@@QEAANXZ
double __fastcall RBX::Network::ConcurrentRakPeer::GetBufferHealth(RBX::Network::ConcurrentRakPeer *this)
{
  boost::mutex *p_mapMutex; // rbx
  double averageValue; // xmm6_8
  signed __int32 v4; // eax
  HANDLE event; // rax
  __int64 v6; // rcx
  const boost::lock_error *v8; // rax
  __int64 v9; // [rsp+0h] [rbp-88h] BYREF
  boost::lock_error v10; // [rsp+20h] [rbp-68h] BYREF

  p_mapMutex = &this->statsUpdateJob._Ptr->mapMutex; /*0x1410b07c9*/
  if ( this->statsUpdateJob._Ptr == (RBX::Network::ConcurrentRakPeer::StatsUpdateJob *)-360LL ) /*0x1410b07d0*/
  {
    v8 = boost::lock_error::lock_error(this: &v10, ev: 1, what_arg: "boost unique_lock has no mutex"); /*0x1410b083f*/
    __wind /*0xf1c0000000000014*/
    {
      boost::throw_exception<boost::lock_error>(e: v8); /*0x1410b0848*/
    }
    __unwind
    {
      boost::thread_resource_error::~thread_resource_error(this: &v10); /*0xf1c0000000000024*/
    }
  }
  boost::detail::basic_timed_mutex::lock(this: p_mapMutex); /*0x1410b07d5*/
  averageValue = this->statsUpdateJob._Ptr->bufferHealth.averageValue; /*0x1410b07de*/
  v4 = _InterlockedExchangeAdd(&p_mapMutex->active_count, 0x80000000); /*0x1410b07eb*/
  if ( (v4 & 0x40000000) == 0 && v4 != 0x80000000 && !_interlockedbittestandset(&p_mapMutex->active_count, 0x1Eu) ) /*0x1410b0801*/
  {
    __wind /*0xf1c0000000000038*/
    {
      event = boost::detail::basic_timed_mutex::get_event(this: p_mapMutex); /*0x1410b0806*/
      SetEvent(hEvent: event); /*0x1410b080e*/
    }
    __unwind
    {
      __std_terminate(a1: v6, a2: &v9); /*0x142f39fa8*/
    }
  }
  return averageValue; /*0x1410b0818*/
}

// Address: 0x1410b0850 | Name: ?GetCongestionControlExceeded@ConcurrentRakPeer@Network@RBX@@QEAANUSystemAddress@RakNet@@@Z
double __fastcall RBX::Network::ConcurrentRakPeer::GetCongestionControlExceeded(
        RBX::Network::ConcurrentRakPeer *this,
        const RakNet::SystemAddress *systemAddress)
{
  boost::mutex *p_mapMutex; // rbx
  double averageValue; // xmm6_8
  signed __int32 v6; // eax
  HANDLE event; // rax
  const boost::lock_error *v9; // rax
  boost::lock_error v10; // [rsp+30h] [rbp-68h] BYREF

  p_mapMutex = &this->statsUpdateJob._Ptr->mapMutex; /*0x1410b0871*/
  if ( this->statsUpdateJob._Ptr == (RBX::Network::ConcurrentRakPeer::StatsUpdateJob *)-360LL ) /*0x1410b0880*/
  {
    v9 = boost::lock_error::lock_error(this: &v10, ev: 1, what_arg: "boost unique_lock has no mutex"); /*0x1410b0907*/
    boost::throw_exception<boost::lock_error>(e: v9); /*0x1410b0910*/
  }
  boost::detail::basic_timed_mutex::lock(this: p_mapMutex); /*0x1410b0885*/
  averageValue = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>>,RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>>::operator[]( /*0x1410b08a2*/
                   this: &this->statsUpdateJob._Ptr->statsMap.table_,
                   k: systemAddress)->second.averageCongestionControlExceeded.averageValue;
  v6 = _InterlockedExchangeAdd(&p_mapMutex->active_count, 0x80000000); /*0x1410b08af*/
  if ( (v6 & 0x40000000) == 0 && v6 != 0x80000000 && !_interlockedbittestandset(&p_mapMutex->active_count, 0x1Eu) ) /*0x1410b08c5*/
  {
    event = boost::detail::basic_timed_mutex::get_event(this: p_mapMutex); /*0x1410b08ca*/
    SetEvent(hEvent: event); /*0x1410b08d2*/
  }
  return averageValue; /*0x1410b08dc*/
}

// Address: 0x1410b0920 | Name: ?Send@ConcurrentRakPeer@Network@RBX@@QEAAXV?$shared_ptr@$$CBVNetworkStream@Network@RBX@@@std@@W4PacketPriority@@W4PacketReliability@@DUSystemAddress@RakNet@@_NPEAUTimeIntervalMeter@23@4@Z
void __fastcall RBX::Network::ConcurrentRakPeer::Send(
        RBX::Network::ConcurrentRakPeer *this,
        std::shared_ptr<RBX::File> *bitStream,
        PacketPriority priority,
        PacketReliability reliability,
        char orderingChannel,
        RakNet::SystemAddress *systemAddress,
        bool broadcast,
        RBX::Network::TimeIntervalMeter *meter,
        bool forceDirectSend)
{
  unsigned int v13; // eax
  std::_Ref_count_base *v14; // rcx
  std::_Ref_count_base *v15; // rbx
  std::_Ref_count_base_vtbl *v16; // rax
  const RBX::Network::NetworkStream *Ptr; // rcx
  std::_Ref_count_base *Rep; // rax
  RakNet::RakPeerInterface *v19; // rdi
  unsigned int (__fastcall *Send)(RakNet::RakPeerInterface *, std::shared_ptr<RakNet::AbstractBitStream const > *, PacketPriority, PacketReliability, char, const RakNet::AddressOrGUID *__struct_ptr, bool, unsigned int); // rbx
  std::_Ref_count_base *v21; // rbx
  std::_Ref_count_base *v22; // rbx
  std::shared_ptr<RakNet::AbstractBitStream const > sendingBytestream; // [rsp+40h] [rbp-71h] BYREF
  RakNet::RakNetGUID v24; // [rsp+50h] [rbp-61h] BYREF
  RakNet::SystemAddress v25; // [rsp+60h] [rbp-51h] BYREF
  RBX::Network::ConcurrentRakPeer::PacketJob::SendData data; // [rsp+80h] [rbp-31h] BYREF

  __wind /*0xf1c0000000000040*/
  {
    v13 = ((__int64 (__fastcall *)(RBX::File *))bitStream->_Ptr->processRemoteEvent)(a1: bitStream->_Ptr); /*0x1410b0959*/
    if ( meter != nullptr ) /*0x1410b0961*/
      meter->count += v13; /*0x1410b0963*/
    else
      this->defaultMeter.count += v13; /*0x1410b0968*/
    if ( DFFlag::IntegrateSendInPeer.value || forceDirectSend ) /*0x1410b0982*/
    {
      Ptr = (const RBX::Network::NetworkStream *)bitStream->_Ptr; /*0x1410b0a27*/
      sendingBytestream = 0; /*0x1410b0a2d*/
      Rep = bitStream->_Rep; /*0x1410b0a32*/
      if ( Rep != nullptr ) /*0x1410b0a39*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410b0a3b*/
        Rep = bitStream->_Rep; /*0x1410b0a3f*/
      }
      __wind /*0xf1c000000000001c*/
      {
        sendingBytestream._Ptr = Ptr; /*0x1410b0a43*/
        sendingBytestream._Rep = Rep; /*0x1410b0a47*/
        v19 = this->peer._Ptr; /*0x1410b0a4b*/
        Send = v19->Send; /*0x1410b0a51*/
        RakNet::RakNetGUID::RakNetGUID(this: &v24); /*0x1410b0a5c*/
        RakNet::SystemAddress::SystemAddress(this: &v25); /*0x1410b0a65*/
        v24 = RakNet::UNASSIGNED_RAKNET_GUID_27; /*0x1410b0a71*/
        RakNet::SystemAddress::operator=(this: &v25, input: systemAddress); /*0x1410b0a88*/
        Send( /*0x1410b0abb*/
          this: v19,
          a2: &sendingBytestream,
          a3: priority,
          a4: reliability,
          a5: orderingChannel,
          a6: (const RakNet::AddressOrGUID *)&v24,
          a7: broadcast,
          a8: 0);
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&sendingBytestream); /*0xf1c0000000000014*/
      }
      v21 = sendingBytestream._Rep; /*0x1410b0abe*/
      if ( sendingBytestream._Rep == nullptr ) /*0x1410b0ac5*/
        goto LABEL_20; /*0x1410b0ac5*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&sendingBytestream._Rep->_Uses, 0xFFFFFFFF) != 1 ) /*0x1410b0ad1*/
        goto LABEL_20; /*0x1410b0ad1*/
      v21->_Destroy(this: v21); /*0x1410b0ad9*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v21->_Weaks, 0xFFFFFFFF) != 1 ) /*0x1410b0ae5*/
        goto LABEL_20; /*0x1410b0ae5*/
      v16 = v21->__vftable; /*0x1410b0ae7*/
    }
    else
    {
      v14 = bitStream->_Rep; /*0x1410b0988*/
      if ( v14 != nullptr ) /*0x1410b098f*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v14->_Uses); /*0x1410b0991*/
        v14 = bitStream->_Rep; /*0x1410b0995*/
      }
      __wind /*0xf1c0000000000034*/
      {
        data.bitStream._Ptr = (const RBX::Network::NetworkStream *)bitStream->_Ptr; /*0x1410b099c*/
        data.bitStream._Rep = v14; /*0x1410b09a0*/
        data.priority = priority; /*0x1410b09a4*/
        data.reliability = reliability; /*0x1410b09a8*/
        data.orderingChannel = orderingChannel; /*0x1410b09b0*/
        data.systemAddress = *systemAddress; /*0x1410b09ba*/
        data.broadcast = broadcast; /*0x1410b09ca*/
        rbx::timestamped_safe_queue<RBX::Network::ConcurrentRakPeer::PacketJob::SendData>::push( /*0x1410b09dc*/
          this: &this->packetJob._Ptr->sendQueue,
          value: &data);
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&data); /*0xf1c000000000002c*/
      }
      if ( data.bitStream._Rep == nullptr ) /*0x1410b09e9*/
        goto LABEL_20; /*0x1410b09e9*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&data.bitStream._Rep->_Uses, 0xFFFFFFFF) != 1 ) /*0x1410b09f9*/
        goto LABEL_20; /*0x1410b09f9*/
      v15 = data.bitStream._Rep; /*0x1410b09ff*/
      data.bitStream._Rep->_Destroy(this: data.bitStream._Rep); /*0x1410b0a09*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v15->_Weaks, 0xFFFFFFFF) != 1 ) /*0x1410b0a15*/
        goto LABEL_20; /*0x1410b0a15*/
      v16 = data.bitStream._Rep->__vftable; /*0x1410b0a1f*/
    }
    ((void (*)(void))v16->_Delete_this)(); /*0x1410b0aed*/
LABEL_20:
    v22 = bitStream->_Rep; /*0x1410b0af1*/
    if ( v22 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410b0b04*/
    {
      v22->_Destroy(this: v22); /*0x1410b0b0c*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410b0b16*/
        v22->_Delete_this(this: v22); /*0x1410b0b1e*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: bitStream); /*0xf1c0000000000008*/
  }
}

// Address: 0x1410b0d20 | Name: ?addStats@ConcurrentRakPeer@Network@RBX@@QEAAXUSystemAddress@RakNet@@HV?$function@$$A6AXAEBUConnectionStats@Network@RBX@@@Z@std@@@Z
void __fastcall RBX::Network::ConcurrentRakPeer::addStats(
        RBX::Network::ConcurrentRakPeer *this,
        RakNet::SystemAddress *address,
        int rssIndex,
        std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *callback)
{
  std::_Func_base<void,RBX::Network::ConnectionStats const &> *v8; // rcx
  RBX::Network::ConnectionStats *v9; // rbx
  RakNet::RakNetStatistics *p_rakStats; // rbx
  RakNet::RakNetStatistics *v11; // rax
  __int64 i; // rcx
  std::function<void __cdecl(RBX::Network::ConnectionStats const &)> *p_callback; // rdx
  RBX::Network::ConcurrentRakPeer::StatsUpdateJob *Ptr; // r9
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v17; // ett
  RakNet::RakPeerInterface *v18; // r8
  RakNet::RakPeerInterface *v19; // rbx
  RBX::Network::ConcurrentRakPeer::StatsUpdateJob *v20; // rbx
  bool v21; // zf
  boost::mutex *p_mapMutex; // rbx
  std::_Func_base<void,RBX::Network::ConnectionStats const &> *v23; // rcx
  __int64 v24; // rdx
  __int64 v25; // rcx
  signed __int32 v26; // eax
  HANDLE event; // rax
  std::function<void __cdecl(RBX::Network::ConnectionStats const &)> *v28; // rdx
  std::_Func_base<void,RBX::Network::ConnectionStats const &> *v29; // rcx
  const boost::lock_error *v30; // rax
  __int64 v31; // [rsp+0h] [rbp-100h] BYREF
  RakNet::RakPeerInterface *peer[2]; // [rsp+20h] [rbp-E0h] BYREF
  boost::unique_lock<boost::mutex> lock; // [rsp+30h] [rbp-D0h] BYREF
  std::function<void __cdecl(RBX::Network::ConnectionStats const &)> v34; // [rsp+40h] [rbp-C0h] BYREF
  std::pair<boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<RakNet::SystemAddress const ,RBX::Network::ConnectionStats> > >,bool> result; // [rsp+80h] [rbp-80h] BYREF
  std::pair<RakNet::SystemAddress const ,RBX::Network::ConnectionStats> p; // [rsp+90h] [rbp-70h] BYREF
  boost::lock_error v37; // [rsp+3A0h] [rbp+2A0h] BYREF
  RBX::Network::ConnectionStats v38; // [rsp+3E8h] [rbp+2E8h] BYREF

  __wind /*0xf1c00000000000b0*/
  {
    __wind /*0xf1c00000000000b8*/
    {
      v34._Mystorage._Ptrs[7] = nullptr; /*0x1410b0d5b*/
      v8 = (std::_Func_base<void,RBX::Network::ConnectionStats const &> *)callback->_Mystorage._Ptrs[7]; /*0x1410b0d60*/
      if ( v8 != nullptr ) /*0x1410b0d67*/
        v34._Mystorage._Ptrs[7] = (std::_Func_base<void,RBX::Network::ConnectionStats const &> *)v8->_Copy( /*0x1410b0d73*/
                                                                                                   this: v8,
                                                                                                   a2: &v34);
    }
    __unwind
    {
      std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&v34); /*0xf1c0000000000088*/
    }
    v9 = RBX::Network::ConnectionStats::ConnectionStats(this: &v38, raknetindex: rssIndex, call: &v34); /*0x1410b0d8b*/
    p.first = *address; /*0x1410b0d91*/
    p.second.metaData.rssIndex = v9->metaData.rssIndex; /*0x1410b0d9f*/
    p.second.metaData.callback._Mystorage._Ptrs[7] = nullptr; /*0x1410b0da2*/
    std::_Func_class<void,int,enum EmbeddedWebBrowser::Status_e,std::string const &>::_Reset_move( /*0x1410b0dae*/
      this: (std::_Func_class<void,RBX::LSP::SnippetState> *)&p.second.metaData.callback,
      _Right: (std::_Func_base<void,RBX::LSP::SnippetState> *)&v9->metaData.callback);
    p.second.mtuSize = v9->mtuSize; /*0x1410b0db6*/
    p.second.averagePing = v9->averagePing; /*0x1410b0dbc*/
    p.second.lastPing = v9->lastPing; /*0x1410b0dc2*/
    p.second.lowestPing = v9->lowestPing; /*0x1410b0dc8*/
    p.second.maxPacketloss = v9->maxPacketloss; /*0x1410b0dd0*/
    p.second.lastBcsQueueTime = v9->lastBcsQueueTime; /*0x1410b0dd8*/
    p.second.bufferHealth = v9->bufferHealth; /*0x1410b0ddf*/
    p.second.prevBufferSize = v9->prevBufferSize; /*0x1410b0dfe*/
    p.second.averageBandwidthExceeded = v9->averageBandwidthExceeded; /*0x1410b0e08*/
    p.second.averageCongestionControlExceeded = v9->averageCongestionControlExceeded; /*0x1410b0e2b*/
    p.second.kiloBytesSentPerSecond = v9->kiloBytesSentPerSecond; /*0x1410b0e51*/
    p.second.kiloBytesReceivedPerSecond = v9->kiloBytesReceivedPerSecond; /*0x1410b0e7d*/
    p_rakStats = &v9->rakStats; /*0x1410b0ea2*/
    v11 = &p.second.rakStats; /*0x1410b0ea9*/
    for ( i = 3; i != 0; --i ) /*0x1410b0eb0*/
    {
      *(_OWORD *)v11->valueOverLastSecond = *(_OWORD *)p_rakStats->valueOverLastSecond; /*0x1410b0ec3*/
      *(_OWORD *)&v11->valueOverLastSecond[2] = *(_OWORD *)&p_rakStats->valueOverLastSecond[2]; /*0x1410b0eca*/
      *(_OWORD *)&v11->valueOverLastSecond[4] = *(_OWORD *)&p_rakStats->valueOverLastSecond[4]; /*0x1410b0ed2*/
      *(_OWORD *)&v11->valueOverLastSecond[6] = *(_OWORD *)&p_rakStats->valueOverLastSecond[6]; /*0x1410b0eda*/
      *(_OWORD *)&v11->runningTotal[1] = *(_OWORD *)&p_rakStats->runningTotal[1]; /*0x1410b0ee2*/
      *(_OWORD *)&v11->runningTotal[3] = *(_OWORD *)&p_rakStats->runningTotal[3]; /*0x1410b0eea*/
      *(_OWORD *)&v11->runningTotal[5] = *(_OWORD *)&p_rakStats->runningTotal[5]; /*0x1410b0ef2*/
      v11 = (RakNet::RakNetStatistics *)((char *)v11 + 128); /*0x1410b0ef6*/
      *(_OWORD *)&v11[-1].perSecTxBwData.txBwInfluencers.bwCappedDueToMaxPacketsInFlightCount = *(_OWORD *)&p_rakStats->connectionStartTime; /*0x1410b0f01*/
      p_rakStats = (RakNet::RakNetStatistics *)((char *)p_rakStats + 128); /*0x1410b0f05*/
    }
    *(_OWORD *)v11->valueOverLastSecond = *(_OWORD *)p_rakStats->valueOverLastSecond; /*0x1410b0f15*/
    *(_OWORD *)&v11->valueOverLastSecond[2] = *(_OWORD *)&p_rakStats->valueOverLastSecond[2]; /*0x1410b0f1c*/
    *(_OWORD *)&v11->valueOverLastSecond[4] = *(_OWORD *)&p_rakStats->valueOverLastSecond[4]; /*0x1410b0f24*/
    *(_OWORD *)&v11->valueOverLastSecond[6] = *(_OWORD *)&p_rakStats->valueOverLastSecond[6]; /*0x1410b0f2c*/
    if ( v38.metaData.callback._Mystorage._Ptrs[7] != nullptr ) /*0x1410b0f3a*/
    {
      p_callback = &v38.metaData.callback; /*0x1410b0f3f*/
      LOBYTE(p_callback) = v38.metaData.callback._Mystorage._Ptrs[7] != (std::_Func_base<void,RBX::Network::ConnectionStats const &> *)&v38.metaData.callback; /*0x1410b0f49*/
      v38.metaData.callback._Mystorage._Ptrs[7]->_Delete_this( /*0x1410b0f4c*/
        this: v38.metaData.callback._Mystorage._Ptrs[7],
        a2: (bool)p_callback);
      v38.metaData.callback._Mystorage._Ptrs[7] = nullptr; /*0x1410b0f4f*/
    }
    Ptr = this->statsUpdateJob._Ptr; /*0x1410b0f56*/
    *(_OWORD *)peer = 0; /*0x1410b0f5d*/
    Rep = Ptr->peer._Rep; /*0x1410b0f63*/
    if ( Rep != nullptr && (Uses = Rep->_Uses) != 0 ) /*0x1410b0f74*/
    {
      while ( 1 ) /*0x1410b0f83*/
      {
        v17 = Uses; /*0x1410b0f83*/
        Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x1410b0f83*/
        if ( v17 == Uses ) /*0x1410b0f88*/
          break; /*0x1410b0f88*/
        if ( Uses == 0 ) /*0x1410b0f90*/
          goto LABEL_12; /*0x1410b0f90*/
      }
      v18 = Ptr->peer._Ptr; /*0x1410b10be*/
      peer[0] = v18; /*0x1410b10c5*/
      v19 = (RakNet::RakPeerInterface *)Ptr->peer._Rep; /*0x1410b10ca*/
      peer[1] = v19; /*0x1410b10d1*/
    }
    else
    {
LABEL_12:
      v18 = peer[0]; /*0x1410b0f92*/
      v19 = peer[1]; /*0x1410b0f97*/
    }
    __wind /*0xf1c000000000009c*/
    {
      __wind /*0xf1c00000000000a4*/
      {
        if ( v18 != nullptr ) /*0x1410b0f9f*/
          RBX::Network::ConcurrentRakPeer::StatsUpdateJob::updateStats(this: Ptr, x: &p, peer: v18); /*0x1410b0fa8*/
        if ( v19 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v19[1], 0xFFFFFFFF) == 1 ) /*0x1410b0fc2*/
        {
          peer[1]->dtr_RakPeerInterface(this: peer[1]); /*0x1410b0fcf*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&peer[1][1].__vftable + 1, 0xFFFFFFFF) == 1 ) /*0x1410b0fd9*/
            ((void (__fastcall *)(RakNet::RakPeerInterface *))peer[1]->Startup)(a1: peer[1]); /*0x1410b0fe3*/
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)peer); /*0xf1c000000000007c*/
      }
      v20 = this->statsUpdateJob._Ptr; /*0x1410b0fe6*/
      v21 = &v20->mapMutex == nullptr; /*0x1410b0fea*/
      p_mapMutex = &v20->mapMutex; /*0x1410b0fea*/
      lock.m = p_mapMutex; /*0x1410b0ff1*/
      lock.is_locked = false; /*0x1410b0ff6*/
      if ( !v21 ) /*0x1410b0ffb*/
      {
        boost::detail::basic_timed_mutex::lock(this: p_mapMutex); /*0x1410b1004*/
        __eh34_enter_wind_state(2, 6); /*0xf1c0000000000070*/
        lock.is_locked = true; /*0x1410b1009*/
        boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>>,RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>>::emplace_impl<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats> const &>( /*0x1410b1025*/
          this: &this->statsUpdateJob._Ptr->statsMap.table_,
          &result,
          k: &p.first,
          <args_0>: &p);
        v23 = (std::_Func_base<void,RBX::Network::ConnectionStats const &> *)callback->_Mystorage._Ptrs[7]; /*0x1410b102a*/
        if ( v23 != nullptr ) /*0x1410b1031*/
        {
          if ( __eh34_unwind(6) ) /*0xf1c0000000000090*/
            goto unwind_state_6; /*0xf1c0000000000090*/
          __eh34_exit_wind_state(6, 2); /*0xf1c0000000000094*/
LABEL_36:
          __wind /*0xf1c000000000002c*/
          {
            v23->_Do_call(this: v23, a2: &p.second); /*0x1410b103e*/
            v26 = _InterlockedExchangeAdd(&p_mapMutex->active_count, 0x80000000); /*0x1410b1047*/
            if ( (v26 & 0x40000000) == 0 /*0x1410b105d*/
              && v26 != 0x80000000
              && !_interlockedbittestandset(&p_mapMutex->active_count, 0x1Eu) )
            {
              event = boost::detail::basic_timed_mutex::get_event(this: p_mapMutex); /*0x1410b1062*/
              SetEvent(hEvent: event); /*0x1410b106a*/
            }
          }
          __unwind
          {
            __std_terminate(a1: v25, a2: &v31); /*0x142f39fa8*/
          }
          goto LABEL_40; /*0xf1c0000000000038*/
        }
        std::_Xbad_function_call(); /*0x1410b10db*/
        if ( __eh34_unwind(6) ) /*0xf1c0000000000050*/
        {
unwind_state_6:
          boost::unique_lock<boost::mutex>::~unique_lock<boost::mutex>(this: &lock); /*0xf1c0000000000054*/
          __eh34_continue_unwinding(6, 2); /*0xf1c0000000000058*/
        }
        __eh34_exit_wind_state(6, 2); /*0xf1c000000000005c*/
      }
      v30 = boost::lock_error::lock_error(this: &v37, ev: 1, what_arg: "boost unique_lock has no mutex"); /*0x1410b10f4*/
      __wind /*0xf1c0000000000014*/
      {
        boost::throw_exception<boost::lock_error>(e: v30); /*0x1410b10fd*/
      }
      __unwind
      {
        boost::thread_resource_error::~thread_resource_error(this: &v37); /*0xf1c0000000000024*/
      }
      goto LABEL_36; /*0xf1c0000000000020*/
    }
    __unwind
    {
      std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>::~pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>( /*0xf1c0000000000048*/
        slot: (rbx::signals::slot_base *)&p,
        a2: v24);
    }
LABEL_40:
    if ( p.second.metaData.callback._Mystorage._Ptrs[7] != nullptr ) /*0x1410b1078*/
    {
      v28 = &p.second.metaData.callback; /*0x1410b107d*/
      LOBYTE(v28) = p.second.metaData.callback._Mystorage._Ptrs[7] != (std::_Func_base<void,RBX::Network::ConnectionStats const &> *)&p.second.metaData.callback; /*0x1410b1084*/
      p.second.metaData.callback._Mystorage._Ptrs[7]->_Delete_this( /*0x1410b1087*/
        this: p.second.metaData.callback._Mystorage._Ptrs[7],
        a2: (bool)v28);
      p.second.metaData.callback._Mystorage._Ptrs[7] = nullptr; /*0x1410b108a*/
    }
    v29 = (std::_Func_base<void,RBX::Network::ConnectionStats const &> *)callback->_Mystorage._Ptrs[7]; /*0x1410b108e*/
    if ( v29 != nullptr ) /*0x1410b1095*/
    {
      LOBYTE(v24) = v29 != (std::_Func_base<void,RBX::Network::ConnectionStats const &> *)callback; /*0x1410b109d*/
      v29->_Delete_this(this: v29, a2: v24); /*0x1410b10a0*/
      callback->_Mystorage._Ptrs[7] = nullptr; /*0x1410b10a3*/
    }
  }
  __unwind
  {
    std::function<void (__int64)>::~function<void (__int64)>(this: callback); /*0xf1c0000000000068*/
  }
}

// Address: 0x1410b1430 | Name: ?removeStats@ConcurrentRakPeer@Network@RBX@@QEAAXUSystemAddress@RakNet@@@Z
void __fastcall RBX::Network::ConcurrentRakPeer::removeStats(
        RBX::Network::ConcurrentRakPeer *this,
        RakNet::SystemAddress *address)
{
  RBX::Network::ConcurrentRakPeer::StatsUpdateJob *Ptr; // rsi
  bool v5; // zf
  boost::mutex *p_mapMutex; // rsi
  unsigned __int64 v7; // rcx
  boost::unordered::unordered_map<RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>,std::allocator<std::pair<RakNet::SystemAddress const ,RBX::Network::ConnectionStats> > > *p_statsMap; // rdi
  unsigned int v9; // eax
  unsigned __int64 v10; // r14
  __int64 v11; // rbp
  boost::unordered::detail::ptr_bucket *next; // rbx
  __int64 v13; // rdx
  boost::unordered::detail::ptr_bucket *buckets; // rax
  signed __int32 v15; // eax
  HANDLE event; // rax
  const boost::lock_error *v17; // rax
  __int64 v18; // [rsp+0h] [rbp-98h] BYREF
  boost::unique_lock<boost::mutex> lock; // [rsp+20h] [rbp-78h] BYREF
  boost::lock_error v20; // [rsp+30h] [rbp-68h] BYREF

  Ptr = this->statsUpdateJob._Ptr; /*0x1410b1451*/
  v5 = &Ptr->mapMutex == nullptr; /*0x1410b1455*/
  p_mapMutex = &Ptr->mapMutex; /*0x1410b1455*/
  lock.m = p_mapMutex; /*0x1410b145c*/
  lock.is_locked = false; /*0x1410b1461*/
  if ( v5 ) /*0x1410b1466*/
  {
    v17 = boost::lock_error::lock_error(this: &v20, ev: 1, what_arg: "boost unique_lock has no mutex"); /*0x1410b15cd*/
    __wind /*0xf1c0000000000014*/
    {
      boost::throw_exception<boost::lock_error>(e: v17); /*0x1410b15d6*/
    }
    __unwind
    {
      boost::thread_resource_error::~thread_resource_error(this: &v20); /*0xf1c0000000000024*/
    }
  }
  boost::detail::basic_timed_mutex::lock(this: p_mapMutex); /*0x1410b146f*/
  lock.is_locked = true; /*0x1410b1474*/
  p_statsMap = &this->statsUpdateJob._Ptr->statsMap; /*0x1410b147d*/
  if ( p_statsMap->table_.size_ != 0 ) /*0x1410b1489*/
  {
    __wind /*0xf1c0000000000044*/
    {
      v9 = RakNet::SystemAddress::ToInteger(sa: address); /*0x1410b1492*/
      v7 = 265 /*0x1410b14af*/
         * ((~(unsigned __int64)v9 + ((unsigned __int64)v9 << 21))
          ^ ((~(unsigned __int64)v9 + ((unsigned __int64)v9 << 21)) >> 24));
      v10 = 2147483649u * (((21 * (v7 ^ (v7 >> 14))) >> 28) ^ (21 * (v7 ^ (v7 >> 14)))); /*0x1410b14d3*/
      v11 = v10 & (p_statsMap->table_.bucket_count_ - 1); /*0x1410b14de*/
      next = p_statsMap->table_.buckets_[v11].next_; /*0x1410b14e5*/
      if ( next != nullptr ) /*0x1410b14ec*/
      {
        while ( 1 ) /*0x1410b14ee*/
        {
          v7 = (unsigned __int64)next->next_; /*0x1410b14ee*/
          if ( next->next_ == nullptr ) /*0x1410b14f4*/
            break; /*0x1410b14f4*/
          v13 = *(_QWORD *)(v7 + 8); /*0x1410b14f6*/
          if ( (v13 & (p_statsMap->table_.bucket_count_ - 1)) != v11 ) /*0x1410b1507*/
            break; /*0x1410b1507*/
          if ( v13 == v10 /*0x1410b151c*/
            && RakNet::SystemAddress::operator==(this: address, right: (const RakNet::SystemAddress *)(v7 + 16)) != 0 )
          {
            boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RakNet::SystemAddress const,RBX::Network::ConnectionStats>>,RakNet::SystemAddress,RBX::Network::ConnectionStats,RakNet::SystemAddressHasher,std::equal_to<RakNet::SystemAddress>>>::delete_nodes( /*0x1410b152f*/
              this: &p_statsMap->table_,
              prev: next,
              end: next->next_->next_);
            v7 = (unsigned __int64)next->next_; /*0x1410b1534*/
            if ( next->next_ != nullptr ) /*0x1410b153a*/
            {
              v7 = (p_statsMap->table_.bucket_count_ - 1) & *(_QWORD *)(v7 + 8); /*0x1410b1547*/
              if ( v11 == v7 ) /*0x1410b154d*/
                goto LABEL_29; /*0x1410b154d*/
              p_statsMap->table_.buckets_[v7].next_ = next; /*0x1410b1553*/
            }
            buckets = p_statsMap->table_.buckets_; /*0x1410b1557*/
            if ( buckets[v11].next_ == next ) /*0x1410b155f*/
              buckets[v11].next_ = nullptr; /*0x1410b1561*/
            goto LABEL_29; /*0xf1c0000000000068*/
          }
          next = next->next_; /*0x1410b151e*/
        }
      }
    }
    __unwind
    {
      boost::unique_lock<boost::mutex>::~unique_lock<boost::mutex>(this: &lock); /*0xf1c0000000000054*/
    }
LABEL_29:
    ;
  }
  __wind /*0xf1c0000000000038*/
  {
    v15 = _InterlockedExchangeAdd(&p_mapMutex->active_count, 0x80000000); /*0x1410b156e*/
    if ( (v15 & 0x40000000) == 0 && v15 != 0x80000000 && !_interlockedbittestandset(&lock.m->active_count, 0x1Eu) ) /*0x1410b1589*/
    {
      event = boost::detail::basic_timed_mutex::get_event(this: lock.m); /*0x1410b1590*/
      SetEvent(hEvent: event); /*0x1410b1598*/
    }
  }
  __unwind
  {
    __std_terminate(a1: v7, a2: &v18); /*0x142f39fa8*/
  }
}

// END ConcurrentRakPeer part 1/1, 10 functions
