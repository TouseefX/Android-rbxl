// DeserializingJoinDataItemV2 -- 2022 Studio + full PDB
// tier 3, 5 functions


// Address: 0x14043bfa0 | Name: ?getIsStillDeserializingCurrentStream@DeserializingJoinDataItemV2@JoinDataItemV2@Replicator@Network@RBX@@QEBA_NXZ
_BOOL8 __fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::getIsStillDeserializingCurrentStream(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this)
{
  return this->isStillDeserializingCurrentStream; /*0x14043bfa4*/
}

// Address: 0x14105bef0 | Name: ??1DeserializingJoinDataItemV2@JoinDataItemV2@Replicator@Network@RBX@@QEAA@XZ
void __fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::~DeserializingJoinDataItemV2(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this)
{
  RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::JDIv2ChildOrderMetaData_deprecated *Myfirst; // rcx
  RBX::Network::InvalidReplicationMetaData *v3; // rcx

  Myfirst = this->childOrderInfo_deprecated._Mypair._Myval2._Myfirst; /*0x14105beff*/
  if ( Myfirst != nullptr ) /*0x14105bf09*/
  {
    if ( (((char *)this->childOrderInfo_deprecated._Mypair._Myval2._Myend - (char *)Myfirst) & 0xFFFFFFFFFFFFFFF8uLL) >= 0x1000 ) /*0x14105bf20*/
    {
      if ( (unsigned __int64)&Myfirst[-1] - *(_QWORD *)&Myfirst[-1] > 0x1F ) /*0x14105bf35*/
        goto LABEL_12; /*0x14105bf35*/
      Myfirst = (RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::JDIv2ChildOrderMetaData_deprecated *)Myfirst[-1]; /*0x14105bf37*/
    }
    operator delete(ptr: Myfirst); /*0x14105bf3a*/
    this->childOrderInfo_deprecated._Mypair._Myval2._Myfirst = nullptr; /*0x14105bf3f*/
    this->childOrderInfo_deprecated._Mypair._Myval2._Mylast = nullptr; /*0x14105bf46*/
    this->childOrderInfo_deprecated._Mypair._Myval2._Myend = nullptr; /*0x14105bf4d*/
  }
  v3 = this->invalidMrdOffsets._Mypair._Myval2._Myfirst; /*0x14105bf54*/
  if ( v3 != nullptr ) /*0x14105bf5b*/
  {
    if ( (((char *)this->invalidMrdOffsets._Mypair._Myval2._Myend - (char *)v3) & 0xFFFFFFFFFFFFFFF8uLL) < 0x1000 ) /*0x14105bf6f*/
    {
LABEL_10:
      operator delete(ptr: v3); /*0x14105bf89*/
      this->invalidMrdOffsets._Mypair._Myval2._Myfirst = nullptr; /*0x14105bf8e*/
      this->invalidMrdOffsets._Mypair._Myval2._Mylast = nullptr; /*0x14105bf92*/
      this->invalidMrdOffsets._Mypair._Myval2._Myend = nullptr; /*0x14105bf96*/
      goto LABEL_11; /*0x14105bf96*/
    }
    if ( (unsigned __int64)&v3[-1] - *(_QWORD *)&v3[-1] <= 0x1F ) /*0x14105bf84*/
    {
      v3 = (RBX::Network::InvalidReplicationMetaData *)v3[-1]; /*0x14105bf86*/
      goto LABEL_10; /*0x14105bf86*/
    }
LABEL_12:
    _invalid_parameter_noinfo_noreturn(); /*0x14105bfad*/
  }
LABEL_11:
  RBX::Network::NetworkStream::~NetworkStream(this: &this->stream); /*0x14105bf9a*/
}

// Address: 0x1411443a0 | Name: ?prepWork@DeserializingJoinDataItemV2@JoinDataItemV2@Replicator@Network@RBX@@QEAAXAEAVNetworkStream@45@@Z
void __fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::prepWork(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this,
        RBX::Network::NetworkStream *inStream)
{
  float compressedBitStreamSize; // xmm1_4
  unsigned int readOffset; // r15d
  unsigned int v6; // ebp
  unsigned int v7; // r15d
  __int64 v8; // rsi
  RBX::Network::InvalidReplicationMetaData *Myfirst; // rbx
  RBX::Network::InvalidReplicationMetaData *v10; // rbx
  RBX::Network::InvalidReplicationMetaData *v11; // rbx
  std::string m; // [rsp+30h] [rbp-98h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+50h] [rbp-78h] BYREF
  RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::JDIv2ChildOrderMetaData_deprecated v14; // [rsp+D0h] [rbp+8h] BYREF
  RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::JDIv2ChildOrderMetaData_deprecated _Val; // [rsp+E0h] [rbp+18h] BYREF

  if ( !this->isStillDeserializingCurrentStream ) /*0x1411443c1*/
  {
    if ( !this->replicator->joinCompleteTagReceived ) /*0x1411443d1*/
    {
      this->replicator->joinRxStats.totalJdiv2BytesRxDuringJoin += inStream->GetNumberOfBytesUsed(this: inStream); /*0x1411443df*/
      ++this->replicator->joinRxStats.totalJdiv2ItemsRxDuringJoin; /*0x1411443e8*/
    }
    this->isStillDeserializingCurrentStream = true; /*0x1411443ee*/
    this->joinDataSubItemType = RBX::Network::NetworkStream::readByte(this: inStream); /*0x1411443fd*/
    this->compressedBitStreamSize = (float)(inStream->numberOfBytesUsed - inStream->readOffset); /*0x141144410*/
    RBX::Network::Replicator::decompressBitStream( /*0x14114441f*/
      inCompressedBitStream: inStream,
      outUncompressedBitStream: &this->stream);
    compressedBitStreamSize = this->compressedBitStreamSize; /*0x141144424*/
    this->compressionRatio = (float)(int)this->stream.numberOfBytesUsed / compressedBitStreamSize; /*0x14114443b*/
    if ( this->joinDataSubItemType == SHARED_STRING ) /*0x141144447*/
    {
      this->replicator->joinRxStats.totalSharedStringBytesRxInJoin = (int)(float)((float)(int)this->replicator->joinRxStats.totalSharedStringBytesRxInJoin /*0x14114467f*/
                                                                                + compressedBitStreamSize);
      this->replicator->joinRxStats.totalSharedStringBytesUncompressedInJoin += this->stream.GetNumberOfBytesUsed(this: &this->stream); /*0x141144693*/
    }
    else
    {
      this->metaDataCount = RBX::Network::NetworkStream::readUInt32(this: inStream); /*0x141144455*/
      this->replicator->joinRxStats.totalMetaBytesRxInJoin += 4; /*0x14114445b*/
      if ( DFLog::ReplicationDataCaching != 0 ) /*0x14114446b*/
        FLog::FastLog( /*0x141144478*/
          level: DFLog::ReplicationDataCaching,
          message: "[DFLog::ReplicationDataCaching] Expecting %d instances",
          arg0: (const void *)this->metaDataCount);
      readOffset = inStream->readOffset; /*0x14114447d*/
      v14.numberOfChildren_deprecated = readOffset; /*0x141144481*/
      RBX::Network::deserializeUnsignedVarint(value: &this->invalidMetaDataCount, stream: inStream); /*0x141144490*/
      v6 = 0; /*0x141144495*/
      _Val = 0; /*0x141144497*/
      std::vector<RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::JDIv2ChildOrderMetaData_deprecated>::assign( /*0x1411444ae*/
        this: (std::vector<RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::JDIv2ChildOrderMetaData_deprecated> *)&this->invalidMrdOffsets,
        _Newsize: this->invalidMetaDataCount,
        &_Val);
      this->replicator->joinRxStats.totalInstancesInBlobs += this->metaDataCount; /*0x1411444b9*/
      this->replicator->joinRxStats.totalWasteInstancesInBlobs += this->invalidMetaDataCount; /*0x1411444c5*/
      if ( DFLog::ReplicationDataCaching != 0 ) /*0x1411444d4*/
        FLog::FastLog( /*0x1411444e1*/
          level: DFLog::ReplicationDataCaching,
          message: "[DFLog::ReplicationDataCaching] Expecting #%d invalid metaData in this blob",
          arg0: (const void *)(int)this->invalidMetaDataCount);
      if ( this->invalidMetaDataCount != 0 ) /*0x1411444e9*/
      {
        v7 = 0; /*0x1411444ef*/
        v8 = 0; /*0x1411444f2*/
        while ( 1 ) /*0x14114450e*/
        {
          RBX::Network::deserializeUnsignedVarint( /*0x14114450e*/
            value: (unsigned int *)&this->invalidMrdOffsets._Mypair._Myval2._Myfirst[v7],
            stream: inStream);
          RBX::Network::deserializeUnsignedVarint( /*0x141144522*/
            value: &this->invalidMrdOffsets._Mypair._Myval2._Myfirst[v7].length,
            stream: inStream);
          if ( DFLog::ReplicationDataCaching != 0 ) /*0x141144530*/
            FLog::FastLog( /*0x14114454b*/
              level: DFLog::ReplicationDataCaching,
              message: "[DFLog::ReplicationDataCaching] Invalid offset %d  length %d",
              arg0: (const void *)this->invalidMrdOffsets._Mypair._Myval2._Myfirst[v8].offset,
              arg1: (const void *)this->invalidMrdOffsets._Mypair._Myval2._Myfirst[v8].length,
              arg2: nullptr);
          this->replicator->joinRxStats.totalWasteBytesRxInJoin += this->invalidMrdOffsets._Mypair._Myval2._Myfirst[v8].length; /*0x14114455b*/
          Myfirst = this->invalidMrdOffsets._Mypair._Myval2._Myfirst; /*0x141144561*/
          if ( Myfirst[v8].offset > this->stream.GetNumberOfBytesUsed(this: &this->stream) ) /*0x141144573*/
          {
LABEL_24:
            std::string::string(this: &m, _Ptr: "Offset index of JDIv2 larger than bitstream length"); /*0x1411446b4*/
            __wind /*0xf1c0000000000004*/
            {
              RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1411446d0*/
              throw &pExceptionObject; /*0x1411446e1*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
            }
          }
          v10 = this->invalidMrdOffsets._Mypair._Myval2._Myfirst; /*0x141144579*/
          if ( v10[v8].length > this->stream.GetNumberOfBytesUsed(this: &this->stream) ) /*0x14114458c*/
            goto LABEL_24; /*0x14114458c*/
          v11 = this->invalidMrdOffsets._Mypair._Myval2._Myfirst; /*0x141144592*/
          if ( v11[v8].offset + v11[v8].length > this->stream.GetNumberOfBytesUsed(this: &this->stream) ) /*0x1411445aa*/
            goto LABEL_24; /*0x1411445aa*/
          ++v7; /*0x1411445b0*/
          ++v8; /*0x1411445b3*/
          if ( v7 >= this->invalidMetaDataCount ) /*0x1411445bb*/
          {
            std::_Sort_unchecked_Luau::BytecodeBuilder::Jump____lambda_80f1ca31a8c0fc9c77d0b5ca46eb518a___( /*0x1411445dc*/
              _First: (Luau::BytecodeBuilder::Jump *)this->invalidMrdOffsets._Mypair._Myval2._Myfirst,
              _Last: (Luau::BytecodeBuilder::Jump *)this->invalidMrdOffsets._Mypair._Myval2._Mylast,
              _Ideal: this->invalidMrdOffsets._Mypair._Myval2._Mylast - this->invalidMrdOffsets._Mypair._Myval2._Myfirst,
              _Pred: (Luau::BytecodeBuilder::expandJumps::__l2::<lambda_80f1ca31a8c0fc9c77d0b5ca46eb518a>)v14.numberOfChildren_deprecated);
            readOffset = v14.numberOfChildren_deprecated; /*0x1411445e1*/
            break; /*0x1411445e1*/
          }
        }
      }
      if ( !RBX::Network::Replicator::getJDIv2NoOrderInfo(this: this->replicator) ) /*0x1411445ec*/
      {
        v14 = 0; /*0x1411445f5*/
        std::vector<RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::JDIv2ChildOrderMetaData_deprecated>::assign( /*0x14114460f*/
          this: &this->childOrderInfo_deprecated,
          _Newsize: this->metaDataCount,
          _Val: &v14);
        if ( this->metaDataCount != 0 ) /*0x141144617*/
        {
          do /*0x141144651*/
          {
            RBX::Network::deserializeUnsignedVarint( /*0x141144630*/
              value: (unsigned int *)&this->childOrderInfo_deprecated._Mypair._Myval2._Myfirst[v6],
              stream: inStream);
            RBX::Network::deserializeUnsignedVarint( /*0x141144647*/
              value: &this->childOrderInfo_deprecated._Mypair._Myval2._Myfirst[v6++].indexInParent_deprecated,
              stream: inStream);
          }
          while ( v6 < this->metaDataCount ); /*0x141144651*/
        }
      }
      this->replicator->joinRxStats.totalMetaBytesRxInJoin += inStream->readOffset - readOffset; /*0x14114465d*/
    }
  }
}

// Address: 0x141144850 | Name: ?read@DeserializingJoinDataItemV2@JoinDataItemV2@Replicator@Network@RBX@@QEAA?AV?$shared_ptr@VDeserializedJoinDataItem@Network@RBX@@@std@@AEAVNetworkStream@45@@Z
std::shared_ptr<RBX::File> *__fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::read(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this,
        std::shared_ptr<RBX::File> *result,
        RBX::Network::NetworkStream *inStream)
{
  unsigned int v6; // eax
  std::shared_ptr<RBX::Network::DeserializedJoinDataItem> *v7; // rax
  RBX::Network::DeserializedJoinDataItem *Ptr; // rcx
  std::_Ref_count_base *v9; // rdx
  std::_Ref_count_base *v10; // rsi
  std::_Ref_count_base *v11; // rsi
  RBX::Network::NetworkStream_vtbl *v12; // rax
  RBX::Network::NetworkStream_vtbl *GetNumberOfBytesUsed; // rcx
  std::_Ref_count_base *Rep; // rsi
  RBX::Time *v15; // rax
  float v16; // xmm1_4
  __int32 v17; // ecx
  RBX::Network::NetworkStream *v18; // rsi
  std::vector<unsigned char> *p_dataVector; // r14
  std::vector<unsigned char> *v20; // rbx
  unsigned __int8 *Myfirst; // rcx
  unsigned __int8 *v22; // rcx
  __int64 v23; // rcx
  std::shared_ptr<RBX::File> *v24; // rax
  __int64 v25; // [rsp+0h] [rbp-79h] BYREF
  int v26; // [rsp+30h] [rbp-49h]
  RBX::SharedString sharedString; // [rsp+38h] [rbp-41h] BYREF
  std::shared_ptr<RBX::Network::DeserializedJoinDataItem> v28; // [rsp+48h] [rbp-31h] BYREF
  RBX::Network::NetworkStream hashTmp; // [rsp+58h] [rbp-21h] BYREF
  RBX::Memory::Scope memscopeNetworkReplicatedInstances; // [rsp+E0h] [rbp+67h] BYREF
  std::shared_ptr<RBX::File> *v31; // [rsp+E8h] [rbp+6Fh]
  RBX::Timer<2> readInstanceTime; // [rsp+F8h] [rbp+7Fh] BYREF

  v31 = result; /*0x141144850*/
  __wind /*0xf1c0000000000088*/
  {
    v26 = 0; /*0x141144877*/
    v6 = RBX::Memory::setCurrentCategory(category: RBX::Memory::NetworkReplicatedInstances); /*0x141144881*/
    __wind /*0xf1c0000000000064*/
    {
      memscopeNetworkReplicatedInstances.parent = v6; /*0x141144886*/
      RBX::Time::now<2>(result: &readInstanceTime.start); /*0x14114488d*/
      RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::prepWork(this, inStream); /*0x141144898*/
      result->_Ptr = nullptr; /*0x14114489d*/
      result->_Rep = nullptr; /*0x1411448a0*/
      v26 = 1; /*0x1411448a4*/
      if ( this->joinDataSubItemType == SHARED_STRING ) /*0x1411448b1*/
      {
        __wind /*0xf1c0000000000058*/
        {
          while ( this->stream.numberOfBytesUsed != this->stream.readOffset /*0x141144979*/
               && !RBX::Network::Replicator::deserializationTimeLimitReached(this: this->replicator) )
          {
            hashTmp.__vftable = nullptr; /*0x14114497f*/
            hashTmp.data = nullptr; /*0x141144983*/
            hashTmp.dataVector._Mypair._Myval2._Myfirst = (unsigned __int8 *)15; /*0x141144987*/
            v12 = (RBX::Network::NetworkStream_vtbl *)operator new(size: 0x20u); /*0x141144997*/
            hashTmp.data = (unsigned __int8 *)16; /*0x14114499c*/
            hashTmp.dataVector._Mypair._Myval2._Myfirst = (unsigned __int8 *)31; /*0x1411449a4*/
            *(_OWORD *)&v12->dtr_AbstractBitStream = 0; /*0x1411449af*/
            LOBYTE(v12->GetNumberOfBytesUsed) = 0; /*0x1411449b2*/
            hashTmp.__vftable = v12; /*0x1411449b6*/
            ++this->replicator->joinRxStats.totalSharedStringCountInJoin; /*0x1411449bd*/
            RBX::SharedString::SharedString(this: &sharedString); /*0x1411449c7*/
            __wind /*0xf1c000000000004c*/
            {
              RBX::Network::Replicator::readANewSharedString( /*0x1411449e5*/
                this: this->replicator,
                inBitStream: &this->stream,
                &sharedString,
                (std::string *)&hashTmp,
                haveDoneSecurityCheck: &this->haveDoneSecurityCheck);
            }
            __unwind
            {
              RBX::SharedString::~SharedString(this: &sharedString); /*0xf1c0000000000044*/
            }
            boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &sharedString.flyweight.h); /*0x1411449ef*/
            if ( hashTmp.dataVector._Mypair._Myval2._Myfirst >= (unsigned __int8 *)0x10 ) /*0x1411449fd*/
            {
              GetNumberOfBytesUsed = hashTmp.__vftable; /*0x141144a06*/
              if ( (unsigned __int64)(hashTmp.dataVector._Mypair._Myval2._Myfirst + 1) >= 0x1000 ) /*0x141144a14*/
              {
                GetNumberOfBytesUsed = (RBX::Network::NetworkStream_vtbl *)hashTmp.__vftable[-1].GetNumberOfBytesUsed; /*0x141144a1a*/
                if ( (unsigned __int64)((char *)hashTmp.__vftable - (char *)GetNumberOfBytesUsed - 8) > 0x1F ) /*0x141144a29*/
                  _invalid_parameter_noinfo_noreturn(); /*0x141144a35*/
              }
              operator delete(ptr: GetNumberOfBytesUsed); /*0x141144a2b*/
            }
          }
          v26 = 3; /*0x141144a3c*/
          result->_Ptr = nullptr; /*0x141144a43*/
          Rep = result->_Rep; /*0x141144a46*/
          result->_Rep = nullptr; /*0x141144a4a*/
          if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141144a62*/
          {
            Rep->_Destroy(this: Rep); /*0x141144a6a*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141144a74*/
              Rep->_Delete_this(this: Rep); /*0x141144a7c*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&hashTmp); /*0xf1c0000000000038*/
        }
        this->isStillDeserializingCurrentStream = this->stream.numberOfBytesUsed != this->stream.readOffset; /*0x141144a88*/
        this->replicator->joinRxStats.cycleLastJdiv2SharedStringArrival = this->replicator->deserializingPacketInfo.frameWhenPacketAddedToDeserializationQueue; /*0x141144a94*/
        this->replicator->joinRxStats.cycleLastJdiv2SharedStringDeserialize = RBX::TaskScheduler::cycle(); /*0x141144aa2*/
        this->replicator->joinRxStats.timeLastJdiv2SharedStringArrival = this->replicator->deserializingPacketInfo.timeWhenPacketAddedToDeserializationQueue; /*0x141144ab1*/
        this->replicator->joinRxStats.timeLastJdiv2SharedStringDeserialize = RakNet::GetTimeMS(); /*0x141144abf*/
      }
      else if ( this->joinDataSubItemType == CACHEABLE_INSTANCES || (unsigned int)(this->joinDataSubItemType - 3) <= 1 ) /*0x1411448bf*/
      {
        v7 = RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::readAnInstance(this, result: &v28); /*0x1411448d1*/
        Ptr = v7->_Ptr; /*0x1411448d6*/
        v9 = v7->_Rep; /*0x1411448d9*/
        v7->_Ptr = nullptr; /*0x1411448dd*/
        v7->_Rep = nullptr; /*0x1411448e0*/
        result->_Ptr = (RBX::File *)Ptr; /*0x1411448e4*/
        v10 = result->_Rep; /*0x1411448e7*/
        result->_Rep = v9; /*0x1411448eb*/
        if ( v10 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Uses, 0xFFFFFFFF) == 1 ) /*0x141144903*/
        {
          v10->_Destroy(this: v10); /*0x14114490b*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141144917*/
            v10->_Delete_this(this: v10); /*0x14114491f*/
        }
        v11 = v28._Rep; /*0x141144922*/
        if ( v28._Rep != nullptr /*0x141144935*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&v28._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v11->_Destroy(this: v11); /*0x14114493d*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v11->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141144947*/
            v11->_Delete_this(this: v11); /*0x14114494f*/
        }
        this->isStillDeserializingCurrentStream = this->offsetIndex != this->metaDataCount; /*0x14114495b*/
      }
      v15 = RBX::Time::now<2>(result: (RBX::Time *)&sharedString); /*0x141144ac9*/
      v16 = (v15->sec - readInstanceTime.start.sec) * 1000.0; /*0x141144adf*/
      this->replicator->joinRxStats.joinDataReadTimeInMs = v16 + this->replicator->joinRxStats.joinDataReadTimeInMs; /*0x141144af1*/
      if ( this->joinDataSubItemType == SHARED_STRING ) /*0x141144aff*/
      {
        this->replicator->joinRxStats.joinDataReadTimeSharedStringsInMs = v16 /*0x141144b30*/
                                                                        + this->replicator->joinRxStats.joinDataReadTimeSharedStringsInMs;
      }
      else if ( this->joinDataSubItemType == CACHEABLE_INSTANCES /*0x141144b09*/
             || (unsigned int)(v17 = this->joinDataSubItemType - 3) <= 1 )
      {
        this->replicator->joinRxStats.joinDataReadTimeInstanceInMs = v16 /*0x141144b1b*/
                                                                   + this->replicator->joinRxStats.joinDataReadTimeInstanceInMs;
      }
      if ( !this->isStillDeserializingCurrentStream ) /*0x141144b3c*/
      {
        this->joinDataSubItemType = MAX; /*0x141144b42*/
        v18 = RBX::Network::NetworkStream::NetworkStream(this: &hashTmp); /*0x141144b52*/
        this->stream.isJoinData = v18->isJoinData; /*0x141144b59*/
        this->stream.data = v18->data; /*0x141144b60*/
        p_dataVector = &v18->dataVector; /*0x141144b64*/
        v20 = &this->stream.dataVector; /*0x141144b68*/
        if ( &this->stream.dataVector != &v18->dataVector ) /*0x141144b6f*/
        {
          Myfirst = v20->_Mypair._Myval2._Myfirst; /*0x141144b71*/
          if ( v20->_Mypair._Myval2._Myfirst != nullptr ) /*0x141144b77*/
          {
            if ( (unsigned __int8 *)(this->stream.dataVector._Mypair._Myval2._Myend - Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x141144b87*/
            {
              if ( (unsigned __int64)&Myfirst[-*((_QWORD *)Myfirst - 1) - 8] > 0x1F ) /*0x141144b9c*/
                goto LABEL_43; /*0x141144b9c*/
              Myfirst = *((unsigned __int8 **)Myfirst - 1); /*0x141144b9e*/
            }
            operator delete(ptr: Myfirst); /*0x141144ba1*/
            v20->_Mypair._Myval2._Myfirst = nullptr; /*0x141144ba6*/
            this->stream.dataVector._Mypair._Myval2._Mylast = nullptr; /*0x141144ba9*/
            this->stream.dataVector._Mypair._Myval2._Myend = nullptr; /*0x141144bad*/
          }
          v20->_Mypair._Myval2._Myfirst = p_dataVector->_Mypair._Myval2._Myfirst; /*0x141144bb4*/
          this->stream.dataVector._Mypair._Myval2._Mylast = v18->dataVector._Mypair._Myval2._Mylast; /*0x141144bbb*/
          this->stream.dataVector._Mypair._Myval2._Myend = v18->dataVector._Mypair._Myval2._Myend; /*0x141144bc3*/
          p_dataVector->_Mypair._Myval2._Myfirst = nullptr; /*0x141144bc7*/
          v18->dataVector._Mypair._Myval2._Mylast = nullptr; /*0x141144bca*/
          v18->dataVector._Mypair._Myval2._Myend = nullptr; /*0x141144bce*/
        }
        this->stream.numberOfBytesUsed = v18->numberOfBytesUsed; /*0x141144bd5*/
        this->stream.numberOfBytesAllocated = v18->numberOfBytesAllocated; /*0x141144bdb*/
        this->stream.readOffset = v18->readOffset; /*0x141144be1*/
        this->stream.ownedData = v18->ownedData; /*0x141144be8*/
        v22 = hashTmp.dataVector._Mypair._Myval2._Myfirst; /*0x141144beb*/
        if ( hashTmp.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x141144bf2*/
        {
          if ( (unsigned __int8 *)(hashTmp.dataVector._Mypair._Myval2._Myend /*0x141144c05*/
                                 - hashTmp.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 )
          {
            v22 = *((unsigned __int8 **)hashTmp.dataVector._Mypair._Myval2._Myfirst - 1); /*0x141144c0b*/
            if ( (unsigned __int64)(hashTmp.dataVector._Mypair._Myval2._Myfirst - v22 - 8) > 0x1F ) /*0x141144c1a*/
LABEL_43:
              _invalid_parameter_noinfo_noreturn(); /*0x141144c1c*/
          }
          operator delete(ptr: v22); /*0x141144c23*/
        }
        this->haveDoneSecurityCheck = false; /*0x141144c28*/
        *(_QWORD *)&this->metaDataCount = 0; /*0x141144c2c*/
        *(_QWORD *)&this->invalidOffsetIndex = 0; /*0x141144c30*/
        this->invalidMrdOffsets._Mypair._Myval2._Mylast = this->invalidMrdOffsets._Mypair._Myval2._Myfirst; /*0x141144c38*/
        this->childOrderInfo_deprecated._Mypair._Myval2._Mylast = this->childOrderInfo_deprecated._Mypair._Myval2._Myfirst; /*0x141144c43*/
        *(_QWORD *)&this->lastInstanceOffset = 0; /*0x141144c4a*/
        this->compressedBitStreamSize = 0.0; /*0x141144c51*/
      }
    }
    __unwind
    {
      RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&memscopeNetworkReplicatedInstances); /*0xf1c0000000000074*/
    }
    __wind /*0xf1c000000000007c*/
    {
      RBX::Memory::setCurrentCategory(category: memscopeNetworkReplicatedInstances.parent); /*0x141144c5b*/
    }
    __unwind
    {
      __std_terminate(a1: v23, a2: &v25); /*0x142f39fa8*/
    }
    v24 = result; /*0x141144c61*/
  }
  __unwind
  {
    if ( (v26 & 1) != 0 ) /*0x1431f12d1*/
    {
      v26 &= ~1u; /*0x1431f12d3*/
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v31); /*0x1431f12de*/
    }
  }
  return v24; /*0x141144c64*/
}

// Address: 0x141144c80 | Name: ?readAnInstance@DeserializingJoinDataItemV2@JoinDataItemV2@Replicator@Network@RBX@@QEAA?AV?$shared_ptr@VDeserializedJoinDataItem@Network@RBX@@@std@@XZ
std::shared_ptr<RBX::File> *__fastcall RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::readAnInstance(
        RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2 *this,
        std::shared_ptr<RBX::File> *result)
{
  RBX::Network::DeserializedJoinDataItem *v4; // rax
  RBX::Network::DeserializedJoinDataItem *v5; // rdi
  std::_Ref_count_base *v6; // rax
  std::_Ref_count_base *Rep; // rdi
  unsigned int invalidOffsetIndex; // eax
  unsigned int v9; // r9d
  unsigned __int8 v10; // cl
  __int64 v11; // rdx
  RBX::Network::InvalidReplicationMetaData *v12; // rax
  const void *offset; // r8
  unsigned __int64 v14; // r8
  RBX::Network::InvalidReplicationMetaData *v15; // rdx
  unsigned int readOffset; // eax
  __int64 offsetIndex; // rdx
  RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::JDIv2ChildOrderMetaData_deprecated *Myfirst; // rcx
  const void *v19; // rdi
  std::string *v20; // rax
  std::string *Ptr; // r8
  char *v22; // rcx
  RBX::Network::DeserializedJoinDataItem *v23; // rdi
  char *second; // rcx
  std::_Ref_count_base *v25; // rdi
  std::_Ref_count_base *v26; // rdi
  RBX::Network::DeserializedNewInstanceItem instanceInfo; // [rsp+50h] [rbp-89h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v29; // [rsp+E0h] [rbp+7h] BYREF
  RBX::Network::DeserializedJoinDataItem *v30; // [rsp+140h] [rbp+67h]
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> v32; // [rsp+150h] [rbp+77h] BYREF
  std::_Ref_count_base *v33; // [rsp+158h] [rbp+7Fh]

  result->_Ptr = nullptr; /*0x141144ca9*/
  result->_Rep = nullptr; /*0x141144cac*/
  if ( this->offsetIndex < this->metaDataCount )
  {
    __wind
    {
      do /*0x141144cd2*/
      {
        if ( RBX::Network::Replicator::deserializationTimeLimitReached(this: this->replicator) ) /*0x141144cd5*/
          goto LABEL_63; /*0x141144cdc*/
        if ( result->_Ptr == nullptr ) /*0x141144ce6*/
        {
          v4 = (RBX::Network::DeserializedJoinDataItem *)operator new(size: 0x38u); /*0x141144cf1*/
          v30 = v4; /*0x141144cf6*/
          __wind /*0xf1c0000000000088*/
          {
            if ( v4 != nullptr ) /*0x141144cfd*/
              v5 = RBX::Network::DeserializedJoinDataItem::DeserializedJoinDataItem( /*0x141144d0c*/
                     this: v4,
                     itemType: (RBX::Network::ExtendedAnalyticsItemType)22);
            else
              v5 = nullptr; /*0x141144d11*/
          }
          __unwind
          {
            operator delete(ptr: v30); /*0x1431f1345*/
          }
          v32._Ptr = (RBX::Graphics::TextureVulkan::DownloadBuffer *)v5; /*0x141144d14*/
          __wind /*0xf1c0000000000070*/
          {
            v6 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x141144d1d*/
            v33 = v6; /*0x141144d22*/
            if ( v6 != nullptr ) /*0x141144d29*/
            {
              *v6 = 0; /*0x141144d2e*/
              v6->_Uses = 1; /*0x141144d31*/
              v6->_Weaks = 1; /*0x141144d38*/
              v6->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::DeserializedJoinDataItem>::`vftable'; /*0x141144d3f*/
              v6[1].__vftable = (std::_Ref_count_base_vtbl *)v5; /*0x141144d42*/
            }
            else
            {
              v6 = nullptr; /*0x141144d48*/
            }
            result->_Ptr = (RBX::File *)v5; /*0x141144d4b*/
            Rep = result->_Rep; /*0x141144d4e*/
            result->_Rep = v6; /*0x141144d52*/
            if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141144d68*/
            {
              Rep->_Destroy(this: Rep); /*0x141144d70*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141144d7f*/
                Rep->_Delete_this(this: Rep); /*0x141144d87*/
            }
          }
          __unwind
          {
            RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: &v32); /*0xf1c0000000000068*/
          }
        }
        RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem(this: &instanceInfo); /*0x141144d8f*/
        __eh34_enter_wind_state(0, 3); /*0xf1c000000000005c*/
        invalidOffsetIndex = this->invalidOffsetIndex; /*0x141144d95*/
        if ( invalidOffsetIndex < this->invalidMetaDataCount ) /*0x141144d9b*/
          break; /*0x141144d9b*/
LABEL_29:
        readOffset = this->stream.readOffset; /*0x141144e61*/
        this->lastInstanceOffset = readOffset; /*0x141144e64*/
        if ( DFLog::ReplicationDataCaching != 0 ) /*0x141144e73*/
          FLog::FastLog( /*0x141144e7f*/
            level: DFLog::ReplicationDataCaching,
            message: "[DFLog::ReplicationDataCaching] Reading instance @ offset=%d",
            arg0: (const void *)readOffset);
        RBX::Network::Replicator::JoinDataItemV2::readInstance( /*0x141144e90*/
          replicator: this->replicator,
          bitStream: &this->stream,
          deserializedItem: &instanceInfo);
        if ( !RBX::Network::Replicator::getJDIv2NoOrderInfo(this: this->replicator) ) /*0x141144e98*/
        {
          offsetIndex = this->offsetIndex; /*0x141144ea1*/
          Myfirst = this->childOrderInfo_deprecated._Mypair._Myval2._Myfirst; /*0x141144ea4*/
          instanceInfo.numberOfChildren_deprecated = Myfirst[offsetIndex].numberOfChildren_deprecated; /*0x141144eae*/
          instanceInfo.indexInParent_deprecated = Myfirst[offsetIndex].indexInParent_deprecated; /*0x141144eb5*/
        }
        instanceInfo.analyticsWireSize = (float)(this->stream.readOffset - this->lastInstanceOffset) /*0x141144ed1*/
                                       / this->compressionRatio;
        *(float *)&result->_Ptr->_Wptr._Rep = instanceInfo.analyticsWireSize + *(float *)&result->_Ptr->_Wptr._Rep; /*0x141144ede*/
        if ( DFLog::ReplicationDataCaching == 0 ) /*0x141144eea*/
          goto LABEL_65; /*0x141144eea*/
        v19 = (const void *)this->stream.readOffset; /*0x141144ef0*/
        v20 = RBX::Guid::readableString(this: &instanceInfo.id, result: &v29.text, scopeLength: 4); /*0x141144f01*/
        Ptr = v20; /*0x141144f06*/
        __wind /*0xf1c0000000000050*/
        {
          if ( v20->_Mypair._Myval2._Myres >= 0x10 ) /*0x141144f0e*/
            Ptr = (std::string *)v20->_Mypair._Myval2._Bx._Ptr; /*0x141144f10*/
          FLog::FastLog( /*0x141144f39*/
            level: DFLog::ReplicationDataCaching,
            message: "[DFLog::ReplicationDataCaching] Done reading join instance %s offset=%X bytes with numOfChildren=%d, indexInParent=%d",
            arg0: Ptr,
            arg1: v19,
            arg2: (void *)instanceInfo.numberOfChildren_deprecated,
            arg3: (void *)instanceInfo.indexInParent_deprecated,
            arg4: nullptr);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v29); /*0xf1c0000000000048*/
        }
        if ( v29.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141144f47*/
        {
          if ( __eh34_unwind(3) ) /*0xf1c0000000000038*/
            goto unwind_state_3; /*0xf1c0000000000038*/
          __eh34_exit_wind_state(3, 0); /*0xf1c000000000003c*/
          v22 = v29.text._Mypair._Myval2._Bx._Ptr; /*0x141144f4c*/
          if ( v29.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141144f5a*/
          {
            v22 = *((char **)v29.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141144f60*/
            if ( (unsigned __int64)(v29.text._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x141144f6f*/
              _invalid_parameter_noinfo_noreturn(); /*0x14114509b*/
          }
          operator delete(ptr: v22); /*0x141144f75*/
        }
        else
        {
          if ( __eh34_unwind(3) ) /*0xf1c0000000000024*/
          {
unwind_state_3:
            RBX::Network::DeserializedNewInstanceItem::~DeserializedNewInstanceItem(this: &instanceInfo); /*0xf1c0000000000028*/
            __eh34_continue_unwinding(3, 0); /*0xf1c000000000002c*/
          }
LABEL_65:
          __eh34_exit_wind_state(3, 0); /*0xf1c0000000000030*/
        }
        v23 = (RBX::Network::DeserializedJoinDataItem *)result->_Ptr; /*0x141144f7a*/
        if ( result->_Ptr->xmlId._Mypair._Myval2 == (std::string *)result->_Ptr->registry.px ) /*0x141144f85*/
        {
          std::vector<RBX::Network::DeserializedNewInstanceItem>::_Emplace_reallocate<RBX::Network::DeserializedNewInstanceItem>( /*0x141144faa*/
            this: &v23->instanceInfos,
            _Whereptr: (RBX::Network::DeserializedNewInstanceItem *const)result->_Ptr->xmlId._Mypair._Myval2,
            <_Val_0>: &instanceInfo);
        }
        else
        {
          RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem( /*0x141144f8f*/
            this: (RBX::Network::DeserializedNewInstanceItem *)result->_Ptr->xmlId._Mypair._Myval2,
            __that: &instanceInfo);
          ++v23->instanceInfos._Mypair._Myval2._Mylast; /*0x141144f94*/
        }
        ++this->offsetIndex; /*0x141144faf*/
        instanceInfo.__vftable = (RBX::Network::DeserializedNewInstanceItem_vtbl *)RBX::Network::DeserializedNewInstanceItem::`vftable'; /*0x141144fb2*/
        second = (char *)instanceInfo.unresolvedInstanceReferences._Mypair._Myval2._Myfirst; /*0x141144fb7*/
        if ( instanceInfo.unresolvedInstanceReferences._Mypair._Myval2._Myfirst != nullptr ) /*0x141144fbe*/
        {
          if ( (((char *)instanceInfo.unresolvedInstanceReferences._Mypair._Myval2._Myend /*0x141144fd5*/
               - (char *)instanceInfo.unresolvedInstanceReferences._Mypair._Myval2._Myfirst)
              & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 )
          {
            second = (char *)instanceInfo.unresolvedInstanceReferences._Mypair._Myval2._Myfirst[-1].second; /*0x141144fdb*/
            if ( (unsigned __int64)((char *)instanceInfo.unresolvedInstanceReferences._Mypair._Myval2._Myfirst /*0x141144fea*/
                                  - second
                                  - 8) > 0x1F )
              _invalid_parameter_noinfo_noreturn(); /*0x1411450a2*/
          }
          operator delete(ptr: second); /*0x141144ff0*/
          memset(&instanceInfo.unresolvedInstanceReferences, 0, sizeof(instanceInfo.unresolvedInstanceReferences)); /*0x141144ff5*/
        }
        v25 = instanceInfo.parent._Rep; /*0x141145001*/
        if ( instanceInfo.parent._Rep != nullptr /*0x141145017*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&instanceInfo.parent._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v25->_Destroy(this: v25); /*0x14114501f*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v25->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14114502e*/
            v25->_Delete_this(this: v25); /*0x141145036*/
        }
        v26 = instanceInfo.instance._Rep; /*0x141145039*/
        if ( instanceInfo.instance._Rep != nullptr /*0x14114504f*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&instanceInfo.instance._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v26->_Destroy(this: v26); /*0x141145057*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v26->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141145066*/
            v26->_Delete_this(this: v26); /*0x14114506e*/
        }
        std::vector<RBX::Network::PropValuePair>::_Tidy(this: &instanceInfo.propValueList); /*0x141145075*/
      }
      while ( this->offsetIndex < this->metaDataCount ); /*0x141144cd2*/
      v9 = this->invalidOffsetIndex; /*0x141144da1*/
      v10 = DFLog::ReplicationDataCaching; /*0x141144da4*/
      while ( 1 )
      {
        v11 = invalidOffsetIndex; /*0x141144db0*/
        v12 = this->invalidMrdOffsets._Mypair._Myval2._Myfirst; /*0x141144db2*/
        offset = (const void *)v12[v11].offset; /*0x141144db6*/
        if ( this->stream.readOffset != (_DWORD)offset ) /*0x141144dbe*/
          goto LABEL_29; /*0x141144dbe*/
        if ( v10 != 0 )
        {
          FLog::FastLog(
            level: v10,
            message: "[DFLog::ReplicationDataCaching] Skipping offset %u  length : %u",
            arg0: offset,
            arg1: (const void *)v12[v11].length,
            arg2: nullptr);
          v9 = this->invalidOffsetIndex; /*0x141144dde*/
        }
        RBX::Network::NetworkStream::IgnoreBytes( /*0x141144df1*/
          this: &this->stream,
          numberOfBytes: this->invalidMrdOffsets._Mypair._Myval2._Myfirst[v9].length);
        v14 = ++this->invalidOffsetIndex; /*0x141144df9*/
        v15 = this->invalidMrdOffsets._Mypair._Myval2._Myfirst; /*0x141144dfd*/
        v10 = DFLog::ReplicationDataCaching; /*0x141144e0c*/
        if ( v14 < this->invalidMrdOffsets._Mypair._Myval2._Mylast - v15 )
        {
          if ( DFLog::ReplicationDataCaching != 0 )
          {
            FLog::FastLog(
              level: DFLog::ReplicationDataCaching,
              message: "[DFLog::ReplicationDataCaching] Next anticipated read at offset %d  (unless invalid),  next invalid offset : %u",
              arg0: (const void *)this->stream.readOffset,
              arg1: (const void *)v15[v14].length,
              arg2: nullptr);
            goto LABEL_27; /*0x141144e46*/
          }
        }
        else if ( DFLog::ReplicationDataCaching != 0 ) /*0x141144e1a*/
        {
          FLog::FastLog( /*0x141144e26*/
            level: DFLog::ReplicationDataCaching,
            message: "[DFLog::ReplicationDataCaching] No more invalid caches in blob",
            arg0: nullptr);
LABEL_27:
          v10 = DFLog::ReplicationDataCaching; /*0x141144e4b*/
        }
        invalidOffsetIndex = this->invalidOffsetIndex; /*0x141144e52*/
        v9 = invalidOffsetIndex; /*0x141144e55*/
        if ( invalidOffsetIndex >= this->invalidMetaDataCount ) /*0x141144e5b*/
          goto LABEL_29; /*0x141144e5b*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: result); /*0x1431f131e*/
    }
LABEL_63:
    ;
  }
  return result; /*0x141145089*/
}

// END DeserializingJoinDataItemV2 part 1/1, 5 functions
