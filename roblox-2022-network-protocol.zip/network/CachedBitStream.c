// CachedBitStream -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x1410d7490 | Name: ??1CachedBitStream@PhysicsMechanismCache@Network@RBX@@QEAA@XZ
void __fastcall RBX::Network::PhysicsMechanismCache::CachedBitStream::~CachedBitStream(
        RBX::Network::PhysicsMechanismCache::CachedBitStream *this)
{
  RBX::Network::NetworkStream::~NetworkStream(this: &this->bitStream); /*0x1410d7494*/
}

// END CachedBitStream part 1/1, 1 functions
