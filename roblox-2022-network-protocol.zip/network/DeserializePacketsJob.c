// DeserializePacketsJob -- 2022 Studio + full PDB
// tier 3, 7 functions


// Address: 0x14104df00 | Name: ??$reset@VDeserializePacketsJob@Network@RBX@@@?$shared_ptr@VDeserializePacketsJob@Network@RBX@@@std@@QEAAXPEAVDeserializePacketsJob@Network@RBX@@@Z
void __fastcall std::shared_ptr<RBX::Network::DeserializePacketsJob>::reset<RBX::Network::DeserializePacketsJob>(
        std::shared_ptr<RBX::Network::DeserializePacketsJob> *this,
        std::_Ref_count_base_vtbl *_Px)
{
  std::_Ref_count_base *v4; // rbx
  RBX::Network::DeserializePacketsJob *v5; // rax
  std::_Ref_count_base *dtr__Ref_count_base; // rcx
  std::_Ref_count_base *v7; // rdx
  std::_Ref_count_base *v8; // rcx
  std::_Ref_count_base *Rep; // rdi

  v4 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x14104df22*/
  v5 = nullptr; /*0x14104df2a*/
  if ( v4 != nullptr ) /*0x14104df2f*/
  {
    *v4 = 0; /*0x14104df34*/
    v4->_Uses = 1; /*0x14104df37*/
    v4->_Weaks = 1; /*0x14104df3e*/
    v4->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::DeserializePacketsJob>::`vftable'; /*0x14104df4c*/
    v4[1].__vftable = _Px; /*0x14104df4f*/
  }
  else
  {
    v4 = nullptr; /*0x14104df55*/
  }
  if ( _Px != nullptr ) /*0x14104df60*/
  {
    dtr__Ref_count_base = (std::_Ref_count_base *)_Px->dtr__Ref_count_base; /*0x14104df62*/
    if ( dtr__Ref_count_base == nullptr || dtr__Ref_count_base->_Uses == 0 ) /*0x14104df6e*/
    {
      if ( v4 != nullptr ) /*0x14104df73*/
        _InterlockedIncrement((volatile signed __int32 *)&v4->_Uses); /*0x14104df75*/
      v7 = nullptr; /*0x14104df79*/
      if ( v4 != nullptr ) /*0x14104df7f*/
      {
        v5 = (RBX::Network::DeserializePacketsJob *)_Px; /*0x14104df81*/
        _InterlockedIncrement((volatile signed __int32 *)&v4->_Weaks); /*0x14104df84*/
        v7 = v4; /*0x14104df88*/
      }
      _Px->_Delete_this = (void (__fastcall *)(std::_Ref_count_base *))v5; /*0x14104df8b*/
      v8 = (std::_Ref_count_base *)_Px->dtr__Ref_count_base; /*0x14104df8f*/
      _Px->dtr__Ref_count_base = (void (__fastcall *)(std::_Ref_count_base *))v7; /*0x14104df93*/
      if ( v8 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v8->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14104dfa6*/
        v8->_Delete_this(this: v8); /*0x14104dfab*/
      if ( v4 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Uses, 0xFFFFFFFF) == 1 ) /*0x14104dfbd*/
      {
        v4->_Destroy(this: v4); /*0x14104dfc5*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14104dfd1*/
          v4->_Delete_this(this: v4); /*0x14104dfd9*/
      }
    }
  }
  this->_Ptr = (RBX::Network::DeserializePacketsJob *)_Px; /*0x14104dfdd*/
  Rep = this->_Rep; /*0x14104dfe0*/
  this->_Rep = v4; /*0x14104dfe4*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14104dff7*/
  {
    Rep->_Destroy(this: Rep); /*0x14104dfff*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14104e009*/
      Rep->_Delete_this(this: Rep); /*0x14104e011*/
  }
}

// Address: 0x141057c00 | Name: ??0DeserializePacketsJob@Network@RBX@@QEAA@AEAVReplicator@12@@Z
RBX::Network::DeserializePacketsJob *__fastcall RBX::Network::DeserializePacketsJob::DeserializePacketsJob(
        RBX::Network::DeserializePacketsJob *this,
        RBX::Network::Replicator *replicator)
{
  RBX::Graphics::TextureVulkan::DownloadBuffer *v4; // rax
  RBX::Graphics::TextureVulkan::DownloadBuffer *v5; // rdi
  RBX::Graphics::TextureVulkan::DownloadBuffer *v6; // rax
  unsigned __int8 *v7; // rax
  __int64 v8; // rcx
  RBX::DataModel *v9; // rax
  RBX::Graphics::ProfilerAdorn::Item *v10; // rax
  int PairIntValue; // edi
  char *Ptr; // rcx
  char *Data; // rcx
  __int64 expectedPlayerId; // rcx
  RBX::Graphics::ProfilerAdorn::Item *v15; // rax
  int v16; // edi
  char *v17; // rcx
  char *v18; // rcx
  bool v19; // al
  int v20; // ecx
  bool v21; // al
  std::string *v22; // rcx
  unsigned __int64 Mysize; // rax
  RBX::DataModel *v24; // rax
  int v25; // edi
  char *v26; // rcx
  bool v27; // al
  std::string *v28; // rcx
  unsigned __int64 v29; // rdx
  int v30; // edi
  char *v31; // rcx
  RBX::Network::DeserializePacketsJob *result; // rax
  __int64 v33; // [rsp+0h] [rbp-60h] BYREF
  RBX::StringView gamePlayLimiterStringPer100; // [rsp+20h] [rbp-40h] BYREF
  __int64 v35; // [rsp+30h] [rbp-30h]
  unsigned __int64 v36; // [rsp+38h] [rbp-28h]
  std::string v37; // [rsp+40h] [rbp-20h] BYREF
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> v39; // [rsp+98h] [rbp+38h] BYREF

  v4 = (RBX::Graphics::TextureVulkan::DownloadBuffer *)operator new(size: 8u); /*0x141057c23*/
  v5 = v4; /*0x141057c28*/
  v39._Ptr = v4; /*0x141057c2b*/
  if ( v4 != nullptr ) /*0x141057c35*/
    v4->__vftable = (RBX::Graphics::TextureVulkan::DownloadBuffer_vtbl *)RBX::Network::DeserializePacketsJob::DummyArbiter::`vftable'; /*0x141057c3e*/
  else
    v5 = nullptr; /*0x141057c43*/
  __wind /*0xf1c0000000000128*/
  {
    gamePlayLimiterStringPer100 = 0; /*0x141057c49*/
    v39._Ptr = v5; /*0x141057c4e*/
    v6 = (RBX::Graphics::TextureVulkan::DownloadBuffer *)operator new(size: 0x18u); /*0x141057c57*/
    v39._Ptr = v6; /*0x141057c5c*/
    if ( v6 != nullptr ) /*0x141057c63*/
    {
      *(_OWORD *)&v6->__vftable = 0; /*0x141057c68*/
      LODWORD(v6->device) = 1; /*0x141057c6b*/
      HIDWORD(v6->device) = 1; /*0x141057c72*/
      v6->__vftable = (RBX::Graphics::TextureVulkan::DownloadBuffer_vtbl *)std::_Ref_count<RBX::Network::DeserializePacketsJob::DummyArbiter>::`vftable'; /*0x141057c80*/
      v6->resourceListIndex = (unsigned __int64)v5; /*0x141057c83*/
    }
    else
    {
      v6 = nullptr; /*0x141057c89*/
    }
  }
  __unwind
  {
    RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: &v39); /*0xf1c0000000000120*/
  }
  gamePlayLimiterStringPer100.Data = (const char *)v5; /*0x141057c8c*/
  gamePlayLimiterStringPer100.Length = (unsigned __int64)v6; /*0x141057c90*/
  RBX::TaskScheduler::Job::Job( /*0x141057ca8*/
    this,
    name: (const char *)&RBX::Network::DeserializePacketsJob::`vftable'[5],
    arbiter: (std::shared_ptr<RBX::TaskScheduler::Arbiter> *)&gamePlayLimiterStringPer100,
    priority: JobPriority_NotOrderDependent);
  this->__vftable = (RBX::Network::DeserializePacketsJob_vtbl *)RBX::Network::DeserializePacketsJob::`vftable'; /*0x141057cb5*/
  this->accumulatedTimeThisFrame = 0.0; /*0x141057cb8*/
  this->frameOfCurrentCycle = 0; /*0x141057cbf*/
  this->replicator = replicator; /*0x141057cc6*/
  Mtx_init_in_situ_0(a1: (_Mtx_t)&this->mx, a2: 2); /*0x141057cd9*/
  __wind /*0xf1c000000000016c*/
  {
    __wind /*0xf1c0000000000174*/
    {
      __wind /*0xf1c000000000017c*/
      {
        __wind /*0xf1c0000000000184*/
        {
          this->incomingPackets_deprecated._Mypair._Myval2._Myfirst = nullptr; /*0x141057cdf*/
          this->incomingPackets_deprecated._Mypair._Myval2._Mylast = nullptr; /*0x141057ce6*/
          this->incomingPackets_deprecated._Mypair._Myval2._Myend = nullptr; /*0x141057ced*/
          this->incomingPacketsBuffer.itemCapacity = 8; /*0x141057cf4*/
          this->incomingPacketsBuffer.read = 0; /*0x141057cff*/
          this->incomingPacketsBuffer.itemCount = 0; /*0x141057d06*/
          v7 = (unsigned __int8 *)RBX::Memory::allocate(size: 0x40u); /*0x141057d12*/
        }
        __unwind
        {
          __std_terminate(a1: v8, a2: &v33); /*0x142f39fa8*/
        }
        __wind /*0xf1c0000000000160*/
        {
          this->incomingPacketsBuffer.buffer = v7; /*0x141057d17*/
          RBX::Network::NetworkStream::NetworkStream(this: &this->stream); /*0x141057d25*/
          __wind /*0xf1c0000000000140*/
          {
            __wind /*0xf1c0000000000148*/
            {
              this->deserializedPacket.rawPacket = nullptr; /*0x141057d2b*/
              this->deserializedPacket.deserializedItems._Mypair._Myval2._Myfirst = nullptr; /*0x141057d32*/
              this->deserializedPacket.deserializedItems._Mypair._Myval2._Mylast = nullptr; /*0x141057d39*/
              this->deserializedPacket.deserializedItems._Mypair._Myval2._Myend = nullptr; /*0x141057d40*/
              *(_QWORD *)&this->deserializedPacket.itemOffset = 0; /*0x141057d47*/
              *(_WORD *)&this->deserializedPacket.containsJdi = 0; /*0x141057d4e*/
              this->deserializedPacket.processShouldDeserialize = false; /*0x141057d57*/
              this->eventRef = 0; /*0x141057d5e*/
              this->stepStart.sec = 0.0; /*0x141057d65*/
              *(_QWORD *)&this->deserializationLimitMsDuringJoin = 0; /*0x141057d6c*/
              this->deserializingJoinItem.replicator = replicator; /*0x141057d73*/
              this->deserializingJoinItem.joinDataSubItemType = MAX; /*0x141057d7a*/
              RBX::Network::NetworkStream::NetworkStream(this: &this->deserializingJoinItem.stream); /*0x141057d8b*/
              *(_WORD *)&this->deserializingJoinItem.isStillDeserializingCurrentStream = 0; /*0x141057d90*/
              *(_QWORD *)&this->deserializingJoinItem.metaDataCount = 0; /*0x141057d99*/
              *(_QWORD *)&this->deserializingJoinItem.invalidOffsetIndex = 0; /*0x141057da0*/
              this->deserializingJoinItem.invalidMrdOffsets._Mypair._Myval2._Myfirst = nullptr; /*0x141057da7*/
              this->deserializingJoinItem.invalidMrdOffsets._Mypair._Myval2._Mylast = nullptr; /*0x141057dae*/
              this->deserializingJoinItem.invalidMrdOffsets._Mypair._Myval2._Myend = nullptr; /*0x141057db5*/
              this->deserializingJoinItem.childOrderInfo_deprecated._Mypair._Myval2._Myfirst = nullptr; /*0x141057dbc*/
              this->deserializingJoinItem.childOrderInfo_deprecated._Mypair._Myval2._Mylast = nullptr; /*0x141057dc3*/
              this->deserializingJoinItem.childOrderInfo_deprecated._Mypair._Myval2._Myend = nullptr; /*0x141057dca*/
              *(_QWORD *)&this->deserializingJoinItem.lastInstanceOffset = 0; /*0x141057dd1*/
              this->deserializingJoinItem.compressedBitStreamSize = 0.0; /*0x141057dd8*/
              if ( DFInt::NetworkStopProducingPacketsToProcessThresholdMs > 0 ) /*0x141057de7*/
                this->deserializationLimitMsDuringJoin = DFInt::NetworkStopProducingPacketsToProcessThresholdMs; /*0x141057de9*/
              __wind /*0xf1c00000000000bc*/
              {
                if ( DFString::JdiDeserializerConfigPerDC._Mypair._Myval2._Mysize != 0 /*0x141057e08*/
                  && (v9 = RBX::DataModel::get(context: replicator)) != nullptr )
                {
                  __eh34_enter_wind_state(8, 9); /*0xf1c00000000000b4*/
                  gamePlayLimiterStringPer100.Data = (const char *)44; /*0x141057e0e*/
                  v36 = 15; /*0x141057e12*/
                  v35 = 1; /*0x141057e1a*/
                  v10 = RBX::format(result: (RBX::Graphics::ProfilerAdorn::Item *)&v37, fmt: "%d", v9->dataCenterId); /*0x141057e3a*/
                  __eh34_enter_wind_state(9, 10); /*0xf1c00000000000ac*/
                  PairIntValue = RBX::Network::getPairIntValue( /*0x141057e53*/
                                   target: &v10->text,
                                   from: &DFString::JdiDeserializerConfigPerDC,
                                   delimiters: (const std::string *)&gamePlayLimiterStringPer100);
                  if ( v37._Mypair._Myval2._Myres >= 0x10 ) /*0x141057e5d*/
                  {
                    Ptr = v37._Mypair._Myval2._Bx._Ptr; /*0x141057e62*/
                    if ( v37._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141057e70*/
                    {
                      Ptr = *((char **)v37._Mypair._Myval2._Bx._Ptr - 1); /*0x141057e76*/
                      if ( (unsigned __int64)(v37._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141057e85*/
                        _invalid_parameter_noinfo_noreturn(); /*0x141057e87*/
                    }
                    operator delete(ptr: Ptr); /*0x141057e8e*/
                  }
                  v37._Mypair._Myval2._Mysize = 0; /*0x141057e93*/
                  v37._Mypair._Myval2._Myres = 15; /*0x141057e97*/
                  v37._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141057e9f*/
                  if ( v36 >= 0x10 ) /*0x141057eab*/
                  {
                    Data = (char *)gamePlayLimiterStringPer100.Data; /*0x141057eb0*/
                    if ( v36 + 1 >= 0x1000 ) /*0x141057ebe*/
                    {
                      Data = *((char **)gamePlayLimiterStringPer100.Data - 1); /*0x141057ec4*/
                      if ( (unsigned __int64)(gamePlayLimiterStringPer100.Data - (const char *)Data - 8) > 0x1F ) /*0x141057ed3*/
                        _invalid_parameter_noinfo_noreturn(); /*0x141057ed5*/
                    }
                    operator delete(ptr: Data); /*0x141057edc*/
                  }
                  if ( PairIntValue != -1 ) /*0x141057ee4*/
                    this->deserializationLimitMsDuringJoin = PairIntValue; /*0x141057ee6*/
                  if ( __eh34_unwind(10) ) /*0xf1c0000000000098*/
                  {
unwind_state_10:
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v37); /*0xf1c000000000009c*/
                    __eh34_continue_unwinding(10, 9); /*0xf1c00000000000a0*/
                  }
                  __eh34_exit_wind_state(10, 9); /*0xf1c00000000000a4*/
                }
                else
                {
                  __eh34_enter_wind_state(8, 9); /*0xf1c0000000000090*/
                }
                if ( DFString::JdiDeserializerConfigUserIdPer100._Mypair._Myval2._Mysize != 0 ) /*0x141057efe*/
                {
                  expectedPlayerId = replicator->expectedPlayerId; /*0x141057f04*/
                  gamePlayLimiterStringPer100.Data = (const char *)44; /*0x141057f29*/
                  v36 = 15; /*0x141057f2d*/
                  v35 = 1; /*0x141057f35*/
                  v15 = RBX::format( /*0x141057f51*/
                          result: (RBX::Graphics::ProfilerAdorn::Item *)&v37,
                          fmt: "%d",
                          expectedPlayerId % 100);
                  __eh34_enter_wind_state(9, 10); /*0xf1c0000000000088*/
                  v16 = RBX::Network::getPairIntValue( /*0x141057f6a*/
                          target: &v15->text,
                          from: &DFString::JdiDeserializerConfigUserIdPer100,
                          delimiters: (const std::string *)&gamePlayLimiterStringPer100);
                  if ( v37._Mypair._Myval2._Myres >= 0x10 ) /*0x141057f74*/
                  {
                    v17 = v37._Mypair._Myval2._Bx._Ptr; /*0x141057f79*/
                    if ( v37._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141057f87*/
                    {
                      v17 = *((char **)v37._Mypair._Myval2._Bx._Ptr - 1); /*0x141057f8d*/
                      if ( (unsigned __int64)(v37._Mypair._Myval2._Bx._Ptr - v17 - 8) > 0x1F ) /*0x141057f9c*/
                        _invalid_parameter_noinfo_noreturn(); /*0x141057f9e*/
                    }
                    operator delete(ptr: v17); /*0x141057fa5*/
                  }
                  v37._Mypair._Myval2._Mysize = 0; /*0x141057faa*/
                  v37._Mypair._Myval2._Myres = 15; /*0x141057fae*/
                  v37._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141057fb6*/
                  if ( v36 >= 0x10 ) /*0x141057fc2*/
                  {
                    v18 = (char *)gamePlayLimiterStringPer100.Data; /*0x141057fc7*/
                    if ( v36 + 1 >= 0x1000 ) /*0x141057fd5*/
                    {
                      v18 = *((char **)gamePlayLimiterStringPer100.Data - 1); /*0x141057fdb*/
                      if ( (unsigned __int64)(gamePlayLimiterStringPer100.Data - (const char *)v18 - 8) > 0x1F ) /*0x141057fea*/
                        _invalid_parameter_noinfo_noreturn(); /*0x141057fec*/
                    }
                    operator delete(ptr: v18); /*0x141057ff3*/
                  }
                  if ( v16 != -1 ) /*0x141057ffb*/
                    this->deserializationLimitMsDuringJoin = v16; /*0x141057ffd*/
                  if ( __eh34_unwind(10) ) /*0xf1c0000000000134*/
                    goto unwind_state_10; /*0xf1c0000000000134*/
                  __eh34_exit_wind_state(10, 9); /*0xf1c0000000000138*/
                }
                if ( __eh34_unwind(9) ) /*0xf1c0000000000074*/
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&gamePlayLimiterStringPer100); /*0xf1c0000000000078*/
                  __eh34_continue_unwinding(9, 8); /*0xf1c000000000007c*/
                }
                __eh34_exit_wind_state(9, 8); /*0xf1c0000000000080*/
                replicator->joinRxStats.deserializeReportingGroup = this->deserializationLimitMsDuringJoin; /*0x141058009*/
                v19 = replicator->isClientReplicator(this: replicator); /*0x141058015*/
                v20 = DFInt::NetworkInDeserializeLimitGameplayMsRcc; /*0x14105801b*/
                if ( v19 ) /*0x141058023*/
                  v20 = DFInt::NetworkInDeserializeLimitGameplayMsClient; /*0x141058023*/
                this->deserializationLimitMsOngoing = v20; /*0x14105802a*/
                v21 = replicator->isClientReplicator(this: replicator); /*0x141058036*/
                v22 = &DFString::NetworkInDeserializeLimitGameplayMsRccPerDc; /*0x141058043*/
                if ( v21 ) /*0x14105804c*/
                  v22 = &DFString::NetworkInDeserializeLimitGameplayMsClientPerDc; /*0x14105804c*/
                Mysize = v22->_Mypair._Myval2._Mysize; /*0x141058050*/
                if ( v22->_Mypair._Myval2._Myres >= 0x10 ) /*0x141058059*/
                  v22 = (std::string *)v22->_Mypair._Myval2._Bx._Ptr; /*0x14105805b*/
                gamePlayLimiterStringPer100.Data = (const char *)v22; /*0x14105805e*/
                gamePlayLimiterStringPer100.Length = Mysize; /*0x141058062*/
                if ( Mysize != 0 ) /*0x141058069*/
                {
                  v24 = RBX::DataModel::get(context: replicator); /*0x141058072*/
                  if ( v24 != nullptr ) /*0x14105807a*/
                  {
                    v37._Mypair._Myval2._Bx._Ptr = (char *)44; /*0x141058080*/
                    v37._Mypair._Myval2._Myres = 15; /*0x141058084*/
                    v37._Mypair._Myval2._Mysize = 1; /*0x14105808c*/
                    __eh34_enter_wind_state(8, 11); /*0xf1c000000000006c*/
                    v25 = RBX::Network::getPairIntValue( /*0x1410580b6*/
                            target: v24->dataCenterId,
                            from: &gamePlayLimiterStringPer100,
                            delimiter: &v37);
                    if ( __eh34_unwind(11) ) /*0xf1c0000000000060*/
                    {
unwind_state_11:
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v37); /*0xf1c0000000000048*/
                      __eh34_continue_unwinding(11, 8); /*0xf1c000000000004c*/
                    }
                    __eh34_exit_wind_state(11, 8); /*0xf1c0000000000064*/
                    if ( v37._Mypair._Myval2._Myres >= 0x10 ) /*0x1410580c0*/
                    {
                      v26 = v37._Mypair._Myval2._Bx._Ptr; /*0x1410580c5*/
                      if ( v37._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410580d3*/
                      {
                        v26 = *((char **)v37._Mypair._Myval2._Bx._Ptr - 1); /*0x1410580d9*/
                        if ( (unsigned __int64)(v37._Mypair._Myval2._Bx._Ptr - v26 - 8) > 0x1F ) /*0x1410580e8*/
                          _invalid_parameter_noinfo_noreturn(); /*0x1410580ea*/
                      }
                      operator delete(ptr: v26); /*0x1410580f1*/
                    }
                    if ( v25 != -1 ) /*0x1410580f9*/
                      this->deserializationLimitMsOngoing = v25; /*0x1410580fb*/
                  }
                }
                v27 = replicator->isClientReplicator(this: replicator); /*0x141058107*/
                v28 = &DFString::NetworkInDeserializeLimitGameplayMsRccPer100; /*0x141058114*/
                if ( v27 ) /*0x14105811d*/
                  v28 = &DFString::NetworkInDeserializeLimitGameplayMsClientPer100; /*0x14105811d*/
                v29 = v28->_Mypair._Myval2._Mysize; /*0x141058121*/
                if ( v28->_Mypair._Myval2._Myres >= 0x10 ) /*0x14105812a*/
                  v28 = (std::string *)v28->_Mypair._Myval2._Bx._Ptr; /*0x14105812c*/
                gamePlayLimiterStringPer100.Data = (const char *)v28; /*0x14105812f*/
                gamePlayLimiterStringPer100.Length = v29; /*0x141058133*/
                if ( v29 != 0 ) /*0x14105813a*/
                {
                  v37._Mypair._Myval2._Bx._Ptr = (char *)44; /*0x141058140*/
                  v37._Mypair._Myval2._Myres = 15; /*0x141058144*/
                  v37._Mypair._Myval2._Mysize = 1; /*0x14105814c*/
                  __eh34_enter_wind_state(8, 11); /*0xf1c0000000000058*/
                  v30 = RBX::Network::getPairIntValue( /*0x141058195*/
                          target: replicator->expectedPlayerId % 100,
                          from: &gamePlayLimiterStringPer100,
                          delimiter: &v37);
                  if ( __eh34_unwind(11) ) /*0xf1c0000000000044*/
                    goto unwind_state_11; /*0xf1c0000000000044*/
                  __eh34_exit_wind_state(11, 8); /*0xf1c0000000000050*/
                  if ( v37._Mypair._Myval2._Myres >= 0x10 ) /*0x14105819f*/
                  {
                    v31 = v37._Mypair._Myval2._Bx._Ptr; /*0x1410581a4*/
                    if ( v37._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410581b2*/
                    {
                      v31 = *((char **)v37._Mypair._Myval2._Bx._Ptr - 1); /*0x1410581b8*/
                      if ( (unsigned __int64)(v37._Mypair._Myval2._Bx._Ptr - v31 - 8) > 0x1F ) /*0x1410581c7*/
                        _invalid_parameter_noinfo_noreturn(); /*0x1410581c9*/
                    }
                    operator delete(ptr: v31); /*0x1410581d0*/
                  }
                  if ( v30 != -1 ) /*0x1410581d8*/
                    this->deserializationLimitMsOngoing = v30; /*0x1410581da*/
                }
                result = this; /*0x1410581e0*/
              }
              __unwind
              {
                RBX::Network::Replicator::JoinDataItemV2::DeserializingJoinDataItemV2::~DeserializingJoinDataItemV2(this: &this->deserializingJoinItem); /*0x1431e873e*/
              }
            }
            __unwind
            {
              rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: &this->deserializedPacket); /*0x1431e871e*/
            }
          }
          __unwind
          {
            RBX::Network::NetworkStream::~NetworkStream(this: &this->stream); /*0x1431e86fe*/
          }
        }
        __unwind
        {
          RBX::UnboundedCircularBuffer<RakNet::Packet *>::~UnboundedCircularBuffer<RakNet::Packet *>(this: (RBX::UnboundedCircularBuffer<RBX::Time> *)&this->incomingPacketsBuffer); /*0x1431e86de*/
        }
      }
      __unwind
      {
        std::vector<Luau::AstExpr *>::~vector<Luau::AstExpr *>(this: (std::vector<RBX::Graphics::FramebufferVulkan *> *)&this->incomingPackets_deprecated); /*0x1431e86be*/
      }
    }
    __unwind
    {
      std::recursive_mutex::~recursive_mutex(this: (RBX::InstrumentedMutex<std::mutex> *)&this->mx); /*0x1431e869e*/
    }
  }
  __unwind
  {
    RBX::TaskScheduler::Job::~Job(this); /*0xf1c0000000000114*/
  }
  return result; /*0x1410581e3*/
}

// Address: 0x14105ee60 | Name: ??_EDummyArbiter@DeserializePacketsJob@Network@RBX@@UEAAPEAXI@Z
RBX::Network::DeserializePacketsJob::DummyArbiter *__fastcall RBX::Network::DeserializePacketsJob::DummyArbiter::`vector deleting destructor'(
        RBX::Network::DeserializePacketsJob::DummyArbiter *this,
        char a2)
{
  this->__vftable = (RBX::Network::DeserializePacketsJob::DummyArbiter_vtbl *)RBX::TaskScheduler::Arbiter::`vftable'; /*0x14105ee70*/
  if ( (a2 & 1) != 0 ) /*0x14105ee76*/
    operator delete(ptr: this); /*0x14105ee7d*/
  return this; /*0x14105ee85*/
}

// Address: 0x141069c00 | Name: ?getTimeLimitReached@DeserializePacketsJob@Network@RBX@@QEAA_NXZ
bool __fastcall RBX::Network::DeserializePacketsJob::getTimeLimitReached(RBX::Network::DeserializePacketsJob *this)
{
  int deserializationLimitMsOngoing; // edi
  RBX::Time v3; // [rsp+30h] [rbp+8h] BYREF

  if ( this->replicator->gameIsLoaded ) /*0x141069c14*/
    deserializationLimitMsOngoing = this->deserializationLimitMsOngoing; /*0x141069c1d*/
  else
    deserializationLimitMsOngoing = this->deserializationLimitMsDuringJoin; /*0x141069c25*/
  return deserializationLimitMsOngoing != 0 /*0x141069c31*/
      && (RBX::Time::nowFast(result: &v3)->sec - this->stepStart.sec) * 1000.0 + this->accumulatedTimeThisFrame > (double)deserializationLimitMsOngoing;
}

// Address: 0x141072d60 | Name: ?pushIncomingPacket@DeserializePacketsJob@Network@RBX@@QEAAXPEAUPacket@RakNet@@@Z
void __fastcall RBX::Network::DeserializePacketsJob::pushIncomingPacket(
        RBX::Network::DeserializePacketsJob *this,
        RakNet::Packet *packet)
{
  int v4; // eax
  unsigned __int64 itemCount; // rcx
  unsigned __int64 itemCapacity; // rbx
  unsigned __int8 *v7; // r14
  unsigned __int64 read; // rsi
  unsigned __int64 i; // r8
  __int64 v10; // rcx
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v13; // ett
  __int64 v14; // [rsp+0h] [rbp-58h] BYREF
  std::enable_shared_from_this<RBX::TaskScheduler::Job> v15; // [rsp+20h] [rbp-38h] BYREF
  std::unique_lock<std::mutex> lock; // [rsp+30h] [rbp-28h] BYREF

  lock._Pmtx = &this->mx; /*0x141072d7f*/
  lock._Owns = false; /*0x141072d84*/
  v4 = Mtx_lock_0(a1: (_Mtx_t)&this->mx); /*0x141072d89*/
  if ( v4 != 0 ) /*0x141072d90*/
  {
    std::_Throw_C_error(a1: v4); /*0x141072ece*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000014*/
    goto LABEL_17; /*0xf1c0000000000014*/
  }
  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000048*/
  lock._Owns = true; /*0x141072d96*/
  itemCount = this->incomingPacketsBuffer.itemCount; /*0x141072d9b*/
  itemCapacity = this->incomingPacketsBuffer.itemCapacity; /*0x141072da6*/
  if ( itemCount + 1 <= itemCapacity ) /*0x141072db0*/
  {
    read = this->incomingPacketsBuffer.read; /*0x141072e48*/
  }
  else
  {
    do /*0x141072dca*/
      itemCapacity = (3 * itemCapacity) >> 1; /*0x141072dc4*/
    while ( itemCapacity < itemCount + 1 ); /*0x141072dca*/
    __wind /*0xf1c000000000003c*/
    {
      v7 = (unsigned __int8 *)RBX::Memory::allocate(size: 8 * itemCapacity); /*0x141072dd9*/
      read = 0; /*0x141072ddc*/
      for ( i = 0; i < this->incomingPacketsBuffer.itemCount; ++i ) /*0x141072de8*/
        *(_QWORD *)&v7[8 * i] = *(_QWORD *)&this->incomingPacketsBuffer.buffer[8 /*0x141072e0e*/
                                                                             * ((i + this->incomingPacketsBuffer.read)
                                                                              % this->incomingPacketsBuffer.itemCapacity)];
      operator delete(ptr: this->incomingPacketsBuffer.buffer); /*0x141072e25*/
      this->incomingPacketsBuffer.read = 0; /*0x141072e2a*/
      this->incomingPacketsBuffer.itemCapacity = itemCapacity; /*0x141072e31*/
      this->incomingPacketsBuffer.buffer = v7; /*0x141072e38*/
    }
    __unwind
    {
      __std_terminate(a1: v10, a2: &v14); /*0x142f39fa8*/
    }
    itemCount = this->incomingPacketsBuffer.itemCount; /*0x141072e3f*/
  }
  *(_QWORD *)&this->incomingPacketsBuffer.buffer[8 * ((itemCount + read) % itemCapacity)] = packet; /*0x141072e5f*/
  ++this->incomingPacketsBuffer.itemCount; /*0x141072e63*/
  v15 = 0; /*0x141072e6d*/
  Rep = this->_Wptr._Rep; /*0x141072e73*/
  if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x141072e81*/
LABEL_17:
    std::_Throw_bad_weak_ptr(); /*0x141072ed4*/
  while ( 1 ) /*0x141072e86*/
  {
    v13 = Uses; /*0x141072e86*/
    Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x141072e86*/
    if ( v13 == Uses ) /*0x141072e8b*/
      break; /*0x141072e8b*/
    if ( Uses == 0 ) /*0x141072e8f*/
      goto LABEL_17; /*0x141072e8f*/
  }
  v15 = this->std::enable_shared_from_this<RBX::TaskScheduler::Job>; /*0x141072e97*/
  RBX::TaskScheduler::reschedule(job: (std::shared_ptr<RBX::TaskScheduler::Job> *)&v15); /*0x141072eaa*/
  if ( __eh34_unwind(0) ) /*0xf1c000000000001c*/
  {
    std::optional<std::scoped_lock<std::mutex>>::~optional<std::scoped_lock<std::mutex>>(this: (RBX::Soundscape::FlaggedLock *)&lock); /*0xf1c0000000000020*/
    __eh34_propagate_exception_into_caller(0, -1); /*0xf1c0000000000024*/
  }
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000028*/
  Mtx_unlock_0(a1: (_Mtx_t)lock._Pmtx); /*0x141072ec7*/
}

// Address: 0x141084480 | Name: ?step@DeserializePacketsJob@Network@RBX@@EEAA?AW4TaskSchedulerStepResult@3@AEBUStats@Job@TaskScheduler@3@@Z
RBX::TaskSchedulerStepResult __fastcall RBX::Network::DeserializePacketsJob::step(
        RBX::Network::DeserializePacketsJob *this,
        const RBX::TaskScheduler::Job::Stats *stats)
{
  unsigned int v3; // eax
  RBX::Network::Replicator *replicator; // rbx
  double sec; // xmm6_8
  RBX::Time *p_longestFrameTimeForJoinProcessingMs; // rax
  RBX::Network::Replicator *v7; // rbx
  signed int v8; // r8d
  int v9; // ecx
  int deserializationLimitMsOngoing; // eax
  RBX::Time v12; // [rsp+50h] [rbp+8h] BYREF
  RBX::Time v13; // [rsp+60h] [rbp+18h] BYREF
  RBX::Time v14; // [rsp+68h] [rbp+20h] BYREF

  v3 = RBX::TaskScheduler::cycle(); /*0x14108448a*/
  replicator = this->replicator; /*0x14108448f*/
  if ( v3 > this->frameOfCurrentCycle ) /*0x14108449c*/
  {
    this->accumulatedTimeThisFrame = 0.0; /*0x1410844b3*/
    this->frameOfCurrentCycle = v3; /*0x1410844ba*/
    sec = (RBX::TaskScheduler::getLastCycleTimestamp(result: &v12)->sec /*0x1410844d6*/
         - replicator->joinRxStats.lastFrameEndTimeStamp.sec)
        * 1000.0;
    v12.sec = sec; /*0x1410844de*/
    replicator->joinRxStats.lastFrameEndTimeStamp = *(RBX::Time *)&RBX::TaskScheduler::getLastCycleTimestamp(result: &v13)->sec; /*0x1410844ed*/
    if ( !replicator->joinRxStats.frameHasJdiDeserializationWork ) /*0x1410844fc*/
    {
      if ( !replicator->joinRxStats.frameHasJdiProcessWork._Storage._Value ) /*0x141084508*/
      {
LABEL_11:
        v7 = this->replicator; /*0x141084570*/
        if ( RBX::Time::now<0>(result: &v14)->sec - v7->joinRxStats.jdiReportTimer.start.sec > (double)DFInt::NetJdiProcessReportingIntervalSeconds ) /*0x1410845a2*/
        {
          if ( v7->joinRxStats.framesWithJoinData != 0 ) /*0x1410845aa*/
          {
            v8 = (unsigned int)RBX::globalRand() % 0x64; /*0x1410845c2*/
            v9 = DFInt::ReplicatorJdiReportThrottlePercent; /*0x1410845c5*/
            if ( v7->streamingEnabled ) /*0x1410845cb*/
              v9 = DFInt::ReplicatorJdiReportThrottlePercentStreamingEnabled; /*0x1410845d2*/
            if ( v8 < v9 ) /*0x1410845dc*/
              RBX::Network::Replicator::reportFrameDataWithJoinData(this: v7); /*0x1410845e1*/
          }
          RBX::Time::now<0>(result: &v13); /*0x1410845eb*/
          v7->joinRxStats.jdiReportTimer.start = v13; /*0x1410845f6*/
          *(_QWORD *)&v7->joinRxStats.framesWithJoinData = 0; /*0x1410845fe*/
          v7->joinRxStats.framesWithJDIUnder60Fps = 0; /*0x141084605*/
          v7->joinRxStats.longestFrameTimeForJoinProcessingMs = 0.0; /*0x14108460b*/
          v7->joinRxStats.cumulativeTimeUnder60FpsMsFramesWithJDI = 0.0; /*0x141084612*/
        }
        replicator = this->replicator; /*0x141084619*/
        goto LABEL_19; /*0x141084619*/
      }
      sec = v12.sec; /*0x14108450a*/
    }
    ++replicator->joinRxStats.framesWithJoinData; /*0x141084510*/
    if ( sec > (double)DFInt::NetworkJDIReadProcessReportingThresholdMs ) /*0x141084526*/
      ++replicator->joinRxStats.framesWithJoinDataOverThreshold; /*0x141084528*/
    p_longestFrameTimeForJoinProcessingMs = &v12; /*0x141084541*/
    if ( sec <= replicator->joinRxStats.longestFrameTimeForJoinProcessingMs ) /*0x141084546*/
      p_longestFrameTimeForJoinProcessingMs = (RBX::Time *)&replicator->joinRxStats.longestFrameTimeForJoinProcessingMs; /*0x141084546*/
    replicator->joinRxStats.longestFrameTimeForJoinProcessingMs = p_longestFrameTimeForJoinProcessingMs->sec; /*0x141084551*/
    if ( sec > 16.5 ) /*0x141084554*/
    {
      ++replicator->joinRxStats.framesWithJDIUnder60Fps; /*0x141084556*/
      replicator->joinRxStats.cumulativeTimeUnder60FpsMsFramesWithJDI = sec /*0x141084568*/
                                                                      - 16.5
                                                                      + replicator->joinRxStats.cumulativeTimeUnder60FpsMsFramesWithJDI;
    }
    goto LABEL_11; /*0x141084568*/
  }
  if ( replicator->gameIsLoaded ) /*0x14108463a*/
    deserializationLimitMsOngoing = this->deserializationLimitMsOngoing; /*0x141084643*/
  else
    deserializationLimitMsOngoing = this->deserializationLimitMsDuringJoin; /*0x14108464b*/
  if ( (double)deserializationLimitMsOngoing <= 0.0 /*0x14108466e*/
    || this->accumulatedTimeThisFrame <= (double)deserializationLimitMsOngoing )
  {
LABEL_19:
    replicator->joinRxStats.frameHasJdiDeserializationWork = false; /*0x141084625*/
    return RBX::Network::DeserializePacketsJob::stepGranular(this); /*0x141084635*/
  }
  return TaskSchedulerStepped; /*0x14108462f*/
}

// Address: 0x141084780 | Name: ?stepGranular@DeserializePacketsJob@Network@RBX@@AEAA?AW4TaskSchedulerStepResult@3@XZ
__int64 __fastcall RBX::Network::DeserializePacketsJob::stepGranular(RBX::Network::DeserializePacketsJob *this)
{
  bool v2; // bl
  unsigned __int64 v3; // rax
  _Mtx_internal_imp_t *p_mx; // r12
  int v5; // eax
  bool Owns; // bl
  unsigned int v7; // r14d
  RBX::Network::ProcessingPacket *p_deserializedPacket; // r15
  unsigned __int64 itemCapacity; // r10
  unsigned __int64 read; // rtt
  unsigned __int8 *buffer; // rcx
  RBX::Network::NetworkStream *v12; // r13
  std::vector<unsigned char> *p_dataVector; // rdi
  std::vector<unsigned char> *v14; // rbx
  unsigned __int8 *Myfirst; // rcx
  unsigned __int8 *v16; // rcx
  int deserializationLimitMsOngoing; // ebx
  char v18; // cl
  RBX::Network::Replicator *v19; // rbx
  RakNet::Packet *rawPacket; // rax
  rbx::timestamped_safe_queue<RBX::Network::ProcessingPacket> *p_packetQueue; // r13
  std::vector<std::shared_ptr<RBX::Network::DeserializedItem>> *p_deserializedItems; // r12
  std::shared_ptr<RBX::Network::DeserializedItem> *v23; // rdi
  std::shared_ptr<RBX::Network::DeserializedItem> *v24; // rax
  volatile signed __int32 *Rep; // rbx
  bool processShouldDeserialize; // cl
  boost::detail::spinlock *p_m; // rax
  unsigned __int64 Mysize; // rcx
  unsigned __int64 Mapsize; // rbx
  unsigned __int64 v30; // rbx
  unsigned __int64 v31; // rax
  unsigned __int64 v32; // rbx
  rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket> **Map; // rax
  rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket> *v34; // rbx
  std::shared_ptr<RBX::Network::DeserializedItem> *v35; // rdi
  volatile signed __int32 *v36; // rbx
  std::shared_ptr<RBX::Network::DeserializedItem> *v37; // rax
  rbx::timestamped_safe_queue<RBX::Network::ProcessingPacket> *p_deserializedPackets_deprecated; // r13
  std::shared_ptr<RBX::Network::DeserializedItem> *v39; // rdi
  std::shared_ptr<RBX::Network::DeserializedItem> *v40; // r12
  std::shared_ptr<RBX::Network::DeserializedItem> *v41; // rcx
  signed __int64 v42; // rdi
  __int64 v43; // rax
  boost::detail::spinlock *sp; // rax
  unsigned __int64 v45; // rdx
  unsigned __int64 v46; // rcx
  unsigned __int64 v47; // rcx
  unsigned __int64 v48; // rax
  unsigned __int64 v49; // r12
  rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket> **v50; // rax
  rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket> *v51; // r12
  std::shared_ptr<RBX::Network::DeserializedItem> *v52; // rdi
  unsigned __int64 v53; // rbx
  VkVertexInputAttributeDescription *v54; // rax
  char *v55; // rcx
  signed __int64 v56; // rdi
  __int64 v57; // rax
  std::shared_ptr<RBX::Network::DeserializedItem> *v58; // rdi
  std::shared_ptr<RBX::Network::DeserializedItem> *v59; // r12
  volatile signed __int32 *v60; // rbx
  std::shared_ptr<RBX::Network::DeserializedItem> *v61; // rax
  std::shared_ptr<RBX::Network::DeserializedItem> *v62; // rdi
  std::shared_ptr<RBX::Network::DeserializedItem> *v63; // rbx
  RBX::Network::NetworkStream *v64; // r13
  std::vector<unsigned char> *v65; // rdi
  std::vector<unsigned char> *v66; // rbx
  unsigned __int8 *v67; // rcx
  char *v68; // rdi
  std::shared_ptr<RBX::File> *i; // rbx
  std::shared_ptr<RBX::File> *v70; // r15
  char *v71; // rax
  int v72; // eax
  RBX::Network::Replicator *replicator; // rax
  RBX::Time *p_totalTimeUsedThisFrame; // rax
  __int64 v75; // rcx
  bool value; // bl
  unsigned __int64 Token; // rax
  unsigned __int64 v79; // rdi
  __int64 v80; // [rsp+0h] [rbp-100h] BYREF
  std::unique_lock<std::mutex> lock; // [rsp+20h] [rbp-E0h] BYREF
  RBX::Profiler::PotentialTelemetryScope profscope772; // [rsp+30h] [rbp-D0h] BYREF
  RBX::Network::ProcessingPacket v83; // [rsp+50h] [rbp-B0h] BYREF
  RBX::Time v84; // [rsp+80h] [rbp-80h] BYREF
  RBX::Network::ProcessingPacket __that; // [rsp+88h] [rbp-78h] BYREF
  RBX::Network::Replicator *v86; // [rsp+B8h] [rbp-48h]
  boost::detail::spinlock::scoped_lock v87; // [rsp+C0h] [rbp-40h] BYREF
  RBX::Time v88; // [rsp+C8h] [rbp-38h] BYREF
  _QWORD _Right[4]; // [rsp+D0h] [rbp-30h] BYREF
  __int64 v90; // [rsp+F0h] [rbp-10h]
  __int16 v91; // [rsp+F8h] [rbp-8h]
  bool v92; // [rsp+FAh] [rbp-6h]
  RBX::Time v93; // [rsp+100h] [rbp+0h] BYREF
  RBX::Time v94; // [rsp+108h] [rbp+8h] BYREF
  RBX::Time v95; // [rsp+110h] [rbp+10h] BYREF
  RBX::Network::NetworkStream v96; // [rsp+118h] [rbp+18h] BYREF
  RBX::Network::ProcessingPacket v97; // [rsp+158h] [rbp+58h] BYREF
  RBX::Time v98; // [rsp+188h] [rbp+88h] BYREF
  RBX::Network::NetworkStream v99; // [rsp+190h] [rbp+90h] BYREF
  char v100; // [rsp+1D8h] [rbp+D8h] BYREF
  RakNet::Packet *v101; // [rsp+260h] [rbp+160h]
  char v102; // [rsp+260h] [rbp+160h]
  std::shared_ptr<RBX::Network::DeserializedItem> *Mylast; // [rsp+268h] [rbp+168h]
  std::shared_ptr<RBX::Network::DeserializedItem> *v104; // [rsp+268h] [rbp+168h]
  long double totalTimeUsedThisFrame; // [rsp+270h] [rbp+170h] BYREF
  boost::detail::spinlock::scoped_lock v106; // [rsp+278h] [rbp+178h] BYREF

  if ( __TSS0__1__stepGranular_DeserializePacketsJob_Network_RBX__AEAA_AW4TaskSchedulerStepResult_4_XZ_4HA > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x1410847c9*/
  {
    Init_thread_header(pOnce: &__TSS0__1__stepGranular_DeserializePacketsJob_Network_RBX__AEAA_AW4TaskSchedulerStepResult_4_XZ_4HA); /*0x14108552c*/
    if ( __TSS0__1__stepGranular_DeserializePacketsJob_Network_RBX__AEAA_AW4TaskSchedulerStepResult_4_XZ_4HA == -1 ) /*0x141085538*/
    {
      __wind /*0xf1c000000000002c*/
      {
        value = DFFlag::EnablePerfDataSubsystemTimersCollection2.value; /*0x14108553e*/
        Token = RBX::Profiler::getToken(group: "Network", name: "deserializePacket", color: -1); /*0x141085559*/
        v79 = Token; /*0x14108555e*/
        if ( value && DFFlag::EnablePerfDataCoreTimersCollection2.value ) /*0x14108556c*/
          RBX::Profiler::PerFrameTelemetry::activateForTelemetry(token: Token); /*0x141085571*/
        `RBX::Network::DeserializePacketsJob::stepGranular'::`2'::proftoken772 = v79; /*0x141085576*/
      }
      __unwind
      {
        Init_thread_abort(pOnce: &__TSS0__1__stepGranular_DeserializePacketsJob_Network_RBX__AEAA_AW4TaskSchedulerStepResult_4_XZ_4HA); /*0x1431eb027*/
      }
      Init_thread_footer(pOnce: &__TSS0__1__stepGranular_DeserializePacketsJob_Network_RBX__AEAA_AW4TaskSchedulerStepResult_4_XZ_4HA); /*0x141085584*/
    }
  }
  v2 = DFFlag::EnablePerfDataSubsystemTimersCollection2.value; /*0x1410847cf*/
  profscope772.region.token = `RBX::Network::DeserializePacketsJob::stepGranular'::`2'::proftoken772; /*0x1410847dd*/
  if ( FFlag::g_flagsLoaded && DFFlag::TelemetryScopeOverhead.value ) /*0x1410847f2*/
  {
    profscope772.isFlagEnabled = true; /*0x1410847f4*/
    v3 = RBX::Profiler::PerFrameTelemetry::enterTelemetryRegion( /*0x141084802*/
           token: `RBX::Network::DeserializePacketsJob::stepGranular'::`2'::proftoken772,
           mpTimestamp: &profscope772.mpTimestamp,
           enabled: DFFlag::EnablePerfDataSubsystemTimersCollection2.value);
  }
  else
  {
    profscope772.isFlagEnabled = false; /*0x141084809*/
    v3 = RBX::Profiler::PerFrameTelemetry::enterTelemetryRegion_deprecated( /*0x141084813*/
           token: `RBX::Network::DeserializePacketsJob::stepGranular'::`2'::proftoken772,
           mpTimestamp: &profscope772.mpTimestamp);
  }
  profscope772.region.timestamp = v3; /*0x141084818*/
  profscope772.isEnabled = v2; /*0x14108481d*/
  __wind /*0xf1c0000000000114*/
  {
    this->stepStart = *(RBX::Time *)&RBX::Time::nowFast(result: &v88)->sec; /*0x14108482e*/
    totalTimeUsedThisFrame = 0.0; /*0x141084839*/
    p_mx = (_Mtx_internal_imp_t *)&this->mx; /*0x141084841*/
    lock._Pmtx = &this->mx; /*0x141084848*/
    lock._Owns = false; /*0x14108484d*/
    v5 = Mtx_lock_0(a1: (_Mtx_t)&this->mx); /*0x141084855*/
    if ( v5 != 0 ) /*0x14108485c*/
    {
      std::_Throw_C_error(a1: v5); /*0x141085590*/
      __eh34_enter_wind_state(1, 2); /*0xf1c0000000000018*/
LABEL_165:
      std::_Throw_C_error(a1: v72); /*0x141085596*/
      JUMPOUT(0x14108559DLL); /*0x14108559d*/
    }
    Owns = true; /*0x141084862*/
    lock._Owns = true; /*0x141084864*/
    __eh34_enter_wind_state(1, 2); /*0xf1c000000000010c*/
    v7 = 0; /*0x141084868*/
    while ( this->stream.numberOfBytesUsed != this->stream.readOffset || this->incomingPacketsBuffer.itemCount != 0 ) /*0x141084896*/
    {
      p_deserializedPacket = &this->deserializedPacket; /*0x14108489c*/
      if ( this->deserializedPacket.rawPacket == nullptr && this->incomingPacketsBuffer.itemCount != 0 ) /*0x1410848b5*/
      {
        itemCapacity = this->incomingPacketsBuffer.itemCapacity; /*0x1410848c2*/
        read = this->incomingPacketsBuffer.read; /*0x1410848ce*/
        buffer = this->incomingPacketsBuffer.buffer; /*0x1410848d4*/
        this->incomingPacketsBuffer.read = (read + 1) % itemCapacity; /*0x1410848e4*/
        v101 = *(RakNet::Packet **)&buffer[8 * (read % itemCapacity)]; /*0x1410848ef*/
        --this->incomingPacketsBuffer.itemCount; /*0x1410848f6*/
        v12 = RBX::Network::NetworkStream::NetworkStream( /*0x141084911*/
                this: &v96,
                _data: v101->data,
                lengthInBytes: v101->length,
                copyData: false);
        this->stream.isJoinData = v12->isJoinData; /*0x141084918*/
        this->stream.data = v12->data; /*0x141084922*/
        p_dataVector = &v12->dataVector; /*0x141084929*/
        v14 = &this->stream.dataVector; /*0x14108492d*/
        if ( &this->stream.dataVector != &v12->dataVector ) /*0x141084937*/
        {
          Myfirst = v14->_Mypair._Myval2._Myfirst; /*0x141084939*/
          if ( v14->_Mypair._Myval2._Myfirst != nullptr ) /*0x14108493f*/
          {
            if ( (unsigned __int8 *)(this->stream.dataVector._Mypair._Myval2._Myend - Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x14108494f*/
            {
              if ( (unsigned __int64)&Myfirst[-*((_QWORD *)Myfirst - 1) - 8] > 0x1F ) /*0x141084964*/
                goto LABEL_137; /*0x141084964*/
              Myfirst = *((unsigned __int8 **)Myfirst - 1); /*0x14108496a*/
            }
            operator delete(ptr: Myfirst); /*0x14108496d*/
            v14->_Mypair._Myval2._Myfirst = nullptr; /*0x141084972*/
            this->stream.dataVector._Mypair._Myval2._Mylast = nullptr; /*0x141084975*/
            this->stream.dataVector._Mypair._Myval2._Myend = nullptr; /*0x141084979*/
          }
          v14->_Mypair._Myval2._Myfirst = p_dataVector->_Mypair._Myval2._Myfirst; /*0x141084980*/
          this->stream.dataVector._Mypair._Myval2._Mylast = v12->dataVector._Mypair._Myval2._Mylast; /*0x141084987*/
          this->stream.dataVector._Mypair._Myval2._Myend = v12->dataVector._Mypair._Myval2._Myend; /*0x14108498f*/
          p_dataVector->_Mypair._Myval2._Myfirst = nullptr; /*0x141084993*/
          v12->dataVector._Mypair._Myval2._Mylast = nullptr; /*0x141084996*/
          v12->dataVector._Mypair._Myval2._Myend = nullptr; /*0x14108499a*/
        }
        this->stream.numberOfBytesUsed = v12->numberOfBytesUsed; /*0x1410849a2*/
        this->stream.numberOfBytesAllocated = v12->numberOfBytesAllocated; /*0x1410849ac*/
        this->stream.readOffset = v12->readOffset; /*0x1410849b6*/
        this->stream.ownedData = v12->ownedData; /*0x1410849c1*/
        v16 = v96.dataVector._Mypair._Myval2._Myfirst; /*0x1410849c7*/
        if ( v96.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x1410849ce*/
        {
          if ( (unsigned __int8 *)(v96.dataVector._Mypair._Myval2._Myend - v96.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x1410849e1*/
          {
            v16 = *((unsigned __int8 **)v96.dataVector._Mypair._Myval2._Myfirst - 1); /*0x1410849e7*/
            if ( (unsigned __int64)(v96.dataVector._Mypair._Myval2._Myfirst - v16 - 8) > 0x1F ) /*0x1410849f6*/
LABEL_137:
              _invalid_parameter_noinfo_noreturn(); /*0x141085341*/
          }
          operator delete(ptr: v16); /*0x1410849fc*/
          memset(&v96.dataVector, 0, sizeof(v96.dataVector)); /*0x141084a01*/
        }
        v96.__vftable = (RBX::Network::NetworkStream_vtbl *)RakNet::AbstractBitStream::`vftable'; /*0x141084a14*/
        p_deserializedPacket->rawPacket = v101; /*0x141084a1f*/
        if ( &this->deserializedPacket.deserializedItems != (std::vector<std::shared_ptr<RBX::Network::DeserializedItem>> *)&v100 ) /*0x141084a30*/
        {
          std::vector<std::shared_ptr<RBX::GuiBase>>::~vector<std::shared_ptr<RBX::GuiBase>>(this: (std::vector<std::shared_ptr<RBX::Graphics::PersistentBufferVulkan>> *)&this->deserializedPacket.deserializedItems); /*0x141084a35*/
          this->deserializedPacket.deserializedItems._Mypair._Myval2._Myfirst = nullptr; /*0x141084a3a*/
          this->deserializedPacket.deserializedItems._Mypair._Myval2._Mylast = nullptr; /*0x141084a3d*/
          this->deserializedPacket.deserializedItems._Mypair._Myval2._Myend = nullptr; /*0x141084a41*/
        }
        *(_QWORD *)&this->deserializedPacket.itemOffset = 0; /*0x141084a45*/
        *(_WORD *)&this->deserializedPacket.containsJdi = 0; /*0x141084a49*/
        this->deserializedPacket.processShouldDeserialize = false; /*0x141084a50*/
        this->replicator->deserializingPacketInfo.frameWhenPacketAddedToDeserializationQueue = v101->cycleReceivedByApplication; /*0x141084a5f*/
        this->replicator->deserializingPacketInfo.timeWhenPacketAddedToDeserializationQueue = v101->timePopped; /*0x141084a70*/
        if ( !this->replicator->isServerReplicator(this: this->replicator) ) /*0x141084a89*/
          RBX::AvatarProfiler::logNetPacketProcessBegin( /*0x141084aa0*/
            pkt: p_deserializedPacket->rawPacket,
            dataID: *p_deserializedPacket->rawPacket->data,
            dataSize: p_deserializedPacket->rawPacket->length,
            outRef: &this->eventRef);
      }
      if ( this->replicator->gameIsLoaded ) /*0x141084aac*/
        deserializationLimitMsOngoing = this->deserializationLimitMsOngoing; /*0x141084ab5*/
      else
        deserializationLimitMsOngoing = this->deserializationLimitMsDuringJoin; /*0x141084abd*/
      if ( deserializationLimitMsOngoing != 0 /*0x141084b09*/
        && (RBX::Time::nowFast(result: &v93)->sec - this->stepStart.sec) * 1000.0 + this->accumulatedTimeThisFrame > (double)deserializationLimitMsOngoing
        || this->replicator->deserializePacketLimitReached(this: this->replicator) )
      {
        totalTimeUsedThisFrame = (RBX::Time::nowFast(result: &v94)->sec - this->stepStart.sec) * 1000.0 /*0x14108537e*/
                               + this->accumulatedTimeThisFrame;
        replicator = this->replicator; /*0x141085386*/
        if ( !replicator->gameIsLoaded ) /*0x141085394*/
        {
          _InterlockedExchange64( /*0x1410853df*/
            (volatile __int64 *)&this->replicator->joinRxStats.cumulativeDeserializeWithJdiOverThrottleMs,
            COERCE__INT64(
              totalTimeUsedThisFrame
            - (double)this->deserializationLimitMsDuringJoin
            + replicator->joinRxStats.cumulativeDeserializeWithJdiOverThrottleMs._Storage._Value));
          v88.sec = this->replicator->joinRxStats.maxDeserializeWithJdiOverThrottleMs._Storage._Value; /*0x141085404*/
          p_totalTimeUsedThisFrame = (RBX::Time *)&totalTimeUsedThisFrame; /*0x141085409*/
          if ( totalTimeUsedThisFrame <= v88.sec ) /*0x141085420*/
            p_totalTimeUsedThisFrame = &v88; /*0x141085420*/
          _InterlockedExchange64( /*0x14108543e*/
            (volatile __int64 *)&this->replicator->joinRxStats.maxDeserializeWithJdiOverThrottleMs,
            *(_QWORD *)&p_totalTimeUsedThisFrame->sec);
          _InterlockedExchange( /*0x14108545c*/
            (volatile __int32 *)&this->replicator->joinRxStats.framesWithDeserializeWithJdiOverThrottle,
            this->replicator->joinRxStats.framesWithDeserializeWithJdiOverThrottle._Storage._Value + 1);
          p_mx = (_Mtx_internal_imp_t *)lock._Pmtx; /*0x141085462*/
        }
        Owns = lock._Owns; /*0x141085467*/
        break; /*0x141085467*/
      }
      if ( p_mx == nullptr ) /*0x141084b1a*/
        std::_Throw_system_error(_Errno: operation_not_permitted); /*0x14108551f*/
      Mtx_unlock_0(a1: p_mx); /*0x141084b23*/
      Owns = false; /*0x141084b28*/
      lock._Owns = false; /*0x141084b2a*/
      if ( !RBX::Network::Replicator::deserializeStreamAsync( /*0x141084b4d*/
              this: this->replicator,
              stream: &this->stream,
              itemType: &this->itemType,
              deserializedPacket: &this->deserializedPacket) )
        goto LABEL_173; /*0x141084b4d*/
      if ( this->stream.numberOfBytesUsed == this->stream.readOffset /*0x141084b61*/
        || this->deserializedPacket.processShouldDeserialize )
      {
        v18 = 1; /*0x141084b6d*/
        this->deserializedPacket.shouldDelete = true; /*0x141084b6f*/
      }
      else
      {
        v18 = 0; /*0x141084b69*/
      }
      v102 = v18; /*0x141084b75*/
      if ( this->deserializedPacket.deserializedItems._Mypair._Myval2._Myfirst != this->deserializedPacket.deserializedItems._Mypair._Myval2._Mylast /*0x141084b8d*/
        || v18 != 0 )
      {
        v19 = this->replicator; /*0x141084b93*/
        v86 = v19; /*0x141084b9a*/
        rawPacket = p_deserializedPacket->rawPacket; /*0x141084ba1*/
        if ( v19->refactorReceiveQueueCached ) /*0x141084ba4*/
        {
          p_packetQueue = &v19->packetQueue; /*0x141084bb1*/
          memset(&__that.deserializedItems, 0, sizeof(__that.deserializedItems)); /*0x141084bb8*/
          __that.rawPacket = rawPacket; /*0x141084bc1*/
          p_deserializedItems = &this->deserializedPacket.deserializedItems; /*0x141084bc5*/
          if ( &__that.deserializedItems != &this->deserializedPacket.deserializedItems ) /*0x141084bd0*/
          {
            __that.deserializedItems._Mypair._Myval2._Myfirst = p_deserializedItems->_Mypair._Myval2._Myfirst; /*0x141084bd6*/
            __that.deserializedItems._Mypair._Myval2._Mylast = this->deserializedPacket.deserializedItems._Mypair._Myval2._Mylast; /*0x141084bdf*/
            __that.deserializedItems._Mypair._Myval2._Myend = this->deserializedPacket.deserializedItems._Mypair._Myval2._Myend; /*0x141084be8*/
            p_deserializedItems->_Mypair._Myval2._Myfirst = nullptr; /*0x141084bec*/
            this->deserializedPacket.deserializedItems._Mypair._Myval2._Mylast = nullptr; /*0x141084bf0*/
            this->deserializedPacket.deserializedItems._Mypair._Myval2._Myend = nullptr; /*0x141084bf5*/
          }
          __that.itemOffset = this->deserializedPacket.itemOffset; /*0x141084bfe*/
          Mylast = this->deserializedPacket.deserializedItems._Mypair._Myval2._Mylast; /*0x141084c06*/
          v23 = p_deserializedItems->_Mypair._Myval2._Myfirst; /*0x141084c0d*/
          if ( p_deserializedItems->_Mypair._Myval2._Myfirst != Mylast ) /*0x141084c14*/
          {
            v24 = this->deserializedPacket.deserializedItems._Mypair._Myval2._Mylast; /*0x141084c16*/
            do /*0x141084c66*/
            {
              Rep = (volatile signed __int32 *)v23->_Rep; /*0x141084c20*/
              if ( Rep != nullptr ) /*0x141084c27*/
              {
                if ( _InterlockedExchangeAdd(Rep + 2, 0xFFFFFFFF) == 1 ) /*0x141084c36*/
                {
                  (**(void (__fastcall ***)(volatile signed __int32 *))Rep)(a1: Rep); /*0x141084c3e*/
                  if ( _InterlockedExchangeAdd(Rep + 3, 0xFFFFFFFF) == 1 ) /*0x141084c4d*/
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)Rep + 8LL))(a1: Rep); /*0x141084c55*/
                }
                v24 = Mylast; /*0x141084c58*/
              }
              ++v23; /*0x141084c5f*/
            }
            while ( v23 != v24 ); /*0x141084c66*/
            v23 = p_deserializedItems->_Mypair._Myval2._Myfirst; /*0x141084c68*/
          }
          this->deserializedPacket.deserializedItems._Mypair._Myval2._Mylast = v23; /*0x141084c6c*/
          this->deserializedPacket.itemOffset = 0; /*0x141084c71*/
          processShouldDeserialize = this->deserializedPacket.processShouldDeserialize; /*0x141084c79*/
          if ( this->deserializedPacket.deserializationProgress != 0 ) /*0x141084c80*/
          {
            __that.deserializationProgress = this->deserializedPacket.deserializationProgress; /*0x141084c82*/
          }
          else if ( processShouldDeserialize || p_deserializedPacket->rawPacket == nullptr ) /*0x141084c91*/
          {
            __that.deserializationProgress = 0; /*0x141084c9b*/
          }
          else
          {
            __that.deserializationProgress = p_deserializedPacket->rawPacket->length; /*0x141084c96*/
          }
          __that.containsJdi = this->deserializedPacket.containsJdi; /*0x141084ca4*/
          __that.shouldDelete = this->deserializedPacket.shouldDelete; /*0x141084cac*/
          __that.processShouldDeserialize = processShouldDeserialize; /*0x141084caf*/
          __wind /*0xf1c0000000000100*/
          {
            RBX::Network::ProcessingPacket::ProcessingPacket(this: &v97, &__that); /*0x141084cba*/
            __wind /*0xf1c00000000000c4*/
            {
              RBX::Time::now<0>(result: &v98); /*0x141084cc7*/
            }
            __unwind
            {
              rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: &v97); /*0xf1c00000000000d4*/
            }
            __wind /*0xf1c00000000000dc*/
            {
              p_m = (boost::detail::spinlock *)&p_packetQueue->m; /*0x141084ccd*/
              v106.sp_ = (boost::detail::spinlock *)&p_packetQueue->m; /*0x141084cd1*/
              while ( _InterlockedExchange(&p_m->v_, 1) != 0 ) /*0x141084cee*/
                p_m = v106.sp_; /*0x141084cf0*/
              Mysize = p_packetQueue->queue._Mypair._Myval2._Mysize; /*0x141084cf9*/
              if ( Mysize == 0 ) /*0x141084d00*/
                p_packetQueue->headTimestamp = v98.sec; /*0x141084d0a*/
              __wind /*0xf1c00000000000b8*/
              {
                Mapsize = p_packetQueue->queue._Mypair._Myval2._Mapsize; /*0x141084d10*/
                if ( Mapsize <= Mysize + 1 ) /*0x141084d1b*/
                {
                  std::deque<rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>>::_Growmap( /*0x141084d25*/
                    this: (std::deque<webrtc::BitrateProber::ProbeCluster> *)p_packetQueue,
                    _Count: 1u);
                  Mysize = p_packetQueue->queue._Mypair._Myval2._Mysize; /*0x141084d2a*/
                  Mapsize = p_packetQueue->queue._Mypair._Myval2._Mapsize; /*0x141084d2e*/
                }
                v30 = Mapsize - 1; /*0x141084d32*/
                v31 = p_packetQueue->queue._Mypair._Myval2._Myoff & v30; /*0x141084d38*/
                p_packetQueue->queue._Mypair._Myval2._Myoff = v31; /*0x141084d3c*/
                v32 = (Mysize + v31) & v30; /*0x141084d43*/
                Map = p_packetQueue->queue._Mypair._Myval2._Map; /*0x141084d46*/
                if ( Map[v32] == nullptr ) /*0x141084d4f*/
                {
                  p_packetQueue->queue._Mypair._Myval2._Map[v32] = (rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket> *)operator new(size: 0x38u); /*0x141084d5f*/
                  Map = v86->packetQueue.queue._Mypair._Myval2._Map; /*0x141084d67*/
                }
                v34 = Map[v32]; /*0x141084d6e*/
                RBX::Network::ProcessingPacket::ProcessingPacket(this: &v34->value, __that: &v97); /*0x141084d79*/
                v34->timestamp = v98; /*0x141084d86*/
                ++p_packetQueue->queue._Mypair._Myval2._Mysize; /*0x141084d8b*/
              }
              __unwind
              {
                rbx::spin_mutex::scoped_lock::~scoped_lock(this: &v106); /*0xf1c00000000000b0*/
              }
              v106.sp_->v_ = 0; /*0x141084d97*/
              std::vector<std::shared_ptr<RBX::GuiBase>>::~vector<std::shared_ptr<RBX::GuiBase>>(this: (std::vector<std::shared_ptr<RBX::Graphics::PersistentBufferVulkan>> *)&v97.deserializedItems); /*0x141084d9e*/
            }
            __unwind
            {
              rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: &v97); /*0xf1c00000000000ec*/
            }
          }
          __unwind
          {
            rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: &__that); /*0xf1c00000000000f8*/
          }
          v35 = __that.deserializedItems._Mypair._Myval2._Myfirst; /*0x141084da4*/
          if ( __that.deserializedItems._Mypair._Myval2._Myfirst != nullptr ) /*0x141084dab*/
          {
            if ( __that.deserializedItems._Mypair._Myval2._Myfirst != __that.deserializedItems._Mypair._Myval2._Mylast ) /*0x141084db5*/
            {
              do /*0x141084df7*/
              {
                v36 = (volatile signed __int32 *)v35->_Rep; /*0x141084db7*/
                if ( v36 != nullptr && _InterlockedExchangeAdd(v36 + 2, 0xFFFFFFFF) == 1 ) /*0x141084dcd*/
                {
                  (**(void (__fastcall ***)(volatile signed __int32 *))v36)(a1: v36); /*0x141084dd5*/
                  if ( _InterlockedExchangeAdd(v36 + 3, 0xFFFFFFFF) == 1 ) /*0x141084de4*/
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v36 + 8LL))(a1: v36); /*0x141084dec*/
                }
                ++v35; /*0x141084def*/
              }
              while ( v35 != __that.deserializedItems._Mypair._Myval2._Mylast ); /*0x141084df7*/
              v35 = __that.deserializedItems._Mypair._Myval2._Myfirst; /*0x141084df9*/
            }
            v37 = v35; /*0x141084e08*/
            if ( (((char *)__that.deserializedItems._Mypair._Myval2._Myend - (char *)v35) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x141084e12*/
            {
              v35 = (std::shared_ptr<RBX::Network::DeserializedItem> *)v35[-1]._Rep; /*0x141084e18*/
              if ( (unsigned __int64)((char *)v37 - (char *)v35 - 8) > 0x1F ) /*0x141084e27*/
LABEL_140:
                _invalid_parameter_noinfo_noreturn(); /*0x141085356*/
            }
            operator delete(ptr: v35); /*0x141084e30*/
          }
        }
        else
        {
          p_deserializedPackets_deprecated = &v19->deserializedPackets_deprecated; /*0x141084e3a*/
          v83.rawPacket = p_deserializedPacket->rawPacket; /*0x141084e41*/
          memset(&v83.deserializedItems, 0, sizeof(v83.deserializedItems)); /*0x141084e46*/
          v39 = this->deserializedPacket.deserializedItems._Mypair._Myval2._Myfirst; /*0x141084e51*/
          v40 = this->deserializedPacket.deserializedItems._Mypair._Myval2._Mylast; /*0x141084e55*/
          if ( v39 != v40 ) /*0x141084e5c*/
          {
            v41 = (std::shared_ptr<RBX::Network::DeserializedItem> *)std::allocator<std::shared_ptr<RBX::AssetImport::IStatus>>::allocate( /*0x141084e75*/
                                                                       this: (std::allocator<VkVertexInputAttributeDescription> *)&v83.deserializedItems,
                                                                       _Count: v40 - v39);
            v83.deserializedItems._Mypair._Myval2._Myfirst = v41; /*0x141084e78*/
            v83.deserializedItems._Mypair._Myval2._Mylast = v41; /*0x141084e7d*/
            v83.deserializedItems._Mypair._Myval2._Myend = &v41[v40 - v39]; /*0x141084e89*/
            v42 = (char *)v39 - (char *)v41; /*0x141084e8e*/
            do /*0x141084ec1*/
            {
              v41->_Ptr = nullptr; /*0x141084e91*/
              v41->_Rep = nullptr; /*0x141084e94*/
              v43 = *(__int64 *)((char *)&v41->_Rep + v42); /*0x141084e98*/
              if ( v43 != 0 ) /*0x141084ea0*/
                _InterlockedIncrement((volatile signed __int32 *)(v43 + 8)); /*0x141084ea2*/
              v41->_Ptr = *(RBX::Network::DeserializedItem **)((char *)&v41->_Ptr + v42); /*0x141084eaa*/
              v41->_Rep = *(std::_Ref_count_base **)((char *)&v41->_Rep + v42); /*0x141084eb2*/
              ++v41; /*0x141084eb6*/
            }
            while ( (std::shared_ptr<RBX::Network::DeserializedItem> *)((char *)v41 + v42) != v40 ); /*0x141084ec1*/
            v83.deserializedItems._Mypair._Myval2._Mylast = v41; /*0x141084ec3*/
            v19 = v86; /*0x141084ec8*/
          }
          __wind /*0xf1c0000000000084*/
          {
            v83.itemOffset = this->deserializedPacket.itemOffset; /*0x141084ed0*/
            v83.deserializationProgress = this->deserializedPacket.deserializationProgress; /*0x141084ed8*/
            v83.containsJdi = this->deserializedPacket.containsJdi; /*0x141084ee1*/
            v83.shouldDelete = this->deserializedPacket.shouldDelete; /*0x141084eea*/
            v83.processShouldDeserialize = this->deserializedPacket.processShouldDeserialize; /*0x141084ef3*/
            RBX::Time::now<0>(result: &v84); /*0x141084efb*/
            sp = (boost::detail::spinlock *)&p_deserializedPackets_deprecated->m; /*0x141084f01*/
            v87.sp_ = (boost::detail::spinlock *)&p_deserializedPackets_deprecated->m; /*0x141084f05*/
            while ( _InterlockedExchange(&sp->v_, 1) != 0 ) /*0x141084f1e*/
              sp = v87.sp_; /*0x141084f20*/
            v45 = p_deserializedPackets_deprecated->queue._Mypair._Myval2._Mysize; /*0x141084f26*/
            if ( v45 == 0 ) /*0x141084f2d*/
              p_deserializedPackets_deprecated->headTimestamp = v84.sec; /*0x141084f34*/
          }
          __unwind
          {
            rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: &v83); /*0xf1c0000000000094*/
          }
          __eh34_enter_wind_state(2, 9); /*0xf1c000000000009c*/
          __wind /*0xf1c00000000000a0*/
          {
            v46 = p_deserializedPackets_deprecated->queue._Mypair._Myval2._Mapsize; /*0x141084f3a*/
            if ( v46 <= v45 + 1 ) /*0x141084f45*/
            {
              std::deque<rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>>::_Growmap( /*0x141084f4f*/
                this: (std::deque<webrtc::BitrateProber::ProbeCluster> *)p_deserializedPackets_deprecated,
                _Count: 1u);
              v45 = p_deserializedPackets_deprecated->queue._Mypair._Myval2._Mysize; /*0x141084f54*/
              v46 = p_deserializedPackets_deprecated->queue._Mypair._Myval2._Mapsize; /*0x141084f58*/
            }
            v47 = v46 - 1; /*0x141084f5c*/
            v48 = p_deserializedPackets_deprecated->queue._Mypair._Myval2._Myoff & v47; /*0x141084f62*/
            p_deserializedPackets_deprecated->queue._Mypair._Myval2._Myoff = v48; /*0x141084f66*/
            v49 = v47 & (v48 + v45); /*0x141084f6e*/
            v50 = p_deserializedPackets_deprecated->queue._Mypair._Myval2._Map; /*0x141084f71*/
            if ( v50[v49] == nullptr ) /*0x141084f7a*/
            {
              p_deserializedPackets_deprecated->queue._Mypair._Myval2._Map[v49] = (rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket> *)operator new(size: 0x38u); /*0x141084f8a*/
              v50 = v19->deserializedPackets_deprecated.queue._Mypair._Myval2._Map; /*0x141084f8e*/
            }
            v51 = v50[v49]; /*0x141084f95*/
            v51->value.rawPacket = v83.rawPacket; /*0x141084f9e*/
            v51->value.deserializedItems._Mypair._Myval2._Myfirst = nullptr; /*0x141084fa7*/
            v51->value.deserializedItems._Mypair._Myval2._Mylast = nullptr; /*0x141084faa*/
            v51->value.deserializedItems._Mypair._Myval2._Myend = nullptr; /*0x141084fae*/
            v52 = v83.deserializedItems._Mypair._Myval2._Myfirst; /*0x141084fb2*/
            v104 = v83.deserializedItems._Mypair._Myval2._Mylast; /*0x141084fbc*/
            if ( v83.deserializedItems._Mypair._Myval2._Myfirst != v83.deserializedItems._Mypair._Myval2._Mylast ) /*0x141084fc6*/
            {
              v53 = v83.deserializedItems._Mypair._Myval2._Mylast - v83.deserializedItems._Mypair._Myval2._Myfirst; /*0x141084fce*/
              v54 = std::allocator<std::shared_ptr<RBX::AssetImport::IStatus>>::allocate( /*0x141084fd5*/
                      this: (std::allocator<VkVertexInputAttributeDescription> *)&v51->value.deserializedItems,
                      _Count: v53);
              v51->value.deserializedItems._Mypair._Myval2._Myfirst = (std::shared_ptr<RBX::Network::DeserializedItem> *)v54; /*0x141084fda*/
              v51->value.deserializedItems._Mypair._Myval2._Mylast = (std::shared_ptr<RBX::Network::DeserializedItem> *)v54; /*0x141084fdf*/
              v51->value.deserializedItems._Mypair._Myval2._Myend = (std::shared_ptr<RBX::Network::DeserializedItem> *)&v54[v53]; /*0x141084feb*/
              v55 = (char *)v51->value.deserializedItems._Mypair._Myval2._Myfirst; /*0x141084ff0*/
              v56 = (char *)v52 - v55; /*0x141084ff5*/
              do /*0x141085030*/
              {
                *(_QWORD *)v55 = 0; /*0x141085000*/
                *((_QWORD *)v55 + 1) = 0; /*0x141085003*/
                v57 = *(_QWORD *)&v55[v56 + 8]; /*0x141085007*/
                if ( v57 != 0 ) /*0x14108500f*/
                  _InterlockedIncrement((volatile signed __int32 *)(v57 + 8)); /*0x141085011*/
                *(_QWORD *)v55 = *(_QWORD *)&v55[v56]; /*0x141085019*/
                *((_QWORD *)v55 + 1) = *(_QWORD *)&v55[v56 + 8]; /*0x141085021*/
                v55 += 16; /*0x141085025*/
              }
              while ( &v55[v56] != (char *)v104 ); /*0x141085030*/
              v51->value.deserializedItems._Mypair._Myval2._Mylast = (std::shared_ptr<RBX::Network::DeserializedItem> *)v55; /*0x141085032*/
            }
            v51->value.itemOffset = v83.itemOffset; /*0x14108503b*/
            v51->value.deserializationProgress = v83.deserializationProgress; /*0x141085044*/
            v51->value.containsJdi = v83.containsJdi; /*0x14108504e*/
            v51->value.shouldDelete = v83.shouldDelete; /*0x141085058*/
            v51->value.processShouldDeserialize = v83.processShouldDeserialize; /*0x141085062*/
            v51->timestamp = v84; /*0x14108506c*/
            ++p_deserializedPackets_deprecated->queue._Mypair._Myval2._Mysize; /*0x141085073*/
          }
          __unwind
          {
            rbx::spin_mutex::scoped_lock::~scoped_lock(this: &v87); /*0xf1c000000000007c*/
          }
          v87.sp_->v_ = 0; /*0x14108507c*/
          v58 = v83.deserializedItems._Mypair._Myval2._Myfirst; /*0x14108507f*/
          if ( v83.deserializedItems._Mypair._Myval2._Myfirst != nullptr ) /*0x141085087*/
          {
            v59 = v83.deserializedItems._Mypair._Myval2._Mylast; /*0x14108508d*/
            if ( v83.deserializedItems._Mypair._Myval2._Myfirst != v83.deserializedItems._Mypair._Myval2._Mylast ) /*0x141085095*/
            {
              do /*0x1410850d6*/
              {
                v60 = (volatile signed __int32 *)v58->_Rep; /*0x141085097*/
                if ( v60 != nullptr && _InterlockedExchangeAdd(v60 + 2, 0xFFFFFFFF) == 1 ) /*0x1410850ad*/
                {
                  (**(void (__fastcall ***)(volatile signed __int32 *))v60)(a1: v60); /*0x1410850b5*/
                  if ( _InterlockedExchangeAdd(v60 + 3, 0xFFFFFFFF) == 1 ) /*0x1410850c4*/
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v60 + 8LL))(a1: v60); /*0x1410850cc*/
                }
                ++v58; /*0x1410850cf*/
              }
              while ( v58 != v59 ); /*0x1410850d6*/
              v58 = v83.deserializedItems._Mypair._Myval2._Myfirst; /*0x1410850d8*/
            }
            if ( __eh34_unwind(9) ) /*0xf1c000000000006c*/
              goto unwind_state_9; /*0xf1c000000000006c*/
            __eh34_exit_wind_state(9, 2); /*0xf1c0000000000070*/
            v61 = v58; /*0x1410850e9*/
            if ( (((char *)v83.deserializedItems._Mypair._Myval2._Myend - (char *)v58) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x1410850f3*/
            {
              v58 = (std::shared_ptr<RBX::Network::DeserializedItem> *)v58[-1]._Rep; /*0x1410850f9*/
              if ( (unsigned __int64)((char *)v61 - (char *)v58 - 8) > 0x1F ) /*0x141085108*/
                _invalid_parameter_noinfo_noreturn(); /*0x141085348*/
            }
            operator delete(ptr: v58); /*0x141085111*/
            memset(&v83.deserializedItems, 0, sizeof(v83.deserializedItems)); /*0x141085119*/
          }
          else
          {
            if ( __eh34_unwind(9) ) /*0xf1c0000000000058*/
            {
unwind_state_9:
              rbx::implementation::timestamped_safe_queue_item<RBX::Network::ProcessingPacket>::~timestamped_safe_queue_item<RBX::Network::ProcessingPacket>(this: &v83); /*0xf1c000000000005c*/
              __eh34_continue_unwinding(9, 2); /*0xf1c0000000000060*/
            }
            __eh34_exit_wind_state(9, 2); /*0xf1c0000000000064*/
          }
          v62 = this->deserializedPacket.deserializedItems._Mypair._Myval2._Mylast; /*0x141085124*/
          v63 = this->deserializedPacket.deserializedItems._Mypair._Myval2._Myfirst; /*0x14108512b*/
          if ( v63 != v62 ) /*0x141085135*/
          {
            do /*0x141085146*/
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)v63++); /*0x14108513a*/
            while ( v63 != v62 ); /*0x141085146*/
            v63 = this->deserializedPacket.deserializedItems._Mypair._Myval2._Myfirst; /*0x141085148*/
          }
          this->deserializedPacket.deserializedItems._Mypair._Myval2._Mylast = v63; /*0x14108514f*/
        }
        if ( v102 != 0 ) /*0x14108515d*/
        {
          if ( !this->replicator->isServerReplicator(this: this->replicator) ) /*0x141085175*/
          {
            RBX::AvatarProfiler::logNetPacketProcessEnd(eventRef: this->eventRef); /*0x14108517e*/
            this->eventRef = 0; /*0x141085183*/
          }
          v64 = RBX::Network::NetworkStream::NetworkStream(this: &v99); /*0x141085196*/
          this->stream.isJoinData = v64->isJoinData; /*0x14108519d*/
          this->stream.data = v64->data; /*0x1410851a7*/
          v65 = &v64->dataVector; /*0x1410851ae*/
          v66 = &this->stream.dataVector; /*0x1410851b2*/
          if ( &this->stream.dataVector != &v64->dataVector ) /*0x1410851bc*/
          {
            v67 = v66->_Mypair._Myval2._Myfirst; /*0x1410851be*/
            if ( v66->_Mypair._Myval2._Myfirst != nullptr ) /*0x1410851c4*/
            {
              if ( (unsigned __int8 *)(this->stream.dataVector._Mypair._Myval2._Myend - v67) >= (unsigned __int8 *)0x1000 ) /*0x1410851d4*/
              {
                if ( (unsigned __int64)&v67[-*((_QWORD *)v67 - 1) - 8] > 0x1F ) /*0x1410851e9*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14108534f*/
                v67 = *((unsigned __int8 **)v67 - 1); /*0x1410851ef*/
              }
              operator delete(ptr: v67); /*0x1410851f2*/
              v66->_Mypair._Myval2._Myfirst = nullptr; /*0x1410851f7*/
              this->stream.dataVector._Mypair._Myval2._Mylast = nullptr; /*0x1410851fa*/
              this->stream.dataVector._Mypair._Myval2._Myend = nullptr; /*0x1410851fe*/
            }
            v66->_Mypair._Myval2._Myfirst = v65->_Mypair._Myval2._Myfirst; /*0x141085205*/
            this->stream.dataVector._Mypair._Myval2._Mylast = v64->dataVector._Mypair._Myval2._Mylast; /*0x14108520c*/
            this->stream.dataVector._Mypair._Myval2._Myend = v64->dataVector._Mypair._Myval2._Myend; /*0x141085214*/
            v65->_Mypair._Myval2._Myfirst = nullptr; /*0x141085218*/
            v64->dataVector._Mypair._Myval2._Mylast = nullptr; /*0x14108521b*/
            v64->dataVector._Mypair._Myval2._Myend = nullptr; /*0x14108521f*/
          }
          this->stream.numberOfBytesUsed = v64->numberOfBytesUsed; /*0x141085227*/
          this->stream.numberOfBytesAllocated = v64->numberOfBytesAllocated; /*0x141085231*/
          this->stream.readOffset = v64->readOffset; /*0x14108523b*/
          this->stream.ownedData = v64->ownedData; /*0x141085246*/
          RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&v99.dataVector); /*0x141085253*/
          v99.__vftable = (RBX::Network::NetworkStream_vtbl *)RakNet::AbstractBitStream::`vftable'; /*0x14108525f*/
          memset(_Right, 0, sizeof(_Right)); /*0x141085269*/
          v90 = 0; /*0x141085276*/
          v91 = 0; /*0x14108527a*/
          v92 = false; /*0x141085280*/
          p_deserializedPacket->rawPacket = nullptr; /*0x141085284*/
          std::vector<std::shared_ptr<RBX::Network::DeserializedItem>>::operator=( /*0x14108528f*/
            this: &this->deserializedPacket.deserializedItems,
            _Right: (std::vector<std::shared_ptr<RBX::Network::DeserializedItem>> *)&_Right[1]);
          *(_QWORD *)&this->deserializedPacket.itemOffset = v90; /*0x141085297*/
          *(_WORD *)&this->deserializedPacket.containsJdi = v91; /*0x1410852a6*/
          this->deserializedPacket.processShouldDeserialize = v92; /*0x1410852b6*/
          v68 = (char *)_Right[1]; /*0x1410852ba*/
          if ( _Right[1] != 0 ) /*0x1410852c1*/
          {
            v70 = (std::shared_ptr<RBX::File> *)_Right[2]; /*0x1410852c6*/
            for ( i = (std::shared_ptr<RBX::File> *)_Right[1]; i != v70; ++i ) /*0x1410852cd*/
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: i); /*0x1410852d3*/
            v71 = v68; /*0x1410852ec*/
            if ( ((_Right[3] - (_QWORD)v68) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x1410852f6*/
            {
              v68 = *((char **)v68 - 1); /*0x1410852fc*/
              if ( (unsigned __int64)(v71 - v68 - 8) > 0x1F ) /*0x14108530b*/
                goto LABEL_140; /*0x14108530b*/
            }
            operator delete(ptr: v68); /*0x141085310*/
            memset(&_Right[1], 0, 24); /*0x141085318*/
          }
        }
        p_mx = (_Mtx_internal_imp_t *)lock._Pmtx; /*0x141085321*/
      }
      v72 = Mtx_lock_0(a1: p_mx); /*0x141085329*/
      if ( v72 != 0 ) /*0x141085330*/
        goto LABEL_165; /*0x141085330*/
      Owns = true; /*0x141085336*/
      lock._Owns = true; /*0x141085338*/
    }
    this->accumulatedTimeThisFrame = (RBX::Time::nowFast(result: &v95)->sec - this->stepStart.sec) * 1000.0 /*0x14108546c*/
                                   + this->accumulatedTimeThisFrame;
    v7 = 1; /*0x141085495*/
    if ( __eh34_unwind(2) ) /*0xf1c0000000000044*/
    {
      std::optional<std::scoped_lock<std::mutex>>::~optional<std::scoped_lock<std::mutex>>(this: (RBX::Soundscape::FlaggedLock *)&lock); /*0xf1c0000000000048*/
      __eh34_continue_unwinding(2, 1); /*0xf1c000000000004c*/
    }
LABEL_173:
    __eh34_exit_wind_state(2, 1); /*0xf1c0000000000050*/
    if ( Owns ) /*0x14108549d*/
      Mtx_unlock_0(a1: p_mx); /*0x1410854a2*/
  }
  __unwind
  {
    RBX::Profiler::PotentialTelemetryScope::~PotentialTelemetryScope(this: &profscope772); /*0xf1c0000000000124*/
  }
  __wind /*0xf1c000000000012c*/
  {
    if ( profscope772.isFlagEnabled && profscope772.isEnabled ) /*0x1410854b4*/
    {
      RBX::Profiler::PerFrameTelemetry::leaveTelemetryRegion( /*0x1410854c5*/
        token: profscope772.region.token,
        timestamp: profscope772.region.timestamp,
        mpTimestamp: profscope772.mpTimestamp);
    }
    else
    {
      RBX::Profiler::leaveRegion(token: profscope772.region.token, enterTimestamp: profscope772.mpTimestamp); /*0x1410854d6*/
      if ( profscope772.isEnabled && DFFlag::EnablePerfDataCoreTimersCollection2.value ) /*0x1410854e9*/
        RBX::Profiler::PerFrameTelemetry::leaveTelemetryRegion_deprecated( /*0x1410854f5*/
          token: profscope772.region.token,
          timestamp: profscope772.region.timestamp);
    }
  }
  __unwind
  {
    __std_terminate(a1: v75, a2: &v80); /*0x142f39fa8*/
  }
  return v7; /*0x1410854fe*/
}

// END DeserializePacketsJob part 1/1, 7 functions
