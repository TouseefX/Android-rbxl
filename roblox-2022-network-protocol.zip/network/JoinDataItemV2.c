// JoinDataItemV2 -- 2022 Studio + full PDB
// tier 3, 11 functions


// Address: 0x141142aa0 | Name: ??0JoinDataItemV2@Replicator@Network@RBX@@QEAA@PEAV123@AEBV?$shared_ptr@$$CBVPreserializedReplicationCache@Network@RBX@@@std@@_N_K@Z
RBX::Network::Replicator::JoinDataItemV2 *__fastcall RBX::Network::Replicator::JoinDataItemV2::JoinDataItemV2(
        RBX::Network::Replicator::JoinDataItemV2 *this,
        RBX::Network::Replicator *replicator,
        const std::shared_ptr<RBX::Network::PreserializedReplicationCache const > *cacheData,
        bool streaming,
        unsigned __int64 numMRDInstances)
{
  unsigned int megaClusterInstanceBlobIndex; // eax
  unsigned int workspaceInstanceBlobIndex; // ecx
  std::_Ref_count_base *Rep; // rax

  RBX::Network::Item::Item(this, replicator); /*0x141142ab9*/
  this->__vftable = (RBX::Network::Replicator::JoinDataItemV2_vtbl *)RBX::Network::Replicator::JoinDataItemV2::`vftable'; /*0x141142ac7*/
  *(_QWORD *)&this->sharedStringsInstanceCounters.numOfInstances = 0; /*0x141142ace*/
  *(_QWORD *)&this->sharedStringsInstanceCounters.numOfCompressedBytes = 0; /*0x141142ad2*/
  this->streamingEnabled = streaming; /*0x141142ad6*/
  this->totalInstancesInMRD = numMRDInstances; /*0x141142ad9*/
  *(_QWORD *)&this->totalNumberOfSentBlobs = 0; /*0x141142adc*/
  *(_QWORD *)&this->totalNumberOfBytesSent = 0; /*0x141142ae0*/
  *(_QWORD *)&this->totalUncompressedBytes = 0; /*0x141142ae4*/
  this->totalSharedStringsWriteTime = 0.0; /*0x141142ae8*/
  if ( cacheData->_Ptr != nullptr ) /*0x141142af1*/
    megaClusterInstanceBlobIndex = cacheData->_Ptr->megaClusterInstanceBlobIndex; /*0x141142af3*/
  else
    megaClusterInstanceBlobIndex = 0; /*0x141142afb*/
  this->megaClusterInstanceBlobIndex = megaClusterInstanceBlobIndex; /*0x141142afd*/
  if ( cacheData->_Ptr != nullptr ) /*0x141142b06*/
    workspaceInstanceBlobIndex = cacheData->_Ptr->workspaceInstanceBlobIndex; /*0x141142b08*/
  else
    workspaceInstanceBlobIndex = 0; /*0x141142b10*/
  this->workspaceInstanceBlobIndex = workspaceInstanceBlobIndex; /*0x141142b12*/
  this->joinCacheStreamData._Ptr = nullptr; /*0x141142b15*/
  this->joinCacheStreamData._Rep = nullptr; /*0x141142b19*/
  Rep = cacheData->_Rep; /*0x141142b20*/
  if ( Rep != nullptr ) /*0x141142b27*/
    _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141142b29*/
  this->joinCacheStreamData._Ptr = cacheData->_Ptr; /*0x141142b35*/
  this->joinCacheStreamData._Rep = cacheData->_Rep; /*0x141142b42*/
  *(_QWORD *)&this->curJoinSharedStringVectorIndex = 0; /*0x141142b4c*/
  *(_QWORD *)&this->curReadyBitStreamIndexForSharedStrings = 0; /*0x141142b53*/
  return this; /*0x141142b30*/
}

// Address: 0x141142b70 | Name: ??1JoinDataItemV2@Replicator@Network@RBX@@UEAA@XZ
void __fastcall RBX::Network::Replicator::JoinDataItemV2::~JoinDataItemV2(
        RBX::Network::Replicator::JoinDataItemV2 *this)
{
  int v2; // ebx
  char *v3; // rax
  char *Ptr; // rcx
  __int64 totalNumOfInstances; // rbx
  signed int totalInstancesInMRD; // edx
  float v7; // xmm6_4
  int v8; // r8d
  float v9; // xmm7_4
  float v10; // xmm0_4
  signed int v11; // edx
  float v12; // xmm1_4
  signed int v13; // ecx
  int v14; // ebx
  char *v15; // rax
  char *v16; // rcx
  const RBX::Network::PreserializedReplicationCache *v17; // rax
  unsigned int v18; // esi
  int v19; // ebx
  unsigned int v20; // r14d
  int v21; // edi
  int v22; // ebx
  char *v23; // rax
  char *v24; // rcx
  const RBX::Network::PreserializedReplicationCache *v25; // rcx
  const RBX::Network::PreserializedReplicationCache *v26; // rbx
  boost::unordered::detail::ptr_bucket *next; // rbx
  unsigned __int8 v28; // cl
  boost::unordered::detail::ptr_bucket *v29; // r8
  boost::unordered::detail::ptr_bucket *v30; // r9
  std::_Ref_count_base *Rep; // rbx
  std::string resource; // [rsp+58h] [rbp-B0h] BYREF
  std::string v33; // [rsp+78h] [rbp-90h] BYREF
  std::string v34; // [rsp+98h] [rbp-70h] BYREF
  RBX::Analytics::InfluxDb::Points v35; // [rsp+B8h] [rbp-50h] BYREF
  RBX::Analytics::InfluxDb::Points v36; // [rsp+128h] [rbp+20h] BYREF
  RBX::Analytics::InfluxDb::Points v37; // [rsp+198h] [rbp+90h] BYREF

  this->__vftable = (RBX::Network::Replicator::JoinDataItemV2_vtbl *)RBX::Network::Replicator::JoinDataItemV2::`vftable'; /*0x141142ba8*/
  if ( DFFlag::ReportReplicatorJoinDataItemStatsToInflux.value ) /*0x141142bb8*/
  {
    RBX::Analytics::InfluxDb::Points::Points( /*0x141142bce*/
      this: &v37,
      throttleHundredthsPercentage: -1,
      categoryType: kStandardType,
      priorityHundredthsPercentage: 0);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141142bf0*/
      this: &v37,
      name: (const char *)&RBX::Network::Replicator::JoinDataItemV2::`vftable'[7],
      value: this->replicator->serverJoinSnapshotTime);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141142c0b*/
      this: &v37,
      name: "numOfPacketsSent",
      value: this->joinCacheStreamData._Ptr->totalNumberOfSentBlobs);
    v2 = DFInt::ReplicatorJoinDataItemV2StatsInfluxHundrethsPercentage; /*0x141142c10*/
    v3 = (char *)operator new(size: 0x20u); /*0x141142c1b*/
    resource._Mypair._Myval2._Mysize = 29; /*0x141142c20*/
    resource._Mypair._Myval2._Myres = 31; /*0x141142c29*/
    strcpy(v3, "ReplicatorJoinDataItemV2Stats"); /*0x141142c39*/
    resource._Mypair._Myval2._Bx._Ptr = v3; /*0x141142c60*/
    RBX::Analytics::InfluxDb::Points::report(this: &v37, &resource, throttleHundredthsPercentage: v2, blocking: false); /*0x141142c77*/
    if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x141142c85*/
    {
      Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x141142c8a*/
      if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141142c99*/
      {
        Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x141142c9f*/
        if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141142cae*/
          _invalid_parameter_noinfo_noreturn(); /*0x141142cb0*/
      }
      operator delete(ptr: Ptr); /*0x141142cb7*/
    }
    RBX::Analytics::InfluxDb::Points::~Points(this: &v37); /*0x141142cc3*/
  }
  RBX::Analytics::InfluxDb::Points::Points( /*0x141142cd5*/
    this: &v35,
    throttleHundredthsPercentage: -1,
    categoryType: kStandardType,
    priorityHundredthsPercentage: 0);
  totalNumOfInstances = this->joinCacheStreamData._Ptr->totalNumOfInstances; /*0x141142cde*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: &v35, name: "StreamingEnabled", value: this->streamingEnabled); /*0x141142cf1*/
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141142d04*/
    this: &v35,
    name: "JoinDataInstances",
    value: (unsigned int)totalNumOfInstances);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141142d18*/
    this: &v35,
    name: "TotalReplicatorInstances",
    value: this->totalInstancesInMRD);
  totalInstancesInMRD = this->totalInstancesInMRD; /*0x141142d1d*/
  v7 = (float)(int)totalNumOfInstances; /*0x141142d29*/
  if ( totalInstancesInMRD != 0 ) /*0x141142d4a*/
    v8 = (int)(float)((float)(v7 * 1000.0) / (float)totalInstancesInMRD); /*0x141142d6b*/
  else
    v8 = 1000; /*0x141142d4c*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: &v35, name: "JoinInstanceTenthPercent", value: v8); /*0x141142d7b*/
  if ( DFFlag::ReportJoinBytesTimeWithInstanceCounts.value ) /*0x141142d87*/
  {
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141142da0*/
      this: &v35,
      name: "TotalJoinBytesCompressed",
      value: this->joinCacheStreamData._Ptr->totalCompressedBytes);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141142db8*/
      this: &v35,
      name: "TotalJoinBytesUncompressed",
      value: this->joinCacheStreamData._Ptr->totalUncompressedBytes);
    v9 = 0.0; /*0x141142dbd*/
    if ( totalNumOfInstances != 0 ) /*0x141142dca*/
    {
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x141142df7*/
        this: &v35,
        name: "CompressedBytesPerJoinInstance",
        value: (float)((float)(int)this->joinCacheStreamData._Ptr->totalCompressedBytes / v7));
      v10 = (float)(int)this->joinCacheStreamData._Ptr->totalUncompressedBytes / v7; /*0x141142e0b*/
    }
    else
    {
      RBX::Analytics::InfluxDb::Points::addPoint(this: &v35, name: "CompressedBytesPerJoinInstance", value: 0.0); /*0x141142dd3*/
      v10 = 0.0; /*0x141142dd8*/
    }
    RBX::Analytics::InfluxDb::Points::addPoint(this: &v35, name: "UncompresedBytesPerJoinInstance", value: v10); /*0x141142e1d*/
    v11 = this->totalInstancesInMRD; /*0x141142e22*/
    v12 = 0.0; /*0x141142e26*/
    if ( v11 != 0 ) /*0x141142e2b*/
      v12 = (float)(int)this->joinCacheStreamData._Ptr->totalCompressedBytes / (float)v11; /*0x141142e41*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: &v35, name: "CompressedBytesPerReplicatableInstance", value: v12); /*0x141142e53*/
    v13 = this->totalInstancesInMRD; /*0x141142e58*/
    if ( v13 != 0 ) /*0x141142e5e*/
      v9 = (float)(int)this->joinCacheStreamData._Ptr->totalUncompressedBytes / (float)v13; /*0x141142e7b*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: &v35, name: "UncompresedBytesPerReplicatableInstance", value: v9); /*0x141142e8c*/
  }
  v14 = DFInt::ReportJoinInstanceCountStreamingDataHundredthPercentage; /*0x141142e91*/
  v15 = (char *)operator new(size: 0x20u); /*0x141142e9c*/
  v33._Mypair._Myval2._Mysize = 29; /*0x141142ea1*/
  v33._Mypair._Myval2._Myres = 31; /*0x141142ea9*/
  strcpy(v15, "JoinInstanceStatsForStreaming"); /*0x141142eb8*/
  v33._Mypair._Myval2._Bx._Ptr = v15; /*0x141142edf*/
  RBX::Analytics::InfluxDb::Points::report( /*0x141142ef3*/
    this: &v35,
    resource: &v33,
    throttleHundredthsPercentage: v14,
    blocking: false);
  if ( v33._Mypair._Myval2._Myres >= 0x10 ) /*0x141142f00*/
  {
    v16 = v33._Mypair._Myval2._Bx._Ptr; /*0x141142f05*/
    if ( v33._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141142f14*/
    {
      v16 = *((char **)v33._Mypair._Myval2._Bx._Ptr - 1); /*0x141142f1a*/
      if ( (unsigned __int64)(v33._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x141142f29*/
        _invalid_parameter_noinfo_noreturn(); /*0x141142f2b*/
    }
    operator delete(ptr: v16); /*0x141142f32*/
  }
  if ( DFInt::ReportJoinDataItemV2CacheEfficiencyHundrethsPercentage2 > 0 ) /*0x141142f3e*/
  {
    v17 = this->joinCacheStreamData._Ptr; /*0x141142f44*/
    v18 = this->sharedStringsInstanceCounters.numOfInstances + v17->notCacheableInstanceCounters.numOfInstances; /*0x141142f4b*/
    v19 = v17->cacheableInstanceCounters.numOfInstances + v17->partsInstanceCounters.numOfInstances; /*0x141142f52*/
    v20 = this->sharedStringsInstanceCounters.numOfBlobs + v17->notCacheableInstanceCounters.numOfBlobs; /*0x141142f58*/
    v21 = v17->cacheableInstanceCounters.numOfBlobs + v17->partsInstanceCounters.numOfBlobs; /*0x141142f5f*/
    RBX::Analytics::InfluxDb::Points::Points( /*0x141142f6f*/
      this: &v36,
      throttleHundredthsPercentage: -1,
      categoryType: kStandardType,
      priorityHundredthsPercentage: 0);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141142f8d*/
      this: &v36,
      name: "InstanceHits",
      value: this->joinCacheStreamData._Ptr->totalNumOfInstances - v19 - v18);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141142fa8*/
      this: &v36,
      name: "InstanceTotal",
      value: this->joinCacheStreamData._Ptr->totalNumOfInstances - v18);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141142fc6*/
      this: &v36,
      name: "BlobHits",
      value: this->joinCacheStreamData._Ptr->totalNumberOfSentBlobs - v21 - v20);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x141142fe1*/
      this: &v36,
      name: "BlobTotal",
      value: this->joinCacheStreamData._Ptr->totalNumberOfSentBlobs - v20);
    v22 = DFInt::ReportJoinDataItemV2CacheEfficiencyHundrethsPercentage2; /*0x141142fe6*/
    v23 = (char *)operator new(size: 0x30u); /*0x141142ff1*/
    v34._Mypair._Myval2._Mysize = 39; /*0x141142ff6*/
    v34._Mypair._Myval2._Myres = 47; /*0x141142ffe*/
    strcpy(v23, "ReplicatorJoinDataItemV2CacheEfficiency"); /*0x14114300d*/
    v34._Mypair._Myval2._Bx._Ptr = v23; /*0x14114303d*/
    RBX::Analytics::InfluxDb::Points::report( /*0x14114304f*/
      this: &v36,
      resource: &v34,
      throttleHundredthsPercentage: v22,
      blocking: false);
    if ( v34._Mypair._Myval2._Myres >= 0x10 ) /*0x14114305c*/
    {
      v24 = v34._Mypair._Myval2._Bx._Ptr; /*0x141143061*/
      if ( v34._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14114306f*/
      {
        v24 = *((char **)v34._Mypair._Myval2._Bx._Ptr - 1); /*0x141143075*/
        if ( (unsigned __int64)(v34._Mypair._Myval2._Bx._Ptr - v24 - 8) > 0x1F ) /*0x141143084*/
          _invalid_parameter_noinfo_noreturn(); /*0x141143086*/
      }
      operator delete(ptr: v24); /*0x14114308d*/
    }
    RBX::Analytics::InfluxDb::Points::~Points(this: &v36); /*0x141143096*/
  }
  if ( DFLog::NetworkJoin != 0 )
  {
    FLog::FastLogFormatted(
      level: DFLog::NetworkJoin,
      message: "[DFLog::NetworkJoin] ~JoinDataItemV2 : Cache Update Stats (CacheableInstances) : %u instances added, %u blob(s) ad"
      "ded, %u raw bytes added, %u compressed bytes added",
      this->joinCacheStreamData._Ptr->cacheableInstanceCounters.numOfInstances,
      this->joinCacheStreamData._Ptr->cacheableInstanceCounters.numOfBlobs,
      this->joinCacheStreamData._Ptr->cacheableInstanceCounters.numOfRawBytes,
      this->joinCacheStreamData._Ptr->cacheableInstanceCounters.numOfCompressedBytes);
    if ( DFLog::NetworkJoin != 0 )
    {
      FLog::FastLogFormatted(
        level: DFLog::NetworkJoin,
        message: "[DFLog::NetworkJoin] ~JoinDataItemV2 : Cache Update Stats (NotCacheableInstances) : %u instances added, %u blob("
        "s) added, %u raw bytes added, %u compressed bytes added",
        this->joinCacheStreamData._Ptr->notCacheableInstanceCounters.numOfInstances,
        this->joinCacheStreamData._Ptr->notCacheableInstanceCounters.numOfBlobs,
        this->joinCacheStreamData._Ptr->notCacheableInstanceCounters.numOfRawBytes,
        this->joinCacheStreamData._Ptr->notCacheableInstanceCounters.numOfCompressedBytes);
      if ( DFLog::NetworkJoin != 0 )
      {
        FLog::FastLogFormatted(
          level: DFLog::NetworkJoin,
          message: "[DFLog::NetworkJoin] ~JoinDataItemV2 : Cache Update Stats (PartInstances) : %u instances added, %u blob(s) add"
          "ed, %u raw bytes added, %u compressed bytes added",
          this->joinCacheStreamData._Ptr->partsInstanceCounters.numOfInstances,
          this->joinCacheStreamData._Ptr->partsInstanceCounters.numOfBlobs,
          this->joinCacheStreamData._Ptr->partsInstanceCounters.numOfRawBytes,
          this->joinCacheStreamData._Ptr->partsInstanceCounters.numOfCompressedBytes);
        if ( DFLog::NetworkJoin != 0 )
        {
          FLog::FastLogFormatted(
            level: DFLog::NetworkJoin,
            message: "[DFLog::NetworkJoin] ~JoinDataItemV2 : sharedStringsInstanceCounters : %u instances added, %u blob(s) added,"
            " %u raw bytes added, %u compressed bytes added, took %f ms",
            this->sharedStringsInstanceCounters.numOfInstances,
            this->sharedStringsInstanceCounters.numOfBlobs,
            this->sharedStringsInstanceCounters.numOfRawBytes,
            this->sharedStringsInstanceCounters.numOfCompressedBytes,
            this->joinCacheStreamData._Ptr->totalSharedStringsWriteTime);
          if ( DFLog::NetworkJoin != 0 )
          {
            v25 = this->joinCacheStreamData._Ptr; /*0x14114319a*/
            FLog::FastLogFormatted(
              level: DFLog::NetworkJoin,
              message: "[DFLog::NetworkJoin] ~JoinDataItemV2 : Total Join Stats : %u instances, %u blob(s), %u total bytes, %u com"
              "pressed bytes, %u uncompressed bytes, %u useful uncompressed bytes",
              this->totalNumOfInstances + v25->totalNumOfInstances,
              this->totalNumberOfSentBlobs + v25->totalNumberOfSentBlobs,
              v25->totalNumberOfBytesSent,
              v25->totalCompressedBytes,
              v25->totalUncompressedBytes,
              v25->totalUsefulUncompressedBytes);
          }
        }
      }
    }
  }
  if ( DFLog::NetworkJoinDetails != 0 ) /*0x1411431e2*/
  {
    FLog::FastLogFormatted( /*0x1411431f1*/
      level: DFLog::NetworkJoinDetails,
      message: "[DFLog::NetworkJoinDetails] InstanceTypePtr,InstanceTypeName,BlobType,Count,minSize,maxSize,avgSize");
    v26 = this->joinCacheStreamData._Ptr; /*0x1411431f6*/
    if ( v26->instanceTypeCountMap.table_.size_ != 0 ) /*0x141143202*/
    {
      next = v26->instanceTypeCountMap.table_.buckets_[v26->instanceTypeCountMap.table_.bucket_count_].next_; /*0x141143212*/
      if ( next != nullptr ) /*0x141143219*/
      {
        v28 = DFLog::NetworkJoinDetails; /*0x14114321b*/
        do /*0x141143280*/
        {
          if ( v28 != 0 ) /*0x141143224*/
          {
            v29 = next[2].next_; /*0x14114323c*/
            v30 = v29[1].next_; /*0x141143240*/
            if ( v30[3].next_ >= (boost::unordered::detail::ptr_bucket *)0x10 ) /*0x141143249*/
              v30 = v30->next_; /*0x14114324b*/
            FLog::FastLogFormatted( /*0x14114326e*/
              level: v28,
              message: "[DFLog::NetworkJoinDetails] %p,%s,%d,%d,%d,%d,%d",
              v29,
              (const char *)v30,
              LODWORD(next[3].next_),
              HIDWORD(next[3].next_),
              LODWORD(next[4].next_),
              HIDWORD(next[4].next_),
              LODWORD(next[5].next_) / HIDWORD(next[3].next_));
            v28 = DFLog::NetworkJoinDetails; /*0x141143273*/
          }
          next = next->next_; /*0x14114327a*/
        }
        while ( next != nullptr ); /*0x141143280*/
      }
    }
  }
  RBX::Analytics::InfluxDb::Points::~Points(this: &v35); /*0x141143286*/
  Rep = this->joinCacheStreamData._Rep; /*0x14114328b*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1411432a2*/
  {
    Rep->_Destroy(this: Rep); /*0x1411432aa*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1411432b6*/
      Rep->_Delete_this(this: Rep); /*0x1411432be*/
  }
  this->__vftable = (RBX::Network::Replicator::JoinDataItemV2_vtbl *)RBX::Network::Item::`vftable'; /*0x1411432c8*/
}

// Address: 0x1411435d0 | Name: ?areCachedStreamsComplete@JoinDataItemV2@Replicator@Network@RBX@@UEAA_NXZ
const RBX::Network::PreserializedReplicationCache *__fastcall RBX::Network::Replicator::JoinDataItemV2::areCachedStreamsComplete(
        RBX::Network::Replicator::JoinDataItemV2 *this)
{
  const RBX::Network::PreserializedReplicationCache *result; // rax

  result = this->joinCacheStreamData._Ptr; /*0x1411435d0*/
  if ( result != nullptr ) /*0x1411435d7*/
    return (const RBX::Network::PreserializedReplicationCache *)result->containsCompleteStreamsInCacheSet; /*0x1411435d9*/
  return result; /*0x1411435e0*/
}

// Address: 0x141143800 | Name: ?constructBlobStreams@JoinDataItemV2@Replicator@Network@RBX@@CAXAEBV?$list@VReplicationDataBlob@Network@RBX@@V?$allocator@VReplicationDataBlob@Network@RBX@@@std@@@std@@W4JoinDataSubItemType@1234@AEAV?$shared_ptr@VPreserializedReplicationCache@Network@RBX@@@6@_N@Z
void __fastcall RBX::Network::Replicator::JoinDataItemV2::constructBlobStreams(
        const std::list<RBX::Network::ReplicationDataBlob> *blobList,
        RBX::Network::Replicator::JoinDataItemV2::JoinDataSubItemType joinDataItemSubType,
        std::shared_ptr<RBX::Network::PreserializedReplicationCache> *cache,
        bool isJDIv2NoOrderInfo)
{
  std::shared_ptr<RBX::Network::PreserializedReplicationCache> *v4; // r15
  std::_List_node<RBX::Network::ReplicationDataBlob,void *> *Myhead; // rdi
  std::_List_node<RBX::Network::ReplicationDataBlob,void *> *Next; // rbx
  unsigned int v7; // esi
  RBX::Network::NetworkStream *v8; // rax
  RBX::Network::NetworkStream *v9; // rax
  RBX::Graphics::TextureVulkan::DownloadBuffer *v10; // r12
  std::_Ref_count_base *v11; // rax
  unsigned int v12; // esi
  unsigned __int8 *v13; // rax
  unsigned int numOfInstances; // r15d
  unsigned int v15; // esi
  unsigned int totalUncompressedUsedBytes; // r14d
  unsigned __int8 *v17; // rax
  RBX::Network::InvalidReplicationMetaData *Mylast; // r14
  unsigned int *i; // rsi
  RBX::Network::ReplicationMetaData *Myfirst; // rsi
  RBX::Network::MegaReplicationData *mrd; // rax
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount> >,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *> > > *p_table; // rcx
  std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount> *v23; // rax
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount> >,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *> > > *v24; // rcx
  std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount> *v25; // rax
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount> >,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *> > > *v26; // rcx
  unsigned int *p_minSize; // rcx
  unsigned int *p_length; // r15
  unsigned int v29; // r14d
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount> >,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *> > > *v30; // rcx
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount> >,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *> > > *v31; // rcx
  unsigned int *p_maxSize; // rcx
  unsigned int v33; // r14d
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount> >,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *> > > *v34; // rcx
  unsigned int v35; // r14d
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount> >,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *> > > *v36; // rcx
  std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount> *v37; // rax
  std::string *v38; // rax
  const char *Ptr; // r15
  RBX::Instance *v40; // rcx
  const RBX::Name *name; // r14
  std::string *FullName; // rax
  char *v43; // rcx
  char *v44; // rcx
  RBX::Network::PreserializedReplicationCache *v45; // r10
  RBX::SharedString *v46; // rsi
  RBX::SharedString *v47; // r15
  unsigned __int64 v48; // r14
  unsigned __int64 v49; // r14
  void *v50; // rax
  RBX::SharedString *v51; // rdx
  signed __int64 v52; // r8
  __int64 v53; // r9
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *h; // rax
  char v55[8]; // [rsp+50h] [rbp-B0h] BYREF
  char v56[8]; // [rsp+58h] [rbp-A8h] BYREF
  char v57[8]; // [rsp+60h] [rbp-A0h] BYREF
  RBX::Network::PreserializedReplicationCache *v58; // [rsp+68h] [rbp-98h]
  unsigned __int8 v59[8]; // [rsp+70h] [rbp-90h] BYREF
  unsigned __int8 inOutByteArray[4]; // [rsp+78h] [rbp-88h] BYREF
  unsigned int totalNumberOfSentBlobs; // [rsp+7Ch] [rbp-84h]
  unsigned int numberOfChildren_deprecated; // [rsp+80h] [rbp-80h]
  unsigned int indexInParent_deprecated; // [rsp+84h] [rbp-7Ch]
  std::_Ref_count_base *v64; // [rsp+88h] [rbp-78h]
  RBX::Network::ReplicationMetaData *j; // [rsp+90h] [rbp-70h]
  std::vector<RBX::SharedString> v66; // [rsp+98h] [rbp-68h] BYREF
  RBX::Reflection::ClassDescriptor *k; // [rsp+B0h] [rbp-50h] BYREF
  RBX::Reflection::ClassDescriptor *descriptor; // [rsp+B8h] [rbp-48h] BYREF
  RBX::Reflection::ClassDescriptor *v69; // [rsp+C0h] [rbp-40h] BYREF
  RBX::Reflection::ClassDescriptor *v70; // [rsp+C8h] [rbp-38h] BYREF
  RBX::Reflection::ClassDescriptor *v71; // [rsp+D0h] [rbp-30h] BYREF
  RBX::Reflection::ClassDescriptor *v72; // [rsp+D8h] [rbp-28h] BYREF
  RBX::Reflection::ClassDescriptor *v73; // [rsp+E0h] [rbp-20h] BYREF
  std::shared_ptr<RBX::Network::NetworkStream> bitStream; // [rsp+E8h] [rbp-18h] BYREF
  std::shared_ptr<RBX::Network::NetworkStream> v75; // [rsp+F8h] [rbp-8h] BYREF
  std::string v76; // [rsp+108h] [rbp+8h] BYREF
  RBX::Network::NetworkStream *v77; // [rsp+128h] [rbp+28h]
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> v78; // [rsp+130h] [rbp+30h] BYREF
  RBX::Graphics::ProfilerAdorn::Item result; // [rsp+138h] [rbp+38h] BYREF
  std::_Ref_count_base *inByteArray; // [rsp+1B0h] [rbp+B0h] BYREF
  RBX::Network::Replicator::JoinDataItemV2::JoinDataSubItemType v81; // [rsp+1B8h] [rbp+B8h]
  std::shared_ptr<RBX::Network::PreserializedReplicationCache> *v82; // [rsp+1C0h] [rbp+C0h]
  bool v83; // [rsp+1C8h] [rbp+C8h]

  v83 = isJDIv2NoOrderInfo; /*0x141143800*/
  v82 = cache; /*0x141143805*/
  v81 = joinDataItemSubType; /*0x14114380a*/
  v4 = cache; /*0x141143826*/
  Myhead = blobList->_Mypair._Myval2._Myhead; /*0x141143829*/
  Next = blobList->_Mypair._Myval2._Myhead->_Next; /*0x14114382c*/
  while ( Next != Myhead )
  {
    v7 = ((__int64 (__fastcall *)(RBX::Network::NetworkStream *))Next->_Myval.compressedBitStream.GetNumberOfBytesUsed)(a1: &Next->_Myval.compressedBitStream) /*0x141143843*/
       + 3;
    if ( Next->_Myval.metaDataList._Mypair._Myval2._Mylast - Next->_Myval.metaDataList._Mypair._Myval2._Myfirst != 0 ) /*0x141143855*/
      v7 += 12 * Next->_Myval.numOfInstances + 4; /*0x141143860*/
    __wind
    {
      bitStream = 0; /*0x141143866*/
      v8 = (RBX::Network::NetworkStream *)operator new(size: 0x40u); /*0x141143870*/
      __wind /*0xf1c0000000000068*/
      {
        v77 = v8; /*0x141143875*/
        if ( v8 != nullptr ) /*0x14114387c*/
        {
          v9 = RBX::Network::NetworkStream::NetworkStream(this: v8, initialBytesToAllocate: v7); /*0x141143883*/
          v10 = (RBX::Graphics::TextureVulkan::DownloadBuffer *)v9; /*0x141143888*/
        }
        else
        {
          v10 = nullptr; /*0x14114388d*/
        }
      }
      __unwind
      {
        operator delete(ptr: (void *)v77); /*0x1431f1295*/
      }
      __wind /*0xf1c0000000000080*/
      {
        v78._Ptr = v10; /*0x141143890*/
        v11 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x141143899*/
        v64 = v11; /*0x14114389e*/
        inByteArray = v11; /*0x1411438a2*/
        if ( v11 != nullptr ) /*0x1411438ac*/
        {
          *v11 = 0; /*0x1411438b1*/
          v11->_Uses = 1; /*0x1411438b4*/
          v11->_Weaks = 1; /*0x1411438bb*/
          v11->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::NetworkStream>::`vftable'; /*0x1411438c9*/
          v11[1].__vftable = (std::_Ref_count_base_vtbl *)v10; /*0x1411438cc*/
        }
        else
        {
          v64 = nullptr; /*0x1411438d2*/
        }
      }
      __unwind
      {
        RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: &v78); /*0xf1c0000000000060*/
      }
      bitStream._Ptr = (RBX::Network::NetworkStream *)v10; /*0x1411438d6*/
      bitStream._Rep = v11; /*0x1411438da*/
      LOBYTE(inByteArray) = -125; /*0x1411438de*/
      RBX::Network::NetworkStream::writeBytes( /*0x1411438f5*/
        this: (RBX::Network::NetworkStream *)v10,
        &inByteArray,
        numberOfBytesToWrite: 1u);
      v55[0] = 22; /*0x1411438fa*/
      RBX::Network::NetworkStream::writeBytes( /*0x14114390d*/
        this: (RBX::Network::NetworkStream *)v10,
        inByteArray: v55,
        numberOfBytesToWrite: 1u);
      v56[0] = v81; /*0x141143918*/
      RBX::Network::NetworkStream::writeBytes( /*0x14114392a*/
        this: (RBX::Network::NetworkStream *)v10,
        inByteArray: v56,
        numberOfBytesToWrite: 1u);
      v12 = Next->_Myval.compressedBitStream.GetNumberOfBytesUsed(this: &Next->_Myval.compressedBitStream); /*0x14114393a*/
      v13 = Next->_Myval.compressedBitStream.GetData(this: &Next->_Myval.compressedBitStream); /*0x141143944*/
      RBX::Network::NetworkStream::writeBytes( /*0x141143950*/
        this: (RBX::Network::NetworkStream *)v10,
        inByteArray: v13,
        numberOfBytesToWrite: v12);
      if ( DFLog::ReplicationDataCaching != 0 ) /*0x14114395c*/
      {
        numOfInstances = Next->_Myval.numOfInstances; /*0x14114395e*/
        v15 = Next->_Myval.compressedBitStream.GetNumberOfBytesUsed(this: &Next->_Myval.compressedBitStream); /*0x14114396d*/
        totalUncompressedUsedBytes = Next->_Myval.totalUncompressedUsedBytes; /*0x14114396f*/
        v17 = Next->_Myval.compressedBitStream.GetData(this: &Next->_Myval.compressedBitStream); /*0x14114397b*/
        FLog::FastLogFormatted( /*0x1411439b1*/
          level: DFLog::ReplicationDataCaching,
          message: "[DFLog::ReplicationDataCaching] ReplicationDataCache::Copying blob#%d [%p],  compressedStream=%p, numOfRawByte"
          "s=%d, numOfCompressedBytes=%d, numOfInstances=%d",
          v82->_Ptr->totalNumberOfSentBlobs,
          &Next->_Myval,
          v17,
          totalUncompressedUsedBytes,
          v15,
          numOfInstances);
        v4 = v82; /*0x1411439b6*/
      }
      if ( Next->_Myval.metaDataList._Mypair._Myval2._Mylast - Next->_Myval.metaDataList._Mypair._Myval2._Myfirst != 0 )
      {
        *(_DWORD *)v59 = Next->_Myval.numOfInstances; /*0x1411439d5*/
        RBX::Network::NetworkStream::ReverseBytes(inByteArray: v59, inOutByteArray, length: 4u); /*0x1411439e9*/
        RBX::Network::NetworkStream::writeBytes( /*0x1411439fc*/
          this: (RBX::Network::NetworkStream *)v10,
          inByteArray: inOutByteArray,
          numberOfBytesToWrite: 4u);
        RBX::Network::serializeUnsignedVarint( /*0x141143a16*/
          value: Next->_Myval.invalidOffsetsList._Mypair._Myval2._Mylast
        - Next->_Myval.invalidOffsetsList._Mypair._Myval2._Myfirst,
          stream: (RBX::Network::NetworkStream *)v10);
        if ( DFLog::ReplicationDataCaching != 0 )
          FLog::FastLog(
            level: DFLog::ReplicationDataCaching,
            message: "[DFLog::ReplicationDataCaching] ReplicationDataCache::Num invalidated cache in blob : %zu",
            arg0: (const void *)(Next->_Myval.invalidOffsetsList._Mypair._Myval2._Mylast
                         - Next->_Myval.invalidOffsetsList._Mypair._Myval2._Myfirst));
        Mylast = Next->_Myval.invalidOffsetsList._Mypair._Myval2._Mylast; /*0x141143a44*/
        for ( i = (unsigned int *)Next->_Myval.invalidOffsetsList._Mypair._Myval2._Myfirst;
              i != (unsigned int *)Mylast;
              i += 2 )
        {
          if ( DFLog::ReplicationDataCaching != 0 )
            FLog::FastLog(
              level: DFLog::ReplicationDataCaching,
              message: "[DFLog::ReplicationDataCaching] ReplicationDataCache::Invalidated Instance : offset %u  length %u",
              arg0: (const void *)*i,
              arg1: (const void *)i[1],
              arg2: nullptr);
          RBX::Network::serializeUnsignedVarint(value: *i, stream: (RBX::Network::NetworkStream *)v10); /*0x141143a8c*/
          RBX::Network::serializeUnsignedVarint(value: i[1], stream: (RBX::Network::NetworkStream *)v10); /*0x141143a97*/
        }
        if ( DFLog::NetworkJoinDetails != 0 || !v83 ) /*0x141143ab5*/
        {
          Myfirst = Next->_Myval.metaDataList._Mypair._Myval2._Myfirst; /*0x141143abb*/
          for ( j = Next->_Myval.metaDataList._Mypair._Myval2._Mylast; Myfirst != j; ++Myfirst ) /*0x141143aca*/
          {
            mrd = Myfirst->mrd; /*0x141143ad0*/
            if ( mrd != nullptr ) /*0x141143ad7*/
            {
              if ( DFLog::NetworkJoinDetails != 0 ) /*0x141143ae4*/
              {
                p_table = &v4->_Ptr->instanceTypeCountMap.table_; /*0x141143aed*/
                k = (RBX::Reflection::ClassDescriptor *)mrd->instance._Ptr->descriptor; /*0x141143afc*/
                v23 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *>>>::operator[]( /*0x141143b04*/
                        this: p_table,
                        (const RBX::Reflection::ClassDescriptor *const *)&k);
                v23->second.type = v81; /*0x141143b0f*/
                v24 = &v4->_Ptr->instanceTypeCountMap.table_; /*0x141143b15*/
                descriptor = (RBX::Reflection::ClassDescriptor *)Myfirst->mrd->instance._Ptr->descriptor; /*0x141143b28*/
                v25 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *>>>::operator[]( /*0x141143b30*/
                        this: v24,
                        k: (const RBX::Reflection::ClassDescriptor *const *)&descriptor);
                ++v25->second.count; /*0x141143b35*/
                v26 = &v4->_Ptr->instanceTypeCountMap.table_; /*0x141143b3b*/
                v69 = (RBX::Reflection::ClassDescriptor *)Myfirst->mrd->instance._Ptr->descriptor; /*0x141143b4e*/
                p_minSize = &boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *>>>::operator[]( /*0x141143b5b*/
                               this: v26,
                               k: (const RBX::Reflection::ClassDescriptor *const *)&v69)->second.minSize;
                p_length = &Myfirst->length; /*0x141143b5f*/
                if ( Myfirst->length < *p_minSize ) /*0x141143b68*/
                  p_minSize = &Myfirst->length; /*0x141143b68*/
                v29 = *p_minSize; /*0x141143b6c*/
                v30 = &v82->_Ptr->instanceTypeCountMap.table_; /*0x141143b79*/
                v70 = (RBX::Reflection::ClassDescriptor *)Myfirst->mrd->instance._Ptr->descriptor; /*0x141143b8c*/
                boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *>>>::operator[]( /*0x141143b99*/
                  this: v30,
                  k: (const RBX::Reflection::ClassDescriptor *const *)&v70)->second.minSize = v29;
                v31 = &v82->_Ptr->instanceTypeCountMap.table_; /*0x141143ba7*/
                v71 = (RBX::Reflection::ClassDescriptor *)Myfirst->mrd->instance._Ptr->descriptor; /*0x141143bba*/
                p_maxSize = &boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *>>>::operator[]( /*0x141143bc7*/
                               this: v31,
                               k: (const RBX::Reflection::ClassDescriptor *const *)&v71)->second.maxSize;
                if ( *p_maxSize < *p_length ) /*0x141143bd0*/
                  p_maxSize = &Myfirst->length; /*0x141143bd0*/
                v33 = *p_maxSize; /*0x141143bd4*/
                v34 = &v82->_Ptr->instanceTypeCountMap.table_; /*0x141143be1*/
                v72 = (RBX::Reflection::ClassDescriptor *)Myfirst->mrd->instance._Ptr->descriptor; /*0x141143bf4*/
                boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *>>>::operator[]( /*0x141143c01*/
                  this: v34,
                  k: (const RBX::Reflection::ClassDescriptor *const *)&v72)->second.maxSize = v33;
                v35 = *p_length; /*0x141143c05*/
                v4 = v82; /*0x141143c08*/
                v36 = &v82->_Ptr->instanceTypeCountMap.table_; /*0x141143c12*/
                v73 = (RBX::Reflection::ClassDescriptor *)Myfirst->mrd->instance._Ptr->descriptor; /*0x141143c25*/
                v37 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Reflection::ClassDescriptor const * const,RBX::Network::PreserializedReplicationCache::instanceTypeCount>>,RBX::Reflection::ClassDescriptor const *,RBX::Network::PreserializedReplicationCache::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const *>,std::equal_to<RBX::Reflection::ClassDescriptor const *>>>::operator[]( /*0x141143c2d*/
                        this: v36,
                        k: (const RBX::Reflection::ClassDescriptor *const *)&v73);
                v37->second.totalSize += v35; /*0x141143c32*/
              }
              if ( DFLog::ReplicationDataCaching != 0 ) /*0x141143c3d*/
              {
                totalNumberOfSentBlobs = v4->_Ptr->totalNumberOfSentBlobs; /*0x141143c49*/
                numberOfChildren_deprecated = Myfirst->numberOfChildren_deprecated; /*0x141143c50*/
                indexInParent_deprecated = Myfirst->indexInParent_deprecated; /*0x141143c56*/
                LODWORD(v58) = Myfirst->offset; /*0x141143c5b*/
                v38 = RBX::Guid::toString(this: &Myfirst->mrd->instance._Ptr->guid, result: &result.text); /*0x141143c6f*/
                Ptr = (const char *)v38; /*0x141143c74*/
                __eh34_enter_wind_state(0, 3); /*0xf1c0000000000054*/
                if ( v38->_Mypair._Myval2._Myres >= 0x10 ) /*0x141143c7c*/
                  Ptr = v38->_Mypair._Myval2._Bx._Ptr; /*0x141143c7e*/
                v40 = Myfirst->mrd->instance._Ptr; /*0x141143c85*/
                name = v40->descriptor->RBX::Reflection::DescribedBase::name; /*0x141143c8d*/
                if ( name->str._Mypair._Myval2._Myres >= 0x10 ) /*0x141143c96*/
                  name = (const RBX::Name *)name->str._Mypair._Myval2._Bx._Ptr; /*0x141143c98*/
                FullName = RBX::Instance::getFullName(this: v40, result: &v76); /*0x141143c9f*/
                __wind /*0xf1c0000000000048*/
                {
                  if ( FullName->_Mypair._Myval2._Myres >= 0x10 ) /*0x141143caa*/
                    FullName = (std::string *)FullName->_Mypair._Myval2._Bx._Ptr; /*0x141143cac*/
                  FLog::FastLogFormatted( /*0x141143ce6*/
                    level: DFLog::ReplicationDataCaching,
                    message: "[DFLog::ReplicationDataCaching] Pushing instance %s[type=%s][guid=%s] with metaDataOffset=%d, indexI"
                    "nParent=%d, numOfChildren=%d into blobIndex=%d",
                    FullName->_Mypair._Myval2._Bx._Buf,
                    name->str._Mypair._Myval2._Bx._Buf,
                    Ptr,
                    (_DWORD)v58,
                    indexInParent_deprecated,
                    numberOfChildren_deprecated,
                    totalNumberOfSentBlobs);
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v76); /*0xf1c0000000000040*/
                }
                if ( v76._Mypair._Myval2._Myres < 0x10 ) /*0x141143cf4*/
                {
                  if ( __eh34_unwind(3) ) /*0xf1c000000000001c*/
                  {
unwind_state_3:
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: &result); /*0xf1c0000000000020*/
                    __eh34_continue_unwinding(3, 0); /*0xf1c0000000000024*/
                  }
                  __eh34_exit_wind_state(3, 0); /*0xf1c0000000000028*/
                }
                else
                {
                  if ( __eh34_unwind(3) ) /*0xf1c0000000000030*/
                    goto unwind_state_3; /*0xf1c0000000000030*/
                  __eh34_exit_wind_state(3, 0); /*0xf1c0000000000034*/
                  v43 = v76._Mypair._Myval2._Bx._Ptr; /*0x141143cf9*/
                  if ( v76._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141143d07*/
                  {
                    v43 = *((char **)v76._Mypair._Myval2._Bx._Ptr - 1); /*0x141143d0d*/
                    if ( (unsigned __int64)(v76._Mypair._Myval2._Bx._Ptr - v43 - 8) > 0x1F ) /*0x141143d1c*/
                      _invalid_parameter_noinfo_noreturn(); /*0x141143f38*/
                  }
                  operator delete(ptr: v43); /*0x141143d22*/
                }
                v76._Mypair._Myval2._Mysize = 0; /*0x141143d27*/
                v76._Mypair._Myval2._Myres = 15; /*0x141143d2f*/
                v76._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141143d37*/
                if ( result.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141143d43*/
                {
                  v44 = result.text._Mypair._Myval2._Bx._Ptr; /*0x141143d48*/
                  if ( result.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141143d56*/
                  {
                    v44 = *((char **)result.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141143d5c*/
                    if ( (unsigned __int64)(result.text._Mypair._Myval2._Bx._Ptr - v44 - 8) > 0x1F ) /*0x141143d6b*/
                      _invalid_parameter_noinfo_noreturn(); /*0x141143f3f*/
                  }
                  operator delete(ptr: v44); /*0x141143d71*/
                }
                v4 = v82; /*0x141143d76*/
              }
              if ( !v83 ) /*0x141143d84*/
              {
                RBX::Network::serializeUnsignedVarint( /*0x141143d8c*/
                  value: Myfirst->numberOfChildren_deprecated,
                  stream: (RBX::Network::NetworkStream *)v10);
                RBX::Network::serializeUnsignedVarint( /*0x141143d97*/
                  value: Myfirst->indexInParent_deprecated,
                  stream: (RBX::Network::NetworkStream *)v10);
              }
            }
          }
        }
      }
      v4->_Ptr->totalNumOfInstances += Next->_Myval.numOfInstances; /*0x141143db0*/
      v4->_Ptr->totalCompressedBytes += Next->_Myval.compressedBitStream.GetNumberOfBytesUsed(this: &Next->_Myval.compressedBitStream); /*0x141143dc1*/
      v4->_Ptr->totalUncompressedBytes += Next->_Myval.totalUncompressedBytes; /*0x141143dca*/
      v4->_Ptr->totalUsefulUncompressedBytes += Next->_Myval.totalUncompressedUsedBytes; /*0x141143dd3*/
      v4->_Ptr->totalNumberOfBytesSent += ((__int64 (__fastcall *)(RBX::Graphics::TextureVulkan::DownloadBuffer *))v10->copyData)(a1: v10); /*0x141143de3*/
      ++v4->_Ptr->totalNumberOfSentBlobs; /*0x141143de9*/
      v57[0] = 0; /*0x141143dec*/
      RBX::Network::NetworkStream::writeBytes( /*0x141143dff*/
        this: (RBX::Network::NetworkStream *)v10,
        inByteArray: v57,
        numberOfBytesToWrite: 1u);
      v45 = v4->_Ptr; /*0x141143e04*/
      v58 = v4->_Ptr; /*0x141143e07*/
      memset(&v66, 0, sizeof(v66)); /*0x141143e0f*/
      v46 = Next->_Myval.sharedStrings._Mypair._Myval2._Myfirst; /*0x141143e1c*/
      v47 = Next->_Myval.sharedStrings._Mypair._Myval2._Mylast; /*0x141143e23*/
      if ( v46 != v47 ) /*0x141143e2d*/
      {
        v48 = v47 - v46; /*0x141143e39*/
        if ( v48 > 0xFFFFFFFFFFFFFFFLL ) /*0x141143e4a*/
          goto LABEL_70; /*0x141143e4a*/
        v49 = 16 * v48; /*0x141143e50*/
        if ( v49 < 0x1000 ) /*0x141143e5b*/
        {
          if ( v49 != 0 ) /*0x141143e8e*/
          {
            v51 = (RBX::SharedString *)operator new(size: v49); /*0x141143e98*/
            v45 = v58; /*0x141143e9b*/
          }
          else
          {
            v51 = nullptr; /*0x141143ea2*/
          }
        }
        else
        {
          if ( v49 + 39 < v49 ) /*0x141143e64*/
LABEL_70:
            std::_Throw_bad_array_new_length(); /*0x141143f6b*/
          v50 = operator new(size: v49 + 39); /*0x141143e6a*/
          if ( v50 == nullptr ) /*0x141143e72*/
            _invalid_parameter_noinfo_noreturn(); /*0x141143f46*/
          v51 = (RBX::SharedString *)(((unsigned __int64)v50 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x141143e7c*/
          *(_QWORD *)&v51[-1].readCount = v50; /*0x141143e80*/
          v45 = v58; /*0x141143e84*/
        }
        v66._Mypair._Myval2._Myfirst = v51; /*0x141143ea4*/
        v66._Mypair._Myval2._Mylast = v51; /*0x141143ea8*/
        v66._Mypair._Myval2._Myend = &v51[v49 / 0x10]; /*0x141143eb0*/
        v52 = (char *)v46 - (char *)v51; /*0x141143eb7*/
        v53 = (char *)v51 - (char *)v46 + 8; /*0x141143ec0*/
        do /*0x141143eef*/
        {
          h = v46->flyweight.h.h; /*0x141143ed0*/
          v51->flyweight.h.h = v46->flyweight.h.h; /*0x141143ed3*/
          _InterlockedIncrement(&h->ref.value_); /*0x141143ed6*/
          *(_DWORD *)((char *)&v46->flyweight.h.h + v53) = *(_DWORD *)((char *)&v46->flyweight.h.h + v53 + v52); /*0x141143ee2*/
          ++v51; /*0x141143ee4*/
          ++v46; /*0x141143ee8*/
        }
        while ( v46 != v47 ); /*0x141143eef*/
        v66._Mypair._Myval2._Mylast = v51; /*0x141143ef1*/
      }
      v75._Ptr = (RBX::Network::NetworkStream *)v10; /*0x141143ef5*/
      v75._Rep = v64; /*0x141143efd*/
      bitStream = 0; /*0x141143f04*/
      RBX::Network::PreserializedReplicationCache::addToCacheSetAndUpdate( /*0x141143f23*/
        this: v45,
        stream: &v75,
        hasMegaClusterInstance: Next->_Myval.hasMegaClusterInBlob,
        hasWorkspaceInstance: Next->_Myval.hasWorkspaceInBlob,
        sharedStrings: &v66);
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&bitStream); /*0xf1c0000000000014*/
    }
    Next = Next->_Next; /*0x141143f29*/
    v4 = v82; /*0x141143f2c*/
  }
  v4->_Ptr->containsCompleteStreamsInCacheSet = true; /*0x141143f50*/
}

// Address: 0x141143f80 | Name: ?getReadyBitStreamShared@JoinDataItemV2@Replicator@Network@RBX@@UEAA?AV?$shared_ptr@VNetworkStream@Network@RBX@@@std@@XZ
std::shared_ptr<RBX::File> *__fastcall RBX::Network::Replicator::JoinDataItemV2::getReadyBitStreamShared(
        RBX::Network::Replicator::JoinDataItemV2 *this,
        std::shared_ptr<RBX::File> *result)
{
  const RBX::Network::PreserializedReplicationCache *Ptr; // r8
  unsigned __int64 v5; // rbp
  __int64 v6; // rdx
  unsigned __int64 curReadyBitStreamIndex; // r9
  std::unique_ptr<RBX::Network::NetworkStream> *v8; // rax
  RBX::Network::PreserializedReplicationCache::StreamInfo *v9; // rax
  std::_Ref_count_base *Rep; // rcx
  std::_Ref_count_base *v11; // r14
  std::unique_ptr<RBX::Network::NetworkStream> *v12; // rax
  std::unique_ptr<RBX::Network::NetworkStream> *v13; // r15
  std::_Ref_count_base_vtbl *Myval2; // r14
  RBX::Network::NetworkStream *v15; // rcx
  std::_Ref_count_base *v16; // rax
  std::_Ref_count_base *v17; // r14
  unsigned __int64 v18; // rdx
  __int64 v19; // rdx
  std::shared_ptr<RBX::Network::NetworkStream> *Myfirst; // rax
  std::_Ref_count_base *v21; // rcx
  unsigned int megaClusterInstanceBlobIndex; // ecx
  unsigned int workspaceInstanceBlobIndex; // eax
  std::shared_ptr<RBX::File> *v25; // [rsp+78h] [rbp+10h]
  std::unique_ptr<RBX::Network::NetworkStream> v26; // [rsp+80h] [rbp+18h] BYREF
  std::unique_ptr<RBX::Network::NetworkStream> v27; // [rsp+88h] [rbp+20h] BYREF

  v25 = result; /*0x141143f80*/
  Ptr = this->joinCacheStreamData._Ptr; /*0x141143fa1*/
  if ( FFlag::SharedStringsDistribute.value ) /*0x141143fb8*/
    v5 = Ptr->readyBitStreamListInfo._Mypair._Myval2._Mylast - Ptr->readyBitStreamListInfo._Mypair._Myval2._Myfirst; /*0x141143fd6*/
  else
    v5 = Ptr->readyBitstreamListShared_deprecated._Mypair._Myval2._Mylast /*0x141143fe3*/
       - Ptr->readyBitstreamListShared_deprecated._Mypair._Myval2._Myfirst;
  __wind
  {
    if ( DFLog::ReplicationDataCaching != 0 )
    {
      if ( FFlag::SharedStringsDistribute.value ) /*0x141143ff6*/
        v6 = Ptr->readyBitStreamListInfo._Mypair._Myval2._Mylast - Ptr->readyBitStreamListInfo._Mypair._Myval2._Myfirst; /*0x141144011*/
      else
        v6 = Ptr->readyBitstreamListShared_deprecated._Mypair._Myval2._Mylast /*0x14114401e*/
           - Ptr->readyBitstreamListShared_deprecated._Mypair._Myval2._Myfirst;
      FLog::FastLog(
        level: DFLog::ReplicationDataCaching,
        message: "[DFLog::ReplicationDataCaching] JoinDataItemV2::getReadyBitStream: readyBitstreamList size: %d",
        arg0: (const void *)(int)v6);
    }
    result->_Ptr = nullptr; /*0x141144035*/
    result->_Rep = nullptr; /*0x141144038*/
    if ( FFlag::SharedStringsDistribute.value )
    {
      curReadyBitStreamIndex = this->curReadyBitStreamIndex; /*0x141144051*/
      if ( curReadyBitStreamIndex >= v5 ) /*0x14114405b*/
        return result; /*0x14114405b*/
      if ( this->curReadyBitStreamIndexForSharedStrings <= (unsigned int)curReadyBitStreamIndex ) /*0x141144068*/
      {
        v8 = RBX::Network::Replicator::JoinDataItemV2::serializeASharedStringVector( /*0x141144097*/
               this,
               result: &v26,
               sharedStrings: (const std::vector<RBX::SharedString> *)((char *)&this->joinCacheStreamData._Ptr->readyBitStreamListInfo._Mypair._Myval2._Myfirst->sharedStringsInBlob
                                                      + 32 * curReadyBitStreamIndex
                                                      + 8 * curReadyBitStreamIndex),
               indexToWrite: &this->curIndexOfSharedStringToWriteInBlob);
        __wind /*0xf1c0000000000040*/
        {
          std::shared_ptr<RBX::Network::NetworkStream>::operator=<RBX::Network::NetworkStream,std::default_delete<RBX::Network::NetworkStream>>( /*0x1411440a3*/
            this: (std::shared_ptr<RBX::Network::NetworkStream> *)result,
            _Right: v8);
        }
        __unwind
        {
          RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: (std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *)&v26); /*0xf1c0000000000038*/
        }
        if ( v26._Mypair._Myval2 != nullptr ) /*0x1411440b4*/
          ((void (__fastcall *)(RBX::Network::NetworkStream *, __int64))v26._Mypair._Myval2->dtr_AbstractBitStream)( /*0x1411440be*/
            a1: v26._Mypair._Myval2,
            a2: 1);
        LODWORD(curReadyBitStreamIndex) = this->curReadyBitStreamIndex; /*0x1411440d3*/
        if ( this->curIndexOfSharedStringToWriteInBlob == this->joinCacheStreamData._Ptr->readyBitStreamListInfo._Mypair._Myval2._Myfirst[(unsigned int)curReadyBitStreamIndex].sharedStringsInBlob._Mypair._Myval2._Mylast /*0x1411440ee*/
                                                        - this->joinCacheStreamData._Ptr->readyBitStreamListInfo._Mypair._Myval2._Myfirst[(unsigned int)curReadyBitStreamIndex].sharedStringsInBlob._Mypair._Myval2._Myfirst )
        {
          this->curIndexOfSharedStringToWriteInBlob = 0; /*0x1411440f0*/
          ++this->curReadyBitStreamIndexForSharedStrings; /*0x1411440f7*/
        }
      }
      if ( result->_Ptr == nullptr ) /*0x141144101*/
      {
        if ( (unsigned int)curReadyBitStreamIndex < v5 ) /*0x14114410d*/
        {
          v9 = &this->joinCacheStreamData._Ptr->readyBitStreamListInfo._Mypair._Myval2._Myfirst[(unsigned int)curReadyBitStreamIndex]; /*0x14114411f*/
          Rep = v9->streamOfBlob._Rep; /*0x141144123*/
          if ( Rep != nullptr ) /*0x14114412a*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x14114412c*/
            Rep = v9->streamOfBlob._Rep; /*0x141144130*/
          }
          result->_Ptr = (RBX::File *)v9->streamOfBlob._Ptr; /*0x141144137*/
          v11 = result->_Rep; /*0x14114413a*/
          result->_Rep = Rep; /*0x14114413e*/
          if ( v11 == nullptr ) /*0x141144145*/
            goto LABEL_47; /*0x141144145*/
          goto LABEL_44; /*0x141144145*/
        }
        return result; /*0x14114410d*/
      }
    }
    else
    {
      if ( this->curJoinSharedStringVectorIndex < (unsigned __int64)(this->joinCacheStreamData._Ptr->sharedStrings_deprecated._Mypair._Myval2._Mylast
                                                                   - this->joinCacheStreamData._Ptr->sharedStrings_deprecated._Mypair._Myval2._Myfirst) )
      {
        if ( DFLog::ReplicationDataCaching != 0 )
          FLog::FastLog(
            level: DFLog::ReplicationDataCaching,
            message: "[DFLog::ReplicationDataCaching] ReplicationDataCache::generateDataBlobs : serializing and creating blob for sharedStrings",
            arg0: nullptr);
        v12 = RBX::Network::Replicator::JoinDataItemV2::serializeJoinDataSharedStrings_deprecated(this, result: &v27); /*0x1411441a4*/
        v13 = v12; /*0x1411441a9*/
        __wind /*0xf1c0000000000028*/
        {
          Myval2 = (std::_Ref_count_base_vtbl *)v12->_Mypair._Myval2; /*0x1411441ac*/
          v15 = nullptr; /*0x1411441af*/
          v16 = nullptr; /*0x1411441b2*/
          if ( Myval2 != nullptr ) /*0x1411441b8*/
          {
            v16 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x1411441bf*/
            v25 = (std::shared_ptr<RBX::File> *)v16; /*0x1411441c4*/
            if ( v16 != nullptr ) /*0x1411441cc*/
            {
              *v16 = 0; /*0x1411441d1*/
              v16->_Uses = 1; /*0x1411441d4*/
              v16->_Weaks = 1; /*0x1411441db*/
              v16->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count_resource<RBX::Network::NetworkStream *,std::default_delete<RBX::Network::NetworkStream>>::`vftable'; /*0x1411441e9*/
              v16[1].__vftable = Myval2; /*0x1411441ec*/
            }
            else
            {
              v16 = nullptr; /*0x1411441f2*/
            }
            v13->_Mypair._Myval2 = nullptr; /*0x1411441f5*/
            v15 = (RBX::Network::NetworkStream *)Myval2; /*0x1411441f8*/
          }
          result->_Ptr = (RBX::File *)v15; /*0x1411441fb*/
          v17 = result->_Rep; /*0x1411441fe*/
          result->_Rep = v16; /*0x141144202*/
          if ( v17 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v17->_Uses, 0xFFFFFFFF) == 1 ) /*0x141144216*/
          {
            v17->_Destroy(this: v17); /*0x14114421e*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v17->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14114422b*/
              v17->_Delete_this(this: v17); /*0x141144233*/
          }
        }
        __unwind
        {
          RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: (std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *)&v27); /*0xf1c0000000000020*/
        }
        if ( v27._Mypair._Myval2 != nullptr ) /*0x141144242*/
          ((void (__fastcall *)(RBX::Network::NetworkStream *, __int64))v27._Mypair._Myval2->dtr_AbstractBitStream)( /*0x14114424c*/
            a1: v27._Mypair._Myval2,
            a2: 1);
      }
      if ( result->_Ptr == nullptr ) /*0x141144252*/
      {
        v18 = this->curReadyBitStreamIndex; /*0x14114425c*/
        if ( v18 < v5 ) /*0x141144265*/
        {
          v19 = v18; /*0x14114426b*/
          Myfirst = this->joinCacheStreamData._Ptr->readyBitstreamListShared_deprecated._Mypair._Myval2._Myfirst; /*0x141144272*/
          v21 = Myfirst[v19]._Rep; /*0x141144276*/
          if ( v21 != nullptr ) /*0x14114427e*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&v21->_Uses); /*0x141144280*/
            v21 = Myfirst[v19]._Rep; /*0x141144284*/
          }
          result->_Ptr = (RBX::File *)Myfirst[v19]._Ptr; /*0x14114428d*/
          v11 = result->_Rep; /*0x141144290*/
          result->_Rep = v21; /*0x141144294*/
          if ( v11 != nullptr ) /*0x14114429b*/
          {
LABEL_44:
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v11->_Uses, 0xFFFFFFFF) == 1 ) /*0x1411442a8*/
            {
              v11->_Destroy(this: v11); /*0x1411442b0*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v11->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1411442bb*/
                v11->_Delete_this(this: v11); /*0x1411442c3*/
            }
          }
LABEL_47:
          ++this->curReadyBitStreamIndex; /*0x1411442c6*/
          megaClusterInstanceBlobIndex = this->megaClusterInstanceBlobIndex; /*0x1411442cc*/
          if ( megaClusterInstanceBlobIndex == 0 ) /*0x1411442d1*/
          {
            megaClusterInstanceBlobIndex = 0; /*0x1411442d3*/
            if ( this->workspaceInstanceBlobIndex == 0 ) /*0x1411442d9*/
            {
              this->replicator->readyToExchangeTerrainData = true; /*0x1411442df*/
              megaClusterInstanceBlobIndex = this->megaClusterInstanceBlobIndex; /*0x1411442e6*/
            }
          }
          workspaceInstanceBlobIndex = this->workspaceInstanceBlobIndex; /*0x1411442e9*/
          if ( workspaceInstanceBlobIndex != 0 ) /*0x1411442ee*/
            this->workspaceInstanceBlobIndex = workspaceInstanceBlobIndex - 1; /*0x1411442f2*/
          if ( megaClusterInstanceBlobIndex != 0 ) /*0x1411442f7*/
            this->megaClusterInstanceBlobIndex = megaClusterInstanceBlobIndex - 1; /*0x1411442fc*/
        }
        return result; /*0x1411442ff*/
      }
    }
    ++this->sharedStringsInstanceCounters.numOfBlobs; /*0x141144254*/
    return result; /*0x141144257*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v25); /*0x1431a51ab*/
  }
}

// Address: 0x141144320 | Name: ?getType@JoinDataItemV2@Replicator@Network@RBX@@UEBA?AW4ItemType@Item@34@XZ
__int64 __fastcall RBX::Network::Replicator::JoinDataItemV2::getType(RBX::Soundscape::TremoloSoundEffect *this)
{
  return 22; /*0x141144325*/
}

// Address: 0x141144330 | Name: ?isPacketReadyToBeSent@JoinDataItemV2@Replicator@Network@RBX@@UEAA_NXZ
bool __fastcall RBX::Network::Replicator::JoinDataItemV2::isPacketReadyToBeSent(
        RBX::Network::Replicator::JoinDataItemV2 *this)
{
  const RBX::Network::PreserializedReplicationCache *Ptr; // rax
  signed __int64 v3; // kr00_8
  unsigned __int64 v5; // rcx

  Ptr = this->joinCacheStreamData._Ptr; /*0x14114433a*/
  if ( FFlag::SharedStringsDistribute.value ) /*0x14114433e*/
  {
    v3 = (char *)Ptr->readyBitStreamListInfo._Mypair._Myval2._Mylast /*0x141144340*/
       - (char *)Ptr->readyBitStreamListInfo._Mypair._Myval2._Myfirst;
    if ( v3 / 40 == 0 ) /*0x141144363*/
      return false; /*0x141144363*/
    return this->curReadyBitStreamIndex < (unsigned __int64)(v3 / 40); /*0x14114436b*/
  }
  else
  {
    v5 = Ptr->readyBitstreamListShared_deprecated._Mypair._Myval2._Mylast /*0x141144378*/
       - Ptr->readyBitstreamListShared_deprecated._Mypair._Myval2._Myfirst;
    if ( v5 == 0 ) /*0x14114437f*/
      return false; /*0x14114437f*/
    return this->curReadyBitStreamIndex < v5; /*0x141144388*/
  }
}

// Address: 0x1411446f0 | Name: ?prepareStreamsForSend@JoinDataItemV2@Replicator@Network@RBX@@SAXAEAV?$shared_ptr@VPreserializedReplicationCache@Network@RBX@@@std@@AEAVReplicationDataCache@34@AEAV?$list@VReplicationDataBlob@Network@RBX@@V?$allocator@VReplicationDataBlob@Network@RBX@@@std@@@6@_N@Z
void __fastcall RBX::Network::Replicator::JoinDataItemV2::prepareStreamsForSend(
        std::shared_ptr<RBX::Network::PreserializedReplicationCache> *cache,
        FT_ModuleRec_ *replicationDataCache,
        std::list<RBX::Network::ReplicationDataBlob> *notCacheableBlobs,
        bool isJDIv2NoOrderInfo)
{
  const std::list<RBX::Network::ReplicationDataBlob> *FrameTimeStats; // rax
  const std::list<RBX::Network::ReplicationDataBlob> *PartBlobCache; // rax
  const std::list<RBX::Network::ReplicationDataBlob> *CharacterModelRootBlobCache; // rax

  cache->_Ptr->cacheableInstanceCounters = *(RBX::Network::ReplicationCacheCounters *)&replicationDataCache[10].memory; /*0x141144719*/
  cache->_Ptr->notCacheableInstanceCounters = *(RBX::Network::ReplicationCacheCounters *)&replicationDataCache[11].library; /*0x141144726*/
  cache->_Ptr->partsInstanceCounters = *(RBX::Network::ReplicationCacheCounters *)&replicationDataCache[12].clazz; /*0x14114473c*/
  RBX::Network::Replicator::JoinDataItemV2::constructBlobStreams( /*0x141144740*/
    blobList: notCacheableBlobs,
    joinDataItemSubType: NOT_CACHEABLE_INSTANCES,
    cache,
    isJDIv2NoOrderInfo);
  FrameTimeStats = (const std::list<RBX::Network::ReplicationDataBlob> *)RBX::FrameRateManager::getFrameTimeStats(module: replicationDataCache); /*0x141144748*/
  RBX::Network::Replicator::JoinDataItemV2::constructBlobStreams( /*0x14114475c*/
    blobList: FrameTimeStats,
    joinDataItemSubType: CACHEABLE_INSTANCES,
    cache,
    isJDIv2NoOrderInfo);
  PartBlobCache = RBX::Network::ReplicationDataCache::getPartBlobCache(this: (RBX::Network::ReplicationDataCache *)replicationDataCache); /*0x141144764*/
  RBX::Network::Replicator::JoinDataItemV2::constructBlobStreams( /*0x141144778*/
    blobList: PartBlobCache,
    joinDataItemSubType: PART_INSTANCES,
    cache,
    isJDIv2NoOrderInfo);
  CharacterModelRootBlobCache = RBX::Network::ReplicationDataCache::getCharacterModelRootBlobCache(this: (RBX::Network::ReplicationDataCache *)replicationDataCache); /*0x141144780*/
  RBX::Network::Replicator::JoinDataItemV2::constructBlobStreams( /*0x1411447a3*/
    blobList: CharacterModelRootBlobCache,
    joinDataItemSubType: CACHEABLE_INSTANCES,
    cache,
    isJDIv2NoOrderInfo);
}

// Address: 0x1411450b0 | Name: ?readInstance@JoinDataItemV2@Replicator@Network@RBX@@CA_NAEAV234@AEAVNetworkStream@34@AEAVDeserializedNewInstanceItem@34@@Z
// local variable allocation has failed, the output may be wrong!
char __fastcall RBX::Network::Replicator::JoinDataItemV2::readInstance(
        RBX::Network::Replicator *replicator,
        RBX::Network::NetworkStream *bitStream,
        RBX::Network::DeserializedNewInstanceItem *deserializedItem)
{
  RBX::Network::NetworkStream *v4; // rdi
  unsigned __int16 v6; // ax
  unsigned __int64 v7; // r8
  const RBX::Network::NetworkSchema *networkSchema; // rax
  RBX::Network::NetworkSchema::ClassInfo *Myfirst; // r9
  const RBX::Network::NetworkSchema::ClassInfo *v10; // rbx
  const RBX::Reflection::ClassDescriptor *localDescriptor; // r14
  RBX::Instance *Ptr; // rcx
  const RBX::ICreator *Creator; // rax
  __int64 v14; // rax
  RBX::Graphics::FrameRateManagerStatsStringItem *v15; // rdx
  std::_Ref_count_base *v16; // rcx
  volatile signed __int32 *v17; // rbx
  std::_Ref_count_base *Rep; // rbx
  RBX::Instance *v19; // rbx
  RBX::GuidItem<RBX::Instance>::Registry *px; // rdi
  RBX::GuidItem<RBX::Instance>::Registry *v21; // rcx
  RBX::Instance *v22; // rax
  unsigned int *memoryCategory; // rcx
  unsigned int v24; // ecx
  unsigned int v25; // ebx
  boost::unordered::detail::ptr_bucket *buckets; // rsi
  unsigned __int64 bucket_count; // r14
  boost::unordered::detail::ptr_bucket *next; // rdi
  boost::unordered::detail::ptr_bucket *v29; // rcx
  unsigned __int64 v30; // rdx
  boost::unordered::detail::ptr_bucket *v31; // rcx
  boost::unordered::detail::ptr_bucket *v32; // rax
  __int64 v33; // rcx
  const char *v35; // rax
  RBX::ContentId *v36; // rax
  const char *v37; // r14
  Luau::InternalErrorReporter *v38; // rax
  RBX::ContentId *v39; // rax
  const char *v40; // rsi
  RBX::ContentId *v41; // rax
  const char *v42; // rdi
  RBX::ContentId *v43; // rax
  const char *v44; // rbx
  const char *v45; // rax
  RBX::ContentId *v46; // rax
  const char *v47; // rax
  __int64 v48; // [rsp+0h] [rbp-C9h] BYREF
  bool allowDictionaries[8]; // [rsp+20h] [rbp-A9h]
  boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *p_deferredSharedStrings; // [rsp+28h] [rbp-A1h]
  RBX::Network::ReplicationVariantSizeLimitsMetaData *p_metaData; // [rsp+30h] [rbp-99h]
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> _Right; // [rsp+40h] [rbp-89h] BYREF
  RBX::Network::ReplicationVariantSizeLimitsMetaData metaData; // [rsp+50h] [rbp-79h] BYREF
  boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > deferredSharedStrings; // [rsp+70h] [rbp-59h] BYREF
  const RBX::Network::NetworkSchema::ClassInfo *v55; // [rsp+A8h] [rbp-21h]
  RBX::Guid v56; // [rsp+B0h] [rbp-19h] BYREF
  char v57; // [rsp+B8h] [rbp-11h] BYREF
  volatile signed __int32 *v58; // [rsp+C0h] [rbp-9h]
  RBX::Graphics::ProfilerAdorn::Item v59; // [rsp+C8h] [rbp-1h] BYREF
  unsigned __int16 classNetworkId; // [rsp+140h] [rbp+77h] BYREF
  const RBX::Reflection::ClassDescriptor *ms; // [rsp+148h] [rbp+7Fh] OVERLAPPED BYREF

  v4 = bitStream; /*0x1411450d4*/
  if ( DFLog::ReplicationDataCaching != 0 ) /*0x1411450e3*/
    FLog::FastLog( /*0x1411450f0*/
      level: DFLog::ReplicationDataCaching,
      message: "[DFLog::ReplicationDataCaching] Begin reading join instance offset=%X bytes",
      arg0: (const void *)bitStream->readOffset);
  deserializedItem->id = *RBX::Network::IdSerializer::deserializeId(this: replicator, result: &v56, stream: v4); /*0x141145106*/
  if ( !RBX::Network::NetworkStream::readBytes(this: v4, inOutByteArray: &classNetworkId, numberOfBytesToRead: 2u) ) /*0x141145125*/
  {
    std::string::string(this: (std::string *)&metaData, _Ptr: "readFast past end for uint16_t"); /*0x141145642*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000001c*/
    RBX::network_stream_exception::network_stream_exception( /*0x141145650*/
      this: (RBX::network_stream_exception *)&deferredSharedStrings,
      m: (const std::string *)&metaData);
    throw (RBX::network_stream_exception *)&deferredSharedStrings; /*0x141145660*/
  }
  v6 = __ROL2__(classNetworkId, 8); /*0x14114512f*/
  v7 = v6; /*0x141145133*/
  classNetworkId = v6; /*0x141145137*/
  networkSchema = replicator->networkSchema; /*0x14114513c*/
  Myfirst = networkSchema->classInfoByNetworkId._Mypair._Myval2._Myfirst; /*0x141145144*/
  if ( v7 >= networkSchema->classInfoByNetworkId._Mypair._Myval2._Mylast - Myfirst /*0x141145184*/
    || (v10 = &Myfirst[v7], v55 = v10, v10 == nullptr) )
  {
    RBX::throw_runtime_error(fmt: "Join data contained invalid class network id"); /*0x141145631*/
  }
  deserializedItem->classInfo = v10; /*0x14114518a*/
  localDescriptor = v10->localDescriptor; /*0x14114518e*/
  ms = localDescriptor; /*0x141145192*/
  if ( RBX::GuidItem<RBX::Instance>::Registry::lookupByGuid(
         this: replicator->guidRegistry.px,
         guid: &deserializedItem->id,
         result: &deserializedItem->instance) )
  {
    Ptr = deserializedItem->instance._Ptr; /*0x1411451af*/
    if ( Ptr == nullptr ) /*0x1411451b6*/
    {
      v46 = (RBX::ContentId *)RBX::Guid::readableString( /*0x141145674*/
                                this: &deserializedItem->id,
                                result: (std::string *)&metaData,
                                scopeLength: 32);
      __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000014*/
      v47 = std::string::c_str(this: v46); /*0x14114567d*/
      RBX::throw_runtime_error(fmt: "read join instance got a null object (guid %s)", v47); /*0x14114568c*/
    }
    if ( Ptr->descriptor == v10->localDescriptor )
    {
      __eh34_enter_wind_state(-1, 0); /*0xf1c00000000000b8*/
    }
    else
    {
      v36 = (RBX::ContentId *)RBX::Guid::readableString( /*0x14114558d*/
                                this: &deserializedItem->id,
                                result: (std::string *)&metaData,
                                scopeLength: 4);
      __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000054*/
      v37 = std::string::c_str(this: v36); /*0x14114559b*/
      v38 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)&deserializedItem->instance); /*0x1411455a2*/
      v39 = (RBX::ContentId *)((__int64 (__fastcall *)(Luau::InternalErrorReporter *))v38->onInternalError._Mystorage._Ptrs[0][5].__vftable)(a1: v38); /*0x1411455ad*/
      v40 = std::string::c_str(this: v39); /*0x1411455b8*/
      v41 = (RBX::ContentId *)RBX::Network::RakNetAddressToString( /*0x1411455cd*/
                                result: &v59.text,
                                raknetAddress: &replicator->remotePlayerRakNetAddress,
                                writePort: true,
                                portDelineator: 124);
      __wind
      {
        v42 = std::string::c_str(this: v41); /*0x1411455db*/
        v43 = (RBX::ContentId *)RBX::Guid::readableString( /*0x1411455ec*/
                                  this: &deserializedItem->id,
                                  result: (std::string *)&deferredSharedStrings,
                                  scopeLength: 4);
        __wind
        {
          v44 = std::string::c_str(this: v43); /*0x1411455fa*/
          v45 = std::string::c_str(this: (RBX::ContentId *)ms->name); /*0x141145605*/
          RBX::throw_runtime_error(
            fmt: "Replication: Bad re-binding in deserialize new instance %s-%s << %s, %s-%s",
            v45,
            v44,
            v42,
            v40,
            v37);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&deferredSharedStrings); /*0xf1c0000000000034*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v59); /*0xf1c0000000000040*/
      }
    }
    if ( __eh34_unwind(0) ) /*0xf1c00000000000a4*/
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&metaData); /*0xf1c00000000000a8*/
      __eh34_propagate_exception_into_caller(0, -1); /*0xf1c00000000000ac*/
    }
    __eh34_exit_wind_state(0, -1); /*0xf1c00000000000b0*/
  }
  else if ( localDescriptor != nullptr )
  {
    Creator = RBX::Creatable<RBX::Instance>::getCreator(name: localDescriptor->name); /*0x1411451dc*/
    if ( Creator != nullptr ) /*0x1411451e9*/
    {
      v14 = Creator->create( /*0x1411451fb*/
              this: (RBX::ICreator *)Creator,
              result: (std::shared_ptr<RBX::Reflection::DescribedBase> *)&v57,
              a3: ReplicationCreator);
      v15 = *(RBX::Graphics::FrameRateManagerStatsStringItem **)v14; /*0x1411451fe*/
      v16 = *(std::_Ref_count_base **)(v14 + 8); /*0x141145201*/
      if ( v16 != nullptr ) /*0x141145208*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v16->_Uses); /*0x14114520a*/
        v16 = *(std::_Ref_count_base **)(v14 + 8); /*0x14114520e*/
      }
      _Right._Ptr = v15; /*0x141145212*/
      _Right._Rep = v16; /*0x141145217*/
      v17 = v58; /*0x14114521c*/
      if ( v58 != nullptr && _InterlockedExchangeAdd(v58 + 2, 0xFFFFFFFF) == 1 ) /*0x14114522f*/
      {
        (**(void (__fastcall ***)(volatile signed __int32 *))v17)(a1: v17); /*0x141145237*/
        if ( _InterlockedExchangeAdd(v17 + 3, 0xFFFFFFFF) == 1 ) /*0x141145243*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 8LL))(a1: v17); /*0x14114524b*/
      }
    }
    else
    {
      _Right = 0; /*0x141145253*/
    }
    std::shared_ptr<RBX::Network::CachedBitstream>::operator=( /*0x141145262*/
      this: (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)&deserializedItem->instance,
      &_Right);
    if ( _Right._Rep != nullptr /*0x14114527b*/
      && _InterlockedExchangeAdd((volatile signed __int32 *)&_Right._Rep->_Uses, 0xFFFFFFFF) == 1 )
    {
      Rep = _Right._Rep; /*0x14114527d*/
      _Right._Rep->_Destroy(this: _Right._Rep); /*0x141145288*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141145292*/
        _Right._Rep->_Delete_this(this: _Right._Rep); /*0x14114529c*/
    }
    v19 = deserializedItem->instance._Ptr; /*0x14114529f*/
    if ( v19 == nullptr )
    {
      v35 = std::string::c_str(this: (RBX::ContentId *)deserializedItem->classInfo->localDescriptor->name); /*0x14114556a*/
      RBX::throw_runtime_error(fmt: "Replication: Can't create object of type %s", v35);
    }
    px = replicator->guidRegistry.px; /*0x1411452ac*/
    v21 = v19->registry.px; /*0x1411452b8*/
    if ( v21 != nullptr ) /*0x1411452be*/
      RBX::GuidItem<RBX::Instance>::Registry::unregister(this: v21, item: &v19->RBX::GuidItem<RBX::Instance>); /*0x1411452c0*/
    v19->guid.scope.peerId.peerId = deserializedItem->id.scope.peerId.peerId; /*0x1411452c9*/
    v19->guid.index = deserializedItem->id.index; /*0x1411452d0*/
    RBX::GuidItem<RBX::Instance>::Registry::reg(this: px, item: v19); /*0x1411452d9*/
    v19->onGuidChanged(this: v19); /*0x1411452e4*/
    deserializedItem->newInstance = true; /*0x1411452e7*/
    if ( DFFlag::DebugAvatarProfilerCallers.value && !replicator->isServerReplicator(this: replicator) ) /*0x141145304*/
      RBX::AvatarProfiler::logNetInstanceCreate(cdesc: localDescriptor, inst: deserializedItem->instance._Ptr); /*0x14114530d*/
    v4 = bitStream; /*0x141145312*/
  }
  if ( deserializedItem->newInstance && (v22 = deserializedItem->instance._Ptr) != nullptr ) /*0x141145324*/
  {
    memoryCategory = (unsigned int *)v22->descriptor->memoryCategory; /*0x14114532a*/
    if ( memoryCategory != nullptr ) /*0x141145334*/
      v24 = *memoryCategory; /*0x141145336*/
    else
      v24 = RBX::Memory::InstanceObject; /*0x14114533a*/
  }
  else
  {
    v24 = RBX::Memory::NetworkReplicator; /*0x141145342*/
  }
  v25 = RBX::Memory::setCurrentCategory(category: v24); /*0x14114534d*/
  LODWORD(ms) = v25; /*0x14114534f*/
  __wind /*0xf1c0000000000098*/
  {
    deferredSharedStrings.table_.current_ = false; /*0x141145352*/
    deferredSharedStrings.table_.bucket_count_ = 16; /*0x141145356*/
    deferredSharedStrings.table_.size_ = 0; /*0x141145361*/
    deferredSharedStrings.table_.mlf_ = 1.0; /*0x14114536d*/
    *(_OWORD *)&deferredSharedStrings.table_.max_load_ = 0; /*0x141145375*/
    memset(&metaData, 0, sizeof(metaData)); /*0x14114537a*/
    p_metaData = &metaData; /*0x14114538e*/
    p_deferredSharedStrings = &deferredSharedStrings; /*0x141145397*/
    allowDictionaries[0] = false; /*0x14114539c*/
    __wind /*0xf1c0000000000068*/
    {
      RBX::Network::DeserializedNewInstanceItem::schemaReadPropertyGroup( /*0x1411453ad*/
        this: deserializedItem,
        replicator,
        bitStream: v4,
        propertyGroup: (RBX::Network::PropertyGroup)0,
        allowDictionaries: allowDictionaries[0],
        deferredSharedStrings: p_deferredSharedStrings,
        metaData: p_metaData);
      buckets = deferredSharedStrings.table_.buckets_; /*0x1411453b3*/
      if ( deferredSharedStrings.table_.buckets_ != nullptr ) /*0x1411453ba*/
      {
        if ( deferredSharedStrings.table_.size_ != 0 ) /*0x1411453c4*/
        {
          bucket_count = deferredSharedStrings.table_.bucket_count_; /*0x1411453ca*/
          next = deferredSharedStrings.table_.buckets_[deferredSharedStrings.table_.bucket_count_].next_; /*0x1411453ce*/
          do /*0x141145490*/
          {
            buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_; /*0x1411453e3*/
            v29 = next[6].next_; /*0x1411453e7*/
            if ( v29 != nullptr ) /*0x1411453ee*/
            {
              if ( (((char *)next[8].next_ - (char *)v29) & 0xFFFFFFFFFFFFFFE0uLL) >= 0x1000 ) /*0x141145402*/
              {
                if ( (unsigned __int64)((char *)v29 - (char *)v29[-1].next_ - 8) > 0x1F ) /*0x141145417*/
                  goto LABEL_54; /*0x141145417*/
                v29 = v29[-1].next_; /*0x14114541d*/
              }
              operator delete(ptr: v29); /*0x141145420*/
              next[6].next_ = nullptr; /*0x141145425*/
              next[7].next_ = nullptr; /*0x141145429*/
              next[8].next_ = nullptr; /*0x14114542d*/
            }
            v30 = (unsigned __int64)next[5].next_; /*0x141145431*/
            if ( v30 >= 0x10 ) /*0x141145439*/
            {
              v31 = next[2].next_; /*0x14114543b*/
              if ( v30 + 1 >= 0x1000 ) /*0x141145449*/
              {
                if ( (unsigned __int64)((char *)v31 - (char *)v31[-1].next_ - 8) > 0x1F ) /*0x14114545e*/
                  goto LABEL_54; /*0x14114545e*/
                v31 = v31[-1].next_; /*0x141145460*/
              }
              operator delete(ptr: v31); /*0x141145463*/
            }
            next[4].next_ = nullptr; /*0x141145468*/
            next[5].next_ = (boost::unordered::detail::ptr_bucket *)15; /*0x14114546c*/
            LOBYTE(next[2].next_) = 0; /*0x141145474*/
            operator delete(ptr: next); /*0x141145480*/
            --deferredSharedStrings.table_.size_; /*0x141145485*/
            next = buckets[bucket_count].next_; /*0x141145489*/
          }
          while ( next != nullptr ); /*0x141145490*/
          buckets = deferredSharedStrings.table_.buckets_; /*0x141145496*/
          v4 = bitStream; /*0x14114549a*/
        }
        v32 = buckets; /*0x1411454aa*/
        if ( 8 * deferredSharedStrings.table_.bucket_count_ + 8 >= 0x1000 ) /*0x1411454b4*/
        {
          buckets = buckets[-1].next_; /*0x1411454ba*/
          if ( (unsigned __int64)((char *)v32 - (char *)buckets - 8) > 0x1F ) /*0x1411454c9*/
LABEL_54:
            _invalid_parameter_noinfo_noreturn(); /*0x1411454cb*/
        }
        operator delete(ptr: buckets); /*0x1411454d5*/
        deferredSharedStrings.table_.buckets_ = nullptr; /*0x1411454da*/
        deferredSharedStrings.table_.max_load_ = 0; /*0x1411454de*/
      }
    }
    __unwind
    {
      boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>>::~unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>>(this: &deferredSharedStrings); /*0xf1c0000000000078*/
    }
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&ms); /*0xf1c0000000000084*/
  }
  __wind /*0xf1c000000000008c*/
  {
    RBX::Memory::setCurrentCategory(category: v25); /*0x1411454e4*/
  }
  __unwind
  {
    __std_terminate(a1: v33, a2: &v48); /*0x142f39fa8*/
  }
  deserializedItem->parentId = *RBX::Network::IdSerializer::deserializeId(this: replicator, result: &v56, stream: v4); /*0x1411454ff*/
  if ( v55->localDescriptor != nullptr ) /*0x141145510*/
  {
    RBX::GuidItem<RBX::Instance>::Registry::lookupByGuid( /*0x14114551e*/
      this: replicator->guidRegistry.px,
      guid: &deserializedItem->parentId,
      result: &deserializedItem->parent);
    return 1; /*0x141145523*/
  }
  else
  {
    if ( DFLog::ReplicationDataCaching != 0 ) /*0x141145549*/
      FLog::FastLog( /*0x141145555*/
        level: DFLog::ReplicationDataCaching,
        message: "[DFLog::ReplicationDataCaching] Discarding join instance due to null local descriptor (schema diff)",
        arg0: nullptr);
    return 0; /*0x14114555a*/
  }
}

// Address: 0x1411456a0 | Name: ?serializeASharedStringVector@JoinDataItemV2@Replicator@Network@RBX@@AEAA?AV?$unique_ptr@VNetworkStream@Network@RBX@@U?$default_delete@VNetworkStream@Network@RBX@@@std@@@std@@AEBV?$vector@VSharedString@RBX@@V?$allocator@VSharedString@RBX@@@std@@@6@AEAH@Z
std::unique_ptr<RBX::Network::NetworkStream> *__fastcall RBX::Network::Replicator::JoinDataItemV2::serializeASharedStringVector(
        RBX::Network::Replicator::JoinDataItemV2 *this,
        std::unique_ptr<RBX::Network::NetworkStream> *result,
        const std::vector<RBX::SharedString> *sharedStrings,
        int *indexToWrite)
{
  char *v8; // rax
  char *v9; // r9
  RBX::SharedString *Myfirst; // r8
  unsigned __int64 v11; // rdx
  RBX::SharedString *v12; // rcx
  char *v13; // rdx
  RBX::Network::Replicator *replicator; // rdi
  RBX::SharedString *v15; // rbx
  char *Ptr; // rcx
  char *v17; // rcx
  int v18; // r13d
  boost::unordered::detail::ptr_node<RBX::SharedString> *v19; // rax
  RBX::Network::NetworkStream *v20; // rax
  RBX::Network::NetworkStream *Myval2; // rcx
  unsigned int numberOfBytesUsed; // ebx
  unsigned int v23; // edx
  void *v24; // rcx
  unsigned __int8 *v25; // rcx
  std::unique_ptr<RBX::Network::NetworkStream> *v26; // rax
  int inByteArray; // [rsp+28h] [rbp-E0h] BYREF
  std::string hash; // [rsp+30h] [rbp-D8h] BYREF
  unsigned __int64 v29; // [rsp+50h] [rbp-B8h]
  std::pair<std::string,RBX::SharedString> v30; // [rsp+58h] [rbp-B0h] BYREF
  std::pair<std::string const ,RBX::SharedString> k; // [rsp+88h] [rbp-80h] BYREF
  std::pair<boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<RBX::SharedString> >,bool> v32; // [rsp+B8h] [rbp-50h] BYREF
  RBX::Network::NetworkStream outBitStream; // [rsp+C8h] [rbp-40h] BYREF
  std::pair<boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<std::string const ,RBX::SharedString> > >,bool> v34; // [rsp+108h] [rbp+0h] BYREF

  __wind /*0xf1c000000000009c*/
  {
    *(_DWORD *)hash._Mypair._Myval2._Bx._Buf = 0; /*0x1411456d9*/
    RBX::Network::NetworkStream::NetworkStream( /*0x141145717*/
      this: &outBitStream,
      initialBytesToAllocate: (int)(float)((float)(1000 * DFLog::MaxJoinDataSizeKB)
                 * (float)((float)DFInt::JoinDataItemEstimatedCompressionRatioHundreths / 100.0)));
    __wind /*0xf1c0000000000078*/
    {
      result->_Mypair._Myval2 = nullptr; /*0x14114571d*/
      *(_DWORD *)hash._Mypair._Myval2._Bx._Buf = 1; /*0x141145721*/
      v18 = 0; /*0x141145729*/
      *(_QWORD *)&hash._Mypair._Myval2._Bx._Alias[8] = 0; /*0x14114572c*/
      hash._Mypair._Myval2._Myres = 0; /*0x141145731*/
      v29 = 15; /*0x141145736*/
      v8 = (char *)operator new(size: 0x20u); /*0x141145747*/
      __wind /*0xf1c000000000006c*/
      {
        v9 = v8; /*0x14114574c*/
        hash._Mypair._Myval2._Myres = 16; /*0x14114574f*/
        v29 = 31; /*0x141145758*/
        *(_OWORD *)v8 = 0; /*0x141145764*/
        v8[16] = 0; /*0x141145767*/
        *(_QWORD *)&hash._Mypair._Myval2._Bx._Alias[8] = v8; /*0x14114576b*/
        Myfirst = sharedStrings->_Mypair._Myval2._Myfirst; /*0x141145770*/
        v11 = *indexToWrite; /*0x14114577e*/
        if ( v11 < sharedStrings->_Mypair._Myval2._Mylast - sharedStrings->_Mypair._Myval2._Myfirst ) /*0x141145784*/
        {
          while ( 1 ) /*0x141145797*/
          {
            v12 = &Myfirst[(int)v11]; /*0x141145797*/
            v13 = &hash._Mypair._Myval2._Bx._Buf[8]; /*0x14114579a*/
            if ( v29 >= 0x10 ) /*0x1411457a5*/
              v13 = v9; /*0x1411457a5*/
            RBX::SharedString::getHash(this: v12, out: v13, size: hash._Mypair._Myval2._Myres); /*0x1411457ae*/
            replicator = this->replicator; /*0x1411457b3*/
            v15 = &sharedStrings->_Mypair._Myval2._Myfirst[*indexToWrite]; /*0x1411457be*/
            std::string::string( /*0x1411457cb*/
              this: (rtc::webrtc_checks_impl::ToStringVal *)&v30,
              __that: (const rtc::webrtc_checks_impl::ToStringVal *)&hash._Mypair._Myval2._Bx._Alias[8]);
            v30.second.flyweight.h.h = v15->flyweight.h.h; /*0x1411457d3*/
            _InterlockedIncrement(&v30.second.flyweight.h.h->ref.value_); /*0x1411457d8*/
            v30.second.readCount = v15->readCount; /*0x1411457df*/
            *(_DWORD *)hash._Mypair._Myval2._Bx._Buf |= 2u; /*0x1411457e3*/
            __wind /*0xf1c0000000000060*/
            {
              k.first._Mypair._Myval2._Bx = v30.first._Mypair._Myval2._Bx; /*0x1411457ed*/
              *(_OWORD *)&k.first._Mypair._Myval2._Mysize = *(_OWORD *)&v30.first._Mypair._Myval2._Mysize; /*0x1411457f6*/
              v30.first._Mypair._Myval2._Mysize = 0; /*0x1411457fc*/
              v30.first._Mypair._Myval2._Myres = 15; /*0x141145801*/
              v30.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14114580a*/
              k.second.flyweight.h.h = v30.second.flyweight.h.h; /*0x141145813*/
              _InterlockedIncrement(&v30.second.flyweight.h.h->ref.value_); /*0x141145817*/
              k.second.readCount = v30.second.readCount; /*0x14114581f*/
              __wind /*0xf1c0000000000054*/
              {
                boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::SharedString>>,std::string,RBX::SharedString,boost::hash<std::string>,std::equal_to<std::string>>>::emplace_impl<std::pair<std::string const,RBX::SharedString>>( /*0x141145835*/
                  this: &replicator->sharedStringSenderReverseLookup.table_,
                  result: &v34,
                  k: &k.first,
                  <args_0>: &k);
                boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &k.second.flyweight.h); /*0x14114583f*/
              }
              __unwind
              {
                boost::_bi::storage3<boost::arg<1>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::SharedString>>::~storage3<boost::arg<1>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::SharedString>>(this: (std::pair<std::string,RBX::SharedString> *)&k); /*0xf1c000000000004c*/
              }
              if ( k.first._Mypair._Myval2._Myres >= 0x10 ) /*0x14114584c*/
              {
                Ptr = k.first._Mypair._Myval2._Bx._Ptr; /*0x141145851*/
                if ( k.first._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14114585f*/
                {
                  Ptr = *((char **)k.first._Mypair._Myval2._Bx._Ptr - 1); /*0x141145865*/
                  if ( (unsigned __int64)(k.first._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141145874*/
                    _invalid_parameter_noinfo_noreturn(); /*0x141145972*/
                }
                operator delete(ptr: Ptr); /*0x14114587a*/
              }
              k.first._Mypair._Myval2._Mysize = 0; /*0x14114587f*/
              k.first._Mypair._Myval2._Myres = 15; /*0x141145883*/
              k.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14114588b*/
              boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &v30.second.flyweight.h); /*0x141145894*/
              if ( v30.first._Mypair._Myval2._Myres >= 0x10 ) /*0x1411458a2*/
              {
                v17 = v30.first._Mypair._Myval2._Bx._Ptr; /*0x1411458a7*/
                if ( v30.first._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1411458b6*/
                {
                  v17 = *((char **)v30.first._Mypair._Myval2._Bx._Ptr - 1); /*0x1411458bc*/
                  if ( (unsigned __int64)(v30.first._Mypair._Myval2._Bx._Ptr - v17 - 8) > 0x1F ) /*0x1411458cb*/
                    _invalid_parameter_noinfo_noreturn(); /*0x141145979*/
                }
                operator delete(ptr: v17); /*0x1411458d1*/
              }
            }
            __unwind
            {
              boost::_bi::storage3<boost::arg<1>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::SharedString>>::~storage3<boost::arg<1>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::SharedString>>(this: &v30); /*0xf1c0000000000040*/
            }
            boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::SharedString>,RBX::SharedString,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::emplace_impl<RBX::SharedString const &>( /*0x1411458f2*/
              this: &this->replicator->sharedStringSentSet.table_,
              result: &v32,
              k: &sharedStrings->_Mypair._Myval2._Myfirst[*indexToWrite],
              <args_0>: &sharedStrings->_Mypair._Myval2._Myfirst[*indexToWrite]);
            if ( v32.second ) /*0x1411458fb*/
            {
              RBX::Network::Replicator::writeASharedString( /*0x14114590b*/
                &outBitStream,
                sharedString: &sharedStrings->_Mypair._Myval2._Myfirst[*indexToWrite]);
              ++v18; /*0x141145910*/
            }
            if ( (float)(int)outBitStream.numberOfBytesUsed >= (float)((float)(1000 * DFLog::MaxJoinDataSizeKB) /*0x141145948*/
                                                                     * (float)((float)DFInt::JoinDataItemEstimatedCompressionRatioHundreths
                                                                             / 100.0)) )
              break; /*0x141145948*/
            LODWORD(v11) = *indexToWrite + 1; /*0x14114594d*/
            *indexToWrite = v11; /*0x14114594f*/
            Myfirst = sharedStrings->_Mypair._Myval2._Myfirst; /*0x141145952*/
            if ( (int)v11 >= (unsigned __int64)(sharedStrings->_Mypair._Myval2._Mylast /*0x141145966*/
                                              - sharedStrings->_Mypair._Myval2._Myfirst) )
              break; /*0x141145966*/
            v9 = *(char **)&hash._Mypair._Myval2._Bx._Alias[8]; /*0x141145968*/
          }
        }
        v19 = (boost::unordered::detail::ptr_node<RBX::SharedString> *)operator new(size: 0x40u); /*0x141145985*/
        __wind /*0xf1c0000000000030*/
        {
          v32.first.node_ = v19; /*0x14114598a*/
          if ( v19 != nullptr ) /*0x141145991*/
            v20 = RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)v19); /*0x141145996*/
          else
            v20 = nullptr; /*0x14114599d*/
          Myval2 = result->_Mypair._Myval2; /*0x1411459a0*/
          result->_Mypair._Myval2 = v20; /*0x1411459a4*/
          if ( Myval2 != nullptr ) /*0x1411459ab*/
            ((void (__fastcall *)(RBX::Network::NetworkStream *, __int64))Myval2->dtr_AbstractBitStream)( /*0x1411459b5*/
              a1: Myval2,
              a2: 1);
        }
        __unwind
        {
          operator delete(ptr: v32.first.node_); /*0x143165ee5*/
        }
        LOBYTE(inByteArray) = -125; /*0x1411459b7*/
        RBX::Network::NetworkStream::writeBytes(this: result->_Mypair._Myval2, &inByteArray, numberOfBytesToWrite: 1u); /*0x1411459cb*/
        RBX::Network::Item::writeItemType(this, stream: result->_Mypair._Myval2, value: ItemTypeJoinDataV2); /*0x1411459dd*/
        LOBYTE(inByteArray) = 1; /*0x1411459e2*/
        RBX::Network::NetworkStream::writeBytes(this: result->_Mypair._Myval2, &inByteArray, numberOfBytesToWrite: 1u); /*0x1411459f6*/
        numberOfBytesUsed = result->_Mypair._Myval2->numberOfBytesUsed; /*0x1411459ff*/
        RBX::Network::Replicator::compressBitStream( /*0x141145a0e*/
          inUncompressedBitStream: &outBitStream,
          outCompressedBitStream: result->_Mypair._Myval2,
          compressRatio: DFInt::JoinDataCompressionLevel);
        if ( this->areCachedStreamsComplete(this) ) /*0x141145a19*/
        {
          LOBYTE(inByteArray) = 0; /*0x141145a20*/
          RBX::Network::NetworkStream::writeBytes(this: result->_Mypair._Myval2, &inByteArray, numberOfBytesToWrite: 1u); /*0x141145a34*/
        }
        v23 = outBitStream.numberOfBytesUsed; /*0x141145a39*/
        this->sharedStringsInstanceCounters.numOfRawBytes += outBitStream.numberOfBytesUsed; /*0x141145a3c*/
        this->sharedStringsInstanceCounters.numOfCompressedBytes += result->_Mypair._Myval2->numberOfBytesUsed /*0x141145a49*/
                                                                  - numberOfBytesUsed;
        this->sharedStringsInstanceCounters.numOfInstances += v18; /*0x141145a4d*/
        this->totalUncompressedBytes += v23; /*0x141145a51*/
        this->totalUsefulUncompressedBytes += v23; /*0x141145a55*/
        this->totalCompressedBytes += result->_Mypair._Myval2->numberOfBytesUsed - numberOfBytesUsed; /*0x141145a62*/
        this->totalNumberOfBytesSent += result->_Mypair._Myval2->GetNumberOfBytesUsed(this: result->_Mypair._Myval2); /*0x141145a70*/
        this->totalNumOfInstances += v18; /*0x141145a74*/
        ++this->totalNumberOfSentBlobs; /*0x141145a78*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&hash._Mypair._Myval2._Bx._Alias[8]); /*0xf1c000000000001c*/
      }
      if ( v29 >= 0x10 ) /*0x141145a85*/
      {
        v24 = *(void **)&hash._Mypair._Myval2._Bx._Alias[8]; /*0x141145a8a*/
        if ( v29 + 1 >= 0x1000 ) /*0x141145a99*/
        {
          v24 = *(void **)(*(_QWORD *)&hash._Mypair._Myval2._Bx._Alias[8] - 8LL); /*0x141145a9f*/
          if ( (unsigned __int64)(*(_QWORD *)&hash._Mypair._Myval2._Bx._Alias[8] - (_QWORD)v24 - 8LL) > 0x1F ) /*0x141145aae*/
            _invalid_parameter_noinfo_noreturn(); /*0x141145ab0*/
        }
        operator delete(ptr: v24); /*0x141145ab7*/
      }
      hash._Mypair._Myval2._Myres = 0; /*0x141145abc*/
      v29 = 15; /*0x141145ac5*/
      hash._Mypair._Myval2._Bx._Buf[8] = 0; /*0x141145ace*/
      v25 = outBitStream.dataVector._Mypair._Myval2._Myfirst; /*0x141145ad3*/
      if ( outBitStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x141145ada*/
      {
        if ( (unsigned __int8 *)(outBitStream.dataVector._Mypair._Myval2._Myend /*0x141145aed*/
                               - outBitStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 )
        {
          v25 = *((unsigned __int8 **)outBitStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x141145af3*/
          if ( (unsigned __int64)(outBitStream.dataVector._Mypair._Myval2._Myfirst - v25 - 8) > 0x1F ) /*0x141145b02*/
            _invalid_parameter_noinfo_noreturn(); /*0x141145b04*/
        }
        operator delete(ptr: v25); /*0x141145b0b*/
      }
      v26 = result; /*0x141145b10*/
    }
    __unwind
    {
      RBX::Network::NetworkStream::~NetworkStream(this: &outBitStream); /*0xf1c0000000000088*/
    }
  }
  __unwind
  {
    if ( (hash._Mypair._Myval2._Bx._Buf[0] & 1) != 0 ) /*0x1431f1381*/
    {
      *(_DWORD *)hash._Mypair._Myval2._Bx._Buf &= ~1u; /*0x1431f1383*/
      RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: (std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *)result); /*0x1431f138e*/
    }
  }
  return v26; /*0x141145b13*/
}

// Address: 0x141145b40 | Name: ?serializeJoinDataSharedStrings_deprecated@JoinDataItemV2@Replicator@Network@RBX@@AEAA?AV?$unique_ptr@VNetworkStream@Network@RBX@@U?$default_delete@VNetworkStream@Network@RBX@@@std@@@std@@XZ
std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *__fastcall RBX::Network::Replicator::JoinDataItemV2::serializeJoinDataSharedStrings_deprecated(
        RBX::Network::Replicator::JoinDataItemV2 *this,
        std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *result)
{
  RBX::Network::NetworkStream *v4; // r14
  unsigned int v5; // r12d
  RBX::Network::NetworkStream *Myval2; // rbx
  RBX::Network::NetworkStream *v7; // rax
  RBX::Network::NetworkStream *v8; // rax
  char *v9; // rax
  std::string *p_hash; // rdx
  RBX::Network::Replicator *replicator; // rdi
  RBX::SharedString *v12; // rbx
  char *Ptr; // rcx
  char *v14; // rcx
  float v15; // xmm2_4
  char *v16; // rcx
  char *v17; // rcx
  RBX::Network::NetworkStream *v18; // rax
  RBX::Network::NetworkStream *v19; // rcx
  unsigned int Mysize; // edi
  RBX::Time *v21; // rax
  RBX::Time *v22; // rax
  float v23; // xmm0_4
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *v24; // rax
  char v25; // [rsp+20h] [rbp-A9h]
  std::string hash; // [rsp+28h] [rbp-A1h] BYREF
  std::pair<std::string,RBX::SharedString> v27; // [rsp+48h] [rbp-81h] BYREF
  std::pair<std::string const ,RBX::SharedString> k; // [rsp+78h] [rbp-51h] BYREF
  RBX::Network::NetworkStream *v29; // [rsp+A8h] [rbp-21h]
  RBX::Time v30; // [rsp+B0h] [rbp-19h] BYREF
  RBX::Time v31; // [rsp+B8h] [rbp-11h] BYREF
  std::pair<boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<RBX::SharedString> >,bool> v32; // [rsp+C0h] [rbp-9h] BYREF
  std::pair<boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<std::string const ,RBX::SharedString> > >,bool> v33; // [rsp+D0h] [rbp+7h] BYREF
  RBX::Network::NetworkStream *inByteArray; // [rsp+130h] [rbp+67h] BYREF
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *v35; // [rsp+138h] [rbp+6Fh]
  std::unique_ptr<RBX::Network::NetworkStream> rawBitStream; // [rsp+140h] [rbp+77h] BYREF
  RBX::Timer<2> sharedStringWriteTimer; // [rsp+148h] [rbp+7Fh] BYREF

  v35 = result; /*0x141145b40*/
  __wind
  {
    __wind
    {
      v4 = nullptr; /*0x141145b69*/
      v5 = 0; /*0x141145b71*/
      Myval2 = nullptr; /*0x141145b74*/
      rawBitStream._Mypair._Myval2 = nullptr; /*0x141145b77*/
      result->_Ptr = nullptr; /*0x141145b7b*/
      v25 = 1; /*0x141145b7e*/
      RBX::Time::now<2>(result: &sharedStringWriteTimer.start); /*0x141145b8a*/
      if ( this->curJoinSharedStringVectorIndex < (unsigned __int64)(this->joinCacheStreamData._Ptr->sharedStrings_deprecated._Mypair._Myval2._Mylast /*0x141145bae*/
                                                                   - this->joinCacheStreamData._Ptr->sharedStrings_deprecated._Mypair._Myval2._Myfirst) )
      {
        while ( 1 ) /*0x141145bc0*/
        {
          if ( Myval2 == nullptr ) /*0x141145bc3*/
          {
            v7 = (RBX::Network::NetworkStream *)operator new(size: 0x40u); /*0x141145bc8*/
            v29 = v7; /*0x141145bcd*/
            __wind /*0xf1c00000000000bc*/
            {
              if ( v7 != nullptr ) /*0x141145bd4*/
                v8 = RBX::Network::NetworkStream::NetworkStream( /*0x141145c05*/
                       this: v7,
                       initialBytesToAllocate: (int)(float)((float)(1000 * DFLog::MaxJoinDataSizeKB)
                                  * (float)((float)DFInt::JoinDataItemEstimatedCompressionRatioHundreths / 100.0)));
              else
                v8 = nullptr; /*0x141145c0c*/
            }
            __unwind
            {
              operator delete(ptr: (void *)v29); /*0x1431e8465*/
            }
            rawBitStream._Mypair._Myval2 = v8; /*0x141145c0f*/
          }
          hash._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141145c13*/
          hash._Mypair._Myval2._Mysize = 0; /*0x141145c18*/
          hash._Mypair._Myval2._Myres = 15; /*0x141145c1d*/
          v9 = (char *)operator new(size: 0x20u); /*0x141145c30*/
          hash._Mypair._Myval2._Mysize = 16; /*0x141145c35*/
          hash._Mypair._Myval2._Myres = 31; /*0x141145c3e*/
          *(_OWORD *)v9 = 0; /*0x141145c4a*/
          v9[16] = 0; /*0x141145c4d*/
          hash._Mypair._Myval2._Bx._Ptr = v9; /*0x141145c51*/
          __eh34_enter_wind_state(1, 3); /*0xf1c00000000000a8*/
          p_hash = &hash; /*0x141145c6b*/
          if ( hash._Mypair._Myval2._Myres >= 0x10 ) /*0x141145c76*/
            p_hash = (std::string *)v9; /*0x141145c76*/
          RBX::SharedString::getHash( /*0x141145c7f*/
            this: &this->joinCacheStreamData._Ptr->sharedStrings_deprecated._Mypair._Myval2._Myfirst[this->curJoinSharedStringVectorIndex],
            out: p_hash->_Mypair._Myval2._Bx._Buf,
            size: hash._Mypair._Myval2._Mysize);
          replicator = this->replicator; /*0x141145c84*/
          v12 = &this->joinCacheStreamData._Ptr->sharedStrings_deprecated._Mypair._Myval2._Myfirst[this->curJoinSharedStringVectorIndex]; /*0x141145c96*/
          std::string::string( /*0x141145ca7*/
            this: (rtc::webrtc_checks_impl::ToStringVal *)&v27,
            __that: (const rtc::webrtc_checks_impl::ToStringVal *)&hash);
          v27.second.flyweight.h.h = v12->flyweight.h.h; /*0x141145caf*/
          _InterlockedIncrement(&v27.second.flyweight.h.h->ref.value_); /*0x141145cb3*/
          v27.second.readCount = v12->readCount; /*0x141145cba*/
          v25 |= 2u; /*0x141145cbd*/
          __wind /*0xf1c000000000009c*/
          {
            k.first._Mypair._Myval2._Bx = v27.first._Mypair._Myval2._Bx; /*0x141145cc7*/
            *(_OWORD *)&k.first._Mypair._Myval2._Mysize = *(_OWORD *)&v27.first._Mypair._Myval2._Mysize; /*0x141145ccf*/
            v27.first._Mypair._Myval2._Mysize = 0; /*0x141145cd3*/
            v27.first._Mypair._Myval2._Myres = 15; /*0x141145cd7*/
            v27.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141145cdf*/
            k.second.flyweight.h.h = v27.second.flyweight.h.h; /*0x141145ce8*/
            _InterlockedIncrement(&v27.second.flyweight.h.h->ref.value_); /*0x141145cec*/
            k.second.readCount = v27.second.readCount; /*0x141145cf3*/
            __wind /*0xf1c000000000006c*/
            {
              boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::SharedString>>,std::string,RBX::SharedString,boost::hash<std::string>,std::equal_to<std::string>>>::emplace_impl<std::pair<std::string const,RBX::SharedString>>( /*0x141145d09*/
                this: &replicator->sharedStringSenderReverseLookup.table_,
                result: &v33,
                k: &k.first,
                <args_0>: &k);
              boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &k.second.flyweight.h); /*0x141145d13*/
            }
            __unwind
            {
              boost::_bi::storage3<boost::arg<1>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::SharedString>>::~storage3<boost::arg<1>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::SharedString>>(this: (std::pair<std::string,RBX::SharedString> *)&k); /*0xf1c000000000007c*/
            }
          }
          __unwind
          {
            boost::_bi::storage3<boost::arg<1>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::SharedString>>::~storage3<boost::arg<1>,boost::_bi::value<RBX::ContentId>,boost::_bi::value<RBX::SharedString>>(this: &v27); /*0xf1c0000000000088*/
          }
          if ( __eh34_unwind(3) ) /*0xf1c0000000000090*/
          {
unwind_state_3:
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&hash); /*0xf1c0000000000054*/
            __eh34_continue_unwinding(3, 1); /*0xf1c0000000000058*/
          }
          __eh34_exit_wind_state(3, 1); /*0xf1c0000000000094*/
          if ( k.first._Mypair._Myval2._Myres >= 0x10 ) /*0x141145d20*/
          {
            Ptr = k.first._Mypair._Myval2._Bx._Ptr; /*0x141145d25*/
            if ( k.first._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141145d33*/
            {
              Ptr = *((char **)k.first._Mypair._Myval2._Bx._Ptr - 1); /*0x141145d39*/
              if ( (unsigned __int64)(k.first._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141145d48*/
                _invalid_parameter_noinfo_noreturn(); /*0x141145ea3*/
            }
            operator delete(ptr: Ptr); /*0x141145d4e*/
          }
          k.first._Mypair._Myval2._Mysize = 0; /*0x141145d53*/
          k.first._Mypair._Myval2._Myres = 15; /*0x141145d57*/
          k.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141145d5f*/
          boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &v27.second.flyweight.h); /*0x141145d67*/
          if ( v27.first._Mypair._Myval2._Myres >= 0x10 ) /*0x141145d74*/
          {
            v14 = v27.first._Mypair._Myval2._Bx._Ptr; /*0x141145d79*/
            if ( v27.first._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141145d88*/
            {
              v14 = *((char **)v27.first._Mypair._Myval2._Bx._Ptr - 1); /*0x141145d8e*/
              if ( (unsigned __int64)(v27.first._Mypair._Myval2._Bx._Ptr - v14 - 8) > 0x1F ) /*0x141145d9d*/
                _invalid_parameter_noinfo_noreturn(); /*0x141145eaa*/
            }
            operator delete(ptr: v14); /*0x141145da3*/
          }
          __eh34_enter_wind_state(1, 3); /*0xf1c0000000000064*/
          boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::SharedString>,RBX::SharedString,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>>>::emplace_impl<RBX::SharedString const &>( /*0x141145dd0*/
            this: &this->replicator->sharedStringSentSet.table_,
            result: &v32,
            k: &this->joinCacheStreamData._Ptr->sharedStrings_deprecated._Mypair._Myval2._Myfirst[this->curJoinSharedStringVectorIndex],
            <args_0>: &this->joinCacheStreamData._Ptr->sharedStrings_deprecated._Mypair._Myval2._Myfirst[this->curJoinSharedStringVectorIndex]);
          Myval2 = rawBitStream._Mypair._Myval2; /*0x141145dd5*/
          if ( v32.second ) /*0x141145ddd*/
          {
            RBX::Network::Replicator::writeASharedString( /*0x141145df7*/
              outBitStream: rawBitStream._Mypair._Myval2,
              sharedString: &this->joinCacheStreamData._Ptr->sharedStrings_deprecated._Mypair._Myval2._Myfirst[this->curJoinSharedStringVectorIndex]);
            ++v5; /*0x141145dfc*/
          }
          ++this->curJoinSharedStringVectorIndex; /*0x141145dff*/
          v15 = (float)(int)Myval2->GetNumberOfBytesUsed(this: Myval2); /*0x141145e13*/
          if ( __eh34_unwind(3) ) /*0xf1c0000000000050*/
            goto unwind_state_3; /*0xf1c0000000000050*/
          __eh34_exit_wind_state(3, 1); /*0xf1c000000000005c*/
          if ( v15 >= (float)((float)(1000 * DFLog::MaxJoinDataSizeKB) /*0x141145e47*/
                            * (float)((float)DFInt::JoinDataItemEstimatedCompressionRatioHundreths / 100.0)) )
            break; /*0x141145e47*/
          if ( hash._Mypair._Myval2._Myres >= 0x10 ) /*0x141145e4d*/
          {
            v16 = hash._Mypair._Myval2._Bx._Ptr; /*0x141145e52*/
            if ( hash._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141145e61*/
            {
              v16 = *((char **)hash._Mypair._Myval2._Bx._Ptr - 1); /*0x141145e67*/
              if ( (unsigned __int64)(hash._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x141145e76*/
                goto LABEL_35; /*0x141145e76*/
            }
            operator delete(ptr: v16); /*0x141145e78*/
          }
          if ( this->curJoinSharedStringVectorIndex >= (unsigned __int64)(this->joinCacheStreamData._Ptr->sharedStrings_deprecated._Mypair._Myval2._Mylast /*0x141145e9c*/
                                                                        - this->joinCacheStreamData._Ptr->sharedStrings_deprecated._Mypair._Myval2._Myfirst) )
            goto LABEL_37; /*0x141145e9c*/
        }
        if ( hash._Mypair._Myval2._Myres >= 0x10 ) /*0x141145eb5*/
        {
          v17 = hash._Mypair._Myval2._Bx._Ptr; /*0x141145eba*/
          if ( hash._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141145ec9*/
          {
            v17 = *((char **)hash._Mypair._Myval2._Bx._Ptr - 1); /*0x141145ecf*/
            if ( (unsigned __int64)(hash._Mypair._Myval2._Bx._Ptr - v17 - 8) > 0x1F ) /*0x141145ede*/
LABEL_35:
              _invalid_parameter_noinfo_noreturn(); /*0x141145ee0*/
          }
          operator delete(ptr: v17); /*0x141145ee7*/
        }
LABEL_37:
        if ( Myval2 != nullptr ) /*0x141145eef*/
        {
          v18 = (RBX::Network::NetworkStream *)operator new(size: 0x40u); /*0x141145efa*/
          inByteArray = v18; /*0x141145eff*/
          __wind /*0xf1c0000000000044*/
          {
            if ( v18 != nullptr ) /*0x141145f06*/
              v4 = RBX::Network::NetworkStream::NetworkStream(this: v18); /*0x141145f10*/
          }
          __unwind
          {
            operator delete(ptr: (void *)inByteArray); /*0x14319df15*/
          }
          v19 = (RBX::Network::NetworkStream *)result->_Ptr; /*0x141145f13*/
          result->_Ptr = (RBX::Graphics::TextureVulkan::DownloadBuffer *)v4; /*0x141145f16*/
          if ( v19 != nullptr ) /*0x141145f1c*/
            ((void (__fastcall *)(RBX::Network::NetworkStream *, __int64))v19->dtr_AbstractBitStream)(a1: v19, a2: 1); /*0x141145f26*/
          LOBYTE(inByteArray) = -125; /*0x141145f28*/
          RBX::Network::NetworkStream::writeBytes( /*0x141145f39*/
            this: (RBX::Network::NetworkStream *)result->_Ptr,
            &inByteArray,
            numberOfBytesToWrite: 1u);
          RBX::Network::Item::writeItemType( /*0x141145f4a*/
            this,
            stream: (RBX::Network::NetworkStream *)result->_Ptr,
            value: ItemTypeJoinDataV2);
          LOBYTE(inByteArray) = 1; /*0x141145f4f*/
          RBX::Network::NetworkStream::writeBytes( /*0x141145f60*/
            this: (RBX::Network::NetworkStream *)result->_Ptr,
            &inByteArray,
            numberOfBytesToWrite: 1u);
          Mysize = result->_Ptr->debugName._Mypair._Myval2._Mysize; /*0x141145f68*/
          RBX::Network::Replicator::compressBitStream( /*0x141145f76*/
            inUncompressedBitStream: Myval2,
            outCompressedBitStream: (RBX::Network::NetworkStream *)result->_Ptr,
            compressRatio: DFInt::JoinDataCompressionLevel);
          if ( this->areCachedStreamsComplete(this) ) /*0x141145f81*/
          {
            LOBYTE(inByteArray) = 0; /*0x141145f88*/
            RBX::Network::NetworkStream::writeBytes( /*0x141145f99*/
              this: (RBX::Network::NetworkStream *)result->_Ptr,
              &inByteArray,
              numberOfBytesToWrite: 1u);
          }
          this->sharedStringsInstanceCounters.numOfRawBytes += Myval2->GetNumberOfBytesUsed(this: Myval2); /*0x141145fa7*/
          this->sharedStringsInstanceCounters.numOfCompressedBytes += LODWORD(result->_Ptr->debugName._Mypair._Myval2._Mysize) /*0x141145fb2*/
                                                                    - Mysize;
          this->sharedStringsInstanceCounters.numOfInstances += v5; /*0x141145fb5*/
          this->totalUncompressedBytes += Myval2->GetNumberOfBytesUsed(this: Myval2); /*0x141145fc2*/
          this->totalUsefulUncompressedBytes += Myval2->GetNumberOfBytesUsed(this: Myval2); /*0x141145fce*/
          this->totalCompressedBytes += LODWORD(result->_Ptr->debugName._Mypair._Myval2._Mysize) - Mysize; /*0x141145fd9*/
          this->totalNumberOfBytesSent += ((__int64 (__fastcall *)(RBX::Graphics::TextureVulkan::DownloadBuffer *))result->_Ptr->copyData)(a1: result->_Ptr); /*0x141145fe5*/
          this->totalNumOfInstances += v5; /*0x141145fe8*/
          ++this->totalNumberOfSentBlobs; /*0x141145fec*/
          RBX::Network::NetworkStream::Reset(this: Myval2); /*0x141145ff2*/
        }
      }
      v21 = RBX::Time::now<2>(result: &v30); /*0x141145ffb*/
      this->totalSharedStringsWriteTime = (float)((v21->sec - sharedStringWriteTimer.start.sec) * 1000.0) /*0x14114601e*/
                                        + this->totalSharedStringsWriteTime;
      if ( DFLog::NetworkJoin != 0 )
      {
        v22 = RBX::Time::now<2>(result: &v31); /*0x141146030*/
        v23 = (v22->sec - sharedStringWriteTimer.start.sec) * 1000.0; /*0x141146042*/
        FLog::FastLogFormatted(
          level: DFLog::NetworkJoin,
          message: "[DFLog::NetworkJoin] SharedString Blob: %u sharedStrings, took %f ms to serlialize",
          v5,
          v23);
      }
    }
    __unwind
    {
      RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: (std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> *)&rawBitStream); /*0xf1c0000000000030*/
    }
    if ( Myval2 != nullptr ) /*0x141146068*/
      ((void (__fastcall *)(RBX::Network::NetworkStream *, __int64))Myval2->dtr_AbstractBitStream)(a1: Myval2, a2: 1); /*0x141146075*/
    v24 = result; /*0x141146077*/
  }
  __unwind
  {
    if ( (v25 & 1) != 0 ) /*0x1431f13e1*/
      RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: v35); /*0x1431f13ee*/
  }
  return v24; /*0x14114607a*/
}

// END JoinDataItemV2 part 1/1, 11 functions
