// ClassInfo -- 2022 Studio + full PDB
// tier 3, 2 functions


// Address: 0x141067c40 | Name: ?eventIdFromLocalDescriptor@ClassInfo@NetworkSchema@Network@RBX@@QEBAPEBGAEBVEventDescriptor@Reflection@4@@Z
const RBX::Reflection::EventDescriptor **__fastcall RBX::Network::NetworkSchema::ClassInfo::eventIdFromLocalDescriptor(
        RBX::Network::NetworkSchema::ClassInfo *this,
        const RBX::Reflection::EventDescriptor *localDescriptor)
{
  std::pair<RBX::Reflection::EventDescriptor const *,unsigned short> *Myfirst; // rdi
  std::pair<RBX::Reflection::EventDescriptor const *,unsigned short> *Mylast; // r8
  const RBX::Reflection::EventDescriptor *empty_key; // r11
  unsigned __int64 v6; // r8
  unsigned __int64 v7; // rcx
  unsigned __int64 v8; // rdx
  const RBX::Reflection::EventDescriptor **p_first; // rax
  unsigned __int64 v10; // rcx
  const RBX::Reflection::EventDescriptor **v11; // rcx

  Myfirst = this->eventNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Myfirst; /*0x141067c4a*/
  Mylast = this->eventNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Mylast; /*0x141067c51*/
  if ( Myfirst == Mylast /*0x141067c66*/
    || (empty_key = this->eventNetworkIdByLocalDescriptor.impl.empty_key, localDescriptor == empty_key) )
  {
LABEL_8:
    p_first = nullptr; /*0x141067cb8*/
  }
  else
  {
    v6 = Mylast - Myfirst - 1; /*0x141067c79*/
    v7 = v6 & ((unsigned __int64)localDescriptor + ((unsigned __int64)localDescriptor >> 3)); /*0x141067c7c*/
    v8 = 0; /*0x141067c82*/
    while ( 1 ) /*0x141067c97*/
    {
      p_first = &Myfirst[v7].first; /*0x141067c97*/
      if ( *p_first == localDescriptor ) /*0x141067ca0*/
        break; /*0x141067ca0*/
      if ( *p_first != empty_key ) /*0x141067ca5*/
      {
        v10 = v8 + v7 + 1; /*0x141067caa*/
        ++v8; /*0x141067cad*/
        v7 = v6 & v10; /*0x141067cb0*/
        if ( v8 <= v6 ) /*0x141067cb6*/
          continue; /*0x141067cb6*/
      }
      goto LABEL_8; /*0x141067cb6*/
    }
  }
  v11 = p_first + 1; /*0x141067cc0*/
  if ( p_first == nullptr ) /*0x141067ccc*/
    return nullptr; /*0x141067ccc*/
  return v11; /*0x141067cd3*/
}

// Address: 0x1410a0990 | Name: ?propertyIdFromLocalDescriptor@ClassInfo@NetworkSchema@Network@RBX@@QEBAPEBGAEBVPropertyDescriptor@Reflection@4@@Z
const RBX::Reflection::PropertyDescriptor **__fastcall RBX::Network::NetworkSchema::ClassInfo::propertyIdFromLocalDescriptor(
        RBX::Network::NetworkSchema::ClassInfo *this,
        const RBX::Reflection::PropertyDescriptor *localDescriptor)
{
  std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short> *Myfirst; // rdi
  std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short> *Mylast; // r8
  const RBX::Reflection::PropertyDescriptor *empty_key; // r11
  unsigned __int64 v6; // r8
  unsigned __int64 v7; // rcx
  unsigned __int64 v8; // rdx
  const RBX::Reflection::PropertyDescriptor **p_first; // rax
  unsigned __int64 v10; // rcx
  const RBX::Reflection::PropertyDescriptor **v11; // rcx

  Myfirst = this->propertyNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Myfirst; /*0x1410a099a*/
  Mylast = this->propertyNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Mylast; /*0x1410a09a1*/
  if ( Myfirst == Mylast /*0x1410a09b6*/
    || (empty_key = this->propertyNetworkIdByLocalDescriptor.impl.empty_key, localDescriptor == empty_key) )
  {
LABEL_8:
    p_first = nullptr; /*0x1410a0a08*/
  }
  else
  {
    v6 = Mylast - Myfirst - 1; /*0x1410a09c9*/
    v7 = v6 & ((unsigned __int64)localDescriptor + ((unsigned __int64)localDescriptor >> 3)); /*0x1410a09cc*/
    v8 = 0; /*0x1410a09d2*/
    while ( 1 ) /*0x1410a09e7*/
    {
      p_first = &Myfirst[v7].first; /*0x1410a09e7*/
      if ( *p_first == localDescriptor ) /*0x1410a09f0*/
        break; /*0x1410a09f0*/
      if ( *p_first != empty_key ) /*0x1410a09f5*/
      {
        v10 = v8 + v7 + 1; /*0x1410a09fa*/
        ++v8; /*0x1410a09fd*/
        v7 = v6 & v10; /*0x1410a0a00*/
        if ( v8 <= v6 ) /*0x1410a0a06*/
          continue; /*0x1410a0a06*/
      }
      goto LABEL_8; /*0x1410a0a06*/
    }
  }
  v11 = p_first + 1; /*0x1410a0a10*/
  if ( p_first == nullptr ) /*0x1410a0a1c*/
    return nullptr; /*0x1410a0a1c*/
  return v11; /*0x1410a0a23*/
}

// END ClassInfo part 1/1, 2 functions
