// KeyRing -- 2022 Studio + full PDB
// tier 3, 13 functions


// Address: 0x14225e970 | Name: ??0KeyRing@Security@RBX@@QEAA@XZ
RBX::Security::KeyRing *__fastcall RBX::Security::KeyRing::KeyRing(RBX::Security::KeyRing *this)
{
  std::unordered_map<std::string,RBX::Security::KeyRing::ApplicationInfo> *p_keyMap; // rbx
  std::_List_node<std::pair<std::string const ,RBX::Security::KeyRing::ApplicationInfo>,void *> *v3; // rax
  HANDLE SemaphoreA; // rax
  HANDLE v5; // rax
  HANDLE v6; // rax
  RBX::Security::KeyRing *result; // rax
  const boost::thread_resource_error *v8; // rax
  const boost::thread_resource_error *v9; // rax
  const boost::thread_resource_error *v10; // rax
  boost::thread_resource_error v11; // [rsp+20h] [rbp-E8h] BYREF
  boost::thread_resource_error v12; // [rsp+68h] [rbp-A0h] BYREF
  boost::thread_resource_error v13; // [rsp+B0h] [rbp-58h] BYREF
  std::unordered_map<std::string,RBX::Security::KeyRing::ApplicationInfo> *v15; // [rsp+118h] [rbp+10h]

  __wind /*0xf1c00000000000d8*/
  {
    this->_Wptr._Ptr = nullptr; /*0x14225e98c*/
    this->_Wptr._Rep = nullptr; /*0x14225e98f*/
    p_keyMap = &this->keyMap; /*0x14225e993*/
    v15 = &this->keyMap; /*0x14225e997*/
    this->keyMap._Traitsobj._Mypair._Myval2._Myval2 = 0.0; /*0x14225e99b*/
    this->keyMap._List._Mypair._Myval2._Myhead = nullptr; /*0x14225e99d*/
    this->keyMap._List._Mypair._Myval2._Mysize = 0; /*0x14225e9a1*/
    v3 = (std::_List_node<std::pair<std::string const ,RBX::Security::KeyRing::ApplicationInfo>,void *> *)operator new(size: 0x50u); /*0x14225e9a8*/
    __wind /*0xf1c00000000000e4*/
    {
      __wind /*0xf1c00000000000ec*/
      {
        v3->_Next = v3; /*0x14225e9ad*/
        v3->_Prev = v3; /*0x14225e9b0*/
        p_keyMap->_List._Mypair._Myval2._Myhead = v3; /*0x14225e9b4*/
        p_keyMap->_Vec._Mypair._Myval2._Myfirst = nullptr; /*0x14225e9bc*/
        p_keyMap->_Vec._Mypair._Myval2._Mylast = nullptr; /*0x14225e9bf*/
        p_keyMap->_Vec._Mypair._Myval2._Myend = nullptr; /*0x14225e9c3*/
        p_keyMap->_Mask = 7; /*0x14225e9c7*/
        p_keyMap->_Maxidx = 8; /*0x14225e9cf*/
        p_keyMap->_Traitsobj._Mypair._Myval2._Myval2 = 1.0; /*0x14225e9d7*/
        std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::shared_ptr<RBX::Graphics::Shader>>>>>>>::_Assign_grow( /*0x14225e9e4*/
          this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > > > > *)&p_keyMap->_Vec,
          _Cells: 0x10u,
          _Val: (const std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > >)p_keyMap->_List._Mypair._Myval2._Myhead);
        SemaphoreA = CreateSemaphoreA( /*0x14225e9f7*/
                       lpSemaphoreAttributes: nullptr,
                       lInitialCount: 0,
                       lMaximumCount: 0x7FFFFFFF,
                       lpName: nullptr);
      }
      __unwind
      {
        std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&v15->_Vec); /*0x14322bf0b*/
      }
    }
    __unwind
    {
      std::list<std::pair<std::string const,RBX::Security::KeyRing::ApplicationInfo>>::~list<std::pair<std::string const,RBX::Security::KeyRing::ApplicationInfo>>(this: &v15->_List); /*0x14328451b*/
    }
    __wind /*0xf1c0000000000110*/
    {
      if ( SemaphoreA == nullptr ) /*0x14225ea00*/
      {
        v9 = boost::thread_resource_error::thread_resource_error(this: &v11); /*0x14225eb22*/
        __wind /*0xf1c0000000000050*/
        {
          boost::throw_exception<boost::thread_resource_error>(e: v9); /*0x14225eb2b*/
        }
        __unwind
        {
          boost::thread_resource_error::~thread_resource_error(this: (boost::lock_error *)&v11); /*0xf1c0000000000060*/
        }
      }
      this->mutex.semaphores[0] = SemaphoreA; /*0x14225ea06*/
      v5 = CreateSemaphoreA( /*0x14225ea17*/
             lpSemaphoreAttributes: nullptr,
             lInitialCount: 0,
             lMaximumCount: 0x7FFFFFFF,
             lpName: nullptr);
      this->mutex.semaphores[1] = v5; /*0x14225ea1d*/
      if ( v5 == nullptr ) /*0x14225ea24*/
      {
        boost::detail::win32::release_semaphore(semaphore: this->mutex.semaphores[0], count: 0x7FFFFFFF); /*0x14225eb3a*/
        v10 = boost::thread_resource_error::thread_resource_error(this: &v12); /*0x14225eb44*/
        __wind /*0xf1c0000000000038*/
        {
          boost::throw_exception<boost::thread_resource_error>(e: v10); /*0x14225eb4d*/
        }
        __unwind
        {
          boost::thread_resource_error::~thread_resource_error(this: (boost::lock_error *)&v12); /*0xf1c0000000000048*/
        }
      }
      v6 = CreateSemaphoreA( /*0x14225ea37*/
             lpSemaphoreAttributes: nullptr,
             lInitialCount: 0,
             lMaximumCount: 0x7FFFFFFF,
             lpName: nullptr);
      this->mutex.upgrade_sem = v6; /*0x14225ea3d*/
      if ( v6 == nullptr ) /*0x14225ea44*/
      {
        boost::detail::win32::release_semaphore(semaphore: this->mutex.semaphores[0], count: 0x7FFFFFFF); /*0x14225eaf3*/
        boost::detail::win32::release_semaphore(semaphore: this->mutex.semaphores[1], count: 0x7FFFFFFF); /*0x14225eb01*/
        v8 = boost::thread_resource_error::thread_resource_error(this: &v13); /*0x14225eb0e*/
        __wind /*0xf1c0000000000068*/
        {
          boost::throw_exception<boost::thread_resource_error>(e: v8); /*0x14225eb17*/
        }
        __unwind
        {
          boost::thread_resource_error::~thread_resource_error(this: (boost::lock_error *)&v13); /*0xf1c0000000000078*/
        }
      }
      __wind /*0xf1c0000000000080*/
      {
        __wind /*0xf1c0000000000088*/
        {
          __wind /*0xf1c0000000000090*/
          {
            this->mutex.state = 0; /*0x14225ea4a*/
            this->jobId._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14225ea4d*/
            this->jobId._Mypair._Myval2._Mysize = 0; /*0x14225ea51*/
            this->jobId._Mypair._Myval2._Myres = 15; /*0x14225ea58*/
            this->jobId._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14225ea63*/
            this->counterPfn = nullptr; /*0x14225ea67*/
            this->filename._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14225ea6e*/
            this->filename._Mypair._Myval2._Mysize = 0; /*0x14225ea75*/
            this->filename._Mypair._Myval2._Myres = 15; /*0x14225ea7c*/
            this->filename._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14225ea87*/
            std::weak_ptr<RBX::BasePart>::weak_ptr<RBX::BasePart>(this: (std::shared_ptr<DataModelPluginLoader> *)&this->timer); /*0x14225ea95*/
            this->configLogName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14225ea9a*/
            this->configLogName._Mypair._Myval2._Mysize = 0; /*0x14225eaa1*/
            this->configLogName._Mypair._Myval2._Myres = 15; /*0x14225eaa8*/
            this->configLogName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14225eab3*/
            this->lastReportTime.sec = 0.0; /*0x14225eaba*/
            this->reportVersionPfn = nullptr; /*0x14225eac1*/
            *(_OWORD *)this->configHash = 0; /*0x14225eacb*/
            result = this; /*0x14225ead2*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->filename); /*0x1432844fe*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&this->jobId); /*0x1432844eb*/
        }
      }
      __unwind
      {
        boost::shared_mutex::~shared_mutex(this: &this->mutex); /*0x1432844db*/
      }
    }
    __unwind
    {
      std::unordered_map<std::string,RBX::Security::KeyRing::ApplicationInfo>::~unordered_map<std::string,RBX::Security::KeyRing::ApplicationInfo>(this: &this->keyMap); /*0x1432844cb*/
    }
  }
  __unwind
  {
    std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>((std::weak_ptr<PluginPermissionsFetcher> *)this); /*0xf1c00000000000d0*/
  }
  return result; /*0x14225ead5*/
}

// Address: 0x14225ed00 | Name: ??1KeyRing@Security@RBX@@QEAA@XZ
void __fastcall RBX::Security::KeyRing::~KeyRing(RBX::Security::KeyRing *this)
{
  unsigned __int64 Myres; // rdx
  char *Ptr; // rcx
  std::_Ref_count_base *Rep; // rdi
  unsigned __int64 v5; // rdx
  char *v6; // rcx
  unsigned __int64 v7; // rdx
  char *v8; // rcx
  std::_Ref_count_base *v9; // rcx

  if ( webrtc::RepeatingTaskHandle::Running(this: (webrtc::RepeatingTaskHandle *)&this->timer) ) /*0x14225ed1e*/
    RBX::SimpleTimer::stop(this: &this->timer); /*0x14225ed2e*/
  this->counterPfn = nullptr; /*0x14225ed35*/
  Myres = this->configLogName._Mypair._Myval2._Myres; /*0x14225ed3c*/
  if ( Myres >= 0x10 ) /*0x14225ed47*/
  {
    Ptr = this->configLogName._Mypair._Myval2._Bx._Ptr; /*0x14225ed4c*/
    if ( Myres + 1 >= 0x1000 ) /*0x14225ed5a*/
    {
      if ( (unsigned __int64)&Ptr[-*((_QWORD *)Ptr - 1) - 8] > 0x1F ) /*0x14225ed6f*/
        goto LABEL_26; /*0x14225ed6f*/
      Ptr = *((char **)Ptr - 1); /*0x14225ed75*/
    }
    operator delete(ptr: Ptr); /*0x14225ed78*/
  }
  this->configLogName._Mypair._Myval2._Mysize = 0; /*0x14225ed7d*/
  this->configLogName._Mypair._Myval2._Myres = 15; /*0x14225ed84*/
  this->configLogName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14225ed8f*/
  Rep = this->timer.timerData._Rep; /*0x14225ed96*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14225edb1*/
  {
    Rep->_Destroy(this: Rep); /*0x14225edb9*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14225edc5*/
      Rep->_Delete_this(this: Rep); /*0x14225edcd*/
  }
  v5 = this->filename._Mypair._Myval2._Myres; /*0x14225edd0*/
  if ( v5 >= 0x10 ) /*0x14225eddb*/
  {
    v6 = this->filename._Mypair._Myval2._Bx._Ptr; /*0x14225ede0*/
    if ( v5 + 1 >= 0x1000 ) /*0x14225edee*/
    {
      if ( (unsigned __int64)&v6[-*((_QWORD *)v6 - 1) - 8] > 0x1F ) /*0x14225ee03*/
        goto LABEL_26; /*0x14225ee03*/
      v6 = *((char **)v6 - 1); /*0x14225ee09*/
    }
    operator delete(ptr: v6); /*0x14225ee0c*/
  }
  this->filename._Mypair._Myval2._Mysize = 0; /*0x14225ee11*/
  this->filename._Mypair._Myval2._Myres = 15; /*0x14225ee18*/
  this->filename._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14225ee23*/
  v7 = this->jobId._Mypair._Myval2._Myres; /*0x14225ee2a*/
  if ( v7 >= 0x10 ) /*0x14225ee35*/
  {
    v8 = this->jobId._Mypair._Myval2._Bx._Ptr; /*0x14225ee3a*/
    if ( v7 + 1 >= 0x1000 ) /*0x14225ee45*/
    {
      if ( (unsigned __int64)&v8[-*((_QWORD *)v8 - 1) - 8] <= 0x1F ) /*0x14225ee5a*/
      {
        v8 = *((char **)v8 - 1); /*0x14225ee5c*/
        goto LABEL_21; /*0x14225ee5c*/
      }
LABEL_26:
      _invalid_parameter_noinfo_noreturn(); /*0x14225eed0*/
    }
LABEL_21:
    operator delete(ptr: v8); /*0x14225ee5f*/
  }
  this->jobId._Mypair._Myval2._Mysize = 0; /*0x14225ee64*/
  this->jobId._Mypair._Myval2._Myres = 15; /*0x14225ee6b*/
  this->jobId._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14225ee76*/
  CloseHandle(hObject: this->mutex.upgrade_sem); /*0x14225ee7e*/
  CloseHandle(hObject: this->mutex.semaphores[0]); /*0x14225ee88*/
  CloseHandle(hObject: this->mutex.semaphores[1]); /*0x14225ee92*/
  std::_Hash<std::_Umap_traits<std::string,RBX::Security::KeyRing::ApplicationInfo,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Security::KeyRing::ApplicationInfo>>,0>>::~_Hash<std::_Umap_traits<std::string,RBX::Security::KeyRing::ApplicationInfo,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Security::KeyRing::ApplicationInfo>>,0>>(this: &this->keyMap); /*0x14225ee9c*/
  v9 = this->_Wptr._Rep; /*0x14225eea1*/
  if ( v9 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v9->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14225eeb2*/
    v9->_Delete_this(this: v9); /*0x14225eeb7*/
}

// Address: 0x14225eee0 | Name: ??_E?$_Ref_count_obj2@VKeyRing@Security@RBX@@@std@@UEAAPEAXI@Z
std::_Ref_count_obj2<RBX::Security::KeyRing> *__fastcall std::_Ref_count_obj2<RBX::Security::KeyRing>::`vector deleting destructor'(
        std::_Ref_count_obj2<RBX::Security::KeyRing> *this,
        char a2)
{
  this->__vftable = (std::_Ref_count_obj2<RBX::Security::KeyRing>_vtbl *)std::_Ref_count_obj2<RBX::Security::KeyRing>::`vftable'; /*0x14225eef0*/
  if ( (a2 & 1) != 0 ) /*0x14225eef6*/
    operator delete(ptr: this); /*0x14225eefd*/
  return this; /*0x14225ef05*/
}

// Address: 0x14225ef20 | Name: ?getInstance@KeyRing@Security@RBX@@SAPEAV123@XZ
RBX::Security::KeyRing *__fastcall RBX::Security::KeyRing::getInstance()
{
  char *v1; // rax
  std::_Ref_count_base *Rep; // rbx
  std::_Ref_count_base *v3; // rdi
  std::_Ref_count_base *v4; // rax
  __int64 v5; // rcx
  std::_Ref_count_base *v6; // rdx
  volatile signed __int32 *v7; // rcx
  void *v8; // [rsp+30h] [rbp+8h]

  if ( _TSS0_1633 <= *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x14225ef4b*/
    return instance_29._Ptr; /*0x14225ef4b*/
  Init_thread_header(pOnce: &_TSS0_1633); /*0x14225ef91*/
  if ( _TSS0_1633 != -1 ) /*0x14225ef9d*/
    return instance_29._Ptr; /*0x14225ef4d*/
  __wind /*0xf1c000000000003c*/
  {
    v1 = (char *)operator new(size: 0x118u); /*0x14225efa4*/
    __wind /*0xf1c0000000000018*/
    {
      Rep = (std::_Ref_count_base *)v1; /*0x14225efa9*/
      v8 = v1; /*0x14225efac*/
      v3 = nullptr; /*0x14225efb1*/
      if ( v1 != nullptr ) /*0x14225efb6*/
      {
        *(_OWORD *)v1 = 0; /*0x14225efbb*/
        *((_DWORD *)v1 + 2) = 1; /*0x14225efbe*/
        *((_DWORD *)v1 + 3) = 1; /*0x14225efc5*/
        *(_QWORD *)v1 = std::_Ref_count_obj2<RBX::Security::KeyRing>::`vftable'; /*0x14225efd3*/
        RBX::Security::KeyRing::KeyRing(this: (RBX::Security::KeyRing *)(v1 + 16)); /*0x14225efda*/
      }
      else
      {
        Rep = nullptr; /*0x14225efe1*/
      }
      v4 = Rep + 1; /*0x14225efe4*/
      instance_29._Ptr = (RBX::Security::KeyRing *)&Rep[1]; /*0x14225efe8*/
      instance_29._Rep = Rep; /*0x14225efef*/
      if ( Rep != (std::_Ref_count_base *)-16LL ) /*0x14225eff9*/
      {
        v5 = *(_QWORD *)&Rep[1]._Uses; /*0x14225efff*/
        if ( v5 == 0 || *(_DWORD *)(v5 + 8) == 0 ) /*0x14225f00c*/
        {
          if ( Rep != nullptr ) /*0x14225f015*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x14225f017*/
            Rep = instance_29._Rep; /*0x14225f01b*/
          }
          v6 = nullptr; /*0x14225f022*/
          if ( Rep != nullptr ) /*0x14225f028*/
          {
            v3 = v4; /*0x14225f02a*/
            _InterlockedIncrement((volatile signed __int32 *)&Rep->_Weaks); /*0x14225f02d*/
            v6 = Rep; /*0x14225f031*/
          }
          v4->__vftable = (std::_Ref_count_base_vtbl *)v3; /*0x14225f034*/
          v7 = *(volatile signed __int32 **)&v4->_Uses; /*0x14225f037*/
          *(_QWORD *)&v4->_Uses = v6; /*0x14225f03b*/
          if ( v7 != nullptr && _InterlockedExchangeAdd(v7 + 3, 0xFFFFFFFF) == 1 ) /*0x14225f053*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 8LL))(a1: v7); /*0x14225f058*/
          if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14225f06e*/
          {
            Rep->_Destroy(this: Rep); /*0x14225f07a*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14225f084*/
              Rep->_Delete_this(this: Rep); /*0x14225f090*/
          }
        }
      }
    }
    __unwind
    {
      operator delete(ptr: v8); /*0x1431c6ed2*/
    }
  }
  __unwind
  {
    Init_thread_abort(pOnce: &_TSS0_1633); /*0x143284527*/
  }
  atexit(function: RBX::Security::KeyRing::getInstance_::_2_::_dynamic_atexit_destructor_for__instance__); /*0x14225ef66*/
  Init_thread_footer(pOnce: &_TSS0_1633); /*0x14225ef73*/
  return instance_29._Ptr; /*0x14225ef54*/
}

// Address: 0x14225f0a0 | Name: ?getKeyForConsumption@KeyRing@Security@RBX@@QEBA?AV?$vector@EV?$allocator@E@std@@@std@@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@5@I@Z
std::vector<unsigned char> *__fastcall RBX::Security::KeyRing::getKeyForConsumption(
        RBX::Security::KeyRing *this,
        std::vector<unsigned char> *result,
        const std::string *name,
        const unsigned int id)
{
  boost::shared_mutex *p_mutex; // rsi
  RBX::Security::KeyRing::KeyInfo *Mylast; // rcx
  RBX::Security::KeyRing::KeyInfo *Myfirst; // rdx
  const boost::lock_error *v12; // rax
  boost::posix_time::time_duration time_of_day; // [rsp+20h] [rbp-88h] BYREF
  boost::posix_time::ptime wait_until; // [rsp+28h] [rbp-80h] BYREF
  boost::shared_lock<boost::shared_mutex> lock; // [rsp+30h] [rbp-78h] BYREF
  boost::lock_error v16; // [rsp+40h] [rbp-68h] BYREF
  std::_List_const_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Security::KeyRing::ApplicationInfo> > > > applicationIt; // [rsp+B0h] [rbp+8h] BYREF

  p_mutex = &this->mutex; /*0x14225f0c2*/
  lock.m = &this->mutex; /*0x14225f0c6*/
  lock.is_locked = false; /*0x14225f0ca*/
  if ( this == (RBX::Security::KeyRing *)-80LL ) /*0x14225f0d2*/
  {
    v12 = boost::lock_error::lock_error(this: &v16, ev: 1, what_arg: "boost shared_lock has no mutex"); /*0x14225f1ac*/
    __wind /*0xf1c0000000000004*/
    {
      boost::throw_exception<boost::lock_error>(e: v12); /*0x14225f1b5*/
    }
    __unwind
    {
      boost::thread_resource_error::~thread_resource_error(this: &v16); /*0xf1c0000000000014*/
    }
  }
  time_of_day.ticks_.value_ = 0x7FFFFFFFFFFFFFFFLL; /*0x14225f0e2*/
  LODWORD(applicationIt._Ptr) = -1; /*0x14225f0e7*/
  boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>( /*0x14225f0fc*/
    this: &wait_until.time_,
    d: (const boost::gregorian::date *)&applicationIt,
    &time_of_day);
  boost::shared_mutex::timed_lock_shared(this: p_mutex, &wait_until); /*0x14225f109*/
  lock.is_locked = true; /*0x14225f10e*/
  std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::find<void>( /*0x14225f122*/
    this: (std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<Luau::Module>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<Luau::Module> > >,0> > *)&this->keyMap,
    result: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<Luau::Module> > > > > *)&applicationIt,
    _Keyval: name);
  if ( applicationIt._Ptr == this->keyMap._List._Mypair._Myval2._Myhead ) /*0x14225f133*/
    goto LABEL_6; /*0x14225f133*/
  Mylast = applicationIt._Ptr->_Myval.second.keys._Mypair._Myval2._Mylast; /*0x14225f135*/
  Myfirst = applicationIt._Ptr->_Myval.second.keys._Mypair._Myval2._Myfirst; /*0x14225f139*/
  if ( Myfirst == Mylast ) /*0x14225f140*/
    goto LABEL_6; /*0x14225f140*/
  while ( Myfirst->id != id ) /*0x14225f145*/
  {
    if ( ++Myfirst == Mylast ) /*0x14225f14e*/
      goto LABEL_6; /*0x14225f14e*/
  }
  if ( !Myfirst->allowed && !DFFlag::KeyRingRevert.value ) /*0x14225f18f*/
  {
LABEL_6:
    result->_Mypair._Myval2._Myend = nullptr; /*0x14225f150*/
    result->_Mypair._Myval2._Mylast = nullptr; /*0x14225f156*/
    result->_Mypair._Myval2._Myfirst = nullptr; /*0x14225f15a*/
  }
  else
  {
    __wind /*0xf1c000000000001c*/
    {
      std::vector<unsigned char>::vector<unsigned char>(this: result, _Right: &Myfirst->value); /*0x14225f194*/
    }
    __unwind
    {
      boost::shared_lock<boost::shared_mutex>::~shared_lock<boost::shared_mutex>(this: &lock); /*0xf1c000000000002c*/
    }
  }
  boost::shared_lock<boost::shared_mutex>::~shared_lock<boost::shared_mutex>(this: &lock); /*0x14225f162*/
  return result; /*0x14225f16a*/
}

// Address: 0x14225f1c0 | Name: ?getKeyForProduction@KeyRing@Security@RBX@@QEBA?AUKeyInfo@123@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
RBX::Security::KeyRing::KeyInfo *__fastcall RBX::Security::KeyRing::getKeyForProduction(
        RBX::Security::KeyRing *this,
        RBX::Security::KeyRing::KeyInfo *result,
        const std::string *name)
{
  boost::shared_mutex *p_mutex; // rbx
  unsigned int sendVersion; // edx
  RBX::Security::KeyRing::KeyInfo *Mylast; // rcx
  RBX::Security::KeyRing::KeyInfo *Myfirst; // r8
  RBX::Security::KeyRing::KeyInfo *v10; // rbx
  const boost::lock_error *v12; // rax
  boost::shared_lock<boost::shared_mutex> lock; // [rsp+20h] [rbp-98h] BYREF
  std::vector<signed char> v14; // [rsp+30h] [rbp-88h] BYREF
  boost::posix_time::ptime wait_until; // [rsp+48h] [rbp-70h] BYREF
  boost::lock_error v16; // [rsp+50h] [rbp-68h] BYREF
  std::_List_const_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Security::KeyRing::ApplicationInfo> > > > applicationIt; // [rsp+C0h] [rbp+8h] BYREF
  boost::posix_time::time_duration v18; // [rsp+D8h] [rbp+20h] BYREF

  p_mutex = &this->mutex; /*0x14225f1da*/
  lock.m = &this->mutex; /*0x14225f1de*/
  lock.is_locked = false; /*0x14225f1e3*/
  if ( this == (RBX::Security::KeyRing *)-80LL ) /*0x14225f1eb*/
  {
    v12 = boost::lock_error::lock_error(this: &v16, ev: 1, what_arg: "boost shared_lock has no mutex"); /*0x14225f2ef*/
    __wind /*0xf1c0000000000004*/
    {
      boost::throw_exception<boost::lock_error>(e: v12); /*0x14225f2f8*/
    }
    __unwind
    {
      boost::thread_resource_error::~thread_resource_error(this: &v16); /*0xf1c0000000000014*/
    }
  }
  v18.ticks_.value_ = 0x7FFFFFFFFFFFFFFFLL; /*0x14225f1fb*/
  LODWORD(applicationIt._Ptr) = -1; /*0x14225f1ff*/
  boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>( /*0x14225f213*/
    this: &wait_until.time_,
    d: (const boost::gregorian::date *)&applicationIt,
    time_of_day: &v18);
  boost::shared_mutex::timed_lock_shared(this: p_mutex, &wait_until); /*0x14225f220*/
  lock.is_locked = true; /*0x14225f225*/
  std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::find<void>( /*0x14225f239*/
    this: (std::_Hash<std::_Umap_traits<std::string,std::shared_ptr<Luau::Module>,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::shared_ptr<Luau::Module> > >,0> > *)&this->keyMap,
    result: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<Luau::Module> > > > > *)&applicationIt,
    _Keyval: name);
  __wind
  {
    if ( applicationIt._Ptr == this->keyMap._List._Mypair._Myval2._Myhead
      || (!DFFlag::KeyRingRevert.value
        ? (sendVersion = applicationIt._Ptr->_Myval.second.sendVersion)
        : (sendVersion = applicationIt._Ptr->_Myval.second.revertVersion),
          Mylast = applicationIt._Ptr->_Myval.second.keys._Mypair._Myval2._Mylast,
          Myfirst = applicationIt._Ptr->_Myval.second.keys._Mypair._Myval2._Myfirst,
          v10 = Myfirst,
          Myfirst == Mylast) )
    {
LABEL_4:
      memset(&v14, 0, sizeof(v14)); /*0x14225f24c*/
      RBX::Security::KeyRing::KeyInfo::KeyInfo(this: result, keyId: 0, keyValue: &v14, allowed: false); /*0x14225f26b*/
    }
    else
    {
      while ( v10->id != sendVersion ) /*0x14225f296*/
      {
        if ( ++v10 == Mylast ) /*0x14225f29f*/
        {
          if ( Myfirst == Mylast ) /*0x14225f2a4*/
            goto LABEL_4; /*0x14225f2a4*/
          break; /*0x14225f2a4*/
        }
      }
      std::vector<unsigned char>::vector<unsigned char>(this: &result->value, _Right: &v10->value); /*0x14225f2a6*/
      result->id = v10->id; /*0x14225f2b4*/
      result->allowed = v10->allowed; /*0x14225f2bb*/
    }
  }
  __unwind
  {
    boost::shared_lock<boost::shared_mutex>::~shared_lock<boost::shared_mutex>(this: &lock); /*0xf1c0000000000020*/
  }
  boost::shared_lock<boost::shared_mutex>::~shared_lock<boost::shared_mutex>(this: &lock); /*0x14225f2c3*/
  return result; /*0x14225f2cb*/
}

// Address: 0x14225f300 | Name: ?parseApplication@KeyRing@Security@RBX@@AEAA_NAEBVValue@json@3@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
bool __fastcall RBX::Security::KeyRing::parseApplication(
        RBX::Security::KeyRing *this,
        RBX::json::Value *application,
        const std::string *applicationName)
{
  const RBX::json::MemberIterator *v6; // rax
  bool v7; // bl
  _DWORD *v8; // rbx
  std::string *Myfirst; // rbx
  unsigned __int64 Myres; // r14
  char *v11; // rsi
  std::string *Mylast; // rdi
  unsigned __int64 Mysize; // r15
  std::string *p_name; // rdx
  size_t v15; // r8
  std::string *v16; // rcx
  std::string *v17; // r8
  char *v18; // rax
  const RBX::json::MemberIterator *v19; // rax
  bool v20; // bl
  RBX::json::Value *v21; // rcx
  RBX::json::Value *v22; // rax
  unsigned int v23; // edi
  RBX::json::Value *v24; // rax
  unsigned int revertVersion; // ebx
  const RBX::json::Value *v26; // rax
  RBX::json::MemberIterator it; // [rsp+30h] [rbp-99h] BYREF
  RBX::json::MemberIteratorHelper members; // [rsp+38h] [rbp-91h] BYREF
  RBX::json::MemberIterator v29; // [rsp+40h] [rbp-89h] BYREF
  RBX::json::Value v30; // [rsp+50h] [rbp-79h] BYREF
  _DWORD *i; // [rsp+60h] [rbp-69h]
  std::string name; // [rsp+68h] [rbp-61h] BYREF
  _QWORD ptr[8]; // [rsp+90h] [rbp-39h] BYREF
  int v34; // [rsp+D0h] [rbp+7h]
  int v35; // [rsp+D4h] [rbp+Bh]
  __int64 v36; // [rsp+E0h] [rbp+17h]
  __int64 v37; // [rsp+E8h] [rbp+1Fh]
  char v38; // [rsp+F0h] [rbp+27h] BYREF
  std::allocator<std::string > v40; // [rsp+148h] [rbp+7Fh] BYREF

  if ( RBX::json::Value::isObject(this: application) )
  {
    RBX::json::Value::members(this: application, result: &members); /*0x14225f36a*/
    RBX::json::MemberIteratorHelper::begin(this: &members, result: &it); /*0x14225f379*/
    __wind
    {
      v6 = RBX::json::MemberIteratorHelper::end(this: &members, result: &v29); /*0x14225f389*/
      __eh34_enter_wind_state(0, 1); /*0xf1c000000000007c*/
      v7 = RBX::json::MemberIterator::operator!=(this: &it, rhs: v6); /*0x14225f39c*/
      if ( __eh34_unwind(1) ) /*0xf1c0000000000070*/
      {
unwind_state_1:
        std::unique_ptr<double>::~unique_ptr<double>(this: &v29); /*0xf1c0000000000034*/
        __eh34_continue_unwinding(1, 0); /*0xf1c0000000000038*/
      }
      __eh34_exit_wind_state(1, 0); /*0xf1c0000000000074*/
      std::unique_ptr<double>::~unique_ptr<double>(this: &v29); /*0x14225f3a4*/
      if ( v7 )
      {
        v8 = (_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL); /*0x14225f3c9*/
        for ( i = v8; ; v8 = i )
        {
          RBX::json::MemberIterator::name(this: &it, result: &name); /*0x14225f3e5*/
          __wind
          {
            if ( _TSS0_1631 > *v8 ) /*0x14225f3f3*/
            {
              Init_thread_header(pOnce: &_TSS0_1631); /*0x14225f592*/
              if ( _TSS0_1631 == -1 ) /*0x14225f59e*/
              {
                ptr[3] = 15; /*0x14225f5a4*/
                ptr[2] = 8; /*0x14225f5ac*/
                strcpy((char *)ptr, "versions"); /*0x14225f5b4*/
                ptr[7] = 15; /*0x14225f5c0*/
                ptr[6] = 4; /*0x14225f5c8*/
                ptr[4] = 1684956531; /*0x14225f5d0*/
                v37 = 15; /*0x14225f5df*/
                v36 = 6; /*0x14225f5e7*/
                v34 = *(_DWORD *)"revert"; /*0x14225f5f5*/
                v35 = *(unsigned __int16 *)"rt"; /*0x14225f5ff*/
                v30.value = (rapidjson110::GenericValue<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator> *)ptr; /*0x14225f60b*/
                *(_QWORD *)&v30.isDead = &v38; /*0x14225f613*/
                __wind /*0xf1c0000000000090*/
                {
                  __wind /*0xf1c0000000000098*/
                  {
                    std::vector<std::string>::vector<std::string>( /*0x14225f626*/
                      this: &kKnownKeys_0,
                      _Ilist: (std::initializer_list<std::string > *)&v30,
                      _Al: &v40);
                  }
                  __unwind
                  {
                    `eh vector destructor iterator'( /*0x1431736a2*/
                      ptr,
                      size: 0x20u,
                      count: 3u,
                      destructor: (void (__fastcall *)(void *))RBX::Graphics::ProfilerAdorn::Item::~Item);
                  }
                  `eh vector destructor iterator'( /*0x14225f640*/
                    ptr,
                    size: 0x20u,
                    count: 3u,
                    destructor: (void (__fastcall *)(void *))RBX::Graphics::ProfilerAdorn::Item::~Item);
                  atexit(function: RBX::Security::KeyRing::parseApplication_::_14_::_dynamic_atexit_destructor_for__kKnownKeys__); /*0x14225f64c*/
                  Init_thread_footer(pOnce: &_TSS0_1631); /*0x14225f659*/
                }
                __unwind
                {
                  Init_thread_abort(pOnce: &_TSS0_1631); /*0x143284537*/
                }
              }
            }
            Myfirst = kKnownKeys_0._Mypair._Myval2._Myfirst; /*0x14225f3f9*/
            Myres = name._Mypair._Myval2._Myres; /*0x14225f400*/
            v11 = name._Mypair._Myval2._Bx._Ptr; /*0x14225f404*/
            Mylast = kKnownKeys_0._Mypair._Myval2._Mylast; /*0x14225f408*/
            if ( kKnownKeys_0._Mypair._Myval2._Myfirst == kKnownKeys_0._Mypair._Myval2._Mylast ) /*0x14225f412*/
              goto LABEL_23; /*0x14225f412*/
            Mysize = name._Mypair._Myval2._Mysize; /*0x14225f414*/
            while ( 1 ) /*0x14225f420*/
            {
              p_name = &name; /*0x14225f420*/
              if ( Myres >= 0x10 ) /*0x14225f428*/
                p_name = (std::string *)v11; /*0x14225f428*/
              v15 = Myfirst->_Mypair._Myval2._Mysize; /*0x14225f42c*/
              v16 = Myfirst; /*0x14225f430*/
              if ( Myfirst->_Mypair._Myval2._Myres >= 0x10 ) /*0x14225f438*/
                v16 = (std::string *)Myfirst->_Mypair._Myval2._Bx._Ptr; /*0x14225f43a*/
              if ( v15 == Mysize && memcmp_0(Buf1: v16, Buf2: p_name, Size: v15) == 0 ) /*0x14225f449*/
                break; /*0x14225f449*/
              if ( ++Myfirst == Mylast ) /*0x14225f452*/
                goto LABEL_23; /*0x14225f452*/
            }
            if ( Mylast == Myfirst )
            {
LABEL_23:
              if ( DFLog::KeyRing != 0 )
              {
                v17 = &name; /*0x14225f466*/
                if ( Myres >= 0x10 ) /*0x14225f46e*/
                  v17 = (std::string *)v11; /*0x14225f46e*/
                FLog::FastLogFormatted(
                  level: DFLog::KeyRing,
                  message: "[DFLog::KeyRing] Application has unknown key : %s.",
                  v17->_Mypair._Myval2._Bx._Buf);
                Myres = name._Mypair._Myval2._Myres; /*0x14225f480*/
                v11 = name._Mypair._Myval2._Bx._Ptr; /*0x14225f484*/
              }
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&name); /*0xf1c0000000000050*/
          }
          if ( Myres >= 0x10 ) /*0x14225f48c*/
          {
            v18 = v11; /*0x14225f492*/
            if ( Myres + 1 >= 0x1000 ) /*0x14225f49c*/
            {
              v11 = *((char **)v11 - 1); /*0x14225f4a2*/
              if ( (unsigned __int64)(v18 - v11 - 8) > 0x1F ) /*0x14225f4b1*/
                _invalid_parameter_noinfo_noreturn(); /*0x14225f4fc*/
            }
            operator delete(ptr: v11); /*0x14225f4b6*/
          }
          RBX::json::MemberIterator::operator++(this: &it); /*0x14225f4c0*/
          v19 = RBX::json::MemberIteratorHelper::end(this: &members, result: &v29); /*0x14225f4cf*/
          __eh34_enter_wind_state(0, 1); /*0xf1c0000000000044*/
          v20 = RBX::json::MemberIterator::operator!=(this: &it, rhs: v19); /*0x14225f4e2*/
          if ( __eh34_unwind(1) ) /*0xf1c0000000000030*/
            goto unwind_state_1; /*0xf1c0000000000030*/
          __eh34_exit_wind_state(1, 0); /*0xf1c000000000003c*/
          std::unique_ptr<double>::~unique_ptr<double>(this: &v29); /*0x14225f4ea*/
          if ( !v20 ) /*0x14225f4f1*/
            break; /*0x14225f4f1*/
        }
      }
      std::unique_ptr<double>::~unique_ptr<double>(this: &it); /*0x14225f508*/
      v21 = application; /*0x14225f518*/
    }
    __unwind
    {
      std::unique_ptr<double>::~unique_ptr<double>(this: &it); /*0xf1c0000000000028*/
    }
    v22 = (RBX::json::Value *)RBX::json::Value::operator[](this: v21, result: &v30, s: "send"); /*0x14225f51b*/
    v23 = RBX::json::Value::getInteger<unsigned int>(this: v22); /*0x14225f528*/
    v24 = (RBX::json::Value *)RBX::json::Value::operator[](this: application, result: &v30, s: "revert"); /*0x14225f538*/
    revertVersion = RBX::json::Value::getInteger<unsigned int>(this: v24); /*0x14225f545*/
    v26 = RBX::json::Value::operator[](this: application, result: &v30, s: "versions"); /*0x14225f555*/
    return RBX::Security::KeyRing::parseVersions(this, versions: v26, applicationName, sendVersion: v23, revertVersion); /*0x14225f56b*/
  }
  else
  {
    if ( DFLog::KeyRing != 0 )
    {
      if ( applicationName->_Mypair._Myval2._Myres >= 0x10 ) /*0x14225f344*/
        applicationName = (const std::string *)applicationName->_Mypair._Myval2._Bx._Ptr; /*0x14225f346*/
      FLog::FastLogFormatted(
        level: DFLog::KeyRing,
        message: "[DFLog::KeyRing] Application invalid : %s.",
        applicationName->_Mypair._Myval2._Bx._Buf);
    }
    return false; /*0x14225f35b*/
  }
}

// Address: 0x14225f670 | Name: ?parseApplications@KeyRing@Security@RBX@@AEAA_NAEBVValue@json@3@_N@Z
char __fastcall RBX::Security::KeyRing::parseApplications(
        RBX::Security::KeyRing *this,
        RBX::json::Value *applications,
        bool isDiagOnly)
{
  int v6; // edi
  char v8; // si
  char v9; // r15
  const RBX::json::MemberIterator *i; // rax
  bool v11; // bl
  std::string *v12; // rbx
  const std::string *Ptr; // rax
  int v14; // edi
  unsigned __int64 Mysize; // rsi
  unsigned __int64 v16; // r14
  void *v17; // rax
  void *v18; // rcx
  char *v19; // rax
  char *v20; // rcx
  char *v21; // rcx
  char *v22; // rcx
  RBX::json::Value *v23; // rax
  char *v24; // rcx
  RBX::json::MemberIterator it; // [rsp+20h] [rbp-79h] BYREF
  RBX::json::MemberIteratorHelper members; // [rsp+28h] [rbp-71h] BYREF
  RBX::json::MemberIterator v27; // [rsp+30h] [rbp-69h] BYREF
  std::string applicationName; // [rsp+38h] [rbp-61h] BYREF
  std::string v29; // [rsp+58h] [rbp-41h] BYREF
  std::string v30; // [rsp+78h] [rbp-21h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v31; // [rsp+98h] [rbp-1h] BYREF
  char v32; // [rsp+118h] [rbp+7Fh]

  v6 = 0; /*0x14225f6a1*/
  if ( RBX::json::Value::isObject(this: applications) ) /*0x14225f6ab*/
  {
    RBX::json::Value::members(this: applications, result: &members); /*0x14225f6db*/
    v8 = 0; /*0x14225f6e0*/
    v9 = 1; /*0x14225f6e3*/
    RBX::json::MemberIteratorHelper::begin(this: &members, result: &it); /*0x14225f6ee*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c00000000000d8*/
    for ( i = RBX::json::MemberIteratorHelper::end(this: &members, result: &v27); /*0x14225f6fc*/
          ;
          i = RBX::json::MemberIteratorHelper::end(this: &members, result: &v27) )
    {
      __wind /*0xf1c00000000000cc*/
      {
        v11 = RBX::json::MemberIterator::operator!=(this: &it, rhs: i); /*0x14225f70e*/
      }
      __unwind
      {
        std::unique_ptr<double>::~unique_ptr<double>(this: &v27); /*0xf1c00000000000c4*/
      }
      std::unique_ptr<double>::~unique_ptr<double>(this: &v27); /*0x14225f715*/
      if ( !v11 ) /*0x14225f71c*/
        break; /*0x14225f71c*/
      if ( isDiagOnly ) /*0x14225f729*/
      {
        Ptr = RBX::json::MemberIterator::name(this: &it, result: &v30); /*0x14225f740*/
        v14 = v6 | 2; /*0x14225f746*/
        if ( Ptr->_Mypair._Myval2._Myres >= 0x10 ) /*0x14225f751*/
          Ptr = (const std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x14225f753*/
        __eh34_enter_wind_state(0, 2); /*0xf1c00000000000e0*/
        __eh34_enter_wind_state(2, 3); /*0xf1c00000000000e4*/
        v12 = RBX::format(result: &v29, fmt: "_%s", Ptr->_Mypair._Myval2._Bx._Buf); /*0x14225f769*/
        v6 = v14 | 4; /*0x14225f76c*/
      }
      else
      {
        v12 = (std::string *)RBX::json::MemberIterator::name(this: &it, result: &v31.text); /*0x14225f734*/
        __eh34_enter_wind_state(0, 2); /*0xf1c00000000000b8*/
        v6 |= 1u; /*0x14225f737*/
        __eh34_enter_wind_state(2, 3); /*0xf1c00000000000b0*/
      }
      v32 = v6; /*0x14225f76f*/
      applicationName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14225f772*/
      applicationName._Mypair._Myval2._Mysize = 0; /*0x14225f776*/
      applicationName._Mypair._Myval2._Myres = 0; /*0x14225f77a*/
      Mysize = v12->_Mypair._Myval2._Mysize; /*0x14225f77e*/
      if ( v12->_Mypair._Myval2._Myres >= 0x10 ) /*0x14225f787*/
        v12 = (std::string *)v12->_Mypair._Myval2._Bx._Ptr; /*0x14225f789*/
      __wind /*0xf1c0000000000054*/
      {
        if ( Mysize >= 0x10 ) /*0x14225f790*/
        {
          v16 = Mysize | 0xF; /*0x14225f7a6*/
          if ( (Mysize | 0xF) > 0x7FFFFFFFFFFFFFFFLL ) /*0x14225f7b7*/
            v16 = 0x7FFFFFFFFFFFFFFFLL; /*0x14225f7b7*/
          if ( v16 + 1 < 0x1000 ) /*0x14225f7c6*/
          {
            if ( v16 == -1 ) /*0x14225f7fa*/
              v19 = nullptr; /*0x14225f803*/
            else
              v19 = (char *)operator new(size: v16 + 1); /*0x14225f7fc*/
          }
          else
          {
            if ( v16 + 40 < v16 + 1 ) /*0x14225f7cf*/
              std::_Throw_bad_array_new_length(); /*0x14225fa0e*/
            v17 = operator new(size: v16 + 40); /*0x14225f7d8*/
            v18 = v17; /*0x14225f7dd*/
            if ( v17 == nullptr ) /*0x14225f7e3*/
              _invalid_parameter_noinfo_noreturn(); /*0x14225f99c*/
            v19 = (char *)(((unsigned __int64)v17 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x14225f7ed*/
            *((_QWORD *)v19 - 1) = v18; /*0x14225f7f1*/
          }
          applicationName._Mypair._Myval2._Bx._Ptr = v19; /*0x14225f805*/
          memcpy_0(a1: v19, Src: v12, Size: Mysize + 1); /*0x14225f813*/
          applicationName._Mypair._Myval2._Myres = v16; /*0x14225f818*/
        }
        else
        {
          applicationName._Mypair._Myval2._Bx = v12->_Mypair._Myval2._Bx; /*0x14225f795*/
          applicationName._Mypair._Myval2._Myres = 15; /*0x14225f799*/
        }
        applicationName._Mypair._Myval2._Mysize = Mysize; /*0x14225f81f*/
      }
      __unwind
      {
        if ( (v6 & 4) != 0 ) /*0x1432845b4*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v29); /*0x1432845c1*/
      }
      __wind /*0xf1c000000000006c*/
      {
        if ( (v6 & 4) != 0 ) /*0x14225f827*/
        {
          v6 &= ~4u; /*0x14225f829*/
          v32 = v6; /*0x14225f82c*/
          if ( v29._Mypair._Myval2._Myres >= 0x10 ) /*0x14225f837*/
          {
            v20 = v29._Mypair._Myval2._Bx._Ptr; /*0x14225f83c*/
            if ( v29._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14225f84a*/
            {
              v20 = *((char **)v29._Mypair._Myval2._Bx._Ptr - 1); /*0x14225f850*/
              if ( (unsigned __int64)(v29._Mypair._Myval2._Bx._Ptr - v20 - 8) > 0x1F ) /*0x14225f85f*/
                _invalid_parameter_noinfo_noreturn(); /*0x14225f9a3*/
            }
            operator delete(ptr: v20); /*0x14225f865*/
          }
          v29._Mypair._Myval2._Mysize = 0; /*0x14225f86a*/
          v29._Mypair._Myval2._Myres = 15; /*0x14225f86e*/
          v29._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14225f876*/
        }
        if ( (v6 & 2) != 0 ) /*0x14225f87e*/
        {
          v6 &= ~2u; /*0x14225f880*/
          v32 = v6; /*0x14225f883*/
          if ( v30._Mypair._Myval2._Myres >= 0x10 ) /*0x14225f88e*/
          {
            v21 = v30._Mypair._Myval2._Bx._Ptr; /*0x14225f893*/
            if ( v30._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14225f8a1*/
            {
              v21 = *((char **)v30._Mypair._Myval2._Bx._Ptr - 1); /*0x14225f8a7*/
              if ( (unsigned __int64)(v30._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x14225f8b6*/
                _invalid_parameter_noinfo_noreturn(); /*0x14225f9aa*/
            }
            operator delete(ptr: v21); /*0x14225f8bc*/
          }
          v30._Mypair._Myval2._Mysize = 0; /*0x14225f8c1*/
          v30._Mypair._Myval2._Myres = 15; /*0x14225f8c5*/
          v30._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14225f8cd*/
        }
        if ( (v6 & 1) != 0 ) /*0x14225f8d5*/
        {
          v6 &= ~1u; /*0x14225f8d7*/
          v32 = v6; /*0x14225f8da*/
          if ( v31.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14225f8e5*/
          {
            v22 = v31.text._Mypair._Myval2._Bx._Ptr; /*0x14225f8ea*/
            if ( v31.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14225f8f8*/
            {
              v22 = *((char **)v31.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14225f8fe*/
              if ( (unsigned __int64)(v31.text._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x14225f90d*/
                _invalid_parameter_noinfo_noreturn(); /*0x14225f9b1*/
            }
            operator delete(ptr: v22); /*0x14225f913*/
          }
          v31.text._Mypair._Myval2._Mysize = 0; /*0x14225f918*/
          v31.text._Mypair._Myval2._Myres = 15; /*0x14225f91c*/
          v31.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14225f924*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&applicationName); /*0xf1c000000000007c*/
      }
      if ( __eh34_unwind(3) ) /*0xf1c0000000000084*/
      {
        if ( (v32 & 2) != 0 ) /*0x143284584*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v30); /*0x143284591*/
        __eh34_continue_unwinding(3, 2); /*0xf1c000000000008c*/
      }
      __eh34_exit_wind_state(3, 2); /*0xf1c0000000000090*/
      if ( __eh34_unwind(2) ) /*0xf1c0000000000094*/
      {
        if ( (v32 & 1) != 0 ) /*0x143284554*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v31); /*0x143284564*/
        __eh34_continue_unwinding(2, 0); /*0xf1c000000000009c*/
      }
      __eh34_exit_wind_state(2, 0); /*0xf1c00000000000a0*/
      __wind /*0xf1c00000000000a4*/
      {
        v23 = (RBX::json::Value *)RBX::json::MemberIterator::value(this: &it, result: (const RBX::json::Value *)&v31.x); /*0x14225f930*/
        v9 &= RBX::Security::KeyRing::parseApplication(this, application: v23, &applicationName); /*0x14225f944*/
        v8 = 1; /*0x14225f947*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&applicationName); /*0xf1c000000000004c*/
      }
      if ( applicationName._Mypair._Myval2._Myres >= 0x10 ) /*0x14225f952*/
      {
        v24 = applicationName._Mypair._Myval2._Bx._Ptr; /*0x14225f957*/
        if ( applicationName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14225f965*/
        {
          v24 = *((char **)applicationName._Mypair._Myval2._Bx._Ptr - 1); /*0x14225f96b*/
          if ( (unsigned __int64)(applicationName._Mypair._Myval2._Bx._Ptr - v24 - 8) > 0x1F ) /*0x14225f97a*/
          {
            if ( __eh34_unwind(0) ) /*0xf1c0000000000034*/
              goto unwind_state_0; /*0xf1c0000000000034*/
            __eh34_exit_wind_state(0, -1); /*0xf1c0000000000038*/
            _invalid_parameter_noinfo_noreturn(); /*0x14225f9b8*/
          }
        }
        operator delete(ptr: v24); /*0x14225f97c*/
      }
      RBX::json::MemberIterator::operator++(this: &it); /*0x14225f985*/
    }
    if ( __eh34_unwind(0) ) /*0xf1c0000000000020*/
    {
unwind_state_0:
      std::unique_ptr<double>::~unique_ptr<double>(this: &it); /*0xf1c0000000000024*/
      __eh34_propagate_exception_into_caller(0, -1); /*0xf1c0000000000028*/
    }
    __eh34_exit_wind_state(0, -1); /*0xf1c000000000002c*/
    std::unique_ptr<double>::~unique_ptr<double>(this: &it); /*0x14225f9c3*/
    if ( v8 == 0 ) /*0x14225f9cb*/
    {
      if ( DFLog::KeyRing != 0 ) /*0x14225f9d6*/
        FLog::FastLogFormatted(level: DFLog::KeyRing, message: "[DFLog::KeyRing] No applicaitons found."); /*0x14225f9e1*/
      return 0; /*0x14225f9e6*/
    }
    return v9; /*0x14225f9e9*/
  }
  else
  {
    if ( DFLog::KeyRing != 0 ) /*0x14225f6bd*/
      FLog::FastLogFormatted(level: DFLog::KeyRing, message: "[DFLog::KeyRing] \"Applications\" invalid."); /*0x14225f6c8*/
    return 0; /*0x14225f6cd*/
  }
}

// Address: 0x14225fa20 | Name: ?parseConfig@KeyRing@Security@RBX@@QEAA_NAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@_N@Z
__int64 __fastcall RBX::Security::KeyRing::parseConfig(
        RBX::Security::KeyRing *this,
        std::string *config,
        bool isDiagOnly)
{
  bool v3; // di
  RBX::Security::KeyRing *v4; // r14
  unsigned __int64 Mysize; // rax
  unsigned __int8 v6; // si
  const RBX::json::MemberIterator *v7; // rax
  bool v8; // bl
  unsigned __int64 v9; // r13
  _DWORD *v10; // r12
  std::string *Myfirst; // rbx
  unsigned __int64 Myres; // r14
  char *v13; // rdi
  std::string *Mylast; // rsi
  unsigned __int64 v15; // r15
  std::string *p_newConfigLogName; // rdx
  size_t v17; // r8
  std::string *v18; // rcx
  std::string *v19; // r8
  char *v20; // rax
  const RBX::json::MemberIterator *v21; // rax
  bool v22; // bl
  RBX::json::Value *v23; // rax
  RBX::json::Value *v24; // rax
  char *v25; // rcx
  std::string *p_creationTime; // r8
  std::string *v27; // rbx
  std::string *v28; // r9
  char *v29; // rcx
  std::string *v30; // rdx
  char *v31; // rcx
  __int64 result; // rax
  std::string newConfigLogName; // [rsp+40h] [rbp-C0h] BYREF
  RBX::json::MemberIteratorHelper members; // [rsp+60h] [rbp-A0h] BYREF
  std::string v35; // [rsp+70h] [rbp-90h] BYREF
  std::unique_lock<boost::shared_mutex> lock; // [rsp+90h] [rbp-70h] BYREF
  std::string v37; // [rsp+A0h] [rbp-60h] BYREF
  std::string creationTime; // [rsp+C0h] [rbp-40h] BYREF
  RBX::json::Document doc; // [rsp+E0h] [rbp-20h] BYREF
  RBX::Graphics::ProfilerAdorn::Item ptr; // [rsp+100h] [rbp+0h] BYREF
  __int64 v41; // [rsp+138h] [rbp+38h]
  char v42; // [rsp+140h] [rbp+40h] BYREF
  boost::gregorian::date d; // [rsp+198h] [rbp+98h] BYREF
  bool v45; // [rsp+1A0h] [rbp+A0h]
  RBX::json::MemberIterator it; // [rsp+1A8h] [rbp+A8h] BYREF

  v45 = isDiagOnly; /*0x14225fa20*/
  v3 = isDiagOnly; /*0x14225fa42*/
  v4 = this; /*0x14225fa46*/
  Mysize = config->_Mypair._Myval2._Mysize; /*0x14225fa49*/
  if ( config->_Mypair._Myval2._Myres >= 0x10 ) /*0x14225fa52*/
    config = (std::string *)config->_Mypair._Myval2._Bx._Ptr; /*0x14225fa54*/
  v37._Mypair._Myval2._Bx._Ptr = (char *)config; /*0x14225fa57*/
  *(_QWORD *)&v37._Mypair._Myval2._Bx._Alias[8] = Mysize; /*0x14225fa5b*/
  lock = (std::unique_lock<boost::shared_mutex>)v37._Mypair._Myval2._Bx; /*0x14225fa63*/
  RBX::json::parse(result: &doc, s: (RBX::StringView *)&lock); /*0x14225fa70*/
  __wind
  {
    if ( RBX::json::Document::hasError(this: &doc) )
    {
      if ( DFLog::KeyRing != 0 ) /*0x14225fa8c*/
        FLog::FastLogFormatted( /*0x14225fa97*/
          level: DFLog::KeyRing,
          message: "[DFLog::KeyRing] Config is invalid json, can only use old config");
      v6 = 0; /*0x14225fa9c*/
    }
    else
    {
      RBX::json::Value::members(this: &doc.RBX::json::Value, result: &members); /*0x14225faad*/
      RBX::json::MemberIteratorHelper::begin(this: &members, result: &it); /*0x14225fabe*/
      __eh34_enter_wind_state(0, 1); /*0xf1c0000000000144*/
      v7 = RBX::json::MemberIteratorHelper::end(this: &members, result: (RBX::json::MemberIterator *)&v37); /*0x14225facd*/
      __eh34_enter_wind_state(1, 2); /*0xf1c000000000013c*/
      v8 = RBX::json::MemberIterator::operator!=(this: &it, rhs: v7); /*0x14225fae2*/
      if ( __eh34_unwind(2) ) /*0xf1c0000000000130*/
      {
unwind_state_2:
        std::unique_ptr<double>::~unique_ptr<double>(this: (RBX::json::MemberIterator *)&v37); /*0xf1c0000000000100*/
        __eh34_continue_unwinding(2, 1); /*0xf1c0000000000104*/
      }
      __eh34_exit_wind_state(2, 1); /*0xf1c0000000000134*/
      std::unique_ptr<double>::~unique_ptr<double>(this: (RBX::json::MemberIterator *)&v37); /*0x14225fae9*/
      v9 = 15; /*0x14225faee*/
      if ( v8 )
      {
        v10 = (_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL); /*0x14225fb14*/
        do
        {
          RBX::json::MemberIterator::name(this: &it, result: &newConfigLogName); /*0x14225fb2c*/
          __wind
          {
            if ( _TSS0_1630 > *v10 ) /*0x14225fb3c*/
            {
              __wind /*0xf1c0000000000030*/
              {
                Init_thread_header(pOnce: &_TSS0_1630); /*0x14225ffc0*/
                if ( _TSS0_1630 == -1 ) /*0x14225ffcc*/
                {
                  __wind /*0xf1c0000000000024*/
                  {
                    ptr.text._Mypair._Myval2._Myres = 15; /*0x14225ffd2*/
                    ptr.text._Mypair._Myval2._Mysize = 12; /*0x14225ffd6*/
                    strcpy(ptr.text._Mypair._Myval2._Bx._Buf, "creationTime"); /*0x14225ffe6*/
                    v41 = 15; /*0x14225fff8*/
                    *(_QWORD *)&ptr.color = 12; /*0x14225fffc*/
                    strcpy((char *)&ptr.x, "applications"); /*0x14226000c*/
                    v35._Mypair._Myval2._Bx._Ptr = (char *)&ptr; /*0x142260022*/
                    *(_QWORD *)&v35._Mypair._Myval2._Bx._Alias[8] = &v42; /*0x14226002b*/
                    std::vector<std::string>::vector<std::string>( /*0x142260043*/
                      this: &kKnownKeys,
                      _Ilist: (std::initializer_list<std::string > *)&v35,
                      _Al: (const std::allocator<std::string > *)&d);
                  }
                  __unwind
                  {
                    `eh vector destructor iterator'( /*0x143284612*/
                      &ptr,
                      size: 0x20u,
                      count: 2u,
                      destructor: (void (__fastcall *)(void *))RBX::Graphics::ProfilerAdorn::Item::~Item);
                  }
                  `eh vector destructor iterator'( /*0x14226005d*/
                    &ptr,
                    size: 0x20u,
                    count: 2u,
                    destructor: (void (__fastcall *)(void *))RBX::Graphics::ProfilerAdorn::Item::~Item);
                  atexit(function: RBX::Security::KeyRing::parseConfig_::_14_::_dynamic_atexit_destructor_for__kKnownKeys__); /*0x142260069*/
                  Init_thread_footer(pOnce: &_TSS0_1630); /*0x142260076*/
                }
              }
              __unwind
              {
                Init_thread_abort(pOnce: &_TSS0_1630); /*0x1432845e7*/
              }
            }
            Myfirst = kKnownKeys._Mypair._Myval2._Myfirst; /*0x14225fb42*/
            Myres = newConfigLogName._Mypair._Myval2._Myres; /*0x14225fb49*/
            v13 = newConfigLogName._Mypair._Myval2._Bx._Ptr; /*0x14225fb4e*/
            Mylast = kKnownKeys._Mypair._Myval2._Mylast; /*0x14225fb53*/
            if ( kKnownKeys._Mypair._Myval2._Myfirst == kKnownKeys._Mypair._Myval2._Mylast ) /*0x14225fb5d*/
              goto LABEL_24; /*0x14225fb5d*/
            v15 = newConfigLogName._Mypair._Myval2._Mysize; /*0x14225fb5f*/
            while ( 1 ) /*0x14225fb70*/
            {
              p_newConfigLogName = &newConfigLogName; /*0x14225fb70*/
              if ( Myres >= 0x10 ) /*0x14225fb79*/
                p_newConfigLogName = (std::string *)v13; /*0x14225fb79*/
              v17 = Myfirst->_Mypair._Myval2._Mysize; /*0x14225fb7d*/
              v18 = Myfirst; /*0x14225fb81*/
              if ( Myfirst->_Mypair._Myval2._Myres >= 0x10 ) /*0x14225fb89*/
                v18 = (std::string *)Myfirst->_Mypair._Myval2._Bx._Ptr; /*0x14225fb8b*/
              if ( v17 == v15 && memcmp_0(Buf1: v18, Buf2: p_newConfigLogName, Size: v17) == 0 ) /*0x14225fb9a*/
                break; /*0x14225fb9a*/
              if ( ++Myfirst == Mylast ) /*0x14225fba3*/
                goto LABEL_24; /*0x14225fba3*/
            }
            if ( Mylast == Myfirst )
            {
LABEL_24:
              if ( DFLog::KeyRing != 0 )
              {
                v19 = &newConfigLogName; /*0x14225fbb7*/
                if ( Myres >= 0x10 ) /*0x14225fbc0*/
                  v19 = (std::string *)v13; /*0x14225fbc0*/
                FLog::FastLogFormatted(
                  level: DFLog::KeyRing,
                  message: "[DFLog::KeyRing] Config has unknown key : %s.",
                  v19->_Mypair._Myval2._Bx._Buf);
                Myres = newConfigLogName._Mypair._Myval2._Myres; /*0x14225fbd2*/
                v13 = newConfigLogName._Mypair._Myval2._Bx._Ptr; /*0x14225fbd7*/
              }
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&newConfigLogName); /*0xf1c000000000011c*/
          }
          if ( Myres >= 0x10 ) /*0x14225fbe0*/
          {
            v20 = v13; /*0x14225fbe6*/
            if ( Myres + 1 >= 0x1000 ) /*0x14225fbf0*/
            {
              v13 = *((char **)v13 - 1); /*0x14225fbf6*/
              if ( (unsigned __int64)(v20 - v13 - 8) > 0x1F ) /*0x14225fc05*/
              {
                if ( __eh34_unwind(1) ) /*0xf1c0000000000158*/
                {
unwind_state_1:
                  std::unique_ptr<double>::~unique_ptr<double>(this: &it); /*0xf1c00000000000ec*/
                  __eh34_continue_unwinding(1, 0); /*0xf1c00000000000f0*/
                }
                __eh34_exit_wind_state(1, 0); /*0xf1c000000000015c*/
                __eh34_enter_wind_state(0, 9); /*0xf1c0000000000160*/
                _invalid_parameter_noinfo_noreturn(); /*0x14225fd07*/
              }
            }
            operator delete(ptr: v13); /*0x14225fc0e*/
          }
          RBX::json::MemberIterator::operator++(this: &it); /*0x14225fc1a*/
          v21 = RBX::json::MemberIteratorHelper::end(this: &members, result: (RBX::json::MemberIterator *)&v37); /*0x14225fc28*/
          __eh34_enter_wind_state(1, 2); /*0xf1c0000000000110*/
          v22 = RBX::json::MemberIterator::operator!=(this: &it, rhs: v21); /*0x14225fc3d*/
          if ( __eh34_unwind(2) ) /*0xf1c00000000000fc*/
            goto unwind_state_2; /*0xf1c00000000000fc*/
          __eh34_exit_wind_state(2, 1); /*0xf1c0000000000108*/
          std::unique_ptr<double>::~unique_ptr<double>(this: (RBX::json::MemberIterator *)&v37); /*0x14225fc44*/
        }
        while ( v22 );
        v4 = this; /*0x14225fc51*/
        v3 = v45; /*0x14225fc58*/
      }
      std::unique_ptr<double>::~unique_ptr<double>(this: &it); /*0x14225fc66*/
      if ( __eh34_unwind(1) ) /*0xf1c00000000000e8*/
        goto unwind_state_1; /*0xf1c00000000000e8*/
      __eh34_exit_wind_state(1, 0); /*0xf1c00000000000f4*/
      v23 = (RBX::json::Value *)RBX::json::Value::operator[]( /*0x14225fc7a*/
                                  this: &doc.RBX::json::Value,
                                  result: (const RBX::json::Value *)&lock,
                                  s: "applications");
      v6 = RBX::Security::KeyRing::parseApplications(this: v4, applications: v23, isDiagOnly: v3); /*0x14225fc8e*/
      v24 = (RBX::json::Value *)RBX::json::Value::operator[]( /*0x14225fca0*/
                                  this: &doc.RBX::json::Value,
                                  result: (const RBX::json::Value *)&lock,
                                  s: "creationTime");
      newConfigLogName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14225fca7*/
      newConfigLogName._Mypair._Myval2._Mysize = 0; /*0x14225fcac*/
      newConfigLogName._Mypair._Myval2._Myres = 15; /*0x14225fcb1*/
      __wind /*0xf1c00000000000c8*/
      {
        RBX::json::Value::getString(this: v24, result: &creationTime, defaultValue: &newConfigLogName); /*0x14225fcc6*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&newConfigLogName); /*0xf1c00000000000d8*/
      }
      __eh34_enter_wind_state(0, 9); /*0xf1c00000000000e0*/
      if ( newConfigLogName._Mypair._Myval2._Myres >= 0x10 ) /*0x14225fcd5*/
      {
        v25 = newConfigLogName._Mypair._Myval2._Bx._Ptr; /*0x14225fcda*/
        if ( newConfigLogName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14225fce9*/
        {
          v25 = *((char **)newConfigLogName._Mypair._Myval2._Bx._Ptr - 1); /*0x14225fcef*/
          if ( (unsigned __int64)(newConfigLogName._Mypair._Myval2._Bx._Ptr - v25 - 8) > 0x1F ) /*0x14225fcfe*/
            _invalid_parameter_noinfo_noreturn(); /*0x14225fd00*/
        }
        operator delete(ptr: v25); /*0x14225fd0e*/
      }
      newConfigLogName._Mypair._Myval2._Mysize = 0; /*0x14225fd13*/
      newConfigLogName._Mypair._Myval2._Myres = 15; /*0x14225fd18*/
      newConfigLogName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14225fd1d*/
      if ( DFLog::KeyRing != 0 )
      {
        if ( creationTime._Mypair._Myval2._Mysize != 0 ) /*0x14225fd32*/
        {
          p_creationTime = &creationTime; /*0x14225fd3d*/
          if ( creationTime._Mypair._Myval2._Myres >= 0x10 ) /*0x14225fd46*/
            p_creationTime = (std::string *)creationTime._Mypair._Myval2._Bx._Ptr; /*0x14225fd46*/
        }
        else
        {
          p_creationTime = (std::string *)"unknown"; /*0x14225fd34*/
        }
        FLog::FastLogFormatted(
          level: DFLog::KeyRing,
          message: "[DFLog::KeyRing] Parsed config created at: %s.",
          p_creationTime->_Mypair._Myval2._Bx._Buf);
      }
      if ( DFFlag::KeyRingVersioning.value && (v3 || creationTime._Mypair._Myval2._Mysize != 0) ) /*0x14225fd72*/
      {
        newConfigLogName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14225fd78*/
        newConfigLogName._Mypair._Myval2._Mysize = 0; /*0x14225fd7d*/
        newConfigLogName._Mypair._Myval2._Myres = 15; /*0x14225fd82*/
        __wind /*0xf1c00000000000bc*/
        {
          if ( creationTime._Mypair._Myval2._Mysize + 33 >= 0x10 ) /*0x14225fd94*/
          {
            std::string::_Reallocate_grow_by<_lambda_9013ee9e23efe4882b67eff5b0ecf103_,>( /*0x14225fd9e*/
              this: &newConfigLogName,
              _Size_increase: creationTime._Mypair._Myval2._Mysize + 33,
              _Fn: 0);
            newConfigLogName._Mypair._Myval2._Mysize = 0; /*0x14225fda3*/
            v9 = newConfigLogName._Mypair._Myval2._Myres; /*0x14225fda8*/
          }
          lock._Pmtx = &v4->mutex; /*0x14225fdb1*/
          it.it._Mypair._Myval2 = (rapidjson110::GenericMemberIterator<1,rapidjson110::UTF8<char>,RBX::json::TrackedAllocator> *)0x7FFFFFFFFFFFFFFFLL; /*0x14225fdbf*/
          d.days_ = -1; /*0x14225fdc6*/
          boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>( /*0x14225fde2*/
            this: (boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config> *)&v37,
            &d,
            time_of_day: (const boost::posix_time::time_duration *)&it);
          boost::shared_mutex::timed_lock(this: &v4->mutex, wait_until: (const boost::posix_time::ptime *)&v37); /*0x14225fdee*/
          lock._Owns = true; /*0x14225fdf3*/
          __wind /*0xf1c0000000000098*/
          {
            v35._Mypair._Myval2._Bx._Ptr = (char *)v4->configHash; /*0x14225fdfe*/
            *(_QWORD *)&v35._Mypair._Myval2._Bx._Alias[8] = 16; /*0x14225fe03*/
            v27 = RBX::Crypto::convertToHex(result: &ptr.text, binData: (const RBX::StringView *)&v35, useLower: true); /*0x14225fe28*/
            __wind /*0xf1c000000000008c*/
            {
              if ( 0x7FFFFFFFFFFFFFFFLL == creationTime._Mypair._Myval2._Mysize ) /*0x14225fe2f*/
                std::_Xlen_string(); /*0x14225ffb3*/
              v28 = &creationTime; /*0x14225fe3c*/
              if ( creationTime._Mypair._Myval2._Myres >= 0x10 ) /*0x14225fe45*/
                v28 = (std::string *)creationTime._Mypair._Myval2._Bx._Ptr; /*0x14225fe45*/
              std::string::string( /*0x14225fe73*/
                this: &v37,
                __formal: (std::_String_constructor_concat_tag)d.days_,
                _Source_of_al: &creationTime,
                _Left_ptr: v28->_Mypair._Myval2._Bx._Buf,
                _Left_size: creationTime._Mypair._Myval2._Mysize,
                _Right_ptr: "#",
                _Right_size: 1u);
              __wind /*0xf1c0000000000080*/
              {
                std::string::string( /*0x14225fe8c*/
                  this: &v35,
                  __formal: (std::_String_constructor_concat_tag)d.days_,
                  _Left: &v37,
                  _Right: v27);
                if ( v9 >= 0x10 ) /*0x14225fe95*/
                {
                  v29 = newConfigLogName._Mypair._Myval2._Bx._Ptr; /*0x14225fe9b*/
                  if ( v9 + 1 >= 0x1000 ) /*0x14225feaa*/
                  {
                    v29 = *((char **)newConfigLogName._Mypair._Myval2._Bx._Ptr - 1); /*0x14225feb0*/
                    if ( (unsigned __int64)(newConfigLogName._Mypair._Myval2._Bx._Ptr - v29 - 8) > 0x1F ) /*0x14225febf*/
                      _invalid_parameter_noinfo_noreturn(); /*0x14225fec1*/
                  }
                  operator delete(ptr: v29); /*0x14225fec8*/
                }
                newConfigLogName = v35; /*0x14225fed2*/
                *(__m128i *)&v35._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14225fee8*/
                v35._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14225feed*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v35); /*0x14225fef7*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v37); /*0xf1c0000000000078*/
              }
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v37); /*0x14225ff01*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: &ptr); /*0x14225ff0b*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: &ptr); /*0xf1c000000000006c*/
            }
            if ( &v4->configLogName != &newConfigLogName ) /*0x14225ff1f*/
            {
              v30 = &newConfigLogName; /*0x14225ff21*/
              if ( newConfigLogName._Mypair._Myval2._Myres >= 0x10 ) /*0x14225ff2c*/
                v30 = (std::string *)newConfigLogName._Mypair._Myval2._Bx._Ptr; /*0x14225ff2c*/
              std::string::assign( /*0x14225ff37*/
                this: &v4->configLogName,
                _Ptr: v30->_Mypair._Myval2._Bx._Buf,
                _Count: newConfigLogName._Mypair._Myval2._Mysize);
            }
            std::unique_lock<boost::shared_mutex>::~unique_lock<boost::shared_mutex>(this: &lock); /*0x14225ff41*/
            if ( newConfigLogName._Mypair._Myval2._Myres >= 0x10 ) /*0x14225ff50*/
            {
              v31 = newConfigLogName._Mypair._Myval2._Bx._Ptr; /*0x14225ff55*/
              if ( newConfigLogName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14225ff64*/
              {
                v31 = *((char **)newConfigLogName._Mypair._Myval2._Bx._Ptr - 1); /*0x14225ff6a*/
                if ( (unsigned __int64)(newConfigLogName._Mypair._Myval2._Bx._Ptr - v31 - 8) > 0x1F ) /*0x14225ff79*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14225ff7b*/
              }
              operator delete(ptr: v31); /*0x14225ff82*/
            }
          }
          __unwind
          {
            std::unique_lock<boost::shared_mutex>::~unique_lock<boost::shared_mutex>(this: &lock); /*0xf1c00000000000a8*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&newConfigLogName); /*0xf1c00000000000b4*/
        }
      }
      if ( __eh34_unwind(9) ) /*0xf1c0000000000054*/
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&creationTime); /*0xf1c0000000000058*/
        __eh34_continue_unwinding(9, 0); /*0xf1c000000000005c*/
      }
      __eh34_exit_wind_state(9, 0); /*0xf1c0000000000060*/
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&creationTime); /*0x14225ff8c*/
    }
    RBX::json::Document::~Document(this: &doc); /*0x14225ff96*/
    result = v6; /*0x14225ff9b*/
  }
  __unwind
  {
    RBX::json::Document::~Document(this: &doc); /*0xf1c000000000004c*/
  }
  return result; /*0x14225ff9f*/
}

// Address: 0x142260090 | Name: ?parseVersion@KeyRing@Security@RBX@@AEAA?AV?$tuple@_NI_N@std@@AEBVValue@json@3@AEAV?$vector@UKeyInfo@KeyRing@Security@RBX@@V?$allocator@UKeyInfo@KeyRing@Security@RBX@@@std@@@5@II@Z
std::tuple<bool,unsigned int,bool> *__fastcall RBX::Security::KeyRing::parseVersion(
        RBX::Security::KeyRing *this,
        std::tuple<bool,unsigned int,bool> *result,
        RBX::json::Value *version,
        std::vector<RBX::Security::KeyRing::KeyInfo> *allowedVersions,
        unsigned int sendVersion,
        unsigned int revertVersion)
{
  std::vector<RBX::Security::KeyRing::KeyInfo> *v6; // r12
  RBX::json::Value *v7; // rsi
  RBX::Security::KeyRing *v9; // r13
  const RBX::json::MemberIterator *v10; // rax
  bool v11; // bl
  char *Myfirst; // rbx
  std::string *v13; // rbx
  unsigned __int64 Myres; // r13
  char *v15; // rdi
  std::string *Mylast; // rsi
  unsigned __int64 Mysize; // r12
  std::string *p_name; // rdx
  size_t v19; // r8
  std::string *v20; // rcx
  std::string *v21; // r8
  char *v22; // rax
  const RBX::json::MemberIterator *v23; // rax
  bool v24; // bl
  RBX::json::Value *v25; // rax
  unsigned int v26; // ebx
  RBX::json::Value *v27; // rax
  std::allocator<std::string > Bool; // di
  RBX::json::Value *v29; // rax
  char *v30; // rcx
  std::string *p_key64; // rcx
  char *v32; // rcx
  char *v33; // rcx
  RBX::Security::KeyRing::KeyInfo *v35; // rcx
  RBX::Security::KeyRing::KeyInfo *v36; // rax
  RBX::json::Value *v37; // rax
  std::string *p_key; // rax
  char *Buf; // rax
  char *v40; // rcx
  std::string *v41; // rdi
  char *v42; // rcx
  size_t v43; // rdi
  unsigned __int8 *Myend; // r12
  char *v45; // r13
  unsigned __int8 *v46; // rsi
  std::string *v47; // rdx
  RBX::Security::KeyRing::KeyInfo *v48; // r9
  unsigned __int64 v49; // rcx
  unsigned __int64 v50; // rdx
  char *v51; // r8
  char *v52; // rax
  char *v53; // rcx
  std::allocator<std::string > v54; // [rsp+20h] [rbp-E0h] BYREF
  std::string key; // [rsp+28h] [rbp-D8h] BYREF
  std::vector<unsigned char> keyValue; // [rsp+50h] [rbp-B0h] BYREF
  std::string name; // [rsp+70h] [rbp-90h] BYREF
  RBX::json::MemberIterator it; // [rsp+90h] [rbp-70h] BYREF
  std::vector<signed char> v59; // [rsp+A0h] [rbp-60h] BYREF
  RBX::json::MemberIteratorHelper members; // [rsp+C0h] [rbp-40h] BYREF
  RBX::json::MemberIterator v61; // [rsp+C8h] [rbp-38h] BYREF
  std::string key64; // [rsp+D0h] [rbp-30h] BYREF
  _QWORD ptr[4]; // [rsp+F0h] [rbp-10h] BYREF
  _BYTE v64[6]; // [rsp+110h] [rbp+10h] BYREF
  __int16 v65; // [rsp+116h] [rbp+16h]
  __int64 v66; // [rsp+120h] [rbp+20h]
  __int64 v67; // [rsp+128h] [rbp+28h]
  __int64 v68; // [rsp+130h] [rbp+30h]
  __int64 v69; // [rsp+140h] [rbp+40h]
  __int64 v70; // [rsp+148h] [rbp+48h]
  int v71; // [rsp+150h] [rbp+50h]
  int v72; // [rsp+154h] [rbp+54h]
  __int64 v73; // [rsp+160h] [rbp+60h]
  __int64 v74; // [rsp+168h] [rbp+68h]
  char v75[16]; // [rsp+170h] [rbp+70h] BYREF
  __int64 v76; // [rsp+180h] [rbp+80h]
  __int64 v77; // [rsp+188h] [rbp+88h]
  char v78; // [rsp+190h] [rbp+90h] BYREF

  v6 = allowedVersions; /*0x1422600be*/
  v7 = version; /*0x1422600c1*/
  v9 = this; /*0x1422600c7*/
  if ( !RBX::json::Value::isObject(this: version) ) /*0x1422600cd*/
  {
    result->std::tuple<unsigned int,bool>::std::tuple<bool>::_Myfirst._Val = false; /*0x1422600d6*/
    result->std::tuple<unsigned int,bool>::_Myfirst._Val = 0; /*0x1422600dc*/
    result->_Myfirst._Val = false; /*0x1422600e0*/
    return result; /*0x1422600e4*/
  }
  RBX::json::Value::members(this: v7, result: &members); /*0x1422600f0*/
  RBX::json::MemberIteratorHelper::begin(this: &members, result: &it); /*0x1422600fd*/
  __wind
  {
    v10 = RBX::json::MemberIteratorHelper::end(this: &members, result: &v61); /*0x14226010b*/
    __eh34_enter_wind_state(0, 1); /*0xf1c000000000011c*/
    v11 = RBX::json::MemberIterator::operator!=(this: &it, rhs: v10); /*0x14226011d*/
    if ( __eh34_unwind(1) ) /*0xf1c0000000000110*/
    {
unwind_state_1:
      std::unique_ptr<double>::~unique_ptr<double>(this: &v61); /*0xf1c00000000000e0*/
      __eh34_continue_unwinding(1, 0); /*0xf1c00000000000e4*/
    }
    __eh34_exit_wind_state(1, 0); /*0xf1c0000000000114*/
    std::unique_ptr<double>::~unique_ptr<double>(this: &v61); /*0x142260124*/
    if ( v11 )
    {
      Myfirst = (char *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL); /*0x14226014c*/
      for ( v59._Mypair._Myval2._Myfirst = Myfirst; ; Myfirst = v59._Mypair._Myval2._Myfirst )
      {
        RBX::json::MemberIterator::name(this: &it, result: &name); /*0x142260161*/
        __wind
        {
          if ( _TSS0_1632 > *(_DWORD *)Myfirst ) /*0x14226016f*/
          {
            __wind /*0xf1c0000000000030*/
            {
              Init_thread_header(pOnce: &_TSS0_1632); /*0x142260817*/
              if ( _TSS0_1632 == -1 ) /*0x142260823*/
              {
                __wind /*0xf1c0000000000024*/
                {
                  ptr[0] = 25705; /*0x142260829*/
                  ptr[3] = 15; /*0x14226082d*/
                  ptr[2] = 2; /*0x142260835*/
                  v67 = 15; /*0x142260849*/
                  v66 = 7; /*0x142260851*/
                  qmemcpy(v64, "allowe", sizeof(v64)); /*0x14226085f*/
                  v65 = (unsigned __int8)aAllowed[6]; /*0x142260874*/
                  v70 = 15; /*0x14226087f*/
                  v69 = 4; /*0x142260887*/
                  v68 = 1701869940; /*0x14226088f*/
                  v74 = 15; /*0x14226089e*/
                  v73 = 5; /*0x1422608a6*/
                  v71 = *(_DWORD *)aValu; /*0x1422608b4*/
                  v72 = 101; /*0x1422608be*/
                  v77 = 15; /*0x1422608c5*/
                  v76 = 9; /*0x1422608d0*/
                  strcpy(v75, "hashJobId"); /*0x1422608e3*/
                  keyValue._Mypair._Myval2._Myfirst = (unsigned __int8 *)ptr; /*0x1422608fa*/
                  keyValue._Mypair._Myval2._Mylast = (unsigned __int8 *)&v78; /*0x142260906*/
                  std::vector<std::string>::vector<std::string>( /*0x14226091c*/
                    this: &kKnownKeys_1,
                    _Ilist: (std::initializer_list<std::string > *)&keyValue,
                    _Al: &v54);
                }
                __unwind
                {
                  `eh vector destructor iterator'( /*0x143284682*/
                    ptr,
                    size: 0x20u,
                    count: 5u,
                    destructor: (void (__fastcall *)(void *))RBX::Graphics::ProfilerAdorn::Item::~Item);
                }
                `eh vector destructor iterator'( /*0x142260936*/
                  ptr,
                  size: 0x20u,
                  count: 5u,
                  destructor: (void (__fastcall *)(void *))RBX::Graphics::ProfilerAdorn::Item::~Item);
                atexit(function: RBX::Security::KeyRing::parseVersion_::_7_::_dynamic_atexit_destructor_for__kKnownKeys__); /*0x142260942*/
                Init_thread_footer(pOnce: &_TSS0_1632); /*0x14226094f*/
              }
            }
            __unwind
            {
              Init_thread_abort(pOnce: &_TSS0_1632); /*0x143284657*/
            }
          }
          v13 = kKnownKeys_1._Mypair._Myval2._Myfirst; /*0x142260175*/
          Myres = name._Mypair._Myval2._Myres; /*0x14226017c*/
          v15 = name._Mypair._Myval2._Bx._Ptr; /*0x142260180*/
          Mylast = kKnownKeys_1._Mypair._Myval2._Mylast; /*0x142260185*/
          if ( kKnownKeys_1._Mypair._Myval2._Myfirst == kKnownKeys_1._Mypair._Myval2._Mylast ) /*0x14226018f*/
            goto LABEL_19; /*0x14226018f*/
          Mysize = name._Mypair._Myval2._Mysize; /*0x142260191*/
          while ( 1 ) /*0x1422601a0*/
          {
            p_name = &name; /*0x1422601a0*/
            if ( Myres >= 0x10 ) /*0x1422601a9*/
              p_name = (std::string *)v15; /*0x1422601a9*/
            v19 = v13->_Mypair._Myval2._Mysize; /*0x1422601ad*/
            v20 = v13; /*0x1422601b1*/
            if ( v13->_Mypair._Myval2._Myres >= 0x10 ) /*0x1422601b9*/
              v20 = (std::string *)v13->_Mypair._Myval2._Bx._Ptr; /*0x1422601bb*/
            if ( v19 == Mysize && memcmp_0(Buf1: v20, Buf2: p_name, Size: v19) == 0 ) /*0x1422601ca*/
              break; /*0x1422601ca*/
            if ( ++v13 == Mylast ) /*0x1422601d3*/
              goto LABEL_19; /*0x1422601d3*/
          }
          if ( Mylast == v13 )
          {
LABEL_19:
            if ( DFLog::KeyRing != 0 )
            {
              v21 = &name; /*0x1422601e7*/
              if ( Myres >= 0x10 ) /*0x1422601f0*/
                v21 = (std::string *)v15; /*0x1422601f0*/
              FLog::FastLogFormatted(
                level: DFLog::KeyRing,
                message: "[DFLog::KeyRing] Version has unknown key : %s.",
                v21->_Mypair._Myval2._Bx._Buf);
              Myres = name._Mypair._Myval2._Myres; /*0x142260202*/
              v15 = name._Mypair._Myval2._Bx._Ptr; /*0x142260206*/
            }
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&name); /*0xf1c00000000000fc*/
        }
        if ( Myres >= 0x10 ) /*0x14226020f*/
        {
          v22 = v15; /*0x142260215*/
          if ( Myres + 1 >= 0x1000 ) /*0x14226021f*/
          {
            v15 = *((char **)v15 - 1); /*0x142260225*/
            if ( (unsigned __int64)(v22 - v15 - 8) > 0x1F ) /*0x142260234*/
              _invalid_parameter_noinfo_noreturn(); /*0x14226027a*/
          }
          operator delete(ptr: v15); /*0x142260239*/
        }
        RBX::json::MemberIterator::operator++(this: &it); /*0x142260242*/
        v23 = RBX::json::MemberIteratorHelper::end(this: &members, result: &v61); /*0x14226024f*/
        __eh34_enter_wind_state(0, 1); /*0xf1c00000000000f0*/
        v24 = RBX::json::MemberIterator::operator!=(this: &it, rhs: v23); /*0x142260261*/
        if ( __eh34_unwind(1) ) /*0xf1c00000000000dc*/
          goto unwind_state_1; /*0xf1c00000000000dc*/
        __eh34_exit_wind_state(1, 0); /*0xf1c00000000000e8*/
        std::unique_ptr<double>::~unique_ptr<double>(this: &v61); /*0x142260268*/
        if ( !v24 ) /*0x14226026f*/
          break; /*0x14226026f*/
      }
      v7 = version; /*0x142260281*/
      v6 = allowedVersions; /*0x142260288*/
      v9 = this; /*0x14226028f*/
    }
    std::unique_ptr<double>::~unique_ptr<double>(this: &it); /*0x14226029a*/
  }
  __unwind
  {
    std::unique_ptr<double>::~unique_ptr<double>(this: &it); /*0xf1c00000000000d4*/
  }
  v25 = (RBX::json::Value *)RBX::json::Value::operator[](this: v7, result: (const RBX::json::Value *)&keyValue, s: "id"); /*0x1422602ae*/
  v26 = RBX::json::Value::getInteger<unsigned int>(this: v25); /*0x1422602bb*/
  if ( v26 == 0 ) /*0x1422602bf*/
  {
    if ( DFLog::KeyRing != 0 ) /*0x1422602ca*/
      FLog::FastLogFormatted(level: DFLog::KeyRing, message: "[DFLog::KeyRing] Application has null-versioned key."); /*0x1422602d5*/
    result->std::tuple<unsigned int,bool>::std::tuple<bool>::_Myfirst._Val = false; /*0x1422602da*/
    result->std::tuple<unsigned int,bool>::_Myfirst._Val = 0; /*0x1422602de*/
    result->_Myfirst._Val = false; /*0x1422602e2*/
    return result; /*0x1422602e7*/
  }
  v27 = (RBX::json::Value *)RBX::json::Value::operator[]( /*0x1422602fb*/
                              this: v7,
                              result: (const RBX::json::Value *)&keyValue,
                              s: "allowed");
  Bool = (std::allocator<std::string >)RBX::json::Value::getBool(this: v27); /*0x142260308*/
  v54 = Bool; /*0x14226030b*/
  v29 = (RBX::json::Value *)RBX::json::Value::operator[]( /*0x14226031e*/
                              this: v7,
                              result: (const RBX::json::Value *)&keyValue,
                              s: aValu);
  name._Mypair._Myval2._Bx._Ptr = nullptr; /*0x142260323*/
  name._Mypair._Myval2._Mysize = 0; /*0x142260328*/
  name._Mypair._Myval2._Myres = 15; /*0x14226032c*/
  __wind /*0xf1c00000000000ac*/
  {
    RBX::json::Value::getString(this: v29, result: &key64, defaultValue: &name); /*0x142260345*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&name); /*0xf1c00000000000bc*/
  }
  __wind /*0xf1c00000000000c4*/
  {
    if ( name._Mypair._Myval2._Myres >= 0x10 ) /*0x142260353*/
    {
      v30 = name._Mypair._Myval2._Bx._Ptr; /*0x142260358*/
      if ( name._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x142260367*/
      {
        v30 = *((char **)name._Mypair._Myval2._Bx._Ptr - 1); /*0x14226036d*/
        if ( (unsigned __int64)(name._Mypair._Myval2._Bx._Ptr - v30 - 8) > 0x1F ) /*0x14226037c*/
          _invalid_parameter_noinfo_noreturn(); /*0x14226037e*/
      }
      operator delete(ptr: v30); /*0x142260385*/
    }
    key._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14226038a*/
    key._Mypair._Myval2._Mysize = 0; /*0x14226038f*/
    key._Mypair._Myval2._Myres = 15; /*0x142260394*/
    p_key64 = &key64; /*0x1422603a2*/
    if ( key64._Mypair._Myval2._Myres >= 0x10 ) /*0x1422603ab*/
      p_key64 = (std::string *)key64._Mypair._Myval2._Bx._Ptr; /*0x1422603ab*/
    __eh34_enter_wind_state(11, 12); /*0xf1c00000000000a4*/
    base64<unsigned char,std::char_traits<unsigned char>>::decode( /*0x1422603b9*/
      input: p_key64->_Mypair._Myval2._Bx._Buf,
      length: key64._Mypair._Myval2._Mysize,
      output: &key);
    if ( key._Mypair._Myval2._Mysize == 0 ) /*0x1422603c4*/
    {
      if ( DFLog::KeyRing != 0 ) /*0x1422603d3*/
        FLog::FastLogFormatted(level: DFLog::KeyRing, message: "[DFLog::KeyRing] Application has empty key"); /*0x1422603de*/
LABEL_48:
      result->_Myfirst._Val = false; /*0x1422603e3*/
      result->std::tuple<unsigned int,bool>::_Myfirst._Val = 0; /*0x1422603e8*/
      result->std::tuple<unsigned int,bool>::std::tuple<bool>::_Myfirst._Val = false; /*0x1422603ec*/
      if ( __eh34_unwind(12) ) /*0xf1c0000000000098*/
        goto unwind_state_12; /*0xf1c0000000000098*/
      __eh34_exit_wind_state(12, 11); /*0xf1c000000000009c*/
      if ( key._Mypair._Myval2._Myres < 0x10 ) /*0x1422603f9*/
      {
LABEL_53:
        key._Mypair._Myval2._Mysize = 0; /*0x14226042d*/
        key._Mypair._Myval2._Myres = 15; /*0x142260432*/
        key._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14226043b*/
        if ( key64._Mypair._Myval2._Myres < 0x10 ) /*0x142260448*/
          return result; /*0x142260448*/
        v33 = key64._Mypair._Myval2._Bx._Ptr; /*0x14226044d*/
        if ( key64._Mypair._Myval2._Myres + 1 < 0x1000 ) /*0x14226045b*/
          goto LABEL_56; /*0x14226045b*/
        v33 = *((char **)key64._Mypair._Myval2._Bx._Ptr - 1); /*0x142260461*/
        if ( (unsigned __int64)(key64._Mypair._Myval2._Bx._Ptr - v33 - 8) <= 0x1F ) /*0x142260470*/
          goto LABEL_56; /*0x142260470*/
        goto LABEL_104; /*0x142260470*/
      }
      v32 = key._Mypair._Myval2._Bx._Ptr; /*0x1422603fb*/
      if ( key._Mypair._Myval2._Myres + 1 < 0x1000 /*0x142260422*/
        || (v32 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1),
            (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v32 - 8) <= 0x1F) )
      {
        operator delete(ptr: v32); /*0x142260428*/
        goto LABEL_53; /*0x142260428*/
      }
LABEL_99:
      _invalid_parameter_noinfo_noreturn(); /*0x1422607a6*/
    }
    v35 = v6->_Mypair._Myval2._Mylast; /*0x142260499*/
    v36 = v6->_Mypair._Myval2._Myfirst; /*0x14226049e*/
    if ( v6->_Mypair._Myval2._Myfirst != v35 ) /*0x1422604a5*/
    {
      while ( v36->id != v26 ) /*0x1422604aa*/
      {
        if ( ++v36 == v35 ) /*0x1422604b3*/
          goto LABEL_61; /*0x1422604b3*/
      }
      if ( v36 != v35 ) /*0x1422604e0*/
      {
        if ( DFLog::KeyRing != 0 ) /*0x1422604eb*/
          FLog::FastLogFormatted( /*0x1422604f8*/
            level: DFLog::KeyRing,
            message: "[DFLog::KeyRing] Application has duplicate versioned key");
        goto LABEL_48; /*0x1422604f8*/
      }
    }
LABEL_61:
    if ( Bool != 0 ) /*0x1422604b8*/
      goto LABEL_69; /*0x1422604b8*/
    if ( sendVersion == v26 ) /*0x1422604c0*/
    {
      if ( DFLog::KeyRing != 0 ) /*0x1422604cb*/
        FLog::FastLogFormatted( /*0x1422604d8*/
          level: DFLog::KeyRing,
          message: "[DFLog::KeyRing] Application sendVersion is not in allowed set.");
      goto LABEL_48; /*0x1422604d8*/
    }
    if ( revertVersion == v26 ) /*0x142260503*/
    {
LABEL_69:
      v37 = (RBX::json::Value *)RBX::json::Value::operator[]( /*0x142260518*/
                                  this: v7,
                                  result: (const RBX::json::Value *)&keyValue,
                                  s: "hashJobId");
      if ( RBX::json::Value::getBool(this: v37) ) /*0x142260520*/
      {
        p_key = &key; /*0x14226052d*/
        if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x142260538*/
          p_key = (std::string *)key._Mypair._Myval2._Bx._Ptr; /*0x142260538*/
        keyValue._Mypair._Myval2._Myfirst = (unsigned __int8 *)p_key; /*0x14226053e*/
        keyValue._Mypair._Myval2._Mylast = (unsigned __int8 *)key._Mypair._Myval2._Mysize; /*0x142260548*/
        Buf = v9->jobId._Mypair._Myval2._Bx._Buf; /*0x14226054d*/
        v40 = (char *)v9->jobId._Mypair._Myval2._Mysize; /*0x142260551*/
        if ( v9->jobId._Mypair._Myval2._Myres >= 0x10 ) /*0x14226055a*/
          Buf = *(char **)Buf; /*0x14226055c*/
        v59._Mypair._Myval2._Myfirst = Buf; /*0x14226055f*/
        v59._Mypair._Myval2._Mylast = v40; /*0x142260563*/
        v41 = RBX::Crypto::computeKeyedBlake2b( /*0x142260594*/
                result: &name,
                data: (const RBX::StringView *)&v59,
                secret: (const RBX::StringView *)&keyValue,
                digestSize: 32);
        if ( &key != v41 ) /*0x14226059f*/
        {
          if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x1422605aa*/
          {
            v42 = key._Mypair._Myval2._Bx._Ptr; /*0x1422605af*/
            if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1422605be*/
            {
              v42 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x1422605c4*/
              if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v42 - 8) > 0x1F ) /*0x1422605d3*/
                _invalid_parameter_noinfo_noreturn(); /*0x1422605d5*/
            }
            operator delete(ptr: v42); /*0x1422605dc*/
          }
          key._Mypair._Myval2._Mysize = 0; /*0x1422605e1*/
          key._Mypair._Myval2._Myres = 15; /*0x1422605e6*/
          key._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1422605ef*/
          key = *v41; /*0x1422605f7*/
          v41->_Mypair._Myval2._Mysize = 0; /*0x142260605*/
          v41->_Mypair._Myval2._Myres = 15; /*0x142260609*/
          v41->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x142260611*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&name); /*0x142260619*/
      }
      v43 = key._Mypair._Myval2._Mysize; /*0x14226061e*/
      memset(&keyValue, 0, sizeof(keyValue)); /*0x142260626*/
      Myend = nullptr; /*0x14226062c*/
      v45 = nullptr; /*0x142260634*/
      v46 = nullptr; /*0x142260637*/
      if ( key._Mypair._Myval2._Mysize != 0 ) /*0x14226063d*/
      {
        if ( key._Mypair._Myval2._Mysize > 0x7FFFFFFFFFFFFFFFLL ) /*0x14226064c*/
          std::vector<Luau::AstNode *>::_Xlength(); /*0x14226080a*/
        std::vector<unsigned char>::_Buy_raw(this: &keyValue, _Newcapacity: key._Mypair._Myval2._Mysize); /*0x14226065a*/
        v46 = keyValue._Mypair._Myval2._Myfirst; /*0x142260664*/
        memset_0(a1: keyValue._Mypair._Myval2._Myfirst, Val: 0, Size: v43); /*0x14226066c*/
        v45 = (char *)&v46[v43]; /*0x142260671*/
        Myend = keyValue._Mypair._Myval2._Myend; /*0x142260675*/
      }
      __wind /*0xf1c0000000000074*/
      {
        v47 = &key; /*0x142260680*/
        if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x14226068b*/
          v47 = (std::string *)key._Mypair._Myval2._Bx._Ptr; /*0x14226068b*/
        memcpy_0(a1: v46, Src: v47, Size: v45 - (char *)v46); /*0x142260694*/
        memset(&keyValue, 0, sizeof(keyValue)); /*0x1422606a3*/
        v59._Mypair._Myval2._Myfirst = (char *)v46; /*0x1422606a8*/
        v59._Mypair._Myval2._Mylast = v45; /*0x1422606ac*/
        v59._Mypair._Myval2._Myend = (char *)Myend; /*0x1422606b0*/
        Bool = v54; /*0x1422606b4*/
        RBX::Security::KeyRing::KeyInfo::KeyInfo( /*0x1422606c8*/
          this: (RBX::Security::KeyRing::KeyInfo *)&name,
          keyId: v26,
          keyValue: &v59,
          allowed: *(_BYTE *)&v54);
        __wind /*0xf1c0000000000068*/
        {
          v48 = allowedVersions->_Mypair._Myval2._Mylast; /*0x1422606d5*/
          if ( v48 == allowedVersions->_Mypair._Myval2._Myend ) /*0x1422606dd*/
          {
            std::vector<RBX::Security::KeyRing::KeyInfo>::_Emplace_reallocate<RBX::Security::KeyRing::KeyInfo>( /*0x14226071f*/
              this: allowedVersions,
              _Whereptr: allowedVersions->_Mypair._Myval2._Mylast,
              <_Val_0>: (RBX::Security::KeyRing::KeyInfo *)&name);
            v50 = name._Mypair._Myval2._Mysize; /*0x142260724*/
            v51 = name._Mypair._Myval2._Bx._Ptr; /*0x142260728*/
          }
          else
          {
            v49 = name._Mypair._Myval2._Mysize; /*0x1422606df*/
            v50 = 0; /*0x1422606e3*/
            v51 = nullptr; /*0x1422606eb*/
            *(std::_String_val<std::_Simple_types<char> >::_Bxty *)&v48->value._Mypair._Myval2._Myfirst = name._Mypair._Myval2._Bx; /*0x1422606ee*/
            v48->value._Mypair._Myval2._Myend = (unsigned __int8 *)v49; /*0x1422606fa*/
            v48->id = name._Mypair._Myval2._Myres; /*0x142260701*/
            v48->allowed = BYTE4(name._Mypair._Myval2._Myres); /*0x142260709*/
            ++allowedVersions->_Mypair._Myval2._Mylast; /*0x14226070d*/
          }
        }
        __unwind
        {
          RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&name); /*0xf1c0000000000060*/
        }
        if ( v51 != nullptr ) /*0x142260730*/
        {
          v52 = v51; /*0x142260735*/
          if ( v50 - (unsigned __int64)v51 >= 0x1000 ) /*0x14226073f*/
          {
            v51 = *((char **)v51 - 1); /*0x142260745*/
            if ( (unsigned __int64)(v52 - v51 - 8) > 0x1F ) /*0x142260754*/
              _invalid_parameter_noinfo_noreturn(); /*0x142260756*/
          }
          operator delete(ptr: v51); /*0x142260760*/
        }
      }
      __unwind
      {
        RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&keyValue); /*0xf1c0000000000084*/
      }
    }
    if ( __eh34_unwind(12) ) /*0xf1c0000000000048*/
    {
unwind_state_12:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key); /*0xf1c000000000004c*/
      __eh34_continue_unwinding(12, 11); /*0xf1c0000000000050*/
    }
    __eh34_exit_wind_state(12, 11); /*0xf1c0000000000054*/
    result->std::tuple<unsigned int,bool>::std::tuple<bool>::_Myfirst._Val = (bool)Bool; /*0x142260766*/
    result->std::tuple<unsigned int,bool>::_Myfirst._Val = v26; /*0x142260769*/
    result->_Myfirst._Val = true; /*0x14226076d*/
    if ( key._Mypair._Myval2._Myres >= 0x10 ) /*0x14226077b*/
    {
      v53 = key._Mypair._Myval2._Bx._Ptr; /*0x142260780*/
      if ( key._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14226078f*/
      {
        v53 = *((char **)key._Mypair._Myval2._Bx._Ptr - 1); /*0x142260795*/
        if ( (unsigned __int64)(key._Mypair._Myval2._Bx._Ptr - v53 - 8) > 0x1F ) /*0x1422607a4*/
          goto LABEL_99; /*0x1422607a4*/
      }
      operator delete(ptr: v53); /*0x1422607ad*/
    }
    key._Mypair._Myval2._Mysize = 0; /*0x1422607b2*/
    key._Mypair._Myval2._Myres = 15; /*0x1422607b7*/
    key._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1422607c0*/
    if ( key64._Mypair._Myval2._Myres >= 0x10 ) /*0x1422607cd*/
    {
      v33 = key64._Mypair._Myval2._Bx._Ptr; /*0x1422607d6*/
      if ( key64._Mypair._Myval2._Myres + 1 < 0x1000 /*0x1422607fd*/
        || (v33 = *((char **)key64._Mypair._Myval2._Bx._Ptr - 1),
            (unsigned __int64)(key64._Mypair._Myval2._Bx._Ptr - v33 - 8) <= 0x1F) )
      {
LABEL_56:
        operator delete(ptr: v33); /*0x142260476*/
        return result; /*0xf1c0000000000144*/
      }
LABEL_104:
      _invalid_parameter_noinfo_noreturn(); /*0x142260803*/
    }
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&key64); /*0xf1c0000000000090*/
  }
  return result; /*0x14226047e*/
}

// Address: 0x142260960 | Name: ?parseVersions@KeyRing@Security@RBX@@AEAA_NAEBVValue@json@3@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@II@Z
char __fastcall RBX::Security::KeyRing::parseVersions(
        RBX::Security::KeyRing *this,
        RBX::json::Value *versions,
        const std::string *applicationName,
        unsigned int sendVersion,
        unsigned int revertVersion)
{
  const std::string *v5; // rdi
  char v8; // r15
  char v9; // bl
  char v10; // si
  char v11; // r13
  RBX::Security::KeyRing::KeyInfo *Myend; // r14
  const RBX::json::ArrayIterator *v13; // rax
  RBX::json::Value *v14; // rax
  const RBX::json::ArrayIterator *v15; // rax
  unsigned __int8 v16; // al
  const char *Ptr; // r8
  const char *v18; // r8
  RBX::Security::KeyRing::KeyInfo *Myfirst; // rsi
  RBX::Security::KeyRing::KeyInfo *Mylast; // rdi
  std::vector<signed char> *v21; // rbx
  RBX::Security::KeyRing::ApplicationInfo *p_second; // rcx
  RBX::Security::KeyRing::KeyInfo *v23; // rax
  RBX::json::ArrayIterator it; // [rsp+30h] [rbp-50h] BYREF
  std::vector<RBX::Security::KeyRing::KeyInfo> allowedVersions; // [rsp+38h] [rbp-48h] BYREF
  RBX::json::ArrayIteratorHelper elements; // [rsp+50h] [rbp-30h] BYREF
  RBX::json::ArrayIterator v27; // [rsp+58h] [rbp-28h] BYREF
  std::pair<std::_List_node<std::pair<std::string const ,RBX::Security::KeyRing::ApplicationInfo>,void *> *,bool> v28; // [rsp+60h] [rbp-20h] BYREF
  std::unique_lock<boost::shared_mutex> lock; // [rsp+70h] [rbp-10h] BYREF

  v5 = applicationName; /*0x142260989*/
  if ( !RBX::json::Value::isArray(this: versions) ) /*0x142260992*/
  {
    if ( DFLog::KeyRing != 0 ) /*0x1422609a4*/
      FLog::FastLogFormatted(level: DFLog::KeyRing, message: "[DFLog::KeyRing] \"Versions\" invalid."); /*0x1422609af*/
    return 0; /*0x1422609b6*/
  }
  v8 = 1; /*0x1422609bb*/
  v9 = 0; /*0x1422609be*/
  v10 = 0; /*0x1422609c0*/
  v11 = 0; /*0x1422609c3*/
  memset(&allowedVersions, 0, sizeof(allowedVersions)); /*0x1422609c9*/
  Myend = nullptr; /*0x1422609ce*/
  __wind
  {
    RBX::json::Value::elements(this: versions, result: &elements); /*0x1422609dc*/
    RBX::json::ArrayIteratorHelper::begin(this: &elements, result: &it); /*0x1422609e9*/
    v13 = RBX::json::ArrayIteratorHelper::end(this: &elements, result: &v27); /*0x1422609f6*/
    if ( !StudioResourceId::operator!=(this: &it, rhs: v13) ) /*0x142260a02*/
      goto LABEL_10; /*0x142260a02*/
    do /*0x142260a80*/
    {
      v14 = (RBX::json::Value *)RBX::json::ArrayIterator::operator*(this: &it, result: (const RBX::json::Value *)&lock); /*0x142260a28*/
      RBX::Security::KeyRing::parseVersion( /*0x142260a44*/
        this,
        result: (std::tuple<bool,unsigned int,bool> *)&v28,
        version: v14,
        &allowedVersions,
        sendVersion,
        revertVersion);
      v9 |= LOBYTE(v28.first); /*0x142260a49*/
      v10 |= HIDWORD(v28.first) == sendVersion; /*0x142260a53*/
      v11 |= HIDWORD(v28.first) == revertVersion; /*0x142260a5c*/
      v8 &= v28.second; /*0x142260a5f*/
      RBX::json::ArrayIterator::operator++(this: &it); /*0x142260a67*/
      v15 = RBX::json::ArrayIteratorHelper::end(this: &elements, result: &v27); /*0x142260a74*/
    }
    while ( StudioResourceId::operator!=(this: &it, rhs: v15) ); /*0x142260a80*/
    v5 = applicationName; /*0x142260a8b*/
    Myend = allowedVersions._Mypair._Myval2._Myend; /*0x142260a8f*/
    if ( v9 != 0 )
    {
      v16 = DFLog::KeyRing; /*0x142260a95*/
    }
    else
    {
LABEL_10:
      v16 = DFLog::KeyRing; /*0x142260a9e*/
      if ( DFLog::KeyRing != 0 )
      {
        Ptr = (const char *)v5; /*0x142260aa9*/
        if ( v5->_Mypair._Myval2._Myres >= 0x10 ) /*0x142260ab1*/
          Ptr = v5->_Mypair._Myval2._Bx._Ptr; /*0x142260ab3*/
        FLog::FastLogFormatted(
          level: DFLog::KeyRing,
          message: "[DFLog::KeyRing] Application has no allowed versions : %s.",
          Ptr);
        v16 = DFLog::KeyRing; /*0x142260ac4*/
      }
      v8 = 0; /*0x142260acb*/
    }
    if ( v10 == 0 )
    {
      if ( v16 != 0 )
      {
        v18 = (const char *)v5; /*0x142260ad7*/
        if ( v5->_Mypair._Myval2._Myres >= 0x10 ) /*0x142260adf*/
          v18 = v5->_Mypair._Myval2._Bx._Ptr; /*0x142260ae1*/
        FLog::FastLogFormatted(
          level: v16,
          message: "[DFLog::KeyRing] Application sendVersion not in versions : %s.",
          v18);
        v16 = DFLog::KeyRing; /*0x142260af3*/
      }
      v8 = 0; /*0x142260afa*/
    }
    if ( v11 != 0 )
    {
      if ( v8 != 0 ) /*0x142260b89*/
      {
        lock._Pmtx = &this->mutex; /*0x142260b93*/
        v27.it = (const rapidjson110::GenericValue<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator> *)0x7FFFFFFFFFFFFFFFLL; /*0x142260ba1*/
        LODWORD(it.it) = -1; /*0x142260ba5*/
        boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>( /*0x142260bb8*/
          this: (boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config> *)&v28,
          d: (const boost::gregorian::date *)&it,
          time_of_day: (const boost::posix_time::time_duration *)&v27);
        boost::shared_mutex::timed_lock(this: &this->mutex, wait_until: (const boost::posix_time::ptime *)&v28); /*0x142260bc4*/
        __wind /*0xf1c0000000000004*/
        {
          lock._Owns = true; /*0x142260bc9*/
          std::_Hash<std::_Umap_traits<std::string,RBX::Security::KeyRing::ApplicationInfo,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Security::KeyRing::ApplicationInfo>>,0>>::_Try_emplace<std::string const &,>( /*0x142260bd8*/
            this: &this->keyMap,
            result: &v28,
            _Keyval_arg: v5);
          p_second = &v28.first->_Myval.second; /*0x142260be1*/
          v28.first->_Myval.second.sendVersion = sendVersion; /*0x142260be5*/
          p_second->revertVersion = revertVersion; /*0x142260bec*/
          if ( p_second == (RBX::Security::KeyRing::ApplicationInfo *)&allowedVersions ) /*0x142260bf6*/
          {
            Mylast = allowedVersions._Mypair._Myval2._Mylast; /*0x142260c1b*/
            Myfirst = allowedVersions._Mypair._Myval2._Myfirst; /*0x142260c1f*/
          }
          else
          {
            Myfirst = p_second->keys._Mypair._Myval2._Myfirst; /*0x142260bf8*/
            p_second->keys._Mypair._Myval2._Myfirst = allowedVersions._Mypair._Myval2._Myfirst; /*0x142260bff*/
            Mylast = p_second->keys._Mypair._Myval2._Mylast; /*0x142260c02*/
            p_second->keys._Mypair._Myval2._Mylast = allowedVersions._Mypair._Myval2._Mylast; /*0x142260c0a*/
            v23 = p_second->keys._Mypair._Myval2._Myend; /*0x142260c0e*/
            p_second->keys._Mypair._Myval2._Myend = Myend; /*0x142260c12*/
            Myend = v23; /*0x142260c16*/
          }
          std::unique_lock<boost::shared_mutex>::~unique_lock<boost::shared_mutex>(this: &lock); /*0x142260c27*/
        }
        __unwind
        {
          std::unique_lock<boost::shared_mutex>::~unique_lock<boost::shared_mutex>(this: &lock); /*0xf1c0000000000014*/
        }
        goto LABEL_43; /*0xf1c0000000000010*/
      }
    }
    else
    {
      if ( v16 != 0 )
      {
        if ( v5->_Mypair._Myval2._Myres >= 0x10 ) /*0x142260b0f*/
          v5 = (const std::string *)v5->_Mypair._Myval2._Bx._Ptr; /*0x142260b11*/
        FLog::FastLogFormatted(
          level: v16,
          message: "[DFLog::KeyRing] Application revertVersion not in versions : %s.",
          v5->_Mypair._Myval2._Bx._Buf);
      }
      v8 = 0; /*0x142260b26*/
    }
    Myfirst = allowedVersions._Mypair._Myval2._Myfirst; /*0x142260b29*/
    Mylast = allowedVersions._Mypair._Myval2._Mylast; /*0x142260b2d*/
  }
  __unwind
  {
    std::vector<RBX::details::Slots<std::vector<unsigned char>>::Slot,std::allocator<RBX::details::Slots<std::vector<unsigned char>>::Slot>>::~vector<RBX::details::Slots<std::vector<unsigned char>>::Slot,std::allocator<RBX::details::Slots<std::vector<unsigned char>>::Slot>>(this: &allowedVersions); /*0xf1c0000000000020*/
  }
LABEL_43:
  if ( Myfirst != nullptr ) /*0x142260b34*/
  {
    v21 = (std::vector<signed char> *)Myfirst; /*0x142260b36*/
    if ( Myfirst != Mylast ) /*0x142260b3c*/
    {
      do /*0x142260b4f*/
      {
        RBX::HuffmanStream::~HuffmanStream(this: v21); /*0x142260b43*/
        v21 = (std::vector<signed char> *)((char *)v21 + 32); /*0x142260b48*/
      }
      while ( v21 != (std::vector<signed char> *)Mylast ); /*0x142260b4f*/
    }
    std::allocator<RBX::Security::KeyRing::KeyInfo>::deallocate( /*0x142260b62*/
      this: (std::allocator<AssetProxyOverrideViewModel::AssetOverride> *)&allowedVersions,
      _Ptr: (AssetProxyOverrideViewModel::AssetOverride *const)Myfirst,
      _Count: Myend - Myfirst);
  }
  return v8; /*0x142260b6b*/
}

// Address: 0x142260cc0 | Name: ?registerCounterFn@KeyRing@Security@RBX@@QEAAXP6AXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@H_N@Z@Z
void __fastcall RBX::Security::KeyRing::registerCounterFn(
        RBX::Security::KeyRing *this,
        void (__fastcall *callback)(const std::string *, int, bool))
{
  this->counterPfn = callback; /*0x142260cc0*/
}

// Address: 0x142260cd0 | Name: ?setJobId@KeyRing@Security@RBX@@QEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RBX::Security::KeyRing::setJobId(RBX::Security::KeyRing *this, const std::string *newJobId)
{
  std::string *p_jobId; // rcx
  unsigned __int64 Mysize; // r8

  p_jobId = &this->jobId; /*0x142260cd0*/
  if ( p_jobId != newJobId ) /*0x142260cd7*/
  {
    Mysize = newJobId->_Mypair._Myval2._Mysize; /*0x142260cde*/
    if ( newJobId->_Mypair._Myval2._Myres >= 0x10 ) /*0x142260ce2*/
      newJobId = (const std::string *)newJobId->_Mypair._Myval2._Bx._Ptr; /*0x142260ce4*/
    std::string::assign(this: p_jobId, _Ptr: newJobId->_Mypair._Myval2._Bx._Buf, _Count: Mysize); /*0x142260ce7*/
  }
}

// END KeyRing part 1/1, 13 functions
