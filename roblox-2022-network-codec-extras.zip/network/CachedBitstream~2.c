// CachedBitstream -- 2022 Studio + full PDB
// tier 3, 3 functions


// Address: 0x14045b530 | Name: ??4?$shared_ptr@UCachedBitstream@Network@RBX@@@std@@QEAAAEAV01@$$QEAV01@@Z
std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *__fastcall std::shared_ptr<RBX::Network::CachedBitstream>::operator=(
        std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *this,
        std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *_Right)
{
  RBX::Graphics::FrameRateManagerStatsStringItem *Ptr; // rax
  std::_Ref_count_base *Rep; // r8
  std::_Ref_count_base *v5; // rbx

  Ptr = _Right->_Ptr; /*0x14045b53a*/
  Rep = _Right->_Rep; /*0x14045b540*/
  _Right->_Ptr = nullptr; /*0x14045b546*/
  _Right->_Rep = nullptr; /*0x14045b549*/
  v5 = this->_Rep; /*0x14045b54d*/
  this->_Ptr = Ptr; /*0x14045b551*/
  this->_Rep = Rep; /*0x14045b554*/
  if ( v5 == nullptr ) /*0x14045b55b*/
    return this; /*0x14045b5a6*/
  if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Uses, 0xFFFFFFFF) == 1 ) /*0x14045b571*/
  {
    v5->_Destroy(this: v5); /*0x14045b579*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v5->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14045b583*/
      v5->_Delete_this(this: v5); /*0x14045b58b*/
  }
  return this; /*0x14045b596*/
}

// Address: 0x141057b10 | Name: ??0CachedBitstream@Network@RBX@@QEAA@W4ReplicationDataCreationMode@12@@Z
RBX::Network::CachedBitstream *__fastcall RBX::Network::CachedBitstream::CachedBitstream(
        RBX::Network::CachedBitstream *this,
        RBX::Network::ReplicationDataCreationMode mode)
{
  RBX::Network::NetworkStream *p_stream; // rcx
  RBX::Network::CachedBitstream *result; // rax

  this->status = Stale; /*0x141057b24*/
  this->mx.active_count = 0; /*0x141057b26*/
  this->mx.event = nullptr; /*0x141057b29*/
  this->mode = mode; /*0x141057b2d*/
  p_stream = &this->stream; /*0x141057b30*/
  __wind /*0xf1c000000000001c*/
  {
    RBX::Network::NetworkStream::NetworkStream(this: p_stream); /*0x141057b34*/
    this->sentSharedStrings._Mypair._Myval2._Myfirst = nullptr; /*0x141057b39*/
    this->sentSharedStrings._Mypair._Myval2._Mylast = nullptr; /*0x141057b3d*/
    this->sentSharedStrings._Mypair._Myval2._Myend = nullptr; /*0x141057b41*/
    result = this; /*0x141057b45*/
  }
  __unwind
  {
    boost::mutex::~mutex(this: &this->mx); /*0x1431e865b*/
  }
  return result; /*0x141057b48*/
}

// Address: 0x1410d9a90 | Name: ??_E?$_Ref_count_obj2@UCachedBitstream@Network@RBX@@@std@@UEAAPEAXI@Z
std::_Ref_count_obj2<RBX::Network::CachedBitstream> *__fastcall std::_Ref_count_obj2<RBX::Network::CachedBitstream>::`vector deleting destructor'(
        std::_Ref_count_obj2<RBX::Network::CachedBitstream> *this,
        char a2)
{
  this->__vftable = (std::_Ref_count_obj2<RBX::Network::CachedBitstream>_vtbl *)std::_Ref_count_obj2<RBX::Network::CachedBitstream>::`vftable'; /*0x1410d9aa0*/
  if ( (a2 & 1) != 0 ) /*0x1410d9aa6*/
    operator delete(ptr: this); /*0x1410d9aad*/
  return this; /*0x1410d9ab5*/
}

// END CachedBitstream part 1/1, 3 functions
