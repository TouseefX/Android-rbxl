// NetworkSchema -- 2022 Studio + full PDB
// tier 3, 10 functions


// Address: 0x141063420 | Name: ?classNetworkIdFromLocalDescriptor@NetworkSchema@Network@RBX@@QEBAPEBGAEBVClassDescriptor@Reflection@3@@Z
const RBX::Reflection::ClassDescriptor **__fastcall RBX::Network::NetworkSchema::classNetworkIdFromLocalDescriptor(
        RBX::Network::NetworkSchema *this,
        const RBX::Reflection::ClassDescriptor *classDesc)
{
  std::pair<RBX::Reflection::ClassDescriptor const *,unsigned short> *Myfirst; // rdi
  std::pair<RBX::Reflection::ClassDescriptor const *,unsigned short> *Mylast; // r8
  const RBX::Reflection::ClassDescriptor *empty_key; // r11
  unsigned __int64 v6; // r8
  unsigned __int64 v7; // rcx
  unsigned __int64 v8; // rdx
  const RBX::Reflection::ClassDescriptor **p_first; // rax
  unsigned __int64 v10; // rcx
  const RBX::Reflection::ClassDescriptor **v11; // rcx

  Myfirst = this->classNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Myfirst; /*0x14106342a*/
  Mylast = this->classNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Mylast; /*0x141063431*/
  if ( Myfirst == Mylast || (empty_key = this->classNetworkIdByLocalDescriptor.impl.empty_key, classDesc == empty_key) ) /*0x141063446*/
  {
LABEL_8:
    p_first = nullptr; /*0x141063498*/
  }
  else
  {
    v6 = Mylast - Myfirst - 1; /*0x141063459*/
    v7 = v6 & ((unsigned __int64)classDesc + ((unsigned __int64)classDesc >> 3)); /*0x14106345c*/
    v8 = 0; /*0x141063462*/
    while ( 1 ) /*0x141063477*/
    {
      p_first = &Myfirst[v7].first; /*0x141063477*/
      if ( *p_first == classDesc ) /*0x141063480*/
        break; /*0x141063480*/
      if ( *p_first != empty_key ) /*0x141063485*/
      {
        v10 = v8 + v7 + 1; /*0x14106348a*/
        ++v8; /*0x14106348d*/
        v7 = v6 & v10; /*0x141063490*/
        if ( v8 <= v6 ) /*0x141063496*/
          continue; /*0x141063496*/
      }
      goto LABEL_8; /*0x141063496*/
    }
  }
  v11 = p_first + 1; /*0x1410634a0*/
  if ( p_first == nullptr ) /*0x1410634ac*/
    return nullptr; /*0x1410634ac*/
  return v11; /*0x1410634b3*/
}

// Address: 0x141067ff0 | Name: ?fixedDictionaryStringFromNetworkId@NetworkSchema@Network@RBX@@QEBAAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@G@Z
const std::string *__fastcall RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId(
        RBX::Network::NetworkSchema *this,
        unsigned __int16 networkId)
{
  unsigned __int64 v3; // rdi
  std::string *Myfirst; // rdx

  v3 = networkId; /*0x141068012*/
  if ( __TSS0__1__fixedDictionaryStringFromNetworkId_NetworkSchema_Network_RBX__QEBAAEBV__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__G_Z_4HA > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x141068023*/
  {
    Init_thread_header(pOnce: &__TSS0__1__fixedDictionaryStringFromNetworkId_NetworkSchema_Network_RBX__QEBAAEBV__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__G_Z_4HA); /*0x14106806d*/
    if ( __TSS0__1__fixedDictionaryStringFromNetworkId_NetworkSchema_Network_RBX__QEBAAEBV__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__G_Z_4HA == -1 ) /*0x141068079*/
    {
      *(__m128i *)&`RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId'::`2'::kEmpty._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14106808a*/
      `RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId'::`2'::kEmpty._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141068092*/
      atexit(function: `RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId'::`2'::`dynamic atexit destructor for 'kEmpty''); /*0x14106809d*/
      Init_thread_footer(pOnce: &__TSS0__1__fixedDictionaryStringFromNetworkId_NetworkSchema_Network_RBX__QEBAAEBV__basic_string_DU__char_traits_D_std__V__allocator_D_2__std__G_Z_4HA); /*0x1410680a9*/
    }
  }
  Myfirst = this->fixedDictionaryStringByNetworkId._Mypair._Myval2._Myfirst; /*0x141068025*/
  if ( v3 >= this->fixedDictionaryStringByNetworkId._Mypair._Myval2._Mylast - Myfirst ) /*0x141068040*/
    return &`RBX::Network::NetworkSchema::fixedDictionaryStringFromNetworkId'::`2'::kEmpty; /*0x141068059*/
  else
    return &Myfirst[v3]; /*0x141068046*/
}

// Address: 0x141096fa0 | Name: ?cframePropertyIdFromLocalClassDescriptor@NetworkSchema@Network@RBX@@QEBAPEBGAEBVClassDescriptor@Reflection@3@@Z
const RBX::Reflection::ClassDescriptor **__fastcall RBX::Network::NetworkSchema::cframePropertyIdFromLocalClassDescriptor(
        RBX::Network::NetworkSchema *this,
        const RBX::Reflection::ClassDescriptor *classDesc)
{
  std::pair<RBX::Reflection::ClassDescriptor const *,unsigned short> *Myfirst; // rdi
  std::pair<RBX::Reflection::ClassDescriptor const *,unsigned short> *Mylast; // r8
  const RBX::Reflection::ClassDescriptor *empty_key; // r11
  unsigned __int64 v6; // r8
  unsigned __int64 v7; // rcx
  unsigned __int64 v8; // rdx
  const RBX::Reflection::ClassDescriptor **p_first; // rax
  unsigned __int64 v10; // rcx
  const RBX::Reflection::ClassDescriptor **v11; // rcx

  Myfirst = this->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Myfirst; /*0x141096faa*/
  Mylast = this->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Mylast; /*0x141096fb1*/
  if ( Myfirst == Mylast /*0x141096fc9*/
    || (empty_key = this->cframePropertyIdByLocalClassDescriptor.impl.empty_key, classDesc == empty_key) )
  {
LABEL_8:
    p_first = nullptr; /*0x141097018*/
  }
  else
  {
    v6 = Mylast - Myfirst - 1; /*0x141096fdc*/
    v7 = v6 & ((unsigned __int64)classDesc + ((unsigned __int64)classDesc >> 3)); /*0x141096fdf*/
    v8 = 0; /*0x141096fe5*/
    while ( 1 ) /*0x141096ff7*/
    {
      p_first = &Myfirst[v7].first; /*0x141096ff7*/
      if ( *p_first == classDesc ) /*0x141097000*/
        break; /*0x141097000*/
      if ( *p_first != empty_key ) /*0x141097005*/
      {
        v10 = v8 + v7 + 1; /*0x14109700a*/
        ++v8; /*0x14109700d*/
        v7 = v6 & v10; /*0x141097010*/
        if ( v8 <= v6 ) /*0x141097016*/
          continue; /*0x141097016*/
      }
      goto LABEL_8; /*0x141097016*/
    }
  }
  v11 = p_first + 1; /*0x141097020*/
  if ( p_first == nullptr ) /*0x14109702c*/
    return nullptr; /*0x14109702c*/
  return v11; /*0x141097033*/
}

// Address: 0x1410d6550 | Name: ??0NetworkSchema@Network@RBX@@QEAA@XZ
RBX::Network::NetworkSchema *__fastcall RBX::Network::NetworkSchema::NetworkSchema(RBX::Network::NetworkSchema *this)
{
  RBX::DenseHashMap<std::string,unsigned short,RBX::Hash<std::string >,std::equal_to<std::string > > *p_networkIdByFixedDictionaryString; // rcx
  void *v3; // rcx
  RBX::Network::NetworkSchema *result; // rax
  _BYTE ptr[40]; // [rsp+20h] [rbp-28h] BYREF

  this->initialized = false; /*0x1410d6563*/
  this->enumTypeByLocalType.impl.data._Mypair._Myval2._Myfirst = nullptr; /*0x1410d6568*/
  this->enumTypeByLocalType.impl.data._Mypair._Myval2._Mylast = nullptr; /*0x1410d656c*/
  this->enumTypeByLocalType.impl.data._Mypair._Myval2._Myend = nullptr; /*0x1410d6570*/
  this->enumTypeByLocalType.impl.count = 0; /*0x1410d6574*/
  this->enumTypeByLocalType.impl.empty_key = nullptr; /*0x1410d6578*/
  this->classNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Myfirst = nullptr; /*0x1410d657c*/
  this->classNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Mylast = nullptr; /*0x1410d6580*/
  this->classNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Myend = nullptr; /*0x1410d6584*/
  this->classNetworkIdByLocalDescriptor.impl.count = 0; /*0x1410d6588*/
  this->classNetworkIdByLocalDescriptor.impl.empty_key = nullptr; /*0x1410d658c*/
  this->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Myfirst = nullptr; /*0x1410d6590*/
  this->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Mylast = nullptr; /*0x1410d6594*/
  this->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Myend = nullptr; /*0x1410d6598*/
  this->cframePropertyIdByLocalClassDescriptor.impl.count = 0; /*0x1410d659c*/
  this->cframePropertyIdByLocalClassDescriptor.impl.empty_key = nullptr; /*0x1410d65a3*/
  this->localEnumTypeByNetworkId._Mypair._Myval2._Myfirst = nullptr; /*0x1410d65aa*/
  this->localEnumTypeByNetworkId._Mypair._Myval2._Mylast = nullptr; /*0x1410d65b1*/
  this->localEnumTypeByNetworkId._Mypair._Myval2._Myend = nullptr; /*0x1410d65b8*/
  this->classInfoByNetworkId._Mypair._Myval2._Myfirst = nullptr; /*0x1410d65bf*/
  this->classInfoByNetworkId._Mypair._Myval2._Mylast = nullptr; /*0x1410d65c6*/
  this->classInfoByNetworkId._Mypair._Myval2._Myend = nullptr; /*0x1410d65cd*/
  this->classPropertyByNetworkId._Mypair._Myval2._Myfirst = nullptr; /*0x1410d65d4*/
  this->classPropertyByNetworkId._Mypair._Myval2._Mylast = nullptr; /*0x1410d65db*/
  this->classPropertyByNetworkId._Mypair._Myval2._Myend = nullptr; /*0x1410d65e2*/
  this->classEventByNetworkId._Mypair._Myval2._Myfirst = nullptr; /*0x1410d65e9*/
  this->classEventByNetworkId._Mypair._Myval2._Mylast = nullptr; /*0x1410d65f0*/
  this->classEventByNetworkId._Mypair._Myval2._Myend = nullptr; /*0x1410d65f7*/
  this->presharedUrlPrefixes._Mypair._Myval2._Myfirst = nullptr; /*0x1410d65fe*/
  this->presharedUrlPrefixes._Mypair._Myval2._Mylast = nullptr; /*0x1410d6605*/
  this->presharedUrlPrefixes._Mypair._Myval2._Myend = nullptr; /*0x1410d660c*/
  p_networkIdByFixedDictionaryString = &this->networkIdByFixedDictionaryString; /*0x1410d6613*/
  *(_QWORD *)ptr = 0; /*0x1410d661a*/
  *(_QWORD *)&ptr[16] = 0; /*0x1410d661e*/
  *(_QWORD *)&ptr[24] = 15; /*0x1410d6622*/
  __wind /*0xf1c00000000000b4*/
  {
    __wind /*0xf1c00000000000bc*/
    {
      __wind /*0xf1c00000000000c4*/
      {
        __wind /*0xf1c00000000000cc*/
        {
          __wind /*0xf1c00000000000d4*/
          {
            __wind /*0xf1c00000000000dc*/
            {
              __wind /*0xf1c00000000000e4*/
              {
                __wind /*0xf1c00000000000ec*/
                {
                  __wind /*0xf1c00000000000f4*/
                  {
                    RBX::detail::DenseHashTable<std::string,std::pair<std::string,unsigned short>,std::pair<std::string const,unsigned short>,RBX::detail::ItemInterfaceMap<std::string,unsigned short>,RBX::Hash<std::string>,std::equal_to<std::string>>::DenseHashTable<std::string,std::pair<std::string,unsigned short>,std::pair<std::string const,unsigned short>,RBX::detail::ItemInterfaceMap<std::string,unsigned short>,RBX::Hash<std::string>,std::equal_to<std::string>>( /*0x1410d6635*/
                      this: &p_networkIdByFixedDictionaryString->impl,
                      empty_key: (const std::string *)ptr,
                      buckets: 0);
                    if ( *(_QWORD *)&ptr[24] >= 0x10u ) /*0x1410d6644*/
                    {
                      v3 = *(void **)ptr; /*0x1410d6649*/
                      if ( (unsigned __int64)(*(_QWORD *)&ptr[24] + 1LL) >= 0x1000 ) /*0x1410d6658*/
                      {
                        v3 = *(void **)(*(_QWORD *)ptr - 8LL); /*0x1410d665e*/
                        if ( (unsigned __int64)(*(_QWORD *)ptr - (_QWORD)v3 - 8LL) > 0x1F ) /*0x1410d666d*/
                          _invalid_parameter_noinfo_noreturn(); /*0x1410d666f*/
                      }
                      operator delete(ptr: v3); /*0x1410d6676*/
                    }
                    this->fixedDictionaryStringByNetworkId._Mypair._Myval2._Myfirst = nullptr; /*0x1410d667b*/
                    this->fixedDictionaryStringByNetworkId._Mypair._Myval2._Mylast = nullptr; /*0x1410d6682*/
                    this->fixedDictionaryStringByNetworkId._Mypair._Myval2._Myend = nullptr; /*0x1410d6689*/
                    result = this; /*0x1410d6690*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)ptr); /*0xf1c000000000004c*/
                  }
                }
                __unwind
                {
                  RBX::ScriptServices::Documentation::ValidateResult::~ValidateResult(this: (std::vector<RBX::MeshId> *)&this->presharedUrlPrefixes); /*0x1431cd36e*/
                }
              }
              __unwind
              {
                std::vector<RBX::Network::NetworkSchema::ClassEvent>::~vector<RBX::Network::NetworkSchema::ClassEvent>(this: &this->classEventByNetworkId); /*0x1431eda6e*/
              }
            }
            __unwind
            {
              std::vector<RBX::Graphics::Shadows::ShadowMapSystemImpl::FrustumUpdateRequest>::~vector<RBX::Graphics::Shadows::ShadowMapSystemImpl::FrustumUpdateRequest>(this: (std::vector<RBX::Collision::ChunkClumpCollectionPair> *)&this->classPropertyByNetworkId); /*0x1431eda4e*/
            }
          }
          __unwind
          {
            std::vector<RBX::Network::NetworkSchema::ClassInfo>::~vector<RBX::Network::NetworkSchema::ClassInfo>(this: &this->classInfoByNetworkId); /*0x1431eda2e*/
          }
        }
        __unwind
        {
          std::vector<Luau::AstExpr *>::~vector<Luau::AstExpr *>(this: (std::vector<RBX::Graphics::FramebufferVulkan *> *)&this->localEnumTypeByNetworkId); /*0x1431d25ae*/
        }
      }
      __unwind
      {
        std::vector<Luau::Location>::~vector<Luau::Location>(this: (RBX::DenseHashMap<RBX::Graphics::ShaderProgram *,VkPipeline_T *,boost::hash<RBX::Graphics::ShaderProgram *>,std::equal_to<RBX::Graphics::ShaderProgram *> > *)&this->cframePropertyIdByLocalClassDescriptor); /*0x14317cfbb*/
      }
    }
    __unwind
    {
      std::vector<Luau::Location>::~vector<Luau::Location>(this: (RBX::DenseHashMap<RBX::Graphics::ShaderProgram *,VkPipeline_T *,boost::hash<RBX::Graphics::ShaderProgram *>,std::equal_to<RBX::Graphics::ShaderProgram *> > *)&this->classNetworkIdByLocalDescriptor); /*0x1431eda1b*/
    }
  }
  __unwind
  {
    std::vector<Luau::AstGenericType>::~vector<Luau::AstGenericType>(this: (std::vector<std::optional<std::pair<Luau::AstName,Luau::Location> >> *)&this->enumTypeByLocalType); /*0x1431eda0b*/
  }
  return result; /*0x1410d6693*/
}

// Address: 0x1410d7cf0 | Name: ??1NetworkSchema@Network@RBX@@QEAA@XZ
void __fastcall RBX::Network::NetworkSchema::~NetworkSchema(RBX::Network::NetworkSchema *this)
{
  const RBX::Reflection::EnumDescriptor **Myfirst; // rcx
  std::pair<RBX::Reflection::ClassDescriptor const *,unsigned short> *v3; // rcx
  std::pair<RBX::Reflection::ClassDescriptor const *,unsigned short> *v4; // rcx
  std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type> *v5; // rcx

  std::vector<RBX::Scripting::DAP::ExceptionOptions>::_Tidy(this: (std::vector<RBX::TextureId> *)&this->fixedDictionaryStringByNetworkId); /*0x1410d7d04*/
  RBX::detail::DenseHashTable<std::string,std::pair<std::string,unsigned short>,std::pair<std::string const,unsigned short>,RBX::detail::ItemInterfaceMap<std::string,unsigned short>,RBX::Hash<std::string>,std::equal_to<std::string>>::~DenseHashTable<std::string,std::pair<std::string,unsigned short>,std::pair<std::string const,unsigned short>,RBX::detail::ItemInterfaceMap<std::string,unsigned short>,RBX::Hash<std::string>,std::equal_to<std::string>>(this: (RBX::detail::DenseHashTable<std::string,std::pair<std::string,RBX::CurveAnimation::HierarchyElement const *>,std::pair<std::string const ,RBX::CurveAnimation::HierarchyElement const *>,RBX::detail::ItemInterfaceMap<std::string,RBX::CurveAnimation::HierarchyElement const *>,RBX::Hash<std::string >,std::equal_to<std::string > > *)&this->networkIdByFixedDictionaryString); /*0x1410d7d10*/
  std::vector<RBX::Scripting::DAP::ExceptionOptions>::_Tidy(this: (std::vector<RBX::TextureId> *)&this->presharedUrlPrefixes); /*0x1410d7d1c*/
  std::vector<RBX::Network::NetworkSchema::ClassEvent>::~vector<RBX::Network::NetworkSchema::ClassEvent>(this: &this->classEventByNetworkId); /*0x1410d7d28*/
  std::vector<RBX::Graphics::Shadows::ShadowMapSystemImpl::FrustumUpdateRequest>::~vector<RBX::Graphics::Shadows::ShadowMapSystemImpl::FrustumUpdateRequest>(this: (std::vector<RBX::Collision::ChunkClumpCollectionPair> *)&this->classPropertyByNetworkId); /*0x1410d7d34*/
  std::vector<RBX::Network::NetworkSchema::ClassInfo>::_Tidy(this: &this->classInfoByNetworkId); /*0x1410d7d40*/
  Myfirst = this->localEnumTypeByNetworkId._Mypair._Myval2._Myfirst; /*0x1410d7d45*/
  if ( Myfirst != nullptr ) /*0x1410d7d51*/
  {
    if ( (((char *)this->localEnumTypeByNetworkId._Mypair._Myval2._Myend - (char *)Myfirst) & 0xFFFFFFFFFFFFFFF8uLL) >= 0x1000 ) /*0x1410d7d68*/
    {
      if ( (unsigned __int64)((char *)Myfirst - (char *)*(Myfirst - 1) - 8) > 0x1F ) /*0x1410d7d7d*/
        goto LABEL_22; /*0x1410d7d7d*/
      Myfirst = (const RBX::Reflection::EnumDescriptor **)*(Myfirst - 1); /*0x1410d7d83*/
    }
    operator delete(ptr: Myfirst); /*0x1410d7d86*/
    this->localEnumTypeByNetworkId._Mypair._Myval2._Myfirst = nullptr; /*0x1410d7d8b*/
    this->localEnumTypeByNetworkId._Mypair._Myval2._Mylast = nullptr; /*0x1410d7d92*/
    this->localEnumTypeByNetworkId._Mypair._Myval2._Myend = nullptr; /*0x1410d7d99*/
  }
  v3 = this->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Myfirst; /*0x1410d7da0*/
  if ( v3 != nullptr ) /*0x1410d7da7*/
  {
    if ( (((char *)this->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Myend - (char *)v3) /*0x1410d7dbb*/
        & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 )
    {
      if ( (unsigned __int64)v3 - *(_QWORD *)&v3[-1].second - 8 > 0x1F ) /*0x1410d7dd0*/
        goto LABEL_22; /*0x1410d7dd0*/
      v3 = *(std::pair<RBX::Reflection::ClassDescriptor const *,unsigned short> **)&v3[-1].second; /*0x1410d7dd6*/
    }
    operator delete(ptr: v3); /*0x1410d7dd9*/
    this->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Myfirst = nullptr; /*0x1410d7dde*/
    this->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Mylast = nullptr; /*0x1410d7de2*/
    this->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Myend = nullptr; /*0x1410d7de6*/
  }
  v4 = this->classNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Myfirst; /*0x1410d7dea*/
  if ( v4 != nullptr ) /*0x1410d7df1*/
  {
    if ( (((char *)this->classNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Myend - (char *)v4) /*0x1410d7e05*/
        & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 )
    {
      if ( (unsigned __int64)v4 - *(_QWORD *)&v4[-1].second - 8 > 0x1F ) /*0x1410d7e1a*/
        goto LABEL_22; /*0x1410d7e1a*/
      v4 = *(std::pair<RBX::Reflection::ClassDescriptor const *,unsigned short> **)&v4[-1].second; /*0x1410d7e1c*/
    }
    operator delete(ptr: v4); /*0x1410d7e1f*/
    this->classNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Myfirst = nullptr; /*0x1410d7e24*/
    this->classNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Mylast = nullptr; /*0x1410d7e28*/
    this->classNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Myend = nullptr; /*0x1410d7e2c*/
  }
  v5 = this->enumTypeByLocalType.impl.data._Mypair._Myval2._Myfirst; /*0x1410d7e30*/
  if ( v5 == nullptr ) /*0x1410d7e37*/
    return; /*0x1410d7e37*/
  if ( (((char *)this->enumTypeByLocalType.impl.data._Mypair._Myval2._Myend - (char *)v5) & 0xFFFFFFFFFFFFFFE0uLL) >= 0x1000 ) /*0x1410d7e4b*/
  {
    if ( (unsigned __int64)v5 - *(_QWORD *)&v5[-1].second.localConformance - 8 <= 0x1F ) /*0x1410d7e60*/
    {
      v5 = *(std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type> **)&v5[-1].second.localConformance; /*0x1410d7e62*/
      goto LABEL_20; /*0x1410d7e62*/
    }
LABEL_22:
    _invalid_parameter_noinfo_noreturn(); /*0x1410d7e81*/
  }
LABEL_20:
  operator delete(ptr: v5); /*0x1410d7e65*/
  this->enumTypeByLocalType.impl.data._Mypair._Myval2._Myfirst = nullptr; /*0x1410d7e6a*/
  this->enumTypeByLocalType.impl.data._Mypair._Myval2._Mylast = nullptr; /*0x1410d7e6e*/
  this->enumTypeByLocalType.impl.data._Mypair._Myval2._Myend = nullptr; /*0x1410d7e72*/
}

// Address: 0x1410de6d0 | Name: ?classPropertyFromNetworkId@NetworkSchema@Network@RBX@@QEBAPEBUClassProperty@123@G@Z
const RBX::Network::NetworkSchema::ClassProperty *__fastcall RBX::Network::NetworkSchema::classPropertyFromNetworkId(
        RBX::Network::NetworkSchema *this,
        unsigned __int16 networkId)
{
  RBX::Network::NetworkSchema::ClassProperty *Myfirst; // r9

  Myfirst = this->classPropertyByNetworkId._Mypair._Myval2._Myfirst; /*0x1410de6d0*/
  if ( networkId >= (unsigned __int64)(this->classPropertyByNetworkId._Mypair._Myval2._Mylast - Myfirst) ) /*0x1410de703*/
    return nullptr; /*0x1410de70e*/
  else
    return &Myfirst[networkId]; /*0x1410de709*/
}

// Address: 0x141110b90 | Name: ?defaultSchemaTypeForReflectionType@NetworkSchema@Network@RBX@@CA?AUType@123@AEBV4Reflection@3@AEBV?$DenseHashMap@PEBVType@Reflection@RBX@@U1NetworkSchema@Network@3@U?$Hash@PEBVType@Reflection@RBX@@@3@U?$equal_to@PEBVType@Reflection@RBX@@@std@@@3@@Z
RBX::Network::NetworkSchema::Type *__fastcall RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType(
        RBX::Network::NetworkSchema::Type *result,
        const RBX::Reflection::Type *reflectionType,
        const RBX::DenseHashMap<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type,RBX::Hash<RBX::Reflection::Type const *>,std::equal_to<RBX::Reflection::Type const *> > *enumTypeByLocalType)
{
  std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type> *Myfirst; // rdi
  std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type> *Mylast; // r9
  const RBX::Reflection::Type *empty_key; // rbx
  unsigned __int64 v7; // r8
  unsigned __int64 v8; // r9
  unsigned __int64 v9; // rax
  const RBX::Reflection::Type **p_first; // rdx
  unsigned __int64 v11; // rax
  const RBX::Reflection::Type **v12; // rax
  __int128 v13; // xmm0
  const RBX::Reflection::Type *v14; // xmm1_8
  __int128 v16; // [rsp+0h] [rbp-20h]
  const RBX::Reflection::Type *result_16; // [rsp+10h] [rbp-10h]

  Myfirst = enumTypeByLocalType->impl.data._Mypair._Myval2._Myfirst; /*0x141110ba7*/
  Mylast = enumTypeByLocalType->impl.data._Mypair._Myval2._Mylast; /*0x141110bac*/
  if ( enumTypeByLocalType->impl.data._Mypair._Myval2._Myfirst == Mylast ) /*0x141110bb6*/
    goto LABEL_7; /*0x141110bb6*/
  empty_key = enumTypeByLocalType->impl.empty_key; /*0x141110bb8*/
  if ( reflectionType == empty_key ) /*0x141110bbf*/
    goto LABEL_7; /*0x141110bbf*/
  v7 = 0; /*0x141110bcb*/
  v8 = Mylast - Myfirst - 1; /*0x141110bd2*/
  v9 = v8 & ((unsigned __int64)reflectionType + ((unsigned __int64)reflectionType >> 3)); /*0x141110bd8*/
  while ( 1 ) /*0x141110be7*/
  {
    p_first = &Myfirst[v9].first; /*0x141110be7*/
    if ( *p_first == reflectionType ) /*0x141110bf0*/
      break; /*0x141110bf0*/
    if ( *p_first != empty_key ) /*0x141110bf5*/
    {
      v11 = v7 + v9 + 1; /*0x141110bfa*/
      ++v7; /*0x141110bfd*/
      v9 = v8 & v11; /*0x141110c00*/
      if ( v7 <= v8 ) /*0x141110c06*/
        continue; /*0x141110c06*/
    }
    goto LABEL_7; /*0x141110c06*/
  }
  v12 = p_first + 1; /*0x141110c45*/
  if ( p_first == nullptr ) /*0x141110c49*/
    v12 = nullptr; /*0x141110c49*/
  if ( v12 == nullptr ) /*0x141110c50*/
  {
LABEL_7:
    LODWORD(result_16) = 0; /*0x141110c0d*/
    WORD1(v16) = -1; /*0x141110c10*/
    switch ( reflectionType->reflectionType ) /*0x141110c40*/
    {
      case ReflectionType_Bool: /*0x141110c40*/
        LOBYTE(v16) = 9; /*0x141110c5f*/
        break; /*0x141110c63*/
      case ReflectionType_Int: /*0x141110c40*/
        LOBYTE(v16) = 10; /*0x141110c68*/
        break; /*0x141110c6c*/
      case ReflectionType_Int64: /*0x141110c40*/
        LOBYTE(v16) = 44; /*0x141110c71*/
        break; /*0x141110c75*/
      case ReflectionType_Float: /*0x141110c40*/
        LOBYTE(v16) = 11; /*0x141110c7a*/
        break; /*0x141110c7e*/
      case ReflectionType_Double: /*0x141110c40*/
        LOBYTE(v16) = 12; /*0x141110c83*/
        break; /*0x141110c87*/
      case ReflectionType_String: /*0x141110c40*/
        LOBYTE(v16) = 2; /*0x141110d5e*/
        break; /*0x141110d62*/
      case ReflectionType_Instance: /*0x141110c40*/
      case ReflectionType_DescribedBase: /*0x141110c40*/
      case ReflectionType_RefType: /*0x141110c40*/
        LOBYTE(v16) = 28; /*0x141110d58*/
        break; /*0x141110d5c*/
      case ReflectionType_Ray: /*0x141110c40*/
        LOBYTE(v16) = 15; /*0x141110c8c*/
        break; /*0x141110c90*/
      case ReflectionType_Vector2: /*0x141110c40*/
        LOBYTE(v16) = 21; /*0x141110c95*/
        break; /*0x141110c99*/
      case ReflectionType_Vector3: /*0x141110c40*/
        LOBYTE(v16) = 22; /*0x141110d64*/
        break; /*0x141110d68*/
      case ReflectionType_Vector2Int16: /*0x141110c40*/
        LOBYTE(v16) = 24; /*0x141110c9e*/
        break; /*0x141110ca2*/
      case ReflectionType_Vector3Int16: /*0x141110c40*/
        LOBYTE(v16) = 25; /*0x141110ca7*/
        break; /*0x141110cab*/
      case ReflectionType_Rect2d: /*0x141110c40*/
        LOBYTE(v16) = 40; /*0x141110cb0*/
        break; /*0x141110cb4*/
      case ReflectionType_CoordinateFrame: /*0x141110c40*/
        LOBYTE(v16) = 27; /*0x141110d6a*/
        break; /*0x141110d6e*/
      case ReflectionType_Color3: /*0x141110c40*/
        LOBYTE(v16) = 19; /*0x141110cb9*/
        break; /*0x141110cbd*/
      case ReflectionType_Color3uint8: /*0x141110c40*/
        LOBYTE(v16) = 20; /*0x141110d4c*/
        break; /*0x141110d50*/
      case ReflectionType_UDim: /*0x141110c40*/
        LOBYTE(v16) = 13; /*0x141110cc2*/
        break; /*0x141110cc6*/
      case ReflectionType_UDim2: /*0x141110c40*/
        LOBYTE(v16) = 14; /*0x141110ccb*/
        break; /*0x141110ccf*/
      case ReflectionType_Faces: /*0x141110c40*/
        LOBYTE(v16) = 16; /*0x141110cd4*/
        break; /*0x141110cd8*/
      case ReflectionType_Axes: /*0x141110c40*/
        LOBYTE(v16) = 17; /*0x141110cdd*/
        break; /*0x141110ce1*/
      case ReflectionType_Region3: /*0x141110c40*/
        LOBYTE(v16) = 42; /*0x141110d76*/
        break; /*0x141110d7a*/
      case ReflectionType_Region3Int16: /*0x141110c40*/
        LOBYTE(v16) = 43; /*0x141110d7c*/
        break; /*0x141110d80*/
      case ReflectionType_PhysicalProperties: /*0x141110c40*/
        LOBYTE(v16) = 41; /*0x141110ce6*/
        break; /*0x141110cea*/
      case ReflectionType_BrickColor: /*0x141110c40*/
        LOBYTE(v16) = 18; /*0x141110cef*/
        break; /*0x141110cf3*/
      case ReflectionType_SystemAddress: /*0x141110c40*/
        LOBYTE(v16) = 34; /*0x141110cf8*/
        break; /*0x141110cfc*/
      case ReflectionType_BinaryString: /*0x141110c40*/
        LOBYTE(v16) = 8; /*0x141110d01*/
        break; /*0x141110d05*/
      case ReflectionType_Tuple: /*0x141110c40*/
        LOBYTE(v16) = 29; /*0x141110d0a*/
        break; /*0x141110d0e*/
      case ReflectionType_ValueArray: /*0x141110c40*/
        LOBYTE(v16) = 30; /*0x141110d13*/
        break; /*0x141110d17*/
      case ReflectionType_ValueTable: /*0x141110c40*/
        LOBYTE(v16) = 31; /*0x141110d1c*/
        break; /*0x141110d20*/
      case ReflectionType_ValueMap: /*0x141110c40*/
        LOBYTE(v16) = 32; /*0x141110d22*/
        break; /*0x141110d26*/
      case ReflectionType_ColorSequence: /*0x141110c40*/
        LOBYTE(v16) = 38; /*0x141110d28*/
        break; /*0x141110d2c*/
      case ReflectionType_ColorSequenceKeypoint: /*0x141110c40*/
        LOBYTE(v16) = 39; /*0x141110d2e*/
        break; /*0x141110d32*/
      case ReflectionType_NumberRange: /*0x141110c40*/
        LOBYTE(v16) = 37; /*0x141110d34*/
        break; /*0x141110d38*/
      case ReflectionType_NumberSequence: /*0x141110c40*/
        LOBYTE(v16) = 35; /*0x141110d3a*/
        break; /*0x141110d3e*/
      case ReflectionType_NumberSequenceKeypoint: /*0x141110c40*/
        LOBYTE(v16) = 36; /*0x141110d40*/
        break; /*0x141110d44*/
      case ReflectionType_ContentId: /*0x141110c40*/
        LOBYTE(v16) = 33; /*0x141110d46*/
        break; /*0x141110d4a*/
      case ReflectionType_PathWaypoint: /*0x141110c40*/
        LOBYTE(v16) = 53; /*0x141110d52*/
        break; /*0x141110d56*/
      case ReflectionType_SharedString: /*0x141110c40*/
        LOBYTE(v16) = 46; /*0x141110d82*/
        break; /*0x141110d86*/
      case ReflectionType_DateTime: /*0x141110c40*/
        LOBYTE(v16) = 48; /*0x141110d88*/
        break; /*0x141110d8c*/
      case ReflectionType_OptionalCoordinateFrame: /*0x141110c40*/
        LOBYTE(v16) = 51; /*0x141110d70*/
        break; /*0x141110d74*/
      case ReflectionType_UniqueId: /*0x141110c40*/
        LOBYTE(v16) = 52; /*0x141110d8e*/
        break; /*0x141110d92*/
      case ReflectionType_Font: /*0x141110c40*/
        LOBYTE(v16) = 54; /*0x141110d94*/
        break; /*0x141110d98*/
      default:
        LOBYTE(v16) = 0; /*0x141110d9a*/
        break; /*0x141110d9a*/
    }
    v13 = v16; /*0x141110d9e*/
    v14 = result_16; /*0x141110da2*/
  }
  else
  {
    v13 = *(_OWORD *)v12; /*0x141110c52*/
    v14 = v12[2]; /*0x141110c55*/
  }
  *(_OWORD *)&result->valueFormat = v13; /*0x141110db9*/
  *(_QWORD *)&result->localConformance = v14; /*0x141110dbc*/
  return result; /*0x141110da7*/
}

// Address: 0x141110ec0 | Name: ?generateSchemaDefinitionPacket@NetworkSchema@Network@RBX@@SAXW4ReplicationMode@23@PEAUServerSchemaInfo@23@@Z
void __fastcall RBX::Network::NetworkSchema::generateSchemaDefinitionPacket(
        RBX::Network::ReplicationMode replicationMode,
        RBX::Network::ServerSchemaInfo *out)
{
  unsigned __int64 count; // rsi
  const RBX::Reflection::Type *empty_key; // r14
  RBX::Reflection::EventDescriptor *v4; // r13
  unsigned __int16 v5; // r12
  std::_Vector_const_iterator<std::_Vector_val<std::_Simple_types<RBX::Reflection::EnumDescriptor const *> > > *v6; // rax
  const RBX::Reflection::EnumDescriptor **Ptr; // rcx
  std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type> *Mylast; // r15
  std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type> *Myfirst; // rdx
  const RBX::Reflection::EnumDescriptor *v10; // rdi
  unsigned __int64 v11; // r8
  __int64 v12; // rax
  unsigned __int64 v13; // rcx
  std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type> *v14; // rbx
  unsigned __int16 v15; // ax
  std::_Vector_const_iterator<std::_Vector_val<std::_Simple_types<RBX::Reflection::EnumDescriptor const *> > > *v16; // rax
  RBX::Reflection::ClassDescriptor *v17; // rdi
  const RBX::ICreator *Creator; // rax
  RBX::Network::NetworkSchema::generateSchemaDefinitionPacket::__l2::TmpClassInfo *v19; // r14
  __int64 v20; // rsi
  char *v21; // rdi
  __int64 v22; // rax
  char *v23; // rcx
  RBX::Network::NetworkSchema::generateSchemaDefinitionPacket::__l2::TmpClassInfo *v24; // r14
  RBX::Network::NetworkSchema::generateSchemaDefinitionPacket::__l2::TmpClassInfo *v25; // r15
  unsigned __int64 v26; // rdx
  char *v27; // rax
  __int64 v28; // rsi
  char *v29; // rax
  RBX::Reflection::ClassDescriptor **i; // rbx
  unsigned int v31; // r13d
  RBX::Network::NetworkSchema::generateSchemaDefinitionPacket::__l2::TmpClassInfo *v32; // r14
  RBX::Network::NetworkSchema::generateSchemaDefinitionPacket::__l2::TmpClassInfo *v33; // rsi
  const RBX::Reflection::PropertyDescriptor ***p_Mylast; // r14
  RBX::Reflection::EventDescriptor *v35; // r15
  RBX::Reflection::PropDescriptor<RBX::Instance,RBX::UniqueId> **category; // rbx
  RBX::Reflection::PropDescriptor<RBX::Instance,RBX::UniqueId> **owner; // rsi
  bool v38; // r15
  RBX::Reflection::PropDescriptor<RBX::Instance,RBX::UniqueId> *v39; // rdi
  RBX::Graphics::FramebufferVulkan **v40; // rdx
  const RBX::Reflection::EnumDescriptor **v41; // rbx
  RBX::Reflection::EventDescriptor *v42; // r13
  bool v43; // si
  RBX::Reflection::SignatureDescriptor::Argument *v44; // r15
  RBX::Reflection::SignatureDescriptor::Argument *v45; // rdi
  RBX::Graphics::FramebufferVulkan **v46; // rdx
  unsigned int v47; // r12d
  __int64 v48; // r8
  RBX::Network::NetworkSchema::generateSchemaDefinitionPacket::__l2::TmpClassInfo *j; // rcx
  const RBX::Reflection::EventDescriptor ***v50; // r15
  RBX::Network::ReplicationMode v51; // r13d
  __int16 v52; // r14
  RBX::Reflection::PropDescriptor<RBX::Instance,std::string > **v53; // rsi
  RBX::Reflection::PropDescriptor<RBX::Instance,std::string > **v54; // r12
  const void *v55; // r8
  char v56; // di
  RBX::Reflection::PropDescriptor<RBX::Instance,std::string > *v57; // rdx
  RBX::Reflection::ClassDescriptor *v58; // rbx
  const RBX::Reflection::Type *type; // r9
  RBX::Network::NetworkSchema::Type *v60; // rax
  __int128 v61; // xmm0
  std::string *v62; // xmm1_8
  const RBX::Reflection::ClassDescriptor *v63; // rax
  bool v64; // al
  RBX::Network::NetworkValueFormat v65; // cl
  char v66; // bl
  RBX::Network::ServerSchemaInfo *v67; // rbx
  const RBX::Reflection::ClassDescriptor **v68; // r9
  const RBX::Reflection::ClassDescriptor **v69; // r11
  unsigned __int64 v70; // r9
  const RBX::Reflection::ClassDescriptor *v71; // r10
  __int64 v72; // rax
  __int64 v73; // rcx
  const RBX::Reflection::ClassDescriptor **v74; // r8
  __int16 v75; // ax
  const RBX::Reflection::EventDescriptor **v76; // r14
  const RBX::Reflection::EventDescriptor **v77; // rdi
  const RBX::Reflection::EventDescriptor *v78; // rbx
  RBX::Reflection::SignatureDescriptor::Argument *v79; // rsi
  RBX::Reflection::SignatureDescriptor::Argument *k; // rbx
  std::string *v81; // rdi
  std::string *m; // rbx
  std::string *v83; // rdi
  std::string *v84; // rbx
  unsigned __int64 Myres; // rdx
  char *v86; // rcx
  std::string *v87; // rax
  RBX::Network::NetworkStream **p_Ptr; // rbx
  RBX::Network::NetworkSchema::generateSchemaDefinitionPacket::__l2::TmpClassInfo *n; // rbx
  RBX::Network::NetworkSchema::generateSchemaDefinitionPacket::__l2::TmpClassInfo *v90; // rax
  std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type> *v91; // rcx
  unsigned __int8 *v92; // rcx
  const char *v93; // r8
  std::vector<std::string> fixedDictionaryList; // [rsp+20h] [rbp-E0h] BYREF
  std::_Vector_const_iterator<std::_Vector_val<std::_Simple_types<RBX::Reflection::EnumDescriptor const *> > > enumItr; // [rsp+38h] [rbp-C8h] BYREF
  RBX::Network::NetworkSchema::Type v96; // [rsp+40h] [rbp-C0h] BYREF
  unsigned __int8 inOutByteArray[4]; // [rsp+58h] [rbp-A8h] BYREF
  unsigned __int8 inByteArray[4]; // [rsp+5Ch] [rbp-A4h] BYREF
  unsigned __int8 v99[8]; // [rsp+60h] [rbp-A0h] BYREF
  RBX::Reflection::EventDescriptor *eventPtr; // [rsp+68h] [rbp-98h] BYREF
  std::vector<`RBX::Network::NetworkSchema::generateSchemaDefinitionPacket'::`2'::TmpClassInfo> tmpClassInfos; // [rsp+70h] [rbp-90h] BYREF
  std::_Vector_const_iterator<std::_Vector_val<std::_Simple_types<RBX::Reflection::EnumDescriptor const *> > > result; // [rsp+88h] [rbp-78h] BYREF
  RBX::DenseHashMap<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type,RBX::Hash<RBX::Reflection::Type const *>,std::equal_to<RBX::Reflection::Type const *> > enumTypeToNetworkType; // [rsp+90h] [rbp-70h] BYREF
  RBX::Network::NetworkStream uncompressedStream; // [rsp+C0h] [rbp-40h] BYREF
  std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type> *Myend; // [rsp+100h] [rbp+0h]
  const RBX::Reflection::ClassDescriptor *v106; // [rsp+108h] [rbp+8h] BYREF
  __int128 v107; // [rsp+110h] [rbp+10h]
  _QWORD v108[4]; // [rsp+120h] [rbp+20h] BYREF
  RBX::Network::ReplicationMode v109; // [rsp+190h] [rbp+90h] BYREF
  RBX::Network::ServerSchemaInfo *v110; // [rsp+198h] [rbp+98h]
  RBX::Reflection::PropertyDescriptor *propertyPtr; // [rsp+1A0h] [rbp+A0h] BYREF
  __int16 v112; // [rsp+1A8h] [rbp+A8h]

  v110 = out; /*0x141110ec0*/
  v109 = replicationMode; /*0x141110ec5*/
  LOBYTE(v112) = replicationMode == ReplicationMode_StudioAsEditor; /*0x141110ee4*/
  RBX::Network::NetworkStream::NetworkStream( /*0x141110ef5*/
    this: &uncompressedStream,
    initialBytesToAllocate: DFInt::SchemaNetworkStreamSize);
  __wind /*0xf1c0000000000064*/
  {
    __wind /*0xf1c000000000006c*/
    {
      memset(&enumTypeToNetworkType, 0, 40); /*0x141110efe*/
      Myend = nullptr; /*0x141110f07*/
      count = 0; /*0x141110f0f*/
      empty_key = nullptr; /*0x141110f15*/
      v4 = (RBX::Reflection::EventDescriptor *)RBX::Reflection::EnumDescriptor::allEnumSize(); /*0x141110f21*/
      eventPtr = v4; /*0x141110f24*/
      RBX::Network::serializeUnsignedVarint(value: (unsigned int)v4, stream: &uncompressedStream); /*0x141110f2f*/
      v5 = 0; /*0x141110f34*/
      RBX::Reflection::EnumDescriptor::enumsBegin(result: &enumItr); /*0x141110f3d*/
      v6 = RBX::Reflection::EnumDescriptor::enumsEnd(&result); /*0x141110f46*/
      Ptr = enumItr._Ptr; /*0x141110f4b*/
      if ( enumItr._Ptr != v6->_Ptr ) /*0x141110f53*/
      {
        Mylast = enumTypeToNetworkType.impl.data._Mypair._Myval2._Mylast; /*0x141110f59*/
        Myfirst = enumTypeToNetworkType.impl.data._Mypair._Myval2._Myfirst; /*0x141110f5d*/
        do /*0x141111062*/
        {
          v10 = *Ptr; /*0x141110f70*/
          if ( count >= (unsigned __int64)(3 * (Mylast - Myfirst)) >> 2 ) /*0x141110f88*/
          {
            RBX::detail::DenseHashTable<RBX::Reflection::Type const *,std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type>,std::pair<RBX::Reflection::Type const * const,RBX::Network::NetworkSchema::Type>,RBX::detail::ItemInterfaceMap<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type>,RBX::Hash<RBX::Reflection::Type const *>,std::equal_to<RBX::Reflection::Type const *>>::rehash(this: &enumTypeToNetworkType.impl); /*0x141110f8e*/
            empty_key = enumTypeToNetworkType.impl.empty_key; /*0x141110f93*/
            count = enumTypeToNetworkType.impl.count; /*0x141110f97*/
            Mylast = enumTypeToNetworkType.impl.data._Mypair._Myval2._Mylast; /*0x141110f9b*/
            Myfirst = enumTypeToNetworkType.impl.data._Mypair._Myval2._Myfirst; /*0x141110f9f*/
          }
          v11 = Mylast - Myfirst - 1; /*0x141110fad*/
          v12 = v11 & ((unsigned __int64)v10 + ((unsigned __int64)v10 >> 3)); /*0x141110fba*/
          v13 = 0; /*0x141110fbd*/
          while ( 1 ) /*0x141110fc7*/
          {
            v14 = &Myfirst[v12]; /*0x141110fc7*/
            if ( v14->first == empty_key ) /*0x141110fd0*/
              break; /*0x141110fd0*/
            if ( v14->first == v10 ) /*0x141110fd5*/
              goto LABEL_12; /*0x141110fd5*/
            v12 = v11 & (v13 + v12 + 1); /*0x141110fdd*/
            ++v13; /*0x141110fe0*/
            Myfirst = enumTypeToNetworkType.impl.data._Mypair._Myval2._Myfirst; /*0x141110fe6*/
            if ( v13 > v11 ) /*0x141110fea*/
            {
              v14 = nullptr; /*0x141110fec*/
              goto LABEL_12; /*0x141110fef*/
            }
          }
          v14->first = v10; /*0x141110ff1*/
          enumTypeToNetworkType.impl.count = ++count; /*0x141110ff7*/
LABEL_12:
          v15 = v5++; /*0x141110ffb*/
          v14->second.enumId = v15; /*0x141111003*/
          v14->second.valueFormat = NetworkValueFormat_Enum_VarInt; /*0x141111007*/
          RBX::Network::serializeString( /*0x141111022*/
            value: &(*enumItr._Ptr)->name->str,
            stream: &uncompressedStream,
            maxStringWriteSize: DFInt::MaxDataPayloadSize);
          LOBYTE(propertyPtr) = v14->second.valueFormat; /*0x14111102b*/
          RBX::Network::NetworkStream::writeBytes( /*0x141111042*/
            this: &uncompressedStream,
            inByteArray: &propertyPtr,
            numberOfBytesToWrite: 1u);
          ++enumItr._Ptr; /*0x141111047*/
          v16 = RBX::Reflection::EnumDescriptor::enumsEnd(&result); /*0x141111051*/
          Ptr = enumItr._Ptr; /*0x141111056*/
          Myfirst = enumTypeToNetworkType.impl.data._Mypair._Myval2._Myfirst; /*0x14111105e*/
        }
        while ( enumItr._Ptr != v16->_Ptr ); /*0x141111062*/
        Myend = enumTypeToNetworkType.impl.data._Mypair._Myval2._Myend; /*0x14111106c*/
        LODWORD(v4) = (_DWORD)eventPtr; /*0x141111070*/
      }
      if ( (unsigned int)v4 > 0xFFFE ) /*0x14111107c*/
      {
        RBX::runtime_error( /*0x141111af5*/
          result: (std::runtime_error *)&tmpClassInfos,
          fmt: "Cannot construct schema, too many enum types");
        throw (std::runtime_error *)&tmpClassInfos; /*0x141111b06*/
      }
      __wind /*0xf1c0000000000040*/
      {
        memset(&tmpClassInfos, 0, sizeof(tmpClassInfos)); /*0x141111085*/
        v47 = 0; /*0x14111108b*/
        v25 = nullptr; /*0x14111108e*/
        enumItr._Ptr = nullptr; /*0x141111091*/
        for ( i = RBX::Reflection::ClassDescriptor::allClasses()->_Mypair._Myval2._Myfirst; /*0x14111109f*/
              i != RBX::Reflection::ClassDescriptor::allClasses()->_Mypair._Myval2._Mylast;
              ++i )
        {
          v17 = *i; /*0x1411110b1*/
          Creator = RBX::Creatable<RBX::Instance>::getCreator(name: (*i)->name); /*0x1411110b8*/
          if ( Creator != nullptr && (*((_BYTE *)v17 + 884) & 6) != 0 || (*((_DWORD *)v17 + 221) & 0x20) != 0 ) /*0x1411110d6*/
          {
            v106 = nullptr; /*0x1411110df*/
            v107 = 0; /*0x1411110eb*/
            memset(v108, 0, sizeof(v108)); /*0x1411110f3*/
            __wind /*0xf1c0000000000034*/
            {
              v19 = tmpClassInfos._Mypair._Myval2._Mylast; /*0x1411110fd*/
              if ( tmpClassInfos._Mypair._Myval2._Mylast == v25 ) /*0x141111105*/
              {
                std::vector__RBX::Network::NetworkSchema::generateSchemaDefinitionPacket_::_2_::TmpClassInfo_std::allocator__RBX::Network::NetworkSchema::generateSchemaDefinitionPacket_::_2_::TmpClassInfo___::_Emplace_reallocate__RBX::Network::NetworkSchema::generateSchemaDefinitionPacket_::_2_::TmpClassInfo_( /*0x141111151*/
                  _Whereptr: (RBX::Network::NetworkSchema::generateSchemaDefinitionPacket::__l2::TmpClassInfo *const)&tmpClassInfos,
                  <_Val_0>: tmpClassInfos._Mypair._Myval2._Mylast);
                v25 = tmpClassInfos._Mypair._Myval2._Myend; /*0x141111156*/
                enumItr._Ptr = (const RBX::Reflection::EnumDescriptor **)tmpClassInfos._Mypair._Myval2._Myend; /*0x14111115a*/
                v22 = v108[3]; /*0x14111115f*/
                v23 = (char *)v108[1]; /*0x141111163*/
                v20 = v108[0]; /*0x141111167*/
                v21 = (char *)v107; /*0x14111116b*/
                v24 = tmpClassInfos._Mypair._Myval2._Mylast; /*0x14111116f*/
              }
              else
              {
                tmpClassInfos._Mypair._Myval2._Mylast->classDescriptor = v106; /*0x14111110b*/
                v20 = 0; /*0x14111110e*/
                *((_QWORD *)&v107 + 1) = 0; /*0x141111111*/
                v21 = nullptr; /*0x141111115*/
                v19->properties._Mypair._Myval2._Myfirst = nullptr; /*0x141111118*/
                v19->properties._Mypair._Myval2._Mylast = nullptr; /*0x14111111c*/
                v19->properties._Mypair._Myval2._Myend = nullptr; /*0x141111120*/
                v22 = 0; /*0x141111124*/
                v108[2] = 0; /*0x141111127*/
                v23 = nullptr; /*0x14111112b*/
                v19->events._Mypair._Myval2._Myfirst = nullptr; /*0x14111112e*/
                v19->events._Mypair._Myval2._Mylast = nullptr; /*0x141111132*/
                v19->events._Mypair._Myval2._Myend = nullptr; /*0x141111136*/
                v24 = v19 + 1; /*0x14111113a*/
                tmpClassInfos._Mypair._Myval2._Mylast = v24; /*0x14111113e*/
              }
            }
            __unwind
            {
              RBX::Network::NetworkSchema::generateSchemaDefinitionPacket_::_2_::TmpClassInfo::_TmpClassInfo(a1: &v106); /*0xf1c000000000002c*/
            }
            if ( v23 != nullptr ) /*0x141111177*/
            {
              v26 = 8 * ((v22 - (__int64)v23) >> 3); /*0x141111180*/
              v27 = v23; /*0x141111188*/
              if ( v26 >= 0x1000 ) /*0x141111192*/
              {
                v23 = *((char **)v23 - 1); /*0x141111198*/
                if ( (unsigned __int64)(v27 - v23 - 8) > 0x1F ) /*0x1411111a7*/
LABEL_34:
                  _invalid_parameter_noinfo_noreturn(); /*0x141111213*/
              }
              operator delete(ptr: v23); /*0x1411111a9*/
              memset(&v108[1], 0, 24); /*0x1411111b1*/
            }
            if ( v21 != nullptr ) /*0x1411111bd*/
            {
              v28 = (v20 - (__int64)v21) >> 3; /*0x1411111c2*/
              v29 = v21; /*0x1411111ce*/
              if ( (unsigned __int64)(8 * v28) >= 0x1000 ) /*0x1411111d8*/
              {
                v21 = *((char **)v21 - 1); /*0x1411111de*/
                if ( (unsigned __int64)(v29 - v21 - 8) > 0x1F ) /*0x1411111ed*/
                  goto LABEL_34; /*0x1411111ed*/
              }
              operator delete(ptr: v21); /*0x1411111f2*/
              v107 = 0; /*0x1411111fa*/
              v108[0] = 0; /*0x1411111ff*/
            }
            v24[-1].classDescriptor = *i; /*0x141111206*/
          }
        }
        v31 = 0; /*0x14111121a*/
        LODWORD(propertyPtr) = 0; /*0x14111121d*/
        v32 = tmpClassInfos._Mypair._Myval2._Myfirst; /*0x141111224*/
        v33 = tmpClassInfos._Mypair._Myval2._Mylast; /*0x141111229*/
        if ( tmpClassInfos._Mypair._Myval2._Myfirst != tmpClassInfos._Mypair._Myval2._Mylast ) /*0x141111231*/
        {
          p_Mylast = &tmpClassInfos._Mypair._Myval2._Myfirst->properties._Mypair._Myval2._Mylast; /*0x141111237*/
          do /*0x14111136e*/
          {
            v35 = (RBX::Reflection::EventDescriptor *)*(p_Mylast - 2); /*0x141111240*/
            eventPtr = v35; /*0x141111244*/
            category = (RBX::Reflection::PropDescriptor<RBX::Instance,RBX::UniqueId> **)v35->category; /*0x141111249*/
            owner = (RBX::Reflection::PropDescriptor<RBX::Instance,RBX::UniqueId> **)v35->owner; /*0x14111124d*/
            if ( category != owner ) /*0x141111254*/
            {
              v38 = v112; /*0x141111256*/
              do /*0x1411112a6*/
              {
                v39 = *category; /*0x141111260*/
                propertyPtr = v39; /*0x141111263*/
                if ( RBX::Network::Replicator::canReplicateProperty(isCloudEdit: v38, descriptor: v39) ) /*0x141111271*/
                {
                  v40 = (RBX::Graphics::FramebufferVulkan **)*p_Mylast; /*0x14111127a*/
                  if ( *p_Mylast == p_Mylast[1] ) /*0x141111281*/
                  {
                    std::vector<Luau::TypeVar *>::_Emplace_reallocate<Luau::TypeVar *>( /*0x141111297*/
                      this: (std::vector<RBX::Graphics::FramebufferVulkan *> *)(p_Mylast - 1),
                      _Whereptr: v40,
                      <_Val_0>: (RBX::Graphics::FramebufferVulkan **)&propertyPtr);
                  }
                  else
                  {
                    *v40 = (RBX::Graphics::FramebufferVulkan *)v39; /*0x141111283*/
                    ++*p_Mylast; /*0x141111286*/
                  }
                  ++v31; /*0x14111129c*/
                }
                ++category; /*0x14111129f*/
              }
              while ( category != owner ); /*0x1411112a6*/
              LODWORD(propertyPtr) = v31; /*0x1411112a8*/
              v35 = eventPtr; /*0x1411112af*/
            }
            v41 = (const RBX::Reflection::EnumDescriptor **)v35[1].signature.results._Mypair._Myval2._Mylast; /*0x1411112b4*/
            result._Ptr = (const RBX::Reflection::EnumDescriptor **)v35[1].signature.results._Mypair._Myval2._Myend; /*0x1411112c2*/
            if ( v41 != result._Ptr ) /*0x1411112c9*/
            {
              do /*0x141111351*/
              {
                v42 = (RBX::Reflection::EventDescriptor *)*v41; /*0x1411112d0*/
                eventPtr = v42; /*0x1411112d3*/
                v43 = true; /*0x1411112d8*/
                v44 = v42->signature.arguments._Mypair._Myval2._Mylast; /*0x1411112db*/
                v45 = v42->signature.arguments._Mypair._Myval2._Myfirst; /*0x1411112df*/
                if ( v45 == v44 ) /*0x1411112e6*/
                  goto LABEL_54; /*0x1411112e6*/
                do /*0x14111131d*/
                {
                  RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType( /*0x1411112fd*/
                    result: (RBX::Network::NetworkSchema::Type *)&fixedDictionaryList,
                    reflectionType: v45->type,
                    enumTypeByLocalType: &enumTypeToNetworkType);
                  v43 = v43 && LOBYTE(fixedDictionaryList._Mypair._Myval2._Myfirst) != 0; /*0x14111130e*/
                  ++v45; /*0x141111316*/
                }
                while ( v45 != v44 ); /*0x14111131d*/
                if ( v43 ) /*0x141111322*/
                {
LABEL_54:
                  v46 = (RBX::Graphics::FramebufferVulkan **)p_Mylast[3]; /*0x141111324*/
                  if ( v46 == (RBX::Graphics::FramebufferVulkan **)p_Mylast[4] ) /*0x14111132c*/
                  {
                    std::vector<Luau::TypeVar *>::_Emplace_reallocate<Luau::TypeVar *>( /*0x141111341*/
                      this: (std::vector<RBX::Graphics::FramebufferVulkan *> *)(p_Mylast + 2),
                      _Whereptr: v46,
                      <_Val_0>: (RBX::Graphics::FramebufferVulkan **)&eventPtr);
                  }
                  else
                  {
                    *v46 = (RBX::Graphics::FramebufferVulkan *)v42; /*0x14111132e*/
                    ++p_Mylast[3]; /*0x141111331*/
                  }
                  ++v47; /*0x141111346*/
                }
                ++v41; /*0x141111349*/
              }
              while ( v41 != result._Ptr ); /*0x141111351*/
              v31 = (unsigned int)propertyPtr; /*0x141111357*/
            }
            p_Mylast += 7; /*0x14111135e*/
            v33 = tmpClassInfos._Mypair._Myval2._Mylast; /*0x141111366*/
          }
          while ( p_Mylast - 2 != (const RBX::Reflection::PropertyDescriptor ***)tmpClassInfos._Mypair._Myval2._Mylast ); /*0x14111136e*/
          v32 = tmpClassInfos._Mypair._Myval2._Myfirst; /*0x141111374*/
        }
        v112 = 0; /*0x14111137c*/
        v48 = v33 - v32; /*0x1411113a5*/
        if ( (unsigned int)v48 > 0xFFFE || v31 > 0xFFFE || v47 > 0xFFFE ) /*0x1411113c9*/
        {
          RBX::runtime_error( /*0x141111ad2*/
            result: (std::runtime_error *)&fixedDictionaryList,
            fmt: "Cannot construct schema, too many classes, properties, or events");
          throw (std::runtime_error *)&fixedDictionaryList; /*0x141111ae3*/
        }
        for ( j = v32; j != v33; ++j ) /*0x1411113d5*/
        {
          if ( (unsigned __int64)(j->properties._Mypair._Myval2._Mylast - j->properties._Mypair._Myval2._Myfirst) > 0xFF ) /*0x1411113f2*/
          {
            v93 = std::string::c_str(this: (RBX::ContentId *)j->classDescriptor->name); /*0x141111aa0*/
            RBX::runtime_error( /*0x141111aaf*/
              result: (std::runtime_error *)&fixedDictionaryList,
              fmt: "Cannot construct schema, too many properties for %s",
              v93);
            throw (std::runtime_error *)&fixedDictionaryList; /*0x141111ac0*/
          }
        }
        RBX::Network::serializeUnsignedVarint(value: v48, stream: &uncompressedStream); /*0x141111408*/
        RBX::Network::serializeUnsignedVarint(value: v31, stream: &uncompressedStream); /*0x141111414*/
        RBX::Network::serializeUnsignedVarint(value: v47, stream: &uncompressedStream); /*0x141111420*/
        if ( v32 != v33 ) /*0x141111428*/
        {
          v50 = &v32->events._Mypair._Myval2._Mylast; /*0x14111142e*/
          v51 = v109; /*0x141111437*/
          do /*0x1411117fc*/
          {
            RBX::Network::serializeString( /*0x141111453*/
              value: (const std::string *)(*(v50 - 5))[1],
              stream: &uncompressedStream,
              maxStringWriteSize: DFInt::MaxDataPayloadSize);
            RBX::Network::serializeUnsignedVarint(value: *(v50 - 3) - *(v50 - 4), stream: &uncompressedStream); /*0x141111468*/
            v52 = -1; /*0x14111146d*/
            v53 = (RBX::Reflection::PropDescriptor<RBX::Instance,std::string > **)*(v50 - 4); /*0x141111471*/
            v54 = (RBX::Reflection::PropDescriptor<RBX::Instance,std::string > **)*(v50 - 3); /*0x141111475*/
            if ( v53 != v54 ) /*0x14111147c*/
            {
              while ( 1 ) /*0x141111494*/
              {
                RBX::Network::serializeString( /*0x141111494*/
                  value: &(*v53)->name->str,
                  stream: &uncompressedStream,
                  maxStringWriteSize: DFInt::MaxDataPayloadSize);
                v56 = 0; /*0x141111499*/
                v57 = *v53; /*0x14111149c*/
                v58 = (RBX::Reflection::ClassDescriptor *)*(v50 - 5); /*0x14111149f*/
                type = (*v53)->type; /*0x1411114a3*/
                v96.enumId = -1; /*0x1411114ac*/
                switch ( type->reflectionType ) /*0x1411114b8*/
                {
                  case ReflectionType_String: /*0x1411114b8*/
                    v96.valueFormat = NetworkValueFormat_String_FixedDictionary; /*0x14111156d*/
                    if ( v57 != &RBX::Instance::desc_Name ) /*0x141111572*/
                      v96.valueFormat = NetworkValueFormat_String_NeverDictionary; /*0x141111574*/
                    goto LABEL_90; /*0x141111574*/
                  case ReflectionType_ProtectedString: /*0x1411114b8*/
                    v56 = 1; /*0x141111515*/
                    if ( v51 == ReplicationMode_StudioAsEditor /*0x14111151e*/
                      || !RBX::Reflection::PropDescriptor<RBX::Accoutrement,RBX::CoordinateFrame>::GetSetImpl<RBX::CoordinateFrame const & (RBX::Accoutrement::*)(void)const,void (RBX::Accoutrement::*)(RBX::CoordinateFrame const &)>::isReadOnly(
                            this: (RBX::Graphics::BufferVulkan *)(unsigned int)(type->reflectionType - 7),
                            offset: (unsigned int)v57,
                            data: v55,
                            sz: (unsigned int)type) )
                    {
                      v96.valueFormat = NetworkValueFormat_ProtectedStringSource; /*0x14111155c*/
                    }
                    else if ( DFFlag::ReplicateProtectedStringForScript3.value ) /*0x14111152e*/
                    {
                      v96.valueFormat = NetworkValueFormat_ProtectedStringBytecode; /*0x141111530*/
                    }
                    else
                    {
                      v63 = RBX::Reflection::Class_getDescriptorPtr<RBX::Script>(); /*0x141111537*/
                      v64 = RBX::Reflection::ClassDescriptor::operator==(this: v58, other: v63); /*0x141111542*/
                      v65 = NetworkValueFormat_ProtectedStringBytecode; /*0x141111547*/
                      if ( v64 ) /*0x141111553*/
                        v65 = NetworkValueFormat_ProtectedStringServerIndexString; /*0x141111553*/
                      v96.valueFormat = v65; /*0x141111556*/
                    }
                    goto LABEL_90; /*0x141111535*/
                  case ReflectionType_Vector3: /*0x1411114b8*/
                    v96.valueFormat = NetworkValueFormat_Vector3_Fixed12Bytes; /*0x14111150e*/
                    goto LABEL_90; /*0x141111513*/
                  default:
                    break; /*0x1411114b8*/
                }
                if ( type->reflectionType == ReflectionType_CoordinateFrame ) /*0x1411114cb*/
                  break; /*0x1411114cb*/
                if ( type->reflectionType == ReflectionType_OptionalCoordinateFrame ) /*0x1411114d0*/
                {
                  v96.valueFormat = (v51 != ReplicationMode_StudioAsEditor) + 50; /*0x1411114f9*/
LABEL_90:
                  v62 = *(std::string **)&v96.localConformance; /*0x141111579*/
                  v61 = *(_OWORD *)&v96.valueFormat; /*0x14111157f*/
                  goto LABEL_91; /*0x14111157f*/
                }
                v60 = RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType( /*0x1411114de*/
                        result: &v96,
                        reflectionType: type,
                        enumTypeByLocalType: &enumTypeToNetworkType);
                v61 = *(_OWORD *)&v60->valueFormat; /*0x1411114e3*/
                v62 = *(std::string **)&v60->localConformance; /*0x1411114e6*/
LABEL_91:
                *(_OWORD *)&fixedDictionaryList._Mypair._Myval2._Myfirst = v61; /*0x141111584*/
                fixedDictionaryList._Mypair._Myval2._Myend = v62; /*0x141111589*/
                v66 = v61; /*0x14111158f*/
                LOBYTE(propertyPtr) = v61; /*0x141111594*/
                RBX::Network::NetworkStream::writeBytes( /*0x1411115ab*/
                  this: &uncompressedStream,
                  inByteArray: &propertyPtr,
                  numberOfBytesToWrite: 1u);
                if ( v66 == 7 ) /*0x1411115b3*/
                {
                  LOWORD(propertyPtr) = WORD1(fixedDictionaryList._Mypair._Myval2._Myfirst); /*0x1411115ba*/
                  RBX::Network::NetworkStream::ReverseBytes( /*0x1411115d3*/
                    inByteArray: (unsigned __int8 *)&propertyPtr,
                    inOutByteArray,
                    length: 2u);
                  RBX::Network::NetworkStream::writeBytes( /*0x1411115e7*/
                    this: &uncompressedStream,
                    inByteArray: inOutByteArray,
                    numberOfBytesToWrite: 2u);
                }
                if ( v56 != 0 ) /*0x1411115ef*/
                {
                  v67 = v110; /*0x1411115f5*/
                  v68 = v110->nonCacheableClasses.impl.data._Mypair._Myval2._Mylast; /*0x1411115fc*/
                  v69 = v110->nonCacheableClasses.impl.data._Mypair._Myval2._Myfirst; /*0x141111600*/
                  if ( v110->nonCacheableClasses.impl.count >= (unsigned __int64)(3 * (v68 - v69)) >> 2 ) /*0x14111161a*/
                  {
                    RBX::detail::DenseHashTable<RBX::Solver::LDLComponent const *,RBX::Solver::LDLComponent const *,RBX::Solver::LDLComponent const *,RBX::detail::ItemInterfaceSet<RBX::Solver::LDLComponent const *>,RBX::Hash<RBX::Solver::LDLComponent const *>,std::equal_to<RBX::Solver::LDLComponent const *>>::rehash(this: (RBX::detail::DenseHashTable<RBX::SpanningNode *,RBX::SpanningNode *,RBX::SpanningNode *,RBX::detail::ItemInterfaceSet<RBX::SpanningNode *>,RBX::Hash<RBX::SpanningNode *>,std::equal_to<RBX::SpanningNode *> > *)&v110->nonCacheableClasses); /*0x141111620*/
                    v68 = v67->nonCacheableClasses.impl.data._Mypair._Myval2._Mylast; /*0x141111625*/
                    v69 = v67->nonCacheableClasses.impl.data._Mypair._Myval2._Myfirst; /*0x141111629*/
                  }
                  v70 = v68 - v69 - 1; /*0x141111634*/
                  v71 = (const RBX::Reflection::ClassDescriptor *)*(v50 - 5); /*0x141111637*/
                  v72 = v70 & ((unsigned __int64)v71 + ((unsigned __int64)v71 >> 3)); /*0x141111645*/
                  v73 = 0; /*0x141111648*/
                  while ( 1 ) /*0x141111650*/
                  {
                    v74 = &v69[v72]; /*0x141111650*/
                    if ( *v74 == v67->nonCacheableClasses.impl.empty_key ) /*0x14111165a*/
                      break; /*0x14111165a*/
                    if ( *v74 != v71 ) /*0x14111165f*/
                    {
                      v72 = v70 & (v73 + v72 + 1); /*0x141111667*/
                      if ( ++v73 <= v70 ) /*0x141111670*/
                        continue; /*0x141111670*/
                    }
                    goto LABEL_102; /*0x141111670*/
                  }
                  *v74 = v71; /*0x141111674*/
                  ++v67->nonCacheableClasses.impl.count; /*0x141111677*/
                }
LABEL_102:
                v75 = v112; /*0x14111167b*/
                if ( *v53 != (RBX::Reflection::PropDescriptor<RBX::Instance,std::string > *)&RBX::BasePart::prop_CFrame ) /*0x14111168f*/
                  v75 = v52; /*0x14111168f*/
                v52 = v75; /*0x141111694*/
                ++v112; /*0x14111169b*/
                if ( ++v53 == v54 ) /*0x1411116a9*/
                  goto LABEL_105; /*0x1411116a9*/
              }
              v96.valueFormat = (v51 != ReplicationMode_StudioAsEditor) + 26; /*0x141111508*/
              goto LABEL_90; /*0x14111150c*/
            }
LABEL_105:
            LOWORD(propertyPtr) = v52; /*0x1411116af*/
            RBX::Network::NetworkStream::ReverseBytes( /*0x1411116c9*/
              inByteArray: (unsigned __int8 *)&propertyPtr,
              inOutByteArray: inByteArray,
              length: 2u);
            RBX::Network::NetworkStream::writeBytes(this: &uncompressedStream, inByteArray, numberOfBytesToWrite: 2u); /*0x1411116dd*/
            RBX::Network::serializeUnsignedVarint(value: *v50 - *(v50 - 1), stream: &uncompressedStream); /*0x1411116f1*/
            v76 = *v50; /*0x1411116f6*/
            v77 = *(v50 - 1); /*0x1411116f9*/
            if ( v77 != *v50 ) /*0x141111700*/
            {
              do /*0x1411117da*/
              {
                RBX::Network::serializeString( /*0x141111722*/
                  value: &(*v77)->name->str,
                  stream: &uncompressedStream,
                  maxStringWriteSize: DFInt::MaxDataPayloadSize);
                v78 = *v77; /*0x141111727*/
                RBX::Network::serializeUnsignedVarint( /*0x14111174d*/
                  value: (*v77)->signature.arguments._Mypair._Myval2._Mylast
                - (*v77)->signature.arguments._Mypair._Myval2._Myfirst,
                  stream: &uncompressedStream);
                v79 = v78->signature.arguments._Mypair._Myval2._Mylast; /*0x141111752*/
                for ( k = v78->signature.arguments._Mypair._Myval2._Myfirst; k != v79; ++k ) /*0x14111175d*/
                {
                  RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType( /*0x14111176d*/
                    result: &v96,
                    reflectionType: k->type,
                    enumTypeByLocalType: &enumTypeToNetworkType);
                  LOBYTE(propertyPtr) = v96.valueFormat; /*0x141111777*/
                  RBX::Network::NetworkStream::writeBytes( /*0x14111178e*/
                    this: &uncompressedStream,
                    inByteArray: &propertyPtr,
                    numberOfBytesToWrite: 1u);
                  LOWORD(propertyPtr) = v96.enumId; /*0x141111798*/
                  RBX::Network::NetworkStream::ReverseBytes( /*0x1411117b1*/
                    inByteArray: (unsigned __int8 *)&propertyPtr,
                    inOutByteArray: v99,
                    length: 2u);
                  RBX::Network::NetworkStream::writeBytes( /*0x1411117c5*/
                    this: &uncompressedStream,
                    inByteArray: v99,
                    numberOfBytesToWrite: 2u);
                }
                ++v77; /*0x1411117d3*/
              }
              while ( v77 != v76 ); /*0x1411117da*/
              v51 = v109; /*0x1411117e0*/
            }
            v50 += 7; /*0x1411117e7*/
            v33 = tmpClassInfos._Mypair._Myval2._Mylast; /*0x1411117ef*/
          }
          while ( v50 - 5 != (const RBX::Reflection::EventDescriptor ***)tmpClassInfos._Mypair._Myval2._Mylast ); /*0x1411117fc*/
          v32 = tmpClassInfos._Mypair._Myval2._Myfirst; /*0x141111802*/
        }
        RBX::Network::serializeUnsignedVarint( /*0x141111820*/
          value: RBX::Network::knownPrefixes._Mypair._Myval2._Mylast - RBX::Network::knownPrefixes._Mypair._Myval2._Myfirst,
          stream: &uncompressedStream);
        v81 = RBX::Network::knownPrefixes._Mypair._Myval2._Mylast; /*0x141111825*/
        for ( m = RBX::Network::knownPrefixes._Mypair._Myval2._Myfirst; m != v81; ++m ) /*0x141111836*/
          RBX::Network::serializeString( /*0x14111184e*/
            value: m,
            stream: &uncompressedStream,
            maxStringWriteSize: DFInt::MaxDataPayloadSize);
        RBX::Network::buildFixedDictionaryList(result: &fixedDictionaryList); /*0x141111861*/
        __wind /*0xf1c000000000001c*/
        {
          RBX::Network::serializeUnsignedVarint( /*0x141111879*/
            value: fixedDictionaryList._Mypair._Myval2._Mylast - fixedDictionaryList._Mypair._Myval2._Myfirst,
            stream: &uncompressedStream);
          v83 = fixedDictionaryList._Mypair._Myval2._Mylast; /*0x14111187e*/
          v84 = fixedDictionaryList._Mypair._Myval2._Myfirst; /*0x141111883*/
          if ( fixedDictionaryList._Mypair._Myval2._Myfirst != fixedDictionaryList._Mypair._Myval2._Mylast ) /*0x14111188b*/
          {
            do /*0x1411118aa*/
              RBX::Network::serializeString( /*0x14111189e*/
                value: v84++,
                stream: &uncompressedStream,
                maxStringWriteSize: DFInt::MaxDataPayloadSize);
            while ( v84 != v83 ); /*0x1411118aa*/
            v83 = fixedDictionaryList._Mypair._Myval2._Mylast; /*0x1411118ac*/
            v84 = fixedDictionaryList._Mypair._Myval2._Myfirst; /*0x1411118b1*/
          }
        }
        __unwind
        {
          RBX::ScriptServices::Documentation::ValidateResult::~ValidateResult(this: (std::vector<RBX::MeshId> *)&fixedDictionaryList); /*0xf1c0000000000014*/
        }
        if ( v84 != nullptr ) /*0x1411118b9*/
        {
          if ( v84 != v83 ) /*0x1411118c2*/
          {
            do /*0x141111910*/
            {
              Myres = v84->_Mypair._Myval2._Myres; /*0x1411118c4*/
              if ( Myres >= 0x10 ) /*0x1411118cc*/
              {
                v86 = v84->_Mypair._Myval2._Bx._Ptr; /*0x1411118ce*/
                if ( Myres + 1 >= 0x1000 ) /*0x1411118db*/
                {
                  if ( (unsigned __int64)&v86[-*((_QWORD *)v86 - 1) - 8] > 0x1F ) /*0x1411118f0*/
                    goto LABEL_129; /*0x1411118f0*/
                  v86 = *((char **)v86 - 1); /*0x1411118f2*/
                }
                operator delete(ptr: v86); /*0x1411118f5*/
              }
              v84->_Mypair._Myval2._Mysize = 0; /*0x1411118fa*/
              v84->_Mypair._Myval2._Myres = 15; /*0x1411118fe*/
              v84->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141111906*/
              ++v84; /*0x141111909*/
            }
            while ( v84 != v83 ); /*0x141111910*/
            v84 = fixedDictionaryList._Mypair._Myval2._Myfirst; /*0x141111912*/
          }
          v87 = v84; /*0x141111923*/
          if ( (((char *)fixedDictionaryList._Mypair._Myval2._Myend - (char *)v84) & 0xFFFFFFFFFFFFFFE0uLL) >= 0x1000 ) /*0x14111192d*/
          {
            v84 = (std::string *)v84[-1]._Mypair._Myval2._Myres; /*0x141111933*/
            if ( (unsigned __int64)((char *)v87 - (char *)v84 - 8) > 0x1F ) /*0x141111942*/
LABEL_129:
              _invalid_parameter_noinfo_noreturn(); /*0x141111944*/
          }
          operator delete(ptr: v84); /*0x14111194e*/
        }
        LOBYTE(v109) = -105; /*0x141111953*/
        p_Ptr = &v110->schemaBitStream._Ptr; /*0x141111967*/
        RBX::Network::NetworkStream::writeBytes( /*0x141111971*/
          this: v110->schemaBitStream._Ptr,
          inByteArray: &v109,
          numberOfBytesToWrite: 1u);
        RBX::Network::Replicator::compressBitStream( /*0x141111985*/
          inUncompressedBitStream: &uncompressedStream,
          outCompressedBitStream: *p_Ptr,
          compressRatio: DFInt::NetworkSchemaCompressionRatio);
      }
      __unwind
      {
        std::vector__RBX::Network::NetworkSchema::generateSchemaDefinitionPacket_::_2_::TmpClassInfo_std::allocator__RBX::Network::NetworkSchema::generateSchemaDefinitionPacket_::_2_::TmpClassInfo___::_vector__RBX::Network::NetworkSchema::generateSchemaDefinitionPacket_::_2_::TmpClassInfo_std::allocator__RBX::Network::NetworkSchema::generateSchemaDefinitionPacket_::_2_::TmpClassInfo___(a1: &tmpClassInfos); /*0xf1c0000000000008*/
      }
      if ( v32 != nullptr ) /*0x14111198e*/
      {
        for ( n = v32; n != v33; ++n ) /*0x141111996*/
          RBX::Network::NetworkSchema::generateSchemaDefinitionPacket_::_2_::TmpClassInfo::_TmpClassInfo(a1: n); /*0x14111199b*/
        v90 = v32; /*0x1411119d0*/
        if ( (unsigned __int64)(56 * (((char *)enumItr._Ptr - (char *)v32) / 56)) >= 0x1000 ) /*0x1411119da*/
        {
          v32 = (RBX::Network::NetworkSchema::generateSchemaDefinitionPacket::__l2::TmpClassInfo *)v32[-1].events._Mypair._Myval2._Myend; /*0x1411119e0*/
          if ( (unsigned __int64)((char *)v90 - (char *)v32 - 8) > 0x1F ) /*0x1411119ef*/
            _invalid_parameter_noinfo_noreturn(); /*0x1411119f1*/
        }
        operator delete(ptr: v32); /*0x1411119fb*/
      }
      v91 = enumTypeToNetworkType.impl.data._Mypair._Myval2._Myfirst; /*0x141111a01*/
      if ( enumTypeToNetworkType.impl.data._Mypair._Myval2._Myfirst != nullptr ) /*0x141111a08*/
      {
        if ( (((char *)Myend - (char *)enumTypeToNetworkType.impl.data._Mypair._Myval2._Myfirst) & 0xFFFFFFFFFFFFFFE0uLL) >= 0x1000 ) /*0x141111a1f*/
        {
          v91 = *(std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type> **)&enumTypeToNetworkType.impl.data._Mypair._Myval2._Myfirst[-1].second.localConformance; /*0x141111a25*/
          if ( (unsigned __int64)((char *)enumTypeToNetworkType.impl.data._Mypair._Myval2._Myfirst - (char *)v91 - 8) > 0x1F ) /*0x141111a34*/
            _invalid_parameter_noinfo_noreturn(); /*0x141111a36*/
        }
        operator delete(ptr: v91); /*0x141111a3d*/
      }
      v92 = uncompressedStream.dataVector._Mypair._Myval2._Myfirst; /*0x141111a43*/
      if ( uncompressedStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x141111a4a*/
      {
        if ( (unsigned __int8 *)(uncompressedStream.dataVector._Mypair._Myval2._Myend /*0x141111a5d*/
                               - uncompressedStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 )
        {
          v92 = *((unsigned __int8 **)uncompressedStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x141111a63*/
          if ( (unsigned __int64)(uncompressedStream.dataVector._Mypair._Myval2._Myfirst - v92 - 8) > 0x1F ) /*0x141111a72*/
            _invalid_parameter_noinfo_noreturn(); /*0x141111a74*/
        }
        operator delete(ptr: v92); /*0x141111a7b*/
      }
    }
    __unwind
    {
      std::vector<Luau::AstGenericType>::~vector<Luau::AstGenericType>(this: (std::vector<std::optional<std::pair<Luau::AstName,Luau::Location> >> *)&enumTypeToNetworkType); /*0xf1c0000000000050*/
    }
  }
  __unwind
  {
    RBX::Network::NetworkStream::~NetworkStream(this: &uncompressedStream); /*0xf1c000000000005c*/
  }
}

// Address: 0x141111b10 | Name: ?initializeFromSchemaDefinitionPacket@NetworkSchema@Network@RBX@@QEAAXAEAVNetworkStream@23@_N@Z
void __fastcall RBX::Network::NetworkSchema::initializeFromSchemaDefinitionPacket(
        RBX::Network::NetworkSchema *this,
        RBX::Network::NetworkStream *packet,
        bool isCloudEdit)
{
  long double sec; // r12
  _QWORD *v5; // r13
  __int64 v6; // rdi
  __int64 v7; // rdx
  unsigned __int64 v8; // rcx
  __int64 v9; // rax
  size_t v10; // rbx
  unsigned __int16 i; // si
  const RBX::Name *v12; // rdi
  const std::vector<RBX::Reflection::Type const *> *AllTypes; // rax
  __int64 v14; // rcx
  unsigned __int64 v15; // rdx
  const RBX::Reflection::Type *v16; // rbx
  __int64 v17; // r9
  __int64 v18; // r10
  unsigned __int64 v19; // r9
  __int64 v20; // rax
  __int64 v21; // rdx
  __int64 v22; // rcx
  char *Ptr; // rcx
  _QWORD *v24; // r14
  RBX::Network::NetworkSchema::ClassInfo *v25; // rdi
  __int64 v26; // r10
  __int64 v27; // rcx
  RBX::Network::NetworkSchema::ClassInfo *v28; // rbx
  __int64 v29; // r9
  std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short> **p_Myend; // rax
  unsigned __int64 v31; // r9
  __int64 v32; // rdi
  __int64 v33; // r10
  __int64 v34; // rcx
  unsigned __int64 v35; // r9
  __int64 v36; // rbx
  __int64 v37; // r15
  __int64 v38; // rbx
  __int64 v39; // r10
  __int64 v40; // rcx
  __int64 v41; // rsi
  __int64 j; // rdi
  __int64 v43; // r9
  _QWORD *v44; // rax
  __int64 v45; // rdi
  unsigned __int16 v46; // r15
  unsigned __int16 v47; // si
  __int64 v48; // r12
  const RBX::Name *v49; // rdi
  RBX::Reflection::ClassDescriptor **v50; // r14
  RBX::Reflection::ClassDescriptor **Myfirst; // rbx
  RBX::Reflection::ClassDescriptor **Mylast; // rcx
  RBX::Reflection::ClassDescriptor *v53; // rdx
  long double v54; // rbx
  __int64 v55; // r10
  __int64 v56; // r11
  unsigned __int64 v57; // r10
  __int64 v58; // rcx
  __int64 v59; // r8
  __int64 v60; // rax
  unsigned __int16 v61; // ax
  __int64 v62; // rdi
  __int64 v63; // rsi
  __int64 v64; // rdx
  std::string *p_nameBuffer; // rdx
  RBX::Reflection::PropertyDescriptor *PropertyDescriptor; // rax
  RBX::Reflection::PropDescriptor<RBX::Instance,RBX::UniqueId> *v67; // rbx
  __int64 v68; // r9
  __int64 v69; // r10
  unsigned __int64 v70; // r9
  __int64 v71; // rcx
  __int64 v72; // rdx
  __int64 v73; // rax
  unsigned __int16 v74; // di
  RBX::Reflection::ClassDescriptor *v75; // r8
  long double v76; // rbx
  __int64 v77; // r10
  __int64 v78; // r11
  unsigned __int64 v79; // r10
  __int64 v80; // rcx
  __int64 v81; // rdx
  __int64 v82; // rax
  unsigned __int16 v83; // bx
  unsigned __int16 v84; // r13
  __int64 v85; // r15
  __int64 v86; // r12
  __int64 v87; // r14
  __int64 v88; // rdi
  __int64 v89; // r10
  __int64 v90; // rcx
  __int64 v91; // r9
  __int64 v92; // rbx
  unsigned int k; // ebx
  __int64 v94; // r8
  std::string *v95; // rdx
  RBX::Reflection::EventDescriptor *EventDescriptor; // rax
  RBX::Reflection::EventDescriptor *v97; // rsi
  RBX::Reflection::SignatureDescriptor::Argument *v98; // rbx
  _QWORD *v99; // rbx
  __int64 v100; // r9
  __int64 v101; // r10
  unsigned __int64 v102; // r9
  __int64 v103; // rcx
  __int64 v104; // rdx
  __int64 v105; // rax
  __int64 v106; // rcx
  __int64 v107; // rax
  __int64 v108; // r14
  __int64 n; // rbx
  __int16 v110; // si
  __int64 v111; // r9
  __int64 v112; // r10
  unsigned __int64 v113; // r9
  unsigned __int64 v114; // rcx
  __int64 v115; // rdx
  __int64 v116; // rax
  unsigned int ii; // ebx
  __int64 v118; // rbx
  const std::string *v119; // rbx
  RBX::Time *v120; // rax
  float v121; // xmm2_4
  char *v122; // rcx
  unsigned __int16 enumId[2]; // [rsp+30h] [rbp-D0h] BYREF
  unsigned __int16 v124; // [rsp+34h] [rbp-CCh]
  unsigned __int16 inOutByteArray[2]; // [rsp+38h] [rbp-C8h] BYREF
  unsigned int argumentCount; // [rsp+3Ch] [rbp-C4h] BYREF
  unsigned __int8 valueFormat[4]; // [rsp+40h] [rbp-C0h] BYREF
  unsigned __int16 cframePropertyId; // [rsp+44h] [rbp-BCh] BYREF
  __int16 v129; // [rsp+48h] [rbp-B8h]
  unsigned __int16 v130; // [rsp+4Ah] [rbp-B6h]
  unsigned int classCount; // [rsp+4Ch] [rbp-B4h] BYREF
  std::_Value_init_tag _Val; // [rsp+50h] [rbp-B0h] BYREF
  RBX::Reflection::ClassDescriptor **v133; // [rsp+58h] [rbp-A8h]
  unsigned int propertyCount; // [rsp+60h] [rbp-A0h] BYREF
  unsigned int eventCount; // [rsp+64h] [rbp-9Ch] BYREF
  unsigned int classProperties; // [rsp+68h] [rbp-98h] BYREF
  unsigned int value; // [rsp+6Ch] [rbp-94h] BYREF
  std::string nameBuffer; // [rsp+70h] [rbp-90h] BYREF
  RBX::Network::NetworkStream inBitStream; // [rsp+90h] [rbp-70h] BYREF
  _QWORD *v140; // [rsp+D0h] [rbp-30h]
  RBX::Graphics::ProfilerAdorn::Item m; // [rsp+D8h] [rbp-28h] BYREF
  _QWORD *v142; // [rsp+110h] [rbp+10h]
  RBX::Timer<2> schemaLoadTimer; // [rsp+118h] [rbp+18h] BYREF
  std::string enumTypeName; // [rsp+120h] [rbp+20h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+140h] [rbp+40h] BYREF
  std::_Uninitialized_backout_al<std::allocator<RBX::Network::NetworkSchema::ClassInfo> > v146[3]; // [rsp+178h] [rbp+78h] BYREF
  RBX::Time numFixedDictionaryEntries; // [rsp+1E0h] [rbp+E0h] BYREF
  bool v148; // [rsp+1F0h] [rbp+F0h]
  unsigned __int8 networkFormat; // [rsp+1F8h] [rbp+F8h] BYREF

  v148 = isCloudEdit; /*0x141111b15*/
  *(RBX::Time *)&numFixedDictionaryEntries.sec = (RBX::Time)this; /*0x141111b1a*/
  sec = *(double *)&this; /*0x141111b3c*/
  RBX::Time::now<2>(result: &schemaLoadTimer.start); /*0x141111b43*/
  RBX::Network::NetworkStream::readByte(this: packet); /*0x141111b4b*/
  RBX::Network::NetworkStream::NetworkStream(this: &inBitStream); /*0x141111b54*/
  __wind /*0xf1c00000000000dc*/
  {
    RBX::Network::Replicator::decompressBitStream(inCompressedBitStream: packet, outUncompressedBitStream: &inBitStream); /*0x141111b61*/
    RBX::Network::deserializeUnsignedVarint(value: &argumentCount, stream: &inBitStream); /*0x141111b6f*/
    v5 = (_QWORD *)(*(_QWORD *)&sec + 152LL); /*0x141111b74*/
    v142 = (_QWORD *)(*(_QWORD *)&sec + 152LL); /*0x141111b7c*/
    v6 = *(_QWORD *)(*(_QWORD *)&sec + 160LL); /*0x141111b84*/
    v7 = *(_QWORD *)(*(_QWORD *)&sec + 152LL); /*0x141111b88*/
    v8 = (v6 - v7) >> 3; /*0x141111b92*/
    if ( argumentCount < v8 ) /*0x141111b99*/
    {
      v9 = v7 + 8LL * argumentCount; /*0x141111b9b*/
LABEL_8:
      *(_QWORD *)(*(_QWORD *)&sec + 160LL) = v9; /*0x141111be3*/
      goto LABEL_9; /*0x141111be3*/
    }
    if ( argumentCount > v8 ) /*0x141111ba1*/
    {
      if ( argumentCount <= (unsigned __int64)((*(_QWORD *)(*(_QWORD *)&sec + 168LL) - v7) >> 3) ) /*0x141111bb1*/
      {
        v10 = 8 * (argumentCount - v8); /*0x141111bca*/
        memset_0(a1: *(void **)(*(_QWORD *)&sec + 160LL), Val: 0, Size: v10); /*0x141111bda*/
        v9 = v6 + v10; /*0x141111bdf*/
        goto LABEL_8; /*0x141111bdf*/
      }
      std::vector<RBX::Reflection::EnumDescriptor const *>::_Resize_reallocate<std::_Value_init_tag>( /*0x141111bc0*/
        this: (std::vector<ncnn::Layer *> *)(*(_QWORD *)&sec + 152LL),
        _Newsize: argumentCount,
        _Val: (const std::_Value_init_tag *)&networkFormat);
    }
LABEL_9:
    for ( i = 0; i < argumentCount; ++i ) /*0x141111bf3*/
    {
      enumTypeName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141111c00*/
      enumTypeName._Mypair._Myval2._Mysize = 0; /*0x141111c04*/
      enumTypeName._Mypair._Myval2._Myres = 15; /*0x141111c08*/
      __wind /*0xf1c00000000000d0*/
      {
        RBX::Network::deserializeString( /*0x141111c23*/
          value: &enumTypeName,
          stream: &inBitStream,
          maxStringReadSize: DFInt::MaxDataPayloadSize);
        if ( !RBX::Network::NetworkStream::readBytes( /*0x141111c40*/
                this: &inBitStream,
                inOutByteArray: &networkFormat,
                numberOfBytesToRead: 1u) )
        {
          std::string::string(this: &m.text, _Ptr: "readFast past end for uint8_t"); /*0x141112c21*/
          __wind /*0xf1c0000000000024*/
          {
            RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &m.text); /*0x141112c2f*/
            throw &pExceptionObject; /*0x141112c3f*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: &m); /*0xf1c0000000000034*/
          }
        }
        *(_QWORD *)(*v5 + 8LL * i) = 0; /*0x141111c4e*/
        v12 = RBX::Name::lookup(name: &enumTypeName); /*0x141111c5b*/
        if ( v12->str._Mypair._Myval2._Mysize != 0 ) /*0x141111c63*/
        {
          AllTypes = RBX::Reflection::Type::getAllTypes(); /*0x141111c69*/
          v14 = 0; /*0x141111c6e*/
          v15 = AllTypes->_Mypair._Myval2._Mylast - AllTypes->_Mypair._Myval2._Myfirst; /*0x141111c7b*/
          if ( v15 != 0 ) /*0x141111c82*/
          {
            while ( 1 ) /*0x141111c90*/
            {
              v16 = AllTypes->_Mypair._Myval2._Myfirst[v14]; /*0x141111c90*/
              if ( v16->name == v12 && v16->isEnum ) /*0x141111c9a*/
                break; /*0x141111c9e*/
              if ( ++v14 >= v15 ) /*0x141111ca6*/
                goto LABEL_205; /*0x141111ca6*/
            }
            if ( v16 != nullptr ) /*0x141111cb1*/
            {
              v17 = *(_QWORD *)(*(_QWORD *)&sec + 16LL); /*0x141111cb7*/
              v18 = *(_QWORD *)(*(_QWORD *)&sec + 8LL); /*0x141111cbc*/
              if ( *(_QWORD *)(*(_QWORD *)&sec + 32LL) >= (unsigned __int64)(3 * ((v17 - v18) >> 5)) >> 2 ) /*0x141111cd8*/
              {
                RBX::detail::DenseHashTable<RBX::Reflection::Type const *,std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type>,std::pair<RBX::Reflection::Type const * const,RBX::Network::NetworkSchema::Type>,RBX::detail::ItemInterfaceMap<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type>,RBX::Hash<RBX::Reflection::Type const *>,std::equal_to<RBX::Reflection::Type const *>>::rehash(this: (RBX::detail::DenseHashTable<RBX::Reflection::Type const *,std::pair<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type>,std::pair<RBX::Reflection::Type const * const,RBX::Network::NetworkSchema::Type>,RBX::detail::ItemInterfaceMap<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type>,RBX::Hash<RBX::Reflection::Type const *>,std::equal_to<RBX::Reflection::Type const *> > *)(*(_QWORD *)&sec + 8LL)); /*0x141111cdf*/
                v17 = *(_QWORD *)(*(_QWORD *)&sec + 16LL); /*0x141111ce4*/
                v18 = *(_QWORD *)(*(_QWORD *)&sec + 8LL); /*0x141111ce9*/
              }
              v19 = ((v17 - v18) >> 5) - 1; /*0x141111cf5*/
              v20 = v19 & ((unsigned __int64)v16 + ((unsigned __int64)v16 >> 3)); /*0x141111d02*/
              v21 = 0; /*0x141111d05*/
              while ( 1 ) /*0x141111d17*/
              {
                v22 = v18 + 32 * v20; /*0x141111d17*/
                if ( *(_QWORD *)v22 == *(_QWORD *)(*(_QWORD *)&sec + 40LL) ) /*0x141111d20*/
                  break; /*0x141111d20*/
                if ( *(const RBX::Reflection::Type **)v22 == v16 ) /*0x141111d25*/
                  goto LABEL_27; /*0x141111d25*/
                v20 = v19 & (v21 + v20 + 1); /*0x141111d2d*/
                if ( ++v21 > v19 ) /*0x141111d36*/
                {
                  v22 = 0; /*0x141111d38*/
                  goto LABEL_27; /*0x141111d3b*/
                }
              }
              *(_QWORD *)v22 = v16; /*0x141111d3d*/
              ++*(_QWORD *)(*(_QWORD *)&sec + 32LL); /*0x141111d40*/
LABEL_27:
              *(_BYTE *)(v22 + 8) = networkFormat; /*0x141111d45*/
              *(_WORD *)(v22 + 10) = i; /*0x141111d4f*/
              *(_QWORD *)(v22 + 16) = v16; /*0x141111d53*/
              *(_QWORD *)(*v5 + 8LL * i) = v16; /*0x141111d5b*/
            }
          }
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&enumTypeName); /*0xf1c00000000000c8*/
      }
LABEL_205:
      if ( enumTypeName._Mypair._Myval2._Myres >= 0x10 ) /*0x141111d67*/
      {
        Ptr = enumTypeName._Mypair._Myval2._Bx._Ptr; /*0x141111d6c*/
        if ( enumTypeName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141111d7a*/
        {
          Ptr = *((char **)enumTypeName._Mypair._Myval2._Bx._Ptr - 1); /*0x141111d80*/
          if ( (unsigned __int64)(enumTypeName._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141111d8f*/
            _invalid_parameter_noinfo_noreturn(); /*0x141111e4a*/
        }
        operator delete(ptr: Ptr); /*0x141111d95*/
      }
    }
    classCount = 0; /*0x141111daa*/
    RBX::Network::deserializeUnsignedVarint(value: &classCount, stream: &inBitStream); /*0x141111db8*/
    propertyCount = 0; /*0x141111dbd*/
    RBX::Network::deserializeUnsignedVarint(value: &propertyCount, stream: &inBitStream); /*0x141111dcb*/
    eventCount = 0; /*0x141111dd0*/
    RBX::Network::deserializeUnsignedVarint(value: &eventCount, stream: &inBitStream); /*0x141111dde*/
    v24 = (_QWORD *)(*(_QWORD *)&sec + 176LL); /*0x141111de3*/
    v140 = (_QWORD *)(*(_QWORD *)&sec + 176LL); /*0x141111deb*/
    v25 = *(RBX::Network::NetworkSchema::ClassInfo **)(*(_QWORD *)&sec + 184LL); /*0x141111df4*/
    v26 = *(_QWORD *)(*(_QWORD *)&sec + 176LL); /*0x141111df8*/
    v27 = (__int64)v25 - v26; /*0x141111dfe*/
    if ( classCount >= (unsigned __int64)(((__int64)v25 - v26) / 112) ) /*0x141111e2a*/
    {
      if ( classCount > (unsigned __int64)(v27 / 112) ) /*0x141111e51*/
      {
        if ( classCount <= (unsigned __int64)((*(_QWORD *)(*(_QWORD *)&sec + 192LL) - v26) / 112) ) /*0x141111e75*/
        {
          v29 = classCount - v27 / 112; /*0x141111e8b*/
          __wind /*0xf1c00000000000b8*/
          {
            if ( v29 != 0 ) /*0x141111e8e*/
            {
              p_Myend = &v25->propertyNetworkIdByLocalDescriptor.impl.data._Mypair._Myval2._Myend; /*0x141111e90*/
              do /*0x141111ee1*/
              {
                v25->classNetworkId = -1; /*0x141111ea0*/
                *(_DWORD *)((char *)p_Myend - 30) = -1; /*0x141111ea3*/
                *(p_Myend - 3) = nullptr; /*0x141111eaa*/
                *(p_Myend - 2) = nullptr; /*0x141111eae*/
                *(p_Myend - 1) = nullptr; /*0x141111eb2*/
                *p_Myend = nullptr; /*0x141111eb6*/
                p_Myend[1] = nullptr; /*0x141111eb9*/
                p_Myend[2] = nullptr; /*0x141111ebd*/
                p_Myend[4] = nullptr; /*0x141111ec1*/
                p_Myend[5] = nullptr; /*0x141111ec5*/
                p_Myend[6] = nullptr; /*0x141111ec9*/
                p_Myend[7] = nullptr; /*0x141111ecd*/
                p_Myend[8] = nullptr; /*0x141111ed1*/
                ++v25; /*0x141111ed5*/
                p_Myend += 14; /*0x141111ed9*/
                --v29; /*0x141111edd*/
              }
              while ( v29 != 0 ); /*0x141111ee1*/
            }
            std::_Destroy_range<std::allocator<RBX::Network::NetworkSchema::ClassInfo>>( /*0x141111eec*/
              _First: v25,
              _Last: v25,
              _Al: (std::allocator<RBX::Network::NetworkSchema::ClassInfo> *)(*(_QWORD *)&sec + 176LL));
            *(_QWORD *)(*(_QWORD *)&sec + 184LL) = v25; /*0x141111ef1*/
          }
          __unwind
          {
            std::_Uninitialized_backout_al<std::allocator<RBX::Network::NetworkSchema::ClassInfo>>::~_Uninitialized_backout_al<std::allocator<RBX::Network::NetworkSchema::ClassInfo>>(this: v146); /*0xf1c00000000000b0*/
          }
        }
        else
        {
          std::vector<RBX::Network::NetworkSchema::ClassInfo>::_Resize_reallocate<std::_Value_init_tag>( /*0x141111e84*/
            this: (std::vector<RBX::Network::NetworkSchema::ClassInfo> *)(*(_QWORD *)&sec + 176LL),
            _Newsize: classCount,
            _Val: (const std::_Value_init_tag *)&networkFormat);
        }
      }
    }
    else
    {
      v28 = (RBX::Network::NetworkSchema::ClassInfo *)(v26 + 112LL * classCount); /*0x141111e30*/
      std::_Destroy_range<std::allocator<RBX::Network::NetworkSchema::ClassInfo>>( /*0x141111e3c*/
        _First: v28,
        _Last: *(RBX::Network::NetworkSchema::ClassInfo *const *)(*(_QWORD *)&sec + 184LL),
        _Al: (std::allocator<RBX::Network::NetworkSchema::ClassInfo> *)(*(_QWORD *)&sec + 176LL));
      *(_QWORD *)(*(_QWORD *)&sec + 184LL) = v28; /*0x141111e41*/
    }
    *(_QWORD *)&m.x = *(_QWORD *)&sec + 200LL; /*0x141111efd*/
    v31 = propertyCount + 1; /*0x141111f06*/
    v32 = *(_QWORD *)(*(_QWORD *)&sec + 208LL); /*0x141111f09*/
    v33 = *(_QWORD *)(*(_QWORD *)&sec + 200LL); /*0x141111f0d*/
    v34 = v32 - v33; /*0x141111f13*/
    if ( v31 >= (v32 - v33) / 40 ) /*0x141111f3a*/
    {
      if ( v31 > v34 / 40 ) /*0x141111f4a*/
      {
        if ( v31 <= (*(_QWORD *)(*(_QWORD *)&sec + 216LL) - v33) / 40 ) /*0x141111f6a*/
        {
          v35 = v31 - v34 / 40; /*0x141111f80*/
          if ( v35 != 0 ) /*0x141111f83*/
          {
            v36 = 40 * v35; /*0x141111f89*/
            memset_0(a1: *(void **)(*(_QWORD *)&sec + 208LL), Val: 0, Size: 40 * v35); /*0x141111f95*/
            v32 += v36; /*0x141111f9a*/
          }
          *(_QWORD *)(*(_QWORD *)&sec + 208LL) = v32; /*0x141111f9d*/
        }
        else
        {
          std::vector<RBX::Network::NetworkSchema::ClassProperty>::_Resize_reallocate<std::_Value_init_tag>( /*0x141111f79*/
            this: (std::vector<RBX::Network::NetworkSchema::ClassProperty> *)(*(_QWORD *)&sec + 200LL),
            _Newsize: propertyCount + 1,
            _Val: (const std::_Value_init_tag *)&networkFormat);
        }
      }
    }
    else
    {
      *(_QWORD *)(*(_QWORD *)&sec + 208LL) = v33 + 40 * v31; /*0x141111f44*/
    }
    v37 = *(_QWORD *)&sec + 224LL; /*0x141111fa1*/
    *(_QWORD *)&m.width = *(_QWORD *)&sec + 224LL; /*0x141111fa9*/
    v38 = *(_QWORD *)(*(_QWORD *)&sec + 232LL); /*0x141111fb2*/
    v39 = *(_QWORD *)(*(_QWORD *)&sec + 224LL); /*0x141111fb6*/
    v40 = v38 - v39; /*0x141111fbc*/
    if ( eventCount >= (unsigned __int64)((v38 - v39) / 40) ) /*0x141111fe3*/
    {
      if ( eventCount > (unsigned __int64)(v40 / 40) ) /*0x14111200d*/
      {
        if ( eventCount <= (unsigned __int64)((*(_QWORD *)(*(_QWORD *)&sec + 240LL) - v39) / 40) ) /*0x14111202d*/
        {
          v43 = eventCount - v40 / 40; /*0x141112043*/
          if ( v43 != 0 ) /*0x141112046*/
          {
            v44 = (_QWORD *)(v38 + 24); /*0x141112048*/
            do /*0x141112077*/
            {
              *(_OWORD *)v38 = 0; /*0x141112055*/
              *(_OWORD *)(v38 + 16) = 0; /*0x141112058*/
              *(_QWORD *)(v38 + 32) = 0; /*0x14111205c*/
              *(v44 - 2) = 0; /*0x141112060*/
              *(v44 - 1) = 0; /*0x141112064*/
              *v44 = 0; /*0x141112068*/
              v38 += 40; /*0x14111206b*/
              v44 += 5; /*0x14111206f*/
              --v43; /*0x141112073*/
            }
            while ( v43 != 0 ); /*0x141112077*/
            sec = numFixedDictionaryEntries.sec; /*0x141112079*/
          }
          *(_QWORD *)(v37 + 8) = v38; /*0x141112080*/
        }
        else
        {
          std::vector<RBX::Network::NetworkSchema::ClassEvent>::_Resize_reallocate<std::_Value_init_tag>( /*0x14111203c*/
            this: (std::vector<RBX::Network::NetworkSchema::ClassEvent> *)(*(_QWORD *)&sec + 224LL),
            _Newsize: eventCount,
            _Val: (const std::_Value_init_tag *)&networkFormat);
        }
      }
    }
    else
    {
      v41 = v39 + 40LL * eventCount; /*0x141111fe9*/
      for ( j = v41; j != v38; j += 40 ) /*0x141111ff3*/
        std::vector<std::pair<RBX::Collision::MidPhasePrimHashPair,RBX::Collision::MidPhaseComponentResultPair &>>::~vector<std::pair<RBX::Collision::MidPhasePrimHashPair,RBX::Collision::MidPhaseComponentResultPair &>>(this: (std::vector<std::pair<RBX::Graphics::SamplerState,VkSampler_T *>> *)(j + 8)); /*0x141111ff9*/
      *(_QWORD *)(*(_QWORD *)&sec + 232LL) = v41; /*0x141112007*/
    }
    LODWORD(v45) = 0; /*0x141112084*/
    v46 = 0; /*0x141112086*/
    v129 = 0; /*0x14111208a*/
    v124 = 0; /*0x14111208f*/
    nameBuffer._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141112094*/
    nameBuffer._Mypair._Myval2._Mysize = 0; /*0x141112099*/
    nameBuffer._Mypair._Myval2._Myres = 15; /*0x14111209d*/
    __wind /*0xf1c00000000000a0*/
    {
      v47 = 0; /*0x1411120aa*/
      v130 = 0; /*0x1411120ad*/
      if ( classCount != 0 ) /*0x1411120b6*/
      {
        while ( 1 ) /*0x1411120fa*/
        {
          RBX::Network::deserializeString( /*0x1411120d0*/
            value: &nameBuffer,
            stream: &inBitStream,
            maxStringReadSize: DFInt::MaxDataPayloadSize);
          v48 = *v24 + 112LL * v47; /*0x1411120dc*/
          *(_QWORD *)&m.color = v48; /*0x1411120df*/
          *(_WORD *)v48 = v47; /*0x1411120e3*/
          v49 = RBX::Name::lookup(name: &nameBuffer); /*0x1411120f2*/
          if ( v49->str._Mypair._Myval2._Mysize == 0 /*0x141112124*/
            || (Myfirst = RBX::Reflection::ClassDescriptor::allClasses()->_Mypair._Myval2._Myfirst,
                Mylast = RBX::Reflection::ClassDescriptor::allClasses()->_Mypair._Myval2._Mylast,
                Myfirst == Mylast) )
          {
            v50 = (RBX::Reflection::ClassDescriptor **)(v48 + 8); /*0x1411120fc*/
            v133 = (RBX::Reflection::ClassDescriptor **)(v48 + 8); /*0x141112101*/
            *(_QWORD *)(v48 + 8) = 0; /*0x141112108*/
          }
          else
          {
            while ( 1 ) /*0x141112126*/
            {
              v53 = *Myfirst; /*0x141112126*/
              if ( (*Myfirst)->name == v49 ) /*0x14111212d*/
                break; /*0x14111212d*/
              if ( ++Myfirst == Mylast ) /*0x141112136*/
              {
                v50 = (RBX::Reflection::ClassDescriptor **)(v48 + 8); /*0x141112138*/
                v133 = (RBX::Reflection::ClassDescriptor **)(v48 + 8); /*0x14111213d*/
                *(_QWORD *)(v48 + 8) = 0; /*0x141112144*/
                goto LABEL_82; /*0x141112147*/
              }
            }
            v50 = (RBX::Reflection::ClassDescriptor **)(v48 + 8); /*0x14111214c*/
            v133 = (RBX::Reflection::ClassDescriptor **)(v48 + 8); /*0x141112151*/
            *(_QWORD *)(v48 + 8) = v53; /*0x141112156*/
            if ( v53 != nullptr ) /*0x14111215c*/
            {
              v54 = numFixedDictionaryEntries.sec; /*0x141112162*/
              v55 = *(_QWORD *)(*(_QWORD *)&numFixedDictionaryEntries.sec + 64LL); /*0x141112169*/
              v56 = *(_QWORD *)(*(_QWORD *)&numFixedDictionaryEntries.sec + 56LL); /*0x14111216d*/
              if ( *(_QWORD *)(*(_QWORD *)&numFixedDictionaryEntries.sec + 80LL) >= (unsigned __int64)(3 * ((v55 - v56) >> 4)) >> 2 ) /*0x141112187*/
              {
                RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const *,std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const * const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const *,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const *>,std::equal_to<RBX::Reflection::PropertyDescriptor const *>>::rehash(this: (RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const *,std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const * const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const *,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const *>,std::equal_to<RBX::Reflection::PropertyDescriptor const *> > *)(*(_QWORD *)&numFixedDictionaryEntries.sec + 56LL)); /*0x14111218d*/
                v55 = *(_QWORD *)(*(_QWORD *)&v54 + 64LL); /*0x141112192*/
                v56 = *(_QWORD *)(*(_QWORD *)&v54 + 56LL); /*0x141112196*/
                v53 = *v50; /*0x14111219a*/
              }
              v57 = ((v55 - v56) >> 4) - 1; /*0x1411121a4*/
              v58 = v57 & ((unsigned __int64)v53 + ((unsigned __int64)v53 >> 3)); /*0x1411121b1*/
              v59 = 0; /*0x1411121b4*/
              while ( 1 ) /*0x1411121c7*/
              {
                v60 = v56 + 16 * v58; /*0x1411121c7*/
                if ( *(_QWORD *)v60 == *(_QWORD *)(*(_QWORD *)&v54 + 88LL) ) /*0x1411121d0*/
                  break; /*0x1411121d0*/
                if ( *(RBX::Reflection::ClassDescriptor **)v60 == v53 ) /*0x1411121d5*/
                  goto LABEL_81; /*0x1411121d5*/
                v58 = v57 & (v59 + v58 + 1); /*0x1411121dd*/
                if ( ++v59 > v57 ) /*0x1411121e6*/
                {
                  MEMORY[8] = v47; /*0x1411121ec*/
                  goto LABEL_82; /*0x1411121f0*/
                }
              }
              *(_QWORD *)v60 = v53; /*0x1411121f2*/
              ++*(_QWORD *)(*(_QWORD *)&v54 + 80LL); /*0x1411121f5*/
LABEL_81:
              *(_WORD *)(v60 + 8) = v47; /*0x1411121f9*/
            }
          }
LABEL_82:
          classProperties = 0; /*0x141112203*/
          RBX::Network::deserializeUnsignedVarint(value: &classProperties, stream: &inBitStream); /*0x141112210*/
          *(_WORD *)(v48 + 2) = v46; /*0x141112215*/
          v61 = v46 + classProperties; /*0x141112220*/
          *(_WORD *)(v48 + 4) = v46 + classProperties; /*0x141112224*/
          if ( v46 < v61 ) /*0x14111222e*/
          {
            do /*0x141112445*/
            {
              RBX::Network::deserializeString( /*0x141112250*/
                value: &nameBuffer,
                stream: &inBitStream,
                maxStringReadSize: DFInt::MaxDataPayloadSize);
              if ( !RBX::Network::NetworkStream::readBytes( /*0x14111226d*/
                      this: &inBitStream,
                      inOutByteArray: &networkFormat,
                      numberOfBytesToRead: 1u) )
              {
                std::string::string(this: &m.text, _Ptr: "readFast past end for uint8_t"); /*0x141112c7f*/
                __eh34_enter_wind_state(5, 6); /*0xf1c0000000000014*/
                RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &m.text); /*0x141112c8d*/
                throw &pExceptionObject; /*0x141112c9d*/
              }
              enumId[0] = -1; /*0x141112278*/
              if ( networkFormat == 7 ) /*0x141112284*/
              {
                if ( !RBX::Network::NetworkStream::readBytes( /*0x14111229c*/
                        this: &inBitStream,
                        inOutByteArray: enumId,
                        numberOfBytesToRead: 2u) )
                {
                  std::string::string(this: &m.text, _Ptr: "readFast past end for uint16_t"); /*0x141112c50*/
                  __eh34_enter_wind_state(5, 6); /*0xf1c000000000001c*/
                  RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &m.text); /*0x141112c5e*/
                  throw &pExceptionObject; /*0x141112c6e*/
                }
                enumId[0] = __ROL2__(enumId[0], 8); /*0x1411122a2*/
              }
              v62 = 5LL * v46; /*0x1411122ac*/
              v63 = **(_QWORD **)&m.x; /*0x1411122b4*/
              *(_WORD *)(v63 + 8 * v62) = v46; /*0x1411122b7*/
              *(_QWORD *)(v63 + 8 * v62 + 32) = 0; /*0x1411122bc*/
              *(_BYTE *)(v63 + 8 * v62 + 8) = networkFormat; /*0x1411122c8*/
              *(_WORD *)(v63 + 8 * v62 + 10) = enumId[0]; /*0x1411122d1*/
              if ( enumId[0] == 0xFFFF ) /*0x1411122e3*/
                v64 = 0; /*0x1411122f1*/
              else
                v64 = *(_QWORD *)(*v5 + 8LL * enumId[0]); /*0x1411122eb*/
              *(_QWORD *)(v63 + 40LL * v46 + 16) = v64; /*0x1411122f4*/
              if ( *v50 != nullptr ) /*0x1411122ff*/
              {
                p_nameBuffer = &nameBuffer; /*0x141112305*/
                if ( nameBuffer._Mypair._Myval2._Myres >= 0x10 ) /*0x14111230f*/
                  p_nameBuffer = (std::string *)nameBuffer._Mypair._Myval2._Bx._Ptr; /*0x14111230f*/
                PropertyDescriptor = RBX::Reflection::ClassDescriptor::findPropertyDescriptor( /*0x141112315*/
                                       this: *v50,
                                       name: p_nameBuffer->_Mypair._Myval2._Bx._Buf);
                v67 = (RBX::Reflection::PropDescriptor<RBX::Instance,RBX::UniqueId> *)PropertyDescriptor; /*0x14111231a*/
                if ( PropertyDescriptor != nullptr /*0x141112366*/
                  && RBX::Network::isNetworkValueFormatCompatibleWithLocalType(
                       reflectionType: PropertyDescriptor->type,
                       valueFormat: (RBX::Network::NetworkValueFormat)networkFormat,
                       enumId: enumId[0],
                       enumTypeByLocalType: (RBX::DenseHashMap<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type,RBX::Hash<RBX::Reflection::Type const *>,std::equal_to<RBX::Reflection::Type const *> > *)(*(_QWORD *)&numFixedDictionaryEntries.sec + 8LL),
                       localConformance: (RBX::Network::NetworkSchema::LocalConformance *)(v63 + 24 + 40LL * v46))
                  && RBX::Network::Replicator::canReplicateProperty(isCloudEdit: v148, descriptor: v67) )
                {
                  *(_QWORD *)(v63 + 40LL * v46 + 32) = v67; /*0x141112373*/
                  v68 = *(_QWORD *)(v48 + 24); /*0x141112378*/
                  v69 = *(_QWORD *)(v48 + 16); /*0x14111237d*/
                  if ( *(_QWORD *)(v48 + 40) >= (unsigned __int64)(3 * ((v68 - v69) >> 4)) >> 2 ) /*0x141112399*/
                  {
                    RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const *,std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const * const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const *,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const *>,std::equal_to<RBX::Reflection::PropertyDescriptor const *>>::rehash(this: (RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const *,std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const * const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const *,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const *>,std::equal_to<RBX::Reflection::PropertyDescriptor const *> > *)(v48 + 16)); /*0x1411123a0*/
                    v68 = *(_QWORD *)(v48 + 24); /*0x1411123a5*/
                    v67 = *(RBX::Reflection::PropDescriptor<RBX::Instance,RBX::UniqueId> **)(v63 + 40LL * v46 + 32); /*0x1411123aa*/
                    v69 = *(_QWORD *)(v48 + 16); /*0x1411123af*/
                  }
                  v70 = ((v68 - v69) >> 4) - 1; /*0x1411123bb*/
                  v71 = v70 & ((unsigned __int64)v67 + ((unsigned __int64)v67 >> 3)); /*0x1411123c8*/
                  v72 = 0; /*0x1411123cb*/
                  while ( 1 ) /*0x1411123e7*/
                  {
                    v73 = v69 + 16 * v71; /*0x1411123e7*/
                    if ( *(_QWORD *)v73 == *(_QWORD *)(v48 + 48) ) /*0x1411123f0*/
                      break; /*0x1411123f0*/
                    v67 = *(RBX::Reflection::PropDescriptor<RBX::Instance,RBX::UniqueId> **)(v63 + 40LL * v46 + 32); /*0x1411123f2*/
                    if ( *(RBX::Reflection::PropDescriptor<RBX::Instance,RBX::UniqueId> **)v73 == v67 ) /*0x1411123fa*/
                      goto LABEL_104; /*0x1411123fa*/
                    v71 = v70 & (v72 + v71 + 1); /*0x141112402*/
                    if ( ++v72 > v70 ) /*0x14111240b*/
                    {
                      MEMORY[8] = v46; /*0x141112411*/
                      v50 = v133; /*0x141112416*/
                      goto LABEL_105; /*0x14111241b*/
                    }
                  }
                  *(_QWORD *)v73 = v67; /*0x14111241d*/
                  ++*(_QWORD *)(v48 + 40); /*0x141112420*/
LABEL_104:
                  *(_WORD *)(v73 + 8) = v46; /*0x141112425*/
                  v50 = v133; /*0x14111242c*/
                }
              }
LABEL_105:
              v129 = ++v46; /*0x141112439*/
            }
            while ( v46 < *(_WORD *)(v48 + 4) ); /*0x141112445*/
          }
          if ( !RBX::Network::NetworkStream::readBytes( /*0x141112461*/
                  this: &inBitStream,
                  inOutByteArray: &cframePropertyId,
                  numberOfBytesToRead: 2u) )
          {
            std::string::string(this: &m.text, _Ptr: "readFast past end for uint16_t"); /*0x141112bf2*/
            __eh34_enter_wind_state(5, 6); /*0xf1c000000000003c*/
            RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &m.text); /*0x141112c00*/
            throw &pExceptionObject; /*0x141112c10*/
          }
          v74 = __ROL2__(cframePropertyId, 8); /*0x14111246c*/
          cframePropertyId = v74; /*0x141112470*/
          v75 = *v50; /*0x141112475*/
          if ( *v50 != nullptr && v74 != 0xFFFF ) /*0x141112489*/
          {
            v76 = numFixedDictionaryEntries.sec; /*0x14111248f*/
            v77 = *(_QWORD *)(*(_QWORD *)&numFixedDictionaryEntries.sec + 112LL); /*0x141112496*/
            v78 = *(_QWORD *)(*(_QWORD *)&numFixedDictionaryEntries.sec + 104LL); /*0x14111249a*/
            if ( *(_QWORD *)(*(_QWORD *)&numFixedDictionaryEntries.sec + 128LL) >= (unsigned __int64)(3 * ((v77 - v78) >> 4)) >> 2 ) /*0x1411124b7*/
            {
              RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const *,std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const * const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const *,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const *>,std::equal_to<RBX::Reflection::PropertyDescriptor const *>>::rehash(this: (RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const *,std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const * const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const *,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const *>,std::equal_to<RBX::Reflection::PropertyDescriptor const *> > *)(*(_QWORD *)&numFixedDictionaryEntries.sec + 104LL)); /*0x1411124bd*/
              v77 = *(_QWORD *)(*(_QWORD *)&v76 + 112LL); /*0x1411124c2*/
              v75 = *v50; /*0x1411124c6*/
              v78 = *(_QWORD *)(*(_QWORD *)&v76 + 104LL); /*0x1411124c9*/
            }
            v79 = ((v77 - v78) >> 4) - 1; /*0x1411124d4*/
            v80 = v79 & ((unsigned __int64)v75 + ((unsigned __int64)v75 >> 3)); /*0x1411124e1*/
            v81 = 0; /*0x1411124e4*/
            while ( 1 ) /*0x1411124f7*/
            {
              v82 = v78 + 16 * v80; /*0x1411124f7*/
              if ( *(_QWORD *)v82 == *(_QWORD *)(*(_QWORD *)&v76 + 136LL) ) /*0x141112500*/
                break; /*0x141112500*/
              v75 = *v50; /*0x141112502*/
              if ( *(RBX::Reflection::ClassDescriptor **)v82 == *v50 ) /*0x141112508*/
                goto LABEL_117; /*0x141112508*/
              v80 = v79 & (v81 + v80 + 1); /*0x141112510*/
              if ( ++v81 > v79 ) /*0x141112519*/
              {
                v82 = 0; /*0x14111251b*/
                goto LABEL_117; /*0x14111251d*/
              }
            }
            *(_QWORD *)v82 = v75; /*0x14111251f*/
            ++*(_QWORD *)(*(_QWORD *)&v76 + 128LL); /*0x141112522*/
LABEL_117:
            *(_WORD *)(v82 + 8) = v74; /*0x141112529*/
          }
          LODWORD(v45) = 0; /*0x141112532*/
          value = 0; /*0x141112534*/
          RBX::Network::deserializeUnsignedVarint(&value, stream: &inBitStream); /*0x141112541*/
          v83 = v124; /*0x14111254c*/
          v84 = v124 + value; /*0x141112551*/
          if ( v124 < (unsigned __int16)(v124 + value) ) /*0x141112559*/
          {
            do /*0x141112878*/
            {
              RBX::Network::deserializeString( /*0x141112570*/
                value: &nameBuffer,
                stream: &inBitStream,
                maxStringReadSize: DFInt::MaxDataPayloadSize);
              v85 = 5LL * v83; /*0x141112578*/
              v86 = **(_QWORD **)&m.width; /*0x141112580*/
              *(_WORD *)(**(_QWORD **)&m.width + 40LL * v83) = v83; /*0x141112583*/
              argumentCount = 0; /*0x141112588*/
              RBX::Network::deserializeUnsignedVarint(value: &argumentCount, stream: &inBitStream); /*0x141112595*/
              v87 = v86 + 40LL * v83; /*0x14111259a*/
              v88 = *(_QWORD *)(v87 + 16); /*0x1411125a3*/
              v89 = *(_QWORD *)(v87 + 8); /*0x1411125a7*/
              v90 = v88 - v89; /*0x1411125ae*/
              if ( argumentCount >= (unsigned __int64)((v88 - v89) / 24) ) /*0x1411125d5*/
              {
                if ( argumentCount > (unsigned __int64)(v90 / 24) ) /*0x1411125e5*/
                {
                  if ( argumentCount <= (unsigned __int64)((*(_QWORD *)(v87 + 24) - v89) / 24) ) /*0x141112605*/
                  {
                    v91 = argumentCount - v90 / 24; /*0x14111261a*/
                    if ( v91 != 0 ) /*0x14111261d*/
                    {
                      v92 = 24 * v91; /*0x141112623*/
                      memset_0(a1: *(void **)(v87 + 16), Val: 0, Size: 24 * v91); /*0x14111262f*/
                      v88 += v92; /*0x141112634*/
                    }
                    *(_QWORD *)(v87 + 16) = v88; /*0x141112637*/
                  }
                  else
                  {
                    std::vector<RBX::Network::NetworkSchema::Type>::_Resize_reallocate<std::_Value_init_tag>( /*0x141112613*/
                      this: (std::vector<RBX::Network::NetworkSchema::Type> *)(v87 + 8),
                      _Newsize: argumentCount,
                      &_Val);
                  }
                }
              }
              else
              {
                *(_QWORD *)(v87 + 16) = v89 + 24LL * argumentCount; /*0x1411125df*/
              }
              v45 = 0; /*0x14111263b*/
              for ( k = 0; k < argumentCount; ++k ) /*0x141112643*/
              {
                if ( !RBX::Network::NetworkStream::readBytes( /*0x141112666*/
                        this: &inBitStream,
                        inOutByteArray: valueFormat,
                        numberOfBytesToRead: 1u) )
                {
                  std::string::string(this: &m.text, _Ptr: "readFast past end for uint8_t"); /*0x141112cdd*/
                  __eh34_enter_wind_state(5, 6); /*0xf1c0000000000004*/
                  RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &m.text); /*0x141112ceb*/
                  throw &pExceptionObject; /*0x141112cfb*/
                }
                if ( !RBX::Network::NetworkStream::readBytes( /*0x141112682*/
                        this: &inBitStream,
                        inOutByteArray,
                        numberOfBytesToRead: 2u) )
                {
                  std::string::string(this: &m.text, _Ptr: "readFast past end for uint16_t"); /*0x141112cae*/
                  __eh34_enter_wind_state(5, 6); /*0xf1c000000000000c*/
                  RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &m.text); /*0x141112cbc*/
                  throw &pExceptionObject; /*0x141112ccc*/
                }
                inOutByteArray[0] = __ROL2__(inOutByteArray[0], 8); /*0x141112688*/
                v94 = 3LL * k; /*0x141112690*/
                *(_BYTE *)(*(_QWORD *)(v87 + 8) + 8 * v94) = valueFormat[0]; /*0x14111269d*/
                *(_WORD *)(*(_QWORD *)(v87 + 8) + 8 * v94 + 2) = inOutByteArray[0]; /*0x1411126aa*/
                if ( inOutByteArray[0] == 0xFFFF ) /*0x1411126b8*/
                  *(_QWORD *)(*(_QWORD *)(v87 + 8) + 24LL * k + 8) = 0; /*0x1411126dd*/
                else
                  *(_QWORD *)(*(_QWORD *)(v87 + 8) + 24LL * k + 8) = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)&numFixedDictionaryEntries.sec /*0x1411126d2*/
                                                                                           + 152LL)
                                                                               + 8LL * inOutByteArray[0]);
              }
              *(_QWORD *)(v86 + 8 * v85 + 32) = 0; /*0x1411126ee*/
              if ( *v133 != nullptr ) /*0x1411126fe*/
              {
                v95 = &nameBuffer; /*0x141112704*/
                if ( nameBuffer._Mypair._Myval2._Myres >= 0x10 ) /*0x14111270e*/
                  v95 = (std::string *)nameBuffer._Mypair._Myval2._Bx._Ptr; /*0x14111270e*/
                EventDescriptor = RBX::Reflection::ClassDescriptor::findEventDescriptor( /*0x141112714*/
                                    this: *v133,
                                    name: v95->_Mypair._Myval2._Bx._Buf);
                v97 = EventDescriptor; /*0x141112719*/
                if ( EventDescriptor != nullptr ) /*0x14111271f*/
                {
                  v98 = EventDescriptor->signature.arguments._Mypair._Myval2._Myfirst; /*0x141112725*/
                  if ( argumentCount == EventDescriptor->signature.arguments._Mypair._Myval2._Mylast - v98 ) /*0x141112752*/
                  {
                    while ( v98 != v97->signature.arguments._Mypair._Myval2._Mylast ) /*0x14111275c*/
                    {
                      if ( !RBX::Network::isNetworkValueFormatCompatibleWithLocalType( /*0x14111278e*/
                              reflectionType: v98->type,
                              valueFormat: *(RBX::Network::NetworkValueFormat *)(v45 + *(_QWORD *)(v87 + 8)),
                              enumId: *(_WORD *)(v45 + *(_QWORD *)(v87 + 8) + 2),
                              enumTypeByLocalType: (RBX::DenseHashMap<RBX::Reflection::Type const *,RBX::Network::NetworkSchema::Type,RBX::Hash<RBX::Reflection::Type const *>,std::equal_to<RBX::Reflection::Type const *> > *)(*(_QWORD *)&numFixedDictionaryEntries.sec + 8LL),
                              localConformance: (RBX::Network::NetworkSchema::LocalConformance *)(v45 + *(_QWORD *)(v87 + 8) + 16LL)) )
                      {
                        LODWORD(v45) = 0; /*0x14111285d*/
                        goto LABEL_152; /*0x14111285d*/
                      }
                      ++v98; /*0x141112794*/
                      v45 += 24; /*0x141112798*/
                    }
                    *(_QWORD *)(v86 + 8 * v85 + 32) = v97; /*0x14111279e*/
                    v99 = *(_QWORD **)&m.color; /*0x1411127a3*/
                    v100 = *(_QWORD *)(*(_QWORD *)&m.color + 72LL); /*0x1411127a7*/
                    v101 = *(_QWORD *)(*(_QWORD *)&m.color + 64LL); /*0x1411127ab*/
                    if ( *(_QWORD *)(*(_QWORD *)&m.color + 88LL) >= (unsigned __int64)(3 * ((v100 - v101) >> 4)) >> 2 ) /*0x1411127c5*/
                    {
                      RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const *,std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const * const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const *,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const *>,std::equal_to<RBX::Reflection::PropertyDescriptor const *>>::rehash(this: (RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const *,std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const * const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const *,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const *>,std::equal_to<RBX::Reflection::PropertyDescriptor const *> > *)(*(_QWORD *)&m.color + 64LL)); /*0x1411127cb*/
                      v100 = v99[9]; /*0x1411127d0*/
                      v97 = *(RBX::Reflection::EventDescriptor **)(v86 + 8 * v85 + 32); /*0x1411127d4*/
                      v101 = v99[8]; /*0x1411127d9*/
                    }
                    v102 = ((v100 - v101) >> 4) - 1; /*0x1411127e4*/
                    v103 = v102 & ((unsigned __int64)v97 + ((unsigned __int64)v97 >> 3)); /*0x1411127f1*/
                    LODWORD(v45) = 0; /*0x1411127f4*/
                    v104 = 0; /*0x1411127f6*/
                    while ( 1 ) /*0x141112817*/
                    {
                      v105 = v101 + 16 * v103; /*0x141112817*/
                      if ( *(_QWORD *)v105 == v99[12] ) /*0x141112820*/
                        break; /*0x141112820*/
                      v97 = *(RBX::Reflection::EventDescriptor **)(v86 + 8 * v85 + 32); /*0x141112822*/
                      if ( *(RBX::Reflection::EventDescriptor **)v105 == v97 ) /*0x14111282a*/
                        goto LABEL_150; /*0x14111282a*/
                      v103 = v102 & (v104 + v103 + 1); /*0x141112832*/
                      if ( ++v104 > v102 ) /*0x14111283b*/
                      {
                        MEMORY[8] = v124; /*0x141112845*/
                        goto LABEL_152; /*0x141112849*/
                      }
                    }
                    *(_QWORD *)v105 = v97; /*0x14111284b*/
                    ++v99[11]; /*0x14111284e*/
LABEL_150:
                    *(_WORD *)(v105 + 8) = v124; /*0x141112852*/
                  }
                }
              }
LABEL_152:
              v83 = ++v124; /*0x141112870*/
            }
            while ( v124 < v84 ); /*0x141112878*/
            v46 = v129; /*0x14111287e*/
          }
          v47 = v130 + 1; /*0x141112889*/
          v130 = v47; /*0x14111288c*/
          v24 = v140; /*0x141112894*/
          if ( v47 >= classCount ) /*0x14111289c*/
            break; /*0x14111289c*/
          v5 = v142; /*0x14111289e*/
        }
        sec = numFixedDictionaryEntries.sec; /*0x1411128a7*/
      }
      *(_WORD *)(*(_QWORD *)&sec + 248LL) = v46; /*0x1411128ae*/
      v106 = 5LL * v46; /*0x1411128bb*/
      v107 = *(_QWORD *)(*(_QWORD *)&sec + 200LL); /*0x1411128bf*/
      *(_WORD *)(v107 + 8 * v106) = v46; /*0x1411128c7*/
      *(_QWORD *)(v107 + 8 * v106 + 32) = &RBX::Instance::propParent; /*0x1411128d3*/
      *(_BYTE *)(v107 + 8 * v106 + 8) = 28; /*0x1411128d8*/
      *(_WORD *)(v107 + 8 * v106 + 10) = -1; /*0x1411128e2*/
      v108 = v24[1]; /*0x1411128e7*/
      for ( n = *(_QWORD *)(*(_QWORD *)&sec + 176LL); n != v108; n += 112 ) /*0x1411128f6*/
      {
        v110 = *(_WORD *)(*(_QWORD *)&sec + 248LL); /*0x141112910*/
        v111 = *(_QWORD *)(n + 24); /*0x141112919*/
        v112 = *(_QWORD *)(n + 16); /*0x14111291d*/
        if ( *(_QWORD *)(n + 40) >= (unsigned __int64)(3 * ((v111 - v112) >> 4)) >> 2 ) /*0x141112937*/
        {
          RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const *,std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const * const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const *,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const *>,std::equal_to<RBX::Reflection::PropertyDescriptor const *>>::rehash(this: (RBX::detail::DenseHashTable<RBX::Reflection::PropertyDescriptor const *,std::pair<RBX::Reflection::PropertyDescriptor const *,unsigned short>,std::pair<RBX::Reflection::PropertyDescriptor const * const,unsigned short>,RBX::detail::ItemInterfaceMap<RBX::Reflection::PropertyDescriptor const *,unsigned short>,RBX::Hash<RBX::Reflection::PropertyDescriptor const *>,std::equal_to<RBX::Reflection::PropertyDescriptor const *> > *)(n + 16)); /*0x14111293d*/
          v111 = *(_QWORD *)(n + 24); /*0x141112942*/
          v112 = *(_QWORD *)(n + 16); /*0x141112946*/
        }
        v113 = ((v111 - v112) >> 4) - 1; /*0x141112951*/
        v114 = v113 /*0x141112957*/
             & ((unsigned __int64)&RBX::Instance::propParent + ((unsigned __int64)&RBX::Instance::propParent >> 3));
        LODWORD(v45) = 0; /*0x14111295a*/
        v115 = 0; /*0x14111295c*/
        while ( 1 ) /*0x141112977*/
        {
          v116 = v112 + 16 * v114; /*0x141112977*/
          if ( *(_QWORD *)v116 == *(_QWORD *)(n + 48) ) /*0x141112980*/
            break; /*0x141112980*/
          if ( *(RBX::Reflection::RefPropDescriptor<RBX::Instance,RBX::Instance> **)v116 == &RBX::Instance::propParent ) /*0x141112985*/
            goto LABEL_166; /*0x141112985*/
          v114 = v113 & (v115 + v114 + 1); /*0x14111298d*/
          if ( ++v115 > v113 ) /*0x141112996*/
          {
            v116 = 0; /*0x141112998*/
            goto LABEL_166; /*0x14111299b*/
          }
        }
        *(_QWORD *)v116 = &RBX::Instance::propParent; /*0x14111299d*/
        ++*(_QWORD *)(n + 40); /*0x1411129a0*/
LABEL_166:
        *(_WORD *)(v116 + 8) = v110; /*0x1411129a4*/
      }
      if ( inBitStream.numberOfBytesUsed != inBitStream.readOffset ) /*0x1411129bb*/
      {
        LODWORD(numFixedDictionaryEntries.sec) = 0; /*0x1411129bd*/
        RBX::Network::deserializeUnsignedVarint(value: (unsigned int *)&numFixedDictionaryEntries, stream: &inBitStream); /*0x1411129ce*/
        std::vector<std::string>::resize( /*0x1411129e3*/
          this: (std::vector<std::string> *)(*(_QWORD *)&sec + 256LL),
          _Newsize: (unsigned int)(LODWORD(numFixedDictionaryEntries.sec) + 1));
        std::string::assign(this: *(std::string **)(*(_QWORD *)&sec + 256LL), _Ptr: pass, _Count: 0); /*0x1411129fa*/
        for ( ii = 0; /*0x1411129ff*/
              ii < LODWORD(numFixedDictionaryEntries.sec);
              RBX::Network::deserializeString(
                value: (std::string *)(*(_QWORD *)(*(_QWORD *)&sec + 256LL) + 32LL * ii),
                stream: &inBitStream,
                maxStringReadSize: DFInt::MaxDataPayloadSize) )
        {
          ++ii; /*0x141112a10*/
        }
        LODWORD(v45) = 0; /*0x141112a38*/
      }
      if ( inBitStream.numberOfBytesUsed != inBitStream.readOffset ) /*0x141112a40*/
      {
        LODWORD(numFixedDictionaryEntries.sec) = 0; /*0x141112a46*/
        RBX::Network::deserializeUnsignedVarint(value: (unsigned int *)&numFixedDictionaryEntries, stream: &inBitStream); /*0x141112a57*/
        std::vector<std::string>::resize( /*0x141112a6a*/
          this: (std::vector<std::string> *)(*(_QWORD *)&sec + 352LL),
          _Newsize: LODWORD(numFixedDictionaryEntries.sec));
        if ( LODWORD(numFixedDictionaryEntries.sec) != 0 ) /*0x141112a76*/
        {
          do /*0x141112b18*/
          {
            v118 = 32LL * (unsigned int)v45; /*0x141112a92*/
            RBX::Network::deserializeString( /*0x141112aac*/
              value: (std::string *)(v118 + *(_QWORD *)(*(_QWORD *)&sec + 352LL)),
              stream: &inBitStream,
              maxStringReadSize: DFInt::MaxDataPayloadSize);
            v119 = (const std::string *)(*(_QWORD *)(*(_QWORD *)&sec + 352LL) + v118); /*0x141112ab1*/
            if ( *(_QWORD *)(*(_QWORD *)&sec + 304LL) >= (unsigned __int64)(3 /*0x141112aed*/
                                                                          * ((*(_QWORD *)(*(_QWORD *)&sec + 288LL)
                                                                            - *(_QWORD *)(*(_QWORD *)&sec + 280LL))
                                                                           / 40LL)) >> 2 )
              RBX::detail::DenseHashTable<std::string,std::pair<std::string,unsigned short>,std::pair<std::string const,unsigned short>,RBX::detail::ItemInterfaceMap<std::string,unsigned short>,RBX::Hash<std::string>,std::equal_to<std::string>>::rehash(this: (RBX::detail::DenseHashTable<std::string,std::pair<std::string,unsigned short>,std::pair<std::string const ,unsigned short>,RBX::detail::ItemInterfaceMap<std::string,unsigned short>,RBX::Hash<std::string >,std::equal_to<std::string > > *)(*(_QWORD *)&sec + 280LL)); /*0x141112af7*/
            LOWORD(RBX::detail::DenseHashTable<std::string,std::pair<std::string,fbxsdk::FbxNode *>,std::pair<std::string const,fbxsdk::FbxNode *>,RBX::detail::ItemInterfaceMap<std::string,fbxsdk::FbxNode *>,RBX::Hash<std::string>,std::equal_to<std::string>>::insert_unsafe<1,std::string const &>( /*0x141112b0c*/
                     this: (RBX::detail::DenseHashTable<std::string,std::pair<std::string,RBX::CurveAnimation::HierarchyElement const *>,std::pair<std::string const ,RBX::CurveAnimation::HierarchyElement const *>,RBX::detail::ItemInterfaceMap<std::string,RBX::CurveAnimation::HierarchyElement const *>,RBX::Hash<std::string >,std::equal_to<std::string > > *)(*(_QWORD *)&sec + 280LL),
                     key: v119)->second) = v45;
            LODWORD(v45) = v45 + 1; /*0x141112b10*/
          }
          while ( (unsigned int)v45 < LODWORD(numFixedDictionaryEntries.sec) ); /*0x141112b18*/
        }
      }
      if ( FLog::Network != 0 ) /*0x141112b25*/
      {
        v120 = RBX::Time::now<2>(result: &numFixedDictionaryEntries); /*0x141112b2e*/
        v121 = (v120->sec - schemaLoadTimer.start.sec) * 1000.0; /*0x141112b44*/
        FLog::FastLogF( /*0x141112b65*/
          channel: FLog::Network,
          message: "[FLog::Network] Time taken to initialize schema = %f ms",
          arg1: v121,
          arg2: 0.0,
          arg3: 0.0,
          arg4: 0.0);
      }
      **(_BYTE **)&sec = 1; /*0x141112b6a*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&nameBuffer); /*0xf1c0000000000054*/
    }
    if ( nameBuffer._Mypair._Myval2._Myres >= 0x10 ) /*0x141112b77*/
    {
      v122 = nameBuffer._Mypair._Myval2._Bx._Ptr; /*0x141112b7c*/
      if ( nameBuffer._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141112b8b*/
      {
        v122 = *((char **)nameBuffer._Mypair._Myval2._Bx._Ptr - 1); /*0x141112b91*/
        if ( (unsigned __int64)(nameBuffer._Mypair._Myval2._Bx._Ptr - v122 - 8) > 0x1F ) /*0x141112ba0*/
          _invalid_parameter_noinfo_noreturn(); /*0x141112ba2*/
      }
      operator delete(ptr: v122); /*0x141112ba9*/
    }
    nameBuffer._Mypair._Myval2._Mysize = 0; /*0x141112bae*/
    nameBuffer._Mypair._Myval2._Myres = 15; /*0x141112bb6*/
    nameBuffer._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141112bbe*/
    RBX::Network::NetworkStream::~NetworkStream(this: &inBitStream); /*0x141112bc7*/
  }
  __unwind
  {
    RBX::Network::NetworkStream::~NetworkStream(this: &inBitStream); /*0xf1c0000000000048*/
  }
}

// Address: 0x141113b80 | Name: ?typeForVariant@NetworkSchema@Network@RBX@@QEBA?AUType@123@AEBVVariant@Reflection@3@@Z
RBX::Network::NetworkSchema::Type *__fastcall RBX::Network::NetworkSchema::typeForVariant(
        RBX::Network::NetworkSchema *this,
        RBX::Network::NetworkSchema::Type *result,
        const RBX::Reflection::Variant *variant)
{
  RBX::Network::NetworkSchema::Type *v4; // rax
  __int128 v5; // xmm0
  __int64 v6; // xmm1_8
  RBX::Network::NetworkSchema::Type v8; // [rsp+20h] [rbp-28h] BYREF

  v4 = RBX::Network::NetworkSchema::defaultSchemaTypeForReflectionType( /*0x141113b98*/
         result: &v8,
         reflectionType: variant->_type,
         enumTypeByLocalType: &this->enumTypeByLocalType);
  v5 = *(_OWORD *)&v4->valueFormat; /*0x141113b9d*/
  v6 = *(_QWORD *)&v4->localConformance; /*0x141113ba0*/
  *(_OWORD *)&result->valueFormat = v5; /*0x141113ba8*/
  *(_QWORD *)&result->localConformance = v6; /*0x141113bab*/
  return result; /*0x141113bb0*/
}

// END NetworkSchema part 1/1, 10 functions
