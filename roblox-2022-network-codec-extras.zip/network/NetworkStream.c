// NetworkStream -- 2022 Studio + full PDB
// tier 3, 83 functions


// Address: 0x140e45800 | Name: ?SetReadOffsetBytes@NetworkStream@Network@RBX@@QEAAXI@Z
void __fastcall RBX::Network::NetworkStream::SetReadOffsetBytes(
        webrtc::BitrateAllocator *this,
        unsigned int start_rate_bps)
{
  this->last_non_zero_bitrate_bps_ = start_rate_bps; /*0x140e45800*/
}

// Address: 0x141010150 | Name: ??1NetworkStream@Network@RBX@@UEAA@XZ
void __fastcall RBX::Network::NetworkStream::~NetworkStream(RBX::Network::NetworkStream *this)
{
  unsigned __int8 *Myfirst; // rcx

  Myfirst = this->dataVector._Mypair._Myval2._Myfirst; /*0x141010159*/
  if ( Myfirst != nullptr ) /*0x141010160*/
  {
    if ( (unsigned __int8 *)(this->dataVector._Mypair._Myval2._Myend - Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x141010170*/
    {
      if ( (unsigned __int64)&Myfirst[-*((_QWORD *)Myfirst - 1) - 8] > 0x1F ) /*0x141010185*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410101ad*/
      Myfirst = *((unsigned __int8 **)Myfirst - 1); /*0x141010187*/
    }
    operator delete(ptr: Myfirst); /*0x14101018a*/
    this->dataVector._Mypair._Myval2._Myfirst = nullptr; /*0x141010191*/
    this->dataVector._Mypair._Myval2._Mylast = nullptr; /*0x141010195*/
    this->dataVector._Mypair._Myval2._Myend = nullptr; /*0x141010199*/
  }
  this->__vftable = (RBX::Network::NetworkStream_vtbl *)RakNet::AbstractBitStream::`vftable'; /*0x1410101a4*/
}

// Address: 0x14101c760 | Name: ?writeByte@NetworkStream@Network@RBX@@QEAAXE@Z
void __fastcall RBX::Network::NetworkStream::writeByte(RBX::Network::NetworkStream *this, unsigned __int8 value)
{
  unsigned __int8 inByteArray; // [rsp+38h] [rbp+10h] BYREF

  inByteArray = value; /*0x14101c760*/
  RBX::Network::NetworkStream::writeBytes(this, &inByteArray, numberOfBytesToWrite: 1u); /*0x14101c773*/
}

// Address: 0x14101c780 | Name: ?writeUInt32@NetworkStream@Network@RBX@@QEAAXI@Z
void __fastcall RBX::Network::NetworkStream::writeUInt32(RBX::Network::NetworkStream *this, unsigned int value)
{
  unsigned int inByteArray; // [rsp+38h] [rbp+10h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+40h] [rbp+18h] BYREF

  inByteArray = value; /*0x14101c789*/
  RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x14101c79d*/
  RBX::Network::NetworkStream::writeBytes(this, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x14101c7b0*/
}

// Address: 0x14101cbf0 | Name: ?writeInt16@NetworkStream@Network@RBX@@QEAAXF@Z
void __fastcall RBX::Network::NetworkStream::writeInt16(RBX::Network::NetworkStream *this, __int16 value)
{
  __int16 inByteArray; // [rsp+38h] [rbp+10h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+40h] [rbp+18h] BYREF

  inByteArray = value; /*0x14101cbf9*/
  RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 2u); /*0x14101cc0e*/
  RBX::Network::NetworkStream::writeBytes(this, inByteArray: &inOutByteArray, numberOfBytesToWrite: 2u); /*0x14101cc21*/
}

// Address: 0x141021730 | Name: ??$make_shared@VNetworkStream@Network@RBX@@$$V@std@@YA?AV?$shared_ptr@VNetworkStream@Network@RBX@@@0@XZ
std::shared_ptr<RBX::Network::NetworkStream> *__fastcall std::make_shared<RBX::Network::NetworkStream,>(
        std::shared_ptr<RBX::Network::NetworkStream> *result)
{
  char *v2; // rax
  char *v3; // rbx

  v2 = (char *)operator new(size: 0x50u); /*0x141021747*/
  v3 = v2; /*0x14102174c*/
  if ( v2 != nullptr ) /*0x141021757*/
  {
    *(_OWORD *)v2 = 0; /*0x14102175c*/
    *((_DWORD *)v2 + 2) = 1; /*0x14102175f*/
    *((_DWORD *)v2 + 3) = 1; /*0x141021766*/
    *(_QWORD *)v2 = std::_Ref_count_obj2<RBX::Network::NetworkStream>::`vftable'; /*0x141021774*/
    RBX::Network::NetworkStream::NetworkStream(this: (RBX::Network::NetworkStream *)(v2 + 16)); /*0x14102177b*/
  }
  else
  {
    v3 = nullptr; /*0x141021782*/
  }
  result->_Ptr = (RBX::Network::NetworkStream *)(v3 + 16); /*0x141021788*/
  result->_Rep = (std::_Ref_count_base *)v3; /*0x14102178b*/
  return result; /*0x141021792*/
}

// Address: 0x141024350 | Name: ??_E?$_Ref_count_obj2@VNetworkStream@Network@RBX@@@std@@UEAAPEAXI@Z
std::_Ref_count_obj2<RBX::Network::NetworkStream> *__fastcall std::_Ref_count_obj2<RBX::Network::NetworkStream>::`vector deleting destructor'(
        std::_Ref_count_obj2<RBX::Network::NetworkStream> *this,
        char a2)
{
  this->__vftable = (std::_Ref_count_obj2<RBX::Network::NetworkStream>_vtbl *)std::_Ref_count_obj2<RBX::Network::NetworkStream>::`vftable'; /*0x141024360*/
  if ( (a2 & 1) != 0 ) /*0x141024366*/
    operator delete(ptr: this); /*0x14102436d*/
  return this; /*0x141024375*/
}

// Address: 0x14105f4b0 | Name: ?GetNumberOfUnreadBytes@NetworkStream@Network@RBX@@QEBAIXZ
__int64 __fastcall RBX::Network::NetworkStream::GetNumberOfUnreadBytes(RBX::Network::NetworkStream *this)
{
  return this->numberOfBytesUsed - this->readOffset; /*0x14105f4b6*/
}

// Address: 0x1410862a0 | Name: ?writeDouble@NetworkStream@Network@RBX@@QEAAXN@Z
void __fastcall RBX::Network::NetworkStream::writeDouble(RBX::Network::NetworkStream *this, long double value)
{
  long double inByteArray; // [rsp+38h] [rbp+10h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+40h] [rbp+18h] BYREF

  inByteArray = value; /*0x1410862a9*/
  RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 8u); /*0x1410862bf*/
  RBX::Network::NetworkStream::writeBytes(this, inByteArray: &inOutByteArray, numberOfBytesToWrite: 8u); /*0x1410862d2*/
}

// Address: 0x1410862e0 | Name: ?writeFloat@NetworkStream@Network@RBX@@QEAAXM@Z
void __fastcall RBX::Network::NetworkStream::writeFloat(RBX::Network::NetworkStream *this, float value)
{
  float inByteArray; // [rsp+38h] [rbp+10h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+40h] [rbp+18h] BYREF

  inByteArray = value; /*0x1410862e9*/
  RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x1410862ff*/
  RBX::Network::NetworkStream::writeBytes(this, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x141086312*/
}

// Address: 0x141086a40 | Name: ?writeUInt64@NetworkStream@Network@RBX@@QEAAX_K@Z
void __fastcall RBX::Network::NetworkStream::writeUInt64(RBX::Network::NetworkStream *this, unsigned __int64 value)
{
  unsigned __int64 inByteArray; // [rsp+38h] [rbp+10h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+40h] [rbp+18h] BYREF

  inByteArray = value; /*0x141086a49*/
  RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 8u); /*0x141086a5e*/
  RBX::Network::NetworkStream::writeBytes(this, inByteArray: &inOutByteArray, numberOfBytesToWrite: 8u); /*0x141086a71*/
}

// Address: 0x1410b1f50 | Name: ??0NetworkStream@Network@RBX@@QEAA@I@Z
RBX::Network::NetworkStream *__fastcall RBX::Network::NetworkStream::NetworkStream(
        RBX::Network::NetworkStream *this,
        const unsigned int initialBytesToAllocate)
{
  std::vector<unsigned char> *p_dataVector; // rcx
  RBX::Network::NetworkStream *result; // rax

  this->isJoinData = false; /*0x1410b1f6e*/
  this->__vftable = (RBX::Network::NetworkStream_vtbl *)RBX::Network::NetworkStream::`vftable'; /*0x1410b1f79*/
  this->dataVector._Mypair._Myval2._Myfirst = nullptr; /*0x1410b1f7e*/
  this->dataVector._Mypair._Myval2._Mylast = nullptr; /*0x1410b1f82*/
  this->dataVector._Mypair._Myval2._Myend = nullptr; /*0x1410b1f86*/
  p_dataVector = &this->dataVector; /*0x1410b1f8c*/
  __wind /*0xf1c0000000000028*/
  {
    __wind /*0xf1c0000000000030*/
    {
      std::vector<unsigned char>::resize(this: p_dataVector, _Newsize: initialBytesToAllocate); /*0x1410b1f90*/
      this->data = this->dataVector._Mypair._Myval2._Myfirst; /*0x1410b1f99*/
      this->numberOfBytesAllocated = initialBytesToAllocate; /*0x1410b1f9d*/
      this->numberOfBytesUsed = 0; /*0x1410b1fa0*/
      this->readOffset = 0; /*0x1410b1fa3*/
      this->ownedData = true; /*0x1410b1fa6*/
      result = this; /*0x1410b1faa*/
    }
    __unwind
    {
      RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&this->dataVector); /*0x1431ec6bb*/
    }
  }
  __unwind
  {
    RakNet::AbstractBitStream::~AbstractBitStream(this); /*0xf1c0000000000020*/
  }
  return result; /*0x1410b1fad*/
}

// Address: 0x1410b1fd0 | Name: ??0NetworkStream@Network@RBX@@QEAA@PEAEI_N@Z
RBX::Network::NetworkStream *__fastcall RBX::Network::NetworkStream::NetworkStream(
        RBX::Network::NetworkStream *this,
        unsigned __int8 *_data,
        const unsigned int lengthInBytes,
        bool copyData)
{
  unsigned __int8 *Myfirst; // rsi
  size_t v7; // rbp
  RBX::Network::NetworkStream *result; // rax

  __wind /*0xf1c0000000000028*/
  {
    __wind /*0xf1c0000000000030*/
    {
      this->isJoinData = false; /*0x1410b1fed*/
      this->__vftable = (RBX::Network::NetworkStream_vtbl *)RBX::Network::NetworkStream::`vftable'; /*0x1410b1ff8*/
      Myfirst = nullptr; /*0x1410b1ffb*/
      this->dataVector._Mypair._Myval2._Myfirst = nullptr; /*0x1410b1ffd*/
      this->dataVector._Mypair._Myval2._Mylast = nullptr; /*0x1410b2001*/
      this->dataVector._Mypair._Myval2._Myend = nullptr; /*0x1410b2005*/
      this->numberOfBytesAllocated = lengthInBytes; /*0x1410b2009*/
      this->numberOfBytesUsed = lengthInBytes; /*0x1410b200d*/
      this->readOffset = 0; /*0x1410b2011*/
      this->ownedData = copyData; /*0x1410b2014*/
      if ( copyData ) /*0x1410b201b*/
      {
        v7 = lengthInBytes; /*0x1410b201d*/
        if ( (unsigned __int8 *)lengthInBytes > this->dataVector._Mypair._Myval2._Myend ) /*0x1410b2024*/
        {
          std::vector<unsigned char>::_Clear_and_reserve_geometric(this: &this->dataVector, _Newsize: lengthInBytes); /*0x1410b202c*/
          Myfirst = this->dataVector._Mypair._Myval2._Myfirst; /*0x1410b2031*/
        }
        memmove_0(a1: Myfirst, Src: _data, Size: v7); /*0x1410b203e*/
        this->dataVector._Mypair._Myval2._Mylast = &Myfirst[v7]; /*0x1410b2047*/
        _data = this->dataVector._Mypair._Myval2._Myfirst; /*0x1410b204b*/
      }
      this->data = _data; /*0x1410b204f*/
      result = this; /*0x1410b2053*/
    }
    __unwind
    {
      RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&this->dataVector); /*0x1431ec6db*/
    }
  }
  __unwind
  {
    RakNet::AbstractBitStream::~AbstractBitStream(this); /*0xf1c0000000000020*/
  }
  return result; /*0x1410b2056*/
}

// Address: 0x1410b2070 | Name: ??0NetworkStream@Network@RBX@@QEAA@XZ
RBX::Network::NetworkStream *__fastcall RBX::Network::NetworkStream::NetworkStream(RBX::Network::NetworkStream *this)
{
  std::vector<unsigned char> *p_dataVector; // rcx
  RBX::Network::NetworkStream *result; // rax
  std::_Value_init_tag _Val; // [rsp+38h] [rbp+10h] BYREF

  this->isJoinData = false; /*0x1410b2087*/
  this->__vftable = (RBX::Network::NetworkStream_vtbl *)RBX::Network::NetworkStream::`vftable'; /*0x1410b2092*/
  this->dataVector._Mypair._Myval2._Myfirst = nullptr; /*0x1410b2097*/
  this->dataVector._Mypair._Myval2._Mylast = nullptr; /*0x1410b209b*/
  this->dataVector._Mypair._Myval2._Myend = nullptr; /*0x1410b209f*/
  p_dataVector = &this->dataVector; /*0x1410b20ad*/
  __wind /*0xf1c0000000000028*/
  {
    __wind /*0xf1c0000000000030*/
    {
      std::vector<unsigned char>::_Resize_reallocate<std::_Value_init_tag>( /*0x1410b20b1*/
        this: (std::vector<signed char> *)p_dataVector,
        _Newsize: 0x100u,
        &_Val);
      this->data = this->dataVector._Mypair._Myval2._Myfirst; /*0x1410b20ba*/
      this->numberOfBytesAllocated = 256; /*0x1410b20be*/
      this->numberOfBytesUsed = 0; /*0x1410b20c5*/
      this->readOffset = 0; /*0x1410b20c8*/
      this->ownedData = true; /*0x1410b20cb*/
      result = this; /*0x1410b20cf*/
    }
    __unwind
    {
      RBX::HuffmanStream::~HuffmanStream(this: (std::vector<signed char> *)&this->dataVector); /*0x1431ec6bb*/
    }
  }
  __unwind
  {
    RakNet::AbstractBitStream::~AbstractBitStream(this); /*0xf1c0000000000020*/
  }
  return result; /*0x1410b20d2*/
}

// Address: 0x1410b2180 | Name: ?AddBytesAndReallocate@NetworkStream@Network@RBX@@QEAAXI@Z
void __fastcall RBX::Network::NetworkStream::AddBytesAndReallocate(
        RBX::Network::NetworkStream *this,
        const unsigned int numberOfBytesToWrite)
{
  unsigned int numberOfBytesUsed; // edi
  unsigned int numberOfBytesAllocated; // ecx
  unsigned int v5; // edi
  unsigned int v6; // edi
  unsigned int v7; // edi

  numberOfBytesUsed = this->numberOfBytesUsed; /*0x1410b218a*/
  numberOfBytesAllocated = this->numberOfBytesAllocated; /*0x1410b2190*/
  v5 = numberOfBytesToWrite + numberOfBytesUsed; /*0x1410b2193*/
  if ( v5 > numberOfBytesAllocated ) /*0x1410b2197*/
  {
    v6 = v5 - numberOfBytesAllocated; /*0x1410b2199*/
    if ( v6 < DFInt::NetworkStreamMinGrowSize ) /*0x1410b21a6*/
      v6 = DFInt::NetworkStreamMinGrowSize; /*0x1410b21a6*/
    v7 = numberOfBytesAllocated + v6; /*0x1410b21ad*/
    std::vector<unsigned char>::resize(this: &this->dataVector, _Newsize: v7); /*0x1410b21b5*/
    this->data = this->dataVector._Mypair._Myval2._Myfirst; /*0x1410b21c3*/
    this->numberOfBytesAllocated = v7; /*0x1410b21c7*/
  }
}

// Address: 0x1410b21e0 | Name: ?IgnoreBytes@NetworkStream@Network@RBX@@QEAAXI@Z
void __fastcall RBX::Network::NetworkStream::IgnoreBytes(
        RBX::Network::NetworkStream *this,
        const unsigned int numberOfBytes)
{
  this->readOffset += numberOfBytes; /*0x1410b21e0*/
}

// Address: 0x1410b21f0 | Name: ?Reset@NetworkStream@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::NetworkStream::Reset(RBX::Network::NetworkStream *this)
{
  this->isJoinData = false; /*0x1410b21f2*/
  this->numberOfBytesUsed = 0; /*0x1410b21f6*/
  this->readOffset = 0; /*0x1410b21f9*/
}

// Address: 0x1410b2200 | Name: ?ReverseBytes@NetworkStream@Network@RBX@@SAXPEBEPEAEI@Z
void __fastcall RBX::Network::NetworkStream::ReverseBytes(
        unsigned __int8 *inByteArray,
        unsigned __int8 *inOutByteArray,
        unsigned int length)
{
  unsigned int i; // eax
  unsigned int v5; // r9d

  for ( i = 0; i < length; *(inOutByteArray - 1) = inByteArray[v5 - 1] ) /*0x1410b220b*/
  {
    ++inOutByteArray; /*0x1410b2213*/
    v5 = length - i++; /*0x1410b2217*/
  }
}

// Address: 0x1410b2230 | Name: ?SetWriteOffsetBytes@NetworkStream@Network@RBX@@QEAAXI_N@Z
void __fastcall RBX::Network::NetworkStream::SetWriteOffsetBytes(
        RBX::Network::NetworkStream *this,
        unsigned int byteOffset,
        bool eraseDataToCurrentOffset)
{
  unsigned int numberOfBytesUsed; // eax
  unsigned int v6; // eax

  if ( eraseDataToCurrentOffset /*0x1410b224d*/
    && (numberOfBytesUsed = this->numberOfBytesUsed, byteOffset < numberOfBytesUsed)
    && (v6 = numberOfBytesUsed - byteOffset) != 0 )
  {
    memset_0(a1: &this->data[byteOffset], Val: 0, Size: v6); /*0x1410b225a*/
    this->numberOfBytesUsed = byteOffset; /*0x1410b225f*/
  }
  else
  {
    this->numberOfBytesUsed = byteOffset; /*0x1410b226d*/
  }
}

// Address: 0x1410b2b50 | Name: ?readFaces@NetworkStream@Network@RBX@@QEAA?AVFaces@3@XZ
RBX::Axes *__fastcall RBX::Network::NetworkStream::readFaces(RBX::Network::NetworkStream *this, RBX::Axes *result)
{
  RBX::Axes::Axes(this: result, axisMask: 0); /*0x1410b2b65*/
  result->axisMask = RBX::Network::NetworkStream::readInt32(this); /*0x1410b2b77*/
  return result; /*0x1410b2b72*/
}

// Address: 0x1410b2b90 | Name: ?readBool@NetworkStream@Network@RBX@@QEAA_NXZ
bool __fastcall RBX::Network::NetworkStream::readBool(RBX::Network::NetworkStream *this)
{
  unsigned int readOffset; // eax
  unsigned int v2; // r9d
  unsigned __int8 v3; // r8
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  readOffset = this->readOffset; /*0x1410b2b97*/
  v2 = readOffset + 1; /*0x1410b2b9a*/
  if ( readOffset + 1 > this->numberOfBytesUsed ) /*0x1410b2ba2*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint8_t"); /*0x1410b2bcd*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b2bdd*/
      throw &pExceptionObject; /*0x1410b2bee*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  v3 = this->data[readOffset]; /*0x1410b2baa*/
  this->readOffset = v2; /*0x1410b2baf*/
  return v3 != 0; /*0x1410b2bb9*/
}

// Address: 0x1410b2c00 | Name: ?readBrickColor@NetworkStream@Network@RBX@@QEAA?AVBrickColor@3@XZ
RBX::BrickColor *__fastcall RBX::Network::NetworkStream::readBrickColor(
        RBX::Network::NetworkStream *this,
        RBX::BrickColor *result)
{
  unsigned __int16 UInt16; // ax

  UInt16 = RBX::Network::NetworkStream::readUInt16(this); /*0x1410b2c09*/
  RBX::BrickColor::BrickColor(this: result, number: UInt16); /*0x1410b2c14*/
  return result; /*0x1410b2c1c*/
}

// Address: 0x1410b2c30 | Name: ?readByte@NetworkStream@Network@RBX@@QEAAEXZ
__int64 __fastcall RBX::Network::NetworkStream::readByte(RBX::Network::NetworkStream *this)
{
  unsigned int readOffset; // eax
  unsigned int v2; // r8d
  __int64 result; // rax
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  readOffset = this->readOffset; /*0x1410b2c37*/
  v2 = readOffset + 1; /*0x1410b2c3a*/
  if ( readOffset + 1 > this->numberOfBytesUsed ) /*0x1410b2c42*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint8_t"); /*0x1410b2c66*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b2c76*/
      throw &pExceptionObject; /*0x1410b2c87*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  result = this->data[readOffset]; /*0x1410b2c4a*/
  this->readOffset = v2; /*0x1410b2c4e*/
  return result; /*0x1410b2c52*/
}

// Address: 0x1410b2c90 | Name: ?readBytes@NetworkStream@Network@RBX@@QEAA_NPEAXI@Z
char __fastcall RBX::Network::NetworkStream::readBytes(
        RBX::Network::NetworkStream *this,
        void *inOutByteArray,
        unsigned int numberOfBytesToRead)
{
  __int64 readOffset; // rcx

  readOffset = this->readOffset; /*0x1410b2ca0*/
  if ( (unsigned int)readOffset + numberOfBytesToRead > this->numberOfBytesUsed ) /*0x1410b2cac*/
    return 0; /*0x1410b2cae*/
  memcpy_0(a1: inOutByteArray, Src: &this->data[readOffset], Size: numberOfBytesToRead); /*0x1410b2cc8*/
  this->readOffset += numberOfBytesToRead; /*0x1410b2ccd*/
  return 1; /*0x1410b2cb0*/
}

// Address: 0x1410b2ce0 | Name: ?readVector3@NetworkStream@Network@RBX@@QEAA?AVVector3@3@XZ
RBX::Vector3 *__fastcall RBX::Network::NetworkStream::readVector3(
        RBX::Network::NetworkStream *this,
        RBX::Vector3 *result)
{
  float Float; // xmm0_4

  *(_QWORD *)&result->x = 0; /*0x1410b2cef*/
  result->z = 0.0; /*0x1410b2cf5*/
  result->x = RBX::Network::NetworkStream::readFloat(this); /*0x1410b2d00*/
  result->y = RBX::Network::NetworkStream::readFloat(this); /*0x1410b2d0c*/
  Float = RBX::Network::NetworkStream::readFloat(this); /*0x1410b2d11*/
  result->z = Float; /*0x1410b2d1e*/
  return result; /*0x1410b2d16*/
}

// Address: 0x1410b2d30 | Name: ?readColor3uint8@NetworkStream@Network@RBX@@QEAA?AVColor3uint8@3@XZ
RBX::Color3uint8 *__fastcall RBX::Network::NetworkStream::readColor3uint8(
        RBX::Network::NetworkStream *this,
        RBX::Color3uint8 *result)
{
  __int64 readOffset; // rax
  __int64 v4; // r9
  unsigned int numberOfBytesUsed; // r11d
  unsigned __int8 *data; // rbx
  unsigned __int8 v7; // cl
  __int64 v8; // r10
  unsigned __int8 v9; // cl
  unsigned __int8 v10; // cl
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  *(_WORD *)&result->r = 0; /*0x1410b2d3c*/
  result->b = 0; /*0x1410b2d41*/
  readOffset = this->readOffset; /*0x1410b2d45*/
  v4 = (unsigned int)(readOffset + 1); /*0x1410b2d48*/
  numberOfBytesUsed = this->numberOfBytesUsed; /*0x1410b2d4c*/
  if ( (unsigned int)v4 > numberOfBytesUsed ) /*0x1410b2d53*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint8_t"); /*0x1410b2dd8*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000000c*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b2de8*/
    throw &pExceptionObject; /*0x1410b2df9*/
  }
  data = this->data; /*0x1410b2d55*/
  v7 = data[readOffset]; /*0x1410b2d59*/
  this->readOffset = v4; /*0x1410b2d5d*/
  result->r = v7; /*0x1410b2d61*/
  v8 = (unsigned int)(readOffset + 2); /*0x1410b2d63*/
  if ( (unsigned int)v8 > numberOfBytesUsed ) /*0x1410b2d6a*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint8_t"); /*0x1410b2da5*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000014*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b2db5*/
    throw &pExceptionObject; /*0x1410b2dc6*/
  }
  v9 = data[v4]; /*0x1410b2d6c*/
  this->readOffset = v8; /*0x1410b2d71*/
  result->g = v9; /*0x1410b2d75*/
  if ( (int)readOffset + 3 > numberOfBytesUsed ) /*0x1410b2d7f*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint8_t"); /*0x1410b2e0b*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000004*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b2e1b*/
    throw &pExceptionObject; /*0x1410b2e2c*/
  }
  v10 = data[v8]; /*0x1410b2d81*/
  this->readOffset = readOffset + 3; /*0x1410b2d86*/
  result->b = v10; /*0x1410b2d8a*/
  return result; /*0x1410b2d90*/
}

// Address: 0x1410b2e40 | Name: ?readColorSequence@NetworkStream@Network@RBX@@QEAA?AVColorSequence@3@XZ
RBX::ColorSequence *__fastcall RBX::Network::NetworkStream::readColorSequence(
        RBX::Network::NetworkStream *this,
        RBX::ColorSequence *result)
{
  unsigned int UInt32; // eax
  __int64 v5; // r14
  __int64 v6; // rsi
  __int64 v7; // rbx
  unsigned __int64 v8; // rdi
  void *v9; // rax
  void *v10; // rcx
  char *v11; // rax
  RBX::ColorSequenceKeypoint *v12; // rcx
  RBX::ColorSequenceKeypoint *v13; // r8
  RBX::ColorSequenceKeypoint *v14; // r9
  __int64 v15; // rdx
  _QWORD *v16; // rax
  float Float; // xmm9_4
  float v18; // xmm8_4
  float v19; // xmm7_4
  float v20; // xmm6_4
  float v21; // xmm0_4
  RBX::ColorSequenceKeypoint *Myfirst; // rax
  RBX::ColorSequenceKeypoint *v23; // r8
  std::vector<RBX::ColorSequenceKeypoint> keys; // [rsp+20h] [rbp-C8h] BYREF
  std::string m; // [rsp+38h] [rbp-B0h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+58h] [rbp-90h] BYREF

  UInt32 = RBX::Network::NetworkStream::readUInt32(this); /*0x1410b2e73*/
  v5 = UInt32; /*0x1410b2e78*/
  if ( UInt32 > 0x14 ) /*0x1410b2e7e*/
  {
    std::string::string(this: &m, _Ptr: "Number sequence is too big"); /*0x1410b3062*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b3072*/
      throw &pExceptionObject; /*0x1410b3083*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  v6 = (unsigned int)v5; /*0x1410b2e84*/
  memset(&keys, 0, sizeof(keys)); /*0x1410b2e8a*/
  v7 = 0; /*0x1410b2e90*/
  if ( UInt32 != 0 ) /*0x1410b2e99*/
  {
    v8 = 20 * v5; /*0x1410b2ea3*/
    if ( (unsigned __int64)(20 * v5) < 0x1000 ) /*0x1410b2eb2*/
    {
      if ( v8 != 0 ) /*0x1410b2eed*/
      {
        v11 = (char *)operator new(size: 20 * v5); /*0x1410b2ef2*/
        v12 = (RBX::ColorSequenceKeypoint *)v11; /*0x1410b2ef7*/
        v13 = (RBX::ColorSequenceKeypoint *)&v11[v8]; /*0x1410b2efa*/
        v14 = (RBX::ColorSequenceKeypoint *)v11; /*0x1410b2efe*/
      }
      else
      {
        v11 = nullptr; /*0x1410b2f03*/
        v12 = nullptr; /*0x1410b2f06*/
        v13 = nullptr; /*0x1410b2f09*/
        v14 = nullptr; /*0x1410b2f0d*/
      }
    }
    else
    {
      if ( v8 + 39 < v8 ) /*0x1410b2ebb*/
        std::_Throw_bad_array_new_length(); /*0x1410b3050*/
      v9 = operator new(size: v8 + 39); /*0x1410b2ec1*/
      v10 = v9; /*0x1410b2ec6*/
      if ( v9 == nullptr ) /*0x1410b2ecc*/
LABEL_19:
        _invalid_parameter_noinfo_noreturn(); /*0x1410b300d*/
      v11 = (char *)(((unsigned __int64)v9 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x1410b2ed6*/
      *((_QWORD *)v11 - 1) = v10; /*0x1410b2eda*/
      v12 = (RBX::ColorSequenceKeypoint *)v11; /*0x1410b2ede*/
      v13 = (RBX::ColorSequenceKeypoint *)&v11[v8]; /*0x1410b2ee1*/
      v14 = (RBX::ColorSequenceKeypoint *)v11; /*0x1410b2ee5*/
    }
    v15 = v5; /*0x1410b2f10*/
    keys._Mypair._Myval2._Myfirst = v14; /*0x1410b2f13*/
    keys._Mypair._Myval2._Myend = v13; /*0x1410b2f18*/
    v16 = v11 + 12; /*0x1410b2f1d*/
    do /*0x1410b2f36*/
    {
      v12->time = 0.0; /*0x1410b2f21*/
      *(v16 - 1) = 0; /*0x1410b2f23*/
      *v16 = 0; /*0x1410b2f27*/
      ++v12; /*0x1410b2f2a*/
      v16 = (_QWORD *)((char *)v16 + 20); /*0x1410b2f2e*/
      --v15; /*0x1410b2f32*/
    }
    while ( v15 != 0 ); /*0x1410b2f36*/
    keys._Mypair._Myval2._Mylast = v12; /*0x1410b2f38*/
  }
  __wind /*0xf1c0000000000028*/
  {
    if ( (_DWORD)v5 != 0 ) /*0x1410b2f40*/
    {
      do /*0x1410b2fa4*/
      {
        Float = RBX::Network::NetworkStream::readFloat(this); /*0x1410b2f4a*/
        v18 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b2f56*/
        v19 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b2f62*/
        v20 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b2f6d*/
        v21 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b2f73*/
        Myfirst = keys._Mypair._Myval2._Myfirst; /*0x1410b2f78*/
        keys._Mypair._Myval2._Myfirst[v7].time = Float; /*0x1410b2f7d*/
        Myfirst[v7].value.r = v18; /*0x1410b2f83*/
        Myfirst[v7].value.g = v19; /*0x1410b2f8a*/
        Myfirst[v7].value.b = v20; /*0x1410b2f90*/
        Myfirst[v7++].envelope = v21; /*0x1410b2f96*/
        --v6; /*0x1410b2fa0*/
      }
      while ( v6 != 0 ); /*0x1410b2fa4*/
    }
    RBX::ColorSequence::ColorSequence(this: result, &keys, exceptions: false); /*0x1410b2fb1*/
  }
  __unwind
  {
    std::vector<GradientPoint>::_Tidy(this: (std::vector<webrtc::RtpPacketizerAv1::Packet> *)&keys); /*0xf1c0000000000020*/
  }
  v23 = keys._Mypair._Myval2._Myfirst; /*0x1410b2fb7*/
  if ( keys._Mypair._Myval2._Myfirst != nullptr ) /*0x1410b2fbf*/
  {
    if ( (unsigned __int64)(20 * (keys._Mypair._Myval2._Myend - keys._Mypair._Myval2._Myfirst)) >= 0x1000 ) /*0x1410b2ff6*/
    {
      v23 = *(RBX::ColorSequenceKeypoint **)&keys._Mypair._Myval2._Myfirst[-1].value.b; /*0x1410b2ffc*/
      if ( (unsigned __int64)((char *)keys._Mypair._Myval2._Myfirst - (char *)v23 - 8) > 0x1F ) /*0x1410b300b*/
        goto LABEL_19; /*0x1410b300b*/
    }
    operator delete(ptr: v23); /*0x1410b3017*/
  }
  return result; /*0x1410b301f*/
}

// Address: 0x1410b3090 | Name: ?readColorSequenceKeypoint@NetworkStream@Network@RBX@@QEAA?AVColorSequenceKeypoint@3@XZ
RBX::ColorSequenceKeypoint *__fastcall RBX::Network::NetworkStream::readColorSequenceKeypoint(
        RBX::Network::NetworkStream *this,
        RBX::ColorSequenceKeypoint *result)
{
  float Float; // xmm7_4
  float v5; // xmm6_4
  float v6; // xmm0_4
  float v7; // xmm0_4

  *(_QWORD *)&result->time = 0; /*0x1410b30a1*/
  *(_QWORD *)&result->value.g = 0; /*0x1410b30a7*/
  result->envelope = 0.0; /*0x1410b30ae*/
  result->time = RBX::Network::NetworkStream::readFloat(this); /*0x1410b30be*/
  Float = RBX::Network::NetworkStream::readFloat(this); /*0x1410b30ca*/
  v5 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b30d5*/
  v6 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b30d8*/
  result->value.r = Float; /*0x1410b30e0*/
  result->value.g = v5; /*0x1410b30e5*/
  result->value.b = v6; /*0x1410b30ea*/
  v7 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b30ef*/
  result->envelope = v7; /*0x1410b3106*/
  return result; /*0x1410b30f4*/
}

// Address: 0x1410b3120 | Name: ?readCoordinateFrame@NetworkStream@Network@RBX@@QEAA?AVCoordinateFrame@3@XZ
RBX::CoordinateFrame *__fastcall RBX::Network::NetworkStream::readCoordinateFrame(
        RBX::Network::NetworkStream *this,
        RBX::CoordinateFrame *result)
{
  unsigned int readOffset; // eax
  unsigned int v5; // r8d
  int v6; // edx
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  *(_QWORD *)&result->rotation.elt[0][0] = 1065353216; /*0x1410b3133*/
  *(_QWORD *)&result->rotation.elt[0][2] = 0; /*0x1410b313c*/
  *(_QWORD *)&result->rotation.elt[1][1] = 1065353216; /*0x1410b3140*/
  *(_QWORD *)&result->rotation.elt[2][0] = 0; /*0x1410b3148*/
  *(_QWORD *)&result->rotation.elt[2][2] = 1065353216; /*0x1410b314c*/
  *(_QWORD *)&result->translation.y = 0; /*0x1410b3154*/
  result->translation.x = RBX::Network::NetworkStream::readFloat(this); /*0x1410b315d*/
  result->translation.y = RBX::Network::NetworkStream::readFloat(this); /*0x1410b316a*/
  result->translation.z = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3177*/
  readOffset = this->readOffset; /*0x1410b317c*/
  v5 = readOffset + 1; /*0x1410b317f*/
  if ( readOffset + 1 > this->numberOfBytesUsed ) /*0x1410b3187*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint8_t"); /*0x1410b31d3*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b31e3*/
      throw &pExceptionObject; /*0x1410b31f4*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  v6 = this->data[readOffset]; /*0x1410b318f*/
  this->readOffset = v5; /*0x1410b3193*/
  if ( (_BYTE)v6 != 0 ) /*0x1410b3199*/
    RBX::Math::idToMatrix3(orientId: v6 - 1, matrix: &result->rotation); /*0x1410b31a1*/
  else
    RBX::Network::Compressor::readRotation(bitStream: this, rotation: &result->rotation); /*0x1410b31ae*/
  return result; /*0x1410b31b6*/
}

// Address: 0x1410b3200 | Name: ?readDateTime@NetworkStream@Network@RBX@@QEAA?AVDateTime@3@XZ
RBX::DateTime *__fastcall RBX::Network::NetworkStream::readDateTime(
        RBX::Network::NetworkStream *this,
        RBX::DateTime *result)
{
  unsigned int readOffset; // eax
  unsigned int v4; // r10d
  __int64 v5; // r9
  unsigned __int64 v6; // r9
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  readOffset = this->readOffset; /*0x1410b320c*/
  v4 = readOffset + 8; /*0x1410b320f*/
  if ( readOffset + 8 > this->numberOfBytesUsed ) /*0x1410b3217*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for int64_t"); /*0x1410b3296*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b32a6*/
      throw &pExceptionObject; /*0x1410b32b7*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  v5 = *(_QWORD *)&this->data[readOffset]; /*0x1410b3220*/
  this->readOffset = v4; /*0x1410b3224*/
  v6 = __ROL8__(v5, 32); /*0x1410b3228*/
  RBX::DateTime::fromUnixTimestampMillis( /*0x1410b3279*/
    result,
    timestampMillis: (((v6 << 16) ^ ((v6 << 16) ^ (v6 >> 16)) & 0xFFFF0000FFFFLL) << 8)
  ^ ((((v6 << 16) ^ ((v6 << 16) ^ (v6 >> 16)) & 0xFFFF0000FFFFLL) << 8)
   ^ (((v6 << 16) ^ ((v6 << 16) ^ (v6 >> 16)) & 0xFFFF0000FFFFLL) >> 8))
  & 0xFF00FF00FF00FFLL);
  return result; /*0x1410b3281*/
}

// Address: 0x1410b32c0 | Name: ?readDouble@NetworkStream@Network@RBX@@QEAANXZ
long double __fastcall RBX::Network::NetworkStream::readDouble(RBX::Network::NetworkStream *this)
{
  unsigned int readOffset; // eax
  unsigned int v2; // r9d
  __int64 v3; // r8
  unsigned __int64 v4; // r8
  unsigned __int64 v5; // rdx
  long double result; // xmm0_8
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  readOffset = this->readOffset; /*0x1410b32c7*/
  v2 = readOffset + 8; /*0x1410b32ca*/
  if ( readOffset + 8 > this->numberOfBytesUsed ) /*0x1410b32d2*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for double"); /*0x1410b3355*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b3365*/
      throw &pExceptionObject; /*0x1410b3376*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  v3 = *(_QWORD *)&this->data[readOffset]; /*0x1410b32da*/
  this->readOffset = v2; /*0x1410b32de*/
  v4 = __ROL8__(v3, 32); /*0x1410b32e2*/
  v5 = (v4 << 16) ^ ((v4 << 16) ^ (v4 >> 16)) & 0xFFFF0000FFFFLL; /*0x1410b3308*/
  *(_QWORD *)&result = (v5 << 8) ^ ((v5 << 8) ^ (v5 >> 8)) & 0xFF00FF00FF00FFLL; /*0x1410b3338*/
  return result; /*0x1410b3341*/
}

// Address: 0x1410b3380 | Name: ?readFloat@NetworkStream@Network@RBX@@QEAAMXZ
float __fastcall RBX::Network::NetworkStream::readFloat(RBX::Network::NetworkStream *this)
{
  unsigned int readOffset; // eax
  unsigned int v2; // r9d
  unsigned int v3; // r8d
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  readOffset = this->readOffset; /*0x1410b3387*/
  v2 = readOffset + 4; /*0x1410b338a*/
  if ( readOffset + 4 > this->numberOfBytesUsed ) /*0x1410b3392*/
  {
    std::string::string(this: &m, _Ptr: (const char *const)&RBX::Network::NetworkStream::`vftable'[3]); /*0x1410b33e4*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b33f4*/
      throw &pExceptionObject; /*0x1410b3405*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  v3 = *(_DWORD *)&this->data[readOffset]; /*0x1410b339a*/
  this->readOffset = v2; /*0x1410b339e*/
  return COERCE_FLOAT(__ROL4__((v3 << 8) ^ ((v3 << 8) ^ (v3 >> 8)) & 0xFF00FF, 16)); /*0x1410b33d0*/
}

// Address: 0x1410b3410 | Name: ?readFont@NetworkStream@Network@RBX@@QEAA?AVFontInfo@Text@3@H@Z
RBX::Text::FontInfo *__fastcall RBX::Network::NetworkStream::readFont(
        RBX::Network::NetworkStream *this,
        RBX::Text::FontInfo *result,
        int maxStringReadSize)
{
  unsigned __int16 UInt16; // ax
  unsigned int readOffset; // eax
  RBX::Text::Style v8; // edx
  const rtc::webrtc_checks_impl::ToStringVal *v9; // rax
  unsigned __int64 v10; // rcx
  unsigned __int64 v11; // r9
  char *Ptr; // rdx
  RBX::network_stream_exception_vtbl *v13; // r8
  RBX::network_stream_exception *p_pExceptionObject; // rax
  RBX::network_stream_exception *v15; // rax
  char *v16; // rcx
  const rtc::webrtc_checks_impl::ToStringVal *v17; // rax
  unsigned __int64 v18; // rcx
  unsigned __int64 v19; // r9
  char *v20; // rdx
  RBX::network_stream_exception_vtbl *v21; // r8
  RBX::network_stream_exception *v22; // rax
  RBX::network_stream_exception *v23; // rax
  RBX::network_stream_exception_vtbl *what; // rcx
  char *v25; // rcx
  RBX::Text::FontInfo *v26; // rax
  RBX::network_stream_exception pExceptionObject; // [rsp+28h] [rbp-58h] BYREF
  std::string v28; // [rsp+60h] [rbp-20h] BYREF

  __wind /*0xf1c0000000000054*/
  {
    RBX::Text::FontInfo::FontInfo(this: result); /*0x1410b343a*/
    UInt16 = RBX::Network::NetworkStream::readUInt16(this); /*0x1410b3449*/
    RBX::Text::FontInfo::setWeight(this: result, value: (RBX::Text::Weight)UInt16); /*0x1410b3454*/
    readOffset = this->readOffset; /*0x1410b3459*/
    if ( readOffset + 1 > this->numberOfBytesUsed ) /*0x1410b3464*/
    {
      std::string::string(this: &v28, _Ptr: "readFast past end for uint8_t"); /*0x1410b3654*/
      __eh34_enter_wind_state(0, 1); /*0xf1c0000000000010*/
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &v28); /*0x1410b3662*/
      throw &pExceptionObject; /*0x1410b3672*/
    }
    __eh34_enter_wind_state(0, 1); /*0xf1c000000000004c*/
    v8 = this->data[readOffset]; /*0x1410b3470*/
    this->readOffset = readOffset + 1; /*0x1410b3474*/
    RBX::Text::FontInfo::setStyle(this: result, value: v8); /*0x1410b347b*/
    v9 = (const rtc::webrtc_checks_impl::ToStringVal *)RBX::Network::NetworkStream::readString( /*0x1410b348a*/
                                                         this,
                                                         result: &v28,
                                                         maxStringReadSize);
    std::string::string(this: (rtc::webrtc_checks_impl::ToStringVal *)&pExceptionObject, __that: v9); /*0x1410b3497*/
    v10 = 0; /*0x1410b349c*/
    v11 = *(_QWORD *)&pExceptionObject._Data._DoFree; /*0x1410b349e*/
    if ( *(_QWORD *)&pExceptionObject._Data._DoFree != 0 ) /*0x1410b34a5*/
    {
      Ptr = pExceptionObject.msg._Mypair._Myval2._Bx._Ptr; /*0x1410b34a7*/
      v13 = pExceptionObject.__vftable; /*0x1410b34ab*/
      do /*0x1410b34e4*/
      {
        p_pExceptionObject = &pExceptionObject; /*0x1410b34b0*/
        if ( (unsigned __int64)Ptr >= 0x10 ) /*0x1410b34b8*/
          p_pExceptionObject = (RBX::network_stream_exception *)v13; /*0x1410b34b8*/
        if ( *((_BYTE *)&p_pExceptionObject->__vftable + v10) == 92 ) /*0x1410b34c0*/
        {
          v15 = &pExceptionObject; /*0x1410b34c2*/
          if ( (unsigned __int64)Ptr >= 0x10 ) /*0x1410b34ca*/
            v15 = (RBX::network_stream_exception *)v13; /*0x1410b34ca*/
          *((_BYTE *)&v15->__vftable + v10) = 47; /*0x1410b34ce*/
          Ptr = pExceptionObject.msg._Mypair._Myval2._Bx._Ptr; /*0x1410b34d2*/
          v11 = *(_QWORD *)&pExceptionObject._Data._DoFree; /*0x1410b34d6*/
          v13 = pExceptionObject.__vftable; /*0x1410b34da*/
        }
        ++v10; /*0x1410b34de*/
      }
      while ( v10 < v11 ); /*0x1410b34e4*/
    }
    RBX::Text::FontInfo::setFamily(this: result, value: (RBX::ContentId *)&pExceptionObject); /*0x1410b34ed*/
    if ( __eh34_unwind(1) ) /*0xf1c0000000000038*/
    {
unwind_state_1:
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v28); /*0xf1c000000000003c*/
      __eh34_continue_unwinding(1, 0); /*0xf1c0000000000040*/
    }
    __eh34_exit_wind_state(1, 0); /*0xf1c0000000000044*/
    if ( v28._Mypair._Myval2._Myres >= 0x10 ) /*0x1410b34fb*/
    {
      v16 = v28._Mypair._Myval2._Bx._Ptr; /*0x1410b3500*/
      if ( v28._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410b350e*/
      {
        v16 = *((char **)v28._Mypair._Myval2._Bx._Ptr - 1); /*0x1410b3514*/
        if ( (unsigned __int64)(v28._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x1410b3523*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410b3525*/
      }
      operator delete(ptr: v16); /*0x1410b352c*/
    }
    v17 = (const rtc::webrtc_checks_impl::ToStringVal *)RBX::Network::NetworkStream::readString( /*0x1410b353b*/
                                                          this,
                                                          result: &v28,
                                                          maxStringReadSize);
    __eh34_enter_wind_state(0, 1); /*0xf1c0000000000030*/
    std::string::string(this: (rtc::webrtc_checks_impl::ToStringVal *)&pExceptionObject, __that: v17); /*0x1410b3548*/
    v18 = 0; /*0x1410b354d*/
    v19 = *(_QWORD *)&pExceptionObject._Data._DoFree; /*0x1410b354f*/
    if ( *(_QWORD *)&pExceptionObject._Data._DoFree != 0 ) /*0x1410b3556*/
    {
      v20 = pExceptionObject.msg._Mypair._Myval2._Bx._Ptr; /*0x1410b3558*/
      v21 = pExceptionObject.__vftable; /*0x1410b355c*/
      do /*0x1410b3594*/
      {
        v22 = &pExceptionObject; /*0x1410b3560*/
        if ( (unsigned __int64)v20 >= 0x10 ) /*0x1410b3568*/
          v22 = (RBX::network_stream_exception *)v21; /*0x1410b3568*/
        if ( *((_BYTE *)&v22->__vftable + v18) == 92 ) /*0x1410b3570*/
        {
          v23 = &pExceptionObject; /*0x1410b3572*/
          if ( (unsigned __int64)v20 >= 0x10 ) /*0x1410b357a*/
            v23 = (RBX::network_stream_exception *)v21; /*0x1410b357a*/
          *((_BYTE *)&v23->__vftable + v18) = 47; /*0x1410b357e*/
          v20 = pExceptionObject.msg._Mypair._Myval2._Bx._Ptr; /*0x1410b3582*/
          v19 = *(_QWORD *)&pExceptionObject._Data._DoFree; /*0x1410b3586*/
          v21 = pExceptionObject.__vftable; /*0x1410b358a*/
        }
        ++v18; /*0x1410b358e*/
      }
      while ( v18 < v19 ); /*0x1410b3594*/
    }
    __wind /*0xf1c0000000000024*/
    {
      RBX::Text::FontInfo::setCachedFaceId(this: result, value: (const RBX::ContentId *)&pExceptionObject); /*0x1410b359d*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&pExceptionObject); /*0xf1c000000000001c*/
    }
    if ( pExceptionObject.msg._Mypair._Myval2._Bx._Ptr >= (char *)0x10 ) /*0x1410b35ab*/
    {
      what = pExceptionObject.__vftable; /*0x1410b35b0*/
      if ( (unsigned __int64)(pExceptionObject.msg._Mypair._Myval2._Bx._Ptr + 1) >= 0x1000 ) /*0x1410b35be*/
      {
        what = (RBX::network_stream_exception_vtbl *)pExceptionObject.__vftable[-1].what; /*0x1410b35c4*/
        if ( (unsigned __int64)((char *)pExceptionObject.__vftable - (char *)what - 8) > 0x1F ) /*0x1410b35d3*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410b35d5*/
      }
      operator delete(ptr: what); /*0x1410b35dc*/
    }
    *(_QWORD *)&pExceptionObject._Data._DoFree = 0; /*0x1410b35e1*/
    pExceptionObject.msg._Mypair._Myval2._Bx._Ptr = (char *)15; /*0x1410b35e9*/
    LOBYTE(pExceptionObject.__vftable) = 0; /*0x1410b35f1*/
    if ( v28._Mypair._Myval2._Myres >= 0x10 ) /*0x1410b35fd*/
    {
      v25 = v28._Mypair._Myval2._Bx._Ptr; /*0x1410b3602*/
      if ( v28._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410b3610*/
      {
        v25 = *((char **)v28._Mypair._Myval2._Bx._Ptr - 1); /*0x1410b3616*/
        if ( (unsigned __int64)(v28._Mypair._Myval2._Bx._Ptr - v25 - 8) > 0x1F ) /*0x1410b3625*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410b3627*/
      }
      operator delete(ptr: v25); /*0x1410b362e*/
    }
    v26 = result; /*0x1410b3633*/
    if ( __eh34_unwind(1) ) /*0xf1c000000000006c*/
      goto unwind_state_1; /*0xf1c000000000006c*/
    __eh34_exit_wind_state(1, 0); /*0xf1c0000000000070*/
  }
  __unwind
  {
    RBX::Text::FontInfo::~FontInfo(this: result); /*0x1431ec6fe*/
  }
  return v26; /*0x1410b3636*/
}

// Address: 0x1410b3680 | Name: ?readInt16@NetworkStream@Network@RBX@@QEAAFXZ
__int16 __fastcall RBX::Network::NetworkStream::readInt16(RBX::Network::NetworkStream *this)
{
  unsigned int readOffset; // eax
  unsigned int v2; // r8d
  __int16 v3; // ax
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  readOffset = this->readOffset; /*0x1410b3687*/
  v2 = readOffset + 2; /*0x1410b368a*/
  if ( readOffset + 2 > this->numberOfBytesUsed ) /*0x1410b3692*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for int16_t"); /*0x1410b36ba*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b36ca*/
      throw &pExceptionObject; /*0x1410b36db*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  v3 = *(_WORD *)&this->data[readOffset]; /*0x1410b369a*/
  this->readOffset = v2; /*0x1410b369e*/
  return __ROL2__(v3, 8); /*0x1410b36a6*/
}

// Address: 0x1410b36f0 | Name: ?readInt32@NetworkStream@Network@RBX@@QEAAHXZ
__int64 __fastcall RBX::Network::NetworkStream::readInt32(RBX::Network::NetworkStream *this)
{
  unsigned int readOffset; // eax
  unsigned int v2; // r9d
  unsigned int v3; // r8d
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  readOffset = this->readOffset; /*0x1410b36f7*/
  v2 = readOffset + 4; /*0x1410b36fa*/
  if ( readOffset + 4 > this->numberOfBytesUsed ) /*0x1410b3702*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for int32_t"); /*0x1410b3743*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b3753*/
      throw &pExceptionObject; /*0x1410b3764*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  v3 = *(_DWORD *)&this->data[readOffset]; /*0x1410b370a*/
  this->readOffset = v2; /*0x1410b370e*/
  return (unsigned int)__ROL4__((v3 << 8) ^ ((v3 << 8) ^ (v3 >> 8)) & 0xFF00FF, 16); /*0x1410b372f*/
}

// Address: 0x1410b3770 | Name: ?readInt8@NetworkStream@Network@RBX@@QEAACXZ
__int64 __fastcall RBX::Network::NetworkStream::readInt8(RBX::Network::NetworkStream *this)
{
  unsigned int readOffset; // eax
  unsigned int v2; // r8d
  __int64 result; // rax
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  readOffset = this->readOffset; /*0x1410b3777*/
  v2 = readOffset + 1; /*0x1410b377a*/
  if ( readOffset + 1 > this->numberOfBytesUsed ) /*0x1410b3782*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for int8_t"); /*0x1410b37a6*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b37b6*/
    throw &pExceptionObject; /*0x1410b37c7*/
  }
  result = this->data[readOffset]; /*0x1410b378a*/
  this->readOffset = v2; /*0x1410b378e*/
  return result; /*0x1410b3792*/
}

// Address: 0x1410b37d0 | Name: ?readNumberRange@NetworkStream@Network@RBX@@QEAA?AVNumberRange@3@XZ
RBX::Vector2 *__fastcall RBX::Network::NetworkStream::readNumberRange(
        RBX::Network::NetworkStream *this,
        RBX::Vector2 *result)
{
  float Float; // xmm0_4

  *result = 0; /*0x1410b37df*/
  result->x = RBX::Network::NetworkStream::readFloat(this); /*0x1410b37ed*/
  Float = RBX::Network::NetworkStream::readFloat(this); /*0x1410b37f1*/
  result->y = Float; /*0x1410b37fe*/
  return result; /*0x1410b37f6*/
}

// Address: 0x1410b3810 | Name: ?readNumberSequence@NetworkStream@Network@RBX@@QEAA?AVNumberSequence@3@XZ
RBX::NumberSequence *__fastcall RBX::Network::NetworkStream::readNumberSequence(
        RBX::Network::NetworkStream *this,
        RBX::NumberSequence *result)
{
  unsigned int UInt32; // eax
  __int64 v5; // r14
  __int64 v6; // rsi
  __int64 v7; // rbx
  unsigned __int64 v8; // rdi
  void *v9; // rax
  void *v10; // rcx
  RBX::NumberSequenceKeypoint *v11; // rax
  RBX::NumberSequenceKeypoint *v12; // rdx
  RBX::NumberSequenceKeypoint *v13; // r8
  __int64 v14; // rcx
  __m128 v15; // xmm0
  __m128 v16; // xmm7
  __m128 v17; // xmm0
  __m128 v18; // xmm6
  RBX::NumberSequenceKeypoint *Myfirst; // rcx
  RBX::NumberSequenceKeypoint *v20; // r8
  std::vector<RBX::NumberSequenceKeypoint> keys; // [rsp+20h] [rbp-B8h] BYREF
  float Float; // [rsp+40h] [rbp-98h]
  std::string m; // [rsp+48h] [rbp-90h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+68h] [rbp-70h] BYREF

  UInt32 = RBX::Network::NetworkStream::readUInt32(this); /*0x1410b3839*/
  v5 = UInt32; /*0x1410b383e*/
  if ( UInt32 > 0x14 ) /*0x1410b3844*/
  {
    std::string::string(this: &m, _Ptr: "Number sequence is too big"); /*0x1410b39f7*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b3a07*/
      throw &pExceptionObject; /*0x1410b3a18*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  v6 = (unsigned int)v5; /*0x1410b384a*/
  memset(&keys, 0, sizeof(keys)); /*0x1410b3850*/
  v7 = 0; /*0x1410b3856*/
  if ( UInt32 != 0 ) /*0x1410b385f*/
  {
    v8 = 12 * v5; /*0x1410b3869*/
    if ( (unsigned __int64)(12 * v5) < 0x1000 ) /*0x1410b3878*/
    {
      if ( v8 != 0 ) /*0x1410b38b0*/
      {
        v11 = (RBX::NumberSequenceKeypoint *)operator new(size: 12 * v5); /*0x1410b38b5*/
        v12 = &v11[v8 / 0xC]; /*0x1410b38ba*/
        v13 = v11; /*0x1410b38be*/
      }
      else
      {
        v11 = nullptr; /*0x1410b38c3*/
        v12 = nullptr; /*0x1410b38c6*/
        v13 = nullptr; /*0x1410b38ca*/
      }
    }
    else
    {
      if ( v8 + 39 < v8 ) /*0x1410b3881*/
        std::_Throw_bad_array_new_length(); /*0x1410b39e5*/
      v9 = operator new(size: v8 + 39); /*0x1410b3887*/
      v10 = v9; /*0x1410b388c*/
      if ( v9 == nullptr ) /*0x1410b3892*/
LABEL_19:
        _invalid_parameter_noinfo_noreturn(); /*0x1410b39ac*/
      v11 = (RBX::NumberSequenceKeypoint *)(((unsigned __int64)v9 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x1410b389c*/
      *(_QWORD *)&v11[-1].value = v10; /*0x1410b38a0*/
      v12 = &v11[v8 / 0xC]; /*0x1410b38a4*/
      v13 = v11; /*0x1410b38a8*/
    }
    v14 = (unsigned int)v5; /*0x1410b38cd*/
    keys._Mypair._Myval2._Myfirst = v13; /*0x1410b38d0*/
    keys._Mypair._Myval2._Myend = v12; /*0x1410b38d5*/
    do /*0x1410b38ee*/
    {
      *(_QWORD *)&v11->time = 0; /*0x1410b38e0*/
      v11->envelope = 0.0; /*0x1410b38e3*/
      ++v11; /*0x1410b38e6*/
      --v14; /*0x1410b38ea*/
    }
    while ( v14 != 0 ); /*0x1410b38ee*/
    keys._Mypair._Myval2._Mylast = v11; /*0x1410b38f0*/
  }
  __wind /*0xf1c0000000000028*/
  {
    if ( (_DWORD)v5 != 0 ) /*0x1410b38f8*/
    {
      do /*0x1410b3944*/
      {
        v15.m128_f32[0] = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3903*/
        v16 = v15; /*0x1410b3908*/
        v17.m128_f32[0] = RBX::Network::NetworkStream::readFloat(this); /*0x1410b390e*/
        v18 = v17; /*0x1410b3913*/
        Float = RBX::Network::NetworkStream::readFloat(this); /*0x1410b391e*/
        Myfirst = keys._Mypair._Myval2._Myfirst; /*0x1410b3924*/
        *(_QWORD *)&keys._Mypair._Myval2._Myfirst[v7].time = _mm_unpacklo_ps(v16, v18).m128_u64[0]; /*0x1410b392f*/
        Myfirst[v7++].envelope = Float; /*0x1410b3938*/
        --v6; /*0x1410b3940*/
      }
      while ( v6 != 0 ); /*0x1410b3944*/
    }
    RBX::NumberSequence::NumberSequence(this: result, &keys, exc: false); /*0x1410b3951*/
  }
  __unwind
  {
    std::vector<RBX::HeightmapImporter::VoxelImportInfo>::_Tidy(this: (std::vector<VkVertexInputBindingDescription> *)&keys); /*0xf1c0000000000020*/
  }
  v20 = keys._Mypair._Myval2._Myfirst; /*0x1410b3957*/
  if ( keys._Mypair._Myval2._Myfirst != nullptr ) /*0x1410b395f*/
  {
    if ( (unsigned __int64)(12 * (keys._Mypair._Myval2._Myend - keys._Mypair._Myval2._Myfirst)) >= 0x1000 ) /*0x1410b3995*/
    {
      v20 = *(RBX::NumberSequenceKeypoint **)&keys._Mypair._Myval2._Myfirst[-1].value; /*0x1410b399b*/
      if ( (unsigned __int64)((char *)keys._Mypair._Myval2._Myfirst - (char *)v20 - 8) > 0x1F ) /*0x1410b39aa*/
        goto LABEL_19; /*0x1410b39aa*/
    }
    operator delete(ptr: v20); /*0x1410b39b6*/
  }
  return result; /*0x1410b39be*/
}

// Address: 0x1410b3a20 | Name: ?readOptionalCoordinateFrame@NetworkStream@Network@RBX@@QEAA?AVOptionalCoordinateFrame@3@XZ
Json::Value::CommentInfo *__fastcall RBX::Network::NetworkStream::readOptionalCoordinateFrame(
        RBX::Network::NetworkStream *this,
        Json::Value::CommentInfo *result)
{
  unsigned int readOffset; // eax
  unsigned int v5; // edx
  char v6; // cl
  unsigned __int8 v7; // cl
  RBX::CoordinateFrame value; // [rsp+20h] [rbp-78h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+50h] [rbp-48h] BYREF
  RBX::OptionalCoordinateFrame optionalValue; // [rsp+A0h] [rbp+8h] BYREF

  readOffset = this->readOffset; /*0x1410b3a33*/
  v5 = readOffset + 1; /*0x1410b3a36*/
  if ( readOffset + 1 > this->numberOfBytesUsed ) /*0x1410b3a3c*/
  {
    std::string::string(this: (std::string *)&value, _Ptr: "readFast past end for uint8_t"); /*0x1410b3b22*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: (const std::string *)&value); /*0x1410b3b32*/
      throw &pExceptionObject; /*0x1410b3b43*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&value); /*0xf1c0000000000014*/
    }
  }
  v6 = this->data[readOffset]; /*0x1410b3a49*/
  this->readOffset = v5; /*0x1410b3a4e*/
  if ( v6 >= 0 ) /*0x1410b3a53*/
  {
    webrtc::AudioNetworkAdaptorImpl::Config::Config(this: result); /*0x1410b3b0f*/
  }
  else
  {
    *(_OWORD *)&value.rotation.elt[0][0] = _xmm; /*0x1410b3a60*/
    *(_OWORD *)&value.rotation.elt[1][1] = _xmm; /*0x1410b3a68*/
    *(_OWORD *)&value.rotation.elt[2][2] = _xmm; /*0x1410b3a6d*/
    v7 = v6 & 0x7F; /*0x1410b3a72*/
    if ( v7 != 0 ) /*0x1410b3a7a*/
      RBX::Math::idToMatrix3(orientId: v7 - 1, matrix: &value.rotation); /*0x1410b3a81*/
    else
      RBX::Network::Compressor::readRotation(bitStream: this, rotation: &value.rotation); /*0x1410b3a8b*/
    value.translation.x = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3a98*/
    value.translation.y = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3aa6*/
    value.translation.z = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3ab4*/
    webrtc::AudioNetworkAdaptorImpl::Config::Config(this: (Json::Value::CommentInfo *)&optionalValue); /*0x1410b3ac2*/
    __wind /*0xf1c0000000000028*/
    {
      RBX::OptionalCoordinateFrame::set(this: &optionalValue, cframe: &value); /*0x1410b3ad5*/
      RBX::OptionalCoordinateFrame::OptionalCoordinateFrame( /*0x1410b3ae5*/
        this: (RBX::OptionalCoordinateFrame *)result,
        other: &optionalValue);
    }
    __unwind
    {
      RBX::OptionalCoordinateFrame::~OptionalCoordinateFrame(this: &optionalValue); /*0xf1c0000000000020*/
    }
    RBX::OptionalCoordinateFrame::~OptionalCoordinateFrame(this: &optionalValue); /*0x1410b3af3*/
  }
  return result; /*0x1410b3afb*/
}

// Address: 0x1410b3b50 | Name: ?readPathWaypointWithLabel@NetworkStream@Network@RBX@@QEAA?AVPathWaypoint@3@H@Z
RBX::PathWaypoint *__fastcall RBX::Network::NetworkStream::readPathWaypointWithLabel(
        RBX::Network::NetworkStream *this,
        RBX::PathWaypoint *result,
        int readPayloadLimit)
{
  __m128 v6; // xmm0
  __m128 v7; // xmm7
  __m128 v8; // xmm0
  __m128 v9; // xmm6
  RBX::PathWaypoint::WayPointData *Ptr; // rcx
  unsigned int readOffset; // eax
  RBX::PathWaypoint::Action v12; // edx
  std::string *v13; // rax
  std::string *p_label; // rcx
  unsigned __int64 Mysize; // r8
  char *v16; // rcx
  RBX::PathWaypoint *v17; // rax
  float Float; // [rsp+2Ch] [rbp-8Ch]
  std::string v19; // [rsp+30h] [rbp-88h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+50h] [rbp-68h] BYREF

  __wind /*0xf1c0000000000040*/
  {
    RBX::PathWaypoint::PathWaypoint(this: result); /*0x1410b3b83*/
    v6.m128_f32[0] = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3b93*/
    v7 = v6; /*0x1410b3b98*/
    v8.m128_f32[0] = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3b9e*/
    v9 = v8; /*0x1410b3ba3*/
    Float = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3bae*/
    Ptr = result->data._Ptr; /*0x1410b3bb4*/
    *(_QWORD *)&Ptr->position.x = _mm_unpacklo_ps(v7, v9).m128_u64[0]; /*0x1410b3bbd*/
    Ptr->position.z = Float; /*0x1410b3bc5*/
    readOffset = this->readOffset; /*0x1410b3bc8*/
    if ( readOffset + 1 > this->numberOfBytesUsed ) /*0x1410b3bd3*/
    {
      std::string::string(this: &v19, _Ptr: "readFast past end for uint8_t"); /*0x1410b3c8f*/
      __eh34_enter_wind_state(0, 1); /*0xf1c0000000000010*/
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &v19); /*0x1410b3c9f*/
      throw &pExceptionObject; /*0x1410b3cb0*/
    }
    __eh34_enter_wind_state(0, 1); /*0xf1c0000000000038*/
    v12 = this->data[readOffset]; /*0x1410b3bdf*/
    this->readOffset = readOffset + 1; /*0x1410b3be3*/
    result->data._Ptr->action = v12; /*0x1410b3bea*/
    v13 = RBX::Network::NetworkStream::readString(this, result: &v19, maxStringReadSize: readPayloadLimit); /*0x1410b3bf8*/
    p_label = &result->data._Ptr->label; /*0x1410b3c01*/
    if ( p_label != v13 ) /*0x1410b3c08*/
    {
      Mysize = v13->_Mypair._Myval2._Mysize; /*0x1410b3c0a*/
      if ( v13->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410b3c13*/
        v13 = (std::string *)v13->_Mypair._Myval2._Bx._Ptr; /*0x1410b3c15*/
      std::string::assign(this: p_label, _Ptr: v13->_Mypair._Myval2._Bx._Buf, _Count: Mysize); /*0x1410b3c1b*/
    }
    if ( __eh34_unwind(1) ) /*0xf1c0000000000024*/
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v19); /*0xf1c0000000000028*/
      __eh34_continue_unwinding(1, 0); /*0xf1c000000000002c*/
    }
    __eh34_exit_wind_state(1, 0); /*0xf1c0000000000030*/
    if ( v19._Mypair._Myval2._Myres >= 0x10 ) /*0x1410b3c2a*/
    {
      v16 = v19._Mypair._Myval2._Bx._Ptr; /*0x1410b3c2f*/
      if ( v19._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410b3c3e*/
      {
        v16 = *((char **)v19._Mypair._Myval2._Bx._Ptr - 1); /*0x1410b3c44*/
        if ( (unsigned __int64)(v19._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x1410b3c53*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410b3c55*/
      }
      operator delete(ptr: v16); /*0x1410b3c5c*/
    }
    v17 = result; /*0x1410b3c61*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)result); /*0x1431802ee*/
  }
  return v17; /*0x1410b3c64*/
}

// Address: 0x1410b3cc0 | Name: ?readPhysicalProperties@NetworkStream@Network@RBX@@QEAA?AVPhysicalProperties@3@XZ
RBX::PhysicalProperties *__fastcall RBX::Network::NetworkStream::readPhysicalProperties(
        RBX::Network::NetworkStream *this,
        RBX::PhysicalProperties *result)
{
  float Float; // xmm6_4
  float v5; // xmm9_4
  float v6; // xmm7_4
  float v7; // xmm8_4
  float v8; // xmm0_4

  if ( RBX::Network::NetworkStream::readBool(this) ) /*0x1410b3cd0*/
  {
    Float = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3d04*/
    v5 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3d0f*/
    v6 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3d1b*/
    v7 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3d26*/
    v8 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3d2a*/
    result->customEnabled = true; /*0x1410b3d5f*/
    result->density = fminf(100.0, fmaxf(0.0099999998, Float)); /*0x1410b3d8d*/
    result->friction = fminf(2.0, fmaxf(0.0, v5)); /*0x1410b3d9a*/
    result->elasticity = fminf(1.0, fmaxf(0.0, v6)); /*0x1410b3daa*/
    result->elasticityWeight = fminf(100.0, fmaxf(0.0, v8)); /*0x1410b3db7*/
    result->frictionWeight = fminf(100.0, fmaxf(0.0, v7)); /*0x1410b3dc6*/
    return result; /*0x1410b3d70*/
  }
  else
  {
    result->customEnabled = false; /*0x1410b3ddb*/
    *(_QWORD *)&result->density = 0; /*0x1410b3dde*/
    *(_QWORD *)&result->friction = 0; /*0x1410b3de2*/
    result->elasticityWeight = 0.0; /*0x1410b3de6*/
    return result; /*0x1410b3de9*/
  }
}

// Address: 0x1410b3e00 | Name: ?readRakString_Deprecated@NetworkStream@Network@RBX@@QEAA_NAEAVRakString@RakNet@@@Z
char __fastcall RBX::Network::NetworkStream::readRakString_Deprecated(
        RBX::Network::NetworkStream *this,
        RakNet::RakString *out)
{
  unsigned int readOffset; // eax
  char v5; // di
  unsigned int v6; // ecx
  __int16 v7; // ax
  char *v8; // rax
  __int64 v9; // rcx
  char *v10; // rsi
  unsigned __int16 len; // [rsp+30h] [rbp+8h]

  readOffset = this->readOffset; /*0x1410b3e0f*/
  v5 = 1; /*0x1410b3e18*/
  v6 = readOffset + 2; /*0x1410b3e1b*/
  if ( readOffset + 2 > this->numberOfBytesUsed ) /*0x1410b3e21*/
    return 0; /*0x1410b3ecf*/
  v7 = *(_WORD *)&this->data[readOffset]; /*0x1410b3e2e*/
  this->readOffset = v6; /*0x1410b3e38*/
  LOBYTE(len) = HIBYTE(v7); /*0x1410b3e40*/
  HIBYTE(len) = v7; /*0x1410b3e44*/
  if ( len != 0 ) /*0x1410b3e4e*/
  {
    v8 = (char *)operator new(size: (unsigned int)len + 1); /*0x1410b3e5d*/
    v9 = this->readOffset; /*0x1410b3e62*/
    v10 = v8; /*0x1410b3e65*/
    if ( (unsigned int)v9 + len <= this->numberOfBytesUsed ) /*0x1410b3e6e*/
    {
      memcpy_0(a1: v8, Src: &this->data[v9], Size: len); /*0x1410b3e8a*/
      this->readOffset += len; /*0x1410b3e8f*/
      v5 = 1; /*0x1410b3e9a*/
      v10[len] = 0; /*0x1410b3e9d*/
      RakNet::RakString::operator=(this: out, str: v10); /*0x1410b3ea4*/
    }
    else
    {
      v5 = 0; /*0x1410b3e70*/
      RakNet::RakString::Clear(this: out); /*0x1410b3e76*/
    }
    operator delete(ptr: v10); /*0x1410b3eac*/
  }
  return v5; /*0x1410b3eba*/
}

// Address: 0x1410b3ee0 | Name: ?readRay@NetworkStream@Network@RBX@@QEAA?AVRay@3@XZ
RBX::Ray *__fastcall RBX::Network::NetworkStream::readRay(RBX::Network::NetworkStream *this, RBX::Ray *result)
{
  __m128 v4; // xmm0
  __m128 v5; // xmm7
  __m128 v6; // xmm0
  __m128 v7; // xmm6
  float Float; // xmm0_4
  __m128 v9; // xmm0
  __m128 v10; // xmm7
  __m128 v11; // xmm0
  __m128 v12; // xmm6
  float v13; // xmm0_4

  *(_QWORD *)&result->m_origin.x = 0; /*0x1410b3ef1*/
  *(_QWORD *)&result->m_origin.z = 0; /*0x1410b3ef7*/
  *(_QWORD *)&result->m_direction.y = 0; /*0x1410b3efe*/
  v4.m128_f32[0] = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3f07*/
  v5 = v4; /*0x1410b3f0f*/
  v6.m128_f32[0] = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3f12*/
  v7 = v6; /*0x1410b3f1a*/
  Float = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3f1d*/
  *(_QWORD *)&result->m_origin.x = _mm_unpacklo_ps(v5, v7).m128_u64[0]; /*0x1410b3f35*/
  result->m_origin.z = Float; /*0x1410b3f39*/
  v9.m128_f32[0] = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3f3c*/
  v10 = v9; /*0x1410b3f44*/
  v11.m128_f32[0] = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3f47*/
  v12 = v11; /*0x1410b3f4f*/
  v13 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3f52*/
  *(_QWORD *)&result->m_direction.x = _mm_unpacklo_ps(v10, v12).m128_u64[0]; /*0x1410b3f76*/
  result->m_direction.z = v13; /*0x1410b3f7b*/
  return result; /*0x1410b3f67*/
}

// Address: 0x1410b3f90 | Name: ?readRect2D@NetworkStream@Network@RBX@@QEAA?AVRect2D@3@XZ
RBX::Rect2D *__fastcall RBX::Network::NetworkStream::readRect2D(RBX::Network::NetworkStream *this, RBX::Rect2D *result)
{
  float Float; // xmm7_4
  float v5; // xmm8_4
  float v6; // xmm6_4
  float v7; // xmm0_4
  RBX::Vector2 *p_x0y0; // rax
  float x; // xmm2_4
  float *p_y; // rax
  float v11; // xmm1_4
  RBX::Vector2 *p_x1y1; // rax
  float v13; // xmm1_4
  float *v14; // rax
  float v15; // xmm0_4
  RBX::Vector2 x0y0; // [rsp+68h] [rbp+10h] BYREF
  RBX::Vector2 x1y1; // [rsp+70h] [rbp+18h] BYREF

  Float = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3fb8*/
  v5 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3fc0*/
  x0y0.x = Float; /*0x1410b3fc4*/
  x0y0.y = v5; /*0x1410b3fcd*/
  v6 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3fdc*/
  v7 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b3fdf*/
  p_x0y0 = &x0y0; /*0x1410b3ff1*/
  x1y1.x = v6; /*0x1410b3ff6*/
  x1y1.y = v7; /*0x1410b3ffc*/
  if ( v6 <= Float ) /*0x1410b4002*/
    p_x0y0 = &x1y1; /*0x1410b4002*/
  x = p_x0y0->x; /*0x1410b400f*/
  p_y = &x0y0.y; /*0x1410b4013*/
  result->min.x = x; /*0x1410b4018*/
  if ( v7 <= v5 ) /*0x1410b401c*/
    p_y = &x1y1.y; /*0x1410b401c*/
  v11 = *p_y; /*0x1410b4028*/
  p_x1y1 = &x0y0; /*0x1410b402c*/
  if ( Float <= v6 ) /*0x1410b403b*/
    p_x1y1 = &x1y1; /*0x1410b403b*/
  result->min.y = v11; /*0x1410b404e*/
  v13 = p_x1y1->x; /*0x1410b4053*/
  v14 = &x0y0.y; /*0x1410b4057*/
  if ( v5 <= v7 ) /*0x1410b405c*/
    v14 = &x1y1.y; /*0x1410b405c*/
  result->max.x = v13; /*0x1410b4060*/
  v15 = *v14; /*0x1410b4065*/
  result->max.y = v15; /*0x1410b406c*/
  return result; /*0x1410b4048*/
}

// Address: 0x1410b4080 | Name: ?readRegion3@NetworkStream@Network@RBX@@QEAA?AVRegion3@3@XZ
RBX::Region3 *__fastcall RBX::Network::NetworkStream::readRegion3(
        RBX::Network::NetworkStream *this,
        RBX::Region3 *result)
{
  RBX::Extents extents; // [rsp+20h] [rbp-68h] BYREF

  extents.low.x = RBX::Network::NetworkStream::readFloat(this); /*0x1410b40df*/
  extents.low.y = RBX::Network::NetworkStream::readFloat(this); /*0x1410b40e6*/
  extents.low.z = RBX::Network::NetworkStream::readFloat(this); /*0x1410b40ed*/
  extents.high.x = RBX::Network::NetworkStream::readFloat(this); /*0x1410b40f3*/
  extents.high.y = RBX::Network::NetworkStream::readFloat(this); /*0x1410b40f9*/
  extents.high.z = RBX::Network::NetworkStream::readFloat(this); /*0x1410b4109*/
  RBX::Region3::Region3(this: result, &extents); /*0x1410b4112*/
  return result; /*0x1410b4117*/
}

// Address: 0x1410b4150 | Name: ?readRegion3int16@NetworkStream@Network@RBX@@QEAA?AVRegion3int16@3@XZ
RBX::Region3int16 *__fastcall RBX::Network::NetworkStream::readRegion3int16(
        RBX::Network::NetworkStream *this,
        RBX::Region3int16 *result)
{
  __int16 Int16; // bx
  __int16 v5; // ax
  int v7; // [rsp+38h] [rbp+10h]
  int v8; // [rsp+40h] [rbp+18h]

  LOWORD(v7) = RBX::Network::NetworkStream::readInt16(this); /*0x1410b416d*/
  HIWORD(v7) = RBX::Network::NetworkStream::readInt16(this); /*0x1410b417a*/
  Int16 = RBX::Network::NetworkStream::readInt16(this); /*0x1410b4187*/
  LOWORD(v8) = RBX::Network::NetworkStream::readInt16(this); /*0x1410b4192*/
  HIWORD(v8) = RBX::Network::NetworkStream::readInt16(this); /*0x1410b419f*/
  v5 = RBX::Network::NetworkStream::readInt16(this); /*0x1410b41a4*/
  *(_DWORD *)&result->minPos.x = v7; /*0x1410b41ad*/
  *(_DWORD *)&result->maxPos.x = v8; /*0x1410b41b3*/
  result->maxPos.z = v5; /*0x1410b41b6*/
  result->minPos.z = Int16; /*0x1410b41bd*/
  return result; /*0x1410b41c1*/
}

// Address: 0x1410b41e0 | Name: ?readStreamRegionId@NetworkStream@Network@RBX@@QEAA?AVId@StreamRegion@3@XZ
RBX::StreamRegion::Id *__fastcall RBX::Network::NetworkStream::readStreamRegionId(
        RBX::Network::NetworkStream *this,
        RBX::StreamRegion::Id *result)
{
  int Int32; // eax
  __int64 vv; // [rsp+20h] [rbp-18h]

  if ( RBX::Network::NetworkStream::readBool(this) ) /*0x1410b41f0*/
  {
    LODWORD(vv) = RBX::Network::NetworkStream::readInt32(this); /*0x1410b4204*/
    HIDWORD(vv) = RBX::Network::NetworkStream::readInt32(this); /*0x1410b4210*/
    Int32 = RBX::Network::NetworkStream::readInt32(this); /*0x1410b4214*/
  }
  else
  {
    LODWORD(vv) = (char)RBX::Network::NetworkStream::readInt8(this); /*0x1410b4223*/
    HIDWORD(vv) = (char)RBX::Network::NetworkStream::readInt8(this); /*0x1410b4232*/
    Int32 = (char)RBX::Network::NetworkStream::readInt8(this); /*0x1410b423e*/
  }
  *(_QWORD *)&result->internalValue.x = vv; /*0x1410b424c*/
  result->internalValue.z = Int32; /*0x1410b4250*/
  return result; /*0x1410b4247*/
}

// Address: 0x1410b4260 | Name: ?readString@NetworkStream@Network@RBX@@QEAA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@H@Z
RBX::Graphics::ProfilerAdorn::Item *__fastcall RBX::Network::NetworkStream::readString(
        RBX::Network::NetworkStream *this,
        RBX::Graphics::ProfilerAdorn::Item *result,
        unsigned int maxStringReadSize)
{
  unsigned int readOffset; // eax
  unsigned int v7; // r10d
  unsigned int numberOfBytesUsed; // r9d
  unsigned int v9; // ecx
  unsigned int v10; // ebx
  std::string *p_text; // rdx
  RBX::Graphics::ProfilerAdorn::Item *v12; // rax
  RBX::Graphics::ProfilerAdorn::Item *v13; // rax
  int NumberOfUnreadBytes; // eax
  RBX::Graphics::ProfilerAdorn::Item *v15; // rax
  std::string v16; // [rsp+28h] [rbp-A0h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+48h] [rbp-80h] BYREF
  RBX::network_stream_exception v18; // [rsp+80h] [rbp-48h] BYREF

  __wind
  {
    readOffset = this->readOffset; /*0x1410b428d*/
    v7 = readOffset + 4; /*0x1410b4290*/
    numberOfBytesUsed = this->numberOfBytesUsed; /*0x1410b4294*/
    if ( readOffset + 4 > numberOfBytesUsed ) /*0x1410b429b*/
    {
      std::string::string(this: &v16, _Ptr: "readFast past end for uint32_t"); /*0x1410b43a1*/
      __eh34_enter_wind_state(0, 1); /*0xf1c0000000000018*/
      RBX::network_stream_exception::network_stream_exception(this: &v18, m: &v16); /*0x1410b43b4*/
      throw &v18; /*0x1410b43c8*/
    }
    v9 = *(_DWORD *)&this->data[readOffset]; /*0x1410b42a7*/
    this->readOffset = v7; /*0x1410b42aa*/
    v10 = __ROL4__((v9 << 8) ^ ((v9 << 8) ^ (v9 >> 8)) & 0xFF00FF, 16); /*0x1410b42c5*/
    if ( DFFlag::NetworkReportStringOverLimit.value && v10 > DFInt::NetworkReportStringOverLimitRead ) /*0x1410b42d7*/
    {
      RBX::Network::NetworkStream::reportStringLengthLimit( /*0x1410b42dd*/
        isWrite: false,
        lengthWanted: v10,
        limitWanted: maxStringReadSize);
      numberOfBytesUsed = this->numberOfBytesUsed; /*0x1410b42e2*/
      v7 = this->readOffset; /*0x1410b42e6*/
    }
    if ( v10 > numberOfBytesUsed - v7 )
    {
      NumberOfUnreadBytes = RBX::Network::NetworkStream::GetNumberOfUnreadBytes(this); /*0x1410b43d1*/
      v15 = RBX::format(
              result: (RBX::Graphics::ProfilerAdorn::Item *)&v16,
              fmt: "BitStream >> String: String too long by: %u",
              v10 - NumberOfUnreadBytes);
      __eh34_enter_wind_state(0, 1); /*0xf1c0000000000010*/
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &v15->text); /*0x1410b43f5*/
      throw &pExceptionObject; /*0x1410b4406*/
    }
    if ( v10 > maxStringReadSize )
    {
      v13 = RBX::format(
              result: (RBX::Graphics::ProfilerAdorn::Item *)&v16,
              fmt: "BitStream >> String: String too long: %u",
              v10);
      __eh34_enter_wind_state(0, 1); /*0xf1c0000000000020*/
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &v13->text); /*0x1410b437e*/
      throw &pExceptionObject; /*0x1410b438f*/
    }
    result->text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410b42fa*/
    result->text._Mypair._Myval2._Mysize = 0; /*0x1410b4301*/
    result->text._Mypair._Myval2._Myres = 15; /*0x1410b4309*/
    result->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410b4311*/
    std::string::resize(this: &result->text, _Newsize: v10, _Ch: 0); /*0x1410b4324*/
    if ( v10 != 0 ) /*0x1410b432b*/
    {
      p_text = &result->text; /*0x1410b432d*/
      if ( result->text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410b4335*/
        p_text = (std::string *)result->text._Mypair._Myval2._Bx._Ptr; /*0x1410b4337*/
      RBX::Network::NetworkStream::readBytes(this, inOutByteArray: p_text, numberOfBytesToRead: v10); /*0x1410b4340*/
    }
    v12 = result; /*0x1410b4345*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: result); /*0x1431ec73e*/
  }
  return v12; /*0x1410b4348*/
}

// Address: 0x1410b4410 | Name: ?readUDim2@NetworkStream@Network@RBX@@QEAA?AVUDim2@3@XZ
RBX::UDim2 *__fastcall RBX::Network::NetworkStream::readUDim2(RBX::Network::NetworkStream *this, RBX::UDim2 *result)
{
  float Float; // xmm6_4
  int Int32; // eax
  float v6; // xmm6_4

  result->x = 0; /*0x1410b4421*/
  result->y = 0; /*0x1410b4427*/
  Float = RBX::Network::NetworkStream::readFloat(this); /*0x1410b4436*/
  Int32 = RBX::Network::NetworkStream::readInt32(this); /*0x1410b4439*/
  result->x.scale = Float; /*0x1410b4441*/
  result->x.offset = Int32; /*0x1410b4445*/
  v6 = RBX::Network::NetworkStream::readFloat(this); /*0x1410b4450*/
  result->y.offset = RBX::Network::NetworkStream::readInt32(this); /*0x1410b445d*/
  result->y.scale = v6; /*0x1410b4463*/
  return result; /*0x1410b4458*/
}

// Address: 0x1410b4480 | Name: ?readUDim@NetworkStream@Network@RBX@@QEAA?AVUDim@3@XZ
RBX::UDim *__fastcall RBX::Network::NetworkStream::readUDim(RBX::Network::NetworkStream *this, RBX::UDim *result)
{
  *result = 0; /*0x1410b448f*/
  result->scale = RBX::Network::NetworkStream::readFloat(this); /*0x1410b449d*/
  result->offset = RBX::Network::NetworkStream::readInt32(this); /*0x1410b44ab*/
  return result; /*0x1410b44a6*/
}

// Address: 0x1410b44c0 | Name: ?readUInt16@NetworkStream@Network@RBX@@QEAAGXZ
unsigned __int16 __fastcall RBX::Network::NetworkStream::readUInt16(RBX::Network::NetworkStream *this)
{
  unsigned int readOffset; // eax
  unsigned int v2; // r8d
  __int16 v3; // ax
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  readOffset = this->readOffset; /*0x1410b44c7*/
  v2 = readOffset + 2; /*0x1410b44ca*/
  if ( readOffset + 2 > this->numberOfBytesUsed ) /*0x1410b44d2*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint16_t"); /*0x1410b44fa*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b450a*/
    throw &pExceptionObject; /*0x1410b451b*/
  }
  v3 = *(_WORD *)&this->data[readOffset]; /*0x1410b44da*/
  this->readOffset = v2; /*0x1410b44de*/
  return __ROL2__(v3, 8); /*0x1410b44e6*/
}

// Address: 0x1410b4530 | Name: ?readUInt32@NetworkStream@Network@RBX@@QEAAIXZ
__int64 __fastcall RBX::Network::NetworkStream::readUInt32(RBX::Network::NetworkStream *this)
{
  unsigned int readOffset; // eax
  unsigned int v2; // r8d
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  readOffset = this->readOffset; /*0x1410b4537*/
  if ( readOffset + 4 > this->numberOfBytesUsed ) /*0x1410b4542*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint32_t"); /*0x1410b4583*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b4593*/
    throw &pExceptionObject; /*0x1410b45a4*/
  }
  v2 = *(_DWORD *)&this->data[readOffset]; /*0x1410b454a*/
  this->readOffset = readOffset + 4; /*0x1410b454e*/
  return (unsigned int)__ROL4__((v2 << 8) ^ ((v2 << 8) ^ (v2 >> 8)) & 0xFF00FF, 16); /*0x1410b456f*/
}

// Address: 0x1410b45b0 | Name: ?readUInt64@NetworkStream@Network@RBX@@QEAA_KXZ
__int64 __fastcall RBX::Network::NetworkStream::readUInt64(RBX::Network::NetworkStream *this)
{
  unsigned int readOffset; // eax
  unsigned int v2; // r9d
  __int64 v3; // r8
  unsigned __int64 v4; // r8
  unsigned __int64 v5; // rdx
  std::string m; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  readOffset = this->readOffset; /*0x1410b45b7*/
  v2 = readOffset + 8; /*0x1410b45ba*/
  if ( readOffset + 8 > this->numberOfBytesUsed ) /*0x1410b45c2*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint64_t"); /*0x1410b4634*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x1410b4644*/
      throw &pExceptionObject; /*0x1410b4655*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  v3 = *(_QWORD *)&this->data[readOffset]; /*0x1410b45ca*/
  this->readOffset = v2; /*0x1410b45ce*/
  v4 = __ROL8__(v3, 32); /*0x1410b45d2*/
  v5 = (v4 << 16) ^ ((v4 << 16) ^ (v4 >> 16)) & 0xFFFF0000FFFFLL; /*0x1410b45f8*/
  return (v5 << 8) ^ ((v5 << 8) ^ (v5 >> 8)) & 0xFF00FF00FF00FFLL; /*0x1410b4620*/
}

// Address: 0x1410b4660 | Name: ?readVector2int16@NetworkStream@Network@RBX@@QEAA?AVVector2int16@3@XZ
RBX::Vector2int16 *__fastcall RBX::Network::NetworkStream::readVector2int16(
        RBX::Network::NetworkStream *this,
        RBX::Vector2int16 *result)
{
  *result = 0; /*0x1410b466f*/
  result->x = RBX::Network::NetworkStream::readInt16(this); /*0x1410b467c*/
  result->y = RBX::Network::NetworkStream::readInt16(this); /*0x1410b4689*/
  return result; /*0x1410b4684*/
}

// Address: 0x1410b46a0 | Name: ?readVector3int16@NetworkStream@Network@RBX@@QEAA?AVVector3int16@3@XZ
RBX::Vector3int16 *__fastcall RBX::Network::NetworkStream::readVector3int16(
        RBX::Network::NetworkStream *this,
        RBX::Vector3int16 *result)
{
  *(_DWORD *)&result->x = 0; /*0x1410b46af*/
  result->z = 0; /*0x1410b46b4*/
  result->x = RBX::Network::NetworkStream::readInt16(this); /*0x1410b46c0*/
  result->y = RBX::Network::NetworkStream::readInt16(this); /*0x1410b46cb*/
  result->z = RBX::Network::NetworkStream::readInt16(this); /*0x1410b46d9*/
  return result; /*0x1410b46d4*/
}

// Address: 0x1410b46f0 | Name: ?reportStringLengthLimit@NetworkStream@Network@RBX@@SAX_NIH@Z
void __fastcall RBX::Network::NetworkStream::reportStringLengthLimit(
        bool isWrite,
        unsigned int lengthWanted,
        int limitWanted)
{
  int v6; // ebx
  char *v7; // rax
  char *Ptr; // rcx
  std::string resource; // [rsp+20h] [rbp-98h] BYREF
  RBX::Analytics::InfluxDb::Points points; // [rsp+40h] [rbp-78h] BYREF

  if ( DFInt::NetworkExcludeStringSizeRpt == 0 || DFInt::NetworkExcludeStringSizeRpt != limitWanted ) /*0x1410b4716*/
  {
    RBX::Analytics::InfluxDb::Points::Points( /*0x1410b472b*/
      this: &points,
      throttleHundredthsPercentage: -1,
      categoryType: kStandardType,
      priorityHundredthsPercentage: 0);
    __wind /*0xf1c0000000000028*/
    {
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "isWrite", value: isWrite); /*0x1410b4741*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "LengthToWrite", value: lengthWanted); /*0x1410b4755*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &points, name: "LimitToBeImposed", value: limitWanted); /*0x1410b4769*/
      v6 = DFInt::NetworkReportStringOverLimitPerMyriad; /*0x1410b476e*/
      v7 = (char *)operator new(size: 0x20u); /*0x1410b4790*/
      resource._Mypair._Myval2._Mysize = 24; /*0x1410b4795*/
      resource._Mypair._Myval2._Myres = 31; /*0x1410b479e*/
      strcpy(v7, "NetworkStreamStringLimit"); /*0x1410b47ae*/
      resource._Mypair._Myval2._Bx._Ptr = v7; /*0x1410b47c2*/
      __wind /*0xf1c000000000001c*/
      {
        RBX::Analytics::InfluxDb::Points::report( /*0x1410b47d7*/
          this: &points,
          &resource,
          throttleHundredthsPercentage: v6,
          blocking: false);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000014*/
      }
      if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x1410b47e6*/
      {
        Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x1410b47eb*/
        if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410b47fa*/
        {
          Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x1410b4800*/
          if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410b480f*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410b4811*/
        }
        operator delete(ptr: Ptr); /*0x1410b4818*/
      }
      RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0x1410b4823*/
    }
    __unwind
    {
      RBX::Analytics::InfluxDb::Points::~Points(this: &points); /*0xf1c0000000000008*/
    }
  }
}

// Address: 0x1410b4e50 | Name: ?writeAxes@NetworkStream@Network@RBX@@QEAAXAEBVAxes@3@@Z
void __fastcall RBX::Network::NetworkStream::writeAxes(RBX::Network::NetworkStream *this, const RBX::Faces *value)
{
  RBX::Network::NetworkStream::writeUInt32(this, value: value->normalIdMask); /*0x1410b4e52*/
}

// Address: 0x1410b4e60 | Name: ?writeBrickColor@NetworkStream@Network@RBX@@QEAAXAEBVBrickColor@3@@Z
void __fastcall RBX::Network::NetworkStream::writeBrickColor(
        RBX::Network::NetworkStream *this,
        const RBX::BrickColor *value)
{
  RBX::Network::NetworkStream::writeInt16(this, value: value->number); /*0x1410b4e63*/
}

// Address: 0x1410b4e70 | Name: ?writeBytes@NetworkStream@Network@RBX@@QEAAXPEBXI@Z
void __fastcall RBX::Network::NetworkStream::writeBytes(
        RBX::Network::NetworkStream *this,
        const void *inByteArray,
        unsigned int numberOfBytesToWrite)
{
  unsigned int numberOfBytesUsed; // eax
  unsigned int numberOfBytesAllocated; // ecx
  size_t v7; // rsi
  unsigned int v8; // ebp
  unsigned int v9; // ebp
  unsigned __int8 *data; // rdx

  if ( numberOfBytesToWrite != 0 ) /*0x1410b4e73*/
  {
    numberOfBytesUsed = this->numberOfBytesUsed; /*0x1410b4e89*/
    numberOfBytesAllocated = this->numberOfBytesAllocated; /*0x1410b4e8f*/
    v7 = numberOfBytesToWrite; /*0x1410b4e95*/
    if ( numberOfBytesUsed + numberOfBytesToWrite <= numberOfBytesAllocated ) /*0x1410b4ea2*/
    {
      data = this->data; /*0x1410b4eda*/
    }
    else
    {
      v8 = numberOfBytesUsed + numberOfBytesToWrite - numberOfBytesAllocated; /*0x1410b4ea4*/
      if ( v8 < DFInt::NetworkStreamMinGrowSize ) /*0x1410b4eb1*/
        v8 = DFInt::NetworkStreamMinGrowSize; /*0x1410b4eb1*/
      v9 = numberOfBytesAllocated + v8; /*0x1410b4eb8*/
      std::vector<unsigned char>::resize(this: &this->dataVector, _Newsize: v9); /*0x1410b4ec0*/
      data = this->dataVector._Mypair._Myval2._Myfirst; /*0x1410b4ec5*/
      numberOfBytesUsed = this->numberOfBytesUsed; /*0x1410b4ec9*/
      this->data = data; /*0x1410b4ed1*/
      this->numberOfBytesAllocated = v9; /*0x1410b4ed5*/
    }
    memcpy_0(a1: &data[numberOfBytesUsed], Src: inByteArray, Size: v7); /*0x1410b4ee9*/
    this->numberOfBytesUsed += v7; /*0x1410b4eee*/
  }
}

// Address: 0x1410b4f10 | Name: ?writeVector3@NetworkStream@Network@RBX@@QEAAXAEBVVector3@3@@Z
void __fastcall RBX::Network::NetworkStream::writeVector3(RBX::Network::NetworkStream *this, const RBX::Vector3 *value)
{
  RBX::Network::NetworkStream::writeFloat(this, value: value->x); /*0x1410b4f24*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->y); /*0x1410b4f31*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->z); /*0x1410b4f48*/
}

// Address: 0x1410b4f50 | Name: ?writeColor3uint8@NetworkStream@Network@RBX@@QEAAXAEBVColor3uint8@3@@Z
void __fastcall RBX::Network::NetworkStream::writeColor3uint8(
        RBX::Network::NetworkStream *this,
        const RBX::Color3uint8 *value)
{
  RBX::Network::NetworkStream::writeByte(this, value: value->r); /*0x1410b4f63*/
  RBX::Network::NetworkStream::writeByte(this, value: value->g); /*0x1410b4f6f*/
  RBX::Network::NetworkStream::writeByte(this, value: value->b); /*0x1410b4f85*/
}

// Address: 0x1410b4f90 | Name: ?writeColorSequence@NetworkStream@Network@RBX@@QEAAXAEBVColorSequence@3@@Z
void __fastcall RBX::Network::NetworkStream::writeColorSequence(
        RBX::Network::NetworkStream *this,
        const RBX::ColorSequence *value)
{
  unsigned __int64 v4; // rdx
  signed __int64 v5; // rcx
  __int64 v6; // rbp
  __int64 v7; // rdi
  RBX::ColorSequenceKeypoint *Myfirst; // rbx

  v4 = (__int64)((unsigned __int128)(((char *)value->m_data._Mypair._Myval2._Mylast /*0x1410b4fc2*/
                                    - (char *)value->m_data._Mypair._Myval2._Myfirst)
                                   * (__int128)0x6666666666666667LL) >> 64) >> 3;
  RBX::Network::NetworkStream::writeUInt32(this, value: (v4 >> 63) + v4); /*0x1410b4fd0*/
  v5 = (char *)value->m_data._Mypair._Myval2._Mylast - (char *)value->m_data._Mypair._Myval2._Myfirst; /*0x1410b4fdc*/
  v6 = (int)(v5 / 20); /*0x1410b4ff0*/
  if ( (int)(v5 / 20) > 0 ) /*0x1410b4ff5*/
  {
    v7 = 0; /*0x1410b4ffc*/
    do /*0x1410b5050*/
    {
      Myfirst = value->m_data._Mypair._Myval2._Myfirst; /*0x1410b5000*/
      RBX::Network::NetworkStream::writeFloat(this, value: value->m_data._Mypair._Myval2._Myfirst[v7].time); /*0x1410b500b*/
      RBX::Network::NetworkStream::writeFloat(this, value: Myfirst[v7].value.r); /*0x1410b5019*/
      RBX::Network::NetworkStream::writeFloat(this, value: Myfirst[v7].value.g); /*0x1410b5027*/
      RBX::Network::NetworkStream::writeFloat(this, value: Myfirst[v7].value.b); /*0x1410b5035*/
      RBX::Network::NetworkStream::writeFloat(this, value: Myfirst[v7++].envelope); /*0x1410b5043*/
      --v6; /*0x1410b504c*/
    }
    while ( v6 != 0 ); /*0x1410b5050*/
  }
}

// Address: 0x1410b5070 | Name: ?writeColorSequenceKeypoint@NetworkStream@Network@RBX@@QEAAXAEBVColorSequenceKeypoint@3@@Z
void __fastcall RBX::Network::NetworkStream::writeColorSequenceKeypoint(
        RBX::Network::NetworkStream *this,
        const RBX::ColorSequenceKeypoint *value)
{
  RBX::Network::NetworkStream::writeFloat(this, value: value->time); /*0x1410b5084*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->value.r); /*0x1410b5091*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->value.g); /*0x1410b509e*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->value.b); /*0x1410b50ab*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->envelope); /*0x1410b50c2*/
}

// Address: 0x1410b50d0 | Name: ?writeCoordinateFrame@NetworkStream@Network@RBX@@QEAAXAEBVCoordinateFrame@3@@Z
void __fastcall RBX::Network::NetworkStream::writeCoordinateFrame(
        RBX::Network::NetworkStream *this,
        const RBX::CoordinateFrame *cf)
{
  __int128 v3; // xmm1
  __int128 v5; // xmm0
  int OrientId; // eax
  RBX::CoordinateFrame value; // [rsp+20h] [rbp-38h] BYREF

  v3 = *(_OWORD *)&cf->rotation.elt[1][1]; /*0x1410b50e5*/
  *(_OWORD *)&value.rotation.elt[0][0] = *(_OWORD *)&cf->rotation.elt[0][0]; /*0x1410b50ec*/
  v5 = *(_OWORD *)&cf->rotation.elt[2][2]; /*0x1410b50f1*/
  *(_OWORD *)&value.rotation.elt[1][1] = v3; /*0x1410b50f5*/
  *(_OWORD *)&value.rotation.elt[2][2] = v5; /*0x1410b50fa*/
  rationalize(&value); /*0x1410b50ff*/
  RBX::Network::NetworkStream::writeFloat(this, value: value.translation.x); /*0x1410b510d*/
  RBX::Network::NetworkStream::writeFloat(this, value: value.translation.y); /*0x1410b511b*/
  RBX::Network::NetworkStream::writeFloat(this, value: value.translation.z); /*0x1410b5129*/
  OrientId = RBX::Math::getOrientId(matrix: &value.rotation, tolerance: 0.000001); /*0x1410b513b*/
  if ( OrientId < 0 ) /*0x1410b5145*/
  {
    RBX::Network::NetworkStream::writeByte(this, value: 0); /*0x1410b515c*/
    RBX::Network::Compressor::writeRotation(bitStream: this, rotation: &cf->rotation); /*0x1410b5167*/
  }
  else
  {
    RBX::Network::NetworkStream::writeByte(this, value: OrientId + 1); /*0x1410b514a*/
  }
}

// Address: 0x1410b5180 | Name: ?writeDateTime@NetworkStream@Network@RBX@@QEAAXAEBVDateTime@3@@Z
void __fastcall RBX::Network::NetworkStream::writeDateTime(RBX::Network::NetworkStream *this, RBX::DateTime *value)
{
  __int64 UnixTimestampMillis; // rax
  char v4; // cl
  unsigned int numberOfBytesUsed; // eax
  unsigned int numberOfBytesAllocated; // ecx
  unsigned int v7; // esi
  unsigned int v8; // esi
  unsigned __int8 *data; // rdx
  __int64 v10; // [rsp+30h] [rbp+8h]
  char v11; // [rsp+43h] [rbp+1Bh]

  UnixTimestampMillis = RBX::DateTime::getUnixTimestampMillis(this: value); /*0x1410b5190*/
  v11 = BYTE3(UnixTimestampMillis); /*0x1410b5195*/
  LOBYTE(v10) = HIBYTE(UnixTimestampMillis); /*0x1410b51a4*/
  BYTE1(v10) = BYTE6(UnixTimestampMillis); /*0x1410b51ad*/
  BYTE2(v10) = BYTE5(UnixTimestampMillis); /*0x1410b51b6*/
  BYTE5(v10) = BYTE2(UnixTimestampMillis); /*0x1410b51bf*/
  v4 = BYTE1(UnixTimestampMillis); /*0x1410b51c3*/
  HIBYTE(v10) = UnixTimestampMillis; /*0x1410b51c8*/
  numberOfBytesUsed = this->numberOfBytesUsed; /*0x1410b51cc*/
  BYTE3(v10) = BYTE4(UnixTimestampMillis); /*0x1410b51cf*/
  BYTE6(v10) = v4; /*0x1410b51d8*/
  numberOfBytesAllocated = this->numberOfBytesAllocated; /*0x1410b51dc*/
  BYTE4(v10) = v11; /*0x1410b51e2*/
  if ( numberOfBytesUsed + 8 <= numberOfBytesAllocated ) /*0x1410b51e8*/
  {
    data = this->data; /*0x1410b5220*/
  }
  else
  {
    v7 = numberOfBytesUsed + 8 - numberOfBytesAllocated; /*0x1410b51ea*/
    if ( v7 < DFInt::NetworkStreamMinGrowSize ) /*0x1410b51f7*/
      v7 = DFInt::NetworkStreamMinGrowSize; /*0x1410b51f7*/
    v8 = numberOfBytesAllocated + v7; /*0x1410b51fe*/
    std::vector<unsigned char>::resize(this: &this->dataVector, _Newsize: v8); /*0x1410b5206*/
    data = this->dataVector._Mypair._Myval2._Myfirst; /*0x1410b520b*/
    numberOfBytesUsed = this->numberOfBytesUsed; /*0x1410b520f*/
    this->data = data; /*0x1410b5217*/
    this->numberOfBytesAllocated = v8; /*0x1410b521b*/
  }
  *(_QWORD *)&data[numberOfBytesUsed] = v10; /*0x1410b5230*/
  this->numberOfBytesUsed += 8; /*0x1410b5234*/
}

// Address: 0x1410b5240 | Name: ?writeFont@NetworkStream@Network@RBX@@QEAAXAEBVFontInfo@Text@3@H@Z
void __fastcall RBX::Network::NetworkStream::writeFont(
        RBX::Network::NetworkStream *this,
        const RBX::Text::FontInfo *value,
        unsigned int maxStringWriteSize)
{
  char *Myfirst; // rbp
  char *v7; // rbx
  RBX::Graphics::ProfilerAdorn::Item *v8; // rax
  std::string result; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  RBX::Network::NetworkStream::writeInt16(this, value: value->weight); /*0x1410b5264*/
  RBX::Network::NetworkStream::writeByte(this, value: value->style); /*0x1410b5270*/
  RBX::Network::NetworkStream::writeString(this, value: &value->family.id, maxStringWriteSize); /*0x1410b527e*/
  Myfirst = value->cachedFaceId._Mypair._Myval2._Myfirst; /*0x1410b5283*/
  v7 = (char *)(value->cachedFaceId._Mypair._Myval2._Mylast - Myfirst); /*0x1410b528b*/
  if ( DFFlag::NetworkReportStringOverLimit.value && (unsigned int)v7 > DFInt::NetworkReportStringOverLimitWrite ) /*0x1410b529d*/
    RBX::Network::NetworkStream::reportStringLengthLimit( /*0x1410b52a6*/
      isWrite: true,
      lengthWanted: (unsigned int)v7,
      limitWanted: maxStringWriteSize);
  if ( (unsigned int)v7 > maxStringWriteSize )
  {
    v8 = RBX::format(
           (RBX::Graphics::ProfilerAdorn::Item *)&result,
           fmt: "BitStream string write: String too long: %u",
           (_DWORD)v7);
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &v8->text); /*0x1410b52fc*/
      throw &pExceptionObject; /*0x1410b530d*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000014*/
    }
  }
  RBX::Network::NetworkStream::writeUInt32(this, value: (unsigned int)v7); /*0x1410b52b4*/
  RBX::Network::NetworkStream::writeBytes(this, inByteArray: Myfirst, numberOfBytesToWrite: (unsigned int)v7); /*0x1410b52da*/
}

// Address: 0x1410b5320 | Name: ?writeFromStream@NetworkStream@Network@RBX@@QEAAXAEAV123@I@Z
void __fastcall RBX::Network::NetworkStream::writeFromStream(
        RBX::Network::NetworkStream *this,
        RBX::Network::NetworkStream *bitStream,
        unsigned int numberOfBytes)
{
  __int64 readOffset; // rbx
  unsigned __int8 *v7; // rax

  readOffset = (int)bitStream->readOffset; /*0x1410b533b*/
  v7 = bitStream->GetData(this: bitStream); /*0x1410b5348*/
  RBX::Network::NetworkStream::writeBytes(this, inByteArray: &v7[readOffset], numberOfBytesToWrite: numberOfBytes); /*0x1410b5355*/
  bitStream->readOffset = readOffset + numberOfBytes; /*0x1410b536c*/
}

// Address: 0x1410b5380 | Name: ?writeNumberRange@NetworkStream@Network@RBX@@QEAAXAEBVNumberRange@3@@Z
void __fastcall RBX::Network::NetworkStream::writeNumberRange(
        RBX::Network::NetworkStream *this,
        const RBX::Vector2 *value)
{
  RBX::Network::NetworkStream::writeFloat(this, value: value->x); /*0x1410b5394*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->y); /*0x1410b53ab*/
}

// Address: 0x1410b53b0 | Name: ?writeNumberSequence@NetworkStream@Network@RBX@@QEAAXAEBVNumberSequence@3@@Z
void __fastcall RBX::Network::NetworkStream::writeNumberSequence(
        RBX::Network::NetworkStream *this,
        const RBX::NumberSequence *value)
{
  unsigned __int64 v4; // rdx
  signed __int64 v5; // rcx
  __int64 v6; // rbp
  __int64 v7; // rdi
  RBX::NumberSequenceKeypoint *Myfirst; // rbx

  v4 = (__int64)((unsigned __int128)(((char *)value->m_data._Mypair._Myval2._Mylast /*0x1410b53e2*/
                                    - (char *)value->m_data._Mypair._Myval2._Myfirst)
                                   * (__int128)0x2AAAAAAAAAAAAAABLL) >> 64) >> 1;
  RBX::Network::NetworkStream::writeUInt32(this, value: (v4 >> 63) + v4); /*0x1410b53ef*/
  v5 = (char *)value->m_data._Mypair._Myval2._Mylast - (char *)value->m_data._Mypair._Myval2._Myfirst; /*0x1410b53fb*/
  v6 = (int)(v5 / 12); /*0x1410b540e*/
  if ( (int)(v5 / 12) > 0 ) /*0x1410b5413*/
  {
    v7 = 0; /*0x1410b541a*/
    do /*0x1410b5454*/
    {
      Myfirst = value->m_data._Mypair._Myval2._Myfirst; /*0x1410b5420*/
      RBX::Network::NetworkStream::writeFloat(this, value: value->m_data._Mypair._Myval2._Myfirst[v7].time); /*0x1410b542b*/
      RBX::Network::NetworkStream::writeFloat(this, value: Myfirst[v7].value); /*0x1410b5439*/
      RBX::Network::NetworkStream::writeFloat(this, value: Myfirst[v7++].envelope); /*0x1410b5447*/
      --v6; /*0x1410b5450*/
    }
    while ( v6 != 0 ); /*0x1410b5454*/
  }
}

// Address: 0x1410b5480 | Name: ?writeOptionalCoordinateFrame@NetworkStream@Network@RBX@@QEAAXAEBVOptionalCoordinateFrame@3@@Z
void __fastcall RBX::Network::NetworkStream::writeOptionalCoordinateFrame(
        RBX::Network::NetworkStream *this,
        RBX::OptionalCoordinateFrame *optionalCFrame)
{
  const RBX::CoordinateFrame *v4; // rax
  __int128 v5; // xmm0
  int OrientId; // eax
  RBX::CoordinateFrame value; // [rsp+20h] [rbp-68h] BYREF
  RBX::CoordinateFrame v8; // [rsp+50h] [rbp-38h] BYREF

  if ( RBX::OptionalCoordinateFrame::has_value(this: optionalCFrame) ) /*0x1410b5496*/
  {
    v4 = RBX::OptionalCoordinateFrame::get(this: optionalCFrame); /*0x1410b54a6*/
    *(_OWORD *)&v8.rotation.elt[0][0] = *(_OWORD *)&v4->rotation.elt[0][0]; /*0x1410b54b3*/
    *(_OWORD *)&v8.rotation.elt[1][1] = *(_OWORD *)&v4->rotation.elt[1][1]; /*0x1410b54bc*/
    v5 = *(_OWORD *)&v4->rotation.elt[2][2]; /*0x1410b54c1*/
    *(_OWORD *)&value.rotation.elt[0][0] = *(_OWORD *)&v8.rotation.elt[0][0]; /*0x1410b54c5*/
    *(_OWORD *)&v8.rotation.elt[2][2] = v5; /*0x1410b54ca*/
    *(_OWORD *)&value.rotation.elt[2][2] = v5; /*0x1410b54cf*/
    *(_OWORD *)&value.rotation.elt[1][1] = *(_OWORD *)&v8.rotation.elt[1][1]; /*0x1410b54d4*/
    rationalize(&value); /*0x1410b54d9*/
    OrientId = RBX::Math::getOrientId(matrix: &value.rotation, tolerance: 0.000001); /*0x1410b54eb*/
    if ( OrientId < 0 ) /*0x1410b54f5*/
    {
      RBX::Network::NetworkStream::writeByte(this, value: 0x80u); /*0x1410b5506*/
      RBX::Network::Compressor::writeRotation(bitStream: this, rotation: &v8.rotation); /*0x1410b5513*/
    }
    else
    {
      RBX::Network::NetworkStream::writeByte(this, value: (OrientId + 1) | 0x80); /*0x1410b54fd*/
    }
    RBX::Network::NetworkStream::writeFloat(this, value: value.translation.x); /*0x1410b5521*/
    RBX::Network::NetworkStream::writeFloat(this, value: value.translation.y); /*0x1410b552f*/
    RBX::Network::NetworkStream::writeFloat(this, value: value.translation.z); /*0x1410b553d*/
  }
  else
  {
    RBX::Network::NetworkStream::writeByte(this, value: 0); /*0x1410b5568*/
  }
}

// Address: 0x1410b5570 | Name: ?writePathWaypointWithLabel@NetworkStream@Network@RBX@@QEAAXAEBVPathWaypoint@3@H@Z
void __fastcall RBX::Network::NetworkStream::writePathWaypointWithLabel(
        RBX::Network::NetworkStream *this,
        const RBX::PathWaypoint *value,
        int writePayloadLimit)
{
  RBX::PathWaypoint::WayPointData *Ptr; // rbx

  Ptr = value->data._Ptr; /*0x1410b5584*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->data._Ptr->position.x); /*0x1410b5594*/
  RBX::Network::NetworkStream::writeFloat(this, value: Ptr->position.y); /*0x1410b55a1*/
  RBX::Network::NetworkStream::writeFloat(this, value: Ptr->position.z); /*0x1410b55ae*/
  RBX::Network::NetworkStream::writeByte(this, value: value->data._Ptr->action); /*0x1410b55bd*/
  RBX::Network::NetworkStream::writeString(this, value: &value->data._Ptr->label, maxStringWriteSize: writePayloadLimit); /*0x1410b55e3*/
}

// Address: 0x1410b55f0 | Name: ?writePhysicalProperties@NetworkStream@Network@RBX@@QEAAXAEBVPhysicalProperties@3@@Z
void __fastcall RBX::Network::NetworkStream::writePhysicalProperties(
        RBX::Network::NetworkStream *this,
        const RBX::PhysicalProperties *value)
{
  bool customEnabled; // bl

  customEnabled = value->customEnabled; /*0x1410b55ff*/
  RBX::Network::NetworkStream::writeByte(this, value: value->customEnabled); /*0x1410b560b*/
  if ( customEnabled ) /*0x1410b5612*/
  {
    RBX::Network::NetworkStream::writeFloat(this, value: value->density); /*0x1410b561c*/
    RBX::Network::NetworkStream::writeFloat(this, value: value->friction); /*0x1410b5629*/
    RBX::Network::NetworkStream::writeFloat(this, value: value->elasticity); /*0x1410b5636*/
    RBX::Network::NetworkStream::writeFloat(this, value: value->frictionWeight); /*0x1410b5643*/
    RBX::Network::NetworkStream::writeFloat(this, value: value->elasticityWeight); /*0x1410b5650*/
  }
}

// Address: 0x1410b5670 | Name: ?writeRakString@NetworkStream@Network@RBX@@QEAAXAEBVRakString@RakNet@@@Z
void __fastcall RBX::Network::NetworkStream::writeRakString(
        RBX::Network::NetworkStream *this,
        RakNet::RakString *value)
{
  unsigned __int16 Length; // bx

  Length = RakNet::RakString::GetLength(this: value); /*0x1410b5693*/
  RBX::Network::NetworkStream::writeInt16(this, value: Length); /*0x1410b5696*/
  RBX::Network::NetworkStream::writeBytes(this, inByteArray: value->sharedString->c_str, numberOfBytesToWrite: Length); /*0x1410b56b8*/
}

// Address: 0x1410b56c0 | Name: ?writeRay@NetworkStream@Network@RBX@@QEAAXAEBVRay@3@@Z
void __fastcall RBX::Network::NetworkStream::writeRay(RBX::Network::NetworkStream *this, const RBX::Ray *value)
{
  RBX::Network::NetworkStream::writeFloat(this, value: value->m_origin.x); /*0x1410b56d4*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->m_origin.y); /*0x1410b56e1*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->m_origin.z); /*0x1410b56ee*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->m_direction.x); /*0x1410b56fb*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->m_direction.y); /*0x1410b5708*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->m_direction.z); /*0x1410b571f*/
}

// Address: 0x1410b5730 | Name: ?writeRect2D@NetworkStream@Network@RBX@@QEAAXAEBVRect2D@3@@Z
void __fastcall RBX::Network::NetworkStream::writeRect2D(RBX::Network::NetworkStream *this, const RBX::Rect2D *value)
{
  __m128 min; // xmm6

  min = (__m128)(unsigned __int64)value->min; /*0x1410b5742*/
  RBX::Network::NetworkStream::writeFloat(this, value: COERCE_FLOAT(*(_QWORD *)&value->min)); /*0x1410b574c*/
  RBX::Network::NetworkStream::writeFloat(this, value: _mm_shuffle_ps(min, min, 85).m128_f32[0]); /*0x1410b575e*/
  min.m128_i32[0] = LODWORD(value->max.y); /*0x1410b576b*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->max.x); /*0x1410b5770*/
  RBX::Network::NetworkStream::writeFloat(this, value: min.m128_f32[0]); /*0x1410b578a*/
}

// Address: 0x1410b5790 | Name: ?writeRegion3@NetworkStream@Network@RBX@@QEAAXAEBVRegion3@3@@Z
void __fastcall RBX::Network::NetworkStream::writeRegion3(RBX::Network::NetworkStream *this, RBX::Region3 *value)
{
  RBX::Vector3 *v4; // rbx
  RBX::Vector3 *v5; // rbx
  RBX::Vector3 result; // [rsp+20h] [rbp-18h] BYREF

  v4 = RBX::Region3::minPos(this: value, &result); /*0x1410b57b5*/
  RBX::Network::NetworkStream::writeFloat(this, value: v4->x); /*0x1410b57bc*/
  RBX::Network::NetworkStream::writeFloat(this, value: v4->y); /*0x1410b57c9*/
  RBX::Network::NetworkStream::writeFloat(this, value: v4->z); /*0x1410b57d6*/
  v5 = RBX::Region3::maxPos(this: value, &result); /*0x1410b57eb*/
  RBX::Network::NetworkStream::writeFloat(this, value: v5->x); /*0x1410b57f2*/
  RBX::Network::NetworkStream::writeFloat(this, value: v5->y); /*0x1410b57ff*/
  RBX::Network::NetworkStream::writeFloat(this, value: v5->z); /*0x1410b580c*/
}

// Address: 0x1410b5830 | Name: ?writeRegion3int16@NetworkStream@Network@RBX@@QEAAXAEBVRegion3int16@3@@Z
void __fastcall RBX::Network::NetworkStream::writeRegion3int16(
        RBX::Network::NetworkStream *this,
        const RBX::Region3int16 *value)
{
  RBX::Network::NetworkStream::writeInt16(this, value: value->minPos.x); /*0x1410b5843*/
  RBX::Network::NetworkStream::writeInt16(this, value: value->minPos.y); /*0x1410b584f*/
  RBX::Network::NetworkStream::writeInt16(this, value: value->minPos.z); /*0x1410b585b*/
  RBX::Network::NetworkStream::writeInt16(this, value: value->maxPos.x); /*0x1410b5867*/
  RBX::Network::NetworkStream::writeInt16(this, value: value->maxPos.y); /*0x1410b5873*/
  RBX::Network::NetworkStream::writeInt16(this, value: value->maxPos.z); /*0x1410b5889*/
}

// Address: 0x1410b5890 | Name: ?writeStreamRegionId@NetworkStream@Network@RBX@@QEAAXAEBVId@StreamRegion@3@@Z
void __fastcall RBX::Network::NetworkStream::writeStreamRegionId(
        RBX::Network::NetworkStream *this,
        const RBX::StreamRegion::Id *value)
{
  int x; // ecx
  int y; // eax
  int z; // edx

  x = value->internalValue.x; /*0x1410b58a0*/
  if ( value->internalValue.x > 127 /*0x1410b58c4*/
    || (y = value->internalValue.y) > 127
    || (z = value->internalValue.z) > 127
    || x < -128
    || y < -128
    || z < -128 )
  {
    RBX::Network::NetworkStream::writeByte(this, value: 1u); /*0x1410b5902*/
    RBX::Network::NetworkStream::writeUInt32(this, value: value->internalValue.x); /*0x1410b590c*/
    RBX::Network::NetworkStream::writeUInt32(this, value: value->internalValue.y); /*0x1410b5917*/
    RBX::Network::NetworkStream::writeUInt32(this, value: value->internalValue.z); /*0x1410b592c*/
  }
  else
  {
    RBX::Network::NetworkStream::writeByte(this, value: 0); /*0x1410b58cb*/
    RBX::Network::NetworkStream::writeByte(this, value: value->internalValue.x); /*0x1410b58d6*/
    RBX::Network::NetworkStream::writeByte(this, value: value->internalValue.y); /*0x1410b58e2*/
    RBX::Network::NetworkStream::writeByte(this, value: value->internalValue.z); /*0x1410b58f8*/
  }
}

// Address: 0x1410b5940 | Name: ?writeString@NetworkStream@Network@RBX@@QEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@H@Z
void __fastcall RBX::Network::NetworkStream::writeString(
        RBX::Network::NetworkStream *this,
        const std::string *value,
        unsigned int maxStringWriteSize)
{
  const std::string *Ptr; // rdi
  unsigned __int64 Mysize; // rbx
  RBX::Graphics::ProfilerAdorn::Item *v7; // rax
  std::string result; // [rsp+20h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-48h] BYREF

  Ptr = value; /*0x1410b595a*/
  Mysize = value->_Mypair._Myval2._Mysize; /*0x1410b5960*/
  if ( value->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410b5969*/
    Ptr = (const std::string *)value->_Mypair._Myval2._Bx._Ptr; /*0x1410b596b*/
  if ( DFFlag::NetworkReportStringOverLimit.value && (unsigned int)Mysize > DFInt::NetworkReportStringOverLimitWrite ) /*0x1410b597d*/
    RBX::Network::NetworkStream::reportStringLengthLimit( /*0x1410b5983*/
      isWrite: true,
      lengthWanted: Mysize,
      limitWanted: maxStringWriteSize);
  if ( (unsigned int)Mysize > maxStringWriteSize )
  {
    v7 = RBX::format(
           (RBX::Graphics::ProfilerAdorn::Item *)&result,
           fmt: "BitStream string write: String too long: %u",
           Mysize);
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: &v7->text); /*0x1410b59d9*/
      throw &pExceptionObject; /*0x1410b59ea*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000014*/
    }
  }
  RBX::Network::NetworkStream::writeUInt32(this, value: Mysize); /*0x1410b5991*/
  RBX::Network::NetworkStream::writeBytes(this, inByteArray: Ptr, numberOfBytesToWrite: Mysize); /*0x1410b59b7*/
}

// Address: 0x1410b59f0 | Name: ?writeUDim2@NetworkStream@Network@RBX@@QEAAXAEBVUDim2@3@@Z
void __fastcall RBX::Network::NetworkStream::writeUDim2(RBX::Network::NetworkStream *this, const RBX::UDim2 *value)
{
  RBX::Network::NetworkStream::writeFloat(this, value: value->x.scale); /*0x1410b5a04*/
  RBX::Network::NetworkStream::writeUInt32(this, value: value->x.offset); /*0x1410b5a0f*/
  RBX::Network::NetworkStream::writeFloat(this, value: value->y.scale); /*0x1410b5a1c*/
  RBX::Network::NetworkStream::writeUInt32(this, value: value->y.offset); /*0x1410b5a31*/
}

// Address: 0x1410b5a40 | Name: ?writeUDim@NetworkStream@Network@RBX@@QEAAXAEBVUDim@3@@Z
void __fastcall RBX::Network::NetworkStream::writeUDim(RBX::Network::NetworkStream *this, const RBX::UDim *value)
{
  RBX::Network::NetworkStream::writeFloat(this, value: value->scale); /*0x1410b5a54*/
  RBX::Network::NetworkStream::writeUInt32(this, value: value->offset); /*0x1410b5a69*/
}

// Address: 0x1410b5a70 | Name: ?writeVector2int16@NetworkStream@Network@RBX@@QEAAXAEBVVector2int16@3@@Z
void __fastcall RBX::Network::NetworkStream::writeVector2int16(
        RBX::Network::NetworkStream *this,
        const RBX::Vector2int16 *value)
{
  RBX::Network::NetworkStream::writeInt16(this, value: value->x); /*0x1410b5a83*/
  RBX::Network::NetworkStream::writeInt16(this, value: value->y); /*0x1410b5a99*/
}

// Address: 0x1410b5aa0 | Name: ?writeVector3int16@NetworkStream@Network@RBX@@QEAAXAEBVVector3int16@3@@Z
void __fastcall RBX::Network::NetworkStream::writeVector3int16(
        RBX::Network::NetworkStream *this,
        const RBX::Vector3int16 *value)
{
  RBX::Network::NetworkStream::writeInt16(this, value: value->x); /*0x1410b5ab3*/
  RBX::Network::NetworkStream::writeInt16(this, value: value->y); /*0x1410b5abf*/
  RBX::Network::NetworkStream::writeInt16(this, value: value->z); /*0x1410b5ad5*/
}

// END NetworkStream part 1/1, 83 functions
