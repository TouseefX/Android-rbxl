; RakPeer vtable slot 30
; rva 0x2880bf0
0x142880bf0:  0fb78112010000       movzx     eax, word ptr [rcx + 0x112]
0x142880bf7:  c3                   ret       
0x142880bf8:  cc                   int3      
0x142880bf9:  cc                   int3      
0x142880bfa:  cc                   int3      
0x142880bfb:  cc                   int3      
0x142880bfc:  cc                   int3      
0x142880bfd:  cc                   int3      
0x142880bfe:  cc                   int3      
0x142880bff:  cc                   int3      
