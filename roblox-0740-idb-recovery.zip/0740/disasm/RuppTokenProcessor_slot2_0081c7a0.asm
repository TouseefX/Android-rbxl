; RuppTokenProcessor vtable slot 2 rva 0x81c7a0
0x14081c7a0:  b001                 mov       al, 1
0x14081c7a2:  c3                   ret       
0x14081c7a3:  cc                   int3      
0x14081c7a4:  cc                   int3      
0x14081c7a5:  cc                   int3      
0x14081c7a6:  cc                   int3      
0x14081c7a7:  cc                   int3      
0x14081c7a8:  cc                   int3      
0x14081c7a9:  cc                   int3      
0x14081c7aa:  cc                   int3      
0x14081c7ab:  cc                   int3      
0x14081c7ac:  cc                   int3      
0x14081c7ad:  cc                   int3      
0x14081c7ae:  cc                   int3      
0x14081c7af:  cc                   int3      
0x14081c7b0:  48895c2410           mov       qword ptr [rsp + 0x10], rbx
0x14081c7b5:  4489442418           mov       dword ptr [rsp + 0x18], r8d
0x14081c7ba:  48894c2408           mov       qword ptr [rsp + 8], rcx
0x14081c7bf:  55                   push      rbp
0x14081c7c0:  56                   push      rsi
0x14081c7c1:  57                   push      rdi
0x14081c7c2:  4883ec60             sub       rsp, 0x60
0x14081c7c6:  488bda               mov       rbx, rdx
0x14081c7c9:  488bf1               mov       rsi, rcx
0x14081c7cc:  33ed                 xor       ebp, ebp
0x14081c7ce:  488b01               mov       rax, qword ptr [rcx]
0x14081c7d1:  4c634004             movsxd    r8, dword ptr [rax + 4]
0x14081c7d5:  488d05bccea405       lea       rax, [rip + 0x5a4cebc]
0x14081c7dc:  49890408             mov       qword ptr [r8 + rcx], rax
0x14081c7e0:  488b01               mov       rax, qword ptr [rcx]
0x14081c7e3:  4c634004             movsxd    r8, dword ptr [rax + 4]
0x14081c7e7:  458d48e8             lea       r9d, [r8 - 0x18]
0x14081c7eb:  45894c08fc           mov       dword ptr [r8 + rcx - 4], r9d
0x14081c7f0:  48896908             mov       qword ptr [rcx + 8], rbp
0x14081c7f4:  488b01               mov       rax, qword ptr [rcx]
0x14081c7f7:  48637804             movsxd    rdi, dword ptr [rax + 4]
0x14081c7fb:  4803f9               add       rdi, rcx
0x14081c7fe:  488bcf               mov       rcx, rdi
0x14081c801:  e8da8dfdff           call      0x1407f55e0
0x14081c806:  48895f48             mov       qword ptr [rdi + 0x48], rbx
0x14081c80a:  48896f50             mov       qword ptr [rdi + 0x50], rbp
0x14081c80e:  488b4740             mov       rax, qword ptr [rdi + 0x40]
0x14081c812:  488b5808             mov       rbx, qword ptr [rax + 8]
0x14081c816:  48895c2428           mov       qword ptr [rsp + 0x28], rbx
0x14081c81b:  488b03               mov       rax, qword ptr [rbx]
0x14081c81e:  488bcb               mov       rcx, rbx
0x14081c821:  488b4008             mov       rax, qword ptr [rax + 8]
0x14081c825:  ff150d359205         call      qword ptr [rip + 0x592350d]
0x14081c82b:  90                   nop       
0x14081c82c:  488d4c2420           lea       rcx, [rsp + 0x20]
0x14081c831:  e88a2e0000           call      0x14081f6c0
0x14081c836:  4c8bc0               mov       r8, rax
0x14081c839:  488b08               mov       rcx, qword ptr [rax]
0x14081c83c:  488b4140             mov       rax, qword ptr [rcx + 0x40]
0x14081c840:  b220                 mov       dl, 0x20
0x14081c842:  498bc8               mov       rcx, r8
0x14081c845:  ff15ed349205         call      qword ptr [rip + 0x59234ed]
0x14081c84b:  0fb6e8               movzx     ebp, al
0x14081c84e:  4885db               test      rbx, rbx
0x14081c851:  742c                 je        0x14081c87f
0x14081c853:  488b13               mov       rdx, qword ptr [rbx]
0x14081c856:  488bcb               mov       rcx, rbx
0x14081c859:  488b4210             mov       rax, qword ptr [rdx + 0x10]
0x14081c85d:  ff15d5349205         call      qword ptr [rip + 0x59234d5]
0x14081c863:  4c8bc0               mov       r8, rax
0x14081c866:  4885c0               test      rax, rax
0x14081c869:  7414                 je        0x14081c87f
0x14081c86b:  488b08               mov       rcx, qword ptr [rax]
0x14081c86e:  488b01               mov       rax, qword ptr [rcx]
0x14081c871:  ba01000000           mov       edx, 1
0x14081c876:  498bc8               mov       rcx, r8
0x14081c879:  ff15b9349205         call      qword ptr [rip + 0x59234b9]
0x14081c87f:  40886f58             mov       byte ptr [rdi + 0x58], bpl
0x14081c883:  48837f4800           cmp       qword ptr [rdi + 0x48], 0
0x14081c888:  7511                 jne       0x14081c89b
0x14081c88a:  8b4710               mov       eax, dword ptr [rdi + 0x10]
0x14081c88d:  83e013               and       eax, 0x13
0x14081c890:  83c804               or        eax, 4
0x14081c893:  894710               mov       dword ptr [rdi + 0x10], eax
0x14081c896:  234714               and       eax, dword ptr [rdi + 0x14]
0x14081c899:  7556                 jne       0x14081c8f1
0x14081c89b:  488b4610             mov       rax, qword ptr [rsi + 0x10]
0x14081c89f:  48634804             movsxd    rcx, dword ptr [rax + 4]
0x14081c8a3:  488d05b6c5a405       lea       rax, [rip + 0x5a4c5b6]
0x14081c8aa:  4889443110           mov       qword ptr [rcx + rsi + 0x10], rax
0x14081c8af:  488b4610             mov       rax, qword ptr [rsi + 0x10]
0x14081c8b3:  48634804             movsxd    rcx, dword ptr [rax + 4]
0x14081c8b7:  8d51f0               lea       edx, [rcx - 0x10]
0x14081c8ba:  8954310c             mov       dword ptr [rcx + rsi + 0xc], edx
0x14081c8be:  488b06               mov       rax, qword ptr [rsi]
0x14081c8c1:  48634804             movsxd    rcx, dword ptr [rax + 4]
0x14081c8c5:  488d05dccda405       lea       rax, [rip + 0x5a4cddc]
0x14081c8cc:  48890431             mov       qword ptr [rcx + rsi], rax
0x14081c8d0:  488b06               mov       rax, qword ptr [rsi]
0x14081c8d3:  48634804             movsxd    rcx, dword ptr [rax + 4]
0x14081c8d7:  8d51e0               lea       edx, [rcx - 0x20]
0x14081c8da:  895431fc             mov       dword ptr [rcx + rsi - 4], edx
0x14081c8de:  488bc6               mov       rax, rsi
0x14081c8e1:  488b9c2488000000     mov       rbx, qword ptr [rsp + 0x88]
0x14081c8e9:  4883c460             add       rsp, 0x60
0x14081c8ed:  5f                   pop       rdi
0x14081c8ee:  5e                   pop       rsi
0x14081c8ef:  5d                   pop       rbp
0x14081c8f0:  c3                   ret       
0x14081c8f1:  a804                 test      al, 4
0x14081c8f3:  7409                 je        0x14081c8fe
0x14081c8f5:  488d1d64de5c06       lea       rbx, [rip + 0x65cde64]
0x14081c8fc:  eb14                 jmp       0x14081c912
0x14081c8fe:  a802                 test      al, 2
0x14081c900:  488d1d71de5c06       lea       rbx, [rip + 0x65cde71]
0x14081c907:  488d0582de5c06       lea       rax, [rip + 0x65cde82]
0x14081c90e:  480f44d8             cmove     rbx, rax
0x14081c912:  ba01000000           mov       edx, 1
0x14081c917:  488d4c2420           lea       rcx, [rsp + 0x20]
0x14081c91c:  e8df79fdff           call      0x1407f4300
0x14081c921:  4c8bc0               mov       r8, rax
0x14081c924:  488bd3               mov       rdx, rbx
0x14081c927:  488d4c2430           lea       rcx, [rsp + 0x30]
0x14081c92c:  e89f8bfdff           call      0x1407f54d0
0x14081c931:  488d1550ad4e07       lea       rdx, [rip + 0x74ead50]
0x14081c938:  488d4c2430           lea       rcx, [rsp + 0x30]
0x14081c93d:  e80e673205           call      0x145b43050
0x14081c942:  cc                   int3      
0x14081c943:  cc                   int3      
0x14081c944:  cc                   int3      
0x14081c945:  cc                   int3      
0x14081c946:  cc                   int3      
0x14081c947:  cc                   int3      
0x14081c948:  cc                   int3      
0x14081c949:  cc                   int3      
0x14081c94a:  cc                   int3      
0x14081c94b:  cc                   int3      
0x14081c94c:  cc                   int3      
0x14081c94d:  cc                   int3      
0x14081c94e:  cc                   int3      
0x14081c94f:  cc                   int3      
0x14081c950:  4c8b4918             mov       r9, qword ptr [rcx + 0x18]
0x14081c954:  488d4170             lea       rax, [rcx + 0x70]
0x14081c958:  493901               cmp       qword ptr [r9], rax
0x14081c95b:  7522                 jne       0x14081c97f
0x14081c95d:  488b9188000000       mov       rdx, qword ptr [rcx + 0x88]
0x14081c964:  4c8b8190000000       mov       r8, qword ptr [rcx + 0x90]
0x14081c96b:  498911               mov       qword ptr [r9], rdx
0x14081c96e:  442bc2               sub       r8d, edx
0x14081c971:  488b4138             mov       rax, qword ptr [rcx + 0x38]
0x14081c975:  488910               mov       qword ptr [rax], rdx
0x14081c978:  488b4150             mov       rax, qword ptr [rcx + 0x50]
0x14081c97c:  448900               mov       dword ptr [rax], r8d
0x14081c97f:  c3                   ret       
0x14081c980:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x14081c985:  57                   push      rdi
0x14081c986:  4883ec20             sub       rsp, 0x20
0x14081c98a:  488b02               mov       rax, qword ptr [rdx]
0x14081c98d:  488bd9               mov       rbx, rcx
0x14081c990:  488bca               mov       rcx, rdx
0x14081c993:  488bfa               mov       rdi, rdx
0x14081c996:  488b4018             mov       rax, qword ptr [rax + 0x18]
0x14081c99a:  ff1598339205         call      qword ptr [rip + 0x5923398]
0x14081c9a0:  4533db               xor       r11d, r11d
0x14081c9a3:  84c0                 test      al, al
0x14081c9a5:  740f                 je        0x14081c9b6
0x14081c9a7:  4c895b68             mov       qword ptr [rbx + 0x68], r11
0x14081c9ab:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14081c9b0:  4883c420             add       rsp, 0x20
0x14081c9b4:  5f                   pop       rdi
0x14081c9b5:  c3                   ret       
0x14081c9b6:  48897b68             mov       qword ptr [rbx + 0x68], rdi
0x14081c9ba:  4c8d5308             lea       r10, [rbx + 8]
0x14081c9be:  4c895318             mov       qword ptr [rbx + 0x18], r10
0x14081c9c2:  4c8d4310             lea       r8, [rbx + 0x10]
0x14081c9c6:  4c894320             mov       qword ptr [rbx + 0x20], r8
0x14081c9ca:  4c8d4b28             lea       r9, [rbx + 0x28]
0x14081c9ce:  4c894b38             mov       qword ptr [rbx + 0x38], r9
0x14081c9d2:  488d4b30             lea       rcx, [rbx + 0x30]
0x14081c9d6:  48894b40             mov       qword ptr [rbx + 0x40], rcx
0x14081c9da:  488d5348             lea       rdx, [rbx + 0x48]
0x14081c9de:  48895350             mov       qword ptr [rbx + 0x50], rdx
0x14081c9e2:  488d434c             lea       rax, [rbx + 0x4c]
0x14081c9e6:  48894358             mov       qword ptr [rbx + 0x58], rax
0x14081c9ea:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14081c9ef:  4d8918               mov       qword ptr [r8], r11
0x14081c9f2:  4c8919               mov       qword ptr [rcx], r11
0x14081c9f5:  448918               mov       dword ptr [rax], r11d
0x14081c9f8:  4d891a               mov       qword ptr [r10], r11
0x14081c9fb:  4d8919               mov       qword ptr [r9], r11
0x14081c9fe:  44891a               mov       dword ptr [rdx], r11d
0x14081ca01:  4883c420             add       rsp, 0x20
0x14081ca05:  5f                   pop       rdi
0x14081ca06:  c3                   ret       
0x14081ca07:  cc                   int3      
0x14081ca08:  cc                   int3      
0x14081ca09:  cc                   int3      
0x14081ca0a:  cc                   int3      
0x14081ca0b:  cc                   int3      
0x14081ca0c:  cc                   int3      
0x14081ca0d:  cc                   int3      
0x14081ca0e:  cc                   int3      
0x14081ca0f:  cc                   int3      
