; RakPeer vtable slot 18
; rva 0x287fa30
0x14287fa30:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x14287fa35:  57                   push      rdi
0x14287fa36:  4883ec20             sub       rsp, 0x20
0x14287fa3a:  488db9d80c0000       lea       rdi, [rcx + 0xcd8]
0x14287fa41:  488bd9               mov       rbx, rcx
0x14287fa44:  488bcf               mov       rcx, rdi
0x14287fa47:  e8643d2a03           call      0x145b237b0
0x14287fa4c:  85c0                 test      eax, eax
0x14287fa4e:  751b                 jne       0x14287fa6b
0x14287fa50:  8b9b280d0000         mov       ebx, dword ptr [rbx + 0xd28]
0x14287fa56:  488bcf               mov       rcx, rdi
0x14287fa59:  e8b23d2a03           call      0x145b23810
0x14287fa5e:  8bc3                 mov       eax, ebx
0x14287fa60:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14287fa65:  4883c420             add       rsp, 0x20
0x14287fa69:  5f                   pop       rdi
0x14287fa6a:  c3                   ret       
0x14287fa6b:  8bc8                 mov       ecx, eax
0x14287fa6d:  e80e432a03           call      0x145b23d80
0x14287fa72:  cc                   int3      
0x14287fa73:  cc                   int3      
0x14287fa74:  cc                   int3      
0x14287fa75:  cc                   int3      
0x14287fa76:  cc                   int3      
0x14287fa77:  cc                   int3      
0x14287fa78:  cc                   int3      
0x14287fa79:  cc                   int3      
0x14287fa7a:  cc                   int3      
0x14287fa7b:  cc                   int3      
0x14287fa7c:  cc                   int3      
0x14287fa7d:  cc                   int3      
0x14287fa7e:  cc                   int3      
0x14287fa7f:  cc                   int3      
0x14287fa80:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x14287fa85:  57                   push      rdi
0x14287fa86:  4883ec20             sub       rsp, 0x20
0x14287fa8a:  488bf9               mov       rdi, rcx
0x14287fa8d:  4881c1d80c0000       add       rcx, 0xcd8
0x14287fa94:  e8173d2a03           call      0x145b237b0
0x14287fa99:  85c0                 test      eax, eax
0x14287fa9b:  753c                 jne       0x14287fad9
0x14287fa9d:  b801000000           mov       eax, 1
0x14287faa2:  48895c2430           mov       qword ptr [rsp + 0x30], rbx
0x14287faa7:  8b9f280d0000         mov       ebx, dword ptr [rdi + 0xd28]
0x14287faad:  488d8fd80c0000       lea       rcx, [rdi + 0xcd8]
0x14287fab4:  8d5301               lea       edx, [rbx + 1]
0x14287fab7:  85d2                 test      edx, edx
0x14287fab9:  0f44d0               cmove     edx, eax
0x14287fabc:  8997280d0000         mov       dword ptr [rdi + 0xd28], edx
0x14287fac2:  e8493d2a03           call      0x145b23810
0x14287fac7:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x14287facc:  8bc3                 mov       eax, ebx
0x14287face:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14287fad3:  4883c420             add       rsp, 0x20
0x14287fad7:  5f                   pop       rdi
0x14287fad8:  c3                   ret       
0x14287fad9:  8bc8                 mov       ecx, eax
0x14287fadb:  e8a0422a03           call      0x145b23d80
0x14287fae0:  cc                   int3      
0x14287fae1:  cc                   int3      
0x14287fae2:  cc                   int3      
0x14287fae3:  cc                   int3      
0x14287fae4:  cc                   int3      
0x14287fae5:  cc                   int3      
0x14287fae6:  cc                   int3      
0x14287fae7:  cc                   int3      
0x14287fae8:  cc                   int3      
0x14287fae9:  cc                   int3      
0x14287faea:  cc                   int3      
0x14287faeb:  cc                   int3      
0x14287faec:  cc                   int3      
0x14287faed:  cc                   int3      
0x14287faee:  cc                   int3      
0x14287faef:  cc                   int3      
