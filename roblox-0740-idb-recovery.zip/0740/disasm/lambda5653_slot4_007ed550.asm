; lambda5653 vtable slot 4 rva 0x7ed550
0x1407ed550:  4883ec28             sub       rsp, 0x28
0x1407ed554:  84d2                 test      dl, dl
0x1407ed556:  7406                 je        0x1407ed55e
0x1407ed558:  e8535b1504           call      0x1449430b0
0x1407ed55d:  90                   nop       
0x1407ed55e:  4883c428             add       rsp, 0x28
0x1407ed562:  c3                   ret       
0x1407ed563:  cc                   int3      
0x1407ed564:  cc                   int3      
0x1407ed565:  cc                   int3      
0x1407ed566:  cc                   int3      
0x1407ed567:  cc                   int3      
0x1407ed568:  cc                   int3      
0x1407ed569:  cc                   int3      
0x1407ed56a:  cc                   int3      
0x1407ed56b:  cc                   int3      
0x1407ed56c:  cc                   int3      
0x1407ed56d:  cc                   int3      
0x1407ed56e:  cc                   int3      
0x1407ed56f:  cc                   int3      
0x1407ed570:  488d4108             lea       rax, [rcx + 8]
0x1407ed574:  c3                   ret       
0x1407ed575:  cc                   int3      
0x1407ed576:  cc                   int3      
0x1407ed577:  cc                   int3      
0x1407ed578:  cc                   int3      
0x1407ed579:  cc                   int3      
0x1407ed57a:  cc                   int3      
0x1407ed57b:  cc                   int3      
0x1407ed57c:  cc                   int3      
0x1407ed57d:  cc                   int3      
0x1407ed57e:  cc                   int3      
0x1407ed57f:  cc                   int3      
