; RakPeer vtable slot 6
; rva 0x287d2c0
0x14287d2c0:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x14287d2c5:  57                   push      rdi
0x14287d2c6:  4883ec20             sub       rsp, 0x20
0x14287d2ca:  83b98809000000       cmp       dword ptr [rcx + 0x988], 0
0x14287d2d1:  488bda               mov       rbx, rdx
0x14287d2d4:  488bf9               mov       rdi, rcx
0x14287d2d7:  750d                 jne       0x14287d2e6
0x14287d2d9:  32c0                 xor       al, al
0x14287d2db:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x14287d2e0:  4883c420             add       rsp, 0x20
0x14287d2e4:  5f                   pop       rdi
0x14287d2e5:  c3                   ret       
0x14287d2e6:  48896c2430           mov       qword ptr [rsp + 0x30], rbp
0x14287d2eb:  4881c188080000       add       rcx, 0x888
0x14287d2f2:  4889742438           mov       qword ptr [rsp + 0x38], rsi
0x14287d2f7:  33f6                 xor       esi, esi
0x14287d2f9:  e8b2642a03           call      0x145b237b0
0x14287d2fe:  85c0                 test      eax, eax
0x14287d300:  0f85ad000000         jne       0x14287d3b3
0x14287d306:  448b9788090000       mov       r10d, dword ptr [rdi + 0x988]
0x14287d30d:  4585d2               test      r10d, r10d
0x14287d310:  746e                 je        0x14287d380
0x14287d312:  4c8b9f80090000       mov       r11, qword ptr [rdi + 0x980]
0x14287d319:  0f1f8000000000       nop       dword ptr [rax]
0x14287d320:  4885db               test      rbx, rbx
0x14287d323:  7454                 je        0x14287d379
0x14287d325:  0fb603               movzx     eax, byte ptr [rbx]
0x14287d328:  84c0                 test      al, al
0x14287d32a:  744d                 je        0x14287d379
0x14287d32c:  48c7c1ffffffff       mov       rcx, 0xffffffffffffffff
0x14287d333:  48ffc1               inc       rcx
0x14287d336:  803c0b00             cmp       byte ptr [rbx + rcx], 0
0x14287d33a:  75f7                 jne       0x14287d333
0x14287d33c:  4883f90f             cmp       rcx, 0xf
0x14287d340:  7737                 ja        0x14287d379
0x14287d342:  498b14f3             mov       rdx, qword ptr [r11 + rsi*8]
0x14287d346:  4533c0               xor       r8d, r8d
0x14287d349:  4c8b4a20             mov       r9, qword ptr [rdx + 0x20]
0x14287d34d:  413801               cmp       byte ptr [r9], al
0x14287d350:  7512                 jne       0x14287d364
0x14287d352:  84c0                 test      al, al
0x14287d354:  744d                 je        0x14287d3a3
0x14287d356:  41ffc0               inc       r8d
0x14287d359:  410fb60418           movzx     eax, byte ptr [r8 + rbx]
0x14287d35e:  43380401             cmp       byte ptr [r9 + r8], al
0x14287d362:  74ee                 je        0x14287d352
0x14287d364:  430fb60c01           movzx     ecx, byte ptr [r9 + r8]
0x14287d369:  84c9                 test      cl, cl
0x14287d36b:  740c                 je        0x14287d379
0x14287d36d:  41803c1800           cmp       byte ptr [r8 + rbx], 0
0x14287d372:  7405                 je        0x14287d379
0x14287d374:  80f92a               cmp       cl, 0x2a
0x14287d377:  742a                 je        0x14287d3a3
0x14287d379:  ffc6                 inc       esi
0x14287d37b:  413bf2               cmp       esi, r10d
0x14287d37e:  72a0                 jb        0x14287d320
0x14287d380:  488d8f88080000       lea       rcx, [rdi + 0x888]
0x14287d387:  e884642a03           call      0x145b23810
0x14287d38c:  32c0                 xor       al, al
0x14287d38e:  488b6c2430           mov       rbp, qword ptr [rsp + 0x30]
0x14287d393:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x14287d398:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x14287d39d:  4883c420             add       rsp, 0x20
0x14287d3a1:  5f                   pop       rdi
0x14287d3a2:  c3                   ret       
0x14287d3a3:  488d8f88080000       lea       rcx, [rdi + 0x888]
0x14287d3aa:  e861642a03           call      0x145b23810
0x14287d3af:  b001                 mov       al, 1
0x14287d3b1:  ebdb                 jmp       0x14287d38e
0x14287d3b3:  8bc8                 mov       ecx, eax
0x14287d3b5:  e8c6692a03           call      0x145b23d80
0x14287d3ba:  cc                   int3      
0x14287d3bb:  cc                   int3      
0x14287d3bc:  cc                   int3      
0x14287d3bd:  cc                   int3      
0x14287d3be:  cc                   int3      
0x14287d3bf:  cc                   int3      
