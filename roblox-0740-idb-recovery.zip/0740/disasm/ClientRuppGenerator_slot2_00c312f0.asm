; ClientRuppGenerator vtable slot 2 rva 0xc312f0
0x140c312f0:  488d4160             lea       rax, [rcx + 0x60]
0x140c312f4:  c3                   ret       
0x140c312f5:  cc                   int3      
0x140c312f6:  cc                   int3      
0x140c312f7:  cc                   int3      
0x140c312f8:  cc                   int3      
0x140c312f9:  cc                   int3      
0x140c312fa:  cc                   int3      
0x140c312fb:  cc                   int3      
0x140c312fc:  cc                   int3      
0x140c312fd:  cc                   int3      
0x140c312fe:  cc                   int3      
0x140c312ff:  cc                   int3      
0x140c31300:  488d81c0000000       lea       rax, [rcx + 0xc0]
0x140c31307:  c3                   ret       
0x140c31308:  cc                   int3      
0x140c31309:  cc                   int3      
0x140c3130a:  cc                   int3      
0x140c3130b:  cc                   int3      
0x140c3130c:  cc                   int3      
0x140c3130d:  cc                   int3      
0x140c3130e:  cc                   int3      
0x140c3130f:  cc                   int3      
0x140c31310:  488d4140             lea       rax, [rcx + 0x40]
0x140c31314:  c3                   ret       
0x140c31315:  cc                   int3      
0x140c31316:  cc                   int3      
0x140c31317:  cc                   int3      
0x140c31318:  cc                   int3      
0x140c31319:  cc                   int3      
0x140c3131a:  cc                   int3      
0x140c3131b:  cc                   int3      
0x140c3131c:  cc                   int3      
0x140c3131d:  cc                   int3      
0x140c3131e:  cc                   int3      
0x140c3131f:  cc                   int3      
0x140c31320:  488d81a0000000       lea       rax, [rcx + 0xa0]
0x140c31327:  c3                   ret       
0x140c31328:  cc                   int3      
0x140c31329:  cc                   int3      
0x140c3132a:  cc                   int3      
0x140c3132b:  cc                   int3      
0x140c3132c:  cc                   int3      
0x140c3132d:  cc                   int3      
0x140c3132e:  cc                   int3      
0x140c3132f:  cc                   int3      
0x140c31330:  488d8100010000       lea       rax, [rcx + 0x100]
0x140c31337:  c3                   ret       
0x140c31338:  cc                   int3      
0x140c31339:  cc                   int3      
0x140c3133a:  cc                   int3      
0x140c3133b:  cc                   int3      
0x140c3133c:  cc                   int3      
0x140c3133d:  cc                   int3      
0x140c3133e:  cc                   int3      
0x140c3133f:  cc                   int3      
