; function_of: str.Offline reverse ruppLength
; xref site 0x14289f9c5 -> str.Offline reverse ruppLength @ 0x146f39fb0
; range 0x14289e210 .. 0x14289fc80  (6768 bytes)

0x00014289e210:  4053                  push      rbx
0x00014289e212:  4883ec20              sub       rsp, 0x20
0x00014289e216:  488bda                mov       rbx, rdx
0x00014289e219:  488bd1                mov       rdx, rcx
0x00014289e21c:  488b4308              mov       rax, qword ptr [rbx + 8]
0x00014289e220:  4885c0                test      rax, rax
0x00014289e223:  7404                  je        0x14289e229
0x00014289e225:  f0ff4008              lock inc  dword ptr [rax + 8]
0x00014289e229:  488b03                mov       rax, qword ptr [rbx]
0x00014289e22c:  4c8b4308              mov       r8, qword ptr [rbx + 8]
0x00014289e230:  488981d00d0000        mov       qword ptr [rcx + 0xdd0], rax
0x00014289e237:  488b89d80d0000        mov       rcx, qword ptr [rcx + 0xdd8]
0x00014289e23e:  4c8982d80d0000        mov       qword ptr [rdx + 0xdd8], r8
0x00014289e245:  4885c9                test      rcx, rcx
0x00014289e248:  7405                  je        0x14289e24f
0x00014289e24a:  e8c1acf2fd            call      0x1407c8f10
0x00014289e24f:  488b4b08              mov       rcx, qword ptr [rbx + 8]
0x00014289e253:  4885c9                test      rcx, rcx
0x00014289e256:  740a                  je        0x14289e262
0x00014289e258:  4883c420              add       rsp, 0x20
0x00014289e25c:  5b                    pop       rbx
0x00014289e25d:  e9aeacf2fd            jmp       0x1407c8f10
0x00014289e262:  4883c420              add       rsp, 0x20
0x00014289e266:  5b                    pop       rbx
0x00014289e267:  c3                    ret       
0x00014289e268:  cc                    int3      
0x00014289e269:  cc                    int3      
0x00014289e26a:  cc                    int3      
0x00014289e26b:  cc                    int3      
0x00014289e26c:  cc                    int3      
0x00014289e26d:  cc                    int3      
0x00014289e26e:  cc                    int3      
0x00014289e26f:  cc                    int3      
0x00014289e270:  4881c1780d0000        add       rcx, 0xd78
0x00014289e277:  483bca                cmp       rcx, rdx
0x00014289e27a:  7413                  je        0x14289e28f
0x00014289e27c:  48837a1810            cmp       qword ptr [rdx + 0x18], 0x10
0x00014289e281:  4c8b4210              mov       r8, qword ptr [rdx + 0x10]
0x00014289e285:  7203                  jb        0x14289e28a
0x00014289e287:  488b12                mov       rdx, qword ptr [rdx]
0x00014289e28a:  e9c157f4fd            jmp       0x1407e3a50
0x00014289e28f:  c3                    ret       
0x00014289e290:  4881c1300d0000        add       rcx, 0xd30
0x00014289e297:  483bca                cmp       rcx, rdx
0x00014289e29a:  7413                  je        0x14289e2af
0x00014289e29c:  48837a1810            cmp       qword ptr [rdx + 0x18], 0x10
0x00014289e2a1:  4c8b4210              mov       r8, qword ptr [rdx + 0x10]
0x00014289e2a5:  7203                  jb        0x14289e2aa
0x00014289e2a7:  488b12                mov       rdx, qword ptr [rdx]
0x00014289e2aa:  e9a157f4fd            jmp       0x1407e3a50
0x00014289e2af:  c3                    ret       
0x00014289e2b0:  48895c2418            mov       qword ptr [rsp + 0x18], rbx
0x00014289e2b5:  55                    push      rbp
0x00014289e2b6:  56                    push      rsi
0x00014289e2b7:  57                    push      rdi
0x00014289e2b8:  4154                  push      r12
0x00014289e2ba:  4155                  push      r13
0x00014289e2bc:  4156                  push      r14
0x00014289e2be:  4157                  push      r15
0x00014289e2c0:  488d6c24b0            lea       rbp, [rsp - 0x50]
0x00014289e2c5:  4881ec50010000        sub       rsp, 0x150
0x00014289e2cc:  488b051d544705        mov       rax, qword ptr [rip + 0x547541d]
0x00014289e2d3:  4833c4                xor       rax, rsp
0x00014289e2d6:  48894540              mov       qword ptr [rbp + 0x40], rax
0x00014289e2da:  488bfa                mov       rdi, rdx
0x00014289e2dd:  4c8bf1                mov       r14, rcx
0x00014289e2e0:  80b9a80d000000        cmp       byte ptr [rcx + 0xda8], 0
0x00014289e2e7:  750a                  jne       0x14289e2f3
0x00014289e2e9:  b801000000            mov       eax, 1
0x00014289e2ee:  e95b040000            jmp       0x14289e74e
0x00014289e2f3:  803d0ed6a20500        cmp       byte ptr [rip + 0x5a2d60e], 0
0x00014289e2fa:  7507                  jne       0x14289e303
0x00014289e2fc:  48837a0820            cmp       qword ptr [rdx + 8], 0x20
0x00014289e301:  7417                  je        0x14289e31a
0x00014289e303:  488b4208              mov       rax, qword ptr [rdx + 8]
0x00014289e307:  4883f821              cmp       rax, 0x21
0x00014289e30b:  740d                  je        0x14289e31a
0x00014289e30d:  4883f832              cmp       rax, 0x32
0x00014289e311:  7407                  je        0x14289e31a
0x00014289e313:  33c0                  xor       eax, eax
0x00014289e315:  e934040000            jmp       0x14289e74e
0x00014289e31a:  4533ff                xor       r15d, r15d
0x00014289e31d:  4c897db0              mov       qword ptr [rbp - 0x50], r15
0x00014289e321:  4c897dc0              mov       qword ptr [rbp - 0x40], r15
0x00014289e325:  48c745c80f000000      mov       qword ptr [rbp - 0x38], 0xf
0x00014289e32d:  44887db0              mov       byte ptr [rbp - 0x50], r15b
0x00014289e331:  488b12                mov       rdx, qword ptr [rdx]
0x00014289e334:  4c897dd0              mov       qword ptr [rbp - 0x30], r15
0x00014289e338:  4c897de0              mov       qword ptr [rbp - 0x20], r15
0x00014289e33c:  48c745e80f000000      mov       qword ptr [rbp - 0x18], 0xf
0x00014289e344:  44887dd0              mov       byte ptr [rbp - 0x30], r15b
0x00014289e348:  4885d2                test      rdx, rdx
0x00014289e34b:  740e                  je        0x14289e35b
0x00014289e34d:  458d4710              lea       r8d, [r15 + 0x10]
0x00014289e351:  488d4dd0              lea       rcx, [rbp - 0x30]
0x00014289e355:  e8f656f4fd            call      0x1407e3a50
0x00014289e35a:  90                    nop       
0x00014289e35b:  498d96300d0000        lea       rdx, [r14 + 0xd30]
0x00014289e362:  4983be480d000010      cmp       qword ptr [r14 + 0xd48], 0x10
0x00014289e36a:  7207                  jb        0x14289e373
0x00014289e36c:  498b96300d0000        mov       rdx, qword ptr [r14 + 0xd30]
0x00014289e373:  4d8b86400d0000        mov       r8, qword ptr [r14 + 0xd40]
0x00014289e37a:  488d4dd0              lea       rcx, [rbp - 0x30]
0x00014289e37e:  e8fd57f4fd            call      0x1407e3b80
0x00014289e383:  4c897d90              mov       qword ptr [rbp - 0x70], r15
0x00014289e387:  4c897da0              mov       qword ptr [rbp - 0x60], r15
0x00014289e38b:  4c897da8              mov       qword ptr [rbp - 0x58], r15
0x00014289e38f:  0f1000                movups    xmm0, xmmword ptr [rax]
0x00014289e392:  0f114590              movups    xmmword ptr [rbp - 0x70], xmm0
0x00014289e396:  0f104810              movups    xmm1, xmmword ptr [rax + 0x10]
0x00014289e39a:  0f114da0              movups    xmmword ptr [rbp - 0x60], xmm1
0x00014289e39e:  4c897810              mov       qword ptr [rax + 0x10], r15
0x00014289e3a2:  48c740180f000000      mov       qword ptr [rax + 0x18], 0xf
0x00014289e3aa:  c60000                mov       byte ptr [rax], 0
0x00014289e3ad:  488b45e8              mov       rax, qword ptr [rbp - 0x18]
0x00014289e3b1:  4883f810              cmp       rax, 0x10
0x00014289e3b5:  722d                  jb        0x14289e3e4
0x00014289e3b7:  48ffc0                inc       rax
0x00014289e3ba:  488b4dd0              mov       rcx, qword ptr [rbp - 0x30]
0x00014289e3be:  488bd1                mov       rdx, rcx
0x00014289e3c1:  483d00100000          cmp       rax, 0x1000
0x00014289e3c7:  7215                  jb        0x14289e3de
0x00014289e3c9:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289e3cd:  482bd1                sub       rdx, rcx
0x00014289e3d0:  488d42f8              lea       rax, [rdx - 8]
0x00014289e3d4:  4883f81f              cmp       rax, 0x1f
0x00014289e3d8:  0f879d030000          ja        0x14289e77b
0x00014289e3de:  e8cd4c0a02            call      0x1449430b0
0x00014289e3e3:  90                    nop       
0x00014289e3e4:  4c897de0              mov       qword ptr [rbp - 0x20], r15
0x00014289e3e8:  48c745e80f000000      mov       qword ptr [rbp - 0x18], 0xf
0x00014289e3f0:  c645d000              mov       byte ptr [rbp - 0x30], 0
0x00014289e3f4:  c644244001            mov       byte ptr [rsp + 0x40], 1
0x00014289e3f9:  803dd8eec80500        cmp       byte ptr [rip + 0x5c8eed8], 0
0x00014289e400:  7476                  je        0x14289e478
0x00014289e402:  488d4590              lea       rax, [rbp - 0x70]
0x00014289e406:  48837da810            cmp       qword ptr [rbp - 0x58], 0x10
0x00014289e40b:  480f434590            cmovae    rax, qword ptr [rbp - 0x70]
0x00014289e410:  4889442450            mov       qword ptr [rsp + 0x50], rax
0x00014289e415:  488b45a0              mov       rax, qword ptr [rbp - 0x60]
0x00014289e419:  4889442458            mov       qword ptr [rsp + 0x58], rax
0x00014289e41e:  0f2807                movaps    xmm0, xmmword ptr [rdi]
0x00014289e421:  660f7f4580            movdqa    xmmword ptr [rbp - 0x80], xmm0
0x00014289e426:  0f284c2450            movaps    xmm1, xmmword ptr [rsp + 0x50]
0x00014289e42b:  660f7f4c2460          movdqa    xmmword ptr [rsp + 0x60], xmm1
0x00014289e431:  4d8d8e300d0000        lea       r9, [r14 + 0xd30]
0x00014289e438:  4c8d4580              lea       r8, [rbp - 0x80]
0x00014289e43c:  488d542460            lea       rdx, [rsp + 0x60]
0x00014289e441:  488d4df0              lea       rcx, [rbp - 0x10]
0x00014289e445:  e8c6f20300            call      0x1428dd710
0x00014289e44a:  488d4c2440            lea       rcx, [rsp + 0x40]
0x00014289e44f:  48894c2470            mov       qword ptr [rsp + 0x70], rcx
0x00014289e454:  488d4db0              lea       rcx, [rbp - 0x50]
0x00014289e458:  48894c2478            mov       qword ptr [rsp + 0x78], rcx
0x00014289e45d:  488bd0                mov       rdx, rax
0x00014289e460:  488d4c2470            lea       rcx, [rsp + 0x70]
0x00014289e465:  e8e6510000            call      0x1428a3650
0x00014289e46a:  488d4df0              lea       rcx, [rbp - 0x10]
0x00014289e46e:  e86d75f4fd            call      0x1407e59e0
0x00014289e473:  e9ca000000            jmp       0x14289e542
0x00014289e478:  4c897df0              mov       qword ptr [rbp - 0x10], r15
0x00014289e47c:  48c745080f000000      mov       qword ptr [rbp + 8], 0xf
0x00014289e484:  4c897d00              mov       qword ptr [rbp], r15
0x00014289e488:  c645f000              mov       byte ptr [rbp - 0x10], 0
0x00014289e48c:  488d4590              lea       rax, [rbp - 0x70]
0x00014289e490:  48837da810            cmp       qword ptr [rbp - 0x58], 0x10
0x00014289e495:  480f434590            cmovae    rax, qword ptr [rbp - 0x70]
0x00014289e49a:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x00014289e49f:  488b45a0              mov       rax, qword ptr [rbp - 0x60]
0x00014289e4a3:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x00014289e4a8:  0f2807                movaps    xmm0, xmmword ptr [rdi]
0x00014289e4ab:  660f7f442460          movdqa    xmmword ptr [rsp + 0x60], xmm0
0x00014289e4b1:  0f284c2470            movaps    xmm1, xmmword ptr [rsp + 0x70]
0x00014289e4b6:  660f7f4d80            movdqa    xmmword ptr [rbp - 0x80], xmm1
0x00014289e4bb:  4c8d4df0              lea       r9, [rbp - 0x10]
0x00014289e4bf:  4c8d442460            lea       r8, [rsp + 0x60]
0x00014289e4c4:  488d5580              lea       rdx, [rbp - 0x80]
0x00014289e4c8:  488d4d18              lea       rcx, [rbp + 0x18]
0x00014289e4cc:  e83ff20300            call      0x1428dd710
0x00014289e4d1:  488d4c2440            lea       rcx, [rsp + 0x40]
0x00014289e4d6:  48894c2450            mov       qword ptr [rsp + 0x50], rcx
0x00014289e4db:  488d4db0              lea       rcx, [rbp - 0x50]
0x00014289e4df:  48894c2458            mov       qword ptr [rsp + 0x58], rcx
0x00014289e4e4:  488bd0                mov       rdx, rax
0x00014289e4e7:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289e4ec:  e85f510000            call      0x1428a3650
0x00014289e4f1:  488d4d18              lea       rcx, [rbp + 0x18]
0x00014289e4f5:  e8e674f4fd            call      0x1407e59e0
0x00014289e4fa:  90                    nop       
0x00014289e4fb:  488b4508              mov       rax, qword ptr [rbp + 8]
0x00014289e4ff:  4883f810              cmp       rax, 0x10
0x00014289e503:  722d                  jb        0x14289e532
0x00014289e505:  48ffc0                inc       rax
0x00014289e508:  488b4df0              mov       rcx, qword ptr [rbp - 0x10]
0x00014289e50c:  488bd1                mov       rdx, rcx
0x00014289e50f:  483d00100000          cmp       rax, 0x1000
0x00014289e515:  7215                  jb        0x14289e52c
0x00014289e517:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289e51b:  482bd1                sub       rdx, rcx
0x00014289e51e:  488d42f8              lea       rax, [rdx - 8]
0x00014289e522:  4883f81f              cmp       rax, 0x1f
0x00014289e526:  0f8755020000          ja        0x14289e781
0x00014289e52c:  e87f4b0a02            call      0x1449430b0
0x00014289e531:  90                    nop       
0x00014289e532:  4c897d00              mov       qword ptr [rbp], r15
0x00014289e536:  48c745080f000000      mov       qword ptr [rbp + 8], 0xf
0x00014289e53e:  c645f000              mov       byte ptr [rbp - 0x10], 0
0x00014289e542:  488b75c0              mov       rsi, qword ptr [rbp - 0x40]
0x00014289e546:  4885f6                test      rsi, rsi
0x00014289e549:  7566                  jne       0x14289e5b1
0x00014289e54b:  488b05bec54c05        mov       rax, qword ptr [rip + 0x54cc5be]
0x00014289e552:  3c06                  cmp       al, 6
0x00014289e554:  724b                  jb        0x14289e5a1
0x00014289e556:  48c1e808              shr       rax, 8
0x00014289e55a:  3c03                  cmp       al, 3
0x00014289e55c:  7243                  jb        0x14289e5a1
0x00014289e55e:  488d0503050907        lea       rax, [rip + 0x7090503]
0x00014289e565:  4889442450            mov       qword ptr [rsp + 0x50], rax
0x00014289e56a:  488b542450            mov       rdx, qword ptr [rsp + 0x50]
0x00014289e56f:  488d150ab96904        lea       rdx, [rip + 0x469b90a]
0x00014289e576:  0f100593c54c05        movups    xmm0, xmmword ptr [rip + 0x54cc593]
0x00014289e57d:  0f29442460            movaps    xmmword ptr [rsp + 0x60], xmm0
0x00014289e582:  4c897c2430            mov       qword ptr [rsp + 0x30], r15
0x00014289e587:  4c897c2428            mov       qword ptr [rsp + 0x28], r15
0x00014289e58c:  4c897c2420            mov       qword ptr [rsp + 0x20], r15
0x00014289e591:  4533c9                xor       r9d, r9d
0x00014289e594:  4533c0                xor       r8d, r8d
0x00014289e597:  488d4c2460            lea       rcx, [rsp + 0x60]
0x00014289e59c:  e87f180c02            call      0x14495fe20
0x00014289e5a1:  418bdf                mov       ebx, r15d
0x00014289e5a4:  4c8b6dc8              mov       r13, qword ptr [rbp - 0x38]
0x00014289e5a8:  4c8b75b0              mov       r14, qword ptr [rbp - 0x50]
0x00014289e5ac:  e919010000            jmp       0x14289e6ca
0x00014289e5b1:  4d8da6980d0000        lea       r12, [r14 + 0xd98]
0x00014289e5b8:  498b3c24              mov       rdi, qword ptr [r12]
0x00014289e5bc:  488b5f08              mov       rbx, qword ptr [rdi + 8]
0x00014289e5c0:  4c8bff                mov       r15, rdi
0x00014289e5c3:  4c8b6dc8              mov       r13, qword ptr [rbp - 0x38]
0x00014289e5c7:  4c8b75b0              mov       r14, qword ptr [rbp - 0x50]
0x00014289e5cb:  807b1900              cmp       byte ptr [rbx + 0x19], 0
0x00014289e5cf:  7571                  jne       0x14289e642
0x00014289e5d1:  0f1f4000              nop       dword ptr [rax]
0x00014289e5d5:  6666660f1f840000000000  nop       word ptr [rax + rax]
0x00014289e5e0:  488d4b20              lea       rcx, [rbx + 0x20]
0x00014289e5e4:  488d55b0              lea       rdx, [rbp - 0x50]
0x00014289e5e8:  4983fd10              cmp       r13, 0x10
0x00014289e5ec:  490f43d6              cmovae    rdx, r14
0x00014289e5f0:  488b7910              mov       rdi, qword ptr [rcx + 0x10]
0x00014289e5f4:  4883791810            cmp       qword ptr [rcx + 0x18], 0x10
0x00014289e5f9:  7203                  jb        0x14289e5fe
0x00014289e5fb:  488b09                mov       rcx, qword ptr [rcx]
0x00014289e5fe:  4c8bc7                mov       r8, rdi
0x00014289e601:  483bf7                cmp       rsi, rdi
0x00014289e604:  4c0f42c6              cmovb     r8, rsi
0x00014289e608:  e823522a03            call      0x145b43830
0x00014289e60d:  85c0                  test      eax, eax
0x00014289e60f:  7514                  jne       0x14289e625
0x00014289e611:  483bfe                cmp       rdi, rsi
0x00014289e614:  7307                  jae       0x14289e61d
0x00014289e616:  b8ffffffff            mov       eax, 0xffffffff
0x00014289e61b:  eb08                  jmp       0x14289e625
0x00014289e61d:  33c0                  xor       eax, eax
0x00014289e61f:  483bfe                cmp       rdi, rsi
0x00014289e622:  0f97c0                seta      al
0x00014289e625:  c1e81f                shr       eax, 0x1f
0x00014289e628:  84c0                  test      al, al
0x00014289e62a:  7406                  je        0x14289e632
0x00014289e62c:  488b5b10              mov       rbx, qword ptr [rbx + 0x10]
0x00014289e630:  eb06                  jmp       0x14289e638
0x00014289e632:  4c8bfb                mov       r15, rbx
0x00014289e635:  488b1b                mov       rbx, qword ptr [rbx]
0x00014289e638:  807b1900              cmp       byte ptr [rbx + 0x19], 0
0x00014289e63c:  74a2                  je        0x14289e5e0
0x00014289e63e:  498b3c24              mov       rdi, qword ptr [r12]
0x00014289e642:  41807f1900            cmp       byte ptr [r15 + 0x19], 0
0x00014289e647:  754c                  jne       0x14289e695
0x00014289e649:  498d5720              lea       rdx, [r15 + 0x20]
0x00014289e64d:  488b5a10              mov       rbx, qword ptr [rdx + 0x10]
0x00014289e651:  48837a1810            cmp       qword ptr [rdx + 0x18], 0x10
0x00014289e656:  7203                  jb        0x14289e65b
0x00014289e658:  488b12                mov       rdx, qword ptr [rdx]
0x00014289e65b:  488d4db0              lea       rcx, [rbp - 0x50]
0x00014289e65f:  4983fd10              cmp       r13, 0x10
0x00014289e663:  490f43ce              cmovae    rcx, r14
0x00014289e667:  4c8bc6                mov       r8, rsi
0x00014289e66a:  483bde                cmp       rbx, rsi
0x00014289e66d:  4c0f42c3              cmovb     r8, rbx
0x00014289e671:  e8ba512a03            call      0x145b43830
0x00014289e676:  85c0                  test      eax, eax
0x00014289e678:  7514                  jne       0x14289e68e
0x00014289e67a:  483bf3                cmp       rsi, rbx
0x00014289e67d:  7307                  jae       0x14289e686
0x00014289e67f:  b8ffffffff            mov       eax, 0xffffffff
0x00014289e684:  eb08                  jmp       0x14289e68e
0x00014289e686:  33c0                  xor       eax, eax
0x00014289e688:  483bf3                cmp       rsi, rbx
0x00014289e68b:  0f97c0                seta      al
0x00014289e68e:  c1e81f                shr       eax, 0x1f
0x00014289e691:  84c0                  test      al, al
0x00014289e693:  7403                  je        0x14289e698
0x00014289e695:  4c8bff                mov       r15, rdi
0x00014289e698:  4d3b3c24              cmp       r15, qword ptr [r12]
0x00014289e69c:  7527                  jne       0x14289e6c5
0x00014289e69e:  4c8d45b0              lea       r8, [rbp - 0x50]
0x00014289e6a2:  488d542460            lea       rdx, [rsp + 0x60]
0x00014289e6a7:  498bcc                mov       rcx, r12
0x00014289e6aa:  e841c00dff            call      0x14197a6f0
0x00014289e6af:  0fb6442440            movzx     eax, byte ptr [rsp + 0x40]
0x00014289e6b4:  f6d8                  neg       al
0x00014289e6b6:  1bdb                  sbb       ebx, ebx
0x00014289e6b8:  83c302                add       ebx, 2
0x00014289e6bb:  4c8b6dc8              mov       r13, qword ptr [rbp - 0x38]
0x00014289e6bf:  4c8b75b0              mov       r14, qword ptr [rbp - 0x50]
0x00014289e6c3:  eb05                  jmp       0x14289e6ca
0x00014289e6c5:  bb03000000            mov       ebx, 3
0x00014289e6ca:  488b45a8              mov       rax, qword ptr [rbp - 0x58]
0x00014289e6ce:  4883f810              cmp       rax, 0x10
0x00014289e6d2:  7235                  jb        0x14289e709
0x00014289e6d4:  48ffc0                inc       rax
0x00014289e6d7:  488b4d90              mov       rcx, qword ptr [rbp - 0x70]
0x00014289e6db:  488bd1                mov       rdx, rcx
0x00014289e6de:  483d00100000          cmp       rax, 0x1000
0x00014289e6e4:  7215                  jb        0x14289e6fb
0x00014289e6e6:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289e6ea:  482bd1                sub       rdx, rcx
0x00014289e6ed:  488d42f8              lea       rax, [rdx - 8]
0x00014289e6f1:  4883f81f              cmp       rax, 0x1f
0x00014289e6f5:  0f878c000000          ja        0x14289e787
0x00014289e6fb:  e8b0490a02            call      0x1449430b0
0x00014289e700:  90                    nop       
0x00014289e701:  4c8b6dc8              mov       r13, qword ptr [rbp - 0x38]
0x00014289e705:  4c8b75b0              mov       r14, qword ptr [rbp - 0x50]
0x00014289e709:  48c745a000000000      mov       qword ptr [rbp - 0x60], 0
0x00014289e711:  48c745a80f000000      mov       qword ptr [rbp - 0x58], 0xf
0x00014289e719:  c6459000              mov       byte ptr [rbp - 0x70], 0
0x00014289e71d:  4983fd10              cmp       r13, 0x10
0x00014289e721:  7229                  jb        0x14289e74c
0x00014289e723:  498d4501              lea       rax, [r13 + 1]
0x00014289e727:  498bce                mov       rcx, r14
0x00014289e72a:  483d00100000          cmp       rax, 0x1000
0x00014289e730:  7211                  jb        0x14289e743
0x00014289e732:  4d8b76f8              mov       r14, qword ptr [r14 - 8]
0x00014289e736:  492bce                sub       rcx, r14
0x00014289e739:  488d41f8              lea       rax, [rcx - 8]
0x00014289e73d:  4883f81f              cmp       rax, 0x1f
0x00014289e741:  7732                  ja        0x14289e775
0x00014289e743:  498bce                mov       rcx, r14
0x00014289e746:  e865490a02            call      0x1449430b0
0x00014289e74b:  90                    nop       
0x00014289e74c:  8bc3                  mov       eax, ebx
0x00014289e74e:  488b4d40              mov       rcx, qword ptr [rbp + 0x40]
0x00014289e752:  4833cc                xor       rcx, rsp
0x00014289e755:  e8862e2803            call      0x145b215e0
0x00014289e75a:  488b9c24a0010000      mov       rbx, qword ptr [rsp + 0x1a0]
0x00014289e762:  4881c450010000        add       rsp, 0x150
0x00014289e769:  415f                  pop       r15
0x00014289e76b:  415e                  pop       r14
0x00014289e76d:  415d                  pop       r13
0x00014289e76f:  415c                  pop       r12
0x00014289e771:  5f                    pop       rdi
0x00014289e772:  5e                    pop       rsi
0x00014289e773:  5d                    pop       rbp
0x00014289e774:  c3                    ret       
0x00014289e775:  e8a62d2b03            call      0x145b51520
0x00014289e77a:  90                    nop       
0x00014289e77b:  e8a02d2b03            call      0x145b51520
0x00014289e780:  90                    nop       
0x00014289e781:  e89a2d2b03            call      0x145b51520
0x00014289e786:  90                    nop       
0x00014289e787:  e8942d2b03            call      0x145b51520
0x00014289e78c:  cc                    int3      
0x00014289e78d:  cc                    int3      
0x00014289e78e:  cc                    int3      
0x00014289e78f:  cc                    int3      
0x00014289e790:  448b91640f0000        mov       r10d, dword ptr [rcx + 0xf64]
0x00014289e797:  4c8bda                mov       r11, rdx
0x00014289e79a:  4585d2                test      r10d, r10d
0x00014289e79d:  7416                  je        0x14289e7b5
0x00014289e79f:  8b81600f0000          mov       eax, dword ptr [rcx + 0xf60]
0x00014289e7a5:  99                    cdq       
0x00014289e7a6:  41f7fa                idiv      r10d
0x00014289e7a9:  660f6ec0              movd      xmm0, eax
0x00014289e7ad:  0f5bc0                cvtdq2ps  xmm0, xmm0
0x00014289e7b0:  f3410f1103            movss     dword ptr [r11], xmm0
0x00014289e7b5:  8b81680f0000          mov       eax, dword ptr [rcx + 0xf68]
0x00014289e7bb:  418900                mov       dword ptr [r8], eax
0x00014289e7be:  8b816c0f0000          mov       eax, dword ptr [rcx + 0xf6c]
0x00014289e7c4:  418901                mov       dword ptr [r9], eax
0x00014289e7c7:  33c0                  xor       eax, eax
0x00014289e7c9:  488981600f0000        mov       qword ptr [rcx + 0xf60], rax
0x00014289e7d0:  c781680f0000ffffff7f  mov       dword ptr [rcx + 0xf68], 0x7fffffff
0x00014289e7da:  c7816c0f000000000080  mov       dword ptr [rcx + 0xf6c], 0x80000000
0x00014289e7e4:  c3                    ret       
0x00014289e7e5:  cc                    int3      
0x00014289e7e6:  cc                    int3      
0x00014289e7e7:  cc                    int3      
0x00014289e7e8:  cc                    int3      
0x00014289e7e9:  cc                    int3      
0x00014289e7ea:  cc                    int3      
0x00014289e7eb:  cc                    int3      
0x00014289e7ec:  cc                    int3      
0x00014289e7ed:  cc                    int3      
0x00014289e7ee:  cc                    int3      
0x00014289e7ef:  cc                    int3      
0x00014289e7f0:  48895c2418            mov       qword ptr [rsp + 0x18], rbx
0x00014289e7f5:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x00014289e7fa:  55                    push      rbp
0x00014289e7fb:  57                    push      rdi
0x00014289e7fc:  4154                  push      r12
0x00014289e7fe:  4156                  push      r14
0x00014289e800:  4157                  push      r15
0x00014289e802:  488dac24f0fdffff      lea       rbp, [rsp - 0x210]
0x00014289e80a:  4881ec10030000        sub       rsp, 0x310
0x00014289e811:  488b05d84e4705        mov       rax, qword ptr [rip + 0x5474ed8]
0x00014289e818:  4833c4                xor       rax, rsp
0x00014289e81b:  48898508020000        mov       qword ptr [rbp + 0x208], rax
0x00014289e822:  488bf2                mov       rsi, rdx
0x00014289e825:  4c8bf9                mov       r15, rcx
0x00014289e828:  4533e4                xor       r12d, r12d
0x00014289e82b:  4489642430            mov       dword ptr [rsp + 0x30], r12d
0x00014289e830:  8b1d6290a205          mov       ebx, dword ptr [rip + 0x5a29062]
0x00014289e836:  448b0563145405        mov       r8d, dword ptr [rip + 0x5541463]
0x00014289e83d:  4183f8ff              cmp       r8d, -1
0x00014289e841:  7523                  jne       0x14289e866
0x00014289e843:  e8a82e0c02            call      0x1449616f0
0x00014289e848:  448bc0                mov       r8d, eax
0x00014289e84b:  b85917b7d1            mov       eax, 0xd1b71759
0x00014289e850:  41f7e0                mul       r8d
0x00014289e853:  c1ea0d                shr       edx, 0xd
0x00014289e856:  69ca10270000          imul      ecx, edx, 0x2710
0x00014289e85c:  442bc1                sub       r8d, ecx
0x00014289e85f:  4489053a145405        mov       dword ptr [rip + 0x554143a], r8d
0x00014289e866:  443bc3                cmp       r8d, ebx
0x00014289e869:  0f8dae040000          jge       0x14289ed1d
0x00014289e86f:  834da001              or        dword ptr [rbp - 0x60], 1
0x00014289e873:  488d4da0              lea       rcx, [rbp - 0x60]
0x00014289e877:  e8041b1e00            call      0x142a80380
0x00014289e87c:  90                    nop       
0x00014289e87d:  4c89a5a8010000        mov       qword ptr [rbp + 0x1a8], r12
0x00014289e884:  660f6f05b46b9304      movdqa    xmm0, xmmword ptr [rip + 0x4936bb4]
0x00014289e88c:  f30f7f85b8010000      movdqu    xmmword ptr [rbp + 0x1b8], xmm0
0x00014289e894:  c685a801000000        mov       byte ptr [rbp + 0x1a8], 0
0x00014289e89b:  4489a5c8010000        mov       dword ptr [rbp + 0x1c8], r12d
0x00014289e8a2:  c685cc01000001        mov       byte ptr [rbp + 0x1cc], 1
0x00014289e8a9:  4c89a5d0010000        mov       qword ptr [rbp + 0x1d0], r12
0x00014289e8b0:  f30f7f85e0010000      movdqu    xmmword ptr [rbp + 0x1e0], xmm0
0x00014289e8b8:  c685d001000000        mov       byte ptr [rbp + 0x1d0], 0
0x00014289e8bf:  4489a5f4010000        mov       dword ptr [rbp + 0x1f4], r12d
0x00014289e8c6:  488b0daba3d005        mov       rcx, qword ptr [rip + 0x5d0a3ab]
0x00014289e8cd:  4885c9                test      rcx, rcx
0x00014289e8d0:  741b                  je        0x14289e8ed
0x00014289e8d2:  488b01                mov       rax, qword ptr [rcx]
0x00014289e8d5:  488d95f8010000        lea       rdx, [rbp + 0x1f8]
0x00014289e8dc:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x00014289e8e0:  ff1552148a03          call      qword ptr [rip + 0x38a1452]
0x00014289e8e6:  bf18000000            mov       edi, 0x18
0x00014289e8eb:  eb10                  jmp       0x14289e8fd
0x00014289e8ed:  0f57c0                xorps     xmm0, xmm0
0x00014289e8f0:  f30f7f85f8010000      movdqu    xmmword ptr [rbp + 0x1f8], xmm0
0x00014289e8f8:  bf08000000            mov       edi, 8
0x00014289e8fd:  83cf04                or        edi, 4
0x00014289e900:  897c2430              mov       dword ptr [rsp + 0x30], edi
0x00014289e904:  488b8e780d0000        mov       rcx, qword ptr [rsi + 0xd78]
0x00014289e90b:  488b01                mov       rax, qword ptr [rcx]
0x00014289e90e:  488b80c0000000        mov       rax, qword ptr [rax + 0xc0]
0x00014289e915:  ff151d148a03          call      qword ptr [rip + 0x38a141d]
0x00014289e91b:  4863d8                movsxd    rbx, eax
0x00014289e91e:  4533c0                xor       r8d, r8d
0x00014289e921:  4c8d3588b56904        lea       r14, [rip + 0x469b588]
0x00014289e928:  498bd6                mov       rdx, r14
0x00014289e92b:  488d4da0              lea       rcx, [rbp - 0x60]
0x00014289e92f:  e8bc0e1e00            call      0x142a7f7f0
0x00014289e934:  4885c0                test      rax, rax
0x00014289e937:  744a                  je        0x14289e983
0x00014289e939:  8bd3                  mov       edx, ebx
0x00014289e93b:  488bc8                mov       rcx, rax
0x00014289e93e:  e89dc31d00            call      0x142a7ace0
0x00014289e943:  488b8df8010000        mov       rcx, qword ptr [rbp + 0x1f8]
0x00014289e94a:  4885c9                test      rcx, rcx
0x00014289e94d:  7434                  je        0x14289e983
0x00014289e94f:  488b01                mov       rax, qword ptr [rcx]
0x00014289e952:  4c89742450            mov       qword ptr [rsp + 0x50], r14
0x00014289e957:  48c744245803000000    mov       qword ptr [rsp + 0x58], 3
0x00014289e960:  0f28442450            movaps    xmm0, xmmword ptr [rsp + 0x50]
0x00014289e965:  660f7f442440          movdqa    xmmword ptr [rsp + 0x40], xmm0
0x00014289e96b:  4c8bc3                mov       r8, rbx
0x00014289e96e:  41b901000000          mov       r9d, 1
0x00014289e974:  488d542440            lea       rdx, [rsp + 0x40]
0x00014289e979:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289e97d:  ff15b5138a03          call      qword ptr [rip + 0x38a13b5]
0x00014289e983:  f20f109618120000      movsd     xmm2, qword ptr [rsi + 0x1218]
0x00014289e98b:  488d15c6b46904        lea       rdx, [rip + 0x469b4c6]
0x00014289e992:  488d4da0              lea       rcx, [rbp - 0x60]
0x00014289e996:  e8e5061e00            call      0x142a7f080
0x00014289e99b:  4983bf1010000000      cmp       qword ptr [r15 + 0x1010], 0
0x00014289e9a3:  7526                  jne       0x14289e9cb
0x00014289e9a5:  4c896580              mov       qword ptr [rbp - 0x80], r12
0x00014289e9a9:  48c745980f000000      mov       qword ptr [rbp - 0x68], 0xf
0x00014289e9b1:  48c7459001000000      mov       qword ptr [rbp - 0x70], 1
0x00014289e9b9:  66c745802e00          mov       word ptr [rbp - 0x80], 0x2e
0x00014289e9bf:  488d5d80              lea       rbx, [rbp - 0x80]
0x00014289e9c3:  83cf01                or        edi, 1
0x00014289e9c6:  e984000000            jmp       0x14289ea4f
0x00014289e9cb:  4c89642460            mov       qword ptr [rsp + 0x60], r12
0x00014289e9d0:  4c89642470            mov       qword ptr [rsp + 0x70], r12
0x00014289e9d5:  4c89642478            mov       qword ptr [rsp + 0x78], r12
0x00014289e9da:  498db700100000        lea       rsi, [r15 + 0x1000]
0x00014289e9e1:  4c8b7610              mov       r14, qword ptr [rsi + 0x10]
0x00014289e9e5:  48837e1810            cmp       qword ptr [rsi + 0x18], 0x10
0x00014289e9ea:  7203                  jb        0x14289e9ef
0x00014289e9ec:  488b36                mov       rsi, qword ptr [rsi]
0x00014289e9ef:  4983fe10              cmp       r14, 0x10
0x00014289e9f3:  7313                  jae       0x14289ea08
0x00014289e9f5:  0f1006                movups    xmm0, xmmword ptr [rsi]
0x00014289e9f8:  0f11442460            movups    xmmword ptr [rsp + 0x60], xmm0
0x00014289e9fd:  48c74424780f000000    mov       qword ptr [rsp + 0x78], 0xf
0x00014289ea06:  eb3a                  jmp       0x14289ea42
0x00014289ea08:  498bde                mov       rbx, r14
0x00014289ea0b:  4883cb0f              or        rbx, 0xf
0x00014289ea0f:  48b8ffffffffffffff7f  movabs    rax, 0x7fffffffffffffff
0x00014289ea19:  483bd8                cmp       rbx, rax
0x00014289ea1c:  480f47d8              cmova     rbx, rax
0x00014289ea20:  488d4b01              lea       rcx, [rbx + 1]
0x00014289ea24:  e8a7b6f4fd            call      0x1407ea0d0
0x00014289ea29:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x00014289ea2e:  4d8d4601              lea       r8, [r14 + 1]
0x00014289ea32:  488bd6                mov       rdx, rsi
0x00014289ea35:  488bc8                mov       rcx, rax
0x00014289ea38:  e863472a03            call      0x145b431a0
0x00014289ea3d:  48895c2478            mov       qword ptr [rsp + 0x78], rbx
0x00014289ea42:  4c89742470            mov       qword ptr [rsp + 0x70], r14
0x00014289ea47:  488d5c2460            lea       rbx, [rsp + 0x60]
0x00014289ea4c:  83cf02                or        edi, 2
0x00014289ea4f:  897c2430              mov       dword ptr [rsp + 0x30], edi
0x00014289ea53:  4533c0                xor       r8d, r8d
0x00014289ea56:  488d3513b46904        lea       rsi, [rip + 0x469b413]
0x00014289ea5d:  488bd6                mov       rdx, rsi
0x00014289ea60:  488d4da0              lea       rcx, [rbp - 0x60]
0x00014289ea64:  e8870d1e00            call      0x142a7f7f0
0x00014289ea69:  4885c0                test      rax, rax
0x00014289ea6c:  0f848b000000          je        0x14289eafd
0x00014289ea72:  4c8b4310              mov       r8, qword ptr [rbx + 0x10]
0x00014289ea76:  b900f00000            mov       ecx, 0xf000
0x00014289ea7b:  4c3bc1                cmp       r8, rcx
0x00014289ea7e:  4c0f43c1              cmovae    r8, rcx
0x00014289ea82:  488bd3                mov       rdx, rbx
0x00014289ea85:  48837b1810            cmp       qword ptr [rbx + 0x18], 0x10
0x00014289ea8a:  7203                  jb        0x14289ea8f
0x00014289ea8c:  488b13                mov       rdx, qword ptr [rbx]
0x00014289ea8f:  488bc8                mov       rcx, rax
0x00014289ea92:  e809bf1d00            call      0x142a7a9a0
0x00014289ea97:  488b8df8010000        mov       rcx, qword ptr [rbp + 0x1f8]
0x00014289ea9e:  4885c9                test      rcx, rcx
0x00014289eaa1:  745a                  je        0x14289eafd
0x00014289eaa3:  488b01                mov       rax, qword ptr [rcx]
0x00014289eaa6:  488b5310              mov       rdx, qword ptr [rbx + 0x10]
0x00014289eaaa:  48837b1810            cmp       qword ptr [rbx + 0x18], 0x10
0x00014289eaaf:  7203                  jb        0x14289eab4
0x00014289eab1:  488b1b                mov       rbx, qword ptr [rbx]
0x00014289eab4:  48895c2450            mov       qword ptr [rsp + 0x50], rbx
0x00014289eab9:  4889542458            mov       qword ptr [rsp + 0x58], rdx
0x00014289eabe:  4889742440            mov       qword ptr [rsp + 0x40], rsi
0x00014289eac3:  48c74424480f000000    mov       qword ptr [rsp + 0x48], 0xf
0x00014289eacc:  0f28442450            movaps    xmm0, xmmword ptr [rsp + 0x50]
0x00014289ead1:  660f7f442450          movdqa    xmmword ptr [rsp + 0x50], xmm0
0x00014289ead7:  0f284c2440            movaps    xmm1, xmmword ptr [rsp + 0x40]
0x00014289eadc:  660f7f4c2440          movdqa    xmmword ptr [rsp + 0x40], xmm1
0x00014289eae2:  41b901000000          mov       r9d, 1
0x00014289eae8:  4c8d442450            lea       r8, [rsp + 0x50]
0x00014289eaed:  488d542440            lea       rdx, [rsp + 0x40]
0x00014289eaf2:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x00014289eaf6:  ff153c128a03          call      qword ptr [rip + 0x38a123c]
0x00014289eafc:  90                    nop       
0x00014289eafd:  40f6c702              test      dil, 2
0x00014289eb01:  7453                  je        0x14289eb56
0x00014289eb03:  83e7fd                and       edi, 0xfffffffd
0x00014289eb06:  897c2430              mov       dword ptr [rsp + 0x30], edi
0x00014289eb0a:  488b442478            mov       rax, qword ptr [rsp + 0x78]
0x00014289eb0f:  4883f810              cmp       rax, 0x10
0x00014289eb13:  722e                  jb        0x14289eb43
0x00014289eb15:  48ffc0                inc       rax
0x00014289eb18:  488b4c2460            mov       rcx, qword ptr [rsp + 0x60]
0x00014289eb1d:  488bd1                mov       rdx, rcx
0x00014289eb20:  483d00100000          cmp       rax, 0x1000
0x00014289eb26:  7215                  jb        0x14289eb3d
0x00014289eb28:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289eb2c:  482bd1                sub       rdx, rcx
0x00014289eb2f:  488d42f8              lea       rax, [rdx - 8]
0x00014289eb33:  4883f81f              cmp       rax, 0x1f
0x00014289eb37:  0f87b4020000          ja        0x14289edf1
0x00014289eb3d:  e86e450a02            call      0x1449430b0
0x00014289eb42:  90                    nop       
0x00014289eb43:  4c89642470            mov       qword ptr [rsp + 0x70], r12
0x00014289eb48:  48c74424780f000000    mov       qword ptr [rsp + 0x78], 0xf
0x00014289eb51:  c644246000            mov       byte ptr [rsp + 0x60], 0
0x00014289eb56:  40f6c701              test      dil, 1
0x00014289eb5a:  7437                  je        0x14289eb93
0x00014289eb5c:  488b4598              mov       rax, qword ptr [rbp - 0x68]
0x00014289eb60:  4883f810              cmp       rax, 0x10
0x00014289eb64:  722d                  jb        0x14289eb93
0x00014289eb66:  48ffc0                inc       rax
0x00014289eb69:  488b4d80              mov       rcx, qword ptr [rbp - 0x80]
0x00014289eb6d:  488bd1                mov       rdx, rcx
0x00014289eb70:  483d00100000          cmp       rax, 0x1000
0x00014289eb76:  7215                  jb        0x14289eb8d
0x00014289eb78:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289eb7c:  482bd1                sub       rdx, rcx
0x00014289eb7f:  488d42f8              lea       rax, [rdx - 8]
0x00014289eb83:  4883f81f              cmp       rax, 0x1f
0x00014289eb87:  0f876a020000          ja        0x14289edf7
0x00014289eb8d:  e81e450a02            call      0x1449430b0
0x00014289eb92:  90                    nop       
0x00014289eb93:  8b1dff8ca205          mov       ebx, dword ptr [rip + 0x5a28cff]
0x00014289eb99:  4c89642460            mov       qword ptr [rsp + 0x60], r12
0x00014289eb9e:  4c89642470            mov       qword ptr [rsp + 0x70], r12
0x00014289eba3:  48c74424780f000000    mov       qword ptr [rsp + 0x78], 0xf
0x00014289ebac:  c644246000            mov       byte ptr [rsp + 0x60], 0
0x00014289ebb1:  b920000000            mov       ecx, 0x20
0x00014289ebb6:  e815b5f4fd            call      0x1407ea0d0
0x00014289ebbb:  48c74424701a000000    mov       qword ptr [rsp + 0x70], 0x1a
0x00014289ebc4:  48c74424781f000000    mov       qword ptr [rsp + 0x78], 0x1f
0x00014289ebcd:  0f10054cb16904        movups    xmm0, xmmword ptr [rip + 0x469b14c]
0x00014289ebd4:  0f1100                movups    xmmword ptr [rax], xmm0
0x00014289ebd7:  f20f100d51b16904      movsd     xmm1, qword ptr [rip + 0x469b151]
0x00014289ebdf:  f20f114810            movsd     qword ptr [rax + 0x10], xmm1
0x00014289ebe4:  0fb70d4db16904        movzx     ecx, word ptr [rip + 0x469b14d]
0x00014289ebeb:  66894818              mov       word ptr [rax + 0x18], cx
0x00014289ebef:  c6401a00              mov       byte ptr [rax + 0x1a], 0
0x00014289ebf3:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x00014289ebf8:  c644242000            mov       byte ptr [rsp + 0x20], 0
0x00014289ebfd:  41b101                mov       r9b, 1
0x00014289ec00:  448bc3                mov       r8d, ebx
0x00014289ec03:  488d542460            lea       rdx, [rsp + 0x60]
0x00014289ec08:  488d4da0              lea       rcx, [rbp - 0x60]
0x00014289ec0c:  e88ffe1d00            call      0x142a7eaa0
0x00014289ec11:  90                    nop       
0x00014289ec12:  488b442478            mov       rax, qword ptr [rsp + 0x78]
0x00014289ec17:  4883f810              cmp       rax, 0x10
0x00014289ec1b:  722e                  jb        0x14289ec4b
0x00014289ec1d:  48ffc0                inc       rax
0x00014289ec20:  488b4c2460            mov       rcx, qword ptr [rsp + 0x60]
0x00014289ec25:  488bd1                mov       rdx, rcx
0x00014289ec28:  483d00100000          cmp       rax, 0x1000
0x00014289ec2e:  7215                  jb        0x14289ec45
0x00014289ec30:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289ec34:  482bd1                sub       rdx, rcx
0x00014289ec37:  488d42f8              lea       rax, [rdx - 8]
0x00014289ec3b:  4883f81f              cmp       rax, 0x1f
0x00014289ec3f:  0f87b8010000          ja        0x14289edfd
0x00014289ec45:  e866440a02            call      0x1449430b0
0x00014289ec4a:  90                    nop       
0x00014289ec4b:  488b8d00020000        mov       rcx, qword ptr [rbp + 0x200]
0x00014289ec52:  4885c9                test      rcx, rcx
0x00014289ec55:  7405                  je        0x14289ec5c
0x00014289ec57:  e8b4a2f2fd            call      0x1407c8f10
0x00014289ec5c:  488b85e8010000        mov       rax, qword ptr [rbp + 0x1e8]
0x00014289ec63:  4883f810              cmp       rax, 0x10
0x00014289ec67:  7230                  jb        0x14289ec99
0x00014289ec69:  48ffc0                inc       rax
0x00014289ec6c:  488b8dd0010000        mov       rcx, qword ptr [rbp + 0x1d0]
0x00014289ec73:  488bd1                mov       rdx, rcx
0x00014289ec76:  483d00100000          cmp       rax, 0x1000
0x00014289ec7c:  7215                  jb        0x14289ec93
0x00014289ec7e:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289ec82:  482bd1                sub       rdx, rcx
0x00014289ec85:  488d42f8              lea       rax, [rdx - 8]
0x00014289ec89:  4883f81f              cmp       rax, 0x1f
0x00014289ec8d:  0f8770010000          ja        0x14289ee03
0x00014289ec93:  e818440a02            call      0x1449430b0
0x00014289ec98:  90                    nop       
0x00014289ec99:  660f6f059f679304      movdqa    xmm0, xmmword ptr [rip + 0x493679f]
0x00014289eca1:  f30f7f85e0010000      movdqu    xmmword ptr [rbp + 0x1e0], xmm0
0x00014289eca9:  c685d001000000        mov       byte ptr [rbp + 0x1d0], 0
0x00014289ecb0:  488b85c0010000        mov       rax, qword ptr [rbp + 0x1c0]
0x00014289ecb7:  4883f810              cmp       rax, 0x10
0x00014289ecbb:  7230                  jb        0x14289eced
0x00014289ecbd:  48ffc0                inc       rax
0x00014289ecc0:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289ecc7:  488bd1                mov       rdx, rcx
0x00014289ecca:  483d00100000          cmp       rax, 0x1000
0x00014289ecd0:  7215                  jb        0x14289ece7
0x00014289ecd2:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289ecd6:  482bd1                sub       rdx, rcx
0x00014289ecd9:  488d42f8              lea       rax, [rdx - 8]
0x00014289ecdd:  4883f81f              cmp       rax, 0x1f
0x00014289ece1:  0f871c010000          ja        0x14289ee03
0x00014289ece7:  e8c4430a02            call      0x1449430b0
0x00014289ecec:  90                    nop       
0x00014289eced:  660f6f054b679304      movdqa    xmm0, xmmword ptr [rip + 0x493674b]
0x00014289ecf5:  f30f7f85b8010000      movdqu    xmmword ptr [rbp + 0x1b8], xmm0
0x00014289ecfd:  c685a801000000        mov       byte ptr [rbp + 0x1a8], 0
0x00014289ed04:  488d4da0              lea       rcx, [rbp - 0x60]
0x00014289ed08:  e873e6f7fd            call      0x14081d380
0x00014289ed0d:  f645a001              test      byte ptr [rbp - 0x60], 1
0x00014289ed11:  750a                  jne       0x14289ed1d
0x00014289ed13:  488b4da8              mov       rcx, qword ptr [rbp - 0x58]
0x00014289ed17:  e894430a02            call      0x1449430b0
0x00014289ed1c:  90                    nop       
0x00014289ed1d:  4180bf3810000000      cmp       byte ptr [r15 + 0x1038], 0
0x00014289ed25:  0f8495000000          je        0x14289edc0
0x00014289ed2b:  48c745980f000000      mov       qword ptr [rbp - 0x68], 0xf
0x00014289ed33:  48c745900a000000      mov       qword ptr [rbp - 0x70], 0xa
0x00014289ed3b:  f20f1005fdaf6904      movsd     xmm0, qword ptr [rip + 0x469affd]
0x00014289ed43:  f20f114580            movsd     qword ptr [rbp - 0x80], xmm0
0x00014289ed48:  0fb705f9af6904        movzx     eax, word ptr [rip + 0x469aff9]
0x00014289ed4f:  66894588              mov       word ptr [rbp - 0x78], ax
0x00014289ed53:  c6458a00              mov       byte ptr [rbp - 0x76], 0
0x00014289ed57:  488d4c2440            lea       rcx, [rsp + 0x40]
0x00014289ed5c:  e84f9f3200            call      0x142bc8cb0
0x00014289ed61:  90                    nop       
0x00014289ed62:  488b4c2440            mov       rcx, qword ptr [rsp + 0x40]
0x00014289ed67:  4885c9                test      rcx, rcx
0x00014289ed6a:  7411                  je        0x14289ed7d
0x00014289ed6c:  4533c9                xor       r9d, r9d
0x00014289ed6f:  458d4101              lea       r8d, [r9 + 1]
0x00014289ed73:  488d5580              lea       rdx, [rbp - 0x80]
0x00014289ed77:  e814733200            call      0x142bc6090
0x00014289ed7c:  90                    nop       
0x00014289ed7d:  488b4c2448            mov       rcx, qword ptr [rsp + 0x48]
0x00014289ed82:  4885c9                test      rcx, rcx
0x00014289ed85:  7406                  je        0x14289ed8d
0x00014289ed87:  e884a1f2fd            call      0x1407c8f10
0x00014289ed8c:  90                    nop       
0x00014289ed8d:  488b4598              mov       rax, qword ptr [rbp - 0x68]
0x00014289ed91:  4883f810              cmp       rax, 0x10
0x00014289ed95:  7229                  jb        0x14289edc0
0x00014289ed97:  48ffc0                inc       rax
0x00014289ed9a:  488b4d80              mov       rcx, qword ptr [rbp - 0x80]
0x00014289ed9e:  488bd1                mov       rdx, rcx
0x00014289eda1:  483d00100000          cmp       rax, 0x1000
0x00014289eda7:  7211                  jb        0x14289edba
0x00014289eda9:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289edad:  482bd1                sub       rdx, rcx
0x00014289edb0:  488d42f8              lea       rax, [rdx - 8]
0x00014289edb4:  4883f81f              cmp       rax, 0x1f
0x00014289edb8:  7731                  ja        0x14289edeb
0x00014289edba:  e8f1420a02            call      0x1449430b0
0x00014289edbf:  90                    nop       
0x00014289edc0:  488b8d08020000        mov       rcx, qword ptr [rbp + 0x208]
0x00014289edc7:  4833cc                xor       rcx, rsp
0x00014289edca:  e811282803            call      0x145b215e0
0x00014289edcf:  4c8d9c2410030000      lea       r11, [rsp + 0x310]
0x00014289edd7:  498b5b40              mov       rbx, qword ptr [r11 + 0x40]
0x00014289eddb:  498b7348              mov       rsi, qword ptr [r11 + 0x48]
0x00014289eddf:  498be3                mov       rsp, r11
0x00014289ede2:  415f                  pop       r15
0x00014289ede4:  415e                  pop       r14
0x00014289ede6:  415c                  pop       r12
0x00014289ede8:  5f                    pop       rdi
0x00014289ede9:  5d                    pop       rbp
0x00014289edea:  c3                    ret       
0x00014289edeb:  e830272b03            call      0x145b51520
0x00014289edf0:  90                    nop       
0x00014289edf1:  e82a272b03            call      0x145b51520
0x00014289edf6:  90                    nop       
0x00014289edf7:  e824272b03            call      0x145b51520
0x00014289edfc:  cc                    int3      
0x00014289edfd:  e81e272b03            call      0x145b51520
0x00014289ee02:  90                    nop       
0x00014289ee03:  e818272b03            call      0x145b51520
0x00014289ee08:  cc                    int3      
0x00014289ee09:  cc                    int3      
0x00014289ee0a:  cc                    int3      
0x00014289ee0b:  cc                    int3      
0x00014289ee0c:  cc                    int3      
0x00014289ee0d:  cc                    int3      
0x00014289ee0e:  cc                    int3      
0x00014289ee0f:  cc                    int3      
0x00014289ee10:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x00014289ee15:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x00014289ee1a:  55                    push      rbp
0x00014289ee1b:  57                    push      rdi
0x00014289ee1c:  4156                  push      r14
0x00014289ee1e:  488dac2440feffff      lea       rbp, [rsp - 0x1c0]
0x00014289ee26:  4881ecc0020000        sub       rsp, 0x2c0
0x00014289ee2d:  488b05bc484705        mov       rax, qword ptr [rip + 0x54748bc]
0x00014289ee34:  4833c4                xor       rax, rsp
0x00014289ee37:  488985b8010000        mov       qword ptr [rbp + 0x1b8], rax
0x00014289ee3e:  488bd9                mov       rbx, rcx
0x00014289ee41:  834c245001            or        dword ptr [rsp + 0x50], 1
0x00014289ee46:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289ee4b:  e830151e00            call      0x142a80380
0x00014289ee50:  90                    nop       
0x00014289ee51:  4533f6                xor       r14d, r14d
0x00014289ee54:  4c89b558010000        mov       qword ptr [rbp + 0x158], r14
0x00014289ee5b:  660f6f05dd659304      movdqa    xmm0, xmmword ptr [rip + 0x49365dd]
0x00014289ee63:  f30f7f8568010000      movdqu    xmmword ptr [rbp + 0x168], xmm0
0x00014289ee6b:  4488b558010000        mov       byte ptr [rbp + 0x158], r14b
0x00014289ee72:  4489b578010000        mov       dword ptr [rbp + 0x178], r14d
0x00014289ee79:  c6857c01000001        mov       byte ptr [rbp + 0x17c], 1
0x00014289ee80:  4c89b580010000        mov       qword ptr [rbp + 0x180], r14
0x00014289ee87:  f30f7f8590010000      movdqu    xmmword ptr [rbp + 0x190], xmm0
0x00014289ee8f:  4488b580010000        mov       byte ptr [rbp + 0x180], r14b
0x00014289ee96:  4489b5a4010000        mov       dword ptr [rbp + 0x1a4], r14d
0x00014289ee9d:  488b0dd49dd005        mov       rcx, qword ptr [rip + 0x5d09dd4]
0x00014289eea4:  4885c9                test      rcx, rcx
0x00014289eea7:  7416                  je        0x14289eebf
0x00014289eea9:  488b01                mov       rax, qword ptr [rcx]
0x00014289eeac:  488d95a8010000        lea       rdx, [rbp + 0x1a8]
0x00014289eeb3:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x00014289eeb7:  ff157b0e8a03          call      qword ptr [rip + 0x38a0e7b]
0x00014289eebd:  eb0b                  jmp       0x14289eeca
0x00014289eebf:  0f57c0                xorps     xmm0, xmm0
0x00014289eec2:  f30f7f85a8010000      movdqu    xmmword ptr [rbp + 0x1a8], xmm0
0x00014289eeca:  803d878aa20500        cmp       byte ptr [rip + 0x5a28a87], 0
0x00014289eed1:  0f84da000000          je        0x14289efb1
0x00014289eed7:  4863bb90000000        movsxd    rdi, dword ptr [rbx + 0x90]
0x00014289eede:  4533c0                xor       r8d, r8d
0x00014289eee1:  488d3500ae6904        lea       rsi, [rip + 0x469ae00]
0x00014289eee8:  488bd6                mov       rdx, rsi
0x00014289eeeb:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289eef0:  e8fb081e00            call      0x142a7f7f0
0x00014289eef5:  4885c0                test      rax, rax
0x00014289eef8:  744a                  je        0x14289ef44
0x00014289eefa:  8bd7                  mov       edx, edi
0x00014289eefc:  488bc8                mov       rcx, rax
0x00014289eeff:  e8dcbd1d00            call      0x142a7ace0
0x00014289ef04:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289ef0b:  4885c9                test      rcx, rcx
0x00014289ef0e:  7434                  je        0x14289ef44
0x00014289ef10:  488b01                mov       rax, qword ptr [rcx]
0x00014289ef13:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289ef18:  48c744243813000000    mov       qword ptr [rsp + 0x38], 0x13
0x00014289ef21:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289ef26:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289ef2c:  4c8bc7                mov       r8, rdi
0x00014289ef2f:  41b901000000          mov       r9d, 1
0x00014289ef35:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289ef3a:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289ef3e:  ff15f40d8a03          call      qword ptr [rip + 0x38a0df4]
0x00014289ef44:  4863bb94000000        movsxd    rdi, dword ptr [rbx + 0x94]
0x00014289ef4b:  4533c0                xor       r8d, r8d
0x00014289ef4e:  488d35abad6904        lea       rsi, [rip + 0x469adab]
0x00014289ef55:  488bd6                mov       rdx, rsi
0x00014289ef58:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289ef5d:  e88e081e00            call      0x142a7f7f0
0x00014289ef62:  4885c0                test      rax, rax
0x00014289ef65:  744a                  je        0x14289efb1
0x00014289ef67:  8bd7                  mov       edx, edi
0x00014289ef69:  488bc8                mov       rcx, rax
0x00014289ef6c:  e86fbd1d00            call      0x142a7ace0
0x00014289ef71:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289ef78:  4885c9                test      rcx, rcx
0x00014289ef7b:  7434                  je        0x14289efb1
0x00014289ef7d:  488b01                mov       rax, qword ptr [rcx]
0x00014289ef80:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289ef85:  48c744243818000000    mov       qword ptr [rsp + 0x38], 0x18
0x00014289ef8e:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289ef93:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289ef99:  4c8bc7                mov       r8, rdi
0x00014289ef9c:  41b901000000          mov       r9d, 1
0x00014289efa2:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289efa7:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289efab:  ff15870d8a03          call      qword ptr [rip + 0x38a0d87]
0x00014289efb1:  4863bb98000000        movsxd    rdi, dword ptr [rbx + 0x98]
0x00014289efb8:  4533c0                xor       r8d, r8d
0x00014289efbb:  488d35c6ad6904        lea       rsi, [rip + 0x469adc6]
0x00014289efc2:  488bd6                mov       rdx, rsi
0x00014289efc5:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289efca:  e821081e00            call      0x142a7f7f0
0x00014289efcf:  4885c0                test      rax, rax
0x00014289efd2:  744a                  je        0x14289f01e
0x00014289efd4:  8bd7                  mov       edx, edi
0x00014289efd6:  488bc8                mov       rcx, rax
0x00014289efd9:  e802bd1d00            call      0x142a7ace0
0x00014289efde:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289efe5:  4885c9                test      rcx, rcx
0x00014289efe8:  7434                  je        0x14289f01e
0x00014289efea:  488b01                mov       rax, qword ptr [rcx]
0x00014289efed:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289eff2:  48c74424381b000000    mov       qword ptr [rsp + 0x38], 0x1b
0x00014289effb:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f000:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f006:  4c8bc7                mov       r8, rdi
0x00014289f009:  41b901000000          mov       r9d, 1
0x00014289f00f:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f014:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f018:  ff151a0d8a03          call      qword ptr [rip + 0x38a0d1a]
0x00014289f01e:  4863bb9c000000        movsxd    rdi, dword ptr [rbx + 0x9c]
0x00014289f025:  4533c0                xor       r8d, r8d
0x00014289f028:  488d3579ad6904        lea       rsi, [rip + 0x469ad79]
0x00014289f02f:  488bd6                mov       rdx, rsi
0x00014289f032:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f037:  e8b4071e00            call      0x142a7f7f0
0x00014289f03c:  4885c0                test      rax, rax
0x00014289f03f:  744a                  je        0x14289f08b
0x00014289f041:  8bd7                  mov       edx, edi
0x00014289f043:  488bc8                mov       rcx, rax
0x00014289f046:  e895bc1d00            call      0x142a7ace0
0x00014289f04b:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f052:  4885c9                test      rcx, rcx
0x00014289f055:  7434                  je        0x14289f08b
0x00014289f057:  488b01                mov       rax, qword ptr [rcx]
0x00014289f05a:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f05f:  48c744243820000000    mov       qword ptr [rsp + 0x38], 0x20
0x00014289f068:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f06d:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f073:  4c8bc7                mov       r8, rdi
0x00014289f076:  41b901000000          mov       r9d, 1
0x00014289f07c:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f081:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f085:  ff15ad0c8a03          call      qword ptr [rip + 0x38a0cad]
0x00014289f08b:  803d76b9a20500        cmp       byte ptr [rip + 0x5a2b976], 0
0x00014289f092:  0f84da000000          je        0x14289f172
0x00014289f098:  4863bba0000000        movsxd    rdi, dword ptr [rbx + 0xa0]
0x00014289f09f:  4533c0                xor       r8d, r8d
0x00014289f0a2:  488d35a7ac6904        lea       rsi, [rip + 0x469aca7]
0x00014289f0a9:  488bd6                mov       rdx, rsi
0x00014289f0ac:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f0b1:  e83a071e00            call      0x142a7f7f0
0x00014289f0b6:  4885c0                test      rax, rax
0x00014289f0b9:  744a                  je        0x14289f105
0x00014289f0bb:  8bd7                  mov       edx, edi
0x00014289f0bd:  488bc8                mov       rcx, rax
0x00014289f0c0:  e81bbc1d00            call      0x142a7ace0
0x00014289f0c5:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f0cc:  4885c9                test      rcx, rcx
0x00014289f0cf:  7434                  je        0x14289f105
0x00014289f0d1:  488b01                mov       rax, qword ptr [rcx]
0x00014289f0d4:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f0d9:  48c744243813000000    mov       qword ptr [rsp + 0x38], 0x13
0x00014289f0e2:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f0e7:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f0ed:  4c8bc7                mov       r8, rdi
0x00014289f0f0:  41b901000000          mov       r9d, 1
0x00014289f0f6:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f0fb:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f0ff:  ff15330c8a03          call      qword ptr [rip + 0x38a0c33]
0x00014289f105:  4863bba4000000        movsxd    rdi, dword ptr [rbx + 0xa4]
0x00014289f10c:  4533c0                xor       r8d, r8d
0x00014289f10f:  488d3552ac6904        lea       rsi, [rip + 0x469ac52]
0x00014289f116:  488bd6                mov       rdx, rsi
0x00014289f119:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f11e:  e8cd061e00            call      0x142a7f7f0
0x00014289f123:  4885c0                test      rax, rax
0x00014289f126:  744a                  je        0x14289f172
0x00014289f128:  8bd7                  mov       edx, edi
0x00014289f12a:  488bc8                mov       rcx, rax
0x00014289f12d:  e8aebb1d00            call      0x142a7ace0
0x00014289f132:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f139:  4885c9                test      rcx, rcx
0x00014289f13c:  7434                  je        0x14289f172
0x00014289f13e:  488b01                mov       rax, qword ptr [rcx]
0x00014289f141:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f146:  48c744243818000000    mov       qword ptr [rsp + 0x38], 0x18
0x00014289f14f:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f154:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f15a:  4c8bc7                mov       r8, rdi
0x00014289f15d:  41b901000000          mov       r9d, 1
0x00014289f163:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f168:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f16c:  ff15c60b8a03          call      qword ptr [rip + 0x38a0bc6]
0x00014289f172:  803d4fb9a20500        cmp       byte ptr [rip + 0x5a2b94f], 0
0x00014289f179:  0f84da000000          je        0x14289f259
0x00014289f17f:  4863bba8000000        movsxd    rdi, dword ptr [rbx + 0xa8]
0x00014289f186:  4533c0                xor       r8d, r8d
0x00014289f189:  488d3590ae6904        lea       rsi, [rip + 0x469ae90]
0x00014289f190:  488bd6                mov       rdx, rsi
0x00014289f193:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f198:  e853061e00            call      0x142a7f7f0
0x00014289f19d:  4885c0                test      rax, rax
0x00014289f1a0:  744a                  je        0x14289f1ec
0x00014289f1a2:  8bd7                  mov       edx, edi
0x00014289f1a4:  488bc8                mov       rcx, rax
0x00014289f1a7:  e834bb1d00            call      0x142a7ace0
0x00014289f1ac:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f1b3:  4885c9                test      rcx, rcx
0x00014289f1b6:  7434                  je        0x14289f1ec
0x00014289f1b8:  488b01                mov       rax, qword ptr [rcx]
0x00014289f1bb:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f1c0:  48c744243818000000    mov       qword ptr [rsp + 0x38], 0x18
0x00014289f1c9:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f1ce:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f1d4:  4c8bc7                mov       r8, rdi
0x00014289f1d7:  41b901000000          mov       r9d, 1
0x00014289f1dd:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f1e2:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f1e6:  ff154c0b8a03          call      qword ptr [rip + 0x38a0b4c]
0x00014289f1ec:  4863bbac000000        movsxd    rdi, dword ptr [rbx + 0xac]
0x00014289f1f3:  4533c0                xor       r8d, r8d
0x00014289f1f6:  488d3543ae6904        lea       rsi, [rip + 0x469ae43]
0x00014289f1fd:  488bd6                mov       rdx, rsi
0x00014289f200:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f205:  e8e6051e00            call      0x142a7f7f0
0x00014289f20a:  4885c0                test      rax, rax
0x00014289f20d:  744a                  je        0x14289f259
0x00014289f20f:  8bd7                  mov       edx, edi
0x00014289f211:  488bc8                mov       rcx, rax
0x00014289f214:  e8c7ba1d00            call      0x142a7ace0
0x00014289f219:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f220:  4885c9                test      rcx, rcx
0x00014289f223:  7434                  je        0x14289f259
0x00014289f225:  488b01                mov       rax, qword ptr [rcx]
0x00014289f228:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f22d:  48c744243824000000    mov       qword ptr [rsp + 0x38], 0x24
0x00014289f236:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f23b:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f241:  4c8bc7                mov       r8, rdi
0x00014289f244:  41b901000000          mov       r9d, 1
0x00014289f24a:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f24f:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f253:  ff15df0a8a03          call      qword ptr [rip + 0x38a0adf]
0x00014289f259:  803d987da20500        cmp       byte ptr [rip + 0x5a27d98], 0
0x00014289f260:  0f844c040000          je        0x14289f6b2
0x00014289f266:  488bbbb8000000        mov       rdi, qword ptr [rbx + 0xb8]
0x00014289f26d:  4533c0                xor       r8d, r8d
0x00014289f270:  488d3579ad6904        lea       rsi, [rip + 0x469ad79]
0x00014289f277:  488bd6                mov       rdx, rsi
0x00014289f27a:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f27f:  e86c051e00            call      0x142a7f7f0
0x00014289f284:  4885c0                test      rax, rax
0x00014289f287:  744b                  je        0x14289f2d4
0x00014289f289:  488bd7                mov       rdx, rdi
0x00014289f28c:  488bc8                mov       rcx, rax
0x00014289f28f:  e84cbd1d00            call      0x142a7afe0
0x00014289f294:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f29b:  4885c9                test      rcx, rcx
0x00014289f29e:  7434                  je        0x14289f2d4
0x00014289f2a0:  488b01                mov       rax, qword ptr [rcx]
0x00014289f2a3:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f2a8:  48c744243813000000    mov       qword ptr [rsp + 0x38], 0x13
0x00014289f2b1:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f2b6:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f2bc:  41b901000000          mov       r9d, 1
0x00014289f2c2:  4c8bc7                mov       r8, rdi
0x00014289f2c5:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f2ca:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f2ce:  ff15640a8a03          call      qword ptr [rip + 0x38a0a64]
0x00014289f2d4:  488bbbc0000000        mov       rdi, qword ptr [rbx + 0xc0]
0x00014289f2db:  4533c0                xor       r8d, r8d
0x00014289f2de:  488d3523ad6904        lea       rsi, [rip + 0x469ad23]
0x00014289f2e5:  488bd6                mov       rdx, rsi
0x00014289f2e8:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f2ed:  e8fe041e00            call      0x142a7f7f0
0x00014289f2f2:  4885c0                test      rax, rax
0x00014289f2f5:  744b                  je        0x14289f342
0x00014289f2f7:  488bd7                mov       rdx, rdi
0x00014289f2fa:  488bc8                mov       rcx, rax
0x00014289f2fd:  e8debc1d00            call      0x142a7afe0
0x00014289f302:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f309:  4885c9                test      rcx, rcx
0x00014289f30c:  7434                  je        0x14289f342
0x00014289f30e:  488b01                mov       rax, qword ptr [rcx]
0x00014289f311:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f316:  48c744243817000000    mov       qword ptr [rsp + 0x38], 0x17
0x00014289f31f:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f324:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f32a:  41b901000000          mov       r9d, 1
0x00014289f330:  4c8bc7                mov       r8, rdi
0x00014289f333:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f338:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f33c:  ff15f6098a03          call      qword ptr [rip + 0x38a09f6]
0x00014289f342:  488bbbc8000000        mov       rdi, qword ptr [rbx + 0xc8]
0x00014289f349:  4533c0                xor       r8d, r8d
0x00014289f34c:  488d3545ad6904        lea       rsi, [rip + 0x469ad45]
0x00014289f353:  488bd6                mov       rdx, rsi
0x00014289f356:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f35b:  e890041e00            call      0x142a7f7f0
0x00014289f360:  4885c0                test      rax, rax
0x00014289f363:  744b                  je        0x14289f3b0
0x00014289f365:  488bd7                mov       rdx, rdi
0x00014289f368:  488bc8                mov       rcx, rax
0x00014289f36b:  e870bc1d00            call      0x142a7afe0
0x00014289f370:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f377:  4885c9                test      rcx, rcx
0x00014289f37a:  7434                  je        0x14289f3b0
0x00014289f37c:  488b01                mov       rax, qword ptr [rcx]
0x00014289f37f:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f384:  48c744243813000000    mov       qword ptr [rsp + 0x38], 0x13
0x00014289f38d:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f392:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f398:  41b901000000          mov       r9d, 1
0x00014289f39e:  4c8bc7                mov       r8, rdi
0x00014289f3a1:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f3a6:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f3aa:  ff1588098a03          call      qword ptr [rip + 0x38a0988]
0x00014289f3b0:  488bbbd0000000        mov       rdi, qword ptr [rbx + 0xd0]
0x00014289f3b7:  4533c0                xor       r8d, r8d
0x00014289f3ba:  488d35efac6904        lea       rsi, [rip + 0x469acef]
0x00014289f3c1:  488bd6                mov       rdx, rsi
0x00014289f3c4:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f3c9:  e822041e00            call      0x142a7f7f0
0x00014289f3ce:  4885c0                test      rax, rax
0x00014289f3d1:  744b                  je        0x14289f41e
0x00014289f3d3:  488bd7                mov       rdx, rdi
0x00014289f3d6:  488bc8                mov       rcx, rax
0x00014289f3d9:  e802bc1d00            call      0x142a7afe0
0x00014289f3de:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f3e5:  4885c9                test      rcx, rcx
0x00014289f3e8:  7434                  je        0x14289f41e
0x00014289f3ea:  488b01                mov       rax, qword ptr [rcx]
0x00014289f3ed:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f3f2:  48c744243810000000    mov       qword ptr [rsp + 0x38], 0x10
0x00014289f3fb:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f400:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f406:  41b901000000          mov       r9d, 1
0x00014289f40c:  4c8bc7                mov       r8, rdi
0x00014289f40f:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f414:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f418:  ff151a098a03          call      qword ptr [rip + 0x38a091a]
0x00014289f41e:  488bbbd8000000        mov       rdi, qword ptr [rbx + 0xd8]
0x00014289f425:  4533c0                xor       r8d, r8d
0x00014289f428:  488d3539ac6904        lea       rsi, [rip + 0x469ac39]
0x00014289f42f:  488bd6                mov       rdx, rsi
0x00014289f432:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f437:  e8b4031e00            call      0x142a7f7f0
0x00014289f43c:  4885c0                test      rax, rax
0x00014289f43f:  744b                  je        0x14289f48c
0x00014289f441:  488bd7                mov       rdx, rdi
0x00014289f444:  488bc8                mov       rcx, rax
0x00014289f447:  e894bb1d00            call      0x142a7afe0
0x00014289f44c:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f453:  4885c9                test      rcx, rcx
0x00014289f456:  7434                  je        0x14289f48c
0x00014289f458:  488b01                mov       rax, qword ptr [rcx]
0x00014289f45b:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f460:  48c744243812000000    mov       qword ptr [rsp + 0x38], 0x12
0x00014289f469:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f46e:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f474:  41b901000000          mov       r9d, 1
0x00014289f47a:  4c8bc7                mov       r8, rdi
0x00014289f47d:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f482:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f486:  ff15ac088a03          call      qword ptr [rip + 0x38a08ac]
0x00014289f48c:  488bbbe0000000        mov       rdi, qword ptr [rbx + 0xe0]
0x00014289f493:  4533c0                xor       r8d, r8d
0x00014289f496:  488d35e3ab6904        lea       rsi, [rip + 0x469abe3]
0x00014289f49d:  488bd6                mov       rdx, rsi
0x00014289f4a0:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f4a5:  e846031e00            call      0x142a7f7f0
0x00014289f4aa:  4885c0                test      rax, rax
0x00014289f4ad:  744b                  je        0x14289f4fa
0x00014289f4af:  488bd7                mov       rdx, rdi
0x00014289f4b2:  488bc8                mov       rcx, rax
0x00014289f4b5:  e826bb1d00            call      0x142a7afe0
0x00014289f4ba:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f4c1:  4885c9                test      rcx, rcx
0x00014289f4c4:  7434                  je        0x14289f4fa
0x00014289f4c6:  488b01                mov       rax, qword ptr [rcx]
0x00014289f4c9:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f4ce:  48c744243816000000    mov       qword ptr [rsp + 0x38], 0x16
0x00014289f4d7:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f4dc:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f4e2:  41b901000000          mov       r9d, 1
0x00014289f4e8:  4c8bc7                mov       r8, rdi
0x00014289f4eb:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f4f0:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f4f4:  ff153e088a03          call      qword ptr [rip + 0x38a083e]
0x00014289f4fa:  488bbbe8000000        mov       rdi, qword ptr [rbx + 0xe8]
0x00014289f501:  4533c0                xor       r8d, r8d
0x00014289f504:  488d35dda96904        lea       rsi, [rip + 0x469a9dd]
0x00014289f50b:  488bd6                mov       rdx, rsi
0x00014289f50e:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f513:  e8d8021e00            call      0x142a7f7f0
0x00014289f518:  4885c0                test      rax, rax
0x00014289f51b:  744b                  je        0x14289f568
0x00014289f51d:  488bd7                mov       rdx, rdi
0x00014289f520:  488bc8                mov       rcx, rax
0x00014289f523:  e8b8ba1d00            call      0x142a7afe0
0x00014289f528:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f52f:  4885c9                test      rcx, rcx
0x00014289f532:  7434                  je        0x14289f568
0x00014289f534:  488b01                mov       rax, qword ptr [rcx]
0x00014289f537:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f53c:  48c74424381a000000    mov       qword ptr [rsp + 0x38], 0x1a
0x00014289f545:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f54a:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f550:  41b901000000          mov       r9d, 1
0x00014289f556:  4c8bc7                mov       r8, rdi
0x00014289f559:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f55e:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f562:  ff15d0078a03          call      qword ptr [rip + 0x38a07d0]
0x00014289f568:  488bbbf0000000        mov       rdi, qword ptr [rbx + 0xf0]
0x00014289f56f:  4533c0                xor       r8d, r8d
0x00014289f572:  488d358fa96904        lea       rsi, [rip + 0x469a98f]
0x00014289f579:  488bd6                mov       rdx, rsi
0x00014289f57c:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f581:  e86a021e00            call      0x142a7f7f0
0x00014289f586:  4885c0                test      rax, rax
0x00014289f589:  744b                  je        0x14289f5d6
0x00014289f58b:  488bd7                mov       rdx, rdi
0x00014289f58e:  488bc8                mov       rcx, rax
0x00014289f591:  e84aba1d00            call      0x142a7afe0
0x00014289f596:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f59d:  4885c9                test      rcx, rcx
0x00014289f5a0:  7434                  je        0x14289f5d6
0x00014289f5a2:  488b01                mov       rax, qword ptr [rcx]
0x00014289f5a5:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f5aa:  48c744243816000000    mov       qword ptr [rsp + 0x38], 0x16
0x00014289f5b3:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f5b8:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f5be:  41b901000000          mov       r9d, 1
0x00014289f5c4:  4c8bc7                mov       r8, rdi
0x00014289f5c7:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f5cc:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f5d0:  ff1562078a03          call      qword ptr [rip + 0x38a0762]
0x00014289f5d6:  488bbbf8000000        mov       rdi, qword ptr [rbx + 0xf8]
0x00014289f5dd:  4533c0                xor       r8d, r8d
0x00014289f5e0:  488d35d1a86904        lea       rsi, [rip + 0x469a8d1]
0x00014289f5e7:  488bd6                mov       rdx, rsi
0x00014289f5ea:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f5ef:  e8fc011e00            call      0x142a7f7f0
0x00014289f5f4:  4885c0                test      rax, rax
0x00014289f5f7:  744b                  je        0x14289f644
0x00014289f5f9:  488bd7                mov       rdx, rdi
0x00014289f5fc:  488bc8                mov       rcx, rax
0x00014289f5ff:  e8dcb91d00            call      0x142a7afe0
0x00014289f604:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f60b:  4885c9                test      rcx, rcx
0x00014289f60e:  7434                  je        0x14289f644
0x00014289f610:  488b01                mov       rax, qword ptr [rcx]
0x00014289f613:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289f618:  48c744243813000000    mov       qword ptr [rsp + 0x38], 0x13
0x00014289f621:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f626:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f62c:  41b901000000          mov       r9d, 1
0x00014289f632:  4c8bc7                mov       r8, rdi
0x00014289f635:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f63a:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f63e:  ff15f4068a03          call      qword ptr [rip + 0x38a06f4]
0x00014289f644:  488b9b00010000        mov       rbx, qword ptr [rbx + 0x100]
0x00014289f64b:  4533c0                xor       r8d, r8d
0x00014289f64e:  488d3d7ba86904        lea       rdi, [rip + 0x469a87b]
0x00014289f655:  488bd7                mov       rdx, rdi
0x00014289f658:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f65d:  e88e011e00            call      0x142a7f7f0
0x00014289f662:  4885c0                test      rax, rax
0x00014289f665:  744b                  je        0x14289f6b2
0x00014289f667:  488bd3                mov       rdx, rbx
0x00014289f66a:  488bc8                mov       rcx, rax
0x00014289f66d:  e86eb91d00            call      0x142a7afe0
0x00014289f672:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x00014289f679:  4885c9                test      rcx, rcx
0x00014289f67c:  7434                  je        0x14289f6b2
0x00014289f67e:  488b01                mov       rax, qword ptr [rcx]
0x00014289f681:  48897c2430            mov       qword ptr [rsp + 0x30], rdi
0x00014289f686:  48c744243815000000    mov       qword ptr [rsp + 0x38], 0x15
0x00014289f68f:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289f694:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289f69a:  41b901000000          mov       r9d, 1
0x00014289f6a0:  4c8bc3                mov       r8, rbx
0x00014289f6a3:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f6a8:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x00014289f6ac:  ff1586068a03          call      qword ptr [rip + 0x38a0686]
0x00014289f6b2:  f7442450feffffff      test      dword ptr [rsp + 0x50], 0xfffffffe
0x00014289f6ba:  0f84b5000000          je        0x14289f775
0x00014289f6c0:  4c89742430            mov       qword ptr [rsp + 0x30], r14
0x00014289f6c5:  4c89742440            mov       qword ptr [rsp + 0x40], r14
0x00014289f6ca:  48c74424480f000000    mov       qword ptr [rsp + 0x48], 0xf
0x00014289f6d3:  c644243000            mov       byte ptr [rsp + 0x30], 0
0x00014289f6d8:  b920000000            mov       ecx, 0x20
0x00014289f6dd:  e8eea9f4fd            call      0x1407ea0d0
0x00014289f6e2:  48c744244019000000    mov       qword ptr [rsp + 0x40], 0x19
0x00014289f6eb:  48c74424481f000000    mov       qword ptr [rsp + 0x48], 0x1f
0x00014289f6f4:  0f100595a86904        movups    xmm0, xmmword ptr [rip + 0x469a895]
0x00014289f6fb:  0f1100                movups    xmmword ptr [rax], xmm0
0x00014289f6fe:  f20f100d9aa86904      movsd     xmm1, qword ptr [rip + 0x469a89a]
0x00014289f706:  f20f114810            movsd     qword ptr [rax + 0x10], xmm1
0x00014289f70b:  0fb60d96a86904        movzx     ecx, byte ptr [rip + 0x469a896]
0x00014289f712:  884818                mov       byte ptr [rax + 0x18], cl
0x00014289f715:  c6401900              mov       byte ptr [rax + 0x19], 0
0x00014289f719:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x00014289f71e:  c644242000            mov       byte ptr [rsp + 0x20], 0
0x00014289f723:  41b101                mov       r9b, 1
0x00014289f726:  41b810270000          mov       r8d, 0x2710
0x00014289f72c:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289f731:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f736:  e865f31d00            call      0x142a7eaa0
0x00014289f73b:  90                    nop       
0x00014289f73c:  488b442448            mov       rax, qword ptr [rsp + 0x48]
0x00014289f741:  4883f810              cmp       rax, 0x10
0x00014289f745:  722e                  jb        0x14289f775
0x00014289f747:  48ffc0                inc       rax
0x00014289f74a:  488b4c2430            mov       rcx, qword ptr [rsp + 0x30]
0x00014289f74f:  488bd1                mov       rdx, rcx
0x00014289f752:  483d00100000          cmp       rax, 0x1000
0x00014289f758:  7215                  jb        0x14289f76f
0x00014289f75a:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289f75e:  482bd1                sub       rdx, rcx
0x00014289f761:  488d42f8              lea       rax, [rdx - 8]
0x00014289f765:  4883f81f              cmp       rax, 0x1f
0x00014289f769:  0f8704010000          ja        0x14289f873
0x00014289f76f:  e83c390a02            call      0x1449430b0
0x00014289f774:  90                    nop       
0x00014289f775:  488b8db0010000        mov       rcx, qword ptr [rbp + 0x1b0]
0x00014289f77c:  4885c9                test      rcx, rcx
0x00014289f77f:  7405                  je        0x14289f786
0x00014289f781:  e88a97f2fd            call      0x1407c8f10
0x00014289f786:  488b8598010000        mov       rax, qword ptr [rbp + 0x198]
0x00014289f78d:  4883f810              cmp       rax, 0x10
0x00014289f791:  7230                  jb        0x14289f7c3
0x00014289f793:  48ffc0                inc       rax
0x00014289f796:  488b8d80010000        mov       rcx, qword ptr [rbp + 0x180]
0x00014289f79d:  488bd1                mov       rdx, rcx
0x00014289f7a0:  483d00100000          cmp       rax, 0x1000
0x00014289f7a6:  7215                  jb        0x14289f7bd
0x00014289f7a8:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289f7ac:  482bd1                sub       rdx, rcx
0x00014289f7af:  488d42f8              lea       rax, [rdx - 8]
0x00014289f7b3:  4883f81f              cmp       rax, 0x1f
0x00014289f7b7:  0f87b0000000          ja        0x14289f86d
0x00014289f7bd:  e8ee380a02            call      0x1449430b0
0x00014289f7c2:  90                    nop       
0x00014289f7c3:  660f6f05755c9304      movdqa    xmm0, xmmword ptr [rip + 0x4935c75]
0x00014289f7cb:  f30f7f8590010000      movdqu    xmmword ptr [rbp + 0x190], xmm0
0x00014289f7d3:  c6858001000000        mov       byte ptr [rbp + 0x180], 0
0x00014289f7da:  488b8570010000        mov       rax, qword ptr [rbp + 0x170]
0x00014289f7e1:  4883f810              cmp       rax, 0x10
0x00014289f7e5:  722c                  jb        0x14289f813
0x00014289f7e7:  48ffc0                inc       rax
0x00014289f7ea:  488b8d58010000        mov       rcx, qword ptr [rbp + 0x158]
0x00014289f7f1:  488bd1                mov       rdx, rcx
0x00014289f7f4:  483d00100000          cmp       rax, 0x1000
0x00014289f7fa:  7211                  jb        0x14289f80d
0x00014289f7fc:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289f800:  482bd1                sub       rdx, rcx
0x00014289f803:  488d42f8              lea       rax, [rdx - 8]
0x00014289f807:  4883f81f              cmp       rax, 0x1f
0x00014289f80b:  7760                  ja        0x14289f86d
0x00014289f80d:  e89e380a02            call      0x1449430b0
0x00014289f812:  90                    nop       
0x00014289f813:  660f6f05255c9304      movdqa    xmm0, xmmword ptr [rip + 0x4935c25]
0x00014289f81b:  f30f7f8568010000      movdqu    xmmword ptr [rbp + 0x168], xmm0
0x00014289f823:  c6855801000000        mov       byte ptr [rbp + 0x158], 0
0x00014289f82a:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289f82f:  e84cdbf7fd            call      0x14081d380
0x00014289f834:  f644245001            test      byte ptr [rsp + 0x50], 1
0x00014289f839:  750b                  jne       0x14289f846
0x00014289f83b:  488b4c2458            mov       rcx, qword ptr [rsp + 0x58]
0x00014289f840:  e86b380a02            call      0x1449430b0
0x00014289f845:  90                    nop       
0x00014289f846:  488b8db8010000        mov       rcx, qword ptr [rbp + 0x1b8]
0x00014289f84d:  4833cc                xor       rcx, rsp
0x00014289f850:  e88b1d2803            call      0x145b215e0
0x00014289f855:  4c8d9c24c0020000      lea       r11, [rsp + 0x2c0]
0x00014289f85d:  498b5b28              mov       rbx, qword ptr [r11 + 0x28]
0x00014289f861:  498b7330              mov       rsi, qword ptr [r11 + 0x30]
0x00014289f865:  498be3                mov       rsp, r11
0x00014289f868:  415e                  pop       r14
0x00014289f86a:  5f                    pop       rdi
0x00014289f86b:  5d                    pop       rbp
0x00014289f86c:  c3                    ret       
0x00014289f86d:  e8ae1c2b03            call      0x145b51520
0x00014289f872:  90                    nop       
0x00014289f873:  e8a81c2b03            call      0x145b51520
0x00014289f878:  90                    nop       
0x00014289f879:  cc                    int3      
0x00014289f87a:  cc                    int3      
0x00014289f87b:  cc                    int3      
0x00014289f87c:  cc                    int3      
0x00014289f87d:  cc                    int3      
0x00014289f87e:  cc                    int3      
0x00014289f87f:  cc                    int3      
0x00014289f880:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014289f885:  55                    push      rbp
0x00014289f886:  56                    push      rsi
0x00014289f887:  57                    push      rdi
0x00014289f888:  4154                  push      r12
0x00014289f88a:  4155                  push      r13
0x00014289f88c:  4156                  push      r14
0x00014289f88e:  4157                  push      r15
0x00014289f890:  488dac24d0feffff      lea       rbp, [rsp - 0x130]
0x00014289f898:  4881ec30020000        sub       rsp, 0x230
0x00014289f89f:  488b054a3e4705        mov       rax, qword ptr [rip + 0x5473e4a]
0x00014289f8a6:  4833c4                xor       rax, rsp
0x00014289f8a9:  48898520010000        mov       qword ptr [rbp + 0x120], rax
0x00014289f8b0:  4c894c2430            mov       qword ptr [rsp + 0x30], r9
0x00014289f8b5:  4c8bf2                mov       r14, rdx
0x00014289f8b8:  4c8bad90010000        mov       r13, qword ptr [rbp + 0x190]
0x00014289f8bf:  33c9                  xor       ecx, ecx
0x00014289f8c1:  894a10                mov       dword ptr [rdx + 0x10], ecx
0x00014289f8c4:  894a18                mov       dword ptr [rdx + 0x18], ecx
0x00014289f8c7:  884a08                mov       byte ptr [rdx + 8], cl
0x00014289f8ca:  66c745200101          mov       word ptr [rbp + 0x20], 0x101
0x00014289f8d0:  48894d60              mov       qword ptr [rbp + 0x60], rcx
0x00014289f8d4:  894d68                mov       dword ptr [rbp + 0x68], ecx
0x00014289f8d7:  48894d70              mov       qword ptr [rbp + 0x70], rcx
0x00014289f8db:  48894d78              mov       qword ptr [rbp + 0x78], rcx
0x00014289f8df:  0f57c0                xorps     xmm0, xmm0
0x00014289f8e2:  660f7f8580000000      movdqa    xmmword ptr [rbp + 0x80], xmm0
0x00014289f8ea:  48898d90000000        mov       qword ptr [rbp + 0x90], rcx
0x00014289f8f1:  488d85b0000000        lea       rax, [rbp + 0xb0]
0x00014289f8f8:  48898598000000        mov       qword ptr [rbp + 0x98], rax
0x00014289f8ff:  48898da0000000        mov       qword ptr [rbp + 0xa0], rcx
0x00014289f906:  48c785a800000020000000  mov       qword ptr [rbp + 0xa8], 0x20
0x00014289f911:  48c7c3ffffffff        mov       rbx, 0xffffffffffffffff
0x00014289f918:  899dd0000000          mov       dword ptr [rbp + 0xd0], ebx
0x00014289f91e:  888dd4000000          mov       byte ptr [rbp + 0xd4], cl
0x00014289f924:  4d8d6518              lea       r12, [r13 + 0x18]
0x00014289f928:  450fb74546            movzx     r8d, word ptr [r13 + 0x46]
0x00014289f92d:  498bd4                mov       rdx, r12
0x00014289f930:  488d4d20              lea       rcx, [rbp + 0x20]
0x00014289f934:  e8f7619dff            call      0x142275b30
0x00014289f939:  8d7305                lea       esi, [rbx + 5]
0x00014289f93c:  4c8bbd88000000        mov       r15, qword ptr [rbp + 0x88]
0x00014289f943:  488bbd80000000        mov       rdi, qword ptr [rbp + 0x80]
0x00014289f94a:  493bff                cmp       rdi, r15
0x00014289f94d:  7424                  je        0x14289f973
0x00014289f94f:  90                    nop       
0x00014289f950:  488b0f                mov       rcx, qword ptr [rdi]
0x00014289f953:  488b01                mov       rax, qword ptr [rcx]
0x00014289f956:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x00014289f95a:  ff15d8038a03          call      qword ptr [rip + 0x38a03d8]
0x00014289f960:  0fb6c0                movzx     eax, al
0x00014289f963:  6683c002              add       ax, 2
0x00014289f967:  6603f0                add       si, ax
0x00014289f96a:  4883c708              add       rdi, 8
0x00014289f96e:  493bff                cmp       rdi, r15
0x00014289f971:  75dd                  jne       0x14289f950
0x00014289f973:  0fb7f6                movzx     esi, si
0x00014289f976:  418b4e14              mov       ecx, dword ptr [r14 + 0x14]
0x00014289f97a:  83c107                add       ecx, 7
0x00014289f97d:  48c1e903              shr       rcx, 3
0x00014289f981:  483bf1                cmp       rsi, rcx
0x00014289f984:  7610                  jbe       0x14289f996
0x00014289f986:  488d14f500000000      lea       rdx, [rsi*8]
0x00014289f98e:  498bce                mov       rcx, r14
0x00014289f991:  e83a670000            call      0x1428a60d0
0x00014289f996:  488b05cbb14c05        mov       rax, qword ptr [rip + 0x54cb1cb]
0x00014289f99d:  3c06                  cmp       al, 6
0x00014289f99f:  0f82b6000000          jb        0x14289fa5b
0x00014289f9a5:  48c1e808              shr       rax, 8
0x00014289f9a9:  3c06                  cmp       al, 6
0x00014289f9ab:  0f82aa000000          jb        0x14289fa5b
0x00014289f9b1:  488d058ae31207        lea       rax, [rip + 0x712e38a]
0x00014289f9b8:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x00014289f9bd:  488b4c2440            mov       rcx, qword ptr [rsp + 0x40]
0x00014289f9c2:  488d0de7a56904        lea       rcx, [rip + 0x469a5e7]
0x00014289f9c9:  48894d80              mov       qword ptr [rbp - 0x80], rcx
0x00014289f9cd:  488bc3                mov       rax, rbx
0x00014289f9d0:  48ffc0                inc       rax
0x00014289f9d3:  803c0100              cmp       byte ptr [rcx + rax], 0
0x00014289f9d7:  75f7                  jne       0x14289f9d0
0x00014289f9d9:  48894588              mov       qword ptr [rbp - 0x78], rax
0x00014289f9dd:  488975a0              mov       qword ptr [rbp - 0x60], rsi
0x00014289f9e1:  4c8965b0              mov       qword ptr [rbp - 0x50], r12
0x00014289f9e5:  410fb74546            movzx     eax, word ptr [r13 + 0x46]
0x00014289f9ea:  8945c0                mov       dword ptr [rbp - 0x40], eax
0x00014289f9ed:  0f1045a0              movups    xmm0, xmmword ptr [rbp - 0x60]
0x00014289f9f1:  0f1185e0000000        movups    xmmword ptr [rbp + 0xe0], xmm0
0x00014289f9f8:  0f104db0              movups    xmm1, xmmword ptr [rbp - 0x50]
0x00014289f9fc:  0f118df0000000        movups    xmmword ptr [rbp + 0xf0], xmm1
0x00014289fa03:  0f1045c0              movups    xmm0, xmmword ptr [rbp - 0x40]
0x00014289fa07:  0f118500010000        movups    xmmword ptr [rbp + 0x100], xmm0
0x00014289fa0e:  48c7442470c4020000    mov       qword ptr [rsp + 0x70], 0x2c4
0x00014289fa17:  488d85e0000000        lea       rax, [rbp + 0xe0]
0x00014289fa1e:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x00014289fa23:  0f28442470            movaps    xmm0, xmmword ptr [rsp + 0x70]
0x00014289fa28:  660f7f442440          movdqa    xmmword ptr [rsp + 0x40], xmm0
0x00014289fa2e:  0f284d80              movaps    xmm1, xmmword ptr [rbp - 0x80]
0x00014289fa32:  660f7f4dd0            movdqa    xmmword ptr [rbp - 0x30], xmm1
0x00014289fa37:  0f10052ab14c05        movups    xmm0, xmmword ptr [rip + 0x54cb12a]
0x00014289fa3e:  0f2945e0              movaps    xmmword ptr [rbp - 0x20], xmm0
0x00014289fa42:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x00014289fa47:  4c8d4c2440            lea       r9, [rsp + 0x40]
0x00014289fa4c:  4c8d45d0              lea       r8, [rbp - 0x30]
0x00014289fa50:  b206                  mov       dl, 6
0x00014289fa52:  488d4de0              lea       rcx, [rbp - 0x20]
0x00014289fa56:  e875000c02            call      0x14495fad0
0x00014289fa5b:  498b06                mov       rax, qword ptr [r14]
0x00014289fa5e:  498bce                mov       rcx, r14
0x00014289fa61:  488b4008              mov       rax, qword ptr [rax + 8]
0x00014289fa65:  ff15cd028a03          call      qword ptr [rip + 0x38a02cd]
0x00014289fa6b:  48894590              mov       qword ptr [rbp - 0x70], rax
0x00014289fa6f:  48897598              mov       qword ptr [rbp - 0x68], rsi
0x00014289fa73:  0f284590              movaps    xmm0, xmmword ptr [rbp - 0x70]
0x00014289fa77:  660f7f45f0            movdqa    xmmword ptr [rbp - 0x10], xmm0
0x00014289fa7c:  4c8b4c2430            mov       r9, qword ptr [rsp + 0x30]
0x00014289fa81:  4c8d45f0              lea       r8, [rbp - 0x10]
0x00014289fa85:  488d5500              lea       rdx, [rbp]
0x00014289fa89:  488d4d20              lea       rcx, [rbp + 0x20]
0x00014289fa8d:  e8ce5a9dff            call      0x142275560
0x00014289fa92:  837d0000              cmp       dword ptr [rbp], 0
0x00014289fa96:  0f84cf000000          je        0x14289fb6b
0x00014289fa9c:  488b05c5b04c05        mov       rax, qword ptr [rip + 0x54cb0c5]
0x00014289faa3:  3c06                  cmp       al, 6
0x00014289faa5:  0f8288000000          jb        0x14289fb33
0x00014289faab:  48c1e808              shr       rax, 8
0x00014289faaf:  3c06                  cmp       al, 6
0x00014289fab1:  0f827c000000          jb        0x14289fb33
0x00014289fab7:  488d05dd431307        lea       rax, [rip + 0x71343dd]
0x00014289fabe:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x00014289fac3:  488b442430            mov       rax, qword ptr [rsp + 0x30]
0x00014289fac8:  4805856056fd          add       rax, -0x2a99f7b
0x00014289face:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x00014289fad3:  48ffc3                inc       rbx
0x00014289fad6:  803c1800              cmp       byte ptr [rax + rbx], 0
0x00014289fada:  75f7                  jne       0x14289fad3
0x00014289fadc:  48895c2468            mov       qword ptr [rsp + 0x68], rbx
0x00014289fae1:  48c744245000000000    mov       qword ptr [rsp + 0x50], 0
0x00014289faea:  488d8510010000        lea       rax, [rbp + 0x110]
0x00014289faf1:  4889442458            mov       qword ptr [rsp + 0x58], rax
0x00014289faf6:  0f28442450            movaps    xmm0, xmmword ptr [rsp + 0x50]
0x00014289fafb:  660f7f442450          movdqa    xmmword ptr [rsp + 0x50], xmm0
0x00014289fb01:  0f284c2460            movaps    xmm1, xmmword ptr [rsp + 0x60]
0x00014289fb06:  660f7f4c2460          movdqa    xmmword ptr [rsp + 0x60], xmm1
0x00014289fb0c:  0f100555b04c05        movups    xmm0, xmmword ptr [rip + 0x54cb055]
0x00014289fb13:  0f29442430            movaps    xmmword ptr [rsp + 0x30], xmm0
0x00014289fb18:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x00014289fb1d:  4c8d4c2450            lea       r9, [rsp + 0x50]
0x00014289fb22:  4c8d442460            lea       r8, [rsp + 0x60]
0x00014289fb27:  b206                  mov       dl, 6
0x00014289fb29:  488d4c2430            lea       rcx, [rsp + 0x30]
0x00014289fb2e:  e89dff0b02            call      0x14495fad0
0x00014289fb33:  4533c9                xor       r9d, r9d
0x00014289fb36:  4533c0                xor       r8d, r8d
0x00014289fb39:  488d5500              lea       rdx, [rbp]
0x00014289fb3d:  488d4d20              lea       rcx, [rbp + 0x20]
0x00014289fb41:  44380580b2a205        cmp       byte ptr [rip + 0x5a2b280], r8b
0x00014289fb48:  7413                  je        0x14289fb5d
0x00014289fb4a:  4488442428            mov       byte ptr [rsp + 0x28], r8b
0x00014289fb4f:  4488442420            mov       byte ptr [rsp + 0x20], r8b
0x00014289fb54:  e877429dff            call      0x142273dd0
0x00014289fb59:  33f6                  xor       esi, esi
0x00014289fb5b:  eb1a                  jmp       0x14289fb77
0x00014289fb5d:  c644242000            mov       byte ptr [rsp + 0x20], 0
0x00014289fb62:  e8492e9dff            call      0x1422729b0
0x00014289fb67:  33f6                  xor       esi, esi
0x00014289fb69:  eb0c                  jmp       0x14289fb77
0x00014289fb6b:  488d04f500000000      lea       rax, [rsi*8]
0x00014289fb73:  41894610              mov       dword ptr [r14 + 0x10], eax
0x00014289fb77:  488d85b0000000        lea       rax, [rbp + 0xb0]
0x00014289fb7e:  488b8d98000000        mov       rcx, qword ptr [rbp + 0x98]
0x00014289fb85:  483bc8                cmp       rcx, rax
0x00014289fb88:  7406                  je        0x14289fb90
0x00014289fb8a:  e821350a02            call      0x1449430b0
0x00014289fb8f:  90                    nop       
0x00014289fb90:  488b9d80000000        mov       rbx, qword ptr [rbp + 0x80]
0x00014289fb97:  4885db                test      rbx, rbx
0x00014289fb9a:  0f848a000000          je        0x14289fc2a
0x00014289fba0:  488bbd88000000        mov       rdi, qword ptr [rbp + 0x88]
0x00014289fba7:  483bdf                cmp       rbx, rdi
0x00014289fbaa:  742d                  je        0x14289fbd9
0x00014289fbac:  0f1f4000              nop       dword ptr [rax]
0x00014289fbb0:  488b0b                mov       rcx, qword ptr [rbx]
0x00014289fbb3:  4885c9                test      rcx, rcx
0x00014289fbb6:  7411                  je        0x14289fbc9
0x00014289fbb8:  488b01                mov       rax, qword ptr [rcx]
0x00014289fbbb:  ba01000000            mov       edx, 1
0x00014289fbc0:  488b00                mov       rax, qword ptr [rax]
0x00014289fbc3:  ff156f018a03          call      qword ptr [rip + 0x38a016f]
0x00014289fbc9:  4883c308              add       rbx, 8
0x00014289fbcd:  483bdf                cmp       rbx, rdi
0x00014289fbd0:  75de                  jne       0x14289fbb0
0x00014289fbd2:  488b9d80000000        mov       rbx, qword ptr [rbp + 0x80]
0x00014289fbd9:  488b8590000000        mov       rax, qword ptr [rbp + 0x90]
0x00014289fbe0:  482bc3                sub       rax, rbx
0x00014289fbe3:  48c1f803              sar       rax, 3
0x00014289fbe7:  488d04c500000000      lea       rax, [rax*8]
0x00014289fbef:  488bcb                mov       rcx, rbx
0x00014289fbf2:  483d00100000          cmp       rax, 0x1000
0x00014289fbf8:  7211                  jb        0x14289fc0b
0x00014289fbfa:  488b5bf8              mov       rbx, qword ptr [rbx - 8]
0x00014289fbfe:  482bcb                sub       rcx, rbx
0x00014289fc01:  488d41f8              lea       rax, [rcx - 8]
0x00014289fc05:  4883f81f              cmp       rax, 0x1f
0x00014289fc09:  776c                  ja        0x14289fc77
0x00014289fc0b:  488bcb                mov       rcx, rbx
0x00014289fc0e:  e89d340a02            call      0x1449430b0
0x00014289fc13:  90                    nop       
0x00014289fc14:  0f57c0                xorps     xmm0, xmm0
0x00014289fc17:  660f7f8580000000      movdqa    xmmword ptr [rbp + 0x80], xmm0
0x00014289fc1f:  48c7859000000000000000  mov       qword ptr [rbp + 0x90], 0
0x00014289fc2a:  488b4d60              mov       rcx, qword ptr [rbp + 0x60]
0x00014289fc2e:  4885c9                test      rcx, rcx
0x00014289fc31:  7417                  je        0x14289fc4a
0x00014289fc33:  488b01                mov       rax, qword ptr [rcx]
0x00014289fc36:  488d5528              lea       rdx, [rbp + 0x28]
0x00014289fc3a:  483bca                cmp       rcx, rdx
0x00014289fc3d:  0f95c2                setne     dl
0x00014289fc40:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x00014289fc44:  ff15ee008a03          call      qword ptr [rip + 0x38a00ee]
0x00014289fc4a:  488bc6                mov       rax, rsi
0x00014289fc4d:  488b8d20010000        mov       rcx, qword ptr [rbp + 0x120]
0x00014289fc54:  4833cc                xor       rcx, rsp
0x00014289fc57:  e884192803            call      0x145b215e0
0x00014289fc5c:  488b9c2470020000      mov       rbx, qword ptr [rsp + 0x270]
0x00014289fc64:  4881c430020000        add       rsp, 0x230
0x00014289fc6b:  415f                  pop       r15
0x00014289fc6d:  415e                  pop       r14
0x00014289fc6f:  415d                  pop       r13
0x00014289fc71:  415c                  pop       r12
0x00014289fc73:  5f                    pop       rdi
0x00014289fc74:  5e                    pop       rsi
0x00014289fc75:  5d                    pop       rbp
0x00014289fc76:  c3                    ret       
0x00014289fc77:  e8a4182b03            call      0x145b51520
0x00014289fc7c:  cc                    int3      
0x00014289fc7d:  cc                    int3      
0x00014289fc7e:  cc                    int3      
0x00014289fc7f:  cc                    int3      
