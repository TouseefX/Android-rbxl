; function_of: str.ClientRuppDeserializationError
; xref site 0x143328e5b -> str.ClientRuppDeserializationError @ 0x146f37ae0
; range 0x143327af0 .. 0x14332a9c0  (11984 bytes)

0x000143327af0:  488bc4                mov       rax, rsp
0x000143327af3:  48895808              mov       qword ptr [rax + 8], rbx
0x000143327af7:  48897020              mov       qword ptr [rax + 0x20], rsi
0x000143327afb:  55                    push      rbp
0x000143327afc:  57                    push      rdi
0x000143327afd:  4156                  push      r14
0x000143327aff:  488d68a1              lea       rbp, [rax - 0x5f]
0x000143327b03:  4881ecf0000000        sub       rsp, 0xf0
0x000143327b0a:  0f2970d8              movaps    xmmword ptr [rax - 0x28], xmm6
0x000143327b0e:  488b05dbbb9e04        mov       rax, qword ptr [rip + 0x49ebbdb]
0x000143327b15:  4833c4                xor       rax, rsp
0x000143327b18:  4889452f              mov       qword ptr [rbp + 0x2f], rax
0x000143327b1c:  498bf8                mov       rdi, r8
0x000143327b1f:  8bda                  mov       ebx, edx
0x000143327b21:  4c8bf1                mov       r14, rcx
0x000143327b24:  0f57c0                xorps     xmm0, xmm0
0x000143327b27:  f30f7f458f            movdqu    xmmword ptr [rbp - 0x71], xmm0
0x000143327b2c:  488b4908              mov       rcx, qword ptr [rcx + 8]
0x000143327b30:  4885c9                test      rcx, rcx
0x000143327b33:  740f                  je        0x143327b44
0x000143327b35:  498b06                mov       rax, qword ptr [r14]
0x000143327b38:  4889458f              mov       qword ptr [rbp - 0x71], rax
0x000143327b3c:  48894d97              mov       qword ptr [rbp - 0x69], rcx
0x000143327b40:  f0ff410c              lock inc  dword ptr [rcx + 0xc]
0x000143327b44:  4c8d05ed16cb03        lea       r8, [rip + 0x3cb16ed]
0x000143327b4b:  488d558f              lea       rdx, [rbp - 0x71]
0x000143327b4f:  488d4dbf              lea       rcx, [rbp - 0x41]
0x000143327b53:  e8688fffff            call      0x143320ac0
0x000143327b58:  90                    nop       
0x000143327b59:  488b75bf              mov       rsi, qword ptr [rbp - 0x41]
0x000143327b5d:  4885f6                test      rsi, rsi
0x000143327b60:  0f846d010000          je        0x143327cd3
0x000143327b66:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x000143327b6b:  4c8d0dc616cb03        lea       r9, [rip + 0x3cb16c6]
0x000143327b72:  4c8bc7                mov       r8, rdi
0x000143327b75:  8bd3                  mov       edx, ebx
0x000143327b77:  488bce                mov       rcx, rsi
0x000143327b7a:  e8d197ffff            call      0x143321350
0x000143327b7f:  84c0                  test      al, al
0x000143327b81:  0f844c010000          je        0x143327cd3
0x000143327b87:  488d9e28010000        lea       rbx, [rsi + 0x128]
0x000143327b8e:  48895d87              mov       qword ptr [rbp - 0x79], rbx
0x000143327b92:  488bcb                mov       rcx, rbx
0x000143327b95:  e816bc7f02            call      0x145b237b0
0x000143327b9a:  85c0                  test      eax, eax
0x000143327b9c:  0f856e010000          jne       0x143327d10
0x000143327ba2:  ff86f4000000          inc       dword ptr [rsi + 0xf4]
0x000143327ba8:  8b86f4000000          mov       eax, dword ptr [rsi + 0xf4]
0x000143327bae:  413b4610              cmp       eax, dword ptr [r14 + 0x10]
0x000143327bb2:  0f8512010000          jne       0x143327cca
0x000143327bb8:  488d4d9f              lea       rcx, [rbp - 0x61]
0x000143327bbc:  e83ffe6101            call      0x144947a00
0x000143327bc1:  f20f10459f            movsd     xmm0, qword ptr [rbp - 0x61]
0x000143327bc6:  f20f5c8600010000      subsd     xmm0, qword ptr [rsi + 0x100]
0x000143327bce:  f20f59056214ea03      mulsd     xmm0, qword ptr [rip + 0x3ea1462]
0x000143327bd6:  f20f2cc0              cvttsd2si eax, xmm0
0x000143327bda:  898614010000          mov       dword ptr [rsi + 0x114], eax
0x000143327be0:  0fb6bedd000000        movzx     edi, byte ptr [rsi + 0xdd]
0x000143327be7:  660f6ef0              movd      xmm6, eax
0x000143327beb:  f30fe6f6              cvtdq2pd  xmm6, xmm6
0x000143327bef:  b920000000            mov       ecx, 0x20
0x000143327bf4:  e8d7244cfd            call      0x1407ea0d0
0x000143327bf9:  48c7451f13000000      mov       qword ptr [rbp + 0x1f], 0x13
0x000143327c01:  48c745271f000000      mov       qword ptr [rbp + 0x27], 0x1f
0x000143327c09:  0f10052819cb03        movups    xmm0, xmmword ptr [rip + 0x3cb1928]
0x000143327c10:  0f1100                movups    xmmword ptr [rax], xmm0
0x000143327c13:  0fb70d2e19cb03        movzx     ecx, word ptr [rip + 0x3cb192e]
0x000143327c1a:  66894810              mov       word ptr [rax + 0x10], cx
0x000143327c1e:  0fb60d2519cb03        movzx     ecx, byte ptr [rip + 0x3cb1925]
0x000143327c25:  884812                mov       byte ptr [rax + 0x12], cl
0x000143327c28:  c6401300              mov       byte ptr [rax + 0x13], 0
0x000143327c2c:  4889450f              mov       qword ptr [rbp + 0xf], rax
0x000143327c30:  440fb6c7              movzx     r8d, dil
0x000143327c34:  0f28ce                movaps    xmm1, xmm6
0x000143327c37:  488d4d0f              lea       rcx, [rbp + 0xf]
0x000143327c3b:  e88075ffff            call      0x14331f1c0
0x000143327c40:  90                    nop       
0x000143327c41:  488b4527              mov       rax, qword ptr [rbp + 0x27]
0x000143327c45:  4883f810              cmp       rax, 0x10
0x000143327c49:  722d                  jb        0x143327c78
0x000143327c4b:  48ffc0                inc       rax
0x000143327c4e:  488b4d0f              mov       rcx, qword ptr [rbp + 0xf]
0x000143327c52:  488bd1                mov       rdx, rcx
0x000143327c55:  483d00100000          cmp       rax, 0x1000
0x000143327c5b:  7215                  jb        0x143327c72
0x000143327c5d:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143327c61:  482bd1                sub       rdx, rcx
0x000143327c64:  488d42f8              lea       rax, [rdx - 8]
0x000143327c68:  4883f81f              cmp       rax, 0x1f
0x000143327c6c:  0f8798000000          ja        0x143327d0a
0x000143327c72:  e839b46101            call      0x1449430b0
0x000143327c77:  90                    nop       
0x000143327c78:  4c8b4e38              mov       r9, qword ptr [rsi + 0x38]
0x000143327c7c:  33c9                  xor       ecx, ecx
0x000143327c7e:  498b4608              mov       rax, qword ptr [r14 + 8]
0x000143327c82:  8bd1                  mov       edx, ecx
0x000143327c84:  4885c0                test      rax, rax
0x000143327c87:  7413                  je        0x143327c9c
0x000143327c89:  498b16                mov       rdx, qword ptr [r14]
0x000143327c8c:  488945b7              mov       qword ptr [rbp - 0x49], rax
0x000143327c90:  f0ff400c              lock inc  dword ptr [rax + 0xc]
0x000143327c94:  488b5d87              mov       rbx, qword ptr [rbp - 0x79]
0x000143327c98:  488b4db7              mov       rcx, qword ptr [rbp - 0x49]
0x000143327c9c:  488d05b5959c03        lea       rax, [rip + 0x39c95b5]
0x000143327ca3:  488945cf              mov       qword ptr [rbp - 0x31], rax
0x000143327ca7:  488955d7              mov       qword ptr [rbp - 0x29], rdx
0x000143327cab:  48894ddf              mov       qword ptr [rbp - 0x21], rcx
0x000143327caf:  488d45cf              lea       rax, [rbp - 0x31]
0x000143327cb3:  48894507              mov       qword ptr [rbp + 7], rax
0x000143327cb7:  41b801000000          mov       r8d, 1
0x000143327cbd:  488d55cf              lea       rdx, [rbp - 0x31]
0x000143327cc1:  498bc9                mov       rcx, r9
0x000143327cc4:  e8a722df00            call      0x144119f70
0x000143327cc9:  90                    nop       
0x000143327cca:  488bcb                mov       rcx, rbx
0x000143327ccd:  e83ebb7f02            call      0x145b23810
0x000143327cd2:  90                    nop       
0x000143327cd3:  488b4dc7              mov       rcx, qword ptr [rbp - 0x39]
0x000143327cd7:  4885c9                test      rcx, rcx
0x000143327cda:  7405                  je        0x143327ce1
0x000143327cdc:  e82f124afd            call      0x1407c8f10
0x000143327ce1:  488b4d2f              mov       rcx, qword ptr [rbp + 0x2f]
0x000143327ce5:  4833cc                xor       rcx, rsp
0x000143327ce8:  e8f3987f02            call      0x145b215e0
0x000143327ced:  4c8d9c24f0000000      lea       r11, [rsp + 0xf0]
0x000143327cf5:  498b5b20              mov       rbx, qword ptr [r11 + 0x20]
0x000143327cf9:  498b7338              mov       rsi, qword ptr [r11 + 0x38]
0x000143327cfd:  410f2873f0            movaps    xmm6, xmmword ptr [r11 - 0x10]
0x000143327d02:  498be3                mov       rsp, r11
0x000143327d05:  415e                  pop       r14
0x000143327d07:  5f                    pop       rdi
0x000143327d08:  5d                    pop       rbp
0x000143327d09:  c3                    ret       
0x000143327d0a:  e811988202            call      0x145b51520
0x000143327d0f:  90                    nop       
0x000143327d10:  8bc8                  mov       ecx, eax
0x000143327d12:  e869c07f02            call      0x145b23d80
0x000143327d17:  cc                    int3      
0x000143327d18:  cc                    int3      
0x000143327d19:  cc                    int3      
0x000143327d1a:  cc                    int3      
0x000143327d1b:  cc                    int3      
0x000143327d1c:  cc                    int3      
0x000143327d1d:  cc                    int3      
0x000143327d1e:  cc                    int3      
0x000143327d1f:  cc                    int3      
0x000143327d20:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x000143327d25:  48896c2418            mov       qword ptr [rsp + 0x18], rbp
0x000143327d2a:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x000143327d2f:  57                    push      rdi
0x000143327d30:  4883ec40              sub       rsp, 0x40
0x000143327d34:  488bf1                mov       rsi, rcx
0x000143327d37:  488b7960              mov       rdi, qword ptr [rcx + 0x60]
0x000143327d3b:  488b1f                mov       rbx, qword ptr [rdi]
0x000143327d3e:  483bdf                cmp       rbx, rdi
0x000143327d41:  741d                  je        0x143327d60
0x000143327d43:  488b4b30              mov       rcx, qword ptr [rbx + 0x30]
0x000143327d47:  e884ecde00            call      0x1441169d0
0x000143327d4c:  4885c0                test      rax, rax
0x000143327d4f:  0f8447010000          je        0x143327e9c
0x000143327d55:  488b03                mov       rax, qword ptr [rbx]
0x000143327d58:  488bd8                mov       rbx, rax
0x000143327d5b:  483bc7                cmp       rax, rdi
0x000143327d5e:  75e3                  jne       0x143327d43
0x000143327d60:  488b7e60              mov       rdi, qword ptr [rsi + 0x60]
0x000143327d64:  488b1f                mov       rbx, qword ptr [rdi]
0x000143327d67:  483bdf                cmp       rbx, rdi
0x000143327d6a:  0f842a010000          je        0x143327e9a
0x000143327d70:  488b6b30              mov       rbp, qword ptr [rbx + 0x30]
0x000143327d74:  4885ed                test      rbp, rbp
0x000143327d77:  742a                  je        0x143327da3
0x000143327d79:  488b7518              mov       rsi, qword ptr [rbp + 0x18]
0x000143327d7d:  e89ea3c8fd            call      0x140fb2120
0x000143327d82:  0fb796b8010000        movzx     edx, word ptr [rsi + 0x1b8]
0x000143327d89:  0fb788b8010000        movzx     ecx, word ptr [rax + 0x1b8]
0x000143327d90:  2bd1                  sub       edx, ecx
0x000143327d92:  0fb780ba010000        movzx     eax, word ptr [rax + 0x1ba]
0x000143327d99:  33f6                  xor       esi, esi
0x000143327d9b:  3bd0                  cmp       edx, eax
0x000143327d9d:  480f46f5              cmovbe    rsi, rbp
0x000143327da1:  eb02                  jmp       0x143327da5
0x000143327da3:  33f6                  xor       esi, esi
0x000143327da5:  4885f6                test      rsi, rsi
0x000143327da8:  7422                  je        0x143327dcc
0x000143327daa:  488d5340              lea       rdx, [rbx + 0x40]
0x000143327dae:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000143327db3:  e86835e000            call      0x14412b320
0x000143327db8:  488d8e70010000        lea       rcx, [rsi + 0x170]
0x000143327dbf:  488bd0                mov       rdx, rax
0x000143327dc2:  e839a0c8fd            call      0x140fb1e00
0x000143327dc7:  e9c2000000            jmp       0x143327e8e
0x000143327dcc:  488b6b30              mov       rbp, qword ptr [rbx + 0x30]
0x000143327dd0:  4885ed                test      rbp, rbp
0x000143327dd3:  742a                  je        0x143327dff
0x000143327dd5:  488b7518              mov       rsi, qword ptr [rbp + 0x18]
0x000143327dd9:  e8428ecbfd            call      0x140fe0c20
0x000143327dde:  0fb796b8010000        movzx     edx, word ptr [rsi + 0x1b8]
0x000143327de5:  0fb788b8010000        movzx     ecx, word ptr [rax + 0x1b8]
0x000143327dec:  2bd1                  sub       edx, ecx
0x000143327dee:  0fb780ba010000        movzx     eax, word ptr [rax + 0x1ba]
0x000143327df5:  33f6                  xor       esi, esi
0x000143327df7:  3bd0                  cmp       edx, eax
0x000143327df9:  480f46f5              cmovbe    rsi, rbp
0x000143327dfd:  eb02                  jmp       0x143327e01
0x000143327dff:  33f6                  xor       esi, esi
0x000143327e01:  4885f6                test      rsi, rsi
0x000143327e04:  741f                  je        0x143327e25
0x000143327e06:  488d5340              lea       rdx, [rbx + 0x40]
0x000143327e0a:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000143327e0f:  e80c35e000            call      0x14412b320
0x000143327e14:  488d8ef0000000        lea       rcx, [rsi + 0xf0]
0x000143327e1b:  488bd0                mov       rdx, rax
0x000143327e1e:  e84d8acbfd            call      0x140fe0870
0x000143327e23:  eb69                  jmp       0x143327e8e
0x000143327e25:  488b6b30              mov       rbp, qword ptr [rbx + 0x30]
0x000143327e29:  4885ed                test      rbp, rbp
0x000143327e2c:  742a                  je        0x143327e58
0x000143327e2e:  488b7518              mov       rsi, qword ptr [rbp + 0x18]
0x000143327e32:  e8293ed4fd            call      0x14106bc60
0x000143327e37:  0fb796b8010000        movzx     edx, word ptr [rsi + 0x1b8]
0x000143327e3e:  0fb788b8010000        movzx     ecx, word ptr [rax + 0x1b8]
0x000143327e45:  2bd1                  sub       edx, ecx
0x000143327e47:  0fb780ba010000        movzx     eax, word ptr [rax + 0x1ba]
0x000143327e4e:  33f6                  xor       esi, esi
0x000143327e50:  3bd0                  cmp       edx, eax
0x000143327e52:  480f46f5              cmovbe    rsi, rbp
0x000143327e56:  eb02                  jmp       0x143327e5a
0x000143327e58:  33f6                  xor       esi, esi
0x000143327e5a:  4885f6                test      rsi, rsi
0x000143327e5d:  742f                  je        0x143327e8e
0x000143327e5f:  488d5340              lea       rdx, [rbx + 0x40]
0x000143327e63:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000143327e68:  e8b334e000            call      0x14412b320
0x000143327e6d:  90                    nop       
0x000143327e6e:  488bd0                mov       rdx, rax
0x000143327e71:  488bce                mov       rcx, rsi
0x000143327e74:  e8b777f200            call      0x14424f630
0x000143327e79:  90                    nop       
0x000143327e7a:  488d4c2428            lea       rcx, [rsp + 0x28]
0x000143327e7f:  e8fcea72fd            call      0x140a56980
0x000143327e84:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000143327e89:  e8f2ea72fd            call      0x140a56980
0x000143327e8e:  488b1b                mov       rbx, qword ptr [rbx]
0x000143327e91:  483bdf                cmp       rbx, rdi
0x000143327e94:  0f85d6feffff          jne       0x143327d70
0x000143327e9a:  b001                  mov       al, 1
0x000143327e9c:  488b5c2458            mov       rbx, qword ptr [rsp + 0x58]
0x000143327ea1:  488b6c2460            mov       rbp, qword ptr [rsp + 0x60]
0x000143327ea6:  488b742468            mov       rsi, qword ptr [rsp + 0x68]
0x000143327eab:  4883c440              add       rsp, 0x40
0x000143327eaf:  5f                    pop       rdi
0x000143327eb0:  c3                    ret       
0x000143327eb1:  cc                    int3      
0x000143327eb2:  cc                    int3      
0x000143327eb3:  cc                    int3      
0x000143327eb4:  cc                    int3      
0x000143327eb5:  cc                    int3      
0x000143327eb6:  cc                    int3      
0x000143327eb7:  cc                    int3      
0x000143327eb8:  cc                    int3      
0x000143327eb9:  cc                    int3      
0x000143327eba:  cc                    int3      
0x000143327ebb:  cc                    int3      
0x000143327ebc:  cc                    int3      
0x000143327ebd:  cc                    int3      
0x000143327ebe:  cc                    int3      
0x000143327ebf:  cc                    int3      
0x000143327ec0:  48895c2418            mov       qword ptr [rsp + 0x18], rbx
0x000143327ec5:  48897c2420            mov       qword ptr [rsp + 0x20], rdi
0x000143327eca:  55                    push      rbp
0x000143327ecb:  488dac2460fdffff      lea       rbp, [rsp - 0x2a0]
0x000143327ed3:  4881eca0030000        sub       rsp, 0x3a0
0x000143327eda:  488b050fb89e04        mov       rax, qword ptr [rip + 0x49eb80f]
0x000143327ee1:  4833c4                xor       rax, rsp
0x000143327ee4:  48898598020000        mov       qword ptr [rbp + 0x298], rax
0x000143327eeb:  0fb6fa                movzx     edi, dl
0x000143327eee:  488bd9                mov       rbx, rcx
0x000143327ef1:  488d157003a604        lea       rdx, [rip + 0x4a60370]
0x000143327ef8:  488d4c2450            lea       rcx, [rsp + 0x50]
0x000143327efd:  e8de064cfd            call      0x1407e85e0
0x000143327f02:  90                    nop       
0x000143327f03:  488d83b8000000        lea       rax, [rbx + 0xb8]
0x000143327f0a:  488b4810              mov       rcx, qword ptr [rax + 0x10]
0x000143327f0e:  4883781810            cmp       qword ptr [rax + 0x18], 0x10
0x000143327f13:  7203                  jb        0x143327f18
0x000143327f15:  488b00                mov       rax, qword ptr [rax]
0x000143327f18:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000143327f1d:  48894c2428            mov       qword ptr [rsp + 0x28], rcx
0x000143327f22:  488d050718cb03        lea       rax, [rip + 0x3cb1807]
0x000143327f29:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x000143327f2e:  48c744243808000000    mov       qword ptr [rsp + 0x38], 8
0x000143327f37:  0f28442420            movaps    xmm0, xmmword ptr [rsp + 0x20]
0x000143327f3c:  660f7f442420          movdqa    xmmword ptr [rsp + 0x20], xmm0
0x000143327f42:  0f284c2430            movaps    xmm1, xmmword ptr [rsp + 0x30]
0x000143327f47:  660f7f4c2430          movdqa    xmmword ptr [rsp + 0x30], xmm1
0x000143327f4d:  41b901000000          mov       r9d, 1
0x000143327f53:  4c8d442420            lea       r8, [rsp + 0x20]
0x000143327f58:  488d542430            lea       rdx, [rsp + 0x30]
0x000143327f5d:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x000143327f64:  e847b6baff            call      0x142ed35b0
0x000143327f69:  488d8398000000        lea       rax, [rbx + 0x98]
0x000143327f70:  488b4810              mov       rcx, qword ptr [rax + 0x10]
0x000143327f74:  4883781810            cmp       qword ptr [rax + 0x18], 0x10
0x000143327f79:  7203                  jb        0x143327f7e
0x000143327f7b:  488b00                mov       rax, qword ptr [rax]
0x000143327f7e:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x000143327f83:  48894c2438            mov       qword ptr [rsp + 0x38], rcx
0x000143327f88:  488d05a1ffad03        lea       rax, [rip + 0x3adffa1]
0x000143327f8f:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000143327f94:  48c74424280d000000    mov       qword ptr [rsp + 0x28], 0xd
0x000143327f9d:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x000143327fa2:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x000143327fa8:  0f284c2420            movaps    xmm1, xmmword ptr [rsp + 0x20]
0x000143327fad:  660f7f4c2420          movdqa    xmmword ptr [rsp + 0x20], xmm1
0x000143327fb3:  41b901000000          mov       r9d, 1
0x000143327fb9:  4c8d442430            lea       r8, [rsp + 0x30]
0x000143327fbe:  488d542420            lea       rdx, [rsp + 0x20]
0x000143327fc3:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x000143327fca:  e8e1b5baff            call      0x142ed35b0
0x000143327fcf:  488d054a17cb03        lea       rax, [rip + 0x3cb174a]
0x000143327fd6:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x000143327fdb:  48c74424380f000000    mov       qword ptr [rsp + 0x38], 0xf
0x000143327fe4:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x000143327fe9:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x000143327fef:  41b901000000          mov       r9d, 1
0x000143327ff5:  4c8b4368              mov       r8, qword ptr [rbx + 0x68]
0x000143327ff9:  488d542430            lea       rdx, [rsp + 0x30]
0x000143327ffe:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x000143328005:  e886aabaff            call      0x142ed2a90
0x00014332800a:  488d057716cb03        lea       rax, [rip + 0x3cb1677]
0x000143328011:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x000143328016:  48c744243816000000    mov       qword ptr [rsp + 0x38], 0x16
0x00014332801f:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x000143328024:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014332802a:  41b901000000          mov       r9d, 1
0x000143328030:  440fb6c7              movzx     r8d, dil
0x000143328034:  488d542430            lea       rdx, [rsp + 0x30]
0x000143328039:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x000143328040:  e82bbabaff            call      0x142ed3a70
0x000143328045:  33c0                  xor       eax, eax
0x000143328047:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x00014332804c:  48c74424480f000000    mov       qword ptr [rsp + 0x48], 0xf
0x000143328055:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x00014332805a:  88442430              mov       byte ptr [rsp + 0x30], al
0x00014332805e:  488d542430            lea       rdx, [rsp + 0x30]
0x000143328063:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x00014332806a:  e881eabaff            call      0x142ed6af0
0x00014332806f:  90                    nop       
0x000143328070:  488b442448            mov       rax, qword ptr [rsp + 0x48]
0x000143328075:  4883f810              cmp       rax, 0x10
0x000143328079:  722a                  jb        0x1433280a5
0x00014332807b:  48ffc0                inc       rax
0x00014332807e:  488b4c2430            mov       rcx, qword ptr [rsp + 0x30]
0x000143328083:  488bd1                mov       rdx, rcx
0x000143328086:  483d00100000          cmp       rax, 0x1000
0x00014332808c:  7211                  jb        0x14332809f
0x00014332808e:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143328092:  482bd1                sub       rdx, rcx
0x000143328095:  488d42f8              lea       rax, [rdx - 8]
0x000143328099:  4883f81f              cmp       rax, 0x1f
0x00014332809d:  7771                  ja        0x143328110
0x00014332809f:  e80cb06101            call      0x1449430b0
0x0001433280a4:  90                    nop       
0x0001433280a5:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x0001433280ac:  e81f00bbff            call      0x142ed80d0
0x0001433280b1:  488d8d68020000        lea       rcx, [rbp + 0x268]
0x0001433280b8:  e8c3feb9ff            call      0x142ec7f80
0x0001433280bd:  90                    nop       
0x0001433280be:  488d8d40020000        lea       rcx, [rbp + 0x240]
0x0001433280c5:  e866a84bfd            call      0x1407e2930
0x0001433280ca:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x0001433280d1:  e85aa84bfd            call      0x1407e2930
0x0001433280d6:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x0001433280dd:  e84e954afd            call      0x1407d1630
0x0001433280e2:  488d4c2478            lea       rcx, [rsp + 0x78]
0x0001433280e7:  e8f4d84bfd            call      0x1407e59e0
0x0001433280ec:  488b8d98020000        mov       rcx, qword ptr [rbp + 0x298]
0x0001433280f3:  4833cc                xor       rcx, rsp
0x0001433280f6:  e8e5947f02            call      0x145b215e0
0x0001433280fb:  4c8d9c24a0030000      lea       r11, [rsp + 0x3a0]
0x000143328103:  498b5b20              mov       rbx, qword ptr [r11 + 0x20]
0x000143328107:  498b7b28              mov       rdi, qword ptr [r11 + 0x28]
0x00014332810b:  498be3                mov       rsp, r11
0x00014332810e:  5d                    pop       rbp
0x00014332810f:  c3                    ret       
0x000143328110:  e80b948202            call      0x145b51520
0x000143328115:  90                    nop       
0x000143328116:  cc                    int3      
0x000143328117:  cc                    int3      
0x000143328118:  cc                    int3      
0x000143328119:  cc                    int3      
0x00014332811a:  cc                    int3      
0x00014332811b:  cc                    int3      
0x00014332811c:  cc                    int3      
0x00014332811d:  cc                    int3      
0x00014332811e:  cc                    int3      
0x00014332811f:  cc                    int3      
0x000143328120:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x000143328125:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x00014332812a:  48897c2420            mov       qword ptr [rsp + 0x20], rdi
0x00014332812f:  55                    push      rbp
0x000143328130:  4154                  push      r12
0x000143328132:  4155                  push      r13
0x000143328134:  4156                  push      r14
0x000143328136:  4157                  push      r15
0x000143328138:  488dac24c0fbffff      lea       rbp, [rsp - 0x440]
0x000143328140:  4881ec40050000        sub       rsp, 0x540
0x000143328147:  488b05a2b59e04        mov       rax, qword ptr [rip + 0x49eb5a2]
0x00014332814e:  4833c4                xor       rax, rsp
0x000143328151:  48898530040000        mov       qword ptr [rbp + 0x430], rax
0x000143328158:  4c8be9                mov       r13, rcx
0x00014332815b:  4533e4                xor       r12d, r12d
0x00014332815e:  458bf4                mov       r14d, r12d
0x000143328161:  4489642430            mov       dword ptr [rsp + 0x30], r12d
0x000143328166:  488b053b00a604        mov       rax, qword ptr [rip + 0x4a6003b]
0x00014332816d:  3c06                  cmp       al, 6
0x00014332816f:  0f82a0000000          jb        0x143328215
0x000143328175:  48c1e808              shr       rax, 8
0x000143328179:  3c04                  cmp       al, 4
0x00014332817b:  0f8294000000          jb        0x143328215
0x000143328181:  488d05cf4f1d04        lea       rax, [rip + 0x41d4fcf]
0x000143328188:  4889442438            mov       qword ptr [rsp + 0x38], rax
0x00014332818d:  488b4c2438            mov       rcx, qword ptr [rsp + 0x38]
0x000143328192:  488d0d0f15cb03        lea       rcx, [rip + 0x3cb150f]
0x000143328199:  48894dc0              mov       qword ptr [rbp - 0x40], rcx
0x00014332819d:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x0001433281a4:  48ffc0                inc       rax
0x0001433281a7:  44382401              cmp       byte ptr [rcx + rax], r12b
0x0001433281ab:  75f7                  jne       0x1433281a4
0x0001433281ad:  488945c8              mov       qword ptr [rbp - 0x38], rax
0x0001433281b1:  488d05b810cb03        lea       rax, [rip + 0x3cb10b8]
0x0001433281b8:  48894530              mov       qword ptr [rbp + 0x30], rax
0x0001433281bc:  0f284530              movaps    xmm0, xmmword ptr [rbp + 0x30]
0x0001433281c0:  660f7f85a0020000      movdqa    xmmword ptr [rbp + 0x2a0], xmm0
0x0001433281c8:  48c745b00c000000      mov       qword ptr [rbp - 0x50], 0xc
0x0001433281d0:  488d85a0020000        lea       rax, [rbp + 0x2a0]
0x0001433281d7:  488945b8              mov       qword ptr [rbp - 0x48], rax
0x0001433281db:  0f2845b0              movaps    xmm0, xmmword ptr [rbp - 0x50]
0x0001433281df:  660f7f4550            movdqa    xmmword ptr [rbp + 0x50], xmm0
0x0001433281e4:  0f284dc0              movaps    xmm1, xmmword ptr [rbp - 0x40]
0x0001433281e8:  660f7f4d60            movdqa    xmmword ptr [rbp + 0x60], xmm1
0x0001433281ed:  0f1005b4ffa504        movups    xmm0, xmmword ptr [rip + 0x4a5ffb4]
0x0001433281f4:  0f294570              movaps    xmmword ptr [rbp + 0x70], xmm0
0x0001433281f8:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x0001433281fd:  4c8d4d50              lea       r9, [rbp + 0x50]
0x000143328201:  4c8d4560              lea       r8, [rbp + 0x60]
0x000143328205:  b204                  mov       dl, 4
0x000143328207:  488d4d70              lea       rcx, [rbp + 0x70]
0x00014332820b:  e8c0786301            call      0x14495fad0
0x000143328210:  448b742430            mov       r14d, dword ptr [rsp + 0x30]
0x000143328215:  4c89a580010000        mov       qword ptr [rbp + 0x180], r12
0x00014332821c:  4c89a590010000        mov       qword ptr [rbp + 0x190], r12
0x000143328223:  48c785980100000f000000  mov       qword ptr [rbp + 0x198], 0xf
0x00014332822e:  4488a580010000        mov       byte ptr [rbp + 0x180], r12b
0x000143328235:  4c8b0554fda504        mov       r8, qword ptr [rip + 0x4a5fd54]
0x00014332823c:  488d153dfda504        lea       rdx, [rip + 0x4a5fd3d]
0x000143328243:  488b0d4efda504        mov       rcx, qword ptr [rip + 0x4a5fd4e]
0x00014332824a:  4c8b0d2ffda504        mov       r9, qword ptr [rip + 0x4a5fd2f]
0x000143328251:  4d85c0                test      r8, r8
0x000143328254:  0f856c020000          jne       0x1433284c6
0x00014332825a:  498b4538              mov       rax, qword ptr [r13 + 0x38]
0x00014332825e:  4c8bb878030000        mov       r15, qword ptr [rax + 0x378]
0x000143328265:  498b4d48              mov       rcx, qword ptr [r13 + 0x48]
0x000143328269:  44380528842905        cmp       byte ptr [rip + 0x5298428], r8b
0x000143328270:  7428                  je        0x14332829a
0x000143328272:  0f1081a8000000        movups    xmm0, xmmword ptr [rcx + 0xa8]
0x000143328279:  0f118540010000        movups    xmmword ptr [rbp + 0x140], xmm0
0x000143328280:  0f1089b8000000        movups    xmm1, xmmword ptr [rcx + 0xb8]
0x000143328287:  0f118d50010000        movups    xmmword ptr [rbp + 0x150], xmm1
0x00014332828e:  660f73d908            psrldq    xmm1, 8
0x000143328293:  66480f7ecf            movq      rdi, xmm1
0x000143328298:  eb49                  jmp       0x1433282e3
0x00014332829a:  488d81a0000000        lea       rax, [rcx + 0xa0]
0x0001433282a1:  4885c0                test      rax, rax
0x0001433282a4:  490f44cc              cmove     rcx, r12
0x0001433282a8:  488bb900030000        mov       rdi, qword ptr [rcx + 0x300]
0x0001433282af:  488b8140040000        mov       rax, qword ptr [rcx + 0x440]
0x0001433282b6:  482d95934805          sub       rax, 0x5489395
0x0001433282bc:  483bf8                cmp       rdi, rax
0x0001433282bf:  0f851e0b0000          jne       0x143328de3
0x0001433282c5:  803d6c83290500        cmp       byte ptr [rip + 0x529836c], 0
0x0001433282cc:  7415                  je        0x1433282e3
0x0001433282ce:  0f1081b8000000        movups    xmm0, xmmword ptr [rcx + 0xb8]
0x0001433282d5:  0f1185d0000000        movups    xmmword ptr [rbp + 0xd0], xmm0
0x0001433282dc:  488bb9a8000000        mov       rdi, qword ptr [rcx + 0xa8]
0x0001433282e3:  488d051b5e0603        lea       rax, [rip + 0x3065e1b]
0x0001433282ea:  488945d0              mov       qword ptr [rbp - 0x30], rax
0x0001433282ee:  4c8965d8              mov       qword ptr [rbp - 0x28], r12
0x0001433282f2:  488945e0              mov       qword ptr [rbp - 0x20], rax
0x0001433282f6:  4c8965e8              mov       qword ptr [rbp - 0x18], r12
0x0001433282fa:  488d05d7afb103        lea       rax, [rip + 0x3b1afd7]
0x000143328301:  488945f0              mov       qword ptr [rbp - 0x10], rax
0x000143328305:  48c745f82e000000      mov       qword ptr [rbp - 8], 0x2e
0x00014332830d:  488d15d863bf03        lea       rdx, [rip + 0x3bf63d8]
0x000143328314:  488d8d80020000        lea       rcx, [rbp + 0x280]
0x00014332831b:  e8d00774ff            call      0x142a68af0
0x000143328320:  41be02000000          mov       r14d, 2
0x000143328326:  4489742430            mov       dword ptr [rsp + 0x30], r14d
0x00014332832b:  488d8580020000        lea       rax, [rbp + 0x280]
0x000143328332:  4883bd9802000010      cmp       qword ptr [rbp + 0x298], 0x10
0x00014332833a:  480f438580020000      cmovae    rax, qword ptr [rbp + 0x280]
0x000143328342:  48894500              mov       qword ptr [rbp], rax
0x000143328346:  488b8590020000        mov       rax, qword ptr [rbp + 0x290]
0x00014332834d:  48894508              mov       qword ptr [rbp + 8], rax
0x000143328351:  488d05243dac03        lea       rax, [rip + 0x3ac3d24]
0x000143328358:  48894510              mov       qword ptr [rbp + 0x10], rax
0x00014332835c:  48c7451805000000      mov       qword ptr [rbp + 0x18], 5
0x000143328364:  0f2845d0              movaps    xmm0, xmmword ptr [rbp - 0x30]
0x000143328368:  660f7f8580000000      movdqa    xmmword ptr [rbp + 0x80], xmm0
0x000143328370:  0f284de0              movaps    xmm1, xmmword ptr [rbp - 0x20]
0x000143328374:  660f7f8d90000000      movdqa    xmmword ptr [rbp + 0x90], xmm1
0x00014332837c:  0f2845f0              movaps    xmm0, xmmword ptr [rbp - 0x10]
0x000143328380:  660f7f85a0000000      movdqa    xmmword ptr [rbp + 0xa0], xmm0
0x000143328388:  0f284d00              movaps    xmm1, xmmword ptr [rbp]
0x00014332838c:  660f7f8db0000000      movdqa    xmmword ptr [rbp + 0xb0], xmm1
0x000143328394:  0f284510              movaps    xmm0, xmmword ptr [rbp + 0x10]
0x000143328398:  660f7f85c0000000      movdqa    xmmword ptr [rbp + 0xc0], xmm0
0x0001433283a0:  488d8580000000        lea       rax, [rbp + 0x80]
0x0001433283a7:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x0001433283ac:  488d8590000000        lea       rax, [rbp + 0x90]
0x0001433283b3:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x0001433283b8:  4c8d8da0000000        lea       r9, [rbp + 0xa0]
0x0001433283bf:  4c8d85b0000000        lea       r8, [rbp + 0xb0]
0x0001433283c6:  488d95c0000000        lea       rdx, [rbp + 0xc0]
0x0001433283cd:  488d8d80030000        lea       rcx, [rbp + 0x380]
0x0001433283d4:  e837c36fff            call      0x142a24710
0x0001433283d9:  90                    nop       
0x0001433283da:  488d95f0020000        lea       rdx, [rbp + 0x2f0]
0x0001433283e1:  488bc8                mov       rcx, rax
0x0001433283e4:  e8b7ce6fff            call      0x142a252a0
0x0001433283e9:  c744243003000000      mov       dword ptr [rsp + 0x30], 3
0x0001433283f1:  488d8d00040000        lea       rcx, [rbp + 0x400]
0x0001433283f8:  e8e3d54bfd            call      0x1407e59e0
0x0001433283fd:  488d8de0030000        lea       rcx, [rbp + 0x3e0]
0x000143328404:  e8d7d54bfd            call      0x1407e59e0
0x000143328409:  488d8dc0030000        lea       rcx, [rbp + 0x3c0]
0x000143328410:  e8cbd54bfd            call      0x1407e59e0
0x000143328415:  488d8da0030000        lea       rcx, [rbp + 0x3a0]
0x00014332841c:  e8bfd54bfd            call      0x1407e59e0
0x000143328421:  488d8d80030000        lea       rcx, [rbp + 0x380]
0x000143328428:  e8b3d54bfd            call      0x1407e59e0
0x00014332842d:  90                    nop       
0x00014332842e:  488b8598020000        mov       rax, qword ptr [rbp + 0x298]
0x000143328435:  4883f810              cmp       rax, 0x10
0x000143328439:  7230                  jb        0x14332846b
0x00014332843b:  48ffc0                inc       rax
0x00014332843e:  488b8d80020000        mov       rcx, qword ptr [rbp + 0x280]
0x000143328445:  488bd1                mov       rdx, rcx
0x000143328448:  483d00100000          cmp       rax, 0x1000
0x00014332844e:  7215                  jb        0x143328465
0x000143328450:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143328454:  482bd1                sub       rdx, rcx
0x000143328457:  488d42f8              lea       rax, [rdx - 8]
0x00014332845b:  4883f81f              cmp       rax, 0x1f
0x00014332845f:  0f8792090000          ja        0x143328df7
0x000143328465:  e846ac6101            call      0x1449430b0
0x00014332846a:  90                    nop       
0x00014332846b:  488b8598010000        mov       rax, qword ptr [rbp + 0x198]
0x000143328472:  4883f810              cmp       rax, 0x10
0x000143328476:  7230                  jb        0x1433284a8
0x000143328478:  48ffc0                inc       rax
0x00014332847b:  488b8d80010000        mov       rcx, qword ptr [rbp + 0x180]
0x000143328482:  488bd1                mov       rdx, rcx
0x000143328485:  483d00100000          cmp       rax, 0x1000
0x00014332848b:  7215                  jb        0x1433284a2
0x00014332848d:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143328491:  482bd1                sub       rdx, rcx
0x000143328494:  488d42f8              lea       rax, [rdx - 8]
0x000143328498:  4883f81f              cmp       rax, 0x1f
0x00014332849c:  0f875b090000          ja        0x143328dfd
0x0001433284a2:  e809ac6101            call      0x1449430b0
0x0001433284a7:  90                    nop       
0x0001433284a8:  0f1085f0020000        movups    xmm0, xmmword ptr [rbp + 0x2f0]
0x0001433284af:  0f118580010000        movups    xmmword ptr [rbp + 0x180], xmm0
0x0001433284b6:  0f108d00030000        movups    xmm1, xmmword ptr [rbp + 0x300]
0x0001433284bd:  0f118d90010000        movups    xmmword ptr [rbp + 0x190], xmm1
0x0001433284c4:  eb1c                  jmp       0x1433284e2
0x0001433284c6:  bf01000000            mov       edi, 1
0x0001433284cb:  448bff                mov       r15d, edi
0x0001433284ce:  4883f910              cmp       rcx, 0x10
0x0001433284d2:  490f43d1              cmovae    rdx, r9
0x0001433284d6:  488d8d80010000        lea       rcx, [rbp + 0x180]
0x0001433284dd:  e86eb54bfd            call      0x1407e3a50
0x0001433284e2:  488d4c2440            lea       rcx, [rsp + 0x40]
0x0001433284e7:  e8043861fd            call      0x14093bcf0
0x0001433284ec:  90                    nop       
0x0001433284ed:  488d4d90              lea       rcx, [rbp - 0x70]
0x0001433284f1:  e89ad55efd            call      0x140915a90
0x0001433284f6:  90                    nop       
0x0001433284f7:  4c89a5a0010000        mov       qword ptr [rbp + 0x1a0], r12
0x0001433284fe:  48c785b80100000f000000  mov       qword ptr [rbp + 0x1b8], 0xf
0x000143328509:  48c785b001000007000000  mov       qword ptr [rbp + 0x1b0], 7
0x000143328514:  8b059e33ac03          mov       eax, dword ptr [rip + 0x3ac339e]
0x00014332851a:  8985a0010000          mov       dword ptr [rbp + 0x1a0], eax
0x000143328520:  0fb7059533ac03        movzx     eax, word ptr [rip + 0x3ac3395]
0x000143328527:  668985a4010000        mov       word ptr [rbp + 0x1a4], ax
0x00014332852e:  0fb6058933ac03        movzx     eax, byte ptr [rip + 0x3ac3389]
0x000143328535:  8885a6010000          mov       byte ptr [rbp + 0x1a6], al
0x00014332853b:  c685a701000000        mov       byte ptr [rbp + 0x1a7], 0
0x000143328542:  4183ce04              or        r14d, 4
0x000143328546:  4c8d85a0010000        lea       r8, [rbp + 0x1a0]
0x00014332854d:  488d95e0000000        lea       rdx, [rbp + 0xe0]
0x000143328554:  488b4c2440            mov       rcx, qword ptr [rsp + 0x40]
0x000143328559:  e8825a61fd            call      0x14093dfe0
0x00014332855e:  488b18                mov       rbx, qword ptr [rax]
0x000143328561:  e87a05a1fe            call      0x141d38ae0
0x000143328566:  48894330              mov       qword ptr [rbx + 0x30], rax
0x00014332856a:  e8e17e55fd            call      0x140880450
0x00014332856f:  488bf0                mov       rsi, rax
0x000143328572:  488b4338              mov       rax, qword ptr [rbx + 0x38]
0x000143328576:  483bc6                cmp       rax, rsi
0x000143328579:  7417                  je        0x143328592
0x00014332857b:  4885c0                test      rax, rax
0x00014332857e:  740e                  je        0x14332858e
0x000143328580:  488d4b40              lea       rcx, [rbx + 0x40]
0x000143328584:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x000143328588:  ff15aa77e102          call      qword ptr [rip + 0x2e177aa]
0x00014332858e:  48897338              mov       qword ptr [rbx + 0x38], rsi
0x000143328592:  4c897b40              mov       qword ptr [rbx + 0x40], r15
0x000143328596:  488b85b8010000        mov       rax, qword ptr [rbp + 0x1b8]
0x00014332859d:  4883f810              cmp       rax, 0x10
0x0001433285a1:  7230                  jb        0x1433285d3
0x0001433285a3:  48ffc0                inc       rax
0x0001433285a6:  488b8da0010000        mov       rcx, qword ptr [rbp + 0x1a0]
0x0001433285ad:  488bd1                mov       rdx, rcx
0x0001433285b0:  483d00100000          cmp       rax, 0x1000
0x0001433285b6:  7215                  jb        0x1433285cd
0x0001433285b8:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x0001433285bc:  482bd1                sub       rdx, rcx
0x0001433285bf:  488d42f8              lea       rax, [rdx - 8]
0x0001433285c3:  4883f81f              cmp       rax, 0x1f
0x0001433285c7:  0f8736080000          ja        0x143328e03
0x0001433285cd:  e8deaa6101            call      0x1449430b0
0x0001433285d2:  90                    nop       
0x0001433285d3:  48c785d80100000f000000  mov       qword ptr [rbp + 0x1d8], 0xf
0x0001433285de:  48c785d00100000f000000  mov       qword ptr [rbp + 0x1d0], 0xf
0x0001433285e9:  f20f1005af0bcb03      movsd     xmm0, qword ptr [rip + 0x3cb0baf]
0x0001433285f1:  f20f1185c0010000      movsd     qword ptr [rbp + 0x1c0], xmm0
0x0001433285f9:  8b05a90bcb03          mov       eax, dword ptr [rip + 0x3cb0ba9]
0x0001433285ff:  8985c8010000          mov       dword ptr [rbp + 0x1c8], eax
0x000143328605:  0fb705a00bcb03        movzx     eax, word ptr [rip + 0x3cb0ba0]
0x00014332860c:  668985cc010000        mov       word ptr [rbp + 0x1cc], ax
0x000143328613:  0fb605940bcb03        movzx     eax, byte ptr [rip + 0x3cb0b94]
0x00014332861a:  8885ce010000          mov       byte ptr [rbp + 0x1ce], al
0x000143328620:  c685cf01000000        mov       byte ptr [rbp + 0x1cf], 0
0x000143328627:  4183ce08              or        r14d, 8
0x00014332862b:  4c8d85c0010000        lea       r8, [rbp + 0x1c0]
0x000143328632:  488d95f0000000        lea       rdx, [rbp + 0xf0]
0x000143328639:  488b4c2440            mov       rcx, qword ptr [rsp + 0x40]
0x00014332863e:  e89d5961fd            call      0x14093dfe0
0x000143328643:  488b18                mov       rbx, qword ptr [rax]
0x000143328646:  e89504a1fe            call      0x141d38ae0
0x00014332864b:  48894330              mov       qword ptr [rbx + 0x30], rax
0x00014332864f:  e8fc7d55fd            call      0x140880450
0x000143328654:  488bf0                mov       rsi, rax
0x000143328657:  488b4338              mov       rax, qword ptr [rbx + 0x38]
0x00014332865b:  483bc6                cmp       rax, rsi
0x00014332865e:  7417                  je        0x143328677
0x000143328660:  4885c0                test      rax, rax
0x000143328663:  740e                  je        0x143328673
0x000143328665:  488d4b40              lea       rcx, [rbx + 0x40]
0x000143328669:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x00014332866d:  ff15c576e102          call      qword ptr [rip + 0x2e176c5]
0x000143328673:  48897338              mov       qword ptr [rbx + 0x38], rsi
0x000143328677:  48897b40              mov       qword ptr [rbx + 0x40], rdi
0x00014332867b:  488b85d8010000        mov       rax, qword ptr [rbp + 0x1d8]
0x000143328682:  4883f810              cmp       rax, 0x10
0x000143328686:  7230                  jb        0x1433286b8
0x000143328688:  48ffc0                inc       rax
0x00014332868b:  488b8dc0010000        mov       rcx, qword ptr [rbp + 0x1c0]
0x000143328692:  488bd1                mov       rdx, rcx
0x000143328695:  483d00100000          cmp       rax, 0x1000
0x00014332869b:  7215                  jb        0x1433286b2
0x00014332869d:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x0001433286a1:  482bd1                sub       rdx, rcx
0x0001433286a4:  488d42f8              lea       rax, [rdx - 8]
0x0001433286a8:  4883f81f              cmp       rax, 0x1f
0x0001433286ac:  0f8757070000          ja        0x143328e09
0x0001433286b2:  e8f9a96101            call      0x1449430b0
0x0001433286b7:  90                    nop       
0x0001433286b8:  48c785380200000f000000  mov       qword ptr [rbp + 0x238], 0xf
0x0001433286c3:  48c785300200000d000000  mov       qword ptr [rbp + 0x230], 0xd
0x0001433286ce:  f20f10055af8ad03      movsd     xmm0, qword ptr [rip + 0x3adf85a]
0x0001433286d6:  f20f118520020000      movsd     qword ptr [rbp + 0x220], xmm0
0x0001433286de:  8b0554f8ad03          mov       eax, dword ptr [rip + 0x3adf854]
0x0001433286e4:  898528020000          mov       dword ptr [rbp + 0x228], eax
0x0001433286ea:  0fb6054bf8ad03        movzx     eax, byte ptr [rip + 0x3adf84b]
0x0001433286f1:  88852c020000          mov       byte ptr [rbp + 0x22c], al
0x0001433286f7:  c6852d02000000        mov       byte ptr [rbp + 0x22d], 0
0x0001433286fe:  4183ce10              or        r14d, 0x10
0x000143328702:  4489742430            mov       dword ptr [rsp + 0x30], r14d
0x000143328707:  4c8d8520020000        lea       r8, [rbp + 0x220]
0x00014332870e:  488d9500010000        lea       rdx, [rbp + 0x100]
0x000143328715:  488b4c2440            mov       rcx, qword ptr [rsp + 0x40]
0x00014332871a:  e8c15861fd            call      0x14093dfe0
0x00014332871f:  488b18                mov       rbx, qword ptr [rax]
0x000143328722:  e8b905a1fe            call      0x141d38ce0
0x000143328727:  48894330              mov       qword ptr [rbx + 0x30], rax
0x00014332872b:  498d9598000000        lea       rdx, [r13 + 0x98]
0x000143328732:  488d4b38              lea       rcx, [rbx + 0x38]
0x000143328736:  e8b55c55fd            call      0x14087e3f0
0x00014332873b:  90                    nop       
0x00014332873c:  488b8538020000        mov       rax, qword ptr [rbp + 0x238]
0x000143328743:  4883f810              cmp       rax, 0x10
0x000143328747:  7230                  jb        0x143328779
0x000143328749:  48ffc0                inc       rax
0x00014332874c:  488b8d20020000        mov       rcx, qword ptr [rbp + 0x220]
0x000143328753:  488bd1                mov       rdx, rcx
0x000143328756:  483d00100000          cmp       rax, 0x1000
0x00014332875c:  7215                  jb        0x143328773
0x00014332875e:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143328762:  482bd1                sub       rdx, rcx
0x000143328765:  488d42f8              lea       rax, [rdx - 8]
0x000143328769:  4883f81f              cmp       rax, 0x1f
0x00014332876d:  0f879c060000          ja        0x143328e0f
0x000143328773:  e838a96101            call      0x1449430b0
0x000143328778:  90                    nop       
0x000143328779:  4d8b7d60              mov       r15, qword ptr [r13 + 0x60]
0x00014332877d:  498b1f                mov       rbx, qword ptr [r15]
0x000143328780:  493bdf                cmp       rbx, r15
0x000143328783:  0f8479020000          je        0x143328a02
0x000143328789:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014332878e:  e85d3561fd            call      0x14093bcf0
0x000143328793:  90                    nop       
0x000143328794:  488b4b30              mov       rcx, qword ptr [rbx + 0x30]
0x000143328798:  488d4160              lea       rax, [rcx + 0x60]
0x00014332879c:  4885c0                test      rax, rax
0x00014332879f:  490f44cc              cmove     rcx, r12
0x0001433287a3:  e8d863a2fe            call      0x141d4eb80
0x0001433287a8:  0f1000                movups    xmm0, xmmword ptr [rax]
0x0001433287ab:  0f114540              movups    xmmword ptr [rbp + 0x40], xmm0
0x0001433287af:  488d9510030000        lea       rdx, [rbp + 0x310]
0x0001433287b6:  488d4d40              lea       rcx, [rbp + 0x40]
0x0001433287ba:  e8f1859ffe            call      0x141d20db0
0x0001433287bf:  488bf0                mov       rsi, rax
0x0001433287c2:  48c785f80100000f000000  mov       qword ptr [rbp + 0x1f8], 0xf
0x0001433287cd:  48c785f001000008000000  mov       qword ptr [rbp + 0x1f0], 8
0x0001433287d8:  488b0dd109cb03        mov       rcx, qword ptr [rip + 0x3cb09d1]
0x0001433287df:  48898de0010000        mov       qword ptr [rbp + 0x1e0], rcx
0x0001433287e6:  c685e801000000        mov       byte ptr [rbp + 0x1e8], 0
0x0001433287ed:  4183ce20              or        r14d, 0x20
0x0001433287f1:  4c8d85e0010000        lea       r8, [rbp + 0x1e0]
0x0001433287f8:  488d9510010000        lea       rdx, [rbp + 0x110]
0x0001433287ff:  488b4c2450            mov       rcx, qword ptr [rsp + 0x50]
0x000143328804:  e8d75761fd            call      0x14093dfe0
0x000143328809:  488b38                mov       rdi, qword ptr [rax]
0x00014332880c:  e8cf04a1fe            call      0x141d38ce0
0x000143328811:  48894730              mov       qword ptr [rdi + 0x30], rax
0x000143328815:  488d4f38              lea       rcx, [rdi + 0x38]
0x000143328819:  488bd6                mov       rdx, rsi
0x00014332881c:  e85f4654fd            call      0x14086ce80
0x000143328821:  90                    nop       
0x000143328822:  488b85f8010000        mov       rax, qword ptr [rbp + 0x1f8]
0x000143328829:  4883f810              cmp       rax, 0x10
0x00014332882d:  7230                  jb        0x14332885f
0x00014332882f:  48ffc0                inc       rax
0x000143328832:  488b8de0010000        mov       rcx, qword ptr [rbp + 0x1e0]
0x000143328839:  488bd1                mov       rdx, rcx
0x00014332883c:  483d00100000          cmp       rax, 0x1000
0x000143328842:  7215                  jb        0x143328859
0x000143328844:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143328848:  482bd1                sub       rdx, rcx
0x00014332884b:  488d42f8              lea       rax, [rdx - 8]
0x00014332884f:  4883f81f              cmp       rax, 0x1f
0x000143328853:  0f87bc050000          ja        0x143328e15
0x000143328859:  e852a86101            call      0x1449430b0
0x00014332885e:  90                    nop       
0x00014332885f:  4c89a5f0010000        mov       qword ptr [rbp + 0x1f0], r12
0x000143328866:  48c785f80100000f000000  mov       qword ptr [rbp + 0x1f8], 0xf
0x000143328871:  c685e001000000        mov       byte ptr [rbp + 0x1e0], 0
0x000143328878:  488b8528030000        mov       rax, qword ptr [rbp + 0x328]
0x00014332887f:  4883f810              cmp       rax, 0x10
0x000143328883:  7230                  jb        0x1433288b5
0x000143328885:  48ffc0                inc       rax
0x000143328888:  488b8d10030000        mov       rcx, qword ptr [rbp + 0x310]
0x00014332888f:  488bd1                mov       rdx, rcx
0x000143328892:  483d00100000          cmp       rax, 0x1000
0x000143328898:  7215                  jb        0x1433288af
0x00014332889a:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014332889e:  482bd1                sub       rdx, rcx
0x0001433288a1:  488d42f8              lea       rax, [rdx - 8]
0x0001433288a5:  4883f81f              cmp       rax, 0x1f
0x0001433288a9:  0f876c050000          ja        0x143328e1b
0x0001433288af:  e8fca76101            call      0x1449430b0
0x0001433288b4:  90                    nop       
0x0001433288b5:  488b4330              mov       rax, qword ptr [rbx + 0x30]
0x0001433288b9:  488b7070              mov       rsi, qword ptr [rax + 0x70]
0x0001433288bd:  4c89a540020000        mov       qword ptr [rbp + 0x240], r12
0x0001433288c4:  48c785580200000f000000  mov       qword ptr [rbp + 0x258], 0xf
0x0001433288cf:  48c7855002000004000000  mov       qword ptr [rbp + 0x250], 4
0x0001433288da:  c785400200006e616d65  mov       dword ptr [rbp + 0x240], 0x656d616e
0x0001433288e4:  c6854402000000        mov       byte ptr [rbp + 0x244], 0
0x0001433288eb:  4183ce40              or        r14d, 0x40
0x0001433288ef:  4489742430            mov       dword ptr [rsp + 0x30], r14d
0x0001433288f4:  4c8d8540020000        lea       r8, [rbp + 0x240]
0x0001433288fb:  488d9520010000        lea       rdx, [rbp + 0x120]
0x000143328902:  488b4c2450            mov       rcx, qword ptr [rsp + 0x50]
0x000143328907:  e8d45661fd            call      0x14093dfe0
0x00014332890c:  488b38                mov       rdi, qword ptr [rax]
0x00014332890f:  e8cc03a1fe            call      0x141d38ce0
0x000143328914:  48894730              mov       qword ptr [rdi + 0x30], rax
0x000143328918:  488d4f38              lea       rcx, [rdi + 0x38]
0x00014332891c:  488d5608              lea       rdx, [rsi + 8]
0x000143328920:  e8cb5a55fd            call      0x14087e3f0
0x000143328925:  90                    nop       
0x000143328926:  488b8558020000        mov       rax, qword ptr [rbp + 0x258]
0x00014332892d:  4883f810              cmp       rax, 0x10
0x000143328931:  7230                  jb        0x143328963
0x000143328933:  48ffc0                inc       rax
0x000143328936:  488b8d40020000        mov       rcx, qword ptr [rbp + 0x240]
0x00014332893d:  488bd1                mov       rdx, rcx
0x000143328940:  483d00100000          cmp       rax, 0x1000
0x000143328946:  7215                  jb        0x14332895d
0x000143328948:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014332894c:  482bd1                sub       rdx, rcx
0x00014332894f:  488d42f8              lea       rax, [rdx - 8]
0x000143328953:  4883f81f              cmp       rax, 0x1f
0x000143328957:  0f87c4040000          ja        0x143328e21
0x00014332895d:  e84ea76101            call      0x1449430b0
0x000143328962:  90                    nop       
0x000143328963:  488b7d90              mov       rdi, qword ptr [rbp - 0x70]
0x000143328967:  488b7708              mov       rsi, qword ptr [rdi + 8]
0x00014332896b:  483b7710              cmp       rsi, qword ptr [rdi + 0x10]
0x00014332896f:  7426                  je        0x143328997
0x000143328971:  4889742438            mov       qword ptr [rsp + 0x38], rsi
0x000143328976:  e8651ea1fe            call      0x141d3a7e0
0x00014332897b:  488906                mov       qword ptr [rsi], rax
0x00014332897e:  488d4e08              lea       rcx, [rsi + 8]
0x000143328982:  4c8921                mov       qword ptr [rcx], r12
0x000143328985:  488d542450            lea       rdx, [rsp + 0x50]
0x00014332898a:  e861fbe1fd            call      0x1411484f0
0x00014332898f:  90                    nop       
0x000143328990:  4883470850            add       qword ptr [rdi + 8], 0x50
0x000143328995:  eb11                  jmp       0x1433289a8
0x000143328997:  4c8d442450            lea       r8, [rsp + 0x50]
0x00014332899c:  488bd6                mov       rdx, rsi
0x00014332899f:  488bcf                mov       rcx, rdi
0x0001433289a2:  e809fefdfd            call      0x1413087b0
0x0001433289a7:  90                    nop       
0x0001433289a8:  488b7c2458            mov       rdi, qword ptr [rsp + 0x58]
0x0001433289ad:  4885ff                test      rdi, rdi
0x0001433289b0:  7442                  je        0x1433289f4
0x0001433289b2:  b8ffffffff            mov       eax, 0xffffffff
0x0001433289b7:  f00fc14708            lock xadd dword ptr [rdi + 8], eax
0x0001433289bc:  83f801                cmp       eax, 1
0x0001433289bf:  752e                  jne       0x1433289ef
0x0001433289c1:  488b07                mov       rax, qword ptr [rdi]
0x0001433289c4:  488bcf                mov       rcx, rdi
0x0001433289c7:  488b00                mov       rax, qword ptr [rax]
0x0001433289ca:  ff156873e102          call      qword ptr [rip + 0x2e17368]
0x0001433289d0:  b8ffffffff            mov       eax, 0xffffffff
0x0001433289d5:  f00fc1470c            lock xadd dword ptr [rdi + 0xc], eax
0x0001433289da:  83f801                cmp       eax, 1
0x0001433289dd:  7510                  jne       0x1433289ef
0x0001433289df:  488b07                mov       rax, qword ptr [rdi]
0x0001433289e2:  488bcf                mov       rcx, rdi
0x0001433289e5:  488b4008              mov       rax, qword ptr [rax + 8]
0x0001433289e9:  ff154973e102          call      qword ptr [rip + 0x2e17349]
0x0001433289ef:  448b742430            mov       r14d, dword ptr [rsp + 0x30]
0x0001433289f4:  488b03                mov       rax, qword ptr [rbx]
0x0001433289f7:  488bd8                mov       rbx, rax
0x0001433289fa:  493bc7                cmp       rax, r15
0x0001433289fd:  e981fdffff            jmp       0x143328783
0x000143328a02:  4c89a500020000        mov       qword ptr [rbp + 0x200], r12
0x000143328a09:  48c785180200000f000000  mov       qword ptr [rbp + 0x218], 0xf
0x000143328a14:  48c7851002000007000000  mov       qword ptr [rbp + 0x210], 7
0x000143328a1f:  8b0563a9c203          mov       eax, dword ptr [rip + 0x3c2a963]
0x000143328a25:  898500020000          mov       dword ptr [rbp + 0x200], eax
0x000143328a2b:  0fb7055aa9c203        movzx     eax, word ptr [rip + 0x3c2a95a]
0x000143328a32:  66898504020000        mov       word ptr [rbp + 0x204], ax
0x000143328a39:  0fb6054ea9c203        movzx     eax, byte ptr [rip + 0x3c2a94e]
0x000143328a40:  888506020000          mov       byte ptr [rbp + 0x206], al
0x000143328a46:  c6850702000000        mov       byte ptr [rbp + 0x207], 0
0x000143328a4d:  4c8d8500020000        lea       r8, [rbp + 0x200]
0x000143328a54:  488d9530010000        lea       rdx, [rbp + 0x130]
0x000143328a5b:  488b4c2440            mov       rcx, qword ptr [rsp + 0x40]
0x000143328a60:  e87b5561fd            call      0x14093dfe0
0x000143328a65:  488b18                mov       rbx, qword ptr [rax]
0x000143328a68:  e8731ba1fe            call      0x141d3a5e0
0x000143328a6d:  48894330              mov       qword ptr [rbx + 0x30], rax
0x000143328a71:  488d4b38              lea       rcx, [rbx + 0x38]
0x000143328a75:  488d5590              lea       rdx, [rbp - 0x70]
0x000143328a79:  e882f3e7fd            call      0x1411a7e00
0x000143328a7e:  90                    nop       
0x000143328a7f:  488b8518020000        mov       rax, qword ptr [rbp + 0x218]
0x000143328a86:  4883f810              cmp       rax, 0x10
0x000143328a8a:  7230                  jb        0x143328abc
0x000143328a8c:  48ffc0                inc       rax
0x000143328a8f:  488b8d00020000        mov       rcx, qword ptr [rbp + 0x200]
0x000143328a96:  488bd1                mov       rdx, rcx
0x000143328a99:  483d00100000          cmp       rax, 0x1000
0x000143328a9f:  7215                  jb        0x143328ab6
0x000143328aa1:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143328aa5:  482bd1                sub       rdx, rcx
0x000143328aa8:  488d42f8              lea       rax, [rdx - 8]
0x000143328aac:  4883f81f              cmp       rax, 0x1f
0x000143328ab0:  0f8771030000          ja        0x143328e27
0x000143328ab6:  e8f5a56101            call      0x1449430b0
0x000143328abb:  90                    nop       
0x000143328abc:  4c89a560010000        mov       qword ptr [rbp + 0x160], r12
0x000143328ac3:  4c89a570010000        mov       qword ptr [rbp + 0x170], r12
0x000143328aca:  48c785780100000f000000  mov       qword ptr [rbp + 0x178], 0xf
0x000143328ad5:  c6856001000000        mov       byte ptr [rbp + 0x160], 0
0x000143328adc:  e8ff1ca1fe            call      0x141d3a7e0
0x000143328ae1:  48898530030000        mov       qword ptr [rbp + 0x330], rax
0x000143328ae8:  4c89a538030000        mov       qword ptr [rbp + 0x338], r12
0x000143328aef:  488d542440            lea       rdx, [rsp + 0x40]
0x000143328af4:  488d8d38030000        lea       rcx, [rbp + 0x338]
0x000143328afb:  e8f0f9e1fd            call      0x1411484f0
0x000143328b00:  90                    nop       
0x000143328b01:  41b801000000          mov       r8d, 1
0x000143328b07:  488d9560010000        lea       rdx, [rbp + 0x160]
0x000143328b0e:  488d8d30030000        lea       rcx, [rbp + 0x330]
0x000143328b15:  e8d6f17901            call      0x144ac7cf0
0x000143328b1a:  90                    nop       
0x000143328b1b:  488b8538030000        mov       rax, qword ptr [rbp + 0x338]
0x000143328b22:  4885c0                test      rax, rax
0x000143328b25:  7412                  je        0x143328b39
0x000143328b27:  488d8d40030000        lea       rcx, [rbp + 0x340]
0x000143328b2e:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x000143328b32:  ff150072e102          call      qword ptr [rip + 0x2e17200]
0x000143328b38:  90                    nop       
0x000143328b39:  33d2                  xor       edx, edx
0x000143328b3b:  488d4c2470            lea       rcx, [rsp + 0x70]
0x000143328b40:  e86bef98ff            call      0x142cb7ab0
0x000143328b45:  90                    nop       
0x000143328b46:  410fb68ddd000000      movzx     ecx, byte ptr [r13 + 0xdd]
0x000143328b4e:  488d442460            lea       rax, [rsp + 0x60]
0x000143328b53:  4889442438            mov       qword ptr [rsp + 0x38], rax
0x000143328b58:  0f57c0                xorps     xmm0, xmm0
0x000143328b5b:  f30f7f442460          movdqu    xmmword ptr [rsp + 0x60], xmm0
0x000143328b61:  498b4550              mov       rax, qword ptr [r13 + 0x50]
0x000143328b65:  4885c0                test      rax, rax
0x000143328b68:  7404                  je        0x143328b6e
0x000143328b6a:  f0ff4008              lock inc  dword ptr [rax + 8]
0x000143328b6e:  498b4548              mov       rax, qword ptr [r13 + 0x48]
0x000143328b72:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x000143328b77:  498b4550              mov       rax, qword ptr [r13 + 0x50]
0x000143328b7b:  4889442468            mov       qword ptr [rsp + 0x68], rax
0x000143328b80:  4c89a560020000        mov       qword ptr [rbp + 0x260], r12
0x000143328b87:  48c785780200000f000000  mov       qword ptr [rbp + 0x278], 0xf
0x000143328b92:  48c7857002000004000000  mov       qword ptr [rbp + 0x270], 4
0x000143328b9d:  c78560020000504f5354  mov       dword ptr [rbp + 0x260], 0x54534f50
0x000143328ba7:  c6856402000000        mov       byte ptr [rbp + 0x264], 0
0x000143328bae:  660f7f4580            movdqa    xmmword ptr [rbp - 0x80], xmm0
0x000143328bb3:  488b7c2478            mov       rdi, qword ptr [rsp + 0x78]
0x000143328bb8:  4885ff                test      rdi, rdi
0x000143328bbb:  7409                  je        0x143328bc6
0x000143328bbd:  f0ff4708              lock inc  dword ptr [rdi + 8]
0x000143328bc1:  488b7c2478            mov       rdi, qword ptr [rsp + 0x78]
0x000143328bc6:  0f28442470            movaps    xmm0, xmmword ptr [rsp + 0x70]
0x000143328bcb:  660f7f4580            movdqa    xmmword ptr [rbp - 0x80], xmm0
0x000143328bd0:  884c2420              mov       byte ptr [rsp + 0x20], cl
0x000143328bd4:  4c8d4c2460            lea       r9, [rsp + 0x60]
0x000143328bd9:  4c8d8580010000        lea       r8, [rbp + 0x180]
0x000143328be0:  488d9560020000        lea       rdx, [rbp + 0x260]
0x000143328be7:  488d4d80              lea       rcx, [rbp - 0x80]
0x000143328beb:  e81068ffff            call      0x14331f400
0x000143328bf0:  90                    nop       
0x000143328bf1:  488b8578020000        mov       rax, qword ptr [rbp + 0x278]
0x000143328bf8:  4883f810              cmp       rax, 0x10
0x000143328bfc:  7230                  jb        0x143328c2e
0x000143328bfe:  48ffc0                inc       rax
0x000143328c01:  488b8d60020000        mov       rcx, qword ptr [rbp + 0x260]
0x000143328c08:  488bd1                mov       rdx, rcx
0x000143328c0b:  483d00100000          cmp       rax, 0x1000
0x000143328c11:  7215                  jb        0x143328c28
0x000143328c13:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143328c17:  482bd1                sub       rdx, rcx
0x000143328c1a:  488d42f8              lea       rax, [rdx - 8]
0x000143328c1e:  4883f81f              cmp       rax, 0x1f
0x000143328c22:  0f8705020000          ja        0x143328e2d
0x000143328c28:  e883a46101            call      0x1449430b0
0x000143328c2d:  90                    nop       
0x000143328c2e:  488d8560010000        lea       rax, [rbp + 0x160]
0x000143328c35:  4883bd7801000010      cmp       qword ptr [rbp + 0x178], 0x10
0x000143328c3d:  480f438560010000      cmovae    rax, qword ptr [rbp + 0x160]
0x000143328c45:  488945a0              mov       qword ptr [rbp - 0x60], rax
0x000143328c49:  488b8570010000        mov       rax, qword ptr [rbp + 0x170]
0x000143328c50:  488945a8              mov       qword ptr [rbp - 0x58], rax
0x000143328c54:  41b001                mov       r8b, 1
0x000143328c57:  488d55a0              lea       rdx, [rbp - 0x60]
0x000143328c5b:  488b5c2470            mov       rbx, qword ptr [rsp + 0x70]
0x000143328c60:  488bcb                mov       rcx, rbx
0x000143328c63:  e8e81499ff            call      0x142cba150
0x000143328c68:  498bd5                mov       rdx, r13
0x000143328c6b:  488d4d20              lea       rcx, [rbp + 0x20]
0x000143328c6f:  e80c5813fe            call      0x14145e480
0x000143328c74:  90                    nop       
0x000143328c75:  488b03                mov       rax, qword ptr [rbx]
0x000143328c78:  0f284d20              movaps    xmm1, xmmword ptr [rbp + 0x20]
0x000143328c7c:  0f57c0                xorps     xmm0, xmm0
0x000143328c7f:  660f7f4520            movdqa    xmmword ptr [rbp + 0x20], xmm0
0x000143328c84:  488d0d1d879c03        lea       rcx, [rip + 0x39c871d]
0x000143328c8b:  48898db0020000        mov       qword ptr [rbp + 0x2b0], rcx
0x000143328c92:  660fd68db8020000      movq      qword ptr [rbp + 0x2b8], xmm1
0x000143328c9a:  660f73d908            psrldq    xmm1, 8
0x000143328c9f:  660fd68dc0020000      movq      qword ptr [rbp + 0x2c0], xmm1
0x000143328ca7:  488d8db0020000        lea       rcx, [rbp + 0x2b0]
0x000143328cae:  48898de8020000        mov       qword ptr [rbp + 0x2e8], rcx
0x000143328cb5:  488d95b0020000        lea       rdx, [rbp + 0x2b0]
0x000143328cbc:  488bcb                mov       rcx, rbx
0x000143328cbf:  488b4008              mov       rax, qword ptr [rax + 8]
0x000143328cc3:  ff156f70e102          call      qword ptr [rip + 0x2e1706f]
0x000143328cc9:  90                    nop       
0x000143328cca:  488b8de8020000        mov       rcx, qword ptr [rbp + 0x2e8]
0x000143328cd1:  4885c9                test      rcx, rcx
0x000143328cd4:  741b                  je        0x143328cf1
0x000143328cd6:  488b01                mov       rax, qword ptr [rcx]
0x000143328cd9:  488d95b0020000        lea       rdx, [rbp + 0x2b0]
0x000143328ce0:  483bca                cmp       rcx, rdx
0x000143328ce3:  0f95c2                setne     dl
0x000143328ce6:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x000143328cea:  ff154870e102          call      qword ptr [rip + 0x2e17048]
0x000143328cf0:  90                    nop       
0x000143328cf1:  4885ff                test      rdi, rdi
0x000143328cf4:  7409                  je        0x143328cff
0x000143328cf6:  488bcf                mov       rcx, rdi
0x000143328cf9:  e812024afd            call      0x1407c8f10
0x000143328cfe:  90                    nop       
0x000143328cff:  488b8578010000        mov       rax, qword ptr [rbp + 0x178]
0x000143328d06:  4883f810              cmp       rax, 0x10
0x000143328d0a:  7230                  jb        0x143328d3c
0x000143328d0c:  48ffc0                inc       rax
0x000143328d0f:  488b8d60010000        mov       rcx, qword ptr [rbp + 0x160]
0x000143328d16:  488bd1                mov       rdx, rcx
0x000143328d19:  483d00100000          cmp       rax, 0x1000
0x000143328d1f:  7215                  jb        0x143328d36
0x000143328d21:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143328d25:  482bd1                sub       rdx, rcx
0x000143328d28:  488d42f8              lea       rax, [rdx - 8]
0x000143328d2c:  4883f81f              cmp       rax, 0x1f
0x000143328d30:  0f87fd000000          ja        0x143328e33
0x000143328d36:  e875a36101            call      0x1449430b0
0x000143328d3b:  90                    nop       
0x000143328d3c:  4c89a570010000        mov       qword ptr [rbp + 0x170], r12
0x000143328d43:  48c785780100000f000000  mov       qword ptr [rbp + 0x178], 0xf
0x000143328d4e:  c6856001000000        mov       byte ptr [rbp + 0x160], 0
0x000143328d55:  488b4d98              mov       rcx, qword ptr [rbp - 0x68]
0x000143328d59:  4885c9                test      rcx, rcx
0x000143328d5c:  7406                  je        0x143328d64
0x000143328d5e:  e8ad014afd            call      0x1407c8f10
0x000143328d63:  90                    nop       
0x000143328d64:  488b4c2448            mov       rcx, qword ptr [rsp + 0x48]
0x000143328d69:  4885c9                test      rcx, rcx
0x000143328d6c:  7406                  je        0x143328d74
0x000143328d6e:  e89d014afd            call      0x1407c8f10
0x000143328d73:  90                    nop       
0x000143328d74:  488b8598010000        mov       rax, qword ptr [rbp + 0x198]
0x000143328d7b:  4883f810              cmp       rax, 0x10
0x000143328d7f:  722c                  jb        0x143328dad
0x000143328d81:  48ffc0                inc       rax
0x000143328d84:  488b8d80010000        mov       rcx, qword ptr [rbp + 0x180]
0x000143328d8b:  488bd1                mov       rdx, rcx
0x000143328d8e:  483d00100000          cmp       rax, 0x1000
0x000143328d94:  7211                  jb        0x143328da7
0x000143328d96:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143328d9a:  482bd1                sub       rdx, rcx
0x000143328d9d:  488d42f8              lea       rax, [rdx - 8]
0x000143328da1:  4883f81f              cmp       rax, 0x1f
0x000143328da5:  7736                  ja        0x143328ddd
0x000143328da7:  e804a36101            call      0x1449430b0
0x000143328dac:  90                    nop       
0x000143328dad:  488b8d30040000        mov       rcx, qword ptr [rbp + 0x430]
0x000143328db4:  4833cc                xor       rcx, rsp
0x000143328db7:  e824887f02            call      0x145b215e0
0x000143328dbc:  4c8d9c2440050000      lea       r11, [rsp + 0x540]
0x000143328dc4:  498b5b38              mov       rbx, qword ptr [r11 + 0x38]
0x000143328dc8:  498b7340              mov       rsi, qword ptr [r11 + 0x40]
0x000143328dcc:  498b7b48              mov       rdi, qword ptr [r11 + 0x48]
0x000143328dd0:  498be3                mov       rsp, r11
0x000143328dd3:  415f                  pop       r15
0x000143328dd5:  415e                  pop       r14
0x000143328dd7:  415d                  pop       r13
0x000143328dd9:  415c                  pop       r12
0x000143328ddb:  5d                    pop       rbp
0x000143328ddc:  c3                    ret       
0x000143328ddd:  e83e878202            call      0x145b51520
0x000143328de2:  90                    nop       
0x000143328de3:  488d151b530603        lea       rdx, [rip + 0x306531b]
0x000143328dea:  488d0d87d6d203        lea       rcx, [rip + 0x3d2d687]
0x000143328df1:  e8ca5e6301            call      0x14495ecc0
0x000143328df6:  90                    nop       
0x000143328df7:  e824878202            call      0x145b51520
0x000143328dfc:  cc                    int3      
0x000143328dfd:  e81e878202            call      0x145b51520
0x000143328e02:  90                    nop       
0x000143328e03:  e818878202            call      0x145b51520
0x000143328e08:  cc                    int3      
0x000143328e09:  e812878202            call      0x145b51520
0x000143328e0e:  cc                    int3      
0x000143328e0f:  e80c878202            call      0x145b51520
0x000143328e14:  90                    nop       
0x000143328e15:  e806878202            call      0x145b51520
0x000143328e1a:  90                    nop       
0x000143328e1b:  e800878202            call      0x145b51520
0x000143328e20:  cc                    int3      
0x000143328e21:  e8fa868202            call      0x145b51520
0x000143328e26:  90                    nop       
0x000143328e27:  e8f4868202            call      0x145b51520
0x000143328e2c:  90                    nop       
0x000143328e2d:  e8ee868202            call      0x145b51520
0x000143328e32:  90                    nop       
0x000143328e33:  e8e8868202            call      0x145b51520
0x000143328e38:  cc                    int3      
0x000143328e39:  cc                    int3      
0x000143328e3a:  cc                    int3      
0x000143328e3b:  cc                    int3      
0x000143328e3c:  cc                    int3      
0x000143328e3d:  cc                    int3      
0x000143328e3e:  cc                    int3      
0x000143328e3f:  cc                    int3      
0x000143328e40:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x000143328e45:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x000143328e4a:  55                    push      rbp
0x000143328e4b:  57                    push      rdi
0x000143328e4c:  4154                  push      r12
0x000143328e4e:  4156                  push      r14
0x000143328e50:  4157                  push      r15
0x000143328e52:  488dac2440fdffff      lea       rbp, [rsp - 0x2c0]
0x000143328e5a:  4881ecc0030000        sub       rsp, 0x3c0
0x000143328e61:  488b0588a89e04        mov       rax, qword ptr [rip + 0x49ea888]
0x000143328e68:  4833c4                xor       rax, rsp
0x000143328e6b:  488985b0020000        mov       qword ptr [rbp + 0x2b0], rax
0x000143328e72:  488bf1                mov       rsi, rcx
0x000143328e75:  33ff                  xor       edi, edi
0x000143328e77:  4c8d67ff              lea       r12, [rdi - 1]
0x000143328e7b:  488b0526f3a504        mov       rax, qword ptr [rip + 0x4a5f326]
0x000143328e82:  3c06                  cmp       al, 6
0x000143328e84:  727b                  jb        0x143328f01
0x000143328e86:  48c1e808              shr       rax, 8
0x000143328e8a:  3c04                  cmp       al, 4
0x000143328e8c:  7273                  jb        0x143328f01
0x000143328e8e:  488d051ced2204        lea       rax, [rip + 0x422ed1c]
0x000143328e95:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x000143328e9a:  488b4c2430            mov       rcx, qword ptr [rsp + 0x30]
0x000143328e9f:  488d0d4a09cb03        lea       rcx, [rip + 0x3cb094a]
0x000143328ea6:  48894db0              mov       qword ptr [rbp - 0x50], rcx
0x000143328eaa:  498bc4                mov       rax, r12
0x000143328ead:  0f1f00                nop       dword ptr [rax]
0x000143328eb0:  48ffc0                inc       rax
0x000143328eb3:  40383c01              cmp       byte ptr [rcx + rax], dil
0x000143328eb7:  75f7                  jne       0x143328eb0
0x000143328eb9:  488945b8              mov       qword ptr [rbp - 0x48], rax
0x000143328ebd:  48897da0              mov       qword ptr [rbp - 0x60], rdi
0x000143328ec1:  488d85f0010000        lea       rax, [rbp + 0x1f0]
0x000143328ec8:  488945a8              mov       qword ptr [rbp - 0x58], rax
0x000143328ecc:  0f2845a0              movaps    xmm0, xmmword ptr [rbp - 0x60]
0x000143328ed0:  660f7f4540            movdqa    xmmword ptr [rbp + 0x40], xmm0
0x000143328ed5:  0f284db0              movaps    xmm1, xmmword ptr [rbp - 0x50]
0x000143328ed9:  660f7f4d50            movdqa    xmmword ptr [rbp + 0x50], xmm1
0x000143328ede:  0f1005c3f2a504        movups    xmm0, xmmword ptr [rip + 0x4a5f2c3]
0x000143328ee5:  0f294560              movaps    xmmword ptr [rbp + 0x60], xmm0
0x000143328ee9:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x000143328eee:  4c8d4d40              lea       r9, [rbp + 0x40]
0x000143328ef2:  4c8d4550              lea       r8, [rbp + 0x50]
0x000143328ef6:  b204                  mov       dl, 4
0x000143328ef8:  488d4d60              lea       rcx, [rbp + 0x60]
0x000143328efc:  e8cf6b6301            call      0x14495fad0
0x000143328f01:  488d4c2470            lea       rcx, [rsp + 0x70]
0x000143328f06:  e8f5ea6101            call      0x144947a00
0x000143328f0b:  f20f10442470          movsd     xmm0, qword ptr [rsp + 0x70]
0x000143328f11:  f20f118600010000      movsd     qword ptr [rsi + 0x100], xmm0
0x000143328f19:  4889bd10010000        mov       qword ptr [rbp + 0x110], rdi
0x000143328f20:  4889bd20010000        mov       qword ptr [rbp + 0x120], rdi
0x000143328f27:  48c785280100000f000000  mov       qword ptr [rbp + 0x128], 0xf
0x000143328f32:  4088bd10010000        mov       byte ptr [rbp + 0x110], dil
0x000143328f39:  8b0571f0a504          mov       eax, dword ptr [rip + 0x4a5f071]
0x000143328f3f:  85c0                  test      eax, eax
0x000143328f41:  0f8eb1010000          jle       0x1433290f8
0x000143328f47:  3b053bf1a504          cmp       eax, dword ptr [rip + 0x4a5f13b]
0x000143328f4d:  0f8fa5010000          jg        0x1433290f8
0x000143328f53:  488d05ab510603        lea       rax, [rip + 0x30651ab]
0x000143328f5a:  488945c0              mov       qword ptr [rbp - 0x40], rax
0x000143328f5e:  48897dc8              mov       qword ptr [rbp - 0x38], rdi
0x000143328f62:  488945d0              mov       qword ptr [rbp - 0x30], rax
0x000143328f66:  48897dd8              mov       qword ptr [rbp - 0x28], rdi
0x000143328f6a:  488d054f08cb03        lea       rax, [rip + 0x3cb084f]
0x000143328f71:  488945e0              mov       qword ptr [rbp - 0x20], rax
0x000143328f75:  48c745e828000000      mov       qword ptr [rbp - 0x18], 0x28
0x000143328f7d:  488d05340dcb03        lea       rax, [rip + 0x3cb0d34]
0x000143328f84:  488945f0              mov       qword ptr [rbp - 0x10], rax
0x000143328f88:  48c745f812000000      mov       qword ptr [rbp - 8], 0x12
0x000143328f90:  488d05cd1db203        lea       rax, [rip + 0x3b21dcd]
0x000143328f97:  48894500              mov       qword ptr [rbp], rax
0x000143328f9b:  48c7450804000000      mov       qword ptr [rbp + 8], 4
0x000143328fa3:  0f2845c0              movaps    xmm0, xmmword ptr [rbp - 0x40]
0x000143328fa7:  660f7f4570            movdqa    xmmword ptr [rbp + 0x70], xmm0
0x000143328fac:  0f284dd0              movaps    xmm1, xmmword ptr [rbp - 0x30]
0x000143328fb0:  660f7f8d80000000      movdqa    xmmword ptr [rbp + 0x80], xmm1
0x000143328fb8:  0f2845e0              movaps    xmm0, xmmword ptr [rbp - 0x20]
0x000143328fbc:  660f7f8590000000      movdqa    xmmword ptr [rbp + 0x90], xmm0
0x000143328fc4:  0f284df0              movaps    xmm1, xmmword ptr [rbp - 0x10]
0x000143328fc8:  660f7f8da0000000      movdqa    xmmword ptr [rbp + 0xa0], xmm1
0x000143328fd0:  0f284500              movaps    xmm0, xmmword ptr [rbp]
0x000143328fd4:  660f7f85b0000000      movdqa    xmmword ptr [rbp + 0xb0], xmm0
0x000143328fdc:  488d4570              lea       rax, [rbp + 0x70]
0x000143328fe0:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x000143328fe5:  488d8580000000        lea       rax, [rbp + 0x80]
0x000143328fec:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000143328ff1:  4c8d8d90000000        lea       r9, [rbp + 0x90]
0x000143328ff8:  4c8d85a0000000        lea       r8, [rbp + 0xa0]
0x000143328fff:  488d95b0000000        lea       rdx, [rbp + 0xb0]
0x000143329006:  488d8d00020000        lea       rcx, [rbp + 0x200]
0x00014332900d:  e8feb66fff            call      0x142a24710
0x000143329012:  90                    nop       
0x000143329013:  488d9570010000        lea       rdx, [rbp + 0x170]
0x00014332901a:  488bc8                mov       rcx, rax
0x00014332901d:  e87ec26fff            call      0x142a252a0
0x000143329022:  488bd8                mov       rbx, rax
0x000143329025:  488d8510010000        lea       rax, [rbp + 0x110]
0x00014332902c:  483bc3                cmp       rax, rbx
0x00014332902f:  7430                  je        0x143329061
0x000143329031:  488d8d10010000        lea       rcx, [rbp + 0x110]
0x000143329038:  e8a3c94bfd            call      0x1407e59e0
0x00014332903d:  0f1003                movups    xmm0, xmmword ptr [rbx]
0x000143329040:  0f118510010000        movups    xmmword ptr [rbp + 0x110], xmm0
0x000143329047:  0f104b10              movups    xmm1, xmmword ptr [rbx + 0x10]
0x00014332904b:  0f118d20010000        movups    xmmword ptr [rbp + 0x120], xmm1
0x000143329052:  48897b10              mov       qword ptr [rbx + 0x10], rdi
0x000143329056:  48c743180f000000      mov       qword ptr [rbx + 0x18], 0xf
0x00014332905e:  c60300                mov       byte ptr [rbx], 0
0x000143329061:  488b8588010000        mov       rax, qword ptr [rbp + 0x188]
0x000143329068:  4883f810              cmp       rax, 0x10
0x00014332906c:  7230                  jb        0x14332909e
0x00014332906e:  48ffc0                inc       rax
0x000143329071:  488b8d70010000        mov       rcx, qword ptr [rbp + 0x170]
0x000143329078:  488bd1                mov       rdx, rcx
0x00014332907b:  483d00100000          cmp       rax, 0x1000
0x000143329081:  7215                  jb        0x143329098
0x000143329083:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143329087:  482bd1                sub       rdx, rcx
0x00014332908a:  488d42f8              lea       rax, [rdx - 8]
0x00014332908e:  4883f81f              cmp       rax, 0x1f
0x000143329092:  0f8759040000          ja        0x1433294f1
0x000143329098:  e813a06101            call      0x1449430b0
0x00014332909d:  90                    nop       
0x00014332909e:  4889bd80010000        mov       qword ptr [rbp + 0x180], rdi
0x0001433290a5:  48c785880100000f000000  mov       qword ptr [rbp + 0x188], 0xf
0x0001433290b0:  c6857001000000        mov       byte ptr [rbp + 0x170], 0
0x0001433290b7:  488d8d80020000        lea       rcx, [rbp + 0x280]
0x0001433290be:  e81dc94bfd            call      0x1407e59e0
0x0001433290c3:  488d8d60020000        lea       rcx, [rbp + 0x260]
0x0001433290ca:  e811c94bfd            call      0x1407e59e0
0x0001433290cf:  488d8d40020000        lea       rcx, [rbp + 0x240]
0x0001433290d6:  e805c94bfd            call      0x1407e59e0
0x0001433290db:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x0001433290e2:  e8f9c84bfd            call      0x1407e59e0
0x0001433290e7:  488d8d00020000        lea       rcx, [rbp + 0x200]
0x0001433290ee:  e8edc84bfd            call      0x1407e59e0
0x0001433290f3:  e995000000            jmp       0x14332918d
0x0001433290f8:  0fb69edd000000        movzx     ebx, byte ptr [rsi + 0xdd]
0x0001433290ff:  488d96b8000000        lea       rdx, [rsi + 0xb8]
0x000143329106:  488d8df0000000        lea       rcx, [rbp + 0xf0]
0x00014332910d:  e84eae4bfd            call      0x1407e3f60
0x000143329112:  440fb6c3              movzx     r8d, bl
0x000143329116:  488bd0                mov       rdx, rax
0x000143329119:  488d8dd0010000        lea       rcx, [rbp + 0x1d0]
0x000143329120:  e8dbe7e5fd            call      0x141187900
0x000143329125:  90                    nop       
0x000143329126:  488d8d10010000        lea       rcx, [rbp + 0x110]
0x00014332912d:  483bc8                cmp       rcx, rax
0x000143329130:  741e                  je        0x143329150
0x000143329132:  4c8b4010              mov       r8, qword ptr [rax + 0x10]
0x000143329136:  4883781810            cmp       qword ptr [rax + 0x18], 0x10
0x00014332913b:  7203                  jb        0x143329140
0x00014332913d:  488b00                mov       rax, qword ptr [rax]
0x000143329140:  488bd0                mov       rdx, rax
0x000143329143:  488d8d10010000        lea       rcx, [rbp + 0x110]
0x00014332914a:  e801a94bfd            call      0x1407e3a50
0x00014332914f:  90                    nop       
0x000143329150:  488b85e8010000        mov       rax, qword ptr [rbp + 0x1e8]
0x000143329157:  4883f810              cmp       rax, 0x10
0x00014332915b:  7230                  jb        0x14332918d
0x00014332915d:  48ffc0                inc       rax
0x000143329160:  488b8dd0010000        mov       rcx, qword ptr [rbp + 0x1d0]
0x000143329167:  488bd1                mov       rdx, rcx
0x00014332916a:  483d00100000          cmp       rax, 0x1000
0x000143329170:  7215                  jb        0x143329187
0x000143329172:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143329176:  482bd1                sub       rdx, rcx
0x000143329179:  488d42f8              lea       rax, [rdx - 8]
0x00014332917d:  4883f81f              cmp       rax, 0x1f
0x000143329181:  0f8770030000          ja        0x1433294f7
0x000143329187:  e8249f6101            call      0x1449430b0
0x00014332918c:  90                    nop       
0x00014332918d:  488bd6                mov       rdx, rsi
0x000143329190:  488d4c2460            lea       rcx, [rsp + 0x60]
0x000143329195:  e8e65213fe            call      0x14145e480
0x00014332919a:  90                    nop       
0x00014332919b:  33d2                  xor       edx, edx
0x00014332919d:  488d4c2440            lea       rcx, [rsp + 0x40]
0x0001433291a2:  e809e998ff            call      0x142cb7ab0
0x0001433291a7:  90                    nop       
0x0001433291a8:  0fb68edd000000        movzx     ecx, byte ptr [rsi + 0xdd]
0x0001433291af:  488d442450            lea       rax, [rsp + 0x50]
0x0001433291b4:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x0001433291b9:  0f57c0                xorps     xmm0, xmm0
0x0001433291bc:  f30f7f442450          movdqu    xmmword ptr [rsp + 0x50], xmm0
0x0001433291c2:  488b4650              mov       rax, qword ptr [rsi + 0x50]
0x0001433291c6:  4885c0                test      rax, rax
0x0001433291c9:  7404                  je        0x1433291cf
0x0001433291cb:  f0ff4008              lock inc  dword ptr [rax + 8]
0x0001433291cf:  488b4648              mov       rax, qword ptr [rsi + 0x48]
0x0001433291d3:  4889442450            mov       qword ptr [rsp + 0x50], rax
0x0001433291d8:  488b4650              mov       rax, qword ptr [rsi + 0x50]
0x0001433291dc:  4889442458            mov       qword ptr [rsp + 0x58], rax
0x0001433291e1:  4889bd30010000        mov       qword ptr [rbp + 0x130], rdi
0x0001433291e8:  48c785480100000f000000  mov       qword ptr [rbp + 0x148], 0xf
0x0001433291f3:  48c7854001000004000000  mov       qword ptr [rbp + 0x140], 4
0x0001433291fe:  c78530010000504f5354  mov       dword ptr [rbp + 0x130], 0x54534f50
0x000143329208:  c6853401000000        mov       byte ptr [rbp + 0x134], 0
0x00014332920f:  660f7f4580            movdqa    xmmword ptr [rbp - 0x80], xmm0
0x000143329214:  4c8b742448            mov       r14, qword ptr [rsp + 0x48]
0x000143329219:  4d85f6                test      r14, r14
0x00014332921c:  740a                  je        0x143329228
0x00014332921e:  f041ff4608            lock inc  dword ptr [r14 + 8]
0x000143329223:  4c8b742448            mov       r14, qword ptr [rsp + 0x48]
0x000143329228:  0f28442440            movaps    xmm0, xmmword ptr [rsp + 0x40]
0x00014332922d:  660f7f4580            movdqa    xmmword ptr [rbp - 0x80], xmm0
0x000143329232:  884c2420              mov       byte ptr [rsp + 0x20], cl
0x000143329236:  4c8d4c2450            lea       r9, [rsp + 0x50]
0x00014332923b:  4c8d8510010000        lea       r8, [rbp + 0x110]
0x000143329242:  488d9530010000        lea       rdx, [rbp + 0x130]
0x000143329249:  488d4d80              lea       rcx, [rbp - 0x80]
0x00014332924d:  e8ae61ffff            call      0x14331f400
0x000143329252:  90                    nop       
0x000143329253:  488b8548010000        mov       rax, qword ptr [rbp + 0x148]
0x00014332925a:  4883f810              cmp       rax, 0x10
0x00014332925e:  7230                  jb        0x143329290
0x000143329260:  48ffc0                inc       rax
0x000143329263:  488b8d30010000        mov       rcx, qword ptr [rbp + 0x130]
0x00014332926a:  488bd1                mov       rdx, rcx
0x00014332926d:  483d00100000          cmp       rax, 0x1000
0x000143329273:  7215                  jb        0x14332928a
0x000143329275:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143329279:  482bd1                sub       rdx, rcx
0x00014332927c:  488d42f8              lea       rax, [rdx - 8]
0x000143329280:  4883f81f              cmp       rax, 0x1f
0x000143329284:  0f8773020000          ja        0x1433294fd
0x00014332928a:  e8219e6101            call      0x1449430b0
0x00014332928f:  90                    nop       
0x000143329290:  488b4648              mov       rax, qword ptr [rsi + 0x48]
0x000143329294:  4c8b7c2440            mov       r15, qword ptr [rsp + 0x40]
0x000143329299:  4885c0                test      rax, rax
0x00014332929c:  7478                  je        0x143329316
0x00014332929e:  80bedd00000000        cmp       byte ptr [rsi + 0xdd], 0
0x0001433292a5:  746f                  je        0x143329316
0x0001433292a7:  803d1aea230500        cmp       byte ptr [rip + 0x523ea1a], 0
0x0001433292ae:  7466                  je        0x143329316
0x0001433292b0:  803d31f1230500        cmp       byte ptr [rip + 0x523f131], 0
0x0001433292b7:  745d                  je        0x143329316
0x0001433292b9:  4805e8040000          add       rax, 0x4e8
0x0001433292bf:  488b4810              mov       rcx, qword ptr [rax + 0x10]
0x0001433292c3:  4883781810            cmp       qword ptr [rax + 0x18], 0x10
0x0001433292c8:  7203                  jb        0x1433292cd
0x0001433292ca:  488b00                mov       rax, qword ptr [rax]
0x0001433292cd:  48894510              mov       qword ptr [rbp + 0x10], rax
0x0001433292d1:  48894d18              mov       qword ptr [rbp + 0x18], rcx
0x0001433292d5:  488d05d47bb303        lea       rax, [rip + 0x3b37bd4]
0x0001433292dc:  48894520              mov       qword ptr [rbp + 0x20], rax
0x0001433292e0:  48c745281a000000      mov       qword ptr [rbp + 0x28], 0x1a
0x0001433292e8:  0f284510              movaps    xmm0, xmmword ptr [rbp + 0x10]
0x0001433292ec:  660f7f85c0000000      movdqa    xmmword ptr [rbp + 0xc0], xmm0
0x0001433292f4:  0f284d20              movaps    xmm1, xmmword ptr [rbp + 0x20]
0x0001433292f8:  660f7f8dd0000000      movdqa    xmmword ptr [rbp + 0xd0], xmm1
0x000143329300:  4c8d85c0000000        lea       r8, [rbp + 0xc0]
0x000143329307:  488d95d0000000        lea       rdx, [rbp + 0xd0]
0x00014332930e:  498bcf                mov       rcx, r15
0x000143329311:  e84a0399ff            call      0x142cb9660
0x000143329316:  4889bd50010000        mov       qword ptr [rbp + 0x150], rdi
0x00014332931d:  48c785680100000f000000  mov       qword ptr [rbp + 0x168], 0xf
0x000143329328:  48c7856001000002000000  mov       qword ptr [rbp + 0x160], 2
0x000143329333:  b87b7d0000            mov       eax, 0x7d7b
0x000143329338:  66898550010000        mov       word ptr [rbp + 0x150], ax
0x00014332933f:  c6855201000000        mov       byte ptr [rbp + 0x152], 0
0x000143329346:  488d8550010000        lea       rax, [rbp + 0x150]
0x00014332934d:  48894530              mov       qword ptr [rbp + 0x30], rax
0x000143329351:  48c7453802000000      mov       qword ptr [rbp + 0x38], 2
0x000143329359:  0f284530              movaps    xmm0, xmmword ptr [rbp + 0x30]
0x00014332935d:  660f7f85e0000000      movdqa    xmmword ptr [rbp + 0xe0], xmm0
0x000143329365:  4533c0                xor       r8d, r8d
0x000143329368:  488d95e0000000        lea       rdx, [rbp + 0xe0]
0x00014332936f:  498bcf                mov       rcx, r15
0x000143329372:  e8d90d99ff            call      0x142cba150
0x000143329377:  90                    nop       
0x000143329378:  488b8568010000        mov       rax, qword ptr [rbp + 0x168]
0x00014332937f:  4883f810              cmp       rax, 0x10
0x000143329383:  7230                  jb        0x1433293b5
0x000143329385:  48ffc0                inc       rax
0x000143329388:  488b8d50010000        mov       rcx, qword ptr [rbp + 0x150]
0x00014332938f:  488bd1                mov       rdx, rcx
0x000143329392:  483d00100000          cmp       rax, 0x1000
0x000143329398:  7215                  jb        0x1433293af
0x00014332939a:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014332939e:  482bd1                sub       rdx, rcx
0x0001433293a1:  488d42f8              lea       rax, [rdx - 8]
0x0001433293a5:  4883f81f              cmp       rax, 0x1f
0x0001433293a9:  0f8754010000          ja        0x143329503
0x0001433293af:  e8fc9c6101            call      0x1449430b0
0x0001433293b4:  90                    nop       
0x0001433293b5:  498b07                mov       rax, qword ptr [r15]
0x0001433293b8:  4c8b4008              mov       r8, qword ptr [rax + 8]
0x0001433293bc:  48897d90              mov       qword ptr [rbp - 0x70], rdi
0x0001433293c0:  488bc7                mov       rax, rdi
0x0001433293c3:  488b5c2468            mov       rbx, qword ptr [rsp + 0x68]
0x0001433293c8:  4885db                test      rbx, rbx
0x0001433293cb:  7423                  je        0x1433293f0
0x0001433293cd:  488b442460            mov       rax, qword ptr [rsp + 0x60]
0x0001433293d2:  48894590              mov       qword ptr [rbp - 0x70], rax
0x0001433293d6:  f0ff430c              lock inc  dword ptr [rbx + 0xc]
0x0001433293da:  488b5c2468            mov       rbx, qword ptr [rsp + 0x68]
0x0001433293df:  488bc3                mov       rax, rbx
0x0001433293e2:  4c8b742448            mov       r14, qword ptr [rsp + 0x48]
0x0001433293e7:  4c8b7c2440            mov       r15, qword ptr [rsp + 0x40]
0x0001433293ec:  488b7d90              mov       rdi, qword ptr [rbp - 0x70]
0x0001433293f0:  488d0d417f9c03        lea       rcx, [rip + 0x39c7f41]
0x0001433293f7:  48898d90010000        mov       qword ptr [rbp + 0x190], rcx
0x0001433293fe:  4889bd98010000        mov       qword ptr [rbp + 0x198], rdi
0x000143329405:  488985a0010000        mov       qword ptr [rbp + 0x1a0], rax
0x00014332940c:  488d8590010000        lea       rax, [rbp + 0x190]
0x000143329413:  488985c8010000        mov       qword ptr [rbp + 0x1c8], rax
0x00014332941a:  488d9590010000        lea       rdx, [rbp + 0x190]
0x000143329421:  498bcf                mov       rcx, r15
0x000143329424:  498bc0                mov       rax, r8
0x000143329427:  ff150b69e102          call      qword ptr [rip + 0x2e1690b]
0x00014332942d:  90                    nop       
0x00014332942e:  488b8dc8010000        mov       rcx, qword ptr [rbp + 0x1c8]
0x000143329435:  4885c9                test      rcx, rcx
0x000143329438:  741b                  je        0x143329455
0x00014332943a:  488b01                mov       rax, qword ptr [rcx]
0x00014332943d:  488d9590010000        lea       rdx, [rbp + 0x190]
0x000143329444:  483bca                cmp       rcx, rdx
0x000143329447:  0f95c2                setne     dl
0x00014332944a:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x00014332944e:  ff15e468e102          call      qword ptr [rip + 0x2e168e4]
0x000143329454:  90                    nop       
0x000143329455:  4d85f6                test      r14, r14
0x000143329458:  7409                  je        0x143329463
0x00014332945a:  498bce                mov       rcx, r14
0x00014332945d:  e8aefa49fd            call      0x1407c8f10
0x000143329462:  90                    nop       
0x000143329463:  4885db                test      rbx, rbx
0x000143329466:  741f                  je        0x143329487
0x000143329468:  f0440fc1630c          lock xadd dword ptr [rbx + 0xc], r12d
0x00014332946e:  4183fc01              cmp       r12d, 1
0x000143329472:  7513                  jne       0x143329487
0x000143329474:  488b4c2468            mov       rcx, qword ptr [rsp + 0x68]
0x000143329479:  488b01                mov       rax, qword ptr [rcx]
0x00014332947c:  488b4008              mov       rax, qword ptr [rax + 8]
0x000143329480:  ff15b268e102          call      qword ptr [rip + 0x2e168b2]
0x000143329486:  90                    nop       
0x000143329487:  488b8528010000        mov       rax, qword ptr [rbp + 0x128]
0x00014332948e:  4883f810              cmp       rax, 0x10
0x000143329492:  722c                  jb        0x1433294c0
0x000143329494:  48ffc0                inc       rax
0x000143329497:  488b8d10010000        mov       rcx, qword ptr [rbp + 0x110]
0x00014332949e:  488bd1                mov       rdx, rcx
0x0001433294a1:  483d00100000          cmp       rax, 0x1000
0x0001433294a7:  7211                  jb        0x1433294ba
0x0001433294a9:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x0001433294ad:  482bd1                sub       rdx, rcx
0x0001433294b0:  488d42f8              lea       rax, [rdx - 8]
0x0001433294b4:  4883f81f              cmp       rax, 0x1f
0x0001433294b8:  7731                  ja        0x1433294eb
0x0001433294ba:  e8f19b6101            call      0x1449430b0
0x0001433294bf:  90                    nop       
0x0001433294c0:  488b8db0020000        mov       rcx, qword ptr [rbp + 0x2b0]
0x0001433294c7:  4833cc                xor       rcx, rsp
0x0001433294ca:  e811817f02            call      0x145b215e0
0x0001433294cf:  4c8d9c24c0030000      lea       r11, [rsp + 0x3c0]
0x0001433294d7:  498b5b38              mov       rbx, qword ptr [r11 + 0x38]
0x0001433294db:  498b7340              mov       rsi, qword ptr [r11 + 0x40]
0x0001433294df:  498be3                mov       rsp, r11
0x0001433294e2:  415f                  pop       r15
0x0001433294e4:  415e                  pop       r14
0x0001433294e6:  415c                  pop       r12
0x0001433294e8:  5f                    pop       rdi
0x0001433294e9:  5d                    pop       rbp
0x0001433294ea:  c3                    ret       
0x0001433294eb:  e830808202            call      0x145b51520
0x0001433294f0:  90                    nop       
0x0001433294f1:  e82a808202            call      0x145b51520
0x0001433294f6:  90                    nop       
0x0001433294f7:  e824808202            call      0x145b51520
0x0001433294fc:  90                    nop       
0x0001433294fd:  e81e808202            call      0x145b51520
0x000143329502:  cc                    int3      
0x000143329503:  e818808202            call      0x145b51520
0x000143329508:  cc                    int3      
0x000143329509:  cc                    int3      
0x00014332950a:  cc                    int3      
0x00014332950b:  cc                    int3      
0x00014332950c:  cc                    int3      
0x00014332950d:  cc                    int3      
0x00014332950e:  cc                    int3      
0x00014332950f:  cc                    int3      
0x000143329510:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000143329515:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x00014332951a:  55                    push      rbp
0x00014332951b:  57                    push      rdi
0x00014332951c:  4156                  push      r14
0x00014332951e:  488d6c24b9            lea       rbp, [rsp - 0x47]
0x000143329523:  4881ece0000000        sub       rsp, 0xe0
0x00014332952a:  488b05bfa19e04        mov       rax, qword ptr [rip + 0x49ea1bf]
0x000143329531:  4833c4                xor       rax, rsp
0x000143329534:  48894537              mov       qword ptr [rbp + 0x37], rax
0x000143329538:  4d8bf0                mov       r14, r8
0x00014332953b:  8bf2                  mov       esi, edx
0x00014332953d:  488bf9                mov       rdi, rcx
0x000143329540:  0f57c0                xorps     xmm0, xmm0
0x000143329543:  f30f7f459f            movdqu    xmmword ptr [rbp - 0x61], xmm0
0x000143329548:  488b5108              mov       rdx, qword ptr [rcx + 8]
0x00014332954c:  4885d2                test      rdx, rdx
0x00014332954f:  740f                  je        0x143329560
0x000143329551:  488b01                mov       rax, qword ptr [rcx]
0x000143329554:  4889459f              mov       qword ptr [rbp - 0x61], rax
0x000143329558:  488955a7              mov       qword ptr [rbp - 0x59], rdx
0x00014332955c:  f0ff420c              lock inc  dword ptr [rdx + 0xc]
0x000143329560:  4c8d05c1fcca03        lea       r8, [rip + 0x3cafcc1]
0x000143329567:  488d559f              lea       rdx, [rbp - 0x61]
0x00014332956b:  488d4dc7              lea       rcx, [rbp - 0x39]
0x00014332956f:  e84c75ffff            call      0x143320ac0
0x000143329574:  90                    nop       
0x000143329575:  488b5dc7              mov       rbx, qword ptr [rbp - 0x39]
0x000143329579:  4885db                test      rbx, rbx
0x00014332957c:  0f840a010000          je        0x14332968c
0x000143329582:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x000143329587:  4c8d0d9afcca03        lea       r9, [rip + 0x3cafc9a]
0x00014332958e:  4d8bc6                mov       r8, r14
0x000143329591:  8bd6                  mov       edx, esi
0x000143329593:  488bcb                mov       rcx, rbx
0x000143329596:  e8b57dffff            call      0x143321350
0x00014332959b:  84c0                  test      al, al
0x00014332959d:  0f84e9000000          je        0x14332968c
0x0001433295a3:  488d4d97              lea       rcx, [rbp - 0x69]
0x0001433295a7:  e854e46101            call      0x144947a00
0x0001433295ac:  f20f104597            movsd     xmm0, qword ptr [rbp - 0x69]
0x0001433295b1:  f20f5c8300010000      subsd     xmm0, qword ptr [rbx + 0x100]
0x0001433295b9:  f20f590577fae903      mulsd     xmm0, qword ptr [rip + 0x3e9fa77]
0x0001433295c1:  f20f2cc0              cvttsd2si eax, xmm0
0x0001433295c5:  898320010000          mov       dword ptr [rbx + 0x120], eax
0x0001433295cb:  660f6ec8              movd      xmm1, eax
0x0001433295cf:  f30fe6c9              cvtdq2pd  xmm1, xmm1
0x0001433295d3:  48c7452f0f000000      mov       qword ptr [rbp + 0x2f], 0xf
0x0001433295db:  48c7452708000000      mov       qword ptr [rbp + 0x27], 8
0x0001433295e3:  48b846696e616c697a65  movabs    rax, 0x657a696c616e6946
0x0001433295ed:  48894517              mov       qword ptr [rbp + 0x17], rax
0x0001433295f1:  c6451f00              mov       byte ptr [rbp + 0x1f], 0
0x0001433295f5:  440fb683dd000000      movzx     r8d, byte ptr [rbx + 0xdd]
0x0001433295fd:  488d4d17              lea       rcx, [rbp + 0x17]
0x000143329601:  e8ba5bffff            call      0x14331f1c0
0x000143329606:  90                    nop       
0x000143329607:  488b452f              mov       rax, qword ptr [rbp + 0x2f]
0x00014332960b:  4883f810              cmp       rax, 0x10
0x00014332960f:  722d                  jb        0x14332963e
0x000143329611:  48ffc0                inc       rax
0x000143329614:  488b4d17              mov       rcx, qword ptr [rbp + 0x17]
0x000143329618:  488bd1                mov       rdx, rcx
0x00014332961b:  483d00100000          cmp       rax, 0x1000
0x000143329621:  7215                  jb        0x143329638
0x000143329623:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143329627:  482bd1                sub       rdx, rcx
0x00014332962a:  488d42f8              lea       rax, [rdx - 8]
0x00014332962e:  4883f81f              cmp       rax, 0x1f
0x000143329632:  0f8786000000          ja        0x1433296be
0x000143329638:  e8739a6101            call      0x1449430b0
0x00014332963d:  90                    nop       
0x00014332963e:  4c8b4b38              mov       r9, qword ptr [rbx + 0x38]
0x000143329642:  33c9                  xor       ecx, ecx
0x000143329644:  488b4708              mov       rax, qword ptr [rdi + 8]
0x000143329648:  8bd1                  mov       edx, ecx
0x00014332964a:  4885c0                test      rax, rax
0x00014332964d:  740f                  je        0x14332965e
0x00014332964f:  488b17                mov       rdx, qword ptr [rdi]
0x000143329652:  488945bf              mov       qword ptr [rbp - 0x41], rax
0x000143329656:  f0ff400c              lock inc  dword ptr [rax + 0xc]
0x00014332965a:  488b4dbf              mov       rcx, qword ptr [rbp - 0x41]
0x00014332965e:  488d057b7d9c03        lea       rax, [rip + 0x39c7d7b]
0x000143329665:  488945d7              mov       qword ptr [rbp - 0x29], rax
0x000143329669:  488955df              mov       qword ptr [rbp - 0x21], rdx
0x00014332966d:  48894de7              mov       qword ptr [rbp - 0x19], rcx
0x000143329671:  488d45d7              lea       rax, [rbp - 0x29]
0x000143329675:  4889450f              mov       qword ptr [rbp + 0xf], rax
0x000143329679:  41b801000000          mov       r8d, 1
0x00014332967f:  488d55d7              lea       rdx, [rbp - 0x29]
0x000143329683:  498bc9                mov       rcx, r9
0x000143329686:  e8e508df00            call      0x144119f70
0x00014332968b:  90                    nop       
0x00014332968c:  488b4dcf              mov       rcx, qword ptr [rbp - 0x31]
0x000143329690:  4885c9                test      rcx, rcx
0x000143329693:  7405                  je        0x14332969a
0x000143329695:  e876f849fd            call      0x1407c8f10
0x00014332969a:  488b4d37              mov       rcx, qword ptr [rbp + 0x37]
0x00014332969e:  4833cc                xor       rcx, rsp
0x0001433296a1:  e83a7f7f02            call      0x145b215e0
0x0001433296a6:  4c8d9c24e0000000      lea       r11, [rsp + 0xe0]
0x0001433296ae:  498b5b20              mov       rbx, qword ptr [r11 + 0x20]
0x0001433296b2:  498b7338              mov       rsi, qword ptr [r11 + 0x38]
0x0001433296b6:  498be3                mov       rsp, r11
0x0001433296b9:  415e                  pop       r14
0x0001433296bb:  5f                    pop       rdi
0x0001433296bc:  5d                    pop       rbp
0x0001433296bd:  c3                    ret       
0x0001433296be:  e85d7e8202            call      0x145b51520
0x0001433296c3:  90                    nop       
0x0001433296c4:  cc                    int3      
0x0001433296c5:  cc                    int3      
0x0001433296c6:  cc                    int3      
0x0001433296c7:  cc                    int3      
0x0001433296c8:  cc                    int3      
0x0001433296c9:  cc                    int3      
0x0001433296ca:  cc                    int3      
0x0001433296cb:  cc                    int3      
0x0001433296cc:  cc                    int3      
0x0001433296cd:  cc                    int3      
0x0001433296ce:  cc                    int3      
0x0001433296cf:  cc                    int3      
0x0001433296d0:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x0001433296d5:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x0001433296da:  48897c2420            mov       qword ptr [rsp + 0x20], rdi
0x0001433296df:  55                    push      rbp
0x0001433296e0:  488d6c24a9            lea       rbp, [rsp - 0x57]
0x0001433296e5:  4881eca0000000        sub       rsp, 0xa0
0x0001433296ec:  488b05fd9f9e04        mov       rax, qword ptr [rip + 0x49e9ffd]
0x0001433296f3:  4833c4                xor       rax, rsp
0x0001433296f6:  4889454f              mov       qword ptr [rbp + 0x4f], rax
0x0001433296fa:  488bf9                mov       rdi, rcx
0x0001433296fd:  0f57c0                xorps     xmm0, xmm0
0x000143329700:  f30f7f45d7            movdqu    xmmword ptr [rbp - 0x29], xmm0
0x000143329705:  488b5108              mov       rdx, qword ptr [rcx + 8]
0x000143329709:  4885d2                test      rdx, rdx
0x00014332970c:  7424                  je        0x143329732
0x00014332970e:  8b4208                mov       eax, dword ptr [rdx + 8]
0x000143329711:  85c0                  test      eax, eax
0x000143329713:  741d                  je        0x143329732
0x000143329715:  6666660f1f840000000000  nop       word ptr [rax + rax]
0x000143329720:  8d4801                lea       ecx, [rax + 1]
0x000143329723:  f00fb14a08            lock cmpxchg dword ptr [rdx + 8], ecx
0x000143329728:  0f8445020000          je        0x143329973
0x00014332972e:  85c0                  test      eax, eax
0x000143329730:  75ee                  jne       0x143329720
0x000143329732:  488b5dd7              mov       rbx, qword ptr [rbp - 0x29]
0x000143329736:  488b7ddf              mov       rdi, qword ptr [rbp - 0x21]
0x00014332973a:  4885db                test      rbx, rbx
0x00014332973d:  0f84fe010000          je        0x143329941
0x000143329743:  80bbdd00000000        cmp       byte ptr [rbx + 0xdd], 0
0x00014332974a:  7433                  je        0x14332977f
0x00014332974c:  80bbde00000000        cmp       byte ptr [rbx + 0xde], 0
0x000143329753:  752a                  jne       0x14332977f
0x000143329755:  80bbdf00000000        cmp       byte ptr [rbx + 0xdf], 0
0x00014332975c:  7521                  jne       0x14332977f
0x00014332975e:  488bcb                mov       rcx, rbx
0x000143329761:  e8bae5ffff            call      0x143327d20
0x000143329766:  84c0                  test      al, al
0x000143329768:  0f8419020000          je        0x143329987
0x00014332976e:  488d4b10              lea       rcx, [rbx + 0x10]
0x000143329772:  e8690e4ffd            call      0x14081a5e0
0x000143329777:  488bcb                mov       rcx, rbx
0x00014332977a:  e8a1e9ffff            call      0x143328120
0x00014332977f:  488d4b18              lea       rcx, [rbx + 0x18]
0x000143329783:  e8580e4ffd            call      0x14081a5e0
0x000143329788:  488d4de7              lea       rcx, [rbp - 0x19]
0x00014332978c:  e86fe26101            call      0x144947a00
0x000143329791:  f20f1045e7            movsd     xmm0, qword ptr [rbp - 0x19]
0x000143329796:  f20f5c83f8000000      subsd     xmm0, qword ptr [rbx + 0xf8]
0x00014332979e:  f20f590592f8e903      mulsd     xmm0, qword ptr [rip + 0x3e9f892]
0x0001433297a6:  f20f2cc8              cvttsd2si ecx, xmm0
0x0001433297aa:  8bf1                  mov       esi, ecx
0x0001433297ac:  2bb320010000          sub       esi, dword ptr [rbx + 0x120]
0x0001433297b2:  2bb314010000          sub       esi, dword ptr [rbx + 0x114]
0x0001433297b8:  2bb310010000          sub       esi, dword ptr [rbx + 0x110]
0x0001433297be:  2bb30c010000          sub       esi, dword ptr [rbx + 0x10c]
0x0001433297c4:  2bb308010000          sub       esi, dword ptr [rbx + 0x108]
0x0001433297ca:  48c7450f00000000      mov       qword ptr [rbp + 0xf], 0
0x0001433297d2:  48c745270f000000      mov       qword ptr [rbp + 0x27], 0xf
0x0001433297da:  48c7451f05000000      mov       qword ptr [rbp + 0x1f], 5
0x0001433297e2:  8b05b8feca03          mov       eax, dword ptr [rip + 0x3cafeb8]
0x0001433297e8:  89450f                mov       dword ptr [rbp + 0xf], eax
0x0001433297eb:  0fb605b2feca03        movzx     eax, byte ptr [rip + 0x3cafeb2]
0x0001433297f2:  884513                mov       byte ptr [rbp + 0x13], al
0x0001433297f5:  c6451400              mov       byte ptr [rbp + 0x14], 0
0x0001433297f9:  660f6ec9              movd      xmm1, ecx
0x0001433297fd:  f30fe6c9              cvtdq2pd  xmm1, xmm1
0x000143329801:  440fb683dd000000      movzx     r8d, byte ptr [rbx + 0xdd]
0x000143329809:  488d4d0f              lea       rcx, [rbp + 0xf]
0x00014332980d:  e8ae59ffff            call      0x14331f1c0
0x000143329812:  90                    nop       
0x000143329813:  488b4527              mov       rax, qword ptr [rbp + 0x27]
0x000143329817:  4883f810              cmp       rax, 0x10
0x00014332981b:  722d                  jb        0x14332984a
0x00014332981d:  48ffc0                inc       rax
0x000143329820:  488b4d0f              mov       rcx, qword ptr [rbp + 0xf]
0x000143329824:  488bd1                mov       rdx, rcx
0x000143329827:  483d00100000          cmp       rax, 0x1000
0x00014332982d:  7215                  jb        0x143329844
0x00014332982f:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143329833:  482bd1                sub       rdx, rcx
0x000143329836:  488d42f8              lea       rax, [rdx - 8]
0x00014332983a:  4883f81f              cmp       rax, 0x1f
0x00014332983e:  0f8755010000          ja        0x143329999
0x000143329844:  e867986101            call      0x1449430b0
0x000143329849:  90                    nop       
0x00014332984a:  48c7452f00000000      mov       qword ptr [rbp + 0x2f], 0
0x000143329852:  48c745470f000000      mov       qword ptr [rbp + 0x47], 0xf
0x00014332985a:  48c7453f04000000      mov       qword ptr [rbp + 0x3f], 4
0x000143329862:  c7452f4d697363        mov       dword ptr [rbp + 0x2f], 0x6373694d
0x000143329869:  c6453300              mov       byte ptr [rbp + 0x33], 0
0x00014332986d:  660f6ece              movd      xmm1, esi
0x000143329871:  f30fe6c9              cvtdq2pd  xmm1, xmm1
0x000143329875:  440fb683dd000000      movzx     r8d, byte ptr [rbx + 0xdd]
0x00014332987d:  488d4d2f              lea       rcx, [rbp + 0x2f]
0x000143329881:  e83a59ffff            call      0x14331f1c0
0x000143329886:  90                    nop       
0x000143329887:  488b4547              mov       rax, qword ptr [rbp + 0x47]
0x00014332988b:  4883f810              cmp       rax, 0x10
0x00014332988f:  722d                  jb        0x1433298be
0x000143329891:  48ffc0                inc       rax
0x000143329894:  488b4d2f              mov       rcx, qword ptr [rbp + 0x2f]
0x000143329898:  488bd1                mov       rdx, rcx
0x00014332989b:  483d00100000          cmp       rax, 0x1000
0x0001433298a1:  7215                  jb        0x1433298b8
0x0001433298a3:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x0001433298a7:  482bd1                sub       rdx, rcx
0x0001433298aa:  488d42f8              lea       rax, [rdx - 8]
0x0001433298ae:  4883f81f              cmp       rax, 0x1f
0x0001433298b2:  0f87e1000000          ja        0x143329999
0x0001433298b8:  e8f3976101            call      0x1449430b0
0x0001433298bd:  90                    nop       
0x0001433298be:  48c745070f000000      mov       qword ptr [rbp + 7], 0xf
0x0001433298c6:  48c745ff0f000000      mov       qword ptr [rbp - 1], 0xf
0x0001433298ce:  f20f1005dafeca03      movsd     xmm0, qword ptr [rip + 0x3cafeda]
0x0001433298d6:  f20f1145ef            movsd     qword ptr [rbp - 0x11], xmm0
0x0001433298db:  8b05d7feca03          mov       eax, dword ptr [rip + 0x3cafed7]
0x0001433298e1:  8945f7                mov       dword ptr [rbp - 9], eax
0x0001433298e4:  0fb705d1feca03        movzx     eax, word ptr [rip + 0x3cafed1]
0x0001433298eb:  668945fb              mov       word ptr [rbp - 5], ax
0x0001433298ef:  0fb605c8feca03        movzx     eax, byte ptr [rip + 0x3cafec8]
0x0001433298f6:  8845fd                mov       byte ptr [rbp - 3], al
0x0001433298f9:  c645fe00              mov       byte ptr [rbp - 2], 0
0x0001433298fd:  0fb693dd000000        movzx     edx, byte ptr [rbx + 0xdd]
0x000143329904:  488d4def              lea       rcx, [rbp - 0x11]
0x000143329908:  e89356ffff            call      0x14331efa0
0x00014332990d:  90                    nop       
0x00014332990e:  488b4507              mov       rax, qword ptr [rbp + 7]
0x000143329912:  4883f810              cmp       rax, 0x10
0x000143329916:  7229                  jb        0x143329941
0x000143329918:  48ffc0                inc       rax
0x00014332991b:  488b4def              mov       rcx, qword ptr [rbp - 0x11]
0x00014332991f:  488bd1                mov       rdx, rcx
0x000143329922:  483d00100000          cmp       rax, 0x1000
0x000143329928:  7211                  jb        0x14332993b
0x00014332992a:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014332992e:  482bd1                sub       rdx, rcx
0x000143329931:  488d42f8              lea       rax, [rdx - 8]
0x000143329935:  4883f81f              cmp       rax, 0x1f
0x000143329939:  775e                  ja        0x143329999
0x00014332993b:  e870976101            call      0x1449430b0
0x000143329940:  90                    nop       
0x000143329941:  4885ff                test      rdi, rdi
0x000143329944:  7408                  je        0x14332994e
0x000143329946:  488bcf                mov       rcx, rdi
0x000143329949:  e8c2f549fd            call      0x1407c8f10
0x00014332994e:  488b4d4f              mov       rcx, qword ptr [rbp + 0x4f]
0x000143329952:  4833cc                xor       rcx, rsp
0x000143329955:  e8867c7f02            call      0x145b215e0
0x00014332995a:  4c8d9c24a0000000      lea       r11, [rsp + 0xa0]
0x000143329962:  498b5b18              mov       rbx, qword ptr [r11 + 0x18]
0x000143329966:  498b7320              mov       rsi, qword ptr [r11 + 0x20]
0x00014332996a:  498b7b28              mov       rdi, qword ptr [r11 + 0x28]
0x00014332996e:  498be3                mov       rsp, r11
0x000143329971:  5d                    pop       rbp
0x000143329972:  c3                    ret       
0x000143329973:  488b1f                mov       rbx, qword ptr [rdi]
0x000143329976:  48895dd7              mov       qword ptr [rbp - 0x29], rbx
0x00014332997a:  488b7f08              mov       rdi, qword ptr [rdi + 8]
0x00014332997e:  48897ddf              mov       qword ptr [rbp - 0x21], rdi
0x000143329982:  e9b3fdffff            jmp       0x14332973a
0x000143329987:  ba01000000            mov       edx, 1
0x00014332998c:  488bcb                mov       rcx, rbx
0x00014332998f:  e89c6effff            call      0x143320830
0x000143329994:  e9effdffff            jmp       0x143329788
0x000143329999:  e8827b8202            call      0x145b51520
0x00014332999e:  cc                    int3      
0x00014332999f:  cc                    int3      
0x0001433299a0:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x0001433299a5:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x0001433299aa:  48897c2420            mov       qword ptr [rsp + 0x20], rdi
0x0001433299af:  55                    push      rbp
0x0001433299b0:  4154                  push      r12
0x0001433299b2:  4155                  push      r13
0x0001433299b4:  4156                  push      r14
0x0001433299b6:  4157                  push      r15
0x0001433299b8:  488dac2430fbffff      lea       rbp, [rsp - 0x4d0]
0x0001433299c0:  4881ecd0050000        sub       rsp, 0x5d0
0x0001433299c7:  488b05229d9e04        mov       rax, qword ptr [rip + 0x49e9d22]
0x0001433299ce:  4833c4                xor       rax, rsp
0x0001433299d1:  488985c0040000        mov       qword ptr [rbp + 0x4c0], rax
0x0001433299d8:  488bf1                mov       rsi, rcx
0x0001433299db:  49c7c5ffffffff        mov       r13, 0xffffffffffffffff
0x0001433299e2:  488b05bfe7a504        mov       rax, qword ptr [rip + 0x4a5e7bf]
0x0001433299e9:  3c06                  cmp       al, 6
0x0001433299eb:  0f82b3000000          jb        0x143329aa4
0x0001433299f1:  48c1e808              shr       rax, 8
0x0001433299f5:  3c04                  cmp       al, 4
0x0001433299f7:  0f82a7000000          jb        0x143329aa4
0x0001433299fd:  488d0517032b04        lea       rax, [rip + 0x42b0317]
0x000143329a04:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x000143329a09:  488b4c2440            mov       rcx, qword ptr [rsp + 0x40]
0x000143329a0e:  488d0d9303cb03        lea       rcx, [rip + 0x3cb0393]
0x000143329a15:  48894d60              mov       qword ptr [rbp + 0x60], rcx
0x000143329a19:  498bc5                mov       rax, r13
0x000143329a1c:  0f1f4000              nop       dword ptr [rax]
0x000143329a20:  48ffc0                inc       rax
0x000143329a23:  803c0100              cmp       byte ptr [rcx + rax], 0
0x000143329a27:  75f7                  jne       0x143329a20
0x000143329a29:  48894568              mov       qword ptr [rbp + 0x68], rax
0x000143329a2d:  488d05f4f7ca03        lea       rax, [rip + 0x3caf7f4]
0x000143329a34:  488985f0000000        mov       qword ptr [rbp + 0xf0], rax
0x000143329a3b:  0f2885f0000000        movaps    xmm0, xmmword ptr [rbp + 0xf0]
0x000143329a42:  660f7f8500030000      movdqa    xmmword ptr [rbp + 0x300], xmm0
0x000143329a4a:  48c745500c000000      mov       qword ptr [rbp + 0x50], 0xc
0x000143329a52:  488d8500030000        lea       rax, [rbp + 0x300]
0x000143329a59:  48894558              mov       qword ptr [rbp + 0x58], rax
0x000143329a5d:  0f284550              movaps    xmm0, xmmword ptr [rbp + 0x50]
0x000143329a61:  660f7f8510010000      movdqa    xmmword ptr [rbp + 0x110], xmm0
0x000143329a69:  0f284d60              movaps    xmm1, xmmword ptr [rbp + 0x60]
0x000143329a6d:  660f7f8d20010000      movdqa    xmmword ptr [rbp + 0x120], xmm1
0x000143329a75:  0f10052ce7a504        movups    xmm0, xmmword ptr [rip + 0x4a5e72c]
0x000143329a7c:  0f298530010000        movaps    xmmword ptr [rbp + 0x130], xmm0
0x000143329a83:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x000143329a88:  4c8d8d10010000        lea       r9, [rbp + 0x110]
0x000143329a8f:  4c8d8520010000        lea       r8, [rbp + 0x120]
0x000143329a96:  b204                  mov       dl, 4
0x000143329a98:  488d8d30010000        lea       rcx, [rbp + 0x130]
0x000143329a9f:  e82c606301            call      0x14495fad0
0x000143329aa4:  488d4d98              lea       rcx, [rbp - 0x68]
0x000143329aa8:  e853df6101            call      0x144947a00
0x000143329aad:  f20f104598            movsd     xmm0, qword ptr [rbp - 0x68]
0x000143329ab2:  f20f118600010000      movsd     qword ptr [rsi + 0x100], xmm0
0x000143329aba:  488bd6                mov       rdx, rsi
0x000143329abd:  488d4d88              lea       rcx, [rbp - 0x78]
0x000143329ac1:  e8ba4913fe            call      0x14145e480
0x000143329ac6:  90                    nop       
0x000143329ac7:  4533e4                xor       r12d, r12d
0x000143329aca:  4c89a520020000        mov       qword ptr [rbp + 0x220], r12
0x000143329ad1:  4c89a530020000        mov       qword ptr [rbp + 0x230], r12
0x000143329ad8:  48c785380200000f000000  mov       qword ptr [rbp + 0x238], 0xf
0x000143329ae3:  4488a520020000        mov       byte ptr [rbp + 0x220], r12b
0x000143329aea:  8b05c0e4a504          mov       eax, dword ptr [rip + 0x4a5e4c0]
0x000143329af0:  85c0                  test      eax, eax
0x000143329af2:  0f8ee0010000          jle       0x143329cd8
0x000143329af8:  3b05b2e5a504          cmp       eax, dword ptr [rip + 0x4a5e5b2]
0x000143329afe:  0f8fd4010000          jg        0x143329cd8
0x000143329b04:  c644243001            mov       byte ptr [rsp + 0x30], 1
0x000143329b09:  488d05f5450603        lea       rax, [rip + 0x30645f5]
0x000143329b10:  48894570              mov       qword ptr [rbp + 0x70], rax
0x000143329b14:  4c896578              mov       qword ptr [rbp + 0x78], r12
0x000143329b18:  48898580000000        mov       qword ptr [rbp + 0x80], rax
0x000143329b1f:  4c89a588000000        mov       qword ptr [rbp + 0x88], r12
0x000143329b26:  488d0543fcca03        lea       rax, [rip + 0x3cafc43]
0x000143329b2d:  48898590000000        mov       qword ptr [rbp + 0x90], rax
0x000143329b34:  48c785980000002f000000  mov       qword ptr [rbp + 0x98], 0x2f
0x000143329b3f:  488d057201cb03        lea       rax, [rip + 0x3cb0172]
0x000143329b46:  488985a0000000        mov       qword ptr [rbp + 0xa0], rax
0x000143329b4d:  48c785a800000012000000  mov       qword ptr [rbp + 0xa8], 0x12
0x000143329b58:  488d050512b203        lea       rax, [rip + 0x3b21205]
0x000143329b5f:  488985b0000000        mov       qword ptr [rbp + 0xb0], rax
0x000143329b66:  48c785b800000004000000  mov       qword ptr [rbp + 0xb8], 4
0x000143329b71:  0f284570              movaps    xmm0, xmmword ptr [rbp + 0x70]
0x000143329b75:  660f7f8540010000      movdqa    xmmword ptr [rbp + 0x140], xmm0
0x000143329b7d:  0f288d80000000        movaps    xmm1, xmmword ptr [rbp + 0x80]
0x000143329b84:  660f7f8d50010000      movdqa    xmmword ptr [rbp + 0x150], xmm1
0x000143329b8c:  0f288590000000        movaps    xmm0, xmmword ptr [rbp + 0x90]
0x000143329b93:  660f7f8560010000      movdqa    xmmword ptr [rbp + 0x160], xmm0
0x000143329b9b:  0f288da0000000        movaps    xmm1, xmmword ptr [rbp + 0xa0]
0x000143329ba2:  660f7f8d00010000      movdqa    xmmword ptr [rbp + 0x100], xmm1
0x000143329baa:  0f2885b0000000        movaps    xmm0, xmmword ptr [rbp + 0xb0]
0x000143329bb1:  660f7f8570010000      movdqa    xmmword ptr [rbp + 0x170], xmm0
0x000143329bb9:  488d8540010000        lea       rax, [rbp + 0x140]
0x000143329bc0:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x000143329bc5:  488d8550010000        lea       rax, [rbp + 0x150]
0x000143329bcc:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000143329bd1:  4c8d8d60010000        lea       r9, [rbp + 0x160]
0x000143329bd8:  4c8d8500010000        lea       r8, [rbp + 0x100]
0x000143329bdf:  488d9570010000        lea       rdx, [rbp + 0x170]
0x000143329be6:  488d8d10040000        lea       rcx, [rbp + 0x410]
0x000143329bed:  e81eab6fff            call      0x142a24710
0x000143329bf2:  90                    nop       
0x000143329bf3:  488d95e0020000        lea       rdx, [rbp + 0x2e0]
0x000143329bfa:  488bc8                mov       rcx, rax
0x000143329bfd:  e89eb66fff            call      0x142a252a0
0x000143329c02:  488bd8                mov       rbx, rax
0x000143329c05:  488d8520020000        lea       rax, [rbp + 0x220]
0x000143329c0c:  483bc3                cmp       rax, rbx
0x000143329c0f:  7430                  je        0x143329c41
0x000143329c11:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x000143329c18:  e8c3bd4bfd            call      0x1407e59e0
0x000143329c1d:  0f1003                movups    xmm0, xmmword ptr [rbx]
0x000143329c20:  0f118520020000        movups    xmmword ptr [rbp + 0x220], xmm0
0x000143329c27:  0f104b10              movups    xmm1, xmmword ptr [rbx + 0x10]
0x000143329c2b:  0f118d30020000        movups    xmmword ptr [rbp + 0x230], xmm1
0x000143329c32:  4c896310              mov       qword ptr [rbx + 0x10], r12
0x000143329c36:  48c743180f000000      mov       qword ptr [rbx + 0x18], 0xf
0x000143329c3e:  448823                mov       byte ptr [rbx], r12b
0x000143329c41:  488b85f8020000        mov       rax, qword ptr [rbp + 0x2f8]
0x000143329c48:  4883f810              cmp       rax, 0x10
0x000143329c4c:  7230                  jb        0x143329c7e
0x000143329c4e:  48ffc0                inc       rax
0x000143329c51:  488b8de0020000        mov       rcx, qword ptr [rbp + 0x2e0]
0x000143329c58:  488bd1                mov       rdx, rcx
0x000143329c5b:  483d00100000          cmp       rax, 0x1000
0x000143329c61:  7215                  jb        0x143329c78
0x000143329c63:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143329c67:  482bd1                sub       rdx, rcx
0x000143329c6a:  488d42f8              lea       rax, [rdx - 8]
0x000143329c6e:  4883f81f              cmp       rax, 0x1f
0x000143329c72:  0f87a6090000          ja        0x14332a61e
0x000143329c78:  e833946101            call      0x1449430b0
0x000143329c7d:  90                    nop       
0x000143329c7e:  4c89a5f0020000        mov       qword ptr [rbp + 0x2f0], r12
0x000143329c85:  48c785f80200000f000000  mov       qword ptr [rbp + 0x2f8], 0xf
0x000143329c90:  c685e002000000        mov       byte ptr [rbp + 0x2e0], 0
0x000143329c97:  488d8d90040000        lea       rcx, [rbp + 0x490]
0x000143329c9e:  e83dbd4bfd            call      0x1407e59e0
0x000143329ca3:  488d8d70040000        lea       rcx, [rbp + 0x470]
0x000143329caa:  e831bd4bfd            call      0x1407e59e0
0x000143329caf:  488d8d50040000        lea       rcx, [rbp + 0x450]
0x000143329cb6:  e825bd4bfd            call      0x1407e59e0
0x000143329cbb:  488d8d30040000        lea       rcx, [rbp + 0x430]
0x000143329cc2:  e819bd4bfd            call      0x1407e59e0
0x000143329cc7:  488d8d10040000        lea       rcx, [rbp + 0x410]
0x000143329cce:  e80dbd4bfd            call      0x1407e59e0
0x000143329cd3:  e99a000000            jmp       0x143329d72
0x000143329cd8:  c644243000            mov       byte ptr [rsp + 0x30], 0
0x000143329cdd:  0fb69edd000000        movzx     ebx, byte ptr [rsi + 0xdd]
0x000143329ce4:  488d96b8000000        lea       rdx, [rsi + 0xb8]
0x000143329ceb:  488d8d00020000        lea       rcx, [rbp + 0x200]
0x000143329cf2:  e869a24bfd            call      0x1407e3f60
0x000143329cf7:  440fb6c3              movzx     r8d, bl
0x000143329cfb:  488bd0                mov       rdx, rax
0x000143329cfe:  488d8d50030000        lea       rcx, [rbp + 0x350]
0x000143329d05:  e806d8e5fd            call      0x141187510
0x000143329d0a:  90                    nop       
0x000143329d0b:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x000143329d12:  483bc8                cmp       rcx, rax
0x000143329d15:  741e                  je        0x143329d35
0x000143329d17:  4c8b4010              mov       r8, qword ptr [rax + 0x10]
0x000143329d1b:  4883781810            cmp       qword ptr [rax + 0x18], 0x10
0x000143329d20:  7203                  jb        0x143329d25
0x000143329d22:  488b00                mov       rax, qword ptr [rax]
0x000143329d25:  488bd0                mov       rdx, rax
0x000143329d28:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x000143329d2f:  e81c9d4bfd            call      0x1407e3a50
0x000143329d34:  90                    nop       
0x000143329d35:  488b8568030000        mov       rax, qword ptr [rbp + 0x368]
0x000143329d3c:  4883f810              cmp       rax, 0x10
0x000143329d40:  7230                  jb        0x143329d72
0x000143329d42:  48ffc0                inc       rax
0x000143329d45:  488b8d50030000        mov       rcx, qword ptr [rbp + 0x350]
0x000143329d4c:  488bd1                mov       rdx, rcx
0x000143329d4f:  483d00100000          cmp       rax, 0x1000
0x000143329d55:  7215                  jb        0x143329d6c
0x000143329d57:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143329d5b:  482bd1                sub       rdx, rcx
0x000143329d5e:  488d42f8              lea       rax, [rdx - 8]
0x000143329d62:  4883f81f              cmp       rax, 0x1f
0x000143329d66:  0f87b8080000          ja        0x14332a624
0x000143329d6c:  e83f936101            call      0x1449430b0
0x000143329d71:  90                    nop       
0x000143329d72:  b940000000            mov       ecx, 0x40
0x000143329d77:  e8849a6101            call      0x144943800
0x000143329d7c:  4c8bf0                mov       r14, rax
0x000143329d7f:  4885c0                test      rax, rax
0x000143329d82:  0f847c080000          je        0x14332a604
0x000143329d88:  4889442448            mov       qword ptr [rsp + 0x48], rax
0x000143329d8d:  c744245000000000      mov       dword ptr [rsp + 0x50], 0
0x000143329d95:  488d542450            lea       rdx, [rsp + 0x50]
0x000143329d9a:  488bc8                mov       rcx, rax
0x000143329d9d:  e81e3c61fd            call      0x14093d9c0
0x000143329da2:  90                    nop       
0x000143329da3:  0f57c0                xorps     xmm0, xmm0
0x000143329da6:  f30f7f45c0            movdqu    xmmword ptr [rbp - 0x40], xmm0
0x000143329dab:  4c89b5c0010000        mov       qword ptr [rbp + 0x1c0], r14
0x000143329db2:  b918000000            mov       ecx, 0x18
0x000143329db7:  e8449a6101            call      0x144943800
0x000143329dbc:  4c8bf8                mov       r15, rax
0x000143329dbf:  4885c0                test      rax, rax
0x000143329dc2:  0f8422080000          je        0x14332a5ea
0x000143329dc8:  c7400801000000        mov       dword ptr [rax + 8], 1
0x000143329dcf:  c7400c01000000        mov       dword ptr [rax + 0xc], 1
0x000143329dd6:  488d05bbcc9103        lea       rax, [rip + 0x391ccbb]
0x000143329ddd:  498907                mov       qword ptr [r15], rax
0x000143329de0:  4d897710              mov       qword ptr [r15 + 0x10], r14
0x000143329de4:  4c8975c0              mov       qword ptr [rbp - 0x40], r14
0x000143329de8:  4c897dc8              mov       qword ptr [rbp - 0x38], r15
0x000143329dec:  b918000000            mov       ecx, 0x18
0x000143329df1:  e80a9a6101            call      0x144943800
0x000143329df6:  488bf8                mov       rdi, rax
0x000143329df9:  4885c0                test      rax, rax
0x000143329dfc:  0f849a080000          je        0x14332a69c
0x000143329e02:  4c8920                mov       qword ptr [rax], r12
0x000143329e05:  4c896008              mov       qword ptr [rax + 8], r12
0x000143329e09:  4c896010              mov       qword ptr [rax + 0x10], r12
0x000143329e0d:  0f57c0                xorps     xmm0, xmm0
0x000143329e10:  f30f7f45a0            movdqu    xmmword ptr [rbp - 0x60], xmm0
0x000143329e15:  488985e0000000        mov       qword ptr [rbp + 0xe0], rax
0x000143329e1c:  b918000000            mov       ecx, 0x18
0x000143329e21:  e8da996101            call      0x144943800
0x000143329e26:  4889442448            mov       qword ptr [rsp + 0x48], rax
0x000143329e2b:  4885c0                test      rax, rax
0x000143329e2e:  0f844e080000          je        0x14332a682
0x000143329e34:  c7400801000000        mov       dword ptr [rax + 8], 1
0x000143329e3b:  c7400c01000000        mov       dword ptr [rax + 0xc], 1
0x000143329e42:  488d15971b8b03        lea       rdx, [rip + 0x38b1b97]
0x000143329e49:  488910                mov       qword ptr [rax], rdx
0x000143329e4c:  48897810              mov       qword ptr [rax + 0x10], rdi
0x000143329e50:  48897da0              mov       qword ptr [rbp - 0x60], rdi
0x000143329e54:  488945a8              mov       qword ptr [rbp - 0x58], rax
0x000143329e58:  b940000000            mov       ecx, 0x40
0x000143329e5d:  e89e996101            call      0x144943800
0x000143329e62:  488bd8                mov       rbx, rax
0x000143329e65:  4885c0                test      rax, rax
0x000143329e68:  0f84fa070000          je        0x14332a668
0x000143329e6e:  4889442438            mov       qword ptr [rsp + 0x38], rax
0x000143329e73:  c744244000000000      mov       dword ptr [rsp + 0x40], 0
0x000143329e7b:  488d542440            lea       rdx, [rsp + 0x40]
0x000143329e80:  488bc8                mov       rcx, rax
0x000143329e83:  e8383b61fd            call      0x14093d9c0
0x000143329e88:  90                    nop       
0x000143329e89:  0f57c0                xorps     xmm0, xmm0
0x000143329e8c:  f30f7f45b0            movdqu    xmmword ptr [rbp - 0x50], xmm0
0x000143329e91:  48899dc8010000        mov       qword ptr [rbp + 0x1c8], rbx
0x000143329e98:  b918000000            mov       ecx, 0x18
0x000143329e9d:  e85e996101            call      0x144943800
0x000143329ea2:  4c8be0                mov       r12, rax
0x000143329ea5:  4885c0                test      rax, rax
0x000143329ea8:  0f84a0070000          je        0x14332a64e
0x000143329eae:  c7400801000000        mov       dword ptr [rax + 8], 1
0x000143329eb5:  c7400c01000000        mov       dword ptr [rax + 0xc], 1
0x000143329ebc:  488d05d5cb9103        lea       rax, [rip + 0x391cbd5]
0x000143329ec3:  49890424              mov       qword ptr [r12], rax
0x000143329ec7:  49895c2410            mov       qword ptr [r12 + 0x10], rbx
0x000143329ecc:  48895db0              mov       qword ptr [rbp - 0x50], rbx
0x000143329ed0:  4c8965b8              mov       qword ptr [rbp - 0x48], r12
0x000143329ed4:  807c243000            cmp       byte ptr [rsp + 0x30], 0
0x000143329ed9:  7407                  je        0x143329ee2
0x000143329edb:  b8c8000000            mov       eax, 0xc8
0x000143329ee0:  eb0b                  jmp       0x143329eed
0x000143329ee2:  488b4638              mov       rax, qword ptr [rsi + 0x38]
0x000143329ee6:  488b8078030000        mov       rax, qword ptr [rax + 0x378]
0x000143329eed:  4889442438            mov       qword ptr [rsp + 0x38], rax
0x000143329ef2:  33c0                  xor       eax, eax
0x000143329ef4:  48898560020000        mov       qword ptr [rbp + 0x260], rax
0x000143329efb:  48898570020000        mov       qword ptr [rbp + 0x270], rax
0x000143329f02:  48c785780200000f000000  mov       qword ptr [rbp + 0x278], 0xf
0x000143329f0d:  888560020000          mov       byte ptr [rbp + 0x260], al
0x000143329f13:  448d4007              lea       r8d, [rax + 7]
0x000143329f17:  488d159a19ac03        lea       rdx, [rip + 0x3ac199a]
0x000143329f1e:  488d8d60020000        lea       rcx, [rbp + 0x260]
0x000143329f25:  e8269b4bfd            call      0x1407e3a50
0x000143329f2a:  90                    nop       
0x000143329f2b:  4c8d8560020000        lea       r8, [rbp + 0x260]
0x000143329f32:  488d95f0010000        lea       rdx, [rbp + 0x1f0]
0x000143329f39:  488bcb                mov       rcx, rbx
0x000143329f3c:  e89f4061fd            call      0x14093dfe0
0x000143329f41:  488b08                mov       rcx, qword ptr [rax]
0x000143329f44:  4883c130              add       rcx, 0x30
0x000143329f48:  488d542438            lea       rdx, [rsp + 0x38]
0x000143329f4d:  e87ee258fd            call      0x1408b81d0
0x000143329f52:  90                    nop       
0x000143329f53:  488b8578020000        mov       rax, qword ptr [rbp + 0x278]
0x000143329f5a:  4883f810              cmp       rax, 0x10
0x000143329f5e:  7230                  jb        0x143329f90
0x000143329f60:  48ffc0                inc       rax
0x000143329f63:  488b8d60020000        mov       rcx, qword ptr [rbp + 0x260]
0x000143329f6a:  488bd1                mov       rdx, rcx
0x000143329f6d:  483d00100000          cmp       rax, 0x1000
0x000143329f73:  7215                  jb        0x143329f8a
0x000143329f75:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000143329f79:  482bd1                sub       rdx, rcx
0x000143329f7c:  488d42f8              lea       rax, [rdx - 8]
0x000143329f80:  4883f81f              cmp       rax, 0x1f
0x000143329f84:  0f87a0060000          ja        0x14332a62a
0x000143329f8a:  e821916101            call      0x1449430b0
0x000143329f8f:  90                    nop       
0x000143329f90:  33c0                  xor       eax, eax
0x000143329f92:  48898580020000        mov       qword ptr [rbp + 0x280], rax
0x000143329f99:  48898590020000        mov       qword ptr [rbp + 0x290], rax
0x000143329fa0:  48c785980200000f000000  mov       qword ptr [rbp + 0x298], 0xf
0x000143329fab:  888580020000          mov       byte ptr [rbp + 0x280], al
0x000143329fb1:  448d4012              lea       r8d, [rax + 0x12]
0x000143329fb5:  488d1534dbb403        lea       rdx, [rip + 0x3b4db34]
0x000143329fbc:  488d8d80020000        lea       rcx, [rbp + 0x280]
0x000143329fc3:  e8889a4bfd            call      0x1407e3a50
0x000143329fc8:  90                    nop       
0x000143329fc9:  4c8d8580020000        lea       r8, [rbp + 0x280]
0x000143329fd0:  488d95d0010000        lea       rdx, [rbp + 0x1d0]
0x000143329fd7:  488bcb                mov       rcx, rbx
0x000143329fda:  e8014061fd            call      0x14093dfe0
0x000143329fdf:  488b18                mov       rbx, qword ptr [rax]
0x000143329fe2:  e8f9e9a0fe            call      0x141d389e0
0x000143329fe7:  48894330              mov       qword ptr [rbx + 0x30], rax
0x000143329feb:  488d96d8000000        lea       rdx, [rsi + 0xd8]
0x000143329ff2:  488d4b38              lea       rcx, [rbx + 0x38]
0x000143329ff6:  e8952054fd            call      0x14086c090
0x000143329ffb:  90                    nop       
0x000143329ffc:  488b8598020000        mov       rax, qword ptr [rbp + 0x298]
0x00014332a003:  4883f810              cmp       rax, 0x10
0x00014332a007:  7230                  jb        0x14332a039
0x00014332a009:  48ffc0                inc       rax
0x00014332a00c:  488b8d80020000        mov       rcx, qword ptr [rbp + 0x280]
0x00014332a013:  488bd1                mov       rdx, rcx
0x00014332a016:  483d00100000          cmp       rax, 0x1000
0x00014332a01c:  7215                  jb        0x14332a033
0x00014332a01e:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014332a022:  482bd1                sub       rdx, rcx
0x00014332a025:  488d42f8              lea       rax, [rdx - 8]
0x00014332a029:  4883f81f              cmp       rax, 0x1f
0x00014332a02d:  0f87fd050000          ja        0x14332a630
0x00014332a033:  e878906101            call      0x1449430b0
0x00014332a038:  90                    nop       
0x00014332a039:  e8a207a1fe            call      0x141d3a7e0
0x00014332a03e:  48898570030000        mov       qword ptr [rbp + 0x370], rax
0x00014332a045:  33db                  xor       ebx, ebx
0x00014332a047:  48899d78030000        mov       qword ptr [rbp + 0x378], rbx
0x00014332a04e:  488d55b0              lea       rdx, [rbp - 0x50]
0x00014332a052:  488d8d78030000        lea       rcx, [rbp + 0x378]
0x00014332a059:  e892e4e1fd            call      0x1411484f0
0x00014332a05e:  90                    nop       
0x00014332a05f:  488b4708              mov       rax, qword ptr [rdi + 8]
0x00014332a063:  483b4710              cmp       rax, qword ptr [rdi + 0x10]
0x00014332a067:  7416                  je        0x14332a07f
0x00014332a069:  488d9570030000        lea       rdx, [rbp + 0x370]
0x00014332a070:  488bc8                mov       rcx, rax
0x00014332a073:  e8d8e054fd            call      0x140878150
0x00014332a078:  4883470850            add       qword ptr [rdi + 8], 0x50
0x00014332a07d:  eb13                  jmp       0x14332a092
0x00014332a07f:  4c8d8570030000        lea       r8, [rbp + 0x370]
0x00014332a086:  488bd0                mov       rdx, rax
0x00014332a089:  488bcf                mov       rcx, rdi
0x00014332a08c:  e80fc059fd            call      0x1408c60a0
0x00014332a091:  90                    nop       
0x00014332a092:  488b8578030000        mov       rax, qword ptr [rbp + 0x378]
0x00014332a099:  4885c0                test      rax, rax
0x00014332a09c:  7412                  je        0x14332a0b0
0x00014332a09e:  488d8d80030000        lea       rcx, [rbp + 0x380]
0x00014332a0a5:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x00014332a0a9:  ff15895ce102          call      qword ptr [rip + 0x2e15c89]
0x00014332a0af:  90                    nop       
0x00014332a0b0:  48899da0020000        mov       qword ptr [rbp + 0x2a0], rbx
0x00014332a0b7:  48899db0020000        mov       qword ptr [rbp + 0x2b0], rbx
0x00014332a0be:  48c785b80200000f000000  mov       qword ptr [rbp + 0x2b8], 0xf
0x00014332a0c9:  c685a002000000        mov       byte ptr [rbp + 0x2a0], 0
0x00014332a0d0:  41b813000000          mov       r8d, 0x13
0x00014332a0d6:  488d1513f0ca03        lea       rdx, [rip + 0x3caf013]
0x00014332a0dd:  488d8da0020000        lea       rcx, [rbp + 0x2a0]
0x00014332a0e4:  e867994bfd            call      0x1407e3a50
0x00014332a0e9:  90                    nop       
0x00014332a0ea:  4c8d85a0020000        lea       r8, [rbp + 0x2a0]
0x00014332a0f1:  488d95e0010000        lea       rdx, [rbp + 0x1e0]
0x00014332a0f8:  498bce                mov       rcx, r14
0x00014332a0fb:  e8e03e61fd            call      0x14093dfe0
0x00014332a100:  488b18                mov       rbx, qword ptr [rax]
0x00014332a103:  e8d804a1fe            call      0x141d3a5e0
0x00014332a108:  48894330              mov       qword ptr [rbx + 0x30], rax
0x00014332a10c:  488d4b38              lea       rcx, [rbx + 0x38]
0x00014332a110:  488d55a0              lea       rdx, [rbp - 0x60]
0x00014332a114:  e8e7dce7fd            call      0x1411a7e00
0x00014332a119:  90                    nop       
0x00014332a11a:  488b85b8020000        mov       rax, qword ptr [rbp + 0x2b8]
0x00014332a121:  4883f810              cmp       rax, 0x10
0x00014332a125:  7230                  jb        0x14332a157
0x00014332a127:  48ffc0                inc       rax
0x00014332a12a:  488b8da0020000        mov       rcx, qword ptr [rbp + 0x2a0]
0x00014332a131:  488bd1                mov       rdx, rcx
0x00014332a134:  483d00100000          cmp       rax, 0x1000
0x00014332a13a:  7215                  jb        0x14332a151
0x00014332a13c:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014332a140:  482bd1                sub       rdx, rcx
0x00014332a143:  488d42f8              lea       rax, [rdx - 8]
0x00014332a147:  4883f81f              cmp       rax, 0x1f
0x00014332a14b:  0f87e5040000          ja        0x14332a636
0x00014332a151:  e85a8f6101            call      0x1449430b0
0x00014332a156:  90                    nop       
0x00014332a157:  33db                  xor       ebx, ebx
0x00014332a159:  48899d40020000        mov       qword ptr [rbp + 0x240], rbx
0x00014332a160:  48899d50020000        mov       qword ptr [rbp + 0x250], rbx
0x00014332a167:  48c785580200000f000000  mov       qword ptr [rbp + 0x258], 0xf
0x00014332a172:  889d40020000          mov       byte ptr [rbp + 0x240], bl
0x00014332a178:  e86306a1fe            call      0x141d3a7e0
0x00014332a17d:  488985c0030000        mov       qword ptr [rbp + 0x3c0], rax
0x00014332a184:  48899dc8030000        mov       qword ptr [rbp + 0x3c8], rbx
0x00014332a18b:  488d55c0              lea       rdx, [rbp - 0x40]
0x00014332a18f:  488d8dc8030000        lea       rcx, [rbp + 0x3c8]
0x00014332a196:  e855e3e1fd            call      0x1411484f0
0x00014332a19b:  90                    nop       
0x00014332a19c:  448d4301              lea       r8d, [rbx + 1]
0x00014332a1a0:  488d9540020000        lea       rdx, [rbp + 0x240]
0x00014332a1a7:  488d8dc0030000        lea       rcx, [rbp + 0x3c0]
0x00014332a1ae:  e83ddb7901            call      0x144ac7cf0
0x00014332a1b3:  90                    nop       
0x00014332a1b4:  488b85c8030000        mov       rax, qword ptr [rbp + 0x3c8]
0x00014332a1bb:  4885c0                test      rax, rax
0x00014332a1be:  7412                  je        0x14332a1d2
0x00014332a1c0:  488d8dd0030000        lea       rcx, [rbp + 0x3d0]
0x00014332a1c7:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x00014332a1cb:  ff15675be102          call      qword ptr [rip + 0x2e15b67]
0x00014332a1d1:  90                    nop       
0x00014332a1d2:  33d2                  xor       edx, edx
0x00014332a1d4:  488d4c2460            lea       rcx, [rsp + 0x60]
0x00014332a1d9:  e8d2d898ff            call      0x142cb7ab0
0x00014332a1de:  90                    nop       
0x00014332a1df:  0fb68edd000000        movzx     ecx, byte ptr [rsi + 0xdd]
0x00014332a1e6:  488d442478            lea       rax, [rsp + 0x78]
0x00014332a1eb:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x00014332a1f0:  0f57c0                xorps     xmm0, xmm0
0x00014332a1f3:  f30f7f442478          movdqu    xmmword ptr [rsp + 0x78], xmm0
0x00014332a1f9:  488b4650              mov       rax, qword ptr [rsi + 0x50]
0x00014332a1fd:  4885c0                test      rax, rax
0x00014332a200:  7404                  je        0x14332a206
0x00014332a202:  f0ff4008              lock inc  dword ptr [rax + 8]
0x00014332a206:  488b4648              mov       rax, qword ptr [rsi + 0x48]
0x00014332a20a:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x00014332a20f:  488b4650              mov       rax, qword ptr [rsi + 0x50]
0x00014332a213:  48894580              mov       qword ptr [rbp - 0x80], rax
0x00014332a217:  48899dc0020000        mov       qword ptr [rbp + 0x2c0], rbx
0x00014332a21e:  48c785d80200000f000000  mov       qword ptr [rbp + 0x2d8], 0xf
0x00014332a229:  48c785d002000004000000  mov       qword ptr [rbp + 0x2d0], 4
0x00014332a234:  c785c0020000504f5354  mov       dword ptr [rbp + 0x2c0], 0x54534f50
0x00014332a23e:  c685c402000000        mov       byte ptr [rbp + 0x2c4], 0
0x00014332a245:  660f7f45d0            movdqa    xmmword ptr [rbp - 0x30], xmm0
0x00014332a24a:  488b7c2468            mov       rdi, qword ptr [rsp + 0x68]
0x00014332a24f:  4885ff                test      rdi, rdi
0x00014332a252:  7409                  je        0x14332a25d
0x00014332a254:  f0ff4708              lock inc  dword ptr [rdi + 8]
0x00014332a258:  488b7c2468            mov       rdi, qword ptr [rsp + 0x68]
0x00014332a25d:  0f28442460            movaps    xmm0, xmmword ptr [rsp + 0x60]
0x00014332a262:  660f7f45d0            movdqa    xmmword ptr [rbp - 0x30], xmm0
0x00014332a267:  884c2420              mov       byte ptr [rsp + 0x20], cl
0x00014332a26b:  4c8d4c2478            lea       r9, [rsp + 0x78]
0x00014332a270:  4c8d8520020000        lea       r8, [rbp + 0x220]
0x00014332a277:  488d95c0020000        lea       rdx, [rbp + 0x2c0]
0x00014332a27e:  488d4dd0              lea       rcx, [rbp - 0x30]
0x00014332a282:  e87951ffff            call      0x14331f400
0x00014332a287:  90                    nop       
0x00014332a288:  488b85d8020000        mov       rax, qword ptr [rbp + 0x2d8]
0x00014332a28f:  4883f810              cmp       rax, 0x10
0x00014332a293:  7230                  jb        0x14332a2c5
0x00014332a295:  48ffc0                inc       rax
0x00014332a298:  488b8dc0020000        mov       rcx, qword ptr [rbp + 0x2c0]
0x00014332a29f:  488bd1                mov       rdx, rcx
0x00014332a2a2:  483d00100000          cmp       rax, 0x1000
0x00014332a2a8:  7215                  jb        0x14332a2bf
0x00014332a2aa:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014332a2ae:  482bd1                sub       rdx, rcx
0x00014332a2b1:  488d42f8              lea       rax, [rdx - 8]
0x00014332a2b5:  4883f81f              cmp       rax, 0x1f
0x00014332a2b9:  0f877d030000          ja        0x14332a63c
0x00014332a2bf:  e8ec8d6101            call      0x1449430b0
0x00014332a2c4:  90                    nop       
0x00014332a2c5:  488b4648              mov       rax, qword ptr [rsi + 0x48]
0x00014332a2c9:  4c8b742460            mov       r14, qword ptr [rsp + 0x60]
0x00014332a2ce:  4885c0                test      rax, rax
0x00014332a2d1:  0f848e000000          je        0x14332a365
0x00014332a2d7:  80bedd00000000        cmp       byte ptr [rsi + 0xdd], 0
0x00014332a2de:  0f8481000000          je        0x14332a365
0x00014332a2e4:  803dddd9230500        cmp       byte ptr [rip + 0x523d9dd], 0
0x00014332a2eb:  7478                  je        0x14332a365
0x00014332a2ed:  803d94dc230500        cmp       byte ptr [rip + 0x523dc94], 0
0x00014332a2f4:  746f                  je        0x14332a365
0x00014332a2f6:  4805e8040000          add       rax, 0x4e8
0x00014332a2fc:  488b4810              mov       rcx, qword ptr [rax + 0x10]
0x00014332a300:  4883781810            cmp       qword ptr [rax + 0x18], 0x10
0x00014332a305:  7203                  jb        0x14332a30a
0x00014332a307:  488b00                mov       rax, qword ptr [rax]
0x00014332a30a:  488985c0000000        mov       qword ptr [rbp + 0xc0], rax
0x00014332a311:  48898dc8000000        mov       qword ptr [rbp + 0xc8], rcx
0x00014332a318:  488d05916bb303        lea       rax, [rip + 0x3b36b91]
0x00014332a31f:  488985d0000000        mov       qword ptr [rbp + 0xd0], rax
0x00014332a326:  48c785d80000001a000000  mov       qword ptr [rbp + 0xd8], 0x1a
0x00014332a331:  0f2885c0000000        movaps    xmm0, xmmword ptr [rbp + 0xc0]
0x00014332a338:  660f7f8580010000      movdqa    xmmword ptr [rbp + 0x180], xmm0
0x00014332a340:  0f288dd0000000        movaps    xmm1, xmmword ptr [rbp + 0xd0]
0x00014332a347:  660f7f8d90010000      movdqa    xmmword ptr [rbp + 0x190], xmm1
0x00014332a34f:  4c8d8580010000        lea       r8, [rbp + 0x180]
0x00014332a356:  488d9590010000        lea       rdx, [rbp + 0x190]
0x00014332a35d:  498bce                mov       rcx, r14
0x00014332a360:  e8fbf298ff            call      0x142cb9660
0x00014332a365:  80bedc00000000        cmp       byte ptr [rsi + 0xdc], 0
0x00014332a36c:  7467                  je        0x14332a3d5
0x00014332a36e:  488d05db03ac03        lea       rax, [rip + 0x3ac03db]
0x00014332a375:  48894520              mov       qword ptr [rbp + 0x20], rax
0x00014332a379:  48c7452804000000      mov       qword ptr [rbp + 0x28], 4
0x00014332a381:  488b0de82aa504        mov       rcx, qword ptr [rip + 0x4a52ae8]
0x00014332a388:  488d05d12aa504        lea       rax, [rip + 0x4a52ad1]
0x00014332a38f:  48833de12aa50410      cmp       qword ptr [rip + 0x4a52ae1], 0x10
0x00014332a397:  480f4305c12aa504      cmovae    rax, qword ptr [rip + 0x4a52ac1]
0x00014332a39f:  48894530              mov       qword ptr [rbp + 0x30], rax
0x00014332a3a3:  48894d38              mov       qword ptr [rbp + 0x38], rcx
0x00014332a3a7:  0f284520              movaps    xmm0, xmmword ptr [rbp + 0x20]
0x00014332a3ab:  660f7f85a0010000      movdqa    xmmword ptr [rbp + 0x1a0], xmm0
0x00014332a3b3:  0f284d30              movaps    xmm1, xmmword ptr [rbp + 0x30]
0x00014332a3b7:  660f7f8db0010000      movdqa    xmmword ptr [rbp + 0x1b0], xmm1
0x00014332a3bf:  4c8d85a0010000        lea       r8, [rbp + 0x1a0]
0x00014332a3c6:  488d95b0010000        lea       rdx, [rbp + 0x1b0]
0x00014332a3cd:  498bce                mov       rcx, r14
0x00014332a3d0:  e88bf298ff            call      0x142cb9660
0x00014332a3d5:  807c243000            cmp       byte ptr [rsp + 0x30], 0
0x00014332a3da:  750e                  jne       0x14332a3ea
0x00014332a3dc:  803d25d8230500        cmp       byte ptr [rip + 0x523d825], 0
0x00014332a3e3:  7405                  je        0x14332a3ea
0x00014332a3e5:  41b001                mov       r8b, 1
0x00014332a3e8:  eb03                  jmp       0x14332a3ed
0x00014332a3ea:  4532c0                xor       r8b, r8b
0x00014332a3ed:  488d8540020000        lea       rax, [rbp + 0x240]
0x00014332a3f4:  4883bd5802000010      cmp       qword ptr [rbp + 0x258], 0x10
0x00014332a3fc:  480f438540020000      cmovae    rax, qword ptr [rbp + 0x240]
0x00014332a404:  48894540              mov       qword ptr [rbp + 0x40], rax
0x00014332a408:  488b8550020000        mov       rax, qword ptr [rbp + 0x250]
0x00014332a40f:  48894548              mov       qword ptr [rbp + 0x48], rax
0x00014332a413:  488d5540              lea       rdx, [rbp + 0x40]
0x00014332a417:  498bce                mov       rcx, r14
0x00014332a41a:  e831fd98ff            call      0x142cba150
0x00014332a41f:  498b06                mov       rax, qword ptr [r14]
0x00014332a422:  4c8b4008              mov       r8, qword ptr [rax + 8]
0x00014332a426:  488bc3                mov       rax, rbx
0x00014332a429:  48895de0              mov       qword ptr [rbp - 0x20], rbx
0x00014332a42d:  488bcb                mov       rcx, rbx
0x00014332a430:  488b5d90              mov       rbx, qword ptr [rbp - 0x70]
0x00014332a434:  4885db                test      rbx, rbx
0x00014332a437:  7421                  je        0x14332a45a
0x00014332a439:  488b4588              mov       rax, qword ptr [rbp - 0x78]
0x00014332a43d:  488945e0              mov       qword ptr [rbp - 0x20], rax
0x00014332a441:  f0ff430c              lock inc  dword ptr [rbx + 0xc]
0x00014332a445:  488b5d90              mov       rbx, qword ptr [rbp - 0x70]
0x00014332a449:  488bcb                mov       rcx, rbx
0x00014332a44c:  488b7c2468            mov       rdi, qword ptr [rsp + 0x68]
0x00014332a451:  4c8b742460            mov       r14, qword ptr [rsp + 0x60]
0x00014332a456:  488b45e0              mov       rax, qword ptr [rbp - 0x20]
0x00014332a45a:  488d154f6d9c03        lea       rdx, [rip + 0x39c6d4f]
0x00014332a461:  48899510030000        mov       qword ptr [rbp + 0x310], rdx
0x00014332a468:  48898518030000        mov       qword ptr [rbp + 0x318], rax
0x00014332a46f:  48898d20030000        mov       qword ptr [rbp + 0x320], rcx
0x00014332a476:  488d8510030000        lea       rax, [rbp + 0x310]
0x00014332a47d:  48898548030000        mov       qword ptr [rbp + 0x348], rax
0x00014332a484:  488d9510030000        lea       rdx, [rbp + 0x310]
0x00014332a48b:  498bce                mov       rcx, r14
0x00014332a48e:  498bc0                mov       rax, r8
0x00014332a491:  ff15a158e102          call      qword ptr [rip + 0x2e158a1]
0x00014332a497:  90                    nop       
0x00014332a498:  488b8d48030000        mov       rcx, qword ptr [rbp + 0x348]
0x00014332a49f:  4885c9                test      rcx, rcx
0x00014332a4a2:  741b                  je        0x14332a4bf
0x00014332a4a4:  488b01                mov       rax, qword ptr [rcx]
0x00014332a4a7:  488d9510030000        lea       rdx, [rbp + 0x310]
0x00014332a4ae:  483bca                cmp       rcx, rdx
0x00014332a4b1:  0f95c2                setne     dl
0x00014332a4b4:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x00014332a4b8:  ff157a58e102          call      qword ptr [rip + 0x2e1587a]
0x00014332a4be:  90                    nop       
0x00014332a4bf:  4885ff                test      rdi, rdi
0x00014332a4c2:  7409                  je        0x14332a4cd
0x00014332a4c4:  488bcf                mov       rcx, rdi
0x00014332a4c7:  e844ea49fd            call      0x1407c8f10
0x00014332a4cc:  90                    nop       
0x00014332a4cd:  488b8558020000        mov       rax, qword ptr [rbp + 0x258]
0x00014332a4d4:  4883f810              cmp       rax, 0x10
0x00014332a4d8:  7230                  jb        0x14332a50a
0x00014332a4da:  48ffc0                inc       rax
0x00014332a4dd:  488b8d40020000        mov       rcx, qword ptr [rbp + 0x240]
0x00014332a4e4:  488bd1                mov       rdx, rcx
0x00014332a4e7:  483d00100000          cmp       rax, 0x1000
0x00014332a4ed:  7215                  jb        0x14332a504
0x00014332a4ef:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014332a4f3:  482bd1                sub       rdx, rcx
0x00014332a4f6:  488d42f8              lea       rax, [rdx - 8]
0x00014332a4fa:  4883f81f              cmp       rax, 0x1f
0x00014332a4fe:  0f873e010000          ja        0x14332a642
0x00014332a504:  e8a78b6101            call      0x1449430b0
0x00014332a509:  90                    nop       
0x00014332a50a:  33ff                  xor       edi, edi
0x00014332a50c:  4889bd50020000        mov       qword ptr [rbp + 0x250], rdi
0x00014332a513:  48c785580200000f000000  mov       qword ptr [rbp + 0x258], 0xf
0x00014332a51e:  4088bd40020000        mov       byte ptr [rbp + 0x240], dil
0x00014332a525:  498bcc                mov       rcx, r12
0x00014332a528:  e8e3e949fd            call      0x1407c8f10
0x00014332a52d:  90                    nop       
0x00014332a52e:  488b4c2448            mov       rcx, qword ptr [rsp + 0x48]
0x00014332a533:  e8d8e949fd            call      0x1407c8f10
0x00014332a538:  90                    nop       
0x00014332a539:  498bcf                mov       rcx, r15
0x00014332a53c:  e8cfe949fd            call      0x1407c8f10
0x00014332a541:  90                    nop       
0x00014332a542:  488b8538020000        mov       rax, qword ptr [rbp + 0x238]
0x00014332a549:  4883f810              cmp       rax, 0x10
0x00014332a54d:  7230                  jb        0x14332a57f
0x00014332a54f:  48ffc0                inc       rax
0x00014332a552:  488b8d20020000        mov       rcx, qword ptr [rbp + 0x220]
0x00014332a559:  488bd1                mov       rdx, rcx
0x00014332a55c:  483d00100000          cmp       rax, 0x1000
0x00014332a562:  7215                  jb        0x14332a579
0x00014332a564:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014332a568:  482bd1                sub       rdx, rcx
0x00014332a56b:  488d42f8              lea       rax, [rdx - 8]
0x00014332a56f:  4883f81f              cmp       rax, 0x1f
0x00014332a573:  0f87cf000000          ja        0x14332a648
0x00014332a579:  e8328b6101            call      0x1449430b0
0x00014332a57e:  90                    nop       
0x00014332a57f:  4889bd30020000        mov       qword ptr [rbp + 0x230], rdi
0x00014332a586:  48c785380200000f000000  mov       qword ptr [rbp + 0x238], 0xf
0x00014332a591:  c6852002000000        mov       byte ptr [rbp + 0x220], 0
0x00014332a598:  4885db                test      rbx, rbx
0x00014332a59b:  741d                  je        0x14332a5ba
0x00014332a59d:  f0440fc16b0c          lock xadd dword ptr [rbx + 0xc], r13d
0x00014332a5a3:  4183fd01              cmp       r13d, 1
0x00014332a5a7:  7511                  jne       0x14332a5ba
0x00014332a5a9:  488b4d90              mov       rcx, qword ptr [rbp - 0x70]
0x00014332a5ad:  488b01                mov       rax, qword ptr [rcx]
0x00014332a5b0:  488b4008              mov       rax, qword ptr [rax + 8]
0x00014332a5b4:  ff157e57e102          call      qword ptr [rip + 0x2e1577e]
0x00014332a5ba:  488b8dc0040000        mov       rcx, qword ptr [rbp + 0x4c0]
0x00014332a5c1:  4833cc                xor       rcx, rsp
0x00014332a5c4:  e817707f02            call      0x145b215e0
0x00014332a5c9:  4c8d9c24d0050000      lea       r11, [rsp + 0x5d0]
0x00014332a5d1:  498b5b38              mov       rbx, qword ptr [r11 + 0x38]
0x00014332a5d5:  498b7340              mov       rsi, qword ptr [r11 + 0x40]
0x00014332a5d9:  498b7b48              mov       rdi, qword ptr [r11 + 0x48]
0x00014332a5dd:  498be3                mov       rsp, r11
0x00014332a5e0:  415f                  pop       r15
0x00014332a5e2:  415e                  pop       r14
0x00014332a5e4:  415d                  pop       r13
0x00014332a5e6:  415c                  pop       r12
0x00014332a5e8:  5d                    pop       rbp
0x00014332a5e9:  c3                    ret       
0x00014332a5ea:  488d4df0              lea       rcx, [rbp - 0x10]
0x00014332a5ee:  e8fd0749fd            call      0x1407badf0
0x00014332a5f3:  488d1546c69d04        lea       rdx, [rip + 0x49dc646]
0x00014332a5fa:  488d4df0              lea       rcx, [rbp - 0x10]
0x00014332a5fe:  e84d8a8102            call      0x145b43050
0x00014332a603:  90                    nop       
0x00014332a604:  488d4d08              lea       rcx, [rbp + 8]
0x00014332a608:  e8e30749fd            call      0x1407badf0
0x00014332a60d:  488d152cc69d04        lea       rdx, [rip + 0x49dc62c]
0x00014332a614:  488d4d08              lea       rcx, [rbp + 8]
0x00014332a618:  e8338a8102            call      0x145b43050
0x00014332a61d:  90                    nop       
0x00014332a61e:  e8fd6e8202            call      0x145b51520
0x00014332a623:  90                    nop       
0x00014332a624:  e8f76e8202            call      0x145b51520
0x00014332a629:  90                    nop       
0x00014332a62a:  e8f16e8202            call      0x145b51520
0x00014332a62f:  cc                    int3      
0x00014332a630:  e8eb6e8202            call      0x145b51520
0x00014332a635:  cc                    int3      
0x00014332a636:  e8e56e8202            call      0x145b51520
0x00014332a63b:  90                    nop       
0x00014332a63c:  e8df6e8202            call      0x145b51520
0x00014332a641:  90                    nop       
0x00014332a642:  e8d96e8202            call      0x145b51520
0x00014332a647:  90                    nop       
0x00014332a648:  e8d36e8202            call      0x145b51520
0x00014332a64d:  90                    nop       
0x00014332a64e:  488d4df0              lea       rcx, [rbp - 0x10]
0x00014332a652:  e8990749fd            call      0x1407badf0
0x00014332a657:  488d15e2c59d04        lea       rdx, [rip + 0x49dc5e2]
0x00014332a65e:  488d4df0              lea       rcx, [rbp - 0x10]
0x00014332a662:  e8e9898102            call      0x145b43050
0x00014332a667:  90                    nop       
0x00014332a668:  488d4df0              lea       rcx, [rbp - 0x10]
0x00014332a66c:  e87f0749fd            call      0x1407badf0
0x00014332a671:  488d15c8c59d04        lea       rdx, [rip + 0x49dc5c8]
0x00014332a678:  488d4df0              lea       rcx, [rbp - 0x10]
0x00014332a67c:  e8cf898102            call      0x145b43050
0x00014332a681:  90                    nop       
0x00014332a682:  488d4d08              lea       rcx, [rbp + 8]
0x00014332a686:  e8650749fd            call      0x1407badf0
0x00014332a68b:  488d15aec59d04        lea       rdx, [rip + 0x49dc5ae]
0x00014332a692:  488d4d08              lea       rcx, [rbp + 8]
0x00014332a696:  e8b5898102            call      0x145b43050
0x00014332a69b:  90                    nop       
0x00014332a69c:  488d4d08              lea       rcx, [rbp + 8]
0x00014332a6a0:  e84b0749fd            call      0x1407badf0
0x00014332a6a5:  488d1594c59d04        lea       rdx, [rip + 0x49dc594]
0x00014332a6ac:  488d4d08              lea       rcx, [rbp + 8]
0x00014332a6b0:  e89b898102            call      0x145b43050
0x00014332a6b5:  cc                    int3      
0x00014332a6b6:  cc                    int3      
0x00014332a6b7:  cc                    int3      
0x00014332a6b8:  cc                    int3      
0x00014332a6b9:  cc                    int3      
0x00014332a6ba:  cc                    int3      
0x00014332a6bb:  cc                    int3      
0x00014332a6bc:  cc                    int3      
0x00014332a6bd:  cc                    int3      
0x00014332a6be:  cc                    int3      
0x00014332a6bf:  cc                    int3      
0x00014332a6c0:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014332a6c5:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x00014332a6ca:  55                    push      rbp
0x00014332a6cb:  57                    push      rdi
0x00014332a6cc:  4156                  push      r14
0x00014332a6ce:  488d6c2490            lea       rbp, [rsp - 0x70]
0x00014332a6d3:  4881ec70010000        sub       rsp, 0x170
0x00014332a6da:  0f29b42460010000      movaps    xmmword ptr [rsp + 0x160], xmm6
0x00014332a6e2:  488b0507909e04        mov       rax, qword ptr [rip + 0x49e9007]
0x00014332a6e9:  4833c4                xor       rax, rsp
0x00014332a6ec:  48894558              mov       qword ptr [rbp + 0x58], rax
0x00014332a6f0:  4d8bf0                mov       r14, r8
0x00014332a6f3:  8bda                  mov       ebx, edx
0x00014332a6f5:  488bf1                mov       rsi, rcx
0x00014332a6f8:  0f57c0                xorps     xmm0, xmm0
0x00014332a6fb:  f30f7f442450          movdqu    xmmword ptr [rsp + 0x50], xmm0
0x00014332a701:  488b5108              mov       rdx, qword ptr [rcx + 8]
0x00014332a705:  4885d2                test      rdx, rdx
0x00014332a708:  7411                  je        0x14332a71b
0x00014332a70a:  488b01                mov       rax, qword ptr [rcx]
0x00014332a70d:  4889442450            mov       qword ptr [rsp + 0x50], rax
0x00014332a712:  4889542458            mov       qword ptr [rsp + 0x58], rdx
0x00014332a717:  f0ff420c              lock inc  dword ptr [rdx + 0xc]
0x00014332a71b:  4c8d0506ebca03        lea       r8, [rip + 0x3caeb06]
0x00014332a722:  488d542450            lea       rdx, [rsp + 0x50]
0x00014332a727:  488d4c2468            lea       rcx, [rsp + 0x68]
0x00014332a72c:  e88f63ffff            call      0x143320ac0
0x00014332a731:  90                    nop       
0x00014332a732:  488b7c2468            mov       rdi, qword ptr [rsp + 0x68]
0x00014332a737:  4885ff                test      rdi, rdi
0x00014332a73a:  0f843f020000          je        0x14332a97f
0x00014332a740:  c644242000            mov       byte ptr [rsp + 0x20], 0
0x00014332a745:  4c8d0ddceaca03        lea       r9, [rip + 0x3caeadc]
0x00014332a74c:  4d8bc6                mov       r8, r14
0x00014332a74f:  8bd3                  mov       edx, ebx
0x00014332a751:  488bcf                mov       rcx, rdi
0x00014332a754:  e8f76bffff            call      0x143321350
0x00014332a759:  84c0                  test      al, al
0x00014332a75b:  0f8523010000          jne       0x14332a884
0x00014332a761:  0fb69fdd000000        movzx     ebx, byte ptr [rdi + 0xdd]
0x00014332a768:  b920000000            mov       ecx, 0x20
0x00014332a76d:  e85ef94bfd            call      0x1407ea0d0
0x00014332a772:  48c7452812000000      mov       qword ptr [rbp + 0x28], 0x12
0x00014332a77a:  48c745301f000000      mov       qword ptr [rbp + 0x30], 0x1f
0x00014332a782:  0f1005cfefca03        movups    xmm0, xmmword ptr [rip + 0x3caefcf]
0x00014332a789:  0f1100                movups    xmmword ptr [rax], xmm0
0x00014332a78c:  0fb70dd5efca03        movzx     ecx, word ptr [rip + 0x3caefd5]
0x00014332a793:  66894810              mov       word ptr [rax + 0x10], cx
0x00014332a797:  c6401200              mov       byte ptr [rax + 0x12], 0
0x00014332a79b:  48894518              mov       qword ptr [rbp + 0x18], rax
0x00014332a79f:  0fb6d3                movzx     edx, bl
0x00014332a7a2:  488d4d18              lea       rcx, [rbp + 0x18]
0x00014332a7a6:  e8f547ffff            call      0x14331efa0
0x00014332a7ab:  90                    nop       
0x00014332a7ac:  488b4530              mov       rax, qword ptr [rbp + 0x30]
0x00014332a7b0:  4883f810              cmp       rax, 0x10
0x00014332a7b4:  722d                  jb        0x14332a7e3
0x00014332a7b6:  48ffc0                inc       rax
0x00014332a7b9:  488b4d18              mov       rcx, qword ptr [rbp + 0x18]
0x00014332a7bd:  488bd1                mov       rdx, rcx
0x00014332a7c0:  483d00100000          cmp       rax, 0x1000
0x00014332a7c6:  7215                  jb        0x14332a7dd
0x00014332a7c8:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014332a7cc:  482bd1                sub       rdx, rcx
0x00014332a7cf:  488d42f8              lea       rax, [rdx - 8]
0x00014332a7d3:  4883f81f              cmp       rax, 0x1f
0x00014332a7d7:  0f87da010000          ja        0x14332a9b7
0x00014332a7dd:  e8ce886101            call      0x1449430b0
0x00014332a7e2:  90                    nop       
0x00014332a7e3:  488d4c2478            lea       rcx, [rsp + 0x78]
0x00014332a7e8:  e833fbe6fd            call      0x14119a320
0x00014332a7ed:  90                    nop       
0x00014332a7ee:  488b5c2478            mov       rbx, qword ptr [rsp + 0x78]
0x00014332a7f3:  4885db                test      rbx, rbx
0x00014332a7f6:  7462                  je        0x14332a85a
0x00014332a7f8:  488bcb                mov       rcx, rbx
0x00014332a7fb:  e890f4e6fd            call      0x141199c90
0x00014332a800:  84c0                  test      al, al
0x00014332a802:  7456                  je        0x14332a85a
0x00014332a804:  8b0b                  mov       ecx, dword ptr [rbx]
0x00014332a806:  488b4308              mov       rax, qword ptr [rbx + 8]
0x00014332a80a:  488b1cc8              mov       rbx, qword ptr [rax + rcx*8]
0x00014332a80e:  803b00                cmp       byte ptr [rbx], 0
0x00014332a811:  7447                  je        0x14332a85a
0x00014332a813:  0f57c0                xorps     xmm0, xmm0
0x00014332a816:  f30f11442440          movss     dword ptr [rsp + 0x40], xmm0
0x00014332a81c:  488d542440            lea       rdx, [rsp + 0x40]
0x00014332a821:  488d4dd8              lea       rcx, [rbp - 0x28]
0x00014332a825:  e8b6ab4bfd            call      0x1407e53e0
0x00014332a82a:  48c744242801000000    mov       qword ptr [rsp + 0x28], 1
0x00014332a833:  488d45d8              lea       rax, [rbp - 0x28]
0x00014332a837:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014332a83c:  4c8d0d15efca03        lea       r9, [rip + 0x3caef15]
0x00014332a843:  4c8d0586f1ca03        lea       r8, [rip + 0x3caf186]
0x00014332a84a:  488d15cf31b203        lea       rdx, [rip + 0x3b231cf]
0x00014332a851:  488bcb                mov       rcx, rbx
0x00014332a854:  e8c716e7fd            call      0x14119bf20
0x00014332a859:  90                    nop       
0x00014332a85a:  488b4d80              mov       rcx, qword ptr [rbp - 0x80]
0x00014332a85e:  4885c9                test      rcx, rcx
0x00014332a861:  7405                  je        0x14332a868
0x00014332a863:  e8a8e649fd            call      0x1407c8f10
0x00014332a868:  80bfdd00000000        cmp       byte ptr [rdi + 0xdd], 0
0x00014332a86f:  7413                  je        0x14332a884
0x00014332a871:  488d4f28              lea       rcx, [rdi + 0x28]
0x00014332a875:  488d542468            lea       rdx, [rsp + 0x68]
0x00014332a87a:  e8310a0000            call      0x14332b2b0
0x00014332a87f:  e9fb000000            jmp       0x14332a97f
0x00014332a884:  488d4c2448            lea       rcx, [rsp + 0x48]
0x00014332a889:  e872d16101            call      0x144947a00
0x00014332a88e:  f20f10442448          movsd     xmm0, qword ptr [rsp + 0x48]
0x00014332a894:  f20f5c8700010000      subsd     xmm0, qword ptr [rdi + 0x100]
0x00014332a89c:  f20f590594e7e903      mulsd     xmm0, qword ptr [rip + 0x3e9e794]
0x00014332a8a4:  f20f2cc0              cvttsd2si eax, xmm0
0x00014332a8a8:  89871c010000          mov       dword ptr [rdi + 0x11c], eax
0x00014332a8ae:  0fb69fdd000000        movzx     ebx, byte ptr [rdi + 0xdd]
0x00014332a8b5:  660f6ef0              movd      xmm6, eax
0x00014332a8b9:  f30fe6f6              cvtdq2pd  xmm6, xmm6
0x00014332a8bd:  b920000000            mov       ecx, 0x20
0x00014332a8c2:  e809f84bfd            call      0x1407ea0d0
0x00014332a8c7:  48c7454810000000      mov       qword ptr [rbp + 0x48], 0x10
0x00014332a8cf:  48c745501f000000      mov       qword ptr [rbp + 0x50], 0x1f
0x00014332a8d7:  0f100562eeca03        movups    xmm0, xmmword ptr [rip + 0x3caee62]
0x00014332a8de:  0f1100                movups    xmmword ptr [rax], xmm0
0x00014332a8e1:  c6401000              mov       byte ptr [rax + 0x10], 0
0x00014332a8e5:  48894538              mov       qword ptr [rbp + 0x38], rax
0x00014332a8e9:  440fb6c3              movzx     r8d, bl
0x00014332a8ed:  0f28ce                movaps    xmm1, xmm6
0x00014332a8f0:  488d4d38              lea       rcx, [rbp + 0x38]
0x00014332a8f4:  e8c748ffff            call      0x14331f1c0
0x00014332a8f9:  90                    nop       
0x00014332a8fa:  488b4550              mov       rax, qword ptr [rbp + 0x50]
0x00014332a8fe:  4883f810              cmp       rax, 0x10
0x00014332a902:  722d                  jb        0x14332a931
0x00014332a904:  48ffc0                inc       rax
0x00014332a907:  488b4d38              mov       rcx, qword ptr [rbp + 0x38]
0x00014332a90b:  488bd1                mov       rdx, rcx
0x00014332a90e:  483d00100000          cmp       rax, 0x1000
0x00014332a914:  7215                  jb        0x14332a92b
0x00014332a916:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014332a91a:  482bd1                sub       rdx, rcx
0x00014332a91d:  488d42f8              lea       rax, [rdx - 8]
0x00014332a921:  4883f81f              cmp       rax, 0x1f
0x00014332a925:  0f878c000000          ja        0x14332a9b7
0x00014332a92b:  e880876101            call      0x1449430b0
0x00014332a930:  90                    nop       
0x00014332a931:  4c8b4f38              mov       r9, qword ptr [rdi + 0x38]
0x00014332a935:  33c9                  xor       ecx, ecx
0x00014332a937:  488b4608              mov       rax, qword ptr [rsi + 8]
0x00014332a93b:  8bd1                  mov       edx, ecx
0x00014332a93d:  4885c0                test      rax, rax
0x00014332a940:  740f                  je        0x14332a951
0x00014332a942:  488b16                mov       rdx, qword ptr [rsi]
0x00014332a945:  48894590              mov       qword ptr [rbp - 0x70], rax
0x00014332a949:  f0ff400c              lock inc  dword ptr [rax + 0xc]
0x00014332a94d:  488b4d90              mov       rcx, qword ptr [rbp - 0x70]
0x00014332a951:  488d05186a9c03        lea       rax, [rip + 0x39c6a18]
0x00014332a958:  48894598              mov       qword ptr [rbp - 0x68], rax
0x00014332a95c:  488955a0              mov       qword ptr [rbp - 0x60], rdx
0x00014332a960:  48894da8              mov       qword ptr [rbp - 0x58], rcx
0x00014332a964:  488d4598              lea       rax, [rbp - 0x68]
0x00014332a968:  488945d0              mov       qword ptr [rbp - 0x30], rax
0x00014332a96c:  41b801000000          mov       r8d, 1
0x00014332a972:  488d5598              lea       rdx, [rbp - 0x68]
0x00014332a976:  498bc9                mov       rcx, r9
0x00014332a979:  e8f2f5de00            call      0x144119f70
0x00014332a97e:  90                    nop       
0x00014332a97f:  488b4c2470            mov       rcx, qword ptr [rsp + 0x70]
0x00014332a984:  4885c9                test      rcx, rcx
0x00014332a987:  7405                  je        0x14332a98e
0x00014332a989:  e882e549fd            call      0x1407c8f10
0x00014332a98e:  488b4d58              mov       rcx, qword ptr [rbp + 0x58]
0x00014332a992:  4833cc                xor       rcx, rsp
0x00014332a995:  e8466c7f02            call      0x145b215e0
0x00014332a99a:  4c8d9c2470010000      lea       r11, [rsp + 0x170]
0x00014332a9a2:  498b5b20              mov       rbx, qword ptr [r11 + 0x20]
0x00014332a9a6:  498b7338              mov       rsi, qword ptr [r11 + 0x38]
0x00014332a9aa:  410f2873f0            movaps    xmm6, xmmword ptr [r11 - 0x10]
0x00014332a9af:  498be3                mov       rsp, r11
0x00014332a9b2:  415e                  pop       r14
0x00014332a9b4:  5f                    pop       rdi
0x00014332a9b5:  5d                    pop       rbp
0x00014332a9b6:  c3                    ret       
0x00014332a9b7:  e8646b8202            call      0x145b51520
0x00014332a9bc:  90                    nop       
0x00014332a9bd:  cc                    int3      
0x00014332a9be:  cc                    int3      
0x00014332a9bf:  cc                    int3      
