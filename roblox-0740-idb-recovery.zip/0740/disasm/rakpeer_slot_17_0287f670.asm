; RakPeer vtable slot 17
; rva 0x287f670
0x14287f670:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x14287f675:  48896c2410           mov       qword ptr [rsp + 0x10], rbp
0x14287f67a:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x14287f67f:  57                   push      rdi
0x14287f680:  4881ecc0000000       sub       rsp, 0xc0
0x14287f687:  498bf0               mov       rsi, r8
0x14287f68a:  488bda               mov       rbx, rdx
0x14287f68d:  4d85c0               test      r8, r8
0x14287f690:  0f8456030000         je        0x14287f9ec
0x14287f696:  4883b95003000000     cmp       qword ptr [rcx + 0x350], 0
0x14287f69e:  0f8442030000         je        0x14287f9e6
0x14287f6a4:  0fb68108010000       movzx     eax, byte ptr [rcx + 0x108]
0x14287f6ab:  90                   nop       
0x14287f6ac:  3c01                 cmp       al, 1
0x14287f6ae:  0f8432030000         je        0x14287f9e6
0x14287f6b4:  33ff                 xor       edi, edi
0x14287f6b6:  48897c2428           mov       qword ptr [rsp + 0x28], rdi
0x14287f6bb:  48897c2420           mov       qword ptr [rsp + 0x20], rdi
0x14287f6c0:  48897c2438           mov       qword ptr [rsp + 0x38], rdi
0x14287f6c5:  48897c2430           mov       qword ptr [rsp + 0x30], rdi
0x14287f6ca:  488b01               mov       rax, qword ptr [rcx]
0x14287f6cd:  4c8d442430           lea       r8, [rsp + 0x30]
0x14287f6d2:  488d542420           lea       rdx, [rsp + 0x20]
0x14287f6d7:  488b8020010000       mov       rax, qword ptr [rax + 0x120]
0x14287f6de:  ff1554068c03         call      qword ptr [rip + 0x38c0654]
0x14287f6e4:  4885db               test      rbx, rbx
0x14287f6e7:  7464                 je        0x14287f74d
0x14287f6e9:  440fb7c7             movzx     r8d, di
0x14287f6ed:  663b3e               cmp       di, word ptr [rsi]
0x14287f6f0:  7355                 jae       0x14287f747
0x14287f6f2:  448b4c2428           mov       r9d, dword ptr [rsp + 0x28]
0x14287f6f7:  410fb7c0             movzx     eax, r8w
0x14287f6fb:  413bc1               cmp       eax, r9d
0x14287f6fe:  7347                 jae       0x14287f747
0x14287f700:  410fb7d0             movzx     edx, r8w
0x14287f704:  48c1e205             shl       rdx, 5
0x14287f708:  488b4c2420           mov       rcx, qword ptr [rsp + 0x20]
0x14287f70d:  0f10040a             movups    xmm0, xmmword ptr [rdx + rcx]
0x14287f711:  0f11041a             movups    xmmword ptr [rdx + rbx], xmm0
0x14287f715:  f20f104c0a10         movsd     xmm1, qword ptr [rdx + rcx + 0x10]
0x14287f71b:  f20f114c1a10         movsd     qword ptr [rdx + rbx + 0x10], xmm1
0x14287f721:  8b440a18             mov       eax, dword ptr [rdx + rcx + 0x18]
0x14287f725:  89441a18             mov       dword ptr [rdx + rbx + 0x18], eax
0x14287f729:  0fb7440a1e           movzx     eax, word ptr [rdx + rcx + 0x1e]
0x14287f72e:  6689441a1e           mov       word ptr [rdx + rbx + 0x1e], ax
0x14287f733:  0fb7440a1c           movzx     eax, word ptr [rdx + rcx + 0x1c]
0x14287f738:  6689441a1c           mov       word ptr [rdx + rbx + 0x1c], ax
0x14287f73d:  6641ffc0             inc       r8w
0x14287f741:  66443b06             cmp       r8w, word ptr [rsi]
0x14287f745:  72b0                 jb        0x14287f6f7
0x14287f747:  66448906             mov       word ptr [rsi], r8w
0x14287f74b:  eb08                 jmp       0x14287f755
0x14287f74d:  0fb7442428           movzx     eax, word ptr [rsp + 0x28]
0x14287f752:  668906               mov       word ptr [rsi], ax
0x14287f755:  488d2d34c71106       lea       rbp, [rip + 0x611c734]
0x14287f75c:  837c243c00           cmp       dword ptr [rsp + 0x3c], 0
0x14287f761:  0f8639010000         jbe       0x14287f8a0
0x14287f767:  4c8b542430           mov       r10, qword ptr [rsp + 0x30]
0x14287f76c:  4d85d2               test      r10, r10
0x14287f76f:  0f842b010000         je        0x14287f8a0
0x14287f775:  0fb6058fa59805       movzx     eax, byte ptr [rip + 0x598a58f]
0x14287f77c:  90                   nop       
0x14287f77d:  498bca               mov       rcx, r10
0x14287f780:  84c0                 test      al, al
0x14287f782:  740a                 je        0x14287f78e
0x14287f784:  e817bbf3fd           call      0x1407bb2a0
0x14287f789:  e912010000           jmp       0x14287f8a0
0x14287f78e:  48c1e910             shr       rcx, 0x10
0x14287f792:  488bd1               mov       rdx, rcx
0x14287f795:  81e2ff1f0000         and       edx, 0x1fff
0x14287f79b:  48c1e90d             shr       rcx, 0xd
0x14287f79f:  488b05da1a9305       mov       rax, qword ptr [rip + 0x5931ada]
0x14287f7a6:  488b0cc8             mov       rcx, qword ptr [rax + rcx*8]
0x14287f7aa:  90                   nop       
0x14287f7ab:  488b0cd1             mov       rcx, qword ptr [rcx + rdx*8]
0x14287f7af:  4885c9               test      rcx, rcx
0x14287f7b2:  7505                 jne       0x14287f7b9
0x14287f7b4:  488bf7               mov       rsi, rdi
0x14287f7b7:  eb1a                 jmp       0x14287f7d3
0x14287f7b9:  488b01               mov       rax, qword ptr [rcx]
0x14287f7bc:  d0e8                 shr       al, 1
0x14287f7be:  a801                 test      al, 1
0x14287f7c0:  7506                 jne       0x14287f7c8
0x14287f7c2:  488b7128             mov       rsi, qword ptr [rcx + 0x28]
0x14287f7c6:  eb0b                 jmp       0x14287f7d3
0x14287f7c8:  498bd2               mov       rdx, r10
0x14287f7cb:  e8d0bff3fd           call      0x1407bb7a0
0x14287f7d0:  488bf0               mov       rsi, rax
0x14287f7d3:  4c8bc6               mov       r8, rsi
0x14287f7d6:  498bd2               mov       rdx, r10
0x14287f7d9:  488d4c2440           lea       rcx, [rsp + 0x40]
0x14287f7de:  e81d071002           call      0x14497ff00
0x14287f7e3:  0f1000               movups    xmm0, xmmword ptr [rax]
0x14287f7e6:  0f11442468           movups    xmmword ptr [rsp + 0x68], xmm0
0x14287f7eb:  4c8d460f             lea       r8, [rsi + 0xf]
0x14287f7ef:  4983e0f0             and       r8, 0xfffffffffffffff0
0x14287f7f3:  4983c010             add       r8, 0x10
0x14287f7f7:  660f7ec0             movd      eax, xmm0
0x14287f7fb:  3d00040000           cmp       eax, 0x400
0x14287f800:  7218                 jb        0x14287f81a
0x14287f802:  803d8aa9980500       cmp       byte ptr [rip + 0x598a98a], 0
0x14287f809:  7445                 je        0x14287f850
0x14287f80b:  803d36edd40500       cmp       byte ptr [rip + 0x5d4ed36], 0
0x14287f812:  0f85ef010000         jne       0x14287fa07
0x14287f818:  eb36                 jmp       0x14287f850
0x14287f81a:  498bd0               mov       rdx, r8
0x14287f81d:  48f7da               neg       rdx
0x14287f820:  8bc8                 mov       ecx, eax
0x14287f822:  48c1e106             shl       rcx, 6
0x14287f826:  488bc2               mov       rax, rdx
0x14287f829:  f0480fc10429         lock xadd qword ptr [rcx + rbp], rax
0x14287f82f:  0fb60d79aee405       movzx     ecx, byte ptr [rip + 0x5e4ae79]
0x14287f836:  90                   nop       
0x14287f837:  84c9                 test      cl, cl
0x14287f839:  7415                 je        0x14287f850
0x14287f83b:  488b0546c61206       mov       rax, qword ptr [rip + 0x612c646]
0x14287f842:  4c3bc0               cmp       r8, rax
0x14287f845:  7309                 jae       0x14287f850
0x14287f847:  f0480fc11538c61206   lock xadd qword ptr [rip + 0x612c638], rdx
0x14287f850:  498bca               mov       rcx, r10
0x14287f853:  e848baf3fd           call      0x1407bb2a0
0x14287f858:  803d5caee40500       cmp       byte ptr [rip + 0x5e4ae5c], 0
0x14287f85f:  7420                 je        0x14287f881
0x14287f861:  e8dae40e02           call      0x14496dd40
0x14287f866:  488bd8               mov       rbx, rax
0x14287f869:  ff4004               inc       dword ptr [rax + 4]
0x14287f86c:  0f57c0               xorps     xmm0, xmm0
0x14287f86f:  e84c612e03           call      0x145b659c0
0x14287f874:  48c1f804             sar       rax, 4
0x14287f878:  01431c               add       dword ptr [rbx + 0x1c], eax
0x14287f87b:  48017310             add       qword ptr [rbx + 0x10], rsi
0x14287f87f:  eb1f                 jmp       0x14287f8a0
0x14287f881:  ff0555821506         inc       dword ptr [rip + 0x6158255]
0x14287f887:  0f57c0               xorps     xmm0, xmm0
0x14287f88a:  e831612e03           call      0x145b659c0
0x14287f88f:  48c1f804             sar       rax, 4
0x14287f893:  01055b821506         add       dword ptr [rip + 0x615825b], eax
0x14287f899:  48013548821506       add       qword ptr [rip + 0x6158248], rsi
0x14287f8a0:  837c242c00           cmp       dword ptr [rsp + 0x2c], 0
0x14287f8a5:  0f8637010000         jbe       0x14287f9e2
0x14287f8ab:  4c8b542420           mov       r10, qword ptr [rsp + 0x20]
0x14287f8b0:  4d85d2               test      r10, r10
0x14287f8b3:  0f8429010000         je        0x14287f9e2
0x14287f8b9:  0fb6054ba49805       movzx     eax, byte ptr [rip + 0x598a44b]
0x14287f8c0:  90                   nop       
0x14287f8c1:  498bca               mov       rcx, r10
0x14287f8c4:  84c0                 test      al, al
0x14287f8c6:  740a                 je        0x14287f8d2
0x14287f8c8:  e8d3b9f3fd           call      0x1407bb2a0
0x14287f8cd:  e910010000           jmp       0x14287f9e2
0x14287f8d2:  48c1e910             shr       rcx, 0x10
0x14287f8d6:  488bd1               mov       rdx, rcx
0x14287f8d9:  81e2ff1f0000         and       edx, 0x1fff
0x14287f8df:  48c1e90d             shr       rcx, 0xd
0x14287f8e3:  488b0596199305       mov       rax, qword ptr [rip + 0x5931996]
0x14287f8ea:  488b0cc8             mov       rcx, qword ptr [rax + rcx*8]
0x14287f8ee:  90                   nop       
0x14287f8ef:  488b0cd1             mov       rcx, qword ptr [rcx + rdx*8]
0x14287f8f3:  4885c9               test      rcx, rcx
0x14287f8f6:  741a                 je        0x14287f912
0x14287f8f8:  488b01               mov       rax, qword ptr [rcx]
0x14287f8fb:  d0e8                 shr       al, 1
0x14287f8fd:  a801                 test      al, 1
0x14287f8ff:  7506                 jne       0x14287f907
0x14287f901:  488b7928             mov       rdi, qword ptr [rcx + 0x28]
0x14287f905:  eb0b                 jmp       0x14287f912
0x14287f907:  498bd2               mov       rdx, r10
0x14287f90a:  e891bef3fd           call      0x1407bb7a0
0x14287f90f:  488bf8               mov       rdi, rax
0x14287f912:  4c8bc7               mov       r8, rdi
0x14287f915:  498bd2               mov       rdx, r10
0x14287f918:  488d4c2450           lea       rcx, [rsp + 0x50]
0x14287f91d:  e8de051002           call      0x14497ff00
0x14287f922:  0f1000               movups    xmm0, xmmword ptr [rax]
0x14287f925:  0f11842498000000     movups    xmmword ptr [rsp + 0x98], xmm0
0x14287f92d:  4c8d470f             lea       r8, [rdi + 0xf]
0x14287f931:  4983e0f0             and       r8, 0xfffffffffffffff0
0x14287f935:  4983c010             add       r8, 0x10
0x14287f939:  660f7ec0             movd      eax, xmm0
0x14287f93d:  3d00040000           cmp       eax, 0x400
0x14287f942:  7218                 jb        0x14287f95c
0x14287f944:  803d48a8980500       cmp       byte ptr [rip + 0x598a848], 0
0x14287f94b:  7445                 je        0x14287f992
0x14287f94d:  803df4ebd40500       cmp       byte ptr [rip + 0x5d4ebf4], 0
0x14287f954:  0f85bc000000         jne       0x14287fa16
0x14287f95a:  eb36                 jmp       0x14287f992
0x14287f95c:  498bd0               mov       rdx, r8
0x14287f95f:  48f7da               neg       rdx
0x14287f962:  8bc8                 mov       ecx, eax
0x14287f964:  48c1e106             shl       rcx, 6
0x14287f968:  488bc2               mov       rax, rdx
0x14287f96b:  f0480fc10429         lock xadd qword ptr [rcx + rbp], rax
0x14287f971:  0fb60d37ade405       movzx     ecx, byte ptr [rip + 0x5e4ad37]
0x14287f978:  90                   nop       
0x14287f979:  84c9                 test      cl, cl
0x14287f97b:  7415                 je        0x14287f992
0x14287f97d:  488b0504c51206       mov       rax, qword ptr [rip + 0x612c504]
0x14287f984:  4c3bc0               cmp       r8, rax
0x14287f987:  7309                 jae       0x14287f992
0x14287f989:  f0480fc115f6c41206   lock xadd qword ptr [rip + 0x612c4f6], rdx
0x14287f992:  498bca               mov       rcx, r10
0x14287f995:  e806b9f3fd           call      0x1407bb2a0
0x14287f99a:  803d1aade40500       cmp       byte ptr [rip + 0x5e4ad1a], 0
0x14287f9a1:  7420                 je        0x14287f9c3
0x14287f9a3:  e898e30e02           call      0x14496dd40
0x14287f9a8:  488bd8               mov       rbx, rax
0x14287f9ab:  ff4004               inc       dword ptr [rax + 4]
0x14287f9ae:  0f57c0               xorps     xmm0, xmm0
0x14287f9b1:  e80a602e03           call      0x145b659c0
0x14287f9b6:  48c1f804             sar       rax, 4
0x14287f9ba:  01431c               add       dword ptr [rbx + 0x1c], eax
0x14287f9bd:  48017b10             add       qword ptr [rbx + 0x10], rdi
0x14287f9c1:  eb1f                 jmp       0x14287f9e2
0x14287f9c3:  ff0513811506         inc       dword ptr [rip + 0x6158113]
0x14287f9c9:  0f57c0               xorps     xmm0, xmm0
0x14287f9cc:  e8ef5f2e03           call      0x145b659c0
0x14287f9d1:  48c1f804             sar       rax, 4
0x14287f9d5:  010519811506         add       dword ptr [rip + 0x6158119], eax
0x14287f9db:  48013d06811506       add       qword ptr [rip + 0x6158106], rdi
0x14287f9e2:  b001                 mov       al, 1
0x14287f9e4:  eb08                 jmp       0x14287f9ee
0x14287f9e6:  33ff                 xor       edi, edi
0x14287f9e8:  66418938             mov       word ptr [r8], di
0x14287f9ec:  32c0                 xor       al, al
0x14287f9ee:  4c8d9c24c0000000     lea       r11, [rsp + 0xc0]
0x14287f9f6:  498b5b10             mov       rbx, qword ptr [r11 + 0x10]
0x14287f9fa:  498b6b18             mov       rbp, qword ptr [r11 + 0x18]
0x14287f9fe:  498b7320             mov       rsi, qword ptr [r11 + 0x20]
0x14287fa02:  498be3               mov       rsp, r11
0x14287fa05:  5f                   pop       rdi
0x14287fa06:  c3                   ret       
0x14287fa07:  488d15d2538504       lea       rdx, [rip + 0x48553d2]
0x14287fa0e:  33c9                 xor       ecx, ecx
0x14287fa10:  e86bf20d02           call      0x14495ec80
0x14287fa15:  90                   nop       
0x14287fa16:  488d15c3538504       lea       rdx, [rip + 0x48553c3]
0x14287fa1d:  33c9                 xor       ecx, ecx
0x14287fa1f:  e85cf20d02           call      0x14495ec80
0x14287fa24:  cc                   int3      
0x14287fa25:  cc                   int3      
0x14287fa26:  cc                   int3      
0x14287fa27:  cc                   int3      
0x14287fa28:  cc                   int3      
0x14287fa29:  cc                   int3      
0x14287fa2a:  cc                   int3      
0x14287fa2b:  cc                   int3      
0x14287fa2c:  cc                   int3      
0x14287fa2d:  cc                   int3      
0x14287fa2e:  cc                   int3      
0x14287fa2f:  cc                   int3      
0x14287fa30:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x14287fa35:  57                   push      rdi
0x14287fa36:  4883ec20             sub       rsp, 0x20
0x14287fa3a:  488db9d80c0000       lea       rdi, [rcx + 0xcd8]
0x14287fa41:  488bd9               mov       rbx, rcx
0x14287fa44:  488bcf               mov       rcx, rdi
0x14287fa47:  e8643d2a03           call      0x145b237b0
0x14287fa4c:  85c0                 test      eax, eax
0x14287fa4e:  751b                 jne       0x14287fa6b
0x14287fa50:  8b9b280d0000         mov       ebx, dword ptr [rbx + 0xd28]
0x14287fa56:  488bcf               mov       rcx, rdi
0x14287fa59:  e8b23d2a03           call      0x145b23810
0x14287fa5e:  8bc3                 mov       eax, ebx
0x14287fa60:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14287fa65:  4883c420             add       rsp, 0x20
0x14287fa69:  5f                   pop       rdi
0x14287fa6a:  c3                   ret       
0x14287fa6b:  8bc8                 mov       ecx, eax
0x14287fa6d:  e80e432a03           call      0x145b23d80
0x14287fa72:  cc                   int3      
0x14287fa73:  cc                   int3      
0x14287fa74:  cc                   int3      
0x14287fa75:  cc                   int3      
0x14287fa76:  cc                   int3      
0x14287fa77:  cc                   int3      
0x14287fa78:  cc                   int3      
0x14287fa79:  cc                   int3      
0x14287fa7a:  cc                   int3      
0x14287fa7b:  cc                   int3      
0x14287fa7c:  cc                   int3      
0x14287fa7d:  cc                   int3      
0x14287fa7e:  cc                   int3      
0x14287fa7f:  cc                   int3      
0x14287fa80:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x14287fa85:  57                   push      rdi
0x14287fa86:  4883ec20             sub       rsp, 0x20
0x14287fa8a:  488bf9               mov       rdi, rcx
0x14287fa8d:  4881c1d80c0000       add       rcx, 0xcd8
0x14287fa94:  e8173d2a03           call      0x145b237b0
0x14287fa99:  85c0                 test      eax, eax
0x14287fa9b:  753c                 jne       0x14287fad9
0x14287fa9d:  b801000000           mov       eax, 1
0x14287faa2:  48895c2430           mov       qword ptr [rsp + 0x30], rbx
0x14287faa7:  8b9f280d0000         mov       ebx, dword ptr [rdi + 0xd28]
0x14287faad:  488d8fd80c0000       lea       rcx, [rdi + 0xcd8]
0x14287fab4:  8d5301               lea       edx, [rbx + 1]
0x14287fab7:  85d2                 test      edx, edx
0x14287fab9:  0f44d0               cmove     edx, eax
0x14287fabc:  8997280d0000         mov       dword ptr [rdi + 0xd28], edx
0x14287fac2:  e8493d2a03           call      0x145b23810
0x14287fac7:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x14287facc:  8bc3                 mov       eax, ebx
0x14287face:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14287fad3:  4883c420             add       rsp, 0x20
0x14287fad7:  5f                   pop       rdi
0x14287fad8:  c3                   ret       
0x14287fad9:  8bc8                 mov       ecx, eax
0x14287fadb:  e8a0422a03           call      0x145b23d80
0x14287fae0:  cc                   int3      
0x14287fae1:  cc                   int3      
0x14287fae2:  cc                   int3      
0x14287fae3:  cc                   int3      
0x14287fae4:  cc                   int3      
0x14287fae5:  cc                   int3      
0x14287fae6:  cc                   int3      
0x14287fae7:  cc                   int3      
0x14287fae8:  cc                   int3      
0x14287fae9:  cc                   int3      
0x14287faea:  cc                   int3      
0x14287faeb:  cc                   int3      
0x14287faec:  cc                   int3      
0x14287faed:  cc                   int3      
0x14287faee:  cc                   int3      
0x14287faef:  cc                   int3      
