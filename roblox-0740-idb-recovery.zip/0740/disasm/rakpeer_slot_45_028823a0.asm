; RakPeer vtable slot 45
; rva 0x28823a0
0x1428823a0:  48895c2410           mov       qword ptr [rsp + 0x10], rbx
0x1428823a5:  57                   push      rdi
0x1428823a6:  4883ec70             sub       rsp, 0x70
0x1428823aa:  8b4228               mov       eax, dword ptr [rdx + 0x28]
0x1428823ad:  4c8bc9               mov       r9, rcx
0x1428823b0:  0f104a10             movups    xmm1, xmmword ptr [rdx + 0x10]
0x1428823b4:  488b3a               mov       rdi, qword ptr [rdx]
0x1428823b7:  483b3daad45605       cmp       rdi, qword ptr [rip + 0x556d4aa]
0x1428823be:  f20f104220           movsd     xmm0, qword ptr [rdx + 0x20]
0x1428823c3:  89442468             mov       dword ptr [rsp + 0x68], eax
0x1428823c7:  0fb7422e             movzx     eax, word ptr [rdx + 0x2e]
0x1428823cb:  668944246e           mov       word ptr [rsp + 0x6e], ax
0x1428823d0:  0fb7422c             movzx     eax, word ptr [rdx + 0x2c]
0x1428823d4:  668944246c           mov       word ptr [rsp + 0x6c], ax
0x1428823d9:  0f114c2450           movups    xmmword ptr [rsp + 0x50], xmm1
0x1428823de:  f20f11442460         movsd     qword ptr [rsp + 0x60], xmm0
0x1428823e4:  7443                 je        0x142882429
0x1428823e6:  440fb78112010000     movzx     r8d, word ptr [rcx + 0x112]
0x1428823ee:  4533db               xor       r11d, r11d
0x1428823f1:  418bd3               mov       edx, r11d
0x1428823f4:  66453bd8             cmp       r11w, r8w
0x1428823f8:  7327                 jae       0x142882421
0x1428823fa:  4c8b9150030000       mov       r10, qword ptr [rcx + 0x350]
0x142882401:  8bc2                 mov       eax, edx
0x142882403:  4869d8d8160000       imul      rbx, rax, 0x16d8
0x14288240a:  4903da               add       rbx, r10
0x14288240d:  4839bb30160000       cmp       qword ptr [rbx + 0x1630], rdi
0x142882414:  0f8455010000         je        0x14288256f
0x14288241a:  ffc2                 inc       edx
0x14288241c:  413bd0               cmp       edx, r8d
0x14288241f:  72e0                 jb        0x142882401
0x142882421:  498bdb               mov       rbx, r11
0x142882424:  e946010000           jmp       0x14288256f
0x142882429:  0f10442460           movups    xmm0, xmmword ptr [rsp + 0x60]
0x14288242e:  440fb7542450         movzx     r10d, word ptr [rsp + 0x50]
0x142882434:  66480f7ec9           movq      rcx, xmm1
0x142882439:  0f294c2420           movaps    xmmword ptr [rsp + 0x20], xmm1
0x14288243e:  488b7c2428           mov       rdi, qword ptr [rsp + 0x28]
0x142882443:  488bc1               mov       rax, rcx
0x142882446:  48c1e810             shr       rax, 0x10
0x14288244a:  663b05f9d35605       cmp       ax, word ptr [rip + 0x556d3f9]
0x142882451:  0f29442430           movaps    xmmword ptr [rsp + 0x30], xmm0
0x142882456:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14288245b:  751d                 jne       0x14288247a
0x14288245d:  66443b15e3d35605     cmp       r10w, word ptr [rip + 0x556d3e3]
0x142882465:  7513                 jne       0x14288247a
0x142882467:  664183fa02           cmp       r10w, 2
0x14288246c:  756c                 jne       0x1428824da
0x14288246e:  48c1e920             shr       rcx, 0x20
0x142882472:  3b0dd4d35605         cmp       ecx, dword ptr [rip + 0x556d3d4]
0x142882478:  7479                 je        0x1428824f3
0x14288247a:  4533db               xor       r11d, r11d
0x14288247d:  4889b42480000000     mov       qword ptr [rsp + 0x80], rsi
0x142882485:  baffffffff           mov       edx, 0xffffffff
0x14288248a:  458bc3               mov       r8d, r11d
0x14288248d:  66453b9912010000     cmp       r11w, word ptr [r9 + 0x112]
0x142882495:  0f83c9000000         jae       0x142882564
0x14288249b:  0f1f440000           nop       dword ptr [rax + rax]
0x1428824a0:  498b8950030000       mov       rcx, qword ptr [r9 + 0x350]
0x1428824a7:  4963c0               movsxd    rax, r8d
0x1428824aa:  4869f0d8160000       imul      rsi, rax, 0x16d8
0x1428824b1:  0fb7442452           movzx     eax, word ptr [rsp + 0x52]
0x1428824b6:  4803ce               add       rcx, rsi
0x1428824b9:  66394106             cmp       word ptr [rcx + 6], ax
0x1428824bd:  756d                 jne       0x14288252c
0x1428824bf:  0fb74104             movzx     eax, word ptr [rcx + 4]
0x1428824c3:  66413bc2             cmp       ax, r10w
0x1428824c7:  7563                 jne       0x14288252c
0x1428824c9:  6683f802             cmp       ax, 2
0x1428824cd:  752c                 jne       0x1428824fb
0x1428824cf:  8b442454             mov       eax, dword ptr [rsp + 0x54]
0x1428824d3:  394108               cmp       dword ptr [rcx + 8], eax
0x1428824d6:  7435                 je        0x14288250d
0x1428824d8:  eb52                 jmp       0x14288252c
0x1428824da:  664183fa17           cmp       r10w, 0x17
0x1428824df:  7599                 jne       0x14288247a
0x1428824e1:  483b3d68d35605       cmp       rdi, qword ptr [rip + 0x556d368]
0x1428824e8:  7590                 jne       0x14288247a
0x1428824ea:  483b1d67d35605       cmp       rbx, qword ptr [rip + 0x556d367]
0x1428824f1:  7587                 jne       0x14288247a
0x1428824f3:  4533db               xor       r11d, r11d
0x1428824f6:  418bdb               mov       ebx, r11d
0x1428824f9:  eb74                 jmp       0x14288256f
0x1428824fb:  6683f817             cmp       ax, 0x17
0x1428824ff:  752b                 jne       0x14288252c
0x142882501:  4839790c             cmp       qword ptr [rcx + 0xc], rdi
0x142882505:  7525                 jne       0x14288252c
0x142882507:  48395914             cmp       qword ptr [rcx + 0x14], rbx
0x14288250b:  751f                 jne       0x14288252c
0x14288250d:  0fb601               movzx     eax, byte ptr [rcx]
0x142882510:  90                   nop       
0x142882511:  84c0                 test      al, al
0x142882513:  7543                 jne       0x142882558
0x142882515:  440fb7542450         movzx     r10d, word ptr [rsp + 0x50]
0x14288251b:  83faff               cmp       edx, -1
0x14288251e:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142882523:  488b7c2428           mov       rdi, qword ptr [rsp + 0x28]
0x142882528:  410f44d0             cmove     edx, r8d
0x14288252c:  410fb78112010000     movzx     eax, word ptr [r9 + 0x112]
0x142882534:  41ffc0               inc       r8d
0x142882537:  443bc0               cmp       r8d, eax
0x14288253a:  0f8260ffffff         jb        0x1428824a0
0x142882540:  83faff               cmp       edx, -1
0x142882543:  741f                 je        0x142882564
0x142882545:  4863c2               movsxd    rax, edx
0x142882548:  4869d8d8160000       imul      rbx, rax, 0x16d8
0x14288254f:  49039950030000       add       rbx, qword ptr [r9 + 0x350]
0x142882556:  eb0f                 jmp       0x142882567
0x142882558:  498b9950030000       mov       rbx, qword ptr [r9 + 0x350]
0x14288255f:  4803de               add       rbx, rsi
0x142882562:  eb03                 jmp       0x142882567
0x142882564:  498bdb               mov       rbx, r11
0x142882567:  488bb42480000000     mov       rsi, qword ptr [rsp + 0x80]
0x14288256f:  4885db               test      rbx, rbx
0x142882572:  7511                 jne       0x142882585
0x142882574:  8d43ff               lea       eax, [rbx - 1]
0x142882577:  488b9c2488000000     mov       rbx, qword ptr [rsp + 0x88]
0x14288257f:  4883c470             add       rsp, 0x70
0x142882583:  5f                   pop       rdi
0x142882584:  c3                   ret       
0x142882585:  498db9a80e0000       lea       rdi, [r9 + 0xea8]
0x14288258c:  488bcf               mov       rcx, rdi
0x14288258f:  e81c122a03           call      0x145b237b0
0x142882594:  85c0                 test      eax, eax
0x142882596:  751d                 jne       0x1428825b5
0x142882598:  0fb75b02             movzx     ebx, word ptr [rbx + 2]
0x14288259c:  488bcf               mov       rcx, rdi
0x14288259f:  90                   nop       
0x1428825a0:  e86b122a03           call      0x145b23810
0x1428825a5:  8bc3                 mov       eax, ebx
0x1428825a7:  488b9c2488000000     mov       rbx, qword ptr [rsp + 0x88]
0x1428825af:  4883c470             add       rsp, 0x70
0x1428825b3:  5f                   pop       rdi
0x1428825b4:  c3                   ret       
0x1428825b5:  8bc8                 mov       ecx, eax
0x1428825b7:  e8c4172a03           call      0x145b23d80
0x1428825bc:  cc                   int3      
0x1428825bd:  cc                   int3      
0x1428825be:  cc                   int3      
0x1428825bf:  cc                   int3      
0x1428825c0:  889110010000         mov       byte ptr [rcx + 0x110], dl
0x1428825c6:  c3                   ret       
0x1428825c7:  cc                   int3      
0x1428825c8:  cc                   int3      
0x1428825c9:  cc                   int3      
0x1428825ca:  cc                   int3      
0x1428825cb:  cc                   int3      
0x1428825cc:  cc                   int3      
0x1428825cd:  cc                   int3      
0x1428825ce:  cc                   int3      
0x1428825cf:  cc                   int3      
0x1428825d0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x1428825d5:  48896c2410           mov       qword ptr [rsp + 0x10], rbp
0x1428825da:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x1428825df:  57                   push      rdi
0x1428825e0:  4883ec20             sub       rsp, 0x20
0x1428825e4:  488bd9               mov       rbx, rcx
0x1428825e7:  418bf8               mov       edi, r8d
0x1428825ea:  4881c1f8030000       add       rcx, 0x3f8
0x1428825f1:  488bea               mov       rbp, rdx
0x1428825f4:  e8b7112a03           call      0x145b237b0
0x1428825f9:  85c0                 test      eax, eax
0x1428825fb:  757a                 jne       0x142882677
0x1428825fd:  898328010000         mov       dword ptr [rbx + 0x128], eax
0x142882603:  898330010000         mov       dword ptr [rbx + 0x130], eax
0x142882609:  888320010000         mov       byte ptr [rbx + 0x120], al
0x14288260f:  4885ed               test      rbp, rbp
0x142882612:  7443                 je        0x142882657
0x142882614:  85ff                 test      edi, edi
0x142882616:  743f                 je        0x142882657
0x142882618:  8d14fd00000000       lea       edx, [rdi*8]
0x14288261f:  488d8b18010000       lea       rcx, [rbx + 0x118]
0x142882626:  e8a53a0200           call      0x1428a60d0
0x14288262b:  8b8b28010000         mov       ecx, dword ptr [rbx + 0x128]
0x142882631:  448bc7               mov       r8d, edi
0x142882634:  83c107               add       ecx, 7
0x142882637:  488bd5               mov       rdx, rbp
0x14288263a:  48c1e903             shr       rcx, 3
0x14288263e:  48038b38010000       add       rcx, qword ptr [rbx + 0x138]
0x142882645:  e8560b2c03           call      0x145b431a0
0x14288264a:  8d04fd00000000       lea       eax, [rdi*8]
0x142882651:  018328010000         add       dword ptr [rbx + 0x128], eax
0x142882657:  488d8bf8030000       lea       rcx, [rbx + 0x3f8]
0x14288265e:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142882663:  488b6c2438           mov       rbp, qword ptr [rsp + 0x38]
0x142882668:  488b742440           mov       rsi, qword ptr [rsp + 0x40]
0x14288266d:  4883c420             add       rsp, 0x20
0x142882671:  5f                   pop       rdi
0x142882672:  e999112a03           jmp       0x145b23810
0x142882677:  8bc8                 mov       ecx, eax
0x142882679:  e802172a03           call      0x145b23d80
0x14288267e:  cc                   int3      
0x14288267f:  cc                   int3      
0x142882680:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x142882685:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x14288268a:  48897c2418           mov       qword ptr [rsp + 0x18], rdi
0x14288268f:  4156                 push      r14
0x142882691:  4883ec20             sub       rsp, 0x20
0x142882695:  488bd9               mov       rbx, rcx
0x142882698:  498bf0               mov       rsi, r8
0x14288269b:  4881c1f8030000       add       rcx, 0x3f8
0x1428826a2:  4c8bf2               mov       r14, rdx
0x1428826a5:  e806112a03           call      0x145b237b0
0x1428826aa:  85c0                 test      eax, eax
0x1428826ac:  7556                 jne       0x142882704
0x1428826ae:  488b8318010000       mov       rax, qword ptr [rbx + 0x118]
0x1428826b5:  488d8b18010000       lea       rcx, [rbx + 0x118]
0x1428826bc:  488b4008             mov       rax, qword ptr [rax + 8]
0x1428826c0:  ff1572d68b03         call      qword ptr [rip + 0x38bd672]
0x1428826c6:  498906               mov       qword ptr [r14], rax
0x1428826c9:  488d8b18010000       lea       rcx, [rbx + 0x118]
0x1428826d0:  488b8318010000       mov       rax, qword ptr [rbx + 0x118]
0x1428826d7:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x1428826db:  ff1557d68b03         call      qword ptr [rip + 0x38bd657]
0x1428826e1:  488d8bf8030000       lea       rcx, [rbx + 0x3f8]
0x1428826e8:  8906                 mov       dword ptr [rsi], eax
0x1428826ea:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x1428826ef:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x1428826f4:  488b7c2440           mov       rdi, qword ptr [rsp + 0x40]
0x1428826f9:  4883c420             add       rsp, 0x20
0x1428826fd:  415e                 pop       r14
0x1428826ff:  e90c112a03           jmp       0x145b23810
0x142882704:  8bc8                 mov       ecx, eax
0x142882706:  e875162a03           call      0x145b23d80
0x14288270b:  cc                   int3      
0x14288270c:  cc                   int3      
0x14288270d:  cc                   int3      
0x14288270e:  cc                   int3      
0x14288270f:  cc                   int3      
0x142882710:  48896c2420           mov       qword ptr [rsp + 0x20], rbp
0x142882715:  56                   push      rsi
0x142882716:  57                   push      rdi
0x142882717:  4156                 push      r14
0x142882719:  4883ec20             sub       rsp, 0x20
0x14288271d:  0fb72d26d15605       movzx     ebp, word ptr [rip + 0x556d126]
0x142882724:  4c8bda               mov       r11, rdx
0x142882727:  4c8bd1               mov       r10, rcx
0x14288272a:  488b3527d15605       mov       rsi, qword ptr [rip + 0x556d127]
0x142882731:  488b3d18d15605       mov       rdi, qword ptr [rip + 0x556d118]
0x142882738:  8b0d0ed15605         mov       ecx, dword ptr [rip + 0x556d10e]
0x14288273e:  0fb71503d15605       movzx     edx, word ptr [rip + 0x556d103]
0x142882745:  4d63f1               movsxd    r14, r9d
0x142882748:  6641396802           cmp       word ptr [r8 + 2], bp
0x14288274d:  7515                 jne       0x142882764
0x14288274f:  410fb700             movzx     eax, word ptr [r8]
0x142882753:  663bc2               cmp       ax, dx
0x142882756:  750c                 jne       0x142882764
0x142882758:  6683f802             cmp       ax, 2
0x14288275c:  7550                 jne       0x1428827ae
0x14288275e:  41394804             cmp       dword ptr [r8 + 4], ecx
0x142882762:  745c                 je        0x1428827c0
0x142882764:  410f1008             movups    xmm1, xmmword ptr [r8]
0x142882768:  48895c2440           mov       qword ptr [rsp + 0x40], rbx
0x14288276d:  410f104010           movups    xmm0, xmmword ptr [r8 + 0x10]
0x142882772:  66490f7ec8           movq      r8, xmm1
0x142882777:  0f290c24             movaps    xmmword ptr [rsp], xmm1
0x14288277b:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882780:  498bc0               mov       rax, r8
0x142882783:  48c1e810             shr       rax, 0x10
0x142882787:  0f29442410           movaps    xmmword ptr [rsp + 0x10], xmm0
0x14288278c:  4c8b4c2410           mov       r9, qword ptr [rsp + 0x10]
0x142882791:  663bc5               cmp       ax, bp
0x142882794:  7561                 jne       0x1428827f7
0x142882796:  66443bc2             cmp       r8w, dx
0x14288279a:  755b                 jne       0x1428827f7
0x14288279c:  664183f802           cmp       r8w, 2
0x1428827a1:  753f                 jne       0x1428827e2
0x1428827a3:  498bc0               mov       rax, r8
0x1428827a6:  48c1e820             shr       rax, 0x20
0x1428827aa:  3bc1                 cmp       eax, ecx
0x1428827ac:  eb43                 jmp       0x1428827f1
0x1428827ae:  6683f817             cmp       ax, 0x17
0x1428827b2:  75b0                 jne       0x142882764
0x1428827b4:  49397808             cmp       qword ptr [r8 + 8], rdi
0x1428827b8:  75aa                 jne       0x142882764
0x1428827ba:  49397010             cmp       qword ptr [r8 + 0x10], rsi
0x1428827be:  75a4                 jne       0x142882764
0x1428827c0:  498bce               mov       rcx, r14
0x1428827c3:  48c1e105             shl       rcx, 5
0x1428827c7:  420f10841190090000   movups    xmm0, xmmword ptr [rcx + r10 + 0x990]
0x1428827d0:  410f1103             movups    xmmword ptr [r11], xmm0
0x1428827d4:  420f108c11a0090000   movups    xmm1, xmmword ptr [rcx + r10 + 0x9a0]
0x1428827dd:  e9a8000000           jmp       0x14288288a
0x1428827e2:  664183f817           cmp       r8w, 0x17
0x1428827e7:  750e                 jne       0x1428827f7
0x1428827e9:  483bdf               cmp       rbx, rdi
0x1428827ec:  7509                 jne       0x1428827f7
0x1428827ee:  4c3bce               cmp       r9, rsi
0x1428827f1:  0f847c000000         je        0x142882873
0x1428827f7:  33d2                 xor       edx, edx
0x1428827f9:  66413b9212010000     cmp       dx, word ptr [r10 + 0x112]
0x142882801:  7370                 jae       0x142882873
0x142882803:  498b8a50030000       mov       rcx, qword ptr [r10 + 0x350]
0x14288280a:  4863c2               movsxd    rax, edx
0x14288280d:  4869f8d8160000       imul      rdi, rax, 0x16d8
0x142882814:  0fb7442402           movzx     eax, word ptr [rsp + 2]
0x142882819:  4803cf               add       rcx, rdi
0x14288281c:  66394106             cmp       word ptr [rcx + 6], ax
0x142882820:  7543                 jne       0x142882865
0x142882822:  0fb74104             movzx     eax, word ptr [rcx + 4]
0x142882826:  66413bc0             cmp       ax, r8w
0x14288282a:  7539                 jne       0x142882865
0x14288282c:  6683f802             cmp       ax, 2
0x142882830:  750b                 jne       0x14288283d
0x142882832:  8b442404             mov       eax, dword ptr [rsp + 4]
0x142882836:  394108               cmp       dword ptr [rcx + 8], eax
0x142882839:  7414                 je        0x14288284f
0x14288283b:  eb28                 jmp       0x142882865
0x14288283d:  6683f817             cmp       ax, 0x17
0x142882841:  7522                 jne       0x142882865
0x142882843:  4839590c             cmp       qword ptr [rcx + 0xc], rbx
0x142882847:  751c                 jne       0x142882865
0x142882849:  4c394914             cmp       qword ptr [rcx + 0x14], r9
0x14288284d:  7516                 jne       0x142882865
0x14288284f:  0fb601               movzx     eax, byte ptr [rcx]
0x142882852:  90                   nop       
0x142882853:  84c0                 test      al, al
0x142882855:  7549                 jne       0x1428828a0
0x142882857:  4c8b4c2410           mov       r9, qword ptr [rsp + 0x10]
0x14288285c:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882861:  4c8b0424             mov       r8, qword ptr [rsp]
0x142882865:  410fb78212010000     movzx     eax, word ptr [r10 + 0x112]
0x14288286d:  ffc2                 inc       edx
0x14288286f:  3bd0                 cmp       edx, eax
0x142882871:  7290                 jb        0x142882803
0x142882873:  0f1005cecf5605       movups    xmm0, xmmword ptr [rip + 0x556cfce]
0x14288287a:  410f1103             movups    xmmword ptr [r11], xmm0
0x14288287e:  0f100dd3cf5605       movups    xmm1, xmmword ptr [rip + 0x556cfd3]
0x142882885:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x14288288a:  488b6c2458           mov       rbp, qword ptr [rsp + 0x58]
0x14288288f:  498bc3               mov       rax, r11
0x142882892:  410f114b10           movups    xmmword ptr [r11 + 0x10], xmm1
0x142882897:  4883c420             add       rsp, 0x20
0x14288289b:  415e                 pop       r14
0x14288289d:  5f                   pop       rdi
0x14288289e:  5e                   pop       rsi
0x14288289f:  c3                   ret       
0x1428828a0:  498b8a50030000       mov       rcx, qword ptr [r10 + 0x350]
0x1428828a7:  4803cf               add       rcx, rdi
0x1428828aa:  74c7                 je        0x142882873
0x1428828ac:  498bc6               mov       rax, r14
0x1428828af:  48c1e005             shl       rax, 5
0x1428828b3:  0f10440844           movups    xmm0, xmmword ptr [rax + rcx + 0x44]
0x1428828b8:  410f1103             movups    xmmword ptr [r11], xmm0
0x1428828bc:  0f104c0854           movups    xmm1, xmmword ptr [rax + rcx + 0x54]
0x1428828c1:  ebc2                 jmp       0x142882885
0x1428828c3:  cc                   int3      
0x1428828c4:  cc                   int3      
0x1428828c5:  cc                   int3      
0x1428828c6:  cc                   int3      
0x1428828c7:  cc                   int3      
0x1428828c8:  cc                   int3      
0x1428828c9:  cc                   int3      
0x1428828ca:  cc                   int3      
0x1428828cb:  cc                   int3      
0x1428828cc:  cc                   int3      
0x1428828cd:  cc                   int3      
0x1428828ce:  cc                   int3      
0x1428828cf:  cc                   int3      
0x1428828d0:  0f108140090000       movups    xmm0, xmmword ptr [rcx + 0x940]
0x1428828d7:  488bc2               mov       rax, rdx
0x1428828da:  0f1102               movups    xmmword ptr [rdx], xmm0
0x1428828dd:  c3                   ret       
0x1428828de:  cc                   int3      
0x1428828df:  cc                   int3      
0x1428828e0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x1428828e5:  57                   push      rdi
0x1428828e6:  4883ec30             sub       rsp, 0x30
0x1428828ea:  418bd8               mov       ebx, r8d
0x1428828ed:  488bfa               mov       rdi, rdx
0x1428828f0:  33c0                 xor       eax, eax
0x1428828f2:  4889442428           mov       qword ptr [rsp + 0x28], rax
0x1428828f7:  4889442420           mov       qword ptr [rsp + 0x20], rax
0x1428828fc:  488b01               mov       rax, qword ptr [rcx]
0x1428828ff:  488d542420           lea       rdx, [rsp + 0x20]
0x142882904:  488b8028020000       mov       rax, qword ptr [rax + 0x228]
0x14288290b:  ff1527d48b03         call      qword ptr [rip + 0x38bd427]
0x142882911:  837c242800           cmp       dword ptr [rsp + 0x28], 0
0x142882916:  7660                 jbe       0x142882978
0x142882918:  8bc3                 mov       eax, ebx
0x14288291a:  4803c0               add       rax, rax
0x14288291d:  4c8b542420           mov       r10, qword ptr [rsp + 0x20]
0x142882922:  498b0cc2             mov       rcx, qword ptr [r10 + rax*8]
0x142882926:  0f10410c             movups    xmm0, xmmword ptr [rcx + 0xc]
0x14288292a:  0f1107               movups    xmmword ptr [rdi], xmm0
0x14288292d:  0f10491c             movups    xmm1, xmmword ptr [rcx + 0x1c]
0x142882931:  0f114f10             movups    xmmword ptr [rdi + 0x10], xmm1
0x142882935:  837c242c00           cmp       dword ptr [rsp + 0x2c], 0
0x14288293a:  0f8680000000         jbe       0x1428829c0
0x142882940:  4d85d2               test      r10, r10
0x142882943:  747b                 je        0x1428829c0
0x142882945:  498d5af8             lea       rbx, [r10 - 8]
0x142882949:  4c8d0db079f4fd       lea       r9, [rip - 0x20b8650]
0x142882950:  4c8b03               mov       r8, qword ptr [rbx]
0x142882953:  ba10000000           mov       edx, 0x10
0x142882958:  498bca               mov       rcx, r10
0x14288295b:  e850ed2903           call      0x145b216b0
0x142882960:  90                   nop       
0x142882961:  488bcb               mov       rcx, rbx
0x142882964:  e847070c02           call      0x1449430b0
0x142882969:  90                   nop       
0x14288296a:  488bc7               mov       rax, rdi
0x14288296d:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x142882972:  4883c430             add       rsp, 0x30
0x142882976:  5f                   pop       rdi
0x142882977:  c3                   ret       
0x142882978:  0f1005c9ce5605       movups    xmm0, xmmword ptr [rip + 0x556cec9]
0x14288297f:  0f1107               movups    xmmword ptr [rdi], xmm0
0x142882982:  0f100dcfce5605       movups    xmm1, xmmword ptr [rip + 0x556cecf]
0x142882989:  0f114f10             movups    xmmword ptr [rdi + 0x10], xmm1
0x14288298d:  837c242c00           cmp       dword ptr [rsp + 0x2c], 0
0x142882992:  762c                 jbe       0x1428829c0
0x142882994:  488b4c2420           mov       rcx, qword ptr [rsp + 0x20]
0x142882999:  4885c9               test      rcx, rcx
0x14288299c:  7422                 je        0x1428829c0
0x14288299e:  488d59f8             lea       rbx, [rcx - 8]
0x1428829a2:  4c8d0d5779f4fd       lea       r9, [rip - 0x20b86a9]
0x1428829a9:  4c8b03               mov       r8, qword ptr [rbx]
0x1428829ac:  ba10000000           mov       edx, 0x10
0x1428829b1:  e8faec2903           call      0x145b216b0
0x1428829b6:  90                   nop       
0x1428829b7:  488bcb               mov       rcx, rbx
0x1428829ba:  e8f1060c02           call      0x1449430b0
0x1428829bf:  90                   nop       
0x1428829c0:  488bc7               mov       rax, rdi
0x1428829c3:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x1428829c8:  4883c430             add       rsp, 0x30
0x1428829cc:  5f                   pop       rdi
0x1428829cd:  c3                   ret       
0x1428829ce:  cc                   int3      
0x1428829cf:  cc                   int3      
0x1428829d0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x1428829d5:  0fb75a02             movzx     ebx, word ptr [rdx + 2]
0x1428829d9:  4c8bd1               mov       r10, rcx
0x1428829dc:  663b1d67ce5605       cmp       bx, word ptr [rip + 0x556ce67]
0x1428829e3:  7525                 jne       0x142882a0a
0x1428829e5:  0fb702               movzx     eax, word ptr [rdx]
0x1428829e8:  663b0559ce5605       cmp       ax, word ptr [rip + 0x556ce59]
0x1428829ef:  7519                 jne       0x142882a0a
0x1428829f1:  6683f802             cmp       ax, 2
0x1428829f5:  0f85b0000000         jne       0x142882aab
0x1428829fb:  8b054bce5605         mov       eax, dword ptr [rip + 0x556ce4b]
0x142882a01:  394204               cmp       dword ptr [rdx + 4], eax
0x142882a04:  0f84cd000000         je        0x142882ad7
0x142882a0a:  0fb7421e             movzx     eax, word ptr [rdx + 0x1e]
0x142882a0e:  b9ffff0000           mov       ecx, 0xffff
0x142882a13:  663bc1               cmp       ax, cx
0x142882a16:  7440                 je        0x142882a58
0x142882a18:  66413b8212010000     cmp       ax, word ptr [r10 + 0x112]
0x142882a20:  7336                 jae       0x142882a58
0x142882a22:  4c69c0d8160000       imul      r8, rax, 0x16d8
0x142882a29:  4d038250030000       add       r8, qword ptr [r10 + 0x350]
0x142882a30:  6641395806           cmp       word ptr [r8 + 6], bx
0x142882a35:  7521                 jne       0x142882a58
0x142882a37:  410fb74004           movzx     eax, word ptr [r8 + 4]
0x142882a3c:  663b02               cmp       ax, word ptr [rdx]
0x142882a3f:  7517                 jne       0x142882a58
0x142882a41:  6683f802             cmp       ax, 2
0x142882a45:  0f8599000000         jne       0x142882ae4
0x142882a4b:  8b4204               mov       eax, dword ptr [rdx + 4]
0x142882a4e:  41394008             cmp       dword ptr [r8 + 8], eax
0x142882a52:  0f84b2000000         je        0x142882b0a
0x142882a58:  450fb79a12010000     movzx     r11d, word ptr [r10 + 0x112]
0x142882a60:  4533c9               xor       r9d, r9d
0x142882a63:  4585db               test      r11d, r11d
0x142882a66:  0f84d1000000         je        0x142882b3d
0x142882a6c:  4d8b9250030000       mov       r10, qword ptr [r10 + 0x350]
0x142882a73:  418bc1               mov       eax, r9d
0x142882a76:  4c69c0d8160000       imul      r8, rax, 0x16d8
0x142882a7d:  4d03c2               add       r8, r10
0x142882a80:  6641395806           cmp       word ptr [r8 + 6], bx
0x142882a85:  0f85a6000000         jne       0x142882b31
0x142882a8b:  410fb74004           movzx     eax, word ptr [r8 + 4]
0x142882a90:  663b02               cmp       ax, word ptr [rdx]
0x142882a93:  0f8598000000         jne       0x142882b31
0x142882a99:  6683f802             cmp       ax, 2
0x142882a9d:  7578                 jne       0x142882b17
0x142882a9f:  8b4204               mov       eax, dword ptr [rdx + 4]
0x142882aa2:  41394008             cmp       dword ptr [r8 + 8], eax
0x142882aa6:  e984000000           jmp       0x142882b2f
0x142882aab:  6683f817             cmp       ax, 0x17
0x142882aaf:  0f8555ffffff         jne       0x142882a0a
0x142882ab5:  488b4208             mov       rax, qword ptr [rdx + 8]
0x142882ab9:  483b0590cd5605       cmp       rax, qword ptr [rip + 0x556cd90]
0x142882ac0:  0f8544ffffff         jne       0x142882a0a
0x142882ac6:  488b4210             mov       rax, qword ptr [rdx + 0x10]
0x142882aca:  483b0587cd5605       cmp       rax, qword ptr [rip + 0x556cd87]
0x142882ad1:  0f8533ffffff         jne       0x142882a0a
0x142882ad7:  488d8140090000       lea       rax, [rcx + 0x940]
0x142882ade:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882ae3:  c3                   ret       
0x142882ae4:  6683f817             cmp       ax, 0x17
0x142882ae8:  0f856affffff         jne       0x142882a58
0x142882aee:  498b400c             mov       rax, qword ptr [r8 + 0xc]
0x142882af2:  483b4208             cmp       rax, qword ptr [rdx + 8]
0x142882af6:  0f855cffffff         jne       0x142882a58
0x142882afc:  498b4014             mov       rax, qword ptr [r8 + 0x14]
0x142882b00:  483b4210             cmp       rax, qword ptr [rdx + 0x10]
0x142882b04:  0f854effffff         jne       0x142882a58
0x142882b0a:  498d8030160000       lea       rax, [r8 + 0x1630]
0x142882b11:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882b16:  c3                   ret       
0x142882b17:  6683f817             cmp       ax, 0x17
0x142882b1b:  7514                 jne       0x142882b31
0x142882b1d:  498b400c             mov       rax, qword ptr [r8 + 0xc]
0x142882b21:  483b4208             cmp       rax, qword ptr [rdx + 8]
0x142882b25:  750a                 jne       0x142882b31
0x142882b27:  498b4014             mov       rax, qword ptr [r8 + 0x14]
0x142882b2b:  483b4210             cmp       rax, qword ptr [rdx + 0x10]
0x142882b2f:  74d9                 je        0x142882b0a
0x142882b31:  41ffc1               inc       r9d
0x142882b34:  453bcb               cmp       r9d, r11d
0x142882b37:  0f8236ffffff         jb        0x142882a73
0x142882b3d:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882b42:  488d051fcd5605       lea       rax, [rip + 0x556cd1f]
0x142882b49:  c3                   ret       
0x142882b4a:  cc                   int3      
0x142882b4b:  cc                   int3      
0x142882b4c:  cc                   int3      
0x142882b4d:  cc                   int3      
0x142882b4e:  cc                   int3      
0x142882b4f:  cc                   int3      
