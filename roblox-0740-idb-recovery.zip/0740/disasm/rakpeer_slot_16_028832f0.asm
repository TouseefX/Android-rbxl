; RakPeer vtable slot 16
; rva 0x28832f0
0x1428832f0:  4053                 push      rbx
0x1428832f2:  4883ec40             sub       rsp, 0x40
0x1428832f6:  0f100a               movups    xmm1, xmmword ptr [rdx]
0x1428832f9:  4c8bd9               mov       r11, rcx
0x1428832fc:  0f104210             movups    xmm0, xmmword ptr [rdx + 0x10]
0x142883300:  66490f7ec9           movq      r9, xmm1
0x142883305:  0f294c2420           movaps    xmmword ptr [rsp + 0x20], xmm1
0x14288330a:  488b5c2428           mov       rbx, qword ptr [rsp + 0x28]
0x14288330f:  498bc1               mov       rax, r9
0x142883312:  48c1e810             shr       rax, 0x10
0x142883316:  663b052dc55605       cmp       ax, word ptr [rip + 0x556c52d]
0x14288331d:  0f29442430           movaps    xmmword ptr [rsp + 0x30], xmm0
0x142883322:  4c8b542430           mov       r10, qword ptr [rsp + 0x30]
0x142883327:  753d                 jne       0x142883366
0x142883329:  66443b0d17c55605     cmp       r9w, word ptr [rip + 0x556c517]
0x142883331:  7533                 jne       0x142883366
0x142883333:  664183f902           cmp       r9w, 2
0x142883338:  750f                 jne       0x142883349
0x14288333a:  498bc1               mov       rax, r9
0x14288333d:  48c1e820             shr       rax, 0x20
0x142883341:  3b0505c55605         cmp       eax, dword ptr [rip + 0x556c505]
0x142883347:  eb17                 jmp       0x142883360
0x142883349:  664183f917           cmp       r9w, 0x17
0x14288334e:  7516                 jne       0x142883366
0x142883350:  483b1df9c45605       cmp       rbx, qword ptr [rip + 0x556c4f9]
0x142883357:  750d                 jne       0x142883366
0x142883359:  4c3b15f8c45605       cmp       r10, qword ptr [rip + 0x556c4f8]
0x142883360:  0f8483000000         je        0x1428833e9
0x142883366:  4533c0               xor       r8d, r8d
0x142883369:  66443b8112010000     cmp       r8w, word ptr [rcx + 0x112]
0x142883371:  7376                 jae       0x1428833e9
0x142883373:  498b9350030000       mov       rdx, qword ptr [r11 + 0x350]
0x14288337a:  4963c0               movsxd    rax, r8d
0x14288337d:  4869c8d8160000       imul      rcx, rax, 0x16d8
0x142883384:  0fb7442422           movzx     eax, word ptr [rsp + 0x22]
0x142883389:  6639441106           cmp       word ptr [rcx + rdx + 6], ax
0x14288338e:  7549                 jne       0x1428833d9
0x142883390:  0fb7441104           movzx     eax, word ptr [rcx + rdx + 4]
0x142883395:  66413bc1             cmp       ax, r9w
0x142883399:  753e                 jne       0x1428833d9
0x14288339b:  6683f802             cmp       ax, 2
0x14288339f:  750c                 jne       0x1428833ad
0x1428833a1:  8b442424             mov       eax, dword ptr [rsp + 0x24]
0x1428833a5:  39441108             cmp       dword ptr [rcx + rdx + 8], eax
0x1428833a9:  7416                 je        0x1428833c1
0x1428833ab:  eb2c                 jmp       0x1428833d9
0x1428833ad:  6683f817             cmp       ax, 0x17
0x1428833b1:  7526                 jne       0x1428833d9
0x1428833b3:  48395c110c           cmp       qword ptr [rcx + rdx + 0xc], rbx
0x1428833b8:  751f                 jne       0x1428833d9
0x1428833ba:  4c39541114           cmp       qword ptr [rcx + rdx + 0x14], r10
0x1428833bf:  7518                 jne       0x1428833d9
0x1428833c1:  0fb60411             movzx     eax, byte ptr [rcx + rdx]
0x1428833c5:  90                   nop       
0x1428833c6:  84c0                 test      al, al
0x1428833c8:  752a                 jne       0x1428833f4
0x1428833ca:  4c8b542430           mov       r10, qword ptr [rsp + 0x30]
0x1428833cf:  488b5c2428           mov       rbx, qword ptr [rsp + 0x28]
0x1428833d4:  4c8b4c2420           mov       r9, qword ptr [rsp + 0x20]
0x1428833d9:  410fb78312010000     movzx     eax, word ptr [r11 + 0x112]
0x1428833e1:  41ffc0               inc       r8d
0x1428833e4:  443bc0               cmp       r8d, eax
0x1428833e7:  728a                 jb        0x142883373
0x1428833e9:  b8ffffffff           mov       eax, 0xffffffff
0x1428833ee:  4883c440             add       rsp, 0x40
0x1428833f2:  5b                   pop       rbx
0x1428833f3:  c3                   ret       
0x1428833f4:  49038b50030000       add       rcx, qword ptr [r11 + 0x350]
0x1428833fb:  74ec                 je        0x1428833e9
0x1428833fd:  4881c188010000       add       rcx, 0x188
0x142883404:  0f28cb               movaps    xmm1, xmm3
0x142883407:  4883c440             add       rsp, 0x40
0x14288340b:  5b                   pop       rbx
0x14288340c:  e93f1b0300           jmp       0x1428b4f50
0x142883411:  cc                   int3      
0x142883412:  cc                   int3      
0x142883413:  cc                   int3      
0x142883414:  cc                   int3      
0x142883415:  cc                   int3      
0x142883416:  cc                   int3      
0x142883417:  cc                   int3      
0x142883418:  cc                   int3      
0x142883419:  cc                   int3      
0x14288341a:  cc                   int3      
0x14288341b:  cc                   int3      
0x14288341c:  cc                   int3      
0x14288341d:  cc                   int3      
0x14288341e:  cc                   int3      
0x14288341f:  cc                   int3      
0x142883420:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x142883425:  4c8b1d2cc45605       mov       r11, qword ptr [rip + 0x556c42c]
0x14288342c:  488d8194090000       lea       rax, [rcx + 0x994]
0x142883433:  488b1d16c45605       mov       rbx, qword ptr [rip + 0x556c416]
0x14288343a:  33d2                 xor       edx, edx
0x14288343c:  448b0509c45605       mov       r8d, dword ptr [rip + 0x556c409]
0x142883443:  440fb70dffc35605     movzx     r9d, word ptr [rip + 0x556c3ff]
0x14288344b:  440fb715f5c35605     movzx     r10d, word ptr [rip + 0x556c3f5]
0x142883453:  66443948fe           cmp       word ptr [rax - 2], r9w
0x142883458:  7527                 jne       0x142883481
0x14288345a:  0fb748fc             movzx     ecx, word ptr [rax - 4]
0x14288345e:  66413bca             cmp       cx, r10w
0x142883462:  751d                 jne       0x142883481
0x142883464:  6683f902             cmp       cx, 2
0x142883468:  7505                 jne       0x14288346f
0x14288346a:  443900               cmp       dword ptr [rax], r8d
0x14288346d:  eb10                 jmp       0x14288347f
0x14288346f:  6683f917             cmp       cx, 0x17
0x142883473:  750c                 jne       0x142883481
0x142883475:  48395804             cmp       qword ptr [rax + 4], rbx
0x142883479:  7506                 jne       0x142883481
0x14288347b:  4c39580c             cmp       qword ptr [rax + 0xc], r11
0x14288347f:  7408                 je        0x142883489
0x142883481:  ffc2                 inc       edx
0x142883483:  4883c020             add       rax, 0x20
0x142883487:  ebca                 jmp       0x142883453
0x142883489:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x14288348e:  8bc2                 mov       eax, edx
0x142883490:  c3                   ret       
0x142883491:  cc                   int3      
0x142883492:  cc                   int3      
0x142883493:  cc                   int3      
0x142883494:  cc                   int3      
0x142883495:  cc                   int3      
0x142883496:  cc                   int3      
0x142883497:  cc                   int3      
0x142883498:  cc                   int3      
0x142883499:  cc                   int3      
0x14288349a:  cc                   int3      
0x14288349b:  cc                   int3      
0x14288349c:  cc                   int3      
0x14288349d:  cc                   int3      
0x14288349e:  cc                   int3      
0x14288349f:  cc                   int3      
0x1428834a0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x1428834a5:  57                   push      rdi
0x1428834a6:  4883ec30             sub       rsp, 0x30
0x1428834aa:  488b01               mov       rax, qword ptr [rcx]
0x1428834ad:  488bd9               mov       rbx, rcx
0x1428834b0:  8bfa                 mov       edi, edx
0x1428834b2:  488b4078             mov       rax, qword ptr [rax + 0x78]
0x1428834b6:  ff157cc88b03         call      qword ptr [rip + 0x38bc87c]
0x1428834bc:  84c0                 test      al, al
0x1428834be:  750c                 jne       0x1428834cc
0x1428834c0:  488d8b90090000       lea       rcx, [rbx + 0x990]
0x1428834c7:  e894500200           call      0x1428a8560
0x1428834cc:  48c1e705             shl       rdi, 5
0x1428834d0:  488d8b90090000       lea       rcx, [rbx + 0x990]
0x1428834d7:  4803cf               add       rcx, rdi
0x1428834da:  4c8d059f941f06       lea       r8, [rip + 0x61f949f]
0x1428834e1:  41b901040000         mov       r9d, 0x401
0x1428834e7:  33d2                 xor       edx, edx
0x1428834e9:  e8b2210200           call      0x1428a56a0
0x1428834ee:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x1428834f3:  488d0586941f06       lea       rax, [rip + 0x61f9486]
0x1428834fa:  4883c430             add       rsp, 0x30
0x1428834fe:  5f                   pop       rdi
0x1428834ff:  c3                   ret       
0x142883500:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x142883505:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x14288350a:  48897c2418           mov       qword ptr [rsp + 0x18], rdi
0x14288350f:  4156                 push      r14
0x142883511:  4883ec20             sub       rsp, 0x20
0x142883515:  488bfa               mov       rdi, rdx
0x142883518:  4c8bf1               mov       r14, rcx
0x14288351b:  4885d2               test      rdx, rdx
0x14288351e:  0f84ab000000         je        0x1428835cf
0x142883524:  803a00               cmp       byte ptr [rdx], 0
0x142883527:  0f84a2000000         je        0x1428835cf
0x14288352d:  488d15dc376704       lea       rdx, [rip + 0x46737dc]
0x142883534:  488bcf               mov       rcx, rdi
0x142883537:  e8846e5503           call      0x145dda3c0
0x14288353c:  85c0                 test      eax, eax
0x14288353e:  7433                 je        0x142883573
0x142883540:  488d15c1c96004       lea       rdx, [rip + 0x460c9c1]
0x142883547:  488bcf               mov       rcx, rdi
0x14288354a:  e8716e5503           call      0x145dda3c0
0x14288354f:  85c0                 test      eax, eax
0x142883551:  7420                 je        0x142883573
0x142883553:  33db                 xor       ebx, ebx
0x142883555:  488d1574596704       lea       rdx, [rip + 0x4675974]
0x14288355c:  8bcb                 mov       ecx, ebx
0x14288355e:  6690                 nop       
0x142883560:  0fb6040f             movzx     eax, byte ptr [rdi + rcx]
0x142883564:  48ffc1               inc       rcx
0x142883567:  3a440aff             cmp       al, byte ptr [rdx + rcx - 1]
0x14288356b:  750a                 jne       0x142883577
0x14288356d:  4883f904             cmp       rcx, 4
0x142883571:  75ed                 jne       0x142883560
0x142883573:  b001                 mov       al, 1
0x142883575:  eb5a                 jmp       0x1428835d1
0x142883577:  498b06               mov       rax, qword ptr [r14]
0x14288357a:  498bce               mov       rcx, r14
0x14288357d:  488b80d8010000       mov       rax, qword ptr [rax + 0x1d8]
0x142883584:  ff15aec78b03         call      qword ptr [rip + 0x38bc7ae]
0x14288358a:  8bf0                 mov       esi, eax
0x14288358c:  85c0                 test      eax, eax
0x14288358e:  7e3f                 jle       0x1428835cf
0x142883590:  498b0e               mov       rcx, qword ptr [r14]
0x142883593:  8bd3                 mov       edx, ebx
0x142883595:  488b81e0010000       mov       rax, qword ptr [rcx + 0x1e0]
0x14288359c:  498bce               mov       rcx, r14
0x14288359f:  ff1593c78b03         call      qword ptr [rip + 0x38bc793]
0x1428835a5:  482bc7               sub       rax, rdi
0x1428835a8:  488bcf               mov       rcx, rdi
0x1428835ab:  0f1f440000           nop       dword ptr [rax + rax]
0x1428835b0:  440fb601             movzx     r8d, byte ptr [rcx]
0x1428835b4:  0fb61401             movzx     edx, byte ptr [rcx + rax]
0x1428835b8:  442bc2               sub       r8d, edx
0x1428835bb:  7507                 jne       0x1428835c4
0x1428835bd:  48ffc1               inc       rcx
0x1428835c0:  85d2                 test      edx, edx
0x1428835c2:  75ec                 jne       0x1428835b0
0x1428835c4:  4585c0               test      r8d, r8d
0x1428835c7:  74aa                 je        0x142883573
0x1428835c9:  ffc3                 inc       ebx
0x1428835cb:  3bde                 cmp       ebx, esi
0x1428835cd:  7cc1                 jl        0x142883590
0x1428835cf:  32c0                 xor       al, al
0x1428835d1:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x1428835d6:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x1428835db:  488b7c2440           mov       rdi, qword ptr [rsp + 0x40]
0x1428835e0:  4883c420             add       rsp, 0x20
0x1428835e4:  415e                 pop       r14
0x1428835e6:  c3                   ret       
0x1428835e7:  cc                   int3      
0x1428835e8:  cc                   int3      
0x1428835e9:  cc                   int3      
0x1428835ea:  cc                   int3      
0x1428835eb:  cc                   int3      
0x1428835ec:  cc                   int3      
0x1428835ed:  cc                   int3      
0x1428835ee:  cc                   int3      
0x1428835ef:  cc                   int3      
0x1428835f0:  889154090000         mov       byte ptr [rcx + 0x954], dl
0x1428835f6:  c3                   ret       
0x1428835f7:  cc                   int3      
0x1428835f8:  cc                   int3      
0x1428835f9:  cc                   int3      
0x1428835fa:  cc                   int3      
0x1428835fb:  cc                   int3      
0x1428835fc:  cc                   int3      
0x1428835fd:  cc                   int3      
0x1428835fe:  cc                   int3      
0x1428835ff:  cc                   int3      
