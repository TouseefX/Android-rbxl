; RakPeer vtable slot 55
; rva 0x2882c70
0x142882c70:  48895c2410           mov       qword ptr [rsp + 0x10], rbx
0x142882c75:  55                   push      rbp
0x142882c76:  56                   push      rsi
0x142882c77:  57                   push      rdi
0x142882c78:  4883ec20             sub       rsp, 0x20
0x142882c7c:  488b35d5cb5605       mov       rsi, qword ptr [rip + 0x556cbd5]
0x142882c83:  8bea                 mov       ebp, edx
0x142882c85:  0fb715becb5605       movzx     edx, word ptr [rip + 0x556cbbe]
0x142882c8c:  4c8bc9               mov       r9, rcx
0x142882c8f:  488b3dbacb5605       mov       rdi, qword ptr [rip + 0x556cbba]
0x142882c96:  8b0db0cb5605         mov       ecx, dword ptr [rip + 0x556cbb0]
0x142882c9c:  0fb71da5cb5605       movzx     ebx, word ptr [rip + 0x556cba5]
0x142882ca3:  6641395002           cmp       word ptr [r8 + 2], dx
0x142882ca8:  7515                 jne       0x142882cbf
0x142882caa:  410fb700             movzx     eax, word ptr [r8]
0x142882cae:  663bc3               cmp       ax, bx
0x142882cb1:  750c                 jne       0x142882cbf
0x142882cb3:  6683f802             cmp       ax, 2
0x142882cb7:  755a                 jne       0x142882d13
0x142882cb9:  41394804             cmp       dword ptr [r8 + 4], ecx
0x142882cbd:  7466                 je        0x142882d25
0x142882cbf:  410f1008             movups    xmm1, xmmword ptr [r8]
0x142882cc3:  410f104010           movups    xmm0, xmmword ptr [r8 + 0x10]
0x142882cc8:  66490f7ec8           movq      r8, xmm1
0x142882ccd:  0f290c24             movaps    xmmword ptr [rsp], xmm1
0x142882cd1:  4c8b5c2408           mov       r11, qword ptr [rsp + 8]
0x142882cd6:  498bc0               mov       rax, r8
0x142882cd9:  48c1e810             shr       rax, 0x10
0x142882cdd:  0f29442410           movaps    xmmword ptr [rsp + 0x10], xmm0
0x142882ce2:  4c8b542410           mov       r10, qword ptr [rsp + 0x10]
0x142882ce7:  663bc2               cmp       ax, dx
0x142882cea:  0f85ba000000         jne       0x142882daa
0x142882cf0:  66443bc3             cmp       r8w, bx
0x142882cf4:  0f85b0000000         jne       0x142882daa
0x142882cfa:  664183f802           cmp       r8w, 2
0x142882cff:  0f8590000000         jne       0x142882d95
0x142882d05:  498bc0               mov       rax, r8
0x142882d08:  48c1e820             shr       rax, 0x20
0x142882d0c:  3bc1                 cmp       eax, ecx
0x142882d0e:  e991000000           jmp       0x142882da4
0x142882d13:  6683f817             cmp       ax, 0x17
0x142882d17:  75a6                 jne       0x142882cbf
0x142882d19:  49397808             cmp       qword ptr [r8 + 8], rdi
0x142882d1d:  75a0                 jne       0x142882cbf
0x142882d1f:  49397010             cmp       qword ptr [r8 + 0x10], rsi
0x142882d23:  759a                 jne       0x142882cbf
0x142882d25:  33c0                 xor       eax, eax
0x142882d27:  4189a93c090000       mov       dword ptr [r9 + 0x93c], ebp
0x142882d2e:  66413b8112010000     cmp       ax, word ptr [r9 + 0x112]
0x142882d36:  0f8313010000         jae       0x142882e4f
0x142882d3c:  0f1f4000             nop       dword ptr [rax]
0x142882d40:  8bc8                 mov       ecx, eax
0x142882d42:  4c69c1d8160000       imul      r8, rcx, 0x16d8
0x142882d49:  498b8950030000       mov       rcx, qword ptr [r9 + 0x350]
0x142882d50:  410fb61408           movzx     edx, byte ptr [r8 + rcx]
0x142882d55:  90                   nop       
0x142882d56:  84d2                 test      dl, dl
0x142882d58:  7420                 je        0x142882d7a
0x142882d5a:  498b8950030000       mov       rcx, qword ptr [r9 + 0x350]
0x142882d61:  410fb61408           movzx     edx, byte ptr [r8 + rcx]
0x142882d66:  90                   nop       
0x142882d67:  84d2                 test      dl, dl
0x142882d69:  740f                 je        0x142882d7a
0x142882d6b:  498b8950030000       mov       rcx, qword ptr [r9 + 0x350]
0x142882d72:  4189ac0840030000     mov       dword ptr [r8 + rcx + 0x340], ebp
0x142882d7a:  410fb78912010000     movzx     ecx, word ptr [r9 + 0x112]
0x142882d82:  ffc0                 inc       eax
0x142882d84:  3bc1                 cmp       eax, ecx
0x142882d86:  72b8                 jb        0x142882d40
0x142882d88:  488b5c2448           mov       rbx, qword ptr [rsp + 0x48]
0x142882d8d:  4883c420             add       rsp, 0x20
0x142882d91:  5f                   pop       rdi
0x142882d92:  5e                   pop       rsi
0x142882d93:  5d                   pop       rbp
0x142882d94:  c3                   ret       
0x142882d95:  664183f817           cmp       r8w, 0x17
0x142882d9a:  750e                 jne       0x142882daa
0x142882d9c:  4c3bdf               cmp       r11, rdi
0x142882d9f:  7509                 jne       0x142882daa
0x142882da1:  4c3bd6               cmp       r10, rsi
0x142882da4:  0f84a5000000         je        0x142882e4f
0x142882daa:  33c0                 xor       eax, eax
0x142882dac:  66413b8112010000     cmp       ax, word ptr [r9 + 0x112]
0x142882db4:  0f8395000000         jae       0x142882e4f
0x142882dba:  660f1f440000         nop       word ptr [rax + rax]
0x142882dc0:  498b9150030000       mov       rdx, qword ptr [r9 + 0x350]
0x142882dc7:  4863c8               movsxd    rcx, eax
0x142882dca:  4869d9d8160000       imul      rbx, rcx, 0x16d8
0x142882dd1:  0fb74c2402           movzx     ecx, word ptr [rsp + 2]
0x142882dd6:  4803d3               add       rdx, rbx
0x142882dd9:  66394a06             cmp       word ptr [rdx + 6], cx
0x142882ddd:  7543                 jne       0x142882e22
0x142882ddf:  0fb74a04             movzx     ecx, word ptr [rdx + 4]
0x142882de3:  66413bc8             cmp       cx, r8w
0x142882de7:  7539                 jne       0x142882e22
0x142882de9:  6683f902             cmp       cx, 2
0x142882ded:  750b                 jne       0x142882dfa
0x142882def:  8b4c2404             mov       ecx, dword ptr [rsp + 4]
0x142882df3:  394a08               cmp       dword ptr [rdx + 8], ecx
0x142882df6:  7414                 je        0x142882e0c
0x142882df8:  eb28                 jmp       0x142882e22
0x142882dfa:  6683f917             cmp       cx, 0x17
0x142882dfe:  7522                 jne       0x142882e22
0x142882e00:  4c395a0c             cmp       qword ptr [rdx + 0xc], r11
0x142882e04:  751c                 jne       0x142882e22
0x142882e06:  4c395214             cmp       qword ptr [rdx + 0x14], r10
0x142882e0a:  7516                 jne       0x142882e22
0x142882e0c:  0fb60a               movzx     ecx, byte ptr [rdx]
0x142882e0f:  90                   nop       
0x142882e10:  84c9                 test      cl, cl
0x142882e12:  7529                 jne       0x142882e3d
0x142882e14:  4c8b542410           mov       r10, qword ptr [rsp + 0x10]
0x142882e19:  4c8b5c2408           mov       r11, qword ptr [rsp + 8]
0x142882e1e:  4c8b0424             mov       r8, qword ptr [rsp]
0x142882e22:  410fb78912010000     movzx     ecx, word ptr [r9 + 0x112]
0x142882e2a:  ffc0                 inc       eax
0x142882e2c:  3bc1                 cmp       eax, ecx
0x142882e2e:  7290                 jb        0x142882dc0
0x142882e30:  488b5c2448           mov       rbx, qword ptr [rsp + 0x48]
0x142882e35:  4883c420             add       rsp, 0x20
0x142882e39:  5f                   pop       rdi
0x142882e3a:  5e                   pop       rsi
0x142882e3b:  5d                   pop       rbp
0x142882e3c:  c3                   ret       
0x142882e3d:  498b8950030000       mov       rcx, qword ptr [r9 + 0x350]
0x142882e44:  4803cb               add       rcx, rbx
0x142882e47:  7406                 je        0x142882e4f
0x142882e49:  89a940030000         mov       dword ptr [rcx + 0x340], ebp
0x142882e4f:  488b5c2448           mov       rbx, qword ptr [rsp + 0x48]
0x142882e54:  4883c420             add       rsp, 0x20
0x142882e58:  5f                   pop       rdi
0x142882e59:  5e                   pop       rsi
0x142882e5a:  5d                   pop       rbp
0x142882e5b:  c3                   ret       
0x142882e5c:  cc                   int3      
0x142882e5d:  cc                   int3      
0x142882e5e:  cc                   int3      
0x142882e5f:  cc                   int3      
0x142882e60:  48896c2418           mov       qword ptr [rsp + 0x18], rbp
0x142882e65:  4889742420           mov       qword ptr [rsp + 0x20], rsi
0x142882e6a:  57                   push      rdi
0x142882e6b:  4883ec20             sub       rsp, 0x20
0x142882e6f:  0fb72dd4c95605       movzx     ebp, word ptr [rip + 0x556c9d4]
0x142882e76:  4c8bd1               mov       r10, rcx
0x142882e79:  488b3dd8c95605       mov       rdi, qword ptr [rip + 0x556c9d8]
0x142882e80:  488b35c9c95605       mov       rsi, qword ptr [rip + 0x556c9c9]
0x142882e87:  8b0dbfc95605         mov       ecx, dword ptr [rip + 0x556c9bf]
0x142882e8d:  440fb705b3c95605     movzx     r8d, word ptr [rip + 0x556c9b3]
0x142882e95:  66396a02             cmp       word ptr [rdx + 2], bp
0x142882e99:  752a                 jne       0x142882ec5
0x142882e9b:  0fb702               movzx     eax, word ptr [rdx]
0x142882e9e:  66413bc0             cmp       ax, r8w
0x142882ea2:  7521                 jne       0x142882ec5
0x142882ea4:  6683f802             cmp       ax, 2
0x142882ea8:  7505                 jne       0x142882eaf
0x142882eaa:  394a04               cmp       dword ptr [rdx + 4], ecx
0x142882ead:  eb10                 jmp       0x142882ebf
0x142882eaf:  6683f817             cmp       ax, 0x17
0x142882eb3:  7510                 jne       0x142882ec5
0x142882eb5:  48397208             cmp       qword ptr [rdx + 8], rsi
0x142882eb9:  750a                 jne       0x142882ec5
0x142882ebb:  48397a10             cmp       qword ptr [rdx + 0x10], rdi
0x142882ebf:  0f84df000000         je        0x142882fa4
0x142882ec5:  0f100a               movups    xmm1, xmmword ptr [rdx]
0x142882ec8:  48895c2430           mov       qword ptr [rsp + 0x30], rbx
0x142882ecd:  0f104210             movups    xmm0, xmmword ptr [rdx + 0x10]
0x142882ed1:  66490f7ec9           movq      r9, xmm1
0x142882ed6:  0f290c24             movaps    xmmword ptr [rsp], xmm1
0x142882eda:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882edf:  498bc1               mov       rax, r9
0x142882ee2:  48c1e810             shr       rax, 0x10
0x142882ee6:  0f29442410           movaps    xmmword ptr [rsp + 0x10], xmm0
0x142882eeb:  4c8b5c2410           mov       r11, qword ptr [rsp + 0x10]
0x142882ef0:  663bc5               cmp       ax, bp
0x142882ef3:  752d                 jne       0x142882f22
0x142882ef5:  66453bc8             cmp       r9w, r8w
0x142882ef9:  7527                 jne       0x142882f22
0x142882efb:  664183f902           cmp       r9w, 2
0x142882f00:  750b                 jne       0x142882f0d
0x142882f02:  498bc1               mov       rax, r9
0x142882f05:  48c1e820             shr       rax, 0x20
0x142882f09:  3bc1                 cmp       eax, ecx
0x142882f0b:  eb0f                 jmp       0x142882f1c
0x142882f0d:  664183f917           cmp       r9w, 0x17
0x142882f12:  750e                 jne       0x142882f22
0x142882f14:  483bde               cmp       rbx, rsi
0x142882f17:  7509                 jne       0x142882f22
0x142882f19:  4c3bdf               cmp       r11, rdi
0x142882f1c:  0f847d000000         je        0x142882f9f
0x142882f22:  4533c0               xor       r8d, r8d
0x142882f25:  66453b8212010000     cmp       r8w, word ptr [r10 + 0x112]
0x142882f2d:  7370                 jae       0x142882f9f
0x142882f2f:  90                   nop       
0x142882f30:  4963c0               movsxd    rax, r8d
0x142882f33:  4869d0d8160000       imul      rdx, rax, 0x16d8
0x142882f3a:  0fb7442402           movzx     eax, word ptr [rsp + 2]
0x142882f3f:  49039250030000       add       rdx, qword ptr [r10 + 0x350]
0x142882f46:  66394206             cmp       word ptr [rdx + 6], ax
0x142882f4a:  7543                 jne       0x142882f8f
0x142882f4c:  0fb74204             movzx     eax, word ptr [rdx + 4]
0x142882f50:  66413bc1             cmp       ax, r9w
0x142882f54:  7539                 jne       0x142882f8f
0x142882f56:  6683f802             cmp       ax, 2
0x142882f5a:  750b                 jne       0x142882f67
0x142882f5c:  8b442404             mov       eax, dword ptr [rsp + 4]
0x142882f60:  394208               cmp       dword ptr [rdx + 8], eax
0x142882f63:  7414                 je        0x142882f79
0x142882f65:  eb28                 jmp       0x142882f8f
0x142882f67:  6683f817             cmp       ax, 0x17
0x142882f6b:  7522                 jne       0x142882f8f
0x142882f6d:  48395a0c             cmp       qword ptr [rdx + 0xc], rbx
0x142882f71:  751c                 jne       0x142882f8f
0x142882f73:  4c395a14             cmp       qword ptr [rdx + 0x14], r11
0x142882f77:  7516                 jne       0x142882f8f
0x142882f79:  0fb602               movzx     eax, byte ptr [rdx]
0x142882f7c:  90                   nop       
0x142882f7d:  84c0                 test      al, al
0x142882f7f:  751e                 jne       0x142882f9f
0x142882f81:  4c8b5c2410           mov       r11, qword ptr [rsp + 0x10]
0x142882f86:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882f8b:  4c8b0c24             mov       r9, qword ptr [rsp]
0x142882f8f:  410fb78212010000     movzx     eax, word ptr [r10 + 0x112]
0x142882f97:  41ffc0               inc       r8d
0x142882f9a:  443bc0               cmp       r8d, eax
0x142882f9d:  7291                 jb        0x142882f30
0x142882f9f:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142882fa4:  418b823c090000       mov       eax, dword ptr [r10 + 0x93c]
0x142882fab:  488b6c2440           mov       rbp, qword ptr [rsp + 0x40]
0x142882fb0:  488b742448           mov       rsi, qword ptr [rsp + 0x48]
0x142882fb5:  4883c420             add       rsp, 0x20
0x142882fb9:  5f                   pop       rdi
0x142882fba:  c3                   ret       
0x142882fbb:  cc                   int3      
0x142882fbc:  cc                   int3      
0x142882fbd:  cc                   int3      
0x142882fbe:  cc                   int3      
0x142882fbf:  cc                   int3      
