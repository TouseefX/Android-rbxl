; RakPeer vtable slot 29
; rva 0x2880a30
0x142880a30:  4885d2               test      rdx, rdx
0x142880a33:  0f8499010000         je        0x142880bd2
0x142880a39:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x142880a3e:  57                   push      rdi
0x142880a3f:  4883ec20             sub       rsp, 0x20
0x142880a43:  807a4000             cmp       byte ptr [rdx + 0x40], 0
0x142880a47:  488bf2               mov       rsi, rdx
0x142880a4a:  488bf9               mov       rdi, rcx
0x142880a4d:  0f8480010000         je        0x142880bd3
0x142880a53:  488b4a38             mov       rcx, qword ptr [rdx + 0x38]
0x142880a57:  48896c2438           mov       qword ptr [rsp + 0x38], rbp
0x142880a5c:  e84f260c02           call      0x1449430b0
0x142880a61:  488d8fc00b0000       lea       rcx, [rdi + 0xbc0]
0x142880a68:  e8432d2a03           call      0x145b237b0
0x142880a6d:  85c0                 test      eax, eax
0x142880a6f:  0f8570010000         jne       0x142880be5
0x142880a75:  48895c2430           mov       qword ptr [rsp + 0x30], rbx
0x142880a7a:  488b5e68             mov       rbx, qword ptr [rsi + 0x68]
0x142880a7e:  48634308             movsxd    rax, dword ptr [rbx + 8]
0x142880a82:  488b0b               mov       rcx, qword ptr [rbx]
0x142880a85:  85c0                 test      eax, eax
0x142880a87:  0f85a4000000         jne       0x142880b31
0x142880a8d:  488931               mov       qword ptr [rcx], rsi
0x142880a90:  ff4308               inc       dword ptr [rbx + 8]
0x142880a93:  ff8f240c0000         dec       dword ptr [rdi + 0xc24]
0x142880a99:  488b4b18             mov       rcx, qword ptr [rbx + 0x18]
0x142880a9d:  488b4320             mov       rax, qword ptr [rbx + 0x20]
0x142880aa1:  48894120             mov       qword ptr [rcx + 0x20], rax
0x142880aa5:  488b4b20             mov       rcx, qword ptr [rbx + 0x20]
0x142880aa9:  488b4318             mov       rax, qword ptr [rbx + 0x18]
0x142880aad:  48894118             mov       qword ptr [rcx + 0x18], rax
0x142880ab1:  83bf240c000000       cmp       dword ptr [rdi + 0xc24], 0
0x142880ab8:  7e17                 jle       0x142880ad1
0x142880aba:  488b87180c0000       mov       rax, qword ptr [rdi + 0xc18]
0x142880ac1:  483bd8               cmp       rbx, rax
0x142880ac4:  750b                 jne       0x142880ad1
0x142880ac6:  488b4018             mov       rax, qword ptr [rax + 0x18]
0x142880aca:  488987180c0000       mov       qword ptr [rdi + 0xc18], rax
0x142880ad1:  8b8f200c0000         mov       ecx, dword ptr [rdi + 0xc20]
0x142880ad7:  8d4101               lea       eax, [rcx + 1]
0x142880ada:  8987200c0000         mov       dword ptr [rdi + 0xc20], eax
0x142880ae0:  85c9                 test      ecx, ecx
0x142880ae2:  7514                 jne       0x142880af8
0x142880ae4:  48899f100c0000       mov       qword ptr [rdi + 0xc10], rbx
0x142880aeb:  48895b18             mov       qword ptr [rbx + 0x18], rbx
0x142880aef:  48895b20             mov       qword ptr [rbx + 0x20], rbx
0x142880af3:  e9ba000000           jmp       0x142880bb2
0x142880af8:  488b87100c0000       mov       rax, qword ptr [rdi + 0xc10]
0x142880aff:  48894318             mov       qword ptr [rbx + 0x18], rax
0x142880b03:  488b87100c0000       mov       rax, qword ptr [rdi + 0xc10]
0x142880b0a:  488b4820             mov       rcx, qword ptr [rax + 0x20]
0x142880b0e:  48894b20             mov       qword ptr [rbx + 0x20], rcx
0x142880b12:  488b87100c0000       mov       rax, qword ptr [rdi + 0xc10]
0x142880b19:  488b4820             mov       rcx, qword ptr [rax + 0x20]
0x142880b1d:  48895918             mov       qword ptr [rcx + 0x18], rbx
0x142880b21:  488b87100c0000       mov       rax, qword ptr [rdi + 0xc10]
0x142880b28:  48895820             mov       qword ptr [rax + 0x20], rbx
0x142880b2c:  e981000000           jmp       0x142880bb2
0x142880b31:  488934c1             mov       qword ptr [rcx + rax*8], rsi
0x142880b35:  48b89324499224499224 movabs    rax, 0x2492492492492493
0x142880b3f:  ff4308               inc       dword ptr [rbx + 8]
0x142880b42:  48638f280c0000       movsxd    rcx, dword ptr [rdi + 0xc28]
0x142880b49:  48f7e1               mul       rcx
0x142880b4c:  482bca               sub       rcx, rdx
0x142880b4f:  48d1e9               shr       rcx, 1
0x142880b52:  4803ca               add       rcx, rdx
0x142880b55:  48c1e906             shr       rcx, 6
0x142880b59:  394b08               cmp       dword ptr [rbx + 8], ecx
0x142880b5c:  7554                 jne       0x142880bb2
0x142880b5e:  83bf200c000004       cmp       dword ptr [rdi + 0xc20], 4
0x142880b65:  7c4b                 jl        0x142880bb2
0x142880b67:  483b9f100c0000       cmp       rbx, qword ptr [rdi + 0xc10]
0x142880b6e:  750b                 jne       0x142880b7b
0x142880b70:  488b4318             mov       rax, qword ptr [rbx + 0x18]
0x142880b74:  488987100c0000       mov       qword ptr [rdi + 0xc10], rax
0x142880b7b:  488b5320             mov       rdx, qword ptr [rbx + 0x20]
0x142880b7f:  488b4318             mov       rax, qword ptr [rbx + 0x18]
0x142880b83:  48894218             mov       qword ptr [rdx + 0x18], rax
0x142880b87:  488b5318             mov       rdx, qword ptr [rbx + 0x18]
0x142880b8b:  488b4320             mov       rax, qword ptr [rbx + 0x20]
0x142880b8f:  48894220             mov       qword ptr [rdx + 0x20], rax
0x142880b93:  ff8f200c0000         dec       dword ptr [rdi + 0xc20]
0x142880b99:  488b0b               mov       rcx, qword ptr [rbx]
0x142880b9c:  e80f250c02           call      0x1449430b0
0x142880ba1:  488b4b10             mov       rcx, qword ptr [rbx + 0x10]
0x142880ba5:  e806250c02           call      0x1449430b0
0x142880baa:  488bcb               mov       rcx, rbx
0x142880bad:  e8fe240c02           call      0x1449430b0
0x142880bb2:  488d8fc00b0000       lea       rcx, [rdi + 0xbc0]
0x142880bb9:  e8522c2a03           call      0x145b23810
0x142880bbe:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142880bc3:  488b6c2438           mov       rbp, qword ptr [rsp + 0x38]
0x142880bc8:  488b742440           mov       rsi, qword ptr [rsp + 0x40]
0x142880bcd:  4883c420             add       rsp, 0x20
0x142880bd1:  5f                   pop       rdi
0x142880bd2:  c3                   ret       
0x142880bd3:  488bce               mov       rcx, rsi
0x142880bd6:  488b742440           mov       rsi, qword ptr [rsp + 0x40]
0x142880bdb:  4883c420             add       rsp, 0x20
0x142880bdf:  5f                   pop       rdi
0x142880be0:  e9cb240c02           jmp       0x1449430b0
0x142880be5:  8bc8                 mov       ecx, eax
0x142880be7:  e894312a03           call      0x145b23d80
0x142880bec:  cc                   int3      
0x142880bed:  cc                   int3      
0x142880bee:  cc                   int3      
0x142880bef:  cc                   int3      
0x142880bf0:  0fb78112010000       movzx     eax, word ptr [rcx + 0x112]
0x142880bf7:  c3                   ret       
0x142880bf8:  cc                   int3      
0x142880bf9:  cc                   int3      
0x142880bfa:  cc                   int3      
0x142880bfb:  cc                   int3      
0x142880bfc:  cc                   int3      
0x142880bfd:  cc                   int3      
0x142880bfe:  cc                   int3      
0x142880bff:  cc                   int3      
