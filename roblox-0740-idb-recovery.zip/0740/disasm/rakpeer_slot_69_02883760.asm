; RakPeer vtable slot 69
; rva 0x2883760
0x142883760:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x142883765:  55                   push      rbp
0x142883766:  56                   push      rsi
0x142883767:  57                   push      rdi
0x142883768:  4156                 push      r14
0x14288376a:  4157                 push      r15
0x14288376c:  4881eca0010000       sub       rsp, 0x1a0
0x142883773:  488b0576ff4805       mov       rax, qword ptr [rip + 0x548ff76]
0x14288377a:  4833c4               xor       rax, rsp
0x14288377d:  4889842490010000     mov       qword ptr [rsp + 0x190], rax
0x142883785:  4c8bf2               mov       r14, rdx
0x142883788:  488bd9               mov       rbx, rcx
0x14288378b:  4533ff               xor       r15d, r15d
0x14288378e:  44397a0c             cmp       dword ptr [rdx + 0xc], r15d
0x142883792:  7430                 je        0x1428837c4
0x142883794:  488b0a               mov       rcx, qword ptr [rdx]
0x142883797:  4885c9               test      rcx, rcx
0x14288379a:  7421                 je        0x1428837bd
0x14288379c:  488d79f8             lea       rdi, [rcx - 8]
0x1428837a0:  4c8d0d596bf4fd       lea       r9, [rip - 0x20b94a7]
0x1428837a7:  4c8b07               mov       r8, qword ptr [rdi]
0x1428837aa:  418d5710             lea       edx, [r15 + 0x10]
0x1428837ae:  e8fdde2903           call      0x145b216b0
0x1428837b3:  90                   nop       
0x1428837b4:  488bcf               mov       rcx, rdi
0x1428837b7:  e8f4f80b02           call      0x1449430b0
0x1428837bc:  90                   nop       
0x1428837bd:  4d897e08             mov       qword ptr [r14 + 8], r15
0x1428837c1:  4d893e               mov       qword ptr [r14], r15
0x1428837c4:  0f57c0               xorps     xmm0, xmm0
0x1428837c7:  660f7f8424e0000000   movdqa    xmmword ptr [rsp + 0xe0], xmm0
0x1428837d0:  4c89bc2480010000     mov       qword ptr [rsp + 0x180], r15
0x1428837d8:  c784247801000001000000 mov       dword ptr [rsp + 0x178], 1
0x1428837e3:  488b057ec05605       mov       rax, qword ptr [rip + 0x556c07e]
0x1428837ea:  4889842400010000     mov       qword ptr [rsp + 0x100], rax
0x1428837f2:  0fb70577c05605       movzx     eax, word ptr [rip + 0x556c077]
0x1428837f9:  6689842408010000     mov       word ptr [rsp + 0x108], ax
0x142883801:  0f100540c05605       movups    xmm0, xmmword ptr [rip + 0x556c040]
0x142883808:  0f29842410010000     movaps    xmmword ptr [rsp + 0x110], xmm0
0x142883810:  f20f100d40c05605     movsd     xmm1, qword ptr [rip + 0x556c040]
0x142883818:  f20f118c2420010000   movsd     qword ptr [rsp + 0x120], xmm1
0x142883821:  8b0539c05605         mov       eax, dword ptr [rip + 0x556c039]
0x142883827:  89842428010000       mov       dword ptr [rsp + 0x128], eax
0x14288382e:  0fb70531c05605       movzx     eax, word ptr [rip + 0x556c031]
0x142883835:  668984242e010000     mov       word ptr [rsp + 0x12e], ax
0x14288383d:  0fb70520c05605       movzx     eax, word ptr [rip + 0x556c020]
0x142883844:  668984242c010000     mov       word ptr [rsp + 0x12c], ax
0x14288384c:  4c89bc2448010000     mov       qword ptr [rsp + 0x148], r15
0x142883854:  488db3e0050000       lea       rsi, [rbx + 0x5e0]
0x14288385b:  488bce               mov       rcx, rsi
0x14288385e:  e85d0da1fe           call      0x1412945c0
0x142883863:  488d9424e0000000     lea       rdx, [rsp + 0xe0]
0x14288386b:  488d4c2430           lea       rcx, [rsp + 0x30]
0x142883870:  e8cb010000           call      0x142883a40
0x142883875:  488bf8               mov       rdi, rax
0x142883878:  4c8d80a8000000       lea       r8, [rax + 0xa8]
0x14288387f:  488bd0               mov       rdx, rax
0x142883882:  488d8ba0050000       lea       rcx, [rbx + 0x5a0]
0x142883889:  e882010200           call      0x1428a3a10
0x14288388e:  488b4f08             mov       rcx, qword ptr [rdi + 8]
0x142883892:  4885c9               test      rcx, rcx
0x142883895:  7405                 je        0x14288389c
0x142883897:  e87456f4fd           call      0x1407c8f10
0x14288389c:  b800000080           mov       eax, 0x80000000
0x1428838a1:  f00fc106             lock xadd dword ptr [rsi], eax
0x1428838a5:  0fbae01e             bt        eax, 0x1e
0x1428838a9:  721f                 jb        0x1428838ca
0x1428838ab:  3d00000080           cmp       eax, 0x80000000
0x1428838b0:  7e18                 jle       0x1428838ca
0x1428838b2:  f00fba2e1e           lock bts  dword ptr [rsi], 0x1e
0x1428838b7:  7211                 jb        0x1428838ca
0x1428838b9:  488bce               mov       rcx, rsi
0x1428838bc:  e88f6bf4fd           call      0x1407ca450
0x1428838c1:  488bc8               mov       rcx, rax
0x1428838c4:  ff150eb48b03         call      qword ptr [rip + 0x38bb40e]
0x1428838ca:  0f57c0               xorps     xmm0, xmm0
0x1428838cd:  f30f7f442420         movdqu    xmmword ptr [rsp + 0x20], xmm0
0x1428838d3:  0fb68309010000       movzx     eax, byte ptr [rbx + 0x109]
0x1428838da:  90                   nop       
0x1428838db:  84c0                 test      al, al
0x1428838dd:  0f8493000000         je        0x142883976
0x1428838e3:  33c9                 xor       ecx, ecx
0x1428838e5:  e8065c0300           call      0x1428b94f0
0x1428838ea:  488d8b38080000       lea       rcx, [rbx + 0x838]
0x1428838f1:  e8bafe2903           call      0x145b237b0
0x1428838f6:  85c0                 test      eax, eax
0x1428838f8:  0f852c010000         jne       0x142883a2a
0x1428838fe:  8b8328080000         mov       eax, dword ptr [rbx + 0x828]
0x142883904:  3b832c080000         cmp       eax, dword ptr [rbx + 0x82c]
0x14288390a:  750e                 jne       0x14288391a
0x14288390c:  488d8b38080000       lea       rcx, [rbx + 0x838]
0x142883913:  e8f8fe2903           call      0x145b23810
0x142883918:  eb4c                 jmp       0x142883966
0x14288391a:  ffc0                 inc       eax
0x14288391c:  898328080000         mov       dword ptr [rbx + 0x828], eax
0x142883922:  8b8b30080000         mov       ecx, dword ptr [rbx + 0x830]
0x142883928:  3bc1                 cmp       eax, ecx
0x14288392a:  7513                 jne       0x14288393f
0x14288392c:  4489bb28080000       mov       dword ptr [rbx + 0x828], r15d
0x142883933:  488bb320080000       mov       rsi, qword ptr [rbx + 0x820]
0x14288393a:  8d41ff               lea       eax, [rcx - 1]
0x14288393d:  eb12                 jmp       0x142883951
0x14288393f:  488bb320080000       mov       rsi, qword ptr [rbx + 0x820]
0x142883946:  85c0                 test      eax, eax
0x142883948:  7505                 jne       0x14288394f
0x14288394a:  8d41ff               lea       eax, [rcx - 1]
0x14288394d:  eb02                 jmp       0x142883951
0x14288394f:  ffc8                 dec       eax
0x142883951:  488b34c6             mov       rsi, qword ptr [rsi + rax*8]
0x142883955:  488d8b38080000       lea       rcx, [rbx + 0x838]
0x14288395c:  e8affe2903           call      0x145b23810
0x142883961:  4885f6               test      rsi, rsi
0x142883964:  7549                 jne       0x1428839af
0x142883966:  0fb68309010000       movzx     eax, byte ptr [rbx + 0x109]
0x14288396d:  90                   nop       
0x14288396e:  84c0                 test      al, al
0x142883970:  0f856dffffff         jne       0x1428838e3
0x142883976:  488b8c24e8000000     mov       rcx, qword ptr [rsp + 0xe8]
0x14288397e:  4885c9               test      rcx, rcx
0x142883981:  7405                 je        0x142883988
0x142883983:  e88855f4fd           call      0x1407c8f10
0x142883988:  488b8c2490010000     mov       rcx, qword ptr [rsp + 0x190]
0x142883990:  4833cc               xor       rcx, rsp
0x142883993:  e848dc2903           call      0x145b215e0
0x142883998:  488b9c24e0010000     mov       rbx, qword ptr [rsp + 0x1e0]
0x1428839a0:  4881c4a0010000       add       rsp, 0x1a0
0x1428839a7:  415f                 pop       r15
0x1428839a9:  415e                 pop       r14
0x1428839ab:  5f                   pop       rdi
0x1428839ac:  5e                   pop       rsi
0x1428839ad:  5d                   pop       rbp
0x1428839ae:  c3                   ret       
0x1428839af:  488bd6               mov       rdx, rsi
0x1428839b2:  498bce               mov       rcx, r14
0x1428839b5:  e8b6db0100           call      0x1428a1570
0x1428839ba:  488bce               mov       rcx, rsi
0x1428839bd:  e8aedc0100           call      0x1428a1670
0x1428839c2:  837e0c00             cmp       dword ptr [rsi + 0xc], 0
0x1428839c6:  762a                 jbe       0x1428839f2
0x1428839c8:  488b0e               mov       rcx, qword ptr [rsi]
0x1428839cb:  4885c9               test      rcx, rcx
0x1428839ce:  7422                 je        0x1428839f2
0x1428839d0:  488d79f8             lea       rdi, [rcx - 8]
0x1428839d4:  4c8d0d2569f4fd       lea       r9, [rip - 0x20b96db]
0x1428839db:  4c8b07               mov       r8, qword ptr [rdi]
0x1428839de:  ba10000000           mov       edx, 0x10
0x1428839e3:  e8c8dc2903           call      0x145b216b0
0x1428839e8:  90                   nop       
0x1428839e9:  488bcf               mov       rcx, rdi
0x1428839ec:  e8bff60b02           call      0x1449430b0
0x1428839f1:  90                   nop       
0x1428839f2:  488d8bd0070000       lea       rcx, [rbx + 0x7d0]
0x1428839f9:  e8b2fd2903           call      0x145b237b0
0x1428839fe:  85c0                 test      eax, eax
0x142883a00:  7520                 jne       0x142883a22
0x142883a02:  488bd6               mov       rdx, rsi
0x142883a05:  488d8bb0070000       lea       rcx, [rbx + 0x7b0]
0x142883a0c:  e83f130200           call      0x1428a4d50
0x142883a11:  488d8bd0070000       lea       rcx, [rbx + 0x7d0]
0x142883a18:  e8f3fd2903           call      0x145b23810
0x142883a1d:  e954ffffff           jmp       0x142883976
0x142883a22:  8bc8                 mov       ecx, eax
0x142883a24:  e857032a03           call      0x145b23d80
0x142883a29:  cc                   int3      
0x142883a2a:  8bc8                 mov       ecx, eax
0x142883a2c:  e84f032a03           call      0x145b23d80
0x142883a31:  cc                   int3      
0x142883a32:  cc                   int3      
0x142883a33:  cc                   int3      
0x142883a34:  cc                   int3      
0x142883a35:  cc                   int3      
0x142883a36:  cc                   int3      
0x142883a37:  cc                   int3      
0x142883a38:  cc                   int3      
0x142883a39:  cc                   int3      
0x142883a3a:  cc                   int3      
0x142883a3b:  cc                   int3      
0x142883a3c:  cc                   int3      
0x142883a3d:  cc                   int3      
0x142883a3e:  cc                   int3      
0x142883a3f:  cc                   int3      
