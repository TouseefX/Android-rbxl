; RakPeer vtable slot 56
; rva 0x2882e60
0x142882e60:  48896c2418           mov       qword ptr [rsp + 0x18], rbp
0x142882e65:  4889742420           mov       qword ptr [rsp + 0x20], rsi
0x142882e6a:  57                   push      rdi
0x142882e6b:  4883ec20             sub       rsp, 0x20
0x142882e6f:  0fb72dd4c95605       movzx     ebp, word ptr [rip + 0x556c9d4]
0x142882e76:  4c8bd1               mov       r10, rcx
0x142882e79:  488b3dd8c95605       mov       rdi, qword ptr [rip + 0x556c9d8]
0x142882e80:  488b35c9c95605       mov       rsi, qword ptr [rip + 0x556c9c9]
0x142882e87:  8b0dbfc95605         mov       ecx, dword ptr [rip + 0x556c9bf]
0x142882e8d:  440fb705b3c95605     movzx     r8d, word ptr [rip + 0x556c9b3]
0x142882e95:  66396a02             cmp       word ptr [rdx + 2], bp
0x142882e99:  752a                 jne       0x142882ec5
0x142882e9b:  0fb702               movzx     eax, word ptr [rdx]
0x142882e9e:  66413bc0             cmp       ax, r8w
0x142882ea2:  7521                 jne       0x142882ec5
0x142882ea4:  6683f802             cmp       ax, 2
0x142882ea8:  7505                 jne       0x142882eaf
0x142882eaa:  394a04               cmp       dword ptr [rdx + 4], ecx
0x142882ead:  eb10                 jmp       0x142882ebf
0x142882eaf:  6683f817             cmp       ax, 0x17
0x142882eb3:  7510                 jne       0x142882ec5
0x142882eb5:  48397208             cmp       qword ptr [rdx + 8], rsi
0x142882eb9:  750a                 jne       0x142882ec5
0x142882ebb:  48397a10             cmp       qword ptr [rdx + 0x10], rdi
0x142882ebf:  0f84df000000         je        0x142882fa4
0x142882ec5:  0f100a               movups    xmm1, xmmword ptr [rdx]
0x142882ec8:  48895c2430           mov       qword ptr [rsp + 0x30], rbx
0x142882ecd:  0f104210             movups    xmm0, xmmword ptr [rdx + 0x10]
0x142882ed1:  66490f7ec9           movq      r9, xmm1
0x142882ed6:  0f290c24             movaps    xmmword ptr [rsp], xmm1
0x142882eda:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882edf:  498bc1               mov       rax, r9
0x142882ee2:  48c1e810             shr       rax, 0x10
0x142882ee6:  0f29442410           movaps    xmmword ptr [rsp + 0x10], xmm0
0x142882eeb:  4c8b5c2410           mov       r11, qword ptr [rsp + 0x10]
0x142882ef0:  663bc5               cmp       ax, bp
0x142882ef3:  752d                 jne       0x142882f22
0x142882ef5:  66453bc8             cmp       r9w, r8w
0x142882ef9:  7527                 jne       0x142882f22
0x142882efb:  664183f902           cmp       r9w, 2
0x142882f00:  750b                 jne       0x142882f0d
0x142882f02:  498bc1               mov       rax, r9
0x142882f05:  48c1e820             shr       rax, 0x20
0x142882f09:  3bc1                 cmp       eax, ecx
0x142882f0b:  eb0f                 jmp       0x142882f1c
0x142882f0d:  664183f917           cmp       r9w, 0x17
0x142882f12:  750e                 jne       0x142882f22
0x142882f14:  483bde               cmp       rbx, rsi
0x142882f17:  7509                 jne       0x142882f22
0x142882f19:  4c3bdf               cmp       r11, rdi
0x142882f1c:  0f847d000000         je        0x142882f9f
0x142882f22:  4533c0               xor       r8d, r8d
0x142882f25:  66453b8212010000     cmp       r8w, word ptr [r10 + 0x112]
0x142882f2d:  7370                 jae       0x142882f9f
0x142882f2f:  90                   nop       
0x142882f30:  4963c0               movsxd    rax, r8d
0x142882f33:  4869d0d8160000       imul      rdx, rax, 0x16d8
0x142882f3a:  0fb7442402           movzx     eax, word ptr [rsp + 2]
0x142882f3f:  49039250030000       add       rdx, qword ptr [r10 + 0x350]
0x142882f46:  66394206             cmp       word ptr [rdx + 6], ax
0x142882f4a:  7543                 jne       0x142882f8f
0x142882f4c:  0fb74204             movzx     eax, word ptr [rdx + 4]
0x142882f50:  66413bc1             cmp       ax, r9w
0x142882f54:  7539                 jne       0x142882f8f
0x142882f56:  6683f802             cmp       ax, 2
0x142882f5a:  750b                 jne       0x142882f67
0x142882f5c:  8b442404             mov       eax, dword ptr [rsp + 4]
0x142882f60:  394208               cmp       dword ptr [rdx + 8], eax
0x142882f63:  7414                 je        0x142882f79
0x142882f65:  eb28                 jmp       0x142882f8f
0x142882f67:  6683f817             cmp       ax, 0x17
0x142882f6b:  7522                 jne       0x142882f8f
0x142882f6d:  48395a0c             cmp       qword ptr [rdx + 0xc], rbx
0x142882f71:  751c                 jne       0x142882f8f
0x142882f73:  4c395a14             cmp       qword ptr [rdx + 0x14], r11
0x142882f77:  7516                 jne       0x142882f8f
0x142882f79:  0fb602               movzx     eax, byte ptr [rdx]
0x142882f7c:  90                   nop       
0x142882f7d:  84c0                 test      al, al
0x142882f7f:  751e                 jne       0x142882f9f
0x142882f81:  4c8b5c2410           mov       r11, qword ptr [rsp + 0x10]
0x142882f86:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882f8b:  4c8b0c24             mov       r9, qword ptr [rsp]
0x142882f8f:  410fb78212010000     movzx     eax, word ptr [r10 + 0x112]
0x142882f97:  41ffc0               inc       r8d
0x142882f9a:  443bc0               cmp       r8d, eax
0x142882f9d:  7291                 jb        0x142882f30
0x142882f9f:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142882fa4:  418b823c090000       mov       eax, dword ptr [r10 + 0x93c]
0x142882fab:  488b6c2440           mov       rbp, qword ptr [rsp + 0x40]
0x142882fb0:  488b742448           mov       rsi, qword ptr [rsp + 0x48]
0x142882fb5:  4883c420             add       rsp, 0x20
0x142882fb9:  5f                   pop       rdi
0x142882fba:  c3                   ret       
0x142882fbb:  cc                   int3      
0x142882fbc:  cc                   int3      
0x142882fbd:  cc                   int3      
0x142882fbe:  cc                   int3      
0x142882fbf:  cc                   int3      
