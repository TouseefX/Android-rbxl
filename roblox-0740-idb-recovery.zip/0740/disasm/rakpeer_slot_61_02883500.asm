; RakPeer vtable slot 61
; rva 0x2883500
0x142883500:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x142883505:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x14288350a:  48897c2418           mov       qword ptr [rsp + 0x18], rdi
0x14288350f:  4156                 push      r14
0x142883511:  4883ec20             sub       rsp, 0x20
0x142883515:  488bfa               mov       rdi, rdx
0x142883518:  4c8bf1               mov       r14, rcx
0x14288351b:  4885d2               test      rdx, rdx
0x14288351e:  0f84ab000000         je        0x1428835cf
0x142883524:  803a00               cmp       byte ptr [rdx], 0
0x142883527:  0f84a2000000         je        0x1428835cf
0x14288352d:  488d15dc376704       lea       rdx, [rip + 0x46737dc]
0x142883534:  488bcf               mov       rcx, rdi
0x142883537:  e8846e5503           call      0x145dda3c0
0x14288353c:  85c0                 test      eax, eax
0x14288353e:  7433                 je        0x142883573
0x142883540:  488d15c1c96004       lea       rdx, [rip + 0x460c9c1]
0x142883547:  488bcf               mov       rcx, rdi
0x14288354a:  e8716e5503           call      0x145dda3c0
0x14288354f:  85c0                 test      eax, eax
0x142883551:  7420                 je        0x142883573
0x142883553:  33db                 xor       ebx, ebx
0x142883555:  488d1574596704       lea       rdx, [rip + 0x4675974]
0x14288355c:  8bcb                 mov       ecx, ebx
0x14288355e:  6690                 nop       
0x142883560:  0fb6040f             movzx     eax, byte ptr [rdi + rcx]
0x142883564:  48ffc1               inc       rcx
0x142883567:  3a440aff             cmp       al, byte ptr [rdx + rcx - 1]
0x14288356b:  750a                 jne       0x142883577
0x14288356d:  4883f904             cmp       rcx, 4
0x142883571:  75ed                 jne       0x142883560
0x142883573:  b001                 mov       al, 1
0x142883575:  eb5a                 jmp       0x1428835d1
0x142883577:  498b06               mov       rax, qword ptr [r14]
0x14288357a:  498bce               mov       rcx, r14
0x14288357d:  488b80d8010000       mov       rax, qword ptr [rax + 0x1d8]
0x142883584:  ff15aec78b03         call      qword ptr [rip + 0x38bc7ae]
0x14288358a:  8bf0                 mov       esi, eax
0x14288358c:  85c0                 test      eax, eax
0x14288358e:  7e3f                 jle       0x1428835cf
0x142883590:  498b0e               mov       rcx, qword ptr [r14]
0x142883593:  8bd3                 mov       edx, ebx
0x142883595:  488b81e0010000       mov       rax, qword ptr [rcx + 0x1e0]
0x14288359c:  498bce               mov       rcx, r14
0x14288359f:  ff1593c78b03         call      qword ptr [rip + 0x38bc793]
0x1428835a5:  482bc7               sub       rax, rdi
0x1428835a8:  488bcf               mov       rcx, rdi
0x1428835ab:  0f1f440000           nop       dword ptr [rax + rax]
0x1428835b0:  440fb601             movzx     r8d, byte ptr [rcx]
0x1428835b4:  0fb61401             movzx     edx, byte ptr [rcx + rax]
0x1428835b8:  442bc2               sub       r8d, edx
0x1428835bb:  7507                 jne       0x1428835c4
0x1428835bd:  48ffc1               inc       rcx
0x1428835c0:  85d2                 test      edx, edx
0x1428835c2:  75ec                 jne       0x1428835b0
0x1428835c4:  4585c0               test      r8d, r8d
0x1428835c7:  74aa                 je        0x142883573
0x1428835c9:  ffc3                 inc       ebx
0x1428835cb:  3bde                 cmp       ebx, esi
0x1428835cd:  7cc1                 jl        0x142883590
0x1428835cf:  32c0                 xor       al, al
0x1428835d1:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x1428835d6:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x1428835db:  488b7c2440           mov       rdi, qword ptr [rsp + 0x40]
0x1428835e0:  4883c420             add       rsp, 0x20
0x1428835e4:  415e                 pop       r14
0x1428835e6:  c3                   ret       
0x1428835e7:  cc                   int3      
0x1428835e8:  cc                   int3      
0x1428835e9:  cc                   int3      
0x1428835ea:  cc                   int3      
0x1428835eb:  cc                   int3      
0x1428835ec:  cc                   int3      
0x1428835ed:  cc                   int3      
0x1428835ee:  cc                   int3      
0x1428835ef:  cc                   int3      
0x1428835f0:  889154090000         mov       byte ptr [rcx + 0x954], dl
0x1428835f6:  c3                   ret       
0x1428835f7:  cc                   int3      
0x1428835f8:  cc                   int3      
0x1428835f9:  cc                   int3      
0x1428835fa:  cc                   int3      
0x1428835fb:  cc                   int3      
0x1428835fc:  cc                   int3      
0x1428835fd:  cc                   int3      
0x1428835fe:  cc                   int3      
0x1428835ff:  cc                   int3      
