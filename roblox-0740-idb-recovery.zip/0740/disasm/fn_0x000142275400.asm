; function_of: str.Generating new Rupp token
; xref site 0x142275465 -> str.Generating new Rupp token @ 0x146f0ae68
; range 0x142275400 .. 0x142275560  (352 bytes)

0x000142275400:  4053                  push      rbx
0x000142275402:  4881eca0000000        sub       rsp, 0xa0
0x000142275409:  488b05e0e2a905        mov       rax, qword ptr [rip + 0x5a9e2e0]
0x000142275410:  4833c4                xor       rax, rsp
0x000142275413:  4889842498000000      mov       qword ptr [rsp + 0x98], rax
0x00014227541b:  4883794000            cmp       qword ptr [rcx + 0x40], 0
0x000142275420:  488bd9                mov       rbx, rcx
0x000142275423:  750a                  jne       0x14227542f
0x000142275425:  b80c000000            mov       eax, 0xc
0x00014227542a:  e909010000            jmp       0x142275538
0x00014227542f:  488b0512abae05        mov       rax, qword ptr [rip + 0x5aeab12]
0x000142275436:  3c06                  cmp       al, 6
0x000142275438:  0f8293000000          jb        0x1422754d1
0x00014227543e:  48c1e808              shr       rax, 8
0x000142275442:  3c06                  cmp       al, 6
0x000142275444:  0f8287000000          jb        0x1422754d1
0x00014227544a:  488d052823d404        lea       rax, [rip + 0x4d42328]
0x000142275451:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x000142275456:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x00014227545d:  488b4c2460            mov       rcx, qword ptr [rsp + 0x60]
0x000142275462:  488d0dff59c904        lea       rcx, [rip + 0x4c959ff]
0x000142275469:  48894c2440            mov       qword ptr [rsp + 0x40], rcx
0x00014227546e:  6690                  nop       
0x000142275470:  48ffc0                inc       rax
0x000142275473:  803c0100              cmp       byte ptr [rcx + rax], 0
0x000142275477:  75f7                  jne       0x142275470
0x000142275479:  4889442448            mov       qword ptr [rsp + 0x48], rax
0x00014227547e:  4c8d4c2430            lea       r9, [rsp + 0x30]
0x000142275483:  0f284c2440            movaps    xmm1, xmmword ptr [rsp + 0x40]
0x000142275488:  488d842488000000      lea       rax, [rsp + 0x88]
0x000142275490:  4889442438            mov       qword ptr [rsp + 0x38], rax
0x000142275495:  4c8d442440            lea       r8, [rsp + 0x40]
0x00014227549a:  48c744243000000000    mov       qword ptr [rsp + 0x30], 0
0x0001422754a3:  488d4c2460            lea       rcx, [rsp + 0x60]
0x0001422754a8:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x0001422754ad:  b206                  mov       dl, 6
0x0001422754af:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x0001422754b5:  0f10058caaae05        movups    xmm0, xmmword ptr [rip + 0x5aeaa8c]
0x0001422754bc:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x0001422754c1:  660f7f4c2440          movdqa    xmmword ptr [rsp + 0x40], xmm1
0x0001422754c7:  0f29442460            movaps    xmmword ptr [rsp + 0x60], xmm0
0x0001422754cc:  e8ffa56e02            call      0x14495fad0
0x0001422754d1:  488b4b40              mov       rcx, qword ptr [rbx + 0x40]
0x0001422754d5:  33c0                  xor       eax, eax
0x0001422754d7:  88842480000000        mov       byte ptr [rsp + 0x80], al
0x0001422754de:  0f57c0                xorps     xmm0, xmm0
0x0001422754e1:  0f11442470            movups    xmmword ptr [rsp + 0x70], xmm0
0x0001422754e6:  4885c9                test      rcx, rcx
0x0001422754e9:  7466                  je        0x142275551
0x0001422754eb:  488b01                mov       rax, qword ptr [rcx]
0x0001422754ee:  488d542470            lea       rdx, [rsp + 0x70]
0x0001422754f3:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x0001422754f7:  ff153ba8ec03          call      qword ptr [rip + 0x3eca83b]
0x0001422754fd:  0fb6542470            movzx     edx, byte ptr [rsp + 0x70]
0x000142275502:  84d2                  test      dl, dl
0x000142275504:  7507                  jne       0x14227550d
0x000142275506:  b809000000            mov       eax, 9
0x00014227550b:  eb2b                  jmp       0x142275538
0x00014227550d:  48c744245810000000    mov       qword ptr [rsp + 0x58], 0x10
0x000142275516:  488d442471            lea       rax, [rsp + 0x71]
0x00014227551b:  4889442450            mov       qword ptr [rsp + 0x50], rax
0x000142275520:  4c8d442450            lea       r8, [rsp + 0x50]
0x000142275525:  0f28442450            movaps    xmm0, xmmword ptr [rsp + 0x50]
0x00014227552a:  488bcb                mov       rcx, rbx
0x00014227552d:  660f7f442450          movdqa    xmmword ptr [rsp + 0x50], xmm0
0x000142275533:  e838070000            call      0x142275c70
0x000142275538:  488b8c2498000000      mov       rcx, qword ptr [rsp + 0x98]
0x000142275540:  4833cc                xor       rcx, rsp
0x000142275543:  e898c08a03            call      0x145b215e0
0x000142275548:  4881c4a0000000        add       rsp, 0xa0
0x00014227554f:  5b                    pop       rbx
0x000142275550:  c3                    ret       
0x000142275551:  e83ade8a03            call      0x145b23390
0x000142275556:  cc                    int3      
0x000142275557:  cc                    int3      
0x000142275558:  cc                    int3      
0x000142275559:  cc                    int3      
0x00014227555a:  cc                    int3      
0x00014227555b:  cc                    int3      
0x00014227555c:  cc                    int3      
0x00014227555d:  cc                    int3      
0x00014227555e:  cc                    int3      
0x00014227555f:  cc                    int3      
