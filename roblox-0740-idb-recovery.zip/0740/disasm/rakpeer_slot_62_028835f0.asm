; RakPeer vtable slot 62
; rva 0x28835f0
0x1428835f0:  889154090000         mov       byte ptr [rcx + 0x954], dl
0x1428835f6:  c3                   ret       
0x1428835f7:  cc                   int3      
0x1428835f8:  cc                   int3      
0x1428835f9:  cc                   int3      
0x1428835fa:  cc                   int3      
0x1428835fb:  cc                   int3      
0x1428835fc:  cc                   int3      
0x1428835fd:  cc                   int3      
0x1428835fe:  cc                   int3      
0x1428835ff:  cc                   int3      
