; ClientRuppGenerator vtable slot 3 rva 0x2271fc0
0x142271fc0:  48895c2420           mov       qword ptr [rsp + 0x20], rbx
0x142271fc5:  55                   push      rbp
0x142271fc6:  56                   push      rsi
0x142271fc7:  57                   push      rdi
0x142271fc8:  4156                 push      r14
0x142271fca:  4157                 push      r15
0x142271fcc:  4881ecb0000000       sub       rsp, 0xb0
0x142271fd3:  488b051617aa05       mov       rax, qword ptr [rip + 0x5aa1716]
0x142271fda:  4833c4               xor       rax, rsp
0x142271fdd:  48898424a0000000     mov       qword ptr [rsp + 0xa0], rax
0x142271fe5:  4d8bf9               mov       r15, r9
0x142271fe8:  4d8bf0               mov       r14, r8
0x142271feb:  488bda               mov       rbx, rdx
0x142271fee:  488be9               mov       rbp, rcx
0x142271ff1:  0fb64204             movzx     eax, byte ptr [rdx + 4]
0x142271ff5:  84c0                 test      al, al
0x142271ff7:  750a                 jne       0x142272003
0x142271ff9:  b809000000           mov       eax, 9
0x142271ffe:  e9d1010000           jmp       0x1422721d4
0x142272003:  3c02                 cmp       al, 2
0x142272005:  0f85c4010000         jne       0x1422721cf
0x14227200b:  4c8b8120010000       mov       r8, qword ptr [rcx + 0x120]
0x142272012:  0f104208             movups    xmm0, xmmword ptr [rdx + 8]
0x142272016:  0f29442430           movaps    xmmword ptr [rsp + 0x30], xmm0
0x14227201b:  660f73d808           psrldq    xmm0, 8
0x142272020:  66480f7ec0           movq      rax, xmm0
0x142272025:  4c3bc0               cmp       r8, rax
0x142272028:  7519                 jne       0x142272043
0x14227202a:  488b542430           mov       rdx, qword ptr [rsp + 0x30]
0x14227202f:  488b8918010000       mov       rcx, qword ptr [rcx + 0x118]
0x142272036:  e8f5178d03           call      0x145b43830
0x14227203b:  85c0                 test      eax, eax
0x14227203d:  0f848c010000         je        0x1422721cf
0x142272043:  488b05e6dfae05       mov       rax, qword ptr [rip + 0x5aedfe6]
0x14227204a:  3c06                 cmp       al, 6
0x14227204c:  0f8205010000         jb        0x142272157
0x142272052:  48c1e808             shr       rax, 8
0x142272056:  3c06                 cmp       al, 6
0x142272058:  0f82f9000000         jb        0x142272157
0x14227205e:  488d05420cce04       lea       rax, [rip + 0x4ce0c42]
0x142272065:  4889442460           mov       qword ptr [rsp + 0x60], rax
0x14227206a:  488b7c2460           mov       rdi, qword ptr [rsp + 0x60]
0x14227206f:  488d3dda88c904       lea       rdi, [rip + 0x4c988da]
0x142272076:  488d942480000000     lea       rdx, [rsp + 0x80]
0x14227207e:  498bce               mov       rcx, r14
0x142272081:  e8fa70f3ff           call      0x1421a9180
0x142272086:  90                   nop       
0x142272087:  48897c2450           mov       qword ptr [rsp + 0x50], rdi
0x14227208c:  48c7c1ffffffff       mov       rcx, 0xffffffffffffffff
0x142272093:  48ffc1               inc       rcx
0x142272096:  803c0f00             cmp       byte ptr [rdi + rcx], 0
0x14227209a:  75f7                 jne       0x142272093
0x14227209c:  48894c2458           mov       qword ptr [rsp + 0x58], rcx
0x1422720a1:  488bc8               mov       rcx, rax
0x1422720a4:  4883781810           cmp       qword ptr [rax + 0x18], 0x10
0x1422720a9:  7203                 jb        0x1422720ae
0x1422720ab:  488b08               mov       rcx, qword ptr [rax]
0x1422720ae:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x1422720b2:  48894c2470           mov       qword ptr [rsp + 0x70], rcx
0x1422720b7:  4889442478           mov       qword ptr [rsp + 0x78], rax
0x1422720bc:  0f28442470           movaps    xmm0, xmmword ptr [rsp + 0x70]
0x1422720c1:  660f7f442470         movdqa    xmmword ptr [rsp + 0x70], xmm0
0x1422720c7:  48c74424400d000000   mov       qword ptr [rsp + 0x40], 0xd
0x1422720d0:  488d442470           lea       rax, [rsp + 0x70]
0x1422720d5:  4889442448           mov       qword ptr [rsp + 0x48], rax
0x1422720da:  0f28442440           movaps    xmm0, xmmword ptr [rsp + 0x40]
0x1422720df:  660f7f442440         movdqa    xmmword ptr [rsp + 0x40], xmm0
0x1422720e5:  0f284c2450           movaps    xmm1, xmmword ptr [rsp + 0x50]
0x1422720ea:  660f7f4c2450         movdqa    xmmword ptr [rsp + 0x50], xmm1
0x1422720f0:  0f100539dfae05       movups    xmm0, xmmword ptr [rip + 0x5aedf39]
0x1422720f7:  0f29442460           movaps    xmmword ptr [rsp + 0x60], xmm0
0x1422720fc:  c644242001           mov       byte ptr [rsp + 0x20], 1
0x142272101:  4c8d4c2440           lea       r9, [rsp + 0x40]
0x142272106:  4c8d442450           lea       r8, [rsp + 0x50]
0x14227210b:  b206                 mov       dl, 6
0x14227210d:  488d4c2460           lea       rcx, [rsp + 0x60]
0x142272112:  e8b9d96e02           call      0x14495fad0
0x142272117:  90                   nop       
0x142272118:  488b842498000000     mov       rax, qword ptr [rsp + 0x98]
0x142272120:  4883f810             cmp       rax, 0x10
0x142272124:  7231                 jb        0x142272157
0x142272126:  48ffc0               inc       rax
0x142272129:  488b8c2480000000     mov       rcx, qword ptr [rsp + 0x80]
0x142272131:  488bd1               mov       rdx, rcx
0x142272134:  483d00100000         cmp       rax, 0x1000
0x14227213a:  7215                 jb        0x142272151
0x14227213c:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x142272140:  482bd1               sub       rdx, rcx
0x142272143:  488d42f8             lea       rax, [rdx - 8]
0x142272147:  4883f81f             cmp       rax, 0x1f
0x14227214b:  0f87aa000000         ja        0x1422721fb
0x142272151:  e85a0f6d02           call      0x1449430b0
0x142272156:  90                   nop       
0x142272157:  488d4d60             lea       rcx, [rbp + 0x60]
0x14227215b:  807b0400             cmp       byte ptr [rbx + 4], 0
0x14227215f:  0f8494feffff         je        0x142271ff9
0x142272165:  4883794000           cmp       qword ptr [rcx + 0x40], 0
0x14227216a:  7563                 jne       0x1422721cf
0x14227216c:  4c897958             mov       qword ptr [rcx + 0x58], r15
0x142272170:  488b4308             mov       rax, qword ptr [rbx + 8]
0x142272174:  4889442430           mov       qword ptr [rsp + 0x30], rax
0x142272179:  48c744243810000000   mov       qword ptr [rsp + 0x38], 0x10
0x142272182:  0f28442430           movaps    xmm0, xmmword ptr [rsp + 0x30]
0x142272187:  660f7f442430         movdqa    xmmword ptr [rsp + 0x30], xmm0
0x14227218d:  4c8d442430           lea       r8, [rsp + 0x30]
0x142272192:  0fb65304             movzx     edx, byte ptr [rbx + 4]
0x142272196:  e8d53a0000           call      0x142275c70
0x14227219b:  85c0                 test      eax, eax
0x14227219d:  7535                 jne       0x1422721d4
0x14227219f:  488b5308             mov       rdx, qword ptr [rbx + 8]
0x1422721a3:  4c8b4310             mov       r8, qword ptr [rbx + 0x10]
0x1422721a7:  4c03c2               add       r8, rdx
0x1422721aa:  48c7852001000000000000 mov       qword ptr [rbp + 0x120], 0
0x1422721b5:  488d8d18010000       lea       rcx, [rbp + 0x118]
0x1422721bc:  e87f5bf5fe           call      0x1411c7d40
0x1422721c1:  0fb64304             movzx     eax, byte ptr [rbx + 4]
0x1422721c5:  888558010000         mov       byte ptr [rbp + 0x158], al
0x1422721cb:  33c0                 xor       eax, eax
0x1422721cd:  eb05                 jmp       0x1422721d4
0x1422721cf:  b80c000000           mov       eax, 0xc
0x1422721d4:  488b8c24a0000000     mov       rcx, qword ptr [rsp + 0xa0]
0x1422721dc:  4833cc               xor       rcx, rsp
0x1422721df:  e8fcf38a03           call      0x145b215e0
0x1422721e4:  488b9c24f8000000     mov       rbx, qword ptr [rsp + 0xf8]
0x1422721ec:  4881c4b0000000       add       rsp, 0xb0
0x1422721f3:  415f                 pop       r15
0x1422721f5:  415e                 pop       r14
0x1422721f7:  5f                   pop       rdi
0x1422721f8:  5e                   pop       rsi
0x1422721f9:  5d                   pop       rbp
0x1422721fa:  c3                   ret       
0x1422721fb:  e820f38d03           call      0x145b51520
0x142272200:  cc                   int3      
0x142272201:  cc                   int3      
0x142272202:  cc                   int3      
0x142272203:  cc                   int3      
0x142272204:  cc                   int3      
0x142272205:  cc                   int3      
0x142272206:  cc                   int3      
0x142272207:  cc                   int3      
0x142272208:  cc                   int3      
0x142272209:  cc                   int3      
0x14227220a:  cc                   int3      
0x14227220b:  cc                   int3      
0x14227220c:  cc                   int3      
0x14227220d:  cc                   int3      
0x14227220e:  cc                   int3      
0x14227220f:  cc                   int3      
