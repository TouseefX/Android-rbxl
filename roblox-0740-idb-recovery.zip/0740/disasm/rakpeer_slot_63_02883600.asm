; RakPeer vtable slot 63
; rva 0x2883600
0x142883600:  33c0                 xor       eax, eax
0x142883602:  899178090000         mov       dword ptr [rcx + 0x978], edx
0x142883608:  4c8bc9               mov       r9, rcx
0x14288360b:  663b8112010000       cmp       ax, word ptr [rcx + 0x112]
0x142883612:  7339                 jae       0x14288364d
0x142883614:  0f1f4000             nop       dword ptr [rax]
0x142883618:  0f1f840000000000     nop       dword ptr [rax + rax]
0x142883620:  498b9150030000       mov       rdx, qword ptr [r9 + 0x350]
0x142883627:  0fb7c8               movzx     ecx, ax
0x14288362a:  66ffc0               inc       ax
0x14288362d:  4c69c1d8160000       imul      r8, rcx, 0x16d8
0x142883634:  418b8978090000       mov       ecx, dword ptr [r9 + 0x978]
0x14288363b:  41898c10b0010000     mov       dword ptr [r8 + rdx + 0x1b0], ecx
0x142883643:  66413b8112010000     cmp       ax, word ptr [r9 + 0x112]
0x14288364b:  72d3                 jb        0x142883620
0x14288364d:  c3                   ret       
0x14288364e:  cc                   int3      
0x14288364f:  cc                   int3      
0x142883650:  8b8178090000         mov       eax, dword ptr [rcx + 0x978]
0x142883656:  c3                   ret       
0x142883657:  cc                   int3      
0x142883658:  cc                   int3      
0x142883659:  cc                   int3      
0x14288365a:  cc                   int3      
0x14288365b:  cc                   int3      
0x14288365c:  cc                   int3      
0x14288365d:  cc                   int3      
0x14288365e:  cc                   int3      
0x14288365f:  cc                   int3      
