; function_of: vtab.Ipv4Tlv, vtab.Ipv6Tlv, vtab.TokenTlv
; xref site 0x142272469 -> vtab.Ipv6Tlv @ 0x146c98968
; xref site 0x142272506 -> vtab.Ipv4Tlv @ 0x146c98990
; xref site 0x142272666 -> vtab.TokenTlv @ 0x146c988f0
; xref site 0x142272750 -> vtab.Ipv6Tlv @ 0x146c98968
; range 0x142272210 .. 0x1422729b0  (1952 bytes)

0x000142272210:  488bc4                mov       rax, rsp
0x000142272213:  48895818              mov       qword ptr [rax + 0x18], rbx
0x000142272217:  48897020              mov       qword ptr [rax + 0x20], rsi
0x00014227221b:  55                    push      rbp
0x00014227221c:  57                    push      rdi
0x00014227221d:  4154                  push      r12
0x00014227221f:  4156                  push      r14
0x000142272221:  4157                  push      r15
0x000142272223:  488d68a8              lea       rbp, [rax - 0x58]
0x000142272227:  4881ec30010000        sub       rsp, 0x130
0x00014227222e:  0f2970c8              movaps    xmmword ptr [rax - 0x38], xmm6
0x000142272232:  488b05b714aa05        mov       rax, qword ptr [rip + 0x5aa14b7]
0x000142272239:  4833c4                xor       rax, rsp
0x00014227223c:  48894510              mov       qword ptr [rbp + 0x10], rax
0x000142272240:  4c8bfa                mov       r15, rdx
0x000142272243:  4c8bf1                mov       r14, rcx
0x000142272246:  66c74424500100        mov       word ptr [rsp + 0x50], 1
0x00014227224d:  4533e4                xor       r12d, r12d
0x000142272250:  4c896590              mov       qword ptr [rbp - 0x70], r12
0x000142272254:  44896598              mov       dword ptr [rbp - 0x68], r12d
0x000142272258:  4c8965a0              mov       qword ptr [rbp - 0x60], r12
0x00014227225c:  4c8965a8              mov       qword ptr [rbp - 0x58], r12
0x000142272260:  0f57c0                xorps     xmm0, xmm0
0x000142272263:  660f7f45b0            movdqa    xmmword ptr [rbp - 0x50], xmm0
0x000142272268:  4c8965c0              mov       qword ptr [rbp - 0x40], r12
0x00014227226c:  488d45e0              lea       rax, [rbp - 0x20]
0x000142272270:  488945c8              mov       qword ptr [rbp - 0x38], rax
0x000142272274:  4c8965d0              mov       qword ptr [rbp - 0x30], r12
0x000142272278:  48c745d820000000      mov       qword ptr [rbp - 0x28], 0x20
0x000142272280:  c74500ffffffff        mov       dword ptr [rbp], 0xffffffff
0x000142272287:  44886504              mov       byte ptr [rbp + 4], r12b
0x00014227228b:  66c741600100          mov       word ptr [rcx + 0x60], 1
0x000142272291:  4883c168              add       rcx, 0x68
0x000142272295:  488d542458            lea       rdx, [rsp + 0x58]
0x00014227229a:  e801a066fe            call      0x1408dc2a0
0x00014227229f:  8b4598                mov       eax, dword ptr [rbp - 0x68]
0x0001422722a2:  418986a8000000        mov       dword ptr [r14 + 0xa8], eax
0x0001422722a9:  488b45a0              mov       rax, qword ptr [rbp - 0x60]
0x0001422722ad:  498986b0000000        mov       qword ptr [r14 + 0xb0], rax
0x0001422722b4:  488b45a8              mov       rax, qword ptr [rbp - 0x58]
0x0001422722b8:  498986b8000000        mov       qword ptr [r14 + 0xb8], rax
0x0001422722bf:  498d9ec0000000        lea       rbx, [r14 + 0xc0]
0x0001422722c6:  488d45b0              lea       rax, [rbp - 0x50]
0x0001422722ca:  483bd8                cmp       rbx, rax
0x0001422722cd:  742b                  je        0x1422722fa
0x0001422722cf:  488bcb                mov       rcx, rbx
0x0001422722d2:  e8590cf0ff            call      0x142172f30
0x0001422722d7:  488b45b0              mov       rax, qword ptr [rbp - 0x50]
0x0001422722db:  488903                mov       qword ptr [rbx], rax
0x0001422722de:  488b45b8              mov       rax, qword ptr [rbp - 0x48]
0x0001422722e2:  48894308              mov       qword ptr [rbx + 8], rax
0x0001422722e6:  488b45c0              mov       rax, qword ptr [rbp - 0x40]
0x0001422722ea:  48894310              mov       qword ptr [rbx + 0x10], rax
0x0001422722ee:  0f57c0                xorps     xmm0, xmm0
0x0001422722f1:  660f7f45b0            movdqa    xmmword ptr [rbp - 0x50], xmm0
0x0001422722f6:  4c8965c0              mov       qword ptr [rbp - 0x40], r12
0x0001422722fa:  498d8ed8000000        lea       rcx, [r14 + 0xd8]
0x000142272301:  488d55c8              lea       rdx, [rbp - 0x38]
0x000142272305:  e8869667fe            call      0x1408eb990
0x00014227230a:  8b4500                mov       eax, dword ptr [rbp]
0x00014227230d:  41898610010000        mov       dword ptr [r14 + 0x110], eax
0x000142272314:  0fb64504              movzx     eax, byte ptr [rbp + 4]
0x000142272318:  41888614010000        mov       byte ptr [r14 + 0x114], al
0x00014227231f:  488d45e0              lea       rax, [rbp - 0x20]
0x000142272323:  488b4dc8              mov       rcx, qword ptr [rbp - 0x38]
0x000142272327:  483bc8                cmp       rcx, rax
0x00014227232a:  7406                  je        0x142272332
0x00014227232c:  e87f0d6d02            call      0x1449430b0
0x000142272331:  90                    nop       
0x000142272332:  488b5db0              mov       rbx, qword ptr [rbp - 0x50]
0x000142272336:  4885db                test      rbx, rbx
0x000142272339:  7477                  je        0x1422723b2
0x00014227233b:  488b7db8              mov       rdi, qword ptr [rbp - 0x48]
0x00014227233f:  483bdf                cmp       rbx, rdi
0x000142272342:  7426                  je        0x14227236a
0x000142272344:  488b0b                mov       rcx, qword ptr [rbx]
0x000142272347:  4885c9                test      rcx, rcx
0x00014227234a:  7411                  je        0x14227235d
0x00014227234c:  488b01                mov       rax, qword ptr [rcx]
0x00014227234f:  ba01000000            mov       edx, 1
0x000142272354:  488b00                mov       rax, qword ptr [rax]
0x000142272357:  ff15dbd9ec03          call      qword ptr [rip + 0x3ecd9db]
0x00014227235d:  4883c308              add       rbx, 8
0x000142272361:  483bdf                cmp       rbx, rdi
0x000142272364:  75de                  jne       0x142272344
0x000142272366:  488b5db0              mov       rbx, qword ptr [rbp - 0x50]
0x00014227236a:  488b45c0              mov       rax, qword ptr [rbp - 0x40]
0x00014227236e:  482bc3                sub       rax, rbx
0x000142272371:  48c1f803              sar       rax, 3
0x000142272375:  488d04c500000000      lea       rax, [rax*8]
0x00014227237d:  488bcb                mov       rcx, rbx
0x000142272380:  483d00100000          cmp       rax, 0x1000
0x000142272386:  7215                  jb        0x14227239d
0x000142272388:  488b5bf8              mov       rbx, qword ptr [rbx - 8]
0x00014227238c:  482bcb                sub       rcx, rbx
0x00014227238f:  488d41f8              lea       rax, [rcx - 8]
0x000142272393:  4883f81f              cmp       rax, 0x1f
0x000142272397:  0f87d1010000          ja        0x14227256e
0x00014227239d:  488bcb                mov       rcx, rbx
0x0001422723a0:  e80b0d6d02            call      0x1449430b0
0x0001422723a5:  90                    nop       
0x0001422723a6:  0f57c0                xorps     xmm0, xmm0
0x0001422723a9:  660f7f45b0            movdqa    xmmword ptr [rbp - 0x50], xmm0
0x0001422723ae:  4c8965c0              mov       qword ptr [rbp - 0x40], r12
0x0001422723b2:  488b4d90              mov       rcx, qword ptr [rbp - 0x70]
0x0001422723b6:  4885c9                test      rcx, rcx
0x0001422723b9:  7418                  je        0x1422723d3
0x0001422723bb:  488b01                mov       rax, qword ptr [rcx]
0x0001422723be:  488d542458            lea       rdx, [rsp + 0x58]
0x0001422723c3:  483bca                cmp       rcx, rdx
0x0001422723c6:  0f95c2                setne     dl
0x0001422723c9:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x0001422723cd:  ff1565d9ec03          call      qword ptr [rip + 0x3ecd965]
0x0001422723d3:  4d89a6e0000000        mov       qword ptr [r14 + 0xe0], r12
0x0001422723da:  498bd7                mov       rdx, r15
0x0001422723dd:  498d4e60              lea       rcx, [r14 + 0x60]
0x0001422723e1:  e89a350000            call      0x142275980
0x0001422723e6:  498d8e18010000        lea       rcx, [r14 + 0x118]
0x0001422723ed:  4c896108              mov       qword ptr [rcx + 8], r12
0x0001422723f1:  4d8d4711              lea       r8, [r15 + 0x11]
0x0001422723f5:  498d5701              lea       rdx, [r15 + 1]
0x0001422723f9:  e84259f5fe            call      0x1411c7d40
0x0001422723fe:  410fb607              movzx     eax, byte ptr [r15]
0x000142272402:  41888658010000        mov       byte ptr [r14 + 0x158], al
0x000142272409:  498d5e42              lea       rbx, [r14 + 0x42]
0x00014227240d:  0fb703                movzx     eax, word ptr [rbx]
0x000142272410:  6683f802              cmp       ax, 2
0x000142272414:  0f84ac000000          je        0x1422724c6
0x00014227241a:  6683f817              cmp       ax, 0x17
0x00014227241e:  0f850b010000          jne       0x14227252f
0x000142272424:  410fb74e44            movzx     ecx, word ptr [r14 + 0x44]
0x000142272429:  ff1501d4ec03          call      qword ptr [rip + 0x3ecd401]
0x00014227242f:  0fb7f8                movzx     edi, ax
0x000142272432:  0fb713                movzx     edx, word ptr [rbx]
0x000142272435:  6683fa02              cmp       dx, 2
0x000142272439:  7411                  je        0x14227244c
0x00014227243b:  488d0db6207606        lea       rcx, [rip + 0x67620b6]
0x000142272442:  6683fa17              cmp       dx, 0x17
0x000142272446:  480f44cb              cmove     rcx, rbx
0x00014227244a:  eb03                  jmp       0x14227244f
0x00014227244c:  488bcb                mov       rcx, rbx
0x00014227244f:  0f107108              movups    xmm6, xmmword ptr [rcx + 8]
0x000142272453:  b920000000            mov       ecx, 0x20
0x000142272458:  e8a3136d02            call      0x144943800
0x00014227245d:  4885c0                test      rax, rax
0x000142272460:  0f84d0000000          je        0x142272536
0x000142272466:  488d0dfb64a204        lea       rcx, [rip + 0x4a264fb]
0x00014227246d:  488908                mov       qword ptr [rax], rcx
0x000142272470:  0f117008              movups    xmmword ptr [rax + 8], xmm6
0x000142272474:  66897818              mov       word ptr [rax + 0x18], di
0x000142272478:  4c89642428            mov       qword ptr [rsp + 0x28], r12
0x00014227247d:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000142272482:  488d542420            lea       rdx, [rsp + 0x20]
0x000142272487:  498d4e60              lea       rcx, [r14 + 0x60]
0x00014227248b:  e8402e0000            call      0x1422752d0
0x000142272490:  90                    nop       
0x000142272491:  85c0                  test      eax, eax
0x000142272493:  0f8496000000          je        0x14227252f
0x000142272499:  488b4d10              mov       rcx, qword ptr [rbp + 0x10]
0x00014227249d:  4833cc                xor       rcx, rsp
0x0001422724a0:  e83bf18a03            call      0x145b215e0
0x0001422724a5:  4c8d9c2430010000      lea       r11, [rsp + 0x130]
0x0001422724ad:  498b5b40              mov       rbx, qword ptr [r11 + 0x40]
0x0001422724b1:  498b7348              mov       rsi, qword ptr [r11 + 0x48]
0x0001422724b5:  410f2873f0            movaps    xmm6, xmmword ptr [r11 - 0x10]
0x0001422724ba:  498be3                mov       rsp, r11
0x0001422724bd:  415f                  pop       r15
0x0001422724bf:  415e                  pop       r14
0x0001422724c1:  415c                  pop       r12
0x0001422724c3:  5f                    pop       rdi
0x0001422724c4:  5d                    pop       rbp
0x0001422724c5:  c3                    ret       
0x0001422724c6:  410fb74e44            movzx     ecx, word ptr [r14 + 0x44]
0x0001422724cb:  ff155fd3ec03          call      qword ptr [rip + 0x3ecd35f]
0x0001422724d1:  0fb7f8                movzx     edi, ax
0x0001422724d4:  0fb713                movzx     edx, word ptr [rbx]
0x0001422724d7:  6683fa02              cmp       dx, 2
0x0001422724db:  7411                  je        0x1422724ee
0x0001422724dd:  488d0d14207606        lea       rcx, [rip + 0x6762014]
0x0001422724e4:  6683fa17              cmp       dx, 0x17
0x0001422724e8:  480f44cb              cmove     rcx, rbx
0x0001422724ec:  eb03                  jmp       0x1422724f1
0x0001422724ee:  488bcb                mov       rcx, rbx
0x0001422724f1:  8b5904                mov       ebx, dword ptr [rcx + 4]
0x0001422724f4:  b910000000            mov       ecx, 0x10
0x0001422724f9:  e802136d02            call      0x144943800
0x0001422724fe:  4885c0                test      rax, rax
0x000142272501:  744f                  je        0x142272552
0x000142272503:  488d0d8664a204        lea       rcx, [rip + 0x4a26486]
0x00014227250a:  488908                mov       qword ptr [rax], rcx
0x00014227250d:  895808                mov       dword ptr [rax + 8], ebx
0x000142272510:  6689780c              mov       word ptr [rax + 0xc], di
0x000142272514:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000142272519:  488d542420            lea       rdx, [rsp + 0x20]
0x00014227251e:  498d4e60              lea       rcx, [r14 + 0x60]
0x000142272522:  e8a92d0000            call      0x1422752d0
0x000142272527:  85c0                  test      eax, eax
0x000142272529:  0f856affffff          jne       0x142272499
0x00014227252f:  33c0                  xor       eax, eax
0x000142272531:  e963ffffff            jmp       0x142272499
0x000142272536:  488d4c2430            lea       rcx, [rsp + 0x30]
0x00014227253b:  e8b08854fe            call      0x1407badf0
0x000142272540:  488d15f946a905        lea       rdx, [rip + 0x5a946f9]
0x000142272547:  488d4c2430            lea       rcx, [rsp + 0x30]
0x00014227254c:  e8ff0a8d03            call      0x145b43050
0x000142272551:  cc                    int3      
0x000142272552:  488d4c2430            lea       rcx, [rsp + 0x30]
0x000142272557:  e8948854fe            call      0x1407badf0
0x00014227255c:  488d15dd46a905        lea       rdx, [rip + 0x5a946dd]
0x000142272563:  488d4c2430            lea       rcx, [rsp + 0x30]
0x000142272568:  e8e30a8d03            call      0x145b43050
0x00014227256d:  cc                    int3      
0x00014227256e:  e8adef8d03            call      0x145b51520
0x000142272573:  cc                    int3      
0x000142272574:  cc                    int3      
0x000142272575:  cc                    int3      
0x000142272576:  cc                    int3      
0x000142272577:  cc                    int3      
0x000142272578:  cc                    int3      
0x000142272579:  cc                    int3      
0x00014227257a:  cc                    int3      
0x00014227257b:  cc                    int3      
0x00014227257c:  cc                    int3      
0x00014227257d:  cc                    int3      
0x00014227257e:  cc                    int3      
0x00014227257f:  cc                    int3      
0x000142272580:  48895c2418            mov       qword ptr [rsp + 0x18], rbx
0x000142272585:  55                    push      rbp
0x000142272586:  56                    push      rsi
0x000142272587:  57                    push      rdi
0x000142272588:  4156                  push      r14
0x00014227258a:  4157                  push      r15
0x00014227258c:  4881ec80000000        sub       rsp, 0x80
0x000142272593:  488b055611aa05        mov       rax, qword ptr [rip + 0x5aa1156]
0x00014227259a:  4833c4                xor       rax, rsp
0x00014227259d:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x0001422725a2:  4d8bf0                mov       r14, r8
0x0001422725a5:  488bda                mov       rbx, rdx
0x0001422725a8:  488bf1                mov       rsi, rcx
0x0001422725ab:  4889542440            mov       qword ptr [rsp + 0x40], rdx
0x0001422725b0:  4533ff                xor       r15d, r15d
0x0001422725b3:  44897c2428            mov       dword ptr [rsp + 0x28], r15d
0x0001422725b8:  c60204                mov       byte ptr [rdx], 4
0x0001422725bb:  488d4201              lea       rax, [rdx + 1]
0x0001422725bf:  448838                mov       byte ptr [rax], r15b
0x0001422725c2:  4c897a40              mov       qword ptr [rdx + 0x40], r15
0x0001422725c6:  44897a48              mov       dword ptr [rdx + 0x48], r15d
0x0001422725ca:  4c897a50              mov       qword ptr [rdx + 0x50], r15
0x0001422725ce:  4c897a58              mov       qword ptr [rdx + 0x58], r15
0x0001422725d2:  4c897a60              mov       qword ptr [rdx + 0x60], r15
0x0001422725d6:  4c897a68              mov       qword ptr [rdx + 0x68], r15
0x0001422725da:  4c897a70              mov       qword ptr [rdx + 0x70], r15
0x0001422725de:  488d4a78              lea       rcx, [rdx + 0x78]
0x0001422725e2:  48894c2420            mov       qword ptr [rsp + 0x20], rcx
0x0001422725e7:  488d4118              lea       rax, [rcx + 0x18]
0x0001422725eb:  488901                mov       qword ptr [rcx], rax
0x0001422725ee:  4c897908              mov       qword ptr [rcx + 8], r15
0x0001422725f2:  48c7411020000000      mov       qword ptr [rcx + 0x10], 0x20
0x0001422725fa:  c782b0000000ffffffff  mov       dword ptr [rdx + 0xb0], 0xffffffff
0x000142272604:  4488bab4000000        mov       byte ptr [rdx + 0xb4], r15b
0x00014227260b:  bd01000000            mov       ebp, 1
0x000142272610:  896c2428              mov       dword ptr [rsp + 0x28], ebp
0x000142272614:  4c89ba80000000        mov       qword ptr [rdx + 0x80], r15
0x00014227261b:  488b8e18010000        mov       rcx, qword ptr [rsi + 0x118]
0x000142272622:  0fb68658010000        movzx     eax, byte ptr [rsi + 0x158]
0x000142272629:  88442450              mov       byte ptr [rsp + 0x50], al
0x00014227262d:  84c0                  test      al, al
0x00014227262f:  7414                  je        0x142272645
0x000142272631:  4883be2001000010      cmp       qword ptr [rsi + 0x120], 0x10
0x000142272639:  750a                  jne       0x142272645
0x00014227263b:  0f1001                movups    xmm0, xmmword ptr [rcx]
0x00014227263e:  0f11442451            movups    xmmword ptr [rsp + 0x51], xmm0
0x000142272643:  eb08                  jmp       0x14227264d
0x000142272645:  0f57c0                xorps     xmm0, xmm0
0x000142272648:  0f11442451            movups    xmmword ptr [rsp + 0x51], xmm0
0x00014227264d:  b920000000            mov       ecx, 0x20
0x000142272652:  e8a9116d02            call      0x144943800
0x000142272657:  488bc8                mov       rcx, rax
0x00014227265a:  4885c0                test      rax, rax
0x00014227265d:  0f8441010000          je        0x1422727a4
0x000142272663:  488d058662a204        lea       rax, [rip + 0x4a26286]
0x00014227266a:  488901                mov       qword ptr [rcx], rax
0x00014227266d:  0f10442450            movups    xmm0, xmmword ptr [rsp + 0x50]
0x000142272672:  0f114108              movups    xmmword ptr [rcx + 8], xmm0
0x000142272676:  0fb6442460            movzx     eax, byte ptr [rsp + 0x60]
0x00014227267b:  884118                mov       byte ptr [rcx + 0x18], al
0x00014227267e:  48894c2420            mov       qword ptr [rsp + 0x20], rcx
0x000142272683:  488d542420            lea       rdx, [rsp + 0x20]
0x000142272688:  488bcb                mov       rcx, rbx
0x00014227268b:  e8402c0000            call      0x1422752d0
0x000142272690:  488d7e42              lea       rdi, [rsi + 0x42]
0x000142272694:  0fb707                movzx     eax, word ptr [rdi]
0x000142272697:  6683f802              cmp       ax, 2
0x00014227269b:  7568                  jne       0x142272705
0x00014227269d:  0fb74e44              movzx     ecx, word ptr [rsi + 0x44]
0x0001422726a1:  ff1589d1ec03          call      qword ptr [rip + 0x3ecd189]
0x0001422726a7:  440fb7c0              movzx     r8d, ax
0x0001422726ab:  0fb70f                movzx     ecx, word ptr [rdi]
0x0001422726ae:  6683f902              cmp       cx, 2
0x0001422726b2:  7411                  je        0x1422726c5
0x0001422726b4:  488d053d1e7606        lea       rax, [rip + 0x6761e3d]
0x0001422726bb:  6683f917              cmp       cx, 0x17
0x0001422726bf:  480f44c7              cmove     rax, rdi
0x0001422726c3:  eb03                  jmp       0x1422726c8
0x0001422726c5:  488bc7                mov       rax, rdi
0x0001422726c8:  8b5004                mov       edx, dword ptr [rax + 4]
0x0001422726cb:  488bcb                mov       rcx, rbx
0x0001422726ce:  e82d320000            call      0x142275900
0x0001422726d3:  498bd6                mov       rdx, r14
0x0001422726d6:  488bcb                mov       rcx, rbx
0x0001422726d9:  e8d2330000            call      0x142275ab0
0x0001422726de:  488bc3                mov       rax, rbx
0x0001422726e1:  488b4c2470            mov       rcx, qword ptr [rsp + 0x70]
0x0001422726e6:  4833cc                xor       rcx, rsp
0x0001422726e9:  e8f2ee8a03            call      0x145b215e0
0x0001422726ee:  488b9c24c0000000      mov       rbx, qword ptr [rsp + 0xc0]
0x0001422726f6:  4881c480000000        add       rsp, 0x80
0x0001422726fd:  415f                  pop       r15
0x0001422726ff:  415e                  pop       r14
0x000142272701:  5f                    pop       rdi
0x000142272702:  5e                    pop       rsi
0x000142272703:  5d                    pop       rbp
0x000142272704:  c3                    ret       
0x000142272705:  6683f817              cmp       ax, 0x17
0x000142272709:  75c8                  jne       0x1422726d3
0x00014227270b:  0fb74e44              movzx     ecx, word ptr [rsi + 0x44]
0x00014227270f:  ff151bd1ec03          call      qword ptr [rip + 0x3ecd11b]
0x000142272715:  0fb7f0                movzx     esi, ax
0x000142272718:  0fb70f                movzx     ecx, word ptr [rdi]
0x00014227271b:  6683f902              cmp       cx, 2
0x00014227271f:  7411                  je        0x142272732
0x000142272721:  488d05d01d7606        lea       rax, [rip + 0x6761dd0]
0x000142272728:  6683f917              cmp       cx, 0x17
0x00014227272c:  480f44c7              cmove     rax, rdi
0x000142272730:  eb03                  jmp       0x142272735
0x000142272732:  488bc7                mov       rax, rdi
0x000142272735:  0f104008              movups    xmm0, xmmword ptr [rax + 8]
0x000142272739:  0f29442450            movaps    xmmword ptr [rsp + 0x50], xmm0
0x00014227273e:  b920000000            mov       ecx, 0x20
0x000142272743:  e8b8106d02            call      0x144943800
0x000142272748:  4885c0                test      rax, rax
0x00014227274b:  743b                  je        0x142272788
0x00014227274d:  488d0d1462a204        lea       rcx, [rip + 0x4a26214]
0x000142272754:  488908                mov       qword ptr [rax], rcx
0x000142272757:  0f28442450            movaps    xmm0, xmmword ptr [rsp + 0x50]
0x00014227275c:  0f114008              movups    xmmword ptr [rax + 8], xmm0
0x000142272760:  66897018              mov       word ptr [rax + 0x18], si
0x000142272764:  83cd02                or        ebp, 2
0x000142272767:  896c2428              mov       dword ptr [rsp + 0x28], ebp
0x00014227276b:  4c897c2430            mov       qword ptr [rsp + 0x30], r15
0x000142272770:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000142272775:  488d542420            lea       rdx, [rsp + 0x20]
0x00014227277a:  488bcb                mov       rcx, rbx
0x00014227277d:  e84e2b0000            call      0x1422752d0
0x000142272782:  90                    nop       
0x000142272783:  e94bffffff            jmp       0x1422726d3
0x000142272788:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014227278d:  e85e8654fe            call      0x1407badf0
0x000142272792:  488d15a744a905        lea       rdx, [rip + 0x5a944a7]
0x000142272799:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014227279e:  e8ad088d03            call      0x145b43050
0x0001422727a3:  cc                    int3      
0x0001422727a4:  488d4c2450            lea       rcx, [rsp + 0x50]
0x0001422727a9:  e8428654fe            call      0x1407badf0
0x0001422727ae:  488d158b44a905        lea       rdx, [rip + 0x5a9448b]
0x0001422727b5:  488d4c2450            lea       rcx, [rsp + 0x50]
0x0001422727ba:  e891088d03            call      0x145b43050
0x0001422727bf:  cc                    int3      
0x0001422727c0:  48895c2418            mov       qword ptr [rsp + 0x18], rbx
0x0001422727c5:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x0001422727ca:  48894c2408            mov       qword ptr [rsp + 8], rcx
0x0001422727cf:  57                    push      rdi
0x0001422727d0:  4883ec20              sub       rsp, 0x20
0x0001422727d4:  488bfa                mov       rdi, rdx
0x0001422727d7:  488bd9                mov       rbx, rcx
0x0001422727da:  0fb602                movzx     eax, byte ptr [rdx]
0x0001422727dd:  8801                  mov       byte ptr [rcx], al
0x0001422727df:  0fb64201              movzx     eax, byte ptr [rdx + 1]
0x0001422727e3:  884101                mov       byte ptr [rcx + 1], al
0x0001422727e6:  4883c108              add       rcx, 8
0x0001422727ea:  33f6                  xor       esi, esi
0x0001422727ec:  48897138              mov       qword ptr [rcx + 0x38], rsi
0x0001422727f0:  4883c208              add       rdx, 8
0x0001422727f4:  e8e78d57fe            call      0x1407eb5e0
0x0001422727f9:  90                    nop       
0x0001422727fa:  8b4748                mov       eax, dword ptr [rdi + 0x48]
0x0001422727fd:  894348                mov       dword ptr [rbx + 0x48], eax
0x000142272800:  488b4750              mov       rax, qword ptr [rdi + 0x50]
0x000142272804:  48894350              mov       qword ptr [rbx + 0x50], rax
0x000142272808:  488b4758              mov       rax, qword ptr [rdi + 0x58]
0x00014227280c:  48894358              mov       qword ptr [rbx + 0x58], rax
0x000142272810:  488b5770              mov       rdx, qword ptr [rdi + 0x70]
0x000142272814:  48897770              mov       qword ptr [rdi + 0x70], rsi
0x000142272818:  488b4f68              mov       rcx, qword ptr [rdi + 0x68]
0x00014227281c:  48897768              mov       qword ptr [rdi + 0x68], rsi
0x000142272820:  488b4760              mov       rax, qword ptr [rdi + 0x60]
0x000142272824:  48897760              mov       qword ptr [rdi + 0x60], rsi
0x000142272828:  48894360              mov       qword ptr [rbx + 0x60], rax
0x00014227282c:  48894b68              mov       qword ptr [rbx + 0x68], rcx
0x000142272830:  48895370              mov       qword ptr [rbx + 0x70], rdx
0x000142272834:  488d4b78              lea       rcx, [rbx + 0x78]
0x000142272838:  48894c2438            mov       qword ptr [rsp + 0x38], rcx
0x00014227283d:  488d5778              lea       rdx, [rdi + 0x78]
0x000142272841:  488d4118              lea       rax, [rcx + 0x18]
0x000142272845:  488901                mov       qword ptr [rcx], rax
0x000142272848:  48897108              mov       qword ptr [rcx + 8], rsi
0x00014227284c:  48c7411020000000      mov       qword ptr [rcx + 0x10], 0x20
0x000142272854:  48397208              cmp       qword ptr [rdx + 8], rsi
0x000142272858:  7406                  je        0x142272860
0x00014227285a:  e8319167fe            call      0x1408eb990
0x00014227285f:  90                    nop       
0x000142272860:  8b87b0000000          mov       eax, dword ptr [rdi + 0xb0]
0x000142272866:  8983b0000000          mov       dword ptr [rbx + 0xb0], eax
0x00014227286c:  0fb687b4000000        movzx     eax, byte ptr [rdi + 0xb4]
0x000142272873:  8883b4000000          mov       byte ptr [rbx + 0xb4], al
0x000142272879:  488bc3                mov       rax, rbx
0x00014227287c:  488b5c2440            mov       rbx, qword ptr [rsp + 0x40]
0x000142272881:  488b742448            mov       rsi, qword ptr [rsp + 0x48]
0x000142272886:  4883c420              add       rsp, 0x20
0x00014227288a:  5f                    pop       rdi
0x00014227288b:  c3                    ret       
0x00014227288c:  cc                    int3      
0x00014227288d:  cc                    int3      
0x00014227288e:  cc                    int3      
0x00014227288f:  cc                    int3      
0x000142272890:  4883ec38              sub       rsp, 0x38
0x000142272894:  488b1515b70306        mov       rdx, qword ptr [rip + 0x603b715]
0x00014227289b:  4c8d0506b70306        lea       r8, [rip + 0x603b706]
0x0001422728a2:  488b0def957306        mov       rcx, qword ptr [rip + 0x67395ef]
0x0001422728a9:  41b902000000          mov       r9d, 2
0x0001422728af:  e88c937002            call      0x14497bc40
0x0001422728b4:  4883c438              add       rsp, 0x38
0x0001422728b8:  c3                    ret       
0x0001422728b9:  cc                    int3      
0x0001422728ba:  cc                    int3      
0x0001422728bb:  cc                    int3      
0x0001422728bc:  cc                    int3      
0x0001422728bd:  cc                    int3      
0x0001422728be:  cc                    int3      
0x0001422728bf:  cc                    int3      
0x0001422728c0:  4883ec38              sub       rsp, 0x38
0x0001422728c4:  488b155dd5ae05        mov       rdx, qword ptr [rip + 0x5aed55d]
0x0001422728cb:  4c8d054ed5ae05        lea       r8, [rip + 0x5aed54e]
0x0001422728d2:  488b0dbf957306        mov       rcx, qword ptr [rip + 0x67395bf]
0x0001422728d9:  41b902000000          mov       r9d, 2
0x0001422728df:  e85c937002            call      0x14497bc40
0x0001422728e4:  4883c438              add       rsp, 0x38
0x0001422728e8:  c3                    ret       
0x0001422728e9:  cc                    int3      
0x0001422728ea:  cc                    int3      
0x0001422728eb:  cc                    int3      
0x0001422728ec:  cc                    int3      
0x0001422728ed:  cc                    int3      
0x0001422728ee:  cc                    int3      
0x0001422728ef:  cc                    int3      
0x0001422728f0:  4883ec38              sub       rsp, 0x38
0x0001422728f4:  488b1575b70306        mov       rdx, qword ptr [rip + 0x603b775]
0x0001422728fb:  4c8d0566b70306        lea       r8, [rip + 0x603b766]
0x000142272902:  488b0d8f957306        mov       rcx, qword ptr [rip + 0x673958f]
0x000142272909:  41b902000000          mov       r9d, 2
0x00014227290f:  e82c937002            call      0x14497bc40
0x000142272914:  4883c438              add       rsp, 0x38
0x000142272918:  c3                    ret       
0x000142272919:  cc                    int3      
0x00014227291a:  cc                    int3      
0x00014227291b:  cc                    int3      
0x00014227291c:  cc                    int3      
0x00014227291d:  cc                    int3      
0x00014227291e:  cc                    int3      
0x00014227291f:  cc                    int3      
0x000142272920:  4883ec38              sub       rsp, 0x38
0x000142272924:  488b157dd5ae05        mov       rdx, qword ptr [rip + 0x5aed57d]
0x00014227292b:  4c8d056ed5ae05        lea       r8, [rip + 0x5aed56e]
0x000142272932:  488b0d5f957306        mov       rcx, qword ptr [rip + 0x673955f]
0x000142272939:  41b902000000          mov       r9d, 2
0x00014227293f:  e8fc927002            call      0x14497bc40
0x000142272944:  4883c438              add       rsp, 0x38
0x000142272948:  c3                    ret       
0x000142272949:  cc                    int3      
0x00014227294a:  cc                    int3      
0x00014227294b:  cc                    int3      
0x00014227294c:  cc                    int3      
0x00014227294d:  cc                    int3      
0x00014227294e:  cc                    int3      
0x00014227294f:  cc                    int3      
0x000142272950:  4883ec38              sub       rsp, 0x38
0x000142272954:  488b15d5b70306        mov       rdx, qword ptr [rip + 0x603b7d5]
0x00014227295b:  4c8d05c6b70306        lea       r8, [rip + 0x603b7c6]
0x000142272962:  488b0d2f957306        mov       rcx, qword ptr [rip + 0x673952f]
0x000142272969:  41b902000000          mov       r9d, 2
0x00014227296f:  e8cc927002            call      0x14497bc40
0x000142272974:  4883c438              add       rsp, 0x38
0x000142272978:  c3                    ret       
0x000142272979:  cc                    int3      
0x00014227297a:  cc                    int3      
0x00014227297b:  cc                    int3      
0x00014227297c:  cc                    int3      
0x00014227297d:  cc                    int3      
0x00014227297e:  cc                    int3      
0x00014227297f:  cc                    int3      
0x000142272980:  4883ec38              sub       rsp, 0x38
0x000142272984:  488b1505b90306        mov       rdx, qword ptr [rip + 0x603b905]
0x00014227298b:  4c8d05f6b80306        lea       r8, [rip + 0x603b8f6]
0x000142272992:  488b0dff947306        mov       rcx, qword ptr [rip + 0x67394ff]
0x000142272999:  41b902000000          mov       r9d, 2
0x00014227299f:  e89c927002            call      0x14497bc40
0x0001422729a4:  4883c438              add       rsp, 0x38
0x0001422729a8:  c3                    ret       
0x0001422729a9:  cc                    int3      
0x0001422729aa:  cc                    int3      
0x0001422729ab:  cc                    int3      
0x0001422729ac:  cc                    int3      
0x0001422729ad:  cc                    int3      
0x0001422729ae:  cc                    int3      
0x0001422729af:  cc                    int3      
