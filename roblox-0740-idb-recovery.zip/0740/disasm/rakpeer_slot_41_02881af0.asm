; RakPeer vtable slot 41
; rva 0x2881af0
0x142881af0:  4055                 push      rbp
0x142881af2:  4883ec50             sub       rsp, 0x50
0x142881af6:  8b4228               mov       eax, dword ptr [rdx + 0x28]
0x142881af9:  498be8               mov       rbp, r8
0x142881afc:  0f104a10             movups    xmm1, xmmword ptr [rdx + 0x10]
0x142881b00:  4c8bc9               mov       r9, rcx
0x142881b03:  89442448             mov       dword ptr [rsp + 0x48], eax
0x142881b07:  f20f104220           movsd     xmm0, qword ptr [rdx + 0x20]
0x142881b0c:  0fb7422e             movzx     eax, word ptr [rdx + 0x2e]
0x142881b10:  48895c2460           mov       qword ptr [rsp + 0x60], rbx
0x142881b15:  488b1a               mov       rbx, qword ptr [rdx]
0x142881b18:  483b1d49dd5605       cmp       rbx, qword ptr [rip + 0x556dd49]
0x142881b1f:  668944244e           mov       word ptr [rsp + 0x4e], ax
0x142881b24:  0fb7422c             movzx     eax, word ptr [rdx + 0x2c]
0x142881b28:  668944244c           mov       word ptr [rsp + 0x4c], ax
0x142881b2d:  0f114c2430           movups    xmmword ptr [rsp + 0x30], xmm1
0x142881b32:  f20f11442440         movsd     qword ptr [rsp + 0x40], xmm0
0x142881b38:  744e                 je        0x142881b88
0x142881b3a:  440fb78112010000     movzx     r8d, word ptr [rcx + 0x112]
0x142881b42:  4533db               xor       r11d, r11d
0x142881b45:  418bd3               mov       edx, r11d
0x142881b48:  66453bd8             cmp       r11w, r8w
0x142881b4c:  7332                 jae       0x142881b80
0x142881b4e:  4c8b9150030000       mov       r10, qword ptr [rcx + 0x350]
0x142881b55:  6666660f1f840000000000 nop       word ptr [rax + rax]
0x142881b60:  8bc2                 mov       eax, edx
0x142881b62:  4869c0d8160000       imul      rax, rax, 0x16d8
0x142881b69:  4903c2               add       rax, r10
0x142881b6c:  48399830160000       cmp       qword ptr [rax + 0x1630], rbx
0x142881b73:  0f8458010000         je        0x142881cd1
0x142881b79:  ffc2                 inc       edx
0x142881b7b:  413bd0               cmp       edx, r8d
0x142881b7e:  72e0                 jb        0x142881b60
0x142881b80:  498bc3               mov       rax, r11
0x142881b83:  e949010000           jmp       0x142881cd1
0x142881b88:  0f10442440           movups    xmm0, xmmword ptr [rsp + 0x40]
0x142881b8d:  440fb7542430         movzx     r10d, word ptr [rsp + 0x30]
0x142881b93:  66480f7ec9           movq      rcx, xmm1
0x142881b98:  48897c2470           mov       qword ptr [rsp + 0x70], rdi
0x142881b9d:  488bc1               mov       rax, rcx
0x142881ba0:  0f290c24             movaps    xmmword ptr [rsp], xmm1
0x142881ba4:  488b7c2408           mov       rdi, qword ptr [rsp + 8]
0x142881ba9:  48c1e810             shr       rax, 0x10
0x142881bad:  663b0596dc5605       cmp       ax, word ptr [rip + 0x556dc96]
0x142881bb4:  0f29442410           movaps    xmmword ptr [rsp + 0x10], xmm0
0x142881bb9:  488b5c2410           mov       rbx, qword ptr [rsp + 0x10]
0x142881bbe:  751d                 jne       0x142881bdd
0x142881bc0:  66443b1580dc5605     cmp       r10w, word ptr [rip + 0x556dc80]
0x142881bc8:  7513                 jne       0x142881bdd
0x142881bca:  664183fa02           cmp       r10w, 2
0x142881bcf:  7569                 jne       0x142881c3a
0x142881bd1:  48c1e920             shr       rcx, 0x20
0x142881bd5:  3b0d71dc5605         cmp       ecx, dword ptr [rip + 0x556dc71]
0x142881bdb:  7476                 je        0x142881c53
0x142881bdd:  4533db               xor       r11d, r11d
0x142881be0:  4889742468           mov       qword ptr [rsp + 0x68], rsi
0x142881be5:  baffffffff           mov       edx, 0xffffffff
0x142881bea:  458bc3               mov       r8d, r11d
0x142881bed:  66453b9912010000     cmp       r11w, word ptr [r9 + 0x112]
0x142881bf5:  0f83c9000000         jae       0x142881cc4
0x142881bfb:  0f1f440000           nop       dword ptr [rax + rax]
0x142881c00:  498b8950030000       mov       rcx, qword ptr [r9 + 0x350]
0x142881c07:  4963c0               movsxd    rax, r8d
0x142881c0a:  4869f0d8160000       imul      rsi, rax, 0x16d8
0x142881c11:  0fb7442432           movzx     eax, word ptr [rsp + 0x32]
0x142881c16:  4803ce               add       rcx, rsi
0x142881c19:  66394106             cmp       word ptr [rcx + 6], ax
0x142881c1d:  756d                 jne       0x142881c8c
0x142881c1f:  0fb74104             movzx     eax, word ptr [rcx + 4]
0x142881c23:  66413bc2             cmp       ax, r10w
0x142881c27:  7563                 jne       0x142881c8c
0x142881c29:  6683f802             cmp       ax, 2
0x142881c2d:  752c                 jne       0x142881c5b
0x142881c2f:  8b442434             mov       eax, dword ptr [rsp + 0x34]
0x142881c33:  394108               cmp       dword ptr [rcx + 8], eax
0x142881c36:  7435                 je        0x142881c6d
0x142881c38:  eb52                 jmp       0x142881c8c
0x142881c3a:  664183fa17           cmp       r10w, 0x17
0x142881c3f:  759c                 jne       0x142881bdd
0x142881c41:  483b3d08dc5605       cmp       rdi, qword ptr [rip + 0x556dc08]
0x142881c48:  7593                 jne       0x142881bdd
0x142881c4a:  483b1d07dc5605       cmp       rbx, qword ptr [rip + 0x556dc07]
0x142881c51:  758a                 jne       0x142881bdd
0x142881c53:  4533db               xor       r11d, r11d
0x142881c56:  418bc3               mov       eax, r11d
0x142881c59:  eb71                 jmp       0x142881ccc
0x142881c5b:  6683f817             cmp       ax, 0x17
0x142881c5f:  752b                 jne       0x142881c8c
0x142881c61:  4839790c             cmp       qword ptr [rcx + 0xc], rdi
0x142881c65:  7525                 jne       0x142881c8c
0x142881c67:  48395914             cmp       qword ptr [rcx + 0x14], rbx
0x142881c6b:  751f                 jne       0x142881c8c
0x142881c6d:  0fb601               movzx     eax, byte ptr [rcx]
0x142881c70:  90                   nop       
0x142881c71:  84c0                 test      al, al
0x142881c73:  7543                 jne       0x142881cb8
0x142881c75:  440fb7542430         movzx     r10d, word ptr [rsp + 0x30]
0x142881c7b:  83faff               cmp       edx, -1
0x142881c7e:  488b5c2410           mov       rbx, qword ptr [rsp + 0x10]
0x142881c83:  488b7c2408           mov       rdi, qword ptr [rsp + 8]
0x142881c88:  410f44d0             cmove     edx, r8d
0x142881c8c:  410fb78112010000     movzx     eax, word ptr [r9 + 0x112]
0x142881c94:  41ffc0               inc       r8d
0x142881c97:  443bc0               cmp       r8d, eax
0x142881c9a:  0f8260ffffff         jb        0x142881c00
0x142881ca0:  83faff               cmp       edx, -1
0x142881ca3:  741f                 je        0x142881cc4
0x142881ca5:  4863c2               movsxd    rax, edx
0x142881ca8:  4869c0d8160000       imul      rax, rax, 0x16d8
0x142881caf:  49038150030000       add       rax, qword ptr [r9 + 0x350]
0x142881cb6:  eb0f                 jmp       0x142881cc7
0x142881cb8:  498b8150030000       mov       rax, qword ptr [r9 + 0x350]
0x142881cbf:  4803c6               add       rax, rsi
0x142881cc2:  eb03                 jmp       0x142881cc7
0x142881cc4:  498bc3               mov       rax, r11
0x142881cc7:  488b742468           mov       rsi, qword ptr [rsp + 0x68]
0x142881ccc:  488b7c2470           mov       rdi, qword ptr [rsp + 0x70]
0x142881cd1:  488b5c2460           mov       rbx, qword ptr [rsp + 0x60]
0x142881cd6:  4885c0               test      rax, rax
0x142881cd9:  740b                 je        0x142881ce6
0x142881cdb:  0f108058060000       movups    xmm0, xmmword ptr [rax + 0x658]
0x142881ce2:  0f114500             movups    xmmword ptr [rbp], xmm0
0x142881ce6:  4883c450             add       rsp, 0x50
0x142881cea:  5d                   pop       rbp
0x142881ceb:  c3                   ret       
0x142881cec:  cc                   int3      
0x142881ced:  cc                   int3      
0x142881cee:  cc                   int3      
0x142881cef:  cc                   int3      
