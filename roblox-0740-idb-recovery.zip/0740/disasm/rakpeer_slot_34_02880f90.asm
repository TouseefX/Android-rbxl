; RakPeer vtable slot 34
; rva 0x2880f90
0x142880f90:  4c8bca               mov       r9, rdx
0x142880f93:  4585c0               test      r8d, r8d
0x142880f96:  7852                 js        0x142880fea
0x142880f98:  0fb78112010000       movzx     eax, word ptr [rcx + 0x112]
0x142880f9f:  443bc0               cmp       r8d, eax
0x142880fa2:  7d46                 jge       0x142880fea
0x142880fa4:  4963c0               movsxd    rax, r8d
0x142880fa7:  4c69c0d8160000       imul      r8, rax, 0x16d8
0x142880fae:  488b8150030000       mov       rax, qword ptr [rcx + 0x350]
0x142880fb5:  410fb61400           movzx     edx, byte ptr [r8 + rax]
0x142880fba:  90                   nop       
0x142880fbb:  84d2                 test      dl, dl
0x142880fbd:  742b                 je        0x142880fea
0x142880fbf:  488b8150030000       mov       rax, qword ptr [rcx + 0x350]
0x142880fc6:  4183bc00d416000007   cmp       dword ptr [r8 + rax + 0x16d4], 7
0x142880fcf:  7519                 jne       0x142880fea
0x142880fd1:  410f10440004         movups    xmm0, xmmword ptr [r8 + rax + 4]
0x142880fd7:  410f104c0014         movups    xmm1, xmmword ptr [r8 + rax + 0x14]
0x142880fdd:  498bc1               mov       rax, r9
0x142880fe0:  410f1101             movups    xmmword ptr [r9], xmm0
0x142880fe4:  410f114910           movups    xmmword ptr [r9 + 0x10], xmm1
0x142880fe9:  c3                   ret       
0x142880fea:  0f100557e85605       movups    xmm0, xmmword ptr [rip + 0x556e857]
0x142880ff1:  498bc1               mov       rax, r9
0x142880ff4:  0f100d5de85605       movups    xmm1, xmmword ptr [rip + 0x556e85d]
0x142880ffb:  410f1101             movups    xmmword ptr [r9], xmm0
0x142880fff:  410f114910           movups    xmmword ptr [r9 + 0x10], xmm1
0x142881004:  c3                   ret       
0x142881005:  cc                   int3      
0x142881006:  cc                   int3      
0x142881007:  cc                   int3      
0x142881008:  cc                   int3      
0x142881009:  cc                   int3      
0x14288100a:  cc                   int3      
0x14288100b:  cc                   int3      
0x14288100c:  cc                   int3      
0x14288100d:  cc                   int3      
0x14288100e:  cc                   int3      
0x14288100f:  cc                   int3      
