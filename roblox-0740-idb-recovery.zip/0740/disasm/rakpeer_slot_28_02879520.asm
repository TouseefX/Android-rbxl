; RakPeer vtable slot 28
; rva 0x2879520
0x142879520:  85d2                 test      edx, edx
0x142879522:  7822                 js        0x142879546
0x142879524:  4863c2               movsxd    rax, edx
0x142879527:  483b8170030000       cmp       rax, qword ptr [rcx + 0x370]
0x14287952e:  7316                 jae       0x142879546
0x142879530:  4869d050100000       imul      rdx, rax, 0x1050
0x142879537:  488b8168030000       mov       rax, qword ptr [rcx + 0x368]
0x14287953e:  4489840240100000     mov       dword ptr [rdx + rax + 0x1040], r8d
0x142879546:  c3                   ret       
0x142879547:  cc                   int3      
0x142879548:  cc                   int3      
0x142879549:  cc                   int3      
0x14287954a:  cc                   int3      
0x14287954b:  cc                   int3      
0x14287954c:  cc                   int3      
0x14287954d:  cc                   int3      
0x14287954e:  cc                   int3      
0x14287954f:  cc                   int3      
