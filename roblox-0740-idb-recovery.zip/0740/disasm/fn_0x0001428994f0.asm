; function_of: vtab.lambda.baa9-Token-amp
; xref site 0x14289af34 -> vtab.lambda.baa9-Token-amp @ 0x146ca3390
; range 0x1428994f0 .. 0x14289b240  (7504 bytes)

0x0001428994f0:  4055                  push      rbp
0x0001428994f2:  53                    push      rbx
0x0001428994f3:  56                    push      rsi
0x0001428994f4:  57                    push      rdi
0x0001428994f5:  4154                  push      r12
0x0001428994f7:  4155                  push      r13
0x0001428994f9:  4156                  push      r14
0x0001428994fb:  4157                  push      r15
0x0001428994fd:  488dac2448ecffff      lea       rbp, [rsp - 0x13b8]
0x000142899505:  b8b8140000            mov       eax, 0x14b8
0x00014289950a:  e8a1862803            call      0x145b21bb0
0x00014289950f:  482be0                sub       rsp, rax
0x000142899512:  488b05d7a14705        mov       rax, qword ptr [rip + 0x547a1d7]
0x000142899519:  4833c4                xor       rax, rsp
0x00014289951c:  488985a0130000        mov       qword ptr [rbp + 0x13a0], rax
0x000142899523:  4c894df0              mov       qword ptr [rbp - 0x10], r9
0x000142899527:  498bd8                mov       rbx, r8
0x00014289952a:  4c8bfa                mov       r15, rdx
0x00014289952d:  48895500              mov       qword ptr [rbp], rdx
0x000142899531:  488bf9                mov       rdi, rcx
0x000142899534:  488b8520140000        mov       rax, qword ptr [rbp + 0x1420]
0x00014289953b:  48894560              mov       qword ptr [rbp + 0x60], rax
0x00014289953f:  488b8528140000        mov       rax, qword ptr [rbp + 0x1428]
0x000142899546:  488945e0              mov       qword ptr [rbp - 0x20], rax
0x00014289954a:  488b8538140000        mov       rax, qword ptr [rbp + 0x1438]
0x000142899551:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x000142899556:  488b8548140000        mov       rax, qword ptr [rbp + 0x1448]
0x00014289955d:  48894550              mov       qword ptr [rbp + 0x50], rax
0x000142899561:  4881c1400e0000        add       rcx, 0xe40
0x000142899568:  e843a22803            call      0x145b237b0
0x00014289956d:  85c0                  test      eax, eax
0x00014289956f:  0f85791c0000          jne       0x14289b1ee
0x000142899575:  ff87340e0000          inc       dword ptr [rdi + 0xe34]
0x00014289957b:  488d8f400e0000        lea       rcx, [rdi + 0xe40]
0x000142899582:  e889a22803            call      0x145b23810
0x000142899587:  4883fb6b              cmp       rbx, 0x6b
0x00014289958b:  0f82dc1b0000          jb        0x14289b16d
0x000142899591:  0fb78d30140000        movzx     ecx, word ptr [rbp + 0x1430]
0x000142899598:  4883c128              add       rcx, 0x28
0x00014289959c:  4803cb                add       rcx, rbx
0x00014289959f:  b840020000            mov       eax, 0x240
0x0001428995a4:  483bc8                cmp       rcx, rax
0x0001428995a7:  0f82c01b0000          jb        0x14289b16d
0x0001428995ad:  4533ed                xor       r13d, r13d
0x0001428995b0:  6644896d84            mov       word ptr [rbp - 0x7c], r13w
0x0001428995b5:  0f57c0                xorps     xmm0, xmm0
0x0001428995b8:  f30f7f85c0000000      movdqu    xmmword ptr [rbp + 0xc0], xmm0
0x0001428995c0:  488d0501a74004        lea       rax, [rip + 0x440a701]
0x0001428995c7:  48898530030000        mov       qword ptr [rbp + 0x330], rax
0x0001428995ce:  4488ad38030000        mov       byte ptr [rbp + 0x338], r13b
0x0001428995d5:  8d0cdd00000000        lea       ecx, [rbx*8]
0x0001428995dc:  898d40030000          mov       dword ptr [rbp + 0x340], ecx
0x0001428995e2:  4488ad58030000        mov       byte ptr [rbp + 0x358], r13b
0x0001428995e9:  898d44030000          mov       dword ptr [rbp + 0x344], ecx
0x0001428995ef:  4c89bd50030000        mov       qword ptr [rbp + 0x350], r15
0x0001428995f6:  ba88000000            mov       edx, 0x88
0x0001428995fb:  899548030000          mov       dword ptr [rbp + 0x348], edx
0x000142899601:  83f908                cmp       ecx, 8
0x000142899604:  721a                  jb        0x142899620
0x000142899606:  8d41f8                lea       eax, [rcx - 8]
0x000142899609:  41b890000000          mov       r8d, 0x90
0x00014289960f:  3bc2                  cmp       eax, edx
0x000142899611:  410f43d0              cmovae    edx, r8d
0x000142899615:  899548030000          mov       dword ptr [rbp + 0x348], edx
0x00014289961b:  0f1f440000            nop       dword ptr [rax + rax]
0x000142899620:  41b908000000          mov       r9d, 8
0x000142899626:  413bc9                cmp       ecx, r9d
0x000142899629:  0f82b3000000          jb        0x1428996e2
0x00014289962f:  8d41f8                lea       eax, [rcx - 8]
0x000142899632:  3bd0                  cmp       edx, eax
0x000142899634:  0f87a8000000          ja        0x1428996e2
0x00014289963a:  448bf2                mov       r14d, edx
0x00014289963d:  4183e607              and       r14d, 7
0x000142899641:  751d                  jne       0x142899660
0x000142899643:  8bc2                  mov       eax, edx
0x000142899645:  48c1e803              shr       rax, 3
0x000142899649:  420fb60438            movzx     eax, byte ptr [rax + r15]
0x00014289964e:  88442470              mov       byte ptr [rsp + 0x70], al
0x000142899652:  4103d1                add       edx, r9d
0x000142899655:  899548030000          mov       dword ptr [rbp + 0x348], edx
0x00014289965b:  e982000000            jmp       0x1428996e2
0x000142899660:  418bdd                mov       ebx, r13d
0x000142899663:  33c0                  xor       eax, eax
0x000142899665:  88442470              mov       byte ptr [rsp + 0x70], al
0x000142899669:  418bf1                mov       esi, r9d
0x00014289966c:  412bf6                sub       esi, r14d
0x00014289966f:  90                    nop       
0x000142899670:  8bc2                  mov       eax, edx
0x000142899672:  48c1e803              shr       rax, 3
0x000142899676:  448bdb                mov       r11d, ebx
0x000142899679:  418bce                mov       ecx, r14d
0x00014289967c:  460fb60438            movzx     r8d, byte ptr [rax + r15]
0x000142899681:  41d2e0                shl       r8b, cl
0x000142899684:  460a441c70            or        r8b, byte ptr [rsp + r11 + 0x70]
0x000142899689:  4688441c70            mov       byte ptr [rsp + r11 + 0x70], r8b
0x00014289968e:  443bce                cmp       r9d, esi
0x000142899691:  7618                  jbe       0x1428996ab
0x000142899693:  420fb6443801          movzx     eax, byte ptr [rax + r15 + 1]
0x000142899699:  400fb6ce              movzx     ecx, sil
0x00014289969d:  d2e8                  shr       al, cl
0x00014289969f:  410ac0                or        al, r8b
0x0001428996a2:  440fb6c0              movzx     r8d, al
0x0001428996a6:  4288441c70            mov       byte ptr [rsp + r11 + 0x70], al
0x0001428996ab:  458d51f8              lea       r10d, [r9 - 8]
0x0001428996af:  83c208                add       edx, 8
0x0001428996b2:  4183f908              cmp       r9d, 8
0x0001428996b6:  7205                  jb        0x1428996bd
0x0001428996b8:  458bca                mov       r9d, r10d
0x0001428996bb:  eb18                  jmp       0x1428996d5
0x0001428996bd:  4585d2                test      r10d, r10d
0x0001428996c0:  7910                  jns       0x1428996d2
0x0001428996c2:  418bca                mov       ecx, r10d
0x0001428996c5:  f7d9                  neg       ecx
0x0001428996c7:  41d2e8                shr       r8b, cl
0x0001428996ca:  4688441c70            mov       byte ptr [rsp + r11 + 0x70], r8b
0x0001428996cf:  4103d2                add       edx, r10d
0x0001428996d2:  458bcd                mov       r9d, r13d
0x0001428996d5:  899548030000          mov       dword ptr [rbp + 0x348], edx
0x0001428996db:  ffc3                  inc       ebx
0x0001428996dd:  4585c9                test      r9d, r9d
0x0001428996e0:  758e                  jne       0x142899670
0x0001428996e2:  488d55c0              lea       rdx, [rbp - 0x40]
0x0001428996e6:  488d8d30030000        lea       rcx, [rbp + 0x330]
0x0001428996ed:  e8be7c0000            call      0x1428a13b0
0x0001428996f2:  488d5584              lea       rdx, [rbp - 0x7c]
0x0001428996f6:  488d8d30030000        lea       rcx, [rbp + 0x330]
0x0001428996fd:  e8ae7c0000            call      0x1428a13b0
0x000142899702:  8b8d48030000          mov       ecx, dword ptr [rbp + 0x348]
0x000142899708:  8d41ff                lea       eax, [rcx - 1]
0x00014289970b:  83e007                and       eax, 7
0x00014289970e:  2bc8                  sub       ecx, eax
0x000142899710:  8d5107                lea       edx, [rcx + 7]
0x000142899713:  899548030000          mov       dword ptr [rbp + 0x348], edx
0x000142899719:  488bb550030000        mov       rsi, qword ptr [rbp + 0x350]
0x000142899720:  448b8540030000        mov       r8d, dword ptr [rbp + 0x340]
0x000142899727:  4181f800010000        cmp       r8d, 0x100
0x00014289972e:  7234                  jb        0x142899764
0x000142899730:  418d8000ffffff        lea       eax, [r8 - 0x100]
0x000142899737:  3bd0                  cmp       edx, eax
0x000142899739:  7729                  ja        0x142899764
0x00014289973b:  8bc2                  mov       eax, edx
0x00014289973d:  48c1e803              shr       rax, 3
0x000142899741:  0f100430              movups    xmm0, xmmword ptr [rax + rsi]
0x000142899745:  0f1185f0020000        movups    xmmword ptr [rbp + 0x2f0], xmm0
0x00014289974c:  0f104c3010            movups    xmm1, xmmword ptr [rax + rsi + 0x10]
0x000142899751:  0f118d00030000        movups    xmmword ptr [rbp + 0x300], xmm1
0x000142899758:  81c200010000          add       edx, 0x100
0x00014289975e:  899548030000          mov       dword ptr [rbp + 0x348], edx
0x000142899764:  803dbdc7a20500        cmp       byte ptr [rip + 0x5a2c7bd], 0
0x00014289976b:  0f8477010000          je        0x1428998e8
0x000142899771:  803d80c8a20500        cmp       byte ptr [rip + 0x5a2c880], 0
0x000142899778:  0f846a010000          je        0x1428998e8
0x00014289977e:  32c9                  xor       cl, cl
0x000142899780:  884c2471              mov       byte ptr [rsp + 0x71], cl
0x000142899784:  41b908000000          mov       r9d, 8
0x00014289978a:  453bc1                cmp       r8d, r9d
0x00014289978d:  0f82b3000000          jb        0x142899846
0x000142899793:  418d40f8              lea       eax, [r8 - 8]
0x000142899797:  3bd0                  cmp       edx, eax
0x000142899799:  0f87a7000000          ja        0x142899846
0x00014289979f:  448bfa                mov       r15d, edx
0x0001428997a2:  4183e707              and       r15d, 7
0x0001428997a6:  751c                  jne       0x1428997c4
0x0001428997a8:  8bc2                  mov       eax, edx
0x0001428997aa:  48c1e803              shr       rax, 3
0x0001428997ae:  0fb60c30              movzx     ecx, byte ptr [rax + rsi]
0x0001428997b2:  884c2471              mov       byte ptr [rsp + 0x71], cl
0x0001428997b6:  4103d1                add       edx, r9d
0x0001428997b9:  899548030000          mov       dword ptr [rbp + 0x348], edx
0x0001428997bf:  e982000000            jmp       0x142899846
0x0001428997c4:  418bdd                mov       ebx, r13d
0x0001428997c7:  458bf1                mov       r14d, r9d
0x0001428997ca:  452bf7                sub       r14d, r15d
0x0001428997cd:  0f1f00                nop       dword ptr [rax]
0x0001428997d0:  8bc2                  mov       eax, edx
0x0001428997d2:  48c1e803              shr       rax, 3
0x0001428997d6:  448bdb                mov       r11d, ebx
0x0001428997d9:  418bcf                mov       ecx, r15d
0x0001428997dc:  440fb60430            movzx     r8d, byte ptr [rax + rsi]
0x0001428997e1:  41d2e0                shl       r8b, cl
0x0001428997e4:  460a441c71            or        r8b, byte ptr [rsp + r11 + 0x71]
0x0001428997e9:  4688441c71            mov       byte ptr [rsp + r11 + 0x71], r8b
0x0001428997ee:  453bce                cmp       r9d, r14d
0x0001428997f1:  7617                  jbe       0x14289980a
0x0001428997f3:  0fb6443001            movzx     eax, byte ptr [rax + rsi + 1]
0x0001428997f8:  410fb6ce              movzx     ecx, r14b
0x0001428997fc:  d2e8                  shr       al, cl
0x0001428997fe:  410ac0                or        al, r8b
0x000142899801:  440fb6c0              movzx     r8d, al
0x000142899805:  4288441c71            mov       byte ptr [rsp + r11 + 0x71], al
0x00014289980a:  458d51f8              lea       r10d, [r9 - 8]
0x00014289980e:  83c208                add       edx, 8
0x000142899811:  4183f908              cmp       r9d, 8
0x000142899815:  7205                  jb        0x14289981c
0x000142899817:  458bca                mov       r9d, r10d
0x00014289981a:  eb18                  jmp       0x142899834
0x00014289981c:  4585d2                test      r10d, r10d
0x00014289981f:  7910                  jns       0x142899831
0x000142899821:  418bca                mov       ecx, r10d
0x000142899824:  f7d9                  neg       ecx
0x000142899826:  41d2e8                shr       r8b, cl
0x000142899829:  4688441c71            mov       byte ptr [rsp + r11 + 0x71], r8b
0x00014289982e:  4103d2                add       edx, r10d
0x000142899831:  458bcd                mov       r9d, r13d
0x000142899834:  899548030000          mov       dword ptr [rbp + 0x348], edx
0x00014289983a:  ffc3                  inc       ebx
0x00014289983c:  4585c9                test      r9d, r9d
0x00014289983f:  758f                  jne       0x1428997d0
0x000142899841:  0fb64c2471            movzx     ecx, byte ptr [rsp + 0x71]
0x000142899846:  0fb6d1                movzx     edx, cl
0x000142899849:  488b05d83b4e05        mov       rax, qword ptr [rip + 0x54e3bd8]
0x000142899850:  483bd0                cmp       rdx, rax
0x000142899853:  7724                  ja        0x142899879
0x000142899855:  488d05bc3b4e05        lea       rax, [rip + 0x54e3bbc]
0x00014289985c:  48833dcc3b4e0510      cmp       qword ptr [rip + 0x54e3bcc], 0x10
0x000142899864:  480f4305ac3b4e05      cmovae    rax, qword ptr [rip + 0x54e3bac]
0x00014289986c:  488915b53b4e05        mov       qword ptr [rip + 0x54e3bb5], rdx
0x000142899873:  c6041000              mov       byte ptr [rax + rdx], 0
0x000142899877:  eb12                  jmp       0x14289988b
0x000142899879:  482bd0                sub       rdx, rax
0x00014289987c:  4533c0                xor       r8d, r8d
0x00014289987f:  488d0d923b4e05        lea       rcx, [rip + 0x54e3b92]
0x000142899886:  e8e5cbf4fd            call      0x1407e6470
0x00014289988b:  488d15863b4e05        lea       rdx, [rip + 0x54e3b86]
0x000142899892:  48833d963b4e0510      cmp       qword ptr [rip + 0x54e3b96], 0x10
0x00014289989a:  480f4315763b4e05      cmovae    rdx, qword ptr [rip + 0x54e3b76]
0x0001428998a2:  448b057f3b4e05        mov       r8d, dword ptr [rip + 0x54e3b7f]
0x0001428998a9:  488d8d30030000        lea       rcx, [rbp + 0x330]
0x0001428998b0:  e82bc50000            call      0x1428a5de0
0x0001428998b5:  488b07                mov       rax, qword ptr [rdi]
0x0001428998b8:  488d15593b4e05        lea       rdx, [rip + 0x54e3b59]
0x0001428998bf:  488bcf                mov       rcx, rdi
0x0001428998c2:  488b8060030000        mov       rax, qword ptr [rax + 0x360]
0x0001428998c9:  ff1569648a03          call      qword ptr [rip + 0x38a6469]
0x0001428998cf:  488b05aa9d9105        mov       rax, qword ptr [rip + 0x5919daa]
0x0001428998d6:  4885c0                test      rax, rax
0x0001428998d9:  740d                  je        0x1428998e8
0x0001428998db:  488d0d363b4e05        lea       rcx, [rip + 0x54e3b36]
0x0001428998e2:  ff1550648a03          call      qword ptr [rip + 0x38a6450]
0x0001428998e8:  b948000000            mov       ecx, 0x48
0x0001428998ed:  e80e9f0a02            call      0x144943800
0x0001428998f2:  488bd8                mov       rbx, rax
0x0001428998f5:  4885c0                test      rax, rax
0x0001428998f8:  0f84d6180000          je        0x14289b1d4
0x0001428998fe:  4c8928                mov       qword ptr [rax], r13
0x000142899901:  4c896810              mov       qword ptr [rax + 0x10], r13
0x000142899905:  48c740180f000000      mov       qword ptr [rax + 0x18], 0xf
0x00014289990d:  4c8d6020              lea       r12, [rax + 0x20]
0x000142899911:  4d892c24              mov       qword ptr [r12], r13
0x000142899915:  4d896c2410            mov       qword ptr [r12 + 0x10], r13
0x00014289991a:  49c74424180f000000    mov       qword ptr [r12 + 0x18], 0xf
0x000142899923:  488945d0              mov       qword ptr [rbp - 0x30], rax
0x000142899927:  b918000000            mov       ecx, 0x18
0x00014289992c:  e8cf9e0a02            call      0x144943800
0x000142899931:  48894568              mov       qword ptr [rbp + 0x68], rax
0x000142899935:  4885c0                test      rax, rax
0x000142899938:  0f84dc180000          je        0x14289b21a
0x00014289993e:  41be01000000          mov       r14d, 1
0x000142899944:  44897008              mov       dword ptr [rax + 8], r14d
0x000142899948:  4489700c              mov       dword ptr [rax + 0xc], r14d
0x00014289994c:  488d0d759a4004        lea       rcx, [rip + 0x4409a75]
0x000142899953:  488908                mov       qword ptr [rax], rcx
0x000142899956:  48895810              mov       qword ptr [rax + 0x10], rbx
0x00014289995a:  4c896dd0              mov       qword ptr [rbp - 0x30], r13
0x00014289995e:  48899dc0000000        mov       qword ptr [rbp + 0xc0], rbx
0x000142899965:  488985c8000000        mov       qword ptr [rbp + 0xc8], rax
0x00014289996c:  41b908000000          mov       r9d, 8
0x000142899972:  8b8540030000          mov       eax, dword ptr [rbp + 0x340]
0x000142899978:  413bc1                cmp       eax, r9d
0x00014289997b:  0f82f6000000          jb        0x142899a77
0x000142899981:  83c0f8                add       eax, -8
0x000142899984:  8b8d48030000          mov       ecx, dword ptr [rbp + 0x348]
0x00014289998a:  3bc8                  cmp       ecx, eax
0x00014289998c:  0f87e5000000          ja        0x142899a77
0x000142899992:  448bf1                mov       r14d, ecx
0x000142899995:  4183e607              and       r14d, 7
0x000142899999:  751e                  jne       0x1428999b9
0x00014289999b:  48c1e903              shr       rcx, 3
0x00014289999f:  488b8550030000        mov       rax, qword ptr [rbp + 0x350]
0x0001428999a6:  0fb60c01              movzx     ecx, byte ptr [rcx + rax]
0x0001428999aa:  884b40                mov       byte ptr [rbx + 0x40], cl
0x0001428999ad:  44018d48030000        add       dword ptr [rbp + 0x348], r9d
0x0001428999b4:  e9b8000000            jmp       0x142899a71
0x0001428999b9:  458bdd                mov       r11d, r13d
0x0001428999bc:  33c0                  xor       eax, eax
0x0001428999be:  884340                mov       byte ptr [rbx + 0x40], al
0x0001428999c1:  418bf1                mov       esi, r9d
0x0001428999c4:  412bf6                sub       esi, r14d
0x0001428999c7:  8b8548030000          mov       eax, dword ptr [rbp + 0x348]
0x0001428999cd:  0f1f00                nop       dword ptr [rax]
0x0001428999d0:  458bd3                mov       r10d, r11d
0x0001428999d3:  8bd0                  mov       edx, eax
0x0001428999d5:  48c1ea03              shr       rdx, 3
0x0001428999d9:  418bce                mov       ecx, r14d
0x0001428999dc:  488b8550030000        mov       rax, qword ptr [rbp + 0x350]
0x0001428999e3:  440fb60402            movzx     r8d, byte ptr [rdx + rax]
0x0001428999e8:  41d2e0                shl       r8b, cl
0x0001428999eb:  450a441a40            or        r8b, byte ptr [r10 + rbx + 0x40]
0x0001428999f0:  4588441a40            mov       byte ptr [r10 + rbx + 0x40], r8b
0x0001428999f5:  443bce                cmp       r9d, esi
0x0001428999f8:  7628                  jbe       0x142899a22
0x0001428999fa:  8b8d48030000          mov       ecx, dword ptr [rbp + 0x348]
0x000142899a00:  48c1e903              shr       rcx, 3
0x000142899a04:  488b8550030000        mov       rax, qword ptr [rbp + 0x350]
0x000142899a0b:  0fb6540101            movzx     edx, byte ptr [rcx + rax + 1]
0x000142899a10:  400fb6ce              movzx     ecx, sil
0x000142899a14:  d2ea                  shr       dl, cl
0x000142899a16:  410ad0                or        dl, r8b
0x000142899a19:  440fb6c2              movzx     r8d, dl
0x000142899a1d:  4188541a40            mov       byte ptr [r10 + rbx + 0x40], dl
0x000142899a22:  418d51f8              lea       edx, [r9 - 8]
0x000142899a26:  4183f908              cmp       r9d, 8
0x000142899a2a:  721b                  jb        0x142899a47
0x000142899a2c:  448bca                mov       r9d, edx
0x000142899a2f:  8b8548030000          mov       eax, dword ptr [rbp + 0x348]
0x000142899a35:  83c008                add       eax, 8
0x000142899a38:  898548030000          mov       dword ptr [rbp + 0x348], eax
0x000142899a3e:  41ffc3                inc       r11d
0x000142899a41:  85d2                  test      edx, edx
0x000142899a43:  758b                  jne       0x1428999d0
0x000142899a45:  eb2a                  jmp       0x142899a71
0x000142899a47:  85d2                  test      edx, edx
0x000142899a49:  791f                  jns       0x142899a6a
0x000142899a4b:  8bca                  mov       ecx, edx
0x000142899a4d:  f7d9                  neg       ecx
0x000142899a4f:  41d2e8                shr       r8b, cl
0x000142899a52:  4588441a40            mov       byte ptr [r10 + rbx + 0x40], r8b
0x000142899a57:  8b8d48030000          mov       ecx, dword ptr [rbp + 0x348]
0x000142899a5d:  83c108                add       ecx, 8
0x000142899a60:  03ca                  add       ecx, edx
0x000142899a62:  898d48030000          mov       dword ptr [rbp + 0x348], ecx
0x000142899a68:  eb07                  jmp       0x142899a71
0x000142899a6a:  83854803000008        add       dword ptr [rbp + 0x348], 8
0x000142899a71:  41be01000000          mov       r14d, 1
0x000142899a77:  41b808000000          mov       r8d, 8
0x000142899a7d:  488d542476            lea       rdx, [rsp + 0x76]
0x000142899a82:  488d8d30030000        lea       rcx, [rbp + 0x330]
0x000142899a89:  e8f2c40000            call      0x1428a5f80
0x000142899a8e:  0fb6742476            movzx     esi, byte ptr [rsp + 0x76]
0x000142899a93:  8bd6                  mov       edx, esi
0x000142899a95:  488b4310              mov       rax, qword ptr [rbx + 0x10]
0x000142899a99:  483bf0                cmp       rsi, rax
0x000142899a9c:  7717                  ja        0x142899ab5
0x000142899a9e:  488bc3                mov       rax, rbx
0x000142899aa1:  48837b1810            cmp       qword ptr [rbx + 0x18], 0x10
0x000142899aa6:  7203                  jb        0x142899aab
0x000142899aa8:  488b03                mov       rax, qword ptr [rbx]
0x000142899aab:  48895310              mov       qword ptr [rbx + 0x10], rdx
0x000142899aaf:  c6043000              mov       byte ptr [rax + rsi], 0
0x000142899ab3:  eb0e                  jmp       0x142899ac3
0x000142899ab5:  482bd0                sub       rdx, rax
0x000142899ab8:  4533c0                xor       r8d, r8d
0x000142899abb:  488bcb                mov       rcx, rbx
0x000142899abe:  e8adc9f4fd            call      0x1407e6470
0x000142899ac3:  448bc6                mov       r8d, esi
0x000142899ac6:  488bd3                mov       rdx, rbx
0x000142899ac9:  48837b1810            cmp       qword ptr [rbx + 0x18], 0x10
0x000142899ace:  7203                  jb        0x142899ad3
0x000142899ad0:  488b13                mov       rdx, qword ptr [rbx]
0x000142899ad3:  488d8d30030000        lea       rcx, [rbp + 0x330]
0x000142899ada:  e801c30000            call      0x1428a5de0
0x000142899adf:  488b4b10              mov       rcx, qword ptr [rbx + 0x10]
0x000142899ae3:  488bc3                mov       rax, rbx
0x000142899ae6:  48837b1810            cmp       qword ptr [rbx + 0x18], 0x10
0x000142899aeb:  7203                  jb        0x142899af0
0x000142899aed:  488b03                mov       rax, qword ptr [rbx]
0x000142899af0:  48894540              mov       qword ptr [rbp + 0x40], rax
0x000142899af4:  48894d48              mov       qword ptr [rbp + 0x48], rcx
0x000142899af8:  0f284540              movaps    xmm0, xmmword ptr [rbp + 0x40]
0x000142899afc:  660f7f4590            movdqa    xmmword ptr [rbp - 0x70], xmm0
0x000142899b01:  488d5590              lea       rdx, [rbp - 0x70]
0x000142899b05:  488bcf                mov       rcx, rdi
0x000142899b08:  e8a3470000            call      0x14289e2b0
0x000142899b0d:  8bf0                  mov       esi, eax
0x000142899b0f:  85c0                  test      eax, eax
0x000142899b11:  0f85c0000000          jne       0x142899bd7
0x000142899b17:  48c785480200000f000000  mov       qword ptr [rbp + 0x248], 0xf
0x000142899b22:  48c785400200000c000000  mov       qword ptr [rbp + 0x240], 0xc
0x000142899b2d:  f20f10053b1b6a04      movsd     xmm0, qword ptr [rip + 0x46a1b3b]
0x000142899b35:  f20f118530020000      movsd     qword ptr [rbp + 0x230], xmm0
0x000142899b3d:  8b0d351b6a04          mov       ecx, dword ptr [rip + 0x46a1b35]
0x000142899b43:  898d38020000          mov       dword ptr [rbp + 0x238], ecx
0x000142899b49:  88853c020000          mov       byte ptr [rbp + 0x23c], al
0x000142899b4f:  4533c0                xor       r8d, r8d
0x000142899b52:  418bd6                mov       edx, r14d
0x000142899b55:  488d8d30020000        lea       rcx, [rbp + 0x230]
0x000142899b5c:  e8efc93200            call      0x142bc6550
0x000142899b61:  90                    nop       
0x000142899b62:  488b8548020000        mov       rax, qword ptr [rbp + 0x248]
0x000142899b69:  4883f810              cmp       rax, 0x10
0x000142899b6d:  7230                  jb        0x142899b9f
0x000142899b6f:  48ffc0                inc       rax
0x000142899b72:  488b8d30020000        mov       rcx, qword ptr [rbp + 0x230]
0x000142899b79:  488bd1                mov       rdx, rcx
0x000142899b7c:  483d00100000          cmp       rax, 0x1000
0x000142899b82:  7215                  jb        0x142899b99
0x000142899b84:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000142899b88:  482bd1                sub       rdx, rcx
0x000142899b8b:  488d42f8              lea       rax, [rdx - 8]
0x000142899b8f:  4883f81f              cmp       rax, 0x1f
0x000142899b93:  0f875d160000          ja        0x14289b1f6
0x000142899b99:  e812950a02            call      0x1449430b0
0x000142899b9e:  90                    nop       
0x000142899b9f:  4c89ad40020000        mov       qword ptr [rbp + 0x240], r13
0x000142899ba6:  48c785480200000f000000  mov       qword ptr [rbp + 0x248], 0xf
0x000142899bb1:  c6853002000000        mov       byte ptr [rbp + 0x230], 0
0x000142899bb8:  803d69c3a20500        cmp       byte ptr [rip + 0x5a2c369], 0
0x000142899bbf:  0f84b0010000          je        0x142899d75
0x000142899bc5:  803d2cc4a20500        cmp       byte ptr [rip + 0x5a2c42c], 0
0x000142899bcc:  0f844a010000          je        0x142899d1c
0x000142899bd2:  e99e010000            jmp       0x142899d75
0x000142899bd7:  83fe01                cmp       esi, 1
0x000142899bda:  0f8592000000          jne       0x142899c72
0x000142899be0:  48c785480200000f000000  mov       qword ptr [rbp + 0x248], 0xf
0x000142899beb:  48c785400200000c000000  mov       qword ptr [rbp + 0x240], 0xc
0x000142899bf6:  f20f1005421b6a04      movsd     xmm0, qword ptr [rip + 0x46a1b42]
0x000142899bfe:  f20f118530020000      movsd     qword ptr [rbp + 0x230], xmm0
0x000142899c06:  8b053c1b6a04          mov       eax, dword ptr [rip + 0x46a1b3c]
0x000142899c0c:  898538020000          mov       dword ptr [rbp + 0x238], eax
0x000142899c12:  c6853c02000000        mov       byte ptr [rbp + 0x23c], 0
0x000142899c19:  4533c0                xor       r8d, r8d
0x000142899c1c:  418bd6                mov       edx, r14d
0x000142899c1f:  488d8d30020000        lea       rcx, [rbp + 0x230]
0x000142899c26:  e825c93200            call      0x142bc6550
0x000142899c2b:  90                    nop       
0x000142899c2c:  488b8548020000        mov       rax, qword ptr [rbp + 0x248]
0x000142899c33:  4883f810              cmp       rax, 0x10
0x000142899c37:  0f82c6000000          jb        0x142899d03
0x000142899c3d:  48ffc0                inc       rax
0x000142899c40:  488b8d30020000        mov       rcx, qword ptr [rbp + 0x230]
0x000142899c47:  488bd1                mov       rdx, rcx
0x000142899c4a:  483d00100000          cmp       rax, 0x1000
0x000142899c50:  7215                  jb        0x142899c67
0x000142899c52:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000142899c56:  482bd1                sub       rdx, rcx
0x000142899c59:  488d42f8              lea       rax, [rdx - 8]
0x000142899c5d:  4883f81f              cmp       rax, 0x1f
0x000142899c61:  0f8795150000          ja        0x14289b1fc
0x000142899c67:  e844940a02            call      0x1449430b0
0x000142899c6c:  90                    nop       
0x000142899c6d:  e991000000            jmp       0x142899d03
0x000142899c72:  83fe02                cmp       esi, 2
0x000142899c75:  0f85a1000000          jne       0x142899d1c
0x000142899c7b:  4c89ad30020000        mov       qword ptr [rbp + 0x230], r13
0x000142899c82:  4c89ad40020000        mov       qword ptr [rbp + 0x240], r13
0x000142899c89:  48c785480200000f000000  mov       qword ptr [rbp + 0x248], 0xf
0x000142899c94:  c6853002000000        mov       byte ptr [rbp + 0x230], 0
0x000142899c9b:  448d460e              lea       r8d, [rsi + 0xe]
0x000142899c9f:  488d15aa1a6a04        lea       rdx, [rip + 0x46a1aaa]
0x000142899ca6:  488d8d30020000        lea       rcx, [rbp + 0x230]
0x000142899cad:  e89e9df4fd            call      0x1407e3a50
0x000142899cb2:  90                    nop       
0x000142899cb3:  4533c0                xor       r8d, r8d
0x000142899cb6:  418bd6                mov       edx, r14d
0x000142899cb9:  488d8d30020000        lea       rcx, [rbp + 0x230]
0x000142899cc0:  e88bc83200            call      0x142bc6550
0x000142899cc5:  90                    nop       
0x000142899cc6:  488b8548020000        mov       rax, qword ptr [rbp + 0x248]
0x000142899ccd:  4883f810              cmp       rax, 0x10
0x000142899cd1:  7230                  jb        0x142899d03
0x000142899cd3:  48ffc0                inc       rax
0x000142899cd6:  488b8d30020000        mov       rcx, qword ptr [rbp + 0x230]
0x000142899cdd:  488bd1                mov       rdx, rcx
0x000142899ce0:  483d00100000          cmp       rax, 0x1000
0x000142899ce6:  7215                  jb        0x142899cfd
0x000142899ce8:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000142899cec:  482bd1                sub       rdx, rcx
0x000142899cef:  488d42f8              lea       rax, [rdx - 8]
0x000142899cf3:  4883f81f              cmp       rax, 0x1f
0x000142899cf7:  0f8705150000          ja        0x14289b202
0x000142899cfd:  e8ae930a02            call      0x1449430b0
0x000142899d02:  90                    nop       
0x000142899d03:  c6853002000000        mov       byte ptr [rbp + 0x230], 0
0x000142899d0a:  48c785480200000f000000  mov       qword ptr [rbp + 0x248], 0xf
0x000142899d15:  4c89ad40020000        mov       qword ptr [rbp + 0x240], r13
0x000142899d1c:  440fb66c2470          movzx     r13d, byte ptr [rsp + 0x70]
0x000142899d22:  8b8548030000          mov       eax, dword ptr [rbp + 0x348]
0x000142899d28:  c1e803                shr       eax, 3
0x000142899d2b:  443be8                cmp       r13d, eax
0x000142899d2e:  0f8492000000          je        0x142899dc6
0x000142899d34:  488b05d50d4d05        mov       rax, qword ptr [rip + 0x54d0dd5]
0x000142899d3b:  3c06                  cmp       al, 6
0x000142899d3d:  7236                  jb        0x142899d75
0x000142899d3f:  48c1e808              shr       rax, 8
0x000142899d43:  3c03                  cmp       al, 3
0x000142899d45:  722e                  jb        0x142899d75
0x000142899d47:  488d05ff28c606        lea       rax, [rip + 0x6c628ff]
0x000142899d4e:  488945d0              mov       qword ptr [rbp - 0x30], rax
0x000142899d52:  488b55d0              mov       rdx, qword ptr [rbp - 0x30]
0x000142899d56:  488d15a3196a04        lea       rdx, [rip + 0x46a19a3]
0x000142899d5d:  0f1005ac0d4d05        movups    xmm0, xmmword ptr [rip + 0x54d0dac]
0x000142899d64:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x000142899d68:  458bc5                mov       r8d, r13d
0x000142899d6b:  488d4d90              lea       rcx, [rbp - 0x70]
0x000142899d6f:  e81c5b0c02            call      0x14495f890
0x000142899d74:  90                    nop       
0x000142899d75:  488d054c9f4004        lea       rax, [rip + 0x4409f4c]
0x000142899d7c:  48898530030000        mov       qword ptr [rbp + 0x330], rax
0x000142899d83:  80bd5803000000        cmp       byte ptr [rbp + 0x358], 0
0x000142899d8a:  7433                  je        0x142899dbf
0x000142899d8c:  8b8544030000          mov       eax, dword ptr [rbp + 0x344]
0x000142899d92:  3d00080000            cmp       eax, 0x800
0x000142899d97:  7609                  jbe       0x142899da2
0x000142899d99:  488b8d50030000        mov       rcx, qword ptr [rbp + 0x350]
0x000142899da0:  eb17                  jmp       0x142899db9
0x000142899da2:  85c0                  test      eax, eax
0x000142899da4:  7419                  je        0x142899dbf
0x000142899da6:  488d8559030000        lea       rax, [rbp + 0x359]
0x000142899dad:  488b8d50030000        mov       rcx, qword ptr [rbp + 0x350]
0x000142899db4:  483bc8                cmp       rcx, rax
0x000142899db7:  7406                  je        0x142899dbf
0x000142899db9:  e8f2920a02            call      0x1449430b0
0x000142899dbe:  90                    nop       
0x000142899dbf:  32db                  xor       bl, bl
0x000142899dc1:  e999130000            jmp       0x14289b15f
0x000142899dc6:  488d05fb9e4004        lea       rax, [rip + 0x4409efb]
0x000142899dcd:  48898530030000        mov       qword ptr [rbp + 0x330], rax
0x000142899dd4:  80bd5803000000        cmp       byte ptr [rbp + 0x358], 0
0x000142899ddb:  7432                  je        0x142899e0f
0x000142899ddd:  8b8544030000          mov       eax, dword ptr [rbp + 0x344]
0x000142899de3:  3d00080000            cmp       eax, 0x800
0x000142899de8:  7609                  jbe       0x142899df3
0x000142899dea:  488b8d50030000        mov       rcx, qword ptr [rbp + 0x350]
0x000142899df1:  eb17                  jmp       0x142899e0a
0x000142899df3:  85c0                  test      eax, eax
0x000142899df5:  7418                  je        0x142899e0f
0x000142899df7:  488d8559030000        lea       rax, [rbp + 0x359]
0x000142899dfe:  488b8d50030000        mov       rcx, qword ptr [rbp + 0x350]
0x000142899e05:  483bc8                cmp       rcx, rax
0x000142899e08:  7405                  je        0x142899e0f
0x000142899e0a:  e8a1920a02            call      0x1449430b0
0x000142899e0f:  488d05a2ff3e04        lea       rax, [rip + 0x43effa2]
0x000142899e16:  48898530030000        mov       qword ptr [rbp + 0x330], rax
0x000142899e1d:  440fb775c0            movzx     r14d, word ptr [rbp - 0x40]
0x000142899e22:  4503f5                add       r14d, r13d
0x000142899e25:  44897580              mov       dword ptr [rbp - 0x80], r14d
0x000142899e29:  807c247035            cmp       byte ptr [rsp + 0x70], 0x35
0x000142899e2e:  734f                  jae       0x142899e7f
0x000142899e30:  488b05d90c4d05        mov       rax, qword ptr [rip + 0x54d0cd9]
0x000142899e37:  3c06                  cmp       al, 6
0x000142899e39:  0f8262020000          jb        0x14289a0a1
0x000142899e3f:  48c1e808              shr       rax, 8
0x000142899e43:  3c03                  cmp       al, 3
0x000142899e45:  0f8256020000          jb        0x14289a0a1
0x000142899e4b:  488d050eb1c606        lea       rax, [rip + 0x6c6b10e]
0x000142899e52:  488945d0              mov       qword ptr [rbp - 0x30], rax
0x000142899e56:  488b55d0              mov       rdx, qword ptr [rbp - 0x30]
0x000142899e5a:  488d159f186a04        lea       rdx, [rip + 0x46a189f]
0x000142899e61:  0f1005a80c4d05        movups    xmm0, xmmword ptr [rip + 0x54d0ca8]
0x000142899e68:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x000142899e6c:  458bc5                mov       r8d, r13d
0x000142899e6f:  488d4d90              lea       rcx, [rbp - 0x70]
0x000142899e73:  e8185a0c02            call      0x14495f890
0x000142899e78:  32db                  xor       bl, bl
0x000142899e7a:  e9e0120000            jmp       0x14289b15f
0x000142899e7f:  488b45f0              mov       rax, qword ptr [rbp - 0x10]
0x000142899e83:  0f1000                movups    xmm0, xmmword ptr [rax]
0x000142899e86:  0f298510030000        movaps    xmmword ptr [rbp + 0x310], xmm0
0x000142899e8d:  0f104810              movups    xmm1, xmmword ptr [rax + 0x10]
0x000142899e91:  0f298d20030000        movaps    xmmword ptr [rbp + 0x320], xmm1
0x000142899e98:  49c7c7ffffffff        mov       r15, 0xffffffffffffffff
0x000142899e9f:  44897c2420            mov       dword ptr [rsp + 0x20], r15d
0x000142899ea4:  41b101                mov       r9b, 1
0x000142899ea7:  450fb6c1              movzx     r8d, r9b
0x000142899eab:  488d9510030000        lea       rdx, [rbp + 0x310]
0x000142899eb2:  488bcf                mov       rcx, rdi
0x000142899eb5:  e896b5feff            call      0x142885450
0x000142899eba:  488bd0                mov       rdx, rax
0x000142899ebd:  48894530              mov       qword ptr [rbp + 0x30], rax
0x000142899ec1:  4885c0                test      rax, rax
0x000142899ec4:  0f84c9000000          je        0x142899f93
0x000142899eca:  0fb608                movzx     ecx, byte ptr [rax]
0x000142899ecd:  90                    nop       
0x000142899ece:  84c9                  test      cl, cl
0x000142899ed0:  0f84bd000000          je        0x142899f93
0x000142899ed6:  b001                  mov       al, 1
0x000142899ed8:  88442473              mov       byte ptr [rsp + 0x73], al
0x000142899edc:  83fe03                cmp       esi, 3
0x000142899edf:  0f85cb010000          jne       0x14289a0b0
0x000142899ee5:  33f6                  xor       esi, esi
0x000142899ee7:  4889b550020000        mov       qword ptr [rbp + 0x250], rsi
0x000142899eee:  4889b560020000        mov       qword ptr [rbp + 0x260], rsi
0x000142899ef5:  48c785680200000f000000  mov       qword ptr [rbp + 0x268], 0xf
0x000142899f00:  4088b550020000        mov       byte ptr [rbp + 0x250], sil
0x000142899f07:  458d4712              lea       r8d, [r15 + 0x12]
0x000142899f0b:  488d15ce156a04        lea       rdx, [rip + 0x46a15ce]
0x000142899f12:  488d8d50020000        lea       rcx, [rbp + 0x250]
0x000142899f19:  e8329bf4fd            call      0x1407e3a50
0x000142899f1e:  90                    nop       
0x000142899f1f:  4533c0                xor       r8d, r8d
0x000142899f22:  8d5601                lea       edx, [rsi + 1]
0x000142899f25:  488d8d50020000        lea       rcx, [rbp + 0x250]
0x000142899f2c:  e81fc63200            call      0x142bc6550
0x000142899f31:  90                    nop       
0x000142899f32:  488b8568020000        mov       rax, qword ptr [rbp + 0x268]
0x000142899f39:  4883f810              cmp       rax, 0x10
0x000142899f3d:  7230                  jb        0x142899f6f
0x000142899f3f:  48ffc0                inc       rax
0x000142899f42:  488b8d50020000        mov       rcx, qword ptr [rbp + 0x250]
0x000142899f49:  488bd1                mov       rdx, rcx
0x000142899f4c:  483d00100000          cmp       rax, 0x1000
0x000142899f52:  7215                  jb        0x142899f69
0x000142899f54:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000142899f58:  482bd1                sub       rdx, rcx
0x000142899f5b:  488d42f8              lea       rax, [rdx - 8]
0x000142899f5f:  4883f81f              cmp       rax, 0x1f
0x000142899f63:  0f879f120000          ja        0x14289b208
0x000142899f69:  e842910a02            call      0x1449430b0
0x000142899f6e:  90                    nop       
0x000142899f6f:  4889b560020000        mov       qword ptr [rbp + 0x260], rsi
0x000142899f76:  48c785680200000f000000  mov       qword ptr [rbp + 0x268], 0xf
0x000142899f81:  c6855002000000        mov       byte ptr [rbp + 0x250], 0
0x000142899f88:  b001                  mov       al, 1
0x000142899f8a:  488b5530              mov       rdx, qword ptr [rbp + 0x30]
0x000142899f8e:  e91f010000            jmp       0x14289a0b2
0x000142899f93:  32c0                  xor       al, al
0x000142899f95:  88442473              mov       byte ptr [rsp + 0x73], al
0x000142899f99:  83fe03                cmp       esi, 3
0x000142899f9c:  0f850e010000          jne       0x14289a0b0
0x000142899fa2:  48c785880200000f000000  mov       qword ptr [rbp + 0x288], 0xf
0x000142899fad:  48c785800200000c000000  mov       qword ptr [rbp + 0x280], 0xc
0x000142899fb8:  f20f1005a8156a04      movsd     xmm0, qword ptr [rip + 0x46a15a8]
0x000142899fc0:  f20f118570020000      movsd     qword ptr [rbp + 0x270], xmm0
0x000142899fc8:  8b05a2156a04          mov       eax, dword ptr [rip + 0x46a15a2]
0x000142899fce:  898578020000          mov       dword ptr [rbp + 0x278], eax
0x000142899fd4:  c6857c02000000        mov       byte ptr [rbp + 0x27c], 0
0x000142899fdb:  4533c0                xor       r8d, r8d
0x000142899fde:  8d56fe                lea       edx, [rsi - 2]
0x000142899fe1:  488d8d70020000        lea       rcx, [rbp + 0x270]
0x000142899fe8:  e863c53200            call      0x142bc6550
0x000142899fed:  90                    nop       
0x000142899fee:  488b8588020000        mov       rax, qword ptr [rbp + 0x288]
0x000142899ff5:  4883f810              cmp       rax, 0x10
0x000142899ff9:  7230                  jb        0x14289a02b
0x000142899ffb:  48ffc0                inc       rax
0x000142899ffe:  488b8d70020000        mov       rcx, qword ptr [rbp + 0x270]
0x00014289a005:  488bd1                mov       rdx, rcx
0x00014289a008:  483d00100000          cmp       rax, 0x1000
0x00014289a00e:  7215                  jb        0x14289a025
0x00014289a010:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289a014:  482bd1                sub       rdx, rcx
0x00014289a017:  488d42f8              lea       rax, [rdx - 8]
0x00014289a01b:  4883f81f              cmp       rax, 0x1f
0x00014289a01f:  0f87e9110000          ja        0x14289b20e
0x00014289a025:  e886900a02            call      0x1449430b0
0x00014289a02a:  90                    nop       
0x00014289a02b:  33f6                  xor       esi, esi
0x00014289a02d:  4889b580020000        mov       qword ptr [rbp + 0x280], rsi
0x00014289a034:  48c785880200000f000000  mov       qword ptr [rbp + 0x288], 0xf
0x00014289a03f:  4088b570020000        mov       byte ptr [rbp + 0x270], sil
0x00014289a046:  4839b7880d0000        cmp       qword ptr [rdi + 0xd88], rsi
0x00014289a04d:  7459                  je        0x14289a0a8
0x00014289a04f:  488b05ba0a4d05        mov       rax, qword ptr [rip + 0x54d0aba]
0x00014289a056:  3c06                  cmp       al, 6
0x00014289a058:  7247                  jb        0x14289a0a1
0x00014289a05a:  48c1e808              shr       rax, 8
0x00014289a05e:  3c03                  cmp       al, 3
0x00014289a060:  723f                  jb        0x14289a0a1
0x00014289a062:  488d0532d3c706        lea       rax, [rip + 0x6c7d332]
0x00014289a069:  488945d0              mov       qword ptr [rbp - 0x30], rax
0x00014289a06d:  488b55d0              mov       rdx, qword ptr [rbp - 0x30]
0x00014289a071:  488d1508156a04        lea       rdx, [rip + 0x46a1508]
0x00014289a078:  0f1005910a4d05        movups    xmm0, xmmword ptr [rip + 0x54d0a91]
0x00014289a07f:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x00014289a083:  4889742430            mov       qword ptr [rsp + 0x30], rsi
0x00014289a088:  4889742428            mov       qword ptr [rsp + 0x28], rsi
0x00014289a08d:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x00014289a092:  4533c9                xor       r9d, r9d
0x00014289a095:  4533c0                xor       r8d, r8d
0x00014289a098:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289a09c:  e87f5d0c02            call      0x14495fe20
0x00014289a0a1:  32db                  xor       bl, bl
0x00014289a0a3:  e9b7100000            jmp       0x14289b15f
0x00014289a0a8:  32c0                  xor       al, al
0x00014289a0aa:  488b5530              mov       rdx, qword ptr [rbp + 0x30]
0x00014289a0ae:  eb02                  jmp       0x14289a0b2
0x00014289a0b0:  33f6                  xor       esi, esi
0x00014289a0b2:  0f57c0                xorps     xmm0, xmm0
0x00014289a0b5:  660f7f4520            movdqa    xmmword ptr [rbp + 0x20], xmm0
0x00014289a0ba:  84c0                  test      al, al
0x00014289a0bc:  742b                  je        0x14289a0e9
0x00014289a0be:  488b8290010000        mov       rax, qword ptr [rdx + 0x190]
0x00014289a0c5:  4885c0                test      rax, rax
0x00014289a0c8:  7404                  je        0x14289a0ce
0x00014289a0ca:  f0ff4008              lock inc  dword ptr [rax + 8]
0x00014289a0ce:  488bb288010000        mov       rsi, qword ptr [rdx + 0x188]
0x00014289a0d5:  48897520              mov       qword ptr [rbp + 0x20], rsi
0x00014289a0d9:  488b8290010000        mov       rax, qword ptr [rdx + 0x190]
0x00014289a0e0:  48894528              mov       qword ptr [rbp + 0x28], rax
0x00014289a0e4:  e9ad020000            jmp       0x14289a396
0x00014289a0e9:  b980000000            mov       ecx, 0x80
0x00014289a0ee:  e8bdedf2fd            call      0x1407c8eb0
0x00014289a0f3:  488945b0              mov       qword ptr [rbp - 0x50], rax
0x00014289a0f7:  4885c0                test      rax, rax
0x00014289a0fa:  740a                  je        0x14289a106
0x00014289a0fc:  488bc8                mov       rcx, rax
0x00014289a0ff:  e8bcb2feff            call      0x1428853c0
0x00014289a104:  eb03                  jmp       0x14289a109
0x00014289a106:  488bc6                mov       rax, rsi
0x00014289a109:  488bd0                mov       rdx, rax
0x00014289a10c:  488d4d20              lea       rcx, [rbp + 0x20]
0x00014289a110:  e89b8d0000            call      0x1428a2eb0
0x00014289a115:  0fb74d84              movzx     ecx, word ptr [rbp - 0x7c]
0x00014289a119:  6685c9                test      cx, cx
0x00014289a11c:  0f95c0                setne     al
0x00014289a11f:  3887a80d0000          cmp       byte ptr [rdi + 0xda8], al
0x00014289a125:  7465                  je        0x14289a18c
0x00014289a127:  488b05e2094d05        mov       rax, qword ptr [rip + 0x54d09e2]
0x00014289a12e:  3c06                  cmp       al, 6
0x00014289a130:  0f82bd020000          jb        0x14289a3f3
0x00014289a136:  48c1e808              shr       rax, 8
0x00014289a13a:  3c03                  cmp       al, 3
0x00014289a13c:  0f82b1020000          jb        0x14289a3f3
0x00014289a142:  488d050b6dc906        lea       rax, [rip + 0x6c96d0b]
0x00014289a149:  488945d0              mov       qword ptr [rbp - 0x30], rax
0x00014289a14d:  488b55d0              mov       rdx, qword ptr [rbp - 0x30]
0x00014289a151:  488d15a8136a04        lea       rdx, [rip + 0x46a13a8]
0x00014289a158:  488d05e9ff5404        lea       rax, [rip + 0x454ffe9]
0x00014289a15f:  4c8d05d6b76604        lea       r8, [rip + 0x466b7d6]
0x00014289a166:  80bfa80d000000        cmp       byte ptr [rdi + 0xda8], 0
0x00014289a16d:  4c0f45c0              cmovne    r8, rax
0x00014289a171:  0f100598094d05        movups    xmm0, xmmword ptr [rip + 0x54d0998]
0x00014289a178:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x00014289a17c:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289a180:  e85b5f0c02            call      0x1449600e0
0x00014289a185:  32db                  xor       bl, bl
0x00014289a187:  e9c40f0000            jmp       0x14289b150
0x00014289a18c:  8bd1                  mov       edx, ecx
0x00014289a18e:  488d8d70010000        lea       rcx, [rbp + 0x170]
0x00014289a195:  e836030200            call      0x1428ba4d0
0x00014289a19a:  90                    nop       
0x00014289a19b:  488b8db8010000        mov       rcx, qword ptr [rbp + 0x1b8]
0x00014289a1a2:  48894db0              mov       qword ptr [rbp - 0x50], rcx
0x00014289a1a6:  488b85c0010000        mov       rax, qword ptr [rbp + 0x1c0]
0x00014289a1ad:  482bc1                sub       rax, rcx
0x00014289a1b0:  48894578              mov       qword ptr [rbp + 0x78], rax
0x00014289a1b4:  488b8da0010000        mov       rcx, qword ptr [rbp + 0x1a0]
0x00014289a1bb:  48898d90000000        mov       qword ptr [rbp + 0x90], rcx
0x00014289a1c2:  488b85a8010000        mov       rax, qword ptr [rbp + 0x1a8]
0x00014289a1c9:  482bc1                sub       rax, rcx
0x00014289a1cc:  48894570              mov       qword ptr [rbp + 0x70], rax
0x00014289a1d0:  488b8588010000        mov       rax, qword ptr [rbp + 0x188]
0x00014289a1d7:  48898588000000        mov       qword ptr [rbp + 0x88], rax
0x00014289a1de:  4c8ba590010000        mov       r12, qword ptr [rbp + 0x190]
0x00014289a1e5:  4c2be0                sub       r12, rax
0x00014289a1e8:  488b8570010000        mov       rax, qword ptr [rbp + 0x170]
0x00014289a1ef:  48898580000000        mov       qword ptr [rbp + 0x80], rax
0x00014289a1f6:  4c8bb578010000        mov       r14, qword ptr [rbp + 0x178]
0x00014289a1fd:  4c2bf0                sub       r14, rax
0x00014289a200:  488b7520              mov       rsi, qword ptr [rbp + 0x20]
0x00014289a204:  c6462801              mov       byte ptr [rsi + 0x28], 1
0x00014289a208:  488bce                mov       rcx, rsi
0x00014289a20b:  e8a02f0400            call      0x1428dd1b0
0x00014289a210:  84c0                  test      al, al
0x00014289a212:  0f848e000000          je        0x14289a2a6
0x00014289a218:  4983fe20              cmp       r14, 0x20
0x00014289a21c:  0f8584000000          jne       0x14289a2a6
0x00014289a222:  4d3be6                cmp       r12, r14
0x00014289a225:  757f                  jne       0x14289a2a6
0x00014289a227:  4c397570              cmp       qword ptr [rbp + 0x70], r14
0x00014289a22b:  7579                  jne       0x14289a2a6
0x00014289a22d:  4c397578              cmp       qword ptr [rbp + 0x78], r14
0x00014289a231:  7573                  jne       0x14289a2a6
0x00014289a233:  4c8d7620              lea       r14, [rsi + 0x20]
0x00014289a237:  498b06                mov       rax, qword ptr [r14]
0x00014289a23a:  488b8d80000000        mov       rcx, qword ptr [rbp + 0x80]
0x00014289a241:  0f1001                movups    xmm0, xmmword ptr [rcx]
0x00014289a244:  0f114040              movups    xmmword ptr [rax + 0x40], xmm0
0x00014289a248:  0f104910              movups    xmm1, xmmword ptr [rcx + 0x10]
0x00014289a24c:  0f114850              movups    xmmword ptr [rax + 0x50], xmm1
0x00014289a250:  498b06                mov       rax, qword ptr [r14]
0x00014289a253:  488b8d88000000        mov       rcx, qword ptr [rbp + 0x88]
0x00014289a25a:  0f1001                movups    xmm0, xmmword ptr [rcx]
0x00014289a25d:  0f114060              movups    xmmword ptr [rax + 0x60], xmm0
0x00014289a261:  0f104910              movups    xmm1, xmmword ptr [rcx + 0x10]
0x00014289a265:  0f114870              movups    xmmword ptr [rax + 0x70], xmm1
0x00014289a269:  498b06                mov       rax, qword ptr [r14]
0x00014289a26c:  488b8d90000000        mov       rcx, qword ptr [rbp + 0x90]
0x00014289a273:  0f1001                movups    xmm0, xmmword ptr [rcx]
0x00014289a276:  0f118080000000        movups    xmmword ptr [rax + 0x80], xmm0
0x00014289a27d:  0f104910              movups    xmm1, xmmword ptr [rcx + 0x10]
0x00014289a281:  0f118890000000        movups    xmmword ptr [rax + 0x90], xmm1
0x00014289a288:  498b06                mov       rax, qword ptr [r14]
0x00014289a28b:  488b4db0              mov       rcx, qword ptr [rbp - 0x50]
0x00014289a28f:  0f1001                movups    xmm0, xmmword ptr [rcx]
0x00014289a292:  0f1180a0000000        movups    xmmword ptr [rax + 0xa0], xmm0
0x00014289a299:  0f104910              movups    xmm1, xmmword ptr [rcx + 0x10]
0x00014289a29d:  0f1188b0000000        movups    xmmword ptr [rax + 0xb0], xmm1
0x00014289a2a4:  eb18                  jmp       0x14289a2be
0x00014289a2a6:  4c8d7620              lea       r14, [rsi + 0x20]
0x00014289a2aa:  33d2                  xor       edx, edx
0x00014289a2ac:  498bce                mov       rcx, r14
0x00014289a2af:  e8dc380400            call      0x1428ddb90
0x00014289a2b4:  66c746290000          mov       word ptr [rsi + 0x29], 0
0x00014289a2ba:  c6462b01              mov       byte ptr [rsi + 0x2b], 1
0x00014289a2be:  807e2b00              cmp       byte ptr [rsi + 0x2b], 0
0x00014289a2c2:  0f85ae000000          jne       0x14289a376
0x00014289a2c8:  807e2800              cmp       byte ptr [rsi + 0x28], 0
0x00014289a2cc:  0f84a4000000          je        0x14289a376
0x00014289a2d2:  4d8b06                mov       r8, qword ptr [r14]
0x00014289a2d5:  4d85c0                test      r8, r8
0x00014289a2d8:  0f8498000000          je        0x14289a376
0x00014289a2de:  498d90e0000000        lea       rdx, [r8 + 0xe0]
0x00014289a2e5:  498d88c0000000        lea       rcx, [r8 + 0xc0]
0x00014289a2ec:  4d8d4860              lea       r9, [r8 + 0x60]
0x00014289a2f0:  4983c040              add       r8, 0x40
0x00014289a2f4:  488d85f0020000        lea       rax, [rbp + 0x2f0]
0x00014289a2fb:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014289a300:  e82b6b0200            call      0x1428c0e30
0x00014289a305:  85c0                  test      eax, eax
0x00014289a307:  7416                  je        0x14289a31f
0x00014289a309:  33d2                  xor       edx, edx
0x00014289a30b:  498bce                mov       rcx, r14
0x00014289a30e:  e87d380400            call      0x1428ddb90
0x00014289a313:  66c746290000          mov       word ptr [rsi + 0x29], 0
0x00014289a319:  c6462b01              mov       byte ptr [rsi + 0x2b], 1
0x00014289a31d:  eb57                  jmp       0x14289a376
0x00014289a31f:  498b06                mov       rax, qword ptr [r14]
0x00014289a322:  488d9020010000        lea       rdx, [rax + 0x120]
0x00014289a329:  488d8800010000        lea       rcx, [rax + 0x100]
0x00014289a330:  4c8d88a0000000        lea       r9, [rax + 0xa0]
0x00014289a337:  4c8d8080000000        lea       r8, [rax + 0x80]
0x00014289a33e:  488d85f0020000        lea       rax, [rbp + 0x2f0]
0x00014289a345:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014289a34a:  e8e16a0200            call      0x1428c0e30
0x00014289a34f:  85c0                  test      eax, eax
0x00014289a351:  75b6                  jne       0x14289a309
0x00014289a353:  c6462901              mov       byte ptr [rsi + 0x29], 1
0x00014289a357:  498b06                mov       rax, qword ptr [r14]
0x00014289a35a:  0f1085f0020000        movups    xmm0, xmmword ptr [rbp + 0x2f0]
0x00014289a361:  0f118040010000        movups    xmmword ptr [rax + 0x140], xmm0
0x00014289a368:  0f108d00030000        movups    xmm1, xmmword ptr [rbp + 0x300]
0x00014289a36f:  0f118850010000        movups    xmmword ptr [rax + 0x150], xmm1
0x00014289a376:  488d8da0010000        lea       rcx, [rbp + 0x1a0]
0x00014289a37d:  e8de0e0000            call      0x14289b260
0x00014289a382:  488d8d70010000        lea       rcx, [rbp + 0x170]
0x00014289a389:  e8d20e0000            call      0x14289b260
0x00014289a38e:  4c8d6320              lea       r12, [rbx + 0x20]
0x00014289a392:  448b7580              mov       r14d, dword ptr [rbp - 0x80]
0x00014289a396:  488bc6                mov       rax, rsi
0x00014289a399:  4885c0                test      rax, rax
0x00014289a39c:  755c                  jne       0x14289a3fa
0x00014289a39e:  488b056b074d05        mov       rax, qword ptr [rip + 0x54d076b]
0x00014289a3a5:  3c06                  cmp       al, 6
0x00014289a3a7:  724a                  jb        0x14289a3f3
0x00014289a3a9:  48c1e808              shr       rax, 8
0x00014289a3ad:  3c03                  cmp       al, 3
0x00014289a3af:  7242                  jb        0x14289a3f3
0x00014289a3b1:  488d059a7aca06        lea       rax, [rip + 0x6ca7a9a]
0x00014289a3b8:  488945b0              mov       qword ptr [rbp - 0x50], rax
0x00014289a3bc:  488b55b0              mov       rdx, qword ptr [rbp - 0x50]
0x00014289a3c0:  488d15110f6a04        lea       rdx, [rip + 0x46a0f11]
0x00014289a3c7:  0f100542074d05        movups    xmm0, xmmword ptr [rip + 0x54d0742]
0x00014289a3ce:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x00014289a3d2:  4533f6                xor       r14d, r14d
0x00014289a3d5:  4c89742430            mov       qword ptr [rsp + 0x30], r14
0x00014289a3da:  4c89742428            mov       qword ptr [rsp + 0x28], r14
0x00014289a3df:  4c89742420            mov       qword ptr [rsp + 0x20], r14
0x00014289a3e4:  4533c9                xor       r9d, r9d
0x00014289a3e7:  4533c0                xor       r8d, r8d
0x00014289a3ea:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289a3ee:  e82d5a0c02            call      0x14495fe20
0x00014289a3f3:  32db                  xor       bl, bl
0x00014289a3f5:  e9560d0000            jmp       0x14289b150
0x00014289a3fa:  488d05c7984004        lea       rax, [rip + 0x44098c7]
0x00014289a401:  48898560040000        mov       qword ptr [rbp + 0x460], rax
0x00014289a408:  c6856804000000        mov       byte ptr [rbp + 0x468], 0
0x00014289a40f:  428d04f5e0000000      lea       eax, [r14*8 + 0xe0]
0x00014289a417:  898570040000          mov       dword ptr [rbp + 0x470], eax
0x00014289a41d:  4533f6                xor       r14d, r14d
0x00014289a420:  4489b578040000        mov       dword ptr [rbp + 0x478], r14d
0x00014289a427:  4488b588040000        mov       byte ptr [rbp + 0x488], r14b
0x00014289a42e:  898574040000          mov       dword ptr [rbp + 0x474], eax
0x00014289a434:  488b4500              mov       rax, qword ptr [rbp]
0x00014289a438:  48898580040000        mov       qword ptr [rbp + 0x480], rax
0x00014289a43f:  440fb6442470          movzx     r8d, byte ptr [rsp + 0x70]
0x00014289a445:  488d9560040000        lea       rdx, [rbp + 0x460]
0x00014289a44c:  488bce                mov       rcx, rsi
0x00014289a44f:  e87cfd0100            call      0x1428ba1d0
0x00014289a454:  84c0                  test      al, al
0x00014289a456:  756b                  jne       0x14289a4c3
0x00014289a458:  41b901040000          mov       r9d, 0x401
0x00014289a45e:  4c8d85800b0000        lea       r8, [rbp + 0xb80]
0x00014289a465:  33d2                  xor       edx, edx
0x00014289a467:  488b4df0              mov       rcx, qword ptr [rbp - 0x10]
0x00014289a46b:  e830b20000            call      0x1428a56a0
0x00014289a470:  488b0599064d05        mov       rax, qword ptr [rip + 0x54d0699]
0x00014289a477:  3c06                  cmp       al, 6
0x00014289a479:  0f82e8020000          jb        0x14289a767
0x00014289a47f:  48c1e808              shr       rax, 8
0x00014289a483:  3c03                  cmp       al, 3
0x00014289a485:  0f82dc020000          jb        0x14289a767
0x00014289a48b:  488d05b240cb06        lea       rax, [rip + 0x6cb40b2]
0x00014289a492:  488945b0              mov       qword ptr [rbp - 0x50], rax
0x00014289a496:  488b55b0              mov       rdx, qword ptr [rbp - 0x50]
0x00014289a49a:  488d1557116a04        lea       rdx, [rip + 0x46a1157]
0x00014289a4a1:  0f100568064d05        movups    xmm0, xmmword ptr [rip + 0x54d0668]
0x00014289a4a8:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x00014289a4ac:  4c8d85800b0000        lea       r8, [rbp + 0xb80]
0x00014289a4b3:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289a4b7:  e8245c0c02            call      0x1449600e0
0x00014289a4bc:  32db                  xor       bl, bl
0x00014289a4be:  e9360c0000            jmp       0x14289b0f9
0x00014289a4c3:  488b8ff80e0000        mov       rcx, qword ptr [rdi + 0xef8]
0x00014289a4ca:  4885c9                test      rcx, rcx
0x00014289a4cd:  740d                  je        0x14289a4dc
0x00014289a4cf:  488b01                mov       rax, qword ptr [rcx]
0x00014289a4d2:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x00014289a4d6:  ff155c588a03          call      qword ptr [rip + 0x38a585c]
0x00014289a4dc:  8b8578040000          mov       eax, dword ptr [rbp + 0x478]
0x00014289a4e2:  428d0ce8              lea       ecx, [rax + r13*8]
0x00014289a4e6:  898d78040000          mov       dword ptr [rbp + 0x478], ecx
0x00014289a4ec:  8b8570040000          mov       eax, dword ptr [rbp + 0x470]
0x00014289a4f2:  2bc1                  sub       eax, ecx
0x00014289a4f4:  83f840                cmp       eax, 0x40
0x00014289a4f7:  7216                  jb        0x14289a50f
0x00014289a4f9:  488d55b8              lea       rdx, [rbp - 0x48]
0x00014289a4fd:  488d8d60040000        lea       rcx, [rbp + 0x460]
0x00014289a504:  e8176d0000            call      0x1428a1220
0x00014289a509:  4c8b6db8              mov       r13, qword ptr [rbp - 0x48]
0x00014289a50d:  eb03                  jmp       0x14289a512
0x00014289a50f:  4d8bee                mov       r13, r14
0x00014289a512:  488d15470d4d05        lea       rdx, [rip + 0x54d0d47]
0x00014289a519:  488d8d90050000        lea       rcx, [rbp + 0x590]
0x00014289a520:  e89b7c94fe            call      0x1411e21c0
0x00014289a525:  90                    nop       
0x00014289a526:  488d8df8050000        lea       rcx, [rbp + 0x5f8]
0x00014289a52d:  e84e5a6400            call      0x142edff80
0x00014289a532:  90                    nop       
0x00014289a533:  488d8db8050000        lea       rcx, [rbp + 0x5b8]
0x00014289a53a:  e8a1b4f4fd            call      0x1407e59e0
0x00014289a53f:  488b0522535505        mov       rax, qword ptr [rip + 0x5555322]
0x00014289a546:  48894510              mov       qword ptr [rbp + 0x10], rax
0x00014289a54a:  0fb7051f535505        movzx     eax, word ptr [rip + 0x555531f]
0x00014289a551:  66894518              mov       word ptr [rbp + 0x18], ax
0x00014289a555:  488d5510              lea       rdx, [rbp + 0x10]
0x00014289a559:  488d8d60040000        lea       rcx, [rbp + 0x460]
0x00014289a560:  e8bb6c0000            call      0x1428a1220
0x00014289a565:  488d5580              lea       rdx, [rbp - 0x80]
0x00014289a569:  488d8d60040000        lea       rcx, [rbp + 0x460]
0x00014289a570:  e83b6e0000            call      0x1428a13b0
0x00014289a575:  41b808000000          mov       r8d, 8
0x00014289a57b:  488d542475            lea       rdx, [rsp + 0x75]
0x00014289a580:  488d8d60040000        lea       rcx, [rbp + 0x460]
0x00014289a587:  e8f4b90000            call      0x1428a5f80
0x00014289a58c:  0f57c0                xorps     xmm0, xmm0
0x00014289a58f:  33c0                  xor       eax, eax
0x00014289a591:  0f1185d0020000        movups    xmmword ptr [rbp + 0x2d0], xmm0
0x00014289a598:  488985e0020000        mov       qword ptr [rbp + 0x2e0], rax
0x00014289a59f:  8985e8020000          mov       dword ptr [rbp + 0x2e8], eax
0x00014289a5a5:  b802000000            mov       eax, 2
0x00014289a5aa:  668985d0020000        mov       word ptr [rbp + 0x2d0], ax
0x00014289a5b1:  c785ec0200000000ffff  mov       dword ptr [rbp + 0x2ec], 0xffff0000
0x00014289a5bb:  488d95d0020000        lea       rdx, [rbp + 0x2d0]
0x00014289a5c2:  488d8d60040000        lea       rcx, [rbp + 0x460]
0x00014289a5c9:  e842ecfdff            call      0x142879210
0x00014289a5ce:  803d53b9a20500        cmp       byte ptr [rip + 0x5a2b953], 0
0x00014289a5d5:  7465                  je        0x14289a63c
0x00014289a5d7:  803d2abca20500        cmp       byte ptr [rip + 0x5a2bc2a], 0
0x00014289a5de:  745c                  je        0x14289a63c
0x00014289a5e0:  0f57c0                xorps     xmm0, xmm0
0x00014289a5e3:  33c0                  xor       eax, eax
0x00014289a5e5:  0f1185b0020000        movups    xmmword ptr [rbp + 0x2b0], xmm0
0x00014289a5ec:  488985c0020000        mov       qword ptr [rbp + 0x2c0], rax
0x00014289a5f3:  8985c8020000          mov       dword ptr [rbp + 0x2c8], eax
0x00014289a5f9:  b802000000            mov       eax, 2
0x00014289a5fe:  668985b0020000        mov       word ptr [rbp + 0x2b0], ax
0x00014289a605:  c785cc0200000000ffff  mov       dword ptr [rbp + 0x2cc], 0xffff0000
0x00014289a60f:  488d95b0020000        lea       rdx, [rbp + 0x2b0]
0x00014289a616:  488d8d60040000        lea       rcx, [rbp + 0x460]
0x00014289a61d:  e8eeebfdff            call      0x142879210
0x00014289a622:  488b07                mov       rax, qword ptr [rdi]
0x00014289a625:  488d95b0020000        lea       rdx, [rbp + 0x2b0]
0x00014289a62c:  488bcf                mov       rcx, rdi
0x00014289a62f:  488b8030030000        mov       rax, qword ptr [rax + 0x330]
0x00014289a636:  ff15fc568a03          call      qword ptr [rip + 0x38a56fc]
0x00014289a63c:  c644247200            mov       byte ptr [rsp + 0x72], 0
0x00014289a641:  41b808000000          mov       r8d, 8
0x00014289a647:  488d542472            lea       rdx, [rsp + 0x72]
0x00014289a64c:  488d8d60040000        lea       rcx, [rbp + 0x460]
0x00014289a653:  e828b90000            call      0x1428a5f80
0x00014289a658:  440fb6742472          movzx     r14d, byte ptr [rsp + 0x72]
0x00014289a65e:  418bd6                mov       edx, r14d
0x00014289a661:  498b442410            mov       rax, qword ptr [r12 + 0x10]
0x00014289a666:  4c3bf0                cmp       r14, rax
0x00014289a669:  771b                  ja        0x14289a686
0x00014289a66b:  498bc4                mov       rax, r12
0x00014289a66e:  49837c241810          cmp       qword ptr [r12 + 0x18], 0x10
0x00014289a674:  7204                  jb        0x14289a67a
0x00014289a676:  498b0424              mov       rax, qword ptr [r12]
0x00014289a67a:  4989542410            mov       qword ptr [r12 + 0x10], rdx
0x00014289a67f:  42c6043000            mov       byte ptr [rax + r14], 0
0x00014289a684:  eb0e                  jmp       0x14289a694
0x00014289a686:  482bd0                sub       rdx, rax
0x00014289a689:  4533c0                xor       r8d, r8d
0x00014289a68c:  498bcc                mov       rcx, r12
0x00014289a68f:  e8dcbdf4fd            call      0x1407e6470
0x00014289a694:  49837c241810          cmp       qword ptr [r12 + 0x18], 0x10
0x00014289a69a:  7204                  jb        0x14289a6a0
0x00014289a69c:  4d8b2424              mov       r12, qword ptr [r12]
0x00014289a6a0:  4585f6                test      r14d, r14d
0x00014289a6a3:  7457                  je        0x14289a6fc
0x00014289a6a5:  8b8d78040000          mov       ecx, dword ptr [rbp + 0x478]
0x00014289a6ab:  8d41ff                lea       eax, [rcx - 1]
0x00014289a6ae:  83e007                and       eax, 7
0x00014289a6b1:  2bc8                  sub       ecx, eax
0x00014289a6b3:  83c107                add       ecx, 7
0x00014289a6b6:  898d78040000          mov       dword ptr [rbp + 0x478], ecx
0x00014289a6bc:  428d14f500000000      lea       edx, [r14*8]
0x00014289a6c4:  8b8570040000          mov       eax, dword ptr [rbp + 0x470]
0x00014289a6ca:  3bd0                  cmp       edx, eax
0x00014289a6cc:  772e                  ja        0x14289a6fc
0x00014289a6ce:  2bc2                  sub       eax, edx
0x00014289a6d0:  3bc8                  cmp       ecx, eax
0x00014289a6d2:  7728                  ja        0x14289a6fc
0x00014289a6d4:  4d8bc6                mov       r8, r14
0x00014289a6d7:  8bd1                  mov       edx, ecx
0x00014289a6d9:  48c1ea03              shr       rdx, 3
0x00014289a6dd:  48039580040000        add       rdx, qword ptr [rbp + 0x480]
0x00014289a6e4:  498bcc                mov       rcx, r12
0x00014289a6e7:  e8b48a2a03            call      0x145b431a0
0x00014289a6ec:  8b8578040000          mov       eax, dword ptr [rbp + 0x478]
0x00014289a6f2:  428d0cf0              lea       ecx, [rax + r14*8]
0x00014289a6f6:  898d78040000          mov       dword ptr [rbp + 0x478], ecx
0x00014289a6fc:  488b4568              mov       rax, qword ptr [rbp + 0x68]
0x00014289a700:  f0ff4008              lock inc  dword ptr [rax + 8]
0x00014289a704:  48895e30              mov       qword ptr [rsi + 0x30], rbx
0x00014289a708:  488b4e38              mov       rcx, qword ptr [rsi + 0x38]
0x00014289a70c:  48894638              mov       qword ptr [rsi + 0x38], rax
0x00014289a710:  4885c9                test      rcx, rcx
0x00014289a713:  7405                  je        0x14289a71a
0x00014289a715:  e8f6e7f2fd            call      0x1407c8f10
0x00014289a71a:  b840020000            mov       eax, 0x240
0x00014289a71f:  66394580              cmp       word ptr [rbp - 0x80], ax
0x00014289a723:  7349                  jae       0x14289a76e
0x00014289a725:  488b05e4034d05        mov       rax, qword ptr [rip + 0x54d03e4]
0x00014289a72c:  3c06                  cmp       al, 6
0x00014289a72e:  7237                  jb        0x14289a767
0x00014289a730:  48c1e808              shr       rax, 8
0x00014289a734:  3c03                  cmp       al, 3
0x00014289a736:  722f                  jb        0x14289a767
0x00014289a738:  488d0576afce06        lea       rax, [rip + 0x6ceaf76]
0x00014289a73f:  488945b8              mov       qword ptr [rbp - 0x48], rax
0x00014289a743:  488b55b8              mov       rdx, qword ptr [rbp - 0x48]
0x00014289a747:  488d15ea0e6a04        lea       rdx, [rip + 0x46a0eea]
0x00014289a74e:  0f1005bb034d05        movups    xmm0, xmmword ptr [rip + 0x54d03bb]
0x00014289a755:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x00014289a759:  440fb74580            movzx     r8d, word ptr [rbp - 0x80]
0x00014289a75e:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289a762:  e829510c02            call      0x14495f890
0x00014289a767:  32db                  xor       bl, bl
0x00014289a769:  e98b090000            jmp       0x14289b0f9
0x00014289a76e:  4533f6                xor       r14d, r14d
0x00014289a771:  4c897500              mov       qword ptr [rbp], r14
0x00014289a775:  41bc01000000          mov       r12d, 1
0x00014289a77b:  418bd4                mov       edx, r12d
0x00014289a77e:  488d4d00              lea       rcx, [rbp]
0x00014289a782:  e8d9c20000            call      0x1428a6a60
0x00014289a787:  488b7500              mov       rsi, qword ptr [rbp]
0x00014289a78b:  4923f5                and       rsi, r13
0x00014289a78e:  4533c0                xor       r8d, r8d
0x00014289a791:  418bd7                mov       edx, r15d
0x00014289a794:  488d8d00060000        lea       rcx, [rbp + 0x600]
0x00014289a79b:  e820231e00            call      0x142a7cac0
0x00014289a7a0:  90                    nop       
0x00014289a7a1:  4533c0                xor       r8d, r8d
0x00014289a7a4:  488d1d350e6a04        lea       rbx, [rip + 0x46a0e35]
0x00014289a7ab:  488bd3                mov       rdx, rbx
0x00014289a7ae:  488d8d00060000        lea       rcx, [rbp + 0x600]
0x00014289a7b5:  e836501e00            call      0x142a7f7f0
0x00014289a7ba:  4885c0                test      rax, rax
0x00014289a7bd:  7452                  je        0x14289a811
0x00014289a7bf:  488bd6                mov       rdx, rsi
0x00014289a7c2:  488bc8                mov       rcx, rax
0x00014289a7c5:  e8d6081e00            call      0x142a7b0a0
0x00014289a7ca:  488b8d58080000        mov       rcx, qword ptr [rbp + 0x858]
0x00014289a7d1:  4885c9                test      rcx, rcx
0x00014289a7d4:  743b                  je        0x14289a811
0x00014289a7d6:  488b01                mov       rax, qword ptr [rcx]
0x00014289a7d9:  48899da0000000        mov       qword ptr [rbp + 0xa0], rbx
0x00014289a7e0:  48c785a800000017000000  mov       qword ptr [rbp + 0xa8], 0x17
0x00014289a7eb:  0f2885a0000000        movaps    xmm0, xmmword ptr [rbp + 0xa0]
0x00014289a7f2:  660f7f85f0000000      movdqa    xmmword ptr [rbp + 0xf0], xmm0
0x00014289a7fa:  458bcc                mov       r9d, r12d
0x00014289a7fd:  4c8bc6                mov       r8, rsi
0x00014289a800:  488d95f0000000        lea       rdx, [rbp + 0xf0]
0x00014289a807:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x00014289a80b:  ff1527558a03          call      qword ptr [rip + 0x38a5527]
0x00014289a811:  8b1df1cca205          mov       ebx, dword ptr [rip + 0x5a2ccf1]
0x00014289a817:  4c89b590020000        mov       qword ptr [rbp + 0x290], r14
0x00014289a81e:  4c89b5a0020000        mov       qword ptr [rbp + 0x2a0], r14
0x00014289a825:  48c785a80200000f000000  mov       qword ptr [rbp + 0x2a8], 0xf
0x00014289a830:  c6859002000000        mov       byte ptr [rbp + 0x290], 0
0x00014289a837:  41b81d000000          mov       r8d, 0x1d
0x00014289a83d:  488d1534f16904        lea       rdx, [rip + 0x469f134]
0x00014289a844:  488d8d90020000        lea       rcx, [rbp + 0x290]
0x00014289a84b:  e80092f4fd            call      0x1407e3a50
0x00014289a850:  90                    nop       
0x00014289a851:  c644242000            mov       byte ptr [rsp + 0x20], 0
0x00014289a856:  41b101                mov       r9b, 1
0x00014289a859:  448bc3                mov       r8d, ebx
0x00014289a85c:  488d9590020000        lea       rdx, [rbp + 0x290]
0x00014289a863:  488d8d00060000        lea       rcx, [rbp + 0x600]
0x00014289a86a:  e831421e00            call      0x142a7eaa0
0x00014289a86f:  90                    nop       
0x00014289a870:  488b85a8020000        mov       rax, qword ptr [rbp + 0x2a8]
0x00014289a877:  4883f810              cmp       rax, 0x10
0x00014289a87b:  7230                  jb        0x14289a8ad
0x00014289a87d:  48ffc0                inc       rax
0x00014289a880:  488b8d90020000        mov       rcx, qword ptr [rbp + 0x290]
0x00014289a887:  488bd1                mov       rdx, rcx
0x00014289a88a:  483d00100000          cmp       rax, 0x1000
0x00014289a890:  7215                  jb        0x14289a8a7
0x00014289a892:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014289a896:  482bd1                sub       rdx, rcx
0x00014289a899:  488d42f8              lea       rax, [rdx - 8]
0x00014289a89d:  4883f81f              cmp       rax, 0x1f
0x00014289a8a1:  0f876d090000          ja        0x14289b214
0x00014289a8a7:  e804880a02            call      0x1449430b0
0x00014289a8ac:  90                    nop       
0x00014289a8ad:  4c89b5a0020000        mov       qword ptr [rbp + 0x2a0], r14
0x00014289a8b4:  48c785a80200000f000000  mov       qword ptr [rbp + 0x2a8], 0xf
0x00014289a8bf:  c6859002000000        mov       byte ptr [rbp + 0x290], 0
0x00014289a8c6:  4c8b4510              mov       r8, qword ptr [rbp + 0x10]
0x00014289a8ca:  4c3b05974f5505        cmp       r8, qword ptr [rip + 0x5554f97]
0x00014289a8d1:  7459                  je        0x14289a92c
0x00014289a8d3:  418bce                mov       ecx, r14d
0x00014289a8d6:  66443bb712010000      cmp       r14w, word ptr [rdi + 0x112]
0x00014289a8de:  734c                  jae       0x14289a92c
0x00014289a8e0:  8bc1                  mov       eax, ecx
0x00014289a8e2:  4869d0d8160000        imul      rdx, rax, 0x16d8
0x00014289a8e9:  488b8750030000        mov       rax, qword ptr [rdi + 0x350]
0x00014289a8f0:  4c39840230160000      cmp       qword ptr [rdx + rax + 0x1630], r8
0x00014289a8f8:  750d                  jne       0x14289a907
0x00014289a8fa:  0fb60402              movzx     eax, byte ptr [rdx + rax]
0x00014289a8fe:  90                    nop       
0x00014289a8ff:  84c0                  test      al, al
0x00014289a901:  7511                  jne       0x14289a914
0x00014289a903:  4c8b4510              mov       r8, qword ptr [rbp + 0x10]
0x00014289a907:  ffc1                  inc       ecx
0x00014289a909:  0fb78712010000        movzx     eax, word ptr [rdi + 0x112]
0x00014289a910:  3bc8                  cmp       ecx, eax
0x00014289a912:  ebca                  jmp       0x14289a8de
0x00014289a914:  488b8f50030000        mov       rcx, qword ptr [rdi + 0x350]
0x00014289a91b:  4803ca                add       rcx, rdx
0x00014289a91e:  740f                  je        0x14289a92f
0x00014289a920:  0fb601                movzx     eax, byte ptr [rcx]
0x00014289a923:  90                    nop       
0x00014289a924:  84c0                  test      al, al
0x00014289a926:  7407                  je        0x14289a92f
0x00014289a928:  b001                  mov       al, 1
0x00014289a92a:  eb05                  jmp       0x14289a931
0x00014289a92c:  498bce                mov       rcx, r14
0x00014289a92f:  32c0                  xor       al, al
0x00014289a931:  0fb6542473            movzx     edx, byte ptr [rsp + 0x73]
0x00014289a936:  84d2                  test      dl, dl
0x00014289a938:  7451                  je        0x14289a98b
0x00014289a93a:  84c0                  test      al, al
0x00014289a93c:  7448                  je        0x14289a986
0x00014289a93e:  488b5530              mov       rdx, qword ptr [rbp + 0x30]
0x00014289a942:  483bd1                cmp       rdx, rcx
0x00014289a945:  754c                  jne       0x14289a993
0x00014289a947:  83bad416000006        cmp       dword ptr [rdx + 0x16d4], 6
0x00014289a94e:  7543                  jne       0x14289a993
0x00014289a950:  488b4d50              mov       rcx, qword ptr [rbp + 0x50]
0x00014289a954:  48894c2430            mov       qword ptr [rsp + 0x30], rcx
0x00014289a959:  488b8540140000        mov       rax, qword ptr [rbp + 0x1440]
0x00014289a960:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x00014289a965:  488b45e0              mov       rax, qword ptr [rbp - 0x20]
0x00014289a969:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014289a96e:  4c8b4d60              mov       r9, qword ptr [rbp + 0x60]
0x00014289a972:  4c8b45f0              mov       r8, qword ptr [rbp - 0x10]
0x00014289a976:  488bcf                mov       rcx, rdi
0x00014289a979:  e882090000            call      0x14289b300
0x00014289a97e:  0fb6d8                movzx     ebx, al
0x00014289a981:  e966070000            jmp       0x14289b0ec
0x00014289a986:  80fa01                cmp       dl, 1
0x00014289a989:  eb02                  jmp       0x14289a98d
0x00014289a98b:  3c01                  cmp       al, 1
0x00014289a98d:  0f8585000000          jne       0x14289aa18
0x00014289a993:  488b0576014d05        mov       rax, qword ptr [rip + 0x54d0176]
0x00014289a99a:  3c06                  cmp       al, 6
0x00014289a99c:  7247                  jb        0x14289a9e5
0x00014289a99e:  48c1e808              shr       rax, 8
0x00014289a9a2:  3c03                  cmp       al, 3
0x00014289a9a4:  723f                  jb        0x14289a9e5
0x00014289a9a6:  488d05583cd206        lea       rax, [rip + 0x6d23c58]
0x00014289a9ad:  488945b8              mov       qword ptr [rbp - 0x48], rax
0x00014289a9b1:  488b55b8              mov       rdx, qword ptr [rbp - 0x48]
0x00014289a9b5:  488d15dcef6904        lea       rdx, [rip + 0x469efdc]
0x00014289a9bc:  0f10054d014d05        movups    xmm0, xmmword ptr [rip + 0x54d014d]
0x00014289a9c3:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x00014289a9c7:  4c89742430            mov       qword ptr [rsp + 0x30], r14
0x00014289a9cc:  4c89742428            mov       qword ptr [rsp + 0x28], r14
0x00014289a9d1:  4c89742420            mov       qword ptr [rsp + 0x20], r14
0x00014289a9d6:  4533c9                xor       r9d, r9d
0x00014289a9d9:  4533c0                xor       r8d, r8d
0x00014289a9dc:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289a9e0:  e83b540c02            call      0x14495fe20
0x00014289a9e5:  c644243001            mov       byte ptr [rsp + 0x30], 1
0x00014289a9ea:  488b8540140000        mov       rax, qword ptr [rbp + 0x1440]
0x00014289a9f1:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x00014289a9f6:  488b45e0              mov       rax, qword ptr [rbp - 0x20]
0x00014289a9fa:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014289a9ff:  4c8b4df0              mov       r9, qword ptr [rbp - 0x10]
0x00014289aa03:  4c8d4510              lea       r8, [rbp + 0x10]
0x00014289aa07:  b212                  mov       dl, 0x12
0x00014289aa09:  488bcf                mov       rcx, rdi
0x00014289aa0c:  e84f210000            call      0x14289cb60
0x00014289aa11:  b301                  mov       bl, 1
0x00014289aa13:  e9d4060000            jmp       0x14289b0ec
0x00014289aa18:  4883bf5003000000      cmp       qword ptr [rdi + 0x350], 0
0x00014289aa20:  7460                  je        0x14289aa82
0x00014289aa22:  0fb68708010000        movzx     eax, byte ptr [rdi + 0x108]
0x00014289aa29:  90                    nop       
0x00014289aa2a:  3c01                  cmp       al, 1
0x00014289aa2c:  7454                  je        0x14289aa82
0x00014289aa2e:  410fb7de              movzx     ebx, r14w
0x00014289aa32:  418bd6                mov       edx, r14d
0x00014289aa35:  8b8760030000          mov       eax, dword ptr [rdi + 0x360]
0x00014289aa3b:  90                    nop       
0x00014289aa3c:  85c0                  test      eax, eax
0x00014289aa3e:  7445                  je        0x14289aa85
0x00014289aa40:  448bc2                mov       r8d, edx
0x00014289aa43:  488b8758030000        mov       rax, qword ptr [rdi + 0x358]
0x00014289aa4a:  4a8b0cc0              mov       rcx, qword ptr [rax + r8*8]
0x00014289aa4e:  0fb601                movzx     eax, byte ptr [rcx]
0x00014289aa51:  90                    nop       
0x00014289aa52:  84c0                  test      al, al
0x00014289aa54:  741d                  je        0x14289aa73
0x00014289aa56:  488b8758030000        mov       rax, qword ptr [rdi + 0x358]
0x00014289aa5d:  4a8b0cc0              mov       rcx, qword ptr [rax + r8*8]
0x00014289aa61:  83b9d416000007        cmp       dword ptr [rcx + 0x16d4], 7
0x00014289aa68:  7509                  jne       0x14289aa73
0x00014289aa6a:  80790100              cmp       byte ptr [rcx + 1], 0
0x00014289aa6e:  7503                  jne       0x14289aa73
0x00014289aa70:  66ffc3                inc       bx
0x00014289aa73:  ffc2                  inc       edx
0x00014289aa75:  8b8760030000          mov       eax, dword ptr [rdi + 0x360]
0x00014289aa7b:  90                    nop       
0x00014289aa7c:  3bd0                  cmp       edx, eax
0x00014289aa7e:  72c0                  jb        0x14289aa40
0x00014289aa80:  eb03                  jmp       0x14289aa85
0x00014289aa82:  418bde                mov       ebx, r14d
0x00014289aa85:  488b07                mov       rax, qword ptr [rdi]
0x00014289aa88:  488bcf                mov       rcx, rdi
0x00014289aa8b:  488b4040              mov       rax, qword ptr [rax + 0x40]
0x00014289aa8f:  ff15a3528a03          call      qword ptr [rip + 0x38a52a3]
0x00014289aa95:  663bd8                cmp       bx, ax
0x00014289aa98:  0f8285000000          jb        0x14289ab23
0x00014289aa9e:  488b056b004d05        mov       rax, qword ptr [rip + 0x54d006b]
0x00014289aaa5:  3c06                  cmp       al, 6
0x00014289aaa7:  7247                  jb        0x14289aaf0
0x00014289aaa9:  48c1e808              shr       rax, 8
0x00014289aaad:  3c03                  cmp       al, 3
0x00014289aaaf:  723f                  jb        0x14289aaf0
0x00014289aab1:  488d0598c3d206        lea       rax, [rip + 0x6d2c398]
0x00014289aab8:  488945b8              mov       qword ptr [rbp - 0x48], rax
0x00014289aabc:  488b55b8              mov       rdx, qword ptr [rbp - 0x48]
0x00014289aac0:  488d1509ee6904        lea       rdx, [rip + 0x469ee09]
0x00014289aac7:  0f100542004d05        movups    xmm0, xmmword ptr [rip + 0x54d0042]
0x00014289aace:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x00014289aad2:  4c89742430            mov       qword ptr [rsp + 0x30], r14
0x00014289aad7:  4c89742428            mov       qword ptr [rsp + 0x28], r14
0x00014289aadc:  4c89742420            mov       qword ptr [rsp + 0x20], r14
0x00014289aae1:  4533c9                xor       r9d, r9d
0x00014289aae4:  4533c0                xor       r8d, r8d
0x00014289aae7:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289aaeb:  e830530c02            call      0x14495fe20
0x00014289aaf0:  c644243001            mov       byte ptr [rsp + 0x30], 1
0x00014289aaf5:  488b8540140000        mov       rax, qword ptr [rbp + 0x1440]
0x00014289aafc:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x00014289ab01:  488b45e0              mov       rax, qword ptr [rbp - 0x20]
0x00014289ab05:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014289ab0a:  4c8b4df0              mov       r9, qword ptr [rbp - 0x10]
0x00014289ab0e:  4c8d4510              lea       r8, [rbp + 0x10]
0x00014289ab12:  b214                  mov       dl, 0x14
0x00014289ab14:  488bcf                mov       rcx, rdi
0x00014289ab17:  e844200000            call      0x14289cb60
0x00014289ab1c:  b301                  mov       bl, 1
0x00014289ab1e:  e9c9050000            jmp       0x14289b0ec
0x00014289ab23:  c644247400            mov       byte ptr [rsp + 0x74], 0
0x00014289ab28:  0f57c0                xorps     xmm0, xmm0
0x00014289ab2b:  660f7f4530            movdqa    xmmword ptr [rbp + 0x30], xmm0
0x00014289ab30:  488b4d28              mov       rcx, qword ptr [rbp + 0x28]
0x00014289ab34:  4885c9                test      rcx, rcx
0x00014289ab37:  7404                  je        0x14289ab3d
0x00014289ab39:  f0ff4108              lock inc  dword ptr [rcx + 8]
0x00014289ab3d:  0f284520              movaps    xmm0, xmmword ptr [rbp + 0x20]
0x00014289ab41:  660f7f4530            movdqa    xmmword ptr [rbp + 0x30], xmm0
0x00014289ab46:  440fb74580            movzx     r8d, word ptr [rbp - 0x80]
0x00014289ab4b:  488b5de0              mov       rbx, qword ptr [rbp - 0x20]
0x00014289ab4f:  488bd3                mov       rdx, rbx
0x00014289ab52:  488d8d00010000        lea       rcx, [rbp + 0x100]
0x00014289ab59:  e8927bf4fd            call      0x1407e26f0
0x00014289ab5e:  488b4c2478            mov       rcx, qword ptr [rsp + 0x78]
0x00014289ab63:  0f2801                movaps    xmm0, xmmword ptr [rcx]
0x00014289ab66:  660f7f8510010000      movdqa    xmmword ptr [rbp + 0x110], xmm0
0x00014289ab6e:  0f284d10              movaps    xmm1, xmmword ptr [rbp + 0x10]
0x00014289ab72:  660f7f8d20010000      movdqa    xmmword ptr [rbp + 0x120], xmm1
0x00014289ab7a:  4c8b65f0              mov       r12, qword ptr [rbp - 0x10]
0x00014289ab7e:  410f100424            movups    xmm0, xmmword ptr [r12]
0x00014289ab83:  0f2985d0010000        movaps    xmmword ptr [rbp + 0x1d0], xmm0
0x00014289ab8a:  410f104c2410          movups    xmm1, xmmword ptr [r12 + 0x10]
0x00014289ab90:  0f298de0010000        movaps    xmmword ptr [rbp + 0x1e0], xmm1
0x00014289ab97:  488b4d50              mov       rcx, qword ptr [rbp + 0x50]
0x00014289ab9b:  48894c2460            mov       qword ptr [rsp + 0x60], rcx
0x00014289aba0:  488d8d10010000        lea       rcx, [rbp + 0x110]
0x00014289aba7:  48894c2458            mov       qword ptr [rsp + 0x58], rcx
0x00014289abac:  488d4d30              lea       rcx, [rbp + 0x30]
0x00014289abb0:  48894c2450            mov       qword ptr [rsp + 0x50], rcx
0x00014289abb5:  4889742448            mov       qword ptr [rsp + 0x48], rsi
0x00014289abba:  488d8d20010000        lea       rcx, [rbp + 0x120]
0x00014289abc1:  48894c2438            mov       qword ptr [rsp + 0x38], rcx
0x00014289abc6:  4489442430            mov       dword ptr [rsp + 0x30], r8d
0x00014289abcb:  488d4c2474            lea       rcx, [rsp + 0x74]
0x00014289abd0:  48894c2420            mov       qword ptr [rsp + 0x20], rcx
0x00014289abd5:  4c8bc8                mov       r9, rax
0x00014289abd8:  488d95d0010000        lea       rdx, [rbp + 0x1d0]
0x00014289abdf:  488bcf                mov       rcx, rdi
0x00014289abe2:  e809bcfeff            call      0x1428867f0
0x00014289abe7:  4c8bf0                mov       r14, rax
0x00014289abea:  488b0507fd4c05        mov       rax, qword ptr [rip + 0x54cfd07]
0x00014289abf1:  3c06                  cmp       al, 6
0x00014289abf3:  7240                  jb        0x14289ac35
0x00014289abf5:  48c1e808              shr       rax, 8
0x00014289abf9:  3c03                  cmp       al, 3
0x00014289abfb:  7238                  jb        0x14289ac35
0x00014289abfd:  488d056a71d406        lea       rax, [rip + 0x6d4716a]
0x00014289ac04:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x00014289ac09:  488b542478            mov       rdx, qword ptr [rsp + 0x78]
0x00014289ac0e:  488d150bed6904        lea       rdx, [rip + 0x469ed0b]
0x00014289ac15:  0f1005dcfc4c05        movups    xmm0, xmmword ptr [rip + 0x54cfcdc]
0x00014289ac1c:  0f298530010000        movaps    xmmword ptr [rbp + 0x130], xmm0
0x00014289ac23:  4c8bce                mov       r9, rsi
0x00014289ac26:  4d8bc5                mov       r8, r13
0x00014289ac29:  488d8d30010000        lea       rcx, [rbp + 0x130]
0x00014289ac30:  e85b4c0c02            call      0x14495f890
0x00014289ac35:  807c247401            cmp       byte ptr [rsp + 0x74], 1
0x00014289ac3a:  0f8585000000          jne       0x14289acc5
0x00014289ac40:  488b05c9fe4c05        mov       rax, qword ptr [rip + 0x54cfec9]
0x00014289ac47:  3c06                  cmp       al, 6
0x00014289ac49:  724c                  jb        0x14289ac97
0x00014289ac4b:  48c1e808              shr       rax, 8
0x00014289ac4f:  3c03                  cmp       al, 3
0x00014289ac51:  7244                  jb        0x14289ac97
0x00014289ac53:  488d0578c0d406        lea       rax, [rip + 0x6d4c078]
0x00014289ac5a:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x00014289ac5f:  488b542478            mov       rdx, qword ptr [rsp + 0x78]
0x00014289ac64:  488d15c5ed6904        lea       rdx, [rip + 0x469edc5]
0x00014289ac6b:  0f10059efe4c05        movups    xmm0, xmmword ptr [rip + 0x54cfe9e]
0x00014289ac72:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x00014289ac76:  4533f6                xor       r14d, r14d
0x00014289ac79:  4c89742430            mov       qword ptr [rsp + 0x30], r14
0x00014289ac7e:  4c89742428            mov       qword ptr [rsp + 0x28], r14
0x00014289ac83:  4c89742420            mov       qword ptr [rsp + 0x20], r14
0x00014289ac88:  4533c9                xor       r9d, r9d
0x00014289ac8b:  4533c0                xor       r8d, r8d
0x00014289ac8e:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289ac92:  e889510c02            call      0x14495fe20
0x00014289ac97:  c644243001            mov       byte ptr [rsp + 0x30], 1
0x00014289ac9c:  488b8540140000        mov       rax, qword ptr [rbp + 0x1440]
0x00014289aca3:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x00014289aca8:  48895c2420            mov       qword ptr [rsp + 0x20], rbx
0x00014289acad:  4d8bcc                mov       r9, r12
0x00014289acb0:  4c8d4510              lea       r8, [rbp + 0x10]
0x00014289acb4:  b21a                  mov       dl, 0x1a
0x00014289acb6:  488bcf                mov       rcx, rdi
0x00014289acb9:  e8a21e0000            call      0x14289cb60
0x00014289acbe:  b301                  mov       bl, 1
0x00014289acc0:  e927040000            jmp       0x14289b0ec
0x00014289acc5:  488b5d20              mov       rbx, qword ptr [rbp + 0x20]
0x00014289acc9:  807b2b00              cmp       byte ptr [rbx + 0x2b], 0
0x00014289accd:  754b                  jne       0x14289ad1a
0x00014289accf:  4c8b4320              mov       r8, qword ptr [rbx + 0x20]
0x00014289acd3:  4d85c0                test      r8, r8
0x00014289acd6:  7442                  je        0x14289ad1a
0x00014289acd8:  807b2800              cmp       byte ptr [rbx + 0x28], 0
0x00014289acdc:  743c                  je        0x14289ad1a
0x00014289acde:  498d8040010000        lea       rax, [r8 + 0x140]
0x00014289ace5:  4d8d4820              lea       r9, [r8 + 0x20]
0x00014289ace9:  488d5360              lea       rdx, [rbx + 0x60]
0x00014289aced:  488d4b40              lea       rcx, [rbx + 0x40]
0x00014289acf1:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014289acf6:  e835610200            call      0x1428c0e30
0x00014289acfb:  85c0                  test      eax, eax
0x00014289acfd:  7417                  je        0x14289ad16
0x00014289acff:  33d2                  xor       edx, edx
0x00014289ad01:  488d4b20              lea       rcx, [rbx + 0x20]
0x00014289ad05:  e8862e0400            call      0x1428ddb90
0x00014289ad0a:  66c743290000          mov       word ptr [rbx + 0x29], 0
0x00014289ad10:  c6432b01              mov       byte ptr [rbx + 0x2b], 1
0x00014289ad14:  eb04                  jmp       0x14289ad1a
0x00014289ad16:  c6432a01              mov       byte ptr [rbx + 0x2a], 1
0x00014289ad1a:  0fb6742475            movzx     esi, byte ptr [rsp + 0x75]
0x00014289ad1f:  41bd01000000          mov       r13d, 1
0x00014289ad25:  40f6c602              test      sil, 2
0x00014289ad29:  7419                  je        0x14289ad44
0x00014289ad2b:  8b055b300d06          mov       eax, dword ptr [rip + 0x60d305b]
0x00014289ad31:  230565300d06          and       eax, dword ptr [rip + 0x60d3065]
0x00014289ad37:  23055b300d06          and       eax, dword ptr [rip + 0x60d305b]
0x00014289ad3d:  413bc5                cmp       eax, r13d
0x00014289ad40:  410f45f5              cmovne    esi, r13d
0x00014289ad44:  4080e67f              and       sil, 0x7f
0x00014289ad48:  4088742475            mov       byte ptr [rsp + 0x75], sil
0x00014289ad4d:  0f8589000000          jne       0x14289addc
0x00014289ad53:  488b05b6fd4c05        mov       rax, qword ptr [rip + 0x54cfdb6]
0x00014289ad5a:  3c06                  cmp       al, 6
0x00014289ad5c:  724c                  jb        0x14289adaa
0x00014289ad5e:  48c1e808              shr       rax, 8
0x00014289ad62:  3c03                  cmp       al, 3
0x00014289ad64:  7244                  jb        0x14289adaa
0x00014289ad66:  488d05a6bdd506        lea       rax, [rip + 0x6d5bda6]
0x00014289ad6d:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x00014289ad72:  488b542478            mov       rdx, qword ptr [rsp + 0x78]
0x00014289ad77:  488d1562ec6904        lea       rdx, [rip + 0x469ec62]
0x00014289ad7e:  0f10058bfd4c05        movups    xmm0, xmmword ptr [rip + 0x54cfd8b]
0x00014289ad85:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x00014289ad89:  4533f6                xor       r14d, r14d
0x00014289ad8c:  4c89742430            mov       qword ptr [rsp + 0x30], r14
0x00014289ad91:  4c89742428            mov       qword ptr [rsp + 0x28], r14
0x00014289ad96:  4c89742420            mov       qword ptr [rsp + 0x20], r14
0x00014289ad9b:  4533c9                xor       r9d, r9d
0x00014289ad9e:  4533c0                xor       r8d, r8d
0x00014289ada1:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289ada5:  e876500c02            call      0x14495fe20
0x00014289adaa:  c644243001            mov       byte ptr [rsp + 0x30], 1
0x00014289adaf:  488b8540140000        mov       rax, qword ptr [rbp + 0x1440]
0x00014289adb6:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x00014289adbb:  488b45e0              mov       rax, qword ptr [rbp - 0x20]
0x00014289adbf:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014289adc4:  4d8bcc                mov       r9, r12
0x00014289adc7:  4c8d4510              lea       r8, [rbp + 0x10]
0x00014289adcb:  b20b                  mov       dl, 0xb
0x00014289adcd:  488bcf                mov       rcx, rdi
0x00014289add0:  e88b1d0000            call      0x14289cb60
0x00014289add5:  32db                  xor       bl, bl
0x00014289add7:  e910030000            jmp       0x14289b0ec
0x00014289addc:  4088732d              mov       byte ptr [rbx + 0x2d], sil
0x00014289ade0:  488d1549fd4c05        lea       rdx, [rip + 0x54cfd49]
0x00014289ade7:  488d8d70080000        lea       rcx, [rbp + 0x870]
0x00014289adee:  e82d6af3fd            call      0x1407d1820
0x00014289adf3:  90                    nop       
0x00014289adf4:  488d05e9e96904        lea       rax, [rip + 0x469e9e9]
0x00014289adfb:  488945f0              mov       qword ptr [rbp - 0x10], rax
0x00014289adff:  48c745f806000000      mov       qword ptr [rbp - 8], 6
0x00014289ae07:  0f2845f0              movaps    xmm0, xmmword ptr [rbp - 0x10]
0x00014289ae0b:  660f7f8540010000      movdqa    xmmword ptr [rbp + 0x140], xmm0
0x00014289ae13:  40f6c602              test      sil, 2
0x00014289ae17:  488d050aec6904        lea       rax, [rip + 0x469ec0a]
0x00014289ae1e:  4c8d05b3e96904        lea       r8, [rip + 0x469e9b3]
0x00014289ae25:  4c0f45c0              cmovne    r8, rax
0x00014289ae29:  458bcd                mov       r9d, r13d
0x00014289ae2c:  488d9540010000        lea       rdx, [rbp + 0x140]
0x00014289ae33:  488d8d400b0000        lea       rcx, [rbp + 0xb40]
0x00014289ae3a:  e8218b6300            call      0x142ed3960
0x00014289ae3f:  488d8d480b0000        lea       rcx, [rbp + 0xb48]
0x00014289ae46:  e855906200            call      0x142ec3ea0
0x00014289ae4b:  803d2efb4c0500        cmp       byte ptr [rip + 0x54cfb2e], 0
0x00014289ae52:  7663                  jbe       0x14289aeb7
0x00014289ae54:  41b901040000          mov       r9d, 0x401
0x00014289ae5a:  4c8d85900f0000        lea       r8, [rbp + 0xf90]
0x00014289ae61:  b201                  mov       dl, 1
0x00014289ae63:  498bcc                mov       rcx, r12
0x00014289ae66:  e835a80000            call      0x1428a56a0
0x00014289ae6b:  488b050efb4c05        mov       rax, qword ptr [rip + 0x54cfb0e]
0x00014289ae72:  3c06                  cmp       al, 6
0x00014289ae74:  7241                  jb        0x14289aeb7
0x00014289ae76:  48c1e808              shr       rax, 8
0x00014289ae7a:  3c03                  cmp       al, 3
0x00014289ae7c:  7239                  jb        0x14289aeb7
0x00014289ae7e:  488d0524ccd606        lea       rax, [rip + 0x6d6cc24]
0x00014289ae85:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x00014289ae8a:  488b542478            mov       rdx, qword ptr [rsp + 0x78]
0x00014289ae8f:  488d15bae86904        lea       rdx, [rip + 0x469e8ba]
0x00014289ae96:  0f1005e3fa4c05        movups    xmm0, xmmword ptr [rip + 0x54cfae3]
0x00014289ae9d:  0f298550010000        movaps    xmmword ptr [rbp + 0x150], xmm0
0x00014289aea4:  4c8d85900f0000        lea       r8, [rbp + 0xf90]
0x00014289aeab:  488d8d50010000        lea       rcx, [rbp + 0x150]
0x00014289aeb2:  e829520c02            call      0x1449600e0
0x00014289aeb7:  488b07                mov       rax, qword ptr [rdi]
0x00014289aeba:  488bcf                mov       rcx, rdi
0x00014289aebd:  488b8008030000        mov       rax, qword ptr [rax + 0x308]
0x00014289aec4:  ff156e4e8a03          call      qword ptr [rip + 0x38a4e6e]
0x00014289aeca:  84c0                  test      al, al
0x00014289aecc:  0f84bd010000          je        0x14289b08f
0x00014289aed2:  488d8d60010000        lea       rcx, [rbp + 0x160]
0x00014289aed9:  e8b2850000            call      0x1428a3490
0x00014289aede:  488bd0                mov       rdx, rax
0x00014289aee1:  498d8e80160000        lea       rcx, [r14 + 0x1680]
0x00014289aee8:  e883e9f7fd            call      0x140819870
0x00014289aeed:  488b8d68010000        mov       rcx, qword ptr [rbp + 0x168]
0x00014289aef4:  4885c9                test      rcx, rcx
0x00014289aef7:  7405                  je        0x14289aefe
0x00014289aef9:  e812e0f2fd            call      0x1407c8f10
0x00014289aefe:  0f57c0                xorps     xmm0, xmm0
0x00014289af01:  33c0                  xor       eax, eax
0x00014289af03:  0f1185d0000000        movups    xmmword ptr [rbp + 0xd0], xmm0
0x00014289af0a:  8885e0000000          mov       byte ptr [rbp + 0xe0], al
0x00014289af10:  488d95d0000000        lea       rdx, [rbp + 0xd0]
0x00014289af17:  498b8e80160000        mov       rcx, qword ptr [r14 + 0x1680]
0x00014289af1e:  e85daa9dff            call      0x142275980
0x00014289af23:  4889bdb0000000        mov       qword ptr [rbp + 0xb0], rdi
0x00014289af2a:  4c89b5b8000000        mov       qword ptr [rbp + 0xb8], r14
0x00014289af31:  488d0558844004        lea       rax, [rip + 0x4408458]
0x00014289af38:  488985f0010000        mov       qword ptr [rbp + 0x1f0], rax
0x00014289af3f:  0f2885b0000000        movaps    xmm0, xmmword ptr [rbp + 0xb0]
0x00014289af46:  0f1185f8010000        movups    xmmword ptr [rbp + 0x1f8], xmm0
0x00014289af4d:  488d85f0010000        lea       rax, [rbp + 0x1f0]
0x00014289af54:  48898528020000        mov       qword ptr [rbp + 0x228], rax
0x00014289af5b:  488d95f0010000        lea       rdx, [rbp + 0x1f0]
0x00014289af62:  498b8e80160000        mov       rcx, qword ptr [r14 + 0x1680]
0x00014289af69:  e882aa9dff            call      0x1422759f0
0x00014289af6e:  4c8b6d50              mov       r13, qword ptr [rbp + 0x50]
0x00014289af72:  41f6450301            test      byte ptr [r13 + 3], 1
0x00014289af77:  0f8416010000          je        0x14289b093
0x00014289af7d:  498d7518              lea       rsi, [r13 + 0x18]
0x00014289af81:  450fb74546            movzx     r8d, word ptr [r13 + 0x46]
0x00014289af86:  488bd6                mov       rdx, rsi
0x00014289af89:  498b8e80160000        mov       rcx, qword ptr [r14 + 0x1680]
0x00014289af90:  e89bab9dff            call      0x142275b30
0x00014289af95:  488b05ccfb4c05        mov       rax, qword ptr [rip + 0x54cfbcc]
0x00014289af9c:  3c06                  cmp       al, 6
0x00014289af9e:  0f82a4000000          jb        0x14289b048
0x00014289afa4:  48c1e808              shr       rax, 8
0x00014289afa8:  3c06                  cmp       al, 6
0x00014289afaa:  0f8298000000          jb        0x14289b048
0x00014289afb0:  488d057eefd806        lea       rax, [rip + 0x6d8ef7e]
0x00014289afb7:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x00014289afbc:  488b442478            mov       rax, qword ptr [rsp + 0x78]
0x00014289afc1:  48055bf890fd          add       rax, -0x26f07a5
0x00014289afc7:  488945d0              mov       qword ptr [rbp - 0x30], rax
0x00014289afcb:  0f1f440000            nop       dword ptr [rax + rax]
0x00014289afd0:  49ffc7                inc       r15
0x00014289afd3:  42803c3800            cmp       byte ptr [rax + r15], 0
0x00014289afd8:  75f6                  jne       0x14289afd0
0x00014289afda:  4c897dd8              mov       qword ptr [rbp - 0x28], r15
0x00014289afde:  48897590              mov       qword ptr [rbp - 0x70], rsi
0x00014289afe2:  410fb74546            movzx     eax, word ptr [r13 + 0x46]
0x00014289afe7:  894550                mov       dword ptr [rbp + 0x50], eax
0x00014289afea:  0f104590              movups    xmm0, xmmword ptr [rbp - 0x70]
0x00014289afee:  0f118510030000        movups    xmmword ptr [rbp + 0x310], xmm0
0x00014289aff5:  0f104d50              movups    xmm1, xmmword ptr [rbp + 0x50]
0x00014289aff9:  0f118d20030000        movups    xmmword ptr [rbp + 0x320], xmm1
0x00014289b000:  48c745402c000000      mov       qword ptr [rbp + 0x40], 0x2c
0x00014289b008:  488d8510030000        lea       rax, [rbp + 0x310]
0x00014289b00f:  48894548              mov       qword ptr [rbp + 0x48], rax
0x00014289b013:  0f284540              movaps    xmm0, xmmword ptr [rbp + 0x40]
0x00014289b017:  660f7f4590            movdqa    xmmword ptr [rbp - 0x70], xmm0
0x00014289b01c:  0f284dd0              movaps    xmm1, xmmword ptr [rbp - 0x30]
0x00014289b020:  660f7f4d40            movdqa    xmmword ptr [rbp + 0x40], xmm1
0x00014289b025:  0f10053cfb4c05        movups    xmm0, xmmword ptr [rip + 0x54cfb3c]
0x00014289b02c:  0f2945d0              movaps    xmmword ptr [rbp - 0x30], xmm0
0x00014289b030:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x00014289b035:  4c8d4d90              lea       r9, [rbp - 0x70]
0x00014289b039:  4c8d4540              lea       r8, [rbp + 0x40]
0x00014289b03d:  b206                  mov       dl, 6
0x00014289b03f:  488d4dd0              lea       rcx, [rbp - 0x30]
0x00014289b043:  e8884a0c02            call      0x14495fad0
0x00014289b048:  410f100424            movups    xmm0, xmmword ptr [r12]
0x00014289b04d:  410f1186a8130000      movups    xmmword ptr [r14 + 0x13a8], xmm0
0x00014289b055:  f2410f104c2410        movsd     xmm1, qword ptr [r12 + 0x10]
0x00014289b05c:  f2410f118eb8130000    movsd     qword ptr [r14 + 0x13b8], xmm1
0x00014289b065:  418b442418            mov       eax, dword ptr [r12 + 0x18]
0x00014289b06a:  418986c0130000        mov       dword ptr [r14 + 0x13c0], eax
0x00014289b071:  410fb744241e          movzx     eax, word ptr [r12 + 0x1e]
0x00014289b077:  66418986c6130000      mov       word ptr [r14 + 0x13c6], ax
0x00014289b07f:  410fb744241c          movzx     eax, word ptr [r12 + 0x1c]
0x00014289b085:  66418986c4130000      mov       word ptr [r14 + 0x13c4], ax
0x00014289b08d:  eb04                  jmp       0x14289b093
0x00014289b08f:  4c8b6d50              mov       r13, qword ptr [rbp + 0x50]
0x00014289b093:  803d5e33a10500        cmp       byte ptr [rip + 0x5a1335e], 0
0x00014289b09a:  7508                  jne       0x14289b0a4
0x00014289b09c:  41c6867116000009      mov       byte ptr [r14 + 0x1671], 9
0x00014289b0a4:  4c896c2430            mov       qword ptr [rsp + 0x30], r13
0x00014289b0a9:  488b8540140000        mov       rax, qword ptr [rbp + 0x1440]
0x00014289b0b0:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x00014289b0b5:  488b45e0              mov       rax, qword ptr [rbp - 0x20]
0x00014289b0b9:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014289b0be:  4c8b4d60              mov       r9, qword ptr [rbp + 0x60]
0x00014289b0c2:  4d8bc4                mov       r8, r12
0x00014289b0c5:  498bd6                mov       rdx, r14
0x00014289b0c8:  488bcf                mov       rcx, rdi
0x00014289b0cb:  e830020000            call      0x14289b300
0x00014289b0d0:  0fb6d8                movzx     ebx, al
0x00014289b0d3:  488d8d400b0000        lea       rcx, [rbp + 0xb40]
0x00014289b0da:  e85165f3fd            call      0x1407d1630
0x00014289b0df:  488d8d98080000        lea       rcx, [rbp + 0x898]
0x00014289b0e6:  e8f5a8f4fd            call      0x1407e59e0
0x00014289b0eb:  90                    nop       
0x00014289b0ec:  488d8d00060000        lea       rcx, [rbp + 0x600]
0x00014289b0f3:  e8f827f6fd            call      0x1407fd8f0
0x00014289b0f8:  90                    nop       
0x00014289b0f9:  488d05c88b4004        lea       rax, [rip + 0x4408bc8]
0x00014289b100:  48898560040000        mov       qword ptr [rbp + 0x460], rax
0x00014289b107:  80bd8804000000        cmp       byte ptr [rbp + 0x488], 0
0x00014289b10e:  7432                  je        0x14289b142
0x00014289b110:  8b8574040000          mov       eax, dword ptr [rbp + 0x474]
0x00014289b116:  3d00080000            cmp       eax, 0x800
0x00014289b11b:  7609                  jbe       0x14289b126
0x00014289b11d:  488b8d80040000        mov       rcx, qword ptr [rbp + 0x480]
0x00014289b124:  eb17                  jmp       0x14289b13d
0x00014289b126:  85c0                  test      eax, eax
0x00014289b128:  7418                  je        0x14289b142
0x00014289b12a:  488d8589040000        lea       rax, [rbp + 0x489]
0x00014289b131:  488b8d80040000        mov       rcx, qword ptr [rbp + 0x480]
0x00014289b138:  483bc8                cmp       rcx, rax
0x00014289b13b:  7405                  je        0x14289b142
0x00014289b13d:  e86e7f0a02            call      0x1449430b0
0x00014289b142:  488d056fec3e04        lea       rax, [rip + 0x43eec6f]
0x00014289b149:  48898560040000        mov       qword ptr [rbp + 0x460], rax
0x00014289b150:  488b4d28              mov       rcx, qword ptr [rbp + 0x28]
0x00014289b154:  4885c9                test      rcx, rcx
0x00014289b157:  7406                  je        0x14289b15f
0x00014289b159:  e8b2ddf2fd            call      0x1407c8f10
0x00014289b15e:  90                    nop       
0x00014289b15f:  488b4d68              mov       rcx, qword ptr [rbp + 0x68]
0x00014289b163:  e8a8ddf2fd            call      0x1407c8f10
0x00014289b168:  0fb6c3                movzx     eax, bl
0x00014289b16b:  eb44                  jmp       0x14289b1b1
0x00014289b16d:  488b059cf94c05        mov       rax, qword ptr [rip + 0x54cf99c]
0x00014289b174:  3c06                  cmp       al, 6
0x00014289b176:  7237                  jb        0x14289b1af
0x00014289b178:  48c1e808              shr       rax, 8
0x00014289b17c:  3c03                  cmp       al, 3
0x00014289b17e:  722f                  jb        0x14289b1af
0x00014289b180:  488d05056ac106        lea       rax, [rip + 0x6c16a05]
0x00014289b187:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x00014289b18c:  488b542478            mov       rdx, qword ptr [rsp + 0x78]
0x00014289b191:  488d1528056a04        lea       rdx, [rip + 0x46a0528]
0x00014289b198:  0f100571f94c05        movups    xmm0, xmmword ptr [rip + 0x54cf971]
0x00014289b19f:  0f294590              movaps    xmmword ptr [rbp - 0x70], xmm0
0x00014289b1a3:  448bc3                mov       r8d, ebx
0x00014289b1a6:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289b1aa:  e8e1460c02            call      0x14495f890
0x00014289b1af:  32c0                  xor       al, al
0x00014289b1b1:  488b8da0130000        mov       rcx, qword ptr [rbp + 0x13a0]
0x00014289b1b8:  4833cc                xor       rcx, rsp
0x00014289b1bb:  e820642803            call      0x145b215e0
0x00014289b1c0:  4881c4b8140000        add       rsp, 0x14b8
0x00014289b1c7:  415f                  pop       r15
0x00014289b1c9:  415e                  pop       r14
0x00014289b1cb:  415d                  pop       r13
0x00014289b1cd:  415c                  pop       r12
0x00014289b1cf:  5f                    pop       rdi
0x00014289b1d0:  5e                    pop       rsi
0x00014289b1d1:  5b                    pop       rbx
0x00014289b1d2:  5d                    pop       rbp
0x00014289b1d3:  c3                    ret       
0x00014289b1d4:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289b1d8:  e813fcf1fd            call      0x1407badf0
0x00014289b1dd:  488d155cba4605        lea       rdx, [rip + 0x546ba5c]
0x00014289b1e4:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289b1e8:  e8637e2a03            call      0x145b43050
0x00014289b1ed:  90                    nop       
0x00014289b1ee:  8bc8                  mov       ecx, eax
0x00014289b1f0:  e88b8b2803            call      0x145b23d80
0x00014289b1f5:  90                    nop       
0x00014289b1f6:  e825632b03            call      0x145b51520
0x00014289b1fb:  cc                    int3      
0x00014289b1fc:  e81f632b03            call      0x145b51520
0x00014289b201:  cc                    int3      
0x00014289b202:  e819632b03            call      0x145b51520
0x00014289b207:  90                    nop       
0x00014289b208:  e813632b03            call      0x145b51520
0x00014289b20d:  cc                    int3      
0x00014289b20e:  e80d632b03            call      0x145b51520
0x00014289b213:  90                    nop       
0x00014289b214:  e807632b03            call      0x145b51520
0x00014289b219:  90                    nop       
0x00014289b21a:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289b21e:  e8cdfbf1fd            call      0x1407badf0
0x00014289b223:  488d1516ba4605        lea       rdx, [rip + 0x546ba16]
0x00014289b22a:  488d4d90              lea       rcx, [rbp - 0x70]
0x00014289b22e:  e81d7e2a03            call      0x145b43050
0x00014289b233:  cc                    int3      
0x00014289b234:  cc                    int3      
0x00014289b235:  cc                    int3      
0x00014289b236:  cc                    int3      
0x00014289b237:  cc                    int3      
0x00014289b238:  cc                    int3      
0x00014289b239:  cc                    int3      
0x00014289b23a:  cc                    int3      
0x00014289b23b:  cc                    int3      
0x00014289b23c:  cc                    int3      
0x00014289b23d:  cc                    int3      
0x00014289b23e:  cc                    int3      
0x00014289b23f:  cc                    int3      
