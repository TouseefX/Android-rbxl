; RakPeer vtable slot 33
; rva 0x2880f60
0x142880f60:  4883ec48             sub       rsp, 0x48
0x142880f64:  0f1002               movups    xmm0, xmmword ptr [rdx]
0x142880f67:  4533c0               xor       r8d, r8d
0x142880f6a:  0f104a10             movups    xmm1, xmmword ptr [rdx + 0x10]
0x142880f6e:  488d542420           lea       rdx, [rsp + 0x20]
0x142880f73:  0f29442420           movaps    xmmword ptr [rsp + 0x20], xmm0
0x142880f78:  0f294c2430           movaps    xmmword ptr [rsp + 0x30], xmm1
0x142880f7d:  e80e3b0000           call      0x142884a90
0x142880f82:  4883c448             add       rsp, 0x48
0x142880f86:  c3                   ret       
0x142880f87:  cc                   int3      
0x142880f88:  cc                   int3      
0x142880f89:  cc                   int3      
0x142880f8a:  cc                   int3      
0x142880f8b:  cc                   int3      
0x142880f8c:  cc                   int3      
0x142880f8d:  cc                   int3      
0x142880f8e:  cc                   int3      
0x142880f8f:  cc                   int3      
