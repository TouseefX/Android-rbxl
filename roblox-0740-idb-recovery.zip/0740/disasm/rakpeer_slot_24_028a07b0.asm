; RakPeer vtable slot 24
; rva 0x28a07b0
0x1428a07b0:  80b95110000000       cmp       byte ptr [rcx + 0x1051], 0
0x1428a07b7:  0f94c0               sete      al
0x1428a07ba:  fec0                 inc       al
0x1428a07bc:  c3                   ret       
0x1428a07bd:  cc                   int3      
0x1428a07be:  cc                   int3      
0x1428a07bf:  cc                   int3      
0x1428a07c0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x1428a07c5:  48896c2410           mov       qword ptr [rsp + 0x10], rbp
0x1428a07ca:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x1428a07cf:  57                   push      rdi
0x1428a07d0:  4883ec40             sub       rsp, 0x40
0x1428a07d4:  488bf2               mov       rsi, rdx
0x1428a07d7:  488bd9               mov       rbx, rcx
0x1428a07da:  488b4108             mov       rax, qword ptr [rcx + 8]
0x1428a07de:  482b01               sub       rax, qword ptr [rcx]
0x1428a07e1:  48c1f805             sar       rax, 5
0x1428a07e5:  483bd0               cmp       rdx, rax
0x1428a07e8:  0f84da000000         je        0x1428a08c8
0x1428a07ee:  48b8ffffffffffffff07 movabs    rax, 0x7ffffffffffffff
0x1428a07f8:  483bd0               cmp       rdx, rax
0x1428a07fb:  0f87dc000000         ja        0x1428a08dd
0x1428a0801:  4885d2               test      rdx, rdx
0x1428a0804:  7504                 jne       0x1428a080a
0x1428a0806:  33ed                 xor       ebp, ebp
0x1428a0808:  eb0f                 jmp       0x1428a0819
0x1428a080a:  488bce               mov       rcx, rsi
0x1428a080d:  48c1e105             shl       rcx, 5
0x1428a0811:  e8ba98f4fd           call      0x1407ea0d0
0x1428a0816:  488be8               mov       rbp, rax
0x1428a0819:  488b4320             mov       rax, qword ptr [rbx + 0x20]
0x1428a081d:  4885c0               test      rax, rax
0x1428a0820:  7505                 jne       0x1428a0827
0x1428a0822:  4533d2               xor       r10d, r10d
0x1428a0825:  eb04                 jmp       0x1428a082b
0x1428a0827:  4c8b5310             mov       r10, qword ptr [rbx + 0x10]
0x1428a082b:  48895c2420           mov       qword ptr [rsp + 0x20], rbx
0x1428a0830:  4c89542428           mov       qword ptr [rsp + 0x28], r10
0x1428a0835:  488bd6               mov       rdx, rsi
0x1428a0838:  483bc6               cmp       rax, rsi
0x1428a083b:  480f42d0             cmovb     rdx, rax
0x1428a083f:  488d4c2420           lea       rcx, [rsp + 0x20]
0x1428a0844:  e827050000           call      0x1428a0d70
0x1428a0849:  488b4808             mov       rcx, qword ptr [rax + 8]
0x1428a084d:  488bfd               mov       rdi, rbp
0x1428a0850:  4c3bd1               cmp       r10, rcx
0x1428a0853:  743f                 je        0x1428a0894
0x1428a0855:  498bc2               mov       rax, r10
0x1428a0858:  4885ff               test      rdi, rdi
0x1428a085b:  7413                 je        0x1428a0870
0x1428a085d:  410f1002             movups    xmm0, xmmword ptr [r10]
0x1428a0861:  0f1107               movups    xmmword ptr [rdi], xmm0
0x1428a0864:  410f104a10           movups    xmm1, xmmword ptr [r10 + 0x10]
0x1428a0869:  0f114f10             movups    xmmword ptr [rdi + 0x10], xmm1
0x1428a086d:  498bc2               mov       rax, r10
0x1428a0870:  4883c020             add       rax, 0x20
0x1428a0874:  483b4308             cmp       rax, qword ptr [rbx + 8]
0x1428a0878:  7503                 jne       0x1428a087d
0x1428a087a:  488b03               mov       rax, qword ptr [rbx]
0x1428a087d:  4883c720             add       rdi, 0x20
0x1428a0881:  4533d2               xor       r10d, r10d
0x1428a0884:  483b4318             cmp       rax, qword ptr [rbx + 0x18]
0x1428a0888:  4c0f45d0             cmovne    r10, rax
0x1428a088c:  498bc2               mov       rax, r10
0x1428a088f:  4c3bd1               cmp       r10, rcx
0x1428a0892:  75c4                 jne       0x1428a0858
0x1428a0894:  488bcb               mov       rcx, rbx
0x1428a0897:  e854040000           call      0x1428a0cf0
0x1428a089c:  488bc7               mov       rax, rdi
0x1428a089f:  482bc5               sub       rax, rbp
0x1428a08a2:  48c1f805             sar       rax, 5
0x1428a08a6:  48894320             mov       qword ptr [rbx + 0x20], rax
0x1428a08aa:  48892b               mov       qword ptr [rbx], rbp
0x1428a08ad:  48896b10             mov       qword ptr [rbx + 0x10], rbp
0x1428a08b1:  48c1e605             shl       rsi, 5
0x1428a08b5:  488d042e             lea       rax, [rsi + rbp]
0x1428a08b9:  48894308             mov       qword ptr [rbx + 8], rax
0x1428a08bd:  483bf8               cmp       rdi, rax
0x1428a08c0:  480f45ef             cmovne    rbp, rdi
0x1428a08c4:  48896b18             mov       qword ptr [rbx + 0x18], rbp
0x1428a08c8:  488b5c2450           mov       rbx, qword ptr [rsp + 0x50]
0x1428a08cd:  488b6c2458           mov       rbp, qword ptr [rsp + 0x58]
0x1428a08d2:  488b742460           mov       rsi, qword ptr [rsp + 0x60]
0x1428a08d7:  4883c440             add       rsp, 0x40
0x1428a08db:  5f                   pop       rdi
0x1428a08dc:  c3                   ret       
0x1428a08dd:  488d15e4705e04       lea       rdx, [rip + 0x45e70e4]
0x1428a08e4:  488d4c2420           lea       rcx, [rsp + 0x20]
0x1428a08e9:  e80204d6fe           call      0x141600cf0
0x1428a08ee:  90                   nop       
0x1428a08ef:  488bc8               mov       rcx, rax
0x1428a08f2:  e809d0d5fe           call      0x1415fd900
0x1428a08f7:  cc                   int3      
0x1428a08f8:  cc                   int3      
0x1428a08f9:  cc                   int3      
0x1428a08fa:  cc                   int3      
0x1428a08fb:  cc                   int3      
0x1428a08fc:  cc                   int3      
0x1428a08fd:  cc                   int3      
0x1428a08fe:  cc                   int3      
0x1428a08ff:  cc                   int3      
0x1428a0900:  48895c2410           mov       qword ptr [rsp + 0x10], rbx
0x1428a0905:  57                   push      rdi
0x1428a0906:  4881ece0000000       sub       rsp, 0xe0
0x1428a090d:  488b05dc2d4705       mov       rax, qword ptr [rip + 0x5472ddc]
0x1428a0914:  4833c4               xor       rax, rsp
0x1428a0917:  48898424d0000000     mov       qword ptr [rsp + 0xd0], rax
0x1428a091f:  488bf9               mov       rdi, rcx
0x1428a0922:  4883791800           cmp       qword ptr [rcx + 0x18], 0
0x1428a0927:  0f84d1000000         je        0x1428a09fe
0x1428a092d:  0f1f00               nop       dword ptr [rax]
0x1428a0930:  4c8b4710             mov       r8, qword ptr [rdi + 0x10]
0x1428a0934:  33d2                 xor       edx, edx
0x1428a0936:  498bc0               mov       rax, r8
0x1428a0939:  48f77708             div       qword ptr [rdi + 8]
0x1428a093d:  4c69d2a8000000       imul      r10, rdx, 0xa8
0x1428a0944:  4c0317               add       r10, qword ptr [rdi]
0x1428a0947:  498d4001             lea       rax, [r8 + 1]
0x1428a094b:  33d2                 xor       edx, edx
0x1428a094d:  48f77708             div       qword ptr [rdi + 8]
0x1428a0951:  48895710             mov       qword ptr [rdi + 0x10], rdx
0x1428a0955:  498bd2               mov       rdx, r10
0x1428a0958:  488d4c2420           lea       rcx, [rsp + 0x20]
0x1428a095d:  e8ce040000           call      0x1428a0e30
0x1428a0962:  498b5a08             mov       rbx, qword ptr [r10 + 8]
0x1428a0966:  4885db               test      rbx, rbx
0x1428a0969:  743d                 je        0x1428a09a8
0x1428a096b:  b8ffffffff           mov       eax, 0xffffffff
0x1428a0970:  f00fc14308           lock xadd dword ptr [rbx + 8], eax
0x1428a0975:  83f801               cmp       eax, 1
0x1428a0978:  752e                 jne       0x1428a09a8
0x1428a097a:  488b03               mov       rax, qword ptr [rbx]
0x1428a097d:  488bcb               mov       rcx, rbx
0x1428a0980:  488b00               mov       rax, qword ptr [rax]
0x1428a0983:  ff15aff38903         call      qword ptr [rip + 0x389f3af]
0x1428a0989:  b8ffffffff           mov       eax, 0xffffffff
0x1428a098e:  f00fc1430c           lock xadd dword ptr [rbx + 0xc], eax
0x1428a0993:  83f801               cmp       eax, 1
0x1428a0996:  7510                 jne       0x1428a09a8
0x1428a0998:  488b03               mov       rax, qword ptr [rbx]
0x1428a099b:  488bcb               mov       rcx, rbx
0x1428a099e:  488b4008             mov       rax, qword ptr [rax + 8]
0x1428a09a2:  ff1590f38903         call      qword ptr [rip + 0x389f390]
0x1428a09a8:  48ff4f18             dec       qword ptr [rdi + 0x18]
0x1428a09ac:  488b5c2428           mov       rbx, qword ptr [rsp + 0x28]
0x1428a09b1:  4885db               test      rbx, rbx
0x1428a09b4:  743d                 je        0x1428a09f3
0x1428a09b6:  b8ffffffff           mov       eax, 0xffffffff
0x1428a09bb:  f00fc14308           lock xadd dword ptr [rbx + 8], eax
0x1428a09c0:  83f801               cmp       eax, 1
0x1428a09c3:  752e                 jne       0x1428a09f3
0x1428a09c5:  488b03               mov       rax, qword ptr [rbx]
0x1428a09c8:  488bcb               mov       rcx, rbx
0x1428a09cb:  488b00               mov       rax, qword ptr [rax]
0x1428a09ce:  ff1564f38903         call      qword ptr [rip + 0x389f364]
0x1428a09d4:  b8ffffffff           mov       eax, 0xffffffff
0x1428a09d9:  f00fc1430c           lock xadd dword ptr [rbx + 0xc], eax
0x1428a09de:  83f801               cmp       eax, 1
0x1428a09e1:  7510                 jne       0x1428a09f3
0x1428a09e3:  488b03               mov       rax, qword ptr [rbx]
0x1428a09e6:  488bcb               mov       rcx, rbx
0x1428a09e9:  488b4008             mov       rax, qword ptr [rax + 8]
0x1428a09ed:  ff1545f38903         call      qword ptr [rip + 0x389f345]
0x1428a09f3:  48837f1800           cmp       qword ptr [rdi + 0x18], 0
0x1428a09f8:  0f8532ffffff         jne       0x1428a0930
0x1428a09fe:  488b0f               mov       rcx, qword ptr [rdi]
0x1428a0a01:  4885c9               test      rcx, rcx
0x1428a0a04:  7406                 je        0x1428a0a0c
0x1428a0a06:  e8a5260a02           call      0x1449430b0
0x1428a0a0b:  90                   nop       
0x1428a0a0c:  488b8c24d0000000     mov       rcx, qword ptr [rsp + 0xd0]
0x1428a0a14:  4833cc               xor       rcx, rsp
0x1428a0a17:  e8c40b2803           call      0x145b215e0
0x1428a0a1c:  488b9c24f8000000     mov       rbx, qword ptr [rsp + 0xf8]
0x1428a0a24:  4881c4e0000000       add       rsp, 0xe0
0x1428a0a2b:  5f                   pop       rdi
0x1428a0a2c:  c3                   ret       
0x1428a0a2d:  cc                   int3      
0x1428a0a2e:  cc                   int3      
0x1428a0a2f:  cc                   int3      
0x1428a0a30:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x1428a0a35:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x1428a0a3a:  57                   push      rdi
0x1428a0a3b:  4883ec20             sub       rsp, 0x20
0x1428a0a3f:  488bd9               mov       rbx, rcx
0x1428a0a42:  8b4908               mov       ecx, dword ptr [rcx + 8]
0x1428a0a45:  448b4310             mov       r8d, dword ptr [rbx + 0x10]
0x1428a0a49:  8d048d00000000       lea       eax, [rcx*4]
0x1428a0a50:  413bc0               cmp       eax, r8d
0x1428a0a53:  0f83a9000000         jae       0x1428a0b02
0x1428a0a59:  4183f840             cmp       r8d, 0x40
0x1428a0a5d:  0f869f000000         jbe       0x1428a0b02
0x1428a0a63:  33ff                 xor       edi, edi
0x1428a0a65:  8bf7                 mov       esi, edi
0x1428a0a67:  85c9                 test      ecx, ecx
0x1428a0a69:  742b                 je        0x1428a0a96
0x1428a0a6b:  83e901               sub       ecx, 1
0x1428a0a6e:  7505                 jne       0x1428a0a75
0x1428a0a70:  8d4f20               lea       ecx, [rdi + 0x20]
0x1428a0a73:  eb06                 jmp       0x1428a0a7b
0x1428a0a75:  0fbdc9               bsr       ecx, ecx
0x1428a0a78:  83f11f               xor       ecx, 0x1f
0x1428a0a7b:  b821000000           mov       eax, 0x21
0x1428a0a80:  2bc1                 sub       eax, ecx
0x1428a0a82:  ba01000000           mov       edx, 1
0x1428a0a87:  0fb6c8               movzx     ecx, al
0x1428a0a8a:  d3e2                 shl       edx, cl
0x1428a0a8c:  be40000000           mov       esi, 0x40
0x1428a0a91:  3bd6                 cmp       edx, esi
0x1428a0a93:  0f4ff2               cmovg     esi, edx
0x1428a0a96:  4c8b0b               mov       r9, qword ptr [rbx]
0x1428a0a99:  413bf0               cmp       esi, r8d
0x1428a0a9c:  7542                 jne       0x1428a0ae0
0x1428a0a9e:  48897b08             mov       qword ptr [rbx + 8], rdi
0x1428a0aa2:  4b8d0cc1             lea       rcx, [r9 + r8*8]
0x1428a0aa6:  4e8d04c507000000     lea       r8, [r8*8 + 7]
0x1428a0aae:  49c1e803             shr       r8, 3
0x1428a0ab2:  4c3bc9               cmp       r9, rcx
0x1428a0ab5:  4c0f47c7             cmova     r8, rdi
0x1428a0ab9:  4d85c0               test      r8, r8
0x1428a0abc:  747f                 je        0x1428a0b3d
0x1428a0abe:  49c1e003             shl       r8, 3
0x1428a0ac2:  48c7c2ffffffff       mov       rdx, 0xffffffffffffffff
0x1428a0ac9:  498bc9               mov       rcx, r9
0x1428a0acc:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x1428a0ad1:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x1428a0ad6:  4883c420             add       rsp, 0x20
0x1428a0ada:  5f                   pop       rdi
0x1428a0adb:  e9e0162a03           jmp       0x145b421c0
0x1428a0ae0:  498bc9               mov       rcx, r9
0x1428a0ae3:  e8c8250a02           call      0x1449430b0
0x1428a0ae8:  90                   nop       
0x1428a0ae9:  8bd6                 mov       edx, esi
0x1428a0aeb:  488bcb               mov       rcx, rbx
0x1428a0aee:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x1428a0af3:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x1428a0af8:  4883c420             add       rsp, 0x20
0x1428a0afc:  5f                   pop       rdi
0x1428a0afd:  e9eef133ff           jmp       0x141bdfcf0
0x1428a0b02:  85c9                 test      ecx, ecx
0x1428a0b04:  7505                 jne       0x1428a0b0b
0x1428a0b06:  394b0c               cmp       dword ptr [rbx + 0xc], ecx
0x1428a0b09:  7432                 je        0x1428a0b3d
0x1428a0b0b:  488b0b               mov       rcx, qword ptr [rbx]
0x1428a0b0e:  4a8d14c1             lea       rdx, [rcx + r8*8]
0x1428a0b12:  4e8d04c507000000     lea       r8, [r8*8 + 7]
0x1428a0b1a:  49c1e803             shr       r8, 3
0x1428a0b1e:  33ff                 xor       edi, edi
0x1428a0b20:  483bca               cmp       rcx, rdx
0x1428a0b23:  4c0f47c7             cmova     r8, rdi
0x1428a0b27:  4d85c0               test      r8, r8
0x1428a0b2a:  740d                 je        0x1428a0b39
0x1428a0b2c:  49c1e003             shl       r8, 3
0x1428a0b30:  488d57ff             lea       rdx, [rdi - 1]
0x1428a0b34:  e887162a03           call      0x145b421c0
0x1428a0b39:  48897b08             mov       qword ptr [rbx + 8], rdi
0x1428a0b3d:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x1428a0b42:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x1428a0b47:  4883c420             add       rsp, 0x20
0x1428a0b4b:  5f                   pop       rdi
0x1428a0b4c:  c3                   ret       
0x1428a0b4d:  cc                   int3      
0x1428a0b4e:  cc                   int3      
0x1428a0b4f:  cc                   int3      
