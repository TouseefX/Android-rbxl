; RakPeer vtable slot 4
; rva 0x287cff0
0x14287cff0:  48895c2410           mov       qword ptr [rsp + 0x10], rbx
0x14287cff5:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x14287cffa:  57                   push      rdi
0x14287cffb:  4883ec20             sub       rsp, 0x20
0x14287cfff:  488bf2               mov       rsi, rdx
0x14287d002:  488bd9               mov       rbx, rcx
0x14287d005:  4881c188080000       add       rcx, 0x888
0x14287d00c:  e89f672a03           call      0x145b237b0
0x14287d011:  85c0                 test      eax, eax
0x14287d013:  7544                 jne       0x14287d059
0x14287d015:  488bd6               mov       rdx, rsi
0x14287d018:  488d4c2430           lea       rcx, [rsp + 0x30]
0x14287d01d:  e8fec50300           call      0x1428b9620
0x14287d022:  90                   nop       
0x14287d023:  488bd0               mov       rdx, rax
0x14287d026:  488d8b80090000       lea       rcx, [rbx + 0x980]
0x14287d02d:  e83e570200           call      0x1428a2770
0x14287d032:  90                   nop       
0x14287d033:  488d4c2430           lea       rcx, [rsp + 0x30]
0x14287d038:  e8d3cb0300           call      0x1428b9c10
0x14287d03d:  90                   nop       
0x14287d03e:  488d8b88080000       lea       rcx, [rbx + 0x888]
0x14287d045:  488b5c2438           mov       rbx, qword ptr [rsp + 0x38]
0x14287d04a:  488b742440           mov       rsi, qword ptr [rsp + 0x40]
0x14287d04f:  4883c420             add       rsp, 0x20
0x14287d053:  5f                   pop       rdi
0x14287d054:  e9b7672a03           jmp       0x145b23810
0x14287d059:  8bc8                 mov       ecx, eax
0x14287d05b:  e8206d2a03           call      0x145b23d80
0x14287d060:  cc                   int3      
0x14287d061:  cc                   int3      
0x14287d062:  cc                   int3      
0x14287d063:  cc                   int3      
0x14287d064:  cc                   int3      
0x14287d065:  cc                   int3      
0x14287d066:  cc                   int3      
0x14287d067:  cc                   int3      
0x14287d068:  cc                   int3      
0x14287d069:  cc                   int3      
0x14287d06a:  cc                   int3      
0x14287d06b:  cc                   int3      
0x14287d06c:  cc                   int3      
0x14287d06d:  cc                   int3      
0x14287d06e:  cc                   int3      
0x14287d06f:  cc                   int3      
0x14287d070:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x14287d075:  48896c2410           mov       qword ptr [rsp + 0x10], rbp
0x14287d07a:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x14287d07f:  48897c2420           mov       qword ptr [rsp + 0x20], rdi
0x14287d084:  4155                 push      r13
0x14287d086:  4156                 push      r14
0x14287d088:  4157                 push      r15
0x14287d08a:  4883ec20             sub       rsp, 0x20
0x14287d08e:  4c8bf2               mov       r14, rdx
0x14287d091:  488bf1               mov       rsi, rcx
0x14287d094:  83b98809000000       cmp       dword ptr [rcx + 0x988], 0
0x14287d09b:  7473                 je        0x14287d110
0x14287d09d:  4881c188080000       add       rcx, 0x888
0x14287d0a4:  4885d2               test      rdx, rdx
0x14287d0a7:  0f8582000000         jne       0x14287d12f
0x14287d0ad:  e8fe662a03           call      0x145b237b0
0x14287d0b2:  85c0                 test      eax, eax
0x14287d0b4:  0f85f5010000         jne       0x14287d2af
0x14287d0ba:  39868c090000         cmp       dword ptr [rsi + 0x98c], eax
0x14287d0c0:  7442                 je        0x14287d104
0x14287d0c2:  488b8e80090000       mov       rcx, qword ptr [rsi + 0x980]
0x14287d0c9:  4885c9               test      rcx, rcx
0x14287d0cc:  7420                 je        0x14287d0ee
0x14287d0ce:  488d59f8             lea       rbx, [rcx - 8]
0x14287d0d2:  4c8d0d77c50300       lea       r9, [rip + 0x3c577]
0x14287d0d9:  4c8b03               mov       r8, qword ptr [rbx]
0x14287d0dc:  8d5008               lea       edx, [rax + 8]
0x14287d0df:  e8cc452a03           call      0x145b216b0
0x14287d0e4:  90                   nop       
0x14287d0e5:  488bcb               mov       rcx, rbx
0x14287d0e8:  e8c35f0c02           call      0x1449430b0
0x14287d0ed:  90                   nop       
0x14287d0ee:  48c7868809000000000000 mov       qword ptr [rsi + 0x988], 0
0x14287d0f9:  48c7868009000000000000 mov       qword ptr [rsi + 0x980], 0
0x14287d104:  488d8e88080000       lea       rcx, [rsi + 0x888]
0x14287d10b:  e800672a03           call      0x145b23810
0x14287d110:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x14287d115:  488b6c2448           mov       rbp, qword ptr [rsp + 0x48]
0x14287d11a:  488b742450           mov       rsi, qword ptr [rsp + 0x50]
0x14287d11f:  488b7c2458           mov       rdi, qword ptr [rsp + 0x58]
0x14287d124:  4883c420             add       rsp, 0x20
0x14287d128:  415f                 pop       r15
0x14287d12a:  415e                 pop       r14
0x14287d12c:  415d                 pop       r13
0x14287d12e:  c3                   ret       
0x14287d12f:  4533ff               xor       r15d, r15d
0x14287d132:  e879662a03           call      0x145b237b0
0x14287d137:  85c0                 test      eax, eax
0x14287d139:  0f8560010000         jne       0x14287d29f
0x14287d13f:  448b8e88090000       mov       r9d, dword ptr [rsi + 0x988]
0x14287d146:  4585c9               test      r9d, r9d
0x14287d149:  74b9                 je        0x14287d104
0x14287d14b:  0f1f440000           nop       dword ptr [rax + rax]
0x14287d150:  4e8d04fd00000000     lea       r8, [r15*8]
0x14287d158:  410fb60e             movzx     ecx, byte ptr [r14]
0x14287d15c:  84c9                 test      cl, cl
0x14287d15e:  0f8423010000         je        0x14287d287
0x14287d164:  48c7c0ffffffff       mov       rax, 0xffffffffffffffff
0x14287d16b:  0f1f440000           nop       dword ptr [rax + rax]
0x14287d170:  48ffc0               inc       rax
0x14287d173:  41803c0600           cmp       byte ptr [r14 + rax], 0
0x14287d178:  75f6                 jne       0x14287d170
0x14287d17a:  4883f80f             cmp       rax, 0xf
0x14287d17e:  0f8703010000         ja        0x14287d287
0x14287d184:  33d2                 xor       edx, edx
0x14287d186:  4c8b9680090000       mov       r10, qword ptr [rsi + 0x980]
0x14287d18d:  4f8d1c02             lea       r11, [r10 + r8]
0x14287d191:  498b03               mov       rax, qword ptr [r11]
0x14287d194:  4c8b4020             mov       r8, qword ptr [rax + 0x20]
0x14287d198:  413808               cmp       byte ptr [r8], cl
0x14287d19b:  7514                 jne       0x14287d1b1
0x14287d19d:  0f1f00               nop       dword ptr [rax]
0x14287d1a0:  84c9                 test      cl, cl
0x14287d1a2:  7430                 je        0x14287d1d4
0x14287d1a4:  ffc2                 inc       edx
0x14287d1a6:  420fb60c32           movzx     ecx, byte ptr [rdx + r14]
0x14287d1ab:  41380c10             cmp       byte ptr [r8 + rdx], cl
0x14287d1af:  74ef                 je        0x14287d1a0
0x14287d1b1:  8bc2                 mov       eax, edx
0x14287d1b3:  410fb61410           movzx     edx, byte ptr [r8 + rdx]
0x14287d1b8:  84d2                 test      dl, dl
0x14287d1ba:  0f84c7000000         je        0x14287d287
0x14287d1c0:  42803c3000           cmp       byte ptr [rax + r14], 0
0x14287d1c5:  0f84bc000000         je        0x14287d287
0x14287d1cb:  80fa2a               cmp       dl, 0x2a
0x14287d1ce:  0f85b3000000         jne       0x14287d287
0x14287d1d4:  418d41ff             lea       eax, [r9 - 1]
0x14287d1d8:  498d14c2             lea       rdx, [r10 + rax*8]
0x14287d1dc:  498bcb               mov       rcx, r11
0x14287d1df:  e87cc40300           call      0x1428b9660
0x14287d1e4:  8b9688090000         mov       edx, dword ptr [rsi + 0x988]
0x14287d1ea:  ffca                 dec       edx
0x14287d1ec:  8b8e88090000         mov       ecx, dword ptr [rsi + 0x988]
0x14287d1f2:  3bd1                 cmp       edx, ecx
0x14287d1f4:  0f8390000000         jae       0x14287d28a
0x14287d1fa:  8d41ff               lea       eax, [rcx - 1]
0x14287d1fd:  3bd0                 cmp       edx, eax
0x14287d1ff:  737b                 jae       0x14287d27c
0x14287d201:  0f1f4000             nop       dword ptr [rax]
0x14287d205:  6666660f1f840000000000 nop       word ptr [rax + rax]
0x14287d210:  8d6a01               lea       ebp, [rdx + 1]
0x14287d213:  488b8e80090000       mov       rcx, qword ptr [rsi + 0x980]
0x14287d21a:  488d3ce9             lea       rdi, [rcx + rbp*8]
0x14287d21e:  8bc2                 mov       eax, edx
0x14287d220:  488d1cc1             lea       rbx, [rcx + rax*8]
0x14287d224:  488bcb               mov       rcx, rbx
0x14287d227:  e8e4c90300           call      0x1428b9c10
0x14287d22c:  488b0f               mov       rcx, qword ptr [rdi]
0x14287d22f:  488d058a454a05       lea       rax, [rip + 0x54a458a]
0x14287d236:  483bc8               cmp       rcx, rax
0x14287d239:  7432                 je        0x14287d26d
0x14287d23b:  488b09               mov       rcx, qword ptr [rcx]
0x14287d23e:  e86d652a03           call      0x145b237b0
0x14287d243:  85c0                 test      eax, eax
0x14287d245:  7560                 jne       0x14287d2a7
0x14287d247:  488b07               mov       rax, qword ptr [rdi]
0x14287d24a:  83780800             cmp       dword ptr [rax + 8], 0
0x14287d24e:  750c                 jne       0x14287d25c
0x14287d250:  488d0569454a05       lea       rax, [rip + 0x54a4569]
0x14287d257:  488903               mov       qword ptr [rbx], rax
0x14287d25a:  eb06                 jmp       0x14287d262
0x14287d25c:  488903               mov       qword ptr [rbx], rax
0x14287d25f:  ff4008               inc       dword ptr [rax + 8]
0x14287d262:  488b0f               mov       rcx, qword ptr [rdi]
0x14287d265:  488b09               mov       rcx, qword ptr [rcx]
0x14287d268:  e8a3652a03           call      0x145b23810
0x14287d26d:  8bd5                 mov       edx, ebp
0x14287d26f:  8b8e88090000         mov       ecx, dword ptr [rsi + 0x988]
0x14287d275:  8d41ff               lea       eax, [rcx - 1]
0x14287d278:  3be8                 cmp       ebp, eax
0x14287d27a:  7294                 jb        0x14287d210
0x14287d27c:  8d41ff               lea       eax, [rcx - 1]
0x14287d27f:  898688090000         mov       dword ptr [rsi + 0x988], eax
0x14287d285:  eb03                 jmp       0x14287d28a
0x14287d287:  41ffc7               inc       r15d
0x14287d28a:  448b8e88090000       mov       r9d, dword ptr [rsi + 0x988]
0x14287d291:  453bf9               cmp       r15d, r9d
0x14287d294:  0f836afeffff         jae       0x14287d104
0x14287d29a:  e9b1feffff           jmp       0x14287d150
0x14287d29f:  8bc8                 mov       ecx, eax
0x14287d2a1:  e8da6a2a03           call      0x145b23d80
0x14287d2a6:  cc                   int3      
0x14287d2a7:  8bc8                 mov       ecx, eax
0x14287d2a9:  e8d26a2a03           call      0x145b23d80
0x14287d2ae:  cc                   int3      
0x14287d2af:  8bc8                 mov       ecx, eax
0x14287d2b1:  e8ca6a2a03           call      0x145b23d80
0x14287d2b6:  cc                   int3      
0x14287d2b7:  cc                   int3      
0x14287d2b8:  cc                   int3      
0x14287d2b9:  cc                   int3      
0x14287d2ba:  cc                   int3      
0x14287d2bb:  cc                   int3      
0x14287d2bc:  cc                   int3      
0x14287d2bd:  cc                   int3      
0x14287d2be:  cc                   int3      
0x14287d2bf:  cc                   int3      
0x14287d2c0:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x14287d2c5:  57                   push      rdi
0x14287d2c6:  4883ec20             sub       rsp, 0x20
0x14287d2ca:  83b98809000000       cmp       dword ptr [rcx + 0x988], 0
0x14287d2d1:  488bda               mov       rbx, rdx
0x14287d2d4:  488bf9               mov       rdi, rcx
0x14287d2d7:  750d                 jne       0x14287d2e6
0x14287d2d9:  32c0                 xor       al, al
0x14287d2db:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x14287d2e0:  4883c420             add       rsp, 0x20
0x14287d2e4:  5f                   pop       rdi
0x14287d2e5:  c3                   ret       
0x14287d2e6:  48896c2430           mov       qword ptr [rsp + 0x30], rbp
0x14287d2eb:  4881c188080000       add       rcx, 0x888
0x14287d2f2:  4889742438           mov       qword ptr [rsp + 0x38], rsi
0x14287d2f7:  33f6                 xor       esi, esi
0x14287d2f9:  e8b2642a03           call      0x145b237b0
0x14287d2fe:  85c0                 test      eax, eax
0x14287d300:  0f85ad000000         jne       0x14287d3b3
0x14287d306:  448b9788090000       mov       r10d, dword ptr [rdi + 0x988]
0x14287d30d:  4585d2               test      r10d, r10d
0x14287d310:  746e                 je        0x14287d380
0x14287d312:  4c8b9f80090000       mov       r11, qword ptr [rdi + 0x980]
0x14287d319:  0f1f8000000000       nop       dword ptr [rax]
0x14287d320:  4885db               test      rbx, rbx
0x14287d323:  7454                 je        0x14287d379
0x14287d325:  0fb603               movzx     eax, byte ptr [rbx]
0x14287d328:  84c0                 test      al, al
0x14287d32a:  744d                 je        0x14287d379
0x14287d32c:  48c7c1ffffffff       mov       rcx, 0xffffffffffffffff
0x14287d333:  48ffc1               inc       rcx
0x14287d336:  803c0b00             cmp       byte ptr [rbx + rcx], 0
0x14287d33a:  75f7                 jne       0x14287d333
0x14287d33c:  4883f90f             cmp       rcx, 0xf
0x14287d340:  7737                 ja        0x14287d379
0x14287d342:  498b14f3             mov       rdx, qword ptr [r11 + rsi*8]
0x14287d346:  4533c0               xor       r8d, r8d
0x14287d349:  4c8b4a20             mov       r9, qword ptr [rdx + 0x20]
0x14287d34d:  413801               cmp       byte ptr [r9], al
0x14287d350:  7512                 jne       0x14287d364
0x14287d352:  84c0                 test      al, al
0x14287d354:  744d                 je        0x14287d3a3
0x14287d356:  41ffc0               inc       r8d
0x14287d359:  410fb60418           movzx     eax, byte ptr [r8 + rbx]
0x14287d35e:  43380401             cmp       byte ptr [r9 + r8], al
0x14287d362:  74ee                 je        0x14287d352
0x14287d364:  430fb60c01           movzx     ecx, byte ptr [r9 + r8]
0x14287d369:  84c9                 test      cl, cl
0x14287d36b:  740c                 je        0x14287d379
0x14287d36d:  41803c1800           cmp       byte ptr [r8 + rbx], 0
0x14287d372:  7405                 je        0x14287d379
0x14287d374:  80f92a               cmp       cl, 0x2a
0x14287d377:  742a                 je        0x14287d3a3
0x14287d379:  ffc6                 inc       esi
0x14287d37b:  413bf2               cmp       esi, r10d
0x14287d37e:  72a0                 jb        0x14287d320
0x14287d380:  488d8f88080000       lea       rcx, [rdi + 0x888]
0x14287d387:  e884642a03           call      0x145b23810
0x14287d38c:  32c0                 xor       al, al
0x14287d38e:  488b6c2430           mov       rbp, qword ptr [rsp + 0x30]
0x14287d393:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x14287d398:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x14287d39d:  4883c420             add       rsp, 0x20
0x14287d3a1:  5f                   pop       rdi
0x14287d3a2:  c3                   ret       
0x14287d3a3:  488d8f88080000       lea       rcx, [rdi + 0x888]
0x14287d3aa:  e861642a03           call      0x145b23810
0x14287d3af:  b001                 mov       al, 1
0x14287d3b1:  ebdb                 jmp       0x14287d38e
0x14287d3b3:  8bc8                 mov       ecx, eax
0x14287d3b5:  e8c6692a03           call      0x145b23d80
0x14287d3ba:  cc                   int3      
0x14287d3bb:  cc                   int3      
0x14287d3bc:  cc                   int3      
0x14287d3bd:  cc                   int3      
0x14287d3be:  cc                   int3      
0x14287d3bf:  cc                   int3      
