; RakPeer vtable slot 21
; rva 0x287fda0
0x14287fda0:  4053                 push      rbx
0x14287fda2:  4154                 push      r12
0x14287fda4:  4155                 push      r13
0x14287fda6:  4156                 push      r14
0x14287fda8:  4157                 push      r15
0x14287fdaa:  4881ecb0000000       sub       rsp, 0xb0
0x14287fdb1:  488b0538394905       mov       rax, qword ptr [rip + 0x5493938]
0x14287fdb8:  4833c4               xor       rax, rsp
0x14287fdbb:  4889842498000000     mov       qword ptr [rsp + 0x98], rax
0x14287fdc3:  488b02               mov       rax, qword ptr [rdx]
0x14287fdc6:  4c8bf1               mov       r14, rcx
0x14287fdc9:  488b9c2408010000     mov       rbx, qword ptr [rsp + 0x108]
0x14287fdd1:  488bca               mov       rcx, rdx
0x14287fdd4:  458be9               mov       r13d, r9d
0x14287fdd7:  4489842490000000     mov       dword ptr [rsp + 0x90], r8d
0x14287fddf:  4c8bfa               mov       r15, rdx
0x14287fde2:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x14287fde6:  ff154cff8b03         call      qword ptr [rip + 0x38bff4c]
0x14287fdec:  85c0                 test      eax, eax
0x14287fdee:  0f84fa010000         je        0x14287ffee
0x14287fdf4:  4983be5003000000     cmp       qword ptr [r14 + 0x350], 0
0x14287fdfc:  0f84ec010000         je        0x14287ffee
0x14287fe02:  410fb68608010000     movzx     eax, byte ptr [r14 + 0x108]
0x14287fe0a:  90                   nop       
0x14287fe0b:  3c01                 cmp       al, 1
0x14287fe0d:  0f84db010000         je        0x14287ffee
0x14287fe13:  440fb6a42410010000   movzx     r12d, byte ptr [rsp + 0x110]
0x14287fe1c:  4584e4               test      r12b, r12b
0x14287fe1f:  7510                 jne       0x14287fe31
0x14287fe21:  488bcb               mov       rcx, rbx
0x14287fe24:  e80790ffff           call      0x142878e30
0x14287fe29:  84c0                 test      al, al
0x14287fe2b:  0f85bd010000         jne       0x14287ffee
0x14287fe31:  4889ac24f8000000     mov       qword ptr [rsp + 0xf8], rbp
0x14287fe39:  8bac2418010000       mov       ebp, dword ptr [rsp + 0x118]
0x14287fe40:  85ed                 test      ebp, ebp
0x14287fe42:  7515                 jne       0x14287fe59
0x14287fe44:  498b06               mov       rax, qword ptr [r14]
0x14287fe47:  498bce               mov       rcx, r14
0x14287fe4a:  488b8098000000       mov       rax, qword ptr [rax + 0x98]
0x14287fe51:  ff15e1fe8b03         call      qword ptr [rip + 0x38bfee1]
0x14287fe57:  8be8                 mov       ebp, eax
0x14287fe59:  4889bc24a0000000     mov       qword ptr [rsp + 0xa0], rdi
0x14287fe61:  4584e4               test      r12b, r12b
0x14287fe64:  0f85e4000000         jne       0x14287ff4e
0x14287fe6a:  41b001               mov       r8b, 1
0x14287fe6d:  488bd3               mov       rdx, rbx
0x14287fe70:  498bce               mov       rcx, r14
0x14287fe73:  e8c87f0000           call      0x142887e40
0x14287fe78:  84c0                 test      al, al
0x14287fe7a:  0f84ce000000         je        0x14287ff4e
0x14287fe80:  498b0e               mov       rcx, qword ptr [r14]
0x14287fe83:  498b07               mov       rax, qword ptr [r15]
0x14287fe86:  488bb9b8000000       mov       rdi, qword ptr [rcx + 0xb8]
0x14287fe8d:  498bcf               mov       rcx, r15
0x14287fe90:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x14287fe94:  ff159efe8b03         call      qword ptr [rip + 0x38bfe9e]
0x14287fe9a:  498b0f               mov       rcx, qword ptr [r15]
0x14287fe9d:  8bd8                 mov       ebx, eax
0x14287fe9f:  488b4108             mov       rax, qword ptr [rcx + 8]
0x14287fea3:  498bcf               mov       rcx, r15
0x14287fea6:  ff158cfe8b03         call      qword ptr [rip + 0x38bfe8c]
0x14287feac:  448bc3               mov       r8d, ebx
0x14287feaf:  498bce               mov       rcx, r14
0x14287feb2:  488bd0               mov       rdx, rax
0x14287feb5:  488bc7               mov       rax, rdi
0x14287feb8:  ff157afe8b03         call      qword ptr [rip + 0x38bfe7a]
0x14287febe:  4183fd05             cmp       r13d, 5
0x14287fec2:  7c57                 jl        0x14287ff1b
0x14287fec4:  498d8ed80c0000       lea       rcx, [r14 + 0xcd8]
0x14287fecb:  c68424900000000e     mov       byte ptr [rsp + 0x90], 0xe
0x14287fed3:  e8d8382a03           call      0x145b237b0
0x14287fed8:  85c0                 test      eax, eax
0x14287feda:  0f8515010000         jne       0x14287fff5
0x14287fee0:  418b86280d0000       mov       eax, dword ptr [r14 + 0xd28]
0x14287fee7:  498d8ed80c0000       lea       rcx, [r14 + 0xcd8]
0x14287feee:  89842491000000       mov       dword ptr [rsp + 0x91], eax
0x14287fef5:  e816392a03           call      0x145b23810
0x14287fefa:  498b06               mov       rax, qword ptr [r14]
0x14287fefd:  488d942490000000     lea       rdx, [rsp + 0x90]
0x14287ff05:  41b805000000         mov       r8d, 5
0x14287ff0b:  498bce               mov       rcx, r14
0x14287ff0e:  488b80b8000000       mov       rax, qword ptr [rax + 0xb8]
0x14287ff15:  ff151dfe8b03         call      qword ptr [rip + 0x38bfe1d]
0x14287ff1b:  8bc5                 mov       eax, ebp
0x14287ff1d:  488bbc24a0000000     mov       rdi, qword ptr [rsp + 0xa0]
0x14287ff25:  488bac24f8000000     mov       rbp, qword ptr [rsp + 0xf8]
0x14287ff2d:  488b8c2498000000     mov       rcx, qword ptr [rsp + 0x98]
0x14287ff35:  4833cc               xor       rcx, rsp
0x14287ff38:  e8a3162a03           call      0x145b215e0
0x14287ff3d:  4881c4b0000000       add       rsp, 0xb0
0x14287ff44:  415f                 pop       r15
0x14287ff46:  415e                 pop       r14
0x14287ff48:  415d                 pop       r13
0x14287ff4a:  415c                 pop       r12
0x14287ff4c:  5b                   pop       rbx
0x14287ff4d:  c3                   ret       
0x14287ff4e:  410fb67f08           movzx     edi, byte ptr [r15 + 8]
0x14287ff53:  488d4c2460           lea       rcx, [rsp + 0x60]
0x14287ff58:  488bd3               mov       rdx, rbx
0x14287ff5b:  4889b424a8000000     mov       qword ptr [rsp + 0xa8], rsi
0x14287ff63:  e8288fffff           call      0x142878e90
0x14287ff68:  498b0f               mov       rcx, qword ptr [r15]
0x14287ff6b:  488bf0               mov       rsi, rax
0x14287ff6e:  488b4110             mov       rax, qword ptr [rcx + 0x10]
0x14287ff72:  498bcf               mov       rcx, r15
0x14287ff75:  ff15bdfd8b03         call      qword ptr [rip + 0x38bfdbd]
0x14287ff7b:  498b0f               mov       rcx, qword ptr [r15]
0x14287ff7e:  8bd8                 mov       ebx, eax
0x14287ff80:  c1e303               shl       ebx, 3
0x14287ff83:  488b4108             mov       rax, qword ptr [rcx + 8]
0x14287ff87:  498bcf               mov       rcx, r15
0x14287ff8a:  ff15a8fd8b03         call      qword ptr [rip + 0x38bfda8]
0x14287ff90:  488b8c2420010000     mov       rcx, qword ptr [rsp + 0x120]
0x14287ff98:  448bc3               mov       r8d, ebx
0x14287ff9b:  448b8c2490000000     mov       r9d, dword ptr [rsp + 0x90]
0x14287ffa3:  488bd0               mov       rdx, rax
0x14287ffa6:  48894c2458           mov       qword ptr [rsp + 0x58], rcx
0x14287ffab:  0fb68c2400010000     movzx     ecx, byte ptr [rsp + 0x100]
0x14287ffb3:  40887c2450           mov       byte ptr [rsp + 0x50], dil
0x14287ffb8:  896c2448             mov       dword ptr [rsp + 0x48], ebp
0x14287ffbc:  c744244000000000     mov       dword ptr [rsp + 0x40], 0
0x14287ffc4:  4488642438           mov       byte ptr [rsp + 0x38], r12b
0x14287ffc9:  4889742430           mov       qword ptr [rsp + 0x30], rsi
0x14287ffce:  884c2428             mov       byte ptr [rsp + 0x28], cl
0x14287ffd2:  498bce               mov       rcx, r14
0x14287ffd5:  44896c2420           mov       dword ptr [rsp + 0x20], r13d
0x14287ffda:  e8318e0000           call      0x142888e10
0x14287ffdf:  488bb424a8000000     mov       rsi, qword ptr [rsp + 0xa8]
0x14287ffe7:  8bc5                 mov       eax, ebp
0x14287ffe9:  e92fffffff           jmp       0x14287ff1d
0x14287ffee:  33c0                 xor       eax, eax
0x14287fff0:  e938ffffff           jmp       0x14287ff2d
0x14287fff5:  8bc8                 mov       ecx, eax
0x14287fff7:  e8843d2a03           call      0x145b23d80
0x14287fffc:  cc                   int3      
0x14287fffd:  cc                   int3      
0x14287fffe:  cc                   int3      
0x14287ffff:  cc                   int3      
