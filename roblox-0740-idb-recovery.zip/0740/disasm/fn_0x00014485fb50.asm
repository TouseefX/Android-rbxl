; function_of: str.Rupp client-failed-setup, str.ruppEnabled
; xref site 0x14485fc19 -> str.ruppEnabled @ 0x1470c3a10
; xref site 0x14485fcc5 -> str.Rupp client-failed-setup @ 0x1470c39e0
; range 0x14485fb50 .. 0x144860c00  (4272 bytes)

0x00014485fb50:  4053                  push      rbx
0x00014485fb52:  56                    push      rsi
0x00014485fb53:  57                    push      rdi
0x00014485fb54:  4881ec80000000        sub       rsp, 0x80
0x00014485fb5b:  488b058e3b4b03        mov       rax, qword ptr [rip + 0x34b3b8e]
0x00014485fb62:  4833c4                xor       rax, rsp
0x00014485fb65:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x00014485fb6a:  4983791810            cmp       qword ptr [r9 + 0x18], 0x10
0x00014485fb6f:  498d7120              lea       rsi, [r9 + 0x20]
0x00014485fb73:  440fb716              movzx     r10d, word ptr [rsi]
0x00014485fb77:  488bf9                mov       rdi, rcx
0x00014485fb7a:  488b8998070000        mov       rcx, qword ptr [rcx + 0x798]
0x00014485fb81:  498bd9                mov       rbx, r9
0x00014485fb84:  488b01                mov       rax, qword ptr [rcx]
0x00014485fb87:  7203                  jb        0x14485fb8c
0x00014485fb89:  4d8b09                mov       r9, qword ptr [r9]
0x00014485fb8c:  488b80f8020000        mov       rax, qword ptr [rax + 0x2f8]
0x00014485fb93:  664489542420          mov       word ptr [rsp + 0x20], r10w
0x00014485fb99:  ff1599018e01          call      qword ptr [rip + 0x18e0199]
0x00014485fb9f:  8bc8                  mov       ecx, eax
0x00014485fba1:  85c0                  test      eax, eax
0x00014485fba3:  0f85ed000000          jne       0x14485fc96
0x00014485fba9:  488d8fd0070000        lea       rcx, [rdi + 0x7d0]
0x00014485fbb0:  c687c807000001        mov       byte ptr [rdi + 0x7c8], 1
0x00014485fbb7:  483bcb                cmp       rcx, rbx
0x00014485fbba:  7416                  je        0x14485fbd2
0x00014485fbbc:  48837b1810            cmp       qword ptr [rbx + 0x18], 0x10
0x00014485fbc1:  4c8b4310              mov       r8, qword ptr [rbx + 0x10]
0x00014485fbc5:  7203                  jb        0x14485fbca
0x00014485fbc7:  488b1b                mov       rbx, qword ptr [rbx]
0x00014485fbca:  488bd3                mov       rdx, rbx
0x00014485fbcd:  e87e3ef8fb            call      0x1407e3a50
0x00014485fbd2:  0fb706                movzx     eax, word ptr [rsi]
0x00014485fbd5:  668987f0070000        mov       word ptr [rdi + 0x7f0], ax
0x00014485fbdc:  488b0585af5003        mov       rax, qword ptr [rip + 0x350af85]
0x00014485fbe3:  3c06                  cmp       al, 6
0x00014485fbe5:  0f82a4000000          jb        0x14485fc8f
0x00014485fbeb:  48c1e808              shr       rax, 8
0x00014485fbef:  3c05                  cmp       al, 5
0x00014485fbf1:  0f8298000000          jb        0x14485fc8f
0x00014485fbf7:  488d0597929d02        lea       rax, [rip + 0x29d9297]
0x00014485fbfe:  4889442450            mov       qword ptr [rsp + 0x50], rax
0x00014485fc03:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x00014485fc0a:  488b4c2450            mov       rcx, qword ptr [rsp + 0x50]
0x00014485fc0f:  0fb697c8070000        movzx     edx, byte ptr [rdi + 0x7c8]
0x00014485fc16:  488d0df33d8602        lea       rcx, [rip + 0x2863df3]
0x00014485fc1d:  48894c2440            mov       qword ptr [rsp + 0x40], rcx
0x00014485fc22:  48ffc0                inc       rax
0x00014485fc25:  803c0100              cmp       byte ptr [rcx + rax], 0
0x00014485fc29:  75f7                  jne       0x14485fc22
0x00014485fc2b:  4889442448            mov       qword ptr [rsp + 0x48], rax
0x00014485fc30:  4c8d4c2430            lea       r9, [rsp + 0x30]
0x00014485fc35:  0f284c2440            movaps    xmm1, xmmword ptr [rsp + 0x40]
0x00014485fc3a:  488d442450            lea       rax, [rsp + 0x50]
0x00014485fc3f:  89542450              mov       dword ptr [rsp + 0x50], edx
0x00014485fc43:  4c8d442440            lea       r8, [rsp + 0x40]
0x00014485fc48:  0f28442450            movaps    xmm0, xmmword ptr [rsp + 0x50]
0x00014485fc4d:  488d4c2460            lea       rcx, [rsp + 0x60]
0x00014485fc52:  660f7f442450          movdqa    xmmword ptr [rsp + 0x50], xmm0
0x00014485fc58:  b205                  mov       dl, 5
0x00014485fc5a:  4889442438            mov       qword ptr [rsp + 0x38], rax
0x00014485fc5f:  48c744243001000000    mov       qword ptr [rsp + 0x30], 1
0x00014485fc68:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014485fc6d:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014485fc73:  0f1005eeae5003        movups    xmm0, xmmword ptr [rip + 0x350aeee]
0x00014485fc7a:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x00014485fc7f:  660f7f4c2440          movdqa    xmmword ptr [rsp + 0x40], xmm1
0x00014485fc85:  0f29442460            movaps    xmmword ptr [rsp + 0x60], xmm0
0x00014485fc8a:  e841fe0f00            call      0x14495fad0
0x00014485fc8f:  b001                  mov       al, 1
0x00014485fc91:  e9bb000000            jmp       0x14485fd51
0x00014485fc96:  488b05cbae5003        mov       rax, qword ptr [rip + 0x350aecb]
0x00014485fc9d:  3c06                  cmp       al, 6
0x00014485fc9f:  0f82aa000000          jb        0x14485fd4f
0x00014485fca5:  48c1e808              shr       rax, 8
0x00014485fca9:  3c02                  cmp       al, 2
0x00014485fcab:  0f829e000000          jb        0x14485fd4f
0x00014485fcb1:  488d0596f39d02        lea       rax, [rip + 0x29df396]
0x00014485fcb8:  4889442450            mov       qword ptr [rsp + 0x50], rax
0x00014485fcbd:  4c8b442450            mov       r8, qword ptr [rsp + 0x50]
0x00014485fcc2:  4c8d05173d8602        lea       r8, [rip + 0x2863d17]
0x00014485fcc9:  e8d27fa1fd            call      0x142277ca0
0x00014485fcce:  4c8bc8                mov       r9, rax
0x00014485fcd1:  4c89442430            mov       qword ptr [rsp + 0x30], r8
0x00014485fcd6:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x00014485fcdd:  0f1f00                nop       dword ptr [rax]
0x00014485fce0:  48ffc0                inc       rax
0x00014485fce3:  41803c0000            cmp       byte ptr [r8 + rax], 0
0x00014485fce8:  75f6                  jne       0x14485fce0
0x00014485fcea:  4889442438            mov       qword ptr [rsp + 0x38], rax
0x00014485fcef:  4c8d442430            lea       r8, [rsp + 0x30]
0x00014485fcf4:  0f284c2430            movaps    xmm1, xmmword ptr [rsp + 0x30]
0x00014485fcf9:  488d442460            lea       rax, [rsp + 0x60]
0x00014485fcfe:  4c894c2460            mov       qword ptr [rsp + 0x60], r9
0x00014485fd03:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014485fd08:  0f28442460            movaps    xmm0, xmmword ptr [rsp + 0x60]
0x00014485fd0d:  4c8d4c2440            lea       r9, [rsp + 0x40]
0x00014485fd12:  660f7f442460          movdqa    xmmword ptr [rsp + 0x60], xmm0
0x00014485fd18:  b202                  mov       dl, 2
0x00014485fd1a:  4889442448            mov       qword ptr [rsp + 0x48], rax
0x00014485fd1f:  48c74424400c000000    mov       qword ptr [rsp + 0x40], 0xc
0x00014485fd28:  0f28442440            movaps    xmm0, xmmword ptr [rsp + 0x40]
0x00014485fd2d:  660f7f442440          movdqa    xmmword ptr [rsp + 0x40], xmm0
0x00014485fd33:  0f10052eae5003        movups    xmm0, xmmword ptr [rip + 0x350ae2e]
0x00014485fd3a:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x00014485fd3f:  660f7f4c2430          movdqa    xmmword ptr [rsp + 0x30], xmm1
0x00014485fd45:  0f29442450            movaps    xmmword ptr [rsp + 0x50], xmm0
0x00014485fd4a:  e881fd0f00            call      0x14495fad0
0x00014485fd4f:  32c0                  xor       al, al
0x00014485fd51:  488b4c2470            mov       rcx, qword ptr [rsp + 0x70]
0x00014485fd56:  4833cc                xor       rcx, rsp
0x00014485fd59:  e882182c01            call      0x145b215e0
0x00014485fd5e:  4881c480000000        add       rsp, 0x80
0x00014485fd65:  5f                    pop       rdi
0x00014485fd66:  5e                    pop       rsi
0x00014485fd67:  5b                    pop       rbx
0x00014485fd68:  c3                    ret       
0x00014485fd69:  cc                    int3      
0x00014485fd6a:  cc                    int3      
0x00014485fd6b:  cc                    int3      
0x00014485fd6c:  cc                    int3      
0x00014485fd6d:  cc                    int3      
0x00014485fd6e:  cc                    int3      
0x00014485fd6f:  cc                    int3      
0x00014485fd70:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014485fd75:  57                    push      rdi
0x00014485fd76:  4883ec20              sub       rsp, 0x20
0x00014485fd7a:  488bda                mov       rbx, rdx
0x00014485fd7d:  488d05448fa001        lea       rax, [rip + 0x1a08f44]
0x00014485fd84:  488901                mov       qword ptr [rcx], rax
0x00014485fd87:  488d5108              lea       rdx, [rcx + 8]
0x00014485fd8b:  488bf9                mov       rdi, rcx
0x00014485fd8e:  0f57c0                xorps     xmm0, xmm0
0x00014485fd91:  0f1102                movups    xmmword ptr [rdx], xmm0
0x00014485fd94:  488d4b08              lea       rcx, [rbx + 8]
0x00014485fd98:  e8231c2e01            call      0x145b419c0
0x00014485fd9d:  488d056cde4a02        lea       rax, [rip + 0x24ade6c]
0x00014485fda4:  488907                mov       qword ptr [rdi], rax
0x00014485fda7:  8b4318                mov       eax, dword ptr [rbx + 0x18]
0x00014485fdaa:  488b5c2430            mov       rbx, qword ptr [rsp + 0x30]
0x00014485fdaf:  894718                mov       dword ptr [rdi + 0x18], eax
0x00014485fdb2:  488bc7                mov       rax, rdi
0x00014485fdb5:  4883c420              add       rsp, 0x20
0x00014485fdb9:  5f                    pop       rdi
0x00014485fdba:  c3                    ret       
0x00014485fdbb:  cc                    int3      
0x00014485fdbc:  cc                    int3      
0x00014485fdbd:  cc                    int3      
0x00014485fdbe:  cc                    int3      
0x00014485fdbf:  cc                    int3      
0x00014485fdc0:  48895c2418            mov       qword ptr [rsp + 0x18], rbx
0x00014485fdc5:  55                    push      rbp
0x00014485fdc6:  56                    push      rsi
0x00014485fdc7:  57                    push      rdi
0x00014485fdc8:  4154                  push      r12
0x00014485fdca:  4155                  push      r13
0x00014485fdcc:  4156                  push      r14
0x00014485fdce:  4157                  push      r15
0x00014485fdd0:  488dac2430fcffff      lea       rbp, [rsp - 0x3d0]
0x00014485fdd8:  4881ecd0040000        sub       rsp, 0x4d0
0x00014485fddf:  0f29b424c0040000      movaps    xmmword ptr [rsp + 0x4c0], xmm6
0x00014485fde7:  488b0502394b03        mov       rax, qword ptr [rip + 0x34b3902]
0x00014485fdee:  4833c4                xor       rax, rsp
0x00014485fdf1:  488985b0030000        mov       qword ptr [rbp + 0x3b0], rax
0x00014485fdf8:  4c8bf2                mov       r14, rdx
0x00014485fdfb:  4c8bf9                mov       r15, rcx
0x00014485fdfe:  4533ed                xor       r13d, r13d
0x00014485fe01:  44896c2460            mov       dword ptr [rsp + 0x60], r13d
0x00014485fe06:  4c396a60              cmp       qword ptr [rdx + 0x60], r13
0x00014485fe0a:  741f                  je        0x14485fe2b
0x00014485fe0c:  4c8d4a70              lea       r9, [rdx + 0x70]
0x00014485fe10:  4c8b82d0010000        mov       r8, qword ptr [rdx + 0x1d0]
0x00014485fe17:  0fb692db010000        movzx     edx, byte ptr [rdx + 0x1db]
0x00014485fe1e:  e82dfdffff            call      0x14485fb50
0x00014485fe23:  84c0                  test      al, al
0x00014485fe25:  0f844e090000          je        0x144860779
0x00014485fe2b:  498d5e70              lea       rbx, [r14 + 0x70]
0x00014485fe2f:  4d396e60              cmp       qword ptr [r14 + 0x60], r13
0x00014485fe33:  490f45de              cmovne    rbx, r14
0x00014485fe37:  488bd3                mov       rdx, rbx
0x00014485fe3a:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x00014485fe41:  e81a41f8fb            call      0x1407e3f60
0x00014485fe46:  90                    nop       
0x00014485fe47:  8b4320                mov       eax, dword ptr [rbx + 0x20]
0x00014485fe4a:  898540020000          mov       dword ptr [rbp + 0x240], eax
0x00014485fe50:  8b4324                mov       eax, dword ptr [rbx + 0x24]
0x00014485fe53:  898544020000          mov       dword ptr [rbp + 0x244], eax
0x00014485fe59:  8b4328                mov       eax, dword ptr [rbx + 0x28]
0x00014485fe5c:  898548020000          mov       dword ptr [rbp + 0x248], eax
0x00014485fe62:  488d5330              lea       rdx, [rbx + 0x30]
0x00014485fe66:  488d8d50020000        lea       rcx, [rbp + 0x250]
0x00014485fe6d:  e8ee40f8fb            call      0x1407e3f60
0x00014485fe72:  90                    nop       
0x00014485fe73:  488d5350              lea       rdx, [rbx + 0x50]
0x00014485fe77:  488d8d70020000        lea       rcx, [rbp + 0x270]
0x00014485fe7e:  e8dd40f8fb            call      0x1407e3f60
0x00014485fe83:  90                    nop       
0x00014485fe84:  0f57c0                xorps     xmm0, xmm0
0x00014485fe87:  f30f7f4540            movdqu    xmmword ptr [rbp + 0x40], xmm0
0x00014485fe8c:  4c896d50              mov       qword ptr [rbp + 0x50], r13
0x00014485fe90:  b946000000            mov       ecx, 0x46
0x00014485fe95:  e866390e00            call      0x144943800
0x00014485fe9a:  488bf0                mov       rsi, rax
0x00014485fe9d:  4885c0                test      rax, rax
0x00014485fea0:  0f84b3080000          je        0x144860759
0x00014485fea6:  48894540              mov       qword ptr [rbp + 0x40], rax
0x00014485feaa:  4883c046              add       rax, 0x46
0x00014485feae:  48894550              mov       qword ptr [rbp + 0x50], rax
0x00014485feb2:  6644892e              mov       word ptr [rsi], r13w
0x00014485feb6:  c6460200              mov       byte ptr [rsi + 2], 0
0x00014485feba:  6644896e44            mov       word ptr [rsi + 0x44], r13w
0x00014485febf:  48894548              mov       qword ptr [rbp + 0x48], rax
0x00014485fec3:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x00014485feca:  4883bd3802000010      cmp       qword ptr [rbp + 0x238], 0x10
0x00014485fed2:  480f438d20020000      cmovae    rcx, qword ptr [rbp + 0x220]
0x00014485feda:  b802000000            mov       eax, 2
0x00014485fedf:  66894644              mov       word ptr [rsi + 0x44], ax
0x00014485fee3:  4c896c2470            mov       qword ptr [rsp + 0x70], r13
0x00014485fee8:  0f57c0                xorps     xmm0, xmm0
0x00014485feeb:  f30f7f45fc            movdqu    xmmword ptr [rbp - 4], xmm0
0x00014485fef0:  0f57c9                xorps     xmm1, xmm1
0x00014485fef3:  f30f7f4d0c            movdqu    xmmword ptr [rbp + 0xc], xmm1
0x00014485fef8:  44896d1c              mov       dword ptr [rbp + 0x1c], r13d
0x00014485fefc:  8945f8                mov       dword ptr [rbp - 8], eax
0x00014485feff:  48c745f0000c0000      mov       qword ptr [rbp - 0x10], 0xc00
0x00014485ff07:  4c8d4c2470            lea       r9, [rsp + 0x70]
0x00014485ff0c:  4c8d45f0              lea       r8, [rbp - 0x10]
0x00014485ff10:  33d2                  xor       edx, edx
0x00014485ff12:  ff1528f98d01          call      qword ptr [rip + 0x18df928]
0x00014485ff18:  8bf8                  mov       edi, eax
0x00014485ff1a:  48c7c3ffffffff        mov       rbx, 0xffffffffffffffff
0x00014485ff21:  488b4c2470            mov       rcx, qword ptr [rsp + 0x70]
0x00014485ff26:  85c0                  test      eax, eax
0x00014485ff28:  7518                  jne       0x14485ff42
0x00014485ff2a:  4885c9                test      rcx, rcx
0x00014485ff2d:  0f841b010000          je        0x14486004e
0x00014485ff33:  83790417              cmp       dword ptr [rcx + 4], 0x17
0x00014485ff37:  7509                  jne       0x14485ff42
0x00014485ff39:  b817000000            mov       eax, 0x17
0x00014485ff3e:  66894644              mov       word ptr [rsi + 0x44], ax
0x00014485ff42:  4885c9                test      rcx, rcx
0x00014485ff45:  7406                  je        0x14485ff4d
0x00014485ff47:  ff15fbf88d01          call      qword ptr [rip + 0x18df8fb]
0x00014485ff4d:  85ff                  test      edi, edi
0x00014485ff4f:  0f84f9000000          je        0x14486004e
0x00014485ff55:  488b058c085603        mov       rax, qword ptr [rip + 0x356088c]
0x00014485ff5c:  3c06                  cmp       al, 6
0x00014485ff5e:  0f82ea000000          jb        0x14486004e
0x00014485ff64:  48c1e808              shr       rax, 8
0x00014485ff68:  3c02                  cmp       al, 2
0x00014485ff6a:  0f82de000000          jb        0x14486004e
0x00014485ff70:  488d05e92cac02        lea       rax, [rip + 0x2ac2ce9]
0x00014485ff77:  488945c0              mov       qword ptr [rbp - 0x40], rax
0x00014485ff7b:  488b4dc0              mov       rcx, qword ptr [rbp - 0x40]
0x00014485ff7f:  488d0d2a3c8602        lea       rcx, [rip + 0x2863c2a]
0x00014485ff86:  488d9520020000        lea       rdx, [rbp + 0x220]
0x00014485ff8d:  4883bd3802000010      cmp       qword ptr [rbp + 0x238], 0x10
0x00014485ff95:  480f439520020000      cmovae    rdx, qword ptr [rbp + 0x220]
0x00014485ff9d:  48894d70              mov       qword ptr [rbp + 0x70], rcx
0x00014485ffa1:  488bc3                mov       rax, rbx
0x00014485ffa4:  48ffc0                inc       rax
0x00014485ffa7:  803c0100              cmp       byte ptr [rcx + rax], 0
0x00014485ffab:  75f7                  jne       0x14485ffa4
0x00014485ffad:  48894578              mov       qword ptr [rbp + 0x78], rax
0x00014485ffb1:  48899530010000        mov       qword ptr [rbp + 0x130], rdx
0x00014485ffb8:  8b8540020000          mov       eax, dword ptr [rbp + 0x240]
0x00014485ffbe:  898540010000          mov       dword ptr [rbp + 0x140], eax
0x00014485ffc4:  89bdc0010000          mov       dword ptr [rbp + 0x1c0], edi
0x00014485ffca:  0f108530010000        movups    xmm0, xmmword ptr [rbp + 0x130]
0x00014485ffd1:  0f118500030000        movups    xmmword ptr [rbp + 0x300], xmm0
0x00014485ffd8:  0f108d40010000        movups    xmm1, xmmword ptr [rbp + 0x140]
0x00014485ffdf:  0f118d10030000        movups    xmmword ptr [rbp + 0x310], xmm1
0x00014485ffe6:  0f1085c0010000        movups    xmm0, xmmword ptr [rbp + 0x1c0]
0x00014485ffed:  0f118520030000        movups    xmmword ptr [rbp + 0x320], xmm0
0x00014485fff4:  48c745601c010000      mov       qword ptr [rbp + 0x60], 0x11c
0x00014485fffc:  488d8500030000        lea       rax, [rbp + 0x300]
0x000144860003:  48894568              mov       qword ptr [rbp + 0x68], rax
0x000144860007:  0f284560              movaps    xmm0, xmmword ptr [rbp + 0x60]
0x00014486000b:  660f7f85d0010000      movdqa    xmmword ptr [rbp + 0x1d0], xmm0
0x000144860013:  0f284d70              movaps    xmm1, xmmword ptr [rbp + 0x70]
0x000144860017:  660f7f8da0000000      movdqa    xmmword ptr [rbp + 0xa0], xmm1
0x00014486001f:  0f1005c2075603        movups    xmm0, xmmword ptr [rip + 0x35607c2]
0x000144860026:  0f2985b0000000        movaps    xmmword ptr [rbp + 0xb0], xmm0
0x00014486002d:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x000144860032:  4c8d8dd0010000        lea       r9, [rbp + 0x1d0]
0x000144860039:  4c8d85a0000000        lea       r8, [rbp + 0xa0]
0x000144860040:  b202                  mov       dl, 2
0x000144860042:  488d8db0000000        lea       rcx, [rbp + 0xb0]
0x000144860049:  e882fa0f00            call      0x14495fad0
0x00014486004e:  410fb786fc000000      movzx     eax, word ptr [r14 + 0xfc]
0x000144860056:  668906                mov       word ptr [rsi], ax
0x000144860059:  0fb74e44              movzx     ecx, word ptr [rsi + 0x44]
0x00014486005d:  bf01000000            mov       edi, 1
0x000144860062:  6683f917              cmp       cx, 0x17
0x000144860066:  7509                  jne       0x144860071
0x000144860068:  4489ad44020000        mov       dword ptr [rbp + 0x244], r13d
0x00014486006f:  eb20                  jmp       0x144860091
0x000144860071:  6683f902              cmp       cx, 2
0x000144860075:  7508                  jne       0x14486007f
0x000144860077:  89bd44020000          mov       dword ptr [rbp + 0x244], edi
0x00014486007d:  eb12                  jmp       0x144860091
0x00014486007f:  418bc5                mov       eax, r13d
0x000144860082:  6685c9                test      cx, cx
0x000144860085:  0f95c0                setne     al
0x000144860088:  83c002                add       eax, 2
0x00014486008b:  898544020000          mov       dword ptr [rbp + 0x244], eax
0x000144860091:  498b8f98070000        mov       rcx, qword ptr [r15 + 0x798]
0x000144860098:  488b01                mov       rax, qword ptr [rcx]
0x00014486009b:  8bd7                  mov       edx, edi
0x00014486009d:  c74424386179feff      mov       dword ptr [rsp + 0x38], 0xfffe7961
0x0001448600a5:  6644896c2430          mov       word ptr [rsp + 0x30], r13w
0x0001448600ab:  6644896c2428          mov       word ptr [rsp + 0x28], r13w
0x0001448600b1:  897c2420              mov       dword ptr [rsp + 0x20], edi
0x0001448600b5:  4c8bce                mov       r9, rsi
0x0001448600b8:  4d8b8600010000        mov       r8, qword ptr [r14 + 0x100]
0x0001448600bf:  488b4008              mov       rax, qword ptr [rax + 8]
0x0001448600c3:  ff156ffc8d01          call      qword ptr [rip + 0x18dfc6f]
0x0001448600c9:  85c0                  test      eax, eax
0x0001448600cb:  0f85cc060000          jne       0x14486079d
0x0001448600d1:  498b8f98070000        mov       rcx, qword ptr [r15 + 0x798]
0x0001448600d8:  488b01                mov       rax, qword ptr [rcx]
0x0001448600db:  410fb696d9010000      movzx     edx, byte ptr [r14 + 0x1d9]
0x0001448600e3:  488b80d0020000        mov       rax, qword ptr [rax + 0x2d0]
0x0001448600ea:  ff1548fc8d01          call      qword ptr [rip + 0x18dfc48]
0x0001448600f0:  4180beda01000000      cmp       byte ptr [r14 + 0x1da], 0
0x0001448600f8:  7421                  je        0x14486011b
0x0001448600fa:  4180bed901000000      cmp       byte ptr [r14 + 0x1d9], 0
0x000144860102:  7417                  je        0x14486011b
0x000144860104:  498b8f98070000        mov       rcx, qword ptr [r15 + 0x798]
0x00014486010b:  488b01                mov       rax, qword ptr [rcx]
0x00014486010e:  488b80d8020000        mov       rax, qword ptr [rax + 0x2d8]
0x000144860115:  ff151dfc8d01          call      qword ptr [rip + 0x18dfc1d]
0x00014486011b:  498b8f98070000        mov       rcx, qword ptr [r15 + 0x798]
0x000144860122:  488b01                mov       rax, qword ptr [rcx]
0x000144860125:  448b054c6e5503        mov       r8d, dword ptr [rip + 0x3556e4c]
0x00014486012c:  448b151d6e5503        mov       r10d, dword ptr [rip + 0x3556e1d]
0x000144860133:  448b1dd6535703        mov       r11d, dword ptr [rip + 0x35753d6]
0x00014486013a:  4c8d0dbf535703        lea       r9, [rip + 0x35753bf]
0x000144860141:  48833dcf53570310      cmp       qword ptr [rip + 0x35753cf], 0x10
0x000144860149:  4c0f430daf535703      cmovae    r9, qword ptr [rip + 0x35753af]
0x000144860151:  488d9520020000        lea       rdx, [rbp + 0x220]
0x000144860158:  4883bd3802000010      cmp       qword ptr [rbp + 0x238], 0x10
0x000144860160:  480f439520020000      cmovae    rdx, qword ptr [rbp + 0x220]
0x000144860168:  44896c2448            mov       dword ptr [rsp + 0x48], r13d
0x00014486016d:  4489442440            mov       dword ptr [rsp + 0x40], r8d
0x000144860172:  4489542438            mov       dword ptr [rsp + 0x38], r10d
0x000144860177:  44896c2430            mov       dword ptr [rsp + 0x30], r13d
0x00014486017c:  4c896c2428            mov       qword ptr [rsp + 0x28], r13
0x000144860181:  44895c2420            mov       dword ptr [rsp + 0x20], r11d
0x000144860186:  440fb78540020000      movzx     r8d, word ptr [rbp + 0x240]
0x00014486018e:  488b4068              mov       rax, qword ptr [rax + 0x68]
0x000144860192:  ff15a0fb8d01          call      qword ptr [rip + 0x18dfba0]
0x000144860198:  8945b0                mov       dword ptr [rbp - 0x50], eax
0x00014486019b:  85c0                  test      eax, eax
0x00014486019d:  0f8556070000          jne       0x1448608f9
0x0001448601a3:  488b059ef95303        mov       rax, qword ptr [rip + 0x353f99e]
0x0001448601aa:  3c06                  cmp       al, 6
0x0001448601ac:  0f82c4000000          jb        0x144860276
0x0001448601b2:  48c1e808              shr       rax, 8
0x0001448601b6:  3c04                  cmp       al, 4
0x0001448601b8:  0f82b8000000          jb        0x144860276
0x0001448601be:  488d05ea73af02        lea       rax, [rip + 0x2af73ea]
0x0001448601c5:  488945c0              mov       qword ptr [rbp - 0x40], rax
0x0001448601c9:  488b7dc0              mov       rdi, qword ptr [rbp - 0x40]
0x0001448601cd:  488d3d24398602        lea       rdi, [rip + 0x2863924]
0x0001448601d4:  488d4d90              lea       rcx, [rbp - 0x70]
0x0001448601d8:  e823780e00            call      0x144947a00
0x0001448601dd:  f20f104d90            movsd     xmm1, qword ptr [rbp - 0x70]
0x0001448601e2:  660f5ac9              cvtpd2ps  xmm1, xmm1
0x0001448601e6:  4889bd90000000        mov       qword ptr [rbp + 0x90], rdi
0x0001448601ed:  488bc3                mov       rax, rbx
0x0001448601f0:  48ffc0                inc       rax
0x0001448601f3:  803c0700              cmp       byte ptr [rdi + rax], 0
0x0001448601f7:  75f7                  jne       0x1448601f0
0x0001448601f9:  48898598000000        mov       qword ptr [rbp + 0x98], rax
0x000144860200:  0f2845c0              movaps    xmm0, xmmword ptr [rbp - 0x40]
0x000144860204:  f30f10c1              movss     xmm0, xmm1
0x000144860208:  660f7f85b0020000      movdqa    xmmword ptr [rbp + 0x2b0], xmm0
0x000144860210:  48c7858000000009000000  mov       qword ptr [rbp + 0x80], 9
0x00014486021b:  488d85b0020000        lea       rax, [rbp + 0x2b0]
0x000144860222:  48898588000000        mov       qword ptr [rbp + 0x88], rax
0x000144860229:  0f288580000000        movaps    xmm0, xmmword ptr [rbp + 0x80]
0x000144860230:  660f7f8500010000      movdqa    xmmword ptr [rbp + 0x100], xmm0
0x000144860238:  0f288d90000000        movaps    xmm1, xmmword ptr [rbp + 0x90]
0x00014486023f:  660f7f8d10010000      movdqa    xmmword ptr [rbp + 0x110], xmm1
0x000144860247:  0f1005faf85303        movups    xmm0, xmmword ptr [rip + 0x353f8fa]
0x00014486024e:  0f298520010000        movaps    xmmword ptr [rbp + 0x120], xmm0
0x000144860255:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x00014486025a:  4c8d8d00010000        lea       r9, [rbp + 0x100]
0x000144860261:  4c8d8510010000        lea       r8, [rbp + 0x110]
0x000144860268:  b204                  mov       dl, 4
0x00014486026a:  488d8d20010000        lea       rcx, [rbp + 0x120]
0x000144860271:  e85af80f00            call      0x14495fad0
0x000144860276:  488b056b055603        mov       rax, qword ptr [rip + 0x356056b]
0x00014486027d:  4180bed801000000      cmp       byte ptr [r14 + 0x1d8], 0
0x000144860285:  0f84c1000000          je        0x14486034c
0x00014486028b:  3c06                  cmp       al, 6
0x00014486028d:  0f8278010000          jb        0x14486040b
0x000144860293:  48c1e808              shr       rax, 8
0x000144860297:  3c04                  cmp       al, 4
0x000144860299:  0f826c010000          jb        0x14486040b
0x00014486029f:  488d05284ab002        lea       rax, [rip + 0x2b04a28]
0x0001448602a6:  48894590              mov       qword ptr [rbp - 0x70], rax
0x0001448602aa:  488b4590              mov       rax, qword ptr [rbp - 0x70]
0x0001448602ae:  4805e2edd5ff          add       rax, -0x2a121e
0x0001448602b4:  498d8fd0070000        lea       rcx, [r15 + 0x7d0]
0x0001448602bb:  4883791810            cmp       qword ptr [rcx + 0x18], 0x10
0x0001448602c0:  7203                  jb        0x1448602c5
0x0001448602c2:  488b09                mov       rcx, qword ptr [rcx]
0x0001448602c5:  488d9520020000        lea       rdx, [rbp + 0x220]
0x0001448602cc:  4883bd3802000010      cmp       qword ptr [rbp + 0x238], 0x10
0x0001448602d4:  480f439520020000      cmovae    rdx, qword ptr [rbp + 0x220]
0x0001448602dc:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x0001448602e1:  48ffc3                inc       rbx
0x0001448602e4:  803c1800              cmp       byte ptr [rax + rbx], 0
0x0001448602e8:  75f7                  jne       0x1448602e1
0x0001448602ea:  48899590020000        mov       qword ptr [rbp + 0x290], rdx
0x0001448602f1:  8b8540020000          mov       eax, dword ptr [rbp + 0x240]
0x0001448602f7:  8945e0                mov       dword ptr [rbp - 0x20], eax
0x0001448602fa:  48894dd0              mov       qword ptr [rbp - 0x30], rcx
0x0001448602fe:  410fb787f0070000      movzx     eax, word ptr [r15 + 0x7f0]
0x000144860306:  8945a0                mov       dword ptr [rbp - 0x60], eax
0x000144860309:  0f108590020000        movups    xmm0, xmmword ptr [rbp + 0x290]
0x000144860310:  0f298530030000        movaps    xmmword ptr [rbp + 0x330], xmm0
0x000144860317:  0f104de0              movups    xmm1, xmmword ptr [rbp - 0x20]
0x00014486031b:  0f298d40030000        movaps    xmmword ptr [rbp + 0x340], xmm1
0x000144860322:  0f1045d0              movups    xmm0, xmmword ptr [rbp - 0x30]
0x000144860326:  0f298550030000        movaps    xmmword ptr [rbp + 0x350], xmm0
0x00014486032d:  0f104da0              movups    xmm1, xmmword ptr [rbp - 0x60]
0x000144860331:  0f298d60030000        movaps    xmmword ptr [rbp + 0x360], xmm1
0x000144860338:  48c745801c2c0000      mov       qword ptr [rbp - 0x80], 0x2c1c
0x000144860340:  488d8530030000        lea       rax, [rbp + 0x330]
0x000144860347:  e980000000            jmp       0x1448603cc
0x00014486034c:  3c06                  cmp       al, 6
0x00014486034e:  0f82b7000000          jb        0x14486040b
0x000144860354:  48c1e808              shr       rax, 8
0x000144860358:  3c04                  cmp       al, 4
0x00014486035a:  0f82ab000000          jb        0x14486040b
0x000144860360:  488d058b97b002        lea       rax, [rip + 0x2b0978b]
0x000144860367:  48894590              mov       qword ptr [rbp - 0x70], rax
0x00014486036b:  488b4590              mov       rax, qword ptr [rbp - 0x70]
0x00014486036f:  48058e9fd5ff          add       rax, -0x2a6072
0x000144860375:  488d8d20020000        lea       rcx, [rbp + 0x220]
0x00014486037c:  4883bd3802000010      cmp       qword ptr [rbp + 0x238], 0x10
0x000144860384:  480f438d20020000      cmovae    rcx, qword ptr [rbp + 0x220]
0x00014486038c:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x000144860391:  48ffc3                inc       rbx
0x000144860394:  803c1800              cmp       byte ptr [rax + rbx], 0
0x000144860398:  75f7                  jne       0x144860391
0x00014486039a:  48894da0              mov       qword ptr [rbp - 0x60], rcx
0x00014486039e:  8b8540020000          mov       eax, dword ptr [rbp + 0x240]
0x0001448603a4:  8945d0                mov       dword ptr [rbp - 0x30], eax
0x0001448603a7:  0f1045a0              movups    xmm0, xmmword ptr [rbp - 0x60]
0x0001448603ab:  0f118590020000        movups    xmmword ptr [rbp + 0x290], xmm0
0x0001448603b2:  0f104dd0              movups    xmm1, xmmword ptr [rbp - 0x30]
0x0001448603b6:  0f118da0020000        movups    xmmword ptr [rbp + 0x2a0], xmm1
0x0001448603bd:  48c745801c000000      mov       qword ptr [rbp - 0x80], 0x1c
0x0001448603c5:  488d8590020000        lea       rax, [rbp + 0x290]
0x0001448603cc:  48894588              mov       qword ptr [rbp - 0x78], rax
0x0001448603d0:  0f284580              movaps    xmm0, xmmword ptr [rbp - 0x80]
0x0001448603d4:  48895c2478            mov       qword ptr [rsp + 0x78], rbx
0x0001448603d9:  660f7f45a0            movdqa    xmmword ptr [rbp - 0x60], xmm0
0x0001448603de:  0f284c2470            movaps    xmm1, xmmword ptr [rsp + 0x70]
0x0001448603e3:  0f1005fe035603        movups    xmm0, xmmword ptr [rip + 0x35603fe]
0x0001448603ea:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x0001448603ef:  660f7f4dd0            movdqa    xmmword ptr [rbp - 0x30], xmm1
0x0001448603f4:  0f2945e0              movaps    xmmword ptr [rbp - 0x20], xmm0
0x0001448603f8:  4c8d4da0              lea       r9, [rbp - 0x60]
0x0001448603fc:  4c8d45d0              lea       r8, [rbp - 0x30]
0x000144860400:  b204                  mov       dl, 4
0x000144860402:  488d4de0              lea       rcx, [rbp - 0x20]
0x000144860406:  e8c5f60f00            call      0x14495fad0
0x00014486040b:  488d9520020000        lea       rdx, [rbp + 0x220]
0x000144860412:  4883bd3802000010      cmp       qword ptr [rbp + 0x238], 0x10
0x00014486041a:  480f439520020000      cmovae    rdx, qword ptr [rbp + 0x220]
0x000144860422:  0fb79d40020000        movzx     ebx, word ptr [rbp + 0x240]
0x000144860429:  41bc02000000          mov       r12d, 2
0x00014486042f:  6644896520            mov       word ptr [rbp + 0x20], r12w
0x000144860434:  488d4d20              lea       rcx, [rbp + 0x20]
0x000144860438:  e8835404fe            call      0x1428a58c0
0x00014486043d:  84c0                  test      al, al
0x00014486043f:  741a                  je        0x14486045b
0x000144860441:  0fb7cb                movzx     ecx, bx
0x000144860444:  ff15eef38d01          call      qword ptr [rip + 0x18df3ee]
0x00014486044a:  66894522              mov       word ptr [rbp + 0x22], ax
0x00014486044e:  0fb7c8                movzx     ecx, ax
0x000144860451:  ff15d9f38d01          call      qword ptr [rip + 0x18df3d9]
0x000144860457:  6689453c              mov       word ptr [rbp + 0x3c], ax
0x00014486045b:  b8ffff0000            mov       eax, 0xffff
0x000144860460:  6689453e              mov       word ptr [rbp + 0x3e], ax
0x000144860464:  0f104520              movups    xmm0, xmmword ptr [rbp + 0x20]
0x000144860468:  410f1187a8070000      movups    xmmword ptr [r15 + 0x7a8], xmm0
0x000144860470:  f20f104d30            movsd     xmm1, qword ptr [rbp + 0x30]
0x000144860475:  f2410f118fb8070000    movsd     qword ptr [r15 + 0x7b8], xmm1
0x00014486047e:  8b4538                mov       eax, dword ptr [rbp + 0x38]
0x000144860481:  418987c0070000        mov       dword ptr [r15 + 0x7c0], eax
0x000144860488:  488b4d38              mov       rcx, qword ptr [rbp + 0x38]
0x00014486048c:  488bc1                mov       rax, rcx
0x00014486048f:  48c1e830              shr       rax, 0x30
0x000144860493:  66418987c6070000      mov       word ptr [r15 + 0x7c6], ax
0x00014486049b:  48c1e920              shr       rcx, 0x20
0x00014486049f:  6641898fc4070000      mov       word ptr [r15 + 0x7c4], cx
0x0001448604a7:  0f288520020000        movaps    xmm0, xmmword ptr [rbp + 0x220]
0x0001448604ae:  0f118550010000        movups    xmmword ptr [rbp + 0x150], xmm0
0x0001448604b5:  0f288d30020000        movaps    xmm1, xmmword ptr [rbp + 0x230]
0x0001448604bc:  0f118d60010000        movups    xmmword ptr [rbp + 0x160], xmm1
0x0001448604c3:  660f6f05754f9702      movdqa    xmm0, xmmword ptr [rip + 0x2974f75]
0x0001448604cb:  660f7f8530020000      movdqa    xmmword ptr [rbp + 0x230], xmm0
0x0001448604d3:  c6852002000000        mov       byte ptr [rbp + 0x220], 0
0x0001448604da:  8b8540020000          mov       eax, dword ptr [rbp + 0x240]
0x0001448604e0:  898570010000          mov       dword ptr [rbp + 0x170], eax
0x0001448604e6:  8b8544020000          mov       eax, dword ptr [rbp + 0x244]
0x0001448604ec:  898574010000          mov       dword ptr [rbp + 0x174], eax
0x0001448604f2:  8b8548020000          mov       eax, dword ptr [rbp + 0x248]
0x0001448604f8:  898578010000          mov       dword ptr [rbp + 0x178], eax
0x0001448604fe:  0f288550020000        movaps    xmm0, xmmword ptr [rbp + 0x250]
0x000144860505:  0f118580010000        movups    xmmword ptr [rbp + 0x180], xmm0
0x00014486050c:  0f288d60020000        movaps    xmm1, xmmword ptr [rbp + 0x260]
0x000144860513:  0f118d90010000        movups    xmmword ptr [rbp + 0x190], xmm1
0x00014486051a:  660f6f051e4f9702      movdqa    xmm0, xmmword ptr [rip + 0x2974f1e]
0x000144860522:  660f7f8560020000      movdqa    xmmword ptr [rbp + 0x260], xmm0
0x00014486052a:  c6855002000000        mov       byte ptr [rbp + 0x250], 0
0x000144860531:  0f288d70020000        movaps    xmm1, xmmword ptr [rbp + 0x270]
0x000144860538:  0f118da0010000        movups    xmmword ptr [rbp + 0x1a0], xmm1
0x00014486053f:  0f288580020000        movaps    xmm0, xmmword ptr [rbp + 0x280]
0x000144860546:  0f1185b0010000        movups    xmmword ptr [rbp + 0x1b0], xmm0
0x00014486054d:  660f6f0deb4e9702      movdqa    xmm1, xmmword ptr [rip + 0x2974eeb]
0x000144860555:  660f7f8d80020000      movdqa    xmmword ptr [rbp + 0x280], xmm1
0x00014486055d:  c6857002000000        mov       byte ptr [rbp + 0x270], 0
0x000144860564:  498d8f20050000        lea       rcx, [r15 + 0x520]
0x00014486056b:  488d9550010000        lea       rdx, [rbp + 0x150]
0x000144860572:  e8494e28ff            call      0x143ae53c0
0x000144860577:  488d8da0010000        lea       rcx, [rbp + 0x1a0]
0x00014486057e:  e85d54f8fb            call      0x1407e59e0
0x000144860583:  488d8d80010000        lea       rcx, [rbp + 0x180]
0x00014486058a:  e85154f8fb            call      0x1407e59e0
0x00014486058f:  488d8d50010000        lea       rcx, [rbp + 0x150]
0x000144860596:  e84554f8fb            call      0x1407e59e0
0x00014486059b:  4180bee800000000      cmp       byte ptr [r14 + 0xe8], 0
0x0001448605a3:  7448                  je        0x1448605ed
0x0001448605a5:  498b8f98070000        mov       rcx, qword ptr [r15 + 0x798]
0x0001448605ac:  488b01                mov       rax, qword ptr [rcx]
0x0001448605af:  f2410f1086e0000000    movsd     xmm0, qword ptr [r14 + 0xe0]
0x0001448605b8:  f20f5905788a9602      mulsd     xmm0, qword ptr [rip + 0x2968a78]
0x0001448605c0:  f2480f2cd0            cvttsd2si rdx, xmm0
0x0001448605c5:  0f10057cf25803        movups    xmm0, xmmword ptr [rip + 0x358f27c]
0x0001448605cc:  0f2945f0              movaps    xmmword ptr [rbp - 0x10], xmm0
0x0001448605d0:  0f100d81f25803        movups    xmm1, xmmword ptr [rip + 0x358f281]
0x0001448605d7:  0f294d00              movaps    xmmword ptr [rbp], xmm1
0x0001448605db:  4c8d45f0              lea       r8, [rbp - 0x10]
0x0001448605df:  488b80b8010000        mov       rax, qword ptr [rax + 0x1b8]
0x0001448605e6:  ff154cf78d01          call      qword ptr [rip + 0x18df74c]
0x0001448605ec:  90                    nop       
0x0001448605ed:  488b4d50              mov       rcx, qword ptr [rbp + 0x50]
0x0001448605f1:  482bce                sub       rcx, rsi
0x0001448605f4:  48b8a10eeaa00eeaa00e  movabs    rax, 0xea0ea0ea0ea0ea1
0x0001448605fe:  48f7e9                imul      rcx
0x000144860601:  48c1fa02              sar       rdx, 2
0x000144860605:  488bc2                mov       rax, rdx
0x000144860608:  48c1e83f              shr       rax, 0x3f
0x00014486060c:  4803d0                add       rdx, rax
0x00014486060f:  486bc246              imul      rax, rdx, 0x46
0x000144860613:  483d00100000          cmp       rax, 0x1000
0x000144860619:  7218                  jb        0x144860633
0x00014486061b:  488b4ef8              mov       rcx, qword ptr [rsi - 8]
0x00014486061f:  482bf1                sub       rsi, rcx
0x000144860622:  488d46f8              lea       rax, [rsi - 8]
0x000144860626:  4883f81f              cmp       rax, 0x1f
0x00014486062a:  0f8723010000          ja        0x144860753
0x000144860630:  488bf1                mov       rsi, rcx
0x000144860633:  488bce                mov       rcx, rsi
0x000144860636:  e8752a0e00            call      0x1449430b0
0x00014486063b:  90                    nop       
0x00014486063c:  488b8588020000        mov       rax, qword ptr [rbp + 0x288]
0x000144860643:  4883f810              cmp       rax, 0x10
0x000144860647:  7230                  jb        0x144860679
0x000144860649:  48ffc0                inc       rax
0x00014486064c:  488b8d70020000        mov       rcx, qword ptr [rbp + 0x270]
0x000144860653:  488bd1                mov       rdx, rcx
0x000144860656:  483d00100000          cmp       rax, 0x1000
0x00014486065c:  7215                  jb        0x144860673
0x00014486065e:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000144860662:  482bd1                sub       rdx, rcx
0x000144860665:  488d42f8              lea       rax, [rdx - 8]
0x000144860669:  4883f81f              cmp       rax, 0x1f
0x00014486066d:  0f8766030000          ja        0x1448609d9
0x000144860673:  e8382a0e00            call      0x1449430b0
0x000144860678:  90                    nop       
0x000144860679:  660f6f05bf4d9702      movdqa    xmm0, xmmword ptr [rip + 0x2974dbf]
0x000144860681:  660f7f8580020000      movdqa    xmmword ptr [rbp + 0x280], xmm0
0x000144860689:  c6857002000000        mov       byte ptr [rbp + 0x270], 0
0x000144860690:  488b8568020000        mov       rax, qword ptr [rbp + 0x268]
0x000144860697:  4883f810              cmp       rax, 0x10
0x00014486069b:  7230                  jb        0x1448606cd
0x00014486069d:  48ffc0                inc       rax
0x0001448606a0:  488b8d50020000        mov       rcx, qword ptr [rbp + 0x250]
0x0001448606a7:  488bd1                mov       rdx, rcx
0x0001448606aa:  483d00100000          cmp       rax, 0x1000
0x0001448606b0:  7215                  jb        0x1448606c7
0x0001448606b2:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x0001448606b6:  482bd1                sub       rdx, rcx
0x0001448606b9:  488d42f8              lea       rax, [rdx - 8]
0x0001448606bd:  4883f81f              cmp       rax, 0x1f
0x0001448606c1:  0f8712030000          ja        0x1448609d9
0x0001448606c7:  e8e4290e00            call      0x1449430b0
0x0001448606cc:  90                    nop       
0x0001448606cd:  660f6f056b4d9702      movdqa    xmm0, xmmword ptr [rip + 0x2974d6b]
0x0001448606d5:  660f7f8560020000      movdqa    xmmword ptr [rbp + 0x260], xmm0
0x0001448606dd:  c6855002000000        mov       byte ptr [rbp + 0x250], 0
0x0001448606e4:  488b8538020000        mov       rax, qword ptr [rbp + 0x238]
0x0001448606eb:  4883f810              cmp       rax, 0x10
0x0001448606ef:  7230                  jb        0x144860721
0x0001448606f1:  48ffc0                inc       rax
0x0001448606f4:  488b8d20020000        mov       rcx, qword ptr [rbp + 0x220]
0x0001448606fb:  488bd1                mov       rdx, rcx
0x0001448606fe:  483d00100000          cmp       rax, 0x1000
0x000144860704:  7215                  jb        0x14486071b
0x000144860706:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014486070a:  482bd1                sub       rdx, rcx
0x00014486070d:  488d42f8              lea       rax, [rdx - 8]
0x000144860711:  4883f81f              cmp       rax, 0x1f
0x000144860715:  0f87be020000          ja        0x1448609d9
0x00014486071b:  e890290e00            call      0x1449430b0
0x000144860720:  90                    nop       
0x000144860721:  488b8db0030000        mov       rcx, qword ptr [rbp + 0x3b0]
0x000144860728:  4833cc                xor       rcx, rsp
0x00014486072b:  e8b00e2c01            call      0x145b215e0
0x000144860730:  488b9c2420050000      mov       rbx, qword ptr [rsp + 0x520]
0x000144860738:  0f28b424c0040000      movaps    xmm6, xmmword ptr [rsp + 0x4c0]
0x000144860740:  4881c4d0040000        add       rsp, 0x4d0
0x000144860747:  415f                  pop       r15
0x000144860749:  415e                  pop       r14
0x00014486074b:  415d                  pop       r13
0x00014486074d:  415c                  pop       r12
0x00014486074f:  5f                    pop       rdi
0x000144860750:  5e                    pop       rsi
0x000144860751:  5d                    pop       rbp
0x000144860752:  c3                    ret       
0x000144860753:  e8c80d2f01            call      0x145b51520
0x000144860758:  90                    nop       
0x000144860759:  488d8de0010000        lea       rcx, [rbp + 0x1e0]
0x000144860760:  e88ba6f5fb            call      0x1407badf0
0x000144860765:  488d15d4644a03        lea       rdx, [rip + 0x34a64d4]
0x00014486076c:  488d8de0010000        lea       rcx, [rbp + 0x1e0]
0x000144860773:  e8d8282e01            call      0x145b43050
0x000144860778:  90                    nop       
0x000144860779:  4533c0                xor       r8d, r8d
0x00014486077c:  488d1535328602        lea       rdx, [rip + 0x2863235]
0x000144860783:  488d4df0              lea       rcx, [rbp - 0x10]
0x000144860787:  e8949c2aff            call      0x143b0a420
0x00014486078c:  488d159dad4a03        lea       rdx, [rip + 0x34aad9d]
0x000144860793:  488d4df0              lea       rcx, [rbp - 0x10]
0x000144860797:  e8b4282e01            call      0x145b43050
0x00014486079c:  90                    nop       
0x00014486079d:  4183befc00000000      cmp       dword ptr [r14 + 0xfc], 0
0x0001448607a5:  7520                  jne       0x1448607c7
0x0001448607a7:  488d15e2338602        lea       rdx, [rip + 0x28633e2]
0x0001448607ae:  488d8d70030000        lea       rcx, [rbp + 0x370]
0x0001448607b5:  e81637f8fb            call      0x1407e3ed0
0x0001448607ba:  90                    nop       
0x0001448607bb:  897c2460              mov       dword ptr [rsp + 0x60], edi
0x0001448607bf:  41bc02000000          mov       r12d, 2
0x0001448607c5:  eb3e                  jmp       0x144860805
0x0001448607c7:  488d8df8010000        lea       rcx, [rbp + 0x1f8]
0x0001448607ce:  e81d060000            call      0x144860df0
0x0001448607d3:  0f1000                movups    xmm0, xmmword ptr [rax]
0x0001448607d6:  0f2985f0000000        movaps    xmmword ptr [rbp + 0xf0], xmm0
0x0001448607dd:  4d8d86fc000000        lea       r8, [r14 + 0xfc]
0x0001448607e4:  488d95f0000000        lea       rdx, [rbp + 0xf0]
0x0001448607eb:  488d8d90030000        lea       rcx, [rbp + 0x390]
0x0001448607f2:  e81976f8fb            call      0x1407e7e10
0x0001448607f7:  41bc02000000          mov       r12d, 2
0x0001448607fd:  418bfc                mov       edi, r12d
0x000144860800:  4489642460            mov       dword ptr [rsp + 0x60], r12d
0x000144860805:  488bd0                mov       rdx, rax
0x000144860808:  488d8dc0020000        lea       rcx, [rbp + 0x2c0]
0x00014486080f:  e8bc35f8fb            call      0x1407e3dd0
0x000144860814:  90                    nop       
0x000144860815:  40f6c702              test      dil, 2
0x000144860819:  7414                  je        0x14486082f
0x00014486081b:  83e7fd                and       edi, 0xfffffffd
0x00014486081e:  897c2460              mov       dword ptr [rsp + 0x60], edi
0x000144860822:  488d8d90030000        lea       rcx, [rbp + 0x390]
0x000144860829:  e84235f8fb            call      0x1407e3d70
0x00014486082e:  90                    nop       
0x00014486082f:  40f6c701              test      dil, 1
0x000144860833:  7413                  je        0x144860848
0x000144860835:  83e7fe                and       edi, 0xfffffffe
0x000144860838:  897c2460              mov       dword ptr [rsp + 0x60], edi
0x00014486083c:  488d8d70030000        lea       rcx, [rbp + 0x370]
0x000144860843:  e82835f8fb            call      0x1407e3d70
0x000144860848:  0f100599ff5503        movups    xmm0, xmmword ptr [rip + 0x355ff99]
0x00014486084f:  0f2985c0000000        movaps    xmmword ptr [rbp + 0xc0], xmm0
0x000144860856:  b202                  mov       dl, 2
0x000144860858:  488d8dc0000000        lea       rcx, [rbp + 0xc0]
0x00014486085f:  e82c92f6fb            call      0x1407c9a90
0x000144860864:  84c0                  test      al, al
0x000144860866:  7465                  je        0x1448608cd
0x000144860868:  488d053d889502        lea       rax, [rip + 0x295883d]
0x00014486086f:  488945c0              mov       qword ptr [rbp - 0x40], rax
0x000144860873:  488b45c0              mov       rax, qword ptr [rbp - 0x40]
0x000144860877:  482dacdb2600          sub       rax, 0x26dbac
0x00014486087d:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x000144860882:  488d8dc0020000        lea       rcx, [rbp + 0x2c0]
0x000144860889:  e81231f8fb            call      0x1407e39a0
0x00014486088e:  48894580              mov       qword ptr [rbp - 0x80], rax
0x000144860892:  0f10354fff5503        movups    xmm6, xmmword ptr [rip + 0x355ff4f]
0x000144860899:  488d542470            lea       rdx, [rsp + 0x70]
0x00014486089e:  488d4da0              lea       rcx, [rbp - 0x60]
0x0001448608a2:  e88971f8fb            call      0x1407e7a30
0x0001448608a7:  0f1000                movups    xmm0, xmmword ptr [rax]
0x0001448608aa:  0f29442470            movaps    xmmword ptr [rsp + 0x70], xmm0
0x0001448608af:  0f29b590020000        movaps    xmmword ptr [rbp + 0x290], xmm6
0x0001448608b6:  4c8d4d80              lea       r9, [rbp - 0x80]
0x0001448608ba:  4c8d442470            lea       r8, [rsp + 0x70]
0x0001448608bf:  b202                  mov       dl, 2
0x0001448608c1:  488d8d90020000        lea       rcx, [rbp + 0x290]
0x0001448608c8:  e80382f8fb            call      0x1407e8ad0
0x0001448608cd:  488d8dc0020000        lea       rcx, [rbp + 0x2c0]
0x0001448608d4:  e8c730f8fb            call      0x1407e39a0
0x0001448608d9:  488bd0                mov       rdx, rax
0x0001448608dc:  458bc4                mov       r8d, r12d
0x0001448608df:  488d4df0              lea       rcx, [rbp - 0x10]
0x0001448608e3:  e8389b2aff            call      0x143b0a420
0x0001448608e8:  488d1541ac4a03        lea       rdx, [rip + 0x34aac41]
0x0001448608ef:  488d4df0              lea       rcx, [rbp - 0x10]
0x0001448608f3:  e858272e01            call      0x145b43050
0x0001448608f8:  90                    nop       
0x0001448608f9:  488d8d08020000        lea       rcx, [rbp + 0x208]
0x000144860900:  e80b050000            call      0x144860e10
0x000144860905:  0f1000                movups    xmm0, xmmword ptr [rax]
0x000144860908:  0f2985d0000000        movaps    xmmword ptr [rbp + 0xd0], xmm0
0x00014486090f:  4c8d45b0              lea       r8, [rbp - 0x50]
0x000144860913:  488d95d0000000        lea       rdx, [rbp + 0xd0]
0x00014486091a:  488d8de0020000        lea       rcx, [rbp + 0x2e0]
0x000144860921:  e8ea74f8fb            call      0x1407e7e10
0x000144860926:  90                    nop       
0x000144860927:  0f1005bafe5503        movups    xmm0, xmmword ptr [rip + 0x355feba]
0x00014486092e:  0f2985e0000000        movaps    xmmword ptr [rbp + 0xe0], xmm0
0x000144860935:  b202                  mov       dl, 2
0x000144860937:  488d8de0000000        lea       rcx, [rbp + 0xe0]
0x00014486093e:  e84d91f6fb            call      0x1407c9a90
0x000144860943:  84c0                  test      al, al
0x000144860945:  7463                  je        0x1448609aa
0x000144860947:  488d05aaab9702        lea       rax, [rip + 0x297abaa]
0x00014486094e:  48894580              mov       qword ptr [rbp - 0x80], rax
0x000144860952:  488b4580              mov       rax, qword ptr [rbp - 0x80]
0x000144860956:  482df8ff2800          sub       rax, 0x28fff8
0x00014486095c:  48894580              mov       qword ptr [rbp - 0x80], rax
0x000144860960:  488d8de0020000        lea       rcx, [rbp + 0x2e0]
0x000144860967:  e83430f8fb            call      0x1407e39a0
0x00014486096c:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x000144860971:  0f103570fe5503        movups    xmm6, xmmword ptr [rip + 0x355fe70]
0x000144860978:  488d5580              lea       rdx, [rbp - 0x80]
0x00014486097c:  488d4da0              lea       rcx, [rbp - 0x60]
0x000144860980:  e8ab70f8fb            call      0x1407e7a30
0x000144860985:  0f1000                movups    xmm0, xmmword ptr [rax]
0x000144860988:  0f298590020000        movaps    xmmword ptr [rbp + 0x290], xmm0
0x00014486098f:  0f297580              movaps    xmmword ptr [rbp - 0x80], xmm6
0x000144860993:  4c8d4c2470            lea       r9, [rsp + 0x70]
0x000144860998:  4c8d8590020000        lea       r8, [rbp + 0x290]
0x00014486099f:  b202                  mov       dl, 2
0x0001448609a1:  488d4d80              lea       rcx, [rbp - 0x80]
0x0001448609a5:  e82681f8fb            call      0x1407e8ad0
0x0001448609aa:  488d8de0020000        lea       rcx, [rbp + 0x2e0]
0x0001448609b1:  e8ea2ff8fb            call      0x1407e39a0
0x0001448609b6:  488bd0                mov       rdx, rax
0x0001448609b9:  41b803000000          mov       r8d, 3
0x0001448609bf:  488d4df0              lea       rcx, [rbp - 0x10]
0x0001448609c3:  e8589a2aff            call      0x143b0a420
0x0001448609c8:  488d1561ab4a03        lea       rdx, [rip + 0x34aab61]
0x0001448609cf:  488d4df0              lea       rcx, [rbp - 0x10]
0x0001448609d3:  e878262e01            call      0x145b43050
0x0001448609d8:  90                    nop       
0x0001448609d9:  e8420b2f01            call      0x145b51520
0x0001448609de:  cc                    int3      
0x0001448609df:  cc                    int3      
0x0001448609e0:  4883ec48              sub       rsp, 0x48
0x0001448609e4:  4c8b8198070000        mov       r8, qword ptr [rcx + 0x798]
0x0001448609eb:  488d542420            lea       rdx, [rsp + 0x20]
0x0001448609f0:  0f1081a8070000        movups    xmm0, xmmword ptr [rcx + 0x7a8]
0x0001448609f7:  0f1089b8070000        movups    xmm1, xmmword ptr [rcx + 0x7b8]
0x0001448609fe:  498b00                mov       rax, qword ptr [r8]
0x000144860a01:  498bc8                mov       rcx, r8
0x000144860a04:  0f29442420            movaps    xmmword ptr [rsp + 0x20], xmm0
0x000144860a09:  0f294c2430            movaps    xmmword ptr [rsp + 0x30], xmm1
0x000144860a0e:  488b80a8020000        mov       rax, qword ptr [rax + 0x2a8]
0x000144860a15:  ff151df38d01          call      qword ptr [rip + 0x18df31d]
0x000144860a1b:  4883c448              add       rsp, 0x48
0x000144860a1f:  c3                    ret       
0x000144860a20:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000144860a25:  4889742410            mov       qword ptr [rsp + 0x10], rsi
0x000144860a2a:  57                    push      rdi
0x000144860a2b:  4883ec70              sub       rsp, 0x70
0x000144860a2f:  488bb198070000        mov       rsi, qword ptr [rcx + 0x798]
0x000144860a36:  488bd9                mov       rbx, rcx
0x000144860a39:  488b06                mov       rax, qword ptr [rsi]
0x000144860a3c:  488bb8f8000000        mov       rdi, qword ptr [rax + 0xf8]
0x000144860a43:  488b01                mov       rax, qword ptr [rcx]
0x000144860a46:  488b80c8000000        mov       rax, qword ptr [rax + 0xc8]
0x000144860a4d:  ff15e5f28d01          call      qword ptr [rip + 0x18df2e5]
0x000144860a53:  8b93c0070000          mov       edx, dword ptr [rbx + 0x7c0]
0x000144860a59:  41b001                mov       r8b, 1
0x000144860a5c:  488b0d05ee5803        mov       rcx, qword ptr [rip + 0x358ee05]
0x000144860a63:  440fb6c8              movzx     r9d, al
0x000144860a67:  0f1083a8070000        movups    xmm0, xmmword ptr [rbx + 0x7a8]
0x000144860a6e:  488bc7                mov       rax, rdi
0x000144860a71:  89542468              mov       dword ptr [rsp + 0x68], edx
0x000144860a75:  f20f108bb8070000      movsd     xmm1, qword ptr [rbx + 0x7b8]
0x000144860a7d:  0fb793c6070000        movzx     edx, word ptr [rbx + 0x7c6]
0x000144860a84:  668954246e            mov       word ptr [rsp + 0x6e], dx
0x000144860a89:  0fb793c4070000        movzx     edx, word ptr [rbx + 0x7c4]
0x000144860a90:  48894c2440            mov       qword ptr [rsp + 0x40], rcx
0x000144860a95:  0fb70dd4ed5803        movzx     ecx, word ptr [rip + 0x358edd4]
0x000144860a9c:  668954246c            mov       word ptr [rsp + 0x6c], dx
0x000144860aa1:  488d542440            lea       rdx, [rsp + 0x40]
0x000144860aa6:  66894c2448            mov       word ptr [rsp + 0x48], cx
0x000144860aab:  488bce                mov       rcx, rsi
0x000144860aae:  c744242803000000      mov       dword ptr [rsp + 0x28], 3
0x000144860ab6:  0f11442450            movups    xmmword ptr [rsp + 0x50], xmm0
0x000144860abb:  c644242000            mov       byte ptr [rsp + 0x20], 0
0x000144860ac0:  f20f114c2460          movsd     qword ptr [rsp + 0x60], xmm1
0x000144860ac6:  ff156cf28d01          call      qword ptr [rip + 0x18df26c]
0x000144860acc:  4c8d5c2470            lea       r11, [rsp + 0x70]
0x000144860ad1:  498b5b10              mov       rbx, qword ptr [r11 + 0x10]
0x000144860ad5:  498b7318              mov       rsi, qword ptr [r11 + 0x18]
0x000144860ad9:  498be3                mov       rsp, r11
0x000144860adc:  5f                    pop       rdi
0x000144860add:  c3                    ret       
0x000144860ade:  cc                    int3      
0x000144860adf:  cc                    int3      
0x000144860ae0:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000144860ae5:  57                    push      rdi
0x000144860ae6:  4883ec40              sub       rsp, 0x40
0x000144860aea:  488bd9                mov       rbx, rcx
0x000144860aed:  8bfa                  mov       edi, edx
0x000144860aef:  488b8998070000        mov       rcx, qword ptr [rcx + 0x798]
0x000144860af6:  488d542420            lea       rdx, [rsp + 0x20]
0x000144860afb:  0f1083a8070000        movups    xmm0, xmmword ptr [rbx + 0x7a8]
0x000144860b02:  488b01                mov       rax, qword ptr [rcx]
0x000144860b05:  0f108bb8070000        movups    xmm1, xmmword ptr [rbx + 0x7b8]
0x000144860b0c:  0f29442420            movaps    xmmword ptr [rsp + 0x20], xmm0
0x000144860b11:  488b8008010000        mov       rax, qword ptr [rax + 0x108]
0x000144860b18:  0f294c2430            movaps    xmmword ptr [rsp + 0x30], xmm1
0x000144860b1d:  ff1515f28d01          call      qword ptr [rip + 0x18df215]
0x000144860b23:  448bc8                mov       r9d, eax
0x000144860b26:  85c0                  test      eax, eax
0x000144860b28:  781d                  js        0x144860b47
0x000144860b2a:  488b8b98070000        mov       rcx, qword ptr [rbx + 0x798]
0x000144860b31:  448bc7                mov       r8d, edi
0x000144860b34:  488b11                mov       rdx, qword ptr [rcx]
0x000144860b37:  488b82d8000000        mov       rax, qword ptr [rdx + 0xd8]
0x000144860b3e:  418bd1                mov       edx, r9d
0x000144860b41:  ff15f1f18d01          call      qword ptr [rip + 0x18df1f1]
0x000144860b47:  488b5c2450            mov       rbx, qword ptr [rsp + 0x50]
0x000144860b4c:  4883c440              add       rsp, 0x40
0x000144860b50:  5f                    pop       rdi
0x000144860b51:  c3                    ret       
0x000144860b52:  cc                    int3      
0x000144860b53:  cc                    int3      
0x000144860b54:  cc                    int3      
0x000144860b55:  cc                    int3      
0x000144860b56:  cc                    int3      
0x000144860b57:  cc                    int3      
0x000144860b58:  cc                    int3      
0x000144860b59:  cc                    int3      
0x000144860b5a:  cc                    int3      
0x000144860b5b:  cc                    int3      
0x000144860b5c:  cc                    int3      
0x000144860b5d:  cc                    int3      
0x000144860b5e:  cc                    int3      
0x000144860b5f:  cc                    int3      
0x000144860b60:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000144860b65:  57                    push      rdi
0x000144860b66:  4883ec40              sub       rsp, 0x40
0x000144860b6a:  488bd9                mov       rbx, rcx
0x000144860b6d:  8bfa                  mov       edi, edx
0x000144860b6f:  488b8998070000        mov       rcx, qword ptr [rcx + 0x798]
0x000144860b76:  488d542420            lea       rdx, [rsp + 0x20]
0x000144860b7b:  0f1083a8070000        movups    xmm0, xmmword ptr [rbx + 0x7a8]
0x000144860b82:  488b01                mov       rax, qword ptr [rcx]
0x000144860b85:  0f108bb8070000        movups    xmm1, xmmword ptr [rbx + 0x7b8]
0x000144860b8c:  0f29442420            movaps    xmmword ptr [rsp + 0x20], xmm0
0x000144860b91:  488b8008010000        mov       rax, qword ptr [rax + 0x108]
0x000144860b98:  0f294c2430            movaps    xmmword ptr [rsp + 0x30], xmm1
0x000144860b9d:  ff1595f18d01          call      qword ptr [rip + 0x18df195]
0x000144860ba3:  448bc8                mov       r9d, eax
0x000144860ba6:  85c0                  test      eax, eax
0x000144860ba8:  781d                  js        0x144860bc7
0x000144860baa:  488b8b98070000        mov       rcx, qword ptr [rbx + 0x798]
0x000144860bb1:  448bc7                mov       r8d, edi
0x000144860bb4:  488b11                mov       rdx, qword ptr [rcx]
0x000144860bb7:  488b82e0000000        mov       rax, qword ptr [rdx + 0xe0]
0x000144860bbe:  418bd1                mov       edx, r9d
0x000144860bc1:  ff1571f18d01          call      qword ptr [rip + 0x18df171]
0x000144860bc7:  488b5c2450            mov       rbx, qword ptr [rsp + 0x50]
0x000144860bcc:  4883c440              add       rsp, 0x40
0x000144860bd0:  5f                    pop       rdi
0x000144860bd1:  c3                    ret       
0x000144860bd2:  cc                    int3      
0x000144860bd3:  cc                    int3      
0x000144860bd4:  cc                    int3      
0x000144860bd5:  cc                    int3      
0x000144860bd6:  cc                    int3      
0x000144860bd7:  cc                    int3      
0x000144860bd8:  cc                    int3      
0x000144860bd9:  cc                    int3      
0x000144860bda:  cc                    int3      
0x000144860bdb:  cc                    int3      
0x000144860bdc:  cc                    int3      
0x000144860bdd:  cc                    int3      
0x000144860bde:  cc                    int3      
0x000144860bdf:  cc                    int3      
0x000144860be0:  488b8998070000        mov       rcx, qword ptr [rcx + 0x798]
0x000144860be7:  488b01                mov       rax, qword ptr [rcx]
0x000144860bea:  488b80d0000000        mov       rax, qword ptr [rax + 0xd0]
0x000144860bf1:  48ff2540f18d01        jmp       qword ptr [rip + 0x18df140]
0x000144860bf8:  cc                    int3      
0x000144860bf9:  cc                    int3      
0x000144860bfa:  cc                    int3      
0x000144860bfb:  cc                    int3      
0x000144860bfc:  cc                    int3      
0x000144860bfd:  cc                    int3      
0x000144860bfe:  cc                    int3      
0x000144860bff:  cc                    int3      
