; function_of: str.Updating Rupp token in header, vtab.RuppTokenProcessor, vtab.ServerRuppGenerator, vtab.TokenTlv, vtab.TraceIdTlv, vtab.lambda.5653-Token-amp
; xref site 0x142275d6a -> str.Updating Rupp token in header @ 0x146f0ae28
; xref site 0x1422761ae -> vtab.ServerRuppGenerator @ 0x146c988c8
; xref site 0x1422762b7 -> vtab.RuppTokenProcessor @ 0x146c989b8
; xref site 0x1422762f6 -> vtab.TokenTlv @ 0x146c988f0
; xref site 0x142276333 -> vtab.RuppTokenProcessor @ 0x146c989b8
; xref site 0x142276538 -> vtab.lambda.5653-Token-amp @ 0x146c98890
; xref site 0x142276695 -> vtab.TokenTlv @ 0x146c988f0
; xref site 0x142276709 -> vtab.TraceIdTlv @ 0x146c98918
; xref site 0x142276997 -> vtab.TokenTlv @ 0x146c988f0
; xref site 0x142276a0b -> vtab.TraceIdTlv @ 0x146c98918
; range 0x142275c70 .. 0x142276b50  (3808 bytes)

0x000142275c70:  4055                  push      rbp
0x000142275c72:  4156                  push      r14
0x000142275c74:  4157                  push      r15
0x000142275c76:  4881ecf0000000        sub       rsp, 0xf0
0x000142275c7d:  488b056cdaa905        mov       rax, qword ptr [rip + 0x5a9da6c]
0x000142275c84:  4833c4                xor       rax, rsp
0x000142275c87:  48898424e0000000      mov       qword ptr [rsp + 0xe0], rax
0x000142275c8f:  440fb6fa              movzx     r15d, dl
0x000142275c93:  4d8bf0                mov       r14, r8
0x000142275c96:  b201                  mov       dl, 1
0x000142275c98:  488be9                mov       rbp, rcx
0x000142275c9b:  e8c0f5ffff            call      0x142275260
0x000142275ca0:  85c0                  test      eax, eax
0x000142275ca2:  790a                  jns       0x142275cae
0x000142275ca4:  b808000000            mov       eax, 8
0x000142275ca9:  e933020000            jmp       0x142275ee1
0x000142275cae:  49837e0810            cmp       qword ptr [r14 + 8], 0x10
0x000142275cb3:  740a                  je        0x142275cbf
0x000142275cb5:  b809000000            mov       eax, 9
0x000142275cba:  e922020000            jmp       0x142275ee1
0x000142275cbf:  410f2806              movaps    xmm0, xmmword ptr [r14]
0x000142275cc3:  4863c8                movsxd    rcx, eax
0x000142275cc6:  488b4560              mov       rax, qword ptr [rbp + 0x60]
0x000142275cca:  0f29442440            movaps    xmmword ptr [rsp + 0x40], xmm0
0x000142275ccf:  4889bc2428010000      mov       qword ptr [rsp + 0x128], rdi
0x000142275cd7:  660f73d808            psrldq    xmm0, 8
0x000142275cdc:  488b3cc8              mov       rdi, qword ptr [rax + rcx*8]
0x000142275ce0:  66480f7ec0            movq      rax, xmm0
0x000142275ce5:  4883f810              cmp       rax, 0x10
0x000142275ce9:  7404                  je        0x142275cef
0x000142275ceb:  32c0                  xor       al, al
0x000142275ced:  eb1c                  jmp       0x142275d0b
0x000142275cef:  488b4c2440            mov       rcx, qword ptr [rsp + 0x40]
0x000142275cf4:  488b4709              mov       rax, qword ptr [rdi + 9]
0x000142275cf8:  482b01                sub       rax, qword ptr [rcx]
0x000142275cfb:  7508                  jne       0x142275d05
0x000142275cfd:  488b4711              mov       rax, qword ptr [rdi + 0x11]
0x000142275d01:  482b4108              sub       rax, qword ptr [rcx + 8]
0x000142275d05:  4885c0                test      rax, rax
0x000142275d08:  0f94c0                sete      al
0x000142275d0b:  443a7f08              cmp       r15b, byte ptr [rdi + 8]
0x000142275d0f:  750e                  jne       0x142275d1f
0x000142275d11:  84c0                  test      al, al
0x000142275d13:  740a                  je        0x142275d1f
0x000142275d15:  b80c000000            mov       eax, 0xc
0x000142275d1a:  e9ba010000            jmp       0x142275ed9
0x000142275d1f:  488b0522a2ae05        mov       rax, qword ptr [rip + 0x5aea222]
0x000142275d26:  48899c2418010000      mov       qword ptr [rsp + 0x118], rbx
0x000142275d2e:  48c7c3ffffffff        mov       rbx, 0xffffffffffffffff
0x000142275d35:  4889b42420010000      mov       qword ptr [rsp + 0x120], rsi
0x000142275d3d:  33f6                  xor       esi, esi
0x000142275d3f:  3c06                  cmp       al, 6
0x000142275d41:  0f829b000000          jb        0x142275de2
0x000142275d47:  48c1e808              shr       rax, 8
0x000142275d4b:  3c06                  cmp       al, 6
0x000142275d4d:  0f828f000000          jb        0x142275de2
0x000142275d53:  488d05c0e6e904        lea       rax, [rip + 0x4e9e6c0]
0x000142275d5a:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x000142275d5f:  488bc3                mov       rax, rbx
0x000142275d62:  488b4c2430            mov       rcx, qword ptr [rsp + 0x30]
0x000142275d67:  488d0dba50c904        lea       rcx, [rip + 0x4c950ba]
0x000142275d6e:  48894c2470            mov       qword ptr [rsp + 0x70], rcx
0x000142275d73:  48ffc0                inc       rax
0x000142275d76:  40383401              cmp       byte ptr [rcx + rax], sil
0x000142275d7a:  75f7                  jne       0x142275d73
0x000142275d7c:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x000142275d81:  4c8d8c2480000000      lea       r9, [rsp + 0x80]
0x000142275d89:  0f284c2470            movaps    xmm1, xmmword ptr [rsp + 0x70]
0x000142275d8e:  488d8424c0000000      lea       rax, [rsp + 0xc0]
0x000142275d96:  4889442468            mov       qword ptr [rsp + 0x68], rax
0x000142275d9b:  4c8d842490000000      lea       r8, [rsp + 0x90]
0x000142275da3:  4889742460            mov       qword ptr [rsp + 0x60], rsi
0x000142275da8:  488d8c24a0000000      lea       rcx, [rsp + 0xa0]
0x000142275db0:  0f28442460            movaps    xmm0, xmmword ptr [rsp + 0x60]
0x000142275db5:  b206                  mov       dl, 6
0x000142275db7:  660f7f842480000000    movdqa    xmmword ptr [rsp + 0x80], xmm0
0x000142275dc0:  0f100581a1ae05        movups    xmm0, xmmword ptr [rip + 0x5aea181]
0x000142275dc7:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x000142275dcc:  660f7f8c2490000000    movdqa    xmmword ptr [rsp + 0x90], xmm1
0x000142275dd5:  0f298424a0000000      movaps    xmmword ptr [rsp + 0xa0], xmm0
0x000142275ddd:  e8ee9c6e02            call      0x14495fad0
0x000142275de2:  ff4548                inc       dword ptr [rbp + 0x48]
0x000142275de5:  410f2806              movaps    xmm0, xmmword ptr [r14]
0x000142275de9:  4889b580000000        mov       qword ptr [rbp + 0x80], rsi
0x000142275df0:  44887f08              mov       byte ptr [rdi + 8], r15b
0x000142275df4:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x000142275dfa:  4584ff                test      r15b, r15b
0x000142275dfd:  0f84b4000000          je        0x142275eb7
0x000142275e03:  48837c243810          cmp       qword ptr [rsp + 0x38], 0x10
0x000142275e09:  0f85a8000000          jne       0x142275eb7
0x000142275e0f:  488b442430            mov       rax, qword ptr [rsp + 0x30]
0x000142275e14:  0f1000                movups    xmm0, xmmword ptr [rax]
0x000142275e17:  0f114709              movups    xmmword ptr [rdi + 9], xmm0
0x000142275e1b:  488b0526a1ae05        mov       rax, qword ptr [rip + 0x5aea126]
0x000142275e22:  3c06                  cmp       al, 6
0x000142275e24:  0f829d000000          jb        0x142275ec7
0x000142275e2a:  48c1e808              shr       rax, 8
0x000142275e2e:  3c06                  cmp       al, 6
0x000142275e30:  0f8291000000          jb        0x142275ec7
0x000142275e36:  488d0547b3d704        lea       rax, [rip + 0x4d7b347]
0x000142275e3d:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x000142275e42:  488b442430            mov       rax, qword ptr [rsp + 0x30]
0x000142275e47:  4805949ef1ff          add       rax, -0xe616c
0x000142275e4d:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x000142275e52:  48ffc3                inc       rbx
0x000142275e55:  40383418              cmp       byte ptr [rax + rbx], sil
0x000142275e59:  75f7                  jne       0x142275e52
0x000142275e5b:  4889742450            mov       qword ptr [rsp + 0x50], rsi
0x000142275e60:  488d8424d0000000      lea       rax, [rsp + 0xd0]
0x000142275e68:  4889442458            mov       qword ptr [rsp + 0x58], rax
0x000142275e6d:  4c8d4c2450            lea       r9, [rsp + 0x50]
0x000142275e72:  0f28442450            movaps    xmm0, xmmword ptr [rsp + 0x50]
0x000142275e77:  4c8d442440            lea       r8, [rsp + 0x40]
0x000142275e7c:  48895c2448            mov       qword ptr [rsp + 0x48], rbx
0x000142275e81:  488d8c24b0000000      lea       rcx, [rsp + 0xb0]
0x000142275e89:  0f284c2440            movaps    xmm1, xmmword ptr [rsp + 0x40]
0x000142275e8e:  b206                  mov       dl, 6
0x000142275e90:  660f7f442450          movdqa    xmmword ptr [rsp + 0x50], xmm0
0x000142275e96:  0f1005aba0ae05        movups    xmm0, xmmword ptr [rip + 0x5aea0ab]
0x000142275e9d:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x000142275ea2:  660f7f4c2440          movdqa    xmmword ptr [rsp + 0x40], xmm1
0x000142275ea8:  0f298424b0000000      movaps    xmmword ptr [rsp + 0xb0], xmm0
0x000142275eb0:  e81b9c6e02            call      0x14495fad0
0x000142275eb5:  eb10                  jmp       0x142275ec7
0x000142275eb7:  40887708              mov       byte ptr [rdi + 8], sil
0x000142275ebb:  0f57c0                xorps     xmm0, xmm0
0x000142275ebe:  0f114709              movups    xmmword ptr [rdi + 9], xmm0
0x000142275ec2:  be09000000            mov       esi, 9
0x000142275ec7:  488b9c2418010000      mov       rbx, qword ptr [rsp + 0x118]
0x000142275ecf:  8bc6                  mov       eax, esi
0x000142275ed1:  488bb42420010000      mov       rsi, qword ptr [rsp + 0x120]
0x000142275ed9:  488bbc2428010000      mov       rdi, qword ptr [rsp + 0x128]
0x000142275ee1:  488b8c24e0000000      mov       rcx, qword ptr [rsp + 0xe0]
0x000142275ee9:  4833cc                xor       rcx, rsp
0x000142275eec:  e8efb68a03            call      0x145b215e0
0x000142275ef1:  4881c4f0000000        add       rsp, 0xf0
0x000142275ef8:  415f                  pop       r15
0x000142275efa:  415e                  pop       r14
0x000142275efc:  5d                    pop       rbp
0x000142275efd:  c3                    ret       
0x000142275efe:  cc                    int3      
0x000142275eff:  cc                    int3      
0x000142275f00:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x000142275f05:  48896c2418            mov       qword ptr [rsp + 0x18], rbp
0x000142275f0a:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x000142275f0f:  57                    push      rdi
0x000142275f10:  4154                  push      r12
0x000142275f12:  4155                  push      r13
0x000142275f14:  4156                  push      r14
0x000142275f16:  4157                  push      r15
0x000142275f18:  4883ec70              sub       rsp, 0x70
0x000142275f1c:  488b05cdd7a905        mov       rax, qword ptr [rip + 0x5a9d7cd]
0x000142275f23:  4833c4                xor       rax, rsp
0x000142275f26:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x000142275f2b:  488b1a                mov       rbx, qword ptr [rdx]
0x000142275f2e:  488be9                mov       rbp, rcx
0x000142275f31:  488b7208              mov       rsi, qword ptr [rdx + 8]
0x000142275f35:  4c8d3c1e              lea       r15, [rsi + rbx]
0x000142275f39:  493bdf                cmp       rbx, r15
0x000142275f3c:  0f8345010000          jae       0x142276087
0x000142275f42:  4c8bf3                mov       r14, rbx
0x000142275f45:  4c8d25b4a0d8fd        lea       r12, [rip - 0x2275f4c]
0x000142275f4c:  4533ed                xor       r13d, r13d
0x000142275f4f:  90                    nop       
0x000142275f50:  498bc6                mov       rax, r14
0x000142275f53:  482bc3                sub       rax, rbx
0x000142275f56:  4803c6                add       rax, rsi
0x000142275f59:  4883f802              cmp       rax, 2
0x000142275f5d:  0f8251010000          jb        0x1422760b4
0x000142275f63:  0fb67b01              movzx     edi, byte ptr [rbx + 1]
0x000142275f67:  4883c0fe              add       rax, -2
0x000142275f6b:  483bf8                cmp       rdi, rax
0x000142275f6e:  0f8740010000          ja        0x1422760b4
0x000142275f74:  0fb603                movzx     eax, byte ptr [rbx]
0x000142275f77:  41b801000000          mov       r8d, 1
0x000142275f7d:  ffc8                  dec       eax
0x000142275f7f:  83f807                cmp       eax, 7
0x000142275f82:  0f87dc000000          ja        0x142276064
0x000142275f88:  4898                  cdqe      
0x000142275f8a:  418b8c84bc602702      mov       ecx, dword ptr [r12 + rax*4 + 0x22760bc]
0x000142275f92:  4903cc                add       rcx, r12
0x000142275f95:  ffe1                  jmp       rcx
0x000142275f97:  4080ff11              cmp       dil, 0x11
0x000142275f9b:  0f8213010000          jb        0x1422760b4
0x000142275fa1:  0fb64302              movzx     eax, byte ptr [rbx + 2]
0x000142275fa5:  884504                mov       byte ptr [rbp + 4], al
0x000142275fa8:  488d4303              lea       rax, [rbx + 3]
0x000142275fac:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000142275fb1:  48c744242810000000    mov       qword ptr [rsp + 0x28], 0x10
0x000142275fba:  0f10442420            movups    xmm0, xmmword ptr [rsp + 0x20]
0x000142275fbf:  0f114508              movups    xmmword ptr [rbp + 8], xmm0
0x000142275fc3:  e9af000000            jmp       0x142276077
0x000142275fc8:  4883ff06              cmp       rdi, 6
0x000142275fcc:  0f858d000000          jne       0x14227605f
0x000142275fd2:  0f57c0                xorps     xmm0, xmm0
0x000142275fd5:  448d4f28              lea       r9d, [rdi + 0x28]
0x000142275fd9:  0f11442430            movups    xmmword ptr [rsp + 0x30], xmm0
0x000142275fde:  8b4302                mov       eax, dword ptr [rbx + 2]
0x000142275fe1:  488d542434            lea       rdx, [rsp + 0x34]
0x000142275fe6:  89442434              mov       dword ptr [rsp + 0x34], eax
0x000142275fea:  8d4ffc                lea       ecx, [rdi - 4]
0x000142275fed:  0fb74306              movzx     eax, word ptr [rbx + 6]
0x000142275ff1:  44884548              mov       byte ptr [rbp + 0x48], r8b
0x000142275ff5:  4c8d4518              lea       r8, [rbp + 0x18]
0x000142275ff9:  6689442432            mov       word ptr [rsp + 0x32], ax
0x000142275ffe:  ff154c98ec03          call      qword ptr [rip + 0x3ec984c]
0x000142276004:  0fb74c2432            movzx     ecx, word ptr [rsp + 0x32]
0x000142276009:  eb47                  jmp       0x142276052
0x00014227600b:  4883ff12              cmp       rdi, 0x12
0x00014227600f:  754e                  jne       0x14227605f
0x000142276011:  6644896c2440          mov       word ptr [rsp + 0x40], r13w
0x000142276017:  4c8d4518              lea       r8, [rbp + 0x18]
0x00014227601b:  44896c2444            mov       dword ptr [rsp + 0x44], r13d
0x000142276020:  448d4f1c              lea       r9d, [rdi + 0x1c]
0x000142276024:  44896c2458            mov       dword ptr [rsp + 0x58], r13d
0x000142276029:  488d542448            lea       rdx, [rsp + 0x48]
0x00014227602e:  0f104302              movups    xmm0, xmmword ptr [rbx + 2]
0x000142276032:  8d4f05                lea       ecx, [rdi + 5]
0x000142276035:  0f11442448            movups    xmmword ptr [rsp + 0x48], xmm0
0x00014227603a:  0fb74312              movzx     eax, word ptr [rbx + 0x12]
0x00014227603e:  6689442442            mov       word ptr [rsp + 0x42], ax
0x000142276043:  44886d48              mov       byte ptr [rbp + 0x48], r13b
0x000142276047:  ff150398ec03          call      qword ptr [rip + 0x3ec9803]
0x00014227604d:  0fb74c2442            movzx     ecx, word ptr [rsp + 0x42]
0x000142276052:  ff15d897ec03          call      qword ptr [rip + 0x3ec97d8]
0x000142276058:  66894546              mov       word ptr [rbp + 0x46], ax
0x00014227605c:  458bc5                mov       r8d, r13d
0x00014227605f:  4585c0                test      r8d, r8d
0x000142276062:  7413                  je        0x142276077
0x000142276064:  418bc0                mov       eax, r8d
0x000142276067:  eb20                  jmp       0x142276089
0x000142276069:  4883ff10              cmp       rdi, 0x10
0x00014227606d:  75f5                  jne       0x142276064
0x00014227606f:  0f104302              movups    xmm0, xmmword ptr [rbx + 2]
0x000142276073:  0f114549              movups    xmmword ptr [rbp + 0x49], xmm0
0x000142276077:  4883c302              add       rbx, 2
0x00014227607b:  4803df                add       rbx, rdi
0x00014227607e:  493bdf                cmp       rbx, r15
0x000142276081:  0f82c9feffff          jb        0x142275f50
0x000142276087:  33c0                  xor       eax, eax
0x000142276089:  488b4c2460            mov       rcx, qword ptr [rsp + 0x60]
0x00014227608e:  4833cc                xor       rcx, rsp
0x000142276091:  e84ab58a03            call      0x145b215e0
0x000142276096:  4c8d5c2470            lea       r11, [rsp + 0x70]
0x00014227609b:  498b5b38              mov       rbx, qword ptr [r11 + 0x38]
0x00014227609f:  498b6b40              mov       rbp, qword ptr [r11 + 0x40]
0x0001422760a3:  498b7348              mov       rsi, qword ptr [r11 + 0x48]
0x0001422760a7:  498be3                mov       rsp, r11
0x0001422760aa:  415f                  pop       r15
0x0001422760ac:  415e                  pop       r14
0x0001422760ae:  415d                  pop       r13
0x0001422760b0:  415c                  pop       r12
0x0001422760b2:  5f                    pop       rdi
0x0001422760b3:  c3                    ret       
0x0001422760b4:  b801000000            mov       eax, 1
0x0001422760b9:  ebce                  jmp       0x142276089
0x0001422760bb:  90                    nop       
0x0001422760bc:  97                    xchg      edi, eax
0x0001422760bd:  5f                    pop       rdi
0x0001422760be:  db 0x27
0x0001422760bf:  027760                add       dh, byte ptr [rdi + 0x60]
0x0001422760c2:  db 0x27
0x0001422760c3:  027760                add       dh, byte ptr [rdi + 0x60]
0x0001422760c6:  db 0x27
0x0001422760c7:  02646027              add       ah, byte ptr [rax + riz*2 + 0x27]
0x0001422760cb:  02646027              add       ah, byte ptr [rax + riz*2 + 0x27]
0x0001422760cf:  02c8                  add       cl, al
0x0001422760d1:  5f                    pop       rdi
0x0001422760d2:  db 0x27
0x0001422760d3:  020b                  add       cl, byte ptr [rbx]
0x0001422760d5:  db 0x60
0x0001422760d6:  db 0x27
0x0001422760d7:  026960                add       ch, byte ptr [rcx + 0x60]
0x0001422760da:  db 0x27
0x0001422760db:  02cc                  add       cl, ah
0x0001422760dd:  cc                    int3      
0x0001422760de:  cc                    int3      
0x0001422760df:  cc                    int3      
0x0001422760e0:  4883ec38              sub       rsp, 0x38
0x0001422760e4:  488b0dad5d7306        mov       rcx, qword ptr [rip + 0x6735dad]
0x0001422760eb:  4c8d0536850306        lea       r8, [rip + 0x6038536]
0x0001422760f2:  41b902000000          mov       r9d, 2
0x0001422760f8:  488d15d94dc904        lea       rdx, [rip + 0x4c94dd9]
0x0001422760ff:  e8ac6a7002            call      0x14497cbb0
0x000142276104:  4883c438              add       rsp, 0x38
0x000142276108:  c3                    ret       
0x000142276109:  cc                    int3      
0x00014227610a:  cc                    int3      
0x00014227610b:  cc                    int3      
0x00014227610c:  cc                    int3      
0x00014227610d:  cc                    int3      
0x00014227610e:  cc                    int3      
0x00014227610f:  cc                    int3      
0x000142276110:  4883ec38              sub       rsp, 0x38
0x000142276114:  488b0d7d5d7306        mov       rcx, qword ptr [rip + 0x6735d7d]
0x00014227611b:  4c8d0586880306        lea       r8, [rip + 0x6038886]
0x000142276122:  41b902000000          mov       r9d, 2
0x000142276128:  488d15814dc904        lea       rdx, [rip + 0x4c94d81]
0x00014227612f:  e87c6a7002            call      0x14497cbb0
0x000142276134:  4883c438              add       rsp, 0x38
0x000142276138:  c3                    ret       
0x000142276139:  cc                    int3      
0x00014227613a:  cc                    int3      
0x00014227613b:  cc                    int3      
0x00014227613c:  cc                    int3      
0x00014227613d:  cc                    int3      
0x00014227613e:  cc                    int3      
0x00014227613f:  cc                    int3      
0x000142276140:  4883ec38              sub       rsp, 0x38
0x000142276144:  488b0d4d5d7306        mov       rcx, qword ptr [rip + 0x6735d4d]
0x00014227614b:  4c8d057e9eae05        lea       r8, [rip + 0x5ae9e7e]
0x000142276152:  41b902000000          mov       r9d, 2
0x000142276158:  488d15914dc904        lea       rdx, [rip + 0x4c94d91]
0x00014227615f:  e87c507002            call      0x14497b1e0
0x000142276164:  4883c438              add       rsp, 0x38
0x000142276168:  c3                    ret       
0x000142276169:  cc                    int3      
0x00014227616a:  cc                    int3      
0x00014227616b:  cc                    int3      
0x00014227616c:  cc                    int3      
0x00014227616d:  cc                    int3      
0x00014227616e:  cc                    int3      
0x00014227616f:  cc                    int3      
0x000142276170:  48894c2408            mov       qword ptr [rsp + 8], rcx
0x000142276175:  53                    push      rbx
0x000142276176:  55                    push      rbp
0x000142276177:  56                    push      rsi
0x000142276178:  57                    push      rdi
0x000142276179:  4156                  push      r14
0x00014227617b:  4883ec40              sub       rsp, 0x40
0x00014227617f:  488bea                mov       rbp, rdx
0x000142276182:  488bf9                mov       rdi, rcx
0x000142276185:  488d05dc26a204        lea       rax, [rip + 0x4a226dc]
0x00014227618c:  488901                mov       qword ptr [rcx], rax
0x00014227618f:  4533f6                xor       r14d, r14d
0x000142276192:  4c897108              mov       qword ptr [rcx + 8], r14
0x000142276196:  4c897110              mov       qword ptr [rcx + 0x10], r14
0x00014227619a:  4c897118              mov       qword ptr [rcx + 0x18], r14
0x00014227619e:  44887120              mov       byte ptr [rcx + 0x20], r14b
0x0001422761a2:  4883c128              add       rcx, 0x28
0x0001422761a6:  e855186d02            call      0x144947a00
0x0001422761ab:  488d051627a204        lea       rax, [rip + 0x4a22716]
0x0001422761b2:  488907                mov       qword ptr [rdi], rax
0x0001422761b5:  488d5f30              lea       rbx, [rdi + 0x30]
0x0001422761b9:  488bd5                mov       rdx, rbp
0x0001422761bc:  488bcb                mov       rcx, rbx
0x0001422761bf:  e89cdd56fe            call      0x1407e3f60
0x0001422761c4:  4883c320              add       rbx, 0x20
0x0001422761c8:  488d4d20              lea       rcx, [rbp + 0x20]
0x0001422761cc:  483bd9                cmp       rbx, rcx
0x0001422761cf:  7416                  je        0x1422761e7
0x0001422761d1:  0f1001                movups    xmm0, xmmword ptr [rcx]
0x0001422761d4:  0f1103                movups    xmmword ptr [rbx], xmm0
0x0001422761d7:  f20f104910            movsd     xmm1, qword ptr [rcx + 0x10]
0x0001422761dc:  f20f114b10            movsd     qword ptr [rbx + 0x10], xmm1
0x0001422761e1:  8b4118                mov       eax, dword ptr [rcx + 0x18]
0x0001422761e4:  894318                mov       dword ptr [rbx + 0x18], eax
0x0001422761e7:  488d5770              lea       rdx, [rdi + 0x70]
0x0001422761eb:  e8902cf3ff            call      0x1421a8e80
0x0001422761f0:  90                    nop       
0x0001422761f1:  c687ac00000000        mov       byte ptr [rdi + 0xac], 0
0x0001422761f8:  4489b7b0000000        mov       dword ptr [rdi + 0xb0], r14d
0x0001422761ff:  488db7b8000000        lea       rsi, [rdi + 0xb8]
0x000142276206:  66c7060100            mov       word ptr [rsi], 1
0x00014227620b:  4c897640              mov       qword ptr [rsi + 0x40], r14
0x00014227620f:  44897648              mov       dword ptr [rsi + 0x48], r14d
0x000142276213:  4c897650              mov       qword ptr [rsi + 0x50], r14
0x000142276217:  4c897658              mov       qword ptr [rsi + 0x58], r14
0x00014227621b:  4c897660              mov       qword ptr [rsi + 0x60], r14
0x00014227621f:  4c897668              mov       qword ptr [rsi + 0x68], r14
0x000142276223:  4c897670              mov       qword ptr [rsi + 0x70], r14
0x000142276227:  488d4e78              lea       rcx, [rsi + 0x78]
0x00014227622b:  48894c2478            mov       qword ptr [rsp + 0x78], rcx
0x000142276230:  488d4118              lea       rax, [rcx + 0x18]
0x000142276234:  488901                mov       qword ptr [rcx], rax
0x000142276237:  4c897108              mov       qword ptr [rcx + 8], r14
0x00014227623b:  48c7411020000000      mov       qword ptr [rcx + 0x10], 0x20
0x000142276243:  c786b0000000ffffffff  mov       dword ptr [rsi + 0xb0], 0xffffffff
0x00014227624d:  c686b400000000        mov       byte ptr [rsi + 0xb4], 0
0x000142276254:  c6877001000009        mov       byte ptr [rdi + 0x170], 9
0x00014227625b:  488d9f78010000        lea       rbx, [rdi + 0x178]
0x000142276262:  4c8933                mov       qword ptr [rbx], r14
0x000142276265:  0f57c0                xorps     xmm0, xmm0
0x000142276268:  33c0                  xor       eax, eax
0x00014227626a:  0f118780010000        movups    xmmword ptr [rdi + 0x180], xmm0
0x000142276271:  48898790010000        mov       qword ptr [rdi + 0x190], rax
0x000142276278:  898798010000          mov       dword ptr [rdi + 0x198], eax
0x00014227627e:  4c89b7a0010000        mov       qword ptr [rdi + 0x1a0], r14
0x000142276285:  4c89b7b0010000        mov       qword ptr [rdi + 0x1b0], r14
0x00014227628c:  48c787b80100000f000000  mov       qword ptr [rdi + 0x1b8], 0xf
0x000142276297:  8887a0010000          mov       byte ptr [rdi + 0x1a0], al
0x00014227629d:  48394510              cmp       qword ptr [rbp + 0x10], rax
0x0001422762a1:  7441                  je        0x1422762e4
0x0001422762a3:  8d4810                lea       ecx, [rax + 0x10]
0x0001422762a6:  e855d56c02            call      0x144943800
0x0001422762ab:  4885c0                test      rax, rax
0x0001422762ae:  0f8485000000          je        0x142276339
0x0001422762b4:  488d0dfd26a204        lea       rcx, [rip + 0x4a226fd]
0x0001422762bb:  488908                mov       qword ptr [rax], rcx
0x0001422762be:  488d4c2478            lea       rcx, [rsp + 0x78]
0x0001422762c3:  483bd9                cmp       rbx, rcx
0x0001422762c6:  7460                  je        0x142276328
0x0001422762c8:  488b0b                mov       rcx, qword ptr [rbx]
0x0001422762cb:  488903                mov       qword ptr [rbx], rax
0x0001422762ce:  4885c9                test      rcx, rcx
0x0001422762d1:  7411                  je        0x1422762e4
0x0001422762d3:  488b01                mov       rax, qword ptr [rcx]
0x0001422762d6:  ba01000000            mov       edx, 1
0x0001422762db:  488b00                mov       rax, qword ptr [rax]
0x0001422762de:  ff15549aec03          call      qword ptr [rip + 0x3ec9a54]
0x0001422762e4:  33db                  xor       ebx, ebx
0x0001422762e6:  8d4b20                lea       ecx, [rbx + 0x20]
0x0001422762e9:  e812d56c02            call      0x144943800
0x0001422762ee:  4885c0                test      rax, rax
0x0001422762f1:  7462                  je        0x142276355
0x0001422762f3:  488d0df625a204        lea       rcx, [rip + 0x4a225f6]
0x0001422762fa:  488908                mov       qword ptr [rax], rcx
0x0001422762fd:  0f57c0                xorps     xmm0, xmm0
0x000142276300:  0f114008              movups    xmmword ptr [rax + 8], xmm0
0x000142276304:  885818                mov       byte ptr [rax + 0x18], bl
0x000142276307:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x00014227630c:  488d542478            lea       rdx, [rsp + 0x78]
0x000142276311:  488bce                mov       rcx, rsi
0x000142276314:  e8b7efffff            call      0x1422752d0
0x000142276319:  90                    nop       
0x00014227631a:  488bc7                mov       rax, rdi
0x00014227631d:  4883c440              add       rsp, 0x40
0x000142276321:  415e                  pop       r14
0x000142276323:  5f                    pop       rdi
0x000142276324:  5e                    pop       rsi
0x000142276325:  5d                    pop       rbp
0x000142276326:  5b                    pop       rbx
0x000142276327:  c3                    ret       
0x000142276328:  ba01000000            mov       edx, 1
0x00014227632d:  488bc8                mov       rcx, rax
0x000142276330:  488b058126a204        mov       rax, qword ptr [rip + 0x4a22681]
0x000142276337:  eba5                  jmp       0x1422762de
0x000142276339:  488d4c2420            lea       rcx, [rsp + 0x20]
0x00014227633e:  e8ad4a54fe            call      0x1407badf0
0x000142276343:  488d15f608a905        lea       rdx, [rip + 0x5a908f6]
0x00014227634a:  488d4c2420            lea       rcx, [rsp + 0x20]
0x00014227634f:  e8fccc8c03            call      0x145b43050
0x000142276354:  cc                    int3      
0x000142276355:  488d4c2420            lea       rcx, [rsp + 0x20]
0x00014227635a:  e8914a54fe            call      0x1407badf0
0x00014227635f:  488d15da08a905        lea       rdx, [rip + 0x5a908da]
0x000142276366:  488d4c2420            lea       rcx, [rsp + 0x20]
0x00014227636b:  e8e0cc8c03            call      0x145b43050
0x000142276370:  cc                    int3      
0x000142276371:  cc                    int3      
0x000142276372:  cc                    int3      
0x000142276373:  cc                    int3      
0x000142276374:  cc                    int3      
0x000142276375:  cc                    int3      
0x000142276376:  cc                    int3      
0x000142276377:  cc                    int3      
0x000142276378:  cc                    int3      
0x000142276379:  cc                    int3      
0x00014227637a:  cc                    int3      
0x00014227637b:  cc                    int3      
0x00014227637c:  cc                    int3      
0x00014227637d:  cc                    int3      
0x00014227637e:  cc                    int3      
0x00014227637f:  cc                    int3      
0x000142276380:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142276385:  57                    push      rdi
0x000142276386:  4883ec20              sub       rsp, 0x20
0x00014227638a:  8bfa                  mov       edi, edx
0x00014227638c:  488bd9                mov       rbx, rcx
0x00014227638f:  4881c1a0010000        add       rcx, 0x1a0
0x000142276396:  e845f656fe            call      0x1407e59e0
0x00014227639b:  488b8b78010000        mov       rcx, qword ptr [rbx + 0x178]
0x0001422763a2:  4885c9                test      rcx, rcx
0x0001422763a5:  7411                  je        0x1422763b8
0x0001422763a7:  488b01                mov       rax, qword ptr [rcx]
0x0001422763aa:  ba01000000            mov       edx, 1
0x0001422763af:  488b00                mov       rax, qword ptr [rax]
0x0001422763b2:  ff158099ec03          call      qword ptr [rip + 0x3ec9980]
0x0001422763b8:  488d8bb8000000        lea       rcx, [rbx + 0xb8]
0x0001422763bf:  e83cb4efff            call      0x142171800
0x0001422763c4:  488d4b70              lea       rcx, [rbx + 0x70]
0x0001422763c8:  e813f656fe            call      0x1407e59e0
0x0001422763cd:  488d4b30              lea       rcx, [rbx + 0x30]
0x0001422763d1:  e80af656fe            call      0x1407e59e0
0x0001422763d6:  40f6c701              test      dil, 1
0x0001422763da:  7409                  je        0x1422763e5
0x0001422763dc:  488bcb                mov       rcx, rbx
0x0001422763df:  e8cccc6c02            call      0x1449430b0
0x0001422763e4:  90                    nop       
0x0001422763e5:  488bc3                mov       rax, rbx
0x0001422763e8:  488b5c2430            mov       rbx, qword ptr [rsp + 0x30]
0x0001422763ed:  4883c420              add       rsp, 0x20
0x0001422763f1:  5f                    pop       rdi
0x0001422763f2:  c3                    ret       
0x0001422763f3:  cc                    int3      
0x0001422763f4:  cc                    int3      
0x0001422763f5:  cc                    int3      
0x0001422763f6:  cc                    int3      
0x0001422763f7:  cc                    int3      
0x0001422763f8:  cc                    int3      
0x0001422763f9:  cc                    int3      
0x0001422763fa:  cc                    int3      
0x0001422763fb:  cc                    int3      
0x0001422763fc:  cc                    int3      
0x0001422763fd:  cc                    int3      
0x0001422763fe:  cc                    int3      
0x0001422763ff:  cc                    int3      
0x000142276400:  4881c190000000        add       rcx, 0x90
0x000142276407:  80791c00              cmp       byte ptr [rcx + 0x1c], 0
0x00014227640b:  741c                  je        0x142276429
0x00014227640d:  483bca                cmp       rcx, rdx
0x000142276410:  7436                  je        0x142276448
0x000142276412:  0f1002                movups    xmm0, xmmword ptr [rdx]
0x000142276415:  0f1101                movups    xmmword ptr [rcx], xmm0
0x000142276418:  f20f104a10            movsd     xmm1, qword ptr [rdx + 0x10]
0x00014227641d:  f20f114910            movsd     qword ptr [rcx + 0x10], xmm1
0x000142276422:  8b4218                mov       eax, dword ptr [rdx + 0x18]
0x000142276425:  894118                mov       dword ptr [rcx + 0x18], eax
0x000142276428:  c3                    ret       
0x000142276429:  483bca                cmp       rcx, rdx
0x00014227642c:  7416                  je        0x142276444
0x00014227642e:  0f1002                movups    xmm0, xmmword ptr [rdx]
0x000142276431:  0f1101                movups    xmmword ptr [rcx], xmm0
0x000142276434:  f20f104a10            movsd     xmm1, qword ptr [rdx + 0x10]
0x000142276439:  f20f114910            movsd     qword ptr [rcx + 0x10], xmm1
0x00014227643e:  8b4218                mov       eax, dword ptr [rdx + 0x18]
0x000142276441:  894118                mov       dword ptr [rcx + 0x18], eax
0x000142276444:  c6411c01              mov       byte ptr [rcx + 0x1c], 1
0x000142276448:  c3                    ret       
0x000142276449:  cc                    int3      
0x00014227644a:  cc                    int3      
0x00014227644b:  cc                    int3      
0x00014227644c:  cc                    int3      
0x00014227644d:  cc                    int3      
0x00014227644e:  cc                    int3      
0x00014227644f:  cc                    int3      
0x000142276450:  488d81b8000000        lea       rax, [rcx + 0xb8]
0x000142276457:  c3                    ret       
0x000142276458:  cc                    int3      
0x000142276459:  cc                    int3      
0x00014227645a:  cc                    int3      
0x00014227645b:  cc                    int3      
0x00014227645c:  cc                    int3      
0x00014227645d:  cc                    int3      
0x00014227645e:  cc                    int3      
0x00014227645f:  cc                    int3      
0x000142276460:  48895c2418            mov       qword ptr [rsp + 0x18], rbx
0x000142276465:  55                    push      rbp
0x000142276466:  56                    push      rsi
0x000142276467:  57                    push      rdi
0x000142276468:  4883ec70              sub       rsp, 0x70
0x00014227646c:  488b057dd2a905        mov       rax, qword ptr [rip + 0x5a9d27d]
0x000142276473:  4833c4                xor       rax, rsp
0x000142276476:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x00014227647b:  488bea                mov       rbp, rdx
0x00014227647e:  488bd9                mov       rbx, rcx
0x000142276481:  4883b97801000000      cmp       qword ptr [rcx + 0x178], 0
0x000142276489:  750a                  jne       0x142276495
0x00014227648b:  b80c000000            mov       eax, 0xc
0x000142276490:  e919010000            jmp       0x1422765ae
0x000142276495:  4881c180010000        add       rcx, 0x180
0x00014227649c:  493bc8                cmp       rcx, r8
0x00014227649f:  7419                  je        0x1422764ba
0x0001422764a1:  410f1000              movups    xmm0, xmmword ptr [r8]
0x0001422764a5:  0f1101                movups    xmmword ptr [rcx], xmm0
0x0001422764a8:  f2410f104810          movsd     xmm1, qword ptr [r8 + 0x10]
0x0001422764ae:  f20f114910            movsd     qword ptr [rcx + 0x10], xmm1
0x0001422764b3:  418b4018              mov       eax, dword ptr [r8 + 0x18]
0x0001422764b7:  894118                mov       dword ptr [rcx + 0x18], eax
0x0001422764ba:  488d542420            lea       rdx, [rsp + 0x20]
0x0001422764bf:  e81c2bf3ff            call      0x1421a8fe0
0x0001422764c4:  488bf8                mov       rdi, rax
0x0001422764c7:  488db3a0010000        lea       rsi, [rbx + 0x1a0]
0x0001422764ce:  483bf0                cmp       rsi, rax
0x0001422764d1:  7429                  je        0x1422764fc
0x0001422764d3:  488bce                mov       rcx, rsi
0x0001422764d6:  e805f556fe            call      0x1407e59e0
0x0001422764db:  0f1007                movups    xmm0, xmmword ptr [rdi]
0x0001422764de:  0f1106                movups    xmmword ptr [rsi], xmm0
0x0001422764e1:  0f104f10              movups    xmm1, xmmword ptr [rdi + 0x10]
0x0001422764e5:  0f114e10              movups    xmmword ptr [rsi + 0x10], xmm1
0x0001422764e9:  48c7471000000000      mov       qword ptr [rdi + 0x10], 0
0x0001422764f1:  48c747180f000000      mov       qword ptr [rdi + 0x18], 0xf
0x0001422764f9:  c60700                mov       byte ptr [rdi], 0
0x0001422764fc:  488b442438            mov       rax, qword ptr [rsp + 0x38]
0x000142276501:  4883f810              cmp       rax, 0x10
0x000142276505:  722e                  jb        0x142276535
0x000142276507:  48ffc0                inc       rax
0x00014227650a:  488b4c2420            mov       rcx, qword ptr [rsp + 0x20]
0x00014227650f:  488bd1                mov       rdx, rcx
0x000142276512:  483d00100000          cmp       rax, 0x1000
0x000142276518:  7215                  jb        0x14227652f
0x00014227651a:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014227651e:  482bd1                sub       rdx, rcx
0x000142276521:  488d42f8              lea       rax, [rdx - 8]
0x000142276525:  4883f81f              cmp       rax, 0x1f
0x000142276529:  0f879c000000          ja        0x1422765cb
0x00014227652f:  e87ccb6c02            call      0x1449430b0
0x000142276534:  90                    nop       
0x000142276535:  488d055423a204        lea       rax, [rip + 0x4a22354]
0x00014227653c:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000142276541:  48895c2428            mov       qword ptr [rsp + 0x28], rbx
0x000142276546:  488d442420            lea       rax, [rsp + 0x20]
0x00014227654b:  4889442458            mov       qword ptr [rsp + 0x58], rax
0x000142276550:  488d542420            lea       rdx, [rsp + 0x20]
0x000142276555:  488d8bb8000000        lea       rcx, [rbx + 0xb8]
0x00014227655c:  e88ff4ffff            call      0x1422759f0
0x000142276561:  0f104508              movups    xmm0, xmmword ptr [rbp + 8]
0x000142276565:  0f29442420            movaps    xmmword ptr [rsp + 0x20], xmm0
0x00014227656a:  488d542420            lea       rdx, [rsp + 0x20]
0x00014227656f:  488bcb                mov       rcx, rbx
0x000142276572:  e879070000            call      0x142276cf0
0x000142276577:  8983b0000000          mov       dword ptr [rbx + 0xb0], eax
0x00014227657d:  f6450301              test      byte ptr [rbp + 3], 1
0x000142276581:  7419                  je        0x14227659c
0x000142276583:  488d5518              lea       rdx, [rbp + 0x18]
0x000142276587:  440fb74546            movzx     r8d, word ptr [rbp + 0x46]
0x00014227658c:  488d8bb8000000        lea       rcx, [rbx + 0xb8]
0x000142276593:  e898f5ffff            call      0x142275b30
0x000142276598:  85c0                  test      eax, eax
0x00014227659a:  7512                  jne       0x1422765ae
0x00014227659c:  803d557e030600        cmp       byte ptr [rip + 0x6037e55], 0
0x0001422765a3:  7507                  jne       0x1422765ac
0x0001422765a5:  c6837001000009        mov       byte ptr [rbx + 0x170], 9
0x0001422765ac:  33c0                  xor       eax, eax
0x0001422765ae:  488b4c2460            mov       rcx, qword ptr [rsp + 0x60]
0x0001422765b3:  4833cc                xor       rcx, rsp
0x0001422765b6:  e825b08a03            call      0x145b215e0
0x0001422765bb:  488b9c24a0000000      mov       rbx, qword ptr [rsp + 0xa0]
0x0001422765c3:  4883c470              add       rsp, 0x70
0x0001422765c7:  5f                    pop       rdi
0x0001422765c8:  5e                    pop       rsi
0x0001422765c9:  5d                    pop       rbp
0x0001422765ca:  c3                    ret       
0x0001422765cb:  e850af8d03            call      0x145b51520
0x0001422765d0:  cc                    int3      
0x0001422765d1:  cc                    int3      
0x0001422765d2:  cc                    int3      
0x0001422765d3:  cc                    int3      
0x0001422765d4:  cc                    int3      
0x0001422765d5:  cc                    int3      
0x0001422765d6:  cc                    int3      
0x0001422765d7:  cc                    int3      
0x0001422765d8:  cc                    int3      
0x0001422765d9:  cc                    int3      
0x0001422765da:  cc                    int3      
0x0001422765db:  cc                    int3      
0x0001422765dc:  cc                    int3      
0x0001422765dd:  cc                    int3      
0x0001422765de:  cc                    int3      
0x0001422765df:  cc                    int3      
0x0001422765e0:  48895c2420            mov       qword ptr [rsp + 0x20], rbx
0x0001422765e5:  55                    push      rbp
0x0001422765e6:  56                    push      rsi
0x0001422765e7:  57                    push      rdi
0x0001422765e8:  4154                  push      r12
0x0001422765ea:  4155                  push      r13
0x0001422765ec:  4156                  push      r14
0x0001422765ee:  4157                  push      r15
0x0001422765f0:  488d6c2490            lea       rbp, [rsp - 0x70]
0x0001422765f5:  4881ec70010000        sub       rsp, 0x170
0x0001422765fc:  488b05edd0a905        mov       rax, qword ptr [rip + 0x5a9d0ed]
0x000142276603:  4833c4                xor       rax, rsp
0x000142276606:  48894560              mov       qword ptr [rbp + 0x60], rax
0x00014227660a:  4d8bf8                mov       r15, r8
0x00014227660d:  4c8be2                mov       r12, rdx
0x000142276610:  488bf1                mov       rsi, rcx
0x000142276613:  4889542430            mov       qword ptr [rsp + 0x30], rdx
0x000142276618:  66c745a00400          mov       word ptr [rbp - 0x60], 4
0x00014227661e:  4533ed                xor       r13d, r13d
0x000142276621:  4c896de0              mov       qword ptr [rbp - 0x20], r13
0x000142276625:  44896de8              mov       dword ptr [rbp - 0x18], r13d
0x000142276629:  4c896df0              mov       qword ptr [rbp - 0x10], r13
0x00014227662d:  4c896df8              mov       qword ptr [rbp - 8], r13
0x000142276631:  0f57c0                xorps     xmm0, xmm0
0x000142276634:  660f7f4500            movdqa    xmmword ptr [rbp], xmm0
0x000142276639:  4c896d10              mov       qword ptr [rbp + 0x10], r13
0x00014227663d:  488d4530              lea       rax, [rbp + 0x30]
0x000142276641:  48894518              mov       qword ptr [rbp + 0x18], rax
0x000142276645:  4c896d20              mov       qword ptr [rbp + 0x20], r13
0x000142276649:  48c7452820000000      mov       qword ptr [rbp + 0x28], 0x20
0x000142276651:  c74550ffffffff        mov       dword ptr [rbp + 0x50], 0xffffffff
0x000142276658:  44886d54              mov       byte ptr [rbp + 0x54], r13b
0x00014227665c:  33c0                  xor       eax, eax
0x00014227665e:  0f11442460            movups    xmmword ptr [rsp + 0x60], xmm0
0x000142276663:  88442470              mov       byte ptr [rsp + 0x70], al
0x000142276667:  48398178010000        cmp       qword ptr [rcx + 0x178], rax
0x00014227666e:  0f85a6010000          jne       0x14227681a
0x000142276674:  8d4820                lea       ecx, [rax + 0x20]
0x000142276677:  e884d16c02            call      0x144943800
0x00014227667c:  488bc8                mov       rcx, rax
0x00014227667f:  4885c0                test      rax, rax
0x000142276682:  0f849b040000          je        0x142276b23
0x000142276688:  0f10442460            movups    xmm0, xmmword ptr [rsp + 0x60]
0x00014227668d:  0fb6442470            movzx     eax, byte ptr [rsp + 0x70]
0x000142276692:  488d155722a204        lea       rdx, [rip + 0x4a22257]
0x000142276699:  488911                mov       qword ptr [rcx], rdx
0x00014227669c:  0f114108              movups    xmmword ptr [rcx + 8], xmm0
0x0001422766a0:  884118                mov       byte ptr [rcx + 0x18], al
0x0001422766a3:  48894c2430            mov       qword ptr [rsp + 0x30], rcx
0x0001422766a8:  488d542430            lea       rdx, [rsp + 0x30]
0x0001422766ad:  488d4da0              lea       rcx, [rbp - 0x60]
0x0001422766b1:  e81aecffff            call      0x1422752d0
0x0001422766b6:  41f6470301            test      byte ptr [r15 + 3], 1
0x0001422766bb:  7412                  je        0x1422766cf
0x0001422766bd:  498d5718              lea       rdx, [r15 + 0x18]
0x0001422766c1:  450fb74746            movzx     r8d, word ptr [r15 + 0x46]
0x0001422766c6:  488d4da0              lea       rcx, [rbp - 0x60]
0x0001422766ca:  e861f4ffff            call      0x142275b30
0x0001422766cf:  0f57c0                xorps     xmm0, xmm0
0x0001422766d2:  0f11442450            movups    xmmword ptr [rsp + 0x50], xmm0
0x0001422766d7:  488b9dd0000000        mov       rbx, qword ptr [rbp + 0xd0]
0x0001422766de:  66480f7ec0            movq      rax, xmm0
0x0001422766e3:  483903                cmp       qword ptr [rbx], rax
0x0001422766e6:  750b                  jne       0x1422766f3
0x0001422766e8:  488b4308              mov       rax, qword ptr [rbx + 8]
0x0001422766ec:  483b442458            cmp       rax, qword ptr [rsp + 0x58]
0x0001422766f1:  743d                  je        0x142276730
0x0001422766f3:  b918000000            mov       ecx, 0x18
0x0001422766f8:  e803d16c02            call      0x144943800
0x0001422766fd:  4885c0                test      rax, rax
0x000142276700:  0f8401040000          je        0x142276b07
0x000142276706:  488d0d0b22a204        lea       rcx, [rip + 0x4a2220b]
0x00014227670d:  488908                mov       qword ptr [rax], rcx
0x000142276710:  0f1003                movups    xmm0, xmmword ptr [rbx]
0x000142276713:  0f114008              movups    xmmword ptr [rax + 8], xmm0
0x000142276717:  4c896c2450            mov       qword ptr [rsp + 0x50], r13
0x00014227671c:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x000142276721:  488d542430            lea       rdx, [rsp + 0x30]
0x000142276726:  488d4da0              lea       rcx, [rbp - 0x60]
0x00014227672a:  e8a1ebffff            call      0x1422752d0
0x00014227672f:  90                    nop       
0x000142276730:  488d55a0              lea       rdx, [rbp - 0x60]
0x000142276734:  498bcc                mov       rcx, r12
0x000142276737:  e884c0ffff            call      0x1422727c0
0x00014227673c:  90                    nop       
0x00014227673d:  488d4530              lea       rax, [rbp + 0x30]
0x000142276741:  488b4d18              mov       rcx, qword ptr [rbp + 0x18]
0x000142276745:  483bc8                cmp       rcx, rax
0x000142276748:  7406                  je        0x142276750
0x00014227674a:  e861c96c02            call      0x1449430b0
0x00014227674f:  90                    nop       
0x000142276750:  488b5d00              mov       rbx, qword ptr [rbp]
0x000142276754:  4885db                test      rbx, rbx
0x000142276757:  7477                  je        0x1422767d0
0x000142276759:  488b7d08              mov       rdi, qword ptr [rbp + 8]
0x00014227675d:  483bdf                cmp       rbx, rdi
0x000142276760:  7426                  je        0x142276788
0x000142276762:  488b0b                mov       rcx, qword ptr [rbx]
0x000142276765:  4885c9                test      rcx, rcx
0x000142276768:  7411                  je        0x14227677b
0x00014227676a:  488b01                mov       rax, qword ptr [rcx]
0x00014227676d:  ba01000000            mov       edx, 1
0x000142276772:  488b00                mov       rax, qword ptr [rax]
0x000142276775:  ff15bd95ec03          call      qword ptr [rip + 0x3ec95bd]
0x00014227677b:  4883c308              add       rbx, 8
0x00014227677f:  483bdf                cmp       rbx, rdi
0x000142276782:  75de                  jne       0x142276762
0x000142276784:  488b5d00              mov       rbx, qword ptr [rbp]
0x000142276788:  488b4510              mov       rax, qword ptr [rbp + 0x10]
0x00014227678c:  482bc3                sub       rax, rbx
0x00014227678f:  48c1f803              sar       rax, 3
0x000142276793:  488d04c500000000      lea       rax, [rax*8]
0x00014227679b:  488bcb                mov       rcx, rbx
0x00014227679e:  483d00100000          cmp       rax, 0x1000
0x0001422767a4:  7215                  jb        0x1422767bb
0x0001422767a6:  488b5bf8              mov       rbx, qword ptr [rbx - 8]
0x0001422767aa:  482bcb                sub       rcx, rbx
0x0001422767ad:  488d41f8              lea       rax, [rcx - 8]
0x0001422767b1:  4883f81f              cmp       rax, 0x1f
0x0001422767b5:  0f878a030000          ja        0x142276b45
0x0001422767bb:  488bcb                mov       rcx, rbx
0x0001422767be:  e8edc86c02            call      0x1449430b0
0x0001422767c3:  90                    nop       
0x0001422767c4:  0f57c0                xorps     xmm0, xmm0
0x0001422767c7:  660f7f4500            movdqa    xmmword ptr [rbp], xmm0
0x0001422767cc:  4c896d10              mov       qword ptr [rbp + 0x10], r13
0x0001422767d0:  488b4de0              mov       rcx, qword ptr [rbp - 0x20]
0x0001422767d4:  4885c9                test      rcx, rcx
0x0001422767d7:  7417                  je        0x1422767f0
0x0001422767d9:  488b01                mov       rax, qword ptr [rcx]
0x0001422767dc:  488d55a8              lea       rdx, [rbp - 0x58]
0x0001422767e0:  483bca                cmp       rcx, rdx
0x0001422767e3:  0f95c2                setne     dl
0x0001422767e6:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x0001422767ea:  ff154895ec03          call      qword ptr [rip + 0x3ec9548]
0x0001422767f0:  498bc4                mov       rax, r12
0x0001422767f3:  488b4d60              mov       rcx, qword ptr [rbp + 0x60]
0x0001422767f7:  4833cc                xor       rcx, rsp
0x0001422767fa:  e8e1ad8a03            call      0x145b215e0
0x0001422767ff:  488b9c24c8010000      mov       rbx, qword ptr [rsp + 0x1c8]
0x000142276807:  4881c470010000        add       rsp, 0x170
0x00014227680e:  415f                  pop       r15
0x000142276810:  415e                  pop       r14
0x000142276812:  415d                  pop       r13
0x000142276814:  415c                  pop       r12
0x000142276816:  5f                    pop       rdi
0x000142276817:  5e                    pop       rsi
0x000142276818:  5d                    pop       rbp
0x000142276819:  c3                    ret       
0x00014227681a:  488d9980010000        lea       rbx, [rcx + 0x180]
0x000142276821:  493bd9                cmp       rbx, r9
0x000142276824:  7419                  je        0x14227683f
0x000142276826:  410f1001              movups    xmm0, xmmword ptr [r9]
0x00014227682a:  0f1103                movups    xmmword ptr [rbx], xmm0
0x00014227682d:  f2410f104910          movsd     xmm1, qword ptr [r9 + 0x10]
0x000142276833:  f20f114b10            movsd     qword ptr [rbx + 0x10], xmm1
0x000142276838:  418b4118              mov       eax, dword ptr [r9 + 0x18]
0x00014227683c:  894318                mov       dword ptr [rbx + 0x18], eax
0x00014227683f:  488d542478            lea       rdx, [rsp + 0x78]
0x000142276844:  488bcb                mov       rcx, rbx
0x000142276847:  e89427f3ff            call      0x1421a8fe0
0x00014227684c:  4c8bf0                mov       r14, rax
0x00014227684f:  488dbea0010000        lea       rdi, [rsi + 0x1a0]
0x000142276856:  483bf8                cmp       rdi, rax
0x000142276859:  7428                  je        0x142276883
0x00014227685b:  488bcf                mov       rcx, rdi
0x00014227685e:  e87df156fe            call      0x1407e59e0
0x000142276863:  410f1006              movups    xmm0, xmmword ptr [r14]
0x000142276867:  0f1107                movups    xmmword ptr [rdi], xmm0
0x00014227686a:  410f104e10            movups    xmm1, xmmword ptr [r14 + 0x10]
0x00014227686f:  0f114f10              movups    xmmword ptr [rdi + 0x10], xmm1
0x000142276873:  4d896e10              mov       qword ptr [r14 + 0x10], r13
0x000142276877:  49c746180f000000      mov       qword ptr [r14 + 0x18], 0xf
0x00014227687f:  41c60600              mov       byte ptr [r14], 0
0x000142276883:  488b4590              mov       rax, qword ptr [rbp - 0x70]
0x000142276887:  4883f810              cmp       rax, 0x10
0x00014227688b:  722e                  jb        0x1422768bb
0x00014227688d:  48ffc0                inc       rax
0x000142276890:  488b4c2478            mov       rcx, qword ptr [rsp + 0x78]
0x000142276895:  488bd1                mov       rdx, rcx
0x000142276898:  483d00100000          cmp       rax, 0x1000
0x00014227689e:  7215                  jb        0x1422768b5
0x0001422768a0:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x0001422768a4:  482bd1                sub       rdx, rcx
0x0001422768a7:  488d42f8              lea       rax, [rdx - 8]
0x0001422768ab:  4883f81f              cmp       rax, 0x1f
0x0001422768af:  0f878a020000          ja        0x142276b3f
0x0001422768b5:  e8f6c76c02            call      0x1449430b0
0x0001422768ba:  90                    nop       
0x0001422768bb:  410f104708            movups    xmm0, xmmword ptr [r15 + 8]
0x0001422768c0:  0f29442450            movaps    xmmword ptr [rsp + 0x50], xmm0
0x0001422768c5:  488d542450            lea       rdx, [rsp + 0x50]
0x0001422768ca:  488bce                mov       rcx, rsi
0x0001422768cd:  e81e040000            call      0x142276cf0
0x0001422768d2:  8986b0000000          mov       dword ptr [rsi + 0xb0], eax
0x0001422768d8:  803d197b030600        cmp       byte ptr [rip + 0x6037b19], 0
0x0001422768df:  7507                  jne       0x1422768e8
0x0001422768e1:  c6867001000009        mov       byte ptr [rsi + 0x170], 9
0x0001422768e8:  c644246002            mov       byte ptr [rsp + 0x60], 2
0x0001422768ed:  803db480030600        cmp       byte ptr [rip + 0x60380b4], 0
0x0001422768f4:  7474                  je        0x14227696a
0x0001422768f6:  c644244100            mov       byte ptr [rsp + 0x41], 0
0x0001422768fb:  c644245800            mov       byte ptr [rsp + 0x58], 0
0x000142276900:  0fb703                movzx     eax, word ptr [rbx]
0x000142276903:  6683f802              cmp       ax, 2
0x000142276907:  740d                  je        0x142276916
0x000142276909:  6683f817              cmp       ax, 0x17
0x00014227690d:  7407                  je        0x142276916
0x00014227690f:  b9ffff0000            mov       ecx, 0xffff
0x000142276914:  eb0d                  jmp       0x142276923
0x000142276916:  0fb74b02              movzx     ecx, word ptr [rbx + 2]
0x00014227691a:  ff15108fec03          call      qword ptr [rip + 0x3ec8f10]
0x000142276920:  0fb7c8                movzx     ecx, ax
0x000142276923:  48837f1810            cmp       qword ptr [rdi + 0x18], 0x10
0x000142276928:  7203                  jb        0x14227692d
0x00014227692a:  488b3f                mov       rdi, qword ptr [rdi]
0x00014227692d:  0f28442450            movaps    xmm0, xmmword ptr [rsp + 0x50]
0x000142276932:  660f7f442450          movdqa    xmmword ptr [rsp + 0x50], xmm0
0x000142276938:  0fb7442440            movzx     eax, word ptr [rsp + 0x40]
0x00014227693d:  6689442428            mov       word ptr [rsp + 0x28], ax
0x000142276942:  488d442450            lea       rax, [rsp + 0x50]
0x000142276947:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014227694c:  440fb7c9              movzx     r9d, cx
0x000142276950:  4c8bc7                mov       r8, rdi
0x000142276953:  488d542461            lea       rdx, [rsp + 0x61]
0x000142276958:  488bce                mov       rcx, rsi
0x00014227695b:  e8e0040000            call      0x142276e40
0x000142276960:  84c0                  test      al, al
0x000142276962:  7513                  jne       0x142276977
0x000142276964:  88442460              mov       byte ptr [rsp + 0x60], al
0x000142276968:  eb0d                  jmp       0x142276977
0x00014227696a:  488d542461            lea       rdx, [rsp + 0x61]
0x00014227696f:  488bce                mov       rcx, rsi
0x000142276972:  e8d9010000            call      0x142276b50
0x000142276977:  b920000000            mov       ecx, 0x20
0x00014227697c:  e87fce6c02            call      0x144943800
0x000142276981:  4885c0                test      rax, rax
0x000142276984:  0f8461010000          je        0x142276aeb
0x00014227698a:  0f10442460            movups    xmm0, xmmword ptr [rsp + 0x60]
0x00014227698f:  0fb64c2470            movzx     ecx, byte ptr [rsp + 0x70]
0x000142276994:  488d15551fa204        lea       rdx, [rip + 0x4a21f55]
0x00014227699b:  488910                mov       qword ptr [rax], rdx
0x00014227699e:  0f114008              movups    xmmword ptr [rax + 8], xmm0
0x0001422769a2:  884818                mov       byte ptr [rax + 0x18], cl
0x0001422769a5:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x0001422769aa:  488d542430            lea       rdx, [rsp + 0x30]
0x0001422769af:  488d4da0              lea       rcx, [rbp - 0x60]
0x0001422769b3:  e818e9ffff            call      0x1422752d0
0x0001422769b8:  41f6470301            test      byte ptr [r15 + 3], 1
0x0001422769bd:  7412                  je        0x1422769d1
0x0001422769bf:  498d5718              lea       rdx, [r15 + 0x18]
0x0001422769c3:  450fb74746            movzx     r8d, word ptr [r15 + 0x46]
0x0001422769c8:  488d4da0              lea       rcx, [rbp - 0x60]
0x0001422769cc:  e85ff1ffff            call      0x142275b30
0x0001422769d1:  0f57c0                xorps     xmm0, xmm0
0x0001422769d4:  0f11442450            movups    xmmword ptr [rsp + 0x50], xmm0
0x0001422769d9:  488b9dd0000000        mov       rbx, qword ptr [rbp + 0xd0]
0x0001422769e0:  66480f7ec0            movq      rax, xmm0
0x0001422769e5:  483903                cmp       qword ptr [rbx], rax
0x0001422769e8:  750b                  jne       0x1422769f5
0x0001422769ea:  488b4308              mov       rax, qword ptr [rbx + 8]
0x0001422769ee:  483b442458            cmp       rax, qword ptr [rsp + 0x58]
0x0001422769f3:  743d                  je        0x142276a32
0x0001422769f5:  b918000000            mov       ecx, 0x18
0x0001422769fa:  e801ce6c02            call      0x144943800
0x0001422769ff:  4885c0                test      rax, rax
0x000142276a02:  0f84c7000000          je        0x142276acf
0x000142276a08:  488d0d091fa204        lea       rcx, [rip + 0x4a21f09]
0x000142276a0f:  488908                mov       qword ptr [rax], rcx
0x000142276a12:  0f1003                movups    xmm0, xmmword ptr [rbx]
0x000142276a15:  0f114008              movups    xmmword ptr [rax + 8], xmm0
0x000142276a19:  4c896c2450            mov       qword ptr [rsp + 0x50], r13
0x000142276a1e:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x000142276a23:  488d542430            lea       rdx, [rsp + 0x30]
0x000142276a28:  488d4da0              lea       rcx, [rbp - 0x60]
0x000142276a2c:  e89fe8ffff            call      0x1422752d0
0x000142276a31:  90                    nop       
0x000142276a32:  488d55a0              lea       rdx, [rbp - 0x60]
0x000142276a36:  498bcc                mov       rcx, r12
0x000142276a39:  e882bdffff            call      0x1422727c0
0x000142276a3e:  90                    nop       
0x000142276a3f:  488d4530              lea       rax, [rbp + 0x30]
0x000142276a43:  488b4d18              mov       rcx, qword ptr [rbp + 0x18]
0x000142276a47:  483bc8                cmp       rcx, rax
0x000142276a4a:  7406                  je        0x142276a52
0x000142276a4c:  e85fc66c02            call      0x1449430b0
0x000142276a51:  90                    nop       
0x000142276a52:  488b5d00              mov       rbx, qword ptr [rbp]
0x000142276a56:  4885db                test      rbx, rbx
0x000142276a59:  0f8471fdffff          je        0x1422767d0
0x000142276a5f:  488b7d08              mov       rdi, qword ptr [rbp + 8]
0x000142276a63:  483bdf                cmp       rbx, rdi
0x000142276a66:  7426                  je        0x142276a8e
0x000142276a68:  488b0b                mov       rcx, qword ptr [rbx]
0x000142276a6b:  4885c9                test      rcx, rcx
0x000142276a6e:  7411                  je        0x142276a81
0x000142276a70:  488b01                mov       rax, qword ptr [rcx]
0x000142276a73:  ba01000000            mov       edx, 1
0x000142276a78:  488b00                mov       rax, qword ptr [rax]
0x000142276a7b:  ff15b792ec03          call      qword ptr [rip + 0x3ec92b7]
0x000142276a81:  4883c308              add       rbx, 8
0x000142276a85:  483bdf                cmp       rbx, rdi
0x000142276a88:  75de                  jne       0x142276a68
0x000142276a8a:  488b5d00              mov       rbx, qword ptr [rbp]
0x000142276a8e:  488b4510              mov       rax, qword ptr [rbp + 0x10]
0x000142276a92:  482bc3                sub       rax, rbx
0x000142276a95:  48c1f803              sar       rax, 3
0x000142276a99:  488d04c500000000      lea       rax, [rax*8]
0x000142276aa1:  488bcb                mov       rcx, rbx
0x000142276aa4:  483d00100000          cmp       rax, 0x1000
0x000142276aaa:  7215                  jb        0x142276ac1
0x000142276aac:  488b5bf8              mov       rbx, qword ptr [rbx - 8]
0x000142276ab0:  482bcb                sub       rcx, rbx
0x000142276ab3:  488d41f8              lea       rax, [rcx - 8]
0x000142276ab7:  4883f81f              cmp       rax, 0x1f
0x000142276abb:  0f8784000000          ja        0x142276b45
0x000142276ac1:  488bcb                mov       rcx, rbx
0x000142276ac4:  e8e7c56c02            call      0x1449430b0
0x000142276ac9:  90                    nop       
0x000142276aca:  e9f5fcffff            jmp       0x1422767c4
0x000142276acf:  488d4c2478            lea       rcx, [rsp + 0x78]
0x000142276ad4:  e8174354fe            call      0x1407badf0
0x000142276ad9:  488d156001a905        lea       rdx, [rip + 0x5a90160]
0x000142276ae0:  488d4c2478            lea       rcx, [rsp + 0x78]
0x000142276ae5:  e866c58c03            call      0x145b43050
0x000142276aea:  cc                    int3      
0x000142276aeb:  488d4c2478            lea       rcx, [rsp + 0x78]
0x000142276af0:  e8fb4254fe            call      0x1407badf0
0x000142276af5:  488d154401a905        lea       rdx, [rip + 0x5a90144]
0x000142276afc:  488d4c2478            lea       rcx, [rsp + 0x78]
0x000142276b01:  e84ac58c03            call      0x145b43050
0x000142276b06:  cc                    int3      
0x000142276b07:  488d4c2478            lea       rcx, [rsp + 0x78]
0x000142276b0c:  e8df4254fe            call      0x1407badf0
0x000142276b11:  488d152801a905        lea       rdx, [rip + 0x5a90128]
0x000142276b18:  488d4c2478            lea       rcx, [rsp + 0x78]
0x000142276b1d:  e82ec58c03            call      0x145b43050
0x000142276b22:  cc                    int3      
0x000142276b23:  488d4c2478            lea       rcx, [rsp + 0x78]
0x000142276b28:  e8c34254fe            call      0x1407badf0
0x000142276b2d:  488d150c01a905        lea       rdx, [rip + 0x5a9010c]
0x000142276b34:  488d4c2478            lea       rcx, [rsp + 0x78]
0x000142276b39:  e812c58c03            call      0x145b43050
0x000142276b3e:  cc                    int3      
0x000142276b3f:  e8dca98d03            call      0x145b51520
0x000142276b44:  90                    nop       
0x000142276b45:  e8d6a98d03            call      0x145b51520
0x000142276b4a:  cc                    int3      
0x000142276b4b:  cc                    int3      
0x000142276b4c:  cc                    int3      
0x000142276b4d:  cc                    int3      
0x000142276b4e:  cc                    int3      
0x000142276b4f:  cc                    int3      
