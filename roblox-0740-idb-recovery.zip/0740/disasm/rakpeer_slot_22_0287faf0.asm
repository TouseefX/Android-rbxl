; RakPeer vtable slot 22
; rva 0x287faf0
0x14287faf0:  4053                 push      rbx
0x14287faf2:  55                   push      rbp
0x14287faf3:  56                   push      rsi
0x14287faf4:  4154                 push      r12
0x14287faf6:  4156                 push      r14
0x14287faf8:  4157                 push      r15
0x14287fafa:  4881eca8000000       sub       rsp, 0xa8
0x14287fb01:  488b05e83b4905       mov       rax, qword ptr [rip + 0x5493be8]
0x14287fb08:  4833c4               xor       rax, rsp
0x14287fb0b:  4889842498000000     mov       qword ptr [rsp + 0x98], rax
0x14287fb13:  4c8bb42410010000     mov       r14, qword ptr [rsp + 0x110]
0x14287fb1b:  458be1               mov       r12d, r9d
0x14287fb1e:  418be8               mov       ebp, r8d
0x14287fb21:  4c8bfa               mov       r15, rdx
0x14287fb24:  488bd9               mov       rbx, rcx
0x14287fb27:  4885d2               test      rdx, rdx
0x14287fb2a:  0f848b010000         je        0x14287fcbb
0x14287fb30:  4585c0               test      r8d, r8d
0x14287fb33:  0f8882010000         js        0x14287fcbb
0x14287fb39:  4883b95003000000     cmp       qword ptr [rcx + 0x350], 0
0x14287fb41:  0f8474010000         je        0x14287fcbb
0x14287fb47:  0fb68108010000       movzx     eax, byte ptr [rcx + 0x108]
0x14287fb4e:  90                   nop       
0x14287fb4f:  3c01                 cmp       al, 1
0x14287fb51:  0f8464010000         je        0x14287fcbb
0x14287fb57:  0fb6b42418010000     movzx     esi, byte ptr [rsp + 0x118]
0x14287fb5f:  4084f6               test      sil, sil
0x14287fb62:  7510                 jne       0x14287fb74
0x14287fb64:  498bce               mov       rcx, r14
0x14287fb67:  e8c492ffff           call      0x142878e30
0x14287fb6c:  84c0                 test      al, al
0x14287fb6e:  0f8547010000         jne       0x14287fcbb
0x14287fb74:  4889bc24a0000000     mov       qword ptr [rsp + 0xa0], rdi
0x14287fb7c:  8bbc2420010000       mov       edi, dword ptr [rsp + 0x120]
0x14287fb83:  85ff                 test      edi, edi
0x14287fb85:  7515                 jne       0x14287fb9c
0x14287fb87:  488b03               mov       rax, qword ptr [rbx]
0x14287fb8a:  488bcb               mov       rcx, rbx
0x14287fb8d:  488b8098000000       mov       rax, qword ptr [rax + 0x98]
0x14287fb94:  ff159e018c03         call      qword ptr [rip + 0x38c019e]
0x14287fb9a:  8bf8                 mov       edi, eax
0x14287fb9c:  4084f6               test      sil, sil
0x14287fb9f:  0f85ba000000         jne       0x14287fc5f
0x14287fba5:  41b001               mov       r8b, 1
0x14287fba8:  498bd6               mov       rdx, r14
0x14287fbab:  488bcb               mov       rcx, rbx
0x14287fbae:  e88d820000           call      0x142887e40
0x14287fbb3:  84c0                 test      al, al
0x14287fbb5:  0f84a4000000         je        0x14287fc5f
0x14287fbbb:  488b0b               mov       rcx, qword ptr [rbx]
0x14287fbbe:  448bc5               mov       r8d, ebp
0x14287fbc1:  498bd7               mov       rdx, r15
0x14287fbc4:  488b81b8000000       mov       rax, qword ptr [rcx + 0xb8]
0x14287fbcb:  488bcb               mov       rcx, rbx
0x14287fbce:  ff1564018c03         call      qword ptr [rip + 0x38c0164]
0x14287fbd4:  83bc240001000005     cmp       dword ptr [rsp + 0x100], 5
0x14287fbdc:  7c56                 jl        0x14287fc34
0x14287fbde:  488d8bd80c0000       lea       rcx, [rbx + 0xcd8]
0x14287fbe5:  c68424900000000e     mov       byte ptr [rsp + 0x90], 0xe
0x14287fbed:  e8be3b2a03           call      0x145b237b0
0x14287fbf2:  85c0                 test      eax, eax
0x14287fbf4:  0f85c8000000         jne       0x14287fcc2
0x14287fbfa:  8b83280d0000         mov       eax, dword ptr [rbx + 0xd28]
0x14287fc00:  488d8bd80c0000       lea       rcx, [rbx + 0xcd8]
0x14287fc07:  89842491000000       mov       dword ptr [rsp + 0x91], eax
0x14287fc0e:  e8fd3b2a03           call      0x145b23810
0x14287fc13:  488b03               mov       rax, qword ptr [rbx]
0x14287fc16:  488d942490000000     lea       rdx, [rsp + 0x90]
0x14287fc1e:  41b805000000         mov       r8d, 5
0x14287fc24:  488bcb               mov       rcx, rbx
0x14287fc27:  488b80b8000000       mov       rax, qword ptr [rax + 0xb8]
0x14287fc2e:  ff1504018c03         call      qword ptr [rip + 0x38c0104]
0x14287fc34:  8bc7                 mov       eax, edi
0x14287fc36:  488bbc24a0000000     mov       rdi, qword ptr [rsp + 0xa0]
0x14287fc3e:  488b8c2498000000     mov       rcx, qword ptr [rsp + 0x98]
0x14287fc46:  4833cc               xor       rcx, rsp
0x14287fc49:  e892192a03           call      0x145b215e0
0x14287fc4e:  4881c4a8000000       add       rsp, 0xa8
0x14287fc55:  415f                 pop       r15
0x14287fc57:  415e                 pop       r14
0x14287fc59:  415c                 pop       r12
0x14287fc5b:  5e                   pop       rsi
0x14287fc5c:  5d                   pop       rbp
0x14287fc5d:  5b                   pop       rbx
0x14287fc5e:  c3                   ret       
0x14287fc5f:  498bd6               mov       rdx, r14
0x14287fc62:  488d4c2460           lea       rcx, [rsp + 0x60]
0x14287fc67:  e82492ffff           call      0x142878e90
0x14287fc6c:  33c9                 xor       ecx, ecx
0x14287fc6e:  448d04ed00000000     lea       r8d, [rbp*8]
0x14287fc76:  48894c2458           mov       qword ptr [rsp + 0x58], rcx
0x14287fc7b:  458bcc               mov       r9d, r12d
0x14287fc7e:  884c2450             mov       byte ptr [rsp + 0x50], cl
0x14287fc82:  498bd7               mov       rdx, r15
0x14287fc85:  897c2448             mov       dword ptr [rsp + 0x48], edi
0x14287fc89:  894c2440             mov       dword ptr [rsp + 0x40], ecx
0x14287fc8d:  488bcb               mov       rcx, rbx
0x14287fc90:  4088742438           mov       byte ptr [rsp + 0x38], sil
0x14287fc95:  4889442430           mov       qword ptr [rsp + 0x30], rax
0x14287fc9a:  0fb6842408010000     movzx     eax, byte ptr [rsp + 0x108]
0x14287fca2:  88442428             mov       byte ptr [rsp + 0x28], al
0x14287fca6:  8b842400010000       mov       eax, dword ptr [rsp + 0x100]
0x14287fcad:  89442420             mov       dword ptr [rsp + 0x20], eax
0x14287fcb1:  e85a910000           call      0x142888e10
0x14287fcb6:  e979ffffff           jmp       0x14287fc34
0x14287fcbb:  33c0                 xor       eax, eax
0x14287fcbd:  e97cffffff           jmp       0x14287fc3e
0x14287fcc2:  8bc8                 mov       ecx, eax
0x14287fcc4:  e8b7402a03           call      0x145b23d80
0x14287fcc9:  cc                   int3      
0x14287fcca:  cc                   int3      
0x14287fccb:  cc                   int3      
0x14287fccc:  cc                   int3      
0x14287fccd:  cc                   int3      
0x14287fcce:  cc                   int3      
0x14287fccf:  cc                   int3      
