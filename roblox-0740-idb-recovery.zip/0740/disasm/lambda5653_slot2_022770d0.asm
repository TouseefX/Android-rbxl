; lambda5653 vtable slot 2 rva 0x22770d0
0x1422770d0:  4053                 push      rbx
0x1422770d2:  4883ec20             sub       rsp, 0x20
0x1422770d6:  803dcb78030600       cmp       byte ptr [rip + 0x60378cb], 0
0x1422770dd:  488bda               mov       rbx, rdx
0x1422770e0:  488b4908             mov       rcx, qword ptr [rcx + 8]
0x1422770e4:  7411                 je        0x1422770f7
0x1422770e6:  e835ffffff           call      0x142277020
0x1422770eb:  84c0                 test      al, al
0x1422770ed:  7518                 jne       0x142277107
0x1422770ef:  8803                 mov       byte ptr [rbx], al
0x1422770f1:  4883c420             add       rsp, 0x20
0x1422770f5:  5b                   pop       rbx
0x1422770f6:  c3                   ret       
0x1422770f7:  c60202               mov       byte ptr [rdx], 2
0x1422770fa:  48ffc2               inc       rdx
0x1422770fd:  4883c420             add       rsp, 0x20
0x142277101:  5b                   pop       rbx
0x142277102:  e949faffff           jmp       0x142276b50
0x142277107:  4883c420             add       rsp, 0x20
0x14227710b:  5b                   pop       rbx
0x14227710c:  c3                   ret       
0x14227710d:  cc                   int3      
0x14227710e:  cc                   int3      
0x14227710f:  cc                   int3      
