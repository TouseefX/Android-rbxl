; RakPeer vtable slot 42
; rva 0x2881cf0
0x142881cf0:  4055                 push      rbp
0x142881cf2:  4883ec50             sub       rsp, 0x50
0x142881cf6:  8b4228               mov       eax, dword ptr [rdx + 0x28]
0x142881cf9:  498be8               mov       rbp, r8
0x142881cfc:  0f104a10             movups    xmm1, xmmword ptr [rdx + 0x10]
0x142881d00:  4c8bc9               mov       r9, rcx
0x142881d03:  89442448             mov       dword ptr [rsp + 0x48], eax
0x142881d07:  f20f104220           movsd     xmm0, qword ptr [rdx + 0x20]
0x142881d0c:  0fb7422e             movzx     eax, word ptr [rdx + 0x2e]
0x142881d10:  48895c2460           mov       qword ptr [rsp + 0x60], rbx
0x142881d15:  488b1a               mov       rbx, qword ptr [rdx]
0x142881d18:  483b1d49db5605       cmp       rbx, qword ptr [rip + 0x556db49]
0x142881d1f:  668944244e           mov       word ptr [rsp + 0x4e], ax
0x142881d24:  0fb7422c             movzx     eax, word ptr [rdx + 0x2c]
0x142881d28:  668944244c           mov       word ptr [rsp + 0x4c], ax
0x142881d2d:  0f114c2430           movups    xmmword ptr [rsp + 0x30], xmm1
0x142881d32:  f20f11442440         movsd     qword ptr [rsp + 0x40], xmm0
0x142881d38:  744e                 je        0x142881d88
0x142881d3a:  440fb78112010000     movzx     r8d, word ptr [rcx + 0x112]
0x142881d42:  4533db               xor       r11d, r11d
0x142881d45:  418bd3               mov       edx, r11d
0x142881d48:  66453bd8             cmp       r11w, r8w
0x142881d4c:  7332                 jae       0x142881d80
0x142881d4e:  4c8b9150030000       mov       r10, qword ptr [rcx + 0x350]
0x142881d55:  6666660f1f840000000000 nop       word ptr [rax + rax]
0x142881d60:  8bc2                 mov       eax, edx
0x142881d62:  4869c0d8160000       imul      rax, rax, 0x16d8
0x142881d69:  4903c2               add       rax, r10
0x142881d6c:  48399830160000       cmp       qword ptr [rax + 0x1630], rbx
0x142881d73:  0f8458010000         je        0x142881ed1
0x142881d79:  ffc2                 inc       edx
0x142881d7b:  413bd0               cmp       edx, r8d
0x142881d7e:  72e0                 jb        0x142881d60
0x142881d80:  498bc3               mov       rax, r11
0x142881d83:  e949010000           jmp       0x142881ed1
0x142881d88:  0f10442440           movups    xmm0, xmmword ptr [rsp + 0x40]
0x142881d8d:  440fb7542430         movzx     r10d, word ptr [rsp + 0x30]
0x142881d93:  66480f7ec9           movq      rcx, xmm1
0x142881d98:  48897c2470           mov       qword ptr [rsp + 0x70], rdi
0x142881d9d:  488bc1               mov       rax, rcx
0x142881da0:  0f290c24             movaps    xmmword ptr [rsp], xmm1
0x142881da4:  488b7c2408           mov       rdi, qword ptr [rsp + 8]
0x142881da9:  48c1e810             shr       rax, 0x10
0x142881dad:  663b0596da5605       cmp       ax, word ptr [rip + 0x556da96]
0x142881db4:  0f29442410           movaps    xmmword ptr [rsp + 0x10], xmm0
0x142881db9:  488b5c2410           mov       rbx, qword ptr [rsp + 0x10]
0x142881dbe:  751d                 jne       0x142881ddd
0x142881dc0:  66443b1580da5605     cmp       r10w, word ptr [rip + 0x556da80]
0x142881dc8:  7513                 jne       0x142881ddd
0x142881dca:  664183fa02           cmp       r10w, 2
0x142881dcf:  7569                 jne       0x142881e3a
0x142881dd1:  48c1e920             shr       rcx, 0x20
0x142881dd5:  3b0d71da5605         cmp       ecx, dword ptr [rip + 0x556da71]
0x142881ddb:  7476                 je        0x142881e53
0x142881ddd:  4533db               xor       r11d, r11d
0x142881de0:  4889742468           mov       qword ptr [rsp + 0x68], rsi
0x142881de5:  baffffffff           mov       edx, 0xffffffff
0x142881dea:  458bc3               mov       r8d, r11d
0x142881ded:  66453b9912010000     cmp       r11w, word ptr [r9 + 0x112]
0x142881df5:  0f83c9000000         jae       0x142881ec4
0x142881dfb:  0f1f440000           nop       dword ptr [rax + rax]
0x142881e00:  498b8950030000       mov       rcx, qword ptr [r9 + 0x350]
0x142881e07:  4963c0               movsxd    rax, r8d
0x142881e0a:  4869f0d8160000       imul      rsi, rax, 0x16d8
0x142881e11:  0fb7442432           movzx     eax, word ptr [rsp + 0x32]
0x142881e16:  4803ce               add       rcx, rsi
0x142881e19:  66394106             cmp       word ptr [rcx + 6], ax
0x142881e1d:  756d                 jne       0x142881e8c
0x142881e1f:  0fb74104             movzx     eax, word ptr [rcx + 4]
0x142881e23:  66413bc2             cmp       ax, r10w
0x142881e27:  7563                 jne       0x142881e8c
0x142881e29:  6683f802             cmp       ax, 2
0x142881e2d:  752c                 jne       0x142881e5b
0x142881e2f:  8b442434             mov       eax, dword ptr [rsp + 0x34]
0x142881e33:  394108               cmp       dword ptr [rcx + 8], eax
0x142881e36:  7435                 je        0x142881e6d
0x142881e38:  eb52                 jmp       0x142881e8c
0x142881e3a:  664183fa17           cmp       r10w, 0x17
0x142881e3f:  759c                 jne       0x142881ddd
0x142881e41:  483b3d08da5605       cmp       rdi, qword ptr [rip + 0x556da08]
0x142881e48:  7593                 jne       0x142881ddd
0x142881e4a:  483b1d07da5605       cmp       rbx, qword ptr [rip + 0x556da07]
0x142881e51:  758a                 jne       0x142881ddd
0x142881e53:  4533db               xor       r11d, r11d
0x142881e56:  418bc3               mov       eax, r11d
0x142881e59:  eb71                 jmp       0x142881ecc
0x142881e5b:  6683f817             cmp       ax, 0x17
0x142881e5f:  752b                 jne       0x142881e8c
0x142881e61:  4839790c             cmp       qword ptr [rcx + 0xc], rdi
0x142881e65:  7525                 jne       0x142881e8c
0x142881e67:  48395914             cmp       qword ptr [rcx + 0x14], rbx
0x142881e6b:  751f                 jne       0x142881e8c
0x142881e6d:  0fb601               movzx     eax, byte ptr [rcx]
0x142881e70:  90                   nop       
0x142881e71:  84c0                 test      al, al
0x142881e73:  7543                 jne       0x142881eb8
0x142881e75:  440fb7542430         movzx     r10d, word ptr [rsp + 0x30]
0x142881e7b:  83faff               cmp       edx, -1
0x142881e7e:  488b5c2410           mov       rbx, qword ptr [rsp + 0x10]
0x142881e83:  488b7c2408           mov       rdi, qword ptr [rsp + 8]
0x142881e88:  410f44d0             cmove     edx, r8d
0x142881e8c:  410fb78112010000     movzx     eax, word ptr [r9 + 0x112]
0x142881e94:  41ffc0               inc       r8d
0x142881e97:  443bc0               cmp       r8d, eax
0x142881e9a:  0f8260ffffff         jb        0x142881e00
0x142881ea0:  83faff               cmp       edx, -1
0x142881ea3:  741f                 je        0x142881ec4
0x142881ea5:  4863c2               movsxd    rax, edx
0x142881ea8:  4869c0d8160000       imul      rax, rax, 0x16d8
0x142881eaf:  49038150030000       add       rax, qword ptr [r9 + 0x350]
0x142881eb6:  eb0f                 jmp       0x142881ec7
0x142881eb8:  498b8150030000       mov       rax, qword ptr [r9 + 0x350]
0x142881ebf:  4803c6               add       rax, rsi
0x142881ec2:  eb03                 jmp       0x142881ec7
0x142881ec4:  498bc3               mov       rax, r11
0x142881ec7:  488b742468           mov       rsi, qword ptr [rsp + 0x68]
0x142881ecc:  488b7c2470           mov       rdi, qword ptr [rsp + 0x70]
0x142881ed1:  488b5c2460           mov       rbx, qword ptr [rsp + 0x60]
0x142881ed6:  4885c0               test      rax, rax
0x142881ed9:  741f                 je        0x142881efa
0x142881edb:  0f108068060000       movups    xmm0, xmmword ptr [rax + 0x668]
0x142881ee2:  0f114500             movups    xmmword ptr [rbp], xmm0
0x142881ee6:  0f108878060000       movups    xmm1, xmmword ptr [rax + 0x678]
0x142881eed:  0f114d10             movups    xmmword ptr [rbp + 0x10], xmm1
0x142881ef1:  8b8088060000         mov       eax, dword ptr [rax + 0x688]
0x142881ef7:  894520               mov       dword ptr [rbp + 0x20], eax
0x142881efa:  4883c450             add       rsp, 0x50
0x142881efe:  5d                   pop       rbp
0x142881eff:  c3                   ret       
0x142881f00:  8b813c100000         mov       eax, dword ptr [rcx + 0x103c]
0x142881f06:  90                   nop       
0x142881f07:  8902                 mov       dword ptr [rdx], eax
0x142881f09:  c3                   ret       
0x142881f0a:  cc                   int3      
0x142881f0b:  cc                   int3      
0x142881f0c:  cc                   int3      
0x142881f0d:  cc                   int3      
0x142881f0e:  cc                   int3      
0x142881f0f:  cc                   int3      
