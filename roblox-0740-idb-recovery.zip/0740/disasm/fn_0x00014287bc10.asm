; function_of: vtab.RakPeer
; xref site 0x14287bc3a -> vtab.RakPeer @ 0x146ca34f0
; range 0x14287bc10 .. 0x14287d3c0  (6064 bytes)

0x00014287bc10:  e9db500200            jmp       0x1428a0cf0
0x00014287bc15:  cc                    int3      
0x00014287bc16:  cc                    int3      
0x00014287bc17:  cc                    int3      
0x00014287bc18:  cc                    int3      
0x00014287bc19:  cc                    int3      
0x00014287bc1a:  cc                    int3      
0x00014287bc1b:  cc                    int3      
0x00014287bc1c:  cc                    int3      
0x00014287bc1d:  cc                    int3      
0x00014287bc1e:  cc                    int3      
0x00014287bc1f:  cc                    int3      
0x00014287bc20:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014287bc25:  48896c2410            mov       qword ptr [rsp + 0x10], rbp
0x00014287bc2a:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x00014287bc2f:  57                    push      rdi
0x00014287bc30:  4883ec20              sub       rsp, 0x20
0x00014287bc34:  488bf9                mov       rdi, rcx
0x00014287bc37:  488d05b2784204        lea       rax, [rip + 0x44278b2]
0x00014287bc3e:  488901                mov       qword ptr [rcx], rax
0x00014287bc41:  e82a2f0000            call      0x14287eb70
0x00014287bc46:  4883bf0805000000      cmp       qword ptr [rdi + 0x508], 0
0x00014287bc4e:  7454                  je        0x14287bca4
0x00014287bc50:  488d8fa8040000        lea       rcx, [rdi + 0x4a8]
0x00014287bc57:  e8547b2a03            call      0x145b237b0
0x00014287bc5c:  85c0                  test      eax, eax
0x00014287bc5e:  0f8588040000          jne       0x14287c0ec
0x00014287bc64:  488b8700050000        mov       rax, qword ptr [rdi + 0x500]
0x00014287bc6b:  488b18                mov       rbx, qword ptr [rax]
0x00014287bc6e:  483bd8                cmp       rbx, rax
0x00014287bc71:  7419                  je        0x14287bc8c
0x00014287bc73:  488b4b30              mov       rcx, qword ptr [rbx + 0x30]
0x00014287bc77:  e834740c02            call      0x1449430b0
0x00014287bc7c:  90                    nop       
0x00014287bc7d:  488b03                mov       rax, qword ptr [rbx]
0x00014287bc80:  488bd8                mov       rbx, rax
0x00014287bc83:  483b8700050000        cmp       rax, qword ptr [rdi + 0x500]
0x00014287bc8a:  75e7                  jne       0x14287bc73
0x00014287bc8c:  488d8ff8040000        lea       rcx, [rdi + 0x4f8]
0x00014287bc93:  e858298efe            call      0x14115e5f0
0x00014287bc98:  488d8fa8040000        lea       rcx, [rdi + 0x4a8]
0x00014287bc9f:  e86c7b2a03            call      0x145b23810
0x00014287bca4:  33f6                  xor       esi, esi
0x00014287bca6:  8b05c4799305          mov       eax, dword ptr [rip + 0x59379c4]
0x00014287bcac:  85c0                  test      eax, eax
0x00014287bcae:  741b                  je        0x14287bccb
0x00014287bcb0:  83f801                cmp       eax, 1
0x00014287bcb3:  7e0a                  jle       0x14287bcbf
0x00014287bcb5:  ffc8                  dec       eax
0x00014287bcb7:  8905b3799305          mov       dword ptr [rip + 0x59379b3], eax
0x00014287bcbd:  eb0c                  jmp       0x14287bccb
0x00014287bcbf:  ff15a33b8c03          call      qword ptr [rip + 0x38c3ba3]
0x00014287bcc5:  8935a5799305          mov       dword ptr [rip + 0x59379a5], esi
0x00014287bccb:  488b8f48100000        mov       rcx, qword ptr [rdi + 0x1048]
0x00014287bcd2:  4885c9                test      rcx, rcx
0x00014287bcd5:  740e                  je        0x14287bce5
0x00014287bcd7:  488b01                mov       rax, qword ptr [rcx]
0x00014287bcda:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x00014287bcde:  ff1554408c03          call      qword ptr [rip + 0x38c4054]
0x00014287bce4:  90                    nop       
0x00014287bce5:  488d8f20100000        lea       rcx, [rdi + 0x1020]
0x00014287bcec:  e88f3405fe            call      0x1408cf180
0x00014287bcf1:  488d8f00100000        lea       rcx, [rdi + 0x1000]
0x00014287bcf8:  e8e39cf6fd            call      0x1407e59e0
0x00014287bcfd:  488d8f180f0000        lea       rcx, [rdi + 0xf18]
0x00014287bd04:  e8e74f0200            call      0x1428a0cf0
0x00014287bd09:  488b8f080f0000        mov       rcx, qword ptr [rdi + 0xf08]
0x00014287bd10:  4885c9                test      rcx, rcx
0x00014287bd13:  7405                  je        0x14287bd1a
0x00014287bd15:  e8f6d1f4fd            call      0x1407c8f10
0x00014287bd1a:  488d8fa80e0000        lea       rcx, [rdi + 0xea8]
0x00014287bd21:  e83a7a2a03            call      0x145b23760
0x00014287bd26:  488b8fa00e0000        mov       rcx, qword ptr [rdi + 0xea0]
0x00014287bd2d:  4885c9                test      rcx, rcx
0x00014287bd30:  7411                  je        0x14287bd43
0x00014287bd32:  488b01                mov       rax, qword ptr [rcx]
0x00014287bd35:  ba01000000            mov       edx, 1
0x00014287bd3a:  488b00                mov       rax, qword ptr [rax]
0x00014287bd3d:  ff15f53f8c03          call      qword ptr [rip + 0x38c3ff5]
0x00014287bd43:  488b8f980e0000        mov       rcx, qword ptr [rdi + 0xe98]
0x00014287bd4a:  4885c9                test      rcx, rcx
0x00014287bd4d:  7405                  je        0x14287bd54
0x00014287bd4f:  e8bcd1f4fd            call      0x1407c8f10
0x00014287bd54:  488d8f400e0000        lea       rcx, [rdi + 0xe40]
0x00014287bd5b:  e8007a2a03            call      0x145b23760
0x00014287bd60:  488d9fe00d0000        lea       rbx, [rdi + 0xde0]
0x00014287bd67:  488b4b38              mov       rcx, qword ptr [rbx + 0x38]
0x00014287bd6b:  4885c9                test      rcx, rcx
0x00014287bd6e:  7417                  je        0x14287bd87
0x00014287bd70:  488b01                mov       rax, qword ptr [rcx]
0x00014287bd73:  483bcb                cmp       rcx, rbx
0x00014287bd76:  0f95c2                setne     dl
0x00014287bd79:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x00014287bd7d:  ff15b53f8c03          call      qword ptr [rip + 0x38c3fb5]
0x00014287bd83:  48897338              mov       qword ptr [rbx + 0x38], rsi
0x00014287bd87:  488b8fd80d0000        mov       rcx, qword ptr [rdi + 0xdd8]
0x00014287bd8e:  4885c9                test      rcx, rcx
0x00014287bd91:  7405                  je        0x14287bd98
0x00014287bd93:  e878d1f4fd            call      0x1407c8f10
0x00014287bd98:  4c8b87980d0000        mov       r8, qword ptr [rdi + 0xd98]
0x00014287bd9f:  4d8b4008              mov       r8, qword ptr [r8 + 8]
0x00014287bda3:  488d97980d0000        lea       rdx, [rdi + 0xd98]
0x00014287bdaa:  488d8f980d0000        lea       rcx, [rdi + 0xd98]
0x00014287bdb1:  e8eaadfafd            call      0x140826ba0
0x00014287bdb6:  90                    nop       
0x00014287bdb7:  488b8f980d0000        mov       rcx, qword ptr [rdi + 0xd98]
0x00014287bdbe:  e8ed720c02            call      0x1449430b0
0x00014287bdc3:  90                    nop       
0x00014287bdc4:  488d8f780d0000        lea       rcx, [rdi + 0xd78]
0x00014287bdcb:  e8109cf6fd            call      0x1407e59e0
0x00014287bdd0:  488d8f500d0000        lea       rcx, [rdi + 0xd50]
0x00014287bdd7:  e8049cf6fd            call      0x1407e59e0
0x00014287bddc:  488d8f300d0000        lea       rcx, [rdi + 0xd30]
0x00014287bde3:  e8f89bf6fd            call      0x1407e59e0
0x00014287bde8:  488d8fd80c0000        lea       rcx, [rdi + 0xcd8]
0x00014287bdef:  e86c792a03            call      0x145b23760
0x00014287bdf4:  488d8f980c0000        lea       rcx, [rdi + 0xc98]
0x00014287bdfb:  e87056f6fd            call      0x1407e1470
0x00014287be00:  83bf900c000000        cmp       dword ptr [rdi + 0xc90], 0
0x00014287be07:  760d                  jbe       0x14287be16
0x00014287be09:  488b8f800c0000        mov       rcx, qword ptr [rdi + 0xc80]
0x00014287be10:  e89b720c02            call      0x1449430b0
0x00014287be15:  90                    nop       
0x00014287be16:  488d8f300c0000        lea       rcx, [rdi + 0xc30]
0x00014287be1d:  e83e792a03            call      0x145b23760
0x00014287be22:  90                    nop       
0x00014287be23:  488d8f100c0000        lea       rcx, [rdi + 0xc10]
0x00014287be2a:  e8115a0200            call      0x1428a1840
0x00014287be2f:  90                    nop       
0x00014287be30:  488d8fc00b0000        lea       rcx, [rdi + 0xbc0]
0x00014287be37:  e824792a03            call      0x145b23760
0x00014287be3c:  488d8f680b0000        lea       rcx, [rdi + 0xb68]
0x00014287be43:  e828355a00            call      0x142e1f370
0x00014287be48:  488d8f180b0000        lea       rcx, [rdi + 0xb18]
0x00014287be4f:  e80c792a03            call      0x145b23760
0x00014287be54:  488d8f100b0000        lea       rcx, [rdi + 0xb10]
0x00014287be5b:  e800bd78fd            call      0x140007b60
0x00014287be60:  488d8f080b0000        lea       rcx, [rdi + 0xb08]
0x00014287be67:  e8f4bc78fd            call      0x140007b60
0x00014287be6c:  488d8ff80a0000        lea       rcx, [rdi + 0xaf8]
0x00014287be73:  e8e8bc78fd            call      0x140007b60
0x00014287be78:  488d8ff00a0000        lea       rcx, [rdi + 0xaf0]
0x00014287be7f:  e8dcbc78fd            call      0x140007b60
0x00014287be84:  83bf8c09000000        cmp       dword ptr [rdi + 0x98c], 0
0x00014287be8b:  762e                  jbe       0x14287bebb
0x00014287be8d:  488b8f80090000        mov       rcx, qword ptr [rdi + 0x980]
0x00014287be94:  4885c9                test      rcx, rcx
0x00014287be97:  7422                  je        0x14287bebb
0x00014287be99:  488d59f8              lea       rbx, [rcx - 8]
0x00014287be9d:  4c8d0dacd70300        lea       r9, [rip + 0x3d7ac]
0x00014287bea4:  4c8b03                mov       r8, qword ptr [rbx]
0x00014287bea7:  ba08000000            mov       edx, 8
0x00014287beac:  e8ff572a03            call      0x145b216b0
0x00014287beb1:  90                    nop       
0x00014287beb2:  488bcb                mov       rcx, rbx
0x00014287beb5:  e8f6710c02            call      0x1449430b0
0x00014287beba:  90                    nop       
0x00014287bebb:  83bf0c09000000        cmp       dword ptr [rdi + 0x90c], 0
0x00014287bec2:  762e                  jbe       0x14287bef2
0x00014287bec4:  488b8f00090000        mov       rcx, qword ptr [rdi + 0x900]
0x00014287becb:  4885c9                test      rcx, rcx
0x00014287bece:  7422                  je        0x14287bef2
0x00014287bed0:  488d59f8              lea       rbx, [rcx - 8]
0x00014287bed4:  4c8d0d25e4f4fd        lea       r9, [rip - 0x20b1bdb]
0x00014287bedb:  4c8b03                mov       r8, qword ptr [rbx]
0x00014287bede:  ba10000000            mov       edx, 0x10
0x00014287bee3:  e8c8572a03            call      0x145b216b0
0x00014287bee8:  90                    nop       
0x00014287bee9:  488bcb                mov       rcx, rbx
0x00014287beec:  e8bf710c02            call      0x1449430b0
0x00014287bef1:  90                    nop       
0x00014287bef2:  488d8fd8080000        lea       rcx, [rdi + 0x8d8]
0x00014287bef9:  e8823205fe            call      0x1408cf180
0x00014287befe:  488d8f88080000        lea       rcx, [rdi + 0x888]
0x00014287bf05:  e856782a03            call      0x145b23760
0x00014287bf0a:  488d8f38080000        lea       rcx, [rdi + 0x838]
0x00014287bf11:  e84a782a03            call      0x145b23760
0x00014287bf16:  83bf3008000000        cmp       dword ptr [rdi + 0x830], 0
0x00014287bf1d:  760d                  jbe       0x14287bf2c
0x00014287bf1f:  488b8f20080000        mov       rcx, qword ptr [rdi + 0x820]
0x00014287bf26:  e885710c02            call      0x1449430b0
0x00014287bf2b:  90                    nop       
0x00014287bf2c:  488d8fd0070000        lea       rcx, [rdi + 0x7d0]
0x00014287bf33:  e828782a03            call      0x145b23760
0x00014287bf38:  90                    nop       
0x00014287bf39:  488d8fb0070000        lea       rcx, [rdi + 0x7b0]
0x00014287bf40:  e8fb580200            call      0x1428a1840
0x00014287bf45:  90                    nop       
0x00014287bf46:  488d8f50070000        lea       rcx, [rdi + 0x750]
0x00014287bf4d:  e80e782a03            call      0x145b23760
0x00014287bf52:  83bf4807000000        cmp       dword ptr [rdi + 0x748], 0
0x00014287bf59:  760d                  jbe       0x14287bf68
0x00014287bf5b:  488b8f38070000        mov       rcx, qword ptr [rdi + 0x738]
0x00014287bf62:  e849710c02            call      0x1449430b0
0x00014287bf67:  90                    nop       
0x00014287bf68:  488d8fe8060000        lea       rcx, [rdi + 0x6e8]
0x00014287bf6f:  e8ec772a03            call      0x145b23760
0x00014287bf74:  90                    nop       
0x00014287bf75:  488d8fc8060000        lea       rcx, [rdi + 0x6c8]
0x00014287bf7c:  e8bf580200            call      0x1428a1840
0x00014287bf81:  90                    nop       
0x00014287bf82:  488d8f78060000        lea       rcx, [rdi + 0x678]
0x00014287bf89:  e8d2772a03            call      0x145b23760
0x00014287bf8e:  83bf7006000000        cmp       dword ptr [rdi + 0x670], 0
0x00014287bf95:  760d                  jbe       0x14287bfa4
0x00014287bf97:  488b8f60060000        mov       rcx, qword ptr [rdi + 0x660]
0x00014287bf9e:  e80d710c02            call      0x1449430b0
0x00014287bfa3:  90                    nop       
0x00014287bfa4:  488d8f10060000        lea       rcx, [rdi + 0x610]
0x00014287bfab:  e8b0772a03            call      0x145b23760
0x00014287bfb0:  90                    nop       
0x00014287bfb1:  488d8ff0050000        lea       rcx, [rdi + 0x5f0]
0x00014287bfb8:  e883580200            call      0x1428a1840
0x00014287bfbd:  90                    nop       
0x00014287bfbe:  4887b7e8050000        xchg      qword ptr [rdi + 0x5e8], rsi
0x00014287bfc5:  4885f6                test      rsi, rsi
0x00014287bfc8:  7409                  je        0x14287bfd3
0x00014287bfca:  488bce                mov       rcx, rsi
0x00014287bfcd:  ff15f52d8c03          call      qword ptr [rip + 0x38c2df5]
0x00014287bfd3:  488d8fc0050000        lea       rcx, [rdi + 0x5c0]
0x00014287bfda:  e821490200            call      0x1428a0900
0x00014287bfdf:  488d8fa0050000        lea       rcx, [rdi + 0x5a0]
0x00014287bfe6:  e815490200            call      0x1428a0900
0x00014287bfeb:  488d8f50050000        lea       rcx, [rdi + 0x550]
0x00014287bff2:  e869772a03            call      0x145b23760
0x00014287bff7:  83bf4805000000        cmp       dword ptr [rdi + 0x548], 0
0x00014287bffe:  760d                  jbe       0x14287c00d
0x00014287c000:  488b8f38050000        mov       rcx, qword ptr [rdi + 0x538]
0x00014287c007:  e8a4700c02            call      0x1449430b0
0x00014287c00c:  90                    nop       
0x00014287c00d:  488d8ff8040000        lea       rcx, [rdi + 0x4f8]
0x00014287c014:  e85754f6fd            call      0x1407e1470
0x00014287c019:  488d8fa8040000        lea       rcx, [rdi + 0x4a8]
0x00014287c020:  e83b772a03            call      0x145b23760
0x00014287c025:  488d8f58040000        lea       rcx, [rdi + 0x458]
0x00014287c02c:  e82f772a03            call      0x145b23760
0x00014287c031:  488d8fa8030000        lea       rcx, [rdi + 0x3a8]
0x00014287c038:  4c8d0d61d6f4fd        lea       r9, [rip - 0x20b299f]
0x00014287c03f:  ba50000000            mov       edx, 0x50
0x00014287c044:  448d42b2              lea       r8d, [rdx - 0x4e]
0x00014287c048:  e863562a03            call      0x145b216b0
0x00014287c04d:  90                    nop       
0x00014287c04e:  488d8f88030000        lea       rcx, [rdi + 0x388]
0x00014287c055:  e8e6570200            call      0x1428a1840
0x00014287c05a:  90                    nop       
0x00014287c05b:  488b8f68030000        mov       rcx, qword ptr [rdi + 0x368]
0x00014287c062:  4885c9                test      rcx, rcx
0x00014287c065:  7406                  je        0x14287c06d
0x00014287c067:  e844700c02            call      0x1449430b0
0x00014287c06c:  90                    nop       
0x00014287c06d:  488d05547c4204        lea       rax, [rip + 0x4427c54]
0x00014287c074:  48898718010000        mov       qword ptr [rdi + 0x118], rax
0x00014287c07b:  80bf4001000000        cmp       byte ptr [rdi + 0x140], 0
0x00014287c082:  7432                  je        0x14287c0b6
0x00014287c084:  8b872c010000          mov       eax, dword ptr [rdi + 0x12c]
0x00014287c08a:  3d00080000            cmp       eax, 0x800
0x00014287c08f:  7609                  jbe       0x14287c09a
0x00014287c091:  488b8f38010000        mov       rcx, qword ptr [rdi + 0x138]
0x00014287c098:  eb17                  jmp       0x14287c0b1
0x00014287c09a:  85c0                  test      eax, eax
0x00014287c09c:  7418                  je        0x14287c0b6
0x00014287c09e:  488b8f38010000        mov       rcx, qword ptr [rdi + 0x138]
0x00014287c0a5:  488d8741010000        lea       rax, [rdi + 0x141]
0x00014287c0ac:  483bc8                cmp       rcx, rax
0x00014287c0af:  7405                  je        0x14287c0b6
0x00014287c0b1:  e8fa6f0c02            call      0x1449430b0
0x00014287c0b6:  488d05fbdc4004        lea       rax, [rip + 0x440dcfb]
0x00014287c0bd:  48898718010000        mov       qword ptr [rdi + 0x118], rax
0x00014287c0c4:  488d4f08              lea       rcx, [rdi + 8]
0x00014287c0c8:  e8b33005fe            call      0x1408cf180
0x00014287c0cd:  488d0504784204        lea       rax, [rip + 0x4427804]
0x00014287c0d4:  488907                mov       qword ptr [rdi], rax
0x00014287c0d7:  488b5c2430            mov       rbx, qword ptr [rsp + 0x30]
0x00014287c0dc:  488b6c2438            mov       rbp, qword ptr [rsp + 0x38]
0x00014287c0e1:  488b742440            mov       rsi, qword ptr [rsp + 0x40]
0x00014287c0e6:  4883c420              add       rsp, 0x20
0x00014287c0ea:  5f                    pop       rdi
0x00014287c0eb:  c3                    ret       
0x00014287c0ec:  8bc8                  mov       ecx, eax
0x00014287c0ee:  e88d7c2a03            call      0x145b23d80
0x00014287c0f3:  cc                    int3      
0x00014287c0f4:  cc                    int3      
0x00014287c0f5:  cc                    int3      
0x00014287c0f6:  cc                    int3      
0x00014287c0f7:  cc                    int3      
0x00014287c0f8:  cc                    int3      
0x00014287c0f9:  cc                    int3      
0x00014287c0fa:  cc                    int3      
0x00014287c0fb:  cc                    int3      
0x00014287c0fc:  cc                    int3      
0x00014287c0fd:  cc                    int3      
0x00014287c0fe:  cc                    int3      
0x00014287c0ff:  cc                    int3      
0x00014287c100:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x00014287c105:  55                    push      rbp
0x00014287c106:  56                    push      rsi
0x00014287c107:  57                    push      rdi
0x00014287c108:  4154                  push      r12
0x00014287c10a:  4155                  push      r13
0x00014287c10c:  4156                  push      r14
0x00014287c10e:  4157                  push      r15
0x00014287c110:  488dac24f0f7ffff      lea       rbp, [rsp - 0x810]
0x00014287c118:  4881ec10090000        sub       rsp, 0x910
0x00014287c11f:  488b05ca754905        mov       rax, qword ptr [rip + 0x54975ca]
0x00014287c126:  4833c4                xor       rax, rsp
0x00014287c129:  48898500080000        mov       qword ptr [rbp + 0x800], rax
0x00014287c130:  498bf9                mov       rdi, r9
0x00014287c133:  4d8bf0                mov       r14, r8
0x00014287c136:  440fb7e2              movzx     r12d, dx
0x00014287c13a:  6689542448            mov       word ptr [rsp + 0x48], dx
0x00014287c13f:  488bf1                mov       rsi, rcx
0x00014287c142:  448b153fa4a405        mov       r10d, dword ptr [rip + 0x5a4a43f]
0x00014287c149:  803da8aea40500        cmp       byte ptr [rip + 0x5a4aea8], 0
0x00014287c150:  440f451534a4a405      cmovne    r10d, dword ptr [rip + 0x5a4a434]
0x00014287c158:  33db                  xor       ebx, ebx
0x00014287c15a:  4181fa00040000        cmp       r10d, 0x400
0x00014287c161:  721c                  jb        0x14287c17f
0x00014287c163:  381d2ae09805          cmp       byte ptr [rip + 0x598e02a], bl
0x00014287c169:  740c                  je        0x14287c177
0x00014287c16b:  381dd723d505          cmp       byte ptr [rip + 0x5d523d7], bl
0x00014287c171:  0f85cc0d0000          jne       0x14287cf43
0x00014287c177:  8bcb                  mov       ecx, ebx
0x00014287c179:  895c2458              mov       dword ptr [rsp + 0x58], ebx
0x00014287c17d:  eb10                  jmp       0x14287c18f
0x00014287c17f:  e88ca10d02            call      0x144956310
0x00014287c184:  8b4808                mov       ecx, dword ptr [rax + 8]
0x00014287c187:  894c2458              mov       dword ptr [rsp + 0x58], ecx
0x00014287c18b:  44895008              mov       dword ptr [rax + 8], r10d
0x00014287c18f:  894dd0                mov       dword ptr [rbp - 0x30], ecx
0x00014287c192:  488b06                mov       rax, qword ptr [rsi]
0x00014287c195:  488bce                mov       rcx, rsi
0x00014287c198:  488b4078              mov       rax, qword ptr [rax + 0x78]
0x00014287c19c:  ff15963b8c03          call      qword ptr [rip + 0x38c3b96]
0x00014287c1a2:  84c0                  test      al, al
0x00014287c1a4:  740b                  je        0x14287c1b1
0x00014287c1a6:  41bd01000000          mov       r13d, 1
0x00014287c1ac:  e90f0d0000            jmp       0x14287cec0
0x00014287c1b1:  8bcb                  mov       ecx, ebx
0x00014287c1b3:  81bd880800006179feff  cmp       dword ptr [rbp + 0x888], 0xfffe7961
0x00014287c1bd:  0f458d88080000        cmovne    ecx, dword ptr [rbp + 0x888]
0x00014287c1c4:  894c2454              mov       dword ptr [rsp + 0x54], ecx
0x00014287c1c8:  488d8e90090000        lea       rcx, [rsi + 0x990]
0x00014287c1cf:  e88cc30200            call      0x1428a8560
0x00014287c1d4:  4885ff                test      rdi, rdi
0x00014287c1d7:  0f84dd0c0000          je        0x14287ceba
0x00014287c1dd:  8b9570080000          mov       edx, dword ptr [rbp + 0x870]
0x00014287c1e3:  83fa01                cmp       edx, 1
0x00014287c1e6:  0f82ce0c0000          jb        0x14287ceba
0x00014287c1ec:  41bf02000000          mov       r15d, 2
0x00014287c1f2:  803d5fdea40500        cmp       byte ptr [rip + 0x5a4de5f], 0
0x00014287c1f9:  0f84b9000000          je        0x14287c2b8
0x00014287c1ff:  83fa01                cmp       edx, 1
0x00014287c202:  0f84b0000000          je        0x14287c2b8
0x00014287c208:  488b05a1f84e05        mov       rax, qword ptr [rip + 0x54ef8a1]
0x00014287c20f:  3c06                  cmp       al, 6
0x00014287c211:  0f82a1000000          jb        0x14287c2b8
0x00014287c217:  48c1e808              shr       rax, 8
0x00014287c21b:  3c03                  cmp       al, 3
0x00014287c21d:  0f8295000000          jb        0x14287c2b8
0x00014287c223:  488d05a52ca904        lea       rax, [rip + 0x4a92ca5]
0x00014287c22a:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x00014287c22f:  488b4c2460            mov       rcx, qword ptr [rsp + 0x60]
0x00014287c234:  4881c1a193c2ff        add       rcx, -0x3d6c5f
0x00014287c23b:  48894df0              mov       qword ptr [rbp - 0x10], rcx
0x00014287c23f:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x00014287c246:  48ffc0                inc       rax
0x00014287c249:  803c0100              cmp       byte ptr [rcx + rax], 0
0x00014287c24d:  75f7                  jne       0x14287c246
0x00014287c24f:  488945f8              mov       qword ptr [rbp - 8], rax
0x00014287c253:  8955a0                mov       dword ptr [rbp - 0x60], edx
0x00014287c256:  0f2845a0              movaps    xmm0, xmmword ptr [rbp - 0x60]
0x00014287c25a:  660f7f85c0010000      movdqa    xmmword ptr [rbp + 0x1c0], xmm0
0x00014287c262:  4c897de0              mov       qword ptr [rbp - 0x20], r15
0x00014287c266:  488d85c0010000        lea       rax, [rbp + 0x1c0]
0x00014287c26d:  488945e8              mov       qword ptr [rbp - 0x18], rax
0x00014287c271:  0f2845e0              movaps    xmm0, xmmword ptr [rbp - 0x20]
0x00014287c275:  660f7f85b0000000      movdqa    xmmword ptr [rbp + 0xb0], xmm0
0x00014287c27d:  0f284df0              movaps    xmm1, xmmword ptr [rbp - 0x10]
0x00014287c281:  660f7f8dc0000000      movdqa    xmmword ptr [rbp + 0xc0], xmm1
0x00014287c289:  0f100520f84e05        movups    xmm0, xmmword ptr [rip + 0x54ef820]
0x00014287c290:  0f2985d0000000        movaps    xmmword ptr [rbp + 0xd0], xmm0
0x00014287c297:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x00014287c29c:  4c8d8db0000000        lea       r9, [rbp + 0xb0]
0x00014287c2a3:  4c8d85c0000000        lea       r8, [rbp + 0xc0]
0x00014287c2aa:  b203                  mov       dl, 3
0x00014287c2ac:  488d8dd0000000        lea       rcx, [rbp + 0xd0]
0x00014287c2b3:  e818380e02            call      0x14495fad0
0x00014287c2b8:  4c89b6100f0000        mov       qword ptr [rsi + 0xf10], r14
0x00014287c2bf:  664585e4              test      r12w, r12w
0x00014287c2c3:  750b                  jne       0x14287c2d0
0x00014287c2c5:  41bd03000000          mov       r13d, 3
0x00014287c2cb:  e9f00b0000            jmp       0x14287cec0
0x00014287c2d0:  488bce                mov       rcx, rsi
0x00014287c2d3:  e808f90000            call      0x14288bbe0
0x00014287c2d8:  895c2450              mov       dword ptr [rsp + 0x50], ebx
0x00014287c2dc:  895c244c              mov       dword ptr [rsp + 0x4c], ebx
0x00014287c2e0:  4883c744              add       rdi, 0x44
0x00014287c2e4:  48897c2460            mov       qword ptr [rsp + 0x60], rdi
0x00014287c2e9:  41bd01000000          mov       r13d, 1
0x00014287c2ef:  90                    nop       
0x00014287c2f0:  b938000000            mov       ecx, 0x38
0x00014287c2f5:  e806750c02            call      0x144943800
0x00014287c2fa:  4c8bf0                mov       r14, rax
0x00014287c2fd:  4885c0                test      rax, rax
0x00014287c300:  0f84140c0000          je        0x14287cf1a
0x00014287c306:  0f57c0                xorps     xmm0, xmm0
0x00014287c309:  33c0                  xor       eax, eax
0x00014287c30b:  410f11460c            movups    xmmword ptr [r14 + 0xc], xmm0
0x00014287c310:  4989461c              mov       qword ptr [r14 + 0x1c], rax
0x00014287c314:  41894624              mov       dword ptr [r14 + 0x24], eax
0x00014287c318:  6645897e0c            mov       word ptr [r14 + 0xc], r15w
0x00014287c31d:  41c746280000ffff      mov       dword ptr [r14 + 0x28], 0xffff0000
0x00014287c325:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x00014287c32c:  498906                mov       qword ptr [r14], rax
0x00014287c32f:  49894630              mov       qword ptr [r14 + 0x30], rax
0x00014287c333:  f30f7f45a0            movdqu    xmmword ptr [rbp - 0x60], xmm0
0x00014287c338:  4c8975d8              mov       qword ptr [rbp - 0x28], r14
0x00014287c33c:  8d4819                lea       ecx, [rax + 0x19]
0x00014287c33f:  e8bc740c02            call      0x144943800
0x00014287c344:  4c8bf8                mov       r15, rax
0x00014287c347:  4885c0                test      rax, rax
0x00014287c34a:  0f847c0c0000          je        0x14287cfcc
0x00014287c350:  44896808              mov       dword ptr [rax + 8], r13d
0x00014287c354:  4489680c              mov       dword ptr [rax + 0xc], r13d
0x00014287c358:  488d0529714204        lea       rax, [rip + 0x4427129]
0x00014287c35f:  498907                mov       qword ptr [r15], rax
0x00014287c362:  4d897710              mov       qword ptr [r15 + 0x10], r14
0x00014287c366:  4c8975a0              mov       qword ptr [rbp - 0x60], r14
0x00014287c36a:  4c897da8              mov       qword ptr [rbp - 0x58], r15
0x00014287c36e:  48895dd8              mov       qword ptr [rbp - 0x28], rbx
0x00014287c372:  0fb73f                movzx     edi, word ptr [rdi]
0x00014287c375:  48895c2468            mov       qword ptr [rsp + 0x68], rbx
0x00014287c37a:  0f57c0                xorps     xmm0, xmm0
0x00014287c37d:  0f114578              movups    xmmword ptr [rbp + 0x78], xmm0
0x00014287c381:  0f118588000000        movups    xmmword ptr [rbp + 0x88], xmm0
0x00014287c388:  0f118598000000        movups    xmmword ptr [rbp + 0x98], xmm0
0x00014287c38f:  c7858000000002000000  mov       dword ptr [rbp + 0x80], 2
0x00014287c399:  6685ff                test      di, di
0x00014287c39c:  7403                  je        0x14287c3a1
0x00014287c39e:  897d7c                mov       dword ptr [rbp + 0x7c], edi
0x00014287c3a1:  c74578000d0000        mov       dword ptr [rbp + 0x78], 0xd00
0x00014287c3a8:  4c8d4c2468            lea       r9, [rsp + 0x68]
0x00014287c3ad:  4c8d4578              lea       r8, [rbp + 0x78]
0x00014287c3b1:  488d157cdc5604        lea       rdx, [rip + 0x456dc7c]
0x00014287c3b8:  33c9                  xor       ecx, ecx
0x00014287c3ba:  ff1580348c03          call      qword ptr [rip + 0x38c3480]
0x00014287c3c0:  85c0                  test      eax, eax
0x00014287c3c2:  744a                  je        0x14287c40e
0x00014287c3c4:  488b0de5f64e05        mov       rcx, qword ptr [rip + 0x54ef6e5]
0x00014287c3cb:  80f906                cmp       cl, 6
0x00014287c3ce:  723e                  jb        0x14287c40e
0x00014287c3d0:  48c1e908              shr       rcx, 8
0x00014287c3d4:  80f903                cmp       cl, 3
0x00014287c3d7:  7235                  jb        0x14287c40e
0x00014287c3d9:  488d0daf737804        lea       rcx, [rip + 0x47873af]
0x00014287c3e0:  48894c2440            mov       qword ptr [rsp + 0x40], rcx
0x00014287c3e5:  488b542440            mov       rdx, qword ptr [rsp + 0x40]
0x00014287c3ea:  488d15bffb6b04        lea       rdx, [rip + 0x46bfbbf]
0x00014287c3f1:  0f1005b8f64e05        movups    xmm0, xmmword ptr [rip + 0x54ef6b8]
0x00014287c3f8:  0f2985e0000000        movaps    xmmword ptr [rbp + 0xe0], xmm0
0x00014287c3ff:  448bc0                mov       r8d, eax
0x00014287c402:  488d8de0000000        lea       rcx, [rbp + 0xe0]
0x00014287c409:  e882340e02            call      0x14495f890
0x00014287c40e:  6685ff                test      di, di
0x00014287c411:  0f8595000000          jne       0x14287c4ac
0x00014287c417:  40383dbadda405        cmp       byte ptr [rip + 0x5a4ddba], dil
0x00014287c41e:  0f8488000000          je        0x14287c4ac
0x00014287c424:  48895d90              mov       qword ptr [rbp - 0x70], rbx
0x00014287c428:  48895d88              mov       qword ptr [rbp - 0x78], rbx
0x00014287c42c:  488bfb                mov       rdi, rbx
0x00014287c42f:  48895c2478            mov       qword ptr [rsp + 0x78], rbx
0x00014287c434:  48895d80              mov       qword ptr [rbp - 0x80], rbx
0x00014287c438:  488b4c2468            mov       rcx, qword ptr [rsp + 0x68]
0x00014287c43d:  4885c9                test      rcx, rcx
0x00014287c440:  7463                  je        0x14287c4a5
0x00014287c442:  4c8b4928              mov       r9, qword ptr [rcx + 0x28]
0x00014287c446:  48895928              mov       qword ptr [rcx + 0x28], rbx
0x00014287c44a:  488d5590              lea       rdx, [rbp - 0x70]
0x00014287c44e:  4c8d442478            lea       r8, [rsp + 0x78]
0x00014287c453:  83790417              cmp       dword ptr [rcx + 4], 0x17
0x00014287c457:  490f45d0              cmovne    rdx, r8
0x00014287c45b:  4c8d4588              lea       r8, [rbp - 0x78]
0x00014287c45f:  4c8d5580              lea       r10, [rbp - 0x80]
0x00014287c463:  4d0f45c2              cmovne    r8, r10
0x00014287c467:  498b00                mov       rax, qword ptr [r8]
0x00014287c46a:  4885c0                test      rax, rax
0x00014287c46d:  7505                  jne       0x14287c474
0x00014287c46f:  48890a                mov       qword ptr [rdx], rcx
0x00014287c472:  eb04                  jmp       0x14287c478
0x00014287c474:  48894828              mov       qword ptr [rax + 0x28], rcx
0x00014287c478:  498908                mov       qword ptr [r8], rcx
0x00014287c47b:  498bc9                mov       rcx, r9
0x00014287c47e:  4d85c9                test      r9, r9
0x00014287c481:  75bf                  jne       0x14287c442
0x00014287c483:  488b4d88              mov       rcx, qword ptr [rbp - 0x78]
0x00014287c487:  4885c9                test      rcx, rcx
0x00014287c48a:  7414                  je        0x14287c4a0
0x00014287c48c:  488b442478            mov       rax, qword ptr [rsp + 0x78]
0x00014287c491:  48894128              mov       qword ptr [rcx + 0x28], rax
0x00014287c495:  488b7d90              mov       rdi, qword ptr [rbp - 0x70]
0x00014287c499:  48897c2468            mov       qword ptr [rsp + 0x68], rdi
0x00014287c49e:  eb11                  jmp       0x14287c4b1
0x00014287c4a0:  488b7c2478            mov       rdi, qword ptr [rsp + 0x78]
0x00014287c4a5:  48897c2468            mov       qword ptr [rsp + 0x68], rdi
0x00014287c4aa:  eb05                  jmp       0x14287c4b1
0x00014287c4ac:  488b7c2468            mov       rdi, qword ptr [rsp + 0x68]
0x00014287c4b1:  4885ff                test      rdi, rdi
0x00014287c4b4:  0f8420040000          je        0x14287c8da
0x00014287c4ba:  ff442450              inc       dword ptr [rsp + 0x50]
0x00014287c4be:  488b4c2460            mov       rcx, qword ptr [rsp + 0x60]
0x00014287c4c3:  0fb701                movzx     eax, word ptr [rcx]
0x00014287c4c6:  6689442420            mov       word ptr [rsp + 0x20], ax
0x00014287c4cb:  440fb78d80080000      movzx     r9d, word ptr [rbp + 0x880]
0x00014287c4d3:  440fb78578080000      movzx     r8d, word ptr [rbp + 0x878]
0x00014287c4db:  0fb751bc              movzx     edx, word ptr [rcx - 0x44]
0x00014287c4df:  488bcf                mov       rcx, rdi
0x00014287c4e2:  e889b30200            call      0x1428a7870
0x00014287c4e7:  8bc8                  mov       ecx, eax
0x00014287c4e9:  49890e                mov       qword ptr [r14], rcx
0x00014287c4ec:  488bcf                mov       rcx, rdi
0x00014287c4ef:  ff1553338c03          call      qword ptr [rip + 0x38c3353]
0x00014287c4f5:  498b0e                mov       rcx, qword ptr [r14]
0x00014287c4f8:  4883f9ff              cmp       rcx, -1
0x00014287c4fc:  0f8478040000          je        0x14287c97a
0x00014287c502:  486305dfc8a405        movsxd    rax, dword ptr [rip + 0x5a4c8df]
0x00014287c509:  85c0                  test      eax, eax
0x00014287c50b:  0f8e81010000          jle       0x14287c692
0x00014287c511:  89442470              mov       dword ptr [rsp + 0x70], eax
0x00014287c515:  c744242004000000      mov       dword ptr [rsp + 0x20], 4
0x00014287c51d:  4c8d4c2470            lea       r9, [rsp + 0x70]
0x00014287c522:  baffff0000            mov       edx, 0xffff
0x00014287c527:  41b805100000          mov       r8d, 0x1005
0x00014287c52d:  ff1545338c03          call      qword ptr [rip + 0x38c3345]
0x00014287c533:  85c0                  test      eax, eax
0x00014287c535:  0f8457010000          je        0x14287c692
0x00014287c53b:  488b056ef54e05        mov       rax, qword ptr [rip + 0x54ef56e]
0x00014287c542:  3c06                  cmp       al, 6
0x00014287c544:  0f8248010000          jb        0x14287c692
0x00014287c54a:  48c1e808              shr       rax, 8
0x00014287c54e:  3c03                  cmp       al, 3
0x00014287c550:  0f823c010000          jb        0x14287c692
0x00014287c556:  488d056e86ac04        lea       rax, [rip + 0x4ac866e]
0x00014287c55d:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x00014287c562:  488b7c2440            mov       rdi, qword ptr [rsp + 0x40]
0x00014287c567:  488d3d62bc6b04        lea       rdi, [rip + 0x46bbc62]
0x00014287c56e:  ff156c338c03          call      qword ptr [rip + 0x38c336c]
0x00014287c574:  448bc0                mov       r8d, eax
0x00014287c577:  488b05ea295605        mov       rax, qword ptr [rip + 0x55629ea]
0x00014287c57e:  488d9580010000        lea       rdx, [rbp + 0x180]
0x00014287c585:  488d0ddc295605        lea       rcx, [rip + 0x55629dc]
0x00014287c58c:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x00014287c590:  ff15a2378c03          call      qword ptr [rip + 0x38c37a2]
0x00014287c596:  90                    nop       
0x00014287c597:  48897d20              mov       qword ptr [rbp + 0x20], rdi
0x00014287c59b:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x00014287c5a2:  48ffc0                inc       rax
0x00014287c5a5:  803c0700              cmp       byte ptr [rdi + rax], 0
0x00014287c5a9:  75f7                  jne       0x14287c5a2
0x00014287c5ab:  48894528              mov       qword ptr [rbp + 0x28], rax
0x00014287c5af:  488d8580010000        lea       rax, [rbp + 0x180]
0x00014287c5b6:  4883bd9801000010      cmp       qword ptr [rbp + 0x198], 0x10
0x00014287c5be:  480f438580010000      cmovae    rax, qword ptr [rbp + 0x180]
0x00014287c5c6:  48894500              mov       qword ptr [rbp], rax
0x00014287c5ca:  488b8590010000        mov       rax, qword ptr [rbp + 0x190]
0x00014287c5d1:  48894508              mov       qword ptr [rbp + 8], rax
0x00014287c5d5:  0f284500              movaps    xmm0, xmmword ptr [rbp]
0x00014287c5d9:  660f7f85d0010000      movdqa    xmmword ptr [rbp + 0x1d0], xmm0
0x00014287c5e1:  48c745100d000000      mov       qword ptr [rbp + 0x10], 0xd
0x00014287c5e9:  488d85d0010000        lea       rax, [rbp + 0x1d0]
0x00014287c5f0:  48894518              mov       qword ptr [rbp + 0x18], rax
0x00014287c5f4:  0f284510              movaps    xmm0, xmmword ptr [rbp + 0x10]
0x00014287c5f8:  660f7f85f0000000      movdqa    xmmword ptr [rbp + 0xf0], xmm0
0x00014287c600:  0f284d20              movaps    xmm1, xmmword ptr [rbp + 0x20]
0x00014287c604:  660f7f8d00010000      movdqa    xmmword ptr [rbp + 0x100], xmm1
0x00014287c60c:  0f10059df44e05        movups    xmm0, xmmword ptr [rip + 0x54ef49d]
0x00014287c613:  0f298510010000        movaps    xmmword ptr [rbp + 0x110], xmm0
0x00014287c61a:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x00014287c61f:  4c8d8df0000000        lea       r9, [rbp + 0xf0]
0x00014287c626:  4c8d8500010000        lea       r8, [rbp + 0x100]
0x00014287c62d:  b203                  mov       dl, 3
0x00014287c62f:  488d8d10010000        lea       rcx, [rbp + 0x110]
0x00014287c636:  e895340e02            call      0x14495fad0
0x00014287c63b:  90                    nop       
0x00014287c63c:  488b8598010000        mov       rax, qword ptr [rbp + 0x198]
0x00014287c643:  4883f810              cmp       rax, 0x10
0x00014287c647:  7230                  jb        0x14287c679
0x00014287c649:  48ffc0                inc       rax
0x00014287c64c:  488b8d80010000        mov       rcx, qword ptr [rbp + 0x180]
0x00014287c653:  488bd1                mov       rdx, rcx
0x00014287c656:  483d00100000          cmp       rax, 0x1000
0x00014287c65c:  7215                  jb        0x14287c673
0x00014287c65e:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014287c662:  482bd1                sub       rdx, rcx
0x00014287c665:  488d42f8              lea       rax, [rdx - 8]
0x00014287c669:  4883f81f              cmp       rax, 0x1f
0x00014287c66d:  0f87df080000          ja        0x14287cf52
0x00014287c673:  e8386a0c02            call      0x1449430b0
0x00014287c678:  90                    nop       
0x00014287c679:  48899d90010000        mov       qword ptr [rbp + 0x190], rbx
0x00014287c680:  48c785980100000f000000  mov       qword ptr [rbp + 0x198], 0xf
0x00014287c68b:  c6858001000000        mov       byte ptr [rbp + 0x180], 0
0x00014287c692:  486305bfc8a405        movsxd    rax, dword ptr [rip + 0x5a4c8bf]
0x00014287c699:  85c0                  test      eax, eax
0x00014287c69b:  0f8e84010000          jle       0x14287c825
0x00014287c6a1:  89442474              mov       dword ptr [rsp + 0x74], eax
0x00014287c6a5:  c744242004000000      mov       dword ptr [rsp + 0x20], 4
0x00014287c6ad:  4c8d4c2474            lea       r9, [rsp + 0x74]
0x00014287c6b2:  baffff0000            mov       edx, 0xffff
0x00014287c6b7:  41b806100000          mov       r8d, 0x1006
0x00014287c6bd:  498b0e                mov       rcx, qword ptr [r14]
0x00014287c6c0:  ff15b2318c03          call      qword ptr [rip + 0x38c31b2]
0x00014287c6c6:  85c0                  test      eax, eax
0x00014287c6c8:  0f8457010000          je        0x14287c825
0x00014287c6ce:  488b05dbf34e05        mov       rax, qword ptr [rip + 0x54ef3db]
0x00014287c6d5:  3c06                  cmp       al, 6
0x00014287c6d7:  0f8248010000          jb        0x14287c825
0x00014287c6dd:  48c1e808              shr       rax, 8
0x00014287c6e1:  3c03                  cmp       al, 3
0x00014287c6e3:  0f823c010000          jb        0x14287c825
0x00014287c6e9:  488d05d321ad04        lea       rax, [rip + 0x4ad21d3]
0x00014287c6f0:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x00014287c6f5:  488b7c2440            mov       rdi, qword ptr [rsp + 0x40]
0x00014287c6fa:  488d3d1fbb6b04        lea       rdi, [rip + 0x46bbb1f]
0x00014287c701:  ff15d9318c03          call      qword ptr [rip + 0x38c31d9]
0x00014287c707:  448bc0                mov       r8d, eax
0x00014287c70a:  488b0557285605        mov       rax, qword ptr [rip + 0x5562857]
0x00014287c711:  488d95a0010000        lea       rdx, [rbp + 0x1a0]
0x00014287c718:  488d0d49285605        lea       rcx, [rip + 0x5562849]
0x00014287c71f:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x00014287c723:  ff150f368c03          call      qword ptr [rip + 0x38c360f]
0x00014287c729:  90                    nop       
0x00014287c72a:  48897d50              mov       qword ptr [rbp + 0x50], rdi
0x00014287c72e:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x00014287c735:  48ffc0                inc       rax
0x00014287c738:  803c0700              cmp       byte ptr [rdi + rax], 0
0x00014287c73c:  75f7                  jne       0x14287c735
0x00014287c73e:  48894558              mov       qword ptr [rbp + 0x58], rax
0x00014287c742:  488d85a0010000        lea       rax, [rbp + 0x1a0]
0x00014287c749:  4883bdb801000010      cmp       qword ptr [rbp + 0x1b8], 0x10
0x00014287c751:  480f4385a0010000      cmovae    rax, qword ptr [rbp + 0x1a0]
0x00014287c759:  48894530              mov       qword ptr [rbp + 0x30], rax
0x00014287c75d:  488b85b0010000        mov       rax, qword ptr [rbp + 0x1b0]
0x00014287c764:  48894538              mov       qword ptr [rbp + 0x38], rax
0x00014287c768:  0f284530              movaps    xmm0, xmmword ptr [rbp + 0x30]
0x00014287c76c:  660f7f85e0010000      movdqa    xmmword ptr [rbp + 0x1e0], xmm0
0x00014287c774:  48c745400d000000      mov       qword ptr [rbp + 0x40], 0xd
0x00014287c77c:  488d85e0010000        lea       rax, [rbp + 0x1e0]
0x00014287c783:  48894548              mov       qword ptr [rbp + 0x48], rax
0x00014287c787:  0f284540              movaps    xmm0, xmmword ptr [rbp + 0x40]
0x00014287c78b:  660f7f8520010000      movdqa    xmmword ptr [rbp + 0x120], xmm0
0x00014287c793:  0f284d50              movaps    xmm1, xmmword ptr [rbp + 0x50]
0x00014287c797:  660f7f8d30010000      movdqa    xmmword ptr [rbp + 0x130], xmm1
0x00014287c79f:  0f10050af34e05        movups    xmm0, xmmword ptr [rip + 0x54ef30a]
0x00014287c7a6:  0f298540010000        movaps    xmmword ptr [rbp + 0x140], xmm0
0x00014287c7ad:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x00014287c7b2:  4c8d8d20010000        lea       r9, [rbp + 0x120]
0x00014287c7b9:  4c8d8530010000        lea       r8, [rbp + 0x130]
0x00014287c7c0:  b203                  mov       dl, 3
0x00014287c7c2:  488d8d40010000        lea       rcx, [rbp + 0x140]
0x00014287c7c9:  e802330e02            call      0x14495fad0
0x00014287c7ce:  90                    nop       
0x00014287c7cf:  488b85b8010000        mov       rax, qword ptr [rbp + 0x1b8]
0x00014287c7d6:  4883f810              cmp       rax, 0x10
0x00014287c7da:  7230                  jb        0x14287c80c
0x00014287c7dc:  48ffc0                inc       rax
0x00014287c7df:  488b8da0010000        mov       rcx, qword ptr [rbp + 0x1a0]
0x00014287c7e6:  488bd1                mov       rdx, rcx
0x00014287c7e9:  483d00100000          cmp       rax, 0x1000
0x00014287c7ef:  7215                  jb        0x14287c806
0x00014287c7f1:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014287c7f5:  482bd1                sub       rdx, rcx
0x00014287c7f8:  488d42f8              lea       rax, [rdx - 8]
0x00014287c7fc:  4883f81f              cmp       rax, 0x1f
0x00014287c800:  0f8752070000          ja        0x14287cf58
0x00014287c806:  e8a5680c02            call      0x1449430b0
0x00014287c80b:  90                    nop       
0x00014287c80c:  48899db0010000        mov       qword ptr [rbp + 0x1b0], rbx
0x00014287c813:  48c785b80100000f000000  mov       qword ptr [rbp + 0x1b8], 0xf
0x00014287c81e:  c685a001000000        mov       byte ptr [rbp + 0x1a0], 0
0x00014287c825:  498d560c              lea       rdx, [r14 + 0xc]
0x00014287c829:  498b0e                mov       rcx, qword ptr [r14]
0x00014287c82c:  e81fbf0200            call      0x1428a8750
0x00014287c831:  410fb74e0e            movzx     ecx, word ptr [r14 + 0xe]
0x00014287c836:  ff15f42f8c03          call      qword ptr [rip + 0x38c2ff4]
0x00014287c83c:  0fb7c8                movzx     ecx, ax
0x00014287c83f:  3b0da3e24e05          cmp       ecx, dword ptr [rip + 0x54ee2a3]
0x00014287c845:  0f8cca000000          jl        0x14287c915
0x00014287c84b:  8b44244c              mov       eax, dword ptr [rsp + 0x4c]
0x00014287c84f:  41894608              mov       dword ptr [r14 + 8], eax
0x00014287c853:  41b901040000          mov       r9d, 0x401
0x00014287c859:  4c8d85f0030000        lea       r8, [rbp + 0x3f0]
0x00014287c860:  b201                  mov       dl, 1
0x00014287c862:  498d4e0c              lea       rcx, [r14 + 0xc]
0x00014287c866:  e8358e0200            call      0x1428a56a0
0x00014287c86b:  488b056e025005        mov       rax, qword ptr [rip + 0x550026e]
0x00014287c872:  3c06                  cmp       al, 6
0x00014287c874:  7253                  jb        0x14287c8c9
0x00014287c876:  48c1e808              shr       rax, 8
0x00014287c87a:  3c03                  cmp       al, 3
0x00014287c87c:  724b                  jb        0x14287c8c9
0x00014287c87e:  488d057b6aae04        lea       rax, [rip + 0x4ae6a7b]
0x00014287c885:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x00014287c88a:  488b542440            mov       rdx, qword ptr [rsp + 0x40]
0x00014287c88f:  488d15e2b66b04        lea       rdx, [rip + 0x46bb6e2]
0x00014287c896:  0f100543025005        movups    xmm0, xmmword ptr [rip + 0x5500243]
0x00014287c89d:  0f298550010000        movaps    xmmword ptr [rbp + 0x150], xmm0
0x00014287c8a4:  48895c2430            mov       qword ptr [rsp + 0x30], rbx
0x00014287c8a9:  48895c2428            mov       qword ptr [rsp + 0x28], rbx
0x00014287c8ae:  48895c2420            mov       qword ptr [rsp + 0x20], rbx
0x00014287c8b3:  4533c9                xor       r9d, r9d
0x00014287c8b6:  4c8d85f0030000        lea       r8, [rbp + 0x3f0]
0x00014287c8bd:  488d8d50010000        lea       rcx, [rbp + 0x150]
0x00014287c8c4:  e857350e02            call      0x14495fe20
0x00014287c8c9:  488d8e00090000        lea       rcx, [rsi + 0x900]
0x00014287c8d0:  488d55a0              lea       rdx, [rbp - 0x60]
0x00014287c8d4:  e8b7800200            call      0x1428a4990
0x00014287c8d9:  90                    nop       
0x00014287c8da:  498bcf                mov       rcx, r15
0x00014287c8dd:  e82ec6f4fd            call      0x1407c8f10
0x00014287c8e2:  448b7c244c            mov       r15d, dword ptr [rsp + 0x4c]
0x00014287c8e7:  41ffc7                inc       r15d
0x00014287c8ea:  44897c244c            mov       dword ptr [rsp + 0x4c], r15d
0x00014287c8ef:  488b7c2460            mov       rdi, qword ptr [rsp + 0x60]
0x00014287c8f4:  4883c746              add       rdi, 0x46
0x00014287c8f8:  48897c2460            mov       qword ptr [rsp + 0x60], rdi
0x00014287c8fd:  443bbd70080000        cmp       r15d, dword ptr [rbp + 0x870]
0x00014287c904:  0f838a000000          jae       0x14287c994
0x00014287c90a:  41bf02000000          mov       r15d, 2
0x00014287c910:  e9dbf9ffff            jmp       0x14287c2f0
0x00014287c915:  488b0594f14e05        mov       rax, qword ptr [rip + 0x54ef194]
0x00014287c91c:  3c06                  cmp       al, 6
0x00014287c91e:  7253                  jb        0x14287c973
0x00014287c920:  48c1e808              shr       rax, 8
0x00014287c924:  3c03                  cmp       al, 3
0x00014287c926:  724b                  jb        0x14287c973
0x00014287c928:  488d054cb9ad04        lea       rax, [rip + 0x4adb94c]
0x00014287c92f:  48894580              mov       qword ptr [rbp - 0x80], rax
0x00014287c933:  488b7d80              mov       rdi, qword ptr [rbp - 0x80]
0x00014287c937:  410fb74e0e            movzx     ecx, word ptr [r14 + 0xe]
0x00014287c93c:  ff15ee2e8c03          call      qword ptr [rip + 0x38c2eee]
0x00014287c942:  440fb7c0              movzx     r8d, ax
0x00014287c946:  0f100563f14e05        movups    xmm0, xmmword ptr [rip + 0x54ef163]
0x00014287c94d:  0f2945b0              movaps    xmmword ptr [rbp - 0x50], xmm0
0x00014287c951:  48895c2430            mov       qword ptr [rsp + 0x30], rbx
0x00014287c956:  48895c2428            mov       qword ptr [rsp + 0x28], rbx
0x00014287c95b:  48895c2420            mov       qword ptr [rsp + 0x20], rbx
0x00014287c960:  4533c9                xor       r9d, r9d
0x00014287c963:  488d97b5fcbdff        lea       rdx, [rdi - 0x42034b]
0x00014287c96a:  488d4db0              lea       rcx, [rbp - 0x50]
0x00014287c96e:  e8ad340e02            call      0x14495fe20
0x00014287c973:  bb0b000000            mov       ebx, 0xb
0x00014287c978:  eb0d                  jmp       0x14287c987
0x00014287c97a:  488bce                mov       rcx, rsi
0x00014287c97d:  e85ef20000            call      0x14288bbe0
0x00014287c982:  bb06000000            mov       ebx, 6
0x00014287c987:  498bcf                mov       rcx, r15
0x00014287c98a:  e881c5f4fd            call      0x1407c8f10
0x00014287c98f:  e92f050000            jmp       0x14287cec3
0x00014287c994:  4c8dbe12010000        lea       r15, [rsi + 0x112]
0x00014287c99b:  6641833f00            cmp       word ptr [r15], 0
0x00014287c9a0:  0f8574030000          jne       0x14287cd1a
0x00014287c9a6:  0fb7542448            movzx     edx, word ptr [rsp + 0x48]
0x00014287c9ab:  0fb7c2                movzx     eax, dx
0x00014287c9ae:  498bcf                mov       rcx, r15
0x00014287c9b1:  66399614010000        cmp       word ptr [rsi + 0x114], dx
0x00014287c9b8:  7607                  jbe       0x14287c9c1
0x00014287c9ba:  66899614010000        mov       word ptr [rsi + 0x114], dx
0x00014287c9c1:  668901                mov       word ptr [rcx], ax
0x00014287c9c4:  4c8bf2                mov       r14, rdx
0x00014287c9c7:  b8d8160000            mov       eax, 0x16d8
0x00014287c9cc:  48f7e2                mul       rdx
0x00014287c9cf:  49c7c5ffffffff        mov       r13, 0xffffffffffffffff
0x00014287c9d6:  490f40c5              cmovo     rax, r13
0x00014287c9da:  4883c008              add       rax, 8
0x00014287c9de:  490f42c5              cmovb     rax, r13
0x00014287c9e2:  488bc8                mov       rcx, rax
0x00014287c9e5:  e8166e0c02            call      0x144943800
0x00014287c9ea:  4885c0                test      rax, rax
0x00014287c9ed:  0f84b9050000          je        0x14287cfac
0x00014287c9f3:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x00014287c9f8:  4c8930                mov       qword ptr [rax], r14
0x00014287c9fb:  488d7808              lea       rdi, [rax + 8]
0x00014287c9ff:  488d05da2b0000        lea       rax, [rip + 0x2bda]
0x00014287ca06:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014287ca0b:  4c8d0dee610200        lea       r9, [rip + 0x261ee]
0x00014287ca12:  4d8bc6                mov       r8, r14
0x00014287ca15:  bad8160000            mov       edx, 0x16d8
0x00014287ca1a:  488bcf                mov       rcx, rdi
0x00014287ca1d:  e8b64f2a03            call      0x145b219d8
0x00014287ca22:  90                    nop       
0x00014287ca23:  4889be50030000        mov       qword ptr [rsi + 0x350], rdi
0x00014287ca2a:  410fb707              movzx     eax, word ptr [r15]
0x00014287ca2e:  6685c0                test      ax, ax
0x00014287ca31:  7505                  jne       0x14287ca38
0x00014287ca33:  488bc3                mov       rax, rbx
0x00014287ca36:  eb24                  jmp       0x14287ca5c
0x00014287ca38:  488bc8                mov       rcx, rax
0x00014287ca3b:  48c1e103              shl       rcx, 3
0x00014287ca3f:  b808000000            mov       eax, 8
0x00014287ca44:  48f7e1                mul       rcx
0x00014287ca47:  490f40c5              cmovo     rax, r13
0x00014287ca4b:  488bc8                mov       rcx, rax
0x00014287ca4e:  e8ad6d0c02            call      0x144943800
0x00014287ca53:  4885c0                test      rax, rax
0x00014287ca56:  0f8436050000          je        0x14287cf92
0x00014287ca5c:  48898680030000        mov       qword ptr [rsi + 0x380], rax
0x00014287ca63:  410fb707              movzx     eax, word ptr [r15]
0x00014287ca67:  6685c0                test      ax, ax
0x00014287ca6a:  7505                  jne       0x14287ca71
0x00014287ca6c:  488bc3                mov       rax, rbx
0x00014287ca6f:  eb20                  jmp       0x14287ca91
0x00014287ca71:  488bc8                mov       rcx, rax
0x00014287ca74:  b808000000            mov       eax, 8
0x00014287ca79:  48f7e1                mul       rcx
0x00014287ca7c:  490f40c5              cmovo     rax, r13
0x00014287ca80:  488bc8                mov       rcx, rax
0x00014287ca83:  e8786d0c02            call      0x144943800
0x00014287ca88:  4885c0                test      rax, rax
0x00014287ca8b:  0f84e7040000          je        0x14287cf78
0x00014287ca91:  48898658030000        mov       qword ptr [rsi + 0x358], rax
0x00014287ca98:  803d89eaa00500        cmp       byte ptr [rip + 0x5a0ea89], 0
0x00014287ca9f:  0f8423010000          je        0x14287cbc8
0x00014287caa5:  803d6cd0df0500        cmp       byte ptr [rip + 0x5dfd06c], 0
0x00014287caac:  0f8416010000          je        0x14287cbc8
0x00014287cab2:  450fb727              movzx     r12d, word ptr [r15]
0x00014287cab6:  b850100000            mov       eax, 0x1050
0x00014287cabb:  49f7e4                mul       r12
0x00014287cabe:  488bf8                mov       rdi, rax
0x00014287cac1:  490f40fd              cmovo     rdi, r13
0x00014287cac5:  488bcf                mov       rcx, rdi
0x00014287cac8:  e8336d0c02            call      0x144943800
0x00014287cacd:  4c8be8                mov       r13, rax
0x00014287cad0:  4885c0                test      rax, rax
0x00014287cad3:  0f8485040000          je        0x14287cf5e
0x00014287cad9:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x00014287cade:  4c8bc7                mov       r8, rdi
0x00014287cae1:  33d2                  xor       edx, edx
0x00014287cae3:  488bc8                mov       rcx, rax
0x00014287cae6:  e8d5562c03            call      0x145b421c0
0x00014287caeb:  4d85e4                test      r12, r12
0x00014287caee:  0f849a000000          je        0x14287cb8e
0x00014287caf4:  498dbd40080000        lea       rdi, [r13 + 0x840]
0x00014287cafb:  0f1f440000            nop       dword ptr [rax + rax]
0x00014287cb00:  49ffcc                dec       r12
0x00014287cb03:  0f57c0                xorps     xmm0, xmm0
0x00014287cb06:  0f1187c0f7ffff        movups    xmmword ptr [rdi - 0x840], xmm0
0x00014287cb0d:  0f1187d0f7ffff        movups    xmmword ptr [rdi - 0x830], xmm0
0x00014287cb14:  33d2                  xor       edx, edx
0x00014287cb16:  41b800080000          mov       r8d, 0x800
0x00014287cb1c:  488d8fe0f7ffff        lea       rcx, [rdi - 0x820]
0x00014287cb23:  e898562c03            call      0x145b421c0
0x00014287cb28:  488bc3                mov       rax, rbx
0x00014287cb2b:  0f1f440000            nop       dword ptr [rax + rax]
0x00014287cb30:  48899cc7e0f7ffff      mov       qword ptr [rdi + rax*8 - 0x820], rbx
0x00014287cb38:  48ffc0                inc       rax
0x00014287cb3b:  483d00010000          cmp       rax, 0x100
0x00014287cb41:  72ed                  jb        0x14287cb30
0x00014287cb43:  0f57c0                xorps     xmm0, xmm0
0x00014287cb46:  0f1147e0              movups    xmmword ptr [rdi - 0x20], xmm0
0x00014287cb4a:  0f1147f0              movups    xmmword ptr [rdi - 0x10], xmm0
0x00014287cb4e:  33d2                  xor       edx, edx
0x00014287cb50:  41b800080000          mov       r8d, 0x800
0x00014287cb56:  488bcf                mov       rcx, rdi
0x00014287cb59:  e862562c03            call      0x145b421c0
0x00014287cb5e:  488bc3                mov       rax, rbx
0x00014287cb61:  48891cc7              mov       qword ptr [rdi + rax*8], rbx
0x00014287cb65:  48ffc0                inc       rax
0x00014287cb68:  483d00010000          cmp       rax, 0x100
0x00014287cb6e:  72f1                  jb        0x14287cb61
0x00014287cb70:  48899f00080000        mov       qword ptr [rdi + 0x800], rbx
0x00014287cb77:  c6870808000000        mov       byte ptr [rdi + 0x808], 0
0x00014287cb7e:  4881c750100000        add       rdi, 0x1050
0x00014287cb85:  4d85e4                test      r12, r12
0x00014287cb88:  0f8572ffffff          jne       0x14287cb00
0x00014287cb8e:  488d8668030000        lea       rax, [rsi + 0x368]
0x00014287cb95:  488d8d60010000        lea       rcx, [rbp + 0x160]
0x00014287cb9c:  483bc1                cmp       rax, rcx
0x00014287cb9f:  7413                  je        0x14287cbb4
0x00014287cba1:  488b08                mov       rcx, qword ptr [rax]
0x00014287cba4:  4c8928                mov       qword ptr [rax], r13
0x00014287cba7:  4885c9                test      rcx, rcx
0x00014287cbaa:  7411                  je        0x14287cbbd
0x00014287cbac:  e8ff640c02            call      0x1449430b0
0x00014287cbb1:  90                    nop       
0x00014287cbb2:  eb09                  jmp       0x14287cbbd
0x00014287cbb4:  498bcd                mov       rcx, r13
0x00014287cbb7:  e8f4640c02            call      0x1449430b0
0x00014287cbbc:  90                    nop       
0x00014287cbbd:  410fb707              movzx     eax, word ptr [r15]
0x00014287cbc1:  48898670030000        mov       qword ptr [rsi + 0x370], rax
0x00014287cbc8:  448bcb                mov       r9d, ebx
0x00014287cbcb:  410fb707              movzx     eax, word ptr [r15]
0x00014287cbcf:  663bd8                cmp       bx, ax
0x00014287cbd2:  0f8316010000          jae       0x14287ccee
0x00014287cbd8:  0f1f840000000000      nop       dword ptr [rax + rax]
0x00014287cbe0:  4d63c1                movsxd    r8, r9d
0x00014287cbe3:  4969d0d8160000        imul      rdx, r8, 0x16d8
0x00014287cbea:  488b8e50030000        mov       rcx, qword ptr [rsi + 0x350]
0x00014287cbf1:  8bc3                  mov       eax, ebx
0x00014287cbf3:  860411                xchg      byte ptr [rcx + rdx], al
0x00014287cbf6:  488b8e50030000        mov       rcx, qword ptr [rsi + 0x350]
0x00014287cbfd:  4803ca                add       rcx, rdx
0x00014287cc00:  0f1005412c5705        movups    xmm0, xmmword ptr [rip + 0x5572c41]
0x00014287cc07:  0f114104              movups    xmmword ptr [rcx + 4], xmm0
0x00014287cc0b:  f20f100d452c5705      movsd     xmm1, qword ptr [rip + 0x5572c45]
0x00014287cc13:  f20f114914            movsd     qword ptr [rcx + 0x14], xmm1
0x00014287cc18:  8b05422c5705          mov       eax, dword ptr [rip + 0x5572c42]
0x00014287cc1e:  89411c                mov       dword ptr [rcx + 0x1c], eax
0x00014287cc21:  0fb7053e2c5705        movzx     eax, word ptr [rip + 0x5572c3e]
0x00014287cc28:  66894122              mov       word ptr [rcx + 0x22], ax
0x00014287cc2c:  0fb705312c5705        movzx     eax, word ptr [rip + 0x5572c31]
0x00014287cc33:  66894120              mov       word ptr [rcx + 0x20], ax
0x00014287cc37:  488b8e50030000        mov       rcx, qword ptr [rsi + 0x350]
0x00014287cc3e:  488b05232c5705        mov       rax, qword ptr [rip + 0x5572c23]
0x00014287cc45:  4889841130160000      mov       qword ptr [rcx + rdx + 0x1630], rax
0x00014287cc4d:  0fb7051c2c5705        movzx     eax, word ptr [rip + 0x5572c1c]
0x00014287cc54:  6689841138160000      mov       word ptr [rcx + rdx + 0x1638], ax
0x00014287cc5c:  488b8650030000        mov       rax, qword ptr [rsi + 0x350]
0x00014287cc63:  899c02d4160000        mov       dword ptr [rdx + rax + 0x16d4], ebx
0x00014287cc6a:  488b8e50030000        mov       rcx, qword ptr [rsi + 0x350]
0x00014287cc71:  8b86f0080000          mov       eax, dword ptr [rsi + 0x8f0]
0x00014287cc77:  89840a40160000        mov       dword ptr [rdx + rcx + 0x1640], eax
0x00014287cc7e:  488b8650030000        mov       rax, qword ptr [rsi + 0x350]
0x00014287cc85:  6644898c0260160000    mov       word ptr [rdx + rax + 0x1660], r9w
0x00014287cc8e:  488b8650030000        mov       rax, qword ptr [rsi + 0x350]
0x00014287cc95:  899c0264160000        mov       dword ptr [rdx + rax + 0x1664], ebx
0x00014287cc9c:  488b8650030000        mov       rax, qword ptr [rsi + 0x350]
0x00014287cca3:  48899c0268160000      mov       qword ptr [rdx + rax + 0x1668], rbx
0x00014287ccab:  488b8650030000        mov       rax, qword ptr [rsi + 0x350]
0x00014287ccb2:  4889b40250120000      mov       qword ptr [rdx + rax + 0x1250], rsi
0x00014287ccba:  488b8650030000        mov       rax, qword ptr [rsi + 0x350]
0x00014287ccc1:  c684027116000009      mov       byte ptr [rdx + rax + 0x1671], 9
0x00014287ccc9:  488b8e50030000        mov       rcx, qword ptr [rsi + 0x350]
0x00014287ccd0:  4803ca                add       rcx, rdx
0x00014287ccd3:  488b8658030000        mov       rax, qword ptr [rsi + 0x358]
0x00014287ccda:  4a890cc0              mov       qword ptr [rax + r8*8], rcx
0x00014287ccde:  41ffc1                inc       r9d
0x00014287cce1:  410fb707              movzx     eax, word ptr [r15]
0x00014287cce5:  443bc8                cmp       r9d, eax
0x00014287cce8:  0f8cf2feffff          jl        0x14287cbe0
0x00014287ccee:  8bd3                  mov       edx, ebx
0x00014287ccf0:  0fb7c0                movzx     eax, ax
0x00014287ccf3:  c1e003                shl       eax, 3
0x00014287ccf6:  85c0                  test      eax, eax
0x00014287ccf8:  7420                  je        0x14287cd1a
0x00014287ccfa:  660f1f440000          nop       word ptr [rax + rax]
0x00014287cd00:  8bca                  mov       ecx, edx
0x00014287cd02:  488b8680030000        mov       rax, qword ptr [rsi + 0x380]
0x00014287cd09:  48891cc8              mov       qword ptr [rax + rcx*8], rbx
0x00014287cd0d:  ffc2                  inc       edx
0x00014287cd0f:  410fb707              movzx     eax, word ptr [r15]
0x00014287cd13:  c1e003                shl       eax, 3
0x00014287cd16:  3bd0                  cmp       edx, eax
0x00014287cd18:  72e6                  jb        0x14287cd00
0x00014287cd1a:  448b642450            mov       r12d, dword ptr [rsp + 0x50]
0x00014287cd1f:  4585e4                test      r12d, r12d
0x00014287cd22:  7512                  jne       0x14287cd36
0x00014287cd24:  488bce                mov       rcx, rsi
0x00014287cd27:  e8b4ee0000            call      0x14288bbe0
0x00014287cd2c:  418d5c2407            lea       ebx, [r12 + 7]
0x00014287cd31:  e98d010000            jmp       0x14287cec3
0x00014287cd36:  0fb68608010000        movzx     eax, byte ptr [rsi + 0x108]
0x00014287cd3d:  90                    nop       
0x00014287cd3e:  84c0                  test      al, al
0x00014287cd40:  0f847d010000          je        0x14287cec3
0x00014287cd46:  c6864804000000        mov       byte ptr [rsi + 0x448], 0
0x00014287cd4d:  8bc3                  mov       eax, ebx
0x00014287cd4f:  868608010000          xchg      byte ptr [rsi + 0x108], al
0x00014287cd55:  8bc3                  mov       eax, ebx
0x00014287cd57:  86860a010000          xchg      byte ptr [rsi + 0x10a], al
0x00014287cd5d:  488bce                mov       rcx, rsi
0x00014287cd60:  e85bd10000            call      0x142889ec0
0x00014287cd65:  488bce                mov       rcx, rsi
0x00014287cd68:  e8b3d20000            call      0x14288a020
0x00014287cd6d:  488d8eb0070000        lea       rcx, [rsi + 0x7b0]
0x00014287cd74:  e877580200            call      0x1428a25f0
0x00014287cd79:  0fb68609010000        movzx     eax, byte ptr [rsi + 0x109]
0x00014287cd80:  90                    nop       
0x00014287cd81:  84c0                  test      al, al
0x00014287cd83:  0f850d010000          jne       0x14287ce96
0x00014287cd89:  895c2448              mov       dword ptr [rsp + 0x48], ebx
0x00014287cd8d:  488d442448            lea       rax, [rsp + 0x48]
0x00014287cd92:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x00014287cd97:  895c2420              mov       dword ptr [rsp + 0x20], ebx
0x00014287cd9b:  4c8bce                mov       r9, rsi
0x00014287cd9e:  4c8d05fb940100        lea       r8, [rip + 0x194fb]
0x00014287cda5:  ba80841e00            mov       edx, 0x1e8480
0x00014287cdaa:  33c9                  xor       ecx, ecx
0x00014287cdac:  e88fdd2d03            call      0x145b5ab40
0x00014287cdb1:  488bf8                mov       rdi, rax
0x00014287cdb4:  448b6c2454            mov       r13d, dword ptr [rsp + 0x54]
0x00014287cdb9:  418bd5                mov       edx, r13d
0x00014287cdbc:  488bc8                mov       rcx, rax
0x00014287cdbf:  ff15eb178c03          call      qword ptr [rip + 0x38c17eb]
0x00014287cdc5:  4885ff                test      rdi, rdi
0x00014287cdc8:  751a                  jne       0x14287cde4
0x00014287cdca:  488b06                mov       rax, qword ptr [rsi]
0x00014287cdcd:  488bce                mov       rcx, rsi
0x00014287cdd0:  488b4070              mov       rax, qword ptr [rax + 0x70]
0x00014287cdd4:  ff155e2f8c03          call      qword ptr [rip + 0x38c2f5e]
0x00014287cdda:  bb09000000            mov       ebx, 9
0x00014287cddf:  e9df000000            jmp       0x14287cec3
0x00014287cde4:  488bcf                mov       rcx, rdi
0x00014287cde7:  ff15db1f8c03          call      qword ptr [rip + 0x38c1fdb]
0x00014287cded:  4c8bf3                mov       r14, rbx
0x00014287cdf0:  8bfb                  mov       edi, ebx
0x00014287cdf2:  488b8600090000        mov       rax, qword ptr [rsi + 0x900]
0x00014287cdf9:  498b0c06              mov       rcx, qword ptr [r14 + rax]
0x00014287cdfd:  488b01                mov       rax, qword ptr [rcx]
0x00014287ce00:  4a898435f0010000      mov       qword ptr [rbp + r14 + 0x1f0], rax
0x00014287ce08:  4a89b435f8010000      mov       qword ptr [rbp + r14 + 0x1f8], rsi
0x00014287ce10:  895c2454              mov       dword ptr [rsp + 0x54], ebx
0x00014287ce14:  4863c7                movsxd    rax, edi
0x00014287ce17:  48c1e004              shl       rax, 4
0x00014287ce1b:  4c8d8df0010000        lea       r9, [rbp + 0x1f0]
0x00014287ce22:  4c03c8                add       r9, rax
0x00014287ce25:  488d442454            lea       rax, [rsp + 0x54]
0x00014287ce2a:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x00014287ce2f:  895c2420              mov       dword ptr [rsp + 0x20], ebx
0x00014287ce33:  4c8d05d6900100        lea       r8, [rip + 0x190d6]
0x00014287ce3a:  ba80841e00            mov       edx, 0x1e8480
0x00014287ce3f:  33c9                  xor       ecx, ecx
0x00014287ce41:  e8fadc2d03            call      0x145b5ab40
0x00014287ce46:  4c8bf8                mov       r15, rax
0x00014287ce49:  418bd5                mov       edx, r13d
0x00014287ce4c:  488bc8                mov       rcx, rax
0x00014287ce4f:  ff155b178c03          call      qword ptr [rip + 0x38c175b]
0x00014287ce55:  4d85ff                test      r15, r15
0x00014287ce58:  0f846cffffff          je        0x14287cdca
0x00014287ce5e:  498bcf                mov       rcx, r15
0x00014287ce61:  ff15611f8c03          call      qword ptr [rip + 0x38c1f61]
0x00014287ce67:  ffc7                  inc       edi
0x00014287ce69:  4983c610              add       r14, 0x10
0x00014287ce6d:  413bfc                cmp       edi, r12d
0x00014287ce70:  7280                  jb        0x14287cdf2
0x00014287ce72:  8b860c010000          mov       eax, dword ptr [rsi + 0x10c]
0x00014287ce78:  90                    nop       
0x00014287ce79:  413bc4                cmp       eax, r12d
0x00014287ce7c:  7318                  jae       0x14287ce96
0x00014287ce7e:  6690                  nop       
0x00014287ce80:  b90a000000            mov       ecx, 0xa
0x00014287ce85:  e866c60300            call      0x1428b94f0
0x00014287ce8a:  8b860c010000          mov       eax, dword ptr [rsi + 0x10c]
0x00014287ce90:  90                    nop       
0x00014287ce91:  413bc4                cmp       eax, r12d
0x00014287ce94:  72ea                  jb        0x14287ce80
0x00014287ce96:  0fb68609010000        movzx     eax, byte ptr [rsi + 0x109]
0x00014287ce9d:  90                    nop       
0x00014287ce9e:  84c0                  test      al, al
0x00014287cea0:  7521                  jne       0x14287cec3
0x00014287cea2:  b90a000000            mov       ecx, 0xa
0x00014287cea7:  e844c60300            call      0x1428b94f0
0x00014287ceac:  0fb68609010000        movzx     eax, byte ptr [rsi + 0x109]
0x00014287ceb3:  90                    nop       
0x00014287ceb4:  84c0                  test      al, al
0x00014287ceb6:  74ea                  je        0x14287cea2
0x00014287ceb8:  eb09                  jmp       0x14287cec3
0x00014287ceba:  41bd02000000          mov       r13d, 2
0x00014287cec0:  418bdd                mov       ebx, r13d
0x00014287cec3:  448b4c2458            mov       r9d, dword ptr [rsp + 0x58]
0x00014287cec8:  4181f900040000        cmp       r9d, 0x400
0x00014287cecf:  7214                  jb        0x14287cee5
0x00014287ced1:  803dbbd2980500        cmp       byte ptr [rip + 0x598d2bb], 0
0x00014287ced8:  7414                  je        0x14287ceee
0x00014287ceda:  803d6716d50500        cmp       byte ptr [rip + 0x5d51667], 0
0x00014287cee1:  7551                  jne       0x14287cf34
0x00014287cee3:  eb09                  jmp       0x14287ceee
0x00014287cee5:  e826940d02            call      0x144956310
0x00014287ceea:  44894808              mov       dword ptr [rax + 8], r9d
0x00014287ceee:  8bc3                  mov       eax, ebx
0x00014287cef0:  488b8d00080000        mov       rcx, qword ptr [rbp + 0x800]
0x00014287cef7:  4833cc                xor       rcx, rsp
0x00014287cefa:  e8e1462a03            call      0x145b215e0
0x00014287ceff:  488b9c2458090000      mov       rbx, qword ptr [rsp + 0x958]
0x00014287cf07:  4881c410090000        add       rsp, 0x910
0x00014287cf0e:  415f                  pop       r15
0x00014287cf10:  415e                  pop       r14
0x00014287cf12:  415d                  pop       r13
0x00014287cf14:  415c                  pop       r12
0x00014287cf16:  5f                    pop       rdi
0x00014287cf17:  5e                    pop       rsi
0x00014287cf18:  5d                    pop       rbp
0x00014287cf19:  c3                    ret       
0x00014287cf1a:  488d4d60              lea       rcx, [rbp + 0x60]
0x00014287cf1e:  e8cddef3fd            call      0x1407badf0
0x00014287cf23:  488d15169d4805        lea       rdx, [rip + 0x5489d16]
0x00014287cf2a:  488d4d60              lea       rcx, [rbp + 0x60]
0x00014287cf2e:  e81d612c03            call      0x145b43050
0x00014287cf33:  90                    nop       
0x00014287cf34:  488d15a57e8504        lea       rdx, [rip + 0x4857ea5]
0x00014287cf3b:  33c9                  xor       ecx, ecx
0x00014287cf3d:  e83e1d0e02            call      0x14495ec80
0x00014287cf42:  90                    nop       
0x00014287cf43:  488d15967e8504        lea       rdx, [rip + 0x4857e96]
0x00014287cf4a:  33c9                  xor       ecx, ecx
0x00014287cf4c:  e82f1d0e02            call      0x14495ec80
0x00014287cf51:  90                    nop       
0x00014287cf52:  e8c9452d03            call      0x145b51520
0x00014287cf57:  cc                    int3      
0x00014287cf58:  e8c3452d03            call      0x145b51520
0x00014287cf5d:  90                    nop       
0x00014287cf5e:  488d4db0              lea       rcx, [rbp - 0x50]
0x00014287cf62:  e889def3fd            call      0x1407badf0
0x00014287cf67:  488d15d29c4805        lea       rdx, [rip + 0x5489cd2]
0x00014287cf6e:  488d4db0              lea       rcx, [rbp - 0x50]
0x00014287cf72:  e8d9602c03            call      0x145b43050
0x00014287cf77:  cc                    int3      
0x00014287cf78:  488d4db0              lea       rcx, [rbp - 0x50]
0x00014287cf7c:  e86fdef3fd            call      0x1407badf0
0x00014287cf81:  488d15b89c4805        lea       rdx, [rip + 0x5489cb8]
0x00014287cf88:  488d4db0              lea       rcx, [rbp - 0x50]
0x00014287cf8c:  e8bf602c03            call      0x145b43050
0x00014287cf91:  cc                    int3      
0x00014287cf92:  488d4db0              lea       rcx, [rbp - 0x50]
0x00014287cf96:  e855def3fd            call      0x1407badf0
0x00014287cf9b:  488d159e9c4805        lea       rdx, [rip + 0x5489c9e]
0x00014287cfa2:  488d4db0              lea       rcx, [rbp - 0x50]
0x00014287cfa6:  e8a5602c03            call      0x145b43050
0x00014287cfab:  cc                    int3      
0x00014287cfac:  488d8d68010000        lea       rcx, [rbp + 0x168]
0x00014287cfb3:  e838def3fd            call      0x1407badf0
0x00014287cfb8:  488d15819c4805        lea       rdx, [rip + 0x5489c81]
0x00014287cfbf:  488d8d68010000        lea       rcx, [rbp + 0x168]
0x00014287cfc6:  e885602c03            call      0x145b43050
0x00014287cfcb:  90                    nop       
0x00014287cfcc:  488d4d60              lea       rcx, [rbp + 0x60]
0x00014287cfd0:  e81bdef3fd            call      0x1407badf0
0x00014287cfd5:  488d15649c4805        lea       rdx, [rip + 0x5489c64]
0x00014287cfdc:  488d4d60              lea       rcx, [rbp + 0x60]
0x00014287cfe0:  e86b602c03            call      0x145b43050
0x00014287cfe5:  cc                    int3      
0x00014287cfe6:  cc                    int3      
0x00014287cfe7:  cc                    int3      
0x00014287cfe8:  cc                    int3      
0x00014287cfe9:  cc                    int3      
0x00014287cfea:  cc                    int3      
0x00014287cfeb:  cc                    int3      
0x00014287cfec:  cc                    int3      
0x00014287cfed:  cc                    int3      
0x00014287cfee:  cc                    int3      
0x00014287cfef:  cc                    int3      
0x00014287cff0:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x00014287cff5:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x00014287cffa:  57                    push      rdi
0x00014287cffb:  4883ec20              sub       rsp, 0x20
0x00014287cfff:  488bf2                mov       rsi, rdx
0x00014287d002:  488bd9                mov       rbx, rcx
0x00014287d005:  4881c188080000        add       rcx, 0x888
0x00014287d00c:  e89f672a03            call      0x145b237b0
0x00014287d011:  85c0                  test      eax, eax
0x00014287d013:  7544                  jne       0x14287d059
0x00014287d015:  488bd6                mov       rdx, rsi
0x00014287d018:  488d4c2430            lea       rcx, [rsp + 0x30]
0x00014287d01d:  e8fec50300            call      0x1428b9620
0x00014287d022:  90                    nop       
0x00014287d023:  488bd0                mov       rdx, rax
0x00014287d026:  488d8b80090000        lea       rcx, [rbx + 0x980]
0x00014287d02d:  e83e570200            call      0x1428a2770
0x00014287d032:  90                    nop       
0x00014287d033:  488d4c2430            lea       rcx, [rsp + 0x30]
0x00014287d038:  e8d3cb0300            call      0x1428b9c10
0x00014287d03d:  90                    nop       
0x00014287d03e:  488d8b88080000        lea       rcx, [rbx + 0x888]
0x00014287d045:  488b5c2438            mov       rbx, qword ptr [rsp + 0x38]
0x00014287d04a:  488b742440            mov       rsi, qword ptr [rsp + 0x40]
0x00014287d04f:  4883c420              add       rsp, 0x20
0x00014287d053:  5f                    pop       rdi
0x00014287d054:  e9b7672a03            jmp       0x145b23810
0x00014287d059:  8bc8                  mov       ecx, eax
0x00014287d05b:  e8206d2a03            call      0x145b23d80
0x00014287d060:  cc                    int3      
0x00014287d061:  cc                    int3      
0x00014287d062:  cc                    int3      
0x00014287d063:  cc                    int3      
0x00014287d064:  cc                    int3      
0x00014287d065:  cc                    int3      
0x00014287d066:  cc                    int3      
0x00014287d067:  cc                    int3      
0x00014287d068:  cc                    int3      
0x00014287d069:  cc                    int3      
0x00014287d06a:  cc                    int3      
0x00014287d06b:  cc                    int3      
0x00014287d06c:  cc                    int3      
0x00014287d06d:  cc                    int3      
0x00014287d06e:  cc                    int3      
0x00014287d06f:  cc                    int3      
0x00014287d070:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014287d075:  48896c2410            mov       qword ptr [rsp + 0x10], rbp
0x00014287d07a:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x00014287d07f:  48897c2420            mov       qword ptr [rsp + 0x20], rdi
0x00014287d084:  4155                  push      r13
0x00014287d086:  4156                  push      r14
0x00014287d088:  4157                  push      r15
0x00014287d08a:  4883ec20              sub       rsp, 0x20
0x00014287d08e:  4c8bf2                mov       r14, rdx
0x00014287d091:  488bf1                mov       rsi, rcx
0x00014287d094:  83b98809000000        cmp       dword ptr [rcx + 0x988], 0
0x00014287d09b:  7473                  je        0x14287d110
0x00014287d09d:  4881c188080000        add       rcx, 0x888
0x00014287d0a4:  4885d2                test      rdx, rdx
0x00014287d0a7:  0f8582000000          jne       0x14287d12f
0x00014287d0ad:  e8fe662a03            call      0x145b237b0
0x00014287d0b2:  85c0                  test      eax, eax
0x00014287d0b4:  0f85f5010000          jne       0x14287d2af
0x00014287d0ba:  39868c090000          cmp       dword ptr [rsi + 0x98c], eax
0x00014287d0c0:  7442                  je        0x14287d104
0x00014287d0c2:  488b8e80090000        mov       rcx, qword ptr [rsi + 0x980]
0x00014287d0c9:  4885c9                test      rcx, rcx
0x00014287d0cc:  7420                  je        0x14287d0ee
0x00014287d0ce:  488d59f8              lea       rbx, [rcx - 8]
0x00014287d0d2:  4c8d0d77c50300        lea       r9, [rip + 0x3c577]
0x00014287d0d9:  4c8b03                mov       r8, qword ptr [rbx]
0x00014287d0dc:  8d5008                lea       edx, [rax + 8]
0x00014287d0df:  e8cc452a03            call      0x145b216b0
0x00014287d0e4:  90                    nop       
0x00014287d0e5:  488bcb                mov       rcx, rbx
0x00014287d0e8:  e8c35f0c02            call      0x1449430b0
0x00014287d0ed:  90                    nop       
0x00014287d0ee:  48c7868809000000000000  mov       qword ptr [rsi + 0x988], 0
0x00014287d0f9:  48c7868009000000000000  mov       qword ptr [rsi + 0x980], 0
0x00014287d104:  488d8e88080000        lea       rcx, [rsi + 0x888]
0x00014287d10b:  e800672a03            call      0x145b23810
0x00014287d110:  488b5c2440            mov       rbx, qword ptr [rsp + 0x40]
0x00014287d115:  488b6c2448            mov       rbp, qword ptr [rsp + 0x48]
0x00014287d11a:  488b742450            mov       rsi, qword ptr [rsp + 0x50]
0x00014287d11f:  488b7c2458            mov       rdi, qword ptr [rsp + 0x58]
0x00014287d124:  4883c420              add       rsp, 0x20
0x00014287d128:  415f                  pop       r15
0x00014287d12a:  415e                  pop       r14
0x00014287d12c:  415d                  pop       r13
0x00014287d12e:  c3                    ret       
0x00014287d12f:  4533ff                xor       r15d, r15d
0x00014287d132:  e879662a03            call      0x145b237b0
0x00014287d137:  85c0                  test      eax, eax
0x00014287d139:  0f8560010000          jne       0x14287d29f
0x00014287d13f:  448b8e88090000        mov       r9d, dword ptr [rsi + 0x988]
0x00014287d146:  4585c9                test      r9d, r9d
0x00014287d149:  74b9                  je        0x14287d104
0x00014287d14b:  0f1f440000            nop       dword ptr [rax + rax]
0x00014287d150:  4e8d04fd00000000      lea       r8, [r15*8]
0x00014287d158:  410fb60e              movzx     ecx, byte ptr [r14]
0x00014287d15c:  84c9                  test      cl, cl
0x00014287d15e:  0f8423010000          je        0x14287d287
0x00014287d164:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x00014287d16b:  0f1f440000            nop       dword ptr [rax + rax]
0x00014287d170:  48ffc0                inc       rax
0x00014287d173:  41803c0600            cmp       byte ptr [r14 + rax], 0
0x00014287d178:  75f6                  jne       0x14287d170
0x00014287d17a:  4883f80f              cmp       rax, 0xf
0x00014287d17e:  0f8703010000          ja        0x14287d287
0x00014287d184:  33d2                  xor       edx, edx
0x00014287d186:  4c8b9680090000        mov       r10, qword ptr [rsi + 0x980]
0x00014287d18d:  4f8d1c02              lea       r11, [r10 + r8]
0x00014287d191:  498b03                mov       rax, qword ptr [r11]
0x00014287d194:  4c8b4020              mov       r8, qword ptr [rax + 0x20]
0x00014287d198:  413808                cmp       byte ptr [r8], cl
0x00014287d19b:  7514                  jne       0x14287d1b1
0x00014287d19d:  0f1f00                nop       dword ptr [rax]
0x00014287d1a0:  84c9                  test      cl, cl
0x00014287d1a2:  7430                  je        0x14287d1d4
0x00014287d1a4:  ffc2                  inc       edx
0x00014287d1a6:  420fb60c32            movzx     ecx, byte ptr [rdx + r14]
0x00014287d1ab:  41380c10              cmp       byte ptr [r8 + rdx], cl
0x00014287d1af:  74ef                  je        0x14287d1a0
0x00014287d1b1:  8bc2                  mov       eax, edx
0x00014287d1b3:  410fb61410            movzx     edx, byte ptr [r8 + rdx]
0x00014287d1b8:  84d2                  test      dl, dl
0x00014287d1ba:  0f84c7000000          je        0x14287d287
0x00014287d1c0:  42803c3000            cmp       byte ptr [rax + r14], 0
0x00014287d1c5:  0f84bc000000          je        0x14287d287
0x00014287d1cb:  80fa2a                cmp       dl, 0x2a
0x00014287d1ce:  0f85b3000000          jne       0x14287d287
0x00014287d1d4:  418d41ff              lea       eax, [r9 - 1]
0x00014287d1d8:  498d14c2              lea       rdx, [r10 + rax*8]
0x00014287d1dc:  498bcb                mov       rcx, r11
0x00014287d1df:  e87cc40300            call      0x1428b9660
0x00014287d1e4:  8b9688090000          mov       edx, dword ptr [rsi + 0x988]
0x00014287d1ea:  ffca                  dec       edx
0x00014287d1ec:  8b8e88090000          mov       ecx, dword ptr [rsi + 0x988]
0x00014287d1f2:  3bd1                  cmp       edx, ecx
0x00014287d1f4:  0f8390000000          jae       0x14287d28a
0x00014287d1fa:  8d41ff                lea       eax, [rcx - 1]
0x00014287d1fd:  3bd0                  cmp       edx, eax
0x00014287d1ff:  737b                  jae       0x14287d27c
0x00014287d201:  0f1f4000              nop       dword ptr [rax]
0x00014287d205:  6666660f1f840000000000  nop       word ptr [rax + rax]
0x00014287d210:  8d6a01                lea       ebp, [rdx + 1]
0x00014287d213:  488b8e80090000        mov       rcx, qword ptr [rsi + 0x980]
0x00014287d21a:  488d3ce9              lea       rdi, [rcx + rbp*8]
0x00014287d21e:  8bc2                  mov       eax, edx
0x00014287d220:  488d1cc1              lea       rbx, [rcx + rax*8]
0x00014287d224:  488bcb                mov       rcx, rbx
0x00014287d227:  e8e4c90300            call      0x1428b9c10
0x00014287d22c:  488b0f                mov       rcx, qword ptr [rdi]
0x00014287d22f:  488d058a454a05        lea       rax, [rip + 0x54a458a]
0x00014287d236:  483bc8                cmp       rcx, rax
0x00014287d239:  7432                  je        0x14287d26d
0x00014287d23b:  488b09                mov       rcx, qword ptr [rcx]
0x00014287d23e:  e86d652a03            call      0x145b237b0
0x00014287d243:  85c0                  test      eax, eax
0x00014287d245:  7560                  jne       0x14287d2a7
0x00014287d247:  488b07                mov       rax, qword ptr [rdi]
0x00014287d24a:  83780800              cmp       dword ptr [rax + 8], 0
0x00014287d24e:  750c                  jne       0x14287d25c
0x00014287d250:  488d0569454a05        lea       rax, [rip + 0x54a4569]
0x00014287d257:  488903                mov       qword ptr [rbx], rax
0x00014287d25a:  eb06                  jmp       0x14287d262
0x00014287d25c:  488903                mov       qword ptr [rbx], rax
0x00014287d25f:  ff4008                inc       dword ptr [rax + 8]
0x00014287d262:  488b0f                mov       rcx, qword ptr [rdi]
0x00014287d265:  488b09                mov       rcx, qword ptr [rcx]
0x00014287d268:  e8a3652a03            call      0x145b23810
0x00014287d26d:  8bd5                  mov       edx, ebp
0x00014287d26f:  8b8e88090000          mov       ecx, dword ptr [rsi + 0x988]
0x00014287d275:  8d41ff                lea       eax, [rcx - 1]
0x00014287d278:  3be8                  cmp       ebp, eax
0x00014287d27a:  7294                  jb        0x14287d210
0x00014287d27c:  8d41ff                lea       eax, [rcx - 1]
0x00014287d27f:  898688090000          mov       dword ptr [rsi + 0x988], eax
0x00014287d285:  eb03                  jmp       0x14287d28a
0x00014287d287:  41ffc7                inc       r15d
0x00014287d28a:  448b8e88090000        mov       r9d, dword ptr [rsi + 0x988]
0x00014287d291:  453bf9                cmp       r15d, r9d
0x00014287d294:  0f836afeffff          jae       0x14287d104
0x00014287d29a:  e9b1feffff            jmp       0x14287d150
0x00014287d29f:  8bc8                  mov       ecx, eax
0x00014287d2a1:  e8da6a2a03            call      0x145b23d80
0x00014287d2a6:  cc                    int3      
0x00014287d2a7:  8bc8                  mov       ecx, eax
0x00014287d2a9:  e8d26a2a03            call      0x145b23d80
0x00014287d2ae:  cc                    int3      
0x00014287d2af:  8bc8                  mov       ecx, eax
0x00014287d2b1:  e8ca6a2a03            call      0x145b23d80
0x00014287d2b6:  cc                    int3      
0x00014287d2b7:  cc                    int3      
0x00014287d2b8:  cc                    int3      
0x00014287d2b9:  cc                    int3      
0x00014287d2ba:  cc                    int3      
0x00014287d2bb:  cc                    int3      
0x00014287d2bc:  cc                    int3      
0x00014287d2bd:  cc                    int3      
0x00014287d2be:  cc                    int3      
0x00014287d2bf:  cc                    int3      
0x00014287d2c0:  48895c2418            mov       qword ptr [rsp + 0x18], rbx
0x00014287d2c5:  57                    push      rdi
0x00014287d2c6:  4883ec20              sub       rsp, 0x20
0x00014287d2ca:  83b98809000000        cmp       dword ptr [rcx + 0x988], 0
0x00014287d2d1:  488bda                mov       rbx, rdx
0x00014287d2d4:  488bf9                mov       rdi, rcx
0x00014287d2d7:  750d                  jne       0x14287d2e6
0x00014287d2d9:  32c0                  xor       al, al
0x00014287d2db:  488b5c2440            mov       rbx, qword ptr [rsp + 0x40]
0x00014287d2e0:  4883c420              add       rsp, 0x20
0x00014287d2e4:  5f                    pop       rdi
0x00014287d2e5:  c3                    ret       
0x00014287d2e6:  48896c2430            mov       qword ptr [rsp + 0x30], rbp
0x00014287d2eb:  4881c188080000        add       rcx, 0x888
0x00014287d2f2:  4889742438            mov       qword ptr [rsp + 0x38], rsi
0x00014287d2f7:  33f6                  xor       esi, esi
0x00014287d2f9:  e8b2642a03            call      0x145b237b0
0x00014287d2fe:  85c0                  test      eax, eax
0x00014287d300:  0f85ad000000          jne       0x14287d3b3
0x00014287d306:  448b9788090000        mov       r10d, dword ptr [rdi + 0x988]
0x00014287d30d:  4585d2                test      r10d, r10d
0x00014287d310:  746e                  je        0x14287d380
0x00014287d312:  4c8b9f80090000        mov       r11, qword ptr [rdi + 0x980]
0x00014287d319:  0f1f8000000000        nop       dword ptr [rax]
0x00014287d320:  4885db                test      rbx, rbx
0x00014287d323:  7454                  je        0x14287d379
0x00014287d325:  0fb603                movzx     eax, byte ptr [rbx]
0x00014287d328:  84c0                  test      al, al
0x00014287d32a:  744d                  je        0x14287d379
0x00014287d32c:  48c7c1ffffffff        mov       rcx, 0xffffffffffffffff
0x00014287d333:  48ffc1                inc       rcx
0x00014287d336:  803c0b00              cmp       byte ptr [rbx + rcx], 0
0x00014287d33a:  75f7                  jne       0x14287d333
0x00014287d33c:  4883f90f              cmp       rcx, 0xf
0x00014287d340:  7737                  ja        0x14287d379
0x00014287d342:  498b14f3              mov       rdx, qword ptr [r11 + rsi*8]
0x00014287d346:  4533c0                xor       r8d, r8d
0x00014287d349:  4c8b4a20              mov       r9, qword ptr [rdx + 0x20]
0x00014287d34d:  413801                cmp       byte ptr [r9], al
0x00014287d350:  7512                  jne       0x14287d364
0x00014287d352:  84c0                  test      al, al
0x00014287d354:  744d                  je        0x14287d3a3
0x00014287d356:  41ffc0                inc       r8d
0x00014287d359:  410fb60418            movzx     eax, byte ptr [r8 + rbx]
0x00014287d35e:  43380401              cmp       byte ptr [r9 + r8], al
0x00014287d362:  74ee                  je        0x14287d352
0x00014287d364:  430fb60c01            movzx     ecx, byte ptr [r9 + r8]
0x00014287d369:  84c9                  test      cl, cl
0x00014287d36b:  740c                  je        0x14287d379
0x00014287d36d:  41803c1800            cmp       byte ptr [r8 + rbx], 0
0x00014287d372:  7405                  je        0x14287d379
0x00014287d374:  80f92a                cmp       cl, 0x2a
0x00014287d377:  742a                  je        0x14287d3a3
0x00014287d379:  ffc6                  inc       esi
0x00014287d37b:  413bf2                cmp       esi, r10d
0x00014287d37e:  72a0                  jb        0x14287d320
0x00014287d380:  488d8f88080000        lea       rcx, [rdi + 0x888]
0x00014287d387:  e884642a03            call      0x145b23810
0x00014287d38c:  32c0                  xor       al, al
0x00014287d38e:  488b6c2430            mov       rbp, qword ptr [rsp + 0x30]
0x00014287d393:  488b742438            mov       rsi, qword ptr [rsp + 0x38]
0x00014287d398:  488b5c2440            mov       rbx, qword ptr [rsp + 0x40]
0x00014287d39d:  4883c420              add       rsp, 0x20
0x00014287d3a1:  5f                    pop       rdi
0x00014287d3a2:  c3                    ret       
0x00014287d3a3:  488d8f88080000        lea       rcx, [rdi + 0x888]
0x00014287d3aa:  e861642a03            call      0x145b23810
0x00014287d3af:  b001                  mov       al, 1
0x00014287d3b1:  ebdb                  jmp       0x14287d38e
0x00014287d3b3:  8bc8                  mov       ecx, eax
0x00014287d3b5:  e8c6692a03            call      0x145b23d80
0x00014287d3ba:  cc                    int3      
0x00014287d3bb:  cc                    int3      
0x00014287d3bc:  cc                    int3      
0x00014287d3bd:  cc                    int3      
0x00014287d3be:  cc                    int3      
0x00014287d3bf:  cc                    int3      
