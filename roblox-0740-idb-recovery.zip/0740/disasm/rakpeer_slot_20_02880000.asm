; RakPeer vtable slot 20
; rva 0x2880000
0x142880000:  4053                 push      rbx
0x142880002:  56                   push      rsi
0x142880003:  4154                 push      r12
0x142880005:  4155                 push      r13
0x142880007:  4156                 push      r14
0x142880009:  4157                 push      r15
0x14288000b:  4881eca8000000       sub       rsp, 0xa8
0x142880012:  488b05d7364905       mov       rax, qword ptr [rip + 0x54936d7]
0x142880019:  4833c4               xor       rax, rsp
0x14288001c:  4889842498000000     mov       qword ptr [rsp + 0x98], rax
0x142880024:  488b9c2408010000     mov       rbx, qword ptr [rsp + 0x108]
0x14288002c:  488bf1               mov       rsi, rcx
0x14288002f:  488b0a               mov       rcx, qword ptr [rdx]
0x142880032:  458be1               mov       r12d, r9d
0x142880035:  458be8               mov       r13d, r8d
0x142880038:  4c8bfa               mov       r15, rdx
0x14288003b:  488b01               mov       rax, qword ptr [rcx]
0x14288003e:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x142880042:  ff15f0fc8b03         call      qword ptr [rip + 0x38bfcf0]
0x142880048:  85c0                 test      eax, eax
0x14288004a:  0f84ce010000         je        0x14288021e
0x142880050:  4883be5003000000     cmp       qword ptr [rsi + 0x350], 0
0x142880058:  0f84c0010000         je        0x14288021e
0x14288005e:  0fb68608010000       movzx     eax, byte ptr [rsi + 0x108]
0x142880065:  90                   nop       
0x142880066:  3c01                 cmp       al, 1
0x142880068:  0f84b0010000         je        0x14288021e
0x14288006e:  440fb6b42410010000   movzx     r14d, byte ptr [rsp + 0x110]
0x142880077:  4584f6               test      r14b, r14b
0x14288007a:  7510                 jne       0x14288008c
0x14288007c:  488bcb               mov       rcx, rbx
0x14288007f:  e8ac8dffff           call      0x142878e30
0x142880084:  84c0                 test      al, al
0x142880086:  0f8592010000         jne       0x14288021e
0x14288008c:  4889ac24f8000000     mov       qword ptr [rsp + 0xf8], rbp
0x142880094:  8bac2418010000       mov       ebp, dword ptr [rsp + 0x118]
0x14288009b:  85ed                 test      ebp, ebp
0x14288009d:  7515                 jne       0x1428800b4
0x14288009f:  488b06               mov       rax, qword ptr [rsi]
0x1428800a2:  488bce               mov       rcx, rsi
0x1428800a5:  488b8098000000       mov       rax, qword ptr [rax + 0x98]
0x1428800ac:  ff1586fc8b03         call      qword ptr [rip + 0x38bfc86]
0x1428800b2:  8be8                 mov       ebp, eax
0x1428800b4:  4889bc24a0000000     mov       qword ptr [rsp + 0xa0], rdi
0x1428800bc:  4584f6               test      r14b, r14b
0x1428800bf:  0f85e7000000         jne       0x1428801ac
0x1428800c5:  41b001               mov       r8b, 1
0x1428800c8:  488bd3               mov       rdx, rbx
0x1428800cb:  488bce               mov       rcx, rsi
0x1428800ce:  e86d7d0000           call      0x142887e40
0x1428800d3:  84c0                 test      al, al
0x1428800d5:  0f84d1000000         je        0x1428801ac
0x1428800db:  488b0e               mov       rcx, qword ptr [rsi]
0x1428800de:  488bb9b8000000       mov       rdi, qword ptr [rcx + 0xb8]
0x1428800e5:  498b0f               mov       rcx, qword ptr [r15]
0x1428800e8:  488b01               mov       rax, qword ptr [rcx]
0x1428800eb:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x1428800ef:  ff1543fc8b03         call      qword ptr [rip + 0x38bfc43]
0x1428800f5:  498b17               mov       rdx, qword ptr [r15]
0x1428800f8:  8bd8                 mov       ebx, eax
0x1428800fa:  488b0a               mov       rcx, qword ptr [rdx]
0x1428800fd:  488b4108             mov       rax, qword ptr [rcx + 8]
0x142880101:  488bca               mov       rcx, rdx
0x142880104:  ff152efc8b03         call      qword ptr [rip + 0x38bfc2e]
0x14288010a:  448bc3               mov       r8d, ebx
0x14288010d:  488bce               mov       rcx, rsi
0x142880110:  488bd0               mov       rdx, rax
0x142880113:  488bc7               mov       rax, rdi
0x142880116:  ff151cfc8b03         call      qword ptr [rip + 0x38bfc1c]
0x14288011c:  4183fc05             cmp       r12d, 5
0x142880120:  7c56                 jl        0x142880178
0x142880122:  488d8ed80c0000       lea       rcx, [rsi + 0xcd8]
0x142880129:  c68424900000000e     mov       byte ptr [rsp + 0x90], 0xe
0x142880131:  e87a362a03           call      0x145b237b0
0x142880136:  85c0                 test      eax, eax
0x142880138:  0f85e7000000         jne       0x142880225
0x14288013e:  8b86280d0000         mov       eax, dword ptr [rsi + 0xd28]
0x142880144:  488d8ed80c0000       lea       rcx, [rsi + 0xcd8]
0x14288014b:  89842491000000       mov       dword ptr [rsp + 0x91], eax
0x142880152:  e8b9362a03           call      0x145b23810
0x142880157:  488b06               mov       rax, qword ptr [rsi]
0x14288015a:  488d942490000000     lea       rdx, [rsp + 0x90]
0x142880162:  41b805000000         mov       r8d, 5
0x142880168:  488bce               mov       rcx, rsi
0x14288016b:  488b80b8000000       mov       rax, qword ptr [rax + 0xb8]
0x142880172:  ff15c0fb8b03         call      qword ptr [rip + 0x38bfbc0]
0x142880178:  488bbc24a0000000     mov       rdi, qword ptr [rsp + 0xa0]
0x142880180:  8bc5                 mov       eax, ebp
0x142880182:  488bac24f8000000     mov       rbp, qword ptr [rsp + 0xf8]
0x14288018a:  488b8c2498000000     mov       rcx, qword ptr [rsp + 0x98]
0x142880192:  4833cc               xor       rcx, rsp
0x142880195:  e846142a03           call      0x145b215e0
0x14288019a:  4881c4a8000000       add       rsp, 0xa8
0x1428801a1:  415f                 pop       r15
0x1428801a3:  415e                 pop       r14
0x1428801a5:  415d                 pop       r13
0x1428801a7:  415c                 pop       r12
0x1428801a9:  5e                   pop       rsi
0x1428801aa:  5b                   pop       rbx
0x1428801ab:  c3                   ret       
0x1428801ac:  498b07               mov       rax, qword ptr [r15]
0x1428801af:  488d4c2460           lea       rcx, [rsp + 0x60]
0x1428801b4:  488bd3               mov       rdx, rbx
0x1428801b7:  0fb67808             movzx     edi, byte ptr [rax + 8]
0x1428801bb:  e8d08cffff           call      0x142878e90
0x1428801c0:  498b0f               mov       rcx, qword ptr [r15]
0x1428801c3:  488bd8               mov       rbx, rax
0x1428801c6:  488b11               mov       rdx, qword ptr [rcx]
0x1428801c9:  488b4210             mov       rax, qword ptr [rdx + 0x10]
0x1428801cd:  ff1565fb8b03         call      qword ptr [rip + 0x38bfb65]
0x1428801d3:  488b8c2420010000     mov       rcx, qword ptr [rsp + 0x120]
0x1428801db:  458bcd               mov       r9d, r13d
0x1428801de:  48894c2458           mov       qword ptr [rsp + 0x58], rcx
0x1428801e3:  448bc0               mov       r8d, eax
0x1428801e6:  0fb6842400010000     movzx     eax, byte ptr [rsp + 0x100]
0x1428801ee:  498bd7               mov       rdx, r15
0x1428801f1:  40887c2450           mov       byte ptr [rsp + 0x50], dil
0x1428801f6:  488bce               mov       rcx, rsi
0x1428801f9:  896c2448             mov       dword ptr [rsp + 0x48], ebp
0x1428801fd:  4488742438           mov       byte ptr [rsp + 0x38], r14b
0x142880202:  48895c2430           mov       qword ptr [rsp + 0x30], rbx
0x142880207:  88442428             mov       byte ptr [rsp + 0x28], al
0x14288020b:  41c1e003             shl       r8d, 3
0x14288020f:  4489642420           mov       dword ptr [rsp + 0x20], r12d
0x142880214:  e8a78f0000           call      0x1428891c0
0x142880219:  e95affffff           jmp       0x142880178
0x14288021e:  33c0                 xor       eax, eax
0x142880220:  e965ffffff           jmp       0x14288018a
0x142880225:  8bc8                 mov       ecx, eax
0x142880227:  e8543b2a03           call      0x145b23d80
0x14288022c:  cc                   int3      
0x14288022d:  cc                   int3      
0x14288022e:  cc                   int3      
0x14288022f:  cc                   int3      
0x142880230:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x142880235:  55                   push      rbp
0x142880236:  57                   push      rdi
0x142880237:  4156                 push      r14
0x142880239:  4883ec30             sub       rsp, 0x30
0x14288023d:  488bd9               mov       rbx, rcx
0x142880240:  33ed                 xor       ebp, ebp
0x142880242:  4881c1300c0000       add       rcx, 0xc30
0x142880249:  48892a               mov       qword ptr [rdx], rbp
0x14288024c:  66896a08             mov       word ptr [rdx + 8], bp
0x142880250:  488bfa               mov       rdi, rdx
0x142880253:  e858352a03           call      0x145b237b0
0x142880258:  85c0                 test      eax, eax
0x14288025a:  0f8520010000         jne       0x142880380
0x142880260:  8b83880c0000         mov       eax, dword ptr [rbx + 0xc88]
0x142880266:  3b838c0c0000         cmp       eax, dword ptr [rbx + 0xc8c]
0x14288026c:  0f84f1000000         je        0x142880363
0x142880272:  8b8b900c0000         mov       ecx, dword ptr [rbx + 0xc90]
0x142880278:  ffc0                 inc       eax
0x14288027a:  4889742458           mov       qword ptr [rsp + 0x58], rsi
0x14288027f:  488bb3800c0000       mov       rsi, qword ptr [rbx + 0xc80]
0x142880286:  8983880c0000         mov       dword ptr [rbx + 0xc88], eax
0x14288028c:  3bc1                 cmp       eax, ecx
0x14288028e:  750b                 jne       0x14288029b
0x142880290:  89ab880c0000         mov       dword ptr [rbx + 0xc88], ebp
0x142880296:  8d41ff               lea       eax, [rcx - 1]
0x142880299:  eb0b                 jmp       0x1428802a6
0x14288029b:  85c0                 test      eax, eax
0x14288029d:  7505                 jne       0x1428802a4
0x14288029f:  8d41ff               lea       eax, [rcx - 1]
0x1428802a2:  eb02                 jmp       0x1428802a6
0x1428802a4:  ffc8                 dec       eax
0x1428802a6:  40382dab76a405       cmp       byte ptr [rip + 0x5a476ab], bpl
0x1428802ad:  488b34c6             mov       rsi, qword ptr [rsi + rax*8]
0x1428802b1:  488937               mov       qword ptr [rdi], rsi
0x1428802b4:  7430                 je        0x1428802e6
0x1428802b6:  488d8b980c0000       lea       rcx, [rbx + 0xc98]
0x1428802bd:  4c8bc6               mov       r8, rsi
0x1428802c0:  488d542450           lea       rdx, [rsp + 0x50]
0x1428802c5:  e8f62a0200           call      0x1428a2dc0
0x1428802ca:  488b442450           mov       rax, qword ptr [rsp + 0x50]
0x1428802cf:  483b83a00c0000       cmp       rax, qword ptr [rbx + 0xca0]
0x1428802d6:  740e                 je        0x1428802e6
0x1428802d8:  8b4830               mov       ecx, dword ptr [rax + 0x30]
0x1428802db:  2b4e30               sub       ecx, dword ptr [rsi + 0x30]
0x1428802de:  85c9                 test      ecx, ecx
0x1428802e0:  0f4fe9               cmovg     ebp, ecx
0x1428802e3:  896830               mov       dword ptr [rax + 0x30], ebp
0x1428802e6:  488b4638             mov       rax, qword ptr [rsi + 0x38]
0x1428802ea:  0fb608               movzx     ecx, byte ptr [rax]
0x1428802ed:  80f990               cmp       cl, 0x90
0x1428802f0:  740e                 je        0x142880300
0x1428802f2:  80e915               sub       cl, 0x15
0x1428802f5:  80f901               cmp       cl, 1
0x1428802f8:  7606                 jbe       0x142880300
0x1428802fa:  c6470900             mov       byte ptr [rdi + 9], 0
0x1428802fe:  eb5e                 jmp       0x14288035e
0x142880300:  488b05c9a64e05       mov       rax, qword ptr [rip + 0x54ea6c9]
0x142880307:  c6470901             mov       byte ptr [rdi + 9], 1
0x14288030b:  3c06                 cmp       al, 6
0x14288030d:  724f                 jb        0x14288035e
0x14288030f:  48c1e808             shr       rax, 8
0x142880313:  3c03                 cmp       al, 3
0x142880315:  7247                 jb        0x14288035e
0x142880317:  488d052be00405       lea       rax, [rip + 0x504e02b]
0x14288031e:  4889442450           mov       qword ptr [rsp + 0x50], rax
0x142880323:  488d0d6a826b04       lea       rcx, [rip + 0x46b826a]
0x14288032a:  488b542450           mov       rdx, qword ptr [rsp + 0x50]
0x14288032f:  4c8d0502826b04       lea       r8, [rip + 0x46b8202]
0x142880336:  488b4638             mov       rax, qword ptr [rsi + 0x38]
0x14288033a:  488d150f826b04       lea       rdx, [rip + 0x46b820f]
0x142880341:  0f100588a64e05       movups    xmm0, xmmword ptr [rip + 0x54ea688]
0x142880348:  803890               cmp       byte ptr [rax], 0x90
0x14288034b:  0f29442420           movaps    xmmword ptr [rsp + 0x20], xmm0
0x142880350:  4c0f44c1             cmove     r8, rcx
0x142880354:  488d4c2420           lea       rcx, [rsp + 0x20]
0x142880359:  e832f50d02           call      0x14495f890
0x14288035e:  488b742458           mov       rsi, qword ptr [rsp + 0x58]
0x142880363:  488d8b300c0000       lea       rcx, [rbx + 0xc30]
0x14288036a:  e8a1342a03           call      0x145b23810
0x14288036f:  488b5c2460           mov       rbx, qword ptr [rsp + 0x60]
0x142880374:  488bc7               mov       rax, rdi
0x142880377:  4883c430             add       rsp, 0x30
0x14288037b:  415e                 pop       r14
0x14288037d:  5f                   pop       rdi
0x14288037e:  5d                   pop       rbp
0x14288037f:  c3                   ret       
0x142880380:  8bc8                 mov       ecx, eax
0x142880382:  e8f9392a03           call      0x145b23d80
0x142880387:  cc                   int3      
0x142880388:  cc                   int3      
0x142880389:  cc                   int3      
0x14288038a:  cc                   int3      
0x14288038b:  cc                   int3      
0x14288038c:  cc                   int3      
0x14288038d:  cc                   int3      
0x14288038e:  cc                   int3      
0x14288038f:  cc                   int3      
0x142880390:  48895c2410           mov       qword ptr [rsp + 0x10], rbx
0x142880395:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x14288039a:  55                   push      rbp
0x14288039b:  57                   push      rdi
0x14288039c:  4154                 push      r12
0x14288039e:  4156                 push      r14
0x1428803a0:  4157                 push      r15
0x1428803a2:  488dac2460fcffff     lea       rbp, [rsp - 0x3a0]
0x1428803aa:  4881eca0040000       sub       rsp, 0x4a0
0x1428803b1:  488b0538334905       mov       rax, qword ptr [rip + 0x5493338]
0x1428803b8:  4833c4               xor       rax, rsp
0x1428803bb:  48898598030000       mov       qword ptr [rbp + 0x398], rax
0x1428803c2:  0fb6da               movzx     ebx, dl
0x1428803c5:  488bf9               mov       rdi, rcx
0x1428803c8:  e8f3990300           call      0x1428b9dc0
0x1428803cd:  448bf8               mov       r15d, eax
0x1428803d0:  8b8760030000         mov       eax, dword ptr [rdi + 0x360]
0x1428803d6:  90                   nop       
0x1428803d7:  85c0                 test      eax, eax
0x1428803d9:  0f84ef010000         je        0x1428805ce
0x1428803df:  ff87c80f0000         inc       dword ptr [rdi + 0xfc8]
0x1428803e5:  418bf7               mov       esi, r15d
0x1428803e8:  2bb7d00f0000         sub       esi, dword ptr [rdi + 0xfd0]
0x1428803ee:  e83d081d00           call      0x142a50c30
0x1428803f3:  660f6ec0             movd      xmm0, eax
0x1428803f7:  f30fe6c0             cvtdq2pd  xmm0, xmm0
0x1428803fb:  660f6e0d3dad4e05     movd      xmm1, dword ptr [rip + 0x54ead3d]
0x142880403:  f30fe6c9             cvtdq2pd  xmm1, xmm1
0x142880407:  f20f5e0d298c9404     divsd     xmm1, qword ptr [rip + 0x4948c29]
0x14288040f:  f20f59c8             mulsd     xmm1, xmm0
0x142880413:  660f6e87c80f0000     movd      xmm0, dword ptr [rdi + 0xfc8]
0x14288041b:  f30fe6c0             cvtdq2pd  xmm0, xmm0
0x14288041f:  660f2fc1             comisd    xmm0, xmm1
0x142880423:  0f86a5010000         jbe       0x1428805ce
0x142880429:  418bcf               mov       ecx, r15d
0x14288042c:  482b8fd80f0000       sub       rcx, qword ptr [rdi + 0xfd8]
0x142880433:  4863052ead4e05       movsxd    rax, dword ptr [rip + 0x54ead2e]
0x14288043a:  483bc8               cmp       rcx, rax
0x14288043d:  0f86be000000         jbe       0x142880501
0x142880443:  4c89bfd80f0000       mov       qword ptr [rdi + 0xfd8], r15
0x14288044a:  488b053fad4e05       mov       rax, qword ptr [rip + 0x54ead3f]
0x142880451:  3c06                 cmp       al, 6
0x142880453:  0f82a8000000         jb        0x142880501
0x142880459:  48c1e808             shr       rax, 8
0x14288045d:  3c06                 cmp       al, 6
0x14288045f:  0f829c000000         jb        0x142880501
0x142880465:  488d05e4090205       lea       rax, [rip + 0x50209e4]
0x14288046c:  4889442440           mov       qword ptr [rsp + 0x40], rax
0x142880471:  488b4c2440           mov       rcx, qword ptr [rsp + 0x40]
0x142880476:  488d0d63806b04       lea       rcx, [rip + 0x46b8063]
0x14288047d:  48894d80             mov       qword ptr [rbp - 0x80], rcx
0x142880481:  48c7c0ffffffff       mov       rax, 0xffffffffffffffff
0x142880488:  0f1f840000000000     nop       dword ptr [rax + rax]
0x142880490:  48ffc0               inc       rax
0x142880493:  803c0100             cmp       byte ptr [rcx + rax], 0
0x142880497:  75f7                 jne       0x142880490
0x142880499:  48894588             mov       qword ptr [rbp - 0x78], rax
0x14288049d:  8b87c80f0000         mov       eax, dword ptr [rdi + 0xfc8]
0x1428804a3:  8945b0               mov       dword ptr [rbp - 0x50], eax
0x1428804a6:  8975c0               mov       dword ptr [rbp - 0x40], esi
0x1428804a9:  0f1045b0             movups    xmm0, xmmword ptr [rbp - 0x50]
0x1428804ad:  0f114530             movups    xmmword ptr [rbp + 0x30], xmm0
0x1428804b1:  0f104dc0             movups    xmm1, xmmword ptr [rbp - 0x40]
0x1428804b5:  0f114d40             movups    xmmword ptr [rbp + 0x40], xmm1
0x1428804b9:  48c744247011000000   mov       qword ptr [rsp + 0x70], 0x11
0x1428804c2:  488d4530             lea       rax, [rbp + 0x30]
0x1428804c6:  4889442478           mov       qword ptr [rsp + 0x78], rax
0x1428804cb:  0f28442470           movaps    xmm0, xmmword ptr [rsp + 0x70]
0x1428804d0:  660f7f45d0           movdqa    xmmword ptr [rbp - 0x30], xmm0
0x1428804d5:  0f284d80             movaps    xmm1, xmmword ptr [rbp - 0x80]
0x1428804d9:  660f7f4de0           movdqa    xmmword ptr [rbp - 0x20], xmm1
0x1428804de:  0f1005abac4e05       movups    xmm0, xmmword ptr [rip + 0x54eacab]
0x1428804e5:  0f2945f0             movaps    xmmword ptr [rbp - 0x10], xmm0
0x1428804e9:  c644242001           mov       byte ptr [rsp + 0x20], 1
0x1428804ee:  4c8d4dd0             lea       r9, [rbp - 0x30]
0x1428804f2:  4c8d45e0             lea       r8, [rbp - 0x20]
0x1428804f6:  b206                 mov       dl, 6
0x1428804f8:  488d4df0             lea       rcx, [rbp - 0x10]
0x1428804fc:  e8cff50d02           call      0x14495fad0
0x142880501:  80bfe00f000000       cmp       byte ptr [rdi + 0xfe0], 0
0x142880508:  0f85c0000000         jne       0x1428805ce
0x14288050e:  c687e00f000001       mov       byte ptr [rdi + 0xfe0], 1
0x142880515:  488d15a4ac4e05       lea       rdx, [rip + 0x54eaca4]
0x14288051c:  488d4d50             lea       rcx, [rbp + 0x50]
0x142880520:  e8fb4bfbfd           call      0x140835120
0x142880525:  90                   nop       
0x142880526:  4c6387c80f0000       movsxd    r8, dword ptr [rdi + 0xfc8]
0x14288052d:  488d055c7f6b04       lea       rax, [rip + 0x46b7f5c]
0x142880534:  48894590             mov       qword ptr [rbp - 0x70], rax
0x142880538:  48c745981d000000     mov       qword ptr [rbp - 0x68], 0x1d
0x142880540:  0f284590             movaps    xmm0, xmmword ptr [rbp - 0x70]
0x142880544:  660f7f4500           movdqa    xmmword ptr [rbp], xmm0
0x142880549:  41b901000000         mov       r9d, 1
0x14288054f:  488d5500             lea       rdx, [rbp]
0x142880553:  488d8d20030000       lea       rcx, [rbp + 0x320]
0x14288055a:  e811286500           call      0x142ed2d70
0x14288055f:  4c63c6               movsxd    r8, esi
0x142880562:  488d05477f6b04       lea       rax, [rip + 0x46b7f47]
0x142880569:  488945a0             mov       qword ptr [rbp - 0x60], rax
0x14288056d:  48c745a81d000000     mov       qword ptr [rbp - 0x58], 0x1d
0x142880575:  0f2845a0             movaps    xmm0, xmmword ptr [rbp - 0x60]
0x142880579:  660f7f4510           movdqa    xmmword ptr [rbp + 0x10], xmm0
0x14288057e:  41b901000000         mov       r9d, 1
0x142880584:  488d5510             lea       rdx, [rbp + 0x10]
0x142880588:  488d8d20030000       lea       rcx, [rbp + 0x320]
0x14288058f:  e8dc276500           call      0x142ed2d70
0x142880594:  488d8d68030000       lea       rcx, [rbp + 0x368]
0x14288059b:  e8e0796400           call      0x142ec7f80
0x1428805a0:  90                   nop       
0x1428805a1:  488d8d40030000       lea       rcx, [rbp + 0x340]
0x1428805a8:  e88323f6fd           call      0x1407e2930
0x1428805ad:  488d8d20030000       lea       rcx, [rbp + 0x320]
0x1428805b4:  e87723f6fd           call      0x1407e2930
0x1428805b9:  488d8d20030000       lea       rcx, [rbp + 0x320]
0x1428805c0:  e86b10f5fd           call      0x1407d1630
0x1428805c5:  488d4d78             lea       rcx, [rbp + 0x78]
0x1428805c9:  e81254f6fd           call      0x1407e59e0
0x1428805ce:  4533e4               xor       r12d, r12d
0x1428805d1:  84db                 test      bl, bl
0x1428805d3:  7468                 je        0x14288063d
0x1428805d5:  488b053ca34e05       mov       rax, qword ptr [rip + 0x54ea33c]
0x1428805dc:  3c06                 cmp       al, 6
0x1428805de:  724d                 jb        0x14288062d
0x1428805e0:  48c1e808             shr       rax, 8
0x1428805e4:  3c03                 cmp       al, 3
0x1428805e6:  7245                 jb        0x14288062d
0x1428805e8:  488d05f37c0605       lea       rax, [rip + 0x5067cf3]
0x1428805ef:  4889442440           mov       qword ptr [rsp + 0x40], rax
0x1428805f4:  488b542440           mov       rdx, qword ptr [rsp + 0x40]
0x1428805f9:  488d15b0836b04       lea       rdx, [rip + 0x46b83b0]
0x142880600:  0f100511a34e05       movups    xmm0, xmmword ptr [rip + 0x54ea311]
0x142880607:  0f294520             movaps    xmmword ptr [rbp + 0x20], xmm0
0x14288060b:  4c89642430           mov       qword ptr [rsp + 0x30], r12
0x142880610:  4c89642428           mov       qword ptr [rsp + 0x28], r12
0x142880615:  4c89642420           mov       qword ptr [rsp + 0x20], r12
0x14288061a:  4533c9               xor       r9d, r9d
0x14288061d:  4c8b87c80d0000       mov       r8, qword ptr [rdi + 0xdc8]
0x142880624:  488d4d20             lea       rcx, [rbp + 0x20]
0x142880628:  e8f3f70d02           call      0x14495fe20
0x14288062d:  443825f45da405       cmp       byte ptr [rip + 0x5a45df4], r12b
0x142880634:  7407                 je        0x14288063d
0x142880636:  4c89a7c80d0000       mov       qword ptr [rdi + 0xdc8], r12
0x14288063d:  488b07               mov       rax, qword ptr [rdi]
0x142880640:  488bcf               mov       rcx, rdi
0x142880643:  488b4078             mov       rax, qword ptr [rax + 0x78]
0x142880647:  ff15ebf68b03         call      qword ptr [rip + 0x38bf6eb]
0x14288064d:  84c0                 test      al, al
0x14288064f:  756b                 jne       0x1428806bc
0x142880651:  84db                 test      bl, bl
0x142880653:  0f84a0030000         je        0x1428809f9
0x142880659:  488b05b8a24e05       mov       rax, qword ptr [rip + 0x54ea2b8]
0x142880660:  3c06                 cmp       al, 6
0x142880662:  0f8291030000         jb        0x1428809f9
0x142880668:  48c1e808             shr       rax, 8
0x14288066c:  3c03                 cmp       al, 3
0x14288066e:  0f8285030000         jb        0x1428809f9
0x142880674:  488d0536540705       lea       rax, [rip + 0x5075436]
0x14288067b:  4889442440           mov       qword ptr [rsp + 0x40], rax
0x142880680:  488b542440           mov       rdx, qword ptr [rsp + 0x40]
0x142880685:  488d158c836b04       lea       rdx, [rip + 0x46b838c]
0x14288068c:  0f100585a24e05       movups    xmm0, xmmword ptr [rip + 0x54ea285]
0x142880693:  0f29442460           movaps    xmmword ptr [rsp + 0x60], xmm0
0x142880698:  4c89642430           mov       qword ptr [rsp + 0x30], r12
0x14288069d:  4c89642428           mov       qword ptr [rsp + 0x28], r12
0x1428806a2:  4c89642420           mov       qword ptr [rsp + 0x20], r12
0x1428806a7:  4533c9               xor       r9d, r9d
0x1428806aa:  4533c0               xor       r8d, r8d
0x1428806ad:  488d4c2460           lea       rcx, [rsp + 0x60]
0x1428806b2:  e869f70d02           call      0x14495fe20
0x1428806b7:  e93d030000           jmp       0x1428809f9
0x1428806bc:  488d542448           lea       rdx, [rsp + 0x48]
0x1428806c1:  488bcf               mov       rcx, rdi
0x1428806c4:  e867fbffff           call      0x142880230
0x1428806c9:  488b742448           mov       rsi, qword ptr [rsp + 0x48]
0x1428806ce:  84db                 test      bl, bl
0x1428806d0:  7468                 je        0x14288073a
0x1428806d2:  4885f6               test      rsi, rsi
0x1428806d5:  7579                 jne       0x142880750
0x1428806d7:  488b053aa24e05       mov       rax, qword ptr [rip + 0x54ea23a]
0x1428806de:  3c06                 cmp       al, 6
0x1428806e0:  0f8224020000         jb        0x14288090a
0x1428806e6:  48c1e808             shr       rax, 8
0x1428806ea:  3c03                 cmp       al, 3
0x1428806ec:  0f8218020000         jb        0x14288090a
0x1428806f2:  488d0598ef0705       lea       rax, [rip + 0x507ef98]
0x1428806f9:  4889442440           mov       qword ptr [rsp + 0x40], rax
0x1428806fe:  488b542440           mov       rdx, qword ptr [rsp + 0x40]
0x142880703:  488d1546826b04       lea       rdx, [rip + 0x46b8246]
0x14288070a:  0f100507a24e05       movups    xmm0, xmmword ptr [rip + 0x54ea207]
0x142880711:  0f29442460           movaps    xmmword ptr [rsp + 0x60], xmm0
0x142880716:  4c89642430           mov       qword ptr [rsp + 0x30], r12
0x14288071b:  4c89642428           mov       qword ptr [rsp + 0x28], r12
0x142880720:  4c89642420           mov       qword ptr [rsp + 0x20], r12
0x142880725:  4533c9               xor       r9d, r9d
0x142880728:  4533c0               xor       r8d, r8d
0x14288072b:  488d4c2460           lea       rcx, [rsp + 0x60]
0x142880730:  e8ebf60d02           call      0x14495fe20
0x142880735:  e9d0010000           jmp       0x14288090a
0x14288073a:  4885f6               test      rsi, rsi
0x14288073d:  0f84c7010000         je        0x14288090a
0x142880743:  0f1f4000             nop       dword ptr [rax]
0x142880747:  660f1f840000000000   nop       word ptr [rax + rax]
0x142880750:  4c89bfd00f0000       mov       qword ptr [rdi + 0xfd0], r15
0x142880757:  4489a7c80f0000       mov       dword ptr [rdi + 0xfc8], r12d
0x14288075e:  443825c3ada005       cmp       byte ptr [rip + 0x5a0adc3], r12b
0x142880765:  746c                 je        0x1428807d3
0x142880767:  443825aa93df05       cmp       byte ptr [rip + 0x5df93aa], r12b
0x14288076e:  7463                 je        0x1428807d3
0x142880770:  44396630             cmp       dword ptr [rsi + 0x30], r12d
0x142880774:  765d                 jbe       0x1428807d3
0x142880776:  488bd6               mov       rdx, rsi
0x142880779:  488bcf               mov       rcx, rdi
0x14288077c:  e80f760000           call      0x142887d90
0x142880781:  8bc8                 mov       ecx, eax
0x142880783:  483b8f70030000       cmp       rcx, qword ptr [rdi + 0x370]
0x14288078a:  7347                 jae       0x1428807d3
0x14288078c:  4869d150100000       imul      rdx, rcx, 0x1050
0x142880793:  488b8768030000       mov       rax, qword ptr [rdi + 0x368]
0x14288079a:  0fb6840248100000     movzx     eax, byte ptr [rdx + rax + 0x1048]
0x1428807a2:  84c0                 test      al, al
0x1428807a4:  7428                 je        0x1428807ce
0x1428807a6:  488b8f68030000       mov       rcx, qword ptr [rdi + 0x368]
0x1428807ad:  4881c120080000       add       rcx, 0x820
0x1428807b4:  4803ca               add       rcx, rdx
0x1428807b7:  448b4630             mov       r8d, dword ptr [rsi + 0x30]
0x1428807bb:  488b742448           mov       rsi, qword ptr [rsp + 0x48]
0x1428807c0:  488b4638             mov       rax, qword ptr [rsi + 0x38]
0x1428807c4:  0fb610               movzx     edx, byte ptr [rax]
0x1428807c7:  e8945a9902           call      0x145216260
0x1428807cc:  eb05                 jmp       0x1428807d3
0x1428807ce:  488b742448           mov       rsi, qword ptr [rsp + 0x48]
0x1428807d3:  4438642450           cmp       byte ptr [rsp + 0x50], r12b
0x1428807d8:  7504                 jne       0x1428807de
0x1428807da:  4c897e50             mov       qword ptr [rsi + 0x50], r15
0x1428807de:  837e3009             cmp       dword ptr [rsi + 0x30], 9
0x1428807e2:  7217                 jb        0x1428807fb
0x1428807e4:  488b5638             mov       rdx, qword ptr [rsi + 0x38]
0x1428807e8:  803a1b               cmp       byte ptr [rdx], 0x1b
0x1428807eb:  750e                 jne       0x1428807fb
0x1428807ed:  48ffc2               inc       rdx
0x1428807f0:  4c8bc6               mov       r8, rsi
0x1428807f3:  488bcf               mov       rcx, rdi
0x1428807f6:  e8e56a0000           call      0x1428872e0
0x1428807fb:  443825265ca405       cmp       byte ptr [rip + 0x5a45c26], r12b
0x142880802:  7407                 je        0x14288080b
0x142880804:  48ff87c80d0000       inc       qword ptr [rdi + 0xdc8]
0x14288080b:  4c39a7f80e0000       cmp       qword ptr [rdi + 0xef8], r12
0x142880812:  0f84b9000000         je        0x1428808d1
0x142880818:  443825296ca405       cmp       byte ptr [rip + 0x5a46c29], r12b
0x14288081f:  0f8490000000         je        0x1428808b5
0x142880825:  4c396660             cmp       qword ptr [rsi + 0x60], r12
0x142880829:  0f8486000000         je        0x1428808b5
0x14288082f:  488b0592401506       mov       rax, qword ptr [rip + 0x6154092]
0x142880836:  443825db64a005       cmp       byte ptr [rip + 0x5a064db], r12b
0x14288083d:  7436                 je        0x142880875
0x14288083f:  4885c0               test      rax, rax
0x142880842:  7406                 je        0x14288084a
0x142880844:  488b5818             mov       rbx, qword ptr [rax + 0x18]
0x142880848:  eb03                 jmp       0x14288084d
0x14288084a:  498bdc               mov       rbx, r12
0x14288084d:  488b07               mov       rax, qword ptr [rdi]
0x142880850:  488bcf               mov       rcx, rdi
0x142880853:  488b80c0000000       mov       rax, qword ptr [rax + 0xc0]
0x14288085a:  ff15d8f48b03         call      qword ptr [rip + 0x38bf4d8]
0x142880860:  41b148               mov       r9b, 0x48
0x142880863:  440fb6c0             movzx     r8d, al
0x142880867:  488b5660             mov       rdx, qword ptr [rsi + 0x60]
0x14288086b:  488bcb               mov       rcx, rbx
0x14288086e:  e8adc52801           call      0x143b0ce20
0x142880873:  eb40                 jmp       0x1428808b5
0x142880875:  4885c0               test      rax, rax
0x142880878:  7406                 je        0x142880880
0x14288087a:  4c8b7018             mov       r14, qword ptr [rax + 0x18]
0x14288087e:  eb03                 jmp       0x142880883
0x142880880:  4d8bf4               mov       r14, r12
0x142880883:  e838950300           call      0x1428b9dc0
0x142880888:  8bd8                 mov       ebx, eax
0x14288088a:  488b07               mov       rax, qword ptr [rdi]
0x14288088d:  488bcf               mov       rcx, rdi
0x142880890:  488b80c0000000       mov       rax, qword ptr [rax + 0xc0]
0x142880897:  ff159bf48b03         call      qword ptr [rip + 0x38bf49b]
0x14288089d:  48895c2420           mov       qword ptr [rsp + 0x20], rbx
0x1428808a2:  41b148               mov       r9b, 0x48
0x1428808a5:  440fb6c0             movzx     r8d, al
0x1428808a9:  488b5660             mov       rdx, qword ptr [rsi + 0x60]
0x1428808ad:  498bce               mov       rcx, r14
0x1428808b0:  e83bc32801           call      0x143b0cbf0
0x1428808b5:  488b8ff80e0000       mov       rcx, qword ptr [rdi + 0xef8]
0x1428808bc:  488b01               mov       rax, qword ptr [rcx]
0x1428808bf:  488bd6               mov       rdx, rsi
0x1428808c2:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x1428808c6:  ff156cf48b03         call      qword ptr [rip + 0x38bf46c]
0x1428808cc:  83f802               cmp       eax, 2
0x1428808cf:  7416                 je        0x1428808e7
0x1428808d1:  488b07               mov       rax, qword ptr [rdi]
0x1428808d4:  488bd6               mov       rdx, rsi
0x1428808d7:  488bcf               mov       rcx, rdi
0x1428808da:  488b80e8000000       mov       rax, qword ptr [rax + 0xe8]
0x1428808e1:  ff1551f48b03         call      qword ptr [rip + 0x38bf451]
0x1428808e7:  488d542460           lea       rdx, [rsp + 0x60]
0x1428808ec:  488bcf               mov       rcx, rdi
0x1428808ef:  e83cf9ffff           call      0x142880230
0x1428808f4:  0f1000               movups    xmm0, xmmword ptr [rax]
0x1428808f7:  0f11442448           movups    xmmword ptr [rsp + 0x48], xmm0
0x1428808fc:  66480f7ec6           movq      rsi, xmm0
0x142880901:  4885f6               test      rsi, rsi
0x142880904:  0f8546feffff         jne       0x142880750
0x14288090a:  44382517aca005       cmp       byte ptr [rip + 0x5a0ac17], r12b
0x142880911:  0f84e2000000         je        0x1428809f9
0x142880917:  443825fa91df05       cmp       byte ptr [rip + 0x5df91fa], r12b
0x14288091e:  0f84d5000000         je        0x1428809f9
0x142880924:  488d056d806b04       lea       rax, [rip + 0x46b806d]
0x14288092b:  4c8d3556816b04       lea       r14, [rip + 0x46b8156]
0x142880932:  4438a750100000       cmp       byte ptr [rdi + 0x1050], r12b
0x142880939:  4c0f45f0             cmovne    r14, rax
0x14288093d:  448bbf78030000       mov       r15d, dword ptr [rdi + 0x378]
0x142880944:  498bf4               mov       rsi, r12
0x142880947:  4c39a770030000       cmp       qword ptr [rdi + 0x370], r12
0x14288094e:  0f86a5000000         jbe       0x1428809f9
0x142880954:  498bdc               mov       rbx, r12
0x142880957:  660f1f840000000000   nop       word ptr [rax + rax]
0x142880960:  4c8b8f68030000       mov       r9, qword ptr [rdi + 0x368]
0x142880967:  4e8d040b             lea       r8, [rbx + r9]
0x14288096b:  418bd4               mov       edx, r12d
0x14288096e:  498b8820080000       mov       rcx, qword ptr [r8 + 0x820]
0x142880975:  4885c9               test      rcx, rcx
0x142880978:  751a                 jne       0x142880994
0x14288097a:  660f1f440000         nop       word ptr [rax + rax]
0x142880980:  ffc2                 inc       edx
0x142880982:  83fa04               cmp       edx, 4
0x142880985:  745b                 je        0x1428809e2
0x142880987:  498b8cd020080000     mov       rcx, qword ptr [r8 + rdx*8 + 0x820]
0x14288098f:  4885c9               test      rcx, rcx
0x142880992:  74ec                 je        0x142880980
0x142880994:  488bc1               mov       rax, rcx
0x142880997:  48f7d8               neg       rax
0x14288099a:  4823c1               and       rax, rcx
0x14288099d:  480fbdc8             bsr       rcx, rax
0x1428809a1:  c1e206               shl       edx, 6
0x1428809a4:  03d1                 add       edx, ecx
0x1428809a6:  83faff               cmp       edx, -1
0x1428809a9:  7437                 je        0x1428809e2
0x1428809ab:  428b940b40100000     mov       edx, dword ptr [rbx + r9 + 0x1040]
0x1428809b3:  488b8768030000       mov       rax, qword ptr [rdi + 0x368]
0x1428809ba:  448b840344100000     mov       r8d, dword ptr [rbx + rax + 0x1044]
0x1428809c2:  488b8f68030000       mov       rcx, qword ptr [rdi + 0x368]
0x1428809c9:  4881c120080000       add       rcx, 0x820
0x1428809d0:  4803cb               add       rcx, rbx
0x1428809d3:  89542420             mov       dword ptr [rsp + 0x20], edx
0x1428809d7:  458bcf               mov       r9d, r15d
0x1428809da:  498bd6               mov       rdx, r14
0x1428809dd:  e88e599902           call      0x145216370
0x1428809e2:  48ffc6               inc       rsi
0x1428809e5:  4881c350100000       add       rbx, 0x1050
0x1428809ec:  483bb770030000       cmp       rsi, qword ptr [rdi + 0x370]
0x1428809f3:  0f8267ffffff         jb        0x142880960
0x1428809f9:  488b8d98030000       mov       rcx, qword ptr [rbp + 0x398]
0x142880a00:  4833cc               xor       rcx, rsp
0x142880a03:  e8d80b2a03           call      0x145b215e0
0x142880a08:  4c8d9c24a0040000     lea       r11, [rsp + 0x4a0]
0x142880a10:  498b5b38             mov       rbx, qword ptr [r11 + 0x38]
0x142880a14:  498b7340             mov       rsi, qword ptr [r11 + 0x40]
0x142880a18:  498be3               mov       rsp, r11
0x142880a1b:  415f                 pop       r15
0x142880a1d:  415e                 pop       r14
0x142880a1f:  415c                 pop       r12
0x142880a21:  5f                   pop       rdi
0x142880a22:  5d                   pop       rbp
0x142880a23:  c3                   ret       
0x142880a24:  cc                   int3      
0x142880a25:  cc                   int3      
0x142880a26:  cc                   int3      
0x142880a27:  cc                   int3      
0x142880a28:  cc                   int3      
0x142880a29:  cc                   int3      
0x142880a2a:  cc                   int3      
0x142880a2b:  cc                   int3      
0x142880a2c:  cc                   int3      
0x142880a2d:  cc                   int3      
0x142880a2e:  cc                   int3      
0x142880a2f:  cc                   int3      
