; RakPeer vtable slot 37
; rva 0x28816c0
0x1428816c0:  4053                 push      rbx
0x1428816c2:  56                   push      rsi
0x1428816c3:  57                   push      rdi
0x1428816c4:  4155                 push      r13
0x1428816c6:  4157                 push      r15
0x1428816c8:  4883ec40             sub       rsp, 0x40
0x1428816cc:  418bf8               mov       edi, r8d
0x1428816cf:  4c8bea               mov       r13, rdx
0x1428816d2:  488bd9               mov       rbx, rcx
0x1428816d5:  e8e6860300           call      0x1428b9dc0
0x1428816da:  488db3a8040000       lea       rsi, [rbx + 0x4a8]
0x1428816e1:  448bf8               mov       r15d, eax
0x1428816e4:  488bce               mov       rcx, rsi
0x1428816e7:  e8c4202a03           call      0x145b237b0
0x1428816ec:  85c0                 test      eax, eax
0x1428816ee:  0f85b7020000         jne       0x1428819ab
0x1428816f4:  4c89a42480000000     mov       qword ptr [rsp + 0x80], r12
0x1428816fc:  488d542470           lea       rdx, [rsp + 0x70]
0x142881701:  4c8da3f8040000       lea       r12, [rbx + 0x4f8]
0x142881708:  4d8bc5               mov       r8, r13
0x14288170b:  498bcc               mov       rcx, r12
0x14288170e:  e8ad160200           call      0x1428a2dc0
0x142881713:  488b442470           mov       rax, qword ptr [rsp + 0x70]
0x142881718:  483b8300050000       cmp       rax, qword ptr [rbx + 0x500]
0x14288171f:  7433                 je        0x142881754
0x142881721:  85ff                 test      edi, edi
0x142881723:  7516                 jne       0x14288173b
0x142881725:  488b4830             mov       rcx, qword ptr [rax + 0x30]
0x142881729:  33d2                 xor       edx, edx
0x14288172b:  895120               mov       dword ptr [rcx + 0x20], edx
0x14288172e:  488bce               mov       rcx, rsi
0x142881731:  e8da202a03           call      0x145b23810
0x142881736:  e938020000           jmp       0x142881973
0x14288173b:  488b5030             mov       rdx, qword ptr [rax + 0x30]
0x14288173f:  458d043f             lea       r8d, [r15 + rdi]
0x142881743:  488bce               mov       rcx, rsi
0x142881746:  44894220             mov       dword ptr [rdx + 0x20], r8d
0x14288174a:  e8c1202a03           call      0x145b23810
0x14288174f:  e91f020000           jmp       0x142881973
0x142881754:  488bce               mov       rcx, rsi
0x142881757:  4c89b42488000000     mov       qword ptr [rsp + 0x88], r14
0x14288175f:  e8ac202a03           call      0x145b23810
0x142881764:  b928000000           mov       ecx, 0x28
0x142881769:  e892200c02           call      0x144943800
0x14288176e:  4c8bf0               mov       r14, rax
0x142881771:  4885c0               test      rax, rax
0x142881774:  0f8415020000         je        0x14288198f
0x14288177a:  33c0                 xor       eax, eax
0x14288177c:  48896c2478           mov       qword ptr [rsp + 0x78], rbp
0x142881781:  0f57c0               xorps     xmm0, xmm0
0x142881784:  33d2                 xor       edx, edx
0x142881786:  410f1106             movups    xmmword ptr [r14], xmm0
0x14288178a:  49894610             mov       qword ptr [r14 + 0x10], rax
0x14288178e:  85ff                 test      edi, edi
0x142881790:  41894618             mov       dword ptr [r14 + 0x18], eax
0x142881794:  b902000000           mov       ecx, 2
0x142881799:  6641890e             mov       word ptr [r14], cx
0x14288179d:  41c7461c0000ffff     mov       dword ptr [r14 + 0x1c], 0xffff0000
0x1428817a5:  41884624             mov       byte ptr [r14 + 0x24], al
0x1428817a9:  410f104500           movups    xmm0, xmmword ptr [r13]
0x1428817ae:  410f1106             movups    xmmword ptr [r14], xmm0
0x1428817b2:  f2410f104d10         movsd     xmm1, qword ptr [r13 + 0x10]
0x1428817b8:  f2410f114e10         movsd     qword ptr [r14 + 0x10], xmm1
0x1428817be:  418b4518             mov       eax, dword ptr [r13 + 0x18]
0x1428817c2:  41894618             mov       dword ptr [r14 + 0x18], eax
0x1428817c6:  410fb7451e           movzx     eax, word ptr [r13 + 0x1e]
0x1428817cb:  664189461e           mov       word ptr [r14 + 0x1e], ax
0x1428817d0:  410fb7451c           movzx     eax, word ptr [r13 + 0x1c]
0x1428817d5:  664189461c           mov       word ptr [r14 + 0x1c], ax
0x1428817da:  418d043f             lea       eax, [r15 + rdi]
0x1428817de:  0f45d0               cmovne    edx, eax
0x1428817e1:  41895620             mov       dword ptr [r14 + 0x20], edx
0x1428817e5:  410f104d00           movups    xmm1, xmmword ptr [r13]
0x1428817ea:  410f104510           movups    xmm0, xmmword ptr [r13 + 0x10]
0x1428817ef:  66490f7ecb           movq      r11, xmm1
0x1428817f4:  0f294c2420           movaps    xmmword ptr [rsp + 0x20], xmm1
0x1428817f9:  4c8b7c2428           mov       r15, qword ptr [rsp + 0x28]
0x1428817fe:  498bc3               mov       rax, r11
0x142881801:  48c1e810             shr       rax, 0x10
0x142881805:  663b053ee05605       cmp       ax, word ptr [rip + 0x556e03e]
0x14288180c:  0f29442430           movaps    xmmword ptr [rsp + 0x30], xmm0
0x142881811:  488b6c2430           mov       rbp, qword ptr [rsp + 0x30]
0x142881816:  753c                 jne       0x142881854
0x142881818:  66443b1d28e05605     cmp       r11w, word ptr [rip + 0x556e028]
0x142881820:  7532                 jne       0x142881854
0x142881822:  66443bd9             cmp       r11w, cx
0x142881826:  750f                 jne       0x142881837
0x142881828:  498bc3               mov       rax, r11
0x14288182b:  48c1e820             shr       rax, 0x20
0x14288182f:  3b0517e05605         cmp       eax, dword ptr [rip + 0x556e017]
0x142881835:  eb17                 jmp       0x14288184e
0x142881837:  664183fb17           cmp       r11w, 0x17
0x14288183c:  7516                 jne       0x142881854
0x14288183e:  4c3b3d0be05605       cmp       r15, qword ptr [rip + 0x556e00b]
0x142881845:  750d                 jne       0x142881854
0x142881847:  483b2d0ae05605       cmp       rbp, qword ptr [rip + 0x556e00a]
0x14288184e:  0f84e7000000         je        0x14288193b
0x142881854:  0fb78312010000       movzx     eax, word ptr [rbx + 0x112]
0x14288185b:  8bf8                 mov       edi, eax
0x14288185d:  6685c0               test      ax, ax
0x142881860:  7505                 jne       0x142881867
0x142881862:  bf01000000           mov       edi, 1
0x142881867:  448bc1               mov       r8d, ecx
0x14288186a:  8bd1                 mov       edx, ecx
0x14288186c:  488d4c2422           lea       rcx, [rsp + 0x22]
0x142881871:  e86a950300           call      0x1428bade0
0x142881876:  448bc0               mov       r8d, eax
0x142881879:  664183fb02           cmp       r11w, 2
0x14288187e:  740c                 je        0x14288188c
0x142881880:  ba10000000           mov       edx, 0x10
0x142881885:  488d4c2428           lea       rcx, [rsp + 0x28]
0x14288188a:  eb0a                 jmp       0x142881896
0x14288188c:  ba04000000           mov       edx, 4
0x142881891:  488d4c2424           lea       rcx, [rsp + 0x24]
0x142881896:  e845950300           call      0x1428bade0
0x14288189b:  33d2                 xor       edx, edx
0x14288189d:  8d0cfd00000000       lea       ecx, [rdi*8]
0x1428818a4:  f7f1                 div       ecx
0x1428818a6:  488b8380030000       mov       rax, qword ptr [rbx + 0x380]
0x1428818ad:  488b14d0             mov       rdx, qword ptr [rax + rdx*8]
0x1428818b1:  4885d2               test      rdx, rdx
0x1428818b4:  0f8481000000         je        0x14288193b
0x1428818ba:  4c8b8b50030000       mov       r9, qword ptr [rbx + 0x350]
0x1428818c1:  0fb75c2422           movzx     ebx, word ptr [rsp + 0x22]
0x1428818c6:  448b542424           mov       r10d, dword ptr [rsp + 0x24]
0x1428818cb:  0f1f440000           nop       dword ptr [rax + rax]
0x1428818d0:  448b02               mov       r8d, dword ptr [rdx]
0x1428818d3:  4969c0d8160000       imul      rax, r8, 0x16d8
0x1428818da:  6642395c0806         cmp       word ptr [rax + r9 + 6], bx
0x1428818e0:  752d                 jne       0x14288190f
0x1428818e2:  420fb74c0804         movzx     ecx, word ptr [rax + r9 + 4]
0x1428818e8:  66413bcb             cmp       cx, r11w
0x1428818ec:  7521                 jne       0x14288190f
0x1428818ee:  6683f902             cmp       cx, 2
0x1428818f2:  7507                 jne       0x1428818fb
0x1428818f4:  4639540808           cmp       dword ptr [rax + r9 + 8], r10d
0x1428818f9:  eb12                 jmp       0x14288190d
0x1428818fb:  6683f917             cmp       cx, 0x17
0x1428818ff:  750e                 jne       0x14288190f
0x142881901:  4e397c080c           cmp       qword ptr [rax + r9 + 0xc], r15
0x142881906:  7507                 jne       0x14288190f
0x142881908:  4a396c0814           cmp       qword ptr [rax + r9 + 0x14], rbp
0x14288190d:  740b                 je        0x14288191a
0x14288190f:  488b5208             mov       rdx, qword ptr [rdx + 8]
0x142881913:  4885d2               test      rdx, rdx
0x142881916:  75b8                 jne       0x1428818d0
0x142881918:  eb21                 jmp       0x14288193b
0x14288191a:  4183f8ff             cmp       r8d, -1
0x14288191e:  741b                 je        0x14288193b
0x142881920:  4969c0d8160000       imul      rax, r8, 0x16d8
0x142881927:  4903c1               add       rax, r9
0x14288192a:  740f                 je        0x14288193b
0x14288192c:  4883b88016000000     cmp       qword ptr [rax + 0x1680], 0
0x142881934:  0f95c0               setne     al
0x142881937:  41884624             mov       byte ptr [r14 + 0x24], al
0x14288193b:  488bce               mov       rcx, rsi
0x14288193e:  e86d1e2a03           call      0x145b237b0
0x142881943:  488b6c2478           mov       rbp, qword ptr [rsp + 0x78]
0x142881948:  85c0                 test      eax, eax
0x14288194a:  753b                 jne       0x142881987
0x14288194c:  4d8bc5               mov       r8, r13
0x14288194f:  488d542420           lea       rdx, [rsp + 0x20]
0x142881954:  498bcc               mov       rcx, r12
0x142881957:  e8d4220200           call      0x1428a3c30
0x14288195c:  488b08               mov       rcx, qword ptr [rax]
0x14288195f:  4c897130             mov       qword ptr [rcx + 0x30], r14
0x142881963:  488bce               mov       rcx, rsi
0x142881966:  e8a51e2a03           call      0x145b23810
0x14288196b:  4c8bb42488000000     mov       r14, qword ptr [rsp + 0x88]
0x142881973:  4c8ba42480000000     mov       r12, qword ptr [rsp + 0x80]
0x14288197b:  4883c440             add       rsp, 0x40
0x14288197f:  415f                 pop       r15
0x142881981:  415d                 pop       r13
0x142881983:  5f                   pop       rdi
0x142881984:  5e                   pop       rsi
0x142881985:  5b                   pop       rbx
0x142881986:  c3                   ret       
0x142881987:  8bc8                 mov       ecx, eax
0x142881989:  e8f2232a03           call      0x145b23d80
0x14288198e:  cc                   int3      
0x14288198f:  488d4c2420           lea       rcx, [rsp + 0x20]
0x142881994:  e85794f3fd           call      0x1407badf0
0x142881999:  488d15a0524805       lea       rdx, [rip + 0x54852a0]
0x1428819a0:  488d4c2420           lea       rcx, [rsp + 0x20]
0x1428819a5:  e8a6162c03           call      0x145b43050
0x1428819aa:  cc                   int3      
0x1428819ab:  8bc8                 mov       ecx, eax
0x1428819ad:  e8ce232a03           call      0x145b23d80
0x1428819b2:  cc                   int3      
0x1428819b3:  cc                   int3      
0x1428819b4:  cc                   int3      
0x1428819b5:  cc                   int3      
0x1428819b6:  cc                   int3      
0x1428819b7:  cc                   int3      
0x1428819b8:  cc                   int3      
0x1428819b9:  cc                   int3      
0x1428819ba:  cc                   int3      
0x1428819bb:  cc                   int3      
0x1428819bc:  cc                   int3      
0x1428819bd:  cc                   int3      
0x1428819be:  cc                   int3      
0x1428819bf:  cc                   int3      
0x1428819c0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x1428819c5:  48896c2410           mov       qword ptr [rsp + 0x10], rbp
0x1428819ca:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x1428819cf:  57                   push      rdi
0x1428819d0:  4883ec20             sub       rsp, 0x20
0x1428819d4:  488bf9               mov       rdi, rcx
0x1428819d7:  4883b90805000000     cmp       qword ptr [rcx + 0x508], 0
0x1428819df:  744d                 je        0x142881a2e
0x1428819e1:  4881c1a8040000       add       rcx, 0x4a8
0x1428819e8:  e8c31d2a03           call      0x145b237b0
0x1428819ed:  85c0                 test      eax, eax
0x1428819ef:  7552                 jne       0x142881a43
0x1428819f1:  488b8700050000       mov       rax, qword ptr [rdi + 0x500]
0x1428819f8:  488b18               mov       rbx, qword ptr [rax]
0x1428819fb:  483bd8               cmp       rbx, rax
0x1428819fe:  7416                 je        0x142881a16
0x142881a00:  488b4b30             mov       rcx, qword ptr [rbx + 0x30]
0x142881a04:  e8a7160c02           call      0x1449430b0
0x142881a09:  90                   nop       
0x142881a0a:  488b1b               mov       rbx, qword ptr [rbx]
0x142881a0d:  483b9f00050000       cmp       rbx, qword ptr [rdi + 0x500]
0x142881a14:  75ea                 jne       0x142881a00
0x142881a16:  488d8ff8040000       lea       rcx, [rdi + 0x4f8]
0x142881a1d:  e8cecb8dfe           call      0x14115e5f0
0x142881a22:  488d8fa8040000       lea       rcx, [rdi + 0x4a8]
0x142881a29:  e8e21d2a03           call      0x145b23810
0x142881a2e:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142881a33:  488b6c2438           mov       rbp, qword ptr [rsp + 0x38]
0x142881a38:  488b742440           mov       rsi, qword ptr [rsp + 0x40]
0x142881a3d:  4883c420             add       rsp, 0x20
0x142881a41:  5f                   pop       rdi
0x142881a42:  c3                   ret       
0x142881a43:  8bc8                 mov       ecx, eax
0x142881a45:  e836232a03           call      0x145b23d80
0x142881a4a:  cc                   int3      
0x142881a4b:  cc                   int3      
0x142881a4c:  cc                   int3      
0x142881a4d:  cc                   int3      
0x142881a4e:  cc                   int3      
0x142881a4f:  cc                   int3      
0x142881a50:  8891b80b0000         mov       byte ptr [rcx + 0xbb8], dl
0x142881a56:  c3                   ret       
0x142881a57:  cc                   int3      
0x142881a58:  cc                   int3      
0x142881a59:  cc                   int3      
0x142881a5a:  cc                   int3      
0x142881a5b:  cc                   int3      
0x142881a5c:  cc                   int3      
0x142881a5d:  cc                   int3      
0x142881a5e:  cc                   int3      
0x142881a5f:  cc                   int3      
0x142881a60:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x142881a65:  56                   push      rsi
0x142881a66:  4883ec20             sub       rsp, 0x20
0x142881a6a:  4883b90805000000     cmp       qword ptr [rcx + 0x508], 0
0x142881a72:  488bf2               mov       rsi, rdx
0x142881a75:  488bd9               mov       rbx, rcx
0x142881a78:  750d                 jne       0x142881a87
0x142881a7a:  32c0                 xor       al, al
0x142881a7c:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x142881a81:  4883c420             add       rsp, 0x20
0x142881a85:  5e                   pop       rsi
0x142881a86:  c3                   ret       
0x142881a87:  4881c1a8040000       add       rcx, 0x4a8
0x142881a8e:  48897c2438           mov       qword ptr [rsp + 0x38], rdi
0x142881a93:  e8181d2a03           call      0x145b237b0
0x142881a98:  85c0                 test      eax, eax
0x142881a9a:  753f                 jne       0x142881adb
0x142881a9c:  488d8bf8040000       lea       rcx, [rbx + 0x4f8]
0x142881aa3:  4c8bc6               mov       r8, rsi
0x142881aa6:  488d542430           lea       rdx, [rsp + 0x30]
0x142881aab:  e810130200           call      0x1428a2dc0
0x142881ab0:  488d8ba8040000       lea       rcx, [rbx + 0x4a8]
0x142881ab7:  e8541d2a03           call      0x145b23810
0x142881abc:  488b8300050000       mov       rax, qword ptr [rbx + 0x500]
0x142881ac3:  4839442430           cmp       qword ptr [rsp + 0x30], rax
0x142881ac8:  488b7c2438           mov       rdi, qword ptr [rsp + 0x38]
0x142881acd:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x142881ad2:  0f95c0               setne     al
0x142881ad5:  4883c420             add       rsp, 0x20
0x142881ad9:  5e                   pop       rsi
0x142881ada:  c3                   ret       
0x142881adb:  8bc8                 mov       ecx, eax
0x142881add:  e89e222a03           call      0x145b23d80
0x142881ae2:  cc                   int3      
0x142881ae3:  cc                   int3      
0x142881ae4:  cc                   int3      
0x142881ae5:  cc                   int3      
0x142881ae6:  cc                   int3      
0x142881ae7:  cc                   int3      
0x142881ae8:  cc                   int3      
0x142881ae9:  cc                   int3      
0x142881aea:  cc                   int3      
0x142881aeb:  cc                   int3      
0x142881aec:  cc                   int3      
0x142881aed:  cc                   int3      
0x142881aee:  cc                   int3      
0x142881aef:  cc                   int3      
