; lambda5653 vtable slot 5 rva 0x7ed570
0x1407ed570:  488d4108             lea       rax, [rcx + 8]
0x1407ed574:  c3                   ret       
0x1407ed575:  cc                   int3      
0x1407ed576:  cc                   int3      
0x1407ed577:  cc                   int3      
0x1407ed578:  cc                   int3      
0x1407ed579:  cc                   int3      
0x1407ed57a:  cc                   int3      
0x1407ed57b:  cc                   int3      
0x1407ed57c:  cc                   int3      
0x1407ed57d:  cc                   int3      
0x1407ed57e:  cc                   int3      
0x1407ed57f:  cc                   int3      
