; RakPeer vtable slot 26
; rva 0x28794d0
0x1428794d0:  899178030000         mov       dword ptr [rcx + 0x378], edx
0x1428794d6:  c3                   ret       
0x1428794d7:  cc                   int3      
0x1428794d8:  cc                   int3      
0x1428794d9:  cc                   int3      
0x1428794da:  cc                   int3      
0x1428794db:  cc                   int3      
0x1428794dc:  cc                   int3      
0x1428794dd:  cc                   int3      
0x1428794de:  cc                   int3      
0x1428794df:  cc                   int3      
