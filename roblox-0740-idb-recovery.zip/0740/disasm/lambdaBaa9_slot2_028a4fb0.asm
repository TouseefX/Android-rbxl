; lambdaBaa9 vtable slot 2 rva 0x28a4fb0
0x1428a4fb0:  4883ec38             sub       rsp, 0x38
0x1428a4fb4:  c60202               mov       byte ptr [rdx], 2
0x1428a4fb7:  4c8b4910             mov       r9, qword ptr [rcx + 0x10]
0x1428a4fbb:  4180b97c16000000     cmp       byte ptr [r9 + 0x167c], 0
0x1428a4fc3:  7409                 je        0x1428a4fce
0x1428a4fc5:  458b9978160000       mov       r11d, dword ptr [r9 + 0x1678]
0x1428a4fcc:  eb03                 jmp       0x1428a4fd1
0x1428a4fce:  4533db               xor       r11d, r11d
0x1428a4fd1:  450fb69171160000     movzx     r10d, byte ptr [r9 + 0x1671]
0x1428a4fd9:  4d8d4104             lea       r8, [r9 + 4]
0x1428a4fdd:  488b4908             mov       rcx, qword ptr [rcx + 8]
0x1428a4fe1:  48ffc2               inc       rdx
0x1428a4fe4:  458bcb               mov       r9d, r11d
0x1428a4fe7:  4488542420           mov       byte ptr [rsp + 0x20], r10b
0x1428a4fec:  488b01               mov       rax, qword ptr [rcx]
0x1428a4fef:  488b8040030000       mov       rax, qword ptr [rax + 0x340]
0x1428a4ff6:  ff153cad8903         call      qword ptr [rip + 0x389ad3c]
0x1428a4ffc:  4883c438             add       rsp, 0x38
0x1428a5000:  c3                   ret       
0x1428a5001:  cc                   int3      
0x1428a5002:  cc                   int3      
0x1428a5003:  cc                   int3      
0x1428a5004:  cc                   int3      
0x1428a5005:  cc                   int3      
0x1428a5006:  cc                   int3      
0x1428a5007:  cc                   int3      
0x1428a5008:  cc                   int3      
0x1428a5009:  cc                   int3      
0x1428a500a:  cc                   int3      
0x1428a500b:  cc                   int3      
0x1428a500c:  cc                   int3      
0x1428a500d:  cc                   int3      
0x1428a500e:  cc                   int3      
0x1428a500f:  cc                   int3      
