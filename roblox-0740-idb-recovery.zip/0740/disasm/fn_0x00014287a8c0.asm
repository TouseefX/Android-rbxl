; function_of: vtab.RakPeer
; xref site 0x14287aed6 -> vtab.RakPeer @ 0x146ca34f0
; range 0x14287a8c0 .. 0x14287bbb0  (4848 bytes)

0x00014287a8c0:  4053                  push      rbx
0x00014287a8c2:  55                    push      rbp
0x00014287a8c3:  56                    push      rsi
0x00014287a8c4:  4154                  push      r12
0x00014287a8c6:  4156                  push      r14
0x00014287a8c8:  4881ec90080000        sub       rsp, 0x890
0x00014287a8cf:  488b051a8e4905        mov       rax, qword ptr [rip + 0x5498e1a]
0x00014287a8d6:  4833c4                xor       rax, rsp
0x00014287a8d9:  4889842470080000      mov       qword ptr [rsp + 0x870], rax
0x00014287a8e1:  410fb600              movzx     eax, byte ptr [r8]
0x00014287a8e5:  418bd9                mov       ebx, r9d
0x00014287a8e8:  4c8ba424e0080000      mov       r12, qword ptr [rsp + 0x8e0]
0x00014287a8f0:  ffc8                  dec       eax
0x00014287a8f2:  4d8bf0                mov       r14, r8
0x00014287a8f5:  488bea                mov       rbp, rdx
0x00014287a8f8:  4c8bd1                mov       r10, rcx
0x00014287a8fb:  83f87d                cmp       eax, 0x7d
0x00014287a8fe:  7745                  ja        0x14287a945
0x00014287a900:  488d15f95678fd        lea       rdx, [rip - 0x287a907]
0x00014287a907:  4898                  cdqe      
0x00014287a909:  0fb6840210ab8702      movzx     eax, byte ptr [rdx + rax + 0x287ab10]
0x00014287a911:  8b8c8200ab8702        mov       ecx, dword ptr [rdx + rax*4 + 0x287ab00]
0x00014287a918:  4803ca                add       rcx, rdx
0x00014287a91b:  ffe1                  jmp       rcx
0x00014287a91d:  803de4c8a40500        cmp       byte ptr [rip + 0x5a4c8e4], 0
0x00014287a924:  0f84ae010000          je        0x14287aad8
0x00014287a92a:  488d358bd86b04        lea       rsi, [rip + 0x46bd88b]
0x00014287a931:  eb19                  jmp       0x14287a94c
0x00014287a933:  488d35bee56804        lea       rsi, [rip + 0x468e5be]
0x00014287a93a:  eb10                  jmp       0x14287a94c
0x00014287a93c:  488d35455f5704        lea       rsi, [rip + 0x4575f45]
0x00014287a943:  eb07                  jmp       0x14287a94c
0x00014287a945:  488d3544fb5a04        lea       rsi, [rip + 0x45afb44]
0x00014287a94c:  4889bc2488080000      mov       qword ptr [rsp + 0x888], rdi
0x00014287a954:  4c8d842470020000      lea       r8, [rsp + 0x270]
0x00014287a95c:  41b900020000          mov       r9d, 0x200
0x00014287a962:  4c89bc2480080000      mov       qword ptr [rsp + 0x880], r15
0x00014287a96a:  b201                  mov       dl, 1
0x00014287a96c:  498bca                mov       rcx, r10
0x00014287a96f:  e82cad0200            call      0x1428a56a0
0x00014287a974:  33ff                  xor       edi, edi
0x00014287a976:  8d53ff                lea       edx, [rbx - 1]
0x00014287a979:  b9cc000000            mov       ecx, 0xcc
0x00014287a97e:  390dfc024f05          cmp       dword ptr [rip + 0x54f02fc], ecx
0x00014287a984:  0f4c0df5024f05        cmovl     ecx, dword ptr [rip + 0x54f02f5]
0x00014287a98b:  3bd1                  cmp       edx, ecx
0x00014287a98d:  0f4cca                cmovl     ecx, edx
0x00014287a990:  4c63f9                movsxd    r15, ecx
0x00014287a993:  4983ff01              cmp       r15, 1
0x00014287a997:  7c38                  jl        0x14287a9d1
0x00014287a999:  bb01000000            mov       ebx, 1
0x00014287a99e:  6690                  nop       
0x00014287a9a0:  460fb60c33            movzx     r9d, byte ptr [rbx + r14]
0x00014287a9a5:  488d8c2470040000      lea       rcx, [rsp + 0x470]
0x00014287a9ad:  4863c7                movsxd    rax, edi
0x00014287a9b0:  4c8d05a1d76b04        lea       r8, [rip + 0x46bd7a1]
0x00014287a9b7:  ba00040000            mov       edx, 0x400
0x00014287a9bc:  4803c8                add       rcx, rax
0x00014287a9bf:  482bd0                sub       rdx, rax
0x00014287a9c2:  e8192d22fe            call      0x140a9d6e0
0x00014287a9c7:  03f8                  add       edi, eax
0x00014287a9c9:  48ffc3                inc       rbx
0x00014287a9cc:  493bdf                cmp       rbx, r15
0x00014287a9cf:  7ecf                  jle       0x14287a9a0
0x00014287a9d1:  4c8bbc2480080000      mov       r15, qword ptr [rsp + 0x880]
0x00014287a9d9:  4863c7                movsxd    rax, edi
0x00014287a9dc:  488bbc2488080000      mov       rdi, qword ptr [rsp + 0x888]
0x00014287a9e4:  483d00040000          cmp       rax, 0x400
0x00014287a9ea:  0f8307010000          jae       0x14287aaf7
0x00014287a9f0:  33c9                  xor       ecx, ecx
0x00014287a9f2:  c684047004000000      mov       byte ptr [rsp + rax + 0x470], 0
0x00014287a9fa:  ff15384e8c03          call      qword ptr [rip + 0x38c4e38]
0x00014287aa00:  33c0                  xor       eax, eax
0x00014287aa02:  c744246c0000ffff      mov       dword ptr [rsp + 0x6c], 0xffff0000
0x00014287aa0a:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x00014287aa0f:  0f57c0                xorps     xmm0, xmm0
0x00014287aa12:  89442468              mov       dword ptr [rsp + 0x68], eax
0x00014287aa16:  b802000000            mov       eax, 2
0x00014287aa1b:  0f11442450            movups    xmmword ptr [rsp + 0x50], xmm0
0x00014287aa20:  6689442450            mov       word ptr [rsp + 0x50], ax
0x00014287aa25:  0fb7442452            movzx     eax, word ptr [rsp + 0x52]
0x00014287aa2a:  66394502              cmp       word ptr [rbp + 2], ax
0x00014287aa2e:  7517                  jne       0x14287aa47
0x00014287aa30:  66837d0002            cmp       word ptr [rbp], 2
0x00014287aa35:  7510                  jne       0x14287aa47
0x00014287aa37:  8b442454              mov       eax, dword ptr [rsp + 0x54]
0x00014287aa3b:  394504                cmp       dword ptr [rbp + 4], eax
0x00014287aa3e:  7507                  jne       0x14287aa47
0x00014287aa40:  c644247000            mov       byte ptr [rsp + 0x70], 0
0x00014287aa45:  eb15                  jmp       0x14287aa5c
0x00014287aa47:  41b900020000          mov       r9d, 0x200
0x00014287aa4d:  4c8d442470            lea       r8, [rsp + 0x70]
0x00014287aa52:  b201                  mov       dl, 1
0x00014287aa54:  488bcd                mov       rcx, rbp
0x00014287aa57:  e844ac0200            call      0x1428a56a0
0x00014287aa5c:  488b05fd014f05        mov       rax, qword ptr [rip + 0x54f01fd]
0x00014287aa63:  3c06                  cmp       al, 6
0x00014287aa65:  7271                  jb        0x14287aad8
0x00014287aa67:  48c1e808              shr       rax, 8
0x00014287aa6b:  3c03                  cmp       al, 3
0x00014287aa6d:  7269                  jb        0x14287aad8
0x00014287aa6f:  0fb68c24e8080000      movzx     ecx, byte ptr [rsp + 0x8e8]
0x00014287aa77:  488d0563ab9704        lea       rax, [rip + 0x497ab63]
0x00014287aa7e:  4889442450            mov       qword ptr [rsp + 0x50], rax
0x00014287aa83:  4c8d842470040000      lea       r8, [rsp + 0x470]
0x00014287aa8b:  488b542450            mov       rdx, qword ptr [rsp + 0x50]
0x00014287aa90:  4c8d8c2470020000      lea       r9, [rsp + 0x270]
0x00014287aa98:  410fb606              movzx     eax, byte ptr [r14]
0x00014287aa9c:  488d15bdd66b04        lea       rdx, [rip + 0x46bd6bd]
0x00014287aaa3:  0f1005b6014f05        movups    xmm0, xmmword ptr [rip + 0x54f01b6]
0x00014287aaaa:  4c89442440            mov       qword ptr [rsp + 0x40], r8
0x00014287aaaf:  4d8bc4                mov       r8, r12
0x00014287aab2:  89442438              mov       dword ptr [rsp + 0x38], eax
0x00014287aab6:  488d442470            lea       rax, [rsp + 0x70]
0x00014287aabb:  894c2430              mov       dword ptr [rsp + 0x30], ecx
0x00014287aabf:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014287aac4:  4889742428            mov       qword ptr [rsp + 0x28], rsi
0x00014287aac9:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014287aace:  0f29442450            movaps    xmmword ptr [rsp + 0x50], xmm0
0x00014287aad3:  e8b84d0e02            call      0x14495f890
0x00014287aad8:  488b8c2470080000      mov       rcx, qword ptr [rsp + 0x870]
0x00014287aae0:  4833cc                xor       rcx, rsp
0x00014287aae3:  e8f86a2a03            call      0x145b215e0
0x00014287aae8:  4881c490080000        add       rsp, 0x890
0x00014287aaef:  415e                  pop       r14
0x00014287aaf1:  415c                  pop       r12
0x00014287aaf3:  5e                    pop       rsi
0x00014287aaf4:  5d                    pop       rbp
0x00014287aaf5:  5b                    pop       rbx
0x00014287aaf6:  c3                    ret       
0x00014287aaf7:  e8b41c0c02            call      0x14493c7b0
0x00014287aafc:  cc                    int3      
0x00014287aafd:  0f1f00                nop       dword ptr [rax]
0x00014287ab00:  1da987023c            sbb       eax, 0x3c0287a9
0x00014287ab05:  a9870233a9            test      eax, 0xa9330287
0x00014287ab0a:  8702                  xchg      dword ptr [rdx], eax
0x00014287ab0c:  45a987020000          test      eax, 0x287
0x00014287ab12:  0303                  add       eax, dword ptr [rbx]
0x00014287ab14:  0000                  add       byte ptr [rax], al
0x00014287ab16:  0000                  add       byte ptr [rax], al
0x00014287ab18:  0303                  add       eax, dword ptr [rbx]
0x00014287ab1a:  0103                  add       dword ptr [rbx], eax
0x00014287ab1c:  0103                  add       dword ptr [rbx], eax
0x00014287ab1e:  0303                  add       eax, dword ptr [rbx]
0x00014287ab20:  0101                  add       dword ptr [rcx], eax
0x00014287ab22:  0301                  add       eax, dword ptr [rcx]
0x00014287ab24:  0303                  add       eax, dword ptr [rbx]
0x00014287ab26:  0101                  add       dword ptr [rcx], eax
0x00014287ab28:  0101                  add       dword ptr [rcx], eax
0x00014287ab2a:  0300                  add       eax, dword ptr [rax]
0x00014287ab2c:  0303                  add       eax, dword ptr [rbx]
0x00014287ab2e:  0303                  add       eax, dword ptr [rbx]
0x00014287ab30:  0303                  add       eax, dword ptr [rbx]
0x00014287ab32:  0303                  add       eax, dword ptr [rbx]
0x00014287ab34:  0303                  add       eax, dword ptr [rbx]
0x00014287ab36:  0303                  add       eax, dword ptr [rbx]
0x00014287ab38:  0303                  add       eax, dword ptr [rbx]
0x00014287ab3a:  0303                  add       eax, dword ptr [rbx]
0x00014287ab3c:  0303                  add       eax, dword ptr [rbx]
0x00014287ab3e:  0303                  add       eax, dword ptr [rbx]
0x00014287ab40:  0303                  add       eax, dword ptr [rbx]
0x00014287ab42:  0303                  add       eax, dword ptr [rbx]
0x00014287ab44:  0303                  add       eax, dword ptr [rbx]
0x00014287ab46:  0303                  add       eax, dword ptr [rbx]
0x00014287ab48:  0303                  add       eax, dword ptr [rbx]
0x00014287ab4a:  0303                  add       eax, dword ptr [rbx]
0x00014287ab4c:  0303                  add       eax, dword ptr [rbx]
0x00014287ab4e:  0303                  add       eax, dword ptr [rbx]
0x00014287ab50:  0303                  add       eax, dword ptr [rbx]
0x00014287ab52:  0303                  add       eax, dword ptr [rbx]
0x00014287ab54:  0303                  add       eax, dword ptr [rbx]
0x00014287ab56:  0303                  add       eax, dword ptr [rbx]
0x00014287ab58:  0303                  add       eax, dword ptr [rbx]
0x00014287ab5a:  0303                  add       eax, dword ptr [rbx]
0x00014287ab5c:  0303                  add       eax, dword ptr [rbx]
0x00014287ab5e:  0303                  add       eax, dword ptr [rbx]
0x00014287ab60:  0303                  add       eax, dword ptr [rbx]
0x00014287ab62:  0303                  add       eax, dword ptr [rbx]
0x00014287ab64:  0303                  add       eax, dword ptr [rbx]
0x00014287ab66:  0303                  add       eax, dword ptr [rbx]
0x00014287ab68:  0303                  add       eax, dword ptr [rbx]
0x00014287ab6a:  0303                  add       eax, dword ptr [rbx]
0x00014287ab6c:  0303                  add       eax, dword ptr [rbx]
0x00014287ab6e:  0303                  add       eax, dword ptr [rbx]
0x00014287ab70:  0303                  add       eax, dword ptr [rbx]
0x00014287ab72:  0303                  add       eax, dword ptr [rbx]
0x00014287ab74:  0303                  add       eax, dword ptr [rbx]
0x00014287ab76:  0303                  add       eax, dword ptr [rbx]
0x00014287ab78:  0303                  add       eax, dword ptr [rbx]
0x00014287ab7a:  0303                  add       eax, dword ptr [rbx]
0x00014287ab7c:  0303                  add       eax, dword ptr [rbx]
0x00014287ab7e:  0303                  add       eax, dword ptr [rbx]
0x00014287ab80:  0303                  add       eax, dword ptr [rbx]
0x00014287ab82:  0303                  add       eax, dword ptr [rbx]
0x00014287ab84:  0303                  add       eax, dword ptr [rbx]
0x00014287ab86:  0302                  add       eax, dword ptr [rdx]
0x00014287ab88:  0303                  add       eax, dword ptr [rbx]
0x00014287ab8a:  0203                  add       al, byte ptr [rbx]
0x00014287ab8c:  0202                  add       al, byte ptr [rdx]
0x00014287ab8e:  cc                    int3      
0x00014287ab8f:  cc                    int3      
0x00014287ab90:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014287ab95:  48896c2410            mov       qword ptr [rsp + 0x10], rbp
0x00014287ab9a:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x00014287ab9f:  4c89442418            mov       qword ptr [rsp + 0x18], r8
0x00014287aba4:  57                    push      rdi
0x00014287aba5:  4883ec20              sub       rsp, 0x20
0x00014287aba9:  8bf2                  mov       esi, edx
0x00014287abab:  488bd9                mov       rbx, rcx
0x00014287abae:  c644244400            mov       byte ptr [rsp + 0x44], 0
0x00014287abb3:  33ed                  xor       ebp, ebp
0x00014287abb5:  40382d3cc4a405        cmp       byte ptr [rip + 0x5a4c43c], bpl
0x00014287abbc:  743f                  je        0x14287abfd
0x00014287abbe:  448b0d03bba405        mov       r9d, dword ptr [rip + 0x5a4bb03]
0x00014287abc5:  4181f900040000        cmp       r9d, 0x400
0x00014287abcc:  721a                  jb        0x14287abe8
0x00014287abce:  40382dbef59805        cmp       byte ptr [rip + 0x598f5be], bpl
0x00014287abd5:  740d                  je        0x14287abe4
0x00014287abd7:  40382d6a39d505        cmp       byte ptr [rip + 0x5d5396a], bpl
0x00014287abde:  0f8527010000          jne       0x14287ad0b
0x00014287abe4:  8bcd                  mov       ecx, ebp
0x00014287abe6:  eb0c                  jmp       0x14287abf4
0x00014287abe8:  e823b70d02            call      0x144956310
0x00014287abed:  8b4808                mov       ecx, dword ptr [rax + 8]
0x00014287abf0:  44894808              mov       dword ptr [rax + 8], r9d
0x00014287abf4:  894c2440              mov       dword ptr [rsp + 0x40], ecx
0x00014287abf8:  c644244401            mov       byte ptr [rsp + 0x44], 1
0x00014287abfd:  488dbbc00b0000        lea       rdi, [rbx + 0xbc0]
0x00014287ac04:  488bcf                mov       rcx, rdi
0x00014287ac07:  e8a48b2a03            call      0x145b237b0
0x00014287ac0c:  85c0                  test      eax, eax
0x00014287ac0e:  0f85e0000000          jne       0x14287acf4
0x00014287ac14:  488d8b100c0000        lea       rcx, [rbx + 0xc10]
0x00014287ac1b:  e8f07c0200            call      0x1428a2910
0x00014287ac20:  488bd8                mov       rbx, rax
0x00014287ac23:  488bcf                mov       rcx, rdi
0x00014287ac26:  e8e58b2a03            call      0x145b23810
0x00014287ac2b:  0f57c0                xorps     xmm0, xmm0
0x00014287ac2e:  33c0                  xor       eax, eax
0x00014287ac30:  0f1103                movups    xmmword ptr [rbx], xmm0
0x00014287ac33:  48894310              mov       qword ptr [rbx + 0x10], rax
0x00014287ac37:  894318                mov       dword ptr [rbx + 0x18], eax
0x00014287ac3a:  b802000000            mov       eax, 2
0x00014287ac3f:  668903                mov       word ptr [rbx], ax
0x00014287ac42:  b8ffff0000            mov       eax, 0xffff
0x00014287ac47:  c7431c0000ffff        mov       dword ptr [rbx + 0x1c], 0xffff0000
0x00014287ac4e:  66894328              mov       word ptr [rbx + 0x28], ax
0x00014287ac52:  488b050f4c5705        mov       rax, qword ptr [rip + 0x5574c0f]
0x00014287ac59:  48894320              mov       qword ptr [rbx + 0x20], rax
0x00014287ac5d:  0fb7050c4c5705        movzx     eax, word ptr [rip + 0x5574c0c]
0x00014287ac64:  66894328              mov       word ptr [rbx + 0x28], ax
0x00014287ac68:  896b58                mov       dword ptr [rbx + 0x58], ebp
0x00014287ac6b:  48896b60              mov       qword ptr [rbx + 0x60], rbp
0x00014287ac6f:  488bce                mov       rcx, rsi
0x00014287ac72:  e8298d0c02            call      0x1449439a0
0x00014287ac77:  48894338              mov       qword ptr [rbx + 0x38], rax
0x00014287ac7b:  897330                mov       dword ptr [rbx + 0x30], esi
0x00014287ac7e:  8d04f500000000        lea       eax, [rsi*8]
0x00014287ac85:  894334                mov       dword ptr [rbx + 0x34], eax
0x00014287ac88:  c6434001              mov       byte ptr [rbx + 0x40], 1
0x00014287ac8c:  488b05d54b5705        mov       rax, qword ptr [rip + 0x5574bd5]
0x00014287ac93:  48894320              mov       qword ptr [rbx + 0x20], rax
0x00014287ac97:  0fb705d24b5705        movzx     eax, word ptr [rip + 0x5574bd2]
0x00014287ac9e:  66894328              mov       word ptr [rbx + 0x28], ax
0x00014287aca2:  40886b41              mov       byte ptr [rbx + 0x41], bpl
0x00014287aca6:  48896b60              mov       qword ptr [rbx + 0x60], rbp
0x00014287acaa:  807c244400            cmp       byte ptr [rsp + 0x44], 0
0x00014287acaf:  742b                  je        0x14287acdc
0x00014287acb1:  448b4c2440            mov       r9d, dword ptr [rsp + 0x40]
0x00014287acb6:  4181f900040000        cmp       r9d, 0x400
0x00014287acbd:  7214                  jb        0x14287acd3
0x00014287acbf:  803dcdf4980500        cmp       byte ptr [rip + 0x598f4cd], 0
0x00014287acc6:  7414                  je        0x14287acdc
0x00014287acc8:  803d7938d50500        cmp       byte ptr [rip + 0x5d53879], 0
0x00014287accf:  752b                  jne       0x14287acfc
0x00014287acd1:  eb09                  jmp       0x14287acdc
0x00014287acd3:  e838b60d02            call      0x144956310
0x00014287acd8:  44894808              mov       dword ptr [rax + 8], r9d
0x00014287acdc:  488bc3                mov       rax, rbx
0x00014287acdf:  488b5c2430            mov       rbx, qword ptr [rsp + 0x30]
0x00014287ace4:  488b6c2438            mov       rbp, qword ptr [rsp + 0x38]
0x00014287ace9:  488b742448            mov       rsi, qword ptr [rsp + 0x48]
0x00014287acee:  4883c420              add       rsp, 0x20
0x00014287acf2:  5f                    pop       rdi
0x00014287acf3:  c3                    ret       
0x00014287acf4:  8bc8                  mov       ecx, eax
0x00014287acf6:  e885902a03            call      0x145b23d80
0x00014287acfb:  90                    nop       
0x00014287acfc:  488d15dda08504        lea       rdx, [rip + 0x485a0dd]
0x00014287ad03:  33c9                  xor       ecx, ecx
0x00014287ad05:  e8763f0e02            call      0x14495ec80
0x00014287ad0a:  90                    nop       
0x00014287ad0b:  488d15cea08504        lea       rdx, [rip + 0x485a0ce]
0x00014287ad12:  33c9                  xor       ecx, ecx
0x00014287ad14:  e8673f0e02            call      0x14495ec80
0x00014287ad19:  cc                    int3      
0x00014287ad1a:  cc                    int3      
0x00014287ad1b:  cc                    int3      
0x00014287ad1c:  cc                    int3      
0x00014287ad1d:  cc                    int3      
0x00014287ad1e:  cc                    int3      
0x00014287ad1f:  cc                    int3      
0x00014287ad20:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014287ad25:  48896c2410            mov       qword ptr [rsp + 0x10], rbp
0x00014287ad2a:  4c894c2420            mov       qword ptr [rsp + 0x20], r9
0x00014287ad2f:  56                    push      rsi
0x00014287ad30:  57                    push      rdi
0x00014287ad31:  4156                  push      r14
0x00014287ad33:  4883ec20              sub       rsp, 0x20
0x00014287ad37:  498be8                mov       rbp, r8
0x00014287ad3a:  8bf2                  mov       esi, edx
0x00014287ad3c:  488bd9                mov       rbx, rcx
0x00014287ad3f:  c644245c00            mov       byte ptr [rsp + 0x5c], 0
0x00014287ad44:  4533f6                xor       r14d, r14d
0x00014287ad47:  443835aac2a405        cmp       byte ptr [rip + 0x5a4c2aa], r14b
0x00014287ad4e:  7440                  je        0x14287ad90
0x00014287ad50:  448b0d71b9a405        mov       r9d, dword ptr [rip + 0x5a4b971]
0x00014287ad57:  4181f900040000        cmp       r9d, 0x400
0x00014287ad5e:  721b                  jb        0x14287ad7b
0x00014287ad60:  4438352cf49805        cmp       byte ptr [rip + 0x598f42c], r14b
0x00014287ad67:  740d                  je        0x14287ad76
0x00014287ad69:  443835d837d505        cmp       byte ptr [rip + 0x5d537d8], r14b
0x00014287ad70:  0f851b010000          jne       0x14287ae91
0x00014287ad76:  418bce                mov       ecx, r14d
0x00014287ad79:  eb0c                  jmp       0x14287ad87
0x00014287ad7b:  e890b50d02            call      0x144956310
0x00014287ad80:  8b4808                mov       ecx, dword ptr [rax + 8]
0x00014287ad83:  44894808              mov       dword ptr [rax + 8], r9d
0x00014287ad87:  894c2458              mov       dword ptr [rsp + 0x58], ecx
0x00014287ad8b:  c644245c01            mov       byte ptr [rsp + 0x5c], 1
0x00014287ad90:  488dbbc00b0000        lea       rdi, [rbx + 0xbc0]
0x00014287ad97:  488bcf                mov       rcx, rdi
0x00014287ad9a:  e8118a2a03            call      0x145b237b0
0x00014287ad9f:  85c0                  test      eax, eax
0x00014287ada1:  0f85d3000000          jne       0x14287ae7a
0x00014287ada7:  488d8b100c0000        lea       rcx, [rbx + 0xc10]
0x00014287adae:  e85d7b0200            call      0x1428a2910
0x00014287adb3:  488bd8                mov       rbx, rax
0x00014287adb6:  488bcf                mov       rcx, rdi
0x00014287adb9:  e8528a2a03            call      0x145b23810
0x00014287adbe:  0f57c0                xorps     xmm0, xmm0
0x00014287adc1:  33c0                  xor       eax, eax
0x00014287adc3:  0f1103                movups    xmmword ptr [rbx], xmm0
0x00014287adc6:  48894310              mov       qword ptr [rbx + 0x10], rax
0x00014287adca:  894318                mov       dword ptr [rbx + 0x18], eax
0x00014287adcd:  b802000000            mov       eax, 2
0x00014287add2:  668903                mov       word ptr [rbx], ax
0x00014287add5:  b8ffff0000            mov       eax, 0xffff
0x00014287adda:  c7431c0000ffff        mov       dword ptr [rbx + 0x1c], 0xffff0000
0x00014287ade1:  66894328              mov       word ptr [rbx + 0x28], ax
0x00014287ade5:  488b057c4a5705        mov       rax, qword ptr [rip + 0x5574a7c]
0x00014287adec:  48894320              mov       qword ptr [rbx + 0x20], rax
0x00014287adf0:  0fb705794a5705        movzx     eax, word ptr [rip + 0x5574a79]
0x00014287adf7:  66894328              mov       word ptr [rbx + 0x28], ax
0x00014287adfb:  44897358              mov       dword ptr [rbx + 0x58], r14d
0x00014287adff:  4c897360              mov       qword ptr [rbx + 0x60], r14
0x00014287ae03:  48896b38              mov       qword ptr [rbx + 0x38], rbp
0x00014287ae07:  897330                mov       dword ptr [rbx + 0x30], esi
0x00014287ae0a:  8d04f500000000        lea       eax, [rsi*8]
0x00014287ae11:  894334                mov       dword ptr [rbx + 0x34], eax
0x00014287ae14:  c6434001              mov       byte ptr [rbx + 0x40], 1
0x00014287ae18:  488b05494a5705        mov       rax, qword ptr [rip + 0x5574a49]
0x00014287ae1f:  48894320              mov       qword ptr [rbx + 0x20], rax
0x00014287ae23:  0fb705464a5705        movzx     eax, word ptr [rip + 0x5574a46]
0x00014287ae2a:  66894328              mov       word ptr [rbx + 0x28], ax
0x00014287ae2e:  44887341              mov       byte ptr [rbx + 0x41], r14b
0x00014287ae32:  807c245c00            cmp       byte ptr [rsp + 0x5c], 0
0x00014287ae37:  742b                  je        0x14287ae64
0x00014287ae39:  448b4c2458            mov       r9d, dword ptr [rsp + 0x58]
0x00014287ae3e:  4181f900040000        cmp       r9d, 0x400
0x00014287ae45:  7214                  jb        0x14287ae5b
0x00014287ae47:  803d45f3980500        cmp       byte ptr [rip + 0x598f345], 0
0x00014287ae4e:  7414                  je        0x14287ae64
0x00014287ae50:  803df136d50500        cmp       byte ptr [rip + 0x5d536f1], 0
0x00014287ae57:  7529                  jne       0x14287ae82
0x00014287ae59:  eb09                  jmp       0x14287ae64
0x00014287ae5b:  e8b0b40d02            call      0x144956310
0x00014287ae60:  44894808              mov       dword ptr [rax + 8], r9d
0x00014287ae64:  488bc3                mov       rax, rbx
0x00014287ae67:  488b5c2440            mov       rbx, qword ptr [rsp + 0x40]
0x00014287ae6c:  488b6c2448            mov       rbp, qword ptr [rsp + 0x48]
0x00014287ae71:  4883c420              add       rsp, 0x20
0x00014287ae75:  415e                  pop       r14
0x00014287ae77:  5f                    pop       rdi
0x00014287ae78:  5e                    pop       rsi
0x00014287ae79:  c3                    ret       
0x00014287ae7a:  8bc8                  mov       ecx, eax
0x00014287ae7c:  e8ff8e2a03            call      0x145b23d80
0x00014287ae81:  90                    nop       
0x00014287ae82:  488d15579f8504        lea       rdx, [rip + 0x4859f57]
0x00014287ae89:  33c9                  xor       ecx, ecx
0x00014287ae8b:  e8f03d0e02            call      0x14495ec80
0x00014287ae90:  90                    nop       
0x00014287ae91:  488d15489f8504        lea       rdx, [rip + 0x4859f48]
0x00014287ae98:  33c9                  xor       ecx, ecx
0x00014287ae9a:  e8e13d0e02            call      0x14495ec80
0x00014287ae9f:  cc                    int3      
0x00014287aea0:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x00014287aea5:  48896c2418            mov       qword ptr [rsp + 0x18], rbp
0x00014287aeaa:  56                    push      rsi
0x00014287aeab:  57                    push      rdi
0x00014287aeac:  4154                  push      r12
0x00014287aeae:  4156                  push      r14
0x00014287aeb0:  4157                  push      r15
0x00014287aeb2:  4881ec20020000        sub       rsp, 0x220
0x00014287aeb9:  488b0530884905        mov       rax, qword ptr [rip + 0x5498830]
0x00014287aec0:  4833c4                xor       rax, rsp
0x00014287aec3:  4889842410020000      mov       qword ptr [rsp + 0x210], rax
0x00014287aecb:  488bf9                mov       rdi, rcx
0x00014287aece:  48894c2440            mov       qword ptr [rsp + 0x40], rcx
0x00014287aed3:  488d0516864204        lea       rax, [rip + 0x4428616]
0x00014287aeda:  488901                mov       qword ptr [rcx], rax
0x00014287aedd:  4533ff                xor       r15d, r15d
0x00014287aee0:  4c897908              mov       qword ptr [rcx + 8], r15
0x00014287aee4:  4c897910              mov       qword ptr [rcx + 0x10], r15
0x00014287aee8:  4c897918              mov       qword ptr [rcx + 0x18], r15
0x00014287aeec:  0f57c0                xorps     xmm0, xmm0
0x00014287aeef:  0f114124              movups    xmmword ptr [rcx + 0x24], xmm0
0x00014287aef3:  0f114134              movups    xmmword ptr [rcx + 0x34], xmm0
0x00014287aef7:  0f114144              movups    xmmword ptr [rcx + 0x44], xmm0
0x00014287aefb:  0f114154              movups    xmmword ptr [rcx + 0x54], xmm0
0x00014287aeff:  33c0                  xor       eax, eax
0x00014287af01:  0f114164              movups    xmmword ptr [rcx + 0x64], xmm0
0x00014287af05:  48894174              mov       qword ptr [rcx + 0x74], rax
0x00014287af09:  89417c                mov       dword ptr [rcx + 0x7c], eax
0x00014287af0c:  41bc02000000          mov       r12d, 2
0x00014287af12:  6644896164            mov       word ptr [rcx + 0x64], r12w
0x00014287af17:  bbffff0000            mov       ebx, 0xffff
0x00014287af1c:  c781800000000000ffff  mov       dword ptr [rcx + 0x80], 0xffff0000
0x00014287af26:  66898184000000        mov       word ptr [rcx + 0x84], ax
0x00014287af2d:  c68186000000ff        mov       byte ptr [rcx + 0x86], 0xff
0x00014287af34:  4489b988000000        mov       dword ptr [rcx + 0x88], r15d
0x00014287af3b:  4c89b990000000        mov       qword ptr [rcx + 0x90], r15
0x00014287af42:  4c89b998000000        mov       qword ptr [rcx + 0x98], r15
0x00014287af49:  4c89b9a0000000        mov       qword ptr [rcx + 0xa0], r15
0x00014287af50:  4c89b9a8000000        mov       qword ptr [rcx + 0xa8], r15
0x00014287af57:  4489b9b0000000        mov       dword ptr [rcx + 0xb0], r15d
0x00014287af5e:  4c89b9b8000000        mov       qword ptr [rcx + 0xb8], r15
0x00014287af65:  4c89b9c0000000        mov       qword ptr [rcx + 0xc0], r15
0x00014287af6c:  4c89b9c8000000        mov       qword ptr [rcx + 0xc8], r15
0x00014287af73:  4c89b9d0000000        mov       qword ptr [rcx + 0xd0], r15
0x00014287af7a:  4c89b9d8000000        mov       qword ptr [rcx + 0xd8], r15
0x00014287af81:  4c89b9e0000000        mov       qword ptr [rcx + 0xe0], r15
0x00014287af88:  4c89b9e8000000        mov       qword ptr [rcx + 0xe8], r15
0x00014287af8f:  4c89b9f0000000        mov       qword ptr [rcx + 0xf0], r15
0x00014287af96:  4c89b9f8000000        mov       qword ptr [rcx + 0xf8], r15
0x00014287af9d:  4c89b900010000        mov       qword ptr [rcx + 0x100], r15
0x00014287afa4:  48898108010000        mov       qword ptr [rcx + 0x108], rax
0x00014287afab:  418bc7                mov       eax, r15d
0x00014287afae:  87810c010000          xchg      dword ptr [rcx + 0x10c], eax
0x00014287afb4:  488d050d8d4204        lea       rax, [rip + 0x4428d0d]
0x00014287afbb:  48898118010000        mov       qword ptr [rcx + 0x118], rax
0x00014287afc2:  4488b920010000        mov       byte ptr [rcx + 0x120], r15b
0x00014287afc9:  4489b928010000        mov       dword ptr [rcx + 0x128], r15d
0x00014287afd0:  48c7812c01000000080000  mov       qword ptr [rcx + 0x12c], 0x800
0x00014287afdb:  488d8141010000        lea       rax, [rcx + 0x141]
0x00014287afe2:  48898138010000        mov       qword ptr [rcx + 0x138], rax
0x00014287afe9:  c6814001000001        mov       byte ptr [rcx + 0x140], 1
0x00014287aff0:  33c0                  xor       eax, eax
0x00014287aff2:  898160030000          mov       dword ptr [rcx + 0x360], eax
0x00014287aff8:  4c89b968030000        mov       qword ptr [rcx + 0x368], r15
0x00014287afff:  4c89b970030000        mov       qword ptr [rcx + 0x370], r15
0x00014287b006:  4489b978030000        mov       dword ptr [rcx + 0x378], r15d
0x00014287b00d:  4c89b998030000        mov       qword ptr [rcx + 0x398], r15
0x00014287b014:  c781a003000000400000  mov       dword ptr [rcx + 0x3a0], 0x4000
0x00014287b01e:  4881c1a8030000        add       rcx, 0x3a8
0x00014287b025:  488d0574e6f4fd        lea       rax, [rip - 0x20b198c]
0x00014287b02c:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014287b031:  4c8d0d48e6f4fd        lea       r9, [rip - 0x20b19b8]
0x00014287b038:  458bc4                mov       r8d, r12d
0x00014287b03b:  418d5750              lea       edx, [r15 + 0x50]
0x00014287b03f:  e894692a03            call      0x145b219d8
0x00014287b044:  90                    nop       
0x00014287b045:  488d8f58040000        lea       rcx, [rdi + 0x458]
0x00014287b04c:  418bd4                mov       edx, r12d
0x00014287b04f:  e82c872a03            call      0x145b23780
0x00014287b054:  90                    nop       
0x00014287b055:  488d8fa8040000        lea       rcx, [rdi + 0x4a8]
0x00014287b05c:  418bd4                mov       edx, r12d
0x00014287b05f:  e81c872a03            call      0x145b23780
0x00014287b064:  90                    nop       
0x00014287b065:  488d8ff8040000        lea       rcx, [rdi + 0x4f8]
0x00014287b06c:  48894c2430            mov       qword ptr [rsp + 0x30], rcx
0x00014287b071:  44897c2430            mov       dword ptr [rsp + 0x30], r15d
0x00014287b076:  488d542430            lea       rdx, [rsp + 0x30]
0x00014287b07b:  e80020fdff            call      0x14284d080
0x00014287b080:  90                    nop       
0x00014287b081:  4c89bf44050000        mov       qword ptr [rdi + 0x544], r15
0x00014287b088:  4c89bf38050000        mov       qword ptr [rdi + 0x538], r15
0x00014287b08f:  4489bf40050000        mov       dword ptr [rdi + 0x540], r15d
0x00014287b096:  488d8f50050000        lea       rcx, [rdi + 0x550]
0x00014287b09d:  418bd4                mov       edx, r12d
0x00014287b0a0:  e8db862a03            call      0x145b23780
0x00014287b0a5:  90                    nop       
0x00014287b0a6:  b940050000            mov       ecx, 0x540
0x00014287b0ab:  e850870c02            call      0x144943800
0x00014287b0b0:  4885c0                test      rax, rax
0x00014287b0b3:  0f848c0a0000          je        0x14287bb45
0x00014287b0b9:  488987a0050000        mov       qword ptr [rdi + 0x5a0], rax
0x00014287b0c0:  48c787a805000008000000  mov       qword ptr [rdi + 0x5a8], 8
0x00014287b0cb:  4c89bfb0050000        mov       qword ptr [rdi + 0x5b0], r15
0x00014287b0d2:  4c89bfb8050000        mov       qword ptr [rdi + 0x5b8], r15
0x00014287b0d9:  b940050000            mov       ecx, 0x540
0x00014287b0de:  e81d870c02            call      0x144943800
0x00014287b0e3:  4885c0                test      rax, rax
0x00014287b0e6:  0f843d0a0000          je        0x14287bb29
0x00014287b0ec:  488987c0050000        mov       qword ptr [rdi + 0x5c0], rax
0x00014287b0f3:  48c787c805000008000000  mov       qword ptr [rdi + 0x5c8], 8
0x00014287b0fe:  4c89bfd0050000        mov       qword ptr [rdi + 0x5d0], r15
0x00014287b105:  4c89bfd8050000        mov       qword ptr [rdi + 0x5d8], r15
0x00014287b10c:  4489bfe0050000        mov       dword ptr [rdi + 0x5e0], r15d
0x00014287b113:  4c89bfe8050000        mov       qword ptr [rdi + 0x5e8], r15
0x00014287b11a:  4c89bf00060000        mov       qword ptr [rdi + 0x600], r15
0x00014287b121:  c7870806000000400000  mov       dword ptr [rdi + 0x608], 0x4000
0x00014287b12b:  488d8f10060000        lea       rcx, [rdi + 0x610]
0x00014287b132:  418bd4                mov       edx, r12d
0x00014287b135:  e846862a03            call      0x145b23780
0x00014287b13a:  4c89bf6c060000        mov       qword ptr [rdi + 0x66c], r15
0x00014287b141:  4c89bf60060000        mov       qword ptr [rdi + 0x660], r15
0x00014287b148:  4489bf68060000        mov       dword ptr [rdi + 0x668], r15d
0x00014287b14f:  488d8f78060000        lea       rcx, [rdi + 0x678]
0x00014287b156:  418bd4                mov       edx, r12d
0x00014287b159:  e822862a03            call      0x145b23780
0x00014287b15e:  90                    nop       
0x00014287b15f:  4c89bfd8060000        mov       qword ptr [rdi + 0x6d8], r15
0x00014287b166:  c787e006000000400000  mov       dword ptr [rdi + 0x6e0], 0x4000
0x00014287b170:  488d8fe8060000        lea       rcx, [rdi + 0x6e8]
0x00014287b177:  418bd4                mov       edx, r12d
0x00014287b17a:  e801862a03            call      0x145b23780
0x00014287b17f:  4c89bf44070000        mov       qword ptr [rdi + 0x744], r15
0x00014287b186:  4c89bf38070000        mov       qword ptr [rdi + 0x738], r15
0x00014287b18d:  4489bf40070000        mov       dword ptr [rdi + 0x740], r15d
0x00014287b194:  488d8f50070000        lea       rcx, [rdi + 0x750]
0x00014287b19b:  418bd4                mov       edx, r12d
0x00014287b19e:  e8dd852a03            call      0x145b23780
0x00014287b1a3:  90                    nop       
0x00014287b1a4:  4c89bfa0070000        mov       qword ptr [rdi + 0x7a0], r15
0x00014287b1ab:  4c89bfa8070000        mov       qword ptr [rdi + 0x7a8], r15
0x00014287b1b2:  4c89bfc0070000        mov       qword ptr [rdi + 0x7c0], r15
0x00014287b1b9:  c787c807000000400000  mov       dword ptr [rdi + 0x7c8], 0x4000
0x00014287b1c3:  488d8fd0070000        lea       rcx, [rdi + 0x7d0]
0x00014287b1ca:  418bd4                mov       edx, r12d
0x00014287b1cd:  e8ae852a03            call      0x145b23780
0x00014287b1d2:  4c89bf2c080000        mov       qword ptr [rdi + 0x82c], r15
0x00014287b1d9:  4c89bf20080000        mov       qword ptr [rdi + 0x820], r15
0x00014287b1e0:  4489bf28080000        mov       dword ptr [rdi + 0x828], r15d
0x00014287b1e7:  488d8f38080000        lea       rcx, [rdi + 0x838]
0x00014287b1ee:  418bd4                mov       edx, r12d
0x00014287b1f1:  e88a852a03            call      0x145b23780
0x00014287b1f6:  90                    nop       
0x00014287b1f7:  488d8f88080000        lea       rcx, [rdi + 0x888]
0x00014287b1fe:  418bd4                mov       edx, r12d
0x00014287b201:  e87a852a03            call      0x145b23780
0x00014287b206:  90                    nop       
0x00014287b207:  4c8db7d8080000        lea       r14, [rdi + 0x8d8]
0x00014287b20e:  4d893e                mov       qword ptr [r14], r15
0x00014287b211:  4d897e08              mov       qword ptr [r14 + 8], r15
0x00014287b215:  4d897e10              mov       qword ptr [r14 + 0x10], r15
0x00014287b219:  4c89bf08090000        mov       qword ptr [rdi + 0x908], r15
0x00014287b220:  4c89bf00090000        mov       qword ptr [rdi + 0x900], r15
0x00014287b227:  0f57c0                xorps     xmm0, xmm0
0x00014287b22a:  33c0                  xor       eax, eax
0x00014287b22c:  0f118718090000        movups    xmmword ptr [rdi + 0x918], xmm0
0x00014287b233:  48898728090000        mov       qword ptr [rdi + 0x928], rax
0x00014287b23a:  898730090000          mov       dword ptr [rdi + 0x930], eax
0x00014287b240:  664489a718090000      mov       word ptr [rdi + 0x918], r12w
0x00014287b248:  c787340900000000ffff  mov       dword ptr [rdi + 0x934], 0xffff0000
0x00014287b252:  66899f48090000        mov       word ptr [rdi + 0x948], bx
0x00014287b259:  488b0508465705        mov       rax, qword ptr [rip + 0x5574608]
0x00014287b260:  48898740090000        mov       qword ptr [rdi + 0x940], rax
0x00014287b267:  0fb70502465705        movzx     eax, word ptr [rip + 0x5574602]
0x00014287b26e:  66898748090000        mov       word ptr [rdi + 0x948], ax
0x00014287b275:  33c0                  xor       eax, eax
0x00014287b277:  0f118758090000        movups    xmmword ptr [rdi + 0x958], xmm0
0x00014287b27e:  48898768090000        mov       qword ptr [rdi + 0x968], rax
0x00014287b285:  898770090000          mov       dword ptr [rdi + 0x970], eax
0x00014287b28b:  664489a758090000      mov       word ptr [rdi + 0x958], r12w
0x00014287b293:  c787740900000000ffff  mov       dword ptr [rdi + 0x974], 0xffff0000
0x00014287b29d:  4c89bf88090000        mov       qword ptr [rdi + 0x988], r15
0x00014287b2a4:  4c89bf80090000        mov       qword ptr [rdi + 0x980], r15
0x00014287b2ab:  488daf90090000        lea       rbp, [rdi + 0x990]
0x00014287b2b2:  488bc5                mov       rax, rbp
0x00014287b2b5:  418d4f0a              lea       ecx, [r15 + 0xa]
0x00014287b2b9:  0f1f8000000000        nop       dword ptr [rax]
0x00014287b2c0:  33d2                  xor       edx, edx
0x00014287b2c2:  0f1100                movups    xmmword ptr [rax], xmm0
0x00014287b2c5:  48895010              mov       qword ptr [rax + 0x10], rdx
0x00014287b2c9:  895018                mov       dword ptr [rax + 0x18], edx
0x00014287b2cc:  66448920              mov       word ptr [rax], r12w
0x00014287b2d0:  c7401c0000ffff        mov       dword ptr [rax + 0x1c], 0xffff0000
0x00014287b2d7:  488d4020              lea       rax, [rax + 0x20]
0x00014287b2db:  4883e901              sub       rcx, 1
0x00014287b2df:  75df                  jne       0x14287b2c0
0x00014287b2e1:  c687e80a000001        mov       byte ptr [rdi + 0xae8], 1
0x00014287b2e8:  8897e90a0000          mov       byte ptr [rdi + 0xae9], dl
0x00014287b2ee:  488d8ff00a0000        lea       rcx, [rdi + 0xaf0]
0x00014287b2f5:  4885c9                test      rcx, rcx
0x00014287b2f8:  740f                  je        0x14287b309
0x00014287b2fa:  4533c0                xor       r8d, r8d
0x00014287b2fd:  488d1554d66c04        lea       rdx, [rip + 0x46cd654]
0x00014287b304:  e8e7c878fd            call      0x140007bf0
0x00014287b309:  488d8ff80a0000        lea       rcx, [rdi + 0xaf8]
0x00014287b310:  4885c9                test      rcx, rcx
0x00014287b313:  7410                  je        0x14287b325
0x00014287b315:  4533c0                xor       r8d, r8d
0x00014287b318:  488d1549d66c04        lea       rdx, [rip + 0x46cd649]
0x00014287b31f:  e83cdf78fd            call      0x140009260
0x00014287b324:  90                    nop       
0x00014287b325:  c687000b000001        mov       byte ptr [rdi + 0xb00], 1
0x00014287b32c:  c687010b000000        mov       byte ptr [rdi + 0xb01], 0
0x00014287b333:  488d8f080b0000        lea       rcx, [rdi + 0xb08]
0x00014287b33a:  4885c9                test      rcx, rcx
0x00014287b33d:  740f                  je        0x14287b34e
0x00014287b33f:  4533c0                xor       r8d, r8d
0x00014287b342:  488d150fd66c04        lea       rdx, [rip + 0x46cd60f]
0x00014287b349:  e8a2c878fd            call      0x140007bf0
0x00014287b34e:  488d8f100b0000        lea       rcx, [rdi + 0xb10]
0x00014287b355:  4885c9                test      rcx, rcx
0x00014287b358:  7410                  je        0x14287b36a
0x00014287b35a:  4533c0                xor       r8d, r8d
0x00014287b35d:  488d1504d66c04        lea       rdx, [rip + 0x46cd604]
0x00014287b364:  e8f7de78fd            call      0x140009260
0x00014287b369:  90                    nop       
0x00014287b36a:  418bd4                mov       edx, r12d
0x00014287b36d:  488d8f180b0000        lea       rcx, [rdi + 0xb18]
0x00014287b374:  e807842a03            call      0x145b23780
0x00014287b379:  488d8f680b0000        lea       rcx, [rdi + 0xb68]
0x00014287b380:  e8739b2a03            call      0x145b24ef8
0x00014287b385:  c687b00b000000        mov       byte ptr [rdi + 0xbb0], 0
0x00014287b38c:  418bd4                mov       edx, r12d
0x00014287b38f:  488d8fc00b0000        lea       rcx, [rdi + 0xbc0]
0x00014287b396:  e8e5832a03            call      0x145b23780
0x00014287b39b:  90                    nop       
0x00014287b39c:  4c89bf200c0000        mov       qword ptr [rdi + 0xc20], r15
0x00014287b3a3:  c787280c000000400000  mov       dword ptr [rdi + 0xc28], 0x4000
0x00014287b3ad:  488d8f300c0000        lea       rcx, [rdi + 0xc30]
0x00014287b3b4:  418bd4                mov       edx, r12d
0x00014287b3b7:  e8c4832a03            call      0x145b23780
0x00014287b3bc:  90                    nop       
0x00014287b3bd:  4c89bf8c0c0000        mov       qword ptr [rdi + 0xc8c], r15
0x00014287b3c4:  4c89bf800c0000        mov       qword ptr [rdi + 0xc80], r15
0x00014287b3cb:  4489bf880c0000        mov       dword ptr [rdi + 0xc88], r15d
0x00014287b3d2:  488d8f980c0000        lea       rcx, [rdi + 0xc98]
0x00014287b3d9:  48894c2438            mov       qword ptr [rsp + 0x38], rcx
0x00014287b3de:  c744243800000000      mov       dword ptr [rsp + 0x38], 0
0x00014287b3e6:  488d542438            lea       rdx, [rsp + 0x38]
0x00014287b3eb:  e8901cfdff            call      0x14284d080
0x00014287b3f0:  90                    nop       
0x00014287b3f1:  418bd4                mov       edx, r12d
0x00014287b3f4:  488d8fd80c0000        lea       rcx, [rdi + 0xcd8]
0x00014287b3fb:  e880832a03            call      0x145b23780
0x00014287b400:  90                    nop       
0x00014287b401:  4c89bf300d0000        mov       qword ptr [rdi + 0xd30], r15
0x00014287b408:  4c89bf400d0000        mov       qword ptr [rdi + 0xd40], r15
0x00014287b40f:  48c787480d00000f000000  mov       qword ptr [rdi + 0xd48], 0xf
0x00014287b41a:  c687300d000000        mov       byte ptr [rdi + 0xd30], 0
0x00014287b421:  4c89bf500d0000        mov       qword ptr [rdi + 0xd50], r15
0x00014287b428:  4c89bf600d0000        mov       qword ptr [rdi + 0xd60], r15
0x00014287b42f:  48c787680d00000f000000  mov       qword ptr [rdi + 0xd68], 0xf
0x00014287b43a:  c687500d000000        mov       byte ptr [rdi + 0xd50], 0
0x00014287b441:  4489bf700d0000        mov       dword ptr [rdi + 0xd70], r15d
0x00014287b448:  4c89bf780d0000        mov       qword ptr [rdi + 0xd78], r15
0x00014287b44f:  4c89bf880d0000        mov       qword ptr [rdi + 0xd88], r15
0x00014287b456:  48c787900d00000f000000  mov       qword ptr [rdi + 0xd90], 0xf
0x00014287b461:  c687780d000000        mov       byte ptr [rdi + 0xd78], 0
0x00014287b468:  488d8f980d0000        lea       rcx, [rdi + 0xd98]
0x00014287b46f:  e86c8b94fe            call      0x1411c3fe0
0x00014287b474:  90                    nop       
0x00014287b475:  4c89bfd00d0000        mov       qword ptr [rdi + 0xdd0], r15
0x00014287b47c:  4c89bfd80d0000        mov       qword ptr [rdi + 0xdd8], r15
0x00014287b483:  4c89bf180e0000        mov       qword ptr [rdi + 0xe18], r15
0x00014287b48a:  0f57c0                xorps     xmm0, xmm0
0x00014287b48d:  0f1187200e0000        movups    xmmword ptr [rdi + 0xe20], xmm0
0x00014287b494:  0f1187300e0000        movups    xmmword ptr [rdi + 0xe30], xmm0
0x00014287b49b:  488d8f400e0000        lea       rcx, [rdi + 0xe40]
0x00014287b4a2:  418bd4                mov       edx, r12d
0x00014287b4a5:  e8d6822a03            call      0x145b23780
0x00014287b4aa:  90                    nop       
0x00014287b4ab:  4c89bf900e0000        mov       qword ptr [rdi + 0xe90], r15
0x00014287b4b2:  4c89bf980e0000        mov       qword ptr [rdi + 0xe98], r15
0x00014287b4b9:  4c89bfa00e0000        mov       qword ptr [rdi + 0xea0], r15
0x00014287b4c0:  488d8fa80e0000        lea       rcx, [rdi + 0xea8]
0x00014287b4c7:  418bd4                mov       edx, r12d
0x00014287b4ca:  e8b1822a03            call      0x145b23780
0x00014287b4cf:  90                    nop       
0x00014287b4d0:  4c89bf000f0000        mov       qword ptr [rdi + 0xf00], r15
0x00014287b4d7:  4c89bf080f0000        mov       qword ptr [rdi + 0xf08], r15
0x00014287b4de:  4c89bf180f0000        mov       qword ptr [rdi + 0xf18], r15
0x00014287b4e5:  4c89bf200f0000        mov       qword ptr [rdi + 0xf20], r15
0x00014287b4ec:  4c89bf280f0000        mov       qword ptr [rdi + 0xf28], r15
0x00014287b4f3:  4c89bf300f0000        mov       qword ptr [rdi + 0xf30], r15
0x00014287b4fa:  4c89bf380f0000        mov       qword ptr [rdi + 0xf38], r15
0x00014287b501:  4c89bf480f0000        mov       qword ptr [rdi + 0xf48], r15
0x00014287b508:  4c89bf500f0000        mov       qword ptr [rdi + 0xf50], r15
0x00014287b50f:  4489bf580f0000        mov       dword ptr [rdi + 0xf58], r15d
0x00014287b516:  4c89bf600f0000        mov       qword ptr [rdi + 0xf60], r15
0x00014287b51d:  c787680f0000ffffff7f  mov       dword ptr [rdi + 0xf68], 0x7fffffff
0x00014287b527:  c7876c0f000000000080  mov       dword ptr [rdi + 0xf6c], 0x80000000
0x00014287b531:  c687700f000000        mov       byte ptr [rdi + 0xf70], 0
0x00014287b538:  4c89bf740f0000        mov       qword ptr [rdi + 0xf74], r15
0x00014287b53f:  c7877c0f0000ffffff7f  mov       dword ptr [rdi + 0xf7c], 0x7fffffff
0x00014287b549:  c787800f000000000080  mov       dword ptr [rdi + 0xf80], 0x80000000
0x00014287b553:  4489bf840f0000        mov       dword ptr [rdi + 0xf84], r15d
0x00014287b55a:  4c89bf880f0000        mov       qword ptr [rdi + 0xf88], r15
0x00014287b561:  4489bf900f0000        mov       dword ptr [rdi + 0xf90], r15d
0x00014287b568:  4c89bf980f0000        mov       qword ptr [rdi + 0xf98], r15
0x00014287b56f:  4489bfa00f0000        mov       dword ptr [rdi + 0xfa0], r15d
0x00014287b576:  4c89bfa80f0000        mov       qword ptr [rdi + 0xfa8], r15
0x00014287b57d:  4c89bfb00f0000        mov       qword ptr [rdi + 0xfb0], r15
0x00014287b584:  4c89bfb80f0000        mov       qword ptr [rdi + 0xfb8], r15
0x00014287b58b:  4489bfc00f0000        mov       dword ptr [rdi + 0xfc0], r15d
0x00014287b592:  4489bfc80f0000        mov       dword ptr [rdi + 0xfc8], r15d
0x00014287b599:  4c89bfd00f0000        mov       qword ptr [rdi + 0xfd0], r15
0x00014287b5a0:  4c89bfd80f0000        mov       qword ptr [rdi + 0xfd8], r15
0x00014287b5a7:  c687e00f000000        mov       byte ptr [rdi + 0xfe0], 0
0x00014287b5ae:  4c89bfe80f0000        mov       qword ptr [rdi + 0xfe8], r15
0x00014287b5b5:  4c89bff00f0000        mov       qword ptr [rdi + 0xff0], r15
0x00014287b5bc:  4c89bff80f0000        mov       qword ptr [rdi + 0xff8], r15
0x00014287b5c3:  4c89bf00100000        mov       qword ptr [rdi + 0x1000], r15
0x00014287b5ca:  4c89bf10100000        mov       qword ptr [rdi + 0x1010], r15
0x00014287b5d1:  48c787181000000f000000  mov       qword ptr [rdi + 0x1018], 0xf
0x00014287b5dc:  c6870010000000        mov       byte ptr [rdi + 0x1000], 0
0x00014287b5e3:  4c89bf20100000        mov       qword ptr [rdi + 0x1020], r15
0x00014287b5ea:  4c89bf28100000        mov       qword ptr [rdi + 0x1028], r15
0x00014287b5f1:  4c89bf30100000        mov       qword ptr [rdi + 0x1030], r15
0x00014287b5f8:  c6873810000000        mov       byte ptr [rdi + 0x1038], 0
0x00014287b5ff:  4489bf3c100000        mov       dword ptr [rdi + 0x103c], r15d
0x00014287b606:  c6874010000000        mov       byte ptr [rdi + 0x1040], 0
0x00014287b60d:  4489bf44100000        mov       dword ptr [rdi + 0x1044], r15d
0x00014287b614:  488d4c2448            lea       rcx, [rsp + 0x48]
0x00014287b619:  e8d2550200            call      0x1428a0bf0
0x00014287b61e:  488b08                mov       rcx, qword ptr [rax]
0x00014287b621:  4c8938                mov       qword ptr [rax], r15
0x00014287b624:  48898f48100000        mov       qword ptr [rdi + 0x1048], rcx
0x00014287b62b:  66c787501000000100    mov       word ptr [rdi + 0x1050], 1
0x00014287b634:  8b0536809305          mov       eax, dword ptr [rip + 0x5938036]
0x00014287b63a:  ffc0                  inc       eax
0x00014287b63c:  89052e809305          mov       dword ptr [rip + 0x593802e], eax
0x00014287b642:  83f801                cmp       eax, 1
0x00014287b645:  7510                  jne       0x14287b657
0x00014287b647:  b902020000            mov       ecx, 0x202
0x00014287b64c:  488d542470            lea       rdx, [rsp + 0x70]
0x00014287b651:  ff1509428c03          call      qword ptr [rip + 0x38c4209]
0x00014287b657:  8b057bf54e05          mov       eax, dword ptr [rip + 0x54ef57b]
0x00014287b65d:  89442450              mov       dword ptr [rsp + 0x50], eax
0x00014287b661:  8b0599f54e05          mov       eax, dword ptr [rip + 0x54ef599]
0x00014287b667:  89442454              mov       dword ptr [rsp + 0x54], eax
0x00014287b66b:  8b05b7f54e05          mov       eax, dword ptr [rip + 0x54ef5b7]
0x00014287b671:  89442458              mov       dword ptr [rsp + 0x58], eax
0x00014287b675:  4c8d44245c            lea       r8, [rsp + 0x5c]
0x00014287b67a:  488d542450            lea       rdx, [rsp + 0x50]
0x00014287b67f:  498bce                mov       rcx, r14
0x00014287b682:  e809c4a9fe            call      0x141317a90
0x00014287b687:  498b0e                mov       rcx, qword ptr [r14]
0x00014287b68a:  498b4608              mov       rax, qword ptr [r14 + 8]
0x00014287b68e:  482bc1                sub       rax, rcx
0x00014287b691:  48c1f802              sar       rax, 2
0x00014287b695:  8b4481fc              mov       eax, dword ptr [rcx + rax*4 - 4]
0x00014287b699:  8987f0080000          mov       dword ptr [rdi + 0x8f0], eax
0x00014287b69f:  c687f408000000        mov       byte ptr [rdi + 0x8f4], 0
0x00014287b6a6:  4489bf12010000        mov       dword ptr [rdi + 0x112], r15d
0x00014287b6ad:  4c89bf50030000        mov       qword ptr [rdi + 0x350], r15
0x00014287b6b4:  4c89bf58030000        mov       qword ptr [rdi + 0x358], r15
0x00014287b6bb:  418bc7                mov       eax, r15d
0x00014287b6be:  878760030000          xchg      dword ptr [rdi + 0x360], eax
0x00014287b6c4:  4c89bf80030000        mov       qword ptr [rdi + 0x380], r15
0x00014287b6cb:  4c89bf4c040000        mov       qword ptr [rdi + 0x44c], r15
0x00014287b6d2:  b801000000            mov       eax, 1
0x00014287b6d7:  86870a010000          xchg      byte ptr [rdi + 0x10a], al
0x00014287b6dd:  b801000000            mov       eax, 1
0x00014287b6e2:  868708010000          xchg      byte ptr [rdi + 0x108], al
0x00014287b6e8:  418bc7                mov       eax, r15d
0x00014287b6eb:  868709010000          xchg      byte ptr [rdi + 0x109], al
0x00014287b6f1:  4489bf64030000        mov       dword ptr [rdi + 0x364], r15d
0x00014287b6f8:  c787f808000001000000  mov       dword ptr [rdi + 0x8f8], 1
0x00014287b702:  4c89bff80e0000        mov       qword ptr [rdi + 0xef8], r15
0x00014287b709:  c6871001000001        mov       byte ptr [rdi + 0x110], 1
0x00014287b710:  c687d00a000000        mov       byte ptr [rdi + 0xad0], 0
0x00014287b717:  0f10052a415705        movups    xmm0, xmmword ptr [rip + 0x557412a]
0x00014287b71e:  0f114500              movups    xmmword ptr [rbp], xmm0
0x00014287b722:  f20f100d2e415705      movsd     xmm1, qword ptr [rip + 0x557412e]
0x00014287b72a:  f20f114d10            movsd     qword ptr [rbp + 0x10], xmm1
0x00014287b72f:  8b052b415705          mov       eax, dword ptr [rip + 0x557412b]
0x00014287b735:  894518                mov       dword ptr [rbp + 0x18], eax
0x00014287b738:  0fb70527415705        movzx     eax, word ptr [rip + 0x5574127]
0x00014287b73f:  6689451e              mov       word ptr [rbp + 0x1e], ax
0x00014287b743:  0fb7051a415705        movzx     eax, word ptr [rip + 0x557411a]
0x00014287b74a:  6689451c              mov       word ptr [rbp + 0x1c], ax
0x00014287b74e:  0f1005f3405705        movups    xmm0, xmmword ptr [rip + 0x55740f3]
0x00014287b755:  0f1187b0090000        movups    xmmword ptr [rdi + 0x9b0], xmm0
0x00014287b75c:  f20f100df4405705      movsd     xmm1, qword ptr [rip + 0x55740f4]
0x00014287b764:  f20f118fc0090000      movsd     qword ptr [rdi + 0x9c0], xmm1
0x00014287b76c:  8b05ee405705          mov       eax, dword ptr [rip + 0x55740ee]
0x00014287b772:  8987c8090000          mov       dword ptr [rdi + 0x9c8], eax
0x00014287b778:  0fb705e7405705        movzx     eax, word ptr [rip + 0x55740e7]
0x00014287b77f:  668987ce090000        mov       word ptr [rdi + 0x9ce], ax
0x00014287b786:  0fb705d7405705        movzx     eax, word ptr [rip + 0x55740d7]
0x00014287b78d:  668987cc090000        mov       word ptr [rdi + 0x9cc], ax
0x00014287b794:  0f1005ad405705        movups    xmm0, xmmword ptr [rip + 0x55740ad]
0x00014287b79b:  0f1187d0090000        movups    xmmword ptr [rdi + 0x9d0], xmm0
0x00014287b7a2:  f20f100dae405705      movsd     xmm1, qword ptr [rip + 0x55740ae]
0x00014287b7aa:  f20f118fe0090000      movsd     qword ptr [rdi + 0x9e0], xmm1
0x00014287b7b2:  8b05a8405705          mov       eax, dword ptr [rip + 0x55740a8]
0x00014287b7b8:  8987e8090000          mov       dword ptr [rdi + 0x9e8], eax
0x00014287b7be:  0fb705a1405705        movzx     eax, word ptr [rip + 0x55740a1]
0x00014287b7c5:  668987ee090000        mov       word ptr [rdi + 0x9ee], ax
0x00014287b7cc:  0fb70591405705        movzx     eax, word ptr [rip + 0x5574091]
0x00014287b7d3:  668987ec090000        mov       word ptr [rdi + 0x9ec], ax
0x00014287b7da:  0f100567405705        movups    xmm0, xmmword ptr [rip + 0x5574067]
0x00014287b7e1:  0f1187f0090000        movups    xmmword ptr [rdi + 0x9f0], xmm0
0x00014287b7e8:  f20f100d68405705      movsd     xmm1, qword ptr [rip + 0x5574068]
0x00014287b7f0:  f20f118f000a0000      movsd     qword ptr [rdi + 0xa00], xmm1
0x00014287b7f8:  8b0562405705          mov       eax, dword ptr [rip + 0x5574062]
0x00014287b7fe:  8987080a0000          mov       dword ptr [rdi + 0xa08], eax
0x00014287b804:  0fb7055b405705        movzx     eax, word ptr [rip + 0x557405b]
0x00014287b80b:  6689870e0a0000        mov       word ptr [rdi + 0xa0e], ax
0x00014287b812:  0fb7054b405705        movzx     eax, word ptr [rip + 0x557404b]
0x00014287b819:  6689870c0a0000        mov       word ptr [rdi + 0xa0c], ax
0x00014287b820:  0f100521405705        movups    xmm0, xmmword ptr [rip + 0x5574021]
0x00014287b827:  0f1187100a0000        movups    xmmword ptr [rdi + 0xa10], xmm0
0x00014287b82e:  f20f100d22405705      movsd     xmm1, qword ptr [rip + 0x5574022]
0x00014287b836:  f20f118f200a0000      movsd     qword ptr [rdi + 0xa20], xmm1
0x00014287b83e:  8b051c405705          mov       eax, dword ptr [rip + 0x557401c]
0x00014287b844:  8987280a0000          mov       dword ptr [rdi + 0xa28], eax
0x00014287b84a:  0fb70515405705        movzx     eax, word ptr [rip + 0x5574015]
0x00014287b851:  6689872e0a0000        mov       word ptr [rdi + 0xa2e], ax
0x00014287b858:  0fb70505405705        movzx     eax, word ptr [rip + 0x5574005]
0x00014287b85f:  6689872c0a0000        mov       word ptr [rdi + 0xa2c], ax
0x00014287b866:  0f1005db3f5705        movups    xmm0, xmmword ptr [rip + 0x5573fdb]
0x00014287b86d:  0f1187300a0000        movups    xmmword ptr [rdi + 0xa30], xmm0
0x00014287b874:  f20f100ddc3f5705      movsd     xmm1, qword ptr [rip + 0x5573fdc]
0x00014287b87c:  f20f118f400a0000      movsd     qword ptr [rdi + 0xa40], xmm1
0x00014287b884:  8b05d63f5705          mov       eax, dword ptr [rip + 0x5573fd6]
0x00014287b88a:  8987480a0000          mov       dword ptr [rdi + 0xa48], eax
0x00014287b890:  0fb705cf3f5705        movzx     eax, word ptr [rip + 0x5573fcf]
0x00014287b897:  6689874e0a0000        mov       word ptr [rdi + 0xa4e], ax
0x00014287b89e:  0fb705bf3f5705        movzx     eax, word ptr [rip + 0x5573fbf]
0x00014287b8a5:  6689874c0a0000        mov       word ptr [rdi + 0xa4c], ax
0x00014287b8ac:  0f1005953f5705        movups    xmm0, xmmword ptr [rip + 0x5573f95]
0x00014287b8b3:  0f1187500a0000        movups    xmmword ptr [rdi + 0xa50], xmm0
0x00014287b8ba:  f20f100d963f5705      movsd     xmm1, qword ptr [rip + 0x5573f96]
0x00014287b8c2:  f20f118f600a0000      movsd     qword ptr [rdi + 0xa60], xmm1
0x00014287b8ca:  8b05903f5705          mov       eax, dword ptr [rip + 0x5573f90]
0x00014287b8d0:  8987680a0000          mov       dword ptr [rdi + 0xa68], eax
0x00014287b8d6:  0fb705893f5705        movzx     eax, word ptr [rip + 0x5573f89]
0x00014287b8dd:  6689876e0a0000        mov       word ptr [rdi + 0xa6e], ax
0x00014287b8e4:  0fb705793f5705        movzx     eax, word ptr [rip + 0x5573f79]
0x00014287b8eb:  6689876c0a0000        mov       word ptr [rdi + 0xa6c], ax
0x00014287b8f2:  0f10054f3f5705        movups    xmm0, xmmword ptr [rip + 0x5573f4f]
0x00014287b8f9:  0f1187700a0000        movups    xmmword ptr [rdi + 0xa70], xmm0
0x00014287b900:  f20f100d503f5705      movsd     xmm1, qword ptr [rip + 0x5573f50]
0x00014287b908:  f20f118f800a0000      movsd     qword ptr [rdi + 0xa80], xmm1
0x00014287b910:  8b054a3f5705          mov       eax, dword ptr [rip + 0x5573f4a]
0x00014287b916:  8987880a0000          mov       dword ptr [rdi + 0xa88], eax
0x00014287b91c:  0fb705433f5705        movzx     eax, word ptr [rip + 0x5573f43]
0x00014287b923:  6689878e0a0000        mov       word ptr [rdi + 0xa8e], ax
0x00014287b92a:  0fb705333f5705        movzx     eax, word ptr [rip + 0x5573f33]
0x00014287b931:  6689878c0a0000        mov       word ptr [rdi + 0xa8c], ax
0x00014287b938:  0f1005093f5705        movups    xmm0, xmmword ptr [rip + 0x5573f09]
0x00014287b93f:  0f1187900a0000        movups    xmmword ptr [rdi + 0xa90], xmm0
0x00014287b946:  f20f100d0a3f5705      movsd     xmm1, qword ptr [rip + 0x5573f0a]
0x00014287b94e:  f20f118fa00a0000      movsd     qword ptr [rdi + 0xaa0], xmm1
0x00014287b956:  8b05043f5705          mov       eax, dword ptr [rip + 0x5573f04]
0x00014287b95c:  8987a80a0000          mov       dword ptr [rdi + 0xaa8], eax
0x00014287b962:  0fb705fd3e5705        movzx     eax, word ptr [rip + 0x5573efd]
0x00014287b969:  668987ae0a0000        mov       word ptr [rdi + 0xaae], ax
0x00014287b970:  0fb705ed3e5705        movzx     eax, word ptr [rip + 0x5573eed]
0x00014287b977:  668987ac0a0000        mov       word ptr [rdi + 0xaac], ax
0x00014287b97e:  0f1005c33e5705        movups    xmm0, xmmword ptr [rip + 0x5573ec3]
0x00014287b985:  0f1187b00a0000        movups    xmmword ptr [rdi + 0xab0], xmm0
0x00014287b98c:  f20f100dc43e5705      movsd     xmm1, qword ptr [rip + 0x5573ec4]
0x00014287b994:  f20f118fc00a0000      movsd     qword ptr [rdi + 0xac0], xmm1
0x00014287b99c:  8b05be3e5705          mov       eax, dword ptr [rip + 0x5573ebe]
0x00014287b9a2:  8987c80a0000          mov       dword ptr [rdi + 0xac8], eax
0x00014287b9a8:  0fb705b73e5705        movzx     eax, word ptr [rip + 0x5573eb7]
0x00014287b9af:  668987ce0a0000        mov       word ptr [rdi + 0xace], ax
0x00014287b9b6:  0fb705a73e5705        movzx     eax, word ptr [rip + 0x5573ea7]
0x00014287b9bd:  668987cc0a0000        mov       word ptr [rdi + 0xacc], ax
0x00014287b9c4:  c6875409000000        mov       byte ptr [rdi + 0x954], 0
0x00014287b9cb:  c6874802000000        mov       byte ptr [rdi + 0x248], 0
0x00014287b9d2:  4489bf78090000        mov       dword ptr [rdi + 0x978], r15d
0x00014287b9d9:  c7877c090000e8030000  mov       dword ptr [rdi + 0x97c], 0x3e8
0x00014287b9e3:  4489bf50090000        mov       dword ptr [rdi + 0x950], r15d
0x00014287b9ea:  0f1005573e5705        movups    xmm0, xmmword ptr [rip + 0x5573e57]
0x00014287b9f1:  0f118758090000        movups    xmmword ptr [rdi + 0x958], xmm0
0x00014287b9f8:  f20f100d583e5705      movsd     xmm1, qword ptr [rip + 0x5573e58]
0x00014287ba00:  f20f118f68090000      movsd     qword ptr [rdi + 0x968], xmm1
0x00014287ba08:  8b05523e5705          mov       eax, dword ptr [rip + 0x5573e52]
0x00014287ba0e:  898770090000          mov       dword ptr [rdi + 0x970], eax
0x00014287ba14:  0fb7054b3e5705        movzx     eax, word ptr [rip + 0x5573e4b]
0x00014287ba1b:  66898776090000        mov       word ptr [rdi + 0x976], ax
0x00014287ba22:  0fb7053b3e5705        movzx     eax, word ptr [rip + 0x5573e3b]
0x00014287ba29:  66898774090000        mov       word ptr [rdi + 0x974], ax
0x00014287ba30:  488b05313e5705        mov       rax, qword ptr [rip + 0x5573e31]
0x00014287ba37:  48898740090000        mov       qword ptr [rdi + 0x940], rax
0x00014287ba3e:  0fb7052b3e5705        movzx     eax, word ptr [rip + 0x5573e2b]
0x00014287ba45:  66898748090000        mov       word ptr [rdi + 0x948], ax
0x00014287ba4c:  4c89bfd80a0000        mov       qword ptr [rdi + 0xad8], r15
0x00014287ba53:  4c89bfe00a0000        mov       qword ptr [rdi + 0xae0], r15
0x00014287ba5a:  8b0528f04e05          mov       eax, dword ptr [rip + 0x54ef028]
0x00014287ba60:  89873c090000          mov       dword ptr [rdi + 0x93c], eax
0x00014287ba66:  c687a80d000000        mov       byte ptr [rdi + 0xda8], 0
0x00014287ba6d:  4c89bfc80d0000        mov       qword ptr [rdi + 0xdc8], r15
0x00014287ba74:  c787c807000080000000  mov       dword ptr [rdi + 0x7c8], 0x80
0x00014287ba7e:  c7870806000040310000  mov       dword ptr [rdi + 0x608], 0x3140
0x00014287ba88:  488d8fc00b0000        lea       rcx, [rdi + 0xbc0]
0x00014287ba8f:  e81c7d2a03            call      0x145b237b0
0x00014287ba94:  85c0                  test      eax, eax
0x00014287ba96:  0f85c5000000          jne       0x14287bb61
0x00014287ba9c:  c787280c0000000e0000  mov       dword ptr [rdi + 0xc28], 0xe00
0x00014287baa6:  488d8fc00b0000        lea       rcx, [rdi + 0xbc0]
0x00014287baad:  e85e7d2a03            call      0x145b23810
0x00014287bab2:  c787a003000000030000  mov       dword ptr [rdi + 0x3a0], 0x300
0x00014287babc:  e89f5c0e02            call      0x144961760
0x00014287bac1:  48898740090000        mov       qword ptr [rdi + 0x940], rax
0x00014287bac8:  c687b80b000000        mov       byte ptr [rdi + 0xbb8], 0
0x00014287bacf:  488d8fd80c0000        lea       rcx, [rdi + 0xcd8]
0x00014287bad6:  e8d57c2a03            call      0x145b237b0
0x00014287badb:  85c0                  test      eax, eax
0x00014287badd:  0f8586000000          jne       0x14287bb69
0x00014287bae3:  c787280d000001000000  mov       dword ptr [rdi + 0xd28], 1
0x00014287baed:  488d8fd80c0000        lea       rcx, [rdi + 0xcd8]
0x00014287baf4:  e8177d2a03            call      0x145b23810
0x00014287baf9:  90                    nop       
0x00014287bafa:  488bc7                mov       rax, rdi
0x00014287bafd:  488b8c2410020000      mov       rcx, qword ptr [rsp + 0x210]
0x00014287bb05:  4833cc                xor       rcx, rsp
0x00014287bb08:  e8d35a2a03            call      0x145b215e0
0x00014287bb0d:  4c8d9c2420020000      lea       r11, [rsp + 0x220]
0x00014287bb15:  498b5b38              mov       rbx, qword ptr [r11 + 0x38]
0x00014287bb19:  498b6b40              mov       rbp, qword ptr [r11 + 0x40]
0x00014287bb1d:  498be3                mov       rsp, r11
0x00014287bb20:  415f                  pop       r15
0x00014287bb22:  415e                  pop       r14
0x00014287bb24:  415c                  pop       r12
0x00014287bb26:  5f                    pop       rdi
0x00014287bb27:  5e                    pop       rsi
0x00014287bb28:  c3                    ret       
0x00014287bb29:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014287bb2e:  e8bdf2f3fd            call      0x1407badf0
0x00014287bb33:  488d1506b14805        lea       rdx, [rip + 0x548b106]
0x00014287bb3a:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014287bb3f:  e80c752c03            call      0x145b43050
0x00014287bb44:  90                    nop       
0x00014287bb45:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014287bb4a:  e8a1f2f3fd            call      0x1407badf0
0x00014287bb4f:  488d15eab04805        lea       rdx, [rip + 0x548b0ea]
0x00014287bb56:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014287bb5b:  e8f0742c03            call      0x145b43050
0x00014287bb60:  90                    nop       
0x00014287bb61:  8bc8                  mov       ecx, eax
0x00014287bb63:  e818822a03            call      0x145b23d80
0x00014287bb68:  cc                    int3      
0x00014287bb69:  8bc8                  mov       ecx, eax
0x00014287bb6b:  e810822a03            call      0x145b23d80
0x00014287bb70:  cc                    int3      
0x00014287bb71:  cc                    int3      
0x00014287bb72:  cc                    int3      
0x00014287bb73:  cc                    int3      
0x00014287bb74:  cc                    int3      
0x00014287bb75:  cc                    int3      
0x00014287bb76:  cc                    int3      
0x00014287bb77:  cc                    int3      
0x00014287bb78:  cc                    int3      
0x00014287bb79:  cc                    int3      
0x00014287bb7a:  cc                    int3      
0x00014287bb7b:  cc                    int3      
0x00014287bb7c:  cc                    int3      
0x00014287bb7d:  cc                    int3      
0x00014287bb7e:  cc                    int3      
0x00014287bb7f:  cc                    int3      
0x00014287bb80:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014287bb85:  57                    push      rdi
0x00014287bb86:  4883ec20              sub       rsp, 0x20
0x00014287bb8a:  8bda                  mov       ebx, edx
0x00014287bb8c:  488bf9                mov       rdi, rcx
0x00014287bb8f:  e88c000000            call      0x14287bc20
0x00014287bb94:  f6c301                test      bl, 1
0x00014287bb97:  7409                  je        0x14287bba2
0x00014287bb99:  488bcf                mov       rcx, rdi
0x00014287bb9c:  e80f750c02            call      0x1449430b0
0x00014287bba1:  90                    nop       
0x00014287bba2:  488bc7                mov       rax, rdi
0x00014287bba5:  488b5c2430            mov       rbx, qword ptr [rsp + 0x30]
0x00014287bbaa:  4883c420              add       rsp, 0x20
0x00014287bbae:  5f                    pop       rdi
0x00014287bbaf:  c3                    ret       
