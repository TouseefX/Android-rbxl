; RakPeer vtable slot 0
; rva 0x287bb80
0x14287bb80:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x14287bb85:  57                   push      rdi
0x14287bb86:  4883ec20             sub       rsp, 0x20
0x14287bb8a:  8bda                 mov       ebx, edx
0x14287bb8c:  488bf9               mov       rdi, rcx
0x14287bb8f:  e88c000000           call      0x14287bc20
0x14287bb94:  f6c301               test      bl, 1
0x14287bb97:  7409                 je        0x14287bba2
0x14287bb99:  488bcf               mov       rcx, rdi
0x14287bb9c:  e80f750c02           call      0x1449430b0
0x14287bba1:  90                   nop       
0x14287bba2:  488bc7               mov       rax, rdi
0x14287bba5:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14287bbaa:  4883c420             add       rsp, 0x20
0x14287bbae:  5f                   pop       rdi
0x14287bbaf:  c3                   ret       
