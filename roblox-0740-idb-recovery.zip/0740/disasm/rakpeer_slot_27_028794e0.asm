; RakPeer vtable slot 27
; rva 0x28794e0
0x1428794e0:  85d2                 test      edx, edx
0x1428794e2:  7831                 js        0x142879515
0x1428794e4:  4863c2               movsxd    rax, edx
0x1428794e7:  483b8170030000       cmp       rax, qword ptr [rcx + 0x370]
0x1428794ee:  7325                 jae       0x142879515
0x1428794f0:  4869d050100000       imul      rdx, rax, 0x1050
0x1428794f7:  488b8168030000       mov       rax, qword ptr [rcx + 0x368]
0x1428794fe:  4489841044100000     mov       dword ptr [rax + rdx + 0x1044], r8d
0x142879506:  488b8168030000       mov       rax, qword ptr [rcx + 0x368]
0x14287950d:  c684104810000001     mov       byte ptr [rax + rdx + 0x1048], 1
0x142879515:  c3                   ret       
0x142879516:  cc                   int3      
0x142879517:  cc                   int3      
0x142879518:  cc                   int3      
0x142879519:  cc                   int3      
0x14287951a:  cc                   int3      
0x14287951b:  cc                   int3      
0x14287951c:  cc                   int3      
0x14287951d:  cc                   int3      
0x14287951e:  cc                   int3      
0x14287951f:  cc                   int3      
