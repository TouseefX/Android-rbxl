; RakPeer vtable slot 75
; rva 0x2884550
0x142884550:  4883ec28             sub       rsp, 0x28
0x142884554:  0fb78112010000       movzx     eax, word ptr [rcx + 0x112]
0x14288455b:  3bd0                 cmp       edx, eax
0x14288455d:  7d3b                 jge       0x14288459a
0x14288455f:  4863c2               movsxd    rax, edx
0x142884562:  4c69c8d8160000       imul      r9, rax, 0x16d8
0x142884569:  488b8150030000       mov       rax, qword ptr [rcx + 0x350]
0x142884570:  410fb61401           movzx     edx, byte ptr [r9 + rax]
0x142884575:  90                   nop       
0x142884576:  84d2                 test      dl, dl
0x142884578:  7420                 je        0x14288459a
0x14288457a:  488b8950030000       mov       rcx, qword ptr [rcx + 0x350]
0x142884581:  498bd0               mov       rdx, r8
0x142884584:  4881c188010000       add       rcx, 0x188
0x14288458b:  4903c9               add       rcx, r9
0x14288458e:  e8dd040300           call      0x1428b4a70
0x142884593:  b001                 mov       al, 1
0x142884595:  4883c428             add       rsp, 0x28
0x142884599:  c3                   ret       
0x14288459a:  32c0                 xor       al, al
0x14288459c:  4883c428             add       rsp, 0x28
0x1428845a0:  c3                   ret       
0x1428845a1:  cc                   int3      
0x1428845a2:  cc                   int3      
0x1428845a3:  cc                   int3      
0x1428845a4:  cc                   int3      
0x1428845a5:  cc                   int3      
0x1428845a6:  cc                   int3      
0x1428845a7:  cc                   int3      
0x1428845a8:  cc                   int3      
0x1428845a9:  cc                   int3      
0x1428845aa:  cc                   int3      
0x1428845ab:  cc                   int3      
0x1428845ac:  cc                   int3      
0x1428845ad:  cc                   int3      
0x1428845ae:  cc                   int3      
0x1428845af:  cc                   int3      
0x1428845b0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x1428845b5:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x1428845ba:  57                   push      rdi
0x1428845bb:  4883ec20             sub       rsp, 0x20
0x1428845bf:  0f100a               movups    xmm1, xmmword ptr [rdx]
0x1428845c2:  498bf0               mov       rsi, r8
0x1428845c5:  4c8bd1               mov       r10, rcx
0x1428845c8:  0f104210             movups    xmm0, xmmword ptr [rdx + 0x10]
0x1428845cc:  66490f7ec9           movq      r9, xmm1
0x1428845d1:  0f290c24             movaps    xmmword ptr [rsp], xmm1
0x1428845d5:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x1428845da:  498bc1               mov       rax, r9
0x1428845dd:  48c1e810             shr       rax, 0x10
0x1428845e1:  663b0562b25605       cmp       ax, word ptr [rip + 0x556b262]
0x1428845e8:  0f29442410           movaps    xmmword ptr [rsp + 0x10], xmm0
0x1428845ed:  4c8b5c2410           mov       r11, qword ptr [rsp + 0x10]
0x1428845f2:  753d                 jne       0x142884631
0x1428845f4:  66443b0d4cb25605     cmp       r9w, word ptr [rip + 0x556b24c]
0x1428845fc:  7533                 jne       0x142884631
0x1428845fe:  664183f902           cmp       r9w, 2
0x142884603:  750f                 jne       0x142884614
0x142884605:  498bc1               mov       rax, r9
0x142884608:  48c1e820             shr       rax, 0x20
0x14288460c:  3b053ab25605         cmp       eax, dword ptr [rip + 0x556b23a]
0x142884612:  eb17                 jmp       0x14288462b
0x142884614:  664183f917           cmp       r9w, 0x17
0x142884619:  7516                 jne       0x142884631
0x14288461b:  483b1d2eb25605       cmp       rbx, qword ptr [rip + 0x556b22e]
0x142884622:  750d                 jne       0x142884631
0x142884624:  4c3b1d2db25605       cmp       r11, qword ptr [rip + 0x556b22d]
0x14288462b:  0f840c010000         je        0x14288473d
0x142884631:  33d2                 xor       edx, edx
0x142884633:  448d42ff             lea       r8d, [rdx - 1]
0x142884637:  663b9112010000       cmp       dx, word ptr [rcx + 0x112]
0x14288463e:  0f83f9000000         jae       0x14288473d
0x142884644:  498b8a50030000       mov       rcx, qword ptr [r10 + 0x350]
0x14288464b:  4863c2               movsxd    rax, edx
0x14288464e:  4869f8d8160000       imul      rdi, rax, 0x16d8
0x142884655:  0fb7442402           movzx     eax, word ptr [rsp + 2]
0x14288465a:  4803cf               add       rcx, rdi
0x14288465d:  66394106             cmp       word ptr [rcx + 6], ax
0x142884661:  754f                 jne       0x1428846b2
0x142884663:  0fb74104             movzx     eax, word ptr [rcx + 4]
0x142884667:  66413bc1             cmp       ax, r9w
0x14288466b:  7545                 jne       0x1428846b2
0x14288466d:  6683f802             cmp       ax, 2
0x142884671:  750b                 jne       0x14288467e
0x142884673:  8b442404             mov       eax, dword ptr [rsp + 4]
0x142884677:  394108               cmp       dword ptr [rcx + 8], eax
0x14288467a:  7414                 je        0x142884690
0x14288467c:  eb34                 jmp       0x1428846b2
0x14288467e:  6683f817             cmp       ax, 0x17
0x142884682:  752e                 jne       0x1428846b2
0x142884684:  4839590c             cmp       qword ptr [rcx + 0xc], rbx
0x142884688:  7528                 jne       0x1428846b2
0x14288468a:  4c395914             cmp       qword ptr [rcx + 0x14], r11
0x14288468e:  7522                 jne       0x1428846b2
0x142884690:  0fb601               movzx     eax, byte ptr [rcx]
0x142884693:  90                   nop       
0x142884694:  84c0                 test      al, al
0x142884696:  0f8595000000         jne       0x142884731
0x14288469c:  4c8b5c2410           mov       r11, qword ptr [rsp + 0x10]
0x1428846a1:  4183f8ff             cmp       r8d, -1
0x1428846a5:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x1428846aa:  4c8b0c24             mov       r9, qword ptr [rsp]
0x1428846ae:  440f44c2             cmove     r8d, edx
0x1428846b2:  410fb78212010000     movzx     eax, word ptr [r10 + 0x112]
0x1428846ba:  ffc2                 inc       edx
0x1428846bc:  3bd0                 cmp       edx, eax
0x1428846be:  7284                 jb        0x142884644
0x1428846c0:  4183f8ff             cmp       r8d, -1
0x1428846c4:  7477                 je        0x14288473d
0x1428846c6:  4963c0               movsxd    rax, r8d
0x1428846c9:  4869c8d8160000       imul      rcx, rax, 0x16d8
0x1428846d0:  49038a50030000       add       rcx, qword ptr [r10 + 0x350]
0x1428846d7:  4885c9               test      rcx, rcx
0x1428846da:  7461                 je        0x14288473d
0x1428846dc:  410fb68208010000     movzx     eax, byte ptr [r10 + 0x108]
0x1428846e4:  90                   nop       
0x1428846e5:  84c0                 test      al, al
0x1428846e7:  7554                 jne       0x14288473d
0x1428846e9:  0f108158050000       movups    xmm0, xmmword ptr [rcx + 0x558]
0x1428846f0:  b001                 mov       al, 1
0x1428846f2:  0f1106               movups    xmmword ptr [rsi], xmm0
0x1428846f5:  0f108968050000       movups    xmm1, xmmword ptr [rcx + 0x568]
0x1428846fc:  0f114e10             movups    xmmword ptr [rsi + 0x10], xmm1
0x142884700:  0f108178050000       movups    xmm0, xmmword ptr [rcx + 0x578]
0x142884707:  0f114620             movups    xmmword ptr [rsi + 0x20], xmm0
0x14288470b:  0f108988050000       movups    xmm1, xmmword ptr [rcx + 0x588]
0x142884712:  0f114e30             movups    xmmword ptr [rsi + 0x30], xmm1
0x142884716:  0f108198050000       movups    xmm0, xmmword ptr [rcx + 0x598]
0x14288471d:  0f114640             movups    xmmword ptr [rsi + 0x40], xmm0
0x142884721:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142884726:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x14288472b:  4883c420             add       rsp, 0x20
0x14288472f:  5f                   pop       rdi
0x142884730:  c3                   ret       
0x142884731:  498b8a50030000       mov       rcx, qword ptr [r10 + 0x350]
0x142884738:  4803cf               add       rcx, rdi
0x14288473b:  eb9a                 jmp       0x1428846d7
0x14288473d:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142884742:  32c0                 xor       al, al
0x142884744:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142884749:  4883c420             add       rsp, 0x20
0x14288474d:  5f                   pop       rdi
0x14288474e:  c3                   ret       
0x14288474f:  cc                   int3      
0x142884750:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x142884755:  48896c2410           mov       qword ptr [rsp + 0x10], rbp
0x14288475a:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x14288475f:  57                   push      rdi
0x142884760:  4883ec40             sub       rsp, 0x40
0x142884764:  0f100a               movups    xmm1, xmmword ptr [rdx]
0x142884767:  498bf0               mov       rsi, r8
0x14288476a:  4c8bd1               mov       r10, rcx
0x14288476d:  0f104210             movups    xmm0, xmmword ptr [rdx + 0x10]
0x142884771:  66490f7ec9           movq      r9, xmm1
0x142884776:  0f294c2420           movaps    xmmword ptr [rsp + 0x20], xmm1
0x14288477b:  488b5c2428           mov       rbx, qword ptr [rsp + 0x28]
0x142884780:  498bc1               mov       rax, r9
0x142884783:  48c1e810             shr       rax, 0x10
0x142884787:  663b05bcb05605       cmp       ax, word ptr [rip + 0x556b0bc]
0x14288478e:  0f29442430           movaps    xmmword ptr [rsp + 0x30], xmm0
0x142884793:  4c8b5c2430           mov       r11, qword ptr [rsp + 0x30]
0x142884798:  753d                 jne       0x1428847d7
0x14288479a:  66443b0da6b05605     cmp       r9w, word ptr [rip + 0x556b0a6]
0x1428847a2:  7533                 jne       0x1428847d7
0x1428847a4:  664183f902           cmp       r9w, 2
0x1428847a9:  750f                 jne       0x1428847ba
0x1428847ab:  498bc1               mov       rax, r9
0x1428847ae:  48c1e820             shr       rax, 0x20
0x1428847b2:  3b0594b05605         cmp       eax, dword ptr [rip + 0x556b094]
0x1428847b8:  eb17                 jmp       0x1428847d1
0x1428847ba:  664183f917           cmp       r9w, 0x17
0x1428847bf:  7516                 jne       0x1428847d7
0x1428847c1:  483b1d88b05605       cmp       rbx, qword ptr [rip + 0x556b088]
0x1428847c8:  750d                 jne       0x1428847d7
0x1428847ca:  4c3b1d87b05605       cmp       r11, qword ptr [rip + 0x556b087]
0x1428847d1:  0f8463010000         je        0x14288493a
0x1428847d7:  33ed                 xor       ebp, ebp
0x1428847d9:  baffffffff           mov       edx, 0xffffffff
0x1428847de:  448bc5               mov       r8d, ebp
0x1428847e1:  663ba912010000       cmp       bp, word ptr [rcx + 0x112]
0x1428847e8:  0f834c010000         jae       0x14288493a
0x1428847ee:  6690                 nop       
0x1428847f0:  0fb74c2422           movzx     ecx, word ptr [rsp + 0x22]
0x1428847f5:  4963c0               movsxd    rax, r8d
0x1428847f8:  4869f8d8160000       imul      rdi, rax, 0x16d8
0x1428847ff:  498b8250030000       mov       rax, qword ptr [r10 + 0x350]
0x142884806:  66394c0706           cmp       word ptr [rdi + rax + 6], cx
0x14288480b:  7554                 jne       0x142884861
0x14288480d:  0fb74c0704           movzx     ecx, word ptr [rdi + rax + 4]
0x142884812:  66413bc9             cmp       cx, r9w
0x142884816:  7549                 jne       0x142884861
0x142884818:  6683f902             cmp       cx, 2
0x14288481c:  750c                 jne       0x14288482a
0x14288481e:  8b4c2424             mov       ecx, dword ptr [rsp + 0x24]
0x142884822:  394c0708             cmp       dword ptr [rdi + rax + 8], ecx
0x142884826:  7416                 je        0x14288483e
0x142884828:  eb37                 jmp       0x142884861
0x14288482a:  6683f917             cmp       cx, 0x17
0x14288482e:  7531                 jne       0x142884861
0x142884830:  48395c070c           cmp       qword ptr [rdi + rax + 0xc], rbx
0x142884835:  752a                 jne       0x142884861
0x142884837:  4c395c0714           cmp       qword ptr [rdi + rax + 0x14], r11
0x14288483c:  7523                 jne       0x142884861
0x14288483e:  0fb60c07             movzx     ecx, byte ptr [rdi + rax]
0x142884842:  90                   nop       
0x142884843:  84c9                 test      cl, cl
0x142884845:  0f85e0000000         jne       0x14288492b
0x14288484b:  4c8b5c2430           mov       r11, qword ptr [rsp + 0x30]
0x142884850:  83faff               cmp       edx, -1
0x142884853:  488b5c2428           mov       rbx, qword ptr [rsp + 0x28]
0x142884858:  4c8b4c2420           mov       r9, qword ptr [rsp + 0x20]
0x14288485d:  410f44d0             cmove     edx, r8d
0x142884861:  410fb78212010000     movzx     eax, word ptr [r10 + 0x112]
0x142884869:  41ffc0               inc       r8d
0x14288486c:  443bc0               cmp       r8d, eax
0x14288486f:  0f827bffffff         jb        0x1428847f0
0x142884875:  83faff               cmp       edx, -1
0x142884878:  0f84bc000000         je        0x14288493a
0x14288487e:  4863c2               movsxd    rax, edx
0x142884881:  4869c8d8160000       imul      rcx, rax, 0x16d8
0x142884888:  49038a50030000       add       rcx, qword ptr [r10 + 0x350]
0x14288488f:  4885c9               test      rcx, rcx
0x142884892:  0f84a2000000         je        0x14288493a
0x142884898:  410fb68208010000     movzx     eax, byte ptr [r10 + 0x108]
0x1428848a0:  90                   nop       
0x1428848a1:  84c0                 test      al, al
0x1428848a3:  0f8591000000         jne       0x14288493a
0x1428848a9:  488b89780d0000       mov       rcx, qword ptr [rcx + 0xd78]
0x1428848b0:  488d542420           lea       rdx, [rsp + 0x20]
0x1428848b5:  0f57c0               xorps     xmm0, xmm0
0x1428848b8:  48896c2430           mov       qword ptr [rsp + 0x30], rbp
0x1428848bd:  f30f7f442420         movdqu    xmmword ptr [rsp + 0x20], xmm0
0x1428848c3:  40886c2438           mov       byte ptr [rsp + 0x38], bpl
0x1428848c8:  488b01               mov       rax, qword ptr [rcx]
0x1428848cb:  488b80e8000000       mov       rax, qword ptr [rax + 0xe8]
0x1428848d2:  ff1560b48b03         call      qword ptr [rip + 0x38bb460]
0x1428848d8:  8b442420             mov       eax, dword ptr [rsp + 0x20]
0x1428848dc:  85c0                 test      eax, eax
0x1428848de:  0f48c5               cmovs     eax, ebp
0x1428848e1:  8906                 mov       dword ptr [rsi], eax
0x1428848e3:  8b442424             mov       eax, dword ptr [rsp + 0x24]
0x1428848e7:  85c0                 test      eax, eax
0x1428848e9:  0f48c5               cmovs     eax, ebp
0x1428848ec:  894604               mov       dword ptr [rsi + 4], eax
0x1428848ef:  8b442428             mov       eax, dword ptr [rsp + 0x28]
0x1428848f3:  85c0                 test      eax, eax
0x1428848f5:  0f48c5               cmovs     eax, ebp
0x1428848f8:  894608               mov       dword ptr [rsi + 8], eax
0x1428848fb:  8b44242c             mov       eax, dword ptr [rsp + 0x2c]
0x1428848ff:  85c0                 test      eax, eax
0x142884901:  0f48c5               cmovs     eax, ebp
0x142884904:  89460c               mov       dword ptr [rsi + 0xc], eax
0x142884907:  8b442430             mov       eax, dword ptr [rsp + 0x30]
0x14288490b:  85c0                 test      eax, eax
0x14288490d:  0f48c5               cmovs     eax, ebp
0x142884910:  894610               mov       dword ptr [rsi + 0x10], eax
0x142884913:  8b442434             mov       eax, dword ptr [rsp + 0x34]
0x142884917:  85c0                 test      eax, eax
0x142884919:  0f48c5               cmovs     eax, ebp
0x14288491c:  894614               mov       dword ptr [rsi + 0x14], eax
0x14288491f:  0fb6442438           movzx     eax, byte ptr [rsp + 0x38]
0x142884924:  884618               mov       byte ptr [rsi + 0x18], al
0x142884927:  b001                 mov       al, 1
0x142884929:  eb11                 jmp       0x14288493c
0x14288492b:  498b8a50030000       mov       rcx, qword ptr [r10 + 0x350]
0x142884932:  4803cf               add       rcx, rdi
0x142884935:  e955ffffff           jmp       0x14288488f
0x14288493a:  32c0                 xor       al, al
0x14288493c:  488b5c2450           mov       rbx, qword ptr [rsp + 0x50]
0x142884941:  488b6c2458           mov       rbp, qword ptr [rsp + 0x58]
0x142884946:  488b742460           mov       rsi, qword ptr [rsp + 0x60]
0x14288494b:  4883c440             add       rsp, 0x40
0x14288494f:  5f                   pop       rdi
0x142884950:  c3                   ret       
0x142884951:  cc                   int3      
0x142884952:  cc                   int3      
0x142884953:  cc                   int3      
0x142884954:  cc                   int3      
0x142884955:  cc                   int3      
0x142884956:  cc                   int3      
0x142884957:  cc                   int3      
0x142884958:  cc                   int3      
0x142884959:  cc                   int3      
0x14288495a:  cc                   int3      
0x14288495b:  cc                   int3      
0x14288495c:  cc                   int3      
0x14288495d:  cc                   int3      
0x14288495e:  cc                   int3      
0x14288495f:  cc                   int3      
