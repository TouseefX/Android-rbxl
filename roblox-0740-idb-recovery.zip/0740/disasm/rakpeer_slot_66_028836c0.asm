; RakPeer vtable slot 66
; rva 0x28836c0
0x1428836c0:  488991f80e0000       mov       qword ptr [rcx + 0xef8], rdx
0x1428836c7:  c3                   ret       
0x1428836c8:  cc                   int3      
0x1428836c9:  cc                   int3      
0x1428836ca:  cc                   int3      
0x1428836cb:  cc                   int3      
0x1428836cc:  cc                   int3      
0x1428836cd:  cc                   int3      
0x1428836ce:  cc                   int3      
0x1428836cf:  cc                   int3      
