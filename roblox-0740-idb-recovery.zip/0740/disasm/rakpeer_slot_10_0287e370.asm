; RakPeer vtable slot 10
; rva 0x287e370
0x14287e370:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x14287e375:  57                   push      rdi
0x14287e376:  4883ec20             sub       rsp, 0x20
0x14287e37a:  b8ff000000           mov       eax, 0xff
0x14287e37f:  488bf9               mov       rdi, rcx
0x14287e382:  443bc0               cmp       r8d, eax
0x14287e385:  410f4ec0             cmovle    eax, r8d
0x14287e389:  33db                 xor       ebx, ebx
0x14287e38b:  4885d2               test      rdx, rdx
0x14287e38e:  0f45d8               cmovne    ebx, eax
0x14287e391:  85db                 test      ebx, ebx
0x14287e393:  7e20                 jle       0x14287e3b5
0x14287e395:  4c63c3               movsxd    r8, ebx
0x14287e398:  4881c149020000       add       rcx, 0x249
0x14287e39f:  e8fc4d2c03           call      0x145b431a0
0x14287e3a4:  889f48020000         mov       byte ptr [rdi + 0x248], bl
0x14287e3aa:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14287e3af:  4883c420             add       rsp, 0x20
0x14287e3b3:  5f                   pop       rdi
0x14287e3b4:  c3                   ret       
0x14287e3b5:  889948020000         mov       byte ptr [rcx + 0x248], bl
0x14287e3bb:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14287e3c0:  4883c420             add       rsp, 0x20
0x14287e3c4:  5f                   pop       rdi
0x14287e3c5:  c3                   ret       
0x14287e3c6:  cc                   int3      
0x14287e3c7:  cc                   int3      
0x14287e3c8:  cc                   int3      
0x14287e3c9:  cc                   int3      
0x14287e3ca:  cc                   int3      
0x14287e3cb:  cc                   int3      
0x14287e3cc:  cc                   int3      
0x14287e3cd:  cc                   int3      
0x14287e3ce:  cc                   int3      
0x14287e3cf:  cc                   int3      
0x14287e3d0:  0fb68148020000       movzx     eax, byte ptr [rcx + 0x248]
0x14287e3d7:  4c8bca               mov       r9, rdx
0x14287e3da:  488bd1               mov       rdx, rcx
0x14287e3dd:  4d85c9               test      r9, r9
0x14287e3e0:  7504                 jne       0x14287e3e6
0x14287e3e2:  418900               mov       dword ptr [r8], eax
0x14287e3e5:  c3                   ret       
0x14287e3e6:  8bc8                 mov       ecx, eax
0x14287e3e8:  418b00               mov       eax, dword ptr [r8]
0x14287e3eb:  3bc1                 cmp       eax, ecx
0x14287e3ed:  7e05                 jle       0x14287e3f4
0x14287e3ef:  418908               mov       dword ptr [r8], ecx
0x14287e3f2:  8bc1                 mov       eax, ecx
0x14287e3f4:  85c0                 test      eax, eax
0x14287e3f6:  7e12                 jle       0x14287e40a
0x14287e3f8:  4c63c0               movsxd    r8, eax
0x14287e3fb:  4881c249020000       add       rdx, 0x249
0x14287e402:  498bc9               mov       rcx, r9
0x14287e405:  e9964d2c03           jmp       0x145b431a0
0x14287e40a:  c3                   ret       
0x14287e40b:  cc                   int3      
0x14287e40c:  cc                   int3      
0x14287e40d:  cc                   int3      
0x14287e40e:  cc                   int3      
0x14287e40f:  cc                   int3      
0x14287e410:  488b4208             mov       rax, qword ptr [rdx + 8]
0x14287e414:  4c8bc9               mov       r9, rcx
0x14287e417:  4885c0               test      rax, rax
0x14287e41a:  7404                 je        0x14287e420
0x14287e41c:  f0ff4008             lock inc  dword ptr [rax + 8]
0x14287e420:  488b02               mov       rax, qword ptr [rdx]
0x14287e423:  4c8b4208             mov       r8, qword ptr [rdx + 8]
0x14287e427:  488981900e0000       mov       qword ptr [rcx + 0xe90], rax
0x14287e42e:  488b89980e0000       mov       rcx, qword ptr [rcx + 0xe98]
0x14287e435:  4d8981980e0000       mov       qword ptr [r9 + 0xe98], r8
0x14287e43c:  4885c9               test      rcx, rcx
0x14287e43f:  0f85cbaaf4fd         jne       0x1407c8f10
0x14287e445:  c3                   ret       
0x14287e446:  cc                   int3      
0x14287e447:  cc                   int3      
0x14287e448:  cc                   int3      
0x14287e449:  cc                   int3      
0x14287e44a:  cc                   int3      
0x14287e44b:  cc                   int3      
0x14287e44c:  cc                   int3      
0x14287e44d:  cc                   int3      
0x14287e44e:  cc                   int3      
0x14287e44f:  cc                   int3      
