; RakPeer vtable slot 7
; rva 0x287e030
0x14287e030:  66899114010000       mov       word ptr [rcx + 0x114], dx
0x14287e037:  c3                   ret       
0x14287e038:  cc                   int3      
0x14287e039:  cc                   int3      
0x14287e03a:  cc                   int3      
0x14287e03b:  cc                   int3      
0x14287e03c:  cc                   int3      
0x14287e03d:  cc                   int3      
0x14287e03e:  cc                   int3      
0x14287e03f:  cc                   int3      
0x14287e040:  0fb78114010000       movzx     eax, word ptr [rcx + 0x114]
0x14287e047:  c3                   ret       
0x14287e048:  cc                   int3      
0x14287e049:  cc                   int3      
0x14287e04a:  cc                   int3      
0x14287e04b:  cc                   int3      
0x14287e04c:  cc                   int3      
0x14287e04d:  cc                   int3      
0x14287e04e:  cc                   int3      
0x14287e04f:  cc                   int3      
0x14287e050:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x14287e055:  48896c2410           mov       qword ptr [rsp + 0x10], rbp
0x14287e05a:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x14287e05f:  48897c2420           mov       qword ptr [rsp + 0x20], rdi
0x14287e064:  4156                 push      r14
0x14287e066:  4881ecc0000000       sub       rsp, 0xc0
0x14287e06d:  33ff                 xor       edi, edi
0x14287e06f:  48897c2428           mov       qword ptr [rsp + 0x28], rdi
0x14287e074:  48897c2420           mov       qword ptr [rsp + 0x20], rdi
0x14287e079:  48897c2438           mov       qword ptr [rsp + 0x38], rdi
0x14287e07e:  48897c2430           mov       qword ptr [rsp + 0x30], rdi
0x14287e083:  488b01               mov       rax, qword ptr [rcx]
0x14287e086:  4c8d442430           lea       r8, [rsp + 0x30]
0x14287e08b:  488d542420           lea       rdx, [rsp + 0x20]
0x14287e090:  488b8020010000       mov       rax, qword ptr [rax + 0x120]
0x14287e097:  ff159b1c8c03         call      qword ptr [rip + 0x38c1c9b]
0x14287e09d:  0fb76c2428           movzx     ebp, word ptr [rsp + 0x28]
0x14287e0a2:  4c8d35e7dd1106       lea       r14, [rip + 0x611dde7]
0x14287e0a9:  397c243c             cmp       dword ptr [rsp + 0x3c], edi
0x14287e0ad:  0f8639010000         jbe       0x14287e1ec
0x14287e0b3:  4c8b542430           mov       r10, qword ptr [rsp + 0x30]
0x14287e0b8:  4d85d2               test      r10, r10
0x14287e0bb:  0f842b010000         je        0x14287e1ec
0x14287e0c1:  0fb60543bc9805       movzx     eax, byte ptr [rip + 0x598bc43]
0x14287e0c8:  90                   nop       
0x14287e0c9:  498bca               mov       rcx, r10
0x14287e0cc:  84c0                 test      al, al
0x14287e0ce:  740a                 je        0x14287e0da
0x14287e0d0:  e8cbd1f3fd           call      0x1407bb2a0
0x14287e0d5:  e912010000           jmp       0x14287e1ec
0x14287e0da:  48c1e910             shr       rcx, 0x10
0x14287e0de:  488bd1               mov       rdx, rcx
0x14287e0e1:  81e2ff1f0000         and       edx, 0x1fff
0x14287e0e7:  48c1e90d             shr       rcx, 0xd
0x14287e0eb:  488b058e319305       mov       rax, qword ptr [rip + 0x593318e]
0x14287e0f2:  488b0cc8             mov       rcx, qword ptr [rax + rcx*8]
0x14287e0f6:  90                   nop       
0x14287e0f7:  488b0cd1             mov       rcx, qword ptr [rcx + rdx*8]
0x14287e0fb:  4885c9               test      rcx, rcx
0x14287e0fe:  7505                 jne       0x14287e105
0x14287e100:  488bf7               mov       rsi, rdi
0x14287e103:  eb1a                 jmp       0x14287e11f
0x14287e105:  488b01               mov       rax, qword ptr [rcx]
0x14287e108:  d0e8                 shr       al, 1
0x14287e10a:  a801                 test      al, 1
0x14287e10c:  7506                 jne       0x14287e114
0x14287e10e:  488b7128             mov       rsi, qword ptr [rcx + 0x28]
0x14287e112:  eb0b                 jmp       0x14287e11f
0x14287e114:  498bd2               mov       rdx, r10
0x14287e117:  e884d6f3fd           call      0x1407bb7a0
0x14287e11c:  488bf0               mov       rsi, rax
0x14287e11f:  4c8bc6               mov       r8, rsi
0x14287e122:  498bd2               mov       rdx, r10
0x14287e125:  488d4c2440           lea       rcx, [rsp + 0x40]
0x14287e12a:  e8d11d1002           call      0x14497ff00
0x14287e12f:  0f1000               movups    xmm0, xmmword ptr [rax]
0x14287e132:  0f11442468           movups    xmmword ptr [rsp + 0x68], xmm0
0x14287e137:  4c8d460f             lea       r8, [rsi + 0xf]
0x14287e13b:  4983e0f0             and       r8, 0xfffffffffffffff0
0x14287e13f:  4983c010             add       r8, 0x10
0x14287e143:  660f7ec0             movd      eax, xmm0
0x14287e147:  3d00040000           cmp       eax, 0x400
0x14287e14c:  7218                 jb        0x14287e166
0x14287e14e:  803d3ec0980500       cmp       byte ptr [rip + 0x598c03e], 0
0x14287e155:  7445                 je        0x14287e19c
0x14287e157:  803dea03d50500       cmp       byte ptr [rip + 0x5d503ea], 0
0x14287e15e:  0f85eb010000         jne       0x14287e34f
0x14287e164:  eb36                 jmp       0x14287e19c
0x14287e166:  498bd0               mov       rdx, r8
0x14287e169:  48f7da               neg       rdx
0x14287e16c:  8bc8                 mov       ecx, eax
0x14287e16e:  48c1e106             shl       rcx, 6
0x14287e172:  488bc2               mov       rax, rdx
0x14287e175:  f04a0fc10431         lock xadd qword ptr [rcx + r14], rax
0x14287e17b:  0fb60d2dc5e405       movzx     ecx, byte ptr [rip + 0x5e4c52d]
0x14287e182:  90                   nop       
0x14287e183:  84c9                 test      cl, cl
0x14287e185:  7415                 je        0x14287e19c
0x14287e187:  488b05fadc1206       mov       rax, qword ptr [rip + 0x612dcfa]
0x14287e18e:  4c3bc0               cmp       r8, rax
0x14287e191:  7309                 jae       0x14287e19c
0x14287e193:  f0480fc115ecdc1206   lock xadd qword ptr [rip + 0x612dcec], rdx
0x14287e19c:  498bca               mov       rcx, r10
0x14287e19f:  e8fcd0f3fd           call      0x1407bb2a0
0x14287e1a4:  803d10c5e40500       cmp       byte ptr [rip + 0x5e4c510], 0
0x14287e1ab:  7420                 je        0x14287e1cd
0x14287e1ad:  e88efb0e02           call      0x14496dd40
0x14287e1b2:  488bd8               mov       rbx, rax
0x14287e1b5:  ff4004               inc       dword ptr [rax + 4]
0x14287e1b8:  0f57c0               xorps     xmm0, xmm0
0x14287e1bb:  e800782e03           call      0x145b659c0
0x14287e1c0:  48c1f804             sar       rax, 4
0x14287e1c4:  01431c               add       dword ptr [rbx + 0x1c], eax
0x14287e1c7:  48017310             add       qword ptr [rbx + 0x10], rsi
0x14287e1cb:  eb1f                 jmp       0x14287e1ec
0x14287e1cd:  ff0509991506         inc       dword ptr [rip + 0x6159909]
0x14287e1d3:  0f57c0               xorps     xmm0, xmm0
0x14287e1d6:  e8e5772e03           call      0x145b659c0
0x14287e1db:  48c1f804             sar       rax, 4
0x14287e1df:  01050f991506         add       dword ptr [rip + 0x615990f], eax
0x14287e1e5:  480135fc981506       add       qword ptr [rip + 0x61598fc], rsi
0x14287e1ec:  837c242c00           cmp       dword ptr [rsp + 0x2c], 0
0x14287e1f1:  0f8637010000         jbe       0x14287e32e
0x14287e1f7:  4c8b542420           mov       r10, qword ptr [rsp + 0x20]
0x14287e1fc:  4d85d2               test      r10, r10
0x14287e1ff:  0f8429010000         je        0x14287e32e
0x14287e205:  0fb605ffba9805       movzx     eax, byte ptr [rip + 0x598baff]
0x14287e20c:  90                   nop       
0x14287e20d:  498bca               mov       rcx, r10
0x14287e210:  84c0                 test      al, al
0x14287e212:  740a                 je        0x14287e21e
0x14287e214:  e887d0f3fd           call      0x1407bb2a0
0x14287e219:  e910010000           jmp       0x14287e32e
0x14287e21e:  48c1e910             shr       rcx, 0x10
0x14287e222:  488bd1               mov       rdx, rcx
0x14287e225:  81e2ff1f0000         and       edx, 0x1fff
0x14287e22b:  48c1e90d             shr       rcx, 0xd
0x14287e22f:  488b054a309305       mov       rax, qword ptr [rip + 0x593304a]
0x14287e236:  488b0cc8             mov       rcx, qword ptr [rax + rcx*8]
0x14287e23a:  90                   nop       
0x14287e23b:  488b0cd1             mov       rcx, qword ptr [rcx + rdx*8]
0x14287e23f:  4885c9               test      rcx, rcx
0x14287e242:  741a                 je        0x14287e25e
0x14287e244:  488b01               mov       rax, qword ptr [rcx]
0x14287e247:  d0e8                 shr       al, 1
0x14287e249:  a801                 test      al, 1
0x14287e24b:  7506                 jne       0x14287e253
0x14287e24d:  488b7928             mov       rdi, qword ptr [rcx + 0x28]
0x14287e251:  eb0b                 jmp       0x14287e25e
0x14287e253:  498bd2               mov       rdx, r10
0x14287e256:  e845d5f3fd           call      0x1407bb7a0
0x14287e25b:  488bf8               mov       rdi, rax
0x14287e25e:  4c8bc7               mov       r8, rdi
0x14287e261:  498bd2               mov       rdx, r10
0x14287e264:  488d4c2450           lea       rcx, [rsp + 0x50]
0x14287e269:  e8921c1002           call      0x14497ff00
0x14287e26e:  0f1000               movups    xmm0, xmmword ptr [rax]
0x14287e271:  0f11842498000000     movups    xmmword ptr [rsp + 0x98], xmm0
0x14287e279:  4c8d470f             lea       r8, [rdi + 0xf]
0x14287e27d:  4983e0f0             and       r8, 0xfffffffffffffff0
0x14287e281:  4983c010             add       r8, 0x10
0x14287e285:  660f7ec0             movd      eax, xmm0
0x14287e289:  3d00040000           cmp       eax, 0x400
0x14287e28e:  7218                 jb        0x14287e2a8
0x14287e290:  803dfcbe980500       cmp       byte ptr [rip + 0x598befc], 0
0x14287e297:  7445                 je        0x14287e2de
0x14287e299:  803da802d50500       cmp       byte ptr [rip + 0x5d502a8], 0
0x14287e2a0:  0f85b8000000         jne       0x14287e35e
0x14287e2a6:  eb36                 jmp       0x14287e2de
0x14287e2a8:  498bd0               mov       rdx, r8
0x14287e2ab:  48f7da               neg       rdx
0x14287e2ae:  8bc8                 mov       ecx, eax
0x14287e2b0:  48c1e106             shl       rcx, 6
0x14287e2b4:  488bc2               mov       rax, rdx
0x14287e2b7:  f04a0fc10431         lock xadd qword ptr [rcx + r14], rax
0x14287e2bd:  0fb60debc3e405       movzx     ecx, byte ptr [rip + 0x5e4c3eb]
0x14287e2c4:  90                   nop       
0x14287e2c5:  84c9                 test      cl, cl
0x14287e2c7:  7415                 je        0x14287e2de
0x14287e2c9:  488b05b8db1206       mov       rax, qword ptr [rip + 0x612dbb8]
0x14287e2d0:  4c3bc0               cmp       r8, rax
0x14287e2d3:  7309                 jae       0x14287e2de
0x14287e2d5:  f0480fc115aadb1206   lock xadd qword ptr [rip + 0x612dbaa], rdx
0x14287e2de:  498bca               mov       rcx, r10
0x14287e2e1:  e8bacff3fd           call      0x1407bb2a0
0x14287e2e6:  803dcec3e40500       cmp       byte ptr [rip + 0x5e4c3ce], 0
0x14287e2ed:  7420                 je        0x14287e30f
0x14287e2ef:  e84cfa0e02           call      0x14496dd40
0x14287e2f4:  488bd8               mov       rbx, rax
0x14287e2f7:  ff4004               inc       dword ptr [rax + 4]
0x14287e2fa:  0f57c0               xorps     xmm0, xmm0
0x14287e2fd:  e8be762e03           call      0x145b659c0
0x14287e302:  48c1f804             sar       rax, 4
0x14287e306:  01431c               add       dword ptr [rbx + 0x1c], eax
0x14287e309:  48017b10             add       qword ptr [rbx + 0x10], rdi
0x14287e30d:  eb1f                 jmp       0x14287e32e
0x14287e30f:  ff05c7971506         inc       dword ptr [rip + 0x61597c7]
0x14287e315:  0f57c0               xorps     xmm0, xmm0
0x14287e318:  e8a3762e03           call      0x145b659c0
0x14287e31d:  48c1f804             sar       rax, 4
0x14287e321:  0105cd971506         add       dword ptr [rip + 0x61597cd], eax
0x14287e327:  48013dba971506       add       qword ptr [rip + 0x61597ba], rdi
0x14287e32e:  0fb7c5               movzx     eax, bp
0x14287e331:  4c8d9c24c0000000     lea       r11, [rsp + 0xc0]
0x14287e339:  498b5b10             mov       rbx, qword ptr [r11 + 0x10]
0x14287e33d:  498b6b18             mov       rbp, qword ptr [r11 + 0x18]
0x14287e341:  498b7320             mov       rsi, qword ptr [r11 + 0x20]
0x14287e345:  498b7b28             mov       rdi, qword ptr [r11 + 0x28]
0x14287e349:  498be3               mov       rsp, r11
0x14287e34c:  415e                 pop       r14
0x14287e34e:  c3                   ret       
0x14287e34f:  488d158a6a8504       lea       rdx, [rip + 0x4856a8a]
0x14287e356:  33c9                 xor       ecx, ecx
0x14287e358:  e823090e02           call      0x14495ec80
0x14287e35d:  90                   nop       
0x14287e35e:  488d157b6a8504       lea       rdx, [rip + 0x4856a7b]
0x14287e365:  33c9                 xor       ecx, ecx
0x14287e367:  e814090e02           call      0x14495ec80
0x14287e36c:  cc                   int3      
0x14287e36d:  cc                   int3      
0x14287e36e:  cc                   int3      
0x14287e36f:  cc                   int3      
0x14287e370:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x14287e375:  57                   push      rdi
0x14287e376:  4883ec20             sub       rsp, 0x20
0x14287e37a:  b8ff000000           mov       eax, 0xff
0x14287e37f:  488bf9               mov       rdi, rcx
0x14287e382:  443bc0               cmp       r8d, eax
0x14287e385:  410f4ec0             cmovle    eax, r8d
0x14287e389:  33db                 xor       ebx, ebx
0x14287e38b:  4885d2               test      rdx, rdx
0x14287e38e:  0f45d8               cmovne    ebx, eax
0x14287e391:  85db                 test      ebx, ebx
0x14287e393:  7e20                 jle       0x14287e3b5
0x14287e395:  4c63c3               movsxd    r8, ebx
0x14287e398:  4881c149020000       add       rcx, 0x249
0x14287e39f:  e8fc4d2c03           call      0x145b431a0
0x14287e3a4:  889f48020000         mov       byte ptr [rdi + 0x248], bl
0x14287e3aa:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14287e3af:  4883c420             add       rsp, 0x20
0x14287e3b3:  5f                   pop       rdi
0x14287e3b4:  c3                   ret       
0x14287e3b5:  889948020000         mov       byte ptr [rcx + 0x248], bl
0x14287e3bb:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14287e3c0:  4883c420             add       rsp, 0x20
0x14287e3c4:  5f                   pop       rdi
0x14287e3c5:  c3                   ret       
0x14287e3c6:  cc                   int3      
0x14287e3c7:  cc                   int3      
0x14287e3c8:  cc                   int3      
0x14287e3c9:  cc                   int3      
0x14287e3ca:  cc                   int3      
0x14287e3cb:  cc                   int3      
0x14287e3cc:  cc                   int3      
0x14287e3cd:  cc                   int3      
0x14287e3ce:  cc                   int3      
0x14287e3cf:  cc                   int3      
0x14287e3d0:  0fb68148020000       movzx     eax, byte ptr [rcx + 0x248]
0x14287e3d7:  4c8bca               mov       r9, rdx
0x14287e3da:  488bd1               mov       rdx, rcx
0x14287e3dd:  4d85c9               test      r9, r9
0x14287e3e0:  7504                 jne       0x14287e3e6
0x14287e3e2:  418900               mov       dword ptr [r8], eax
0x14287e3e5:  c3                   ret       
0x14287e3e6:  8bc8                 mov       ecx, eax
0x14287e3e8:  418b00               mov       eax, dword ptr [r8]
0x14287e3eb:  3bc1                 cmp       eax, ecx
0x14287e3ed:  7e05                 jle       0x14287e3f4
0x14287e3ef:  418908               mov       dword ptr [r8], ecx
0x14287e3f2:  8bc1                 mov       eax, ecx
0x14287e3f4:  85c0                 test      eax, eax
0x14287e3f6:  7e12                 jle       0x14287e40a
0x14287e3f8:  4c63c0               movsxd    r8, eax
0x14287e3fb:  4881c249020000       add       rdx, 0x249
0x14287e402:  498bc9               mov       rcx, r9
0x14287e405:  e9964d2c03           jmp       0x145b431a0
0x14287e40a:  c3                   ret       
0x14287e40b:  cc                   int3      
0x14287e40c:  cc                   int3      
0x14287e40d:  cc                   int3      
0x14287e40e:  cc                   int3      
0x14287e40f:  cc                   int3      
0x14287e410:  488b4208             mov       rax, qword ptr [rdx + 8]
0x14287e414:  4c8bc9               mov       r9, rcx
0x14287e417:  4885c0               test      rax, rax
0x14287e41a:  7404                 je        0x14287e420
0x14287e41c:  f0ff4008             lock inc  dword ptr [rax + 8]
0x14287e420:  488b02               mov       rax, qword ptr [rdx]
0x14287e423:  4c8b4208             mov       r8, qword ptr [rdx + 8]
0x14287e427:  488981900e0000       mov       qword ptr [rcx + 0xe90], rax
0x14287e42e:  488b89980e0000       mov       rcx, qword ptr [rcx + 0xe98]
0x14287e435:  4d8981980e0000       mov       qword ptr [r9 + 0xe98], r8
0x14287e43c:  4885c9               test      rcx, rcx
0x14287e43f:  0f85cbaaf4fd         jne       0x1407c8f10
0x14287e445:  c3                   ret       
0x14287e446:  cc                   int3      
0x14287e447:  cc                   int3      
0x14287e448:  cc                   int3      
0x14287e449:  cc                   int3      
0x14287e44a:  cc                   int3      
0x14287e44b:  cc                   int3      
0x14287e44c:  cc                   int3      
0x14287e44d:  cc                   int3      
0x14287e44e:  cc                   int3      
0x14287e44f:  cc                   int3      
