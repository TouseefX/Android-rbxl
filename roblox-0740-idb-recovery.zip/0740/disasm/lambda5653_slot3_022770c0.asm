; lambda5653 vtable slot 3 rva 0x22770c0
0x1422770c0:  488d05a916bb05       lea       rax, [rip + 0x5bb16a9]
0x1422770c7:  c3                   ret       
0x1422770c8:  cc                   int3      
0x1422770c9:  cc                   int3      
0x1422770ca:  cc                   int3      
0x1422770cb:  cc                   int3      
0x1422770cc:  cc                   int3      
0x1422770cd:  cc                   int3      
0x1422770ce:  cc                   int3      
0x1422770cf:  cc                   int3      
