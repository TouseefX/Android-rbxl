; RakPeer vtable slot 1
; rva 0x287c100
0x14287c100:  48895c2410           mov       qword ptr [rsp + 0x10], rbx
0x14287c105:  55                   push      rbp
0x14287c106:  56                   push      rsi
0x14287c107:  57                   push      rdi
0x14287c108:  4154                 push      r12
0x14287c10a:  4155                 push      r13
0x14287c10c:  4156                 push      r14
0x14287c10e:  4157                 push      r15
0x14287c110:  488dac24f0f7ffff     lea       rbp, [rsp - 0x810]
0x14287c118:  4881ec10090000       sub       rsp, 0x910
0x14287c11f:  488b05ca754905       mov       rax, qword ptr [rip + 0x54975ca]
0x14287c126:  4833c4               xor       rax, rsp
0x14287c129:  48898500080000       mov       qword ptr [rbp + 0x800], rax
0x14287c130:  498bf9               mov       rdi, r9
0x14287c133:  4d8bf0               mov       r14, r8
0x14287c136:  440fb7e2             movzx     r12d, dx
0x14287c13a:  6689542448           mov       word ptr [rsp + 0x48], dx
0x14287c13f:  488bf1               mov       rsi, rcx
0x14287c142:  448b153fa4a405       mov       r10d, dword ptr [rip + 0x5a4a43f]
0x14287c149:  803da8aea40500       cmp       byte ptr [rip + 0x5a4aea8], 0
0x14287c150:  440f451534a4a405     cmovne    r10d, dword ptr [rip + 0x5a4a434]
0x14287c158:  33db                 xor       ebx, ebx
0x14287c15a:  4181fa00040000       cmp       r10d, 0x400
0x14287c161:  721c                 jb        0x14287c17f
0x14287c163:  381d2ae09805         cmp       byte ptr [rip + 0x598e02a], bl
0x14287c169:  740c                 je        0x14287c177
0x14287c16b:  381dd723d505         cmp       byte ptr [rip + 0x5d523d7], bl
0x14287c171:  0f85cc0d0000         jne       0x14287cf43
0x14287c177:  8bcb                 mov       ecx, ebx
0x14287c179:  895c2458             mov       dword ptr [rsp + 0x58], ebx
0x14287c17d:  eb10                 jmp       0x14287c18f
0x14287c17f:  e88ca10d02           call      0x144956310
0x14287c184:  8b4808               mov       ecx, dword ptr [rax + 8]
0x14287c187:  894c2458             mov       dword ptr [rsp + 0x58], ecx
0x14287c18b:  44895008             mov       dword ptr [rax + 8], r10d
0x14287c18f:  894dd0               mov       dword ptr [rbp - 0x30], ecx
0x14287c192:  488b06               mov       rax, qword ptr [rsi]
0x14287c195:  488bce               mov       rcx, rsi
0x14287c198:  488b4078             mov       rax, qword ptr [rax + 0x78]
0x14287c19c:  ff15963b8c03         call      qword ptr [rip + 0x38c3b96]
0x14287c1a2:  84c0                 test      al, al
0x14287c1a4:  740b                 je        0x14287c1b1
0x14287c1a6:  41bd01000000         mov       r13d, 1
0x14287c1ac:  e90f0d0000           jmp       0x14287cec0
0x14287c1b1:  8bcb                 mov       ecx, ebx
0x14287c1b3:  81bd880800006179feff cmp       dword ptr [rbp + 0x888], 0xfffe7961
0x14287c1bd:  0f458d88080000       cmovne    ecx, dword ptr [rbp + 0x888]
0x14287c1c4:  894c2454             mov       dword ptr [rsp + 0x54], ecx
0x14287c1c8:  488d8e90090000       lea       rcx, [rsi + 0x990]
0x14287c1cf:  e88cc30200           call      0x1428a8560
0x14287c1d4:  4885ff               test      rdi, rdi
0x14287c1d7:  0f84dd0c0000         je        0x14287ceba
0x14287c1dd:  8b9570080000         mov       edx, dword ptr [rbp + 0x870]
0x14287c1e3:  83fa01               cmp       edx, 1
0x14287c1e6:  0f82ce0c0000         jb        0x14287ceba
0x14287c1ec:  41bf02000000         mov       r15d, 2
0x14287c1f2:  803d5fdea40500       cmp       byte ptr [rip + 0x5a4de5f], 0
0x14287c1f9:  0f84b9000000         je        0x14287c2b8
0x14287c1ff:  83fa01               cmp       edx, 1
0x14287c202:  0f84b0000000         je        0x14287c2b8
0x14287c208:  488b05a1f84e05       mov       rax, qword ptr [rip + 0x54ef8a1]
0x14287c20f:  3c06                 cmp       al, 6
0x14287c211:  0f82a1000000         jb        0x14287c2b8
0x14287c217:  48c1e808             shr       rax, 8
0x14287c21b:  3c03                 cmp       al, 3
0x14287c21d:  0f8295000000         jb        0x14287c2b8
0x14287c223:  488d05a52ca904       lea       rax, [rip + 0x4a92ca5]
0x14287c22a:  4889442460           mov       qword ptr [rsp + 0x60], rax
0x14287c22f:  488b4c2460           mov       rcx, qword ptr [rsp + 0x60]
0x14287c234:  4881c1a193c2ff       add       rcx, -0x3d6c5f
0x14287c23b:  48894df0             mov       qword ptr [rbp - 0x10], rcx
0x14287c23f:  48c7c0ffffffff       mov       rax, 0xffffffffffffffff
0x14287c246:  48ffc0               inc       rax
0x14287c249:  803c0100             cmp       byte ptr [rcx + rax], 0
0x14287c24d:  75f7                 jne       0x14287c246
0x14287c24f:  488945f8             mov       qword ptr [rbp - 8], rax
0x14287c253:  8955a0               mov       dword ptr [rbp - 0x60], edx
0x14287c256:  0f2845a0             movaps    xmm0, xmmword ptr [rbp - 0x60]
0x14287c25a:  660f7f85c0010000     movdqa    xmmword ptr [rbp + 0x1c0], xmm0
0x14287c262:  4c897de0             mov       qword ptr [rbp - 0x20], r15
0x14287c266:  488d85c0010000       lea       rax, [rbp + 0x1c0]
0x14287c26d:  488945e8             mov       qword ptr [rbp - 0x18], rax
0x14287c271:  0f2845e0             movaps    xmm0, xmmword ptr [rbp - 0x20]
0x14287c275:  660f7f85b0000000     movdqa    xmmword ptr [rbp + 0xb0], xmm0
0x14287c27d:  0f284df0             movaps    xmm1, xmmword ptr [rbp - 0x10]
0x14287c281:  660f7f8dc0000000     movdqa    xmmword ptr [rbp + 0xc0], xmm1
0x14287c289:  0f100520f84e05       movups    xmm0, xmmword ptr [rip + 0x54ef820]
0x14287c290:  0f2985d0000000       movaps    xmmword ptr [rbp + 0xd0], xmm0
0x14287c297:  c644242001           mov       byte ptr [rsp + 0x20], 1
0x14287c29c:  4c8d8db0000000       lea       r9, [rbp + 0xb0]
0x14287c2a3:  4c8d85c0000000       lea       r8, [rbp + 0xc0]
0x14287c2aa:  b203                 mov       dl, 3
0x14287c2ac:  488d8dd0000000       lea       rcx, [rbp + 0xd0]
0x14287c2b3:  e818380e02           call      0x14495fad0
0x14287c2b8:  4c89b6100f0000       mov       qword ptr [rsi + 0xf10], r14
0x14287c2bf:  664585e4             test      r12w, r12w
0x14287c2c3:  750b                 jne       0x14287c2d0
0x14287c2c5:  41bd03000000         mov       r13d, 3
0x14287c2cb:  e9f00b0000           jmp       0x14287cec0
0x14287c2d0:  488bce               mov       rcx, rsi
0x14287c2d3:  e808f90000           call      0x14288bbe0
0x14287c2d8:  895c2450             mov       dword ptr [rsp + 0x50], ebx
0x14287c2dc:  895c244c             mov       dword ptr [rsp + 0x4c], ebx
0x14287c2e0:  4883c744             add       rdi, 0x44
0x14287c2e4:  48897c2460           mov       qword ptr [rsp + 0x60], rdi
0x14287c2e9:  41bd01000000         mov       r13d, 1
0x14287c2ef:  90                   nop       
0x14287c2f0:  b938000000           mov       ecx, 0x38
0x14287c2f5:  e806750c02           call      0x144943800
0x14287c2fa:  4c8bf0               mov       r14, rax
0x14287c2fd:  4885c0               test      rax, rax
0x14287c300:  0f84140c0000         je        0x14287cf1a
0x14287c306:  0f57c0               xorps     xmm0, xmm0
0x14287c309:  33c0                 xor       eax, eax
0x14287c30b:  410f11460c           movups    xmmword ptr [r14 + 0xc], xmm0
0x14287c310:  4989461c             mov       qword ptr [r14 + 0x1c], rax
0x14287c314:  41894624             mov       dword ptr [r14 + 0x24], eax
0x14287c318:  6645897e0c           mov       word ptr [r14 + 0xc], r15w
0x14287c31d:  41c746280000ffff     mov       dword ptr [r14 + 0x28], 0xffff0000
0x14287c325:  48c7c0ffffffff       mov       rax, 0xffffffffffffffff
0x14287c32c:  498906               mov       qword ptr [r14], rax
0x14287c32f:  49894630             mov       qword ptr [r14 + 0x30], rax
0x14287c333:  f30f7f45a0           movdqu    xmmword ptr [rbp - 0x60], xmm0
0x14287c338:  4c8975d8             mov       qword ptr [rbp - 0x28], r14
0x14287c33c:  8d4819               lea       ecx, [rax + 0x19]
0x14287c33f:  e8bc740c02           call      0x144943800
0x14287c344:  4c8bf8               mov       r15, rax
0x14287c347:  4885c0               test      rax, rax
0x14287c34a:  0f847c0c0000         je        0x14287cfcc
0x14287c350:  44896808             mov       dword ptr [rax + 8], r13d
0x14287c354:  4489680c             mov       dword ptr [rax + 0xc], r13d
0x14287c358:  488d0529714204       lea       rax, [rip + 0x4427129]
0x14287c35f:  498907               mov       qword ptr [r15], rax
0x14287c362:  4d897710             mov       qword ptr [r15 + 0x10], r14
0x14287c366:  4c8975a0             mov       qword ptr [rbp - 0x60], r14
0x14287c36a:  4c897da8             mov       qword ptr [rbp - 0x58], r15
0x14287c36e:  48895dd8             mov       qword ptr [rbp - 0x28], rbx
0x14287c372:  0fb73f               movzx     edi, word ptr [rdi]
0x14287c375:  48895c2468           mov       qword ptr [rsp + 0x68], rbx
0x14287c37a:  0f57c0               xorps     xmm0, xmm0
0x14287c37d:  0f114578             movups    xmmword ptr [rbp + 0x78], xmm0
0x14287c381:  0f118588000000       movups    xmmword ptr [rbp + 0x88], xmm0
0x14287c388:  0f118598000000       movups    xmmword ptr [rbp + 0x98], xmm0
0x14287c38f:  c7858000000002000000 mov       dword ptr [rbp + 0x80], 2
0x14287c399:  6685ff               test      di, di
0x14287c39c:  7403                 je        0x14287c3a1
0x14287c39e:  897d7c               mov       dword ptr [rbp + 0x7c], edi
0x14287c3a1:  c74578000d0000       mov       dword ptr [rbp + 0x78], 0xd00
0x14287c3a8:  4c8d4c2468           lea       r9, [rsp + 0x68]
0x14287c3ad:  4c8d4578             lea       r8, [rbp + 0x78]
0x14287c3b1:  488d157cdc5604       lea       rdx, [rip + 0x456dc7c]
0x14287c3b8:  33c9                 xor       ecx, ecx
0x14287c3ba:  ff1580348c03         call      qword ptr [rip + 0x38c3480]
0x14287c3c0:  85c0                 test      eax, eax
0x14287c3c2:  744a                 je        0x14287c40e
0x14287c3c4:  488b0de5f64e05       mov       rcx, qword ptr [rip + 0x54ef6e5]
0x14287c3cb:  80f906               cmp       cl, 6
0x14287c3ce:  723e                 jb        0x14287c40e
0x14287c3d0:  48c1e908             shr       rcx, 8
0x14287c3d4:  80f903               cmp       cl, 3
0x14287c3d7:  7235                 jb        0x14287c40e
0x14287c3d9:  488d0daf737804       lea       rcx, [rip + 0x47873af]
0x14287c3e0:  48894c2440           mov       qword ptr [rsp + 0x40], rcx
0x14287c3e5:  488b542440           mov       rdx, qword ptr [rsp + 0x40]
0x14287c3ea:  488d15bffb6b04       lea       rdx, [rip + 0x46bfbbf]
0x14287c3f1:  0f1005b8f64e05       movups    xmm0, xmmword ptr [rip + 0x54ef6b8]
0x14287c3f8:  0f2985e0000000       movaps    xmmword ptr [rbp + 0xe0], xmm0
0x14287c3ff:  448bc0               mov       r8d, eax
0x14287c402:  488d8de0000000       lea       rcx, [rbp + 0xe0]
0x14287c409:  e882340e02           call      0x14495f890
0x14287c40e:  6685ff               test      di, di
0x14287c411:  0f8595000000         jne       0x14287c4ac
0x14287c417:  40383dbadda405       cmp       byte ptr [rip + 0x5a4ddba], dil
0x14287c41e:  0f8488000000         je        0x14287c4ac
0x14287c424:  48895d90             mov       qword ptr [rbp - 0x70], rbx
0x14287c428:  48895d88             mov       qword ptr [rbp - 0x78], rbx
0x14287c42c:  488bfb               mov       rdi, rbx
0x14287c42f:  48895c2478           mov       qword ptr [rsp + 0x78], rbx
0x14287c434:  48895d80             mov       qword ptr [rbp - 0x80], rbx
0x14287c438:  488b4c2468           mov       rcx, qword ptr [rsp + 0x68]
0x14287c43d:  4885c9               test      rcx, rcx
0x14287c440:  7463                 je        0x14287c4a5
0x14287c442:  4c8b4928             mov       r9, qword ptr [rcx + 0x28]
0x14287c446:  48895928             mov       qword ptr [rcx + 0x28], rbx
0x14287c44a:  488d5590             lea       rdx, [rbp - 0x70]
0x14287c44e:  4c8d442478           lea       r8, [rsp + 0x78]
0x14287c453:  83790417             cmp       dword ptr [rcx + 4], 0x17
0x14287c457:  490f45d0             cmovne    rdx, r8
0x14287c45b:  4c8d4588             lea       r8, [rbp - 0x78]
0x14287c45f:  4c8d5580             lea       r10, [rbp - 0x80]
0x14287c463:  4d0f45c2             cmovne    r8, r10
0x14287c467:  498b00               mov       rax, qword ptr [r8]
0x14287c46a:  4885c0               test      rax, rax
0x14287c46d:  7505                 jne       0x14287c474
0x14287c46f:  48890a               mov       qword ptr [rdx], rcx
0x14287c472:  eb04                 jmp       0x14287c478
0x14287c474:  48894828             mov       qword ptr [rax + 0x28], rcx
0x14287c478:  498908               mov       qword ptr [r8], rcx
0x14287c47b:  498bc9               mov       rcx, r9
0x14287c47e:  4d85c9               test      r9, r9
0x14287c481:  75bf                 jne       0x14287c442
0x14287c483:  488b4d88             mov       rcx, qword ptr [rbp - 0x78]
0x14287c487:  4885c9               test      rcx, rcx
0x14287c48a:  7414                 je        0x14287c4a0
0x14287c48c:  488b442478           mov       rax, qword ptr [rsp + 0x78]
0x14287c491:  48894128             mov       qword ptr [rcx + 0x28], rax
0x14287c495:  488b7d90             mov       rdi, qword ptr [rbp - 0x70]
0x14287c499:  48897c2468           mov       qword ptr [rsp + 0x68], rdi
0x14287c49e:  eb11                 jmp       0x14287c4b1
0x14287c4a0:  488b7c2478           mov       rdi, qword ptr [rsp + 0x78]
0x14287c4a5:  48897c2468           mov       qword ptr [rsp + 0x68], rdi
0x14287c4aa:  eb05                 jmp       0x14287c4b1
0x14287c4ac:  488b7c2468           mov       rdi, qword ptr [rsp + 0x68]
0x14287c4b1:  4885ff               test      rdi, rdi
0x14287c4b4:  0f8420040000         je        0x14287c8da
0x14287c4ba:  ff442450             inc       dword ptr [rsp + 0x50]
0x14287c4be:  488b4c2460           mov       rcx, qword ptr [rsp + 0x60]
0x14287c4c3:  0fb701               movzx     eax, word ptr [rcx]
0x14287c4c6:  6689442420           mov       word ptr [rsp + 0x20], ax
0x14287c4cb:  440fb78d80080000     movzx     r9d, word ptr [rbp + 0x880]
0x14287c4d3:  440fb78578080000     movzx     r8d, word ptr [rbp + 0x878]
0x14287c4db:  0fb751bc             movzx     edx, word ptr [rcx - 0x44]
0x14287c4df:  488bcf               mov       rcx, rdi
0x14287c4e2:  e889b30200           call      0x1428a7870
0x14287c4e7:  8bc8                 mov       ecx, eax
0x14287c4e9:  49890e               mov       qword ptr [r14], rcx
0x14287c4ec:  488bcf               mov       rcx, rdi
0x14287c4ef:  ff1553338c03         call      qword ptr [rip + 0x38c3353]
0x14287c4f5:  498b0e               mov       rcx, qword ptr [r14]
0x14287c4f8:  4883f9ff             cmp       rcx, -1
0x14287c4fc:  0f8478040000         je        0x14287c97a
0x14287c502:  486305dfc8a405       movsxd    rax, dword ptr [rip + 0x5a4c8df]
0x14287c509:  85c0                 test      eax, eax
0x14287c50b:  0f8e81010000         jle       0x14287c692
0x14287c511:  89442470             mov       dword ptr [rsp + 0x70], eax
0x14287c515:  c744242004000000     mov       dword ptr [rsp + 0x20], 4
0x14287c51d:  4c8d4c2470           lea       r9, [rsp + 0x70]
0x14287c522:  baffff0000           mov       edx, 0xffff
0x14287c527:  41b805100000         mov       r8d, 0x1005
0x14287c52d:  ff1545338c03         call      qword ptr [rip + 0x38c3345]
0x14287c533:  85c0                 test      eax, eax
0x14287c535:  0f8457010000         je        0x14287c692
0x14287c53b:  488b056ef54e05       mov       rax, qword ptr [rip + 0x54ef56e]
0x14287c542:  3c06                 cmp       al, 6
0x14287c544:  0f8248010000         jb        0x14287c692
0x14287c54a:  48c1e808             shr       rax, 8
0x14287c54e:  3c03                 cmp       al, 3
0x14287c550:  0f823c010000         jb        0x14287c692
0x14287c556:  488d056e86ac04       lea       rax, [rip + 0x4ac866e]
0x14287c55d:  4889442440           mov       qword ptr [rsp + 0x40], rax
0x14287c562:  488b7c2440           mov       rdi, qword ptr [rsp + 0x40]
0x14287c567:  488d3d62bc6b04       lea       rdi, [rip + 0x46bbc62]
0x14287c56e:  ff156c338c03         call      qword ptr [rip + 0x38c336c]
0x14287c574:  448bc0               mov       r8d, eax
0x14287c577:  488b05ea295605       mov       rax, qword ptr [rip + 0x55629ea]
0x14287c57e:  488d9580010000       lea       rdx, [rbp + 0x180]
0x14287c585:  488d0ddc295605       lea       rcx, [rip + 0x55629dc]
0x14287c58c:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x14287c590:  ff15a2378c03         call      qword ptr [rip + 0x38c37a2]
0x14287c596:  90                   nop       
0x14287c597:  48897d20             mov       qword ptr [rbp + 0x20], rdi
0x14287c59b:  48c7c0ffffffff       mov       rax, 0xffffffffffffffff
0x14287c5a2:  48ffc0               inc       rax
0x14287c5a5:  803c0700             cmp       byte ptr [rdi + rax], 0
0x14287c5a9:  75f7                 jne       0x14287c5a2
0x14287c5ab:  48894528             mov       qword ptr [rbp + 0x28], rax
0x14287c5af:  488d8580010000       lea       rax, [rbp + 0x180]
0x14287c5b6:  4883bd9801000010     cmp       qword ptr [rbp + 0x198], 0x10
0x14287c5be:  480f438580010000     cmovae    rax, qword ptr [rbp + 0x180]
0x14287c5c6:  48894500             mov       qword ptr [rbp], rax
0x14287c5ca:  488b8590010000       mov       rax, qword ptr [rbp + 0x190]
0x14287c5d1:  48894508             mov       qword ptr [rbp + 8], rax
0x14287c5d5:  0f284500             movaps    xmm0, xmmword ptr [rbp]
0x14287c5d9:  660f7f85d0010000     movdqa    xmmword ptr [rbp + 0x1d0], xmm0
0x14287c5e1:  48c745100d000000     mov       qword ptr [rbp + 0x10], 0xd
0x14287c5e9:  488d85d0010000       lea       rax, [rbp + 0x1d0]
0x14287c5f0:  48894518             mov       qword ptr [rbp + 0x18], rax
0x14287c5f4:  0f284510             movaps    xmm0, xmmword ptr [rbp + 0x10]
0x14287c5f8:  660f7f85f0000000     movdqa    xmmword ptr [rbp + 0xf0], xmm0
0x14287c600:  0f284d20             movaps    xmm1, xmmword ptr [rbp + 0x20]
0x14287c604:  660f7f8d00010000     movdqa    xmmword ptr [rbp + 0x100], xmm1
0x14287c60c:  0f10059df44e05       movups    xmm0, xmmword ptr [rip + 0x54ef49d]
0x14287c613:  0f298510010000       movaps    xmmword ptr [rbp + 0x110], xmm0
0x14287c61a:  c644242001           mov       byte ptr [rsp + 0x20], 1
0x14287c61f:  4c8d8df0000000       lea       r9, [rbp + 0xf0]
0x14287c626:  4c8d8500010000       lea       r8, [rbp + 0x100]
0x14287c62d:  b203                 mov       dl, 3
0x14287c62f:  488d8d10010000       lea       rcx, [rbp + 0x110]
0x14287c636:  e895340e02           call      0x14495fad0
0x14287c63b:  90                   nop       
0x14287c63c:  488b8598010000       mov       rax, qword ptr [rbp + 0x198]
0x14287c643:  4883f810             cmp       rax, 0x10
0x14287c647:  7230                 jb        0x14287c679
0x14287c649:  48ffc0               inc       rax
0x14287c64c:  488b8d80010000       mov       rcx, qword ptr [rbp + 0x180]
0x14287c653:  488bd1               mov       rdx, rcx
0x14287c656:  483d00100000         cmp       rax, 0x1000
0x14287c65c:  7215                 jb        0x14287c673
0x14287c65e:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x14287c662:  482bd1               sub       rdx, rcx
0x14287c665:  488d42f8             lea       rax, [rdx - 8]
0x14287c669:  4883f81f             cmp       rax, 0x1f
0x14287c66d:  0f87df080000         ja        0x14287cf52
0x14287c673:  e8386a0c02           call      0x1449430b0
0x14287c678:  90                   nop       
0x14287c679:  48899d90010000       mov       qword ptr [rbp + 0x190], rbx
0x14287c680:  48c785980100000f000000 mov       qword ptr [rbp + 0x198], 0xf
0x14287c68b:  c6858001000000       mov       byte ptr [rbp + 0x180], 0
0x14287c692:  486305bfc8a405       movsxd    rax, dword ptr [rip + 0x5a4c8bf]
0x14287c699:  85c0                 test      eax, eax
0x14287c69b:  0f8e84010000         jle       0x14287c825
0x14287c6a1:  89442474             mov       dword ptr [rsp + 0x74], eax
0x14287c6a5:  c744242004000000     mov       dword ptr [rsp + 0x20], 4
0x14287c6ad:  4c8d4c2474           lea       r9, [rsp + 0x74]
0x14287c6b2:  baffff0000           mov       edx, 0xffff
0x14287c6b7:  41b806100000         mov       r8d, 0x1006
0x14287c6bd:  498b0e               mov       rcx, qword ptr [r14]
0x14287c6c0:  ff15b2318c03         call      qword ptr [rip + 0x38c31b2]
0x14287c6c6:  85c0                 test      eax, eax
0x14287c6c8:  0f8457010000         je        0x14287c825
0x14287c6ce:  488b05dbf34e05       mov       rax, qword ptr [rip + 0x54ef3db]
0x14287c6d5:  3c06                 cmp       al, 6
0x14287c6d7:  0f8248010000         jb        0x14287c825
0x14287c6dd:  48c1e808             shr       rax, 8
0x14287c6e1:  3c03                 cmp       al, 3
0x14287c6e3:  0f823c010000         jb        0x14287c825
0x14287c6e9:  488d05d321ad04       lea       rax, [rip + 0x4ad21d3]
0x14287c6f0:  4889442440           mov       qword ptr [rsp + 0x40], rax
0x14287c6f5:  488b7c2440           mov       rdi, qword ptr [rsp + 0x40]
0x14287c6fa:  488d3d1fbb6b04       lea       rdi, [rip + 0x46bbb1f]
0x14287c701:  ff15d9318c03         call      qword ptr [rip + 0x38c31d9]
0x14287c707:  448bc0               mov       r8d, eax
0x14287c70a:  488b0557285605       mov       rax, qword ptr [rip + 0x5562857]
0x14287c711:  488d95a0010000       lea       rdx, [rbp + 0x1a0]
0x14287c718:  488d0d49285605       lea       rcx, [rip + 0x5562849]
0x14287c71f:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x14287c723:  ff150f368c03         call      qword ptr [rip + 0x38c360f]
0x14287c729:  90                   nop       
0x14287c72a:  48897d50             mov       qword ptr [rbp + 0x50], rdi
0x14287c72e:  48c7c0ffffffff       mov       rax, 0xffffffffffffffff
0x14287c735:  48ffc0               inc       rax
0x14287c738:  803c0700             cmp       byte ptr [rdi + rax], 0
0x14287c73c:  75f7                 jne       0x14287c735
0x14287c73e:  48894558             mov       qword ptr [rbp + 0x58], rax
0x14287c742:  488d85a0010000       lea       rax, [rbp + 0x1a0]
0x14287c749:  4883bdb801000010     cmp       qword ptr [rbp + 0x1b8], 0x10
0x14287c751:  480f4385a0010000     cmovae    rax, qword ptr [rbp + 0x1a0]
0x14287c759:  48894530             mov       qword ptr [rbp + 0x30], rax
0x14287c75d:  488b85b0010000       mov       rax, qword ptr [rbp + 0x1b0]
0x14287c764:  48894538             mov       qword ptr [rbp + 0x38], rax
0x14287c768:  0f284530             movaps    xmm0, xmmword ptr [rbp + 0x30]
0x14287c76c:  660f7f85e0010000     movdqa    xmmword ptr [rbp + 0x1e0], xmm0
0x14287c774:  48c745400d000000     mov       qword ptr [rbp + 0x40], 0xd
0x14287c77c:  488d85e0010000       lea       rax, [rbp + 0x1e0]
0x14287c783:  48894548             mov       qword ptr [rbp + 0x48], rax
0x14287c787:  0f284540             movaps    xmm0, xmmword ptr [rbp + 0x40]
0x14287c78b:  660f7f8520010000     movdqa    xmmword ptr [rbp + 0x120], xmm0
0x14287c793:  0f284d50             movaps    xmm1, xmmword ptr [rbp + 0x50]
0x14287c797:  660f7f8d30010000     movdqa    xmmword ptr [rbp + 0x130], xmm1
0x14287c79f:  0f10050af34e05       movups    xmm0, xmmword ptr [rip + 0x54ef30a]
0x14287c7a6:  0f298540010000       movaps    xmmword ptr [rbp + 0x140], xmm0
0x14287c7ad:  c644242001           mov       byte ptr [rsp + 0x20], 1
0x14287c7b2:  4c8d8d20010000       lea       r9, [rbp + 0x120]
0x14287c7b9:  4c8d8530010000       lea       r8, [rbp + 0x130]
0x14287c7c0:  b203                 mov       dl, 3
0x14287c7c2:  488d8d40010000       lea       rcx, [rbp + 0x140]
0x14287c7c9:  e802330e02           call      0x14495fad0
0x14287c7ce:  90                   nop       
0x14287c7cf:  488b85b8010000       mov       rax, qword ptr [rbp + 0x1b8]
0x14287c7d6:  4883f810             cmp       rax, 0x10
0x14287c7da:  7230                 jb        0x14287c80c
0x14287c7dc:  48ffc0               inc       rax
0x14287c7df:  488b8da0010000       mov       rcx, qword ptr [rbp + 0x1a0]
0x14287c7e6:  488bd1               mov       rdx, rcx
0x14287c7e9:  483d00100000         cmp       rax, 0x1000
0x14287c7ef:  7215                 jb        0x14287c806
0x14287c7f1:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x14287c7f5:  482bd1               sub       rdx, rcx
0x14287c7f8:  488d42f8             lea       rax, [rdx - 8]
0x14287c7fc:  4883f81f             cmp       rax, 0x1f
0x14287c800:  0f8752070000         ja        0x14287cf58
0x14287c806:  e8a5680c02           call      0x1449430b0
0x14287c80b:  90                   nop       
0x14287c80c:  48899db0010000       mov       qword ptr [rbp + 0x1b0], rbx
0x14287c813:  48c785b80100000f000000 mov       qword ptr [rbp + 0x1b8], 0xf
0x14287c81e:  c685a001000000       mov       byte ptr [rbp + 0x1a0], 0
0x14287c825:  498d560c             lea       rdx, [r14 + 0xc]
0x14287c829:  498b0e               mov       rcx, qword ptr [r14]
0x14287c82c:  e81fbf0200           call      0x1428a8750
0x14287c831:  410fb74e0e           movzx     ecx, word ptr [r14 + 0xe]
0x14287c836:  ff15f42f8c03         call      qword ptr [rip + 0x38c2ff4]
0x14287c83c:  0fb7c8               movzx     ecx, ax
0x14287c83f:  3b0da3e24e05         cmp       ecx, dword ptr [rip + 0x54ee2a3]
0x14287c845:  0f8cca000000         jl        0x14287c915
0x14287c84b:  8b44244c             mov       eax, dword ptr [rsp + 0x4c]
0x14287c84f:  41894608             mov       dword ptr [r14 + 8], eax
0x14287c853:  41b901040000         mov       r9d, 0x401
0x14287c859:  4c8d85f0030000       lea       r8, [rbp + 0x3f0]
0x14287c860:  b201                 mov       dl, 1
0x14287c862:  498d4e0c             lea       rcx, [r14 + 0xc]
0x14287c866:  e8358e0200           call      0x1428a56a0
0x14287c86b:  488b056e025005       mov       rax, qword ptr [rip + 0x550026e]
0x14287c872:  3c06                 cmp       al, 6
0x14287c874:  7253                 jb        0x14287c8c9
0x14287c876:  48c1e808             shr       rax, 8
0x14287c87a:  3c03                 cmp       al, 3
0x14287c87c:  724b                 jb        0x14287c8c9
0x14287c87e:  488d057b6aae04       lea       rax, [rip + 0x4ae6a7b]
0x14287c885:  4889442440           mov       qword ptr [rsp + 0x40], rax
0x14287c88a:  488b542440           mov       rdx, qword ptr [rsp + 0x40]
0x14287c88f:  488d15e2b66b04       lea       rdx, [rip + 0x46bb6e2]
0x14287c896:  0f100543025005       movups    xmm0, xmmword ptr [rip + 0x5500243]
0x14287c89d:  0f298550010000       movaps    xmmword ptr [rbp + 0x150], xmm0
0x14287c8a4:  48895c2430           mov       qword ptr [rsp + 0x30], rbx
0x14287c8a9:  48895c2428           mov       qword ptr [rsp + 0x28], rbx
0x14287c8ae:  48895c2420           mov       qword ptr [rsp + 0x20], rbx
0x14287c8b3:  4533c9               xor       r9d, r9d
0x14287c8b6:  4c8d85f0030000       lea       r8, [rbp + 0x3f0]
0x14287c8bd:  488d8d50010000       lea       rcx, [rbp + 0x150]
0x14287c8c4:  e857350e02           call      0x14495fe20
0x14287c8c9:  488d8e00090000       lea       rcx, [rsi + 0x900]
0x14287c8d0:  488d55a0             lea       rdx, [rbp - 0x60]
0x14287c8d4:  e8b7800200           call      0x1428a4990
0x14287c8d9:  90                   nop       
0x14287c8da:  498bcf               mov       rcx, r15
0x14287c8dd:  e82ec6f4fd           call      0x1407c8f10
0x14287c8e2:  448b7c244c           mov       r15d, dword ptr [rsp + 0x4c]
0x14287c8e7:  41ffc7               inc       r15d
0x14287c8ea:  44897c244c           mov       dword ptr [rsp + 0x4c], r15d
0x14287c8ef:  488b7c2460           mov       rdi, qword ptr [rsp + 0x60]
0x14287c8f4:  4883c746             add       rdi, 0x46
0x14287c8f8:  48897c2460           mov       qword ptr [rsp + 0x60], rdi
0x14287c8fd:  443bbd70080000       cmp       r15d, dword ptr [rbp + 0x870]
0x14287c904:  0f838a000000         jae       0x14287c994
0x14287c90a:  41bf02000000         mov       r15d, 2
0x14287c910:  e9dbf9ffff           jmp       0x14287c2f0
0x14287c915:  488b0594f14e05       mov       rax, qword ptr [rip + 0x54ef194]
0x14287c91c:  3c06                 cmp       al, 6
0x14287c91e:  7253                 jb        0x14287c973
0x14287c920:  48c1e808             shr       rax, 8
0x14287c924:  3c03                 cmp       al, 3
0x14287c926:  724b                 jb        0x14287c973
0x14287c928:  488d054cb9ad04       lea       rax, [rip + 0x4adb94c]
0x14287c92f:  48894580             mov       qword ptr [rbp - 0x80], rax
0x14287c933:  488b7d80             mov       rdi, qword ptr [rbp - 0x80]
0x14287c937:  410fb74e0e           movzx     ecx, word ptr [r14 + 0xe]
0x14287c93c:  ff15ee2e8c03         call      qword ptr [rip + 0x38c2eee]
0x14287c942:  440fb7c0             movzx     r8d, ax
0x14287c946:  0f100563f14e05       movups    xmm0, xmmword ptr [rip + 0x54ef163]
0x14287c94d:  0f2945b0             movaps    xmmword ptr [rbp - 0x50], xmm0
0x14287c951:  48895c2430           mov       qword ptr [rsp + 0x30], rbx
0x14287c956:  48895c2428           mov       qword ptr [rsp + 0x28], rbx
0x14287c95b:  48895c2420           mov       qword ptr [rsp + 0x20], rbx
0x14287c960:  4533c9               xor       r9d, r9d
0x14287c963:  488d97b5fcbdff       lea       rdx, [rdi - 0x42034b]
0x14287c96a:  488d4db0             lea       rcx, [rbp - 0x50]
0x14287c96e:  e8ad340e02           call      0x14495fe20
0x14287c973:  bb0b000000           mov       ebx, 0xb
0x14287c978:  eb0d                 jmp       0x14287c987
0x14287c97a:  488bce               mov       rcx, rsi
0x14287c97d:  e85ef20000           call      0x14288bbe0
0x14287c982:  bb06000000           mov       ebx, 6
0x14287c987:  498bcf               mov       rcx, r15
0x14287c98a:  e881c5f4fd           call      0x1407c8f10
0x14287c98f:  e92f050000           jmp       0x14287cec3
0x14287c994:  4c8dbe12010000       lea       r15, [rsi + 0x112]
0x14287c99b:  6641833f00           cmp       word ptr [r15], 0
0x14287c9a0:  0f8574030000         jne       0x14287cd1a
0x14287c9a6:  0fb7542448           movzx     edx, word ptr [rsp + 0x48]
0x14287c9ab:  0fb7c2               movzx     eax, dx
0x14287c9ae:  498bcf               mov       rcx, r15
0x14287c9b1:  66399614010000       cmp       word ptr [rsi + 0x114], dx
0x14287c9b8:  7607                 jbe       0x14287c9c1
0x14287c9ba:  66899614010000       mov       word ptr [rsi + 0x114], dx
0x14287c9c1:  668901               mov       word ptr [rcx], ax
0x14287c9c4:  4c8bf2               mov       r14, rdx
0x14287c9c7:  b8d8160000           mov       eax, 0x16d8
0x14287c9cc:  48f7e2               mul       rdx
0x14287c9cf:  49c7c5ffffffff       mov       r13, 0xffffffffffffffff
0x14287c9d6:  490f40c5             cmovo     rax, r13
0x14287c9da:  4883c008             add       rax, 8
0x14287c9de:  490f42c5             cmovb     rax, r13
0x14287c9e2:  488bc8               mov       rcx, rax
0x14287c9e5:  e8166e0c02           call      0x144943800
0x14287c9ea:  4885c0               test      rax, rax
0x14287c9ed:  0f84b9050000         je        0x14287cfac
0x14287c9f3:  4889442440           mov       qword ptr [rsp + 0x40], rax
0x14287c9f8:  4c8930               mov       qword ptr [rax], r14
0x14287c9fb:  488d7808             lea       rdi, [rax + 8]
0x14287c9ff:  488d05da2b0000       lea       rax, [rip + 0x2bda]
0x14287ca06:  4889442420           mov       qword ptr [rsp + 0x20], rax
0x14287ca0b:  4c8d0dee610200       lea       r9, [rip + 0x261ee]
0x14287ca12:  4d8bc6               mov       r8, r14
0x14287ca15:  bad8160000           mov       edx, 0x16d8
0x14287ca1a:  488bcf               mov       rcx, rdi
0x14287ca1d:  e8b64f2a03           call      0x145b219d8
0x14287ca22:  90                   nop       
0x14287ca23:  4889be50030000       mov       qword ptr [rsi + 0x350], rdi
0x14287ca2a:  410fb707             movzx     eax, word ptr [r15]
0x14287ca2e:  6685c0               test      ax, ax
0x14287ca31:  7505                 jne       0x14287ca38
0x14287ca33:  488bc3               mov       rax, rbx
0x14287ca36:  eb24                 jmp       0x14287ca5c
0x14287ca38:  488bc8               mov       rcx, rax
0x14287ca3b:  48c1e103             shl       rcx, 3
0x14287ca3f:  b808000000           mov       eax, 8
0x14287ca44:  48f7e1               mul       rcx
0x14287ca47:  490f40c5             cmovo     rax, r13
0x14287ca4b:  488bc8               mov       rcx, rax
0x14287ca4e:  e8ad6d0c02           call      0x144943800
0x14287ca53:  4885c0               test      rax, rax
0x14287ca56:  0f8436050000         je        0x14287cf92
0x14287ca5c:  48898680030000       mov       qword ptr [rsi + 0x380], rax
0x14287ca63:  410fb707             movzx     eax, word ptr [r15]
0x14287ca67:  6685c0               test      ax, ax
0x14287ca6a:  7505                 jne       0x14287ca71
0x14287ca6c:  488bc3               mov       rax, rbx
0x14287ca6f:  eb20                 jmp       0x14287ca91
0x14287ca71:  488bc8               mov       rcx, rax
0x14287ca74:  b808000000           mov       eax, 8
0x14287ca79:  48f7e1               mul       rcx
0x14287ca7c:  490f40c5             cmovo     rax, r13
0x14287ca80:  488bc8               mov       rcx, rax
0x14287ca83:  e8786d0c02           call      0x144943800
0x14287ca88:  4885c0               test      rax, rax
0x14287ca8b:  0f84e7040000         je        0x14287cf78
0x14287ca91:  48898658030000       mov       qword ptr [rsi + 0x358], rax
0x14287ca98:  803d89eaa00500       cmp       byte ptr [rip + 0x5a0ea89], 0
0x14287ca9f:  0f8423010000         je        0x14287cbc8
0x14287caa5:  803d6cd0df0500       cmp       byte ptr [rip + 0x5dfd06c], 0
0x14287caac:  0f8416010000         je        0x14287cbc8
0x14287cab2:  450fb727             movzx     r12d, word ptr [r15]
0x14287cab6:  b850100000           mov       eax, 0x1050
0x14287cabb:  49f7e4               mul       r12
0x14287cabe:  488bf8               mov       rdi, rax
0x14287cac1:  490f40fd             cmovo     rdi, r13
0x14287cac5:  488bcf               mov       rcx, rdi
0x14287cac8:  e8336d0c02           call      0x144943800
0x14287cacd:  4c8be8               mov       r13, rax
0x14287cad0:  4885c0               test      rax, rax
0x14287cad3:  0f8485040000         je        0x14287cf5e
0x14287cad9:  4889442440           mov       qword ptr [rsp + 0x40], rax
0x14287cade:  4c8bc7               mov       r8, rdi
0x14287cae1:  33d2                 xor       edx, edx
0x14287cae3:  488bc8               mov       rcx, rax
0x14287cae6:  e8d5562c03           call      0x145b421c0
0x14287caeb:  4d85e4               test      r12, r12
0x14287caee:  0f849a000000         je        0x14287cb8e
0x14287caf4:  498dbd40080000       lea       rdi, [r13 + 0x840]
0x14287cafb:  0f1f440000           nop       dword ptr [rax + rax]
0x14287cb00:  49ffcc               dec       r12
0x14287cb03:  0f57c0               xorps     xmm0, xmm0
0x14287cb06:  0f1187c0f7ffff       movups    xmmword ptr [rdi - 0x840], xmm0
0x14287cb0d:  0f1187d0f7ffff       movups    xmmword ptr [rdi - 0x830], xmm0
0x14287cb14:  33d2                 xor       edx, edx
0x14287cb16:  41b800080000         mov       r8d, 0x800
0x14287cb1c:  488d8fe0f7ffff       lea       rcx, [rdi - 0x820]
0x14287cb23:  e898562c03           call      0x145b421c0
0x14287cb28:  488bc3               mov       rax, rbx
0x14287cb2b:  0f1f440000           nop       dword ptr [rax + rax]
0x14287cb30:  48899cc7e0f7ffff     mov       qword ptr [rdi + rax*8 - 0x820], rbx
0x14287cb38:  48ffc0               inc       rax
0x14287cb3b:  483d00010000         cmp       rax, 0x100
0x14287cb41:  72ed                 jb        0x14287cb30
0x14287cb43:  0f57c0               xorps     xmm0, xmm0
0x14287cb46:  0f1147e0             movups    xmmword ptr [rdi - 0x20], xmm0
0x14287cb4a:  0f1147f0             movups    xmmword ptr [rdi - 0x10], xmm0
0x14287cb4e:  33d2                 xor       edx, edx
0x14287cb50:  41b800080000         mov       r8d, 0x800
0x14287cb56:  488bcf               mov       rcx, rdi
0x14287cb59:  e862562c03           call      0x145b421c0
0x14287cb5e:  488bc3               mov       rax, rbx
0x14287cb61:  48891cc7             mov       qword ptr [rdi + rax*8], rbx
0x14287cb65:  48ffc0               inc       rax
0x14287cb68:  483d00010000         cmp       rax, 0x100
0x14287cb6e:  72f1                 jb        0x14287cb61
0x14287cb70:  48899f00080000       mov       qword ptr [rdi + 0x800], rbx
0x14287cb77:  c6870808000000       mov       byte ptr [rdi + 0x808], 0
0x14287cb7e:  4881c750100000       add       rdi, 0x1050
0x14287cb85:  4d85e4               test      r12, r12
0x14287cb88:  0f8572ffffff         jne       0x14287cb00
0x14287cb8e:  488d8668030000       lea       rax, [rsi + 0x368]
0x14287cb95:  488d8d60010000       lea       rcx, [rbp + 0x160]
0x14287cb9c:  483bc1               cmp       rax, rcx
0x14287cb9f:  7413                 je        0x14287cbb4
0x14287cba1:  488b08               mov       rcx, qword ptr [rax]
0x14287cba4:  4c8928               mov       qword ptr [rax], r13
0x14287cba7:  4885c9               test      rcx, rcx
0x14287cbaa:  7411                 je        0x14287cbbd
0x14287cbac:  e8ff640c02           call      0x1449430b0
0x14287cbb1:  90                   nop       
0x14287cbb2:  eb09                 jmp       0x14287cbbd
0x14287cbb4:  498bcd               mov       rcx, r13
0x14287cbb7:  e8f4640c02           call      0x1449430b0
0x14287cbbc:  90                   nop       
0x14287cbbd:  410fb707             movzx     eax, word ptr [r15]
0x14287cbc1:  48898670030000       mov       qword ptr [rsi + 0x370], rax
0x14287cbc8:  448bcb               mov       r9d, ebx
0x14287cbcb:  410fb707             movzx     eax, word ptr [r15]
0x14287cbcf:  663bd8               cmp       bx, ax
0x14287cbd2:  0f8316010000         jae       0x14287ccee
0x14287cbd8:  0f1f840000000000     nop       dword ptr [rax + rax]
0x14287cbe0:  4d63c1               movsxd    r8, r9d
0x14287cbe3:  4969d0d8160000       imul      rdx, r8, 0x16d8
0x14287cbea:  488b8e50030000       mov       rcx, qword ptr [rsi + 0x350]
0x14287cbf1:  8bc3                 mov       eax, ebx
0x14287cbf3:  860411               xchg      byte ptr [rcx + rdx], al
0x14287cbf6:  488b8e50030000       mov       rcx, qword ptr [rsi + 0x350]
0x14287cbfd:  4803ca               add       rcx, rdx
0x14287cc00:  0f1005412c5705       movups    xmm0, xmmword ptr [rip + 0x5572c41]
0x14287cc07:  0f114104             movups    xmmword ptr [rcx + 4], xmm0
0x14287cc0b:  f20f100d452c5705     movsd     xmm1, qword ptr [rip + 0x5572c45]
0x14287cc13:  f20f114914           movsd     qword ptr [rcx + 0x14], xmm1
0x14287cc18:  8b05422c5705         mov       eax, dword ptr [rip + 0x5572c42]
0x14287cc1e:  89411c               mov       dword ptr [rcx + 0x1c], eax
0x14287cc21:  0fb7053e2c5705       movzx     eax, word ptr [rip + 0x5572c3e]
0x14287cc28:  66894122             mov       word ptr [rcx + 0x22], ax
0x14287cc2c:  0fb705312c5705       movzx     eax, word ptr [rip + 0x5572c31]
0x14287cc33:  66894120             mov       word ptr [rcx + 0x20], ax
0x14287cc37:  488b8e50030000       mov       rcx, qword ptr [rsi + 0x350]
0x14287cc3e:  488b05232c5705       mov       rax, qword ptr [rip + 0x5572c23]
0x14287cc45:  4889841130160000     mov       qword ptr [rcx + rdx + 0x1630], rax
0x14287cc4d:  0fb7051c2c5705       movzx     eax, word ptr [rip + 0x5572c1c]
0x14287cc54:  6689841138160000     mov       word ptr [rcx + rdx + 0x1638], ax
0x14287cc5c:  488b8650030000       mov       rax, qword ptr [rsi + 0x350]
0x14287cc63:  899c02d4160000       mov       dword ptr [rdx + rax + 0x16d4], ebx
0x14287cc6a:  488b8e50030000       mov       rcx, qword ptr [rsi + 0x350]
0x14287cc71:  8b86f0080000         mov       eax, dword ptr [rsi + 0x8f0]
0x14287cc77:  89840a40160000       mov       dword ptr [rdx + rcx + 0x1640], eax
0x14287cc7e:  488b8650030000       mov       rax, qword ptr [rsi + 0x350]
0x14287cc85:  6644898c0260160000   mov       word ptr [rdx + rax + 0x1660], r9w
0x14287cc8e:  488b8650030000       mov       rax, qword ptr [rsi + 0x350]
0x14287cc95:  899c0264160000       mov       dword ptr [rdx + rax + 0x1664], ebx
0x14287cc9c:  488b8650030000       mov       rax, qword ptr [rsi + 0x350]
0x14287cca3:  48899c0268160000     mov       qword ptr [rdx + rax + 0x1668], rbx
0x14287ccab:  488b8650030000       mov       rax, qword ptr [rsi + 0x350]
0x14287ccb2:  4889b40250120000     mov       qword ptr [rdx + rax + 0x1250], rsi
0x14287ccba:  488b8650030000       mov       rax, qword ptr [rsi + 0x350]
0x14287ccc1:  c684027116000009     mov       byte ptr [rdx + rax + 0x1671], 9
0x14287ccc9:  488b8e50030000       mov       rcx, qword ptr [rsi + 0x350]
0x14287ccd0:  4803ca               add       rcx, rdx
0x14287ccd3:  488b8658030000       mov       rax, qword ptr [rsi + 0x358]
0x14287ccda:  4a890cc0             mov       qword ptr [rax + r8*8], rcx
0x14287ccde:  41ffc1               inc       r9d
0x14287cce1:  410fb707             movzx     eax, word ptr [r15]
0x14287cce5:  443bc8               cmp       r9d, eax
0x14287cce8:  0f8cf2feffff         jl        0x14287cbe0
0x14287ccee:  8bd3                 mov       edx, ebx
0x14287ccf0:  0fb7c0               movzx     eax, ax
0x14287ccf3:  c1e003               shl       eax, 3
0x14287ccf6:  85c0                 test      eax, eax
0x14287ccf8:  7420                 je        0x14287cd1a
0x14287ccfa:  660f1f440000         nop       word ptr [rax + rax]
0x14287cd00:  8bca                 mov       ecx, edx
0x14287cd02:  488b8680030000       mov       rax, qword ptr [rsi + 0x380]
0x14287cd09:  48891cc8             mov       qword ptr [rax + rcx*8], rbx
0x14287cd0d:  ffc2                 inc       edx
0x14287cd0f:  410fb707             movzx     eax, word ptr [r15]
0x14287cd13:  c1e003               shl       eax, 3
0x14287cd16:  3bd0                 cmp       edx, eax
0x14287cd18:  72e6                 jb        0x14287cd00
0x14287cd1a:  448b642450           mov       r12d, dword ptr [rsp + 0x50]
0x14287cd1f:  4585e4               test      r12d, r12d
0x14287cd22:  7512                 jne       0x14287cd36
0x14287cd24:  488bce               mov       rcx, rsi
0x14287cd27:  e8b4ee0000           call      0x14288bbe0
0x14287cd2c:  418d5c2407           lea       ebx, [r12 + 7]
0x14287cd31:  e98d010000           jmp       0x14287cec3
0x14287cd36:  0fb68608010000       movzx     eax, byte ptr [rsi + 0x108]
0x14287cd3d:  90                   nop       
0x14287cd3e:  84c0                 test      al, al
0x14287cd40:  0f847d010000         je        0x14287cec3
0x14287cd46:  c6864804000000       mov       byte ptr [rsi + 0x448], 0
0x14287cd4d:  8bc3                 mov       eax, ebx
0x14287cd4f:  868608010000         xchg      byte ptr [rsi + 0x108], al
0x14287cd55:  8bc3                 mov       eax, ebx
0x14287cd57:  86860a010000         xchg      byte ptr [rsi + 0x10a], al
0x14287cd5d:  488bce               mov       rcx, rsi
0x14287cd60:  e85bd10000           call      0x142889ec0
0x14287cd65:  488bce               mov       rcx, rsi
0x14287cd68:  e8b3d20000           call      0x14288a020
0x14287cd6d:  488d8eb0070000       lea       rcx, [rsi + 0x7b0]
0x14287cd74:  e877580200           call      0x1428a25f0
0x14287cd79:  0fb68609010000       movzx     eax, byte ptr [rsi + 0x109]
0x14287cd80:  90                   nop       
0x14287cd81:  84c0                 test      al, al
0x14287cd83:  0f850d010000         jne       0x14287ce96
0x14287cd89:  895c2448             mov       dword ptr [rsp + 0x48], ebx
0x14287cd8d:  488d442448           lea       rax, [rsp + 0x48]
0x14287cd92:  4889442428           mov       qword ptr [rsp + 0x28], rax
0x14287cd97:  895c2420             mov       dword ptr [rsp + 0x20], ebx
0x14287cd9b:  4c8bce               mov       r9, rsi
0x14287cd9e:  4c8d05fb940100       lea       r8, [rip + 0x194fb]
0x14287cda5:  ba80841e00           mov       edx, 0x1e8480
0x14287cdaa:  33c9                 xor       ecx, ecx
0x14287cdac:  e88fdd2d03           call      0x145b5ab40
0x14287cdb1:  488bf8               mov       rdi, rax
0x14287cdb4:  448b6c2454           mov       r13d, dword ptr [rsp + 0x54]
0x14287cdb9:  418bd5               mov       edx, r13d
0x14287cdbc:  488bc8               mov       rcx, rax
0x14287cdbf:  ff15eb178c03         call      qword ptr [rip + 0x38c17eb]
0x14287cdc5:  4885ff               test      rdi, rdi
0x14287cdc8:  751a                 jne       0x14287cde4
0x14287cdca:  488b06               mov       rax, qword ptr [rsi]
0x14287cdcd:  488bce               mov       rcx, rsi
0x14287cdd0:  488b4070             mov       rax, qword ptr [rax + 0x70]
0x14287cdd4:  ff155e2f8c03         call      qword ptr [rip + 0x38c2f5e]
0x14287cdda:  bb09000000           mov       ebx, 9
0x14287cddf:  e9df000000           jmp       0x14287cec3
0x14287cde4:  488bcf               mov       rcx, rdi
0x14287cde7:  ff15db1f8c03         call      qword ptr [rip + 0x38c1fdb]
0x14287cded:  4c8bf3               mov       r14, rbx
0x14287cdf0:  8bfb                 mov       edi, ebx
0x14287cdf2:  488b8600090000       mov       rax, qword ptr [rsi + 0x900]
0x14287cdf9:  498b0c06             mov       rcx, qword ptr [r14 + rax]
0x14287cdfd:  488b01               mov       rax, qword ptr [rcx]
0x14287ce00:  4a898435f0010000     mov       qword ptr [rbp + r14 + 0x1f0], rax
0x14287ce08:  4a89b435f8010000     mov       qword ptr [rbp + r14 + 0x1f8], rsi
0x14287ce10:  895c2454             mov       dword ptr [rsp + 0x54], ebx
0x14287ce14:  4863c7               movsxd    rax, edi
0x14287ce17:  48c1e004             shl       rax, 4
0x14287ce1b:  4c8d8df0010000       lea       r9, [rbp + 0x1f0]
0x14287ce22:  4c03c8               add       r9, rax
0x14287ce25:  488d442454           lea       rax, [rsp + 0x54]
0x14287ce2a:  4889442428           mov       qword ptr [rsp + 0x28], rax
0x14287ce2f:  895c2420             mov       dword ptr [rsp + 0x20], ebx
0x14287ce33:  4c8d05d6900100       lea       r8, [rip + 0x190d6]
0x14287ce3a:  ba80841e00           mov       edx, 0x1e8480
0x14287ce3f:  33c9                 xor       ecx, ecx
0x14287ce41:  e8fadc2d03           call      0x145b5ab40
0x14287ce46:  4c8bf8               mov       r15, rax
0x14287ce49:  418bd5               mov       edx, r13d
0x14287ce4c:  488bc8               mov       rcx, rax
0x14287ce4f:  ff155b178c03         call      qword ptr [rip + 0x38c175b]
0x14287ce55:  4d85ff               test      r15, r15
0x14287ce58:  0f846cffffff         je        0x14287cdca
0x14287ce5e:  498bcf               mov       rcx, r15
0x14287ce61:  ff15611f8c03         call      qword ptr [rip + 0x38c1f61]
0x14287ce67:  ffc7                 inc       edi
0x14287ce69:  4983c610             add       r14, 0x10
0x14287ce6d:  413bfc               cmp       edi, r12d
0x14287ce70:  7280                 jb        0x14287cdf2
0x14287ce72:  8b860c010000         mov       eax, dword ptr [rsi + 0x10c]
0x14287ce78:  90                   nop       
0x14287ce79:  413bc4               cmp       eax, r12d
0x14287ce7c:  7318                 jae       0x14287ce96
0x14287ce7e:  6690                 nop       
0x14287ce80:  b90a000000           mov       ecx, 0xa
0x14287ce85:  e866c60300           call      0x1428b94f0
0x14287ce8a:  8b860c010000         mov       eax, dword ptr [rsi + 0x10c]
0x14287ce90:  90                   nop       
0x14287ce91:  413bc4               cmp       eax, r12d
0x14287ce94:  72ea                 jb        0x14287ce80
0x14287ce96:  0fb68609010000       movzx     eax, byte ptr [rsi + 0x109]
0x14287ce9d:  90                   nop       
0x14287ce9e:  84c0                 test      al, al
0x14287cea0:  7521                 jne       0x14287cec3
0x14287cea2:  b90a000000           mov       ecx, 0xa
0x14287cea7:  e844c60300           call      0x1428b94f0
0x14287ceac:  0fb68609010000       movzx     eax, byte ptr [rsi + 0x109]
0x14287ceb3:  90                   nop       
0x14287ceb4:  84c0                 test      al, al
0x14287ceb6:  74ea                 je        0x14287cea2
0x14287ceb8:  eb09                 jmp       0x14287cec3
0x14287ceba:  41bd02000000         mov       r13d, 2
0x14287cec0:  418bdd               mov       ebx, r13d
0x14287cec3:  448b4c2458           mov       r9d, dword ptr [rsp + 0x58]
0x14287cec8:  4181f900040000       cmp       r9d, 0x400
0x14287cecf:  7214                 jb        0x14287cee5
0x14287ced1:  803dbbd2980500       cmp       byte ptr [rip + 0x598d2bb], 0
0x14287ced8:  7414                 je        0x14287ceee
0x14287ceda:  803d6716d50500       cmp       byte ptr [rip + 0x5d51667], 0
0x14287cee1:  7551                 jne       0x14287cf34
0x14287cee3:  eb09                 jmp       0x14287ceee
0x14287cee5:  e826940d02           call      0x144956310
0x14287ceea:  44894808             mov       dword ptr [rax + 8], r9d
0x14287ceee:  8bc3                 mov       eax, ebx
0x14287cef0:  488b8d00080000       mov       rcx, qword ptr [rbp + 0x800]
0x14287cef7:  4833cc               xor       rcx, rsp
0x14287cefa:  e8e1462a03           call      0x145b215e0
0x14287ceff:  488b9c2458090000     mov       rbx, qword ptr [rsp + 0x958]
0x14287cf07:  4881c410090000       add       rsp, 0x910
0x14287cf0e:  415f                 pop       r15
0x14287cf10:  415e                 pop       r14
0x14287cf12:  415d                 pop       r13
0x14287cf14:  415c                 pop       r12
0x14287cf16:  5f                   pop       rdi
0x14287cf17:  5e                   pop       rsi
0x14287cf18:  5d                   pop       rbp
0x14287cf19:  c3                   ret       
0x14287cf1a:  488d4d60             lea       rcx, [rbp + 0x60]
0x14287cf1e:  e8cddef3fd           call      0x1407badf0
0x14287cf23:  488d15169d4805       lea       rdx, [rip + 0x5489d16]
0x14287cf2a:  488d4d60             lea       rcx, [rbp + 0x60]
0x14287cf2e:  e81d612c03           call      0x145b43050
0x14287cf33:  90                   nop       
0x14287cf34:  488d15a57e8504       lea       rdx, [rip + 0x4857ea5]
0x14287cf3b:  33c9                 xor       ecx, ecx
0x14287cf3d:  e83e1d0e02           call      0x14495ec80
0x14287cf42:  90                   nop       
0x14287cf43:  488d15967e8504       lea       rdx, [rip + 0x4857e96]
0x14287cf4a:  33c9                 xor       ecx, ecx
0x14287cf4c:  e82f1d0e02           call      0x14495ec80
0x14287cf51:  90                   nop       
0x14287cf52:  e8c9452d03           call      0x145b51520
0x14287cf57:  cc                   int3      
0x14287cf58:  e8c3452d03           call      0x145b51520
0x14287cf5d:  90                   nop       
0x14287cf5e:  488d4db0             lea       rcx, [rbp - 0x50]
0x14287cf62:  e889def3fd           call      0x1407badf0
0x14287cf67:  488d15d29c4805       lea       rdx, [rip + 0x5489cd2]
0x14287cf6e:  488d4db0             lea       rcx, [rbp - 0x50]
0x14287cf72:  e8d9602c03           call      0x145b43050
0x14287cf77:  cc                   int3      
0x14287cf78:  488d4db0             lea       rcx, [rbp - 0x50]
0x14287cf7c:  e86fdef3fd           call      0x1407badf0
0x14287cf81:  488d15b89c4805       lea       rdx, [rip + 0x5489cb8]
0x14287cf88:  488d4db0             lea       rcx, [rbp - 0x50]
0x14287cf8c:  e8bf602c03           call      0x145b43050
0x14287cf91:  cc                   int3      
0x14287cf92:  488d4db0             lea       rcx, [rbp - 0x50]
0x14287cf96:  e855def3fd           call      0x1407badf0
0x14287cf9b:  488d159e9c4805       lea       rdx, [rip + 0x5489c9e]
0x14287cfa2:  488d4db0             lea       rcx, [rbp - 0x50]
0x14287cfa6:  e8a5602c03           call      0x145b43050
0x14287cfab:  cc                   int3      
0x14287cfac:  488d8d68010000       lea       rcx, [rbp + 0x168]
0x14287cfb3:  e838def3fd           call      0x1407badf0
0x14287cfb8:  488d15819c4805       lea       rdx, [rip + 0x5489c81]
0x14287cfbf:  488d8d68010000       lea       rcx, [rbp + 0x168]
0x14287cfc6:  e885602c03           call      0x145b43050
0x14287cfcb:  90                   nop       
0x14287cfcc:  488d4d60             lea       rcx, [rbp + 0x60]
0x14287cfd0:  e81bdef3fd           call      0x1407badf0
0x14287cfd5:  488d15649c4805       lea       rdx, [rip + 0x5489c64]
0x14287cfdc:  488d4d60             lea       rcx, [rbp + 0x60]
0x14287cfe0:  e86b602c03           call      0x145b43050
0x14287cfe5:  cc                   int3      
0x14287cfe6:  cc                   int3      
0x14287cfe7:  cc                   int3      
0x14287cfe8:  cc                   int3      
0x14287cfe9:  cc                   int3      
0x14287cfea:  cc                   int3      
0x14287cfeb:  cc                   int3      
0x14287cfec:  cc                   int3      
0x14287cfed:  cc                   int3      
0x14287cfee:  cc                   int3      
0x14287cfef:  cc                   int3      
0x14287cff0:  48895c2410           mov       qword ptr [rsp + 0x10], rbx
0x14287cff5:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x14287cffa:  57                   push      rdi
0x14287cffb:  4883ec20             sub       rsp, 0x20
0x14287cfff:  488bf2               mov       rsi, rdx
0x14287d002:  488bd9               mov       rbx, rcx
0x14287d005:  4881c188080000       add       rcx, 0x888
0x14287d00c:  e89f672a03           call      0x145b237b0
0x14287d011:  85c0                 test      eax, eax
0x14287d013:  7544                 jne       0x14287d059
0x14287d015:  488bd6               mov       rdx, rsi
0x14287d018:  488d4c2430           lea       rcx, [rsp + 0x30]
0x14287d01d:  e8fec50300           call      0x1428b9620
0x14287d022:  90                   nop       
0x14287d023:  488bd0               mov       rdx, rax
0x14287d026:  488d8b80090000       lea       rcx, [rbx + 0x980]
0x14287d02d:  e83e570200           call      0x1428a2770
0x14287d032:  90                   nop       
0x14287d033:  488d4c2430           lea       rcx, [rsp + 0x30]
0x14287d038:  e8d3cb0300           call      0x1428b9c10
0x14287d03d:  90                   nop       
0x14287d03e:  488d8b88080000       lea       rcx, [rbx + 0x888]
0x14287d045:  488b5c2438           mov       rbx, qword ptr [rsp + 0x38]
0x14287d04a:  488b742440           mov       rsi, qword ptr [rsp + 0x40]
0x14287d04f:  4883c420             add       rsp, 0x20
0x14287d053:  5f                   pop       rdi
0x14287d054:  e9b7672a03           jmp       0x145b23810
0x14287d059:  8bc8                 mov       ecx, eax
0x14287d05b:  e8206d2a03           call      0x145b23d80
0x14287d060:  cc                   int3      
0x14287d061:  cc                   int3      
0x14287d062:  cc                   int3      
0x14287d063:  cc                   int3      
0x14287d064:  cc                   int3      
0x14287d065:  cc                   int3      
0x14287d066:  cc                   int3      
0x14287d067:  cc                   int3      
0x14287d068:  cc                   int3      
0x14287d069:  cc                   int3      
0x14287d06a:  cc                   int3      
0x14287d06b:  cc                   int3      
0x14287d06c:  cc                   int3      
0x14287d06d:  cc                   int3      
0x14287d06e:  cc                   int3      
0x14287d06f:  cc                   int3      
0x14287d070:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x14287d075:  48896c2410           mov       qword ptr [rsp + 0x10], rbp
0x14287d07a:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x14287d07f:  48897c2420           mov       qword ptr [rsp + 0x20], rdi
0x14287d084:  4155                 push      r13
0x14287d086:  4156                 push      r14
0x14287d088:  4157                 push      r15
0x14287d08a:  4883ec20             sub       rsp, 0x20
0x14287d08e:  4c8bf2               mov       r14, rdx
0x14287d091:  488bf1               mov       rsi, rcx
0x14287d094:  83b98809000000       cmp       dword ptr [rcx + 0x988], 0
0x14287d09b:  7473                 je        0x14287d110
0x14287d09d:  4881c188080000       add       rcx, 0x888
0x14287d0a4:  4885d2               test      rdx, rdx
0x14287d0a7:  0f8582000000         jne       0x14287d12f
0x14287d0ad:  e8fe662a03           call      0x145b237b0
0x14287d0b2:  85c0                 test      eax, eax
0x14287d0b4:  0f85f5010000         jne       0x14287d2af
0x14287d0ba:  39868c090000         cmp       dword ptr [rsi + 0x98c], eax
0x14287d0c0:  7442                 je        0x14287d104
0x14287d0c2:  488b8e80090000       mov       rcx, qword ptr [rsi + 0x980]
0x14287d0c9:  4885c9               test      rcx, rcx
0x14287d0cc:  7420                 je        0x14287d0ee
0x14287d0ce:  488d59f8             lea       rbx, [rcx - 8]
0x14287d0d2:  4c8d0d77c50300       lea       r9, [rip + 0x3c577]
0x14287d0d9:  4c8b03               mov       r8, qword ptr [rbx]
0x14287d0dc:  8d5008               lea       edx, [rax + 8]
0x14287d0df:  e8cc452a03           call      0x145b216b0
0x14287d0e4:  90                   nop       
0x14287d0e5:  488bcb               mov       rcx, rbx
0x14287d0e8:  e8c35f0c02           call      0x1449430b0
0x14287d0ed:  90                   nop       
0x14287d0ee:  48c7868809000000000000 mov       qword ptr [rsi + 0x988], 0
0x14287d0f9:  48c7868009000000000000 mov       qword ptr [rsi + 0x980], 0
0x14287d104:  488d8e88080000       lea       rcx, [rsi + 0x888]
0x14287d10b:  e800672a03           call      0x145b23810
0x14287d110:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x14287d115:  488b6c2448           mov       rbp, qword ptr [rsp + 0x48]
0x14287d11a:  488b742450           mov       rsi, qword ptr [rsp + 0x50]
0x14287d11f:  488b7c2458           mov       rdi, qword ptr [rsp + 0x58]
0x14287d124:  4883c420             add       rsp, 0x20
0x14287d128:  415f                 pop       r15
0x14287d12a:  415e                 pop       r14
0x14287d12c:  415d                 pop       r13
0x14287d12e:  c3                   ret       
0x14287d12f:  4533ff               xor       r15d, r15d
0x14287d132:  e879662a03           call      0x145b237b0
0x14287d137:  85c0                 test      eax, eax
0x14287d139:  0f8560010000         jne       0x14287d29f
0x14287d13f:  448b8e88090000       mov       r9d, dword ptr [rsi + 0x988]
0x14287d146:  4585c9               test      r9d, r9d
0x14287d149:  74b9                 je        0x14287d104
0x14287d14b:  0f1f440000           nop       dword ptr [rax + rax]
0x14287d150:  4e8d04fd00000000     lea       r8, [r15*8]
0x14287d158:  410fb60e             movzx     ecx, byte ptr [r14]
0x14287d15c:  84c9                 test      cl, cl
0x14287d15e:  0f8423010000         je        0x14287d287
0x14287d164:  48c7c0ffffffff       mov       rax, 0xffffffffffffffff
0x14287d16b:  0f1f440000           nop       dword ptr [rax + rax]
0x14287d170:  48ffc0               inc       rax
0x14287d173:  41803c0600           cmp       byte ptr [r14 + rax], 0
0x14287d178:  75f6                 jne       0x14287d170
0x14287d17a:  4883f80f             cmp       rax, 0xf
0x14287d17e:  0f8703010000         ja        0x14287d287
0x14287d184:  33d2                 xor       edx, edx
0x14287d186:  4c8b9680090000       mov       r10, qword ptr [rsi + 0x980]
0x14287d18d:  4f8d1c02             lea       r11, [r10 + r8]
0x14287d191:  498b03               mov       rax, qword ptr [r11]
0x14287d194:  4c8b4020             mov       r8, qword ptr [rax + 0x20]
0x14287d198:  413808               cmp       byte ptr [r8], cl
0x14287d19b:  7514                 jne       0x14287d1b1
0x14287d19d:  0f1f00               nop       dword ptr [rax]
0x14287d1a0:  84c9                 test      cl, cl
0x14287d1a2:  7430                 je        0x14287d1d4
0x14287d1a4:  ffc2                 inc       edx
0x14287d1a6:  420fb60c32           movzx     ecx, byte ptr [rdx + r14]
0x14287d1ab:  41380c10             cmp       byte ptr [r8 + rdx], cl
0x14287d1af:  74ef                 je        0x14287d1a0
0x14287d1b1:  8bc2                 mov       eax, edx
0x14287d1b3:  410fb61410           movzx     edx, byte ptr [r8 + rdx]
0x14287d1b8:  84d2                 test      dl, dl
0x14287d1ba:  0f84c7000000         je        0x14287d287
0x14287d1c0:  42803c3000           cmp       byte ptr [rax + r14], 0
0x14287d1c5:  0f84bc000000         je        0x14287d287
0x14287d1cb:  80fa2a               cmp       dl, 0x2a
0x14287d1ce:  0f85b3000000         jne       0x14287d287
0x14287d1d4:  418d41ff             lea       eax, [r9 - 1]
0x14287d1d8:  498d14c2             lea       rdx, [r10 + rax*8]
0x14287d1dc:  498bcb               mov       rcx, r11
0x14287d1df:  e87cc40300           call      0x1428b9660
0x14287d1e4:  8b9688090000         mov       edx, dword ptr [rsi + 0x988]
0x14287d1ea:  ffca                 dec       edx
0x14287d1ec:  8b8e88090000         mov       ecx, dword ptr [rsi + 0x988]
0x14287d1f2:  3bd1                 cmp       edx, ecx
0x14287d1f4:  0f8390000000         jae       0x14287d28a
0x14287d1fa:  8d41ff               lea       eax, [rcx - 1]
0x14287d1fd:  3bd0                 cmp       edx, eax
0x14287d1ff:  737b                 jae       0x14287d27c
0x14287d201:  0f1f4000             nop       dword ptr [rax]
0x14287d205:  6666660f1f840000000000 nop       word ptr [rax + rax]
0x14287d210:  8d6a01               lea       ebp, [rdx + 1]
0x14287d213:  488b8e80090000       mov       rcx, qword ptr [rsi + 0x980]
0x14287d21a:  488d3ce9             lea       rdi, [rcx + rbp*8]
0x14287d21e:  8bc2                 mov       eax, edx
0x14287d220:  488d1cc1             lea       rbx, [rcx + rax*8]
0x14287d224:  488bcb               mov       rcx, rbx
0x14287d227:  e8e4c90300           call      0x1428b9c10
0x14287d22c:  488b0f               mov       rcx, qword ptr [rdi]
0x14287d22f:  488d058a454a05       lea       rax, [rip + 0x54a458a]
0x14287d236:  483bc8               cmp       rcx, rax
0x14287d239:  7432                 je        0x14287d26d
0x14287d23b:  488b09               mov       rcx, qword ptr [rcx]
0x14287d23e:  e86d652a03           call      0x145b237b0
0x14287d243:  85c0                 test      eax, eax
0x14287d245:  7560                 jne       0x14287d2a7
0x14287d247:  488b07               mov       rax, qword ptr [rdi]
0x14287d24a:  83780800             cmp       dword ptr [rax + 8], 0
0x14287d24e:  750c                 jne       0x14287d25c
0x14287d250:  488d0569454a05       lea       rax, [rip + 0x54a4569]
0x14287d257:  488903               mov       qword ptr [rbx], rax
0x14287d25a:  eb06                 jmp       0x14287d262
0x14287d25c:  488903               mov       qword ptr [rbx], rax
0x14287d25f:  ff4008               inc       dword ptr [rax + 8]
0x14287d262:  488b0f               mov       rcx, qword ptr [rdi]
0x14287d265:  488b09               mov       rcx, qword ptr [rcx]
0x14287d268:  e8a3652a03           call      0x145b23810
0x14287d26d:  8bd5                 mov       edx, ebp
0x14287d26f:  8b8e88090000         mov       ecx, dword ptr [rsi + 0x988]
0x14287d275:  8d41ff               lea       eax, [rcx - 1]
0x14287d278:  3be8                 cmp       ebp, eax
0x14287d27a:  7294                 jb        0x14287d210
0x14287d27c:  8d41ff               lea       eax, [rcx - 1]
0x14287d27f:  898688090000         mov       dword ptr [rsi + 0x988], eax
0x14287d285:  eb03                 jmp       0x14287d28a
0x14287d287:  41ffc7               inc       r15d
0x14287d28a:  448b8e88090000       mov       r9d, dword ptr [rsi + 0x988]
0x14287d291:  453bf9               cmp       r15d, r9d
0x14287d294:  0f836afeffff         jae       0x14287d104
0x14287d29a:  e9b1feffff           jmp       0x14287d150
0x14287d29f:  8bc8                 mov       ecx, eax
0x14287d2a1:  e8da6a2a03           call      0x145b23d80
0x14287d2a6:  cc                   int3      
0x14287d2a7:  8bc8                 mov       ecx, eax
0x14287d2a9:  e8d26a2a03           call      0x145b23d80
0x14287d2ae:  cc                   int3      
0x14287d2af:  8bc8                 mov       ecx, eax
0x14287d2b1:  e8ca6a2a03           call      0x145b23d80
0x14287d2b6:  cc                   int3      
0x14287d2b7:  cc                   int3      
0x14287d2b8:  cc                   int3      
0x14287d2b9:  cc                   int3      
0x14287d2ba:  cc                   int3      
0x14287d2bb:  cc                   int3      
0x14287d2bc:  cc                   int3      
0x14287d2bd:  cc                   int3      
0x14287d2be:  cc                   int3      
0x14287d2bf:  cc                   int3      
0x14287d2c0:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x14287d2c5:  57                   push      rdi
0x14287d2c6:  4883ec20             sub       rsp, 0x20
0x14287d2ca:  83b98809000000       cmp       dword ptr [rcx + 0x988], 0
0x14287d2d1:  488bda               mov       rbx, rdx
0x14287d2d4:  488bf9               mov       rdi, rcx
0x14287d2d7:  750d                 jne       0x14287d2e6
0x14287d2d9:  32c0                 xor       al, al
0x14287d2db:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x14287d2e0:  4883c420             add       rsp, 0x20
0x14287d2e4:  5f                   pop       rdi
0x14287d2e5:  c3                   ret       
0x14287d2e6:  48896c2430           mov       qword ptr [rsp + 0x30], rbp
0x14287d2eb:  4881c188080000       add       rcx, 0x888
0x14287d2f2:  4889742438           mov       qword ptr [rsp + 0x38], rsi
0x14287d2f7:  33f6                 xor       esi, esi
0x14287d2f9:  e8b2642a03           call      0x145b237b0
0x14287d2fe:  85c0                 test      eax, eax
0x14287d300:  0f85ad000000         jne       0x14287d3b3
0x14287d306:  448b9788090000       mov       r10d, dword ptr [rdi + 0x988]
0x14287d30d:  4585d2               test      r10d, r10d
0x14287d310:  746e                 je        0x14287d380
0x14287d312:  4c8b9f80090000       mov       r11, qword ptr [rdi + 0x980]
0x14287d319:  0f1f8000000000       nop       dword ptr [rax]
0x14287d320:  4885db               test      rbx, rbx
0x14287d323:  7454                 je        0x14287d379
0x14287d325:  0fb603               movzx     eax, byte ptr [rbx]
0x14287d328:  84c0                 test      al, al
0x14287d32a:  744d                 je        0x14287d379
0x14287d32c:  48c7c1ffffffff       mov       rcx, 0xffffffffffffffff
0x14287d333:  48ffc1               inc       rcx
0x14287d336:  803c0b00             cmp       byte ptr [rbx + rcx], 0
0x14287d33a:  75f7                 jne       0x14287d333
0x14287d33c:  4883f90f             cmp       rcx, 0xf
0x14287d340:  7737                 ja        0x14287d379
0x14287d342:  498b14f3             mov       rdx, qword ptr [r11 + rsi*8]
0x14287d346:  4533c0               xor       r8d, r8d
0x14287d349:  4c8b4a20             mov       r9, qword ptr [rdx + 0x20]
0x14287d34d:  413801               cmp       byte ptr [r9], al
0x14287d350:  7512                 jne       0x14287d364
0x14287d352:  84c0                 test      al, al
0x14287d354:  744d                 je        0x14287d3a3
0x14287d356:  41ffc0               inc       r8d
0x14287d359:  410fb60418           movzx     eax, byte ptr [r8 + rbx]
0x14287d35e:  43380401             cmp       byte ptr [r9 + r8], al
0x14287d362:  74ee                 je        0x14287d352
0x14287d364:  430fb60c01           movzx     ecx, byte ptr [r9 + r8]
0x14287d369:  84c9                 test      cl, cl
0x14287d36b:  740c                 je        0x14287d379
0x14287d36d:  41803c1800           cmp       byte ptr [r8 + rbx], 0
0x14287d372:  7405                 je        0x14287d379
0x14287d374:  80f92a               cmp       cl, 0x2a
0x14287d377:  742a                 je        0x14287d3a3
0x14287d379:  ffc6                 inc       esi
0x14287d37b:  413bf2               cmp       esi, r10d
0x14287d37e:  72a0                 jb        0x14287d320
0x14287d380:  488d8f88080000       lea       rcx, [rdi + 0x888]
0x14287d387:  e884642a03           call      0x145b23810
0x14287d38c:  32c0                 xor       al, al
0x14287d38e:  488b6c2430           mov       rbp, qword ptr [rsp + 0x30]
0x14287d393:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x14287d398:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x14287d39d:  4883c420             add       rsp, 0x20
0x14287d3a1:  5f                   pop       rdi
0x14287d3a2:  c3                   ret       
0x14287d3a3:  488d8f88080000       lea       rcx, [rdi + 0x888]
0x14287d3aa:  e861642a03           call      0x145b23810
0x14287d3af:  b001                 mov       al, 1
0x14287d3b1:  ebdb                 jmp       0x14287d38e
0x14287d3b3:  8bc8                 mov       ecx, eax
0x14287d3b5:  e8c6692a03           call      0x145b23d80
0x14287d3ba:  cc                   int3      
0x14287d3bb:  cc                   int3      
0x14287d3bc:  cc                   int3      
0x14287d3bd:  cc                   int3      
0x14287d3be:  cc                   int3      
0x14287d3bf:  cc                   int3      
