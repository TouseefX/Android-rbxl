; lambda5653 vtable slot 0 rva 0x2277110
0x142277110:  488d057917a204       lea       rax, [rip + 0x4a21779]
0x142277117:  488902               mov       qword ptr [rdx], rax
0x14227711a:  488b4108             mov       rax, qword ptr [rcx + 8]
0x14227711e:  48894208             mov       qword ptr [rdx + 8], rax
0x142277122:  488bc2               mov       rax, rdx
0x142277125:  c3                   ret       
0x142277126:  cc                   int3      
0x142277127:  cc                   int3      
0x142277128:  cc                   int3      
0x142277129:  cc                   int3      
0x14227712a:  cc                   int3      
0x14227712b:  cc                   int3      
0x14227712c:  cc                   int3      
0x14227712d:  cc                   int3      
0x14227712e:  cc                   int3      
0x14227712f:  cc                   int3      
0x142277130:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x142277135:  55                   push      rbp
0x142277136:  56                   push      rsi
0x142277137:  57                   push      rdi
0x142277138:  4154                 push      r12
0x14227713a:  4156                 push      r14
0x14227713c:  4883ec50             sub       rsp, 0x50
0x142277140:  488b05a9c5a905       mov       rax, qword ptr [rip + 0x5a9c5a9]
0x142277147:  4833c4               xor       rax, rsp
0x14227714a:  4889442448           mov       qword ptr [rsp + 0x48], rax
0x14227714f:  488bda               mov       rbx, rdx
0x142277152:  488bf9               mov       rdi, rcx
0x142277155:  48894c2420           mov       qword ptr [rsp + 0x20], rcx
0x14227715a:  4c8d6210             lea       r12, [rdx + 0x10]
0x14227715e:  498b2c24             mov       rbp, qword ptr [r12]
0x142277162:  4c8bf2               mov       r14, rdx
0x142277165:  48837a1810           cmp       qword ptr [rdx + 0x18], 0x10
0x14227716a:  7203                 jb        0x14227716f
0x14227716c:  4c8b32               mov       r14, qword ptr [rdx]
0x14227716f:  4885ed               test      rbp, rbp
0x142277172:  0f84ab000000         je        0x142277223
0x142277178:  4c8bc5               mov       r8, rbp
0x14227717b:  ba2d000000           mov       edx, 0x2d
0x142277180:  498bce               mov       rcx, r14
0x142277183:  e878bf8c03           call      0x145b43100
0x142277188:  488bf0               mov       rsi, rax
0x14227718b:  4885c0               test      rax, rax
0x14227718e:  0f848f000000         je        0x142277223
0x142277194:  492bf6               sub       rsi, r14
0x142277197:  4883feff             cmp       rsi, -1
0x14227719b:  0f8482000000         je        0x142277223
0x1422771a1:  4533f6               xor       r14d, r14d
0x1422771a4:  4c89742428           mov       qword ptr [rsp + 0x28], r14
0x1422771a9:  4c89742438           mov       qword ptr [rsp + 0x38], r14
0x1422771ae:  48c74424400f000000   mov       qword ptr [rsp + 0x40], 0xf
0x1422771b7:  4488742428           mov       byte ptr [rsp + 0x28], r14b
0x1422771bc:  4c8bc6               mov       r8, rsi
0x1422771bf:  483bee               cmp       rbp, rsi
0x1422771c2:  4c0f42c5             cmovb     r8, rbp
0x1422771c6:  488bd3               mov       rdx, rbx
0x1422771c9:  48837b1810           cmp       qword ptr [rbx + 0x18], 0x10
0x1422771ce:  7203                 jb        0x1422771d3
0x1422771d0:  488b13               mov       rdx, qword ptr [rbx]
0x1422771d3:  488d4c2428           lea       rcx, [rsp + 0x28]
0x1422771d8:  e873c856fe           call      0x1407e3a50
0x1422771dd:  90                   nop       
0x1422771de:  4d8b0424             mov       r8, qword ptr [r12]
0x1422771e2:  48ffc6               inc       rsi
0x1422771e5:  4c3bc6               cmp       r8, rsi
0x1422771e8:  490f42f0             cmovb     rsi, r8
0x1422771ec:  48837b1810           cmp       qword ptr [rbx + 0x18], 0x10
0x1422771f1:  7203                 jb        0x1422771f6
0x1422771f3:  488b1b               mov       rbx, qword ptr [rbx]
0x1422771f6:  4c2bc6               sub       r8, rsi
0x1422771f9:  4d890424             mov       qword ptr [r12], r8
0x1422771fd:  49ffc0               inc       r8
0x142277200:  488d1433             lea       rdx, [rbx + rsi]
0x142277204:  488bcb               mov       rcx, rbx
0x142277207:  e894bf8c03           call      0x145b431a0
0x14227720c:  0f10442428           movups    xmm0, xmmword ptr [rsp + 0x28]
0x142277211:  0f1107               movups    xmmword ptr [rdi], xmm0
0x142277214:  0f104c2438           movups    xmm1, xmmword ptr [rsp + 0x38]
0x142277219:  0f114f10             movups    xmmword ptr [rdi + 0x10], xmm1
0x14227721d:  c6472001             mov       byte ptr [rdi + 0x20], 1
0x142277221:  eb04                 jmp       0x142277227
0x142277223:  c6472000             mov       byte ptr [rdi + 0x20], 0
0x142277227:  488bc7               mov       rax, rdi
0x14227722a:  488b4c2448           mov       rcx, qword ptr [rsp + 0x48]
0x14227722f:  4833cc               xor       rcx, rsp
0x142277232:  e8a9a38a03           call      0x145b215e0
0x142277237:  488b9c2490000000     mov       rbx, qword ptr [rsp + 0x90]
0x14227723f:  4883c450             add       rsp, 0x50
0x142277243:  415e                 pop       r14
0x142277245:  415c                 pop       r12
0x142277247:  5f                   pop       rdi
0x142277248:  5e                   pop       rsi
0x142277249:  5d                   pop       rbp
0x14227724a:  c3                   ret       
0x14227724b:  cc                   int3      
0x14227724c:  cc                   int3      
0x14227724d:  cc                   int3      
0x14227724e:  cc                   int3      
0x14227724f:  cc                   int3      
0x142277250:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x142277255:  55                   push      rbp
0x142277256:  56                   push      rsi
0x142277257:  57                   push      rdi
0x142277258:  4154                 push      r12
0x14227725a:  4155                 push      r13
0x14227725c:  488d6c24c9           lea       rbp, [rsp - 0x37]
0x142277261:  4881ecf0000000       sub       rsp, 0xf0
0x142277268:  488b0581c4a905       mov       rax, qword ptr [rip + 0x5a9c481]
0x14227726f:  4833c4               xor       rax, rsp
0x142277272:  4889452f             mov       qword ptr [rbp + 0x2f], rax
0x142277276:  4c8be9               mov       r13, rcx
0x142277279:  488d4db7             lea       rcx, [rbp - 0x49]
0x14227727d:  e8decc56fe           call      0x1407e3f60
0x142277282:  90                   nop       
0x142277283:  0f57c0               xorps     xmm0, xmm0
0x142277286:  33c0                 xor       eax, eax
0x142277288:  0f1145f7             movups    xmmword ptr [rbp - 9], xmm0
0x14227728c:  894507               mov       dword ptr [rbp + 7], eax
0x14227728f:  6689450b             mov       word ptr [rbp + 0xb], ax
0x142277293:  488d55b7             lea       rdx, [rbp - 0x49]
0x142277297:  488d4d8f             lea       rcx, [rbp - 0x71]
0x14227729b:  e890feffff           call      0x142277130
0x1422772a0:  90                   nop       
0x1422772a1:  488d55b7             lea       rdx, [rbp - 0x49]
0x1422772a5:  488d4c2420           lea       rcx, [rsp + 0x20]
0x1422772aa:  e881feffff           call      0x142277130
0x1422772af:  90                   nop       
0x1422772b0:  440fb66587           movzx     r12d, byte ptr [rbp - 0x79]
0x1422772b5:  807daf00             cmp       byte ptr [rbp - 0x51], 0
0x1422772b9:  0f84c8040000         je        0x142277787
0x1422772bf:  4584e4               test      r12b, r12b
0x1422772c2:  0f84bf040000         je        0x142277787
0x1422772c8:  33ff                 xor       edi, edi
0x1422772ca:  48897dd7             mov       qword ptr [rbp - 0x29], rdi
0x1422772ce:  48897de7             mov       qword ptr [rbp - 0x19], rdi
0x1422772d2:  48c745ef0f000000     mov       qword ptr [rbp - 0x11], 0xf
0x1422772da:  40887dd7             mov       byte ptr [rbp - 0x29], dil
0x1422772de:  488d5db7             lea       rbx, [rbp - 0x49]
0x1422772e2:  48837dcf10           cmp       qword ptr [rbp - 0x31], 0x10
0x1422772e7:  480f435db7           cmovae    rbx, qword ptr [rbp - 0x49]
0x1422772ec:  488b75c7             mov       rsi, qword ptr [rbp - 0x39]
0x1422772f0:  4885f6               test      rsi, rsi
0x1422772f3:  745c                 je        0x142277351
0x1422772f5:  4c8bc6               mov       r8, rsi
0x1422772f8:  8d572e               lea       edx, [rdi + 0x2e]
0x1422772fb:  488bcb               mov       rcx, rbx
0x1422772fe:  e8fdbd8c03           call      0x145b43100
0x142277303:  4885c0               test      rax, rax
0x142277306:  7449                 je        0x142277351
0x142277308:  482bc3               sub       rax, rbx
0x14227730b:  4883f8ff             cmp       rax, -1
0x14227730f:  7440                 je        0x142277351
0x142277311:  48897d0f             mov       qword ptr [rbp + 0xf], rdi
0x142277315:  48897d1f             mov       qword ptr [rbp + 0x1f], rdi
0x142277319:  48c745270f000000     mov       qword ptr [rbp + 0x27], 0xf
0x142277321:  483bf0               cmp       rsi, rax
0x142277324:  480f42c6             cmovb     rax, rsi
0x142277328:  488d55b7             lea       rdx, [rbp - 0x49]
0x14227732c:  48837dcf10           cmp       qword ptr [rbp - 0x31], 0x10
0x142277331:  480f4355b7           cmovae    rdx, qword ptr [rbp - 0x49]
0x142277336:  4c8bc0               mov       r8, rax
0x142277339:  488d4d0f             lea       rcx, [rbp + 0xf]
0x14227733d:  e80ec756fe           call      0x1407e3a50
0x142277342:  0f10450f             movups    xmm0, xmmword ptr [rbp + 0xf]
0x142277346:  0f104d1f             movups    xmm1, xmmword ptr [rbp + 0x1f]
0x14227734a:  440fb66587           movzx     r12d, byte ptr [rbp - 0x79]
0x14227734f:  eb18                 jmp       0x142277369
0x142277351:  0f1045b7             movups    xmm0, xmmword ptr [rbp - 0x49]
0x142277355:  0f104dc7             movups    xmm1, xmmword ptr [rbp - 0x39]
0x142277359:  48897dc7             mov       qword ptr [rbp - 0x39], rdi
0x14227735d:  48c745cf0f000000     mov       qword ptr [rbp - 0x31], 0xf
0x142277365:  c645b700             mov       byte ptr [rbp - 0x49], 0
0x142277369:  0f114de7             movups    xmmword ptr [rbp - 0x19], xmm1
0x14227736d:  0f1145d7             movups    xmmword ptr [rbp - 0x29], xmm0
0x142277371:  488b75e7             mov       rsi, qword ptr [rbp - 0x19]
0x142277375:  4885f6               test      rsi, rsi
0x142277378:  0f85a0000000         jne       0x14227741e
0x14227737e:  41887516             mov       byte ptr [r13 + 0x16], sil
0x142277382:  488b45ef             mov       rax, qword ptr [rbp - 0x11]
0x142277386:  4883f810             cmp       rax, 0x10
0x14227738a:  7232                 jb        0x1422773be
0x14227738c:  48ffc0               inc       rax
0x14227738f:  488b4dd7             mov       rcx, qword ptr [rbp - 0x29]
0x142277393:  488bd1               mov       rdx, rcx
0x142277396:  483d00100000         cmp       rax, 0x1000
0x14227739c:  7215                 jb        0x1422773b3
0x14227739e:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x1422773a2:  482bd1               sub       rdx, rcx
0x1422773a5:  488d42f8             lea       rax, [rdx - 8]
0x1422773a9:  4883f81f             cmp       rax, 0x1f
0x1422773ad:  0f8758040000         ja        0x14227780b
0x1422773b3:  e8f8bc6c02           call      0x1449430b0
0x1422773b8:  90                   nop       
0x1422773b9:  440fb66587           movzx     r12d, byte ptr [rbp - 0x79]
0x1422773be:  4584e4               test      r12b, r12b
0x1422773c1:  740b                 je        0x1422773ce
0x1422773c3:  488d4c2420           lea       rcx, [rsp + 0x20]
0x1422773c8:  e813e656fe           call      0x1407e59e0
0x1422773cd:  90                   nop       
0x1422773ce:  807daf00             cmp       byte ptr [rbp - 0x51], 0
0x1422773d2:  740a                 je        0x1422773de
0x1422773d4:  488d4d8f             lea       rcx, [rbp - 0x71]
0x1422773d8:  e803e656fe           call      0x1407e59e0
0x1422773dd:  90                   nop       
0x1422773de:  488b45cf             mov       rax, qword ptr [rbp - 0x31]
0x1422773e2:  4883f810             cmp       rax, 0x10
0x1422773e6:  0f82f3030000         jb        0x1422777df
0x1422773ec:  48ffc0               inc       rax
0x1422773ef:  488b4db7             mov       rcx, qword ptr [rbp - 0x49]
0x1422773f3:  488bd1               mov       rdx, rcx
0x1422773f6:  483d00100000         cmp       rax, 0x1000
0x1422773fc:  7215                 jb        0x142277413
0x1422773fe:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x142277402:  482bd1               sub       rdx, rcx
0x142277405:  488d42f8             lea       rax, [rdx - 8]
0x142277409:  4883f81f             cmp       rax, 0x1f
0x14227740d:  0f87f2030000         ja        0x142277805
0x142277413:  e898bc6c02           call      0x1449430b0
0x142277418:  90                   nop       
0x142277419:  e9c1030000           jmp       0x1422777df
0x14227741e:  488b5def             mov       rbx, qword ptr [rbp - 0x11]
0x142277422:  4c8b5dd7             mov       r11, qword ptr [rbp - 0x29]
0x142277426:  48837d9f20           cmp       qword ptr [rbp - 0x61], 0x20
0x14227742b:  0f85bc020000         jne       0x1422776ed
0x142277431:  4c8bc7               mov       r8, rdi
0x142277434:  4c8b4da7             mov       r9, qword ptr [rbp - 0x59]
0x142277438:  4c8b558f             mov       r10, qword ptr [rbp - 0x71]
0x14227743c:  0f1f4000             nop       dword ptr [rax]
0x142277440:  488d458f             lea       rax, [rbp - 0x71]
0x142277444:  4983f910             cmp       r9, 0x10
0x142277448:  490f43c2             cmovae    rax, r10
0x14227744c:  420fbe0c40           movsx     ecx, byte ptr [rax + r8*2]
0x142277451:  8d41d0               lea       eax, [rcx - 0x30]
0x142277454:  3c09                 cmp       al, 9
0x142277456:  7705                 ja        0x14227745d
0x142277458:  83e930               sub       ecx, 0x30
0x14227745b:  eb1d                 jmp       0x14227747a
0x14227745d:  8d419f               lea       eax, [rcx - 0x61]
0x142277460:  3c05                 cmp       al, 5
0x142277462:  7705                 ja        0x142277469
0x142277464:  83e957               sub       ecx, 0x57
0x142277467:  eb11                 jmp       0x14227747a
0x142277469:  8d41bf               lea       eax, [rcx - 0x41]
0x14227746c:  3c05                 cmp       al, 5
0x14227746e:  7705                 ja        0x142277475
0x142277470:  83e937               sub       ecx, 0x37
0x142277473:  eb05                 jmp       0x14227747a
0x142277475:  b9ffffffff           mov       ecx, 0xffffffff
0x14227747a:  488d458f             lea       rax, [rbp - 0x71]
0x14227747e:  4983f910             cmp       r9, 0x10
0x142277482:  490f43c2             cmovae    rax, r10
0x142277486:  420fbe544001         movsx     edx, byte ptr [rax + r8*2 + 1]
0x14227748c:  8d42d0               lea       eax, [rdx - 0x30]
0x14227748f:  3c09                 cmp       al, 9
0x142277491:  7705                 ja        0x142277498
0x142277493:  8d42d0               lea       eax, [rdx - 0x30]
0x142277496:  eb1b                 jmp       0x1422774b3
0x142277498:  8d429f               lea       eax, [rdx - 0x61]
0x14227749b:  3c05                 cmp       al, 5
0x14227749d:  7705                 ja        0x1422774a4
0x14227749f:  8d42a9               lea       eax, [rdx - 0x57]
0x1422774a2:  eb0f                 jmp       0x1422774b3
0x1422774a4:  8d42bf               lea       eax, [rdx - 0x41]
0x1422774a7:  3c05                 cmp       al, 5
0x1422774a9:  8d42c9               lea       eax, [rdx - 0x37]
0x1422774ac:  7605                 jbe       0x1422774b3
0x1422774ae:  b8ffffffff           mov       eax, 0xffffffff
0x1422774b3:  85c9                 test      ecx, ecx
0x1422774b5:  0f8832020000         js        0x1422776ed
0x1422774bb:  85c0                 test      eax, eax
0x1422774bd:  0f882a020000         js        0x1422776ed
0x1422774c3:  c0e104               shl       cl, 4
0x1422774c6:  0ac8                 or        cl, al
0x1422774c8:  42884c05f7           mov       byte ptr [rbp + r8 - 9], cl
0x1422774cd:  49ffc0               inc       r8
0x1422774d0:  4983f810             cmp       r8, 0x10
0x1422774d4:  0f8266ffffff         jb        0x142277440
0x1422774da:  48837c243008         cmp       qword ptr [rsp + 0x30], 8
0x1422774e0:  0f8507020000         jne       0x1422776ed
0x1422774e6:  4c8bc7               mov       r8, rdi
0x1422774e9:  4c8b4c2438           mov       r9, qword ptr [rsp + 0x38]
0x1422774ee:  4c8b542420           mov       r10, qword ptr [rsp + 0x20]
0x1422774f3:  488d442420           lea       rax, [rsp + 0x20]
0x1422774f8:  4983f910             cmp       r9, 0x10
0x1422774fc:  490f43c2             cmovae    rax, r10
0x142277500:  420fbe0c40           movsx     ecx, byte ptr [rax + r8*2]
0x142277505:  8d41d0               lea       eax, [rcx - 0x30]
0x142277508:  3c09                 cmp       al, 9
0x14227750a:  7705                 ja        0x142277511
0x14227750c:  83e930               sub       ecx, 0x30
0x14227750f:  eb1d                 jmp       0x14227752e
0x142277511:  8d419f               lea       eax, [rcx - 0x61]
0x142277514:  3c05                 cmp       al, 5
0x142277516:  7705                 ja        0x14227751d
0x142277518:  83e957               sub       ecx, 0x57
0x14227751b:  eb11                 jmp       0x14227752e
0x14227751d:  8d41bf               lea       eax, [rcx - 0x41]
0x142277520:  3c05                 cmp       al, 5
0x142277522:  7705                 ja        0x142277529
0x142277524:  83e937               sub       ecx, 0x37
0x142277527:  eb05                 jmp       0x14227752e
0x142277529:  b9ffffffff           mov       ecx, 0xffffffff
0x14227752e:  488d442420           lea       rax, [rsp + 0x20]
0x142277533:  4983f910             cmp       r9, 0x10
0x142277537:  490f43c2             cmovae    rax, r10
0x14227753b:  420fbe544001         movsx     edx, byte ptr [rax + r8*2 + 1]
0x142277541:  8d42d0               lea       eax, [rdx - 0x30]
0x142277544:  3c09                 cmp       al, 9
0x142277546:  7705                 ja        0x14227754d
0x142277548:  8d42d0               lea       eax, [rdx - 0x30]
0x14227754b:  eb1b                 jmp       0x142277568
0x14227754d:  8d429f               lea       eax, [rdx - 0x61]
0x142277550:  3c05                 cmp       al, 5
0x142277552:  7705                 ja        0x142277559
0x142277554:  8d42a9               lea       eax, [rdx - 0x57]
0x142277557:  eb0f                 jmp       0x142277568
0x142277559:  8d42bf               lea       eax, [rdx - 0x41]
0x14227755c:  3c05                 cmp       al, 5
0x14227755e:  8d42c9               lea       eax, [rdx - 0x37]
0x142277561:  7605                 jbe       0x142277568
0x142277563:  b8ffffffff           mov       eax, 0xffffffff
0x142277568:  85c9                 test      ecx, ecx
0x14227756a:  0f887d010000         js        0x1422776ed
0x142277570:  85c0                 test      eax, eax
0x142277572:  0f8875010000         js        0x1422776ed
0x142277578:  c0e104               shl       cl, 4
0x14227757b:  0ac8                 or        cl, al
0x14227757d:  42884c0507           mov       byte ptr [rbp + r8 + 7], cl
0x142277582:  49ffc0               inc       r8
0x142277585:  4983f804             cmp       r8, 4
0x142277589:  0f8264ffffff         jb        0x1422774f3
0x14227758f:  4883fe04             cmp       rsi, 4
0x142277593:  0f8554010000         jne       0x1422776ed
0x142277599:  0f1f8000000000       nop       dword ptr [rax]
0x1422775a0:  488d45d7             lea       rax, [rbp - 0x29]
0x1422775a4:  4883fb10             cmp       rbx, 0x10
0x1422775a8:  490f43c3             cmovae    rax, r11
0x1422775ac:  0fbe0c78             movsx     ecx, byte ptr [rax + rdi*2]
0x1422775b0:  8d41d0               lea       eax, [rcx - 0x30]
0x1422775b3:  3c09                 cmp       al, 9
0x1422775b5:  7705                 ja        0x1422775bc
0x1422775b7:  83e930               sub       ecx, 0x30
0x1422775ba:  eb1d                 jmp       0x1422775d9
0x1422775bc:  8d419f               lea       eax, [rcx - 0x61]
0x1422775bf:  3c05                 cmp       al, 5
0x1422775c1:  7705                 ja        0x1422775c8
0x1422775c3:  83e957               sub       ecx, 0x57
0x1422775c6:  eb11                 jmp       0x1422775d9
0x1422775c8:  8d41bf               lea       eax, [rcx - 0x41]
0x1422775cb:  3c05                 cmp       al, 5
0x1422775cd:  7705                 ja        0x1422775d4
0x1422775cf:  83e937               sub       ecx, 0x37
0x1422775d2:  eb05                 jmp       0x1422775d9
0x1422775d4:  b9ffffffff           mov       ecx, 0xffffffff
0x1422775d9:  488d45d7             lea       rax, [rbp - 0x29]
0x1422775dd:  4883fb10             cmp       rbx, 0x10
0x1422775e1:  490f43c3             cmovae    rax, r11
0x1422775e5:  0fbe547801           movsx     edx, byte ptr [rax + rdi*2 + 1]
0x1422775ea:  8d42d0               lea       eax, [rdx - 0x30]
0x1422775ed:  3c09                 cmp       al, 9
0x1422775ef:  7705                 ja        0x1422775f6
0x1422775f1:  8d42d0               lea       eax, [rdx - 0x30]
0x1422775f4:  eb1b                 jmp       0x142277611
0x1422775f6:  8d429f               lea       eax, [rdx - 0x61]
0x1422775f9:  3c05                 cmp       al, 5
0x1422775fb:  7705                 ja        0x142277602
0x1422775fd:  8d42a9               lea       eax, [rdx - 0x57]
0x142277600:  eb0f                 jmp       0x142277611
0x142277602:  8d42bf               lea       eax, [rdx - 0x41]
0x142277605:  3c05                 cmp       al, 5
0x142277607:  8d42c9               lea       eax, [rdx - 0x37]
0x14227760a:  7605                 jbe       0x142277611
0x14227760c:  b8ffffffff           mov       eax, 0xffffffff
0x142277611:  85c9                 test      ecx, ecx
0x142277613:  0f88d4000000         js        0x1422776ed
0x142277619:  85c0                 test      eax, eax
0x14227761b:  0f88cc000000         js        0x1422776ed
0x142277621:  c0e104               shl       cl, 4
0x142277624:  0ac8                 or        cl, al
0x142277626:  884c3d0b             mov       byte ptr [rbp + rdi + 0xb], cl
0x14227762a:  48ffc7               inc       rdi
0x14227762d:  4883ff02             cmp       rdi, 2
0x142277631:  0f8269ffffff         jb        0x1422775a0
0x142277637:  0f1045f7             movups    xmm0, xmmword ptr [rbp - 9]
0x14227763b:  410f114500           movups    xmmword ptr [r13], xmm0
0x142277640:  8b4507               mov       eax, dword ptr [rbp + 7]
0x142277643:  41894510             mov       dword ptr [r13 + 0x10], eax
0x142277647:  0fb7450b             movzx     eax, word ptr [rbp + 0xb]
0x14227764b:  6641894514           mov       word ptr [r13 + 0x14], ax
0x142277650:  41c6451601           mov       byte ptr [r13 + 0x16], 1
0x142277655:  4883fb10             cmp       rbx, 0x10
0x142277659:  7232                 jb        0x14227768d
0x14227765b:  488d4301             lea       rax, [rbx + 1]
0x14227765f:  498bcb               mov       rcx, r11
0x142277662:  483d00100000         cmp       rax, 0x1000
0x142277668:  7215                 jb        0x14227767f
0x14227766a:  4d8b5bf8             mov       r11, qword ptr [r11 - 8]
0x14227766e:  492bcb               sub       rcx, r11
0x142277671:  488d41f8             lea       rax, [rcx - 8]
0x142277675:  4883f81f             cmp       rax, 0x1f
0x142277679:  0f878c010000         ja        0x14227780b
0x14227767f:  498bcb               mov       rcx, r11
0x142277682:  e829ba6c02           call      0x1449430b0
0x142277687:  90                   nop       
0x142277688:  440fb66587           movzx     r12d, byte ptr [rbp - 0x79]
0x14227768d:  4584e4               test      r12b, r12b
0x142277690:  740b                 je        0x14227769d
0x142277692:  488d4c2420           lea       rcx, [rsp + 0x20]
0x142277697:  e844e356fe           call      0x1407e59e0
0x14227769c:  90                   nop       
0x14227769d:  807daf00             cmp       byte ptr [rbp - 0x51], 0
0x1422776a1:  740a                 je        0x1422776ad
0x1422776a3:  488d4d8f             lea       rcx, [rbp - 0x71]
0x1422776a7:  e834e356fe           call      0x1407e59e0
0x1422776ac:  90                   nop       
0x1422776ad:  488b45cf             mov       rax, qword ptr [rbp - 0x31]
0x1422776b1:  4883f810             cmp       rax, 0x10
0x1422776b5:  0f8224010000         jb        0x1422777df
0x1422776bb:  48ffc0               inc       rax
0x1422776be:  488b4db7             mov       rcx, qword ptr [rbp - 0x49]
0x1422776c2:  488bd1               mov       rdx, rcx
0x1422776c5:  483d00100000         cmp       rax, 0x1000
0x1422776cb:  7215                 jb        0x1422776e2
0x1422776cd:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x1422776d1:  482bd1               sub       rdx, rcx
0x1422776d4:  488d42f8             lea       rax, [rdx - 8]
0x1422776d8:  4883f81f             cmp       rax, 0x1f
0x1422776dc:  0f8723010000         ja        0x142277805
0x1422776e2:  e8c9b96c02           call      0x1449430b0
0x1422776e7:  90                   nop       
0x1422776e8:  e9f2000000           jmp       0x1422777df
0x1422776ed:  41c6451600           mov       byte ptr [r13 + 0x16], 0
0x1422776f2:  4883fb10             cmp       rbx, 0x10
0x1422776f6:  7232                 jb        0x14227772a
0x1422776f8:  488d4301             lea       rax, [rbx + 1]
0x1422776fc:  498bcb               mov       rcx, r11
0x1422776ff:  483d00100000         cmp       rax, 0x1000
0x142277705:  7215                 jb        0x14227771c
0x142277707:  4d8b5bf8             mov       r11, qword ptr [r11 - 8]
0x14227770b:  492bcb               sub       rcx, r11
0x14227770e:  488d41f8             lea       rax, [rcx - 8]
0x142277712:  4883f81f             cmp       rax, 0x1f
0x142277716:  0f87ef000000         ja        0x14227780b
0x14227771c:  498bcb               mov       rcx, r11
0x14227771f:  e88cb96c02           call      0x1449430b0
0x142277724:  90                   nop       
0x142277725:  440fb66587           movzx     r12d, byte ptr [rbp - 0x79]
0x14227772a:  4584e4               test      r12b, r12b
0x14227772d:  740b                 je        0x14227773a
0x14227772f:  488d4c2420           lea       rcx, [rsp + 0x20]
0x142277734:  e8a7e256fe           call      0x1407e59e0
0x142277739:  90                   nop       
0x14227773a:  807daf00             cmp       byte ptr [rbp - 0x51], 0
0x14227773e:  740a                 je        0x14227774a
0x142277740:  488d4d8f             lea       rcx, [rbp - 0x71]
0x142277744:  e897e256fe           call      0x1407e59e0
0x142277749:  90                   nop       
0x14227774a:  488b45cf             mov       rax, qword ptr [rbp - 0x31]
0x14227774e:  4883f810             cmp       rax, 0x10
0x142277752:  0f8287000000         jb        0x1422777df
0x142277758:  48ffc0               inc       rax
0x14227775b:  488b4db7             mov       rcx, qword ptr [rbp - 0x49]
0x14227775f:  488bd1               mov       rdx, rcx
0x142277762:  483d00100000         cmp       rax, 0x1000
0x142277768:  7215                 jb        0x14227777f
0x14227776a:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x14227776e:  482bd1               sub       rdx, rcx
0x142277771:  488d42f8             lea       rax, [rdx - 8]
0x142277775:  4883f81f             cmp       rax, 0x1f
0x142277779:  0f8786000000         ja        0x142277805
0x14227777f:  e82cb96c02           call      0x1449430b0
0x142277784:  90                   nop       
0x142277785:  eb58                 jmp       0x1422777df
0x142277787:  41c6451600           mov       byte ptr [r13 + 0x16], 0
0x14227778c:  4584e4               test      r12b, r12b
0x14227778f:  740b                 je        0x14227779c
0x142277791:  488d4c2420           lea       rcx, [rsp + 0x20]
0x142277796:  e845e256fe           call      0x1407e59e0
0x14227779b:  90                   nop       
0x14227779c:  807daf00             cmp       byte ptr [rbp - 0x51], 0
0x1422777a0:  740a                 je        0x1422777ac
0x1422777a2:  488d4d8f             lea       rcx, [rbp - 0x71]
0x1422777a6:  e835e256fe           call      0x1407e59e0
0x1422777ab:  90                   nop       
0x1422777ac:  488b45cf             mov       rax, qword ptr [rbp - 0x31]
0x1422777b0:  4883f810             cmp       rax, 0x10
0x1422777b4:  7229                 jb        0x1422777df
0x1422777b6:  48ffc0               inc       rax
0x1422777b9:  488b4db7             mov       rcx, qword ptr [rbp - 0x49]
0x1422777bd:  488bd1               mov       rdx, rcx
0x1422777c0:  483d00100000         cmp       rax, 0x1000
0x1422777c6:  7211                 jb        0x1422777d9
0x1422777c8:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x1422777cc:  482bd1               sub       rdx, rcx
0x1422777cf:  488d42f8             lea       rax, [rdx - 8]
0x1422777d3:  4883f81f             cmp       rax, 0x1f
0x1422777d7:  772c                 ja        0x142277805
0x1422777d9:  e8d2b86c02           call      0x1449430b0
0x1422777de:  90                   nop       
0x1422777df:  498bc5               mov       rax, r13
0x1422777e2:  488b4d2f             mov       rcx, qword ptr [rbp + 0x2f]
0x1422777e6:  4833cc               xor       rcx, rsp
0x1422777e9:  e8f29d8a03           call      0x145b215e0
0x1422777ee:  488b9c2430010000     mov       rbx, qword ptr [rsp + 0x130]
0x1422777f6:  4881c4f0000000       add       rsp, 0xf0
0x1422777fd:  415d                 pop       r13
0x1422777ff:  415c                 pop       r12
0x142277801:  5f                   pop       rdi
0x142277802:  5e                   pop       rsi
0x142277803:  5d                   pop       rbp
0x142277804:  c3                   ret       
0x142277805:  e8169d8d03           call      0x145b51520
0x14227780a:  90                   nop       
0x14227780b:  e8109d8d03           call      0x145b51520
0x142277810:  90                   nop       
0x142277811:  cc                   int3      
0x142277812:  cc                   int3      
0x142277813:  cc                   int3      
0x142277814:  cc                   int3      
0x142277815:  cc                   int3      
0x142277816:  cc                   int3      
0x142277817:  cc                   int3      
0x142277818:  cc                   int3      
0x142277819:  cc                   int3      
0x14227781a:  cc                   int3      
0x14227781b:  cc                   int3      
0x14227781c:  cc                   int3      
0x14227781d:  cc                   int3      
0x14227781e:  cc                   int3      
0x14227781f:  cc                   int3      
