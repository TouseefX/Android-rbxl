; RakPeer vtable slot 64
; rva 0x2883650
0x142883650:  8b8178090000         mov       eax, dword ptr [rcx + 0x978]
0x142883656:  c3                   ret       
0x142883657:  cc                   int3      
0x142883658:  cc                   int3      
0x142883659:  cc                   int3      
0x14288365a:  cc                   int3      
0x14288365b:  cc                   int3      
0x14288365c:  cc                   int3      
0x14288365d:  cc                   int3      
0x14288365e:  cc                   int3      
0x14288365f:  cc                   int3      
