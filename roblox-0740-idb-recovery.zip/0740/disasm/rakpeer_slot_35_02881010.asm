; RakPeer vtable slot 35
; rva 0x2881010
0x142881010:  4c8bca               mov       r9, rdx
0x142881013:  4585c0               test      r8d, r8d
0x142881016:  784a                 js        0x142881062
0x142881018:  0fb78112010000       movzx     eax, word ptr [rcx + 0x112]
0x14288101f:  443bc0               cmp       r8d, eax
0x142881022:  7d3e                 jge       0x142881062
0x142881024:  4963c0               movsxd    rax, r8d
0x142881027:  4c69c0d8160000       imul      r8, rax, 0x16d8
0x14288102e:  488b8150030000       mov       rax, qword ptr [rcx + 0x350]
0x142881035:  410fb61400           movzx     edx, byte ptr [r8 + rax]
0x14288103a:  90                   nop       
0x14288103b:  84d2                 test      dl, dl
0x14288103d:  7423                 je        0x142881062
0x14288103f:  488b8150030000       mov       rax, qword ptr [rcx + 0x350]
0x142881046:  4183bc00d416000007   cmp       dword ptr [r8 + rax + 0x16d4], 7
0x14288104f:  7511                 jne       0x142881062
0x142881051:  410f10840030160000   movups    xmm0, xmmword ptr [r8 + rax + 0x1630]
0x14288105a:  498bc1               mov       rax, r9
0x14288105d:  410f1101             movups    xmmword ptr [r9], xmm0
0x142881061:  c3                   ret       
0x142881062:  0f1005ffe75605       movups    xmm0, xmmword ptr [rip + 0x556e7ff]
0x142881069:  498bc1               mov       rax, r9
0x14288106c:  410f1101             movups    xmmword ptr [r9], xmm0
0x142881070:  c3                   ret       
0x142881071:  cc                   int3      
0x142881072:  cc                   int3      
0x142881073:  cc                   int3      
0x142881074:  cc                   int3      
0x142881075:  cc                   int3      
0x142881076:  cc                   int3      
0x142881077:  cc                   int3      
0x142881078:  cc                   int3      
0x142881079:  cc                   int3      
0x14288107a:  cc                   int3      
0x14288107b:  cc                   int3      
0x14288107c:  cc                   int3      
0x14288107d:  cc                   int3      
0x14288107e:  cc                   int3      
0x14288107f:  cc                   int3      
0x142881080:  4c89442418           mov       qword ptr [rsp + 0x18], r8
0x142881085:  48894c2408           mov       qword ptr [rsp + 8], rcx
0x14288108a:  53                   push      rbx
0x14288108b:  55                   push      rbp
0x14288108c:  56                   push      rsi
0x14288108d:  57                   push      rdi
0x14288108e:  4154                 push      r12
0x142881090:  4155                 push      r13
0x142881092:  4156                 push      r14
0x142881094:  4157                 push      r15
0x142881096:  4881ecc8000000       sub       rsp, 0xc8
0x14288109d:  498bf0               mov       rsi, r8
0x1428810a0:  4c8bf2               mov       r14, rdx
0x1428810a3:  4c8be9               mov       r13, rcx
0x1428810a6:  33ed                 xor       ebp, ebp
0x1428810a8:  396a0c               cmp       dword ptr [rdx + 0xc], ebp
0x1428810ab:  7410                 je        0x1428810bd
0x1428810ad:  488b0a               mov       rcx, qword ptr [rdx]
0x1428810b0:  e8fb1f0c02           call      0x1449430b0
0x1428810b5:  90                   nop       
0x1428810b6:  49896e08             mov       qword ptr [r14 + 8], rbp
0x1428810ba:  49892e               mov       qword ptr [r14], rbp
0x1428810bd:  837e0c00             cmp       dword ptr [rsi + 0xc], 0
0x1428810c1:  7410                 je        0x1428810d3
0x1428810c3:  488b0e               mov       rcx, qword ptr [rsi]
0x1428810c6:  e8e51f0c02           call      0x1449430b0
0x1428810cb:  90                   nop       
0x1428810cc:  48896e08             mov       qword ptr [rsi + 8], rbp
0x1428810d0:  48892e               mov       qword ptr [rsi], rbp
0x1428810d3:  4983bd5003000000     cmp       qword ptr [r13 + 0x350], 0
0x1428810db:  0f8467050000         je        0x142881648
0x1428810e1:  410fb68508010000     movzx     eax, byte ptr [r13 + 0x108]
0x1428810e9:  90                   nop       
0x1428810ea:  3c01                 cmp       al, 1
0x1428810ec:  0f8456050000         je        0x142881648
0x1428810f2:  8bcd                 mov       ecx, ebp
0x1428810f4:  898c2418010000       mov       dword ptr [rsp + 0x118], ecx
0x1428810fb:  418b8560030000       mov       eax, dword ptr [r13 + 0x360]
0x142881102:  90                   nop       
0x142881103:  85c0                 test      eax, eax
0x142881105:  0f843d050000         je        0x142881648
0x14288110b:  49c7c0ffffffff       mov       r8, 0xffffffffffffffff
0x142881112:  4c8d1d77ad1106       lea       r11, [rip + 0x611ad77]
0x142881119:  0f1f8000000000       nop       dword ptr [rax]
0x142881120:  448be1               mov       r12d, ecx
0x142881123:  498b8558030000       mov       rax, qword ptr [r13 + 0x358]
0x14288112a:  4a8b0ce0             mov       rcx, qword ptr [rax + r12*8]
0x14288112e:  0fb601               movzx     eax, byte ptr [rcx]
0x142881131:  90                   nop       
0x142881132:  84c0                 test      al, al
0x142881134:  0f84ee040000         je        0x142881628
0x14288113a:  498b8558030000       mov       rax, qword ptr [r13 + 0x358]
0x142881141:  4e8b3ce0             mov       r15, qword ptr [rax + r12*8]
0x142881145:  4183bfd416000007     cmp       dword ptr [r15 + 0x16d4], 7
0x14288114d:  0f85d5040000         jne       0x142881628
0x142881153:  418b460c             mov       eax, dword ptr [r14 + 0xc]
0x142881157:  41394608             cmp       dword ptr [r14 + 8], eax
0x14288115b:  0f8534020000         jne       0x142881395
0x142881161:  85c0                 test      eax, eax
0x142881163:  0f85ff000000         jne       0x142881268
0x142881169:  41c7460c10000000     mov       dword ptr [r14 + 0xc], 0x10
0x142881171:  b810000000           mov       eax, 0x10
0x142881176:  4863d8               movsxd    rbx, eax
0x142881179:  b820000000           mov       eax, 0x20
0x14288117e:  48f7e3               mul       rbx
0x142881181:  490f40c0             cmovo     rax, r8
0x142881185:  488bc8               mov       rcx, rax
0x142881188:  e873260c02           call      0x144943800
0x14288118d:  488bf8               mov       rdi, rax
0x142881190:  4885c0               test      rax, rax
0x142881193:  0f84c3040000         je        0x14288165c
0x142881199:  4889842428010000     mov       qword ptr [rsp + 0x128], rax
0x1428811a1:  488bc8               mov       rcx, rax
0x1428811a4:  4885db               test      rbx, rbx
0x1428811a7:  743b                 je        0x1428811e4
0x1428811a9:  41bd02000000         mov       r13d, 2
0x1428811af:  90                   nop       
0x1428811b0:  0f57c0               xorps     xmm0, xmm0
0x1428811b3:  33c0                 xor       eax, eax
0x1428811b5:  0f1101               movups    xmmword ptr [rcx], xmm0
0x1428811b8:  48894110             mov       qword ptr [rcx + 0x10], rax
0x1428811bc:  894118               mov       dword ptr [rcx + 0x18], eax
0x1428811bf:  66448929             mov       word ptr [rcx], r13w
0x1428811c3:  c7411c0000ffff       mov       dword ptr [rcx + 0x1c], 0xffff0000
0x1428811ca:  488d4920             lea       rcx, [rcx + 0x20]
0x1428811ce:  4883eb01             sub       rbx, 1
0x1428811d2:  75dc                 jne       0x1428811b0
0x1428811d4:  488bb42420010000     mov       rsi, qword ptr [rsp + 0x120]
0x1428811dc:  4c8bac2410010000     mov       r13, qword ptr [rsp + 0x110]
0x1428811e4:  4c8d1da5ac1106       lea       r11, [rip + 0x611aca5]
0x1428811eb:  49833e00             cmp       qword ptr [r14], 0
0x1428811ef:  0f8496010000         je        0x14288138b
0x1428811f5:  448bc5               mov       r8d, ebp
0x1428811f8:  41837e0800           cmp       dword ptr [r14 + 8], 0
0x1428811fd:  7644                 jbe       0x142881243
0x1428811ff:  90                   nop       
0x142881200:  418bd0               mov       edx, r8d
0x142881203:  48c1e205             shl       rdx, 5
0x142881207:  498b0e               mov       rcx, qword ptr [r14]
0x14288120a:  0f10040a             movups    xmm0, xmmword ptr [rdx + rcx]
0x14288120e:  0f11043a             movups    xmmword ptr [rdx + rdi], xmm0
0x142881212:  f20f104c0a10         movsd     xmm1, qword ptr [rdx + rcx + 0x10]
0x142881218:  f20f114c3a10         movsd     qword ptr [rdx + rdi + 0x10], xmm1
0x14288121e:  8b440a18             mov       eax, dword ptr [rdx + rcx + 0x18]
0x142881222:  89443a18             mov       dword ptr [rdx + rdi + 0x18], eax
0x142881226:  0fb7440a1e           movzx     eax, word ptr [rdx + rcx + 0x1e]
0x14288122b:  6689443a1e           mov       word ptr [rdx + rdi + 0x1e], ax
0x142881230:  0fb7440a1c           movzx     eax, word ptr [rdx + rcx + 0x1c]
0x142881235:  6689443a1c           mov       word ptr [rdx + rdi + 0x1c], ax
0x14288123a:  41ffc0               inc       r8d
0x14288123d:  453b4608             cmp       r8d, dword ptr [r14 + 8]
0x142881241:  72bd                 jb        0x142881200
0x142881243:  4d8b16               mov       r10, qword ptr [r14]
0x142881246:  4d85d2               test      r10, r10
0x142881249:  0f843c010000         je        0x14288138b
0x14288124f:  0fb605b58a9805       movzx     eax, byte ptr [rip + 0x5988ab5]
0x142881256:  90                   nop       
0x142881257:  498bca               mov       rcx, r10
0x14288125a:  84c0                 test      al, al
0x14288125c:  741e                 je        0x14288127c
0x14288125e:  e83da0f3fd           call      0x1407bb2a0
0x142881263:  e923010000           jmp       0x14288138b
0x142881268:  03c0                 add       eax, eax
0x14288126a:  4189460c             mov       dword ptr [r14 + 0xc], eax
0x14288126e:  0f8502ffffff         jne       0x142881176
0x142881274:  488bfd               mov       rdi, rbp
0x142881277:  e96fffffff           jmp       0x1428811eb
0x14288127c:  48c1e910             shr       rcx, 0x10
0x142881280:  488bd1               mov       rdx, rcx
0x142881283:  81e2ff1f0000         and       edx, 0x1fff
0x142881289:  48c1e90d             shr       rcx, 0xd
0x14288128d:  488b05ecff9205       mov       rax, qword ptr [rip + 0x592ffec]
0x142881294:  488b0cc8             mov       rcx, qword ptr [rax + rcx*8]
0x142881298:  90                   nop       
0x142881299:  488b0cd1             mov       rcx, qword ptr [rcx + rdx*8]
0x14288129d:  4885c9               test      rcx, rcx
0x1428812a0:  741a                 je        0x1428812bc
0x1428812a2:  488b01               mov       rax, qword ptr [rcx]
0x1428812a5:  d0e8                 shr       al, 1
0x1428812a7:  a801                 test      al, 1
0x1428812a9:  7506                 jne       0x1428812b1
0x1428812ab:  488b6928             mov       rbp, qword ptr [rcx + 0x28]
0x1428812af:  eb0b                 jmp       0x1428812bc
0x1428812b1:  498bd2               mov       rdx, r10
0x1428812b4:  e8e7a4f3fd           call      0x1407bb7a0
0x1428812b9:  488be8               mov       rbp, rax
0x1428812bc:  4c8bc5               mov       r8, rbp
0x1428812bf:  498bd2               mov       rdx, r10
0x1428812c2:  488d4c2438           lea       rcx, [rsp + 0x38]
0x1428812c7:  e834ec0f02           call      0x14497ff00
0x1428812cc:  0f1000               movups    xmm0, xmmword ptr [rax]
0x1428812cf:  0f11442460           movups    xmmword ptr [rsp + 0x60], xmm0
0x1428812d4:  4c8d450f             lea       r8, [rbp + 0xf]
0x1428812d8:  4983e0f0             and       r8, 0xfffffffffffffff0
0x1428812dc:  4983c010             add       r8, 0x10
0x1428812e0:  660f7ec0             movd      eax, xmm0
0x1428812e4:  3d00040000           cmp       eax, 0x400
0x1428812e9:  7218                 jb        0x142881303
0x1428812eb:  803da18e980500       cmp       byte ptr [rip + 0x5988ea1], 0
0x1428812f2:  7445                 je        0x142881339
0x1428812f4:  803d4dd2d40500       cmp       byte ptr [rip + 0x5d4d24d], 0
0x1428812fb:  0f8577030000         jne       0x142881678
0x142881301:  eb36                 jmp       0x142881339
0x142881303:  498bd0               mov       rdx, r8
0x142881306:  48f7da               neg       rdx
0x142881309:  8bc8                 mov       ecx, eax
0x14288130b:  48c1e106             shl       rcx, 6
0x14288130f:  488bc2               mov       rax, rdx
0x142881312:  f04a0fc10419         lock xadd qword ptr [rcx + r11], rax
0x142881318:  0fb60d9093e405       movzx     ecx, byte ptr [rip + 0x5e49390]
0x14288131f:  90                   nop       
0x142881320:  84c9                 test      cl, cl
0x142881322:  7415                 je        0x142881339
0x142881324:  488b055dab1206       mov       rax, qword ptr [rip + 0x612ab5d]
0x14288132b:  4c3bc0               cmp       r8, rax
0x14288132e:  7309                 jae       0x142881339
0x142881330:  f0480fc1154fab1206   lock xadd qword ptr [rip + 0x612ab4f], rdx
0x142881339:  498bca               mov       rcx, r10
0x14288133c:  e85f9ff3fd           call      0x1407bb2a0
0x142881341:  803d7393e40500       cmp       byte ptr [rip + 0x5e49373], 0
0x142881348:  7420                 je        0x14288136a
0x14288134a:  e8f1c90e02           call      0x14496dd40
0x14288134f:  488bd8               mov       rbx, rax
0x142881352:  ff4004               inc       dword ptr [rax + 4]
0x142881355:  0f57c0               xorps     xmm0, xmm0
0x142881358:  e863462e03           call      0x145b659c0
0x14288135d:  48c1f804             sar       rax, 4
0x142881361:  01431c               add       dword ptr [rbx + 0x1c], eax
0x142881364:  48016b10             add       qword ptr [rbx + 0x10], rbp
0x142881368:  eb1f                 jmp       0x142881389
0x14288136a:  ff056c671506         inc       dword ptr [rip + 0x615676c]
0x142881370:  0f57c0               xorps     xmm0, xmm0
0x142881373:  e848462e03           call      0x145b659c0
0x142881378:  48c1f804             sar       rax, 4
0x14288137c:  010572671506         add       dword ptr [rip + 0x6156772], eax
0x142881382:  48012d5f671506       add       qword ptr [rip + 0x615675f], rbp
0x142881389:  33ed                 xor       ebp, ebp
0x14288138b:  49893e               mov       qword ptr [r14], rdi
0x14288138e:  49c7c0ffffffff       mov       r8, 0xffffffffffffffff
0x142881395:  418b4e08             mov       ecx, dword ptr [r14 + 8]
0x142881399:  48c1e105             shl       rcx, 5
0x14288139d:  49030e               add       rcx, qword ptr [r14]
0x1428813a0:  410f104704           movups    xmm0, xmmword ptr [r15 + 4]
0x1428813a5:  0f1101               movups    xmmword ptr [rcx], xmm0
0x1428813a8:  f2410f104f14         movsd     xmm1, qword ptr [r15 + 0x14]
0x1428813ae:  f20f114910           movsd     qword ptr [rcx + 0x10], xmm1
0x1428813b3:  418b471c             mov       eax, dword ptr [r15 + 0x1c]
0x1428813b7:  894118               mov       dword ptr [rcx + 0x18], eax
0x1428813ba:  410fb74722           movzx     eax, word ptr [r15 + 0x22]
0x1428813bf:  6689411e             mov       word ptr [rcx + 0x1e], ax
0x1428813c3:  410fb74720           movzx     eax, word ptr [r15 + 0x20]
0x1428813c8:  6689411c             mov       word ptr [rcx + 0x1c], ax
0x1428813cc:  41ff4608             inc       dword ptr [r14 + 8]
0x1428813d0:  498b8558030000       mov       rax, qword ptr [r13 + 0x358]
0x1428813d7:  4e8b3ce0             mov       r15, qword ptr [rax + r12*8]
0x1428813db:  8b460c               mov       eax, dword ptr [rsi + 0xc]
0x1428813de:  394608               cmp       dword ptr [rsi + 8], eax
0x1428813e1:  0f8510020000         jne       0x1428815f7
0x1428813e7:  85c0                 test      eax, eax
0x1428813e9:  0f85da000000         jne       0x1428814c9
0x1428813ef:  c7460c10000000       mov       dword ptr [rsi + 0xc], 0x10
0x1428813f6:  b810000000           mov       eax, 0x10
0x1428813fb:  4863d8               movsxd    rbx, eax
0x1428813fe:  b810000000           mov       eax, 0x10
0x142881403:  48f7e3               mul       rbx
0x142881406:  490f40c0             cmovo     rax, r8
0x14288140a:  488bc8               mov       rcx, rax
0x14288140d:  e8ee230c02           call      0x144943800
0x142881412:  488bf8               mov       rdi, rax
0x142881415:  4885c0               test      rax, rax
0x142881418:  0f8478020000         je        0x142881696
0x14288141e:  4889842428010000     mov       qword ptr [rsp + 0x128], rax
0x142881426:  4885db               test      rbx, rbx
0x142881429:  7439                 je        0x142881464
0x14288142b:  488d4808             lea       rcx, [rax + 8]
0x14288142f:  bdffff0000           mov       ebp, 0xffff
0x142881434:  0f1f4000             nop       dword ptr [rax]
0x142881438:  0f1f840000000000     nop       dword ptr [rax + rax]
0x142881440:  668929               mov       word ptr [rcx], bp
0x142881443:  488b051ee45605       mov       rax, qword ptr [rip + 0x556e41e]
0x14288144a:  488941f8             mov       qword ptr [rcx - 8], rax
0x14288144e:  0fb7051be45605       movzx     eax, word ptr [rip + 0x556e41b]
0x142881455:  668901               mov       word ptr [rcx], ax
0x142881458:  488d4910             lea       rcx, [rcx + 0x10]
0x14288145c:  4883eb01             sub       rbx, 1
0x142881460:  75de                 jne       0x142881440
0x142881462:  33ed                 xor       ebp, ebp
0x142881464:  48833e00             cmp       qword ptr [rsi], 0
0x142881468:  0f8486010000         je        0x1428815f4
0x14288146e:  448bc5               mov       r8d, ebp
0x142881471:  837e0800             cmp       dword ptr [rsi + 8], 0
0x142881475:  762d                 jbe       0x1428814a4
0x142881477:  660f1f840000000000   nop       word ptr [rax + rax]
0x142881480:  418bd0               mov       edx, r8d
0x142881483:  4803d2               add       rdx, rdx
0x142881486:  488b0e               mov       rcx, qword ptr [rsi]
0x142881489:  488b04d1             mov       rax, qword ptr [rcx + rdx*8]
0x14288148d:  488904d7             mov       qword ptr [rdi + rdx*8], rax
0x142881491:  0fb744d108           movzx     eax, word ptr [rcx + rdx*8 + 8]
0x142881496:  668944d708           mov       word ptr [rdi + rdx*8 + 8], ax
0x14288149b:  41ffc0               inc       r8d
0x14288149e:  443b4608             cmp       r8d, dword ptr [rsi + 8]
0x1428814a2:  72dc                 jb        0x142881480
0x1428814a4:  4c8b16               mov       r10, qword ptr [rsi]
0x1428814a7:  4d85d2               test      r10, r10
0x1428814aa:  0f8444010000         je        0x1428815f4
0x1428814b0:  0fb60554889805       movzx     eax, byte ptr [rip + 0x5988854]
0x1428814b7:  90                   nop       
0x1428814b8:  498bca               mov       rcx, r10
0x1428814bb:  84c0                 test      al, al
0x1428814bd:  741a                 je        0x1428814d9
0x1428814bf:  e8dc9df3fd           call      0x1407bb2a0
0x1428814c4:  e92b010000           jmp       0x1428815f4
0x1428814c9:  03c0                 add       eax, eax
0x1428814cb:  89460c               mov       dword ptr [rsi + 0xc], eax
0x1428814ce:  0f8527ffffff         jne       0x1428813fb
0x1428814d4:  488bfd               mov       rdi, rbp
0x1428814d7:  eb8b                 jmp       0x142881464
0x1428814d9:  48c1e910             shr       rcx, 0x10
0x1428814dd:  488bd1               mov       rdx, rcx
0x1428814e0:  81e2ff1f0000         and       edx, 0x1fff
0x1428814e6:  48c1e90d             shr       rcx, 0xd
0x1428814ea:  488b058ffd9205       mov       rax, qword ptr [rip + 0x592fd8f]
0x1428814f1:  488b0cc8             mov       rcx, qword ptr [rax + rcx*8]
0x1428814f5:  90                   nop       
0x1428814f6:  488b0cd1             mov       rcx, qword ptr [rcx + rdx*8]
0x1428814fa:  4885c9               test      rcx, rcx
0x1428814fd:  741a                 je        0x142881519
0x1428814ff:  488b01               mov       rax, qword ptr [rcx]
0x142881502:  d0e8                 shr       al, 1
0x142881504:  a801                 test      al, 1
0x142881506:  7506                 jne       0x14288150e
0x142881508:  488b6928             mov       rbp, qword ptr [rcx + 0x28]
0x14288150c:  eb0b                 jmp       0x142881519
0x14288150e:  498bd2               mov       rdx, r10
0x142881511:  e88aa2f3fd           call      0x1407bb7a0
0x142881516:  488be8               mov       rbp, rax
0x142881519:  4c8bc5               mov       r8, rbp
0x14288151c:  498bd2               mov       rdx, r10
0x14288151f:  488d4c2448           lea       rcx, [rsp + 0x48]
0x142881524:  e8d7e90f02           call      0x14497ff00
0x142881529:  0f1000               movups    xmm0, xmmword ptr [rax]
0x14288152c:  0f11842490000000     movups    xmmword ptr [rsp + 0x90], xmm0
0x142881534:  4c8d450f             lea       r8, [rbp + 0xf]
0x142881538:  4983e0f0             and       r8, 0xfffffffffffffff0
0x14288153c:  4983c010             add       r8, 0x10
0x142881540:  660f7ec0             movd      eax, xmm0
0x142881544:  3d00040000           cmp       eax, 0x400
0x142881549:  7218                 jb        0x142881563
0x14288154b:  803d418c980500       cmp       byte ptr [rip + 0x5988c41], 0
0x142881552:  744e                 je        0x1428815a2
0x142881554:  803dedcfd40500       cmp       byte ptr [rip + 0x5d4cfed], 0
0x14288155b:  0f8526010000         jne       0x142881687
0x142881561:  eb3f                 jmp       0x1428815a2
0x142881563:  498bd0               mov       rdx, r8
0x142881566:  48f7da               neg       rdx
0x142881569:  8bc8                 mov       ecx, eax
0x14288156b:  48c1e106             shl       rcx, 6
0x14288156f:  488d051aa91106       lea       rax, [rip + 0x611a91a]
0x142881576:  4803c8               add       rcx, rax
0x142881579:  488bc2               mov       rax, rdx
0x14288157c:  f0480fc101           lock xadd qword ptr [rcx], rax
0x142881581:  0fb60d2791e405       movzx     ecx, byte ptr [rip + 0x5e49127]
0x142881588:  90                   nop       
0x142881589:  84c9                 test      cl, cl
0x14288158b:  7415                 je        0x1428815a2
0x14288158d:  488b05f4a81206       mov       rax, qword ptr [rip + 0x612a8f4]
0x142881594:  4c3bc0               cmp       r8, rax
0x142881597:  7309                 jae       0x1428815a2
0x142881599:  f0480fc115e6a81206   lock xadd qword ptr [rip + 0x612a8e6], rdx
0x1428815a2:  498bca               mov       rcx, r10
0x1428815a5:  e8f69cf3fd           call      0x1407bb2a0
0x1428815aa:  803d0a91e40500       cmp       byte ptr [rip + 0x5e4910a], 0
0x1428815b1:  7420                 je        0x1428815d3
0x1428815b3:  e888c70e02           call      0x14496dd40
0x1428815b8:  488bd8               mov       rbx, rax
0x1428815bb:  ff4004               inc       dword ptr [rax + 4]
0x1428815be:  0f57c0               xorps     xmm0, xmm0
0x1428815c1:  e8fa432e03           call      0x145b659c0
0x1428815c6:  48c1f804             sar       rax, 4
0x1428815ca:  01431c               add       dword ptr [rbx + 0x1c], eax
0x1428815cd:  48016b10             add       qword ptr [rbx + 0x10], rbp
0x1428815d1:  eb1f                 jmp       0x1428815f2
0x1428815d3:  ff0503651506         inc       dword ptr [rip + 0x6156503]
0x1428815d9:  0f57c0               xorps     xmm0, xmm0
0x1428815dc:  e8df432e03           call      0x145b659c0
0x1428815e1:  48c1f804             sar       rax, 4
0x1428815e5:  010509651506         add       dword ptr [rip + 0x6156509], eax
0x1428815eb:  48012df6641506       add       qword ptr [rip + 0x61564f6], rbp
0x1428815f2:  33ed                 xor       ebp, ebp
0x1428815f4:  48893e               mov       qword ptr [rsi], rdi
0x1428815f7:  8b4e08               mov       ecx, dword ptr [rsi + 8]
0x1428815fa:  48c1e104             shl       rcx, 4
0x1428815fe:  48030e               add       rcx, qword ptr [rsi]
0x142881601:  498b8730160000       mov       rax, qword ptr [r15 + 0x1630]
0x142881608:  488901               mov       qword ptr [rcx], rax
0x14288160b:  410fb78738160000     movzx     eax, word ptr [r15 + 0x1638]
0x142881613:  66894108             mov       word ptr [rcx + 8], ax
0x142881617:  ff4608               inc       dword ptr [rsi + 8]
0x14288161a:  49c7c0ffffffff       mov       r8, 0xffffffffffffffff
0x142881621:  4c8d1d68a81106       lea       r11, [rip + 0x611a868]
0x142881628:  8b8c2418010000       mov       ecx, dword ptr [rsp + 0x118]
0x14288162f:  ffc1                 inc       ecx
0x142881631:  898c2418010000       mov       dword ptr [rsp + 0x118], ecx
0x142881638:  418b8560030000       mov       eax, dword ptr [r13 + 0x360]
0x14288163f:  90                   nop       
0x142881640:  3bc8                 cmp       ecx, eax
0x142881642:  0f82d8faffff         jb        0x142881120
0x142881648:  4881c4c8000000       add       rsp, 0xc8
0x14288164f:  415f                 pop       r15
0x142881651:  415e                 pop       r14
0x142881653:  415d                 pop       r13
0x142881655:  415c                 pop       r12
0x142881657:  5f                   pop       rdi
0x142881658:  5e                   pop       rsi
0x142881659:  5d                   pop       rbp
0x14288165a:  5b                   pop       rbx
0x14288165b:  c3                   ret       
0x14288165c:  488d4c2420           lea       rcx, [rsp + 0x20]
0x142881661:  e88a97f3fd           call      0x1407badf0
0x142881666:  488d15d3554805       lea       rdx, [rip + 0x54855d3]
0x14288166d:  488d4c2420           lea       rcx, [rsp + 0x20]
0x142881672:  e8d9192c03           call      0x145b43050
0x142881677:  90                   nop       
0x142881678:  488d1561378504       lea       rdx, [rip + 0x4853761]
0x14288167f:  33c9                 xor       ecx, ecx
0x142881681:  e8fad50d02           call      0x14495ec80
0x142881686:  90                   nop       
0x142881687:  488d1552378504       lea       rdx, [rip + 0x4853752]
0x14288168e:  33c9                 xor       ecx, ecx
0x142881690:  e8ebd50d02           call      0x14495ec80
0x142881695:  90                   nop       
0x142881696:  488d4c2420           lea       rcx, [rsp + 0x20]
0x14288169b:  e85097f3fd           call      0x1407badf0
0x1428816a0:  488d1599554805       lea       rdx, [rip + 0x5485599]
0x1428816a7:  488d4c2420           lea       rcx, [rsp + 0x20]
0x1428816ac:  e89f192c03           call      0x145b43050
0x1428816b1:  cc                   int3      
0x1428816b2:  cc                   int3      
0x1428816b3:  cc                   int3      
0x1428816b4:  cc                   int3      
0x1428816b5:  cc                   int3      
0x1428816b6:  cc                   int3      
0x1428816b7:  cc                   int3      
0x1428816b8:  cc                   int3      
0x1428816b9:  cc                   int3      
0x1428816ba:  cc                   int3      
0x1428816bb:  cc                   int3      
0x1428816bc:  cc                   int3      
0x1428816bd:  cc                   int3      
0x1428816be:  cc                   int3      
0x1428816bf:  cc                   int3      
