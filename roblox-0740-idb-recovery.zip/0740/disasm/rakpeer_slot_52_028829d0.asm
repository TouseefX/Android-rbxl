; RakPeer vtable slot 52
; rva 0x28829d0
0x1428829d0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x1428829d5:  0fb75a02             movzx     ebx, word ptr [rdx + 2]
0x1428829d9:  4c8bd1               mov       r10, rcx
0x1428829dc:  663b1d67ce5605       cmp       bx, word ptr [rip + 0x556ce67]
0x1428829e3:  7525                 jne       0x142882a0a
0x1428829e5:  0fb702               movzx     eax, word ptr [rdx]
0x1428829e8:  663b0559ce5605       cmp       ax, word ptr [rip + 0x556ce59]
0x1428829ef:  7519                 jne       0x142882a0a
0x1428829f1:  6683f802             cmp       ax, 2
0x1428829f5:  0f85b0000000         jne       0x142882aab
0x1428829fb:  8b054bce5605         mov       eax, dword ptr [rip + 0x556ce4b]
0x142882a01:  394204               cmp       dword ptr [rdx + 4], eax
0x142882a04:  0f84cd000000         je        0x142882ad7
0x142882a0a:  0fb7421e             movzx     eax, word ptr [rdx + 0x1e]
0x142882a0e:  b9ffff0000           mov       ecx, 0xffff
0x142882a13:  663bc1               cmp       ax, cx
0x142882a16:  7440                 je        0x142882a58
0x142882a18:  66413b8212010000     cmp       ax, word ptr [r10 + 0x112]
0x142882a20:  7336                 jae       0x142882a58
0x142882a22:  4c69c0d8160000       imul      r8, rax, 0x16d8
0x142882a29:  4d038250030000       add       r8, qword ptr [r10 + 0x350]
0x142882a30:  6641395806           cmp       word ptr [r8 + 6], bx
0x142882a35:  7521                 jne       0x142882a58
0x142882a37:  410fb74004           movzx     eax, word ptr [r8 + 4]
0x142882a3c:  663b02               cmp       ax, word ptr [rdx]
0x142882a3f:  7517                 jne       0x142882a58
0x142882a41:  6683f802             cmp       ax, 2
0x142882a45:  0f8599000000         jne       0x142882ae4
0x142882a4b:  8b4204               mov       eax, dword ptr [rdx + 4]
0x142882a4e:  41394008             cmp       dword ptr [r8 + 8], eax
0x142882a52:  0f84b2000000         je        0x142882b0a
0x142882a58:  450fb79a12010000     movzx     r11d, word ptr [r10 + 0x112]
0x142882a60:  4533c9               xor       r9d, r9d
0x142882a63:  4585db               test      r11d, r11d
0x142882a66:  0f84d1000000         je        0x142882b3d
0x142882a6c:  4d8b9250030000       mov       r10, qword ptr [r10 + 0x350]
0x142882a73:  418bc1               mov       eax, r9d
0x142882a76:  4c69c0d8160000       imul      r8, rax, 0x16d8
0x142882a7d:  4d03c2               add       r8, r10
0x142882a80:  6641395806           cmp       word ptr [r8 + 6], bx
0x142882a85:  0f85a6000000         jne       0x142882b31
0x142882a8b:  410fb74004           movzx     eax, word ptr [r8 + 4]
0x142882a90:  663b02               cmp       ax, word ptr [rdx]
0x142882a93:  0f8598000000         jne       0x142882b31
0x142882a99:  6683f802             cmp       ax, 2
0x142882a9d:  7578                 jne       0x142882b17
0x142882a9f:  8b4204               mov       eax, dword ptr [rdx + 4]
0x142882aa2:  41394008             cmp       dword ptr [r8 + 8], eax
0x142882aa6:  e984000000           jmp       0x142882b2f
0x142882aab:  6683f817             cmp       ax, 0x17
0x142882aaf:  0f8555ffffff         jne       0x142882a0a
0x142882ab5:  488b4208             mov       rax, qword ptr [rdx + 8]
0x142882ab9:  483b0590cd5605       cmp       rax, qword ptr [rip + 0x556cd90]
0x142882ac0:  0f8544ffffff         jne       0x142882a0a
0x142882ac6:  488b4210             mov       rax, qword ptr [rdx + 0x10]
0x142882aca:  483b0587cd5605       cmp       rax, qword ptr [rip + 0x556cd87]
0x142882ad1:  0f8533ffffff         jne       0x142882a0a
0x142882ad7:  488d8140090000       lea       rax, [rcx + 0x940]
0x142882ade:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882ae3:  c3                   ret       
0x142882ae4:  6683f817             cmp       ax, 0x17
0x142882ae8:  0f856affffff         jne       0x142882a58
0x142882aee:  498b400c             mov       rax, qword ptr [r8 + 0xc]
0x142882af2:  483b4208             cmp       rax, qword ptr [rdx + 8]
0x142882af6:  0f855cffffff         jne       0x142882a58
0x142882afc:  498b4014             mov       rax, qword ptr [r8 + 0x14]
0x142882b00:  483b4210             cmp       rax, qword ptr [rdx + 0x10]
0x142882b04:  0f854effffff         jne       0x142882a58
0x142882b0a:  498d8030160000       lea       rax, [r8 + 0x1630]
0x142882b11:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882b16:  c3                   ret       
0x142882b17:  6683f817             cmp       ax, 0x17
0x142882b1b:  7514                 jne       0x142882b31
0x142882b1d:  498b400c             mov       rax, qword ptr [r8 + 0xc]
0x142882b21:  483b4208             cmp       rax, qword ptr [rdx + 8]
0x142882b25:  750a                 jne       0x142882b31
0x142882b27:  498b4014             mov       rax, qword ptr [r8 + 0x14]
0x142882b2b:  483b4210             cmp       rax, qword ptr [rdx + 0x10]
0x142882b2f:  74d9                 je        0x142882b0a
0x142882b31:  41ffc1               inc       r9d
0x142882b34:  453bcb               cmp       r9d, r11d
0x142882b37:  0f8236ffffff         jb        0x142882a73
0x142882b3d:  488b5c2408           mov       rbx, qword ptr [rsp + 8]
0x142882b42:  488d051fcd5605       lea       rax, [rip + 0x556cd1f]
0x142882b49:  c3                   ret       
0x142882b4a:  cc                   int3      
0x142882b4b:  cc                   int3      
0x142882b4c:  cc                   int3      
0x142882b4d:  cc                   int3      
0x142882b4e:  cc                   int3      
0x142882b4f:  cc                   int3      
