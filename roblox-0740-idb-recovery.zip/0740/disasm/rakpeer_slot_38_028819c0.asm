; RakPeer vtable slot 38
; rva 0x28819c0
0x1428819c0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x1428819c5:  48896c2410           mov       qword ptr [rsp + 0x10], rbp
0x1428819ca:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x1428819cf:  57                   push      rdi
0x1428819d0:  4883ec20             sub       rsp, 0x20
0x1428819d4:  488bf9               mov       rdi, rcx
0x1428819d7:  4883b90805000000     cmp       qword ptr [rcx + 0x508], 0
0x1428819df:  744d                 je        0x142881a2e
0x1428819e1:  4881c1a8040000       add       rcx, 0x4a8
0x1428819e8:  e8c31d2a03           call      0x145b237b0
0x1428819ed:  85c0                 test      eax, eax
0x1428819ef:  7552                 jne       0x142881a43
0x1428819f1:  488b8700050000       mov       rax, qword ptr [rdi + 0x500]
0x1428819f8:  488b18               mov       rbx, qword ptr [rax]
0x1428819fb:  483bd8               cmp       rbx, rax
0x1428819fe:  7416                 je        0x142881a16
0x142881a00:  488b4b30             mov       rcx, qword ptr [rbx + 0x30]
0x142881a04:  e8a7160c02           call      0x1449430b0
0x142881a09:  90                   nop       
0x142881a0a:  488b1b               mov       rbx, qword ptr [rbx]
0x142881a0d:  483b9f00050000       cmp       rbx, qword ptr [rdi + 0x500]
0x142881a14:  75ea                 jne       0x142881a00
0x142881a16:  488d8ff8040000       lea       rcx, [rdi + 0x4f8]
0x142881a1d:  e8cecb8dfe           call      0x14115e5f0
0x142881a22:  488d8fa8040000       lea       rcx, [rdi + 0x4a8]
0x142881a29:  e8e21d2a03           call      0x145b23810
0x142881a2e:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142881a33:  488b6c2438           mov       rbp, qword ptr [rsp + 0x38]
0x142881a38:  488b742440           mov       rsi, qword ptr [rsp + 0x40]
0x142881a3d:  4883c420             add       rsp, 0x20
0x142881a41:  5f                   pop       rdi
0x142881a42:  c3                   ret       
0x142881a43:  8bc8                 mov       ecx, eax
0x142881a45:  e836232a03           call      0x145b23d80
0x142881a4a:  cc                   int3      
0x142881a4b:  cc                   int3      
0x142881a4c:  cc                   int3      
0x142881a4d:  cc                   int3      
0x142881a4e:  cc                   int3      
0x142881a4f:  cc                   int3      
0x142881a50:  8891b80b0000         mov       byte ptr [rcx + 0xbb8], dl
0x142881a56:  c3                   ret       
0x142881a57:  cc                   int3      
0x142881a58:  cc                   int3      
0x142881a59:  cc                   int3      
0x142881a5a:  cc                   int3      
0x142881a5b:  cc                   int3      
0x142881a5c:  cc                   int3      
0x142881a5d:  cc                   int3      
0x142881a5e:  cc                   int3      
0x142881a5f:  cc                   int3      
0x142881a60:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x142881a65:  56                   push      rsi
0x142881a66:  4883ec20             sub       rsp, 0x20
0x142881a6a:  4883b90805000000     cmp       qword ptr [rcx + 0x508], 0
0x142881a72:  488bf2               mov       rsi, rdx
0x142881a75:  488bd9               mov       rbx, rcx
0x142881a78:  750d                 jne       0x142881a87
0x142881a7a:  32c0                 xor       al, al
0x142881a7c:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x142881a81:  4883c420             add       rsp, 0x20
0x142881a85:  5e                   pop       rsi
0x142881a86:  c3                   ret       
0x142881a87:  4881c1a8040000       add       rcx, 0x4a8
0x142881a8e:  48897c2438           mov       qword ptr [rsp + 0x38], rdi
0x142881a93:  e8181d2a03           call      0x145b237b0
0x142881a98:  85c0                 test      eax, eax
0x142881a9a:  753f                 jne       0x142881adb
0x142881a9c:  488d8bf8040000       lea       rcx, [rbx + 0x4f8]
0x142881aa3:  4c8bc6               mov       r8, rsi
0x142881aa6:  488d542430           lea       rdx, [rsp + 0x30]
0x142881aab:  e810130200           call      0x1428a2dc0
0x142881ab0:  488d8ba8040000       lea       rcx, [rbx + 0x4a8]
0x142881ab7:  e8541d2a03           call      0x145b23810
0x142881abc:  488b8300050000       mov       rax, qword ptr [rbx + 0x500]
0x142881ac3:  4839442430           cmp       qword ptr [rsp + 0x30], rax
0x142881ac8:  488b7c2438           mov       rdi, qword ptr [rsp + 0x38]
0x142881acd:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x142881ad2:  0f95c0               setne     al
0x142881ad5:  4883c420             add       rsp, 0x20
0x142881ad9:  5e                   pop       rsi
0x142881ada:  c3                   ret       
0x142881adb:  8bc8                 mov       ecx, eax
0x142881add:  e89e222a03           call      0x145b23d80
0x142881ae2:  cc                   int3      
0x142881ae3:  cc                   int3      
0x142881ae4:  cc                   int3      
0x142881ae5:  cc                   int3      
0x142881ae6:  cc                   int3      
0x142881ae7:  cc                   int3      
0x142881ae8:  cc                   int3      
0x142881ae9:  cc                   int3      
0x142881aea:  cc                   int3      
0x142881aeb:  cc                   int3      
0x142881aec:  cc                   int3      
0x142881aed:  cc                   int3      
0x142881aee:  cc                   int3      
0x142881aef:  cc                   int3      
