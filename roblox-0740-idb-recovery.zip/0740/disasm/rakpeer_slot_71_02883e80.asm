; RakPeer vtable slot 71
; rva 0x2883e80
0x142883e80:  488991d80a0000       mov       qword ptr [rcx + 0xad8], rdx
0x142883e87:  4c8981e00a0000       mov       qword ptr [rcx + 0xae0], r8
0x142883e8e:  c3                   ret       
0x142883e8f:  cc                   int3      
0x142883e90:  48895c2420           mov       qword ptr [rsp + 0x20], rbx
0x142883e95:  55                   push      rbp
0x142883e96:  56                   push      rsi
0x142883e97:  57                   push      rdi
0x142883e98:  4154                 push      r12
0x142883e9a:  4155                 push      r13
0x142883e9c:  4156                 push      r14
0x142883e9e:  4157                 push      r15
0x142883ea0:  488dac2440feffff     lea       rbp, [rsp - 0x1c0]
0x142883ea8:  4881ecc0020000       sub       rsp, 0x2c0
0x142883eaf:  488b053af84805       mov       rax, qword ptr [rip + 0x548f83a]
0x142883eb6:  4833c4               xor       rax, rsp
0x142883eb9:  488985b0010000       mov       qword ptr [rbp + 0x1b0], rax
0x142883ec0:  4d8bf0               mov       r14, r8
0x142883ec3:  488bda               mov       rbx, rdx
0x142883ec6:  488bf1               mov       rsi, rcx
0x142883ec9:  b920000000           mov       ecx, 0x20
0x142883ece:  65488b042558000000   mov       rax, qword ptr gs:[0x58]
0x142883ed7:  4c8b08               mov       r9, qword ptr [rax]
0x142883eda:  488d3daf8e1f06       lea       rdi, [rip + 0x61f8eaf]
0x142883ee1:  428b0409             mov       eax, dword ptr [rcx + r9]
0x142883ee5:  3905998e1f06         cmp       dword ptr [rip + 0x61f8e99], eax
0x142883eeb:  0f8ff8040000         jg        0x1428843e9
0x142883ef1:  4d85f6               test      r14, r14
0x142883ef4:  490f45fe             cmovne    rdi, r14
0x142883ef8:  4c8b3559b95605       mov       r14, qword ptr [rip + 0x556b959]
0x142883eff:  4c8b054ab95605       mov       r8, qword ptr [rip + 0x556b94a]
0x142883f06:  8b0d40b95605         mov       ecx, dword ptr [rip + 0x556b940]
0x142883f0c:  0fb71535b95605       movzx     edx, word ptr [rip + 0x556b935]
0x142883f13:  440fb73d2fb95605     movzx     r15d, word ptr [rip + 0x556b92f]
0x142883f1b:  6644397b02           cmp       word ptr [rbx + 2], r15w
0x142883f20:  7513                 jne       0x142883f35
0x142883f22:  0fb703               movzx     eax, word ptr [rbx]
0x142883f25:  663bc2               cmp       ax, dx
0x142883f28:  750b                 jne       0x142883f35
0x142883f2a:  6683f802             cmp       ax, 2
0x142883f2e:  7559                 jne       0x142883f89
0x142883f30:  394b04               cmp       dword ptr [rbx + 4], ecx
0x142883f33:  7466                 je        0x142883f9b
0x142883f35:  0f100b               movups    xmm1, xmmword ptr [rbx]
0x142883f38:  0f294c2430           movaps    xmmword ptr [rsp + 0x30], xmm1
0x142883f3d:  0f104310             movups    xmm0, xmmword ptr [rbx + 0x10]
0x142883f41:  0f29442440           movaps    xmmword ptr [rsp + 0x40], xmm0
0x142883f46:  66490f7ec9           movq      r9, xmm1
0x142883f4b:  498bc1               mov       rax, r9
0x142883f4e:  48c1e810             shr       rax, 0x10
0x142883f52:  4c8b542440           mov       r10, qword ptr [rsp + 0x40]
0x142883f57:  4c8b5c2438           mov       r11, qword ptr [rsp + 0x38]
0x142883f5c:  66413bc7             cmp       ax, r15w
0x142883f60:  0f858d030000         jne       0x1428842f3
0x142883f66:  66443bca             cmp       r9w, dx
0x142883f6a:  0f8583030000         jne       0x1428842f3
0x142883f70:  664183f902           cmp       r9w, 2
0x142883f75:  0f8563030000         jne       0x1428842de
0x142883f7b:  498bc1               mov       rax, r9
0x142883f7e:  48c1e820             shr       rax, 0x20
0x142883f82:  3bc1                 cmp       eax, ecx
0x142883f84:  e964030000           jmp       0x1428842ed
0x142883f89:  6683f817             cmp       ax, 0x17
0x142883f8d:  75a6                 jne       0x142883f35
0x142883f8f:  4c394308             cmp       qword ptr [rbx + 8], r8
0x142883f93:  75a0                 jne       0x142883f35
0x142883f95:  4c397310             cmp       qword ptr [rbx + 0x10], r14
0x142883f99:  759a                 jne       0x142883f35
0x142883f9b:  4532e4               xor       r12b, r12b
0x142883f9e:  33db                 xor       ebx, ebx
0x142883fa0:  440fb7f3             movzx     r14d, bx
0x142883fa4:  663b9e12010000       cmp       bx, word ptr [rsi + 0x112]
0x142883fab:  0f8325030000         jae       0x1428842d6
0x142883fb1:  4c8d2dc82e06fe       lea       r13, [rip - 0x1f9d138]
0x142883fb8:  0f1f840000000000     nop       dword ptr [rax + rax]
0x142883fc0:  410fb7c6             movzx     eax, r14w
0x142883fc4:  4c69f8d8160000       imul      r15, rax, 0x16d8
0x142883fcb:  488b8650030000       mov       rax, qword ptr [rsi + 0x350]
0x142883fd2:  410fb60c07           movzx     ecx, byte ptr [r15 + rax]
0x142883fd7:  90                   nop       
0x142883fd8:  84c9                 test      cl, cl
0x142883fda:  0f84e4020000         je        0x1428842c4
0x142883fe0:  b804000000           mov       eax, 4
0x142883fe5:  488d4c2454           lea       rcx, [rsp + 0x54]
0x142883fea:  660f1f440000         nop       word ptr [rax + rax]
0x142883ff0:  c60100               mov       byte ptr [rcx], 0
0x142883ff3:  488d4908             lea       rcx, [rcx + 8]
0x142883ff7:  4883e801             sub       rax, 1
0x142883ffb:  75f3                 jne       0x142883ff0
0x142883ffd:  88442474             mov       byte ptr [rsp + 0x74], al
0x142884001:  8844247c             mov       byte ptr [rsp + 0x7c], al
0x142884005:  884584               mov       byte ptr [rbp - 0x7c], al
0x142884008:  88458c               mov       byte ptr [rbp - 0x74], al
0x14288400b:  4c896c2420           mov       qword ptr [rsp + 0x20], r13
0x142884010:  4c8d0d397126ff       lea       r9, [rip - 0xd98ec7]
0x142884017:  8d5020               lea       edx, [rax + 0x20]
0x14288401a:  448d4004             lea       r8d, [rax + 4]
0x14288401e:  488d4d90             lea       rcx, [rbp - 0x70]
0x142884022:  e8b1d92903           call      0x145b219d8
0x142884027:  0f57c0               xorps     xmm0, xmm0
0x14288402a:  0f114510             movups    xmmword ptr [rbp + 0x10], xmm0
0x14288402e:  0f114520             movups    xmmword ptr [rbp + 0x20], xmm0
0x142884032:  0f114530             movups    xmmword ptr [rbp + 0x30], xmm0
0x142884036:  0f114540             movups    xmmword ptr [rbp + 0x40], xmm0
0x14288403a:  0f57c9               xorps     xmm1, xmm1
0x14288403d:  33c0                 xor       eax, eax
0x14288403f:  0f118d00010000       movups    xmmword ptr [rbp + 0x100], xmm1
0x142884046:  0f118d10010000       movups    xmmword ptr [rbp + 0x110], xmm1
0x14288404d:  0f118d20010000       movups    xmmword ptr [rbp + 0x120], xmm1
0x142884054:  0f118d30010000       movups    xmmword ptr [rbp + 0x130], xmm1
0x14288405b:  0f118d40010000       movups    xmmword ptr [rbp + 0x140], xmm1
0x142884062:  48898550010000       mov       qword ptr [rbp + 0x150], rax
0x142884069:  48899d58010000       mov       qword ptr [rbp + 0x158], rbx
0x142884070:  48899d60010000       mov       qword ptr [rbp + 0x160], rbx
0x142884077:  48899d68010000       mov       qword ptr [rbp + 0x168], rbx
0x14288407e:  48899d70010000       mov       qword ptr [rbp + 0x170], rbx
0x142884085:  48899d78010000       mov       qword ptr [rbp + 0x178], rbx
0x14288408c:  48899d80010000       mov       qword ptr [rbp + 0x180], rbx
0x142884093:  48899d88010000       mov       qword ptr [rbp + 0x188], rbx
0x14288409a:  48899d90010000       mov       qword ptr [rbp + 0x190], rbx
0x1428840a1:  48899d98010000       mov       qword ptr [rbp + 0x198], rbx
0x1428840a8:  48899da0010000       mov       qword ptr [rbp + 0x1a0], rbx
0x1428840af:  488b8e50030000       mov       rcx, qword ptr [rsi + 0x350]
0x1428840b6:  4881c188010000       add       rcx, 0x188
0x1428840bd:  4903cf               add       rcx, r15
0x1428840c0:  488d542450           lea       rdx, [rsp + 0x50]
0x1428840c5:  e8a6090300           call      0x1428b4a70
0x1428840ca:  4584e4               test      r12b, r12b
0x1428840cd:  0f8595000000         jne       0x142884168
0x1428840d3:  488bc7               mov       rax, rdi
0x1428840d6:  488d4c2450           lea       rcx, [rsp + 0x50]
0x1428840db:  ba04000000           mov       edx, 4
0x1428840e0:  0f1001               movups    xmm0, xmmword ptr [rcx]
0x1428840e3:  0f1100               movups    xmmword ptr [rax], xmm0
0x1428840e6:  0f104910             movups    xmm1, xmmword ptr [rcx + 0x10]
0x1428840ea:  0f114810             movups    xmmword ptr [rax + 0x10], xmm1
0x1428840ee:  0f104120             movups    xmm0, xmmword ptr [rcx + 0x20]
0x1428840f2:  0f114020             movups    xmmword ptr [rax + 0x20], xmm0
0x1428840f6:  0f104930             movups    xmm1, xmmword ptr [rcx + 0x30]
0x1428840fa:  0f114830             movups    xmmword ptr [rax + 0x30], xmm1
0x1428840fe:  0f104140             movups    xmm0, xmmword ptr [rcx + 0x40]
0x142884102:  0f114040             movups    xmmword ptr [rax + 0x40], xmm0
0x142884106:  0f104950             movups    xmm1, xmmword ptr [rcx + 0x50]
0x14288410a:  0f114850             movups    xmmword ptr [rax + 0x50], xmm1
0x14288410e:  0f104160             movups    xmm0, xmmword ptr [rcx + 0x60]
0x142884112:  0f114060             movups    xmmword ptr [rax + 0x60], xmm0
0x142884116:  488d8080000000       lea       rax, [rax + 0x80]
0x14288411d:  0f104970             movups    xmm1, xmmword ptr [rcx + 0x70]
0x142884121:  0f1148f0             movups    xmmword ptr [rax - 0x10], xmm1
0x142884125:  488d8980000000       lea       rcx, [rcx + 0x80]
0x14288412c:  4883ea01             sub       rdx, 1
0x142884130:  75ae                 jne       0x1428840e0
0x142884132:  0f1001               movups    xmm0, xmmword ptr [rcx]
0x142884135:  0f1100               movups    xmmword ptr [rax], xmm0
0x142884138:  0f104910             movups    xmm1, xmmword ptr [rcx + 0x10]
0x14288413c:  0f114810             movups    xmmword ptr [rax + 0x10], xmm1
0x142884140:  0f104120             movups    xmm0, xmmword ptr [rcx + 0x20]
0x142884144:  0f114020             movups    xmmword ptr [rax + 0x20], xmm0
0x142884148:  0f104930             movups    xmm1, xmmword ptr [rcx + 0x30]
0x14288414c:  0f114830             movups    xmmword ptr [rax + 0x30], xmm1
0x142884150:  0f104140             movups    xmm0, xmmword ptr [rcx + 0x40]
0x142884154:  0f114040             movups    xmmword ptr [rax + 0x40], xmm0
0x142884158:  0f104950             movups    xmm1, xmmword ptr [rcx + 0x50]
0x14288415c:  0f114850             movups    xmmword ptr [rax + 0x50], xmm1
0x142884160:  41b401               mov       r12b, 1
0x142884163:  e946010000           jmp       0x1428842ae
0x142884168:  8b85b8000000         mov       eax, dword ptr [rbp + 0xb8]
0x14288416e:  018768010000         add       dword ptr [rdi + 0x168], eax
0x142884174:  f20f1085c8000000     movsd     xmm0, qword ptr [rbp + 0xc8]
0x14288417c:  f20f588778010000     addsd     xmm0, qword ptr [rdi + 0x178]
0x142884184:  f20f118778010000     movsd     qword ptr [rdi + 0x178], xmm0
0x14288418c:  8b85bc000000         mov       eax, dword ptr [rbp + 0xbc]
0x142884192:  01876c010000         add       dword ptr [rdi + 0x16c], eax
0x142884198:  f20f1085d0000000     movsd     xmm0, qword ptr [rbp + 0xd0]
0x1428841a0:  f20f588780010000     addsd     xmm0, qword ptr [rdi + 0x180]
0x1428841a8:  f20f118780010000     movsd     qword ptr [rdi + 0x180], xmm0
0x1428841b0:  8b85c0000000         mov       eax, dword ptr [rbp + 0xc0]
0x1428841b6:  018770010000         add       dword ptr [rdi + 0x170], eax
0x1428841bc:  f20f1085d8000000     movsd     xmm0, qword ptr [rbp + 0xd8]
0x1428841c4:  f20f588788010000     addsd     xmm0, qword ptr [rdi + 0x188]
0x1428841cc:  f20f118788010000     movsd     qword ptr [rdi + 0x188], xmm0
0x1428841d4:  8b85c4000000         mov       eax, dword ptr [rbp + 0xc4]
0x1428841da:  018774010000         add       dword ptr [rdi + 0x174], eax
0x1428841e0:  f20f1085e0000000     movsd     xmm0, qword ptr [rbp + 0xe0]
0x1428841e8:  f20f588790010000     addsd     xmm0, qword ptr [rdi + 0x190]
0x1428841f0:  f20f118790010000     movsd     qword ptr [rdi + 0x190], xmm0
0x1428841f8:  488b4510             mov       rax, qword ptr [rbp + 0x10]
0x1428841fc:  480187c0000000       add       qword ptr [rdi + 0xc0], rax
0x142884203:  488b4550             mov       rax, qword ptr [rbp + 0x50]
0x142884207:  48018700010000       add       qword ptr [rdi + 0x100], rax
0x14288420e:  488b4518             mov       rax, qword ptr [rbp + 0x18]
0x142884212:  480187c8000000       add       qword ptr [rdi + 0xc8], rax
0x142884219:  488b4558             mov       rax, qword ptr [rbp + 0x58]
0x14288421d:  48018708010000       add       qword ptr [rdi + 0x108], rax
0x142884224:  488b4520             mov       rax, qword ptr [rbp + 0x20]
0x142884228:  480187d0000000       add       qword ptr [rdi + 0xd0], rax
0x14288422f:  488b4560             mov       rax, qword ptr [rbp + 0x60]
0x142884233:  48018710010000       add       qword ptr [rdi + 0x110], rax
0x14288423a:  488b4528             mov       rax, qword ptr [rbp + 0x28]
0x14288423e:  480187d8000000       add       qword ptr [rdi + 0xd8], rax
0x142884245:  488b4568             mov       rax, qword ptr [rbp + 0x68]
0x142884249:  48018718010000       add       qword ptr [rdi + 0x118], rax
0x142884250:  488b4530             mov       rax, qword ptr [rbp + 0x30]
0x142884254:  480187e0000000       add       qword ptr [rdi + 0xe0], rax
0x14288425b:  488b4570             mov       rax, qword ptr [rbp + 0x70]
0x14288425f:  48018720010000       add       qword ptr [rdi + 0x120], rax
0x142884266:  488b4538             mov       rax, qword ptr [rbp + 0x38]
0x14288426a:  480187e8000000       add       qword ptr [rdi + 0xe8], rax
0x142884271:  488b4578             mov       rax, qword ptr [rbp + 0x78]
0x142884275:  48018728010000       add       qword ptr [rdi + 0x128], rax
0x14288427c:  488b4540             mov       rax, qword ptr [rbp + 0x40]
0x142884280:  480187f0000000       add       qword ptr [rdi + 0xf0], rax
0x142884287:  488b8580000000       mov       rax, qword ptr [rbp + 0x80]
0x14288428e:  48018730010000       add       qword ptr [rdi + 0x130], rax
0x142884295:  488b4548             mov       rax, qword ptr [rbp + 0x48]
0x142884299:  480187f8000000       add       qword ptr [rdi + 0xf8], rax
0x1428842a0:  488b8588000000       mov       rax, qword ptr [rbp + 0x88]
0x1428842a7:  48018738010000       add       qword ptr [rdi + 0x138], rax
0x1428842ae:  4d8bcd               mov       r9, r13
0x1428842b1:  ba20000000           mov       edx, 0x20
0x1428842b6:  448d42e4             lea       r8d, [rdx - 0x1c]
0x1428842ba:  488d4d90             lea       rcx, [rbp - 0x70]
0x1428842be:  e8edd32903           call      0x145b216b0
0x1428842c3:  90                   nop       
0x1428842c4:  6641ffc6             inc       r14w
0x1428842c8:  66443bb612010000     cmp       r14w, word ptr [rsi + 0x112]
0x1428842d0:  0f82eafcffff         jb        0x142883fc0
0x1428842d6:  488bc7               mov       rax, rdi
0x1428842d9:  e9e1000000           jmp       0x1428843bf
0x1428842de:  664183f917           cmp       r9w, 0x17
0x1428842e3:  750e                 jne       0x1428842f3
0x1428842e5:  4d3bd8               cmp       r11, r8
0x1428842e8:  7509                 jne       0x1428842f3
0x1428842ea:  4d3bd6               cmp       r10, r14
0x1428842ed:  0f84ca000000         je        0x1428843bd
0x1428842f3:  33db                 xor       ebx, ebx
0x1428842f5:  448d43ff             lea       r8d, [rbx - 1]
0x1428842f9:  663b9e12010000       cmp       bx, word ptr [rsi + 0x112]
0x142884300:  0f83b7000000         jae       0x1428843bd
0x142884306:  4863c3               movsxd    rax, ebx
0x142884309:  4869c8d8160000       imul      rcx, rax, 0x16d8
0x142884310:  488b9650030000       mov       rdx, qword ptr [rsi + 0x350]
0x142884317:  0fb7442432           movzx     eax, word ptr [rsp + 0x32]
0x14288431c:  6639440a06           cmp       word ptr [rdx + rcx + 6], ax
0x142884321:  7551                 jne       0x142884374
0x142884323:  0fb7440a04           movzx     eax, word ptr [rdx + rcx + 4]
0x142884328:  66413bc1             cmp       ax, r9w
0x14288432c:  7546                 jne       0x142884374
0x14288432e:  6683f802             cmp       ax, 2
0x142884332:  750c                 jne       0x142884340
0x142884334:  8b442434             mov       eax, dword ptr [rsp + 0x34]
0x142884338:  39440a08             cmp       dword ptr [rdx + rcx + 8], eax
0x14288433c:  7416                 je        0x142884354
0x14288433e:  eb34                 jmp       0x142884374
0x142884340:  6683f817             cmp       ax, 0x17
0x142884344:  752e                 jne       0x142884374
0x142884346:  4c395c0a0c           cmp       qword ptr [rdx + rcx + 0xc], r11
0x14288434b:  7527                 jne       0x142884374
0x14288434d:  4c39540a14           cmp       qword ptr [rdx + rcx + 0x14], r10
0x142884352:  7520                 jne       0x142884374
0x142884354:  0fb6040a             movzx     eax, byte ptr [rdx + rcx]
0x142884358:  90                   nop       
0x142884359:  84c0                 test      al, al
0x14288435b:  7534                 jne       0x142884391
0x14288435d:  4183f8ff             cmp       r8d, -1
0x142884361:  440f44c3             cmove     r8d, ebx
0x142884365:  4c8b542440           mov       r10, qword ptr [rsp + 0x40]
0x14288436a:  4c8b5c2438           mov       r11, qword ptr [rsp + 0x38]
0x14288436f:  4c8b4c2430           mov       r9, qword ptr [rsp + 0x30]
0x142884374:  ffc3                 inc       ebx
0x142884376:  0fb78612010000       movzx     eax, word ptr [rsi + 0x112]
0x14288437d:  3bd8                 cmp       ebx, eax
0x14288437f:  7285                 jb        0x142884306
0x142884381:  4183f8ff             cmp       r8d, -1
0x142884385:  7436                 je        0x1428843bd
0x142884387:  4963c0               movsxd    rax, r8d
0x14288438a:  4869c8d8160000       imul      rcx, rax, 0x16d8
0x142884391:  48038e50030000       add       rcx, qword ptr [rsi + 0x350]
0x142884398:  4885c9               test      rcx, rcx
0x14288439b:  7420                 je        0x1428843bd
0x14288439d:  0fb68608010000       movzx     eax, byte ptr [rsi + 0x108]
0x1428843a4:  90                   nop       
0x1428843a5:  84c0                 test      al, al
0x1428843a7:  7514                 jne       0x1428843bd
0x1428843a9:  4881c188010000       add       rcx, 0x188
0x1428843b0:  488bd7               mov       rdx, rdi
0x1428843b3:  e8b8060300           call      0x1428b4a70
0x1428843b8:  488bc7               mov       rax, rdi
0x1428843bb:  eb02                 jmp       0x1428843bf
0x1428843bd:  33c0                 xor       eax, eax
0x1428843bf:  488b8db0010000       mov       rcx, qword ptr [rbp + 0x1b0]
0x1428843c6:  4833cc               xor       rcx, rsp
0x1428843c9:  e812d22903           call      0x145b215e0
0x1428843ce:  488b9c2418030000     mov       rbx, qword ptr [rsp + 0x318]
0x1428843d6:  4881c4c0020000       add       rsp, 0x2c0
0x1428843dd:  415f                 pop       r15
0x1428843df:  415e                 pop       r14
0x1428843e1:  415d                 pop       r13
0x1428843e3:  415c                 pop       r12
0x1428843e5:  5f                   pop       rdi
0x1428843e6:  5e                   pop       rsi
0x1428843e7:  5d                   pop       rbp
0x1428843e8:  c3                   ret       
0x1428843e9:  488d0d94891f06       lea       rcx, [rip + 0x61f8994]
0x1428843f0:  e87bce77fd           call      0x140001270
0x1428843f5:  833d88891f06ff       cmp       dword ptr [rip + 0x61f8988], -1
0x1428843fc:  0f85effaffff         jne       0x142883ef1
0x142884402:  488bcf               mov       rcx, rdi
0x142884405:  e826000000           call      0x142884430
0x14288440a:  488d0daf048703       lea       rcx, [rip + 0x38704af]
0x142884411:  e8aad52903           call      0x145b219c0
0x142884416:  90                   nop       
0x142884417:  488d0d66891f06       lea       rcx, [rip + 0x61f8966]
0x14288441e:  e82dcf77fd           call      0x140001350
0x142884423:  e9c9faffff           jmp       0x142883ef1
0x142884428:  cc                   int3      
0x142884429:  cc                   int3      
0x14288442a:  cc                   int3      
0x14288442b:  cc                   int3      
0x14288442c:  cc                   int3      
0x14288442d:  cc                   int3      
0x14288442e:  cc                   int3      
0x14288442f:  cc                   int3      
