; function_of: str.getaddrinfo neither ipv4 nor ipv6, str.getaddrinfo no info, str.getaddrinfo returned %d
; xref site 0x1428a59c1 -> str.getaddrinfo returned %d @ 0x146f3b7e8
; xref site 0x1428a5a1c -> str.getaddrinfo no info @ 0x146f3b768
; xref site 0x1428a5aa1 -> str.getaddrinfo neither ipv4 nor ipv6 @ 0x146f3b7a0
; range 0x1428a58c0 .. 0x1428a5bf0  (816 bytes)

0x0001428a58c0:  4053                  push      rbx
0x0001428a58c2:  56                    push      rsi
0x0001428a58c3:  57                    push      rdi
0x0001428a58c4:  4881ec90000000        sub       rsp, 0x90
0x0001428a58cb:  488bf2                mov       rsi, rdx
0x0001428a58ce:  488bd9                mov       rbx, rcx
0x0001428a58d1:  4885d2                test      rdx, rdx
0x0001428a58d4:  7524                  jne       0x1428a58fa
0x0001428a58d6:  33c0                  xor       eax, eax
0x0001428a58d8:  0f57c0                xorps     xmm0, xmm0
0x0001428a58db:  0f1101                movups    xmmword ptr [rcx], xmm0
0x0001428a58de:  48894110              mov       qword ptr [rcx + 0x10], rax
0x0001428a58e2:  bf02000000            mov       edi, 2
0x0001428a58e7:  894118                mov       dword ptr [rcx + 0x18], eax
0x0001428a58ea:  b001                  mov       al, 1
0x0001428a58ec:  668939                mov       word ptr [rcx], di
0x0001428a58ef:  4881c490000000        add       rsp, 0x90
0x0001428a58f6:  5f                    pop       rdi
0x0001428a58f7:  5e                    pop       rsi
0x0001428a58f8:  5b                    pop       rbx
0x0001428a58f9:  c3                    ret       
0x0001428a58fa:  4889ac24b0000000      mov       qword ptr [rsp + 0xb0], rbp
0x0001428a5902:  4c89b424c0000000      mov       qword ptr [rsp + 0xc0], r14
0x0001428a590a:  e8b1160000            call      0x1428a6fc0
0x0001428a590f:  0fb76b02              movzx     ebp, word ptr [rbx + 2]
0x0001428a5913:  4c8d8c24b8000000      lea       r9, [rsp + 0xb8]
0x0001428a591b:  0f57c0                xorps     xmm0, xmm0
0x0001428a591e:  48c7442460000c0000    mov       qword ptr [rsp + 0x60], 0xc00
0x0001428a5927:  0f57c9                xorps     xmm1, xmm1
0x0001428a592a:  4c8d442460            lea       r8, [rsp + 0x60]
0x0001428a592f:  4533f6                xor       r14d, r14d
0x0001428a5932:  bf02000000            mov       edi, 2
0x0001428a5937:  33d2                  xor       edx, edx
0x0001428a5939:  4c89b424b8000000      mov       qword ptr [rsp + 0xb8], r14
0x0001428a5941:  488bce                mov       rcx, rsi
0x0001428a5944:  4489b4248c000000      mov       dword ptr [rsp + 0x8c], r14d
0x0001428a594c:  f30f7f44246c          movdqu    xmmword ptr [rsp + 0x6c], xmm0
0x0001428a5952:  897c2468              mov       dword ptr [rsp + 0x68], edi
0x0001428a5956:  f30f7f4c247c          movdqu    xmmword ptr [rsp + 0x7c], xmm1
0x0001428a595c:  ff15de9e8903          call      qword ptr [rip + 0x3899ede]
0x0001428a5962:  488b8c24b8000000      mov       rcx, qword ptr [rsp + 0xb8]
0x0001428a596a:  8bf0                  mov       esi, eax
0x0001428a596c:  85c0                  test      eax, eax
0x0001428a596e:  7466                  je        0x1428a59d6
0x0001428a5970:  4885c9                test      rcx, rcx
0x0001428a5973:  7406                  je        0x1428a597b
0x0001428a5975:  ff15cd9e8903          call      qword ptr [rip + 0x3899ecd]
0x0001428a597b:  488b0daea64b05        mov       rcx, qword ptr [rip + 0x54ba6ae]
0x0001428a5982:  80f906                cmp       cl, 6
0x0001428a5985:  0f82ac000000          jb        0x1428a5a37
0x0001428a598b:  48c1e908              shr       rcx, 8
0x0001428a598f:  80f903                cmp       cl, 3
0x0001428a5992:  0f829f000000          jb        0x1428a5a37
0x0001428a5998:  488d05d33c8e04        lea       rax, [rip + 0x48e3cd3]
0x0001428a599f:  448bc6                mov       r8d, esi
0x0001428a59a2:  48898424c8000000      mov       qword ptr [rsp + 0xc8], rax
0x0001428a59aa:  488d4c2440            lea       rcx, [rsp + 0x40]
0x0001428a59af:  488b9424c8000000      mov       rdx, qword ptr [rsp + 0xc8]
0x0001428a59b7:  0f100572a64b05        movups    xmm0, xmmword ptr [rip + 0x54ba672]
0x0001428a59be:  488d15235e6904        lea       rdx, [rip + 0x4695e23]
0x0001428a59c5:  0f29442440            movaps    xmmword ptr [rsp + 0x40], xmm0
0x0001428a59ca:  e8c19e0b02            call      0x14495f890
0x0001428a59cf:  32c0                  xor       al, al
0x0001428a59d1:  e98b010000            jmp       0x1428a5b61
0x0001428a59d6:  4885c9                test      rcx, rcx
0x0001428a59d9:  7563                  jne       0x1428a5a3e
0x0001428a59db:  488b054ea64b05        mov       rax, qword ptr [rip + 0x54ba64e]
0x0001428a59e2:  3c06                  cmp       al, 6
0x0001428a59e4:  7251                  jb        0x1428a5a37
0x0001428a59e6:  48c1e808              shr       rax, 8
0x0001428a59ea:  3c03                  cmp       al, 3
0x0001428a59ec:  7249                  jb        0x1428a5a37
0x0001428a59ee:  488d05e69d8e04        lea       rax, [rip + 0x48e9de6]
0x0001428a59f5:  4c89742430            mov       qword ptr [rsp + 0x30], r14
0x0001428a59fa:  48898424c8000000      mov       qword ptr [rsp + 0xc8], rax
0x0001428a5a02:  488d4c2440            lea       rcx, [rsp + 0x40]
0x0001428a5a07:  488b9424c8000000      mov       rdx, qword ptr [rsp + 0xc8]
0x0001428a5a0f:  4533c9                xor       r9d, r9d
0x0001428a5a12:  0f100517a64b05        movups    xmm0, xmmword ptr [rip + 0x54ba617]
0x0001428a5a19:  488d15485d6904        lea       rdx, [rip + 0x4695d48]
0x0001428a5a20:  4c89742428            mov       qword ptr [rsp + 0x28], r14
0x0001428a5a25:  4533c0                xor       r8d, r8d
0x0001428a5a28:  4c89742420            mov       qword ptr [rsp + 0x20], r14
0x0001428a5a2d:  0f29442440            movaps    xmmword ptr [rsp + 0x40], xmm0
0x0001428a5a32:  e8e9a30b02            call      0x14495fe20
0x0001428a5a37:  32c0                  xor       al, al
0x0001428a5a39:  e923010000            jmp       0x1428a5b61
0x0001428a5a3e:  8b5104                mov       edx, dword ptr [rcx + 4]
0x0001428a5a41:  3bd7                  cmp       edx, edi
0x0001428a5a43:  7512                  jne       0x1428a5a57
0x0001428a5a45:  66893b                mov       word ptr [rbx], di
0x0001428a5a48:  488b4120              mov       rax, qword ptr [rcx + 0x20]
0x0001428a5a4c:  0f1000                movups    xmm0, xmmword ptr [rax]
0x0001428a5a4f:  0f1103                movups    xmmword ptr [rbx], xmm0
0x0001428a5a52:  e98f000000            jmp       0x1428a5ae6
0x0001428a5a57:  488b05d2a54b05        mov       rax, qword ptr [rip + 0x54ba5d2]
0x0001428a5a5e:  84c0                  test      al, al
0x0001428a5a60:  7462                  je        0x1428a5ac4
0x0001428a5a62:  83fa17                cmp       edx, 0x17
0x0001428a5a65:  745d                  je        0x1428a5ac4
0x0001428a5a67:  3c06                  cmp       al, 6
0x0001428a5a69:  7259                  jb        0x1428a5ac4
0x0001428a5a6b:  48c1e808              shr       rax, 8
0x0001428a5a6f:  3c03                  cmp       al, 3
0x0001428a5a71:  7251                  jb        0x1428a5ac4
0x0001428a5a73:  488d05bfaf8f04        lea       rax, [rip + 0x48fafbf]
0x0001428a5a7a:  4c89742430            mov       qword ptr [rsp + 0x30], r14
0x0001428a5a7f:  48898424c8000000      mov       qword ptr [rsp + 0xc8], rax
0x0001428a5a87:  488d4c2450            lea       rcx, [rsp + 0x50]
0x0001428a5a8c:  488b9424c8000000      mov       rdx, qword ptr [rsp + 0xc8]
0x0001428a5a94:  4533c9                xor       r9d, r9d
0x0001428a5a97:  0f100592a54b05        movups    xmm0, xmmword ptr [rip + 0x54ba592]
0x0001428a5a9e:  488d15fb5c6904        lea       rdx, [rip + 0x4695cfb]
0x0001428a5aa5:  4c89742428            mov       qword ptr [rsp + 0x28], r14
0x0001428a5aaa:  4533c0                xor       r8d, r8d
0x0001428a5aad:  4c89742420            mov       qword ptr [rsp + 0x20], r14
0x0001428a5ab2:  0f29442450            movaps    xmmword ptr [rsp + 0x50], xmm0
0x0001428a5ab7:  e864a30b02            call      0x14495fe20
0x0001428a5abc:  488b8c24b8000000      mov       rcx, qword ptr [rsp + 0xb8]
0x0001428a5ac4:  b817000000            mov       eax, 0x17
0x0001428a5ac9:  668903                mov       word ptr [rbx], ax
0x0001428a5acc:  488b4120              mov       rax, qword ptr [rcx + 0x20]
0x0001428a5ad0:  0f1000                movups    xmm0, xmmword ptr [rax]
0x0001428a5ad3:  0f1103                movups    xmmword ptr [rbx], xmm0
0x0001428a5ad6:  f20f104810            movsd     xmm1, qword ptr [rax + 0x10]
0x0001428a5adb:  f20f114b10            movsd     qword ptr [rbx + 0x10], xmm1
0x0001428a5ae0:  8b4018                mov       eax, dword ptr [rax + 0x18]
0x0001428a5ae3:  894318                mov       dword ptr [rbx + 0x18], eax
0x0001428a5ae6:  488b1543a54b05        mov       rdx, qword ptr [rip + 0x54ba543]
0x0001428a5aed:  84d2                  test      dl, dl
0x0001428a5aef:  745a                  je        0x1428a5b4b
0x0001428a5af1:  0fb703                movzx     eax, word ptr [rbx]
0x0001428a5af4:  394104                cmp       dword ptr [rcx + 4], eax
0x0001428a5af7:  7452                  je        0x1428a5b4b
0x0001428a5af9:  80fa06                cmp       dl, 6
0x0001428a5afc:  724d                  jb        0x1428a5b4b
0x0001428a5afe:  48c1ea08              shr       rdx, 8
0x0001428a5b02:  80fa03                cmp       dl, 3
0x0001428a5b05:  7244                  jb        0x1428a5b4b
0x0001428a5b07:  488d05534c9004        lea       rax, [rip + 0x4904c53]
0x0001428a5b0e:  48898424c8000000      mov       qword ptr [rsp + 0xc8], rax
0x0001428a5b16:  488b9424c8000000      mov       rdx, qword ptr [rsp + 0xc8]
0x0001428a5b1e:  0f10050ba54b05        movups    xmm0, xmmword ptr [rip + 0x54ba50b]
0x0001428a5b25:  448b4104              mov       r8d, dword ptr [rcx + 4]
0x0001428a5b29:  488d15f05c6904        lea       rdx, [rip + 0x4695cf0]
0x0001428a5b30:  440fb70b              movzx     r9d, word ptr [rbx]
0x0001428a5b34:  488d4c2440            lea       rcx, [rsp + 0x40]
0x0001428a5b39:  0f29442440            movaps    xmmword ptr [rsp + 0x40], xmm0
0x0001428a5b3e:  e84d9d0b02            call      0x14495f890
0x0001428a5b43:  488b8c24b8000000      mov       rcx, qword ptr [rsp + 0xb8]
0x0001428a5b4b:  4885c9                test      rcx, rcx
0x0001428a5b4e:  7406                  je        0x1428a5b56
0x0001428a5b50:  ff15f29c8903          call      qword ptr [rip + 0x3899cf2]
0x0001428a5b56:  e8c5140000            call      0x1428a7020
0x0001428a5b5b:  b001                  mov       al, 1
0x0001428a5b5d:  66896b02              mov       word ptr [rbx + 2], bp
0x0001428a5b61:  488bac24b0000000      mov       rbp, qword ptr [rsp + 0xb0]
0x0001428a5b69:  4c8bb424c0000000      mov       r14, qword ptr [rsp + 0xc0]
0x0001428a5b71:  4881c490000000        add       rsp, 0x90
0x0001428a5b78:  5f                    pop       rdi
0x0001428a5b79:  5e                    pop       rsi
0x0001428a5b7a:  5b                    pop       rbx
0x0001428a5b7b:  c3                    ret       
0x0001428a5b7c:  cc                    int3      
0x0001428a5b7d:  cc                    int3      
0x0001428a5b7e:  cc                    int3      
0x0001428a5b7f:  cc                    int3      
0x0001428a5b80:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x0001428a5b85:  57                    push      rdi
0x0001428a5b86:  4883ec20              sub       rsp, 0x20
0x0001428a5b8a:  8bfa                  mov       edi, edx
0x0001428a5b8c:  488bd9                mov       rbx, rcx
0x0001428a5b8f:  488d0532e13f04        lea       rax, [rip + 0x43fe132]
0x0001428a5b96:  488901                mov       qword ptr [rcx], rax
0x0001428a5b99:  80792800              cmp       byte ptr [rcx + 0x28], 0
0x0001428a5b9d:  7426                  je        0x1428a5bc5
0x0001428a5b9f:  8b4114                mov       eax, dword ptr [rcx + 0x14]
0x0001428a5ba2:  3d00080000            cmp       eax, 0x800
0x0001428a5ba7:  7606                  jbe       0x1428a5baf
0x0001428a5ba9:  488b4920              mov       rcx, qword ptr [rcx + 0x20]
0x0001428a5bad:  eb11                  jmp       0x1428a5bc0
0x0001428a5baf:  85c0                  test      eax, eax
0x0001428a5bb1:  7412                  je        0x1428a5bc5
0x0001428a5bb3:  488b4920              mov       rcx, qword ptr [rcx + 0x20]
0x0001428a5bb7:  488d4329              lea       rax, [rbx + 0x29]
0x0001428a5bbb:  483bc8                cmp       rcx, rax
0x0001428a5bbe:  7405                  je        0x1428a5bc5
0x0001428a5bc0:  e8ebd40902            call      0x1449430b0
0x0001428a5bc5:  488d05ec413e04        lea       rax, [rip + 0x43e41ec]
0x0001428a5bcc:  488903                mov       qword ptr [rbx], rax
0x0001428a5bcf:  40f6c701              test      dil, 1
0x0001428a5bd3:  7409                  je        0x1428a5bde
0x0001428a5bd5:  488bcb                mov       rcx, rbx
0x0001428a5bd8:  e8d3d40902            call      0x1449430b0
0x0001428a5bdd:  90                    nop       
0x0001428a5bde:  488bc3                mov       rax, rbx
0x0001428a5be1:  488b5c2430            mov       rbx, qword ptr [rsp + 0x30]
0x0001428a5be6:  4883c420              add       rsp, 0x20
0x0001428a5bea:  5f                    pop       rdi
0x0001428a5beb:  c3                    ret       
0x0001428a5bec:  cc                    int3      
0x0001428a5bed:  cc                    int3      
0x0001428a5bee:  cc                    int3      
0x0001428a5bef:  cc                    int3      
