; Ipv4Tlv vtable slot 0 rva 0x7c9520
0x1407c9520:  4053                 push      rbx
0x1407c9522:  4883ec20             sub       rsp, 0x20
0x1407c9526:  488bd9               mov       rbx, rcx
0x1407c9529:  f6c201               test      dl, 1
0x1407c952c:  7406                 je        0x1407c9534
0x1407c952e:  e87d9b1704           call      0x1449430b0
0x1407c9533:  90                   nop       
0x1407c9534:  488bc3               mov       rax, rbx
0x1407c9537:  4883c420             add       rsp, 0x20
0x1407c953b:  5b                   pop       rbx
0x1407c953c:  c3                   ret       
0x1407c953d:  cc                   int3      
0x1407c953e:  cc                   int3      
0x1407c953f:  cc                   int3      
