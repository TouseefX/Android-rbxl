; RakPeer vtable slot 2
; rva 0x7ca2d0
0x1407ca2d0:  32c0                 xor       al, al
0x1407ca2d2:  c3                   ret       
0x1407ca2d3:  cc                   int3      
0x1407ca2d4:  cc                   int3      
0x1407ca2d5:  cc                   int3      
0x1407ca2d6:  cc                   int3      
0x1407ca2d7:  cc                   int3      
0x1407ca2d8:  cc                   int3      
0x1407ca2d9:  cc                   int3      
0x1407ca2da:  cc                   int3      
0x1407ca2db:  cc                   int3      
0x1407ca2dc:  cc                   int3      
0x1407ca2dd:  cc                   int3      
0x1407ca2de:  cc                   int3      
0x1407ca2df:  cc                   int3      
