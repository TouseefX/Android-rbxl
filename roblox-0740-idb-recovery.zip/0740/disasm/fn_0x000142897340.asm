; function_of: str.Client did not opt in. Omitting Rupp header, str.Rupp client-opted-in
; xref site 0x142897a83 -> str.Rupp client-opted-in @ 0x146f3b3a0
; xref site 0x142897b32 -> str.Client did not opt in. Omitting Rupp header @ 0x146f3b400
; range 0x142897340 .. 0x142897f00  (3008 bytes)

0x000142897340:  4c8bdc                mov       r11, rsp
0x000142897343:  55                    push      rbp
0x000142897344:  56                    push      rsi
0x000142897345:  57                    push      rdi
0x000142897346:  4156                  push      r14
0x000142897348:  4157                  push      r15
0x00014289734a:  498d6ba9              lea       rbp, [r11 - 0x57]
0x00014289734e:  4881ec00010000        sub       rsp, 0x100
0x000142897355:  488b0594c34705        mov       rax, qword ptr [rip + 0x547c394]
0x00014289735c:  4833c4                xor       rax, rsp
0x00014289735f:  4889450f              mov       qword ptr [rbp + 0xf], rax
0x000142897363:  4883b9a00e000000      cmp       qword ptr [rcx + 0xea0], 0
0x00014289736b:  458bf9                mov       r15d, r9d
0x00014289736e:  498bf0                mov       rsi, r8
0x000142897371:  4c8bf2                mov       r14, rdx
0x000142897374:  488bf9                mov       rdi, rcx
0x000142897377:  0f84bd010000          je        0x14289753a
0x00014289737d:  0fb64d7f              movzx     ecx, byte ptr [rbp + 0x7f]
0x000142897381:  49895bd0              mov       qword ptr [r11 - 0x30], rbx
0x000142897385:  32db                  xor       bl, bl
0x000142897387:  4d8963c8              mov       qword ptr [r11 - 0x38], r12
0x00014289738b:  83e905                sub       ecx, 5
0x00014289738e:  740c                  je        0x14289739c
0x000142897390:  83e901                sub       ecx, 1
0x000142897393:  7405                  je        0x14289739a
0x000142897395:  83e903                sub       ecx, 3
0x000142897398:  eb02                  jmp       0x14289739c
0x00014289739a:  b301                  mov       bl, 1
0x00014289739c:  0fb74f66              movzx     ecx, word ptr [rdi + 0x66]
0x0001428973a0:  488d4724              lea       rax, [rdi + 0x24]
0x0001428973a4:  4533e4                xor       r12d, r12d
0x0001428973a7:  4889442448            mov       qword ptr [rsp + 0x48], rax
0x0001428973ac:  4c896587              mov       qword ptr [rbp - 0x79], r12
0x0001428973b0:  664489658f            mov       word ptr [rbp - 0x71], r12w
0x0001428973b5:  ff1575848a03          call      qword ptr [rip + 0x38a8475]
0x0001428973bb:  6689442450            mov       word ptr [rsp + 0x50], ax
0x0001428973c0:  4885f6                test      rsi, rsi
0x0001428973c3:  0f84e7000000          je        0x1428974b0
0x0001428973c9:  0f1006                movups    xmm0, xmmword ptr [rsi]
0x0001428973cc:  488d4d9f              lea       rcx, [rbp - 0x61]
0x0001428973d0:  0f104e10              movups    xmm1, xmmword ptr [rsi + 0x10]
0x0001428973d4:  0f11459f              movups    xmmword ptr [rbp - 0x61], xmm0
0x0001428973d8:  0f114daf              movups    xmmword ptr [rbp - 0x51], xmm1
0x0001428973dc:  e8efe10000            call      0x1428a55d0
0x0001428973e1:  0fb70562845505        movzx     eax, word ptr [rip + 0x5558462]
0x0001428973e8:  0f57c0                xorps     xmm0, xmm0
0x0001428973eb:  0fb7559f              movzx     edx, word ptr [rbp - 0x61]
0x0001428973ef:  0f1145bf              movups    xmmword ptr [rbp - 0x41], xmm0
0x0001428973f3:  663945a1              cmp       word ptr [rbp - 0x5f], ax
0x0001428973f7:  751a                  jne       0x142897413
0x0001428973f9:  663b1548845505        cmp       dx, word ptr [rip + 0x5558448]
0x000142897400:  7511                  jne       0x142897413
0x000142897402:  6683fa02              cmp       dx, 2
0x000142897406:  7542                  jne       0x14289744a
0x000142897408:  8b053e845505          mov       eax, dword ptr [rip + 0x555843e]
0x00014289740e:  3945a3                cmp       dword ptr [rbp - 0x5d], eax
0x000142897411:  7457                  je        0x14289746a
0x000142897413:  488d4dbf              lea       rcx, [rbp - 0x41]
0x000142897417:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x00014289741e:  6690                  nop       
0x000142897420:  48ffc0                inc       rax
0x000142897423:  44382401              cmp       byte ptr [rcx + rax], r12b
0x000142897427:  75f7                  jne       0x142897420
0x000142897429:  b940000000            mov       ecx, 0x40
0x00014289742e:  2bc8                  sub       ecx, eax
0x000142897430:  7864                  js        0x142897496
0x000142897432:  4c63c9                movsxd    r9, ecx
0x000142897435:  4c8d45cf              lea       r8, [rbp - 0x31]
0x000142897439:  6683fa02              cmp       dx, 2
0x00014289743d:  7543                  jne       0x142897482
0x00014289743f:  488d55a3              lea       rdx, [rbp - 0x5d]
0x000142897443:  b902000000            mov       ecx, 2
0x000142897448:  eb41                  jmp       0x14289748b
0x00014289744a:  6683fa17              cmp       dx, 0x17
0x00014289744e:  75c3                  jne       0x142897413
0x000142897450:  488b45a7              mov       rax, qword ptr [rbp - 0x59]
0x000142897454:  483b05f5835505        cmp       rax, qword ptr [rip + 0x55583f5]
0x00014289745b:  75b6                  jne       0x142897413
0x00014289745d:  488b45af              mov       rax, qword ptr [rbp - 0x51]
0x000142897461:  483b05f0835505        cmp       rax, qword ptr [rip + 0x55583f0]
0x000142897468:  75a9                  jne       0x142897413
0x00014289746a:  41b840000000          mov       r8d, 0x40
0x000142897470:  488d15f9436a04        lea       rdx, [rip + 0x46a43f9]
0x000142897477:  488d4dcf              lea       rcx, [rbp - 0x31]
0x00014289747b:  e870d92c03            call      0x145b64df0
0x000142897480:  eb18                  jmp       0x14289749a
0x000142897482:  488d55a7              lea       rdx, [rbp - 0x59]
0x000142897486:  b917000000            mov       ecx, 0x17
0x00014289748b:  ff15bf838a03          call      qword ptr [rip + 0x38a83bf]
0x000142897491:  4885c0                test      rax, rax
0x000142897494:  7504                  jne       0x14289749a
0x000142897496:  448865cf              mov       byte ptr [rbp - 0x31], r12b
0x00014289749a:  0fb74e02              movzx     ecx, word ptr [rsi + 2]
0x00014289749e:  488d45cf              lea       rax, [rbp - 0x31]
0x0001428974a2:  48894587              mov       qword ptr [rbp - 0x79], rax
0x0001428974a6:  ff1584838a03          call      qword ptr [rip + 0x38a8384]
0x0001428974ac:  6689458f              mov       word ptr [rbp - 0x71], ax
0x0001428974b0:  4438257171a105        cmp       byte ptr [rip + 0x5a17171], r12b
0x0001428974b7:  4c8d459f              lea       r8, [rbp - 0x61]
0x0001428974bb:  0f10442448            movups    xmm0, xmmword ptr [rsp + 0x48]
0x0001428974c0:  488b8fa00e0000        mov       rcx, qword ptr [rdi + 0xea0]
0x0001428974c7:  458bcf                mov       r9d, r15d
0x0001428974ca:  0f104d87              movups    xmm1, xmmword ptr [rbp - 0x79]
0x0001428974ce:  0f29459f              movaps    xmmword ptr [rbp - 0x61], xmm0
0x0001428974d2:  0f294daf              movaps    xmmword ptr [rbp - 0x51], xmm1
0x0001428974d6:  743e                  je        0x142897516
0x0001428974d8:  4489642440            mov       dword ptr [rsp + 0x40], r12d
0x0001428974dd:  488d542440            lea       rdx, [rsp + 0x40]
0x0001428974e2:  488b01                mov       rax, qword ptr [rcx]
0x0001428974e5:  4889542428            mov       qword ptr [rsp + 0x28], rdx
0x0001428974ea:  498bd6                mov       rdx, r14
0x0001428974ed:  885c2420              mov       byte ptr [rsp + 0x20], bl
0x0001428974f1:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x0001428974f5:  ff153d888a03          call      qword ptr [rip + 0x38a883d]
0x0001428974fb:  8b542440              mov       edx, dword ptr [rsp + 0x40]
0x0001428974ff:  41b101                mov       r9b, 1
0x000142897502:  410fb6c9              movzx     ecx, r9b
0x000142897506:  4488642420            mov       byte ptr [rsp + 0x20], r12b
0x00014289750b:  440fb6c3              movzx     r8d, bl
0x00014289750f:  e89cd69dff            call      0x142274bb0
0x000142897514:  eb14                  jmp       0x14289752a
0x000142897516:  488b01                mov       rax, qword ptr [rcx]
0x000142897519:  498bd6                mov       rdx, r14
0x00014289751c:  885c2420              mov       byte ptr [rsp + 0x20], bl
0x000142897520:  488b4018              mov       rax, qword ptr [rax + 0x18]
0x000142897524:  ff150e888a03          call      qword ptr [rip + 0x38a880e]
0x00014289752a:  488b9c24f8000000      mov       rbx, qword ptr [rsp + 0xf8]
0x000142897532:  4c8ba424f0000000      mov       r12, qword ptr [rsp + 0xf0]
0x00014289753a:  488b4d0f              mov       rcx, qword ptr [rbp + 0xf]
0x00014289753e:  4833cc                xor       rcx, rsp
0x000142897541:  e89aa02803            call      0x145b215e0
0x000142897546:  4881c400010000        add       rsp, 0x100
0x00014289754d:  415f                  pop       r15
0x00014289754f:  415e                  pop       r14
0x000142897551:  5f                    pop       rdi
0x000142897552:  5e                    pop       rsi
0x000142897553:  5d                    pop       rbp
0x000142897554:  c3                    ret       
0x000142897555:  cc                    int3      
0x000142897556:  cc                    int3      
0x000142897557:  cc                    int3      
0x000142897558:  cc                    int3      
0x000142897559:  cc                    int3      
0x00014289755a:  cc                    int3      
0x00014289755b:  cc                    int3      
0x00014289755c:  cc                    int3      
0x00014289755d:  cc                    int3      
0x00014289755e:  cc                    int3      
0x00014289755f:  cc                    int3      
0x000142897560:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x000142897565:  57                    push      rdi
0x000142897566:  4881ec90000000        sub       rsp, 0x90
0x00014289756d:  488b057cc14705        mov       rax, qword ptr [rip + 0x547c17c]
0x000142897574:  4833c4                xor       rax, rsp
0x000142897577:  4889842480000000      mov       qword ptr [rsp + 0x80], rax
0x00014289757f:  488bfa                mov       rdi, rdx
0x000142897582:  48899c24a0000000      mov       qword ptr [rsp + 0xa0], rbx
0x00014289758a:  488bcf                mov       rcx, rdi
0x00014289758d:  c64424317b            mov       byte ptr [rsp + 0x31], 0x7b
0x000142897592:  488d542431            lea       rdx, [rsp + 0x31]
0x000142897597:  498bf0                mov       rsi, r8
0x00014289759a:  e8d1990000            call      0x1428a0f70
0x00014289759f:  8b4f10                mov       ecx, dword ptr [rdi + 0x10]
0x0001428975a2:  bb80000000            mov       ebx, 0x80
0x0001428975a7:  8bd3                  mov       edx, ebx
0x0001428975a9:  8d41ff                lea       eax, [rcx - 1]
0x0001428975ac:  83e007                and       eax, 7
0x0001428975af:  2bc8                  sub       ecx, eax
0x0001428975b1:  83c107                add       ecx, 7
0x0001428975b4:  894f10                mov       dword ptr [rdi + 0x10], ecx
0x0001428975b7:  f6c107                test      cl, 7
0x0001428975ba:  488bcf                mov       rcx, rdi
0x0001428975bd:  750d                  jne       0x1428975cc
0x0001428975bf:  e80ceb0000            call      0x1428a60d0
0x0001428975c4:  8b4f10                mov       ecx, dword ptr [rdi + 0x10]
0x0001428975c7:  83c107                add       ecx, 7
0x0001428975ca:  eb13                  jmp       0x1428975df
0x0001428975cc:  e8ffea0000            call      0x1428a60d0
0x0001428975d1:  8b5710                mov       edx, dword ptr [rdi + 0x10]
0x0001428975d4:  448bd2                mov       r10d, edx
0x0001428975d7:  4183e207              and       r10d, 7
0x0001428975db:  751a                  jne       0x1428975f7
0x0001428975dd:  8bca                  mov       ecx, edx
0x0001428975df:  0f10056ab4c403        movups    xmm0, xmmword ptr [rip + 0x3c4b46a]
0x0001428975e6:  488b4720              mov       rax, qword ptr [rdi + 0x20]
0x0001428975ea:  48c1e903              shr       rcx, 3
0x0001428975ee:  0f110401              movups    xmmword ptr [rcx + rax], xmm0
0x0001428975f2:  015f10                add       dword ptr [rdi + 0x10], ebx
0x0001428975f5:  eb72                  jmp       0x142897669
0x0001428975f7:  4c8d0d52b4c403        lea       r9, [rip + 0x3c4b452]
0x0001428975fe:  6690                  nop       
0x000142897600:  450fb601              movzx     r8d, byte ptr [r9]
0x000142897604:  4d8d4901              lea       r9, [r9 + 1]
0x000142897608:  83fb08                cmp       ebx, 8
0x00014289760b:  730a                  jae       0x142897617
0x00014289760d:  b908000000            mov       ecx, 8
0x000142897612:  2bcb                  sub       ecx, ebx
0x000142897614:  41d2e0                shl       r8b, cl
0x000142897617:  48c1ea03              shr       rdx, 3
0x00014289761b:  410fb6ca              movzx     ecx, r10b
0x00014289761f:  48035720              add       rdx, qword ptr [rdi + 0x20]
0x000142897623:  410fb6c0              movzx     eax, r8b
0x000142897627:  d2e8                  shr       al, cl
0x000142897629:  b908000000            mov       ecx, 8
0x00014289762e:  412bca                sub       ecx, r10d
0x000142897631:  0802                  or        byte ptr [rdx], al
0x000142897633:  83f908                cmp       ecx, 8
0x000142897636:  7317                  jae       0x14289764f
0x000142897638:  3bcb                  cmp       ecx, ebx
0x00014289763a:  7313                  jae       0x14289764f
0x00014289763c:  488b4720              mov       rax, qword ptr [rdi + 0x20]
0x000142897640:  41d2e0                shl       r8b, cl
0x000142897643:  8b4f10                mov       ecx, dword ptr [rdi + 0x10]
0x000142897646:  48c1e903              shr       rcx, 3
0x00014289764a:  4488440101            mov       byte ptr [rcx + rax + 1], r8b
0x00014289764f:  8b4710                mov       eax, dword ptr [rdi + 0x10]
0x000142897652:  83fb08                cmp       ebx, 8
0x000142897655:  720d                  jb        0x142897664
0x000142897657:  8d5008                lea       edx, [rax + 8]
0x00014289765a:  895710                mov       dword ptr [rdi + 0x10], edx
0x00014289765d:  83c3f8                add       ebx, -8
0x000142897660:  759e                  jne       0x142897600
0x000142897662:  eb05                  jmp       0x142897669
0x000142897664:  03c3                  add       eax, ebx
0x000142897666:  894710                mov       dword ptr [rdi + 0x10], eax
0x000142897669:  488d542430            lea       rdx, [rsp + 0x30]
0x00014289766e:  c644243005            mov       byte ptr [rsp + 0x30], 5
0x000142897673:  488bcf                mov       rcx, rdi
0x000142897676:  e8f5980000            call      0x1428a0f70
0x00014289767b:  488b05e6344d05        mov       rax, qword ptr [rip + 0x54d34e6]
0x000142897682:  488b9c24a0000000      mov       rbx, qword ptr [rsp + 0xa0]
0x00014289768a:  3c06                  cmp       al, 6
0x00014289768c:  0f828e000000          jb        0x142897720
0x000142897692:  48c1e808              shr       rax, 8
0x000142897696:  3c05                  cmp       al, 5
0x000142897698:  0f8282000000          jb        0x142897720
0x00014289769e:  488d050223ac06        lea       rax, [rip + 0x6ac2302]
0x0001428976a5:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x0001428976aa:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x0001428976b1:  488b4c2460            mov       rcx, qword ptr [rsp + 0x60]
0x0001428976b6:  488d0dab3c6a04        lea       rcx, [rip + 0x46a3cab]
0x0001428976bd:  48894c2450            mov       qword ptr [rsp + 0x50], rcx
0x0001428976c2:  48ffc0                inc       rax
0x0001428976c5:  803c0100              cmp       byte ptr [rcx + rax], 0
0x0001428976c9:  75f7                  jne       0x1428976c2
0x0001428976cb:  4889442458            mov       qword ptr [rsp + 0x58], rax
0x0001428976d0:  4c8d4c2440            lea       r9, [rsp + 0x40]
0x0001428976d5:  0f284c2450            movaps    xmm1, xmmword ptr [rsp + 0x50]
0x0001428976da:  488d442470            lea       rax, [rsp + 0x70]
0x0001428976df:  4889442448            mov       qword ptr [rsp + 0x48], rax
0x0001428976e4:  4c8d442450            lea       r8, [rsp + 0x50]
0x0001428976e9:  48c744244000000000    mov       qword ptr [rsp + 0x40], 0
0x0001428976f2:  488d4c2460            lea       rcx, [rsp + 0x60]
0x0001428976f7:  0f28442440            movaps    xmm0, xmmword ptr [rsp + 0x40]
0x0001428976fc:  b205                  mov       dl, 5
0x0001428976fe:  660f7f442440          movdqa    xmmword ptr [rsp + 0x40], xmm0
0x000142897704:  0f10055d344d05        movups    xmm0, xmmword ptr [rip + 0x54d345d]
0x00014289770b:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x000142897710:  660f7f4c2450          movdqa    xmmword ptr [rsp + 0x50], xmm1
0x000142897716:  0f29442460            movaps    xmmword ptr [rsp + 0x60], xmm0
0x00014289771b:  e8b0830c02            call      0x14495fad0
0x000142897720:  488d542430            lea       rdx, [rsp + 0x30]
0x000142897725:  c644243001            mov       byte ptr [rsp + 0x30], 1
0x00014289772a:  488bcf                mov       rcx, rdi
0x00014289772d:  e83e980000            call      0x1428a0f70
0x000142897732:  8bd6                  mov       edx, esi
0x000142897734:  488bcf                mov       rcx, rdi
0x000142897737:  e854ea0000            call      0x1428a6190
0x00014289773c:  488b8c2480000000      mov       rcx, qword ptr [rsp + 0x80]
0x000142897744:  4833cc                xor       rcx, rsp
0x000142897747:  e8949e2803            call      0x145b215e0
0x00014289774c:  488bb424b8000000      mov       rsi, qword ptr [rsp + 0xb8]
0x000142897754:  4881c490000000        add       rsp, 0x90
0x00014289775b:  5f                    pop       rdi
0x00014289775c:  c3                    ret       
0x00014289775d:  cc                    int3      
0x00014289775e:  cc                    int3      
0x00014289775f:  cc                    int3      
0x000142897760:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x000142897765:  55                    push      rbp
0x000142897766:  56                    push      rsi
0x000142897767:  57                    push      rdi
0x000142897768:  4154                  push      r12
0x00014289776a:  4155                  push      r13
0x00014289776c:  4156                  push      r14
0x00014289776e:  4157                  push      r15
0x000142897770:  4881ec90040000        sub       rsp, 0x490
0x000142897777:  488b0572bf4705        mov       rax, qword ptr [rip + 0x547bf72]
0x00014289777e:  4833c4                xor       rax, rsp
0x000142897781:  4889842480040000      mov       qword ptr [rsp + 0x480], rax
0x000142897789:  4c8ba424f0040000      mov       r12, qword ptr [rsp + 0x4f0]
0x000142897791:  488bd9                mov       rbx, rcx
0x000142897794:  4c8bbc24f8040000      mov       r15, qword ptr [rsp + 0x4f8]
0x00014289779c:  4881c1400e0000        add       rcx, 0xe40
0x0001428977a3:  4c8bac2410050000      mov       r13, qword ptr [rsp + 0x510]
0x0001428977ab:  4d8bf1                mov       r14, r9
0x0001428977ae:  498bf8                mov       rdi, r8
0x0001428977b1:  488bf2                mov       rsi, rdx
0x0001428977b4:  e8f7bf2803            call      0x145b237b0
0x0001428977b9:  85c0                  test      eax, eax
0x0001428977bb:  0f8505020000          jne       0x1428979c6
0x0001428977c1:  ff83240e0000          inc       dword ptr [rbx + 0xe24]
0x0001428977c7:  488d8b400e0000        lea       rcx, [rbx + 0xe40]
0x0001428977ce:  e83dc02803            call      0x145b23810
0x0001428977d3:  4883ff12              cmp       rdi, 0x12
0x0001428977d7:  0f8278010000          jb        0x142897955
0x0001428977dd:  0fb7ac2400050000      movzx     ebp, word ptr [rsp + 0x500]
0x0001428977e5:  4803ef                add       rbp, rdi
0x0001428977e8:  488d4528              lea       rax, [rbp + 0x28]
0x0001428977ec:  483d40020000          cmp       rax, 0x240
0x0001428977f2:  0f825d010000          jb        0x142897955
0x0001428977f8:  807e1200              cmp       byte ptr [rsi + 0x12], 0
0x0001428977fc:  400f95c7              setne     dil
0x000142897800:  807e1105              cmp       byte ptr [rsi + 0x11], 5
0x000142897804:  0f84b6000000          je        0x1428978c0
0x00014289780a:  488b05ff324d05        mov       rax, qword ptr [rip + 0x54d32ff]
0x000142897811:  3c06                  cmp       al, 6
0x000142897813:  724d                  jb        0x142897862
0x000142897815:  48c1e808              shr       rax, 8
0x000142897819:  3c03                  cmp       al, 3
0x00014289781b:  7245                  jb        0x142897862
0x00014289781d:  488d051b95ae06        lea       rax, [rip + 0x6ae951b]
0x000142897824:  4533c9                xor       r9d, r9d
0x000142897827:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x00014289782c:  488d4c2440            lea       rcx, [rsp + 0x40]
0x000142897831:  488b542440            mov       rdx, qword ptr [rsp + 0x40]
0x000142897836:  33c0                  xor       eax, eax
0x000142897838:  0f1005d1324d05        movups    xmm0, xmmword ptr [rip + 0x54d32d1]
0x00014289783f:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x000142897844:  488d15153c6a04        lea       rdx, [rip + 0x46a3c15]
0x00014289784b:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x000142897850:  4533c0                xor       r8d, r8d
0x000142897853:  0f29442440            movaps    xmmword ptr [rsp + 0x40], xmm0
0x000142897858:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014289785d:  e8be850c02            call      0x14495fe20
0x000142897862:  488b03                mov       rax, qword ptr [rbx]
0x000142897865:  488d542450            lea       rdx, [rsp + 0x50]
0x00014289786a:  0f1005d77f5505        movups    xmm0, xmmword ptr [rip + 0x5557fd7]
0x000142897871:  488bcb                mov       rcx, rbx
0x000142897874:  0f100ddd7f5505        movups    xmm1, xmmword ptr [rip + 0x5557fdd]
0x00014289787b:  488b80a0010000        mov       rax, qword ptr [rax + 0x1a0]
0x000142897882:  0f29442450            movaps    xmmword ptr [rsp + 0x50], xmm0
0x000142897887:  0f294c2460            movaps    xmmword ptr [rsp + 0x60], xmm1
0x00014289788c:  ff15a6848a03          call      qword ptr [rip + 0x38a84a6]
0x000142897892:  40887c2430            mov       byte ptr [rsp + 0x30], dil
0x000142897897:  4d8bce                mov       r9, r14
0x00014289789a:  4c8bc0                mov       r8, rax
0x00014289789d:  b219                  mov       dl, 0x19
0x00014289789f:  488b842408050000      mov       rax, qword ptr [rsp + 0x508]
0x0001428978a7:  488bcb                mov       rcx, rbx
0x0001428978aa:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x0001428978af:  4c897c2420            mov       qword ptr [rsp + 0x20], r15
0x0001428978b4:  e8a7520000            call      0x14289cb60
0x0001428978b9:  b001                  mov       al, 1
0x0001428978bb:  e9db000000            jmp       0x14289799b
0x0001428978c0:  803db9304d0500        cmp       byte ptr [rip + 0x54d30b9], 0
0x0001428978c7:  765b                  jbe       0x142897924
0x0001428978c9:  41b901040000          mov       r9d, 0x401
0x0001428978cf:  4c8d442470            lea       r8, [rsp + 0x70]
0x0001428978d4:  b201                  mov       dl, 1
0x0001428978d6:  498bce                mov       rcx, r14
0x0001428978d9:  e8c2dd0000            call      0x1428a56a0
0x0001428978de:  488b059b304d05        mov       rax, qword ptr [rip + 0x54d309b]
0x0001428978e5:  3c06                  cmp       al, 6
0x0001428978e7:  723b                  jb        0x142897924
0x0001428978e9:  48c1e808              shr       rax, 8
0x0001428978ed:  3c03                  cmp       al, 3
0x0001428978ef:  7233                  jb        0x142897924
0x0001428978f1:  488d055958af06        lea       rax, [rip + 0x6af5859]
0x0001428978f8:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x0001428978fd:  4c8d442470            lea       r8, [rsp + 0x70]
0x000142897902:  488b542440            mov       rdx, qword ptr [rsp + 0x40]
0x000142897907:  488d4c2440            lea       rcx, [rsp + 0x40]
0x00014289790c:  0f10056d304d05        movups    xmm0, xmmword ptr [rip + 0x54d306d]
0x000142897913:  488d15863b6a04        lea       rdx, [rip + 0x46a3b86]
0x00014289791a:  0f29442440            movaps    xmmword ptr [rsp + 0x40], xmm0
0x00014289791f:  e8bc870c02            call      0x1449600e0
0x000142897924:  488b842408050000      mov       rax, qword ptr [rsp + 0x508]
0x00014289792c:  4d8bcc                mov       r9, r12
0x00014289792f:  4c896c2438            mov       qword ptr [rsp + 0x38], r13
0x000142897934:  4d8bc6                mov       r8, r14
0x000142897937:  40887c2430            mov       byte ptr [rsp + 0x30], dil
0x00014289793c:  488bd5                mov       rdx, rbp
0x00014289793f:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x000142897944:  488bcb                mov       rcx, rbx
0x000142897947:  4c897c2420            mov       qword ptr [rsp + 0x20], r15
0x00014289794c:  e87f000000            call      0x1428979d0
0x000142897951:  b001                  mov       al, 1
0x000142897953:  eb46                  jmp       0x14289799b
0x000142897955:  488b05b4314d05        mov       rax, qword ptr [rip + 0x54d31b4]
0x00014289795c:  3c06                  cmp       al, 6
0x00014289795e:  7239                  jb        0x142897999
0x000142897960:  48c1e808              shr       rax, 8
0x000142897964:  3c03                  cmp       al, 3
0x000142897966:  7231                  jb        0x142897999
0x000142897968:  488d0521bbad06        lea       rax, [rip + 0x6adbb21]
0x00014289796f:  448bc7                mov       r8d, edi
0x000142897972:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x000142897977:  488d4c2440            lea       rcx, [rsp + 0x40]
0x00014289797c:  488b542440            mov       rdx, qword ptr [rsp + 0x40]
0x000142897981:  0f100588314d05        movups    xmm0, xmmword ptr [rip + 0x54d3188]
0x000142897988:  488d1589396a04        lea       rdx, [rip + 0x46a3989]
0x00014289798f:  0f29442440            movaps    xmmword ptr [rsp + 0x40], xmm0
0x000142897994:  e8f77e0c02            call      0x14495f890
0x000142897999:  32c0                  xor       al, al
0x00014289799b:  488b8c2480040000      mov       rcx, qword ptr [rsp + 0x480]
0x0001428979a3:  4833cc                xor       rcx, rsp
0x0001428979a6:  e8359c2803            call      0x145b215e0
0x0001428979ab:  488b9c24d8040000      mov       rbx, qword ptr [rsp + 0x4d8]
0x0001428979b3:  4881c490040000        add       rsp, 0x490
0x0001428979ba:  415f                  pop       r15
0x0001428979bc:  415e                  pop       r14
0x0001428979be:  415d                  pop       r13
0x0001428979c0:  415c                  pop       r12
0x0001428979c2:  5f                    pop       rdi
0x0001428979c3:  5e                    pop       rsi
0x0001428979c4:  5d                    pop       rbp
0x0001428979c5:  c3                    ret       
0x0001428979c6:  8bc8                  mov       ecx, eax
0x0001428979c8:  e8b3c32803            call      0x145b23d80
0x0001428979cd:  cc                    int3      
0x0001428979ce:  cc                    int3      
0x0001428979cf:  cc                    int3      
0x0001428979d0:  48895c2420            mov       qword ptr [rsp + 0x20], rbx
0x0001428979d5:  55                    push      rbp
0x0001428979d6:  56                    push      rsi
0x0001428979d7:  57                    push      rdi
0x0001428979d8:  4154                  push      r12
0x0001428979da:  4155                  push      r13
0x0001428979dc:  4156                  push      r14
0x0001428979de:  4157                  push      r15
0x0001428979e0:  488dac24b0feffff      lea       rbp, [rsp - 0x150]
0x0001428979e8:  4881ec50020000        sub       rsp, 0x250
0x0001428979ef:  488b05fabc4705        mov       rax, qword ptr [rip + 0x547bcfa]
0x0001428979f6:  4833c4                xor       rax, rsp
0x0001428979f9:  48898540010000        mov       qword ptr [rbp + 0x140], rax
0x000142897a00:  4d8be1                mov       r12, r9
0x000142897a03:  4d8be8                mov       r13, r8
0x000142897a06:  4c8bfa                mov       r15, rdx
0x000142897a09:  488bf9                mov       rdi, rcx
0x000142897a0c:  4c8bb5b0010000        mov       r14, qword ptr [rbp + 0x1b0]
0x000142897a13:  488bb5c8010000        mov       rsi, qword ptr [rbp + 0x1c8]
0x000142897a1a:  488d05a7c24004        lea       rax, [rip + 0x440c2a7]
0x000142897a21:  48894500              mov       qword ptr [rbp], rax
0x000142897a25:  c6450800              mov       byte ptr [rbp + 8], 0
0x000142897a29:  4533c0                xor       r8d, r8d
0x000142897a2c:  44894510              mov       dword ptr [rbp + 0x10], r8d
0x000142897a30:  48c7451400080000      mov       qword ptr [rbp + 0x14], 0x800
0x000142897a38:  488d4529              lea       rax, [rbp + 0x29]
0x000142897a3c:  48894520              mov       qword ptr [rbp + 0x20], rax
0x000142897a40:  c6452801              mov       byte ptr [rbp + 0x28], 1
0x000142897a44:  0fb65e03              movzx     ebx, byte ptr [rsi + 3]
0x000142897a48:  80e301                and       bl, 1
0x000142897a4b:  443885c0010000        cmp       byte ptr [rbp + 0x1c0], r8b
0x000142897a52:  0f84b3000000          je        0x142897b0b
0x000142897a58:  488b0509314d05        mov       rax, qword ptr [rip + 0x54d3109]
0x000142897a5f:  3c06                  cmp       al, 6
0x000142897a61:  0f827c000000          jb        0x142897ae3
0x000142897a67:  48c1e808              shr       rax, 8
0x000142897a6b:  3c05                  cmp       al, 5
0x000142897a6d:  7274                  jb        0x142897ae3
0x000142897a6f:  488d05a904b106        lea       rax, [rip + 0x6b104a9]
0x000142897a76:  4889442468            mov       qword ptr [rsp + 0x68], rax
0x000142897a7b:  488b4c2468            mov       rcx, qword ptr [rsp + 0x68]
0x000142897a80:  488d0d19396a04        lea       rcx, [rip + 0x46a3919]
0x000142897a87:  48894d90              mov       qword ptr [rbp - 0x70], rcx
0x000142897a8b:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x000142897a92:  48ffc0                inc       rax
0x000142897a95:  803c0100              cmp       byte ptr [rcx + rax], 0
0x000142897a99:  75f7                  jne       0x142897a92
0x000142897a9b:  48894598              mov       qword ptr [rbp - 0x68], rax
0x000142897a9f:  4c894580              mov       qword ptr [rbp - 0x80], r8
0x000142897aa3:  488d8530010000        lea       rax, [rbp + 0x130]
0x000142897aaa:  48894588              mov       qword ptr [rbp - 0x78], rax
0x000142897aae:  0f284580              movaps    xmm0, xmmword ptr [rbp - 0x80]
0x000142897ab2:  660f7f45a0            movdqa    xmmword ptr [rbp - 0x60], xmm0
0x000142897ab7:  0f284d90              movaps    xmm1, xmmword ptr [rbp - 0x70]
0x000142897abb:  660f7f4db0            movdqa    xmmword ptr [rbp - 0x50], xmm1
0x000142897ac0:  0f1005a1304d05        movups    xmm0, xmmword ptr [rip + 0x54d30a1]
0x000142897ac7:  0f2945c0              movaps    xmmword ptr [rbp - 0x40], xmm0
0x000142897acb:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x000142897ad0:  4c8d4da0              lea       r9, [rbp - 0x60]
0x000142897ad4:  4c8d45b0              lea       r8, [rbp - 0x50]
0x000142897ad8:  b205                  mov       dl, 5
0x000142897ada:  488d4dc0              lea       rcx, [rbp - 0x40]
0x000142897ade:  e8ed7f0c02            call      0x14495fad0
0x000142897ae3:  4c8b8db8010000        mov       r9, qword ptr [rbp + 0x1b8]
0x000142897aea:  488d5500              lea       rdx, [rbp]
0x000142897aee:  84db                  test      bl, bl
0x000142897af0:  740c                  je        0x142897afe
0x000142897af2:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x000142897af7:  e8847d0000            call      0x14289f880
0x000142897afc:  eb61                  jmp       0x142897b5f
0x000142897afe:  4533c0                xor       r8d, r8d
0x000142897b01:  488bcf                mov       rcx, rdi
0x000142897b04:  e877810000            call      0x14289fc80
0x000142897b09:  eb54                  jmp       0x142897b5f
0x000142897b0b:  488b051e854c05        mov       rax, qword ptr [rip + 0x54c851e]
0x000142897b12:  3c06                  cmp       al, 6
0x000142897b14:  7249                  jb        0x142897b5f
0x000142897b16:  48c1e808              shr       rax, 8
0x000142897b1a:  3c03                  cmp       al, 3
0x000142897b1c:  7241                  jb        0x142897b5f
0x000142897b1e:  488d0556efb106        lea       rax, [rip + 0x6b1ef56]
0x000142897b25:  4889442468            mov       qword ptr [rsp + 0x68], rax
0x000142897b2a:  488b542468            mov       rdx, qword ptr [rsp + 0x68]
0x000142897b2f:  488d15ca386a04        lea       rdx, [rip + 0x46a38ca]
0x000142897b36:  0f1005f3844c05        movups    xmm0, xmmword ptr [rip + 0x54c84f3]
0x000142897b3d:  0f2945d0              movaps    xmmword ptr [rbp - 0x30], xmm0
0x000142897b41:  4c89442430            mov       qword ptr [rsp + 0x30], r8
0x000142897b46:  4c89442428            mov       qword ptr [rsp + 0x28], r8
0x000142897b4b:  4c89442420            mov       qword ptr [rsp + 0x20], r8
0x000142897b50:  4533c9                xor       r9d, r9d
0x000142897b53:  4533c0                xor       r8d, r8d
0x000142897b56:  488d4dd0              lea       rcx, [rbp - 0x30]
0x000142897b5a:  e8c1820c02            call      0x14495fe20
0x000142897b5f:  c64424607e            mov       byte ptr [rsp + 0x60], 0x7e
0x000142897b64:  bb08000000            mov       ebx, 8
0x000142897b69:  8bd3                  mov       edx, ebx
0x000142897b6b:  488d4d00              lea       rcx, [rbp]
0x000142897b6f:  e85ce50000            call      0x1428a60d0
0x000142897b74:  8b5510                mov       edx, dword ptr [rbp + 0x10]
0x000142897b77:  448bd2                mov       r10d, edx
0x000142897b7a:  4183e207              and       r10d, 7
0x000142897b7e:  0f8565010000          jne       0x142897ce9
0x000142897b84:  8bca                  mov       ecx, edx
0x000142897b86:  48c1e903              shr       rcx, 3
0x000142897b8a:  488b4520              mov       rax, qword ptr [rbp + 0x20]
0x000142897b8e:  c604017e              mov       byte ptr [rcx + rax], 0x7e
0x000142897b92:  8b5510                mov       edx, dword ptr [rbp + 0x10]
0x000142897b95:  03d3                  add       edx, ebx
0x000142897b97:  8d4aff                lea       ecx, [rdx - 1]
0x000142897b9a:  83e107                and       ecx, 7
0x000142897b9d:  b807000000            mov       eax, 7
0x000142897ba2:  2bc1                  sub       eax, ecx
0x000142897ba4:  03d0                  add       edx, eax
0x000142897ba6:  895510                mov       dword ptr [rbp + 0x10], edx
0x000142897ba9:  bb80000000            mov       ebx, 0x80
0x000142897bae:  488d4d00              lea       rcx, [rbp]
0x000142897bb2:  f6c207                test      dl, 7
0x000142897bb5:  8bd3                  mov       edx, ebx
0x000142897bb7:  0f85a0010000          jne       0x142897d5d
0x000142897bbd:  e80ee50000            call      0x1428a60d0
0x000142897bc2:  8b4d10                mov       ecx, dword ptr [rbp + 0x10]
0x000142897bc5:  83c107                add       ecx, 7
0x000142897bc8:  48c1e903              shr       rcx, 3
0x000142897bcc:  488b4520              mov       rax, qword ptr [rbp + 0x20]
0x000142897bd0:  0f100579aec403        movups    xmm0, xmmword ptr [rip + 0x3c4ae79]
0x000142897bd7:  0f110401              movups    xmmword ptr [rcx + rax], xmm0
0x000142897bdb:  015d10                add       dword ptr [rbp + 0x10], ebx
0x000142897bde:  488b07                mov       rax, qword ptr [rdi]
0x000142897be1:  0f1005607c5505        movups    xmm0, xmmword ptr [rip + 0x5557c60]
0x000142897be8:  0f2945e0              movaps    xmmword ptr [rbp - 0x20], xmm0
0x000142897bec:  0f100d657c5505        movups    xmm1, xmmword ptr [rip + 0x5557c65]
0x000142897bf3:  0f294df0              movaps    xmmword ptr [rbp - 0x10], xmm1
0x000142897bf7:  488d55e0              lea       rdx, [rbp - 0x20]
0x000142897bfb:  488bcf                mov       rcx, rdi
0x000142897bfe:  488b80a0010000        mov       rax, qword ptr [rax + 0x1a0]
0x000142897c05:  ff152d818a03          call      qword ptr [rip + 0x38a812d]
0x000142897c0b:  488bd0                mov       rdx, rax
0x000142897c0e:  488d4d00              lea       rcx, [rbp]
0x000142897c12:  e839940000            call      0x1428a1050
0x000142897c17:  c644246100            mov       byte ptr [rsp + 0x61], 0
0x000142897c1c:  bb08000000            mov       ebx, 8
0x000142897c21:  8bd3                  mov       edx, ebx
0x000142897c23:  488d4d00              lea       rcx, [rbp]
0x000142897c27:  e8a4e40000            call      0x1428a60d0
0x000142897c2c:  8b5510                mov       edx, dword ptr [rbp + 0x10]
0x000142897c2f:  448bd2                mov       r10d, edx
0x000142897c32:  4183e207              and       r10d, 7
0x000142897c36:  0f85b0010000          jne       0x142897dec
0x000142897c3c:  8bca                  mov       ecx, edx
0x000142897c3e:  48c1e903              shr       rcx, 3
0x000142897c42:  488b4520              mov       rax, qword ptr [rbp + 0x20]
0x000142897c46:  44881401              mov       byte ptr [rcx + rax], r10b
0x000142897c4a:  015d10                add       dword ptr [rbp + 0x10], ebx
0x000142897c4d:  664183c728            add       r15w, 0x28
0x000142897c52:  6644897c2462          mov       word ptr [rsp + 0x62], r15w
0x000142897c58:  488d542462            lea       rdx, [rsp + 0x62]
0x000142897c5d:  488d4d00              lea       rcx, [rbp]
0x000142897c61:  e8cab20000            call      0x1428a2f30
0x000142897c66:  448b4510              mov       r8d, dword ptr [rbp + 0x10]
0x000142897c6a:  4183c007              add       r8d, 7
0x000142897c6e:  41c1e803              shr       r8d, 3
0x000142897c72:  488b5520              mov       rdx, qword ptr [rbp + 0x20]
0x000142897c76:  0f57c0                xorps     xmm0, xmm0
0x000142897c79:  f30f7f442468          movdqu    xmmword ptr [rsp + 0x68], xmm0
0x000142897c7f:  498b4608              mov       rax, qword ptr [r14 + 8]
0x000142897c83:  4885c0                test      rax, rax
0x000142897c86:  7404                  je        0x142897c8c
0x000142897c88:  f0ff4008              lock inc  dword ptr [rax + 8]
0x000142897c8c:  498b06                mov       rax, qword ptr [r14]
0x000142897c8f:  4889442468            mov       qword ptr [rsp + 0x68], rax
0x000142897c94:  498b4608              mov       rax, qword ptr [r14 + 8]
0x000142897c98:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x000142897c9d:  33c0                  xor       eax, eax
0x000142897c9f:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x000142897ca4:  4889442438            mov       qword ptr [rsp + 0x38], rax
0x000142897ca9:  48897c2430            mov       qword ptr [rsp + 0x30], rdi
0x000142897cae:  88442428              mov       byte ptr [rsp + 0x28], al
0x000142897cb2:  4c89642420            mov       qword ptr [rsp + 0x20], r12
0x000142897cb7:  4d8bcd                mov       r9, r13
0x000142897cba:  488d4c2468            lea       rcx, [rsp + 0x68]
0x000142897cbf:  e85c010100            call      0x1428a7e20
0x000142897cc4:  83f8fd                cmp       eax, -3
0x000142897cc7:  0f84a0010000          je        0x142897e6d
0x000142897ccd:  48ff87e80f0000        inc       qword ptr [rdi + 0xfe8]
0x000142897cd4:  83f8fc                cmp       eax, -4
0x000142897cd7:  0f8583010000          jne       0x142897e60
0x000142897cdd:  48ff87f00f0000        inc       qword ptr [rdi + 0xff0]
0x000142897ce4:  e9a7010000            jmp       0x142897e90
0x000142897ce9:  4c8d4c2460            lea       r9, [rsp + 0x60]
0x000142897cee:  41b07e                mov       r8b, 0x7e
0x000142897cf1:  4d8d4901              lea       r9, [r9 + 1]
0x000142897cf5:  83fb08                cmp       ebx, 8
0x000142897cf8:  730a                  jae       0x142897d04
0x000142897cfa:  b908000000            mov       ecx, 8
0x000142897cff:  2bcb                  sub       ecx, ebx
0x000142897d01:  41d2e0                shl       r8b, cl
0x000142897d04:  48c1ea03              shr       rdx, 3
0x000142897d08:  48035520              add       rdx, qword ptr [rbp + 0x20]
0x000142897d0c:  410fb6c0              movzx     eax, r8b
0x000142897d10:  410fb6ca              movzx     ecx, r10b
0x000142897d14:  d2e8                  shr       al, cl
0x000142897d16:  0802                  or        byte ptr [rdx], al
0x000142897d18:  b908000000            mov       ecx, 8
0x000142897d1d:  412bca                sub       ecx, r10d
0x000142897d20:  83f908                cmp       ecx, 8
0x000142897d23:  7317                  jae       0x142897d3c
0x000142897d25:  3bcb                  cmp       ecx, ebx
0x000142897d27:  7313                  jae       0x142897d3c
0x000142897d29:  41d2e0                shl       r8b, cl
0x000142897d2c:  8b4d10                mov       ecx, dword ptr [rbp + 0x10]
0x000142897d2f:  48c1e903              shr       rcx, 3
0x000142897d33:  488b4520              mov       rax, qword ptr [rbp + 0x20]
0x000142897d37:  4488440101            mov       byte ptr [rcx + rax + 1], r8b
0x000142897d3c:  83fb08                cmp       ebx, 8
0x000142897d3f:  0f824dfeffff          jb        0x142897b92
0x000142897d45:  8b5510                mov       edx, dword ptr [rbp + 0x10]
0x000142897d48:  83c208                add       edx, 8
0x000142897d4b:  895510                mov       dword ptr [rbp + 0x10], edx
0x000142897d4e:  83c3f8                add       ebx, -8
0x000142897d51:  0f8440feffff          je        0x142897b97
0x000142897d57:  450fb601              movzx     r8d, byte ptr [r9]
0x000142897d5b:  eb94                  jmp       0x142897cf1
0x000142897d5d:  e86ee30000            call      0x1428a60d0
0x000142897d62:  8b5510                mov       edx, dword ptr [rbp + 0x10]
0x000142897d65:  448bd2                mov       r10d, edx
0x000142897d68:  4183e207              and       r10d, 7
0x000142897d6c:  7507                  jne       0x142897d75
0x000142897d6e:  8bca                  mov       ecx, edx
0x000142897d70:  e953feffff            jmp       0x142897bc8
0x000142897d75:  4c8d0dd4acc403        lea       r9, [rip + 0x3c4acd4]
0x000142897d7c:  0f1f4000              nop       dword ptr [rax]
0x000142897d80:  450fb601              movzx     r8d, byte ptr [r9]
0x000142897d84:  4d8d4901              lea       r9, [r9 + 1]
0x000142897d88:  83fb08                cmp       ebx, 8
0x000142897d8b:  730a                  jae       0x142897d97
0x000142897d8d:  b908000000            mov       ecx, 8
0x000142897d92:  2bcb                  sub       ecx, ebx
0x000142897d94:  41d2e0                shl       r8b, cl
0x000142897d97:  48c1ea03              shr       rdx, 3
0x000142897d9b:  48035520              add       rdx, qword ptr [rbp + 0x20]
0x000142897d9f:  410fb6c0              movzx     eax, r8b
0x000142897da3:  410fb6ca              movzx     ecx, r10b
0x000142897da7:  d2e8                  shr       al, cl
0x000142897da9:  0802                  or        byte ptr [rdx], al
0x000142897dab:  b908000000            mov       ecx, 8
0x000142897db0:  412bca                sub       ecx, r10d
0x000142897db3:  83f908                cmp       ecx, 8
0x000142897db6:  7317                  jae       0x142897dcf
0x000142897db8:  3bcb                  cmp       ecx, ebx
0x000142897dba:  7313                  jae       0x142897dcf
0x000142897dbc:  41d2e0                shl       r8b, cl
0x000142897dbf:  8b4d10                mov       ecx, dword ptr [rbp + 0x10]
0x000142897dc2:  48c1e903              shr       rcx, 3
0x000142897dc6:  488b4520              mov       rax, qword ptr [rbp + 0x20]
0x000142897dca:  4488440101            mov       byte ptr [rcx + rax + 1], r8b
0x000142897dcf:  83fb08                cmp       ebx, 8
0x000142897dd2:  0f8203feffff          jb        0x142897bdb
0x000142897dd8:  8b5510                mov       edx, dword ptr [rbp + 0x10]
0x000142897ddb:  83c208                add       edx, 8
0x000142897dde:  895510                mov       dword ptr [rbp + 0x10], edx
0x000142897de1:  83c3f8                add       ebx, -8
0x000142897de4:  0f84f4fdffff          je        0x142897bde
0x000142897dea:  eb94                  jmp       0x142897d80
0x000142897dec:  4c8d4c2461            lea       r9, [rsp + 0x61]
0x000142897df1:  4532c0                xor       r8b, r8b
0x000142897df4:  4d8d4901              lea       r9, [r9 + 1]
0x000142897df8:  83fb08                cmp       ebx, 8
0x000142897dfb:  730a                  jae       0x142897e07
0x000142897dfd:  b908000000            mov       ecx, 8
0x000142897e02:  2bcb                  sub       ecx, ebx
0x000142897e04:  41d2e0                shl       r8b, cl
0x000142897e07:  48c1ea03              shr       rdx, 3
0x000142897e0b:  48035520              add       rdx, qword ptr [rbp + 0x20]
0x000142897e0f:  410fb6c0              movzx     eax, r8b
0x000142897e13:  410fb6ca              movzx     ecx, r10b
0x000142897e17:  d2e8                  shr       al, cl
0x000142897e19:  0802                  or        byte ptr [rdx], al
0x000142897e1b:  b908000000            mov       ecx, 8
0x000142897e20:  412bca                sub       ecx, r10d
0x000142897e23:  83f908                cmp       ecx, 8
0x000142897e26:  7317                  jae       0x142897e3f
0x000142897e28:  3bcb                  cmp       ecx, ebx
0x000142897e2a:  7313                  jae       0x142897e3f
0x000142897e2c:  41d2e0                shl       r8b, cl
0x000142897e2f:  8b4d10                mov       ecx, dword ptr [rbp + 0x10]
0x000142897e32:  48c1e903              shr       rcx, 3
0x000142897e36:  488b4520              mov       rax, qword ptr [rbp + 0x20]
0x000142897e3a:  4488440101            mov       byte ptr [rcx + rax + 1], r8b
0x000142897e3f:  83fb08                cmp       ebx, 8
0x000142897e42:  0f8202feffff          jb        0x142897c4a
0x000142897e48:  8b5510                mov       edx, dword ptr [rbp + 0x10]
0x000142897e4b:  83c208                add       edx, 8
0x000142897e4e:  895510                mov       dword ptr [rbp + 0x10], edx
0x000142897e51:  83c3f8                add       ebx, -8
0x000142897e54:  0f84f3fdffff          je        0x142897c4d
0x000142897e5a:  450fb601              movzx     r8d, byte ptr [r9]
0x000142897e5e:  eb94                  jmp       0x142897df4
0x000142897e60:  85c0                  test      eax, eax
0x000142897e62:  7409                  je        0x142897e6d
0x000142897e64:  48ff87f80f0000        inc       qword ptr [rdi + 0xff8]
0x000142897e6b:  eb23                  jmp       0x142897e90
0x000142897e6d:  488d8f400e0000        lea       rcx, [rdi + 0xe40]
0x000142897e74:  e837b92803            call      0x145b237b0
0x000142897e79:  85c0                  test      eax, eax
0x000142897e7b:  7575                  jne       0x142897ef2
0x000142897e7d:  ff87280e0000          inc       dword ptr [rdi + 0xe28]
0x000142897e83:  488d8f400e0000        lea       rcx, [rdi + 0xe40]
0x000142897e8a:  e881b92803            call      0x145b23810
0x000142897e8f:  90                    nop       
0x000142897e90:  488d0531be4004        lea       rax, [rip + 0x440be31]
0x000142897e97:  48894500              mov       qword ptr [rbp], rax
0x000142897e9b:  807d2800              cmp       byte ptr [rbp + 0x28], 0
0x000142897e9f:  7427                  je        0x142897ec8
0x000142897ea1:  8b4514                mov       eax, dword ptr [rbp + 0x14]
0x000142897ea4:  3d00080000            cmp       eax, 0x800
0x000142897ea9:  7606                  jbe       0x142897eb1
0x000142897eab:  488b4d20              mov       rcx, qword ptr [rbp + 0x20]
0x000142897eaf:  eb11                  jmp       0x142897ec2
0x000142897eb1:  85c0                  test      eax, eax
0x000142897eb3:  7413                  je        0x142897ec8
0x000142897eb5:  488d4529              lea       rax, [rbp + 0x29]
0x000142897eb9:  488b4d20              mov       rcx, qword ptr [rbp + 0x20]
0x000142897ebd:  483bc8                cmp       rcx, rax
0x000142897ec0:  7406                  je        0x142897ec8
0x000142897ec2:  e8e9b10a02            call      0x1449430b0
0x000142897ec7:  90                    nop       
0x000142897ec8:  488b8d40010000        mov       rcx, qword ptr [rbp + 0x140]
0x000142897ecf:  4833cc                xor       rcx, rsp
0x000142897ed2:  e809972803            call      0x145b215e0
0x000142897ed7:  488b9c24a8020000      mov       rbx, qword ptr [rsp + 0x2a8]
0x000142897edf:  4881c450020000        add       rsp, 0x250
0x000142897ee6:  415f                  pop       r15
0x000142897ee8:  415e                  pop       r14
0x000142897eea:  415d                  pop       r13
0x000142897eec:  415c                  pop       r12
0x000142897eee:  5f                    pop       rdi
0x000142897eef:  5e                    pop       rsi
0x000142897ef0:  5d                    pop       rbp
0x000142897ef1:  c3                    ret       
0x000142897ef2:  8bc8                  mov       ecx, eax
0x000142897ef4:  e887be2803            call      0x145b23d80
0x000142897ef9:  cc                    int3      
0x000142897efa:  cc                    int3      
0x000142897efb:  cc                    int3      
0x000142897efc:  cc                    int3      
0x000142897efd:  cc                    int3      
0x000142897efe:  cc                    int3      
0x000142897eff:  cc                    int3      
