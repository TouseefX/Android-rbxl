; Ipv4Tlv vtable slot 1 rva 0x15d98e0
0x1415d98e0:  b002                 mov       al, 2
0x1415d98e2:  c3                   ret       
0x1415d98e3:  cc                   int3      
0x1415d98e4:  cc                   int3      
0x1415d98e5:  cc                   int3      
0x1415d98e6:  cc                   int3      
0x1415d98e7:  cc                   int3      
0x1415d98e8:  cc                   int3      
0x1415d98e9:  cc                   int3      
0x1415d98ea:  cc                   int3      
0x1415d98eb:  cc                   int3      
0x1415d98ec:  cc                   int3      
0x1415d98ed:  cc                   int3      
0x1415d98ee:  cc                   int3      
0x1415d98ef:  cc                   int3      
