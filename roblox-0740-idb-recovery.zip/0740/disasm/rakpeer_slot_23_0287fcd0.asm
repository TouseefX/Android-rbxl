; RakPeer vtable slot 23
; rva 0x287fcd0
0x14287fcd0:  4885d2               test      rdx, rdx
0x14287fcd3:  0f84bd000000         je        0x14287fd96
0x14287fcd9:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x14287fcde:  48897c2418           mov       qword ptr [rsp + 0x18], rdi
0x14287fce3:  4156                 push      r14
0x14287fce5:  4883ec20             sub       rsp, 0x20
0x14287fce9:  4963f8               movsxd    rdi, r8d
0x14287fcec:  488bf2               mov       rsi, rdx
0x14287fcef:  4c8bf1               mov       r14, rcx
0x14287fcf2:  4585c0               test      r8d, r8d
0x14287fcf5:  0f888b000000         js        0x14287fd86
0x14287fcfb:  8bd7                 mov       edx, edi
0x14287fcfd:  48895c2430           mov       qword ptr [rsp + 0x30], rbx
0x14287fd02:  e889aeffff           call      0x14287ab90
0x14287fd07:  4c8bc7               mov       r8, rdi
0x14287fd0a:  488bd6               mov       rdx, rsi
0x14287fd0d:  488bd8               mov       rbx, rax
0x14287fd10:  488b4838             mov       rcx, qword ptr [rax + 0x38]
0x14287fd14:  e887342c03           call      0x145b431a0
0x14287fd19:  410f108ea0090000     movups    xmm1, xmmword ptr [r14 + 0x9a0]
0x14287fd21:  4533c0               xor       r8d, r8d
0x14287fd24:  488bd3               mov       rdx, rbx
0x14287fd27:  410f108690090000     movups    xmm0, xmmword ptr [r14 + 0x990]
0x14287fd2f:  0f1103               movups    xmmword ptr [rbx], xmm0
0x14287fd32:  f20f114b10           movsd     qword ptr [rbx + 0x10], xmm1
0x14287fd37:  660f73d908           psrldq    xmm1, 8
0x14287fd3c:  66480f7ec9           movq      rcx, xmm1
0x14287fd41:  894b18               mov       dword ptr [rbx + 0x18], ecx
0x14287fd44:  488bc1               mov       rax, rcx
0x14287fd47:  48c1e830             shr       rax, 0x30
0x14287fd4b:  6689431e             mov       word ptr [rbx + 0x1e], ax
0x14287fd4f:  48c1e920             shr       rcx, 0x20
0x14287fd53:  66894b1c             mov       word ptr [rbx + 0x1c], cx
0x14287fd57:  498bce               mov       rcx, r14
0x14287fd5a:  498b8640090000       mov       rax, qword ptr [r14 + 0x940]
0x14287fd61:  48894320             mov       qword ptr [rbx + 0x20], rax
0x14287fd65:  410fb78648090000     movzx     eax, word ptr [r14 + 0x948]
0x14287fd6d:  66894328             mov       word ptr [rbx + 0x28], ax
0x14287fd71:  498b06               mov       rax, qword ptr [r14]
0x14287fd74:  488b8018020000       mov       rax, qword ptr [rax + 0x218]
0x14287fd7b:  ff15b7ff8b03         call      qword ptr [rip + 0x38bffb7]
0x14287fd81:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14287fd86:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x14287fd8b:  488b7c2440           mov       rdi, qword ptr [rsp + 0x40]
0x14287fd90:  4883c420             add       rsp, 0x20
0x14287fd94:  415e                 pop       r14
0x14287fd96:  c3                   ret       
0x14287fd97:  cc                   int3      
0x14287fd98:  cc                   int3      
0x14287fd99:  cc                   int3      
0x14287fd9a:  cc                   int3      
0x14287fd9b:  cc                   int3      
0x14287fd9c:  cc                   int3      
0x14287fd9d:  cc                   int3      
0x14287fd9e:  cc                   int3      
0x14287fd9f:  cc                   int3      
