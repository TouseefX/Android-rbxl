; RakPeer vtable slot 79
; rva 0x2884960
0x142884960:  4053                 push      rbx
0x142884962:  4881ec50030000       sub       rsp, 0x350
0x142884969:  0f29b42440030000     movaps    xmmword ptr [rsp + 0x340], xmm6
0x142884971:  488b0578ed4805       mov       rax, qword ptr [rip + 0x548ed78]
0x142884978:  4833c4               xor       rax, rsp
0x14288497b:  4889842430030000     mov       qword ptr [rsp + 0x330], rax
0x142884983:  488bd9               mov       rbx, rcx
0x142884986:  4883b9000f000000     cmp       qword ptr [rcx + 0xf00], 0
0x14288498e:  7452                 je        0x1428849e2
0x142884990:  488d1521694e05       lea       rdx, [rip + 0x54e6921]
0x142884997:  488d4c2420           lea       rcx, [rsp + 0x20]
0x14288499c:  e87fcef4fd           call      0x1407d1820
0x1428849a1:  90                   nop       
0x1428849a2:  488d8c24f8020000     lea       rcx, [rsp + 0x2f8]
0x1428849aa:  e8f1f46300           call      0x142ec3ea0
0x1428849af:  488b8b000f0000       mov       rcx, qword ptr [rbx + 0xf00]
0x1428849b6:  488b01               mov       rax, qword ptr [rcx]
0x1428849b9:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x1428849bd:  ff1575b38b03         call      qword ptr [rip + 0x38bb375]
0x1428849c3:  0f28f0               movaps    xmm6, xmm0
0x1428849c6:  488d8c24f0020000     lea       rcx, [rsp + 0x2f0]
0x1428849ce:  e85dccf4fd           call      0x1407d1630
0x1428849d3:  488d4c2448           lea       rcx, [rsp + 0x48]
0x1428849d8:  e80310f6fd           call      0x1407e59e0
0x1428849dd:  0f28c6               movaps    xmm0, xmm6
0x1428849e0:  eb08                 jmp       0x1428849ea
0x1428849e2:  f20f10051e529404     movsd     xmm0, qword ptr [rip + 0x494521e]
0x1428849ea:  488b8c2430030000     mov       rcx, qword ptr [rsp + 0x330]
0x1428849f2:  4833cc               xor       rcx, rsp
0x1428849f5:  e8e6cb2903           call      0x145b215e0
0x1428849fa:  0f28b42440030000     movaps    xmm6, xmmword ptr [rsp + 0x340]
0x142884a02:  4881c450030000       add       rsp, 0x350
0x142884a09:  5b                   pop       rbx
0x142884a0a:  c3                   ret       
0x142884a0b:  cc                   int3      
0x142884a0c:  cc                   int3      
0x142884a0d:  cc                   int3      
0x142884a0e:  cc                   int3      
0x142884a0f:  cc                   int3      
0x142884a10:  4881c1200e0000       add       rcx, 0xe20
0x142884a17:  e9147f0000           jmp       0x14288c930
0x142884a1c:  cc                   int3      
0x142884a1d:  cc                   int3      
0x142884a1e:  cc                   int3      
0x142884a1f:  cc                   int3      
0x142884a20:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x142884a25:  57                   push      rdi
0x142884a26:  4883ec20             sub       rsp, 0x20
0x142884a2a:  488bf9               mov       rdi, rcx
0x142884a2d:  4881c1300c0000       add       rcx, 0xc30
0x142884a34:  e877ed2903           call      0x145b237b0
0x142884a39:  85c0                 test      eax, eax
0x142884a3b:  7541                 jne       0x142884a7e
0x142884a3d:  8b87880c0000         mov       eax, dword ptr [rdi + 0xc88]
0x142884a43:  48895c2430           mov       qword ptr [rsp + 0x30], rbx
0x142884a48:  8b9f8c0c0000         mov       ebx, dword ptr [rdi + 0xc8c]
0x142884a4e:  3bc3                 cmp       eax, ebx
0x142884a50:  7704                 ja        0x142884a56
0x142884a52:  2bd8                 sub       ebx, eax
0x142884a54:  eb0a                 jmp       0x142884a60
0x142884a56:  8b97900c0000         mov       edx, dword ptr [rdi + 0xc90]
0x142884a5c:  2bd0                 sub       edx, eax
0x142884a5e:  03da                 add       ebx, edx
0x142884a60:  488d8f300c0000       lea       rcx, [rdi + 0xc30]
0x142884a67:  e8a4ed2903           call      0x145b23810
0x142884a6c:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142884a71:  8bc3                 mov       eax, ebx
0x142884a73:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142884a78:  4883c420             add       rsp, 0x20
0x142884a7c:  5f                   pop       rdi
0x142884a7d:  c3                   ret       
0x142884a7e:  8bc8                 mov       ecx, eax
0x142884a80:  e8fbf22903           call      0x145b23d80
0x142884a85:  cc                   int3      
0x142884a86:  cc                   int3      
0x142884a87:  cc                   int3      
0x142884a88:  cc                   int3      
0x142884a89:  cc                   int3      
0x142884a8a:  cc                   int3      
0x142884a8b:  cc                   int3      
0x142884a8c:  cc                   int3      
0x142884a8d:  cc                   int3      
0x142884a8e:  cc                   int3      
0x142884a8f:  cc                   int3      
