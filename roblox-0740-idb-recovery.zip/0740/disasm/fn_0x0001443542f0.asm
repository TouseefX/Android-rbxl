; function_of: str.setServerMachineAddress
; xref site 0x144355c93 -> str.setServerMachineAddress @ 0x146f39dd8
; range 0x1443542f0 .. 0x144356730  (9280 bytes)

0x0001443542f0:  4055                  push      rbp
0x0001443542f2:  53                    push      rbx
0x0001443542f3:  57                    push      rdi
0x0001443542f4:  4154                  push      r12
0x0001443542f6:  4155                  push      r13
0x0001443542f8:  488bec                mov       rbp, rsp
0x0001443542fb:  4881ec80000000        sub       rsp, 0x80
0x000144354302:  488bd9                mov       rbx, rcx
0x000144354305:  4c8d253c5f1602        lea       r12, [rip + 0x2165f3c]
0x00014435430c:  488b4910              mov       rcx, qword ptr [rcx + 0x10]
0x000144354310:  498bd4                mov       rdx, r12
0x000144354313:  4c8b4328              mov       r8, qword ptr [rbx + 0x28]
0x000144354317:  493bc8                cmp       rcx, r8
0x00014435431a:  480f42d1              cmovb     rdx, rcx
0x00014435431e:  837a0c06              cmp       dword ptr [rdx + 0xc], 6
0x000144354322:  7457                  je        0x14435437b
0x000144354324:  0fb64301              movzx     eax, byte ptr [rbx + 1]
0x000144354328:  a804                  test      al, 4
0x00014435432a:  7415                  je        0x144354341
0x00014435432c:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x000144354330:  24fb                  and       al, 0xfb
0x000144354332:  884301                mov       byte ptr [rbx + 1], al
0x000144354335:  488b4138              mov       rax, qword ptr [rcx + 0x38]
0x000144354339:  48894350              mov       qword ptr [rbx + 0x50], rax
0x00014435433d:  48895938              mov       qword ptr [rcx + 0x38], rbx
0x000144354341:  488bcb                mov       rcx, rbx
0x000144354344:  e867f331fe            call      0x1426736b0
0x000144354349:  85c0                  test      eax, eax
0x00014435434b:  0f84f00b0000          je        0x144354f41
0x000144354351:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x000144354355:  488b4150              mov       rax, qword ptr [rcx + 0x50]
0x000144354359:  48394158              cmp       qword ptr [rcx + 0x58], rax
0x00014435435d:  720a                  jb        0x144354369
0x00014435435f:  b201                  mov       dl, 1
0x000144354361:  488bcb                mov       rcx, rbx
0x000144354364:  e887f532fe            call      0x1426838f0
0x000144354369:  488b4b10              mov       rcx, qword ptr [rbx + 0x10]
0x00014435436d:  498bd4                mov       rdx, r12
0x000144354370:  4c8b4328              mov       r8, qword ptr [rbx + 0x28]
0x000144354374:  493bc8                cmp       rcx, r8
0x000144354377:  480f42d1              cmovb     rdx, rcx
0x00014435437b:  488b02                mov       rax, qword ptr [rdx]
0x00014435437e:  8b7814                mov       edi, dword ptr [rax + 0x14]
0x000144354381:  4c8d6818              lea       r13, [rax + 0x18]
0x000144354385:  48897d40              mov       qword ptr [rbp + 0x40], rdi
0x000144354389:  4d85ed                test      r13, r13
0x00014435438c:  0f84af0b0000          je        0x144354f41
0x000144354392:  4889b424c8000000      mov       qword ptr [rsp + 0xc8], rsi
0x00014435439a:  4883c110              add       rcx, 0x10
0x00014435439e:  4c89742478            mov       qword ptr [rsp + 0x78], r14
0x0001443543a3:  be03000000            mov       esi, 3
0x0001443543a8:  493bc8                cmp       rcx, r8
0x0001443543ab:  734b                  jae       0x1443543f8
0x0001443543ad:  493bcc                cmp       rcx, r12
0x0001443543b0:  7446                  je        0x1443543f8
0x0001443543b2:  83790c00              cmp       dword ptr [rcx + 0xc], 0
0x0001443543b6:  7e40                  jle       0x1443543f8
0x0001443543b8:  8b410c                mov       eax, dword ptr [rcx + 0xc]
0x0001443543bb:  3bc6                  cmp       eax, esi
0x0001443543bd:  7432                  je        0x1443543f1
0x0001443543bf:  83f806                cmp       eax, 6
0x0001443543c2:  0f858b0b0000          jne       0x144354f53
0x0001443543c8:  488b09                mov       rcx, qword ptr [rcx]
0x0001443543cb:  488d5530              lea       rdx, [rbp + 0x30]
0x0001443543cf:  4883c118              add       rcx, 0x18
0x0001443543d3:  e8f81b34fe            call      0x142695fd0
0x0001443543d8:  85c0                  test      eax, eax
0x0001443543da:  0f84730b0000          je        0x144354f53
0x0001443543e0:  f20f104530            movsd     xmm0, qword ptr [rbp + 0x30]
0x0001443543e5:  488d4dd0              lea       rcx, [rbp - 0x30]
0x0001443543e9:  f20f1145d0            movsd     qword ptr [rbp - 0x30], xmm0
0x0001443543ee:  8975dc                mov       dword ptr [rbp - 0x24], esi
0x0001443543f1:  f2440f2c31            cvttsd2si r14d, qword ptr [rcx]
0x0001443543f6:  eb06                  jmp       0x1443543fe
0x0001443543f8:  41be01000000          mov       r14d, 1
0x0001443543fe:  488b4310              mov       rax, qword ptr [rbx + 0x10]
0x000144354402:  4883c020              add       rax, 0x20
0x000144354406:  4c897c2470            mov       qword ptr [rsp + 0x70], r15
0x00014435440b:  483b4328              cmp       rax, qword ptr [rbx + 0x28]
0x00014435440f:  734b                  jae       0x14435445c
0x000144354411:  493bc4                cmp       rax, r12
0x000144354414:  7446                  je        0x14435445c
0x000144354416:  83780c00              cmp       dword ptr [rax + 0xc], 0
0x00014435441a:  7e40                  jle       0x14435445c
0x00014435441c:  8b480c                mov       ecx, dword ptr [rax + 0xc]
0x00014435441f:  3bce                  cmp       ecx, esi
0x000144354421:  7432                  je        0x144354455
0x000144354423:  83f906                cmp       ecx, 6
0x000144354426:  0f85380b0000          jne       0x144354f64
0x00014435442c:  488b08                mov       rcx, qword ptr [rax]
0x00014435442f:  488d5538              lea       rdx, [rbp + 0x38]
0x000144354433:  4883c118              add       rcx, 0x18
0x000144354437:  e8941b34fe            call      0x142695fd0
0x00014435443c:  85c0                  test      eax, eax
0x00014435443e:  0f84200b0000          je        0x144354f64
0x000144354444:  f20f104538            movsd     xmm0, qword ptr [rbp + 0x38]
0x000144354449:  488d45e0              lea       rax, [rbp - 0x20]
0x00014435444d:  f20f1145e0            movsd     qword ptr [rbp - 0x20], xmm0
0x000144354452:  8975ec                mov       dword ptr [rbp - 0x14], esi
0x000144354455:  f2440f2c38            cvttsd2si r15d, qword ptr [rax]
0x00014435445a:  eb06                  jmp       0x144354462
0x00014435445c:  41bfffffffff          mov       r15d, 0xffffffff
0x000144354462:  4585f6                test      r14d, r14d
0x000144354465:  740a                  je        0x144354471
0x000144354467:  7905                  jns       0x14435446e
0x000144354469:  4403f7                add       r14d, edi
0x00014435446c:  eb03                  jmp       0x144354471
0x00014435446e:  41ffce                dec       r14d
0x000144354471:  4585ff                test      r15d, r15d
0x000144354474:  740a                  je        0x144354480
0x000144354476:  7905                  jns       0x14435447d
0x000144354478:  4403ff                add       r15d, edi
0x00014435447b:  eb03                  jmp       0x144354480
0x00014435447d:  41ffcf                dec       r15d
0x000144354480:  803d5165f80300        cmp       byte ptr [rip + 0x3f86551], 0
0x000144354487:  0f845e050000          je        0x1443549eb
0x00014435448d:  453bf7                cmp       r14d, r15d
0x000144354490:  0f8fe5020000          jg        0x14435477b
0x000144354496:  443bf7                cmp       r14d, edi
0x000144354499:  0f8ddc020000          jge       0x14435477b
0x00014435449f:  4585f6                test      r14d, r14d
0x0001443544a2:  7425                  je        0x1443544c9
0x0001443544a4:  4c896de0              mov       qword ptr [rbp - 0x20], r13
0x0001443544a8:  488d55e0              lea       rdx, [rbp - 0x20]
0x0001443544ac:  48897de8              mov       qword ptr [rbp - 0x18], rdi
0x0001443544b0:  488d4dd0              lea       rcx, [rbp - 0x30]
0x0001443544b4:  0f2845e0              movaps    xmm0, xmmword ptr [rbp - 0x20]
0x0001443544b8:  4d63c6                movsxd    r8, r14d
0x0001443544bb:  660f7f45e0            movdqa    xmmword ptr [rbp - 0x20], xmm0
0x0001443544c0:  e8ab1675fe            call      0x142aa5b70
0x0001443544c5:  448b75d0              mov       r14d, dword ptr [rbp - 0x30]
0x0001443544c9:  8d47ff                lea       eax, [rdi - 1]
0x0001443544cc:  443bff                cmp       r15d, edi
0x0001443544cf:  7c05                  jl        0x1443544d6
0x0001443544d1:  448bf8                mov       r15d, eax
0x0001443544d4:  eb31                  jmp       0x144354507
0x0001443544d6:  443bf8                cmp       r15d, eax
0x0001443544d9:  742c                  je        0x144354507
0x0001443544db:  4c896de0              mov       qword ptr [rbp - 0x20], r13
0x0001443544df:  488d55d0              lea       rdx, [rbp - 0x30]
0x0001443544e3:  48897de8              mov       qword ptr [rbp - 0x18], rdi
0x0001443544e7:  488d4de0              lea       rcx, [rbp - 0x20]
0x0001443544eb:  0f2845e0              movaps    xmm0, xmmword ptr [rbp - 0x20]
0x0001443544ef:  4d63c7                movsxd    r8, r15d
0x0001443544f2:  660f7f45d0            movdqa    xmmword ptr [rbp - 0x30], xmm0
0x0001443544f7:  e8741675fe            call      0x142aa5b70
0x0001443544fc:  448b7de8              mov       r15d, dword ptr [rbp - 0x18]
0x000144354500:  41ffcf                dec       r15d
0x000144354503:  44037de0              add       r15d, dword ptr [rbp - 0x20]
0x000144354507:  0fb64301              movzx     eax, byte ptr [rbx + 1]
0x00014435450b:  a804                  test      al, 4
0x00014435450d:  7415                  je        0x144354524
0x00014435450f:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x000144354513:  24fb                  and       al, 0xfb
0x000144354515:  884301                mov       byte ptr [rbx + 1], al
0x000144354518:  488b4138              mov       rax, qword ptr [rcx + 0x38]
0x00014435451c:  48894350              mov       qword ptr [rbx + 0x50], rax
0x000144354520:  48895938              mov       qword ptr [rcx + 0x38], rbx
0x000144354524:  488b4308              mov       rax, qword ptr [rbx + 8]
0x000144354528:  488b4b28              mov       rcx, qword ptr [rbx + 0x28]
0x00014435452c:  4883c110              add       rcx, 0x10
0x000144354530:  483b08                cmp       rcx, qword ptr [rax]
0x000144354533:  7615                  jbe       0x14435454a
0x000144354535:  ba01000000            mov       edx, 1
0x00014435453a:  488bcb                mov       rcx, rbx
0x00014435453d:  e88e7f30fe            call      0x14265c4d0
0x000144354542:  85c0                  test      eax, eax
0x000144354544:  0f84660a0000          je        0x144354fb0
0x00014435454a:  488b4b28              mov       rcx, qword ptr [rbx + 0x28]
0x00014435454e:  418bd6                mov       edx, r14d
0x000144354551:  48394b10              cmp       qword ptr [rbx + 0x10], rcx
0x000144354555:  4c0f426310            cmovb     r12, qword ptr [rbx + 0x10]
0x00014435455a:  410f100424            movups    xmm0, xmmword ptr [r12]
0x00014435455f:  0f1101                movups    xmmword ptr [rcx], xmm0
0x000144354562:  4883432810            add       qword ptr [rbx + 0x28], 0x10
0x000144354567:  488bcb                mov       rcx, rbx
0x00014435456a:  e8119030fe            call      0x14265d580
0x00014435456f:  418bd7                mov       edx, r15d
0x000144354572:  488bcb                mov       rcx, rbx
0x000144354575:  e8069030fe            call      0x14265d580
0x00014435457a:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x00014435457e:  488b4150              mov       rax, qword ptr [rcx + 0x50]
0x000144354582:  48394158              cmp       qword ptr [rcx + 0x58], rax
0x000144354586:  720a                  jb        0x144354592
0x000144354588:  b201                  mov       dl, 1
0x00014435458a:  488bcb                mov       rcx, rbx
0x00014435458d:  e85ef332fe            call      0x1426838f0
0x000144354592:  0fb64301              movzx     eax, byte ptr [rbx + 1]
0x000144354596:  a804                  test      al, 4
0x000144354598:  7415                  je        0x1443545af
0x00014435459a:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x00014435459e:  24fb                  and       al, 0xfb
0x0001443545a0:  884301                mov       byte ptr [rbx + 1], al
0x0001443545a3:  488b4138              mov       rax, qword ptr [rcx + 0x38]
0x0001443545a7:  48894350              mov       qword ptr [rbx + 0x50], rax
0x0001443545ab:  48895938              mov       qword ptr [rcx + 0x38], rbx
0x0001443545af:  488b4308              mov       rax, qword ptr [rbx + 8]
0x0001443545b3:  488b4b28              mov       rcx, qword ptr [rbx + 0x28]
0x0001443545b7:  4883c110              add       rcx, 0x10
0x0001443545bb:  483b08                cmp       rcx, qword ptr [rax]
0x0001443545be:  7615                  jbe       0x1443545d5
0x0001443545c0:  ba01000000            mov       edx, 1
0x0001443545c5:  488bcb                mov       rcx, rbx
0x0001443545c8:  e8037f30fe            call      0x14265c4d0
0x0001443545cd:  85c0                  test      eax, eax
0x0001443545cf:  0f84db090000          je        0x144354fb0
0x0001443545d5:  488b4308              mov       rax, qword ptr [rbx + 8]
0x0001443545d9:  483b4370              cmp       rax, qword ptr [rbx + 0x70]
0x0001443545dd:  7506                  jne       0x1443545e5
0x0001443545df:  4c8b6b60              mov       r13, qword ptr [rbx + 0x60]
0x0001443545e3:  eb0b                  jmp       0x1443545f0
0x0001443545e5:  488b4008              mov       rax, qword ptr [rax + 8]
0x0001443545e9:  488b08                mov       rcx, qword ptr [rax]
0x0001443545ec:  4c8b6910              mov       r13, qword ptr [rcx + 0x10]
0x0001443545f0:  480fbe05a804a103      movsx     rax, byte ptr [rip + 0x3a104a8]
0x0001443545f8:  440fb67b04            movzx     r15d, byte ptr [rbx + 4]
0x0001443545fd:  4c8b7318              mov       r14, qword ptr [rbx + 0x18]
0x000144354601:  85c0                  test      eax, eax
0x000144354603:  0f888a000000          js        0x144354693
0x000144354609:  498b94c6a0000000      mov       rdx, qword ptr [r14 + rax*8 + 0xa0]
0x000144354611:  4c8be0                mov       r12, rax
0x000144354614:  4885d2                test      rdx, rdx
0x000144354617:  751e                  jne       0x144354637
0x000144354619:  88542420              mov       byte ptr [rsp + 0x20], dl
0x00014435461d:  4d8d4668              lea       r8, [r14 + 0x68]
0x000144354621:  498d96a0000000        lea       rdx, [r14 + 0xa0]
0x000144354628:  440fb6c8              movzx     r9d, al
0x00014435462c:  488bcb                mov       rcx, rbx
0x00014435462f:  e87c8a34fe            call      0x14269d0b0
0x000144354634:  488bd0                mov       rdx, rax
0x000144354637:  4c634230              movsxd    r8, dword ptr [rdx + 0x30]
0x00014435463b:  4585c0                test      r8d, r8d
0x00014435463e:  7811                  js        0x144354651
0x000144354640:  488d7a40              lea       rdi, [rdx + 0x40]
0x000144354644:  4903f8                add       rdi, r8
0x000144354647:  442b4224              sub       r8d, dword ptr [rdx + 0x24]
0x00014435464b:  44894230              mov       dword ptr [rdx + 0x30], r8d
0x00014435464f:  eb0c                  jmp       0x14435465d
0x000144354651:  488b7a28              mov       rdi, qword ptr [rdx + 0x28]
0x000144354655:  488b4708              mov       rax, qword ptr [rdi + 8]
0x000144354659:  48894228              mov       qword ptr [rdx + 0x28], rax
0x00014435465d:  ff4234                inc       dword ptr [rdx + 0x34]
0x000144354660:  48837a2800            cmp       qword ptr [rdx + 0x28], 0
0x000144354665:  7557                  jne       0x1443546be
0x000144354667:  4585c0                test      r8d, r8d
0x00014435466a:  7952                  jns       0x1443546be
0x00014435466c:  488b4218              mov       rax, qword ptr [rdx + 0x18]
0x000144354670:  4b8984e6a0000000      mov       qword ptr [r14 + r12*8 + 0xa0], rax
0x000144354678:  488b4218              mov       rax, qword ptr [rdx + 0x18]
0x00014435467c:  4885c0                test      rax, rax
0x00014435467f:  7408                  je        0x144354689
0x000144354681:  48c7401000000000      mov       qword ptr [rax + 0x10], 0
0x000144354689:  48c7421800000000      mov       qword ptr [rdx + 0x18], 0
0x000144354691:  eb2b                  jmp       0x1443546be
0x000144354693:  41b960000000          mov       r9d, 0x60
0x000144354699:  c744242001000000      mov       dword ptr [rsp + 0x20], 1
0x0001443546a1:  498d5668              lea       rdx, [r14 + 0x68]
0x0001443546a5:  488bcb                mov       rcx, rbx
0x0001443546a8:  458d4140              lea       r8d, [r9 + 0x40]
0x0001443546ac:  e88f8834fe            call      0x14269cf40
0x0001443546b1:  8b4824                mov       ecx, dword ptr [rax + 0x24]
0x0001443546b4:  488d7840              lea       rdi, [rax + 0x40]
0x0001443546b8:  294830                sub       dword ptr [rax + 0x30], ecx
0x0001443546bb:  ff4034                inc       dword ptr [rax + 0x34]
0x0001443546be:  4885ff                test      rdi, rdi
0x0001443546c1:  0f846c080000          je        0x144354f33
0x0001443546c7:  4983465860            add       qword ptr [r14 + 0x58], 0x60
0x0001443546cc:  410fb6c7              movzx     eax, r15b
0x0001443546d0:  498384c6b02d000060    add       qword ptr [r14 + rax*8 + 0x2db0], 0x60
0x0001443546d9:  498b8660060000        mov       rax, qword ptr [r14 + 0x660]
0x0001443546e0:  4885c0                test      rax, rax
0x0001443546e3:  742a                  je        0x14435470f
0x0001443546e5:  c744243000000000      mov       dword ptr [rsp + 0x30], 0
0x0001443546ed:  41b960000000          mov       r9d, 0x60
0x0001443546f3:  c744242808000000      mov       dword ptr [rsp + 0x28], 8
0x0001443546fb:  4533c0                xor       r8d, r8d
0x0001443546fe:  488bd7                mov       rdx, rdi
0x000144354701:  44887c2420            mov       byte ptr [rsp + 0x20], r15b
0x000144354706:  488bcb                mov       rcx, rbx
0x000144354709:  ff1529b6de01          call      qword ptr [rip + 0x1deb629]
0x00014435470f:  488b4318              mov       rax, qword ptr [rbx + 0x18]
0x000144354713:  0fb608                movzx     ecx, byte ptr [rax]
0x000144354716:  4022ce                and       cl, sil
0x000144354719:  c60708                mov       byte ptr [rdi], 8
0x00014435471c:  884f01                mov       byte ptr [rdi + 1], cl
0x00014435471f:  488d0d3af6ffff        lea       rcx, [rip - 0x9c6]
0x000144354726:  0fb64304              movzx     eax, byte ptr [rbx + 4]
0x00014435472a:  884702                mov       byte ptr [rdi + 2], al
0x00014435472d:  488d4720              lea       rax, [rdi + 0x20]
0x000144354731:  488900                mov       qword ptr [rax], rax
0x000144354734:  48894f18              mov       qword ptr [rdi + 0x18], rcx
0x000144354738:  b930000000            mov       ecx, 0x30
0x00014435473d:  48c7472800000000      mov       qword ptr [rdi + 0x28], 0
0x000144354745:  c7470301031400        mov       dword ptr [rdi + 3], 0x140301
0x00014435474c:  4c896f10              mov       qword ptr [rdi + 0x10], r13
0x000144354750:  48834328d0            add       qword ptr [rbx + 0x28], -0x30
0x000144354755:  6666660f1f840000000000  nop       word ptr [rax + rax]
0x000144354760:  488b4328              mov       rax, qword ptr [rbx + 0x28]
0x000144354764:  488d49f0              lea       rcx, [rcx - 0x10]
0x000144354768:  0f100401              movups    xmm0, xmmword ptr [rcx + rax]
0x00014435476c:  0f11440f30            movups    xmmword ptr [rdi + rcx + 0x30], xmm0
0x000144354771:  83ee01                sub       esi, 1
0x000144354774:  75ea                  jne       0x144354760
0x000144354776:  e97f070000            jmp       0x144354efa
0x00014435477b:  0fb64301              movzx     eax, byte ptr [rbx + 1]
0x00014435477f:  a804                  test      al, 4
0x000144354781:  7415                  je        0x144354798
0x000144354783:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x000144354787:  24fb                  and       al, 0xfb
0x000144354789:  884301                mov       byte ptr [rbx + 1], al
0x00014435478c:  488b4138              mov       rax, qword ptr [rcx + 0x38]
0x000144354790:  48894350              mov       qword ptr [rbx + 0x50], rax
0x000144354794:  48895938              mov       qword ptr [rcx + 0x38], rbx
0x000144354798:  488b4308              mov       rax, qword ptr [rbx + 8]
0x00014435479c:  488b4b28              mov       rcx, qword ptr [rbx + 0x28]
0x0001443547a0:  4883c110              add       rcx, 0x10
0x0001443547a4:  483b08                cmp       rcx, qword ptr [rax]
0x0001443547a7:  7615                  jbe       0x1443547be
0x0001443547a9:  ba01000000            mov       edx, 1
0x0001443547ae:  488bcb                mov       rcx, rbx
0x0001443547b1:  e81a7d30fe            call      0x14265c4d0
0x0001443547b6:  85c0                  test      eax, eax
0x0001443547b8:  0f84f2070000          je        0x144354fb0
0x0001443547be:  488b4b28              mov       rcx, qword ptr [rbx + 0x28]
0x0001443547c2:  ba01000000            mov       edx, 1
0x0001443547c7:  48394b10              cmp       qword ptr [rbx + 0x10], rcx
0x0001443547cb:  4c0f426310            cmovb     r12, qword ptr [rbx + 0x10]
0x0001443547d0:  410f100424            movups    xmm0, xmmword ptr [r12]
0x0001443547d5:  0f1101                movups    xmmword ptr [rcx], xmm0
0x0001443547d8:  4883432810            add       qword ptr [rbx + 0x28], 0x10
0x0001443547dd:  488bcb                mov       rcx, rbx
0x0001443547e0:  e89b8d30fe            call      0x14265d580
0x0001443547e5:  33d2                  xor       edx, edx
0x0001443547e7:  488bcb                mov       rcx, rbx
0x0001443547ea:  e8918d30fe            call      0x14265d580
0x0001443547ef:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x0001443547f3:  488b4150              mov       rax, qword ptr [rcx + 0x50]
0x0001443547f7:  48394158              cmp       qword ptr [rcx + 0x58], rax
0x0001443547fb:  720a                  jb        0x144354807
0x0001443547fd:  b201                  mov       dl, 1
0x0001443547ff:  488bcb                mov       rcx, rbx
0x000144354802:  e8e9f032fe            call      0x1426838f0
0x000144354807:  0fb64301              movzx     eax, byte ptr [rbx + 1]
0x00014435480b:  a804                  test      al, 4
0x00014435480d:  7415                  je        0x144354824
0x00014435480f:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x000144354813:  24fb                  and       al, 0xfb
0x000144354815:  884301                mov       byte ptr [rbx + 1], al
0x000144354818:  488b4138              mov       rax, qword ptr [rcx + 0x38]
0x00014435481c:  48894350              mov       qword ptr [rbx + 0x50], rax
0x000144354820:  48895938              mov       qword ptr [rcx + 0x38], rbx
0x000144354824:  488b4308              mov       rax, qword ptr [rbx + 8]
0x000144354828:  488b4b28              mov       rcx, qword ptr [rbx + 0x28]
0x00014435482c:  4883c110              add       rcx, 0x10
0x000144354830:  483b08                cmp       rcx, qword ptr [rax]
0x000144354833:  7615                  jbe       0x14435484a
0x000144354835:  ba01000000            mov       edx, 1
0x00014435483a:  488bcb                mov       rcx, rbx
0x00014435483d:  e88e7c30fe            call      0x14265c4d0
0x000144354842:  85c0                  test      eax, eax
0x000144354844:  0f8466070000          je        0x144354fb0
0x00014435484a:  488b4308              mov       rax, qword ptr [rbx + 8]
0x00014435484e:  483b4370              cmp       rax, qword ptr [rbx + 0x70]
0x000144354852:  7506                  jne       0x14435485a
0x000144354854:  4c8b6b60              mov       r13, qword ptr [rbx + 0x60]
0x000144354858:  eb0b                  jmp       0x144354865
0x00014435485a:  488b4008              mov       rax, qword ptr [rax + 8]
0x00014435485e:  488b08                mov       rcx, qword ptr [rax]
0x000144354861:  4c8b6910              mov       r13, qword ptr [rcx + 0x10]
0x000144354865:  480fbe053302a103      movsx     rax, byte ptr [rip + 0x3a10233]
0x00014435486d:  440fb67b04            movzx     r15d, byte ptr [rbx + 4]
0x000144354872:  4c8b7318              mov       r14, qword ptr [rbx + 0x18]
0x000144354876:  85c0                  test      eax, eax
0x000144354878:  0f888a000000          js        0x144354908
0x00014435487e:  498b94c6a0000000      mov       rdx, qword ptr [r14 + rax*8 + 0xa0]
0x000144354886:  4c8be0                mov       r12, rax
0x000144354889:  4885d2                test      rdx, rdx
0x00014435488c:  751e                  jne       0x1443548ac
0x00014435488e:  88542420              mov       byte ptr [rsp + 0x20], dl
0x000144354892:  4d8d4668              lea       r8, [r14 + 0x68]
0x000144354896:  498d96a0000000        lea       rdx, [r14 + 0xa0]
0x00014435489d:  440fb6c8              movzx     r9d, al
0x0001443548a1:  488bcb                mov       rcx, rbx
0x0001443548a4:  e8078834fe            call      0x14269d0b0
0x0001443548a9:  488bd0                mov       rdx, rax
0x0001443548ac:  4c634230              movsxd    r8, dword ptr [rdx + 0x30]
0x0001443548b0:  4585c0                test      r8d, r8d
0x0001443548b3:  7811                  js        0x1443548c6
0x0001443548b5:  488d7a40              lea       rdi, [rdx + 0x40]
0x0001443548b9:  4903f8                add       rdi, r8
0x0001443548bc:  442b4224              sub       r8d, dword ptr [rdx + 0x24]
0x0001443548c0:  44894230              mov       dword ptr [rdx + 0x30], r8d
0x0001443548c4:  eb0c                  jmp       0x1443548d2
0x0001443548c6:  488b7a28              mov       rdi, qword ptr [rdx + 0x28]
0x0001443548ca:  488b4708              mov       rax, qword ptr [rdi + 8]
0x0001443548ce:  48894228              mov       qword ptr [rdx + 0x28], rax
0x0001443548d2:  ff4234                inc       dword ptr [rdx + 0x34]
0x0001443548d5:  48837a2800            cmp       qword ptr [rdx + 0x28], 0
0x0001443548da:  7557                  jne       0x144354933
0x0001443548dc:  4585c0                test      r8d, r8d
0x0001443548df:  7952                  jns       0x144354933
0x0001443548e1:  488b4218              mov       rax, qword ptr [rdx + 0x18]
0x0001443548e5:  4b8984e6a0000000      mov       qword ptr [r14 + r12*8 + 0xa0], rax
0x0001443548ed:  488b4218              mov       rax, qword ptr [rdx + 0x18]
0x0001443548f1:  4885c0                test      rax, rax
0x0001443548f4:  7408                  je        0x1443548fe
0x0001443548f6:  48c7401000000000      mov       qword ptr [rax + 0x10], 0
0x0001443548fe:  48c7421800000000      mov       qword ptr [rdx + 0x18], 0
0x000144354906:  eb2b                  jmp       0x144354933
0x000144354908:  41b960000000          mov       r9d, 0x60
0x00014435490e:  c744242001000000      mov       dword ptr [rsp + 0x20], 1
0x000144354916:  498d5668              lea       rdx, [r14 + 0x68]
0x00014435491a:  488bcb                mov       rcx, rbx
0x00014435491d:  458d4140              lea       r8d, [r9 + 0x40]
0x000144354921:  e81a8634fe            call      0x14269cf40
0x000144354926:  8b4824                mov       ecx, dword ptr [rax + 0x24]
0x000144354929:  488d7840              lea       rdi, [rax + 0x40]
0x00014435492d:  294830                sub       dword ptr [rax + 0x30], ecx
0x000144354930:  ff4034                inc       dword ptr [rax + 0x34]
0x000144354933:  4885ff                test      rdi, rdi
0x000144354936:  0f84f7050000          je        0x144354f33
0x00014435493c:  4983465860            add       qword ptr [r14 + 0x58], 0x60
0x000144354941:  410fb6c7              movzx     eax, r15b
0x000144354945:  498384c6b02d000060    add       qword ptr [r14 + rax*8 + 0x2db0], 0x60
0x00014435494e:  498b8660060000        mov       rax, qword ptr [r14 + 0x660]
0x000144354955:  4885c0                test      rax, rax
0x000144354958:  742a                  je        0x144354984
0x00014435495a:  c744243000000000      mov       dword ptr [rsp + 0x30], 0
0x000144354962:  41b960000000          mov       r9d, 0x60
0x000144354968:  c744242808000000      mov       dword ptr [rsp + 0x28], 8
0x000144354970:  4533c0                xor       r8d, r8d
0x000144354973:  488bd7                mov       rdx, rdi
0x000144354976:  44887c2420            mov       byte ptr [rsp + 0x20], r15b
0x00014435497b:  488bcb                mov       rcx, rbx
0x00014435497e:  ff15b4b3de01          call      qword ptr [rip + 0x1deb3b4]
0x000144354984:  488b4318              mov       rax, qword ptr [rbx + 0x18]
0x000144354988:  0fb608                movzx     ecx, byte ptr [rax]
0x00014435498b:  4022ce                and       cl, sil
0x00014435498e:  c60708                mov       byte ptr [rdi], 8
0x000144354991:  884f01                mov       byte ptr [rdi + 1], cl
0x000144354994:  488d0dc5f3ffff        lea       rcx, [rip - 0xc3b]
0x00014435499b:  0fb64304              movzx     eax, byte ptr [rbx + 4]
0x00014435499f:  884702                mov       byte ptr [rdi + 2], al
0x0001443549a2:  488d4720              lea       rax, [rdi + 0x20]
0x0001443549a6:  488900                mov       qword ptr [rax], rax
0x0001443549a9:  48894f18              mov       qword ptr [rdi + 0x18], rcx
0x0001443549ad:  b930000000            mov       ecx, 0x30
0x0001443549b2:  48c7472800000000      mov       qword ptr [rdi + 0x28], 0
0x0001443549ba:  c7470301031400        mov       dword ptr [rdi + 3], 0x140301
0x0001443549c1:  4c896f10              mov       qword ptr [rdi + 0x10], r13
0x0001443549c5:  48834328d0            add       qword ptr [rbx + 0x28], -0x30
0x0001443549ca:  660f1f440000          nop       word ptr [rax + rax]
0x0001443549d0:  488b4328              mov       rax, qword ptr [rbx + 0x28]
0x0001443549d4:  488d49f0              lea       rcx, [rcx - 0x10]
0x0001443549d8:  0f100401              movups    xmm0, xmmword ptr [rcx + rax]
0x0001443549dc:  0f11443930            movups    xmmword ptr [rcx + rdi + 0x30], xmm0
0x0001443549e1:  83ee01                sub       esi, 1
0x0001443549e4:  75ea                  jne       0x1443549d0
0x0001443549e6:  e90f050000            jmp       0x144354efa
0x0001443549eb:  41bcffffffff          mov       r12d, 0xffffffff
0x0001443549f1:  418d46ff              lea       eax, [r14 - 1]
0x0001443549f5:  418bce                mov       ecx, r14d
0x0001443549f8:  4183fcff              cmp       r12d, -1
0x0001443549fc:  4c8bc7                mov       r8, rdi
0x0001443549ff:  498bd5                mov       rdx, r13
0x000144354a02:  0f45c8                cmovne    ecx, eax
0x000144354a05:  4c63c9                movsxd    r9, ecx
0x000144354a08:  488d4dc0              lea       rcx, [rbp - 0x40]
0x000144354a0c:  e8ff0775fe            call      0x142aa5210
0x000144354a11:  488b55c0              mov       rdx, qword ptr [rbp - 0x40]
0x000144354a15:  4533c9                xor       r9d, r9d
0x000144354a18:  4c8b5dc8              mov       r11, qword ptr [rbp - 0x38]
0x000144354a1c:  33ff                  xor       edi, edi
0x000144354a1e:  4c03da                add       r11, rdx
0x000144354a21:  493bd3                cmp       rdx, r11
0x000144354a24:  7371                  jae       0x144354a97
0x000144354a26:  66660f1f840000000000  nop       word ptr [rax + rax]
0x000144354a30:  420fb60c2a            movzx     ecx, byte ptr [rdx + r13]
0x000144354a35:  4c8d05242f1a02        lea       r8, [rip + 0x21a2f24]
0x000144354a3c:  460fb61401            movzx     r10d, byte ptr [rcx + r8]
0x000144354a41:  448bc1                mov       r8d, ecx
0x000144354a44:  4585c9                test      r9d, r9d
0x000144354a47:  7410                  je        0x144354a59
0x000144354a49:  8bc7                  mov       eax, edi
0x000144354a4b:  4183e03f              and       r8d, 0x3f
0x000144354a4f:  c1e006                shl       eax, 6
0x000144354a52:  418bf8                mov       edi, r8d
0x000144354a55:  0bf8                  or        edi, eax
0x000144354a57:  eb0d                  jmp       0x144354a66
0x000144354a59:  bfff000000            mov       edi, 0xff
0x000144354a5e:  418bca                mov       ecx, r10d
0x000144354a61:  d3ff                  sar       edi, cl
0x000144354a63:  4123f8                and       edi, r8d
0x000144354a66:  418d4110              lea       eax, [r9 + 0x10]
0x000144354a6a:  c1e004                shl       eax, 4
0x000144354a6d:  488d0dec2e1a02        lea       rcx, [rip + 0x21a2eec]
0x000144354a74:  4103c2                add       eax, r10d
0x000144354a77:  440fb60c08            movzx     r9d, byte ptr [rax + rcx]
0x000144354a7c:  4183f901              cmp       r9d, 1
0x000144354a80:  0f840b050000          je        0x144354f91
0x000144354a86:  48ffc2                inc       rdx
0x000144354a89:  493bd3                cmp       rdx, r11
0x000144354a8c:  72a2                  jb        0x144354a30
0x000144354a8e:  4585c9                test      r9d, r9d
0x000144354a91:  0f85db040000          jne       0x144354f72
0x000144354a97:  4183fcff              cmp       r12d, -1
0x000144354a9b:  740e                  je        0x144354aab
0x000144354a9d:  418bd4                mov       edx, r12d
0x000144354aa0:  8bcf                  mov       ecx, edi
0x000144354aa2:  e8993377fe            call      0x142ac7e40
0x000144354aa7:  84c0                  test      al, al
0x000144354aa9:  7515                  jne       0x144354ac0
0x000144354aab:  448b75c0              mov       r14d, dword ptr [rbp - 0x40]
0x000144354aaf:  448be7                mov       r12d, edi
0x000144354ab2:  4585f6                test      r14d, r14d
0x000144354ab5:  7e09                  jle       0x144354ac0
0x000144354ab7:  488b7d40              mov       rdi, qword ptr [rbp + 0x40]
0x000144354abb:  e931ffffff            jmp       0x1443549f1
0x000144354ac0:  0fb64301              movzx     eax, byte ptr [rbx + 1]
0x000144354ac4:  a804                  test      al, 4
0x000144354ac6:  7415                  je        0x144354add
0x000144354ac8:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x000144354acc:  24fb                  and       al, 0xfb
0x000144354ace:  884301                mov       byte ptr [rbx + 1], al
0x000144354ad1:  488b4138              mov       rax, qword ptr [rcx + 0x38]
0x000144354ad5:  48894350              mov       qword ptr [rbx + 0x50], rax
0x000144354ad9:  48895938              mov       qword ptr [rcx + 0x38], rbx
0x000144354add:  488b5328              mov       rdx, qword ptr [rbx + 0x28]
0x000144354ae1:  488b4308              mov       rax, qword ptr [rbx + 8]
0x000144354ae5:  488d4a10              lea       rcx, [rdx + 0x10]
0x000144354ae9:  483b08                cmp       rcx, qword ptr [rax]
0x000144354aec:  765d                  jbe       0x144354b4b
0x000144354aee:  488bc2                mov       rax, rdx
0x000144354af1:  482b4310              sub       rax, qword ptr [rbx + 0x10]
0x000144354af5:  48c1f804              sar       rax, 4
0x000144354af9:  48ffc0                inc       rax
0x000144354afc:  483d401f0000          cmp       rax, 0x1f40
0x000144354b02:  0f8fa8040000          jg        0x144354fb0
0x000144354b08:  488b4330              mov       rax, qword ptr [rbx + 0x30]
0x000144354b0c:  482bc2                sub       rax, rdx
0x000144354b0f:  4883f810              cmp       rax, 0x10
0x000144354b13:  7f22                  jg        0x144354b37
0x000144354b15:  4c8d4530              lea       r8, [rbp + 0x30]
0x000144354b19:  c7453001000000        mov       dword ptr [rbp + 0x30], 1
0x000144354b20:  488d15797a30fe        lea       rdx, [rip - 0x1cf8587]
0x000144354b27:  488bcb                mov       rcx, rbx
0x000144354b2a:  e8e19e31fe            call      0x14266ea10
0x000144354b2f:  85c0                  test      eax, eax
0x000144354b31:  0f8579040000          jne       0x144354fb0
0x000144354b37:  488b4b08              mov       rcx, qword ptr [rbx + 8]
0x000144354b3b:  488b4328              mov       rax, qword ptr [rbx + 0x28]
0x000144354b3f:  4883c010              add       rax, 0x10
0x000144354b43:  483901                cmp       qword ptr [rcx], rax
0x000144354b46:  7303                  jae       0x144354b4b
0x000144354b48:  488901                mov       qword ptr [rcx], rax
0x000144354b4b:  488b4b28              mov       rcx, qword ptr [rbx + 0x28]
0x000144354b4f:  488d15f2561602        lea       rdx, [rip + 0x21656f2]
0x000144354b56:  48394b10              cmp       qword ptr [rbx + 0x10], rcx
0x000144354b5a:  480f425310            cmovb     rdx, qword ptr [rbx + 0x10]
0x000144354b5f:  0f1002                movups    xmm0, xmmword ptr [rdx]
0x000144354b62:  0f1101                movups    xmmword ptr [rcx], xmm0
0x000144354b65:  488b5328              mov       rdx, qword ptr [rbx + 0x28]
0x000144354b69:  488b4308              mov       rax, qword ptr [rbx + 8]
0x000144354b6d:  4883c210              add       rdx, 0x10
0x000144354b71:  48895328              mov       qword ptr [rbx + 0x28], rdx
0x000144354b75:  488d4a10              lea       rcx, [rdx + 0x10]
0x000144354b79:  483b08                cmp       rcx, qword ptr [rax]
0x000144354b7c:  765d                  jbe       0x144354bdb
0x000144354b7e:  488bc2                mov       rax, rdx
0x000144354b81:  482b4310              sub       rax, qword ptr [rbx + 0x10]
0x000144354b85:  48c1f804              sar       rax, 4
0x000144354b89:  48ffc0                inc       rax
0x000144354b8c:  483d401f0000          cmp       rax, 0x1f40
0x000144354b92:  0f8f18040000          jg        0x144354fb0
0x000144354b98:  488b4330              mov       rax, qword ptr [rbx + 0x30]
0x000144354b9c:  482bc2                sub       rax, rdx
0x000144354b9f:  4883f810              cmp       rax, 0x10
0x000144354ba3:  7f22                  jg        0x144354bc7
0x000144354ba5:  4c8d4530              lea       r8, [rbp + 0x30]
0x000144354ba9:  c7453001000000        mov       dword ptr [rbp + 0x30], 1
0x000144354bb0:  488d15e97930fe        lea       rdx, [rip - 0x1cf8617]
0x000144354bb7:  488bcb                mov       rcx, rbx
0x000144354bba:  e8519e31fe            call      0x14266ea10
0x000144354bbf:  85c0                  test      eax, eax
0x000144354bc1:  0f85e9030000          jne       0x144354fb0
0x000144354bc7:  488b4b08              mov       rcx, qword ptr [rbx + 8]
0x000144354bcb:  488b4328              mov       rax, qword ptr [rbx + 0x28]
0x000144354bcf:  4883c010              add       rax, 0x10
0x000144354bd3:  483901                cmp       qword ptr [rcx], rax
0x000144354bd6:  7303                  jae       0x144354bdb
0x000144354bd8:  488901                mov       qword ptr [rcx], rax
0x000144354bdb:  488b4328              mov       rax, qword ptr [rbx + 0x28]
0x000144354bdf:  66410f6ec6            movd      xmm0, r14d
0x000144354be4:  f30fe6c0              cvtdq2pd  xmm0, xmm0
0x000144354be8:  89700c                mov       dword ptr [rax + 0xc], esi
0x000144354beb:  f20f1100              movsd     qword ptr [rax], xmm0
0x000144354bef:  488b5328              mov       rdx, qword ptr [rbx + 0x28]
0x000144354bf3:  488b4308              mov       rax, qword ptr [rbx + 8]
0x000144354bf7:  4883c210              add       rdx, 0x10
0x000144354bfb:  48895328              mov       qword ptr [rbx + 0x28], rdx
0x000144354bff:  488d4a10              lea       rcx, [rdx + 0x10]
0x000144354c03:  483b08                cmp       rcx, qword ptr [rax]
0x000144354c06:  765d                  jbe       0x144354c65
0x000144354c08:  488bc2                mov       rax, rdx
0x000144354c0b:  482b4310              sub       rax, qword ptr [rbx + 0x10]
0x000144354c0f:  48c1f804              sar       rax, 4
0x000144354c13:  48ffc0                inc       rax
0x000144354c16:  483d401f0000          cmp       rax, 0x1f40
0x000144354c1c:  0f8f8e030000          jg        0x144354fb0
0x000144354c22:  488b4330              mov       rax, qword ptr [rbx + 0x30]
0x000144354c26:  482bc2                sub       rax, rdx
0x000144354c29:  4883f810              cmp       rax, 0x10
0x000144354c2d:  7f22                  jg        0x144354c51
0x000144354c2f:  4c8d4530              lea       r8, [rbp + 0x30]
0x000144354c33:  c7453001000000        mov       dword ptr [rbp + 0x30], 1
0x000144354c3a:  488d155f7930fe        lea       rdx, [rip - 0x1cf86a1]
0x000144354c41:  488bcb                mov       rcx, rbx
0x000144354c44:  e8c79d31fe            call      0x14266ea10
0x000144354c49:  85c0                  test      eax, eax
0x000144354c4b:  0f855f030000          jne       0x144354fb0
0x000144354c51:  488b4b08              mov       rcx, qword ptr [rbx + 8]
0x000144354c55:  488b4328              mov       rax, qword ptr [rbx + 0x28]
0x000144354c59:  4883c010              add       rax, 0x10
0x000144354c5d:  483901                cmp       qword ptr [rcx], rax
0x000144354c60:  7303                  jae       0x144354c65
0x000144354c62:  488901                mov       qword ptr [rcx], rax
0x000144354c65:  488b4328              mov       rax, qword ptr [rbx + 0x28]
0x000144354c69:  66410f6ec7            movd      xmm0, r15d
0x000144354c6e:  f30fe6c0              cvtdq2pd  xmm0, xmm0
0x000144354c72:  89700c                mov       dword ptr [rax + 0xc], esi
0x000144354c75:  f20f1100              movsd     qword ptr [rax], xmm0
0x000144354c79:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x000144354c7d:  4883432810            add       qword ptr [rbx + 0x28], 0x10
0x000144354c82:  488b4150              mov       rax, qword ptr [rcx + 0x50]
0x000144354c86:  48394158              cmp       qword ptr [rcx + 0x58], rax
0x000144354c8a:  720a                  jb        0x144354c96
0x000144354c8c:  b201                  mov       dl, 1
0x000144354c8e:  488bcb                mov       rcx, rbx
0x000144354c91:  e85aec32fe            call      0x1426838f0
0x000144354c96:  0fb64301              movzx     eax, byte ptr [rbx + 1]
0x000144354c9a:  a804                  test      al, 4
0x000144354c9c:  7415                  je        0x144354cb3
0x000144354c9e:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x000144354ca2:  24fb                  and       al, 0xfb
0x000144354ca4:  884301                mov       byte ptr [rbx + 1], al
0x000144354ca7:  488b4138              mov       rax, qword ptr [rcx + 0x38]
0x000144354cab:  48894350              mov       qword ptr [rbx + 0x50], rax
0x000144354caf:  48895938              mov       qword ptr [rcx + 0x38], rbx
0x000144354cb3:  4c8b4328              mov       r8, qword ptr [rbx + 0x28]
0x000144354cb7:  488b4308              mov       rax, qword ptr [rbx + 8]
0x000144354cbb:  498d4810              lea       rcx, [r8 + 0x10]
0x000144354cbf:  483b08                cmp       rcx, qword ptr [rax]
0x000144354cc2:  765d                  jbe       0x144354d21
0x000144354cc4:  498bc0                mov       rax, r8
0x000144354cc7:  482b4310              sub       rax, qword ptr [rbx + 0x10]
0x000144354ccb:  48c1f804              sar       rax, 4
0x000144354ccf:  48ffc0                inc       rax
0x000144354cd2:  483d401f0000          cmp       rax, 0x1f40
0x000144354cd8:  0f8fd2020000          jg        0x144354fb0
0x000144354cde:  488b4330              mov       rax, qword ptr [rbx + 0x30]
0x000144354ce2:  492bc0                sub       rax, r8
0x000144354ce5:  4883f810              cmp       rax, 0x10
0x000144354ce9:  7f22                  jg        0x144354d0d
0x000144354ceb:  4c8d4530              lea       r8, [rbp + 0x30]
0x000144354cef:  c7453001000000        mov       dword ptr [rbp + 0x30], 1
0x000144354cf6:  488d15a37830fe        lea       rdx, [rip - 0x1cf875d]
0x000144354cfd:  488bcb                mov       rcx, rbx
0x000144354d00:  e80b9d31fe            call      0x14266ea10
0x000144354d05:  85c0                  test      eax, eax
0x000144354d07:  0f85a3020000          jne       0x144354fb0
0x000144354d0d:  488b4b08              mov       rcx, qword ptr [rbx + 8]
0x000144354d11:  488b4328              mov       rax, qword ptr [rbx + 0x28]
0x000144354d15:  4883c010              add       rax, 0x10
0x000144354d19:  483901                cmp       qword ptr [rcx], rax
0x000144354d1c:  7303                  jae       0x144354d21
0x000144354d1e:  488901                mov       qword ptr [rcx], rax
0x000144354d21:  488b4308              mov       rax, qword ptr [rbx + 8]
0x000144354d25:  483b4370              cmp       rax, qword ptr [rbx + 0x70]
0x000144354d29:  7506                  jne       0x144354d31
0x000144354d2b:  4c8b6b60              mov       r13, qword ptr [rbx + 0x60]
0x000144354d2f:  eb0b                  jmp       0x144354d3c
0x000144354d31:  488b4008              mov       rax, qword ptr [rax + 8]
0x000144354d35:  488b08                mov       rcx, qword ptr [rax]
0x000144354d38:  4c8b6910              mov       r13, qword ptr [rcx + 0x10]
0x000144354d3c:  480fbe055cfda003      movsx     rax, byte ptr [rip + 0x3a0fd5c]
0x000144354d44:  440fb67b04            movzx     r15d, byte ptr [rbx + 4]
0x000144354d49:  4c8b7318              mov       r14, qword ptr [rbx + 0x18]
0x000144354d4d:  85c0                  test      eax, eax
0x000144354d4f:  0f888a000000          js        0x144354ddf
0x000144354d55:  498b94c6a0000000      mov       rdx, qword ptr [r14 + rax*8 + 0xa0]
0x000144354d5d:  4c8be0                mov       r12, rax
0x000144354d60:  4885d2                test      rdx, rdx
0x000144354d63:  751e                  jne       0x144354d83
0x000144354d65:  88542420              mov       byte ptr [rsp + 0x20], dl
0x000144354d69:  4d8d4668              lea       r8, [r14 + 0x68]
0x000144354d6d:  498d96a0000000        lea       rdx, [r14 + 0xa0]
0x000144354d74:  440fb6c8              movzx     r9d, al
0x000144354d78:  488bcb                mov       rcx, rbx
0x000144354d7b:  e8308334fe            call      0x14269d0b0
0x000144354d80:  488bd0                mov       rdx, rax
0x000144354d83:  4c634230              movsxd    r8, dword ptr [rdx + 0x30]
0x000144354d87:  4585c0                test      r8d, r8d
0x000144354d8a:  7811                  js        0x144354d9d
0x000144354d8c:  488d7a40              lea       rdi, [rdx + 0x40]
0x000144354d90:  4903f8                add       rdi, r8
0x000144354d93:  442b4224              sub       r8d, dword ptr [rdx + 0x24]
0x000144354d97:  44894230              mov       dword ptr [rdx + 0x30], r8d
0x000144354d9b:  eb0c                  jmp       0x144354da9
0x000144354d9d:  488b7a28              mov       rdi, qword ptr [rdx + 0x28]
0x000144354da1:  488b4708              mov       rax, qword ptr [rdi + 8]
0x000144354da5:  48894228              mov       qword ptr [rdx + 0x28], rax
0x000144354da9:  ff4234                inc       dword ptr [rdx + 0x34]
0x000144354dac:  48837a2800            cmp       qword ptr [rdx + 0x28], 0
0x000144354db1:  7527                  jne       0x144354dda
0x000144354db3:  4585c0                test      r8d, r8d
0x000144354db6:  7922                  jns       0x144354dda
0x000144354db8:  488b4218              mov       rax, qword ptr [rdx + 0x18]
0x000144354dbc:  4b8984e6a0000000      mov       qword ptr [r14 + r12*8 + 0xa0], rax
0x000144354dc4:  4533e4                xor       r12d, r12d
0x000144354dc7:  488b4218              mov       rax, qword ptr [rdx + 0x18]
0x000144354dcb:  4885c0                test      rax, rax
0x000144354dce:  7404                  je        0x144354dd4
0x000144354dd0:  4c896010              mov       qword ptr [rax + 0x10], r12
0x000144354dd4:  4c896218              mov       qword ptr [rdx + 0x18], r12
0x000144354dd8:  eb7a                  jmp       0x144354e54
0x000144354dda:  4533e4                xor       r12d, r12d
0x000144354ddd:  eb75                  jmp       0x144354e54
0x000144354ddf:  498b4e10              mov       rcx, qword ptr [r14 + 0x10]
0x000144354de3:  498d7e68              lea       rdi, [r14 + 0x68]
0x000144354de7:  498b4608              mov       rax, qword ptr [r14 + 8]
0x000144354deb:  41b9a0000000          mov       r9d, 0xa0
0x000144354df1:  4533c0                xor       r8d, r8d
0x000144354df4:  33d2                  xor       edx, edx
0x000144354df6:  ff153cafde01          call      qword ptr [rip + 0x1deaf3c]
0x000144354dfc:  488bc8                mov       rcx, rax
0x000144354dff:  4885c0                test      rax, rax
0x000144354e02:  0f842b010000          je        0x144354f33
0x000144354e08:  4533e4                xor       r12d, r12d
0x000144354e0b:  c74020a0000000        mov       dword ptr [rax + 0x20], 0xa0
0x000144354e12:  4c896010              mov       qword ptr [rax + 0x10], r12
0x000144354e16:  4c896018              mov       qword ptr [rax + 0x18], r12
0x000144354e1a:  4c8920                mov       qword ptr [rax], r12
0x000144354e1d:  4c896008              mov       qword ptr [rax + 8], r12
0x000144354e21:  c7402460000000        mov       dword ptr [rax + 0x24], 0x60
0x000144354e28:  4c896028              mov       qword ptr [rax + 0x28], r12
0x000144354e2c:  4c896030              mov       qword ptr [rax + 0x30], r12
0x000144354e30:  4885ff                test      rdi, rdi
0x000144354e33:  7412                  je        0x144354e47
0x000144354e35:  488b07                mov       rax, qword ptr [rdi]
0x000144354e38:  48894108              mov       qword ptr [rcx + 8], rax
0x000144354e3c:  4885c0                test      rax, rax
0x000144354e3f:  7403                  je        0x144354e44
0x000144354e41:  488908                mov       qword ptr [rax], rcx
0x000144354e44:  48890f                mov       qword ptr [rdi], rcx
0x000144354e47:  8b4124                mov       eax, dword ptr [rcx + 0x24]
0x000144354e4a:  488d7940              lea       rdi, [rcx + 0x40]
0x000144354e4e:  294130                sub       dword ptr [rcx + 0x30], eax
0x000144354e51:  ff4134                inc       dword ptr [rcx + 0x34]
0x000144354e54:  4885ff                test      rdi, rdi
0x000144354e57:  0f84d6000000          je        0x144354f33
0x000144354e5d:  4983465860            add       qword ptr [r14 + 0x58], 0x60
0x000144354e62:  410fb6c7              movzx     eax, r15b
0x000144354e66:  498384c6b02d000060    add       qword ptr [r14 + rax*8 + 0x2db0], 0x60
0x000144354e6f:  498b8660060000        mov       rax, qword ptr [r14 + 0x660]
0x000144354e76:  4885c0                test      rax, rax
0x000144354e79:  7427                  je        0x144354ea2
0x000144354e7b:  4489642430            mov       dword ptr [rsp + 0x30], r12d
0x000144354e80:  41b960000000          mov       r9d, 0x60
0x000144354e86:  c744242808000000      mov       dword ptr [rsp + 0x28], 8
0x000144354e8e:  4533c0                xor       r8d, r8d
0x000144354e91:  488bd7                mov       rdx, rdi
0x000144354e94:  44887c2420            mov       byte ptr [rsp + 0x20], r15b
0x000144354e99:  488bcb                mov       rcx, rbx
0x000144354e9c:  ff1596aede01          call      qword ptr [rip + 0x1deae96]
0x000144354ea2:  488b4318              mov       rax, qword ptr [rbx + 0x18]
0x000144354ea6:  0fb608                movzx     ecx, byte ptr [rax]
0x000144354ea9:  4022ce                and       cl, sil
0x000144354eac:  c60708                mov       byte ptr [rdi], 8
0x000144354eaf:  884f01                mov       byte ptr [rdi + 1], cl
0x000144354eb2:  488d0da7eeffff        lea       rcx, [rip - 0x1159]
0x000144354eb9:  0fb64304              movzx     eax, byte ptr [rbx + 4]
0x000144354ebd:  884702                mov       byte ptr [rdi + 2], al
0x000144354ec0:  488d4720              lea       rax, [rdi + 0x20]
0x000144354ec4:  488900                mov       qword ptr [rax], rax
0x000144354ec7:  48894f18              mov       qword ptr [rdi + 0x18], rcx
0x000144354ecb:  b930000000            mov       ecx, 0x30
0x000144354ed0:  4c896728              mov       qword ptr [rdi + 0x28], r12
0x000144354ed4:  c7470301031400        mov       dword ptr [rdi + 3], 0x140301
0x000144354edb:  4c896f10              mov       qword ptr [rdi + 0x10], r13
0x000144354edf:  48834328d0            add       qword ptr [rbx + 0x28], -0x30
0x000144354ee4:  488b4328              mov       rax, qword ptr [rbx + 0x28]
0x000144354ee8:  488d49f0              lea       rcx, [rcx - 0x10]
0x000144354eec:  0f100408              movups    xmm0, xmmword ptr [rax + rcx]
0x000144354ef0:  0f11440f30            movups    xmmword ptr [rdi + rcx + 0x30], xmm0
0x000144354ef5:  83ee01                sub       esi, 1
0x000144354ef8:  75ea                  jne       0x144354ee4
0x000144354efa:  488b4328              mov       rax, qword ptr [rbx + 0x28]
0x000144354efe:  4c8b7c2470            mov       r15, qword ptr [rsp + 0x70]
0x000144354f03:  488bb424c8000000      mov       rsi, qword ptr [rsp + 0xc8]
0x000144354f0b:  4c8b742478            mov       r14, qword ptr [rsp + 0x78]
0x000144354f10:  488938                mov       qword ptr [rax], rdi
0x000144354f13:  c7400c08000000        mov       dword ptr [rax + 0xc], 8
0x000144354f1a:  b801000000            mov       eax, 1
0x000144354f1f:  4883432810            add       qword ptr [rbx + 0x28], 0x10
0x000144354f24:  4881c480000000        add       rsp, 0x80
0x000144354f2b:  415d                  pop       r13
0x000144354f2d:  415c                  pop       r12
0x000144354f2f:  5f                    pop       rdi
0x000144354f30:  5b                    pop       rbx
0x000144354f31:  5d                    pop       rbp
0x000144354f32:  c3                    ret       
0x000144354f33:  ba04000000            mov       edx, 4
0x000144354f38:  488bcb                mov       rcx, rbx
0x000144354f3b:  e8009b31fe            call      0x14266ea40
0x000144354f40:  cc                    int3      
0x000144354f41:  ba01000000            mov       edx, 1
0x000144354f46:  488bcb                mov       rcx, rbx
0x000144354f49:  448d4205              lea       r8d, [rdx + 5]
0x000144354f4d:  e85eee30fe            call      0x142663db0
0x000144354f52:  cc                    int3      
0x000144354f53:  ba02000000            mov       edx, 2
0x000144354f58:  448bc6                mov       r8d, esi
0x000144354f5b:  488bcb                mov       rcx, rbx
0x000144354f5e:  e84dee30fe            call      0x142663db0
0x000144354f63:  cc                    int3      
0x000144354f64:  448bc6                mov       r8d, esi
0x000144354f67:  8bd6                  mov       edx, esi
0x000144354f69:  488bcb                mov       rcx, rbx
0x000144354f6c:  e83fee30fe            call      0x142663db0
0x000144354f71:  cc                    int3      
0x000144354f72:  488d053475e602        lea       rax, [rip + 0x2e67534]
0x000144354f79:  488bcb                mov       rcx, rbx
0x000144354f7c:  48894530              mov       qword ptr [rbp + 0x30], rax
0x000144354f80:  488b5530              mov       rdx, qword ptr [rbp + 0x30]
0x000144354f84:  488d158dccd202        lea       rdx, [rip + 0x2d2cc8d]
0x000144354f8b:  e840f930fe            call      0x1426648d0
0x000144354f90:  cc                    int3      
0x000144354f91:  488d052c13e602        lea       rax, [rip + 0x2e6132c]
0x000144354f98:  488bcb                mov       rcx, rbx
0x000144354f9b:  48894530              mov       qword ptr [rbp + 0x30], rax
0x000144354f9f:  488b5530              mov       rdx, qword ptr [rbp + 0x30]
0x000144354fa3:  488d156eccd202        lea       rdx, [rip + 0x2d2cc6e]
0x000144354faa:  e821f930fe            call      0x1426648d0
0x000144354faf:  cc                    int3      
0x000144354fb0:  488d15d166bc02        lea       rdx, [rip + 0x2bc66d1]
0x000144354fb7:  488bcb                mov       rcx, rbx
0x000144354fba:  e8e11834fe            call      0x1426968a0
0x000144354fbf:  488bcb                mov       rcx, rbx
0x000144354fc2:  e8999e30fe            call      0x14265ee60
0x000144354fc7:  cc                    int3      
0x000144354fc8:  cc                    int3      
0x000144354fc9:  cc                    int3      
0x000144354fca:  cc                    int3      
0x000144354fcb:  cc                    int3      
0x000144354fcc:  cc                    int3      
0x000144354fcd:  cc                    int3      
0x000144354fce:  cc                    int3      
0x000144354fcf:  cc                    int3      
0x000144354fd0:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x000144354fd5:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x000144354fda:  48897c2420            mov       qword ptr [rsp + 0x20], rdi
0x000144354fdf:  55                    push      rbp
0x000144354fe0:  4154                  push      r12
0x000144354fe2:  4155                  push      r13
0x000144354fe4:  4156                  push      r14
0x000144354fe6:  4157                  push      r15
0x000144354fe8:  488d6c24c9            lea       rbp, [rsp - 0x37]
0x000144354fed:  4881eca0000000        sub       rsp, 0xa0
0x000144354ff4:  488b05f5e69b03        mov       rax, qword ptr [rip + 0x39be6f5]
0x000144354ffb:  4833c4                xor       rax, rsp
0x000144354ffe:  48894527              mov       qword ptr [rbp + 0x27], rax
0x000144355002:  488bf1                mov       rsi, rcx
0x000144355005:  488b4110              mov       rax, qword ptr [rcx + 0x10]
0x000144355009:  488d1d38521602        lea       rbx, [rip + 0x2165238]
0x000144355010:  488bd3                mov       rdx, rbx
0x000144355013:  483b4128              cmp       rax, qword ptr [rcx + 0x28]
0x000144355017:  480f42d0              cmovb     rdx, rax
0x00014435501b:  837a0c06              cmp       dword ptr [rdx + 0xc], 6
0x00014435501f:  7454                  je        0x144355075
0x000144355021:  0fb64101              movzx     eax, byte ptr [rcx + 1]
0x000144355025:  a804                  test      al, 4
0x000144355027:  7415                  je        0x14435503e
0x000144355029:  488b4918              mov       rcx, qword ptr [rcx + 0x18]
0x00014435502d:  24fb                  and       al, 0xfb
0x00014435502f:  884601                mov       byte ptr [rsi + 1], al
0x000144355032:  488b4138              mov       rax, qword ptr [rcx + 0x38]
0x000144355036:  48894650              mov       qword ptr [rsi + 0x50], rax
0x00014435503a:  48897138              mov       qword ptr [rcx + 0x38], rsi
0x00014435503e:  488bce                mov       rcx, rsi
0x000144355041:  e86ae631fe            call      0x1426736b0
0x000144355046:  85c0                  test      eax, eax
0x000144355048:  0f849c090000          je        0x1443559ea
0x00014435504e:  488b4e18              mov       rcx, qword ptr [rsi + 0x18]
0x000144355052:  488b4150              mov       rax, qword ptr [rcx + 0x50]
0x000144355056:  48394158              cmp       qword ptr [rcx + 0x58], rax
0x00014435505a:  720a                  jb        0x144355066
0x00014435505c:  b201                  mov       dl, 1
0x00014435505e:  488bce                mov       rcx, rsi
0x000144355061:  e88ae832fe            call      0x1426838f0
0x000144355066:  488b4610              mov       rax, qword ptr [rsi + 0x10]
0x00014435506a:  488bd3                mov       rdx, rbx
0x00014435506d:  483b4628              cmp       rax, qword ptr [rsi + 0x28]
0x000144355071:  480f42d0              cmovb     rdx, rax
0x000144355075:  488b02                mov       rax, qword ptr [rdx]
0x000144355078:  448b6014              mov       r12d, dword ptr [rax + 0x14]
0x00014435507c:  488d4818              lea       rcx, [rax + 0x18]
0x000144355080:  48894de7              mov       qword ptr [rbp - 0x19], rcx
0x000144355084:  4885c9                test      rcx, rcx
0x000144355087:  0f845d090000          je        0x1443559ea
0x00014435508d:  4533f6                xor       r14d, r14d
0x000144355090:  4c897507              mov       qword ptr [rbp + 7], r14
0x000144355094:  458bfe                mov       r15d, r14d
0x000144355097:  4c897517              mov       qword ptr [rbp + 0x17], r14
0x00014435509b:  48c7451f0f000000      mov       qword ptr [rbp + 0x1f], 0xf
0x0001443550a3:  44887507              mov       byte ptr [rbp + 7], r14b
0x0001443550a7:  4c8d1d52afcafb        lea       r11, [rip - 0x43550ae]
0x0001443550ae:  4983fc0f              cmp       r12, 0xf
0x0001443550b2:  7456                  je        0x14435510a
0x0001443550b4:  764b                  jbe       0x144355101
0x0001443550b6:  48b8ffffffffffffff7f  movabs    rax, 0x7fffffffffffffff
0x0001443550c0:  4c3be0                cmp       r12, rax
0x0001443550c3:  0f8733090000          ja        0x1443559fc
0x0001443550c9:  418bdc                mov       ebx, r12d
0x0001443550cc:  4883cb0f              or        rbx, 0xf
0x0001443550d0:  b816000000            mov       eax, 0x16
0x0001443550d5:  483bd8                cmp       rbx, rax
0x0001443550d8:  480f42d8              cmovb     rbx, rax
0x0001443550dc:  488d4b01              lea       rcx, [rbx + 1]
0x0001443550e0:  e8eb4f49fc            call      0x1407ea0d0
0x0001443550e5:  48895d1f              mov       qword ptr [rbp + 0x1f], rbx
0x0001443550e9:  448830                mov       byte ptr [rax], r14b
0x0001443550ec:  48894507              mov       qword ptr [rbp + 7], rax
0x0001443550f0:  4c897517              mov       qword ptr [rbp + 0x17], r14
0x0001443550f4:  488b4de7              mov       rcx, qword ptr [rbp - 0x19]
0x0001443550f8:  4c8d1d01afcafb        lea       r11, [rip - 0x43550ff]
0x0001443550ff:  eb09                  jmp       0x14435510a
0x000144355101:  4d85e4                test      r12, r12
0x000144355104:  0f8457030000          je        0x144355461
0x00014435510a:  498bc6                mov       rax, r14
0x00014435510d:  bbffffffff            mov       ebx, 0xffffffff
0x000144355112:  458bee                mov       r13d, r14d
0x000144355115:  418bfe                mov       edi, r14d
0x000144355118:  458bce                mov       r9d, r14d
0x00014435511b:  448975e3              mov       dword ptr [rbp - 0x1d], r14d
0x00014435511f:  4c8d15caab2dfe        lea       r10, [rip - 0x1d25436]
0x000144355126:  66660f1f840000000000  nop       word ptr [rax + rax]
0x000144355130:  0fb60c08              movzx     ecx, byte ptr [rax + rcx]
0x000144355134:  460fb6841960794f06    movzx     r8d, byte ptr [rcx + r11 + 0x64f7960]
0x00014435513d:  8bd1                  mov       edx, ecx
0x00014435513f:  4585ed                test      r13d, r13d
0x000144355142:  740e                  je        0x144355152
0x000144355144:  83e23f                and       edx, 0x3f
0x000144355147:  8bc7                  mov       eax, edi
0x000144355149:  c1e006                shl       eax, 6
0x00014435514c:  8bfa                  mov       edi, edx
0x00014435514e:  0bf8                  or        edi, eax
0x000144355150:  eb0c                  jmp       0x14435515e
0x000144355152:  bfff000000            mov       edi, 0xff
0x000144355157:  418bc8                mov       ecx, r8d
0x00014435515a:  d3ff                  sar       edi, cl
0x00014435515c:  23fa                  and       edi, edx
0x00014435515e:  418d4510              lea       eax, [r13 + 0x10]
0x000144355162:  c1e004                shl       eax, 4
0x000144355165:  4103c0                add       eax, r8d
0x000144355168:  460fb6ac1860794f06    movzx     r13d, byte ptr [rax + r11 + 0x64f7960]
0x000144355171:  4183fd01              cmp       r13d, 1
0x000144355175:  0f8450080000          je        0x1443559cb
0x00014435517b:  4585ed                test      r13d, r13d
0x00014435517e:  0f85ee010000          jne       0x144355372
0x000144355184:  83fbff                cmp       ebx, -1
0x000144355187:  0f84e3010000          je        0x144355370
0x00014435518d:  8d830054ffff          lea       eax, [rbx - 0xac00]
0x000144355193:  3da32b0000            cmp       eax, 0x2ba3
0x000144355198:  771a                  ja        0x1443551b4
0x00014435519a:  8d8759eeffff          lea       eax, [rdi - 0x11a7]
0x0001443551a0:  83f81b                cmp       eax, 0x1b
0x0001443551a3:  770f                  ja        0x1443551b4
0x0001443551a5:  8d8359eeffff          lea       eax, [rbx - 0x11a7]
0x0001443551ab:  03c7                  add       eax, edi
0x0001443551ad:  8bd8                  mov       ebx, eax
0x0001443551af:  e9be010000            jmp       0x144355372
0x0001443551b4:  8d8300efffff          lea       eax, [rbx - 0x1100]
0x0001443551ba:  83f812                cmp       eax, 0x12
0x0001443551bd:  771f                  ja        0x1443551de
0x0001443551bf:  8d879feeffff          lea       eax, [rdi - 0x1161]
0x0001443551c5:  83f814                cmp       eax, 0x14
0x0001443551c8:  7714                  ja        0x1443551de
0x0001443551ca:  6bc315                imul      eax, ebx, 0x15
0x0001443551cd:  03c7                  add       eax, edi
0x0001443551cf:  6bc01c                imul      eax, eax, 0x1c
0x0001443551d2:  2d9c462800            sub       eax, 0x28469c
0x0001443551d7:  8bd8                  mov       ebx, eax
0x0001443551d9:  e994010000            jmp       0x144355372
0x0001443551de:  448975fb              mov       dword ptr [rbp - 5], r14d
0x0001443551e2:  895df7                mov       dword ptr [rbp - 9], ebx
0x0001443551e5:  4c89542420            mov       qword ptr [rsp + 0x20], r10
0x0001443551ea:  41b908000000          mov       r9d, 8
0x0001443551f0:  41b8d3000000          mov       r8d, 0xd3
0x0001443551f6:  488d1533821602        lea       rdx, [rip + 0x2168233]
0x0001443551fd:  488d4df7              lea       rcx, [rbp - 9]
0x000144355201:  e8f25e8101            call      0x145b6b0f8
0x000144355206:  4885c0                test      rax, rax
0x000144355209:  740d                  je        0x144355218
0x00014435520b:  440fbf7806            movsx     r15d, word ptr [rax + 6]
0x000144355210:  442b38                sub       r15d, dword ptr [rax]
0x000144355213:  4403fb                add       r15d, ebx
0x000144355216:  eb06                  jmp       0x14435521e
0x000144355218:  41bfffffffff          mov       r15d, 0xffffffff
0x00014435521e:  44897503              mov       dword ptr [rbp + 3], r14d
0x000144355222:  897dff                mov       dword ptr [rbp - 1], edi
0x000144355225:  488d05c4aa2dfe        lea       rax, [rip - 0x1d2553c]
0x00014435522c:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000144355231:  41b908000000          mov       r9d, 8
0x000144355237:  458d4120              lea       r8d, [r9 + 0x20]
0x00014435523b:  488d15ce161802        lea       rdx, [rip + 0x21816ce]
0x000144355242:  488d4dff              lea       rcx, [rbp - 1]
0x000144355246:  e8ad5e8101            call      0x145b6b0f8
0x00014435524b:  4885c0                test      rax, rax
0x00014435524e:  740a                  je        0x14435525a
0x000144355250:  0fbf4806              movsx     ecx, word ptr [rax + 6]
0x000144355254:  2b08                  sub       ecx, dword ptr [rax]
0x000144355256:  03cf                  add       ecx, edi
0x000144355258:  eb05                  jmp       0x14435525f
0x00014435525a:  b9ffffffff            mov       ecx, 0xffffffff
0x00014435525f:  4585ff                test      r15d, r15d
0x000144355262:  7852                  js        0x1443552b6
0x000144355264:  85c9                  test      ecx, ecx
0x000144355266:  784e                  js        0x1443552b6
0x000144355268:  416bd73e              imul      edx, r15d, 0x3e
0x00014435526c:  03d1                  add       edx, ecx
0x00014435526e:  4863c2                movsxd    rax, edx
0x000144355271:  48c1f803              sar       rax, 3
0x000144355275:  4c8d1d84adcafb        lea       r11, [rip - 0x435527c]
0x00014435527c:  410fb78c4320524d06    movzx     ecx, word ptr [r11 + rax*2 + 0x64d5220]
0x000144355285:  8bc2                  mov       eax, edx
0x000144355287:  d1f8                  sar       eax, 1
0x000144355289:  83e003                and       eax, 3
0x00014435528c:  8d0488                lea       eax, [rax + rcx*4]
0x00014435528f:  410fb7844340534c06    movzx     eax, word ptr [r11 + rax*2 + 0x64c5340]
0x000144355298:  03c0                  add       eax, eax
0x00014435529a:  83e201                and       edx, 1
0x00014435529d:  03c2                  add       eax, edx
0x00014435529f:  418b8483106c4c06      mov       eax, dword ptr [r11 + rax*4 + 0x64c6c10]
0x0001443552a7:  85c0                  test      eax, eax
0x0001443552a9:  740b                  je        0x1443552b6
0x0001443552ab:  448b4de3              mov       r9d, dword ptr [rbp - 0x1d]
0x0001443552af:  8bd8                  mov       ebx, eax
0x0001443552b1:  e9bc000000            jmp       0x144355372
0x0001443552b6:  83fb7f                cmp       ebx, 0x7f
0x0001443552b9:  770e                  ja        0x1443552c9
0x0001443552bb:  885dd7                mov       byte ptr [rbp - 0x29], bl
0x0001443552be:  41b801000000          mov       r8d, 1
0x0001443552c4:  e996000000            jmp       0x14435535f
0x0001443552c9:  81fbff070000          cmp       ebx, 0x7ff
0x0001443552cf:  771d                  ja        0x1443552ee
0x0001443552d1:  8bc3                  mov       eax, ebx
0x0001443552d3:  c1e806                shr       eax, 6
0x0001443552d6:  241f                  and       al, 0x1f
0x0001443552d8:  0cc0                  or        al, 0xc0
0x0001443552da:  8845d7                mov       byte ptr [rbp - 0x29], al
0x0001443552dd:  80e33f                and       bl, 0x3f
0x0001443552e0:  80cb80                or        bl, 0x80
0x0001443552e3:  885dd8                mov       byte ptr [rbp - 0x28], bl
0x0001443552e6:  41b802000000          mov       r8d, 2
0x0001443552ec:  eb71                  jmp       0x14435535f
0x0001443552ee:  81fbffff0000          cmp       ebx, 0xffff
0x0001443552f4:  7729                  ja        0x14435531f
0x0001443552f6:  8bc3                  mov       eax, ebx
0x0001443552f8:  c1e80c                shr       eax, 0xc
0x0001443552fb:  240f                  and       al, 0xf
0x0001443552fd:  0ce0                  or        al, 0xe0
0x0001443552ff:  8845d7                mov       byte ptr [rbp - 0x29], al
0x000144355302:  8bc3                  mov       eax, ebx
0x000144355304:  c1e806                shr       eax, 6
0x000144355307:  243f                  and       al, 0x3f
0x000144355309:  0c80                  or        al, 0x80
0x00014435530b:  8845d8                mov       byte ptr [rbp - 0x28], al
0x00014435530e:  80e33f                and       bl, 0x3f
0x000144355311:  80cb80                or        bl, 0x80
0x000144355314:  885dd9                mov       byte ptr [rbp - 0x27], bl
0x000144355317:  41b803000000          mov       r8d, 3
0x00014435531d:  eb40                  jmp       0x14435535f
0x00014435531f:  81fbffff1000          cmp       ebx, 0x10ffff
0x000144355325:  7735                  ja        0x14435535c
0x000144355327:  8bc3                  mov       eax, ebx
0x000144355329:  c1e812                shr       eax, 0x12
0x00014435532c:  2407                  and       al, 7
0x00014435532e:  0cf0                  or        al, 0xf0
0x000144355330:  8845d7                mov       byte ptr [rbp - 0x29], al
0x000144355333:  8bc3                  mov       eax, ebx
0x000144355335:  c1e80c                shr       eax, 0xc
0x000144355338:  243f                  and       al, 0x3f
0x00014435533a:  0c80                  or        al, 0x80
0x00014435533c:  8845d8                mov       byte ptr [rbp - 0x28], al
0x00014435533f:  8bc3                  mov       eax, ebx
0x000144355341:  c1e806                shr       eax, 6
0x000144355344:  243f                  and       al, 0x3f
0x000144355346:  0c80                  or        al, 0x80
0x000144355348:  8845d9                mov       byte ptr [rbp - 0x27], al
0x00014435534b:  80e33f                and       bl, 0x3f
0x00014435534e:  80cb80                or        bl, 0x80
0x000144355351:  885dda                mov       byte ptr [rbp - 0x26], bl
0x000144355354:  41b804000000          mov       r8d, 4
0x00014435535a:  eb03                  jmp       0x14435535f
0x00014435535c:  4d8bc6                mov       r8, r14
0x00014435535f:  488d55d7              lea       rdx, [rbp - 0x29]
0x000144355363:  488d4d07              lea       rcx, [rbp + 7]
0x000144355367:  e814e848fc            call      0x1407e3b80
0x00014435536c:  448b4de3              mov       r9d, dword ptr [rbp - 0x1d]
0x000144355370:  8bdf                  mov       ebx, edi
0x000144355372:  41ffc1                inc       r9d
0x000144355375:  44894de3              mov       dword ptr [rbp - 0x1d], r9d
0x000144355379:  418bc1                mov       eax, r9d
0x00014435537c:  493bc4                cmp       rax, r12
0x00014435537f:  488b4de7              mov       rcx, qword ptr [rbp - 0x19]
0x000144355383:  4c8d1566a92dfe        lea       r10, [rip - 0x1d2569a]
0x00014435538a:  4c8d1d6faccafb        lea       r11, [rip - 0x4355391]
0x000144355391:  0f8299fdffff          jb        0x144355130
0x000144355397:  4585ed                test      r13d, r13d
0x00014435539a:  0f8562060000          jne       0x144355a02
0x0001443553a0:  83fbff                cmp       ebx, -1
0x0001443553a3:  0f84b4000000          je        0x14435545d
0x0001443553a9:  83fb7f                cmp       ebx, 0x7f
0x0001443553ac:  770c                  ja        0x1443553ba
0x0001443553ae:  885dd7                mov       byte ptr [rbp - 0x29], bl
0x0001443553b1:  418d4501              lea       eax, [r13 + 1]
0x0001443553b5:  e993000000            jmp       0x14435544d
0x0001443553ba:  81fbff070000          cmp       ebx, 0x7ff
0x0001443553c0:  771c                  ja        0x1443553de
0x0001443553c2:  8bc3                  mov       eax, ebx
0x0001443553c4:  c1e806                shr       eax, 6
0x0001443553c7:  241f                  and       al, 0x1f
0x0001443553c9:  0cc0                  or        al, 0xc0
0x0001443553cb:  8845d7                mov       byte ptr [rbp - 0x29], al
0x0001443553ce:  80e33f                and       bl, 0x3f
0x0001443553d1:  80cb80                or        bl, 0x80
0x0001443553d4:  885dd8                mov       byte ptr [rbp - 0x28], bl
0x0001443553d7:  b802000000            mov       eax, 2
0x0001443553dc:  eb6f                  jmp       0x14435544d
0x0001443553de:  81fbffff0000          cmp       ebx, 0xffff
0x0001443553e4:  7728                  ja        0x14435540e
0x0001443553e6:  8bc3                  mov       eax, ebx
0x0001443553e8:  c1e80c                shr       eax, 0xc
0x0001443553eb:  240f                  and       al, 0xf
0x0001443553ed:  0ce0                  or        al, 0xe0
0x0001443553ef:  8845d7                mov       byte ptr [rbp - 0x29], al
0x0001443553f2:  8bc3                  mov       eax, ebx
0x0001443553f4:  c1e806                shr       eax, 6
0x0001443553f7:  243f                  and       al, 0x3f
0x0001443553f9:  0c80                  or        al, 0x80
0x0001443553fb:  8845d8                mov       byte ptr [rbp - 0x28], al
0x0001443553fe:  80e33f                and       bl, 0x3f
0x000144355401:  80cb80                or        bl, 0x80
0x000144355404:  885dd9                mov       byte ptr [rbp - 0x27], bl
0x000144355407:  b803000000            mov       eax, 3
0x00014435540c:  eb3f                  jmp       0x14435544d
0x00014435540e:  81fbffff1000          cmp       ebx, 0x10ffff
0x000144355414:  7734                  ja        0x14435544a
0x000144355416:  8bc3                  mov       eax, ebx
0x000144355418:  c1e812                shr       eax, 0x12
0x00014435541b:  2407                  and       al, 7
0x00014435541d:  0cf0                  or        al, 0xf0
0x00014435541f:  8845d7                mov       byte ptr [rbp - 0x29], al
0x000144355422:  8bc3                  mov       eax, ebx
0x000144355424:  c1e80c                shr       eax, 0xc
0x000144355427:  243f                  and       al, 0x3f
0x000144355429:  0c80                  or        al, 0x80
0x00014435542b:  8845d8                mov       byte ptr [rbp - 0x28], al
0x00014435542e:  8bc3                  mov       eax, ebx
0x000144355430:  c1e806                shr       eax, 6
0x000144355433:  243f                  and       al, 0x3f
0x000144355435:  0c80                  or        al, 0x80
0x000144355437:  8845d9                mov       byte ptr [rbp - 0x27], al
0x00014435543a:  80e33f                and       bl, 0x3f
0x00014435543d:  80cb80                or        bl, 0x80
0x000144355440:  885dda                mov       byte ptr [rbp - 0x26], bl
0x000144355443:  b804000000            mov       eax, 4
0x000144355448:  eb03                  jmp       0x14435544d
0x00014435544a:  498bc6                mov       rax, r14
0x00014435544d:  4c8bc0                mov       r8, rax
0x000144355450:  488d55d7              lea       rdx, [rbp - 0x29]
0x000144355454:  488d4d07              lea       rcx, [rbp + 7]
0x000144355458:  e823e748fc            call      0x1407e3b80
0x00014435545d:  4c8b7d17              mov       r15, qword ptr [rbp + 0x17]
0x000144355461:  4c8d6507              lea       r12, [rbp + 7]
0x000144355465:  48837d1f10            cmp       qword ptr [rbp + 0x1f], 0x10
0x00014435546a:  4c0f436507            cmovae    r12, qword ptr [rbp + 7]
0x00014435546f:  4c8965f7              mov       qword ptr [rbp - 9], r12
0x000144355473:  488b4e18              mov       rcx, qword ptr [rsi + 0x18]
0x000144355477:  488b4150              mov       rax, qword ptr [rcx + 0x50]
0x00014435547b:  48394158              cmp       qword ptr [rcx + 0x58], rax
0x00014435547f:  720a                  jb        0x14435548b
0x000144355481:  b201                  mov       dl, 1
0x000144355483:  488bce                mov       rcx, rsi
0x000144355486:  e865e432fe            call      0x1426838f0
0x00014435548b:  0fb64601              movzx     eax, byte ptr [rsi + 1]
0x00014435548f:  a804                  test      al, 4
0x000144355491:  7415                  je        0x1443554a8
0x000144355493:  488b4e18              mov       rcx, qword ptr [rsi + 0x18]
0x000144355497:  24fb                  and       al, 0xfb
0x000144355499:  884601                mov       byte ptr [rsi + 1], al
0x00014435549c:  488b4138              mov       rax, qword ptr [rcx + 0x38]
0x0001443554a0:  48894650              mov       qword ptr [rsi + 0x50], rax
0x0001443554a4:  48897138              mov       qword ptr [rcx + 0x38], rsi
0x0001443554a8:  488b4e08              mov       rcx, qword ptr [rsi + 8]
0x0001443554ac:  488b4628              mov       rax, qword ptr [rsi + 0x28]
0x0001443554b0:  4883c010              add       rax, 0x10
0x0001443554b4:  483b01                cmp       rax, qword ptr [rcx]
0x0001443554b7:  7615                  jbe       0x1443554ce
0x0001443554b9:  ba01000000            mov       edx, 1
0x0001443554be:  488bce                mov       rcx, rsi
0x0001443554c1:  e80a7030fe            call      0x14265c4d0
0x0001443554c6:  85c0                  test      eax, eax
0x0001443554c8:  0f8453050000          je        0x144355a21
0x0001443554ce:  488b4628              mov       rax, qword ptr [rsi + 0x28]
0x0001443554d2:  488945d7              mov       qword ptr [rbp - 0x29], rax
0x0001443554d6:  498bd7                mov       rdx, r15
0x0001443554d9:  4c897dff              mov       qword ptr [rbp - 1], r15
0x0001443554dd:  4d8bd4                mov       r10, r12
0x0001443554e0:  458bc6                mov       r8d, r14d
0x0001443554e3:  458bce                mov       r9d, r14d
0x0001443554e6:  418bdf                mov       ebx, r15d
0x0001443554e9:  4983ff20              cmp       r15, 0x20
0x0001443554ed:  726a                  jb        0x144355559
0x0001443554ef:  498d4fec              lea       rcx, [r15 - 0x14]
0x0001443554f3:  48b8abaaaaaaaaaaaaaa  movabs    rax, 0xaaaaaaaaaaaaaaab
0x0001443554fd:  48f7e1                mul       rcx
0x000144355500:  4c8bda                mov       r11, rdx
0x000144355503:  49c1eb03              shr       r11, 3
0x000144355507:  496bd3f4              imul      rdx, r11, -0xc
0x00014435550b:  4903d7                add       rdx, r15
0x00014435550e:  6690                  nop       
0x000144355510:  f2410f1002            movsd     xmm0, qword ptr [r10]
0x000144355515:  f20f1145e7            movsd     qword ptr [rbp - 0x19], xmm0
0x00014435551a:  41035a08              add       ebx, dword ptr [r10 + 8]
0x00014435551e:  8bcb                  mov       ecx, ebx
0x000144355520:  c1c90e                ror       ecx, 0xe
0x000144355523:  440345e7              add       r8d, dword ptr [rbp - 0x19]
0x000144355527:  4433c3                xor       r8d, ebx
0x00014435552a:  442bc1                sub       r8d, ecx
0x00014435552d:  418bc8                mov       ecx, r8d
0x000144355530:  c1c90b                ror       ecx, 0xb
0x000144355533:  488b45e7              mov       rax, qword ptr [rbp - 0x19]
0x000144355537:  48c1e820              shr       rax, 0x20
0x00014435553b:  4403c8                add       r9d, eax
0x00014435553e:  4533c8                xor       r9d, r8d
0x000144355541:  442bc9                sub       r9d, ecx
0x000144355544:  418bc1                mov       eax, r9d
0x000144355547:  c1c007                rol       eax, 7
0x00014435554a:  4133d9                xor       ebx, r9d
0x00014435554d:  2bd8                  sub       ebx, eax
0x00014435554f:  4983c20c              add       r10, 0xc
0x000144355553:  4983eb01              sub       r11, 1
0x000144355557:  75b7                  jne       0x144355510
0x000144355559:  4885d2                test      rdx, rdx
0x00014435555c:  741e                  je        0x14435557c
0x00014435555e:  6690                  nop       
0x000144355560:  410fb64c12ff          movzx     ecx, byte ptr [r10 + rdx - 1]
0x000144355566:  8bc3                  mov       eax, ebx
0x000144355568:  c1e005                shl       eax, 5
0x00014435556b:  03c8                  add       ecx, eax
0x00014435556d:  8bc3                  mov       eax, ebx
0x00014435556f:  c1e802                shr       eax, 2
0x000144355572:  03c8                  add       ecx, eax
0x000144355574:  33d9                  xor       ebx, ecx
0x000144355576:  4883ea01              sub       rdx, 1
0x00014435557a:  75e4                  jne       0x144355560
0x00014435557c:  4c8b6e18              mov       r13, qword ptr [rsi + 0x18]
0x000144355580:  49634d18              movsxd    rcx, dword ptr [r13 + 0x18]
0x000144355584:  48ffc9                dec       rcx
0x000144355587:  4863c3                movsxd    rax, ebx
0x00014435558a:  4823c8                and       rcx, rax
0x00014435558d:  498b4520              mov       rax, qword ptr [r13 + 0x20]
0x000144355591:  488b3cc8              mov       rdi, qword ptr [rax + rcx*8]
0x000144355595:  4885ff                test      rdi, rdi
0x000144355598:  7444                  je        0x1443555de
0x00014435559a:  8b4714                mov       eax, dword ptr [rdi + 0x14]
0x00014435559d:  493bc7                cmp       rax, r15
0x0001443555a0:  7513                  jne       0x1443555b5
0x0001443555a2:  488d5718              lea       rdx, [rdi + 0x18]
0x0001443555a6:  4d8bc7                mov       r8, r15
0x0001443555a9:  498bcc                mov       rcx, r12
0x0001443555ac:  e87fe27e01            call      0x145b43830
0x0001443555b1:  85c0                  test      eax, eax
0x0001443555b3:  7406                  je        0x1443555bb
0x0001443555b5:  488b7f08              mov       rdi, qword ptr [rdi + 8]
0x0001443555b9:  ebda                  jmp       0x144355595
0x0001443555bb:  0fb64f01              movzx     ecx, byte ptr [rdi + 1]
0x0001443555bf:  410fb64500            movzx     eax, byte ptr [r13]
0x0001443555c4:  f7d0                  not       eax
0x0001443555c6:  83e003                and       eax, 3
0x0001443555c9:  33c1                  xor       eax, ecx
0x0001443555cb:  a80b                  test      al, 0xb
0x0001443555cd:  0f8570030000          jne       0x144355943
0x0001443555d3:  80f103                xor       cl, 3
0x0001443555d6:  884f01                mov       byte ptr [rdi + 1], cl
0x0001443555d9:  e965030000            jmp       0x144355943
0x0001443555de:  4981ff00000040        cmp       r15, 0x40000000
0x0001443555e5:  0f87d7030000          ja        0x1443559c2
0x0001443555eb:  0fb64604              movzx     eax, byte ptr [rsi + 4]
0x0001443555ef:  8845df                mov       byte ptr [rbp - 0x21], al
0x0001443555f2:  4d8d6719              lea       r12, [r15 + 0x19]
0x0001443555f6:  498d4424ff            lea       rax, [r12 - 1]
0x0001443555fb:  483d00040000          cmp       rax, 0x400
0x000144355601:  0f83a1000000          jae       0x1443556a8
0x000144355607:  488d05f2a9cafb        lea       rax, [rip - 0x435560e]
0x00014435560e:  490fbe8c04404ad607    movsx     rcx, byte ptr [r12 + rax + 0x7d64a40]
0x000144355617:  84c9                  test      cl, cl
0x000144355619:  0f8889000000          js        0x1443556a8
0x00014435561f:  498d95a0000000        lea       rdx, [r13 + 0xa0]
0x000144355626:  4c8d04ca              lea       r8, [rdx + rcx*8]
0x00014435562a:  4c8945e7              mov       qword ptr [rbp - 0x19], r8
0x00014435562e:  4d8b08                mov       r9, qword ptr [r8]
0x000144355631:  4d85c9                test      r9, r9
0x000144355634:  751c                  jne       0x144355652
0x000144355636:  44884c2420            mov       byte ptr [rsp + 0x20], r9b
0x00014435563b:  440fb6c9              movzx     r9d, cl
0x00014435563f:  4d8d4568              lea       r8, [r13 + 0x68]
0x000144355643:  488bce                mov       rcx, rsi
0x000144355646:  e8657a34fe            call      0x14269d0b0
0x00014435564b:  4c8bc8                mov       r9, rax
0x00014435564e:  4c8b45e7              mov       r8, qword ptr [rbp - 0x19]
0x000144355652:  49635130              movsxd    rdx, dword ptr [r9 + 0x30]
0x000144355656:  85d2                  test      edx, edx
0x000144355658:  7811                  js        0x14435566b
0x00014435565a:  498d7940              lea       rdi, [r9 + 0x40]
0x00014435565e:  4803fa                add       rdi, rdx
0x000144355661:  412b5124              sub       edx, dword ptr [r9 + 0x24]
0x000144355665:  41895130              mov       dword ptr [r9 + 0x30], edx
0x000144355669:  eb0c                  jmp       0x144355677
0x00014435566b:  498b7928              mov       rdi, qword ptr [r9 + 0x28]
0x00014435566f:  488b4708              mov       rax, qword ptr [rdi + 8]
0x000144355673:  49894128              mov       qword ptr [r9 + 0x28], rax
0x000144355677:  41ff4134              inc       dword ptr [r9 + 0x34]
0x00014435567b:  4983792800            cmp       qword ptr [r9 + 0x28], 0
0x000144355680:  0f8595000000          jne       0x14435571b
0x000144355686:  85d2                  test      edx, edx
0x000144355688:  0f898d000000          jns       0x14435571b
0x00014435568e:  498b4118              mov       rax, qword ptr [r9 + 0x18]
0x000144355692:  498900                mov       qword ptr [r8], rax
0x000144355695:  498b4118              mov       rax, qword ptr [r9 + 0x18]
0x000144355699:  4885c0                test      rax, rax
0x00014435569c:  7404                  je        0x1443556a2
0x00014435569e:  4c897010              mov       qword ptr [rax + 0x10], r14
0x0001443556a2:  4d897118              mov       qword ptr [r9 + 0x18], r14
0x0001443556a6:  eb73                  jmp       0x14435571b
0x0001443556a8:  418d442440            lea       eax, [r12 + 0x40]
0x0001443556ad:  8945e3                mov       dword ptr [rbp - 0x1d], eax
0x0001443556b0:  498d7d68              lea       rdi, [r13 + 0x68]
0x0001443556b4:  4c63c8                movsxd    r9, eax
0x0001443556b7:  4533c0                xor       r8d, r8d
0x0001443556ba:  33d2                  xor       edx, edx
0x0001443556bc:  498b4d10              mov       rcx, qword ptr [r13 + 0x10]
0x0001443556c0:  498b4508              mov       rax, qword ptr [r13 + 8]
0x0001443556c4:  ff156ea6de01          call      qword ptr [rip + 0x1dea66e]
0x0001443556ca:  488bc8                mov       rcx, rax
0x0001443556cd:  4885c0                test      rax, rax
0x0001443556d0:  0f8469030000          je        0x144355a3f
0x0001443556d6:  4c897010              mov       qword ptr [rax + 0x10], r14
0x0001443556da:  4c897018              mov       qword ptr [rax + 0x18], r14
0x0001443556de:  4c8930                mov       qword ptr [rax], r14
0x0001443556e1:  4c897008              mov       qword ptr [rax + 8], r14
0x0001443556e5:  8b45e3                mov       eax, dword ptr [rbp - 0x1d]
0x0001443556e8:  894120                mov       dword ptr [rcx + 0x20], eax
0x0001443556eb:  44896124              mov       dword ptr [rcx + 0x24], r12d
0x0001443556ef:  4c897128              mov       qword ptr [rcx + 0x28], r14
0x0001443556f3:  4c897130              mov       qword ptr [rcx + 0x30], r14
0x0001443556f7:  4885ff                test      rdi, rdi
0x0001443556fa:  7412                  je        0x14435570e
0x0001443556fc:  488b07                mov       rax, qword ptr [rdi]
0x0001443556ff:  48894108              mov       qword ptr [rcx + 8], rax
0x000144355703:  4885c0                test      rax, rax
0x000144355706:  7403                  je        0x14435570b
0x000144355708:  488908                mov       qword ptr [rax], rcx
0x00014435570b:  48890f                mov       qword ptr [rdi], rcx
0x00014435570e:  488d7940              lea       rdi, [rcx + 0x40]
0x000144355712:  8b4124                mov       eax, dword ptr [rcx + 0x24]
0x000144355715:  294130                sub       dword ptr [rcx + 0x30], eax
0x000144355718:  ff4134                inc       dword ptr [rcx + 0x34]
0x00014435571b:  4885ff                test      rdi, rdi
0x00014435571e:  7509                  jne       0x144355729
0x000144355720:  4d85e4                test      r12, r12
0x000144355723:  0f8516030000          jne       0x144355a3f
0x000144355729:  4d016558              add       qword ptr [r13 + 0x58], r12
0x00014435572d:  0fb64ddf              movzx     ecx, byte ptr [rbp - 0x21]
0x000144355731:  4d01a4cdb02d0000      add       qword ptr [r13 + rcx*8 + 0x2db0], r12
0x000144355739:  498b8560060000        mov       rax, qword ptr [r13 + 0x660]
0x000144355740:  4885c0                test      rax, rax
0x000144355743:  7423                  je        0x144355768
0x000144355745:  4489742430            mov       dword ptr [rsp + 0x30], r14d
0x00014435574a:  c744242806000000      mov       dword ptr [rsp + 0x28], 6
0x000144355752:  884c2420              mov       byte ptr [rsp + 0x20], cl
0x000144355756:  4d8bcc                mov       r9, r12
0x000144355759:  4533c0                xor       r8d, r8d
0x00014435575c:  488bd7                mov       rdx, rdi
0x00014435575f:  488bce                mov       rcx, rsi
0x000144355762:  ff15d0a5de01          call      qword ptr [rip + 0x1dea5d0]
0x000144355768:  488b4618              mov       rax, qword ptr [rsi + 0x18]
0x00014435576c:  0fb608                movzx     ecx, byte ptr [rax]
0x00014435576f:  80e103                and       cl, 3
0x000144355772:  884f01                mov       byte ptr [rdi + 1], cl
0x000144355775:  c60706                mov       byte ptr [rdi], 6
0x000144355778:  0fb64604              movzx     eax, byte ptr [rsi + 4]
0x00014435577c:  884702                mov       byte ptr [rdi + 2], al
0x00014435577f:  c74704ffff0080        mov       dword ptr [rdi + 4], 0x8000ffff
0x000144355786:  8d4710                lea       eax, [rdi + 0x10]
0x000144355789:  2bc3                  sub       eax, ebx
0x00014435578b:  894710                mov       dword ptr [rdi + 0x10], eax
0x00014435578e:  488b45ff              mov       rax, qword ptr [rbp - 1]
0x000144355792:  894714                mov       dword ptr [rdi + 0x14], eax
0x000144355795:  488d4f18              lea       rcx, [rdi + 0x18]
0x000144355799:  4d8bc7                mov       r8, r15
0x00014435579c:  488b55f7              mov       rdx, qword ptr [rbp - 9]
0x0001443557a0:  e8fbd97e01            call      0x145b431a0
0x0001443557a5:  42c6443f1800          mov       byte ptr [rdi + r15 + 0x18], 0
0x0001443557ab:  4c8b4618              mov       r8, qword ptr [rsi + 0x18]
0x0001443557af:  418b4018              mov       eax, dword ptr [r8 + 0x18]
0x0001443557b3:  ffc8                  dec       eax
0x0001443557b5:  23c3                  and       eax, ebx
0x0001443557b7:  488d14c500000000      lea       rdx, [rax*8]
0x0001443557bf:  498b4020              mov       rax, qword ptr [r8 + 0x20]
0x0001443557c3:  488b0c02              mov       rcx, qword ptr [rdx + rax]
0x0001443557c7:  48894f08              mov       qword ptr [rdi + 8], rcx
0x0001443557cb:  498b4020              mov       rax, qword ptr [r8 + 0x20]
0x0001443557cf:  48893c02              mov       qword ptr [rdx + rax], rdi
0x0001443557d3:  41ff401c              inc       dword ptr [r8 + 0x1c]
0x0001443557d7:  458b6018              mov       r12d, dword ptr [r8 + 0x18]
0x0001443557db:  4539601c              cmp       dword ptr [r8 + 0x1c], r12d
0x0001443557df:  0f865e010000          jbe       0x144355943
0x0001443557e5:  4181fcffffff3f        cmp       r12d, 0x3fffffff
0x0001443557ec:  0f8f51010000          jg        0x144355943
0x0001443557f2:  4503e4                add       r12d, r12d
0x0001443557f5:  4d63ec                movsxd    r13, r12d
0x0001443557f8:  48b8ffffffffffffff1f  movabs    rax, 0x1fffffffffffffff
0x000144355802:  4c3be8                cmp       r13, rax
0x000144355805:  0f87b7010000          ja        0x1443559c2
0x00014435580b:  4e8d2ced00000000      lea       r13, [r13*8]
0x000144355813:  4c8b7e18              mov       r15, qword ptr [rsi + 0x18]
0x000144355817:  498d45ff              lea       rax, [r13 - 1]
0x00014435581b:  483d00040000          cmp       rax, 0x400
0x000144355821:  731e                  jae       0x144355841
0x000144355823:  488d05d6a7cafb        lea       rax, [rip - 0x435582a]
0x00014435582a:  420fbe9428404ad607    movsx     edx, byte ptr [rax + r13 + 0x7d64a40]
0x000144355833:  85d2                  test      edx, edx
0x000144355835:  780a                  js        0x144355841
0x000144355837:  488bce                mov       rcx, rsi
0x00014435583a:  e8c17534fe            call      0x14269ce00
0x00014435583f:  eb16                  jmp       0x144355857
0x000144355841:  4d8bcd                mov       r9, r13
0x000144355844:  4533c0                xor       r8d, r8d
0x000144355847:  33d2                  xor       edx, edx
0x000144355849:  498b4f10              mov       rcx, qword ptr [r15 + 0x10]
0x00014435584d:  498b4708              mov       rax, qword ptr [r15 + 8]
0x000144355851:  ff15e1a4de01          call      qword ptr [rip + 0x1dea4e1]
0x000144355857:  488bd8                mov       rbx, rax
0x00014435585a:  4885c0                test      rax, rax
0x00014435585d:  7509                  jne       0x144355868
0x00014435585f:  4d85ed                test      r13, r13
0x000144355862:  0f85d7010000          jne       0x144355a3f
0x000144355868:  4d016f58              add       qword ptr [r15 + 0x58], r13
0x00014435586c:  4d01afb02d0000        add       qword ptr [r15 + 0x2db0], r13
0x000144355873:  498b8760060000        mov       rax, qword ptr [r15 + 0x660]
0x00014435587a:  4885c0                test      rax, rax
0x00014435587d:  7424                  je        0x1443558a3
0x00014435587f:  4489742430            mov       dword ptr [rsp + 0x30], r14d
0x000144355884:  c744242811000000      mov       dword ptr [rsp + 0x28], 0x11
0x00014435588c:  c644242000            mov       byte ptr [rsp + 0x20], 0
0x000144355891:  4d8bcd                mov       r9, r13
0x000144355894:  4533c0                xor       r8d, r8d
0x000144355897:  488bd3                mov       rdx, rbx
0x00014435589a:  488bce                mov       rcx, rsi
0x00014435589d:  ff1595a4de01          call      qword ptr [rip + 0x1dea495]
0x0001443558a3:  4c8b7e18              mov       r15, qword ptr [rsi + 0x18]
0x0001443558a7:  4585e4                test      r12d, r12d
0x0001443558aa:  7e11                  jle       0x1443558bd
0x0001443558ac:  4983e5f8              and       r13, 0xfffffffffffffff8
0x0001443558b0:  4d8bc5                mov       r8, r13
0x0001443558b3:  33d2                  xor       edx, edx
0x0001443558b5:  488bcb                mov       rcx, rbx
0x0001443558b8:  e803c97e01            call      0x145b421c0
0x0001443558bd:  418b4718              mov       eax, dword ptr [r15 + 0x18]
0x0001443558c1:  85c0                  test      eax, eax
0x0001443558c3:  7e60                  jle       0x144355925
0x0001443558c5:  4d8bd6                mov       r10, r14
0x0001443558c8:  0f1f840000000000      nop       dword ptr [rax + rax]
0x0001443558d0:  498b4720              mov       rax, qword ptr [r15 + 0x20]
0x0001443558d4:  4d8b0402              mov       r8, qword ptr [r10 + rax]
0x0001443558d8:  4d85c0                test      r8, r8
0x0001443558db:  7438                  je        0x144355915
0x0001443558dd:  458d4c24ff            lea       r9d, [r12 - 1]
0x0001443558e2:  0f1f4000              nop       dword ptr [rax]
0x0001443558e6:  66660f1f840000000000  nop       word ptr [rax + rax]
0x0001443558f0:  498b5008              mov       rdx, qword ptr [r8 + 8]
0x0001443558f4:  498d4010              lea       rax, [r8 + 0x10]
0x0001443558f8:  2b00                  sub       eax, dword ptr [rax]
0x0001443558fa:  4123c1                and       eax, r9d
0x0001443558fd:  4898                  cdqe      
0x0001443558ff:  488d0cc3              lea       rcx, [rbx + rax*8]
0x000144355903:  488b01                mov       rax, qword ptr [rcx]
0x000144355906:  49894008              mov       qword ptr [r8 + 8], rax
0x00014435590a:  4c8901                mov       qword ptr [rcx], r8
0x00014435590d:  4c8bc2                mov       r8, rdx
0x000144355910:  4885d2                test      rdx, rdx
0x000144355913:  75db                  jne       0x1443558f0
0x000144355915:  41ffc6                inc       r14d
0x000144355918:  4983c208              add       r10, 8
0x00014435591c:  418b4718              mov       eax, dword ptr [r15 + 0x18]
0x000144355920:  443bf0                cmp       r14d, eax
0x000144355923:  7cab                  jl        0x1443558d0
0x000144355925:  4c63c0                movsxd    r8, eax
0x000144355928:  49c1e003              shl       r8, 3
0x00014435592c:  4533c9                xor       r9d, r9d
0x00014435592f:  498b5720              mov       rdx, qword ptr [r15 + 0x20]
0x000144355933:  488bce                mov       rcx, rsi
0x000144355936:  e8c56e34fe            call      0x14269c800
0x00014435593b:  45896718              mov       dword ptr [r15 + 0x18], r12d
0x00014435593f:  49895f20              mov       qword ptr [r15 + 0x20], rbx
0x000144355943:  488b45d7              mov       rax, qword ptr [rbp - 0x29]
0x000144355947:  488938                mov       qword ptr [rax], rdi
0x00014435594a:  c7400c06000000        mov       dword ptr [rax + 0xc], 6
0x000144355951:  4883462810            add       qword ptr [rsi + 0x28], 0x10
0x000144355956:  488b451f              mov       rax, qword ptr [rbp + 0x1f]
0x00014435595a:  4883f810              cmp       rax, 0x10
0x00014435595e:  7230                  jb        0x144355990
0x000144355960:  48ffc0                inc       rax
0x000144355963:  488b5507              mov       rdx, qword ptr [rbp + 7]
0x000144355967:  488bca                mov       rcx, rdx
0x00014435596a:  483d00100000          cmp       rax, 0x1000
0x000144355970:  7215                  jb        0x144355987
0x000144355972:  488b52f8              mov       rdx, qword ptr [rdx - 8]
0x000144355976:  482bca                sub       rcx, rdx
0x000144355979:  488d41f8              lea       rax, [rcx - 8]
0x00014435597d:  4883f81f              cmp       rax, 0x1f
0x000144355981:  0f87b2000000          ja        0x144355a39
0x000144355987:  488bca                mov       rcx, rdx
0x00014435598a:  e821d75e00            call      0x1449430b0
0x00014435598f:  90                    nop       
0x000144355990:  b801000000            mov       eax, 1
0x000144355995:  488b4d27              mov       rcx, qword ptr [rbp + 0x27]
0x000144355999:  4833cc                xor       rcx, rsp
0x00014435599c:  e83fbc7c01            call      0x145b215e0
0x0001443559a1:  4c8d9c24a0000000      lea       r11, [rsp + 0xa0]
0x0001443559a9:  498b5b38              mov       rbx, qword ptr [r11 + 0x38]
0x0001443559ad:  498b7340              mov       rsi, qword ptr [r11 + 0x40]
0x0001443559b1:  498b7b48              mov       rdi, qword ptr [r11 + 0x48]
0x0001443559b5:  498be3                mov       rsp, r11
0x0001443559b8:  415f                  pop       r15
0x0001443559ba:  415e                  pop       r14
0x0001443559bc:  415d                  pop       r13
0x0001443559be:  415c                  pop       r12
0x0001443559c0:  5d                    pop       rbp
0x0001443559c1:  c3                    ret       
0x0001443559c2:  488bce                mov       rcx, rsi
0x0001443559c5:  e8466d34fe            call      0x14269c710
0x0001443559ca:  cc                    int3      
0x0001443559cb:  488d05672be902        lea       rax, [rip + 0x2e92b67]
0x0001443559d2:  488945e7              mov       qword ptr [rbp - 0x19], rax
0x0001443559d6:  488b55e7              mov       rdx, qword ptr [rbp - 0x19]
0x0001443559da:  488d15cfc1d202        lea       rdx, [rip + 0x2d2c1cf]
0x0001443559e1:  488bce                mov       rcx, rsi
0x0001443559e4:  e8e7ee30fe            call      0x1426648d0
0x0001443559e9:  90                    nop       
0x0001443559ea:  ba01000000            mov       edx, 1
0x0001443559ef:  448d4205              lea       r8d, [rdx + 5]
0x0001443559f3:  488bce                mov       rcx, rsi
0x0001443559f6:  e8b5e330fe            call      0x142663db0
0x0001443559fb:  90                    nop       
0x0001443559fc:  e86f3547fc            call      0x1407c8f70
0x000144355a01:  cc                    int3      
0x000144355a02:  488d059c4feb02        lea       rax, [rip + 0x2eb4f9c]
0x000144355a09:  488945e7              mov       qword ptr [rbp - 0x19], rax
0x000144355a0d:  488b55e7              mov       rdx, qword ptr [rbp - 0x19]
0x000144355a11:  488d15b8c1d202        lea       rdx, [rip + 0x2d2c1b8]
0x000144355a18:  488bce                mov       rcx, rsi
0x000144355a1b:  e8b0ee30fe            call      0x1426648d0
0x000144355a20:  cc                    int3      
0x000144355a21:  488d15605cbc02        lea       rdx, [rip + 0x2bc5c60]
0x000144355a28:  488bce                mov       rcx, rsi
0x000144355a2b:  e8700e34fe            call      0x1426968a0
0x000144355a30:  488bce                mov       rcx, rsi
0x000144355a33:  e8289430fe            call      0x14265ee60
0x000144355a38:  90                    nop       
0x000144355a39:  e8e2ba7f01            call      0x145b51520
0x000144355a3e:  90                    nop       
0x000144355a3f:  ba04000000            mov       edx, 4
0x000144355a44:  488bce                mov       rcx, rsi
0x000144355a47:  e8f48f31fe            call      0x14266ea40
0x000144355a4c:  cc                    int3      
0x000144355a4d:  cc                    int3      
0x000144355a4e:  cc                    int3      
0x000144355a4f:  cc                    int3      
0x000144355a50:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x000144355a55:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x000144355a5a:  48897c2420            mov       qword ptr [rsp + 0x20], rdi
0x000144355a5f:  55                    push      rbp
0x000144355a60:  4154                  push      r12
0x000144355a62:  4155                  push      r13
0x000144355a64:  4156                  push      r14
0x000144355a66:  4157                  push      r15
0x000144355a68:  488d6c24f0            lea       rbp, [rsp - 0x10]
0x000144355a6d:  4881ec10010000        sub       rsp, 0x110
0x000144355a74:  488b0575dc9b03        mov       rax, qword ptr [rip + 0x39bdc75]
0x000144355a7b:  4833c4                xor       rax, rsp
0x000144355a7e:  48894500              mov       qword ptr [rbp], rax
0x000144355a82:  4c8bf9                mov       r15, rcx
0x000144355a85:  48894c2450            mov       qword ptr [rsp + 0x50], rcx
0x000144355a8a:  488b4110              mov       rax, qword ptr [rcx + 0x10]
0x000144355a8e:  488d1db3471602        lea       rbx, [rip + 0x21647b3]
0x000144355a95:  488bd3                mov       rdx, rbx
0x000144355a98:  483b4128              cmp       rax, qword ptr [rcx + 0x28]
0x000144355a9c:  480f42d0              cmovb     rdx, rax
0x000144355aa0:  837a0c06              cmp       dword ptr [rdx + 0xc], 6
0x000144355aa4:  7455                  je        0x144355afb
0x000144355aa6:  0fb64101              movzx     eax, byte ptr [rcx + 1]
0x000144355aaa:  a804                  test      al, 4
0x000144355aac:  7416                  je        0x144355ac4
0x000144355aae:  488b4918              mov       rcx, qword ptr [rcx + 0x18]
0x000144355ab2:  24fb                  and       al, 0xfb
0x000144355ab4:  41884701              mov       byte ptr [r15 + 1], al
0x000144355ab8:  488b4138              mov       rax, qword ptr [rcx + 0x38]
0x000144355abc:  49894750              mov       qword ptr [r15 + 0x50], rax
0x000144355ac0:  4c897938              mov       qword ptr [rcx + 0x38], r15
0x000144355ac4:  498bcf                mov       rcx, r15
0x000144355ac7:  e8e4db31fe            call      0x1426736b0
0x000144355acc:  85c0                  test      eax, eax
0x000144355ace:  0f84e00b0000          je        0x1443566b4
0x000144355ad4:  498b4f18              mov       rcx, qword ptr [r15 + 0x18]
0x000144355ad8:  488b4150              mov       rax, qword ptr [rcx + 0x50]
0x000144355adc:  48394158              cmp       qword ptr [rcx + 0x58], rax
0x000144355ae0:  720a                  jb        0x144355aec
0x000144355ae2:  b201                  mov       dl, 1
0x000144355ae4:  498bcf                mov       rcx, r15
0x000144355ae7:  e804de32fe            call      0x1426838f0
0x000144355aec:  498b4710              mov       rax, qword ptr [r15 + 0x10]
0x000144355af0:  488bd3                mov       rdx, rbx
0x000144355af3:  493b4728              cmp       rax, qword ptr [r15 + 0x28]
0x000144355af7:  480f42d0              cmovb     rdx, rax
0x000144355afb:  488b02                mov       rax, qword ptr [rdx]
0x000144355afe:  8b4814                mov       ecx, dword ptr [rax + 0x14]
0x000144355b01:  48894c2478            mov       qword ptr [rsp + 0x78], rcx
0x000144355b06:  488d5018              lea       rdx, [rax + 0x18]
0x000144355b0a:  48895598              mov       qword ptr [rbp - 0x68], rdx
0x000144355b0e:  4885d2                test      rdx, rdx
0x000144355b11:  0f849d0b0000          je        0x1443566b4
0x000144355b17:  4533ed                xor       r13d, r13d
0x000144355b1a:  4c896da0              mov       qword ptr [rbp - 0x60], r13
0x000144355b1e:  458be5                mov       r12d, r13d
0x000144355b21:  4c896db0              mov       qword ptr [rbp - 0x50], r13
0x000144355b25:  bb0f000000            mov       ebx, 0xf
0x000144355b2a:  48895db8              mov       qword ptr [rbp - 0x48], rbx
0x000144355b2e:  448865a0              mov       byte ptr [rbp - 0x60], r12b
0x000144355b32:  4c8d1dc7a4cafb        lea       r11, [rip - 0x4355b39]
0x000144355b39:  48b8ffffffffffffff7f  movabs    rax, 0x7fffffffffffffff
0x000144355b43:  41beffff0000          mov       r14d, 0xffff
0x000144355b49:  483bcb                cmp       rcx, rbx
0x000144355b4c:  7453                  je        0x144355ba1
0x000144355b4e:  7643                  jbe       0x144355b93
0x000144355b50:  483bc8                cmp       rcx, rax
0x000144355b53:  0f87730b0000          ja        0x1443566cc
0x000144355b59:  8bd9                  mov       ebx, ecx
0x000144355b5b:  4883cb0f              or        rbx, 0xf
0x000144355b5f:  b816000000            mov       eax, 0x16
0x000144355b64:  483bd8                cmp       rbx, rax
0x000144355b67:  480f42d8              cmovb     rbx, rax
0x000144355b6b:  488d4b01              lea       rcx, [rbx + 1]
0x000144355b6f:  e85c4549fc            call      0x1407ea0d0
0x000144355b74:  488bf0                mov       rsi, rax
0x000144355b77:  48895db8              mov       qword ptr [rbp - 0x48], rbx
0x000144355b7b:  448828                mov       byte ptr [rax], r13b
0x000144355b7e:  488945a0              mov       qword ptr [rbp - 0x60], rax
0x000144355b82:  4c896db0              mov       qword ptr [rbp - 0x50], r13
0x000144355b86:  488b5598              mov       rdx, qword ptr [rbp - 0x68]
0x000144355b8a:  4c8d1d6fa4cafb        lea       r11, [rip - 0x4355b91]
0x000144355b91:  eb12                  jmp       0x144355ba5
0x000144355b93:  4885c9                test      rcx, rcx
0x000144355b96:  7509                  jne       0x144355ba1
0x000144355b98:  488b75a0              mov       rsi, qword ptr [rbp - 0x60]
0x000144355b9c:  e941050000            jmp       0x1443560e2
0x000144355ba1:  488b75a0              mov       rsi, qword ptr [rbp - 0x60]
0x000144355ba5:  498bc5                mov       rax, r13
0x000144355ba8:  458bd5                mov       r10d, r13d
0x000144355bab:  458bcd                mov       r9d, r13d
0x000144355bae:  44896d8c              mov       dword ptr [rbp - 0x74], r13d
0x000144355bb2:  0f1f4000              nop       dword ptr [rax]
0x000144355bb6:  66660f1f840000000000  nop       word ptr [rax + rax]
0x000144355bc0:  0fb60c10              movzx     ecx, byte ptr [rax + rdx]
0x000144355bc4:  460fb6841960794f06    movzx     r8d, byte ptr [rcx + r11 + 0x64f7960]
0x000144355bcd:  8bd1                  mov       edx, ecx
0x000144355bcf:  4585d2                test      r10d, r10d
0x000144355bd2:  7411                  je        0x144355be5
0x000144355bd4:  83e23f                and       edx, 0x3f
0x000144355bd7:  418bc1                mov       eax, r9d
0x000144355bda:  c1e006                shl       eax, 6
0x000144355bdd:  448bca                mov       r9d, edx
0x000144355be0:  440bc8                or        r9d, eax
0x000144355be3:  eb0f                  jmp       0x144355bf4
0x000144355be5:  41b9ff000000          mov       r9d, 0xff
0x000144355beb:  418bc8                mov       ecx, r8d
0x000144355bee:  41d3f9                sar       r9d, cl
0x000144355bf1:  4423ca                and       r9d, edx
0x000144355bf4:  44894d90              mov       dword ptr [rbp - 0x70], r9d
0x000144355bf8:  418d4210              lea       eax, [r10 + 0x10]
0x000144355bfc:  c1e004                shl       eax, 4
0x000144355bff:  4103c0                add       eax, r8d
0x000144355c02:  460fb6941860794f06    movzx     r10d, byte ptr [rax + r11 + 0x64f7960]
0x000144355c0b:  44895588              mov       dword ptr [rbp - 0x78], r10d
0x000144355c0f:  4183fa01              cmp       r10d, 1
0x000144355c13:  0f84780a0000          je        0x144356691
0x000144355c19:  4585d2                test      r10d, r10d
0x000144355c1c:  0f8593040000          jne       0x1443560b5
0x000144355c22:  498bfd                mov       rdi, r13
0x000144355c25:  418bc9                mov       ecx, r9d
0x000144355c28:  894c2458              mov       dword ptr [rsp + 0x58], ecx
0x000144355c2c:  0f1f4000              nop       dword ptr [rax]
0x000144355c30:  4883ff10              cmp       rdi, 0x10
0x000144355c34:  732b                  jae       0x144355c61
0x000144355c36:  4c8d44245c            lea       r8, [rsp + 0x5c]
0x000144355c3b:  488d542458            lea       rdx, [rsp + 0x58]
0x000144355c40:  e8cba02dfe            call      0x14262fd10
0x000144355c45:  85c0                  test      eax, eax
0x000144355c47:  0f95c1                setne     cl
0x000144355c4a:  85c0                  test      eax, eax
0x000144355c4c:  740b                  je        0x144355c59
0x000144355c4e:  8b44245c              mov       eax, dword ptr [rsp + 0x5c]
0x000144355c52:  8944bdc0              mov       dword ptr [rbp + rdi*4 - 0x40], eax
0x000144355c56:  48ffc7                inc       rdi
0x000144355c59:  84c9                  test      cl, cl
0x000144355c5b:  8b4c2458              mov       ecx, dword ptr [rsp + 0x58]
0x000144355c5f:  75cf                  jne       0x144355c30
0x000144355c61:  83f97f                cmp       ecx, 0x7f
0x000144355c64:  770f                  ja        0x144355c75
0x000144355c66:  884c2440              mov       byte ptr [rsp + 0x40], cl
0x000144355c6a:  41be01000000          mov       r14d, 1
0x000144355c70:  e99c000000            jmp       0x144355d11
0x000144355c75:  81f9ff070000          cmp       ecx, 0x7ff
0x000144355c7b:  771f                  ja        0x144355c9c
0x000144355c7d:  8bc1                  mov       eax, ecx
0x000144355c7f:  c1e806                shr       eax, 6
0x000144355c82:  241f                  and       al, 0x1f
0x000144355c84:  0cc0                  or        al, 0xc0
0x000144355c86:  88442440              mov       byte ptr [rsp + 0x40], al
0x000144355c8a:  80e13f                and       cl, 0x3f
0x000144355c8d:  80c980                or        cl, 0x80
0x000144355c90:  884c2441              mov       byte ptr [rsp + 0x41], cl
0x000144355c94:  41be02000000          mov       r14d, 2
0x000144355c9a:  eb75                  jmp       0x144355d11
0x000144355c9c:  413bce                cmp       ecx, r14d
0x000144355c9f:  772c                  ja        0x144355ccd
0x000144355ca1:  8bc1                  mov       eax, ecx
0x000144355ca3:  c1e80c                shr       eax, 0xc
0x000144355ca6:  240f                  and       al, 0xf
0x000144355ca8:  0ce0                  or        al, 0xe0
0x000144355caa:  88442440              mov       byte ptr [rsp + 0x40], al
0x000144355cae:  8bc1                  mov       eax, ecx
0x000144355cb0:  c1e806                shr       eax, 6
0x000144355cb3:  243f                  and       al, 0x3f
0x000144355cb5:  0c80                  or        al, 0x80
0x000144355cb7:  88442441              mov       byte ptr [rsp + 0x41], al
0x000144355cbb:  80e13f                and       cl, 0x3f
0x000144355cbe:  80c980                or        cl, 0x80
0x000144355cc1:  884c2442              mov       byte ptr [rsp + 0x42], cl
0x000144355cc5:  41be03000000          mov       r14d, 3
0x000144355ccb:  eb44                  jmp       0x144355d11
0x000144355ccd:  81f9ffff1000          cmp       ecx, 0x10ffff
0x000144355cd3:  7739                  ja        0x144355d0e
0x000144355cd5:  8bc1                  mov       eax, ecx
0x000144355cd7:  c1e812                shr       eax, 0x12
0x000144355cda:  2407                  and       al, 7
0x000144355cdc:  0cf0                  or        al, 0xf0
0x000144355cde:  88442440              mov       byte ptr [rsp + 0x40], al
0x000144355ce2:  8bc1                  mov       eax, ecx
0x000144355ce4:  c1e80c                shr       eax, 0xc
0x000144355ce7:  243f                  and       al, 0x3f
0x000144355ce9:  0c80                  or        al, 0x80
0x000144355ceb:  88442441              mov       byte ptr [rsp + 0x41], al
0x000144355cef:  8bc1                  mov       eax, ecx
0x000144355cf1:  c1e806                shr       eax, 6
0x000144355cf4:  243f                  and       al, 0x3f
0x000144355cf6:  0c80                  or        al, 0x80
0x000144355cf8:  88442442              mov       byte ptr [rsp + 0x42], al
0x000144355cfc:  80e13f                and       cl, 0x3f
0x000144355cff:  80c980                or        cl, 0x80
0x000144355d02:  884c2443              mov       byte ptr [rsp + 0x43], cl
0x000144355d06:  41be04000000          mov       r14d, 4
0x000144355d0c:  eb03                  jmp       0x144355d11
0x000144355d0e:  4d8bf5                mov       r14, r13
0x000144355d11:  488bc3                mov       rax, rbx
0x000144355d14:  492bc4                sub       rax, r12
0x000144355d17:  4c3bf0                cmp       r14, rax
0x000144355d1a:  7743                  ja        0x144355d5f
0x000144355d1c:  4b8d0434              lea       rax, [r12 + r14]
0x000144355d20:  488945b0              mov       qword ptr [rbp - 0x50], rax
0x000144355d24:  488d45a0              lea       rax, [rbp - 0x60]
0x000144355d28:  4883fb10              cmp       rbx, 0x10
0x000144355d2c:  480f43c6              cmovae    rax, rsi
0x000144355d30:  4a8d1c20              lea       rbx, [rax + r12]
0x000144355d34:  4d8bc6                mov       r8, r14
0x000144355d37:  488d542440            lea       rdx, [rsp + 0x40]
0x000144355d3c:  488bcb                mov       rcx, rbx
0x000144355d3f:  e85cd47e01            call      0x145b431a0
0x000144355d44:  41c6041e00            mov       byte ptr [r14 + rbx], 0
0x000144355d49:  488b5db8              mov       rbx, qword ptr [rbp - 0x48]
0x000144355d4d:  4c8b7db0              mov       r15, qword ptr [rbp - 0x50]
0x000144355d51:  4c897c2460            mov       qword ptr [rsp + 0x60], r15
0x000144355d56:  488b75a0              mov       rsi, qword ptr [rbp - 0x60]
0x000144355d5a:  e90d010000            jmp       0x144355e6c
0x000144355d5f:  4d8bec                mov       r13, r12
0x000144355d62:  49b8ffffffffffffff7f  movabs    r8, 0x7fffffffffffffff
0x000144355d6c:  498bc0                mov       rax, r8
0x000144355d6f:  492bc4                sub       rax, r12
0x000144355d72:  493bc6                cmp       rax, r14
0x000144355d75:  0f8251090000          jb        0x1443566cc
0x000144355d7b:  4f8d3c26              lea       r15, [r14 + r12]
0x000144355d7f:  4c897c2460            mov       qword ptr [rsp + 0x60], r15
0x000144355d84:  488bd3                mov       rdx, rbx
0x000144355d87:  48895c2468            mov       qword ptr [rsp + 0x68], rbx
0x000144355d8c:  498bdf                mov       rbx, r15
0x000144355d8f:  4883cb0f              or        rbx, 0xf
0x000144355d93:  493bd8                cmp       rbx, r8
0x000144355d96:  7605                  jbe       0x144355d9d
0x000144355d98:  498bd8                mov       rbx, r8
0x000144355d9b:  eb21                  jmp       0x144355dbe
0x000144355d9d:  488bca                mov       rcx, rdx
0x000144355da0:  48d1e9                shr       rcx, 1
0x000144355da3:  498bc0                mov       rax, r8
0x000144355da6:  482bc1                sub       rax, rcx
0x000144355da9:  483bd0                cmp       rdx, rax
0x000144355dac:  7605                  jbe       0x144355db3
0x000144355dae:  498bd8                mov       rbx, r8
0x000144355db1:  eb0b                  jmp       0x144355dbe
0x000144355db3:  488d040a              lea       rax, [rdx + rcx]
0x000144355db7:  483bd8                cmp       rbx, rax
0x000144355dba:  480f42d8              cmovb     rbx, rax
0x000144355dbe:  488d4b01              lea       rcx, [rbx + 1]
0x000144355dc2:  e8094349fc            call      0x1407ea0d0
0x000144355dc7:  4c8be0                mov       r12, rax
0x000144355dca:  4c897db0              mov       qword ptr [rbp - 0x50], r15
0x000144355dce:  48895db8              mov       qword ptr [rbp - 0x48], rbx
0x000144355dd2:  4b8d042e              lea       rax, [r14 + r13]
0x000144355dd6:  4903c4                add       rax, r12
0x000144355dd9:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x000144355dde:  4d8bc5                mov       r8, r13
0x000144355de1:  498bcc                mov       rcx, r12
0x000144355de4:  48837c246810          cmp       qword ptr [rsp + 0x68], 0x10
0x000144355dea:  7254                  jb        0x144355e40
0x000144355dec:  488bd6                mov       rdx, rsi
0x000144355def:  e8acd37e01            call      0x145b431a0
0x000144355df4:  4d8bc6                mov       r8, r14
0x000144355df7:  488d542440            lea       rdx, [rsp + 0x40]
0x000144355dfc:  4b8d0c2c              lea       rcx, [r12 + r13]
0x000144355e00:  e89bd37e01            call      0x145b431a0
0x000144355e05:  488b442470            mov       rax, qword ptr [rsp + 0x70]
0x000144355e0a:  c60000                mov       byte ptr [rax], 0
0x000144355e0d:  488b442468            mov       rax, qword ptr [rsp + 0x68]
0x000144355e12:  48ffc0                inc       rax
0x000144355e15:  488bce                mov       rcx, rsi
0x000144355e18:  483d00100000          cmp       rax, 0x1000
0x000144355e1e:  7215                  jb        0x144355e35
0x000144355e20:  488b76f8              mov       rsi, qword ptr [rsi - 8]
0x000144355e24:  482bce                sub       rcx, rsi
0x000144355e27:  488d41f8              lea       rax, [rcx - 8]
0x000144355e2b:  4883f81f              cmp       rax, 0x1f
0x000144355e2f:  0f8791080000          ja        0x1443566c6
0x000144355e35:  488bce                mov       rcx, rsi
0x000144355e38:  e873d25e00            call      0x1449430b0
0x000144355e3d:  90                    nop       
0x000144355e3e:  eb22                  jmp       0x144355e62
0x000144355e40:  488d55a0              lea       rdx, [rbp - 0x60]
0x000144355e44:  e857d37e01            call      0x145b431a0
0x000144355e49:  4d8bc6                mov       r8, r14
0x000144355e4c:  488d542440            lea       rdx, [rsp + 0x40]
0x000144355e51:  4b8d0c2c              lea       rcx, [r12 + r13]
0x000144355e55:  e846d37e01            call      0x145b431a0
0x000144355e5a:  488b442470            mov       rax, qword ptr [rsp + 0x70]
0x000144355e5f:  c60000                mov       byte ptr [rax], 0
0x000144355e62:  4533ed                xor       r13d, r13d
0x000144355e65:  4c8965a0              mov       qword ptr [rbp - 0x60], r12
0x000144355e69:  498bf4                mov       rsi, r12
0x000144355e6c:  8d47ff                lea       eax, [rdi - 1]
0x000144355e6f:  4898                  cdqe      
0x000144355e71:  4889442468            mov       qword ptr [rsp + 0x68], rax
0x000144355e76:  4885c0                test      rax, rax
0x000144355e79:  0f8820020000          js        0x14435609f
0x000144355e7f:  90                    nop       
0x000144355e80:  8b4485c0              mov       eax, dword ptr [rbp + rax*4 - 0x40]
0x000144355e84:  83f87f                cmp       eax, 0x7f
0x000144355e87:  770e                  ja        0x144355e97
0x000144355e89:  88442444              mov       byte ptr [rsp + 0x44], al
0x000144355e8d:  bf01000000            mov       edi, 1
0x000144355e92:  e99f000000            jmp       0x144355f36
0x000144355e97:  3dff070000            cmp       eax, 0x7ff
0x000144355e9c:  771e                  ja        0x144355ebc
0x000144355e9e:  8bc8                  mov       ecx, eax
0x000144355ea0:  c1e906                shr       ecx, 6
0x000144355ea3:  80e11f                and       cl, 0x1f
0x000144355ea6:  80c9c0                or        cl, 0xc0
0x000144355ea9:  884c2444              mov       byte ptr [rsp + 0x44], cl
0x000144355ead:  243f                  and       al, 0x3f
0x000144355eaf:  0c80                  or        al, 0x80
0x000144355eb1:  88442445              mov       byte ptr [rsp + 0x45], al
0x000144355eb5:  bf02000000            mov       edi, 2
0x000144355eba:  eb7a                  jmp       0x144355f36
0x000144355ebc:  3dffff0000            cmp       eax, 0xffff
0x000144355ec1:  772d                  ja        0x144355ef0
0x000144355ec3:  8bc8                  mov       ecx, eax
0x000144355ec5:  c1e90c                shr       ecx, 0xc
0x000144355ec8:  80e10f                and       cl, 0xf
0x000144355ecb:  80c9e0                or        cl, 0xe0
0x000144355ece:  884c2444              mov       byte ptr [rsp + 0x44], cl
0x000144355ed2:  8bc8                  mov       ecx, eax
0x000144355ed4:  c1e906                shr       ecx, 6
0x000144355ed7:  80e13f                and       cl, 0x3f
0x000144355eda:  80c980                or        cl, 0x80
0x000144355edd:  884c2445              mov       byte ptr [rsp + 0x45], cl
0x000144355ee1:  243f                  and       al, 0x3f
0x000144355ee3:  0c80                  or        al, 0x80
0x000144355ee5:  88442446              mov       byte ptr [rsp + 0x46], al
0x000144355ee9:  bf03000000            mov       edi, 3
0x000144355eee:  eb46                  jmp       0x144355f36
0x000144355ef0:  3dffff1000            cmp       eax, 0x10ffff
0x000144355ef5:  773c                  ja        0x144355f33
0x000144355ef7:  8bc8                  mov       ecx, eax
0x000144355ef9:  c1e912                shr       ecx, 0x12
0x000144355efc:  80e107                and       cl, 7
0x000144355eff:  80c9f0                or        cl, 0xf0
0x000144355f02:  884c2444              mov       byte ptr [rsp + 0x44], cl
0x000144355f06:  8bc8                  mov       ecx, eax
0x000144355f08:  c1e90c                shr       ecx, 0xc
0x000144355f0b:  80e13f                and       cl, 0x3f
0x000144355f0e:  80c980                or        cl, 0x80
0x000144355f11:  884c2445              mov       byte ptr [rsp + 0x45], cl
0x000144355f15:  8bc8                  mov       ecx, eax
0x000144355f17:  c1e906                shr       ecx, 6
0x000144355f1a:  80e13f                and       cl, 0x3f
0x000144355f1d:  80c980                or        cl, 0x80
0x000144355f20:  884c2446              mov       byte ptr [rsp + 0x46], cl
0x000144355f24:  243f                  and       al, 0x3f
0x000144355f26:  0c80                  or        al, 0x80
0x000144355f28:  88442447              mov       byte ptr [rsp + 0x47], al
0x000144355f2c:  bf04000000            mov       edi, 4
0x000144355f31:  eb03                  jmp       0x144355f36
0x000144355f33:  498bfd                mov       rdi, r13
0x000144355f36:  488bc3                mov       rax, rbx
0x000144355f39:  492bc7                sub       rax, r15
0x000144355f3c:  483bf8                cmp       rdi, rax
0x000144355f3f:  7742                  ja        0x144355f83
0x000144355f41:  4a8d043f              lea       rax, [rdi + r15]
0x000144355f45:  488945b0              mov       qword ptr [rbp - 0x50], rax
0x000144355f49:  488d45a0              lea       rax, [rbp - 0x60]
0x000144355f4d:  4883fb10              cmp       rbx, 0x10
0x000144355f51:  480f43c6              cmovae    rax, rsi
0x000144355f55:  498d1c07              lea       rbx, [r15 + rax]
0x000144355f59:  4c8bc7                mov       r8, rdi
0x000144355f5c:  488d542444            lea       rdx, [rsp + 0x44]
0x000144355f61:  488bcb                mov       rcx, rbx
0x000144355f64:  e837d27e01            call      0x145b431a0
0x000144355f69:  c6041f00              mov       byte ptr [rdi + rbx], 0
0x000144355f6d:  488b5db8              mov       rbx, qword ptr [rbp - 0x48]
0x000144355f71:  4c8b7db0              mov       r15, qword ptr [rbp - 0x50]
0x000144355f75:  4c897c2460            mov       qword ptr [rsp + 0x60], r15
0x000144355f7a:  488b75a0              mov       rsi, qword ptr [rbp - 0x60]
0x000144355f7e:  e902010000            jmp       0x144356085
0x000144355f83:  48baffffffffffffff7f  movabs    rdx, 0x7fffffffffffffff
0x000144355f8d:  488bc2                mov       rax, rdx
0x000144355f90:  492bc7                sub       rax, r15
0x000144355f93:  483bc7                cmp       rax, rdi
0x000144355f96:  0f8230070000          jb        0x1443566cc
0x000144355f9c:  4d8d243f              lea       r12, [r15 + rdi]
0x000144355fa0:  4c89642460            mov       qword ptr [rsp + 0x60], r12
0x000144355fa5:  4c8beb                mov       r13, rbx
0x000144355fa8:  498bdc                mov       rbx, r12
0x000144355fab:  4883cb0f              or        rbx, 0xf
0x000144355faf:  483bda                cmp       rbx, rdx
0x000144355fb2:  7605                  jbe       0x144355fb9
0x000144355fb4:  488bda                mov       rbx, rdx
0x000144355fb7:  eb21                  jmp       0x144355fda
0x000144355fb9:  498bcd                mov       rcx, r13
0x000144355fbc:  48d1e9                shr       rcx, 1
0x000144355fbf:  488bc2                mov       rax, rdx
0x000144355fc2:  482bc1                sub       rax, rcx
0x000144355fc5:  4c3be8                cmp       r13, rax
0x000144355fc8:  7605                  jbe       0x144355fcf
0x000144355fca:  488bda                mov       rbx, rdx
0x000144355fcd:  eb0b                  jmp       0x144355fda
0x000144355fcf:  4a8d0429              lea       rax, [rcx + r13]
0x000144355fd3:  483bd8                cmp       rbx, rax
0x000144355fd6:  480f42d8              cmovb     rbx, rax
0x000144355fda:  488d4b01              lea       rcx, [rbx + 1]
0x000144355fde:  e8ed4049fc            call      0x1407ea0d0
0x000144355fe3:  4c8bf0                mov       r14, rax
0x000144355fe6:  4c8965b0              mov       qword ptr [rbp - 0x50], r12
0x000144355fea:  48895db8              mov       qword ptr [rbp - 0x48], rbx
0x000144355fee:  4d8d2407              lea       r12, [r15 + rax]
0x000144355ff2:  4803c7                add       rax, rdi
0x000144355ff5:  4903c7                add       rax, r15
0x000144355ff8:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x000144355ffd:  4d8bc7                mov       r8, r15
0x000144356000:  498bce                mov       rcx, r14
0x000144356003:  4983fd10              cmp       r13, 0x10
0x000144356007:  724f                  jb        0x144356058
0x000144356009:  488bd6                mov       rdx, rsi
0x00014435600c:  e88fd17e01            call      0x145b431a0
0x000144356011:  4c8bc7                mov       r8, rdi
0x000144356014:  488d542444            lea       rdx, [rsp + 0x44]
0x000144356019:  498bcc                mov       rcx, r12
0x00014435601c:  e87fd17e01            call      0x145b431a0
0x000144356021:  488b442470            mov       rax, qword ptr [rsp + 0x70]
0x000144356026:  c60000                mov       byte ptr [rax], 0
0x000144356029:  498d4501              lea       rax, [r13 + 1]
0x00014435602d:  488bce                mov       rcx, rsi
0x000144356030:  483d00100000          cmp       rax, 0x1000
0x000144356036:  7215                  jb        0x14435604d
0x000144356038:  488b76f8              mov       rsi, qword ptr [rsi - 8]
0x00014435603c:  482bce                sub       rcx, rsi
0x00014435603f:  488d41f8              lea       rax, [rcx - 8]
0x000144356043:  4883f81f              cmp       rax, 0x1f
0x000144356047:  0f8779060000          ja        0x1443566c6
0x00014435604d:  488bce                mov       rcx, rsi
0x000144356050:  e85bd05e00            call      0x1449430b0
0x000144356055:  90                    nop       
0x000144356056:  eb21                  jmp       0x144356079
0x000144356058:  488d55a0              lea       rdx, [rbp - 0x60]
0x00014435605c:  e83fd17e01            call      0x145b431a0
0x000144356061:  4c8bc7                mov       r8, rdi
0x000144356064:  488d542444            lea       rdx, [rsp + 0x44]
0x000144356069:  498bcc                mov       rcx, r12
0x00014435606c:  e82fd17e01            call      0x145b431a0
0x000144356071:  488b442470            mov       rax, qword ptr [rsp + 0x70]
0x000144356076:  c60000                mov       byte ptr [rax], 0
0x000144356079:  4c8b7c2460            mov       r15, qword ptr [rsp + 0x60]
0x00014435607e:  4c8975a0              mov       qword ptr [rbp - 0x60], r14
0x000144356082:  498bf6                mov       rsi, r14
0x000144356085:  488b442468            mov       rax, qword ptr [rsp + 0x68]
0x00014435608a:  4883e801              sub       rax, 1
0x00014435608e:  4889442468            mov       qword ptr [rsp + 0x68], rax
0x000144356093:  41bd00000000          mov       r13d, 0
0x000144356099:  0f89e1fdffff          jns       0x144355e80
0x00014435609f:  4c8d1d5a9fcafb        lea       r11, [rip - 0x43560a6]
0x0001443560a6:  41beffff0000          mov       r14d, 0xffff
0x0001443560ac:  448b5588              mov       r10d, dword ptr [rbp - 0x78]
0x0001443560b0:  4c8b642460            mov       r12, qword ptr [rsp + 0x60]
0x0001443560b5:  8b458c                mov       eax, dword ptr [rbp - 0x74]
0x0001443560b8:  ffc0                  inc       eax
0x0001443560ba:  89458c                mov       dword ptr [rbp - 0x74], eax
0x0001443560bd:  483b442478            cmp       rax, qword ptr [rsp + 0x78]
0x0001443560c2:  7310                  jae       0x1443560d4
0x0001443560c4:  4533ed                xor       r13d, r13d
0x0001443560c7:  448b4d90              mov       r9d, dword ptr [rbp - 0x70]
0x0001443560cb:  488b5598              mov       rdx, qword ptr [rbp - 0x68]
0x0001443560cf:  e9ecfaffff            jmp       0x144355bc0
0x0001443560d4:  4585d2                test      r10d, r10d
0x0001443560d7:  0f85f5050000          jne       0x1443566d2
0x0001443560dd:  4c8b7c2450            mov       r15, qword ptr [rsp + 0x50]
0x0001443560e2:  4c8d6da0              lea       r13, [rbp - 0x60]
0x0001443560e6:  4883fb10              cmp       rbx, 0x10
0x0001443560ea:  4c0f43ee              cmovae    r13, rsi
0x0001443560ee:  4c896c2470            mov       qword ptr [rsp + 0x70], r13
0x0001443560f3:  498b4f18              mov       rcx, qword ptr [r15 + 0x18]
0x0001443560f7:  488b4150              mov       rax, qword ptr [rcx + 0x50]
0x0001443560fb:  48394158              cmp       qword ptr [rcx + 0x58], rax
0x0001443560ff:  720a                  jb        0x14435610b
0x000144356101:  b201                  mov       dl, 1
0x000144356103:  498bcf                mov       rcx, r15
0x000144356106:  e8e5d732fe            call      0x1426838f0
0x00014435610b:  410fb64701            movzx     eax, byte ptr [r15 + 1]
0x000144356110:  a804                  test      al, 4
0x000144356112:  7416                  je        0x14435612a
0x000144356114:  498b4f18              mov       rcx, qword ptr [r15 + 0x18]
0x000144356118:  24fb                  and       al, 0xfb
0x00014435611a:  41884701              mov       byte ptr [r15 + 1], al
0x00014435611e:  488b4138              mov       rax, qword ptr [rcx + 0x38]
0x000144356122:  49894750              mov       qword ptr [r15 + 0x50], rax
0x000144356126:  4c897938              mov       qword ptr [rcx + 0x38], r15
0x00014435612a:  498b4f08              mov       rcx, qword ptr [r15 + 8]
0x00014435612e:  498b4728              mov       rax, qword ptr [r15 + 0x28]
0x000144356132:  4883c010              add       rax, 0x10
0x000144356136:  483b01                cmp       rax, qword ptr [rcx]
0x000144356139:  7615                  jbe       0x144356150
0x00014435613b:  ba01000000            mov       edx, 1
0x000144356140:  498bcf                mov       rcx, r15
0x000144356143:  e8886330fe            call      0x14265c4d0
0x000144356148:  85c0                  test      eax, eax
0x00014435614a:  0f84a5050000          je        0x1443566f5
0x000144356150:  498b4728              mov       rax, qword ptr [r15 + 0x28]
0x000144356154:  4889442468            mov       qword ptr [rsp + 0x68], rax
0x000144356159:  498bd4                mov       rdx, r12
0x00014435615c:  4c896598              mov       qword ptr [rbp - 0x68], r12
0x000144356160:  4d8bd5                mov       r10, r13
0x000144356163:  33c9                  xor       ecx, ecx
0x000144356165:  448bc1                mov       r8d, ecx
0x000144356168:  448bc9                mov       r9d, ecx
0x00014435616b:  458bf4                mov       r14d, r12d
0x00014435616e:  4983fc20              cmp       r12, 0x20
0x000144356172:  727a                  jb        0x1443561ee
0x000144356174:  498d4c24ec            lea       rcx, [r12 - 0x14]
0x000144356179:  48b8abaaaaaaaaaaaaaa  movabs    rax, 0xaaaaaaaaaaaaaaab
0x000144356183:  48f7e1                mul       rcx
0x000144356186:  4c8bda                mov       r11, rdx
0x000144356189:  49c1eb03              shr       r11, 3
0x00014435618d:  496bd3f4              imul      rdx, r11, -0xc
0x000144356191:  4903d4                add       rdx, r12
0x000144356194:  0f1f4000              nop       dword ptr [rax]
0x000144356198:  0f1f840000000000      nop       dword ptr [rax + rax]
0x0001443561a0:  f2410f1002            movsd     xmm0, qword ptr [r10]
0x0001443561a5:  f20f11442478          movsd     qword ptr [rsp + 0x78], xmm0
0x0001443561ab:  45037208              add       r14d, dword ptr [r10 + 8]
0x0001443561af:  418bce                mov       ecx, r14d
0x0001443561b2:  c1c90e                ror       ecx, 0xe
0x0001443561b5:  4403442478            add       r8d, dword ptr [rsp + 0x78]
0x0001443561ba:  4533c6                xor       r8d, r14d
0x0001443561bd:  442bc1                sub       r8d, ecx
0x0001443561c0:  418bc8                mov       ecx, r8d
0x0001443561c3:  c1c90b                ror       ecx, 0xb
0x0001443561c6:  488b442478            mov       rax, qword ptr [rsp + 0x78]
0x0001443561cb:  48c1e820              shr       rax, 0x20
0x0001443561cf:  4403c8                add       r9d, eax
0x0001443561d2:  4533c8                xor       r9d, r8d
0x0001443561d5:  442bc9                sub       r9d, ecx
0x0001443561d8:  418bc1                mov       eax, r9d
0x0001443561db:  c1c007                rol       eax, 7
0x0001443561de:  4533f1                xor       r14d, r9d
0x0001443561e1:  442bf0                sub       r14d, eax
0x0001443561e4:  4983c20c              add       r10, 0xc
0x0001443561e8:  4983eb01              sub       r11, 1
0x0001443561ec:  75b2                  jne       0x1443561a0
0x0001443561ee:  4885d2                test      rdx, rdx
0x0001443561f1:  742c                  je        0x14435621f
0x0001443561f3:  0f1f4000              nop       dword ptr [rax]
0x0001443561f7:  660f1f840000000000    nop       word ptr [rax + rax]
0x000144356200:  410fb64c12ff          movzx     ecx, byte ptr [r10 + rdx - 1]
0x000144356206:  418bc6                mov       eax, r14d
0x000144356209:  c1e005                shl       eax, 5
0x00014435620c:  03c8                  add       ecx, eax
0x00014435620e:  418bc6                mov       eax, r14d
0x000144356211:  c1e802                shr       eax, 2
0x000144356214:  03c8                  add       ecx, eax
0x000144356216:  4433f1                xor       r14d, ecx
0x000144356219:  4883ea01              sub       rdx, 1
0x00014435621d:  75e1                  jne       0x144356200
0x00014435621f:  4d8b7f18              mov       r15, qword ptr [r15 + 0x18]
0x000144356223:  49634f18              movsxd    rcx, dword ptr [r15 + 0x18]
0x000144356227:  48ffc9                dec       rcx
0x00014435622a:  4963c6                movsxd    rax, r14d
0x00014435622d:  4823c8                and       rcx, rax
0x000144356230:  498b4720              mov       rax, qword ptr [r15 + 0x20]
0x000144356234:  488b3cc8              mov       rdi, qword ptr [rax + rcx*8]
0x000144356238:  4885ff                test      rdi, rdi
0x00014435623b:  7443                  je        0x144356280
0x00014435623d:  8b4714                mov       eax, dword ptr [rdi + 0x14]
0x000144356240:  493bc4                cmp       rax, r12
0x000144356243:  7513                  jne       0x144356258
0x000144356245:  488d5718              lea       rdx, [rdi + 0x18]
0x000144356249:  4d8bc4                mov       r8, r12
0x00014435624c:  498bcd                mov       rcx, r13
0x00014435624f:  e8dcd57e01            call      0x145b43830
0x000144356254:  85c0                  test      eax, eax
0x000144356256:  7406                  je        0x14435625e
0x000144356258:  488b7f08              mov       rdi, qword ptr [rdi + 8]
0x00014435625c:  ebda                  jmp       0x144356238
0x00014435625e:  0fb64f01              movzx     ecx, byte ptr [rdi + 1]
0x000144356262:  410fb607              movzx     eax, byte ptr [r15]
0x000144356266:  f7d0                  not       eax
0x000144356268:  83e003                and       eax, 3
0x00014435626b:  33c1                  xor       eax, ecx
0x00014435626d:  a80b                  test      al, 0xb
0x00014435626f:  0f8590030000          jne       0x144356605
0x000144356275:  80f103                xor       cl, 3
0x000144356278:  884f01                mov       byte ptr [rdi + 1], cl
0x00014435627b:  e985030000            jmp       0x144356605
0x000144356280:  4981fc00000040        cmp       r12, 0x40000000
0x000144356287:  0f87f6030000          ja        0x144356683
0x00014435628d:  4c8b5c2450            mov       r11, qword ptr [rsp + 0x50]
0x000144356292:  410fb64304            movzx     eax, byte ptr [r11 + 4]
0x000144356297:  88442448              mov       byte ptr [rsp + 0x48], al
0x00014435629b:  4d8d6c2419            lea       r13, [r12 + 0x19]
0x0001443562a0:  498d45ff              lea       rax, [r13 - 1]
0x0001443562a4:  483d00040000          cmp       rax, 0x400
0x0001443562aa:  0f83a1000000          jae       0x144356351
0x0001443562b0:  488d05499dcafb        lea       rax, [rip - 0x43562b7]
0x0001443562b7:  4a0fbe8c28404ad607    movsx     rcx, byte ptr [rax + r13 + 0x7d64a40]
0x0001443562c0:  84c9                  test      cl, cl
0x0001443562c2:  0f8889000000          js        0x144356351
0x0001443562c8:  498d97a0000000        lea       rdx, [r15 + 0xa0]
0x0001443562cf:  4c8d04ca              lea       r8, [rdx + rcx*8]
0x0001443562d3:  4c89442478            mov       qword ptr [rsp + 0x78], r8
0x0001443562d8:  4d8b08                mov       r9, qword ptr [r8]
0x0001443562db:  4d85c9                test      r9, r9
0x0001443562de:  751d                  jne       0x1443562fd
0x0001443562e0:  44884c2420            mov       byte ptr [rsp + 0x20], r9b
0x0001443562e5:  440fb6c9              movzx     r9d, cl
0x0001443562e9:  4d8d4768              lea       r8, [r15 + 0x68]
0x0001443562ed:  498bcb                mov       rcx, r11
0x0001443562f0:  e8bb6d34fe            call      0x14269d0b0
0x0001443562f5:  4c8bc8                mov       r9, rax
0x0001443562f8:  4c8b442478            mov       r8, qword ptr [rsp + 0x78]
0x0001443562fd:  49635130              movsxd    rdx, dword ptr [r9 + 0x30]
0x000144356301:  85d2                  test      edx, edx
0x000144356303:  7811                  js        0x144356316
0x000144356305:  498d7940              lea       rdi, [r9 + 0x40]
0x000144356309:  4803fa                add       rdi, rdx
0x00014435630c:  412b5124              sub       edx, dword ptr [r9 + 0x24]
0x000144356310:  41895130              mov       dword ptr [r9 + 0x30], edx
0x000144356314:  eb0c                  jmp       0x144356322
0x000144356316:  498b7928              mov       rdi, qword ptr [r9 + 0x28]
0x00014435631a:  488b4708              mov       rax, qword ptr [rdi + 8]
0x00014435631e:  49894128              mov       qword ptr [r9 + 0x28], rax
0x000144356322:  41ff4134              inc       dword ptr [r9 + 0x34]
0x000144356326:  4983792800            cmp       qword ptr [r9 + 0x28], 0
0x00014435632b:  7520                  jne       0x14435634d
0x00014435632d:  85d2                  test      edx, edx
0x00014435632f:  791c                  jns       0x14435634d
0x000144356331:  498b4118              mov       rax, qword ptr [r9 + 0x18]
0x000144356335:  498900                mov       qword ptr [r8], rax
0x000144356338:  498b4118              mov       rax, qword ptr [r9 + 0x18]
0x00014435633c:  33d2                  xor       edx, edx
0x00014435633e:  4885c0                test      rax, rax
0x000144356341:  7404                  je        0x144356347
0x000144356343:  48895010              mov       qword ptr [rax + 0x10], rdx
0x000144356347:  49895118              mov       qword ptr [r9 + 0x18], rdx
0x00014435634b:  eb7a                  jmp       0x1443563c7
0x00014435634d:  33d2                  xor       edx, edx
0x00014435634f:  eb76                  jmp       0x1443563c7
0x000144356351:  418d4540              lea       eax, [r13 + 0x40]
0x000144356355:  8944245c              mov       dword ptr [rsp + 0x5c], eax
0x000144356359:  498d7f68              lea       rdi, [r15 + 0x68]
0x00014435635d:  4c63c8                movsxd    r9, eax
0x000144356360:  4533c0                xor       r8d, r8d
0x000144356363:  33d2                  xor       edx, edx
0x000144356365:  498b4f10              mov       rcx, qword ptr [r15 + 0x10]
0x000144356369:  498b4708              mov       rax, qword ptr [r15 + 8]
0x00014435636d:  ff15c599de01          call      qword ptr [rip + 0x1de99c5]
0x000144356373:  488bc8                mov       rcx, rax
0x000144356376:  4885c0                test      rax, rax
0x000144356379:  0f8494030000          je        0x144356713
0x00014435637f:  33d2                  xor       edx, edx
0x000144356381:  48895010              mov       qword ptr [rax + 0x10], rdx
0x000144356385:  48895018              mov       qword ptr [rax + 0x18], rdx
0x000144356389:  488910                mov       qword ptr [rax], rdx
0x00014435638c:  48895008              mov       qword ptr [rax + 8], rdx
0x000144356390:  8b44245c              mov       eax, dword ptr [rsp + 0x5c]
0x000144356394:  894120                mov       dword ptr [rcx + 0x20], eax
0x000144356397:  44896924              mov       dword ptr [rcx + 0x24], r13d
0x00014435639b:  48895128              mov       qword ptr [rcx + 0x28], rdx
0x00014435639f:  48895130              mov       qword ptr [rcx + 0x30], rdx
0x0001443563a3:  4885ff                test      rdi, rdi
0x0001443563a6:  7412                  je        0x1443563ba
0x0001443563a8:  488b07                mov       rax, qword ptr [rdi]
0x0001443563ab:  48894108              mov       qword ptr [rcx + 8], rax
0x0001443563af:  4885c0                test      rax, rax
0x0001443563b2:  7403                  je        0x1443563b7
0x0001443563b4:  488908                mov       qword ptr [rax], rcx
0x0001443563b7:  48890f                mov       qword ptr [rdi], rcx
0x0001443563ba:  488d7940              lea       rdi, [rcx + 0x40]
0x0001443563be:  8b4124                mov       eax, dword ptr [rcx + 0x24]
0x0001443563c1:  294130                sub       dword ptr [rcx + 0x30], eax
0x0001443563c4:  ff4134                inc       dword ptr [rcx + 0x34]
0x0001443563c7:  4885ff                test      rdi, rdi
0x0001443563ca:  7509                  jne       0x1443563d5
0x0001443563cc:  4d85ed                test      r13, r13
0x0001443563cf:  0f853e030000          jne       0x144356713
0x0001443563d5:  4d016f58              add       qword ptr [r15 + 0x58], r13
0x0001443563d9:  0fb64c2448            movzx     ecx, byte ptr [rsp + 0x48]
0x0001443563de:  4d01accfb02d0000      add       qword ptr [r15 + rcx*8 + 0x2db0], r13
0x0001443563e6:  498b8760060000        mov       rax, qword ptr [r15 + 0x660]
0x0001443563ed:  4c8b7c2450            mov       r15, qword ptr [rsp + 0x50]
0x0001443563f2:  4885c0                test      rax, rax
0x0001443563f5:  7422                  je        0x144356419
0x0001443563f7:  89542430              mov       dword ptr [rsp + 0x30], edx
0x0001443563fb:  c744242806000000      mov       dword ptr [rsp + 0x28], 6
0x000144356403:  884c2420              mov       byte ptr [rsp + 0x20], cl
0x000144356407:  4d8bcd                mov       r9, r13
0x00014435640a:  4533c0                xor       r8d, r8d
0x00014435640d:  488bd7                mov       rdx, rdi
0x000144356410:  498bcf                mov       rcx, r15
0x000144356413:  ff151f99de01          call      qword ptr [rip + 0x1de991f]
0x000144356419:  498b4718              mov       rax, qword ptr [r15 + 0x18]
0x00014435641d:  0fb608                movzx     ecx, byte ptr [rax]
0x000144356420:  80e103                and       cl, 3
0x000144356423:  884f01                mov       byte ptr [rdi + 1], cl
0x000144356426:  c60706                mov       byte ptr [rdi], 6
0x000144356429:  410fb64704            movzx     eax, byte ptr [r15 + 4]
0x00014435642e:  884702                mov       byte ptr [rdi + 2], al
0x000144356431:  c74704ffff0080        mov       dword ptr [rdi + 4], 0x8000ffff
0x000144356438:  8d4710                lea       eax, [rdi + 0x10]
0x00014435643b:  412bc6                sub       eax, r14d
0x00014435643e:  894710                mov       dword ptr [rdi + 0x10], eax
0x000144356441:  488b4598              mov       rax, qword ptr [rbp - 0x68]
0x000144356445:  894714                mov       dword ptr [rdi + 0x14], eax
0x000144356448:  488d4f18              lea       rcx, [rdi + 0x18]
0x00014435644c:  4d8bc4                mov       r8, r12
0x00014435644f:  488b542470            mov       rdx, qword ptr [rsp + 0x70]
0x000144356454:  e847cd7e01            call      0x145b431a0
0x000144356459:  41c6443c1800          mov       byte ptr [r12 + rdi + 0x18], 0
0x00014435645f:  4d8b4718              mov       r8, qword ptr [r15 + 0x18]
0x000144356463:  418b4018              mov       eax, dword ptr [r8 + 0x18]
0x000144356467:  ffc8                  dec       eax
0x000144356469:  4123c6                and       eax, r14d
0x00014435646c:  488d14c500000000      lea       rdx, [rax*8]
0x000144356474:  498b4020              mov       rax, qword ptr [r8 + 0x20]
0x000144356478:  488b0c02              mov       rcx, qword ptr [rdx + rax]
0x00014435647c:  48894f08              mov       qword ptr [rdi + 8], rcx
0x000144356480:  498b4020              mov       rax, qword ptr [r8 + 0x20]
0x000144356484:  48893c02              mov       qword ptr [rdx + rax], rdi
0x000144356488:  41ff401c              inc       dword ptr [r8 + 0x1c]
0x00014435648c:  458b6018              mov       r12d, dword ptr [r8 + 0x18]
0x000144356490:  4539601c              cmp       dword ptr [r8 + 0x1c], r12d
0x000144356494:  0f866b010000          jbe       0x144356605
0x00014435649a:  4181fcffffff3f        cmp       r12d, 0x3fffffff
0x0001443564a1:  0f8f5e010000          jg        0x144356605
0x0001443564a7:  4503e4                add       r12d, r12d
0x0001443564aa:  4d63ec                movsxd    r13, r12d
0x0001443564ad:  48b8ffffffffffffff1f  movabs    rax, 0x1fffffffffffffff
0x0001443564b7:  4c3be8                cmp       r13, rax
0x0001443564ba:  0f87c8010000          ja        0x144356688
0x0001443564c0:  4e8d2ced00000000      lea       r13, [r13*8]
0x0001443564c8:  4d8b7f18              mov       r15, qword ptr [r15 + 0x18]
0x0001443564cc:  498d45ff              lea       rax, [r13 - 1]
0x0001443564d0:  483d00040000          cmp       rax, 0x400
0x0001443564d6:  7320                  jae       0x1443564f8
0x0001443564d8:  488d05219bcafb        lea       rax, [rip - 0x43564df]
0x0001443564df:  420fbe9428404ad607    movsx     edx, byte ptr [rax + r13 + 0x7d64a40]
0x0001443564e8:  85d2                  test      edx, edx
0x0001443564ea:  780c                  js        0x1443564f8
0x0001443564ec:  488b4c2450            mov       rcx, qword ptr [rsp + 0x50]
0x0001443564f1:  e80a6934fe            call      0x14269ce00
0x0001443564f6:  eb16                  jmp       0x14435650e
0x0001443564f8:  4d8bcd                mov       r9, r13
0x0001443564fb:  4533c0                xor       r8d, r8d
0x0001443564fe:  33d2                  xor       edx, edx
0x000144356500:  498b4f10              mov       rcx, qword ptr [r15 + 0x10]
0x000144356504:  498b4708              mov       rax, qword ptr [r15 + 8]
0x000144356508:  ff152a98de01          call      qword ptr [rip + 0x1de982a]
0x00014435650e:  4c8bf0                mov       r14, rax
0x000144356511:  4885c0                test      rax, rax
0x000144356514:  7509                  jne       0x14435651f
0x000144356516:  4d85ed                test      r13, r13
0x000144356519:  0f85f4010000          jne       0x144356713
0x00014435651f:  4d016f58              add       qword ptr [r15 + 0x58], r13
0x000144356523:  4d01afb02d0000        add       qword ptr [r15 + 0x2db0], r13
0x00014435652a:  498b8760060000        mov       rax, qword ptr [r15 + 0x660]
0x000144356531:  4885c0                test      rax, rax
0x000144356534:  7426                  je        0x14435655c
0x000144356536:  33c9                  xor       ecx, ecx
0x000144356538:  894c2430              mov       dword ptr [rsp + 0x30], ecx
0x00014435653c:  c744242811000000      mov       dword ptr [rsp + 0x28], 0x11
0x000144356544:  884c2420              mov       byte ptr [rsp + 0x20], cl
0x000144356548:  4d8bcd                mov       r9, r13
0x00014435654b:  4533c0                xor       r8d, r8d
0x00014435654e:  498bd6                mov       rdx, r14
0x000144356551:  488b4c2450            mov       rcx, qword ptr [rsp + 0x50]
0x000144356556:  ff15dc97de01          call      qword ptr [rip + 0x1de97dc]
0x00014435655c:  488b442450            mov       rax, qword ptr [rsp + 0x50]
0x000144356561:  4c8b7818              mov       r15, qword ptr [rax + 0x18]
0x000144356565:  4585e4                test      r12d, r12d
0x000144356568:  7e11                  jle       0x14435657b
0x00014435656a:  4983e5f8              and       r13, 0xfffffffffffffff8
0x00014435656e:  4d8bc5                mov       r8, r13
0x000144356571:  33d2                  xor       edx, edx
0x000144356573:  498bce                mov       rcx, r14
0x000144356576:  e845bc7e01            call      0x145b421c0
0x00014435657b:  418b4718              mov       eax, dword ptr [r15 + 0x18]
0x00014435657f:  85c0                  test      eax, eax
0x000144356581:  7e62                  jle       0x1443565e5
0x000144356583:  4533db                xor       r11d, r11d
0x000144356586:  458bd3                mov       r10d, r11d
0x000144356589:  0f1f8000000000        nop       dword ptr [rax]
0x000144356590:  498b4720              mov       rax, qword ptr [r15 + 0x20]
0x000144356594:  4d8b0402              mov       r8, qword ptr [r10 + rax]
0x000144356598:  4d85c0                test      r8, r8
0x00014435659b:  7438                  je        0x1443565d5
0x00014435659d:  458d4c24ff            lea       r9d, [r12 - 1]
0x0001443565a2:  0f1f4000              nop       dword ptr [rax]
0x0001443565a6:  66660f1f840000000000  nop       word ptr [rax + rax]
0x0001443565b0:  498b5008              mov       rdx, qword ptr [r8 + 8]
0x0001443565b4:  498d4010              lea       rax, [r8 + 0x10]
0x0001443565b8:  2b00                  sub       eax, dword ptr [rax]
0x0001443565ba:  4123c1                and       eax, r9d
0x0001443565bd:  4898                  cdqe      
0x0001443565bf:  498d0cc6              lea       rcx, [r14 + rax*8]
0x0001443565c3:  488b01                mov       rax, qword ptr [rcx]
0x0001443565c6:  49894008              mov       qword ptr [r8 + 8], rax
0x0001443565ca:  4c8901                mov       qword ptr [rcx], r8
0x0001443565cd:  4c8bc2                mov       r8, rdx
0x0001443565d0:  4885d2                test      rdx, rdx
0x0001443565d3:  75db                  jne       0x1443565b0
0x0001443565d5:  41ffc3                inc       r11d
0x0001443565d8:  4983c208              add       r10, 8
0x0001443565dc:  418b4718              mov       eax, dword ptr [r15 + 0x18]
0x0001443565e0:  443bd8                cmp       r11d, eax
0x0001443565e3:  7cab                  jl        0x144356590
0x0001443565e5:  4c63c0                movsxd    r8, eax
0x0001443565e8:  49c1e003              shl       r8, 3
0x0001443565ec:  4533c9                xor       r9d, r9d
0x0001443565ef:  498b5720              mov       rdx, qword ptr [r15 + 0x20]
0x0001443565f3:  488b4c2450            mov       rcx, qword ptr [rsp + 0x50]
0x0001443565f8:  e8036234fe            call      0x14269c800
0x0001443565fd:  45896718              mov       dword ptr [r15 + 0x18], r12d
0x000144356601:  4d897720              mov       qword ptr [r15 + 0x20], r14
0x000144356605:  488b442468            mov       rax, qword ptr [rsp + 0x68]
0x00014435660a:  488938                mov       qword ptr [rax], rdi
0x00014435660d:  c7400c06000000        mov       dword ptr [rax + 0xc], 6
0x000144356614:  488b442450            mov       rax, qword ptr [rsp + 0x50]
0x000144356619:  4883402810            add       qword ptr [rax + 0x28], 0x10
0x00014435661e:  4883fb10              cmp       rbx, 0x10
0x000144356622:  722d                  jb        0x144356651
0x000144356624:  488d4301              lea       rax, [rbx + 1]
0x000144356628:  488bce                mov       rcx, rsi
0x00014435662b:  483d00100000          cmp       rax, 0x1000
0x000144356631:  7215                  jb        0x144356648
0x000144356633:  488b76f8              mov       rsi, qword ptr [rsi - 8]
0x000144356637:  482bce                sub       rcx, rsi
0x00014435663a:  488d41f8              lea       rax, [rcx - 8]
0x00014435663e:  4883f81f              cmp       rax, 0x1f
0x000144356642:  0f87c5000000          ja        0x14435670d
0x000144356648:  488bce                mov       rcx, rsi
0x00014435664b:  e860ca5e00            call      0x1449430b0
0x000144356650:  90                    nop       
0x000144356651:  b801000000            mov       eax, 1
0x000144356656:  488b4d00              mov       rcx, qword ptr [rbp]
0x00014435665a:  4833cc                xor       rcx, rsp
0x00014435665d:  e87eaf7c01            call      0x145b215e0
0x000144356662:  4c8d9c2410010000      lea       r11, [rsp + 0x110]
0x00014435666a:  498b5b38              mov       rbx, qword ptr [r11 + 0x38]
0x00014435666e:  498b7340              mov       rsi, qword ptr [r11 + 0x40]
0x000144356672:  498b7b48              mov       rdi, qword ptr [r11 + 0x48]
0x000144356676:  498be3                mov       rsp, r11
0x000144356679:  415f                  pop       r15
0x00014435667b:  415e                  pop       r14
0x00014435667d:  415d                  pop       r13
0x00014435667f:  415c                  pop       r12
0x000144356681:  5d                    pop       rbp
0x000144356682:  c3                    ret       
0x000144356683:  4c8b7c2450            mov       r15, qword ptr [rsp + 0x50]
0x000144356688:  498bcf                mov       rcx, r15
0x00014435668b:  e8806034fe            call      0x14269c710
0x000144356690:  cc                    int3      
0x000144356691:  488d05f8a1ed02        lea       rax, [rip + 0x2eda1f8]
0x000144356698:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x00014435669d:  488b542478            mov       rdx, qword ptr [rsp + 0x78]
0x0001443566a2:  488d1507b5d202        lea       rdx, [rip + 0x2d2b507]
0x0001443566a9:  488b4c2450            mov       rcx, qword ptr [rsp + 0x50]
0x0001443566ae:  e81de230fe            call      0x1426648d0
0x0001443566b3:  90                    nop       
0x0001443566b4:  ba01000000            mov       edx, 1
0x0001443566b9:  448d4205              lea       r8d, [rdx + 5]
0x0001443566bd:  498bcf                mov       rcx, r15
0x0001443566c0:  e8ebd630fe            call      0x142663db0
0x0001443566c5:  90                    nop       
0x0001443566c6:  e855ae7f01            call      0x145b51520
0x0001443566cb:  cc                    int3      
0x0001443566cc:  e89f2847fc            call      0x1407c8f70
0x0001443566d1:  cc                    int3      
0x0001443566d2:  488d051fb1f002        lea       rax, [rip + 0x2f0b11f]
0x0001443566d9:  4889442478            mov       qword ptr [rsp + 0x78], rax
0x0001443566de:  488b542478            mov       rdx, qword ptr [rsp + 0x78]
0x0001443566e3:  488d15e6b4d202        lea       rdx, [rip + 0x2d2b4e6]
0x0001443566ea:  488b4c2450            mov       rcx, qword ptr [rsp + 0x50]
0x0001443566ef:  e8dce130fe            call      0x1426648d0
0x0001443566f4:  cc                    int3      
0x0001443566f5:  488d158c4fbc02        lea       rdx, [rip + 0x2bc4f8c]
0x0001443566fc:  498bcf                mov       rcx, r15
0x0001443566ff:  e89c0134fe            call      0x1426968a0
0x000144356704:  498bcf                mov       rcx, r15
0x000144356707:  e8548730fe            call      0x14265ee60
0x00014435670c:  90                    nop       
0x00014435670d:  e80eae7f01            call      0x145b51520
0x000144356712:  90                    nop       
0x000144356713:  ba04000000            mov       edx, 4
0x000144356718:  488b4c2450            mov       rcx, qword ptr [rsp + 0x50]
0x00014435671d:  e81e8331fe            call      0x14266ea40
0x000144356722:  cc                    int3      
0x000144356723:  cc                    int3      
0x000144356724:  cc                    int3      
0x000144356725:  cc                    int3      
0x000144356726:  cc                    int3      
0x000144356727:  cc                    int3      
0x000144356728:  cc                    int3      
0x000144356729:  cc                    int3      
0x00014435672a:  cc                    int3      
0x00014435672b:  cc                    int3      
0x00014435672c:  cc                    int3      
0x00014435672d:  cc                    int3      
0x00014435672e:  cc                    int3      
0x00014435672f:  cc                    int3      
