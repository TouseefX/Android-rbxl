; function_of: vtab.lambda.5653-Token-amp
; xref site 0x142277113 -> vtab.lambda.5653-Token-amp @ 0x146c98890
; range 0x142277110 .. 0x142277820  (1808 bytes)

0x000142277110:  488d057917a204        lea       rax, [rip + 0x4a21779]
0x000142277117:  488902                mov       qword ptr [rdx], rax
0x00014227711a:  488b4108              mov       rax, qword ptr [rcx + 8]
0x00014227711e:  48894208              mov       qword ptr [rdx + 8], rax
0x000142277122:  488bc2                mov       rax, rdx
0x000142277125:  c3                    ret       
0x000142277126:  cc                    int3      
0x000142277127:  cc                    int3      
0x000142277128:  cc                    int3      
0x000142277129:  cc                    int3      
0x00014227712a:  cc                    int3      
0x00014227712b:  cc                    int3      
0x00014227712c:  cc                    int3      
0x00014227712d:  cc                    int3      
0x00014227712e:  cc                    int3      
0x00014227712f:  cc                    int3      
0x000142277130:  48895c2418            mov       qword ptr [rsp + 0x18], rbx
0x000142277135:  55                    push      rbp
0x000142277136:  56                    push      rsi
0x000142277137:  57                    push      rdi
0x000142277138:  4154                  push      r12
0x00014227713a:  4156                  push      r14
0x00014227713c:  4883ec50              sub       rsp, 0x50
0x000142277140:  488b05a9c5a905        mov       rax, qword ptr [rip + 0x5a9c5a9]
0x000142277147:  4833c4                xor       rax, rsp
0x00014227714a:  4889442448            mov       qword ptr [rsp + 0x48], rax
0x00014227714f:  488bda                mov       rbx, rdx
0x000142277152:  488bf9                mov       rdi, rcx
0x000142277155:  48894c2420            mov       qword ptr [rsp + 0x20], rcx
0x00014227715a:  4c8d6210              lea       r12, [rdx + 0x10]
0x00014227715e:  498b2c24              mov       rbp, qword ptr [r12]
0x000142277162:  4c8bf2                mov       r14, rdx
0x000142277165:  48837a1810            cmp       qword ptr [rdx + 0x18], 0x10
0x00014227716a:  7203                  jb        0x14227716f
0x00014227716c:  4c8b32                mov       r14, qword ptr [rdx]
0x00014227716f:  4885ed                test      rbp, rbp
0x000142277172:  0f84ab000000          je        0x142277223
0x000142277178:  4c8bc5                mov       r8, rbp
0x00014227717b:  ba2d000000            mov       edx, 0x2d
0x000142277180:  498bce                mov       rcx, r14
0x000142277183:  e878bf8c03            call      0x145b43100
0x000142277188:  488bf0                mov       rsi, rax
0x00014227718b:  4885c0                test      rax, rax
0x00014227718e:  0f848f000000          je        0x142277223
0x000142277194:  492bf6                sub       rsi, r14
0x000142277197:  4883feff              cmp       rsi, -1
0x00014227719b:  0f8482000000          je        0x142277223
0x0001422771a1:  4533f6                xor       r14d, r14d
0x0001422771a4:  4c89742428            mov       qword ptr [rsp + 0x28], r14
0x0001422771a9:  4c89742438            mov       qword ptr [rsp + 0x38], r14
0x0001422771ae:  48c74424400f000000    mov       qword ptr [rsp + 0x40], 0xf
0x0001422771b7:  4488742428            mov       byte ptr [rsp + 0x28], r14b
0x0001422771bc:  4c8bc6                mov       r8, rsi
0x0001422771bf:  483bee                cmp       rbp, rsi
0x0001422771c2:  4c0f42c5              cmovb     r8, rbp
0x0001422771c6:  488bd3                mov       rdx, rbx
0x0001422771c9:  48837b1810            cmp       qword ptr [rbx + 0x18], 0x10
0x0001422771ce:  7203                  jb        0x1422771d3
0x0001422771d0:  488b13                mov       rdx, qword ptr [rbx]
0x0001422771d3:  488d4c2428            lea       rcx, [rsp + 0x28]
0x0001422771d8:  e873c856fe            call      0x1407e3a50
0x0001422771dd:  90                    nop       
0x0001422771de:  4d8b0424              mov       r8, qword ptr [r12]
0x0001422771e2:  48ffc6                inc       rsi
0x0001422771e5:  4c3bc6                cmp       r8, rsi
0x0001422771e8:  490f42f0              cmovb     rsi, r8
0x0001422771ec:  48837b1810            cmp       qword ptr [rbx + 0x18], 0x10
0x0001422771f1:  7203                  jb        0x1422771f6
0x0001422771f3:  488b1b                mov       rbx, qword ptr [rbx]
0x0001422771f6:  4c2bc6                sub       r8, rsi
0x0001422771f9:  4d890424              mov       qword ptr [r12], r8
0x0001422771fd:  49ffc0                inc       r8
0x000142277200:  488d1433              lea       rdx, [rbx + rsi]
0x000142277204:  488bcb                mov       rcx, rbx
0x000142277207:  e894bf8c03            call      0x145b431a0
0x00014227720c:  0f10442428            movups    xmm0, xmmword ptr [rsp + 0x28]
0x000142277211:  0f1107                movups    xmmword ptr [rdi], xmm0
0x000142277214:  0f104c2438            movups    xmm1, xmmword ptr [rsp + 0x38]
0x000142277219:  0f114f10              movups    xmmword ptr [rdi + 0x10], xmm1
0x00014227721d:  c6472001              mov       byte ptr [rdi + 0x20], 1
0x000142277221:  eb04                  jmp       0x142277227
0x000142277223:  c6472000              mov       byte ptr [rdi + 0x20], 0
0x000142277227:  488bc7                mov       rax, rdi
0x00014227722a:  488b4c2448            mov       rcx, qword ptr [rsp + 0x48]
0x00014227722f:  4833cc                xor       rcx, rsp
0x000142277232:  e8a9a38a03            call      0x145b215e0
0x000142277237:  488b9c2490000000      mov       rbx, qword ptr [rsp + 0x90]
0x00014227723f:  4883c450              add       rsp, 0x50
0x000142277243:  415e                  pop       r14
0x000142277245:  415c                  pop       r12
0x000142277247:  5f                    pop       rdi
0x000142277248:  5e                    pop       rsi
0x000142277249:  5d                    pop       rbp
0x00014227724a:  c3                    ret       
0x00014227724b:  cc                    int3      
0x00014227724c:  cc                    int3      
0x00014227724d:  cc                    int3      
0x00014227724e:  cc                    int3      
0x00014227724f:  cc                    int3      
0x000142277250:  48895c2418            mov       qword ptr [rsp + 0x18], rbx
0x000142277255:  55                    push      rbp
0x000142277256:  56                    push      rsi
0x000142277257:  57                    push      rdi
0x000142277258:  4154                  push      r12
0x00014227725a:  4155                  push      r13
0x00014227725c:  488d6c24c9            lea       rbp, [rsp - 0x37]
0x000142277261:  4881ecf0000000        sub       rsp, 0xf0
0x000142277268:  488b0581c4a905        mov       rax, qword ptr [rip + 0x5a9c481]
0x00014227726f:  4833c4                xor       rax, rsp
0x000142277272:  4889452f              mov       qword ptr [rbp + 0x2f], rax
0x000142277276:  4c8be9                mov       r13, rcx
0x000142277279:  488d4db7              lea       rcx, [rbp - 0x49]
0x00014227727d:  e8decc56fe            call      0x1407e3f60
0x000142277282:  90                    nop       
0x000142277283:  0f57c0                xorps     xmm0, xmm0
0x000142277286:  33c0                  xor       eax, eax
0x000142277288:  0f1145f7              movups    xmmword ptr [rbp - 9], xmm0
0x00014227728c:  894507                mov       dword ptr [rbp + 7], eax
0x00014227728f:  6689450b              mov       word ptr [rbp + 0xb], ax
0x000142277293:  488d55b7              lea       rdx, [rbp - 0x49]
0x000142277297:  488d4d8f              lea       rcx, [rbp - 0x71]
0x00014227729b:  e890feffff            call      0x142277130
0x0001422772a0:  90                    nop       
0x0001422772a1:  488d55b7              lea       rdx, [rbp - 0x49]
0x0001422772a5:  488d4c2420            lea       rcx, [rsp + 0x20]
0x0001422772aa:  e881feffff            call      0x142277130
0x0001422772af:  90                    nop       
0x0001422772b0:  440fb66587            movzx     r12d, byte ptr [rbp - 0x79]
0x0001422772b5:  807daf00              cmp       byte ptr [rbp - 0x51], 0
0x0001422772b9:  0f84c8040000          je        0x142277787
0x0001422772bf:  4584e4                test      r12b, r12b
0x0001422772c2:  0f84bf040000          je        0x142277787
0x0001422772c8:  33ff                  xor       edi, edi
0x0001422772ca:  48897dd7              mov       qword ptr [rbp - 0x29], rdi
0x0001422772ce:  48897de7              mov       qword ptr [rbp - 0x19], rdi
0x0001422772d2:  48c745ef0f000000      mov       qword ptr [rbp - 0x11], 0xf
0x0001422772da:  40887dd7              mov       byte ptr [rbp - 0x29], dil
0x0001422772de:  488d5db7              lea       rbx, [rbp - 0x49]
0x0001422772e2:  48837dcf10            cmp       qword ptr [rbp - 0x31], 0x10
0x0001422772e7:  480f435db7            cmovae    rbx, qword ptr [rbp - 0x49]
0x0001422772ec:  488b75c7              mov       rsi, qword ptr [rbp - 0x39]
0x0001422772f0:  4885f6                test      rsi, rsi
0x0001422772f3:  745c                  je        0x142277351
0x0001422772f5:  4c8bc6                mov       r8, rsi
0x0001422772f8:  8d572e                lea       edx, [rdi + 0x2e]
0x0001422772fb:  488bcb                mov       rcx, rbx
0x0001422772fe:  e8fdbd8c03            call      0x145b43100
0x000142277303:  4885c0                test      rax, rax
0x000142277306:  7449                  je        0x142277351
0x000142277308:  482bc3                sub       rax, rbx
0x00014227730b:  4883f8ff              cmp       rax, -1
0x00014227730f:  7440                  je        0x142277351
0x000142277311:  48897d0f              mov       qword ptr [rbp + 0xf], rdi
0x000142277315:  48897d1f              mov       qword ptr [rbp + 0x1f], rdi
0x000142277319:  48c745270f000000      mov       qword ptr [rbp + 0x27], 0xf
0x000142277321:  483bf0                cmp       rsi, rax
0x000142277324:  480f42c6              cmovb     rax, rsi
0x000142277328:  488d55b7              lea       rdx, [rbp - 0x49]
0x00014227732c:  48837dcf10            cmp       qword ptr [rbp - 0x31], 0x10
0x000142277331:  480f4355b7            cmovae    rdx, qword ptr [rbp - 0x49]
0x000142277336:  4c8bc0                mov       r8, rax
0x000142277339:  488d4d0f              lea       rcx, [rbp + 0xf]
0x00014227733d:  e80ec756fe            call      0x1407e3a50
0x000142277342:  0f10450f              movups    xmm0, xmmword ptr [rbp + 0xf]
0x000142277346:  0f104d1f              movups    xmm1, xmmword ptr [rbp + 0x1f]
0x00014227734a:  440fb66587            movzx     r12d, byte ptr [rbp - 0x79]
0x00014227734f:  eb18                  jmp       0x142277369
0x000142277351:  0f1045b7              movups    xmm0, xmmword ptr [rbp - 0x49]
0x000142277355:  0f104dc7              movups    xmm1, xmmword ptr [rbp - 0x39]
0x000142277359:  48897dc7              mov       qword ptr [rbp - 0x39], rdi
0x00014227735d:  48c745cf0f000000      mov       qword ptr [rbp - 0x31], 0xf
0x000142277365:  c645b700              mov       byte ptr [rbp - 0x49], 0
0x000142277369:  0f114de7              movups    xmmword ptr [rbp - 0x19], xmm1
0x00014227736d:  0f1145d7              movups    xmmword ptr [rbp - 0x29], xmm0
0x000142277371:  488b75e7              mov       rsi, qword ptr [rbp - 0x19]
0x000142277375:  4885f6                test      rsi, rsi
0x000142277378:  0f85a0000000          jne       0x14227741e
0x00014227737e:  41887516              mov       byte ptr [r13 + 0x16], sil
0x000142277382:  488b45ef              mov       rax, qword ptr [rbp - 0x11]
0x000142277386:  4883f810              cmp       rax, 0x10
0x00014227738a:  7232                  jb        0x1422773be
0x00014227738c:  48ffc0                inc       rax
0x00014227738f:  488b4dd7              mov       rcx, qword ptr [rbp - 0x29]
0x000142277393:  488bd1                mov       rdx, rcx
0x000142277396:  483d00100000          cmp       rax, 0x1000
0x00014227739c:  7215                  jb        0x1422773b3
0x00014227739e:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x0001422773a2:  482bd1                sub       rdx, rcx
0x0001422773a5:  488d42f8              lea       rax, [rdx - 8]
0x0001422773a9:  4883f81f              cmp       rax, 0x1f
0x0001422773ad:  0f8758040000          ja        0x14227780b
0x0001422773b3:  e8f8bc6c02            call      0x1449430b0
0x0001422773b8:  90                    nop       
0x0001422773b9:  440fb66587            movzx     r12d, byte ptr [rbp - 0x79]
0x0001422773be:  4584e4                test      r12b, r12b
0x0001422773c1:  740b                  je        0x1422773ce
0x0001422773c3:  488d4c2420            lea       rcx, [rsp + 0x20]
0x0001422773c8:  e813e656fe            call      0x1407e59e0
0x0001422773cd:  90                    nop       
0x0001422773ce:  807daf00              cmp       byte ptr [rbp - 0x51], 0
0x0001422773d2:  740a                  je        0x1422773de
0x0001422773d4:  488d4d8f              lea       rcx, [rbp - 0x71]
0x0001422773d8:  e803e656fe            call      0x1407e59e0
0x0001422773dd:  90                    nop       
0x0001422773de:  488b45cf              mov       rax, qword ptr [rbp - 0x31]
0x0001422773e2:  4883f810              cmp       rax, 0x10
0x0001422773e6:  0f82f3030000          jb        0x1422777df
0x0001422773ec:  48ffc0                inc       rax
0x0001422773ef:  488b4db7              mov       rcx, qword ptr [rbp - 0x49]
0x0001422773f3:  488bd1                mov       rdx, rcx
0x0001422773f6:  483d00100000          cmp       rax, 0x1000
0x0001422773fc:  7215                  jb        0x142277413
0x0001422773fe:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x000142277402:  482bd1                sub       rdx, rcx
0x000142277405:  488d42f8              lea       rax, [rdx - 8]
0x000142277409:  4883f81f              cmp       rax, 0x1f
0x00014227740d:  0f87f2030000          ja        0x142277805
0x000142277413:  e898bc6c02            call      0x1449430b0
0x000142277418:  90                    nop       
0x000142277419:  e9c1030000            jmp       0x1422777df
0x00014227741e:  488b5def              mov       rbx, qword ptr [rbp - 0x11]
0x000142277422:  4c8b5dd7              mov       r11, qword ptr [rbp - 0x29]
0x000142277426:  48837d9f20            cmp       qword ptr [rbp - 0x61], 0x20
0x00014227742b:  0f85bc020000          jne       0x1422776ed
0x000142277431:  4c8bc7                mov       r8, rdi
0x000142277434:  4c8b4da7              mov       r9, qword ptr [rbp - 0x59]
0x000142277438:  4c8b558f              mov       r10, qword ptr [rbp - 0x71]
0x00014227743c:  0f1f4000              nop       dword ptr [rax]
0x000142277440:  488d458f              lea       rax, [rbp - 0x71]
0x000142277444:  4983f910              cmp       r9, 0x10
0x000142277448:  490f43c2              cmovae    rax, r10
0x00014227744c:  420fbe0c40            movsx     ecx, byte ptr [rax + r8*2]
0x000142277451:  8d41d0                lea       eax, [rcx - 0x30]
0x000142277454:  3c09                  cmp       al, 9
0x000142277456:  7705                  ja        0x14227745d
0x000142277458:  83e930                sub       ecx, 0x30
0x00014227745b:  eb1d                  jmp       0x14227747a
0x00014227745d:  8d419f                lea       eax, [rcx - 0x61]
0x000142277460:  3c05                  cmp       al, 5
0x000142277462:  7705                  ja        0x142277469
0x000142277464:  83e957                sub       ecx, 0x57
0x000142277467:  eb11                  jmp       0x14227747a
0x000142277469:  8d41bf                lea       eax, [rcx - 0x41]
0x00014227746c:  3c05                  cmp       al, 5
0x00014227746e:  7705                  ja        0x142277475
0x000142277470:  83e937                sub       ecx, 0x37
0x000142277473:  eb05                  jmp       0x14227747a
0x000142277475:  b9ffffffff            mov       ecx, 0xffffffff
0x00014227747a:  488d458f              lea       rax, [rbp - 0x71]
0x00014227747e:  4983f910              cmp       r9, 0x10
0x000142277482:  490f43c2              cmovae    rax, r10
0x000142277486:  420fbe544001          movsx     edx, byte ptr [rax + r8*2 + 1]
0x00014227748c:  8d42d0                lea       eax, [rdx - 0x30]
0x00014227748f:  3c09                  cmp       al, 9
0x000142277491:  7705                  ja        0x142277498
0x000142277493:  8d42d0                lea       eax, [rdx - 0x30]
0x000142277496:  eb1b                  jmp       0x1422774b3
0x000142277498:  8d429f                lea       eax, [rdx - 0x61]
0x00014227749b:  3c05                  cmp       al, 5
0x00014227749d:  7705                  ja        0x1422774a4
0x00014227749f:  8d42a9                lea       eax, [rdx - 0x57]
0x0001422774a2:  eb0f                  jmp       0x1422774b3
0x0001422774a4:  8d42bf                lea       eax, [rdx - 0x41]
0x0001422774a7:  3c05                  cmp       al, 5
0x0001422774a9:  8d42c9                lea       eax, [rdx - 0x37]
0x0001422774ac:  7605                  jbe       0x1422774b3
0x0001422774ae:  b8ffffffff            mov       eax, 0xffffffff
0x0001422774b3:  85c9                  test      ecx, ecx
0x0001422774b5:  0f8832020000          js        0x1422776ed
0x0001422774bb:  85c0                  test      eax, eax
0x0001422774bd:  0f882a020000          js        0x1422776ed
0x0001422774c3:  c0e104                shl       cl, 4
0x0001422774c6:  0ac8                  or        cl, al
0x0001422774c8:  42884c05f7            mov       byte ptr [rbp + r8 - 9], cl
0x0001422774cd:  49ffc0                inc       r8
0x0001422774d0:  4983f810              cmp       r8, 0x10
0x0001422774d4:  0f8266ffffff          jb        0x142277440
0x0001422774da:  48837c243008          cmp       qword ptr [rsp + 0x30], 8
0x0001422774e0:  0f8507020000          jne       0x1422776ed
0x0001422774e6:  4c8bc7                mov       r8, rdi
0x0001422774e9:  4c8b4c2438            mov       r9, qword ptr [rsp + 0x38]
0x0001422774ee:  4c8b542420            mov       r10, qword ptr [rsp + 0x20]
0x0001422774f3:  488d442420            lea       rax, [rsp + 0x20]
0x0001422774f8:  4983f910              cmp       r9, 0x10
0x0001422774fc:  490f43c2              cmovae    rax, r10
0x000142277500:  420fbe0c40            movsx     ecx, byte ptr [rax + r8*2]
0x000142277505:  8d41d0                lea       eax, [rcx - 0x30]
0x000142277508:  3c09                  cmp       al, 9
0x00014227750a:  7705                  ja        0x142277511
0x00014227750c:  83e930                sub       ecx, 0x30
0x00014227750f:  eb1d                  jmp       0x14227752e
0x000142277511:  8d419f                lea       eax, [rcx - 0x61]
0x000142277514:  3c05                  cmp       al, 5
0x000142277516:  7705                  ja        0x14227751d
0x000142277518:  83e957                sub       ecx, 0x57
0x00014227751b:  eb11                  jmp       0x14227752e
0x00014227751d:  8d41bf                lea       eax, [rcx - 0x41]
0x000142277520:  3c05                  cmp       al, 5
0x000142277522:  7705                  ja        0x142277529
0x000142277524:  83e937                sub       ecx, 0x37
0x000142277527:  eb05                  jmp       0x14227752e
0x000142277529:  b9ffffffff            mov       ecx, 0xffffffff
0x00014227752e:  488d442420            lea       rax, [rsp + 0x20]
0x000142277533:  4983f910              cmp       r9, 0x10
0x000142277537:  490f43c2              cmovae    rax, r10
0x00014227753b:  420fbe544001          movsx     edx, byte ptr [rax + r8*2 + 1]
0x000142277541:  8d42d0                lea       eax, [rdx - 0x30]
0x000142277544:  3c09                  cmp       al, 9
0x000142277546:  7705                  ja        0x14227754d
0x000142277548:  8d42d0                lea       eax, [rdx - 0x30]
0x00014227754b:  eb1b                  jmp       0x142277568
0x00014227754d:  8d429f                lea       eax, [rdx - 0x61]
0x000142277550:  3c05                  cmp       al, 5
0x000142277552:  7705                  ja        0x142277559
0x000142277554:  8d42a9                lea       eax, [rdx - 0x57]
0x000142277557:  eb0f                  jmp       0x142277568
0x000142277559:  8d42bf                lea       eax, [rdx - 0x41]
0x00014227755c:  3c05                  cmp       al, 5
0x00014227755e:  8d42c9                lea       eax, [rdx - 0x37]
0x000142277561:  7605                  jbe       0x142277568
0x000142277563:  b8ffffffff            mov       eax, 0xffffffff
0x000142277568:  85c9                  test      ecx, ecx
0x00014227756a:  0f887d010000          js        0x1422776ed
0x000142277570:  85c0                  test      eax, eax
0x000142277572:  0f8875010000          js        0x1422776ed
0x000142277578:  c0e104                shl       cl, 4
0x00014227757b:  0ac8                  or        cl, al
0x00014227757d:  42884c0507            mov       byte ptr [rbp + r8 + 7], cl
0x000142277582:  49ffc0                inc       r8
0x000142277585:  4983f804              cmp       r8, 4
0x000142277589:  0f8264ffffff          jb        0x1422774f3
0x00014227758f:  4883fe04              cmp       rsi, 4
0x000142277593:  0f8554010000          jne       0x1422776ed
0x000142277599:  0f1f8000000000        nop       dword ptr [rax]
0x0001422775a0:  488d45d7              lea       rax, [rbp - 0x29]
0x0001422775a4:  4883fb10              cmp       rbx, 0x10
0x0001422775a8:  490f43c3              cmovae    rax, r11
0x0001422775ac:  0fbe0c78              movsx     ecx, byte ptr [rax + rdi*2]
0x0001422775b0:  8d41d0                lea       eax, [rcx - 0x30]
0x0001422775b3:  3c09                  cmp       al, 9
0x0001422775b5:  7705                  ja        0x1422775bc
0x0001422775b7:  83e930                sub       ecx, 0x30
0x0001422775ba:  eb1d                  jmp       0x1422775d9
0x0001422775bc:  8d419f                lea       eax, [rcx - 0x61]
0x0001422775bf:  3c05                  cmp       al, 5
0x0001422775c1:  7705                  ja        0x1422775c8
0x0001422775c3:  83e957                sub       ecx, 0x57
0x0001422775c6:  eb11                  jmp       0x1422775d9
0x0001422775c8:  8d41bf                lea       eax, [rcx - 0x41]
0x0001422775cb:  3c05                  cmp       al, 5
0x0001422775cd:  7705                  ja        0x1422775d4
0x0001422775cf:  83e937                sub       ecx, 0x37
0x0001422775d2:  eb05                  jmp       0x1422775d9
0x0001422775d4:  b9ffffffff            mov       ecx, 0xffffffff
0x0001422775d9:  488d45d7              lea       rax, [rbp - 0x29]
0x0001422775dd:  4883fb10              cmp       rbx, 0x10
0x0001422775e1:  490f43c3              cmovae    rax, r11
0x0001422775e5:  0fbe547801            movsx     edx, byte ptr [rax + rdi*2 + 1]
0x0001422775ea:  8d42d0                lea       eax, [rdx - 0x30]
0x0001422775ed:  3c09                  cmp       al, 9
0x0001422775ef:  7705                  ja        0x1422775f6
0x0001422775f1:  8d42d0                lea       eax, [rdx - 0x30]
0x0001422775f4:  eb1b                  jmp       0x142277611
0x0001422775f6:  8d429f                lea       eax, [rdx - 0x61]
0x0001422775f9:  3c05                  cmp       al, 5
0x0001422775fb:  7705                  ja        0x142277602
0x0001422775fd:  8d42a9                lea       eax, [rdx - 0x57]
0x000142277600:  eb0f                  jmp       0x142277611
0x000142277602:  8d42bf                lea       eax, [rdx - 0x41]
0x000142277605:  3c05                  cmp       al, 5
0x000142277607:  8d42c9                lea       eax, [rdx - 0x37]
0x00014227760a:  7605                  jbe       0x142277611
0x00014227760c:  b8ffffffff            mov       eax, 0xffffffff
0x000142277611:  85c9                  test      ecx, ecx
0x000142277613:  0f88d4000000          js        0x1422776ed
0x000142277619:  85c0                  test      eax, eax
0x00014227761b:  0f88cc000000          js        0x1422776ed
0x000142277621:  c0e104                shl       cl, 4
0x000142277624:  0ac8                  or        cl, al
0x000142277626:  884c3d0b              mov       byte ptr [rbp + rdi + 0xb], cl
0x00014227762a:  48ffc7                inc       rdi
0x00014227762d:  4883ff02              cmp       rdi, 2
0x000142277631:  0f8269ffffff          jb        0x1422775a0
0x000142277637:  0f1045f7              movups    xmm0, xmmword ptr [rbp - 9]
0x00014227763b:  410f114500            movups    xmmword ptr [r13], xmm0
0x000142277640:  8b4507                mov       eax, dword ptr [rbp + 7]
0x000142277643:  41894510              mov       dword ptr [r13 + 0x10], eax
0x000142277647:  0fb7450b              movzx     eax, word ptr [rbp + 0xb]
0x00014227764b:  6641894514            mov       word ptr [r13 + 0x14], ax
0x000142277650:  41c6451601            mov       byte ptr [r13 + 0x16], 1
0x000142277655:  4883fb10              cmp       rbx, 0x10
0x000142277659:  7232                  jb        0x14227768d
0x00014227765b:  488d4301              lea       rax, [rbx + 1]
0x00014227765f:  498bcb                mov       rcx, r11
0x000142277662:  483d00100000          cmp       rax, 0x1000
0x000142277668:  7215                  jb        0x14227767f
0x00014227766a:  4d8b5bf8              mov       r11, qword ptr [r11 - 8]
0x00014227766e:  492bcb                sub       rcx, r11
0x000142277671:  488d41f8              lea       rax, [rcx - 8]
0x000142277675:  4883f81f              cmp       rax, 0x1f
0x000142277679:  0f878c010000          ja        0x14227780b
0x00014227767f:  498bcb                mov       rcx, r11
0x000142277682:  e829ba6c02            call      0x1449430b0
0x000142277687:  90                    nop       
0x000142277688:  440fb66587            movzx     r12d, byte ptr [rbp - 0x79]
0x00014227768d:  4584e4                test      r12b, r12b
0x000142277690:  740b                  je        0x14227769d
0x000142277692:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142277697:  e844e356fe            call      0x1407e59e0
0x00014227769c:  90                    nop       
0x00014227769d:  807daf00              cmp       byte ptr [rbp - 0x51], 0
0x0001422776a1:  740a                  je        0x1422776ad
0x0001422776a3:  488d4d8f              lea       rcx, [rbp - 0x71]
0x0001422776a7:  e834e356fe            call      0x1407e59e0
0x0001422776ac:  90                    nop       
0x0001422776ad:  488b45cf              mov       rax, qword ptr [rbp - 0x31]
0x0001422776b1:  4883f810              cmp       rax, 0x10
0x0001422776b5:  0f8224010000          jb        0x1422777df
0x0001422776bb:  48ffc0                inc       rax
0x0001422776be:  488b4db7              mov       rcx, qword ptr [rbp - 0x49]
0x0001422776c2:  488bd1                mov       rdx, rcx
0x0001422776c5:  483d00100000          cmp       rax, 0x1000
0x0001422776cb:  7215                  jb        0x1422776e2
0x0001422776cd:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x0001422776d1:  482bd1                sub       rdx, rcx
0x0001422776d4:  488d42f8              lea       rax, [rdx - 8]
0x0001422776d8:  4883f81f              cmp       rax, 0x1f
0x0001422776dc:  0f8723010000          ja        0x142277805
0x0001422776e2:  e8c9b96c02            call      0x1449430b0
0x0001422776e7:  90                    nop       
0x0001422776e8:  e9f2000000            jmp       0x1422777df
0x0001422776ed:  41c6451600            mov       byte ptr [r13 + 0x16], 0
0x0001422776f2:  4883fb10              cmp       rbx, 0x10
0x0001422776f6:  7232                  jb        0x14227772a
0x0001422776f8:  488d4301              lea       rax, [rbx + 1]
0x0001422776fc:  498bcb                mov       rcx, r11
0x0001422776ff:  483d00100000          cmp       rax, 0x1000
0x000142277705:  7215                  jb        0x14227771c
0x000142277707:  4d8b5bf8              mov       r11, qword ptr [r11 - 8]
0x00014227770b:  492bcb                sub       rcx, r11
0x00014227770e:  488d41f8              lea       rax, [rcx - 8]
0x000142277712:  4883f81f              cmp       rax, 0x1f
0x000142277716:  0f87ef000000          ja        0x14227780b
0x00014227771c:  498bcb                mov       rcx, r11
0x00014227771f:  e88cb96c02            call      0x1449430b0
0x000142277724:  90                    nop       
0x000142277725:  440fb66587            movzx     r12d, byte ptr [rbp - 0x79]
0x00014227772a:  4584e4                test      r12b, r12b
0x00014227772d:  740b                  je        0x14227773a
0x00014227772f:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142277734:  e8a7e256fe            call      0x1407e59e0
0x000142277739:  90                    nop       
0x00014227773a:  807daf00              cmp       byte ptr [rbp - 0x51], 0
0x00014227773e:  740a                  je        0x14227774a
0x000142277740:  488d4d8f              lea       rcx, [rbp - 0x71]
0x000142277744:  e897e256fe            call      0x1407e59e0
0x000142277749:  90                    nop       
0x00014227774a:  488b45cf              mov       rax, qword ptr [rbp - 0x31]
0x00014227774e:  4883f810              cmp       rax, 0x10
0x000142277752:  0f8287000000          jb        0x1422777df
0x000142277758:  48ffc0                inc       rax
0x00014227775b:  488b4db7              mov       rcx, qword ptr [rbp - 0x49]
0x00014227775f:  488bd1                mov       rdx, rcx
0x000142277762:  483d00100000          cmp       rax, 0x1000
0x000142277768:  7215                  jb        0x14227777f
0x00014227776a:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x00014227776e:  482bd1                sub       rdx, rcx
0x000142277771:  488d42f8              lea       rax, [rdx - 8]
0x000142277775:  4883f81f              cmp       rax, 0x1f
0x000142277779:  0f8786000000          ja        0x142277805
0x00014227777f:  e82cb96c02            call      0x1449430b0
0x000142277784:  90                    nop       
0x000142277785:  eb58                  jmp       0x1422777df
0x000142277787:  41c6451600            mov       byte ptr [r13 + 0x16], 0
0x00014227778c:  4584e4                test      r12b, r12b
0x00014227778f:  740b                  je        0x14227779c
0x000142277791:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142277796:  e845e256fe            call      0x1407e59e0
0x00014227779b:  90                    nop       
0x00014227779c:  807daf00              cmp       byte ptr [rbp - 0x51], 0
0x0001422777a0:  740a                  je        0x1422777ac
0x0001422777a2:  488d4d8f              lea       rcx, [rbp - 0x71]
0x0001422777a6:  e835e256fe            call      0x1407e59e0
0x0001422777ab:  90                    nop       
0x0001422777ac:  488b45cf              mov       rax, qword ptr [rbp - 0x31]
0x0001422777b0:  4883f810              cmp       rax, 0x10
0x0001422777b4:  7229                  jb        0x1422777df
0x0001422777b6:  48ffc0                inc       rax
0x0001422777b9:  488b4db7              mov       rcx, qword ptr [rbp - 0x49]
0x0001422777bd:  488bd1                mov       rdx, rcx
0x0001422777c0:  483d00100000          cmp       rax, 0x1000
0x0001422777c6:  7211                  jb        0x1422777d9
0x0001422777c8:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x0001422777cc:  482bd1                sub       rdx, rcx
0x0001422777cf:  488d42f8              lea       rax, [rdx - 8]
0x0001422777d3:  4883f81f              cmp       rax, 0x1f
0x0001422777d7:  772c                  ja        0x142277805
0x0001422777d9:  e8d2b86c02            call      0x1449430b0
0x0001422777de:  90                    nop       
0x0001422777df:  498bc5                mov       rax, r13
0x0001422777e2:  488b4d2f              mov       rcx, qword ptr [rbp + 0x2f]
0x0001422777e6:  4833cc                xor       rcx, rsp
0x0001422777e9:  e8f29d8a03            call      0x145b215e0
0x0001422777ee:  488b9c2430010000      mov       rbx, qword ptr [rsp + 0x130]
0x0001422777f6:  4881c4f0000000        add       rsp, 0xf0
0x0001422777fd:  415d                  pop       r13
0x0001422777ff:  415c                  pop       r12
0x000142277801:  5f                    pop       rdi
0x000142277802:  5e                    pop       rsi
0x000142277803:  5d                    pop       rbp
0x000142277804:  c3                    ret       
0x000142277805:  e8169d8d03            call      0x145b51520
0x00014227780a:  90                    nop       
0x00014227780b:  e8109d8d03            call      0x145b51520
0x000142277810:  90                    nop       
0x000142277811:  cc                    int3      
0x000142277812:  cc                    int3      
0x000142277813:  cc                    int3      
0x000142277814:  cc                    int3      
0x000142277815:  cc                    int3      
0x000142277816:  cc                    int3      
0x000142277817:  cc                    int3      
0x000142277818:  cc                    int3      
0x000142277819:  cc                    int3      
0x00014227781a:  cc                    int3      
0x00014227781b:  cc                    int3      
0x00014227781c:  cc                    int3      
0x00014227781d:  cc                    int3      
0x00014227781e:  cc                    int3      
0x00014227781f:  cc                    int3      
