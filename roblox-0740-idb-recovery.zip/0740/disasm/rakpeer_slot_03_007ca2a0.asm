; RakPeer vtable slot 3
; rva 0x7ca2a0
0x1407ca2a0:  c20000               ret       0
0x1407ca2a3:  cc                   int3      
0x1407ca2a4:  cc                   int3      
0x1407ca2a5:  cc                   int3      
0x1407ca2a6:  cc                   int3      
0x1407ca2a7:  cc                   int3      
0x1407ca2a8:  cc                   int3      
0x1407ca2a9:  cc                   int3      
0x1407ca2aa:  cc                   int3      
0x1407ca2ab:  cc                   int3      
0x1407ca2ac:  cc                   int3      
0x1407ca2ad:  cc                   int3      
0x1407ca2ae:  cc                   int3      
0x1407ca2af:  cc                   int3      
