; RakPeer vtable slot 65
; rva 0x2883660
0x142883660:  33c0                 xor       eax, eax
0x142883662:  89917c090000         mov       dword ptr [rcx + 0x97c], edx
0x142883668:  4c8bc9               mov       r9, rcx
0x14288366b:  663b8112010000       cmp       ax, word ptr [rcx + 0x112]
0x142883672:  7340                 jae       0x1428836b4
0x142883674:  0f1f4000             nop       dword ptr [rax]
0x142883678:  0f1f840000000000     nop       dword ptr [rax + rax]
0x142883680:  418b897c090000       mov       ecx, dword ptr [r9 + 0x97c]
0x142883687:  4c69c1e8030000       imul      r8, rcx, 0x3e8
0x14288368e:  0fb7c8               movzx     ecx, ax
0x142883691:  66ffc0               inc       ax
0x142883694:  4869d1d8160000       imul      rdx, rcx, 0x16d8
0x14288369b:  498b8950030000       mov       rcx, qword ptr [r9 + 0x350]
0x1428836a2:  4c89840ab8010000     mov       qword ptr [rdx + rcx + 0x1b8], r8
0x1428836aa:  66413b8112010000     cmp       ax, word ptr [r9 + 0x112]
0x1428836b2:  72cc                 jb        0x142883680
0x1428836b4:  c3                   ret       
0x1428836b5:  cc                   int3      
0x1428836b6:  cc                   int3      
0x1428836b7:  cc                   int3      
0x1428836b8:  cc                   int3      
0x1428836b9:  cc                   int3      
0x1428836ba:  cc                   int3      
0x1428836bb:  cc                   int3      
0x1428836bc:  cc                   int3      
0x1428836bd:  cc                   int3      
0x1428836be:  cc                   int3      
0x1428836bf:  cc                   int3      
0x1428836c0:  488991f80e0000       mov       qword ptr [rcx + 0xef8], rdx
0x1428836c7:  c3                   ret       
0x1428836c8:  cc                   int3      
0x1428836c9:  cc                   int3      
0x1428836ca:  cc                   int3      
0x1428836cb:  cc                   int3      
0x1428836cc:  cc                   int3      
0x1428836cd:  cc                   int3      
0x1428836ce:  cc                   int3      
0x1428836cf:  cc                   int3      
