; RakPeer vtable slot 14
; rva 0x287eb70
0x14287eb70:  488bc4               mov       rax, rsp
0x14287eb73:  48895810             mov       qword ptr [rax + 0x10], rbx
0x14287eb77:  48897018             mov       qword ptr [rax + 0x18], rsi
0x14287eb7b:  48897820             mov       qword ptr [rax + 0x20], rdi
0x14287eb7f:  55                   push      rbp
0x14287eb80:  4154                 push      r12
0x14287eb82:  4155                 push      r13
0x14287eb84:  4156                 push      r14
0x14287eb86:  4157                 push      r15
0x14287eb88:  488da858f8ffff       lea       rbp, [rax - 0x7a8]
0x14287eb8f:  4881ec80080000       sub       rsp, 0x880
0x14287eb96:  0f2970c8             movaps    xmmword ptr [rax - 0x38], xmm6
0x14287eb9a:  0f2978b8             movaps    xmmword ptr [rax - 0x48], xmm7
0x14287eb9e:  488b054b4b4905       mov       rax, qword ptr [rip + 0x5494b4b]
0x14287eba5:  4833c4               xor       rax, rsp
0x14287eba8:  48898550070000       mov       qword ptr [rbp + 0x750], rax
0x14287ebaf:  488bf9               mov       rdi, rcx
0x14287ebb2:  0fb6810a010000       movzx     eax, byte ptr [rcx + 0x10a]
0x14287ebb9:  90                   nop       
0x14287ebba:  84c0                 test      al, al
0x14287ebbc:  7407                 je        0x14287ebc5
0x14287ebbe:  b001                 mov       al, 1
0x14287ebc0:  e99e090000           jmp       0x14287f563
0x14287ebc5:  41b401               mov       r12b, 1
0x14287ebc8:  4488642440           mov       byte ptr [rsp + 0x40], r12b
0x14287ebcd:  0f57f6               xorps     xmm6, xmm6
0x14287ebd0:  c744244400000000     mov       dword ptr [rsp + 0x44], 0
0x14287ebd8:  488d542444           lea       rdx, [rsp + 0x44]
0x14287ebdd:  488d4d30             lea       rcx, [rbp + 0x30]
0x14287ebe1:  e85a5709fe           call      0x140914340
0x14287ebe6:  90                   nop       
0x14287ebe7:  b801000000           mov       eax, 1
0x14287ebec:  86870a010000         xchg      byte ptr [rdi + 0x10a], al
0x14287ebf2:  488d8f180b0000       lea       rcx, [rdi + 0xb18]
0x14287ebf9:  e8b24b2a03           call      0x145b237b0
0x14287ebfe:  85c0                 test      eax, eax
0x14287ec00:  0f859f090000         jne       0x14287f5a5
0x14287ec06:  4488a7b00b0000       mov       byte ptr [rdi + 0xbb0], r12b
0x14287ec0d:  488d8f180b0000       lea       rcx, [rdi + 0xb18]
0x14287ec14:  e8f74b2a03           call      0x145b23810
0x14287ec19:  488d8f680b0000       lea       rcx, [rdi + 0xb68]
0x14287ec20:  e81f632a03           call      0x145b24f44
0x14287ec25:  488d4c2460           lea       rcx, [rsp + 0x60]
0x14287ec2a:  e8d18d0c02           call      0x144947a00
0x14287ec2f:  0fb68709010000       movzx     eax, byte ptr [rdi + 0x109]
0x14287ec36:  90                   nop       
0x14287ec37:  4533ff               xor       r15d, r15d
0x14287ec3a:  f20f103df6a39404     movsd     xmm7, qword ptr [rip + 0x494a3f6]
0x14287ec42:  84c0                 test      al, al
0x14287ec44:  0f8491010000         je        0x14287eddb
0x14287ec4a:  488d8f000b0000       lea       rcx, [rdi + 0xb00]
0x14287ec51:  8b1559bf4e05         mov       edx, dword ptr [rip + 0x54ebf59]
0x14287ec57:  e804231a00           call      0x142a20f60
0x14287ec5c:  85c0                 test      eax, eax
0x14287ec5e:  0f8477010000         je        0x14287eddb
0x14287ec64:  488b0545ce4e05       mov       rax, qword ptr [rip + 0x54ece45]
0x14287ec6b:  3c06                 cmp       al, 6
0x14287ec6d:  726b                 jb        0x14287ecda
0x14287ec6f:  48c1e808             shr       rax, 8
0x14287ec73:  3c03                 cmp       al, 3
0x14287ec75:  7263                 jb        0x14287ecda
0x14287ec77:  488d05b16ddc04       lea       rax, [rip + 0x4dc6db1]
0x14287ec7e:  4889442450           mov       qword ptr [rsp + 0x50], rax
0x14287ec83:  488b5c2450           mov       rbx, qword ptr [rsp + 0x50]
0x14287ec88:  488d4c2468           lea       rcx, [rsp + 0x68]
0x14287ec8d:  e86e8d0c02           call      0x144947a00
0x14287ec92:  f20f10442468         movsd     xmm0, qword ptr [rsp + 0x68]
0x14287ec98:  f20f5c442460         subsd     xmm0, qword ptr [rsp + 0x60]
0x14287ec9e:  f20f59c7             mulsd     xmm0, xmm7
0x14287eca2:  f20f2cc0             cvttsd2si eax, xmm0
0x14287eca6:  4c63c8               movsxd    r9, eax
0x14287eca9:  4c630500bf4e05       movsxd    r8, dword ptr [rip + 0x54ebf00]
0x14287ecb0:  0f1005f9cd4e05       movups    xmm0, xmmword ptr [rip + 0x54ecdf9]
0x14287ecb7:  0f2945c0             movaps    xmmword ptr [rbp - 0x40], xmm0
0x14287ecbb:  4c897c2430           mov       qword ptr [rsp + 0x30], r15
0x14287ecc0:  4c897c2428           mov       qword ptr [rsp + 0x28], r15
0x14287ecc5:  4c897c2420           mov       qword ptr [rsp + 0x20], r15
0x14287ecca:  488d93812c8fff       lea       rdx, [rbx - 0x70d37f]
0x14287ecd1:  488d4dc0             lea       rcx, [rbp - 0x40]
0x14287ecd5:  e846110e02           call      0x14495fe20
0x14287ecda:  44383d8798a405       cmp       byte ptr [rip + 0x5a49887], r15b
0x14287ece1:  0f85c6080000         jne       0x14287f5ad
0x14287ece7:  4c89bda0000000       mov       qword ptr [rbp + 0xa0], r15
0x14287ecee:  4c89bdb0000000       mov       qword ptr [rbp + 0xb0], r15
0x14287ecf5:  48c785b80000000f000000 mov       qword ptr [rbp + 0xb8], 0xf
0x14287ed00:  4488bda0000000       mov       byte ptr [rbp + 0xa0], r15b
0x14287ed07:  b930000000           mov       ecx, 0x30
0x14287ed0c:  e8bfb3f6fd           call      0x1407ea0d0
0x14287ed11:  488bc8               mov       rcx, rax
0x14287ed14:  48c785b000000023000000 mov       qword ptr [rbp + 0xb0], 0x23
0x14287ed1f:  48c785b80000002f000000 mov       qword ptr [rbp + 0xb8], 0x2f
0x14287ed2a:  0f1005af986b04       movups    xmm0, xmmword ptr [rip + 0x46b98af]
0x14287ed31:  0f1100               movups    xmmword ptr [rax], xmm0
0x14287ed34:  0f100db5986b04       movups    xmm1, xmmword ptr [rip + 0x46b98b5]
0x14287ed3b:  0f114810             movups    xmmword ptr [rax + 0x10], xmm1
0x14287ed3f:  0fb705ba986b04       movzx     eax, word ptr [rip + 0x46b98ba]
0x14287ed46:  66894120             mov       word ptr [rcx + 0x20], ax
0x14287ed4a:  0fb605b1986b04       movzx     eax, byte ptr [rip + 0x46b98b1]
0x14287ed51:  884122               mov       byte ptr [rcx + 0x22], al
0x14287ed54:  44887923             mov       byte ptr [rcx + 0x23], r15b
0x14287ed58:  48898da0000000       mov       qword ptr [rbp + 0xa0], rcx
0x14287ed5f:  4c8d85a0000000       lea       r8, [rbp + 0xa0]
0x14287ed66:  488d5570             lea       rdx, [rbp + 0x70]
0x14287ed6a:  488d4d30             lea       rcx, [rbp + 0x30]
0x14287ed6e:  e8bd6294fe           call      0x1411c5030
0x14287ed73:  488b08               mov       rcx, qword ptr [rax]
0x14287ed76:  c7413001000000       mov       dword ptr [rcx + 0x30], 1
0x14287ed7d:  488b85b8000000       mov       rax, qword ptr [rbp + 0xb8]
0x14287ed84:  4883f810             cmp       rax, 0x10
0x14287ed88:  7230                 jb        0x14287edba
0x14287ed8a:  48ffc0               inc       rax
0x14287ed8d:  488b8da0000000       mov       rcx, qword ptr [rbp + 0xa0]
0x14287ed94:  488bd1               mov       rdx, rcx
0x14287ed97:  483d00100000         cmp       rax, 0x1000
0x14287ed9d:  7215                 jb        0x14287edb4
0x14287ed9f:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x14287eda3:  482bd1               sub       rdx, rcx
0x14287eda6:  488d42f8             lea       rax, [rdx - 8]
0x14287edaa:  4883f81f             cmp       rax, 0x1f
0x14287edae:  0f870b080000         ja        0x14287f5bf
0x14287edb4:  e8f7420c02           call      0x1449430b0
0x14287edb9:  90                   nop       
0x14287edba:  4c89bdb0000000       mov       qword ptr [rbp + 0xb0], r15
0x14287edc1:  48c785b80000000f000000 mov       qword ptr [rbp + 0xb8], 0xf
0x14287edcc:  c685a000000000       mov       byte ptr [rbp + 0xa0], 0
0x14287edd3:  4532e4               xor       r12b, r12b
0x14287edd6:  4488642440           mov       byte ptr [rsp + 0x40], r12b
0x14287eddb:  418bc7               mov       eax, r15d
0x14287edde:  878760030000         xchg      dword ptr [rdi + 0x360], eax
0x14287ede4:  803d6db2a40500       cmp       byte ptr [rip + 0x5a4b26d], 0
0x14287edeb:  0f84b3010000         je        0x14287efa4
0x14287edf1:  488bcf               mov       rcx, rdi
0x14287edf4:  e867f9ffff           call      0x14287e760
0x14287edf9:  84c0                 test      al, al
0x14287edfb:  0f85a3010000         jne       0x14287efa4
0x14287ee01:  488b05a8cc4e05       mov       rax, qword ptr [rip + 0x54ecca8]
0x14287ee08:  3c06                 cmp       al, 6
0x14287ee0a:  0f829c000000         jb        0x14287eeac
0x14287ee10:  48c1e808             shr       rax, 8
0x14287ee14:  3c03                 cmp       al, 3
0x14287ee16:  0f8290000000         jb        0x14287eeac
0x14287ee1c:  488d051443de04       lea       rax, [rip + 0x4de4314]
0x14287ee23:  4889442450           mov       qword ptr [rsp + 0x50], rax
0x14287ee28:  488b4c2450           mov       rcx, qword ptr [rsp + 0x50]
0x14287ee2d:  488d0d8c996b04       lea       rcx, [rip + 0x46b998c]
0x14287ee34:  48894d90             mov       qword ptr [rbp - 0x70], rcx
0x14287ee38:  48c7c0ffffffff       mov       rax, 0xffffffffffffffff
0x14287ee3f:  90                   nop       
0x14287ee40:  48ffc0               inc       rax
0x14287ee43:  803c0100             cmp       byte ptr [rcx + rax], 0
0x14287ee47:  75f7                 jne       0x14287ee40
0x14287ee49:  48894598             mov       qword ptr [rbp - 0x68], rax
0x14287ee4d:  8b05c5c24e05         mov       eax, dword ptr [rip + 0x54ec2c5]
0x14287ee53:  89442450             mov       dword ptr [rsp + 0x50], eax
0x14287ee57:  0f28442450           movaps    xmm0, xmmword ptr [rsp + 0x50]
0x14287ee5c:  660f7f8500010000     movdqa    xmmword ptr [rbp + 0x100], xmm0
0x14287ee64:  48c7458001000000     mov       qword ptr [rbp - 0x80], 1
0x14287ee6c:  488d8500010000       lea       rax, [rbp + 0x100]
0x14287ee73:  48894588             mov       qword ptr [rbp - 0x78], rax
0x14287ee77:  0f284580             movaps    xmm0, xmmword ptr [rbp - 0x80]
0x14287ee7b:  660f7f45d0           movdqa    xmmword ptr [rbp - 0x30], xmm0
0x14287ee80:  0f284d90             movaps    xmm1, xmmword ptr [rbp - 0x70]
0x14287ee84:  660f7f4de0           movdqa    xmmword ptr [rbp - 0x20], xmm1
0x14287ee89:  0f100520cc4e05       movups    xmm0, xmmword ptr [rip + 0x54ecc20]
0x14287ee90:  0f2945f0             movaps    xmmword ptr [rbp - 0x10], xmm0
0x14287ee94:  c644242001           mov       byte ptr [rsp + 0x20], 1
0x14287ee99:  4c8d4dd0             lea       r9, [rbp - 0x30]
0x14287ee9d:  4c8d45e0             lea       r8, [rbp - 0x20]
0x14287eea1:  b203                 mov       dl, 3
0x14287eea3:  488d4df0             lea       rcx, [rbp - 0x10]
0x14287eea7:  e8240c0e02           call      0x14495fad0
0x14287eeac:  4c89bdc0000000       mov       qword ptr [rbp + 0xc0], r15
0x14287eeb3:  4c89bdd0000000       mov       qword ptr [rbp + 0xd0], r15
0x14287eeba:  48c785d80000000f000000 mov       qword ptr [rbp + 0xd8], 0xf
0x14287eec5:  c685c000000000       mov       byte ptr [rbp + 0xc0], 0
0x14287eecc:  b940000000           mov       ecx, 0x40
0x14287eed1:  e8fab1f6fd           call      0x1407ea0d0
0x14287eed6:  488bc8               mov       rcx, rax
0x14287eed9:  48c785d000000035000000 mov       qword ptr [rbp + 0xd0], 0x35
0x14287eee4:  48c785d80000003f000000 mov       qword ptr [rbp + 0xd8], 0x3f
0x14287eeef:  0f100532996b04       movups    xmm0, xmmword ptr [rip + 0x46b9932]
0x14287eef6:  0f1100               movups    xmmword ptr [rax], xmm0
0x14287eef9:  0f100d38996b04       movups    xmm1, xmmword ptr [rip + 0x46b9938]
0x14287ef00:  0f114810             movups    xmmword ptr [rax + 0x10], xmm1
0x14287ef04:  0f10053d996b04       movups    xmm0, xmmword ptr [rip + 0x46b993d]
0x14287ef0b:  0f114020             movups    xmmword ptr [rax + 0x20], xmm0
0x14287ef0f:  8b0543996b04         mov       eax, dword ptr [rip + 0x46b9943]
0x14287ef15:  894130               mov       dword ptr [rcx + 0x30], eax
0x14287ef18:  0fb6053d996b04       movzx     eax, byte ptr [rip + 0x46b993d]
0x14287ef1f:  884134               mov       byte ptr [rcx + 0x34], al
0x14287ef22:  c6413500             mov       byte ptr [rcx + 0x35], 0
0x14287ef26:  48898dc0000000       mov       qword ptr [rbp + 0xc0], rcx
0x14287ef2d:  4c8d85c0000000       lea       r8, [rbp + 0xc0]
0x14287ef34:  488d9580000000       lea       rdx, [rbp + 0x80]
0x14287ef3b:  488d4d30             lea       rcx, [rbp + 0x30]
0x14287ef3f:  e8ec6094fe           call      0x1411c5030
0x14287ef44:  488b08               mov       rcx, qword ptr [rax]
0x14287ef47:  c7413001000000       mov       dword ptr [rcx + 0x30], 1
0x14287ef4e:  488b85d8000000       mov       rax, qword ptr [rbp + 0xd8]
0x14287ef55:  4883f810             cmp       rax, 0x10
0x14287ef59:  7230                 jb        0x14287ef8b
0x14287ef5b:  48ffc0               inc       rax
0x14287ef5e:  488b8dc0000000       mov       rcx, qword ptr [rbp + 0xc0]
0x14287ef65:  488bd1               mov       rdx, rcx
0x14287ef68:  483d00100000         cmp       rax, 0x1000
0x14287ef6e:  7215                 jb        0x14287ef85
0x14287ef70:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x14287ef74:  482bd1               sub       rdx, rcx
0x14287ef77:  488d42f8             lea       rax, [rdx - 8]
0x14287ef7b:  4883f81f             cmp       rax, 0x1f
0x14287ef7f:  0f8740060000         ja        0x14287f5c5
0x14287ef85:  e826410c02           call      0x1449430b0
0x14287ef8a:  90                   nop       
0x14287ef8b:  4c89bdd0000000       mov       qword ptr [rbp + 0xd0], r15
0x14287ef92:  48c785d80000000f000000 mov       qword ptr [rbp + 0xd8], 0xf
0x14287ef9d:  c685c000000000       mov       byte ptr [rbp + 0xc0], 0
0x14287efa4:  8b870c010000         mov       eax, dword ptr [rdi + 0x10c]
0x14287efaa:  90                   nop       
0x14287efab:  85c0                 test      eax, eax
0x14287efad:  0f8463010000         je        0x14287f116
0x14287efb3:  488d8fe80a0000       lea       rcx, [rdi + 0xae8]
0x14287efba:  8b15c8bb4e05         mov       edx, dword ptr [rip + 0x54ebbc8]
0x14287efc0:  e89b1f1a00           call      0x142a20f60
0x14287efc5:  85c0                 test      eax, eax
0x14287efc7:  0f8449010000         je        0x14287f116
0x14287efcd:  488b05dcca4e05       mov       rax, qword ptr [rip + 0x54ecadc]
0x14287efd4:  3c06                 cmp       al, 6
0x14287efd6:  726b                 jb        0x14287f043
0x14287efd8:  48c1e808             shr       rax, 8
0x14287efdc:  3c03                 cmp       al, 3
0x14287efde:  7263                 jb        0x14287f043
0x14287efe0:  488d057eefdf04       lea       rax, [rip + 0x4dfef7e]
0x14287efe7:  4889442450           mov       qword ptr [rsp + 0x50], rax
0x14287efec:  488b5c2450           mov       rbx, qword ptr [rsp + 0x50]
0x14287eff1:  488d4c2470           lea       rcx, [rsp + 0x70]
0x14287eff6:  e8058a0c02           call      0x144947a00
0x14287effb:  f20f10442470         movsd     xmm0, qword ptr [rsp + 0x70]
0x14287f001:  f20f5c442460         subsd     xmm0, qword ptr [rsp + 0x60]
0x14287f007:  f20f59c7             mulsd     xmm0, xmm7
0x14287f00b:  f20f2cc0             cvttsd2si eax, xmm0
0x14287f00f:  4c63c8               movsxd    r9, eax
0x14287f012:  4c630597bb4e05       movsxd    r8, dword ptr [rip + 0x54ebb97]
0x14287f019:  0f100590ca4e05       movups    xmm0, xmmword ptr [rip + 0x54eca90]
0x14287f020:  0f294500             movaps    xmmword ptr [rbp], xmm0
0x14287f024:  4c897c2430           mov       qword ptr [rsp + 0x30], r15
0x14287f029:  4c897c2428           mov       qword ptr [rsp + 0x28], r15
0x14287f02e:  4c897c2420           mov       qword ptr [rsp + 0x20], r15
0x14287f033:  488d93bba78bff       lea       rdx, [rbx - 0x745845]
0x14287f03a:  488d4d00             lea       rcx, [rbp]
0x14287f03e:  e8dd0d0e02           call      0x14495fe20
0x14287f043:  4c89bde0000000       mov       qword ptr [rbp + 0xe0], r15
0x14287f04a:  4c89bdf0000000       mov       qword ptr [rbp + 0xf0], r15
0x14287f051:  48c785f80000000f000000 mov       qword ptr [rbp + 0xf8], 0xf
0x14287f05c:  c685e000000000       mov       byte ptr [rbp + 0xe0], 0
0x14287f063:  b930000000           mov       ecx, 0x30
0x14287f068:  e863b0f6fd           call      0x1407ea0d0
0x14287f06d:  488bc8               mov       rcx, rax
0x14287f070:  48c785f000000021000000 mov       qword ptr [rbp + 0xf0], 0x21
0x14287f07b:  48c785f80000002f000000 mov       qword ptr [rbp + 0xf8], 0x2f
0x14287f086:  0f100503976b04       movups    xmm0, xmmword ptr [rip + 0x46b9703]
0x14287f08d:  0f1100               movups    xmmword ptr [rax], xmm0
0x14287f090:  0f100d09976b04       movups    xmm1, xmmword ptr [rip + 0x46b9709]
0x14287f097:  0f114810             movups    xmmword ptr [rax + 0x10], xmm1
0x14287f09b:  0fb6050e976b04       movzx     eax, byte ptr [rip + 0x46b970e]
0x14287f0a2:  884120               mov       byte ptr [rcx + 0x20], al
0x14287f0a5:  c6412100             mov       byte ptr [rcx + 0x21], 0
0x14287f0a9:  48898de0000000       mov       qword ptr [rbp + 0xe0], rcx
0x14287f0b0:  4c8d85e0000000       lea       r8, [rbp + 0xe0]
0x14287f0b7:  488d9590000000       lea       rdx, [rbp + 0x90]
0x14287f0be:  488d4d30             lea       rcx, [rbp + 0x30]
0x14287f0c2:  e8695f94fe           call      0x1411c5030
0x14287f0c7:  488b08               mov       rcx, qword ptr [rax]
0x14287f0ca:  c7413001000000       mov       dword ptr [rcx + 0x30], 1
0x14287f0d1:  488b85f8000000       mov       rax, qword ptr [rbp + 0xf8]
0x14287f0d8:  4883f810             cmp       rax, 0x10
0x14287f0dc:  7230                 jb        0x14287f10e
0x14287f0de:  48ffc0               inc       rax
0x14287f0e1:  488b8de0000000       mov       rcx, qword ptr [rbp + 0xe0]
0x14287f0e8:  488bd1               mov       rdx, rcx
0x14287f0eb:  483d00100000         cmp       rax, 0x1000
0x14287f0f1:  7215                 jb        0x14287f108
0x14287f0f3:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x14287f0f7:  482bd1               sub       rdx, rcx
0x14287f0fa:  488d42f8             lea       rax, [rdx - 8]
0x14287f0fe:  4883f81f             cmp       rax, 0x1f
0x14287f102:  0f87c3040000         ja        0x14287f5cb
0x14287f108:  e8a33f0c02           call      0x1449430b0
0x14287f10d:  90                   nop       
0x14287f10e:  4532e4               xor       r12b, r12b
0x14287f111:  4488642440           mov       byte ptr [rsp + 0x40], r12b
0x14287f116:  48837d4000           cmp       qword ptr [rbp + 0x40], 0
0x14287f11b:  740b                 je        0x14287f128
0x14287f11d:  33d2                 xor       edx, edx
0x14287f11f:  488d4d30             lea       rcx, [rbp + 0x30]
0x14287f123:  e888743400           call      0x142bc65b0
0x14287f128:  488d1529c24e05       lea       rdx, [rip + 0x54ec229]
0x14287f12f:  488d8d30040000       lea       rcx, [rbp + 0x430]
0x14287f136:  e8d528f5fd           call      0x1407d1a10
0x14287f13b:  90                   nop       
0x14287f13c:  488d1d8d936b04       lea       rbx, [rip + 0x46b938d]
0x14287f143:  48895da0             mov       qword ptr [rbp - 0x60], rbx
0x14287f147:  48c745a80f000000     mov       qword ptr [rbp - 0x58], 0xf
0x14287f14f:  0f2845a0             movaps    xmm0, xmmword ptr [rbp - 0x60]
0x14287f153:  660f7f4510           movdqa    xmmword ptr [rbp + 0x10], xmm0
0x14287f158:  41b901000000         mov       r9d, 1
0x14287f15e:  440fb687a80d0000     movzx     r8d, byte ptr [rdi + 0xda8]
0x14287f166:  488d5510             lea       rdx, [rbp + 0x10]
0x14287f16a:  488d8d00070000       lea       rcx, [rbp + 0x700]
0x14287f171:  e8fa486500           call      0x142ed3a70
0x14287f176:  488b97e80f0000       mov       rdx, qword ptr [rdi + 0xfe8]
0x14287f17d:  4885d2               test      rdx, rdx
0x14287f180:  7459                 je        0x14287f1db
0x14287f182:  488b8ff00f0000       mov       rcx, qword ptr [rdi + 0xff0]
0x14287f189:  0f57c0               xorps     xmm0, xmm0
0x14287f18c:  4885c9               test      rcx, rcx
0x14287f18f:  7807                 js        0x14287f198
0x14287f191:  f3480f2ac1           cvtsi2ss  xmm0, rcx
0x14287f196:  eb15                 jmp       0x14287f1ad
0x14287f198:  488bc1               mov       rax, rcx
0x14287f19b:  48d1e8               shr       rax, 1
0x14287f19e:  83e101               and       ecx, 1
0x14287f1a1:  480bc1               or        rax, rcx
0x14287f1a4:  f3480f2ac0           cvtsi2ss  xmm0, rax
0x14287f1a9:  f30f58c0             addss     xmm0, xmm0
0x14287f1ad:  0f57c9               xorps     xmm1, xmm1
0x14287f1b0:  4885d2               test      rdx, rdx
0x14287f1b3:  780b                 js        0x14287f1c0
0x14287f1b5:  f3480f2aca           cvtsi2ss  xmm1, rdx
0x14287f1ba:  f30f5ec1             divss     xmm0, xmm1
0x14287f1be:  eb1e                 jmp       0x14287f1de
0x14287f1c0:  488bc2               mov       rax, rdx
0x14287f1c3:  48d1e8               shr       rax, 1
0x14287f1c6:  83e201               and       edx, 1
0x14287f1c9:  480bc2               or        rax, rdx
0x14287f1cc:  f3480f2ac8           cvtsi2ss  xmm1, rax
0x14287f1d1:  f30f58c9             addss     xmm1, xmm1
0x14287f1d5:  f30f5ec1             divss     xmm0, xmm1
0x14287f1d9:  eb03                 jmp       0x14287f1de
0x14287f1db:  0f28c6               movaps    xmm0, xmm6
0x14287f1de:  0f57c9               xorps     xmm1, xmm1
0x14287f1e1:  f30f5ac8             cvtss2sd  xmm1, xmm0
0x14287f1e5:  488d8d40070000       lea       rcx, [rbp + 0x740]
0x14287f1ec:  e84f736400           call      0x142ec6540
0x14287f1f1:  488d8d20070000       lea       rcx, [rbp + 0x720]
0x14287f1f8:  e843786400           call      0x142ec6a40
0x14287f1fd:  488d156cc14e05       lea       rdx, [rip + 0x54ec16c]
0x14287f204:  488d8d10010000       lea       rcx, [rbp + 0x110]
0x14287f20b:  e80028f5fd           call      0x1407d1a10
0x14287f210:  90                   nop       
0x14287f211:  48895db0             mov       qword ptr [rbp - 0x50], rbx
0x14287f215:  48c745b80f000000     mov       qword ptr [rbp - 0x48], 0xf
0x14287f21d:  0f2845b0             movaps    xmm0, xmmword ptr [rbp - 0x50]
0x14287f221:  660f7f4520           movdqa    xmmword ptr [rbp + 0x20], xmm0
0x14287f226:  41b901000000         mov       r9d, 1
0x14287f22c:  440fb687a80d0000     movzx     r8d, byte ptr [rdi + 0xda8]
0x14287f234:  488d5520             lea       rdx, [rbp + 0x20]
0x14287f238:  488d8de0030000       lea       rcx, [rbp + 0x3e0]
0x14287f23f:  e82c486500           call      0x142ed3a70
0x14287f244:  488b97e80f0000       mov       rdx, qword ptr [rdi + 0xfe8]
0x14287f24b:  4885d2               test      rdx, rdx
0x14287f24e:  7453                 je        0x14287f2a3
0x14287f250:  488b8ff80f0000       mov       rcx, qword ptr [rdi + 0xff8]
0x14287f257:  0f57f6               xorps     xmm6, xmm6
0x14287f25a:  4885c9               test      rcx, rcx
0x14287f25d:  7807                 js        0x14287f266
0x14287f25f:  f3480f2af1           cvtsi2ss  xmm6, rcx
0x14287f264:  eb15                 jmp       0x14287f27b
0x14287f266:  488bc1               mov       rax, rcx
0x14287f269:  48d1e8               shr       rax, 1
0x14287f26c:  83e101               and       ecx, 1
0x14287f26f:  480bc1               or        rax, rcx
0x14287f272:  f3480f2af0           cvtsi2ss  xmm6, rax
0x14287f277:  f30f58f6             addss     xmm6, xmm6
0x14287f27b:  0f57c0               xorps     xmm0, xmm0
0x14287f27e:  4885d2               test      rdx, rdx
0x14287f281:  7807                 js        0x14287f28a
0x14287f283:  f3480f2ac2           cvtsi2ss  xmm0, rdx
0x14287f288:  eb15                 jmp       0x14287f29f
0x14287f28a:  488bc2               mov       rax, rdx
0x14287f28d:  48d1e8               shr       rax, 1
0x14287f290:  83e201               and       edx, 1
0x14287f293:  480bc2               or        rax, rdx
0x14287f296:  f3480f2ac0           cvtsi2ss  xmm0, rax
0x14287f29b:  f30f58c0             addss     xmm0, xmm0
0x14287f29f:  f30f5ef0             divss     xmm6, xmm0
0x14287f2a3:  0f57c9               xorps     xmm1, xmm1
0x14287f2a6:  f30f5ace             cvtss2sd  xmm1, xmm6
0x14287f2aa:  488d8d20040000       lea       rcx, [rbp + 0x420]
0x14287f2b1:  e88a726400           call      0x142ec6540
0x14287f2b6:  488d8d00040000       lea       rcx, [rbp + 0x400]
0x14287f2bd:  e87e776400           call      0x142ec6a40
0x14287f2c2:  458bf7               mov       r14d, r15d
0x14287f2c5:  66443bbf12010000     cmp       r15w, word ptr [rdi + 0x112]
0x14287f2cd:  0f8323010000         jae       0x14287f3f6
0x14287f2d3:  498bf7               mov       rsi, r15
0x14287f2d6:  f20f103d429f9404     movsd     xmm7, qword ptr [rip + 0x4949f42]
0x14287f2de:  f20f1035a2a39404     movsd     xmm6, qword ptr [rip + 0x494a3a2]
0x14287f2e6:  49bc0000000000000080 movabs    r12, 0x8000000000000000
0x14287f2f0:  4963c6               movsxd    rax, r14d
0x14287f2f3:  4869c8d8160000       imul      rcx, rax, 0x16d8
0x14287f2fa:  48038f50030000       add       rcx, qword ptr [rdi + 0x350]
0x14287f301:  418bc7               mov       eax, r15d
0x14287f304:  8601                 xchg      byte ptr [rcx], al
0x14287f306:  488b8f50030000       mov       rcx, qword ptr [rdi + 0x350]
0x14287f30d:  488d1c31             lea       rbx, [rcx + rsi]
0x14287f311:  448bac3140160000     mov       r13d, dword ptr [rcx + rsi + 0x1640]
0x14287f319:  488d8b88010000       lea       rcx, [rbx + 0x188]
0x14287f320:  e83bb30200           call      0x1428aa660
0x14287f325:  803dacb1a40500       cmp       byte ptr [rip + 0x5a4b1ac], 0
0x14287f32c:  7447                 je        0x14287f375
0x14287f32e:  488b9b780d0000       mov       rbx, qword ptr [rbx + 0xd78]
0x14287f335:  488b03               mov       rax, qword ptr [rbx]
0x14287f338:  4c8b7810             mov       r15, qword ptr [rax + 0x10]
0x14287f33c:  e85f830c02           call      0x1449476a0
0x14287f341:  f20f59c7             mulsd     xmm0, xmm7
0x14287f345:  33c0                 xor       eax, eax
0x14287f347:  660f2fc6             comisd    xmm0, xmm6
0x14287f34b:  720d                 jb        0x14287f35a
0x14287f34d:  f20f5cc6             subsd     xmm0, xmm6
0x14287f351:  660f2fc6             comisd    xmm0, xmm6
0x14287f355:  7303                 jae       0x14287f35a
0x14287f357:  498bc4               mov       rax, r12
0x14287f35a:  f2480f2cd0           cvttsd2si rdx, xmm0
0x14287f35f:  4803d0               add       rdx, rax
0x14287f362:  458d45c6             lea       r8d, [r13 - 0x3a]
0x14287f366:  488bcb               mov       rcx, rbx
0x14287f369:  498bc7               mov       rax, r15
0x14287f36c:  ff15c6098c03         call      qword ptr [rip + 0x38c09c6]
0x14287f372:  4533ff               xor       r15d, r15d
0x14287f375:  488b8750030000       mov       rax, qword ptr [rdi + 0x350]
0x14287f37c:  4c89bc3050160000     mov       qword ptr [rax + rsi + 0x1650], r15
0x14287f384:  488b9c3058160000     mov       rbx, qword ptr [rax + rsi + 0x1658]
0x14287f38c:  4c89bc3058160000     mov       qword ptr [rax + rsi + 0x1658], r15
0x14287f394:  4885db               test      rbx, rbx
0x14287f397:  743d                 je        0x14287f3d6
0x14287f399:  b8ffffffff           mov       eax, 0xffffffff
0x14287f39e:  f00fc14308           lock xadd dword ptr [rbx + 8], eax
0x14287f3a3:  83f801               cmp       eax, 1
0x14287f3a6:  752e                 jne       0x14287f3d6
0x14287f3a8:  488b03               mov       rax, qword ptr [rbx]
0x14287f3ab:  488bcb               mov       rcx, rbx
0x14287f3ae:  488b00               mov       rax, qword ptr [rax]
0x14287f3b1:  ff1581098c03         call      qword ptr [rip + 0x38c0981]
0x14287f3b7:  b8ffffffff           mov       eax, 0xffffffff
0x14287f3bc:  f00fc1430c           lock xadd dword ptr [rbx + 0xc], eax
0x14287f3c1:  83f801               cmp       eax, 1
0x14287f3c4:  7510                 jne       0x14287f3d6
0x14287f3c6:  488b03               mov       rax, qword ptr [rbx]
0x14287f3c9:  488bcb               mov       rcx, rbx
0x14287f3cc:  488b4008             mov       rax, qword ptr [rax + 8]
0x14287f3d0:  ff1562098c03         call      qword ptr [rip + 0x38c0962]
0x14287f3d6:  41ffc6               inc       r14d
0x14287f3d9:  4881c6d8160000       add       rsi, 0x16d8
0x14287f3e0:  0fb78712010000       movzx     eax, word ptr [rdi + 0x112]
0x14287f3e7:  443bf0               cmp       r14d, eax
0x14287f3ea:  0f8c00ffffff         jl        0x14287f2f0
0x14287f3f0:  440fb6642440         movzx     r12d, byte ptr [rsp + 0x40]
0x14287f3f6:  664489bf12010000     mov       word ptr [rdi + 0x112], r15w
0x14287f3fe:  488bcf               mov       rcx, rdi
0x14287f401:  e8daf1ffff           call      0x14287e5e0
0x14287f406:  488bcf               mov       rcx, rdi
0x14287f409:  e8d2c70000           call      0x14288bbe0
0x14287f40e:  488bcf               mov       rcx, rdi
0x14287f411:  e8aaaa0000           call      0x142889ec0
0x14287f416:  488bcf               mov       rcx, rdi
0x14287f419:  e802ac0000           call      0x14288a020
0x14287f41e:  488d8fb0070000       lea       rcx, [rdi + 0x7b0]
0x14287f425:  e8c6310200           call      0x1428a25f0
0x14287f42a:  488bcf               mov       rcx, rdi
0x14287f42d:  e80ead0000           call      0x14288a140
0x14287f432:  48c7874c04000000000000 mov       qword ptr [rdi + 0x44c], 0
0x14287f43d:  488b8f50030000       mov       rcx, qword ptr [rdi + 0x350]
0x14287f444:  4c89bf50030000       mov       qword ptr [rdi + 0x350], r15
0x14287f44b:  4885c9               test      rcx, rcx
0x14287f44e:  7422                 je        0x14287f472
0x14287f450:  488d59f8             lea       rbx, [rcx - 8]
0x14287f454:  4c8d0d85010000       lea       r9, [rip + 0x185]
0x14287f45b:  4c8b03               mov       r8, qword ptr [rbx]
0x14287f45e:  bad8160000           mov       edx, 0x16d8
0x14287f463:  e848222a03           call      0x145b216b0
0x14287f468:  90                   nop       
0x14287f469:  488bcb               mov       rcx, rbx
0x14287f46c:  e83f3c0c02           call      0x1449430b0
0x14287f471:  90                   nop       
0x14287f472:  488b8f58030000       mov       rcx, qword ptr [rdi + 0x358]
0x14287f479:  e8323c0c02           call      0x1449430b0
0x14287f47e:  90                   nop       
0x14287f47f:  4c89bf58030000       mov       qword ptr [rdi + 0x358], r15
0x14287f486:  488d8f88030000       lea       rcx, [rdi + 0x388]
0x14287f48d:  e8ae230200           call      0x1428a1840
0x14287f492:  90                   nop       
0x14287f493:  488b8f80030000       mov       rcx, qword ptr [rdi + 0x380]
0x14287f49a:  e8113c0c02           call      0x1449430b0
0x14287f49f:  90                   nop       
0x14287f4a0:  4c89bf80030000       mov       qword ptr [rdi + 0x380], r15
0x14287f4a7:  488d8fd80c0000       lea       rcx, [rdi + 0xcd8]
0x14287f4ae:  e8fd422a03           call      0x145b237b0
0x14287f4b3:  85c0                 test      eax, eax
0x14287f4b5:  0f85e2000000         jne       0x14287f59d
0x14287f4bb:  c787280d000001000000 mov       dword ptr [rdi + 0xd28], 1
0x14287f4c5:  488d8fd80c0000       lea       rcx, [rdi + 0xcd8]
0x14287f4cc:  e83f432a03           call      0x145b23810
0x14287f4d1:  488b8f000f0000       mov       rcx, qword ptr [rdi + 0xf00]
0x14287f4d8:  4885c9               test      rcx, rcx
0x14287f4db:  740e                 je        0x14287f4eb
0x14287f4dd:  488b01               mov       rax, qword ptr [rcx]
0x14287f4e0:  488b4018             mov       rax, qword ptr [rax + 0x18]
0x14287f4e4:  ff154e088c03         call      qword ptr [rip + 0x38c084e]
0x14287f4ea:  90                   nop       
0x14287f4eb:  488b95e8030000       mov       rdx, qword ptr [rbp + 0x3e8]
0x14287f4f2:  4885d2               test      rdx, rdx
0x14287f4f5:  740c                 je        0x14287f503
0x14287f4f7:  488d8de0030000       lea       rcx, [rbp + 0x3e0]
0x14287f4fe:  e85d51f6fd           call      0x1407e4660
0x14287f503:  488d8de0030000       lea       rcx, [rbp + 0x3e0]
0x14287f50a:  e82121f5fd           call      0x1407d1630
0x14287f50f:  488d8d38010000       lea       rcx, [rbp + 0x138]
0x14287f516:  e8c564f6fd           call      0x1407e59e0
0x14287f51b:  90                   nop       
0x14287f51c:  488b9508070000       mov       rdx, qword ptr [rbp + 0x708]
0x14287f523:  4885d2               test      rdx, rdx
0x14287f526:  740c                 je        0x14287f534
0x14287f528:  488d8d00070000       lea       rcx, [rbp + 0x700]
0x14287f52f:  e82c51f6fd           call      0x1407e4660
0x14287f534:  488d8d00070000       lea       rcx, [rbp + 0x700]
0x14287f53b:  e8f020f5fd           call      0x1407d1630
0x14287f540:  488d8d58040000       lea       rcx, [rbp + 0x458]
0x14287f547:  e89464f6fd           call      0x1407e59e0
0x14287f54c:  90                   nop       
0x14287f54d:  488d4d48             lea       rcx, [rbp + 0x48]
0x14287f551:  e84a34f6fd           call      0x1407e29a0
0x14287f556:  488d4d38             lea       rcx, [rbp + 0x38]
0x14287f55a:  e8d138f6fd           call      0x1407e2e30
0x14287f55f:  410fb6c4             movzx     eax, r12b
0x14287f563:  488b8d50070000       mov       rcx, qword ptr [rbp + 0x750]
0x14287f56a:  4833cc               xor       rcx, rsp
0x14287f56d:  e86e202a03           call      0x145b215e0
0x14287f572:  4c8d9c2480080000     lea       r11, [rsp + 0x880]
0x14287f57a:  498b5b38             mov       rbx, qword ptr [r11 + 0x38]
0x14287f57e:  498b7340             mov       rsi, qword ptr [r11 + 0x40]
0x14287f582:  498b7b48             mov       rdi, qword ptr [r11 + 0x48]
0x14287f586:  410f2873f0           movaps    xmm6, xmmword ptr [r11 - 0x10]
0x14287f58b:  410f287be0           movaps    xmm7, xmmword ptr [r11 - 0x20]
0x14287f590:  498be3               mov       rsp, r11
0x14287f593:  415f                 pop       r15
0x14287f595:  415e                 pop       r14
0x14287f597:  415d                 pop       r13
0x14287f599:  415c                 pop       r12
0x14287f59b:  5d                   pop       rbp
0x14287f59c:  c3                   ret       
0x14287f59d:  8bc8                 mov       ecx, eax
0x14287f59f:  e8dc472a03           call      0x145b23d80
0x14287f5a4:  90                   nop       
0x14287f5a5:  8bc8                 mov       ecx, eax
0x14287f5a7:  e8d4472a03           call      0x145b23d80
0x14287f5ac:  cc                   int3      
0x14287f5ad:  488d15ec8f6b04       lea       rdx, [rip + 0x46b8fec]
0x14287f5b4:  b903000000           mov       ecx, 3
0x14287f5b9:  e8c2f60d02           call      0x14495ec80
0x14287f5be:  cc                   int3      
0x14287f5bf:  e85c1f2d03           call      0x145b51520
0x14287f5c4:  cc                   int3      
0x14287f5c5:  e8561f2d03           call      0x145b51520
0x14287f5ca:  cc                   int3      
0x14287f5cb:  e8501f2d03           call      0x145b51520
0x14287f5d0:  cc                   int3      
0x14287f5d1:  cc                   int3      
0x14287f5d2:  cc                   int3      
0x14287f5d3:  cc                   int3      
0x14287f5d4:  cc                   int3      
0x14287f5d5:  cc                   int3      
0x14287f5d6:  cc                   int3      
0x14287f5d7:  cc                   int3      
0x14287f5d8:  cc                   int3      
0x14287f5d9:  cc                   int3      
0x14287f5da:  cc                   int3      
0x14287f5db:  cc                   int3      
0x14287f5dc:  cc                   int3      
0x14287f5dd:  cc                   int3      
0x14287f5de:  cc                   int3      
0x14287f5df:  cc                   int3      
