; function_of: vtab.ClientRuppGenerator
; xref site 0x142147ead -> vtab.ClientRuppGenerator @ 0x146c98840
; range 0x142147660 .. 0x142147fb0  (2384 bytes)

0x000142147660:  488b01                mov       rax, qword ptr [rcx]
0x000142147663:  c6405000              mov       byte ptr [rax + 0x50], 0
0x000142147667:  488b09                mov       rcx, qword ptr [rcx]
0x00014214766a:  e931170000            jmp       0x142148da0
0x00014214766f:  cc                    int3      
0x000142147670:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142147675:  57                    push      rdi
0x000142147676:  4881ecc0000000        sub       rsp, 0xc0
0x00014214767d:  488bfa                mov       rdi, rdx
0x000142147680:  488bd9                mov       rbx, rcx
0x000142147683:  488b4920              mov       rcx, qword ptr [rcx + 0x20]
0x000142147687:  4c8b4310              mov       r8, qword ptr [rbx + 0x10]
0x00014214768b:  493bc8                cmp       rcx, r8
0x00014214768e:  0f8532010000          jne       0x1421477c6
0x000142147694:  488d542430            lea       rdx, [rsp + 0x30]
0x000142147699:  488bcb                mov       rcx, rbx
0x00014214769c:  e87f190000            call      0x142149020
0x0001421476a1:  90                    nop       
0x0001421476a2:  488bd7                mov       rdx, rdi
0x0001421476a5:  488d4c2430            lea       rcx, [rsp + 0x30]
0x0001421476aa:  e8c1ffffff            call      0x142147670
0x0001421476af:  488b5320              mov       rdx, qword ptr [rbx + 0x20]
0x0001421476b3:  4885d2                test      rdx, rdx
0x0001421476b6:  0f848b000000          je        0x142147747
0x0001421476bc:  0f1f4000              nop       dword ptr [rax]
0x0001421476c0:  488b4318              mov       rax, qword ptr [rbx + 0x18]
0x0001421476c4:  48ffc8                dec       rax
0x0001421476c7:  4803c2                add       rax, rdx
0x0001421476ca:  33d2                  xor       edx, edx
0x0001421476cc:  48f77310              div       qword ptr [rbx + 0x10]
0x0001421476d0:  486bd268              imul      rdx, rdx, 0x68
0x0001421476d4:  48035308              add       rdx, qword ptr [rbx + 8]
0x0001421476d8:  488b02                mov       rax, qword ptr [rdx]
0x0001421476db:  4889442458            mov       qword ptr [rsp + 0x58], rax
0x0001421476e0:  488b4208              mov       rax, qword ptr [rdx + 8]
0x0001421476e4:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x0001421476e9:  4883c210              add       rdx, 0x10
0x0001421476ed:  488d4c2468            lea       rcx, [rsp + 0x68]
0x0001421476f2:  e869e50c03            call      0x145215c60
0x0001421476f7:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x0001421476fb:  488b4320              mov       rax, qword ptr [rbx + 0x20]
0x0001421476ff:  48ffc9                dec       rcx
0x000142147702:  4803c1                add       rax, rcx
0x000142147705:  33d2                  xor       edx, edx
0x000142147707:  48f77310              div       qword ptr [rbx + 0x10]
0x00014214770b:  486bca68              imul      rcx, rdx, 0x68
0x00014214770f:  4883c110              add       rcx, 0x10
0x000142147713:  48034b08              add       rcx, qword ptr [rbx + 8]
0x000142147717:  e814a7fdff            call      0x142121e30
0x00014214771c:  48ff4b20              dec       qword ptr [rbx + 0x20]
0x000142147720:  488d542458            lea       rdx, [rsp + 0x58]
0x000142147725:  488d4c2430            lea       rcx, [rsp + 0x30]
0x00014214772a:  e8f1330000            call      0x14214ab20
0x00014214772f:  90                    nop       
0x000142147730:  488d4c2468            lea       rcx, [rsp + 0x68]
0x000142147735:  e8f6a6fdff            call      0x142121e30
0x00014214773a:  488b5320              mov       rdx, qword ptr [rbx + 0x20]
0x00014214773e:  4885d2                test      rdx, rdx
0x000142147741:  0f8579ffffff          jne       0x1421476c0
0x000142147747:  4c8b5308              mov       r10, qword ptr [rbx + 8]
0x00014214774b:  488b442438            mov       rax, qword ptr [rsp + 0x38]
0x000142147750:  48894308              mov       qword ptr [rbx + 8], rax
0x000142147754:  4c89542438            mov       qword ptr [rsp + 0x38], r10
0x000142147759:  4c8b4310              mov       r8, qword ptr [rbx + 0x10]
0x00014214775d:  488b442440            mov       rax, qword ptr [rsp + 0x40]
0x000142147762:  48894310              mov       qword ptr [rbx + 0x10], rax
0x000142147766:  4c89442440            mov       qword ptr [rsp + 0x40], r8
0x00014214776b:  488b4b18              mov       rcx, qword ptr [rbx + 0x18]
0x00014214776f:  488b442448            mov       rax, qword ptr [rsp + 0x48]
0x000142147774:  48894318              mov       qword ptr [rbx + 0x18], rax
0x000142147778:  48894c2448            mov       qword ptr [rsp + 0x48], rcx
0x00014214777d:  488b442450            mov       rax, qword ptr [rsp + 0x50]
0x000142147782:  48894320              mov       qword ptr [rbx + 0x20], rax
0x000142147786:  4889542450            mov       qword ptr [rsp + 0x50], rdx
0x00014214778b:  4d85d2                test      r10, r10
0x00014214778e:  7425                  je        0x1421477b5
0x000142147790:  4d85c0                test      r8, r8
0x000142147793:  7420                  je        0x1421477b5
0x000142147795:  488b4c2430            mov       rcx, qword ptr [rsp + 0x30]
0x00014214779a:  488b01                mov       rax, qword ptr [rcx]
0x00014214779d:  4d6bc068              imul      r8, r8, 0x68
0x0001421477a1:  41b908000000          mov       r9d, 8
0x0001421477a7:  498bd2                mov       rdx, r10
0x0001421477aa:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x0001421477ae:  ff158485ff03          call      qword ptr [rip + 0x3ff8584]
0x0001421477b4:  90                    nop       
0x0001421477b5:  488b9c24d0000000      mov       rbx, qword ptr [rsp + 0xd0]
0x0001421477bd:  4881c4c0000000        add       rsp, 0xc0
0x0001421477c4:  5f                    pop       rdi
0x0001421477c5:  c3                    ret       
0x0001421477c6:  48ffc1                inc       rcx
0x0001421477c9:  48894b20              mov       qword ptr [rbx + 0x20], rcx
0x0001421477cd:  488b4318              mov       rax, qword ptr [rbx + 0x18]
0x0001421477d1:  48ffc9                dec       rcx
0x0001421477d4:  4803c1                add       rax, rcx
0x0001421477d7:  33d2                  xor       edx, edx
0x0001421477d9:  49f7f0                div       r8
0x0001421477dc:  486bca68              imul      rcx, rdx, 0x68
0x0001421477e0:  48034b08              add       rcx, qword ptr [rbx + 8]
0x0001421477e4:  488b07                mov       rax, qword ptr [rdi]
0x0001421477e7:  488901                mov       qword ptr [rcx], rax
0x0001421477ea:  488b4708              mov       rax, qword ptr [rdi + 8]
0x0001421477ee:  48894108              mov       qword ptr [rcx + 8], rax
0x0001421477f2:  488d5710              lea       rdx, [rdi + 0x10]
0x0001421477f6:  4883c110              add       rcx, 0x10
0x0001421477fa:  488b9c24d0000000      mov       rbx, qword ptr [rsp + 0xd0]
0x000142147802:  4881c4c0000000        add       rsp, 0xc0
0x000142147809:  5f                    pop       rdi
0x00014214780a:  e951e40c03            jmp       0x145215c60
0x00014214780f:  cc                    int3      
0x000142147810:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142147815:  55                    push      rbp
0x000142147816:  56                    push      rsi
0x000142147817:  57                    push      rdi
0x000142147818:  4883ec40              sub       rsp, 0x40
0x00014214781c:  488bf2                mov       rsi, rdx
0x00014214781f:  488bf9                mov       rdi, rcx
0x000142147822:  b920040000            mov       ecx, 0x420
0x000142147827:  e8d4bf7f02            call      0x144943800
0x00014214782c:  488bd8                mov       rbx, rax
0x00014214782f:  4885c0                test      rax, rax
0x000142147832:  0f8402010000          je        0x14214793a
0x000142147838:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x00014214783d:  488d058c8fdb04        lea       rax, [rip + 0x4db8f8c]
0x000142147844:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000142147849:  48c744242811000000    mov       qword ptr [rsp + 0x28], 0x11
0x000142147852:  0f28442420            movaps    xmm0, xmmword ptr [rsp + 0x20]
0x000142147857:  660f7f442420          movdqa    xmmword ptr [rsp + 0x20], xmm0
0x00014214785d:  4c8d442420            lea       r8, [rsp + 0x20]
0x000142147862:  8b16                  mov       edx, dword ptr [rsi]
0x000142147864:  488bcb                mov       rcx, rbx
0x000142147867:  e88476feff            call      0x14212eef0
0x00014214786c:  33ed                  xor       ebp, ebp
0x00014214786e:  4889aba0030000        mov       qword ptr [rbx + 0x3a0], rbp
0x000142147875:  4889aba8030000        mov       qword ptr [rbx + 0x3a8], rbp
0x00014214787c:  4889abb0030000        mov       qword ptr [rbx + 0x3b0], rbp
0x000142147883:  488d056607b504        lea       rax, [rip + 0x4b50766]
0x00014214788a:  488903                mov       qword ptr [rbx], rax
0x00014214788d:  4889abc4030000        mov       qword ptr [rbx + 0x3c4], rbp
0x000142147894:  4889abb8030000        mov       qword ptr [rbx + 0x3b8], rbp
0x00014214789b:  89abc0030000          mov       dword ptr [rbx + 0x3c0], ebp
0x0001421478a1:  48c783d003000000010000  mov       qword ptr [rbx + 0x3d0], 0x100
0x0001421478ac:  0fb605c5291606        movzx     eax, byte ptr [rip + 0x61629c5]
0x0001421478b3:  8883d8030000          mov       byte ptr [rbx + 0x3d8], al
0x0001421478b9:  486305a078c105        movsxd    rax, dword ptr [rip + 0x5c178a0]
0x0001421478c0:  488983e0030000        mov       qword ptr [rbx + 0x3e0], rax
0x0001421478c7:  4889abe8030000        mov       qword ptr [rbx + 0x3e8], rbp
0x0001421478ce:  488db3f0030000        lea       rsi, [rbx + 0x3f0]
0x0001421478d5:  4889742478            mov       qword ptr [rsp + 0x78], rsi
0x0001421478da:  48892e                mov       qword ptr [rsi], rbp
0x0001421478dd:  48896e08              mov       qword ptr [rsi + 8], rbp
0x0001421478e1:  48896e10              mov       qword ptr [rsi + 0x10], rbp
0x0001421478e5:  48896e18              mov       qword ptr [rsi + 0x18], rbp
0x0001421478e9:  48896e20              mov       qword ptr [rsi + 0x20], rbp
0x0001421478ed:  8d4d10                lea       ecx, [rbp + 0x10]
0x0001421478f0:  e80bbf7f02            call      0x144943800
0x0001421478f5:  4885c0                test      rax, rax
0x0001421478f8:  7424                  je        0x14214791e
0x0001421478fa:  48896808              mov       qword ptr [rax + 8], rbp
0x0001421478fe:  488906                mov       qword ptr [rsi], rax
0x000142147901:  488930                mov       qword ptr [rax], rsi
0x000142147904:  4889ab18040000        mov       qword ptr [rbx + 0x418], rbp
0x00014214790b:  48891f                mov       qword ptr [rdi], rbx
0x00014214790e:  488bc7                mov       rax, rdi
0x000142147911:  488b5c2460            mov       rbx, qword ptr [rsp + 0x60]
0x000142147916:  4883c440              add       rsp, 0x40
0x00014214791a:  5f                    pop       rdi
0x00014214791b:  5e                    pop       rsi
0x00014214791c:  5d                    pop       rbp
0x00014214791d:  c3                    ret       
0x00014214791e:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142147923:  e8c83467fe            call      0x1407badf0
0x000142147928:  488d1511f3bb05        lea       rdx, [rip + 0x5bbf311]
0x00014214792f:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142147934:  e817b79f03            call      0x145b43050
0x000142147939:  90                    nop       
0x00014214793a:  488d4c2420            lea       rcx, [rsp + 0x20]
0x00014214793f:  e8ac3467fe            call      0x1407badf0
0x000142147944:  488d15f5f2bb05        lea       rdx, [rip + 0x5bbf2f5]
0x00014214794b:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142147950:  e8fbb69f03            call      0x145b43050
0x000142147955:  cc                    int3      
0x000142147956:  cc                    int3      
0x000142147957:  cc                    int3      
0x000142147958:  cc                    int3      
0x000142147959:  cc                    int3      
0x00014214795a:  cc                    int3      
0x00014214795b:  cc                    int3      
0x00014214795c:  cc                    int3      
0x00014214795d:  cc                    int3      
0x00014214795e:  cc                    int3      
0x00014214795f:  cc                    int3      
0x000142147960:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x000142147965:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x00014214796a:  48894c2408            mov       qword ptr [rsp + 8], rcx
0x00014214796f:  57                    push      rdi
0x000142147970:  4883ec20              sub       rsp, 0x20
0x000142147974:  488bf2                mov       rsi, rdx
0x000142147977:  488bf9                mov       rdi, rcx
0x00014214797a:  c6416801              mov       byte ptr [rcx + 0x68], 1
0x00014214797e:  488b5908              mov       rbx, qword ptr [rcx + 8]
0x000142147982:  483b5f10              cmp       rbx, qword ptr [rdi + 0x10]
0x000142147986:  742a                  je        0x1421479b2
0x000142147988:  488b5318              mov       rdx, qword ptr [rbx + 0x18]
0x00014214798c:  0fb6c2                movzx     eax, dl
0x00014214798f:  d0f8                  sar       al, 1
0x000142147991:  a801                  test      al, 1
0x000142147993:  488bcb                mov       rcx, rbx
0x000142147996:  7503                  jne       0x14214799b
0x000142147998:  488b0b                mov       rcx, qword ptr [rbx]
0x00014214799b:  4883e2f8              and       rdx, 0xfffffffffffffff8
0x00014214799f:  488b02                mov       rax, qword ptr [rdx]
0x0001421479a2:  488bd6                mov       rdx, rsi
0x0001421479a5:  ff158d83ff03          call      qword ptr [rip + 0x3ff838d]
0x0001421479ab:  90                    nop       
0x0001421479ac:  4883c320              add       rbx, 0x20
0x0001421479b0:  ebd0                  jmp       0x142147982
0x0001421479b2:  c6476800              mov       byte ptr [rdi + 0x68], 0
0x0001421479b6:  488bcf                mov       rcx, rdi
0x0001421479b9:  488b5c2438            mov       rbx, qword ptr [rsp + 0x38]
0x0001421479be:  488b742440            mov       rsi, qword ptr [rsp + 0x40]
0x0001421479c3:  4883c420              add       rsp, 0x20
0x0001421479c7:  5f                    pop       rdi
0x0001421479c8:  e973140000            jmp       0x142148e40
0x0001421479cd:  cc                    int3      
0x0001421479ce:  cc                    int3      
0x0001421479cf:  cc                    int3      
0x0001421479d0:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x0001421479d5:  48896c2418            mov       qword ptr [rsp + 0x18], rbp
0x0001421479da:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x0001421479df:  57                    push      rdi
0x0001421479e0:  4883ec40              sub       rsp, 0x40
0x0001421479e4:  488bf1                mov       rsi, rcx
0x0001421479e7:  b930020000            mov       ecx, 0x230
0x0001421479ec:  e80fbe7f02            call      0x144943800
0x0001421479f1:  488bf8                mov       rdi, rax
0x0001421479f4:  4885c0                test      rax, rax
0x0001421479f7:  0f84b3010000          je        0x142147bb0
0x0001421479fd:  488d480d              lea       rcx, [rax + 0xd]
0x000142147a01:  33d2                  xor       edx, edx
0x000142147a03:  41b823020000          mov       r8d, 0x223
0x000142147a09:  e8b2a79f03            call      0x145b421c0
0x000142147a0e:  48c707ffffffff        mov       qword ptr [rdi], 0xffffffffffffffff
0x000142147a15:  33ed                  xor       ebp, ebp
0x000142147a17:  896f08                mov       dword ptr [rdi + 8], ebp
0x000142147a1a:  40886f0c              mov       byte ptr [rdi + 0xc], bpl
0x000142147a1e:  40886f18              mov       byte ptr [rdi + 0x18], bpl
0x000142147a22:  488d5f20              lea       rbx, [rdi + 0x20]
0x000142147a26:  e85518ec00            call      0x143009280
0x000142147a2b:  90                    nop       
0x000142147a2c:  48894310              mov       qword ptr [rbx + 0x10], rax
0x000142147a30:  488d4b18              lea       rcx, [rbx + 0x18]
0x000142147a34:  488919                mov       qword ptr [rcx], rbx
0x000142147a37:  48896908              mov       qword ptr [rcx + 8], rbp
0x000142147a3b:  48896910              mov       qword ptr [rcx + 0x10], rbp
0x000142147a3f:  48896918              mov       qword ptr [rcx + 0x18], rbp
0x000142147a43:  488d05f6d2b404        lea       rax, [rip + 0x4b4d2f6]
0x000142147a4a:  488903                mov       qword ptr [rbx], rax
0x000142147a4d:  488b4118              mov       rax, qword ptr [rcx + 0x18]
0x000142147a51:  482b4108              sub       rax, qword ptr [rcx + 8]
0x000142147a55:  4883f807              cmp       rax, 7
0x000142147a59:  7309                  jae       0x142147a64
0x000142147a5b:  8d5507                lea       edx, [rbp + 7]
0x000142147a5e:  e8edeeffff            call      0x142146950
0x000142147a63:  90                    nop       
0x000142147a64:  48896f58              mov       qword ptr [rdi + 0x58], rbp
0x000142147a68:  c6476400              mov       byte ptr [rdi + 0x64], 0
0x000142147a6c:  48896f70              mov       qword ptr [rdi + 0x70], rbp
0x000142147a70:  48896f78              mov       qword ptr [rdi + 0x78], rbp
0x000142147a74:  4889af80000000        mov       qword ptr [rdi + 0x80], rbp
0x000142147a7b:  4889af88000000        mov       qword ptr [rdi + 0x88], rbp
0x000142147a82:  4889af90000000        mov       qword ptr [rdi + 0x90], rbp
0x000142147a89:  4889af98000000        mov       qword ptr [rdi + 0x98], rbp
0x000142147a90:  4889afa0000000        mov       qword ptr [rdi + 0xa0], rbp
0x000142147a97:  c687a800000000        mov       byte ptr [rdi + 0xa8], 0
0x000142147a9e:  0fb605b31f5306        movzx     eax, byte ptr [rip + 0x6531fb3]
0x000142147aa5:  8887b0000000          mov       byte ptr [rdi + 0xb0], al
0x000142147aab:  4889afb8000000        mov       qword ptr [rdi + 0xb8], rbp
0x000142147ab2:  c687c000000000        mov       byte ptr [rdi + 0xc0], 0
0x000142147ab9:  488d9fc8000000        lea       rbx, [rdi + 0xc8]
0x000142147ac0:  e8bb17ec00            call      0x143009280
0x000142147ac5:  90                    nop       
0x000142147ac6:  48898388000000        mov       qword ptr [rbx + 0x88], rax
0x000142147acd:  488d8b90000000        lea       rcx, [rbx + 0x90]
0x000142147ad4:  488919                mov       qword ptr [rcx], rbx
0x000142147ad7:  48896908              mov       qword ptr [rcx + 8], rbp
0x000142147adb:  48896910              mov       qword ptr [rcx + 0x10], rbp
0x000142147adf:  48896918              mov       qword ptr [rcx + 0x18], rbp
0x000142147ae3:  488d0596e0b404        lea       rax, [rip + 0x4b4e096]
0x000142147aea:  488903                mov       qword ptr [rbx], rax
0x000142147aed:  488b4118              mov       rax, qword ptr [rcx + 0x18]
0x000142147af1:  482b4108              sub       rax, qword ptr [rcx + 8]
0x000142147af5:  483d80000000          cmp       rax, 0x80
0x000142147afb:  730b                  jae       0x142147b08
0x000142147afd:  ba80000000            mov       edx, 0x80
0x000142147b02:  e849eeffff            call      0x142146950
0x000142147b07:  90                    nop       
0x000142147b08:  4889af78010000        mov       qword ptr [rdi + 0x178], rbp
0x000142147b0f:  8b05ab4ec105          mov       eax, dword ptr [rip + 0x5c14eab]
0x000142147b15:  898780010000          mov       dword ptr [rdi + 0x180], eax
0x000142147b1b:  c687b001000000        mov       byte ptr [rdi + 0x1b0], 0
0x000142147b22:  4889afb8010000        mov       qword ptr [rdi + 0x1b8], rbp
0x000142147b29:  c687c001000000        mov       byte ptr [rdi + 0x1c0], 0
0x000142147b30:  4889afc8010000        mov       qword ptr [rdi + 0x1c8], rbp
0x000142147b37:  4889afd0010000        mov       qword ptr [rdi + 0x1d0], rbp
0x000142147b3e:  e83d17ec00            call      0x143009280
0x000142147b43:  488987d8010000        mov       qword ptr [rdi + 0x1d8], rax
0x000142147b4a:  4889afe0010000        mov       qword ptr [rdi + 0x1e0], rbp
0x000142147b51:  4889afe8010000        mov       qword ptr [rdi + 0x1e8], rbp
0x000142147b58:  4889aff0010000        mov       qword ptr [rdi + 0x1f0], rbp
0x000142147b5f:  4889aff8010000        mov       qword ptr [rdi + 0x1f8], rbp
0x000142147b66:  4889af00020000        mov       qword ptr [rdi + 0x200], rbp
0x000142147b6d:  e80e17ec00            call      0x143009280
0x000142147b72:  48898708020000        mov       qword ptr [rdi + 0x208], rax
0x000142147b79:  4889af10020000        mov       qword ptr [rdi + 0x210], rbp
0x000142147b80:  4889af18020000        mov       qword ptr [rdi + 0x218], rbp
0x000142147b87:  4889af20020000        mov       qword ptr [rdi + 0x220], rbp
0x000142147b8e:  4889af28020000        mov       qword ptr [rdi + 0x228], rbp
0x000142147b95:  48893e                mov       qword ptr [rsi], rdi
0x000142147b98:  488bc6                mov       rax, rsi
0x000142147b9b:  488b5c2450            mov       rbx, qword ptr [rsp + 0x50]
0x000142147ba0:  488b6c2460            mov       rbp, qword ptr [rsp + 0x60]
0x000142147ba5:  488b742468            mov       rsi, qword ptr [rsp + 0x68]
0x000142147baa:  4883c440              add       rsp, 0x40
0x000142147bae:  5f                    pop       rdi
0x000142147baf:  c3                    ret       
0x000142147bb0:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142147bb5:  e8363267fe            call      0x1407badf0
0x000142147bba:  488d157ff0bb05        lea       rdx, [rip + 0x5bbf07f]
0x000142147bc1:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142147bc6:  e885b49f03            call      0x145b43050
0x000142147bcb:  cc                    int3      
0x000142147bcc:  cc                    int3      
0x000142147bcd:  cc                    int3      
0x000142147bce:  cc                    int3      
0x000142147bcf:  cc                    int3      
0x000142147bd0:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142147bd5:  4889742410            mov       qword ptr [rsp + 0x10], rsi
0x000142147bda:  57                    push      rdi
0x000142147bdb:  4883ec20              sub       rsp, 0x20
0x000142147bdf:  498bf8                mov       rdi, r8
0x000142147be2:  488bf2                mov       rsi, rdx
0x000142147be5:  488bd9                mov       rbx, rcx
0x000142147be8:  80b9a800000000        cmp       byte ptr [rcx + 0xa8], 0
0x000142147bef:  7419                  je        0x142147c0a
0x000142147bf1:  4883c150              add       rcx, 0x50
0x000142147bf5:  e8d6ac69fe            call      0x1407e28d0
0x000142147bfa:  488d4b20              lea       rcx, [rbx + 0x20]
0x000142147bfe:  e8bde4ffff            call      0x1421460c0
0x000142147c03:  c683a800000000        mov       byte ptr [rbx + 0xa8], 0
0x000142147c0a:  4533c9                xor       r9d, r9d
0x000142147c0d:  448b07                mov       r8d, dword ptr [rdi]
0x000142147c10:  0fb616                movzx     edx, byte ptr [rsi]
0x000142147c13:  488bcb                mov       rcx, rbx
0x000142147c16:  e825effeff            call      0x142136b40
0x000142147c1b:  48c78398000000ffffffff  mov       qword ptr [rbx + 0x98], 0xffffffffffffffff
0x000142147c26:  48c783a000000000000000  mov       qword ptr [rbx + 0xa0], 0
0x000142147c31:  c683a800000001        mov       byte ptr [rbx + 0xa8], 1
0x000142147c38:  488bc3                mov       rax, rbx
0x000142147c3b:  488b5c2430            mov       rbx, qword ptr [rsp + 0x30]
0x000142147c40:  488b742438            mov       rsi, qword ptr [rsp + 0x38]
0x000142147c45:  4883c420              add       rsp, 0x20
0x000142147c49:  5f                    pop       rdi
0x000142147c4a:  c3                    ret       
0x000142147c4b:  cc                    int3      
0x000142147c4c:  cc                    int3      
0x000142147c4d:  cc                    int3      
0x000142147c4e:  cc                    int3      
0x000142147c4f:  cc                    int3      
0x000142147c50:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142147c55:  4889742410            mov       qword ptr [rsp + 0x10], rsi
0x000142147c5a:  48897c2418            mov       qword ptr [rsp + 0x18], rdi
0x000142147c5f:  4156                  push      r14
0x000142147c61:  4883ec40              sub       rsp, 0x40
0x000142147c65:  498bf0                mov       rsi, r8
0x000142147c68:  4c8bf2                mov       r14, rdx
0x000142147c6b:  488bf9                mov       rdi, rcx
0x000142147c6e:  b9c0000000            mov       ecx, 0xc0
0x000142147c73:  e888bb7f02            call      0x144943800
0x000142147c78:  488bd8                mov       rbx, rax
0x000142147c7b:  4885c0                test      rax, rax
0x000142147c7e:  745e                  je        0x142147cde
0x000142147c80:  4889442468            mov       qword ptr [rsp + 0x68], rax
0x000142147c85:  41b901000000          mov       r9d, 1
0x000142147c8b:  448b06                mov       r8d, dword ptr [rsi]
0x000142147c8e:  410fb616              movzx     edx, byte ptr [r14]
0x000142147c92:  488bc8                mov       rcx, rax
0x000142147c95:  e8a6eefeff            call      0x142136b40
0x000142147c9a:  c7839800000000000080  mov       dword ptr [rbx + 0x98], 0x80000000
0x000142147ca4:  33c0                  xor       eax, eax
0x000142147ca6:  488983a0000000        mov       qword ptr [rbx + 0xa0], rax
0x000142147cad:  488983a8000000        mov       qword ptr [rbx + 0xa8], rax
0x000142147cb4:  488983b0000000        mov       qword ptr [rbx + 0xb0], rax
0x000142147cbb:  488983b8000000        mov       qword ptr [rbx + 0xb8], rax
0x000142147cc2:  48891f                mov       qword ptr [rdi], rbx
0x000142147cc5:  488bc7                mov       rax, rdi
0x000142147cc8:  488b5c2450            mov       rbx, qword ptr [rsp + 0x50]
0x000142147ccd:  488b742458            mov       rsi, qword ptr [rsp + 0x58]
0x000142147cd2:  488b7c2460            mov       rdi, qword ptr [rsp + 0x60]
0x000142147cd7:  4883c440              add       rsp, 0x40
0x000142147cdb:  415e                  pop       r14
0x000142147cdd:  c3                    ret       
0x000142147cde:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142147ce3:  e8083167fe            call      0x1407badf0
0x000142147ce8:  488d1551efbb05        lea       rdx, [rip + 0x5bbef51]
0x000142147cef:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142147cf4:  e857b39f03            call      0x145b43050
0x000142147cf9:  cc                    int3      
0x000142147cfa:  cc                    int3      
0x000142147cfb:  cc                    int3      
0x000142147cfc:  cc                    int3      
0x000142147cfd:  cc                    int3      
0x000142147cfe:  cc                    int3      
0x000142147cff:  cc                    int3      
0x000142147d00:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142147d05:  57                    push      rdi
0x000142147d06:  4883ec20              sub       rsp, 0x20
0x000142147d0a:  488bda                mov       rbx, rdx
0x000142147d0d:  488bf9                mov       rdi, rcx
0x000142147d10:  488b4908              mov       rcx, qword ptr [rcx + 8]
0x000142147d14:  4883c220              add       rdx, 0x20
0x000142147d18:  e823bcfeff            call      0x142133940
0x000142147d1d:  0f1003                movups    xmm0, xmmword ptr [rbx]
0x000142147d20:  4c8b07                mov       r8, qword ptr [rdi]
0x000142147d23:  410f1100              movups    xmmword ptr [r8], xmm0
0x000142147d27:  f20f104b10            movsd     xmm1, qword ptr [rbx + 0x10]
0x000142147d2c:  f2410f114810          movsd     qword ptr [r8 + 0x10], xmm1
0x000142147d32:  8b4318                mov       eax, dword ptr [rbx + 0x18]
0x000142147d35:  488b5c2430            mov       rbx, qword ptr [rsp + 0x30]
0x000142147d3a:  41894018              mov       dword ptr [r8 + 0x18], eax
0x000142147d3e:  488bc7                mov       rax, rdi
0x000142147d41:  4883c420              add       rsp, 0x20
0x000142147d45:  5f                    pop       rdi
0x000142147d46:  c3                    ret       
0x000142147d47:  cc                    int3      
0x000142147d48:  cc                    int3      
0x000142147d49:  cc                    int3      
0x000142147d4a:  cc                    int3      
0x000142147d4b:  cc                    int3      
0x000142147d4c:  cc                    int3      
0x000142147d4d:  cc                    int3      
0x000142147d4e:  cc                    int3      
0x000142147d4f:  cc                    int3      
0x000142147d50:  4881eca8000000        sub       rsp, 0xa8
0x000142147d57:  488b0592b9bc05        mov       rax, qword ptr [rip + 0x5bcb992]
0x000142147d5e:  4833c4                xor       rax, rsp
0x000142147d61:  4889842490000000      mov       qword ptr [rsp + 0x90], rax
0x000142147d69:  4983791810            cmp       qword ptr [r9 + 0x18], 0x10
0x000142147d6e:  440fb6da              movzx     r11d, dl
0x000142147d72:  498bd1                mov       rdx, r9
0x000142147d75:  4c8bd1                mov       r10, rcx
0x000142147d78:  7203                  jb        0x142147d7d
0x000142147d7a:  498b11                mov       rdx, qword ptr [r9]
0x000142147d7d:  498b4110              mov       rax, qword ptr [r9 + 0x10]
0x000142147d81:  4889442448            mov       qword ptr [rsp + 0x48], rax
0x000142147d86:  488b8424d0000000      mov       rax, qword ptr [rsp + 0xd0]
0x000142147d8e:  4889542440            mov       qword ptr [rsp + 0x40], rdx
0x000142147d93:  0fb708                movzx     ecx, word ptr [rax]
0x000142147d96:  488b8424d8000000      mov       rax, qword ptr [rsp + 0xd8]
0x000142147d9e:  894c2450              mov       dword ptr [rsp + 0x50], ecx
0x000142147da2:  488bc8                mov       rcx, rax
0x000142147da5:  4883781810            cmp       qword ptr [rax + 0x18], 0x10
0x000142147daa:  7203                  jb        0x142147daf
0x000142147dac:  488b08                mov       rcx, qword ptr [rax]
0x000142147daf:  0f10442440            movups    xmm0, xmmword ptr [rsp + 0x40]
0x000142147db4:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x000142147db8:  4c8d4c2450            lea       r9, [rsp + 0x50]
0x000142147dbd:  0f104c2450            movups    xmm1, xmmword ptr [rsp + 0x50]
0x000142147dc2:  48894c2430            mov       qword ptr [rsp + 0x30], rcx
0x000142147dc7:  410fb6d3              movzx     edx, r11b
0x000142147dcb:  4889442438            mov       qword ptr [rsp + 0x38], rax
0x000142147dd0:  488d4c2440            lea       rcx, [rsp + 0x40]
0x000142147dd5:  0f11442460            movups    xmmword ptr [rsp + 0x60], xmm0
0x000142147dda:  488d442460            lea       rax, [rsp + 0x60]
0x000142147ddf:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x000142147de4:  0f10442430            movups    xmm0, xmmword ptr [rsp + 0x30]
0x000142147de9:  48c74424302d0d0000    mov       qword ptr [rsp + 0x30], 0xd2d
0x000142147df2:  4889442438            mov       qword ptr [rsp + 0x38], rax
0x000142147df7:  0f11842480000000      movups    xmmword ptr [rsp + 0x80], xmm0
0x000142147dff:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x000142147e04:  660f7f442450          movdqa    xmmword ptr [rsp + 0x50], xmm0
0x000142147e0a:  410f2802              movaps    xmm0, xmmword ptr [r10]
0x000142147e0e:  0f114c2470            movups    xmmword ptr [rsp + 0x70], xmm1
0x000142147e13:  410f2808              movaps    xmm1, xmmword ptr [r8]
0x000142147e17:  4c8d442430            lea       r8, [rsp + 0x30]
0x000142147e1c:  660f7f442440          movdqa    xmmword ptr [rsp + 0x40], xmm0
0x000142147e22:  660f7f4c2430          movdqa    xmmword ptr [rsp + 0x30], xmm1
0x000142147e28:  e8a37c8102            call      0x14495fad0
0x000142147e2d:  488b8c2490000000      mov       rcx, qword ptr [rsp + 0x90]
0x000142147e35:  4833cc                xor       rcx, rsp
0x000142147e38:  e8a3979d03            call      0x145b215e0
0x000142147e3d:  4881c4a8000000        add       rsp, 0xa8
0x000142147e44:  c3                    ret       
0x000142147e45:  cc                    int3      
0x000142147e46:  cc                    int3      
0x000142147e47:  cc                    int3      
0x000142147e48:  cc                    int3      
0x000142147e49:  cc                    int3      
0x000142147e4a:  cc                    int3      
0x000142147e4b:  cc                    int3      
0x000142147e4c:  cc                    int3      
0x000142147e4d:  cc                    int3      
0x000142147e4e:  cc                    int3      
0x000142147e4f:  cc                    int3      
0x000142147e50:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142147e55:  48896c2410            mov       qword ptr [rsp + 0x10], rbp
0x000142147e5a:  4889742420            mov       qword ptr [rsp + 0x20], rsi
0x000142147e5f:  57                    push      rdi
0x000142147e60:  4883ec40              sub       rsp, 0x40
0x000142147e64:  488bf2                mov       rsi, rdx
0x000142147e67:  488bf9                mov       rdi, rcx
0x000142147e6a:  b960010000            mov       ecx, 0x160
0x000142147e6f:  e88cb97f02            call      0x144943800
0x000142147e74:  488bd8                mov       rbx, rax
0x000142147e77:  4885c0                test      rax, rax
0x000142147e7a:  0f8413010000          je        0x142147f93
0x000142147e80:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x000142147e85:  488d05dc09b504        lea       rax, [rip + 0x4b509dc]
0x000142147e8c:  488903                mov       qword ptr [rbx], rax
0x000142147e8f:  33ed                  xor       ebp, ebp
0x000142147e91:  48896b08              mov       qword ptr [rbx + 8], rbp
0x000142147e95:  48896b10              mov       qword ptr [rbx + 0x10], rbp
0x000142147e99:  48896b18              mov       qword ptr [rbx + 0x18], rbp
0x000142147e9d:  40886b20              mov       byte ptr [rbx + 0x20], bpl
0x000142147ea1:  488d4b28              lea       rcx, [rbx + 0x28]
0x000142147ea5:  e856fb7f02            call      0x144947a00
0x000142147eaa:  488d058f09b504        lea       rax, [rip + 0x4b5098f]
0x000142147eb1:  488903                mov       qword ptr [rbx], rax
0x000142147eb4:  0fb606                movzx     eax, byte ptr [rsi]
0x000142147eb7:  884330                mov       byte ptr [rbx + 0x30], al
0x000142147eba:  0f104601              movups    xmm0, xmmword ptr [rsi + 1]
0x000142147ebe:  0f114331              movups    xmmword ptr [rbx + 0x31], xmm0
0x000142147ec2:  0fb64611              movzx     eax, byte ptr [rsi + 0x11]
0x000142147ec6:  884341                mov       byte ptr [rbx + 0x41], al
0x000142147ec9:  488d4b42              lea       rcx, [rbx + 0x42]
0x000142147ecd:  488d4612              lea       rax, [rsi + 0x12]
0x000142147ed1:  483bc8                cmp       rcx, rax
0x000142147ed4:  7416                  je        0x142147eec
0x000142147ed6:  0f1000                movups    xmm0, xmmword ptr [rax]
0x000142147ed9:  0f1101                movups    xmmword ptr [rcx], xmm0
0x000142147edc:  f20f104810            movsd     xmm1, qword ptr [rax + 0x10]
0x000142147ee1:  f20f114910            movsd     qword ptr [rcx + 0x10], xmm1
0x000142147ee6:  8b4018                mov       eax, dword ptr [rax + 0x18]
0x000142147ee9:  894118                mov       dword ptr [rcx + 0x18], eax
0x000142147eec:  66c743600100          mov       word ptr [rbx + 0x60], 1
0x000142147ef2:  4889aba0000000        mov       qword ptr [rbx + 0xa0], rbp
0x000142147ef9:  89aba8000000          mov       dword ptr [rbx + 0xa8], ebp
0x000142147eff:  4889abb0000000        mov       qword ptr [rbx + 0xb0], rbp
0x000142147f06:  4889abb8000000        mov       qword ptr [rbx + 0xb8], rbp
0x000142147f0d:  4889abc0000000        mov       qword ptr [rbx + 0xc0], rbp
0x000142147f14:  4889abc8000000        mov       qword ptr [rbx + 0xc8], rbp
0x000142147f1b:  4889abd0000000        mov       qword ptr [rbx + 0xd0], rbp
0x000142147f22:  488d8bd8000000        lea       rcx, [rbx + 0xd8]
0x000142147f29:  48894c2460            mov       qword ptr [rsp + 0x60], rcx
0x000142147f2e:  488d4118              lea       rax, [rcx + 0x18]
0x000142147f32:  488901                mov       qword ptr [rcx], rax
0x000142147f35:  48896908              mov       qword ptr [rcx + 8], rbp
0x000142147f39:  48c7411020000000      mov       qword ptr [rcx + 0x10], 0x20
0x000142147f41:  c78310010000ffffffff  mov       dword ptr [rbx + 0x110], 0xffffffff
0x000142147f4b:  c6831401000000        mov       byte ptr [rbx + 0x114], 0
0x000142147f52:  488d8b18010000        lea       rcx, [rbx + 0x118]
0x000142147f59:  48894c2460            mov       qword ptr [rsp + 0x60], rcx
0x000142147f5e:  488d4118              lea       rax, [rcx + 0x18]
0x000142147f62:  488901                mov       qword ptr [rcx], rax
0x000142147f65:  48896908              mov       qword ptr [rcx + 8], rbp
0x000142147f69:  48c7411028000000      mov       qword ptr [rcx + 0x10], 0x28
0x000142147f71:  c6835801000000        mov       byte ptr [rbx + 0x158], 0
0x000142147f78:  48891f                mov       qword ptr [rdi], rbx
0x000142147f7b:  488bc7                mov       rax, rdi
0x000142147f7e:  488b5c2450            mov       rbx, qword ptr [rsp + 0x50]
0x000142147f83:  488b6c2458            mov       rbp, qword ptr [rsp + 0x58]
0x000142147f88:  488b742468            mov       rsi, qword ptr [rsp + 0x68]
0x000142147f8d:  4883c440              add       rsp, 0x40
0x000142147f91:  5f                    pop       rdi
0x000142147f92:  c3                    ret       
0x000142147f93:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142147f98:  e8532e67fe            call      0x1407badf0
0x000142147f9d:  488d159cecbb05        lea       rdx, [rip + 0x5bbec9c]
0x000142147fa4:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142147fa9:  e8a2b09f03            call      0x145b43050
0x000142147fae:  cc                    int3      
0x000142147faf:  cc                    int3      
