; function_of: vtab.Ipv4ReverseEndpointTlv, vtab.Ipv4Tlv, vtab.Ipv6Tlv, vtab.TokenTlv, vtab.TraceIdTlv
; xref site 0x14227592a -> vtab.Ipv4Tlv @ 0x146c98990
; xref site 0x1422759a6 -> vtab.TokenTlv @ 0x146c988f0
; xref site 0x142275ad2 -> vtab.TraceIdTlv @ 0x146c98918
; xref site 0x142275b8b -> vtab.Ipv4ReverseEndpointTlv @ 0x146c98940
; xref site 0x142275c0b -> vtab.Ipv6Tlv @ 0x146c98968
; range 0x142275560 .. 0x142275c70  (1808 bytes)

0x000142275560:  4053                  push      rbx
0x000142275562:  55                    push      rbp
0x000142275563:  56                    push      rsi
0x000142275564:  4154                  push      r12
0x000142275566:  4157                  push      r15
0x000142275568:  4881ec80000000        sub       rsp, 0x80
0x00014227556f:  488b057ae1a905        mov       rax, qword ptr [rip + 0x5a9e17a]
0x000142275576:  4833c4                xor       rax, rsp
0x000142275579:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x00014227557e:  33ed                  xor       ebp, ebp
0x000142275580:  c742040c000000        mov       dword ptr [rdx + 4], 0xc
0x000142275587:  892a                  mov       dword ptr [rdx], ebp
0x000142275589:  498bd9                mov       rbx, r9
0x00014227558c:  48896a08              mov       qword ptr [rdx + 8], rbp
0x000142275590:  4d8bf8                mov       r15, r8
0x000142275593:  40886a10              mov       byte ptr [rdx + 0x10], bpl
0x000142275597:  4c8be2                mov       r12, rdx
0x00014227559a:  48896a18              mov       qword ptr [rdx + 0x18], rbp
0x00014227559e:  488bf1                mov       rsi, rcx
0x0001422755a1:  4c89442430            mov       qword ptr [rsp + 0x30], r8
0x0001422755a6:  48396940              cmp       qword ptr [rcx + 0x40], rbp
0x0001422755aa:  0f8491000000          je        0x142275641
0x0001422755b0:  40382db18f0306        cmp       byte ptr [rip + 0x6038fb1], bpl
0x0001422755b7:  7429                  je        0x1422755e2
0x0001422755b9:  4038a9b4000000        cmp       byte ptr [rcx + 0xb4], bpl
0x0001422755c0:  7517                  jne       0x1422755d9
0x0001422755c2:  486305cfa9ae05        movsxd    rax, dword ptr [rip + 0x5aea9cf]
0x0001422755c9:  4869c8e8030000        imul      rcx, rax, 0x3e8
0x0001422755d0:  48034e50              add       rcx, qword ptr [rsi + 0x50]
0x0001422755d4:  483bd9                cmp       rbx, rcx
0x0001422755d7:  7668                  jbe       0x142275641
0x0001422755d9:  4088aeb4000000        mov       byte ptr [rsi + 0xb4], bpl
0x0001422755e0:  eb16                  jmp       0x1422755f8
0x0001422755e2:  6905aca9ae05e8030000  imul      eax, dword ptr [rip + 0x5aea9ac], 0x3e8
0x0001422755ec:  4863c8                movsxd    rcx, eax
0x0001422755ef:  48034e50              add       rcx, qword ptr [rsi + 0x50]
0x0001422755f3:  483bd9                cmp       rbx, rcx
0x0001422755f6:  7649                  jbe       0x142275641
0x0001422755f8:  488bce                mov       rcx, rsi
0x0001422755fb:  e800feffff            call      0x142275400
0x000142275600:  448bc0                mov       r8d, eax
0x000142275603:  48396e50              cmp       qword ptr [rsi + 0x50], rbp
0x000142275607:  7504                  jne       0x14227560d
0x000142275609:  48895e50              mov       qword ptr [rsi + 0x50], rbx
0x00014227560d:  488bcb                mov       rcx, rbx
0x000142275610:  4589442404            mov       dword ptr [r12 + 4], r8d
0x000142275615:  482b4e50              sub       rcx, qword ptr [rsi + 0x50]
0x000142275619:  48b877be9f1a2fdd2406  movabs    rax, 0x624dd2f1a9fbe77
0x000142275623:  48f7e1                mul       rcx
0x000142275626:  482bca                sub       rcx, rdx
0x000142275629:  48d1e9                shr       rcx, 1
0x00014227562c:  4803ca                add       rcx, rdx
0x00014227562f:  48c1e909              shr       rcx, 9
0x000142275633:  49894c2408            mov       qword ptr [r12 + 8], rcx
0x000142275638:  4585c0                test      r8d, r8d
0x00014227563b:  7504                  jne       0x142275641
0x00014227563d:  48895e50              mov       qword ptr [rsi + 0x50], rbx
0x000142275641:  4c8b8680000000        mov       r8, qword ptr [rsi + 0x80]
0x000142275648:  4d85c0                test      r8, r8
0x00014227564b:  742f                  je        0x14227567c
0x00014227564d:  410f2807              movaps    xmm0, xmmword ptr [r15]
0x000142275651:  0f29442420            movaps    xmmword ptr [rsp + 0x20], xmm0
0x000142275656:  660f73d808            psrldq    xmm0, 8
0x00014227565b:  66480f7ec0            movq      rax, xmm0
0x000142275660:  4c3bc0                cmp       r8, rax
0x000142275663:  0f870f020000          ja        0x142275878
0x000142275669:  488b5678              mov       rdx, qword ptr [rsi + 0x78]
0x00014227566d:  488b4c2420            mov       rcx, qword ptr [rsp + 0x20]
0x000142275672:  e829db8c03            call      0x145b431a0
0x000142275677:  e901020000            jmp       0x14227587d
0x00014227567c:  4889bc24c8000000      mov       qword ptr [rsp + 0xc8], rdi
0x000142275684:  4889ae80000000        mov       qword ptr [rsi + 0x80], rbp
0x00014227568b:  4883be8800000004      cmp       qword ptr [rsi + 0x88], 4
0x000142275693:  4c896c2478            mov       qword ptr [rsp + 0x78], r13
0x000142275698:  4c89742470            mov       qword ptr [rsp + 0x70], r14
0x00014227569d:  731a                  jae       0x1422756b9
0x00014227569f:  41b901000000          mov       r9d, 1
0x0001422756a5:  488d9690000000        lea       rdx, [rsi + 0x90]
0x0001422756ac:  488d4e78              lea       rcx, [rsi + 0x78]
0x0001422756b0:  458d4103              lea       r8d, [r9 + 3]
0x0001422756b4:  e8f7bb6e02            call      0x1449612b0
0x0001422756b9:  488b4e78              mov       rcx, qword ptr [rsi + 0x78]
0x0001422756bd:  4c8d4104              lea       r8, [rcx + 4]
0x0001422756c1:  48038e80000000        add       rcx, qword ptr [rsi + 0x80]
0x0001422756c8:  493bc8                cmp       rcx, r8
0x0001422756cb:  740a                  je        0x1422756d7
0x0001422756cd:  4c2bc1                sub       r8, rcx
0x0001422756d0:  33d2                  xor       edx, edx
0x0001422756d2:  e8e9ca8c03            call      0x145b421c0
0x0001422756d7:  48c7868000000004000000  mov       qword ptr [rsi + 0x80], 4
0x0001422756e2:  488bce                mov       rcx, rsi
0x0001422756e5:  0fb606                movzx     eax, byte ptr [rsi]
0x0001422756e8:  488b7e78              mov       rdi, qword ptr [rsi + 0x78]
0x0001422756ec:  8807                  mov       byte ptr [rdi], al
0x0001422756ee:  0fb64601              movzx     eax, byte ptr [rsi + 1]
0x0001422756f2:  884701                mov       byte ptr [rdi + 1], al
0x0001422756f5:  e896fcffff            call      0x142275390
0x0001422756fa:  0fb7c8                movzx     ecx, ax
0x0001422756fd:  ff1535a1ec03          call      qword ptr [rip + 0x3eca135]
0x000142275703:  66894702              mov       word ptr [rdi + 2], ax
0x000142275707:  4c8b6e68              mov       r13, qword ptr [rsi + 0x68]
0x00014227570b:  4c8b7660              mov       r14, qword ptr [rsi + 0x60]
0x00014227570f:  4d3bf5                cmp       r14, r13
0x000142275712:  0f841a010000          je        0x142275832
0x000142275718:  0f1f840000000000      nop       dword ptr [rax + rax]
0x000142275720:  498b0e                mov       rcx, qword ptr [r14]
0x000142275723:  488b01                mov       rax, qword ptr [rcx]
0x000142275726:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x00014227572a:  ff1508a6ec03          call      qword ptr [rip + 0x3eca608]
0x000142275730:  488bbe80000000        mov       rdi, qword ptr [rsi + 0x80]
0x000142275737:  440fb6f8              movzx     r15d, al
0x00014227573b:  4983c702              add       r15, 2
0x00014227573f:  4903ff                add       rdi, r15
0x000142275742:  483bbe80000000        cmp       rdi, qword ptr [rsi + 0x80]
0x000142275749:  7242                  jb        0x14227578d
0x00014227574b:  7647                  jbe       0x142275794
0x00014227574d:  4839be88000000        cmp       qword ptr [rsi + 0x88], rdi
0x000142275754:  7319                  jae       0x14227576f
0x000142275756:  488d9690000000        lea       rdx, [rsi + 0x90]
0x00014227575d:  41b901000000          mov       r9d, 1
0x000142275763:  4c8bc7                mov       r8, rdi
0x000142275766:  488d4e78              lea       rcx, [rsi + 0x78]
0x00014227576a:  e841bb6e02            call      0x1449612b0
0x00014227576f:  488b4e78              mov       rcx, qword ptr [rsi + 0x78]
0x000142275773:  4c8d0439              lea       r8, [rcx + rdi]
0x000142275777:  48038e80000000        add       rcx, qword ptr [rsi + 0x80]
0x00014227577e:  493bc8                cmp       rcx, r8
0x000142275781:  740a                  je        0x14227578d
0x000142275783:  4c2bc1                sub       r8, rcx
0x000142275786:  33d2                  xor       edx, edx
0x000142275788:  e833ca8c03            call      0x145b421c0
0x00014227578d:  4889be80000000        mov       qword ptr [rsi + 0x80], rdi
0x000142275794:  498b0e                mov       rcx, qword ptr [r14]
0x000142275797:  488bbe80000000        mov       rdi, qword ptr [rsi + 0x80]
0x00014227579e:  492bff                sub       rdi, r15
0x0001422757a1:  48037e78              add       rdi, qword ptr [rsi + 0x78]
0x0001422757a5:  488b01                mov       rax, qword ptr [rcx]
0x0001422757a8:  488b4008              mov       rax, qword ptr [rax + 8]
0x0001422757ac:  ff1586a5ec03          call      qword ptr [rip + 0x3eca586]
0x0001422757b2:  8807                  mov       byte ptr [rdi], al
0x0001422757b4:  498b0e                mov       rcx, qword ptr [r14]
0x0001422757b7:  488b01                mov       rax, qword ptr [rcx]
0x0001422757ba:  488b4010              mov       rax, qword ptr [rax + 0x10]
0x0001422757be:  ff1574a5ec03          call      qword ptr [rip + 0x3eca574]
0x0001422757c4:  884701                mov       byte ptr [rdi + 1], al
0x0001422757c7:  4883c702              add       rdi, 2
0x0001422757cb:  498b0e                mov       rcx, qword ptr [r14]
0x0001422757ce:  488b01                mov       rax, qword ptr [rcx]
0x0001422757d1:  488b4008              mov       rax, qword ptr [rax + 8]
0x0001422757d5:  ff155da5ec03          call      qword ptr [rip + 0x3eca55d]
0x0001422757db:  3c01                  cmp       al, 1
0x0001422757dd:  750e                  jne       0x1422757ed
0x0001422757df:  8bc7                  mov       eax, edi
0x0001422757e1:  2b4678                sub       eax, dword ptr [rsi + 0x78]
0x0001422757e4:  83c008                add       eax, 8
0x0001422757e7:  8986b0000000          mov       dword ptr [rsi + 0xb0], eax
0x0001422757ed:  498b0e                mov       rcx, qword ptr [r14]
0x0001422757f0:  498d47fe              lea       rax, [r15 - 2]
0x0001422757f4:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x0001422757f9:  4c8d442440            lea       r8, [rsp + 0x40]
0x0001422757fe:  48897c2420            mov       qword ptr [rsp + 0x20], rdi
0x000142275803:  488d542450            lea       rdx, [rsp + 0x50]
0x000142275808:  0f28442420            movaps    xmm0, xmmword ptr [rsp + 0x20]
0x00014227580d:  488b01                mov       rax, qword ptr [rcx]
0x000142275810:  660f7f442440          movdqa    xmmword ptr [rsp + 0x40], xmm0
0x000142275816:  488b4018              mov       rax, qword ptr [rax + 0x18]
0x00014227581a:  ff1518a5ec03          call      qword ptr [rip + 0x3eca518]
0x000142275820:  4983c608              add       r14, 8
0x000142275824:  4d3bf5                cmp       r14, r13
0x000142275827:  0f85f3feffff          jne       0x142275720
0x00014227582d:  4c8b7c2430            mov       r15, qword ptr [rsp + 0x30]
0x000142275832:  4c8b8680000000        mov       r8, qword ptr [rsi + 0x80]
0x000142275839:  4c8b742470            mov       r14, qword ptr [rsp + 0x70]
0x00014227583e:  4c8b6c2478            mov       r13, qword ptr [rsp + 0x78]
0x000142275843:  488bbc24c8000000      mov       rdi, qword ptr [rsp + 0xc8]
0x00014227584b:  4d85c0                test      r8, r8
0x00014227584e:  7428                  je        0x142275878
0x000142275850:  410f2807              movaps    xmm0, xmmword ptr [r15]
0x000142275854:  0f29442440            movaps    xmmword ptr [rsp + 0x40], xmm0
0x000142275859:  660f73d808            psrldq    xmm0, 8
0x00014227585e:  66480f7ec0            movq      rax, xmm0
0x000142275863:  4c3bc0                cmp       r8, rax
0x000142275866:  7710                  ja        0x142275878
0x000142275868:  488b5678              mov       rdx, qword ptr [rsi + 0x78]
0x00014227586c:  488b4c2440            mov       rcx, qword ptr [rsp + 0x40]
0x000142275871:  e82ad98c03            call      0x145b431a0
0x000142275876:  eb05                  jmp       0x14227587d
0x000142275878:  bd0b000000            mov       ebp, 0xb
0x00014227587d:  498bc4                mov       rax, r12
0x000142275880:  41892c24              mov       dword ptr [r12], ebp
0x000142275884:  488b4c2460            mov       rcx, qword ptr [rsp + 0x60]
0x000142275889:  4833cc                xor       rcx, rsp
0x00014227588c:  e84fbd8a03            call      0x145b215e0
0x000142275891:  4881c480000000        add       rsp, 0x80
0x000142275898:  415f                  pop       r15
0x00014227589a:  415c                  pop       r12
0x00014227589c:  5e                    pop       rsi
0x00014227589d:  5d                    pop       rbp
0x00014227589e:  5b                    pop       rbx
0x00014227589f:  c3                    ret       
0x0001422758a0:  4883ec38              sub       rsp, 0x38
0x0001422758a4:  807a0400              cmp       byte ptr [rdx + 4], 0
0x0001422758a8:  750a                  jne       0x1422758b4
0x0001422758aa:  b809000000            mov       eax, 9
0x0001422758af:  4883c438              add       rsp, 0x38
0x0001422758b3:  c3                    ret       
0x0001422758b4:  4883794000            cmp       qword ptr [rcx + 0x40], 0
0x0001422758b9:  740a                  je        0x1422758c5
0x0001422758bb:  b80c000000            mov       eax, 0xc
0x0001422758c0:  4883c438              add       rsp, 0x38
0x0001422758c4:  c3                    ret       
0x0001422758c5:  4c894158              mov       qword ptr [rcx + 0x58], r8
0x0001422758c9:  4c8d442420            lea       r8, [rsp + 0x20]
0x0001422758ce:  488b4208              mov       rax, qword ptr [rdx + 8]
0x0001422758d2:  0fb65204              movzx     edx, byte ptr [rdx + 4]
0x0001422758d6:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x0001422758db:  48c744242810000000    mov       qword ptr [rsp + 0x28], 0x10
0x0001422758e4:  0f28442420            movaps    xmm0, xmmword ptr [rsp + 0x20]
0x0001422758e9:  660f7f442420          movdqa    xmmword ptr [rsp + 0x20], xmm0
0x0001422758ef:  e87c030000            call      0x142275c70
0x0001422758f4:  4883c438              add       rsp, 0x38
0x0001422758f8:  c3                    ret       
0x0001422758f9:  cc                    int3      
0x0001422758fa:  cc                    int3      
0x0001422758fb:  cc                    int3      
0x0001422758fc:  cc                    int3      
0x0001422758fd:  cc                    int3      
0x0001422758fe:  cc                    int3      
0x0001422758ff:  cc                    int3      
0x000142275900:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142275905:  4889742410            mov       qword ptr [rsp + 0x10], rsi
0x00014227590a:  57                    push      rdi
0x00014227590b:  4883ec40              sub       rsp, 0x40
0x00014227590f:  488bf1                mov       rsi, rcx
0x000142275912:  410fb7f8              movzx     edi, r8w
0x000142275916:  b910000000            mov       ecx, 0x10
0x00014227591b:  8bda                  mov       ebx, edx
0x00014227591d:  e8dede6c02            call      0x144943800
0x000142275922:  4885c0                test      rax, rax
0x000142275925:  7433                  je        0x14227595a
0x000142275927:  488d0d6230a204        lea       rcx, [rip + 0x4a23062]
0x00014227592e:  895808                mov       dword ptr [rax + 8], ebx
0x000142275931:  488908                mov       qword ptr [rax], rcx
0x000142275934:  488d542468            lea       rdx, [rsp + 0x68]
0x000142275939:  6689780c              mov       word ptr [rax + 0xc], di
0x00014227593d:  488bce                mov       rcx, rsi
0x000142275940:  4889442468            mov       qword ptr [rsp + 0x68], rax
0x000142275945:  e886f9ffff            call      0x1422752d0
0x00014227594a:  488b5c2450            mov       rbx, qword ptr [rsp + 0x50]
0x00014227594f:  488b742458            mov       rsi, qword ptr [rsp + 0x58]
0x000142275954:  4883c440              add       rsp, 0x40
0x000142275958:  5f                    pop       rdi
0x000142275959:  c3                    ret       
0x00014227595a:  488d4c2428            lea       rcx, [rsp + 0x28]
0x00014227595f:  e88c5454fe            call      0x1407badf0
0x000142275964:  488d15d512a905        lea       rdx, [rip + 0x5a912d5]
0x00014227596b:  488d4c2428            lea       rcx, [rsp + 0x28]
0x000142275970:  e8dbd68c03            call      0x145b43050
0x000142275975:  cc                    int3      
0x000142275976:  cc                    int3      
0x000142275977:  cc                    int3      
0x000142275978:  cc                    int3      
0x000142275979:  cc                    int3      
0x00014227597a:  cc                    int3      
0x00014227597b:  cc                    int3      
0x00014227597c:  cc                    int3      
0x00014227597d:  cc                    int3      
0x00014227597e:  cc                    int3      
0x00014227597f:  cc                    int3      
0x000142275980:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142275985:  57                    push      rdi
0x000142275986:  4883ec40              sub       rsp, 0x40
0x00014227598a:  488bf9                mov       rdi, rcx
0x00014227598d:  488bda                mov       rbx, rdx
0x000142275990:  b920000000            mov       ecx, 0x20
0x000142275995:  e866de6c02            call      0x144943800
0x00014227599a:  4885c0                test      rax, rax
0x00014227599d:  7435                  je        0x1422759d4
0x00014227599f:  0fb65310              movzx     edx, byte ptr [rbx + 0x10]
0x0001422759a3:  488d0d462fa204        lea       rcx, [rip + 0x4a22f46]
0x0001422759aa:  0f1003                movups    xmm0, xmmword ptr [rbx]
0x0001422759ad:  488908                mov       qword ptr [rax], rcx
0x0001422759b0:  488bcf                mov       rcx, rdi
0x0001422759b3:  0f114008              movups    xmmword ptr [rax + 8], xmm0
0x0001422759b7:  885018                mov       byte ptr [rax + 0x18], dl
0x0001422759ba:  488d542460            lea       rdx, [rsp + 0x60]
0x0001422759bf:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x0001422759c4:  e807f9ffff            call      0x1422752d0
0x0001422759c9:  488b5c2450            mov       rbx, qword ptr [rsp + 0x50]
0x0001422759ce:  4883c440              add       rsp, 0x40
0x0001422759d2:  5f                    pop       rdi
0x0001422759d3:  c3                    ret       
0x0001422759d4:  488d4c2420            lea       rcx, [rsp + 0x20]
0x0001422759d9:  e8125454fe            call      0x1407badf0
0x0001422759de:  488d155b12a905        lea       rdx, [rip + 0x5a9125b]
0x0001422759e5:  488d4c2420            lea       rcx, [rsp + 0x20]
0x0001422759ea:  e861d68c03            call      0x145b43050
0x0001422759ef:  cc                    int3      
0x0001422759f0:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x0001422759f5:  4889742410            mov       qword ptr [rsp + 0x10], rsi
0x0001422759fa:  57                    push      rdi
0x0001422759fb:  4883ec20              sub       rsp, 0x20
0x0001422759ff:  488d7908              lea       rdi, [rcx + 8]
0x000142275a03:  33f6                  xor       esi, esi
0x000142275a05:  488bda                mov       rbx, rdx
0x000142275a08:  483bfa                cmp       rdi, rdx
0x000142275a0b:  7468                  je        0x142275a75
0x000142275a0d:  488b4f38              mov       rcx, qword ptr [rdi + 0x38]
0x000142275a11:  4885c9                test      rcx, rcx
0x000142275a14:  7417                  je        0x142275a2d
0x000142275a16:  488b01                mov       rax, qword ptr [rcx]
0x000142275a19:  483bcf                cmp       rcx, rdi
0x000142275a1c:  0f95c2                setne     dl
0x000142275a1f:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x000142275a23:  ff150fa3ec03          call      qword ptr [rip + 0x3eca30f]
0x000142275a29:  48897738              mov       qword ptr [rdi + 0x38], rsi
0x000142275a2d:  488b4b38              mov       rcx, qword ptr [rbx + 0x38]
0x000142275a31:  4885c9                test      rcx, rcx
0x000142275a34:  743f                  je        0x142275a75
0x000142275a36:  483bcb                cmp       rcx, rbx
0x000142275a39:  7532                  jne       0x142275a6d
0x000142275a3b:  488b01                mov       rax, qword ptr [rcx]
0x000142275a3e:  488bd7                mov       rdx, rdi
0x000142275a41:  488b4008              mov       rax, qword ptr [rax + 8]
0x000142275a45:  ff15eda2ec03          call      qword ptr [rip + 0x3eca2ed]
0x000142275a4b:  48894738              mov       qword ptr [rdi + 0x38], rax
0x000142275a4f:  488b4b38              mov       rcx, qword ptr [rbx + 0x38]
0x000142275a53:  4885c9                test      rcx, rcx
0x000142275a56:  741d                  je        0x142275a75
0x000142275a58:  488b01                mov       rax, qword ptr [rcx]
0x000142275a5b:  483bcb                cmp       rcx, rbx
0x000142275a5e:  0f95c2                setne     dl
0x000142275a61:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x000142275a65:  ff15cda2ec03          call      qword ptr [rip + 0x3eca2cd]
0x000142275a6b:  eb04                  jmp       0x142275a71
0x000142275a6d:  48894f38              mov       qword ptr [rdi + 0x38], rcx
0x000142275a71:  48897338              mov       qword ptr [rbx + 0x38], rsi
0x000142275a75:  488b4b38              mov       rcx, qword ptr [rbx + 0x38]
0x000142275a79:  4885c9                test      rcx, rcx
0x000142275a7c:  7417                  je        0x142275a95
0x000142275a7e:  488b01                mov       rax, qword ptr [rcx]
0x000142275a81:  483bcb                cmp       rcx, rbx
0x000142275a84:  0f95c2                setne     dl
0x000142275a87:  488b4020              mov       rax, qword ptr [rax + 0x20]
0x000142275a8b:  ff15a7a2ec03          call      qword ptr [rip + 0x3eca2a7]
0x000142275a91:  48897338              mov       qword ptr [rbx + 0x38], rsi
0x000142275a95:  488b5c2430            mov       rbx, qword ptr [rsp + 0x30]
0x000142275a9a:  33c0                  xor       eax, eax
0x000142275a9c:  488b742438            mov       rsi, qword ptr [rsp + 0x38]
0x000142275aa1:  4883c420              add       rsp, 0x20
0x000142275aa5:  5f                    pop       rdi
0x000142275aa6:  c3                    ret       
0x000142275aa7:  cc                    int3      
0x000142275aa8:  cc                    int3      
0x000142275aa9:  cc                    int3      
0x000142275aaa:  cc                    int3      
0x000142275aab:  cc                    int3      
0x000142275aac:  cc                    int3      
0x000142275aad:  cc                    int3      
0x000142275aae:  cc                    int3      
0x000142275aaf:  cc                    int3      
0x000142275ab0:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142275ab5:  57                    push      rdi
0x000142275ab6:  4883ec40              sub       rsp, 0x40
0x000142275aba:  488bda                mov       rbx, rdx
0x000142275abd:  488bf9                mov       rdi, rcx
0x000142275ac0:  b918000000            mov       ecx, 0x18
0x000142275ac5:  e836dd6c02            call      0x144943800
0x000142275aca:  4885c0                test      rax, rax
0x000142275acd:  7438                  je        0x142275b07
0x000142275acf:  488d0d422ea204        lea       rcx, [rip + 0x4a22e42]
0x000142275ad6:  488908                mov       qword ptr [rax], rcx
0x000142275ad9:  0f1003                movups    xmm0, xmmword ptr [rbx]
0x000142275adc:  0f114008              movups    xmmword ptr [rax + 8], xmm0
0x000142275ae0:  48c744246800000000    mov       qword ptr [rsp + 0x68], 0
0x000142275ae9:  4889442460            mov       qword ptr [rsp + 0x60], rax
0x000142275aee:  488d542460            lea       rdx, [rsp + 0x60]
0x000142275af3:  488bcf                mov       rcx, rdi
0x000142275af6:  e8d5f7ffff            call      0x1422752d0
0x000142275afb:  90                    nop       
0x000142275afc:  488b5c2450            mov       rbx, qword ptr [rsp + 0x50]
0x000142275b01:  4883c440              add       rsp, 0x40
0x000142275b05:  5f                    pop       rdi
0x000142275b06:  c3                    ret       
0x000142275b07:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142275b0c:  e8df5254fe            call      0x1407badf0
0x000142275b11:  488d152811a905        lea       rdx, [rip + 0x5a91128]
0x000142275b18:  488d4c2420            lea       rcx, [rsp + 0x20]
0x000142275b1d:  e82ed58c03            call      0x145b43050
0x000142275b22:  cc                    int3      
0x000142275b23:  cc                    int3      
0x000142275b24:  cc                    int3      
0x000142275b25:  cc                    int3      
0x000142275b26:  cc                    int3      
0x000142275b27:  cc                    int3      
0x000142275b28:  cc                    int3      
0x000142275b29:  cc                    int3      
0x000142275b2a:  cc                    int3      
0x000142275b2b:  cc                    int3      
0x000142275b2c:  cc                    int3      
0x000142275b2d:  cc                    int3      
0x000142275b2e:  cc                    int3      
0x000142275b2f:  cc                    int3      
0x000142275b30:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142275b35:  57                    push      rdi
0x000142275b36:  4883ec50              sub       rsp, 0x50
0x000142275b3a:  410fb7d8              movzx     ebx, r8w
0x000142275b3e:  488bf9                mov       rdi, rcx
0x000142275b41:  c744247800000000      mov       dword ptr [rsp + 0x78], 0
0x000142275b49:  4c8d442478            lea       r8, [rsp + 0x78]
0x000142275b4e:  b902000000            mov       ecx, 2
0x000142275b53:  ff15c79cec03          call      qword ptr [rip + 0x3ec9cc7]
0x000142275b59:  83f801                cmp       eax, 1
0x000142275b5c:  7410                  je        0x142275b6e
0x000142275b5e:  b80a000000            mov       eax, 0xa
0x000142275b63:  488b5c2460            mov       rbx, qword ptr [rsp + 0x60]
0x000142275b68:  4883c450              add       rsp, 0x50
0x000142275b6c:  5f                    pop       rdi
0x000142275b6d:  c3                    ret       
0x000142275b6e:  b910000000            mov       ecx, 0x10
0x000142275b73:  e888dc6c02            call      0x144943800
0x000142275b78:  4885c0                test      rax, rax
0x000142275b7b:  743c                  je        0x142275bb9
0x000142275b7d:  8b4c2478              mov       ecx, dword ptr [rsp + 0x78]
0x000142275b81:  894808                mov       dword ptr [rax + 8], ecx
0x000142275b84:  6689580c              mov       word ptr [rax + 0xc], bx
0x000142275b88:  488d0db12da204        lea       rcx, [rip + 0x4a22db1]
0x000142275b8f:  488908                mov       qword ptr [rax], rcx
0x000142275b92:  48c744242800000000    mov       qword ptr [rsp + 0x28], 0
0x000142275b9b:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x000142275ba0:  488d542420            lea       rdx, [rsp + 0x20]
0x000142275ba5:  488bcf                mov       rcx, rdi
0x000142275ba8:  e823f7ffff            call      0x1422752d0
0x000142275bad:  90                    nop       
0x000142275bae:  488b5c2460            mov       rbx, qword ptr [rsp + 0x60]
0x000142275bb3:  4883c450              add       rsp, 0x50
0x000142275bb7:  5f                    pop       rdi
0x000142275bb8:  c3                    ret       
0x000142275bb9:  488d4c2430            lea       rcx, [rsp + 0x30]
0x000142275bbe:  e82d5254fe            call      0x1407badf0
0x000142275bc3:  488d157610a905        lea       rdx, [rip + 0x5a91076]
0x000142275bca:  488d4c2430            lea       rcx, [rsp + 0x30]
0x000142275bcf:  e87cd48c03            call      0x145b43050
0x000142275bd4:  cc                    int3      
0x000142275bd5:  cc                    int3      
0x000142275bd6:  cc                    int3      
0x000142275bd7:  cc                    int3      
0x000142275bd8:  cc                    int3      
0x000142275bd9:  cc                    int3      
0x000142275bda:  cc                    int3      
0x000142275bdb:  cc                    int3      
0x000142275bdc:  cc                    int3      
0x000142275bdd:  cc                    int3      
0x000142275bde:  cc                    int3      
0x000142275bdf:  cc                    int3      
0x000142275be0:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x000142275be5:  4889742410            mov       qword ptr [rsp + 0x10], rsi
0x000142275bea:  57                    push      rdi
0x000142275beb:  4883ec40              sub       rsp, 0x40
0x000142275bef:  410fb7d8              movzx     ebx, r8w
0x000142275bf3:  488bfa                mov       rdi, rdx
0x000142275bf6:  488bf1                mov       rsi, rcx
0x000142275bf9:  b920000000            mov       ecx, 0x20
0x000142275bfe:  e8fddb6c02            call      0x144943800
0x000142275c03:  4885c0                test      rax, rax
0x000142275c06:  7441                  je        0x142275c49
0x000142275c08:  488d0d592da204        lea       rcx, [rip + 0x4a22d59]
0x000142275c0f:  488908                mov       qword ptr [rax], rcx
0x000142275c12:  0f1007                movups    xmm0, xmmword ptr [rdi]
0x000142275c15:  0f114008              movups    xmmword ptr [rax + 8], xmm0
0x000142275c19:  66895818              mov       word ptr [rax + 0x18], bx
0x000142275c1d:  48c744242000000000    mov       qword ptr [rsp + 0x20], 0
0x000142275c26:  4889442468            mov       qword ptr [rsp + 0x68], rax
0x000142275c2b:  488d542468            lea       rdx, [rsp + 0x68]
0x000142275c30:  488bce                mov       rcx, rsi
0x000142275c33:  e898f6ffff            call      0x1422752d0
0x000142275c38:  90                    nop       
0x000142275c39:  488b5c2450            mov       rbx, qword ptr [rsp + 0x50]
0x000142275c3e:  488b742458            mov       rsi, qword ptr [rsp + 0x58]
0x000142275c43:  4883c440              add       rsp, 0x40
0x000142275c47:  5f                    pop       rdi
0x000142275c48:  c3                    ret       
0x000142275c49:  488d4c2428            lea       rcx, [rsp + 0x28]
0x000142275c4e:  e89d5154fe            call      0x1407badf0
0x000142275c53:  488d15e60fa905        lea       rdx, [rip + 0x5a90fe6]
0x000142275c5a:  488d4c2428            lea       rcx, [rsp + 0x28]
0x000142275c5f:  e8ecd38c03            call      0x145b43050
0x000142275c64:  cc                    int3      
0x000142275c65:  cc                    int3      
0x000142275c66:  cc                    int3      
0x000142275c67:  cc                    int3      
0x000142275c68:  cc                    int3      
0x000142275c69:  cc                    int3      
0x000142275c6a:  cc                    int3      
0x000142275c6b:  cc                    int3      
0x000142275c6c:  cc                    int3      
0x000142275c6d:  cc                    int3      
0x000142275c6e:  cc                    int3      
0x000142275c6f:  cc                    int3      
