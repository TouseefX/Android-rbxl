; function_of: str.Offline ruppLength
; xref site 0x14289fdaf -> str.Offline ruppLength @ 0x146f39f68
; range 0x14289fc80 .. 0x1428a03c0  (1856 bytes)

0x00014289fc80:  4055                  push      rbp
0x00014289fc82:  53                    push      rbx
0x00014289fc83:  56                    push      rsi
0x00014289fc84:  57                    push      rdi
0x00014289fc85:  4154                  push      r12
0x00014289fc87:  4156                  push      r14
0x00014289fc89:  4157                  push      r15
0x00014289fc8b:  488d6c24d9            lea       rbp, [rsp - 0x27]
0x00014289fc90:  4881ecd0000000        sub       rsp, 0xd0
0x00014289fc97:  488b05523a4705        mov       rax, qword ptr [rip + 0x5473a52]
0x00014289fc9e:  4833c4                xor       rax, rsp
0x00014289fca1:  48894517              mov       qword ptr [rbp + 0x17], rax
0x00014289fca5:  4d8be1                mov       r12, r9
0x00014289fca8:  4c8bf2                mov       r14, rdx
0x00014289fcab:  33db                  xor       ebx, ebx
0x00014289fcad:  895a10                mov       dword ptr [rdx + 0x10], ebx
0x00014289fcb0:  895a18                mov       dword ptr [rdx + 0x18], ebx
0x00014289fcb3:  885a08                mov       byte ptr [rdx + 8], bl
0x00014289fcb6:  0f57c0                xorps     xmm0, xmm0
0x00014289fcb9:  f30f7f4587            movdqu    xmmword ptr [rbp - 0x79], xmm0
0x00014289fcbe:  8bc3                  mov       eax, ebx
0x00014289fcc0:  448bfb                mov       r15d, ebx
0x00014289fcc3:  4d85c0                test      r8, r8
0x00014289fcc6:  742e                  je        0x14289fcf6
0x00014289fcc8:  498b8088160000        mov       rax, qword ptr [r8 + 0x1688]
0x00014289fccf:  4885c0                test      rax, rax
0x00014289fcd2:  7404                  je        0x14289fcd8
0x00014289fcd4:  f0ff4008              lock inc  dword ptr [rax + 8]
0x00014289fcd8:  498b8080160000        mov       rax, qword ptr [r8 + 0x1680]
0x00014289fcdf:  4d8bb888160000        mov       r15, qword ptr [r8 + 0x1688]
0x00014289fce6:  488bf8                mov       rdi, rax
0x00014289fce9:  48894587              mov       qword ptr [rbp - 0x79], rax
0x00014289fced:  498bf7                mov       rsi, r15
0x00014289fcf0:  4c897d8f              mov       qword ptr [rbp - 0x71], r15
0x00014289fcf4:  eb08                  jmp       0x14289fcfe
0x00014289fcf6:  488b758f              mov       rsi, qword ptr [rbp - 0x71]
0x00014289fcfa:  488b7d87              mov       rdi, qword ptr [rbp - 0x79]
0x00014289fcfe:  4d85c0                test      r8, r8
0x00014289fd01:  754b                  jne       0x14289fd4e
0x00014289fd03:  488b01                mov       rax, qword ptr [rcx]
0x00014289fd06:  488d5597              lea       rdx, [rbp - 0x69]
0x00014289fd0a:  488b8020030000        mov       rax, qword ptr [rax + 0x320]
0x00014289fd11:  ff1521008a03          call      qword ptr [rip + 0x38a0021]
0x00014289fd17:  488b38                mov       rdi, qword ptr [rax]
0x00014289fd1a:  488b7008              mov       rsi, qword ptr [rax + 8]
0x00014289fd1e:  488918                mov       qword ptr [rax], rbx
0x00014289fd21:  48895808              mov       qword ptr [rax + 8], rbx
0x00014289fd25:  48897d87              mov       qword ptr [rbp - 0x79], rdi
0x00014289fd29:  4889758f              mov       qword ptr [rbp - 0x71], rsi
0x00014289fd2d:  4d85ff                test      r15, r15
0x00014289fd30:  7408                  je        0x14289fd3a
0x00014289fd32:  498bcf                mov       rcx, r15
0x00014289fd35:  e8d691f2fd            call      0x1407c8f10
0x00014289fd3a:  488bc7                mov       rax, rdi
0x00014289fd3d:  488b4d9f              mov       rcx, qword ptr [rbp - 0x61]
0x00014289fd41:  4885c9                test      rcx, rcx
0x00014289fd44:  7408                  je        0x14289fd4e
0x00014289fd46:  e8c591f2fd            call      0x1407c8f10
0x00014289fd4b:  488bc7                mov       rax, rdi
0x00014289fd4e:  4885c0                test      rax, rax
0x00014289fd51:  0f8447010000          je        0x14289fe9e
0x00014289fd57:  488bcf                mov       rcx, rdi
0x00014289fd5a:  e831569dff            call      0x142275390
0x00014289fd5f:  0fb7d8                movzx     ebx, ax
0x00014289fd62:  418b4e14              mov       ecx, dword ptr [r14 + 0x14]
0x00014289fd66:  83c107                add       ecx, 7
0x00014289fd69:  48c1e903              shr       rcx, 3
0x00014289fd6d:  483bd9                cmp       rbx, rcx
0x00014289fd70:  7610                  jbe       0x14289fd82
0x00014289fd72:  488d14dd00000000      lea       rdx, [rbx*8]
0x00014289fd7a:  498bce                mov       rcx, r14
0x00014289fd7d:  e84e630000            call      0x1428a60d0
0x00014289fd82:  488b05dfad4c05        mov       rax, qword ptr [rip + 0x54caddf]
0x00014289fd89:  3c06                  cmp       al, 6
0x00014289fd8b:  0f8296000000          jb        0x14289fe27
0x00014289fd91:  48c1e808              shr       rax, 8
0x00014289fd95:  3c06                  cmp       al, 6
0x00014289fd97:  0f828a000000          jb        0x14289fe27
0x00014289fd9d:  488d054aa01507        lea       rax, [rip + 0x715a04a]
0x00014289fda4:  48894597              mov       qword ptr [rbp - 0x69], rax
0x00014289fda8:  488b4d97              mov       rcx, qword ptr [rbp - 0x69]
0x00014289fdac:  488d0db5a16904        lea       rcx, [rip + 0x469a1b5]
0x00014289fdb3:  48894db7              mov       qword ptr [rbp - 0x49], rcx
0x00014289fdb7:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x00014289fdbe:  6690                  nop       
0x00014289fdc0:  48ffc0                inc       rax
0x00014289fdc3:  803c0100              cmp       byte ptr [rcx + rax], 0
0x00014289fdc7:  75f7                  jne       0x14289fdc0
0x00014289fdc9:  488945bf              mov       qword ptr [rbp - 0x41], rax
0x00014289fdcd:  48895d97              mov       qword ptr [rbp - 0x69], rbx
0x00014289fdd1:  0f284597              movaps    xmm0, xmmword ptr [rbp - 0x69]
0x00014289fdd5:  660f7f4507            movdqa    xmmword ptr [rbp + 7], xmm0
0x00014289fdda:  48c745a704000000      mov       qword ptr [rbp - 0x59], 4
0x00014289fde2:  488d4507              lea       rax, [rbp + 7]
0x00014289fde6:  488945af              mov       qword ptr [rbp - 0x51], rax
0x00014289fdea:  0f2845a7              movaps    xmm0, xmmword ptr [rbp - 0x59]
0x00014289fdee:  660f7f45a7            movdqa    xmmword ptr [rbp - 0x59], xmm0
0x00014289fdf3:  0f284db7              movaps    xmm1, xmmword ptr [rbp - 0x49]
0x00014289fdf7:  660f7f4db7            movdqa    xmmword ptr [rbp - 0x49], xmm1
0x00014289fdfc:  0f100565ad4c05        movups    xmm0, xmmword ptr [rip + 0x54cad65]
0x00014289fe03:  0f2945c7              movaps    xmmword ptr [rbp - 0x39], xmm0
0x00014289fe07:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x00014289fe0c:  4c8d4da7              lea       r9, [rbp - 0x59]
0x00014289fe10:  4c8d45b7              lea       r8, [rbp - 0x49]
0x00014289fe14:  b206                  mov       dl, 6
0x00014289fe16:  488d4dc7              lea       rcx, [rbp - 0x39]
0x00014289fe1a:  e8b1fc0b02            call      0x14495fad0
0x00014289fe1f:  488b758f              mov       rsi, qword ptr [rbp - 0x71]
0x00014289fe23:  488b7d87              mov       rdi, qword ptr [rbp - 0x79]
0x00014289fe27:  498b06                mov       rax, qword ptr [r14]
0x00014289fe2a:  498bce                mov       rcx, r14
0x00014289fe2d:  488b4008              mov       rax, qword ptr [rax + 8]
0x00014289fe31:  ff1501ff8903          call      qword ptr [rip + 0x389ff01]
0x00014289fe37:  488945d7              mov       qword ptr [rbp - 0x29], rax
0x00014289fe3b:  48895ddf              mov       qword ptr [rbp - 0x21], rbx
0x00014289fe3f:  0f2845d7              movaps    xmm0, xmmword ptr [rbp - 0x29]
0x00014289fe43:  660f7f45c7            movdqa    xmmword ptr [rbp - 0x39], xmm0
0x00014289fe48:  4d8bcc                mov       r9, r12
0x00014289fe4b:  4c8d45c7              lea       r8, [rbp - 0x39]
0x00014289fe4f:  488d55e7              lea       rdx, [rbp - 0x19]
0x00014289fe53:  488bcf                mov       rcx, rdi
0x00014289fe56:  e805579dff            call      0x142275560
0x00014289fe5b:  837de700              cmp       dword ptr [rbp - 0x19], 0
0x00014289fe5f:  7431                  je        0x14289fe92
0x00014289fe61:  4533c9                xor       r9d, r9d
0x00014289fe64:  4533c0                xor       r8d, r8d
0x00014289fe67:  488d55e7              lea       rdx, [rbp - 0x19]
0x00014289fe6b:  488bcf                mov       rcx, rdi
0x00014289fe6e:  44380553afa205        cmp       byte ptr [rip + 0x5a2af53], r8b
0x00014289fe75:  7411                  je        0x14289fe88
0x00014289fe77:  4488442428            mov       byte ptr [rsp + 0x28], r8b
0x00014289fe7c:  4488442420            mov       byte ptr [rsp + 0x20], r8b
0x00014289fe81:  e84a3f9dff            call      0x142273dd0
0x00014289fe86:  eb0a                  jmp       0x14289fe92
0x00014289fe88:  c644242000            mov       byte ptr [rsp + 0x20], 0
0x00014289fe8d:  e81e2b9dff            call      0x1422729b0
0x00014289fe92:  488d14dd00000000      lea       rdx, [rbx*8]
0x00014289fe9a:  41895610              mov       dword ptr [r14 + 0x10], edx
0x00014289fe9e:  4885f6                test      rsi, rsi
0x00014289fea1:  7408                  je        0x14289feab
0x00014289fea3:  488bce                mov       rcx, rsi
0x00014289fea6:  e86590f2fd            call      0x1407c8f10
0x00014289feab:  488bc3                mov       rax, rbx
0x00014289feae:  488b4d17              mov       rcx, qword ptr [rbp + 0x17]
0x00014289feb2:  4833cc                xor       rcx, rsp
0x00014289feb5:  e826172803            call      0x145b215e0
0x00014289feba:  4881c4d0000000        add       rsp, 0xd0
0x00014289fec1:  415f                  pop       r15
0x00014289fec3:  415e                  pop       r14
0x00014289fec5:  415c                  pop       r12
0x00014289fec7:  5f                    pop       rdi
0x00014289fec8:  5e                    pop       rsi
0x00014289fec9:  5b                    pop       rbx
0x00014289feca:  5d                    pop       rbp
0x00014289fecb:  c3                    ret       
0x00014289fecc:  cc                    int3      
0x00014289fecd:  cc                    int3      
0x00014289fece:  cc                    int3      
0x00014289fecf:  cc                    int3      
0x00014289fed0:  448981f8080000        mov       dword ptr [rcx + 0x8f8], r8d
0x00014289fed7:  c3                    ret       
0x00014289fed8:  cc                    int3      
0x00014289fed9:  cc                    int3      
0x00014289feda:  cc                    int3      
0x00014289fedb:  cc                    int3      
0x00014289fedc:  cc                    int3      
0x00014289fedd:  cc                    int3      
0x00014289fede:  cc                    int3      
0x00014289fedf:  cc                    int3      
0x00014289fee0:  8b81f8080000          mov       eax, dword ptr [rcx + 0x8f8]
0x00014289fee6:  c3                    ret       
0x00014289fee7:  cc                    int3      
0x00014289fee8:  cc                    int3      
0x00014289fee9:  cc                    int3      
0x00014289feea:  cc                    int3      
0x00014289feeb:  cc                    int3      
0x00014289feec:  cc                    int3      
0x00014289feed:  cc                    int3      
0x00014289feee:  cc                    int3      
0x00014289feef:  cc                    int3      
0x00014289fef0:  889150100000          mov       byte ptr [rcx + 0x1050], dl
0x00014289fef6:  889151100000          mov       byte ptr [rcx + 0x1051], dl
0x00014289fefc:  c3                    ret       
0x00014289fefd:  cc                    int3      
0x00014289fefe:  cc                    int3      
0x00014289feff:  cc                    int3      
0x00014289ff00:  48896c2410            mov       qword ptr [rsp + 0x10], rbp
0x00014289ff05:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x00014289ff0a:  57                    push      rdi
0x00014289ff0b:  4156                  push      r14
0x00014289ff0d:  4157                  push      r15
0x00014289ff0f:  4881ec80000000        sub       rsp, 0x80
0x00014289ff16:  0f1012                movups    xmm2, xmmword ptr [rdx]
0x00014289ff19:  33c0                  xor       eax, eax
0x00014289ff1b:  488be9                mov       rbp, rcx
0x00014289ff1e:  f20f104a10            movsd     xmm1, qword ptr [rdx + 0x10]
0x00014289ff23:  4d8bf9                mov       r15, r9
0x00014289ff26:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x00014289ff2b:  66480f7ed1            movq      rcx, xmm2
0x00014289ff30:  8b4218                mov       eax, dword ptr [rdx + 0x18]
0x00014289ff33:  458bf0                mov       r14d, r8d
0x00014289ff36:  89442478              mov       dword ptr [rsp + 0x78], eax
0x00014289ff3a:  0fb7421e              movzx     eax, word ptr [rdx + 0x1e]
0x00014289ff3e:  668944247e            mov       word ptr [rsp + 0x7e], ax
0x00014289ff43:  0fb7421c              movzx     eax, word ptr [rdx + 0x1c]
0x00014289ff47:  668944247c            mov       word ptr [rsp + 0x7c], ax
0x00014289ff4c:  488bc1                mov       rax, rcx
0x00014289ff4f:  0f10442470            movups    xmm0, xmmword ptr [rsp + 0x70]
0x00014289ff54:  48c1e810              shr       rax, 0x10
0x00014289ff58:  663b05ebf85405        cmp       ax, word ptr [rip + 0x554f8eb]
0x00014289ff5f:  f20f10c1              movsd     xmm0, xmm1
0x00014289ff63:  0f29542430            movaps    xmmword ptr [rsp + 0x30], xmm2
0x00014289ff68:  488b742438            mov       rsi, qword ptr [rsp + 0x38]
0x00014289ff6d:  0f29442440            movaps    xmmword ptr [rsp + 0x40], xmm0
0x00014289ff72:  488b7c2440            mov       rdi, qword ptr [rsp + 0x40]
0x00014289ff77:  0f11542460            movups    xmmword ptr [rsp + 0x60], xmm2
0x00014289ff7c:  440fb75c2460          movzx     r11d, word ptr [rsp + 0x60]
0x00014289ff82:  753a                  jne       0x14289ffbe
0x00014289ff84:  66443b1dbcf85405      cmp       r11w, word ptr [rip + 0x554f8bc]
0x00014289ff8c:  7530                  jne       0x14289ffbe
0x00014289ff8e:  664183fb02            cmp       r11w, 2
0x00014289ff93:  750c                  jne       0x14289ffa1
0x00014289ff95:  48c1e920              shr       rcx, 0x20
0x00014289ff99:  3b0dadf85405          cmp       ecx, dword ptr [rip + 0x554f8ad]
0x00014289ff9f:  eb17                  jmp       0x14289ffb8
0x00014289ffa1:  664183fb17            cmp       r11w, 0x17
0x00014289ffa6:  7516                  jne       0x14289ffbe
0x00014289ffa8:  483b35a1f85405        cmp       rsi, qword ptr [rip + 0x554f8a1]
0x00014289ffaf:  750d                  jne       0x14289ffbe
0x00014289ffb1:  483b3da0f85405        cmp       rdi, qword ptr [rip + 0x554f8a0]
0x00014289ffb8:  0f845d010000          je        0x1428a011b
0x00014289ffbe:  0fb78512010000        movzx     eax, word ptr [rbp + 0x112]
0x00014289ffc5:  48899c24a0000000      mov       qword ptr [rsp + 0xa0], rbx
0x00014289ffcd:  8bd8                  mov       ebx, eax
0x00014289ffcf:  6685c0                test      ax, ax
0x00014289ffd2:  7505                  jne       0x14289ffd9
0x00014289ffd4:  bb01000000            mov       ebx, 1
0x00014289ffd9:  ba02000000            mov       edx, 2
0x00014289ffde:  488d4c2432            lea       rcx, [rsp + 0x32]
0x00014289ffe3:  448bc2                mov       r8d, edx
0x00014289ffe6:  e8f5ad0100            call      0x1428bade0
0x00014289ffeb:  448bc0                mov       r8d, eax
0x00014289ffee:  664183fb02            cmp       r11w, 2
0x00014289fff3:  740c                  je        0x1428a0001
0x00014289fff5:  ba10000000            mov       edx, 0x10
0x00014289fffa:  488d4c2438            lea       rcx, [rsp + 0x38]
0x00014289ffff:  eb0a                  jmp       0x1428a000b
0x0001428a0001:  ba04000000            mov       edx, 4
0x0001428a0006:  488d4c2434            lea       rcx, [rsp + 0x34]
0x0001428a000b:  e8d0ad0100            call      0x1428bade0
0x0001428a0010:  33d2                  xor       edx, edx
0x0001428a0012:  8d0cdd00000000        lea       ecx, [rbx*8]
0x0001428a0019:  f7f1                  div       ecx
0x0001428a001b:  488b8580030000        mov       rax, qword ptr [rbp + 0x380]
0x0001428a0022:  488b14d0              mov       rdx, qword ptr [rax + rdx*8]
0x0001428a0026:  4885d2                test      rdx, rdx
0x0001428a0029:  0f84e4000000          je        0x1428a0113
0x0001428a002f:  4c8b8d50030000        mov       r9, qword ptr [rbp + 0x350]
0x0001428a0036:  448b542464            mov       r10d, dword ptr [rsp + 0x64]
0x0001428a003b:  0fb75c2462            movzx     ebx, word ptr [rsp + 0x62]
0x0001428a0040:  448b02                mov       r8d, dword ptr [rdx]
0x0001428a0043:  4969c0d8160000        imul      rax, r8, 0x16d8
0x0001428a004a:  6642395c0806          cmp       word ptr [rax + r9 + 6], bx
0x0001428a0050:  752d                  jne       0x1428a007f
0x0001428a0052:  420fb74c0804          movzx     ecx, word ptr [rax + r9 + 4]
0x0001428a0058:  66413bcb              cmp       cx, r11w
0x0001428a005c:  7521                  jne       0x1428a007f
0x0001428a005e:  6683f902              cmp       cx, 2
0x0001428a0062:  7507                  jne       0x1428a006b
0x0001428a0064:  4639540808            cmp       dword ptr [rax + r9 + 8], r10d
0x0001428a0069:  eb12                  jmp       0x1428a007d
0x0001428a006b:  6683f917              cmp       cx, 0x17
0x0001428a006f:  750e                  jne       0x1428a007f
0x0001428a0071:  4a3974080c            cmp       qword ptr [rax + r9 + 0xc], rsi
0x0001428a0076:  7507                  jne       0x1428a007f
0x0001428a0078:  4a397c0814            cmp       qword ptr [rax + r9 + 0x14], rdi
0x0001428a007d:  740e                  je        0x1428a008d
0x0001428a007f:  488b5208              mov       rdx, qword ptr [rdx + 8]
0x0001428a0083:  4885d2                test      rdx, rdx
0x0001428a0086:  75b8                  jne       0x1428a0040
0x0001428a0088:  e986000000            jmp       0x1428a0113
0x0001428a008d:  4183f8ff              cmp       r8d, -1
0x0001428a0091:  0f847c000000          je        0x1428a0113
0x0001428a0097:  4969c8d8160000        imul      rcx, r8, 0x16d8
0x0001428a009e:  420fb60409            movzx     eax, byte ptr [rcx + r9]
0x0001428a00a3:  90                    nop       
0x0001428a00a4:  3c01                  cmp       al, 1
0x0001428a00a6:  756b                  jne       0x1428a0113
0x0001428a00a8:  48038d50030000        add       rcx, qword ptr [rbp + 0x350]
0x0001428a00af:  7462                  je        0x1428a0113
0x0001428a00b1:  4585f6                test      r14d, r14d
0x0001428a00b4:  7507                  jne       0x1428a00bd
0x0001428a00b6:  4488b1d0160000        mov       byte ptr [rcx + 0x16d0], r14b
0x0001428a00bd:  80b9d016000000        cmp       byte ptr [rcx + 0x16d0], 0
0x0001428a00c4:  754d                  jne       0x1428a0113
0x0001428a00c6:  48630513b04c05        movsxd    rax, dword ptr [rip + 0x54cb013]
0x0001428a00cd:  4c3bf8                cmp       r15, rax
0x0001428a00d0:  7241                  jb        0x1428a0113
0x0001428a00d2:  488b8180160000        mov       rax, qword ptr [rcx + 0x1680]
0x0001428a00d9:  498bd7                mov       rdx, r15
0x0001428a00dc:  4c8b8c24c0000000      mov       r9, qword ptr [rsp + 0xc0]
0x0001428a00e4:  4c2b8920160000        sub       r9, qword ptr [rcx + 0x1620]
0x0001428a00eb:  c681d016000001        mov       byte ptr [rcx + 0x16d0], 1
0x0001428a00f2:  418bce                mov       ecx, r14d
0x0001428a00f5:  803dccaca20500        cmp       byte ptr [rip + 0x5a2accc], 0
0x0001428a00fc:  448b4048              mov       r8d, dword ptr [rax + 0x48]
0x0001428a0100:  740c                  je        0x1428a010e
0x0001428a0102:  c644242000            mov       byte ptr [rsp + 0x20], 0
0x0001428a0107:  e804479dff            call      0x142274810
0x0001428a010c:  eb05                  jmp       0x1428a0113
0x0001428a010e:  e8bd319dff            call      0x1422732d0
0x0001428a0113:  488b9c24a0000000      mov       rbx, qword ptr [rsp + 0xa0]
0x0001428a011b:  4c8d9c2480000000      lea       r11, [rsp + 0x80]
0x0001428a0123:  498b6b28              mov       rbp, qword ptr [r11 + 0x28]
0x0001428a0127:  498b7330              mov       rsi, qword ptr [r11 + 0x30]
0x0001428a012b:  498be3                mov       rsp, r11
0x0001428a012e:  415f                  pop       r15
0x0001428a0130:  415e                  pop       r14
0x0001428a0132:  5f                    pop       rdi
0x0001428a0133:  c3                    ret       
0x0001428a0134:  cc                    int3      
0x0001428a0135:  cc                    int3      
0x0001428a0136:  cc                    int3      
0x0001428a0137:  cc                    int3      
0x0001428a0138:  cc                    int3      
0x0001428a0139:  cc                    int3      
0x0001428a013a:  cc                    int3      
0x0001428a013b:  cc                    int3      
0x0001428a013c:  cc                    int3      
0x0001428a013d:  cc                    int3      
0x0001428a013e:  cc                    int3      
0x0001428a013f:  cc                    int3      
0x0001428a0140:  48895c2418            mov       qword ptr [rsp + 0x18], rbx
0x0001428a0145:  48897c2420            mov       qword ptr [rsp + 0x20], rdi
0x0001428a014a:  55                    push      rbp
0x0001428a014b:  488dac2420fbffff      lea       rbp, [rsp - 0x4e0]
0x0001428a0153:  4881ece0050000        sub       rsp, 0x5e0
0x0001428a015a:  488b058f354705        mov       rax, qword ptr [rip + 0x547358f]
0x0001428a0161:  4833c4                xor       rax, rsp
0x0001428a0164:  488985d0040000        mov       qword ptr [rbp + 0x4d0], rax
0x0001428a016b:  4c8bc2                mov       r8, rdx
0x0001428a016e:  488bd9                mov       rbx, rcx
0x0001428a0171:  482bda                sub       rbx, rdx
0x0001428a0174:  48b877be9f1a2fdd2406  movabs    rax, 0x624dd2f1a9fbe77
0x0001428a017e:  48f7e3                mul       rbx
0x0001428a0181:  482bda                sub       rbx, rdx
0x0001428a0184:  48d1eb                shr       rbx, 1
0x0001428a0187:  4803da                add       rbx, rdx
0x0001428a018a:  48c1eb09              shr       rbx, 9
0x0001428a018e:  4d85c0                test      r8, r8
0x0001428a0191:  0f84ff010000          je        0x1428a0396
0x0001428a0197:  3b1d1baf4c05          cmp       ebx, dword ptr [rip + 0x54caf1b]
0x0001428a019d:  0f8cf3010000          jl        0x1428a0396
0x0001428a01a3:  8b0d7f81a205          mov       ecx, dword ptr [rip + 0x5a2817f]
0x0001428a01a9:  e832a41d00            call      0x142a7a5e0
0x0001428a01ae:  84c0                  test      al, al
0x0001428a01b0:  0f8469010000          je        0x1428a031f
0x0001428a01b6:  4533c0                xor       r8d, r8d
0x0001428a01b9:  8b156981a205          mov       edx, dword ptr [rip + 0x5a28169]
0x0001428a01bf:  488d4c2450            lea       rcx, [rsp + 0x50]
0x0001428a01c4:  e8f7c81d00            call      0x142a7cac0
0x0001428a01c9:  90                    nop       
0x0001428a01ca:  4533c0                xor       r8d, r8d
0x0001428a01cd:  488d3df09e6904        lea       rdi, [rip + 0x4699ef0]
0x0001428a01d4:  488bd7                mov       rdx, rdi
0x0001428a01d7:  488d4c2450            lea       rcx, [rsp + 0x50]
0x0001428a01dc:  e80ff61d00            call      0x142a7f7f0
0x0001428a01e1:  4885c0                test      rax, rax
0x0001428a01e4:  744a                  je        0x1428a0230
0x0001428a01e6:  8bd3                  mov       edx, ebx
0x0001428a01e8:  488bc8                mov       rcx, rax
0x0001428a01eb:  e8f0aa1d00            call      0x142a7ace0
0x0001428a01f0:  488b8da8010000        mov       rcx, qword ptr [rbp + 0x1a8]
0x0001428a01f7:  4885c9                test      rcx, rcx
0x0001428a01fa:  7434                  je        0x1428a0230
0x0001428a01fc:  488b01                mov       rax, qword ptr [rcx]
0x0001428a01ff:  48897c2430            mov       qword ptr [rsp + 0x30], rdi
0x0001428a0204:  48c744243806000000    mov       qword ptr [rsp + 0x38], 6
0x0001428a020d:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x0001428a0212:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x0001428a0218:  4c63c3                movsxd    r8, ebx
0x0001428a021b:  41b901000000          mov       r9d, 1
0x0001428a0221:  488d542430            lea       rdx, [rsp + 0x30]
0x0001428a0226:  488b4028              mov       rax, qword ptr [rax + 0x28]
0x0001428a022a:  ff1508fb8903          call      qword ptr [rip + 0x389fb08]
0x0001428a0230:  8b1df280a205          mov       ebx, dword ptr [rip + 0x5a280f2]
0x0001428a0236:  33c0                  xor       eax, eax
0x0001428a0238:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x0001428a023d:  4889442440            mov       qword ptr [rsp + 0x40], rax
0x0001428a0242:  48c74424480f000000    mov       qword ptr [rsp + 0x48], 0xf
0x0001428a024b:  88442430              mov       byte ptr [rsp + 0x30], al
0x0001428a024f:  8d4820                lea       ecx, [rax + 0x20]
0x0001428a0252:  e8799ef4fd            call      0x1407ea0d0
0x0001428a0257:  48c744244014000000    mov       qword ptr [rsp + 0x40], 0x14
0x0001428a0260:  48c74424481f000000    mov       qword ptr [rsp + 0x48], 0x1f
0x0001428a0269:  0f1005609e6904        movups    xmm0, xmmword ptr [rip + 0x4699e60]
0x0001428a0270:  0f1100                movups    xmmword ptr [rax], xmm0
0x0001428a0273:  8b0d679e6904          mov       ecx, dword ptr [rip + 0x4699e67]
0x0001428a0279:  894810                mov       dword ptr [rax + 0x10], ecx
0x0001428a027c:  c6401400              mov       byte ptr [rax + 0x14], 0
0x0001428a0280:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x0001428a0285:  c644242000            mov       byte ptr [rsp + 0x20], 0
0x0001428a028a:  41b101                mov       r9b, 1
0x0001428a028d:  448bc3                mov       r8d, ebx
0x0001428a0290:  488d542430            lea       rdx, [rsp + 0x30]
0x0001428a0295:  488d4c2450            lea       rcx, [rsp + 0x50]
0x0001428a029a:  e801e81d00            call      0x142a7eaa0
0x0001428a029f:  90                    nop       
0x0001428a02a0:  488b442448            mov       rax, qword ptr [rsp + 0x48]
0x0001428a02a5:  4883f810              cmp       rax, 0x10
0x0001428a02a9:  722e                  jb        0x1428a02d9
0x0001428a02ab:  48ffc0                inc       rax
0x0001428a02ae:  488b4c2430            mov       rcx, qword ptr [rsp + 0x30]
0x0001428a02b3:  488bd1                mov       rdx, rcx
0x0001428a02b6:  483d00100000          cmp       rax, 0x1000
0x0001428a02bc:  7215                  jb        0x1428a02d3
0x0001428a02be:  488b49f8              mov       rcx, qword ptr [rcx - 8]
0x0001428a02c2:  482bd1                sub       rdx, rcx
0x0001428a02c5:  488d42f8              lea       rax, [rdx - 8]
0x0001428a02c9:  4883f81f              cmp       rax, 0x1f
0x0001428a02cd:  0f87e7000000          ja        0x1428a03ba
0x0001428a02d3:  e8d82d0a02            call      0x1449430b0
0x0001428a02d8:  90                    nop       
0x0001428a02d9:  488b8db0010000        mov       rcx, qword ptr [rbp + 0x1b0]
0x0001428a02e0:  4885c9                test      rcx, rcx
0x0001428a02e3:  7405                  je        0x1428a02ea
0x0001428a02e5:  e8268cf2fd            call      0x1407c8f10
0x0001428a02ea:  488d8d80010000        lea       rcx, [rbp + 0x180]
0x0001428a02f1:  e8ea56f4fd            call      0x1407e59e0
0x0001428a02f6:  488d8d58010000        lea       rcx, [rbp + 0x158]
0x0001428a02fd:  e8de56f4fd            call      0x1407e59e0
0x0001428a0302:  90                    nop       
0x0001428a0303:  488d4c2450            lea       rcx, [rsp + 0x50]
0x0001428a0308:  e873d0f7fd            call      0x14081d380
0x0001428a030d:  f644245001            test      byte ptr [rsp + 0x50], 1
0x0001428a0312:  750b                  jne       0x1428a031f
0x0001428a0314:  488b4c2458            mov       rcx, qword ptr [rsp + 0x58]
0x0001428a0319:  e8922d0a02            call      0x1449430b0
0x0001428a031e:  90                    nop       
0x0001428a031f:  488d1522af4c05        lea       rdx, [rip + 0x54caf22]
0x0001428a0326:  488d8dc0010000        lea       rcx, [rbp + 0x1c0]
0x0001428a032d:  e8ee14f3fd            call      0x1407d1820
0x0001428a0332:  90                    nop       
0x0001428a0333:  4c630562284805        movsxd    r8, dword ptr [rip + 0x5482862]
0x0001428a033a:  488d05afec6704        lea       rax, [rip + 0x467ecaf]
0x0001428a0341:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x0001428a0346:  48c74424380c000000    mov       qword ptr [rsp + 0x38], 0xc
0x0001428a034f:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x0001428a0354:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x0001428a035a:  41b901000000          mov       r9d, 1
0x0001428a0360:  488d542430            lea       rdx, [rsp + 0x30]
0x0001428a0365:  488d8d90040000        lea       rcx, [rbp + 0x490]
0x0001428a036c:  e81f276300            call      0x142ed2a90
0x0001428a0371:  488d8d98040000        lea       rcx, [rbp + 0x498]
0x0001428a0378:  e8233b6200            call      0x142ec3ea0
0x0001428a037d:  90                    nop       
0x0001428a037e:  488d8d90040000        lea       rcx, [rbp + 0x490]
0x0001428a0385:  e8a612f3fd            call      0x1407d1630
0x0001428a038a:  488d8de8010000        lea       rcx, [rbp + 0x1e8]
0x0001428a0391:  e84a56f4fd            call      0x1407e59e0
0x0001428a0396:  488b8dd0040000        mov       rcx, qword ptr [rbp + 0x4d0]
0x0001428a039d:  4833cc                xor       rcx, rsp
0x0001428a03a0:  e83b122803            call      0x145b215e0
0x0001428a03a5:  4c8d9c24e0050000      lea       r11, [rsp + 0x5e0]
0x0001428a03ad:  498b5b20              mov       rbx, qword ptr [r11 + 0x20]
0x0001428a03b1:  498b7b28              mov       rdi, qword ptr [r11 + 0x28]
0x0001428a03b5:  498be3                mov       rsp, r11
0x0001428a03b8:  5d                    pop       rbp
0x0001428a03b9:  c3                    ret       
0x0001428a03ba:  e861112b03            call      0x145b51520
0x0001428a03bf:  90                    nop       
