; lambdaBaa9 vtable slot 0 rva 0x28a5010
0x1428a5010:  488d0579e33f04       lea       rax, [rip + 0x43fe379]
0x1428a5017:  488902               mov       qword ptr [rdx], rax
0x1428a501a:  488bc2               mov       rax, rdx
0x1428a501d:  0f104108             movups    xmm0, xmmword ptr [rcx + 8]
0x1428a5021:  0f114208             movups    xmmword ptr [rdx + 8], xmm0
0x1428a5025:  c3                   ret       
0x1428a5026:  cc                   int3      
0x1428a5027:  cc                   int3      
0x1428a5028:  cc                   int3      
0x1428a5029:  cc                   int3      
0x1428a502a:  cc                   int3      
0x1428a502b:  cc                   int3      
0x1428a502c:  cc                   int3      
0x1428a502d:  cc                   int3      
0x1428a502e:  cc                   int3      
0x1428a502f:  cc                   int3      
0x1428a5030:  4883c110             add       rcx, 0x10
0x1428a5034:  e9c7c78cff           jmp       0x142171800
0x1428a5039:  cc                   int3      
0x1428a503a:  cc                   int3      
0x1428a503b:  cc                   int3      
0x1428a503c:  cc                   int3      
0x1428a503d:  cc                   int3      
0x1428a503e:  cc                   int3      
0x1428a503f:  cc                   int3      
