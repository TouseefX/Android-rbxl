; function_of: str.setServerMachineAddress, str.setServerRuppStemma, vtab.RuppTokenProcessor
; xref site 0x14289dfcd -> vtab.RuppTokenProcessor @ 0x146c989b8
; xref site 0x14289dff7 -> vtab.RuppTokenProcessor @ 0x146c989b8
; xref site 0x14289e042 -> str.setServerRuppStemma @ 0x146f39e18
; xref site 0x14289e13e -> str.setServerMachineAddress @ 0x146f39dd8
; range 0x14289dfa0 .. 0x14289e210  (624 bytes)

0x00014289dfa0:  4053                  push      rbx
0x00014289dfa2:  4883ec60              sub       rsp, 0x60
0x00014289dfa6:  488d99a00e0000        lea       rbx, [rcx + 0xea0]
0x00014289dfad:  48833b00              cmp       qword ptr [rbx], 0
0x00014289dfb1:  0f85ba000000          jne       0x14289e071
0x00014289dfb7:  b910000000            mov       ecx, 0x10
0x00014289dfbc:  e83f580a02            call      0x144943800
0x00014289dfc1:  4885c0                test      rax, rax
0x00014289dfc4:  0f84ad000000          je        0x14289e077
0x00014289dfca:  488d0de7a93f04        lea       rcx, [rip + 0x43fa9e7]
0x00014289dfd1:  488908                mov       qword ptr [rax], rcx
0x00014289dfd4:  488d4c2470            lea       rcx, [rsp + 0x70]
0x00014289dfd9:  483bd9                cmp       rbx, rcx
0x00014289dfdc:  7413                  je        0x14289dff1
0x00014289dfde:  488b0b                mov       rcx, qword ptr [rbx]
0x00014289dfe1:  488903                mov       qword ptr [rbx], rax
0x00014289dfe4:  4885c9                test      rcx, rcx
0x00014289dfe7:  741d                  je        0x14289e006
0x00014289dfe9:  488b01                mov       rax, qword ptr [rcx]
0x00014289dfec:  488b00                mov       rax, qword ptr [rax]
0x00014289dfef:  eb0a                  jmp       0x14289dffb
0x00014289dff1:  488bc8                mov       rcx, rax
0x00014289dff4:  488b05bda93f04        mov       rax, qword ptr [rip + 0x43fa9bd]
0x00014289dffb:  ba01000000            mov       edx, 1
0x00014289e000:  ff15321d8a03          call      qword ptr [rip + 0x38a1d32]
0x00014289e006:  488b0523204c05        mov       rax, qword ptr [rip + 0x54c2023]
0x00014289e00d:  3c06                  cmp       al, 6
0x00014289e00f:  7260                  jb        0x14289e071
0x00014289e011:  48c1e808              shr       rax, 8
0x00014289e015:  3c03                  cmp       al, 3
0x00014289e017:  7258                  jb        0x14289e071
0x00014289e019:  488d0576fd0307        lea       rax, [rip + 0x703fd76]
0x00014289e020:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x00014289e025:  4c8d05a4bd6904        lea       r8, [rip + 0x469bda4]
0x00014289e02c:  488b542470            mov       rdx, qword ptr [rsp + 0x70]
0x00014289e031:  488d0518be6904        lea       rax, [rip + 0x469be18]
0x00014289e038:  0f1005f11f4c05        movups    xmm0, xmmword ptr [rip + 0x54c1ff1]
0x00014289e03f:  488d15d2bd6904        lea       rdx, [rip + 0x469bdd2]
0x00014289e046:  488d4c2440            lea       rcx, [rsp + 0x40]
0x00014289e04b:  48833b00              cmp       qword ptr [rbx], 0
0x00014289e04f:  0f29442440            movaps    xmmword ptr [rsp + 0x40], xmm0
0x00014289e054:  4c0f45c0              cmovne    r8, rax
0x00014289e058:  33c0                  xor       eax, eax
0x00014289e05a:  4889442430            mov       qword ptr [rsp + 0x30], rax
0x00014289e05f:  4533c9                xor       r9d, r9d
0x00014289e062:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x00014289e067:  4889442420            mov       qword ptr [rsp + 0x20], rax
0x00014289e06c:  e8af1d0c02            call      0x14495fe20
0x00014289e071:  4883c460              add       rsp, 0x60
0x00014289e075:  5b                    pop       rbx
0x00014289e076:  c3                    ret       
0x00014289e077:  488d4c2440            lea       rcx, [rsp + 0x40]
0x00014289e07c:  e86fcdf1fd            call      0x1407badf0
0x00014289e081:  488d15b88b4605        lea       rdx, [rip + 0x5468bb8]
0x00014289e088:  488d4c2440            lea       rcx, [rsp + 0x40]
0x00014289e08d:  e8be4f2a03            call      0x145b43050
0x00014289e092:  cc                    int3      
0x00014289e093:  cc                    int3      
0x00014289e094:  cc                    int3      
0x00014289e095:  cc                    int3      
0x00014289e096:  cc                    int3      
0x00014289e097:  cc                    int3      
0x00014289e098:  cc                    int3      
0x00014289e099:  cc                    int3      
0x00014289e09a:  cc                    int3      
0x00014289e09b:  cc                    int3      
0x00014289e09c:  cc                    int3      
0x00014289e09d:  cc                    int3      
0x00014289e09e:  cc                    int3      
0x00014289e09f:  cc                    int3      
0x00014289e0a0:  48895c2410            mov       qword ptr [rsp + 0x10], rbx
0x00014289e0a5:  57                    push      rdi
0x00014289e0a6:  4881ec80000000        sub       rsp, 0x80
0x00014289e0ad:  488b053c564705        mov       rax, qword ptr [rip + 0x547563c]
0x00014289e0b4:  4833c4                xor       rax, rsp
0x00014289e0b7:  4889442470            mov       qword ptr [rsp + 0x70], rax
0x00014289e0bc:  0f1002                movups    xmm0, xmmword ptr [rdx]
0x00014289e0bf:  488d7964              lea       rdi, [rcx + 0x64]
0x00014289e0c3:  488bd9                mov       rbx, rcx
0x00014289e0c6:  488bcf                mov       rcx, rdi
0x00014289e0c9:  0f1107                movups    xmmword ptr [rdi], xmm0
0x00014289e0cc:  f20f104a10            movsd     xmm1, qword ptr [rdx + 0x10]
0x00014289e0d1:  f20f114f10            movsd     qword ptr [rdi + 0x10], xmm1
0x00014289e0d6:  8b4218                mov       eax, dword ptr [rdx + 0x18]
0x00014289e0d9:  894718                mov       dword ptr [rdi + 0x18], eax
0x00014289e0dc:  0fb7421e              movzx     eax, word ptr [rdx + 0x1e]
0x00014289e0e0:  6689471e              mov       word ptr [rdi + 0x1e], ax
0x00014289e0e4:  0fb7421c              movzx     eax, word ptr [rdx + 0x1c]
0x00014289e0e8:  6689471c              mov       word ptr [rdi + 0x1c], ax
0x00014289e0ec:  e8df740000            call      0x1428a55d0
0x00014289e0f1:  4883c324              add       rbx, 0x24
0x00014289e0f5:  41b940000000          mov       r9d, 0x40
0x00014289e0fb:  4c8bc3                mov       r8, rbx
0x00014289e0fe:  33d2                  xor       edx, edx
0x00014289e100:  488bcf                mov       rcx, rdi
0x00014289e103:  e898750000            call      0x1428a56a0
0x00014289e108:  488b05211f4c05        mov       rax, qword ptr [rip + 0x54c1f21]
0x00014289e10f:  3c06                  cmp       al, 6
0x00014289e111:  0f829e000000          jb        0x14289e1b5
0x00014289e117:  48c1e808              shr       rax, 8
0x00014289e11b:  3c04                  cmp       al, 4
0x00014289e11d:  0f8292000000          jb        0x14289e1b5
0x00014289e123:  488d05febf0407        lea       rax, [rip + 0x704bffe]
0x00014289e12a:  4889442450            mov       qword ptr [rsp + 0x50], rax
0x00014289e12f:  48c7c0ffffffff        mov       rax, 0xffffffffffffffff
0x00014289e136:  488b4c2450            mov       rcx, qword ptr [rsp + 0x50]
0x00014289e13b:  488d0d96bc6904        lea       rcx, [rip + 0x469bc96]
0x00014289e142:  48894c2440            mov       qword ptr [rsp + 0x40], rcx
0x00014289e147:  48ffc0                inc       rax
0x00014289e14a:  803c0100              cmp       byte ptr [rcx + rax], 0
0x00014289e14e:  75f7                  jne       0x14289e147
0x00014289e150:  4889442448            mov       qword ptr [rsp + 0x48], rax
0x00014289e155:  4c8d4c2430            lea       r9, [rsp + 0x30]
0x00014289e15a:  0f284c2440            movaps    xmm1, xmmword ptr [rsp + 0x40]
0x00014289e15f:  488d442460            lea       rax, [rsp + 0x60]
0x00014289e164:  48895c2460            mov       qword ptr [rsp + 0x60], rbx
0x00014289e169:  4c8d442440            lea       r8, [rsp + 0x40]
0x00014289e16e:  0f28442460            movaps    xmm0, xmmword ptr [rsp + 0x60]
0x00014289e173:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014289e178:  660f7f442460          movdqa    xmmword ptr [rsp + 0x60], xmm0
0x00014289e17e:  b204                  mov       dl, 4
0x00014289e180:  4889442438            mov       qword ptr [rsp + 0x38], rax
0x00014289e185:  48c74424300c000000    mov       qword ptr [rsp + 0x30], 0xc
0x00014289e18e:  0f28442430            movaps    xmm0, xmmword ptr [rsp + 0x30]
0x00014289e193:  660f7f442430          movdqa    xmmword ptr [rsp + 0x30], xmm0
0x00014289e199:  0f1005901e4c05        movups    xmm0, xmmword ptr [rip + 0x54c1e90]
0x00014289e1a0:  c644242001            mov       byte ptr [rsp + 0x20], 1
0x00014289e1a5:  660f7f4c2440          movdqa    xmmword ptr [rsp + 0x40], xmm1
0x00014289e1ab:  0f29442450            movaps    xmmword ptr [rsp + 0x50], xmm0
0x00014289e1b0:  e81b190c02            call      0x14495fad0
0x00014289e1b5:  488b4c2470            mov       rcx, qword ptr [rsp + 0x70]
0x00014289e1ba:  4833cc                xor       rcx, rsp
0x00014289e1bd:  e81e342803            call      0x145b215e0
0x00014289e1c2:  488b9c2498000000      mov       rbx, qword ptr [rsp + 0x98]
0x00014289e1ca:  4881c480000000        add       rsp, 0x80
0x00014289e1d1:  5f                    pop       rdi
0x00014289e1d2:  c3                    ret       
0x00014289e1d3:  cc                    int3      
0x00014289e1d4:  cc                    int3      
0x00014289e1d5:  cc                    int3      
0x00014289e1d6:  cc                    int3      
0x00014289e1d7:  cc                    int3      
0x00014289e1d8:  cc                    int3      
0x00014289e1d9:  cc                    int3      
0x00014289e1da:  cc                    int3      
0x00014289e1db:  cc                    int3      
0x00014289e1dc:  cc                    int3      
0x00014289e1dd:  cc                    int3      
0x00014289e1de:  cc                    int3      
0x00014289e1df:  cc                    int3      
0x00014289e1e0:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014289e1e5:  57                    push      rdi
0x00014289e1e6:  4883ec20              sub       rsp, 0x20
0x00014289e1ea:  488bd9                mov       rbx, rcx
0x00014289e1ed:  0fb7fa                movzx     edi, dx
0x00014289e1f0:  0fb7ca                movzx     ecx, dx
0x00014289e1f3:  ff153f168a03          call      qword ptr [rip + 0x38a163f]
0x00014289e1f9:  66894366              mov       word ptr [rbx + 0x66], ax
0x00014289e1fd:  6689bb80000000        mov       word ptr [rbx + 0x80], di
0x00014289e204:  488b5c2430            mov       rbx, qword ptr [rsp + 0x30]
0x00014289e209:  4883c420              add       rsp, 0x20
0x00014289e20d:  5f                    pop       rdi
0x00014289e20e:  c3                    ret       
0x00014289e20f:  cc                    int3      
