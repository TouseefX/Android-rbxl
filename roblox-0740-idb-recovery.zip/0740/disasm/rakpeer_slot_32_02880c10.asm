; RakPeer vtable slot 32
; rva 0x2880c10
0x142880c10:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x142880c15:  48896c2420           mov       qword ptr [rsp + 0x20], rbp
0x142880c1a:  56                   push      rsi
0x142880c1b:  57                   push      rdi
0x142880c1c:  4156                 push      r14
0x142880c1e:  4883ec40             sub       rsp, 0x40
0x142880c22:  488bda               mov       rbx, rdx
0x142880c25:  4533f6               xor       r14d, r14d
0x142880c28:  0fb7151bec5605       movzx     edx, word ptr [rip + 0x556ec1b]
0x142880c2f:  488bf9               mov       rdi, rcx
0x142880c32:  66395312             cmp       word ptr [rbx + 0x12], dx
0x142880c36:  754a                 jne       0x142880c82
0x142880c38:  0fb74310             movzx     eax, word ptr [rbx + 0x10]
0x142880c3c:  0fb70d05ec5605       movzx     ecx, word ptr [rip + 0x556ec05]
0x142880c43:  663bc1               cmp       ax, cx
0x142880c46:  753a                 jne       0x142880c82
0x142880c48:  6683f802             cmp       ax, 2
0x142880c4c:  7510                 jne       0x142880c5e
0x142880c4e:  8b05f8eb5605         mov       eax, dword ptr [rip + 0x556ebf8]
0x142880c54:  394314               cmp       dword ptr [rbx + 0x14], eax
0x142880c57:  7529                 jne       0x142880c82
0x142880c59:  e9ff000000           jmp       0x142880d5d
0x142880c5e:  6683f817             cmp       ax, 0x17
0x142880c62:  751e                 jne       0x142880c82
0x142880c64:  488b4318             mov       rax, qword ptr [rbx + 0x18]
0x142880c68:  483b05e1eb5605       cmp       rax, qword ptr [rip + 0x556ebe1]
0x142880c6f:  7511                 jne       0x142880c82
0x142880c71:  488b4320             mov       rax, qword ptr [rbx + 0x20]
0x142880c75:  483b05dceb5605       cmp       rax, qword ptr [rip + 0x556ebdc]
0x142880c7c:  0f84db000000         je        0x142880d5d
0x142880c82:  488d8f50050000       lea       rcx, [rdi + 0x550]
0x142880c89:  418bf6               mov       esi, r14d
0x142880c8c:  e81f2b2a03           call      0x145b237b0
0x142880c91:  85c0                 test      eax, eax
0x142880c93:  0f8594020000         jne       0x142880f2d
0x142880c99:  448b8f40050000       mov       r9d, dword ptr [rdi + 0x540]
0x142880ca0:  458bd9               mov       r11d, r9d
0x142880ca3:  448b9744050000       mov       r10d, dword ptr [rdi + 0x544]
0x142880caa:  660f1f440000         nop       word ptr [rax + rax]
0x142880cb0:  453bca               cmp       r9d, r10d
0x142880cb3:  7708                 ja        0x142880cbd
0x142880cb5:  418bc2               mov       eax, r10d
0x142880cb8:  412bc1               sub       eax, r9d
0x142880cbb:  eb0c                 jmp       0x142880cc9
0x142880cbd:  8b8748050000         mov       eax, dword ptr [rdi + 0x548]
0x142880cc3:  412bc1               sub       eax, r9d
0x142880cc6:  4103c2               add       eax, r10d
0x142880cc9:  3bf0                 cmp       esi, eax
0x142880ccb:  7376                 jae       0x142880d43
0x142880ccd:  8b9748050000         mov       edx, dword ptr [rdi + 0x548]
0x142880cd3:  418bc9               mov       ecx, r9d
0x142880cd6:  4c8b8738050000       mov       r8, qword ptr [rdi + 0x538]
0x142880cdd:  2bca                 sub       ecx, edx
0x142880cdf:  03ce                 add       ecx, esi
0x142880ce1:  418bc3               mov       eax, r11d
0x142880ce4:  443bda               cmp       r11d, edx
0x142880ce7:  0f43c1               cmovae    eax, ecx
0x142880cea:  498b0cc0             mov       rcx, qword ptr [r8 + rax*8]
0x142880cee:  0fb74312             movzx     eax, word ptr [rbx + 0x12]
0x142880cf2:  66394102             cmp       word ptr [rcx + 2], ax
0x142880cf6:  7531                 jne       0x142880d29
0x142880cf8:  0fb701               movzx     eax, word ptr [rcx]
0x142880cfb:  663b4310             cmp       ax, word ptr [rbx + 0x10]
0x142880cff:  7528                 jne       0x142880d29
0x142880d01:  6683f802             cmp       ax, 2
0x142880d05:  7508                 jne       0x142880d0f
0x142880d07:  8b4314               mov       eax, dword ptr [rbx + 0x14]
0x142880d0a:  394104               cmp       dword ptr [rcx + 4], eax
0x142880d0d:  eb18                 jmp       0x142880d27
0x142880d0f:  6683f817             cmp       ax, 0x17
0x142880d13:  7514                 jne       0x142880d29
0x142880d15:  488b4108             mov       rax, qword ptr [rcx + 8]
0x142880d19:  483b4318             cmp       rax, qword ptr [rbx + 0x18]
0x142880d1d:  750a                 jne       0x142880d29
0x142880d1f:  488b4110             mov       rax, qword ptr [rcx + 0x10]
0x142880d23:  483b4320             cmp       rax, qword ptr [rbx + 0x20]
0x142880d27:  7407                 je        0x142880d30
0x142880d29:  ffc6                 inc       esi
0x142880d2b:  41ffc3               inc       r11d
0x142880d2e:  eb80                 jmp       0x142880cb0
0x142880d30:  488d8f50050000       lea       rcx, [rdi + 0x550]
0x142880d37:  e8d42a2a03           call      0x145b23810
0x142880d3c:  33c0                 xor       eax, eax
0x142880d3e:  e990010000           jmp       0x142880ed3
0x142880d43:  488d8f50050000       lea       rcx, [rdi + 0x550]
0x142880d4a:  e8c12a2a03           call      0x145b23810
0x142880d4f:  0fb715f4ea5605       movzx     edx, word ptr [rip + 0x556eaf4]
0x142880d56:  0fb70debea5605       movzx     ecx, word ptr [rip + 0x556eaeb]
0x142880d5d:  66395312             cmp       word ptr [rbx + 0x12], dx
0x142880d61:  751a                 jne       0x142880d7d
0x142880d63:  0fb74310             movzx     eax, word ptr [rbx + 0x10]
0x142880d67:  663bc1               cmp       ax, cx
0x142880d6a:  7511                 jne       0x142880d7d
0x142880d6c:  6683f802             cmp       ax, 2
0x142880d70:  755e                 jne       0x142880dd0
0x142880d72:  8b05d4ea5605         mov       eax, dword ptr [rip + 0x556ead4]
0x142880d78:  394314               cmp       dword ptr [rbx + 0x14], eax
0x142880d7b:  7473                 je        0x142880df0
0x142880d7d:  0f104310             movups    xmm0, xmmword ptr [rbx + 0x10]
0x142880d81:  4533c0               xor       r8d, r8d
0x142880d84:  488d542420           lea       rdx, [rsp + 0x20]
0x142880d89:  0f104b20             movups    xmm1, xmmword ptr [rbx + 0x20]
0x142880d8d:  488bcf               mov       rcx, rdi
0x142880d90:  0f29442420           movaps    xmmword ptr [rsp + 0x20], xmm0
0x142880d95:  0f294c2430           movaps    xmmword ptr [rsp + 0x30], xmm1
0x142880d9a:  e8f13c0000           call      0x142884a90
0x142880d9f:  83f8ff               cmp       eax, -1
0x142880da2:  0f8426010000         je        0x142880ece
0x142880da8:  4863c8               movsxd    rcx, eax
0x142880dab:  488b8750030000       mov       rax, qword ptr [rdi + 0x350]
0x142880db2:  4869d1d8160000       imul      rdx, rcx, 0x16d8
0x142880db9:  0fb60c02             movzx     ecx, byte ptr [rdx + rax]
0x142880dbd:  90                   nop       
0x142880dbe:  84c9                 test      cl, cl
0x142880dc0:  0f8520010000         jne       0x142880ee6
0x142880dc6:  b805000000           mov       eax, 5
0x142880dcb:  e903010000           jmp       0x142880ed3
0x142880dd0:  6683f817             cmp       ax, 0x17
0x142880dd4:  75a7                 jne       0x142880d7d
0x142880dd6:  488b4318             mov       rax, qword ptr [rbx + 0x18]
0x142880dda:  483b056fea5605       cmp       rax, qword ptr [rip + 0x556ea6f]
0x142880de1:  759a                 jne       0x142880d7d
0x142880de3:  488b4320             mov       rax, qword ptr [rbx + 0x20]
0x142880de7:  483b056aea5605       cmp       rax, qword ptr [rip + 0x556ea6a]
0x142880dee:  758d                 jne       0x142880d7d
0x142880df0:  0f1003               movups    xmm0, xmmword ptr [rbx]
0x142880df3:  66490f7ec1           movq      r9, xmm0
0x142880df8:  0f29442420           movaps    xmmword ptr [rsp + 0x20], xmm0
0x142880dfd:  4c3b0d64ea5605       cmp       r9, qword ptr [rip + 0x556ea64]
0x142880e04:  0f84c4000000         je        0x142880ece
0x142880e0a:  0fb7542428           movzx     edx, word ptr [rsp + 0x28]
0x142880e0f:  b8ffff0000           mov       eax, 0xffff
0x142880e14:  663bd0               cmp       dx, ax
0x142880e17:  7431                 je        0x142880e4a
0x142880e19:  663b9712010000       cmp       dx, word ptr [rdi + 0x112]
0x142880e20:  7328                 jae       0x142880e4a
0x142880e22:  488b8750030000       mov       rax, qword ptr [rdi + 0x350]
0x142880e29:  4869cad8160000       imul      rcx, rdx, 0x16d8
0x142880e30:  4c398c0130160000     cmp       qword ptr [rcx + rax + 0x1630], r9
0x142880e38:  7510                 jne       0x142880e4a
0x142880e3a:  0fb60401             movzx     eax, byte ptr [rcx + rax]
0x142880e3e:  90                   nop       
0x142880e3f:  84c0                 test      al, al
0x142880e41:  7407                 je        0x142880e4a
0x142880e43:  8bc2                 mov       eax, edx
0x142880e45:  e955ffffff           jmp       0x142880d9f
0x142880e4a:  0fb78f12010000       movzx     ecx, word ptr [rdi + 0x112]
0x142880e51:  418bc6               mov       eax, r14d
0x142880e54:  66443bf1             cmp       r14w, cx
0x142880e58:  7342                 jae       0x142880e9c
0x142880e5a:  660f1f440000         nop       word ptr [rax + rax]
0x142880e60:  8bc8                 mov       ecx, eax
0x142880e62:  4c69c1d8160000       imul      r8, rcx, 0x16d8
0x142880e69:  488b8f50030000       mov       rcx, qword ptr [rdi + 0x350]
0x142880e70:  410fb61408           movzx     edx, byte ptr [r8 + rcx]
0x142880e75:  90                   nop       
0x142880e76:  84d2                 test      dl, dl
0x142880e78:  7415                 je        0x142880e8f
0x142880e7a:  488b8f50030000       mov       rcx, qword ptr [rdi + 0x350]
0x142880e81:  4d398c0830160000     cmp       qword ptr [r8 + rcx + 0x1630], r9
0x142880e89:  0f8410ffffff         je        0x142880d9f
0x142880e8f:  0fb78f12010000       movzx     ecx, word ptr [rdi + 0x112]
0x142880e96:  ffc0                 inc       eax
0x142880e98:  3bc1                 cmp       eax, ecx
0x142880e9a:  72c4                 jb        0x142880e60
0x142880e9c:  440fb7c1             movzx     r8d, cx
0x142880ea0:  418bc6               mov       eax, r14d
0x142880ea3:  4585c0               test      r8d, r8d
0x142880ea6:  7426                 je        0x142880ece
0x142880ea8:  4c8b9750030000       mov       r10, qword ptr [rdi + 0x350]
0x142880eaf:  90                   nop       
0x142880eb0:  8bc8                 mov       ecx, eax
0x142880eb2:  4869d1d8160000       imul      rdx, rcx, 0x16d8
0x142880eb9:  4e398c1230160000     cmp       qword ptr [rdx + r10 + 0x1630], r9
0x142880ec1:  0f84d8feffff         je        0x142880d9f
0x142880ec7:  ffc0                 inc       eax
0x142880ec9:  413bc0               cmp       eax, r8d
0x142880ecc:  72e2                 jb        0x142880eb0
0x142880ece:  b806000000           mov       eax, 6
0x142880ed3:  488b5c2470           mov       rbx, qword ptr [rsp + 0x70]
0x142880ed8:  488b6c2478           mov       rbp, qword ptr [rsp + 0x78]
0x142880edd:  4883c440             add       rsp, 0x40
0x142880ee1:  415e                 pop       r14
0x142880ee3:  5f                   pop       rdi
0x142880ee4:  5e                   pop       rsi
0x142880ee5:  c3                   ret       
0x142880ee6:  488b8750030000       mov       rax, qword ptr [rdi + 0x350]
0x142880eed:  8b8c10d4160000       mov       ecx, dword ptr [rax + rdx + 0x16d4]
0x142880ef4:  ffc9                 dec       ecx
0x142880ef6:  83f906               cmp       ecx, 6
0x142880ef9:  77d3                 ja        0x142880ece
0x142880efb:  4863c1               movsxd    rax, ecx
0x142880efe:  488d15fbf077fd       lea       rdx, [rip - 0x2880f05]
0x142880f05:  8b8c82380f8802       mov       ecx, dword ptr [rdx + rax*4 + 0x2880f38]
0x142880f0c:  4803ca               add       rcx, rdx
0x142880f0f:  ffe1                 jmp       rcx
0x142880f11:  b804000000           mov       eax, 4
0x142880f16:  ebbb                 jmp       0x142880ed3
0x142880f18:  b803000000           mov       eax, 3
0x142880f1d:  ebb4                 jmp       0x142880ed3
0x142880f1f:  b801000000           mov       eax, 1
0x142880f24:  ebad                 jmp       0x142880ed3
0x142880f26:  b802000000           mov       eax, 2
0x142880f2b:  eba6                 jmp       0x142880ed3
0x142880f2d:  8bc8                 mov       ecx, eax
0x142880f2f:  e84c2e2a03           call      0x145b23d80
0x142880f34:  cc                   int3      
0x142880f35:  0f1f00               nop       dword ptr [rax]
0x142880f38:  180f                 sbb       byte ptr [rdi], cl
0x142880f3a:  8802                 mov       byte ptr [rdx], al
0x142880f3c:  110f                 adc       dword ptr [rdi], ecx
0x142880f3e:  8802                 mov       byte ptr [rdx], al
0x142880f40:  180f                 sbb       byte ptr [rdi], cl
0x142880f42:  8802                 mov       byte ptr [rdx], al
0x142880f44:  db 0x1f
0x142880f45:  0f88021f0f88         js        0xca972e4d
0x142880f4b:  021f                 add       bl, byte ptr [rdi]
0x142880f4d:  0f8802260f88         js        0xca973555
0x142880f53:  02cc                 add       cl, ah
0x142880f55:  cc                   int3      
0x142880f56:  cc                   int3      
0x142880f57:  cc                   int3      
0x142880f58:  cc                   int3      
0x142880f59:  cc                   int3      
0x142880f5a:  cc                   int3      
0x142880f5b:  cc                   int3      
0x142880f5c:  cc                   int3      
0x142880f5d:  cc                   int3      
0x142880f5e:  cc                   int3      
0x142880f5f:  cc                   int3      
0x142880f60:  4883ec48             sub       rsp, 0x48
0x142880f64:  0f1002               movups    xmm0, xmmword ptr [rdx]
0x142880f67:  4533c0               xor       r8d, r8d
0x142880f6a:  0f104a10             movups    xmm1, xmmword ptr [rdx + 0x10]
0x142880f6e:  488d542420           lea       rdx, [rsp + 0x20]
0x142880f73:  0f29442420           movaps    xmmword ptr [rsp + 0x20], xmm0
0x142880f78:  0f294c2430           movaps    xmmword ptr [rsp + 0x30], xmm1
0x142880f7d:  e80e3b0000           call      0x142884a90
0x142880f82:  4883c448             add       rsp, 0x48
0x142880f86:  c3                   ret       
0x142880f87:  cc                   int3      
0x142880f88:  cc                   int3      
0x142880f89:  cc                   int3      
0x142880f8a:  cc                   int3      
0x142880f8b:  cc                   int3      
0x142880f8c:  cc                   int3      
0x142880f8d:  cc                   int3      
0x142880f8e:  cc                   int3      
0x142880f8f:  cc                   int3      
