; Ipv6Tlv vtable slot 1 rva 0xe7d800
0x140e7d800:  b003                 mov       al, 3
0x140e7d802:  c3                   ret       
0x140e7d803:  cc                   int3      
0x140e7d804:  cc                   int3      
0x140e7d805:  cc                   int3      
0x140e7d806:  cc                   int3      
0x140e7d807:  cc                   int3      
0x140e7d808:  cc                   int3      
0x140e7d809:  cc                   int3      
0x140e7d80a:  cc                   int3      
0x140e7d80b:  cc                   int3      
0x140e7d80c:  cc                   int3      
0x140e7d80d:  cc                   int3      
0x140e7d80e:  cc                   int3      
0x140e7d80f:  cc                   int3      
0x140e7d810:  48895c2410           mov       qword ptr [rsp + 0x10], rbx
0x140e7d815:  57                   push      rdi
0x140e7d816:  4883ec40             sub       rsp, 0x40
0x140e7d81a:  488bf9               mov       rdi, rcx
0x140e7d81d:  488d5950             lea       rbx, [rcx + 0x50]
0x140e7d821:  c6442438ff           mov       byte ptr [rsp + 0x38], 0xff
0x140e7d826:  c644243000           mov       byte ptr [rsp + 0x30], 0
0x140e7d82b:  c644242803           mov       byte ptr [rsp + 0x28], 3
0x140e7d830:  48895c2420           mov       qword ptr [rsp + 0x20], rbx
0x140e7d835:  4d8bc8               mov       r9, r8
0x140e7d838:  4c8bc2               mov       r8, rdx
0x140e7d83b:  b209                 mov       dl, 9
0x140e7d83d:  e80eeec3ff           call      0x140abc650
0x140e7d842:  90                   nop       
0x140e7d843:  488d05d6b6d605       lea       rax, [rip + 0x5d6b6d6]
0x140e7d84a:  488907               mov       qword ptr [rdi], rax
0x140e7d84d:  b903000000           mov       ecx, 3
0x140e7d852:  488d4318             lea       rax, [rbx + 0x18]
0x140e7d856:  33d2                 xor       edx, edx
0x140e7d858:  0f1f840000000000     nop       dword ptr [rax + rax]
0x140e7d860:  488913               mov       qword ptr [rbx], rdx
0x140e7d863:  488950f0             mov       qword ptr [rax - 0x10], rdx
0x140e7d867:  488950f8             mov       qword ptr [rax - 8], rdx
0x140e7d86b:  488910               mov       qword ptr [rax], rdx
0x140e7d86e:  48895008             mov       qword ptr [rax + 8], rdx
0x140e7d872:  48895010             mov       qword ptr [rax + 0x10], rdx
0x140e7d876:  c740183333f33f       mov       dword ptr [rax + 0x18], 0x3ff33333
0x140e7d87d:  c7401c0000803f       mov       dword ptr [rax + 0x1c], 0x3f800000
0x140e7d884:  c740203333f33f       mov       dword ptr [rax + 0x20], 0x3ff33333
0x140e7d88b:  c740240000803f       mov       dword ptr [rax + 0x24], 0x3f800000
0x140e7d892:  488d5b40             lea       rbx, [rbx + 0x40]
0x140e7d896:  488d4040             lea       rax, [rax + 0x40]
0x140e7d89a:  4883e901             sub       rcx, 1
0x140e7d89e:  75c0                 jne       0x140e7d860
0x140e7d8a0:  48899710010000       mov       qword ptr [rdi + 0x110], rdx
0x140e7d8a7:  48899718010000       mov       qword ptr [rdi + 0x118], rdx
0x140e7d8ae:  48899720010000       mov       qword ptr [rdi + 0x120], rdx
0x140e7d8b5:  488bc7               mov       rax, rdi
0x140e7d8b8:  488b5c2458           mov       rbx, qword ptr [rsp + 0x58]
0x140e7d8bd:  4883c440             add       rsp, 0x40
0x140e7d8c1:  5f                   pop       rdi
0x140e7d8c2:  c3                   ret       
0x140e7d8c3:  cc                   int3      
0x140e7d8c4:  cc                   int3      
0x140e7d8c5:  cc                   int3      
0x140e7d8c6:  cc                   int3      
0x140e7d8c7:  cc                   int3      
0x140e7d8c8:  cc                   int3      
0x140e7d8c9:  cc                   int3      
0x140e7d8ca:  cc                   int3      
0x140e7d8cb:  cc                   int3      
0x140e7d8cc:  cc                   int3      
0x140e7d8cd:  cc                   int3      
0x140e7d8ce:  cc                   int3      
0x140e7d8cf:  cc                   int3      
0x140e7d8d0:  b812000000           mov       eax, 0x12
0x140e7d8d5:  c3                   ret       
0x140e7d8d6:  cc                   int3      
0x140e7d8d7:  cc                   int3      
0x140e7d8d8:  cc                   int3      
0x140e7d8d9:  cc                   int3      
0x140e7d8da:  cc                   int3      
0x140e7d8db:  cc                   int3      
0x140e7d8dc:  cc                   int3      
0x140e7d8dd:  cc                   int3      
0x140e7d8de:  cc                   int3      
0x140e7d8df:  cc                   int3      
0x140e7d8e0:  4883ec38             sub       rsp, 0x38
0x140e7d8e4:  660f2f0564c33406     comisd    xmm0, xmmword ptr [rip + 0x634c364]
0x140e7d8ec:  f20f100d8cb23406     movsd     xmm1, qword ptr [rip + 0x634b28c]
0x140e7d8f4:  0f297c2420           movaps    xmmword ptr [rsp + 0x20], xmm7
0x140e7d8f9:  0f28f8               movaps    xmm7, xmm0
0x140e7d8fc:  7206                 jb        0x140e7d904
0x140e7d8fe:  660f2fc8             comisd    xmm1, xmm0
0x140e7d902:  771d                 ja        0x140e7d921
0x140e7d904:  f20f58c1             addsd     xmm0, xmm1
0x140e7d908:  f20f5e0568b33406     divsd     xmm0, qword ptr [rip + 0x634b368]
0x140e7d910:  e8df16f604           call      0x145ddeff4
0x140e7d915:  f20f59055bb33406     mulsd     xmm0, qword ptr [rip + 0x634b35b]
0x140e7d91d:  f20f5cf8             subsd     xmm7, xmm0
0x140e7d921:  0f57c0               xorps     xmm0, xmm0
0x140e7d924:  f20f5ac7             cvtsd2ss  xmm0, xmm7
0x140e7d928:  0f287c2420           movaps    xmm7, xmmword ptr [rsp + 0x20]
0x140e7d92d:  4883c438             add       rsp, 0x38
0x140e7d931:  c3                   ret       
0x140e7d932:  cc                   int3      
0x140e7d933:  cc                   int3      
0x140e7d934:  cc                   int3      
0x140e7d935:  cc                   int3      
0x140e7d936:  cc                   int3      
0x140e7d937:  cc                   int3      
0x140e7d938:  cc                   int3      
0x140e7d939:  cc                   int3      
0x140e7d93a:  cc                   int3      
0x140e7d93b:  cc                   int3      
0x140e7d93c:  cc                   int3      
0x140e7d93d:  cc                   int3      
0x140e7d93e:  cc                   int3      
0x140e7d93f:  cc                   int3      
0x140e7d940:  4883ec38             sub       rsp, 0x38
0x140e7d944:  488b0d4de5b207       mov       rcx, qword ptr [rip + 0x7b2e54d]
0x140e7d94b:  4c8d05269b3907       lea       r8, [rip + 0x7399b26]
0x140e7d952:  41b902000000         mov       r9d, 2
0x140e7d958:  488d15f974fa05       lea       rdx, [rip + 0x5fa74f9]
0x140e7d95f:  e84cf2af03           call      0x14497cbb0
0x140e7d964:  4883c438             add       rsp, 0x38
0x140e7d968:  c3                   ret       
0x140e7d969:  cc                   int3      
0x140e7d96a:  cc                   int3      
0x140e7d96b:  cc                   int3      
0x140e7d96c:  cc                   int3      
0x140e7d96d:  cc                   int3      
0x140e7d96e:  cc                   int3      
0x140e7d96f:  cc                   int3      
0x140e7d970:  4883ec38             sub       rsp, 0x38
0x140e7d974:  488b0d1de5b207       mov       rcx, qword ptr [rip + 0x7b2e51d]
0x140e7d97b:  4c8d05569c3907       lea       r8, [rip + 0x7399c56]
0x140e7d982:  41b902000000         mov       r9d, 2
0x140e7d988:  488d15f174fa05       lea       rdx, [rip + 0x5fa74f1]
0x140e7d98f:  e81cf2af03           call      0x14497cbb0
0x140e7d994:  4883c438             add       rsp, 0x38
0x140e7d998:  c3                   ret       
0x140e7d999:  cc                   int3      
0x140e7d99a:  cc                   int3      
0x140e7d99b:  cc                   int3      
0x140e7d99c:  cc                   int3      
0x140e7d99d:  cc                   int3      
0x140e7d99e:  cc                   int3      
0x140e7d99f:  cc                   int3      
0x140e7d9a0:  4883ec38             sub       rsp, 0x38
0x140e7d9a4:  488b15050fec06       mov       rdx, qword ptr [rip + 0x6ec0f05]
0x140e7d9ab:  4c8d05f60eec06       lea       r8, [rip + 0x6ec0ef6]
0x140e7d9b2:  488b0ddfe4b207       mov       rcx, qword ptr [rip + 0x7b2e4df]
0x140e7d9b9:  41b902000000         mov       r9d, 2
0x140e7d9bf:  e87ce2af03           call      0x14497bc40
0x140e7d9c4:  4883c438             add       rsp, 0x38
0x140e7d9c8:  c3                   ret       
0x140e7d9c9:  cc                   int3      
0x140e7d9ca:  cc                   int3      
0x140e7d9cb:  cc                   int3      
0x140e7d9cc:  cc                   int3      
0x140e7d9cd:  cc                   int3      
0x140e7d9ce:  cc                   int3      
0x140e7d9cf:  cc                   int3      
0x140e7d9d0:  48894c2408           mov       qword ptr [rsp + 8], rcx
0x140e7d9d5:  53                   push      rbx
0x140e7d9d6:  55                   push      rbp
0x140e7d9d7:  56                   push      rsi
0x140e7d9d8:  57                   push      rdi
0x140e7d9d9:  4154                 push      r12
0x140e7d9db:  4155                 push      r13
0x140e7d9dd:  4156                 push      r14
0x140e7d9df:  4157                 push      r15
0x140e7d9e1:  4881eca8000000       sub       rsp, 0xa8
0x140e7d9e8:  488bfa               mov       rdi, rdx
0x140e7d9eb:  4c8bf1               mov       r14, rcx
0x140e7d9ee:  33db                 xor       ebx, ebx
0x140e7d9f0:  899c24f8000000       mov       dword ptr [rsp + 0xf8], ebx
0x140e7d9f7:  e8d4247900           call      0x14160fed0
0x140e7d9fc:  488d052db3d605       lea       rax, [rip + 0x5d6b32d]
0x140e7da03:  498906               mov       qword ptr [r14], rax
0x140e7da06:  488d05d3b2d605       lea       rax, [rip + 0x5d6b2d3]
0x140e7da0d:  49894610             mov       qword ptr [r14 + 0x10], rax
0x140e7da11:  41c78610010000ffffffff mov       dword ptr [r14 + 0x110], 0xffffffff
0x140e7da1c:  498db618010000       lea       rsi, [r14 + 0x118]
0x140e7da23:  4889b42400010000     mov       qword ptr [rsp + 0x100], rsi
0x140e7da2b:  4c8d2dae73fa05       lea       r13, [rip + 0x5fa73ae]
0x140e7da32:  4d8bc5               mov       r8, r13
0x140e7da35:  488bd7               mov       rdx, rdi
0x140e7da38:  488bce               mov       rcx, rsi
0x140e7da3b:  e8202dec00           call      0x141d40760
0x140e7da40:  90                   nop       
0x140e7da41:  488d05a0afd605       lea       rax, [rip + 0x5d6afa0]
0x140e7da48:  488906               mov       qword ptr [rsi], rax
0x140e7da4b:  e8005f0900           call      0x140f13950
0x140e7da50:  48894618             mov       qword ptr [rsi + 0x18], rax
0x140e7da54:  e8f75e0900           call      0x140f13950
0x140e7da59:  488bf8               mov       rdi, rax
0x140e7da5c:  e80fdeeb00           call      0x141d3b870
0x140e7da61:  4c8b00               mov       r8, qword ptr [rax]
0x140e7da64:  488b4808             mov       rcx, qword ptr [rax + 8]
0x140e7da68:  492bc8               sub       rcx, r8
0x140e7da6b:  48c1f904             sar       rcx, 4
0x140e7da6f:  0fb797b8010000       movzx     edx, word ptr [rdi + 0x1b8]
0x140e7da76:  483bd1               cmp       rdx, rcx
0x140e7da79:  7209                 jb        0x140e7da84
0x140e7da7b:  488d15ce63b507       lea       rdx, [rip + 0x7b563ce]
0x140e7da82:  eb07                 jmp       0x140e7da8b
0x140e7da84:  48c1e204             shl       rdx, 4
0x140e7da88:  4903d0               add       rdx, r8
0x140e7da8b:  b801000000           mov       eax, 1
0x140e7da90:  f00fc14208           lock xadd dword ptr [rdx + 8], eax
0x140e7da95:  49899ec0010000       mov       qword ptr [r14 + 0x1c0], rbx
0x140e7da9c:  49899ec8010000       mov       qword ptr [r14 + 0x1c8], rbx
0x140e7daa3:  49899ed0010000       mov       qword ptr [r14 + 0x1d0], rbx
0x140e7daaa:  49899ed8010000       mov       qword ptr [r14 + 0x1d8], rbx
0x140e7dab1:  49899ee0010000       mov       qword ptr [r14 + 0x1e0], rbx
0x140e7dab8:  49899ee8010000       mov       qword ptr [r14 + 0x1e8], rbx
0x140e7dabf:  49899ef0010000       mov       qword ptr [r14 + 0x1f0], rbx
0x140e7dac6:  49899ef8010000       mov       qword ptr [r14 + 0x1f8], rbx
0x140e7dacd:  49899e00020000       mov       qword ptr [r14 + 0x200], rbx
0x140e7dad4:  49c786080200000000803f mov       qword ptr [r14 + 0x208], 0x3f800000
0x140e7dadf:  49899e10020000       mov       qword ptr [r14 + 0x210], rbx
0x140e7dae6:  41899e18020000       mov       dword ptr [r14 + 0x218], ebx
0x140e7daed:  49c7861c0200000000803f mov       qword ptr [r14 + 0x21c], 0x3f800000
0x140e7daf8:  41c7862402000000008041 mov       dword ptr [r14 + 0x224], 0x41800000
0x140e7db03:  41c7862802000000000041 mov       dword ptr [r14 + 0x228], 0x41000000
0x140e7db0e:  bdffffffff           mov       ebp, 0xffffffff
0x140e7db13:  49c78638020000ffffffff mov       qword ptr [r14 + 0x238], 0xffffffffffffffff
0x140e7db1e:  49899e40020000       mov       qword ptr [r14 + 0x240], rbx
0x140e7db25:  41899e48020000       mov       dword ptr [r14 + 0x248], ebx
0x140e7db2c:  488d051db1d605       lea       rax, [rip + 0x5d6b11d]
0x140e7db33:  498906               mov       qword ptr [r14], rax
0x140e7db36:  488d055baed605       lea       rax, [rip + 0x5d6ae5b]
0x140e7db3d:  49894610             mov       qword ptr [r14 + 0x10], rax
0x140e7db41:  488d05e8abd605       lea       rax, [rip + 0x5d6abe8]
0x140e7db48:  488906               mov       qword ptr [rsi], rax
0x140e7db4b:  488d055eabd605       lea       rax, [rip + 0x5d6ab5e]
0x140e7db52:  498986b8010000       mov       qword ptr [r14 + 0x1b8], rax
0x140e7db59:  488d0500abd605       lea       rax, [rip + 0x5d6ab00]
0x140e7db60:  49898630020000       mov       qword ptr [r14 + 0x230], rax
0x140e7db67:  498d8e50020000       lea       rcx, [r14 + 0x250]
0x140e7db6e:  e85dfaffff           call      0x140e7d5d0
0x140e7db73:  90                   nop       
0x140e7db74:  498d8ef8040000       lea       rcx, [r14 + 0x4f8]
0x140e7db7b:  4533c0               xor       r8d, r8d
0x140e7db7e:  33d2                 xor       edx, edx
0x140e7db80:  e8bb7be603           call      0x144ce5740
0x140e7db85:  90                   nop       
0x140e7db86:  4533c0               xor       r8d, r8d
0x140e7db89:  33d2                 xor       edx, edx
0x140e7db8b:  498d8e68060000       lea       rcx, [r14 + 0x668]
0x140e7db92:  e889b7e603           call      0x144ce9320
0x140e7db97:  488d0522b2d605       lea       rax, [rip + 0x5d6b222]
0x140e7db9e:  49898668060000       mov       qword ptr [r14 + 0x668], rax
0x140e7dba5:  41899e28070000       mov       dword ptr [r14 + 0x728], ebx
0x140e7dbac:  49c7862c0700000000803f mov       qword ptr [r14 + 0x72c], 0x3f800000
0x140e7dbb7:  498d8e38070000       lea       rcx, [r14 + 0x738]
0x140e7dbbe:  4533c0               xor       r8d, r8d
0x140e7dbc1:  33d2                 xor       edx, edx
0x140e7dbc3:  e848fcffff           call      0x140e7d810
0x140e7dbc8:  90                   nop       
0x140e7dbc9:  498d8e60080000       lea       rcx, [r14 + 0x860]
0x140e7dbd0:  4533c0               xor       r8d, r8d
0x140e7dbd3:  33d2                 xor       edx, edx
0x140e7dbd5:  e84656e503           call      0x144cd3220
0x140e7dbda:  90                   nop       
0x140e7dbdb:  498d8e78090000       lea       rcx, [r14 + 0x978]
0x140e7dbe2:  4533c0               xor       r8d, r8d
0x140e7dbe5:  33d2                 xor       edx, edx
0x140e7dbe7:  e85449e603           call      0x144ce2540
0x140e7dbec:  90                   nop       
0x140e7dbed:  498d8ef80a0000       lea       rcx, [r14 + 0xaf8]
0x140e7dbf4:  4533c0               xor       r8d, r8d
0x140e7dbf7:  33d2                 xor       edx, edx
0x140e7dbf9:  e8f2def8ff           call      0x140e0baf0
0x140e7dbfe:  90                   nop       
0x140e7dbff:  498d8e200c0000       lea       rcx, [r14 + 0xc20]
0x140e7dc06:  4533c0               xor       r8d, r8d
0x140e7dc09:  33d2                 xor       edx, edx
0x140e7dc0b:  e860ebc3ff           call      0x140abc770
0x140e7dc10:  90                   nop       
0x140e7dc11:  4d8da6100e0000       lea       r12, [r14 + 0xe10]
0x140e7dc18:  49891c24             mov       qword ptr [r12], rbx
0x140e7dc1c:  488d4c2450           lea       rcx, [rsp + 0x50]
0x140e7dc21:  e88a490000           call      0x140e825b0
0x140e7dc26:  488b08               mov       rcx, qword ptr [rax]
0x140e7dc29:  488918               mov       qword ptr [rax], rbx
0x140e7dc2c:  49898e200e0000       mov       qword ptr [r14 + 0xe20], rcx
0x140e7dc33:  4533c9               xor       r9d, r9d
0x140e7dc36:  4d8bc6               mov       r8, r14
0x140e7dc39:  488bd6               mov       rdx, rsi
0x140e7dc3c:  498d8e280e0000       lea       rcx, [r14 + 0xe28]
0x140e7dc43:  e81868f9ff           call      0x140e14460
0x140e7dc48:  90                   nop       
0x140e7dc49:  49899eb80e0000       mov       qword ptr [r14 + 0xeb8], rbx
0x140e7dc50:  41899ec00e0000       mov       dword ptr [r14 + 0xec0], ebx
0x140e7dc57:  49899ec80e0000       mov       qword ptr [r14 + 0xec8], rbx
0x140e7dc5e:  49899ed00e0000       mov       qword ptr [r14 + 0xed0], rbx
0x140e7dc65:  41c786d800000012000000 mov       dword ptr [r14 + 0xd8], 0x12
0x140e7dc70:  4180a6dc000000fd     and       byte ptr [r14 + 0xdc], 0xfd
0x140e7dc78:  41808edc00000001     or        byte ptr [r14 + 0xdc], 1
0x140e7dc80:  b908010000           mov       ecx, 0x108
0x140e7dc85:  e8765bac03           call      0x144943800
0x140e7dc8a:  4885c0               test      rax, rax
0x140e7dc8d:  0f84ec030000         je        0x140e7e07f
0x140e7dc93:  48898424f8000000     mov       qword ptr [rsp + 0xf8], rax
0x140e7dc9b:  488bc8               mov       rcx, rax
0x140e7dc9e:  e88d347900           call      0x141611130
0x140e7dca3:  488bf8               mov       rdi, rax
0x140e7dca6:  c78424f800000001000000 mov       dword ptr [rsp + 0xf8], 1
0x140e7dcb1:  488d442458           lea       rax, [rsp + 0x58]
0x140e7dcb6:  4c3be0               cmp       r12, rax
0x140e7dcb9:  7470                 je        0x140e7dd2b
0x140e7dcbb:  498b3424             mov       rsi, qword ptr [r12]
0x140e7dcbf:  49893c24             mov       qword ptr [r12], rdi
0x140e7dcc3:  4885f6               test      rsi, rsi
0x140e7dcc6:  0f84c1000000         je        0x140e7dd8d
0x140e7dccc:  488d8eb0000000       lea       rcx, [rsi + 0xb0]
0x140e7dcd3:  e838470000           call      0x140e82410
0x140e7dcd8:  488b8ea8000000       mov       rcx, qword ptr [rsi + 0xa8]
0x140e7dcdf:  4885c9               test      rcx, rcx
0x140e7dce2:  7419                 je        0x140e7dcfd
0x140e7dce4:  8bc5                 mov       eax, ebp
0x140e7dce6:  f00fc1410c           lock xadd dword ptr [rcx + 0xc], eax
0x140e7dceb:  83f801               cmp       eax, 1
0x140e7dcee:  750d                 jne       0x140e7dcfd
0x140e7dcf0:  488b01               mov       rax, qword ptr [rcx]
0x140e7dcf3:  488b4008             mov       rax, qword ptr [rax + 8]
0x140e7dcf7:  ff153b202c05         call      qword ptr [rip + 0x52c203b]
0x140e7dcfd:  488b4e38             mov       rcx, qword ptr [rsi + 0x38]
0x140e7dd01:  4885c9               test      rcx, rcx
0x140e7dd04:  741a                 je        0x140e7dd20
0x140e7dd06:  8bc5                 mov       eax, ebp
0x140e7dd08:  f00fc1410c           lock xadd dword ptr [rcx + 0xc], eax
0x140e7dd0d:  83f801               cmp       eax, 1
0x140e7dd10:  750e                 jne       0x140e7dd20
0x140e7dd12:  488b01               mov       rax, qword ptr [rcx]
0x140e7dd15:  488b4008             mov       rax, qword ptr [rax + 8]
0x140e7dd19:  ff1519202c05         call      qword ptr [rip + 0x52c2019]
0x140e7dd1f:  90                   nop       
0x140e7dd20:  488bce               mov       rcx, rsi
0x140e7dd23:  e88853ac03           call      0x1449430b0
0x140e7dd28:  90                   nop       
0x140e7dd29:  eb62                 jmp       0x140e7dd8d
0x140e7dd2b:  4885ff               test      rdi, rdi
0x140e7dd2e:  745d                 je        0x140e7dd8d
0x140e7dd30:  488d8fb0000000       lea       rcx, [rdi + 0xb0]
0x140e7dd37:  e8d4460000           call      0x140e82410
0x140e7dd3c:  488b8fa8000000       mov       rcx, qword ptr [rdi + 0xa8]
0x140e7dd43:  4885c9               test      rcx, rcx
0x140e7dd46:  7419                 je        0x140e7dd61
0x140e7dd48:  8bc5                 mov       eax, ebp
0x140e7dd4a:  f00fc1410c           lock xadd dword ptr [rcx + 0xc], eax
0x140e7dd4f:  83f801               cmp       eax, 1
0x140e7dd52:  750d                 jne       0x140e7dd61
0x140e7dd54:  488b01               mov       rax, qword ptr [rcx]
0x140e7dd57:  488b4008             mov       rax, qword ptr [rax + 8]
0x140e7dd5b:  ff15d71f2c05         call      qword ptr [rip + 0x52c1fd7]
0x140e7dd61:  488b4f38             mov       rcx, qword ptr [rdi + 0x38]
0x140e7dd65:  4885c9               test      rcx, rcx
0x140e7dd68:  741a                 je        0x140e7dd84
0x140e7dd6a:  8bc5                 mov       eax, ebp
0x140e7dd6c:  f00fc1410c           lock xadd dword ptr [rcx + 0xc], eax
0x140e7dd71:  83f801               cmp       eax, 1
0x140e7dd74:  750e                 jne       0x140e7dd84
0x140e7dd76:  488b01               mov       rax, qword ptr [rcx]
0x140e7dd79:  488b4008             mov       rax, qword ptr [rax + 8]
0x140e7dd7d:  ff15b51f2c05         call      qword ptr [rip + 0x52c1fb5]
0x140e7dd83:  90                   nop       
0x140e7dd84:  488bcf               mov       rcx, rdi
0x140e7dd87:  e82453ac03           call      0x1449430b0
0x140e7dd8c:  90                   nop       
0x140e7dd8d:  498b86200e0000       mov       rax, qword ptr [r14 + 0xe20]
0x140e7dd94:  4885c0               test      rax, rax
0x140e7dd97:  7406                 je        0x140e7dd9f
0x140e7dd99:  488b4818             mov       rcx, qword ptr [rax + 0x18]
0x140e7dd9d:  eb03                 jmp       0x140e7dda2
0x140e7dd9f:  488bcb               mov       rcx, rbx
0x140e7dda2:  488d05c34ef805       lea       rax, [rip + 0x5f84ec3]
0x140e7dda9:  4889442430           mov       qword ptr [rsp + 0x30], rax
0x140e7ddae:  48c744243805000000   mov       qword ptr [rsp + 0x38], 5
0x140e7ddb7:  4c896c2440           mov       qword ptr [rsp + 0x40], r13
0x140e7ddbc:  48c744244811000000   mov       qword ptr [rsp + 0x48], 0x11
0x140e7ddc5:  0f28442430           movaps    xmm0, xmmword ptr [rsp + 0x30]
0x140e7ddca:  660f7f442460         movdqa    xmmword ptr [rsp + 0x60], xmm0
0x140e7ddd0:  0f284c2440           movaps    xmm1, xmmword ptr [rsp + 0x40]
0x140e7ddd5:  660f7f4c2470         movdqa    xmmword ptr [rsp + 0x70], xmm1
0x140e7dddb:  4c8d442460           lea       r8, [rsp + 0x60]
0x140e7dde0:  488d542470           lea       rdx, [rsp + 0x70]
0x140e7dde5:  e8d6777b00           call      0x1416355c0
0x140e7ddea:  6641c786180e00000101 mov       word ptr [r14 + 0xe18], 0x101
0x140e7ddf4:  448b0d11fc7407       mov       r9d, dword ptr [rip + 0x774fc11]
0x140e7ddfb:  4181f900040000       cmp       r9d, 0x400
0x140e7de02:  721a                 jb        0x140e7de1e
0x140e7de04:  803d88c3380700       cmp       byte ptr [rip + 0x738c388], 0
0x140e7de0b:  740d                 je        0x140e7de1a
0x140e7de0d:  803d3407750700       cmp       byte ptr [rip + 0x7750734], 0
0x140e7de14:  0f8547020000         jne       0x140e7e061
0x140e7de1a:  8bfb                 mov       edi, ebx
0x140e7de1c:  eb0c                 jmp       0x140e7de2a
0x140e7de1e:  e8ed84ad03           call      0x144956310
0x140e7de23:  8b7808               mov       edi, dword ptr [rax + 8]
0x140e7de26:  44894808             mov       dword ptr [rax + 8], r9d
0x140e7de2a:  89bc2400010000       mov       dword ptr [rsp + 0x100], edi
0x140e7de31:  498d8e280e0000       lea       rcx, [r14 + 0xe28]
0x140e7de38:  e8139aad03           call      0x144957850
0x140e7de3d:  b930000000           mov       ecx, 0x30
0x140e7de42:  e89995ad03           call      0x1449573e0
0x140e7de47:  488bf0               mov       rsi, rax
0x140e7de4a:  4889842408010000     mov       qword ptr [rsp + 0x108], rax
0x140e7de52:  4885c0               test      rax, rax
0x140e7de55:  7458                 je        0x140e7deaf
0x140e7de57:  8918                 mov       dword ptr [rax], ebx
0x140e7de59:  c7400401000000       mov       dword ptr [rax + 4], 1
0x140e7de60:  488d05e94a0000       lea       rax, [rip + 0x4ae9]
0x140e7de67:  48894608             mov       qword ptr [rsi + 8], rax
0x140e7de6b:  48895e10             mov       qword ptr [rsi + 0x10], rbx
0x140e7de6f:  48895e18             mov       qword ptr [rsi + 0x18], rbx
0x140e7de73:  498b86280e0000       mov       rax, qword ptr [r14 + 0xe28]
0x140e7de7a:  48894620             mov       qword ptr [rsi + 0x20], rax
0x140e7de7e:  4885c0               test      rax, rax
0x140e7de81:  7404                 je        0x140e7de87
0x140e7de83:  f0ff4004             lock inc  dword ptr [rax + 4]
0x140e7de87:  48836618fb           and       qword ptr [rsi + 0x18], 0xfffffffffffffffb
0x140e7de8c:  4c897628             mov       qword ptr [rsi + 0x28], r14
0x140e7de90:  488bd6               mov       rdx, rsi
0x140e7de93:  498b8e280e0000       mov       rcx, qword ptr [r14 + 0xe28]
0x140e7de9a:  e8418cad03           call      0x144956ae0
0x140e7de9f:  4889742420           mov       qword ptr [rsp + 0x20], rsi
0x140e7dea4:  4885f6               test      rsi, rsi
0x140e7dea7:  741c                 je        0x140e7dec5
0x140e7dea9:  f0ff4604             lock inc  dword ptr [rsi + 4]
0x140e7dead:  eb16                 jmp       0x140e7dec5
0x140e7deaf:  488bf3               mov       rsi, rbx
0x140e7deb2:  33d2                 xor       edx, edx
0x140e7deb4:  498b8e280e0000       mov       rcx, qword ptr [r14 + 0xe28]
0x140e7debb:  e8208cad03           call      0x144956ae0
0x140e7dec0:  48895c2420           mov       qword ptr [rsp + 0x20], rbx
0x140e7dec5:  c78424f800000003000000 mov       dword ptr [rsp + 0xf8], 3
0x140e7ded0:  81ff00040000         cmp       edi, 0x400
0x140e7ded6:  7218                 jb        0x140e7def0
0x140e7ded8:  803db4c2380700       cmp       byte ptr [rip + 0x738c2b4], 0
0x140e7dedf:  7417                 je        0x140e7def8
0x140e7dee1:  803d6006750700       cmp       byte ptr [rip + 0x7750660], 0
0x140e7dee8:  0f8582010000         jne       0x140e7e070
0x140e7deee:  eb08                 jmp       0x140e7def8
0x140e7def0:  e81b84ad03           call      0x144956310
0x140e7def5:  897808               mov       dword ptr [rax + 8], edi
0x140e7def8:  4885f6               test      rsi, rsi
0x140e7defb:  7415                 je        0x140e7df12
0x140e7defd:  8b06                 mov       eax, dword ptr [rsi]
0x140e7deff:  90                   nop       
0x140e7df00:  85c0                 test      eax, eax
0x140e7df02:  740e                 je        0x140e7df12
0x140e7df04:  8d4801               lea       ecx, [rax + 1]
0x140e7df07:  f00fb10e             lock cmpxchg dword ptr [rsi], ecx
0x140e7df0b:  75f3                 jne       0x140e7df00
0x140e7df0d:  488bfe               mov       rdi, rsi
0x140e7df10:  eb03                 jmp       0x140e7df15
0x140e7df12:  488bfb               mov       rdi, rbx
0x140e7df15:  498b96b80e0000       mov       rdx, qword ptr [r14 + 0xeb8]
0x140e7df1c:  4885d2               test      rdx, rdx
0x140e7df1f:  7447                 je        0x140e7df68
0x140e7df21:  8b02                 mov       eax, dword ptr [rdx]
0x140e7df23:  90                   nop       
0x140e7df24:  85c0                 test      eax, eax
0x140e7df26:  7440                 je        0x140e7df68
0x140e7df28:  8d4801               lea       ecx, [rax + 1]
0x140e7df2b:  f00fb10a             lock cmpxchg dword ptr [rdx], ecx
0x140e7df2f:  75f3                 jne       0x140e7df24
0x140e7df31:  4d8bbeb80e0000       mov       r15, qword ptr [r14 + 0xeb8]
0x140e7df38:  4d85ff               test      r15, r15
0x140e7df3b:  742e                 je        0x140e7df6b
0x140e7df3d:  8bc5                 mov       eax, ebp
0x140e7df3f:  f0410fc107           lock xadd dword ptr [r15], eax
0x140e7df44:  83f801               cmp       eax, 1
0x140e7df47:  7522                 jne       0x140e7df6b
0x140e7df49:  498bcf               mov       rcx, r15
0x140e7df4c:  e81f8aad03           call      0x144956970
0x140e7df51:  8bc5                 mov       eax, ebp
0x140e7df53:  f0410fc14704         lock xadd dword ptr [r15 + 4], eax
0x140e7df59:  83f801               cmp       eax, 1
0x140e7df5c:  750d                 jne       0x140e7df6b
0x140e7df5e:  498bcf               mov       rcx, r15
0x140e7df61:  e8fa96ad03           call      0x144957660
0x140e7df66:  eb03                 jmp       0x140e7df6b
0x140e7df68:  4c8bfb               mov       r15, rbx
0x140e7df6b:  4885ff               test      rdi, rdi
0x140e7df6e:  7427                 je        0x140e7df97
0x140e7df70:  8bc5                 mov       eax, ebp
0x140e7df72:  f00fc107             lock xadd dword ptr [rdi], eax
0x140e7df76:  83f801               cmp       eax, 1
0x140e7df79:  751c                 jne       0x140e7df97
0x140e7df7b:  488bcf               mov       rcx, rdi
0x140e7df7e:  e8ed89ad03           call      0x144956970
0x140e7df83:  8bc5                 mov       eax, ebp
0x140e7df85:  f00fc14704           lock xadd dword ptr [rdi + 4], eax
0x140e7df8a:  83f801               cmp       eax, 1
0x140e7df8d:  7508                 jne       0x140e7df97
0x140e7df8f:  488bcf               mov       rcx, rdi
0x140e7df92:  e8c996ad03           call      0x144957660
0x140e7df97:  4c3bff               cmp       r15, rdi
0x140e7df9a:  0f8492000000         je        0x140e7e032
0x140e7dfa0:  498b96b80e0000       mov       rdx, qword ptr [r14 + 0xeb8]
0x140e7dfa7:  4885d2               test      rdx, rdx
0x140e7dfaa:  7417                 je        0x140e7dfc3
0x140e7dfac:  8b02                 mov       eax, dword ptr [rdx]
0x140e7dfae:  90                   nop       
0x140e7dfaf:  85c0                 test      eax, eax
0x140e7dfb1:  7410                 je        0x140e7dfc3
0x140e7dfb3:  8d4801               lea       ecx, [rax + 1]
0x140e7dfb6:  f00fb10a             lock cmpxchg dword ptr [rdx], ecx
0x140e7dfba:  75f3                 jne       0x140e7dfaf
0x140e7dfbc:  498b9eb80e0000       mov       rbx, qword ptr [r14 + 0xeb8]
0x140e7dfc3:  488bfb               mov       rdi, rbx
0x140e7dfc6:  48895c2428           mov       qword ptr [rsp + 0x28], rbx
0x140e7dfcb:  4885db               test      rbx, rbx
0x140e7dfce:  7409                 je        0x140e7dfd9
0x140e7dfd0:  488bcb               mov       rcx, rbx
0x140e7dfd3:  e8b888ad03           call      0x144956890
0x140e7dfd8:  90                   nop       
0x140e7dfd9:  4885ff               test      rdi, rdi
0x140e7dfdc:  7427                 je        0x140e7e005
0x140e7dfde:  8bc5                 mov       eax, ebp
0x140e7dfe0:  f00fc107             lock xadd dword ptr [rdi], eax
0x140e7dfe4:  83f801               cmp       eax, 1
0x140e7dfe7:  751c                 jne       0x140e7e005
0x140e7dfe9:  488bcf               mov       rcx, rdi
0x140e7dfec:  e87f89ad03           call      0x144956970
0x140e7dff1:  8bc5                 mov       eax, ebp
0x140e7dff3:  f00fc14704           lock xadd dword ptr [rdi + 4], eax
0x140e7dff8:  83f801               cmp       eax, 1
0x140e7dffb:  7508                 jne       0x140e7e005
0x140e7dffd:  488bcf               mov       rcx, rdi
0x140e7e000:  e85b96ad03           call      0x144957660
0x140e7e005:  498b8eb80e0000       mov       rcx, qword ptr [r14 + 0xeb8]
0x140e7e00c:  4885c9               test      rcx, rcx
0x140e7e00f:  7411                 je        0x140e7e022
0x140e7e011:  8bc5                 mov       eax, ebp
0x140e7e013:  f00fc14104           lock xadd dword ptr [rcx + 4], eax
0x140e7e018:  83f801               cmp       eax, 1
0x140e7e01b:  7505                 jne       0x140e7e022
0x140e7e01d:  e83e96ad03           call      0x144957660
0x140e7e022:  4989b6b80e0000       mov       qword ptr [r14 + 0xeb8], rsi
0x140e7e029:  4885f6               test      rsi, rsi
0x140e7e02c:  7404                 je        0x140e7e032
0x140e7e02e:  f0ff4604             lock inc  dword ptr [rsi + 4]
0x140e7e032:  4885f6               test      rsi, rsi
0x140e7e035:  7413                 je        0x140e7e04a
0x140e7e037:  f00fc16e04           lock xadd dword ptr [rsi + 4], ebp
0x140e7e03c:  83fd01               cmp       ebp, 1
0x140e7e03f:  7509                 jne       0x140e7e04a
0x140e7e041:  488bce               mov       rcx, rsi
0x140e7e044:  e81796ad03           call      0x144957660
0x140e7e049:  90                   nop       
0x140e7e04a:  498bc6               mov       rax, r14
0x140e7e04d:  4881c4a8000000       add       rsp, 0xa8
0x140e7e054:  415f                 pop       r15
0x140e7e056:  415e                 pop       r14
0x140e7e058:  415d                 pop       r13
0x140e7e05a:  415c                 pop       r12
0x140e7e05c:  5f                   pop       rdi
0x140e7e05d:  5e                   pop       rsi
0x140e7e05e:  5d                   pop       rbp
0x140e7e05f:  5b                   pop       rbx
0x140e7e060:  c3                   ret       
0x140e7e061:  488d15786d2506       lea       rdx, [rip + 0x6256d78]
0x140e7e068:  33c9                 xor       ecx, ecx
0x140e7e06a:  e8110cae03           call      0x14495ec80
0x140e7e06f:  90                   nop       
0x140e7e070:  488d15696d2506       lea       rdx, [rip + 0x6256d69]
0x140e7e077:  33c9                 xor       ecx, ecx
0x140e7e079:  e8020cae03           call      0x14495ec80
0x140e7e07e:  90                   nop       
0x140e7e07f:  488d8c2480000000     lea       rcx, [rsp + 0x80]
0x140e7e087:  e864cd93ff           call      0x1407badf0
0x140e7e08c:  488d15ad8be806       lea       rdx, [rip + 0x6e88bad]
0x140e7e093:  488d8c2480000000     lea       rcx, [rsp + 0x80]
0x140e7e09b:  e8b04fcc04           call      0x145b43050
0x140e7e0a0:  cc                   int3      
0x140e7e0a1:  cc                   int3      
0x140e7e0a2:  cc                   int3      
0x140e7e0a3:  cc                   int3      
0x140e7e0a4:  cc                   int3      
0x140e7e0a5:  cc                   int3      
0x140e7e0a6:  cc                   int3      
0x140e7e0a7:  cc                   int3      
0x140e7e0a8:  cc                   int3      
0x140e7e0a9:  cc                   int3      
0x140e7e0aa:  cc                   int3      
0x140e7e0ab:  cc                   int3      
0x140e7e0ac:  cc                   int3      
0x140e7e0ad:  cc                   int3      
0x140e7e0ae:  cc                   int3      
0x140e7e0af:  cc                   int3      
0x140e7e0b0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x140e7e0b5:  57                   push      rdi
0x140e7e0b6:  4883ec20             sub       rsp, 0x20
0x140e7e0ba:  8bda                 mov       ebx, edx
0x140e7e0bc:  488bf9               mov       rdi, rcx
0x140e7e0bf:  e86c000000           call      0x140e7e130
0x140e7e0c4:  f6c301               test      bl, 1
0x140e7e0c7:  7409                 je        0x140e7e0d2
0x140e7e0c9:  488bcf               mov       rcx, rdi
0x140e7e0cc:  e8df4fac03           call      0x1449430b0
0x140e7e0d1:  90                   nop       
0x140e7e0d2:  488bc7               mov       rax, rdi
0x140e7e0d5:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x140e7e0da:  4883c420             add       rsp, 0x20
0x140e7e0de:  5f                   pop       rdi
0x140e7e0df:  c3                   ret       
