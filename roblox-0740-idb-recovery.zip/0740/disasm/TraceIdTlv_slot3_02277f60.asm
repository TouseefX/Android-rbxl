; TraceIdTlv vtable slot 3 rva 0x2277f60
0x142277f60:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x142277f65:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x142277f6a:  57                   push      rdi
0x142277f6b:  4883ec20             sub       rsp, 0x20
0x142277f6f:  488b01               mov       rax, qword ptr [rcx]
0x142277f72:  498bf0               mov       rsi, r8
0x142277f75:  488bda               mov       rbx, rdx
0x142277f78:  488bf9               mov       rdi, rcx
0x142277f7b:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x142277f7f:  ff15b37dec03         call      qword ptr [rip + 0x3ec7db3]
0x142277f85:  0fb6c0               movzx     eax, al
0x142277f88:  483b4608             cmp       rax, qword ptr [rsi + 8]
0x142277f8c:  7621                 jbe       0x142277faf
0x142277f8e:  c7030b000000         mov       dword ptr [rbx], 0xb
0x142277f94:  488bc3               mov       rax, rbx
0x142277f97:  48c7430800000000     mov       qword ptr [rbx + 8], 0
0x142277f9f:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142277fa4:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142277fa9:  4883c420             add       rsp, 0x20
0x142277fad:  5f                   pop       rdi
0x142277fae:  c3                   ret       
0x142277faf:  488b06               mov       rax, qword ptr [rsi]
0x142277fb2:  488bcf               mov       rcx, rdi
0x142277fb5:  0f104708             movups    xmm0, xmmword ptr [rdi + 8]
0x142277fb9:  c70300000000         mov       dword ptr [rbx], 0
0x142277fbf:  0f1100               movups    xmmword ptr [rax], xmm0
0x142277fc2:  488b07               mov       rax, qword ptr [rdi]
0x142277fc5:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x142277fc9:  ff15697dec03         call      qword ptr [rip + 0x3ec7d69]
0x142277fcf:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142277fd4:  0fb6c0               movzx     eax, al
0x142277fd7:  48894308             mov       qword ptr [rbx + 8], rax
0x142277fdb:  488bc3               mov       rax, rbx
0x142277fde:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142277fe3:  4883c420             add       rsp, 0x20
0x142277fe7:  5f                   pop       rdi
0x142277fe8:  c3                   ret       
0x142277fe9:  cc                   int3      
0x142277fea:  cc                   int3      
0x142277feb:  cc                   int3      
0x142277fec:  cc                   int3      
0x142277fed:  cc                   int3      
0x142277fee:  cc                   int3      
0x142277fef:  cc                   int3      
0x142277ff0:  4883ec38             sub       rsp, 0x38
0x142277ff4:  488b0d9d3e7306       mov       rcx, qword ptr [rip + 0x6733e9d]
0x142277ffb:  4c8d05ee7fae05       lea       r8, [rip + 0x5ae7fee]
0x142278002:  41b901000000         mov       r9d, 1
0x142278008:  488d155930c904       lea       rdx, [rip + 0x4c93059]
0x14227800f:  e8fc367002           call      0x14497b710
0x142278014:  4883c438             add       rsp, 0x38
0x142278018:  c3                   ret       
0x142278019:  cc                   int3      
0x14227801a:  cc                   int3      
0x14227801b:  cc                   int3      
0x14227801c:  cc                   int3      
0x14227801d:  cc                   int3      
0x14227801e:  cc                   int3      
0x14227801f:  cc                   int3      
0x142278020:  4883ec38             sub       rsp, 0x38
0x142278024:  488b0d6d3e7306       mov       rcx, qword ptr [rip + 0x6733e6d]
0x14227802b:  4c8d05fe7fae05       lea       r8, [rip + 0x5ae7ffe]
0x142278032:  41b902000000         mov       r9d, 2
0x142278038:  488d153930c904       lea       rdx, [rip + 0x4c93039]
0x14227803f:  e89c317002           call      0x14497b1e0
0x142278044:  4883c438             add       rsp, 0x38
0x142278048:  c3                   ret       
0x142278049:  cc                   int3      
0x14227804a:  cc                   int3      
0x14227804b:  cc                   int3      
0x14227804c:  cc                   int3      
0x14227804d:  cc                   int3      
0x14227804e:  cc                   int3      
0x14227804f:  cc                   int3      
