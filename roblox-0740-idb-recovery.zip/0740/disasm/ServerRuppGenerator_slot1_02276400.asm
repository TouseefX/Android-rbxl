; ServerRuppGenerator vtable slot 1 rva 0x2276400
0x142276400:  4881c190000000       add       rcx, 0x90
0x142276407:  80791c00             cmp       byte ptr [rcx + 0x1c], 0
0x14227640b:  741c                 je        0x142276429
0x14227640d:  483bca               cmp       rcx, rdx
0x142276410:  7436                 je        0x142276448
0x142276412:  0f1002               movups    xmm0, xmmword ptr [rdx]
0x142276415:  0f1101               movups    xmmword ptr [rcx], xmm0
0x142276418:  f20f104a10           movsd     xmm1, qword ptr [rdx + 0x10]
0x14227641d:  f20f114910           movsd     qword ptr [rcx + 0x10], xmm1
0x142276422:  8b4218               mov       eax, dword ptr [rdx + 0x18]
0x142276425:  894118               mov       dword ptr [rcx + 0x18], eax
0x142276428:  c3                   ret       
0x142276429:  483bca               cmp       rcx, rdx
0x14227642c:  7416                 je        0x142276444
0x14227642e:  0f1002               movups    xmm0, xmmword ptr [rdx]
0x142276431:  0f1101               movups    xmmword ptr [rcx], xmm0
0x142276434:  f20f104a10           movsd     xmm1, qword ptr [rdx + 0x10]
0x142276439:  f20f114910           movsd     qword ptr [rcx + 0x10], xmm1
0x14227643e:  8b4218               mov       eax, dword ptr [rdx + 0x18]
0x142276441:  894118               mov       dword ptr [rcx + 0x18], eax
0x142276444:  c6411c01             mov       byte ptr [rcx + 0x1c], 1
0x142276448:  c3                   ret       
0x142276449:  cc                   int3      
0x14227644a:  cc                   int3      
0x14227644b:  cc                   int3      
0x14227644c:  cc                   int3      
0x14227644d:  cc                   int3      
0x14227644e:  cc                   int3      
0x14227644f:  cc                   int3      
0x142276450:  488d81b8000000       lea       rax, [rcx + 0xb8]
0x142276457:  c3                   ret       
0x142276458:  cc                   int3      
0x142276459:  cc                   int3      
0x14227645a:  cc                   int3      
0x14227645b:  cc                   int3      
0x14227645c:  cc                   int3      
0x14227645d:  cc                   int3      
0x14227645e:  cc                   int3      
0x14227645f:  cc                   int3      
0x142276460:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x142276465:  55                   push      rbp
0x142276466:  56                   push      rsi
0x142276467:  57                   push      rdi
0x142276468:  4883ec70             sub       rsp, 0x70
0x14227646c:  488b057dd2a905       mov       rax, qword ptr [rip + 0x5a9d27d]
0x142276473:  4833c4               xor       rax, rsp
0x142276476:  4889442460           mov       qword ptr [rsp + 0x60], rax
0x14227647b:  488bea               mov       rbp, rdx
0x14227647e:  488bd9               mov       rbx, rcx
0x142276481:  4883b97801000000     cmp       qword ptr [rcx + 0x178], 0
0x142276489:  750a                 jne       0x142276495
0x14227648b:  b80c000000           mov       eax, 0xc
0x142276490:  e919010000           jmp       0x1422765ae
0x142276495:  4881c180010000       add       rcx, 0x180
0x14227649c:  493bc8               cmp       rcx, r8
0x14227649f:  7419                 je        0x1422764ba
0x1422764a1:  410f1000             movups    xmm0, xmmword ptr [r8]
0x1422764a5:  0f1101               movups    xmmword ptr [rcx], xmm0
0x1422764a8:  f2410f104810         movsd     xmm1, qword ptr [r8 + 0x10]
0x1422764ae:  f20f114910           movsd     qword ptr [rcx + 0x10], xmm1
0x1422764b3:  418b4018             mov       eax, dword ptr [r8 + 0x18]
0x1422764b7:  894118               mov       dword ptr [rcx + 0x18], eax
0x1422764ba:  488d542420           lea       rdx, [rsp + 0x20]
0x1422764bf:  e81c2bf3ff           call      0x1421a8fe0
0x1422764c4:  488bf8               mov       rdi, rax
0x1422764c7:  488db3a0010000       lea       rsi, [rbx + 0x1a0]
0x1422764ce:  483bf0               cmp       rsi, rax
0x1422764d1:  7429                 je        0x1422764fc
0x1422764d3:  488bce               mov       rcx, rsi
0x1422764d6:  e805f556fe           call      0x1407e59e0
0x1422764db:  0f1007               movups    xmm0, xmmword ptr [rdi]
0x1422764de:  0f1106               movups    xmmword ptr [rsi], xmm0
0x1422764e1:  0f104f10             movups    xmm1, xmmword ptr [rdi + 0x10]
0x1422764e5:  0f114e10             movups    xmmword ptr [rsi + 0x10], xmm1
0x1422764e9:  48c7471000000000     mov       qword ptr [rdi + 0x10], 0
0x1422764f1:  48c747180f000000     mov       qword ptr [rdi + 0x18], 0xf
0x1422764f9:  c60700               mov       byte ptr [rdi], 0
0x1422764fc:  488b442438           mov       rax, qword ptr [rsp + 0x38]
0x142276501:  4883f810             cmp       rax, 0x10
0x142276505:  722e                 jb        0x142276535
0x142276507:  48ffc0               inc       rax
0x14227650a:  488b4c2420           mov       rcx, qword ptr [rsp + 0x20]
0x14227650f:  488bd1               mov       rdx, rcx
0x142276512:  483d00100000         cmp       rax, 0x1000
0x142276518:  7215                 jb        0x14227652f
0x14227651a:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x14227651e:  482bd1               sub       rdx, rcx
0x142276521:  488d42f8             lea       rax, [rdx - 8]
0x142276525:  4883f81f             cmp       rax, 0x1f
0x142276529:  0f879c000000         ja        0x1422765cb
0x14227652f:  e87ccb6c02           call      0x1449430b0
0x142276534:  90                   nop       
0x142276535:  488d055423a204       lea       rax, [rip + 0x4a22354]
0x14227653c:  4889442420           mov       qword ptr [rsp + 0x20], rax
0x142276541:  48895c2428           mov       qword ptr [rsp + 0x28], rbx
0x142276546:  488d442420           lea       rax, [rsp + 0x20]
0x14227654b:  4889442458           mov       qword ptr [rsp + 0x58], rax
0x142276550:  488d542420           lea       rdx, [rsp + 0x20]
0x142276555:  488d8bb8000000       lea       rcx, [rbx + 0xb8]
0x14227655c:  e88ff4ffff           call      0x1422759f0
0x142276561:  0f104508             movups    xmm0, xmmword ptr [rbp + 8]
0x142276565:  0f29442420           movaps    xmmword ptr [rsp + 0x20], xmm0
0x14227656a:  488d542420           lea       rdx, [rsp + 0x20]
0x14227656f:  488bcb               mov       rcx, rbx
0x142276572:  e879070000           call      0x142276cf0
0x142276577:  8983b0000000         mov       dword ptr [rbx + 0xb0], eax
0x14227657d:  f6450301             test      byte ptr [rbp + 3], 1
0x142276581:  7419                 je        0x14227659c
0x142276583:  488d5518             lea       rdx, [rbp + 0x18]
0x142276587:  440fb74546           movzx     r8d, word ptr [rbp + 0x46]
0x14227658c:  488d8bb8000000       lea       rcx, [rbx + 0xb8]
0x142276593:  e898f5ffff           call      0x142275b30
0x142276598:  85c0                 test      eax, eax
0x14227659a:  7512                 jne       0x1422765ae
0x14227659c:  803d557e030600       cmp       byte ptr [rip + 0x6037e55], 0
0x1422765a3:  7507                 jne       0x1422765ac
0x1422765a5:  c6837001000009       mov       byte ptr [rbx + 0x170], 9
0x1422765ac:  33c0                 xor       eax, eax
0x1422765ae:  488b4c2460           mov       rcx, qword ptr [rsp + 0x60]
0x1422765b3:  4833cc               xor       rcx, rsp
0x1422765b6:  e825b08a03           call      0x145b215e0
0x1422765bb:  488b9c24a0000000     mov       rbx, qword ptr [rsp + 0xa0]
0x1422765c3:  4883c470             add       rsp, 0x70
0x1422765c7:  5f                   pop       rdi
0x1422765c8:  5e                   pop       rsi
0x1422765c9:  5d                   pop       rbp
0x1422765ca:  c3                   ret       
0x1422765cb:  e850af8d03           call      0x145b51520
0x1422765d0:  cc                   int3      
0x1422765d1:  cc                   int3      
0x1422765d2:  cc                   int3      
0x1422765d3:  cc                   int3      
0x1422765d4:  cc                   int3      
0x1422765d5:  cc                   int3      
0x1422765d6:  cc                   int3      
0x1422765d7:  cc                   int3      
0x1422765d8:  cc                   int3      
0x1422765d9:  cc                   int3      
0x1422765da:  cc                   int3      
0x1422765db:  cc                   int3      
0x1422765dc:  cc                   int3      
0x1422765dd:  cc                   int3      
0x1422765de:  cc                   int3      
0x1422765df:  cc                   int3      
0x1422765e0:  48895c2420           mov       qword ptr [rsp + 0x20], rbx
0x1422765e5:  55                   push      rbp
0x1422765e6:  56                   push      rsi
0x1422765e7:  57                   push      rdi
0x1422765e8:  4154                 push      r12
0x1422765ea:  4155                 push      r13
0x1422765ec:  4156                 push      r14
0x1422765ee:  4157                 push      r15
0x1422765f0:  488d6c2490           lea       rbp, [rsp - 0x70]
0x1422765f5:  4881ec70010000       sub       rsp, 0x170
0x1422765fc:  488b05edd0a905       mov       rax, qword ptr [rip + 0x5a9d0ed]
0x142276603:  4833c4               xor       rax, rsp
0x142276606:  48894560             mov       qword ptr [rbp + 0x60], rax
0x14227660a:  4d8bf8               mov       r15, r8
0x14227660d:  4c8be2               mov       r12, rdx
0x142276610:  488bf1               mov       rsi, rcx
0x142276613:  4889542430           mov       qword ptr [rsp + 0x30], rdx
0x142276618:  66c745a00400         mov       word ptr [rbp - 0x60], 4
0x14227661e:  4533ed               xor       r13d, r13d
0x142276621:  4c896de0             mov       qword ptr [rbp - 0x20], r13
0x142276625:  44896de8             mov       dword ptr [rbp - 0x18], r13d
0x142276629:  4c896df0             mov       qword ptr [rbp - 0x10], r13
0x14227662d:  4c896df8             mov       qword ptr [rbp - 8], r13
0x142276631:  0f57c0               xorps     xmm0, xmm0
0x142276634:  660f7f4500           movdqa    xmmword ptr [rbp], xmm0
0x142276639:  4c896d10             mov       qword ptr [rbp + 0x10], r13
0x14227663d:  488d4530             lea       rax, [rbp + 0x30]
0x142276641:  48894518             mov       qword ptr [rbp + 0x18], rax
0x142276645:  4c896d20             mov       qword ptr [rbp + 0x20], r13
0x142276649:  48c7452820000000     mov       qword ptr [rbp + 0x28], 0x20
0x142276651:  c74550ffffffff       mov       dword ptr [rbp + 0x50], 0xffffffff
0x142276658:  44886d54             mov       byte ptr [rbp + 0x54], r13b
0x14227665c:  33c0                 xor       eax, eax
0x14227665e:  0f11442460           movups    xmmword ptr [rsp + 0x60], xmm0
0x142276663:  88442470             mov       byte ptr [rsp + 0x70], al
0x142276667:  48398178010000       cmp       qword ptr [rcx + 0x178], rax
0x14227666e:  0f85a6010000         jne       0x14227681a
0x142276674:  8d4820               lea       ecx, [rax + 0x20]
0x142276677:  e884d16c02           call      0x144943800
0x14227667c:  488bc8               mov       rcx, rax
0x14227667f:  4885c0               test      rax, rax
0x142276682:  0f849b040000         je        0x142276b23
0x142276688:  0f10442460           movups    xmm0, xmmword ptr [rsp + 0x60]
0x14227668d:  0fb6442470           movzx     eax, byte ptr [rsp + 0x70]
0x142276692:  488d155722a204       lea       rdx, [rip + 0x4a22257]
0x142276699:  488911               mov       qword ptr [rcx], rdx
0x14227669c:  0f114108             movups    xmmword ptr [rcx + 8], xmm0
0x1422766a0:  884118               mov       byte ptr [rcx + 0x18], al
0x1422766a3:  48894c2430           mov       qword ptr [rsp + 0x30], rcx
0x1422766a8:  488d542430           lea       rdx, [rsp + 0x30]
0x1422766ad:  488d4da0             lea       rcx, [rbp - 0x60]
0x1422766b1:  e81aecffff           call      0x1422752d0
0x1422766b6:  41f6470301           test      byte ptr [r15 + 3], 1
0x1422766bb:  7412                 je        0x1422766cf
0x1422766bd:  498d5718             lea       rdx, [r15 + 0x18]
0x1422766c1:  450fb74746           movzx     r8d, word ptr [r15 + 0x46]
0x1422766c6:  488d4da0             lea       rcx, [rbp - 0x60]
0x1422766ca:  e861f4ffff           call      0x142275b30
0x1422766cf:  0f57c0               xorps     xmm0, xmm0
0x1422766d2:  0f11442450           movups    xmmword ptr [rsp + 0x50], xmm0
0x1422766d7:  488b9dd0000000       mov       rbx, qword ptr [rbp + 0xd0]
0x1422766de:  66480f7ec0           movq      rax, xmm0
0x1422766e3:  483903               cmp       qword ptr [rbx], rax
0x1422766e6:  750b                 jne       0x1422766f3
0x1422766e8:  488b4308             mov       rax, qword ptr [rbx + 8]
0x1422766ec:  483b442458           cmp       rax, qword ptr [rsp + 0x58]
0x1422766f1:  743d                 je        0x142276730
0x1422766f3:  b918000000           mov       ecx, 0x18
0x1422766f8:  e803d16c02           call      0x144943800
0x1422766fd:  4885c0               test      rax, rax
0x142276700:  0f8401040000         je        0x142276b07
0x142276706:  488d0d0b22a204       lea       rcx, [rip + 0x4a2220b]
0x14227670d:  488908               mov       qword ptr [rax], rcx
0x142276710:  0f1003               movups    xmm0, xmmword ptr [rbx]
0x142276713:  0f114008             movups    xmmword ptr [rax + 8], xmm0
0x142276717:  4c896c2450           mov       qword ptr [rsp + 0x50], r13
0x14227671c:  4889442430           mov       qword ptr [rsp + 0x30], rax
0x142276721:  488d542430           lea       rdx, [rsp + 0x30]
0x142276726:  488d4da0             lea       rcx, [rbp - 0x60]
0x14227672a:  e8a1ebffff           call      0x1422752d0
0x14227672f:  90                   nop       
0x142276730:  488d55a0             lea       rdx, [rbp - 0x60]
0x142276734:  498bcc               mov       rcx, r12
0x142276737:  e884c0ffff           call      0x1422727c0
0x14227673c:  90                   nop       
0x14227673d:  488d4530             lea       rax, [rbp + 0x30]
0x142276741:  488b4d18             mov       rcx, qword ptr [rbp + 0x18]
0x142276745:  483bc8               cmp       rcx, rax
0x142276748:  7406                 je        0x142276750
0x14227674a:  e861c96c02           call      0x1449430b0
0x14227674f:  90                   nop       
0x142276750:  488b5d00             mov       rbx, qword ptr [rbp]
0x142276754:  4885db               test      rbx, rbx
0x142276757:  7477                 je        0x1422767d0
0x142276759:  488b7d08             mov       rdi, qword ptr [rbp + 8]
0x14227675d:  483bdf               cmp       rbx, rdi
0x142276760:  7426                 je        0x142276788
0x142276762:  488b0b               mov       rcx, qword ptr [rbx]
0x142276765:  4885c9               test      rcx, rcx
0x142276768:  7411                 je        0x14227677b
0x14227676a:  488b01               mov       rax, qword ptr [rcx]
0x14227676d:  ba01000000           mov       edx, 1
0x142276772:  488b00               mov       rax, qword ptr [rax]
0x142276775:  ff15bd95ec03         call      qword ptr [rip + 0x3ec95bd]
0x14227677b:  4883c308             add       rbx, 8
0x14227677f:  483bdf               cmp       rbx, rdi
0x142276782:  75de                 jne       0x142276762
0x142276784:  488b5d00             mov       rbx, qword ptr [rbp]
0x142276788:  488b4510             mov       rax, qword ptr [rbp + 0x10]
0x14227678c:  482bc3               sub       rax, rbx
0x14227678f:  48c1f803             sar       rax, 3
0x142276793:  488d04c500000000     lea       rax, [rax*8]
0x14227679b:  488bcb               mov       rcx, rbx
0x14227679e:  483d00100000         cmp       rax, 0x1000
0x1422767a4:  7215                 jb        0x1422767bb
0x1422767a6:  488b5bf8             mov       rbx, qword ptr [rbx - 8]
0x1422767aa:  482bcb               sub       rcx, rbx
0x1422767ad:  488d41f8             lea       rax, [rcx - 8]
0x1422767b1:  4883f81f             cmp       rax, 0x1f
0x1422767b5:  0f878a030000         ja        0x142276b45
0x1422767bb:  488bcb               mov       rcx, rbx
0x1422767be:  e8edc86c02           call      0x1449430b0
0x1422767c3:  90                   nop       
0x1422767c4:  0f57c0               xorps     xmm0, xmm0
0x1422767c7:  660f7f4500           movdqa    xmmword ptr [rbp], xmm0
0x1422767cc:  4c896d10             mov       qword ptr [rbp + 0x10], r13
0x1422767d0:  488b4de0             mov       rcx, qword ptr [rbp - 0x20]
0x1422767d4:  4885c9               test      rcx, rcx
0x1422767d7:  7417                 je        0x1422767f0
0x1422767d9:  488b01               mov       rax, qword ptr [rcx]
0x1422767dc:  488d55a8             lea       rdx, [rbp - 0x58]
0x1422767e0:  483bca               cmp       rcx, rdx
0x1422767e3:  0f95c2               setne     dl
0x1422767e6:  488b4020             mov       rax, qword ptr [rax + 0x20]
0x1422767ea:  ff154895ec03         call      qword ptr [rip + 0x3ec9548]
0x1422767f0:  498bc4               mov       rax, r12
0x1422767f3:  488b4d60             mov       rcx, qword ptr [rbp + 0x60]
0x1422767f7:  4833cc               xor       rcx, rsp
0x1422767fa:  e8e1ad8a03           call      0x145b215e0
0x1422767ff:  488b9c24c8010000     mov       rbx, qword ptr [rsp + 0x1c8]
0x142276807:  4881c470010000       add       rsp, 0x170
0x14227680e:  415f                 pop       r15
0x142276810:  415e                 pop       r14
0x142276812:  415d                 pop       r13
0x142276814:  415c                 pop       r12
0x142276816:  5f                   pop       rdi
0x142276817:  5e                   pop       rsi
0x142276818:  5d                   pop       rbp
0x142276819:  c3                   ret       
0x14227681a:  488d9980010000       lea       rbx, [rcx + 0x180]
0x142276821:  493bd9               cmp       rbx, r9
0x142276824:  7419                 je        0x14227683f
0x142276826:  410f1001             movups    xmm0, xmmword ptr [r9]
0x14227682a:  0f1103               movups    xmmword ptr [rbx], xmm0
0x14227682d:  f2410f104910         movsd     xmm1, qword ptr [r9 + 0x10]
0x142276833:  f20f114b10           movsd     qword ptr [rbx + 0x10], xmm1
0x142276838:  418b4118             mov       eax, dword ptr [r9 + 0x18]
0x14227683c:  894318               mov       dword ptr [rbx + 0x18], eax
0x14227683f:  488d542478           lea       rdx, [rsp + 0x78]
0x142276844:  488bcb               mov       rcx, rbx
0x142276847:  e89427f3ff           call      0x1421a8fe0
0x14227684c:  4c8bf0               mov       r14, rax
0x14227684f:  488dbea0010000       lea       rdi, [rsi + 0x1a0]
0x142276856:  483bf8               cmp       rdi, rax
0x142276859:  7428                 je        0x142276883
0x14227685b:  488bcf               mov       rcx, rdi
0x14227685e:  e87df156fe           call      0x1407e59e0
0x142276863:  410f1006             movups    xmm0, xmmword ptr [r14]
0x142276867:  0f1107               movups    xmmword ptr [rdi], xmm0
0x14227686a:  410f104e10           movups    xmm1, xmmword ptr [r14 + 0x10]
0x14227686f:  0f114f10             movups    xmmword ptr [rdi + 0x10], xmm1
0x142276873:  4d896e10             mov       qword ptr [r14 + 0x10], r13
0x142276877:  49c746180f000000     mov       qword ptr [r14 + 0x18], 0xf
0x14227687f:  41c60600             mov       byte ptr [r14], 0
0x142276883:  488b4590             mov       rax, qword ptr [rbp - 0x70]
0x142276887:  4883f810             cmp       rax, 0x10
0x14227688b:  722e                 jb        0x1422768bb
0x14227688d:  48ffc0               inc       rax
0x142276890:  488b4c2478           mov       rcx, qword ptr [rsp + 0x78]
0x142276895:  488bd1               mov       rdx, rcx
0x142276898:  483d00100000         cmp       rax, 0x1000
0x14227689e:  7215                 jb        0x1422768b5
0x1422768a0:  488b49f8             mov       rcx, qword ptr [rcx - 8]
0x1422768a4:  482bd1               sub       rdx, rcx
0x1422768a7:  488d42f8             lea       rax, [rdx - 8]
0x1422768ab:  4883f81f             cmp       rax, 0x1f
0x1422768af:  0f878a020000         ja        0x142276b3f
0x1422768b5:  e8f6c76c02           call      0x1449430b0
0x1422768ba:  90                   nop       
0x1422768bb:  410f104708           movups    xmm0, xmmword ptr [r15 + 8]
0x1422768c0:  0f29442450           movaps    xmmword ptr [rsp + 0x50], xmm0
0x1422768c5:  488d542450           lea       rdx, [rsp + 0x50]
0x1422768ca:  488bce               mov       rcx, rsi
0x1422768cd:  e81e040000           call      0x142276cf0
0x1422768d2:  8986b0000000         mov       dword ptr [rsi + 0xb0], eax
0x1422768d8:  803d197b030600       cmp       byte ptr [rip + 0x6037b19], 0
0x1422768df:  7507                 jne       0x1422768e8
0x1422768e1:  c6867001000009       mov       byte ptr [rsi + 0x170], 9
0x1422768e8:  c644246002           mov       byte ptr [rsp + 0x60], 2
0x1422768ed:  803db480030600       cmp       byte ptr [rip + 0x60380b4], 0
0x1422768f4:  7474                 je        0x14227696a
0x1422768f6:  c644244100           mov       byte ptr [rsp + 0x41], 0
0x1422768fb:  c644245800           mov       byte ptr [rsp + 0x58], 0
0x142276900:  0fb703               movzx     eax, word ptr [rbx]
0x142276903:  6683f802             cmp       ax, 2
0x142276907:  740d                 je        0x142276916
0x142276909:  6683f817             cmp       ax, 0x17
0x14227690d:  7407                 je        0x142276916
0x14227690f:  b9ffff0000           mov       ecx, 0xffff
0x142276914:  eb0d                 jmp       0x142276923
0x142276916:  0fb74b02             movzx     ecx, word ptr [rbx + 2]
0x14227691a:  ff15108fec03         call      qword ptr [rip + 0x3ec8f10]
0x142276920:  0fb7c8               movzx     ecx, ax
0x142276923:  48837f1810           cmp       qword ptr [rdi + 0x18], 0x10
0x142276928:  7203                 jb        0x14227692d
0x14227692a:  488b3f               mov       rdi, qword ptr [rdi]
0x14227692d:  0f28442450           movaps    xmm0, xmmword ptr [rsp + 0x50]
0x142276932:  660f7f442450         movdqa    xmmword ptr [rsp + 0x50], xmm0
0x142276938:  0fb7442440           movzx     eax, word ptr [rsp + 0x40]
0x14227693d:  6689442428           mov       word ptr [rsp + 0x28], ax
0x142276942:  488d442450           lea       rax, [rsp + 0x50]
0x142276947:  4889442420           mov       qword ptr [rsp + 0x20], rax
0x14227694c:  440fb7c9             movzx     r9d, cx
0x142276950:  4c8bc7               mov       r8, rdi
0x142276953:  488d542461           lea       rdx, [rsp + 0x61]
0x142276958:  488bce               mov       rcx, rsi
0x14227695b:  e8e0040000           call      0x142276e40
0x142276960:  84c0                 test      al, al
0x142276962:  7513                 jne       0x142276977
0x142276964:  88442460             mov       byte ptr [rsp + 0x60], al
0x142276968:  eb0d                 jmp       0x142276977
0x14227696a:  488d542461           lea       rdx, [rsp + 0x61]
0x14227696f:  488bce               mov       rcx, rsi
0x142276972:  e8d9010000           call      0x142276b50
0x142276977:  b920000000           mov       ecx, 0x20
0x14227697c:  e87fce6c02           call      0x144943800
0x142276981:  4885c0               test      rax, rax
0x142276984:  0f8461010000         je        0x142276aeb
0x14227698a:  0f10442460           movups    xmm0, xmmword ptr [rsp + 0x60]
0x14227698f:  0fb64c2470           movzx     ecx, byte ptr [rsp + 0x70]
0x142276994:  488d15551fa204       lea       rdx, [rip + 0x4a21f55]
0x14227699b:  488910               mov       qword ptr [rax], rdx
0x14227699e:  0f114008             movups    xmmword ptr [rax + 8], xmm0
0x1422769a2:  884818               mov       byte ptr [rax + 0x18], cl
0x1422769a5:  4889442430           mov       qword ptr [rsp + 0x30], rax
0x1422769aa:  488d542430           lea       rdx, [rsp + 0x30]
0x1422769af:  488d4da0             lea       rcx, [rbp - 0x60]
0x1422769b3:  e818e9ffff           call      0x1422752d0
0x1422769b8:  41f6470301           test      byte ptr [r15 + 3], 1
0x1422769bd:  7412                 je        0x1422769d1
0x1422769bf:  498d5718             lea       rdx, [r15 + 0x18]
0x1422769c3:  450fb74746           movzx     r8d, word ptr [r15 + 0x46]
0x1422769c8:  488d4da0             lea       rcx, [rbp - 0x60]
0x1422769cc:  e85ff1ffff           call      0x142275b30
0x1422769d1:  0f57c0               xorps     xmm0, xmm0
0x1422769d4:  0f11442450           movups    xmmword ptr [rsp + 0x50], xmm0
0x1422769d9:  488b9dd0000000       mov       rbx, qword ptr [rbp + 0xd0]
0x1422769e0:  66480f7ec0           movq      rax, xmm0
0x1422769e5:  483903               cmp       qword ptr [rbx], rax
0x1422769e8:  750b                 jne       0x1422769f5
0x1422769ea:  488b4308             mov       rax, qword ptr [rbx + 8]
0x1422769ee:  483b442458           cmp       rax, qword ptr [rsp + 0x58]
0x1422769f3:  743d                 je        0x142276a32
0x1422769f5:  b918000000           mov       ecx, 0x18
0x1422769fa:  e801ce6c02           call      0x144943800
0x1422769ff:  4885c0               test      rax, rax
0x142276a02:  0f84c7000000         je        0x142276acf
0x142276a08:  488d0d091fa204       lea       rcx, [rip + 0x4a21f09]
0x142276a0f:  488908               mov       qword ptr [rax], rcx
0x142276a12:  0f1003               movups    xmm0, xmmword ptr [rbx]
0x142276a15:  0f114008             movups    xmmword ptr [rax + 8], xmm0
0x142276a19:  4c896c2450           mov       qword ptr [rsp + 0x50], r13
0x142276a1e:  4889442430           mov       qword ptr [rsp + 0x30], rax
0x142276a23:  488d542430           lea       rdx, [rsp + 0x30]
0x142276a28:  488d4da0             lea       rcx, [rbp - 0x60]
0x142276a2c:  e89fe8ffff           call      0x1422752d0
0x142276a31:  90                   nop       
0x142276a32:  488d55a0             lea       rdx, [rbp - 0x60]
0x142276a36:  498bcc               mov       rcx, r12
0x142276a39:  e882bdffff           call      0x1422727c0
0x142276a3e:  90                   nop       
0x142276a3f:  488d4530             lea       rax, [rbp + 0x30]
0x142276a43:  488b4d18             mov       rcx, qword ptr [rbp + 0x18]
0x142276a47:  483bc8               cmp       rcx, rax
0x142276a4a:  7406                 je        0x142276a52
0x142276a4c:  e85fc66c02           call      0x1449430b0
0x142276a51:  90                   nop       
0x142276a52:  488b5d00             mov       rbx, qword ptr [rbp]
0x142276a56:  4885db               test      rbx, rbx
0x142276a59:  0f8471fdffff         je        0x1422767d0
0x142276a5f:  488b7d08             mov       rdi, qword ptr [rbp + 8]
0x142276a63:  483bdf               cmp       rbx, rdi
0x142276a66:  7426                 je        0x142276a8e
0x142276a68:  488b0b               mov       rcx, qword ptr [rbx]
0x142276a6b:  4885c9               test      rcx, rcx
0x142276a6e:  7411                 je        0x142276a81
0x142276a70:  488b01               mov       rax, qword ptr [rcx]
0x142276a73:  ba01000000           mov       edx, 1
0x142276a78:  488b00               mov       rax, qword ptr [rax]
0x142276a7b:  ff15b792ec03         call      qword ptr [rip + 0x3ec92b7]
0x142276a81:  4883c308             add       rbx, 8
0x142276a85:  483bdf               cmp       rbx, rdi
0x142276a88:  75de                 jne       0x142276a68
0x142276a8a:  488b5d00             mov       rbx, qword ptr [rbp]
0x142276a8e:  488b4510             mov       rax, qword ptr [rbp + 0x10]
0x142276a92:  482bc3               sub       rax, rbx
0x142276a95:  48c1f803             sar       rax, 3
0x142276a99:  488d04c500000000     lea       rax, [rax*8]
0x142276aa1:  488bcb               mov       rcx, rbx
0x142276aa4:  483d00100000         cmp       rax, 0x1000
0x142276aaa:  7215                 jb        0x142276ac1
0x142276aac:  488b5bf8             mov       rbx, qword ptr [rbx - 8]
0x142276ab0:  482bcb               sub       rcx, rbx
0x142276ab3:  488d41f8             lea       rax, [rcx - 8]
0x142276ab7:  4883f81f             cmp       rax, 0x1f
0x142276abb:  0f8784000000         ja        0x142276b45
0x142276ac1:  488bcb               mov       rcx, rbx
0x142276ac4:  e8e7c56c02           call      0x1449430b0
0x142276ac9:  90                   nop       
0x142276aca:  e9f5fcffff           jmp       0x1422767c4
0x142276acf:  488d4c2478           lea       rcx, [rsp + 0x78]
0x142276ad4:  e8174354fe           call      0x1407badf0
0x142276ad9:  488d156001a905       lea       rdx, [rip + 0x5a90160]
0x142276ae0:  488d4c2478           lea       rcx, [rsp + 0x78]
0x142276ae5:  e866c58c03           call      0x145b43050
0x142276aea:  cc                   int3      
0x142276aeb:  488d4c2478           lea       rcx, [rsp + 0x78]
0x142276af0:  e8fb4254fe           call      0x1407badf0
0x142276af5:  488d154401a905       lea       rdx, [rip + 0x5a90144]
0x142276afc:  488d4c2478           lea       rcx, [rsp + 0x78]
0x142276b01:  e84ac58c03           call      0x145b43050
0x142276b06:  cc                   int3      
0x142276b07:  488d4c2478           lea       rcx, [rsp + 0x78]
0x142276b0c:  e8df4254fe           call      0x1407badf0
0x142276b11:  488d152801a905       lea       rdx, [rip + 0x5a90128]
0x142276b18:  488d4c2478           lea       rcx, [rsp + 0x78]
0x142276b1d:  e82ec58c03           call      0x145b43050
0x142276b22:  cc                   int3      
0x142276b23:  488d4c2478           lea       rcx, [rsp + 0x78]
0x142276b28:  e8c34254fe           call      0x1407badf0
0x142276b2d:  488d150c01a905       lea       rdx, [rip + 0x5a9010c]
0x142276b34:  488d4c2478           lea       rcx, [rsp + 0x78]
0x142276b39:  e812c58c03           call      0x145b43050
0x142276b3e:  cc                   int3      
0x142276b3f:  e8dca98d03           call      0x145b51520
0x142276b44:  90                   nop       
0x142276b45:  e8d6a98d03           call      0x145b51520
0x142276b4a:  cc                   int3      
0x142276b4b:  cc                   int3      
0x142276b4c:  cc                   int3      
0x142276b4d:  cc                   int3      
0x142276b4e:  cc                   int3      
0x142276b4f:  cc                   int3      
