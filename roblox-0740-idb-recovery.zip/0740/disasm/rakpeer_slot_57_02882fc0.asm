; RakPeer vtable slot 57
; rva 0x2882fc0
0x142882fc0:  4053                 push      rbx
0x142882fc2:  55                   push      rbp
0x142882fc3:  56                   push      rsi
0x142882fc4:  57                   push      rdi
0x142882fc5:  4154                 push      r12
0x142882fc7:  4155                 push      r13
0x142882fc9:  4156                 push      r14
0x142882fcb:  4157                 push      r15
0x142882fcd:  4883ec68             sub       rsp, 0x68
0x142882fd1:  488b8424e8000000     mov       rax, qword ptr [rsp + 0xe8]
0x142882fd9:  4d8be9               mov       r13, r9
0x142882fdc:  4c8bb424d0000000     mov       r14, qword ptr [rsp + 0xd0]
0x142882fe4:  488bf1               mov       rsi, rcx
0x142882fe7:  4c8bbc24d8000000     mov       r15, qword ptr [rsp + 0xd8]
0x142882fef:  4c8ba424e0000000     mov       r12, qword ptr [rsp + 0xe0]
0x142882ff7:  488b9c24f0000000     mov       rbx, qword ptr [rsp + 0xf0]
0x142882fff:  4889442430           mov       qword ptr [rsp + 0x30], rax
0x142883004:  0fb7053fc85605       movzx     eax, word ptr [rip + 0x556c83f]
0x14288300b:  66394202             cmp       word ptr [rdx + 2], ax
0x14288300f:  7541                 jne       0x142883052
0x142883011:  0fb702               movzx     eax, word ptr [rdx]
0x142883014:  663b052dc85605       cmp       ax, word ptr [rip + 0x556c82d]
0x14288301b:  7535                 jne       0x142883052
0x14288301d:  6683f802             cmp       ax, 2
0x142883021:  750b                 jne       0x14288302e
0x142883023:  8b0523c85605         mov       eax, dword ptr [rip + 0x556c823]
0x142883029:  394204               cmp       dword ptr [rdx + 4], eax
0x14288302c:  eb1e                 jmp       0x14288304c
0x14288302e:  6683f817             cmp       ax, 0x17
0x142883032:  751e                 jne       0x142883052
0x142883034:  488b4208             mov       rax, qword ptr [rdx + 8]
0x142883038:  483b0511c85605       cmp       rax, qword ptr [rip + 0x556c811]
0x14288303f:  7511                 jne       0x142883052
0x142883041:  488b4210             mov       rax, qword ptr [rdx + 0x10]
0x142883045:  483b050cc85605       cmp       rax, qword ptr [rip + 0x556c80c]
0x14288304c:  0f84d1000000         je        0x142883123
0x142883052:  0f1002               movups    xmm0, xmmword ptr [rdx]
0x142883055:  4489442420           mov       dword ptr [rsp + 0x20], r8d
0x14288305a:  41b101               mov       r9b, 1
0x14288305d:  0f104a10             movups    xmm1, xmmword ptr [rdx + 0x10]
0x142883061:  4533c0               xor       r8d, r8d
0x142883064:  488d542440           lea       rdx, [rsp + 0x40]
0x142883069:  0f29442440           movaps    xmmword ptr [rsp + 0x40], xmm0
0x14288306e:  0f294c2450           movaps    xmmword ptr [rsp + 0x50], xmm1
0x142883073:  e8d8230000           call      0x142885450
0x142883078:  488be8               mov       rbp, rax
0x14288307b:  4885c0               test      rax, rax
0x14288307e:  0f849f000000         je        0x142883123
0x142883084:  488d8ea80e0000       lea       rcx, [rsi + 0xea8]
0x14288308b:  e820072a03           call      0x145b237b0
0x142883090:  85c0                 test      eax, eax
0x142883092:  0f85be000000         jne       0x142883156
0x142883098:  8b8540160000         mov       eax, dword ptr [rbp + 0x1640]
0x14288309e:  488d8d88010000       lea       rcx, [rbp + 0x188]
0x1428830a5:  488bd3               mov       rdx, rbx
0x1428830a8:  41894500             mov       dword ptr [r13], eax
0x1428830ac:  e8bf190300           call      0x1428b4a70
0x1428830b1:  4c8bc3               mov       r8, rbx
0x1428830b4:  488bd5               mov       rdx, rbp
0x1428830b7:  e854eeffff           call      0x142881f10
0x1428830bc:  807b0400             cmp       byte ptr [rbx + 4], 0
0x1428830c0:  7404                 je        0x1428830c6
0x1428830c2:  8b03                 mov       eax, dword ptr [rbx]
0x1428830c4:  eb05                 jmp       0x1428830cb
0x1428830c6:  b8ffffffff           mov       eax, 0xffffffff
0x1428830cb:  418906               mov       dword ptr [r14], eax
0x1428830ce:  807b2400             cmp       byte ptr [rbx + 0x24], 0
0x1428830d2:  7405                 je        0x1428830d9
0x1428830d4:  8b4320               mov       eax, dword ptr [rbx + 0x20]
0x1428830d7:  eb05                 jmp       0x1428830de
0x1428830d9:  b8ffffffff           mov       eax, 0xffffffff
0x1428830de:  418907               mov       dword ptr [r15], eax
0x1428830e1:  807b2c00             cmp       byte ptr [rbx + 0x2c], 0
0x1428830e5:  7405                 je        0x1428830ec
0x1428830e7:  8b4328               mov       eax, dword ptr [rbx + 0x28]
0x1428830ea:  eb05                 jmp       0x1428830f1
0x1428830ec:  b8ffff0000           mov       eax, 0xffff
0x1428830f1:  488b4c2430           mov       rcx, qword ptr [rsp + 0x30]
0x1428830f6:  41890424             mov       dword ptr [r12], eax
0x1428830fa:  8b8688000000         mov       eax, dword ptr [rsi + 0x88]
0x142883100:  8901                 mov       dword ptr [rcx], eax
0x142883102:  488d8ea80e0000       lea       rcx, [rsi + 0xea8]
0x142883109:  0fb68608010000       movzx     eax, byte ptr [rsi + 0x108]
0x142883110:  90                   nop       
0x142883111:  84c0                 test      al, al
0x142883113:  7509                 jne       0x14288311e
0x142883115:  e8f6062a03           call      0x145b23810
0x14288311a:  b001                 mov       al, 1
0x14288311c:  eb27                 jmp       0x142883145
0x14288311e:  e8ed062a03           call      0x145b23810
0x142883123:  8b86f0080000         mov       eax, dword ptr [rsi + 0x8f0]
0x142883129:  41894500             mov       dword ptr [r13], eax
0x14288312d:  32c0                 xor       al, al
0x14288312f:  41c706ffffffff       mov       dword ptr [r14], 0xffffffff
0x142883136:  41c707ffffffff       mov       dword ptr [r15], 0xffffffff
0x14288313d:  41c70424ffffffff     mov       dword ptr [r12], 0xffffffff
0x142883145:  4883c468             add       rsp, 0x68
0x142883149:  415f                 pop       r15
0x14288314b:  415e                 pop       r14
0x14288314d:  415d                 pop       r13
0x14288314f:  415c                 pop       r12
0x142883151:  5f                   pop       rdi
0x142883152:  5e                   pop       rsi
0x142883153:  5d                   pop       rbp
0x142883154:  5b                   pop       rbx
0x142883155:  c3                   ret       
0x142883156:  8bc8                 mov       ecx, eax
0x142883158:  e8230c2a03           call      0x145b23d80
0x14288315d:  cc                   int3      
0x14288315e:  cc                   int3      
0x14288315f:  cc                   int3      
0x142883160:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x142883165:  55                   push      rbp
0x142883166:  56                   push      rsi
0x142883167:  57                   push      rdi
0x142883168:  4883ec40             sub       rsp, 0x40
0x14288316c:  0fb72dd7c65605       movzx     ebp, word ptr [rip + 0x556c6d7]
0x142883173:  4c8bc9               mov       r9, rcx
0x142883176:  488b3ddbc65605       mov       rdi, qword ptr [rip + 0x556c6db]
0x14288317d:  8b0dc9c65605         mov       ecx, dword ptr [rip + 0x556c6c9]
0x142883183:  488b35c6c65605       mov       rsi, qword ptr [rip + 0x556c6c6]
0x14288318a:  0fb71db7c65605       movzx     ebx, word ptr [rip + 0x556c6b7]
0x142883191:  66396a02             cmp       word ptr [rdx + 2], bp
0x142883195:  7529                 jne       0x1428831c0
0x142883197:  0fb702               movzx     eax, word ptr [rdx]
0x14288319a:  663bc3               cmp       ax, bx
0x14288319d:  7521                 jne       0x1428831c0
0x14288319f:  6683f802             cmp       ax, 2
0x1428831a3:  7505                 jne       0x1428831aa
0x1428831a5:  394a04               cmp       dword ptr [rdx + 4], ecx
0x1428831a8:  eb10                 jmp       0x1428831ba
0x1428831aa:  6683f817             cmp       ax, 0x17
0x1428831ae:  7510                 jne       0x1428831c0
0x1428831b0:  48397208             cmp       qword ptr [rdx + 8], rsi
0x1428831b4:  750a                 jne       0x1428831c0
0x1428831b6:  48397a10             cmp       qword ptr [rdx + 0x10], rdi
0x1428831ba:  0f84d6000000         je        0x142883296
0x1428831c0:  0f100a               movups    xmm1, xmmword ptr [rdx]
0x1428831c3:  0f104210             movups    xmm0, xmmword ptr [rdx + 0x10]
0x1428831c7:  66490f7ec8           movq      r8, xmm1
0x1428831cc:  0f294c2420           movaps    xmmword ptr [rsp + 0x20], xmm1
0x1428831d1:  4c8b5c2428           mov       r11, qword ptr [rsp + 0x28]
0x1428831d6:  498bc0               mov       rax, r8
0x1428831d9:  48c1e810             shr       rax, 0x10
0x1428831dd:  0f29442430           movaps    xmmword ptr [rsp + 0x30], xmm0
0x1428831e2:  4c8b542430           mov       r10, qword ptr [rsp + 0x30]
0x1428831e7:  663bc5               cmp       ax, bp
0x1428831ea:  752d                 jne       0x142883219
0x1428831ec:  66443bc3             cmp       r8w, bx
0x1428831f0:  7527                 jne       0x142883219
0x1428831f2:  664183f802           cmp       r8w, 2
0x1428831f7:  750b                 jne       0x142883204
0x1428831f9:  498bc0               mov       rax, r8
0x1428831fc:  48c1e820             shr       rax, 0x20
0x142883200:  3bc1                 cmp       eax, ecx
0x142883202:  eb0f                 jmp       0x142883213
0x142883204:  664183f817           cmp       r8w, 0x17
0x142883209:  750e                 jne       0x142883219
0x14288320b:  4c3bde               cmp       r11, rsi
0x14288320e:  7509                 jne       0x142883219
0x142883210:  4c3bd7               cmp       r10, rdi
0x142883213:  0f847d000000         je        0x142883296
0x142883219:  33d2                 xor       edx, edx
0x14288321b:  66413b9112010000     cmp       dx, word ptr [r9 + 0x112]
0x142883223:  7371                 jae       0x142883296
0x142883225:  498b8950030000       mov       rcx, qword ptr [r9 + 0x350]
0x14288322c:  4863c2               movsxd    rax, edx
0x14288322f:  4869d8d8160000       imul      rbx, rax, 0x16d8
0x142883236:  0fb7442422           movzx     eax, word ptr [rsp + 0x22]
0x14288323b:  4803cb               add       rcx, rbx
0x14288323e:  66394106             cmp       word ptr [rcx + 6], ax
0x142883242:  7544                 jne       0x142883288
0x142883244:  0fb74104             movzx     eax, word ptr [rcx + 4]
0x142883248:  66413bc0             cmp       ax, r8w
0x14288324c:  753a                 jne       0x142883288
0x14288324e:  6683f802             cmp       ax, 2
0x142883252:  750b                 jne       0x14288325f
0x142883254:  8b442424             mov       eax, dword ptr [rsp + 0x24]
0x142883258:  394108               cmp       dword ptr [rcx + 8], eax
0x14288325b:  7414                 je        0x142883271
0x14288325d:  eb29                 jmp       0x142883288
0x14288325f:  6683f817             cmp       ax, 0x17
0x142883263:  7523                 jne       0x142883288
0x142883265:  4c39590c             cmp       qword ptr [rcx + 0xc], r11
0x142883269:  751d                 jne       0x142883288
0x14288326b:  4c395114             cmp       qword ptr [rcx + 0x14], r10
0x14288326f:  7517                 jne       0x142883288
0x142883271:  0fb601               movzx     eax, byte ptr [rcx]
0x142883274:  90                   nop       
0x142883275:  84c0                 test      al, al
0x142883277:  7531                 jne       0x1428832aa
0x142883279:  4c8b542430           mov       r10, qword ptr [rsp + 0x30]
0x14288327e:  4c8b5c2428           mov       r11, qword ptr [rsp + 0x28]
0x142883283:  4c8b442420           mov       r8, qword ptr [rsp + 0x20]
0x142883288:  410fb78112010000     movzx     eax, word ptr [r9 + 0x112]
0x142883290:  ffc2                 inc       edx
0x142883292:  3bd0                 cmp       edx, eax
0x142883294:  728f                 jb        0x142883225
0x142883296:  418b81f0080000       mov       eax, dword ptr [r9 + 0x8f0]
0x14288329d:  488b5c2470           mov       rbx, qword ptr [rsp + 0x70]
0x1428832a2:  4883c440             add       rsp, 0x40
0x1428832a6:  5f                   pop       rdi
0x1428832a7:  5e                   pop       rsi
0x1428832a8:  5d                   pop       rbp
0x1428832a9:  c3                   ret       
0x1428832aa:  49039950030000       add       rbx, qword ptr [r9 + 0x350]
0x1428832b1:  74e3                 je        0x142883296
0x1428832b3:  498db9a80e0000       lea       rdi, [r9 + 0xea8]
0x1428832ba:  488bcf               mov       rcx, rdi
0x1428832bd:  e8ee042a03           call      0x145b237b0
0x1428832c2:  85c0                 test      eax, eax
0x1428832c4:  751d                 jne       0x1428832e3
0x1428832c6:  8b9b40160000         mov       ebx, dword ptr [rbx + 0x1640]
0x1428832cc:  488bcf               mov       rcx, rdi
0x1428832cf:  e83c052a03           call      0x145b23810
0x1428832d4:  8bc3                 mov       eax, ebx
0x1428832d6:  488b5c2470           mov       rbx, qword ptr [rsp + 0x70]
0x1428832db:  4883c440             add       rsp, 0x40
0x1428832df:  5f                   pop       rdi
0x1428832e0:  5e                   pop       rsi
0x1428832e1:  5d                   pop       rbp
0x1428832e2:  c3                   ret       
0x1428832e3:  8bc8                 mov       ecx, eax
0x1428832e5:  e8960a2a03           call      0x145b23d80
0x1428832ea:  cc                   int3      
0x1428832eb:  cc                   int3      
0x1428832ec:  cc                   int3      
0x1428832ed:  cc                   int3      
0x1428832ee:  cc                   int3      
0x1428832ef:  cc                   int3      
