; RakPeer vtable slot 67
; rva 0x28836d0
0x1428836d0:  4885d2               test      rdx, rdx
0x1428836d3:  7463                 je        0x142883738
0x1428836d5:  4889742418           mov       qword ptr [rsp + 0x18], rsi
0x1428836da:  4889542410           mov       qword ptr [rsp + 0x10], rdx
0x1428836df:  57                   push      rdi
0x1428836e0:  4883ec30             sub       rsp, 0x30
0x1428836e4:  488bf9               mov       rdi, rcx
0x1428836e7:  48895c2440           mov       qword ptr [rsp + 0x40], rbx
0x1428836ec:  4881c1300c0000       add       rcx, 0xc30
0x1428836f3:  410fb6f0             movzx     esi, r8b
0x1428836f7:  e8b4002a03           call      0x145b237b0
0x1428836fc:  85c0                 test      eax, eax
0x1428836fe:  7539                 jne       0x142883739
0x142883700:  488d8f800c0000       lea       rcx, [rdi + 0xc80]
0x142883707:  488d542448           lea       rdx, [rsp + 0x48]
0x14288370c:  4084f6               test      sil, sil
0x14288370f:  7407                 je        0x142883718
0x142883711:  e86af30100           call      0x1428a2a80
0x142883716:  eb05                 jmp       0x14288371d
0x142883718:  e873e30100           call      0x1428a1a90
0x14288371d:  488d8f300c0000       lea       rcx, [rdi + 0xc30]
0x142883724:  e8e7002a03           call      0x145b23810
0x142883729:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x14288372e:  488b742450           mov       rsi, qword ptr [rsp + 0x50]
0x142883733:  4883c430             add       rsp, 0x30
0x142883737:  5f                   pop       rdi
0x142883738:  c3                   ret       
0x142883739:  8bc8                 mov       ecx, eax
0x14288373b:  e840062a03           call      0x145b23d80
0x142883740:  cc                   int3      
0x142883741:  cc                   int3      
0x142883742:  cc                   int3      
0x142883743:  cc                   int3      
0x142883744:  cc                   int3      
0x142883745:  cc                   int3      
0x142883746:  cc                   int3      
0x142883747:  cc                   int3      
0x142883748:  cc                   int3      
0x142883749:  cc                   int3      
0x14288374a:  cc                   int3      
0x14288374b:  cc                   int3      
0x14288374c:  cc                   int3      
0x14288374d:  cc                   int3      
0x14288374e:  cc                   int3      
0x14288374f:  cc                   int3      
