; RuppTokenProcessor vtable slot 0 rva 0x2278050
0x142278050:  4053                 push      rbx
0x142278052:  4883ec20             sub       rsp, 0x20
0x142278056:  488bd9               mov       rbx, rcx
0x142278059:  488d055809a204       lea       rax, [rip + 0x4a20958]
0x142278060:  488901               mov       qword ptr [rcx], rax
0x142278063:  f6c201               test      dl, 1
0x142278066:  7406                 je        0x14227806e
0x142278068:  e843b06c02           call      0x1449430b0
0x14227806d:  90                   nop       
0x14227806e:  488bc3               mov       rax, rbx
0x142278071:  4883c420             add       rsp, 0x20
0x142278075:  5b                   pop       rbx
0x142278076:  c3                   ret       
0x142278077:  cc                   int3      
0x142278078:  cc                   int3      
0x142278079:  cc                   int3      
0x14227807a:  cc                   int3      
0x14227807b:  cc                   int3      
0x14227807c:  cc                   int3      
0x14227807d:  cc                   int3      
0x14227807e:  cc                   int3      
0x14227807f:  cc                   int3      
