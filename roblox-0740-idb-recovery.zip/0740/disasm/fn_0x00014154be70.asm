; function_of: vtab.Ipv4ReverseEndpointTlv
; xref site 0x14154bfb7 -> vtab.Ipv4ReverseEndpointTlv @ 0x146c98940
; range 0x14154be70 .. 0x14154c210  (928 bytes)

0x00014154be70:  4053                  push      rbx
0x00014154be72:  4883ec60              sub       rsp, 0x60
0x00014154be76:  803d436d120700        cmp       byte ptr [rip + 0x7126d43], 0
0x00014154be7d:  488b5928              mov       rbx, qword ptr [rcx + 0x28]
0x00014154be81:  742c                  je        0x14154beaf
0x00014154be83:  e818128c00            call      0x141e0d0a0
0x00014154be88:  84c0                  test      al, al
0x00014154be8a:  7409                  je        0x14154be95
0x00014154be8c:  488b8b18050000        mov       rcx, qword ptr [rbx + 0x518]
0x00014154be93:  eb21                  jmp       0x14154beb6
0x00014154be95:  80bb1005000000        cmp       byte ptr [rbx + 0x510], 0
0x00014154be9c:  741d                  je        0x14154bebb
0x00014154be9e:  488b8b08050000        mov       rcx, qword ptr [rbx + 0x508]
0x00014154bea5:  e8e62139ff            call      0x1408de090
0x00014154beaa:  488bc8                mov       rcx, rax
0x00014154bead:  eb07                  jmp       0x14154beb6
0x00014154beaf:  488b8bf8040000        mov       rcx, qword ptr [rbx + 0x4f8]
0x00014154beb6:  4885c9                test      rcx, rcx
0x00014154beb9:  750e                  jne       0x14154bec9
0x00014154bebb:  f20f100545ddc705      movsd     xmm0, qword ptr [rip + 0x5c7dd45]
0x00014154bec3:  4883c460              add       rsp, 0x60
0x00014154bec7:  5b                    pop       rbx
0x00014154bec8:  c3                    ret       
0x00014154bec9:  f20f100537ddc705      movsd     xmm0, qword ptr [rip + 0x5c7dd37]
0x00014154bed1:  488d1540ab7005        lea       rdx, [rip + 0x570ab40]
0x00014154bed8:  4889542420            mov       qword ptr [rsp + 0x20], rdx
0x00014154bedd:  4c8d442420            lea       r8, [rsp + 0x20]
0x00014154bee2:  488d542470            lea       rdx, [rsp + 0x70]
0x00014154bee7:  f20f11442470          movsd     qword ptr [rsp + 0x70], xmm0
0x00014154beed:  488b01                mov       rax, qword ptr [rcx]
0x00014154bef0:  4889542428            mov       qword ptr [rsp + 0x28], rdx
0x00014154bef5:  488d542420            lea       rdx, [rsp + 0x20]
0x00014154befa:  4889542458            mov       qword ptr [rsp + 0x58], rdx
0x00014154beff:  ba01000000            mov       edx, 1
0x00014154bf04:  488b4040              mov       rax, qword ptr [rax + 0x40]
0x00014154bf08:  ff152a3ebf04          call      qword ptr [rip + 0x4bf3e2a]
0x00014154bf0e:  f20f10442470          movsd     xmm0, qword ptr [rsp + 0x70]
0x00014154bf14:  4883c460              add       rsp, 0x60
0x00014154bf18:  5b                    pop       rbx
0x00014154bf19:  c3                    ret       
0x00014154bf1a:  cc                    int3      
0x00014154bf1b:  cc                    int3      
0x00014154bf1c:  cc                    int3      
0x00014154bf1d:  cc                    int3      
0x00014154bf1e:  cc                    int3      
0x00014154bf1f:  cc                    int3      
0x00014154bf20:  4883ec38              sub       rsp, 0x38
0x00014154bf24:  ba20000000            mov       edx, 0x20
0x00014154bf29:  65488b042558000000    mov       rax, qword ptr gs:[0x58]
0x00014154bf32:  488b08                mov       rcx, qword ptr [rax]
0x00014154bf35:  8b040a                mov       eax, dword ptr [rdx + rcx]
0x00014154bf38:  390542e45107          cmp       dword ptr [rip + 0x751e442], eax
0x00014154bf3e:  7f31                  jg        0x14154bf71
0x00014154bf40:  488d05812b8a06        lea       rax, [rip + 0x68a2b81]
0x00014154bf47:  4883c438              add       rsp, 0x38
0x00014154bf4b:  c3                    ret       
0x00014154bf4c:  488d0d3dd9b904        lea       rcx, [rip + 0x4b9d93d]
0x00014154bf53:  e8685a5d04            call      0x145b219c0
0x00014154bf58:  90                    nop       
0x00014154bf59:  488d0d20e45107        lea       rcx, [rip + 0x751e420]
0x00014154bf60:  e8eb53abfe            call      0x140001350
0x00014154bf65:  488d055c2b8a06        lea       rax, [rip + 0x68a2b5c]
0x00014154bf6c:  4883c438              add       rsp, 0x38
0x00014154bf70:  c3                    ret       
0x00014154bf71:  488d0d08e45107        lea       rcx, [rip + 0x751e408]
0x00014154bf78:  e8f352abfe            call      0x140001270
0x00014154bf7d:  833dfce35107ff        cmp       dword ptr [rip + 0x751e3fc], -1
0x00014154bf84:  75ba                  jne       0x14154bf40
0x00014154bf86:  488d4c2420            lea       rcx, [rsp + 0x20]
0x00014154bf8b:  e800de0000            call      0x141559d90
0x00014154bf90:  488b08                mov       rcx, qword ptr [rax]
0x00014154bf93:  488b5008              mov       rdx, qword ptr [rax + 8]
0x00014154bf97:  4533c0                xor       r8d, r8d
0x00014154bf9a:  4c8900                mov       qword ptr [rax], r8
0x00014154bf9d:  4c894008              mov       qword ptr [rax + 8], r8
0x00014154bfa1:  48890d482b8a06        mov       qword ptr [rip + 0x68a2b48], rcx
0x00014154bfa8:  488b0d492b8a06        mov       rcx, qword ptr [rip + 0x68a2b49]
0x00014154bfaf:  488915422b8a06        mov       qword ptr [rip + 0x68a2b42], rdx
0x00014154bfb6:  4885c9                test      rcx, rcx
0x00014154bfb9:  7405                  je        0x14154bfc0
0x00014154bfbb:  e850cf27ff            call      0x1407c8f10
0x00014154bfc0:  488b4c2428            mov       rcx, qword ptr [rsp + 0x28]
0x00014154bfc5:  4885c9                test      rcx, rcx
0x00014154bfc8:  7482                  je        0x14154bf4c
0x00014154bfca:  e841cf27ff            call      0x1407c8f10
0x00014154bfcf:  90                    nop       
0x00014154bfd0:  e977ffffff            jmp       0x14154bf4c
0x00014154bfd5:  cc                    int3      
0x00014154bfd6:  cc                    int3      
0x00014154bfd7:  cc                    int3      
0x00014154bfd8:  cc                    int3      
0x00014154bfd9:  cc                    int3      
0x00014154bfda:  cc                    int3      
0x00014154bfdb:  cc                    int3      
0x00014154bfdc:  cc                    int3      
0x00014154bfdd:  cc                    int3      
0x00014154bfde:  cc                    int3      
0x00014154bfdf:  cc                    int3      
0x00014154bfe0:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014154bfe5:  57                    push      rdi
0x00014154bfe6:  4883ec20              sub       rsp, 0x20
0x00014154bfea:  8bfa                  mov       edi, edx
0x00014154bfec:  488bd9                mov       rbx, rcx
0x00014154bfef:  488d050aae7005        lea       rax, [rip + 0x570ae0a]
0x00014154bff6:  488901                mov       qword ptr [rcx], rax
0x00014154bff9:  488b4930              mov       rcx, qword ptr [rcx + 0x30]
0x00014154bffd:  4885c9                test      rcx, rcx
0x00014154c000:  7405                  je        0x14154c007
0x00014154c002:  e809cf27ff            call      0x1407c8f10
0x00014154c007:  488d4b08              lea       rcx, [rbx + 8]
0x00014154c00b:  e8d09929ff            call      0x1407e59e0
0x00014154c010:  40f6c701              test      dil, 1
0x00014154c014:  7409                  je        0x14154c01f
0x00014154c016:  488bcb                mov       rcx, rbx
0x00014154c019:  e892703f03            call      0x1449430b0
0x00014154c01e:  90                    nop       
0x00014154c01f:  488bc3                mov       rax, rbx
0x00014154c022:  488b5c2430            mov       rbx, qword ptr [rsp + 0x30]
0x00014154c027:  4883c420              add       rsp, 0x20
0x00014154c02b:  5f                    pop       rdi
0x00014154c02c:  c3                    ret       
0x00014154c02d:  cc                    int3      
0x00014154c02e:  cc                    int3      
0x00014154c02f:  cc                    int3      
0x00014154c030:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014154c035:  48896c2410            mov       qword ptr [rsp + 0x10], rbp
0x00014154c03a:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x00014154c03f:  57                    push      rdi
0x00014154c040:  4883ec70              sub       rsp, 0x70
0x00014154c044:  498bf0                mov       rsi, r8
0x00014154c047:  488bea                mov       rbp, rdx
0x00014154c04a:  488bf9                mov       rdi, rcx
0x00014154c04d:  b938000000            mov       ecx, 0x38
0x00014154c052:  e8a9773f03            call      0x144943800
0x00014154c057:  488bd8                mov       rbx, rax
0x00014154c05a:  4885c0                test      rax, rax
0x00014154c05d:  0f84a1000000          je        0x14154c104
0x00014154c063:  4889842498000000      mov       qword ptr [rsp + 0x98], rax
0x00014154c06b:  0f1006                movups    xmm0, xmmword ptr [rsi]
0x00014154c06e:  0f29442420            movaps    xmmword ptr [rsp + 0x20], xmm0
0x00014154c073:  0f104d00              movups    xmm1, xmmword ptr [rbp]
0x00014154c077:  0f294c2430            movaps    xmmword ptr [rsp + 0x30], xmm1
0x00014154c07c:  33f6                  xor       esi, esi
0x00014154c07e:  48897008              mov       qword ptr [rax + 8], rsi
0x00014154c082:  48897018              mov       qword ptr [rax + 0x18], rsi
0x00014154c086:  48c740200f000000      mov       qword ptr [rax + 0x20], 0xf
0x00014154c08e:  488d056bad7005        lea       rax, [rip + 0x570ad6b]
0x00014154c095:  488903                mov       qword ptr [rbx], rax
0x00014154c098:  48897328              mov       qword ptr [rbx + 0x28], rsi
0x00014154c09c:  48897330              mov       qword ptr [rbx + 0x30], rsi
0x00014154c0a0:  4c8d442420            lea       r8, [rsp + 0x20]
0x00014154c0a5:  488d542430            lea       rdx, [rsp + 0x30]
0x00014154c0aa:  488d4c2440            lea       rcx, [rsp + 0x40]
0x00014154c0af:  e8ccde0000            call      0x141559f80
0x00014154c0b4:  488b08                mov       rcx, qword ptr [rax]
0x00014154c0b7:  488b5008              mov       rdx, qword ptr [rax + 8]
0x00014154c0bb:  488930                mov       qword ptr [rax], rsi
0x00014154c0be:  48897008              mov       qword ptr [rax + 8], rsi
0x00014154c0c2:  48894b28              mov       qword ptr [rbx + 0x28], rcx
0x00014154c0c6:  488b4b30              mov       rcx, qword ptr [rbx + 0x30]
0x00014154c0ca:  48895330              mov       qword ptr [rbx + 0x30], rdx
0x00014154c0ce:  4885c9                test      rcx, rcx
0x00014154c0d1:  7405                  je        0x14154c0d8
0x00014154c0d3:  e838ce27ff            call      0x1407c8f10
0x00014154c0d8:  488b4c2448            mov       rcx, qword ptr [rsp + 0x48]
0x00014154c0dd:  4885c9                test      rcx, rcx
0x00014154c0e0:  7406                  je        0x14154c0e8
0x00014154c0e2:  e829ce27ff            call      0x1407c8f10
0x00014154c0e7:  90                    nop       
0x00014154c0e8:  48891f                mov       qword ptr [rdi], rbx
0x00014154c0eb:  488bc7                mov       rax, rdi
0x00014154c0ee:  4c8d5c2470            lea       r11, [rsp + 0x70]
0x00014154c0f3:  498b5b10              mov       rbx, qword ptr [r11 + 0x10]
0x00014154c0f7:  498b6b18              mov       rbp, qword ptr [r11 + 0x18]
0x00014154c0fb:  498b7320              mov       rsi, qword ptr [r11 + 0x20]
0x00014154c0ff:  498be3                mov       rsp, r11
0x00014154c102:  5f                    pop       rdi
0x00014154c103:  c3                    ret       
0x00014154c104:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014154c109:  e8e2ec26ff            call      0x1407badf0
0x00014154c10e:  488d152bab7b06        lea       rdx, [rip + 0x67bab2b]
0x00014154c115:  488d4c2450            lea       rcx, [rsp + 0x50]
0x00014154c11a:  e8316f5f04            call      0x145b43050
0x00014154c11f:  cc                    int3      
0x00014154c120:  48895c2408            mov       qword ptr [rsp + 8], rbx
0x00014154c125:  48896c2410            mov       qword ptr [rsp + 0x10], rbp
0x00014154c12a:  4889742418            mov       qword ptr [rsp + 0x18], rsi
0x00014154c12f:  57                    push      rdi
0x00014154c130:  4883ec60              sub       rsp, 0x60
0x00014154c134:  498bf0                mov       rsi, r8
0x00014154c137:  488bea                mov       rbp, rdx
0x00014154c13a:  488bf9                mov       rdi, rcx
0x00014154c13d:  b938000000            mov       ecx, 0x38
0x00014154c142:  e8b9763f03            call      0x144943800
0x00014154c147:  488bd8                mov       rbx, rax
0x00014154c14a:  4885c0                test      rax, rax
0x00014154c14d:  0f849f000000          je        0x14154c1f2
0x00014154c153:  4889442428            mov       qword ptr [rsp + 0x28], rax
0x00014154c158:  4889b42488000000      mov       qword ptr [rsp + 0x88], rsi
0x00014154c160:  48896c2420            mov       qword ptr [rsp + 0x20], rbp
0x00014154c165:  33f6                  xor       esi, esi
0x00014154c167:  48897008              mov       qword ptr [rax + 8], rsi
0x00014154c16b:  48897018              mov       qword ptr [rax + 0x18], rsi
0x00014154c16f:  48c740200f000000      mov       qword ptr [rax + 0x20], 0xf
0x00014154c177:  488d0582ac7005        lea       rax, [rip + 0x570ac82]
0x00014154c17e:  488903                mov       qword ptr [rbx], rax
0x00014154c181:  48897328              mov       qword ptr [rbx + 0x28], rsi
0x00014154c185:  48897330              mov       qword ptr [rbx + 0x30], rsi
0x00014154c189:  4c8d842488000000      lea       r8, [rsp + 0x88]
0x00014154c191:  488d542420            lea       rdx, [rsp + 0x20]
0x00014154c196:  488d4c2430            lea       rcx, [rsp + 0x30]
0x00014154c19b:  e850e00000            call      0x14155a1f0
0x00014154c1a0:  488b08                mov       rcx, qword ptr [rax]
0x00014154c1a3:  488b5008              mov       rdx, qword ptr [rax + 8]
0x00014154c1a7:  488930                mov       qword ptr [rax], rsi
0x00014154c1aa:  48897008              mov       qword ptr [rax + 8], rsi
0x00014154c1ae:  48894b28              mov       qword ptr [rbx + 0x28], rcx
0x00014154c1b2:  488b4b30              mov       rcx, qword ptr [rbx + 0x30]
0x00014154c1b6:  48895330              mov       qword ptr [rbx + 0x30], rdx
0x00014154c1ba:  4885c9                test      rcx, rcx
0x00014154c1bd:  7405                  je        0x14154c1c4
0x00014154c1bf:  e84ccd27ff            call      0x1407c8f10
0x00014154c1c4:  488b4c2438            mov       rcx, qword ptr [rsp + 0x38]
0x00014154c1c9:  4885c9                test      rcx, rcx
0x00014154c1cc:  7406                  je        0x14154c1d4
0x00014154c1ce:  e83dcd27ff            call      0x1407c8f10
0x00014154c1d3:  90                    nop       
0x00014154c1d4:  48891f                mov       qword ptr [rdi], rbx
0x00014154c1d7:  488bc7                mov       rax, rdi
0x00014154c1da:  488b5c2470            mov       rbx, qword ptr [rsp + 0x70]
0x00014154c1df:  488b6c2478            mov       rbp, qword ptr [rsp + 0x78]
0x00014154c1e4:  488bb42480000000      mov       rsi, qword ptr [rsp + 0x80]
0x00014154c1ec:  4883c460              add       rsp, 0x60
0x00014154c1f0:  5f                    pop       rdi
0x00014154c1f1:  c3                    ret       
0x00014154c1f2:  488d4c2440            lea       rcx, [rsp + 0x40]
0x00014154c1f7:  e8f4eb26ff            call      0x1407badf0
0x00014154c1fc:  488d153daa7b06        lea       rdx, [rip + 0x67baa3d]
0x00014154c203:  488d4c2440            lea       rcx, [rsp + 0x40]
0x00014154c208:  e8436e5f04            call      0x145b43050
0x00014154c20d:  cc                    int3      
0x00014154c20e:  cc                    int3      
0x00014154c20f:  cc                    int3      
