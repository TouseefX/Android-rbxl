; RakPeer vtable slot 13
; rva 0x287e450
0x14287e450:  4057                 push      rdi
0x14287e452:  4154                 push      r12
0x14287e454:  4155                 push      r13
0x14287e456:  4157                 push      r15
0x14287e458:  4883ec78             sub       rsp, 0x78
0x14287e45c:  488b01               mov       rax, qword ptr [rcx]
0x14287e45f:  4c8be2               mov       r12, rdx
0x14287e462:  33d2                 xor       edx, edx
0x14287e464:  4d8bf9               mov       r15, r9
0x14287e467:  450fb7e8             movzx     r13d, r8w
0x14287e46b:  488bf9               mov       rdi, rcx
0x14287e46e:  488b80d0030000       mov       rax, qword ptr [rax + 0x3d0]
0x14287e475:  ff15bd188c03         call      qword ptr [rip + 0x38c18bd]
0x14287e47b:  4d85e4               test      r12, r12
0x14287e47e:  0f8442010000         je        0x14287e5c6
0x14287e484:  0fb68708010000       movzx     eax, byte ptr [rdi + 0x108]
0x14287e48b:  90                   nop       
0x14287e48c:  84c0                 test      al, al
0x14287e48e:  0f8532010000         jne       0x14287e5c6
0x14287e494:  8b8f08090000         mov       ecx, dword ptr [rdi + 0x908]
0x14287e49a:  8b9424d0000000       mov       edx, dword ptr [rsp + 0xd0]
0x14287e4a1:  3bd1                 cmp       edx, ecx
0x14287e4a3:  0f831d010000         jae       0x14287e5c6
0x14287e4a9:  48899c24a8000000     mov       qword ptr [rsp + 0xa8], rbx
0x14287e4b1:  4889ac24b0000000     mov       qword ptr [rsp + 0xb0], rbp
0x14287e4b9:  4889b424b8000000     mov       qword ptr [rsp + 0xb8], rsi
0x14287e4c1:  33f6                 xor       esi, esi
0x14287e4c3:  4c89742470           mov       qword ptr [rsp + 0x70], r14
0x14287e4c8:  8bde                 mov       ebx, esi
0x14287e4ca:  85c9                 test      ecx, ecx
0x14287e4cc:  7426                 je        0x14287e4f4
0x14287e4ce:  4c8b8700090000       mov       r8, qword ptr [rdi + 0x900]
0x14287e4d5:  6666660f1f840000000000 nop       word ptr [rax + rax]
0x14287e4e0:  8bc3                 mov       eax, ebx
0x14287e4e2:  4803c0               add       rax, rax
0x14287e4e5:  498b04c0             mov       rax, qword ptr [r8 + rax*8]
0x14287e4e9:  395008               cmp       dword ptr [rax + 8], edx
0x14287e4ec:  740b                 je        0x14287e4f9
0x14287e4ee:  ffc3                 inc       ebx
0x14287e4f0:  3bd9                 cmp       ebx, ecx
0x14287e4f2:  72ec                 jb        0x14287e4e0
0x14287e4f4:  bbffffffff           mov       ebx, 0xffffffff
0x14287e4f9:  488b0580c44e05       mov       rax, qword ptr [rip + 0x54ec480]
0x14287e500:  b9ff000000           mov       ecx, 0xff
0x14287e505:  398c24c0000000       cmp       dword ptr [rsp + 0xc0], ecx
0x14287e50c:  8bac24e0000000       mov       ebp, dword ptr [rsp + 0xe0]
0x14287e513:  0f4e8c24c0000000     cmovle    ecx, dword ptr [rsp + 0xc0]
0x14287e51b:  4d85ff               test      r15, r15
0x14287e51e:  448bb424d8000000     mov       r14d, dword ptr [rsp + 0xd8]
0x14287e526:  0f45f1               cmovne    esi, ecx
0x14287e529:  3c06                 cmp       al, 6
0x14287e52b:  7242                 jb        0x14287e56f
0x14287e52d:  48c1e808             shr       rax, 8
0x14287e531:  3c03                 cmp       al, 3
0x14287e533:  723a                 jb        0x14287e56f
0x14287e535:  488d0548b8d204       lea       rax, [rip + 0x4d2b848]
0x14287e53c:  448bcd               mov       r9d, ebp
0x14287e53f:  48898424a0000000     mov       qword ptr [rsp + 0xa0], rax
0x14287e547:  488d4c2460           lea       rcx, [rsp + 0x60]
0x14287e54c:  488b9424a0000000     mov       rdx, qword ptr [rsp + 0xa0]
0x14287e554:  458bc6               mov       r8d, r14d
0x14287e557:  0f100522c44e05       movups    xmm0, xmmword ptr [rip + 0x54ec422]
0x14287e55e:  488d158b9b6b04       lea       rdx, [rip + 0x46b9b8b]
0x14287e565:  0f29442460           movaps    xmmword ptr [rsp + 0x60], xmm0
0x14287e56a:  e821130e02           call      0x14495f890
0x14287e56f:  8b8424e8000000       mov       eax, dword ptr [rsp + 0xe8]
0x14287e576:  4d8bcf               mov       r9, r15
0x14287e579:  89442450             mov       dword ptr [rsp + 0x50], eax
0x14287e57d:  450fb7c5             movzx     r8d, r13w
0x14287e581:  896c2448             mov       dword ptr [rsp + 0x48], ebp
0x14287e585:  498bd4               mov       rdx, r12
0x14287e588:  4489742440           mov       dword ptr [rsp + 0x40], r14d
0x14287e58d:  488bcf               mov       rcx, rdi
0x14287e590:  895c2430             mov       dword ptr [rsp + 0x30], ebx
0x14287e594:  89742420             mov       dword ptr [rsp + 0x20], esi
0x14287e598:  e8b3670000           call      0x142884d50
0x14287e59d:  4c8b742470           mov       r14, qword ptr [rsp + 0x70]
0x14287e5a2:  488bb424b8000000     mov       rsi, qword ptr [rsp + 0xb8]
0x14287e5aa:  488bac24b0000000     mov       rbp, qword ptr [rsp + 0xb0]
0x14287e5b2:  488b9c24a8000000     mov       rbx, qword ptr [rsp + 0xa8]
0x14287e5ba:  4883c478             add       rsp, 0x78
0x14287e5be:  415f                 pop       r15
0x14287e5c0:  415d                 pop       r13
0x14287e5c2:  415c                 pop       r12
0x14287e5c4:  5f                   pop       rdi
0x14287e5c5:  c3                   ret       
0x14287e5c6:  b801000000           mov       eax, 1
0x14287e5cb:  4883c478             add       rsp, 0x78
0x14287e5cf:  415f                 pop       r15
0x14287e5d1:  415d                 pop       r13
0x14287e5d3:  415c                 pop       r12
0x14287e5d5:  5f                   pop       rdi
0x14287e5d6:  c3                   ret       
0x14287e5d7:  cc                   int3      
0x14287e5d8:  cc                   int3      
0x14287e5d9:  cc                   int3      
0x14287e5da:  cc                   int3      
0x14287e5db:  cc                   int3      
0x14287e5dc:  cc                   int3      
0x14287e5dd:  cc                   int3      
0x14287e5de:  cc                   int3      
0x14287e5df:  cc                   int3      
0x14287e5e0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x14287e5e5:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x14287e5ea:  57                   push      rdi
0x14287e5eb:  4883ec20             sub       rsp, 0x20
0x14287e5ef:  488bd9               mov       rbx, rcx
0x14287e5f2:  4881c1300c0000       add       rcx, 0xc30
0x14287e5f9:  e8b2512a03           call      0x145b237b0
0x14287e5fe:  85c0                 test      eax, eax
0x14287e600:  0f8546010000         jne       0x14287e74c
0x14287e606:  33ff                 xor       edi, edi
0x14287e608:  0f1f840000000000     nop       dword ptr [rax + rax]
0x14287e610:  8b93880c0000         mov       edx, dword ptr [rbx + 0xc88]
0x14287e616:  8b8b8c0c0000         mov       ecx, dword ptr [rbx + 0xc8c]
0x14287e61c:  3bd1                 cmp       edx, ecx
0x14287e61e:  7704                 ja        0x14287e624
0x14287e620:  2bca                 sub       ecx, edx
0x14287e622:  eb0a                 jmp       0x14287e62e
0x14287e624:  8b83900c0000         mov       eax, dword ptr [rbx + 0xc90]
0x14287e62a:  2bc2                 sub       eax, edx
0x14287e62c:  03c8                 add       ecx, eax
0x14287e62e:  3bf9                 cmp       edi, ecx
0x14287e630:  0f839a000000         jae       0x14287e6d0
0x14287e636:  803d0b8ea40500       cmp       byte ptr [rip + 0x5a48e0b], 0
0x14287e63d:  744f                 je        0x14287e68e
0x14287e63f:  448d0c3a             lea       r9d, [rdx + rdi]
0x14287e643:  448b83900c0000       mov       r8d, dword ptr [rbx + 0xc90]
0x14287e64a:  4c8b93800c0000       mov       r10, qword ptr [rbx + 0xc80]
0x14287e651:  8bca                 mov       ecx, edx
0x14287e653:  412bc8               sub       ecx, r8d
0x14287e656:  03cf                 add       ecx, edi
0x14287e658:  418bc1               mov       eax, r9d
0x14287e65b:  453bc8               cmp       r9d, r8d
0x14287e65e:  0f43c1               cmovae    eax, ecx
0x14287e661:  498b0cc2             mov       rcx, qword ptr [r10 + rax*8]
0x14287e665:  4883796000           cmp       qword ptr [rcx + 0x60], 0
0x14287e66a:  7422                 je        0x14287e68e
0x14287e66c:  e85f250200           call      0x1428a0bd0
0x14287e671:  8bca                 mov       ecx, edx
0x14287e673:  412bc8               sub       ecx, r8d
0x14287e676:  453bc8               cmp       r9d, r8d
0x14287e679:  0f42ca               cmovb     ecx, edx
0x14287e67c:  03cf                 add       ecx, edi
0x14287e67e:  498b14ca             mov       rdx, qword ptr [r10 + rcx*8]
0x14287e682:  488b5260             mov       rdx, qword ptr [rdx + 0x60]
0x14287e686:  488bc8               mov       rcx, rax
0x14287e689:  e8a2df2801           call      0x143b0c630
0x14287e68e:  488b03               mov       rax, qword ptr [rbx]
0x14287e691:  448b83880c0000       mov       r8d, dword ptr [rbx + 0xc88]
0x14287e698:  418d1438             lea       edx, [r8 + rdi]
0x14287e69c:  8b8b900c0000         mov       ecx, dword ptr [rbx + 0xc90]
0x14287e6a2:  4c8b8b800c0000       mov       r9, qword ptr [rbx + 0xc80]
0x14287e6a9:  442bc1               sub       r8d, ecx
0x14287e6ac:  4403c7               add       r8d, edi
0x14287e6af:  3bd1                 cmp       edx, ecx
0x14287e6b1:  410f43d0             cmovae    edx, r8d
0x14287e6b5:  498b14d1             mov       rdx, qword ptr [r9 + rdx*8]
0x14287e6b9:  488bcb               mov       rcx, rbx
0x14287e6bc:  488b80e8000000       mov       rax, qword ptr [rax + 0xe8]
0x14287e6c3:  ff156f168c03         call      qword ptr [rip + 0x38c166f]
0x14287e6c9:  ffc7                 inc       edi
0x14287e6cb:  e940ffffff           jmp       0x14287e610
0x14287e6d0:  8b83900c0000         mov       eax, dword ptr [rbx + 0xc90]
0x14287e6d6:  85c0                 test      eax, eax
0x14287e6d8:  7427                 je        0x14287e701
0x14287e6da:  83f820               cmp       eax, 0x20
0x14287e6dd:  7617                 jbe       0x14287e6f6
0x14287e6df:  488b8b800c0000       mov       rcx, qword ptr [rbx + 0xc80]
0x14287e6e6:  e8c5490c02           call      0x1449430b0
0x14287e6eb:  90                   nop       
0x14287e6ec:  c783900c000000000000 mov       dword ptr [rbx + 0xc90], 0
0x14287e6f6:  48c783880c000000000000 mov       qword ptr [rbx + 0xc88], 0
0x14287e701:  488d8b300c0000       lea       rcx, [rbx + 0xc30]
0x14287e708:  e803512a03           call      0x145b23810
0x14287e70d:  488d8bc00b0000       lea       rcx, [rbx + 0xbc0]
0x14287e714:  e897502a03           call      0x145b237b0
0x14287e719:  85c0                 test      eax, eax
0x14287e71b:  7527                 jne       0x14287e744
0x14287e71d:  488d8b100c0000       lea       rcx, [rbx + 0xc10]
0x14287e724:  e817310200           call      0x1428a1840
0x14287e729:  488d8bc00b0000       lea       rcx, [rbx + 0xbc0]
0x14287e730:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x14287e735:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x14287e73a:  4883c420             add       rsp, 0x20
0x14287e73e:  5f                   pop       rdi
0x14287e73f:  e9cc502a03           jmp       0x145b23810
0x14287e744:  8bc8                 mov       ecx, eax
0x14287e746:  e835562a03           call      0x145b23d80
0x14287e74b:  cc                   int3      
0x14287e74c:  8bc8                 mov       ecx, eax
0x14287e74e:  e82d562a03           call      0x145b23d80
0x14287e753:  cc                   int3      
0x14287e754:  cc                   int3      
0x14287e755:  cc                   int3      
0x14287e756:  cc                   int3      
0x14287e757:  cc                   int3      
0x14287e758:  cc                   int3      
0x14287e759:  cc                   int3      
0x14287e75a:  cc                   int3      
0x14287e75b:  cc                   int3      
0x14287e75c:  cc                   int3      
0x14287e75d:  cc                   int3      
0x14287e75e:  cc                   int3      
0x14287e75f:  cc                   int3      
