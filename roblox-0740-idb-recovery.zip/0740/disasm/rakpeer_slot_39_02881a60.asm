; RakPeer vtable slot 39
; rva 0x2881a60
0x142881a60:  48895c2418           mov       qword ptr [rsp + 0x18], rbx
0x142881a65:  56                   push      rsi
0x142881a66:  4883ec20             sub       rsp, 0x20
0x142881a6a:  4883b90805000000     cmp       qword ptr [rcx + 0x508], 0
0x142881a72:  488bf2               mov       rsi, rdx
0x142881a75:  488bd9               mov       rbx, rcx
0x142881a78:  750d                 jne       0x142881a87
0x142881a7a:  32c0                 xor       al, al
0x142881a7c:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x142881a81:  4883c420             add       rsp, 0x20
0x142881a85:  5e                   pop       rsi
0x142881a86:  c3                   ret       
0x142881a87:  4881c1a8040000       add       rcx, 0x4a8
0x142881a8e:  48897c2438           mov       qword ptr [rsp + 0x38], rdi
0x142881a93:  e8181d2a03           call      0x145b237b0
0x142881a98:  85c0                 test      eax, eax
0x142881a9a:  753f                 jne       0x142881adb
0x142881a9c:  488d8bf8040000       lea       rcx, [rbx + 0x4f8]
0x142881aa3:  4c8bc6               mov       r8, rsi
0x142881aa6:  488d542430           lea       rdx, [rsp + 0x30]
0x142881aab:  e810130200           call      0x1428a2dc0
0x142881ab0:  488d8ba8040000       lea       rcx, [rbx + 0x4a8]
0x142881ab7:  e8541d2a03           call      0x145b23810
0x142881abc:  488b8300050000       mov       rax, qword ptr [rbx + 0x500]
0x142881ac3:  4839442430           cmp       qword ptr [rsp + 0x30], rax
0x142881ac8:  488b7c2438           mov       rdi, qword ptr [rsp + 0x38]
0x142881acd:  488b5c2440           mov       rbx, qword ptr [rsp + 0x40]
0x142881ad2:  0f95c0               setne     al
0x142881ad5:  4883c420             add       rsp, 0x20
0x142881ad9:  5e                   pop       rsi
0x142881ada:  c3                   ret       
0x142881adb:  8bc8                 mov       ecx, eax
0x142881add:  e89e222a03           call      0x145b23d80
0x142881ae2:  cc                   int3      
0x142881ae3:  cc                   int3      
0x142881ae4:  cc                   int3      
0x142881ae5:  cc                   int3      
0x142881ae6:  cc                   int3      
0x142881ae7:  cc                   int3      
0x142881ae8:  cc                   int3      
0x142881ae9:  cc                   int3      
0x142881aea:  cc                   int3      
0x142881aeb:  cc                   int3      
0x142881aec:  cc                   int3      
0x142881aed:  cc                   int3      
0x142881aee:  cc                   int3      
0x142881aef:  cc                   int3      
