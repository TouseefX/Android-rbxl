; RakPeer vtable slot 43
; rva 0x2881f00
0x142881f00:  8b813c100000         mov       eax, dword ptr [rcx + 0x103c]
0x142881f06:  90                   nop       
0x142881f07:  8902                 mov       dword ptr [rdx], eax
0x142881f09:  c3                   ret       
0x142881f0a:  cc                   int3      
0x142881f0b:  cc                   int3      
0x142881f0c:  cc                   int3      
0x142881f0d:  cc                   int3      
0x142881f0e:  cc                   int3      
0x142881f0f:  cc                   int3      
