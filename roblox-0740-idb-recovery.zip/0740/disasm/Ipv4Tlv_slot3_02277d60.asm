; Ipv4Tlv vtable slot 3 rva 0x2277d60
0x142277d60:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x142277d65:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x142277d6a:  57                   push      rdi
0x142277d6b:  4883ec20             sub       rsp, 0x20
0x142277d6f:  488b01               mov       rax, qword ptr [rcx]
0x142277d72:  498bd8               mov       rbx, r8
0x142277d75:  488bfa               mov       rdi, rdx
0x142277d78:  488bf1               mov       rsi, rcx
0x142277d7b:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x142277d7f:  ff15b37fec03         call      qword ptr [rip + 0x3ec7fb3]
0x142277d85:  0fb6c0               movzx     eax, al
0x142277d88:  483b4308             cmp       rax, qword ptr [rbx + 8]
0x142277d8c:  7621                 jbe       0x142277daf
0x142277d8e:  c7070b000000         mov       dword ptr [rdi], 0xb
0x142277d94:  488bc7               mov       rax, rdi
0x142277d97:  48c7470800000000     mov       qword ptr [rdi + 8], 0
0x142277d9f:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142277da4:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142277da9:  4883c420             add       rsp, 0x20
0x142277dad:  5f                   pop       rdi
0x142277dae:  c3                   ret       
0x142277daf:  8b4608               mov       eax, dword ptr [rsi + 8]
0x142277db2:  488b1b               mov       rbx, qword ptr [rbx]
0x142277db5:  8903                 mov       dword ptr [rbx], eax
0x142277db7:  0fb74e0c             movzx     ecx, word ptr [rsi + 0xc]
0x142277dbb:  ff15777aec03         call      qword ptr [rip + 0x3ec7a77]
0x142277dc1:  488bce               mov       rcx, rsi
0x142277dc4:  c70700000000         mov       dword ptr [rdi], 0
0x142277dca:  66894304             mov       word ptr [rbx + 4], ax
0x142277dce:  488b06               mov       rax, qword ptr [rsi]
0x142277dd1:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x142277dd5:  ff155d7fec03         call      qword ptr [rip + 0x3ec7f5d]
0x142277ddb:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142277de0:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142277de5:  0fb6c0               movzx     eax, al
0x142277de8:  48894708             mov       qword ptr [rdi + 8], rax
0x142277dec:  488bc7               mov       rax, rdi
0x142277def:  4883c420             add       rsp, 0x20
0x142277df3:  5f                   pop       rdi
0x142277df4:  c3                   ret       
0x142277df5:  cc                   int3      
0x142277df6:  cc                   int3      
0x142277df7:  cc                   int3      
0x142277df8:  cc                   int3      
0x142277df9:  cc                   int3      
0x142277dfa:  cc                   int3      
0x142277dfb:  cc                   int3      
0x142277dfc:  cc                   int3      
0x142277dfd:  cc                   int3      
0x142277dfe:  cc                   int3      
0x142277dff:  cc                   int3      
0x142277e00:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x142277e05:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x142277e0a:  57                   push      rdi
0x142277e0b:  4883ec20             sub       rsp, 0x20
0x142277e0f:  488b01               mov       rax, qword ptr [rcx]
0x142277e12:  498bd8               mov       rbx, r8
0x142277e15:  488bfa               mov       rdi, rdx
0x142277e18:  488bf1               mov       rsi, rcx
0x142277e1b:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x142277e1f:  ff15137fec03         call      qword ptr [rip + 0x3ec7f13]
0x142277e25:  0fb6c0               movzx     eax, al
0x142277e28:  483b4308             cmp       rax, qword ptr [rbx + 8]
0x142277e2c:  7621                 jbe       0x142277e4f
0x142277e2e:  c7070b000000         mov       dword ptr [rdi], 0xb
0x142277e34:  488bc7               mov       rax, rdi
0x142277e37:  48c7470800000000     mov       qword ptr [rdi + 8], 0
0x142277e3f:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142277e44:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142277e49:  4883c420             add       rsp, 0x20
0x142277e4d:  5f                   pop       rdi
0x142277e4e:  c3                   ret       
0x142277e4f:  0f104608             movups    xmm0, xmmword ptr [rsi + 8]
0x142277e53:  488b1b               mov       rbx, qword ptr [rbx]
0x142277e56:  0f1103               movups    xmmword ptr [rbx], xmm0
0x142277e59:  0fb74e18             movzx     ecx, word ptr [rsi + 0x18]
0x142277e5d:  ff15d579ec03         call      qword ptr [rip + 0x3ec79d5]
0x142277e63:  488bce               mov       rcx, rsi
0x142277e66:  c70700000000         mov       dword ptr [rdi], 0
0x142277e6c:  66894310             mov       word ptr [rbx + 0x10], ax
0x142277e70:  488b06               mov       rax, qword ptr [rsi]
0x142277e73:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x142277e77:  ff15bb7eec03         call      qword ptr [rip + 0x3ec7ebb]
0x142277e7d:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142277e82:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142277e87:  0fb6c0               movzx     eax, al
0x142277e8a:  48894708             mov       qword ptr [rdi + 8], rax
0x142277e8e:  488bc7               mov       rax, rdi
0x142277e91:  4883c420             add       rsp, 0x20
0x142277e95:  5f                   pop       rdi
0x142277e96:  c3                   ret       
0x142277e97:  cc                   int3      
0x142277e98:  cc                   int3      
0x142277e99:  cc                   int3      
0x142277e9a:  cc                   int3      
0x142277e9b:  cc                   int3      
0x142277e9c:  cc                   int3      
0x142277e9d:  cc                   int3      
0x142277e9e:  cc                   int3      
0x142277e9f:  cc                   int3      
0x142277ea0:  4983780810           cmp       qword ptr [r8 + 8], 0x10
0x142277ea5:  0f57c0               xorps     xmm0, xmm0
0x142277ea8:  c60101               mov       byte ptr [rcx], 1
0x142277eab:  0f114101             movups    xmmword ptr [rcx + 1], xmm0
0x142277eaf:  750a                 jne       0x142277ebb
0x142277eb1:  498b00               mov       rax, qword ptr [r8]
0x142277eb4:  0f1000               movups    xmm0, xmmword ptr [rax]
0x142277eb7:  0f114101             movups    xmmword ptr [rcx + 1], xmm0
0x142277ebb:  488bc1               mov       rax, rcx
0x142277ebe:  c3                   ret       
0x142277ebf:  cc                   int3      
0x142277ec0:  b011                 mov       al, 0x11
0x142277ec2:  c3                   ret       
0x142277ec3:  cc                   int3      
0x142277ec4:  cc                   int3      
0x142277ec5:  cc                   int3      
0x142277ec6:  cc                   int3      
0x142277ec7:  cc                   int3      
0x142277ec8:  cc                   int3      
0x142277ec9:  cc                   int3      
0x142277eca:  cc                   int3      
0x142277ecb:  cc                   int3      
0x142277ecc:  cc                   int3      
0x142277ecd:  cc                   int3      
0x142277ece:  cc                   int3      
0x142277ecf:  cc                   int3      
0x142277ed0:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x142277ed5:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x142277eda:  57                   push      rdi
0x142277edb:  4883ec20             sub       rsp, 0x20
0x142277edf:  488b01               mov       rax, qword ptr [rcx]
0x142277ee2:  498bf0               mov       rsi, r8
0x142277ee5:  488bda               mov       rbx, rdx
0x142277ee8:  488bf9               mov       rdi, rcx
0x142277eeb:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x142277eef:  ff15437eec03         call      qword ptr [rip + 0x3ec7e43]
0x142277ef5:  0fb6c0               movzx     eax, al
0x142277ef8:  483b4608             cmp       rax, qword ptr [rsi + 8]
0x142277efc:  7621                 jbe       0x142277f1f
0x142277efe:  c7030b000000         mov       dword ptr [rbx], 0xb
0x142277f04:  488bc3               mov       rax, rbx
0x142277f07:  48c7430800000000     mov       qword ptr [rbx + 8], 0
0x142277f0f:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142277f14:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142277f19:  4883c420             add       rsp, 0x20
0x142277f1d:  5f                   pop       rdi
0x142277f1e:  c3                   ret       
0x142277f1f:  0fb64708             movzx     eax, byte ptr [rdi + 8]
0x142277f23:  488b0e               mov       rcx, qword ptr [rsi]
0x142277f26:  c70300000000         mov       dword ptr [rbx], 0
0x142277f2c:  8801                 mov       byte ptr [rcx], al
0x142277f2e:  0f104709             movups    xmm0, xmmword ptr [rdi + 9]
0x142277f32:  0f114101             movups    xmmword ptr [rcx + 1], xmm0
0x142277f36:  488b07               mov       rax, qword ptr [rdi]
0x142277f39:  488bcf               mov       rcx, rdi
0x142277f3c:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x142277f40:  ff15f27dec03         call      qword ptr [rip + 0x3ec7df2]
0x142277f46:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142277f4b:  0fb6c0               movzx     eax, al
0x142277f4e:  48894308             mov       qword ptr [rbx + 8], rax
0x142277f52:  488bc3               mov       rax, rbx
0x142277f55:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142277f5a:  4883c420             add       rsp, 0x20
0x142277f5e:  5f                   pop       rdi
0x142277f5f:  c3                   ret       
0x142277f60:  48895c2408           mov       qword ptr [rsp + 8], rbx
0x142277f65:  4889742410           mov       qword ptr [rsp + 0x10], rsi
0x142277f6a:  57                   push      rdi
0x142277f6b:  4883ec20             sub       rsp, 0x20
0x142277f6f:  488b01               mov       rax, qword ptr [rcx]
0x142277f72:  498bf0               mov       rsi, r8
0x142277f75:  488bda               mov       rbx, rdx
0x142277f78:  488bf9               mov       rdi, rcx
0x142277f7b:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x142277f7f:  ff15b37dec03         call      qword ptr [rip + 0x3ec7db3]
0x142277f85:  0fb6c0               movzx     eax, al
0x142277f88:  483b4608             cmp       rax, qword ptr [rsi + 8]
0x142277f8c:  7621                 jbe       0x142277faf
0x142277f8e:  c7030b000000         mov       dword ptr [rbx], 0xb
0x142277f94:  488bc3               mov       rax, rbx
0x142277f97:  48c7430800000000     mov       qword ptr [rbx + 8], 0
0x142277f9f:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142277fa4:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142277fa9:  4883c420             add       rsp, 0x20
0x142277fad:  5f                   pop       rdi
0x142277fae:  c3                   ret       
0x142277faf:  488b06               mov       rax, qword ptr [rsi]
0x142277fb2:  488bcf               mov       rcx, rdi
0x142277fb5:  0f104708             movups    xmm0, xmmword ptr [rdi + 8]
0x142277fb9:  c70300000000         mov       dword ptr [rbx], 0
0x142277fbf:  0f1100               movups    xmmword ptr [rax], xmm0
0x142277fc2:  488b07               mov       rax, qword ptr [rdi]
0x142277fc5:  488b4010             mov       rax, qword ptr [rax + 0x10]
0x142277fc9:  ff15697dec03         call      qword ptr [rip + 0x3ec7d69]
0x142277fcf:  488b742438           mov       rsi, qword ptr [rsp + 0x38]
0x142277fd4:  0fb6c0               movzx     eax, al
0x142277fd7:  48894308             mov       qword ptr [rbx + 8], rax
0x142277fdb:  488bc3               mov       rax, rbx
0x142277fde:  488b5c2430           mov       rbx, qword ptr [rsp + 0x30]
0x142277fe3:  4883c420             add       rsp, 0x20
0x142277fe7:  5f                   pop       rdi
0x142277fe8:  c3                   ret       
0x142277fe9:  cc                   int3      
0x142277fea:  cc                   int3      
0x142277feb:  cc                   int3      
0x142277fec:  cc                   int3      
0x142277fed:  cc                   int3      
0x142277fee:  cc                   int3      
0x142277fef:  cc                   int3      
0x142277ff0:  4883ec38             sub       rsp, 0x38
0x142277ff4:  488b0d9d3e7306       mov       rcx, qword ptr [rip + 0x6733e9d]
0x142277ffb:  4c8d05ee7fae05       lea       r8, [rip + 0x5ae7fee]
0x142278002:  41b901000000         mov       r9d, 1
0x142278008:  488d155930c904       lea       rdx, [rip + 0x4c93059]
0x14227800f:  e8fc367002           call      0x14497b710
0x142278014:  4883c438             add       rsp, 0x38
0x142278018:  c3                   ret       
0x142278019:  cc                   int3      
0x14227801a:  cc                   int3      
0x14227801b:  cc                   int3      
0x14227801c:  cc                   int3      
0x14227801d:  cc                   int3      
0x14227801e:  cc                   int3      
0x14227801f:  cc                   int3      
0x142278020:  4883ec38             sub       rsp, 0x38
0x142278024:  488b0d6d3e7306       mov       rcx, qword ptr [rip + 0x6733e6d]
0x14227802b:  4c8d05fe7fae05       lea       r8, [rip + 0x5ae7ffe]
0x142278032:  41b902000000         mov       r9d, 2
0x142278038:  488d153930c904       lea       rdx, [rip + 0x4c93039]
0x14227803f:  e89c317002           call      0x14497b1e0
0x142278044:  4883c438             add       rsp, 0x38
0x142278048:  c3                   ret       
0x142278049:  cc                   int3      
0x14227804a:  cc                   int3      
0x14227804b:  cc                   int3      
0x14227804c:  cc                   int3      
0x14227804d:  cc                   int3      
0x14227804e:  cc                   int3      
0x14227804f:  cc                   int3      
