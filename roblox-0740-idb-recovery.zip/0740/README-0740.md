# Roblox 0.740 IDB recovery — parsed artifacts

Source: `kingdudely/Roblox-RakNet-Decompilation-Project/releases/download/dumpedRobloxI64/dump.zip`
→ `rebased_decrypted_2366ba214ec740ca.exe.i64` (2.15 GB, IDA2 database, IDA-9-era container).

## What this build actually is

- **64-bit Windows (MSVC/COFF) build, image base `0x140000000`.** NOT the iOS/arm64 build analyzed for
  0.735. Evidence: `??_7…@@6B@` MSVC-mangled vtables, `??_R0..??_R4` MSVC RTTI records,
  `std::_Ref_count_obj2<>` STL internals in the symbol table, PE rebased layout, and x86-64 machine code
  (RIP-relative addressing, `int3` padding, `int 0x29` fast-fail guards).
- The "rebased_decrypted" name refers to the packed user-mode EXE dump; ID1 section stores each address
  as a u32 flag word whose **low byte is the byte value** (standard IDA ≥7 layout), segments are stored
  relative to the image base (RVA).

## How it was parsed (python-idb could not be used)

The environment has ~1.4 GB RAM and no swap; python-idb materializes the whole 2.15 GB database
(immediate OOM) and additionally does not understand the IDA-9-era header (version u16 @0x1E = 910,
no v6 `{comp,len}` section headers). Instead the file was parsed structurally:

1. Container scanned for content magics:
   - `B-tree v2` signature at file 0x100 → **id0 B-tree @ 0xED** (page_size 0x2000, root_page 0x2331D,
     38,444,985 records, 180,969 pages).
   - `VA*\0` at 0x5EACE0ED → **id1** (13 segments, 0x10996 pages), at 0x7FDFA0ED → **nam**.
2. Custom zero-copy B+-tree walker (DFS leaf order, prefix-compressed keys) over the id0 section
   (46 seconds for all 38.27 M records). Symbol records decode as
   `key = 'N' + MSVC-mangled-name, value = LE u64 RVA+0x140000000`.
   → **285,694 recovered symbols** (`symbols-all.txt`).
3. ID1 flags array (numpy, vectorized) → **145,391 function-start addresses** (`function-starts.txt`)
   where `flags & 0xF0000000 == 0x10000000` (FF_FUNC) inside segment1 (.text, RVA 0x1000..0x613C800,
   101,475,840 bytes).
4. rel32/x86-64 RIP-relative xref scanner (4-phase chunked numpy) over .text for targeted RVAs
   (vtable + string xrefs in `xrefs.tsv`, 43 precise hits).
5. Per-function disasm via capstone (x86-64) using ea→flags→byte extraction (`disasm/`, 147 files).

## The RUPP stack — fully present with full RTTI (0.740)

Namespace `RBX::Rupp::` intact in symbols: `ClientRuppGenerator`, `ServerRuppGenerator`,
`RuppTokenProcessor`, `TokenTlv`, `Ipv4Tlv`, `Ipv6Tlv`, `Ipv4ReverseEndpointTlv`, `TraceIdTlv`,
`TypeLengthValue`, `RuppGeneratorInterface` — plus two
`std::_Func_impl_no_alloc<lambda_…, void(TokenTlv::Token&)>` wrappers (token deserialization dispatch
lambdas) and `std::_Ref_count_obj2<RBX::Rupp>` / `_Ref_count_obj_alloc3<…>` (Rupp object held in a
ref-counted shared_ptr).

Decoded vtables (image RVA slots; full disasm per slot in `disasm/`):

| class | vftable EA | slots |
|---|---|---|
| RakNet::RakPeer | 0x146CA34F0 | 80 (disasm/rakpeer_slot_*.asm) |
| RBX::Rupp::ClientRuppGenerator | 0x146C98840 | dtor 0x2271F70, stub 0x7CA2A0, getter 0xC312F0 (ret this+0x60), **token-processor 0x2271FC0** |
| RBX::Rupp::ServerRuppGenerator | 0x146C988C8 | dtor 0x2276380, 0x2276400, 0x2276450, 0x88F8E0 |
| RBX::Rupp::RuppTokenProcessor | 0x146C989B8 | dtor 0x2278050, pure-virtuals → cxa_pure 0x81C7A0 |
| RBX::Rupp::TokenTlv | 0x146C988F0 | dtor 0x7C9520, pure 0x81C7A0, getType→**0x11** at 0x2277EC0, loader 0x2277ED0 |
| TraceIdTlv / Ipv4Tlv / Ipv6Tlv / Ipv4ReverseEndpointTlv | 0x146C98918 / …0x146C98990 / …0x146C98968 / …40 | see disasm/rupp_family_vtables.txt |

Client-side token processor entry (`ClientRuppGenerator` slot 3 @ RVA 0x2271FC0) reads
`[rdx+4]` = TLvType byte (0 → return 9, requires 2 = Token), then copies 16 bytes `xmm0 ← [rdx+8]`
— mirrors the 0.735 `onPeerPacketReceived` token pipeline.

## Rupp pipeline functions located via DFLog-string xrefs (owning function = .text fn)

| string (in image .rdata) | owning function EA |
|---|---|
| "[DFLog::Rupp] Client opted in to receiving Rupp headers. Sending reply with Rupp header." + "… did not opt in … Omitting Rupp header." | **0x142897340** — Rupp header writer (reply serializer) |
| "[DFLog::Rupp] Offline reverse ruppLength: {}. Endpoint: {} \| {}" | 0x14289E210 — offline reverse-header builder |
| "[DFLog::Rupp] Offline ruppLength: {}" | 0x14289FC80 |
| "[DFLog::RuppTokenClientLog2] Generating new Rupp token." | 0x142275400 (small wrapper) |
| "[DFLog::RuppTokenClientLog2] Updating Rupp token in header." | **0x142275C70** — client token update (constructs RuppTokenProcessor + ServerRuppGenerator + lambda.5653) |
| "ClientRuppDeserializationError" label | **0x143327AF0 — the updateTokenFromDeserializationResult family** (2,689-insn function; calls TLV-decode helpers 0x14331F1C0/…AC0/…1350/…1400) |
| "[DFLog::Rupp] ruppEnabled is {}" + "Client failed Rupp setup: {}" | **0x14485FB50 — setupRuppImpl region** |
| "RakPeer::setServerMachineAddress" + "RakPeer::setServerRuppStemma %s" | 0x14289DFA0 (+ 0x1443542F0 second setServerMachineAddress site) |
| getaddrinfo RUPP diagnostics | 0x1428A58C0 (proxy/endpoint resolution) |
| ClientRuppGenerator ctor (vtab stored) | 0x142147660 |
| RakPeer ctors (vtab stored) | 0x14287A8C0, 0x14287BC10 |
| not yet located (no direct xref): "OpenRequest2 received with reverse endpoint" (0x146F39790), "startOfflineBitStreamReverse serialization failed." (0x146F39F20) | — strings exist; xref likely via TLS/format tables, not plain lea |

## Crypto in 0.740 — measured, not guessed

- **SHA-256 round-constant table present** in .rdata at image RVA 0x62DC500 (first 4 K-values verified,
  LE `982f8a42 91443771 cffbc0b5 a5dbb5e9`), loaded from code at .text RVA 0x54295/0x55873/0x567C3/0x57778
  (4 small wrappers **with no direct E8 callers** — invoked indirectly).
- **SHA-512 K table NOT present** (header signature search negative); no `SHA256_Init/Final`,
  `EVP_sha256` symbol strings (OpenSSL is statically linked but its names are stripped differently).
- **libsodium still present**: `[FLog::Error] Unable to initialize libsodium` string in .rdata;
  class `RBX::DigitalSignature::VerifierSodium` vtable + RTTI at 0x146DDFD30 (digsig, used by
  Lua/script signature verification — not RUPP).
- OpenSSL EVP AES-NI machinery + BLAKE2b512/BLAKE2s256/SipHash/Poly1305/ARIA OID name tables = static
  OpenSSL used by **`ChatJanitorToText`/`encoding`/TLS services**, positioned around the
  "Unable to initialize libsodium" FLog line in service-name context.
- **In the recovered RUPP headline functions there are NO references** to the SHA-256 K-table code,
  no AES-GCM (`pclmulqdq`) and no `rdrand/rdseed` instructions anywhere in disasm/ (147 files settled).
  ⇒ **User claim "crypto changed from libsodium to SHA-2 in 0.740" is NOT supported for the RUPP
  pipeline in this build.** SHA-2 code exists in the image but nothing in the RUPP token/TLV path
  references it in the recovered set. libsodium-init failure logging also remains.

## Files in this deliverable

- `symbols-all.txt` — 285,694 `0xEA\t<msvc-mangled-name>` (full recovered symbol table).
- `symbols-network-vtables-rtti.txt` — 97 RakNet/Rupp/related vftable + RTTI symbols.
- `function-starts.txt` — 145,391 .text function-start EAs (FF_FUNC).
- `xrefs.tsv` — 43 precise string/vftable xref sites (`site_EA, target_EA, label`).
- `disasm/` — 147 annotated disasm files:
  - `fn_0x*.asm` — 20 functions owning the DFLog/vftable xref sites (headers say which).
  - `rakpeer_slot_NN_*.asm` — all 80 RakPeer vtable slots.
  - `{Client,Server}RuppGenerator`, `RuppTokenProcessor`, `TokenTlv`, `TraceIdTlv`, `Ipv4[6]{,ReverseEndpoint}Tlv`,
    `lambda5653`, `lambdaBaa9` — slot disasms + `rakpeer_vtable.txt`, `rupp_family_vtables.txt`.
- `README-0740.md` — this file.

## Known limitations / next steps

- RakPeer vtable has 80 slots vs 87 virtuals in upstream RakNet 4.x `RakPeerInterface` — Roblox's fork
  diverges; per-slot names require mapping via RakNet source alignment (slot disasm provided).
- Non-virtual internals (`setupRuppImpl`, `sendDatagrams`, `ProcessNetworkPacket`) are module-statics:
  not in any vtable; reachable via call-graph analysis from the identified entry functions.
- `OpenRequest2 received with reverse endpoint` / `startOfflineBitStreamReverse` strings have no plain
  lea-references — likely reached via `fmt::` argument packs or jump tables; indirect-xref pass pending.
- Everything here is the **Windows desktop build**; the 0.735 evidence remains the authoritative source
  for iOS/arm64 addresses. RUPP architecture is the same on both (same class tree, same TLV set,
  same offline/reply flows), but every address differs.
