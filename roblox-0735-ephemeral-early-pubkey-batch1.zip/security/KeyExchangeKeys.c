// KeyExchangeKeys -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 4 functions


// Address: 0x1039e9c76 | Name: __ZN3RBX8Security13SessionCrypto15KeyExchangeKeysC2Ev
__int64 __fastcall RBX::Security::SessionCrypto::KeyExchangeKeys::KeyExchangeKeys(
        RBX::Security::SessionCrypto::KeyExchangeKeys *this)
{
  sodium_memzero(a1: this, a2: 32); /*0x1039e9c84*/
  sodium_memzero(a1: (char *)this + 32, a2: 32); /*0x1039e9c92*/
  sodium_memzero(a1: (char *)this + 64, a2: 32); /*0x1039e9ca0*/
  sodium_memzero(a1: (char *)this + 96, a2: 32); /*0x1039e9cae*/
  sodium_memzero(a1: (char *)this + 128, a2: 32); /*0x1039e9cbf*/
  sodium_memzero(a1: (char *)this + 160, a2: 32); /*0x1039e9cd0*/
  sodium_memzero(a1: (char *)this + 192, a2: 32); /*0x1039e9ce1*/
  return sodium_memzero(a1: (char *)this + 224, a2: 32); /*0x1039e9cf9*/
}

// Address: 0x1039e9d00 | Name: __ZN3RBX8Security13SessionCrypto15KeyExchangeKeysC1Ev
__int64 __fastcall RBX::Security::SessionCrypto::KeyExchangeKeys::KeyExchangeKeys(
        RBX::Security::SessionCrypto::KeyExchangeKeys *this)
{
  return RBX::Security::SessionCrypto::KeyExchangeKeys::KeyExchangeKeys(this); /*0x1039e9d04*/
}

// Address: 0x1039e9d0a | Name: __ZN3RBX8Security13SessionCrypto15KeyExchangeKeysD2Ev
void __fastcall RBX::Security::SessionCrypto::KeyExchangeKeys::~KeyExchangeKeys(
        RBX::Security::SessionCrypto::KeyExchangeKeys *this)
{
  sodium_memzero(a1: (char *)this + 32, a2: 32); /*0x1039e9d1c*/
  sodium_memzero(a1: (char *)this + 64, a2: 32); /*0x1039e9d2a*/
  sodium_memzero(a1: (char *)this + 96, a2: 32); /*0x1039e9d38*/
  sodium_memzero(a1: (char *)this + 128, a2: 32); /*0x1039e9d49*/
  sodium_memzero(a1: (char *)this + 160, a2: 32); /*0x1039e9d5a*/
  sodium_memzero(a1: (char *)this + 192, a2: 32); /*0x1039e9d6b*/
  sodium_memzero(a1: (char *)this + 224, a2: 32); /*0x1039e9d7f*/
}

// Address: 0x1039e9d94 | Name: __ZN3RBX8Security13SessionCrypto15KeyExchangeKeysD1Ev
void __fastcall RBX::Security::SessionCrypto::KeyExchangeKeys::~KeyExchangeKeys(
        RBX::Security::SessionCrypto::KeyExchangeKeys *this)
{
  RBX::Security::SessionCrypto::KeyExchangeKeys::~KeyExchangeKeys(this); /*0x1039e9d99*/
}

// END KeyExchangeKeys part 1/1, 4 functions
