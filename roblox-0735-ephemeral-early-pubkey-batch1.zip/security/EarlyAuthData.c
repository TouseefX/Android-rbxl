// EarlyAuthData -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 1 functions


// Address: 0x10687edb0 | Name: __ZN3RBX8Security13EarlyAuthDataD1Ev
void __fastcall RBX::Security::EarlyAuthData::~EarlyAuthData(void **this)
{
  if ( (*(_BYTE *)(this + 3) & 1) != 0 ) /*0x10687edbd*/
    operator delete(a1: *(this + 5)); /*0x10687edc3*/
  if ( (*(_BYTE *)this & 1) != 0 ) /*0x10687edcb*/
    operator delete(a1: *(this + 2)); /*0x10687edde*/
}

// END EarlyAuthData part 1/1, 1 functions
