// QuicSessionCrypto -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 3 functions


// Address: 0x106d5e802 | Name: __ZN3RBX8Security17QuicSessionCrypto6createERKNSt3__15arrayIhLm32EEES6_b
__int64 *__fastcall RBX::Security::QuicSessionCrypto::create(__int64 *a1, _OWORD *a2, _OWORD *a3, char a4)
{
  __int64 v8; // rax
  __int128 v9; // xmm1
  __int128 v10; // xmm1
  _BYTE v12[33]; // [rsp+Fh] [rbp-21h] BYREF

  RBX::make_shared<RBX::Security::QuicSessionCrypto,RBX::Security::QuicSessionCrypto::PrivateTag>(a1, a2: v12); /*0x106d5e820*/
  v8 = *a1; /*0x106d5e825*/
  *(_BYTE *)(v8 + 40) = a4; /*0x106d5e829*/
  v9 = a2[1]; /*0x106d5e830*/
  *(_OWORD *)(v8 + 64) = *a2; /*0x106d5e835*/
  *(_OWORD *)(v8 + 80) = v9; /*0x106d5e839*/
  v10 = a3[1]; /*0x106d5e841*/
  *(_OWORD *)(v8 + 96) = *a3; /*0x106d5e846*/
  *(_OWORD *)(v8 + 112) = v10; /*0x106d5e84a*/
  *(_BYTE *)(v8 + 42) = 1; /*0x106d5e850*/
  *(_BYTE *)(v8 + 45) = 1; /*0x106d5e853*/
  return a1; /*0x106d5e859*/
}

// Address: 0x106d5ea06 | Name: __ZN3RBX8Security17QuicSessionCryptoD1Ev
void __fastcall RBX::Security::QuicSessionCrypto::~QuicSessionCrypto(RBX::Security::QuicSessionCrypto *this)
{
  *(_QWORD *)this = off_10C9030B8; /*0x106d5ea16*/
  std::shared_ptr<RBX::Security::EarlyAuthData>::~shared_ptr[abi:ne200100](a1: (char *)this + 48); /*0x106d5ea1d*/
  std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>::reset[abi:ne200100](a1: (char *)this + 32, a2: 0); /*0x106d5ea31*/
}

// Address: 0x106d5ea36 | Name: __ZN3RBX8Security17QuicSessionCryptoD0Ev
void __fastcall RBX::Security::QuicSessionCrypto::~QuicSessionCrypto(RBX::Security::QuicSessionCrypto *this)
{
  *(_QWORD *)this = off_10C9030B8; /*0x106d5ea46*/
  std::shared_ptr<RBX::Security::EarlyAuthData>::~shared_ptr[abi:ne200100](a1: (char *)this + 48); /*0x106d5ea4d*/
  std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>::reset[abi:ne200100](a1: (char *)this + 32, a2: 0); /*0x106d5ea58*/
  operator delete(a1: this); /*0x106d5ea66*/
}

// END QuicSessionCrypto part 1/1, 3 functions
