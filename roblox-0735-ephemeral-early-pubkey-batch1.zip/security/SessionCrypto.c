// SessionCrypto -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 37 functions


// Address: 0x1039d136c | Name: __ZN3RBX8Security13SessionCryptoD1Ev
void __fastcall RBX::Security::SessionCrypto::~SessionCrypto(RBX::Security::SessionCrypto *this)
{
  *(_QWORD *)this = off_10C9030B8; /*0x1039d137c*/
  std::shared_ptr<RBX::Security::EarlyAuthData>::~shared_ptr[abi:ne200100](a1: (char *)this + 48); /*0x1039d1383*/
  std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>::reset[abi:ne200100](a1: (char *)this + 32, a2: 0); /*0x1039d1397*/
}

// Address: 0x1039d139c | Name: __ZN3RBX8Security13SessionCryptoD0Ev
void __fastcall RBX::Security::SessionCrypto::~SessionCrypto(RBX::Security::SessionCrypto *this)
{
  *(_QWORD *)this = off_10C9030B8; /*0x1039d13ac*/
  std::shared_ptr<RBX::Security::EarlyAuthData>::~shared_ptr[abi:ne200100](a1: (char *)this + 48); /*0x1039d13b3*/
  std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>::reset[abi:ne200100](a1: (char *)this + 32, a2: 0); /*0x1039d13be*/
  operator delete(a1: this); /*0x1039d13cc*/
}

// Address: 0x1039e9c70 | Name: __ZN3RBX8Security13SessionCrypto14static_assertsEv
void __fastcall RBX::Security::SessionCrypto::static_asserts(RBX::Security::SessionCrypto *this)
{
  ; /*0x1039e9c70*/
}

// Address: 0x1039e9d9e | Name: __ZN3RBX8Security13SessionCryptoC2Ev
__int64 __fastcall RBX::Security::SessionCrypto::SessionCrypto(RBX::Security::SessionCrypto *this)
{
  *(_QWORD *)this = off_10C9030B8; /*0x1039e9da9*/
  *((_QWORD *)this + 1) = 0; /*0x1039e9dae*/
  *((_OWORD *)this + 3) = 0; /*0x1039e9db5*/
  *((_QWORD *)this + 4) = 0; /*0x1039e9db9*/
  *(_QWORD *)((char *)this + 38) = 0; /*0x1039e9dbd*/
  *((_QWORD *)this + 3) = 0x754E657571696E55LL; /*0x1039e9dcb*/
  return _InterlockedExchange64((volatile __int64 *)this + 2, 0x754E657571696E55LL); /*0x1039e9dd3*/
}

// Address: 0x1039e9dd6 | Name: __ZN3RBX8Security13SessionCryptoC1Ev
__int64 __fastcall RBX::Security::SessionCrypto::SessionCrypto(RBX::Security::SessionCrypto *this)
{
  *(_QWORD *)this = off_10C9030B8; /*0x1039e9de1*/
  *((_QWORD *)this + 1) = 0; /*0x1039e9de6*/
  *((_OWORD *)this + 3) = 0; /*0x1039e9ded*/
  *((_QWORD *)this + 4) = 0; /*0x1039e9df1*/
  *(_QWORD *)((char *)this + 38) = 0; /*0x1039e9df5*/
  *((_QWORD *)this + 3) = 0x754E657571696E55LL; /*0x1039e9e03*/
  return _InterlockedExchange64((volatile __int64 *)this + 2, 0x754E657571696E55LL); /*0x1039e9e0b*/
}

// Address: 0x1039e9e0e | Name: __ZN3RBX8Security13SessionCrypto10initCommonEv
bool __fastcall RBX::Security::SessionCrypto::initCommon(RBX::Security::SessionCrypto *this)
{
  RBX::Security::SessionCrypto::KeyExchangeKeys *v2; // r14

  *(_WORD *)((char *)this + 41) = 0; /*0x1039e9e18*/
  *((_BYTE *)this + 43) = 0; /*0x1039e9e1e*/
  v2 = (RBX::Security::SessionCrypto::KeyExchangeKeys *)operator new(a1: 0x160u); /*0x1039e9e2c*/
  RBX::Security::SessionCrypto::KeyExchangeKeys::KeyExchangeKeys(this: v2); /*0x1039e9e32*/
  std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>::reset[abi:ne200100](a1: (char *)this + 32, a2: v2); /*0x1039e9e3e*/
  return (unsigned int)crypto_kx_keypair(a1: *((_QWORD *)this + 4), a2: *((_QWORD *)this + 4) + 32LL) == 0; /*0x1039e9e55*/
}

// Address: 0x1039e9e6e | Name: __ZNK3RBX8Security13SessionCrypto13getSupportAesEv
bool __fastcall RBX::Security::SessionCrypto::getSupportAes(RBX::Security::SessionCrypto *this)
{
  return (unsigned int)crypto_aead_aes256gcm_is_available(a1: this) == 1; /*0x1039e9e7d*/
}

// Address: 0x1039e9e80 | Name: __ZNK3RBX8Security13SessionCrypto18getRakCryptoFormatEv
__int64 __fastcall RBX::Security::SessionCrypto::getRakCryptoFormat(RBX::Security::SessionCrypto *this)
{
  return *((unsigned __int8 *)this + 45); /*0x1039e9e88*/
}

// Address: 0x1039e9e8a | Name: __ZN3RBX8Security13SessionCrypto18setRakCryptoFormatENS1_12CryptoFormatE
void __fastcall RBX::Security::SessionCrypto::setRakCryptoFormat(__int64 a1, char a2)
{
  *(_BYTE *)(a1 + 45) = a2; /*0x1039e9e8e*/
}

// Address: 0x1039e9e94 | Name: __ZN3RBX8Security13SessionCrypto8isAesGcmENS1_12CryptoFormatE
bool __fastcall RBX::Security::SessionCrypto::isAesGcm(char a1)
{
  return (a1 & 2) != 0; /*0x1039e9e9e*/
}

// Address: 0x1039e9ea0 | Name: __ZNK3RBX8Security13SessionCrypto11rakIsAesGcmEv
bool __fastcall RBX::Security::SessionCrypto::rakIsAesGcm(RBX::Security::SessionCrypto *this)
{
  return (*((_BYTE *)this + 45) & 2) != 0; /*0x1039e9eab*/
}

// Address: 0x1039e9eae | Name: __ZN3RBX8Security13SessionCrypto10isTestOnlyENS1_12CryptoFormatE
char __fastcall RBX::Security::SessionCrypto::isTestOnly(unsigned __int8 a1)
{
  return a1 >> 7; /*0x1039e9eb7*/
}

// Address: 0x1039e9eba | Name: __ZNK3RBX8Security13SessionCrypto13rakIsTestOnlyEv
char __fastcall RBX::Security::SessionCrypto::rakIsTestOnly(RBX::Security::SessionCrypto *this)
{
  return *((_BYTE *)this + 45) >> 7; /*0x1039e9ec4*/
}

// Address: 0x1039e9ec6 | Name: __ZNK3RBX8Security13SessionCrypto19getEnabledForRaknetEv
bool __fastcall RBX::Security::SessionCrypto::getEnabledForRaknet(RBX::Security::SessionCrypto *this)
{
  return *((_BYTE *)this + 45) > 0; /*0x1039e9ed1*/
}

// Address: 0x1039e9ed4 | Name: __ZNK3RBX8Security13SessionCrypto25writeAndIncrementAppNonceEPh
unsigned __int8 *__fastcall RBX::Security::SessionCrypto::writeAndIncrementAppNonce(
        RBX::Security::SessionCrypto *this,
        unsigned __int8 *a2)
{
  *(_QWORD *)a2 = _InterlockedExchangeAdd64((volatile signed __int64 *)this + 1, 1u) + 0x754E657571696E55LL; /*0x1039e9ef3*/
  *((_DWORD *)a2 + 2) = 1919246957; /*0x1039e9ef6*/
  return a2; /*0x1039e9efd*/
}

// Address: 0x1039e9f00 | Name: __ZNK3RBX8Security13SessionCrypto27writeAndIncrementRakTxNonceEPh
unsigned __int8 *__fastcall RBX::Security::SessionCrypto::writeAndIncrementRakTxNonce(
        RBX::Security::SessionCrypto *this,
        unsigned __int8 *a2)
{
  qmemcpy(a2, "UniqueNumbeR", 12); /*0x1039e9f11*/
  *(_QWORD *)a2 = _InterlockedExchangeAdd64((volatile signed __int64 *)this + 2, 1u); /*0x1039e9f26*/
  return a2; /*0x1039e9f29*/
}

// Address: 0x1039e9f2c | Name: __ZNK3RBX8Security13SessionCrypto13getRakRxNonceEtPh
bool __fastcall RBX::Security::SessionCrypto::getRakRxNonce(
        RBX::Security::SessionCrypto *this,
        unsigned int a2,
        unsigned __int8 *a3)
{
  __int64 v3; // rcx
  int v4; // eax
  unsigned __int64 v5; // rcx
  __int64 v6; // r8
  unsigned __int64 v7; // r9
  __int64 v8; // rdi
  bool v9; // zf
  int v10; // esi
  bool result; // al
  __int64 v12; // rcx

  v3 = *((_QWORD *)this + 3); /*0x1039e9f30*/
  v4 = (unsigned __int16)v3; /*0x1039e9f34*/
  v5 = v3 & 0xFFFFFFFFFFFF0000LL; /*0x1039e9f3e*/
  v6 = a2; /*0x1039e9f41*/
  v7 = v5 + a2; /*0x1039e9f44*/
  v8 = v7 - 0x10000; /*0x1039e9f48*/
  v9 = a2 == v4; /*0x1039e9f4b*/
  v10 = a2 - v4; /*0x1039e9f4b*/
  result = !v9; /*0x1039e9f4d*/
  if ( v10 < 32769 ) /*0x1039e9f56*/
    v8 = v7; /*0x1039e9f56*/
  v12 = v5 + v6 + 0x10000; /*0x1039e9f60*/
  if ( v10 >= -32768 ) /*0x1039e9f68*/
    v12 = v8; /*0x1039e9f68*/
  *((_DWORD *)a3 + 2) = 1382376045; /*0x1039e9f6c*/
  *(_QWORD *)a3 = v12; /*0x1039e9f73*/
  return result; /*0x1039e9f76*/
}

// Address: 0x1039e9f78 | Name: __ZN3RBX8Security13SessionCrypto16updateRakRxNonceEt
unsigned __int64 __fastcall RBX::Security::SessionCrypto::updateRakRxNonce(RBX::Security::SessionCrypto *this, int a2)
{
  unsigned __int64 result; // rax

  result = a2 - (unsigned int)*((unsigned __int16 *)this + 12); /*0x1039e9f82*/
  if ( (int)result > -32769 ) /*0x1039e9f89*/
  {
    if ( (int)result <= 0 ) /*0x1039e9fa0*/
      return result; /*0x1039e9fa0*/
    result = *((_QWORD *)this + 3) & 0xFFFFFFFFFFFF0000LL; /*0x1039e9fa9*/
  }
  else
  {
    result = (*((_QWORD *)this + 3) & 0xFFFFFFFFFFFF0000LL) + 0x10000; /*0x1039e9f96*/
  }
  *((_QWORD *)this + 3) = result | (unsigned __int16)a2; /*0x1039e9fb3*/
  return result; /*0x1039e9fb7*/
}

// Address: 0x1039e9fba | Name: __ZNK3RBX8Security13SessionCrypto16expandRakRxNonceEtPh
unsigned __int64 __fastcall RBX::Security::SessionCrypto::expandRakRxNonce(
        RBX::Security::SessionCrypto *this,
        unsigned int a2,
        unsigned __int8 *a3)
{
  unsigned __int64 v3; // rcx
  unsigned __int64 result; // rax
  unsigned __int64 v5; // rdi
  unsigned __int64 v6; // rsi

  v3 = *((_QWORD *)this + 3) & 0xFFFFFFFFFFFF0000LL | a2; /*0x1039e9fcb*/
  qmemcpy(a3, "UniqueNumbeR", 12); /*0x1039e9fd8*/
  result = *((_QWORD *)this + 3); /*0x1039e9fe2*/
  if ( v3 >= result ) /*0x1039e9fec*/
  {
    v6 = v3 - 0x10000; /*0x1039ea00f*/
    if ( v3 - result < 0x8001 ) /*0x1039ea01d*/
    {
      v6 = v3; /*0x1039ea01d*/
      result = v3; /*0x1039ea021*/
    }
  }
  else
  {
    v5 = v3 + 0x10000; /*0x1039e9ff4*/
    if ( result - v3 >= 0x8001 ) /*0x1039ea002*/
    {
      v3 += 0x10000LL; /*0x1039ea002*/
      result = v5; /*0x1039ea006*/
    }
    v6 = v3; /*0x1039ea00a*/
  }
  *(_QWORD *)a3 = v6; /*0x1039ea025*/
  return result; /*0x1039ea028*/
}

// Address: 0x1039ea02a | Name: __ZNK3RBX8Security13SessionCrypto16earlyEncryptDataENS_16MutableArrayViewIhEENS_9ArrayViewIhEEm
bool __fastcall RBX::Security::SessionCrypto::earlyEncryptData(
        __int64 a1,
        void *a2,
        __int64 a3,
        const void *a4,
        __int64 a5,
        size_t a6)
{
  int v10; // r14d
  __int64 v12; // rax
  __int64 v13; // rax
  __int64 v14; // rsi
  __int64 v15; // [rsp-40h] [rbp-40h] BYREF
  __int64 v16; // [rsp-38h] [rbp-38h]

  if ( *(_BYTE *)(a1 + 43) != 0 ) /*0x1039ea02e*/
    return false; /*0x1039ea030*/
  if ( *(_BYTE *)(a1 + 41) != 1 ) /*0x1039ea04b*/
    return false; /*0x1039ea073*/
  v10 = (int)a4; /*0x1039ea053*/
  if ( *(_BYTE *)(a1 + 40) == 1 ) /*0x1039ea05e*/
  {
    v12 = *(_QWORD *)(a1 + 32); /*0x1039ea060*/
    if ( *(_BYTE *)(a1 + 44) == 1 ) /*0x1039ea069*/
      v13 = v12 + 288; /*0x1039ea06b*/
    else
      v13 = v12 + 224; /*0x1039ea085*/
  }
  else
  {
    v13 = *(_QWORD *)(a1 + 32) + 192LL; /*0x1039ea07f*/
  }
  v16 = v13; /*0x1039ea08b*/
  memcpy(__dst: a2, __src: a4, __n: a6); /*0x1039ea098*/
  v14 = (__int64)a2 + a5 + 12; /*0x1039ea0bd*/
  *(_QWORD *)(v14 - 12) = _InterlockedExchangeAdd64((volatile signed __int64 *)(a1 + 8), 1u) + 0x754E657571696E55LL; /*0x1039ea0c1*/
  *(_DWORD *)(v14 - 4) = 1919246957; /*0x1039ea0c5*/
  return (unsigned int)crypto_aead_chacha20poly1305_ietf_encrypt_detached( /*0x1039ea032*/
                         a1: (int)a6 + (int)a2,
                         a2: v14,
                         a3: (unsigned int)&v15,
                         a4: v10 + (int)a6,
                         a5: (int)a5 - (int)a6,
                         a6: v10,
                         a7: a6,
                         a8: 0,
                         a9: (__int64)a2 + a5,
                         a10: v16) == 0
      && v15 == 16;
}

// Address: 0x1039ea114 | Name: __ZN3RBX8Security13SessionCrypto16earlyDecryptDataENS_16MutableArrayViewIhEENS_9ArrayViewIhEEm
bool __fastcall RBX::Security::SessionCrypto::earlyDecryptData(
        __int64 a1,
        void *a2,
        __int64 a3,
        const void *a4,
        __int64 a5,
        size_t a6)
{
  int v9; // r15d
  __int64 v10; // r13
  __int64 v11; // r13

  if ( *(_BYTE *)(a1 + 43) != 0 || *(_BYTE *)(a1 + 41) != 1 ) /*0x1039ea122*/
    return false; /*0x1039ea1b0*/
  v9 = (int)a2; /*0x1039ea13f*/
  v10 = 224; /*0x1039ea142*/
  if ( *(_BYTE *)(a1 + 40) == 1 ) /*0x1039ea14c*/
  {
    *(_BYTE *)(a1 + 44) = 1; /*0x1039ea14e*/
    v10 = 256; /*0x1039ea152*/
  }
  v11 = *(_QWORD *)(a1 + 32) + v10; /*0x1039ea158*/
  memcpy(__dst: a2, __src: a4, __n: a6); /*0x1039ea165*/
  return (unsigned int)crypto_aead_chacha20poly1305_ietf_decrypt_detached( /*0x1039ea1af*/
                         a1: (int)a6 + v9,
                         a2: 0,
                         a3: (int)a4 + (int)a6,
                         a4: (int)a3 - (int)a6,
                         a5: (int)a4 + (int)a3 + 12,
                         a6: (_DWORD)a4,
                         a7: a6,
                         a8: (__int64)a4 + a3,
                         a9: v11) == 0;
}

// Address: 0x1039ea1b4 | Name: __ZN3RBX8Security13SessionCrypto20resetKeyExchangeKeysEb
__int64 __fastcall RBX::Security::SessionCrypto::resetKeyExchangeKeys(RBX::Security::SessionCrypto *this, int a2)
{
  __int64 result; // rax

  result = std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>::reset[abi:ne200100]( /*0x1039ea1c7*/
             a1: (char *)this + 32,
             a2: 0);
  *((_BYTE *)this + 41) = 0; /*0x1039ea1cc*/
  if ( a2 != 0 ) /*0x1039ea1d3*/
    *((_WORD *)this + 21) = 256; /*0x1039ea1d5*/
  return result; /*0x1039ea1db*/
}

// Address: 0x1039ea1e0 | Name: __ZNK3RBX8Security13SessionCrypto21isKeyExchangeCompleteEv
char __fastcall RBX::Security::SessionCrypto::isKeyExchangeComplete(RBX::Security::SessionCrypto *this)
{
  if ( *((_BYTE *)this + 43) != 0 ) /*0x1039ea1e8*/
    return 0; /*0x1039ea1ea*/
  else
    return *((_BYTE *)this + 42); /*0x1039ea1ee*/
}

// Address: 0x1039ea1f4 | Name: __ZNK3RBX8Security13SessionCrypto11encryptDataENS_16MutableArrayViewIhEENS_9ArrayViewIhEE
bool __fastcall RBX::Security::SessionCrypto::encryptData(__int64 a1, __int64 a2, __int64 a3, int a4, __int64 a5)
{
  __int64 v5; // rdx
  __int64 v6; // rax
  __int64 v8; // [rsp+28h] [rbp-10h] BYREF

  if ( *(_BYTE *)(a1 + 43) != 0 || (*(_BYTE *)(a1 + 42) & (a5 + 28 == a3)) != 1 ) /*0x1039ea20d*/
    return false; /*0x1039ea283*/
  v5 = a1 + 32 * (unsigned int)*(unsigned __int8 *)(a1 + 40) + 64; /*0x1039ea222*/
  v6 = a2 + a5 + 12; /*0x1039ea246*/
  *(_QWORD *)(v6 - 12) = _InterlockedExchangeAdd64((volatile signed __int64 *)(a1 + 8), 1u) + 0x754E657571696E55LL; /*0x1039ea24a*/
  *(_DWORD *)(v6 - 4) = 1919246957; /*0x1039ea24e*/
  return (unsigned int)crypto_aead_chacha20poly1305_ietf_encrypt_detached( /*0x1039ea282*/
                         a1: a2,
                         a2: (int)a2 + (int)a5 + 12,
                         a3: (unsigned int)&v8,
                         a4,
                         a5,
                         a6: 0,
                         a7: 0,
                         a8: 0,
                         a9: a2 + a5,
                         a10: v5) == 0;
}

// Address: 0x1039ea286 | Name: __ZNK3RBX8Security13SessionCrypto11decryptDataENS_16MutableArrayViewIhEENS_9ArrayViewIhEE
bool __fastcall RBX::Security::SessionCrypto::decryptData(
        unsigned __int8 *a1,
        int a2,
        __int64 a3,
        __int64 a4,
        unsigned __int64 a5)
{
  bool result; // al

  if ( a1[43] != 0 ) /*0x1039ea28a*/
    return false; /*0x1039ea28c*/
  result = false; /*0x1039ea28f*/
  if ( a1[42] == 1 && a5 >= 0x1C && a5 - 28 == a3 ) /*0x1039ea2a7*/
    return (unsigned int)crypto_aead_chacha20poly1305_ietf_decrypt_detached( /*0x1039ea2ec*/
                           a1: a2,
                           a2: 0,
                           a3: a4,
                           a4: a3,
                           a5: (int)a4 + (int)a3 + 12,
                           a6: 0,
                           a7: 0,
                           a8: a4 + a3,
                           a9: (__int64)&a1[32 * (a1[40] ^ 1) + 64]) == 0;
  return result; /*0x1039ea28e*/
}

// Address: 0x1039ea2f2 | Name: __ZNK3RBX8Security13SessionCrypto11encryptDataENS_9ArrayViewIhEE
__int64 __fastcall RBX::Security::SessionCrypto::encryptData(__int64 a1, __int64 a2, int a3, __int64 a4)
{
  char *v8; // rsi
  __int64 v9; // rdx
  bool v10; // al
  char v11; // cl
  __int128 v13; // [rsp+0h] [rbp-40h] BYREF
  void *v14; // [rsp+10h] [rbp-30h]
  char v15; // [rsp+18h] [rbp-28h]

  v13 = 0; /*0x1039ea314*/
  v14 = nullptr; /*0x1039ea317*/
  v15 = 1; /*0x1039ea31f*/
  std::string::resize(a1: &v13, a2: a4 + 28, a3: 0); /*0x1039ea329*/
  if ( (v13 & 1) != 0 ) /*0x1039ea335*/
  {
    v8 = (char *)v14; /*0x1039ea337*/
    v9 = *((_QWORD *)&v13 + 1); /*0x1039ea33b*/
  }
  else
  {
    v8 = (char *)&v13 + 1; /*0x1039ea341*/
    v9 = (unsigned __int8)v13 >> 1; /*0x1039ea345*/
  }
  v10 = RBX::Security::SessionCrypto::encryptData(a1: a2, a2: (__int64)v8, a3: v9, a4: a3, a5: a4); /*0x1039ea350*/
  *(_BYTE *)a1 = 0; /*0x1039ea357*/
  *(_BYTE *)(a1 + 24) = 0; /*0x1039ea359*/
  v11 = v15; /*0x1039ea35c*/
  if ( v10 && (v15 & 1) != 0 ) /*0x1039ea366*/
  {
    *(_QWORD *)(a1 + 16) = v14; /*0x1039ea36c*/
    *(_OWORD *)a1 = v13; /*0x1039ea374*/
    v13 = 0; /*0x1039ea37a*/
    v14 = nullptr; /*0x1039ea37e*/
    *(_BYTE *)(a1 + 24) = 1; /*0x1039ea386*/
  }
  if ( (v11 & 1) != 0 && (v13 & 1) != 0 ) /*0x1039ea393*/
    operator delete(a1: v14); /*0x1039ea399*/
  return a1; /*0x1039ea3a1*/
}

// Address: 0x1039ea3d0 | Name: __ZNK3RBX8Security13SessionCrypto13encryptStringERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
__int64 __fastcall RBX::Security::SessionCrypto::encryptString(__int64 a1, __int64 a2, unsigned __int8 *a3)
{
  unsigned int v4; // ecx
  __int64 v5; // rcx

  v4 = *a3; /*0x1039ea3d9*/
  if ( (v4 & 1) != 0 ) /*0x1039ea3df*/
  {
    v5 = *((_QWORD *)a3 + 1); /*0x1039ea3e1*/
    a3 = *((unsigned __int8 **)a3 + 2); /*0x1039ea3e5*/
  }
  else
  {
    LODWORD(a3) = (_DWORD)a3 + 1; /*0x1039ea3eb*/
    v5 = v4 >> 1; /*0x1039ea3ee*/
  }
  RBX::Security::SessionCrypto::encryptData(a1, a2, (int)a3, a4: v5); /*0x1039ea3f3*/
  return a1; /*0x1039ea3ff*/
}

// Address: 0x1039ea402 | Name: __ZNK3RBX8Security13SessionCrypto18encryptDataInPlaceENS_16MutableArrayViewIhEE
bool __fastcall RBX::Security::SessionCrypto::encryptDataInPlace(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  return a3 >= 0x1C && RBX::Security::SessionCrypto::encryptData(a1, a2, a3, a4: a2, a5: a3 - 28); /*0x1039ea40e*/
}

// Address: 0x1039ea41e | Name: __ZNK3RBX8Security13SessionCrypto11decryptDataENS_9ArrayViewIhEE
__int64 __fastcall RBX::Security::SessionCrypto::decryptData(
        __int64 a1,
        unsigned __int8 *a2,
        __int64 a3,
        unsigned __int64 a4)
{
  __int64 v8; // r13
  char *v9; // rsi
  bool v10; // al
  char v11; // cl
  __int128 v13; // [rsp+0h] [rbp-50h] BYREF
  void *v14; // [rsp+10h] [rbp-40h]
  char v15; // [rsp+18h] [rbp-38h]

  if ( a4 > 0x1B ) /*0x1039ea436*/
  {
    v13 = 0; /*0x1039ea454*/
    v14 = nullptr; /*0x1039ea457*/
    v15 = 1; /*0x1039ea45f*/
    v8 = a4 - 28; /*0x1039ea463*/
    std::string::resize(a1: &v13, a2: a4 - 28, a3: 0); /*0x1039ea46c*/
    if ( (v13 & 1) != 0 ) /*0x1039ea475*/
      LODWORD(v9) = (_DWORD)v14; /*0x1039ea477*/
    else
      v9 = (char *)&v13 + 1; /*0x1039ea47d*/
    v10 = RBX::Security::SessionCrypto::decryptData(a1: a2, a2: (int)v9, a3: v8, a4: a3, a5: a4); /*0x1039ea48d*/
    *(_BYTE *)a1 = 0; /*0x1039ea494*/
    *(_BYTE *)(a1 + 24) = 0; /*0x1039ea496*/
    v11 = v15; /*0x1039ea499*/
    if ( v10 && (v15 & 1) != 0 ) /*0x1039ea4a3*/
    {
      *(_QWORD *)(a1 + 16) = v14; /*0x1039ea4a9*/
      *(_OWORD *)a1 = v13; /*0x1039ea4b1*/
      v13 = 0; /*0x1039ea4b7*/
      v14 = nullptr; /*0x1039ea4bb*/
      *(_BYTE *)(a1 + 24) = 1; /*0x1039ea4c3*/
    }
    if ( (v11 & 1) != 0 && (v13 & 1) != 0 ) /*0x1039ea4d0*/
      operator delete(a1: v14); /*0x1039ea4d6*/
  }
  else
  {
    *(_BYTE *)a1 = 0; /*0x1039ea43a*/
    *(_BYTE *)(a1 + 24) = 0; /*0x1039ea43c*/
  }
  return a1; /*0x1039ea4de*/
}

// Address: 0x1039ea510 | Name: __ZNK3RBX8Security13SessionCrypto13decryptStringERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
__int64 __fastcall RBX::Security::SessionCrypto::decryptString(__int64 a1, unsigned __int8 *a2, unsigned __int8 *a3)
{
  unsigned int v4; // ecx
  unsigned __int64 v5; // rcx
  __int64 v6; // rdx

  v4 = *a3; /*0x1039ea519*/
  if ( (v4 & 1) != 0 ) /*0x1039ea51f*/
  {
    v5 = *((_QWORD *)a3 + 1); /*0x1039ea521*/
    v6 = *((_QWORD *)a3 + 2); /*0x1039ea525*/
  }
  else
  {
    v6 = (__int64)(a3 + 1); /*0x1039ea52b*/
    v5 = v4 >> 1; /*0x1039ea52e*/
  }
  RBX::Security::SessionCrypto::decryptData(a1, a2, a3: v6, a4: v5); /*0x1039ea533*/
  return a1; /*0x1039ea53f*/
}

// Address: 0x1039ea542 | Name: __ZNK3RBX8Security13SessionCrypto18decryptDataInPlaceENS_16MutableArrayViewIhEE
bool __fastcall RBX::Security::SessionCrypto::decryptDataInPlace(unsigned __int8 *a1, __int64 a2, unsigned __int64 a3)
{
  return a3 >= 0x1C && RBX::Security::SessionCrypto::decryptData(a1, a2, a3: a3 - 28, a4: a2, a5: a3); /*0x1039ea54e*/
}

// Address: 0x1039ea560 | Name: __ZNK3RBX8Security13SessionCrypto21encryptRakDataInPlaceENS_16MutableArrayViewIhEE
__int64 __fastcall RBX::Security::SessionCrypto::encryptRakDataInPlace(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  __int64 result; // rax
  int v5; // r8d
  __int64 v6; // rsi
  _QWORD *v7; // rax
  __int64 v8; // r9
  int v9; // eax
  _BYTE v10[16]; // [rsp+28h] [rbp-10h] BYREF

  result = 1; /*0x1039ea560*/
  if ( a3 >= 0x12 ) /*0x1039ea569*/
  {
    result = 2; /*0x1039ea56f*/
    if ( *(_BYTE *)(a1 + 43) == 0 ) /*0x1039ea578*/
    {
      result = 3; /*0x1039ea57e*/
      if ( *(_BYTE *)(a1 + 42) == 1 ) /*0x1039ea587*/
      {
        v5 = a3 - 18; /*0x1039ea590*/
        v6 = 32 * (unsigned int)*(unsigned __int8 *)(a1 + 40); /*0x1039ea598*/
        v7 = (_QWORD *)(a2 + a3 - 18); /*0x1039ea59f*/
        qmemcpy(v7, "UniqueNumbeR", 12); /*0x1039ea5ad*/
        v8 = a1 + v6 + 64; /*0x1039ea5c7*/
        *v7 = _InterlockedExchangeAdd64((volatile signed __int64 *)(a1 + 16), 1u); /*0x1039ea5cb*/
        if ( (*(_BYTE *)(a1 + 45) & 2) != 0 ) /*0x1039ea5d2*/
          v9 = crypto_aead_aes256gcm_encrypt_detached( /*0x1039ea60f*/
                 a1: a2,
                 a2: (int)a2 + (int)a3 - 16,
                 a3: (int)v10,
                 a4: a2,
                 a5: v5,
                 a6: 0,
                 a7: 0,
                 a8: 0,
                 a9: a2 + a3 - 18,
                 a10: v8);
        else
          v9 = crypto_aead_chacha20poly1305_ietf_encrypt_detached( /*0x1039ea5db*/
                 a1: a2,
                 a2: (int)a2 + (int)a3 - 16,
                 a3: (unsigned int)v10,
                 a4: a2,
                 a5: v5,
                 a6: 0,
                 a7: 0,
                 a8: 0,
                 a9: a2 + a3 - 18,
                 a10: v8);
        return 5 * (unsigned int)(v9 != 0); /*0x1039ea619*/
      }
    }
  }
  return result; /*0x1039ea621*/
}

// Address: 0x1039ea622 | Name: __ZNK3RBX8Security13SessionCrypto32encryptRakDataInPlace_deprecatedENS_16MutableArrayViewIhEE
bool __fastcall RBX::Security::SessionCrypto::encryptRakDataInPlace_deprecated(
        __int64 a1,
        __int64 a2,
        unsigned __int64 a3)
{
  int v4; // r8d
  __int64 v5; // rsi
  _QWORD *v6; // rax
  __int64 v7; // r9
  int v8; // eax
  _BYTE v10[16]; // [rsp+28h] [rbp-10h] BYREF

  if ( a3 < 0x12 || *(_BYTE *)(a1 + 43) != 0 || *(_BYTE *)(a1 + 42) != 1 ) /*0x1039ea632*/
    return false; /*0x1039ea684*/
  v4 = a3 - 18; /*0x1039ea637*/
  v5 = 32 * (unsigned int)*(unsigned __int8 *)(a1 + 40); /*0x1039ea63f*/
  v6 = (_QWORD *)(a2 + a3 - 18); /*0x1039ea646*/
  qmemcpy(v6, "UniqueNumbeR", 12); /*0x1039ea654*/
  v7 = a1 + v5 + 64; /*0x1039ea66e*/
  *v6 = _InterlockedExchangeAdd64((volatile signed __int64 *)(a1 + 16), 1u); /*0x1039ea672*/
  if ( (*(_BYTE *)(a1 + 45) & 2) != 0 ) /*0x1039ea679*/
    v8 = crypto_aead_aes256gcm_encrypt_detached( /*0x1039ea6b9*/
           a1: a2,
           a2: (int)a2 + (int)a3 - 16,
           a3: (int)v10,
           a4: a2,
           a5: v4,
           a6: 0,
           a7: 0,
           a8: 0,
           a9: a2 + a3 - 18,
           a10: v7);
  else
    v8 = crypto_aead_chacha20poly1305_ietf_encrypt_detached( /*0x1039ea682*/
           a1: a2,
           a2: (int)a2 + (int)a3 - 16,
           a3: (unsigned int)v10,
           a4: a2,
           a5: v4,
           a6: 0,
           a7: 0,
           a8: 0,
           a9: a2 + a3 - 18,
           a10: v7);
  return v8 == 0; /*0x1039ea686*/
}

// Address: 0x1039ea6c8 | Name: __ZN3RBX8Security13SessionCrypto21decryptRakDataInPlaceENS_16MutableArrayViewIhEE
bool __fastcall RBX::Security::SessionCrypto::decryptRakDataInPlace(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  unsigned __int64 v6; // rcx
  __int64 (__usercall *v7)@<rax>(void *@<rdi>, __int128, __int64); // rax
  bool result; // al
  __int64 v9; // r10
  unsigned __int64 v10; // r14
  unsigned __int64 v11; // rsi
  unsigned __int64 v12; // r9
  unsigned __int64 v13; // rdi
  _QWORD v14[2]; // [rsp+8h] [rbp-28h] BYREF

  if ( a3 < 0x12 || *(_BYTE *)(a1 + 43) != 0 || *(_BYTE *)(a1 + 42) != 1 ) /*0x1039ea6f7*/
    return false; /*0x1039ea719*/
  v6 = a3 - 18; /*0x1039ea6fc*/
  if ( (*(_BYTE *)(a1 + 45) & 2) != 0 ) /*0x1039ea70e*/
    v7 = crypto_aead_aes256gcm_decrypt_detached; /*0x1039ea738*/
  else
    v7 = (__int64 (__usercall *)@<rax>(void *@<rdi>, __int128, __int64))crypto_aead_chacha20poly1305_ietf_decrypt_detached; /*0x1039ea710*/
  v9 = a1 + 32 * (*(unsigned __int8 *)(a1 + 40) ^ 1u) + 64; /*0x1039ea743*/
  v10 = *(_QWORD *)(a1 + 24); /*0x1039ea74b*/
  v11 = v10; /*0x1039ea753*/
  LOWORD(v11) = *(_WORD *)(a2 + v6); /*0x1039ea756*/
  qmemcpy(v14, "UniqueNumbeR", 12); /*0x1039ea763*/
  if ( v11 >= v10 ) /*0x1039ea774*/
  {
    v13 = v11 - 0x10000; /*0x1039ea797*/
    if ( v11 - v10 < 0x8001 ) /*0x1039ea7a5*/
    {
      v13 = v11; /*0x1039ea7a5*/
      v10 = v11; /*0x1039ea7a9*/
    }
  }
  else
  {
    v12 = v11 + 0x10000; /*0x1039ea77c*/
    if ( v10 - v11 >= 0x8001 ) /*0x1039ea78a*/
    {
      v11 += 0x10000LL; /*0x1039ea78a*/
      v10 = v12; /*0x1039ea78e*/
    }
    v13 = v11; /*0x1039ea792*/
  }
  v14[0] = v13; /*0x1039ea7b1*/
  result = ((unsigned int (__fastcall *)(_DWORD, _DWORD, _DWORD, _DWORD, _DWORD, _DWORD, __int64, __int64, __int64))v7)( /*0x1039ea7d2*/
             a1: a2,
             a2: 0,
             a3: a2,
             a4: v6,
             a5: a2 + v6 + 2,
             a6: 0,
             a7: 0,
             a8: (__int64)v14,
             a9: v9) == 0;
  if ( result ) /*0x1039ea7d5*/
    *(_QWORD *)(a1 + 24) = v10; /*0x1039ea7db*/
  return result; /*0x1039ea72f*/
}

// Address: 0x1039ea7ea | Name: __ZNK3RBX8Security13SessionCrypto16getEarlyAuthDataEv
RBX::Security::SessionCrypto *__fastcall RBX::Security::SessionCrypto::getEarlyAuthData(
        RBX::Security::SessionCrypto *this,
        __int64 a2)
{
  RBX::Security::SessionCrypto *result; // rax
  __int64 v3; // rcx

  result = this; /*0x1039ea7ea*/
  v3 = *(_QWORD *)(a2 + 56); /*0x1039ea7ed*/
  *(_OWORD *)this = *(_OWORD *)(a2 + 48); /*0x1039ea7f5*/
  if ( v3 != 0 ) /*0x1039ea7fb*/
    _InterlockedIncrement64((volatile signed __int64 *)(v3 + 8)); /*0x1039ea801*/
  return result; /*0x1039ea807*/
}

// Address: 0x1039ea808 | Name: __ZN3RBX8Security13SessionCrypto16verifyPreauthMacENS_10StringViewES2_RKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEE
__m128i *__fastcall RBX::Security::SessionCrypto::verifyPreauthMac(
        __m128i *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        unsigned __int64 a5,
        unsigned __int8 *a6)
{
  __int64 v6; // rcx
  unsigned __int64 v7; // rdx
  char *v8; // r11
  __int128 *v9; // r10
  unsigned __int64 v10; // rsi
  char v11; // di
  bool v12; // zf
  __int64 v13; // rdx
  _BYTE *v14; // rcx
  char v15; // r14
  char *v16; // r12
  const __m128i **v17; // r15
  char v18; // bl
  const __m128i *v19; // r15
  __int64 v20; // rcx
  const __m128i *v21; // rax
  __m128i v22; // xmm1
  unsigned __int8 v23; // r13
  __m128i *v24; // rbx
  __int64 Instance; // [rsp+10h] [rbp-D0h]
  void *v30; // [rsp+28h] [rbp-B8h] BYREF
  _BYTE *v31; // [rsp+30h] [rbp-B0h]
  __m128i v32; // [rsp+40h] [rbp-A0h] BYREF
  void *v33; // [rsp+50h] [rbp-90h]
  __m128i *v34; // [rsp+58h] [rbp-88h]
  __m128i v35; // [rsp+60h] [rbp-80h] BYREF
  void *v36; // [rsp+70h] [rbp-70h]
  void *v37; // [rsp+78h] [rbp-68h]
  __int64 v38; // [rsp+80h] [rbp-60h]
  char v39; // [rsp+8Dh] [rbp-53h] BYREF
  _BYTE v40[2]; // [rsp+8Eh] [rbp-52h] BYREF
  __int128 v41; // [rsp+90h] [rbp-50h] BYREF
  __int128 v42; // [rsp+A0h] [rbp-40h] BYREF

  v40[0] = 0; /*0x1039ea841*/
  v39 = 0; /*0x1039ea844*/
  v42 = 0; /*0x1039ea84f*/
  v41 = 0; /*0x1039ea853*/
  v35 = 0; /*0x1039ea858*/
  v36 = nullptr; /*0x1039ea85d*/
  v34 = a1; /*0x1039ea874*/
  if ( ((unsigned __int8)DFFlag::ForceNewPaBlob2 | (a5 >= 0x21)) == 1 ) /*0x1039ea87b*/
  {
    v6 = a4 + 17; /*0x1039ea87d*/
    v7 = a5 - 17; /*0x1039ea889*/
    v8 = v40; /*0x1039ea88d*/
    v9 = &v41; /*0x1039ea891*/
    v10 = 33; /*0x1039ea895*/
    a1 = nullptr; /*0x1039ea89a*/
    do /*0x1039ea8e5*/
    {
      if ( 16 - a5 + v10 == 33 ) /*0x1039ea8a8*/
        break; /*0x1039ea8a8*/
      *v8 = *(_BYTE *)(v6 - 1); /*0x1039ea8ad*/
      if ( v7 < 0x10 ) /*0x1039ea8b4*/
        break; /*0x1039ea8b4*/
      *(_QWORD *)v9 = v6; /*0x1039ea8b6*/
      *((_QWORD *)v9 + 1) = 16; /*0x1039ea8b9*/
      v11 = (v10 >= a5) | (unsigned __int8)a1; /*0x1039ea8c8*/
      v6 += 17; /*0x1039ea8cb*/
      v10 += 17LL; /*0x1039ea8cf*/
      v7 -= 17LL; /*0x1039ea8d3*/
      v9 = &v42; /*0x1039ea8d7*/
      v8 = &v39; /*0x1039ea8db*/
      v12 = (v11 & 1) == 0; /*0x1039ea8de*/
      LOBYTE(a1) = 1; /*0x1039ea8e2*/
    }
    while ( v12 ); /*0x1039ea8e5*/
  }
  else
  {
    v40[0] = 6; /*0x1039ea8e9*/
    *(_QWORD *)&v41 = a4 + 16; /*0x1039ea8f1*/
    *((_QWORD *)&v41 + 1) = 16; /*0x1039ea8f5*/
  }
  Instance = RBX::Security::KeyRing::getInstance(this: (RBX::Security::KeyRing *)a1); /*0x1039ea902*/
  v15 = 1; /*0x1039ea909*/
  v16 = v40; /*0x1039ea90c*/
  v17 = (const __m128i **)&v41; /*0x1039ea910*/
  v37 = nullptr; /*0x1039ea914*/
  v38 = 0; /*0x1039ea91c*/
  v18 = 0; /*0x1039ea924*/
  do /*0x1039eaa46*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v32, a2: "PreAuthKey", a3: v13, a4: v14); /*0x1039ea937*/
    RBX::Security::KeyRing::getKeyForConsumption( /*0x1039ea959*/
      a1: (__int64)&v30,
      a2: Instance,
      a3: (unsigned __int8 *)&v32,
      a4: (unsigned __int8)*v16,
      a5: a6);
    if ( (v32.i8[0] & 1) != 0 ) /*0x1039ea965*/
      operator delete(a1: v33); /*0x1039ea96e*/
    v14 = v30; /*0x1039ea973*/
    if ( v30 == v31 || (v19 = *v17) == nullptr ) /*0x1039ea990*/
    {
      v15 = 0; /*0x1039eaa1c*/
      v23 = 0; /*0x1039eaa1f*/
    }
    else
    {
      RBX::Crypto::computeKeyedBlake2b(a1: &v32, a2, a3, a4: v30, a5: v31 - (_BYTE *)v30, a6: 16); /*0x1039ea9b0*/
      if ( (v38 & 1) != 0 ) /*0x1039ea9b9*/
        operator delete(a1: v37); /*0x1039ea9bf*/
      v21 = (const __m128i *)v33; /*0x1039ea9c4*/
      v36 = v33; /*0x1039ea9cb*/
      v35 = v32; /*0x1039ea9d6*/
      LOBYTE(v20) = v32.i8[0]; /*0x1039ea9da*/
      v38 = v20; /*0x1039ea9dd*/
      v37 = v33; /*0x1039ea9e4*/
      if ( (v32.i8[0] & 1) == 0 ) /*0x1039ea9ec*/
        v21 = (const __m128i *)&v35.i8[1]; /*0x1039ea9ec*/
      v22 = _mm_xor_si128(_mm_loadu_si128(v19), _mm_loadu_si128(v21)); /*0x1039ea9f9*/
      v23 = _mm_testz_si128(v22, v22); /*0x1039eaa02*/
      if ( !v23 ) /*0x1039eaa0f*/
        v15 = 0; /*0x1039eaa0f*/
      v14 = v30; /*0x1039eaa13*/
    }
    if ( v14 != nullptr ) /*0x1039eaa25*/
    {
      v31 = v14; /*0x1039eaa27*/
      operator delete(a1: v14); /*0x1039eaa31*/
    }
    v17 = (const __m128i **)&v42; /*0x1039eaa39*/
    v16 = &v39; /*0x1039eaa3d*/
    v12 = ((v23 | (unsigned __int8)v18) & 1) == 0; /*0x1039eaa41*/
    v18 = 1; /*0x1039eaa44*/
  }
  while ( v12 ); /*0x1039eaa46*/
  if ( v23 != 0 ) /*0x1039eaa4f*/
  {
    v24 = v34; /*0x1039eaa55*/
    v34[1].i64[0] = (__int64)v36; /*0x1039eaa5c*/
    *v24 = _mm_load_si128(&v35); /*0x1039eaa65*/
    v24[1].i8[8] = v15; /*0x1039eaa69*/
  }
  else
  {
    v24 = v34; /*0x1039eaa73*/
    *v34 = 0; /*0x1039eaa7a*/
    v24[1].i64[0] = 0; /*0x1039eaa7e*/
    v24[1].i8[8] = 0; /*0x1039eaa86*/
    if ( (v38 & 1) != 0 ) /*0x1039eaa8e*/
      operator delete(a1: v36); /*0x1039eaa94*/
  }
  return v24; /*0x1039eaaac*/
}

// Address: 0x1039eab10 | Name: __ZN3RBX8Security13SessionCrypto16verifyTicketBlobENS_10StringViewES2_
RBX::Security::KeyRing *__fastcall RBX::Security::SessionCrypto::verifyTicketBlob(
        RBX::Security::KeyRing *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        RBX::Security::KeyRing *a5)
{
  unsigned __int64 v5; // rax
  char *v6; // r10
  __int128 *v7; // r9
  char v8; // dl
  char v9; // dl
  bool v10; // zf
  char *v11; // r15
  RBX::Security::KeyRing **v12; // r14
  char v13; // r13
  __int64 Instance; // r12
  __int64 v15; // rdx
  __int64 v16; // rcx
  int v17; // ebx
  __int64 v18; // rdx
  __int64 v19; // rcx
  void *v20; // rcx
  bool v21; // bl
  int v22; // eax
  RBX::Security::KeyRing *result; // rax
  char v24; // cl
  unsigned __int8 v25[16]; // [rsp+8h] [rbp-B8h] BYREF
  void *v26; // [rsp+18h] [rbp-A8h]
  unsigned __int8 v27[16]; // [rsp+20h] [rbp-A0h] BYREF
  void *v28; // [rsp+30h] [rbp-90h]
  __int64 v29; // [rsp+38h] [rbp-88h]
  __int64 v30; // [rsp+40h] [rbp-80h]
  RBX::Security::KeyRing *v31; // [rsp+48h] [rbp-78h]
  void *v32[3]; // [rsp+50h] [rbp-70h] BYREF
  int v33; // [rsp+68h] [rbp-58h]
  char v34; // [rsp+6Dh] [rbp-53h] BYREF
  _BYTE v35[2]; // [rsp+6Eh] [rbp-52h] BYREF
  __int128 v36; // [rsp+70h] [rbp-50h] BYREF
  __int128 v37; // [rsp+80h] [rbp-40h] BYREF

  v29 = a3; /*0x1039eab24*/
  v30 = a2; /*0x1039eab2b*/
  v35[0] = 0; /*0x1039eab3f*/
  v34 = 0; /*0x1039eab42*/
  v5 = (unsigned __int64)&v37; /*0x1039eab45*/
  v37 = 0; /*0x1039eab4c*/
  v36 = 0; /*0x1039eab4f*/
  v31 = a1; /*0x1039eab62*/
  if ( ((unsigned __int8)DFFlag::ForceNewPaBlob2 | (a5 != (RBX::Security::KeyRing *)64)) == 1 ) /*0x1039eab66*/
  {
    v6 = v35; /*0x1039eab68*/
    v7 = &v36; /*0x1039eab6c*/
    v5 = 66; /*0x1039eab70*/
    v8 = 0; /*0x1039eab75*/
    a1 = a5; /*0x1039eab7b*/
    do /*0x1039eabce*/
    {
      if ( (unsigned __int64)a1 < 2 ) /*0x1039eab82*/
        break; /*0x1039eab82*/
      *v6 = *(_BYTE *)(a4 + v5 - 66); /*0x1039eab89*/
      if ( *(_BYTE *)(a4 + v5 - 65) != 1 ) /*0x1039eab91*/
        break; /*0x1039eab91*/
      if ( (unsigned __int64)a1 - 2 < 0x40 ) /*0x1039eab9b*/
        break; /*0x1039eab9b*/
      *(_QWORD *)v7 = a4 + v5 - 64; /*0x1039eaba5*/
      *((_QWORD *)v7 + 1) = 64; /*0x1039eaba8*/
      v9 = (v5 >= (unsigned __int64)a5) | v8; /*0x1039eabb7*/
      v5 += 66LL; /*0x1039eabba*/
      a1 = (RBX::Security::KeyRing *)((char *)a1 - 66); /*0x1039eabbe*/
      v7 = &v37; /*0x1039eabc2*/
      v6 = &v34; /*0x1039eabc6*/
      v10 = (v9 & 1) == 0; /*0x1039eabc9*/
      v8 = 1; /*0x1039eabcc*/
    }
    while ( v10 ); /*0x1039eabce*/
  }
  else
  {
    v35[0] = 6; /*0x1039eabd2*/
    *(_QWORD *)&v36 = a4; /*0x1039eabd6*/
  }
  v11 = v35; /*0x1039eabda*/
  v12 = (RBX::Security::KeyRing **)&v36; /*0x1039eabde*/
  LOBYTE(v5) = 1; /*0x1039eabe2*/
  v33 = v5; /*0x1039eabe4*/
  v13 = 0; /*0x1039eabe7*/
  do /*0x1039eacdd*/
  {
    Instance = RBX::Security::KeyRing::getInstance(this: a1); /*0x1039eabef*/
    std::string::basic_string[abi:ne200100]<0>(a1: v27, a2: "TicketPublicKey", a3: v15, a4: v16); /*0x1039eac00*/
    v17 = (unsigned __int8)*v11; /*0x1039eac05*/
    std::string::basic_string[abi:ne200100]<0>(a1: v25, a2: "", a3: v18, a4: v19); /*0x1039eac1a*/
    RBX::Security::KeyRing::getKeyForConsumption(a1: (__int64)v32, a2: Instance, a3: v27, a4: v17, a5: v25); /*0x1039eac32*/
    if ( (v25[0] & 1) != 0 ) /*0x1039eac3e*/
      operator delete(a1: v26); /*0x1039eac47*/
    if ( (v27[0] & 1) != 0 ) /*0x1039eac53*/
      operator delete(a1: v28); /*0x1039eac5c*/
    v20 = v32[0]; /*0x1039eac61*/
    v21 = false; /*0x1039eac6c*/
    if ( (void *)((char *)v32[1] - (char *)v32[0]) == (void *)32 ) /*0x1039eac72*/
    {
      a1 = *v12; /*0x1039eac74*/
      if ( *v12 != nullptr ) /*0x1039eac7a*/
      {
        v21 = (unsigned int)crypto_sign_verify_detached(a1, a2: v30, a3: v29) == 0; /*0x1039eac8e*/
        v22 = (unsigned __int8)v33; /*0x1039eac94*/
        if ( !v21 ) /*0x1039eac9c*/
          v22 = 0; /*0x1039eac9c*/
        v33 = v22; /*0x1039eac9f*/
        v20 = v32[0]; /*0x1039eaca2*/
      }
      else
      {
        v33 = 0; /*0x1039eacb1*/
        v21 = false; /*0x1039eacb8*/
      }
    }
    else
    {
      v33 = 0; /*0x1039eaca8*/
    }
    if ( v20 != nullptr ) /*0x1039eacbd*/
    {
      v32[1] = v20; /*0x1039eacbf*/
      operator delete(a1: v20); /*0x1039eacc6*/
    }
    v12 = (RBX::Security::KeyRing **)&v37; /*0x1039eacce*/
    v11 = &v34; /*0x1039eacd2*/
    v10 = ((v21 | (unsigned __int8)v13) & 1) == 0; /*0x1039eacd6*/
    v13 = 1; /*0x1039eacda*/
  }
  while ( v10 ); /*0x1039eacdd*/
  if ( v21 ) /*0x1039eace5*/
  {
    RBX::Crypto::blake2b(a1: v32, a2: v30, a3: v29, a4: 32); /*0x1039eacfb*/
    result = v31; /*0x1039ead04*/
    qmemcpy(v31, v32, 24); /*0x1039ead08*/
    v24 = v33; /*0x1039ead13*/
  }
  else
  {
    result = v31; /*0x1039ead1b*/
    *(_OWORD *)v31 = 0; /*0x1039ead1f*/
    *((_QWORD *)result + 2) = 0; /*0x1039ead22*/
    v24 = 0; /*0x1039ead2a*/
  }
  *((_BYTE *)result + 24) = v24; /*0x1039ead2c*/
  return result; /*0x1039ead3f*/
}

// END SessionCrypto part 1/1, 37 functions
