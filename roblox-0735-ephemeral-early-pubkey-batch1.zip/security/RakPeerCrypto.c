// RakPeerCrypto -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 18 functions

// Field names below come from the 2022 PDB, which is the only
// build that has them. Each is marked: bare `this->x` was
// corroborated by a store of matching width in that same
// function; UNVERIFIED means the 2022 layout says so and
// nothing target-era has confirmed it.


// Address: 0x1039ab618 | Name: __ZN3RBX8Security13RakPeerCrypto19initServer_DualPairENS_9ArrayViewIhEES3_S3_S3_
__int64 __fastcall RBX::Security::RakPeerCrypto::initServer_DualPair(
        RBX::Security::SessionCrypto *this,
        __int128 *a2,
        __int64 a3,
        __int128 *a4,
        __int64 a5,
        __int64 a6,
        __int128 *a7,
        __int64 a8,
        __int128 *a9,
        __int64 a10)
{
  unsigned int v13; // r14d
  __int64 v14; // rdx
  __int128 v15; // xmm0
  __int64 v16; // rdx
  __int128 v17; // xmm0
  __int64 v18; // rdx
  __int128 v19; // xmm0
  __int64 v20; // rcx
  __int128 v21; // xmm0

  v13 = a5; /*0x1039ab626*/
  this->.isServer /* +40 */ = 1; /*0x1039ab635*/
  LOBYTE(v13) = RBX::Security::SessionCrypto::initCommon(this) & (a3 == 32) & (a5 == 32) & (a8 == 32) & (a10 == 32); /*0x1039ab663*/
  if ( (_BYTE)v13 != 0 ) /*0x1039ab666*/
  {
    v14 = *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */; /*0x1039ab670*/
    v15 = *a2; /*0x1039ab674*/
    *(_OWORD *)(v14 + 80) = a2[1]; /*0x1039ab67f*/
    *(_OWORD *)(v14 + 64) = v15; /*0x1039ab683*/
    v16 = *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */; /*0x1039ab687*/
    v17 = *a4; /*0x1039ab68b*/
    *(_OWORD *)(v16 + 112) = a4[1]; /*0x1039ab694*/
    *(_OWORD *)(v16 + 96) = v17; /*0x1039ab698*/
    v18 = *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */; /*0x1039ab69c*/
    v19 = *a7; /*0x1039ab6a3*/
    *(_OWORD *)(v18 + 144) = a7[1]; /*0x1039ab6aa*/
    *(_OWORD *)(v18 + 128) = v19; /*0x1039ab6b1*/
    v20 = *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */; /*0x1039ab6b8*/
    v21 = *a9; /*0x1039ab6bf*/
    *(_OWORD *)(v20 + 176) = a9[1]; /*0x1039ab6c6*/
    *(_OWORD *)(v20 + 160) = v21; /*0x1039ab6cd*/
  }
  else
  {
    RBX::Security::SessionCrypto::resetKeyExchangeKeys(this, a2: true); /*0x1039ab6de*/
  }
  return v13; /*0x1039ab6ea*/
}

// Address: 0x1039ab6f6 | Name: __ZN3RBX8Security13RakPeerCrypto10initClientENS_9ArrayViewIhEE
int __fastcall RBX::Security::RakPeerCrypto::initClient(RBX::Security::SessionCrypto *this, __int128 *a2, __int64 a3)
{
  __int64 v5; // rax
  __int128 v6; // xmm0

  this->.isServer /* +40 */ = 0; /*0x1039ab709*/
  if ( ((a3 == 32) & (unsigned __int8)RBX::Security::SessionCrypto::initCommon(this)) != 0 /*0x1039ab752*/
    && (v5 = *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */,
        v6 = *a2,
        *(_OWORD *)(v5 + 80) = a2[1],
        *(_OWORD *)(v5 + 64) = v6,
        (unsigned int)crypto_kx_client_session_keys(
                        a1: *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */ + 224LL,
                        a2: *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */ + 192LL,
                        a3: *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */,
                        a4: *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */ + 32LL,
                        a5: a2) == 0) )
  {
    this->.isEarlySessionReady /* +41 */ = 1; /*0x1039ab76e*/
    return 1; /*0x1039ab772*/
  }
  else
  {
    RBX::Security::SessionCrypto::resetKeyExchangeKeys(this, a2: true); /*0x1039ab75c*/
    return 0; /*0x1039ab761*/
  }
}

// Address: 0x1039ab776 | Name: __ZNK3RBX8Security13RakPeerCrypto12getPublicKeyEv
__int64 __fastcall RBX::Security::RakPeerCrypto::getPublicKey(RBX::Security::RakPeerCrypto *this)
{
  __int64 result; // rax

  result = 0; /*0x1039ab77a*/
  if ( *((_BYTE *)this + 43) /* +43 likely .isError -- UNVERIFIED */ == 0 ) /*0x1039ab785*/
    return *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */; /*0x1039ab787*/
  return result; /*0x1039ab796*/
}

// Address: 0x1039ab798 | Name: __ZN3RBX8Security13RakPeerCrypto30clientInitEphemeralSessionKeysENS_9ArrayViewIhEE
int __fastcall RBX::Security::RakPeerCrypto::clientInitEphemeralSessionKeys(
        RBX::Security::SessionCrypto *this,
        __int64 a2,
        __int64 a3)
{
  __int64 v5; // rdx

  if ( (*((_BYTE *)this + 43) /* +43 likely .isError -- UNVERIFIED */ | (a3 != 32)) != 0 ) /*0x1039ab7a2*/
    return 0; /*0x1039ab7a6*/
  if ( *((_BYTE *)this + 40) /* +40 likely .isServer -- UNVERIFIED */ == 0 ) /*0x1039ab7b4*/
  {
    v5 = *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */; /*0x1039ab7b6*/
    if ( v5 != 0 ) /*0x1039ab7bd*/
    {
      if ( (unsigned int)crypto_kx_client_session_keys( /*0x1039ab7d5*/
                           a1: (char *)this + 96 /* +96 = .sessionKeyServerToClient._Elems (unsigned __int8[32], 32B) -- SIZE CONFLICT, see --verify */,
                           a2: (char *)this + 64 /* +64 = .sessionKeyClientToServer._Elems (unsigned __int8[32], 32B) -- SIZE CONFLICT, see --verify */,
                           a3: v5,
                           a4: v5 + 32,
                           a5: a2) == 0 )
      {
        this->.isSessionReady /* +42 */ = 1; /*0x1039ab7ed*/
        return 1; /*0x1039ab7f1*/
      }
      RBX::Security::SessionCrypto::resetKeyExchangeKeys(this, a2: true); /*0x1039ab7df*/
    }
  }
  return 0; /*0x1039ab7a6*/
}

// Address: 0x1039ab7f6 | Name: __ZN3RBX8Security13RakPeerCrypto35serverInitEarlySessionKeys_DualPairENS_9ArrayViewIhEE
char __fastcall RBX::Security::RakPeerCrypto::serverInitEarlySessionKeys_DualPair(
        RBX::Security::SessionCrypto *this,
        __int128 *a2,
        __int64 a3)
{
  __int64 v5; // rcx
  __int64 v7; // rax
  __int128 v8; // xmm0

  if ( (*((_BYTE *)this + 43) /* +43 likely .isError -- UNVERIFIED */ | (a3 != 32)) != 0 ) /*0x1039ab800*/
    return 0; /*0x1039ab804*/
  if ( *((_BYTE *)this + 40) /* +40 likely .isServer -- UNVERIFIED */ == 1 ) /*0x1039ab813*/
  {
    v5 = *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */; /*0x1039ab815*/
    if ( v5 != 0 ) /*0x1039ab81c*/
    {
      if ( (unsigned int)crypto_kx_server_session_keys(a1: v5 + 192, a2: v5 + 224, a3: v5 + 64, a4: v5 + 96, a5: a2) == 0 /*0x1039ab86d*/
        && (unsigned int)crypto_kx_server_session_keys(
                           a1: *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */ + 256LL,
                           a2: *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */ + 288LL,
                           a3: *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */ + 128LL,
                           a4: *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */ + 160LL,
                           a5: a2) == 0 )
      {
        this->.isEarlySessionReady /* +41 */ = 1; /*0x1039ab883*/
        v7 = *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */; /*0x1039ab887*/
        v8 = *a2; /*0x1039ab88b*/
        *(_OWORD *)(v7 + 336) = a2[1]; /*0x1039ab894*/
        *(_OWORD *)(v7 + 320) = v8; /*0x1039ab89b*/
        return 1; /*0x1039ab8a2*/
      }
      RBX::Security::SessionCrypto::resetKeyExchangeKeys(this, a2: true); /*0x1039ab877*/
    }
  }
  return 0; /*0x1039ab804*/
}

// Address: 0x1039ab8a6 | Name: __ZN3RBX8Security13RakPeerCrypto30serverInitEphemeralSessionKeysEv
int __fastcall RBX::Security::RakPeerCrypto::serverInitEphemeralSessionKeys(RBX::Security::RakPeerCrypto *this)
{
  __int64 v3; // rdx

  if ( *((_BYTE *)this + 43) /* +43 likely .isError -- UNVERIFIED */ != 0 ) /*0x1039ab8aa*/
    return 0; /*0x1039ab8ae*/
  v3 = *((_QWORD *)this + 4) /* +32 likely .keyExchangeKeys -- UNVERIFIED */; /*0x1039ab8b8*/
  if ( v3 != 0 && *((_BYTE *)this + 40) /* +40 likely .isServer -- UNVERIFIED */ == 1 ) /*0x1039ab8c5*/
  {
    if ( (unsigned int)crypto_kx_server_session_keys( /*0x1039ab8e1*/
                         a1: (char *)this + 64 /* +64 = .sessionKeyClientToServer._Elems (unsigned __int8[32], 32B) -- SIZE CONFLICT, see --verify */,
                         a2: (char *)this + 96 /* +96 = .sessionKeyServerToClient._Elems (unsigned __int8[32], 32B) -- SIZE CONFLICT, see --verify */,
                         a3: v3,
                         a4: v3 + 32,
                         a5: v3 + 320) == 0 )
    {
      this->.isSessionReady /* +42 */ = 1; /*0x1039ab8f9*/
      return 1; /*0x1039ab8fd*/
    }
    RBX::Security::SessionCrypto::resetKeyExchangeKeys(this, a2: true); /*0x1039ab8eb*/
  }
  return 0; /*0x1039ab8ae*/
}

// Address: 0x1039ab902 | Name: __ZNK3RBX8Security13RakPeerCrypto16earlyEncryptDataERN6RakNet9BitStreamEmt
__int64 __fastcall RBX::Security::RakPeerCrypto::earlyEncryptData(
        RBX::Security::RakPeerCrypto *this,
        RakNet::BitStream *a2,
        __int64 a3,
        unsigned int a4)
{
  __int64 v6; // r15
  __int64 v7; // rax

  v6 = (*(unsigned int (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 24LL))(a1: a2) - a4; /*0x1039ab92d*/
  RakNet::BitStream::AssertCopyData(this: a2); /*0x1039ab937*/
  RakNet::BitStream::PadWithZeroToByteLength(this: a2, a2: v6 + 28 + a4); /*0x1039ab948*/
  v7 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1039ab954*/
  return RBX::Security::SessionCrypto::earlyEncryptData(a1: this, a2: v7 + a4, a3: v6 + 28, a4: v7 + a4, a5: v6, a6: a3); /*0x1039ab96e*/
}

// Address: 0x1039ab982 | Name: __ZN3RBX8Security13RakPeerCrypto16earlyDecryptDataERN6RakNet9BitStreamEm
char __fastcall RBX::Security::RakPeerCrypto::earlyDecryptData(
        RBX::Security::RakPeerCrypto *this,
        RakNet::BitStream *a2,
        __int64 a3)
{
  unsigned __int64 v6; // r13
  __int64 v7; // r15
  __int64 v8; // rax
  RBX::Security::RakPeerCrypto *v9; // r15
  _BYTE v11[72]; // [rsp+0h] [rbp-290h] BYREF
  _BYTE v12[528]; // [rsp+48h] [rbp-248h] BYREF
  unsigned __int64 v13; // [rsp+258h] [rbp-38h]
  RBX::Security::RakPeerCrypto *v14; // [rsp+260h] [rbp-30h]

  v6 = (*(unsigned int (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 24LL))(a1: a2); /*0x1039ab9a8*/
  if ( a3 + 28 > v6 ) /*0x1039ab9b3*/
    return 0; /*0x1039ab9b3*/
  v13 = v6 - 28; /*0x1039ab9bd*/
  RakNet::BitStream::AssertCopyData(this: a2); /*0x1039ab9c4*/
  v7 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1039ab9d2*/
  v8 = (*(__int64 (__fastcall **)(RakNet::BitStream *))(*(_QWORD *)a2 + 16LL))(a1: a2); /*0x1039ab9db*/
  v14 = this; /*0x1039ab9de*/
  if ( (unsigned __int8)RBX::Security::SessionCrypto::earlyDecryptData( /*0x1039ab9ff*/
                          a1: this,
                          a2: v7,
                          a3: v6 - 28,
                          a4: v8,
                          a5: v6,
                          a6: a3) == 0 )
    return 0; /*0x1039aba7f*/
  v9 = v14; /*0x1039aba08*/
  if ( DFFlag::ReportEphemeralEarlyKeyUsage == 1 && *((_BYTE *)v14 + 40) == 1 ) /*0x1039aba13*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1039aba23*/
      a1: (__int64)v11,
      a2: (__int64)&RBX::Telemetry::kSessionCryptoEarlyKey);
    RBX::Telemetry::FieldsContainer::addField( /*0x1039aba46*/
      a1: v12,
      a2: "useEphemeral",
      a3: 12,
      a4: *((unsigned __int8 *)v9 + 44),
      a5: 1);
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v11); /*0x1039aba52*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v11); /*0x1039aba65*/
  }
  RakNet::BitStream::SetWriteOffset(this: a2, a2: 8 * (v6 - 28), a3: false); /*0x1039aba76*/
  return 1; /*0x1039aba81*/
}

// Address: 0x1039abab2 | Name: __ZN3RBX8Security13RakPeerCrypto18unitTestSetTxNonceEy
void __fastcall RBX::Security::RakPeerCrypto::unitTestSetTxNonce(RBX::Security::RakPeerCrypto *this, __int64 a2)
{
  _InterlockedExchange64((volatile __int64 *)this + 2, a2); /*0x1039abab6*/
}

// Address: 0x1039ababc | Name: __ZN3RBX8Security13RakPeerCrypto18unitTestSetRxNonceEy
void __fastcall RBX::Security::RakPeerCrypto::unitTestSetRxNonce(RBX::Security::RakPeerCrypto *this, __int64 a2)
{
  this->.rxRakNonce /* +24 */ = a2; /*0x1039abac0*/
}

// Address: 0x1039abac6 | Name: __ZNK3RBX8Security13RakPeerCrypto18unitTestGetTxNonceEv
__int64 __fastcall RBX::Security::RakPeerCrypto::unitTestGetTxNonce(RBX::Security::RakPeerCrypto *this)
{
  return *((_QWORD *)this + 2) /* +16 likely .txRakNonce.. -- UNVERIFIED */; /*0x1039abace*/
}

// Address: 0x1039abad0 | Name: __ZNK3RBX8Security13RakPeerCrypto18unitTestGetRxNonceEv
__int64 __fastcall RBX::Security::RakPeerCrypto::unitTestGetRxNonce(RBX::Security::RakPeerCrypto *this)
{
  return *((_QWORD *)this + 3) /* +24 likely .rxRakNonce -- UNVERIFIED */; /*0x1039abad8*/
}

// Address: 0x1039abada | Name: __ZN3RBX8Security13RakPeerCrypto16getClientKeyInfoEb
RBX::Security::RakPeerCrypto *__fastcall RBX::Security::RakPeerCrypto::getClientKeyInfo(
        RBX::Security::RakPeerCrypto *this,
        int a2)
{
  RBX::Security::KeyRing *v4; // rdi
  __int64 Instance; // rax
  void *v6; // rdi
  _OWORD *v7; // rax
  unsigned __int64 v8; // rcx
  __int128 v10; // [rsp+0h] [rbp-30h] BYREF
  __int64 v11; // [rsp+10h] [rbp-20h]
  int v12; // [rsp+18h] [rbp-18h]
  char v13; // [rsp+1Ch] [rbp-14h]

  *(_OWORD *)this = 0; /*0x1039abaee*/
  this->.txRakNonce.. /* +16 */ = 0; /*0x1039abaf1*/
  std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1039abaff*/
    a1: this,
    a2: 0,
    a3: 0,
    a4: 0);
  this->.rxRakNonce /* +24 */ = 0; /*0x1039abb04*/
  *((_BYTE *)this + 28) /* +28: NO 2022 FIELD */ = 0; /*0x1039abb0b*/
  if ( a2 == 0 ) /*0x1039abb12*/
    goto LABEL_5; /*0x1039abb12*/
  Instance = RBX::Security::KeyRing::getInstance(this: v4); /*0x1039abb14*/
  RBX::Security::KeyRing::getKeyForProduction( /*0x1039abb27*/
    a1: (__int64)&v10,
    a2: Instance,
    a3: RBX::Security::kRakNetEarlyPublicKeyName);
  v6 = *(void **)this; /*0x1039abb30*/
  if ( *(_QWORD *)this  /* +0 likely .__vftable -- UNVERIFIED */!= 0 ) /*0x1039abb36*/
  {
    this->.appNonce.. /* +8 */ = v6; /*0x1039abb38*/
    operator delete(a1: v6); /*0x1039abb3c*/
  }
  *(_OWORD *)this = v10; /*0x1039abb45*/
  this->.txRakNonce.. /* +16 */ = v11; /*0x1039abb4c*/
  *((_BYTE *)this + 28) /* +28: NO 2022 FIELD */ = v13; /*0x1039abb53*/
  this->.rxRakNonce /* +24 */ = v12; /*0x1039abb5a*/
  if ( (*((_BYTE *)this + 28) /* +28: NO 2022 FIELD */ & 1) == 0 ) /*0x1039abb61*/
  {
LABEL_5:
    *((_BYTE *)this + 28) /* +28: NO 2022 FIELD */ = 1; /*0x1039abb63*/
    v7 = *(_OWORD **)this; /*0x1039abb67*/
    v8 = this->.appNonce.. /* +8 */ - *(_QWORD *)this /* +0 likely .__vftable -- UNVERIFIED */; /*0x1039abb6e*/
    if ( v8 > 0x1F ) /*0x1039abb75*/
    {
      if ( v8 != 32 ) /*0x1039abb90*/
        this->.appNonce.. /* +8 */ = v7 + 2; /*0x1039abb96*/
    }
    else
    {
      std::vector<unsigned char>::__append(a1: this); /*0x1039abb82*/
      v7 = *(_OWORD **)this; /*0x1039abb87*/
    }
    v7[1] = xmmword_10957A546; /*0x1039abba1*/
    *v7 = RBX::Security::RakPeerCrypto::kPublicEphemeralEarlyTestKey; /*0x1039abbac*/
  }
  return this; /*0x1039abbb2*/
}

// Address: 0x1039abbda | Name: __ZN3RBX8Security13RakPeerCrypto20getServerDualKeyInfoEj
RBX::Security::RakPeerCrypto *__fastcall RBX::Security::RakPeerCrypto::getServerDualKeyInfo(
        RBX::Security::RakPeerCrypto *this,
        int a2)
{
  __int64 Instance; // r14
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // rdx
  __int64 v12; // rcx
  _OWORD *v13; // rax
  _BYTE *v14; // rcx
  _OWORD *v15; // rdx
  unsigned __int64 v16; // rcx
  _OWORD *v17; // rax
  _OWORD *v18; // rax
  void *v20[3]; // [rsp+0h] [rbp-F0h] BYREF
  void *v21[3]; // [rsp+18h] [rbp-D8h]
  void *v22[4]; // [rsp+30h] [rbp-C0h] BYREF
  __int128 v23; // [rsp+50h] [rbp-A0h] BYREF
  void *v24; // [rsp+60h] [rbp-90h]
  void *v25[3]; // [rsp+68h] [rbp-88h]
  void *v26[4]; // [rsp+80h] [rbp-70h] BYREF
  void *v27[4]; // [rsp+A0h] [rbp-50h] BYREF
  void *v28[6]; // [rsp+C0h] [rbp-30h] BYREF

  memset(v26, 0, 24); /*0x1039abbf6*/
  memset(v27, 0, 24); /*0x1039abbfe*/
  memset(v28, 0, 24); /*0x1039abc06*/
  memset(v22, 0, 24); /*0x1039abc11*/
  if ( a2 != 0 ) /*0x1039abc1a*/
  {
    Instance = RBX::Security::KeyRing::getInstance(this); /*0x1039abc28*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v23, a2: "", a3: v5, a4: v6); /*0x1039abc39*/
    RBX::Security::KeyRing::getKeyForConsumption( /*0x1039abc59*/
      a1: (__int64)v20,
      a2: Instance,
      a3: RBX::Security::kRakNetEarlyPublicKeyName,
      a4: a2,
      a5: (unsigned __int8 *)&v23);
    if ( v26[0] != nullptr ) /*0x1039abc65*/
    {
      v26[1] = v26[0]; /*0x1039abc67*/
      operator delete(a1: v26[0]); /*0x1039abc6b*/
    }
    qmemcpy(v26, v20, 24); /*0x1039abc77*/
    memset(v20, 0, sizeof(v20)); /*0x1039abc89*/
    if ( (v23 & 1) != 0 ) /*0x1039abca2*/
      operator delete(a1: v24); /*0x1039abcab*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v23, a2: "", a3: v7, a4: v8); /*0x1039abcbe*/
    RBX::Security::KeyRing::getKeyForConsumption( /*0x1039abcde*/
      a1: (__int64)v20,
      a2: Instance,
      a3: RBX::Security::kRakNetEarlySecretKeyName,
      a4: a2,
      a5: (unsigned __int8 *)&v23);
    if ( v27[0] != nullptr ) /*0x1039abcea*/
    {
      v27[1] = v27[0]; /*0x1039abcec*/
      operator delete(a1: v27[0]); /*0x1039abcf0*/
    }
    qmemcpy(v27, v20, 24); /*0x1039abcfc*/
    memset(v20, 0, sizeof(v20)); /*0x1039abd0e*/
    if ( (v23 & 1) != 0 ) /*0x1039abd27*/
      operator delete(a1: v24); /*0x1039abd30*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v23, a2: "", a3: v9, a4: v10); /*0x1039abd43*/
    RBX::Security::KeyRing::getKeyForConsumption( /*0x1039abd65*/
      a1: (__int64)v20,
      a2: Instance,
      a3: RBX::Security::kRakNetEphemeralEarlyPublicKeyName,
      a4: 1,
      a5: (unsigned __int8 *)&v23);
    if ( v28[0] != nullptr ) /*0x1039abd71*/
    {
      v28[1] = v28[0]; /*0x1039abd73*/
      operator delete(a1: v28[0]); /*0x1039abd77*/
    }
    qmemcpy(v28, v20, 24); /*0x1039abd83*/
    memset(v20, 0, sizeof(v20)); /*0x1039abd95*/
    if ( (v23 & 1) != 0 ) /*0x1039abdae*/
      operator delete(a1: v24); /*0x1039abdb7*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v23, a2: "", a3: v11, a4: v12); /*0x1039abdca*/
    RBX::Security::KeyRing::getKeyForConsumption( /*0x1039abdec*/
      a1: (__int64)v20,
      a2: Instance,
      a3: RBX::Security::kRakNetEphemeralEarlySecretKeyName,
      a4: 1,
      a5: (unsigned __int8 *)&v23);
    qmemcpy(v22, v20, 24); /*0x1039abdff*/
    memset(v20, 0, sizeof(v20)); /*0x1039abe10*/
    if ( (v23 & 1) != 0 ) /*0x1039abe29*/
      operator delete(a1: v24); /*0x1039abe36*/
  }
  else
  {
    std::vector<unsigned char>::__append(a1: v26); /*0x1039abe49*/
    v13 = v27[0]; /*0x1039abe4e*/
    v14 = v27[1]; /*0x1039abe52*/
    v15 = v26[0]; /*0x1039abe56*/
    *((_OWORD *)v26[0] + 1) = xmmword_10957A566; /*0x1039abe61*/
    *v15 = RBX::Security::RakPeerCrypto::kPublicEarlyTestKey; /*0x1039abe6c*/
    v16 = v14 - (_BYTE *)v13; /*0x1039abe6f*/
    if ( v16 > 0x1F ) /*0x1039abe76*/
    {
      if ( v16 != 32 ) /*0x1039abe93*/
        v27[1] = v13 + 2; /*0x1039abe99*/
    }
    else
    {
      std::vector<unsigned char>::__append(a1: v27); /*0x1039abe84*/
      v13 = v27[0]; /*0x1039abe89*/
    }
    v13[1] = xmmword_10957A586; /*0x1039abea4*/
    *v13 = RBX::Security::RakPeerCrypto::kSecretEarlyTestKey; /*0x1039abeaf*/
    v17 = v28[0]; /*0x1039abeb2*/
    if ( (void *)((char *)v28[1] - (char *)v28[0]) > (void *)0x1F ) /*0x1039abec1*/
    {
      if ( (void *)((char *)v28[1] - (char *)v28[0]) != (void *)32 ) /*0x1039abede*/
        v28[1] = (char *)v28[0] + 32; /*0x1039abee4*/
    }
    else
    {
      std::vector<unsigned char>::__append(a1: v28); /*0x1039abecf*/
      v17 = v28[0]; /*0x1039abed4*/
    }
    v17[1] = xmmword_10957A546; /*0x1039abeef*/
    *v17 = RBX::Security::RakPeerCrypto::kPublicEphemeralEarlyTestKey; /*0x1039abefa*/
    std::vector<unsigned char>::__append(a1: v22); /*0x1039abf09*/
    v18 = v22[0]; /*0x1039abf0e*/
    *((_OWORD *)v22[0] + 1) = xmmword_10957A5A6; /*0x1039abf1c*/
    *v18 = RBX::Security::RakPeerCrypto::kSecretEphemeralEarlyTestKey; /*0x1039abf27*/
  }
  qmemcpy(v20, v26, sizeof(v20)); /*0x1039abf35*/
  memset(v26, 0, 24); /*0x1039abf43*/
  qmemcpy(v21, v27, sizeof(v21)); /*0x1039abf51*/
  memset(v27, 0, 24); /*0x1039abf5d*/
  v23 = *(_OWORD *)v28; /*0x1039abf70*/
  v24 = v28[2]; /*0x1039abf77*/
  memset(v28, 0, 24); /*0x1039abf7b*/
  qmemcpy(v25, v22, sizeof(v25)); /*0x1039abf8a*/
  memset(v22, 0, 24); /*0x1039abf99*/
  std::pair<std::pair<std::vector<unsigned char>,std::vector<unsigned char>>,std::pair<std::vector<unsigned char>,std::vector<unsigned char>>>::pair[abi:ne200100]<true,0>(a1: this); /*0x1039abfaa*/
  if ( v25[0] != nullptr ) /*0x1039abfb9*/
  {
    v25[1] = v25[0]; /*0x1039abfbb*/
    operator delete(a1: v25[0]); /*0x1039abfbf*/
  }
  if ( (_QWORD)v23 != 0 ) /*0x1039abfce*/
  {
    *((_QWORD *)&v23 + 1) = v23; /*0x1039abfd0*/
    operator delete(a1: (void *)v23); /*0x1039abfd7*/
  }
  if ( v21[0] != nullptr ) /*0x1039abfe6*/
  {
    v21[1] = v21[0]; /*0x1039abfe8*/
    operator delete(a1: v21[0]); /*0x1039abfef*/
  }
  if ( v20[0] != nullptr ) /*0x1039abffe*/
  {
    v20[1] = v20[0]; /*0x1039ac000*/
    operator delete(a1: v20[0]); /*0x1039ac007*/
  }
  if ( v22[0] != nullptr ) /*0x1039ac016*/
  {
    v22[1] = v22[0]; /*0x1039ac018*/
    operator delete(a1: v22[0]); /*0x1039ac01f*/
  }
  if ( v28[0] != nullptr ) /*0x1039ac02b*/
  {
    v28[1] = v28[0]; /*0x1039ac02d*/
    operator delete(a1: v28[0]); /*0x1039ac031*/
  }
  if ( v27[0] != nullptr ) /*0x1039ac03d*/
  {
    v27[1] = v27[0]; /*0x1039ac03f*/
    operator delete(a1: v27[0]); /*0x1039ac043*/
  }
  if ( v26[0] != nullptr ) /*0x1039ac04f*/
  {
    v26[1] = v26[0]; /*0x1039ac051*/
    operator delete(a1: v26[0]); /*0x1039ac055*/
  }
  return this; /*0x1039ac05d*/
}

// Address: 0x1039ac10c | Name: __ZN3RBX8Security13RakPeerCrypto28getRbxTransportClientKeyInfoEb
RBX::Security::RakPeerCrypto *__fastcall RBX::Security::RakPeerCrypto::getRbxTransportClientKeyInfo(
        RBX::Security::RakPeerCrypto *this,
        int a2)
{
  _OWORD *v3; // rax
  __int64 Instance; // rax
  RBX::Security::KeyRing *v6; // [rsp+8h] [rbp-28h] BYREF
  RBX::Security::KeyRing *v7; // [rsp+10h] [rbp-20h]

  if ( a2 != 0 ) /*0x1039ac11c*/
  {
    std::vector<unsigned char>::vector[abi:ne200100](a1: &v6, a2: 32); /*0x1039ac12a*/
    *(_OWORD *)this = 0; /*0x1039ac132*/
    this->.txRakNonce.. /* +16 */ = 0; /*0x1039ac135*/
    std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x1039ac14d*/
      a1: this,
      a2: v6,
      a3: v7,
      a4: v7 - v6);
    this->.rxRakNonce /* +24 */ = 0; /*0x1039ac152*/
    *((_BYTE *)this + 28) /* +28: NO 2022 FIELD */ = 1; /*0x1039ac159*/
    if ( v6 != nullptr ) /*0x1039ac164*/
    {
      v7 = v6; /*0x1039ac166*/
      operator delete(a1: v6); /*0x1039ac16a*/
    }
    v3 = *(_OWORD **)this; /*0x1039ac16f*/
    v3[1] = xmmword_10957A5C6; /*0x1039ac179*/
    *v3 = RBX::Security::RakPeerCrypto::kRbxTransportPublicEphemeralEarlyTestKey; /*0x1039ac184*/
  }
  else
  {
    Instance = RBX::Security::KeyRing::getInstance(this); /*0x1039ac189*/
    RBX::Security::KeyRing::getKeyForProduction( /*0x1039ac19b*/
      a1: (__int64)this,
      a2: Instance,
      a3: RBX::Security::kRbxTransportEphemeralEarlyPublicKeyName);
  }
  return this; /*0x1039ac1a3*/
}

// Address: 0x1039ac1ca | Name: __ZN3RBX8Security13RakPeerCrypto28getRbxTransportServerKeyInfoEb
RBX::Security::RakPeerCrypto *__fastcall RBX::Security::RakPeerCrypto::getRbxTransportServerKeyInfo(
        RBX::Security::RakPeerCrypto *this,
        int a2)
{
  _OWORD *v3; // rax
  _OWORD *v4; // rcx
  __int64 Instance; // r14
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int128 v11; // [rsp+0h] [rbp-80h] BYREF
  __int64 v12; // [rsp+10h] [rbp-70h]
  unsigned __int8 v13[16]; // [rsp+20h] [rbp-60h] BYREF
  void *v14; // [rsp+30h] [rbp-50h]
  _OWORD *v15; // [rsp+38h] [rbp-48h] BYREF
  void *v16[2]; // [rsp+40h] [rbp-40h]
  void *v17[6]; // [rsp+50h] [rbp-30h] BYREF

  if ( a2 != 0 ) /*0x1039ac1dc*/
  {
    std::vector<unsigned char>::vector[abi:ne200100](a1: v17, a2: 32); /*0x1039ac1e7*/
    std::vector<unsigned char>::vector[abi:ne200100](a1: &v15, a2: 32); /*0x1039ac1f5*/
    v3 = v17[0]; /*0x1039ac1fa*/
    *((_OWORD *)v17[0] + 1) = xmmword_10957A5C6; /*0x1039ac205*/
    *v3 = RBX::Security::RakPeerCrypto::kRbxTransportPublicEphemeralEarlyTestKey; /*0x1039ac210*/
    v4 = v15; /*0x1039ac213*/
    *v15 = RBX::Security::RakPeerCrypto::kRbxTransportSecretEphemeralEarlyTestKey; /*0x1039ac21e*/
    v4[1] = xmmword_10957A5E6; /*0x1039ac228*/
    this->.__vftable /* +0 */= v3; /*0x1039ac22c*/
    *(_OWORD *)((char *)this + 8 /* +8 = .appNonce.. (std::_Atomic_integral<unsigned __int64,8>, 8B) -- SIZE CONFLICT, see --verify */) = *(_OWORD *)&v17[1]; /*0x1039ac233*/
    this->.rxRakNonce /* +24 */ = v4; /*0x1039ac237*/
    *((_OWORD *)this + 2) = *(_OWORD *)v16; /*0x1039ac23f*/
  }
  else
  {
    Instance = RBX::Security::KeyRing::getInstance(this); /*0x1039ac24d*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v15, a2: "", a3: v6, a4: v7); /*0x1039ac25e*/
    RBX::Security::KeyRing::getKeyForConsumption( /*0x1039ac279*/
      a1: (__int64)v17,
      a2: Instance,
      a3: RBX::Security::kRbxTransportEphemeralEarlyPublicKeyName,
      a4: 1,
      a5: (unsigned __int8 *)&v15);
    std::string::basic_string[abi:ne200100]<0>(a1: v13, a2: "", a3: v8, a4: v9); /*0x1039ac289*/
    RBX::Security::KeyRing::getKeyForConsumption( /*0x1039ac2a5*/
      a1: (__int64)&v11,
      a2: Instance,
      a3: RBX::Security::kRbxTransportEphemeralEarlySecretKeyName,
      a4: 1,
      a5: v13);
    qmemcpy(this, v17, 24); /*0x1039ac2ae*/
    memset(v17, 0, 24); /*0x1039ac2c2*/
    *(_OWORD *)((char *)this + 24 /* +24 = .rxRakNonce (unsigned __int64, 8B) */) = v11; /*0x1039ac2ca*/
    *((_QWORD *)this + 5) /* +40 likely .isServer -- UNVERIFIED */ = v12; /*0x1039ac2d2*/
    v12 = 0; /*0x1039ac2d6*/
    v11 = 0; /*0x1039ac2da*/
    if ( (v13[0] & 1) != 0 ) /*0x1039ac2e2*/
    {
      operator delete(a1: v14); /*0x1039ac2e8*/
      if ( v17[0] != nullptr ) /*0x1039ac2f4*/
      {
        v17[1] = v17[0]; /*0x1039ac2f6*/
        operator delete(a1: v17[0]); /*0x1039ac2fa*/
      }
    }
    if ( ((unsigned __int8)v15 & 1) != 0 ) /*0x1039ac303*/
      operator delete(a1: v16[1]); /*0x1039ac309*/
  }
  return this; /*0x1039ac311*/
}

// Address: 0x1039d1306 | Name: __ZN3RBX8Security13RakPeerCryptoD1Ev
void __fastcall RBX::Security::RakPeerCrypto::~RakPeerCrypto(RBX::Security::RakPeerCrypto *this)
{
  this->.__vftable /* +0 */= off_10C9030B8; /*0x1039d1316*/
  std::shared_ptr<RBX::Security::EarlyAuthData>::~shared_ptr[abi:ne200100](a1: (char *)this + 48 /* +48 = .earlyAuthData.._Ptr (RBX::Security::EarlyAuthData *, 8B) -- SIZE CONFLICT, see --verify */); /*0x1039d131d*/
  std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>::reset[abi:ne200100](a1: (char *)this + 32 /* +32 = .keyExchangeKeys (std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>, 8B) -- SIZE CONFLICT, see --verify */, a2: 0); /*0x1039d1331*/
}

// Address: 0x1039d1336 | Name: __ZN3RBX8Security13RakPeerCryptoD0Ev
void __fastcall RBX::Security::RakPeerCrypto::~RakPeerCrypto(RBX::Security::RakPeerCrypto *this)
{
  this->.__vftable /* +0 */= off_10C9030B8; /*0x1039d1346*/
  std::shared_ptr<RBX::Security::EarlyAuthData>::~shared_ptr[abi:ne200100](a1: (char *)this + 48 /* +48 = .earlyAuthData.._Ptr (RBX::Security::EarlyAuthData *, 8B) -- SIZE CONFLICT, see --verify */); /*0x1039d134d*/
  std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>::reset[abi:ne200100](a1: (char *)this + 32 /* +32 = .keyExchangeKeys (std::unique_ptr<RBX::Security::SessionCrypto::KeyExchangeKeys>, 8B) -- SIZE CONFLICT, see --verify */, a2: 0); /*0x1039d1358*/
  operator delete(a1: this); /*0x1039d1366*/
}

// END RakPeerCrypto part 1/1, 18 functions
