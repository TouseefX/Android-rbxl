// KeyRing -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 38 functions


// Address: 0x10761c37a | Name: __ZN3RBX8Security7KeyRing7findKeyERKNSt3__16vectorINS1_7KeyInfoENS2_9allocatorIS4_EEEEj
__int64 __fastcall RBX::Security::KeyRing::findKey(__int64 *a1, int a2)
{
  __int64 result; // rax
  __int64 v3; // rcx

  result = *a1; /*0x10761c37a*/
  v3 = a1[1]; /*0x10761c37d*/
  if ( *a1 != v3 ) /*0x10761c384*/
  {
    do /*0x10761c396*/
    {
      if ( *(_DWORD *)(result + 24) == a2 ) /*0x10761c38d*/
        break; /*0x10761c38d*/
      result += 32; /*0x10761c38f*/
    }
    while ( result != v3 ); /*0x10761c396*/
  }
  return result; /*0x10761c399*/
}

// Address: 0x10761c45a | Name: __ZN3RBX8Security7KeyRing11parseConfigERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEb
__int64 __fastcall RBX::Security::KeyRing::parseConfig(RBX::json::Value *a1, __int64 a2, int a3)
{
  __int64 v4; // rsi
  int v5; // ecx
  int v6; // r8d
  int v7; // r9d
  RBX::Security::KeyRing *v8; // rdi
  __int64 Instance; // rax
  __int64 v10; // r14
  volatile signed __int64 *v11; // rbx
  char v12; // bl
  __int64 v13; // rbx
  int v14; // r8d
  int v15; // r9d
  RBX::Security::KeyRing *v16; // rdi
  char *v17; // rcx
  __int64 v18; // rax
  __int64 v19; // r15
  volatile signed __int64 *v20; // rbx
  const char *v21; // rdx
  __int64 v22; // rdx
  __int64 v23; // rcx
  __int64 v24; // rdx
  __int64 v25; // rcx
  __int64 i; // rbx
  bool v27; // dl
  char *v28; // rbx
  char v29; // dl
  int v30; // r8d
  int v31; // r9d
  RBX::Security::KeyRing *v32; // rdi
  const char *v33; // rcx
  const char *ParseError; // rax
  __int64 v35; // rax
  volatile signed __int64 *v36; // r14
  const char *v37; // rdx
  size_t v38; // rcx
  size_t v39; // rsi
  char v40; // al
  size_t v41; // rdx
  boost::shared_mutex *v42; // r14
  size_t v43; // rbx
  char *v44; // r15
  _BYTE *v45; // rsi
  char *v46; // rsi
  __int64 v47; // rdx
  __int64 v48; // rax
  char v49; // bl
  char v50; // r15
  void *v51; // r12
  RBX::json::Value *v52; // rbx
  _QWORD v54[5]; // [rsp+18h] [rbp-338h] BYREF
  unsigned __int8 v55; // [rsp+40h] [rbp-310h] BYREF
  char v56; // [rsp+41h] [rbp-30Fh] BYREF
  __int64 v57; // [rsp+48h] [rbp-308h]
  void *v58; // [rsp+50h] [rbp-300h]
  RBX::json::Value *v59; // [rsp+58h] [rbp-2F8h]
  __int64 v60; // [rsp+60h] [rbp-2F0h] BYREF
  volatile signed __int64 *v61; // [rsp+68h] [rbp-2E8h]
  void *__dst; // [rsp+70h] [rbp-2E0h]
  __int128 v63; // [rsp+78h] [rbp-2D8h] BYREF
  void *v64; // [rsp+88h] [rbp-2C8h]
  char v65; // [rsp+90h] [rbp-2C0h]
  _BYTE v66[4]; // [rsp+98h] [rbp-2B8h]
  int v67; // [rsp+9Ch] [rbp-2B4h]
  bool v68[16]; // [rsp+A0h] [rbp-2B0h] BYREF
  void *v69; // [rsp+B0h] [rbp-2A0h]
  _BYTE v70[24]; // [rsp+B8h] [rbp-298h] BYREF
  _BYTE v71[24]; // [rsp+D0h] [rbp-280h] BYREF
  _BYTE v72[528]; // [rsp+E8h] [rbp-268h] BYREF
  _BYTE v73[14]; // [rsp+2F8h] [rbp-58h]
  unsigned __int8 v74; // [rsp+308h] [rbp-48h] BYREF
  _BYTE __src[7]; // [rsp+309h] [rbp-47h] BYREF
  size_t __len; // [rsp+310h] [rbp-40h]
  void *v77; // [rsp+318h] [rbp-38h]

  v67 = a3; /*0x10761c46e*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x10761c48b*/
    v4 = *(_QWORD *)(a2 + 16); /*0x10761c491*/
  else
    v4 = a2 + 1; /*0x10761c497*/
  RBX::json::parse(a1: v54, a2: v4); /*0x10761c4a3*/
  if ( (unsigned __int8)RBX::json::Document::hasError(this: (RBX::json::Document *)v54) != 0 ) /*0x10761c4b6*/
  {
    v8 = DFLog::KeyRing; /*0x10761c4bc*/
    if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u ) /*0x10761c4d1*/
    {
      LOBYTE(v5) = (unsigned __int8)DFLog::KeyRing < 6u; /*0x10761c4cc*/
      FLog::FastLogFormatted( /*0x10761c4e8*/
        a1: (_DWORD)DFLog::KeyRing,
        a2: qword_10D826CD8,
        a3: (unsigned int)"[DFLog::KeyRing] Config is invalid json, can only use old config",
        a4: v5,
        a5: v6,
        a6: v7);
      LOBYTE(v8) = (_BYTE)DFLog::KeyRing; /*0x10761c4ed*/
    }
    if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v8 != 0 ) /*0x10761c504*/
    {
      Instance = RBX::Security::KeyRing::getInstance(this: v8); /*0x10761c50a*/
      if ( Instance != 0 ) /*0x10761c512*/
      {
        v10 = *(_QWORD *)(Instance + 616); /*0x10761c518*/
        *(_QWORD *)&v63 = v10; /*0x10761c51f*/
        v11 = *(volatile signed __int64 **)(Instance + 624); /*0x10761c526*/
        *((_QWORD *)&v63 + 1) = v11; /*0x10761c52d*/
        if ( v11 != nullptr ) /*0x10761c537*/
          _InterlockedIncrement64(v11 + 1); /*0x10761c53d*/
        else
          v11 = nullptr; /*0x10761c91a*/
        if ( v10 != 0 ) /*0x10761c91f*/
        {
          RBX::format(this: (RBX *)v68, a2: "Config is invalid json, can only use old config"); /*0x10761c931*/
          (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, bool *))(*(_QWORD *)v10 + 8LL))( /*0x10761c94a*/
            a1: v10,
            a2: &DFLog::KeyRing,
            a3: v68);
          if ( v68[0] ) /*0x10761c94d*/
            operator delete(a1: v69); /*0x10761c95d*/
        }
        if ( v11 != nullptr && _InterlockedExchangeAdd64(v11 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761c977*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v11 + 16))(a1: v11); /*0x10761c97f*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v11); /*0x10761c985*/
        }
      }
    }
    ParseError = (const char *)RBX::json::Document::getParseError(this: (RBX::json::Document *)v54); /*0x10761c991*/
    RBX::format(this: (RBX *)v68, a2: "badParse:%s", ParseError); /*0x10761c9a9*/
    if ( (*((_BYTE *)a1 + 632) & 1) != 0 ) /*0x10761c9bd*/
      operator delete(a1: *((void **)a1 + 81)); /*0x10761c9c6*/
    *((_QWORD *)a1 + 81) = v69; /*0x10761c9d2*/
    *(_OWORD *)((char *)a1 + 632) = *(_OWORD *)v68; /*0x10761c9dd*/
    LODWORD(v28) = 0; /*0x10761c9e0*/
    goto LABEL_121; /*0x10761c9e2*/
  }
  v54[4] = RBX::json::Value::members(this: (RBX::json::Value *)v54); /*0x10761c55a*/
  RBX::json::MemberIteratorHelper::begin(this: (RBX::json::MemberIteratorHelper *)&v74); /*0x10761c561*/
  v59 = a1; /*0x10761c578*/
  while ( 1 )
  {
    RBX::json::MemberIteratorHelper::end(this: (RBX::json::MemberIteratorHelper *)v68); /*0x10761c589*/
    v12 = RBX::json::MemberIterator::operator!=(a1: &v74, a2: v68); /*0x10761c599*/
    RBX::json::MemberIterator::~MemberIterator(this: (RBX::json::MemberIterator *)v68); /*0x10761c59e*/
    if ( v12 == 0 ) /*0x10761c5a5*/
      break; /*0x10761c5a5*/
    RBX::json::MemberIterator::name(this: (RBX::json::MemberIterator *)&v63); /*0x10761c5b1*/
    if ( (_BYTE)`guard variable for'RBX::Security::KeyRing::parseConfig(std::string const&,bool)::kKnownKeys == 0 /*0x10761c73b*/
      && __cxa_guard_acquire(a1: &`guard variable for'RBX::Security::KeyRing::parseConfig(std::string const&,bool)::kKnownKeys) != 0 )
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v68, a2: "creationTime", a3: v22, a4: v23); /*0x10761c74b*/
      std::string::basic_string[abi:ne200100]<0>(a1: v70, a2: "applications", a3: v24, a4: v25); /*0x10761c75e*/
      RBX::Security::KeyRing::parseConfig(std::string const&,bool)::kKnownKeys = 0; /*0x10761c766*/
      qword_10D4D0E88 = 0; /*0x10761c76d*/
      std::vector<std::string>::__init_with_size[abi:ne200100]<std::string const*,std::string const*>( /*0x10761c78e*/
        a1: &RBX::Security::KeyRing::parseConfig(std::string const&,bool)::kKnownKeys,
        a2: v68,
        a3: v71,
        a4: 2);
      for ( i = 48; i != 0; i -= 24 ) /*0x10761c793*/
      {
        if ( (*((_BYTE *)&v64 + i) & 1) != 0 ) /*0x10761c7a0*/
          operator delete(a1: *(void **)&v66[i]); /*0x10761c7aa*/
      }
      __cxa_atexit( /*0x10761c7ca*/
        lpfunc: std::vector<std::string>::~vector[abi:ne200100],
        obj: &RBX::Security::KeyRing::parseConfig(std::string const&,bool)::kKnownKeys,
        lpdso_handle: (void *)&_mh_execute_header);
      __cxa_guard_release(a1: &`guard variable for'RBX::Security::KeyRing::parseConfig(std::string const&,bool)::kKnownKeys); /*0x10761c7d6*/
      a1 = v59; /*0x10761c7db*/
    }
    v13 = *((_QWORD *)&RBX::Security::KeyRing::parseConfig(std::string const&,bool)::kKnownKeys + 1); /*0x10761c5c4*/
    if ( v13 == std::__find[abi:ne200100]<std::string const*,std::string const*,std::string,std::__identity>(
                  a1: RBX::Security::KeyRing::parseConfig(std::string const&,bool)::kKnownKeys,
                  a2: *((_QWORD *)&RBX::Security::KeyRing::parseConfig(std::string const&,bool)::kKnownKeys + 1),
                  a3: &v63,
                  a4: v68) )
    {
      v16 = DFLog::KeyRing; /*0x10761c607*/
      if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u )
      {
        v17 = (char *)&v63 + 1; /*0x10761c62a*/
        if ( (v63 & 1) != 0 ) /*0x10761c631*/
          LODWORD(v17) = (_DWORD)v64; /*0x10761c633*/
        FLog::FastLogFormatted(
          a1: (_DWORD)DFLog::KeyRing,
          a2: qword_10D826CD8,
          a3: (unsigned int)"[DFLog::KeyRing] Config has unknown key : %s.",
          a4: (_DWORD)v17,
          a5: v14,
          a6: v15);
        LOBYTE(v16) = (_BYTE)DFLog::KeyRing; /*0x10761c64f*/
      }
      if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v16 != 0 )
      {
        v18 = RBX::Security::KeyRing::getInstance(this: v16); /*0x10761c664*/
        if ( v18 != 0 )
        {
          v19 = *(_QWORD *)(v18 + 616); /*0x10761c672*/
          v60 = v19; /*0x10761c679*/
          v20 = *(volatile signed __int64 **)(v18 + 624); /*0x10761c680*/
          v61 = v20; /*0x10761c687*/
          if ( v20 != nullptr ) /*0x10761c691*/
            _InterlockedIncrement64(v20 + 1); /*0x10761c693*/
          else
            v20 = nullptr; /*0x10761c69a*/
          if ( v19 != 0 )
          {
            v21 = (char *)&v63 + 1; /*0x10761c6a8*/
            if ( (v63 & 1) != 0 ) /*0x10761c6af*/
              v21 = (const char *)v64; /*0x10761c6b1*/
            RBX::format(this: (RBX *)v68, a2: "Config has unknown key : %s.", v21);
            (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, bool *))(*(_QWORD *)v19 + 8LL))( /*0x10761c6d9*/
              a1: v19,
              a2: &DFLog::KeyRing,
              a3: v68);
            if ( v68[0] ) /*0x10761c6dc*/
              operator delete(a1: v69); /*0x10761c6ec*/
          }
          a1 = v59; /*0x10761c6f4*/
          if ( v20 != nullptr && _InterlockedExchangeAdd64(v20 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761c711*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v20 + 16))(a1: v20); /*0x10761c71d*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v20); /*0x10761c723*/
          }
        }
      }
    }
    if ( (v63 & 1) != 0 ) /*0x10761c5ec*/
      operator delete(a1: v64); /*0x10761c5f5*/
    RBX::json::MemberIterator::operator++(a1: &v74); /*0x10761c5fd*/
  }
  RBX::json::MemberIterator::~MemberIterator(this: (RBX::json::MemberIterator *)&v74); /*0x10761c7eb*/
  *(_QWORD *)v68 = RBX::json::Value::operator[](a1: v54, a2: "applications", a3: 12); /*0x10761c80f*/
  v68[8] = v27; /*0x10761c812*/
  RBX::Security::KeyRing::parseApplications(this: (RBX::Security::KeyRing *)&v63, a2: a1, a3: (bool)v68); /*0x10761c82a*/
  v28 = (char *)a1 + 632; /*0x10761c82f*/
  if ( (*((_BYTE *)a1 + 632) & 1) != 0 ) /*0x10761c83e*/
    operator delete(a1: *((void **)a1 + 81)); /*0x10761c847*/
  *((_QWORD *)a1 + 81) = v64; /*0x10761c853*/
  *(_OWORD *)v28 = v63; /*0x10761c85e*/
  LOWORD(v63) = 0; /*0x10761c861*/
  v60 = RBX::json::Value::operator[](a1: v54, a2: "creationTime", a3: 12); /*0x10761c889*/
  LOBYTE(v61) = v29; /*0x10761c88c*/
  *(_OWORD *)v68 = 0; /*0x10761c899*/
  v69 = nullptr; /*0x10761c89c*/
  RBX::json::Value::getString(a1: &v74, a2: &v60, a3: v68); /*0x10761c8a8*/
  if ( v68[0] ) /*0x10761c8ad*/
    operator delete(a1: v69); /*0x10761c8bd*/
  v32 = DFLog::KeyRing; /*0x10761c8c2*/
  if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u )
  {
    if ( (v74 & 1) != 0 ) /*0x10761c8ee*/
    {
      if ( __len != 0 ) /*0x10761c90b*/
        LODWORD(v33) = (_DWORD)v77; /*0x10761c911*/
      else
        v33 = "unknown"; /*0x10761c9e7*/
    }
    else
    {
      v33 = "unknown"; /*0x10761c8f6*/
      if ( v74 != 0 ) /*0x10761c8fd*/
        v33 = __src; /*0x10761c8fd*/
    }
    FLog::FastLogFormatted(
      a1: (_DWORD)DFLog::KeyRing,
      a2: qword_10D826CD8,
      a3: (unsigned int)"[DFLog::KeyRing] Parsed config created at: %s.",
      a4: (_DWORD)v33,
      a5: v30,
      a6: v31);
    LOBYTE(v32) = (_BYTE)DFLog::KeyRing; /*0x10761c9fc*/
  }
  if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v32 != 0 )
  {
    v35 = RBX::Security::KeyRing::getInstance(this: v32); /*0x10761ca19*/
    if ( v35 != 0 )
    {
      v28 = *(char **)(v35 + 616); /*0x10761ca27*/
      v60 = (__int64)v28; /*0x10761ca2e*/
      v36 = *(volatile signed __int64 **)(v35 + 624); /*0x10761ca35*/
      v61 = v36; /*0x10761ca3c*/
      if ( v36 != nullptr ) /*0x10761ca46*/
        _InterlockedIncrement64(v36 + 1); /*0x10761ca48*/
      else
        v36 = nullptr; /*0x10761ca4f*/
      if ( v28 != nullptr )
      {
        if ( (v74 & 1) != 0 ) /*0x10761ca5c*/
        {
          if ( __len != 0 ) /*0x10761ca76*/
            v37 = (const char *)v77; /*0x10761ca78*/
          else
            v37 = "unknown"; /*0x10761ca7e*/
        }
        else
        {
          v37 = "unknown"; /*0x10761ca64*/
          if ( v74 != 0 ) /*0x10761ca6b*/
            v37 = __src; /*0x10761ca6b*/
        }
        RBX::format(this: (RBX *)v68, a2: "Parsed config created at: %s.", v37);
        (*(void (__fastcall **)(char *, RBX::Security::KeyRing **, bool *))(*(_QWORD *)v28 + 8LL))( /*0x10761caae*/
          a1: v28,
          a2: &DFLog::KeyRing,
          a3: v68);
        if ( v68[0] ) /*0x10761cab1*/
          operator delete(a1: v69); /*0x10761cac1*/
      }
      if ( v36 != nullptr && _InterlockedExchangeAdd64(v36 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761cadb*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v36 + 16))(a1: v36); /*0x10761cae3*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v36); /*0x10761cae9*/
      }
    }
  }
  if ( (_BYTE)v67 != 0 ) /*0x10761caf9*/
  {
    v38 = __len; /*0x10761cafb*/
    v39 = v74 >> 1; /*0x10761cb06*/
    v40 = v74 & 1; /*0x10761cb09*/
  }
  else
  {
    v39 = v74 >> 1; /*0x10761cb0f*/
    v40 = v74 & 1; /*0x10761cb11*/
    v38 = __len; /*0x10761cb13*/
    v41 = __len; /*0x10761cb17*/
    if ( (v74 & 1) == 0 ) /*0x10761cb1a*/
      v41 = v74 >> 1; /*0x10761cb1a*/
    if ( v41 == 0 ) /*0x10761cb21*/
      goto LABEL_114; /*0x10761cb21*/
  }
  *(_OWORD *)v68 = 0; /*0x10761cb31*/
  v69 = nullptr; /*0x10761cb34*/
  if ( v40 != 0 ) /*0x10761cb3e*/
    v39 = v38; /*0x10761cb3e*/
  std::string::reserve(a1: v68, a2: v39 + 33); /*0x10761cb46*/
  v42 = (RBX::json::Value *)((char *)a1 + 64); /*0x10761cb4b*/
  boost::shared_mutex::lock(this: (RBX::json::Value *)((char *)a1 + 64)); /*0x10761cb60*/
  if ( (v74 & 1) != 0 ) /*0x10761cb6c*/
    v43 = __len; /*0x10761cb6e*/
  else
    v43 = v74 >> 1; /*0x10761cb74*/
  std::string::basic_string[abi:ne200100](a1: &v60, a2: v43 + 1); /*0x10761cb88*/
  if ( (v60 & 1) != 0 ) /*0x10761cb94*/
    v44 = (char *)__dst; /*0x10761cb96*/
  else
    v44 = (char *)&v60 + 1; /*0x10761cb9f*/
  if ( v43 != 0 ) /*0x10761cba9*/
  {
    if ( (v74 & 1) != 0 ) /*0x10761cbaf*/
      v45 = v77; /*0x10761cbb1*/
    else
      v45 = __src; /*0x10761cbb7*/
    memmove(__dst: v44, __src: v45, __len: v43); /*0x10761cbc1*/
  }
  *(_WORD *)&v44[v43] = 35; /*0x10761cbc6*/
  RBX::Crypto::convertToHex(a1: &v55, a2: (char *)v59 + 544, a3: 16, a4: 1); /*0x10761cbec*/
  if ( (v55 & 1) != 0 ) /*0x10761cbfb*/
  {
    v46 = (char *)v58; /*0x10761cbfd*/
    v47 = v57; /*0x10761cc04*/
  }
  else
  {
    v47 = v55 >> 1; /*0x10761cc0d*/
    v46 = &v56; /*0x10761cc0f*/
  }
  v48 = std::string::append(a1: &v60, a2: v46, a3: v47); /*0x10761cc1d*/
  v49 = *(_BYTE *)v48; /*0x10761cc22*/
  v50 = *(_BYTE *)(v48 + 1); /*0x10761cc24*/
  *(_QWORD *)&v73[6] = *(_QWORD *)(v48 + 8); /*0x10761cc2c*/
  *(_QWORD *)v73 = *(_QWORD *)(v48 + 2); /*0x10761cc34*/
  v51 = *(void **)(v48 + 16); /*0x10761cc38*/
  *(_OWORD *)v48 = 0; /*0x10761cc3f*/
  *(_QWORD *)(v48 + 16) = 0; /*0x10761cc42*/
  if ( v68[0] ) /*0x10761cc4a*/
    operator delete(a1: v69); /*0x10761cc5a*/
  v68[0] = v49; /*0x10761cc5f*/
  v68[1] = v50; /*0x10761cc65*/
  *(_QWORD *)&v68[2] = *(_QWORD *)v73; /*0x10761cc74*/
  *(_QWORD *)&v68[8] = *(_QWORD *)&v73[6]; /*0x10761cc7b*/
  v69 = v51; /*0x10761cc82*/
  if ( (v55 & 1) != 0 ) /*0x10761cc90*/
    operator delete(a1: v58); /*0x10761cc99*/
  v52 = v59; /*0x10761cca5*/
  if ( (v60 & 1) != 0 ) /*0x10761ccac*/
    operator delete(a1: __dst); /*0x10761ccb5*/
  v28 = (char *)v52 + 560; /*0x10761ccba*/
  std::string::operator=(a1: v28, a2: v68); /*0x10761cccb*/
  boost::shared_mutex::unlock(this: v42); /*0x10761ccd3*/
  if ( v68[0] ) /*0x10761ccd8*/
    operator delete(a1: v69); /*0x10761cce8*/
LABEL_114:
  if ( ((unsigned __int8)v67 | (unsigned __int8)DFFlag::KeyRingUsingDynamicConfigTelemetry ^ 1) == 0 && v65 == 1 ) /*0x10761cd04*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)18,std::enable_if<false,void>>( /*0x10761cd14*/
      a1: v68,
      a2: &RBX::Telemetry::kKeyRingUsingDynamicConfig);
    v28 = v72; /*0x10761cd19*/
    RBX::Telemetry::FieldsContainer::addField(a1: v72, a2: "KeyRingUsingDynamicConfig", a3: 25, a4: 1, a5: 1); /*0x10761cd3a*/
    RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v72); /*0x10761cd42*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v68); /*0x10761cd4e*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v68); /*0x10761cd61*/
  }
  LOBYTE(v28) = v65; /*0x10761cd66*/
  if ( (v74 & 1) != 0 ) /*0x10761cd70*/
    operator delete(a1: v77); /*0x10761cd76*/
  if ( (v63 & 1) != 0 ) /*0x10761cd82*/
    operator delete(a1: v64); /*0x10761cd8b*/
LABEL_121:
  RBX::json::Document::~Document(this: (RBX::json::Document *)v54); /*0x10761cd90*/
  return (unsigned int)v28; /*0x10761cdae*/
}

// Address: 0x10761cfda | Name: __ZN3RBX8Security7KeyRing14getDebugLoggerEv
RBX::Security::KeyRing *__fastcall RBX::Security::KeyRing::getDebugLogger(RBX::Security::KeyRing *this)
{
  __int64 Instance; // rax
  __int64 v3; // rcx

  Instance = RBX::Security::KeyRing::getInstance(this); /*0x10761cfe3*/
  if ( Instance != 0 ) /*0x10761cfeb*/
  {
    v3 = *(_QWORD *)(Instance + 624); /*0x10761cfed*/
    *(_OWORD *)this = *(_OWORD *)(Instance + 616); /*0x10761cffb*/
    if ( v3 != 0 ) /*0x10761d001*/
      _InterlockedIncrement64((volatile signed __int64 *)(v3 + 8)); /*0x10761d003*/
  }
  else
  {
    *(_OWORD *)this = 0; /*0x10761d00d*/
  }
  return this; /*0x10761d017*/
}

// Address: 0x10761d01c | Name: __ZN3RBX8Security7KeyRing17parseApplicationsERKNS_4json5ValueEb
RBX::Security::KeyRing *__fastcall RBX::Security::KeyRing::parseApplications(
        RBX::Security::KeyRing *this,
        const RBX::json::Value *a2,
        RBX::json::Value *a3,
        int a4)
{
  __int64 v6; // rdx
  __int64 v7; // rcx
  int v8; // r8d
  int v9; // r9d
  char i; // r15
  char v11; // r14
  const char *v12; // rdx
  RBX::Security::KeyRing *v13; // rdi
  __int64 v14; // rax
  __int64 v15; // r14
  volatile signed __int64 *v16; // rbx
  __int64 v17; // rdx
  __int64 v18; // rcx
  int v19; // r8d
  int v20; // r9d
  RBX::Security::KeyRing *v21; // rdi
  __int64 Instance; // rax
  void *v23; // r14
  volatile signed __int64 *v24; // rbx
  void *v26[3]; // [rsp+28h] [rbp-A8h] BYREF
  RBX::Security::KeyRing *v27; // [rsp+40h] [rbp-90h]
  int v28; // [rsp+4Ch] [rbp-84h]
  __int128 v29; // [rsp+50h] [rbp-80h] BYREF
  void *v30; // [rsp+60h] [rbp-70h]
  char v31; // [rsp+68h] [rbp-68h]
  _QWORD v32[2]; // [rsp+70h] [rbp-60h] BYREF
  void *v33; // [rsp+80h] [rbp-50h]
  _BYTE v34[16]; // [rsp+90h] [rbp-40h] BYREF

  v28 = a4; /*0x10761d030*/
  if ( (unsigned __int8)RBX::json::Value::isObject(this: a3) != 0 ) /*0x10761d05b*/
  {
    v27 = this; /*0x10761d061*/
    RBX::json::Value::members(this: a3); /*0x10761d06b*/
    v29 = 0; /*0x10761d07d*/
    v30 = nullptr; /*0x10761d081*/
    v31 = 1; /*0x10761d089*/
    RBX::json::MemberIteratorHelper::begin(this: (RBX::json::MemberIteratorHelper *)v34); /*0x10761d091*/
    for ( i = 0; ; i = 1 ) /*0x10761d096*/
    {
      RBX::json::MemberIteratorHelper::end(this: (RBX::json::MemberIteratorHelper *)v32); /*0x10761d0b2*/
      v11 = RBX::json::MemberIterator::operator!=(a1: v34, a2: v32); /*0x10761d0c2*/
      RBX::json::MemberIterator::~MemberIterator(this: (RBX::json::MemberIterator *)v32); /*0x10761d0c8*/
      if ( v11 == 0 ) /*0x10761d0d0*/
        break; /*0x10761d0d0*/
      if ( (_BYTE)v28 != 0 ) /*0x10761d0dd*/
      {
        RBX::json::MemberIterator::name(this: (RBX::json::MemberIterator *)v32); /*0x10761d0e5*/
        v12 = (char *)v32 + 1; /*0x10761d0ee*/
        if ( (v32[0] & 1) != 0 ) /*0x10761d0f2*/
          v12 = (const char *)v33; /*0x10761d0f4*/
        RBX::format(this: (RBX *)v26, a2: "_%s", v12); /*0x10761d104*/
        if ( (v32[0] & 1) != 0 ) /*0x10761d10d*/
          operator delete(a1: v33); /*0x10761d113*/
      }
      else
      {
        RBX::json::MemberIterator::name(this: (RBX::json::MemberIterator *)v26); /*0x10761d120*/
      }
      RBX::json::MemberIterator::value(this: (RBX::json::MemberIterator *)v34); /*0x10761d128*/
      RBX::Security::KeyRing::parseApplication(this: (RBX *)v32); /*0x10761d14e*/
      RBX::Security::KeyRing::ParseResult::update(a1: &v29, a2: v32); /*0x10761d15a*/
      if ( (v32[0] & 1) != 0 ) /*0x10761d163*/
        operator delete(a1: v33); /*0x10761d169*/
      if ( ((__int64)v26[0] & 1) != 0 ) /*0x10761d175*/
        operator delete(a1: v26[2]); /*0x10761d17e*/
      RBX::json::MemberIterator::operator++(a1: v34); /*0x10761d189*/
    }
    RBX::json::MemberIterator::~MemberIterator(this: (RBX::json::MemberIterator *)v34); /*0x10761d21c*/
    if ( (i & 1) != 0 ) /*0x10761d225*/
    {
      this = v27; /*0x10761d22b*/
      *((_QWORD *)v27 + 2) = v30; /*0x10761d232*/
      *(_OWORD *)this = v29; /*0x10761d23a*/
      *((_BYTE *)this + 24) = v31; /*0x10761d241*/
    }
    else
    {
      v21 = DFLog::KeyRing; /*0x10761d24a*/
      LOBYTE(v18) = (unsigned __int8)DFLog::KeyRing < 6u; /*0x10761d25a*/
      this = v27; /*0x10761d264*/
      if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u ) /*0x10761d25f*/
      {
        FLog::FastLogFormatted( /*0x10761d27d*/
          a1: (_DWORD)DFLog::KeyRing,
          a2: qword_10D826CD8,
          a3: (unsigned int)"[DFLog::KeyRing] No applicaitons found.",
          a4: v18,
          a5: v19,
          a6: v20);
        LOBYTE(v21) = (_BYTE)DFLog::KeyRing; /*0x10761d282*/
      }
      if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v21 != 0 ) /*0x10761d299*/
      {
        Instance = RBX::Security::KeyRing::getInstance(this: v21); /*0x10761d29f*/
        if ( Instance != 0 ) /*0x10761d2a7*/
        {
          v23 = *(void **)(Instance + 616); /*0x10761d2ad*/
          v26[0] = v23; /*0x10761d2b4*/
          v24 = *(volatile signed __int64 **)(Instance + 624); /*0x10761d2bb*/
          v26[1] = (void *)v24; /*0x10761d2c2*/
          if ( v24 != nullptr ) /*0x10761d2cc*/
            _InterlockedIncrement64(v24 + 1); /*0x10761d2d2*/
          else
            v24 = nullptr; /*0x10761d37d*/
          if ( v23 != nullptr ) /*0x10761d382*/
          {
            RBX::format(this: (RBX *)v32, a2: "No applicaitons found."); /*0x10761d391*/
            (*(void (__fastcall **)(void *, RBX::Security::KeyRing **, _QWORD *))(*(_QWORD *)v23 + 8LL))( /*0x10761d3a7*/
              a1: v23,
              a2: &DFLog::KeyRing,
              a3: v32);
            if ( (v32[0] & 1) != 0 ) /*0x10761d3ae*/
              operator delete(a1: v33); /*0x10761d3b4*/
          }
          if ( v24 != nullptr && _InterlockedExchangeAdd64(v24 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761d3ce*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v24 + 16))(a1: v24); /*0x10761d3d6*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v24); /*0x10761d3dc*/
          }
        }
      }
      std::string::basic_string[abi:ne200100]<0>(a1: this, a2: "noApps", a3: v17, a4: v18); /*0x10761d3eb*/
      *((_BYTE *)this + 24) = 0; /*0x10761d3f0*/
      if ( (v29 & 1) != 0 ) /*0x10761d3f9*/
        operator delete(a1: v30); /*0x10761d403*/
    }
  }
  else
  {
    v13 = DFLog::KeyRing; /*0x10761d193*/
    LOBYTE(v7) = (unsigned __int8)DFLog::KeyRing < 6u; /*0x10761d1a3*/
    if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u ) /*0x10761d1a8*/
    {
      FLog::FastLogFormatted( /*0x10761d1bf*/
        a1: (_DWORD)DFLog::KeyRing,
        a2: qword_10D826CD8,
        a3: (unsigned int)"[DFLog::KeyRing] \"Applications\" invalid.",
        a4: v7,
        a5: v8,
        a6: v9);
      LOBYTE(v13) = (_BYTE)DFLog::KeyRing; /*0x10761d1c4*/
    }
    if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v13 != 0 ) /*0x10761d1db*/
    {
      v14 = RBX::Security::KeyRing::getInstance(this: v13); /*0x10761d1e1*/
      if ( v14 != 0 ) /*0x10761d1e9*/
      {
        v15 = *(_QWORD *)(v14 + 616); /*0x10761d1ef*/
        v32[0] = v15; /*0x10761d1f6*/
        v16 = *(volatile signed __int64 **)(v14 + 624); /*0x10761d1fa*/
        v32[1] = v16; /*0x10761d201*/
        if ( v16 != nullptr ) /*0x10761d208*/
          _InterlockedIncrement64(v16 + 1); /*0x10761d20e*/
        else
          v16 = nullptr; /*0x10761d2dc*/
        if ( v15 != 0 ) /*0x10761d2e1*/
        {
          RBX::format(this: (RBX *)&v29, a2: "\"Applications\" invalid."); /*0x10761d2f0*/
          (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __int128 *))(*(_QWORD *)v15 + 8LL))( /*0x10761d306*/
            a1: v15,
            a2: &DFLog::KeyRing,
            a3: &v29);
          if ( (v29 & 1) != 0 ) /*0x10761d30d*/
            operator delete(a1: v30); /*0x10761d313*/
        }
        if ( v16 != nullptr && _InterlockedExchangeAdd64(v16 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761d32d*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v16 + 16))(a1: v16); /*0x10761d335*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v16); /*0x10761d33b*/
        }
      }
    }
    std::string::basic_string[abi:ne200100]<0>(a1: this, a2: "appsNotObj", a3: v6, a4: v7); /*0x10761d34a*/
    *((_BYTE *)this + 24) = 0; /*0x10761d34f*/
  }
  return this; /*0x10761d36b*/
}

// Address: 0x10761d4e0 | Name: __ZN3RBX8Security7KeyRing16parseApplicationERKNS_4json5ValueERKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEE
RBX *__fastcall RBX::Security::KeyRing::parseApplication(RBX *this, __int64 a2, RBX::json::Value *a3, __int64 a4)
{
  RBX::json::Value *v5; // r12
  int v7; // r8d
  int v8; // r9d
  char v9; // r15
  __int64 v10; // r15
  int v11; // r8d
  int v12; // r9d
  RBX::Security::KeyRing *v13; // rdi
  char *v14; // rcx
  __int64 Instance; // rax
  __int64 v16; // r15
  volatile signed __int64 *v17; // r12
  const char *v18; // rdx
  __int64 v19; // rdx
  __int64 v20; // rcx
  __int64 v21; // rdx
  __int64 v22; // rcx
  __int64 v23; // rdx
  __int64 v24; // rcx
  __int64 i; // r15
  RBX::Security::KeyRing *v26; // rdi
  __int64 v27; // rcx
  char v28; // dl
  unsigned int v29; // ebx
  char v30; // dl
  unsigned int v31; // r14d
  char v32; // dl
  __int64 v34; // r12
  __int64 v35; // rax
  RBX *v36; // r15
  __int64 v37; // r14
  volatile signed __int64 *v38; // rbx
  const char *v39; // rdx
  const char *v40; // rdx
  __int64 v42; // [rsp+28h] [rbp-B8h]
  RBX::json::Value *v43; // [rsp+30h] [rbp-B0h]
  RBX *v44; // [rsp+38h] [rbp-A8h]
  _QWORD v45[2]; // [rsp+40h] [rbp-A0h] BYREF
  void *v46; // [rsp+50h] [rbp-90h]
  __int64 v47; // [rsp+58h] [rbp-88h] BYREF
  char v48; // [rsp+60h] [rbp-80h]
  void *v49; // [rsp+68h] [rbp-78h]
  _BYTE v50[24]; // [rsp+70h] [rbp-70h] BYREF
  _BYTE v51[24]; // [rsp+88h] [rbp-58h] BYREF
  _BYTE v52[16]; // [rsp+A0h] [rbp-40h] BYREF

  v5 = a3; /*0x10761d4f7*/
  if ( (unsigned __int8)RBX::json::Value::isObject(this: a3) != 0 )
  {
    v42 = a4; /*0x10761d522*/
    v44 = this; /*0x10761d529*/
    RBX::json::Value::members(this: v5); /*0x10761d533*/
    RBX::json::MemberIteratorHelper::begin(this: (RBX::json::MemberIteratorHelper *)v52); /*0x10761d546*/
    v43 = v5; /*0x10761d55d*/
    while ( 1 )
    {
      RBX::json::MemberIteratorHelper::end(this: (RBX::json::MemberIteratorHelper *)&v47); /*0x10761d56e*/
      v9 = RBX::json::MemberIterator::operator!=(a1: v52, a2: &v47); /*0x10761d57e*/
      RBX::json::MemberIterator::~MemberIterator(this: (RBX::json::MemberIterator *)&v47); /*0x10761d584*/
      if ( v9 == 0 ) /*0x10761d58c*/
        break; /*0x10761d58c*/
      RBX::json::MemberIterator::name(this: (RBX::json::MemberIterator *)v45); /*0x10761d598*/
      if ( (_BYTE)`guard variable for'RBX::Security::KeyRing::parseApplication(RBX::json::Value const&,std::string const&)::kKnownKeys == 0 /*0x10761d722*/
        && __cxa_guard_acquire(a1: &`guard variable for'RBX::Security::KeyRing::parseApplication(RBX::json::Value const&,std::string const&)::kKnownKeys) != 0 )
      {
        std::string::basic_string[abi:ne200100]<0>(a1: &v47, a2: "versions", a3: v19, a4: v20); /*0x10761d732*/
        std::string::basic_string[abi:ne200100]<0>(a1: v50, a2: "send", a3: v21, a4: v22); /*0x10761d745*/
        std::string::basic_string[abi:ne200100]<0>(a1: v51, a2: "revert", a3: v23, a4: v24); /*0x10761d758*/
        RBX::Security::KeyRing::parseApplication(RBX::json::Value const&,std::string const&)::kKnownKeys = 0; /*0x10761d760*/
        qword_10D4D0EA8 = 0; /*0x10761d767*/
        std::vector<std::string>::__init_with_size[abi:ne200100]<std::string const*,std::string const*>( /*0x10761d785*/
          a1: &RBX::Security::KeyRing::parseApplication(RBX::json::Value const&,std::string const&)::kKnownKeys,
          a2: &v47,
          a3: v52,
          a4: 3);
        for ( i = 9; i != 0; i -= 3 ) /*0x10761d78a*/
        {
          if ( (v45[i] & 1) != 0 ) /*0x10761d799*/
            operator delete(a1: *(void **)((char *)&v46 + i * 8)); /*0x10761d7a3*/
        }
        __cxa_atexit( /*0x10761d7c3*/
          lpfunc: std::vector<std::string>::~vector[abi:ne200100],
          obj: &RBX::Security::KeyRing::parseApplication(RBX::json::Value const&,std::string const&)::kKnownKeys,
          lpdso_handle: (void *)&_mh_execute_header);
        __cxa_guard_release(a1: &`guard variable for'RBX::Security::KeyRing::parseApplication(RBX::json::Value const&,std::string const&)::kKnownKeys); /*0x10761d7cf*/
        v5 = v43; /*0x10761d7d4*/
      }
      v10 = *((_QWORD *)&RBX::Security::KeyRing::parseApplication(RBX::json::Value const&,std::string const&)::kKnownKeys /*0x10761d5ab*/
            + 1);
      if ( v10 == std::__find[abi:ne200100]<std::string const*,std::string const*,std::string,std::__identity>(
                    a1: RBX::Security::KeyRing::parseApplication(RBX::json::Value const&,std::string const&)::kKnownKeys,
                    a2: *((_QWORD *)&RBX::Security::KeyRing::parseApplication(RBX::json::Value const&,std::string const&)::kKnownKeys
                    + 1),
                    a3: v45,
                    a4: &v47) )
      {
        v13 = DFLog::KeyRing; /*0x10761d5d0*/
        if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u )
        {
          v14 = (char *)v45 + 1; /*0x10761d5f3*/
          if ( (v45[0] & 1) != 0 ) /*0x10761d5fa*/
            LODWORD(v14) = (_DWORD)v46; /*0x10761d5fc*/
          FLog::FastLogFormatted(
            a1: (_DWORD)DFLog::KeyRing,
            a2: qword_10D826CD8,
            a3: (unsigned int)"[DFLog::KeyRing] Application has unknown key : %s.",
            a4: (_DWORD)v14,
            a5: v11,
            a6: v12);
          LOBYTE(v13) = (_BYTE)DFLog::KeyRing; /*0x10761d618*/
        }
        if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v13 != 0 )
        {
          Instance = RBX::Security::KeyRing::getInstance(this: v13); /*0x10761d635*/
          if ( Instance != 0 )
          {
            v16 = *(_QWORD *)(Instance + 616); /*0x10761d643*/
            v17 = *(volatile signed __int64 **)(Instance + 624); /*0x10761d651*/
            if ( v17 != nullptr ) /*0x10761d662*/
              _InterlockedIncrement64(v17 + 1); /*0x10761d664*/
            else
              v17 = nullptr; /*0x10761d66c*/
            if ( v16 != 0 )
            {
              v18 = (char *)v45 + 1; /*0x10761d67b*/
              if ( (v45[0] & 1) != 0 ) /*0x10761d682*/
                v18 = (const char *)v46; /*0x10761d684*/
              RBX::format(this: (RBX *)&v47, a2: "Application has unknown key : %s.", v18);
              (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __int64 *))(*(_QWORD *)v16 + 8LL))( /*0x10761d6ac*/
                a1: v16,
                a2: &DFLog::KeyRing,
                a3: &v47);
              if ( (v47 & 1) != 0 ) /*0x10761d6b6*/
                operator delete(a1: v49); /*0x10761d6bc*/
            }
            if ( v17 != nullptr && _InterlockedExchangeAdd64(v17 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761d6d7*/
            {
              (*(void (__fastcall **)(volatile signed __int64 *))(*v17 + 16))(a1: v17); /*0x10761d6e0*/
              std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v17); /*0x10761d6e6*/
            }
          }
          v5 = v43; /*0x10761d6eb*/
        }
      }
      if ( (v45[0] & 1) != 0 ) /*0x10761d6f9*/
        operator delete(a1: v46); /*0x10761d702*/
      RBX::json::MemberIterator::operator++(a1: v52); /*0x10761d70a*/
    }
    RBX::json::MemberIterator::~MemberIterator(this: (RBX::json::MemberIterator *)v52); /*0x10761d81d*/
    v47 = RBX::json::Value::operator[](a1: v5, a2: "send", a3: 4); /*0x10761d83d*/
    v48 = v28; /*0x10761d840*/
    v29 = RBX::json::Value::getInteger<unsigned int>(); /*0x10761d848*/
    v47 = RBX::json::Value::operator[](a1: v5, a2: "revert", a3: 6); /*0x10761d865*/
    v48 = v30; /*0x10761d868*/
    v31 = RBX::json::Value::getInteger<unsigned int>(); /*0x10761d870*/
    v47 = RBX::json::Value::operator[](a1: v5, a2: "versions", a3: 8); /*0x10761d88e*/
    v48 = v32; /*0x10761d891*/
    RBX::Security::KeyRing::parseVersions(a1: v44, a2, a3: &v47, a4: v42, a5: v29, a6: v31); /*0x10761d8b2*/
    return v44; /*0x10761d8b7*/
  }
  else
  {
    v26 = DFLog::KeyRing; /*0x10761d7e0*/
    if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u )
    {
      if ( (*(_BYTE *)a4 & 1) != 0 ) /*0x10761d80a*/
        v27 = *(_QWORD *)(a4 + 16); /*0x10761d810*/
      else
        LODWORD(v27) = a4 + 1; /*0x10761d8c3*/
      FLog::FastLogFormatted(
        a1: (_DWORD)DFLog::KeyRing,
        a2: qword_10D826CD8,
        a3: (unsigned int)"[DFLog::KeyRing] Application invalid : %s.",
        a4: v27,
        a5: v7,
        a6: v8);
      LOBYTE(v26) = (_BYTE)DFLog::KeyRing; /*0x10761d8d5*/
    }
    if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v26 != 0 )
    {
      v34 = a4; /*0x10761d8f2*/
      v35 = RBX::Security::KeyRing::getInstance(this: v26); /*0x10761d8f5*/
      if ( v35 != 0 )
      {
        v36 = this; /*0x10761d903*/
        v37 = *(_QWORD *)(v35 + 616); /*0x10761d906*/
        v45[0] = v37; /*0x10761d90d*/
        v38 = *(volatile signed __int64 **)(v35 + 624); /*0x10761d914*/
        v45[1] = v38; /*0x10761d91b*/
        if ( v38 != nullptr ) /*0x10761d925*/
          _InterlockedIncrement64(v38 + 1); /*0x10761d927*/
        else
          v38 = nullptr; /*0x10761d92e*/
        if ( v37 != 0 )
        {
          v39 = (*(_BYTE *)v34 & 1) != 0 ? *(const char **)(v34 + 16) : (const char *)(v34 + 1);
          RBX::format(this: (RBX *)&v47, a2: "Application invalid : %s.", v39);
          (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __int64 *))(*(_QWORD *)v37 + 8LL))( /*0x10761d972*/
            a1: v37,
            a2: &DFLog::KeyRing,
            a3: &v47);
          if ( (v47 & 1) != 0 ) /*0x10761d97c*/
            operator delete(a1: v49); /*0x10761d982*/
        }
        this = v36; /*0x10761d98a*/
        if ( v38 != nullptr && _InterlockedExchangeAdd64(v38 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761d99f*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v38 + 16))(a1: v38); /*0x10761d9a7*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v38); /*0x10761d9ad*/
        }
      }
      a4 = v34; /*0x10761d9b2*/
    }
    if ( (*(_BYTE *)a4 & 1) != 0 ) /*0x10761d9b8*/
      v40 = *(const char **)(a4 + 16); /*0x10761d9ba*/
    else
      v40 = (const char *)(a4 + 1); /*0x10761d9c3*/
    RBX::format(this, a2: "badApp:%s", v40); /*0x10761d9d5*/
    *((_BYTE *)this + 24) = 0; /*0x10761d9dd*/
    return this; /*0x10761d9da*/
  }
}

// Address: 0x10761dadc | Name: __ZN3RBX8Security7KeyRing13parseVersionsERKNS_4json5ValueERKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEjj
RBX *__fastcall RBX::Security::KeyRing::parseVersions(
        __int64 a1,
        __int64 a2,
        RBX::json::Value *a3,
        __int64 a4,
        unsigned int a5,
        unsigned int a6)
{
  int v8; // ecx
  int v9; // r8d
  int v10; // r9d
  char v11; // r14
  char v12; // r15
  char v13; // bl
  int v14; // r8d
  int v15; // r9d
  char v16; // dl
  char v17; // r12
  int v18; // r13d
  bool v19; // al
  bool v20; // r13
  RBX::Security::KeyRing *v21; // rdi
  __int64 v22; // rax
  __int64 v23; // r14
  volatile signed __int64 *v24; // rbx
  bool v25; // zf
  RBX *v26; // rbx
  RBX::Security::KeyRing *v27; // rdi
  __int64 v28; // rcx
  __int64 Instance; // rax
  char v30; // r12
  __int64 v31; // r14
  volatile signed __int64 *v32; // rbx
  const char *v33; // rdx
  const char *v34; // rdx
  const char *v35; // rdx
  RBX::Security::KeyRing *v36; // rdi
  __int64 v37; // rcx
  __int64 v38; // rax
  char v39; // r15
  __int64 v40; // r14
  volatile signed __int64 *v41; // rbx
  const char *v42; // rdx
  const char *v43; // rdx
  RBX::Security::KeyRing *v44; // rdi
  __int64 v45; // rcx
  __int64 v46; // rax
  __int64 v47; // r14
  volatile signed __int64 *v48; // rbx
  const char *v49; // rdx
  const char *v50; // rdx
  __int64 v51; // r14
  boost::shared_mutex *v52; // rbx
  __int64 v53; // rax
  __int128 v54; // xmm1
  __int64 v55; // rcx
  __int64 v57; // [rsp+8h] [rbp-B8h] BYREF
  __int64 v58; // [rsp+10h] [rbp-B0h] BYREF
  __int64 v59; // [rsp+18h] [rbp-A8h]
  __int128 v60; // [rsp+20h] [rbp-A0h] BYREF
  __int64 v61; // [rsp+30h] [rbp-90h]
  __int64 v62; // [rsp+40h] [rbp-80h] BYREF
  volatile signed __int64 *v63; // [rsp+48h] [rbp-78h]
  unsigned int v64; // [rsp+50h] [rbp-70h]
  unsigned int v65; // [rsp+54h] [rbp-6Ch]
  RBX *v66; // [rsp+58h] [rbp-68h]
  __int64 v67; // [rsp+60h] [rbp-60h] BYREF
  char v68; // [rsp+68h] [rbp-58h]
  void *v69; // [rsp+70h] [rbp-50h]
  char v70; // [rsp+78h] [rbp-48h]
  int v71; // [rsp+80h] [rbp-40h]
  char v72; // [rsp+84h] [rbp-3Ch]
  __int64 v73; // [rsp+88h] [rbp-38h]
  bool v74; // [rsp+97h] [rbp-29h]

  v64 = a6; /*0x10761daf0*/
  v65 = a5; /*0x10761daf4*/
  v73 = a4; /*0x10761daf8*/
  v59 = a2; /*0x10761daff*/
  v66 = (RBX *)a1; /*0x10761db13*/
  if ( (unsigned __int8)RBX::json::Value::isArray(this: a3) != 0 )
  {
    *(_OWORD *)a1 = 0; /*0x10761db20*/
    *(_QWORD *)(a1 + 16) = 0; /*0x10761db26*/
    *(_BYTE *)(a1 + 24) = 1; /*0x10761db2a*/
    v61 = 0; /*0x10761db2f*/
    v60 = 0; /*0x10761db36*/
    v57 = RBX::json::Value::elements(this: a3); /*0x10761db4c*/
    v58 = RBX::json::ArrayIteratorHelper::begin(this: (RBX::json::ArrayIteratorHelper *)&v57); /*0x10761db5b*/
    v11 = 0; /*0x10761db5f*/
    v12 = 0; /*0x10761db62*/
    v13 = 0; /*0x10761db65*/
    while ( 1 ) /*0x10761db73*/
    {
      v67 = RBX::json::ArrayIteratorHelper::end(this: (RBX::json::ArrayIteratorHelper *)&v57); /*0x10761db73*/
      if ( (unsigned __int8)RBX::json::ArrayIterator::operator!=(a1: &v58, a2: &v67) == 0 ) /*0x10761db85*/
        break; /*0x10761db85*/
      v62 = RBX::json::ArrayIterator::operator*(a1: &v58); /*0x10761db97*/
      LOBYTE(v63) = v16; /*0x10761db9b*/
      RBX::Security::KeyRing::parseVersion(a1: &v67, a2: v59, a3: &v62, a4: &v60, a5: v65, a6: v64); /*0x10761dbbb*/
      v17 = v72; /*0x10761dbc3*/
      v18 = v71; /*0x10761dbc7*/
      RBX::Security::KeyRing::ParseResult::update(a1: v66, a2: &v67); /*0x10761dbcf*/
      v19 = v18 == v64; /*0x10761dbd8*/
      v20 = v18 == v65; /*0x10761dbdf*/
      if ( (v67 & 1) != 0 ) /*0x10761dbe7*/
      {
        v74 = v19; /*0x10761dbed*/
        operator delete(a1: v69); /*0x10761dbf0*/
        v19 = v74; /*0x10761dbf5*/
      }
      v11 |= v19; /*0x10761dbf8*/
      v12 |= v20; /*0x10761dbfb*/
      v13 = v17 | v13 & 1; /*0x10761dc01*/
      RBX::json::ArrayIterator::operator++(a1: &v58); /*0x10761dc0e*/
    }
    v25 = (v13 & 1) == 0; /*0x10761dca3*/
    v26 = v66; /*0x10761dca6*/
    if ( v25 )
    {
      v27 = DFLog::KeyRing; /*0x10761dcb0*/
      if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u )
      {
        if ( (*(_BYTE *)v73 & 1) != 0 ) /*0x10761dcda*/
          v28 = *(_QWORD *)(v73 + 16); /*0x10761dcdc*/
        else
          LODWORD(v28) = v73 + 1; /*0x10761dce2*/
        FLog::FastLogFormatted(
          a1: (_DWORD)DFLog::KeyRing,
          a2: qword_10D826CD8,
          a3: (unsigned int)"[DFLog::KeyRing] Application has no allowed versions : %s.",
          a4: v28,
          a5: v14,
          a6: v15);
        LOBYTE(v27) = (_BYTE)DFLog::KeyRing; /*0x10761dcf4*/
      }
      if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v27 != 0 )
      {
        Instance = RBX::Security::KeyRing::getInstance(this: v27); /*0x10761dd11*/
        if ( Instance != 0 )
        {
          v30 = v11; /*0x10761dd1f*/
          v31 = *(_QWORD *)(Instance + 616); /*0x10761dd22*/
          v62 = v31; /*0x10761dd29*/
          v32 = *(volatile signed __int64 **)(Instance + 624); /*0x10761dd2d*/
          v63 = v32; /*0x10761dd34*/
          if ( v32 != nullptr ) /*0x10761dd3b*/
            _InterlockedIncrement64(v32 + 1); /*0x10761dd41*/
          else
            v32 = nullptr; /*0x10761dddf*/
          if ( v31 != 0 )
          {
            v34 = (*(_BYTE *)v73 & 1) != 0 ? *(const char **)(v73 + 16) : (const char *)(v73 + 1);
            RBX::format(this: (RBX *)&v67, a2: "Application has no allowed versions : %s.", v34);
            (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __int64 *))(*(_QWORD *)v31 + 8LL))( /*0x10761de1c*/
              a1: v31,
              a2: &DFLog::KeyRing,
              a3: &v67);
            if ( (v67 & 1) != 0 ) /*0x10761de23*/
              operator delete(a1: v69); /*0x10761de29*/
          }
          v11 = v30; /*0x10761de31*/
          if ( v32 != nullptr && _InterlockedExchangeAdd64(v32 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761de46*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v32 + 16))(a1: v32); /*0x10761de4e*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v32); /*0x10761de54*/
          }
        }
        v26 = v66; /*0x10761de59*/
      }
      if ( (*(_BYTE *)v73 & 1) != 0 ) /*0x10761de64*/
        v35 = *(const char **)(v73 + 16); /*0x10761de66*/
      else
        v35 = (const char *)(v73 + 1); /*0x10761de6c*/
      RBX::format(this: (RBX *)&v67, a2: "noAllowed:%s", v35); /*0x10761de7d*/
      v70 = 0; /*0x10761de86*/
      RBX::Security::KeyRing::ParseResult::update(a1: v26, a2: &v67); /*0x10761de8d*/
      if ( (v67 & 1) != 0 ) /*0x10761de96*/
        operator delete(a1: v69); /*0x10761de9c*/
    }
    if ( (v12 & 1) == 0 )
    {
      v36 = DFLog::KeyRing; /*0x10761deab*/
      if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u )
      {
        if ( (*(_BYTE *)v73 & 1) != 0 ) /*0x10761ded5*/
          v37 = *(_QWORD *)(v73 + 16); /*0x10761ded7*/
        else
          LODWORD(v37) = v73 + 1; /*0x10761dedd*/
        FLog::FastLogFormatted(
          a1: (_DWORD)DFLog::KeyRing,
          a2: qword_10D826CD8,
          a3: (unsigned int)"[DFLog::KeyRing] Application sendVersion not in versions : %s.",
          a4: v37,
          a5: v14,
          a6: v15);
        LOBYTE(v36) = (_BYTE)DFLog::KeyRing; /*0x10761deef*/
      }
      if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v36 != 0 )
      {
        v38 = RBX::Security::KeyRing::getInstance(this: v36); /*0x10761df0c*/
        if ( v38 != 0 )
        {
          v39 = v11; /*0x10761df1a*/
          v40 = *(_QWORD *)(v38 + 616); /*0x10761df1d*/
          v62 = v40; /*0x10761df24*/
          v41 = *(volatile signed __int64 **)(v38 + 624); /*0x10761df28*/
          v63 = v41; /*0x10761df2f*/
          if ( v41 != nullptr ) /*0x10761df36*/
            _InterlockedIncrement64(v41 + 1); /*0x10761df38*/
          else
            v41 = nullptr; /*0x10761df3f*/
          if ( v40 != 0 )
          {
            v42 = (*(_BYTE *)v73 & 1) != 0 ? *(const char **)(v73 + 16) : (const char *)(v73 + 1);
            RBX::format(this: (RBX *)&v67, a2: "Application sendVersion not in versions : %s.", v42);
            (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __int64 *))(*(_QWORD *)v40 + 8LL))( /*0x10761df7c*/
              a1: v40,
              a2: &DFLog::KeyRing,
              a3: &v67);
            if ( (v67 & 1) != 0 ) /*0x10761df83*/
              operator delete(a1: v69); /*0x10761df89*/
          }
          v11 = v39; /*0x10761df91*/
          if ( v41 != nullptr && _InterlockedExchangeAdd64(v41 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761dfa6*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v41 + 16))(a1: v41); /*0x10761dfae*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v41); /*0x10761dfb4*/
          }
        }
        v26 = v66; /*0x10761dfb9*/
      }
      if ( (*(_BYTE *)v73 & 1) != 0 ) /*0x10761dfc4*/
        v43 = *(const char **)(v73 + 16); /*0x10761dfc6*/
      else
        v43 = (const char *)(v73 + 1); /*0x10761dfcc*/
      RBX::format(this: (RBX *)&v67, a2: "noSend:%s", v43); /*0x10761dfdd*/
      v70 = 0; /*0x10761dfe6*/
      RBX::Security::KeyRing::ParseResult::update(a1: v26, a2: &v67); /*0x10761dfed*/
      if ( (v67 & 1) != 0 ) /*0x10761dff6*/
        operator delete(a1: v69); /*0x10761dffc*/
    }
    if ( (v11 & 1) == 0 )
    {
      v44 = DFLog::KeyRing; /*0x10761e00b*/
      if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u )
      {
        if ( (*(_BYTE *)v73 & 1) != 0 ) /*0x10761e035*/
          v45 = *(_QWORD *)(v73 + 16); /*0x10761e037*/
        else
          LODWORD(v45) = v73 + 1; /*0x10761e03d*/
        FLog::FastLogFormatted(
          a1: (_DWORD)DFLog::KeyRing,
          a2: qword_10D826CD8,
          a3: (unsigned int)"[DFLog::KeyRing] Application revertVersion not in versions : %s.",
          a4: v45,
          a5: v14,
          a6: v15);
        LOBYTE(v44) = (_BYTE)DFLog::KeyRing; /*0x10761e04f*/
      }
      if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v44 != 0 )
      {
        v46 = RBX::Security::KeyRing::getInstance(this: v44); /*0x10761e06c*/
        if ( v46 != 0 )
        {
          v47 = *(_QWORD *)(v46 + 616); /*0x10761e07a*/
          v62 = v47; /*0x10761e081*/
          v48 = *(volatile signed __int64 **)(v46 + 624); /*0x10761e085*/
          v63 = v48; /*0x10761e08c*/
          if ( v48 != nullptr ) /*0x10761e093*/
            _InterlockedIncrement64(v48 + 1); /*0x10761e095*/
          else
            v48 = nullptr; /*0x10761e09c*/
          if ( v47 != 0 )
          {
            v49 = (*(_BYTE *)v73 & 1) != 0 ? *(const char **)(v73 + 16) : (const char *)(v73 + 1);
            RBX::format(this: (RBX *)&v67, a2: "Application revertVersion not in versions : %s.", v49);
            (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __int64 *))(*(_QWORD *)v47 + 8LL))( /*0x10761e0d9*/
              a1: v47,
              a2: &DFLog::KeyRing,
              a3: &v67);
            if ( (v67 & 1) != 0 ) /*0x10761e0e0*/
              operator delete(a1: v69); /*0x10761e0e6*/
          }
          if ( v48 != nullptr && _InterlockedExchangeAdd64(v48 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761e100*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v48 + 16))(a1: v48); /*0x10761e108*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v48); /*0x10761e10e*/
          }
        }
        v26 = v66; /*0x10761e113*/
      }
      if ( (*(_BYTE *)v73 & 1) != 0 ) /*0x10761e11e*/
        v50 = *(const char **)(v73 + 16); /*0x10761e120*/
      else
        v50 = (const char *)(v73 + 1); /*0x10761e126*/
      RBX::format(this: (RBX *)&v67, a2: "noRevert:%s", v50); /*0x10761e137*/
      v70 = 0; /*0x10761e140*/
      RBX::Security::KeyRing::ParseResult::update(a1: v26, a2: &v67); /*0x10761e147*/
      if ( (v67 & 1) != 0 ) /*0x10761e150*/
        operator delete(a1: v69); /*0x10761e156*/
    }
    if ( *((_BYTE *)v26 + 24) == 1 ) /*0x10761e15f*/
    {
      v51 = v59; /*0x10761e165*/
      v52 = (boost::shared_mutex *)(v59 + 64); /*0x10761e16c*/
      v67 = v59 + 64; /*0x10761e170*/
      v68 = 1; /*0x10761e174*/
      boost::shared_mutex::lock(this: (boost::shared_mutex *)(v59 + 64)); /*0x10761e17b*/
      v62 = v73; /*0x10761e18c*/
      v53 = std::__hash_table<std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>( /*0x10761e1a0*/
              a1: v51 + 24,
              a2: v73,
              a3: std::piecewise_construct,
              a4: &v62,
              a5: &v58);
      *(_DWORD *)(v53 + 64) = v65; /*0x10761e1a8*/
      *(_DWORD *)(v53 + 68) = v64; /*0x10761e1ae*/
      v54 = *(_OWORD *)(v53 + 40); /*0x10761e1b8*/
      *(_OWORD *)(v53 + 40) = v60; /*0x10761e1bc*/
      v60 = v54; /*0x10761e1c0*/
      v55 = *(_QWORD *)(v53 + 56); /*0x10761e1c7*/
      *(_QWORD *)(v53 + 56) = v61; /*0x10761e1d2*/
      v61 = v55; /*0x10761e1d6*/
      boost::shared_mutex::unlock(this: v52); /*0x10761e1e0*/
      v26 = v66; /*0x10761e1e5*/
    }
    v67 = (__int64)&v60; /*0x10761e1f4*/
    std::vector<RBX::Security::KeyRing::KeyInfo>::__destroy_vector::operator()[abi:ne200100](); /*0x10761e1f7*/
  }
  else
  {
    v21 = DFLog::KeyRing; /*0x10761dc18*/
    if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u ) /*0x10761dc2d*/
    {
      LOBYTE(v8) = (unsigned __int8)DFLog::KeyRing < 6u; /*0x10761dc28*/
      FLog::FastLogFormatted( /*0x10761dc44*/
        a1: (_DWORD)DFLog::KeyRing,
        a2: qword_10D826CD8,
        a3: (unsigned int)"[DFLog::KeyRing] \"Versions\" invalid.",
        a4: v8,
        a5: v9,
        a6: v10);
      LOBYTE(v21) = (_BYTE)DFLog::KeyRing; /*0x10761dc49*/
    }
    if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v21 != 0 ) /*0x10761dc60*/
    {
      v22 = RBX::Security::KeyRing::getInstance(this: v21); /*0x10761dc66*/
      if ( v22 != 0 ) /*0x10761dc6e*/
      {
        v23 = *(_QWORD *)(v22 + 616); /*0x10761dc74*/
        *(_QWORD *)&v60 = v23; /*0x10761dc7b*/
        v24 = *(volatile signed __int64 **)(v22 + 624); /*0x10761dc82*/
        *((_QWORD *)&v60 + 1) = v24; /*0x10761dc89*/
        if ( v24 != nullptr ) /*0x10761dc93*/
          _InterlockedIncrement64(v24 + 1); /*0x10761dc99*/
        else
          v24 = nullptr; /*0x10761dd4b*/
        if ( v23 != 0 ) /*0x10761dd50*/
        {
          RBX::format(this: (RBX *)&v67, a2: "\"Versions\" invalid."); /*0x10761dd5f*/
          (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __int64 *))(*(_QWORD *)v23 + 8LL))( /*0x10761dd75*/
            a1: v23,
            a2: &DFLog::KeyRing,
            a3: &v67);
          if ( (v67 & 1) != 0 ) /*0x10761dd7c*/
            operator delete(a1: v69); /*0x10761dd82*/
        }
        if ( v24 != nullptr && _InterlockedExchangeAdd64(v24 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761dd9c*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v24 + 16))(a1: v24); /*0x10761dda4*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v24); /*0x10761ddaa*/
        }
      }
    }
    v26 = v66; /*0x10761ddb6*/
    if ( (*(_BYTE *)v73 & 1) != 0 ) /*0x10761ddba*/
      v33 = *(const char **)(v73 + 16); /*0x10761ddbc*/
    else
      v33 = (const char *)(v73 + 1); /*0x10761ddc2*/
    RBX::format(this: v66, a2: "verNotArray:%s", v33); /*0x10761ddd1*/
    *((_BYTE *)v66 + 24) = 0; /*0x10761ddd6*/
  }
  return v26; /*0x10761e1ff*/
}

// Address: 0x10761e2d6 | Name: __ZN3RBX8Security7KeyRing12parseVersionERKNS_4json5ValueERNSt3__16vectorINS1_7KeyInfoENS6_9allocatorIS8_EEEEjj
__int64 __fastcall RBX::Security::KeyRing::parseVersion(
        __int64 a1,
        __int64 a2,
        RBX::json::Value *a3,
        __int64 *a4,
        int a5,
        int a6)
{
  __int64 v8; // rdx
  __int64 v9; // rcx
  char v10; // r14
  __int64 v11; // r14
  int v12; // r8d
  int v13; // r9d
  RBX::Security::KeyRing *v14; // rdi
  char *v15; // rcx
  __int64 Instance; // rax
  void *v17; // r14
  volatile signed __int64 *v18; // r12
  const char *v19; // rdx
  __int64 v20; // rdx
  __int64 v21; // rcx
  __int64 v22; // rdx
  __int64 v23; // rcx
  __int64 v24; // rdx
  __int64 v25; // rcx
  __int64 v26; // rdx
  __int64 v27; // rcx
  __int64 v28; // rdx
  __int64 v29; // rcx
  __int64 i; // r14
  char v31; // dl
  __int64 v32; // rdx
  __int64 v33; // rcx
  int v34; // r8d
  int v35; // r9d
  int v36; // r13d
  char v37; // dl
  unsigned __int8 Bool; // bl
  char v39; // dl
  char *v40; // rdi
  __int64 v41; // rsi
  RBX::Security::KeyRing *v42; // rdi
  __int64 v43; // rax
  __int64 v44; // r14
  volatile signed __int64 *v45; // rbx
  __int64 v46; // rdx
  int v47; // r9d
  __int64 v48; // rcx
  __int64 v49; // rax
  void *v50; // r8
  __int64 v51; // rax
  __int64 v52; // rdx
  RBX::Security::KeyRing *v53; // rdi
  __int64 v54; // rax
  void *v55; // rbx
  volatile signed __int64 *v56; // rax
  RBX::Security::KeyRing *v57; // rdi
  __int64 v58; // rax
  void *v59; // r14
  volatile signed __int64 *v60; // rbx
  char v61; // dl
  char v62; // al
  unsigned int v63; // edx
  __int64 v64; // rdx
  __int64 v65; // rsi
  RBX::Security::KeyRing *v66; // rdi
  __int64 v67; // rax
  void *v68; // rbx
  volatile signed __int64 *v69; // rax
  bool v70; // zf
  void *v71; // rdi
  char *v72; // rcx
  unsigned __int64 v73; // rsi
  char *v74; // rsi
  _BYTE *v75; // r14
  _BYTE *v76; // rdx
  __int64 v79; // [rsp+18h] [rbp-128h]
  RBX::json::Value *v83; // [rsp+30h] [rbp-110h]
  __int64 v84; // [rsp+38h] [rbp-108h] BYREF
  volatile signed __int64 *v85; // [rsp+40h] [rbp-100h]
  void *v86; // [rsp+48h] [rbp-F8h]
  void *__dst[2]; // [rsp+50h] [rbp-F0h] BYREF
  __int64 v88; // [rsp+60h] [rbp-E0h]
  _QWORD __src[2]; // [rsp+70h] [rbp-D0h] BYREF
  void *v90; // [rsp+80h] [rbp-C0h]
  void *v92[2]; // [rsp+90h] [rbp-B0h] BYREF
  void *v93; // [rsp+A0h] [rbp-A0h]
  int v94; // [rsp+A8h] [rbp-98h] BYREF
  unsigned __int8 v95; // [rsp+ACh] [rbp-94h]
  char v96[24]; // [rsp+C0h] [rbp-80h] BYREF
  char v97[24]; // [rsp+D8h] [rbp-68h] BYREF
  char v98[24]; // [rsp+F0h] [rbp-50h] BYREF
  char v99[8]; // [rsp+108h] [rbp-38h] BYREF

  if ( (unsigned __int8)RBX::json::Value::isObject(this: a3) != 0 )
  {
    v83 = a3; /*0x10761e32a*/
    RBX::json::Value::members(this: a3); /*0x10761e334*/
    RBX::json::MemberIteratorHelper::begin(this: (RBX::json::MemberIteratorHelper *)__src); /*0x10761e34a*/
    v79 = a1; /*0x10761e364*/
    while ( 1 )
    {
      RBX::json::MemberIteratorHelper::end(this: (RBX::json::MemberIteratorHelper *)v92); /*0x10761e375*/
      v10 = RBX::json::MemberIterator::operator!=(a1: __src, a2: v92); /*0x10761e385*/
      RBX::json::MemberIterator::~MemberIterator(this: (RBX::json::MemberIterator *)v92); /*0x10761e38b*/
      if ( v10 == 0 ) /*0x10761e393*/
        break; /*0x10761e393*/
      RBX::json::MemberIterator::name(this: (RBX::json::MemberIterator *)&v84); /*0x10761e39f*/
      if ( (_BYTE)`guard variable for'RBX::Security::KeyRing::parseVersion(RBX::json::Value const&,std::vector<RBX::Security::KeyRing::KeyInfo> &,unsigned int,unsigned int)::kKnownKeys == 0 /*0x10761e52c*/
        && __cxa_guard_acquire(a1: &`guard variable for'RBX::Security::KeyRing::parseVersion(RBX::json::Value const&,std::vector<RBX::Security::KeyRing::KeyInfo> &,unsigned int,unsigned int)::kKnownKeys) != 0 )
      {
        std::string::basic_string[abi:ne200100]<0>(a1: v92, a2: "id", a3: v20, a4: v21); /*0x10761e53c*/
        std::string::basic_string[abi:ne200100]<0>(a1: &v94, a2: "allowed", a3: v22, a4: v23); /*0x10761e552*/
        std::string::basic_string[abi:ne200100]<0>(a1: v96, a2: "type", a3: v24, a4: v25); /*0x10761e565*/
        std::string::basic_string[abi:ne200100]<0>(a1: v97, a2: "value", a3: v26, a4: v27); /*0x10761e578*/
        std::string::basic_string[abi:ne200100]<0>(a1: v98, a2: "hashJobId", a3: v28, a4: v29); /*0x10761e58b*/
        RBX::Security::KeyRing::parseVersion(RBX::json::Value const&,std::vector<RBX::Security::KeyRing::KeyInfo> &,unsigned int,unsigned int)::kKnownKeys = 0; /*0x10761e593*/
        qword_10D4D0EC8 = 0; /*0x10761e59a*/
        std::vector<std::string>::__init_with_size[abi:ne200100]<std::string const*,std::string const*>( /*0x10761e5b8*/
          a1: &RBX::Security::KeyRing::parseVersion(RBX::json::Value const&,std::vector<RBX::Security::KeyRing::KeyInfo> &,unsigned int,unsigned int)::kKnownKeys,
          a2: v92,
          a3: v99,
          a4: 5);
        for ( i = 15; i != 0; i -= 3 ) /*0x10761e5bd*/
        {
          if ( (__src[i + 1] & 1) != 0 ) /*0x10761e5cc*/
            operator delete(a1: v92[i - 1]); /*0x10761e5d6*/
        }
        __cxa_atexit( /*0x10761e5f6*/
          lpfunc: std::vector<std::string>::~vector[abi:ne200100],
          obj: &RBX::Security::KeyRing::parseVersion(RBX::json::Value const&,std::vector<RBX::Security::KeyRing::KeyInfo> &,unsigned int,unsigned int)::kKnownKeys,
          lpdso_handle: (void *)&_mh_execute_header);
        __cxa_guard_release(a1: &`guard variable for'RBX::Security::KeyRing::parseVersion(RBX::json::Value const&,std::vector<RBX::Security::KeyRing::KeyInfo> &,unsigned int,unsigned int)::kKnownKeys); /*0x10761e602*/
        a1 = v79; /*0x10761e607*/
      }
      v11 = *((_QWORD *)&RBX::Security::KeyRing::parseVersion(RBX::json::Value const&,std::vector<RBX::Security::KeyRing::KeyInfo> &,unsigned int,unsigned int)::kKnownKeys /*0x10761e3b2*/
            + 1);
      if ( v11 == std::__find[abi:ne200100]<std::string const*,std::string const*,std::string,std::__identity>(
                    a1: RBX::Security::KeyRing::parseVersion(RBX::json::Value const&,std::vector<RBX::Security::KeyRing::KeyInfo> &,unsigned int,unsigned int)::kKnownKeys,
                    a2: *((_QWORD *)&RBX::Security::KeyRing::parseVersion(RBX::json::Value const&,std::vector<RBX::Security::KeyRing::KeyInfo> &,unsigned int,unsigned int)::kKnownKeys
                    + 1),
                    a3: &v84,
                    a4: v92) )
      {
        v14 = DFLog::KeyRing; /*0x10761e3d7*/
        if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u )
        {
          v15 = (char *)&v84 + 1; /*0x10761e3fa*/
          if ( (v84 & 1) != 0 ) /*0x10761e401*/
            LODWORD(v15) = (_DWORD)v86; /*0x10761e403*/
          FLog::FastLogFormatted(
            a1: (_DWORD)DFLog::KeyRing,
            a2: qword_10D826CD8,
            a3: (unsigned int)"[DFLog::KeyRing] Version has unknown key : %s.",
            a4: (_DWORD)v15,
            a5: v12,
            a6: v13);
          LOBYTE(v14) = (_BYTE)DFLog::KeyRing; /*0x10761e41f*/
        }
        if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v14 != 0 )
        {
          Instance = RBX::Security::KeyRing::getInstance(this: v14); /*0x10761e43c*/
          if ( Instance != 0 )
          {
            v17 = *(void **)(Instance + 616); /*0x10761e44a*/
            __dst[0] = v17; /*0x10761e451*/
            v18 = *(volatile signed __int64 **)(Instance + 624); /*0x10761e458*/
            __dst[1] = (void *)v18; /*0x10761e45f*/
            if ( v18 != nullptr ) /*0x10761e469*/
              _InterlockedIncrement64(v18 + 1); /*0x10761e46b*/
            else
              v18 = nullptr; /*0x10761e473*/
            if ( v17 != nullptr )
            {
              v19 = (char *)&v84 + 1; /*0x10761e482*/
              if ( (v84 & 1) != 0 ) /*0x10761e489*/
                v19 = (const char *)v86; /*0x10761e48b*/
              RBX::format(this: (RBX *)v92, a2: "Version has unknown key : %s.", v19);
              (*(void (__fastcall **)(void *, RBX::Security::KeyRing **, void **))(*(_QWORD *)v17 + 8LL))( /*0x10761e4b3*/
                a1: v17,
                a2: &DFLog::KeyRing,
                a3: v92);
              if ( ((__int64)v92[0] & 1) != 0 ) /*0x10761e4bd*/
                operator delete(a1: v93); /*0x10761e4c6*/
            }
            if ( v18 != nullptr && _InterlockedExchangeAdd64(v18 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761e4e1*/
            {
              (*(void (__fastcall **)(volatile signed __int64 *))(*v18 + 16))(a1: v18); /*0x10761e4ea*/
              std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v18); /*0x10761e4f0*/
            }
          }
          a1 = v79; /*0x10761e4f5*/
        }
      }
      if ( (v84 & 1) != 0 ) /*0x10761e503*/
        operator delete(a1: v86); /*0x10761e50c*/
      RBX::json::MemberIterator::operator++(a1: __src); /*0x10761e514*/
    }
    RBX::json::MemberIterator::~MemberIterator(this: (RBX::json::MemberIterator *)__src); /*0x10761e65c*/
    v92[0] = (void *)RBX::json::Value::operator[](a1: a3, a2: "id", a3: 2); /*0x10761e680*/
    LOBYTE(v92[1]) = v31; /*0x10761e683*/
    v36 = RBX::json::Value::getInteger<unsigned int>(); /*0x10761e68b*/
    if ( v36 != 0 ) /*0x10761e690*/
    {
      v92[0] = (void *)RBX::json::Value::operator[](a1: a3, a2: "allowed", a3: 7); /*0x10761e6b5*/
      LOBYTE(v92[1]) = v37; /*0x10761e6b8*/
      Bool = RBX::json::Value::getBool(this: (RBX::json::Value *)v92); /*0x10761e6c0*/
      __src[0] = RBX::json::Value::operator[](a1: v83, a2: "value", a3: 5); /*0x10761e6e1*/
      LOBYTE(__src[1]) = v39; /*0x10761e6e4*/
      *(_OWORD *)v92 = 0; /*0x10761e6f1*/
      v93 = nullptr; /*0x10761e6f4*/
      RBX::json::Value::getString(a1: &v84, a2: __src, a3: v92); /*0x10761e703*/
      if ( ((__int64)v92[0] & 1) != 0 ) /*0x10761e70f*/
        operator delete(a1: v93); /*0x10761e718*/
      *(_OWORD *)__src = 0; /*0x10761e720*/
      v90 = nullptr; /*0x10761e727*/
      if ( (v84 & 1) != 0 ) /*0x10761e73d*/
      {
        v40 = (char *)v86; /*0x10761e743*/
        v41 = (__int64)v85; /*0x10761e74a*/
      }
      else
      {
        v41 = (unsigned __int8)v84 >> 1; /*0x10761e7e1*/
        v40 = (char *)&v84 + 1; /*0x10761e7e3*/
      }
      base64<char,std::char_traits<char>>::decode(a1: (__int64)v40, a2: v41, a3: (__int64)__src); /*0x10761e7f1*/
      v48 = LOBYTE(__src[0]); /*0x10761e7f6*/
      v49 = LOBYTE(__src[0]) >> 1; /*0x10761e7ff*/
      v50 = (void *)__src[1]; /*0x10761e804*/
      if ( (__src[0] & 1) != 0 ) /*0x10761e80b*/
        v49 = __src[1]; /*0x10761e80b*/
      if ( v49 != 0 ) /*0x10761e812*/
      {
        v51 = *a4; /*0x10761e81f*/
        v52 = a4[1]; /*0x10761e822*/
        if ( *a4 != v52 ) /*0x10761e829*/
        {
          while ( *(_DWORD *)(v51 + 24) != v36 ) /*0x10761e82f*/
          {
            v51 += 32; /*0x10761e831*/
            if ( v51 == v52 ) /*0x10761e838*/
              goto LABEL_74; /*0x10761e838*/
          }
        }
        if ( v51 == v52 ) /*0x10761e842*/
        {
LABEL_74:
          if ( (Bool | (v36 != a5)) != 0 ) /*0x10761e9b4*/
          {
            if ( ((Bool ^ 1) & (v36 != a6)) == 0 ) /*0x10761e9ca*/
            {
              if ( FFlag::FixPreauthKeyRingJobIdDerivation == 0 ) /*0x10761e9d7*/
              {
                v92[0] = (void *)RBX::json::Value::operator[](a1: v83, a2: "hashJobId", a3: 9); /*0x10761e9fc*/
                LOBYTE(v92[1]) = v61; /*0x10761e9ff*/
                v62 = RBX::json::Value::getBool(this: (RBX::json::Value *)v92); /*0x10761ea02*/
                LOBYTE(v48) = __src[0]; /*0x10761ea07*/
                v50 = (void *)__src[1]; /*0x10761ea0d*/
                if ( v62 != 0 ) /*0x10761ea16*/
                {
                  v63 = *(unsigned __int8 *)(a2 + 472); /*0x10761ea23*/
                  if ( (v63 & 1) != 0 ) /*0x10761ea2d*/
                  {
                    v64 = *(_QWORD *)(a2 + 480); /*0x10761ea33*/
                    v65 = *(_QWORD *)(a2 + 488); /*0x10761ea3a*/
                  }
                  else
                  {
                    v65 = a2 + 473; /*0x10761ede8*/
                    v64 = v63 >> 1; /*0x10761edef*/
                  }
                  if ( (__src[0] & 1) != 0 ) /*0x10761edf4*/
                  {
                    v72 = (char *)v90; /*0x10761edf6*/
                  }
                  else
                  {
                    v50 = (void *)(LOBYTE(__src[0]) >> 1); /*0x10761ee03*/
                    v72 = (char *)__src + 1; /*0x10761ee06*/
                  }
                  RBX::Crypto::computeKeyedBlake2b(a1: v92, a2: v65, a3: v64, a4: v72, a5: v50, a6: 32); /*0x10761ee1a*/
                  if ( (__src[0] & 1) != 0 ) /*0x10761ee26*/
                    operator delete(a1: v90); /*0x10761ee2f*/
                  v90 = v93; /*0x10761ee3b*/
                  *(_OWORD *)__src = *(_OWORD *)v92; /*0x10761ee49*/
                  LOBYTE(v48) = v92[0]; /*0x10761ee50*/
                  v50 = v92[1]; /*0x10761ee56*/
                }
              }
              v73 = (unsigned __int8)v48 >> 1; /*0x10761ee64*/
              if ( (v48 & 1) != 0 ) /*0x10761ee67*/
                v73 = (unsigned __int64)v50; /*0x10761ee67*/
              std::vector<unsigned char>::vector[abi:ne200100](a1: __dst, a2: v73); /*0x10761ee72*/
              if ( (__src[0] & 1) != 0 ) /*0x10761ee7e*/
                v74 = (char *)v90; /*0x10761ee80*/
              else
                v74 = (char *)__src + 1; /*0x10761ee89*/
              memcpy(__dst: __dst[0], __src: v74, __n: (char *)__dst[1] - (char *)__dst[0]); /*0x10761eea1*/
              v75 = __dst[0]; /*0x10761eea6*/
              v76 = __dst[1]; /*0x10761eead*/
              v88 = 0; /*0x10761eeb6*/
              *(_OWORD *)__dst = 0; /*0x10761eec0*/
              *(_OWORD *)v92 = 0; /*0x10761eece*/
              v93 = nullptr; /*0x10761eed1*/
              std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x10761eede*/
                a1: v92,
                a2: v75,
                a3: v76,
                a4: v76 - v75);
              v94 = v36; /*0x10761eeea*/
              v95 = Bool; /*0x10761eeee*/
              std::vector<RBX::Security::KeyRing::KeyInfo>::emplace_back<RBX::Security::KeyRing::KeyInfo>(a1: a4); /*0x10761eef8*/
              if ( v92[0] != nullptr ) /*0x10761ef07*/
              {
                v92[1] = v92[0]; /*0x10761ef09*/
                operator delete(a1: v92[0]); /*0x10761ef10*/
              }
              if ( v75 != nullptr ) /*0x10761ef18*/
                operator delete(a1: v75); /*0x10761ef1d*/
              if ( __dst[0] != nullptr ) /*0x10761ef2c*/
              {
                __dst[1] = __dst[0]; /*0x10761ef2e*/
                operator delete(a1: __dst[0]); /*0x10761ef35*/
              }
            }
            *(_OWORD *)a1 = 0; /*0x10761ef3d*/
            *(_QWORD *)(a1 + 16) = 0; /*0x10761ef42*/
            *(_BYTE *)(a1 + 24) = 1; /*0x10761ef4b*/
            *(_DWORD *)(a1 + 32) = v36; /*0x10761ef51*/
            *(_BYTE *)(a1 + 36) = Bool; /*0x10761ef56*/
            goto LABEL_140; /*0x10761ef56*/
          }
          v66 = DFLog::KeyRing; /*0x10761ea46*/
          LOBYTE(v48) = (unsigned __int8)DFLog::KeyRing < 6u; /*0x10761ea56*/
          if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u ) /*0x10761ea5b*/
          {
            FLog::FastLogFormatted( /*0x10761ea72*/
              a1: (_DWORD)DFLog::KeyRing,
              a2: qword_10D826CD8,
              a3: (unsigned int)"[DFLog::KeyRing] Application sendVersion is not in allowed set.",
              a4: v48,
              a5: __src[1],
              a6: v47);
            LOBYTE(v66) = (_BYTE)DFLog::KeyRing; /*0x10761ea77*/
          }
          if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v66 != 0 ) /*0x10761ea8e*/
          {
            v67 = RBX::Security::KeyRing::getInstance(this: v66); /*0x10761ea94*/
            if ( v67 != 0 ) /*0x10761ea9c*/
            {
              v68 = *(void **)(v67 + 616); /*0x10761eaa2*/
              __dst[0] = v68; /*0x10761eaa9*/
              v69 = *(volatile signed __int64 **)(v67 + 624); /*0x10761eab0*/
              __dst[1] = (void *)v69; /*0x10761eab7*/
              if ( v69 != nullptr ) /*0x10761eac1*/
                _InterlockedIncrement64(v69 + 1); /*0x10761eac3*/
              if ( v68 != nullptr ) /*0x10761eacb*/
              {
                RBX::format(this: (RBX *)v92, a2: "Application sendVersion is not in allowed set."); /*0x10761eae1*/
                (*(void (__fastcall **)(void *, RBX::Security::KeyRing **, void **))(*(_QWORD *)v68 + 8LL))( /*0x10761eafa*/
                  a1: v68,
                  a2: &DFLog::KeyRing,
                  a3: v92);
                if ( ((__int64)v92[0] & 1) != 0 ) /*0x10761eb04*/
                  operator delete(a1: v93); /*0x10761eb11*/
              }
            }
            else
            {
              *(_OWORD *)__dst = 0; /*0x10761ed32*/
            }
            std::shared_ptr<RBX::Security::IKeyRingDebugLogger>::~shared_ptr[abi:ne200100](a1: __dst); /*0x10761ed40*/
          }
          std::string::basic_string[abi:ne200100]<0>(a1: v92, a2: "sendNotAllowed", a3: v52, a4: v48); /*0x10761ed53*/
          LOBYTE(v94) = 0; /*0x10761ed58*/
          if ( ((__int64)v92[0] & 1) != 0 ) /*0x10761ed66*/
          {
LABEL_119:
            std::string::__init_copy_ctor_external(a1, a2: v93, a3: v92[1]); /*0x10761ed9a*/
            v70 = ((__int64)v92[0] & 1) == 0; /*0x10761edb0*/
            *(_BYTE *)(a1 + 24) = v94; /*0x10761edbd*/
            *(_DWORD *)(a1 + 32) = 0; /*0x10761edc2*/
            *(_BYTE *)(a1 + 36) = 0; /*0x10761edcb*/
            if ( !v70 ) /*0x10761edd1*/
              operator delete(a1: v93); /*0x10761edde*/
LABEL_140:
            if ( (__src[0] & 1) != 0 ) /*0x10761ef62*/
              operator delete(a1: v90); /*0x10761ef6b*/
            if ( (v84 & 1) != 0 ) /*0x10761ef77*/
            {
              v71 = v86; /*0x10761ef79*/
              goto LABEL_144; /*0x10761ef79*/
            }
            return a1; /*0x10761ef77*/
          }
        }
        else
        {
          v53 = DFLog::KeyRing; /*0x10761e848*/
          LOBYTE(v48) = (unsigned __int8)DFLog::KeyRing < 6u; /*0x10761e858*/
          if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u ) /*0x10761e85d*/
          {
            FLog::FastLogFormatted( /*0x10761e874*/
              a1: (_DWORD)DFLog::KeyRing,
              a2: qword_10D826CD8,
              a3: (unsigned int)"[DFLog::KeyRing] Application has duplicate versioned key",
              a4: v48,
              a5: __src[1],
              a6: v47);
            LOBYTE(v53) = (_BYTE)DFLog::KeyRing; /*0x10761e879*/
          }
          if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v53 != 0 ) /*0x10761e890*/
          {
            v54 = RBX::Security::KeyRing::getInstance(this: v53); /*0x10761e896*/
            if ( v54 != 0 ) /*0x10761e89e*/
            {
              v55 = *(void **)(v54 + 616); /*0x10761e8a4*/
              __dst[0] = v55; /*0x10761e8ab*/
              v56 = *(volatile signed __int64 **)(v54 + 624); /*0x10761e8b2*/
              __dst[1] = (void *)v56; /*0x10761e8b9*/
              if ( v56 != nullptr ) /*0x10761e8c3*/
                _InterlockedIncrement64(v56 + 1); /*0x10761e8c5*/
              if ( v55 != nullptr ) /*0x10761e8cd*/
              {
                RBX::format(this: (RBX *)v92, a2: "Application has duplicate versioned key"); /*0x10761e8e3*/
                (*(void (__fastcall **)(void *, RBX::Security::KeyRing **, void **))(*(_QWORD *)v55 + 8LL))( /*0x10761e8fc*/
                  a1: v55,
                  a2: &DFLog::KeyRing,
                  a3: v92);
                if ( ((__int64)v92[0] & 1) != 0 ) /*0x10761e906*/
                  operator delete(a1: v93); /*0x10761e913*/
              }
            }
            else
            {
              *(_OWORD *)__dst = 0; /*0x10761ec2c*/
            }
            std::shared_ptr<RBX::Security::IKeyRingDebugLogger>::~shared_ptr[abi:ne200100](a1: __dst); /*0x10761ec3a*/
          }
          std::string::basic_string[abi:ne200100]<0>(a1: v92, a2: "dupeKey", a3: v52, a4: v48); /*0x10761ec4d*/
          LOBYTE(v94) = 0; /*0x10761ec52*/
          if ( ((__int64)v92[0] & 1) != 0 ) /*0x10761ec60*/
            goto LABEL_119; /*0x10761ec60*/
        }
      }
      else
      {
        v57 = DFLog::KeyRing; /*0x10761e91d*/
        LOBYTE(v48) = (unsigned __int8)DFLog::KeyRing < 6u; /*0x10761e92d*/
        if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u ) /*0x10761e932*/
        {
          FLog::FastLogFormatted( /*0x10761e949*/
            a1: (_DWORD)DFLog::KeyRing,
            a2: qword_10D826CD8,
            a3: (unsigned int)"[DFLog::KeyRing] Application has empty key",
            a4: v48,
            a5: __src[1],
            a6: v47);
          LOBYTE(v57) = (_BYTE)DFLog::KeyRing; /*0x10761e94e*/
        }
        if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v57 != 0 ) /*0x10761e965*/
        {
          v58 = RBX::Security::KeyRing::getInstance(this: v57); /*0x10761e96b*/
          if ( v58 != 0 ) /*0x10761e973*/
          {
            v59 = *(void **)(v58 + 616); /*0x10761e979*/
            __dst[0] = v59; /*0x10761e980*/
            v60 = *(volatile signed __int64 **)(v58 + 624); /*0x10761e987*/
            __dst[1] = (void *)v60; /*0x10761e98e*/
            if ( v60 != nullptr ) /*0x10761e998*/
              _InterlockedIncrement64(v60 + 1); /*0x10761e99e*/
            else
              v60 = nullptr; /*0x10761ec81*/
            if ( v59 != nullptr ) /*0x10761ec86*/
            {
              RBX::format(this: (RBX *)v92, a2: "Application has empty key"); /*0x10761ec98*/
              (*(void (__fastcall **)(void *, RBX::Security::KeyRing **, void **))(*(_QWORD *)v59 + 8LL))( /*0x10761ecb1*/
                a1: v59,
                a2: &DFLog::KeyRing,
                a3: v92);
              if ( ((__int64)v92[0] & 1) != 0 ) /*0x10761ecbb*/
                operator delete(a1: v93); /*0x10761ecc4*/
            }
            if ( v60 != nullptr && _InterlockedExchangeAdd64(v60 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761ecde*/
            {
              (*(void (__fastcall **)(volatile signed __int64 *))(*v60 + 16))(a1: v60); /*0x10761ece6*/
              std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v60); /*0x10761ecec*/
            }
          }
        }
        std::string::basic_string[abi:ne200100]<0>(a1: v92, a2: "emptyKey", a3: v46, a4: v48); /*0x10761ecff*/
        LOBYTE(v94) = 0; /*0x10761ed04*/
        if ( ((__int64)v92[0] & 1) != 0 ) /*0x10761ed12*/
          goto LABEL_119; /*0x10761ed12*/
      }
      *(_QWORD *)(a1 + 16) = v93; /*0x10761ed6f*/
      *(_OWORD *)a1 = *(_OWORD *)v92; /*0x10761ed7b*/
      *(_BYTE *)(a1 + 24) = 0; /*0x10761ed82*/
      *(_DWORD *)(a1 + 32) = 0; /*0x10761ed87*/
      *(_BYTE *)(a1 + 36) = 0; /*0x10761ed90*/
      goto LABEL_140; /*0x10761ed95*/
    }
    v42 = DFLog::KeyRing; /*0x10761e756*/
    LOBYTE(v33) = (unsigned __int8)DFLog::KeyRing < 6u; /*0x10761e766*/
    if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u ) /*0x10761e76b*/
    {
      FLog::FastLogFormatted( /*0x10761e782*/
        a1: (_DWORD)DFLog::KeyRing,
        a2: qword_10D826CD8,
        a3: (unsigned int)"[DFLog::KeyRing] Application has null-versioned key.",
        a4: v33,
        a5: v34,
        a6: v35);
      LOBYTE(v42) = (_BYTE)DFLog::KeyRing; /*0x10761e787*/
    }
    if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v42 != 0 ) /*0x10761e79e*/
    {
      v43 = RBX::Security::KeyRing::getInstance(this: v42); /*0x10761e7a4*/
      if ( v43 != 0 ) /*0x10761e7ac*/
      {
        v44 = *(_QWORD *)(v43 + 616); /*0x10761e7b2*/
        v84 = v44; /*0x10761e7b9*/
        v45 = *(volatile signed __int64 **)(v43 + 624); /*0x10761e7c0*/
        v85 = v45; /*0x10761e7c7*/
        if ( v45 != nullptr ) /*0x10761e7d1*/
          _InterlockedIncrement64(v45 + 1); /*0x10761e7d7*/
        else
          v45 = nullptr; /*0x10761eb1b*/
        if ( v44 != 0 ) /*0x10761eb20*/
        {
          RBX::format(this: (RBX *)v92, a2: "Application has null-versioned key."); /*0x10761eb32*/
          (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, void **))(*(_QWORD *)v44 + 8LL))( /*0x10761eb4b*/
            a1: v44,
            a2: &DFLog::KeyRing,
            a3: v92);
          if ( ((__int64)v92[0] & 1) != 0 ) /*0x10761eb55*/
            operator delete(a1: v93); /*0x10761eb5e*/
        }
        if ( v45 != nullptr && _InterlockedExchangeAdd64(v45 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761eb78*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v45 + 16))(a1: v45); /*0x10761eb80*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v45); /*0x10761eb86*/
        }
      }
    }
    std::string::basic_string[abi:ne200100]<0>(a1: v92, a2: "nullVer", a3: v32, a4: v33); /*0x10761eb99*/
    LOBYTE(v94) = 0; /*0x10761eb9e*/
    if ( ((__int64)v92[0] & 1) == 0 ) /*0x10761ebac*/
    {
LABEL_98:
      *(_QWORD *)(a1 + 16) = v93; /*0x10761ebae*/
      *(_OWORD *)a1 = *(_OWORD *)v92; /*0x10761ebc1*/
      *(_BYTE *)(a1 + 24) = 0; /*0x10761ebc8*/
      *(_DWORD *)(a1 + 32) = 0; /*0x10761ebcd*/
      *(_BYTE *)(a1 + 36) = 0; /*0x10761ebd6*/
      return a1; /*0x10761ebdb*/
    }
    std::string::__init_copy_ctor_external(a1, a2: v93, a3: v92[1]); /*0x10761ebf1*/
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v92, a2: "badVer", a3: v8, a4: v9); /*0x10761e621*/
    LOBYTE(v94) = 0; /*0x10761e626*/
    if ( ((__int64)v92[0] & 1) == 0 ) /*0x10761e634*/
      goto LABEL_98; /*0x10761e634*/
    std::string::__init_copy_ctor_external(a1, a2: v93, a3: v92[1]); /*0x10761e64b*/
  }
  v70 = ((__int64)v92[0] & 1) == 0; /*0x10761ebf6*/
  *(_BYTE *)(a1 + 24) = v94; /*0x10761ec03*/
  *(_DWORD *)(a1 + 32) = 0; /*0x10761ec08*/
  *(_BYTE *)(a1 + 36) = 0; /*0x10761ec11*/
  if ( !v70 ) /*0x10761ec17*/
  {
    v71 = v93; /*0x10761ec1d*/
LABEL_144:
    operator delete(a1: v71); /*0x10761ef80*/
  }
  return a1; /*0x10761ef98*/
}

// Address: 0x10761f188 | Name: __ZNK3RBX8Security7KeyRing20getKeyForConsumptionERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEjSA_
__int64 __fastcall RBX::Security::KeyRing::getKeyForConsumption(
        __int64 a1,
        __int64 a2,
        unsigned __int8 *a3,
        int a4,
        unsigned __int8 *a5)
{
  __int64 v10; // rax
  __int64 v11; // r13
  __int64 v12; // rax
  unsigned int v13; // r8d
  __int64 v14; // r8
  unsigned __int8 *v15; // r15
  _BYTE *v16; // rcx
  __int64 v17; // r8
  unsigned int v18; // eax
  __int64 v19; // rdx
  unsigned __int8 *v20; // r14
  char *v22; // rsi
  __int64 v23; // rcx
  unsigned __int8 v24; // [rsp+8h] [rbp-2A8h] BYREF
  char v25; // [rsp+9h] [rbp-2A7h] BYREF
  __int64 v26; // [rsp+10h] [rbp-2A0h]
  void *v27; // [rsp+18h] [rbp-298h]
  _BYTE v28[528]; // [rsp+50h] [rbp-260h] BYREF
  boost::shared_mutex *v29; // [rsp+260h] [rbp-50h] BYREF
  char v30; // [rsp+268h] [rbp-48h]
  unsigned __int8 v31; // [rsp+270h] [rbp-40h] BYREF
  _BYTE v32[15]; // [rsp+271h] [rbp-3Fh] BYREF
  void *v33; // [rsp+280h] [rbp-30h]

  v29 = (boost::shared_mutex *)(a2 + 64); /*0x10761f1b3*/
  v30 = 0; /*0x10761f1b6*/
  boost::shared_lock<RBX::BoostSharedMutex>::lock(a1: (__int64)&v29); /*0x10761f1ba*/
  v10 = std::__hash_table<std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>>>::find<std::string>( /*0x10761f1c9*/
          a1: a2 + 24,
          a2: a3);
  if ( v10 == 0 ) /*0x10761f1d1*/
    goto LABEL_12; /*0x10761f1d1*/
  v11 = *(_QWORD *)(v10 + 40); /*0x10761f1d7*/
  v12 = *(_QWORD *)(v10 + 48); /*0x10761f1db*/
  while ( v11 != v12 && *(_DWORD *)(v11 + 24) != a4 ) /*0x10761f1e8*/
    v11 += 32; /*0x10761f1ea*/
  if ( v11 != v12 && (*(_BYTE *)(v11 + 28) != 0 || DFFlag::KeyRingRevert != 0) )
  {
    if ( DFFlag::ReportKeyringVersionBeingUsed == 1 ) /*0x10761f20c*/
    {
      RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x10761f220*/
        a1: (__int64)&v24,
        a2: (__int64)&RBX::Telemetry::kKeyRingUsageVersionInfo);
      RBX::Telemetry::FieldsContainer::addField(a1: v28, a2: "usageType", a3: 9, a4: "consumption", a5: 1); /*0x10761f248*/
      v13 = *a3; /*0x10761f24d*/
      if ( (v13 & 1) != 0 ) /*0x10761f255*/
      {
        v14 = *((_QWORD *)a3 + 1); /*0x10761f257*/
        v15 = *((unsigned __int8 **)a3 + 2); /*0x10761f25b*/
      }
      else
      {
        v15 = a3 + 1; /*0x10761f274*/
        v14 = v13 >> 1; /*0x10761f277*/
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v28, a2: "application", a3: 11, a4: v15, a5: v14, a6: 1); /*0x10761f292*/
      std::to_string(a1: (unsigned int)&v31); /*0x10761f29f*/
      if ( (v31 & 1) != 0 ) /*0x10761f2ad*/
      {
        v16 = v33; /*0x10761f2af*/
        v17 = *(_QWORD *)&v32[7]; /*0x10761f2b3*/
      }
      else
      {
        v17 = v31 >> 1; /*0x10761f2b9*/
        v16 = v32; /*0x10761f2bc*/
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v28, a2: "version", a3: 7, a4: v16, a5: v17, a6: 1); /*0x10761f2d5*/
      if ( (v31 & 1) != 0 ) /*0x10761f2de*/
        operator delete(a1: v33); /*0x10761f2e4*/
      RBX::Telemetry::FieldsContainer::addField( /*0x10761f303*/
        a1: v28,
        a2: "allowed",
        a3: 7,
        a4: *(unsigned __int8 *)(v11 + 28),
        a5: 1);
      RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)&v24); /*0x10761f30f*/
      RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)&v24); /*0x10761f322*/
    }
    if ( FFlag::FixPreauthKeyRingJobIdDerivation == 1
      && (((v18 = *a5) & 1) == 0 ? (v19 = v18 >> 1) : (v19 = *((_QWORD *)a5 + 1)), v19 != 0) )
    {
      if ( (v18 & 1) != 0 ) /*0x10761f349*/
        v20 = *((unsigned __int8 **)a5 + 2); /*0x10761f34b*/
      else
        v20 = a5 + 1; /*0x10761f399*/
      RBX::Crypto::computeKeyedBlake2b( /*0x10761f3b7*/
        a1: &v24,
        a2: v20,
        a3: v19,
        a4: *(_QWORD *)v11,
        a5: *(_QWORD *)(v11 + 8) - *(_QWORD *)v11,
        a6: 32);
      if ( (v24 & 1) != 0 ) /*0x10761f3c6*/
      {
        v22 = (char *)v27; /*0x10761f3c8*/
        v23 = v26; /*0x10761f3cf*/
      }
      else
      {
        v23 = v24 >> 1; /*0x10761f3d8*/
        v22 = &v25; /*0x10761f3da*/
      }
      *(_OWORD *)a1 = 0; /*0x10761f3e8*/
      *(_QWORD *)(a1 + 16) = 0; /*0x10761f3eb*/
      std::vector<unsigned char>::__init_with_size[abi:ne200100]<std::__wrap_iter<char *>,std::__wrap_iter<char *>>( /*0x10761f3f6*/
        a1,
        a2: v22,
        a3: &v22[v23]);
      if ( (v24 & 1) != 0 ) /*0x10761f402*/
        operator delete(a1: v27); /*0x10761f40f*/
    }
    else
    {
      *(_OWORD *)a1 = 0; /*0x10761f354*/
      *(_QWORD *)(a1 + 16) = 0; /*0x10761f357*/
      std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x10761f370*/
        a1,
        a2: *(_QWORD *)v11,
        a3: *(_QWORD *)(v11 + 8),
        a4: *(_QWORD *)(v11 + 8) - *(_QWORD *)v11);
    }
  }
  else
  {
LABEL_12:
    *(_OWORD *)a1 = 0; /*0x10761f264*/
    *(_QWORD *)(a1 + 16) = 0; /*0x10761f267*/
  }
  if ( v30 == 1 ) /*0x10761f379*/
    boost::shared_mutex::unlock_shared(this: v29); /*0x10761f37f*/
  return a1; /*0x10761f387*/
}

// Address: 0x10761f486 | Name: __ZNK3RBX8Security7KeyRing19getKeyForProductionERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
__int64 __fastcall RBX::Security::KeyRing::getKeyForProduction(__int64 a1, __int64 a2, unsigned __int8 *a3)
{
  __int64 v6; // rax
  __int64 v7; // r12
  __int64 v8; // rcx
  int v9; // eax
  unsigned int v10; // r8d
  __int64 v11; // r8
  unsigned __int8 *v12; // r15
  _BYTE *v13; // rcx
  __int64 v14; // r8
  _BYTE v16[72]; // [rsp+0h] [rbp-2A0h] BYREF
  _BYTE v17[528]; // [rsp+48h] [rbp-258h] BYREF
  boost::shared_mutex *v18; // [rsp+258h] [rbp-48h] BYREF
  char v19; // [rsp+260h] [rbp-40h]
  unsigned __int8 v20; // [rsp+268h] [rbp-38h] BYREF
  _BYTE v21[15]; // [rsp+269h] [rbp-37h] BYREF
  void *v22; // [rsp+278h] [rbp-28h]

  v18 = (boost::shared_mutex *)(a2 + 64); /*0x10761f4a9*/
  v19 = 0; /*0x10761f4ac*/
  boost::shared_lock<RBX::BoostSharedMutex>::lock(a1: (__int64)&v18); /*0x10761f4b0*/
  v6 = std::__hash_table<std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>>>::find<std::string>( /*0x10761f4bf*/
         a1: a2 + 24,
         a2: a3);
  if ( v6 == 0 || (v7 = *(_QWORD *)(v6 + 40), v8 = *(_QWORD *)(v6 + 48), v7 == v8) ) /*0x10761f4d8*/
  {
    *(_OWORD *)a1 = 0; /*0x10761f576*/
    *(_QWORD *)(a1 + 16) = 0; /*0x10761f579*/
    std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>(a1, a2: 0, a3: 0, a4: 0); /*0x10761f58a*/
    *(_DWORD *)(a1 + 24) = 0; /*0x10761f58f*/
    *(_BYTE *)(a1 + 28) = 0; /*0x10761f596*/
  }
  else
  {
    v9 = *(_DWORD *)(v6 + 4LL * (unsigned __int8)DFFlag::KeyRingRevert + 64); /*0x10761f4e5*/
    do /*0x10761f4f7*/
    {
      if ( *(_DWORD *)(v7 + 24) == v9 ) /*0x10761f4ee*/
        break; /*0x10761f4ee*/
      v7 += 32; /*0x10761f4f0*/
    }
    while ( v7 != v8 ); /*0x10761f4f7*/
    if ( DFFlag::ReportKeyringVersionBeingUsed == 1 ) /*0x10761f500*/
    {
      RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x10761f514*/
        a1: (__int64)v16,
        a2: (__int64)&RBX::Telemetry::kKeyRingUsageVersionInfo);
      RBX::Telemetry::FieldsContainer::addField(a1: v17, a2: "usageType", a3: 9, a4: "production", a5: 1); /*0x10761f53c*/
      v10 = *a3; /*0x10761f541*/
      if ( (v10 & 1) != 0 ) /*0x10761f549*/
      {
        v11 = *((_QWORD *)a3 + 1); /*0x10761f54b*/
        v12 = *((unsigned __int8 **)a3 + 2); /*0x10761f54f*/
      }
      else
      {
        v12 = a3 + 1; /*0x10761f59f*/
        v11 = v10 >> 1; /*0x10761f5a2*/
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v17, a2: "application", a3: 11, a4: v12, a5: v11, a6: 1); /*0x10761f5bd*/
      std::to_string(a1: (unsigned int)&v20); /*0x10761f5cb*/
      if ( (v20 & 1) != 0 ) /*0x10761f5d9*/
      {
        v13 = v22; /*0x10761f5db*/
        v14 = *(_QWORD *)&v21[7]; /*0x10761f5df*/
      }
      else
      {
        v14 = v20 >> 1; /*0x10761f5e5*/
        v13 = v21; /*0x10761f5e8*/
      }
      RBX::Telemetry::FieldsContainer::addField(a1: v17, a2: "version", a3: 7, a4: v13, a5: v14, a6: 1); /*0x10761f601*/
      if ( (v20 & 1) != 0 ) /*0x10761f60a*/
        operator delete(a1: v22); /*0x10761f610*/
      RBX::Telemetry::FieldsContainer::addField(a1: v17, a2: "allowed", a3: 7, a4: *(unsigned __int8 *)(v7 + 28), a5: 1); /*0x10761f630*/
      RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v16); /*0x10761f63c*/
      RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v16); /*0x10761f64f*/
    }
    *(_OWORD *)a1 = 0; /*0x10761f657*/
    *(_QWORD *)(a1 + 16) = 0; /*0x10761f65a*/
    std::vector<unsigned char>::__init_with_size[abi:ne200100]<unsigned char *,unsigned char *>( /*0x10761f674*/
      a1,
      a2: *(_QWORD *)v7,
      a3: *(_QWORD *)(v7 + 8),
      a4: *(_QWORD *)(v7 + 8) - *(_QWORD *)v7);
    *(_BYTE *)(a1 + 28) = *(_BYTE *)(v7 + 28); /*0x10761f67e*/
    *(_DWORD *)(a1 + 24) = *(_DWORD *)(v7 + 24); /*0x10761f686*/
  }
  if ( v19 == 1 ) /*0x10761f68d*/
    boost::shared_mutex::unlock_shared(this: v18); /*0x10761f693*/
  return a1; /*0x10761f69b*/
}

// Address: 0x10761f6fe | Name: __ZN3RBX8Security7KeyRing14updateFromFileEb
__int64 __fastcall RBX::Security::KeyRing::updateFromFile(__m128i *this, int a2)
{
  const char *v4; // rbx
  int v5; // r8d
  int v6; // r9d
  __int64 v7; // r14
  char *v8; // rbx
  char *v9; // rsi
  __m128i v10; // xmm0
  bool v11; // r14
  __int64 v12; // rdx
  RBX::Security::KeyRing *v13; // rdi
  __int64 v14; // rcx
  RBX::Security::KeyRing *v15; // rdi
  __m128i *v16; // r13
  char *v17; // rsi
  volatile signed __int64 *v18; // rdx
  const __m128i *v19; // r12
  const __m128i *v20; // rax
  int v21; // ecx
  __m128i v22; // xmm1
  int v23; // ebx
  int v24; // r14d
  int v25; // r9d
  __int8 *v26; // rcx
  __int64 v27; // rax
  __int64 v28; // r14
  volatile signed __int64 *v29; // rbx
  __int8 *v30; // r8
  __int64 Instance; // rax
  __int64 v32; // r14
  volatile signed __int64 *v33; // rbx
  const char *v34; // rdx
  unsigned int v35; // ebx
  const char *v36; // rdx
  const char *v37; // rcx
  int v38; // r14d
  __int8 *v39; // rcx
  __int8 *v40; // r8
  __int8 *v41; // r9
  __int64 v42; // rax
  __int64 v43; // r14
  volatile signed __int64 *v44; // rbx
  const char *v45; // rdx
  const char *v46; // rcx
  const char *v47; // r8
  char v48; // al
  int v49; // r8d
  int v50; // r9d
  RBX::Security::KeyRing *v51; // rdi
  bool v52; // cl
  RBX::Security::KeyRing *v53; // r12
  __int64 v54; // rcx
  RBX::Security::KeyRing *v55; // r12
  __int64 v56; // rcx
  __int64 v57; // rax
  __int64 v58; // r14
  volatile signed __int64 *v59; // rbx
  __int64 v60; // rax
  __int64 v61; // r14
  volatile signed __int64 *v62; // rbx
  const char *v63; // rdx
  const char *v64; // rdx
  __int64 *v65; // r15
  RBX::Security::KeyRing *v66; // r14
  RBX::Security::KeyRing *v67; // rdi
  __int64 v68; // rcx
  __int64 v69; // rax
  RBX::Security::KeyRing *v70; // r13
  __int64 v71; // r14
  volatile signed __int64 *v72; // r12
  const char *v73; // rdx
  const char *v74; // rdx
  RBX::Security::KeyRing *v75; // rsi
  __m128i *v77; // [rsp+10h] [rbp-590h] BYREF
  __int64 v78; // [rsp+18h] [rbp-588h]
  volatile signed __int64 *v79; // [rsp+20h] [rbp-580h]
  int v80; // [rsp+2Ch] [rbp-574h]
  __int128 v81; // [rsp+30h] [rbp-570h] BYREF
  void *v82; // [rsp+40h] [rbp-560h]
  __int64 v83; // [rsp+48h] [rbp-558h] BYREF
  volatile signed __int64 *v84; // [rsp+50h] [rbp-550h]
  void *v85; // [rsp+58h] [rbp-548h]
  __m128i v86; // [rsp+60h] [rbp-540h] BYREF
  void *v87; // [rsp+70h] [rbp-530h]
  __m128i v88; // [rsp+80h] [rbp-520h] BYREF
  void *v89; // [rsp+90h] [rbp-510h]
  __int64 v90; // [rsp+98h] [rbp-508h] BYREF
  volatile signed __int64 *v91; // [rsp+A0h] [rbp-500h]
  void *v92; // [rsp+A8h] [rbp-4F8h]
  int v93; // [rsp+B4h] [rbp-4ECh]
  RBX::Security::KeyRing *v94; // [rsp+B8h] [rbp-4E8h]
  __int128 v95; // [rsp+C0h] [rbp-4E0h]
  __m128i v96; // [rsp+D8h] [rbp-4C8h] BYREF
  RBX::Security::KeyRing *v97; // [rsp+E8h] [rbp-4B8h]
  _BYTE v98[56]; // [rsp+120h] [rbp-480h] BYREF
  __int64 v99; // [rsp+158h] [rbp-448h]
  _QWORD v100[2]; // [rsp+330h] [rbp-270h] BYREF
  _QWORD v101[51]; // [rsp+340h] [rbp-260h] BYREF
  _QWORD v102[18]; // [rsp+4D8h] [rbp-C8h] BYREF
  int v103; // [rsp+568h] [rbp-38h]

  v77 = this; /*0x10761f726*/
  v81 = 0; /*0x10761f731*/
  v82 = nullptr; /*0x10761f739*/
  if ( (*((_BYTE *)this + 504) & 1) != 0 ) /*0x10761f74b*/
    v4 = *((const char **)this + 65); /*0x10761f757*/
  else
    v4 = (char *)this + 505; /*0x10761f74d*/
  v102[6] = 0; /*0x10761f768*/
  v102[0] = &off_10CA6D4F0; /*0x10761f786*/
  v100[1] = 0; /*0x10761f789*/
  std::ios_base::init(this: (std::ios_base *)v102, a2: v101); /*0x10761f790*/
  v102[17] = 0; /*0x10761f795*/
  v103 = -1; /*0x10761f79d*/
  v100[0] = &off_10CA6D458; /*0x10761f7b6*/
  v102[0] = off_10CA6D480; /*0x10761f7c8*/
  std::filebuf::basic_filebuf(a1: v101); /*0x10761f7d2*/
  if ( std::filebuf::open(a1: (__int64)v101, a2: v4, a3: 0xEu) == 0 ) /*0x10761f7ea*/
    std::ios_base::clear( /*0x10761f808*/
      this: (std::ios_base *)((char *)v100 + *(_QWORD *)(v100[0] - 24LL)),
      a2: *(_DWORD *)((char *)&v101[2] + *(_QWORD *)(v100[0] - 24LL)) | 4);
  if ( v101[15] != 0 )
  {
    std::istream::tellg(a1: &v96, a2: v100); /*0x10761f829*/
    v7 = v99; /*0x10761f82e*/
    std::istream::seekg(a1: v100, a2: 0, a3: 0); /*0x10761f840*/
    std::string::resize(a1: &v81, a2: v7, a3: 0); /*0x10761f851*/
    v8 = (char *)&v81 + 1; /*0x10761f856*/
    v9 = (char *)&v81 + 1; /*0x10761f861*/
    if ( (v81 & 1) != 0 ) /*0x10761f864*/
      v9 = (char *)v82; /*0x10761f866*/
    std::istream::read(a1: v100, a2: v9, a3: v7); /*0x10761f877*/
    if ( std::filebuf::close(a1: v101) == nullptr ) /*0x10761f887*/
      std::ios_base::clear( /*0x10761f8a5*/
        this: (std::ios_base *)((char *)v100 + *(_QWORD *)(v100[0] - 24LL)),
        a2: *(_DWORD *)((char *)&v101[2] + *(_QWORD *)(v100[0] - 24LL)) | 4);
    v95 = 0; /*0x10761f8ae*/
    v10 = _mm_loadu_si128(this + 34); /*0x10761f8b6*/
    v93 = 0; /*0x10761f8c0*/
    v11 = !_mm_testz_si128(v10, v10); /*0x10761f8cf*/
    if ( (v81 & 1) != 0 ) /*0x10761f8dd*/
    {
      v8 = (char *)v82; /*0x10761f8df*/
      v12 = *((_QWORD *)&v81 + 1); /*0x10761f8e6*/
    }
    else
    {
      v12 = (unsigned __int8)v81 >> 1; /*0x10761f932*/
    }
    v80 = a2; /*0x10761f934*/
    RBX::Crypto::blake2b(a1: &v83, a2: v8, a3: v12, a4: 16); /*0x10761f94a*/
    v16 = this + 34; /*0x10761f94f*/
    v88 = 0; /*0x10761f95b*/
    v89 = nullptr; /*0x10761f965*/
    v87 = nullptr; /*0x10761f96c*/
    v86 = 0; /*0x10761f973*/
    if ( (_BYTE)DFLog::KeyRingUpdate != 0 ) /*0x10761f982*/
    {
      if ( (v83 & 1) != 0 ) /*0x10761f992*/
      {
        v17 = (char *)v85; /*0x10761f994*/
        v18 = v84; /*0x10761f99b*/
      }
      else
      {
        v18 = (volatile signed __int64 *)((unsigned __int8)v83 >> 1); /*0x10761f9a4*/
        v17 = (char *)&v83 + 1; /*0x10761f9a6*/
      }
      RBX::Crypto::convertToHex(a1: &v96, a2: v17, a3: v18, a4: 1); /*0x10761f9b9*/
      if ( (v88.i8[0] & 1) != 0 ) /*0x10761f9c5*/
        operator delete(a1: v89); /*0x10761f9ce*/
      v89 = v97; /*0x10761f9de*/
      v88 = _mm_loadu_si128(&v96); /*0x10761f9e9*/
      RBX::Crypto::convertToHex(a1: &v96, a2: this + 34, a3: 16, a4: 1); /*0x10761f9fe*/
      if ( (v86.i8[0] & 1) != 0 ) /*0x10761fa0a*/
        operator delete(a1: v87); /*0x10761fa13*/
      v87 = v97; /*0x10761fa1f*/
      v86 = _mm_loadu_si128(&v96); /*0x10761fa2e*/
    }
    v94 = (RBX::Security::KeyRing *)this; /*0x10761fa36*/
    v19 = (const __m128i *)((char *)&v83 + 1); /*0x10761fa3d*/
    v20 = (const __m128i *)((char *)&v83 + 1); /*0x10761fa4a*/
    if ( (v83 & 1) != 0 ) /*0x10761fa4d*/
      v20 = (const __m128i *)v85; /*0x10761fa4f*/
    v21 = v93; /*0x10761fa56*/
    LOBYTE(v21) = v11; /*0x10761fa5c*/
    v93 = v21; /*0x10761fa5f*/
    v22 = _mm_xor_si128(_mm_loadu_si128(v20), _mm_loadu_si128(v16)); /*0x10761fa6f*/
    v23 = (int)DFLog::KeyRingUpdate; /*0x10761fa78*/
    if ( _mm_testz_si128(v22, v22) ) /*0x10761fa73*/
    {
      if ( (unsigned __int8)DFLog::KeyRingUpdate >= 6u && BYTE1(DFLog::KeyRingUpdate) >= 3u ) /*0x10761fa92*/
      {
        v24 = qword_10D826CE8; /*0x10761fa9d*/
        RBX::Security::KeyRing::getConfigLogName(this: (RBX::Security::KeyRing *)&v96); /*0x10761fab2*/
        if ( (v96.i8[0] & 1) != 0 ) /*0x10761fabe*/
          LODWORD(v26) = (_DWORD)v97; /*0x10761fac0*/
        else
          v26 = &v96.i8[1]; /*0x10761fb39*/
        if ( (v88.i8[0] & 1) != 0 ) /*0x10761fb47*/
          LODWORD(v30) = (_DWORD)v89; /*0x10761fb49*/
        else
          v30 = &v88.i8[1]; /*0x10761fb52*/
        FLog::FastLogFormatted( /*0x10761fb68*/
          a1: v23,
          a2: v24,
          a3: (unsigned int)"[DFLog::KeyRingUpdate] updateFromFile detected no changes, name = %s, hash = %s.",
          a4: (_DWORD)v26,
          a5: (_DWORD)v30,
          a6: v25);
        if ( (v96.i8[0] & 1) != 0 ) /*0x10761fb74*/
          operator delete(a1: v97); /*0x10761fb7d*/
        LOBYTE(v23) = (_BYTE)DFLog::KeyRingUpdate; /*0x10761fb82*/
      }
      if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v23 != 0 ) /*0x10761fb97*/
      {
        Instance = RBX::Security::KeyRing::getInstance(this: v15); /*0x10761fb9d*/
        if ( Instance != 0 ) /*0x10761fba5*/
        {
          v32 = *(_QWORD *)(Instance + 616); /*0x10761fbab*/
          v78 = v32; /*0x10761fbb2*/
          v33 = *(volatile signed __int64 **)(Instance + 624); /*0x10761fbb9*/
          v79 = v33; /*0x10761fbc0*/
          if ( v33 != nullptr ) /*0x10761fbca*/
            _InterlockedIncrement64(v33 + 1); /*0x10761fbd0*/
          else
            v33 = nullptr; /*0x10761fcdb*/
          if ( v32 != 0 ) /*0x10761fce0*/
          {
            RBX::Security::KeyRing::getConfigLogName(this: (RBX::Security::KeyRing *)&v90); /*0x10761fcf4*/
            if ( (v90 & 1) != 0 ) /*0x10761fd00*/
              v36 = (const char *)v92; /*0x10761fd02*/
            else
              v36 = (char *)&v90 + 1; /*0x10761fd0b*/
            if ( (v88.i8[0] & 1) != 0 ) /*0x10761fd19*/
              v37 = (const char *)v89; /*0x10761fd1b*/
            else
              v37 = &v88.i8[1]; /*0x10761fd24*/
            RBX::format(this: (RBX *)&v96, a2: "updateFromFile detected no changes, name = %s, hash = %s.", v36, v37); /*0x10761fd3b*/
            (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __m128i *))(*(_QWORD *)v32 + 8LL))( /*0x10761fd54*/
              a1: v32,
              a2: &DFLog::KeyRingUpdate,
              a3: &v96);
            if ( (v96.i8[0] & 1) != 0 ) /*0x10761fd5e*/
              operator delete(a1: v97); /*0x10761fd67*/
            if ( (v90 & 1) != 0 ) /*0x10761fd73*/
              operator delete(a1: v92); /*0x10761fd7c*/
          }
          if ( v33 != nullptr && _InterlockedExchangeAdd64(v33 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761fd96*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v33 + 16))(a1: v33); /*0x10761fd9e*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v33); /*0x10761fda4*/
          }
        }
      }
      if ( v93 == 0 ) /*0x10761fdb0*/
        RBX::Security::KeyRing::sendCounter(this: v94, a2: "KeyRingNoUpdate"); /*0x10761fdc0*/
      v35 = 2; /*0x10761fdc5*/
      if ( DFFlag::DebugKeyRingAlwaysLoad != 1 ) /*0x10761fdd1*/
        goto LABEL_202; /*0x10761fdd1*/
      v23 = (int)DFLog::KeyRingUpdate; /*0x10761fdd7*/
    }
    if ( (unsigned __int8)v23 >= 6u && BYTE1(v23) >= 3u ) /*0x10761fdeb*/
    {
      v38 = qword_10D826CE8; /*0x10761fdf6*/
      RBX::Security::KeyRing::getConfigLogName(this: (RBX::Security::KeyRing *)&v96); /*0x10761fe0b*/
      if ( (v96.i8[0] & 1) != 0 ) /*0x10761fe17*/
        LODWORD(v39) = (_DWORD)v97; /*0x10761fe19*/
      else
        v39 = &v96.i8[1]; /*0x10761fe22*/
      if ( (v88.i8[0] & 1) != 0 ) /*0x10761fe30*/
        LODWORD(v40) = (_DWORD)v89; /*0x10761fe32*/
      else
        v40 = &v88.i8[1]; /*0x10761fe3b*/
      if ( (v86.i8[0] & 1) != 0 ) /*0x10761fe49*/
        LODWORD(v41) = (_DWORD)v87; /*0x10761fe4b*/
      else
        v41 = &v86.i8[1]; /*0x10761fe54*/
      FLog::FastLogFormatted( /*0x10761fe6a*/
        a1: v23,
        a2: v38,
        a3: (unsigned int)"[DFLog::KeyRingUpdate] updateFromFile detected changes, name = %s, new = %s, old = %s.",
        a4: (_DWORD)v39,
        a5: (_DWORD)v40,
        a6: (_DWORD)v41);
      if ( (v96.i8[0] & 1) != 0 ) /*0x10761fe76*/
        operator delete(a1: v97); /*0x10761fe7f*/
      LOBYTE(v23) = (_BYTE)DFLog::KeyRingUpdate; /*0x10761fe84*/
    }
    if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v23 != 0 ) /*0x10761fe99*/
    {
      v42 = RBX::Security::KeyRing::getInstance(this: v15); /*0x10761fe9f*/
      if ( v42 != 0 ) /*0x10761fea7*/
      {
        v43 = *(_QWORD *)(v42 + 616); /*0x10761fead*/
        v78 = v43; /*0x10761feb4*/
        v44 = *(volatile signed __int64 **)(v42 + 624); /*0x10761febb*/
        v79 = v44; /*0x10761fec2*/
        if ( v44 != nullptr ) /*0x10761fecc*/
          _InterlockedIncrement64(v44 + 1); /*0x10761fece*/
        else
          v44 = nullptr; /*0x10761fed5*/
        if ( v43 != 0 ) /*0x10761feda*/
        {
          RBX::Security::KeyRing::getConfigLogName(this: (RBX::Security::KeyRing *)&v90); /*0x10761feee*/
          if ( (v90 & 1) != 0 ) /*0x10761fefa*/
            v45 = (const char *)v92; /*0x10761fefc*/
          else
            v45 = (char *)&v90 + 1; /*0x10761ff05*/
          if ( (v88.i8[0] & 1) != 0 ) /*0x10761ff13*/
            v46 = (const char *)v89; /*0x10761ff15*/
          else
            v46 = &v88.i8[1]; /*0x10761ff1e*/
          if ( (v86.i8[0] & 1) != 0 ) /*0x10761ff2c*/
            v47 = (const char *)v87; /*0x10761ff2e*/
          else
            v47 = &v86.i8[1]; /*0x10761ff37*/
          RBX::format( /*0x10761ff4e*/
            this: (RBX *)&v96,
            a2: "updateFromFile detected changes, name = %s, new = %s, old = %s.",
            v45,
            v46,
            v47);
          (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __m128i *))(*(_QWORD *)v43 + 8LL))( /*0x10761ff67*/
            a1: v43,
            a2: &DFLog::KeyRingUpdate,
            a3: &v96);
          if ( (v96.i8[0] & 1) != 0 ) /*0x10761ff71*/
            operator delete(a1: v97); /*0x10761ff7a*/
          if ( (v90 & 1) != 0 ) /*0x10761ff86*/
            operator delete(a1: v92); /*0x10761ff8f*/
        }
        if ( v44 != nullptr && _InterlockedExchangeAdd64(v44 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761ffa9*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v44 + 16))(a1: v44); /*0x10761ffb1*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v44); /*0x10761ffb7*/
        }
      }
    }
    if ( (v83 & 1) != 0 ) /*0x10761ffc3*/
      v19 = (const __m128i *)v85; /*0x10761ffc5*/
    *v16 = _mm_loadu_si128(v19); /*0x10761ffd2*/
    v48 = RBX::Security::KeyRing::parseConfig(a1: v94, a2: (__int64)&v81, a3: (unsigned __int8)v80); /*0x10761ffed*/
    v51 = DFLog::KeyRing; /*0x10761fff2*/
    v52 = (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u; /*0x10762000b*/
    if ( v48 != 0 )
    {
      v53 = v94; /*0x107620013*/
      if ( v52 )
      {
        if ( (*((_BYTE *)v94 + 504) & 1) != 0 ) /*0x10762002c*/
          v54 = *((_QWORD *)v94 + 65); /*0x107620063*/
        else
          LODWORD(v54) = (_DWORD)v94 + 505; /*0x10762002e*/
        FLog::FastLogFormatted(
          a1: (_DWORD)DFLog::KeyRing,
          a2: qword_10D826CD8,
          a3: (unsigned int)"[DFLog::KeyRing] Parsed KeyRing config at: %s",
          a4: v54,
          a5: v49,
          a6: v50);
        LOBYTE(v51) = (_BYTE)DFLog::KeyRing; /*0x107620079*/
        v53 = v94; /*0x107620080*/
      }
      if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v51 != 0 )
      {
        v57 = RBX::Security::KeyRing::getInstance(this: v51); /*0x10762009d*/
        if ( v57 != 0 )
        {
          v58 = *(_QWORD *)(v57 + 616); /*0x1076200ab*/
          v90 = v58; /*0x1076200b2*/
          v59 = *(volatile signed __int64 **)(v57 + 624); /*0x1076200b9*/
          v91 = v59; /*0x1076200c0*/
          if ( v59 != nullptr ) /*0x1076200ca*/
            _InterlockedIncrement64(v59 + 1); /*0x1076200cc*/
          else
            v59 = nullptr; /*0x107620143*/
          if ( v58 != 0 )
          {
            v63 = (*((_BYTE *)v53 + 504) & 1) != 0 ? *((const char **)v53 + 65) : (char *)v53 + 505;
            RBX::format(this: (RBX *)&v96, a2: "Parsed KeyRing config at: %s", v63);
            (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __m128i *))(*(_QWORD *)v58 + 8LL))( /*0x1076201bb*/
              a1: v58,
              a2: &DFLog::KeyRing,
              a3: &v96);
            if ( (v96.i8[0] & 1) != 0 ) /*0x1076201c5*/
              operator delete(a1: v97); /*0x1076201ce*/
          }
          if ( v59 != nullptr && _InterlockedExchangeAdd64(v59 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1076201e8*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v59 + 16))(a1: v59); /*0x1076201f0*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v59); /*0x1076201f6*/
          }
        }
      }
      v65 = *((__int64 **)v53 + 5); /*0x1076201fb*/
      if ( v65 != nullptr ) /*0x107620203*/
      {
        v66 = (RBX::Security::KeyRing *)&v96.i8[1]; /*0x107620209*/
        do /*0x1076203ba*/
        {
          v67 = DFLog::KeyRing; /*0x10762021e*/
          if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u ) /*0x107620233*/
          {
            if ( (v65[2] & 1) != 0 ) /*0x10762023f*/
              v68 = v65[4]; /*0x107620247*/
            else
              LODWORD(v68) = (_DWORD)v65 + 17; /*0x107620241*/
            FLog::FastLogFormatted( /*0x107620267*/
              a1: (_DWORD)DFLog::KeyRing,
              a2: qword_10D826CD8,
              a3: (unsigned int)"[DFLog::KeyRing] KeyRing application \"%s\" has %lld keys.",
              a4: v68,
              a5: (v65[6] - v65[5]) >> 5,
              a6: v50);
            LOBYTE(v67) = (_BYTE)DFLog::KeyRing; /*0x10762026c*/
          }
          if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v67 != 0 ) /*0x107620283*/
          {
            v69 = RBX::Security::KeyRing::getInstance(this: v67); /*0x107620289*/
            if ( v69 != 0 ) /*0x107620291*/
            {
              v70 = v66; /*0x107620297*/
              v71 = *(_QWORD *)(v69 + 616); /*0x10762029a*/
              v90 = v71; /*0x1076202a1*/
              v72 = *(volatile signed __int64 **)(v69 + 624); /*0x1076202a8*/
              v91 = v72; /*0x1076202af*/
              if ( v72 != nullptr ) /*0x1076202b9*/
                _InterlockedIncrement64(v72 + 1); /*0x1076202bb*/
              else
                v72 = nullptr; /*0x1076202c3*/
              if ( v71 != 0 ) /*0x1076202c9*/
              {
                if ( (v65[2] & 1) != 0 ) /*0x1076202d0*/
                  v73 = (const char *)v65[4]; /*0x1076202d8*/
                else
                  v73 = (char *)v65 + 17; /*0x1076202d2*/
                RBX::format( /*0x1076202f7*/
                  this: (RBX *)&v96,
                  a2: "KeyRing application \"%s\" has %lld keys.",
                  v73,
                  (v65[6] - v65[5]) >> 5);
                (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __m128i *))(*(_QWORD *)v71 + 8LL))( /*0x10762030c*/
                  a1: v71,
                  a2: &DFLog::KeyRing,
                  a3: &v96);
                if ( (v96.i8[0] & 1) != 0 ) /*0x107620316*/
                  operator delete(a1: v97); /*0x10762031f*/
                v72 = v91; /*0x107620324*/
              }
              v66 = v70; /*0x10762032e*/
              if ( v72 != nullptr && _InterlockedExchangeAdd64(v72 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10762034b*/
              {
                (*(void (__fastcall **)(volatile signed __int64 *))(*v72 + 16))(a1: v72); /*0x107620354*/
                std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v72); /*0x10762035a*/
              }
            }
            v53 = v94; /*0x10762035f*/
          }
          if ( (v65[2] & 1) != 0 ) /*0x10762036b*/
            v74 = (const char *)v65[4]; /*0x107620373*/
          else
            v74 = (char *)v65 + 17; /*0x10762036d*/
          RBX::format(this: (RBX *)&v96, a2: "KeyRing%s", v74); /*0x10762037f*/
          v75 = v66; /*0x10762038b*/
          if ( (v96.i8[0] & 1) != 0 ) /*0x10762038e*/
            v75 = v97; /*0x107620390*/
          RBX::Security::KeyRing::sendCounter(this: v53, a2: (const char *)v75); /*0x10762039a*/
          if ( (v96.i8[0] & 1) != 0 ) /*0x1076203a6*/
            operator delete(a1: v97); /*0x1076203af*/
          v65 = (__int64 *)*v65; /*0x1076203b4*/
        }
        while ( v65 != nullptr ); /*0x1076203ba*/
      }
      if ( v93 != 0 ) /*0x1076203ce*/
        RBX::Security::KeyRing::sendCounter(this: v94, a2: "KeyRingDynamicUpdate"); /*0x1076203de*/
      v35 = 1; /*0x1076203e3*/
      RBX::Security::KeyRing::sendCounter(this: v94, a2: "KeyRingUpdated"); /*0x1076203f6*/
    }
    else
    {
      v55 = v94; /*0x10762003a*/
      if ( v52 )
      {
        if ( (*((_BYTE *)v94 + 504) & 1) != 0 ) /*0x107620057*/
          v56 = *((_QWORD *)v94 + 65); /*0x1076200d3*/
        else
          LODWORD(v56) = (_DWORD)v94 + 505; /*0x107620059*/
        FLog::FastLogFormatted(
          a1: (_DWORD)DFLog::KeyRing,
          a2: qword_10D826CD8,
          a3: (unsigned int)"[DFLog::KeyRing] Cannot parse KeyRing config at: %s",
          a4: v56,
          a5: v49,
          a6: v50);
        LOBYTE(v51) = (_BYTE)DFLog::KeyRing; /*0x1076200e9*/
        v55 = v94; /*0x1076200f0*/
      }
      if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v51 != 0 )
      {
        v60 = RBX::Security::KeyRing::getInstance(this: v51); /*0x10762010d*/
        if ( v60 != 0 )
        {
          v61 = *(_QWORD *)(v60 + 616); /*0x10762011b*/
          v90 = v61; /*0x107620122*/
          v62 = *(volatile signed __int64 **)(v60 + 624); /*0x107620129*/
          v91 = v62; /*0x107620130*/
          if ( v62 != nullptr ) /*0x10762013a*/
            _InterlockedIncrement64(v62 + 1); /*0x10762013c*/
          else
            v62 = nullptr; /*0x107620163*/
          if ( v61 != 0 )
          {
            v64 = (*((_BYTE *)v55 + 504) & 1) != 0 ? *((const char **)v55 + 65) : (char *)v55 + 505;
            RBX::format(this: (RBX *)&v96, a2: "Cannot parse KeyRing config at: %s", v64);
            (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __m128i *))(*(_QWORD *)v61 + 8LL))( /*0x107620431*/
              a1: v61,
              a2: &DFLog::KeyRing,
              a3: &v96);
            if ( (v96.i8[0] & 1) != 0 ) /*0x10762043b*/
              operator delete(a1: v97); /*0x107620444*/
          }
          if ( v62 != nullptr && _InterlockedExchangeAdd64(v62 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10762045e*/
          {
            (*(void (__fastcall **)(volatile signed __int64 *))(*v62 + 16))(a1: v62); /*0x107620466*/
            std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v62); /*0x10762046c*/
          }
        }
      }
      if ( DFFlag::KeyRingParseErrorStopUsingOldSystem == 0 ) /*0x107620478*/
        RBX::Security::KeyRing::sendCounter(this: v94, a2: "KeyRingParseError"); /*0x107620488*/
      if ( v93 != 0 ) /*0x107620494*/
        RBX::Security::KeyRing::sendCounter(this: v94, a2: "KeyRingDynamicParseError"); /*0x1076204a4*/
      RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)18,std::enable_if<false,void>>( /*0x1076204b7*/
        a1: &v96,
        a2: &RBX::Telemetry::kKeyRingParseError);
      RBX::Telemetry::FieldsContainer::addField(a1: v98, a2: "KeyRingParseError", a3: 17, a4: 1, a5: 1); /*0x1076204da*/
      RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)&v96); /*0x1076204e6*/
      RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)&v96); /*0x1076204f9*/
      v35 = 0; /*0x1076204fe*/
    }
LABEL_202:
    if ( (v86.i8[0] & 1) != 0 ) /*0x107620507*/
      operator delete(a1: v87); /*0x107620510*/
    if ( (v88.i8[0] & 1) != 0 ) /*0x10762051c*/
      operator delete(a1: v89); /*0x107620525*/
    if ( (v83 & 1) != 0 ) /*0x107620531*/
      operator delete(a1: v85); /*0x10762053a*/
    goto LABEL_208; /*0x10762053a*/
  }
  v13 = DFLog::KeyRing; /*0x10761f8ef*/
  if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u )
  {
    if ( (*((_BYTE *)this + 504) & 1) != 0 ) /*0x10761f91f*/
      v14 = *((_QWORD *)this + 65); /*0x10761fac9*/
    else
      LODWORD(v14) = (_DWORD)this + 505; /*0x10761f925*/
    FLog::FastLogFormatted(
      a1: (_DWORD)DFLog::KeyRing,
      a2: qword_10D826CD8,
      a3: (unsigned int)"[DFLog::KeyRing] Cannot open KeyRing config at: %s",
      a4: v14,
      a5: v5,
      a6: v6);
    LOBYTE(v13) = (_BYTE)DFLog::KeyRing; /*0x10761fadf*/
  }
  if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v13 != 0 )
  {
    v27 = RBX::Security::KeyRing::getInstance(this: v13); /*0x10761fafc*/
    if ( v27 != 0 )
    {
      v28 = *(_QWORD *)(v27 + 616); /*0x10761fb0a*/
      v83 = v28; /*0x10761fb11*/
      v29 = *(volatile signed __int64 **)(v27 + 624); /*0x10761fb18*/
      v84 = v29; /*0x10761fb1f*/
      if ( v29 != nullptr ) /*0x10761fb29*/
        _InterlockedIncrement64(v29 + 1); /*0x10761fb2f*/
      else
        v29 = nullptr; /*0x10761fbda*/
      if ( v28 != 0 )
      {
        v34 = (*((_BYTE *)this + 504) & 1) != 0 ? *((const char **)this + 65) : (char *)this + 505;
        RBX::format(this: (RBX *)&v96, a2: "Cannot open KeyRing config at: %s", v34);
        (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, __m128i *))(*(_QWORD *)v28 + 8LL))( /*0x10761fc27*/
          a1: v28,
          a2: &DFLog::KeyRing,
          a3: &v96);
        if ( (v96.i8[0] & 1) != 0 ) /*0x10761fc31*/
          operator delete(a1: v97); /*0x10761fc3a*/
      }
      if ( v29 != nullptr && _InterlockedExchangeAdd64(v29 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x10761fc54*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v29 + 16))(a1: v29); /*0x10761fc5c*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v29); /*0x10761fc62*/
      }
    }
  }
  if ( DFFlag::KeyRingFileErrorStopUsingOldSystem == 0 ) /*0x10761fc6e*/
    RBX::Security::KeyRing::sendCounter((RBX::Security::KeyRing *)this, a2: "KeyRingFileError"); /*0x10761fc7a*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)18,std::enable_if<false,void>>( /*0x10761fc8d*/
    a1: &v96,
    a2: &RBX::Telemetry::kKeyRingFileError);
  RBX::Telemetry::FieldsContainer::addField(a1: v98, a2: "KeyRingFileError", a3: 16, a4: 1, a5: 1); /*0x10761fcb0*/
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)&v96); /*0x10761fcbc*/
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)&v96); /*0x10761fccf*/
  v35 = 0; /*0x10761fcd4*/
LABEL_208:
  v100[0] = &off_10CA6D458; /*0x10762053f*/
  v102[0] = off_10CA6D480; /*0x107620557*/
  std::filebuf::~filebuf(a1: (__int64)v101); /*0x107620561*/
  std::istream::~istream(a1: v100, a2: off_10CA6D498); /*0x107620574*/
  std::ios::~ios(a1: v102); /*0x107620580*/
  if ( (v81 & 1) != 0 ) /*0x10762058c*/
    operator delete(a1: v82); /*0x107620595*/
  RBX::Security::ScopedSendKeyRingOutOfDateToDiag::~ScopedSendKeyRingOutOfDateToDiag(this: (RBX::Security::ScopedSendKeyRingOutOfDateToDiag *)&v77); /*0x1076205a1*/
  return v35; /*0x1076205b8*/
}

// Address: 0x1076207e0 | Name: __ZNK3RBX8Security7KeyRing11sendCounterEPKc
void __fastcall RBX::Security::KeyRing::sendCounter(
        RBX::Security::KeyRing *this,
        const char *a2,
        __int64 a3,
        __int64 a4)
{
  void (__fastcall *v4)(_BYTE *, __int64, _QWORD); // r14
  _BYTE v5[16]; // [rsp+8h] [rbp-28h] BYREF
  void *v6; // [rsp+18h] [rbp-18h]

  v4 = *((void (__fastcall **)(_BYTE *, __int64, _QWORD))this + 62); /*0x1076207eb*/
  if ( v4 != nullptr ) /*0x1076207f5*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v5, a2, a3, a4); /*0x1076207fe*/
    v4(a1: v5, a2: 1, a3: 0); /*0x10762080d*/
    if ( (v5[0] & 1) != 0 ) /*0x107620814*/
      operator delete(a1: v6); /*0x10762081a*/
  }
}

// Address: 0x107620842 | Name: __ZNK3RBX8Security7KeyRing16getConfigLogNameEv
RBX::Security::KeyRing *__fastcall RBX::Security::KeyRing::getConfigLogName(RBX::Security::KeyRing *this, __int64 a2)
{
  __int64 v4; // r14
  boost::shared_mutex *v6; // [rsp+0h] [rbp-20h] BYREF
  char v7; // [rsp+8h] [rbp-18h]

  v6 = (boost::shared_mutex *)(a2 + 64); /*0x10762085b*/
  v7 = 0; /*0x10762085e*/
  boost::shared_lock<RBX::BoostSharedMutex>::lock(a1: (__int64)&v6); /*0x107620862*/
  if ( (*(_BYTE *)(a2 + 560) & 1) != 0 ) /*0x10762086f*/
  {
    std::string::__init_copy_ctor_external(a1: this, a2: *(_QWORD *)(a2 + 576), a3: *(_QWORD *)(a2 + 568)); /*0x10762089a*/
  }
  else
  {
    v4 = a2 + 560; /*0x107620871*/
    *((_QWORD *)this + 2) = *(_QWORD *)(v4 + 16); /*0x10762087c*/
    *(_OWORD *)this = *(_OWORD *)v4; /*0x107620884*/
  }
  if ( v7 == 1 ) /*0x1076208a3*/
    boost::shared_mutex::unlock_shared(this: v6); /*0x1076208a9*/
  return this; /*0x1076208b1*/
}

// Address: 0x1076208d8 | Name: __ZN3RBX8Security7KeyRing16moveLastErrorStrEv
RBX::Security::KeyRing *__fastcall RBX::Security::KeyRing::moveLastErrorStr(RBX::Security::KeyRing *this, __int64 a2)
{
  *((_QWORD *)this + 2) = *(_QWORD *)(a2 + 648); /*0x1076208e6*/
  *(_OWORD *)this = *(_OWORD *)(a2 + 632); /*0x1076208f1*/
  *(_OWORD *)(a2 + 632) = 0; /*0x1076208f7*/
  *(_QWORD *)(a2 + 648) = 0; /*0x1076208fe*/
  return this; /*0x107620909*/
}

// Address: 0x10762090c | Name: __ZN3RBX8Security7KeyRing16reportReasonCstrENS1_12ReportReasonE
const char *__fastcall RBX::Security::KeyRing::reportReasonCstr(unsigned int a1)
{
  if ( a1 > 3 ) /*0x107620913*/
    return "unknown"; /*0x107620927*/
  else
    return (char *)dword_10A482564 + dword_10A482564[a1]; /*0x107620922*/
}

// Address: 0x107620930 | Name: __ZN3RBX8Security7KeyRing14initConfigLoopERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEdb
__int64 __fastcall RBX::Security::KeyRing::initConfigLoop(
        void **this,
        __int128 *a2,
        unsigned int a3,
        double a4,
        __int64 a5,
        __int64 a6,
        int a7)
{
  unsigned int v7; // r14d
  RBX::Security::KeyRing *v10; // rdi
  __int64 v11; // rcx
  const char *v12; // r8
  __int64 Instance; // rax
  __int64 v14; // r13
  volatile signed __int64 *v15; // r12
  __int64 v16; // rdx
  const char *v17; // rcx
  __int64 v18; // rdx
  __int64 v19; // rcx
  int v20; // r8d
  int v21; // r9d
  int v22; // ecx
  int v23; // r8d
  int v24; // r9d
  std::__shared_weak_count *v25; // rbx
  __int64 v26; // rax
  RBX::Security::KeyRing *v27; // rdi
  __int64 v28; // rcx
  RBX::Security::KeyRing *v29; // rdi
  __int64 v30; // rax
  __int64 v31; // r15
  volatile signed __int64 *v32; // r14
  __int64 v33; // rax
  __int64 v34; // r12
  volatile signed __int64 *v35; // r14
  const char *v36; // rdx
  const char *v37; // r15
  std::__shared_weak_count *v39[2]; // [rsp+0h] [rbp-2E0h] BYREF
  char v40; // [rsp+10h] [rbp-2D0h]
  __int64 v41; // [rsp+18h] [rbp-2C8h] BYREF
  volatile signed __int64 *v42; // [rsp+20h] [rbp-2C0h]
  double v43; // [rsp+28h] [rbp-2B8h]
  __int128 v44; // [rsp+30h] [rbp-2B0h] BYREF
  void *v45; // [rsp+40h] [rbp-2A0h]
  _BYTE v46[24]; // [rsp+50h] [rbp-290h] BYREF
  char v47; // [rsp+68h] [rbp-278h]
  _BYTE v48[7]; // [rsp+69h] [rbp-277h] BYREF
  _BYTE *v49; // [rsp+70h] [rbp-270h]
  _BYTE v50[536]; // [rsp+98h] [rbp-248h] BYREF

  v7 = a3; /*0x107620944*/
  v43 = a4; /*0x107620947*/
  v10 = DFLog::KeyRingUpdate; /*0x107620963*/
  if ( (unsigned __int8)DFLog::KeyRingUpdate >= 6u && BYTE1(DFLog::KeyRingUpdate) >= 3u ) /*0x107620978*/
  {
    if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x10762098a*/
      v11 = *((_QWORD *)a2 + 2); /*0x10762098c*/
    else
      LODWORD(v11) = (_DWORD)a2 + 1; /*0x107620992*/
    v12 = "functional"; /*0x10762099d*/
    if ( (_BYTE)a3 != 0 ) /*0x1076209a7*/
      v12 = "diagnostic"; /*0x1076209a7*/
    FLog::FastLogFormatted( /*0x1076209bc*/
      a1: (_DWORD)DFLog::KeyRingUpdate,
      a2: qword_10D826CE8,
      a3: (unsigned int)"[DFLog::KeyRingUpdate] initConfigLoop(%s, %f, %s)",
      a4: v11,
      a5: (_DWORD)v12,
      a6: a7);
    LOBYTE(v10) = (_BYTE)DFLog::KeyRingUpdate; /*0x1076209c1*/
  }
  if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v10 != 0 ) /*0x1076209d8*/
  {
    Instance = RBX::Security::KeyRing::getInstance(this: v10); /*0x1076209de*/
    if ( Instance != 0 ) /*0x1076209e6*/
    {
      v14 = *(_QWORD *)(Instance + 616); /*0x1076209ec*/
      *(_QWORD *)&v44 = v14; /*0x1076209f3*/
      v15 = *(volatile signed __int64 **)(Instance + 624); /*0x1076209fa*/
      *((_QWORD *)&v44 + 1) = v15; /*0x107620a01*/
      if ( v15 != nullptr ) /*0x107620a0b*/
        _InterlockedIncrement64(v15 + 1); /*0x107620a0d*/
      else
        v15 = nullptr; /*0x107620a15*/
      if ( v14 != 0 ) /*0x107620a1b*/
      {
        if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x107620a21*/
          v16 = *((_QWORD *)a2 + 2); /*0x107620a23*/
        else
          v16 = (__int64)a2 + 1; /*0x107620a29*/
        v17 = "functional"; /*0x107620a34*/
        if ( (_BYTE)v7 != 0 ) /*0x107620a3e*/
          v17 = "diagnostic"; /*0x107620a3e*/
        RBX::format(this: (RBX *)v46, a2: "initConfigLoop(%s, %f, %s)", v16, v17, v43); /*0x107620a5a*/
        (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, _BYTE *))(*(_QWORD *)v14 + 8LL))( /*0x107620a74*/
          a1: v14,
          a2: &DFLog::KeyRingUpdate,
          a3: v46);
        if ( (v46[0] & 1) != 0 ) /*0x107620a7e*/
          operator delete(a1: *(void **)&v46[16]); /*0x107620a87*/
      }
      if ( v15 != nullptr && _InterlockedExchangeAdd64(v15 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107620aa2*/
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*v15 + 16))(a1: v15); /*0x107620aab*/
        std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v15); /*0x107620ab1*/
      }
    }
  }
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x107620aba*/
  {
    std::string::__init_copy_ctor_external(a1: &v44, a2: *((_QWORD *)a2 + 2), a3: *((_QWORD *)a2 + 1)); /*0x107620ae3*/
  }
  else
  {
    v45 = *((void **)a2 + 2); /*0x107620ac0*/
    v44 = *a2; /*0x107620acb*/
  }
  boost::system::system_category(); /*0x107620ae8*/
  if ( (boost::filesystem::detail::status(this: (boost::filesystem::path *)&v44, a2: 0) & 0xFFFFFFFE) != 0 )
  {
    std::string::operator=(a1: this + 63, a2: &v44); /*0x107620b14*/
    if ( DFFlag::KeyRingReset == 1 /*0x107620b30*/
      && (unsigned __int8)RBX::SimpleTimer::isValid(this: (RBX::SimpleTimer *)(this + 66)) != 0 )
    {
      RBX::Security::KeyRing::stopConfigLoop((RBX::Security::KeyRing *)this); /*0x107620b35*/
    }
    if ( (unsigned int)RBX::Security::KeyRing::updateFromFile((__m128i *)this, a2: (unsigned __int8)v7) != 0 ) /*0x107620b48*/
    {
      if ( DFFlag::KeyRingReset == 1 ) /*0x107620b55*/
      {
        *((_BYTE *)this + 594) = v7 ^ 1; /*0x107620b5c*/
        if ( (_BYTE)v7 == 0 ) /*0x107620b65*/
          *(this + 75) = (char *)*(this + 75) + 1; /*0x107620b67*/
      }
      RBX::Security::KeyRing::sendConfigReport(a1: this, a2: 1); /*0x107620b76*/
      RBX::weak_from<RBX::Security::KeyRing>(a1: v39, a2: this); /*0x107620b85*/
      v40 = v7; /*0x107620b8a*/
      *(_QWORD *)v46 = &off_10CB62578; /*0x107620b9f*/
      *(_OWORD *)&v46[8] = *(_OWORD *)v39; /*0x107620ba9*/
      *(_OWORD *)v39 = 0; /*0x107620bb1*/
      v47 = v7; /*0x107620bb8*/
      memset(v48, 0, sizeof(v48)); /*0x107620bbe*/
      v49 = v46; /*0x107620bc6*/
      RBX::SimpleTimer::callEvery(a1: &v41, a2: v46, a3: 0, a4: v43); /*0x107620bde*/
      std::shared_ptr<RBX::TimerData>::operator=[abi:ne200100](a1: this + 66, a2: &v41); /*0x107620bf7*/
      v25 = (std::__shared_weak_count *)v42; /*0x107620bfc*/
      if ( v42 != nullptr && _InterlockedExchangeAdd64(v42 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107620c16*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v25 + 16LL))(a1: v25); /*0x107620c1e*/
        std::__shared_weak_count::__release_weak(this: v25); /*0x107620c24*/
      }
      if ( v49 == v46 ) /*0x107620c33*/
      {
        v26 = 32; /*0x107620d11*/
      }
      else
      {
        v26 = 40; /*0x107620c39*/
        if ( v49 == nullptr ) /*0x107620c41*/
          goto LABEL_54; /*0x107620c41*/
      }
      (*(void (**)(void))(*(_QWORD *)v49 + v26))(); /*0x107620d19*/
LABEL_54:
      if ( v39[1] != nullptr ) /*0x107620d26*/
        std::__shared_weak_count::__release_weak(this: v39[1]); /*0x107620d28*/
      LOBYTE(v7) = v7 ^ 1; /*0x107620d2d*/
      goto LABEL_90; /*0x107620d31*/
    }
    v29 = DFLog::KeyRingUpdate; /*0x107620c86*/
    if ( (unsigned __int8)DFLog::KeyRingUpdate >= 6u && BYTE1(DFLog::KeyRingUpdate) >= 3u ) /*0x107620c9b*/
    {
      LOBYTE(v22) = (unsigned __int8)DFLog::KeyRingUpdate < 6u; /*0x107620c96*/
      FLog::FastLogFormatted( /*0x107620cb2*/
        a1: (_DWORD)DFLog::KeyRingUpdate,
        a2: qword_10D826CE8,
        a3: (unsigned int)"[DFLog::KeyRingUpdate] initConfigLoop failed while parsing config.  loop stopped",
        a4: v22,
        a5: v23,
        a6: v24);
      LOBYTE(v29) = (_BYTE)DFLog::KeyRingUpdate; /*0x107620cb7*/
    }
    if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v29 != 0 ) /*0x107620cce*/
    {
      v30 = RBX::Security::KeyRing::getInstance(this: v29); /*0x107620cd4*/
      if ( v30 != 0 ) /*0x107620cdc*/
      {
        v31 = *(_QWORD *)(v30 + 616); /*0x107620ce2*/
        v41 = v31; /*0x107620ce9*/
        v32 = *(volatile signed __int64 **)(v30 + 624); /*0x107620cf0*/
        v42 = v32; /*0x107620cf7*/
        if ( v32 != nullptr ) /*0x107620d01*/
          _InterlockedIncrement64(v32 + 1); /*0x107620d07*/
        else
          v32 = nullptr; /*0x107620ef2*/
        if ( v31 != 0 ) /*0x107620ef8*/
        {
          RBX::format(this: (RBX *)v46, a2: "initConfigLoop failed while parsing config.  loop stopped"); /*0x107620f0a*/
          (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, _BYTE *))(*(_QWORD *)v31 + 8LL))( /*0x107620f23*/
            a1: v31,
            a2: &DFLog::KeyRingUpdate,
            a3: v46);
          if ( (v46[0] & 1) != 0 ) /*0x107620f2d*/
            operator delete(a1: *(void **)&v46[16]); /*0x107620f36*/
        }
        if ( v32 != nullptr && _InterlockedExchangeAdd64(v32 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107620f50*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v32 + 16))(a1: v32); /*0x107620f58*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v32); /*0x107620f5e*/
        }
      }
    }
    v7 = 0; /*0x107620f63*/
    RBX::Security::KeyRing::sendConfigReport(a1: this, a2: 0); /*0x107620f6b*/
  }
  else
  {
    v27 = DFLog::KeyRing; /*0x107620c4c*/
    LOBYTE(v19) = (unsigned __int8)DFLog::KeyRing < 6u; /*0x107620c5c*/
    if ( (unsigned __int8)DFLog::KeyRing >= 6u && BYTE1(DFLog::KeyRing) >= 3u )
    {
      if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x107620c77*/
        v28 = *((_QWORD *)a2 + 2); /*0x107620c7d*/
      else
        LODWORD(v28) = (_DWORD)a2 + 1; /*0x107620d36*/
      FLog::FastLogFormatted(
        a1: (_DWORD)DFLog::KeyRing,
        a2: qword_10D826CD8,
        a3: (unsigned int)"[DFLog::KeyRing] initConfigLoop missing KeyRing config at: %s.  loop stopped",
        a4: v28,
        a5: v20,
        a6: v21);
      LOBYTE(v27) = (_BYTE)DFLog::KeyRing; /*0x107620d48*/
    }
    if ( DFFlag::DebugKeyRingLogService == 1 && (_BYTE)v27 != 0 )
    {
      v33 = RBX::Security::KeyRing::getInstance(this: v27); /*0x107620d65*/
      if ( v33 != 0 )
      {
        v34 = *(_QWORD *)(v33 + 616); /*0x107620d73*/
        v41 = v34; /*0x107620d7a*/
        v35 = *(volatile signed __int64 **)(v33 + 624); /*0x107620d81*/
        v42 = v35; /*0x107620d88*/
        if ( v35 != nullptr ) /*0x107620d92*/
          _InterlockedIncrement64(v35 + 1); /*0x107620d94*/
        else
          v35 = nullptr; /*0x107620d9b*/
        if ( v34 != 0 )
        {
          v36 = (*(_BYTE *)a2 & 1) != 0 ? *((const char **)a2 + 2) : (char *)a2 + 1;
          RBX::format(this: (RBX *)v46, a2: "initConfigLoop missing KeyRing config at: %s.  loop stopped", v36);
          (*(void (__fastcall **)(__int64, RBX::Security::KeyRing **, _BYTE *))(*(_QWORD *)v34 + 8LL))( /*0x107620ddd*/
            a1: v34,
            a2: &DFLog::KeyRing,
            a3: v46);
          if ( (v46[0] & 1) != 0 ) /*0x107620de7*/
            operator delete(a1: *(void **)&v46[16]); /*0x107620df0*/
        }
        if ( v35 != nullptr && _InterlockedExchangeAdd64(v35 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x107620e0a*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v35 + 16))(a1: v35); /*0x107620e12*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v35); /*0x107620e18*/
        }
      }
    }
    if ( DFFlag::KeyRingMissingStopUsingOldSystem == 0 ) /*0x107620e24*/
      RBX::Security::KeyRing::sendCounter((RBX::Security::KeyRing *)this, a2: "KeyRingMissing", a3: v18, a4: v19); /*0x107620e30*/
    if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x107620e39*/
      v37 = *((const char **)a2 + 2); /*0x107620e3b*/
    else
      v37 = (char *)a2 + 1; /*0x107620e41*/
    RBX::format(this: (RBX *)v46, a2: "noFile:%s", v37); /*0x107620e57*/
    if ( (*(_BYTE *)(this + 79) & 1) != 0 ) /*0x107620e6a*/
      operator delete(a1: *(this + 81)); /*0x107620e73*/
    qmemcpy(this + 79, v46, 24); /*0x107620e7f*/
    RBX::Security::KeyRing::sendConfigReport(a1: this, a2: 0); /*0x107620e93*/
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)18,std::enable_if<false,void>>( /*0x107620ea6*/
      a1: v46,
      a2: &RBX::Telemetry::kKeyRingMissing);
    RBX::Telemetry::FieldsContainer::addField(a1: v50, a2: "KeyRingFileError", a3: 16, a4: 1, a5: 1); /*0x107620ec9*/
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v46); /*0x107620ed5*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v46); /*0x107620ee8*/
    v7 = 0; /*0x107620eed*/
  }
LABEL_90:
  if ( (v44 & 1) != 0 ) /*0x107620f77*/
    operator delete(a1: v45); /*0x107620f80*/
  return v7; /*0x107620f98*/
}

// Address: 0x107621090 | Name: __ZN3RBX8Security7KeyRing16sendConfigReportENS1_12ReportReasonE
__int64 __fastcall RBX::Security::KeyRing::sendConfigReport(_QWORD *a1, unsigned int a2)
{
  RBX::Time *v4; // r14
  _QWORD *i; // r14
  __int64 v6; // rdx
  __int64 v7; // rbx
  __int64 v8; // r12
  _QWORD *v9; // rbx
  void (__fastcall *v10)(_QWORD *, __int128 *, _BYTE *, __int128 *, _QWORD); // rax
  boost::shared_mutex *v11; // r14
  RBX::Time *v12; // rdi
  __int64 v13; // xmm0_8
  __int64 result; // rax
  _BYTE v15[32]; // [rsp+0h] [rbp-120h] BYREF
  __int128 v16; // [rsp+20h] [rbp-100h] BYREF
  void *v17; // [rsp+30h] [rbp-F0h]
  __int128 v18; // [rsp+40h] [rbp-E0h] BYREF
  void *v19; // [rsp+50h] [rbp-D0h]
  boost::shared_mutex *v20; // [rsp+60h] [rbp-C0h] BYREF
  char v21; // [rsp+68h] [rbp-B8h]
  RBX::Time *v22; // [rsp+70h] [rbp-B0h]
  _QWORD *v23; // [rsp+78h] [rbp-A8h]
  __int128 v24; // [rsp+80h] [rbp-A0h] BYREF
  __int128 v25; // [rsp+90h] [rbp-90h] BYREF
  __int128 v26; // [rsp+A0h] [rbp-80h]
  _QWORD v27[4]; // [rsp+B0h] [rbp-70h] BYREF
  __int128 v28; // [rsp+D0h] [rbp-50h] BYREF
  void *v29; // [rsp+E0h] [rbp-40h]
  unsigned int v30; // [rsp+F4h] [rbp-2Ch]

  if ( a1[76] != 0 ) /*0x1076210ac*/
  {
    memset(v27, 0, 24); /*0x1076210bb*/
    v29 = nullptr; /*0x1076210c5*/
    v28 = 0; /*0x1076210c9*/
    v4 = (RBX::Time *)(a1 + 8); /*0x1076210cd*/
    v20 = (boost::shared_mutex *)(a1 + 8); /*0x1076210d8*/
    v21 = 0; /*0x1076210db*/
    boost::shared_lock<RBX::BoostSharedMutex>::lock(a1: (__int64)&v20); /*0x1076210df*/
    v30 = a2; /*0x1076210e4*/
    v22 = v4; /*0x1076210e8*/
    std::string::operator=(a1: &v28, a2: a1 + 70); /*0x1076210fa*/
    std::vector<RBX::Security::KeyRing::ApplicationVersionReport>::reserve(a1: v27, a2: a1[6]); /*0x107621107*/
    v23 = a1; /*0x10762110c*/
    for ( i = (_QWORD *)a1[5]; i != nullptr; i = (_QWORD *)*i ) /*0x10762111a*/
    {
      v26 = 0; /*0x107621135*/
      v25 = 0; /*0x107621139*/
      v24 = 0; /*0x107621140*/
      std::string::operator=(a1: &v24, a2: i + 2); /*0x10762114a*/
      std::vector<unsigned int>::reserve(a1: (char *)&v25 + 8, a2: (__int64)(i[6] - i[5]) >> 5); /*0x10762115e*/
      v7 = i[5]; /*0x107621163*/
      v8 = i[6]; /*0x107621167*/
      while ( v7 != v8 ) /*0x10762116e*/
      {
        std::vector<unsigned int>::push_back[abi:ne200100](a1: (char *)&v25 + 8, a2: v7 + 24, a3: v6); /*0x107621177*/
        v7 += 32; /*0x10762117c*/
      }
      std::vector<RBX::Security::KeyRing::ApplicationVersionReport>::push_back[abi:ne200100](a1: v27, a2: &v24); /*0x107621189*/
      if ( *((_QWORD *)&v25 + 1) != 0 ) /*0x107621198*/
      {
        *(_QWORD *)&v26 = *((_QWORD *)&v25 + 1); /*0x10762119a*/
        operator delete(a1: *((void **)&v25 + 1)); /*0x10762119e*/
      }
      if ( (v24 & 1) != 0 ) /*0x1076211aa*/
        operator delete(a1: (void *)v25); /*0x1076211b3*/
    }
    if ( v21 == 1 ) /*0x1076211cb*/
      boost::shared_mutex::unlock_shared(this: v20); /*0x1076211d4*/
    v9 = v23; /*0x1076211d9*/
    v10 = (void (__fastcall *)(_QWORD *, __int128 *, _BYTE *, __int128 *, _QWORD))v23[76]; /*0x1076211e0*/
    v17 = v29; /*0x1076211f2*/
    v16 = v28; /*0x1076211fa*/
    v28 = 0; /*0x107621200*/
    v29 = nullptr; /*0x107621206*/
    qmemcpy(v15, v27, 24); /*0x107621215*/
    memset(v27, 0, 24); /*0x107621221*/
    v19 = (void *)v23[81]; /*0x107621237*/
    v18 = *(_OWORD *)(v23 + 79); /*0x107621242*/
    v23[81] = 0; /*0x107621245*/
    *(_OWORD *)(v9 + 79) = 0; /*0x10762124c*/
    v10(a1: v9, a2: &v16, a3: v15, a4: &v18, a5: v30); /*0x10762125d*/
    if ( (v18 & 1) != 0 ) /*0x107621266*/
      operator delete(a1: v19); /*0x10762126f*/
    *(_QWORD *)&v24 = v15; /*0x10762127b*/
    std::vector<RBX::Security::KeyRing::ApplicationVersionReport>::__destroy_vector::operator()[abi:ne200100](); /*0x10762127e*/
    if ( (v16 & 1) != 0 ) /*0x10762128a*/
      operator delete(a1: v17); /*0x107621293*/
    v11 = v22; /*0x107621298*/
    *(_QWORD *)&v24 = v22; /*0x10762129f*/
    BYTE8(v24) = 1; /*0x1076212a6*/
    boost::shared_mutex::lock(this: v22); /*0x1076212b0*/
    RBX::Time::nowFast(this: v12); /*0x1076212b5*/
    v9[73] = v13; /*0x1076212ba*/
    boost::shared_mutex::unlock(this: v11); /*0x1076212c5*/
    if ( (v28 & 1) != 0 ) /*0x1076212ce*/
      operator delete(a1: v29); /*0x1076212d4*/
    *(_QWORD *)&v24 = v27; /*0x1076212e4*/
    return std::vector<RBX::Security::KeyRing::ApplicationVersionReport>::__destroy_vector::operator()[abi:ne200100](); /*0x1076212e7*/
  }
  return result; /*0x1076212ec*/
}

// Address: 0x1076213aa | Name: __ZN3RBX8Security7KeyRing14stopConfigLoopEv
__int64 __fastcall RBX::Security::KeyRing::stopConfigLoop(__m128i *this)
{
  RBX::SimpleTimer *v2; // r14
  __m128i v3; // xmm0

  v2 = (RBX::SimpleTimer *)(this + 33); /*0x1076213c6*/
  if ( (unsigned __int8)RBX::SimpleTimer::isValid(this: (RBX::SimpleTimer *)(this + 33)) != 0 ) /*0x1076213d7*/
    RBX::SimpleTimer::stop(this: v2); /*0x1076213dc*/
  if ( DFFlag::KeyRingReset != 0 ) /*0x1076213e8*/
  {
    *((_BYTE *)this + 594) = 0; /*0x1076213ea*/
    v3 = _mm_loadu_si128(this + 34); /*0x1076213f8*/
    if ( !_mm_testz_si128(v3, v3) ) /*0x107621405*/
      *(this + 34) = _mm_load_si128((const __m128i *)&xmmword_1097F7C50); /*0x107621416*/
  }
  else
  {
    *((_QWORD *)this + 62) = 0; /*0x10762141c*/
    *((_BYTE *)this + 594) = 0; /*0x107621427*/
  }
  return __stack_chk_guard; /*0x10762143e*/
}

// Address: 0x1076214f8 | Name: __ZN3RBX8Security7KeyRing24setHasOutOfDateKeyConfigEb
void __fastcall RBX::Security::KeyRing::setHasOutOfDateKeyConfig(RBX::Security::KeyRing *this, char a2)
{
  *((_BYTE *)this + 592) = a2; /*0x1076214fc*/
}

// Address: 0x107621506 | Name: __ZN3RBX8Security7KeyRing24getHasOutOfDateKeyConfigEv
char __fastcall RBX::Security::KeyRing::getHasOutOfDateKeyConfig(RBX::Security::KeyRing *this)
{
  return *((_BYTE *)this + 592); /*0x107621510*/
}

// Address: 0x107621512 | Name: __ZN3RBX8Security7KeyRing15setFirstOODCaseEb
void __fastcall RBX::Security::KeyRing::setFirstOODCase(RBX::Security::KeyRing *this, char a2)
{
  *((_BYTE *)this + 593) = a2; /*0x107621516*/
}

// Address: 0x107621520 | Name: __ZN3RBX8Security7KeyRing15getFirstOODCaseEv
char __fastcall RBX::Security::KeyRing::getFirstOODCase(RBX::Security::KeyRing *this)
{
  return *((_BYTE *)this + 593); /*0x10762152a*/
}

// Address: 0x10762152c | Name: __ZN3RBX8Security7KeyRing8setJobIdERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
__int64 __fastcall RBX::Security::KeyRing::setJobId(__int64 a1, __int64 a2)
{
  return std::string::operator=(a1: a1 + 472, a2); /*0x107621537*/
}

// Address: 0x10762153e | Name: __ZNK3RBX8Security7KeyRing8getJobIdEv
__int64 __fastcall RBX::Security::KeyRing::getJobId(RBX::Security::KeyRing *this)
{
  return (__int64)this + 472; /*0x107621549*/
}

// Address: 0x10762154c | Name: __ZN3RBX8Security7KeyRing17registerCounterFnEPFvRKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEibE
void __fastcall RBX::Security::KeyRing::registerCounterFn(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a1 + 496) = a2; /*0x107621550*/
}

// Address: 0x10762155a | Name: __ZN3RBX8Security7KeyRing23registerReportVersionFnEPFvPKS1_NSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS4_6vectorINS1_24ApplicationVersionReportENS8_ISC_EEEESA_NS1_12ReportReasonEE
void __fastcall RBX::Security::KeyRing::registerReportVersionFn(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a1 + 608) = a2; /*0x10762155e*/
}

// Address: 0x1076216ee | Name: __ZN3RBX8Security7KeyRingC2Ev
__int64 __fastcall RBX::Security::KeyRing::KeyRing(RBX::Security::KeyRing *this)
{
  *(_OWORD *)this = 0; /*0x1076216ff*/
  *((double *)this + 2) = RBX::Time::now<(RBX::Time::SampleMethod)0>(a1: this); /*0x107621707*/
  *(_OWORD *)((char *)this + 24) = 0; /*0x10762170f*/
  *(_OWORD *)((char *)this + 40) = 0; /*0x107621713*/
  *((_DWORD *)this + 14) = 1065353216; /*0x107621717*/
  boost::shared_mutex::shared_mutex(this: (RBX::Security::KeyRing *)((char *)this + 64)); /*0x107621725*/
  *(_OWORD *)((char *)this + 504) = 0; /*0x10762173b*/
  *(_OWORD *)((char *)this + 488) = 0; /*0x107621742*/
  *(_OWORD *)((char *)this + 472) = 0; /*0x107621749*/
  *((_QWORD *)this + 65) = 0; /*0x107621750*/
  RBX::SimpleTimer::SimpleTimer(this: (RBX::Security::KeyRing *)((char *)this + 528)); /*0x10762175b*/
  *((_BYTE *)this + 594) = 0; /*0x107621762*/
  *((_OWORD *)this + 34) = 0; /*0x10762176b*/
  *((_OWORD *)this + 35) = 0; /*0x107621772*/
  *((_OWORD *)this + 36) = 0; /*0x107621779*/
  *((_BYTE *)this + 592) = 0; /*0x107621780*/
  *(_OWORD *)((char *)this + 600) = 0; /*0x107621786*/
  *(_OWORD *)((char *)this + 616) = 0; /*0x10762178d*/
  *(_OWORD *)((char *)this + 632) = 0; /*0x107621794*/
  *((_QWORD *)this + 81) = 0; /*0x10762179b*/
  return 0; /*0x1076217a6*/
}

// Address: 0x10762180c | Name: __ZN3RBX8Security7KeyRingC1Ev
__int64 __fastcall RBX::Security::KeyRing::KeyRing(RBX::Security::KeyRing *this)
{
  return RBX::Security::KeyRing::KeyRing(this); /*0x107621810*/
}

// Address: 0x107621816 | Name: __ZN3RBX8Security7KeyRingD2Ev
void __fastcall RBX::Security::KeyRing::~KeyRing(RBX::Security::KeyRing *this)
{
  std::__shared_weak_count *v2; // rdi

  *((_QWORD *)this + 62) = 0; /*0x10762181f*/
  RBX::Security::KeyRing::stopConfigLoop((__m128i *)this); /*0x10762182a*/
  if ( (*((_BYTE *)this + 632) & 1) != 0 ) /*0x107621836*/
    operator delete(a1: *((void **)this + 81)); /*0x10762183f*/
  std::shared_ptr<RBX::Security::IKeyRingDebugLogger>::~shared_ptr[abi:ne200100](a1: (char *)this + 616); /*0x10762184b*/
  if ( (*((_BYTE *)this + 560) & 1) != 0 ) /*0x107621857*/
    operator delete(a1: *((void **)this + 72)); /*0x107621860*/
  std::shared_ptr<RBX::TimerData>::~shared_ptr[abi:ne200100](a1: (char *)this + 528); /*0x10762186c*/
  if ( (*((_BYTE *)this + 504) & 1) != 0 ) /*0x107621878*/
    operator delete(a1: *((void **)this + 65)); /*0x107621881*/
  if ( (*((_BYTE *)this + 472) & 1) != 0 ) /*0x10762188d*/
    operator delete(a1: *((void **)this + 61)); /*0x107621896*/
  boost::shared_mutex::~shared_mutex(this: (RBX::Security::KeyRing *)((char *)this + 64)); /*0x10762189f*/
  std::__hash_table<std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>>>::~__hash_table(a1: (char *)this + 24); /*0x1076218a8*/
  v2 = *((std::__shared_weak_count **)this + 1); /*0x1076218ad*/
  if ( v2 != nullptr ) /*0x1076218b8*/
    std::__shared_weak_count::__release_weak(this: v2); /*0x1076218bc*/
}

// Address: 0x1076218cc | Name: __ZN3RBX8Security7KeyRingD1Ev
void __fastcall RBX::Security::KeyRing::~KeyRing(RBX::Security::KeyRing *this)
{
  RBX::Security::KeyRing::~KeyRing(this); /*0x1076218d1*/
}

// Address: 0x1076218d6 | Name: __ZN3RBX8Security7KeyRing11getInstanceEv
__int64 __fastcall RBX::Security::KeyRing::getInstance(RBX::Security::KeyRing *this)
{
  if ( (_BYTE)`guard variable for'RBX::Security::KeyRing::getInstance(void)::instance == 0 /*0x107621902*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Security::KeyRing::getInstance(void)::instance) != 0 )
  {
    RBX::make_shared<RBX::Security::KeyRing>(a1: &RBX::Security::KeyRing::getInstance(void)::instance); /*0x10762190b*/
    __cxa_atexit( /*0x107621925*/
      lpfunc: std::shared_ptr<RBX::Security::KeyRing>::~shared_ptr[abi:ne200100],
      obj: &RBX::Security::KeyRing::getInstance(void)::instance,
      lpdso_handle: (void *)&_mh_execute_header);
    __cxa_guard_release(a1: &`guard variable for'RBX::Security::KeyRing::getInstance(void)::instance); /*0x107621931*/
  }
  return RBX::Security::KeyRing::getInstance(void)::instance; /*0x1076218f1*/
}

// Address: 0x10762199e | Name: __ZN3RBX8Security7KeyRing14setDebugLoggerENSt3__110shared_ptrINS0_19IKeyRingDebugLoggerEEE
__int64 __fastcall RBX::Security::KeyRing::setDebugLogger(__int64 a1)
{
  return std::shared_ptr<RBX::Security::IKeyRingDebugLogger>::operator=[abi:ne200100](a1: a1 + 616); /*0x1076219a9*/
}

// Address: 0x107621a02 | Name: __ZN3RBX8Security7KeyRing24genAppPubKeyConfigHelperERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEESA_jSA_
RBX *__fastcall RBX::Security::KeyRing::genAppPubKeyConfigHelper(
        RBX *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        int a5,
        __int64 a6)
{
  const char *v7; // rdx
  const char *v8; // rcx
  const char *v9; // r9

  if ( (*(_BYTE *)a3 & 1) != 0 ) /*0x107621a0e*/
    v7 = *(const char **)(a3 + 16); /*0x107621a10*/
  else
    v7 = (const char *)(a3 + 1); /*0x107621a16*/
  if ( (*(_BYTE *)a4 & 1) != 0 ) /*0x107621a1c*/
    v8 = *(const char **)(a4 + 16); /*0x107621a1e*/
  else
    v8 = (const char *)(a4 + 1); /*0x107621a24*/
  if ( (*(_BYTE *)a6 & 1) != 0 ) /*0x107621a2b*/
    v9 = *(const char **)(a6 + 16); /*0x107621a2d*/
  else
    v9 = (const char *)(a6 + 1); /*0x107621a33*/
  RBX::format(
    this,
    a2: "\n"
    "    {\"creationTime\" : \"%s\",\n"
    "     \"applications\" : {\"%s\": { \"versions\":[{\"id\" : %u,\n"
    "                                            \"value\" : \"%s\",\n"
    "                                            \"allowed\" : true\n"
    "                                            }],\n"
    "                                \"send\" : %u,\n"
    "                                \"revert\" : %u}}}",
    v7,
    v8,
    a5,
    v9,
    a5,
    a5);
  return this; /*0x107621a56*/
}

// Address: 0x107621a5a | Name: __ZN3RBX8Security7KeyRing17testOnlyResetKeysEv
int __fastcall RBX::Security::KeyRing::testOnlyResetKeys(RBX::Security::KeyRing *this)
{
  boost::shared_mutex *v2; // r14

  v2 = (RBX::Security::KeyRing *)((char *)this + 64); /*0x107621a64*/
  boost::shared_mutex::lock(this: (RBX::Security::KeyRing *)((char *)this + 64)); /*0x107621a6b*/
  std::__hash_table<std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Security::KeyRing::ApplicationInfo>>>::clear(a1: (char *)this + 24); /*0x107621a77*/
  return boost::shared_mutex::unlock(this: v2); /*0x107621a84*/
}

// Address: 0x1087bda22 | Name: __ZN3RBX8Security7KeyRing11parseConfigERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEb.cold.1
void __fastcall RBX::Security::KeyRing::parseConfig(__int64 a1, __int64 a2)
{
  do /*0x1087bda46*/
  {
    if ( (*(_BYTE *)(a1 - 24) & 1) != 0 ) /*0x1087bda34*/
      operator delete(a1: *(void **)(a1 - 8)); /*0x1087bda3a*/
    a1 -= 24; /*0x1087bda3f*/
  }
  while ( a1 != a2 ); /*0x1087bda46*/
}

// Address: 0x1087bda4d | Name: __ZN3RBX8Security7KeyRing16parseApplicationERKNS_4json5ValueERKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEE.cold.1
void __fastcall RBX::Security::KeyRing::parseApplication(__int64 a1, __int64 a2)
{
  do /*0x1087bda71*/
  {
    if ( (*(_BYTE *)(a1 - 24) & 1) != 0 ) /*0x1087bda5f*/
      operator delete(a1: *(void **)(a1 - 8)); /*0x1087bda65*/
    a1 -= 24; /*0x1087bda6a*/
  }
  while ( a1 != a2 ); /*0x1087bda71*/
}

// Address: 0x1087bda78 | Name: __ZN3RBX8Security7KeyRing16parseApplicationERKNS_4json5ValueERKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEE.cold.2
void __fastcall RBX::Security::KeyRing::parseApplication(__int64 a1, __int64 a2)
{
  do /*0x1087bda9c*/
  {
    if ( (*(_BYTE *)(a1 - 24) & 1) != 0 ) /*0x1087bda8a*/
      operator delete(a1: *(void **)(a1 - 8)); /*0x1087bda90*/
    a1 -= 24; /*0x1087bda95*/
  }
  while ( a1 != a2 ); /*0x1087bda9c*/
}

// Address: 0x1087bdaa3 | Name: __ZN3RBX8Security7KeyRing12parseVersionERKNS_4json5ValueERNSt3__16vectorINS1_7KeyInfoENS6_9allocatorIS8_EEEEjj.cold.1
void __fastcall RBX::Security::KeyRing::parseVersion(__int64 a1, __int64 a2)
{
  do /*0x1087bdac7*/
  {
    if ( (*(_BYTE *)(a1 - 24) & 1) != 0 ) /*0x1087bdab5*/
      operator delete(a1: *(void **)(a1 - 8)); /*0x1087bdabb*/
    a1 -= 24; /*0x1087bdac0*/
  }
  while ( a1 != a2 ); /*0x1087bdac7*/
}

// Address: 0x1087bdace | Name: __ZN3RBX8Security7KeyRing12parseVersionERKNS_4json5ValueERNSt3__16vectorINS1_7KeyInfoENS6_9allocatorIS8_EEEEjj.cold.2
void __fastcall RBX::Security::KeyRing::parseVersion(__int64 a1, __int64 a2)
{
  do /*0x1087bdaf2*/
  {
    if ( (*(_BYTE *)(a1 - 24) & 1) != 0 ) /*0x1087bdae0*/
      operator delete(a1: *(void **)(a1 - 8)); /*0x1087bdae6*/
    a1 -= 24; /*0x1087bdaeb*/
  }
  while ( a1 != a2 ); /*0x1087bdaf2*/
}

// END KeyRing part 1/1, 38 functions
