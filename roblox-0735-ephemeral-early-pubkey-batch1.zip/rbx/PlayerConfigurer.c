// PlayerConfigurer -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 48 functions

// Field names below come from the 2022 PDB, which is the only
// build that has them. Each is marked: bare `this->x` was
// corroborated by a store of matching width in that same
// function; UNVERIFIED means the 2022 layout says so and
// nothing target-era has confirmed it.


// Address: 0x1067b8abe | Name: __ZN3RBX16PlayerConfigurerC2Ev
__int64 __fastcall RBX::PlayerConfigurer::PlayerConfigurer(RBX::PlayerConfigurer *this)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // rdx
  __int64 v5; // rcx
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // rdx
  __int64 v13; // rcx
  __int64 v14; // rdx
  __int64 v15; // rcx
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // rdx
  __int64 v19; // rcx
  __int64 v20; // rdx
  __int64 v21; // rcx
  __int64 result; // rax

  *(_OWORD *)((char *)this + 8 /* +8 = .._Wptr. (std::_Ptr_base<RBX::GameConfigurer>, 16B) -- SIZE CONFLICT, see --verify */) = 0; /*0x1067b8acf*/
  *((_OWORD *)this + 2) = 0; /*0x1067b8ad3*/
  this->.__vftable /* +0 */= off_10CAAC010; /*0x1067b8ade*/
  this->testing /* +48 */ = 1; /*0x1067b8ae3*/
  *(_DWORD *)((char *)this + 49 /* +49 = logAnalytics (bool, 1B) -- SIZE CONFLICT, see --verify */) = 0; /*0x1067b8ae8*/
  *(_WORD *)((char *)this + 53 /* +53 = loadResolved (bool, 1B) -- SIZE CONFLICT, see --verify */) = 0; /*0x1067b8aeb*/
  this->playResolved /* +55 */ = 1; /*0x1067b8aef*/
  *((_WORD *)this + 32) /* +64 likely waitingForCharacter -- UNVERIFIED */ = 0; /*0x1067b8af2*/
  this->userId /* +72 */ = 0; /*0x1067b8af6*/
  this->userJoinDataOverrides._Mypair._Myval2._Bx /* +80 */ = 256; /*0x1067b8afa*/
  *((_BYTE *)this + 82) /* +82: NO 2022 FIELD */ = 0; /*0x1067b8b00*/
  *((_OWORD *)this + 26) = 0; /*0x1067b8b04*/
  *((_QWORD *)this + 54) /* +432: NO 2022 FIELD */ = 0; /*0x1067b8b0b*/
  *(_OWORD *)((char *)this + 168 /* +168: NO 2022 FIELD */) = 0; /*0x1067b8b12*/
  *(_OWORD *)((char *)this + 184 /* +184: NO 2022 FIELD */) = 0; /*0x1067b8b19*/
  *(_OWORD *)((char *)this + 200 /* +200: NO 2022 FIELD */) = 0; /*0x1067b8b20*/
  *(_OWORD *)((char *)this + 216 /* +216: NO 2022 FIELD */) = 0; /*0x1067b8b27*/
  *(_OWORD *)((char *)this + 232 /* +232: NO 2022 FIELD */) = 0; /*0x1067b8b2e*/
  *(_OWORD *)((char *)this + 248 /* +248: NO 2022 FIELD */) = 0; /*0x1067b8b35*/
  *(_OWORD *)((char *)this + 264 /* +264: NO 2022 FIELD */) = 0; /*0x1067b8b3c*/
  *(_OWORD *)((char *)this + 280 /* +280: NO 2022 FIELD */) = 0; /*0x1067b8b43*/
  *(_OWORD *)((char *)this + 296 /* +296: NO 2022 FIELD */) = 0; /*0x1067b8b4a*/
  *(_OWORD *)((char *)this + 312 /* +312: NO 2022 FIELD */) = 0; /*0x1067b8b51*/
  *(_OWORD *)((char *)this + 328 /* +328: NO 2022 FIELD */) = 0; /*0x1067b8b58*/
  *(_OWORD *)((char *)this + 344 /* +344: NO 2022 FIELD */) = 0; /*0x1067b8b5f*/
  *(_OWORD *)((char *)this + 360 /* +360: NO 2022 FIELD */) = 0; /*0x1067b8b66*/
  *((_DWORD *)this + 94) /* +376: NO 2022 FIELD */ = 0; /*0x1067b8b6d*/
  *(_OWORD *)((char *)this + 394 /* +394: NO 2022 FIELD */) = 0; /*0x1067b8b73*/
  *((_OWORD *)this + 24) = 0; /*0x1067b8b7a*/
  *(_OWORD *)((char *)this + 148 /* +148: NO 2022 FIELD */) = 0; /*0x1067b8b81*/
  *(_OWORD *)((char *)this + 136 /* +136: NO 2022 FIELD */) = 0; /*0x1067b8b88*/
  *(_OWORD *)((char *)this + 120 /* +120: NO 2022 FIELD */) = 0; /*0x1067b8b8f*/
  *(_OWORD *)((char *)this + 104 /* +104 = userJoinDataOverrides._Mypair._Myval2._Myres (unsigned __int64, 8B) -- SIZE CONFLICT, see --verify */) = 0; /*0x1067b8b93*/
  *(_OWORD *)((char *)this + 88 /* +88: NO 2022 FIELD */) = 0; /*0x1067b8b97*/
  *((_DWORD *)this + 110) /* +440: NO 2022 FIELD */ = 1; /*0x1067b8b9b*/
  *((_QWORD *)this + 58) /* +464: NO 2022 FIELD */ = 0; /*0x1067b8bac*/
  *((_OWORD *)this + 28) = 0; /*0x1067b8bb3*/
  RBX::AvatarLoadMetrics::AvatarLoadMetrics(this: (RBX::PlayerConfigurer *)((char *)this + 480 /* +480: NO 2022 FIELD */)); /*0x1067b8bbd*/
  this->avatarTextureStartConnection.con.weak_slot.p_ /* +896 */ = 0; /*0x1067b8bc2*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 912 /* +912 = clientJoinFailureConnection.con.weak_slot.p_ (rbx::signals::slot_base *, 8B) -- SIZE CONFLICT, see --verify */, a2: "", a3: v2, a4: v3); /*0x1067b8bdb*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 936 /* +936: NO 2022 FIELD */, a2: "NotStarted", a3: v4, a4: v5); /*0x1067b8bf4*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 960 /* +960: NO 2022 FIELD */, a2: "PlaceLaunched", a3: v6, a4: v7); /*0x1067b8c0d*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 984 /* +984: NO 2022 FIELD */, a2: "FetchedJoinScript", a3: v8, a4: v9); /*0x1067b8c26*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 1008 /* +1008: NO 2022 FIELD */, a2: "PlayerConfigured", a3: v10, a4: v11); /*0x1067b8c3f*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 1032 /* +1032: NO 2022 FIELD */, a2: "Connected", a3: v12, a4: v13); /*0x1067b8c58*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 1056 /* +1056: NO 2022 FIELD */, a2: "ReceivedGlobals", a3: v14, a4: v15); /*0x1067b8c71*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 1080 /* +1080: NO 2022 FIELD */, a2: "GameLoaded", a3: v16, a4: v17); /*0x1067b8c8a*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 1104 /* +1104: NO 2022 FIELD */, a2: "GameJoined", a3: v18, a4: v19); /*0x1067b8ca3*/
  std::string::basic_string[abi:ne200100]<0>(a1: (char *)this + 1128 /* +1128: NO 2022 FIELD */, a2: "AvatarLoaded", a3: v20, a4: v21); /*0x1067b8cbc*/
  RBX::Analytics::InfluxDb::Points::Points(a1: (char *)this + 1152 /* +1152: NO 2022 FIELD */, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1067b8cd4*/
  *(_OWORD *)((char *)this + 1624 /* +1624: NO 2022 FIELD */) = 0; /*0x1067b8cdc*/
  *((_QWORD *)this + 205) /* +1640: NO 2022 FIELD */ = RBX::Subsystem<RBX::Analytics::TelemetryInformation,false>::startup<RBX::SubsystemDefaultFactory<RBX::Analytics::TelemetryInformation>>(); /*0x1067b8ce8*/
  result = RBX::Subsystem<RBX::InferredCrash,false>::startup<RBX::SubsystemDefaultFactory<RBX::InferredCrash>>(); /*0x1067b8cef*/
  *((_QWORD *)this + 206) /* +1648: NO 2022 FIELD */ = result; /*0x1067b8cf4*/
  *(_OWORD *)((char *)this + 1656 /* +1656: NO 2022 FIELD */) = 0; /*0x1067b8cfe*/
  *(_OWORD *)((char *)this + 1672 /* +1672: NO 2022 FIELD */) = 0; /*0x1067b8d05*/
  *(_OWORD *)((char *)this + 1688 /* +1688: NO 2022 FIELD */) = 0; /*0x1067b8d0c*/
  *(_OWORD *)((char *)this + 1704 /* +1704: NO 2022 FIELD */) = 0; /*0x1067b8d13*/
  *(_OWORD *)((char *)this + 1720 /* +1720: NO 2022 FIELD */) = 0; /*0x1067b8d1a*/
  *(_OWORD *)((char *)this + 1736 /* +1736: NO 2022 FIELD */) = 0; /*0x1067b8d21*/
  *(_OWORD *)((char *)this + 1752 /* +1752: NO 2022 FIELD */) = 0; /*0x1067b8d28*/
  *(_OWORD *)((char *)this + 1768 /* +1768: NO 2022 FIELD */) = 0; /*0x1067b8d2f*/
  *(_OWORD *)((char *)this + 1784 /* +1784: NO 2022 FIELD */) = 0; /*0x1067b8d36*/
  return result; /*0x1067b8d3d*/
}

// Address: 0x1067b8edc | Name: __ZN3RBX16PlayerConfigurerC1Ev
__int64 __fastcall RBX::PlayerConfigurer::PlayerConfigurer(RBX::PlayerConfigurer *this)
{
  return RBX::PlayerConfigurer::PlayerConfigurer(this); /*0x1067b8ee0*/
}

// Address: 0x1067b8ee6 | Name: __ZN3RBX16PlayerConfigurerD2Ev
void __fastcall RBX::PlayerConfigurer::~PlayerConfigurer(
        RBX::PlayerConfigurer *this,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  rbx::signals::connection *v5; // r15
  rbx::signals::connection *v6; // r12
  volatile signed __int32 *v7; // rdi
  __int64 v8; // rdi
  __int64 v9; // rdi
  __int64 i; // r14
  void *v11[7]; // [rsp+8h] [rbp-38h] BYREF

  this->.__vftable /* +0 */= off_10CAAC010; /*0x1067b8eff*/
  std::string::basic_string[abi:ne200100]<0>(a1: v11, a2: "ClientJoinFail", a3, a4); /*0x1067b8f0d*/
  RBX::Analytics::InfluxDb::Points::report( /*0x1067b8f28*/
    a1: (char *)this + 1152 /* +1152: NO 2022 FIELD */,
    a2: v11,
    a3: (unsigned int)DFInt::JoinInfluxHundredthsPercentage,
    a4: 0);
  if ( ((__int64)v11[0] & 1) != 0 ) /*0x1067b8f31*/
    operator delete(a1: v11[2]); /*0x1067b8f37*/
  v5 = *((rbx::signals::connection **)this + 219); /*0x1067b8f3c*/
  v6 = *((rbx::signals::connection **)this + 220); /*0x1067b8f43*/
  while ( v5 != v6 ) /*0x1067b8f4d*/
  {
    rbx::signals::connection::disconnect(this: v5); /*0x1067b8f52*/
    v5 = (rbx::signals::connection *)((char *)v5 + 8); /*0x1067b8f57*/
  }
  rbx::signals::connection::disconnect(this: (RBX::PlayerConfigurer *)((char *)this + 1776 /* +1776: NO 2022 FIELD */)); /*0x1067b8f64*/
  std::shared_ptr<RBX::DataModelSnapshotJob>::~shared_ptr[abi:ne200100](a1: (char *)this + 1784 /* +1784: NO 2022 FIELD */); /*0x1067b8f77*/
  v7 = *((volatile signed __int32 **)this + 222); /*0x1067b8f7c*/
  if ( v7 != nullptr && _InterlockedDecrement(v7 + 1) == 0 ) /*0x1067b8f8c*/
    rbx::signals::slot_base::operator delete(a1: (void *)v7); /*0x1067b8f8e*/
  v11[0] = (char *)this + 1752 /* +1752: NO 2022 FIELD */; /*0x1067b8f97*/
  std::vector<rbx::signals::connection>::__destroy_vector::operator()[abi:ne200100](); /*0x1067b8f9a*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1744 /* +1744: NO 2022 FIELD */)); /*0x1067b8fa6*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1736 /* +1736: NO 2022 FIELD */)); /*0x1067b8fb2*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1728 /* +1728: NO 2022 FIELD */)); /*0x1067b8fbe*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1720 /* +1720: NO 2022 FIELD */)); /*0x1067b8fca*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1712 /* +1712: NO 2022 FIELD */)); /*0x1067b8fd6*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1704 /* +1704: NO 2022 FIELD */)); /*0x1067b8fe2*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1696 /* +1696: NO 2022 FIELD */)); /*0x1067b8fee*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1688 /* +1688: NO 2022 FIELD */)); /*0x1067b8ffa*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1680 /* +1680: NO 2022 FIELD */)); /*0x1067b9006*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1672 /* +1672: NO 2022 FIELD */)); /*0x1067b9012*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1664 /* +1664: NO 2022 FIELD */)); /*0x1067b901e*/
  rbx::signals::scoped_connection::~scoped_connection(this: (RBX::PlayerConfigurer *)((char *)this + 1656 /* +1656: NO 2022 FIELD */)); /*0x1067b902a*/
  v8 = *((_QWORD *)this + 206) /* +1648: NO 2022 FIELD */; /*0x1067b902f*/
  if ( v8 != 0 ) /*0x1067b9039*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x1067b903e*/
  v9 = *((_QWORD *)this + 205) /* +1640: NO 2022 FIELD */; /*0x1067b9041*/
  if ( v9 != 0 ) /*0x1067b904b*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x1067b9050*/
  std::shared_ptr<RBX::GamePerfMonitor>::~shared_ptr[abi:ne200100](a1: (char *)this + 1624 /* +1624: NO 2022 FIELD */); /*0x1067b905a*/
  RBX::Analytics::InfluxDb::Points::~Points(this: (void **)this + 144); /*0x1067b9062*/
  for ( i = 1144; i != 904; i -= 24 ) /*0x1067b9067*/
  {
    if ( (this->.__vftable /* +0 */+ i - 16) & 1) != 0 ) /*0x1067b9073*/
      operator delete(a1: *(void **)((char *)this + i)); /*0x1067b9079*/
  }
  std::unique_ptr<RBX::AvatarLoadMetrics>::reset[abi:ne200100](a1: (char *)this + 896 /* +896 = avatarTextureStartConnection.con.weak_slot.p_ (rbx::signals::slot_base *, 8B) -- SIZE CONFLICT, see --verify */, a2: 0); /*0x1067b9094*/
  RBX::AvatarLoadMetrics::~AvatarLoadMetrics(this: (RBX::PlayerConfigurer *)((char *)this + 480 /* +480: NO 2022 FIELD */)); /*0x1067b90a0*/
  std::shared_ptr<RBX::Reflection::ValueTable const>::~shared_ptr[abi:ne200100](a1: (__int64)this + 456); /*0x1067b90ac*/
  if ( (*((_BYTE *)this + 416) /* +416 likely joinPhaseStrings -- UNVERIFIED */ & 1) != 0 ) /*0x1067b90b8*/
    operator delete(a1: *((void **)this + 54)); /*0x1067b90c1*/
  if ( (*((_BYTE *)this + 352) /* +352: NO 2022 FIELD */ & 1) != 0 ) /*0x1067b90cd*/
    operator delete(a1: *((void **)this + 46)); /*0x1067b90d6*/
  if ( (*((_BYTE *)this + 328) /* +328: NO 2022 FIELD */ & 1) != 0 ) /*0x1067b90e2*/
    operator delete(a1: *((void **)this + 43)); /*0x1067b90eb*/
  if ( (*((_BYTE *)this + 304) /* +304: NO 2022 FIELD */ & 1) != 0 ) /*0x1067b90f7*/
    operator delete(a1: *((void **)this + 40)); /*0x1067b9100*/
  if ( (*((_BYTE *)this + 136) /* +136: NO 2022 FIELD */ & 1) != 0 ) /*0x1067b910c*/
    operator delete(a1: *((void **)this + 19)); /*0x1067b9115*/
  if ( (*((_BYTE *)this + 112) /* +112 likely sgs -- UNVERIFIED */ & 1) != 0 ) /*0x1067b911e*/
    operator delete(a1: *((void **)this + 16)); /*0x1067b9127*/
  if ( (*((_BYTE *)this + 88) /* +88: NO 2022 FIELD */ & 1) != 0 ) /*0x1067b9130*/
    operator delete(a1: *((void **)this + 13)); /*0x1067b9136*/
  RBX::GameConfigurer::~GameConfigurer(this); /*0x1067b913e*/
}

// Address: 0x1067b915e | Name: __ZN3RBX16PlayerConfigurerD1Ev
void __fastcall RBX::PlayerConfigurer::~PlayerConfigurer(
        RBX::PlayerConfigurer *this,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  RBX::PlayerConfigurer::~PlayerConfigurer(this, a2, a3, a4); /*0x1067b9163*/
}

// Address: 0x1067b9168 | Name: __ZN3RBX16PlayerConfigurerD0Ev
void __fastcall RBX::PlayerConfigurer::~PlayerConfigurer(
        RBX::PlayerConfigurer *this,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  RBX::PlayerConfigurer::~PlayerConfigurer(this, a2, a3, a4); /*0x1067b9171*/
  operator delete(a1: this); /*0x1067b917f*/
}

// Address: 0x1067b9184 | Name: __ZN3RBX16PlayerConfigurer24setUserJoinDataOverridesERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall RBX::PlayerConfigurer::setUserJoinDataOverrides(__int64 a1, __int64 a2)
{
  return std::string::operator=(a1: a1 + 88, a2); /*0x1067b918c*/
}

// Address: 0x1067b9192 | Name: __ZN3RBX16PlayerConfigurer22setUserGameJoinContextERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall RBX::PlayerConfigurer::setUserGameJoinContext(__int64 a1, __int64 a2)
{
  return std::string::operator=(a1: a1 + 112, a2); /*0x1067b919a*/
}

// Address: 0x1067b91a0 | Name: __ZN3RBX16PlayerConfigurer19setPreloadedVersionEi
void __fastcall RBX::PlayerConfigurer::setPreloadedVersion(RBX::PlayerConfigurer *this, int a2)
{
  *((_DWORD *)this + 40) /* +160: NO 2022 FIELD */ = a2; /*0x1067b91a4*/
}

// Address: 0x1067b91ac | Name: __ZN3RBX16PlayerConfigurer23ifSeleniumThenSetCookieERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_
void __fastcall RBX::PlayerConfigurer::ifSeleniumThenSetCookie(__int64 a1, __int128 *a2, __int128 *a3, __int64 a4)
{
  char ParamBool; // r12
  __int64 v8; // rax
  __int64 v9; // r15
  _BYTE v10[16]; // [rsp+8h] [rbp-78h] BYREF
  void *v11; // [rsp+18h] [rbp-68h]
  __int128 v12; // [rsp+20h] [rbp-60h] BYREF
  void *v13; // [rsp+30h] [rbp-50h]
  __int128 v14; // [rsp+40h] [rbp-40h] BYREF
  void *v15; // [rsp+50h] [rbp-30h]

  std::string::basic_string[abi:ne200100]<0>(a1: v10, a2: "SeleniumTestMode", a3, a4); /*0x1067b91d2*/
  ParamBool = RBX::GameConfigurer::getParamBool(a1, a2: v10); /*0x1067b91e2*/
  if ( (v10[0] & 1) != 0 ) /*0x1067b91e9*/
    operator delete(a1: v11); /*0x1067b91ef*/
  if ( ParamBool != 0 ) /*0x1067b91f7*/
  {
    v8 = RBX::ServiceProvider::create<RBX::CookiesService>(this: (RBX::ServiceProvider *)(*(_QWORD *)(a1 + 24) + 464LL)); /*0x1067b9208*/
    if ( v8 != 0 ) /*0x1067b9210*/
    {
      v9 = v8; /*0x1067b9216*/
      if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1067b921d*/
      {
        std::string::__init_copy_ctor_external(a1: &v12, a2: *((_QWORD *)a2 + 2), a3: *((_QWORD *)a2 + 1)); /*0x1067b923d*/
      }
      else
      {
        v13 = *((void **)a2 + 2); /*0x1067b9223*/
        v12 = *a2; /*0x1067b922b*/
      }
      if ( (*(_BYTE *)a3 & 1) != 0 ) /*0x1067b9245*/
      {
        std::string::__init_copy_ctor_external(a1: &v14, a2: *((_QWORD *)a3 + 2), a3: *((_QWORD *)a3 + 1)); /*0x1067b9264*/
      }
      else
      {
        v15 = *((void **)a3 + 2); /*0x1067b924b*/
        v14 = *a3; /*0x1067b9252*/
      }
      RBX::CookiesService::SetValue(a1: v9, a2: &v12, a3: &v14); /*0x1067b9274*/
      if ( (v14 & 1) != 0 ) /*0x1067b927d*/
        operator delete(a1: v15); /*0x1067b9283*/
      if ( (v12 & 1) != 0 ) /*0x1067b928c*/
        operator delete(a1: v13); /*0x1067b9292*/
    }
  }
}

// Address: 0x1067b92e2 | Name: __ZN3RBX16PlayerConfigurer15showErrorWindowERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_S9_i
void __fastcall RBX::PlayerConfigurer::showErrorWindow(__int64 a1, __int128 *a2, char *a3, __int64 a4, __int64 a5)
{
  char *v6; // r14
  __int64 v8; // r13
  volatile signed __int64 *v9; // r14
  __int64 v10; // rbx
  RBX::ClientSessionTracker::ClientSessionTrackerContext *v11; // rdi
  __int64 Instance; // rax
  std::__shared_weak_count *v13; // rbx
  int v14; // ecx
  __int64 v15; // rax
  __int64 v16; // rbx
  RBX::SessionTransitionFSM *v17; // rdi
  double v18; // xmm0_8
  __int64 v19; // rdx
  __int64 v20; // rcx
  __int64 v21; // rdx
  __int64 v22; // rcx
  double v23; // xmm0_8
  __int64 v24; // rdx
  __int64 v25; // rcx
  char v26; // r15
  const char *v27; // rbx
  __int64 ParamInt64; // rax
  const char *v29; // r14
  bool v30; // r9
  const char *v31; // rdx
  __int64 v32; // rdx
  __int64 v33; // rcx
  char v34; // r15
  const char *v35; // r13
  const char *v36; // rcx
  bool v37; // r9
  const char *v38; // rdx
  __int64 v39; // rdx
  __int64 v40; // rcx
  char v41; // r15
  const char *v42; // rbx
  int ParamInt; // eax
  bool v44; // r9
  const char *v45; // rdx
  bool v46; // r9
  __int64 v47; // rax
  __int128 *v48; // rcx
  __int64 v49; // r12
  _DWORD *v50; // r14
  bool v51; // zf
  std::__shared_weak_count *v52; // rbx
  _BYTE v53[16]; // [rsp+8h] [rbp-B8h] BYREF
  void *v54; // [rsp+18h] [rbp-A8h]
  __int64 v55; // [rsp+20h] [rbp-A0h]
  std::__shared_weak_count *v56; // [rsp+28h] [rbp-98h]
  __int128 v57; // [rsp+30h] [rbp-90h] BYREF
  void *v58; // [rsp+40h] [rbp-80h]
  __int128 *v59; // [rsp+48h] [rbp-78h]
  int v60[2]; // [rsp+50h] [rbp-70h]
  double v61; // [rsp+58h] [rbp-68h]
  char v62; // [rsp+60h] [rbp-60h] BYREF
  char v63; // [rsp+61h] [rbp-5Fh] BYREF
  void *v64; // [rsp+70h] [rbp-50h]
  char *v65; // [rsp+78h] [rbp-48h]
  char v66[8]; // [rsp+80h] [rbp-40h] BYREF
  std::__shared_weak_count *v67; // [rsp+88h] [rbp-38h]
  void *v68; // [rsp+90h] [rbp-30h]

  *(_QWORD *)v60 = a5; /*0x1067b92f6*/
  v6 = a3; /*0x1067b92fd*/
  v59 = a2; /*0x1067b9300*/
  v51 = *(_BYTE *)(a1 + 80) == 0; /*0x1067b9307*/
  v65 = a3; /*0x1067b930b*/
  if ( v51 )
  {
    v8 = RBX::ClientSessionTrackerKeys::LastGameErrorTime; /*0x1067b931c*/
    v9 = (volatile signed __int64 *)unk_10D5120C0; /*0x1067b931f*/
    v55 = RBX::ClientSessionTrackerKeys::LastGameErrorTime; /*0x1067b9323*/
    v56 = (std::__shared_weak_count *)unk_10D5120C0; /*0x1067b932a*/
    if ( unk_10D5120C0 != 0 ) /*0x1067b9334*/
      _InterlockedIncrement64((volatile signed __int64 *)(unk_10D5120C0 + 8LL)); /*0x1067b9336*/
    v10 = RBX::Time::epochTime(this: (RBX::Time *)a1); /*0x1067b9340*/
    Instance = RBX::ClientSessionTracker::ClientSessionTrackerContext::getInstance(this: v11); /*0x1067b9343*/
    *(_QWORD *)v66 = v8; /*0x1067b9348*/
    v67 = (std::__shared_weak_count *)v9; /*0x1067b934c*/
    if ( v9 != nullptr ) /*0x1067b9353*/
      _InterlockedIncrement64(v9 + 1); /*0x1067b9355*/
    RBX::ClientSessionTracker::ClientSessionTrackerContext::updateClientSessionMetric<long long,false>( /*0x1067b9366*/
      a1: Instance,
      a2: v66,
      a3: v10,
      a4: 0);
    v13 = v67; /*0x1067b936b*/
    v6 = v65; /*0x1067b9372*/
    if ( v67 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v67 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067b9388*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(a1: v13); /*0x1067b9390*/
      std::__shared_weak_count::__release_weak(this: v13); /*0x1067b9396*/
    }
    if ( v56 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v56 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067b93b7*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v56 + 16LL))(a1: v56); /*0x1067b93bf*/
      std::__shared_weak_count::__release_weak(this: v56); /*0x1067b93c5*/
    }
    if ( (unsigned int)(v60[0] - 267) > 0x19 || (v14 = 33816577, !_bittest(&v14, v60[0] - 267)) )
    {
      if ( v60[0] != 0 )
      {
        v15 = RBX::Subsystem<RBX::SessionTransitionFSM,false>::startup<RBX::SubsystemDefaultFactory<RBX::SessionTransitionFSM>>(); /*0x1067b93e8*/
        v16 = v15; /*0x1067b93ed*/
        v17 = v15 != 0 ? *(RBX::SessionTransitionFSM **)(v15 + 24) : nullptr;
        RBX::SessionTransitionFSM::sessionEndsWithError(this: v17, a2: v60[0]); /*0x1067b9401*/
        if ( v16 != 0 ) /*0x1067b9409*/
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x1067b9411*/
      }
    }
  }
  if ( *(_BYTE *)(a1 + 53) == 1 && *(_BYTE *)(a1 + 54) != 0 ) /*0x1067b9426*/
  {
    if ( *(_BYTE *)(a1 + 55) != 0 ) /*0x1067b9432*/
      goto LABEL_69; /*0x1067b9432*/
    RBX::Time::nowFastSec(this: (RBX::Time *)a1); /*0x1067b9438*/
    v61 = v18 - *(double *)(a1 + 168) - *(double *)(a1 + 240); /*0x1067b9451*/
    std::string::basic_string[abi:ne200100]<0>(a1: v66, a2: "GameDuration", a3: v19, a4: v20); /*0x1067b9464*/
    RBX::PlayerConfigurer::reportDuration(a1, a2: v66, a3: a4, a4: v61); /*0x1067b9477*/
    if ( (v66[0] & 1) != 0 ) /*0x1067b9480*/
      operator delete(a1: v68); /*0x1067b9486*/
    *(_BYTE *)(a1 + 55) = 1; /*0x1067b948b*/
    std::operator+<char>(a1: v66, a2: "GameDisconnect-", v6); /*0x1067b949f*/
    RBX::Analytics::EphemeralCounter::reportCounter(a1: v66, a2: 1, a3: 0); /*0x1067b94af*/
  }
  else
  {
    RBX::Time::nowFastSec(this: (RBX::Time *)a1); /*0x1067b94b9*/
    v61 = v23 - *(double *)(a1 + 256); /*0x1067b94c8*/
    if ( *(_BYTE *)(a1 + 53) == 0 ) /*0x1067b94d3*/
    {
      *(_BYTE *)(a1 + 53) = 1; /*0x1067b94d5*/
      std::string::basic_string[abi:ne200100]<0>(a1: v66, a2: "GameLoad", a3: v21, a4: v22); /*0x1067b94e6*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v62, a2: "Failure", a3: v24, a4: v25); /*0x1067b94f6*/
      RBX::PlayerConfigurer::reportDuration(a1, a2: v66, a3: &v62, a4: v61); /*0x1067b950b*/
      if ( (v62 & 1) != 0 ) /*0x1067b9514*/
        operator delete(a1: v64); /*0x1067b951a*/
      if ( (v66[0] & 1) != 0 ) /*0x1067b9523*/
        operator delete(a1: v68); /*0x1067b9529*/
    }
    if ( *(_BYTE *)(a1 + 54) == 0 ) /*0x1067b9534*/
    {
      *(_BYTE *)(a1 + 54) = 1; /*0x1067b9536*/
      std::string::basic_string[abi:ne200100]<0>(a1: v66, a2: "GameJoin", a3: v21, a4: v22); /*0x1067b954a*/
      RBX::PlayerConfigurer::reportDuration(a1, a2: v66, a3: a4, a4: v61); /*0x1067b955d*/
      if ( (v66[0] & 1) != 0 ) /*0x1067b9566*/
        operator delete(a1: v68); /*0x1067b956c*/
    }
    v26 = *v6; /*0x1067b9571*/
    v27 = *((const char **)v6 + 2); /*0x1067b9574*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v62, a2: "PlaceId", a3: v21, a4: v22); /*0x1067b9586*/
    ParamInt64 = RBX::GameConfigurer::getParamInt64(a1, a2: &v62); /*0x1067b9591*/
    v29 = v6 + 1; /*0x1067b9596*/
    if ( (v26 & 1) == 0 ) /*0x1067b959d*/
      v27 = v29; /*0x1067b959d*/
    RBX::format(this: (RBX *)v66, a2: "%s_%lld", v27, ParamInt64); /*0x1067b95b4*/
    if ( (v66[0] & 1) != 0 ) /*0x1067b95bd*/
      v31 = (const char *)v68; /*0x1067b95bf*/
    else
      v31 = &v66[1]; /*0x1067b95c5*/
    RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1067b95dc*/
      this: (RBX::Analytics::Event *)"Game",
      a2: "JoinFailurePlace",
      a3: v31,
      a4: nullptr,
      a5: 0,
      a6: v30);
    if ( (v66[0] & 1) != 0 ) /*0x1067b95e5*/
      operator delete(a1: v68); /*0x1067b95eb*/
    if ( (v62 & 1) != 0 ) /*0x1067b95f4*/
      operator delete(a1: v64); /*0x1067b95fa*/
    v34 = *v65; /*0x1067b9603*/
    v35 = *((const char **)v65 + 2); /*0x1067b9606*/
    std::string::basic_string[abi:ne200100]<0>(a1: v53, a2: "MachineAddress", a3: v32, a4: v33); /*0x1067b961b*/
    RBX::GameConfigurer::getParamString(a1: &v62, a2: a1, a3: v53); /*0x1067b962a*/
    if ( (v34 & 1) == 0 ) /*0x1067b9633*/
      v35 = v29; /*0x1067b9633*/
    if ( (v62 & 1) != 0 ) /*0x1067b963b*/
      v36 = (const char *)v64; /*0x1067b963d*/
    else
      v36 = &v63; /*0x1067b9643*/
    RBX::format(this: (RBX *)v66, a2: "%s_%s", v35, v36); /*0x1067b9657*/
    if ( (v66[0] & 1) != 0 ) /*0x1067b9660*/
      v38 = (const char *)v68; /*0x1067b9662*/
    else
      v38 = &v66[1]; /*0x1067b9668*/
    RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1067b967f*/
      this: (RBX::Analytics::Event *)"Game",
      a2: "JoinFailureIP",
      a3: v38,
      a4: nullptr,
      a5: 0,
      a6: v37);
    if ( (v66[0] & 1) != 0 ) /*0x1067b9688*/
      operator delete(a1: v68); /*0x1067b968e*/
    if ( (v62 & 1) != 0 ) /*0x1067b9697*/
      operator delete(a1: v64); /*0x1067b969d*/
    if ( (v53[0] & 1) != 0 ) /*0x1067b96a9*/
      operator delete(a1: v54); /*0x1067b96b2*/
    v41 = *v65; /*0x1067b96bb*/
    v42 = *((const char **)v65 + 2); /*0x1067b96be*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v62, a2: "DataCenterId", a3: v39, a4: v40); /*0x1067b96d0*/
    ParamInt = RBX::GameConfigurer::getParamInt(a1, a2: &v62); /*0x1067b96db*/
    if ( (v41 & 1) == 0 ) /*0x1067b96e4*/
      v42 = v29; /*0x1067b96e4*/
    RBX::format(this: (RBX *)v66, a2: "%s_%d", v42, ParamInt); /*0x1067b96fa*/
    if ( (v66[0] & 1) != 0 ) /*0x1067b9703*/
      v45 = (const char *)v68; /*0x1067b9705*/
    else
      v45 = &v66[1]; /*0x1067b970b*/
    v6 = v65; /*0x1067b970f*/
    RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1067b9726*/
      this: (RBX::Analytics::Event *)"Game",
      a2: "JoinFailureDataCenter",
      a3: v45,
      a4: nullptr,
      a5: 0,
      a6: v44);
    if ( (v66[0] & 1) != 0 ) /*0x1067b972f*/
      operator delete(a1: v68); /*0x1067b9735*/
    if ( (v62 & 1) != 0 ) /*0x1067b973e*/
      operator delete(a1: v64); /*0x1067b9744*/
    RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1067b9763*/
      this: (RBX::Analytics::Event *)"Game",
      a2: "GameJoin",
      a3: "Failure",
      a4: nullptr,
      a5: 0,
      a6: v46);
    std::operator+<char>(a1: v66, a2: "JoinFailure-", v6); /*0x1067b9776*/
    RBX::Analytics::EphemeralCounter::reportCounter(a1: v66, a2: 1, a3: 0); /*0x1067b9786*/
  }
  if ( (v66[0] & 1) != 0 ) /*0x1067b978f*/
    operator delete(a1: v68); /*0x1067b9795*/
LABEL_69:
  v47 = RBX::ServiceProvider::create<RBX::GuiService>(a1: *(_QWORD *)(a1 + 24) + 464LL, a2: 0); /*0x1067b979a*/
  v48 = v59; /*0x1067b97ae*/
  if ( v47 == 0 ) /*0x1067b97b2*/
    return; /*0x1067b97b2*/
  v49 = v47; /*0x1067b97b8*/
  if ( (*v6 & 1) != 0 ) /*0x1067b97c0*/
  {
    if ( *((_QWORD *)v6 + 1) == 4 ) /*0x1067b97d0*/
    {
      v50 = *((_DWORD **)v6 + 2); /*0x1067b97d2*/
      goto LABEL_75; /*0x1067b97d2*/
    }
LABEL_76:
    if ( (*(_BYTE *)v48 & 1) != 0 ) /*0x1067b97e2*/
    {
      std::string::__init_copy_ctor_external(a1: &v57, a2: *((_QWORD *)v48 + 2), a3: *((_QWORD *)v48 + 1)); /*0x1067b9809*/
    }
    else
    {
      v58 = *((void **)v48 + 2); /*0x1067b97e8*/
      v57 = *v48; /*0x1067b97f0*/
    }
    RBX::GuiService::setErrorMessage(a1: v49, a2: &v57, a3: *(_QWORD *)v60); /*0x1067b981c*/
    if ( (v57 & 1) != 0 ) /*0x1067b9828*/
      operator delete(a1: v58); /*0x1067b982e*/
    return; /*0x1067b9833*/
  }
  if ( *v6 != 8 ) /*0x1067b97c4*/
    goto LABEL_76; /*0x1067b97c4*/
  v50 = v6 + 1; /*0x1067b97c6*/
LABEL_75:
  if ( *v50 != 1801677131 ) /*0x1067b97dd*/
    goto LABEL_76; /*0x1067b97dd*/
  RBX::GuiService::getErrorMessage(this: (RBX::GuiService *)v66); /*0x1067b983f*/
  if ( (v66[0] & 1) != 0 ) /*0x1067b9848*/
  {
    v52 = v67; /*0x1067b984e*/
    operator delete(a1: v68); /*0x1067b9856*/
    v51 = v52 == nullptr; /*0x1067b985b*/
  }
  else
  {
    v51 = v66[0] == 0; /*0x1067b984a*/
  }
  v48 = v59; /*0x1067b985e*/
  if ( v51 ) /*0x1067b9862*/
    goto LABEL_76; /*0x1067b9862*/
}

// Address: 0x1067b9a40 | Name: __ZN3RBX16PlayerConfigurer14reportDurationERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_d
__int64 __fastcall RBX::PlayerConfigurer::reportDuration(
        __int64 a1,
        unsigned __int8 *a2,
        unsigned __int8 *a3,
        double a4)
{
  __int64 v6; // rax
  __int64 v7; // rax
  _QWORD **v8; // rcx
  _QWORD *v9; // r12
  __int64 v10; // rbx
  __int64 v11; // rax
  __int64 v12; // rdx
  __int64 v13; // rcx
  unsigned int v14; // r12d
  size_t v15; // r12
  char *v16; // r13
  const void *v17; // rsi
  unsigned int v18; // edx
  _DWORD *v19; // rbx
  unsigned __int8 *v20; // rsi
  __int64 v21; // rdx
  __int64 v22; // rax
  __int64 v23; // rax
  float v24; // xmm0_4
  unsigned int v25; // r12d
  size_t v26; // r12
  char *v27; // r13
  const void *v28; // rsi
  unsigned int v29; // edx
  unsigned __int8 *v30; // rsi
  __int64 v31; // rdx
  __int64 v32; // rax
  __int64 v33; // rax
  float v34; // xmm0_4
  __int64 v35; // rdx
  __int64 v36; // rcx
  const char *v37; // rdx
  const char *v38; // rdx
  __int64 v39; // rdx
  __int64 v40; // rcx
  int ParamInt; // eax
  unsigned __int8 v42; // al
  unsigned __int8 *v43; // rcx
  _QWORD *v44; // rcx
  _DWORD *v45; // rdx
  size_t v47; // r15
  char *v48; // r12
  const void *v49; // rsi
  char *v50; // rsi
  __int64 v51; // rdx
  __int64 v52; // rax
  unsigned int v53; // r15d
  size_t v54; // r15
  const char *v55; // r12
  char *v56; // r13
  const void *v57; // rsi
  _QWORD *v58; // r14
  __int64 v59; // rax
  double v62; // [rsp+18h] [rbp-258h]
  float v63; // [rsp+24h] [rbp-24Ch]
  void *v64[2]; // [rsp+28h] [rbp-248h] BYREF
  void *__dst; // [rsp+38h] [rbp-238h]
  __int128 v66; // [rsp+40h] [rbp-230h] BYREF
  void *v67; // [rsp+50h] [rbp-220h]
  __int128 v68; // [rsp+60h] [rbp-210h] BYREF
  void *v69; // [rsp+70h] [rbp-200h]

  v6 = RBX::ServiceProvider::find<RBX::Network::Client>(a1: *(_QWORD *)(a1 + 24) + 464LL, a2: 0); /*0x1067b9a85*/
  v62 = -1.0; /*0x1067b9a92*/
  if ( v6 != 0 ) /*0x1067b9a9d*/
  {
    v7 = *(_QWORD *)(v6 + 120); /*0x1067b9aa3*/
    if ( v7 != 0 ) /*0x1067b9aaa*/
    {
      v8 = *(_QWORD ***)v7; /*0x1067b9aac*/
      if ( *(_QWORD *)(v7 + 8) != *(_QWORD *)v7 ) /*0x1067b9ab3*/
      {
        v9 = *v8; /*0x1067b9ab5*/
        if ( *v8 != nullptr ) /*0x1067b9abb*/
        {
          v10 = v9[3]; /*0x1067b9abd*/
          v11 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(); /*0x1067b9ac2*/
          v12 = *(unsigned __int16 *)(v11 + 440); /*0x1067b9ace*/
          v13 = *(unsigned __int16 *)(v10 + 440) - (unsigned int)v12; /*0x1067b9ad5*/
          if ( (unsigned int)v13 <= *(unsigned __int16 *)(v11 + 442) ) /*0x1067b9ae0*/
          {
            std::string::basic_string[abi:ne200100]<0>(a1: &v68, a2: "Total Bytes Received", a3: v12, a4: v13); /*0x1067b9af0*/
            v62 = (*(double (__fastcall **)(_QWORD *, __int128 *))(*v9 + 808LL))(a1: v9, a2: &v68); /*0x1067b9b09*/
            if ( (v68 & 1) != 0 ) /*0x1067b9b18*/
              operator delete(a1: v69); /*0x1067b9b21*/
          }
        }
      }
    }
  }
  v14 = *a2; /*0x1067b9b26*/
  if ( (v14 & 1) != 0 ) /*0x1067b9b2e*/
    v15 = *((_QWORD *)a2 + 1); /*0x1067b9b30*/
  else
    v15 = v14 >> 1; /*0x1067b9b36*/
  std::string::basic_string[abi:ne200100](a1: v64, a2: v15 + 1); /*0x1067b9b4c*/
  if ( ((__int64)v64[0] & 1) != 0 ) /*0x1067b9b58*/
    v16 = (char *)__dst; /*0x1067b9b5a*/
  else
    v16 = (char *)v64 + 1; /*0x1067b9b63*/
  if ( v15 != 0 ) /*0x1067b9b6d*/
  {
    if ( (*a2 & 1) != 0 ) /*0x1067b9b73*/
      v17 = *((const void **)a2 + 2); /*0x1067b9b75*/
    else
      v17 = a2 + 1; /*0x1067b9b7b*/
    memmove(__dst: v16, __src: v17, __len: v15); /*0x1067b9b85*/
  }
  *(_WORD *)&v16[v15] = 95; /*0x1067b9b8a*/
  v18 = *a3; /*0x1067b9b92*/
  v19 = a3 + 1; /*0x1067b9b96*/
  if ( (v18 & 1) != 0 ) /*0x1067b9b9d*/
  {
    v20 = *((unsigned __int8 **)a3 + 2); /*0x1067b9b9f*/
    v21 = *((_QWORD *)a3 + 1); /*0x1067b9ba3*/
  }
  else
  {
    v21 = v18 >> 1; /*0x1067b9ba9*/
    v20 = a3 + 1; /*0x1067b9bab*/
  }
  v22 = std::string::append(a1: v64, a2: v20, a3: v21); /*0x1067b9bb5*/
  v67 = *(void **)(v22 + 16); /*0x1067b9bc5*/
  v66 = *(_OWORD *)v22; /*0x1067b9bcc*/
  *(_OWORD *)v22 = 0; /*0x1067b9bd2*/
  *(_QWORD *)(v22 + 16) = 0; /*0x1067b9bd5*/
  v23 = std::string::append(a1: &v66, a2: "_Duration"); /*0x1067b9be4*/
  v24 = 1000.0 * a4; /*0x1067b9bf9*/
  v69 = *(void **)(v23 + 16); /*0x1067b9c08*/
  v68 = *(_OWORD *)v23; /*0x1067b9c0f*/
  *(_OWORD *)v23 = 0; /*0x1067b9c15*/
  *(_QWORD *)(v23 + 16) = 0; /*0x1067b9c18*/
  v63 = v24; /*0x1067b9c20*/
  ((void (*)(void))RBX::PlayerConfigurer::reportStats)(); /*0x1067b9c28*/
  if ( (v68 & 1) != 0 ) /*0x1067b9c34*/
    operator delete(a1: v69); /*0x1067b9c3d*/
  if ( (v66 & 1) != 0 ) /*0x1067b9c49*/
    operator delete(a1: v67); /*0x1067b9c52*/
  if ( ((__int64)v64[0] & 1) != 0 ) /*0x1067b9c5e*/
    operator delete(a1: __dst); /*0x1067b9c67*/
  v25 = *a2; /*0x1067b9c6c*/
  if ( (v25 & 1) != 0 ) /*0x1067b9c74*/
    v26 = *((_QWORD *)a2 + 1); /*0x1067b9c76*/
  else
    v26 = v25 >> 1; /*0x1067b9c7c*/
  std::string::basic_string[abi:ne200100](a1: v64, a2: v26 + 1); /*0x1067b9c92*/
  if ( ((__int64)v64[0] & 1) != 0 ) /*0x1067b9c9e*/
    v27 = (char *)__dst; /*0x1067b9ca0*/
  else
    v27 = (char *)v64 + 1; /*0x1067b9ca9*/
  if ( v26 != 0 ) /*0x1067b9cb3*/
  {
    if ( (*a2 & 1) != 0 ) /*0x1067b9cb9*/
      v28 = *((const void **)a2 + 2); /*0x1067b9cbb*/
    else
      v28 = a2 + 1; /*0x1067b9cc1*/
    memmove(__dst: v27, __src: v28, __len: v26); /*0x1067b9ccb*/
  }
  *(_WORD *)&v27[v26] = 95; /*0x1067b9cd0*/
  v29 = *a3; /*0x1067b9cd8*/
  if ( (v29 & 1) != 0 ) /*0x1067b9cdf*/
  {
    v30 = *((unsigned __int8 **)a3 + 2); /*0x1067b9ce1*/
    v31 = *((_QWORD *)a3 + 1); /*0x1067b9ce5*/
  }
  else
  {
    v31 = v29 >> 1; /*0x1067b9ceb*/
    v30 = a3 + 1; /*0x1067b9ced*/
  }
  v32 = std::string::append(a1: v64, a2: v30, a3: v31); /*0x1067b9cf7*/
  v67 = *(void **)(v32 + 16); /*0x1067b9d07*/
  v66 = *(_OWORD *)v32; /*0x1067b9d0e*/
  *(_OWORD *)v32 = 0; /*0x1067b9d14*/
  *(_QWORD *)(v32 + 16) = 0; /*0x1067b9d17*/
  v33 = std::string::append(a1: &v66, a2: "_BytesReceived"); /*0x1067b9d26*/
  v69 = *(void **)(v33 + 16); /*0x1067b9d36*/
  v68 = *(_OWORD *)v33; /*0x1067b9d3d*/
  *(_OWORD *)v33 = 0; /*0x1067b9d43*/
  *(_QWORD *)(v33 + 16) = 0; /*0x1067b9d46*/
  v34 = v62; /*0x1067b9d51*/
  RBX::PlayerConfigurer::reportStats(a1: v34); /*0x1067b9d59*/
  if ( (v68 & 1) != 0 ) /*0x1067b9d65*/
    operator delete(a1: v69); /*0x1067b9d6e*/
  if ( (v66 & 1) != 0 ) /*0x1067b9d7a*/
    operator delete(a1: v67); /*0x1067b9d83*/
  if ( ((__int64)v64[0] & 1) != 0 ) /*0x1067b9d8f*/
    operator delete(a1: __dst); /*0x1067b9d98*/
  if ( (int)DFInt::JoinInfluxHundredthsPercentage > 0 ) /*0x1067b9da4*/
  {
    RBX::Analytics::InfluxDb::Points::Points(a1: &v68, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1067b9dba*/
    if ( (*a2 & 1) != 0 ) /*0x1067b9dc3*/
      v37 = *((const char **)a2 + 2); /*0x1067b9dc5*/
    else
      v37 = (const char *)(a2 + 1); /*0x1067b9dcb*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)&v68, a2: "Category", a3: v37); /*0x1067b9ddd*/
    v38 = (const char *)(a3 + 1); /*0x1067b9de6*/
    if ( (*a3 & 1) != 0 ) /*0x1067b9de9*/
      v38 = *((const char **)a3 + 2); /*0x1067b9deb*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)&v68, a2: "Result", a3: v38); /*0x1067b9dfd*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)&v68, a2: "Duration", a3: a4); /*0x1067b9e18*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v66, a2: "GameDuration", a3: v39, a4: v40); /*0x1067b9e2b*/
    RBX::Analytics::InfluxDb::Points::report( /*0x1067b9e46*/
      a1: &v68,
      a2: &v66,
      a3: (unsigned int)DFInt::JoinInfluxHundredthsPercentage,
      a4: 0);
    if ( (v66 & 1) != 0 ) /*0x1067b9e52*/
      operator delete(a1: v67); /*0x1067b9e5b*/
    RBX::Analytics::InfluxDb::Points::~Points(this: (void **)&v68); /*0x1067b9e67*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v66, a2: "DataCenterId", a3: v35, a4: v36); /*0x1067b9e7a*/
  ParamInt = RBX::GameConfigurer::getParamInt(a1, a2: &v66); /*0x1067b9e8d*/
  RBX::format(this: (RBX *)&v68, a2: "%d", ParamInt); /*0x1067b9ea4*/
  if ( (v66 & 1) != 0 ) /*0x1067b9eb0*/
    operator delete(a1: v67); /*0x1067b9eb9*/
  v42 = *a2; /*0x1067b9ebe*/
  if ( (*a2 & 1) != 0 ) /*0x1067b9ec3*/
  {
    if ( *((_QWORD *)a2 + 1) != 12 ) /*0x1067b9ed4*/
      goto LABEL_65; /*0x1067b9ed4*/
    v43 = *((unsigned __int8 **)a2 + 2); /*0x1067b9ed6*/
  }
  else
  {
    if ( v42 != 24 ) /*0x1067b9ec7*/
      goto LABEL_65; /*0x1067b9ec7*/
    v43 = a2 + 1; /*0x1067b9ec9*/
  }
  if ( (*(_QWORD *)v43 ^ 0x61727544656D6147LL | *((unsigned int *)v43 + 2) ^ 0x6E6F6974LL) == 0 ) /*0x1067b9ef4*/
  {
    if ( (*a3 & 1) != 0 ) /*0x1067b9f56*/
    {
      if ( *((_QWORD *)a3 + 1) != 4 ) /*0x1067b9fc4*/
        goto LABEL_65; /*0x1067b9fc4*/
      v45 = *((_DWORD **)a3 + 2); /*0x1067b9fca*/
    }
    else
    {
      v45 = a3 + 1; /*0x1067b9f58*/
      if ( *a3 != 8 ) /*0x1067b9f5e*/
        goto LABEL_65; /*0x1067b9f5e*/
    }
    if ( *v45 == 1801677131 ) /*0x1067b9fd4*/
    {
      std::operator+<char>(a1: &v66, a2: "KickByDatacenter_", &v68); /*0x1067b9fef*/
      RBX::PlayerConfigurer::reportStats(a1: v63); /*0x1067ba003*/
      if ( (v66 & 1) != 0 ) /*0x1067ba00f*/
        operator delete(a1: v67); /*0x1067ba018*/
      v42 = *a2; /*0x1067ba01d*/
    }
  }
LABEL_65:
  if ( (v42 & 1) != 0 ) /*0x1067b9ef8*/
  {
    if ( *((_QWORD *)a2 + 1) != 8 ) /*0x1067b9f1d*/
      goto LABEL_81; /*0x1067b9f1d*/
    v44 = *((_QWORD **)a2 + 2); /*0x1067b9f1f*/
    if ( *v44 == 0x6E696F4A656D6147LL ) /*0x1067b9f30*/
      goto LABEL_72; /*0x1067b9f30*/
  }
  else
  {
    if ( v42 != 16 ) /*0x1067b9efc*/
      goto LABEL_81; /*0x1067b9efc*/
    if ( *(_QWORD *)(a2 + 1) == 0x6E696F4A656D6147LL ) /*0x1067b9f10*/
      goto LABEL_72; /*0x1067b9f10*/
    v44 = a2 + 1; /*0x1067b9f12*/
  }
  if ( *v44 != 0x64616F4C656D6147LL ) /*0x1067b9f3f*/
    goto LABEL_81; /*0x1067b9f3f*/
LABEL_72:
  if ( (*a3 & 1) != 0 ) /*0x1067b9f47*/
  {
    if ( *((_QWORD *)a3 + 1) != 7 ) /*0x1067b9f67*/
      goto LABEL_81; /*0x1067b9f67*/
    v19 = *((_DWORD **)a3 + 2); /*0x1067b9f69*/
LABEL_80:
    if ( (*v19 ^ 0x63637553 | *(_DWORD *)((char *)v19 + 3) ^ 0x73736563) != 0 ) /*0x1067b9f7e*/
      goto LABEL_81; /*0x1067b9f7e*/
    if ( (v42 & 1) != 0 ) /*0x1067ba027*/
      v47 = *((_QWORD *)a2 + 1); /*0x1067ba029*/
    else
      v47 = v42 >> 1; /*0x1067ba031*/
    std::string::basic_string[abi:ne200100](a1: v64, a2: v47 + 13); /*0x1067ba047*/
    if ( ((__int64)v64[0] & 1) != 0 ) /*0x1067ba053*/
      v48 = (char *)__dst; /*0x1067ba055*/
    else
      v48 = (char *)v64 + 1; /*0x1067ba05e*/
    if ( v47 != 0 ) /*0x1067ba068*/
    {
      if ( (*a2 & 1) != 0 ) /*0x1067ba06e*/
        v49 = *((const void **)a2 + 2); /*0x1067ba070*/
      else
        v49 = a2 + 1; /*0x1067ba076*/
      memmove(__dst: v48, __src: v49, __len: v47); /*0x1067ba080*/
    }
    strcpy(&v48[v47], "ByDatacenter_"); /*0x1067ba09e*/
    if ( (v68 & 1) != 0 ) /*0x1067ba0b2*/
    {
      v50 = (char *)v69; /*0x1067ba0b4*/
      v51 = *((_QWORD *)&v68 + 1); /*0x1067ba0bb*/
    }
    else
    {
      v51 = (unsigned __int8)v68 >> 1; /*0x1067ba0c4*/
      v50 = (char *)&v68 + 1; /*0x1067ba0c6*/
    }
    v52 = std::string::append(a1: v64, a2: v50, a3: v51); /*0x1067ba0d4*/
    v67 = *(void **)(v52 + 16); /*0x1067ba0e4*/
    v66 = *(_OWORD *)v52; /*0x1067ba0eb*/
    *(_OWORD *)v52 = 0; /*0x1067ba0f1*/
    *(_QWORD *)(v52 + 16) = 0; /*0x1067ba0f4*/
    RBX::PlayerConfigurer::reportStats(a1: v63); /*0x1067ba104*/
    if ( (v66 & 1) != 0 ) /*0x1067ba110*/
      operator delete(a1: v67); /*0x1067ba119*/
    if ( ((__int64)v64[0] & 1) != 0 ) /*0x1067ba125*/
      operator delete(a1: __dst); /*0x1067ba12e*/
    v53 = *a2; /*0x1067ba133*/
    if ( (v53 & 1) != 0 ) /*0x1067ba13b*/
      v54 = *((_QWORD *)a2 + 1); /*0x1067ba13d*/
    else
      v54 = v53 >> 1; /*0x1067ba143*/
    std::string::basic_string[abi:ne200100](a1: &v66, a2: v54 + 13); /*0x1067ba158*/
    v55 = (char *)&v66 + 1; /*0x1067ba15d*/
    v56 = (char *)&v66 + 1; /*0x1067ba16a*/
    if ( (v66 & 1) != 0 ) /*0x1067ba16d*/
      v56 = (char *)v67; /*0x1067ba16f*/
    if ( v54 != 0 ) /*0x1067ba179*/
    {
      if ( (*a2 & 1) != 0 ) /*0x1067ba17f*/
        v57 = *((const void **)a2 + 2); /*0x1067ba181*/
      else
        v57 = a2 + 1; /*0x1067ba187*/
      memmove(__dst: v56, __src: v57, __len: v54); /*0x1067ba191*/
    }
    strcpy(&v56[v54], "BytesReceived"); /*0x1067ba1af*/
    if ( (v66 & 1) != 0 ) /*0x1067ba1cf*/
      v55 = (const char *)v67; /*0x1067ba1d1*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)(a1 + 1152), a2: v55, a3: v62); /*0x1067ba1e3*/
    if ( (v66 & 1) != 0 ) /*0x1067ba1ef*/
      operator delete(a1: v67); /*0x1067ba1f8*/
    if ( (*a2 & 1) != 0 ) /*0x1067ba202*/
    {
      if ( *((_QWORD *)a2 + 1) != 8 ) /*0x1067ba226*/
        goto LABEL_81; /*0x1067ba226*/
      v58 = *((_QWORD **)a2 + 2); /*0x1067ba22c*/
      if ( *v58 != 0x64616F4C656D6147LL ) /*0x1067ba23d*/
        goto LABEL_128; /*0x1067ba23d*/
    }
    else
    {
      if ( *a2 != 16 ) /*0x1067ba206*/
        goto LABEL_81; /*0x1067ba206*/
      if ( *(_QWORD *)(a2 + 1) != 0x64616F4C656D6147LL ) /*0x1067ba21a*/
      {
        v58 = a2 + 1; /*0x1067ba21c*/
LABEL_128:
        if ( *v58 != 0x6E696F4A656D6147LL ) /*0x1067ba24c*/
          goto LABEL_81; /*0x1067ba24c*/
        v59 = 392; /*0x1067ba252*/
        goto LABEL_131; /*0x1067ba257*/
      }
    }
    v59 = 400; /*0x1067ba259*/
LABEL_131:
    *(double *)(a1 + v59) = v62; /*0x1067ba25e*/
    goto LABEL_81; /*0x1067ba272*/
  }
  if ( *a3 == 14 ) /*0x1067b9f4c*/
    goto LABEL_80; /*0x1067b9f4c*/
LABEL_81:
  if ( (v68 & 1) != 0 ) /*0x1067b9f8b*/
    operator delete(a1: v69); /*0x1067b9f94*/
  return __stack_chk_guard; /*0x1067b9fad*/
}

// Address: 0x1067ba4aa | Name: __ZN3RBX16PlayerConfigurer11reportErrorERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_
__int64 __fastcall RBX::PlayerConfigurer::reportError(__int64 a1, __int64 a2, __int128 *a3, __int64 a4, int a5, int a6)
{
  __int128 *v6; // rbx
  const char *v9; // r15
  __int64 v10; // rcx
  __int64 v11; // rax
  __int64 v12; // rdx
  __int64 v13; // rcx
  __int64 v14; // r13
  __int64 v15; // rdx
  __int64 v16; // rcx
  RBX::Network::Client *v17; // r13
  __int64 LoadStateSuffix; // rax
  __int64 v19; // r13
  __int64 v20; // r14
  _OWORD *v21; // rdi
  __int64 v22; // rax
  _BYTE v24[16]; // [rsp+8h] [rbp-E8h] BYREF
  void *v25; // [rsp+18h] [rbp-D8h]
  std::__shared_weak_count *v26[2]; // [rsp+20h] [rbp-D0h]
  __int128 v27; // [rsp+30h] [rbp-C0h] BYREF
  void *v28; // [rsp+40h] [rbp-B0h]
  __int128 v29; // [rsp+48h] [rbp-A8h] BYREF
  void *v30; // [rsp+58h] [rbp-98h]
  std::__shared_weak_count *v31[2]; // [rsp+60h] [rbp-90h] BYREF
  void *v32; // [rsp+70h] [rbp-80h]
  __int128 v33; // [rsp+78h] [rbp-78h] BYREF
  void *v34; // [rsp+88h] [rbp-68h]
  _BYTE v35[32]; // [rsp+90h] [rbp-60h] BYREF
  _BYTE *v36; // [rsp+B0h] [rbp-40h]

  v6 = a3; /*0x1067ba4be*/
  v9 = (const char *)(a2 + 1); /*0x1067ba4d5*/
  LODWORD(a3) = a2 + 1; /*0x1067ba4dc*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1067ba4df*/
    a3 = *(__int128 **)(a2 + 16); /*0x1067ba4e1*/
  if ( (*(_BYTE *)v6 & 1) != 0 ) /*0x1067ba4e9*/
    v10 = *((_QWORD *)v6 + 2); /*0x1067ba4eb*/
  else
    LODWORD(v10) = (_DWORD)v6 + 1; /*0x1067ba4f1*/
  RBX::CreatorLog::printf(a1: 1, a2: (unsigned int)"***ERROR*** %s %s", (_DWORD)a3, a4: v10, a5, a6); /*0x1067ba503*/
  if ( *(_BYTE *)(a1 + 48) == 0 ) /*0x1067ba50d*/
  {
    v11 = RBX::ServiceProvider::find<RBX::Visit>(this: (RBX::ServiceProvider *)(*(_QWORD *)(a1 + 24) + 464LL)); /*0x1067ba51a*/
    if ( v11 != 0 ) /*0x1067ba522*/
    {
      v14 = v11; /*0x1067ba524*/
      std::string::basic_string[abi:ne200100]<0>(a1: v24, a2: "", a3: v12, a4: v13); /*0x1067ba535*/
      RBX::Visit::setUploadUrl(a1: v14, a2: v24); /*0x1067ba544*/
      if ( (v24[0] & 1) != 0 ) /*0x1067ba550*/
        operator delete(a1: v25); /*0x1067ba559*/
    }
  }
  v17 = (RBX::Network::Client *)RBX::ServiceProvider::find<RBX::Network::Client>( /*0x1067ba56e*/
                                  a1: *(_QWORD *)(a1 + 24) + 464LL,
                                  a2: 0);
  if ( v17 != nullptr ) /*0x1067ba574*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v33, a2: "Exception", a3: v15, a4: v16); /*0x1067ba585*/
    RBX::Network::Client::getConnectedServer(this: (RBX::Network::Client *)v31); /*0x1067ba594*/
    LoadStateSuffix = RBX::Network::Client::getLoadStateSuffix(this: v17); /*0x1067ba59c*/
    std::string::append(a1: &v33, a2: LoadStateSuffix); /*0x1067ba5a8*/
    RBX::Network::Client::handleConnectionStateAndMetricReporting(this: v17); /*0x1067ba5e7*/
    RBX::Network::Client::disconnect(this: v17); /*0x1067ba5f4*/
    if ( ((__int64)v31[0] & 1) != 0 ) /*0x1067ba600*/
      operator delete(a1: v32); /*0x1067ba606*/
    if ( (v33 & 1) != 0 ) /*0x1067ba60f*/
      operator delete(a1: v34); /*0x1067ba615*/
  }
  v19 = RBX::ServiceProvider::create<RBX::TimerService>(a1: *(_QWORD *)(a1 + 24) + 464LL, a2: 0); /*0x1067ba62a*/
  if ( v19 != 0 )
  {
    if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1067ba63b*/
      v9 = *(const char **)(a2 + 16); /*0x1067ba63d*/
    RBX::format(this: (RBX *)&v33, a2: "Error: %s", v9);
    RBX::weak_from<RBX::PlayerConfigurer>(a1: v31, a2: a1); /*0x1067ba661*/
    *(_OWORD *)v26 = *(_OWORD *)v31; /*0x1067ba674*/
    if ( v31[1] != nullptr ) /*0x1067ba67e*/
      _InterlockedIncrement64((volatile signed __int64 *)v31[1] + 2); /*0x1067ba680*/
    if ( (v33 & 1) != 0 ) /*0x1067ba690*/
    {
      std::string::__init_copy_ctor_external(a1: &v27, a2: v34, a3: *((_QWORD *)&v33 + 1)); /*0x1067ba6af*/
    }
    else
    {
      v28 = v34; /*0x1067ba696*/
      v27 = v33; /*0x1067ba69e*/
    }
    if ( (*(_BYTE *)v6 & 1) != 0 ) /*0x1067ba6be*/
    {
      std::string::__init_copy_ctor_external(a1: &v29, a2: *((_QWORD *)v6 + 2), a3: *((_QWORD *)v6 + 1)); /*0x1067ba6de*/
    }
    else
    {
      v30 = *((void **)v6 + 2); /*0x1067ba6c4*/
      v29 = *v6; /*0x1067ba6cc*/
    }
    v36 = nullptr; /*0x1067ba6e3*/
    v20 = operator new(a1: 0x48u); /*0x1067ba6f5*/
    *(_QWORD *)v20 = &off_10CAAC100; /*0x1067ba6ff*/
    *(_OWORD *)(v20 + 8) = *(_OWORD *)v26; /*0x1067ba709*/
    *(_OWORD *)v26 = 0; /*0x1067ba711*/
    *(_QWORD *)(v20 + 40) = v28; /*0x1067ba71c*/
    *(_OWORD *)(v20 + 24) = v27; /*0x1067ba724*/
    v27 = 0; /*0x1067ba729*/
    v28 = nullptr; /*0x1067ba72d*/
    v21 = (_OWORD *)(v20 + 48); /*0x1067ba735*/
    if ( (v29 & 1) != 0 ) /*0x1067ba740*/
    {
      std::string::__init_copy_ctor_external(a1: v21, a2: v30, a3: *((_QWORD *)&v29 + 1)); /*0x1067ba76a*/
    }
    else
    {
      *(_QWORD *)(v20 + 64) = v30; /*0x1067ba747*/
      *v21 = v29; /*0x1067ba750*/
    }
    v36 = (_BYTE *)v20; /*0x1067ba773*/
    RBX::TimerService::delay(a1: v19, a2: v35, a3: 4.0); /*0x1067ba785*/
    if ( v36 == v35 ) /*0x1067ba791*/
    {
      v22 = 32; /*0x1067ba79f*/
    }
    else
    {
      v22 = 40; /*0x1067ba793*/
      if ( v36 == nullptr ) /*0x1067ba79b*/
        goto LABEL_34; /*0x1067ba79b*/
    }
    (*(void (**)(void))(*(_QWORD *)v36 + v22))(); /*0x1067ba7a7*/
LABEL_34:
    if ( (v29 & 1) != 0 ) /*0x1067ba7b1*/
      operator delete(a1: v30); /*0x1067ba7ba*/
    if ( (v27 & 1) != 0 ) /*0x1067ba7c6*/
      operator delete(a1: v28); /*0x1067ba7cf*/
    if ( v26[1] != nullptr ) /*0x1067ba7de*/
      std::__shared_weak_count::__release_weak(this: v26[1]); /*0x1067ba7e0*/
    if ( v31[1] != nullptr ) /*0x1067ba7ef*/
      std::__shared_weak_count::__release_weak(this: v31[1]); /*0x1067ba7f1*/
    if ( (v33 & 1) != 0 ) /*0x1067ba7fa*/
      operator delete(a1: v34); /*0x1067ba800*/
  }
  return __stack_chk_guard; /*0x1067ba815*/
}

// Address: 0x1067baa50 | Name: __ZZN3RBX16PlayerConfigurer11reportErrorERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_EN3$_0D1Ev
void __fastcall RBX::PlayerConfigurer::reportError(std::string const&,std::string const&)::$_0::~$_0(__int64 a1)
{
  std::__shared_weak_count *v2; // rdi

  if ( (*(_BYTE *)(a1 + 40) & 1) != 0 ) /*0x1067baa5d*/
    operator delete(a1: *(void **)(a1 + 56)); /*0x1067baa63*/
  if ( (*(_BYTE *)(a1 + 16) & 1) != 0 ) /*0x1067baa6c*/
    operator delete(a1: *(void **)(a1 + 32)); /*0x1067baa72*/
  v2 = *(std::__shared_weak_count **)(a1 + 8); /*0x1067baa77*/
  if ( v2 != nullptr ) /*0x1067baa82*/
    std::__shared_weak_count::__release_weak(this: v2); /*0x1067baa86*/
}

// Address: 0x1067baa8e | Name: __ZN3RBX16PlayerConfigurer13reportCounterERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEb
__int64 __fastcall RBX::PlayerConfigurer::reportCounter(__int64 a1, __int64 a2, unsigned int a3)
{
  return RBX::Analytics::EphemeralCounter::reportCountersCSV(a1: a2, a2: a3); /*0x1067baaa2*/
}

// Address: 0x1067baaf8 | Name: __ZN3RBX16PlayerConfigurer11reportStatsERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEf
char *__fastcall RBX::PlayerConfigurer::reportStats(float a1, __int64 a2, unsigned __int8 *a3)
{
  unsigned int v4; // r8d
  unsigned __int8 *v5; // rcx
  __int64 v6; // r8
  char *result; // rax
  _BYTE v8[72]; // [rsp+0h] [rbp-250h] BYREF
  _BYTE v9[500]; // [rsp+48h] [rbp-208h] BYREF
  float v10; // [rsp+23Ch] [rbp-14h]

  if ( FFlag::MigrateGameEngineNetworkingReplicationAlertingTelemetryToV2 == 1 ) /*0x1067bab13*/
  {
    v10 = a1; /*0x1067bab2a*/
    RBX::Telemetry::RobloxTelemetryStat::RobloxTelemetryStat( /*0x1067bab2f*/
      a1: (__int64)v8,
      a2: (__int64)&RBX::Telemetry::kPlayerConfigurerStatsV2);
    RBX::Telemetry::RobloxTelemetryStat::setValue(this: (RBX::Telemetry::RobloxTelemetryStat *)v8, a2: v10); /*0x1067bab3f*/
    v4 = *a3; /*0x1067bab4b*/
    if ( (v4 & 1) != 0 ) /*0x1067bab53*/
    {
      v5 = *((unsigned __int8 **)a3 + 2); /*0x1067bab55*/
      v6 = *((_QWORD *)a3 + 1); /*0x1067bab59*/
    }
    else
    {
      v5 = a3 + 1; /*0x1067bab5f*/
      v6 = v4 >> 1; /*0x1067bab63*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: v9, a2: "category", a3: 8, a4: v5, a5: v6, a6: 1); /*0x1067bab78*/
    RBX::Telemetry::RobloxTelemetryStat::send(this: (RBX::Telemetry::RobloxTelemetryStat *)v8); /*0x1067bab84*/
    RBX::Telemetry::RobloxTelemetryStat::~RobloxTelemetryStat(this: (RBX::Telemetry::RobloxTelemetryStat *)v8); /*0x1067bab97*/
    a1 = v10; /*0x1067bab9c*/
  }
  result = &FFlag::DisableGameEngineNetworkingReplicationAlertingLegacyTelemetryMetrics; /*0x1067baba1*/
  if ( FFlag::DisableGameEngineNetworkingReplicationAlertingLegacyTelemetryMetrics == 0 ) /*0x1067babab*/
    return (char *)RBX::Analytics::EphemeralCounter::reportStats(a1: a3, a2: 0, a3: a1); /*0x1067babb6*/
  return result; /*0x1067babbb*/
}

// Address: 0x1067babe6 | Name: __ZN3RBX16PlayerConfigurer11onGameCloseEv
void __fastcall RBX::PlayerConfigurer::onGameClose(RBX::PlayerConfigurer *this)
{
  double v2; // xmm0_8
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // rax
  void *v8; // rcx
  __int64 v9; // rdx
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // rcx
  unsigned __int64 v13; // rdx
  signed __int64 v14; // rcx
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rdx
  __int64 v18; // rcx
  __int64 v19; // r8
  __int64 v20; // r9
  double v21; // xmm0_8
  __int64 v22; // rdx
  __int64 v23; // rcx
  __int64 v24; // rdx
  __int64 v25; // rcx
  bool v26; // r9
  __int64 v27; // rdx
  __int64 v28; // rcx
  double v29; // xmm0_8
  __int64 v30; // rdx
  __int64 v31; // rcx
  __int64 v32; // rdx
  __int64 v33; // rcx
  const char *v34; // r14
  const char *v35; // r15
  __int64 v36; // rax
  __int64 v37; // rdx
  __int64 v38; // rcx
  __int64 v39; // rax
  __int64 v40; // rdx
  __int64 v41; // rcx
  __int64 v42; // rdx
  __int64 v43; // rcx
  __int64 v44; // rdx
  __int64 v45; // rcx
  bool v46; // r9
  volatile signed __int64 *v47; // rax
  std::__shared_weak_count *v48; // rbx
  __int128 v49; // [rsp+0h] [rbp-180h] BYREF
  __int128 v50; // [rsp+10h] [rbp-170h]
  int v51; // [rsp+20h] [rbp-160h]
  _DWORD v52[10]; // [rsp+30h] [rbp-150h] BYREF
  _BYTE v53[16]; // [rsp+58h] [rbp-128h] BYREF
  void *v54; // [rsp+68h] [rbp-118h]
  _BYTE v55[16]; // [rsp+70h] [rbp-110h] BYREF
  void *v56; // [rsp+80h] [rbp-100h]
  _BYTE v57[16]; // [rsp+88h] [rbp-F8h] BYREF
  void *v58; // [rsp+98h] [rbp-E8h]
  _BYTE v59[16]; // [rsp+A0h] [rbp-E0h] BYREF
  RBX::Time *v60; // [rsp+B0h] [rbp-D0h]
  _BYTE v61[16]; // [rsp+B8h] [rbp-C8h] BYREF
  void *v62; // [rsp+C8h] [rbp-B8h]
  _BYTE v63[16]; // [rsp+D0h] [rbp-B0h] BYREF
  void *v64; // [rsp+E0h] [rbp-A0h]
  double v65; // [rsp+E8h] [rbp-98h]
  void *v66[3]; // [rsp+F0h] [rbp-90h] BYREF
  double v67; // [rsp+108h] [rbp-78h]
  std::__shared_weak_count *v68[2]; // [rsp+110h] [rbp-70h] BYREF
  void *v69[2]; // [rsp+120h] [rbp-60h]
  int v70; // [rsp+130h] [rbp-50h]
  unsigned __int8 v71[16]; // [rsp+138h] [rbp-48h] BYREF
  void *v72; // [rsp+148h] [rbp-38h]
  _BYTE v73[41]; // [rsp+157h] [rbp-29h] BYREF

  if ( *((_BYTE *)this + 51) /* +51 likely connectResolved -- UNVERIFIED */ != 0 ) /*0x1067bac01*/
  {
    if ( this->loadResolved /* +53 */ == 1 && this->joinResolved /* +54 */ != 0 ) /*0x1067bac15*/
    {
      if ( this->playResolved /* +55 */ == 0 ) /*0x1067bac1f*/
      {
        RBX::Time::nowFastSec(this); /*0x1067bac25*/
        v67 = v2 - *((double *)this + 21) /* +168: NO 2022 FIELD */ - *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067bac3a*/
        this->playResolved /* +55 */ = 1; /*0x1067bac3f*/
        std::string::basic_string[abi:ne200100]<0>(a1: v68, a2: "GameDuration", a3: v3, a4: v4); /*0x1067bac4e*/
        std::string::basic_string[abi:ne200100]<0>(a1: v71, a2: "Success", a3: v5, a4: v6); /*0x1067bac5e*/
        RBX::PlayerConfigurer::reportDuration(a1: (__int64)this, a2: (unsigned __int8 *)v68, a3: v71, a4: v67); /*0x1067bac73*/
        if ( (v71[0] & 1) != 0 ) /*0x1067bac7c*/
          operator delete(a1: v72); /*0x1067bac82*/
        if ( ((__int64)v68[0] & 1) != 0 ) /*0x1067bac8b*/
          operator delete(a1: v69[0]); /*0x1067bac91*/
        RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)v71); /*0x1067bac9d*/
        v7 = std::string::insert(a1: v71, a2: 0, a3: "GameDuration_"); /*0x1067bacae*/
        v69[0] = *(void **)(v7 + 16); /*0x1067bacb7*/
        v8 = v69[0]; /*0x1067bacb3*/
        *(_OWORD *)v68 = *(_OWORD *)v7; /*0x1067bacbf*/
        *(_OWORD *)v7 = 0; /*0x1067bacc8*/
        *(_QWORD *)(v7 + 16) = 0; /*0x1067baccc*/
        std::string::basic_string[abi:ne200100]<0>(a1: v66, a2: "Success", a3: v9, a4: v8); /*0x1067bace2*/
        RBX::PlayerConfigurer::reportDuration( /*0x1067bacfa*/
          a1: (__int64)this,
          a2: (unsigned __int8 *)v68,
          a3: (unsigned __int8 *)v66,
          a4: v67);
        if ( ((__int64)v66[0] & 1) != 0 ) /*0x1067bad06*/
          operator delete(a1: v66[2]); /*0x1067bad0c*/
        if ( ((__int64)v68[0] & 1) != 0 ) /*0x1067bad15*/
          operator delete(a1: v69[0]); /*0x1067bad1b*/
        if ( (v71[0] & 1) != 0 ) /*0x1067bad24*/
          operator delete(a1: v72); /*0x1067bad2a*/
        std::string::basic_string[abi:ne200100]<0>(a1: v68, a2: "LeftGame", a3: v10, a4: v11); /*0x1067bad3d*/
        RBX::Stats::reportGameStatus(a1: v68, a2: 0); /*0x1067bad47*/
        if ( ((__int64)v68[0] & 1) != 0 ) /*0x1067bad50*/
          operator delete(a1: v69[0]); /*0x1067bad56*/
        v12 = *((_QWORD *)this + 9) /* +72 likely userId -- UNVERIFIED */; /*0x1067bad5b*/
        if ( v12 > 0 ) /*0x1067bad62*/
        {
          v13 = v12 / 0x3E8uLL; /*0x1067bad7c*/
          v14 = v12 % 0x3E8uLL; /*0x1067bad87*/
          if ( v14 < DFInt::ClientJoinProcessPositiveSamplesThousandths ) /*0x1067bad97*/
          {
            std::string::basic_string[abi:ne200100]<0>(a1: v59, a2: "client", a3: v13, a4: v14); /*0x1067badab*/
            std::string::basic_string[abi:ne200100]<0>(a1: v61, a2: "report", a3: v15, a4: v16); /*0x1067badbe*/
            std::string::basic_string[abi:ne200100]<0>(a1: v63, a2: "GameLeaving", a3: v17, a4: v18); /*0x1067badd1*/
            memset(v52, 0, 32); /*0x1067bade6*/
            v52[8] = 1065353216; /*0x1067badea*/
            RBX::Analytics::EventIngest::setRBXEvent( /*0x1067bae06*/
              a1: v59,
              a2: v61,
              a3: v63,
              a4: v52,
              a5: v19,
              a6: v20,
              a7: v49,
              a8: *((_QWORD *)&v49 + 1),
              a9: v50,
              a10: *((_QWORD *)&v50 + 1),
              a11: v51);
            std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v52); /*0x1067bae12*/
            if ( (v63[0] & 1) != 0 ) /*0x1067bae1e*/
              operator delete(a1: v64); /*0x1067bae27*/
            if ( (v61[0] & 1) != 0 ) /*0x1067bae33*/
              operator delete(a1: v62); /*0x1067bae3c*/
            if ( (v59[0] & 1) != 0 ) /*0x1067bae48*/
              operator delete(a1: v60); /*0x1067bae55*/
          }
        }
      }
    }
    else
    {
      RBX::Time::nowFastSec(this); /*0x1067baef8*/
      v67 = v29 - *((double *)this + 32) /* +256: NO 2022 FIELD */; /*0x1067baf05*/
      if ( this->loadResolved /* +53 */ == 0 ) /*0x1067baf0e*/
      {
        this->loadResolved /* +53 */ = 1; /*0x1067baf10*/
        std::string::basic_string[abi:ne200100]<0>(a1: v68, a2: "GameLoad", a3: v27, a4: v28); /*0x1067baf1f*/
        std::string::basic_string[abi:ne200100]<0>(a1: v71, a2: "Cancel", a3: v30, a4: v31); /*0x1067baf2f*/
        RBX::PlayerConfigurer::reportDuration(a1: (__int64)this, a2: (unsigned __int8 *)v68, a3: v71, a4: v67); /*0x1067baf44*/
        if ( (v71[0] & 1) != 0 ) /*0x1067baf4d*/
          operator delete(a1: v72); /*0x1067baf53*/
        if ( ((__int64)v68[0] & 1) != 0 ) /*0x1067baf5c*/
          operator delete(a1: v69[0]); /*0x1067baf62*/
      }
      if ( this->joinResolved /* +54 */ == 0 ) /*0x1067baf6b*/
      {
        this->joinResolved /* +54 */ = 1; /*0x1067baf6d*/
        std::string::basic_string[abi:ne200100]<0>(a1: v68, a2: "GameJoin", a3: v27, a4: v28); /*0x1067baf7c*/
        std::string::basic_string[abi:ne200100]<0>(a1: v71, a2: "Cancel", a3: v32, a4: v33); /*0x1067baf8c*/
        RBX::PlayerConfigurer::reportDuration(a1: (__int64)this, a2: (unsigned __int8 *)v68, a3: v71, a4: v67); /*0x1067bafa1*/
        if ( (v71[0] & 1) != 0 ) /*0x1067bafaa*/
          operator delete(a1: v72); /*0x1067bafb0*/
        if ( ((__int64)v68[0] & 1) != 0 ) /*0x1067bafb9*/
          operator delete(a1: v69[0]); /*0x1067bafbf*/
      }
      *(_OWORD *)v69 = 0; /*0x1067bafc8*/
      *(_OWORD *)v68 = 0; /*0x1067bafcd*/
      v70 = 1065353216; /*0x1067bafd2*/
      v34 = "no"; /*0x1067bafe4*/
      v35 = "no"; /*0x1067bafeb*/
      if ( this->loadResolved /* +53 */ != 0 ) /*0x1067bafee*/
        v35 = "yes"; /*0x1067bafee*/
      std::string::basic_string[abi:ne200100]<0>(a1: v71, a2: "loadResolved", a3: v27, a4: v28); /*0x1067bb000*/
      v66[0] = v71; /*0x1067bb00c*/
      v36 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067bb021*/
              a1: v68,
              a2: v71,
              a3: std::piecewise_construct,
              a4: v66,
              a5: v73);
      std::string::assign(a1: v36 + 40, a2: v35); /*0x1067bb030*/
      if ( (v71[0] & 1) != 0 ) /*0x1067bb039*/
        operator delete(a1: v72); /*0x1067bb03f*/
      if ( this->joinResolved /* +54 */ != 0 ) /*0x1067bb048*/
        v34 = "yes"; /*0x1067bb048*/
      std::string::basic_string[abi:ne200100]<0>(a1: v71, a2: "joinResolved", a3: v37, a4: v38); /*0x1067bb05a*/
      v66[0] = v71; /*0x1067bb066*/
      v39 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067bb07b*/
              a1: v68,
              a2: v71,
              a3: std::piecewise_construct,
              a4: v66,
              a5: v73);
      std::string::assign(a1: v39 + 40, a2: v34); /*0x1067bb08a*/
      if ( (v71[0] & 1) != 0 ) /*0x1067bb093*/
        operator delete(a1: v72); /*0x1067bb099*/
      std::string::basic_string[abi:ne200100]<0>(a1: v53, a2: "client", a3: v40, a4: v41); /*0x1067bb0ac*/
      std::string::basic_string[abi:ne200100]<0>(a1: v55, a2: "report", a3: v42, a4: v43); /*0x1067bb0bf*/
      std::string::basic_string[abi:ne200100]<0>(a1: v57, a2: "GameLoadCanceled", a3: v44, a4: v45); /*0x1067bb0d2*/
      v50 = 0; /*0x1067bb0e2*/
      v49 = 0; /*0x1067bb0e7*/
      v51 = 1065353216; /*0x1067bb0eb*/
      ((void (__fastcall *)(_BYTE *, _BYTE *, _BYTE *, __int128 *))RBX::Analytics::EventIngest::setRBXEvent)( /*0x1067bb107*/
        a1: v53,
        a2: v55,
        a3: v57,
        a4: &v49);
      std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: &v49); /*0x1067bb113*/
      if ( (v57[0] & 1) != 0 ) /*0x1067bb11f*/
        operator delete(a1: v58); /*0x1067bb128*/
      if ( (v55[0] & 1) != 0 ) /*0x1067bb134*/
        operator delete(a1: v56); /*0x1067bb13d*/
      if ( (v53[0] & 1) != 0 ) /*0x1067bb149*/
        operator delete(a1: v54); /*0x1067bb152*/
      RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1067bb171*/
        this: (RBX::Analytics::Event *)"Game",
        a2: "GameJoin",
        a3: "Cancel",
        a4: nullptr,
        a5: 0,
        a6: v46);
      std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v68); /*0x1067bb17a*/
    }
  }
  else
  {
    RBX::Time::nowFastSec(this); /*0x1067bae5f*/
    v67 = v21; /*0x1067bae64*/
    v65 = *((double *)this + 32) /* +256: NO 2022 FIELD */; /*0x1067bae71*/
    std::string::basic_string[abi:ne200100]<0>(a1: v68, a2: "GameConnect", a3: v22, a4: v23); /*0x1067bae84*/
    std::string::basic_string[abi:ne200100]<0>(a1: v71, a2: "Failure", a3: v24, a4: v25); /*0x1067bae94*/
    RBX::PlayerConfigurer::reportDuration(a1: (__int64)this, a2: (unsigned __int8 *)v68, a3: v71, a4: v67 - v65); /*0x1067baeb1*/
    if ( (v71[0] & 1) != 0 ) /*0x1067baeba*/
      operator delete(a1: v72); /*0x1067baec0*/
    if ( ((__int64)v68[0] & 1) != 0 ) /*0x1067baec9*/
      operator delete(a1: v69[0]); /*0x1067baecf*/
    RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1067baeee*/
      this: (RBX::Analytics::Event *)"Game",
      a2: "GameJoin",
      a3: "Failure",
      a4: nullptr,
      a5: 0,
      a6: v26);
  }
  if ( FFlag::EnableLocationRecording == 1 && *((_QWORD *)this + 223) /* +1784: NO 2022 FIELD */ != 0 ) /*0x1067bb192*/
  {
    v68[0] = *((std::__shared_weak_count **)this + 223); /*0x1067bb194*/
    v47 = *((volatile signed __int64 **)this + 224); /*0x1067bb198*/
    v68[1] = (std::__shared_weak_count *)v47; /*0x1067bb19f*/
    if ( v47 != nullptr ) /*0x1067bb1a6*/
      _InterlockedIncrement64(v47 + 1); /*0x1067bb1a8*/
    RBX::TaskScheduler::remove(a1: v68); /*0x1067bb1b1*/
    v48 = v68[1]; /*0x1067bb1b6*/
    if ( v68[1] != nullptr /*0x1067bb1cf*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v68[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v48 + 16LL))(a1: v48); /*0x1067bb1d7*/
      std::__shared_weak_count::__release_weak(this: v48); /*0x1067bb1dd*/
    }
  }
}

// Address: 0x1067bb364 | Name: __ZN3RBX16PlayerConfigurer15onDisconnectionERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEbS7_i
void __fastcall RBX::PlayerConfigurer::onDisconnection(__int64 a1, __int64 a2, __int64 a3, unsigned __int8 *a4, int a5)
{
  char v7; // r12
  __int64 v9; // rdi
  __int64 v10; // rax
  char v11; // al
  int v12; // eax
  _DWORD *v13; // rax
  char v14; // al
  _DWORD *v15; // rax
  __int64 v16; // rax
  __int64 v17; // rdx
  __int64 v18; // rcx
  __int64 v19; // rax
  __int64 v20; // rdx
  __int64 v21; // rcx
  char *v22; // rsi
  __int64 v23; // rdx
  __int64 v24; // rcx
  __int64 v25; // rdx
  __int64 v26; // rcx
  unsigned int v27; // r15d
  char *v28; // rsi
  __int64 v29; // rdx
  __int64 v30; // rcx
  __int64 v31; // rdx
  __int64 v32; // rcx
  __int64 v33; // rdi
  __int64 v34; // rax
  __int64 v35; // rax
  __int64 v36; // r14
  __int64 FirstChildByName; // r14
  RBX::Visit *v38; // rax
  RBX::Visit *v39; // r14
  __int64 v40; // rdx
  __int64 v41; // rcx
  unsigned int ParamInt; // eax
  const char *v43; // rdx
  _BYTE v44[8]; // [rsp+0h] [rbp-D0h] BYREF
  volatile signed __int32 *v45; // [rsp+8h] [rbp-C8h] BYREF
  _BYTE v46[16]; // [rsp+10h] [rbp-C0h] BYREF
  void *v47; // [rsp+20h] [rbp-B0h]
  _BYTE v48[16]; // [rsp+28h] [rbp-A8h] BYREF
  void *v49; // [rsp+38h] [rbp-98h]
  __int128 v50; // [rsp+40h] [rbp-90h] BYREF
  __int128 v51; // [rsp+50h] [rbp-80h]
  int v52; // [rsp+60h] [rbp-70h]
  __int64 v53; // [rsp+68h] [rbp-68h]
  char v54; // [rsp+70h] [rbp-60h]
  char v55[16]; // [rsp+80h] [rbp-50h] BYREF
  void *v56; // [rsp+90h] [rbp-40h]
  __int128 v57; // [rsp+98h] [rbp-38h] BYREF
  void *v58; // [rsp+A8h] [rbp-28h]

  v7 = a3; /*0x1067bb37c*/
  if ( a5 == 262 && DFFlag::ReportLuauConnIssue != 0 ) /*0x1067bb395*/
  {
    v9 = *(_QWORD *)(a1 + 24); /*0x1067bb397*/
    if ( v9 != 0 ) /*0x1067bb39e*/
    {
      v10 = RBX::ServiceProvider::find<RBX::Network::Client>(a1: v9 + 464, a2: 0); /*0x1067bb3a9*/
      if ( v10 != 0 ) /*0x1067bb3b1*/
        RBX::Network::ReportDebugConnectionIssueMetrics(a1: v10 + 4872); /*0x1067bb3bc*/
    }
  }
  v11 = *(_BYTE *)(a1 + 52); /*0x1067bb3c1*/
  if ( v7 != 0 ) /*0x1067bb3c7*/
  {
    if ( v11 != 0 ) /*0x1067bb3cb*/
      goto LABEL_47; /*0x1067bb3cb*/
    v50 = 0; /*0x1067bb3d4*/
    *(_QWORD *)&v51 = 0; /*0x1067bb3db*/
    v12 = *a4; /*0x1067bb3e3*/
    if ( (v12 & 1) != 0 ) /*0x1067bb3e9*/
    {
      v16 = *((_QWORD *)a4 + 1); /*0x1067bb43c*/
      if ( v16 == 0 ) /*0x1067bb443*/
        goto LABEL_32; /*0x1067bb443*/
      if ( v16 == 4 ) /*0x1067bb44d*/
      {
        v13 = *((_DWORD **)a4 + 2); /*0x1067bb44f*/
LABEL_20:
        if ( *v13 != 1701736302 ) /*0x1067bb459*/
          goto LABEL_21; /*0x1067bb459*/
LABEL_32:
        std::string::assign( /*0x1067bb51f*/
          a1: &v50,
          a2: "You have lost connection to the game server, please close the Window and click \"Play\" again on the game page.");
        goto LABEL_33; /*0x1067bb52d*/
      }
    }
    else
    {
      if ( *a4 == 0 ) /*0x1067bb3ed*/
        goto LABEL_32; /*0x1067bb3ed*/
      if ( v12 == 8 ) /*0x1067bb3f6*/
      {
        v13 = a4 + 1; /*0x1067bb3f8*/
        goto LABEL_20; /*0x1067bb3fc*/
      }
    }
LABEL_21:
    std::string::operator=(a1: &v50, a2: a4); /*0x1067bb45f*/
LABEL_33:
    v27 = 256; /*0x1067bb532*/
    if ( a5 > 0 ) /*0x1067bb53b*/
      v27 = a5; /*0x1067bb53b*/
    if ( (v50 & 1) != 0 ) /*0x1067bb546*/
      v28 = (char *)v51; /*0x1067bb548*/
    else
      v28 = (char *)&v50 + 1; /*0x1067bb54e*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v57, a2: v28, a3: v17, a4: v18); /*0x1067bb559*/
    std::string::basic_string[abi:ne200100]<0>(a1: v55, a2: "LostConnection", a3: v29, a4: v30); /*0x1067bb569*/
    std::string::basic_string[abi:ne200100]<0>(a1: v48, a2: "LostConnection", a3: v31, a4: v32); /*0x1067bb57c*/
    RBX::PlayerConfigurer::showErrorWindow(a1, a2: &v57, a3: v55, a4: (__int64)v48, a5: v27); /*0x1067bb596*/
    goto LABEL_39; /*0x1067bb596*/
  }
  if ( v11 != 0 ) /*0x1067bb400*/
    goto LABEL_47; /*0x1067bb400*/
  v50 = 0; /*0x1067bb409*/
  *(_QWORD *)&v51 = 0; /*0x1067bb410*/
  v14 = *a4; /*0x1067bb418*/
  if ( (*a4 & 1) != 0 ) /*0x1067bb41d*/
  {
    v19 = *((_QWORD *)a4 + 1); /*0x1067bb47d*/
    if ( v19 == 0 && a5 != 267 ) /*0x1067bb47a*/
      goto LABEL_27; /*0x1067bb489*/
    if ( v19 == 4 ) /*0x1067bb48f*/
    {
      v15 = *((_DWORD **)a4 + 2); /*0x1067bb491*/
LABEL_25:
      if ( *v15 != 1701736302 ) /*0x1067bb49b*/
        goto LABEL_26; /*0x1067bb49b*/
LABEL_27:
      std::string::assign(a1: &v50, a2: "This game server has shut down, please reconnect"); /*0x1067bb4ae*/
      goto LABEL_28; /*0x1067bb4bc*/
    }
  }
  else
  {
    if ( v14 == 0 && a5 != 267 ) /*0x1067bb426*/
      goto LABEL_27; /*0x1067bb430*/
    if ( v14 == 8 ) /*0x1067bb434*/
    {
      v15 = a4 + 1; /*0x1067bb436*/
      goto LABEL_25; /*0x1067bb43a*/
    }
  }
LABEL_26:
  std::string::operator=(a1: &v50, a2: a4); /*0x1067bb49d*/
LABEL_28:
  if ( (v50 & 1) != 0 ) /*0x1067bb4c8*/
    v22 = (char *)v51; /*0x1067bb4ca*/
  else
    v22 = (char *)&v50 + 1; /*0x1067bb4d0*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v57, a2: v22, a3: v20, a4: v21); /*0x1067bb4db*/
  std::string::basic_string[abi:ne200100]<0>(a1: v55, a2: "Kick", a3: v23, a4: v24); /*0x1067bb4eb*/
  std::string::basic_string[abi:ne200100]<0>(a1: v48, a2: "Kick", a3: v25, a4: v26); /*0x1067bb4fe*/
  RBX::PlayerConfigurer::showErrorWindow(a1, a2: &v57, a3: v55, a4: (__int64)v48, (unsigned int)a5); /*0x1067bb518*/
LABEL_39:
  if ( (v48[0] & 1) != 0 ) /*0x1067bb5a2*/
    operator delete(a1: v49); /*0x1067bb5ab*/
  if ( (v55[0] & 1) != 0 ) /*0x1067bb5b4*/
    operator delete(a1: v56); /*0x1067bb5ba*/
  if ( (v57 & 1) != 0 ) /*0x1067bb5c3*/
    operator delete(a1: v58); /*0x1067bb5c9*/
  if ( (v50 & 1) != 0 ) /*0x1067bb5d5*/
    operator delete(a1: (void *)v51); /*0x1067bb5db*/
LABEL_47:
  v33 = *(_QWORD *)(a1 + 24); /*0x1067bb5e0*/
  if ( v33 != 0 ) /*0x1067bb5e7*/
  {
    if ( FFlag::UnlockMouseIfKicked == 1 ) /*0x1067bb5f4*/
    {
      v34 = RBX::ServiceProvider::find<RBX::MouseService>(a1: v33 + 464, a2: 0); /*0x1067bb5ff*/
      if ( v34 != 0 ) /*0x1067bb607*/
        RBX::MouseService::setMouseType(a1: v34, a2: 0); /*0x1067bb60e*/
    }
    v35 = RBX::ServiceProvider::find<RBX::Players>(a1: *(_QWORD *)(a1 + 24) + 464LL, a2: 0); /*0x1067bb61e*/
    if ( v35 != 0 ) /*0x1067bb626*/
    {
      v36 = *(_QWORD *)(v35 + 288); /*0x1067bb628*/
      if ( v36 != 0 ) /*0x1067bb632*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: &v50, a2: "PlayerScripts", a3, a4); /*0x1067bb645*/
        FirstChildByName = RBX::Instance::findFirstChildByName(a1: v36, a2: &v50, a3: 0); /*0x1067bb657*/
        if ( (v50 & 1) != 0 ) /*0x1067bb661*/
          operator delete(a1: (void *)v51); /*0x1067bb667*/
        if ( FirstChildByName != 0 ) /*0x1067bb66f*/
          (*(void (__fastcall **)(__int64))(*(_QWORD *)FirstChildByName + 280LL))(a1: FirstChildByName); /*0x1067bb677*/
      }
    }
  }
  if ( *(_BYTE *)(a1 + 48) == 0 ) /*0x1067bb681*/
  {
    v38 = (RBX::Visit *)RBX::ServiceProvider::find<RBX::Visit>(this: (RBX::ServiceProvider *)(*(_QWORD *)(a1 + 24) /*0x1067bb692*/
                                                                                            + 464LL));
    if ( v38 != nullptr ) /*0x1067bb69a*/
    {
      v39 = v38; /*0x1067bb69c*/
      if ( (unsigned __int8)RBX::Visit::hasPingThread(this: v38) != 0 ) /*0x1067bb6a9*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: v46, a2: "", a3, a4); /*0x1067bb6b9*/
        std::string::basic_string[abi:ne200100]<0>(a1: &v50, a2: "PingInterval", a3: v40, a4: v41); /*0x1067bb6cc*/
        ParamInt = RBX::GameConfigurer::getParamInt(a1, a2: &v50); /*0x1067bb6db*/
        RBX::Visit::setPing(a1: v39, a2: v46, a3: ParamInt); /*0x1067bb6ec*/
        if ( (v50 & 1) != 0 ) /*0x1067bb6f8*/
          operator delete(a1: (void *)v51); /*0x1067bb6fe*/
        if ( (v46[0] & 1) != 0 ) /*0x1067bb70a*/
          operator delete(a1: v47); /*0x1067bb713*/
      }
    }
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v50, a2: "PingUrl", a3, a4); /*0x1067bb729*/
  RBX::GameConfigurer::getParamString(a1: &v57, a2: a1, a3: &v50); /*0x1067bb738*/
  if ( (v50 & 1) != 0 ) /*0x1067bb744*/
    operator delete(a1: (void *)v51); /*0x1067bb74a*/
  if ( (v57 & 1) != 0 ) /*0x1067bb754*/
  {
    if ( *((_QWORD *)&v57 + 1) == 0 ) /*0x1067bb765*/
      goto LABEL_73; /*0x1067bb765*/
    v43 = (const char *)v58; /*0x1067bb767*/
  }
  else
  {
    if ( (_BYTE)v57 == 0 ) /*0x1067bb758*/
      goto LABEL_73; /*0x1067bb758*/
    v43 = (char *)&v57 + 1; /*0x1067bb75a*/
  }
  RBX::format(this: (RBX *)v55, a2: "%s&disconnect=true", v43); /*0x1067bb778*/
  v51 = 0; /*0x1067bb787*/
  v50 = 0; /*0x1067bb78b*/
  v52 = 1065353216; /*0x1067bb78e*/
  v53 = 0; /*0x1067bb795*/
  v54 = 0; /*0x1067bb79d*/
  RBX::HttpAsync::get(a1: v44, a2: v55, a3: &v50); /*0x1067bb7ac*/
  boost::detail::shared_count::~shared_count(this: &v45); /*0x1067bb7b8*/
  std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: &v50); /*0x1067bb7c4*/
  if ( (v55[0] & 1) != 0 ) /*0x1067bb7cd*/
    operator delete(a1: v56); /*0x1067bb7d3*/
LABEL_73:
  if ( (v57 & 1) != 0 ) /*0x1067bb7dc*/
    operator delete(a1: v58); /*0x1067bb7e2*/
}

// Address: 0x1067bb974 | Name: __ZN3RBX16PlayerConfigurer29onDisconnectionShutdownCameraEv
__int64 __fastcall RBX::PlayerConfigurer::onDisconnectionShutdownCamera(RBX::PlayerConfigurer *this)
{
  __int64 v1; // rdi
  __int64 v2; // rsi
  __int64 result; // rax
  std::__shared_weak_count *v4; // rbx
  RBX::VideoCaptureService *v5; // [rsp+8h] [rbp-18h] BYREF
  std::__shared_weak_count *v6; // [rsp+10h] [rbp-10h]

  v1 = *((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */; /*0x1067bb97d*/
  if ( v1 != 0 ) /*0x1067bb984*/
    v2 = *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::VideoCaptureService>(this: (RBX::ServiceProvider *)(v1 + 464)); /*0x1067bb992*/
  else
    v2 = 0; /*0x1067bb997*/
  result = RBX::shared_from<RBX::VideoCaptureService>(a1: &v5, a2: v2); /*0x1067bb9a0*/
  if ( v5 != nullptr ) /*0x1067bb9ab*/
    result = RBX::VideoCaptureService::stop(this: v5); /*0x1067bb9ad*/
  v4 = v6; /*0x1067bb9b2*/
  if ( v6 != nullptr ) /*0x1067bb9b9*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v6 + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x1067bb9c2*/
    if ( result == 0 ) /*0x1067bb9cb*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(a1: v4); /*0x1067bb9d3*/
      return std::__shared_weak_count::__release_weak(this: v4); /*0x1067bb9d9*/
    }
  }
  return result; /*0x1067bb9de*/
}

// Address: 0x1067bb9fa | Name: __ZN3RBX16PlayerConfigurer20onConnectionAcceptedERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERKNS1_10shared_ptrINS_8InstanceEEE
__int64 __fastcall RBX::PlayerConfigurer::onConnectionAccepted(__int64 a1, __int64 a2, __int64 a3)
{
  RBX::Network::Client *v5; // rax
  RBX::Time *v6; // rdi
  unsigned __int8 ConnectionNetworkPath; // al
  RBX::Memory *v8; // xmm0_8
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // rdx
  __int64 v12; // rcx
  _BYTE *v13; // rax
  __int64 v14; // r14
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rdx
  __int64 v18; // rcx
  unsigned int ParamInt; // eax
  __int64 v20; // r14
  __int64 v21; // rax
  __int64 v22; // rdi
  char *v23; // rdx
  __int64 v24; // rcx
  rbx::signals::slots_holder **v25; // r14
  char v26; // r15
  void *v27; // r13
  unsigned int v28; // esi
  unsigned __int64 v29; // rsi
  volatile signed __int32 *v30; // r12
  rbx::signals::slots_holder *v31; // rax
  __int64 v32; // rax
  __int64 v33; // rcx
  unsigned int v34; // esi
  void **v35; // rax
  __int64 v36; // rax
  volatile signed __int32 *v37; // rdi
  __int64 v38; // r14
  void **v39; // rax
  __int64 v40; // rax
  volatile signed __int32 *v41; // rdi
  __int64 v42; // r14
  unsigned int v43; // esi
  unsigned int v44; // r13d
  rbx::signals::slots_holder **v45; // r14
  unsigned __int64 v46; // rsi
  volatile signed __int32 *v47; // r12
  rbx::signals::slots_holder *v48; // rax
  __int64 v49; // rax
  rbx::signals::slots_holder *v50; // rdi
  unsigned int v51; // esi
  void **v52; // rax
  __int64 v53; // rax
  volatile signed __int32 *v54; // rdi
  __int64 v55; // rax
  __int64 v56; // r14
  unsigned int v57; // esi
  unsigned int v58; // r13d
  rbx::signals::slots_holder **v59; // r14
  unsigned __int64 v60; // rsi
  volatile signed __int32 *v61; // r12
  rbx::signals::slots_holder *v62; // rax
  __int64 v63; // rax
  rbx::signals::slots_holder *v64; // rdi
  unsigned int v65; // esi
  unsigned int v66; // esi
  void **v67; // rax
  __int64 v68; // rax
  volatile signed __int32 *v69; // rdi
  rbx::signals::slots_holder **v70; // r14
  unsigned int v71; // r13d
  unsigned __int64 v72; // rsi
  unsigned __int64 v73; // r12
  rbx::signals::slots_holder *v74; // rax
  unsigned __int64 v75; // rax
  rbx::signals::slots_holder *v76; // rdi
  unsigned int v77; // esi
  std::__shared_weak_count **v78; // rax
  __int64 v79; // r12
  __int64 v80; // rax
  volatile signed __int32 *v81; // rdi
  __int64 v82; // r14
  void **v83; // rax
  __int64 v84; // rax
  volatile signed __int32 *v85; // rdi
  __int64 v86; // r14
  void **v87; // rax
  __int64 v88; // rax
  volatile signed __int32 *v89; // rdi
  __int64 v90; // r14
  void **v91; // rax
  __int64 v92; // rax
  volatile signed __int32 *v93; // rdi
  __int64 v94; // r14
  volatile signed __int32 *v95; // rdi
  __int64 v96; // rdx
  __int64 v97; // rcx
  __int64 v98; // r14
  __int64 v99; // rdx
  __int64 v100; // rcx
  __int64 v101; // rdx
  __int64 v102; // rcx
  std::__shared_weak_count *v103; // rbx
  std::__shared_weak_count *v104; // rbx
  char v106[8]; // [rsp+0h] [rbp-150h] BYREF
  std::__shared_weak_count *v107; // [rsp+8h] [rbp-148h]
  _BYTE v108[16]; // [rsp+10h] [rbp-140h] BYREF
  void *v109; // [rsp+20h] [rbp-130h]
  _BYTE v110[16]; // [rsp+28h] [rbp-128h] BYREF
  void *v111; // [rsp+38h] [rbp-118h]
  _BYTE v112[16]; // [rsp+40h] [rbp-110h] BYREF
  void *v113; // [rsp+50h] [rbp-100h]
  _BYTE v114[16]; // [rsp+58h] [rbp-F8h] BYREF
  void *v115; // [rsp+68h] [rbp-E8h]
  __int64 v116; // [rsp+B8h] [rbp-98h]
  _DWORD v117[3]; // [rsp+C4h] [rbp-8Ch] BYREF
  std::__shared_weak_count *v118; // [rsp+D0h] [rbp-80h]
  RBX::Memory *v119; // [rsp+D8h] [rbp-78h]
  __int128 v120; // [rsp+E0h] [rbp-70h] BYREF
  void *v121; // [rsp+F0h] [rbp-60h]
  void *v122; // [rsp+F8h] [rbp-58h] BYREF
  std::__shared_weak_count *v123[2]; // [rsp+100h] [rbp-50h] BYREF
  void *v124; // [rsp+110h] [rbp-40h]
  __int64 v125; // [rsp+118h] [rbp-38h]

  v5 = (RBX::Network::Client *)RBX::ServiceProvider::find<RBX::Network::Client>(a1: *(_QWORD *)(a1 + 24) + 464LL, a2: 0); /*0x1067bba2d*/
  if ( v5 != nullptr ) /*0x1067bba35*/
  {
    ConnectionNetworkPath = RBX::Network::Client::getConnectionNetworkPath(this: v5); /*0x1067bba3a*/
    RBX::Transport::reportConnectionAttemptResult(a1: 1, a2: ConnectionNetworkPath); /*0x1067bba47*/
  }
  *(_BYTE *)(a1 + 51) = 1; /*0x1067bba4c*/
  RBX::Time::nowFastSec(this: v6); /*0x1067bba50*/
  v119 = v8; /*0x1067bba55*/
  std::string::basic_string[abi:ne200100]<0>(a1: v123, a2: "GameConnect", a3: v9, a4: v10); /*0x1067bba65*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v120, a2: "Success", a3: v11, a4: v12); /*0x1067bba75*/
  RBX::PlayerConfigurer::reportDuration( /*0x1067bba92*/
    a1,
    a2: (unsigned __int8 *)v123,
    a3: (unsigned __int8 *)&v120,
    a4: *(double *)&v119 - *(double *)(a1 + 256));
  if ( (v120 & 1) != 0 ) /*0x1067bba9b*/
    operator delete(a1: v121); /*0x1067bbaa1*/
  if ( ((__int64)v123[0] & 1) != 0 ) /*0x1067bbaaa*/
    operator delete(a1: v124); /*0x1067bbab0*/
  *(double *)(a1 + 216) = *(double *)&v119 - *(double *)(a1 + 168); /*0x1067bbac2*/
  *(_DWORD *)(a1 + 440) = 5; /*0x1067bbaca*/
  v13 = (_BYTE *)operator new(a1: 1u); /*0x1067bbad9*/
  *v13 = 1; /*0x1067bbade*/
  std::shared_ptr<bool>::shared_ptr[abi:ne200100]<bool,0>(a1: v106, a2: v13); /*0x1067bbaeb*/
  if ( *(_BYTE *)(a1 + 48) == 0 ) /*0x1067bbaf4*/
  {
    v14 = RBX::ServiceProvider::create<RBX::Visit>(this: (RBX::ServiceProvider *)(*(_QWORD *)(a1 + 24) + 464LL)); /*0x1067bbb0a*/
    std::string::basic_string[abi:ne200100]<0>(a1: v123, a2: "PingUrl", a3: v15, a4: v16); /*0x1067bbb18*/
    RBX::GameConfigurer::getParamString(a1: v108, a2: a1, a3: v123); /*0x1067bbb2b*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v120, a2: "PingInterval", a3: v17, a4: v18); /*0x1067bbb3b*/
    ParamInt = RBX::GameConfigurer::getParamInt(a1, a2: &v120); /*0x1067bbb47*/
    RBX::Visit::setPing(a1: v14, a2: v108, a3: ParamInt); /*0x1067bbb58*/
    if ( (v120 & 1) != 0 ) /*0x1067bbb61*/
      operator delete(a1: v121); /*0x1067bbb67*/
    if ( (v108[0] & 1) != 0 ) /*0x1067bbb73*/
      operator delete(a1: v109); /*0x1067bbb7c*/
    if ( ((__int64)v123[0] & 1) != 0 ) /*0x1067bbb85*/
      operator delete(a1: v124); /*0x1067bbb8b*/
  }
  RBX::Reflection::DescribedBase::fastSharedDynamicCast<RBX::Network::ClientReplicator,RBX::Instance>( /*0x1067bbb9a*/
    a1: &v117[1],
    a2: a3);
  v20 = RBX::Subsystem<RBX::AppQoSInstance,false>::startup<RBX::SubsystemDefaultFactory<RBX::AppQoSInstance>>(); /*0x1067bbba4*/
  v21 = **(_QWORD **)&v117[1]; /*0x1067bbbae*/
  v116 = v20; /*0x1067bbbb5*/
  (*(void (__fastcall **)(__int128 *))(v21 + 1520))(a1: &v120); /*0x1067bbbbc*/
  if ( v20 != 0 ) /*0x1067bbbc5*/
    v22 = *(_QWORD *)(v20 + 24); /*0x1067bbbc7*/
  else
    v22 = 0; /*0x1067bbbcd*/
  if ( (v120 & 1) != 0 ) /*0x1067bbbdc*/
  {
    v23 = (char *)v121; /*0x1067bbbde*/
    v24 = *((_QWORD *)&v120 + 1); /*0x1067bbbe2*/
  }
  else
  {
    v24 = (unsigned __int8)v120 >> 1; /*0x1067bbbe8*/
    v23 = (char *)&v120 + 1; /*0x1067bbbea*/
  }
  RBX::AppQoSInstance::onGameConnected(a1: v22, a2: a3, a3: v23, a4: v24, a5: *(_QWORD *)(a1 + 72)); /*0x1067bbbf4*/
  v25 = (rbx::signals::slots_holder **)(*(_QWORD *)&v117[1] + 11280LL); /*0x1067bbbff*/
  v26 = v120; /*0x1067bbc06*/
  v123[0] = *(std::__shared_weak_count **)((char *)&v120 + 1); /*0x1067bbc13*/
  *(std::__shared_weak_count **)((char *)v123 + 7) = *((std::__shared_weak_count **)&v120 + 1); /*0x1067bbc17*/
  v27 = v121; /*0x1067bbc1b*/
  v120 = 0; /*0x1067bbc23*/
  v121 = nullptr; /*0x1067bbc28*/
  LODWORD(v119) = (_DWORD)RBX::Memory::InstanceSignal; /*0x1067bbc39*/
  v117[0] = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v28); /*0x1067bbc41*/
  rbx::lazyInitSlotsHolder(a1: v25); /*0x1067bbc4a*/
  v30 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x48, a2: v29); /*0x1067bbc59*/
  *(_QWORD *)v30 = &_mh_execute_header; /*0x1067bbc66*/
  *((_QWORD *)v30 + 1) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::onConnectionAccepted(std::string const&,std::shared_ptr<RBX::Instance> const&)::$_0,std::string,bool,std::string,int>::do_call; /*0x1067bbc71*/
  *((_OWORD *)v30 + 1) = 0; /*0x1067bbc7a*/
  v31 = *v25; /*0x1067bbc81*/
  *((_QWORD *)v30 + 4) = *v25; /*0x1067bbc84*/
  if ( v31 != nullptr ) /*0x1067bbc8c*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v31 + 1); /*0x1067bbc8e*/
    v32 = *((_QWORD *)v30 + 3) | 4LL; /*0x1067bbc97*/
  }
  else
  {
    v32 = 4; /*0x1067bbc9d*/
  }
  *((_QWORD *)v30 + 3) = v32; /*0x1067bbca2*/
  *((_QWORD *)v30 + 5) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::onConnectionAccepted(std::string const&,std::shared_ptr<RBX::Instance> const&)::$_0,std::string,bool,std::string,int>::do_dtor; /*0x1067bbcae*/
  *((_BYTE *)v30 + 48) = v26; /*0x1067bbcb3*/
  v33 = *(__int64 *)((char *)v123 + 7); /*0x1067bbcbc*/
  *(std::__shared_weak_count **)((char *)v30 + 49) = v123[0]; /*0x1067bbcc0*/
  *((_QWORD *)v30 + 7) = v33; /*0x1067bbcc5*/
  *((_QWORD *)v30 + 8) = v27; /*0x1067bbcca*/
  *(std::__shared_weak_count **)((char *)v123 + 7) = nullptr; /*0x1067bbcd2*/
  v123[0] = nullptr; /*0x1067bbcd6*/
  rbx::signals::slots_holder::insert(this: *v25, a2: (unsigned __int64)v30); /*0x1067bbce3*/
  v122 = (void *)v30; /*0x1067bbce8*/
  _InterlockedIncrement(v30 + 1); /*0x1067bbcec*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v117[0], a2: v34); /*0x1067bbcf8*/
  v35 = *(void ***)(a1 + 1760); /*0x1067bbd04*/
  if ( (unsigned __int64)v35 >= *(_QWORD *)(a1 + 1768) ) /*0x1067bbd12*/
  {
    v36 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067bbd2f*/
            a1: a1 + 1752,
            a2: &v122);
    v37 = (volatile signed __int32 *)v122; /*0x1067bbd34*/
    *(_QWORD *)(a1 + 1760) = v36; /*0x1067bbd38*/
    if ( v37 != nullptr && _InterlockedDecrement(v37 + 1) == 0 ) /*0x1067bbd48*/
      rbx::signals::slot_base::operator delete(a1: (void *)v37); /*0x1067bbd4a*/
  }
  else
  {
    *v35 = v122; /*0x1067bbd18*/
    *(_QWORD *)(a1 + 1760) = v35 + 1; /*0x1067bbd1f*/
  }
  v38 = *(_QWORD *)&v117[1]; /*0x1067bbd4f*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: v123, a2: a1); /*0x1067bbd5d*/
  v124 = RBX::PlayerConfigurer::onDisconnection; /*0x1067bbd6d*/
  v125 = 0; /*0x1067bbd71*/
  _ZN3rbx6signalIFvNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEbS7_iEE7connectIZN3RBX16PlayerConfigurer11with_lockedIMSC_FvRKS7_bS7_iEEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSJ_( /*0x1067bbd87*/
    a1: &v122,
    a2: v38 + 11280);
  v39 = *(void ***)(a1 + 1760); /*0x1067bbd8c*/
  if ( (unsigned __int64)v39 >= *(_QWORD *)(a1 + 1768) ) /*0x1067bbd9a*/
  {
    v40 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067bbdbf*/
            a1: a1 + 1752,
            a2: &v122);
    v41 = (volatile signed __int32 *)v122; /*0x1067bbdc4*/
    *(_QWORD *)(a1 + 1760) = v40; /*0x1067bbdc8*/
    if ( v41 != nullptr && _InterlockedDecrement(v41 + 1) == 0 ) /*0x1067bbdd8*/
      rbx::signals::slot_base::operator delete(a1: (void *)v41); /*0x1067bbdda*/
  }
  else
  {
    *v39 = v122; /*0x1067bbda0*/
    v122 = nullptr; /*0x1067bbda3*/
    *(_QWORD *)(a1 + 1760) = v39 + 1; /*0x1067bbdaf*/
  }
  if ( v123[1] != nullptr ) /*0x1067bbde6*/
    std::__shared_weak_count::__release_weak(this: v123[1]); /*0x1067bbde8*/
  v42 = *(_QWORD *)&v117[1]; /*0x1067bbded*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: v123, a2: a1); /*0x1067bbdfb*/
  v44 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)v119, a2: v43); /*0x1067bbe08*/
  v45 = (rbx::signals::slots_holder **)(v42 + 11280); /*0x1067bbe0b*/
  rbx::lazyInitSlotsHolder(a1: v45); /*0x1067bbe15*/
  v47 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x40, a2: v46); /*0x1067bbe24*/
  *(_QWORD *)v47 = &_mh_execute_header; /*0x1067bbe31*/
  *((_QWORD *)v47 + 1) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::onConnectionAccepted(std::string const&,std::shared_ptr<RBX::Instance> const&)::$_1,std::string,bool,std::string,int>::do_call; /*0x1067bbe3c*/
  *((_OWORD *)v47 + 1) = 0; /*0x1067bbe45*/
  v48 = *v45; /*0x1067bbe4c*/
  *((_QWORD *)v47 + 4) = *v45; /*0x1067bbe4f*/
  if ( v48 != nullptr ) /*0x1067bbe57*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v48 + 1); /*0x1067bbe59*/
    v49 = *((_QWORD *)v47 + 3) | 4LL; /*0x1067bbe62*/
    v50 = *v45; /*0x1067bbe66*/
  }
  else
  {
    v49 = 4; /*0x1067bbe6b*/
    v50 = nullptr; /*0x1067bbe70*/
  }
  *((_QWORD *)v47 + 3) = v49; /*0x1067bbe72*/
  *((_QWORD *)v47 + 5) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::onConnectionAccepted(std::string const&,std::shared_ptr<RBX::Instance> const&)::$_1,std::string,bool,std::string,int>::do_dtor; /*0x1067bbe7e*/
  *((_OWORD *)v47 + 3) = *(_OWORD *)v123; /*0x1067bbe87*/
  *(_OWORD *)v123 = 0; /*0x1067bbe8d*/
  rbx::signals::slots_holder::insert(this: v50, a2: (unsigned __int64)v47); /*0x1067bbe95*/
  v122 = (void *)v47; /*0x1067bbe9a*/
  _InterlockedIncrement(v47 + 1); /*0x1067bbe9e*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v44, a2: v51); /*0x1067bbea7*/
  v52 = *(void ***)(a1 + 1760); /*0x1067bbeac*/
  if ( (unsigned __int64)v52 >= *(_QWORD *)(a1 + 1768) ) /*0x1067bbeba*/
  {
    v53 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067bbedf*/
            a1: a1 + 1752,
            a2: &v122);
    v54 = (volatile signed __int32 *)v122; /*0x1067bbee4*/
    *(_QWORD *)(a1 + 1760) = v53; /*0x1067bbee8*/
    if ( v54 != nullptr && _InterlockedDecrement(v54 + 1) == 0 ) /*0x1067bbef8*/
      rbx::signals::slot_base::operator delete(a1: (void *)v54); /*0x1067bbefa*/
  }
  else
  {
    *v52 = v122; /*0x1067bbec0*/
    v122 = nullptr; /*0x1067bbec3*/
    *(_QWORD *)(a1 + 1760) = v52 + 1; /*0x1067bbecf*/
  }
  if ( v123[1] != nullptr ) /*0x1067bbf06*/
    std::__shared_weak_count::__release_weak(this: v123[1]); /*0x1067bbf08*/
  v55 = RBX::ServiceProvider::find<RBX::VoiceChatService>(this: (RBX::ServiceProvider *)(*(_QWORD *)(a1 + 24) + 464LL)); /*0x1067bbf18*/
  v56 = *(_QWORD *)&v117[1]; /*0x1067bbf1d*/
  RBX::weak_from<RBX::VoiceChatService>(a1: v123, a2: v55); /*0x1067bbf2b*/
  v58 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)v119, a2: v57); /*0x1067bbf38*/
  v59 = (rbx::signals::slots_holder **)(v56 + 11280); /*0x1067bbf3b*/
  rbx::lazyInitSlotsHolder(a1: v59); /*0x1067bbf45*/
  v61 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x40, a2: v60); /*0x1067bbf54*/
  *(_QWORD *)v61 = &_mh_execute_header; /*0x1067bbf61*/
  *((_QWORD *)v61 + 1) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::onConnectionAccepted(std::string const&,std::shared_ptr<RBX::Instance> const&)::$_2,std::string,bool,std::string,int>::do_call; /*0x1067bbf6c*/
  *((_OWORD *)v61 + 1) = 0; /*0x1067bbf75*/
  v62 = *v59; /*0x1067bbf7c*/
  *((_QWORD *)v61 + 4) = *v59; /*0x1067bbf7f*/
  if ( v62 != nullptr ) /*0x1067bbf87*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v62 + 1); /*0x1067bbf89*/
    v63 = *((_QWORD *)v61 + 3) | 4LL; /*0x1067bbf92*/
    v64 = *v59; /*0x1067bbf96*/
  }
  else
  {
    v63 = 4; /*0x1067bbf9b*/
    v64 = nullptr; /*0x1067bbfa0*/
  }
  *((_QWORD *)v61 + 3) = v63; /*0x1067bbfa2*/
  *((_QWORD *)v61 + 5) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::onConnectionAccepted(std::string const&,std::shared_ptr<RBX::Instance> const&)::$_2,std::string,bool,std::string,int>::do_dtor; /*0x1067bbfae*/
  *((_OWORD *)v61 + 3) = *(_OWORD *)v123; /*0x1067bbfb7*/
  *(_OWORD *)v123 = 0; /*0x1067bbfbd*/
  rbx::signals::slots_holder::insert(this: v64, a2: (unsigned __int64)v61); /*0x1067bbfc5*/
  v122 = (void *)v61; /*0x1067bbfca*/
  _InterlockedIncrement(v61 + 1); /*0x1067bbfce*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v58, a2: v65); /*0x1067bbfd7*/
  v67 = *(void ***)(a1 + 1760); /*0x1067bbfdc*/
  if ( (unsigned __int64)v67 >= *(_QWORD *)(a1 + 1768) ) /*0x1067bbfea*/
  {
    v68 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067bc00f*/
            a1: a1 + 1752,
            a2: &v122);
    v69 = (volatile signed __int32 *)v122; /*0x1067bc014*/
    *(_QWORD *)(a1 + 1760) = v68; /*0x1067bc018*/
    if ( v69 != nullptr && _InterlockedDecrement(v69 + 1) == 0 ) /*0x1067bc028*/
      rbx::signals::slot_base::operator delete(a1: (void *)v69); /*0x1067bc02a*/
  }
  else
  {
    *v67 = v122; /*0x1067bbff0*/
    v122 = nullptr; /*0x1067bbff3*/
    *(_QWORD *)(a1 + 1760) = v67 + 1; /*0x1067bbfff*/
  }
  if ( v123[1] != nullptr ) /*0x1067bc036*/
    std::__shared_weak_count::__release_weak(this: v123[1]); /*0x1067bc038*/
  v70 = (rbx::signals::slots_holder **)(*(_QWORD *)&v117[1] + 11280LL); /*0x1067bc043*/
  v71 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)v119, a2: v66); /*0x1067bc052*/
  rbx::lazyInitSlotsHolder(a1: v70); /*0x1067bc058*/
  v73 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v72); /*0x1067bc067*/
  *(_QWORD *)v73 = &_mh_execute_header; /*0x1067bc074*/
  *(_QWORD *)(v73 + 8) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::onConnectionAccepted(std::string const&,std::shared_ptr<RBX::Instance> const&)::$_3,std::string,bool,std::string,int>::do_call; /*0x1067bc07f*/
  *(_OWORD *)(v73 + 16) = 0; /*0x1067bc088*/
  v74 = *v70; /*0x1067bc08f*/
  *(_QWORD *)(v73 + 32) = *v70; /*0x1067bc092*/
  if ( v74 != nullptr ) /*0x1067bc09a*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v74 + 1); /*0x1067bc09c*/
    v75 = *(_QWORD *)(v73 + 24) & 0xFFFFFFFFFFFFFFFBLL; /*0x1067bc0a5*/
    v76 = *v70; /*0x1067bc0a9*/
  }
  else
  {
    v76 = nullptr; /*0x1067bc0ae*/
    v75 = 0; /*0x1067bc0b0*/
  }
  *(_QWORD *)(v73 + 24) = v75; /*0x1067bc0b2*/
  rbx::signals::slots_holder::insert(this: v76, a2: v73); /*0x1067bc0ba*/
  v123[0] = (std::__shared_weak_count *)v73; /*0x1067bc0bf*/
  _InterlockedIncrement((volatile signed __int32 *)(v73 + 4)); /*0x1067bc0c3*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v71, a2: v77); /*0x1067bc0cc*/
  v78 = *(std::__shared_weak_count ***)(a1 + 1760); /*0x1067bc0d1*/
  v79 = v116; /*0x1067bc0df*/
  if ( (unsigned __int64)v78 >= *(_QWORD *)(a1 + 1768) ) /*0x1067bc0e6*/
  {
    v80 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067bc103*/
            a1: a1 + 1752,
            a2: v123);
    v81 = (volatile signed __int32 *)v123[0]; /*0x1067bc108*/
    *(_QWORD *)(a1 + 1760) = v80; /*0x1067bc10c*/
    if ( v81 != nullptr && _InterlockedDecrement(v81 + 1) == 0 ) /*0x1067bc11c*/
      rbx::signals::slot_base::operator delete(a1: (void *)v81); /*0x1067bc11e*/
  }
  else
  {
    *v78 = v123[0]; /*0x1067bc0ec*/
    *(_QWORD *)(a1 + 1760) = v78 + 1; /*0x1067bc0f3*/
  }
  v82 = *(_QWORD *)&v117[1]; /*0x1067bc123*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: v123, a2: a1); /*0x1067bc131*/
  v124 = RBX::PlayerConfigurer::onReceivedGlobals; /*0x1067bc141*/
  v125 = 0; /*0x1067bc145*/
  _ZN3rbx6signalIFvvEE7connectIZN3RBX16PlayerConfigurer11with_lockedIMS5_FvvEEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSA_( /*0x1067bc15b*/
    a1: &v122,
    a2: v82 + 24432);
  v83 = *(void ***)(a1 + 1760); /*0x1067bc160*/
  if ( (unsigned __int64)v83 >= *(_QWORD *)(a1 + 1768) ) /*0x1067bc16e*/
  {
    v84 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067bc193*/
            a1: a1 + 1752,
            a2: &v122);
    v85 = (volatile signed __int32 *)v122; /*0x1067bc198*/
    *(_QWORD *)(a1 + 1760) = v84; /*0x1067bc19c*/
    if ( v85 != nullptr && _InterlockedDecrement(v85 + 1) == 0 ) /*0x1067bc1ac*/
      rbx::signals::slot_base::operator delete(a1: (void *)v85); /*0x1067bc1ae*/
  }
  else
  {
    *v83 = v122; /*0x1067bc174*/
    v122 = nullptr; /*0x1067bc177*/
    *(_QWORD *)(a1 + 1760) = v83 + 1; /*0x1067bc183*/
  }
  if ( v123[1] != nullptr ) /*0x1067bc1ba*/
    std::__shared_weak_count::__release_weak(this: v123[1]); /*0x1067bc1bc*/
  v86 = *(_QWORD *)&v117[1]; /*0x1067bc1c1*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: v123, a2: a1); /*0x1067bc1cf*/
  v124 = RBX::PlayerConfigurer::onGameLoaded; /*0x1067bc1df*/
  v125 = 0; /*0x1067bc1e3*/
  _ZN3rbx6signalIFvvEE7connectIZN3RBX16PlayerConfigurer11with_lockedIMS5_FvvEEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSA_( /*0x1067bc1f9*/
    a1: &v122,
    a2: v86 + 24440);
  v87 = *(void ***)(a1 + 1760); /*0x1067bc1fe*/
  if ( (unsigned __int64)v87 >= *(_QWORD *)(a1 + 1768) ) /*0x1067bc20c*/
  {
    v88 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067bc231*/
            a1: a1 + 1752,
            a2: &v122);
    v89 = (volatile signed __int32 *)v122; /*0x1067bc236*/
    *(_QWORD *)(a1 + 1760) = v88; /*0x1067bc23a*/
    if ( v89 != nullptr && _InterlockedDecrement(v89 + 1) == 0 ) /*0x1067bc24a*/
      rbx::signals::slot_base::operator delete(a1: (void *)v89); /*0x1067bc24c*/
  }
  else
  {
    *v87 = v122; /*0x1067bc212*/
    v122 = nullptr; /*0x1067bc215*/
    *(_QWORD *)(a1 + 1760) = v87 + 1; /*0x1067bc221*/
  }
  if ( v123[1] != nullptr ) /*0x1067bc258*/
    std::__shared_weak_count::__release_weak(this: v123[1]); /*0x1067bc25a*/
  v90 = *(_QWORD *)&v117[1]; /*0x1067bc25f*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: v123, a2: a1); /*0x1067bc26d*/
  v124 = RBX::PlayerConfigurer::onGameLoadFailed; /*0x1067bc27d*/
  v125 = 0; /*0x1067bc281*/
  _ZN3rbx6signalIFvbEE7connectIZN3RBX16PlayerConfigurer11with_lockedIMS5_FvbEEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSA_( /*0x1067bc297*/
    a1: &v122,
    a2: v90 + 24448);
  v91 = *(void ***)(a1 + 1760); /*0x1067bc29c*/
  if ( (unsigned __int64)v91 >= *(_QWORD *)(a1 + 1768) ) /*0x1067bc2aa*/
  {
    v92 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067bc2cf*/
            a1: a1 + 1752,
            a2: &v122);
    v93 = (volatile signed __int32 *)v122; /*0x1067bc2d4*/
    *(_QWORD *)(a1 + 1760) = v92; /*0x1067bc2d8*/
    if ( v93 != nullptr && _InterlockedDecrement(v93 + 1) == 0 ) /*0x1067bc2e8*/
      rbx::signals::slot_base::operator delete(a1: (void *)v93); /*0x1067bc2ea*/
  }
  else
  {
    *v91 = v122; /*0x1067bc2b0*/
    v122 = nullptr; /*0x1067bc2b3*/
    *(_QWORD *)(a1 + 1760) = v91 + 1; /*0x1067bc2bf*/
  }
  if ( v123[1] != nullptr ) /*0x1067bc2f6*/
    std::__shared_weak_count::__release_weak(this: v123[1]); /*0x1067bc2f8*/
  v94 = RBX::ServiceProvider::find<RBX::ReplicatedFirst>(this: (RBX::ServiceProvider *)(*(_QWORD *)(a1 + 24) + 464LL)); /*0x1067bc30d*/
  if ( v94 != 0 ) /*0x1067bc313*/
  {
    RBX::weak_from<RBX::PlayerConfigurer>(a1: v123, a2: a1); /*0x1067bc31c*/
    v124 = RBX::PlayerConfigurer::onDefaultLoadingScreenRemoved; /*0x1067bc32c*/
    v125 = 0; /*0x1067bc330*/
    _ZN3rbx6signalIFvvEE7connectIZN3RBX16PlayerConfigurer11with_lockedIMS5_FvvEEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSA_( /*0x1067bc346*/
      a1: &v122,
      a2: v94 + 224);
    v95 = *(volatile signed __int32 **)(a1 + 1776); /*0x1067bc34b*/
    *(_QWORD *)(a1 + 1776) = v122; /*0x1067bc356*/
    v122 = (void *)v95; /*0x1067bc35d*/
    if ( v95 != nullptr && _InterlockedDecrement(v95 + 1) == 0 ) /*0x1067bc36a*/
      rbx::signals::slot_base::operator delete(a1: (void *)v95); /*0x1067bc36c*/
    if ( v123[1] != nullptr ) /*0x1067bc378*/
      std::__shared_weak_count::__release_weak(this: v123[1]); /*0x1067bc37a*/
  }
  v98 = RBX::ServiceProvider::find<RBX::TeleportService>(a1: *(_QWORD *)(a1 + 24) + 464LL, a2: 0); /*0x1067bc38f*/
  if ( v98 != 0 ) /*0x1067bc395*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v110, a2: "ClientConnectResult", a3: v96, a4: v97); /*0x1067bc3a9*/
    std::string::basic_string[abi:ne200100]<0>(a1: v112, a2: "Success", a3: v99, a4: v100); /*0x1067bc3bc*/
    std::string::basic_string[abi:ne200100]<0>(a1: v114, a2: "", a3: v101, a4: v102); /*0x1067bc3cf*/
    RBX::TeleportService::logClientGroupTeleportInfluxDB(a1: v98, a2: v110, a3: v112, a4: v114); /*0x1067bc3ec*/
    if ( (v114[0] & 1) != 0 ) /*0x1067bc3f8*/
      operator delete(a1: v115); /*0x1067bc401*/
    if ( (v112[0] & 1) != 0 ) /*0x1067bc40d*/
      operator delete(a1: v113); /*0x1067bc416*/
    if ( (v110[0] & 1) != 0 ) /*0x1067bc422*/
      operator delete(a1: v111); /*0x1067bc42b*/
  }
  if ( (v120 & 1) != 0 ) /*0x1067bc434*/
    operator delete(a1: v121); /*0x1067bc43a*/
  if ( v79 != 0 ) /*0x1067bc442*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v79 + 16LL))(a1: v79); /*0x1067bc44b*/
  v103 = v118; /*0x1067bc44e*/
  if ( v118 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v118 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067bc467*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v103 + 16LL))(a1: v103); /*0x1067bc46f*/
    std::__shared_weak_count::__release_weak(this: v103); /*0x1067bc475*/
  }
  v104 = v107; /*0x1067bc47a*/
  if ( v107 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v107 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067bc496*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v104 + 16LL))(a1: v104); /*0x1067bc49e*/
    std::__shared_weak_count::__release_weak(this: v104); /*0x1067bc4a4*/
  }
  return __stack_chk_guard; /*0x1067bc4b9*/
}

// Address: 0x1067bcac8 | Name: __ZN3RBX16PlayerConfigurer17onReceivedGlobalsEv
__int64 __fastcall RBX::PlayerConfigurer::onReceivedGlobals(RBX::PlayerConfigurer *this)
{
  int v2; // ecx
  int v3; // r8d
  int v4; // r9d
  double v5; // xmm0_8
  __int64 v6; // rax
  __int64 *v7; // rcx
  int v8; // r8d
  int v9; // r9d
  __int64 v10; // r14
  __int64 v11; // r15
  __int64 v12; // rax
  __int64 v13; // rdx
  int v14; // edi
  unsigned int v15; // eax
  _BYTE v17[16]; // [rsp+0h] [rbp-30h] BYREF
  void *v18; // [rsp+10h] [rbp-20h]

  RBX::Time::nowFastSec(this); /*0x1067bcad8*/
  *((double *)this + 28) /* +224: NO 2022 FIELD */ = v5 - *((double *)this + 21) /* +168: NO 2022 FIELD */; /*0x1067bcae5*/
  *((_DWORD *)this + 110) /* +440: NO 2022 FIELD */ = 6; /*0x1067bcaed*/
  if ( (unsigned __int8)FLog::AvatarJoinMetrics >= 6u && BYTE1(FLog::AvatarJoinMetrics) >= 3u ) /*0x1067bcb0c*/
  {
    LOBYTE(v2) = (unsigned __int8)FLog::AvatarJoinMetrics < 6u; /*0x1067bcb07*/
    FLog::FastLogFormatted( /*0x1067bcb23*/
      a1: FLog::AvatarJoinMetrics,
      a2: qword_10D80B698,
      a3: (unsigned int)"[FLog::AvatarJoinMetrics] receivedGlobalsTime = %g",
      a4: v2,
      a5: v3,
      a6: v4);
  }
  v6 = *(_QWORD *)(RBX::ServiceProvider::create<RBX::Network::Client>(this: (RBX::ServiceProvider *)(*((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 464LL)) /*0x1067bcb38*/
                 + 120);
  if ( v6 != 0 ) /*0x1067bcb3f*/
  {
    v7 = *(__int64 **)v6; /*0x1067bcb45*/
    if ( *(_QWORD *)(v6 + 8) != *(_QWORD *)v6 ) /*0x1067bcb4c*/
    {
      v10 = *v7; /*0x1067bcb4e*/
      if ( *v7 != 0 ) /*0x1067bcb54*/
      {
        v11 = *(_QWORD *)(v10 + 24); /*0x1067bcb56*/
        v12 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(); /*0x1067bcb5a*/
        v13 = *(unsigned __int16 *)(v12 + 440); /*0x1067bcb67*/
        v7 = (__int64 *)(*(unsigned __int16 *)(v11 + 440) - (unsigned int)v13); /*0x1067bcb6e*/
        if ( (unsigned int)v7 <= *(unsigned __int16 *)(v12 + 442) ) /*0x1067bcb79*/
        {
          std::string::basic_string[abi:ne200100]<0>(a1: v17, a2: "Total Bytes Received", a3: v13, a4: v7); /*0x1067bcb89*/
          *((double *)this + 48) /* +384: NO 2022 FIELD */ = (*(double (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v10 + 808LL))( /*0x1067bcb9d*/
                                     a1: v10,
                                     a2: v17);
          if ( (v17[0] & 1) != 0 ) /*0x1067bcba9*/
            operator delete(a1: v18); /*0x1067bcbaf*/
          `anonymous namespace'::reportGameLoadResult( /*0x1067bcbc3*/
            this: (_anonymous_namespace_ *)"LoadStarted",
            a2: (const char *)*(unsigned __int8 *)(v10 + 10391));
        }
      }
    }
  }
  if ( FFlag::LogClientLoadToAvatarLoad == 1 ) /*0x1067bcbd2*/
  {
    v14 = FLog::LogStepTimeAndNetworkUsage; /*0x1067bcbdb*/
    v15 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067bcbe0*/
    if ( (unsigned __int8)FLog::LogStepTimeAndNetworkUsage >= 6u && BYTE1(FLog::LogStepTimeAndNetworkUsage) >= 3u ) /*0x1067bcbec*/
    {
      FLog::FastLog( /*0x1067bcc00*/
        a1: *(_QWORD *)&FLog::LogStepTimeAndNetworkUsage,
        a2: qword_10D804018,
        a3: "[FLog::LogStepTimeAndNetworkUsage] Received Globals",
        0);
      v14 = FLog::LogStepTimeAndNetworkUsage; /*0x1067bcc05*/
      v15 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067bcc0a*/
    }
    if ( (unsigned __int8)v14 >= 6u && (unsigned __int8)v15 >= 3u ) /*0x1067bcc16*/
    {
      LOBYTE(v7) = (unsigned __int8)v14 < 6u; /*0x1067bcc11*/
      FLog::FastLogFormatted( /*0x1067bcc2a*/
        a1: v14,
        a2: qword_10D804018,
        a3: (unsigned int)"[FLog::LogStepTimeAndNetworkUsage] 0, 0, 0, 0",
        a4: (_DWORD)v7,
        a5: v8,
        a6: v9);
    }
  }
  return RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bcc4d*/
           this: (RBX::PlayerConfigurer *)((char *)this + 1152 /* +1152: NO 2022 FIELD */),
           a2: "ReceivedGlobalsTime",
           a3: *((double *)this + 28) /* +224: NO 2022 FIELD */);
}

// Address: 0x1067bcc72 | Name: __ZN3RBX16PlayerConfigurer12onGameLoadedEv
__int64 __fastcall RBX::PlayerConfigurer::onGameLoaded(RBX::PlayerConfigurer *this)
{
  double v2; // xmm0_8
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // rax
  RBX::Profiler::RomarkMarkers *v8; // rdi
  int v9; // r8d
  int v10; // r9d
  __int64 v11; // rax
  __int64 *v12; // rcx
  __int64 v13; // r14
  __int64 v14; // r15
  __int64 v15; // rax
  __int64 v16; // rax
  __int64 v17; // rax
  __int64 v18; // r14
  __int64 v19; // rdi
  __int64 v20; // rcx
  unsigned __int64 v21; // rdx
  __int64 v22; // rdx
  __int64 v23; // rcx
  __int64 v24; // rdx
  __int64 v25; // rcx
  __int64 v26; // r8
  __int64 v27; // r9
  int v28; // edi
  unsigned int v29; // eax
  std::__shared_weak_count *v30; // r15
  __int64 v31; // rax
  std::__shared_weak_count *v32; // r15
  __int64 v33; // rax
  _QWORD *v34; // rax
  __int64 v35; // rdx
  __int64 v36; // rcx
  const char *v37; // rsi
  _QWORD *v38; // r14
  const char *v39; // r12
  RBX::RbxDbgInfo *v40; // rdi
  FLog *v41; // r15
  unsigned int v42; // eax
  __int64 v43; // r12
  _QWORD *v44; // r14
  const char *v45; // rcx
  RBX *v46; // rdi
  char *v47; // r14
  std::__shared_weak_count *v48; // r12
  __int64 v49; // rax
  std::__shared_weak_count *v50; // r15
  __int64 v51; // rax
  __int64 v52; // r13
  __int64 v53; // rax
  __int64 v54; // rdi
  __int64 v55; // rax
  std::__shared_weak_count *v56; // r15
  std::__shared_weak_count *v57; // r14
  unsigned int v58; // esi
  unsigned int v59; // r15d
  rbx::signals::slots_holder **v60; // r13
  unsigned __int64 v61; // rsi
  volatile signed __int32 *v62; // rbx
  rbx::signals::slots_holder *v63; // rax
  __int64 v64; // rax
  rbx::signals::slots_holder *v65; // rdi
  unsigned int v66; // esi
  _DWORD v68[12]; // [rsp+0h] [rbp-150h] BYREF
  char v69[8]; // [rsp+30h] [rbp-120h] BYREF
  std::__shared_weak_count *v70; // [rsp+38h] [rbp-118h]
  char v71[8]; // [rsp+40h] [rbp-110h] BYREF
  std::__shared_weak_count *v72; // [rsp+48h] [rbp-108h]
  _BYTE v73[16]; // [rsp+50h] [rbp-100h] BYREF
  void *v74; // [rsp+60h] [rbp-F0h]
  _BYTE v75[16]; // [rsp+68h] [rbp-E8h] BYREF
  void *v76; // [rsp+78h] [rbp-D8h]
  _BYTE v77[16]; // [rsp+80h] [rbp-D0h] BYREF
  void *v78; // [rsp+90h] [rbp-C0h]
  double v79; // [rsp+98h] [rbp-B8h]
  std::__shared_weak_count *v80[2]; // [rsp+A0h] [rbp-B0h] BYREF
  void *v81; // [rsp+B0h] [rbp-A0h]
  _QWORD v82[4]; // [rsp+C0h] [rbp-90h] BYREF
  _QWORD *v83; // [rsp+E0h] [rbp-70h]
  std::__shared_weak_count *v84[4]; // [rsp+F0h] [rbp-60h] BYREF
  std::__shared_weak_count **v85; // [rsp+110h] [rbp-40h]

  if ( this->loadResolved /* +53 */ == 0 )
  {
    this->loadResolved /* +53 */ = 1; /*0x1067bcca1*/
    RBX::Time::nowFastSec(this); /*0x1067bcca5*/
    v79 = v2; /*0x1067bccaa*/
    std::string::basic_string[abi:ne200100]<0>(a1: v84, a2: "GameLoad", a3: v3, a4: v4); /*0x1067bccbd*/
    std::string::basic_string[abi:ne200100]<0>(a1: v80, a2: "Success", a3: v5, a4: v6); /*0x1067bccd0*/
    RBX::PlayerConfigurer::reportDuration( /*0x1067bccf3*/
      a1: (__int64)this,
      a2: (unsigned __int8 *)v84,
      a3: (unsigned __int8 *)v80,
      a4: v79 - *((double *)this + 32) /* +256: NO 2022 FIELD */);
    if ( ((__int64)v80[0] & 1) != 0 ) /*0x1067bccff*/
      operator delete(a1: v81); /*0x1067bcd08*/
    if ( ((__int64)v84[0] & 1) != 0 ) /*0x1067bcd11*/
      operator delete(a1: v84[2]); /*0x1067bcd17*/
    v7 = RBX::ServiceProvider::find<RBX::Network::Client>(a1: *((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 464LL, a2: 0); /*0x1067bcd27*/
    if ( v7 != 0 ) /*0x1067bcd2f*/
    {
      v11 = *(_QWORD *)(v7 + 120); /*0x1067bcd31*/
      if ( v11 != 0 ) /*0x1067bcd38*/
      {
        v12 = *(__int64 **)v11; /*0x1067bcd3a*/
        if ( *(_QWORD *)(v11 + 8) != *(_QWORD *)v11 ) /*0x1067bcd41*/
        {
          v13 = *v12; /*0x1067bcd43*/
          if ( *v12 != 0 ) /*0x1067bcd49*/
          {
            v14 = *(_QWORD *)(v13 + 24); /*0x1067bcd4b*/
            v15 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(); /*0x1067bcd4f*/
            if ( *(unsigned __int16 *)(v14 + 440) - (unsigned int)*(unsigned __int16 *)(v15 + 440) <= *(unsigned __int16 *)(v15 + 442) ) /*0x1067bcd6e*/
              `anonymous namespace'::reportGameLoadResult( /*0x1067bcd7f*/
                this: (_anonymous_namespace_ *)"Success",
                a2: (const char *)*(unsigned __int8 *)(v13 + 10391));
          }
        }
      }
    }
    if ( DFFlag::DebugPerfMode == 1 ) /*0x1067bcd8e*/
    {
      v16 = RBX::Profiler::RomarkMarkers::instance(this: v8); /*0x1067bcd90*/
      RBX::Profiler::RomarkMarkers::endSpan(a1: v16, a2: "gameload", a3: 8); /*0x1067bcda4*/
    }
    if ( DFFlag::DebugEnablePhaseTracking != 0 || DFFlag::DebugEnableClientPhaseTracking == 1 )
    {
      v17 = RBX::Subsystem<RBX::RomarkClientPhaseTracker,false>::startup<RBX::SubsystemDefaultFactory<RBX::RomarkClientPhaseTracker>>(); /*0x1067bcdc1*/
      v18 = v17; /*0x1067bcdc6*/
      v19 = v17 != 0 ? *(_QWORD *)(v17 + 24) : 0LL;
      RBX::RomarkClientPhaseTracker::changeRomarkClientPhase(a1: v19, a2: 3); /*0x1067bcddb*/
      if ( v18 != 0 ) /*0x1067bcde3*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v18 + 16LL))(a1: v18); /*0x1067bcdeb*/
    }
    v20 = *((_QWORD *)this + 9) /* +72 likely userId -- UNVERIFIED */; /*0x1067bcdee*/
    if ( v20 > 0 ) /*0x1067bcdf5*/
    {
      v21 = v20 / 0x3E8uLL; /*0x1067bce0f*/
      v20 %= 0x3E8uLL; /*0x1067bce1a*/
      if ( v20 < DFInt::ClientJoinProcessPositiveSamplesThousandths ) /*0x1067bce2a*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: v73, a2: "client", a3: v21, a4: v20); /*0x1067bce3e*/
        std::string::basic_string[abi:ne200100]<0>(a1: v75, a2: "report", a3: v22, a4: v23); /*0x1067bce51*/
        std::string::basic_string[abi:ne200100]<0>(a1: v77, a2: "GameLoadSucess", a3: v24, a4: v25); /*0x1067bce64*/
        memset(v68, 0, 32); /*0x1067bce79*/
        v68[8] = 1065353216; /*0x1067bce7d*/
        ((void (__fastcall *)(_BYTE *, _BYTE *, _BYTE *, _DWORD *, __int64, __int64))RBX::Analytics::EventIngest::setRBXEvent)( /*0x1067bce99*/
          a1: v73,
          a2: v75,
          a3: v77,
          a4: v68,
          a5: v26,
          a6: v27);
        std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v68); /*0x1067bcea5*/
        if ( (v77[0] & 1) != 0 ) /*0x1067bceb1*/
          operator delete(a1: v78); /*0x1067bceba*/
        if ( (v75[0] & 1) != 0 ) /*0x1067bcec6*/
          operator delete(a1: v76); /*0x1067bcecf*/
        if ( (v73[0] & 1) != 0 ) /*0x1067bcedb*/
          operator delete(a1: v74); /*0x1067bcee4*/
      }
    }
    *((double *)this + 29) /* +232: NO 2022 FIELD */ = v79 - *((double *)this + 21) /* +168: NO 2022 FIELD */; /*0x1067bcef9*/
    *((_DWORD *)this + 110) /* +440: NO 2022 FIELD */ = 7; /*0x1067bcf01*/
    if ( (unsigned __int8)FLog::AvatarJoinMetrics >= 6u && BYTE1(FLog::AvatarJoinMetrics) >= 3u ) /*0x1067bcf20*/
    {
      LOBYTE(v20) = (unsigned __int8)FLog::AvatarJoinMetrics < 6u; /*0x1067bcf1b*/
      FLog::FastLogFormatted( /*0x1067bcf37*/
        a1: FLog::AvatarJoinMetrics,
        a2: qword_10D80B698,
        a3: (unsigned int)"[FLog::AvatarJoinMetrics] gameLoadTime = %g",
        a4: v20,
        a5: v9,
        a6: v10);
    }
    if ( FFlag::LogClientLoadToAvatarLoad == 1 ) /*0x1067bcf46*/
    {
      v28 = FLog::LogStepTimeAndNetworkUsage; /*0x1067bcf4f*/
      v29 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067bcf54*/
      if ( (unsigned __int8)FLog::LogStepTimeAndNetworkUsage >= 6u && BYTE1(FLog::LogStepTimeAndNetworkUsage) >= 3u ) /*0x1067bcf60*/
      {
        FLog::FastLog( /*0x1067bcf74*/
          a1: *(_QWORD *)&FLog::LogStepTimeAndNetworkUsage,
          a2: qword_10D804018,
          a3: "[FLog::LogStepTimeAndNetworkUsage] Game Loaded",
          0);
        v28 = FLog::LogStepTimeAndNetworkUsage; /*0x1067bcf79*/
        v29 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067bcf7e*/
      }
      if ( (unsigned __int8)v28 >= 6u && (unsigned __int8)v29 >= 3u ) /*0x1067bcf8a*/
      {
        LOBYTE(v20) = (unsigned __int8)v28 < 6u; /*0x1067bcf85*/
        FLog::FastLogFormatted( /*0x1067bcf9e*/
          a1: v28,
          a2: qword_10D804018,
          a3: (unsigned int)"[FLog::LogStepTimeAndNetworkUsage] 0, 0, 0, 0",
          a4: v20,
          a5: v9,
          a6: v10);
      }
    }
  }
  this->waitingForCharacter /* +64 */ = 1; /*0x1067bcfa3*/
  v84[0] = (std::__shared_weak_count *)off_10CAAC1D0; /*0x1067bcfb2*/
  v85 = v84; /*0x1067bcfb5*/
  RBX::SimpleTimer::callIn(a1: v69, a2: v84, a3: (double)DFInt::PlayerConfigurerCDNProbeDelayMs / 1000.0); /*0x1067bcfd6*/
  v30 = v70; /*0x1067bcfdb*/
  if ( v70 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v70 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067bcff7*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v30 + 16LL))(a1: v30); /*0x1067bcfff*/
    std::__shared_weak_count::__release_weak(this: v30); /*0x1067bd005*/
  }
  if ( v85 == v84 ) /*0x1067bd011*/
  {
    v31 = 32; /*0x1067bd01f*/
    goto LABEL_43; /*0x1067bd01f*/
  }
  v31 = 40; /*0x1067bd013*/
  if ( v85 != nullptr ) /*0x1067bd01b*/
LABEL_43:
    (*(void (**)(void))((char *)*v85 + v31))(); /*0x1067bd024*/
  if ( DFFlag::PlayerConfigurerRunLMSTest == 1 ) /*0x1067bd031*/
  {
    v84[0] = (std::__shared_weak_count *)off_10CAAC250; /*0x1067bd03e*/
    v85 = v84; /*0x1067bd042*/
    RBX::SimpleTimer::callIn(a1: v71, a2: v84, a3: (double)DFInt::PlayerConfigurerLMSTestDelayMs / 1000.0); /*0x1067bd063*/
    v32 = v72; /*0x1067bd068*/
    if ( v72 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v72 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067bd084*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v32 + 16LL))(a1: v32); /*0x1067bd08c*/
      std::__shared_weak_count::__release_weak(this: v32); /*0x1067bd092*/
    }
    if ( v85 == v84 ) /*0x1067bd09e*/
    {
      v33 = 32; /*0x1067bd0ac*/
      goto LABEL_52; /*0x1067bd0ac*/
    }
    v33 = 40; /*0x1067bd0a0*/
    if ( v85 != nullptr ) /*0x1067bd0a8*/
LABEL_52:
      (*(void (**)(void))((char *)*v85 + v33))(); /*0x1067bd0b1*/
  }
  v34 = (_QWORD *)RBX::ServiceProvider::find<RBX::Players>(a1: *((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 464LL, a2: 0); /*0x1067bd0b7*/
  v38 = v34; /*0x1067bd0c7*/
  if ( v34 != nullptr )
  {
    if ( (v34[24] & 1) != 0 ) /*0x1067bd0db*/
      std::string::__init_copy_ctor_external(a1: v84, a2: v34[26], a3: v34[25]); /*0x1067bd109*/
    else
      qmemcpy(v84, v34 + 24, 24); /*0x1067bd0e8*/
    v39 = (char *)v84 + 1; /*0x1067bd10e*/
    v40 = (RBX::RbxDbgInfo *)((char *)v84 + 1); /*0x1067bd118*/
    if ( ((__int64)v84[0] & 1) != 0 ) /*0x1067bd11b*/
      v40 = v84[2]; /*0x1067bd11d*/
    RBX::RbxDbgInfo::SetServerGitHash(this: v40, a2: v37); /*0x1067bd121*/
    v41 = (FLog *)FLog::Output; /*0x1067bd12d*/
    v42 = (unsigned int)FLog::Output >> 8; /*0x1067bd134*/
    LOBYTE(v35) = (unsigned __int8)FLog::Output < 6u || BYTE1(FLog::Output) < 3u; /*0x1067bd143*/
    if ( (_BYTE)v35 == 0 )
    {
      if ( ((__int64)v84[0] & 1) != 0 ) /*0x1067bd14f*/
        v39 = (const char *)v84[2]; /*0x1067bd151*/
      FLog::FastLogS(
        this: (FLog *)FLog::Output,
        a2: qword_10D7BE938,
        a3: (unsigned __int64)"[FLog::Output] Server RobloxGitHash: %s",
        a4: v39);
      v41 = (FLog *)FLog::Output; /*0x1067bd167*/
      v42 = (unsigned int)FLog::Output >> 8; /*0x1067bd16e*/
    }
    LOBYTE(v36) = (unsigned __int8)v41 < 6u; /*0x1067bd175*/
    if ( (unsigned __int8)v41 >= 6u && (unsigned __int8)v42 >= 3u )
    {
      v43 = qword_10D7BE938; /*0x1067bd185*/
      if ( (v38[27] & 1) != 0 ) /*0x1067bd191*/
      {
        std::string::__init_copy_ctor_external(a1: v80, a2: v38[29], a3: v38[28]); /*0x1067bd1c9*/
      }
      else
      {
        v44 = v38 + 27; /*0x1067bd193*/
        v81 = (void *)v44[2]; /*0x1067bd19e*/
        *(_OWORD *)v80 = *(_OWORD *)v44; /*0x1067bd1aa*/
      }
      v45 = ((__int64)v80[0] & 1) != 0 ? (const char *)v81 : (char *)v80 + 1;
      FLog::FastLogS(this: v41, a2: v43, a3: (unsigned __int64)"[FLog::Output] Server Prefix: %s", a4: v45);
      if ( ((__int64)v80[0] & 1) != 0 ) /*0x1067bd200*/
        operator delete(a1: v81); /*0x1067bd209*/
    }
    if ( ((__int64)v84[0] & 1) != 0 ) /*0x1067bd212*/
      operator delete(a1: v84[2]); /*0x1067bd218*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v84, a2: "PlaceId", a3: v35, a4: v36); /*0x1067bd228*/
  RBX::GameConfigurer::getParamInt64(a1: this, a2: v84); /*0x1067bd234*/
  if ( ((__int64)v84[0] & 1) != 0 ) /*0x1067bd240*/
    operator delete(a1: v84[2]); /*0x1067bd246*/
  if ( *((_BYTE *)this + 80) /* +80 likely userJoinDataOverrides._Mypair._Myval2._Bx -- UNVERIFIED */ == 0 ) /*0x1067bd24f*/
  {
    RBX::SessionAppEventsHandler::instance(this: (RBX::SessionAppEventsHandler *)v80); /*0x1067bd3da*/
    v56 = v80[0]; /*0x1067bd3df*/
    std::to_string(a1: (__int64)v84); /*0x1067bd3ed*/
    RBX::SessionAppEventsHandler::onGameLoaded(a1: v56, a2: v84); /*0x1067bd3f9*/
    if ( ((__int64)v84[0] & 1) != 0 ) /*0x1067bd402*/
      operator delete(a1: v84[2]); /*0x1067bd408*/
    v57 = v80[1]; /*0x1067bd40d*/
    if ( v80[1] != nullptr /*0x1067bd42d*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v80[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v57 + 16LL))(a1: v57); /*0x1067bd439*/
      std::__shared_weak_count::__release_weak(this: v57); /*0x1067bd43f*/
    }
  }
  v47 = (char *)this + 24 /* +24 = .dataModel (RBX::DataModel *, 8B) -- SIZE CONFLICT, see --verify */; /*0x1067bd255*/
  if ( FFlag::EnableLocationRecording == 1 /*0x1067bd288*/
    && (unsigned int)RBX::globalRand(this: v46) % 0x2710 < DFInt::LocationRecordSessionPercentHundredths )
  {
    RBX::make_shared<RBX::DataModelSnapshotJob,RBX::DataModel *&>(a1: v84, a2: (char *)this + 24 /* +24 = .dataModel (RBX::DataModel *, 8B) -- SIZE CONFLICT, see --verify */); /*0x1067bd295*/
    std::shared_ptr<RBX::DataModelSnapshotJob>::operator=[abi:ne200100](a1: (char *)this + 1784 /* +1784: NO 2022 FIELD */, a2: v84); /*0x1067bd2ab*/
    v48 = v84[1]; /*0x1067bd2b0*/
    if ( v84[1] != nullptr /*0x1067bd2cb*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v84[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v48 + 16LL))(a1: v48); /*0x1067bd2d4*/
      std::__shared_weak_count::__release_weak(this: v48); /*0x1067bd2da*/
    }
    v49 = *((_QWORD *)this + 224) /* +1792: NO 2022 FIELD */; /*0x1067bd2df*/
    *(_OWORD *)v84 = *(_OWORD *)((char *)this + 1784 /* +1784: NO 2022 FIELD */); /*0x1067bd2e8*/
    if ( v49 != 0 ) /*0x1067bd2f0*/
      _InterlockedIncrement64((volatile signed __int64 *)(v49 + 8)); /*0x1067bd2f2*/
    RBX::TaskScheduler::add(a1: v84); /*0x1067bd2fb*/
    v50 = v84[1]; /*0x1067bd300*/
    if ( v84[1] != nullptr /*0x1067bd319*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v84[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v50 + 16LL))(a1: v50); /*0x1067bd321*/
      std::__shared_weak_count::__release_weak(this: v50); /*0x1067bd327*/
    }
  }
  if ( FFlag::DebugEnableClientTestService == 1 ) /*0x1067bd333*/
  {
    v51 = RBX::ServiceProvider::find<RBX::ReplicatedFirst>(this: (RBX::ServiceProvider *)(*(_QWORD *)v47 + 464LL)); /*0x1067bd343*/
    v52 = v51; /*0x1067bd348*/
    if ( v51 != 0 ) /*0x1067bd34e*/
    {
      if ( FFlag::FixTestServiceStart == 1 && *(_BYTE *)(v51 + 232) == 1 ) /*0x1067bd369*/
      {
        v53 = *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::TestService>(this: (RBX::ServiceProvider *)(*(_QWORD *)v47 + 464LL)); /*0x1067bd37c*/
        if ( *(_QWORD *)(v53 + 120) != 0 ) /*0x1067bd384*/
        {
          v54 = *(_QWORD *)v47; /*0x1067bd38a*/
          v82[0] = off_10CAAC370; /*0x1067bd39b*/
          v82[1] = v53; /*0x1067bd39e*/
          v83 = v82; /*0x1067bd3a2*/
          RBX::DataModel::submitTask(a1: v54, a2: v82, a3: 1); /*0x1067bd3ae*/
          if ( v83 == v82 ) /*0x1067bd3ba*/
          {
            v55 = 32; /*0x1067bd531*/
          }
          else
          {
            v55 = 40; /*0x1067bd3c0*/
            if ( v83 == nullptr ) /*0x1067bd3c8*/
              goto LABEL_109; /*0x1067bd3c8*/
          }
          (*(void (**)(void))(*v83 + v55))(); /*0x1067bd539*/
        }
      }
      else
      {
        v84[0] = this; /*0x1067bd44d*/
        RBX::weak_from<RBX::PlayerConfigurer>(a1: &v84[1], a2: this); /*0x1067bd458*/
        v59 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v58); /*0x1067bd46b*/
        v60 = (rbx::signals::slots_holder **)(v52 + 224); /*0x1067bd46e*/
        rbx::lazyInitSlotsHolder(a1: v60); /*0x1067bd478*/
        v62 = (volatile signed __int32 *)rbx::signals::slot_base::operator new( /*0x1067bd487*/
                                           this: (rbx::signals::slot_base *)0x48,
                                           a2: v61);
        *(_QWORD *)v62 = &_mh_execute_header; /*0x1067bd494*/
        *((_QWORD *)v62 + 1) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::onGameLoaded(void)::$_3>::do_call; /*0x1067bd49e*/
        *((_OWORD *)v62 + 1) = 0; /*0x1067bd4a6*/
        v63 = *v60; /*0x1067bd4ab*/
        *((_QWORD *)v62 + 4) = *v60; /*0x1067bd4af*/
        if ( v63 != nullptr ) /*0x1067bd4b6*/
        {
          _InterlockedIncrement((volatile signed __int32 *)v63 + 1); /*0x1067bd4b8*/
          v64 = *((_QWORD *)v62 + 3) | 4LL; /*0x1067bd4c0*/
          v65 = *v60; /*0x1067bd4c4*/
        }
        else
        {
          v64 = 4; /*0x1067bd4ca*/
          v65 = nullptr; /*0x1067bd4cf*/
        }
        *((_QWORD *)v62 + 3) = v64; /*0x1067bd4d1*/
        *((_QWORD *)v62 + 5) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::onGameLoaded(void)::$_3>::do_dtor; /*0x1067bd4dc*/
        qmemcpy((void *)(v62 + 12), v84, 24); /*0x1067bd4e4*/
        *(_OWORD *)&v84[1] = 0; /*0x1067bd4f0*/
        rbx::signals::slots_holder::insert(this: v65, a2: (unsigned __int64)v62); /*0x1067bd4f9*/
        _InterlockedIncrement(v62 + 1); /*0x1067bd505*/
        RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v59, a2: v66); /*0x1067bd50d*/
        if ( _InterlockedDecrement(v62 + 1) == 0 ) /*0x1067bd517*/
          rbx::signals::slot_base::operator delete(a1: (void *)v62); /*0x1067bd51c*/
        if ( v84[2] != nullptr ) /*0x1067bd528*/
          std::__shared_weak_count::__release_weak(this: v84[2]); /*0x1067bd52a*/
      }
    }
  }
LABEL_109:
  RBX::ServiceProvider::create<RBX::ModerationService>(this: (RBX::ServiceProvider *)(*(_QWORD *)v47 + 464LL)); /*0x1067bd53c*/
  return __stack_chk_guard; /*0x1067bd55b*/
}

// Address: 0x1067bd784 | Name: __ZN3RBX16PlayerConfigurer16onGameLoadFailedEb
void __fastcall RBX::PlayerConfigurer::onGameLoadFailed(RBX::PlayerConfigurer *this, const char *a2)
{
  `anonymous namespace'::reportGameLoadResult(this: (_anonymous_namespace_ *)"Failure", a2); /*0x1067bd790*/
}

// Address: 0x1067bd81e | Name: __ZN3RBX16PlayerConfigurer29onDefaultLoadingScreenRemovedEv
__int64 __fastcall RBX::PlayerConfigurer::onDefaultLoadingScreenRemoved(RBX::PlayerConfigurer *this)
{
  RBX::Time *v2; // rdi
  double v3; // xmm0_8
  __int64 v4; // rdx
  __int64 v5; // rcx
  float v6; // xmm0_4
  __int64 v7; // rdi
  int v8; // esi
  __int64 v9; // rax
  _QWORD *v10; // rcx
  volatile signed __int64 *v11; // rbx
  unsigned __int64 v12; // rdx
  __int64 v13; // rdx
  __int64 v14; // rcx
  _BYTE v16[16]; // [rsp+18h] [rbp-208h] BYREF
  void *v17; // [rsp+28h] [rbp-1F8h]
  double v18; // [rsp+30h] [rbp-1F0h]
  int v19[4]; // [rsp+38h] [rbp-1E8h] BYREF
  void *v20; // [rsp+48h] [rbp-1D8h]

  rbx::signals::connection::disconnect(this: (RBX::PlayerConfigurer *)((char *)this + 1776 /* +1776: NO 2022 FIELD */)); /*0x1067bd842*/
  RBX::Time::nowFastSec(this: v2); /*0x1067bd847*/
  v18 = v3 - *((double *)this + 32) /* +256: NO 2022 FIELD */; /*0x1067bd854*/
  *((double *)this + 37) /* +296: NO 2022 FIELD */ = v18; /*0x1067bd85c*/
  std::string::basic_string[abi:ne200100]<0>(a1: v19, a2: "DefaultLoadingScreenRemoved_Duration", a3: v4, a4: v5); /*0x1067bd872*/
  v6 = v18 * 1000.0; /*0x1067bd887*/
  RBX::PlayerConfigurer::reportStats(a1: v6, a2: v7, a3: (unsigned __int8 *)v19); /*0x1067bd892*/
  if ( (v19[0] & 1) != 0 ) /*0x1067bd89e*/
    operator delete(a1: v20); /*0x1067bd8a7*/
  if ( (unsigned __int8)RBX::Analytics::InfluxDb::canSend( /*0x1067bd8b9*/
                          this: (RBX::Analytics::InfluxDb *)(unsigned int)DFInt::JoinInfluxHundredthsPercentage,
                          a2: v8) != 0 )
  {
    RBX::Analytics::InfluxDb::Points::Points(a1: v19, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1067bd8cf*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bd8e9*/
      this: (RBX::Analytics::InfluxDb::Points *)v19,
      a2: "Category",
      a3: "DefaultLoadingScreenRemoved");
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bd904*/
      this: (RBX::Analytics::InfluxDb::Points *)v19,
      a2: "Duration",
      a3: *((double *)this + 37) /* +296: NO 2022 FIELD */);
    v9 = RBX::ServiceProvider::find<RBX::ReplicatedFirst>(this: (RBX::ServiceProvider *)(*((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 464LL)); /*0x1067bd914*/
    v10 = *(_QWORD **)(v9 + 120); /*0x1067bd919*/
    v11 = *(volatile signed __int64 **)(v9 + 128); /*0x1067bd924*/
    if ( v11 != nullptr ) /*0x1067bd935*/
      _InterlockedIncrement64(v11 + 1); /*0x1067bd937*/
    if ( v10 != nullptr ) /*0x1067bd93f*/
      v12 = (__int64)(v10[1] - *v10) >> 4; /*0x1067bd948*/
    else
      v12 = 0; /*0x1067bd94e*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bd95e*/
      this: (RBX::Analytics::InfluxDb::Points *)v19,
      a2: "ReplicatedFirstChildrenCount",
      a3: v12);
    std::string::basic_string[abi:ne200100]<0>(a1: v16, a2: "GameDuration", a3: v13, a4: v14); /*0x1067bd971*/
    RBX::Analytics::InfluxDb::Points::report( /*0x1067bd98c*/
      a1: v19,
      a2: v16,
      a3: (unsigned int)DFInt::JoinInfluxHundredthsPercentage,
      a4: 0);
    if ( (v16[0] & 1) != 0 ) /*0x1067bd998*/
      operator delete(a1: v17); /*0x1067bd9a1*/
    if ( v11 != nullptr && _InterlockedExchangeAdd64(v11 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067bd9bb*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v11 + 16))(a1: v11); /*0x1067bd9c3*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v11); /*0x1067bd9c9*/
    }
    RBX::Analytics::InfluxDb::Points::~Points(this: (void **)v19); /*0x1067bd9d5*/
  }
  return __stack_chk_guard; /*0x1067bd9ea*/
}

// Address: 0x1067bda5e | Name: __ZN3RBX16PlayerConfigurer18onConnectionFailedERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEi
__int64 __fastcall RBX::PlayerConfigurer::onConnectionFailed(__int64 a1, __int64 a2, unsigned int a3)
{
  RBX::Network::Client *v5; // rax
  unsigned __int8 ConnectionNetworkPath; // al
  __int64 v7; // rax
  __int64 v8; // rbx
  RBX::AppQoSInstance *v9; // rdi
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // rdx
  __int64 v13; // rcx
  int ParamInt; // eax
  __int64 v15; // rdx
  __int64 v16; // rcx
  const char *v17; // rdx
  RBX::Time *v18; // rdi
  double v19; // xmm0_8
  __int64 v20; // rdx
  __int64 v21; // rcx
  __int64 v22; // rdx
  __int64 v23; // rcx
  __int64 v24; // rdx
  __int64 v25; // rcx
  __int64 v26; // r14
  __int64 v27; // rdx
  __int64 v28; // rcx
  __int64 v29; // rdx
  __int64 v30; // rcx
  _BYTE v32[16]; // [rsp+8h] [rbp-278h] BYREF
  void *v33; // [rsp+18h] [rbp-268h]
  _BYTE v34[16]; // [rsp+20h] [rbp-260h] BYREF
  void *v35; // [rsp+30h] [rbp-250h]
  _BYTE v36[16]; // [rsp+38h] [rbp-248h] BYREF
  void *v37; // [rsp+48h] [rbp-238h]
  _QWORD v38[2]; // [rsp+50h] [rbp-230h] BYREF
  RBX::Time *v39; // [rsp+60h] [rbp-220h]
  char v40; // [rsp+70h] [rbp-210h] BYREF
  char v41; // [rsp+71h] [rbp-20Fh] BYREF
  void *v42; // [rsp+80h] [rbp-200h]
  __int128 v43; // [rsp+88h] [rbp-1F8h] BYREF
  void *v44; // [rsp+98h] [rbp-1E8h]

  v5 = (RBX::Network::Client *)RBX::ServiceProvider::find<RBX::Network::Client>(a1: *(_QWORD *)(a1 + 24) + 464LL, a2: 0); /*0x1067bda8d*/
  if ( v5 != nullptr ) /*0x1067bda95*/
  {
    ConnectionNetworkPath = RBX::Network::Client::getConnectionNetworkPath(this: v5); /*0x1067bdaa6*/
    RBX::Transport::reportConnectionAttemptResult(a1: (a3 == 279) ^ 3u, a2: ConnectionNetworkPath); /*0x1067bdab3*/
  }
  *(_BYTE *)(a1 + 52) = 1; /*0x1067bdab8*/
  v7 = RBX::Subsystem<RBX::AppQoSInstance,false>::startup<RBX::SubsystemDefaultFactory<RBX::AppQoSInstance>>(); /*0x1067bdabd*/
  v8 = v7; /*0x1067bdac2*/
  if ( v7 != 0 ) /*0x1067bdac8*/
    v9 = *(RBX::AppQoSInstance **)(v7 + 24); /*0x1067bdaca*/
  else
    v9 = nullptr; /*0x1067bdad0*/
  RBX::AppQoSInstance::onGameConnectFailed(this: v9, a2: a3); /*0x1067bdad5*/
  if ( FInt::DisconnectInfluxHundredthsPercentage > 0 ) /*0x1067bdae1*/
  {
    RBX::Analytics::InfluxDb::Points::Points(a1: &v43, a2: 0xFFFFFFFFLL, a3: 0, a4: 0); /*0x1067bdaf7*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)&v43, a2: "errorCode", a3); /*0x1067bdb0d*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bdb25*/
      this: (RBX::Analytics::InfluxDb::Points *)&v43,
      a2: "loaded",
      a3: *(_BYTE *)(a1 + 53));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bdb3d*/
      this: (RBX::Analytics::InfluxDb::Points *)&v43,
      a2: "joined",
      a3: *(_BYTE *)(a1 + 54));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bdb55*/
      this: (RBX::Analytics::InfluxDb::Points *)&v43,
      a2: "played",
      a3: *(_BYTE *)(a1 + 55));
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bdb6d*/
      this: (RBX::Analytics::InfluxDb::Points *)&v43,
      a2: "waiting4char",
      a3: *(_BYTE *)(a1 + 64));
    RBX::Analytics::InfluxDb::Points::addPoint(this: (RBX::Analytics::InfluxDb::Points *)&v43, a2: "launchmode", a3: -1); /*0x1067bdb85*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bdb9d*/
      this: (RBX::Analytics::InfluxDb::Points *)&v43,
      a2: "studio2rcc",
      a3: *(_BYTE *)(a1 + 65));
    std::string::basic_string[abi:ne200100]<0>(a1: &v40, a2: "DataCenterId", a3: v12, a4: v13); /*0x1067bdbb0*/
    ParamInt = RBX::GameConfigurer::getParamInt(a1, a2: &v40); /*0x1067bdbbf*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bdbd4*/
      this: (RBX::Analytics::InfluxDb::Points *)&v43,
      a2: "datacenter",
      a3: ParamInt);
    if ( (v40 & 1) != 0 ) /*0x1067bdbe0*/
      operator delete(a1: v42); /*0x1067bdbe9*/
    std::string::basic_string[abi:ne200100]<0>(a1: v38, a2: "MachineAddress", a3: v15, a4: v16); /*0x1067bdbfc*/
    RBX::GameConfigurer::getParamString(a1: &v40, a2: a1, a3: v38); /*0x1067bdc12*/
    if ( (v40 & 1) != 0 ) /*0x1067bdc1e*/
      v17 = (const char *)v42; /*0x1067bdc20*/
    else
      v17 = &v41; /*0x1067bdc29*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bdc3e*/
      this: (RBX::Analytics::InfluxDb::Points *)&v43,
      a2: "remoteaddr",
      a3: v17);
    if ( (v40 & 1) != 0 ) /*0x1067bdc4a*/
      operator delete(a1: v42); /*0x1067bdc53*/
    if ( (v38[0] & 1) != 0 ) /*0x1067bdc5f*/
      operator delete(a1: v39); /*0x1067bdc68*/
    RBX::Time::nowFastSec(this: v18); /*0x1067bdc6d*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067bdc89*/
      this: (RBX::Analytics::InfluxDb::Points *)&v43,
      a2: "duration",
      a3: v19 - *(double *)(a1 + 256));
    std::string::basic_string[abi:ne200100]<0>(a1: &v40, a2: "Disconnect", a3: v20, a4: v21); /*0x1067bdc9c*/
    RBX::Analytics::InfluxDb::Points::report( /*0x1067bdcb7*/
      a1: &v43,
      a2: &v40,
      a3: (unsigned int)FInt::DisconnectInfluxHundredthsPercentage,
      a4: 0);
    if ( (v40 & 1) != 0 ) /*0x1067bdcc3*/
      operator delete(a1: v42); /*0x1067bdccc*/
    RBX::Analytics::InfluxDb::Points::~Points(this: (void **)&v43); /*0x1067bdcd8*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v43, a2: "Failed to connect to the Game.", a3: v10, a4: v11); /*0x1067bdceb*/
  v38[0] = a3; /*0x1067bdcfa*/
  fmt::v8::vformat(a1: &v40, a2: "Code{}", a3: 6, a4: 1, a5: v38); /*0x1067bdd15*/
  std::string::basic_string[abi:ne200100]<0>(a1: v38, a2: "Other", a3: v22, a4: v23); /*0x1067bdd28*/
  RBX::PlayerConfigurer::showErrorWindow(a1, a2: &v43, a3: &v40, a4: (__int64)v38, a5: a3); /*0x1067bdd48*/
  if ( (v38[0] & 1) != 0 ) /*0x1067bdd54*/
    operator delete(a1: v39); /*0x1067bdd5d*/
  v26 = RBX::ServiceProvider::find<RBX::TeleportService>(a1: *(_QWORD *)(a1 + 24) + 464LL, a2: 0); /*0x1067bdd72*/
  if ( v26 != 0 ) /*0x1067bdd78*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v32, a2: "ClientConnectResult", a3: v24, a4: v25); /*0x1067bdd8c*/
    std::string::basic_string[abi:ne200100]<0>(a1: v34, a2: "Failure", a3: v27, a4: v28); /*0x1067bdd9f*/
    std::string::basic_string[abi:ne200100]<0>(a1: v36, a2: "", a3: v29, a4: v30); /*0x1067bddb2*/
    RBX::TeleportService::logClientGroupTeleportInfluxDB(a1: v26, a2: v32, a3: v34, a4: v36); /*0x1067bddcf*/
    if ( (v36[0] & 1) != 0 ) /*0x1067bdddb*/
      operator delete(a1: v37); /*0x1067bdde4*/
    if ( (v34[0] & 1) != 0 ) /*0x1067bddf0*/
      operator delete(a1: v35); /*0x1067bddf9*/
    if ( (v32[0] & 1) != 0 ) /*0x1067bde05*/
      operator delete(a1: v33); /*0x1067bde0e*/
  }
  if ( (v40 & 1) != 0 ) /*0x1067bde1a*/
    operator delete(a1: v42); /*0x1067bde23*/
  if ( (v43 & 1) != 0 ) /*0x1067bde2f*/
    operator delete(a1: v44); /*0x1067bde38*/
  if ( v8 != 0 ) /*0x1067bde40*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x1067bde48*/
  return __stack_chk_guard; /*0x1067bde5b*/
}

// Address: 0x1067be25a | Name: __ZN3RBX16PlayerConfigurer19shouldTimeoutPlayerEd
__int64 __fastcall RBX::PlayerConfigurer::shouldTimeoutPlayer(RBX::PlayerConfigurer *this, double a2)
{
  return 0; /*0x1067be260*/
}

// Address: 0x1067be262 | Name: __ZN3RBX16PlayerConfigurer13onPlayerIdledEd
void __fastcall RBX::PlayerConfigurer::onPlayerIdled(RBX::PlayerConfigurer *this, double a2)
{
  ; /*0x1067be262*/
}

// Address: 0x1067be268 | Name: __ZN3RBX16PlayerConfigurer25getGameLocaleIdFromParamsEv
RBX::PlayerConfigurer *__fastcall RBX::PlayerConfigurer::getGameLocaleIdFromParams(
        RBX::PlayerConfigurer *this,
        __int64 a2,
        __int64 a3,
        __int64 a4)
{
  _BYTE v7[16]; // [rsp+0h] [rbp-30h] BYREF
  void *v8; // [rsp+10h] [rbp-20h]

  std::string::basic_string[abi:ne200100]<0>(a1: v7, a2: "GameLocale", a3, a4); /*0x1067be289*/
  RBX::GameConfigurer::getParamString(a1: this, a2, a3: v7); /*0x1067be297*/
  if ( (v7[0] & 1) != 0 ) /*0x1067be2a0*/
    operator delete(a1: v8); /*0x1067be2a6*/
  return this; /*0x1067be2ae*/
}

// Address: 0x1067be2d4 | Name: __ZN3RBX16PlayerConfigurer9configureENS_8Security10IdentitiesEPNS_9DataModelERKNSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEPK19StartGameStatistics
__int64 __fastcall RBX::PlayerConfigurer::configure(
        _QWORD *a1,
        int a2,
        RBX::DataModel *a3,
        char *a4,
        RBX::Network::Client *a5)
{
  int v7; // ecx
  int v8; // r8d
  int v9; // r9d
  double v10; // xmm0_8
  RBX::Network::Client *v11; // rbx
  double v12; // xmm1_8
  double v13; // xmm0_8
  char *v14; // r14
  RBX::Network::Client *v15; // r15
  double v16; // xmm1_8
  double v17; // xmm0_8
  RBX::Network::Client *v18; // rax
  double v19; // xmm1_8
  unsigned int v20; // eax
  __int64 v21; // rax
  const char *v22; // rdx
  RBX::AvatarLoadMetrics *v23; // rbx
  char *v24; // rbx
  int v25; // ecx
  RBX::Object *v26; // rsi
  int v27; // r8d
  int v28; // r9d
  __int64 v29; // rdi
  unsigned int v30; // eax
  RBX::DataModel *v31; // rcx
  __int64 v32; // rsi
  __int64 v33; // rax
  RBX::AvatarLoadEvents *v34; // r13
  rbx::signals::slots_holder **v35; // r15
  unsigned int v36; // r14d
  unsigned int v37; // esi
  unsigned int v38; // ebx
  unsigned __int64 v39; // rsi
  unsigned __int64 v40; // r12
  rbx::signals::slots_holder *v41; // rax
  __int64 v42; // rax
  rbx::signals::slots_holder *v43; // rdi
  unsigned int v44; // esi
  RBX::Object *v45; // rsi
  __int64 v46; // r15
  unsigned int v47; // esi
  unsigned int v48; // ebx
  rbx::signals::slots_holder **v49; // r15
  unsigned __int64 v50; // rsi
  unsigned __int64 v51; // r12
  rbx::signals::slots_holder *v52; // rax
  __int64 v53; // rax
  rbx::signals::slots_holder *v54; // rdi
  unsigned int v55; // esi
  RBX::Object *v56; // rsi
  __int64 v57; // r15
  unsigned int v58; // esi
  unsigned int v59; // ebx
  rbx::signals::slots_holder **v60; // r15
  unsigned __int64 v61; // rsi
  unsigned __int64 v62; // r12
  rbx::signals::slots_holder *v63; // rax
  __int64 v64; // rax
  rbx::signals::slots_holder *v65; // rdi
  unsigned int v66; // esi
  RBX::Object *v67; // rsi
  __int64 v68; // r15
  unsigned int v69; // esi
  unsigned int v70; // ebx
  rbx::signals::slots_holder **v71; // r15
  unsigned __int64 v72; // rsi
  unsigned __int64 v73; // r12
  rbx::signals::slots_holder *v74; // rax
  __int64 v75; // rax
  rbx::signals::slots_holder *v76; // rdi
  unsigned int v77; // esi
  unsigned int v78; // esi
  void *v79; // rdi
  unsigned int v80; // ebx
  rbx::signals::slots_holder **v81; // r14
  unsigned __int64 v82; // rsi
  unsigned __int64 v83; // r15
  rbx::signals::slots_holder *v84; // rax
  unsigned __int64 v85; // rax
  unsigned int v86; // esi
  std::__shared_weak_count *v87; // rdi
  __int64 v88; // rdx
  char *v89; // rcx
  unsigned int v90; // eax
  __int64 v91; // rax
  __int64 v92; // rdx
  __int64 v93; // rcx
  __int64 v94; // rdx
  __int64 v95; // rcx
  __int64 v96; // rdx
  __int64 v97; // rcx
  char *v98; // rbx
  __int64 v99; // rdx
  __int64 v100; // rcx
  RBX::Security::KeyRing *v101; // rdi
  __int64 v102; // rax
  __int64 v103; // rbx
  void **v104; // rax
  __int64 v105; // rbx
  RBX::json::Value *Instance; // r15
  __int64 v107; // rax
  __int64 v108; // rax
  __int64 v109; // rdx
  __int64 v110; // rcx
  __int64 v111; // rcx
  __int64 v112; // rdx
  char *v113; // rsi
  char v114; // al
  const char *v115; // rdx
  __int64 v116; // rdi
  __int64 v117; // rdx
  __int64 v118; // rcx
  const char *v119; // rdx
  char v120; // al
  const char *v121; // rdx
  __int64 v122; // rdi
  __int64 v123; // rax
  size_t v124; // rax
  char *v125; // rcx
  void *v126; // rdx
  char *v127; // rsi
  __int64 v128; // rdx
  std::__shared_weak_count *v129; // rbx
  __int64 v130; // rdx
  __int64 v131; // rcx
  __int64 v132; // rdx
  __int64 v133; // rcx
  unsigned int ParamInt; // eax
  char *v135; // rbx
  _QWORD *v136; // rax
  __int64 v137; // rdi
  bool v138; // r9
  __int64 v139; // rdx
  __int64 v140; // rcx
  __int64 v141; // rdx
  __int64 v142; // rcx
  bool v143; // zf
  char *v144; // rax
  RBX::TeleportService *v145; // rax
  __int64 v146; // rdx
  __int64 v147; // rcx
  RBX::TeleportService *v148; // rbx
  __int64 v149; // rax
  __int64 v150; // r14
  RBX::SessionTransitionFSM *v151; // rdi
  size_t v152; // r15
  size_t v153; // r14
  unsigned __int8 v154; // bl
  RBX::ClientSessionTracker::ClientSessionTrackerContext *v155; // rdi
  __int64 v156; // rax
  std::__shared_weak_count *v157; // rbx
  std::__shared_weak_count *v158; // rbx
  char *v159; // r14
  RBX::UniverseConfigurator *v160; // rbx
  RBX::DataModel *ParamInt64; // r15
  __int64 v162; // rdx
  __int64 v163; // rcx
  FLog *v164; // r14
  __int64 v165; // rdx
  __int64 v166; // rcx
  unsigned int v167; // eax
  int v168; // r8d
  __int64 v169; // rdx
  __int64 v170; // rcx
  char *v171; // r14
  RBX::DataModelPlaceVersion *v172; // rbx
  unsigned int v173; // eax
  int v174; // edx
  __int64 v175; // rdx
  __int64 v176; // rcx
  __int64 v177; // rax
  int v178; // r8d
  int v179; // r9d
  _BYTE *v180; // rcx
  __int64 v181; // rdx
  __int64 v182; // rcx
  __int64 v183; // rax
  char TouchEnabled; // al
  RBX::TeleportService *v185; // rax
  __int64 v186; // rdx
  int v187; // ebx
  __int64 v188; // rcx
  int v189; // r15d
  __int64 v190; // rdx
  __int64 v191; // rcx
  char *v192; // r12
  int v193; // r14d
  __int64 v194; // rdx
  __int64 v195; // rcx
  char *v196; // r9
  RBX::Network::Client *v197; // rbx
  __int64 v198; // rax
  __int64 v199; // rdx
  __int64 v200; // rcx
  __int64 v201; // rdx
  __int64 v202; // rcx
  __int64 v203; // rdx
  __int64 v204; // rcx
  __int64 v205; // rdx
  __int64 v206; // rcx
  RBX::Time *v207; // rdi
  int v208; // eax
  __int64 v209; // rdx
  __int64 v210; // rcx
  __int64 v211; // rdx
  __int64 v212; // rcx
  __int64 i; // rbx
  __int64 v214; // rdx
  __int64 v215; // rcx
  __int64 v216; // rdx
  __int64 v217; // rcx
  __int64 v218; // rdx
  __int64 v219; // rcx
  __int64 v220; // rdx
  __int64 v221; // rcx
  __int64 v222; // r8
  __int64 v223; // r9
  _QWORD *v224; // rbx
  size_t v225; // r13
  char *v226; // r12
  char *v227; // rsi
  char *v228; // rsi
  __int64 v229; // rdx
  __int64 v230; // rax
  __int64 v231; // rax
  RBX::Time *v232; // rsi
  __int64 v233; // rdx
  char v234; // al
  char *v235; // rcx
  __int64 v236; // rdx
  __int64 v237; // rcx
  __int64 v238; // rax
  char *v239; // rcx
  std::__shared_weak_count *v240; // r8
  __int64 v241; // rax
  __int64 v242; // rdx
  __int64 v243; // rcx
  __int64 v244; // rdx
  __int64 v245; // rcx
  __int64 v246; // rdx
  __int64 v247; // rcx
  __int64 j; // rbx
  __int64 v249; // rdx
  __int64 v250; // rcx
  __int64 v251; // rdx
  __int64 v252; // rcx
  char v253; // bl
  __int64 v254; // rax
  std::__shared_weak_count *v255; // rbx
  __int64 v256; // rdx
  __int64 v257; // rcx
  __int64 v258; // rdx
  __int64 v259; // rcx
  __int64 v260; // rdx
  __int64 v261; // rcx
  std::__shared_weak_count *v262; // rbx
  char *v263; // rcx
  std::__shared_weak_count *v264; // r8
  _BYTE *v265; // rcx
  __int64 v266; // r8
  char *v267; // rdx
  __int64 v268; // rdx
  __int64 v269; // rcx
  std::__shared_weak_count *v270; // rbx
  std::__shared_weak_count *v271; // rbx
  char ParamBool; // bl
  __int64 v273; // rdx
  __int64 v274; // rcx
  __int64 v275; // rax
  char *v276; // rcx
  std::__shared_weak_count *v277; // r8
  char *v278; // rcx
  std::__shared_weak_count *v279; // r8
  _BYTE *v280; // rcx
  __int64 v281; // r8
  char *v282; // rdx
  __int64 v283; // rdx
  __int64 v284; // rcx
  std::__shared_weak_count *v285; // rbx
  std::__shared_weak_count *v286; // rbx
  char v287; // bl
  char *v288; // rsi
  std::__shared_weak_count *v289; // rbx
  __int64 v290; // rdx
  __int64 v291; // rcx
  __int64 v292; // rax
  __int64 v293; // rdx
  __int64 v294; // rcx
  __int64 v295; // rax
  __int64 v296; // rdx
  __int64 v297; // rcx
  __int64 v298; // rax
  std::__shared_weak_count *v299; // rbx
  __int64 v300; // rbx
  char *v301; // rdx
  char *v302; // r12
  std::__shared_weak_count **v303; // rax
  __int64 v304; // rax
  volatile signed __int32 *v305; // rdi
  RBX::ChangeHistoryService *v306; // rax
  RBX::VoiceChat *v307; // rax
  bool v308; // dl
  RBX::Reflection::EnumDescriptor *v309; // rbx
  __int64 v310; // rdx
  __int64 v311; // rcx
  RBX::Name *v312; // rsi
  __int64 v313; // rdx
  __int64 v314; // rcx
  char *v315; // r14
  __int64 v316; // rbx
  __int64 v317; // rax
  __int64 v318; // r13
  RBX::Reflection::EnumDescriptor *v319; // rbx
  __int64 v320; // rdx
  __int64 v321; // rcx
  RBX::Name *v322; // rsi
  __int64 v323; // rdx
  __int64 v324; // rcx
  __int64 v325; // rdx
  __int64 v326; // rcx
  __int64 v327; // rcx
  RBX::ServiceProvider *v328; // r14
  char *v329; // rdx
  std::__shared_weak_count **v330; // rax
  __int64 v331; // rax
  volatile signed __int32 *v332; // rdi
  char *v333; // rdx
  std::__shared_weak_count **v334; // rax
  char *v335; // rcx
  __int64 v336; // rax
  volatile signed __int32 *v337; // rdi
  std::__shared_weak_count **v338; // rax
  __int64 v339; // rax
  volatile signed __int32 *v340; // rdi
  __int64 v341; // rdx
  __int64 v342; // rcx
  __int64 v343; // rdx
  __int64 v344; // rcx
  __int64 v345; // rcx
  __int64 v346; // rdx
  __int64 v347; // rcx
  char *v348; // rdx
  void **v349; // rax
  char *v350; // rcx
  __int64 v351; // rax
  volatile signed __int32 *v352; // rdi
  __int64 v353; // rdx
  __int64 v354; // rcx
  __int64 v355; // rbx
  unsigned __int8 *v356; // rbx
  __int64 v357; // rdi
  RBX::TeleportService *v358; // rax
  __int64 v359; // rdx
  __int64 v360; // rcx
  RBX::TeleportService *v361; // rbx
  __int64 v362; // rdx
  __int64 v363; // rcx
  unsigned __int8 *v364; // r15
  __int64 v365; // rdi
  __int64 v366; // rdx
  __int64 v367; // rcx
  unsigned __int8 *v368; // rbx
  __int64 v369; // rdi
  __int64 v370; // rdx
  __int64 v371; // rcx
  unsigned __int8 *v372; // rbx
  __int64 v373; // rdx
  __int64 v374; // rcx
  __int64 v375; // rdi
  __int64 v376; // rsi
  __int64 v377; // rdx
  __int64 v378; // rcx
  __int64 v379; // rdx
  __int64 v380; // rcx
  unsigned __int8 *v381; // rbx
  __int64 v382; // rdx
  __int64 v383; // rcx
  __int64 v384; // rdi
  __int64 v385; // rsi
  __int64 v386; // rdx
  __int64 v387; // rcx
  __int64 v388; // rdx
  __int64 v389; // rcx
  unsigned __int8 *v390; // rbx
  __int64 v391; // rdi
  __int64 v392; // rdx
  __int64 v393; // rcx
  __int64 v394; // rdx
  __int64 v395; // rcx
  unsigned __int8 *v396; // rbx
  __int64 v397; // rdx
  __int64 v398; // rcx
  __int64 v399; // rdi
  __int64 v400; // rsi
  bool v401; // bl
  __int64 v402; // rdx
  __int64 v403; // rcx
  unsigned __int8 *v404; // rbx
  __int64 v405; // rdx
  __int64 v406; // rcx
  __int64 v407; // rdi
  __int64 v408; // rsi
  __int64 v409; // rdx
  __int64 v410; // rcx
  __int64 v411; // rdx
  __int64 v412; // rcx
  unsigned __int8 *v413; // rbx
  __int64 v414; // rdi
  __int64 v415; // rdx
  __int64 v416; // rcx
  __int64 v417; // rdx
  __int64 v418; // rcx
  unsigned __int8 *v419; // rbx
  __int64 v420; // rdx
  __int64 v421; // rcx
  __int64 v422; // rdi
  __int64 v423; // rsi
  __int64 v424; // rdx
  __int64 v425; // rcx
  __int64 v426; // rdx
  __int64 v427; // rcx
  unsigned __int8 *v428; // rbx
  __int64 v429; // rdi
  __int64 v430; // rdx
  __int64 v431; // rcx
  __int64 v432; // rdx
  __int64 v433; // rcx
  unsigned __int8 *v434; // rbx
  __int64 v435; // rdx
  __int64 v436; // rcx
  __int64 v437; // rdi
  __int64 v438; // rsi
  __int64 v439; // rdx
  __int64 v440; // rcx
  unsigned __int8 *v441; // rbx
  __int64 v442; // rdi
  __int64 v443; // rdx
  __int64 v444; // rcx
  __int64 v445; // rdx
  __int64 v446; // rcx
  unsigned __int8 *v447; // rbx
  __int64 v448; // rdi
  __int64 v449; // rdx
  __int64 v450; // rcx
  __int64 v451; // rdx
  __int64 v452; // rcx
  unsigned __int8 *v453; // rbx
  __int64 v454; // rdi
  __int64 v455; // rdx
  __int64 v456; // rcx
  unsigned __int8 *v457; // rbx
  __int64 v458; // rdi
  __int64 v459; // rdx
  __int64 v460; // rcx
  __int64 v461; // rdx
  __int64 v462; // rcx
  unsigned __int8 *v463; // rbx
  __int64 v464; // rdx
  __int64 v465; // rcx
  __int64 v466; // rdi
  __int64 v467; // rsi
  char v468; // bl
  __int64 v469; // rdi
  RBX::ExperienceStateCapture::ExperienceStateRecordingService *v470; // rbx
  __int64 v471; // rax
  RBX::ServiceProvider *v472; // rsi
  __int64 v473; // rax
  RBX::ServiceProvider *v474; // rsi
  RBX::CoreGlobalBasicSettings *v475; // rdi
  __int64 v476; // rbx
  __int64 v477; // rdx
  __int64 v478; // rcx
  unsigned __int8 *v479; // r15
  __int64 v480; // rdx
  __int64 v481; // rcx
  __int64 v482; // rdi
  __int64 v483; // rsi
  __int64 v484; // rdx
  __int64 v485; // rcx
  unsigned __int8 *v486; // rbx
  __int64 v487; // rdx
  __int64 v488; // rcx
  __int64 v489; // rdi
  __int64 v490; // rsi
  __int64 v491; // rdx
  __int64 v492; // rcx
  __int64 v493; // rdx
  __int64 v494; // rcx
  __int64 v495; // rdx
  __int64 v496; // rcx
  __int64 v497; // rdx
  __int64 v498; // rcx
  __int64 v499; // rdx
  __int64 v500; // rcx
  std::__shared_weak_count *v501; // rax
  __int64 v502; // rdx
  __int64 v503; // rcx
  std::__shared_weak_count *v504; // rax
  __int64 v505; // rdx
  __int64 v506; // rcx
  RBX::LocalizationService *v507; // rax
  RBX::Localization::TranslationLocaleId *v508; // rax
  __int64 v509; // rax
  __int64 v510; // rax
  __int64 v511; // rdx
  __int64 v512; // rcx
  RBX::LocalizationService *v513; // r15
  char v514; // al
  __int64 v515; // rdx
  __int64 v516; // rcx
  std::__shared_weak_count *v517; // rbx
  std::__shared_weak_count *v518; // rax
  RBX::Localization::TranslationLocaleId *TranslationLocaleId; // rax
  __int64 UGCLocaleId; // rax
  __int64 v521; // rax
  unsigned __int8 *v522; // rbx
  __int64 v523; // rdx
  __int64 v524; // rcx
  __int64 v525; // rdi
  __int64 v526; // rsi
  __int64 v527; // rdx
  __int64 v528; // rcx
  unsigned __int8 *v529; // rbx
  __int64 v530; // rdx
  __int64 v531; // rcx
  __int64 v532; // rdi
  __int64 v533; // rsi
  __int64 v534; // rdx
  __int64 v535; // rcx
  RBX::ThirdPartyUserService *v536; // rdi
  __int64 v537; // rdx
  __int64 v538; // rcx
  RBX::LocalizationService *v539; // rbx
  char v540; // al
  __int64 v541; // rdx
  __int64 v542; // rcx
  std::__shared_weak_count *v543; // rbx
  unsigned __int8 *v544; // rbx
  __int64 v545; // rdx
  __int64 v546; // rcx
  __int64 v547; // rdi
  __int64 v548; // rsi
  __int64 v549; // rdx
  __int64 v550; // rcx
  unsigned __int8 *v551; // rbx
  __int64 v552; // rdx
  __int64 v553; // rcx
  __int64 v554; // rdi
  __int64 v555; // rsi
  __int64 v556; // rdx
  __int64 v557; // rcx
  __int64 v558; // rbx
  unsigned __int8 *v559; // r15
  __int64 v560; // rdx
  __int64 v561; // rcx
  __int64 v562; // rdi
  __int64 v563; // rsi
  __int64 v564; // rbx
  int v565; // eax
  __int64 v566; // rdx
  __int64 v567; // rcx
  unsigned __int8 *v568; // rbx
  __int64 v569; // rdx
  __int64 v570; // rcx
  __int64 v571; // rdi
  __int64 v572; // rsi
  __int64 v573; // rdx
  __int64 v574; // rcx
  unsigned __int8 *v575; // rbx
  __int64 v576; // rdi
  __int64 v577; // rdx
  __int64 v578; // rcx
  unsigned __int8 *v579; // rbx
  __int64 v580; // rdi
  __int64 v581; // rdx
  __int64 v582; // rcx
  __int64 v583; // rdx
  __int64 v584; // rcx
  unsigned __int8 *v585; // rbx
  __int64 v586; // rdx
  __int64 v587; // rcx
  __int64 v588; // rdi
  __int64 v589; // rsi
  __int64 v590; // rdx
  __int64 v591; // rcx
  __int64 v592; // rdx
  __int64 v593; // rcx
  unsigned __int8 *v594; // rbx
  __int64 v595; // rdi
  __int64 v596; // rdx
  __int64 v597; // rcx
  unsigned __int8 *v598; // rbx
  __int64 v599; // rdx
  __int64 v600; // rcx
  __int64 v601; // rdi
  __int64 v602; // rsi
  __int64 v603; // rdx
  __int64 v604; // rcx
  unsigned __int8 *v605; // rbx
  __int64 v606; // rdi
  __int64 v607; // rdx
  __int64 v608; // rcx
  unsigned __int8 *v609; // rbx
  __int64 v610; // rdx
  __int64 v611; // rcx
  __int64 v612; // rdi
  __int64 v613; // rsi
  RBX::Http *v614; // rdi
  __int64 UserAgent; // rbx
  __int64 v616; // rdx
  __int64 v617; // rcx
  unsigned __int8 *v618; // r14
  __int64 v619; // rdx
  __int64 v620; // rcx
  __int64 v621; // rdi
  __int64 v622; // rsi
  __int64 v623; // rdx
  __int64 v624; // rcx
  unsigned __int8 *v625; // rbx
  __int64 v626; // rdx
  __int64 v627; // rcx
  __int64 v628; // rdi
  __int64 v629; // rsi
  __int64 v630; // rdx
  __int64 v631; // rcx
  unsigned __int8 *v632; // rbx
  __int64 v633; // rdx
  __int64 v634; // rcx
  __int64 v635; // rdi
  __int64 v636; // rsi
  __int64 v637; // rdx
  __int64 v638; // rcx
  unsigned __int8 *v639; // rbx
  __int64 v640; // rdx
  __int64 v641; // rcx
  __int64 v642; // rdi
  __int64 v643; // rsi
  RBX *v644; // rdi
  __int64 RobloxChannelName; // rbx
  __int64 v646; // rdx
  __int64 v647; // rcx
  unsigned __int8 *v648; // r14
  __int64 v649; // rdx
  __int64 v650; // rcx
  __int64 v651; // rdi
  __int64 v652; // rsi
  RBX::SystemUtil *v653; // rdi
  __int64 v654; // rdx
  __int64 v655; // rcx
  unsigned __int8 *v656; // rbx
  __int64 v657; // rdi
  __int64 v658; // rdx
  __int64 v659; // rcx
  __int64 v660; // rdx
  __int64 v661; // rcx
  char isParamExist; // bl
  __int64 v663; // rdx
  __int64 v664; // rcx
  unsigned __int8 *v665; // rbx
  __int64 v666; // rdx
  __int64 v667; // rcx
  __int64 v668; // rdi
  __int64 v669; // rsi
  __int64 v670; // rdx
  __int64 v671; // rcx
  RBX::RbxDbgInfo *v672; // rdi
  __int64 v673; // rdx
  __int64 v674; // rcx
  unsigned __int8 *v675; // rbx
  __int64 v676; // rdx
  __int64 v677; // rcx
  __int64 v678; // rdi
  __int64 v679; // rsi
  char v680; // bl
  __int64 v681; // rdx
  __int64 v682; // rcx
  unsigned __int8 *v683; // rbx
  __int64 v684; // rdx
  __int64 v685; // rcx
  __int64 v686; // rdi
  __int64 v687; // rsi
  __int64 v688; // rdx
  __int64 v689; // rcx
  RBX::RbxDbgInfo *v690; // rdi
  __int64 v691; // rdx
  __int64 v692; // rcx
  unsigned __int8 *v693; // rbx
  __int64 v694; // rdx
  __int64 v695; // rcx
  __int64 v696; // rdi
  __int64 v697; // rsi
  __int64 v698; // rdx
  __int64 v699; // rcx
  unsigned __int8 *v700; // rbx
  __int64 v701; // rdx
  __int64 v702; // rcx
  __int64 v703; // rdi
  __int64 v704; // rsi
  __int64 v705; // rdx
  __int64 v706; // rcx
  char v707; // bl
  __int64 v708; // rdx
  __int64 v709; // rcx
  unsigned __int8 *v710; // rbx
  __int64 v711; // rdx
  __int64 v712; // rcx
  __int64 v713; // rdi
  __int64 v714; // rsi
  char v715; // bl
  __int64 v716; // rdx
  __int64 v717; // rcx
  unsigned __int8 *v718; // rbx
  __int64 v719; // rdx
  __int64 v720; // rcx
  __int64 v721; // rdi
  __int64 v722; // rsi
  __int64 v723; // rdx
  __int64 v724; // rcx
  unsigned __int8 *v725; // rbx
  __int64 v726; // rdi
  __int64 v727; // rdx
  __int64 v728; // rcx
  __int64 v729; // rdx
  __int64 v730; // rcx
  unsigned __int8 *v731; // rbx
  __int64 v732; // rdx
  __int64 v733; // rcx
  __int64 v734; // rdi
  __int64 v735; // rsi
  __int64 v736; // rdx
  __int64 v737; // rcx
  __int64 v738; // rdx
  __int64 v739; // rcx
  unsigned __int8 *v740; // rbx
  __int64 v741; // rdi
  RBX::TeleportService *v742; // rax
  __int64 v743; // rdx
  __int64 v744; // rcx
  __int64 RawJoinData; // rax
  __int64 v746; // rdx
  void *v747; // rcx
  __int64 v748; // rdx
  __int64 v749; // rcx
  unsigned __int8 *v750; // rbx
  __int64 v751; // rdx
  void *v752; // rdi
  unsigned __int8 *v753; // rbx
  void *v754; // rcx
  unsigned __int8 *v755; // rbx
  __int64 v756; // rdx
  void *v757; // rcx
  unsigned __int8 *v758; // rbx
  __int64 v759; // rdx
  __int64 v760; // rcx
  unsigned __int8 *v761; // rbx
  __int64 v762; // rdi
  __int64 v763; // rax
  char *v764; // rsi
  __int64 v765; // rax
  __int64 v766; // rax
  size_t v767; // rcx
  unsigned __int8 *v768; // rbx
  __int64 v769; // rdx
  __int64 v770; // rcx
  __int64 v771; // rdi
  __int64 v772; // rsi
  __int64 v773; // rdx
  __int64 v774; // rcx
  unsigned __int8 *v775; // rbx
  __int64 v776; // rdi
  __int64 v777; // rdx
  __int64 v778; // rcx
  __int64 v779; // rdx
  __int64 v780; // rcx
  RBX::TeleportService *v781; // rax
  __int64 v782; // rdx
  __int64 v783; // rcx
  RBX::TeleportService *v784; // rbx
  __int64 v785; // rdx
  __int64 v786; // rcx
  RBX::AppQoSInstance *v787; // rdi
  __int64 v788; // rdi
  RBX::PlayerHydrationService *v789; // rdi
  __int64 v790; // rdx
  __int64 v791; // rcx
  __int64 v792; // rdx
  __int64 v793; // rcx
  __int64 v794; // rdx
  __int64 v795; // rcx
  __int64 v796; // rdx
  __int64 v797; // rcx
  char v798; // r13
  char *v799; // rdi
  __int64 v800; // rsi
  char *v801; // rdx
  __int64 v802; // rcx
  __int64 v803; // rdx
  __int64 v804; // rcx
  __int64 v805; // rdx
  __int64 v806; // rcx
  const char *v807; // rsi
  RBX::RbxDbgInfo *v808; // rdi
  unsigned int v809; // ebx
  int v810; // esi
  char *v811; // rdi
  __int64 v812; // rsi
  __int64 v813; // rdx
  __int64 v814; // rcx
  __int64 v815; // rdx
  __int64 v816; // rcx
  int v817; // ebx
  __int64 v818; // rdx
  unsigned __int8 v819; // al
  __int64 v820; // rcx
  __int64 v821; // rcx
  __int64 v822; // rax
  bool v823; // cl
  __int64 v824; // rdx
  bool v825; // dl
  char *v826; // rdx
  __int64 v827; // rcx
  unsigned __int8 ConnectionNetworkPath; // al
  __int64 v829; // rdx
  __int64 v830; // rcx
  int v831; // r14d
  __int64 v832; // rdx
  __int64 v833; // rcx
  __int64 v834; // rdx
  __int64 v835; // rcx
  int v836; // r15d
  __int64 v837; // rdx
  __int64 v838; // rcx
  int v839; // ebx
  __int64 v840; // rdx
  __int64 v841; // rcx
  int v842; // r12d
  __int64 v843; // rdx
  __int64 v844; // rcx
  __int64 v845; // rdx
  __int64 v846; // rcx
  unsigned __int8 v847; // bl
  int v848; // r12d
  __int64 v849; // r14
  RBX::Time *v850; // rdi
  std::__shared_weak_count *v851; // rbx
  _WORD *v852; // rax
  char v853; // al
  char *v854; // rax
  bool v855; // bl
  RBX::Network::Client *v856; // xmm0_8
  RBX::Time *v857; // rdx
  __int64 v858; // rdi
  __int64 v859; // rax
  __int64 v860; // rdx
  __int64 v861; // rcx
  __int64 v862; // rbx
  __int64 v863; // rax
  std::__shared_weak_count *v864; // rbx
  RBX::EngineStabilityStats *v865; // rdi
  __int64 v866; // rax
  RBX::DataModel *v867; // rbx
  __int64 v868; // rsi
  char *v869; // rax
  __int64 v870; // r14
  __int64 v871; // r15
  __int64 v872; // r12
  int v873; // r13d
  RBX::EngineStabilityStats *v874; // rbx
  __int64 v875; // rdx
  __int64 v876; // rcx
  __int64 v877; // rax
  __int64 v878; // rdx
  __int64 v879; // rcx
  __int64 v880; // rdx
  __int64 v881; // rcx
  __int64 v882; // rax
  __int64 v883; // rdx
  __int64 v884; // rcx
  __int64 v885; // rcx
  __int64 v886; // rdx
  __int64 v887; // rcx
  __int64 v888; // rdx
  __int64 v889; // rcx
  __int64 v890; // rcx
  int v892; // eax
  char v893; // al
  RBX::Time *v894; // rcx
  char v895; // al
  _QWORD *v896; // rcx
  unsigned __int64 *v897; // rsi
  unsigned __int64 v898; // rcx
  unsigned __int64 v899; // rdx
  int v900; // esi
  __int128 v901; // [rsp+0h] [rbp-BB0h]
  __int64 v902; // [rsp+10h] [rbp-BA0h]
  __int64 v903; // [rsp+18h] [rbp-B98h]
  int v904; // [rsp+20h] [rbp-B90h]
  _BYTE v905[56]; // [rsp+70h] [rbp-B40h] BYREF
  _QWORD v906[6]; // [rsp+A8h] [rbp-B08h] BYREF
  std::__shared_weak_count *v907; // [rsp+D8h] [rbp-AD8h]
  char *v908; // [rsp+E0h] [rbp-AD0h]
  std::__shared_weak_count *v909; // [rsp+E8h] [rbp-AC8h]
  __int128 v910; // [rsp+F0h] [rbp-AC0h] BYREF
  __int64 v911; // [rsp+100h] [rbp-AB0h]
  __int128 v912; // [rsp+110h] [rbp-AA0h] BYREF
  __int64 v913; // [rsp+120h] [rbp-A90h]
  _BYTE v914[16]; // [rsp+128h] [rbp-A88h] BYREF
  void *v915; // [rsp+138h] [rbp-A78h]
  char v916; // [rsp+140h] [rbp-A70h]
  __int64 *v917; // [rsp+148h] [rbp-A68h] BYREF
  _BYTE v918[16]; // [rsp+150h] [rbp-A60h] BYREF
  char v919; // [rsp+160h] [rbp-A50h] BYREF
  __int64 v920; // [rsp+168h] [rbp-A48h]
  std::__shared_weak_count *v921; // [rsp+170h] [rbp-A40h]
  _BYTE v922[16]; // [rsp+178h] [rbp-A38h] BYREF
  void *v923; // [rsp+188h] [rbp-A28h]
  _BYTE v924[16]; // [rsp+190h] [rbp-A20h] BYREF
  void *v925; // [rsp+1A0h] [rbp-A10h]
  _BYTE v926[16]; // [rsp+1A8h] [rbp-A08h] BYREF
  void *v927; // [rsp+1B8h] [rbp-9F8h]
  _BYTE v928[16]; // [rsp+1C0h] [rbp-9F0h] BYREF
  void *v929; // [rsp+1D0h] [rbp-9E0h]
  char *v930; // [rsp+1D8h] [rbp-9D8h]
  char *v931; // [rsp+1E0h] [rbp-9D0h]
  _BYTE v932[16]; // [rsp+1E8h] [rbp-9C8h] BYREF
  void *v933; // [rsp+1F8h] [rbp-9B8h]
  _BYTE v934[16]; // [rsp+200h] [rbp-9B0h] BYREF
  void *v935; // [rsp+210h] [rbp-9A0h]
  char v936[8]; // [rsp+218h] [rbp-998h] BYREF
  std::__shared_weak_count *v937; // [rsp+220h] [rbp-990h]
  _BYTE v938[16]; // [rsp+228h] [rbp-988h] BYREF
  void *v939; // [rsp+238h] [rbp-978h]
  _BYTE v940[16]; // [rsp+240h] [rbp-970h] BYREF
  void *v941; // [rsp+250h] [rbp-960h]
  char v942[8]; // [rsp+258h] [rbp-958h] BYREF
  std::__shared_weak_count *v943; // [rsp+260h] [rbp-950h]
  _BYTE v944[16]; // [rsp+268h] [rbp-948h] BYREF
  void *v945; // [rsp+278h] [rbp-938h]
  _BYTE v946[16]; // [rsp+280h] [rbp-930h] BYREF
  void *v947; // [rsp+290h] [rbp-920h]
  _BYTE v948[16]; // [rsp+298h] [rbp-918h] BYREF
  void *v949; // [rsp+2A8h] [rbp-908h]
  _BYTE v950[16]; // [rsp+2B0h] [rbp-900h] BYREF
  void *v951; // [rsp+2C0h] [rbp-8F0h]
  _BYTE v952[16]; // [rsp+2C8h] [rbp-8E8h] BYREF
  void *v953; // [rsp+2D8h] [rbp-8D8h]
  _BYTE v954[16]; // [rsp+2E0h] [rbp-8D0h] BYREF
  void *v955; // [rsp+2F0h] [rbp-8C0h]
  _BYTE v956[16]; // [rsp+2F8h] [rbp-8B8h] BYREF
  void *v957; // [rsp+308h] [rbp-8A8h]
  _BYTE v958[16]; // [rsp+310h] [rbp-8A0h] BYREF
  void *v959; // [rsp+320h] [rbp-890h]
  _BYTE v960[16]; // [rsp+328h] [rbp-888h] BYREF
  void *v961; // [rsp+338h] [rbp-878h]
  char v962[8]; // [rsp+340h] [rbp-870h] BYREF
  std::__shared_weak_count *v963; // [rsp+348h] [rbp-868h]
  std::__shared_weak_count *v964[2]; // [rsp+350h] [rbp-860h] BYREF
  std::__shared_weak_count *v965[2]; // [rsp+360h] [rbp-850h] BYREF
  char v966[8]; // [rsp+378h] [rbp-838h] BYREF
  __int64 v967; // [rsp+380h] [rbp-830h]
  void *v968; // [rsp+388h] [rbp-828h]
  __int128 v969; // [rsp+390h] [rbp-820h] BYREF
  __int64 v970; // [rsp+3A0h] [rbp-810h] BYREF
  unsigned __int8 v971; // [rsp+3B0h] [rbp-800h] BYREF
  char v972; // [rsp+3B1h] [rbp-7FFh] BYREF
  __int64 v973; // [rsp+3B8h] [rbp-7F8h]
  void *v974; // [rsp+3C0h] [rbp-7F0h]
  unsigned __int8 v975; // [rsp+3C8h] [rbp-7E8h] BYREF
  char v976; // [rsp+3C9h] [rbp-7E7h] BYREF
  __int64 v977; // [rsp+3D0h] [rbp-7E0h]
  void *v978; // [rsp+3D8h] [rbp-7D8h]
  __int64 v979; // [rsp+3E0h] [rbp-7D0h] BYREF
  char v980; // [rsp+3E8h] [rbp-7C8h]
  _BYTE v981[24]; // [rsp+3F0h] [rbp-7C0h] BYREF
  char v982[8]; // [rsp+408h] [rbp-7A8h] BYREF
  __int64 v983; // [rsp+410h] [rbp-7A0h]
  void *v984; // [rsp+418h] [rbp-798h]
  __int128 v985; // [rsp+420h] [rbp-790h] BYREF
  void *v986; // [rsp+430h] [rbp-780h]
  __int128 v987; // [rsp+440h] [rbp-770h] BYREF
  void *v988; // [rsp+450h] [rbp-760h]
  __int128 v989; // [rsp+460h] [rbp-750h] BYREF
  void *v990; // [rsp+470h] [rbp-740h]
  __int128 v991; // [rsp+480h] [rbp-730h] BYREF
  void *v992; // [rsp+490h] [rbp-720h]
  int v993; // [rsp+4A0h] [rbp-710h] BYREF
  int v994; // [rsp+4A4h] [rbp-70Ch] BYREF
  int v995; // [rsp+4A8h] [rbp-708h]
  int v996; // [rsp+4ACh] [rbp-704h]
  __int64 v997; // [rsp+4B0h] [rbp-700h] BYREF
  StartGameStatistics *v998; // [rsp+4B8h] [rbp-6F8h]
  std::__shared_weak_count *v999; // [rsp+4C0h] [rbp-6F0h]
  unsigned __int8 v1000; // [rsp+4C8h] [rbp-6E8h] BYREF
  char v1001; // [rsp+4C9h] [rbp-6E7h] BYREF
  __int64 v1002; // [rsp+4D0h] [rbp-6E0h]
  void *v1003; // [rsp+4D8h] [rbp-6D8h]
  __int128 v1004; // [rsp+4E0h] [rbp-6D0h] BYREF
  void *v1005; // [rsp+4F0h] [rbp-6C0h]
  __int128 v1006; // [rsp+500h] [rbp-6B0h] BYREF
  void *v1007; // [rsp+510h] [rbp-6A0h]
  __int64 v1008; // [rsp+518h] [rbp-698h] BYREF
  __int128 v1009; // [rsp+520h] [rbp-690h] BYREF
  void *v1010; // [rsp+530h] [rbp-680h]
  unsigned __int8 v1011; // [rsp+540h] [rbp-670h] BYREF
  _BYTE v1012[7]; // [rsp+541h] [rbp-66Fh] BYREF
  __int64 v1013; // [rsp+548h] [rbp-668h]
  void *v1014; // [rsp+550h] [rbp-660h]
  char *v1015; // [rsp+558h] [rbp-658h]
  int v1016; // [rsp+564h] [rbp-64Ch] BYREF
  double v1017; // [rsp+568h] [rbp-648h]
  __int64 v1018; // [rsp+570h] [rbp-640h]
  char v1019; // [rsp+57Fh] [rbp-631h] BYREF
  std::__shared_weak_count *v1020[2]; // [rsp+580h] [rbp-630h] BYREF
  void *v1021; // [rsp+590h] [rbp-620h]
  RBX::AppQoSInstance **v1022; // [rsp+5A0h] [rbp-610h]
  RBX::Network::Client *v1023; // [rsp+5A8h] [rbp-608h]
  __int128 __dst; // [rsp+5B0h] [rbp-600h] BYREF
  void *v1025; // [rsp+5C0h] [rbp-5F0h]
  std::__shared_weak_count *v1026[2]; // [rsp+5D0h] [rbp-5E0h] BYREF
  void *v1027; // [rsp+5E0h] [rbp-5D0h]
  std::__shared_weak_count *v1028[2]; // [rsp+5F0h] [rbp-5C0h] BYREF
  void *v1029[2]; // [rsp+600h] [rbp-5B0h]
  int v1030; // [rsp+610h] [rbp-5A0h]
  void *v1031[2]; // [rsp+620h] [rbp-590h] BYREF
  RBX::RbxDbgInfo *v1032; // [rsp+630h] [rbp-580h]
  char v1033; // [rsp+638h] [rbp-578h]
  char *v1034; // [rsp+648h] [rbp-568h]
  __int128 v1035; // [rsp+650h] [rbp-560h]
  __int16 v1036; // [rsp+660h] [rbp-550h]
  _QWORD v1037[2]; // [rsp+670h] [rbp-540h] BYREF
  _BYTE v1038[15]; // [rsp+680h] [rbp-530h]
  _BYTE v1039[9]; // [rsp+68Fh] [rbp-521h] BYREF
  size_t __len[3]; // [rsp+6A0h] [rbp-510h] BYREF
  __int128 v1042; // [rsp+6B8h] [rbp-4F8h] BYREF
  void *v1043; // [rsp+6C8h] [rbp-4E8h]
  void *v1044[6]; // [rsp+6D0h] [rbp-4E0h] BYREF
  char v1045[48]; // [rsp+700h] [rbp-4B0h] BYREF
  _QWORD v1046[6]; // [rsp+730h] [rbp-480h] BYREF
  _QWORD v1047[6]; // [rsp+760h] [rbp-450h] BYREF
  _QWORD v1048[46]; // [rsp+790h] [rbp-420h] BYREF
  std::__shared_weak_count *v1049[2]; // [rsp+900h] [rbp-2B0h] BYREF
  void *v1050; // [rsp+910h] [rbp-2A0h]
  __int64 v1051; // [rsp+918h] [rbp-298h]
  std::__shared_weak_count **v1052; // [rsp+920h] [rbp-290h]
  _BYTE v1053[536]; // [rsp+948h] [rbp-268h] BYREF
  __int64 v1054[2]; // [rsp+B60h] [rbp-50h] BYREF
  RBX::Time *v1055; // [rsp+B70h] [rbp-40h]

  v1015 = a4; /*0x1067be2eb*/
  v1022 = (RBX::AppQoSInstance **)a3; /*0x1067be2f2*/
  LODWORD(v1018) = a2; /*0x1067be2f9*/
  RBX::Time::nowFastSec(this: (RBX::Time *)a1); /*0x1067be310*/
  v998 = (StartGameStatistics *)(a1 + 21); /*0x1067be31c*/
  *((double *)a1 + 32) = v10; /*0x1067be323*/
  v1034 = (char *)a1; /*0x1067be32b*/
  v1017 = v10; /*0x1067be332*/
  *((double *)a1 + 21) = v10; /*0x1067be33a*/
  v1023 = a5; /*0x1067be342*/
  if ( *(double *)&a5 != 0.0 ) /*0x1067be34c*/
  {
    v11 = v1023; /*0x1067be352*/
    v12 = *(double *)v1023; /*0x1067be359*/
    if ( *(double *)v1023 != 0.0 || (v12 = *((double *)v1023 + 2)) != 0.0 ) /*0x1067be37a*/
      *(double *)v998 = v12; /*0x1067be385*/
    if ( DFFlag::PlayerConfigurer2886 == 1 /*0x1067be3ab*/
      && (unsigned __int8)FLog::AvatarJoinMetrics >= 6u
      && BYTE1(FLog::AvatarJoinMetrics) >= 3u )
    {
      LOBYTE(v7) = (unsigned __int8)FLog::AvatarJoinMetrics < 6u; /*0x1067be3a6*/
      FLog::FastLogFormatted( /*0x1067be3c2*/
        a1: FLog::AvatarJoinMetrics,
        a2: qword_10D80B698,
        a3: (unsigned int)"[FLog::AvatarJoinMetrics] startProgress/userClickTime = %g",
        a4: v7,
        a5: v8,
        a6: v9);
    }
    v13 = *((double *)v11 + 1); /*0x1067be3c7*/
    v14 = v1034; /*0x1067be3d4*/
    if ( v13 != 0.0 ) /*0x1067be3db*/
      *((double *)v1034 + 22) = v13 - *((double *)v1034 + 21); /*0x1067be3e8*/
    v15 = v1023; /*0x1067be3f8*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067be411*/
      this: (RBX::Analytics::InfluxDb::Points *)(v14 + 1152),
      a2: "VideoAdShown",
      a3: *((_BYTE *)v1023 + 240));
    v14[408] = *((_BYTE *)v1023 + 240); /*0x1067be41d*/
    v16 = *((double *)v15 + 2); /*0x1067be424*/
    v17 = *((double *)v14 + 21); /*0x1067be432*/
    if ( v16 != 0.0 ) /*0x1067be43b*/
      *((double *)v14 + 23) = v16 - v17; /*0x1067be443*/
    v18 = v1023; /*0x1067be44c*/
    *((double *)v14 + 24) = *((double *)v1023 + 3) - v17; /*0x1067be45c*/
    v19 = *((double *)v18 + 4); /*0x1067be465*/
    if ( v19 != 0.0 ) /*0x1067be472*/
      *((double *)v14 + 25) = v19 - v17; /*0x1067be47a*/
    v20 = *((unsigned __int8 *)v1023 + 136); /*0x1067be48a*/
    if ( (v20 & 1) != 0 ) /*0x1067be493*/
      v21 = *((_QWORD *)v1023 + 18); /*0x1067be499*/
    else
      v21 = v20 >> 1; /*0x1067be495*/
    if ( v21 != 0 ) /*0x1067be4a3*/
    {
      std::string::operator=(a1: v1034 + 304, a2: (char *)v1023 + 136); /*0x1067be4c4*/
      if ( (*((_BYTE *)v1023 + 136) & 1) != 0 ) /*0x1067be4cd*/
        v22 = *((const char **)v1023 + 19); /*0x1067be4d8*/
      else
        v22 = (char *)v1023 + 137; /*0x1067be4cf*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067be4e9*/
        this: (RBX::Analytics::InfluxDb::Points *)(v14 + 1152),
        a2: "JoinRequestType",
        a3: v22);
    }
  }
  if ( FFlag::MigrateAvatarMetricsFromPlayerConfigurer == 1 ) /*0x1067be4f5*/
  {
    v23 = (RBX::AvatarLoadMetrics *)operator new(a1: 0x1A0u); /*0x1067be501*/
    __bzero(a1: v23, a2: 416); /*0x1067be50c*/
    RBX::AvatarLoadMetrics::AvatarLoadMetrics(this: v23); /*0x1067be514*/
    std::unique_ptr<RBX::AvatarLoadMetrics>::reset[abi:ne200100](a1: v1034 + 896, a2: v23); /*0x1067be52a*/
  }
  v24 = v1034; /*0x1067be52f*/
  RBX::AvatarLoadMetrics::logAvatarLoadStart(a1: v1034 + 304, a2: *((double *)v1034 + 21)); /*0x1067be545*/
  *((double *)v1034 + 26) = v1017 - *((double *)v1034 + 21); /*0x1067be55e*/
  *((_DWORD *)v24 + 110) = 4; /*0x1067be566*/
  if ( FFlag::LogClientLoadToAvatarLoad == 1 ) /*0x1067be57a*/
  {
    v29 = *(_QWORD *)&FLog::LogStepTimeAndNetworkUsage; /*0x1067be587*/
    v30 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067be58c*/
    if ( (unsigned __int8)FLog::LogStepTimeAndNetworkUsage >= 6u && BYTE1(FLog::LogStepTimeAndNetworkUsage) >= 3u ) /*0x1067be598*/
    {
      FLog::FastLog( /*0x1067be5ac*/
        a1: *(_QWORD *)&FLog::LogStepTimeAndNetworkUsage,
        a2: qword_10D804018,
        a3: "[FLog::LogStepTimeAndNetworkUsage] Step Time, HTTP B/W, RakNet B/W, Overall B/W",
        0);
      v29 = *(_QWORD *)&FLog::LogStepTimeAndNetworkUsage; /*0x1067be5b1*/
      v30 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067be5b6*/
    }
    if ( (unsigned __int8)v29 >= 6u && (unsigned __int8)v30 >= 3u ) /*0x1067be5c2*/
    {
      FLog::FastLog(a1: v29, a2: qword_10D804018, a3: "[FLog::LogStepTimeAndNetworkUsage] Player Configured", 0); /*0x1067be5d6*/
      LODWORD(v29) = FLog::LogStepTimeAndNetworkUsage; /*0x1067be5db*/
      v30 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067be5e0*/
    }
    if ( (unsigned __int8)v29 >= 6u && (unsigned __int8)v30 >= 3u ) /*0x1067be5ec*/
    {
      LOBYTE(v25) = (unsigned __int8)v29 < 6u; /*0x1067be5e7*/
      FLog::FastLogFormatted( /*0x1067be600*/
        a1: v29,
        a2: qword_10D804018,
        a3: (unsigned int)"[FLog::LogStepTimeAndNetworkUsage] 0, 0, 0, 0",
        a4: v25,
        a5: v27,
        a6: v28);
    }
  }
  v31 = (RBX::DataModel *)v1022; /*0x1067be60c*/
  *((_QWORD *)v1034 + 3) = v1022; /*0x1067be613*/
  if ( (~*((_BYTE *)v31 + 2256) & 0x3D) == 0 ) /*0x1067be621*/
  {
    if ( FFlag::MigrateAvatarMetricsFromPlayerConfigurer == 1 ) /*0x1067be62e*/
    {
      v32 = *((_QWORD *)v1034 + 112) + 368LL; /*0x1067be63c*/
      v1049[0] = (std::__shared_weak_count *)off_10CAAC470; /*0x1067be651*/
      v1049[1] = (std::__shared_weak_count *)v1034; /*0x1067be654*/
      v1052 = v1049; /*0x1067be658*/
      std::__function::__value_func<void ()(void)>::swap[abi:ne200100](a1: (__int64)v1049, a2: v32); /*0x1067be65f*/
      if ( v1052 == v1049 ) /*0x1067be66b*/
      {
        v33 = 32; /*0x1067be71d*/
      }
      else
      {
        v33 = 40; /*0x1067be671*/
        if ( v1052 == nullptr ) /*0x1067be679*/
          goto LABEL_40; /*0x1067be679*/
      }
      (*(void (**)(void))((char *)*v1052 + v33))(); /*0x1067be725*/
LABEL_40:
      RBX::AvatarLoadMetrics::initConnections( /*0x1067be728*/
        this: *((RBX::AvatarLoadMetrics **)v1034 + 112),
        a2: (RBX::DataModel *)v1022,
        a3: v998,
        a4: (RBX::Analytics::InfluxDb::Points *)(v1034 + 1152));
      goto LABEL_82; /*0x1067be750*/
    }
    v34 = (RBX::AvatarLoadEvents *)(v1022 + 58); /*0x1067be68b*/
    v35 = (rbx::signals::slots_holder **)RBX::AvatarLoadEvents::getOrCreate( /*0x1067be69a*/
                                           this: (RBX::AvatarLoadEvents *)(v1022 + 58),
                                           a2: v26);
    RBX::weak_from<RBX::PlayerConfigurer>(a1: v1049, a2: v1034); /*0x1067be6ab*/
    v36 = (unsigned int)RBX::Memory::InstanceSignal; /*0x1067be6b7*/
    v38 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v37); /*0x1067be6c2*/
    rbx::lazyInitSlotsHolder(a1: v35); /*0x1067be6c7*/
    v40 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x40, a2: v39); /*0x1067be6d6*/
    *(_QWORD *)v40 = &_mh_execute_header; /*0x1067be6e3*/
    *(_QWORD *)(v40 + 8) = &rbx::signals::slot_with_functor<RBX::PlayerConfigurer::configure(RBX::Security::Identities,RBX::DataModel *,std::string const&,StartGameStatistics const*)::$_1,RBX::Humanoid *,double>::do_call; /*0x1067be6ee*/
    *(_OWORD *)(v40 + 16) = 0; /*0x1067be6f7*/
    v41 = *v35; /*0x1067be6fe*/
    *(_QWORD *)(v40 + 32) = *v35; /*0x1067be701*/
    if ( v41 != nullptr ) /*0x1067be709*/
    {
      _InterlockedIncrement((volatile signed __int32 *)v41 + 1); /*0x1067be70b*/
      v42 = *(_QWORD *)(v40 + 24) | 4LL; /*0x1067be714*/
      v43 = *v35; /*0x1067be718*/
    }
    else
    {
      v42 = 4; /*0x1067be755*/
      v43 = nullptr; /*0x1067be75a*/
    }
    *(_QWORD *)(v40 + 24) = v42; /*0x1067be75c*/
    *(_QWORD *)(v40 + 40) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::configure(RBX::Security::Identities,RBX::DataModel *,std::string const&,StartGameStatistics const*)::$_1,RBX::Humanoid *,double>::do_dtor; /*0x1067be768*/
    *(_OWORD *)(v40 + 48) = *(_OWORD *)v1049; /*0x1067be775*/
    *(_OWORD *)v1049 = 0; /*0x1067be77c*/
    rbx::signals::slots_holder::insert(this: v43, a2: v40); /*0x1067be787*/
    __len[0] = v40; /*0x1067be78c*/
    _InterlockedIncrement((volatile signed __int32 *)(v40 + 4)); /*0x1067be793*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v38, a2: v44); /*0x1067be79b*/
    rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(v1034 + 1672)); /*0x1067be7b5*/
    if ( v40 != 0 && _InterlockedDecrement((volatile signed __int32 *)(__len[0] + 4)) == 0 ) /*0x1067be7ca*/
      rbx::signals::slot_base::operator delete(a1: (void *)v40); /*0x1067be7cc*/
    if ( v1049[1] != nullptr ) /*0x1067be7db*/
      std::__shared_weak_count::__release_weak(this: v1049[1]); /*0x1067be7dd*/
    v46 = RBX::AvatarLoadEvents::getOrCreate(this: v34, a2: v45); /*0x1067be7ea*/
    RBX::weak_from<RBX::PlayerConfigurer>(a1: v1049, a2: v1034); /*0x1067be7fb*/
    v48 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v36, a2: v47); /*0x1067be808*/
    v49 = (rbx::signals::slots_holder **)(v46 + 8); /*0x1067be80a*/
    rbx::lazyInitSlotsHolder(a1: v49); /*0x1067be811*/
    v51 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x40, a2: v50); /*0x1067be820*/
    *(_QWORD *)v51 = &_mh_execute_header; /*0x1067be82d*/
    *(_QWORD *)(v51 + 8) = &rbx::signals::slot_with_functor<RBX::PlayerConfigurer::configure(RBX::Security::Identities,RBX::DataModel *,std::string const&,StartGameStatistics const*)::$_2,RBX::Humanoid *,double,double,std::vector<RBX::ContentId> const&,unsigned int>::do_call; /*0x1067be838*/
    *(_OWORD *)(v51 + 16) = 0; /*0x1067be841*/
    v52 = *v49; /*0x1067be848*/
    *(_QWORD *)(v51 + 32) = *v49; /*0x1067be84b*/
    if ( v52 != nullptr ) /*0x1067be853*/
    {
      _InterlockedIncrement((volatile signed __int32 *)v52 + 1); /*0x1067be855*/
      v53 = *(_QWORD *)(v51 + 24) | 4LL; /*0x1067be85e*/
      v54 = *v49; /*0x1067be862*/
    }
    else
    {
      v53 = 4; /*0x1067be867*/
      v54 = nullptr; /*0x1067be86c*/
    }
    *(_QWORD *)(v51 + 24) = v53; /*0x1067be86e*/
    *(_QWORD *)(v51 + 40) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::configure(RBX::Security::Identities,RBX::DataModel *,std::string const&,StartGameStatistics const*)::$_2,RBX::Humanoid *,double,double,std::vector<RBX::ContentId> const&,unsigned int>::do_dtor; /*0x1067be87a*/
    *(_OWORD *)(v51 + 48) = *(_OWORD *)v1049; /*0x1067be887*/
    *(_OWORD *)v1049 = 0; /*0x1067be88e*/
    rbx::signals::slots_holder::insert(this: v54, a2: v51); /*0x1067be899*/
    __len[0] = v51; /*0x1067be89e*/
    _InterlockedIncrement((volatile signed __int32 *)(v51 + 4)); /*0x1067be8a5*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v48, a2: v55); /*0x1067be8ad*/
    rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(v1034 + 1680)); /*0x1067be8c7*/
    if ( v51 != 0 && _InterlockedDecrement((volatile signed __int32 *)(__len[0] + 4)) == 0 ) /*0x1067be8dc*/
      rbx::signals::slot_base::operator delete(a1: (void *)v51); /*0x1067be8de*/
    if ( v1049[1] != nullptr ) /*0x1067be8ed*/
      std::__shared_weak_count::__release_weak(this: v1049[1]); /*0x1067be8ef*/
    v57 = RBX::AvatarLoadEvents::getOrCreate(this: v34, a2: v56); /*0x1067be8fc*/
    RBX::weak_from<RBX::PlayerConfigurer>(a1: v1049, a2: v1034); /*0x1067be90d*/
    v59 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v36, a2: v58); /*0x1067be91a*/
    v60 = (rbx::signals::slots_holder **)(v57 + 16); /*0x1067be91c*/
    rbx::lazyInitSlotsHolder(a1: v60); /*0x1067be923*/
    v62 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x40, a2: v61); /*0x1067be932*/
    *(_QWORD *)v62 = &_mh_execute_header; /*0x1067be93f*/
    *(_QWORD *)(v62 + 8) = &rbx::signals::slot_with_functor<RBX::PlayerConfigurer::configure(RBX::Security::Identities,RBX::DataModel *,std::string const&,StartGameStatistics const*)::$_3,RBX::Humanoid *,double>::do_call; /*0x1067be94a*/
    *(_OWORD *)(v62 + 16) = 0; /*0x1067be953*/
    v63 = *v60; /*0x1067be95a*/
    *(_QWORD *)(v62 + 32) = *v60; /*0x1067be95d*/
    if ( v63 != nullptr ) /*0x1067be965*/
    {
      _InterlockedIncrement((volatile signed __int32 *)v63 + 1); /*0x1067be967*/
      v64 = *(_QWORD *)(v62 + 24) | 4LL; /*0x1067be970*/
      v65 = *v60; /*0x1067be974*/
    }
    else
    {
      v64 = 4; /*0x1067be979*/
      v65 = nullptr; /*0x1067be97e*/
    }
    *(_QWORD *)(v62 + 24) = v64; /*0x1067be980*/
    *(_QWORD *)(v62 + 40) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::configure(RBX::Security::Identities,RBX::DataModel *,std::string const&,StartGameStatistics const*)::$_3,RBX::Humanoid *,double>::do_dtor; /*0x1067be98c*/
    *(_OWORD *)(v62 + 48) = *(_OWORD *)v1049; /*0x1067be999*/
    *(_OWORD *)v1049 = 0; /*0x1067be9a0*/
    rbx::signals::slots_holder::insert(this: v65, a2: v62); /*0x1067be9ab*/
    __len[0] = v62; /*0x1067be9b0*/
    _InterlockedIncrement((volatile signed __int32 *)(v62 + 4)); /*0x1067be9b7*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v59, a2: v66); /*0x1067be9bf*/
    rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(v1034 + 1688)); /*0x1067be9d9*/
    if ( v62 != 0 && _InterlockedDecrement((volatile signed __int32 *)(__len[0] + 4)) == 0 ) /*0x1067be9ee*/
      rbx::signals::slot_base::operator delete(a1: (void *)v62); /*0x1067be9f0*/
    if ( v1049[1] != nullptr ) /*0x1067be9ff*/
      std::__shared_weak_count::__release_weak(this: v1049[1]); /*0x1067bea01*/
    v68 = RBX::AvatarLoadEvents::getOrCreate(this: v34, a2: v67); /*0x1067bea0e*/
    RBX::weak_from<RBX::PlayerConfigurer>(a1: v1049, a2: v1034); /*0x1067bea1f*/
    v70 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v36, a2: v69); /*0x1067bea2c*/
    v71 = (rbx::signals::slots_holder **)(v68 + 24); /*0x1067bea2e*/
    rbx::lazyInitSlotsHolder(a1: v71); /*0x1067bea35*/
    v73 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x40, a2: v72); /*0x1067bea44*/
    *(_QWORD *)v73 = &_mh_execute_header; /*0x1067bea51*/
    *(_QWORD *)(v73 + 8) = &rbx::signals::slot_with_functor<RBX::PlayerConfigurer::configure(RBX::Security::Identities,RBX::DataModel *,std::string const&,StartGameStatistics const*)::$_4,RBX::Humanoid *,double,std::vector<RBX::ContentId> const&>::do_call; /*0x1067bea5c*/
    *(_OWORD *)(v73 + 16) = 0; /*0x1067bea65*/
    v74 = *v71; /*0x1067bea6c*/
    *(_QWORD *)(v73 + 32) = *v71; /*0x1067bea6f*/
    if ( v74 != nullptr ) /*0x1067bea77*/
    {
      _InterlockedIncrement((volatile signed __int32 *)v74 + 1); /*0x1067bea79*/
      v75 = *(_QWORD *)(v73 + 24) | 4LL; /*0x1067bea82*/
      v76 = *v71; /*0x1067bea86*/
    }
    else
    {
      v75 = 4; /*0x1067bea8b*/
      v76 = nullptr; /*0x1067bea90*/
    }
    *(_QWORD *)(v73 + 24) = v75; /*0x1067bea92*/
    *(_QWORD *)(v73 + 40) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::configure(RBX::Security::Identities,RBX::DataModel *,std::string const&,StartGameStatistics const*)::$_4,RBX::Humanoid *,double,std::vector<RBX::ContentId> const&>::do_dtor; /*0x1067bea9e*/
    *(_OWORD *)(v73 + 48) = *(_OWORD *)v1049; /*0x1067beaab*/
    *(_OWORD *)v1049 = 0; /*0x1067beab2*/
    rbx::signals::slots_holder::insert(this: v76, a2: v73); /*0x1067beabd*/
    __len[0] = v73; /*0x1067beac2*/
    _InterlockedIncrement((volatile signed __int32 *)(v73 + 4)); /*0x1067beac9*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v70, a2: v77); /*0x1067bead1*/
    rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(v1034 + 1696)); /*0x1067beaeb*/
    if ( v73 != 0 && _InterlockedDecrement((volatile signed __int32 *)(__len[0] + 4)) == 0 ) /*0x1067beb00*/
      rbx::signals::slot_base::operator delete(a1: (void *)v73); /*0x1067beb02*/
    if ( v1049[1] != nullptr ) /*0x1067beb11*/
      std::__shared_weak_count::__release_weak(this: v1049[1]); /*0x1067beb13*/
    RBX::weak_from<RBX::PlayerConfigurer>(a1: v1049, a2: v1034); /*0x1067beb26*/
    v1050 = RBX::PlayerConfigurer::reportLocalJoinFailureMetrics; /*0x1067beb47*/
    v1051 = 0; /*0x1067beb4b*/
    _ZN3rbx6signalIFvNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEdEE7connectIZN3RBX16PlayerConfigurer11with_lockedIMSC_FvS7_dEEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSH_( /*0x1067beb5a*/
      a1: __len,
      a2: v1022 + 142);
    rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(v1034 + 1704)); /*0x1067beb74*/
    v79 = (void *)__len[0]; /*0x1067beb79*/
    if ( __len[0] != 0 && _InterlockedDecrement((volatile signed __int32 *)(__len[0] + 4)) == 0 ) /*0x1067beb89*/
      rbx::signals::slot_base::operator delete(a1: v79); /*0x1067beb8b*/
    if ( v1049[1] != nullptr ) /*0x1067beb9a*/
      std::__shared_weak_count::__release_weak(this: v1049[1]); /*0x1067beb9c*/
    v80 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v36, a2: v78); /*0x1067beba9*/
    v81 = v1022 + 139; /*0x1067bebb2*/
    rbx::lazyInitSlotsHolder(a1: v1022 + 139); /*0x1067bebbc*/
    v83 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v82); /*0x1067bebcb*/
    *(_QWORD *)v83 = &_mh_execute_header; /*0x1067bebd8*/
    *(_QWORD *)(v83 + 8) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::configure(RBX::Security::Identities,RBX::DataModel *,std::string const&,StartGameStatistics const*)::$_5>::do_call; /*0x1067bebe2*/
    *(_OWORD *)(v83 + 16) = 0; /*0x1067bebea*/
    v84 = *v81; /*0x1067bebf0*/
    *(_QWORD *)(v83 + 32) = *v81; /*0x1067bebf3*/
    if ( v84 != nullptr ) /*0x1067bebfa*/
    {
      _InterlockedIncrement((volatile signed __int32 *)v84 + 1); /*0x1067bebfc*/
      v85 = *(_QWORD *)(v83 + 24) & 0xFFFFFFFFFFFFFFFBLL; /*0x1067bec04*/
    }
    else
    {
      v85 = 0; /*0x1067bec0a*/
    }
    *(_QWORD *)(v83 + 24) = v85; /*0x1067bec0c*/
    *(_QWORD *)(v83 + 40) = v1034; /*0x1067bec17*/
    rbx::signals::slots_holder::insert(this: *v81, a2: v83); /*0x1067bec21*/
    v1049[0] = (std::__shared_weak_count *)v83; /*0x1067bec26*/
    _InterlockedIncrement((volatile signed __int32 *)(v83 + 4)); /*0x1067bec2d*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v80, a2: v86); /*0x1067bec34*/
    rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(v1034 + 1736)); /*0x1067bec4e*/
    v87 = v1049[0]; /*0x1067bec53*/
    if ( v1049[0] != nullptr && _InterlockedDecrement((volatile signed __int32 *)v1049[0] + 1) == 0 ) /*0x1067bec63*/
      rbx::signals::slot_base::operator delete(a1: v87); /*0x1067bec65*/
  }
LABEL_82:
  RBX::Security::Identity::Identity(a1: v1049, a2: (unsigned int)v1018, a3: 0, a4: 0); /*0x1067bec6a*/
  RBX::Security::Impersonator::Impersonator(a1: v905, a2: v1049, a3: 0x3FFFFFFFFFFF00LL, a4: 0); /*0x1067bec9a*/
  v89 = v1015; /*0x1067bec9f*/
  v90 = (unsigned __int8)*v1015; /*0x1067beca6*/
  if ( (v90 & 1) != 0 ) /*0x1067becab*/
    v91 = *((_QWORD *)v1015 + 1); /*0x1067becad*/
  else
    v91 = v90 >> 1; /*0x1067becb3*/
  if ( v91 != 0 ) /*0x1067becb8*/
    RBX::GameConfigurer::parseArgs(a1: v1034, a2: v1015); /*0x1067becc8*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "GameId", a3: v88, a4: v89); /*0x1067becdb*/
  RBX::GameConfigurer::getParamString(a1: v1049, a2: v1034, a3: __len); /*0x1067becf5*/
  RBX::DataModel::setContextAttribute(a1: v1022, a2: 5, a3: v1049); /*0x1067bed0d*/
  if ( ((__int64)v1049[0] & 1) != 0 ) /*0x1067bed19*/
    operator delete(a1: v1050); /*0x1067bed22*/
  if ( (__len[0] & 1) != 0 ) /*0x1067bed2e*/
    operator delete(a1: (void *)__len[2]); /*0x1067bed37*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "MachineAddress", a3: v92, a4: v93); /*0x1067bed4a*/
  RBX::GameConfigurer::getParamString(a1: v1049, a2: v1034, a3: __len); /*0x1067bed64*/
  RBX::DataModel::setContextAttribute(a1: v1022, a2: 10, a3: v1049); /*0x1067bed7c*/
  if ( ((__int64)v1049[0] & 1) != 0 ) /*0x1067bed88*/
    operator delete(a1: v1050); /*0x1067bed91*/
  if ( (__len[0] & 1) != 0 ) /*0x1067bed9d*/
    operator delete(a1: (void *)__len[2]); /*0x1067beda6*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "ServerPort", a3: v94, a4: v95); /*0x1067bedb9*/
  RBX::GameConfigurer::getParamString(a1: v1049, a2: v1034, a3: __len); /*0x1067bedd3*/
  RBX::DataModel::setContextAttribute(a1: v1022, a2: 11, a3: v1049); /*0x1067bedeb*/
  if ( ((__int64)v1049[0] & 1) != 0 ) /*0x1067bedf7*/
    operator delete(a1: v1050); /*0x1067bee00*/
  if ( (__len[0] & 1) != 0 ) /*0x1067bee0c*/
    operator delete(a1: (void *)__len[2]); /*0x1067bee15*/
  v98 = v1034; /*0x1067bee1a*/
  LOBYTE(v97) = v1034[81]; /*0x1067bee25*/
  *(_BYTE *)(*((_QWORD *)v1034 + 3) + 2432LL) = v97; /*0x1067bee28*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1049, a2: "CountryCode", a3: v96, a4: v97); /*0x1067bee3c*/
  RBX::GameConfigurer::getParamString(a1: v982, a2: v98, a3: v1049); /*0x1067bee52*/
  if ( ((__int64)v1049[0] & 1) != 0 ) /*0x1067bee5e*/
    operator delete(a1: v1050); /*0x1067bee67*/
  if ( (v982[0] & 1) != 0 ) /*0x1067bee75*/
    v102 = v983; /*0x1067bee77*/
  else
    v102 = (unsigned __int8)v982[0] >> 1; /*0x1067bee80*/
  if ( v102 != 0 ) /*0x1067bee85*/
    RBX::Analytics::setLocation(a1: v982); /*0x1067bee8e*/
  if ( v1034[81] == 1 ) /*0x1067bee9e*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "GameId", a3: v99, a4: v100); /*0x1067beeae*/
    RBX::GameConfigurer::getParamString(a1: v1049, a2: v1034, a3: __len); /*0x1067beec8*/
    if ( (RBX::Http::gameID & 1) != 0 ) /*0x1067beed7*/
      operator delete(a1: (void *)qword_10D783240); /*0x1067beedd*/
    qword_10D783240 = (__int64)v1050; /*0x1067beee9*/
    RBX::Http::gameID = *(_OWORD *)v1049; /*0x1067beef5*/
    LOWORD(v1049[0]) = 0; /*0x1067beef9*/
    if ( (__len[0] & 1) != 0 ) /*0x1067bef09*/
      operator delete(a1: (void *)__len[2]); /*0x1067bef12*/
  }
  if ( FFlag::DebugLocalRccServerConnection == 1 ) /*0x1067bef21*/
  {
    v103 = *((_QWORD *)v1034 + 3); /*0x1067bef2a*/
    std::string::basic_string[abi:ne200100]<0>(a1: v918, a2: "Test", a3: v99, a4: v100); /*0x1067bef3c*/
    RBX::DataModelProp::setJobIdSetOnly(a1: v103 + 720, a2: v918); /*0x1067bef52*/
    if ( (v918[0] & 1) == 0 ) /*0x1067bef5e*/
      goto LABEL_121; /*0x1067bef5e*/
    v104 = (void **)&v919; /*0x1067bef64*/
    goto LABEL_120; /*0x1067bef6b*/
  }
  if ( v1034[81] == 1 ) /*0x1067bef78*/
  {
    v105 = *((_QWORD *)v1034 + 3); /*0x1067bef81*/
    if ( (RBX::Http::gameID & 1) != 0 ) /*0x1067bef8f*/
    {
      std::string::__init_copy_ctor_external(a1: &v969, a2: qword_10D783240, a3: *((_QWORD *)&RBX::Http::gameID + 1)); /*0x1067befb9*/
    }
    else
    {
      v970 = qword_10D783240; /*0x1067bef95*/
      v969 = RBX::Http::gameID; /*0x1067befa0*/
    }
    RBX::DataModelProp::setJobIdSetOnly(a1: v105 + 720, a2: &v969); /*0x1067befcf*/
    if ( (v969 & 1) != 0 ) /*0x1067befdb*/
    {
      v104 = (void **)&v970; /*0x1067befdd*/
LABEL_120:
      operator delete(a1: *v104); /*0x1067befe4*/
    }
  }
LABEL_121:
  Instance = (RBX::json::Value *)RBX::Security::KeyRing::getInstance(this: v101); /*0x1067befec*/
  v107 = *((_QWORD *)v1034 + 3); /*0x1067beffb*/
  if ( (*(_BYTE *)(v107 + 744) & 1) != 0 ) /*0x1067bf006*/
  {
    std::string::__init_copy_ctor_external(a1: v1049, a2: *(_QWORD *)(v107 + 760), a3: *(_QWORD *)(v107 + 752)); /*0x1067bf03c*/
  }
  else
  {
    v108 = v107 + 744; /*0x1067bf008*/
    v1050 = *(void **)(v108 + 16); /*0x1067bf012*/
    *(_OWORD *)v1049 = *(_OWORD *)v108; /*0x1067bf01d*/
  }
  RBX::Security::KeyRing::setJobId(a1: Instance, a2: v1049); /*0x1067bf04b*/
  if ( ((__int64)v1049[0] & 1) != 0 ) /*0x1067bf057*/
    operator delete(a1: v1050); /*0x1067bf060*/
  RBX::Security::KeyRing::registerCounterFn(a1: Instance, a2: RBX::Analytics::EphemeralCounter::reportCounter); /*0x1067bf06f*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1049, a2: "EphemeralEarlyPubKey", a3: v109, a4: v110); /*0x1067bf082*/
  RBX::GameConfigurer::getParamString(a1: &v971, a2: v1034, a3: v1049); /*0x1067bf09c*/
  if ( ((__int64)v1049[0] & 1) != 0 ) /*0x1067bf0a8*/
    operator delete(a1: v1050); /*0x1067bf0b1*/
  if ( (v971 & 1) != 0 ) /*0x1067bf0bf*/
    v112 = v973; /*0x1067bf0c1*/
  else
    v112 = v971 >> 1; /*0x1067bf0cc*/
  if ( v112 != 0 ) /*0x1067bf0d1*/
  {
    if ( (v971 & 1) != 0 ) /*0x1067bf0d5*/
      v113 = (char *)v974; /*0x1067bf0db*/
    else
      v113 = &v972; /*0x1067bf176*/
    RBX::Url::urlDecode(a1: v1049, a2: v113); /*0x1067bf184*/
    if ( ((__int64)v1049[0] & 1) != 0 ) /*0x1067bf190*/
      v119 = (const char *)v1050; /*0x1067bf192*/
    else
      v119 = (char *)v1049 + 1; /*0x1067bf19b*/
    RBX::format( /*0x1067bf1b2*/
      this: (RBX *)__len,
      a2: "{\"creationTime\":\"11:59 4/1/2024\",\"applications\":{\"RakNetEarlyPublicKey\":{\"versions\":[{\"id\":5,\"value\""
      ":\"%s\",\"allowed\":true}],\"send\":5,\"revert\":5}}}",
      v119);
    v120 = RBX::Security::KeyRing::parseConfig(a1: Instance); /*0x1067bf1c3*/
    v121 = "Error"; /*0x1067bf1cf*/
    if ( v120 != 0 ) /*0x1067bf1d8*/
      v121 = "Loaded"; /*0x1067bf1d8*/
    RBX::format(this: (RBX *)v1028, a2: "KeyRingClient%s", v121); /*0x1067bf1ec*/
    RBX::PlayerConfigurer::reportCounter(a1: v122, a2: (__int64)v1028, a3: 0); /*0x1067bf1fa*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067bf206*/
      operator delete(a1: v1029[0]); /*0x1067bf20f*/
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "ClientPublicKeyData", a3: 0, a4: v111); /*0x1067bf0f5*/
    RBX::GameConfigurer::getParamString(a1: v1049, a2: v1034, a3: __len); /*0x1067bf10f*/
    if ( (__len[0] & 1) != 0 ) /*0x1067bf11b*/
      operator delete(a1: (void *)__len[2]); /*0x1067bf124*/
    v114 = RBX::Security::KeyRing::parseConfig(a1: Instance); /*0x1067bf135*/
    v115 = "Error"; /*0x1067bf141*/
    if ( v114 != 0 ) /*0x1067bf14a*/
      v115 = "Loaded"; /*0x1067bf14a*/
    RBX::format(this: (RBX *)__len, a2: "KeyRingClient%s", v115); /*0x1067bf15e*/
    RBX::PlayerConfigurer::reportCounter(a1: v116, a2: (__int64)__len, a3: 0); /*0x1067bf16c*/
  }
  if ( (__len[0] & 1) != 0 ) /*0x1067bf21b*/
    operator delete(a1: (void *)__len[2]); /*0x1067bf224*/
  if ( ((__int64)v1049[0] & 1) != 0 ) /*0x1067bf230*/
    operator delete(a1: v1050); /*0x1067bf239*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1049, a2: "NetStackConfig", a3: v117, a4: v118); /*0x1067bf24c*/
  RBX::GameConfigurer::getParamString(a1: v966, a2: v1034, a3: v1049); /*0x1067bf266*/
  if ( ((__int64)v1049[0] & 1) != 0 ) /*0x1067bf272*/
    operator delete(a1: v1050); /*0x1067bf27b*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1067bf28e*/
    a1: (__int64)v1049,
    a2: (__int64)&RBX::Telemetry::kRbxTransportEphemeralEarlyPubKeyPlayerClientLoading);
  if ( (v966[0] & 1) != 0 ) /*0x1067bf29c*/
    v123 = v967; /*0x1067bf29e*/
  else
    v123 = (unsigned __int8)v966[0] >> 1; /*0x1067bf2a7*/
  if ( v123 != 0 )
  {
    RBX::RbxTransport::deserializeRbxTransportConfig(a1: __len, a2: v966); /*0x1067bf2bc*/
    if ( (__len[0] & 1) != 0 ) /*0x1067bf2cb*/
      v124 = __len[1]; /*0x1067bf2d1*/
    else
      v124 = LOBYTE(__len[0]) >> 1; /*0x1067bf385*/
    if ( v124 != 0 ) /*0x1067bf38a*/
    {
      if ( (__len[0] & 1) != 0 ) /*0x1067bf38f*/
        v125 = (char *)__len[2]; /*0x1067bf395*/
      else
        v125 = (char *)__len + 1; /*0x1067bf435*/
      v1031[0] = v125; /*0x1067bf443*/
      v1031[1] = (void *)v124; /*0x1067bf446*/
      fmt::v8::vformat( /*0x1067bf462*/
        a1: v1028,
        a2: "{{\"creationTime\":\"11:59 8/18/2025\",\"applications\":{{\"RbxTransportEphemeralEarlyPublicKey\":{{\"versions\""
        ":[{{\"id\":1,\"value\":\"{}\",\"allowed\":true}}],\"send\":1,\"revert\":1}}}}}}",
        a3: 169,
        a4: 13,
        a5: v1031);
      if ( (unsigned __int8)RBX::Security::KeyRing::parseConfig(a1: Instance) != 0 ) /*0x1067bf481*/
      {
        RBX::Telemetry::FieldsContainer::addField(a1: v1053, a2: "status", a3: 6, a4: "success", a5: 1); /*0x1067bf4a0*/
        if ( (unsigned __int8)DFLog::PlayerConfigurer >= 6u && BYTE1(DFLog::PlayerConfigurer) >= 5u ) /*0x1067bf4ba*/
        {
          v1031[0] = nullptr; /*0x1067bf4cc*/
          v1031[1] = v1054; /*0x1067bf4db*/
          v901 = *(_OWORD *)v1031; /*0x1067bf4ea*/
          FLog::detail::FastLogSafeFormattedInternal( /*0x1067bf507*/
            a1: DFLog::PlayerConfigurer,
            a2: qword_10D80BC08,
            a3: 5,
            a4: (unsigned int)"[DFLog::PlayerConfigurer] RbxTransportConfig ephemeralEarlyPublicKey loaded",
            a5: 75,
            a6: 1);
        }
      }
      else
      {
        RBX::Telemetry::FieldsContainer::addField(a1: v1053, a2: "status", a3: 6, a4: "parse error", a5: 1); /*0x1067bf52a*/
        if ( (unsigned __int8)DFLog::PlayerConfigurer >= 6u && BYTE1(DFLog::PlayerConfigurer) >= 5u ) /*0x1067bf544*/
        {
          v1031[0] = nullptr; /*0x1067bf552*/
          v1031[1] = v1054; /*0x1067bf561*/
          v901 = *(_OWORD *)v1031; /*0x1067bf570*/
          FLog::detail::FastLogSafeFormattedInternal( /*0x1067bf58d*/
            a1: DFLog::PlayerConfigurer,
            a2: qword_10D80BC08,
            a3: 5,
            a4: (unsigned int)"[DFLog::PlayerConfigurer] RbxTransportConfig ephemeralEarlyPublicKey parse error",
            a5: 80,
            a6: 1);
        }
      }
      if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067bf599*/
        operator delete(a1: v1029[0]); /*0x1067bf5a2*/
    }
    else
    {
      RBX::Telemetry::FieldsContainer::addField(a1: v1053, a2: "status", a3: 6, a4: "empty key", a5: 1); /*0x1067bf3c1*/
      if ( (unsigned __int8)DFLog::PlayerConfigurer >= 6u && BYTE1(DFLog::PlayerConfigurer) >= 5u ) /*0x1067bf3db*/
      {
        v1028[0] = nullptr; /*0x1067bf3ed*/
        v1028[1] = (std::__shared_weak_count *)v1031; /*0x1067bf3ff*/
        v901 = *(_OWORD *)v1028; /*0x1067bf40e*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x1067bf42b*/
          a1: DFLog::PlayerConfigurer,
          a2: qword_10D80BC08,
          a3: 5,
          a4: (unsigned int)"[DFLog::PlayerConfigurer] RbxTransportConfig has empty ephemeralEarlyPublicKey",
          a5: 78,
          a6: 1);
      }
    }
    if ( DFFlag::RbxTransportTakeServerCapabilitiesFromJoin == 1 )
    {
      v126 = (BYTE8(v1042) & 1) != 0 ? v1043 : (void *)(BYTE8(v1042) >> 1);
      if ( v126 != nullptr ) /*0x1067bf5cf*/
      {
        if ( (BYTE8(v1042) & 1) != 0 ) /*0x1067bf5d7*/
          v127 = (char *)v1044[0]; /*0x1067bf5d9*/
        else
          v127 = (char *)&v1042 + 9; /*0x1067bf5e2*/
        RBX::RbxTransport::parseCapabilitiesValue(a1: v1028, a2: v127); /*0x1067bf5f0*/
        if ( LOBYTE(v1028[1]) != 0 ) /*0x1067bf5fc*/
        {
          v129 = v1028[0]; /*0x1067bf5fe*/
          LOBYTE(v128) = 1; /*0x1067bf61d*/
          v1018 = v128; /*0x1067bf61f*/
          if ( (unsigned __int8)DFLog::PlayerConfigurer >= 6u && BYTE1(DFLog::PlayerConfigurer) >= 5u ) /*0x1067bf61a*/
          {
            v1028[0] = nullptr; /*0x1067bf635*/
            v1028[1] = (std::__shared_weak_count *)v1031; /*0x1067bf647*/
            v901 = *(_OWORD *)v1028; /*0x1067bf656*/
            FLog::detail::FastLogSafeFormattedInternal( /*0x1067bf673*/
              a1: DFLog::PlayerConfigurer,
              a2: qword_10D80BC08,
              a3: 5,
              a4: (unsigned int)"[DFLog::PlayerConfigurer] RbxTransportConfig server capabilities loaded from join reply",
              a5: 87,
              a6: 1);
          }
          goto LABEL_190; /*0x1067bf678*/
        }
        if ( (unsigned __int8)DFLog::PlayerConfigurer >= 6u && BYTE1(DFLog::PlayerConfigurer) >= 5u ) /*0x1067bf68f*/
        {
          v1028[0] = nullptr; /*0x1067bf69d*/
          v1028[1] = (std::__shared_weak_count *)v1031; /*0x1067bf6af*/
          v901 = *(_OWORD *)v1028; /*0x1067bf6be*/
          FLog::detail::FastLogSafeFormattedInternal( /*0x1067bf6db*/
            a1: DFLog::PlayerConfigurer,
            a2: qword_10D80BC08,
            a3: 5,
            a4: (unsigned int)"[DFLog::PlayerConfigurer] RbxTransportConfig server capabilities parse error",
            a5: 76,
            a6: 1);
        }
      }
    }
    v129 = nullptr; /*0x1067bf6e0*/
    v1018 = 0; /*0x1067bf6e2*/
LABEL_190:
    if ( (BYTE8(v1042) & 1) != 0 ) /*0x1067bf6f4*/
      operator delete(a1: v1044[0]); /*0x1067bf6fd*/
    if ( (__len[0] & 1) != 0 ) /*0x1067bf709*/
      operator delete(a1: (void *)__len[2]); /*0x1067bf712*/
    v999 = v129; /*0x1067bf717*/
    goto LABEL_195; /*0x1067bf717*/
  }
  RBX::Telemetry::FieldsContainer::addField(a1: v1053, a2: "status", a3: 6, a4: "empty config", a5: 1); /*0x1067bf2fd*/
  if ( (unsigned __int8)DFLog::PlayerConfigurer >= 6u && BYTE1(DFLog::PlayerConfigurer) >= 5u ) /*0x1067bf317*/
  {
    __len[0] = 0; /*0x1067bf325*/
    __len[1] = (size_t)v1028; /*0x1067bf337*/
    v901 = *(_OWORD *)__len; /*0x1067bf346*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x1067bf363*/
      a1: DFLog::PlayerConfigurer,
      a2: qword_10D80BC08,
      a3: 5,
      a4: (unsigned int)"[DFLog::PlayerConfigurer] RbxTransportConfig is empty",
      a5: 53,
      a6: 1);
  }
  v999 = nullptr; /*0x1067bf368*/
  v1018 = 0; /*0x1067bf373*/
LABEL_195:
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v1049); /*0x1067bf71e*/
  if ( v1034[81] == 1 ) /*0x1067bf735*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "MachineAddress", a3: v130, a4: v131); /*0x1067bf749*/
    RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1028); /*0x1067bf763*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "ServerPort", a3: v132, a4: v133); /*0x1067bf776*/
    ParamInt = RBX::GameConfigurer::getParamInt(a1: v1034, a2: v1031); /*0x1067bf789*/
    RBX::Analytics::setServerAddress(a1: __len, a2: ParamInt); /*0x1067bf797*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067bf7a3*/
      operator delete(a1: v1032); /*0x1067bf7ac*/
    if ( (__len[0] & 1) != 0 ) /*0x1067bf7b8*/
      operator delete(a1: (void *)__len[2]); /*0x1067bf7c1*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067bf7cd*/
      operator delete(a1: v1029[0]); /*0x1067bf7d6*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "UserId", a3: v130, a4: v131); /*0x1067bf7e9*/
  v135 = v1034; /*0x1067bf7f5*/
  *((_QWORD *)v135 + 9) = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: __len); /*0x1067bf804*/
  if ( (__len[0] & 1) != 0 ) /*0x1067bf80f*/
    operator delete(a1: (void *)__len[2]); /*0x1067bf818*/
  RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)v1028); /*0x1067bf824*/
  v136 = (_QWORD *)std::string::insert(a1: v1028, a2: 0, a3: "GameJoinStart,GameJoinStart"); /*0x1067bf839*/
  qmemcpy(__len, v136, sizeof(__len)); /*0x1067bf849*/
  *(_OWORD *)v136 = 0; /*0x1067bf859*/
  v136[2] = 0; /*0x1067bf85d*/
  RBX::PlayerConfigurer::reportCounter(a1: v137, a2: (__int64)__len, a3: 0); /*0x1067bf867*/
  if ( (__len[0] & 1) != 0 ) /*0x1067bf873*/
    operator delete(a1: (void *)__len[2]); /*0x1067bf87c*/
  if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067bf888*/
    operator delete(a1: v1029[0]); /*0x1067bf891*/
  RBX::Analytics::Event::DEPRECATED_trackEvent( /*0x1067bf8b0*/
    this: (RBX::Analytics::Event *)"Game",
    a2: "GameJoin",
    a3: "Start",
    a4: nullptr,
    a5: 0,
    a6: v138);
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "JoiningGame", a3: v139, a4: v140); /*0x1067bf8c3*/
  RBX::Stats::reportGameStatus(a1: __len, a2: 0); /*0x1067bf8d1*/
  if ( (__len[0] & 1) != 0 ) /*0x1067bf8dd*/
    operator delete(a1: (void *)__len[2]); /*0x1067bf8e6*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "ClientTicket", a3: v141, a4: v142); /*0x1067bf8f9*/
  RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1028); /*0x1067bf913*/
  v1015 = v1034 + 48; /*0x1067bf92d*/
  if ( (__len[0] & 1) != 0 ) /*0x1067bf920*/
  {
    v1034[48] = __len[1] == 0; /*0x1067bf956*/
    operator delete(a1: (void *)__len[2]); /*0x1067bf961*/
  }
  else
  {
    v1034[48] = LOBYTE(__len[0]) == 0; /*0x1067bf936*/
  }
  if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067bf96d*/
    operator delete(a1: v1029[0]); /*0x1067bf976*/
  v143 = rand() % 100 == 1; /*0x1067bf99b*/
  v144 = v1034; /*0x1067bf99e*/
  v1034[49] = v143; /*0x1067bf9a5*/
  RBX::ServiceProvider::create<RBX::Network::Client>(this: (RBX::ServiceProvider *)(*((_QWORD *)v144 + 3) + 464LL)); /*0x1067bf9b7*/
  v145 = (RBX::TeleportService *)RBX::ServiceProvider::find<RBX::TeleportService>( /*0x1067bf9cc*/
                                   a1: *((_QWORD *)v1034 + 3) + 464LL,
                                   a2: 0);
  v148 = v145; /*0x1067bf9d1*/
  if ( v145 != nullptr )
  {
    if ( RBX::TeleportService::getPreviousPlaceId(this: v145) > 0 )
    {
      v149 = RBX::Subsystem<RBX::SessionTransitionFSM,false>::startup<RBX::SubsystemDefaultFactory<RBX::SessionTransitionFSM>>(); /*0x1067bf9ea*/
      v150 = v149; /*0x1067bf9ef*/
      v151 = v149 != 0 ? *(RBX::SessionTransitionFSM **)(v149 + 24) : nullptr;
      RBX::SessionTransitionFSM::setTeleported(this: v151, a2: true); /*0x1067bfa04*/
      if ( v150 != 0 ) /*0x1067bfa0c*/
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v150 + 16LL))(a1: v150); /*0x1067bfa14*/
    }
    if ( DFFlag::DebugCheckSessionMetricTeleportCondition == 1 ) /*0x1067bfa1e*/
    {
      v152 = RBX::ClientSessionTrackerKeys::DebugPlayerConfigurerTeleported; /*0x1067bfa2b*/
      v153 = unk_10D511BB0; /*0x1067bfa2e*/
      v920 = RBX::ClientSessionTrackerKeys::DebugPlayerConfigurerTeleported; /*0x1067bfa32*/
      v921 = (std::__shared_weak_count *)unk_10D511BB0; /*0x1067bfa39*/
      if ( unk_10D511BB0 != 0 ) /*0x1067bfa43*/
        _InterlockedIncrement64((volatile signed __int64 *)(unk_10D511BB0 + 8LL)); /*0x1067bfa45*/
      v154 = RBX::TeleportService::didTeleport(this: v148); /*0x1067bfa52*/
      v156 = RBX::ClientSessionTracker::ClientSessionTrackerContext::getInstance(this: v155); /*0x1067bfa54*/
      __len[0] = v152; /*0x1067bfa59*/
      __len[1] = v153; /*0x1067bfa60*/
      if ( v153 != 0 ) /*0x1067bfa6a*/
        _InterlockedIncrement64((volatile signed __int64 *)(v153 + 8)); /*0x1067bfa6c*/
      RBX::ClientSessionTracker::ClientSessionTrackerContext::updateClientSessionMetric<bool,false>( /*0x1067bfa80*/
        a1: v156,
        a2: __len,
        a3: v154,
        a4: 0);
      v157 = (std::__shared_weak_count *)__len[1]; /*0x1067bfa85*/
      if ( __len[1] != 0 /*0x1067bfaa1*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)(__len[1] + 8), 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v157 + 16LL))(a1: v157); /*0x1067bfaa9*/
        std::__shared_weak_count::__release_weak(this: v157); /*0x1067bfaaf*/
      }
      v158 = v921; /*0x1067bfab4*/
      if ( v921 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v921 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067bfad0*/
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v158 + 16LL))(a1: v158); /*0x1067bfad8*/
        std::__shared_weak_count::__release_weak(this: v158); /*0x1067bfade*/
      }
    }
  }
  v159 = v1034; /*0x1067bfae3*/
  v160 = *((RBX::UniverseConfigurator **)v1034 + 3); /*0x1067bfaea*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "UniverseId", a3: v146, a4: v147); /*0x1067bfafc*/
  ParamInt64 = (RBX::DataModel *)RBX::GameConfigurer::getParamInt64(a1: v159, a2: __len); /*0x1067bfb10*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "PlaceId", a3: v162, a4: v163); /*0x1067bfb21*/
  v164 = (FLog *)RBX::GameConfigurer::getParamInt64(a1: v1034, a2: v1028); /*0x1067bfb39*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "DataCenterId", a3: v165, a4: v166); /*0x1067bfb4a*/
  v167 = RBX::GameConfigurer::getParamInt(a1: v1034, a2: v1031); /*0x1067bfb5d*/
  RBX::UniverseConfigurator::setUniverseIdPlaceIdAndDataCenterId( /*0x1067bfb6d*/
    this: v160,
    a2: ParamInt64,
    a3: v164,
    a4: v167,
    a5: v168);
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067bfb79*/
    operator delete(a1: v1032); /*0x1067bfb82*/
  if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067bfb8e*/
    operator delete(a1: v1029[0]); /*0x1067bfb97*/
  if ( (__len[0] & 1) != 0 ) /*0x1067bfba3*/
    operator delete(a1: (void *)__len[2]); /*0x1067bfbac*/
  v171 = v1034; /*0x1067bfbb1*/
  v172 = *((RBX::DataModelPlaceVersion **)v1034 + 3); /*0x1067bfbb8*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "PlaceVersion", a3: v169, a4: v170); /*0x1067bfbca*/
  v173 = RBX::GameConfigurer::getParamInt(a1: v171, a2: __len); /*0x1067bfbd9*/
  RBX::DataModelPlaceVersion::setPlaceVersion(this: v172, a2: (RBX::DataModel *)v173, a3: v174); /*0x1067bfbe3*/
  if ( (__len[0] & 1) != 0 ) /*0x1067bfbef*/
    operator delete(a1: (void *)__len[2]); /*0x1067bfbf8*/
  RBX::GameConfigurer::getParamString(a1: &v1011, a2: v1034, a3: &FString::AnalyticsSessionIdName); /*0x1067bfc12*/
  if ( (v1011 & 1) != 0 ) /*0x1067bfc20*/
    v177 = v1013; /*0x1067bfc22*/
  else
    v177 = v1011 >> 1; /*0x1067bfc2b*/
  if ( v177 != 0 && v1034[81] == 1 ) /*0x1067bfc41*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "sid", a3: v175, a4: v176); /*0x1067bfc55*/
    RBX::Analytics::EventIngest::addCommonArg(a1: __len, a2: &v1011); /*0x1067bfc68*/
    if ( (__len[0] & 1) != 0 ) /*0x1067bfc74*/
      operator delete(a1: (void *)__len[2]); /*0x1067bfc7d*/
    if ( (unsigned __int8)FLog::Output >= 6u && BYTE1(FLog::Output) >= 3u ) /*0x1067bfc9b*/
    {
      if ( (v1011 & 1) != 0 ) /*0x1067bfcad*/
        LODWORD(v180) = (_DWORD)v1014; /*0x1067bfcaf*/
      else
        v180 = v1012; /*0x1067bfcb8*/
      FLog::FastLogFormatted( /*0x1067bfcc8*/
        a1: FLog::Output,
        a2: qword_10D7BE938,
        a3: (unsigned int)"[FLog::Output] AnalyticsSessionId is %s.",
        a4: (_DWORD)v180,
        a5: v178,
        a6: v179);
    }
  }
  RBX::DataModel::setContextAttribute(a1: v1022, a2: 7, a3: &v1011); /*0x1067bfce0*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "UniverseId", a3: v181, a4: v182); /*0x1067bfcf3*/
  v1017 = COERCE_DOUBLE(RBX::GameConfigurer::getParamInt64(a1: v1034, a2: __len)); /*0x1067bfd0e*/
  if ( (__len[0] & 1) != 0 ) /*0x1067bfd1c*/
    operator delete(a1: (void *)__len[2]); /*0x1067bfd25*/
  RBX::ServiceProvider::create<RBX::HttpService>(a1: *((_QWORD *)v1034 + 3) + 464LL, a2: 0); /*0x1067bfd3c*/
  if ( FFlag::ReplaceTouchEnabled == 0 ) /*0x1067bfd4b*/
  {
    v183 = RBX::ServiceProvider::create<RBX::UserInputService>(this: (RBX::ServiceProvider *)(v1022 + 58)); /*0x1067bfd5d*/
    TouchEnabled = RBX::UserInputServiceProp::getTouchEnabled(this: (RBX::UserInputServiceProp *)(v183 + 192)); /*0x1067bfd6b*/
    v1034[50] = TouchEnabled; /*0x1067bfd77*/
  }
  v185 = (RBX::TeleportService *)RBX::ServiceProvider::find<RBX::TeleportService>( /*0x1067bfd8c*/
                                   a1: *((_QWORD *)v1034 + 3) + 464LL,
                                   a2: 0);
  if ( v185 != nullptr ) /*0x1067bfd94*/
    RBX::TeleportService::updateRootPlaceInfo( /*0x1067bfdb2*/
      this: v185,
      a2: *(_QWORD *)(*((_QWORD *)v1034 + 3) + 840LL),
      a3: *(_QWORD *)(*((_QWORD *)v1034 + 3) + 832LL));
  v187 = FLog::Output; /*0x1067bfdbe*/
  v188 = (unsigned int)FLog::Output >> 8; /*0x1067bfdc3*/
  LOBYTE(v186) = (unsigned __int8)FLog::Output < 6u; /*0x1067bfdc9*/
  LOBYTE(v188) = (unsigned __int8)FLog::Output < 6u || BYTE1(FLog::Output) < 3u; /*0x1067bfdd2*/
  if ( (_BYTE)v188 == 0 ) /*0x1067bfdd4*/
  {
    v189 = qword_10D7BE938; /*0x1067bfdda*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "GameId", a3: v186, a4: v188); /*0x1067bfdec*/
    RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1028); /*0x1067bfe06*/
    if ( (__len[0] & 1) != 0 ) /*0x1067bfe12*/
      LODWORD(v192) = __len[2]; /*0x1067bfe14*/
    else
      v192 = (char *)__len + 1; /*0x1067bfe1d*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "PlaceId", a3: v190, a4: v191); /*0x1067bfe32*/
    v193 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: v1031); /*0x1067bfe4a*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1026, a2: "MachineAddress", a3: v194, a4: v195); /*0x1067bfe5b*/
    RBX::GameConfigurer::getParamString(a1: v1054, a2: v1034, a3: v1026); /*0x1067bfe72*/
    if ( (v1054[0] & 1) != 0 ) /*0x1067bfe7b*/
      LODWORD(v196) = (_DWORD)v1055; /*0x1067bfe7d*/
    else
      v196 = (char *)v1054 + 1; /*0x1067bfe83*/
    FLog::FastLogFormatted( /*0x1067bfe9c*/
      a1: v187,
      a2: v189,
      a3: (unsigned int)"[FLog::Output] ! Joining game '%s' place %lld at %s",
      a4: (_DWORD)v192,
      a5: v193,
      a6: (_DWORD)v196);
    if ( (v1054[0] & 1) != 0 ) /*0x1067bfea5*/
      operator delete(a1: v1055); /*0x1067bfeab*/
    if ( ((__int64)v1026[0] & 1) != 0 ) /*0x1067bfeb7*/
      operator delete(a1: v1027); /*0x1067bfec0*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067bfecc*/
      operator delete(a1: v1032); /*0x1067bfed5*/
    if ( (__len[0] & 1) != 0 ) /*0x1067bfee1*/
      operator delete(a1: (void *)__len[2]); /*0x1067bfeea*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067bfef6*/
      operator delete(a1: v1029[0]); /*0x1067bfeff*/
  }
  v197 = v1023; /*0x1067bff04*/
  if ( *(double *)&v1023 != 0.0 )
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "PlaceId", a3: v186, a4: v188); /*0x1067bff1f*/
    v198 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: v1054); /*0x1067bff2f*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: v1031, a2: v198); /*0x1067bff3e*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "placeid", a3: v199, a4: v200); /*0x1067bff4d*/
    v1043 = v1032; /*0x1067bff60*/
    v1042 = *(_OWORD *)v1031; /*0x1067bff6c*/
    *(_OWORD *)v1031 = 0; /*0x1067bff76*/
    v1032 = nullptr; /*0x1067bff7e*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: v1026, a2: *(_QWORD *)&v1017); /*0x1067bff97*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1044, a2: "universeid", a3: v201, a4: v202); /*0x1067bffa6*/
    v1044[5] = v1027; /*0x1067bffb9*/
    *(_OWORD *)&v1044[3] = *(_OWORD *)v1026; /*0x1067bffc5*/
    *(_OWORD *)v1026 = 0; /*0x1067bffcf*/
    v1027 = nullptr; /*0x1067bffd7*/
    std::pair<std::string const,std::string>::pair[abi:ne200100]<char const(&)[14],std::string const&,0>( /*0x1067bfff6*/
      a1: v1045,
      a2: "referral_page",
      a3: (char *)v197 + 248);
    RBX::StringConverter_detail::BasicTypeStringable<double>::toString(a1: &__dst, a2: *((double *)v1034 + 26)); /*0x1067c0018*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1046, a2: "join_time", a3: v203, a4: v204); /*0x1067c0027*/
    v1046[5] = v1025; /*0x1067c003a*/
    *(_OWORD *)&v1046[3] = __dst; /*0x1067c0046*/
    __dst = 0; /*0x1067c0050*/
    v1025 = nullptr; /*0x1067c0058*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: v1020, a2: *((_QWORD *)v1034 + 9)); /*0x1067c0075*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1047, a2: "userid", a3: v205, a4: v206); /*0x1067c0084*/
    v1047[5] = v1021; /*0x1067c0097*/
    *(_OWORD *)&v1047[3] = *(_OWORD *)v1020; /*0x1067c00a3*/
    *(_OWORD *)v1020 = 0; /*0x1067c00ad*/
    v1021 = nullptr; /*0x1067c00b5*/
    v208 = RBX::Time::epochTimeMs(this: v207); /*0x1067c00c0*/
    RBX::StringConverter_detail::BasicTypeStringable<double>::toString(a1: &v1009, a2: (double)v208 / 1000.0); /*0x1067c00dc*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1048, a2: "clienttime", a3: v209, a4: v210); /*0x1067c00eb*/
    v1048[5] = v1010; /*0x1067c00fe*/
    *(_OWORD *)&v1048[3] = v1009; /*0x1067c010d*/
    v1009 = 0; /*0x1067c0119*/
    v1010 = nullptr; /*0x1067c0121*/
    std::unordered_map<std::string,std::string>::unordered_map(a1: v1028, a2: __len, a3: 6); /*0x1067c0138*/
    for ( i = 36; i != 0; i -= 6 ) /*0x1067c013d*/
    {
      if ( (v1038[i * 8 + 8] & 1) != 0 ) /*0x1067c014a*/
        operator delete(a1: (void *)__len[i - 1]); /*0x1067c0154*/
      if ( (v1037[i] & 1) != 0 ) /*0x1067c0161*/
        operator delete(a1: *(void **)&v1038[i * 8]); /*0x1067c016b*/
    }
    if ( (v1009 & 1) != 0 ) /*0x1067c017d*/
      operator delete(a1: v1010); /*0x1067c0186*/
    if ( ((__int64)v1020[0] & 1) != 0 ) /*0x1067c0192*/
      operator delete(a1: v1021); /*0x1067c019b*/
    if ( (__dst & 1) != 0 ) /*0x1067c01a7*/
      operator delete(a1: v1025); /*0x1067c01b0*/
    if ( ((__int64)v1026[0] & 1) != 0 ) /*0x1067c01bc*/
      operator delete(a1: v1027); /*0x1067c01c5*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c01d1*/
      operator delete(a1: v1032); /*0x1067c01da*/
    if ( (v1054[0] & 1) != 0 ) /*0x1067c01e3*/
      operator delete(a1: v1055); /*0x1067c01e9*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "sid", a3: v211, a4: v212); /*0x1067c01fc*/
    RBX::Analytics::EventIngest::appendCommonArg(a1: __len, a2: v1028); /*0x1067c020f*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c021b*/
      operator delete(a1: (void *)__len[2]); /*0x1067c0224*/
    std::string::basic_string[abi:ne200100]<0>(a1: v922, a2: "client", a3: v214, a4: v215); /*0x1067c0237*/
    std::string::basic_string[abi:ne200100]<0>(a1: v924, a2: "report", a3: v216, a4: v217); /*0x1067c024a*/
    std::string::basic_string[abi:ne200100]<0>(a1: v926, a2: "game_join_loadtime", a3: v218, a4: v219); /*0x1067c025d*/
    std::unordered_map<std::string,std::string>::unordered_map(a1: v906, a2: v1028); /*0x1067c0270*/
    RBX::Analytics::EventIngest::setRBXEventStream(a1: v922, a2: v924, a3: v926, a4: v906); /*0x1067c0291*/
    std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v906); /*0x1067c029d*/
    if ( (v926[0] & 1) != 0 ) /*0x1067c02a9*/
      operator delete(a1: v927); /*0x1067c02b2*/
    if ( (v924[0] & 1) != 0 ) /*0x1067c02be*/
      operator delete(a1: v925); /*0x1067c02c7*/
    if ( (v922[0] & 1) != 0 ) /*0x1067c02d3*/
      operator delete(a1: v923); /*0x1067c02dc*/
    if ( (_BYTE)FLog::GameJoinLoadTime != 0 )
    {
      *(_OWORD *)v1031 = 0; /*0x1067c02f2*/
      v1032 = nullptr; /*0x1067c02fa*/
      v224 = v1029[0]; /*0x1067c0305*/
      if ( v1029[0] != nullptr ) /*0x1067c030f*/
      {
        do /*0x1067c04b7*/
        {
          std::pair<std::string const,std::string>::pair[abi:ne200100]( /*0x1067c032e*/
            a1: __len,
            a2: v224 + 2,
            a3: v220,
            a4: v221,
            a5: v222,
            a6: v223,
            a7: v901,
            a8: *((_QWORD *)&v901 + 1),
            a9: v902,
            a10: v903,
            a11: v904);
          if ( (__len[0] & 1) != 0 ) /*0x1067c033f*/
            v225 = __len[1]; /*0x1067c0341*/
          else
            v225 = LOBYTE(__len[0]) >> 1; /*0x1067c034a*/
          std::string::basic_string[abi:ne200100](a1: &__dst, a2: v225 + 1); /*0x1067c035b*/
          v226 = (char *)&__dst + 1; /*0x1067c0367*/
          if ( (__dst & 1) != 0 ) /*0x1067c036e*/
            v226 = (char *)v1025; /*0x1067c0370*/
          if ( v225 != 0 ) /*0x1067c037a*/
          {
            v227 = (char *)__len + 1; /*0x1067c0383*/
            if ( (__len[0] & 1) != 0 ) /*0x1067c038a*/
              v227 = (char *)__len[2]; /*0x1067c038c*/
            memmove(__dst: v226, __src: v227, __len: v225); /*0x1067c0399*/
          }
          *(_WORD *)&v226[v225] = 58; /*0x1067c039e*/
          if ( (v1042 & 1) != 0 ) /*0x1067c03af*/
          {
            v228 = (char *)v1043; /*0x1067c03b1*/
            v229 = *((_QWORD *)&v1042 + 1); /*0x1067c03b8*/
          }
          else
          {
            v229 = (unsigned __int8)v1042 >> 1; /*0x1067c03c1*/
            v228 = (char *)&v1042 + 1; /*0x1067c03c3*/
          }
          v230 = std::string::append(a1: &__dst, a2: v228, a3: v229); /*0x1067c03cd*/
          v1027 = *(void **)(v230 + 16); /*0x1067c03d6*/
          *(_OWORD *)v1026 = *(_OWORD *)v230; /*0x1067c03e1*/
          *(_OWORD *)v230 = 0; /*0x1067c03ed*/
          *(_QWORD *)(v230 + 16) = 0; /*0x1067c03f1*/
          v231 = std::string::append(a1: v1026, a2: ", "); /*0x1067c0407*/
          v1055 = *(RBX::Time **)(v231 + 16); /*0x1067c0410*/
          *(_OWORD *)v1054 = *(_OWORD *)v231; /*0x1067c0418*/
          *(_OWORD *)v231 = 0; /*0x1067c0421*/
          *(_QWORD *)(v231 + 16) = 0; /*0x1067c0425*/
          if ( (v1054[0] & 1) != 0 ) /*0x1067c0434*/
          {
            v232 = v1055; /*0x1067c0436*/
            v233 = v1054[1]; /*0x1067c043a*/
          }
          else
          {
            v233 = LOBYTE(v1054[0]) >> 1; /*0x1067c0440*/
            v232 = (RBX::Time *)((char *)v1054 + 1); /*0x1067c0442*/
          }
          std::string::append(a1: v1031, a2: v232, a3: v233); /*0x1067c0449*/
          if ( (v1054[0] & 1) != 0 ) /*0x1067c0452*/
            operator delete(a1: v1055); /*0x1067c0458*/
          if ( ((__int64)v1026[0] & 1) != 0 ) /*0x1067c0464*/
            operator delete(a1: v1027); /*0x1067c046d*/
          if ( (__dst & 1) != 0 ) /*0x1067c0479*/
            operator delete(a1: v1025); /*0x1067c0482*/
          if ( (v1042 & 1) != 0 ) /*0x1067c048e*/
            operator delete(a1: v1043); /*0x1067c0497*/
          if ( (__len[0] & 1) != 0 ) /*0x1067c04a3*/
            operator delete(a1: (void *)__len[2]); /*0x1067c04ac*/
          v224 = (_QWORD *)*v224; /*0x1067c04b1*/
        }
        while ( v224 != nullptr ); /*0x1067c04b7*/
        v234 = (char)v1031[0]; /*0x1067c04bd*/
      }
      else
      {
        v234 = 0; /*0x1067c04c5*/
      }
      if ( (unsigned __int8)FLog::GameJoinLoadTime >= 6u && BYTE1(FLog::GameJoinLoadTime) >= 3u )
      {
        if ( (v234 & 1) != 0 ) /*0x1067c04ed*/
          LODWORD(v235) = (_DWORD)v1032; /*0x1067c04ef*/
        else
          v235 = (char *)v1031 + 1; /*0x1067c04f8*/
        FLog::FastLogFormatted(
          a1: FLog::GameJoinLoadTime,
          a2: qword_10D80B750,
          a3: (unsigned int)"[FLog::GameJoinLoadTime] Report game_join_loadtime: %s",
          a4: (_DWORD)v235,
          a5: v222,
          a6: v223);
        v234 = (char)v1031[0]; /*0x1067c050d*/
      }
      if ( (v234 & 1) != 0 ) /*0x1067c0515*/
        operator delete(a1: v1032); /*0x1067c051e*/
    }
    std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v1028); /*0x1067c052a*/
  }
  if ( FFlag::MigrateGameJoinPlaySessionV2Telemetry == 1 ) /*0x1067c0536*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)1,std::enable_if<true,void>>( /*0x1067c054a*/
      a1: __len,
      a2: &RBX::Telemetry::kGameJoinPlaySessionEvent);
    RBX::Telemetry::RobloxTelemetryEvent::setContextForEventIngest(a1: __len, a2: "report", a3: 6); /*0x1067c0562*/
    RBX::Telemetry::RobloxTelemetryEvent::LEGACY_overrideTargetForEventIngest(a1: __len, a2: "client", a3: 6); /*0x1067c057a*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "PlaceId", a3: v236, a4: v237); /*0x1067c058d*/
    v238 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: v1031); /*0x1067c05a0*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: v1028, a2: v238); /*0x1067c05af*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c05c7*/
    {
      v239 = (char *)v1029[0]; /*0x1067c05cd*/
      v240 = v1028[1]; /*0x1067c05d4*/
    }
    else
    {
      v240 = (std::__shared_weak_count *)(LOBYTE(v1028[0]) >> 1); /*0x1067c0905*/
      v239 = (char *)v1028 + 1; /*0x1067c0908*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: &v1044[3], a2: "placeid", a3: 7, a4: v239, a5: v240, a6: 1); /*0x1067c0924*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c0930*/
      operator delete(a1: v1029[0]); /*0x1067c0939*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c0945*/
      operator delete(a1: v1032); /*0x1067c094e*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: v1028, a2: *(_QWORD *)&v1017); /*0x1067c0961*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c0972*/
    {
      v263 = (char *)v1029[0]; /*0x1067c0974*/
      v264 = v1028[1]; /*0x1067c097b*/
    }
    else
    {
      v264 = (std::__shared_weak_count *)(LOBYTE(v1028[0]) >> 1); /*0x1067c0984*/
      v263 = (char *)v1028 + 1; /*0x1067c0987*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: &v1044[3], a2: "universeid", a3: 10, a4: v263, a5: v264, a6: 1); /*0x1067c09a3*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c09af*/
      operator delete(a1: v1029[0]); /*0x1067c09b8*/
    if ( (v1011 & 1) != 0 ) /*0x1067c09c9*/
    {
      v265 = v1014; /*0x1067c09cb*/
      v266 = v1013; /*0x1067c09d2*/
    }
    else
    {
      v266 = v1011 >> 1; /*0x1067c09db*/
      v265 = v1012; /*0x1067c09de*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: &v1044[3], a2: "sid", a3: 3, a4: v265, a5: v266, a6: 1); /*0x1067c09fa*/
    RBX::SessionManager::instance(this: (RBX::SessionManager *)v1028); /*0x1067c0a06*/
    v267 = (char *)v1028[0] + 8; /*0x1067c0a19*/
    if ( v1028[0] == nullptr ) /*0x1067c0a20*/
      v267 = nullptr; /*0x1067c0a20*/
    v906[5] = v267; /*0x1067c0a2b*/
    v907 = v1028[1]; /*0x1067c0a2e*/
    *(_OWORD *)v1028 = 0; /*0x1067c0a36*/
    RBX::Telemetry::FieldsContainer::addSessionInfoFromSessionManager(a1: &v1044[3]); /*0x1067c0a41*/
    v270 = v907; /*0x1067c0a46*/
    if ( v907 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v907 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067c0a62*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v270 + 16LL))(a1: v270); /*0x1067c0a6a*/
      std::__shared_weak_count::__release_weak(this: v270); /*0x1067c0a70*/
    }
    v271 = v1028[1]; /*0x1067c0a75*/
    if ( v1028[1] != nullptr /*0x1067c0a91*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v1028[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v271 + 16LL))(a1: v271); /*0x1067c0a99*/
      std::__shared_weak_count::__release_weak(this: v271); /*0x1067c0a9f*/
    }
    if ( FFlag::IncludeActionTypeInPlaySession == 1 ) /*0x1067c0aab*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "IsDemo", a3: v268, a4: v269); /*0x1067c0abb*/
      ParamBool = RBX::GameConfigurer::getParamBool(a1: v1034, a2: v1028); /*0x1067c0ad3*/
      if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c0adc*/
        operator delete(a1: v1029[0]); /*0x1067c0ae5*/
      if ( ParamBool != 0 ) /*0x1067c0aec*/
        RBX::Telemetry::FieldsContainer::addField(a1: &v1044[3], a2: "actionType", a3: 10, a4: "DemoPlaySession", a5: 1); /*0x1067c0b0a*/
    }
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)__len); /*0x1067c0b16*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)__len); /*0x1067c0b29*/
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "PlaceId", a3: v186, a4: v188); /*0x1067c05eb*/
    v241 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: v1054); /*0x1067c05fb*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: v1031, a2: v241); /*0x1067c060a*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "placeid", a3: v242, a4: v243); /*0x1067c0620*/
    v1043 = v1032; /*0x1067c0633*/
    v1042 = *(_OWORD *)v1031; /*0x1067c063f*/
    *(_OWORD *)v1031 = 0; /*0x1067c0648*/
    v1032 = nullptr; /*0x1067c0650*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: v1026, a2: *(_QWORD *)&v1017); /*0x1067c0669*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1044, a2: "universeid", a3: v244, a4: v245); /*0x1067c0678*/
    v1044[5] = v1027; /*0x1067c068b*/
    *(_OWORD *)&v1044[3] = *(_OWORD *)v1026; /*0x1067c0697*/
    *(_OWORD *)v1026 = 0; /*0x1067c06a0*/
    v1027 = nullptr; /*0x1067c06a8*/
    std::unordered_map<std::string,std::string>::unordered_map(a1: v1028, a2: __len, a3: 2); /*0x1067c06bf*/
    for ( j = 12; j != 0; j -= 6 ) /*0x1067c06c4*/
    {
      if ( (v1038[j * 8 + 8] & 1) != 0 ) /*0x1067c06d1*/
        operator delete(a1: (void *)__len[j - 1]); /*0x1067c06db*/
      if ( (v1037[j] & 1) != 0 ) /*0x1067c06e8*/
        operator delete(a1: *(void **)&v1038[j * 8]); /*0x1067c06f2*/
    }
    if ( ((__int64)v1026[0] & 1) != 0 ) /*0x1067c0704*/
      operator delete(a1: v1027); /*0x1067c070d*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c0719*/
      operator delete(a1: v1032); /*0x1067c0722*/
    if ( (v1054[0] & 1) != 0 ) /*0x1067c072b*/
      operator delete(a1: v1055); /*0x1067c0731*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "sid", a3: v246, a4: v247); /*0x1067c0744*/
    RBX::Analytics::EventIngest::appendCommonArg(a1: __len, a2: v1028); /*0x1067c0757*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c0763*/
      operator delete(a1: (void *)__len[2]); /*0x1067c076c*/
    if ( FFlag::IncludeActionTypeInPlaySession == 1 ) /*0x1067c0778*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "IsDemo", a3: v249, a4: v250); /*0x1067c078c*/
      v253 = RBX::GameConfigurer::getParamBool(a1: v1034, a2: __len); /*0x1067c07a4*/
      if ( (__len[0] & 1) != 0 ) /*0x1067c07ad*/
        operator delete(a1: (void *)__len[2]); /*0x1067c07b6*/
      if ( v253 != 0 ) /*0x1067c07bd*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "actionType", a3: v251, a4: v252); /*0x1067c07d0*/
        v1031[0] = __len; /*0x1067c07dc*/
        v254 = std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c07f4*/
                 a1: v1028,
                 a2: __len,
                 a3: std::piecewise_construct,
                 a4: v1031,
                 a5: v1054);
        std::string::assign(a1: v254 + 40, a2: "DemoPlaySession"); /*0x1067c0807*/
        if ( (__len[0] & 1) != 0 ) /*0x1067c0813*/
          operator delete(a1: (void *)__len[2]); /*0x1067c081c*/
      }
    }
    RBX::SessionizedEventIngest::instance(this: (RBX::SessionizedEventIngest *)v1026); /*0x1067c0828*/
    v255 = v1026[0]; /*0x1067c082d*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "client", a3: v256, a4: v257); /*0x1067c0842*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "report", a3: v258, a4: v259); /*0x1067c0855*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "gameJoinPlaySession", a3: v260, a4: v261); /*0x1067c0865*/
    (*(void (__fastcall **)(std::__shared_weak_count *, size_t *, void **, __int64 *, std::__shared_weak_count **))(*(_QWORD *)v255 + 24LL))( /*0x1067c0889*/
      a1: v255,
      a2: __len,
      a3: v1031,
      a4: v1054,
      a5: v1028);
    if ( (v1054[0] & 1) != 0 ) /*0x1067c0890*/
      operator delete(a1: v1055); /*0x1067c0896*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c08a2*/
      operator delete(a1: v1032); /*0x1067c08ab*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c08b7*/
      operator delete(a1: (void *)__len[2]); /*0x1067c08c0*/
    v262 = v1026[1]; /*0x1067c08c5*/
    if ( v1026[1] != nullptr /*0x1067c08e1*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v1026[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v262 + 16LL))(a1: v262); /*0x1067c08e9*/
      std::__shared_weak_count::__release_weak(this: v262); /*0x1067c08ef*/
    }
    std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v1028); /*0x1067c08fb*/
  }
  if ( FFlag::GameJoinPlaySessionShadowTelemetry == 1 ) /*0x1067c0b35*/
  {
    RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)1,std::enable_if<true,void>>( /*0x1067c0b49*/
      a1: __len,
      a2: &RBX::Telemetry::kGameJoinPlaySessionShadowEvent);
    RBX::Telemetry::RobloxTelemetryEvent::setContextForEventIngest(a1: __len, a2: "report", a3: 6); /*0x1067c0b61*/
    RBX::Telemetry::RobloxTelemetryEvent::LEGACY_overrideTargetForEventIngest(a1: __len, a2: "client", a3: 6); /*0x1067c0b79*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "PlaceId", a3: v273, a4: v274); /*0x1067c0b8c*/
    v275 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: v1031); /*0x1067c0b9f*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: v1028, a2: v275); /*0x1067c0bae*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c0bc6*/
    {
      v276 = (char *)v1029[0]; /*0x1067c0bc8*/
      v277 = v1028[1]; /*0x1067c0bcf*/
    }
    else
    {
      v277 = (std::__shared_weak_count *)(LOBYTE(v1028[0]) >> 1); /*0x1067c0bd8*/
      v276 = (char *)v1028 + 1; /*0x1067c0bdb*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: &v1044[3], a2: "placeid", a3: 7, a4: v276, a5: v277, a6: 1); /*0x1067c0bf7*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c0c03*/
      operator delete(a1: v1029[0]); /*0x1067c0c0c*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c0c18*/
      operator delete(a1: v1032); /*0x1067c0c21*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: v1028, a2: *(_QWORD *)&v1017); /*0x1067c0c34*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c0c45*/
    {
      v278 = (char *)v1029[0]; /*0x1067c0c47*/
      v279 = v1028[1]; /*0x1067c0c4e*/
    }
    else
    {
      v279 = (std::__shared_weak_count *)(LOBYTE(v1028[0]) >> 1); /*0x1067c0c57*/
      v278 = (char *)v1028 + 1; /*0x1067c0c5a*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: &v1044[3], a2: "universeid", a3: 10, a4: v278, a5: v279, a6: 1); /*0x1067c0c76*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c0c82*/
      operator delete(a1: v1029[0]); /*0x1067c0c8b*/
    if ( (v1011 & 1) != 0 ) /*0x1067c0c9c*/
    {
      v280 = v1014; /*0x1067c0c9e*/
      v281 = v1013; /*0x1067c0ca5*/
    }
    else
    {
      v281 = v1011 >> 1; /*0x1067c0cae*/
      v280 = v1012; /*0x1067c0cb1*/
    }
    RBX::Telemetry::FieldsContainer::addField(a1: &v1044[3], a2: "sid", a3: 3, a4: v280, a5: v281, a6: 1); /*0x1067c0ccd*/
    RBX::SessionManager::instance(this: (RBX::SessionManager *)v1028); /*0x1067c0cd9*/
    v282 = (char *)v1028[0] + 8; /*0x1067c0cec*/
    if ( v1028[0] == nullptr ) /*0x1067c0cf3*/
      v282 = nullptr; /*0x1067c0cf3*/
    v908 = v282; /*0x1067c0cfe*/
    v909 = v1028[1]; /*0x1067c0d01*/
    *(_OWORD *)v1028 = 0; /*0x1067c0d09*/
    RBX::Telemetry::FieldsContainer::addSessionInfoFromSessionManager(a1: &v1044[3]); /*0x1067c0d14*/
    v285 = v909; /*0x1067c0d19*/
    if ( v909 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v909 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067c0d35*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v285 + 16LL))(a1: v285); /*0x1067c0d3d*/
      std::__shared_weak_count::__release_weak(this: v285); /*0x1067c0d43*/
    }
    v286 = v1028[1]; /*0x1067c0d48*/
    if ( v1028[1] != nullptr /*0x1067c0d64*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v1028[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v286 + 16LL))(a1: v286); /*0x1067c0d6c*/
      std::__shared_weak_count::__release_weak(this: v286); /*0x1067c0d72*/
    }
    if ( FFlag::IncludeActionTypeInPlaySession == 1 ) /*0x1067c0d7e*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "IsDemo", a3: v283, a4: v284); /*0x1067c0d8e*/
      v287 = RBX::GameConfigurer::getParamBool(a1: v1034, a2: v1028); /*0x1067c0da6*/
      if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c0daf*/
        operator delete(a1: v1029[0]); /*0x1067c0db8*/
      if ( v287 != 0 ) /*0x1067c0dbf*/
        RBX::Telemetry::FieldsContainer::addField(a1: &v1044[3], a2: "actionType", a3: 10, a4: "DemoPlaySession", a5: 1); /*0x1067c0ddd*/
    }
    RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)__len); /*0x1067c0de9*/
    RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)__len); /*0x1067c0dfc*/
  }
  v288 = v1034; /*0x1067c0e01*/
  if ( v1034[80] == 0 ) /*0x1067c0e0c*/
  {
    RBX::SessionAppEventsHandler::instance(this: (RBX::SessionAppEventsHandler *)v1020); /*0x1067c0e19*/
    v289 = v1020[0]; /*0x1067c0e1e*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "UniverseId", a3: v290, a4: v291); /*0x1067c0e33*/
    v292 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: v1028); /*0x1067c0e46*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: __len, a2: v292); /*0x1067c0e55*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "PlaceId", a3: v293, a4: v294); /*0x1067c0e65*/
    v295 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: v1054); /*0x1067c0e75*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: v1031, a2: v295); /*0x1067c0e84*/
    std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "UserId", a3: v296, a4: v297); /*0x1067c0e97*/
    v298 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: &__dst); /*0x1067c0eaa*/
    RBX::StringConverter_detail::BasicTypeStringable<long long>::toString(a1: v1026, a2: v298); /*0x1067c0eb9*/
    RBX::SessionAppEventsHandler::onGameLoading(a1: v289, a2: __len, a3: v1031, a4: v1026); /*0x1067c0ed6*/
    if ( ((__int64)v1026[0] & 1) != 0 ) /*0x1067c0ee2*/
      operator delete(a1: v1027); /*0x1067c0eeb*/
    if ( (__dst & 1) != 0 ) /*0x1067c0ef7*/
      operator delete(a1: v1025); /*0x1067c0f00*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c0f0c*/
      operator delete(a1: v1032); /*0x1067c0f15*/
    if ( (v1054[0] & 1) != 0 ) /*0x1067c0f1e*/
      operator delete(a1: v1055); /*0x1067c0f24*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c0f30*/
      operator delete(a1: (void *)__len[2]); /*0x1067c0f39*/
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c0f45*/
      operator delete(a1: v1029[0]); /*0x1067c0f4e*/
    v299 = v1020[1]; /*0x1067c0f53*/
    if ( v1020[1] != nullptr /*0x1067c0f6f*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v1020[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v299 + 16LL))(a1: v299); /*0x1067c0f77*/
      std::__shared_weak_count::__release_weak(this: v299); /*0x1067c0f7d*/
    }
    v288 = v1034; /*0x1067c0f82*/
  }
  v300 = *((_QWORD *)v288 + 3); /*0x1067c0f89*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: __len, a2: v288); /*0x1067c0f94*/
  __len[2] = (size_t)RBX::PlayerConfigurer::onGameClose; /*0x1067c0fa7*/
  *(_QWORD *)&v1042 = 0; /*0x1067c0fab*/
  _ZN3rbx6signalIFvvEE7connectIZN3RBX16PlayerConfigurer11with_lockedIMS5_FvvEEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSA_( /*0x1067c0fc4*/
    a1: v1028,
    a2: v300 + 688);
  v301 = v1034; /*0x1067c0fc9*/
  v302 = v1034 + 1752; /*0x1067c0fd0*/
  v303 = *((std::__shared_weak_count ***)v1034 + 220); /*0x1067c0fd7*/
  if ( (unsigned __int64)v303 >= *((_QWORD *)v1034 + 221) ) /*0x1067c0fe5*/
  {
    v304 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067c1013*/
             a1: v1034 + 1752,
             a2: v1028);
    v305 = (volatile signed __int32 *)v1028[0]; /*0x1067c1018*/
    *((_QWORD *)v1034 + 220) = v304; /*0x1067c1026*/
    if ( v305 != nullptr && _InterlockedDecrement(v305 + 1) == 0 ) /*0x1067c1036*/
      rbx::signals::slot_base::operator delete(a1: (void *)v305); /*0x1067c1038*/
  }
  else
  {
    *v303 = v1028[0]; /*0x1067c0fee*/
    v1028[0] = nullptr; /*0x1067c0ff1*/
    *((_QWORD *)v301 + 220) = v303 + 1; /*0x1067c1000*/
  }
  if ( __len[1] != 0 ) /*0x1067c1047*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)__len[1]); /*0x1067c1049*/
  v306 = (RBX::ChangeHistoryService *)RBX::ServiceProvider::create<RBX::ChangeHistoryService>( /*0x1067c1060*/
                                        a1: *((_QWORD *)v1034 + 3) + 464LL,
                                        a2: 0);
  RBX::ChangeHistoryService::setEnabled(this: v306, a2: false); /*0x1067c106a*/
  RBX::ServiceProvider::create<RBX::ContentProvider>(a1: *((_QWORD *)v1034 + 3) + 464LL, a2: 0); /*0x1067c1084*/
  RBX::ServiceProvider::create<RBX::InsertService>(this: (RBX::ServiceProvider *)(*((_QWORD *)v1034 + 3) + 464LL)); /*0x1067c1099*/
  if ( FFlag::VoiceEnabledForPartyIfUserEligibleClient == 1 ) /*0x1067c10a8*/
  {
    v307 = (RBX::VoiceChat *)RBX::ServiceProvider::create<RBX::VoiceChatService>(this: (RBX::ServiceProvider *)(*((_QWORD *)v1034 + 3) + 464LL)); /*0x1067c10bc*/
    if ( v1034[82] == 1 ) /*0x1067c10cc*/
      RBX::VoiceChat::setVoiceEnabledIfUserEligible(this: v307, a2: (RBX::VoiceChatService *)1, a3: v308); /*0x1067c10d6*/
  }
  v309 = (RBX::Reflection::EnumDescriptor *)RBX::Reflection::EnumDesc<RBX::DataModelCreatorType>::singleton(); /*0x1067c10e0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "CreatorTypeEnum", a3: v310, a4: v311); /*0x1067c10f1*/
  RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1028); /*0x1067c110b*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c1117*/
    v312 = (RBX::Name *)__len[2]; /*0x1067c1119*/
  else
    v312 = (RBX::Name *)((char *)__len + 1); /*0x1067c1122*/
  RBX::Reflection::EnumDescriptor::_convertToValue(this: v309, a2: v312, a3: &v993); /*0x1067c1133*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c113f*/
    operator delete(a1: (void *)__len[2]); /*0x1067c1148*/
  if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c1154*/
    operator delete(a1: v1029[0]); /*0x1067c115d*/
  v315 = v1034; /*0x1067c1162*/
  v316 = *((_QWORD *)v1034 + 3); /*0x1067c1169*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "CreatorId", a3: v313, a4: v314); /*0x1067c117b*/
  v317 = RBX::GameConfigurer::getParamInt64(a1: v315, a2: __len); /*0x1067c118a*/
  RBX::DataModel::setCreatorID(a1: v316, a2: v317, a3: (unsigned int)v993); /*0x1067c119b*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c11a7*/
    operator delete(a1: (void *)__len[2]); /*0x1067c11b0*/
  v318 = RBX::ServiceProvider::create<RBX::Players>(a1: *((_QWORD *)v1034 + 3) + 464LL, a2: 0); /*0x1067c11cc*/
  v319 = (RBX::Reflection::EnumDescriptor *)RBX::Reflection::EnumDesc<RBX::Enums::ChatStyleEnum::ChatOption>::singleton(); /*0x1067c11d4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "ChatStyle", a3: v320, a4: v321); /*0x1067c11e5*/
  RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1028); /*0x1067c11ff*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c120b*/
    v322 = (RBX::Name *)__len[2]; /*0x1067c120d*/
  else
    v322 = (RBX::Name *)((char *)__len + 1); /*0x1067c1216*/
  RBX::Reflection::EnumDescriptor::_convertToValue(this: v319, a2: v322, a3: &v994); /*0x1067c1227*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c1233*/
    operator delete(a1: (void *)__len[2]); /*0x1067c123c*/
  if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c1248*/
    operator delete(a1: v1029[0]); /*0x1067c1251*/
  RBX::Players::setChatOption(a1: v318, a2: (unsigned int)v994); /*0x1067c125f*/
  RBX::ServiceProvider::create<RBX::Visit>(this: (RBX::ServiceProvider *)(*((_QWORD *)v1034 + 3) + 464LL)); /*0x1067c1276*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "SeleniumTest1", a3: v323, a4: v324); /*0x1067c1289*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "Started join script", a3: v325, a4: v326); /*0x1067c129c*/
  RBX::PlayerConfigurer::ifSeleniumThenSetCookie( /*0x1067c12b6*/
    a1: (__int64)v1034,
    a2: (__int128 *)__len,
    a3: (__int128 *)v1028,
    a4: v327);
  if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c12c2*/
    operator delete(a1: v1029[0]); /*0x1067c12cb*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c12d7*/
    operator delete(a1: (void *)__len[2]); /*0x1067c12e0*/
  v328 = (RBX::ServiceProvider *)(v1022 + 58); /*0x1067c12ec*/
  *(double *)&v1023 = COERCE_DOUBLE(RBX::ServiceProvider::create<RBX::Network::Client>(this: (RBX::ServiceProvider *)(v1022 + 58))); /*0x1067c12fd*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: __len, a2: v1034); /*0x1067c1312*/
  __len[2] = (size_t)RBX::PlayerConfigurer::onConnectionAccepted; /*0x1067c1325*/
  *(_QWORD *)&v1042 = 0; /*0x1067c1329*/
  _ZN3rbx6signalIFvNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEENS1_10shared_ptrIN3RBX8InstanceEEEEE7connectIZNS9_16PlayerConfigurer11with_lockedIMSF_FvRKS7_RKSB_EEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSO_( /*0x1067c1346*/
    a1: v1028,
    a2: (char *)v1023 + 4824);
  v329 = v1034; /*0x1067c134b*/
  v330 = *((std::__shared_weak_count ***)v1034 + 220); /*0x1067c1352*/
  if ( (unsigned __int64)v330 >= *((_QWORD *)v1034 + 221) ) /*0x1067c1360*/
  {
    v331 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067c138e*/
             a1: v302,
             a2: v1028);
    v332 = (volatile signed __int32 *)v1028[0]; /*0x1067c1393*/
    *((_QWORD *)v1034 + 220) = v331; /*0x1067c13a1*/
    if ( v332 != nullptr && _InterlockedDecrement(v332 + 1) == 0 ) /*0x1067c13b1*/
      rbx::signals::slot_base::operator delete(a1: (void *)v332); /*0x1067c13b3*/
  }
  else
  {
    *v330 = v1028[0]; /*0x1067c1369*/
    v1028[0] = nullptr; /*0x1067c136c*/
    *((_QWORD *)v329 + 220) = v330 + 1; /*0x1067c137b*/
  }
  if ( __len[1] != 0 ) /*0x1067c13c2*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)__len[1]); /*0x1067c13c4*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: __len, a2: v1034); /*0x1067c13d7*/
  __len[2] = (size_t)RBX::PlayerConfigurer::onConnectionFailed; /*0x1067c13ea*/
  *(_QWORD *)&v1042 = 0; /*0x1067c13ee*/
  _ZN3rbx6signalIFvNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEiEE7connectIZN3RBX16PlayerConfigurer11with_lockedIMSC_FvRKS7_iEEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSJ_( /*0x1067c140b*/
    a1: v1028,
    a2: (char *)v1023 + 4832);
  v333 = v1034; /*0x1067c1410*/
  v334 = *((std::__shared_weak_count ***)v1034 + 220); /*0x1067c1417*/
  if ( (unsigned __int64)v334 >= *((_QWORD *)v1034 + 221) ) /*0x1067c1425*/
  {
    v336 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067c1453*/
             a1: v302,
             a2: v1028);
    v337 = (volatile signed __int32 *)v1028[0]; /*0x1067c1458*/
    v335 = v1034; /*0x1067c145f*/
    *((_QWORD *)v1034 + 220) = v336; /*0x1067c1466*/
    if ( v337 != nullptr && _InterlockedDecrement(v337 + 1) == 0 ) /*0x1067c1476*/
      rbx::signals::slot_base::operator delete(a1: (void *)v337); /*0x1067c1478*/
  }
  else
  {
    v335 = (char *)v1028[0]; /*0x1067c1427*/
    *v334 = v1028[0]; /*0x1067c142e*/
    v1028[0] = nullptr; /*0x1067c1431*/
    *((_QWORD *)v333 + 220) = v334 + 1; /*0x1067c1440*/
  }
  if ( __len[1] != 0 ) /*0x1067c1487*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)__len[1]); /*0x1067c1489*/
  if ( FFlag::PerformanceControlAddSupportForOomBox == 1 ) /*0x1067c1498*/
  {
    RBX::weak_from<RBX::PlayerConfigurer>(a1: __len, a2: v1034); /*0x1067c14ac*/
    __len[2] = (size_t)RBX::PlayerConfigurer::onShowOomBox; /*0x1067c14bf*/
    *(_QWORD *)&v1042 = 0; /*0x1067c14c3*/
    _ZN3rbx6signalIFvvEE7connectIZN3RBX16PlayerConfigurer11with_lockedIMS5_FvvEEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSA_( /*0x1067c14e0*/
      a1: v1028,
      a2: (char *)v1023 + 4856);
    v333 = v1034; /*0x1067c14e5*/
    v338 = *((std::__shared_weak_count ***)v1034 + 220); /*0x1067c14ec*/
    if ( (unsigned __int64)v338 >= *((_QWORD *)v1034 + 221) ) /*0x1067c14fa*/
    {
      v339 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067c1528*/
               a1: v302,
               a2: v1028);
      v340 = (volatile signed __int32 *)v1028[0]; /*0x1067c152d*/
      v335 = v1034; /*0x1067c1534*/
      *((_QWORD *)v1034 + 220) = v339; /*0x1067c153b*/
      if ( v340 != nullptr && _InterlockedDecrement(v340 + 1) == 0 ) /*0x1067c154b*/
        rbx::signals::slot_base::operator delete(a1: (void *)v340); /*0x1067c154d*/
    }
    else
    {
      v335 = (char *)v1028[0]; /*0x1067c14fc*/
      *v338 = v1028[0]; /*0x1067c1503*/
      v1028[0] = nullptr; /*0x1067c1506*/
      *((_QWORD *)v333 + 220) = v338 + 1; /*0x1067c1515*/
    }
    if ( __len[1] != 0 ) /*0x1067c155c*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)__len[1]); /*0x1067c155e*/
  }
  if ( v1034[65] == 1 ) /*0x1067c156e*/
    RBX::Network::Client::configureAsCloudTestClient(this: v1023); /*0x1067c1577*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "ClientTicket", a3: v333, a4: v335); /*0x1067c158a*/
  RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1028); /*0x1067c15a4*/
  RBX::Network::Client::setTicket(a1: v1023, a2: __len); /*0x1067c15b7*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c15c3*/
    operator delete(a1: (void *)__len[2]); /*0x1067c15cc*/
  if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c15d8*/
    operator delete(a1: v1029[0]); /*0x1067c15e1*/
  RBX::Network::Client::setPlaySessionId(a1: v1023, a2: &v1011); /*0x1067c15f4*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "SeleniumTest2", a3: v341, a4: v342); /*0x1067c1607*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "Successfully connected to server", a3: v343, a4: v344); /*0x1067c161a*/
  RBX::PlayerConfigurer::ifSeleniumThenSetCookie( /*0x1067c1634*/
    a1: (__int64)v1034,
    a2: (__int128 *)__len,
    a3: (__int128 *)v1028,
    a4: v345);
  if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c1640*/
    operator delete(a1: v1029[0]); /*0x1067c1649*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c1655*/
    operator delete(a1: (void *)__len[2]); /*0x1067c165e*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "SessionId", a3: v346, a4: v347); /*0x1067c1671*/
  RBX::GameConfigurer::getParamString(a1: v928, a2: v1034, a3: __len); /*0x1067c168b*/
  RBX::Network::Client::setGameSessionID(this: v1023, a2: (RBX::Instance *)v928); /*0x1067c169e*/
  if ( (v928[0] & 1) != 0 ) /*0x1067c16aa*/
    operator delete(a1: v929); /*0x1067c16b3*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c16bf*/
    operator delete(a1: (void *)__len[2]); /*0x1067c16c8*/
  *(_OWORD *)v1029 = 0; /*0x1067c16d1*/
  *(_OWORD *)v1028 = 0; /*0x1067c16d9*/
  v1030 = 1065353216; /*0x1067c16e1*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: __len, a2: v1034); /*0x1067c16f9*/
  __len[2] = (size_t)RBX::PlayerConfigurer::connectPlayerToSignals; /*0x1067c170c*/
  *(_QWORD *)&v1042 = 0; /*0x1067c1710*/
  _ZN3rbx6signalIFvNSt3__110shared_ptrIN3RBX6PlayerEEEEE7connectIZNS3_16PlayerConfigurer11with_lockedIMS9_FvS5_EEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSE_( /*0x1067c1726*/
    a1: v1031,
    a2: v318 + 1936);
  v348 = v1034; /*0x1067c172b*/
  v349 = *((void ***)v1034 + 220); /*0x1067c1732*/
  if ( (unsigned __int64)v349 >= *((_QWORD *)v1034 + 221) ) /*0x1067c1740*/
  {
    v351 = std::vector<rbx::signals::connection>::__emplace_back_slow_path<rbx::signals::connection>( /*0x1067c176e*/
             a1: v302,
             a2: v1031);
    v352 = (volatile signed __int32 *)v1031[0]; /*0x1067c1773*/
    v350 = v1034; /*0x1067c177a*/
    *((_QWORD *)v1034 + 220) = v351; /*0x1067c1781*/
    if ( v352 != nullptr && _InterlockedDecrement(v352 + 1) == 0 ) /*0x1067c1791*/
      rbx::signals::slot_base::operator delete(a1: (void *)v352); /*0x1067c1793*/
  }
  else
  {
    v350 = (char *)v1031[0]; /*0x1067c1742*/
    *v349 = v1031[0]; /*0x1067c1749*/
    v1031[0] = nullptr; /*0x1067c174c*/
    *((_QWORD *)v348 + 220) = v349 + 1; /*0x1067c175b*/
  }
  if ( __len[1] != 0 ) /*0x1067c17a2*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)__len[1]); /*0x1067c17a4*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "UserId", a3: v348, a4: v350); /*0x1067c17b7*/
  v355 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: __len); /*0x1067c17cf*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c17d9*/
    operator delete(a1: (void *)__len[2]); /*0x1067c17e2*/
  v997 = v355; /*0x1067c17e7*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "UserId", a3: v353, a4: v354); /*0x1067c17ff*/
  v1031[0] = __len; /*0x1067c180b*/
  v356 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c1828*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)__len,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1031,
           a5: (__int64)v1054);
  *((_QWORD *)v356 + 5) = RBX::Reflection::Type::getSingleton<long long>(a1: v357); /*0x1067c1830*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<long long>(a1: v356 + 48, a2: &v997); /*0x1067c1842*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c184e*/
    operator delete(a1: (void *)__len[2]); /*0x1067c1857*/
  v358 = (RBX::TeleportService *)RBX::ServiceProvider::find<RBX::TeleportService>( /*0x1067c186e*/
                                   a1: *((_QWORD *)v1034 + 3) + 464LL,
                                   a2: 0);
  v361 = v358; /*0x1067c1873*/
  if ( v358 != nullptr ) /*0x1067c1879*/
  {
    LOBYTE(v1026[0]) = RBX::TeleportService::getPreviousPlaceId(this: v358) > 0; /*0x1067c188a*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "IsTeleportedIn", a3: v362, a4: v363); /*0x1067c18a2*/
    v1031[0] = __len; /*0x1067c18ae*/
    v364 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c18cb*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)__len,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1031,
             a5: (__int64)v1054);
    *((_QWORD *)v364 + 5) = RBX::Reflection::Type::getSingleton<bool>(a1: v365); /*0x1067c18d3*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<bool,(bool *)0>(a1: v364 + 48, a2: v1026); /*0x1067c18e5*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c18f1*/
      operator delete(a1: (void *)__len[2]); /*0x1067c18fa*/
    v1054[0] = RBX::TeleportService::getPreviousUniverseId(this: v361); /*0x1067c1907*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "PreviousUniverseId", a3: v366, a4: v367); /*0x1067c191c*/
    v1031[0] = __len; /*0x1067c1928*/
    v368 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c1948*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)__len,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1031,
             a5: (__int64)v1026);
    *((_QWORD *)v368 + 5) = RBX::Reflection::Type::getSingleton<long long>(a1: v369); /*0x1067c1950*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<long long,(long long *)0>(a1: v368 + 48, a2: v1054); /*0x1067c195f*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c196b*/
      operator delete(a1: (void *)__len[2]); /*0x1067c1974*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "UserName", a3: v359, a4: v360); /*0x1067c1987*/
  RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c19a1*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "UserName", a3: v370, a4: v371); /*0x1067c19b4*/
  v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c19c0*/
  v372 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c19e0*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1054,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1026,
           a5: (__int64)&__dst);
  *((_QWORD *)v372 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v375, a2: v376, a3: v373, a4: v374); /*0x1067c19e8*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c19fa*/
    a1: (__int64)(v372 + 48),
    a2: (__int64)__len);
  if ( (v1054[0] & 1) != 0 ) /*0x1067c1a03*/
    operator delete(a1: v1055); /*0x1067c1a09*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c1a15*/
    operator delete(a1: (void *)__len[2]); /*0x1067c1a1e*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c1a2a*/
    operator delete(a1: v1032); /*0x1067c1a33*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "DisplayName", a3: v377, a4: v378); /*0x1067c1a46*/
  RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c1a60*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "DisplayName", a3: v379, a4: v380); /*0x1067c1a73*/
  v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c1a7f*/
  v381 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c1a9f*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1054,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1026,
           a5: (__int64)&__dst);
  *((_QWORD *)v381 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v384, a2: v385, a3: v382, a4: v383); /*0x1067c1aa7*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c1ab9*/
    a1: (__int64)(v381 + 48),
    a2: (__int64)__len);
  if ( (v1054[0] & 1) != 0 ) /*0x1067c1ac2*/
    operator delete(a1: v1055); /*0x1067c1ac8*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c1ad4*/
    operator delete(a1: (void *)__len[2]); /*0x1067c1add*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c1ae9*/
    operator delete(a1: v1032); /*0x1067c1af2*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "HasVerifiedBadge", a3: v386, a4: v387); /*0x1067c1b05*/
  LOBYTE(__dst) = RBX::GameConfigurer::getParamBool(a1: v1034, a2: __len); /*0x1067c1b1d*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "HasVerifiedBadge", a3: v388, a4: v389); /*0x1067c1b34*/
  v1054[0] = (__int64)v1031; /*0x1067c1b3d*/
  v390 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c1b5d*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)v1026);
  *((_QWORD *)v390 + 5) = RBX::Reflection::Type::getSingleton<bool>(a1: v391); /*0x1067c1b65*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<bool,(bool *)0>(a1: v390 + 48, a2: &__dst); /*0x1067c1b77*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c1b83*/
    operator delete(a1: v1032); /*0x1067c1b8c*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c1b98*/
    operator delete(a1: (void *)__len[2]); /*0x1067c1ba1*/
  if ( FFlag::EnablePlayerPartyId == 1 ) /*0x1067c1bb0*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "PartyId", a3: v392, a4: v393); /*0x1067c1bc4*/
    RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c1bde*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "PartyId", a3: v394, a4: v395); /*0x1067c1bf1*/
    v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c1bfd*/
    v396 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c1c1d*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1054,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1026,
             a5: (__int64)&__dst);
    *((_QWORD *)v396 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v399, a2: v400, a3: v397, a4: v398); /*0x1067c1c25*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c1c37*/
      a1: (__int64)(v396 + 48),
      a2: (__int64)__len);
    if ( (v1054[0] & 1) != 0 ) /*0x1067c1c40*/
      operator delete(a1: v1055); /*0x1067c1c46*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c1c52*/
      operator delete(a1: (void *)__len[2]); /*0x1067c1c5b*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c1c67*/
      operator delete(a1: v1032); /*0x1067c1c70*/
  }
  if ( FFlag::CLI56034 == 1 ) /*0x1067c1c7c*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "RandomSeed1", a3: v392, a4: v393); /*0x1067c1c90*/
    RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c1caa*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c1cb7*/
    {
      v401 = __len[1] == 0; /*0x1067c1cc8*/
      operator delete(a1: (void *)__len[2]); /*0x1067c1cd2*/
    }
    else
    {
      v401 = LOBYTE(__len[0]) == 0; /*0x1067c1cbb*/
    }
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c1cde*/
      operator delete(a1: v1032); /*0x1067c1ce7*/
    if ( v401 ) /*0x1067c1cee*/
    {
      std::string::basic_string[abi:ne200100]<0>( /*0x1067c1cfe*/
        a1: __len,
        a2: "EncryptedUserScore_ClientNoReceive",
        a3: v392,
        a4: v393);
      RBX::Analytics::EphemeralCounter::reportCounter(a1: __len, a2: 1, a3: 0); /*0x1067c1d11*/
      if ( (__len[0] & 1) != 0 ) /*0x1067c1d1d*/
        operator delete(a1: (void *)__len[2]); /*0x1067c1d26*/
    }
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "RandomSeed1", a3: v392, a4: v393); /*0x1067c1d39*/
  RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c1d53*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "RandomSeed1", a3: v402, a4: v403); /*0x1067c1d66*/
  v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c1d72*/
  v404 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c1d92*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1054,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1026,
           a5: (__int64)&__dst);
  *((_QWORD *)v404 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v407, a2: v408, a3: v405, a4: v406); /*0x1067c1d9a*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c1dac*/
    a1: (__int64)(v404 + 48),
    a2: (__int64)__len);
  if ( (v1054[0] & 1) != 0 ) /*0x1067c1db5*/
    operator delete(a1: v1055); /*0x1067c1dbb*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c1dc7*/
    operator delete(a1: (void *)__len[2]); /*0x1067c1dd0*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c1ddc*/
    operator delete(a1: v1032); /*0x1067c1de5*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "VerifiedAMP", a3: v409, a4: v410); /*0x1067c1df8*/
  LODWORD(v1026[0]) = RBX::GameConfigurer::getParamInt(a1: v1034, a2: __len); /*0x1067c1e10*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "VerifiedAMP", a3: v411, a4: v412); /*0x1067c1e27*/
  v1054[0] = (__int64)v1031; /*0x1067c1e30*/
  v413 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c1e50*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)&__dst);
  *((_QWORD *)v413 + 5) = RBX::Reflection::Type::getSingleton<int>(a1: v414); /*0x1067c1e58*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int,(int *)0>(a1: v413 + 48, a2: v1026); /*0x1067c1e6a*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c1e76*/
    operator delete(a1: v1032); /*0x1067c1e7f*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c1e8b*/
    operator delete(a1: (void *)__len[2]); /*0x1067c1e94*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "PrivateServerID", a3: v415, a4: v416); /*0x1067c1ea7*/
  RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c1ec1*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "PrivateServerID", a3: v417, a4: v418); /*0x1067c1ed4*/
  v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c1ee0*/
  v419 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c1f00*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1054,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1026,
           a5: (__int64)&__dst);
  *((_QWORD *)v419 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v422, a2: v423, a3: v420, a4: v421); /*0x1067c1f08*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c1f1a*/
    a1: (__int64)(v419 + 48),
    a2: (__int64)__len);
  if ( (v1054[0] & 1) != 0 ) /*0x1067c1f23*/
    operator delete(a1: v1055); /*0x1067c1f29*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c1f35*/
    operator delete(a1: (void *)__len[2]); /*0x1067c1f3e*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c1f4a*/
    operator delete(a1: v1032); /*0x1067c1f53*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "PrivateServerOwnerID", a3: v424, a4: v425); /*0x1067c1f66*/
  v1026[0] = (std::__shared_weak_count *)RBX::GameConfigurer::getParamInt64(a1: v1034, a2: __len); /*0x1067c1f7e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "PrivateServerOwnerID", a3: v426, a4: v427); /*0x1067c1f96*/
  v1054[0] = (__int64)v1031; /*0x1067c1f9f*/
  v428 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c1fbf*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)&__dst);
  *((_QWORD *)v428 + 5) = RBX::Reflection::Type::getSingleton<long long>(a1: v429); /*0x1067c1fc7*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<long long,(long long *)0>(a1: v428 + 48, a2: v1026); /*0x1067c1fd9*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c1fe5*/
    operator delete(a1: v1032); /*0x1067c1fee*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c1ffa*/
    operator delete(a1: (void *)__len[2]); /*0x1067c2003*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "MatchmakingAttributes", a3: v430, a4: v431); /*0x1067c2016*/
  RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c2030*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "MatchmakingAttributes", a3: v432, a4: v433); /*0x1067c2043*/
  v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c204f*/
  v434 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c206f*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1054,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1026,
           a5: (__int64)&__dst);
  *((_QWORD *)v434 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v437, a2: v438, a3: v435, a4: v436); /*0x1067c2077*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c2089*/
    a1: (__int64)(v434 + 48),
    a2: (__int64)__len);
  if ( (v1054[0] & 1) != 0 ) /*0x1067c2092*/
    operator delete(a1: v1055); /*0x1067c2098*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c20a4*/
    operator delete(a1: (void *)__len[2]); /*0x1067c20ad*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c20b9*/
    operator delete(a1: v1032); /*0x1067c20c2*/
  v1054[0] = hyperionTokenValue; /*0x1067c20ce*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "UdmuxToken", a3: v439, a4: v440); /*0x1067c20e3*/
  v1031[0] = __len; /*0x1067c20ef*/
  v441 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c210f*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)__len,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1031,
           a5: (__int64)v1026);
  *((_QWORD *)v441 + 5) = RBX::Reflection::Type::getSingleton<long long>(a1: v442); /*0x1067c2117*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<long long,(long long *)0>(a1: v441 + 48, a2: v1054); /*0x1067c2126*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c2132*/
    operator delete(a1: (void *)__len[2]); /*0x1067c213b*/
  if ( DFFlag::PopulateUserInformationForPlayers == 1 ) /*0x1067c2147*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "DomainUserId", a3: v443, a4: v444); /*0x1067c215b*/
    v1026[0] = (std::__shared_weak_count *)RBX::GameConfigurer::getParamInt64(a1: v1034, a2: __len); /*0x1067c2173*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "DomainUserId", a3: v445, a4: v446); /*0x1067c218b*/
    v1054[0] = (__int64)v1031; /*0x1067c2194*/
    v447 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c21b4*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1031,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1054,
             a5: (__int64)&__dst);
    *((_QWORD *)v447 + 5) = RBX::Reflection::Type::getSingleton<long long>(a1: v448); /*0x1067c21bc*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<long long,(long long *)0>(a1: v447 + 48, a2: v1026); /*0x1067c21ce*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c21da*/
      operator delete(a1: v1032); /*0x1067c21e3*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c21ef*/
      operator delete(a1: (void *)__len[2]); /*0x1067c21f8*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "UserIdMode", a3: v449, a4: v450); /*0x1067c220b*/
    LODWORD(v1026[0]) = RBX::GameConfigurer::getParamInt(a1: v1034, a2: __len); /*0x1067c2223*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "UserIdMode", a3: v451, a4: v452); /*0x1067c223a*/
    v1054[0] = (__int64)v1031; /*0x1067c2243*/
    v453 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c2263*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1031,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1054,
             a5: (__int64)&__dst);
    *((_QWORD *)v453 + 5) = RBX::Reflection::Type::getSingleton<int>(a1: v454); /*0x1067c226b*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int,(int *)0>(a1: v453 + 48, a2: v1026); /*0x1067c227d*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c2289*/
      operator delete(a1: v1032); /*0x1067c2292*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c229e*/
      operator delete(a1: (void *)__len[2]); /*0x1067c22a7*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "ServerClaimedTime", a3: v443, a4: v444); /*0x1067c22ba*/
  v1026[0] = (std::__shared_weak_count *)RBX::GameConfigurer::getParamInt64(a1: v1034, a2: __len); /*0x1067c22d2*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "ServerClaimedTime", a3: v455, a4: v456); /*0x1067c22ea*/
  v1054[0] = (__int64)v1031; /*0x1067c22f3*/
  v457 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c2313*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)&__dst);
  *((_QWORD *)v457 + 5) = RBX::Reflection::Type::getSingleton<long long>(a1: v458); /*0x1067c231b*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<long long,(long long *)0>(a1: v457 + 48, a2: v1026); /*0x1067c232d*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c2339*/
    operator delete(a1: v1032); /*0x1067c2342*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c234e*/
    operator delete(a1: (void *)__len[2]); /*0x1067c2357*/
  if ( DFFlag::JoinTicketAPIsecurityToken == 1 ) /*0x1067c2366*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "APIsecurityToken", a3: v459, a4: v460); /*0x1067c237a*/
    RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c2394*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "APIsecurityToken", a3: v461, a4: v462); /*0x1067c23a7*/
    v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c23b3*/
    v463 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c23d3*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1054,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1026,
             a5: (__int64)&__dst);
    *((_QWORD *)v463 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v466, a2: v467, a3: v464, a4: v465); /*0x1067c23db*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c23ed*/
      a1: (__int64)(v463 + 48),
      a2: (__int64)__len);
    if ( (v1054[0] & 1) != 0 ) /*0x1067c23f6*/
      operator delete(a1: v1055); /*0x1067c23fc*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c2408*/
      operator delete(a1: (void *)__len[2]); /*0x1067c2411*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c241d*/
      operator delete(a1: v1032); /*0x1067c2426*/
  }
  if ( FFlag::ClientServerAlignedDataModelRecording == 1 ) /*0x1067c2435*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "ServerDMRecording", a3: v459, a4: v460); /*0x1067c2449*/
    v468 = RBX::GameConfigurer::getParamBool(a1: v1034, a2: __len); /*0x1067c2461*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c246a*/
      operator delete(a1: (void *)__len[2]); /*0x1067c2473*/
    if ( v468 != 0 ) /*0x1067c247a*/
    {
      v469 = *((_QWORD *)v1034 + 3); /*0x1067c2483*/
      if ( v469 != 0 ) /*0x1067c248a*/
      {
        v470 = (RBX::ExperienceStateCapture::ExperienceStateRecordingService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::ExperienceStateCapture::ExperienceStateRecordingService>(this: (RBX::ServiceProvider *)(v469 + 464)); /*0x1067c2498*/
        v471 = *((_QWORD *)v1034 + 3); /*0x1067c24a2*/
      }
      else
      {
        v471 = 0; /*0x1067c24a8*/
        v470 = nullptr; /*0x1067c24aa*/
      }
      v472 = (RBX::ServiceProvider *)(v471 + 464); /*0x1067c24ac*/
      if ( v471 == 0 ) /*0x1067c24b6*/
        v472 = nullptr; /*0x1067c24b6*/
      RBX::ExperienceStateCapture::ExperienceStateRecordingService::startInputRecorderIfNotStarted(this: v470, a2: v472); /*0x1067c24bd*/
      if ( FFlag::EnableCameraOnlyRecording == 0 ) /*0x1067c24cc*/
      {
        v473 = *((_QWORD *)v1034 + 3); /*0x1067c24d5*/
        v474 = (RBX::ServiceProvider *)(v473 + 464); /*0x1067c24d9*/
        if ( v473 == 0 ) /*0x1067c24e3*/
          v474 = nullptr; /*0x1067c24e3*/
        RBX::ExperienceStateCapture::ExperienceStateRecordingService::startCameraOnlyRecordingIfNotStarted( /*0x1067c24ea*/
          this: v470,
          a2: v474);
      }
    }
  }
  v930 = &aLocale2idref[32526591]; /*0x1067c24fc*/
  RBX::CoreGlobalBasicSettings::CoreGlobalBasicSettings(this: (RBX::CoreGlobalBasicSettings *)__len); /*0x1067c2518*/
  v476 = RBX::CoreGlobalBasicSettings::singleton(this: v475); /*0x1067c2522*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "Locale2IdRef", a3: v477, a4: v478); /*0x1067c2532*/
  v1054[0] = (__int64)v1031; /*0x1067c253b*/
  v479 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c255b*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)v1026);
  *((_QWORD *)v479 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v482, a2: v483, a3: v480, a4: v481); /*0x1067c2567*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>(a1: (__int64 **)v479 + 6, a2: v476 + 64); /*0x1067c2575*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c2581*/
    operator delete(a1: v1032); /*0x1067c258a*/
  RBX::CoreGlobalBasicSettings::~CoreGlobalBasicSettings(this: (RBX::CoreGlobalBasicSettings *)__len); /*0x1067c2596*/
  v931 = &aLocale2info[32913612]; /*0x1067c25a8*/
  RBX::SystemUtil::osVer(this: (RBX::SystemUtil *)__len); /*0x1067c25bd*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "Locale2Info", a3: v484, a4: v485); /*0x1067c25d6*/
  v1054[0] = (__int64)v1031; /*0x1067c25df*/
  v486 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c25ff*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)v1026);
  *((_QWORD *)v486 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v489, a2: v490, a3: v487, a4: v488); /*0x1067c2607*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c2619*/
    a1: (__int64)(v486 + 48),
    a2: (__int64)__len);
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c2625*/
    operator delete(a1: v1032); /*0x1067c262e*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c263a*/
    operator delete(a1: (void *)__len[2]); /*0x1067c2643*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1020, a2: "", a3: v491, a4: v492); /*0x1067c2656*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v1009, a2: "", a3: v493, a4: v494); /*0x1067c2669*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v1004, a2: "", a3: v495, a4: v496); /*0x1067c267c*/
  if ( FFlag::UgcLocaleFromGameJoinEnabled == 1 ) /*0x1067c268b*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "UgcLocale", a3: v497, a4: v498); /*0x1067c269f*/
    RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c26b9*/
    if ( ((__int64)v1020[0] & 1) != 0 ) /*0x1067c26c5*/
      operator delete(a1: v1021); /*0x1067c26ce*/
    v1021 = (void *)__len[2]; /*0x1067c26da*/
    *(_OWORD *)v1020 = *(_OWORD *)__len; /*0x1067c26e9*/
    LOWORD(__len[0]) = 0; /*0x1067c26f1*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c2701*/
      operator delete(a1: v1032); /*0x1067c270a*/
    if ( ((__int64)v1020[0] & 1) != 0 ) /*0x1067c2718*/
      v501 = v1020[1]; /*0x1067c271e*/
    else
      v501 = (std::__shared_weak_count *)(LOBYTE(v1020[0]) >> 1); /*0x1067c295a*/
    if ( v501 == nullptr ) /*0x1067c295f*/
    {
      __len[0] = (size_t)&off_10C443EC0; /*0x1067c2973*/
      RBX::Telemetry::RobloxTelemetryCommon::RobloxTelemetryCommon<(RBX::Telemetry::TelemetryBackend)16>( /*0x1067c298b*/
        a1: __len,
        a2: off_10C8C8838,
        a3: &RBX::Telemetry::kPlayerConfigurerMissingLocaleId);
      __len[0] = (size_t)&off_10C8C87E8; /*0x1067c29a2*/
      LODWORD(v1044[3]) = 1; /*0x1067c29a5*/
      RBX::Telemetry::RobloxTelemetryEphemeralCounter::send(this: (RBX::Telemetry::RobloxTelemetryEphemeralCounter *)__len); /*0x1067c29ac*/
      RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: (void **)__len, a2: (void **)off_10C8C8838); /*0x1067c29bb*/
      if ( DFFlag::PlayerConfigurerMissingLocaleIdDetailsTelemetry == 1 ) /*0x1067c29c7*/
      {
        RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1067c29db*/
          a1: (__int64)__len,
          a2: (__int64)&RBX::Telemetry::kPlayerConfigurerMissingLocaleIdDetails);
        RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)&v1044[3]); /*0x1067c29ea*/
        RBX::Telemetry::FieldsContainer::addArchitectureInfo(this: (RBX::Telemetry::FieldsContainer *)&v1044[3]); /*0x1067c29f2*/
        std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "", a3: v511, a4: v512); /*0x1067c2a05*/
        RBX::Telemetry::FieldsContainer::addPlaceId(this: (RBX::Analytics *)&v1044[3]); /*0x1067c2a14*/
        if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c2a20*/
          operator delete(a1: v1032); /*0x1067c2a29*/
        RBX::Telemetry::FieldsContainer::addField(a1: &v1044[3], a2: "ugcLocaleEnabled", a3: 16, a4: 1, a5: 1); /*0x1067c2a48*/
        RBX::Telemetry::FieldsContainer::addField( /*0x1067c2a6c*/
          a1: &v1044[3],
          a2: "testing",
          a3: 7,
          a4: (unsigned __int8)*v1015,
          a5: 1);
        RBX::Telemetry::FieldsContainer::addField( /*0x1067c2a91*/
          a1: &v1044[3],
          a2: "isStudioToRcc",
          a3: 13,
          a4: (unsigned __int8)v1034[65],
          a5: 1);
        RBX::Telemetry::FieldsContainer::addField( /*0x1067c2ab5*/
          a1: &v1044[3],
          a2: "isLocalRcc",
          a3: 10,
          a4: (unsigned __int8)FFlag::DebugLocalRccServerConnection,
          a5: 1);
        RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)__len); /*0x1067c2ac1*/
        RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)__len); /*0x1067c2ad4*/
      }
    }
    if ( v1022 != nullptr ) /*0x1067c2ae1*/
    {
      v513 = *(RBX::LocalizationService **)RBX::ServiceProvider::refByClass<RBX::LocalizationService>(this: v328); /*0x1067c2aef*/
      if ( v513 != nullptr ) /*0x1067c2af5*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "ShowRobloxTranslations", a3: v499, a4: v500); /*0x1067c2b09*/
        v514 = RBX::GameConfigurer::getParamBool(a1: v1034, a2: __len); /*0x1067c2b1c*/
        RBX::LocalizationService::setIsLoadingInternalRobloxTranslations(this: v513, a2: v514); /*0x1067c2b27*/
        if ( (__len[0] & 1) != 0 ) /*0x1067c2b33*/
          operator delete(a1: (void *)__len[2]); /*0x1067c2b3c*/
        if ( DFFlag::AddTranslationDisplayMode == 1 ) /*0x1067c2b4b*/
        {
          std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "TranslationDisplayMode", a3: v515, a4: v516); /*0x1067c2b5b*/
          RBX::GameConfigurer::getParamString(a1: v932, a2: v1034, a3: __len); /*0x1067c2b75*/
          RBX::LocalizationService::setTranslationDisplayMode(a1: v513, a2: v932); /*0x1067c2b84*/
          if ( (v932[0] & 1) != 0 ) /*0x1067c2b90*/
            operator delete(a1: v933); /*0x1067c2b99*/
          if ( (__len[0] & 1) != 0 ) /*0x1067c2ba5*/
            operator delete(a1: (void *)__len[2]); /*0x1067c2bae*/
        }
        if ( DFFlag::AddImageTranslationContentVariantType == 1 ) /*0x1067c2bbd*/
        {
          std::string::basic_string[abi:ne200100]<0>( /*0x1067c2bcd*/
            a1: __len,
            a2: "ImageTranslationContentVariantType",
            a3: v515,
            a4: v516);
          RBX::GameConfigurer::getParamString(a1: v934, a2: v1034, a3: __len); /*0x1067c2be7*/
          RBX::LocalizationService::setImageTranslationContentVariantType(a1: v513, a2: v934); /*0x1067c2bf6*/
          if ( (v934[0] & 1) != 0 ) /*0x1067c2c02*/
            operator delete(a1: v935); /*0x1067c2c0b*/
          if ( (__len[0] & 1) != 0 ) /*0x1067c2c17*/
            operator delete(a1: (void *)__len[2]); /*0x1067c2c20*/
        }
        if ( DFFlag::AddImageTranslationSupportedLocales == 1 ) /*0x1067c2c2f*/
        {
          std::string::basic_string[abi:ne200100]<0>( /*0x1067c2c43*/
            a1: __len,
            a2: "SupportedLocalesForImageTranslation",
            a3: v515,
            a4: v516);
          RBX::GameConfigurer::getValueArray(a1: v936, a2: v1034, a3: __len); /*0x1067c2c5d*/
          RBX::LocalizationService::setupImageTranslationSupportedLocales(a1: v513, a2: v936); /*0x1067c2c6c*/
          v517 = v937; /*0x1067c2c71*/
          if ( v937 != nullptr /*0x1067c2c8d*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v937 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v517 + 16LL))(a1: v517); /*0x1067c2c95*/
            std::__shared_weak_count::__release_weak(this: v517); /*0x1067c2c9b*/
          }
          if ( (__len[0] & 1) != 0 ) /*0x1067c2ca7*/
            operator delete(a1: (void *)__len[2]); /*0x1067c2cb0*/
        }
        if ( ((__int64)v1020[0] & 1) != 0 ) /*0x1067c2cbe*/
          v518 = v1020[1]; /*0x1067c2cc0*/
        else
          v518 = (std::__shared_weak_count *)(LOBYTE(v1020[0]) >> 1); /*0x1067c2cc9*/
        if ( v518 != nullptr ) /*0x1067c2cce*/
        {
          RBX::LocalizationService::setUgcLocaleId(a1: v513, a2: v1020); /*0x1067c2cda*/
        }
        else
        {
          TranslationLocaleId = (RBX::Localization::TranslationLocaleId *)RBX::LocalizationService::getTranslationLocaleId(this: v513); /*0x1067c2ce7*/
          UGCLocaleId = RBX::Localization::TranslationLocaleId::getUGCLocaleId(this: TranslationLocaleId); /*0x1067c2cef*/
          v521 = RBX::Localization::LocaleId::toLocaleString(a1: UGCLocaleId, a2: 1); /*0x1067c2cfc*/
          if ( v521 != 0 ) /*0x1067c2d04*/
            std::string::basic_string[abi:ne200100](a1: __len, a2: v521, a3: v499); /*0x1067c2d14*/
          else
            memset(__len, 0, sizeof(__len)); /*0x1067c302d*/
          if ( ((__int64)v1020[0] & 1) != 0 ) /*0x1067c3047*/
            operator delete(a1: v1021); /*0x1067c3050*/
          v1021 = (void *)__len[2]; /*0x1067c305c*/
          *(_OWORD *)v1020 = *(_OWORD *)__len; /*0x1067c306b*/
        }
      }
    }
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "LocaleId", a3: v499, a4: v500); /*0x1067c3084*/
    v1031[0] = __len; /*0x1067c3090*/
    v544 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c30ad*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)__len,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1031,
             a5: (__int64)v1054);
    *((_QWORD *)v544 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v547, a2: v548, a3: v545, a4: v546); /*0x1067c30b5*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>( /*0x1067c30c7*/
      a1: (__int64 **)v544 + 6,
      a2: (__int64)v1020);
    if ( (__len[0] & 1) != 0 ) /*0x1067c30d3*/
      operator delete(a1: (void *)__len[2]); /*0x1067c30dc*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "LocaleIdInternal", a3: v549, a4: v550); /*0x1067c30f2*/
    v1031[0] = __len; /*0x1067c30fe*/
    v551 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c311b*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)__len,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1031,
             a5: (__int64)v1054);
    *((_QWORD *)v551 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v554, a2: v555, a3: v552, a4: v553); /*0x1067c3123*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>( /*0x1067c3135*/
      a1: (__int64 **)v551 + 6,
      a2: (__int64)v1020);
    if ( (__len[0] & 1) != 0 ) /*0x1067c3141*/
      operator delete(a1: (void *)__len[2]); /*0x1067c314a*/
    if ( v1022 != nullptr ) /*0x1067c3157*/
    {
LABEL_719:
      v558 = *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::VRService>(this: v328); /*0x1067c315d*/
      if ( v558 != 0 ) /*0x1067c316b*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "VrDevice", a3: v556, a4: v557); /*0x1067c3182*/
        v1031[0] = __len; /*0x1067c318e*/
        v559 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c31ab*/
                 a1: (__int64 *)v1028,
                 a2: (unsigned __int8 *)__len,
                 a3: (__int64)std::piecewise_construct,
                 a4: (__int64)v1031,
                 a5: (__int64)v1054);
        v564 = v558 + 200; /*0x1067c31b3*/
        *((_QWORD *)v559 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v562, a2: v563, a3: v560, a4: v561); /*0x1067c31ba*/
        RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>(a1: (__int64 **)v559 + 6, a2: v564); /*0x1067c31c8*/
        if ( (__len[0] & 1) != 0 ) /*0x1067c31d4*/
          operator delete(a1: (void *)__len[2]); /*0x1067c31dd*/
        std::string::operator=(a1: &v1009, a2: v564); /*0x1067c31ec*/
      }
      v536 = *(RBX::ThirdPartyUserService **)RBX::ServiceProvider::refByClass<RBX::ThirdPartyUserService>(this: v328); /*0x1067c31f9*/
      if ( v536 != nullptr ) /*0x1067c31ff*/
      {
        RBX::ThirdPartyUserService::getTextChatRestrictionStatus(this: v536); /*0x1067c3205*/
        v565 = RBX::Reflection::EnumDesc<RBX::Enums::ChatRestrictionStatus>::singleton(); /*0x1067c320c*/
        RBX::Reflection::EnumDescriptor::_convertToString(this: (RBX::Reflection::EnumDescriptor *)__len, a2: v565); /*0x1067c321d*/
        if ( (v1004 & 1) != 0 ) /*0x1067c3229*/
          operator delete(a1: v1005); /*0x1067c3232*/
        v1005 = (void *)__len[2]; /*0x1067c3242*/
        v1004 = *(_OWORD *)__len; /*0x1067c324d*/
        std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "TextChatRestrictionStatus", a3: v566, a4: v567); /*0x1067c325f*/
        v1031[0] = __len; /*0x1067c326b*/
        v568 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3288*/
                 a1: (__int64 *)v1028,
                 a2: (unsigned __int8 *)__len,
                 a3: (__int64)std::piecewise_construct,
                 a4: (__int64)v1031,
                 a5: (__int64)v1054);
        *((_QWORD *)v568 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v571, a2: v572, a3: v569, a4: v570); /*0x1067c3290*/
        RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>( /*0x1067c32a2*/
          a1: (__int64 **)v568 + 6,
          a2: (__int64)&v1004);
        if ( (__len[0] & 1) != 0 ) /*0x1067c32ae*/
          operator delete(a1: (void *)__len[2]); /*0x1067c32b7*/
      }
    }
  }
  else
  {
    RBX::PlayerConfigurer::getGameLocaleIdFromParams( /*0x1067c2738*/
      this: (RBX::PlayerConfigurer *)__len,
      a2: (__int64)v1034,
      a3: v497,
      a4: v498);
    if ( ((__int64)v1020[0] & 1) != 0 ) /*0x1067c2744*/
      operator delete(a1: v1021); /*0x1067c274d*/
    v1021 = (void *)__len[2]; /*0x1067c2759*/
    *(_OWORD *)v1020 = *(_OWORD *)__len; /*0x1067c2768*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c2779*/
      v504 = v1020[1]; /*0x1067c277b*/
    else
      v504 = (std::__shared_weak_count *)(LOBYTE(__len[0]) >> 1); /*0x1067c2784*/
    if ( v504 == nullptr ) /*0x1067c2789*/
    {
      __len[0] = (size_t)&off_10C443EC0; /*0x1067c279d*/
      RBX::Telemetry::RobloxTelemetryCommon::RobloxTelemetryCommon<(RBX::Telemetry::TelemetryBackend)16>( /*0x1067c27b5*/
        a1: __len,
        a2: off_10C8C8838,
        a3: &RBX::Telemetry::kPlayerConfigurerMissingLocaleId);
      __len[0] = (size_t)&off_10C8C87E8; /*0x1067c27cc*/
      LODWORD(v1044[3]) = 1; /*0x1067c27cf*/
      RBX::Telemetry::RobloxTelemetryEphemeralCounter::send(this: (RBX::Telemetry::RobloxTelemetryEphemeralCounter *)__len); /*0x1067c27d6*/
      RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: (void **)__len, a2: (void **)off_10C8C8838); /*0x1067c27e5*/
      if ( DFFlag::PlayerConfigurerMissingLocaleIdDetailsTelemetry == 1 ) /*0x1067c27f1*/
      {
        RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1067c2805*/
          a1: (__int64)__len,
          a2: (__int64)&RBX::Telemetry::kPlayerConfigurerMissingLocaleIdDetails);
        RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)&v1044[3]); /*0x1067c2814*/
        RBX::Telemetry::FieldsContainer::addArchitectureInfo(this: (RBX::Telemetry::FieldsContainer *)&v1044[3]); /*0x1067c281c*/
        std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "", a3: v505, a4: v506); /*0x1067c282f*/
        RBX::Telemetry::FieldsContainer::addPlaceId(this: (RBX::Analytics *)&v1044[3]); /*0x1067c283e*/
        if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c284a*/
          operator delete(a1: v1032); /*0x1067c2853*/
        RBX::Telemetry::FieldsContainer::addField(a1: &v1044[3], a2: "ugcLocaleEnabled", a3: 16, a4: 0, a5: 1); /*0x1067c286f*/
        RBX::Telemetry::FieldsContainer::addField( /*0x1067c2893*/
          a1: &v1044[3],
          a2: "testing",
          a3: 7,
          a4: (unsigned __int8)*v1015,
          a5: 1);
        RBX::Telemetry::FieldsContainer::addField( /*0x1067c28b8*/
          a1: &v1044[3],
          a2: "isStudioToRcc",
          a3: 13,
          a4: (unsigned __int8)v1034[65],
          a5: 1);
        RBX::Telemetry::FieldsContainer::addField( /*0x1067c28dc*/
          a1: &v1044[3],
          a2: "isLocalRcc",
          a3: 10,
          a4: (unsigned __int8)FFlag::DebugLocalRccServerConnection,
          a5: 1);
        RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)__len); /*0x1067c28e8*/
        RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)__len); /*0x1067c28fb*/
      }
      v507 = (RBX::LocalizationService *)RBX::ServiceProvider::find<RBX::LocalizationService>( /*0x1067c2912*/
                                           a1: *((_QWORD *)v1034 + 3) + 464LL,
                                           a2: 0);
      if ( v507 != nullptr ) /*0x1067c291a*/
      {
        v508 = (RBX::Localization::TranslationLocaleId *)RBX::LocalizationService::getTranslationLocaleId(this: v507); /*0x1067c2923*/
        v509 = RBX::Localization::TranslationLocaleId::getUGCLocaleId(this: v508); /*0x1067c292b*/
        v510 = RBX::Localization::LocaleId::toLocaleString(a1: v509, a2: 1); /*0x1067c2938*/
        if ( v510 != 0 ) /*0x1067c2940*/
          std::string::basic_string[abi:ne200100](a1: __len, a2: v510, a3: v502); /*0x1067c2950*/
        else
          memset(__len, 0, sizeof(__len)); /*0x1067c2d22*/
        if ( ((__int64)v1020[0] & 1) != 0 ) /*0x1067c2d3c*/
          operator delete(a1: v1021); /*0x1067c2d45*/
        v1021 = (void *)__len[2]; /*0x1067c2d51*/
        *(_OWORD *)v1020 = *(_OWORD *)__len; /*0x1067c2d60*/
      }
    }
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "LocaleId", a3: v502, a4: v503); /*0x1067c2d79*/
    v1031[0] = __len; /*0x1067c2d85*/
    v522 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c2da2*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)__len,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1031,
             a5: (__int64)v1054);
    *((_QWORD *)v522 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v525, a2: v526, a3: v523, a4: v524); /*0x1067c2daa*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>( /*0x1067c2dbc*/
      a1: (__int64 **)v522 + 6,
      a2: (__int64)v1020);
    if ( (__len[0] & 1) != 0 ) /*0x1067c2dc8*/
      operator delete(a1: (void *)__len[2]); /*0x1067c2dd1*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "LocaleIdInternal", a3: v527, a4: v528); /*0x1067c2de7*/
    v1031[0] = __len; /*0x1067c2df3*/
    v529 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c2e10*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)__len,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1031,
             a5: (__int64)v1054);
    *((_QWORD *)v529 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v532, a2: v533, a3: v530, a4: v531); /*0x1067c2e18*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>( /*0x1067c2e2a*/
      a1: (__int64 **)v529 + 6,
      a2: (__int64)v1020);
    if ( (__len[0] & 1) != 0 ) /*0x1067c2e36*/
      operator delete(a1: (void *)__len[2]); /*0x1067c2e3f*/
    if ( v1022 != nullptr ) /*0x1067c2e4c*/
    {
      v539 = *(RBX::LocalizationService **)RBX::ServiceProvider::refByClass<RBX::LocalizationService>(this: v328); /*0x1067c2e5a*/
      if ( v539 != nullptr ) /*0x1067c2e60*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "ShowRobloxTranslations", a3: v537, a4: v538); /*0x1067c2e74*/
        v540 = RBX::GameConfigurer::getParamBool(a1: v1034, a2: __len); /*0x1067c2e87*/
        RBX::LocalizationService::setIsLoadingInternalRobloxTranslations(this: v539, a2: v540); /*0x1067c2e92*/
        if ( (__len[0] & 1) != 0 ) /*0x1067c2e9e*/
          operator delete(a1: (void *)__len[2]); /*0x1067c2ea7*/
        if ( DFFlag::AddTranslationDisplayMode == 1 ) /*0x1067c2eb6*/
        {
          std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "TranslationDisplayMode", a3: v541, a4: v542); /*0x1067c2ec6*/
          RBX::GameConfigurer::getParamString(a1: v938, a2: v1034, a3: __len); /*0x1067c2ee0*/
          RBX::LocalizationService::setTranslationDisplayMode(a1: v539, a2: v938); /*0x1067c2eef*/
          if ( (v938[0] & 1) != 0 ) /*0x1067c2efb*/
            operator delete(a1: v939); /*0x1067c2f04*/
          if ( (__len[0] & 1) != 0 ) /*0x1067c2f10*/
            operator delete(a1: (void *)__len[2]); /*0x1067c2f19*/
        }
        if ( DFFlag::AddImageTranslationContentVariantType == 1 ) /*0x1067c2f28*/
        {
          std::string::basic_string[abi:ne200100]<0>( /*0x1067c2f38*/
            a1: __len,
            a2: "ImageTranslationContentVariantType",
            a3: v541,
            a4: v542);
          RBX::GameConfigurer::getParamString(a1: v940, a2: v1034, a3: __len); /*0x1067c2f52*/
          RBX::LocalizationService::setImageTranslationContentVariantType(a1: v539, a2: v940); /*0x1067c2f61*/
          if ( (v940[0] & 1) != 0 ) /*0x1067c2f6d*/
            operator delete(a1: v941); /*0x1067c2f76*/
          if ( (__len[0] & 1) != 0 ) /*0x1067c2f82*/
            operator delete(a1: (void *)__len[2]); /*0x1067c2f8b*/
        }
        if ( DFFlag::AddImageTranslationSupportedLocales == 1 ) /*0x1067c2f9a*/
        {
          std::string::basic_string[abi:ne200100]<0>( /*0x1067c2fae*/
            a1: __len,
            a2: "SupportedLocalesForImageTranslation",
            a3: v541,
            a4: v542);
          RBX::GameConfigurer::getValueArray(a1: v942, a2: v1034, a3: __len); /*0x1067c2fc8*/
          RBX::LocalizationService::setupImageTranslationSupportedLocales(a1: v539, a2: v942); /*0x1067c2fd7*/
          v543 = v943; /*0x1067c2fdc*/
          if ( v943 != nullptr /*0x1067c2ff8*/
            && _InterlockedExchangeAdd64((volatile signed __int64 *)v943 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
          {
            (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v543 + 16LL))(a1: v543); /*0x1067c3000*/
            std::__shared_weak_count::__release_weak(this: v543); /*0x1067c3006*/
          }
          if ( (__len[0] & 1) != 0 ) /*0x1067c3012*/
            operator delete(a1: (void *)__len[2]); /*0x1067c301f*/
        }
      }
      goto LABEL_719; /*0x1067c3024*/
    }
  }
  if ( DFFlag::EnableThirdPartyVoiceMutingPlatformType == 1 ) /*0x1067c32c6*/
  {
    LODWORD(v1054[0]) = RBX::ThirdPartyUserService::getVoiceMutingPlatformType(this: v536); /*0x1067c32cd*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "VoiceMutingPlatformType", a3: v573, a4: v574); /*0x1067c32e1*/
    v1031[0] = __len; /*0x1067c32ed*/
    v575 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c330d*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)__len,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1031,
             a5: (__int64)v1026);
    *((_QWORD *)v575 + 5) = RBX::Reflection::Type::getSingleton<int>(a1: v576); /*0x1067c3315*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int,(int *)0>(a1: v575 + 48, a2: v1054); /*0x1067c3324*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c3330*/
      operator delete(a1: (void *)__len[2]); /*0x1067c3339*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "SuperSafeChat", a3: v534, a4: v535); /*0x1067c334c*/
  LOBYTE(__dst) = RBX::GameConfigurer::getParamBool(a1: v1034, a2: __len); /*0x1067c3364*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "SuperSafeChat", a3: v577, a4: v578); /*0x1067c337b*/
  v1054[0] = (__int64)v1031; /*0x1067c3384*/
  v579 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c33a4*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)v1026);
  *((_QWORD *)v579 + 5) = RBX::Reflection::Type::getSingleton<bool>(a1: v580); /*0x1067c33ac*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<bool,(bool *)0>(a1: v579 + 48, a2: &__dst); /*0x1067c33be*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c33ca*/
    operator delete(a1: v1032); /*0x1067c33d3*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c33df*/
    operator delete(a1: (void *)__len[2]); /*0x1067c33e8*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "MembershipType", a3: v581, a4: v582); /*0x1067c33fb*/
  RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c3415*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "MembershipType", a3: v583, a4: v584); /*0x1067c3428*/
  v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c3434*/
  v585 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3454*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1054,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1026,
           a5: (__int64)&__dst);
  *((_QWORD *)v585 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v588, a2: v589, a3: v586, a4: v587); /*0x1067c345c*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c346e*/
    a1: (__int64)(v585 + 48),
    a2: (__int64)__len);
  if ( (v1054[0] & 1) != 0 ) /*0x1067c3477*/
    operator delete(a1: v1055); /*0x1067c347d*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c3489*/
    operator delete(a1: (void *)__len[2]); /*0x1067c3492*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c349e*/
    operator delete(a1: v1032); /*0x1067c34a7*/
  if ( DFFlag::ReadHasRobloxSubscription == 1 ) /*0x1067c34b3*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "HasRobloxSubscription", a3: v590, a4: v591); /*0x1067c34c7*/
    LOBYTE(__dst) = RBX::GameConfigurer::getParamBool(a1: v1034, a2: __len); /*0x1067c34df*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "HasRobloxSubscription", a3: v592, a4: v593); /*0x1067c34f6*/
    v1054[0] = (__int64)v1031; /*0x1067c34ff*/
    v594 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c351f*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1031,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1054,
             a5: (__int64)v1026);
    *((_QWORD *)v594 + 5) = RBX::Reflection::Type::getSingleton<bool>(a1: v595); /*0x1067c3527*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<bool,(bool *)0>(a1: v594 + 48, a2: &__dst); /*0x1067c3539*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c3545*/
      operator delete(a1: v1032); /*0x1067c354e*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c355a*/
      operator delete(a1: (void *)__len[2]); /*0x1067c3563*/
  }
  if ( DFFlag::ReadAgeChecked == 1 ) /*0x1067c356f*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "AgeChecked", a3: v590, a4: v591); /*0x1067c3583*/
    RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c359d*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "AgeChecked", a3: v596, a4: v597); /*0x1067c35b0*/
    v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c35bc*/
    v598 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c35dc*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1054,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1026,
             a5: (__int64)&__dst);
    *((_QWORD *)v598 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v601, a2: v602, a3: v599, a4: v600); /*0x1067c35e4*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c35f6*/
      a1: (__int64)(v598 + 48),
      a2: (__int64)__len);
    if ( (v1054[0] & 1) != 0 ) /*0x1067c35ff*/
      operator delete(a1: v1055); /*0x1067c3605*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c3611*/
      operator delete(a1: (void *)__len[2]); /*0x1067c361a*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c3626*/
      operator delete(a1: v1032); /*0x1067c362f*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "AccountAge", a3: v590, a4: v591); /*0x1067c3642*/
  LODWORD(v1026[0]) = RBX::GameConfigurer::getParamInt(a1: v1034, a2: __len); /*0x1067c365a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "AccountAge", a3: v603, a4: v604); /*0x1067c3671*/
  v1054[0] = (__int64)v1031; /*0x1067c367a*/
  v605 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c369a*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)&__dst);
  *((_QWORD *)v605 + 5) = RBX::Reflection::Type::getSingleton<int>(a1: v606); /*0x1067c36a2*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int,(int *)0>(a1: v605 + 48, a2: v1026); /*0x1067c36b4*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c36c0*/
    operator delete(a1: v1032); /*0x1067c36c9*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c36d5*/
    operator delete(a1: (void *)__len[2]); /*0x1067c36de*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "CountryRegionCode", a3: v607, a4: v608); /*0x1067c36f4*/
  v1031[0] = __len; /*0x1067c3700*/
  v609 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c371d*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)__len,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1031,
           a5: (__int64)v1054);
  *((_QWORD *)v609 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v612, a2: v613, a3: v610, a4: v611); /*0x1067c3725*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>(a1: (__int64 **)v609 + 6, a2: (__int64)v982); /*0x1067c3737*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c3743*/
    operator delete(a1: (void *)__len[2]); /*0x1067c374c*/
  UserAgent = RBX::Http::getUserAgent(this: v614); /*0x1067c3756*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "UserAgentStr", a3: v616, a4: v617); /*0x1067c376a*/
  v1031[0] = __len; /*0x1067c3776*/
  v618 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3793*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)__len,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1031,
           a5: (__int64)v1054);
  *((_QWORD *)v618 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v621, a2: v622, a3: v619, a4: v620); /*0x1067c379b*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>(a1: (__int64 **)v618 + 6, a2: UserAgent); /*0x1067c37a9*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c37b5*/
    operator delete(a1: (void *)__len[2]); /*0x1067c37be*/
  RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)__len); /*0x1067c37ca*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "OsPlatform", a3: v623, a4: v624); /*0x1067c37e0*/
  v1054[0] = (__int64)v1031; /*0x1067c37e9*/
  v625 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3809*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)v1026);
  *((_QWORD *)v625 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v628, a2: v629, a3: v626, a4: v627); /*0x1067c3811*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c3823*/
    a1: (__int64)(v625 + 48),
    a2: (__int64)__len);
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c382f*/
    operator delete(a1: v1032); /*0x1067c3838*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c3844*/
    operator delete(a1: (void *)__len[2]); /*0x1067c384d*/
  RBX::SystemUtil::osPlatformName(this: (RBX::SystemUtil *)__len); /*0x1067c3859*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "OsPlatformName", a3: v630, a4: v631); /*0x1067c386f*/
  v1054[0] = (__int64)v1031; /*0x1067c3878*/
  v632 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3898*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)v1026);
  *((_QWORD *)v632 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v635, a2: v636, a3: v633, a4: v634); /*0x1067c38a0*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c38b2*/
    a1: (__int64)(v632 + 48),
    a2: (__int64)__len);
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c38be*/
    operator delete(a1: v1032); /*0x1067c38c7*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c38d3*/
    operator delete(a1: (void *)__len[2]); /*0x1067c38dc*/
  RBX::DebugSettings::getRobloxVersionSafe(this: (RBX::DebugSettings *)__len); /*0x1067c38e8*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "ClientRobloxVersion", a3: v637, a4: v638); /*0x1067c38fe*/
  v1054[0] = (__int64)v1031; /*0x1067c3907*/
  v639 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3927*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)v1026);
  *((_QWORD *)v639 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v642, a2: v643, a3: v640, a4: v641); /*0x1067c392f*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c3941*/
    a1: (__int64)(v639 + 48),
    a2: (__int64)__len);
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c394d*/
    operator delete(a1: v1032); /*0x1067c3956*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c3962*/
    operator delete(a1: (void *)__len[2]); /*0x1067c396b*/
  RobloxChannelName = RBX::GetRobloxChannelName(this: v644); /*0x1067c3975*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "ClientRobloxChannel", a3: v646, a4: v647); /*0x1067c3989*/
  v1031[0] = __len; /*0x1067c3995*/
  v648 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c39b2*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)__len,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1031,
           a5: (__int64)v1054);
  *((_QWORD *)v648 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v651, a2: v652, a3: v649, a4: v650); /*0x1067c39ba*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>( /*0x1067c39c8*/
    a1: (__int64 **)v648 + 6,
    a2: RobloxChannelName);
  if ( (__len[0] & 1) != 0 ) /*0x1067c39d4*/
    operator delete(a1: (void *)__len[2]); /*0x1067c39dd*/
  v1054[0] = RBX::SystemUtil::getMBSysRAM(this: v653); /*0x1067c39e7*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "ClientDeviceRamMegabytes", a3: v654, a4: v655); /*0x1067c39fc*/
  v1031[0] = __len; /*0x1067c3a08*/
  v656 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3a28*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)__len,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1031,
           a5: (__int64)v1026);
  *((_QWORD *)v656 + 5) = RBX::Reflection::Type::getSingleton<long long>(a1: v657); /*0x1067c3a30*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<long long,(long long *)0>(a1: v656 + 48, a2: v1054); /*0x1067c3a3f*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c3a4b*/
    operator delete(a1: (void *)__len[2]); /*0x1067c3a54*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "WhoCanWhisperChatWithMeInExperiences", a3: v658, a4: v659); /*0x1067c3a67*/
  isParamExist = RBX::GameConfigurer::isParamExist(a1: v1034, a2: __len); /*0x1067c3a7f*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c3a88*/
    operator delete(a1: (void *)__len[2]); /*0x1067c3a91*/
  if ( isParamExist != 0 ) /*0x1067c3a98*/
  {
    std::string::basic_string[abi:ne200100]<0>( /*0x1067c3aac*/
      a1: v1031,
      a2: "WhoCanWhisperChatWithMeInExperiences",
      a3: v660,
      a4: v661);
    RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c3ac6*/
    std::string::basic_string[abi:ne200100]<0>( /*0x1067c3ad9*/
      a1: v1054,
      a2: "WhoCanWhisperChatWithMeInExperiences",
      a3: v663,
      a4: v664);
    v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c3ae5*/
    v665 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3b05*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1054,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1026,
             a5: (__int64)&__dst);
    *((_QWORD *)v665 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v668, a2: v669, a3: v666, a4: v667); /*0x1067c3b0d*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c3b1f*/
      a1: (__int64)(v665 + 48),
      a2: (__int64)__len);
    if ( (v1054[0] & 1) != 0 ) /*0x1067c3b28*/
      operator delete(a1: v1055); /*0x1067c3b2e*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c3b3a*/
      operator delete(a1: (void *)__len[2]); /*0x1067c3b43*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c3b4f*/
    {
      v672 = v1032; /*0x1067c3b55*/
LABEL_790:
      operator delete(a1: v672); /*0x1067c3bf2*/
    }
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "NoOne", a3: v660, a4: v661); /*0x1067c3b6f*/
    std::string::basic_string[abi:ne200100]<0>( /*0x1067c3b85*/
      a1: v1031,
      a2: "WhoCanWhisperChatWithMeInExperiences",
      a3: v673,
      a4: v674);
    v1054[0] = (__int64)v1031; /*0x1067c3b8e*/
    v675 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3bae*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1031,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1054,
             a5: (__int64)v1026);
    *((_QWORD *)v675 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v678, a2: v679, a3: v676, a4: v677); /*0x1067c3bb6*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c3bc8*/
      a1: (__int64)(v675 + 48),
      a2: (__int64)__len);
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c3bd4*/
      operator delete(a1: v1032); /*0x1067c3bdd*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c3be9*/
    {
      v672 = (RBX::RbxDbgInfo *)__len[2]; /*0x1067c3beb*/
      goto LABEL_790; /*0x1067c3beb*/
    }
  }
  if ( FFlag::DebugForceChatDisabled == 1 ) /*0x1067c3bfe*/
    goto LABEL_801; /*0x1067c3bfe*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "GameChatType", a3: v670, a4: v671); /*0x1067c3c7f*/
  v680 = RBX::GameConfigurer::isParamExist(a1: v1034, a2: __len); /*0x1067c3c97*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c3ca0*/
    operator delete(a1: (void *)__len[2]); /*0x1067c3ca9*/
  if ( v680 == 0 ) /*0x1067c3cb0*/
  {
LABEL_801:
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "NoOne", a3: v670, a4: v671); /*0x1067c3d87*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "GameChatType", a3: v691, a4: v692); /*0x1067c3d9d*/
    v1054[0] = (__int64)v1031; /*0x1067c3da6*/
    v693 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3dc6*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1031,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1054,
             a5: (__int64)v1026);
    *((_QWORD *)v693 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v696, a2: v697, a3: v694, a4: v695); /*0x1067c3dce*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c3de0*/
      a1: (__int64)(v693 + 48),
      a2: (__int64)__len);
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c3dec*/
      operator delete(a1: v1032); /*0x1067c3df5*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c3e01*/
    {
      v690 = (RBX::RbxDbgInfo *)__len[2]; /*0x1067c3e03*/
      goto LABEL_805; /*0x1067c3e03*/
    }
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "GameChatType", a3: v670, a4: v671); /*0x1067c3cc4*/
    RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c3cde*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "GameChatType", a3: v681, a4: v682); /*0x1067c3cf1*/
    v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c3cfd*/
    v683 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3d1d*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1054,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1026,
             a5: (__int64)&__dst);
    *((_QWORD *)v683 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v686, a2: v687, a3: v684, a4: v685); /*0x1067c3d25*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c3d37*/
      a1: (__int64)(v683 + 48),
      a2: (__int64)__len);
    if ( (v1054[0] & 1) != 0 ) /*0x1067c3d40*/
      operator delete(a1: v1055); /*0x1067c3d46*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c3d52*/
      operator delete(a1: (void *)__len[2]); /*0x1067c3d5b*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c3d67*/
    {
      v690 = v1032; /*0x1067c3d6d*/
LABEL_805:
      operator delete(a1: v690); /*0x1067c3e0a*/
    }
  }
  if ( v1034[65] == 0 ) /*0x1067c3e1a*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "AllUsers", a3: v688, a4: v689); /*0x1067c3e2e*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "GameChatType", a3: v698, a4: v699); /*0x1067c3e44*/
    v1054[0] = (__int64)v1031; /*0x1067c3e4d*/
    v700 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3e6d*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1031,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1054,
             a5: (__int64)v1026);
    *((_QWORD *)v700 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v703, a2: v704, a3: v701, a4: v702); /*0x1067c3e75*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c3e87*/
      a1: (__int64)(v700 + 48),
      a2: (__int64)__len);
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c3e93*/
      operator delete(a1: v1032); /*0x1067c3e9c*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c3ea8*/
      operator delete(a1: (void *)__len[2]); /*0x1067c3eb1*/
  }
  if ( DFFlag::ConsumePlatformNameOverAlternateName == 1 ) /*0x1067c3ec0*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "PlatformName", a3: v688, a4: v689); /*0x1067c3ed4*/
    v707 = RBX::GameConfigurer::isParamExist(a1: v1034, a2: __len); /*0x1067c3eec*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c3ef5*/
      operator delete(a1: (void *)__len[2]); /*0x1067c3efe*/
    if ( v707 != 0 ) /*0x1067c3f05*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "PlatformName", a3: v705, a4: v706); /*0x1067c3f19*/
      RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c3f33*/
      std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "PlatformName", a3: v708, a4: v709); /*0x1067c3f46*/
      v917 = v1054; /*0x1067c3f52*/
      v710 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c3f72*/
               a1: (__int64 *)v1028,
               a2: (unsigned __int8 *)v1054,
               a3: (__int64)std::piecewise_construct,
               a4: (__int64)&v917,
               a5: (__int64)&v1019);
      *((_QWORD *)v710 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v713, a2: v714, a3: v711, a4: v712); /*0x1067c3f7a*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c3f8c*/
        a1: (__int64)(v710 + 48),
        a2: (__int64)__len);
LABEL_820:
      if ( (v1054[0] & 1) != 0 ) /*0x1067c4065*/
        operator delete(a1: v1055); /*0x1067c406b*/
      if ( (__len[0] & 1) != 0 ) /*0x1067c4077*/
        operator delete(a1: (void *)__len[2]); /*0x1067c4080*/
      if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c408c*/
        operator delete(a1: v1032); /*0x1067c4095*/
    }
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "AlternateName", a3: v688, a4: v689); /*0x1067c3fa4*/
    v715 = RBX::GameConfigurer::isParamExist(a1: v1034, a2: __len); /*0x1067c3fbc*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c3fc5*/
      operator delete(a1: (void *)__len[2]); /*0x1067c3fce*/
    if ( v715 != 0 ) /*0x1067c3fd5*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "AlternateName", a3: v705, a4: v706); /*0x1067c3fe9*/
      RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c4003*/
      std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "AlternateName", a3: v716, a4: v717); /*0x1067c4016*/
      v917 = v1054; /*0x1067c4022*/
      v718 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c4042*/
               a1: (__int64 *)v1028,
               a2: (unsigned __int8 *)v1054,
               a3: (__int64)std::piecewise_construct,
               a4: (__int64)&v917,
               a5: (__int64)&v1019);
      *((_QWORD *)v718 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v721, a2: v722, a3: v719, a4: v720); /*0x1067c404a*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c405c*/
        a1: (__int64)(v718 + 48),
        a2: (__int64)__len);
      goto LABEL_820; /*0x1067c405c*/
    }
  }
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "characterAppearanceId", a3: v705, a4: v706); /*0x1067c409a*/
  v1026[0] = (std::__shared_weak_count *)RBX::GameConfigurer::getParamInt64(a1: v1034, a2: __len); /*0x1067c40c0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "CharacterAppearanceId", a3: v723, a4: v724); /*0x1067c40d8*/
  v1054[0] = (__int64)v1031; /*0x1067c40e1*/
  v725 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c4101*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)&__dst);
  *((_QWORD *)v725 + 5) = RBX::Reflection::Type::getSingleton<long long>(a1: v726); /*0x1067c4109*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<long long,(long long *)0>(a1: v725 + 48, a2: v1026); /*0x1067c411b*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c4127*/
    operator delete(a1: v1032); /*0x1067c4130*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c413c*/
    operator delete(a1: (void *)__len[2]); /*0x1067c4145*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "CharacterAppearance", a3: v727, a4: v728); /*0x1067c4158*/
  RBX::GameConfigurer::getParamString(a1: __len, a2: v1034, a3: v1031); /*0x1067c4172*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "CharacterAppearance", a3: v729, a4: v730); /*0x1067c4185*/
  v1026[0] = (std::__shared_weak_count *)v1054; /*0x1067c4191*/
  v731 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c41b1*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1054,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1026,
           a5: (__int64)&__dst);
  *((_QWORD *)v731 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v734, a2: v735, a3: v732, a4: v733); /*0x1067c41b9*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c41cb*/
    a1: (__int64)(v731 + 48),
    a2: (__int64)__len);
  if ( (v1054[0] & 1) != 0 ) /*0x1067c41d4*/
    operator delete(a1: v1055); /*0x1067c41da*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c41e6*/
    operator delete(a1: (void *)__len[2]); /*0x1067c41ef*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c41fb*/
    operator delete(a1: v1032); /*0x1067c4204*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "FollowUserId", a3: v736, a4: v737); /*0x1067c4217*/
  v1026[0] = (std::__shared_weak_count *)RBX::GameConfigurer::getParamInt64(a1: v1034, a2: __len); /*0x1067c422f*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "FollowUserId", a3: v738, a4: v739); /*0x1067c4247*/
  v1054[0] = (__int64)v1031; /*0x1067c4250*/
  v740 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c4270*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)&__dst);
  *((_QWORD *)v740 + 5) = RBX::Reflection::Type::getSingleton<long long>(a1: v741); /*0x1067c4278*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<long long,(long long *)0>(a1: v740 + 48, a2: v1026); /*0x1067c428a*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c4296*/
    operator delete(a1: v1032); /*0x1067c429f*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c42ab*/
    operator delete(a1: (void *)__len[2]); /*0x1067c42b4*/
  v742 = (RBX::TeleportService *)RBX::ServiceProvider::find<RBX::TeleportService>( /*0x1067c42cb*/
                                   a1: *((_QWORD *)v1034 + 3) + 464LL,
                                   a2: 0);
  if ( v742 != nullptr ) /*0x1067c42d3*/
  {
    RawJoinData = RBX::TeleportService::getRawJoinData(this: v742); /*0x1067c42d8*/
    if ( (*(_BYTE *)RawJoinData & 1) != 0 ) /*0x1067c42e0*/
    {
      std::string::__init_copy_ctor_external( /*0x1067c43f5*/
        a1: &v985,
        a2: *(_QWORD *)(RawJoinData + 16),
        a3: *(_QWORD *)(RawJoinData + 8));
    }
    else
    {
      v747 = *(void **)(RawJoinData + 16); /*0x1067c42e6*/
      v986 = v747; /*0x1067c42ea*/
      v985 = *(_OWORD *)RawJoinData; /*0x1067c42f5*/
    }
    __len[2] = (size_t)v986; /*0x1067c4401*/
    *(_OWORD *)__len = v985; /*0x1067c4410*/
    v985 = 0; /*0x1067c441c*/
    v986 = nullptr; /*0x1067c4424*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "RawJoinData", a3: v746, a4: v747); /*0x1067c4440*/
    v1054[0] = (__int64)v1031; /*0x1067c4449*/
    v753 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c4469*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1031,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1054,
             a5: (__int64)v1026);
    *((_QWORD *)v753 + 5) = RBX::Reflection::Type::getSingleton<RBX::BinaryString>(); /*0x1067c4471*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<RBX::BinaryString,(RBX::BinaryString*)0>( /*0x1067c4483*/
      a1: v753 + 48,
      a2: __len);
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c448f*/
      operator delete(a1: v1032); /*0x1067c4498*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c44a4*/
      operator delete(a1: (void *)__len[2]); /*0x1067c44ad*/
    if ( (v985 & 1) != 0 ) /*0x1067c44b9*/
    {
      v752 = v986; /*0x1067c44bb*/
      goto LABEL_856; /*0x1067c44bb*/
    }
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v981, a2: "", a3: v743, a4: v744); /*0x1067c4310*/
    qmemcpy(__len, v981, sizeof(__len)); /*0x1067c431c*/
    memset(v981, 0, sizeof(v981)); /*0x1067c4337*/
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "RawJoinData", a3: v748, a4: v749); /*0x1067c435b*/
    v1054[0] = (__int64)v1031; /*0x1067c4364*/
    v750 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c4384*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1031,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1054,
             a5: (__int64)v1026);
    *((_QWORD *)v750 + 5) = RBX::Reflection::Type::getSingleton<RBX::BinaryString>(); /*0x1067c438c*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<RBX::BinaryString,(RBX::BinaryString*)0>( /*0x1067c439e*/
      a1: v750 + 48,
      a2: __len);
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c43aa*/
      operator delete(a1: v1032); /*0x1067c43b3*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c43bf*/
      operator delete(a1: (void *)__len[2]); /*0x1067c43c8*/
    if ( (v981[0] & 1) != 0 ) /*0x1067c43d4*/
    {
      v752 = *(void **)&v981[16]; /*0x1067c43da*/
LABEL_856:
      operator delete(a1: v752); /*0x1067c44c2*/
    }
  }
  if ( (v1034[88] & 1) != 0 ) /*0x1067c44d2*/
  {
    std::string::__init_copy_ctor_external(a1: &v987, a2: *((_QWORD *)v1034 + 13), a3: *((_QWORD *)v1034 + 12)); /*0x1067c4500*/
  }
  else
  {
    v754 = *((void **)v1034 + 13); /*0x1067c44d8*/
    v988 = v754; /*0x1067c44dc*/
    v987 = *(_OWORD *)(v1034 + 88); /*0x1067c44e7*/
  }
  __len[2] = (size_t)v988; /*0x1067c450c*/
  *(_OWORD *)__len = v987; /*0x1067c451b*/
  v987 = 0; /*0x1067c4527*/
  v988 = nullptr; /*0x1067c452f*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "ClientJoinData", a3: v751, a4: v754); /*0x1067c454b*/
  v1054[0] = (__int64)v1031; /*0x1067c4554*/
  v755 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c4574*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)v1026);
  *((_QWORD *)v755 + 5) = RBX::Reflection::Type::getSingleton<RBX::BinaryString>(); /*0x1067c457c*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<RBX::BinaryString,(RBX::BinaryString*)0>( /*0x1067c458e*/
    a1: v755 + 48,
    a2: __len);
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c459a*/
    operator delete(a1: v1032); /*0x1067c45a3*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c45af*/
    operator delete(a1: (void *)__len[2]); /*0x1067c45b8*/
  if ( (v987 & 1) != 0 ) /*0x1067c45c4*/
    operator delete(a1: v988); /*0x1067c45cd*/
  if ( (v1034[112] & 1) != 0 ) /*0x1067c45dd*/
  {
    std::string::__init_copy_ctor_external(a1: &v989, a2: *((_QWORD *)v1034 + 16), a3: *((_QWORD *)v1034 + 15)); /*0x1067c460e*/
  }
  else
  {
    v757 = *((void **)v1034 + 16); /*0x1067c45e3*/
    v990 = v757; /*0x1067c45e7*/
    v989 = *((_OWORD *)v1034 + 7); /*0x1067c45f2*/
  }
  __len[2] = (size_t)v990; /*0x1067c461a*/
  *(_OWORD *)__len = v989; /*0x1067c4629*/
  v989 = 0; /*0x1067c4635*/
  v990 = nullptr; /*0x1067c463d*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "GameJoinContext", a3: v756, a4: v757); /*0x1067c4659*/
  v1054[0] = (__int64)v1031; /*0x1067c4662*/
  v758 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c4682*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)v1026);
  *((_QWORD *)v758 + 5) = RBX::Reflection::Type::getSingleton<RBX::BinaryString>(); /*0x1067c468a*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<RBX::BinaryString,(RBX::BinaryString*)0>( /*0x1067c469c*/
    a1: v758 + 48,
    a2: __len);
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c46a8*/
    operator delete(a1: v1032); /*0x1067c46b1*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c46bd*/
    operator delete(a1: (void *)__len[2]); /*0x1067c46c6*/
  if ( (v989 & 1) != 0 ) /*0x1067c46d2*/
    operator delete(a1: v990); /*0x1067c46db*/
  if ( DFFlag::EnablePreloading == 1 && *((int *)v1034 + 40) > 0 ) /*0x1067c46fe*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "PreloadedVersion", a3: v759, a4: v760); /*0x1067c4711*/
    v1031[0] = __len; /*0x1067c471d*/
    v761 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c473a*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)__len,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1031,
             a5: (__int64)v1054);
    v763 = RBX::Reflection::Type::getSingleton<int>(a1: v762); /*0x1067c473d*/
    v764 = v1034 + 160; /*0x1067c4749*/
    *((_QWORD *)v761 + 5) = v763; /*0x1067c4750*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int>(a1: (__int64 *)v761 + 6, a2: v764); /*0x1067c475b*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c4767*/
      operator delete(a1: (void *)__len[2]); /*0x1067c4770*/
  }
  if ( FFlag::DebugLocalRccTicketTesting == 1 ) /*0x1067c477f*/
  {
    v765 = *((_QWORD *)v1034 + 3); /*0x1067c478c*/
    if ( (*(_BYTE *)(v765 + 744) & 1) != 0 ) /*0x1067c4797*/
    {
      std::string::__init_copy_ctor_external(a1: __len, a2: *(_QWORD *)(v765 + 760), a3: *(_QWORD *)(v765 + 752)); /*0x1067c47cd*/
    }
    else
    {
      v766 = v765 + 744; /*0x1067c4799*/
      v767 = *(_QWORD *)(v766 + 16); /*0x1067c479f*/
      __len[2] = v767; /*0x1067c47a3*/
      *(_OWORD *)__len = *(_OWORD *)v766; /*0x1067c47ae*/
    }
    std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "DebugGameId", a3: v759, a4: v767); /*0x1067c47e3*/
    v1054[0] = (__int64)v1031; /*0x1067c47ec*/
    v768 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c480c*/
             a1: (__int64 *)v1028,
             a2: (unsigned __int8 *)v1031,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v1054,
             a5: (__int64)v1026);
    *((_QWORD *)v768 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v771, a2: v772, a3: v769, a4: v770); /*0x1067c4814*/
    RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string,(std::string*)0>( /*0x1067c4826*/
      a1: (__int64)(v768 + 48),
      a2: (__int64)__len);
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c4832*/
      operator delete(a1: v1032); /*0x1067c483b*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c4847*/
      operator delete(a1: (void *)__len[2]); /*0x1067c4850*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "IsUnknownOrUnder13", a3: v759, a4: v760); /*0x1067c4863*/
  LOBYTE(__dst) = RBX::GameConfigurer::getParamBool(a1: v1034, a2: __len); /*0x1067c487b*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "IsUnder13", a3: v773, a4: v774); /*0x1067c4892*/
  v1054[0] = (__int64)v1031; /*0x1067c489b*/
  v775 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c48be*/
           a1: (__int64 *)v1028,
           a2: (unsigned __int8 *)v1031,
           a3: (__int64)std::piecewise_construct,
           a4: (__int64)v1054,
           a5: (__int64)v1026);
  *((_QWORD *)v775 + 5) = RBX::Reflection::Type::getSingleton<bool>(a1: v776); /*0x1067c48c6*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<bool,(bool *)0>(a1: v775 + 48, a2: &__dst); /*0x1067c48d8*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c48e4*/
    operator delete(a1: v1032); /*0x1067c48ed*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c48f9*/
    operator delete(a1: (void *)__len[2]); /*0x1067c4902*/
  v1022 = (RBX::AppQoSInstance **)RBX::Subsystem<RBX::AppQoSInstance,false>::startup<RBX::SubsystemDefaultFactory<RBX::AppQoSInstance>>(); /*0x1067c490c*/
  v1042 = 0; /*0x1067c4917*/
  *(_OWORD *)&__len[1] = 0; /*0x1067c491f*/
  LOWORD(v1043) = 0; /*0x1067c4927*/
  memset(v1044, 0, sizeof(v1044)); /*0x1067c4930*/
  __len[0] = v997; /*0x1067c494f*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "PlaceId", a3: v777, a4: v778); /*0x1067c4964*/
  __len[1] = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: v1031); /*0x1067c497c*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c498a*/
    operator delete(a1: v1032); /*0x1067c4993*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "AccountAge", a3: v779, a4: v780); /*0x1067c49a6*/
  LODWORD(v1042) = RBX::GameConfigurer::getParamInt(a1: v1034, a2: v1031); /*0x1067c49be*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c49cb*/
    operator delete(a1: v1032); /*0x1067c49d4*/
  v781 = (RBX::TeleportService *)RBX::ServiceProvider::find<RBX::TeleportService>( /*0x1067c49eb*/
                                   a1: *((_QWORD *)v1034 + 3) + 464LL,
                                   a2: 0);
  v784 = v781; /*0x1067c49f0*/
  if ( v781 != nullptr ) /*0x1067c49f6*/
  {
    __len[2] = RBX::TeleportService::getPreviousUniverseId(this: v781); /*0x1067c4a00*/
    LOBYTE(v1043) = RBX::TeleportService::getPreviousPlaceId(this: v784) > 0; /*0x1067c4a12*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "HasVerifiedBadge", a3: v782, a4: v783); /*0x1067c4a27*/
  BYTE1(v1043) = RBX::GameConfigurer::getParamBool(a1: v1034, a2: v1031); /*0x1067c4a46*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c4a50*/
    operator delete(a1: v1032); /*0x1067c4a59*/
  std::string::operator=(a1: v1044, a2: &v1011); /*0x1067c4a68*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "MembershipType", a3: v785, a4: v786); /*0x1067c4a78*/
  RBX::GameConfigurer::getParamString(a1: v1031, a2: v1034, a3: v1054); /*0x1067c4a8f*/
  if ( ((__int64)v1044[3] & 1) != 0 ) /*0x1067c4a9e*/
    operator delete(a1: v1044[5]); /*0x1067c4aa7*/
  v1044[5] = v1032; /*0x1067c4ab3*/
  *(_OWORD *)&v1044[3] = *(_OWORD *)v1031; /*0x1067c4abf*/
  LOWORD(v1031[0]) = 0; /*0x1067c4ac3*/
  if ( (v1054[0] & 1) != 0 ) /*0x1067c4ad0*/
    operator delete(a1: v1055); /*0x1067c4ad6*/
  RBX::DebugSettings::getRobloxVersionSafe(this: (RBX::DebugSettings *)v1031); /*0x1067c4ae2*/
  RBX::AppQoSGameJoiningInfo::setVersion(a1: __len, a2: v1031); /*0x1067c4af5*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c4b01*/
    operator delete(a1: v1032); /*0x1067c4b0a*/
  if ( v1022 != nullptr ) /*0x1067c4b19*/
    v787 = v1022[3]; /*0x1067c4b1b*/
  else
    v787 = nullptr; /*0x1067c4b21*/
  RBX::AppQoSInstance::onGameConnecting( /*0x1067c4b31*/
    this: v787,
    a2: (const RBX::AppQoSGameJoiningInfo *)__len,
    a3: (RBX::Reflection::ValueTable *)v1028);
  if ( (*(_BYTE *)(v318 + 2320) & 1) != 0 ) /*0x1067c4b45*/
    operator delete(a1: *(void **)(v318 + 2336)); /*0x1067c4b4e*/
  *(_QWORD *)(v318 + 2336) = v1021; /*0x1067c4b5a*/
  *(_OWORD *)(v318 + 2320) = *(_OWORD *)v1020; /*0x1067c4b65*/
  LOWORD(v1020[0]) = 0; /*0x1067c4b68*/
  if ( (*(_BYTE *)(v318 + 2344) & 1) != 0 ) /*0x1067c4b80*/
    operator delete(a1: *(void **)(v318 + 2360)); /*0x1067c4b89*/
  *(_QWORD *)(v318 + 2360) = v1010; /*0x1067c4b95*/
  *(_OWORD *)(v318 + 2344) = v1009; /*0x1067c4ba1*/
  LOWORD(v1009) = 0; /*0x1067c4ba5*/
  std::string::operator=(a1: v318 + 2368, a2: v982); /*0x1067c4bbc*/
  if ( (*(_BYTE *)(v318 + 2392) & 1) != 0 ) /*0x1067c4bd3*/
    operator delete(a1: *(void **)(v318 + 2408)); /*0x1067c4bdc*/
  *(_QWORD *)(v318 + 2408) = v1005; /*0x1067c4be8*/
  *(_OWORD *)(v318 + 2392) = v1004; /*0x1067c4bf4*/
  LOWORD(v1004) = 0; /*0x1067c4bf8*/
  v788 = *((_QWORD *)v1034 + 3); /*0x1067c4c08*/
  if ( v788 != 0 ) /*0x1067c4c0f*/
    v789 = (RBX::PlayerHydrationService *)RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::PlayerHydrationService>(this: (RBX::ServiceProvider *)(v788 + 464)); /*0x1067c4c1d*/
  else
    v789 = nullptr; /*0x1067c4c22*/
  RBX::PlayerHydrationService::hydrate(this: v789, a2: v997, a3: (RBX::Reflection::ValueTable *)v1028); /*0x1067c4c32*/
  RBX::make_shared<RBX::Reflection::ValueTable const,RBX::Reflection::ValueTable&>(a1: v965, a2: v1028); /*0x1067c4c45*/
  v910 = 0; /*0x1067c4c4e*/
  v911 = 0; /*0x1067c4c56*/
  std::string::basic_string[abi:ne200100]<0>(a1: v944, a2: "ServerConnections", a3: v790, a4: v791); /*0x1067c4c6f*/
  RBX::PlayerConfigurer::fillServerConnectionsArrayFromConfig(a1: v1034, a2: &v910, a3: v944); /*0x1067c4c89*/
  if ( (v944[0] & 1) != 0 ) /*0x1067c4c95*/
    operator delete(a1: v945); /*0x1067c4c9e*/
  v912 = 0; /*0x1067c4ca7*/
  v913 = 0; /*0x1067c4caf*/
  std::string::basic_string[abi:ne200100]<0>(a1: v946, a2: "UdmuxEndpoints", a3: v792, a4: v793); /*0x1067c4cc8*/
  RBX::PlayerConfigurer::fillServerConnectionsArrayFromConfig(a1: v1034, a2: &v912, a3: v946); /*0x1067c4ce2*/
  if ( (v946[0] & 1) != 0 ) /*0x1067c4cee*/
    operator delete(a1: v947); /*0x1067c4cf7*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "DirectServerReturn", a3: v794, a4: v795); /*0x1067c4d0a*/
  v798 = RBX::GameConfigurer::getParamBool(a1: v1034, a2: v1031); /*0x1067c4d22*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c4d2c*/
    operator delete(a1: v1032); /*0x1067c4d35*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1031, a2: "TokenValue", a3: v796, a4: v797); /*0x1067c4d48*/
  RBX::GameConfigurer::getParamString(a1: &v975, a2: v1034, a3: v1031); /*0x1067c4d62*/
  if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c4d6e*/
    operator delete(a1: v1032); /*0x1067c4d77*/
  v991 = 0; /*0x1067c4d80*/
  v992 = nullptr; /*0x1067c4d88*/
  if ( (v975 & 1) != 0 ) /*0x1067c4d9e*/
  {
    v799 = (char *)v978; /*0x1067c4da0*/
    v800 = v977; /*0x1067c4da7*/
  }
  else
  {
    v800 = v975 >> 1; /*0x1067c4db0*/
    v799 = &v976; /*0x1067c4db2*/
  }
  base64<char,std::char_traits<char>>::decode(a1: (__int64)v799, a2: v800, a3: (__int64)&v991); /*0x1067c4dc0*/
  if ( (v991 & 1) != 0 ) /*0x1067c4dcf*/
  {
    v801 = (char *)v992; /*0x1067c4dd1*/
    v802 = *((_QWORD *)&v991 + 1); /*0x1067c4dd8*/
  }
  else
  {
    v802 = (unsigned __int8)v991 >> 1; /*0x1067c4de1*/
    v801 = (char *)&v991 + 1; /*0x1067c4de3*/
  }
  RBX::Rupp::TokenTlv::Token::Token(a1: v1039, a2: 1, a3: v801, a4: v802); /*0x1067c4df6*/
  if ( FFlag::DebugLocalRccServerConnection == 1 && FFlag::DebugLocalRccRuppToken == 1 ) /*0x1067c4e15*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "MachineAddress", a3: v803, a4: v804); /*0x1067c4e26*/
    RBX::GameConfigurer::getParamString(a1: v1031, a2: v1034, a3: v1054); /*0x1067c4e3d*/
    if ( (v1054[0] & 1) != 0 ) /*0x1067c4e46*/
      operator delete(a1: v1055); /*0x1067c4e4c*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c4e59*/
    {
      if ( v1031[1] != nullptr ) /*0x1067c4e70*/
      {
        v808 = v1032; /*0x1067c4e72*/
        goto LABEL_940; /*0x1067c4e72*/
      }
    }
    else if ( LOBYTE(v1031[0]) != 0 ) /*0x1067c4e5d*/
    {
      v808 = (RBX::RbxDbgInfo *)((char *)v1031 + 1); /*0x1067c4e5f*/
LABEL_940:
      RBX::RbxDbgInfo::SetServerIP(this: v808, a2: v807); /*0x1067c4e79*/
    }
    std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "ServerPort", a3: v805, a4: v806); /*0x1067c4e7e*/
    v809 = RBX::GameConfigurer::getParamInt(a1: v1034, a2: v1054); /*0x1067c4e9e*/
    if ( (v1054[0] & 1) != 0 ) /*0x1067c4ea4*/
      operator delete(a1: v1055); /*0x1067c4eaa*/
    if ( v809 != 0 ) /*0x1067c4eb1*/
      RBX::RbxDbgInfo::SetDebugServerPort(this: (RBX::RbxDbgInfo *)v809, a2: v810); /*0x1067c4eb5*/
    if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c4ec1*/
      operator delete(a1: v1032); /*0x1067c4eca*/
  }
  LOBYTE(v1008) = 0; /*0x1067c4ecf*/
  BYTE4(v1008) = 0; /*0x1067c4ed7*/
  LOBYTE(v1037[0]) = 0; /*0x1067c4edd*/
  v1038[1] = 0; /*0x1067c4ee3*/
  LOBYTE(v1031[0]) = 0; /*0x1067c4ee9*/
  v1033 = 0; /*0x1067c4eef*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "NetStackTokenValue", a3: v803, a4: v804); /*0x1067c4f00*/
  RBX::GameConfigurer::getParamString(a1: &v1000, a2: v1034, a3: v1054); /*0x1067c4f17*/
  if ( (v1054[0] & 1) != 0 ) /*0x1067c4f20*/
    operator delete(a1: v1055); /*0x1067c4f26*/
  v1006 = 0; /*0x1067c4f2f*/
  v1007 = nullptr; /*0x1067c4f37*/
  if ( (v1000 & 1) != 0 ) /*0x1067c4f4d*/
  {
    v811 = (char *)v1003; /*0x1067c4f4f*/
    v812 = v1002; /*0x1067c4f56*/
  }
  else
  {
    v812 = v1000 >> 1; /*0x1067c4f5f*/
    v811 = &v1001; /*0x1067c4f61*/
  }
  base64<char,std::char_traits<char>>::decode(a1: (__int64)v811, a2: v812, a3: (__int64)&v1006); /*0x1067c4f6f*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "NetStackPort", a3: v813, a4: v814); /*0x1067c4f7f*/
  v817 = RBX::GameConfigurer::getParamInt(a1: v1034, a2: v1054); /*0x1067c4f94*/
  if ( (v1054[0] & 1) != 0 ) /*0x1067c4f9a*/
    operator delete(a1: v1055); /*0x1067c4fa0*/
  v1016 = v817; /*0x1067c4fa5*/
  if ( DFFlag::RbxTransportUseGameFqdn == 1 )
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v1026, a2: "GameFqdn", a3: v815, a4: v816); /*0x1067c4fc6*/
    RBX::GameConfigurer::getParamString(a1: v1054, a2: v1034, a3: v1026); /*0x1067c4fdd*/
    if ( ((__int64)v1026[0] & 1) != 0 ) /*0x1067c4fe9*/
      operator delete(a1: v1027); /*0x1067c4ff2*/
    v819 = v1054[0]; /*0x1067c4ff7*/
    if ( DFFlag::RbxTransportReadLowercaseGameFqdn == 1 )
    {
      v820 = (v1054[0] & 1) != 0 ? v1054[1] : LOBYTE(v1054[0]) >> 1;
      if ( v820 == 0 ) /*0x1067c5019*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "gameFqdn", a3: v818, a4: 0); /*0x1067c5029*/
        RBX::GameConfigurer::getParamString(a1: v1026, a2: v1034, a3: &__dst); /*0x1067c5043*/
        if ( (v1054[0] & 1) != 0 ) /*0x1067c504c*/
          operator delete(a1: v1055); /*0x1067c5052*/
        v1055 = (RBX::Time *)v1027; /*0x1067c505e*/
        *(_OWORD *)v1054 = *(_OWORD *)v1026; /*0x1067c506a*/
        LOWORD(v1026[0]) = 0; /*0x1067c506f*/
        if ( (__dst & 1) != 0 ) /*0x1067c507f*/
          operator delete(a1: v1025); /*0x1067c5088*/
        v819 = v1054[0]; /*0x1067c508d*/
      }
    }
    if ( (v819 & 1) != 0 ) /*0x1067c5092*/
      v821 = v1054[1]; /*0x1067c5094*/
    else
      v821 = v819 >> 1; /*0x1067c509e*/
    if ( v821 != 0 ) /*0x1067c50a4*/
    {
      if ( (unsigned __int8)DFLog::PlayerConfigurer >= 6u && BYTE1(DFLog::PlayerConfigurer) >= 5u ) /*0x1067c50bb*/
        FLog::FastLogSafeFormatted<std::string &>( /*0x1067c50df*/
          a1: DFLog::PlayerConfigurer,
          a2: qword_10D80BC08,
          a3: 5,
          a4: (int)"[DFLog::PlayerConfigurer] Received GameFqdn from join script. GameFqdn = {}",
          a5: 75,
          a6: (unsigned __int8 *)v1054);
      if ( v1033 == 1 ) /*0x1067c50eb*/
      {
        if ( ((__int64)v1031[0] & 1) != 0 ) /*0x1067c50f4*/
          operator delete(a1: v1032); /*0x1067c50fd*/
        v1032 = v1055; /*0x1067c5106*/
        *(_OWORD *)v1031 = *(_OWORD *)v1054; /*0x1067c5112*/
      }
      else
      {
        v1032 = v1055; /*0x1067c512f*/
        *(_OWORD *)v1031 = *(_OWORD *)v1054; /*0x1067c513b*/
        v1033 = 1; /*0x1067c5143*/
      }
    }
    else if ( (v819 & 1) != 0 ) /*0x1067c511e*/
    {
      operator delete(a1: v1055); /*0x1067c5124*/
    }
  }
  if ( (unsigned __int8)RBX::Network::Peer::isLocalTest(this: v1023) != 0 ) /*0x1067c5158*/
  {
    if ( (v1000 & 1) != 0 ) /*0x1067c5163*/
      v822 = v1002; /*0x1067c5165*/
    else
      v822 = v1000 >> 1; /*0x1067c5172*/
    v823 = v822 == 0; /*0x1067c5177*/
  }
  else
  {
    v823 = false; /*0x1067c516e*/
  }
  if ( v1016 > 0 && ((v1000 & 1) == 0 ? (v824 = v1000 >> 1) : (v824 = v1002), v823 || v824 != 0) )
  {
    v825 = (unsigned __int8)DFLog::PlayerConfigurer >= 6u && BYTE1(DFLog::PlayerConfigurer) >= 5u; /*0x1067c51c8*/
    if ( v823 ) /*0x1067c51cd*/
    {
      if ( v825 ) /*0x1067c51d5*/
      {
        v1026[0] = (std::__shared_weak_count *)v1016; /*0x1067c51e2*/
        v1054[0] = 1; /*0x1067c51e9*/
        v1054[1] = (__int64)v1026; /*0x1067c51f1*/
        FLog::detail::FastLogSafeFormattedInternal( /*0x1067c5217*/
          a1: DFLog::PlayerConfigurer,
          a2: qword_10D80BC08,
          a3: 5,
          a4: (unsigned int)"[DFLog::PlayerConfigurer] Received RbxTransport port without token (local test, no RUPP). rbxTransportPort = {}",
          a5: 111,
          a6: 1,
          1,
          v1026);
      }
    }
    else
    {
      if ( v825 ) /*0x1067c5277*/
        FLog::FastLogSafeFormatted<std::string &,int &>( /*0x1067c52a4*/
          a1: DFLog::PlayerConfigurer,
          a2: qword_10D80BC08,
          a3: 5,
          a4: (int)"[DFLog::PlayerConfigurer] Received RbxTransport token and port. rbxTransportTokenValue = {}, rbxTransportPort = {}",
          a5: 114,
          a6: (unsigned __int8 *)&v1006,
          a7: (unsigned int *)&v1016);
      if ( (v1006 & 1) != 0 ) /*0x1067c52b3*/
      {
        v826 = (char *)v1007; /*0x1067c52b5*/
        v827 = *((_QWORD *)&v1006 + 1); /*0x1067c52bc*/
      }
      else
      {
        v827 = (unsigned __int8)v1006 >> 1; /*0x1067c52c5*/
        v826 = (char *)&v1006 + 1; /*0x1067c52c7*/
      }
      RBX::Rupp::TokenTlv::Token::Token(a1: v1054, a2: 1, a3: v826, a4: v827); /*0x1067c52d7*/
      v1038[0] = (_BYTE)v1055; /*0x1067c52df*/
      *(_OWORD *)v1037 = *(_OWORD *)v1054; /*0x1067c52ea*/
      v1038[1] = 1; /*0x1067c52f2*/
    }
    LODWORD(v1008) = v1016; /*0x1067c52ff*/
    BYTE4(v1008) = 1; /*0x1067c5305*/
  }
  else if ( (unsigned __int8)DFLog::PlayerConfigurer >= 6u && (DFLog::PlayerConfigurer & 0xFE00) != 0 ) /*0x1067c5235*/
  {
    FLog::FastLogSafeFormatted<std::string &,int &>( /*0x1067c526b*/
      a1: DFLog::PlayerConfigurer,
      a2: qword_10D80BC08,
      a3: 2,
      a4: (int)"[DFLog::PlayerConfigurer] RbxTransport token or port is empty. rbxTransportTokenValue = {}, rbxTransportPort = {}",
      a5: 113,
      a6: (unsigned __int8 *)&v1006,
      a7: (unsigned int *)&v1016);
  }
  if ( DFFlag::ReportRbxTransportAvailability == 1 ) /*0x1067c5313*/
    RBX::PlayerConfigurer::reportRbxTransportAvailabilityTelemetry(a1: &v1008, a2: v1037); /*0x1067c5323*/
  ConnectionNetworkPath = RBX::Network::Client::getConnectionNetworkPath(this: v1023); /*0x1067c532f*/
  RBX::Transport::reportConnectionAttemptResult(a1: 0, a2: ConnectionNetworkPath); /*0x1067c5339*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1054, a2: "UserId", a3: v829, a4: v830); /*0x1067c5349*/
  v831 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: v1054); /*0x1067c535e*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1026, a2: "MachineAddress", a3: v832, a4: v833); /*0x1067c536f*/
  RBX::GameConfigurer::getParamString(a1: v948, a2: v1034, a3: v1026); /*0x1067c5389*/
  std::string::basic_string[abi:ne200100]<0>(a1: &__dst, a2: "ServerPort", a3: v834, a4: v835); /*0x1067c539c*/
  v836 = RBX::GameConfigurer::getParamInt(a1: v1034, a2: &__dst); /*0x1067c53b4*/
  std::string::basic_string[abi:ne200100]<0>(a1: v950, a2: "ClientPort", a3: v837, a4: v838); /*0x1067c53c5*/
  v839 = RBX::GameConfigurer::getParamInt(a1: v1034, a2: v950); /*0x1067c53dd*/
  std::string::basic_string[abi:ne200100]<0>(a1: v952, a2: "DataCenterId", a3: v840, a4: v841); /*0x1067c53ed*/
  v842 = RBX::GameConfigurer::getParamInt(a1: v1034, a2: v952); /*0x1067c5405*/
  std::string::basic_string[abi:ne200100]<0>(a1: v956, a2: "UserName", a3: v843, a4: v844); /*0x1067c5416*/
  RBX::GameConfigurer::getParamString(a1: v954, a2: v1034, a3: v956); /*0x1067c5430*/
  std::string::basic_string[abi:ne200100]<0>(a1: v958, a2: "IsUnknownOrUnder13", a3: v845, a4: v846); /*0x1067c5443*/
  v995 = v842; /*0x1067c5448*/
  LODWORD(v1017) = v839; /*0x1067c544f*/
  v847 = RBX::GameConfigurer::getParamBool(a1: v1034, a2: v958); /*0x1067c5468*/
  v996 = v836; /*0x1067c546a*/
  v848 = v831; /*0x1067c5471*/
  *(_OWORD *)v964 = *(_OWORD *)v965; /*0x1067c5482*/
  if ( v965[1] != nullptr ) /*0x1067c548c*/
    _InterlockedIncrement64((volatile signed __int64 *)v965[1] + 1); /*0x1067c548e*/
  v849 = v1008; /*0x1067c5493*/
  v1036 = *(_WORD *)v1038; /*0x1067c54a1*/
  v1035 = *(_OWORD *)v1037; /*0x1067c54b0*/
  std::__optional_copy_base<std::string,false>::__optional_copy_base[abi:ne200100](a1: v914, a2: v1031); /*0x1067c54c9*/
  LOBYTE(v979) = 0; /*0x1067c54d0*/
  v980 = 0; /*0x1067c54d6*/
  if ( (_BYTE)v1018 != 0 ) /*0x1067c54e3*/
  {
    v979 = 0; /*0x1067c54e5*/
    _InterlockedExchange64(&v979, (__int64)v999); /*0x1067c54f7*/
    v980 = 1; /*0x1067c54fe*/
  }
  RBX::Network::Client::playerConnect( /*0x1067c55ad*/
    a1: (_DWORD)v1023,
    a2: v848,
    a3: (unsigned int)v948,
    a4: v996,
    a5: LODWORD(v1017),
    a6: -1,
    a7: v995,
    a8: (unsigned int)v954,
    a9: v847,
    a10: (__int64)v964,
    a11: (__int64)&v910,
    a12: (__int64)&v912,
    a13: (__int64)v1039,
    a14: v798,
    a15: v849,
    a16: v1035,
    a17: DWORD2(v1035),
    a18: v1036,
    a19: (__int64)v914,
    a20: (__int64)&v979);
  if ( v916 == 1 && (v914[0] & 1) != 0 ) /*0x1067c55c2*/
    operator delete(a1: v915); /*0x1067c55cb*/
  v851 = v964[1]; /*0x1067c55d0*/
  if ( v964[1] != nullptr /*0x1067c55ec*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v964[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v851 + 16LL))(a1: v851); /*0x1067c55f4*/
    std::__shared_weak_count::__release_weak(this: v851); /*0x1067c55fa*/
  }
  if ( (v958[0] & 1) != 0 ) /*0x1067c5606*/
    operator delete(a1: v959); /*0x1067c560f*/
  if ( (v954[0] & 1) != 0 ) /*0x1067c561b*/
    operator delete(a1: v955); /*0x1067c5624*/
  if ( (v956[0] & 1) != 0 ) /*0x1067c5630*/
    operator delete(a1: v957); /*0x1067c5639*/
  if ( (v952[0] & 1) != 0 ) /*0x1067c5645*/
    operator delete(a1: v953); /*0x1067c564e*/
  if ( (v950[0] & 1) != 0 ) /*0x1067c565a*/
    operator delete(a1: v951); /*0x1067c5663*/
  if ( (__dst & 1) != 0 ) /*0x1067c566f*/
    operator delete(a1: v1025); /*0x1067c5678*/
  if ( (v948[0] & 1) != 0 ) /*0x1067c5684*/
    operator delete(a1: v949); /*0x1067c568d*/
  if ( ((__int64)v1026[0] & 1) != 0 ) /*0x1067c5699*/
    operator delete(a1: v1027); /*0x1067c56a2*/
  if ( (v1054[0] & 1) != 0 ) /*0x1067c56ab*/
    operator delete(a1: v1055); /*0x1067c56b1*/
  if ( FFlag::DebugSendAttemptsToDiagCase1 == 1 )
  {
    if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067c56cf*/
    {
      if ( *((_QWORD *)&RBX::Analytics::location + 1) != 2 ) /*0x1067c56e0*/
        goto LABEL_1047; /*0x1067c56e0*/
      v852 = qword_10D50FFF8; /*0x1067c56e2*/
    }
    else
    {
      if ( (_BYTE)RBX::Analytics::location != 4 ) /*0x1067c56d4*/
        goto LABEL_1047; /*0x1067c56d4*/
      v852 = (_WORD *)((char *)&RBX::Analytics::location + 1); /*0x1067c56d6*/
    }
    if ( *v852 != 21333 || v1034[409] != 1 ) /*0x1067c56fb*/
      goto LABEL_1047; /*0x1067c56fb*/
    v853 = v1034[328]; /*0x1067c56fd*/
    if ( (v853 & 1) != 0 )
    {
      if ( *((_QWORD *)v1034 + 42) == 2 )
      {
        v854 = *((char **)v1034 + 43); /*0x1067c5724*/
LABEL_1046:
        if ( *(_WORD *)v854 != 18228 ) /*0x1067c5730*/
          goto LABEL_1047; /*0x1067c5730*/
        v892 = isCoreCase1Devices(void)::ret; /*0x1067c5d2d*/
        if ( isCoreCase1Devices(void)::ret != 0 ) /*0x1067c5d35*/
        {
LABEL_1158:
          v855 = v892 == 1; /*0x1067c5ea9*/
LABEL_1048:
          RBX::Time::nowFastSec(this: v850); /*0x1067c5738*/
          v1023 = v856; /*0x1067c573d*/
          if ( v855 ) /*0x1067c5747*/
          {
            *(double *)&v1023 = *(double *)&v1023 - *(double *)v998; /*0x1067c5760*/
            std::to_string(a1: (__int64)v1054); /*0x1067c577e*/
            if ( (v1054[0] & 1) != 0 ) /*0x1067c5787*/
              v857 = v1055; /*0x1067c5789*/
            else
              v857 = (RBX::Time *)((char *)v1054 + 1); /*0x1067c578f*/
            RBX::format(this: (RBX *)v1026, a2: "JoinTime_Case1_Attempt_%s", (const char *)v857); /*0x1067c57a3*/
            RBX::Analytics::EphemeralCounter::reportStats(a1: v1026, a2: 0, a3: *(double *)&v1023); /*0x1067c57b9*/
            if ( ((__int64)v1026[0] & 1) != 0 ) /*0x1067c57c5*/
              operator delete(a1: v1027); /*0x1067c57ce*/
            if ( (v1054[0] & 1) != 0 ) /*0x1067c57d7*/
              operator delete(a1: v1055); /*0x1067c57dd*/
          }
          goto LABEL_1056; /*0x1067c57dd*/
        }
        RBX::SystemUtil::deviceName(this: (RBX::SystemUtil *)v1054); /*0x1067c5d3f*/
        v893 = v1054[0] & 1; /*0x1067c5d49*/
        if ( (v1054[0] & 1) != 0 ) /*0x1067c5d4b*/
        {
          if ( v1054[1] != 9 ) /*0x1067c5d5d*/
            goto LABEL_1131; /*0x1067c5d5d*/
          v894 = v1055; /*0x1067c5d5f*/
        }
        else
        {
          if ( LOBYTE(v1054[0]) != 18 ) /*0x1067c5d50*/
            goto LABEL_1131; /*0x1067c5d50*/
          v894 = (RBX::Time *)((char *)v1054 + 1); /*0x1067c5d52*/
        }
        if ( (*(_QWORD *)v894 ^ 0x3520656E6F685069LL | *((unsigned __int8 *)v894 + 8) ^ 0x53LL) == 0 ) /*0x1067c5d7b*/
        {
          isCoreCase1Devices(void)::ret = 1; /*0x1067c5e4b*/
LABEL_1155:
          if ( v893 != 0 ) /*0x1067c5e98*/
            operator delete(a1: v1055); /*0x1067c5e9e*/
          v892 = isCoreCase1Devices(void)::ret; /*0x1067c5ea3*/
          goto LABEL_1158; /*0x1067c5ea3*/
        }
LABEL_1131:
        RBX::SystemUtil::deviceName(this: (RBX::SystemUtil *)v1026); /*0x1067c5d81*/
        v895 = (__int64)v1026[0] & 1; /*0x1067c5d95*/
        if ( ((__int64)v1026[0] & 1) != 0 ) /*0x1067c5d97*/
        {
          if ( v1026[1] != (std::__shared_weak_count *)8 ) /*0x1067c5daf*/
            goto LABEL_1137; /*0x1067c5daf*/
          v896 = v1027; /*0x1067c5db1*/
        }
        else
        {
          if ( LOBYTE(v1026[0]) != 16 ) /*0x1067c5d9c*/
            goto LABEL_1137; /*0x1067c5d9c*/
          v896 = (std::__shared_weak_count **)((char *)v1026 + 1); /*0x1067c5d9e*/
        }
        if ( *v896 == 0x3620656E6F685069LL ) /*0x1067c5dc5*/
        {
          isCoreCase1Devices(void)::ret = 1; /*0x1067c5eb4*/
          goto LABEL_1152; /*0x1067c5ebe*/
        }
LABEL_1137:
        RBX::SystemUtil::deviceName(this: (RBX::SystemUtil *)&__dst); /*0x1067c5dcb*/
        if ( (__dst & 1) != 0 ) /*0x1067c5ddf*/
        {
          if ( *((_QWORD *)&__dst + 1) != 13 ) /*0x1067c5df6*/
          {
            isCoreCase1Devices(void)::ret = -1; /*0x1067c5e63*/
LABEL_1150:
            operator delete(a1: v1025); /*0x1067c5e6d*/
            goto LABEL_1151; /*0x1067c5e74*/
          }
          v897 = (unsigned __int64 *)v1025; /*0x1067c5df8*/
        }
        else
        {
          if ( (_BYTE)__dst != 26 ) /*0x1067c5de3*/
          {
            isCoreCase1Devices(void)::ret = -1; /*0x1067c5e57*/
LABEL_1151:
            v895 = (__int64)v1026[0] & 1; /*0x1067c5e79*/
LABEL_1152:
            if ( v895 != 0 ) /*0x1067c5e83*/
              operator delete(a1: v1027); /*0x1067c5e8c*/
            v893 = v1054[0] & 1; /*0x1067c5e94*/
            goto LABEL_1155; /*0x1067c5e94*/
          }
          v897 = (unsigned __int64 *)((char *)&__dst + 1); /*0x1067c5de5*/
        }
        v898 = 0x6950686F6E652036LL; /*0x1067c5dff*/
        v899 = _byteswap_uint64(*v897); /*0x1067c5e0c*/
        if ( v899 != 0x6950686F6E652036LL
          || (v898 = 0x65203620506C7573LL,
              v899 = _byteswap_uint64(*(unsigned __int64 *)((char *)v897 + 5)),
              v900 = 0,
              v899 != 0x65203620506C7573LL) )
        {
          v900 = v899 < v898 ? -1 : 1;
        }
        isCoreCase1Devices(void)::ret = v900 != 0 ? -1 : 1;
        if ( (__dst & 1) == 0 ) /*0x1067c5e47*/
          goto LABEL_1151; /*0x1067c5e47*/
        goto LABEL_1150; /*0x1067c5e47*/
      }
    }
    else if ( v853 == 4 ) /*0x1067c5709*/
    {
      v854 = v1034 + 329; /*0x1067c5712*/
      goto LABEL_1046; /*0x1067c5718*/
    }
LABEL_1047:
    v855 = false; /*0x1067c5736*/
    goto LABEL_1048; /*0x1067c5736*/
  }
LABEL_1056:
  v858 = *((_QWORD *)v1034 + 3); /*0x1067c57e2*/
  if ( v858 != 0 ) /*0x1067c57f0*/
  {
    v859 = *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::Players>(this: (RBX::ServiceProvider *)(v858 + 464)); /*0x1067c57fe*/
    if ( v859 != 0 ) /*0x1067c5804*/
      *(_DWORD *)(v859 + 872) = *((_DWORD *)v1034 + 226); /*0x1067c5813*/
  }
  if ( *v1015 == 0 ) /*0x1067c5823*/
  {
    v862 = RBX::ServiceProvider::find<RBX::Visit>(this: (RBX::ServiceProvider *)(*((_QWORD *)v1034 + 3) + 464LL)); /*0x1067c583c*/
    if ( v862 != 0 ) /*0x1067c5842*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v960, a2: "", a3: v860, a4: v861); /*0x1067c5852*/
      RBX::Visit::setUploadUrl(a1: v862, a2: v960); /*0x1067c5861*/
      if ( (v960[0] & 1) != 0 ) /*0x1067c586d*/
        operator delete(a1: v961); /*0x1067c5876*/
    }
  }
  v863 = RBX::ServiceProvider::createDangerous_DEPRECATED<RBX::RunService>(this: (RBX::ServiceProvider *)(*((_QWORD *)v1034 + 3) + 464LL)); /*0x1067c588b*/
  RBX::RunServiceProp::setRunState(a1: v863 + 192, a2: 1); /*0x1067c589e*/
  if ( (v1006 & 1) != 0 ) /*0x1067c58aa*/
    operator delete(a1: v1007); /*0x1067c58b3*/
  if ( (v1000 & 1) != 0 ) /*0x1067c58bf*/
    operator delete(a1: v1003); /*0x1067c58c8*/
  if ( v1033 == 1 && ((__int64)v1031[0] & 1) != 0 ) /*0x1067c58dd*/
    operator delete(a1: v1032); /*0x1067c58e6*/
  if ( (v991 & 1) != 0 ) /*0x1067c58f2*/
    operator delete(a1: v992); /*0x1067c58fb*/
  if ( (v975 & 1) != 0 ) /*0x1067c5907*/
    operator delete(a1: v978); /*0x1067c5910*/
  v1031[0] = &v912; /*0x1067c591c*/
  std::vector<RBX::Network::ConnectionInfo>::__destroy_vector::operator()[abi:ne200100](a1: v1031); /*0x1067c5922*/
  v1031[0] = &v910; /*0x1067c5927*/
  std::vector<RBX::Network::ConnectionInfo>::__destroy_vector::operator()[abi:ne200100](a1: v1031); /*0x1067c5931*/
  v864 = v965[1]; /*0x1067c5936*/
  if ( v965[1] != nullptr /*0x1067c5952*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v965[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v864 + 16LL))(a1: v864); /*0x1067c595a*/
    std::__shared_weak_count::__release_weak(this: v864); /*0x1067c5960*/
  }
  if ( ((__int64)v1044[3] & 1) != 0 ) /*0x1067c596c*/
    operator delete(a1: v1044[5]); /*0x1067c5975*/
  if ( ((__int64)v1044[0] & 1) != 0 ) /*0x1067c5981*/
    operator delete(a1: v1044[2]); /*0x1067c598a*/
  if ( v1022 != nullptr ) /*0x1067c5999*/
    (*((void (__fastcall **)(RBX::AppQoSInstance **))*v1022 + 2))(a1: v1022); /*0x1067c599e*/
  if ( (v1004 & 1) != 0 ) /*0x1067c59a8*/
    operator delete(a1: v1005); /*0x1067c59b1*/
  if ( (v1009 & 1) != 0 ) /*0x1067c59bd*/
    operator delete(a1: v1010); /*0x1067c59c6*/
  if ( ((__int64)v1020[0] & 1) != 0 ) /*0x1067c59d2*/
    operator delete(a1: v1021); /*0x1067c59db*/
  std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::~__hash_table(a1: (__int64)v1028); /*0x1067c59e7*/
  if ( v1034[80] == 0 ) /*0x1067c59f7*/
  {
    v866 = *((_QWORD *)v1034 + 206); /*0x1067c5a04*/
    if ( v866 != 0 ) /*0x1067c5a0e*/
      v867 = *(RBX::DataModel **)(v866 + 24); /*0x1067c5a10*/
    else
      v867 = nullptr; /*0x1067c5a16*/
    v868 = *((_QWORD *)v1034 + 3); /*0x1067c5a1f*/
    v143 = (*(_BYTE *)(v868 + 744) & 1) == 0; /*0x1067c5a23*/
    v1022 = (RBX::AppQoSInstance **)v867; /*0x1067c5a2a*/
    if ( v143 ) /*0x1067c5a31*/
    {
      qmemcpy(__len, (const void *)(v868 + 744), sizeof(__len)); /*0x1067c5a3e*/
      v869 = v1034; /*0x1067c5a51*/
    }
    else
    {
      std::string::__init_copy_ctor_external(a1: __len, a2: *(_QWORD *)(v868 + 760), a3: *(_QWORD *)(v868 + 752)); /*0x1067c5a6f*/
      v869 = v1034; /*0x1067c5a74*/
      v868 = *((_QWORD *)v1034 + 3); /*0x1067c5a7b*/
    }
    v870 = *((_QWORD *)v869 + 9); /*0x1067c5a7f*/
    v871 = *(_QWORD *)(v868 + 832); /*0x1067c5a83*/
    v872 = *(_QWORD *)(v868 + 840); /*0x1067c5a8a*/
    v873 = *(_DWORD *)(v868 + 868); /*0x1067c5a91*/
    RBX::DataModel::getPlaySessionId(this: (RBX::DataModel *)v1028); /*0x1067c5aa2*/
    RBX::InferredCrash::onGameStart( /*0x1067c5ac5*/
      a1: (_DWORD)v1022,
      a2: (unsigned int)__len,
      a3: v870,
      a4: v871,
      a5: v872,
      a6: v873,
      a7: (__int64)v1028);
    if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c5ad1*/
      operator delete(a1: v1029[0]); /*0x1067c5ada*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c5ae6*/
      operator delete(a1: (void *)__len[2]); /*0x1067c5aef*/
  }
  v874 = (RBX::EngineStabilityStats *)RBX::EngineStabilityStats::getInstance(this: v865); /*0x1067c5af9*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "UserId", a3: v875, a4: v876); /*0x1067c5b0a*/
  v877 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: __len); /*0x1067c5b1d*/
  RBX::EngineStabilityStats::onUserIdUpdated(this: v874, a2: v877); /*0x1067c5b28*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c5b34*/
    operator delete(a1: (void *)__len[2]); /*0x1067c5b3d*/
  if ( *v1015 == 0 ) /*0x1067c5b4c*/
  {
    RBX::weak_from<RBX::DataModel>(a1: v962, a2: *((_QWORD *)v1034 + 3)); /*0x1067c5b60*/
    std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "UserId", a3: v880, a4: v881); /*0x1067c5b73*/
    v882 = RBX::GameConfigurer::getParamInt64(a1: v1034, a2: __len); /*0x1067c5b86*/
    RBX::GamePerfMonitor::start(a1: v962, a2: v882); /*0x1067c5b95*/
    if ( (__len[0] & 1) != 0 ) /*0x1067c5ba1*/
      operator delete(a1: (void *)__len[2]); /*0x1067c5baa*/
    if ( v963 != nullptr ) /*0x1067c5bb9*/
      std::__shared_weak_count::__release_weak(this: v963); /*0x1067c5bbb*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "SeleniumTest3", a3: v878, a4: v879); /*0x1067c5bce*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "Successfully created player", a3: v883, a4: v884); /*0x1067c5be1*/
  RBX::PlayerConfigurer::ifSeleniumThenSetCookie( /*0x1067c5bfb*/
    a1: (__int64)v1034,
    a2: (__int128 *)__len,
    a3: (__int128 *)v1028,
    a4: v885);
  if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c5c07*/
    operator delete(a1: v1029[0]); /*0x1067c5c10*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c5c1c*/
    operator delete(a1: (void *)__len[2]); /*0x1067c5c25*/
  std::string::basic_string[abi:ne200100]<0>(a1: __len, a2: "SeleniumTest4", a3: v886, a4: v887); /*0x1067c5c38*/
  std::string::basic_string[abi:ne200100]<0>(a1: v1028, a2: "Finished join", a3: v888, a4: v889); /*0x1067c5c4b*/
  RBX::PlayerConfigurer::ifSeleniumThenSetCookie( /*0x1067c5c65*/
    a1: (__int64)v1034,
    a2: (__int128 *)__len,
    a3: (__int128 *)v1028,
    a4: v890);
  if ( ((__int64)v1028[0] & 1) != 0 ) /*0x1067c5c71*/
    operator delete(a1: v1029[0]); /*0x1067c5c7a*/
  if ( (__len[0] & 1) != 0 ) /*0x1067c5c86*/
    operator delete(a1: (void *)__len[2]); /*0x1067c5c8f*/
  if ( (v1011 & 1) != 0 ) /*0x1067c5c9b*/
    operator delete(a1: v1014); /*0x1067c5ca4*/
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v1049); /*0x1067c5cb7*/
  if ( (v966[0] & 1) != 0 ) /*0x1067c5cc3*/
    operator delete(a1: v968); /*0x1067c5ccc*/
  if ( (v971 & 1) != 0 ) /*0x1067c5cd8*/
    operator delete(a1: v974); /*0x1067c5ce1*/
  if ( (v982[0] & 1) != 0 ) /*0x1067c5ced*/
    operator delete(a1: v984); /*0x1067c5cf6*/
  RBX::Security::Impersonator::~Impersonator(this: (RBX::Security::Impersonator *)v905); /*0x1067c5d02*/
  return __stack_chk_guard; /*0x1067c5d1b*/
}

// Address: 0x1067c79e6 | Name: __ZN3RBX16PlayerConfigurer29reportLocalJoinFailureMetricsENSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEd
void __fastcall RBX::PlayerConfigurer::reportLocalJoinFailureMetrics(__int64 a1, __int128 *a2, double a3)
{
  _BYTE v5[40]; // [rsp+8h] [rbp-1E8h] BYREF
  void *v6; // [rsp+30h] [rbp-1C0h]
  char v7; // [rsp+38h] [rbp-1B8h]
  void *v8; // [rsp+48h] [rbp-1A8h]
  char v9; // [rsp+50h] [rbp-1A0h]
  void *v10; // [rsp+60h] [rbp-190h]
  char v11; // [rsp+160h] [rbp-90h] BYREF
  char v12; // [rsp+178h] [rbp-78h] BYREF
  char *v13; // [rsp+198h] [rbp-58h] BYREF
  __int128 v14; // [rsp+1A0h] [rbp-50h] BYREF
  void *v15; // [rsp+1B0h] [rbp-40h]
  __int128 v16; // [rsp+1C0h] [rbp-30h] BYREF
  void *v17; // [rsp+1D0h] [rbp-20h]
  double v18; // [rsp+1D8h] [rbp-18h]

  v18 = a3; /*0x1067c79f4*/
  __bzero(a1: v5, a2: 395); /*0x1067c7a0b*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1067c7a14*/
  {
    std::string::__init_copy_ctor_external(a1: &v14, a2: *((_QWORD *)a2 + 2), a3: *((_QWORD *)a2 + 1)); /*0x1067c7a34*/
  }
  else
  {
    v15 = *((void **)a2 + 2); /*0x1067c7a1a*/
    v14 = *a2; /*0x1067c7a22*/
  }
  RBX::PlayerConfigurer::reportLocalAvatarMetrics(a1, a2: v5, a3: &v14, a4: v18); /*0x1067c7a4c*/
  if ( (v14 & 1) != 0 ) /*0x1067c7a55*/
    operator delete(a1: v15); /*0x1067c7a5b*/
  if ( (*(_BYTE *)a2 & 1) != 0 ) /*0x1067c7a64*/
  {
    std::string::__init_copy_ctor_external(a1: &v16, a2: *((_QWORD *)a2 + 2), a3: *((_QWORD *)a2 + 1)); /*0x1067c7a84*/
  }
  else
  {
    v17 = *((void **)a2 + 2); /*0x1067c7a6a*/
    v16 = *a2; /*0x1067c7a72*/
  }
  RBX::AvatarLoadMetrics::reportFailedMetrics_DEPRECATED(a1: a1 + 480, a2: a1 + 168, a3: &v16, a4: v18); /*0x1067c7aa3*/
  if ( (v16 & 1) != 0 ) /*0x1067c7aac*/
    operator delete(a1: v17); /*0x1067c7ab2*/
  v13 = &v12; /*0x1067c7abf*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: &v13); /*0x1067c7ac5*/
  v13 = &v11; /*0x1067c7ad1*/
  std::vector<RBX::AvatarAssetMetrics>::__destroy_vector::operator()[abi:ne200100](a1: &v13); /*0x1067c7ad8*/
  if ( (v9 & 1) != 0 ) /*0x1067c7ae5*/
    operator delete(a1: v10); /*0x1067c7aee*/
  if ( (v7 & 1) != 0 ) /*0x1067c7afa*/
    operator delete(a1: v8); /*0x1067c7b03*/
  if ( (v5[24] & 1) != 0 ) /*0x1067c7b0f*/
    operator delete(a1: v6); /*0x1067c7b18*/
}

// Address: 0x1067c7b64 | Name: __ZNK3RBX16PlayerConfigurer31getShouldSetGlobalTelemetryInfoEv
char __fastcall RBX::PlayerConfigurer::getShouldSetGlobalTelemetryInfo(RBX::PlayerConfigurer *this)
{
  return *((_BYTE *)this + 81) /* +81: NO 2022 FIELD */; /*0x1067c7b6b*/
}

// Address: 0x1067c7d46 | Name: __ZN3RBX16PlayerConfigurer12onShowOomBoxEv
__int64 __fastcall RBX::PlayerConfigurer::onShowOomBox(RBX::PlayerConfigurer *this, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v5; // rax
  __int64 v6; // rdi
  __int64 v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // rdx
  __int64 v12; // rcx
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // rbx
  _QWORD *v16; // r14
  __int64 v17; // rdi
  __int128 v18; // xmm0
  __int64 v19; // rax
  _BYTE v21[16]; // [rsp+0h] [rbp-D0h] BYREF
  void *v22; // [rsp+10h] [rbp-C0h]
  _BYTE v23[16]; // [rsp+18h] [rbp-B8h] BYREF
  void *v24; // [rsp+28h] [rbp-A8h]
  __int128 v25; // [rsp+30h] [rbp-A0h] BYREF
  void *v26; // [rsp+40h] [rbp-90h]
  char v27[16]; // [rsp+48h] [rbp-88h] BYREF
  void *v28; // [rsp+58h] [rbp-78h]
  std::__shared_weak_count *v29[2]; // [rsp+60h] [rbp-70h] BYREF
  void *v30; // [rsp+70h] [rbp-60h]
  _QWORD v31[4]; // [rsp+80h] [rbp-50h] BYREF
  _QWORD *v32; // [rsp+A0h] [rbp-30h]

  v25 = 0; /*0x1067c7d6a*/
  v26 = nullptr; /*0x1067c7d71*/
  std::string::basic_string[abi:ne200100]<0>( /*0x1067c7d8a*/
    a1: v21,
    a2: "InGame.ConnectionError.DisconnectOutOfMemoryKeepPlayingLeave",
    a3,
    a4);
  v5 = *((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */; /*0x1067c7d8f*/
  v6 = v5 + 464; /*0x1067c7d93*/
  if ( v5 == 0 ) /*0x1067c7d9d*/
    v6 = 0; /*0x1067c7d9d*/
  if ( (unsigned __int8)RBX::LocalizationService::CorescriptLocalizationGetKey(a1: v6, a2: v21, a3: &v25) != 0 ) /*0x1067c7db6*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v29, a2: "Disconnect", a3: v7, a4: v8); /*0x1067c7dc3*/
    std::string::basic_string[abi:ne200100]<0>(a1: v27, a2: "Memory", a3: v9, a4: v10); /*0x1067c7dd6*/
    RBX::PlayerConfigurer::showErrorWindow(a1: (__int64)this, a2: &v25, a3: (char *)v29, a4: (__int64)v27, a5: 292); /*0x1067c7df6*/
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>( /*0x1067c7e08*/
      a1: v29,
      a2: "Your device’s memory is low. Leaving now will preserve your state and prevent Roblox from crashing.",
      a3: v7,
      a4: v8);
    std::string::basic_string[abi:ne200100]<0>(a1: v27, a2: "Disconnect", a3: v11, a4: v12); /*0x1067c7e1b*/
    std::string::basic_string[abi:ne200100]<0>(a1: v23, a2: "Memory", a3: v13, a4: v14); /*0x1067c7e2e*/
    RBX::PlayerConfigurer::showErrorWindow(a1: (__int64)this, a2: (__int128 *)v29, a3: v27, a4: (__int64)v23, a5: 292); /*0x1067c7e4e*/
    if ( (v23[0] & 1) != 0 ) /*0x1067c7e5a*/
      operator delete(a1: v24); /*0x1067c7e63*/
  }
  if ( (v27[0] & 1) != 0 ) /*0x1067c7e6f*/
    operator delete(a1: v28); /*0x1067c7e75*/
  if ( ((__int64)v29[0] & 1) != 0 ) /*0x1067c7e7e*/
    operator delete(a1: v30); /*0x1067c7e84*/
  v15 = RBX::ServiceProvider::create<RBX::GuiService>(a1: *((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 464LL, a2: 0); /*0x1067c7e99*/
  if ( v15 != 0 ) /*0x1067c7e9f*/
  {
    v16 = (_QWORD *)RBX::Subsystem<RBX::PerformanceControl::OomBoxSubsystem,false>::startup<RBX::SubsystemDefaultFactory<RBX::PerformanceControl::OomBoxSubsystem>>(); /*0x1067c7eaa*/
    RBX::weak_from<RBX::GuiService>(a1: v29, a2: v15); /*0x1067c7eb4*/
    if ( v16 != nullptr ) /*0x1067c7ebc*/
      v17 = v16[3]; /*0x1067c7ebe*/
    else
      v17 = 0; /*0x1067c7ec4*/
    v18 = *(_OWORD *)v29; /*0x1067c7ec6*/
    *(_OWORD *)v29 = 0; /*0x1067c7ecd*/
    v31[0] = &off_10CAAC570; /*0x1067c7edc*/
    *(_OWORD *)&v31[1] = v18; /*0x1067c7edf*/
    v32 = v31; /*0x1067c7ee4*/
    RBX::PerformanceControl::OomBoxSubsystem::setPlayerContinuedTestFunction(a1: v17, a2: v31); /*0x1067c7eeb*/
    if ( v32 == v31 ) /*0x1067c7ef7*/
    {
      v19 = 32; /*0x1067c7f05*/
    }
    else
    {
      v19 = 40; /*0x1067c7ef9*/
      if ( v32 == nullptr ) /*0x1067c7f01*/
        goto LABEL_20; /*0x1067c7f01*/
    }
    (*(void (**)(void))(*v32 + v19))(); /*0x1067c7f0d*/
LABEL_20:
    if ( v29[1] != nullptr ) /*0x1067c7f17*/
      std::__shared_weak_count::__release_weak(this: v29[1]); /*0x1067c7f19*/
    if ( v16 != nullptr ) /*0x1067c7f21*/
      (*(void (__fastcall **)(_QWORD *))(*v16 + 16LL))(a1: v16); /*0x1067c7f29*/
  }
  if ( (v21[0] & 1) != 0 ) /*0x1067c7f33*/
    operator delete(a1: v22); /*0x1067c7f3c*/
  if ( (v25 & 1) != 0 ) /*0x1067c7f48*/
    operator delete(a1: v26); /*0x1067c7f51*/
  return __stack_chk_guard; /*0x1067c7f66*/
}

// Address: 0x1067c8104 | Name: __ZN3RBX16PlayerConfigurer22connectPlayerToSignalsENSt3__110shared_ptrINS_6PlayerEEE
__int64 __fastcall RBX::PlayerConfigurer::connectPlayerToSignals(__int64 a1, RBX::Player **a2)
{
  unsigned int v4; // eax
  unsigned __int64 v5; // rax
  __int64 *v6; // r15
  __int64 v7; // rdx
  __int64 v8; // rcx
  unsigned __int8 *v9; // r15
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // rdi
  __int64 v13; // rsi
  RBX::Player *v14; // rdi
  std::__shared_weak_count *v15; // r15
  std::__shared_weak_count *v16; // r15
  std::__shared_weak_count *v17; // r15
  RBX::Player *v18; // r15
  void *v19; // rdi
  RBX::Time *v20; // rdi
  double v21; // xmm0_8
  __int64 v22; // rdx
  __int64 v23; // rcx
  __int64 v24; // rdx
  __int64 v25; // rcx
  __int64 ParamInt64; // r15
  __int64 v27; // rdx
  __int64 v28; // rcx
  __int64 v29; // rax
  __int64 v30; // r15
  __int128 v31; // xmm0
  __int64 v32; // rax
  __int64 v33; // r15
  void *v34; // rdi
  RBX::Player *v35; // r13
  RBX::Player *v36; // rax
  unsigned int v37; // esi
  unsigned int v38; // r12d
  rbx::signals::slots_holder **v39; // r13
  unsigned __int64 v40; // rsi
  unsigned __int64 v41; // r15
  rbx::signals::slots_holder *v42; // rax
  __int64 v43; // rax
  rbx::signals::slots_holder *v44; // rdi
  unsigned int v45; // esi
  void *v46; // rdi
  __int64 v47; // rdi
  RBX::Player *v48; // rax
  std::__shared_weak_count *v49; // r15
  std::__shared_weak_count *v50; // rdi
  RBX::Player *v51; // r13
  RBX::Player *v52; // rax
  unsigned int v53; // esi
  unsigned int v54; // r12d
  rbx::signals::slots_holder **v55; // r13
  unsigned __int64 v56; // rsi
  unsigned __int64 v57; // r15
  rbx::signals::slots_holder *v58; // rax
  __int64 v59; // rax
  rbx::signals::slots_holder *v60; // rdi
  unsigned int v61; // esi
  void *v62; // rdi
  rbx::signals::slots_holder **v63; // r12
  unsigned int v64; // esi
  unsigned int v65; // r15d
  unsigned __int64 v66; // rsi
  unsigned __int64 v67; // r13
  rbx::signals::slots_holder *v68; // rax
  __int64 v69; // rax
  rbx::signals::slots_holder *v70; // rdi
  unsigned int v71; // esi
  void *v72; // rdi
  rbx::signals::slots_holder **v73; // r12
  unsigned int v74; // esi
  RBX::Player *v75; // rax
  unsigned int v76; // r15d
  unsigned __int64 v77; // rsi
  unsigned __int64 v78; // r13
  rbx::signals::slots_holder *v79; // rcx
  __int64 v80; // rcx
  rbx::signals::slots_holder *v81; // rdi
  unsigned int v82; // esi
  __int64 v83; // rdx
  __int64 v84; // rcx
  void *v85; // rdi
  RBX::Player *v86; // r14
  char ParamBool; // al
  __int128 v89; // [rsp+0h] [rbp-F0h] BYREF
  _BYTE v90[16]; // [rsp+18h] [rbp-D8h] BYREF
  void *v91; // [rsp+28h] [rbp-C8h]
  std::__shared_weak_count *v92[2]; // [rsp+30h] [rbp-C0h] BYREF
  void *v93; // [rsp+40h] [rbp-B0h]
  _DWORD v94[5]; // [rsp+4Ch] [rbp-A4h] BYREF
  void *v95; // [rsp+60h] [rbp-90h]
  std::__shared_weak_count *v96[2]; // [rsp+70h] [rbp-80h] BYREF
  std::__shared_weak_count *v97[2]; // [rsp+80h] [rbp-70h]
  _QWORD v98[4]; // [rsp+90h] [rbp-60h] BYREF
  _QWORD *v99; // [rsp+B0h] [rbp-40h]

  if ( DFFlag::ClientLaunchDataInJoinData == 1 ) /*0x1067c8136*/
  {
    v4 = *(unsigned __int8 *)(a1 + 136); /*0x1067c813c*/
    if ( (v4 & 1) != 0 ) /*0x1067c8145*/
    {
      v5 = *(_QWORD *)(a1 + 144); /*0x1067c8154*/
      if ( v5 == 0 ) /*0x1067c815e*/
        goto LABEL_20; /*0x1067c815e*/
    }
    else
    {
      if ( *(_BYTE *)(a1 + 136) == 0 ) /*0x1067c814a*/
        goto LABEL_20; /*0x1067c814a*/
      v5 = v4 >> 1; /*0x1067c8150*/
    }
    if ( v5 <= FInt::LaunchDataLength ) /*0x1067c8171*/
    {
      RBX::make_shared<RBX::Reflection::ValueTable>(a1: (RSL::Arena *)&v94[1]); /*0x1067c817e*/
      v6 = *(__int64 **)&v94[1]; /*0x1067c8183*/
      std::string::basic_string[abi:ne200100]<0>(a1: v96, a2: "LaunchData", a3: v7, a4: v8); /*0x1067c8198*/
      v92[0] = (std::__shared_weak_count *)v96; /*0x1067c81a4*/
      v9 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x1067c81c0*/
             a1: v6,
             a2: (unsigned __int8 *)v96,
             a3: (__int64)std::piecewise_construct,
             a4: (__int64)v92,
             a5: (__int64)v90);
      *((_QWORD *)v9 + 5) = RBX::Reflection::Type::getSingleton<std::string>(a1: v12, a2: v13, a3: v10, a4: v11); /*0x1067c81cf*/
      RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<std::string>(a1: (__int64 **)v9 + 6, a2: a1 + 136); /*0x1067c81da*/
      if ( ((__int64)v96[0] & 1) != 0 ) /*0x1067c81e3*/
        operator delete(a1: v97[0]); /*0x1067c81e9*/
      v14 = *a2; /*0x1067c81ee*/
      *(_OWORD *)v96 = 0; /*0x1067c81f4*/
      *(_OWORD *)v92 = *(_OWORD *)&v94[1]; /*0x1067c8207*/
      if ( *(_QWORD *)&v94[3] != 0 ) /*0x1067c8212*/
        _InterlockedIncrement64((volatile signed __int64 *)(*(_QWORD *)&v94[3] + 8LL)); /*0x1067c8214*/
      RBX::Player::setJoinData(a1: v14, a2: v96, a3: v92); /*0x1067c8224*/
      v15 = v92[1]; /*0x1067c8229*/
      if ( v92[1] != nullptr /*0x1067c8245*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v92[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(a1: v15); /*0x1067c824d*/
        std::__shared_weak_count::__release_weak(this: v15); /*0x1067c8253*/
      }
      v16 = v96[1]; /*0x1067c8258*/
      if ( v96[1] != nullptr /*0x1067c8271*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)v96[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x1067c8279*/
        std::__shared_weak_count::__release_weak(this: v16); /*0x1067c827f*/
      }
      v17 = *(std::__shared_weak_count **)&v94[3]; /*0x1067c8284*/
      if ( *(_QWORD *)&v94[3] != 0 /*0x1067c82a0*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v94[3] + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v17 + 16LL))(a1: v17); /*0x1067c82a8*/
        std::__shared_weak_count::__release_weak(this: v17); /*0x1067c82ae*/
      }
    }
  }
LABEL_20:
  v18 = *a2; /*0x1067c82b3*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: v96, a2: a1); /*0x1067c82bd*/
  v97[0] = (std::__shared_weak_count *)RBX::PlayerConfigurer::onPlayerChanged; /*0x1067c82d1*/
  v97[1] = nullptr; /*0x1067c82d5*/
  _ZN3rbx6signalIFvPKN3RBX10Reflection18PropertyDescriptorEEE7connectIZNS1_16PlayerConfigurer11with_lockedIMS9_FvS5_EEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSE_( /*0x1067c82e7*/
    a1: &v94[1],
    a2: (char *)v18 + 72);
  rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(a1 + 1656)); /*0x1067c82fa*/
  v19 = *(void **)&v94[1]; /*0x1067c82ff*/
  if ( *(_QWORD *)&v94[1] != 0 && _InterlockedDecrement((volatile signed __int32 *)(*(_QWORD *)&v94[1] + 4LL)) == 0 ) /*0x1067c830f*/
    rbx::signals::slot_base::operator delete(a1: v19); /*0x1067c8311*/
  v20 = v96[1]; /*0x1067c8316*/
  if ( v96[1] != nullptr ) /*0x1067c831d*/
    std::__shared_weak_count::__release_weak(this: v96[1]); /*0x1067c831f*/
  RBX::Time::nowFastSec(this: v20); /*0x1067c8324*/
  *(double *)(a1 + 264) = v21 - *(double *)(a1 + 168); /*0x1067c8331*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v94[1], a2: "CookieStoreFirstTimePlayKey", a3: v22, a4: v23); /*0x1067c8347*/
  RBX::GameConfigurer::getParamString(a1: v96, a2: a1, a3: &v94[1]); /*0x1067c835a*/
  std::string::basic_string[abi:ne200100]<0>(a1: v92, a2: "UserId", a3: v24, a4: v25); /*0x1067c836d*/
  ParamInt64 = RBX::GameConfigurer::getParamInt64(a1, a2: v92); /*0x1067c8381*/
  std::string::basic_string[abi:ne200100]<0>(a1: v90, a2: "PlaceId", a3: v27, a4: v28); /*0x1067c8392*/
  v29 = RBX::GameConfigurer::getParamInt64(a1, a2: v90); /*0x1067c83a1*/
  RBX::GameConfigurer::registerPlay(a1, a2: v96, a3: ParamInt64, a4: v29); /*0x1067c83b3*/
  if ( (v90[0] & 1) != 0 ) /*0x1067c83bf*/
    operator delete(a1: v91); /*0x1067c83c8*/
  if ( ((__int64)v92[0] & 1) != 0 ) /*0x1067c83d4*/
    operator delete(a1: v93); /*0x1067c83dd*/
  if ( ((__int64)v96[0] & 1) != 0 ) /*0x1067c83e6*/
    operator delete(a1: v97[0]); /*0x1067c83ec*/
  if ( (v94[1] & 1) != 0 ) /*0x1067c83f8*/
    operator delete(a1: v95); /*0x1067c8401*/
  v30 = RBX::ServiceProvider::create<RBX::TimerService>(a1: *(_QWORD *)(a1 + 24) + 464LL, a2: 0); /*0x1067c8416*/
  if ( v30 != 0 ) /*0x1067c841c*/
  {
    RBX::weak_from<RBX::PlayerConfigurer>(a1: v96, a2: a1); /*0x1067c8425*/
    v31 = *(_OWORD *)v96; /*0x1067c842a*/
    if ( v96[1] != nullptr ) /*0x1067c8435*/
      _InterlockedIncrement64((volatile signed __int64 *)v96[1] + 2); /*0x1067c8437*/
    v98[0] = &off_10CAAC4F0; /*0x1067c8447*/
    *(_OWORD *)&v98[1] = v31; /*0x1067c844b*/
    v99 = v98; /*0x1067c8451*/
    RBX::TimerService::delay(a1: v30, a2: v98, a3: 300.0); /*0x1067c8464*/
    if ( v99 == v98 ) /*0x1067c8470*/
    {
      v32 = 32; /*0x1067c847e*/
    }
    else
    {
      v32 = 40; /*0x1067c8472*/
      if ( v99 == nullptr ) /*0x1067c847a*/
      {
LABEL_41:
        if ( v96[1] != nullptr ) /*0x1067c8490*/
          std::__shared_weak_count::__release_weak(this: v96[1]); /*0x1067c8492*/
        goto LABEL_43; /*0x1067c8492*/
      }
    }
    (*(void (**)(void))(*v99 + v32))(); /*0x1067c8486*/
    goto LABEL_41; /*0x1067c8486*/
  }
LABEL_43:
  v33 = (__int64)*a2 + 2632; /*0x1067c8497*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: v96, a2: a1); /*0x1067c84a7*/
  v97[0] = (std::__shared_weak_count *)RBX::PlayerConfigurer::onPlayerIdled; /*0x1067c84b7*/
  v97[1] = nullptr; /*0x1067c84bb*/
  _ZN3rbx6signalIFvdEE7connectIZN3RBX16PlayerConfigurer11with_lockedIMS5_FvdEEEDaT_EUlDpOT_E_EENS_7signals10connectionEOSA_( /*0x1067c84cd*/
    a1: &v94[1],
    a2: v33);
  rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(a1 + 1664)); /*0x1067c84e0*/
  v34 = *(void **)&v94[1]; /*0x1067c84e5*/
  if ( *(_QWORD *)&v94[1] != 0 && _InterlockedDecrement((volatile signed __int32 *)(*(_QWORD *)&v94[1] + 4LL)) == 0 ) /*0x1067c84f5*/
    rbx::signals::slot_base::operator delete(a1: v34); /*0x1067c84f7*/
  if ( v96[1] != nullptr ) /*0x1067c8503*/
    std::__shared_weak_count::__release_weak(this: v96[1]); /*0x1067c8505*/
  if ( (~*(_BYTE *)(*(_QWORD *)(a1 + 24) + 2256LL) & 0x3D) == 0 ) /*0x1067c8518*/
  {
    v35 = *a2; /*0x1067c851e*/
    RBX::weak_from<RBX::PlayerConfigurer>(a1: v96, a2: a1); /*0x1067c8528*/
    v36 = a2[1]; /*0x1067c852d*/
    *(_OWORD *)v97 = *(_OWORD *)a2; /*0x1067c8536*/
    if ( v36 != nullptr ) /*0x1067c853e*/
      _InterlockedIncrement64((volatile signed __int64 *)v36 + 2); /*0x1067c8540*/
    rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::Player *)((char *)v35 + 2592)); /*0x1067c854c*/
    v94[0] = (_DWORD)RBX::Memory::InstanceSignal; /*0x1067c855a*/
    v38 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v37); /*0x1067c8565*/
    v39 = (rbx::signals::slots_holder **)((char *)v35 + 2584); /*0x1067c8568*/
    rbx::lazyInitSlotsHolder(a1: v39); /*0x1067c8572*/
    v41 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x50, a2: v40); /*0x1067c8581*/
    *(_QWORD *)v41 = &_mh_execute_header; /*0x1067c858e*/
    *(_QWORD *)(v41 + 8) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::connectPlayerToSignals(std::shared_ptr<RBX::Player>)::$_1,std::shared_ptr<RBX::ModelInstance>>::do_call; /*0x1067c8598*/
    *(_OWORD *)(v41 + 16) = 0; /*0x1067c85a0*/
    v42 = *v39; /*0x1067c85a6*/
    *(_QWORD *)(v41 + 32) = *v39; /*0x1067c85aa*/
    if ( v42 != nullptr ) /*0x1067c85b1*/
    {
      _InterlockedIncrement((volatile signed __int32 *)v42 + 1); /*0x1067c85b3*/
      v43 = *(_QWORD *)(v41 + 24) | 4LL; /*0x1067c85bb*/
      v44 = *v39; /*0x1067c85bf*/
    }
    else
    {
      v43 = 4; /*0x1067c85c5*/
      v44 = nullptr; /*0x1067c85ca*/
    }
    *(_QWORD *)(v41 + 24) = v43; /*0x1067c85cc*/
    *(_QWORD *)(v41 + 40) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::connectPlayerToSignals(std::shared_ptr<RBX::Player>)::$_1,std::shared_ptr<RBX::ModelInstance>>::do_dtor; /*0x1067c85d7*/
    *(_OWORD *)(v41 + 48) = *(_OWORD *)v96; /*0x1067c85df*/
    *(_OWORD *)v96 = 0; /*0x1067c85e4*/
    *(_OWORD *)(v41 + 64) = *(_OWORD *)v97; /*0x1067c85ed*/
    *(_OWORD *)v97 = 0; /*0x1067c85f6*/
    rbx::signals::slots_holder::insert(this: v44, a2: v41); /*0x1067c85fd*/
    *(_QWORD *)&v94[1] = v41; /*0x1067c8602*/
    _InterlockedIncrement((volatile signed __int32 *)(v41 + 4)); /*0x1067c8609*/
    RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v38, a2: v45); /*0x1067c8611*/
    rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(a1 + 1712)); /*0x1067c8624*/
    v46 = *(void **)&v94[1]; /*0x1067c8629*/
    if ( *(_QWORD *)&v94[1] != 0 && _InterlockedDecrement((volatile signed __int32 *)(*(_QWORD *)&v94[1] + 4LL)) == 0 ) /*0x1067c8639*/
      rbx::signals::slot_base::operator delete(a1: v46); /*0x1067c863b*/
    if ( v97[1] != nullptr ) /*0x1067c8647*/
      std::__shared_weak_count::__release_weak(this: v97[1]); /*0x1067c8649*/
    if ( v96[1] != nullptr ) /*0x1067c8655*/
      std::__shared_weak_count::__release_weak(this: v96[1]); /*0x1067c8657*/
    if ( FFlag::MigrateAvatarMetricsFromPlayerConfigurer == 1 ) /*0x1067c8663*/
    {
      v47 = *(_QWORD *)(a1 + 896); /*0x1067c8665*/
      v48 = a2[1]; /*0x1067c866c*/
      v89 = *(_OWORD *)a2; /*0x1067c8675*/
      if ( v48 != nullptr ) /*0x1067c8680*/
        _InterlockedIncrement64((volatile signed __int64 *)v48 + 1); /*0x1067c8682*/
      RBX::AvatarLoadMetrics::initPlayerConnections(a1: v47, a2: &v89); /*0x1067c868e*/
      v49 = *((std::__shared_weak_count **)&v89 + 1); /*0x1067c8693*/
      if ( *((_QWORD *)&v89 + 1) != 0 /*0x1067c86b3*/
        && _InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v89 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) == 0 )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v49 + 16LL))(a1: v49); /*0x1067c86bf*/
        v50 = v49; /*0x1067c86c2*/
LABEL_86:
        std::__shared_weak_count::__release_weak(this: v50); /*0x1067c88ec*/
      }
    }
    else
    {
      v51 = *a2; /*0x1067c86ca*/
      RBX::weak_from<RBX::PlayerConfigurer>(a1: v96, a2: a1); /*0x1067c86d4*/
      v52 = a2[1]; /*0x1067c86d9*/
      *(_OWORD *)v97 = *(_OWORD *)a2; /*0x1067c86e2*/
      if ( v52 != nullptr ) /*0x1067c86ea*/
        _InterlockedIncrement64((volatile signed __int64 *)v52 + 2); /*0x1067c86ec*/
      rbx::signal<void ()(void)>::invokeImpl<(rbx::SignalInvokePolicy)0>(a1: (RBX::Player *)((char *)v51 + 440)); /*0x1067c86f8*/
      v54 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v94[0], a2: v53); /*0x1067c8708*/
      v55 = (rbx::signals::slots_holder **)((char *)v51 + 432); /*0x1067c870b*/
      rbx::lazyInitSlotsHolder(a1: v55); /*0x1067c8715*/
      v57 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x50, a2: v56); /*0x1067c8724*/
      *(_QWORD *)v57 = &_mh_execute_header; /*0x1067c8731*/
      *(_QWORD *)(v57 + 8) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::connectPlayerToSignals(std::shared_ptr<RBX::Player>)::$_2,std::shared_ptr<RBX::Reflection::ValueTable const>>::do_call; /*0x1067c873b*/
      *(_OWORD *)(v57 + 16) = 0; /*0x1067c8743*/
      v58 = *v55; /*0x1067c8749*/
      *(_QWORD *)(v57 + 32) = *v55; /*0x1067c874d*/
      if ( v58 != nullptr ) /*0x1067c8754*/
      {
        _InterlockedIncrement((volatile signed __int32 *)v58 + 1); /*0x1067c8756*/
        v59 = *(_QWORD *)(v57 + 24) | 4LL; /*0x1067c875e*/
        v60 = *v55; /*0x1067c8762*/
      }
      else
      {
        v59 = 4; /*0x1067c8768*/
        v60 = nullptr; /*0x1067c876d*/
      }
      *(_QWORD *)(v57 + 24) = v59; /*0x1067c876f*/
      *(_QWORD *)(v57 + 40) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::connectPlayerToSignals(std::shared_ptr<RBX::Player>)::$_2,std::shared_ptr<RBX::Reflection::ValueTable const>>::do_dtor; /*0x1067c877a*/
      *(_OWORD *)(v57 + 48) = *(_OWORD *)v96; /*0x1067c8782*/
      *(_OWORD *)v96 = 0; /*0x1067c8787*/
      *(_OWORD *)(v57 + 64) = *(_OWORD *)v97; /*0x1067c8790*/
      *(_OWORD *)v97 = 0; /*0x1067c8799*/
      rbx::signals::slots_holder::insert(this: v60, a2: v57); /*0x1067c87a0*/
      *(_QWORD *)&v94[1] = v57; /*0x1067c87a5*/
      _InterlockedIncrement((volatile signed __int32 *)(v57 + 4)); /*0x1067c87ac*/
      RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v54, a2: v61); /*0x1067c87b4*/
      rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(a1 + 1728)); /*0x1067c87c7*/
      v62 = *(void **)&v94[1]; /*0x1067c87cc*/
      if ( *(_QWORD *)&v94[1] != 0 && _InterlockedDecrement((volatile signed __int32 *)(*(_QWORD *)&v94[1] + 4LL)) == 0 ) /*0x1067c87dc*/
        rbx::signals::slot_base::operator delete(a1: v62); /*0x1067c87de*/
      if ( v97[1] != nullptr ) /*0x1067c87ea*/
        std::__shared_weak_count::__release_weak(this: v97[1]); /*0x1067c87ec*/
      if ( v96[1] != nullptr ) /*0x1067c87f8*/
        std::__shared_weak_count::__release_weak(this: v96[1]); /*0x1067c87fa*/
      v63 = (rbx::signals::slots_holder **)((char *)*a2 + 2664); /*0x1067c8805*/
      RBX::weak_from<RBX::PlayerConfigurer>(a1: v96, a2: a1); /*0x1067c880f*/
      v65 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v94[0], a2: v64); /*0x1067c881f*/
      rbx::lazyInitSlotsHolder(a1: v63); /*0x1067c8825*/
      v67 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x40, a2: v66); /*0x1067c8834*/
      *(_QWORD *)v67 = &_mh_execute_header; /*0x1067c8841*/
      *(_QWORD *)(v67 + 8) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::connectPlayerToSignals(std::shared_ptr<RBX::Player>)::$_3,double>::do_call; /*0x1067c884c*/
      *(_OWORD *)(v67 + 16) = 0; /*0x1067c8854*/
      v68 = *v63; /*0x1067c885a*/
      *(_QWORD *)(v67 + 32) = *v63; /*0x1067c885e*/
      if ( v68 != nullptr ) /*0x1067c8865*/
      {
        _InterlockedIncrement((volatile signed __int32 *)v68 + 1); /*0x1067c8867*/
        v69 = *(_QWORD *)(v67 + 24) | 4LL; /*0x1067c886f*/
        v70 = *v63; /*0x1067c8873*/
      }
      else
      {
        v69 = 4; /*0x1067c8879*/
        v70 = nullptr; /*0x1067c887e*/
      }
      *(_QWORD *)(v67 + 24) = v69; /*0x1067c8880*/
      *(_QWORD *)(v67 + 40) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::connectPlayerToSignals(std::shared_ptr<RBX::Player>)::$_3,double>::do_dtor; /*0x1067c888b*/
      *(_OWORD *)(v67 + 48) = *(_OWORD *)v96; /*0x1067c8893*/
      *(_OWORD *)v96 = 0; /*0x1067c8898*/
      rbx::signals::slots_holder::insert(this: v70, a2: v67); /*0x1067c88a0*/
      *(_QWORD *)&v94[1] = v67; /*0x1067c88a5*/
      _InterlockedIncrement((volatile signed __int32 *)(v67 + 4)); /*0x1067c88ac*/
      RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v65, a2: v71); /*0x1067c88b4*/
      rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(a1 + 1744)); /*0x1067c88c7*/
      v72 = *(void **)&v94[1]; /*0x1067c88cc*/
      if ( *(_QWORD *)&v94[1] != 0 && _InterlockedDecrement((volatile signed __int32 *)(*(_QWORD *)&v94[1] + 4LL)) == 0 ) /*0x1067c88dc*/
        rbx::signals::slot_base::operator delete(a1: v72); /*0x1067c88de*/
      v50 = v96[1]; /*0x1067c88e3*/
      if ( v96[1] != nullptr ) /*0x1067c88ea*/
        goto LABEL_86; /*0x1067c88ea*/
    }
  }
  v73 = (rbx::signals::slots_holder **)((char *)*a2 + 2656); /*0x1067c88f1*/
  RBX::weak_from<RBX::PlayerConfigurer>(a1: v96, a2: a1); /*0x1067c8901*/
  v75 = a2[1]; /*0x1067c8906*/
  *(_OWORD *)v97 = *(_OWORD *)a2; /*0x1067c890f*/
  if ( v75 != nullptr ) /*0x1067c8917*/
    _InterlockedIncrement64((volatile signed __int64 *)v75 + 2); /*0x1067c8919*/
  v76 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v74); /*0x1067c892c*/
  rbx::lazyInitSlotsHolder(a1: v73); /*0x1067c8932*/
  v78 = rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x50, a2: v77); /*0x1067c8941*/
  *(_QWORD *)v78 = &_mh_execute_header; /*0x1067c8952*/
  *(_QWORD *)(v78 + 8) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::connectPlayerToSignals(std::shared_ptr<RBX::Player>)::$_4>::do_call; /*0x1067c895d*/
  *(_OWORD *)(v78 + 16) = 0; /*0x1067c8965*/
  v79 = *v73; /*0x1067c896b*/
  *(_QWORD *)(v78 + 32) = *v73; /*0x1067c896f*/
  if ( v79 != nullptr ) /*0x1067c8976*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v79 + 1); /*0x1067c8978*/
    v80 = *(_QWORD *)(v78 + 24) | 4LL; /*0x1067c8980*/
    v81 = *v73; /*0x1067c8984*/
  }
  else
  {
    v80 = 4; /*0x1067c898a*/
    v81 = nullptr; /*0x1067c898f*/
  }
  *(_QWORD *)(v78 + 24) = v80; /*0x1067c8991*/
  *(_QWORD *)(v78 + 40) = rbx::signals::slot_with_functor<RBX::PlayerConfigurer::connectPlayerToSignals(std::shared_ptr<RBX::Player>)::$_4>::do_dtor; /*0x1067c899c*/
  *(_OWORD *)(v78 + 48) = *(_OWORD *)v96; /*0x1067c89a4*/
  *(_OWORD *)v96 = 0; /*0x1067c89a9*/
  *(_OWORD *)(v78 + 64) = *(_OWORD *)v97; /*0x1067c89b2*/
  *(_OWORD *)v97 = 0; /*0x1067c89b7*/
  rbx::signals::slots_holder::insert(this: v81, a2: v78); /*0x1067c89be*/
  *(_QWORD *)&v94[1] = v78; /*0x1067c89c3*/
  _InterlockedIncrement((volatile signed __int32 *)(v78 + 4)); /*0x1067c89ca*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v76, a2: v82); /*0x1067c89d2*/
  rbx::signals::scoped_connection::operator=(this: (rbx::signals::connection *)(a1 + 1720)); /*0x1067c89e5*/
  v85 = *(void **)&v94[1]; /*0x1067c89ea*/
  if ( *(_QWORD *)&v94[1] != 0 && _InterlockedDecrement((volatile signed __int32 *)(*(_QWORD *)&v94[1] + 4LL)) == 0 ) /*0x1067c89fa*/
    rbx::signals::slot_base::operator delete(a1: v85); /*0x1067c89fc*/
  if ( v97[1] != nullptr ) /*0x1067c8a08*/
    std::__shared_weak_count::__release_weak(this: v97[1]); /*0x1067c8a0a*/
  if ( v96[1] != nullptr ) /*0x1067c8a16*/
    std::__shared_weak_count::__release_weak(this: v96[1]); /*0x1067c8a18*/
  v86 = *a2; /*0x1067c8a1d*/
  std::string::basic_string[abi:ne200100]<0>(a1: v96, a2: "IsUnknownOrUnder13", a3: v83, a4: v84); /*0x1067c8a2b*/
  ParamBool = RBX::GameConfigurer::getParamBool(a1, a2: v96); /*0x1067c8a37*/
  RBX::Player::setUnder13(this: v86, a2: ParamBool); /*0x1067c8a42*/
  if ( ((__int64)v96[0] & 1) != 0 ) /*0x1067c8a4b*/
    operator delete(a1: v97[0]); /*0x1067c8a51*/
  return __stack_chk_guard; /*0x1067c8a66*/
}

// Address: 0x1067c8cdc | Name: __ZN3RBX16PlayerConfigurer36fillServerConnectionsArrayFromConfigERNSt3__16vectorINS_7Network14ConnectionInfoENS1_9allocatorIS4_EEEENS1_12basic_stringIcNS1_11char_traitsIcEENS5_IcEEEE
void __fastcall RBX::PlayerConfigurer::fillServerConnectionsArrayFromConfig(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v3; // r14
  __int64 v4; // r15
  __int64 v5; // r13
  __int64 v6; // rbx
  unsigned int v7; // eax
  std::__shared_weak_count *v8; // rbx
  std::__shared_weak_count *v9; // rbx
  _BYTE v10[16]; // [rsp+0h] [rbp-C0h] BYREF
  void *v11; // [rsp+10h] [rbp-B0h]
  char v12; // [rsp+28h] [rbp-98h]
  void *v13; // [rsp+38h] [rbp-88h]
  char v14; // [rsp+40h] [rbp-80h]
  void *v15; // [rsp+50h] [rbp-70h]
  __int64 *v16; // [rsp+58h] [rbp-68h] BYREF
  std::__shared_weak_count *v17; // [rsp+60h] [rbp-60h]
  _BYTE v18[16]; // [rsp+68h] [rbp-58h] BYREF
  void *v19; // [rsp+78h] [rbp-48h]
  __int64 v20; // [rsp+80h] [rbp-40h]
  RBX::Reflection::ValueTable *v21; // [rsp+88h] [rbp-38h] BYREF
  std::__shared_weak_count *v22; // [rsp+90h] [rbp-30h]

  v20 = a2; /*0x1067c8cf0*/
  RBX::GameConfigurer::getValueArray(a1: &v16, a2: a1, a3); /*0x1067c8cfe*/
  if ( v16 != nullptr ) /*0x1067c8d09*/
  {
    v3 = *v16; /*0x1067c8d0f*/
    v4 = v16[1]; /*0x1067c8d12*/
    if ( *v16 != v4 ) /*0x1067c8d19*/
    {
      do /*0x1067c8e1c*/
      {
        RBX::Reflection::Variant::get<std::shared_ptr<RBX::Reflection::ValueTable const>>(a1: &v21, a2: v3); /*0x1067c8d2d*/
        v5 = RBX::Reflection::ValueTable::find(this: v21, a2: "Address"); /*0x1067c8d42*/
        v6 = RBX::Reflection::ValueTable::find(this: v21, a2: "Port"); /*0x1067c8d55*/
        if ( v5 != 0 && v6 != 0 ) /*0x1067c8d61*/
        {
          RBX::Reflection::Variant::get<std::string>(a1: v18, a2: v5 + 40); /*0x1067c8d76*/
          v7 = RBX::Reflection::Variant::get<int>(a1: v6 + 40); /*0x1067c8d82*/
          RBX::Network::ConnectionInfo::ConnectionInfo(a1: v10, a2: v18, a3: v7); /*0x1067c8d90*/
          std::vector<RBX::Network::ConnectionInfo>::push_back[abi:ne200100](a1: v20, a2: v10); /*0x1067c8d9c*/
          if ( (v14 & 1) != 0 ) /*0x1067c8da5*/
            operator delete(a1: v15); /*0x1067c8dab*/
          if ( (v12 & 1) != 0 ) /*0x1067c8db7*/
            operator delete(a1: v13); /*0x1067c8dc0*/
          if ( (v10[0] & 1) != 0 ) /*0x1067c8dcc*/
            operator delete(a1: v11); /*0x1067c8dd5*/
          if ( (v18[0] & 1) != 0 ) /*0x1067c8dde*/
            operator delete(a1: v19); /*0x1067c8de4*/
        }
        v8 = v22; /*0x1067c8de9*/
        if ( v22 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v22 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067c8e02*/
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x1067c8e0a*/
          std::__shared_weak_count::__release_weak(this: v8); /*0x1067c8e10*/
        }
        v3 += 80; /*0x1067c8e15*/
      }
      while ( v3 != v4 ); /*0x1067c8e1c*/
    }
  }
  v9 = v17; /*0x1067c8e22*/
  if ( v17 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v17 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067c8e3b*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(a1: v9); /*0x1067c8e43*/
    std::__shared_weak_count::__release_weak(this: v9); /*0x1067c8e49*/
  }
}

// Address: 0x1067c8eac | Name: __ZN3RBX16PlayerConfigurer39reportRbxTransportAvailabilityTelemetryERKNSt3__18optionalIiEERKNS2_INS_4Rupp8TokenTlv5TokenEEE
void __fastcall RBX::PlayerConfigurer::reportRbxTransportAvailabilityTelemetry(__int64 a1, __int64 a2)
{
  _BYTE v4[72]; // [rsp+0h] [rbp-270h] BYREF
  _BYTE v5[552]; // [rsp+48h] [rbp-228h] BYREF

  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)2,std::enable_if<true,void>>( /*0x1067c8ed0*/
    a1: (__int64)v4,
    a2: (__int64)&RBX::Telemetry::kRbxTransportAvailability);
  RBX::Telemetry::FieldsContainer::addField( /*0x1067c8ef6*/
    a1: v5,
    a2: "rbxTransportPortAvailable",
    a3: 25,
    a4: *(unsigned __int8 *)(a1 + 4),
    a5: 1);
  RBX::Telemetry::FieldsContainer::addField( /*0x1067c8f14*/
    a1: v5,
    a2: "rbxTransportTokenAvailable",
    a3: 26,
    a4: *(unsigned __int8 *)(a2 + 17),
    a5: 1);
  if ( *(_BYTE *)(a1 + 4) == 1 ) /*0x1067c8f1e*/
    RBX::Telemetry::FieldsContainer::addField( /*0x1067c8f39*/
      a1: v5,
      a2: "rbxTransportTokenAvailableGivenPort",
      a3: 35,
      a4: *(unsigned __int8 *)(a2 + 17),
      a5: 1);
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v4); /*0x1067c8f45*/
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v4); /*0x1067c8f58*/
}

// Address: 0x1067c8fc0 | Name: __ZN3RBX16PlayerConfigurer12createPlayerEv
void __fastcall RBX::PlayerConfigurer::createPlayer(RBX::PlayerConfigurer *this)
{
  const RBX::UserInfo *v2; // r14
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // rdx
  __int64 v12; // rcx
  char isParamExist; // r15
  __int64 v14; // rdx
  __int64 v15; // rcx
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // rdx
  __int64 v19; // rcx
  __int64 v20; // rdx
  __int64 v21; // rcx
  char v22; // r15
  __int64 v23; // rdx
  __int64 v24; // rcx
  RBX::TeleportService *v25; // rax
  bool v26; // al
  __int64 v27; // rdx
  __int64 v28; // rcx
  __int128 v29; // xmm0
  std::__shared_weak_count *v30; // r14
  __int64 v31; // rdi
  __int64 v32; // rax
  std::__shared_weak_count *v33; // r14
  __int128 *v34; // rax
  char v35; // al
  RBX::Reflection::EnumDescriptor *v36; // r14
  __int64 v37; // rdx
  __int64 v38; // rcx
  RBX::Name *v39; // rsi
  RBX::PlayerProp *v40; // r15
  __int64 v41; // rdx
  __int64 v42; // rcx
  char v43; // al
  RBX::Reflection::EnumDescriptor *v44; // r12
  __int64 v45; // rdx
  __int64 v46; // rcx
  RBX::Name *v47; // rsi
  void *v48; // rdi
  _BOOL4 v49; // eax
  int v50; // eax
  __int64 v51; // rdx
  __int64 v52; // rcx
  __int64 v53; // rdx
  __int64 v54; // rcx
  int v55; // eax
  __int64 v56; // rsi
  __int64 v57; // rdx
  __int64 v58; // rcx
  int v59; // eax
  __int64 v60; // r13
  __int64 v61; // rdx
  __int64 v62; // rcx
  __int64 v63; // r14
  __int64 v64; // rsi
  __int64 v65; // r8
  __int64 v66; // r9
  _DWORD *v67; // r12
  __int64 v68; // rax
  __int64 v69; // rdx
  __int64 v70; // rcx
  int v71; // r13d
  __int64 v72; // rdx
  __int64 v73; // rcx
  __int64 v74; // r14
  _DWORD *v75; // r13
  __int64 v76; // rax
  __int64 v77; // rax
  __int64 v78; // rdx
  __int64 v79; // rcx
  __int64 v80; // rdx
  __int64 v81; // rcx
  __int64 v82; // rdx
  __int64 v83; // rcx
  void **v84; // rax
  __int64 v85; // rsi
  _QWORD *v86; // rax
  __int64 v87; // rdx
  __int64 v88; // rcx
  __int64 v89; // rax
  __int64 v90; // rdx
  __int64 v91; // rcx
  __int64 v92; // rdx
  __int64 v93; // rcx
  __int64 v94; // rax
  volatile signed __int64 *v95; // r14
  std::__shared_weak_count *v96; // rbx
  __int64 ParamInt64; // [rsp+20h] [rbp-2B0h] BYREF
  char ParamBool; // [rsp+28h] [rbp-2A8h]
  __int128 v99; // [rsp+30h] [rbp-2A0h]
  void *v100[2]; // [rsp+40h] [rbp-290h]
  __int128 v101; // [rsp+50h] [rbp-280h]
  __int128 v102; // [rsp+68h] [rbp-268h]
  void *v103[2]; // [rsp+78h] [rbp-258h]
  int ParamInt; // [rsp+88h] [rbp-248h]
  __int128 v105; // [rsp+90h] [rbp-240h]
  __int64 v106; // [rsp+A0h] [rbp-230h]
  __int64 v107; // [rsp+B0h] [rbp-220h]
  void *v108[4]; // [rsp+B8h] [rbp-218h] BYREF
  int v109; // [rsp+D8h] [rbp-1F8h]
  __int128 v110; // [rsp+E0h] [rbp-1F0h]
  void *v111[10]; // [rsp+F0h] [rbp-1E0h] BYREF
  __int128 v112; // [rsp+140h] [rbp-190h]
  void *v113; // [rsp+150h] [rbp-180h]
  _BYTE v114[16]; // [rsp+158h] [rbp-178h] BYREF
  void *v115; // [rsp+168h] [rbp-168h]
  _BYTE v116[16]; // [rsp+170h] [rbp-160h] BYREF
  void *v117; // [rsp+180h] [rbp-150h]
  _BYTE v118[16]; // [rsp+188h] [rbp-148h] BYREF
  void *v119; // [rsp+198h] [rbp-138h]
  _BYTE v120[16]; // [rsp+1A0h] [rbp-130h] BYREF
  char v121; // [rsp+1B0h] [rbp-120h] BYREF
  _BYTE v122[16]; // [rsp+1B8h] [rbp-118h] BYREF
  void *v123; // [rsp+1C8h] [rbp-108h]
  RBX::Player *v124[2]; // [rsp+1D0h] [rbp-100h] BYREF
  __int128 v125; // [rsp+1E0h] [rbp-F0h] BYREF
  void *v126; // [rsp+1F0h] [rbp-E0h]
  __int128 v127; // [rsp+200h] [rbp-D0h] BYREF
  void *v128; // [rsp+210h] [rbp-C0h] BYREF
  __int64 v129; // [rsp+218h] [rbp-B8h]
  int v130; // [rsp+224h] [rbp-ACh] BYREF
  _BYTE v131[16]; // [rsp+228h] [rbp-A8h] BYREF
  void *v132; // [rsp+238h] [rbp-98h]
  std::__shared_weak_count *v133[2]; // [rsp+240h] [rbp-90h]
  int v134[4]; // [rsp+258h] [rbp-78h] BYREF
  void *v135; // [rsp+268h] [rbp-68h]
  RBX::Player *v136; // [rsp+270h] [rbp-60h]
  std::__shared_weak_count *v137[2]; // [rsp+278h] [rbp-58h] BYREF
  void *v138; // [rsp+288h] [rbp-48h]
  __int128 v139; // [rsp+290h] [rbp-40h] BYREF
  void *v140; // [rsp+2A0h] [rbp-30h]

  v2 = (const RBX::UserInfo *)RBX::ServiceProvider::find<RBX::Players>(a1: *((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 464LL, a2: 0); /*0x1067c8fea*/
  ParamBool = 1; /*0x1067c8ff4*/
  v99 = 0; /*0x1067c8ffe*/
  *(_OWORD *)v100 = 0; /*0x1067c9005*/
  v101 = 0; /*0x1067c900c*/
  v102 = 0; /*0x1067c9013*/
  *(_OWORD *)v103 = 0; /*0x1067c901a*/
  ParamInt = 1; /*0x1067c9021*/
  v105 = 0; /*0x1067c902b*/
  v106 = 0; /*0x1067c9032*/
  v109 = 0; /*0x1067c9039*/
  memset(v108, 0, 29); /*0x1067c9043*/
  v110 = 0; /*0x1067c9051*/
  memset(v111, 0, sizeof(v111)); /*0x1067c9058*/
  v112 = 0; /*0x1067c907b*/
  v113 = nullptr; /*0x1067c9082*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "UserId", a3: v3, a4: v4); /*0x1067c9094*/
  ParamInt64 = RBX::GameConfigurer::getParamInt64(a1: this, a2: &v139); /*0x1067c90a5*/
  if ( (v139 & 1) != 0 ) /*0x1067c90b0*/
    operator delete(a1: v140); /*0x1067c90b6*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "UserName", a3: v5, a4: v6); /*0x1067c90c6*/
  RBX::GameConfigurer::getParamString(a1: &v139, a2: this, a3: v137); /*0x1067c90d6*/
  if ( (v99 & 1) != 0 ) /*0x1067c90e6*/
    operator delete(a1: v100[0]); /*0x1067c90ef*/
  v100[0] = v140; /*0x1067c90f8*/
  v99 = v139; /*0x1067c9100*/
  LOWORD(v139) = 0; /*0x1067c9104*/
  if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c910e*/
    operator delete(a1: v138); /*0x1067c9114*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "IsUnknownOrUnder13", a3: v7, a4: v8); /*0x1067c9124*/
  ParamBool = RBX::GameConfigurer::getParamBool(a1: this, a2: &v139); /*0x1067c9135*/
  if ( (v139 & 1) != 0 ) /*0x1067c913f*/
    operator delete(a1: v140); /*0x1067c9145*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "AlternateName", a3: v9, a4: v10); /*0x1067c9155*/
  isParamExist = RBX::GameConfigurer::isParamExist(a1: this, a2: v137); /*0x1067c9166*/
  if ( isParamExist != 0 ) /*0x1067c916b*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v114, a2: "AlternateName", a3: v11, a4: v12); /*0x1067c917b*/
    RBX::GameConfigurer::getParamString(a1: &v139, a2: this, a3: v114); /*0x1067c918e*/
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "", a3: v11, a4: v12); /*0x1067c91a0*/
  }
  if ( ((__int64)v111[7] & 1) != 0 ) /*0x1067c91b1*/
    operator delete(a1: v111[9]); /*0x1067c91ba*/
  v111[9] = v140; /*0x1067c91c3*/
  *(_OWORD *)&v111[7] = v139; /*0x1067c91cc*/
  LOWORD(v139) = 0; /*0x1067c91d1*/
  if ( isParamExist != 0 && (v114[0] & 1) != 0 ) /*0x1067c91e3*/
    operator delete(a1: v115); /*0x1067c91ec*/
  if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c91f5*/
    operator delete(a1: v138); /*0x1067c91fb*/
  if ( FFlag::EnablePlayerPartyId == 1 ) /*0x1067c920c*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "PartyId", a3: v14, a4: v15); /*0x1067c9219*/
    RBX::GameConfigurer::getParamString(a1: &v139, a2: this, a3: v137); /*0x1067c9229*/
    if ( (v102 & 1) != 0 ) /*0x1067c9239*/
      operator delete(a1: v103[0]); /*0x1067c9242*/
    v103[0] = v140; /*0x1067c924b*/
    v102 = v139; /*0x1067c9253*/
    LOWORD(v139) = 0; /*0x1067c9257*/
    if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c9261*/
      operator delete(a1: v138); /*0x1067c9267*/
  }
  if ( DFFlag::PopulateUserInformationForPlayers == 1 ) /*0x1067c9273*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "DomainUserId", a3: v14, a4: v15); /*0x1067c9280*/
    v103[1] = (void *)RBX::GameConfigurer::getParamInt64(a1: this, a2: &v139); /*0x1067c9291*/
    if ( (v139 & 1) != 0 ) /*0x1067c929c*/
      operator delete(a1: v140); /*0x1067c92a2*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "UserIdMode", a3: v16, a4: v17); /*0x1067c92b2*/
    ParamInt = RBX::GameConfigurer::getParamInt(a1: this, a2: &v139); /*0x1067c92c3*/
    if ( (v139 & 1) != 0 ) /*0x1067c92cd*/
      operator delete(a1: v140); /*0x1067c92d3*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "ServerClaimedTime", a3: v14, a4: v15); /*0x1067c92e3*/
  v107 = RBX::GameConfigurer::getParamInt64(a1: this, a2: &v139); /*0x1067c92f4*/
  if ( (v139 & 1) != 0 ) /*0x1067c92ff*/
    operator delete(a1: v140); /*0x1067c9305*/
  if ( DFFlag::JoinTicketAPIsecurityToken == 1 ) /*0x1067c9314*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "APIsecurityToken", a3: v18, a4: v19); /*0x1067c9321*/
    RBX::GameConfigurer::getParamString(a1: &v139, a2: this, a3: v137); /*0x1067c9331*/
    if ( ((__int64)v108[0] & 1) != 0 ) /*0x1067c9341*/
      operator delete(a1: v108[2]); /*0x1067c934a*/
    v108[2] = v140; /*0x1067c9353*/
    *(_OWORD *)v108 = v139; /*0x1067c935b*/
    LOWORD(v139) = 0; /*0x1067c935f*/
    if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c9369*/
      operator delete(a1: v138); /*0x1067c936f*/
  }
  if ( DFFlag::ConsumePlatformNameOverAlternateName == 1 ) /*0x1067c937e*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "PlatformName", a3: v18, a4: v19); /*0x1067c938b*/
    v22 = RBX::GameConfigurer::isParamExist(a1: this, a2: v137); /*0x1067c939c*/
    if ( v22 != 0 ) /*0x1067c93a1*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v131, a2: "PlatformName", a3: v20, a4: v21); /*0x1067c93b1*/
      RBX::GameConfigurer::getParamString(a1: &v139, a2: this, a3: v131); /*0x1067c93c4*/
      goto LABEL_42; /*0x1067c93c9*/
    }
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "AlternateName", a3: v18, a4: v19); /*0x1067c93d6*/
    v22 = RBX::GameConfigurer::isParamExist(a1: this, a2: v137); /*0x1067c93e7*/
    if ( v22 != 0 ) /*0x1067c93ec*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v131, a2: "AlternateName", a3: v20, a4: v21); /*0x1067c93fc*/
      RBX::GameConfigurer::getParamString(a1: &v139, a2: this, a3: v131); /*0x1067c940f*/
      goto LABEL_42; /*0x1067c9414*/
    }
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "", a3: v20, a4: v21); /*0x1067c9433*/
LABEL_42:
  if ( (v112 & 1) != 0 ) /*0x1067c9444*/
    operator delete(a1: v113); /*0x1067c944d*/
  v113 = v140; /*0x1067c9456*/
  v112 = v139; /*0x1067c945f*/
  LOWORD(v139) = 0; /*0x1067c9464*/
  if ( v22 != 0 && (v131[0] & 1) != 0 ) /*0x1067c9476*/
    operator delete(a1: v132); /*0x1067c947f*/
  if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c9488*/
    operator delete(a1: v138); /*0x1067c948e*/
  RBX::PlayerConfigurer::getGameLocaleIdFromParams( /*0x1067c949a*/
    this: (RBX::PlayerConfigurer *)&v139,
    a2: (__int64)this,
    a3: v23,
    a4: v24);
  if ( ((__int64)v111[1] & 1) != 0 ) /*0x1067c94aa*/
    operator delete(a1: v111[3]); /*0x1067c94b3*/
  v111[3] = v140; /*0x1067c94bc*/
  *(_OWORD *)&v111[1] = v139; /*0x1067c94c4*/
  *(_OWORD *)v133 = 0; /*0x1067c94cb*/
  v25 = (RBX::TeleportService *)RBX::ServiceProvider::find<RBX::TeleportService>( /*0x1067c94dd*/
                                  a1: *((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 464LL,
                                  a2: 0);
  v26 = v25 != nullptr && RBX::TeleportService::getPreviousPlaceId(this: v25) > 0; /*0x1067c94f2*/
  RBX::Players::createLocalPlayer(this: (RBX::Players *)v137, a2: v2, a3: (bool)&ParamInt64, a4: v26); /*0x1067c950d*/
  RBX::Reflection::DescribedBase::fastSharedDynamicCast<RBX::Player,RBX::Player>(a1: &v139, a2: v137); /*0x1067c951a*/
  v29 = v139; /*0x1067c951f*/
  v139 = 0; /*0x1067c9526*/
  *(_OWORD *)v133 = v29; /*0x1067c952a*/
  v30 = v137[1]; /*0x1067c9531*/
  if ( v137[1] != nullptr /*0x1067c954a*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v137[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v30 + 16LL))(a1: v30); /*0x1067c9552*/
    std::__shared_weak_count::__release_weak(this: v30); /*0x1067c9558*/
  }
  v31 = *((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */; /*0x1067c955d*/
  if ( v31 != 0 ) /*0x1067c9564*/
  {
    v32 = *(_QWORD *)RBX::ServiceProvider::refByClass<RBX::VRService>(this: (RBX::ServiceProvider *)(v31 + 464)); /*0x1067c9572*/
    v33 = v133[0]; /*0x1067c9575*/
    if ( v32 != 0 ) /*0x1067c957f*/
    {
      if ( (*(_BYTE *)(v32 + 200) & 1) != 0 ) /*0x1067c9588*/
      {
        std::string::__init_copy_ctor_external(a1: &v125, a2: *(_QWORD *)(v32 + 216), a3: *(_QWORD *)(v32 + 208)); /*0x1067c95c5*/
      }
      else
      {
        v34 = (__int128 *)(v32 + 200); /*0x1067c958a*/
        v126 = *((void **)v34 + 2); /*0x1067c9594*/
        v125 = *v34; /*0x1067c959e*/
      }
      RBX::PlayerProp::setVRDevice(a1: (char *)v33 + 176, a2: &v125); /*0x1067c95d8*/
      if ( (v125 & 1) != 0 ) /*0x1067c95e4*/
        operator delete(a1: v126); /*0x1067c95ed*/
    }
  }
  else
  {
    v33 = v133[0]; /*0x1067c95a7*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "SuperSafeChat", a3: v27, a4: v28); /*0x1067c95fd*/
  v35 = RBX::GameConfigurer::getParamBool(a1: this, a2: &v139); /*0x1067c9609*/
  RBX::PlayerProp::setSuperSafeChat(this: (std::__shared_weak_count *)((char *)v33 + 176), a2: v35); /*0x1067c961b*/
  if ( (v139 & 1) != 0 ) /*0x1067c9624*/
    operator delete(a1: v140); /*0x1067c962a*/
  v36 = (RBX::Reflection::EnumDescriptor *)RBX::Reflection::EnumDesc<RBX::MembershipType>::singleton(); /*0x1067c9634*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "MembershipType", a3: v37, a4: v38); /*0x1067c9642*/
  RBX::GameConfigurer::getParamString(a1: &v139, a2: this, a3: v137); /*0x1067c9652*/
  if ( (v139 & 1) != 0 ) /*0x1067c965b*/
    v39 = (RBX::Name *)v140; /*0x1067c965d*/
  else
    v39 = (RBX::Name *)((char *)&v139 + 1); /*0x1067c9663*/
  RBX::Reflection::EnumDescriptor::_convertToValue(this: v36, a2: v39, a3: &v130); /*0x1067c9671*/
  if ( (v139 & 1) != 0 ) /*0x1067c967a*/
    operator delete(a1: v140); /*0x1067c9680*/
  if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c9689*/
    operator delete(a1: v138); /*0x1067c968f*/
  v136 = v133[0]; /*0x1067c969b*/
  v40 = (std::__shared_weak_count *)((char *)v133[0] + 176); /*0x1067c969f*/
  RBX::PlayerProp::setMembershipType(a1: (char *)v133[0] + 176, a2: (unsigned int)v130); /*0x1067c96af*/
  if ( DFFlag::ReadHasRobloxSubscription == 1 ) /*0x1067c96bb*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "HasRobloxSubscription", a3: v41, a4: v42); /*0x1067c96c8*/
    v43 = RBX::GameConfigurer::getParamBool(a1: this, a2: &v139); /*0x1067c96d4*/
    RBX::PlayerProp::setHasRobloxSubscription(this: v40, a2: v43); /*0x1067c96df*/
    if ( (v139 & 1) != 0 ) /*0x1067c96e8*/
      operator delete(a1: v140); /*0x1067c96ee*/
  }
  if ( DFFlag::ReadAgeChecked == 1 ) /*0x1067c96fa*/
  {
    v134[0] = 0; /*0x1067c9700*/
    if ( DFFlag::DecodeAgeCheckedAsInt == 1 ) /*0x1067c970e*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "AgeChecked", a3: v41, a4: v42); /*0x1067c971b*/
      RBX::GameConfigurer::getParamString(a1: &v139, a2: this, a3: v137); /*0x1067c972b*/
      if ( (v139 & 1) == 0 ) /*0x1067c9735*/
      {
        v134[0] = (_BYTE)v139 == 2 && BYTE1(v139) == 49; /*0x1067c9744*/
        goto LABEL_92; /*0x1067c9747*/
      }
      v48 = v140; /*0x1067c977d*/
      v49 = false; /*0x1067c9781*/
      if ( *((_QWORD *)&v139 + 1) == 1 ) /*0x1067c9788*/
        v49 = *(_BYTE *)v140 == 49; /*0x1067c978f*/
      v134[0] = v49; /*0x1067c9792*/
    }
    else
    {
      v44 = (RBX::Reflection::EnumDescriptor *)RBX::Reflection::EnumDesc<RBX::Enums::AgeCheckStatus>::singleton(); /*0x1067c974e*/
      std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "AgeChecked", a3: v45, a4: v46); /*0x1067c975c*/
      RBX::GameConfigurer::getParamString(a1: &v139, a2: this, a3: v137); /*0x1067c976c*/
      if ( (v139 & 1) != 0 ) /*0x1067c9775*/
        v47 = (RBX::Name *)v140; /*0x1067c9777*/
      else
        v47 = (RBX::Name *)((char *)&v139 + 1); /*0x1067c9797*/
      RBX::Reflection::EnumDescriptor::_convertToValue(this: v44, a2: v47, a3: v134); /*0x1067c97a2*/
      if ( (v139 & 1) == 0 ) /*0x1067c97ab*/
        goto LABEL_92; /*0x1067c97ab*/
      v48 = v140; /*0x1067c97ad*/
    }
    operator delete(a1: v48); /*0x1067c97b1*/
LABEL_92:
    if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c97c3*/
      operator delete(a1: v138); /*0x1067c97c9*/
    RBX::PlayerProp::setAgeChecked(a1: v40, a2: (unsigned int)v134[0]); /*0x1067c97d4*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "AccountAge", a3: v41, a4: v42); /*0x1067c97d9*/
  v50 = RBX::GameConfigurer::getParamInt(a1: this, a2: &v139); /*0x1067c97f0*/
  RBX::PlayerProp::setAccountAge(this: v40, a2: v50); /*0x1067c97fa*/
  if ( (v139 & 1) != 0 ) /*0x1067c9803*/
    operator delete(a1: v140); /*0x1067c9809*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "CountryCode", a3: v51, a4: v52); /*0x1067c9819*/
  RBX::GameConfigurer::getParamString(a1: &v139, a2: this, a3: v137); /*0x1067c9829*/
  RBX::PlayerProp::setCountryRegionCode(a1: v40, a2: &v139); /*0x1067c9835*/
  if ( (v139 & 1) != 0 ) /*0x1067c983e*/
    operator delete(a1: v140); /*0x1067c9844*/
  if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c984d*/
    operator delete(a1: v138); /*0x1067c9853*/
  if ( FFlag::EnablePlayerPartyId == 1 ) /*0x1067c985d*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "PartyId", a3: v53, a4: v54); /*0x1067c986a*/
    RBX::GameConfigurer::getParamString(a1: v116, a2: this, a3: &v139); /*0x1067c987d*/
    RBX::PlayerProp::setPartyId(a1: v40, a2: v116); /*0x1067c988c*/
    if ( (v116[0] & 1) != 0 ) /*0x1067c9898*/
      operator delete(a1: v117); /*0x1067c98a1*/
    if ( (v139 & 1) != 0 ) /*0x1067c98aa*/
      operator delete(a1: v140); /*0x1067c98b0*/
  }
  if ( DFFlag::PopulateUserInformationForPlayers == 1 ) /*0x1067c98bc*/
  {
    if ( FFlag::ReplicatePlayerUserIdMode == 1 ) /*0x1067c98cc*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "UserIdMode", a3: v53, a4: v54); /*0x1067c98d9*/
      v55 = RBX::GameConfigurer::getParamInt(a1: this, a2: &v139); /*0x1067c98e5*/
      v56 = 2 * (unsigned int)(v55 == 2); /*0x1067c98f3*/
      if ( v55 == 1 ) /*0x1067c98f8*/
        v56 = 1; /*0x1067c98f8*/
      RBX::PlayerProp::setUserIdModeReplicate(a1: v40, a2: v56); /*0x1067c98fe*/
    }
    else
    {
      std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "UserIdMode", a3: v53, a4: v54); /*0x1067c9910*/
      v59 = RBX::GameConfigurer::getParamInt(a1: this, a2: &v139); /*0x1067c991c*/
      v58 = 2 * (unsigned int)(v59 == 2); /*0x1067c9929*/
      if ( v59 == 1 ) /*0x1067c992e*/
        v58 = 1; /*0x1067c992e*/
      *((_DWORD *)v136 + 610) = v58; /*0x1067c9935*/
    }
    if ( (v139 & 1) != 0 ) /*0x1067c993f*/
      operator delete(a1: v140); /*0x1067c9945*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "DomainUserId", a3: v57, a4: v58); /*0x1067c9955*/
    v60 = RBX::GameConfigurer::getParamInt64(a1: this, a2: &v139); /*0x1067c9966*/
    std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "UniverseId", a3: v61, a4: v62); /*0x1067c9974*/
    v63 = RBX::GameConfigurer::getParamInt64(a1: this, a2: v137); /*0x1067c9985*/
    v67 = (_DWORD *)operator new(a1: 0x20u); /*0x1067c9992*/
    v68 = ParamInt64; /*0x1067c9995*/
    *(_QWORD *)v67 = v60; /*0x1067c999c*/
    v67[2] = 1; /*0x1067c99a0*/
    *((_QWORD *)v67 + 2) = v63; /*0x1067c99a9*/
    *((_QWORD *)v67 + 3) = v68; /*0x1067c99ae*/
    if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c99b7*/
      operator delete(a1: v138); /*0x1067c99bd*/
    if ( (v139 & 1) != 0 ) /*0x1067c99c6*/
      operator delete(a1: v140); /*0x1067c99cc*/
    if ( FFlag::PopulatePlayerUser == 1 ) /*0x1067c99d8*/
    {
      if ( FFlag::PlayerUserIdReturnsEffectiveId == 1 ) /*0x1067c99e8*/
      {
        std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "UserIdMode", a3: v53, a4: v54); /*0x1067c99f9*/
        v71 = RBX::GameConfigurer::getParamInt(a1: this, a2: &v139); /*0x1067c9a0a*/
        if ( (v139 & 1) != 0 ) /*0x1067c9a11*/
          operator delete(a1: v140); /*0x1067c9a17*/
        std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "DomainUserId", a3: v69, a4: v70); /*0x1067c9a27*/
        v129 = RBX::GameConfigurer::getParamInt64(a1: this, a2: &v139); /*0x1067c9a38*/
        if ( (v139 & 1) != 0 ) /*0x1067c9a43*/
          operator delete(a1: v140); /*0x1067c9a49*/
        if ( v71 != 2 ) /*0x1067c9a52*/
          v129 = ParamInt64; /*0x1067c9a5b*/
        std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "UniverseId", a3: v72, a4: v73); /*0x1067c9a6d*/
        v74 = RBX::GameConfigurer::getParamInt64(a1: this, a2: &v139); /*0x1067c9a7e*/
        v75 = (_DWORD *)operator new(a1: 0x20u); /*0x1067c9a8b*/
        v76 = ParamInt64; /*0x1067c9a8e*/
        *(_QWORD *)v75 = v129; /*0x1067c9a9c*/
        v75[2] = 1; /*0x1067c9aa0*/
        *((_QWORD *)v75 + 2) = v74; /*0x1067c9aa8*/
        *((_QWORD *)v75 + 3) = v76; /*0x1067c9aac*/
        operator delete(a1: v67); /*0x1067c9ab3*/
        if ( (v139 & 1) != 0 ) /*0x1067c9abc*/
          operator delete(a1: v140); /*0x1067c9ac2*/
      }
      else
      {
        v75 = v67; /*0x1067c9ae2*/
      }
      RBX::PlayerProp::setUser( /*0x1067c9afb*/
        a1: v40,
        a2: v64,
        a3: v53,
        a4: v54,
        a5: v65,
        a6: v66,
        a7: *(_QWORD *)v75,
        a8: *((_QWORD *)v75 + 1),
        a9: *((_QWORD *)v75 + 2),
        a10: *((_QWORD *)v75 + 3));
      goto LABEL_134; /*0x1067c9afb*/
    }
    v75 = *((_DWORD **)v136 + 304); /*0x1067c9acd*/
    *((_QWORD *)v136 + 304) = v67; /*0x1067c9ad4*/
    if ( v75 != nullptr ) /*0x1067c9ade*/
LABEL_134:
      operator delete(a1: v75); /*0x1067c9b00*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "ServerClaimedTime", a3: v53, a4: v54); /*0x1067c9b08*/
  v77 = RBX::GameConfigurer::getParamInt64(a1: this, a2: &v139); /*0x1067c9b1f*/
  RBX::Player::setServerClaimedTime(this: v136, a2: v77); /*0x1067c9b2b*/
  if ( (v139 & 1) != 0 ) /*0x1067c9b34*/
    operator delete(a1: v140); /*0x1067c9b3a*/
  if ( DFFlag::JoinTicketAPIsecurityToken == 1 ) /*0x1067c9b49*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v139, a2: "APIsecurityToken", a3: v78, a4: v79); /*0x1067c9b56*/
    RBX::GameConfigurer::getParamString(a1: v118, a2: this, a3: &v139); /*0x1067c9b69*/
    RBX::Player::setAPIsecurityToken(a1: v136, a2: v118); /*0x1067c9b79*/
    if ( (v118[0] & 1) != 0 ) /*0x1067c9b85*/
      operator delete(a1: v119); /*0x1067c9b8e*/
    if ( (v139 & 1) != 0 ) /*0x1067c9b97*/
      operator delete(a1: v140); /*0x1067c9b9d*/
  }
  v139 = 0; /*0x1067c9ba5*/
  v140 = nullptr; /*0x1067c9ba9*/
  std::string::basic_string[abi:ne200100]<0>(a1: v134, a2: "GameChatType", a3: v78, a4: v79); /*0x1067c9bbc*/
  RBX::GameConfigurer::getParamString(a1: v137, a2: this, a3: v134); /*0x1067c9bcc*/
  v139 = *(_OWORD *)v137; /*0x1067c9bd5*/
  v140 = v138; /*0x1067c9bdd*/
  LOWORD(v137[0]) = 0; /*0x1067c9be1*/
  if ( (v134[0] & 1) != 0 ) /*0x1067c9beb*/
    operator delete(a1: v135); /*0x1067c9bf1*/
  if ( FFlag::DebugForceChatDisabled == 1 ) /*0x1067c9bfd*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v120, a2: "Unknown", a3: v80, a4: v81); /*0x1067c9c0d*/
    RBX::PlayerProp::setChatAvailabilityStatus(a1: v40, a2: v120); /*0x1067c9c1c*/
    if ( (v120[0] & 1) != 0 ) /*0x1067c9c28*/
    {
      v84 = (void **)&v121; /*0x1067c9c2a*/
LABEL_152:
      operator delete(a1: *v84); /*0x1067c9c84*/
    }
  }
  else
  {
    if ( (v139 & 1) != 0 ) /*0x1067c9c37*/
    {
      std::string::__init_copy_ctor_external(a1: &v127, a2: v140, a3: *((_QWORD *)&v139 + 1)); /*0x1067c9c60*/
    }
    else
    {
      v128 = v140; /*0x1067c9c3d*/
      v127 = v139; /*0x1067c9c48*/
    }
    RBX::PlayerProp::setChatAvailabilityStatus(a1: v40, a2: &v127); /*0x1067c9c6f*/
    if ( (v127 & 1) != 0 ) /*0x1067c9c7b*/
    {
      v84 = &v128; /*0x1067c9c7d*/
      goto LABEL_152; /*0x1067c9c7d*/
    }
  }
  if ( *((_BYTE *)this + 65) /* +65 likely isStudioToRcc -- UNVERIFIED */ == 0 ) /*0x1067c9c90*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v122, a2: "Enabled", a3: v82, a4: v83); /*0x1067c9ca0*/
    RBX::PlayerProp::setChatAvailabilityStatus(a1: v40, a2: v122); /*0x1067c9caf*/
    if ( (v122[0] & 1) != 0 ) /*0x1067c9cbb*/
      operator delete(a1: v123); /*0x1067c9cc4*/
  }
  v85 = 1; /*0x1067c9cc9*/
  if ( FFlag::DebugForceChatDisabled == 0 ) /*0x1067c9cd5*/
  {
    if ( (v139 & 1) != 0 ) /*0x1067c9cdd*/
    {
      if ( *((_QWORD *)&v139 + 1) != 7 /*0x1067c9d0f*/
        || (*(_DWORD *)v140 ^ 0x62616E45 | *(_DWORD *)((char *)v140 + 3) ^ 0x64656C62) != 0 )
      {
        if ( *((_QWORD *)&v139 + 1) != 8 ) /*0x1067c9d16*/
          goto LABEL_167; /*0x1067c9d16*/
        v86 = v140; /*0x1067c9d18*/
LABEL_165:
        if ( *v86 != 0x73726573556C6C41LL ) /*0x1067c9d29*/
          goto LABEL_167; /*0x1067c9d29*/
      }
LABEL_166:
      v85 = 0; /*0x1067c9d2b*/
      goto LABEL_167; /*0x1067c9d2b*/
    }
    if ( (unsigned __int8)v139 != 14 ) /*0x1067c9ce2*/
    {
      if ( (unsigned __int8)v139 != 16 ) /*0x1067c9ceb*/
        goto LABEL_167; /*0x1067c9ceb*/
      v86 = (_QWORD *)((char *)&v139 + 1); /*0x1067c9ced*/
      goto LABEL_165; /*0x1067c9cf1*/
    }
    if ( (*(_DWORD *)((char *)&v139 + 1) ^ 0x62616E45 | DWORD1(v139) ^ 0x64656C62) == 0 ) /*0x1067c9ec3*/
      goto LABEL_166; /*0x1067c9ec3*/
  }
LABEL_167:
  RBX::PlayerProp::setChatPrivacyMode(a1: v40, a2: v85); /*0x1067c9d2d*/
  if ( *((_BYTE *)this + 65) /* +65 likely isStudioToRcc -- UNVERIFIED */ == 0 ) /*0x1067c9d39*/
    RBX::PlayerProp::setChatPrivacyMode(a1: v40, a2: 0); /*0x1067c9d40*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "characterAppearanceId", a3: v87, a4: v88); /*0x1067c9d50*/
  v89 = RBX::GameConfigurer::getParamInt64(a1: this, a2: v137); /*0x1067c9d5c*/
  RBX::PlayerProp::setCharacterAppearanceId(this: v40, a2: v89); /*0x1067c9d67*/
  if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c9d70*/
    operator delete(a1: v138); /*0x1067c9d76*/
  std::string::basic_string[abi:ne200100]<0>(a1: v134, a2: "CharacterAppearance", a3: v90, a4: v91); /*0x1067c9d86*/
  RBX::GameConfigurer::getParamString(a1: v137, a2: this, a3: v134); /*0x1067c9d96*/
  RBX::PlayerProp::setCharacterAppearance(a1: v40, a2: v137); /*0x1067c9da2*/
  if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c9dab*/
    operator delete(a1: v138); /*0x1067c9db1*/
  if ( (v134[0] & 1) != 0 ) /*0x1067c9dba*/
    operator delete(a1: v135); /*0x1067c9dc0*/
  std::string::basic_string[abi:ne200100]<0>(a1: v137, a2: "FollowUserId", a3: v92, a4: v93); /*0x1067c9dd0*/
  v94 = RBX::GameConfigurer::getParamInt64(a1: this, a2: v137); /*0x1067c9ddc*/
  RBX::PlayerProp::setFollowUserId(this: v40, a2: v94); /*0x1067c9de7*/
  if ( ((__int64)v137[0] & 1) != 0 ) /*0x1067c9df0*/
    operator delete(a1: v138); /*0x1067c9df6*/
  v124[0] = v136; /*0x1067c9dff*/
  v95 = (volatile signed __int64 *)v133[1]; /*0x1067c9e06*/
  v124[1] = v133[1]; /*0x1067c9e0d*/
  if ( v133[1] != nullptr ) /*0x1067c9e17*/
    _InterlockedIncrement64((volatile signed __int64 *)v133[1] + 1); /*0x1067c9e19*/
  RBX::PlayerConfigurer::connectPlayerToSignals(a1: (__int64)this, a2: v124); /*0x1067c9e28*/
  if ( v95 != nullptr && _InterlockedExchangeAdd64(v95 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1067c9e42*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v95 + 16))(a1: v95); /*0x1067c9e4a*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v95); /*0x1067c9e50*/
  }
  if ( (v139 & 1) != 0 ) /*0x1067c9e59*/
    operator delete(a1: v140); /*0x1067c9e5f*/
  v96 = v133[1]; /*0x1067c9e64*/
  if ( v133[1] != nullptr /*0x1067c9e80*/
    && _InterlockedExchangeAdd64((volatile signed __int64 *)v133[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v96 + 16LL))(a1: v96); /*0x1067c9e88*/
    std::__shared_weak_count::__release_weak(this: v96); /*0x1067c9e8e*/
  }
  RBX::UserInfo::~UserInfo(this: (RBX::UserInfo *)&ParamInt64); /*0x1067c9e9a*/
}

// Address: 0x1067ca280 | Name: __ZN3RBX16PlayerConfigurer15onPlayerChangedEPKNS_10Reflection18PropertyDescriptorE
void __fastcall RBX::PlayerConfigurer::onPlayerChanged(
        RBX::PlayerConfigurer *this,
        const RBX::Reflection::PropertyDescriptor *a2)
{
  RBX::Time *v3; // rdi
  double v4; // xmm0_8
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // rdx
  __int64 v8; // rcx
  int v9; // ecx
  int v10; // r8d
  int v11; // r9d
  int v12; // edi
  unsigned int v13; // eax
  __int64 v14; // rax
  __int64 v15; // r14
  RBX::Network::Replicator *v16; // rax
  __int64 v17; // rax
  __int64 v18; // rax
  __int64 v19; // rax
  char *v20; // rsi
  __int64 v21; // rdx
  __int64 v22; // rax
  __int64 v23; // rdi
  __int64 v24; // rdx
  __int64 v25; // rcx
  __int64 v26; // rax
  unsigned __int8 v27; // al
  unsigned int v28; // r14d
  RBX::MegaClusterInstance *v29; // r12
  __int64 v30; // r13
  __int64 v31; // rax
  char isAllocated; // al
  __int64 Workspace; // rax
  char NetworkStreamingEnabled; // al
  RBX::TeleportService *v35; // rax
  __int64 v36; // rdx
  __int64 v37; // rcx
  __int64 v38; // rax
  const char *v39; // rdx
  RBX::Time *v40; // rdi
  int ParamInt; // r12d
  __int64 v42; // xmm0_8
  __int128 v43; // [rsp+0h] [rbp-C0h] BYREF
  void *v44; // [rsp+10h] [rbp-B0h]
  _BYTE v45[16]; // [rsp+20h] [rbp-A0h] BYREF
  void *v46; // [rsp+30h] [rbp-90h]
  double v47; // [rsp+38h] [rbp-88h]
  __int128 v48; // [rsp+40h] [rbp-80h] BYREF
  void *v49; // [rsp+50h] [rbp-70h]
  __int128 v50; // [rsp+60h] [rbp-60h] BYREF
  void *v51; // [rsp+70h] [rbp-50h]
  __int128 v52; // [rsp+80h] [rbp-40h] BYREF
  void *v53; // [rsp+90h] [rbp-30h]

  if ( (unsigned __int8)RBX::Name::operator==(a1: *((_QWORD *)a2 + 1), a2: "Character") != 0 ) /*0x1067ca2a9*/
  {
    this->waitingForCharacter /* +64 */ = 0; /*0x1067ca2af*/
    rbx::signals::connection::disconnect(this: (RBX::PlayerConfigurer *)((char *)this + 1656 /* +1656: NO 2022 FIELD */)); /*0x1067ca2ba*/
    if ( this->joinResolved /* +54 */ == 0 ) /*0x1067ca2c3*/
    {
      this->joinResolved /* +54 */ = 1; /*0x1067ca2c9*/
      RBX::Time::nowFastSec(this: v3); /*0x1067ca2cd*/
      v47 = v4; /*0x1067ca2d2*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v50, a2: "GameJoin", a3: v5, a4: v6); /*0x1067ca2e5*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v52, a2: "Success", a3: v7, a4: v8); /*0x1067ca2f5*/
      RBX::PlayerConfigurer::reportDuration( /*0x1067ca315*/
        a1: (__int64)this,
        a2: (unsigned __int8 *)&v50,
        a3: (unsigned __int8 *)&v52,
        a4: v47 - *((double *)this + 32) /* +256: NO 2022 FIELD */);
      if ( (v52 & 1) != 0 ) /*0x1067ca31e*/
        operator delete(a1: v53); /*0x1067ca324*/
      if ( (v50 & 1) != 0 ) /*0x1067ca32d*/
        operator delete(a1: v51); /*0x1067ca333*/
      if ( FFlag::LogClientLoadToAvatarLoad == 1 ) /*0x1067ca342*/
      {
        v12 = FLog::LogStepTimeAndNetworkUsage; /*0x1067ca34b*/
        v13 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067ca350*/
        if ( (unsigned __int8)FLog::LogStepTimeAndNetworkUsage >= 6u && BYTE1(FLog::LogStepTimeAndNetworkUsage) >= 3u ) /*0x1067ca35c*/
        {
          FLog::FastLog( /*0x1067ca370*/
            a1: *(_QWORD *)&FLog::LogStepTimeAndNetworkUsage,
            a2: qword_10D804018,
            a3: "[FLog::LogStepTimeAndNetworkUsage] Game Join",
            0);
          v12 = FLog::LogStepTimeAndNetworkUsage; /*0x1067ca375*/
          v13 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067ca37a*/
        }
        if ( (unsigned __int8)v12 >= 6u && (unsigned __int8)v13 >= 3u ) /*0x1067ca386*/
        {
          LOBYTE(v9) = (unsigned __int8)v12 < 6u; /*0x1067ca381*/
          FLog::FastLogFormatted( /*0x1067ca39a*/
            a1: v12,
            a2: qword_10D804018,
            a3: (unsigned int)"[FLog::LogStepTimeAndNetworkUsage] 0, 0, 0, 0",
            a4: v9,
            a5: v10,
            a6: v11);
        }
      }
      v14 = RBX::ServiceProvider::find<RBX::Network::Client>(a1: *((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 464LL, a2: 0); /*0x1067ca3aa*/
      if ( v14 != 0 ) /*0x1067ca3b2*/
      {
        v15 = v14; /*0x1067ca3b4*/
        rbx::signal<void ()(RBX::StringLiteral const&)>::invokeImpl<(rbx::SignalInvokePolicy)0>( /*0x1067ca3c8*/
          a1: v14 + 4864,
          a2: &RBX::Analytics::kPlayerSetCharacter);
        v16 = (RBX::Network::Replicator *)RBX::Instance::findConstFirstChildOfType<RBX::Network::ClientReplicator>(a1: v15); /*0x1067ca3d0*/
        if ( v16 != nullptr ) /*0x1067ca3d8*/
          RBX::Network::Replicator::addReplicatorState(this: v16); /*0x1067ca3e2*/
      }
      *((double *)this + 30) /* +240: NO 2022 FIELD */ = v47 - *((double *)this + 21) /* +168: NO 2022 FIELD */; /*0x1067ca3f7*/
      *((_DWORD *)this + 110) /* +440: NO 2022 FIELD */ = 8; /*0x1067ca3ff*/
      RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)&v52); /*0x1067ca410*/
      v17 = std::string::insert(a1: &v52, a2: 0, a3: "GameJoinSuccess_"); /*0x1067ca421*/
      v51 = *(void **)(v17 + 16); /*0x1067ca42a*/
      v50 = *(_OWORD *)v17; /*0x1067ca432*/
      *(_OWORD *)v17 = 0; /*0x1067ca43b*/
      *(_QWORD *)(v17 + 16) = 0; /*0x1067ca43f*/
      if ( (v52 & 1) != 0 ) /*0x1067ca44b*/
        operator delete(a1: v53); /*0x1067ca451*/
      RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)v45); /*0x1067ca45d*/
      v18 = std::string::insert(a1: v45, a2: 0, a3: "GameJoinSuccess,GameJoin"); /*0x1067ca472*/
      v44 = *(void **)(v18 + 16); /*0x1067ca482*/
      v43 = *(_OWORD *)v18; /*0x1067ca48a*/
      *(_OWORD *)v18 = 0; /*0x1067ca492*/
      *(_QWORD *)(v18 + 16) = 0; /*0x1067ca496*/
      v19 = std::string::append(a1: &v43, a2: ","); /*0x1067ca4a5*/
      v49 = *(void **)(v19 + 16); /*0x1067ca4ae*/
      v48 = *(_OWORD *)v19; /*0x1067ca4b6*/
      *(_OWORD *)v19 = 0; /*0x1067ca4bf*/
      *(_QWORD *)(v19 + 16) = 0; /*0x1067ca4c3*/
      if ( (v50 & 1) != 0 ) /*0x1067ca4d2*/
      {
        v20 = (char *)v51; /*0x1067ca4d4*/
        v21 = *((_QWORD *)&v50 + 1); /*0x1067ca4d8*/
      }
      else
      {
        v21 = (unsigned __int8)v50 >> 1; /*0x1067ca4de*/
        v20 = (char *)&v50 + 1; /*0x1067ca4e0*/
      }
      v22 = std::string::append(a1: &v48, a2: v20, a3: v21); /*0x1067ca4e8*/
      v53 = *(void **)(v22 + 16); /*0x1067ca4f5*/
      v52 = *(_OWORD *)v22; /*0x1067ca4fd*/
      *(_OWORD *)v22 = 0; /*0x1067ca505*/
      *(_QWORD *)(v22 + 16) = 0; /*0x1067ca509*/
      RBX::PlayerConfigurer::reportCounter(a1: v23, a2: (__int64)&v52, a3: 0); /*0x1067ca513*/
      if ( (v52 & 1) != 0 ) /*0x1067ca51c*/
        operator delete(a1: v53); /*0x1067ca522*/
      if ( (v48 & 1) != 0 ) /*0x1067ca52b*/
        operator delete(a1: v49); /*0x1067ca531*/
      if ( (v43 & 1) != 0 ) /*0x1067ca53d*/
        operator delete(a1: v44); /*0x1067ca546*/
      if ( (v45[0] & 1) != 0 ) /*0x1067ca552*/
        operator delete(a1: v46); /*0x1067ca55b*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v52, a2: "InGame", a3: v24, a4: v25); /*0x1067ca56b*/
      RBX::Stats::reportGameStatus(a1: &v52, a2: 0); /*0x1067ca576*/
      if ( (v52 & 1) != 0 ) /*0x1067ca57f*/
        operator delete(a1: v53); /*0x1067ca585*/
      v26 = RBX::ServiceProvider::find<RBX::Players>(a1: *((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 464LL, a2: 0); /*0x1067ca595*/
      if ( v26 != 0 ) /*0x1067ca59d*/
        v27 = *(_BYTE *)(v26 + 317); /*0x1067ca59f*/
      else
        v27 = 0; /*0x1067ca5a7*/
      v28 = v27; /*0x1067ca5b0*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ca5c1*/
        this: (RBX::PlayerConfigurer *)((char *)this + 1152 /* +1152: NO 2022 FIELD */),
        a2: "CharacterAutoSpawn",
        a3: v27);
      v29 = *(RBX::MegaClusterInstance **)(RBX::DataModelProp::getWorkspace(this: (RBX::DataModelProp *)(*((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 720LL)) /*0x1067ca5d4*/
                                         + 1120);
      if ( v29 != nullptr /*0x1067ca604*/
        && (v30 = *((_QWORD *)v29 + 3),
            v31 = RBX::Reflection::Class_getDescriptorPtr<RBX::MegaClusterInstance>(),
            *(unsigned __int16 *)(v30 + 440) - (unsigned int)*(unsigned __int16 *)(v31 + 440) <= *(unsigned __int16 *)(v31 + 442)) )
      {
        isAllocated = RBX::MegaClusterInstance::isAllocated(this: v29); /*0x1067ca60d*/
      }
      else
      {
        isAllocated = 0; /*0x1067ca606*/
      }
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ca61f*/
        this: (RBX::PlayerConfigurer *)((char *)this + 1152 /* +1152: NO 2022 FIELD */),
        a2: "HasTerrain",
        a3: isAllocated);
      Workspace = RBX::DataModelProp::getWorkspace(this: (RBX::DataModelProp *)(*((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 720LL)); /*0x1067ca62d*/
      NetworkStreamingEnabled = RBX::WorkspaceProp::getNetworkStreamingEnabled(this: (RBX::WorkspaceProp *)(Workspace + 1056)); /*0x1067ca63b*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ca64d*/
        this: (RBX::PlayerConfigurer *)((char *)this + 1152 /* +1152: NO 2022 FIELD */),
        a2: "StreamingEnabled",
        a3: NetworkStreamingEnabled);
      v35 = (RBX::TeleportService *)RBX::ServiceProvider::find<RBX::TeleportService>( /*0x1067ca65d*/
                                      a1: *((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 464LL,
                                      a2: 0);
      if ( v35 != nullptr && RBX::TeleportService::getPreviousPlaceId(this: v35) > 0 ) /*0x1067ca672*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ca68a*/
          this: (RBX::PlayerConfigurer *)((char *)this + 1152 /* +1152: NO 2022 FIELD */),
          a2: "Mode",
          a3: "Teleport",
          a4: true);
      RBX::SystemUtil::getNetworkType(this: (RBX::SystemUtil *)&v52); /*0x1067ca693*/
      if ( (v52 & 1) != 0 ) /*0x1067ca69e*/
        v38 = *((_QWORD *)&v52 + 1); /*0x1067ca6a0*/
      else
        v38 = (unsigned __int8)v52 >> 1; /*0x1067ca6a6*/
      if ( v38 != 0 ) /*0x1067ca6ab*/
      {
        std::string::operator=(a1: (char *)this + 328 /* +328: NO 2022 FIELD */, a2: &v52); /*0x1067ca6b8*/
        if ( (v52 & 1) != 0 ) /*0x1067ca6c1*/
          v39 = (const char *)v53; /*0x1067ca6c3*/
        else
          v39 = (char *)&v52 + 1; /*0x1067ca6c9*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ca6d7*/
          this: (RBX::PlayerConfigurer *)((char *)this + 1152 /* +1152: NO 2022 FIELD */),
          a2: "NetworkType",
          a3: v39);
      }
      std::string::basic_string[abi:ne200100]<0>(a1: &v48, a2: "DataCenterId", a3: v36, a4: v37); /*0x1067ca6e7*/
      ParamInt = RBX::GameConfigurer::getParamInt(a1: this, a2: &v48); /*0x1067ca6f8*/
      if ( (v48 & 1) != 0 ) /*0x1067ca6ff*/
        operator delete(a1: v49); /*0x1067ca705*/
      if ( ParamInt != 0 ) /*0x1067ca70d*/
      {
        *((_DWORD *)this + 94) /* +376: NO 2022 FIELD */ = ParamInt; /*0x1067ca70f*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x1067ca723*/
          this: (RBX::PlayerConfigurer *)((char *)this + 1152 /* +1152: NO 2022 FIELD */),
          a2: "DataCenterId",
          a3: ParamInt);
      }
      RBX::Time::nowFastSec(this: v40); /*0x1067ca728*/
      this->playStartTime /* +56 */ = v42; /*0x1067ca72d*/
      this->playResolved /* +55 */ = 0; /*0x1067ca732*/
      RBX::AvatarLoadMetrics::logGameJoined(a1: (char *)this + 328 /* +328: NO 2022 FIELD */, a2: v28); /*0x1067ca743*/
      if ( (v52 & 1) != 0 ) /*0x1067ca74c*/
        operator delete(a1: v53); /*0x1067ca752*/
      if ( (v50 & 1) != 0 ) /*0x1067ca75b*/
        operator delete(a1: v51); /*0x1067ca761*/
    }
  }
}

// Address: 0x1067ca8fa | Name: __ZZN3RBX16PlayerConfigurer22connectPlayerToSignalsENSt3__110shared_ptrINS_6PlayerEEEEN3$_1D1Ev
__int64 __fastcall RBX::PlayerConfigurer::connectPlayerToSignals(std::shared_ptr<RBX::Player>)::$_1::~$_1(__int64 a1)
{
  std::__shared_weak_count *v2; // rdi
  __int64 result; // rax
  std::__shared_weak_count *v4; // rdi

  v2 = *(std::__shared_weak_count **)(a1 + 24); /*0x1067ca903*/
  if ( v2 != nullptr ) /*0x1067ca90a*/
    result = std::__shared_weak_count::__release_weak(this: v2); /*0x1067ca90c*/
  v4 = *(std::__shared_weak_count **)(a1 + 8); /*0x1067ca911*/
  if ( v4 != nullptr ) /*0x1067ca91c*/
    return std::__shared_weak_count::__release_weak(this: v4); /*0x1067ca920*/
  return result; /*0x1067ca91e*/
}

// Address: 0x1067ca928 | Name: __ZZN3RBX16PlayerConfigurer22connectPlayerToSignalsENSt3__110shared_ptrINS_6PlayerEEEEN3$_2D1Ev
__int64 __fastcall RBX::PlayerConfigurer::connectPlayerToSignals(std::shared_ptr<RBX::Player>)::$_2::~$_2(__int64 a1)
{
  std::__shared_weak_count *v2; // rdi
  __int64 result; // rax
  std::__shared_weak_count *v4; // rdi

  v2 = *(std::__shared_weak_count **)(a1 + 24); /*0x1067ca931*/
  if ( v2 != nullptr ) /*0x1067ca938*/
    result = std::__shared_weak_count::__release_weak(this: v2); /*0x1067ca93a*/
  v4 = *(std::__shared_weak_count **)(a1 + 8); /*0x1067ca93f*/
  if ( v4 != nullptr ) /*0x1067ca94a*/
    return std::__shared_weak_count::__release_weak(this: v4); /*0x1067ca94e*/
  return result; /*0x1067ca94c*/
}

// Address: 0x1067ca956 | Name: __ZZN3RBX16PlayerConfigurer22connectPlayerToSignalsENSt3__110shared_ptrINS_6PlayerEEEEN3$_4D1Ev
__int64 __fastcall RBX::PlayerConfigurer::connectPlayerToSignals(std::shared_ptr<RBX::Player>)::$_4::~$_4(__int64 a1)
{
  std::__shared_weak_count *v2; // rdi
  __int64 result; // rax
  std::__shared_weak_count *v4; // rdi

  v2 = *(std::__shared_weak_count **)(a1 + 24); /*0x1067ca95f*/
  if ( v2 != nullptr ) /*0x1067ca966*/
    result = std::__shared_weak_count::__release_weak(this: v2); /*0x1067ca968*/
  v4 = *(std::__shared_weak_count **)(a1 + 8); /*0x1067ca96d*/
  if ( v4 != nullptr ) /*0x1067ca978*/
    return std::__shared_weak_count::__release_weak(this: v4); /*0x1067ca97c*/
  return result; /*0x1067ca97a*/
}

// Address: 0x1067caa04 | Name: __ZN3RBX16PlayerConfigurer22setSkipSessionTrackingEb
void __fastcall RBX::PlayerConfigurer::setSkipSessionTracking(RBX::PlayerConfigurer *this, char a2)
{
  this->userJoinDataOverrides._Mypair._Myval2._Bx /* +80 */ = a2; /*0x1067caa08*/
}

// Address: 0x1067caa0e | Name: __ZN3RBX16PlayerConfigurer25setIdleTimerResetBehaviorENS_22IdleTimerResetBehaviorE
void __fastcall RBX::PlayerConfigurer::setIdleTimerResetBehavior(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 904) = a2; /*0x1067caa12*/
}

// Address: 0x1067caa1a | Name: __ZN3RBX16PlayerConfigurer29setVoiceEnabledIfUserEligibleEb
void __fastcall RBX::PlayerConfigurer::setVoiceEnabledIfUserEligible(RBX::PlayerConfigurer *this, char a2)
{
  *((_BYTE *)this + 82) /* +82: NO 2022 FIELD */ = a2; /*0x1067caa1e*/
}

// Address: 0x1067caa24 | Name: __ZN3RBX16PlayerConfigurer24reportLocalAvatarMetricsERNS_13AvatarMetricsENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEd
void __fastcall RBX::PlayerConfigurer::reportLocalAvatarMetrics(__int64 a1, __int64 a2, __int128 *a3, double a4)
{
  __int64 v6; // r15
  RBX::Time *v7; // rdi
  double v8; // xmm0_8
  RBX::Analytics::InfluxDb::Points *v9; // r15
  double v10; // xmm0_8
  double v11; // xmm0_8
  double v12; // xmm0_8
  double v13; // xmm1_8
  double v14; // xmm0_8
  double v15; // xmm0_8
  double v16; // xmm0_8
  double v17; // xmm0_8
  double v18; // xmm0_8
  double v19; // xmm0_8
  double v20; // xmm1_8
  double v21; // xmm0_8
  double v22; // xmm0_8
  double v23; // xmm0_8
  double v24; // xmm0_8
  double v25; // xmm0_8
  double v26; // xmm0_8
  double v27; // xmm0_8
  __int64 v28; // rax
  double v29; // xmm0_8
  double v30; // xmm0_8
  __int64 v31; // rax
  double v32; // xmm0_8
  __int64 v33; // rax
  __int64 v34; // rax
  __int64 v35; // rax
  __int64 v36; // rax
  __int64 v37; // rax
  __int64 v38; // rax
  __int64 v39; // rax
  double v40; // xmm0_8
  double v41; // xmm0_8
  double v42; // xmm0_8
  double v43; // xmm0_8
  double v44; // xmm0_8
  __int128 *v45; // rdx
  __int64 v46; // rcx
  __int64 v47; // rdi
  __int64 v48; // rsi
  double v49; // xmm1_8
  __int64 v50; // rax
  __int64 *v51; // rax
  __int64 v52; // r14
  __int64 v53; // rdx
  __int64 v54; // rcx
  __int64 v55; // rdi
  __int64 v56; // rsi
  __int64 v57; // r14
  __int64 v58; // rdi
  __int64 v59; // r14
  __int64 v60; // rdi
  __int64 v61; // r15
  __int64 v62; // rax
  __int64 v63; // rdi
  __int64 v64; // r14
  __int64 v65; // r14
  const char *v66; // rsi
  double v67; // rcx
  unsigned int v68; // r15d
  size_t v69; // r15
  char *v70; // r14
  const void *v71; // rsi
  unsigned int v72; // edx
  __int64 v73; // r12
  __int64 v74; // rsi
  __int64 v75; // rdx
  __int64 v76; // rax
  __int64 v77; // rdx
  __int64 v78; // rdi
  __int64 v79; // rsi
  char *v80; // rcx
  char *v81; // r14
  __int64 v82; // r15
  const char *v83; // rsi
  __int64 v84; // rdx
  unsigned __int8 *v85; // r15
  double v86; // r14
  unsigned int v87; // edx
  __int64 v88; // rdx
  __int64 v89; // r14
  __int64 v90; // rdx
  __int64 v91; // rcx
  __int64 v92; // rdi
  __int64 v93; // rsi
  const char *v94; // rsi
  unsigned __int8 *v95; // rsi
  unsigned int v96; // edx
  __int64 v97; // rdx
  unsigned __int8 *v98; // rsi
  __int64 v99; // r14
  __int64 v100; // rdx
  __int64 v101; // rcx
  __int64 v102; // rdi
  __int64 v103; // rsi
  const char *v104; // rsi
  char *v105; // rsi
  __int64 v106; // rdx
  __int64 v107; // r15
  char v108; // r14
  std::__shared_weak_count *v109; // r14
  const char *v110; // r14
  __int64 v111; // r15
  const char *v112; // r14
  __int64 v113; // r14
  const char *v114; // rsi
  __int64 *v115; // rdx
  const char *v116; // r14
  __int64 v117; // r15
  __int64 v118; // rdx
  const char *v119; // rsi
  double v120; // r15
  _QWORD *v121; // rax
  __int64 v122; // r13
  __int64 v123; // r12
  unsigned __int64 v124; // r14
  __int64 v125; // r15
  __int64 v126; // r12
  const char *v127; // rsi
  char *v128; // rsi
  void *v129; // rdx
  __int64 v130; // r12
  char v131; // al
  __int64 v132; // r15
  __int64 v133; // rsi
  char *v134; // rdx
  __int64 v135; // rdx
  __int64 v136; // rcx
  __int64 v137; // r12
  __int64 i; // r13
  unsigned int v139; // edx
  const void *v140; // r15
  __int64 v141; // rsi
  __int64 v142; // rdx
  unsigned int v143; // eax
  size_t v144; // rdx
  __int64 v145; // rsi
  unsigned int v146; // ecx
  __int64 v147; // rdi
  const void *v148; // rsi
  RBX::Analytics::InfluxDb::Points *v149; // rbx
  __int64 v150; // rax
  _BYTE v151[48]; // [rsp+0h] [rbp-2F0h] BYREF
  std::__shared_weak_count *v152; // [rsp+30h] [rbp-2C0h]
  _QWORD v153[4]; // [rsp+40h] [rbp-2B0h] BYREF
  int v154; // [rsp+60h] [rbp-290h]
  _BYTE v155[40]; // [rsp+70h] [rbp-280h] BYREF
  _BYTE v156[16]; // [rsp+98h] [rbp-258h] BYREF
  void *v157; // [rsp+A8h] [rbp-248h]
  _BYTE v158[16]; // [rsp+B0h] [rbp-240h] BYREF
  void *v159; // [rsp+C0h] [rbp-230h]
  const void *v160; // [rsp+C8h] [rbp-228h]
  void *__dst[4]; // [rsp+D0h] [rbp-220h] BYREF
  __int128 v162; // [rsp+F0h] [rbp-200h]
  _BYTE v163[25]; // [rsp+100h] [rbp-1F0h] BYREF
  __int128 v164; // [rsp+120h] [rbp-1D0h]
  char v165; // [rsp+130h] [rbp-1C0h]
  __int128 v166; // [rsp+138h] [rbp-1B8h]
  char v167; // [rsp+148h] [rbp-1A8h]
  char v168; // [rsp+150h] [rbp-1A0h]
  __int64 v169; // [rsp+158h] [rbp-198h]
  __int128 v170; // [rsp+160h] [rbp-190h] BYREF
  char *v171; // [rsp+170h] [rbp-180h]
  void *v172[14]; // [rsp+180h] [rbp-170h] BYREF
  __int128 v173; // [rsp+1F0h] [rbp-100h] BYREF
  void *v174; // [rsp+200h] [rbp-F0h]
  __int128 v175; // [rsp+210h] [rbp-E0h] BYREF
  void *v176; // [rsp+220h] [rbp-D0h]
  __int128 v177; // [rsp+230h] [rbp-C0h] BYREF
  void *v178; // [rsp+240h] [rbp-B0h]
  __int128 v179; // [rsp+250h] [rbp-A0h] BYREF
  void *v180; // [rsp+260h] [rbp-90h]
  __int128 v181; // [rsp+270h] [rbp-80h] BYREF
  void *v182; // [rsp+280h] [rbp-70h]
  __int128 v183; // [rsp+290h] [rbp-60h] BYREF
  void *v184; // [rsp+2A0h] [rbp-50h]
  double v185; // [rsp+2A8h] [rbp-48h]
  __int64 *v186; // [rsp+2B0h] [rbp-40h]
  __int64 v187; // [rsp+2B8h] [rbp-38h]
  RBX::Analytics::InfluxDb::Points *v188; // [rsp+2C0h] [rbp-30h]

  v185 = a4; /*0x1067caa38*/
  v187 = a2; /*0x1067caa40*/
  v6 = RBX::Time::epochTimeMs(this: (RBX::Time *)a1); /*0x1067caa4c*/
  RBX::Time::nowFastSec(this: v7); /*0x1067caa4f*/
  RBX::Time::createISO8601Timestamp( /*0x1067caa79*/
    this: (RBX::Time *)v156,
    a2: v6 - (unsigned int)(int)((v8 - *(double *)(a1 + 168)) * 1000.0));
  v188 = (RBX::Analytics::InfluxDb::Points *)(a1 + 1152); /*0x1067caa8c*/
  RBX::Analytics::InfluxDb::Points::addPoint(a1: a1 + 1152, a2: "userClickTimestamp", a3: v156); /*0x1067caa93*/
  if ( (v156[0] & 1) != 0 ) /*0x1067caa9f*/
    operator delete(a1: v157); /*0x1067caaa8*/
  v9 = v188; /*0x1067caabc*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "PlayerConfigureTime", a3: *(double *)(a1 + 208)); /*0x1067caac3*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: v9, a2: "AvatarConfigureTime", a3: *(double *)(a1 + 256)); /*0x1067caada*/
  RBX::Analytics::InfluxDb::Points::addPoint(this: v9, a2: "AvatarR15", a3: (double)*(char *)(v187 + 393)); /*0x1067caafb*/
  v10 = *(double *)(a1 + 240); /*0x1067cab00*/
  if ( v10 > 0.0 ) /*0x1067cab10*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "GameJoinTime", a3: v10); /*0x1067cab1d*/
  v11 = *(double *)(a1 + 232); /*0x1067cab26*/
  if ( v11 > 0.0 ) /*0x1067cab32*/
  {
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "GameLoadTime", a3: v11); /*0x1067cab3f*/
    v11 = *(double *)(a1 + 232); /*0x1067cab44*/
  }
  v12 = v11 - *(double *)(a1 + 224); /*0x1067cab4c*/
  if ( v12 > 0.0 ) /*0x1067cab5c*/
  {
    v13 = (*(double *)(a1 + 400) - *(double *)(a1 + 384)) / v12; /*0x1067cab6e*/
    if ( v13 > 0.0 ) /*0x1067cab76*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "GameLoadBandwidth", a3: v13); /*0x1067cab87*/
  }
  v14 = *(double *)(a1 + 216); /*0x1067cab90*/
  if ( v14 > 0.0 ) /*0x1067cab9c*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "ConnectTime", a3: v14); /*0x1067caba9*/
  v15 = *(double *)(a1 + 184); /*0x1067cabae*/
  if ( v15 > 0.0 ) /*0x1067cabbe*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "StartGameTime", a3: v15); /*0x1067cabcb*/
  v16 = *(double *)(a1 + 200); /*0x1067cabd4*/
  if ( v16 > 0.0 ) /*0x1067cabe0*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "FetchedJoinScriptTime", a3: v16); /*0x1067cabed*/
  v17 = *(double *)(a1 + 192); /*0x1067cabf2*/
  if ( v17 > 0.0 ) /*0x1067cac02*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "PlaceLauncherStartTime", a3: v17); /*0x1067cac0f*/
  v18 = *(double *)(a1 + 176); /*0x1067cac18*/
  if ( v18 > 0.0 ) /*0x1067cac24*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "VideoAdFinishedTime", a3: v18); /*0x1067cac31*/
  v19 = *(double *)(a1 + 224); /*0x1067cac36*/
  if ( v19 > 0.0 ) /*0x1067cac46*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "ReceivedGlobalsTime", a3: v19); /*0x1067cac53*/
  v20 = *(double *)(a1 + 168); /*0x1067cac5c*/
  v21 = *(double *)(a1 + 448) - v20; /*0x1067cac6c*/
  if ( v21 > 0.0 ) /*0x1067cac74*/
  {
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "InitSolidTexturesTime", a3: v21); /*0x1067cac81*/
    v20 = *(double *)(a1 + 168); /*0x1067cac86*/
  }
  v22 = *(double *)(a1 + 248) - v20; /*0x1067cac96*/
  if ( v22 > 0.0 ) /*0x1067caca2*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "PlayerMovedTime", a3: v22); /*0x1067cacaf*/
  v23 = *(double *)(v187 + 96); /*0x1067cacbc*/
  if ( v23 > 0.0 ) /*0x1067cacc5*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarCreateTime", a3: v23); /*0x1067cacd2*/
  v24 = *(double *)(v187 + 232); /*0x1067cacdb*/
  if ( v24 > 0.0 ) /*0x1067caceb*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarLoadTime", a3: v24); /*0x1067cacf8*/
  v25 = *(double *)(v187 + 160); /*0x1067cad05*/
  if ( v25 > 0.0 ) /*0x1067cad11*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarClusterStartTime", a3: v25); /*0x1067cad1e*/
  v26 = *(double *)(v187 + 168); /*0x1067cad27*/
  if ( v26 > 0.0 ) /*0x1067cad37*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarClusterEndTime", a3: v26); /*0x1067cad44*/
  v27 = *(double *)(v187 + 184); /*0x1067cad51*/
  if ( v27 > 0.0 ) /*0x1067cad5d*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarLastUpdateEntityTime", a3: v27); /*0x1067cad6a*/
  v28 = *(_QWORD *)(v187 + 176); /*0x1067cad73*/
  if ( v28 > 0 ) /*0x1067cad7d*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarClusterUpdateCnt", a3: (double)(int)v28); /*0x1067cad92*/
  v29 = *(double *)(v187 + 192); /*0x1067cad9b*/
  if ( v29 > 0.0 ) /*0x1067cadab*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarTextureStartTime", a3: v29); /*0x1067cadb8*/
  v30 = *(double *)(v187 + 200); /*0x1067cadc5*/
  if ( v30 > 0.0 ) /*0x1067cadd1*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarTextureEndTime", a3: v30); /*0x1067cadde*/
  v31 = *(_QWORD *)(v187 + 208); /*0x1067cade7*/
  if ( v31 > 0 ) /*0x1067cadf1*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarTextureUpdateCnt", a3: (double)(int)v31); /*0x1067cae06*/
  v32 = *(double *)(v187 + 216); /*0x1067cae0f*/
  if ( v32 > 0.0 ) /*0x1067cae1f*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarLastTextureRenderJobTime", a3: v32); /*0x1067cae2c*/
  v33 = *(_QWORD *)(v187 + 288); /*0x1067cae35*/
  if ( v33 > 0 ) /*0x1067cae3f*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarHttpCacheHitCnt", a3: (double)(int)v33); /*0x1067cae54*/
  v34 = *(_QWORD *)(v187 + 296); /*0x1067cae5d*/
  if ( v34 > 0 ) /*0x1067cae67*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarHttpCacheMissCnt", a3: (double)(int)v34); /*0x1067cae7c*/
  v35 = *(_QWORD *)(v187 + 304); /*0x1067cae85*/
  if ( v35 > 0 ) /*0x1067cae8f*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarHttpCacheHitBytes", a3: (double)(int)v35); /*0x1067caea4*/
  v36 = *(_QWORD *)(v187 + 312); /*0x1067caead*/
  if ( v36 > 0 ) /*0x1067caeb7*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarHttpCacheMissBytes", a3: (double)(int)v36); /*0x1067caecc*/
  v37 = *(_QWORD *)(v187 + 320); /*0x1067caed5*/
  if ( v37 > 0 ) /*0x1067caedf*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarAssetsByteSize", a3: (double)(int)v37); /*0x1067caef4*/
  v38 = *(_QWORD *)(v187 + 328); /*0x1067caefd*/
  if ( v38 > 0 ) /*0x1067caf07*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarTexturesByteSize", a3: (double)(int)v38); /*0x1067caf1c*/
  v39 = *(_QWORD *)(v187 + 336); /*0x1067caf25*/
  if ( v39 > 0 ) /*0x1067caf2f*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarAnimationsByteSize", a3: (double)(int)v39); /*0x1067caf44*/
  v40 = *(double *)(v187 + 248); /*0x1067caf4d*/
  if ( v40 > 0.0 ) /*0x1067caf5d*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarTotalClientAssetRequestTime", a3: v40); /*0x1067caf6a*/
  v41 = *(double *)(v187 + 256); /*0x1067caf77*/
  if ( v41 > 0.0 ) /*0x1067caf83*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarTotalAssetResolveTime", a3: v41); /*0x1067caf90*/
  v42 = *(double *)(v187 + 264); /*0x1067caf99*/
  if ( v42 > 0.0 ) /*0x1067cafa9*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarFirstAssetQueuedTime", a3: v42); /*0x1067cafb6*/
  v43 = *(double *)(v187 + 272); /*0x1067cafc3*/
  if ( v43 > 0.0 ) /*0x1067cafcf*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarLastAssetDeliveredTime", a3: v43); /*0x1067cafdc*/
  v44 = *(double *)(v187 + 280); /*0x1067cafe5*/
  if ( v44 > 0.0 ) /*0x1067caff5*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "AvatarAllAssetNetworkingTime", a3: v44); /*0x1067cb002*/
  v183 = 0; /*0x1067cb00b*/
  v184 = nullptr; /*0x1067cb012*/
  v180 = nullptr; /*0x1067cb01d*/
  v179 = 0; /*0x1067cb021*/
  std::string::operator=(a1: &v179, a2: a1 + 24LL * *(int *)(a1 + 440) + 888); /*0x1067cb03b*/
  std::string::operator=(a1: &v183, a2: a1 + 912 + 24LL * *(int *)(a1 + 440)); /*0x1067cb05a*/
  if ( (v183 & 1) != 0 ) /*0x1067cb063*/
  {
    std::string::__init_copy_ctor_external(a1: &v173, a2: v184, a3: *((_QWORD *)&v183 + 1)); /*0x1067cb08e*/
  }
  else
  {
    v174 = v184; /*0x1067cb069*/
    v173 = v183; /*0x1067cb075*/
  }
  RBX::Analytics::InfluxDb::Points::addPoint(a1: v188, a2: "CurrentJoinPhase", a3: &v173); /*0x1067cb0a5*/
  if ( (v173 & 1) != 0 ) /*0x1067cb0b1*/
    operator delete(a1: v174); /*0x1067cb0ba*/
  if ( (v179 & 1) != 0 ) /*0x1067cb0c6*/
  {
    std::string::__init_copy_ctor_external(a1: &v175, a2: v180, a3: *((_QWORD *)&v179 + 1)); /*0x1067cb0fd*/
  }
  else
  {
    v176 = v180; /*0x1067cb0cf*/
    v175 = v179; /*0x1067cb0de*/
  }
  RBX::Analytics::InfluxDb::Points::addPoint(a1: v188, a2: "LastCompleteJoinPhase", a3: &v175); /*0x1067cb114*/
  if ( (v175 & 1) != 0 ) /*0x1067cb120*/
    operator delete(a1: v176); /*0x1067cb129*/
  if ( v185 > 0.0 ) /*0x1067cb13b*/
  {
    if ( (*(_BYTE *)a3 & 1) != 0 ) /*0x1067cb145*/
    {
      std::string::__init_copy_ctor_external(a1: &v177, a2: *((_QWORD *)a3 + 2), a3: *((_QWORD *)a3 + 1)); /*0x1067cb170*/
    }
    else
    {
      v178 = *((void **)a3 + 2); /*0x1067cb14b*/
      v177 = *a3; /*0x1067cb157*/
    }
    RBX::Analytics::InfluxDb::Points::addPoint(a1: v188, a2: "JoinFailureError", a3: &v177); /*0x1067cb187*/
    if ( (v177 & 1) != 0 ) /*0x1067cb193*/
      operator delete(a1: v178); /*0x1067cb19c*/
    v49 = v185 - *(double *)(a1 + 168); /*0x1067cb1a6*/
    if ( v49 > 0.0 ) /*0x1067cb1b6*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: "TimeToFailure", a3: v49); /*0x1067cb1c7*/
  }
  memset(v153, 0, sizeof(v153)); /*0x1067cb1d8*/
  v154 = 1065353216; /*0x1067cb1e0*/
  v50 = *(_QWORD *)(a1 + 456); /*0x1067cb1ea*/
  if ( v50 != 0 ) /*0x1067cb1f4*/
  {
    v51 = *(__int64 **)(v50 + 16); /*0x1067cb1fa*/
    if ( v51 != nullptr ) /*0x1067cb201*/
    {
      do /*0x1067cb20e*/
      {
        v186 = v51; /*0x1067cb20e*/
        v52 = v51[5]; /*0x1067cb212*/
        if ( RBX::Reflection::Type::getSingleton<std::string>(a1: v47, a2: v48, a3: v45, a4: v46) == v52 ) /*0x1067cb21e*/
        {
          if ( (v186[2] & 1) != 0 ) /*0x1067cb6c9*/
            v111 = v186[4]; /*0x1067cb6e1*/
          else
            v111 = (__int64)v186 + 17; /*0x1067cb6cb*/
          v113 = v186[5]; /*0x1067cb6e5*/
          if ( RBX::Reflection::Type::getSingleton<std::string>(a1: v55, a2: v56, a3: v53, a4: v54) != v113 ) /*0x1067cb6f1*/
LABEL_245:
            RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v114); /*0x1067cbb84*/
          v115 = v186 + 7; /*0x1067cb6ff*/
          if ( v186[6] == 0 ) /*0x1067cb706*/
            v115 = nullptr; /*0x1067cb706*/
          RBX::Analytics::InfluxDb::Points::addPoint(a1: v188, a2: v111, a3: v115); /*0x1067cb711*/
        }
        else
        {
          v57 = v186[5]; /*0x1067cb228*/
          if ( RBX::Reflection::Type::getSingleton<bool>(a1: v55) == v57 ) /*0x1067cb234*/
          {
            if ( (v186[2] & 1) != 0 ) /*0x1067cb6d9*/
              v112 = (const char *)v186[4]; /*0x1067cb732*/
            else
              v112 = (char *)v186 + 17; /*0x1067cb6db*/
            v117 = v186[5]; /*0x1067cb736*/
            if ( RBX::Reflection::Type::getSingleton<bool>(a1: v58) != v117 ) /*0x1067cb742*/
              goto LABEL_245; /*0x1067cb742*/
            RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: v112, a3: *((_BYTE *)v186 + 56)); /*0x1067cb757*/
          }
          else
          {
            v59 = v186[5]; /*0x1067cb23e*/
            if ( RBX::Reflection::Type::getSingleton<long long>(a1: v58) == v59 ) /*0x1067cb24a*/
            {
              if ( (v186[2] & 1) != 0 ) /*0x1067cb723*/
                v116 = (const char *)v186[4]; /*0x1067cb8ab*/
              else
                v116 = (char *)v186 + 17; /*0x1067cb729*/
              v132 = v186[5]; /*0x1067cb8af*/
              if ( RBX::Reflection::Type::getSingleton<long long>(a1: v60) != v132 ) /*0x1067cb8bb*/
                goto LABEL_245; /*0x1067cb8bb*/
              RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: v116, a3: v186[7]); /*0x1067cb8d0*/
            }
            else
            {
              v61 = v186[5]; /*0x1067cb254*/
              v62 = RBX::Reflection::Type::getSingleton<std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>(a1: v60); /*0x1067cb258*/
              v64 = v186[5]; /*0x1067cb261*/
              if ( v62 == v61 ) /*0x1067cb268*/
              {
                if ( RBX::Reflection::Type::getSingleton<std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>(a1: v63) != v64 ) /*0x1067cb769*/
                  RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v119); /*0x1067cbb9d*/
                *(_QWORD *)&v120 = v186 + 7; /*0x1067cb777*/
                if ( v186[6] == 0 ) /*0x1067cb77e*/
                  v120 = 0.0; /*0x1067cb77e*/
                std::string::basic_string[abi:ne200100]<0>(a1: &v170, a2: "", a3: v118, a4: v186); /*0x1067cb790*/
                v121 = **(_QWORD ***)&v120; /*0x1067cb795*/
                v122 = ***(_QWORD ***)&v120; /*0x1067cb798*/
                if ( *(_QWORD *)(**(_QWORD **)&v120 + 8LL) != v122 ) /*0x1067cb79f*/
                {
                  v123 = 16; /*0x1067cb7a5*/
                  v124 = 0; /*0x1067cb7ab*/
                  v185 = v120; /*0x1067cb7ae*/
                  do /*0x1067cb88f*/
                  {
                    if ( v124 != 0 ) /*0x1067cb7b5*/
                    {
                      std::string::append(a1: &v170, a2: ","); /*0x1067cb7c5*/
                      v121 = **(_QWORD ***)&v120; /*0x1067cb7ca*/
                      v122 = ***(_QWORD ***)&v120; /*0x1067cb7cd*/
                    }
                    if ( 0xCCCCCCCCCCCCCCCDLL * ((v121[1] - v122) >> 4) <= v124 ) /*0x1067cb7ec*/
                      std::vector<RBX::Reflection::Variant>::__throw_out_of_range[abi:ne200100](); /*0x1067cbb4d*/
                    v125 = v123; /*0x1067cb7f2*/
                    v126 = *(_QWORD *)(v122 + v123 - 16); /*0x1067cb7f5*/
                    if ( RBX::Reflection::Type::getSingleton<long long>(a1: v47) != v126 ) /*0x1067cb802*/
                      RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v127); /*0x1067cbb46*/
                    std::to_string(a1: (__int64)__dst); /*0x1067cb814*/
                    if ( ((__int64)__dst[0] & 1) != 0 ) /*0x1067cb823*/
                    {
                      v128 = (char *)__dst[2]; /*0x1067cb825*/
                      v129 = __dst[1]; /*0x1067cb82c*/
                    }
                    else
                    {
                      v129 = (void *)(LOBYTE(__dst[0]) >> 1); /*0x1067cb835*/
                      v128 = (char *)__dst + 1; /*0x1067cb837*/
                    }
                    v130 = v125; /*0x1067cb83e*/
                    std::string::append(a1: &v170, a2: v128, a3: v129); /*0x1067cb848*/
                    v120 = v185; /*0x1067cb84d*/
                    if ( ((__int64)__dst[0] & 1) != 0 ) /*0x1067cb858*/
                      operator delete(a1: __dst[2]); /*0x1067cb861*/
                    ++v124; /*0x1067cb866*/
                    v121 = **(_QWORD ***)&v120; /*0x1067cb869*/
                    v122 = ***(_QWORD ***)&v120; /*0x1067cb86c*/
                    v123 = v130 + 80; /*0x1067cb888*/
                  }
                  while ( v124 < 0xCCCCCCCCCCCCCCCDLL * ((*(_QWORD *)(**(_QWORD **)&v120 + 8LL) - v122) >> 4) ); /*0x1067cb88f*/
                }
                v131 = v170 & 1; /*0x1067cb89e*/
                if ( (v170 & 1) != 0 ) /*0x1067cb8a0*/
                  v46 = *((_QWORD *)&v170 + 1); /*0x1067cb8a2*/
                else
                  v46 = (unsigned __int8)v170 >> 1; /*0x1067cb8da*/
                v45 = &v170; /*0x1067cb8df*/
                if ( v46 != 0 ) /*0x1067cb8e6*/
                {
                  if ( (v186[2] & 1) != 0 ) /*0x1067cb8f0*/
                    v133 = v186[4]; /*0x1067cb8f8*/
                  else
                    v133 = (__int64)v186 + 17; /*0x1067cb8f2*/
                  RBX::Analytics::InfluxDb::Points::addPoint(a1: v188, a2: v133, a3: &v170); /*0x1067cb900*/
                  v131 = v170 & 1; /*0x1067cb90b*/
                }
                if ( v131 != 0 ) /*0x1067cb90f*/
                  operator delete(a1: v171); /*0x1067cb918*/
              }
              else if ( RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::ValueTable const>>(a1: v63) == v64 ) /*0x1067cb276*/
              {
                v65 = v186[5]; /*0x1067cb280*/
                if ( RBX::Reflection::Type::getSingleton<std::shared_ptr<RBX::Reflection::ValueTable const>>(a1: v47) != v65 ) /*0x1067cb28c*/
                  RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v66); /*0x1067cbbad*/
                RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::WriterT( /*0x1067cb29e*/
                  a1: v155,
                  a2: 0);
                RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::startObject(a1: v155); /*0x1067cb2a6*/
                v67 = *(double *)(v186[7] + 16); /*0x1067cb2b3*/
                if ( v67 != 0.0 ) /*0x1067cb2ba*/
                {
                  v160 = (char *)v186 + 17; /*0x1067cb2c8*/
                  do /*0x1067cb698*/
                  {
                    v68 = *((unsigned __int8 *)v186 + 16); /*0x1067cb2d3*/
                    if ( (v68 & 1) != 0 ) /*0x1067cb2dc*/
                      v69 = v186[3]; /*0x1067cb2de*/
                    else
                      v69 = v68 >> 1; /*0x1067cb2e4*/
                    v185 = v67; /*0x1067cb2e7*/
                    std::string::basic_string[abi:ne200100](a1: __dst, a2: v69 + 1); /*0x1067cb2fd*/
                    v70 = (char *)__dst + 1; /*0x1067cb309*/
                    if ( ((__int64)__dst[0] & 1) != 0 ) /*0x1067cb30c*/
                      v70 = (char *)__dst[2]; /*0x1067cb30e*/
                    if ( v69 != 0 ) /*0x1067cb318*/
                    {
                      v71 = v160; /*0x1067cb322*/
                      if ( (v186[2] & 1) != 0 ) /*0x1067cb329*/
                        v71 = (const void *)v186[4]; /*0x1067cb32f*/
                      memmove(__dst: v70, __src: v71, __len: v69); /*0x1067cb339*/
                    }
                    *(_WORD *)&v70[v69] = 47; /*0x1067cb33e*/
                    v72 = *(unsigned __int8 *)(*(_QWORD *)&v185 + 16LL); /*0x1067cb349*/
                    v73 = *(_QWORD *)&v185 + 17LL; /*0x1067cb34d*/
                    if ( (v72 & 1) != 0 ) /*0x1067cb354*/
                    {
                      v74 = *(_QWORD *)(*(_QWORD *)&v185 + 32LL); /*0x1067cb356*/
                      v75 = *(_QWORD *)(*(_QWORD *)&v185 + 24LL); /*0x1067cb35a*/
                    }
                    else
                    {
                      v75 = v72 >> 1; /*0x1067cb360*/
                      v74 = *(_QWORD *)&v185 + 17LL; /*0x1067cb362*/
                    }
                    v76 = std::string::append(a1: __dst, a2: v74, a3: v75); /*0x1067cb36c*/
                    v80 = *(char **)(v76 + 16); /*0x1067cb371*/
                    v171 = v80; /*0x1067cb375*/
                    v170 = *(_OWORD *)v76; /*0x1067cb380*/
                    *(_OWORD *)v76 = 0; /*0x1067cb38c*/
                    *(_QWORD *)(v76 + 16) = 0; /*0x1067cb390*/
                    v81 = (char *)&v170 + 1; /*0x1067cb39f*/
                    if ( (v170 & 1) != 0 ) /*0x1067cb3a6*/
                      v81 = v171; /*0x1067cb3a8*/
                    v82 = *(_QWORD *)(*(_QWORD *)&v185 + 40LL); /*0x1067cb3b3*/
                    if ( RBX::Reflection::Type::getSingleton<std::string>(a1: v78, a2: v79, a3: v77, a4: v80) != v82 ) /*0x1067cb3bf*/
                      RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v83); /*0x1067cbb7d*/
                    v84 = *(_QWORD *)(*(_QWORD *)&v185 + 48LL); /*0x1067cb3c9*/
                    v85 = (unsigned __int8 *)(*(_QWORD *)&v185 + 56LL); /*0x1067cb3cd*/
                    if ( v84 != 0 ) /*0x1067cb3d4*/
                      v84 = *(_QWORD *)&v185 + 56LL; /*0x1067cb3d4*/
                    RBX::Analytics::InfluxDb::Points::addPoint(a1: v188, a2: v81, a3: v84); /*0x1067cb3df*/
                    if ( (v170 & 1) != 0 ) /*0x1067cb3eb*/
                      operator delete(a1: v171); /*0x1067cb3f4*/
                    v86 = v185; /*0x1067cb400*/
                    if ( ((__int64)__dst[0] & 1) != 0 ) /*0x1067cb404*/
                      operator delete(a1: __dst[2]); /*0x1067cb40d*/
                    v87 = *(unsigned __int8 *)(*(_QWORD *)&v86 + 16LL); /*0x1067cb412*/
                    if ( (v87 & 1) != 0 ) /*0x1067cb41a*/
                    {
                      v73 = *(_QWORD *)(*(_QWORD *)&v86 + 32LL); /*0x1067cb41c*/
                      v88 = *(_QWORD *)(*(_QWORD *)&v86 + 24LL); /*0x1067cb420*/
                    }
                    else
                    {
                      v88 = v87 >> 1; /*0x1067cb426*/
                    }
                    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::string( /*0x1067cb432*/
                      a1: v155,
                      a2: v73,
                      a3: v88);
                    v89 = *(_QWORD *)(*(_QWORD *)&v185 + 40LL); /*0x1067cb43b*/
                    if ( RBX::Reflection::Type::getSingleton<std::string>(a1: v92, a2: v93, a3: v90, a4: v91) != v89 ) /*0x1067cb447*/
                      RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v94); /*0x1067cbb5d*/
                    v95 = *(unsigned __int8 **)(*(_QWORD *)&v185 + 48LL); /*0x1067cb451*/
                    if ( v95 != nullptr ) /*0x1067cb458*/
                      v95 = v85; /*0x1067cb458*/
                    v96 = *v95; /*0x1067cb45c*/
                    if ( (v96 & 1) != 0 ) /*0x1067cb462*/
                    {
                      v97 = *((_QWORD *)v95 + 1); /*0x1067cb464*/
                      v98 = *((unsigned __int8 **)v95 + 2); /*0x1067cb468*/
                    }
                    else
                    {
                      v98 = v95 + 1; /*0x1067cb46e*/
                      v97 = v96 >> 1; /*0x1067cb471*/
                    }
                    RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::string( /*0x1067cb47a*/
                      a1: v155,
                      a2: v98,
                      a3: v97);
                    v99 = *(_QWORD *)(*(_QWORD *)&v185 + 40LL); /*0x1067cb483*/
                    if ( RBX::Reflection::Type::getSingleton<std::string>(a1: v102, a2: v103, a3: v100, a4: v101) != v99 ) /*0x1067cb48f*/
                      RBX::throw_runtime_error(this: (RBX *)"Variant cast failed", a2: v104); /*0x1067cbb6d*/
                    if ( *(_QWORD *)(*(_QWORD *)&v185 + 48LL) == 0 ) /*0x1067cb4a0*/
                      v85 = nullptr; /*0x1067cb4a0*/
                    if ( (*v85 & 1) != 0 ) /*0x1067cb4a8*/
                    {
                      std::string::__init_copy_ctor_external( /*0x1067cb4ca*/
                        a1: &v181,
                        a2: *((_QWORD *)v85 + 2),
                        a3: *((_QWORD *)v85 + 1));
                    }
                    else
                    {
                      v182 = *((void **)v85 + 2); /*0x1067cb4ae*/
                      v181 = *(_OWORD *)v85; /*0x1067cb4b7*/
                    }
                    std::basic_regex<char,std::regex_traits<char>>::basic_regex[abi:ne200100]( /*0x1067cb4df*/
                      a1: v151,
                      a2: "[-\\d\\.]+",
                      a3: 0);
                    if ( (v181 & 1) != 0 ) /*0x1067cb4f2*/
                    {
                      v105 = (char *)v182; /*0x1067cb4f4*/
                      v106 = *((_QWORD *)&v181 + 1); /*0x1067cb4f8*/
                    }
                    else
                    {
                      v106 = (unsigned __int8)v181 >> 1; /*0x1067cb4fe*/
                      v105 = (char *)&v181 + 1; /*0x1067cb500*/
                    }
                    std::regex_iterator<std::__wrap_iter<char const*>,char,std::regex_traits<char>>::regex_iterator( /*0x1067cb514*/
                      a1: &v170,
                      a2: v105,
                      a3: &v105[v106],
                      a4: v151,
                      a5: 0);
                    v107 = *(_QWORD *)&v185 + 16LL; /*0x1067cb51d*/
                    while ( 1 ) /*0x1067cb525*/
                    {
                      v164 = 0; /*0x1067cb525*/
                      v165 = 0; /*0x1067cb52c*/
                      v167 = 0; /*0x1067cb52f*/
                      v166 = 0; /*0x1067cb532*/
                      v168 = 0; /*0x1067cb537*/
                      v169 = 0; /*0x1067cb53d*/
                      memset(v163, 0, sizeof(v163)); /*0x1067cb54d*/
                      v162 = 0; /*0x1067cb552*/
                      memset(__dst, 0, 28); /*0x1067cb55f*/
                      v108 = std::regex_iterator<std::__wrap_iter<char const*>,char,std::regex_traits<char>>::operator==( /*0x1067cb576*/
                               a1: &v170,
                               a2: __dst);
                      if ( (_QWORD)v162 != 0 ) /*0x1067cb583*/
                      {
                        *((_QWORD *)&v162 + 1) = v162; /*0x1067cb585*/
                        operator delete(a1: (void *)v162); /*0x1067cb58c*/
                      }
                      if ( v108 != 0 ) /*0x1067cb594*/
                        break; /*0x1067cb594*/
                      std::match_results<std::__wrap_iter<char const*>>::str[abi:ne200100](a1: v158, a2: v172, a3: 0); /*0x1067cb5ad*/
                      std::pair<std::string const,std::string>::pair[abi:ne200100]<std::string,std::string const&,0>( /*0x1067cb5c9*/
                        a1: __dst,
                        a2: v158,
                        a3: v107);
                      std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::pair<std::string const,std::string>>( /*0x1067cb5db*/
                        a1: v153,
                        a2: __dst,
                        a3: __dst);
                      if ( ((__int64)__dst[3] & 1) != 0 ) /*0x1067cb5e7*/
                        operator delete(a1: *((void **)&v162 + 1)); /*0x1067cb5f0*/
                      if ( ((__int64)__dst[0] & 1) != 0 ) /*0x1067cb5fc*/
                        operator delete(a1: __dst[2]); /*0x1067cb605*/
                      if ( (v158[0] & 1) != 0 ) /*0x1067cb611*/
                        operator delete(a1: v159); /*0x1067cb61a*/
                      std::regex_iterator<std::__wrap_iter<char const*>,char,std::regex_traits<char>>::operator++(a1: &v170); /*0x1067cb622*/
                    }
                    if ( v172[0] != nullptr ) /*0x1067cb636*/
                    {
                      v172[1] = v172[0]; /*0x1067cb638*/
                      operator delete(a1: v172[0]); /*0x1067cb63f*/
                    }
                    v109 = v152; /*0x1067cb644*/
                    if ( v152 != nullptr /*0x1067cb660*/
                      && _InterlockedExchangeAdd64((volatile signed __int64 *)v152 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
                    {
                      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v109 + 16LL))(a1: v109); /*0x1067cb668*/
                      std::__shared_weak_count::__release_weak(this: v109); /*0x1067cb66e*/
                    }
                    std::locale::~locale(this: (std::locale *)v151); /*0x1067cb67a*/
                    if ( (v181 & 1) != 0 ) /*0x1067cb683*/
                      operator delete(a1: v182); /*0x1067cb689*/
                    v67 = **(double **)&v185; /*0x1067cb692*/
                  }
                  while ( **(_QWORD **)&v185 != 0 ); /*0x1067cb698*/
                }
                RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::endObject(a1: v155); /*0x1067cb6a5*/
                if ( (v186[2] & 1) != 0 ) /*0x1067cb6b2*/
                  v110 = (const char *)v186[4]; /*0x1067cb91f*/
                else
                  v110 = (char *)v186 + 17; /*0x1067cb6b8*/
                RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::str( /*0x1067cb931*/
                  a1: &v170,
                  a2: v155);
                v134 = (char *)&v170 + 1; /*0x1067cb93d*/
                if ( (v170 & 1) != 0 ) /*0x1067cb944*/
                  v134 = v171; /*0x1067cb946*/
                RBX::Analytics::InfluxDb::Points::addPoint(this: v188, a2: v110, a3: v134); /*0x1067cb954*/
                if ( (v170 & 1) != 0 ) /*0x1067cb960*/
                  operator delete(a1: v171); /*0x1067cb969*/
                RBX::json::detail::WriterT<rapidjson110::GenericStringBuffer<rapidjson110::UTF8<char>,RBX::json::TrackedAllocator>>::~WriterT(a1: v155); /*0x1067cb975*/
              }
            }
          }
        }
        v51 = (__int64 *)*v186; /*0x1067cb97e*/
      }
      while ( *v186 != 0 ); /*0x1067cb20e*/
    }
  }
  std::string::basic_string[abi:ne200100]<0>(a1: &v170, a2: "", a3: v45, a4: v46); /*0x1067cb98a*/
  v137 = *(_QWORD *)(v187 + 344); /*0x1067cb9a1*/
  for ( i = *(_QWORD *)(v187 + 352); v137 != i; v137 += 296 )
  {
    v139 = *(unsigned __int8 *)(v137 + 8); /*0x1067cb9c6*/
    v140 = (const void *)(v137 + 9); /*0x1067cb9cc*/
    if ( (v139 & 1) != 0 ) /*0x1067cb9d4*/
    {
      v141 = *(_QWORD *)(v137 + 24); /*0x1067cb9d6*/
      v142 = *(_QWORD *)(v137 + 16); /*0x1067cb9db*/
    }
    else
    {
      v142 = v139 >> 1; /*0x1067cb9e2*/
      v141 = v137 + 9; /*0x1067cb9e4*/
    }
    std::string::append(a1: &v170, a2: v141, a3: v142); /*0x1067cb9ea*/
    v143 = *(unsigned __int8 *)(v137 + 8); /*0x1067cb9ef*/
    if ( (v143 & 1) != 0 ) /*0x1067cb9f7*/
      v144 = *(_QWORD *)(v137 + 16); /*0x1067cb9f9*/
    else
      v144 = v143 >> 1; /*0x1067cba02*/
    v145 = *(_QWORD *)(v187 + 352); /*0x1067cba08*/
    v146 = *(unsigned __int8 *)(v145 - 288); /*0x1067cba0f*/
    if ( (v146 & 1) != 0 ) /*0x1067cba19*/
      v147 = *(_QWORD *)(v145 - 280); /*0x1067cba1b*/
    else
      v147 = v146 >> 1; /*0x1067cba26*/
    if ( v144 == v147 )
    {
      if ( (v143 & 1) != 0 ) /*0x1067cba2f*/
        v140 = *(const void **)(v137 + 24); /*0x1067cba31*/
      v148 = (v146 & 1) != 0 ? *(const void **)(v145 - 272) : (const void *)(v145 - 287);
      if ( memcmp(__s1: v140, __s2: v148, __n: v144) == 0 ) /*0x1067cba55*/
        continue; /*0x1067cba55*/
    }
    std::string::append(a1: &v170, a2: ","); /*0x1067cba5d*/
  }
  v149 = v188; /*0x1067cba7b*/
  if ( (v170 & 1) != 0 ) /*0x1067cba7f*/
    v150 = *((_QWORD *)&v170 + 1); /*0x1067cba81*/
  else
    v150 = (unsigned __int8)v170 >> 1; /*0x1067cba8a*/
  if ( v150 != 0 ) /*0x1067cba8f*/
    RBX::Analytics::InfluxDb::Points::addPoint(a1: v188, a2: "AssetIds", a3: &v170); /*0x1067cbaa2*/
  std::string::basic_string[abi:ne200100]<0>(a1: __dst, a2: "ClientJoin_All", a3: v135, a4: v136); /*0x1067cbab5*/
  RBX::Analytics::InfluxDb::Points::report( /*0x1067cbacc*/
    a1: v149,
    a2: __dst,
    a3: (unsigned int)DFInt::JoinAllInfluxHundredthsPercentage,
    a4: 0);
  if ( ((__int64)__dst[0] & 1) != 0 ) /*0x1067cbad8*/
    operator delete(a1: __dst[2]); /*0x1067cbae1*/
  if ( (v170 & 1) != 0 ) /*0x1067cbaed*/
    operator delete(a1: v171); /*0x1067cbaf6*/
  std::__hash_table<std::__hash_value_type<std::string,std::string>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,std::string>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,std::string>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,std::string>>>::~__hash_table(a1: v153); /*0x1067cbb02*/
  if ( (v179 & 1) != 0 ) /*0x1067cbb0e*/
    operator delete(a1: v180); /*0x1067cbb17*/
  if ( (v183 & 1) != 0 ) /*0x1067cbb20*/
    operator delete(a1: v184); /*0x1067cbb26*/
}

// Address: 0x1067cbdf8 | Name: __ZN3RBX16PlayerConfigurer18getJoinPhaseStringERNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES8_
__int64 __fastcall RBX::PlayerConfigurer::getJoinPhaseString(__int64 a1, __int64 a2, __int64 a3)
{
  std::string::operator=(a1: a3, a2: a1 + 24LL * *(int *)(a1 + 440) + 888); /*0x1067cbe1e*/
  return std::string::operator=(a1: a2, a2: a1 + 24LL * *(int *)(a1 + 440) + 912); /*0x1067cbe3c*/
}

// Address: 0x1067cbe48 | Name: __ZN3RBX16PlayerConfigurer18onAvatarCompletionEPNS_8HumanoidEb
void __fastcall RBX::PlayerConfigurer::onAvatarCompletion(RBX::PlayerConfigurer *this, RBX::Humanoid *a2, bool a3)
{
  int v6; // ecx
  RBX::Time *v7; // rdi
  int v8; // r8d
  int v9; // r9d
  unsigned int v10; // eax
  double v11; // xmm0_8
  __int64 v12; // rdx
  __int64 v13; // rcx
  __int64 v14; // rdx
  __int64 v15; // rcx
  RBX *v16; // rdi
  __int64 v17; // rdx
  __int64 v18; // rcx
  char v19; // al
  _QWORD *v20; // rax
  int v21; // r15d
  RBX *v22; // rdi
  int PairIntValue; // r14d
  const RBX::Url *v24; // rsi
  char isRobloxChineseDomain; // r13
  int v26; // r14d
  int v27; // eax
  const char *v28; // rdx
  _QWORD *v29; // r13
  signed __int64 v30; // r13
  unsigned __int64 v31; // rsi
  __int64 v32; // rax
  __int64 v33; // rdx
  __int64 v34; // r14
  char *v35; // rax
  _WORD *v36; // rax
  __int64 v37; // r15
  void *v38; // r14
  void *v39; // r13
  void *v40; // r15
  RBX *v41; // rax
  void *v42; // rcx
  const char *v43; // rdx
  double v44; // xmm1_8
  double *v45; // r13
  signed __int64 v46; // r13
  unsigned __int64 v47; // rsi
  __int64 v48; // rax
  __int64 v49; // rdx
  __int64 v50; // r14
  __int64 v51; // r15
  void *v52; // r14
  void *v53; // r13
  void *v54; // r15
  RBX *v55; // rax
  void *v56; // rcx
  const char *v57; // rdx
  double v58; // xmm1_8
  double *v59; // r13
  signed __int64 v60; // r13
  unsigned __int64 v61; // rsi
  __int64 v62; // rax
  __int64 v63; // rdx
  __int64 v64; // r14
  __int64 v65; // r15
  void *v66; // r14
  void *v67; // r13
  void *v68; // r15
  RBX *v69; // rax
  void *v70; // rcx
  const char *v71; // rdx
  double v72; // xmm1_8
  double *v73; // r13
  signed __int64 v74; // r13
  unsigned __int64 v75; // rsi
  __int64 v76; // rax
  __int64 v77; // rdx
  __int64 v78; // r14
  __int64 v79; // r15
  void *v80; // r14
  void *v81; // r13
  void *v82; // r15
  RBX *v83; // rax
  void *v84; // rcx
  const char *v85; // rdx
  double v86; // xmm1_8
  double *v87; // r13
  signed __int64 v88; // r13
  unsigned __int64 v89; // rsi
  __int64 v90; // rax
  __int64 v91; // rdx
  __int64 v92; // r14
  __int64 v93; // r15
  void *v94; // r14
  void *v95; // r13
  void *v96; // r15
  RBX *v97; // rax
  void *v98; // rcx
  const char *v99; // rdx
  double v100; // xmm1_8
  double *v101; // r13
  signed __int64 v102; // r13
  unsigned __int64 v103; // rsi
  __int64 v104; // rax
  __int64 v105; // rdx
  __int64 v106; // r14
  __int64 v107; // r15
  void *v108; // r14
  void *v109; // r13
  void *v110; // r15
  RBX *v111; // rax
  void *v112; // rcx
  const char *v113; // rdx
  double v114; // xmm1_8
  double *v115; // r13
  signed __int64 v116; // r13
  unsigned __int64 v117; // rsi
  __int64 v118; // rax
  __int64 v119; // rdx
  __int64 v120; // r14
  __int64 v121; // r15
  void *v122; // r14
  void *v123; // r13
  void *v124; // r15
  RBX *v125; // rax
  void *v126; // rcx
  const char *v127; // rdx
  double v128; // xmm1_8
  double *v129; // r13
  signed __int64 v130; // r13
  unsigned __int64 v131; // rsi
  __int64 v132; // rax
  __int64 v133; // rdx
  __int64 v134; // r14
  __int64 v135; // r15
  void *v136; // r14
  void *v137; // r13
  void *v138; // r15
  RBX *v139; // rax
  void *v140; // rcx
  const char *v141; // rdx
  __int64 v142; // rdx
  __int64 v143; // rcx
  double v144; // xmm1_8
  double *v145; // r13
  signed __int64 v146; // r13
  unsigned __int64 v147; // rsi
  __int64 v148; // rax
  __int64 v149; // rdx
  __int64 v150; // r14
  __int64 v151; // r15
  void *v152; // r14
  void *v153; // r13
  void *v154; // r15
  RBX *v155; // rax
  void *v156; // rcx
  double *v157; // r15
  char *v158; // r14
  __int64 v159; // rdx
  __int64 v160; // rcx
  double v161; // xmm0_8
  _QWORD *v162; // r14
  __int64 v163; // rdx
  __int64 v164; // rcx
  _QWORD *v165; // r14
  __int64 v166; // rdx
  __int64 v167; // rcx
  _QWORD *v168; // r14
  __int64 v169; // rdx
  __int64 v170; // rcx
  _QWORD *v171; // r14
  __int64 v172; // rdx
  __int64 v173; // rcx
  _QWORD *v174; // r14
  __int64 v175; // rdx
  __int64 v176; // rcx
  _QWORD *v177; // r14
  __int64 v178; // rdx
  __int64 v179; // rcx
  _QWORD *v180; // r14
  __int64 v181; // rdx
  __int64 v182; // rcx
  _QWORD *v183; // r14
  void *v184; // r14
  const char *v185; // rdx
  __int64 v186; // rdx
  __int64 v187; // rcx
  double *v188; // r13
  signed __int64 v189; // r13
  unsigned __int64 v190; // rsi
  __int64 v191; // rax
  __int64 v192; // rdx
  __int64 v193; // r14
  __int64 v194; // r15
  void *v195; // r14
  void *v196; // r13
  void *v197; // r15
  RBX *v198; // rax
  void *v199; // rcx
  double *v200; // r14
  void *v201; // r14
  const char *v202; // rdx
  const char *v203; // r13
  const char *v204; // rcx
  __int64 v205; // rdi
  double v206; // xmm1_8
  double *v207; // r14
  signed __int64 v208; // r14
  unsigned __int64 v209; // rsi
  __int64 v210; // rax
  __int64 v211; // rdx
  __int64 v212; // r15
  __int64 v213; // r13
  void *v214; // r15
  void *v215; // r14
  void *v216; // r13
  RBX *v217; // rax
  void *v218; // rcx
  const char *v219; // rdx
  const char *v220; // rcx
  __int64 v221; // rdi
  double v222; // xmm1_8
  double *v223; // r14
  signed __int64 v224; // r14
  unsigned __int64 v225; // rsi
  __int64 v226; // rax
  __int64 v227; // rdx
  __int64 v228; // r15
  __int64 v229; // r13
  void *v230; // r15
  void *v231; // r14
  void *v232; // r13
  RBX *v233; // rax
  void *v234; // rcx
  const char *v235; // rdx
  const char *v236; // rcx
  __int64 v237; // rdi
  double v238; // xmm1_8
  double *v239; // r14
  signed __int64 v240; // r14
  unsigned __int64 v241; // rsi
  __int64 v242; // rax
  __int64 v243; // rdx
  __int64 v244; // r15
  __int64 v245; // r13
  void *v246; // r15
  void *v247; // r14
  void *v248; // r13
  RBX *v249; // rax
  void *v250; // rcx
  const char *v251; // rdx
  const char *v252; // rcx
  __int64 v253; // rdi
  double v254; // xmm1_8
  double *v255; // r14
  signed __int64 v256; // r14
  unsigned __int64 v257; // rsi
  __int64 v258; // rax
  __int64 v259; // rdx
  __int64 v260; // r15
  __int64 v261; // r13
  void *v262; // r15
  void *v263; // r14
  void *v264; // r13
  RBX *v265; // rax
  void *v266; // rcx
  const char *v267; // rdx
  const char *v268; // rcx
  __int64 v269; // rdi
  double v270; // xmm1_8
  double *v271; // r14
  signed __int64 v272; // r14
  unsigned __int64 v273; // rsi
  __int64 v274; // rax
  __int64 v275; // rdx
  __int64 v276; // r15
  __int64 v277; // r13
  void *v278; // r15
  void *v279; // r14
  void *v280; // r13
  RBX *v281; // rax
  void *v282; // rcx
  const char *v283; // rdx
  const char *v284; // rcx
  __int64 v285; // rdi
  double v286; // xmm1_8
  double *v287; // r14
  signed __int64 v288; // r14
  unsigned __int64 v289; // rsi
  __int64 v290; // rax
  __int64 v291; // rdx
  __int64 v292; // r15
  __int64 v293; // r13
  void *v294; // r15
  void *v295; // r14
  void *v296; // r13
  RBX *v297; // rax
  void *v298; // rcx
  const char *v299; // rdx
  const char *v300; // rcx
  __int64 v301; // rdi
  double v302; // xmm1_8
  double *v303; // r14
  signed __int64 v304; // r14
  unsigned __int64 v305; // rsi
  __int64 v306; // rax
  __int64 v307; // rdx
  __int64 v308; // r15
  __int64 v309; // r13
  void *v310; // r15
  void *v311; // r14
  void *v312; // r13
  RBX *v313; // rax
  void *v314; // rcx
  const char *v315; // rdx
  const char *v316; // rcx
  __int64 v317; // rdi
  double v318; // xmm1_8
  double *v319; // r14
  signed __int64 v320; // r14
  unsigned __int64 v321; // rsi
  __int64 v322; // rax
  __int64 v323; // rdx
  __int64 v324; // r15
  __int64 v325; // r13
  void *v326; // r15
  void *v327; // r14
  void *v328; // r13
  RBX *v329; // rax
  void *v330; // rcx
  const char *v331; // rdx
  double *v332; // r13
  signed __int64 v333; // r13
  unsigned __int64 v334; // rsi
  __int64 v335; // rax
  __int64 v336; // rdx
  __int64 v337; // r14
  __int64 v338; // r15
  void *v339; // r14
  void *v340; // r13
  void *v341; // r15
  RBX *v342; // rax
  void *v343; // rcx
  const char *v344; // rdx
  double v345; // xmm1_8
  double *v346; // r13
  signed __int64 v347; // r13
  unsigned __int64 v348; // rsi
  __int64 v349; // rax
  __int64 v350; // rdx
  __int64 v351; // r14
  __int64 v352; // r15
  void *v353; // r14
  void *v354; // r13
  void *v355; // r15
  RBX *v356; // rax
  void *v357; // rcx
  const char *v358; // rdx
  double v359; // xmm1_8
  double *v360; // r13
  signed __int64 v361; // r13
  unsigned __int64 v362; // rsi
  __int64 v363; // rax
  __int64 v364; // rdx
  __int64 v365; // r14
  __int64 v366; // r15
  void *v367; // r14
  void *v368; // r13
  void *v369; // r15
  RBX *v370; // rax
  void *v371; // rcx
  const char *v372; // rdx
  double v373; // xmm1_8
  double *v374; // r13
  signed __int64 v375; // r13
  unsigned __int64 v376; // rsi
  __int64 v377; // rax
  __int64 v378; // rdx
  __int64 v379; // r14
  __int64 v380; // r15
  void *v381; // r14
  void *v382; // r13
  void *v383; // r15
  RBX *v384; // rax
  void *v385; // rcx
  const char *v386; // rdx
  double v387; // xmm1_8
  double *v388; // r13
  signed __int64 v389; // r13
  unsigned __int64 v390; // rsi
  __int64 v391; // rax
  __int64 v392; // rdx
  __int64 v393; // r14
  __int64 v394; // r15
  void *v395; // r14
  void *v396; // r13
  void *v397; // r15
  RBX *v398; // rax
  void *v399; // rcx
  const char *v400; // rdx
  double v401; // xmm1_8
  double *v402; // r13
  signed __int64 v403; // r13
  unsigned __int64 v404; // rsi
  __int64 v405; // rax
  __int64 v406; // rdx
  __int64 v407; // r14
  __int64 v408; // r15
  void *v409; // r14
  void *v410; // r13
  void *v411; // r15
  RBX *v412; // rax
  void *v413; // rcx
  const char *v414; // rdx
  double v415; // xmm1_8
  double *v416; // r13
  signed __int64 v417; // r13
  unsigned __int64 v418; // rsi
  __int64 v419; // rax
  __int64 v420; // rdx
  __int64 v421; // r14
  __int64 v422; // r15
  void *v423; // r14
  void *v424; // r13
  void *v425; // r15
  RBX *v426; // rax
  void *v427; // rcx
  const char *v428; // rdx
  double v429; // xmm1_8
  double *v430; // r13
  signed __int64 v431; // r13
  unsigned __int64 v432; // rsi
  __int64 v433; // rax
  __int64 v434; // rdx
  __int64 v435; // r14
  __int64 v436; // r15
  void *v437; // r14
  void *v438; // r13
  void *v439; // r15
  RBX *v440; // rax
  void *v441; // rcx
  const char *v442; // rdx
  double v443; // xmm1_8
  double *v444; // r13
  signed __int64 v445; // r13
  unsigned __int64 v446; // rsi
  __int64 v447; // rax
  __int64 v448; // rdx
  __int64 v449; // r14
  __int64 v450; // r15
  void *v451; // r14
  void *v452; // r13
  void *v453; // r15
  RBX *v454; // rax
  void *v455; // rcx
  __int64 v456; // r14
  const char *v457; // r12
  __int64 v458; // rdi
  double *v459; // r12
  signed __int64 v460; // r12
  unsigned __int64 v461; // rcx
  __int64 v462; // rax
  __int64 v463; // rdx
  __int64 v464; // r14
  __int64 v465; // r15
  void *v466; // r14
  void *v467; // r12
  void *v468; // r15
  RBX *v469; // rax
  void *v470; // rcx
  __int64 v471; // rax
  int v472; // r15d
  int v473; // r14d
  const RBX::Url *v474; // rsi
  char v475; // r12
  int v476; // r14d
  int v477; // eax
  float v478; // xmm0_4
  __int64 v479; // rdx
  __int64 v480; // rcx
  float v481; // xmm1_4
  double *v482; // r15
  double *v483; // r15
  signed __int64 v484; // r15
  unsigned __int64 v485; // rdx
  unsigned __int64 v486; // rsi
  __int64 v487; // rax
  __int64 v488; // rdx
  __int64 v489; // r13
  __int64 v490; // r14
  void *v491; // r13
  void *v492; // r14
  RBX *v493; // rax
  void *v494; // rcx
  float v495; // xmm0_4
  float v496; // xmm0_4
  float v497; // xmm1_4
  void *v498; // r15
  __int64 v499; // rdx
  __int64 v500; // rcx
  float v501; // xmm1_4
  float v502; // xmm0_4
  float v503; // xmm1_4
  double *v504; // r13
  signed __int64 v505; // r13
  unsigned __int64 v506; // rdx
  unsigned __int64 v507; // rsi
  __int64 v508; // rax
  __int64 v509; // rdx
  __int64 v510; // r15
  __int64 v511; // r14
  void *v512; // r15
  void *v513; // r13
  void *v514; // r14
  RBX *v515; // rax
  void *v516; // rcx
  float v517; // xmm0_4
  float v518; // xmm1_4
  double *v519; // r15
  float v520; // xmm0_4
  float v521; // xmm1_4
  void *v522; // r15
  __int64 v523; // rax
  __int64 v524; // rdx
  __int64 v525; // rcx
  float v526; // xmm0_4
  double *v527; // r15
  void *v528; // r15
  __int64 v529; // rdx
  __int64 v530; // rcx
  float v531; // xmm1_4
  double *v532; // r15
  double *v533; // r15
  signed __int64 v534; // r15
  unsigned __int64 v535; // rdx
  unsigned __int64 v536; // rsi
  __int64 v537; // rax
  __int64 v538; // rdx
  __int64 v539; // r12
  __int64 v540; // r14
  void *v541; // r12
  void *v542; // r14
  RBX *v543; // rax
  void *v544; // rcx
  float v545; // xmm0_4
  float v546; // xmm1_4
  void *v547; // r15
  __int64 v548; // rdi
  float v549; // xmm1_4
  float v550; // xmm0_4
  float v551; // xmm1_4
  double *v552; // r12
  signed __int64 v553; // r12
  __int64 v554; // rsi
  unsigned __int64 v555; // rcx
  __int64 v556; // rax
  __int64 v557; // rdx
  __int64 v558; // r14
  __int64 v559; // r15
  void *v560; // r14
  void *v561; // r12
  void *v562; // r15
  RBX *v563; // rax
  void *v564; // rcx
  unsigned __int8 v565; // r15
  __int64 v566; // r14
  __int64 v567; // rdx
  __int64 v568; // rcx
  __int64 v569; // rdx
  __int64 v570; // rcx
  __int64 v571; // rdx
  __int64 v572; // rcx
  __int64 v573; // rdx
  __int64 v574; // rcx
  __int64 v575; // rdx
  __int64 v576; // rcx
  __int64 v577; // rdx
  __int64 v578; // rcx
  __int64 v579; // rdx
  __int64 v580; // rcx
  __int64 v581; // rdx
  __int64 v582; // rcx
  __int64 v583; // rdx
  __int64 v584; // rcx
  __int64 v585; // rdx
  __int64 v586; // rcx
  __int64 v587; // rdx
  __int64 v588; // rcx
  __int64 v589; // rdx
  __int64 v590; // rcx
  __int64 v591; // rdx
  __int64 v592; // rcx
  __int64 v593; // rdx
  __int64 v594; // rcx
  __int64 v595; // rdx
  __int64 v596; // rcx
  __int64 v597; // rdx
  __int64 v598; // rcx
  __int64 v599; // rdx
  __int64 v600; // rcx
  __int64 v601; // rdx
  __int64 v602; // rcx
  int v603; // eax
  unsigned __int64 v604; // rdx
  __int64 v605; // rcx
  __int64 v606; // rax
  RBX::Http *v607; // rdi
  __m128d v608; // xmm0
  __int64 v609; // rax
  RBX::Http *v610; // rdi
  __m128d v611; // xmm0
  __int64 v612; // rax
  int v613; // r15d
  int v614; // r14d
  __int64 v615; // rdx
  __int64 v616; // rcx
  __int64 v617; // rdx
  __int64 v618; // rcx
  __int64 v619; // rdx
  __int64 v620; // rcx
  __int64 v621; // rdx
  __int64 v622; // rcx
  __int64 v623; // rdx
  __int64 v624; // rcx
  __int64 v625; // rdx
  __int64 v626; // rcx
  __int64 v627; // rdx
  __int64 v628; // rcx
  __int64 v629; // rdi
  unsigned int v630; // eax
  unsigned int v631; // xmm0_4
  unsigned int v632; // xmm0_4
  unsigned int v633; // xmm0_4
  unsigned int v634; // xmm0_4
  unsigned int v635; // xmm0_4
  unsigned int v636; // xmm0_4
  unsigned int v637; // xmm0_4
  unsigned int v638; // xmm0_4
  float v639; // xmm0_4
  double v640; // xmm0_8
  unsigned int v641; // xmm0_4
  float v642; // xmm0_4
  double v643; // xmm0_8
  unsigned int v644; // xmm0_4
  float v645; // xmm0_4
  float v646; // xmm1_4
  unsigned int v647; // xmm0_4
  double v648; // xmm0_8
  double v649; // xmm0_8
  double v650; // xmm0_8
  double v651; // xmm0_8
  double v652; // xmm0_8
  double v653; // xmm0_8
  double v654; // xmm0_8
  double v655; // xmm0_8
  unsigned __int8 v656; // r14
  unsigned __int8 v657; // r15
  __int64 v658; // r13
  unsigned int v659; // r12d
  __int64 v660; // r14
  double v661; // xmm0_8
  _BYTE v662[40]; // [rsp+8h] [rbp-528h] BYREF
  void *v663; // [rsp+30h] [rbp-500h]
  char v664; // [rsp+38h] [rbp-4F8h]
  void *v665; // [rsp+48h] [rbp-4E8h]
  char v666; // [rsp+50h] [rbp-4E0h]
  void *v667; // [rsp+60h] [rbp-4D0h]
  __int64 v668; // [rsp+B0h] [rbp-480h]
  __int64 v669; // [rsp+D0h] [rbp-460h]
  char v670; // [rsp+160h] [rbp-3D0h] BYREF
  _QWORD v671[5]; // [rsp+178h] [rbp-3B8h] BYREF
  _BYTE v672[16]; // [rsp+1A0h] [rbp-390h] BYREF
  void *v673; // [rsp+1B0h] [rbp-380h]
  _BYTE v674[16]; // [rsp+1B8h] [rbp-378h] BYREF
  void *v675; // [rsp+1C8h] [rbp-368h]
  _BYTE v676[16]; // [rsp+1D0h] [rbp-360h] BYREF
  void *v677; // [rsp+1E0h] [rbp-350h]
  __int128 v678; // [rsp+1E8h] [rbp-348h] BYREF
  void *v679; // [rsp+1F8h] [rbp-338h]
  _BYTE v680[16]; // [rsp+200h] [rbp-330h] BYREF
  void *v681; // [rsp+210h] [rbp-320h]
  _BYTE v682[16]; // [rsp+218h] [rbp-318h] BYREF
  void *v683; // [rsp+228h] [rbp-308h]
  _BYTE v684[16]; // [rsp+230h] [rbp-300h] BYREF
  void *v685; // [rsp+240h] [rbp-2F0h]
  _BYTE v686[16]; // [rsp+248h] [rbp-2E8h] BYREF
  void *v687; // [rsp+258h] [rbp-2D8h]
  _BYTE v688[16]; // [rsp+260h] [rbp-2D0h] BYREF
  void *v689; // [rsp+270h] [rbp-2C0h]
  _BYTE v690[16]; // [rsp+278h] [rbp-2B8h] BYREF
  void *v691; // [rsp+288h] [rbp-2A8h]
  _BYTE v692[16]; // [rsp+290h] [rbp-2A0h] BYREF
  void *v693; // [rsp+2A0h] [rbp-290h]
  _BYTE v694[16]; // [rsp+2A8h] [rbp-288h] BYREF
  void *v695; // [rsp+2B8h] [rbp-278h]
  _BYTE v696[16]; // [rsp+2C0h] [rbp-270h] BYREF
  void *v697; // [rsp+2D0h] [rbp-260h]
  _BYTE v698[16]; // [rsp+2D8h] [rbp-258h] BYREF
  void *v699; // [rsp+2E8h] [rbp-248h]
  _BYTE v700[16]; // [rsp+2F0h] [rbp-240h] BYREF
  void *v701; // [rsp+300h] [rbp-230h]
  _BYTE v702[16]; // [rsp+308h] [rbp-228h] BYREF
  void *v703; // [rsp+318h] [rbp-218h]
  _BYTE v704[16]; // [rsp+320h] [rbp-210h] BYREF
  void *v705; // [rsp+330h] [rbp-200h]
  _BYTE v706[16]; // [rsp+338h] [rbp-1F8h] BYREF
  void *v707; // [rsp+348h] [rbp-1E8h]
  _BYTE v708[16]; // [rsp+350h] [rbp-1E0h] BYREF
  void *v709; // [rsp+360h] [rbp-1D0h]
  _BYTE v710[16]; // [rsp+368h] [rbp-1C8h] BYREF
  void *v711; // [rsp+378h] [rbp-1B8h]
  _BYTE v712[16]; // [rsp+380h] [rbp-1B0h] BYREF
  void *v713; // [rsp+390h] [rbp-1A0h]
  _BYTE v714[16]; // [rsp+398h] [rbp-198h] BYREF
  void *v715; // [rsp+3A8h] [rbp-188h]
  _BYTE v716[16]; // [rsp+3B0h] [rbp-180h] BYREF
  void *v717; // [rsp+3C0h] [rbp-170h]
  double v718; // [rsp+3C8h] [rbp-168h]
  __int64 v719[3]; // [rsp+3D0h] [rbp-160h] BYREF
  StartGameStatistics *v720; // [rsp+3E8h] [rbp-148h]
  __int128 v721; // [rsp+3F0h] [rbp-140h] BYREF
  RBX *v722; // [rsp+400h] [rbp-130h]
  void *v723; // [rsp+408h] [rbp-128h]
  void **v724; // [rsp+410h] [rbp-120h]
  void *v725; // [rsp+418h] [rbp-118h]
  char v726; // [rsp+420h] [rbp-110h]
  void *v727; // [rsp+430h] [rbp-100h]
  char v728; // [rsp+438h] [rbp-F8h]
  void *v729; // [rsp+448h] [rbp-E8h]
  char v730; // [rsp+450h] [rbp-E0h]
  void *v731; // [rsp+460h] [rbp-D0h]
  double *v732; // [rsp+478h] [rbp-B8h]
  double v733; // [rsp+480h] [rbp-B0h]
  double v734; // [rsp+488h] [rbp-A8h]
  __int64 v735[2]; // [rsp+490h] [rbp-A0h] BYREF
  void *v736; // [rsp+4A0h] [rbp-90h]
  __int128 v737; // [rsp+4B0h] [rbp-80h] BYREF
  void *v738; // [rsp+4C0h] [rbp-70h]
  double v739; // [rsp+4C8h] [rbp-68h]
  __int128 v740; // [rsp+4D0h] [rbp-60h] BYREF
  void *v741; // [rsp+4E0h] [rbp-50h]
  void *__src[2]; // [rsp+4F0h] [rbp-40h] BYREF
  void *v743[6]; // [rsp+500h] [rbp-30h] BYREF

  __bzero(a1: v662, a2: 395); /*0x1067cbe74*/
  v720 = (RBX::PlayerConfigurer *)((char *)this + 168 /* +168: NO 2022 FIELD */); /*0x1067cbe93*/
  RBX::AvatarLoadMetrics::buildAvatarMetrics( /*0x1067cbe9a*/
    this: (RBX::PlayerConfigurer *)((char *)this + 480 /* +480: NO 2022 FIELD */),
    a2: (RBX::AvatarMetrics *)v662,
    a3: a2,
    a4: a3,
    a5: (RBX::PlayerConfigurer *)((char *)this + 168 /* +168: NO 2022 FIELD */));
  RBX::AvatarLoadMetrics::logAvatarMetrics( /*0x1067cbeb4*/
    this: (RBX::PlayerConfigurer *)((char *)this + 480 /* +480: NO 2022 FIELD */),
    a2: (RBX::AvatarMetrics *)v662,
    a3: v720,
    a4: *((const RBX::DataModel **)this + 3));
  if ( !a3 ) /*0x1067cbebc*/
    goto LABEL_770; /*0x1067cbebc*/
  if ( FFlag::DebugPlayerConfigurerOthersMetrics == 0 ) /*0x1067cbec9*/
  {
    rbx::signals::connection::disconnect(this: (RBX::PlayerConfigurer *)((char *)this + 1672 /* +1672: NO 2022 FIELD */)); /*0x1067cbed2*/
    rbx::signals::connection::disconnect(this: (RBX::PlayerConfigurer *)((char *)this + 1680 /* +1680: NO 2022 FIELD */)); /*0x1067cbede*/
    rbx::signals::connection::disconnect(this: (RBX::PlayerConfigurer *)((char *)this + 1688 /* +1688: NO 2022 FIELD */)); /*0x1067cbeea*/
    rbx::signals::connection::disconnect(this: (RBX::PlayerConfigurer *)((char *)this + 1696 /* +1696: NO 2022 FIELD */)); /*0x1067cbef6*/
  }
  if ( (unsigned __int8)rbx::signals::connection::connected(this: (RBX::PlayerConfigurer *)((char *)this + 1728 /* +1728: NO 2022 FIELD */)) != 0 ) /*0x1067cbf0c*/
    rbx::signals::connection::disconnect(this: (RBX::PlayerConfigurer *)((char *)this + 1728 /* +1728: NO 2022 FIELD */)); /*0x1067cbf11*/
  rbx::signals::connection::disconnect(this: (RBX::PlayerConfigurer *)((char *)this + 1736 /* +1736: NO 2022 FIELD */)); /*0x1067cbf1d*/
  if ( FFlag::LogClientLoadToAvatarLoad == 1 ) /*0x1067cbf2c*/
  {
    v7 = *(RBX::Time **)&FLog::LogStepTimeAndNetworkUsage; /*0x1067cbf35*/
    v10 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067cbf3a*/
    if ( (unsigned __int8)FLog::LogStepTimeAndNetworkUsage >= 6u && BYTE1(FLog::LogStepTimeAndNetworkUsage) >= 3u ) /*0x1067cbf46*/
    {
      FLog::FastLog( /*0x1067cbf5a*/
        a1: *(_QWORD *)&FLog::LogStepTimeAndNetworkUsage,
        a2: qword_10D804018,
        a3: "[FLog::LogStepTimeAndNetworkUsage] Avatar Load",
        0);
      v7 = *(RBX::Time **)&FLog::LogStepTimeAndNetworkUsage; /*0x1067cbf5f*/
      v10 = (unsigned int)FLog::LogStepTimeAndNetworkUsage >> 8; /*0x1067cbf64*/
    }
    if ( (unsigned __int8)v7 >= 6u && (unsigned __int8)v10 >= 3u ) /*0x1067cbf70*/
    {
      LOBYTE(v6) = (unsigned __int8)v7 < 6u; /*0x1067cbf6b*/
      FLog::FastLogFormatted( /*0x1067cbf84*/
        a1: (_DWORD)v7,
        a2: qword_10D804018,
        a3: (unsigned int)"[FLog::LogStepTimeAndNetworkUsage] 0, 0, 0, 0",
        a4: v6,
        a5: v8,
        a6: v9);
    }
  }
  RBX::Time::nowFastSec(this: v7); /*0x1067cbf89*/
  *((double *)this + 36) /* +288: NO 2022 FIELD */ = v11 - *((double *)this + 21) /* +168: NO 2022 FIELD */; /*0x1067cbf96*/
  *((_DWORD *)this + 110) /* +440: NO 2022 FIELD */ = 9; /*0x1067cbf9e*/
  *((_QWORD *)this + 34) /* +272: NO 2022 FIELD */ = v668; /*0x1067cbfb7*/
  *((_QWORD *)this + 35) /* +280: NO 2022 FIELD */ = v669; /*0x1067cbfc7*/
  RBX::AvatarLoadMetrics::reportLocalAvatarMetrics( /*0x1067cbfd9*/
    this: (RBX::PlayerConfigurer *)((char *)this + 480 /* +480: NO 2022 FIELD */),
    a2: (RBX::AvatarMetrics *)v662,
    a3: v720);
  std::string::basic_string[abi:ne200100]<0>(a1: &v678, a2: "", a3: v12, a4: v13); /*0x1067cbfec*/
  RBX::PlayerConfigurer::reportLocalAvatarMetrics(a1: (__int64)this, a2: (__int64)v662, a3: &v678, a4: 0.0); /*0x1067cc006*/
  if ( (v678 & 1) != 0 ) /*0x1067cc012*/
    operator delete(a1: v679); /*0x1067cc01b*/
  v732 = (double *)((char *)this + 288 /* +288: NO 2022 FIELD */); /*0x1067cc027*/
  if ( FFlag::JoinTimeCounters == 1 ) /*0x1067cc035*/
  {
    *(_OWORD *)__src = 0; /*0x1067cc03f*/
    v743[0] = nullptr; /*0x1067cc044*/
    std::to_string(a1: (__int64)v735); /*0x1067cc05e*/
    v19 = *((_BYTE *)this + 304) /* +304: NO 2022 FIELD */; /*0x1067cc063*/
    if ( (v19 & 1) != 0 ) /*0x1067cc06b*/
    {
      if ( *((_QWORD *)this + 39) /* +312: NO 2022 FIELD */ == 11 ) /*0x1067cc082*/
      {
        v20 = *((_QWORD **)this + 40); /*0x1067cc084*/
LABEL_19:
        v18 = *v20 ^ 0x4774736575716552LL; /*0x1067cc08b*/
        v17 = v18 | *(_QWORD *)((char *)v20 + 3) ^ 0x656D614774736575LL; /*0x1067cc0a6*/
        if ( v17 != 0 ) /*0x1067cc0a9*/
          goto LABEL_20; /*0x1067cc0a9*/
        if ( (v735[0] & 1) != 0 ) /*0x1067cc2c7*/
        {
          if ( v735[1] == 6 ) /*0x1067cc2de*/
          {
            v35 = (char *)v736; /*0x1067cc2e0*/
LABEL_56:
            v18 = *(_DWORD *)v35 ^ 0x37393831u; /*0x1067cc2e7*/
            if ( ((unsigned int)v18 | *((unsigned __int16 *)v35 + 2) ^ 0x3730) == 0 ) /*0x1067cc2f9*/
              goto LABEL_58; /*0x1067cc2f9*/
          }
        }
        else if ( LOBYTE(v735[0]) == 12 ) /*0x1067cc2cb*/
        {
          v35 = (char *)v735 + 1; /*0x1067cc2cd*/
          goto LABEL_56; /*0x1067cc2d4*/
        }
        if ( FFlag::SendJoinTimesToDiag != 1 ) /*0x1067cc305*/
          goto LABEL_20; /*0x1067cc305*/
LABEL_58:
        if ( *((_BYTE *)this + 408) /* +408: NO 2022 FIELD */ != 0 ) /*0x1067cc312*/
          goto LABEL_20; /*0x1067cc312*/
        if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cc324*/
        {
          if ( *((_QWORD *)&RBX::Analytics::location + 1) != 2 ) /*0x1067d0a85*/
            goto LABEL_780; /*0x1067d0a85*/
          v36 = qword_10D50FFF8; /*0x1067d0a87*/
        }
        else
        {
          if ( (_BYTE)RBX::Analytics::location != 4 ) /*0x1067cc32d*/
            goto LABEL_780; /*0x1067cc32d*/
          v36 = (_WORD *)((char *)&RBX::Analytics::location + 1); /*0x1067cc333*/
        }
        if ( *v36 == 21333 ) /*0x1067d0a90*/
        {
          v656 = 1; /*0x1067d0d31*/
          if ( *((_BYTE *)this + 409) /* +409: NO 2022 FIELD */ == 1 /*0x1067d0d4f*/
            && std::operator==[abi:ne200100]<char,std::char_traits<char>,std::allocator<char>>(
                 a1: (unsigned __int8 *)this + 328,
                 a2: "4G") )
          {
            v657 = isIPhone5s_6s(); /*0x1067d0d61*/
            goto LABEL_782; /*0x1067d0d64*/
          }
LABEL_781:
          v657 = 0; /*0x1067d0a99*/
LABEL_782:
          v658 = *(_QWORD *)(*((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 840LL); /*0x1067d0a9c*/
          v659 = v656; /*0x1067d0aaf*/
          v660 = v657; /*0x1067d0ab3*/
          reportJoinStats( /*0x1067d0ad1*/
            a1: __src,
            a2: "VideoAdFinishedTime",
            a3: v659,
            a4: v657,
            a5: v658,
            a6: 1,
            a7: *((double *)this + 22) /* +176: NO 2022 FIELD */);
          reportJoinStats( /*0x1067d0af8*/
            a1: __src,
            a2: "StartGameTime",
            a3: v659,
            a4: v657,
            a5: v658,
            a6: 1,
            a7: *((double *)this + 23) /* +184: NO 2022 FIELD */);
          reportJoinStats( /*0x1067d0b1f*/
            a1: __src,
            a2: "PlaceLauncherStartTime",
            a3: v659,
            a4: v657,
            a5: v658,
            a6: 1,
            a7: *((double *)this + 24) /* +192: NO 2022 FIELD */);
          v661 = *((double *)this + 25) /* +200: NO 2022 FIELD */; /*0x1067d0b24*/
          if ( DFFlag::AvatarCompletionJoinStatsArgs == 1 ) /*0x1067d0b33*/
          {
            reportJoinStats(a1: __src, a2: "FetchedJoinScriptTime", a3: v659, a4: v657, a5: v658, a6: 0, a7: v661); /*0x1067d0b50*/
            reportJoinStats( /*0x1067d0b74*/
              a1: __src,
              a2: "PlayerConfigureTime",
              a3: v659,
              a4: v657,
              a5: v658,
              a6: 0,
              a7: *((double *)this + 26) /* +208: NO 2022 FIELD */);
            reportJoinStats( /*0x1067d0b98*/
              a1: __src,
              a2: "ConnectTime",
              a3: v659,
              a4: v657,
              a5: v658,
              a6: 0,
              a7: *((double *)this + 27) /* +216: NO 2022 FIELD */);
            reportJoinStats( /*0x1067d0bbc*/
              a1: __src,
              a2: "ReceivedGlobalsTime",
              a3: v659,
              a4: v657,
              a5: v658,
              a6: 0,
              a7: *((double *)this + 28) /* +224: NO 2022 FIELD */);
            reportJoinStats( /*0x1067d0be0*/
              a1: __src,
              a2: "GameLoadTime",
              a3: v659,
              a4: v657,
              a5: v658,
              a6: 0,
              a7: *((double *)this + 29) /* +232: NO 2022 FIELD */);
            reportJoinStats( /*0x1067d0c04*/
              a1: __src,
              a2: "GameJoinTime",
              a3: v659,
              a4: v657,
              a5: v658,
              a6: 0,
              a7: *((double *)this + 30) /* +240: NO 2022 FIELD */);
          }
          else
          {
            v657 = v658 != 0; /*0x1067d0c14*/
            reportJoinStats(a1: __src, a2: "FetchedJoinScriptTime", a3: v659, a4: v658 != 0, a5: v660, a6: 0, a7: v661); /*0x1067d0c2f*/
            reportJoinStats( /*0x1067d0c58*/
              a1: __src,
              a2: "PlayerConfigureTime",
              a3: v659,
              a4: v658 != 0,
              a5: v660,
              a6: 0,
              a7: *((double *)this + 26) /* +208: NO 2022 FIELD */);
            reportJoinStats( /*0x1067d0c81*/
              a1: __src,
              a2: "ConnectTime",
              a3: v659,
              a4: v658 != 0,
              a5: v660,
              a6: 0,
              a7: *((double *)this + 27) /* +216: NO 2022 FIELD */);
            reportJoinStats( /*0x1067d0caa*/
              a1: __src,
              a2: "ReceivedGlobalsTime",
              a3: v659,
              a4: v658 != 0,
              a5: v660,
              a6: 0,
              a7: *((double *)this + 28) /* +224: NO 2022 FIELD */);
            reportJoinStats( /*0x1067d0cd3*/
              a1: __src,
              a2: "GameLoadTime",
              a3: v659,
              a4: v658 != 0,
              a5: v660,
              a6: 0,
              a7: *((double *)this + 29) /* +232: NO 2022 FIELD */);
            reportJoinStats( /*0x1067d0cfc*/
              a1: __src,
              a2: "GameJoinTime",
              a3: v659,
              a4: v658 != 0,
              a5: v660,
              a6: 0,
              a7: *((double *)this + 30) /* +240: NO 2022 FIELD */);
            v658 = v660; /*0x1067d0d01*/
          }
          reportJoinStats(a1: __src, a2: "AvatarLoadTime", a3: v659, a4: v657, a5: v658, a6: 0, a7: *v732); /*0x1067d0d27*/
          goto LABEL_20; /*0x1067d0d2c*/
        }
LABEL_780:
        v656 = 0; /*0x1067d0a96*/
        goto LABEL_781; /*0x1067d0a96*/
      }
    }
    else if ( v19 == 22 ) /*0x1067cc06f*/
    {
      v20 = (_QWORD *)((char *)this + 305 /* +305: NO 2022 FIELD */); /*0x1067cc071*/
      goto LABEL_19; /*0x1067cc078*/
    }
LABEL_20:
    v21 = DFInt::SendJoinTimeDeltasToDiag_HundredthsPercentage; /*0x1067cc0af*/
    std::string::basic_string[abi:ne200100]<0>(a1: &v721, a2: ",", a3: v17, a4: v18); /*0x1067cc0c4*/
    PairIntValue = RBX::Network::getPairIntValue( /*0x1067cc0e6*/
                     a1: &RBX::Analytics::location,
                     a2: &DFString::SendJoinTimeDeltasHundPrecCountryOverride,
                     a3: &v721);
    if ( (v721 & 1) != 0 ) /*0x1067cc0f0*/
      operator delete(a1: v722); /*0x1067cc0f9*/
    if ( PairIntValue != -1 ) /*0x1067cc102*/
      v21 = PairIntValue; /*0x1067cc102*/
    RBX::GetBaseURL(this: v22); /*0x1067cc106*/
    RBX::Url::fromString(this: (RBX::Url *)&v721); /*0x1067cc12c*/
    isRobloxChineseDomain = RBX::Http::isRobloxChineseDomain(this: (RBX::Http *)&v721, a2: v24); /*0x1067cc13d*/
    if ( (v730 & 1) != 0 ) /*0x1067cc147*/
      operator delete(a1: v731); /*0x1067cc150*/
    if ( (v728 & 1) != 0 ) /*0x1067cc15c*/
      operator delete(a1: v729); /*0x1067cc165*/
    if ( (v726 & 1) != 0 ) /*0x1067cc171*/
      operator delete(a1: v727); /*0x1067cc17a*/
    if ( ((unsigned __int8)v723 & 1) != 0 ) /*0x1067cc186*/
      operator delete(a1: v725); /*0x1067cc18f*/
    if ( (v721 & 1) != 0 ) /*0x1067cc19b*/
      operator delete(a1: v722); /*0x1067cc1a4*/
    v26 = DFInt::SendJoinTimeDeltasToDiagLuobu_HundredthsPercentage; /*0x1067cc1a9*/
    v27 = rand(); /*0x1067cc1b0*/
    if ( v26 == -1 ) /*0x1067cc1b9*/
      v26 = v21; /*0x1067cc1b9*/
    if ( isRobloxChineseDomain == 0 ) /*0x1067cc1c0*/
      v26 = v21; /*0x1067cc1c0*/
    if ( v27 % 10000 < v26 ) /*0x1067cc1e5*/
    {
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cc1f0*/
        v28 = (const char *)qword_10D50FFF8; /*0x1067cc1f2*/
      else
        v28 = (char *)&RBX::Analytics::location + 1; /*0x1067cc1f9*/
      LOBYTE(v739) = isRobloxChineseDomain; /*0x1067cc1fe*/
      RBX::format(this: (RBX *)&v737, a2: "UserClickToStartGameTime_Country_%s", v28); /*0x1067cc20f*/
      v29 = __src[1]; /*0x1067cc229*/
      *(_QWORD *)&v733 = (char *)this + 184 /* +184: NO 2022 FIELD */; /*0x1067cc233*/
      if ( __src[1] >= v743[0] ) /*0x1067cc23a*/
      {
        v30 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cc26b*/
        if ( (unsigned __int64)(v30 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cc276*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0d7d*/
        v31 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cc282*/
        if ( v31 <= v30 + 1 ) /*0x1067cc289*/
          v31 = v30 + 1; /*0x1067cc289*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cc29a*/
          v31 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cc29a*/
        v724 = v743; /*0x1067cc2a2*/
        if ( v31 != 0 ) /*0x1067cc2ac*/
        {
          v32 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cc2b2*/
          v34 = v33; /*0x1067cc2b7*/
        }
        else
        {
          v32 = 0; /*0x1067cc33b*/
          v34 = 0; /*0x1067cc33d*/
        }
        v37 = v32 + 32 * v30; /*0x1067cc344*/
        v38 = (void *)(v32 + 32 * v34); /*0x1067cc34c*/
        v39 = (void *)(v37 + 32); /*0x1067cc356*/
        *(_QWORD *)(v37 + 16) = v738; /*0x1067cc35a*/
        *(_OWORD *)v37 = v737; /*0x1067cc362*/
        v737 = 0; /*0x1067cc36a*/
        v738 = nullptr; /*0x1067cc36e*/
        *(_QWORD *)(v37 + 24) = **(_QWORD **)&v733; /*0x1067cc381*/
        v40 = (void *)(v37 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cc392*/
        memcpy(__dst: v40, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cc398*/
        v41 = (RBX *)__src[0]; /*0x1067cc39d*/
        v42 = v743[0]; /*0x1067cc3a1*/
        __src[0] = v40; /*0x1067cc3a5*/
        *((_QWORD *)&v721 + 1) = v41; /*0x1067cc3b0*/
        __src[1] = v39; /*0x1067cc3b4*/
        v722 = v41; /*0x1067cc3b8*/
        v743[0] = v38; /*0x1067cc3bc*/
        v723 = v42; /*0x1067cc3c0*/
        *(_QWORD *)&v721 = v41; /*0x1067cc3c4*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cc3c7*/
        __src[1] = v39; /*0x1067cc3d0*/
        if ( (v737 & 1) != 0 ) /*0x1067cc3d4*/
          operator delete(a1: v738); /*0x1067cc3da*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v738; /*0x1067cc240*/
        *(_OWORD *)v29 = v737; /*0x1067cc248*/
        v29[3] = *((_QWORD *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067cc251*/
        __src[1] = v29 + 4; /*0x1067cc25b*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cc3e4*/
        v43 = (const char *)qword_10D50FFF8; /*0x1067cc3e6*/
      else
        v43 = (char *)&RBX::Analytics::location + 1; /*0x1067cc3ed*/
      RBX::format(this: (RBX *)&v737, a2: "StartGameToPlaceLauncherStartTime_Country_%s", v43); /*0x1067cc3ff*/
      v44 = *((double *)this + 24) /* +192: NO 2022 FIELD */ - *((double *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067cc40c*/
      v45 = (double *)__src[1]; /*0x1067cc414*/
      if ( __src[1] >= v743[0] ) /*0x1067cc41f*/
      {
        v734 = *((double *)this + 24) /* +192: NO 2022 FIELD */ - *((double *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067cc447*/
        v46 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cc456*/
        if ( (unsigned __int64)(v46 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cc46b*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0d87*/
        v47 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cc477*/
        if ( v47 <= v46 + 1 ) /*0x1067cc47e*/
          v47 = v46 + 1; /*0x1067cc47e*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cc48f*/
          v47 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cc48f*/
        v724 = v743; /*0x1067cc497*/
        if ( v47 != 0 ) /*0x1067cc4a1*/
        {
          v48 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cc4a3*/
          v50 = v49; /*0x1067cc4a8*/
        }
        else
        {
          v48 = 0; /*0x1067cc4ad*/
          v50 = 0; /*0x1067cc4af*/
        }
        v51 = v48 + 32 * v46; /*0x1067cc4b6*/
        v52 = (void *)(v48 + 32 * v50); /*0x1067cc4be*/
        v53 = (void *)(v51 + 32); /*0x1067cc4c8*/
        *(_QWORD *)(v51 + 16) = v738; /*0x1067cc4cc*/
        *(_OWORD *)v51 = v737; /*0x1067cc4d4*/
        v737 = 0; /*0x1067cc4dc*/
        v738 = nullptr; /*0x1067cc4e0*/
        *(double *)(v51 + 24) = v734; /*0x1067cc4f0*/
        v54 = (void *)(v51 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cc501*/
        memcpy(__dst: v54, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cc507*/
        v55 = (RBX *)__src[0]; /*0x1067cc50c*/
        v56 = v743[0]; /*0x1067cc510*/
        __src[0] = v54; /*0x1067cc514*/
        *((_QWORD *)&v721 + 1) = v55; /*0x1067cc51f*/
        __src[1] = v53; /*0x1067cc523*/
        v722 = v55; /*0x1067cc527*/
        v743[0] = v52; /*0x1067cc52b*/
        v723 = v56; /*0x1067cc52f*/
        *(_QWORD *)&v721 = v55; /*0x1067cc533*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cc536*/
        __src[1] = v53; /*0x1067cc53f*/
        if ( (v737 & 1) != 0 ) /*0x1067cc543*/
          operator delete(a1: v738); /*0x1067cc549*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v738; /*0x1067cc425*/
        *(_OWORD *)v45 = v737; /*0x1067cc42e*/
        v45[3] = v44; /*0x1067cc434*/
        __src[1] = v45 + 4; /*0x1067cc43e*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cc553*/
        v57 = (const char *)qword_10D50FFF8; /*0x1067cc555*/
      else
        v57 = (char *)&RBX::Analytics::location + 1; /*0x1067cc55c*/
      RBX::format(this: (RBX *)&v737, a2: "PlaceLauncherStartToFetchedScriptTime_Country_%s", v57); /*0x1067cc56e*/
      v58 = *((double *)this + 25) /* +200: NO 2022 FIELD */ - *((double *)this + 24) /* +192: NO 2022 FIELD */; /*0x1067cc57b*/
      v59 = (double *)__src[1]; /*0x1067cc583*/
      if ( __src[1] >= v743[0] ) /*0x1067cc58e*/
      {
        v734 = *((double *)this + 25) /* +200: NO 2022 FIELD */ - *((double *)this + 24) /* +192: NO 2022 FIELD */; /*0x1067cc5b6*/
        v60 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cc5c5*/
        if ( (unsigned __int64)(v60 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cc5da*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0d91*/
        v61 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cc5e6*/
        if ( v61 <= v60 + 1 ) /*0x1067cc5ed*/
          v61 = v60 + 1; /*0x1067cc5ed*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cc5fe*/
          v61 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cc5fe*/
        v724 = v743; /*0x1067cc606*/
        if ( v61 != 0 ) /*0x1067cc610*/
        {
          v62 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cc612*/
          v64 = v63; /*0x1067cc617*/
        }
        else
        {
          v62 = 0; /*0x1067cc61c*/
          v64 = 0; /*0x1067cc61e*/
        }
        v65 = v62 + 32 * v60; /*0x1067cc625*/
        v66 = (void *)(v62 + 32 * v64); /*0x1067cc62d*/
        v67 = (void *)(v65 + 32); /*0x1067cc637*/
        *(_QWORD *)(v65 + 16) = v738; /*0x1067cc63b*/
        *(_OWORD *)v65 = v737; /*0x1067cc643*/
        v737 = 0; /*0x1067cc64b*/
        v738 = nullptr; /*0x1067cc64f*/
        *(double *)(v65 + 24) = v734; /*0x1067cc65f*/
        v68 = (void *)(v65 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cc670*/
        memcpy(__dst: v68, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cc676*/
        v69 = (RBX *)__src[0]; /*0x1067cc67b*/
        v70 = v743[0]; /*0x1067cc67f*/
        __src[0] = v68; /*0x1067cc683*/
        *((_QWORD *)&v721 + 1) = v69; /*0x1067cc68e*/
        __src[1] = v67; /*0x1067cc692*/
        v722 = v69; /*0x1067cc696*/
        v743[0] = v66; /*0x1067cc69a*/
        v723 = v70; /*0x1067cc69e*/
        *(_QWORD *)&v721 = v69; /*0x1067cc6a2*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cc6a5*/
        __src[1] = v67; /*0x1067cc6ae*/
        if ( (v737 & 1) != 0 ) /*0x1067cc6b2*/
          operator delete(a1: v738); /*0x1067cc6b8*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v738; /*0x1067cc594*/
        *(_OWORD *)v59 = v737; /*0x1067cc59d*/
        v59[3] = v58; /*0x1067cc5a3*/
        __src[1] = v59 + 4; /*0x1067cc5ad*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cc6c2*/
        v71 = (const char *)qword_10D50FFF8; /*0x1067cc6c4*/
      else
        v71 = (char *)&RBX::Analytics::location + 1; /*0x1067cc6cb*/
      RBX::format(this: (RBX *)&v737, a2: "FetchedScriptToPlayerConfTime_Country_%s", v71); /*0x1067cc6dd*/
      v72 = *((double *)this + 26) /* +208: NO 2022 FIELD */ - *((double *)this + 25) /* +200: NO 2022 FIELD */; /*0x1067cc6ea*/
      v73 = (double *)__src[1]; /*0x1067cc6f2*/
      if ( __src[1] >= v743[0] ) /*0x1067cc6fd*/
      {
        v734 = *((double *)this + 26) /* +208: NO 2022 FIELD */ - *((double *)this + 25) /* +200: NO 2022 FIELD */; /*0x1067cc725*/
        v74 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cc734*/
        if ( (unsigned __int64)(v74 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cc749*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0d9b*/
        v75 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cc755*/
        if ( v75 <= v74 + 1 ) /*0x1067cc75c*/
          v75 = v74 + 1; /*0x1067cc75c*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cc76d*/
          v75 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cc76d*/
        v724 = v743; /*0x1067cc775*/
        if ( v75 != 0 ) /*0x1067cc77f*/
        {
          v76 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cc781*/
          v78 = v77; /*0x1067cc786*/
        }
        else
        {
          v76 = 0; /*0x1067cc78b*/
          v78 = 0; /*0x1067cc78d*/
        }
        v79 = v76 + 32 * v74; /*0x1067cc794*/
        v80 = (void *)(v76 + 32 * v78); /*0x1067cc79c*/
        v81 = (void *)(v79 + 32); /*0x1067cc7a6*/
        *(_QWORD *)(v79 + 16) = v738; /*0x1067cc7aa*/
        *(_OWORD *)v79 = v737; /*0x1067cc7b2*/
        v737 = 0; /*0x1067cc7ba*/
        v738 = nullptr; /*0x1067cc7be*/
        *(double *)(v79 + 24) = v734; /*0x1067cc7ce*/
        v82 = (void *)(v79 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cc7df*/
        memcpy(__dst: v82, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cc7e5*/
        v83 = (RBX *)__src[0]; /*0x1067cc7ea*/
        v84 = v743[0]; /*0x1067cc7ee*/
        __src[0] = v82; /*0x1067cc7f2*/
        *((_QWORD *)&v721 + 1) = v83; /*0x1067cc7fd*/
        __src[1] = v81; /*0x1067cc801*/
        v722 = v83; /*0x1067cc805*/
        v743[0] = v80; /*0x1067cc809*/
        v723 = v84; /*0x1067cc80d*/
        *(_QWORD *)&v721 = v83; /*0x1067cc811*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cc814*/
        __src[1] = v81; /*0x1067cc81d*/
        if ( (v737 & 1) != 0 ) /*0x1067cc821*/
          operator delete(a1: v738); /*0x1067cc827*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v738; /*0x1067cc703*/
        *(_OWORD *)v73 = v737; /*0x1067cc70c*/
        v73[3] = v72; /*0x1067cc712*/
        __src[1] = v73 + 4; /*0x1067cc71c*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cc831*/
        v85 = (const char *)qword_10D50FFF8; /*0x1067cc833*/
      else
        v85 = (char *)&RBX::Analytics::location + 1; /*0x1067cc83a*/
      RBX::format(this: (RBX *)&v737, a2: "PlayerConfigToConnectTime_Country_%s", v85); /*0x1067cc84c*/
      v86 = *((double *)this + 27) /* +216: NO 2022 FIELD */ - *((double *)this + 26) /* +208: NO 2022 FIELD */; /*0x1067cc859*/
      v87 = (double *)__src[1]; /*0x1067cc861*/
      if ( __src[1] >= v743[0] ) /*0x1067cc86c*/
      {
        v734 = *((double *)this + 27) /* +216: NO 2022 FIELD */ - *((double *)this + 26) /* +208: NO 2022 FIELD */; /*0x1067cc894*/
        v88 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cc8a3*/
        if ( (unsigned __int64)(v88 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cc8b8*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0da5*/
        v89 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cc8c4*/
        if ( v89 <= v88 + 1 ) /*0x1067cc8cb*/
          v89 = v88 + 1; /*0x1067cc8cb*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cc8dc*/
          v89 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cc8dc*/
        v724 = v743; /*0x1067cc8e4*/
        if ( v89 != 0 ) /*0x1067cc8ee*/
        {
          v90 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cc8f0*/
          v92 = v91; /*0x1067cc8f5*/
        }
        else
        {
          v90 = 0; /*0x1067cc8fa*/
          v92 = 0; /*0x1067cc8fc*/
        }
        v93 = v90 + 32 * v88; /*0x1067cc903*/
        v94 = (void *)(v90 + 32 * v92); /*0x1067cc90b*/
        v95 = (void *)(v93 + 32); /*0x1067cc915*/
        *(_QWORD *)(v93 + 16) = v738; /*0x1067cc919*/
        *(_OWORD *)v93 = v737; /*0x1067cc921*/
        v737 = 0; /*0x1067cc929*/
        v738 = nullptr; /*0x1067cc92d*/
        *(double *)(v93 + 24) = v734; /*0x1067cc93d*/
        v96 = (void *)(v93 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cc94e*/
        memcpy(__dst: v96, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cc954*/
        v97 = (RBX *)__src[0]; /*0x1067cc959*/
        v98 = v743[0]; /*0x1067cc95d*/
        __src[0] = v96; /*0x1067cc961*/
        *((_QWORD *)&v721 + 1) = v97; /*0x1067cc96c*/
        __src[1] = v95; /*0x1067cc970*/
        v722 = v97; /*0x1067cc974*/
        v743[0] = v94; /*0x1067cc978*/
        v723 = v98; /*0x1067cc97c*/
        *(_QWORD *)&v721 = v97; /*0x1067cc980*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cc983*/
        __src[1] = v95; /*0x1067cc98c*/
        if ( (v737 & 1) != 0 ) /*0x1067cc990*/
          operator delete(a1: v738); /*0x1067cc996*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v738; /*0x1067cc872*/
        *(_OWORD *)v87 = v737; /*0x1067cc87b*/
        v87[3] = v86; /*0x1067cc881*/
        __src[1] = v87 + 4; /*0x1067cc88b*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cc9a0*/
        v99 = (const char *)qword_10D50FFF8; /*0x1067cc9a2*/
      else
        v99 = (char *)&RBX::Analytics::location + 1; /*0x1067cc9a9*/
      RBX::format(this: (RBX *)&v737, a2: "ConnectToReceivedGlobalsTime_Country_%s", v99); /*0x1067cc9bb*/
      v100 = *((double *)this + 28) /* +224: NO 2022 FIELD */ - *((double *)this + 27) /* +216: NO 2022 FIELD */; /*0x1067cc9c8*/
      v101 = (double *)__src[1]; /*0x1067cc9d0*/
      if ( __src[1] >= v743[0] ) /*0x1067cc9db*/
      {
        v734 = *((double *)this + 28) /* +224: NO 2022 FIELD */ - *((double *)this + 27) /* +216: NO 2022 FIELD */; /*0x1067cca03*/
        v102 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cca12*/
        if ( (unsigned __int64)(v102 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cca27*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0daf*/
        v103 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cca33*/
        if ( v103 <= v102 + 1 ) /*0x1067cca3a*/
          v103 = v102 + 1; /*0x1067cca3a*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cca4b*/
          v103 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cca4b*/
        v724 = v743; /*0x1067cca53*/
        if ( v103 != 0 ) /*0x1067cca5d*/
        {
          v104 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cca5f*/
          v106 = v105; /*0x1067cca64*/
        }
        else
        {
          v104 = 0; /*0x1067cca69*/
          v106 = 0; /*0x1067cca6b*/
        }
        v107 = v104 + 32 * v102; /*0x1067cca72*/
        v108 = (void *)(v104 + 32 * v106); /*0x1067cca7a*/
        v109 = (void *)(v107 + 32); /*0x1067cca84*/
        *(_QWORD *)(v107 + 16) = v738; /*0x1067cca88*/
        *(_OWORD *)v107 = v737; /*0x1067cca90*/
        v737 = 0; /*0x1067cca98*/
        v738 = nullptr; /*0x1067cca9c*/
        *(double *)(v107 + 24) = v734; /*0x1067ccaac*/
        v110 = (void *)(v107 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ccabd*/
        memcpy(__dst: v110, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ccac3*/
        v111 = (RBX *)__src[0]; /*0x1067ccac8*/
        v112 = v743[0]; /*0x1067ccacc*/
        __src[0] = v110; /*0x1067ccad0*/
        *((_QWORD *)&v721 + 1) = v111; /*0x1067ccadb*/
        __src[1] = v109; /*0x1067ccadf*/
        v722 = v111; /*0x1067ccae3*/
        v743[0] = v108; /*0x1067ccae7*/
        v723 = v112; /*0x1067ccaeb*/
        *(_QWORD *)&v721 = v111; /*0x1067ccaef*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ccaf2*/
        __src[1] = v109; /*0x1067ccafb*/
        if ( (v737 & 1) != 0 ) /*0x1067ccaff*/
          operator delete(a1: v738); /*0x1067ccb05*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v738; /*0x1067cc9e1*/
        *(_OWORD *)v101 = v737; /*0x1067cc9ea*/
        v101[3] = v100; /*0x1067cc9f0*/
        __src[1] = v101 + 4; /*0x1067cc9fa*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ccb0f*/
        v113 = (const char *)qword_10D50FFF8; /*0x1067ccb11*/
      else
        v113 = (char *)&RBX::Analytics::location + 1; /*0x1067ccb18*/
      RBX::format(this: (RBX *)&v737, a2: "ReceivedGlobalToGameLoadTime_Country_%s", v113); /*0x1067ccb2a*/
      v114 = *((double *)this + 29) /* +232: NO 2022 FIELD */ - *((double *)this + 28) /* +224: NO 2022 FIELD */; /*0x1067ccb37*/
      v115 = (double *)__src[1]; /*0x1067ccb3f*/
      if ( __src[1] >= v743[0] ) /*0x1067ccb4a*/
      {
        v734 = *((double *)this + 29) /* +232: NO 2022 FIELD */ - *((double *)this + 28) /* +224: NO 2022 FIELD */; /*0x1067ccb72*/
        v116 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067ccb81*/
        if ( (unsigned __int64)(v116 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067ccb96*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0db9*/
        v117 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067ccba2*/
        if ( v117 <= v116 + 1 ) /*0x1067ccba9*/
          v117 = v116 + 1; /*0x1067ccba9*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067ccbba*/
          v117 = 0x7FFFFFFFFFFFFFFLL; /*0x1067ccbba*/
        v724 = v743; /*0x1067ccbc2*/
        if ( v117 != 0 ) /*0x1067ccbcc*/
        {
          v118 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067ccbce*/
          v120 = v119; /*0x1067ccbd3*/
        }
        else
        {
          v118 = 0; /*0x1067ccbd8*/
          v120 = 0; /*0x1067ccbda*/
        }
        v121 = v118 + 32 * v116; /*0x1067ccbe1*/
        v122 = (void *)(v118 + 32 * v120); /*0x1067ccbe9*/
        v123 = (void *)(v121 + 32); /*0x1067ccbf3*/
        *(_QWORD *)(v121 + 16) = v738; /*0x1067ccbf7*/
        *(_OWORD *)v121 = v737; /*0x1067ccbff*/
        v737 = 0; /*0x1067ccc07*/
        v738 = nullptr; /*0x1067ccc0b*/
        *(double *)(v121 + 24) = v734; /*0x1067ccc1b*/
        v124 = (void *)(v121 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ccc2c*/
        memcpy(__dst: v124, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ccc32*/
        v125 = (RBX *)__src[0]; /*0x1067ccc37*/
        v126 = v743[0]; /*0x1067ccc3b*/
        __src[0] = v124; /*0x1067ccc3f*/
        *((_QWORD *)&v721 + 1) = v125; /*0x1067ccc4a*/
        __src[1] = v123; /*0x1067ccc4e*/
        v722 = v125; /*0x1067ccc52*/
        v743[0] = v122; /*0x1067ccc56*/
        v723 = v126; /*0x1067ccc5a*/
        *(_QWORD *)&v721 = v125; /*0x1067ccc5e*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ccc61*/
        __src[1] = v123; /*0x1067ccc6a*/
        if ( (v737 & 1) != 0 ) /*0x1067ccc6e*/
          operator delete(a1: v738); /*0x1067ccc74*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v738; /*0x1067ccb50*/
        *(_OWORD *)v115 = v737; /*0x1067ccb59*/
        v115[3] = v114; /*0x1067ccb5f*/
        __src[1] = v115 + 4; /*0x1067ccb69*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ccc7e*/
        v127 = (const char *)qword_10D50FFF8; /*0x1067ccc80*/
      else
        v127 = (char *)&RBX::Analytics::location + 1; /*0x1067ccc87*/
      RBX::format(this: (RBX *)&v737, a2: "GameLoadToGameJoinTime_Country_%s", v127); /*0x1067ccc99*/
      v128 = *((double *)this + 30) /* +240: NO 2022 FIELD */ - *((double *)this + 29) /* +232: NO 2022 FIELD */; /*0x1067ccca6*/
      v129 = (double *)__src[1]; /*0x1067cccae*/
      if ( __src[1] >= v743[0] ) /*0x1067cccb9*/
      {
        v734 = *((double *)this + 30) /* +240: NO 2022 FIELD */ - *((double *)this + 29) /* +232: NO 2022 FIELD */; /*0x1067ccce1*/
        v130 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cccf0*/
        if ( (unsigned __int64)(v130 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067ccd05*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0dc3*/
        v131 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067ccd11*/
        if ( v131 <= v130 + 1 ) /*0x1067ccd18*/
          v131 = v130 + 1; /*0x1067ccd18*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067ccd29*/
          v131 = 0x7FFFFFFFFFFFFFFLL; /*0x1067ccd29*/
        v724 = v743; /*0x1067ccd31*/
        if ( v131 != 0 ) /*0x1067ccd3b*/
        {
          v132 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067ccd3d*/
          v134 = v133; /*0x1067ccd42*/
        }
        else
        {
          v132 = 0; /*0x1067ccd47*/
          v134 = 0; /*0x1067ccd49*/
        }
        v135 = v132 + 32 * v130; /*0x1067ccd50*/
        v136 = (void *)(v132 + 32 * v134); /*0x1067ccd58*/
        v137 = (void *)(v135 + 32); /*0x1067ccd62*/
        *(_QWORD *)(v135 + 16) = v738; /*0x1067ccd66*/
        *(_OWORD *)v135 = v737; /*0x1067ccd6e*/
        v737 = 0; /*0x1067ccd76*/
        v738 = nullptr; /*0x1067ccd7a*/
        *(double *)(v135 + 24) = v734; /*0x1067ccd8a*/
        v138 = (void *)(v135 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ccd9b*/
        memcpy(__dst: v138, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ccda1*/
        v139 = (RBX *)__src[0]; /*0x1067ccda6*/
        v140 = v743[0]; /*0x1067ccdaa*/
        __src[0] = v138; /*0x1067ccdae*/
        *((_QWORD *)&v721 + 1) = v139; /*0x1067ccdb9*/
        __src[1] = v137; /*0x1067ccdbd*/
        v722 = v139; /*0x1067ccdc1*/
        v743[0] = v136; /*0x1067ccdc5*/
        v723 = v140; /*0x1067ccdc9*/
        *(_QWORD *)&v721 = v139; /*0x1067ccdcd*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ccdd0*/
        __src[1] = v137; /*0x1067ccdd9*/
        if ( (v737 & 1) != 0 ) /*0x1067ccddd*/
          operator delete(a1: v738); /*0x1067ccde3*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v738; /*0x1067cccbf*/
        *(_OWORD *)v129 = v737; /*0x1067cccc8*/
        v129[3] = v128; /*0x1067cccce*/
        __src[1] = v129 + 4; /*0x1067cccd8*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ccded*/
        v141 = (const char *)qword_10D50FFF8; /*0x1067ccdef*/
      else
        v141 = (char *)&RBX::Analytics::location + 1; /*0x1067ccdf6*/
      RBX::format(this: (RBX *)&v737, a2: "GameJoinToAvatarLoadTime_Country_%s", v141); /*0x1067cce08*/
      v144 = *((double *)this + 36) /* +288: NO 2022 FIELD */ - *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cce15*/
      v145 = (double *)__src[1]; /*0x1067cce1d*/
      if ( __src[1] >= v743[0] ) /*0x1067cce28*/
      {
        v734 = *((double *)this + 36) /* +288: NO 2022 FIELD */ - *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cce50*/
        v146 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cce5f*/
        if ( (unsigned __int64)(v146 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cce74*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0dcd*/
        v147 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cce80*/
        if ( v147 <= v146 + 1 ) /*0x1067cce87*/
          v147 = v146 + 1; /*0x1067cce87*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cce98*/
          v147 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cce98*/
        v724 = v743; /*0x1067ccea0*/
        if ( v147 != 0 ) /*0x1067cceaa*/
        {
          v148 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cceac*/
          v150 = v149; /*0x1067cceb1*/
        }
        else
        {
          v148 = 0; /*0x1067cceb6*/
          v150 = 0; /*0x1067cceb8*/
        }
        v151 = v148 + 32 * v146; /*0x1067ccebf*/
        v152 = (void *)(v148 + 32 * v150); /*0x1067ccec7*/
        v153 = (void *)(v151 + 32); /*0x1067cced1*/
        *(_QWORD *)(v151 + 16) = v738; /*0x1067cced5*/
        *(_OWORD *)v151 = v737; /*0x1067ccedd*/
        v737 = 0; /*0x1067ccee5*/
        v738 = nullptr; /*0x1067ccee9*/
        *(double *)(v151 + 24) = v734; /*0x1067ccef9*/
        v154 = (void *)(v151 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ccf0a*/
        memcpy(__dst: v154, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ccf10*/
        v155 = (RBX *)__src[0]; /*0x1067ccf15*/
        v156 = v743[0]; /*0x1067ccf19*/
        __src[0] = v154; /*0x1067ccf1d*/
        *((_QWORD *)&v721 + 1) = v155; /*0x1067ccf28*/
        __src[1] = v153; /*0x1067ccf2c*/
        v722 = v155; /*0x1067ccf30*/
        v743[0] = v152; /*0x1067ccf34*/
        v723 = v156; /*0x1067ccf38*/
        *(_QWORD *)&v721 = v155; /*0x1067ccf3c*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ccf3f*/
        __src[1] = v153; /*0x1067ccf48*/
        if ( (v737 & 1) != 0 ) /*0x1067ccf4c*/
          operator delete(a1: v738); /*0x1067ccf52*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v738; /*0x1067cce2e*/
        *(_OWORD *)v145 = v737; /*0x1067cce37*/
        v145[3] = v144; /*0x1067cce3d*/
        __src[1] = v145 + 4; /*0x1067cce47*/
      }
      v157 = *(double **)&v733; /*0x1067ccf5b*/
      if ( LOBYTE(v739) != 0 ) /*0x1067ccf62*/
      {
        v158 = (char *)__src[1]; /*0x1067ccf68*/
        if ( __src[1] >= v743[0] ) /*0x1067ccf70*/
        {
          v162 = (_QWORD *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[31],double &>( /*0x1067ccfa5*/
                             a1: __src,
                             a2: "UserClickToStartGameTime_Luobu",
                             a3: *(_QWORD *)&v733);
          v161 = *v157; /*0x1067ccfa8*/
        }
        else
        {
          std::string::basic_string[abi:ne200100]<0>( /*0x1067ccf7c*/
            a1: __src[1],
            a2: "UserClickToStartGameTime_Luobu",
            a3: v142,
            a4: v143);
          v161 = *v157; /*0x1067ccf81*/
          *((double *)v158 + 3) = *v157; /*0x1067ccf86*/
          v162 = v158 + 32; /*0x1067ccf8c*/
        }
        __src[1] = v162; /*0x1067ccfad*/
        *(double *)&v721 = *((double *)this + 24) /* +192: NO 2022 FIELD */ - v161; /*0x1067ccfbd*/
        if ( v162 >= v743[0] ) /*0x1067ccfc9*/
        {
          v165 = (_QWORD *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[40],double>( /*0x1067cd005*/
                             a1: __src,
                             a2: "StartGameToPlaceLauncherStartTime_Luobu",
                             a3: &v721);
        }
        else
        {
          std::string::basic_string[abi:ne200100]<0>( /*0x1067ccfd5*/
            a1: v162,
            a2: "StartGameToPlaceLauncherStartTime_Luobu",
            a3: v159,
            a4: v160);
          v162[3] = v721; /*0x1067ccfe2*/
          v165 = v162 + 4; /*0x1067ccfe8*/
        }
        __src[1] = v165; /*0x1067cd008*/
        *(double *)&v721 = *((double *)this + 25) /* +200: NO 2022 FIELD */ - *((double *)this + 24) /* +192: NO 2022 FIELD */; /*0x1067cd01c*/
        if ( v165 >= v743[0] ) /*0x1067cd028*/
        {
          v168 = (_QWORD *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[44],double>( /*0x1067cd064*/
                             a1: __src,
                             a2: "PlaceLauncherStartToFetchedScriptTime_Luobu",
                             a3: &v721);
        }
        else
        {
          std::string::basic_string[abi:ne200100]<0>( /*0x1067cd034*/
            a1: v165,
            a2: "PlaceLauncherStartToFetchedScriptTime_Luobu",
            a3: v163,
            a4: v164);
          v165[3] = v721; /*0x1067cd041*/
          v168 = v165 + 4; /*0x1067cd047*/
        }
        __src[1] = v168; /*0x1067cd067*/
        *(double *)&v721 = *((double *)this + 26) /* +208: NO 2022 FIELD */ - *((double *)this + 25) /* +200: NO 2022 FIELD */; /*0x1067cd07b*/
        if ( v168 >= v743[0] ) /*0x1067cd087*/
        {
          v171 = (_QWORD *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[36],double>( /*0x1067cd0c3*/
                             a1: __src,
                             a2: "FetchedScriptToPlayerConfTime_Luobu",
                             a3: &v721);
        }
        else
        {
          std::string::basic_string[abi:ne200100]<0>( /*0x1067cd093*/
            a1: v168,
            a2: "FetchedScriptToPlayerConfTime_Luobu",
            a3: v166,
            a4: v167);
          v168[3] = v721; /*0x1067cd0a0*/
          v171 = v168 + 4; /*0x1067cd0a6*/
        }
        __src[1] = v171; /*0x1067cd0c6*/
        *(double *)&v721 = *((double *)this + 27) /* +216: NO 2022 FIELD */ - *((double *)this + 26) /* +208: NO 2022 FIELD */; /*0x1067cd0da*/
        if ( v171 >= v743[0] ) /*0x1067cd0e6*/
        {
          v174 = (_QWORD *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[32],double>( /*0x1067cd122*/
                             a1: __src,
                             a2: "PlayerConfigToConnectTime_Luobu",
                             a3: &v721);
        }
        else
        {
          std::string::basic_string[abi:ne200100]<0>( /*0x1067cd0f2*/
            a1: v171,
            a2: "PlayerConfigToConnectTime_Luobu",
            a3: v169,
            a4: v170);
          v171[3] = v721; /*0x1067cd0ff*/
          v174 = v171 + 4; /*0x1067cd105*/
        }
        __src[1] = v174; /*0x1067cd125*/
        *(double *)&v721 = *((double *)this + 28) /* +224: NO 2022 FIELD */ - *((double *)this + 27) /* +216: NO 2022 FIELD */; /*0x1067cd139*/
        if ( v174 >= v743[0] ) /*0x1067cd145*/
        {
          v177 = (_QWORD *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[35],double>( /*0x1067cd181*/
                             a1: __src,
                             a2: "ConnectToReceivedGlobalsTime_Luobu",
                             a3: &v721);
        }
        else
        {
          std::string::basic_string[abi:ne200100]<0>( /*0x1067cd151*/
            a1: v174,
            a2: "ConnectToReceivedGlobalsTime_Luobu",
            a3: v172,
            a4: v173);
          v174[3] = v721; /*0x1067cd15e*/
          v177 = v174 + 4; /*0x1067cd164*/
        }
        __src[1] = v177; /*0x1067cd184*/
        *(double *)&v721 = *((double *)this + 29) /* +232: NO 2022 FIELD */ - *((double *)this + 28) /* +224: NO 2022 FIELD */; /*0x1067cd198*/
        if ( v177 >= v743[0] ) /*0x1067cd1a4*/
        {
          v180 = (_QWORD *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[35],double>( /*0x1067cd1e0*/
                             a1: __src,
                             a2: "ReceivedGlobalToGameLoadTime_Luobu",
                             a3: &v721);
        }
        else
        {
          std::string::basic_string[abi:ne200100]<0>( /*0x1067cd1b0*/
            a1: v177,
            a2: "ReceivedGlobalToGameLoadTime_Luobu",
            a3: v175,
            a4: v176);
          v177[3] = v721; /*0x1067cd1bd*/
          v180 = v177 + 4; /*0x1067cd1c3*/
        }
        __src[1] = v180; /*0x1067cd1e3*/
        *(double *)&v721 = *((double *)this + 30) /* +240: NO 2022 FIELD */ - *((double *)this + 29) /* +232: NO 2022 FIELD */; /*0x1067cd1f7*/
        if ( v180 >= v743[0] ) /*0x1067cd203*/
        {
          v183 = (_QWORD *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[29],double>( /*0x1067cd23f*/
                             a1: __src,
                             a2: "GameLoadToGameJoinTime_Luobu",
                             a3: &v721);
        }
        else
        {
          std::string::basic_string[abi:ne200100]<0>(a1: v180, a2: "GameLoadToGameJoinTime_Luobu", a3: v178, a4: v179); /*0x1067cd20f*/
          v180[3] = v721; /*0x1067cd21c*/
          v183 = v180 + 4; /*0x1067cd222*/
        }
        __src[1] = v183; /*0x1067cd242*/
        *(double *)&v721 = *((double *)this + 36) /* +288: NO 2022 FIELD */ - *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cd256*/
        if ( v183 >= v743[0] ) /*0x1067cd262*/
        {
          v184 = (void *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[31],double>( /*0x1067cd29e*/
                           a1: __src,
                           a2: "GameJoinToAvatarLoadTime_Luobu",
                           a3: &v721);
        }
        else
        {
          std::string::basic_string[abi:ne200100]<0>(a1: v183, a2: "GameJoinToAvatarLoadTime_Luobu", a3: v181, a4: v182); /*0x1067cd26e*/
          v183[3] = v721; /*0x1067cd27b*/
          v184 = v183 + 4; /*0x1067cd281*/
        }
        __src[1] = v184; /*0x1067cd2a1*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cd2aa*/
        v185 = (const char *)qword_10D50FFF8; /*0x1067cd2ac*/
      else
        v185 = (char *)&RBX::Analytics::location + 1; /*0x1067cd2b3*/
      RBX::format(this: (RBX *)&v737, a2: "AvatarLoadTime_Country_%s", v185); /*0x1067cd2c5*/
      v188 = (double *)__src[1]; /*0x1067cd2ca*/
      if ( __src[1] >= v743[0] ) /*0x1067cd2d5*/
      {
        v189 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cd30d*/
        if ( (unsigned __int64)(v189 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cd322*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0dd7*/
        v190 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cd32e*/
        if ( v190 <= v189 + 1 ) /*0x1067cd335*/
          v190 = v189 + 1; /*0x1067cd335*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cd346*/
          v190 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cd346*/
        v724 = v743; /*0x1067cd34e*/
        if ( v190 != 0 ) /*0x1067cd358*/
        {
          v191 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cd35a*/
          v193 = v192; /*0x1067cd35f*/
        }
        else
        {
          v191 = 0; /*0x1067cd364*/
          v193 = 0; /*0x1067cd366*/
        }
        v194 = v191 + 32 * v189; /*0x1067cd36d*/
        v195 = (void *)(v191 + 32 * v193); /*0x1067cd375*/
        v196 = (void *)(v194 + 32); /*0x1067cd37f*/
        *(_QWORD *)(v194 + 16) = v738; /*0x1067cd383*/
        *(_OWORD *)v194 = v737; /*0x1067cd38b*/
        v737 = 0; /*0x1067cd393*/
        v738 = nullptr; /*0x1067cd397*/
        *(double *)(v194 + 24) = *v732; /*0x1067cd3aa*/
        v197 = (void *)(v194 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cd3bb*/
        memcpy(__dst: v197, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cd3c1*/
        v198 = (RBX *)__src[0]; /*0x1067cd3c6*/
        v199 = v743[0]; /*0x1067cd3ca*/
        __src[0] = v197; /*0x1067cd3ce*/
        *((_QWORD *)&v721 + 1) = v198; /*0x1067cd3d9*/
        __src[1] = v196; /*0x1067cd3dd*/
        v722 = v198; /*0x1067cd3e1*/
        v743[0] = v195; /*0x1067cd3e5*/
        v723 = v199; /*0x1067cd3e9*/
        *(_QWORD *)&v721 = v198; /*0x1067cd3ed*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cd3f0*/
        __src[1] = v196; /*0x1067cd3f9*/
        if ( (v737 & 1) != 0 ) /*0x1067cd3fd*/
          operator delete(a1: v738); /*0x1067cd403*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v738; /*0x1067cd2db*/
        *(_OWORD *)v188 = v737; /*0x1067cd2e3*/
        v188[3] = *v732; /*0x1067cd2f3*/
        __src[1] = v188 + 4; /*0x1067cd2fd*/
      }
      if ( LOBYTE(v739) != 0 ) /*0x1067cd416*/
      {
        v200 = (double *)__src[1]; /*0x1067cd418*/
        if ( __src[1] >= v743[0] ) /*0x1067cd420*/
        {
          v201 = (void *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[21],double &>( /*0x1067cd45f*/
                           a1: __src,
                           a2: "AvatarLoadTime_Luobu",
                           a3: v732);
        }
        else
        {
          std::string::basic_string[abi:ne200100]<0>(a1: __src[1], a2: "AvatarLoadTime_Luobu", a3: v186, a4: v187); /*0x1067cd42c*/
          v200[3] = *v732; /*0x1067cd43c*/
          v201 = v200 + 4; /*0x1067cd442*/
        }
        __src[1] = v201; /*0x1067cd462*/
      }
      RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)&v737); /*0x1067cd46a*/
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cd474*/
        v202 = (const char *)qword_10D50FFF8; /*0x1067cd476*/
      else
        v202 = (char *)&RBX::Analytics::location + 1; /*0x1067cd47d*/
      v203 = (char *)&v737 + 1; /*0x1067cd482*/
      v204 = (char *)&v737 + 1; /*0x1067cd48b*/
      if ( (v737 & 1) != 0 ) /*0x1067cd48e*/
        v204 = (const char *)v738; /*0x1067cd490*/
      RBX::format(this: (RBX *)&v740, a2: "StartGameToPlaceLauncherStartTime_Country_%s_%s", v202, v204); /*0x1067cd4a1*/
      v206 = *((double *)this + 24) /* +192: NO 2022 FIELD */ - *((double *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067cd4ae*/
      v207 = (double *)__src[1]; /*0x1067cd4b6*/
      if ( __src[1] >= v743[0] ) /*0x1067cd4c1*/
      {
        v739 = *((double *)this + 24) /* +192: NO 2022 FIELD */ - *((double *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067cd4e8*/
        v208 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cd4f4*/
        if ( (unsigned __int64)(v208 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cd4ff*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v205); /*0x1067d0deb*/
        v209 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cd50b*/
        if ( v209 <= v208 + 1 ) /*0x1067cd512*/
          v209 = v208 + 1; /*0x1067cd512*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cd523*/
          v209 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cd523*/
        v724 = v743; /*0x1067cd52b*/
        if ( v209 != 0 ) /*0x1067cd535*/
        {
          v210 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cd537*/
          v212 = v211; /*0x1067cd53c*/
        }
        else
        {
          v210 = 0; /*0x1067cd541*/
          v212 = 0; /*0x1067cd543*/
        }
        v213 = v210 + 32 * v208; /*0x1067cd54a*/
        v214 = (void *)(v210 + 32 * v212); /*0x1067cd552*/
        v215 = (void *)(v213 + 32); /*0x1067cd55c*/
        *(_QWORD *)(v213 + 16) = v741; /*0x1067cd560*/
        *(_OWORD *)v213 = v740; /*0x1067cd568*/
        v740 = 0; /*0x1067cd570*/
        v741 = nullptr; /*0x1067cd574*/
        *(double *)(v213 + 24) = v739; /*0x1067cd581*/
        v216 = (void *)(v213 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cd592*/
        memcpy(__dst: v216, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cd598*/
        v217 = (RBX *)__src[0]; /*0x1067cd59d*/
        v218 = v743[0]; /*0x1067cd5a1*/
        __src[0] = v216; /*0x1067cd5a5*/
        *((_QWORD *)&v721 + 1) = v217; /*0x1067cd5b0*/
        __src[1] = v215; /*0x1067cd5b4*/
        v722 = v217; /*0x1067cd5b8*/
        v743[0] = v214; /*0x1067cd5bc*/
        v723 = v218; /*0x1067cd5c0*/
        *(_QWORD *)&v721 = v217; /*0x1067cd5c4*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cd5c7*/
        __src[1] = v215; /*0x1067cd5d0*/
        v203 = (char *)&v737 + 1; /*0x1067cd5de*/
        if ( (v740 & 1) != 0 ) /*0x1067cd5e2*/
          operator delete(a1: v741); /*0x1067cd5e8*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v741; /*0x1067cd4c7*/
        *(_OWORD *)v207 = v740; /*0x1067cd4d0*/
        v207[3] = v206; /*0x1067cd4d5*/
        __src[1] = v207 + 4; /*0x1067cd4df*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cd5f2*/
        v219 = (const char *)qword_10D50FFF8; /*0x1067cd5f4*/
      else
        v219 = (char *)&RBX::Analytics::location + 1; /*0x1067cd5fb*/
      v220 = (char *)&v737 + 1; /*0x1067cd604*/
      if ( (v737 & 1) != 0 ) /*0x1067cd607*/
        v220 = (const char *)v738; /*0x1067cd609*/
      RBX::format(this: (RBX *)&v740, a2: "PlaceLauncherStartToFetchedScriptTime_Country_%s_%s", v219, v220); /*0x1067cd61a*/
      v222 = *((double *)this + 25) /* +200: NO 2022 FIELD */ - *((double *)this + 24) /* +192: NO 2022 FIELD */; /*0x1067cd627*/
      v223 = (double *)__src[1]; /*0x1067cd62f*/
      if ( __src[1] >= v743[0] ) /*0x1067cd63a*/
      {
        v739 = *((double *)this + 25) /* +200: NO 2022 FIELD */ - *((double *)this + 24) /* +192: NO 2022 FIELD */; /*0x1067cd661*/
        v224 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cd66d*/
        if ( (unsigned __int64)(v224 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cd678*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v221); /*0x1067d0df2*/
        v225 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cd684*/
        if ( v225 <= v224 + 1 ) /*0x1067cd68b*/
          v225 = v224 + 1; /*0x1067cd68b*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cd69c*/
          v225 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cd69c*/
        v724 = v743; /*0x1067cd6a4*/
        if ( v225 != 0 ) /*0x1067cd6ae*/
        {
          v226 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cd6b0*/
          v228 = v227; /*0x1067cd6b5*/
        }
        else
        {
          v226 = 0; /*0x1067cd6ba*/
          v228 = 0; /*0x1067cd6bc*/
        }
        v229 = v226 + 32 * v224; /*0x1067cd6c3*/
        v230 = (void *)(v226 + 32 * v228); /*0x1067cd6cb*/
        v231 = (void *)(v229 + 32); /*0x1067cd6d5*/
        *(_QWORD *)(v229 + 16) = v741; /*0x1067cd6d9*/
        *(_OWORD *)v229 = v740; /*0x1067cd6e1*/
        v740 = 0; /*0x1067cd6e9*/
        v741 = nullptr; /*0x1067cd6ed*/
        *(double *)(v229 + 24) = v739; /*0x1067cd6fa*/
        v232 = (void *)(v229 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cd70b*/
        memcpy(__dst: v232, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cd711*/
        v233 = (RBX *)__src[0]; /*0x1067cd716*/
        v234 = v743[0]; /*0x1067cd71a*/
        __src[0] = v232; /*0x1067cd71e*/
        *((_QWORD *)&v721 + 1) = v233; /*0x1067cd729*/
        __src[1] = v231; /*0x1067cd72d*/
        v722 = v233; /*0x1067cd731*/
        v743[0] = v230; /*0x1067cd735*/
        v723 = v234; /*0x1067cd739*/
        *(_QWORD *)&v721 = v233; /*0x1067cd73d*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cd740*/
        __src[1] = v231; /*0x1067cd749*/
        v203 = (char *)&v737 + 1; /*0x1067cd757*/
        if ( (v740 & 1) != 0 ) /*0x1067cd75b*/
          operator delete(a1: v741); /*0x1067cd761*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v741; /*0x1067cd640*/
        *(_OWORD *)v223 = v740; /*0x1067cd649*/
        v223[3] = v222; /*0x1067cd64e*/
        __src[1] = v223 + 4; /*0x1067cd658*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cd76b*/
        v235 = (const char *)qword_10D50FFF8; /*0x1067cd76d*/
      else
        v235 = (char *)&RBX::Analytics::location + 1; /*0x1067cd774*/
      v236 = (char *)&v737 + 1; /*0x1067cd77d*/
      if ( (v737 & 1) != 0 ) /*0x1067cd780*/
        v236 = (const char *)v738; /*0x1067cd782*/
      RBX::format(this: (RBX *)&v740, a2: "FetchedScriptToPlayerConfTime_Country_%s_%s", v235, v236); /*0x1067cd793*/
      v238 = *((double *)this + 26) /* +208: NO 2022 FIELD */ - *((double *)this + 25) /* +200: NO 2022 FIELD */; /*0x1067cd7a0*/
      v239 = (double *)__src[1]; /*0x1067cd7a8*/
      if ( __src[1] >= v743[0] ) /*0x1067cd7b3*/
      {
        v739 = *((double *)this + 26) /* +208: NO 2022 FIELD */ - *((double *)this + 25) /* +200: NO 2022 FIELD */; /*0x1067cd7da*/
        v240 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cd7e6*/
        if ( (unsigned __int64)(v240 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cd7f1*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v237); /*0x1067d0e00*/
        v241 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cd7fd*/
        if ( v241 <= v240 + 1 ) /*0x1067cd804*/
          v241 = v240 + 1; /*0x1067cd804*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cd815*/
          v241 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cd815*/
        v724 = v743; /*0x1067cd81d*/
        if ( v241 != 0 ) /*0x1067cd827*/
        {
          v242 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cd829*/
          v244 = v243; /*0x1067cd82e*/
        }
        else
        {
          v242 = 0; /*0x1067cd833*/
          v244 = 0; /*0x1067cd835*/
        }
        v245 = v242 + 32 * v240; /*0x1067cd83c*/
        v246 = (void *)(v242 + 32 * v244); /*0x1067cd844*/
        v247 = (void *)(v245 + 32); /*0x1067cd84e*/
        *(_QWORD *)(v245 + 16) = v741; /*0x1067cd852*/
        *(_OWORD *)v245 = v740; /*0x1067cd85a*/
        v740 = 0; /*0x1067cd862*/
        v741 = nullptr; /*0x1067cd866*/
        *(double *)(v245 + 24) = v739; /*0x1067cd873*/
        v248 = (void *)(v245 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cd884*/
        memcpy(__dst: v248, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cd88a*/
        v249 = (RBX *)__src[0]; /*0x1067cd88f*/
        v250 = v743[0]; /*0x1067cd893*/
        __src[0] = v248; /*0x1067cd897*/
        *((_QWORD *)&v721 + 1) = v249; /*0x1067cd8a2*/
        __src[1] = v247; /*0x1067cd8a6*/
        v722 = v249; /*0x1067cd8aa*/
        v743[0] = v246; /*0x1067cd8ae*/
        v723 = v250; /*0x1067cd8b2*/
        *(_QWORD *)&v721 = v249; /*0x1067cd8b6*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cd8b9*/
        __src[1] = v247; /*0x1067cd8c2*/
        v203 = (char *)&v737 + 1; /*0x1067cd8d0*/
        if ( (v740 & 1) != 0 ) /*0x1067cd8d4*/
          operator delete(a1: v741); /*0x1067cd8da*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v741; /*0x1067cd7b9*/
        *(_OWORD *)v239 = v740; /*0x1067cd7c2*/
        v239[3] = v238; /*0x1067cd7c7*/
        __src[1] = v239 + 4; /*0x1067cd7d1*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cd8e4*/
        v251 = (const char *)qword_10D50FFF8; /*0x1067cd8e6*/
      else
        v251 = (char *)&RBX::Analytics::location + 1; /*0x1067cd8ed*/
      v252 = (char *)&v737 + 1; /*0x1067cd8f6*/
      if ( (v737 & 1) != 0 ) /*0x1067cd8f9*/
        v252 = (const char *)v738; /*0x1067cd8fb*/
      RBX::format(this: (RBX *)&v740, a2: "PlayerConfigToConnectTime_Country_%s_%s", v251, v252); /*0x1067cd90c*/
      v254 = *((double *)this + 27) /* +216: NO 2022 FIELD */ - *((double *)this + 26) /* +208: NO 2022 FIELD */; /*0x1067cd919*/
      v255 = (double *)__src[1]; /*0x1067cd921*/
      if ( __src[1] >= v743[0] ) /*0x1067cd92c*/
      {
        v739 = *((double *)this + 27) /* +216: NO 2022 FIELD */ - *((double *)this + 26) /* +208: NO 2022 FIELD */; /*0x1067cd953*/
        v256 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cd95f*/
        if ( (unsigned __int64)(v256 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cd96a*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v253); /*0x1067d0e07*/
        v257 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cd976*/
        if ( v257 <= v256 + 1 ) /*0x1067cd97d*/
          v257 = v256 + 1; /*0x1067cd97d*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cd98e*/
          v257 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cd98e*/
        v724 = v743; /*0x1067cd996*/
        if ( v257 != 0 ) /*0x1067cd9a0*/
        {
          v258 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cd9a2*/
          v260 = v259; /*0x1067cd9a7*/
        }
        else
        {
          v258 = 0; /*0x1067cd9ac*/
          v260 = 0; /*0x1067cd9ae*/
        }
        v261 = v258 + 32 * v256; /*0x1067cd9b5*/
        v262 = (void *)(v258 + 32 * v260); /*0x1067cd9bd*/
        v263 = (void *)(v261 + 32); /*0x1067cd9c7*/
        *(_QWORD *)(v261 + 16) = v741; /*0x1067cd9cb*/
        *(_OWORD *)v261 = v740; /*0x1067cd9d3*/
        v740 = 0; /*0x1067cd9db*/
        v741 = nullptr; /*0x1067cd9df*/
        *(double *)(v261 + 24) = v739; /*0x1067cd9ec*/
        v264 = (void *)(v261 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cd9fd*/
        memcpy(__dst: v264, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cda03*/
        v265 = (RBX *)__src[0]; /*0x1067cda08*/
        v266 = v743[0]; /*0x1067cda0c*/
        __src[0] = v264; /*0x1067cda10*/
        *((_QWORD *)&v721 + 1) = v265; /*0x1067cda1b*/
        __src[1] = v263; /*0x1067cda1f*/
        v722 = v265; /*0x1067cda23*/
        v743[0] = v262; /*0x1067cda27*/
        v723 = v266; /*0x1067cda2b*/
        *(_QWORD *)&v721 = v265; /*0x1067cda2f*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cda32*/
        __src[1] = v263; /*0x1067cda3b*/
        v203 = (char *)&v737 + 1; /*0x1067cda49*/
        if ( (v740 & 1) != 0 ) /*0x1067cda4d*/
          operator delete(a1: v741); /*0x1067cda53*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v741; /*0x1067cd932*/
        *(_OWORD *)v255 = v740; /*0x1067cd93b*/
        v255[3] = v254; /*0x1067cd940*/
        __src[1] = v255 + 4; /*0x1067cd94a*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cda5d*/
        v267 = (const char *)qword_10D50FFF8; /*0x1067cda5f*/
      else
        v267 = (char *)&RBX::Analytics::location + 1; /*0x1067cda66*/
      v268 = (char *)&v737 + 1; /*0x1067cda6f*/
      if ( (v737 & 1) != 0 ) /*0x1067cda72*/
        v268 = (const char *)v738; /*0x1067cda74*/
      RBX::format(this: (RBX *)&v740, a2: "ConnectToReceivedGlobalsTime_Country_%s_%s", v267, v268); /*0x1067cda85*/
      v270 = *((double *)this + 28) /* +224: NO 2022 FIELD */ - *((double *)this + 27) /* +216: NO 2022 FIELD */; /*0x1067cda92*/
      v271 = (double *)__src[1]; /*0x1067cda9a*/
      if ( __src[1] >= v743[0] ) /*0x1067cdaa5*/
      {
        v739 = *((double *)this + 28) /* +224: NO 2022 FIELD */ - *((double *)this + 27) /* +216: NO 2022 FIELD */; /*0x1067cdacc*/
        v272 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cdad8*/
        if ( (unsigned __int64)(v272 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cdae3*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v269); /*0x1067d0e0e*/
        v273 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cdaef*/
        if ( v273 <= v272 + 1 ) /*0x1067cdaf6*/
          v273 = v272 + 1; /*0x1067cdaf6*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cdb07*/
          v273 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cdb07*/
        v724 = v743; /*0x1067cdb0f*/
        if ( v273 != 0 ) /*0x1067cdb19*/
        {
          v274 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cdb1b*/
          v276 = v275; /*0x1067cdb20*/
        }
        else
        {
          v274 = 0; /*0x1067cdb25*/
          v276 = 0; /*0x1067cdb27*/
        }
        v277 = v274 + 32 * v272; /*0x1067cdb2e*/
        v278 = (void *)(v274 + 32 * v276); /*0x1067cdb36*/
        v279 = (void *)(v277 + 32); /*0x1067cdb40*/
        *(_QWORD *)(v277 + 16) = v741; /*0x1067cdb44*/
        *(_OWORD *)v277 = v740; /*0x1067cdb4c*/
        v740 = 0; /*0x1067cdb54*/
        v741 = nullptr; /*0x1067cdb58*/
        *(double *)(v277 + 24) = v739; /*0x1067cdb65*/
        v280 = (void *)(v277 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cdb76*/
        memcpy(__dst: v280, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cdb7c*/
        v281 = (RBX *)__src[0]; /*0x1067cdb81*/
        v282 = v743[0]; /*0x1067cdb85*/
        __src[0] = v280; /*0x1067cdb89*/
        *((_QWORD *)&v721 + 1) = v281; /*0x1067cdb94*/
        __src[1] = v279; /*0x1067cdb98*/
        v722 = v281; /*0x1067cdb9c*/
        v743[0] = v278; /*0x1067cdba0*/
        v723 = v282; /*0x1067cdba4*/
        *(_QWORD *)&v721 = v281; /*0x1067cdba8*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cdbab*/
        __src[1] = v279; /*0x1067cdbb4*/
        v203 = (char *)&v737 + 1; /*0x1067cdbc2*/
        if ( (v740 & 1) != 0 ) /*0x1067cdbc6*/
          operator delete(a1: v741); /*0x1067cdbcc*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v741; /*0x1067cdaab*/
        *(_OWORD *)v271 = v740; /*0x1067cdab4*/
        v271[3] = v270; /*0x1067cdab9*/
        __src[1] = v271 + 4; /*0x1067cdac3*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cdbd6*/
        v283 = (const char *)qword_10D50FFF8; /*0x1067cdbd8*/
      else
        v283 = (char *)&RBX::Analytics::location + 1; /*0x1067cdbdf*/
      v284 = (char *)&v737 + 1; /*0x1067cdbe8*/
      if ( (v737 & 1) != 0 ) /*0x1067cdbeb*/
        v284 = (const char *)v738; /*0x1067cdbed*/
      RBX::format(this: (RBX *)&v740, a2: "ReceivedGlobalToGameLoadTime_Country_%s_%s", v283, v284); /*0x1067cdbfe*/
      v286 = *((double *)this + 29) /* +232: NO 2022 FIELD */ - *((double *)this + 28) /* +224: NO 2022 FIELD */; /*0x1067cdc0b*/
      v287 = (double *)__src[1]; /*0x1067cdc13*/
      if ( __src[1] >= v743[0] ) /*0x1067cdc1e*/
      {
        v739 = *((double *)this + 29) /* +232: NO 2022 FIELD */ - *((double *)this + 28) /* +224: NO 2022 FIELD */; /*0x1067cdc45*/
        v288 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cdc51*/
        if ( (unsigned __int64)(v288 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cdc5c*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v285); /*0x1067d0e15*/
        v289 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cdc68*/
        if ( v289 <= v288 + 1 ) /*0x1067cdc6f*/
          v289 = v288 + 1; /*0x1067cdc6f*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cdc80*/
          v289 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cdc80*/
        v724 = v743; /*0x1067cdc88*/
        if ( v289 != 0 ) /*0x1067cdc92*/
        {
          v290 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cdc94*/
          v292 = v291; /*0x1067cdc99*/
        }
        else
        {
          v290 = 0; /*0x1067cdc9e*/
          v292 = 0; /*0x1067cdca0*/
        }
        v293 = v290 + 32 * v288; /*0x1067cdca7*/
        v294 = (void *)(v290 + 32 * v292); /*0x1067cdcaf*/
        v295 = (void *)(v293 + 32); /*0x1067cdcb9*/
        *(_QWORD *)(v293 + 16) = v741; /*0x1067cdcbd*/
        *(_OWORD *)v293 = v740; /*0x1067cdcc5*/
        v740 = 0; /*0x1067cdccd*/
        v741 = nullptr; /*0x1067cdcd1*/
        *(double *)(v293 + 24) = v739; /*0x1067cdcde*/
        v296 = (void *)(v293 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cdcef*/
        memcpy(__dst: v296, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cdcf5*/
        v297 = (RBX *)__src[0]; /*0x1067cdcfa*/
        v298 = v743[0]; /*0x1067cdcfe*/
        __src[0] = v296; /*0x1067cdd02*/
        *((_QWORD *)&v721 + 1) = v297; /*0x1067cdd0d*/
        __src[1] = v295; /*0x1067cdd11*/
        v722 = v297; /*0x1067cdd15*/
        v743[0] = v294; /*0x1067cdd19*/
        v723 = v298; /*0x1067cdd1d*/
        *(_QWORD *)&v721 = v297; /*0x1067cdd21*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cdd24*/
        __src[1] = v295; /*0x1067cdd2d*/
        v203 = (char *)&v737 + 1; /*0x1067cdd3b*/
        if ( (v740 & 1) != 0 ) /*0x1067cdd3f*/
          operator delete(a1: v741); /*0x1067cdd45*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v741; /*0x1067cdc24*/
        *(_OWORD *)v287 = v740; /*0x1067cdc2d*/
        v287[3] = v286; /*0x1067cdc32*/
        __src[1] = v287 + 4; /*0x1067cdc3c*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cdd4f*/
        v299 = (const char *)qword_10D50FFF8; /*0x1067cdd51*/
      else
        v299 = (char *)&RBX::Analytics::location + 1; /*0x1067cdd58*/
      v300 = (char *)&v737 + 1; /*0x1067cdd61*/
      if ( (v737 & 1) != 0 ) /*0x1067cdd64*/
        v300 = (const char *)v738; /*0x1067cdd66*/
      RBX::format(this: (RBX *)&v740, a2: "GameLoadToGameJoinTime_Country_%s_%s", v299, v300); /*0x1067cdd77*/
      v302 = *((double *)this + 30) /* +240: NO 2022 FIELD */ - *((double *)this + 29) /* +232: NO 2022 FIELD */; /*0x1067cdd84*/
      v303 = (double *)__src[1]; /*0x1067cdd8c*/
      if ( __src[1] >= v743[0] ) /*0x1067cdd97*/
      {
        v739 = *((double *)this + 30) /* +240: NO 2022 FIELD */ - *((double *)this + 29) /* +232: NO 2022 FIELD */; /*0x1067cddbe*/
        v304 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cddca*/
        if ( (unsigned __int64)(v304 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cddd5*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v301); /*0x1067d0e1c*/
        v305 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cdde1*/
        if ( v305 <= v304 + 1 ) /*0x1067cdde8*/
          v305 = v304 + 1; /*0x1067cdde8*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cddf9*/
          v305 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cddf9*/
        v724 = v743; /*0x1067cde01*/
        if ( v305 != 0 ) /*0x1067cde0b*/
        {
          v306 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cde0d*/
          v308 = v307; /*0x1067cde12*/
        }
        else
        {
          v306 = 0; /*0x1067cde17*/
          v308 = 0; /*0x1067cde19*/
        }
        v309 = v306 + 32 * v304; /*0x1067cde20*/
        v310 = (void *)(v306 + 32 * v308); /*0x1067cde28*/
        v311 = (void *)(v309 + 32); /*0x1067cde32*/
        *(_QWORD *)(v309 + 16) = v741; /*0x1067cde36*/
        *(_OWORD *)v309 = v740; /*0x1067cde3e*/
        v740 = 0; /*0x1067cde46*/
        v741 = nullptr; /*0x1067cde4a*/
        *(double *)(v309 + 24) = v739; /*0x1067cde57*/
        v312 = (void *)(v309 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cde68*/
        memcpy(__dst: v312, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cde6e*/
        v313 = (RBX *)__src[0]; /*0x1067cde73*/
        v314 = v743[0]; /*0x1067cde77*/
        __src[0] = v312; /*0x1067cde7b*/
        *((_QWORD *)&v721 + 1) = v313; /*0x1067cde86*/
        __src[1] = v311; /*0x1067cde8a*/
        v722 = v313; /*0x1067cde8e*/
        v743[0] = v310; /*0x1067cde92*/
        v723 = v314; /*0x1067cde96*/
        *(_QWORD *)&v721 = v313; /*0x1067cde9a*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cde9d*/
        __src[1] = v311; /*0x1067cdea6*/
        v203 = (char *)&v737 + 1; /*0x1067cdeb4*/
        if ( (v740 & 1) != 0 ) /*0x1067cdeb8*/
          operator delete(a1: v741); /*0x1067cdebe*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v741; /*0x1067cdd9d*/
        *(_OWORD *)v303 = v740; /*0x1067cdda6*/
        v303[3] = v302; /*0x1067cddab*/
        __src[1] = v303 + 4; /*0x1067cddb5*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cdec8*/
        v315 = (const char *)qword_10D50FFF8; /*0x1067cdeca*/
      else
        v315 = (char *)&RBX::Analytics::location + 1; /*0x1067cded1*/
      v316 = (char *)&v737 + 1; /*0x1067cdeda*/
      if ( (v737 & 1) != 0 ) /*0x1067cdedd*/
        v316 = (const char *)v738; /*0x1067cdedf*/
      RBX::format(this: (RBX *)&v740, a2: "GameJoinToAvatarLoadTime_Country_%s_%s", v315, v316); /*0x1067cdef0*/
      v318 = *((double *)this + 36) /* +288: NO 2022 FIELD */ - *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cdefd*/
      v319 = (double *)__src[1]; /*0x1067cdf05*/
      if ( __src[1] >= v743[0] ) /*0x1067cdf10*/
      {
        v739 = *((double *)this + 36) /* +288: NO 2022 FIELD */ - *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cdf37*/
        v320 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cdf43*/
        if ( (unsigned __int64)(v320 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cdf4e*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v317); /*0x1067d0e23*/
        v321 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cdf5a*/
        if ( v321 <= v320 + 1 ) /*0x1067cdf61*/
          v321 = v320 + 1; /*0x1067cdf61*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cdf72*/
          v321 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cdf72*/
        v724 = v743; /*0x1067cdf7a*/
        if ( v321 != 0 ) /*0x1067cdf84*/
        {
          v322 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cdf86*/
          v324 = v323; /*0x1067cdf8b*/
        }
        else
        {
          v322 = 0; /*0x1067cdf90*/
          v324 = 0; /*0x1067cdf92*/
        }
        v325 = v322 + 32 * v320; /*0x1067cdf99*/
        v326 = (void *)(v322 + 32 * v324); /*0x1067cdfa1*/
        v327 = (void *)(v325 + 32); /*0x1067cdfab*/
        *(_QWORD *)(v325 + 16) = v741; /*0x1067cdfaf*/
        *(_OWORD *)v325 = v740; /*0x1067cdfb7*/
        v740 = 0; /*0x1067cdfbf*/
        v741 = nullptr; /*0x1067cdfc3*/
        *(double *)(v325 + 24) = v739; /*0x1067cdfd0*/
        v328 = (void *)(v325 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cdfe1*/
        memcpy(__dst: v328, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cdfe7*/
        v329 = (RBX *)__src[0]; /*0x1067cdfec*/
        v330 = v743[0]; /*0x1067cdff0*/
        __src[0] = v328; /*0x1067cdff4*/
        *((_QWORD *)&v721 + 1) = v329; /*0x1067cdfff*/
        __src[1] = v327; /*0x1067ce003*/
        v722 = v329; /*0x1067ce007*/
        v743[0] = v326; /*0x1067ce00b*/
        v723 = v330; /*0x1067ce00f*/
        *(_QWORD *)&v721 = v329; /*0x1067ce013*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ce016*/
        __src[1] = v327; /*0x1067ce01f*/
        v203 = (char *)&v737 + 1; /*0x1067ce023*/
        if ( (v740 & 1) != 0 ) /*0x1067ce027*/
          operator delete(a1: v741); /*0x1067ce02d*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v741; /*0x1067cdf16*/
        *(_OWORD *)v319 = v740; /*0x1067cdf1f*/
        v319[3] = v318; /*0x1067cdf24*/
        __src[1] = v319 + 4; /*0x1067cdf2e*/
      }
      if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ce037*/
        v331 = (const char *)qword_10D50FFF8; /*0x1067ce039*/
      else
        v331 = (char *)&RBX::Analytics::location + 1; /*0x1067ce040*/
      if ( (v737 & 1) != 0 ) /*0x1067ce049*/
        v203 = (const char *)v738; /*0x1067ce04b*/
      RBX::format(this: (RBX *)&v740, a2: "AvatarLoadTime_Country_%s_%s", v331, v203); /*0x1067ce05f*/
      v332 = (double *)__src[1]; /*0x1067ce064*/
      if ( __src[1] >= v743[0] ) /*0x1067ce06f*/
      {
        v333 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067ce0a7*/
        if ( (unsigned __int64)(v333 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067ce0bc*/
          std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0e2a*/
        v334 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067ce0c8*/
        if ( v334 <= v333 + 1 ) /*0x1067ce0cf*/
          v334 = v333 + 1; /*0x1067ce0cf*/
        if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067ce0e0*/
          v334 = 0x7FFFFFFFFFFFFFFLL; /*0x1067ce0e0*/
        v724 = v743; /*0x1067ce0e8*/
        if ( v334 != 0 ) /*0x1067ce0f2*/
        {
          v335 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067ce0f4*/
          v337 = v336; /*0x1067ce0f9*/
        }
        else
        {
          v335 = 0; /*0x1067ce0fe*/
          v337 = 0; /*0x1067ce100*/
        }
        v338 = v335 + 32 * v333; /*0x1067ce107*/
        v339 = (void *)(v335 + 32 * v337); /*0x1067ce10f*/
        v340 = (void *)(v338 + 32); /*0x1067ce119*/
        *(_QWORD *)(v338 + 16) = v741; /*0x1067ce11d*/
        *(_OWORD *)v338 = v740; /*0x1067ce125*/
        v740 = 0; /*0x1067ce12d*/
        v741 = nullptr; /*0x1067ce131*/
        *(double *)(v338 + 24) = *v732; /*0x1067ce144*/
        v341 = (void *)(v338 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ce155*/
        memcpy(__dst: v341, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ce15b*/
        v342 = (RBX *)__src[0]; /*0x1067ce160*/
        v343 = v743[0]; /*0x1067ce164*/
        __src[0] = v341; /*0x1067ce168*/
        *((_QWORD *)&v721 + 1) = v342; /*0x1067ce173*/
        __src[1] = v340; /*0x1067ce177*/
        v722 = v342; /*0x1067ce17b*/
        v743[0] = v339; /*0x1067ce17f*/
        v723 = v343; /*0x1067ce183*/
        *(_QWORD *)&v721 = v342; /*0x1067ce187*/
        std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ce18a*/
        __src[1] = v340; /*0x1067ce193*/
        if ( (v740 & 1) != 0 ) /*0x1067ce197*/
          operator delete(a1: v741); /*0x1067ce19d*/
      }
      else
      {
        *((_QWORD *)__src[1] + 2) = v741; /*0x1067ce075*/
        *(_OWORD *)v332 = v740; /*0x1067ce07d*/
        v332[3] = *v732; /*0x1067ce08d*/
        __src[1] = v332 + 4; /*0x1067ce097*/
      }
      if ( (unsigned __int8)isMobile() != 0 ) /*0x1067ce1a9*/
      {
        if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ce1b4*/
          v344 = (const char *)qword_10D50FFF8; /*0x1067ce1b6*/
        else
          v344 = (char *)&RBX::Analytics::location + 1; /*0x1067ce1bd*/
        RBX::format(this: (RBX *)&v740, a2: "StartGameToPlaceLauncherStartTime_Country_%s_Mobile", v344); /*0x1067ce1cf*/
        v345 = *((double *)this + 24) /* +192: NO 2022 FIELD */ - *((double *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067ce1dc*/
        v346 = (double *)__src[1]; /*0x1067ce1e4*/
        if ( __src[1] >= v743[0] ) /*0x1067ce1ef*/
        {
          v739 = *((double *)this + 24) /* +192: NO 2022 FIELD */ - *((double *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067ce217*/
          v347 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067ce223*/
          if ( (unsigned __int64)(v347 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067ce238*/
            std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0e31*/
          v348 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067ce244*/
          if ( v348 <= v347 + 1 ) /*0x1067ce24b*/
            v348 = v347 + 1; /*0x1067ce24b*/
          if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067ce25c*/
            v348 = 0x7FFFFFFFFFFFFFFLL; /*0x1067ce25c*/
          v724 = v743; /*0x1067ce264*/
          if ( v348 != 0 ) /*0x1067ce26e*/
          {
            v349 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067ce270*/
            v351 = v350; /*0x1067ce275*/
          }
          else
          {
            v349 = 0; /*0x1067ce27a*/
            v351 = 0; /*0x1067ce27c*/
          }
          v352 = v349 + 32 * v347; /*0x1067ce283*/
          v353 = (void *)(v349 + 32 * v351); /*0x1067ce28b*/
          v354 = (void *)(v352 + 32); /*0x1067ce295*/
          *(_QWORD *)(v352 + 16) = v741; /*0x1067ce299*/
          *(_OWORD *)v352 = v740; /*0x1067ce2a1*/
          v740 = 0; /*0x1067ce2a9*/
          v741 = nullptr; /*0x1067ce2ad*/
          *(double *)(v352 + 24) = v739; /*0x1067ce2ba*/
          v355 = (void *)(v352 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ce2cb*/
          memcpy(__dst: v355, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ce2d1*/
          v356 = (RBX *)__src[0]; /*0x1067ce2d6*/
          v357 = v743[0]; /*0x1067ce2da*/
          __src[0] = v355; /*0x1067ce2de*/
          *((_QWORD *)&v721 + 1) = v356; /*0x1067ce2e9*/
          __src[1] = v354; /*0x1067ce2ed*/
          v722 = v356; /*0x1067ce2f1*/
          v743[0] = v353; /*0x1067ce2f5*/
          v723 = v357; /*0x1067ce2f9*/
          *(_QWORD *)&v721 = v356; /*0x1067ce2fd*/
          std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ce300*/
          __src[1] = v354; /*0x1067ce309*/
          if ( (v740 & 1) != 0 ) /*0x1067ce30d*/
            operator delete(a1: v741); /*0x1067ce313*/
        }
        else
        {
          *((_QWORD *)__src[1] + 2) = v741; /*0x1067ce1f5*/
          *(_OWORD *)v346 = v740; /*0x1067ce1fe*/
          v346[3] = v345; /*0x1067ce204*/
          __src[1] = v346 + 4; /*0x1067ce20e*/
        }
        if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ce31d*/
          v358 = (const char *)qword_10D50FFF8; /*0x1067ce31f*/
        else
          v358 = (char *)&RBX::Analytics::location + 1; /*0x1067ce326*/
        RBX::format(this: (RBX *)&v740, a2: "PlaceLauncherStartToFetchedScriptTime_Country_%s_Mobile", v358); /*0x1067ce338*/
        v359 = *((double *)this + 25) /* +200: NO 2022 FIELD */ - *((double *)this + 24) /* +192: NO 2022 FIELD */; /*0x1067ce345*/
        v360 = (double *)__src[1]; /*0x1067ce34d*/
        if ( __src[1] >= v743[0] ) /*0x1067ce358*/
        {
          v739 = *((double *)this + 25) /* +200: NO 2022 FIELD */ - *((double *)this + 24) /* +192: NO 2022 FIELD */; /*0x1067ce380*/
          v361 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067ce38c*/
          if ( (unsigned __int64)(v361 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067ce3a1*/
            std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0e38*/
          v362 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067ce3ad*/
          if ( v362 <= v361 + 1 ) /*0x1067ce3b4*/
            v362 = v361 + 1; /*0x1067ce3b4*/
          if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067ce3c5*/
            v362 = 0x7FFFFFFFFFFFFFFLL; /*0x1067ce3c5*/
          v724 = v743; /*0x1067ce3cd*/
          if ( v362 != 0 ) /*0x1067ce3d7*/
          {
            v363 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067ce3d9*/
            v365 = v364; /*0x1067ce3de*/
          }
          else
          {
            v363 = 0; /*0x1067ce3e3*/
            v365 = 0; /*0x1067ce3e5*/
          }
          v366 = v363 + 32 * v361; /*0x1067ce3ec*/
          v367 = (void *)(v363 + 32 * v365); /*0x1067ce3f4*/
          v368 = (void *)(v366 + 32); /*0x1067ce3fe*/
          *(_QWORD *)(v366 + 16) = v741; /*0x1067ce402*/
          *(_OWORD *)v366 = v740; /*0x1067ce40a*/
          v740 = 0; /*0x1067ce412*/
          v741 = nullptr; /*0x1067ce416*/
          *(double *)(v366 + 24) = v739; /*0x1067ce423*/
          v369 = (void *)(v366 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ce434*/
          memcpy(__dst: v369, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ce43a*/
          v370 = (RBX *)__src[0]; /*0x1067ce43f*/
          v371 = v743[0]; /*0x1067ce443*/
          __src[0] = v369; /*0x1067ce447*/
          *((_QWORD *)&v721 + 1) = v370; /*0x1067ce452*/
          __src[1] = v368; /*0x1067ce456*/
          v722 = v370; /*0x1067ce45a*/
          v743[0] = v367; /*0x1067ce45e*/
          v723 = v371; /*0x1067ce462*/
          *(_QWORD *)&v721 = v370; /*0x1067ce466*/
          std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ce469*/
          __src[1] = v368; /*0x1067ce472*/
          if ( (v740 & 1) != 0 ) /*0x1067ce476*/
            operator delete(a1: v741); /*0x1067ce47c*/
        }
        else
        {
          *((_QWORD *)__src[1] + 2) = v741; /*0x1067ce35e*/
          *(_OWORD *)v360 = v740; /*0x1067ce367*/
          v360[3] = v359; /*0x1067ce36d*/
          __src[1] = v360 + 4; /*0x1067ce377*/
        }
        if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ce486*/
          v372 = (const char *)qword_10D50FFF8; /*0x1067ce488*/
        else
          v372 = (char *)&RBX::Analytics::location + 1; /*0x1067ce48f*/
        RBX::format(this: (RBX *)&v740, a2: "FetchedScriptToPlayerConfTime_Country_%s_Mobile", v372); /*0x1067ce4a1*/
        v373 = *((double *)this + 26) /* +208: NO 2022 FIELD */ - *((double *)this + 25) /* +200: NO 2022 FIELD */; /*0x1067ce4ae*/
        v374 = (double *)__src[1]; /*0x1067ce4b6*/
        if ( __src[1] >= v743[0] ) /*0x1067ce4c1*/
        {
          v739 = *((double *)this + 26) /* +208: NO 2022 FIELD */ - *((double *)this + 25) /* +200: NO 2022 FIELD */; /*0x1067ce4e9*/
          v375 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067ce4f5*/
          if ( (unsigned __int64)(v375 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067ce50a*/
            std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0e3f*/
          v376 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067ce516*/
          if ( v376 <= v375 + 1 ) /*0x1067ce51d*/
            v376 = v375 + 1; /*0x1067ce51d*/
          if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067ce52e*/
            v376 = 0x7FFFFFFFFFFFFFFLL; /*0x1067ce52e*/
          v724 = v743; /*0x1067ce536*/
          if ( v376 != 0 ) /*0x1067ce540*/
          {
            v377 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067ce542*/
            v379 = v378; /*0x1067ce547*/
          }
          else
          {
            v377 = 0; /*0x1067ce54c*/
            v379 = 0; /*0x1067ce54e*/
          }
          v380 = v377 + 32 * v375; /*0x1067ce555*/
          v381 = (void *)(v377 + 32 * v379); /*0x1067ce55d*/
          v382 = (void *)(v380 + 32); /*0x1067ce567*/
          *(_QWORD *)(v380 + 16) = v741; /*0x1067ce56b*/
          *(_OWORD *)v380 = v740; /*0x1067ce573*/
          v740 = 0; /*0x1067ce57b*/
          v741 = nullptr; /*0x1067ce57f*/
          *(double *)(v380 + 24) = v739; /*0x1067ce58c*/
          v383 = (void *)(v380 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ce59d*/
          memcpy(__dst: v383, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ce5a3*/
          v384 = (RBX *)__src[0]; /*0x1067ce5a8*/
          v385 = v743[0]; /*0x1067ce5ac*/
          __src[0] = v383; /*0x1067ce5b0*/
          *((_QWORD *)&v721 + 1) = v384; /*0x1067ce5bb*/
          __src[1] = v382; /*0x1067ce5bf*/
          v722 = v384; /*0x1067ce5c3*/
          v743[0] = v381; /*0x1067ce5c7*/
          v723 = v385; /*0x1067ce5cb*/
          *(_QWORD *)&v721 = v384; /*0x1067ce5cf*/
          std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ce5d2*/
          __src[1] = v382; /*0x1067ce5db*/
          if ( (v740 & 1) != 0 ) /*0x1067ce5df*/
            operator delete(a1: v741); /*0x1067ce5e5*/
        }
        else
        {
          *((_QWORD *)__src[1] + 2) = v741; /*0x1067ce4c7*/
          *(_OWORD *)v374 = v740; /*0x1067ce4d0*/
          v374[3] = v373; /*0x1067ce4d6*/
          __src[1] = v374 + 4; /*0x1067ce4e0*/
        }
        if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ce5ef*/
          v386 = (const char *)qword_10D50FFF8; /*0x1067ce5f1*/
        else
          v386 = (char *)&RBX::Analytics::location + 1; /*0x1067ce5f8*/
        RBX::format(this: (RBX *)&v740, a2: "PlayerConfigToConnectTime_Country_%s_Mobile", v386); /*0x1067ce60a*/
        v387 = *((double *)this + 27) /* +216: NO 2022 FIELD */ - *((double *)this + 26) /* +208: NO 2022 FIELD */; /*0x1067ce617*/
        v388 = (double *)__src[1]; /*0x1067ce61f*/
        if ( __src[1] >= v743[0] ) /*0x1067ce62a*/
        {
          v739 = *((double *)this + 27) /* +216: NO 2022 FIELD */ - *((double *)this + 26) /* +208: NO 2022 FIELD */; /*0x1067ce652*/
          v389 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067ce65e*/
          if ( (unsigned __int64)(v389 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067ce673*/
            std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0e46*/
          v390 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067ce67f*/
          if ( v390 <= v389 + 1 ) /*0x1067ce686*/
            v390 = v389 + 1; /*0x1067ce686*/
          if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067ce697*/
            v390 = 0x7FFFFFFFFFFFFFFLL; /*0x1067ce697*/
          v724 = v743; /*0x1067ce69f*/
          if ( v390 != 0 ) /*0x1067ce6a9*/
          {
            v391 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067ce6ab*/
            v393 = v392; /*0x1067ce6b0*/
          }
          else
          {
            v391 = 0; /*0x1067ce6b5*/
            v393 = 0; /*0x1067ce6b7*/
          }
          v394 = v391 + 32 * v389; /*0x1067ce6be*/
          v395 = (void *)(v391 + 32 * v393); /*0x1067ce6c6*/
          v396 = (void *)(v394 + 32); /*0x1067ce6d0*/
          *(_QWORD *)(v394 + 16) = v741; /*0x1067ce6d4*/
          *(_OWORD *)v394 = v740; /*0x1067ce6dc*/
          v740 = 0; /*0x1067ce6e4*/
          v741 = nullptr; /*0x1067ce6e8*/
          *(double *)(v394 + 24) = v739; /*0x1067ce6f5*/
          v397 = (void *)(v394 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ce706*/
          memcpy(__dst: v397, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ce70c*/
          v398 = (RBX *)__src[0]; /*0x1067ce711*/
          v399 = v743[0]; /*0x1067ce715*/
          __src[0] = v397; /*0x1067ce719*/
          *((_QWORD *)&v721 + 1) = v398; /*0x1067ce724*/
          __src[1] = v396; /*0x1067ce728*/
          v722 = v398; /*0x1067ce72c*/
          v743[0] = v395; /*0x1067ce730*/
          v723 = v399; /*0x1067ce734*/
          *(_QWORD *)&v721 = v398; /*0x1067ce738*/
          std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ce73b*/
          __src[1] = v396; /*0x1067ce744*/
          if ( (v740 & 1) != 0 ) /*0x1067ce748*/
            operator delete(a1: v741); /*0x1067ce74e*/
        }
        else
        {
          *((_QWORD *)__src[1] + 2) = v741; /*0x1067ce630*/
          *(_OWORD *)v388 = v740; /*0x1067ce639*/
          v388[3] = v387; /*0x1067ce63f*/
          __src[1] = v388 + 4; /*0x1067ce649*/
        }
        if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ce758*/
          v400 = (const char *)qword_10D50FFF8; /*0x1067ce75a*/
        else
          v400 = (char *)&RBX::Analytics::location + 1; /*0x1067ce761*/
        RBX::format(this: (RBX *)&v740, a2: "ConnectToReceivedGlobalsTime_Country_%s_Mobile", v400); /*0x1067ce773*/
        v401 = *((double *)this + 28) /* +224: NO 2022 FIELD */ - *((double *)this + 27) /* +216: NO 2022 FIELD */; /*0x1067ce780*/
        v402 = (double *)__src[1]; /*0x1067ce788*/
        if ( __src[1] >= v743[0] ) /*0x1067ce793*/
        {
          v739 = *((double *)this + 28) /* +224: NO 2022 FIELD */ - *((double *)this + 27) /* +216: NO 2022 FIELD */; /*0x1067ce7bb*/
          v403 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067ce7c7*/
          if ( (unsigned __int64)(v403 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067ce7dc*/
            std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0e4d*/
          v404 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067ce7e8*/
          if ( v404 <= v403 + 1 ) /*0x1067ce7ef*/
            v404 = v403 + 1; /*0x1067ce7ef*/
          if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067ce800*/
            v404 = 0x7FFFFFFFFFFFFFFLL; /*0x1067ce800*/
          v724 = v743; /*0x1067ce808*/
          if ( v404 != 0 ) /*0x1067ce812*/
          {
            v405 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067ce814*/
            v407 = v406; /*0x1067ce819*/
          }
          else
          {
            v405 = 0; /*0x1067ce81e*/
            v407 = 0; /*0x1067ce820*/
          }
          v408 = v405 + 32 * v403; /*0x1067ce827*/
          v409 = (void *)(v405 + 32 * v407); /*0x1067ce82f*/
          v410 = (void *)(v408 + 32); /*0x1067ce839*/
          *(_QWORD *)(v408 + 16) = v741; /*0x1067ce83d*/
          *(_OWORD *)v408 = v740; /*0x1067ce845*/
          v740 = 0; /*0x1067ce84d*/
          v741 = nullptr; /*0x1067ce851*/
          *(double *)(v408 + 24) = v739; /*0x1067ce85e*/
          v411 = (void *)(v408 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ce86f*/
          memcpy(__dst: v411, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ce875*/
          v412 = (RBX *)__src[0]; /*0x1067ce87a*/
          v413 = v743[0]; /*0x1067ce87e*/
          __src[0] = v411; /*0x1067ce882*/
          *((_QWORD *)&v721 + 1) = v412; /*0x1067ce88d*/
          __src[1] = v410; /*0x1067ce891*/
          v722 = v412; /*0x1067ce895*/
          v743[0] = v409; /*0x1067ce899*/
          v723 = v413; /*0x1067ce89d*/
          *(_QWORD *)&v721 = v412; /*0x1067ce8a1*/
          std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ce8a4*/
          __src[1] = v410; /*0x1067ce8ad*/
          if ( (v740 & 1) != 0 ) /*0x1067ce8b1*/
            operator delete(a1: v741); /*0x1067ce8b7*/
        }
        else
        {
          *((_QWORD *)__src[1] + 2) = v741; /*0x1067ce799*/
          *(_OWORD *)v402 = v740; /*0x1067ce7a2*/
          v402[3] = v401; /*0x1067ce7a8*/
          __src[1] = v402 + 4; /*0x1067ce7b2*/
        }
        if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ce8c1*/
          v414 = (const char *)qword_10D50FFF8; /*0x1067ce8c3*/
        else
          v414 = (char *)&RBX::Analytics::location + 1; /*0x1067ce8ca*/
        RBX::format(this: (RBX *)&v740, a2: "ReceivedGlobalToGameLoadTime_Country_%s_Mobile", v414); /*0x1067ce8dc*/
        v415 = *((double *)this + 29) /* +232: NO 2022 FIELD */ - *((double *)this + 28) /* +224: NO 2022 FIELD */; /*0x1067ce8e9*/
        v416 = (double *)__src[1]; /*0x1067ce8f1*/
        if ( __src[1] >= v743[0] ) /*0x1067ce8fc*/
        {
          v739 = *((double *)this + 29) /* +232: NO 2022 FIELD */ - *((double *)this + 28) /* +224: NO 2022 FIELD */; /*0x1067ce924*/
          v417 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067ce930*/
          if ( (unsigned __int64)(v417 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067ce945*/
            std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0e54*/
          v418 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067ce951*/
          if ( v418 <= v417 + 1 ) /*0x1067ce958*/
            v418 = v417 + 1; /*0x1067ce958*/
          if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067ce969*/
            v418 = 0x7FFFFFFFFFFFFFFLL; /*0x1067ce969*/
          v724 = v743; /*0x1067ce971*/
          if ( v418 != 0 ) /*0x1067ce97b*/
          {
            v419 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067ce97d*/
            v421 = v420; /*0x1067ce982*/
          }
          else
          {
            v419 = 0; /*0x1067ce987*/
            v421 = 0; /*0x1067ce989*/
          }
          v422 = v419 + 32 * v417; /*0x1067ce990*/
          v423 = (void *)(v419 + 32 * v421); /*0x1067ce998*/
          v424 = (void *)(v422 + 32); /*0x1067ce9a2*/
          *(_QWORD *)(v422 + 16) = v741; /*0x1067ce9a6*/
          *(_OWORD *)v422 = v740; /*0x1067ce9ae*/
          v740 = 0; /*0x1067ce9b6*/
          v741 = nullptr; /*0x1067ce9ba*/
          *(double *)(v422 + 24) = v739; /*0x1067ce9c7*/
          v425 = (void *)(v422 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ce9d8*/
          memcpy(__dst: v425, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ce9de*/
          v426 = (RBX *)__src[0]; /*0x1067ce9e3*/
          v427 = v743[0]; /*0x1067ce9e7*/
          __src[0] = v425; /*0x1067ce9eb*/
          *((_QWORD *)&v721 + 1) = v426; /*0x1067ce9f6*/
          __src[1] = v424; /*0x1067ce9fa*/
          v722 = v426; /*0x1067ce9fe*/
          v743[0] = v423; /*0x1067cea02*/
          v723 = v427; /*0x1067cea06*/
          *(_QWORD *)&v721 = v426; /*0x1067cea0a*/
          std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cea0d*/
          __src[1] = v424; /*0x1067cea16*/
          if ( (v740 & 1) != 0 ) /*0x1067cea1a*/
            operator delete(a1: v741); /*0x1067cea20*/
        }
        else
        {
          *((_QWORD *)__src[1] + 2) = v741; /*0x1067ce902*/
          *(_OWORD *)v416 = v740; /*0x1067ce90b*/
          v416[3] = v415; /*0x1067ce911*/
          __src[1] = v416 + 4; /*0x1067ce91b*/
        }
        if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067cea2a*/
          v428 = (const char *)qword_10D50FFF8; /*0x1067cea2c*/
        else
          v428 = (char *)&RBX::Analytics::location + 1; /*0x1067cea33*/
        RBX::format(this: (RBX *)&v740, a2: "GameLoadToGameJoinTime_Country_%s_Mobile", v428); /*0x1067cea45*/
        v429 = *((double *)this + 30) /* +240: NO 2022 FIELD */ - *((double *)this + 29) /* +232: NO 2022 FIELD */; /*0x1067cea52*/
        v430 = (double *)__src[1]; /*0x1067cea5a*/
        if ( __src[1] >= v743[0] ) /*0x1067cea65*/
        {
          v739 = *((double *)this + 30) /* +240: NO 2022 FIELD */ - *((double *)this + 29) /* +232: NO 2022 FIELD */; /*0x1067cea8d*/
          v431 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cea99*/
          if ( (unsigned __int64)(v431 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067ceaae*/
            std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0e5b*/
          v432 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067ceaba*/
          if ( v432 <= v431 + 1 ) /*0x1067ceac1*/
            v432 = v431 + 1; /*0x1067ceac1*/
          if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cead2*/
            v432 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cead2*/
          v724 = v743; /*0x1067ceada*/
          if ( v432 != 0 ) /*0x1067ceae4*/
          {
            v433 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067ceae6*/
            v435 = v434; /*0x1067ceaeb*/
          }
          else
          {
            v433 = 0; /*0x1067ceaf0*/
            v435 = 0; /*0x1067ceaf2*/
          }
          v436 = v433 + 32 * v431; /*0x1067ceaf9*/
          v437 = (void *)(v433 + 32 * v435); /*0x1067ceb01*/
          v438 = (void *)(v436 + 32); /*0x1067ceb0b*/
          *(_QWORD *)(v436 + 16) = v741; /*0x1067ceb0f*/
          *(_OWORD *)v436 = v740; /*0x1067ceb17*/
          v740 = 0; /*0x1067ceb1f*/
          v741 = nullptr; /*0x1067ceb23*/
          *(double *)(v436 + 24) = v739; /*0x1067ceb30*/
          v439 = (void *)(v436 - ((char *)__src[1] - (char *)__src[0])); /*0x1067ceb41*/
          memcpy(__dst: v439, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067ceb47*/
          v440 = (RBX *)__src[0]; /*0x1067ceb4c*/
          v441 = v743[0]; /*0x1067ceb50*/
          __src[0] = v439; /*0x1067ceb54*/
          *((_QWORD *)&v721 + 1) = v440; /*0x1067ceb5f*/
          __src[1] = v438; /*0x1067ceb63*/
          v722 = v440; /*0x1067ceb67*/
          v743[0] = v437; /*0x1067ceb6b*/
          v723 = v441; /*0x1067ceb6f*/
          *(_QWORD *)&v721 = v440; /*0x1067ceb73*/
          std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067ceb76*/
          __src[1] = v438; /*0x1067ceb7f*/
          if ( (v740 & 1) != 0 ) /*0x1067ceb83*/
            operator delete(a1: v741); /*0x1067ceb89*/
        }
        else
        {
          *((_QWORD *)__src[1] + 2) = v741; /*0x1067cea6b*/
          *(_OWORD *)v430 = v740; /*0x1067cea74*/
          v430[3] = v429; /*0x1067cea7a*/
          __src[1] = v430 + 4; /*0x1067cea84*/
        }
        if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ceb93*/
          v442 = (const char *)qword_10D50FFF8; /*0x1067ceb95*/
        else
          v442 = (char *)&RBX::Analytics::location + 1; /*0x1067ceb9c*/
        RBX::format(this: (RBX *)&v740, a2: "GameJoinToAvatarLoadTime_Country_%s_Mobile", v442); /*0x1067cebae*/
        v443 = *((double *)this + 36) /* +288: NO 2022 FIELD */ - *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cebbb*/
        v444 = (double *)__src[1]; /*0x1067cebc3*/
        if ( __src[1] >= v743[0] ) /*0x1067cebce*/
        {
          v739 = *((double *)this + 36) /* +288: NO 2022 FIELD */ - *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cebf6*/
          v445 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cec02*/
          if ( (unsigned __int64)(v445 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cec17*/
            std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0e62*/
          v446 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cec23*/
          if ( v446 <= v445 + 1 ) /*0x1067cec2a*/
            v446 = v445 + 1; /*0x1067cec2a*/
          if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cec3b*/
            v446 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cec3b*/
          v724 = v743; /*0x1067cec43*/
          if ( v446 != 0 ) /*0x1067cec4d*/
          {
            v447 = ((__int64 (*)(void))std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>)(); /*0x1067cec4f*/
            v449 = v448; /*0x1067cec54*/
          }
          else
          {
            v447 = 0; /*0x1067cec59*/
            v449 = 0; /*0x1067cec5b*/
          }
          v450 = v447 + 32 * v445; /*0x1067cec62*/
          v451 = (void *)(v447 + 32 * v449); /*0x1067cec6a*/
          v452 = (void *)(v450 + 32); /*0x1067cec74*/
          *(_QWORD *)(v450 + 16) = v741; /*0x1067cec78*/
          *(_OWORD *)v450 = v740; /*0x1067cec80*/
          v740 = 0; /*0x1067cec88*/
          v741 = nullptr; /*0x1067cec8c*/
          *(double *)(v450 + 24) = v739; /*0x1067cec99*/
          v453 = (void *)(v450 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cecaa*/
          memcpy(__dst: v453, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cecb0*/
          v454 = (RBX *)__src[0]; /*0x1067cecb5*/
          v455 = v743[0]; /*0x1067cecb9*/
          __src[0] = v453; /*0x1067cecbd*/
          *((_QWORD *)&v721 + 1) = v454; /*0x1067cecc8*/
          __src[1] = v452; /*0x1067ceccc*/
          v722 = v454; /*0x1067cecd0*/
          v743[0] = v451; /*0x1067cecd4*/
          v723 = v455; /*0x1067cecd8*/
          *(_QWORD *)&v721 = v454; /*0x1067cecdc*/
          std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cecdf*/
          __src[1] = v452; /*0x1067cece8*/
          if ( (v740 & 1) != 0 ) /*0x1067cecec*/
            operator delete(a1: v741); /*0x1067cecf2*/
        }
        else
        {
          *((_QWORD *)__src[1] + 2) = v741; /*0x1067cebd4*/
          *(_OWORD *)v444 = v740; /*0x1067cebdd*/
          v444[3] = v443; /*0x1067cebe3*/
          __src[1] = v444 + 4; /*0x1067cebed*/
        }
        v456 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cecfc*/
        if ( (RBX::Analytics::location & 1) != 0 ) /*0x1067ced06*/
          v457 = (const char *)qword_10D50FFF8; /*0x1067ced08*/
        else
          v457 = (char *)&RBX::Analytics::location + 1; /*0x1067ced0f*/
        RBX::format(this: (RBX *)&v740, a2: "AvatarLoadTime_Country_%s_Mobile", v457); /*0x1067ced22*/
        v459 = (double *)__src[1]; /*0x1067ced27*/
        if ( __src[1] >= v743[0] ) /*0x1067ced32*/
        {
          v460 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067ced6c*/
          if ( (unsigned __int64)(v460 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067ced78*/
            std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v458); /*0x1067d0e69*/
          v461 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067ced84*/
          if ( v461 <= v460 + 1 ) /*0x1067ced8b*/
            v461 = v460 + 1; /*0x1067ced8b*/
          if ( (void *)((char *)v743[0] - (char *)__src[0]) < (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067ced9c*/
            v456 = v461; /*0x1067ced9c*/
          v724 = v743; /*0x1067ceda4*/
          if ( v456 != 0 ) /*0x1067cedae*/
          {
            v462 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>( /*0x1067cedb3*/
                     a1: v743,
                     a2: v456,
                     a3: 0x7FFFFFFFFFFFFFE0LL,
                     a4: v461);
            v464 = v463; /*0x1067cedb8*/
          }
          else
          {
            v462 = 0; /*0x1067cedbd*/
            v464 = 0; /*0x1067cedbf*/
          }
          v465 = v462 + 32 * v460; /*0x1067cedc6*/
          v466 = (void *)(v462 + 32 * v464); /*0x1067cedce*/
          v467 = (void *)(v465 + 32); /*0x1067cedd8*/
          *(_QWORD *)(v465 + 16) = v741; /*0x1067ceddc*/
          *(_OWORD *)v465 = v740; /*0x1067cede5*/
          v740 = 0; /*0x1067cedee*/
          v741 = nullptr; /*0x1067cedf2*/
          *(double *)(v465 + 24) = *v732; /*0x1067cee05*/
          v468 = (void *)(v465 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cee17*/
          memcpy(__dst: v468, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cee1d*/
          v469 = (RBX *)__src[0]; /*0x1067cee22*/
          v470 = v743[0]; /*0x1067cee26*/
          __src[0] = v468; /*0x1067cee2a*/
          *((_QWORD *)&v721 + 1) = v469; /*0x1067cee35*/
          __src[1] = v467; /*0x1067cee39*/
          v722 = v469; /*0x1067cee3d*/
          v743[0] = v466; /*0x1067cee41*/
          v723 = v470; /*0x1067cee45*/
          *(_QWORD *)&v721 = v469; /*0x1067cee49*/
          std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cee4c*/
          __src[1] = v467; /*0x1067cee55*/
          if ( (v740 & 1) != 0 ) /*0x1067cee59*/
            operator delete(a1: v741); /*0x1067cee5f*/
        }
        else
        {
          *((_QWORD *)__src[1] + 2) = v741; /*0x1067ced38*/
          *(_OWORD *)v459 = v740; /*0x1067ced41*/
          v459[3] = *v732; /*0x1067ced51*/
          __src[1] = v459 + 4; /*0x1067ced5c*/
        }
      }
      if ( (v737 & 1) != 0 ) /*0x1067cee68*/
        operator delete(a1: v738); /*0x1067cee6e*/
    }
    if ( __src[0] != __src[1] ) /*0x1067cee7b*/
      RBX::Analytics::EphemeralCounter::bulkReportStats(a1: __src, a2: 0); /*0x1067cee83*/
    if ( (v735[0] & 1) != 0 ) /*0x1067cee8f*/
      operator delete(a1: v736); /*0x1067cee98*/
    *(_QWORD *)&v721 = __src; /*0x1067ceea8*/
    std::vector<std::pair<std::string,double>>::__destroy_vector::operator()[abi:ne200100](); /*0x1067ceeab*/
  }
  if ( (DFString::SendJoinTimeStatsHundPrecCountryOverride & 1) != 0 ) /*0x1067ceeb9*/
    v471 = qword_10D80B890; /*0x1067ceebb*/
  else
    v471 = (unsigned __int8)DFString::SendJoinTimeStatsHundPrecCountryOverride >> 1; /*0x1067ceec4*/
  v472 = DFInt::SendJoinTimeStatsToDiag_HundredthsPercentage; /*0x1067ceec6*/
  if ( v471 != 0 ) /*0x1067ceed0*/
  {
    std::string::basic_string[abi:ne200100]<0>(a1: &v721, a2: ",", a3: v14, a4: v15); /*0x1067ceee0*/
    v473 = RBX::Network::getPairIntValue( /*0x1067ceeff*/
             a1: &RBX::Analytics::location,
             a2: &DFString::SendJoinTimeStatsHundPrecCountryOverride,
             a3: &v721);
    if ( (v721 & 1) != 0 ) /*0x1067cef09*/
      operator delete(a1: v722); /*0x1067cef12*/
    if ( v473 != -1 ) /*0x1067cef1b*/
      v472 = v473; /*0x1067cef1b*/
  }
  RBX::GetBaseURL(this: v16); /*0x1067cef1f*/
  RBX::Url::fromString(this: (RBX::Url *)&v721); /*0x1067cef45*/
  v475 = RBX::Http::isRobloxChineseDomain(this: (RBX::Http *)&v721, a2: v474); /*0x1067cef56*/
  if ( (v730 & 1) != 0 ) /*0x1067cef60*/
    operator delete(a1: v731); /*0x1067cef69*/
  if ( (v728 & 1) != 0 ) /*0x1067cef75*/
    operator delete(a1: v729); /*0x1067cef7e*/
  if ( (v726 & 1) != 0 ) /*0x1067cef8a*/
    operator delete(a1: v727); /*0x1067cef93*/
  if ( ((unsigned __int8)v723 & 1) != 0 ) /*0x1067cef9f*/
    operator delete(a1: v725); /*0x1067cefa8*/
  if ( (v721 & 1) != 0 ) /*0x1067cefb4*/
    operator delete(a1: v722); /*0x1067cefbd*/
  v476 = DFInt::SendJoinTimeStatsHundPrecLuobuOverride; /*0x1067cefc2*/
  v477 = rand(); /*0x1067cefc9*/
  if ( v476 == -1 ) /*0x1067cefd2*/
    v476 = v472; /*0x1067cefd2*/
  if ( v475 == 0 ) /*0x1067cefd9*/
    v476 = v472; /*0x1067cefd9*/
  if ( v477 % 10000 >= v476 ) /*0x1067ceffe*/
    goto LABEL_665; /*0x1067ceffe*/
  *(_OWORD *)__src = 0; /*0x1067cf00c*/
  v743[0] = nullptr; /*0x1067cf010*/
  v478 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf01b*/
  *(float *)&v721 = v478; /*0x1067cf02a*/
  __src[1] = (void *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[11],float>( /*0x1067cf03a*/
                       a1: __src,
                       a2: "LaunchTime");
  std::operator+<char>(a1: v735, a2: "LaunchTime_Country_", &RBX::Analytics::location); /*0x1067cf053*/
  v481 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf05c*/
  v482 = (double *)__src[1]; /*0x1067cf06e*/
  if ( __src[1] >= v743[0] ) /*0x1067cf078*/
  {
    *(float *)&v739 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf0aa*/
    v484 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cf0b6*/
    v485 = v484 + 1; /*0x1067cf0ba*/
    if ( (unsigned __int64)(v484 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cf0c1*/
      std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0d69*/
    v486 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cf0cd*/
    if ( v486 <= v485 ) /*0x1067cf0d4*/
      v486 = v484 + 1; /*0x1067cf0d4*/
    if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cf0e5*/
      v486 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cf0e5*/
    v724 = v743; /*0x1067cf0e9*/
    if ( v486 != 0 ) /*0x1067cf0f3*/
    {
      v487 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>( /*0x1067cf0f8*/
               a1: v743,
               a2: v486,
               a3: v485,
               a4: 0x7FFFFFFFFFFFFFE0LL);
      v489 = v488; /*0x1067cf0fd*/
    }
    else
    {
      v487 = 0; /*0x1067cf102*/
      v489 = 0; /*0x1067cf104*/
    }
    v490 = v487 + 32 * v484; /*0x1067cf10b*/
    v491 = (void *)(v487 + 32 * v489); /*0x1067cf113*/
    v483 = (double *)(v490 + 32); /*0x1067cf120*/
    *(_QWORD *)(v490 + 16) = v736; /*0x1067cf124*/
    *(_OWORD *)v490 = *(_OWORD *)v735; /*0x1067cf12f*/
    *(_OWORD *)v735 = 0; /*0x1067cf137*/
    v736 = nullptr; /*0x1067cf13e*/
    *(double *)(v490 + 24) = *(float *)&v739; /*0x1067cf151*/
    v492 = (void *)(v490 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cf162*/
    memcpy(__dst: v492, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cf168*/
    v493 = (RBX *)__src[0]; /*0x1067cf16d*/
    v494 = v743[0]; /*0x1067cf171*/
    __src[0] = v492; /*0x1067cf175*/
    *((_QWORD *)&v721 + 1) = v493; /*0x1067cf180*/
    __src[1] = v483; /*0x1067cf184*/
    v722 = v493; /*0x1067cf188*/
    v743[0] = v491; /*0x1067cf18c*/
    v723 = v494; /*0x1067cf190*/
    *(_QWORD *)&v721 = v493; /*0x1067cf194*/
    std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cf197*/
    __src[1] = v483; /*0x1067cf1a3*/
    if ( (v735[0] & 1) != 0 ) /*0x1067cf1ab*/
    {
      operator delete(a1: v736); /*0x1067cf1b4*/
      v483 = (double *)__src[1]; /*0x1067cf1b9*/
    }
  }
  else
  {
    *((_QWORD *)__src[1] + 2) = v736; /*0x1067cf081*/
    *(_OWORD *)v482 = *(_OWORD *)v735; /*0x1067cf08c*/
    v482[3] = v481; /*0x1067cf097*/
    v483 = v482 + 4; /*0x1067cf09d*/
    __src[1] = v483; /*0x1067cf0a1*/
  }
  if ( v475 != 0 ) /*0x1067cf1c0*/
  {
    v495 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf1c5*/
    *(float *)&v721 = v495; /*0x1067cf1cd*/
    if ( v483 >= v743[0] ) /*0x1067cf1d9*/
    {
      v483 = (double *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[17],float>( /*0x1067cf218*/
                         a1: __src,
                         a2: "LaunchTime_Luobu",
                         a3: &v721);
    }
    else
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v483, a2: "LaunchTime_Luobu", a3: v479, a4: v480); /*0x1067cf1e5*/
      v483[3] = *(float *)&v721; /*0x1067cf1f5*/
      v483 += 4; /*0x1067cf1fb*/
    }
    __src[1] = v483; /*0x1067cf21b*/
  }
  v496 = *((double *)this + 36) /* +288: NO 2022 FIELD */; /*0x1067cf222*/
  v497 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf22d*/
  *(float *)&v721 = v496 - v497; /*0x1067cf239*/
  if ( v483 >= v743[0] ) /*0x1067cf245*/
  {
    v498 = (void *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[18],float>( /*0x1067cf284*/
                     a1: __src,
                     a2: "AssetOnlyLoadTime",
                     a3: &v721);
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: v483, a2: "AssetOnlyLoadTime", a3: v479, a4: v480); /*0x1067cf251*/
    v483[3] = *(float *)&v721; /*0x1067cf261*/
    v498 = v483 + 4; /*0x1067cf267*/
  }
  __src[1] = v498; /*0x1067cf287*/
  std::operator+<char>(a1: v735, a2: "AssetOnlyLoadTime_Country_", &RBX::Analytics::location); /*0x1067cf2a0*/
  v501 = *((double *)this + 36) /* +288: NO 2022 FIELD */; /*0x1067cf2a8*/
  v502 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf2b3*/
  v503 = v501 - v502; /*0x1067cf2bb*/
  v504 = (double *)__src[1]; /*0x1067cf2bf*/
  if ( __src[1] >= v743[0] ) /*0x1067cf2ca*/
  {
    *(float *)&v739 = v503; /*0x1067cf2fd*/
    v505 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cf309*/
    v506 = v505 + 1; /*0x1067cf30d*/
    if ( (unsigned __int64)(v505 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cf31e*/
      std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0d73*/
    v507 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cf32a*/
    if ( v507 <= v506 ) /*0x1067cf331*/
      v507 = v505 + 1; /*0x1067cf331*/
    if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cf342*/
      v507 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cf342*/
    v724 = v743; /*0x1067cf346*/
    if ( v507 != 0 ) /*0x1067cf350*/
    {
      v508 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>( /*0x1067cf355*/
               a1: v743,
               a2: v507,
               a3: v506,
               a4: 0x7FFFFFFFFFFFFFE0LL);
      v510 = v509; /*0x1067cf35a*/
    }
    else
    {
      v508 = 0; /*0x1067cf35f*/
      v510 = 0; /*0x1067cf361*/
    }
    v511 = v508 + 32 * v505; /*0x1067cf368*/
    v512 = (void *)(v508 + 32 * v510); /*0x1067cf370*/
    v513 = (void *)(v511 + 32); /*0x1067cf37d*/
    *(_QWORD *)(v511 + 16) = v736; /*0x1067cf381*/
    *(_OWORD *)v511 = *(_OWORD *)v735; /*0x1067cf38c*/
    *(_OWORD *)v735 = 0; /*0x1067cf394*/
    v736 = nullptr; /*0x1067cf39b*/
    *(double *)(v511 + 24) = *(float *)&v739; /*0x1067cf3ae*/
    v514 = (void *)(v511 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cf3bf*/
    memcpy(__dst: v514, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cf3c5*/
    v515 = (RBX *)__src[0]; /*0x1067cf3ca*/
    v516 = v743[0]; /*0x1067cf3ce*/
    __src[0] = v514; /*0x1067cf3d2*/
    *((_QWORD *)&v721 + 1) = v515; /*0x1067cf3dd*/
    __src[1] = v513; /*0x1067cf3e1*/
    v722 = v515; /*0x1067cf3e5*/
    v743[0] = v512; /*0x1067cf3e9*/
    v723 = v516; /*0x1067cf3ed*/
    *(_QWORD *)&v721 = v515; /*0x1067cf3f1*/
    std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cf3f4*/
    __src[1] = v513; /*0x1067cf400*/
    if ( (v735[0] & 1) != 0 ) /*0x1067cf408*/
      operator delete(a1: v736); /*0x1067cf411*/
  }
  else
  {
    *((_QWORD *)__src[1] + 2) = v736; /*0x1067cf2d3*/
    *(_OWORD *)v504 = *(_OWORD *)v735; /*0x1067cf2de*/
    v504[3] = v503; /*0x1067cf2ea*/
    __src[1] = v504 + 4; /*0x1067cf2f4*/
  }
  if ( v475 == 0 ) /*0x1067cf419*/
  {
    v520 = *((double *)this + 36) /* +288: NO 2022 FIELD */; /*0x1067cf45b*/
    v521 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf466*/
    *(float *)&v721 = v520 - v521; /*0x1067cf472*/
    v519 = (double *)__src[1]; /*0x1067cf47a*/
    if ( __src[1] < v743[0] ) /*0x1067cf482*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: __src[1], a2: "AssetOnlyLoadTime_NonLuobu", a3: v499, a4: v500); /*0x1067cf48e*/
      goto LABEL_590; /*0x1067cf48e*/
    }
    v523 = std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[27],float>( /*0x1067cf4d5*/
             a1: __src,
             a2: "AssetOnlyLoadTime_NonLuobu",
             a3: &v721);
LABEL_593:
    v522 = (void *)v523; /*0x1067cf4da*/
    goto LABEL_594; /*0x1067cf4da*/
  }
  v517 = *((double *)this + 36) /* +288: NO 2022 FIELD */; /*0x1067cf41e*/
  v518 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf429*/
  *(float *)&v721 = v517 - v518; /*0x1067cf435*/
  v519 = (double *)__src[1]; /*0x1067cf43d*/
  if ( __src[1] >= v743[0] ) /*0x1067cf445*/
  {
    v523 = std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[24],float>( /*0x1067cf4bc*/
             a1: __src,
             a2: "AssetOnlyLoadTime_Luobu",
             a3: &v721);
    goto LABEL_593; /*0x1067cf4c1*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1: __src[1], a2: "AssetOnlyLoadTime_Luobu", a3: v499, a4: v500); /*0x1067cf451*/
LABEL_590:
  v519[3] = *(float *)&v721; /*0x1067cf493*/
  v522 = v519 + 4; /*0x1067cf4a4*/
LABEL_594:
  __src[1] = v522; /*0x1067cf4dd*/
  if ( (unsigned __int8)isMobile() != 0 ) /*0x1067cf4e8*/
  {
    v526 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf4f1*/
    *(float *)&v721 = v526; /*0x1067cf4f9*/
    v527 = (double *)__src[1]; /*0x1067cf501*/
    if ( __src[1] >= v743[0] ) /*0x1067cf509*/
    {
      v528 = (void *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[18],float>( /*0x1067cf548*/
                       a1: __src,
                       a2: "LaunchTime_Mobile",
                       a3: &v721);
    }
    else
    {
      std::string::basic_string[abi:ne200100]<0>(a1: __src[1], a2: "LaunchTime_Mobile", a3: v524, a4: v525); /*0x1067cf515*/
      v527[3] = *(float *)&v721; /*0x1067cf525*/
      v528 = v527 + 4; /*0x1067cf52b*/
    }
    __src[1] = v528; /*0x1067cf54b*/
    std::operator+<char>(a1: v735, a2: "LaunchTime_Mobile_Country_", &RBX::Analytics::location); /*0x1067cf564*/
    v531 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf56c*/
    v532 = (double *)__src[1]; /*0x1067cf574*/
    if ( __src[1] >= v743[0] ) /*0x1067cf57f*/
    {
      *(float *)&v739 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf5b1*/
      v534 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cf5bd*/
      v535 = v534 + 1; /*0x1067cf5c1*/
      if ( (unsigned __int64)(v534 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cf5d2*/
        std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: 0x7FFFFFFFFFFFFFFLL); /*0x1067d0de1*/
      v536 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cf5de*/
      if ( v536 <= v535 ) /*0x1067cf5e5*/
        v536 = v534 + 1; /*0x1067cf5e5*/
      if ( (void *)((char *)v743[0] - (char *)__src[0]) >= (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cf5f6*/
        v536 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cf5f6*/
      v724 = v743; /*0x1067cf5fa*/
      if ( v536 != 0 ) /*0x1067cf604*/
      {
        v537 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>( /*0x1067cf609*/
                 a1: v743,
                 a2: v536,
                 a3: v535,
                 a4: 0x7FFFFFFFFFFFFFE0LL);
        v539 = v538; /*0x1067cf60e*/
      }
      else
      {
        v537 = 0; /*0x1067cf619*/
        v539 = 0; /*0x1067cf61b*/
      }
      v540 = v537 + 32 * v534; /*0x1067cf622*/
      v541 = (void *)(v537 + 32 * v539); /*0x1067cf62a*/
      v533 = (double *)(v540 + 32); /*0x1067cf637*/
      *(_QWORD *)(v540 + 16) = v736; /*0x1067cf63b*/
      *(_OWORD *)v540 = *(_OWORD *)v735; /*0x1067cf646*/
      *(_OWORD *)v735 = 0; /*0x1067cf64e*/
      v736 = nullptr; /*0x1067cf655*/
      *(double *)(v540 + 24) = *(float *)&v739; /*0x1067cf668*/
      v542 = (void *)(v540 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cf679*/
      memcpy(__dst: v542, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cf67f*/
      v543 = (RBX *)__src[0]; /*0x1067cf684*/
      v544 = v743[0]; /*0x1067cf688*/
      __src[0] = v542; /*0x1067cf68c*/
      *((_QWORD *)&v721 + 1) = v543; /*0x1067cf697*/
      __src[1] = v533; /*0x1067cf69b*/
      v722 = v543; /*0x1067cf69f*/
      v743[0] = v541; /*0x1067cf6a3*/
      v723 = v544; /*0x1067cf6a7*/
      *(_QWORD *)&v721 = v543; /*0x1067cf6ab*/
      std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cf6ae*/
      __src[1] = v533; /*0x1067cf6ba*/
      if ( (v735[0] & 1) != 0 ) /*0x1067cf6c1*/
      {
        operator delete(a1: v736); /*0x1067cf6ca*/
        v533 = (double *)__src[1]; /*0x1067cf6cf*/
      }
    }
    else
    {
      *((_QWORD *)__src[1] + 2) = v736; /*0x1067cf588*/
      *(_OWORD *)v532 = *(_OWORD *)v735; /*0x1067cf593*/
      v532[3] = v531; /*0x1067cf59e*/
      v533 = v532 + 4; /*0x1067cf5a4*/
      __src[1] = v533; /*0x1067cf5a8*/
    }
    v545 = *((double *)this + 36) /* +288: NO 2022 FIELD */; /*0x1067cf6d6*/
    v546 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf6e1*/
    *(float *)&v721 = v545 - v546; /*0x1067cf6ed*/
    if ( v533 >= v743[0] ) /*0x1067cf6f9*/
    {
      v547 = (void *)std::vector<std::pair<std::string,double>>::__emplace_back_slow_path<char const(&)[25],float>( /*0x1067cf738*/
                       a1: __src,
                       a2: "AssetOnlyLoadTime_Mobile",
                       a3: &v721);
    }
    else
    {
      std::string::basic_string[abi:ne200100]<0>(a1: v533, a2: "AssetOnlyLoadTime_Mobile", a3: v529, a4: v530); /*0x1067cf705*/
      v533[3] = *(float *)&v721; /*0x1067cf715*/
      v547 = v533 + 4; /*0x1067cf71b*/
    }
    __src[1] = v547; /*0x1067cf73b*/
    std::operator+<char>(a1: v735, a2: "AssetOnlyLoadTime_Mobile_Country_", &RBX::Analytics::location); /*0x1067cf754*/
    v549 = *((double *)this + 36) /* +288: NO 2022 FIELD */; /*0x1067cf75c*/
    v550 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067cf767*/
    v551 = v549 - v550; /*0x1067cf76f*/
    v552 = (double *)__src[1]; /*0x1067cf773*/
    if ( __src[1] >= v743[0] ) /*0x1067cf77e*/
    {
      *(float *)&v739 = v551; /*0x1067cf7b3*/
      v553 = ((char *)__src[1] - (char *)__src[0]) >> 5; /*0x1067cf7bf*/
      v554 = 0x7FFFFFFFFFFFFFFLL; /*0x1067cf7c8*/
      if ( (unsigned __int64)(v553 + 1) > 0x7FFFFFFFFFFFFFFLL ) /*0x1067cf7d5*/
        std::vector<std::pair<std::string,double>>::__throw_length_error[abi:ne200100](a1: v548); /*0x1067d0df9*/
      v555 = ((char *)v743[0] - (char *)__src[0]) >> 4; /*0x1067cf7e1*/
      if ( v555 <= v553 + 1 ) /*0x1067cf7e8*/
        v555 = v553 + 1; /*0x1067cf7e8*/
      if ( (void *)((char *)v743[0] - (char *)__src[0]) < (void *)0x7FFFFFFFFFFFFFE0LL ) /*0x1067cf7f9*/
        v554 = v555; /*0x1067cf7f9*/
      v724 = v743; /*0x1067cf7fd*/
      if ( v554 != 0 ) /*0x1067cf807*/
      {
        v556 = std::__allocate_at_least[abi:ne200100]<std::allocator<std::pair<std::string,double>>>( /*0x1067cf80c*/
                 a1: v743,
                 a2: v554,
                 a3: 0x7FFFFFFFFFFFFFE0LL,
                 a4: v555);
        v558 = v557; /*0x1067cf811*/
      }
      else
      {
        v556 = 0; /*0x1067cf816*/
        v558 = 0; /*0x1067cf818*/
      }
      v559 = v556 + 32 * v553; /*0x1067cf81f*/
      v560 = (void *)(v556 + 32 * v558); /*0x1067cf827*/
      v561 = (void *)(v559 + 32); /*0x1067cf834*/
      *(_QWORD *)(v559 + 16) = v736; /*0x1067cf838*/
      *(_OWORD *)v559 = *(_OWORD *)v735; /*0x1067cf844*/
      *(_OWORD *)v735 = 0; /*0x1067cf84d*/
      v736 = nullptr; /*0x1067cf854*/
      *(double *)(v559 + 24) = *(float *)&v739; /*0x1067cf867*/
      v562 = (void *)(v559 - ((char *)__src[1] - (char *)__src[0])); /*0x1067cf879*/
      memcpy(__dst: v562, __src: __src[0], __n: (char *)__src[1] - (char *)__src[0]); /*0x1067cf87f*/
      v563 = (RBX *)__src[0]; /*0x1067cf884*/
      v564 = v743[0]; /*0x1067cf888*/
      __src[0] = v562; /*0x1067cf88c*/
      *((_QWORD *)&v721 + 1) = v563; /*0x1067cf897*/
      __src[1] = v561; /*0x1067cf89b*/
      v722 = v563; /*0x1067cf89f*/
      v743[0] = v560; /*0x1067cf8a3*/
      v723 = v564; /*0x1067cf8a7*/
      *(_QWORD *)&v721 = v563; /*0x1067cf8ab*/
      std::__split_buffer<std::pair<std::string,double>>::~__split_buffer(); /*0x1067cf8ae*/
      __src[1] = v561; /*0x1067cf8ba*/
      if ( (v735[0] & 1) != 0 ) /*0x1067cf8be*/
        operator delete(a1: v736); /*0x1067cf8c7*/
    }
    else
    {
      *((_QWORD *)__src[1] + 2) = v736; /*0x1067cf787*/
      *(_OWORD *)v552 = *(_OWORD *)v735; /*0x1067cf793*/
      v552[3] = v551; /*0x1067cf79f*/
      __src[1] = v552 + 4; /*0x1067cf7aa*/
    }
  }
  if ( DFFlag::DebugLaunchTimeByCountryPlaceSpecific == 1 ) /*0x1067cf8d3*/
  {
    v565 = DFFlag::DebugLaunchTimeByCountryPlaceSpecificAddPlatform; /*0x1067cf8d9*/
    v566 = *(_QWORD *)(*((_QWORD *)this + 3) /* +24 likely .dataModel -- UNVERIFIED */ + 840LL); /*0x1067cf8e4*/
    std::string::basic_string[abi:ne200100]<0>(a1: v680, a2: "LaunchTime", a3: v524, a4: v525); /*0x1067cf8f9*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cf91b*/
      a1: __src,
      a2: v680,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 30) /* +240: NO 2022 FIELD */);
    if ( (v680[0] & 1) != 0 ) /*0x1067cf927*/
      operator delete(a1: v681); /*0x1067cf930*/
    std::string::basic_string[abi:ne200100]<0>(a1: v682, a2: "StartGameTime", a3: v567, a4: v568); /*0x1067cf943*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cf961*/
      a1: __src,
      a2: v682,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 23) /* +184: NO 2022 FIELD */);
    if ( (v682[0] & 1) != 0 ) /*0x1067cf96d*/
      operator delete(a1: v683); /*0x1067cf976*/
    std::string::basic_string[abi:ne200100]<0>(a1: v684, a2: "PlaceLauncherStart", a3: v569, a4: v570); /*0x1067cf989*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cf9a7*/
      a1: __src,
      a2: v684,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 24) /* +192: NO 2022 FIELD */);
    if ( (v684[0] & 1) != 0 ) /*0x1067cf9b3*/
      operator delete(a1: v685); /*0x1067cf9bc*/
    std::string::basic_string[abi:ne200100]<0>(a1: v686, a2: "FetchedJoinScriptTime", a3: v571, a4: v572); /*0x1067cf9cf*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cf9ed*/
      a1: __src,
      a2: v686,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 25) /* +200: NO 2022 FIELD */);
    if ( (v686[0] & 1) != 0 ) /*0x1067cf9f9*/
      operator delete(a1: v687); /*0x1067cfa02*/
    std::string::basic_string[abi:ne200100]<0>(a1: v688, a2: "PlayerConfigureTime", a3: v573, a4: v574); /*0x1067cfa15*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfa33*/
      a1: __src,
      a2: v688,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 26) /* +208: NO 2022 FIELD */);
    if ( (v688[0] & 1) != 0 ) /*0x1067cfa3f*/
      operator delete(a1: v689); /*0x1067cfa48*/
    std::string::basic_string[abi:ne200100]<0>(a1: v690, a2: "ConnectTime", a3: v575, a4: v576); /*0x1067cfa5b*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfa79*/
      a1: __src,
      a2: v690,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 27) /* +216: NO 2022 FIELD */);
    if ( (v690[0] & 1) != 0 ) /*0x1067cfa85*/
      operator delete(a1: v691); /*0x1067cfa8e*/
    std::string::basic_string[abi:ne200100]<0>(a1: v692, a2: "ReceivedGlobasTime", a3: v577, a4: v578); /*0x1067cfaa1*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfabf*/
      a1: __src,
      a2: v692,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 28) /* +224: NO 2022 FIELD */);
    if ( (v692[0] & 1) != 0 ) /*0x1067cfacb*/
      operator delete(a1: v693); /*0x1067cfad4*/
    std::string::basic_string[abi:ne200100]<0>(a1: v694, a2: "GameLoadTime", a3: v579, a4: v580); /*0x1067cfae7*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfb05*/
      a1: __src,
      a2: v694,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 29) /* +232: NO 2022 FIELD */);
    if ( (v694[0] & 1) != 0 ) /*0x1067cfb11*/
      operator delete(a1: v695); /*0x1067cfb1a*/
    std::string::basic_string[abi:ne200100]<0>(a1: v696, a2: "GameJoinTime", a3: v581, a4: v582); /*0x1067cfb2d*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfb4b*/
      a1: __src,
      a2: v696,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 30) /* +240: NO 2022 FIELD */);
    if ( (v696[0] & 1) != 0 ) /*0x1067cfb57*/
      operator delete(a1: v697); /*0x1067cfb60*/
    std::string::basic_string[abi:ne200100]<0>(a1: v698, a2: "AvatarLoadTime", a3: v583, a4: v584); /*0x1067cfb73*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation(a1: __src, a2: v698, a3: v565, a4: v566, a5: *v732); /*0x1067cfb94*/
    if ( (v698[0] & 1) != 0 ) /*0x1067cfba0*/
      operator delete(a1: v699); /*0x1067cfba9*/
    std::string::basic_string[abi:ne200100]<0>(a1: v700, a2: "UserClickToStartGameTime", a3: v585, a4: v586); /*0x1067cfbbc*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfbda*/
      a1: __src,
      a2: v700,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 23) /* +184: NO 2022 FIELD */);
    if ( (v700[0] & 1) != 0 ) /*0x1067cfbe6*/
      operator delete(a1: v701); /*0x1067cfbef*/
    std::string::basic_string[abi:ne200100]<0>(a1: v702, a2: "StartGameToPlaceLauncherStartTime", a3: v587, a4: v588); /*0x1067cfc02*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfc28*/
      a1: __src,
      a2: v702,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 24) /* +192: NO 2022 FIELD */ - *((double *)this + 23) /* +184: NO 2022 FIELD */);
    if ( (v702[0] & 1) != 0 ) /*0x1067cfc34*/
      operator delete(a1: v703); /*0x1067cfc3d*/
    std::string::basic_string[abi:ne200100]<0>( /*0x1067cfc50*/
      a1: v704,
      a2: "PlaceLauncherStartToFetchedScriptTime",
      a3: v589,
      a4: v590);
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfc76*/
      a1: __src,
      a2: v704,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 25) /* +200: NO 2022 FIELD */ - *((double *)this + 24) /* +192: NO 2022 FIELD */);
    if ( (v704[0] & 1) != 0 ) /*0x1067cfc82*/
      operator delete(a1: v705); /*0x1067cfc8b*/
    std::string::basic_string[abi:ne200100]<0>(a1: v706, a2: "FetchedScriptToPlayerConfTime", a3: v591, a4: v592); /*0x1067cfc9e*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfcc4*/
      a1: __src,
      a2: v706,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 26) /* +208: NO 2022 FIELD */ - *((double *)this + 25) /* +200: NO 2022 FIELD */);
    if ( (v706[0] & 1) != 0 ) /*0x1067cfcd0*/
      operator delete(a1: v707); /*0x1067cfcd9*/
    std::string::basic_string[abi:ne200100]<0>(a1: v708, a2: "PlayerConfigToConnectTime", a3: v593, a4: v594); /*0x1067cfcec*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfd12*/
      a1: __src,
      a2: v708,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 27) /* +216: NO 2022 FIELD */ - *((double *)this + 26) /* +208: NO 2022 FIELD */);
    if ( (v708[0] & 1) != 0 ) /*0x1067cfd1e*/
      operator delete(a1: v709); /*0x1067cfd27*/
    std::string::basic_string[abi:ne200100]<0>(a1: v710, a2: "ConnectToReceivedGlobalsTime", a3: v595, a4: v596); /*0x1067cfd3a*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfd60*/
      a1: __src,
      a2: v710,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 28) /* +224: NO 2022 FIELD */ - *((double *)this + 27) /* +216: NO 2022 FIELD */);
    if ( (v710[0] & 1) != 0 ) /*0x1067cfd6c*/
      operator delete(a1: v711); /*0x1067cfd75*/
    std::string::basic_string[abi:ne200100]<0>(a1: v712, a2: "ReceivedGlobalToGameLoadTime", a3: v597, a4: v598); /*0x1067cfd88*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfdae*/
      a1: __src,
      a2: v712,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 29) /* +232: NO 2022 FIELD */ - *((double *)this + 28) /* +224: NO 2022 FIELD */);
    if ( (v712[0] & 1) != 0 ) /*0x1067cfdba*/
      operator delete(a1: v713); /*0x1067cfdc3*/
    std::string::basic_string[abi:ne200100]<0>(a1: v714, a2: "GameLoadToGameJoinTime_Country", a3: v599, a4: v600); /*0x1067cfdd6*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfdfc*/
      a1: __src,
      a2: v714,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 30) /* +240: NO 2022 FIELD */ - *((double *)this + 29) /* +232: NO 2022 FIELD */);
    if ( (v714[0] & 1) != 0 ) /*0x1067cfe08*/
      operator delete(a1: v715); /*0x1067cfe11*/
    std::string::basic_string[abi:ne200100]<0>(a1: v716, a2: "GameJoinToAvatarLoadTime_Country", a3: v601, a4: v602); /*0x1067cfe24*/
    generatePlaceSpecificGameJoinAnalyticsWithLocation( /*0x1067cfe4a*/
      a1: __src,
      a2: v716,
      a3: v565,
      a4: v566,
      a5: *((double *)this + 36) /* +288: NO 2022 FIELD */ - *((double *)this + 30) /* +240: NO 2022 FIELD */);
    if ( (v716[0] & 1) != 0 ) /*0x1067cfe56*/
      operator delete(a1: v717); /*0x1067cfe5f*/
  }
  RBX::Analytics::EphemeralCounter::bulkReportStats(a1: __src, a2: 0); /*0x1067cfe6d*/
  *(_QWORD *)&v721 = __src; /*0x1067cfe79*/
  std::vector<std::pair<std::string,double>>::__destroy_vector::operator()[abi:ne200100](); /*0x1067cfe7c*/
LABEL_665:
  v603 = rand(); /*0x1067cfe81*/
  v604 = (unsigned __int64)(1759218605LL * v603) >> 63; /*0x1067cfe92*/
  v605 = (unsigned int)(10000 * (v603 / 10000)); /*0x1067cfe9c*/
  if ( v603 % 10000 < DFInt::SendJoinHttpBytesToDiag_HundredthsPercentage ) /*0x1067cfeaa*/
  {
    RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)__src); /*0x1067cfeb4*/
    v606 = std::string::insert(a1: __src, a2: 0, a3: "HTTPBytesInJoin-"); /*0x1067cfec6*/
    v722 = *(RBX **)(v606 + 16); /*0x1067cfecf*/
    v721 = *(_OWORD *)v606; /*0x1067cfeda*/
    *(_OWORD *)v606 = 0; /*0x1067cfee6*/
    *(_QWORD *)(v606 + 16) = 0; /*0x1067cfeea*/
    v608 = _mm_sub_pd( /*0x1067cff04*/
             (__m128d)_mm_unpacklo_epi32(
                        (__m128i)(unsigned __int64)RBX::Http::getNumOfDownloadedBytes(this: v607),
                        (__m128i)xmmword_108F2F9A0),
             (__m128d)xmmword_108F2F9B0);
    RBX::Analytics::EphemeralCounter::reportStats(a1: &v721, a2: 0, a3: _mm_hadd_pd(v608, v608).f64[0]); /*0x1067cff19*/
    if ( (v721 & 1) != 0 ) /*0x1067cff25*/
      operator delete(a1: v722); /*0x1067cff2e*/
    if ( ((__int64)__src[0] & 1) != 0 ) /*0x1067cff37*/
      operator delete(a1: v743[0]); /*0x1067cff3d*/
    RBX::SystemUtil::osPlatform(this: (RBX::SystemUtil *)__src); /*0x1067cff46*/
    v609 = std::string::insert(a1: __src, a2: 0, a3: "HTTPNonCachedBytesInJoin-"); /*0x1067cff58*/
    v722 = *(RBX **)(v609 + 16); /*0x1067cff61*/
    v721 = *(_OWORD *)v609; /*0x1067cff6c*/
    *(_OWORD *)v609 = 0; /*0x1067cff78*/
    *(_QWORD *)(v609 + 16) = 0; /*0x1067cff7c*/
    v611 = _mm_sub_pd( /*0x1067cff96*/
             (__m128d)_mm_unpacklo_epi32(
                        (__m128i)(unsigned __int64)RBX::Http::getNumOfNonCachedDownloadedBytes(this: v610),
                        (__m128i)xmmword_108F2F9A0),
             (__m128d)xmmword_108F2F9B0);
    RBX::Analytics::EphemeralCounter::reportStats(a1: &v721, a2: 0, a3: _mm_hadd_pd(v611, v611).f64[0]); /*0x1067cffab*/
    if ( (v721 & 1) != 0 ) /*0x1067cffb7*/
      operator delete(a1: v722); /*0x1067cffc0*/
    if ( ((__int64)__src[0] & 1) != 0 ) /*0x1067cffc9*/
      operator delete(a1: v743[0]); /*0x1067cffcf*/
  }
  if ( DFFlag::DebugLogAvatarLoadTimeStatsByPlace == 1 ) /*0x1067cffdb*/
  {
    if ( (DFString::SendAvatarLoadTimeStatsHundPrecCountryOverride & 1) != 0 ) /*0x1067cffea*/
      v612 = qword_10D80B848; /*0x1067cffec*/
    else
      v612 = (unsigned __int8)DFString::SendAvatarLoadTimeStatsHundPrecCountryOverride >> 1; /*0x1067cfff5*/
    v613 = DFInt::SendAvatarLoadTimeStats_HundredthsPercentage; /*0x1067cfff7*/
    if ( v612 != 0 ) /*0x1067d0001*/
    {
      std::string::basic_string[abi:ne200100]<0>(a1: &v721, a2: ",", a3: v604, a4: v605); /*0x1067d0011*/
      v614 = RBX::Network::getPairIntValue( /*0x1067d0030*/
               a1: &RBX::Analytics::location,
               a2: &DFString::SendAvatarLoadTimeStatsHundPrecCountryOverride,
               a3: &v721);
      if ( (v721 & 1) != 0 ) /*0x1067d003a*/
        operator delete(a1: v722); /*0x1067d0043*/
      if ( v614 != -1 ) /*0x1067d004c*/
        v613 = v614; /*0x1067d004c*/
    }
    if ( rand() % 10000 < v613 ) /*0x1067d0076*/
    {
      std::to_string(a1: (__int64)v719); /*0x1067d008e*/
      v721 = 0; /*0x1067d0097*/
      v722 = nullptr; /*0x1067d009f*/
      v733 = *((double *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067d00b2*/
      v739 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067d00c2*/
      std::string::basic_string[abi:ne200100]<0>(a1: __src, a2: "AvatarReplicatedTime", a3: v615, a4: v616); /*0x1067d00d2*/
      generatePlaceSpecificAvatarLoadTimeStats(a1: v720, a2: &v721, a3: __src, a4: v719, a5: v739 - v733); /*0x1067d00fd*/
      if ( ((__int64)__src[0] & 1) != 0 ) /*0x1067d0106*/
        operator delete(a1: v743[0]); /*0x1067d010c*/
      v733 = *((double *)this + 29) /* +232: NO 2022 FIELD */; /*0x1067d0119*/
      v739 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067d0129*/
      std::string::basic_string[abi:ne200100]<0>(a1: v735, a2: "AvatarReplicatedTimeFromGameLoaded", a3: v617, a4: v618); /*0x1067d013c*/
      generatePlaceSpecificAvatarLoadTimeStats(a1: v720, a2: &v721, a3: v735, a4: v719, a5: v739 - v733); /*0x1067d016a*/
      if ( (v735[0] & 1) != 0 ) /*0x1067d0176*/
        operator delete(a1: v736); /*0x1067d017f*/
      v733 = *((double *)this + 35) /* +280: NO 2022 FIELD */; /*0x1067d018c*/
      v739 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067d019c*/
      v734 = *((double *)this + 34) /* +272: NO 2022 FIELD */; /*0x1067d01a9*/
      v718 = *((double *)this + 36) /* +288: NO 2022 FIELD */; /*0x1067d01b9*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v737, a2: "AvatarTextureLoadTime", a3: v619, a4: v620); /*0x1067d01cc*/
      generatePlaceSpecificAvatarLoadTimeStats(a1: v720, a2: &v721, a3: &v737, a4: v719, a5: v733 - v739); /*0x1067d01f7*/
      if ( (v737 & 1) != 0 ) /*0x1067d0200*/
        operator delete(a1: v738); /*0x1067d0206*/
      std::string::basic_string[abi:ne200100]<0>(a1: &v740, a2: "AvatarMeshLoadTime", a3: v621, a4: v622); /*0x1067d0216*/
      generatePlaceSpecificAvatarLoadTimeStats(a1: v720, a2: &v721, a3: &v740, a4: v719, a5: v734 - v739); /*0x1067d0241*/
      if ( (v740 & 1) != 0 ) /*0x1067d024a*/
        operator delete(a1: v741); /*0x1067d0250*/
      std::string::basic_string[abi:ne200100]<0>(a1: v672, a2: "AvatarAssetsLoadTime", a3: v623, a4: v624); /*0x1067d0263*/
      generatePlaceSpecificAvatarLoadTimeStats(a1: v720, a2: &v721, a3: v672, a4: v719, a5: v718 - v739); /*0x1067d0291*/
      if ( (v672[0] & 1) != 0 ) /*0x1067d029d*/
        operator delete(a1: v673); /*0x1067d02a6*/
      v733 = *((double *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067d02b3*/
      v739 = *((double *)this + 36) /* +288: NO 2022 FIELD */; /*0x1067d02c3*/
      std::string::basic_string[abi:ne200100]<0>(a1: v674, a2: "AvatarLoadTimeTotal", a3: v625, a4: v626); /*0x1067d02d6*/
      generatePlaceSpecificAvatarLoadTimeStats(a1: v720, a2: &v721, a3: v674, a4: v719, a5: v739 - v733); /*0x1067d0304*/
      if ( (v674[0] & 1) != 0 ) /*0x1067d0310*/
        operator delete(a1: v675); /*0x1067d0319*/
      v733 = *((double *)this + 29) /* +232: NO 2022 FIELD */; /*0x1067d0326*/
      v739 = *((double *)this + 36) /* +288: NO 2022 FIELD */; /*0x1067d0336*/
      std::string::basic_string[abi:ne200100]<0>(a1: v676, a2: "AvatarLoadTimeFromGameLoaded", a3: v627, a4: v628); /*0x1067d0349*/
      generatePlaceSpecificAvatarLoadTimeStats(a1: v720, a2: &v721, a3: v676, a4: v719, a5: v739 - v733); /*0x1067d0377*/
      if ( (v676[0] & 1) != 0 ) /*0x1067d0383*/
        operator delete(a1: v677); /*0x1067d038c*/
      RBX::Analytics::EphemeralCounter::bulkReportStats(a1: &v721, a2: 0); /*0x1067d039d*/
      v671[4] = &v721; /*0x1067d03a9*/
      std::vector<std::pair<std::string,double>>::__destroy_vector::operator()[abi:ne200100](); /*0x1067d03ac*/
      if ( (v719[0] & 1) != 0 ) /*0x1067d03b8*/
        operator delete(a1: (void *)v719[2]); /*0x1067d03c1*/
    }
  }
  if ( FFlag::LogJoinTime == 1 )
  {
    v629 = FLog::JoinTimeLog; /*0x1067d03d3*/
    v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d03dc*/
    if ( (unsigned __int8)FLog::JoinTimeLog >= 6u && BYTE1(FLog::JoinTimeLog) >= 3u ) /*0x1067d03e8*/
    {
      FLog::FastLog( /*0x1067d03ff*/
        a1: FLog::JoinTimeLog,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] ======== Join Times =======",
        0);
      v629 = FLog::JoinTimeLog; /*0x1067d0404*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d040d*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      *(float *)&v631 = *((double *)this + 22) /* +176: NO 2022 FIELD */; /*0x1067d042a*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] VideoAdFinishedTime   : %.4f",
        COERCE_DOUBLE((unsigned __int64)v631),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d0448*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d0451*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      *(float *)&v632 = *((double *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067d046e*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] StartGameTime         : %.4f",
        COERCE_DOUBLE((unsigned __int64)v632),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d048c*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d0495*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      *(float *)&v633 = *((double *)this + 24) /* +192: NO 2022 FIELD */; /*0x1067d04ac*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] PlacelauncherStartTime: %.4f",
        COERCE_DOUBLE((unsigned __int64)v633),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d04ca*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d04d3*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      *(float *)&v634 = *((double *)this + 25) /* +200: NO 2022 FIELD */; /*0x1067d04ea*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] FetchedJoinScriptTime : %.4f",
        COERCE_DOUBLE((unsigned __int64)v634),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d0508*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d0511*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      *(float *)&v635 = *((double *)this + 26) /* +208: NO 2022 FIELD */; /*0x1067d0528*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] PlayerConfigureTime   : %.4f",
        COERCE_DOUBLE((unsigned __int64)v635),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d0546*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d054f*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      *(float *)&v636 = *((double *)this + 27) /* +216: NO 2022 FIELD */; /*0x1067d0566*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] ConnectTime           : %.4f",
        COERCE_DOUBLE((unsigned __int64)v636),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d0584*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d058d*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      *(float *)&v637 = *((double *)this + 28) /* +224: NO 2022 FIELD */; /*0x1067d05a4*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] ReceivedGlobalsTime   : %.4f",
        COERCE_DOUBLE((unsigned __int64)v637),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d05c2*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d05cb*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      *(float *)&v638 = *((double *)this + 29) /* +232: NO 2022 FIELD */; /*0x1067d05e2*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] GameLoadTime          : %.4f",
        COERCE_DOUBLE((unsigned __int64)v638),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d0600*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d0609*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      v639 = *((double *)this + 56) /* +448: NO 2022 FIELD */; /*0x1067d0620*/
      v640 = v639 - *((double *)this + 21) /* +168: NO 2022 FIELD */; /*0x1067d062c*/
      *(float *)&v640 = v640; /*0x1067d0634*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] InitSolidTextures     : %.4f",
        v640,
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d064e*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d0657*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      *(float *)&v641 = *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067d066e*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] GameJoinTime          : %.4f",
        COERCE_DOUBLE((unsigned __int64)v641),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d068c*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d0695*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      v642 = *((double *)this + 31) /* +248: NO 2022 FIELD */; /*0x1067d06ac*/
      v643 = v642 - *((double *)this + 21) /* +168: NO 2022 FIELD */; /*0x1067d06b8*/
      *(float *)&v643 = v643; /*0x1067d06c0*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] PlayerMovedTime       : %.4f",
        v643,
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d06da*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d06e3*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      *(float *)&v644 = *v732; /*0x1067d0701*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] AvatarLoadTime        : %.4f",
        COERCE_DOUBLE((unsigned __int64)v644),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d071b*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d0724*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      v645 = *((double *)this + 36) /* +288: NO 2022 FIELD */; /*0x1067d073b*/
      v646 = *((double *)this + 27) /* +216: NO 2022 FIELD */; /*0x1067d0746*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] Connect-Ava           : %.4f",
        COERCE_DOUBLE((unsigned __int64)COERCE_UNSIGNED_INT(v645 - v646)),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d0767*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d0770*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u ) /*0x1067d077b*/
    {
      FLog::FastLog(a1: v629, a2: qword_10D80B790, a3: "[FLog::JoinTimeLog] ======== Join Times (Delta) =======", 0); /*0x1067d078d*/
      v629 = FLog::JoinTimeLog; /*0x1067d0792*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d079b*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      *(float *)&v647 = *((double *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067d07b2*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] UserClickToStartGameTime        : %.4f",
        COERCE_DOUBLE((unsigned __int64)v647),
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d07cf*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d07d8*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      v648 = *((double *)this + 24) /* +192: NO 2022 FIELD */ - *((double *)this + 23) /* +184: NO 2022 FIELD */; /*0x1067d07f4*/
      *(float *)&v648 = v648; /*0x1067d07fc*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] StartGameToPlacelauncherStart   : %.4f",
        v648,
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d0815*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d081e*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      v649 = *((double *)this + 25) /* +200: NO 2022 FIELD */ - *((double *)this + 24) /* +192: NO 2022 FIELD */; /*0x1067d083a*/
      *(float *)&v649 = v649; /*0x1067d0842*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] PlacelauncherStartToJoinScript  : %.4f",
        v649,
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d085b*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d0864*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      v650 = *((double *)this + 26) /* +208: NO 2022 FIELD */ - *((double *)this + 25) /* +200: NO 2022 FIELD */; /*0x1067d0880*/
      *(float *)&v650 = v650; /*0x1067d0888*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] FetchedScriptToPlayerConfTime   : %.4f",
        v650,
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d08a1*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d08aa*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      v651 = *((double *)this + 27) /* +216: NO 2022 FIELD */ - *((double *)this + 26) /* +208: NO 2022 FIELD */; /*0x1067d08c6*/
      *(float *)&v651 = v651; /*0x1067d08ce*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] PlayerConfigToConnectTime       : %.4f",
        v651,
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d08e7*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d08f0*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      v652 = *((double *)this + 28) /* +224: NO 2022 FIELD */ - *((double *)this + 27) /* +216: NO 2022 FIELD */; /*0x1067d090c*/
      *(float *)&v652 = v652; /*0x1067d0914*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] ConnectToReceivedGlobalsTime    : %.4f",
        v652,
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d092d*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d0936*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      v653 = *((double *)this + 29) /* +232: NO 2022 FIELD */ - *((double *)this + 28) /* +224: NO 2022 FIELD */; /*0x1067d0952*/
      *(float *)&v653 = v653; /*0x1067d095a*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] ReceivedGlobalToGameLoadTime    : %.4f",
        v653,
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d0973*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d097c*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      v654 = *((double *)this + 30) /* +240: NO 2022 FIELD */ - *((double *)this + 29) /* +232: NO 2022 FIELD */; /*0x1067d0998*/
      *(float *)&v654 = v654; /*0x1067d09a0*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] GameLoadToGameJoinTime          : %.4f",
        v654,
        0.0,
        0.0,
        0.0);
      v629 = FLog::JoinTimeLog; /*0x1067d09b9*/
      v630 = (unsigned int)FLog::JoinTimeLog >> 8; /*0x1067d09c2*/
    }
    if ( (unsigned __int8)v629 >= 6u && (unsigned __int8)v630 >= 3u )
    {
      v655 = *((double *)this + 36) /* +288: NO 2022 FIELD */ - *((double *)this + 30) /* +240: NO 2022 FIELD */; /*0x1067d09de*/
      *(float *)&v655 = v655; /*0x1067d09e6*/
      FLog::FastLogF(
        a1: v629,
        a2: qword_10D80B790,
        a3: "[FLog::JoinTimeLog] GameJoinToAvatarLoadTime        : %.4f",
        v655,
        0.0,
        0.0,
        0.0);
    }
  }
LABEL_770:
  *(_QWORD *)&v721 = v671; /*0x1067d09ff*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: &v721); /*0x1067d0a13*/
  *(_QWORD *)&v721 = &v670; /*0x1067d0a1f*/
  std::vector<RBX::AvatarAssetMetrics>::__destroy_vector::operator()[abi:ne200100](a1: &v721); /*0x1067d0a29*/
  if ( (v666 & 1) != 0 ) /*0x1067d0a36*/
    operator delete(a1: v667); /*0x1067d0a3f*/
  if ( (v664 & 1) != 0 ) /*0x1067d0a4b*/
    operator delete(a1: v665); /*0x1067d0a54*/
  if ( (v662[24] & 1) != 0 ) /*0x1067d0a60*/
    operator delete(a1: v663); /*0x1067d0a69*/
}

// Address: 0x1067d2786 | Name: __ZN3RBX16PlayerConfigurer16setIsStudioToRccEb
void __fastcall RBX::PlayerConfigurer::setIsStudioToRcc(RBX::PlayerConfigurer *this, char a2)
{
  this->isStudioToRcc /* +65 */ = a2; /*0x1067d278a*/
}

// Address: 0x1067d2790 | Name: __ZN3RBX16PlayerConfigurer22reportVoiceIdleTimeoutEd
void __fastcall RBX::PlayerConfigurer::reportVoiceIdleTimeout(RBX::PlayerConfigurer *this, double a2)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  _BYTE v4[72]; // [rsp+0h] [rbp-490h] BYREF
  _BYTE v5[528]; // [rsp+48h] [rbp-448h] BYREF
  void *v6[9]; // [rsp+258h] [rbp-238h] BYREF
  _BYTE v7[472]; // [rsp+2A0h] [rbp-1F0h] BYREF
  double v8; // [rsp+478h] [rbp-18h]

  v8 = a2; /*0x1067d279e*/
  RBX::Telemetry::RobloxTelemetryEvent::RobloxTelemetryEvent<(RBX::Telemetry::TelemetryBackend)1,std::enable_if<true,void>>( /*0x1067d27b1*/
    a1: v4,
    a2: &RBX::Telemetry::kCevIdleTimeoutTelemetry);
  RBX::Telemetry::FieldsContainer::addField(a1: v5, a2: "timeInSeconds", a3: 13, a4: (unsigned int)(int)v8, a5: 1); /*0x1067d27d8*/
  std::string::basic_string[abi:ne200100]<0>(a1: v6, a2: "", a3: v2, a4: v3); /*0x1067d27eb*/
  RBX::Telemetry::FieldsContainer::addPlaceId(this: (RBX::Analytics *)v5); /*0x1067d27fa*/
  if ( ((__int64)v6[0] & 1) != 0 ) /*0x1067d2806*/
    operator delete(a1: v6[2]); /*0x1067d280f*/
  RBX::Telemetry::FieldsContainer::addPlaySessionId(this: (RBX::Telemetry::FieldsContainer *)v5); /*0x1067d2817*/
  RBX::Telemetry::RobloxTelemetryEvent::send(this: (RBX::Telemetry::RobloxTelemetryEvent *)v4); /*0x1067d2823*/
  if ( DFFlag::CevIdleTimeoutCounter == 1 ) /*0x1067d282f*/
  {
    RBX::Telemetry::RobloxTelemetryCounter::RobloxTelemetryCounter( /*0x1067d283f*/
      a1: v6,
      a2: (__int64)&RBX::Telemetry::kCevIdleTimeoutCounter);
    RBX::Telemetry::FieldsContainer::addOSInfo(this: (RBX::Telemetry::FieldsContainer *)v7); /*0x1067d284e*/
    RBX::Telemetry::RobloxTelemetryCounter::send(this: (RBX::Telemetry::RobloxTelemetryCounter *)v6); /*0x1067d285a*/
    RBX::Telemetry::FieldsContainer::~FieldsContainer(this: (RBX::Telemetry::FieldsContainer *)v7); /*0x1067d286d*/
    RBX::Telemetry::RobloxTelemetryCommon::~RobloxTelemetryCommon(this: v6, a2: (void **)off_10C8C7EB0); /*0x1067d2880*/
  }
  RBX::Telemetry::RobloxTelemetryEvent::~RobloxTelemetryEvent(this: (RBX::Telemetry::RobloxTelemetryEvent *)v4); /*0x1067d2893*/
}

// Address: 0x10876501c | Name: __ZN3RBX16PlayerConfigurerC2Ev.cold.1
void __fastcall RBX::PlayerConfigurer::PlayerConfigurer(RBX::PlayerConfigurer *this, __int64 a2)
{
  do /*0x108765046*/
  {
    if ( (*((_BYTE *)this  /* +0 likely .__vftable -- UNVERIFIED */+ a2 - 24) & 1) != 0 ) /*0x10876502f*/
      operator delete(a1: *(void **)((char *)this + a2 - 8)); /*0x108765036*/
    this = (RBX::PlayerConfigurer *)((char *)this - 24); /*0x10876503b*/
  }
  while ( this != (RBX::PlayerConfigurer *)912 ); /*0x108765046*/
}

// END PlayerConfigurer part 1/1, 48 functions
