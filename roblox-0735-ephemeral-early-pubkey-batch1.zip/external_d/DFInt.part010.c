// DFInt -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 400 functions, part 10 of 12


// Address: 0x10675d76e | Name: __ZN5DFIntL65rbxImplDynInit_MegaReplicatorNumParallelTasksDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MegaReplicatorNumParallelTasksDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MegaReplicatorNumParallelTasks, a2: 2u); /*0x10675d77e*/
}

// Address: 0x10675d784 | Name: __ZN5DFIntL65rbxImplDynInit_PhysicsReceiveNumParallelTasksDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PhysicsReceiveNumParallelTasksDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PhysicsReceiveNumParallelTasks, a2: 2u); /*0x10675d794*/
}

// Address: 0x10675d7b7 | Name: __ZN5DFIntL72rbxImplDynInit_ReportNeverReplicateStatEveryXSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportNeverReplicateStatEveryXSecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportNeverReplicateStatEveryXSeconds, a2: 2u); /*0x10675d7c7*/
}

// Address: 0x10675d843 | Name: __ZN5DFIntL90rbxImplDynInit_ReportReplicateDestroySettingInfluxHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportReplicateDestroySettingInfluxHundredthsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportReplicateDestroySettingInfluxHundredthsPercentage, a2: 2u); /*0x10675d853*/
}

// Address: 0x10675d876 | Name: __ZN5DFIntL87rbxImplDynInit_ObjRefEdgeCleanupSrcMissingThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ObjRefEdgeCleanupSrcMissingThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ObjRefEdgeCleanupSrcMissingThrottleHundredthsPercent, a2: 2u); /*0x10675d886*/
}

// Address: 0x10675d902 | Name: __ZN5DFIntL78rbxImplDynInit_ReportStreamingRegionRemovalStatsHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportStreamingRegionRemovalStatsHundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportStreamingRegionRemovalStatsHundredths, a2: 2u); /*0x10675d912*/
}

// Address: 0x10675d918 | Name: __ZN5DFIntL76rbxImplDynInit_TrackerDataParallelSerializationBatchSizeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TrackerDataParallelSerializationBatchSizeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TrackerDataParallelSerializationBatchSize, a2: 2u); /*0x10675d928*/
}

// Address: 0x10675d968 | Name: __ZN5DFIntL70rbxImplDynInit_ReportJoinStructureMismatchThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportJoinStructureMismatchThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportJoinStructureMismatchThrottle, a2: 2u); /*0x10675d978*/
}

// Address: 0x10675d99b | Name: __ZN5DFIntL58rbxImplDynInit_ISRParallelStepBatchingDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ISRParallelStepBatchingDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ISRParallelStepBatching, a2: 2u); /*0x10675d9ab*/
}

// Address: 0x10675da77 | Name: __ZN5DFIntL76rbxImplDynInit_MRDTableMemUsageThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MRDTableMemUsageThrottleHundredthsPercentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MRDTableMemUsageThrottleHundredthsPercent, a2: 2u); /*0x10675da87*/
}

// Address: 0x10675da8d | Name: __ZN5DFIntL66rbxImplDynInit_StreamDataItemPoolStatsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_StreamDataItemPoolStatsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::StreamDataItemPoolStatsThrottle, a2: 2u); /*0x10675da9d*/
}

// Address: 0x10675dadd | Name: __ZN5DFIntL67rbxImplDynInit_ParallelResolveMetadataBatchSizeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ParallelResolveMetadataBatchSizeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ParallelResolveMetadataBatchSize, a2: 2u); /*0x10675daed*/
}

// Address: 0x10675daf3 | Name: __ZN5DFIntL72rbxImplDynInit_ParallelResolveMetadataMinReplicatorsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ParallelResolveMetadataMinReplicatorsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ParallelResolveMetadataMinReplicators, a2: 2u); /*0x10675db03*/
}

// Address: 0x10675db26 | Name: __ZN5DFIntL69rbxImplDynInit_StreamingConversionStatsThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_StreamingConversionStatsThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::StreamingConversionStatsThrottleHP, a2: 2u); /*0x10675db36*/
}

// Address: 0x10678ea84 | Name: __ZN5DFIntL102rbxImplDynInit_BandwidthManagerReportHighestWatermarkInSessionHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_BandwidthManagerReportHighestWatermarkInSessionHundredthsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt( /*0x10678ea94*/
           a1: (__int64)&DFInt::BandwidthManagerReportHighestWatermarkInSessionHundredthsPercentage,
           a2: 2u);
}

// Address: 0x10678ea9a | Name: __ZN5DFIntL67rbxImplDynInit_TrackerDataSenderMaxBandwidthBpsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TrackerDataSenderMaxBandwidthBpsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TrackerDataSenderMaxBandwidthBps, a2: 2u); /*0x10678eaaa*/
}

// Address: 0x10678eab0 | Name: __ZN5DFIntL63rbxImplDynInit_PhysicsSenderMaxBandwidthBpsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PhysicsSenderMaxBandwidthBpsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PhysicsSenderMaxBandwidthBps, a2: 2u); /*0x10678eac0*/
}

// Address: 0x10678eac6 | Name: __ZN5DFIntL70rbxImplDynInit_PhysicsSenderMaxBandwidthBpsScalingDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PhysicsSenderMaxBandwidthBpsScalingDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PhysicsSenderMaxBandwidthBpsScaling, a2: 2u); /*0x10678ead6*/
}

// Address: 0x10678eadc | Name: __ZN5DFIntL60rbxImplDynInit_DataSenderMaxBandwidthBpsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DataSenderMaxBandwidthBpsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DataSenderMaxBandwidthBps, a2: 2u); /*0x10678eaec*/
}

// Address: 0x10678eaf2 | Name: __ZN5DFIntL65rbxImplDynInit_LargeDataSenderMaxBandwidthBpsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_LargeDataSenderMaxBandwidthBpsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::LargeDataSenderMaxBandwidthBps, a2: 2u); /*0x10678eb02*/
}

// Address: 0x10678eb08 | Name: __ZN5DFIntL65rbxImplDynInit_LargeDataSenderMinBandwidthBpsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_LargeDataSenderMinBandwidthBpsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::LargeDataSenderMinBandwidthBps, a2: 2u); /*0x10678eb18*/
}

// Address: 0x10678eb1e | Name: __ZN5DFIntL64rbxImplDynInit_DataSenderMaxJoinBandwidthBpsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DataSenderMaxJoinBandwidthBpsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DataSenderMaxJoinBandwidthBps, a2: 2u); /*0x10678eb2e*/
}

// Address: 0x10678eb34 | Name: __ZN5DFIntL74rbxImplDynInit_DataSenderMaxJoinBandwidthBpsMultiplierDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DataSenderMaxJoinBandwidthBpsMultiplierDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DataSenderMaxJoinBandwidthBpsMultiplier, a2: 2u); /*0x10678eb44*/
}

// Address: 0x10678eb4a | Name: __ZN5DFIntL70rbxImplDynInit_DataSenderMaxBandwidthBpsMultiplierDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DataSenderMaxBandwidthBpsMultiplierDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DataSenderMaxBandwidthBpsMultiplier, a2: 2u); /*0x10678eb5a*/
}

// Address: 0x10678eb60 | Name: __ZN5DFIntL49rbxImplDynInit_DataSenderRateDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DataSenderRateDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DataSenderRate, a2: 2u); /*0x10678eb70*/
}

// Address: 0x10678eb76 | Name: __ZN5DFIntL69rbxImplDynInit_ClusterSenderMaxUpdateBandwidthBpsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClusterSenderMaxUpdateBandwidthBpsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClusterSenderMaxUpdateBandwidthBps, a2: 2u); /*0x10678eb86*/
}

// Address: 0x10678eb8c | Name: __ZN5DFIntL76rbxImplDynInit_ClusterSenderMaxUpdateBandwidthBpsScalingDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClusterSenderMaxUpdateBandwidthBpsScalingDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClusterSenderMaxUpdateBandwidthBpsScaling, a2: 2u); /*0x10678eb9c*/
}

// Address: 0x10678eba2 | Name: __ZN5DFIntL67rbxImplDynInit_ClusterSenderMaxJoinBandwidthBpsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClusterSenderMaxJoinBandwidthBpsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClusterSenderMaxJoinBandwidthBps, a2: 2u); /*0x10678ebb2*/
}

// Address: 0x10678ebb8 | Name: __ZN5DFIntL74rbxImplDynInit_ClusterSenderMaxJoinBandwidthBpsScalingDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClusterSenderMaxJoinBandwidthBpsScalingDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClusterSenderMaxJoinBandwidthBpsScaling, a2: 2u); /*0x10678ebc8*/
}

// Address: 0x10678ebce | Name: __ZN5DFIntL68rbxImplDynInit_TouchSenderMaxBandwidthBpsScalingDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TouchSenderMaxBandwidthBpsScalingDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TouchSenderMaxBandwidthBpsScaling, a2: 2u); /*0x10678ebde*/
}

// Address: 0x10678ebe4 | Name: __ZN5DFIntL61rbxImplDynInit_TouchSenderMaxBandwidthBpsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TouchSenderMaxBandwidthBpsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TouchSenderMaxBandwidthBps, a2: 2u); /*0x10678ebf4*/
}

// Address: 0x10678ebfa | Name: __ZN5DFIntL86rbxImplDynInit_ReportNetworkSendersLeftoverBytesThrottlePercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportNetworkSendersLeftoverBytesThrottlePercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportNetworkSendersLeftoverBytesThrottlePercentage, a2: 2u); /*0x10678ec0a*/
}

// Address: 0x10678ec10 | Name: __ZN5DFIntL85rbxImplDynInit_BandwidthManagerFeedbackInfluxHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_BandwidthManagerFeedbackInfluxHundredthsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::BandwidthManagerFeedbackInfluxHundredthsPercentage, a2: 2u); /*0x10678ec20*/
}

// Address: 0x10678ec26 | Name: __ZN5DFIntL85rbxImplDynInit_BandwidthManagerFeedbackMetricsUpdateEveryXSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_BandwidthManagerFeedbackMetricsUpdateEveryXSecondsDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::BandwidthManagerFeedbackMetricsUpdateEveryXSeconds, a2: 2u); /*0x10678ec36*/
}

// Address: 0x10678ec3c | Name: __ZN5DFIntL85rbxImplDynInit_BandwidthManagerFeedbackMetricsSendEveryXSecondsV2DynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_BandwidthManagerFeedbackMetricsSendEveryXSecondsV2DynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::BandwidthManagerFeedbackMetricsSendEveryXSecondsV2, a2: 2u); /*0x10678ec4c*/
}

// Address: 0x10678ec52 | Name: __ZN5DFIntL72rbxImplDynInit_BandwidthManagerApplicationDefaultBpsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_BandwidthManagerApplicationDefaultBpsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::BandwidthManagerApplicationDefaultBps, a2: 2u); /*0x10678ec62*/
}

// Address: 0x10678eca2 | Name: __ZN5DFIntL59rbxImplDynInit_ISRSenderMaxBandwidthBpsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ISRSenderMaxBandwidthBpsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ISRSenderMaxBandwidthBps, a2: 2u); /*0x10678ecb2*/
}

// Address: 0x10678ecb8 | Name: __ZN5DFIntL48rbxImplDynInit_ISRSenderRateDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ISRSenderRateDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ISRSenderRate, a2: 2u); /*0x10678ecc8*/
}

// Address: 0x10678ecce | Name: __ZN5DFIntL69rbxImplDynInit_ISRSenderMaxBandwidthBpsMultiplierDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ISRSenderMaxBandwidthBpsMultiplierDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ISRSenderMaxBandwidthBpsMultiplier, a2: 2u); /*0x10678ecde*/
}

// Address: 0x10678ed01 | Name: __ZN5DFIntL60rbxImplDynInit_ISRBandwidthSendLimiterHzDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ISRBandwidthSendLimiterHzDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ISRBandwidthSendLimiterHz, a2: 2u); /*0x10678ed11*/
}

// Address: 0x10678ed17 | Name: __ZN5DFIntL77rbxImplDynInit_BandwidthManagerDataSenderMaxWorkCatchupMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_BandwidthManagerDataSenderMaxWorkCatchupMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::BandwidthManagerDataSenderMaxWorkCatchupMs, a2: 2u); /*0x10678ed27*/
}

// Address: 0x10678ed2d | Name: __ZN5DFIntL59rbxImplDynInit_BandwithHealthyTargetPctDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_BandwithHealthyTargetPctDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::BandwithHealthyTargetPct, a2: 2u); /*0x10678ed3d*/
}

// Address: 0x10678ed43 | Name: __ZN5DFIntL61rbxImplDynInit_BandwithUnhealthyTargetPctDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_BandwithUnhealthyTargetPctDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::BandwithUnhealthyTargetPct, a2: 2u); /*0x10678ed53*/
}

// Address: 0x10678ed59 | Name: __ZN5DFIntL57rbxImplDynInit_BandwithHealthPeriodMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_BandwithHealthPeriodMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::BandwithHealthPeriodMs, a2: 2u); /*0x10678ed69*/
}

// Address: 0x10678ed6f | Name: __ZN5DFIntL81rbxImplDynInit_LargeReplicatorDynamicBandwidthIncreasePercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_LargeReplicatorDynamicBandwidthIncreasePercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::LargeReplicatorDynamicBandwidthIncreasePercent, a2: 2u); /*0x10678ed7f*/
}

// Address: 0x10678ed85 | Name: __ZN5DFIntL81rbxImplDynInit_LargeReplicatorMaxBandwidthUsageAllowedPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_LargeReplicatorMaxBandwidthUsageAllowedPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::LargeReplicatorMaxBandwidthUsageAllowedPercent, a2: 2u); /*0x10678ed95*/
}

// Address: 0x106794cbc | Name: __ZN5DFIntL76rbxImplDynInit_NetworkClusterPacketCacheNumParallelTasksDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkClusterPacketCacheNumParallelTasksDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkClusterPacketCacheNumParallelTasks, a2: 2u); /*0x106794ccc*/
}

// Address: 0x106798007 | Name: __ZN5DFIntL89rbxImplDynInit_RbxTransportReplicationSendPacketLossHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportReplicationSendPacketLossHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RbxTransportReplicationSendPacketLossHundredthsPercent, a2: 2u); /*0x106798017*/
}

// Address: 0x10679801d | Name: __ZN5DFIntL89rbxImplDynInit_RbxTransportReplicationRecvPacketLossHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportReplicationRecvPacketLossHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RbxTransportReplicationRecvPacketLossHundredthsPercent, a2: 2u); /*0x10679802d*/
}

// Address: 0x106798033 | Name: __ZN5DFIntL71rbxImplDynInit_RbxTransportReplicationSendLatencyMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportReplicationSendLatencyMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RbxTransportReplicationSendLatencyMs, a2: 2u); /*0x106798043*/
}

// Address: 0x106798049 | Name: __ZN5DFIntL70rbxImplDynInit_RbxTransportReplicationSendJitterMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportReplicationSendJitterMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RbxTransportReplicationSendJitterMs, a2: 2u); /*0x106798059*/
}

// Address: 0x10679805f | Name: __ZN5DFIntL71rbxImplDynInit_RbxTransportReplicationRecvLatencyMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportReplicationRecvLatencyMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RbxTransportReplicationRecvLatencyMs, a2: 2u); /*0x10679806f*/
}

// Address: 0x106798075 | Name: __ZN5DFIntL70rbxImplDynInit_RbxTransportReplicationRecvJitterMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportReplicationRecvJitterMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RbxTransportReplicationRecvJitterMs, a2: 2u); /*0x106798085*/
}

// Address: 0x1067980a8 | Name: __ZN5DFIntL88rbxImplDynInit_NetworkEmulationConfigPointsThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkEmulationConfigPointsThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkEmulationConfigPointsThrottleHundredthsPercent, a2: 2u); /*0x1067980b8*/
}

// Address: 0x106799285 | Name: __ZN5DFIntL52rbxImplDynInit_ClientOwnershipMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientOwnershipMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientOwnershipMs, a2: 2u); /*0x106799295*/
}

// Address: 0x10679beca | Name: __ZN5DFIntL64rbxImplDynInit_NetworkSchemaCompressionRatioDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkSchemaCompressionRatioDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkSchemaCompressionRatio, a2: 2u); /*0x10679beda*/
}

// Address: 0x10679befd | Name: __ZN5DFIntL58rbxImplDynInit_SchemaNetworkStreamSizeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SchemaNetworkStreamSizeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SchemaNetworkStreamSize, a2: 2u); /*0x10679bf0d*/
}

// Address: 0x10679bf6a | Name: __ZN5DFIntL58rbxImplDynInit_DebugLrCacheCategoryMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DebugLrCacheCategoryMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DebugLrCacheCategoryMax, a2: 2u); /*0x10679bf7a*/
}

// Address: 0x1067a599f | Name: __ZN5DFIntL66rbxImplDynInit_DebugRakPeerReceiveAfterSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DebugRakPeerReceiveAfterSecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DebugRakPeerReceiveAfterSeconds, a2: 2u); /*0x1067a59af*/
}

// Address: 0x1067a59d2 | Name: __ZN5DFIntL63rbxImplDynInit_ReportLuauConnIssuePermyriadDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportLuauConnIssuePermyriadDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportLuauConnIssuePermyriad, a2: 2u); /*0x1067a59e2*/
}

// Address: 0x1067a8cb8 | Name: __ZN5DFIntL53rbxImplDynInit_PTRPacketToleranceDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PTRPacketToleranceDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PTRPacketTolerance, a2: 2u); /*0x1067a8cc8*/
}

// Address: 0x1067a8cce | Name: __ZN5DFIntL52rbxImplDynInit_PTREventThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PTREventThresholdDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PTREventThreshold, a2: 2u); /*0x1067a8cde*/
}

// Address: 0x1067a8ce4 | Name: __ZN5DFIntL49rbxImplDynInit_PTREventWindowDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PTREventWindowDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PTREventWindow, a2: 2u); /*0x1067a8cf4*/
}

// Address: 0x1067adbb2 | Name: __ZN5DFIntL52rbxImplDynInit_PercentSentAlwaysDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PercentSentAlwaysDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PercentSentAlways, a2: 2u); /*0x1067adbc2*/
}

// Address: 0x1067adbc8 | Name: __ZN5DFIntL77rbxImplDynInit_FairMixedPriorityAsymptoteMultSizeDistanceDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_FairMixedPriorityAsymptoteMultSizeDistanceDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::FairMixedPriorityAsymptoteMultSizeDistance, a2: 2u); /*0x1067adbd8*/
}

// Address: 0x1067adbde | Name: __ZN5DFIntL74rbxImplDynInit_FairMixedPriorityAsymptoteMultDeltaTimeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_FairMixedPriorityAsymptoteMultDeltaTimeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::FairMixedPriorityAsymptoteMultDeltaTime, a2: 2u); /*0x1067adbee*/
}

// Address: 0x1067adbf4 | Name: __ZN5DFIntL65rbxImplDynInit_AdjustMixedPriorityGroup1CountDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_AdjustMixedPriorityGroup1CountDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::AdjustMixedPriorityGroup1Count, a2: 2u); /*0x1067adc04*/
}

// Address: 0x1067adc0a | Name: __ZN5DFIntL65rbxImplDynInit_AdjustMixedPriorityGroup2CountDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_AdjustMixedPriorityGroup2CountDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::AdjustMixedPriorityGroup2Count, a2: 2u); /*0x1067adc1a*/
}

// Address: 0x1067adc20 | Name: __ZN5DFIntL50rbxImplDynInit_MaxFramesToSendDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxFramesToSendDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxFramesToSend, a2: 2u); /*0x1067adc30*/
}

// Address: 0x1067adc53 | Name: __ZN5DFIntL55rbxImplDynInit_DebugSendDistInStepsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DebugSendDistInStepsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DebugSendDistInSteps, a2: 2u); /*0x1067adc63*/
}

// Address: 0x1067adc69 | Name: __ZN5DFIntL78rbxImplDynInit_DistanceWeightTuneInMixedPriorityHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DistanceWeightTuneInMixedPriorityHundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DistanceWeightTuneInMixedPriorityHundredths, a2: 2u); /*0x1067adc79*/
}

// Address: 0x1067adcb9 | Name: __ZN5DFIntL55rbxImplDynInit_LayOnHandsCooldownMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_LayOnHandsCooldownMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::LayOnHandsCooldownMs, a2: 2u); /*0x1067adcc9*/
}

// Address: 0x1067adccf | Name: __ZN5DFIntL78rbxImplDynInit_GameNetCompressionLodByteBudgetThresholdPctDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_GameNetCompressionLodByteBudgetThresholdPctDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::GameNetCompressionLodByteBudgetThresholdPct, a2: 2u); /*0x1067adcdf*/
}

// Address: 0x1067adce5 | Name: __ZN5DFIntL64rbxImplDynInit_GameNetLocalSpaceMaxSendIndexDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_GameNetLocalSpaceMaxSendIndexDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::GameNetLocalSpaceMaxSendIndex, a2: 2u); /*0x1067adcf5*/
}

// Address: 0x1067adcfb | Name: __ZN5DFIntL79rbxImplDynInit_GameNetPVHeaderTranslationZeroCutoffExponentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_GameNetPVHeaderTranslationZeroCutoffExponentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::GameNetPVHeaderTranslationZeroCutoffExponent, a2: 2u); /*0x1067add0b*/
}

// Address: 0x1067add11 | Name: __ZN5DFIntL83rbxImplDynInit_GameNetPVHeaderRotationOrientIdToleranceExponentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_GameNetPVHeaderRotationOrientIdToleranceExponentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::GameNetPVHeaderRotationOrientIdToleranceExponent, a2: 2u); /*0x1067add21*/
}

// Address: 0x1067add27 | Name: __ZN5DFIntL82rbxImplDynInit_GameNetPVHeaderLinearVelocityZeroCutoffExponentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_GameNetPVHeaderLinearVelocityZeroCutoffExponentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::GameNetPVHeaderLinearVelocityZeroCutoffExponent, a2: 2u); /*0x1067add37*/
}

// Address: 0x1067add3d | Name: __ZN5DFIntL86rbxImplDynInit_GameNetPVHeaderRotationalVelocityZeroCutoffExponentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_GameNetPVHeaderRotationalVelocityZeroCutoffExponentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::GameNetPVHeaderRotationalVelocityZeroCutoffExponent, a2: 2u); /*0x1067add4d*/
}

// Address: 0x1067add53 | Name: __ZN5DFIntL74rbxImplDynInit_TangentialVelocityCoefficientHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TangentialVelocityCoefficientHundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TangentialVelocityCoefficientHundredths, a2: 2u); /*0x1067add63*/
}

// Address: 0x1067add69 | Name: __ZN5DFIntL68rbxImplDynInit_NumTrackerDataToReplicatePerFrameDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NumTrackerDataToReplicatePerFrameDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NumTrackerDataToReplicatePerFrame, a2: 2u); /*0x1067add79*/
}

// Address: 0x1067b729a | Name: __ZN5DFIntL70rbxImplDynInit_TouchQueueMetricsSendEveryXSeconds2DynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TouchQueueMetricsSendEveryXSeconds2DynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TouchQueueMetricsSendEveryXSeconds2, a2: 2u); /*0x1067b72aa*/
}

// Address: 0x1067b72b0 | Name: __ZN5DFIntL79rbxImplDynInit_TouchQueueMetricsInfluxHundredthsPercentage2DynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TouchQueueMetricsInfluxHundredthsPercentage2DynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TouchQueueMetricsInfluxHundredthsPercentage2, a2: 2u); /*0x1067b72c0*/
}

// Address: 0x1067b843a | Name: __ZN5DFIntL65rbxImplDynInit_JoinInfluxHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_JoinInfluxHundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::JoinInfluxHundredthsPercentage, a2: 2u); /*0x1067b844a*/
}

// Address: 0x1067b8450 | Name: __ZN5DFIntL68rbxImplDynInit_JoinAllInfluxHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_JoinAllInfluxHundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::JoinAllInfluxHundredthsPercentage, a2: 2u); /*0x1067b8460*/
}

// Address: 0x1067b8466 | Name: __ZN5DFIntL79rbxImplDynInit_SendAvatarLoadTimeStats_HundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendAvatarLoadTimeStats_HundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendAvatarLoadTimeStats_HundredthsPercentage, a2: 2u); /*0x1067b8476*/
}

// Address: 0x1067b8499 | Name: __ZN5DFIntL58rbxImplDynInit_OnDisconnectHTTPTimeoutDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_OnDisconnectHTTPTimeoutDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::OnDisconnectHTTPTimeout, a2: 2u); /*0x1067b84a9*/
}

// Address: 0x1067b84e2 | Name: __ZN5DFIntL66rbxImplDynInit_PlayerConfigurerCDNProbeDelayMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PlayerConfigurerCDNProbeDelayMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PlayerConfigurerCDNProbeDelayMs, a2: 2u); /*0x1067b84f2*/
}

// Address: 0x1067b8515 | Name: __ZN5DFIntL65rbxImplDynInit_PlayerConfigurerLMSTestDelayMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PlayerConfigurerLMSTestDelayMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PlayerConfigurerLMSTestDelayMs, a2: 2u); /*0x1067b8525*/
}

// Address: 0x1067b864d | Name: __ZN5DFIntL80rbxImplDynInit_SendJoinTimeDeltasToDiag_HundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendJoinTimeDeltasToDiag_HundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendJoinTimeDeltasToDiag_HundredthsPercentage, a2: 2u); /*0x1067b865d*/
}

// Address: 0x1067b8663 | Name: __ZN5DFIntL85rbxImplDynInit_SendJoinTimeDeltasToDiagLuobu_HundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendJoinTimeDeltasToDiagLuobu_HundredthsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendJoinTimeDeltasToDiagLuobu_HundredthsPercentage, a2: 2u); /*0x1067b8673*/
}

// Address: 0x1067b8679 | Name: __ZN5DFIntL79rbxImplDynInit_SendJoinTimeStatsToDiag_HundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendJoinTimeStatsToDiag_HundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendJoinTimeStatsToDiag_HundredthsPercentage, a2: 2u); /*0x1067b8689*/
}

// Address: 0x1067b868f | Name: __ZN5DFIntL75rbxImplDynInit_SendJoinTimesToDiag_HundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendJoinTimesToDiag_HundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendJoinTimesToDiag_HundredthsPercentage, a2: 2u); /*0x1067b869f*/
}

// Address: 0x1067b8736 | Name: __ZN5DFIntL73rbxImplDynInit_SendJoinTimeStatsHundPrecLuobuOverrideDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendJoinTimeStatsHundPrecLuobuOverrideDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendJoinTimeStatsHundPrecLuobuOverride, a2: 2u); /*0x1067b8746*/
}

// Address: 0x1067b874c | Name: __ZN5DFIntL79rbxImplDynInit_SendJoinHttpBytesToDiag_HundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendJoinHttpBytesToDiag_HundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendJoinHttpBytesToDiag_HundredthsPercentage, a2: 2u); /*0x1067b875c*/
}

// Address: 0x1067b877f | Name: __ZN5DFIntL84rbxImplDynInit_LongAvatarAssetTelemetryThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_LongAvatarAssetTelemetryThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::LongAvatarAssetTelemetryThrottleHundredthsPercent, a2: 2u); /*0x1067b878f*/
}

// Address: 0x1067b8795 | Name: __ZN5DFIntL78rbxImplDynInit_LongAvatarAssetTelemetryMinimumMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_LongAvatarAssetTelemetryMinimumMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::LongAvatarAssetTelemetryMinimumMilliseconds, a2: 2u); /*0x1067b87a5*/
}

// Address: 0x1067b883c | Name: __ZN5DFIntL98rbxImplDynInit_PlayerConfigurerMissingLocaleIdDetailsThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PlayerConfigurerMissingLocaleIdDetailsThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PlayerConfigurerMissingLocaleIdDetailsThrottleHundredthsPercent, a2: 2u); /*0x1067b884c*/
}

// Address: 0x1067b886f | Name: __ZN5DFIntL73rbxImplDynInit_LocationRecordSessionPercentHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_LocationRecordSessionPercentHundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::LocationRecordSessionPercentHundredths, a2: 2u); /*0x1067b887f*/
}

// Address: 0x1067b88a2 | Name: __ZN5DFIntL83rbxImplDynInit_CevIdleTimeoutTelemetryThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_CevIdleTimeoutTelemetryThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::CevIdleTimeoutTelemetryThrottleHundredthsPercent, a2: 2u); /*0x1067b88b2*/
}

// Address: 0x1067b88d5 | Name: __ZN5DFIntL86rbxImplDynInit_ClientGameLoadResultPointsThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientGameLoadResultPointsThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientGameLoadResultPointsThrottleHundredthsPercent, a2: 2u); /*0x1067b88e5*/
}

// Address: 0x1067b891e | Name: __ZN5DFIntL111rbxImplDynInit_RbxTransportEphemeralEarlyPubKeyPlayerClientLoadingThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportEphemeralEarlyPubKeyPlayerClientLoadingThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt( /*0x1067b892e*/
           a1: (__int64)&DFInt::RbxTransportEphemeralEarlyPubKeyPlayerClientLoadingThrottleHundredthsPercent,
           a2: 2u);
}

// Address: 0x1067b89a8 | Name: __ZN5DFIntL84rbxImplDynInit_RbxTransportAvailabilityThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportAvailabilityThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RbxTransportAvailabilityThrottleHundredthsPercent, a2: 2u); /*0x1067b89b8*/
}

// Address: 0x1067d98e9 | Name: __ZN5DFIntL63rbxImplDynInit_MaxHaltedPacketBytesToReportDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxHaltedPacketBytesToReportDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxHaltedPacketBytesToReport, a2: 2u); /*0x1067d98f9*/
}

// Address: 0x1067d991c | Name: __ZN5DFIntL61rbxImplDynInit_PPJProgressHaltThresholdMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PPJProgressHaltThresholdMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PPJProgressHaltThresholdMs, a2: 2u); /*0x1067d992c*/
}

// Address: 0x1067d9932 | Name: __ZN5DFIntL66rbxImplDynInit_PPJProgressHaltReportThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PPJProgressHaltReportThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PPJProgressHaltReportThrottleHP, a2: 2u); /*0x1067d9942*/
}

// Address: 0x1067d9948 | Name: __ZN5DFIntL61rbxImplDynInit_DPJProgressHaltThresholdMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DPJProgressHaltThresholdMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DPJProgressHaltThresholdMs, a2: 2u); /*0x1067d9958*/
}

// Address: 0x1067d995e | Name: __ZN5DFIntL66rbxImplDynInit_DPJProgressHaltReportThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DPJProgressHaltReportThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DPJProgressHaltReportThrottleHP, a2: 2u); /*0x1067d996e*/
}

// Address: 0x1067d99ae | Name: __ZN5DFIntL67rbxImplDynInit_NetworkDataSenderHaltThresholdMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkDataSenderHaltThresholdMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkDataSenderHaltThresholdMs, a2: 2u); /*0x1067d99be*/
}

// Address: 0x1067d99c4 | Name: __ZN5DFIntL72rbxImplDynInit_NetworkDataSenderHaltReportThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkDataSenderHaltReportThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkDataSenderHaltReportThrottleHP, a2: 2u); /*0x1067d99d4*/
}

// Address: 0x1067d99da | Name: __ZN5DFIntL70rbxImplDynInit_NetworkPhysicsSenderHaltThresholdMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkPhysicsSenderHaltThresholdMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkPhysicsSenderHaltThresholdMs, a2: 2u); /*0x1067d99ea*/
}

// Address: 0x1067d99f0 | Name: __ZN5DFIntL75rbxImplDynInit_NetworkPhysicsSenderHaltReportThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkPhysicsSenderHaltReportThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkPhysicsSenderHaltReportThrottleHP, a2: 2u); /*0x1067d9a00*/
}

// Address: 0x1067dba9c | Name: __ZN5DFIntL69rbxImplDynInit_JoinBlobInvalidateThresholdPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_JoinBlobInvalidateThresholdPercentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::JoinBlobInvalidateThresholdPercent, a2: 2u); /*0x1067dbaac*/
}

// Address: 0x1067dbab2 | Name: __ZN5DFIntL74rbxImplDynInit_JoinBlobInvalidateCountThresholdPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_JoinBlobInvalidateCountThresholdPercentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::JoinBlobInvalidateCountThresholdPercent, a2: 2u); /*0x1067dbac2*/
}

// Address: 0x1067dbac8 | Name: __ZN5DFIntL81rbxImplDynInit_JoinDataItemEstimatedCompressionRatioHundrethsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_JoinDataItemEstimatedCompressionRatioHundrethsDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::JoinDataItemEstimatedCompressionRatioHundreths, a2: 2u); /*0x1067dbad8*/
}

// Address: 0x1067dbade | Name: __ZN5DFIntL71rbxImplDynInit_ReplicationDataCacheNumParallelTasksDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicationDataCacheNumParallelTasksDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicationDataCacheNumParallelTasks, a2: 2u); /*0x1067dbaee*/
}

// Address: 0x1067e4237 | Name: __ZN5DFIntL65rbxImplDynInit_MaxTerrainClusterChunkSizeLog2DynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxTerrainClusterChunkSizeLog2DynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxTerrainClusterChunkSizeLog2, a2: 2u); /*0x1067e4247*/
}

// Address: 0x1067e7c57 | Name: __ZN5DFIntL70rbxImplDynInit_ClientSendEventStringDataLimitBytesDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientSendEventStringDataLimitBytesDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientSendEventStringDataLimitBytes, a2: 2u); /*0x1067e7c67*/
}

// Address: 0x1067e7c6d | Name: __ZN5DFIntL67rbxImplDynInit_ClientSendEventVariantCountLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientSendEventVariantCountLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientSendEventVariantCountLimit, a2: 2u); /*0x1067e7c7d*/
}

// Address: 0x1067e7c83 | Name: __ZN5DFIntL70rbxImplDynInit_RCCReceiveEventStringDataLimitBytesDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RCCReceiveEventStringDataLimitBytesDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RCCReceiveEventStringDataLimitBytes, a2: 2u); /*0x1067e7c93*/
}

// Address: 0x1067e7c99 | Name: __ZN5DFIntL67rbxImplDynInit_RCCReceiveEventVariantCountLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RCCReceiveEventVariantCountLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RCCReceiveEventVariantCountLimit, a2: 2u); /*0x1067e7ca9*/
}

// Address: 0x1067e7caf | Name: __ZN5DFIntL74rbxImplDynInit_RCCReceiveEventStringDataReportingBytesDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RCCReceiveEventStringDataReportingBytesDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RCCReceiveEventStringDataReportingBytes, a2: 2u); /*0x1067e7cbf*/
}

// Address: 0x1067e7cc5 | Name: __ZN5DFIntL71rbxImplDynInit_RCCReceiveEventVariantReportingCountDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RCCReceiveEventVariantReportingCountDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RCCReceiveEventVariantReportingCount, a2: 2u); /*0x1067e7cd5*/
}

// Address: 0x1067e7cdb | Name: __ZN5DFIntL75rbxImplDynInit_ReplicatorEventReportEventMetaDataMyriadDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorEventReportEventMetaDataMyriadDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorEventReportEventMetaDataMyriad, a2: 2u); /*0x1067e7ceb*/
}

// Address: 0x1067e7cf1 | Name: __ZN5DFIntL71rbxImplDynInit_EventMetaDataReportingDepthThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_EventMetaDataReportingDepthThresholdDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::EventMetaDataReportingDepthThreshold, a2: 2u); /*0x1067e7d01*/
}

// Address: 0x1067e7d07 | Name: __ZN5DFIntL78rbxImplDynInit_EventMetaDataReportingVariantCountThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_EventMetaDataReportingVariantCountThresholdDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::EventMetaDataReportingVariantCountThreshold, a2: 2u); /*0x1067e7d17*/
}

// Address: 0x1067e7d1d | Name: __ZN5DFIntL76rbxImplDynInit_EventMetaDataReportingStringSizeThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_EventMetaDataReportingStringSizeThresholdDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::EventMetaDataReportingStringSizeThreshold, a2: 2u); /*0x1067e7d2d*/
}

// Address: 0x1067e7d33 | Name: __ZN5DFIntL81rbxImplDynInit_EventMetaDataReportingTotalStreamSizeThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_EventMetaDataReportingTotalStreamSizeThresholdDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::EventMetaDataReportingTotalStreamSizeThreshold, a2: 2u); /*0x1067e7d43*/
}

// Address: 0x1067e7d49 | Name: __ZN5DFIntL77rbxImplDynInit_EventMetaDataReportingTotalMemoryThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_EventMetaDataReportingTotalMemoryThresholdDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::EventMetaDataReportingTotalMemoryThreshold, a2: 2u); /*0x1067e7d59*/
}

// Address: 0x1067ea536 | Name: __ZN5DFIntL60rbxImplDynInit_MaxJoinDataSendPerBurstKBDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxJoinDataSendPerBurstKBDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxJoinDataSendPerBurstKB, a2: 2u); /*0x1067ea546*/
}

// Address: 0x1067ea54c | Name: __ZN5DFIntL59rbxImplDynInit_MaxUREPayloadSingleLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxUREPayloadSingleLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxUREPayloadSingleLimit, a2: 2u); /*0x1067ea55c*/
}

// Address: 0x1067ea562 | Name: __ZN5DFIntL55rbxImplDynInit_TotalRepPayloadLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TotalRepPayloadLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TotalRepPayloadLimit, a2: 2u); /*0x1067ea572*/
}

// Address: 0x1067ea609 | Name: __ZN5DFIntL76rbxImplDynInit_ReportSendItemLimitMetricsStatsHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportSendItemLimitMetricsStatsHundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportSendItemLimitMetricsStatsHundredths, a2: 2u); /*0x1067ea619*/
}

// Address: 0x1067ea61f | Name: __ZN5DFIntL48rbxImplDynInit_SendItemLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendItemLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendItemLimit, a2: 2u); /*0x1067ea62f*/
}

// Address: 0x1067ea635 | Name: __ZN5DFIntL76rbxImplDynInit_ReportOversizedUnrelItemDroppedUnfairlyHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportOversizedUnrelItemDroppedUnfairlyHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportOversizedUnrelItemDroppedUnfairlyHP, a2: 2u); /*0x1067ea645*/
}

// Address: 0x1067ed83a | Name: __ZN5DFIntL89rbxImplDynInit_ReplicatorJoinDataItemV2StatsInfluxHundrethsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorJoinDataItemV2StatsInfluxHundrethsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorJoinDataItemV2StatsInfluxHundrethsPercentage, a2: 2u); /*0x1067ed84a*/
}

// Address: 0x1067ed850 | Name: __ZN5DFIntL90rbxImplDynInit_ReportJoinDataItemV2CacheEfficiencyHundrethsPercentage2DynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportJoinDataItemV2CacheEfficiencyHundrethsPercentage2DynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportJoinDataItemV2CacheEfficiencyHundrethsPercentage2, a2: 2u); /*0x1067ed860*/
}

// Address: 0x1067ed866 | Name: __ZN5DFIntL90rbxImplDynInit_ReportJoinInstanceCountStreamingDataHundredthPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportJoinInstanceCountStreamingDataHundredthPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportJoinInstanceCountStreamingDataHundredthPercentage, a2: 2u); /*0x1067ed876*/
}

// Address: 0x1067ed87c | Name: __ZN5DFIntL87rbxImplDynInit_ReportJoinInstaceStatsToEventIngestHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportJoinInstaceStatsToEventIngestHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportJoinInstaceStatsToEventIngestHundredthsPercent, a2: 2u); /*0x1067ed88c*/
}

// Address: 0x1067f3fde | Name: __ZN5DFIntL62rbxImplDynInit_SkipSomePropertiesPermyriadDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SkipSomePropertiesPermyriadDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SkipSomePropertiesPermyriad, a2: 2u); /*0x1067f3fee*/
}

// Address: 0x1067f402e | Name: __ZN5DFIntL71rbxImplDynInit_ReportNewInstancetemsItemsHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportNewInstancetemsItemsHundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportNewInstancetemsItemsHundredths, a2: 2u); /*0x1067f403e*/
}

// Address: 0x1067fd29e | Name: __ZN5DFIntL72rbxImplDynInit_MaxWaitTimeBeforeForcePacketProcessMSDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxWaitTimeBeforeForcePacketProcessMSDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxWaitTimeBeforeForcePacketProcessMS, a2: 2u); /*0x1067fd2ae*/
}

// Address: 0x1067fd2b4 | Name: __ZN5DFIntL66rbxImplDynInit_MaxProcessPacketsStepsPerCyclicDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxProcessPacketsStepsPerCyclicDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxProcessPacketsStepsPerCyclic, a2: 2u); /*0x1067fd2c4*/
}

// Address: 0x1067fd2ca | Name: __ZN5DFIntL68rbxImplDynInit_MaxProcessPacketsStepsAccumulatedDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxProcessPacketsStepsAccumulatedDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxProcessPacketsStepsAccumulated, a2: 2u); /*0x1067fd2da*/
}

// Address: 0x1067fd2e0 | Name: __ZN5DFIntL62rbxImplDynInit_MaxProcessPacketsJobScalingDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxProcessPacketsJobScalingDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxProcessPacketsJobScaling, a2: 2u); /*0x1067fd2f0*/
}

// Address: 0x1067fd2f6 | Name: __ZN5DFIntL45rbxImplDynInit_PpjEtrFillDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PpjEtrFillDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PpjEtrFill, a2: 2u); /*0x1067fd306*/
}

// Address: 0x1067fd30c | Name: __ZN5DFIntL44rbxImplDynInit_PpjPmFillDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PpjPmFillDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PpjPmFill, a2: 2u); /*0x1067fd31c*/
}

// Address: 0x1067fd322 | Name: __ZN5DFIntL42rbxImplDynInit_PpjLeakDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PpjLeakDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PpjLeak, a2: 2u); /*0x1067fd332*/
}

// Address: 0x1067fd338 | Name: __ZN5DFIntL46rbxImplDynInit_PpjCapacityDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PpjCapacityDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PpjCapacity, a2: 2u); /*0x1067fd348*/
}

// Address: 0x1067fd34e | Name: __ZN5DFIntL50rbxImplDynInit_PpjEtrThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PpjEtrThresholdDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PpjEtrThreshold, a2: 2u); /*0x1067fd35e*/
}

// Address: 0x1067fd364 | Name: __ZN5DFIntL49rbxImplDynInit_PpjPmThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PpjPmThresholdDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PpjPmThreshold, a2: 2u); /*0x1067fd374*/
}

// Address: 0x1067fd428 | Name: __ZN5DFIntL66rbxImplDynInit_NetworkProcessPacketThresholdMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkProcessPacketThresholdMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkProcessPacketThresholdMs, a2: 2u); /*0x1067fd438*/
}

// Address: 0x1067fd43e | Name: __ZN5DFIntL72rbxImplDynInit_NetworkInProcessLimitGameplayMsClientDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkInProcessLimitGameplayMsClientDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkInProcessLimitGameplayMsClient, a2: 2u); /*0x1067fd44e*/
}

// Address: 0x1067fd454 | Name: __ZN5DFIntL69rbxImplDynInit_NetworkInProcessLimitGameplayMsRccDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkInProcessLimitGameplayMsRccDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkInProcessLimitGameplayMsRcc, a2: 2u); /*0x1067fd464*/
}

// Address: 0x1067fd487 | Name: __ZN5DFIntL71rbxImplDynInit_ClientPacketHealthyAllocationPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientPacketHealthyAllocationPercentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientPacketHealthyAllocationPercent, a2: 2u); /*0x1067fd497*/
}

// Address: 0x1067fd49d | Name: __ZN5DFIntL70rbxImplDynInit_ClientPacketHealthyMsPerSecondLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientPacketHealthyMsPerSecondLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientPacketHealthyMsPerSecondLimit, a2: 2u); /*0x1067fd4ad*/
}

// Address: 0x1067fd4b3 | Name: __ZN5DFIntL74rbxImplDynInit_ClientPacketUnhealthyContEscMsPerSecondDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientPacketUnhealthyContEscMsPerSecondDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientPacketUnhealthyContEscMsPerSecond, a2: 2u); /*0x1067fd4c3*/
}

// Address: 0x1067fd4c9 | Name: __ZN5DFIntL62rbxImplDynInit_ClientPacketMinMicrosecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientPacketMinMicrosecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientPacketMinMicroseconds, a2: 2u); /*0x1067fd4d9*/
}

// Address: 0x1067fd4df | Name: __ZN5DFIntL67rbxImplDynInit_ClientPacketMaxFrameMicrosecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientPacketMaxFrameMicrosecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientPacketMaxFrameMicroseconds, a2: 2u); /*0x1067fd4ef*/
}

// Address: 0x1067fd4f5 | Name: __ZN5DFIntL65rbxImplDynInit_ClientPacketExcessMicrosecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientPacketExcessMicrosecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientPacketExcessMicroseconds, a2: 2u); /*0x1067fd505*/
}

// Address: 0x1067fd50b | Name: __ZN5DFIntL57rbxImplDynInit_ClientPacketMaxDelayMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientPacketMaxDelayMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientPacketMaxDelayMs, a2: 2u); /*0x1067fd51b*/
}

// Address: 0x106800e48 | Name: __ZN5DFIntL61rbxImplDynInit_MaxProflingDataPayloadSizeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxProflingDataPayloadSizeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxProflingDataPayloadSize, a2: 2u); /*0x106800e58*/
}

// Address: 0x106800e5e | Name: __ZN5DFIntL61rbxImplDynInit_MaxLuauHeapDataPayloadSizeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxLuauHeapDataPayloadSizeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxLuauHeapDataPayloadSize, a2: 2u); /*0x106800e6e*/
}

// Address: 0x106809ecf | Name: __ZN5DFIntL53rbxImplDynInit_ContentIdMaxLengthDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ContentIdMaxLengthDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ContentIdMaxLength, a2: 2u); /*0x106809edf*/
}

// Address: 0x106809f59 | Name: __ZN5DFIntL71rbxImplDynInit_NetworkReportContentIdLimitPerMyriadDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkReportContentIdLimitPerMyriadDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkReportContentIdLimitPerMyriad, a2: 2u); /*0x106809f69*/
}

// Address: 0x106809f6f | Name: __ZN5DFIntL66rbxImplDynInit_NetworkReportContentIdLimitReadDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkReportContentIdLimitReadDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkReportContentIdLimitRead, a2: 2u); /*0x106809f7f*/
}

// Address: 0x106809f85 | Name: __ZN5DFIntL65rbxImplDynInit_NetworkReportContentIdLimitMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkReportContentIdLimitMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkReportContentIdLimitMax, a2: 2u); /*0x106809f95*/
}

// Address: 0x106809f9b | Name: __ZN5DFIntL77rbxImplDynInit_NetworkReportContentIdLimitIntervalSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkReportContentIdLimitIntervalSecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkReportContentIdLimitIntervalSeconds, a2: 2u); /*0x106809fab*/
}

// Address: 0x106809fb1 | Name: __ZN5DFIntL73rbxImplDynInit_ClientReportRxTotalHundrethsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientReportRxTotalHundrethsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientReportRxTotalHundrethsPercentage, a2: 2u); /*0x106809fc1*/
}

// Address: 0x10680a03b | Name: __ZN5DFIntL76rbxImplDynInit_NetworkInDeserializeLimitGameplayMsClientDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkInDeserializeLimitGameplayMsClientDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkInDeserializeLimitGameplayMsClient, a2: 2u); /*0x10680a04b*/
}

// Address: 0x10680a051 | Name: __ZN5DFIntL73rbxImplDynInit_NetworkInDeserializeLimitGameplayMsRccDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkInDeserializeLimitGameplayMsRccDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkInDeserializeLimitGameplayMsRcc, a2: 2u); /*0x10680a061*/
}

// Address: 0x10680a0db | Name: __ZN5DFIntL56rbxImplDynInit_MaxClusterKBPerSecondDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxClusterKBPerSecondDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxClusterKBPerSecond, a2: 2u); /*0x10680a0eb*/
}

// Address: 0x10680a107 | Name: __ZN5DFIntL55rbxImplDynInit_MaxDataPacketPerSendDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxDataPacketPerSendDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxDataPacketPerSend, a2: 2u); /*0x10680a117*/
}

// Address: 0x10680a11d | Name: __ZN5DFIntL72rbxImplDynInit_PacketErrorInfluxHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PacketErrorInfluxHundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PacketErrorInfluxHundredthsPercentage, a2: 2u); /*0x10680a12d*/
}

// Address: 0x10680a133 | Name: __ZN5DFIntL78rbxImplDynInit_ReplicatorMaxPacketBytesSentToInfluxOnErrorDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorMaxPacketBytesSentToInfluxOnErrorDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorMaxPacketBytesSentToInfluxOnError, a2: 2u); /*0x10680a143*/
}

// Address: 0x10680a149 | Name: __ZN5DFIntL91rbxImplDynInit_StreamingReportPerformanceStatsAverageLerpValueThousandsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_StreamingReportPerformanceStatsAverageLerpValueThousandsDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::StreamingReportPerformanceStatsAverageLerpValueThousands, a2: 2u); /*0x10680a159*/
}

// Address: 0x10680a15f | Name: __ZN5DFIntL58rbxImplDynInit_SendRakNetStatsIntervalDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendRakNetStatsIntervalDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendRakNetStatsInterval, a2: 2u); /*0x10680a16f*/
}

// Address: 0x10680a175 | Name: __ZN5DFIntL63rbxImplDynInit_SendRakNetEarlyStatsIntervalDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendRakNetEarlyStatsIntervalDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendRakNetEarlyStatsInterval, a2: 2u); /*0x10680a185*/
}

// Address: 0x10680a18b | Name: __ZN5DFIntL59rbxImplDynInit_RakNetStatsShortIntervalDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RakNetStatsShortIntervalDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RakNetStatsShortInterval, a2: 2u); /*0x10680a19b*/
}

// Address: 0x10680a1a1 | Name: __ZN5DFIntL63rbxImplDynInit_EarlyReplicatorStatsMaxCountDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_EarlyReplicatorStatsMaxCountDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::EarlyReplicatorStatsMaxCount, a2: 2u); /*0x10680a1b1*/
}

// Address: 0x10680a1b7 | Name: __ZN5DFIntL58rbxImplDynInit_SendRakNetStatsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendRakNetStatsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendRakNetStatsThrottle, a2: 2u); /*0x10680a1c7*/
}

// Address: 0x10680a207 | Name: __ZN5DFIntL81rbxImplDynInit_ReportReplicatorStatsToInfluxHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportReplicatorStatsToInfluxHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportReplicatorStatsToInfluxHundredthsPercent, a2: 2u); /*0x10680a217*/
}

// Address: 0x10680a21d | Name: __ZN5DFIntL86rbxImplDynInit_ReportReplicatorEarlyStatsToInfluxHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportReplicatorEarlyStatsToInfluxHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportReplicatorEarlyStatsToInfluxHundredthsPercent, a2: 2u); /*0x10680a22d*/
}

// Address: 0x10680a233 | Name: __ZN5DFIntL95rbxImplDynInit_ReportReplicatorSessionSummaryStatsToInfluxHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportReplicatorSessionSummaryStatsToInfluxHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportReplicatorSessionSummaryStatsToInfluxHundredthsPercent, a2: 2u); /*0x10680a243*/
}

// Address: 0x10680a249 | Name: __ZN5DFIntL63rbxImplDynInit_MinPhyPacketsToCalculateLossDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MinPhyPacketsToCalculateLossDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MinPhyPacketsToCalculateLoss, a2: 2u); /*0x10680a259*/
}

// Address: 0x10680a32a | Name: __ZN5DFIntL60rbxImplDynInit_MissingDataPingIntervalMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MissingDataPingIntervalMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MissingDataPingIntervalMs, a2: 2u); /*0x10680a33a*/
}

// Address: 0x10680a340 | Name: __ZN5DFIntL61rbxImplDynInit_MissingDataPingThresholdMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MissingDataPingThresholdMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MissingDataPingThresholdMs, a2: 2u); /*0x10680a350*/
}

// Address: 0x10680a356 | Name: __ZN5DFIntL81rbxImplDynInit_MissingDataPingReportThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MissingDataPingReportThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MissingDataPingReportThrottleHundredthsPercent, a2: 2u); /*0x10680a366*/
}

// Address: 0x10680a3ff | Name: __ZN5DFIntL62rbxImplDynInit_DataPingTraceReportThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DataPingTraceReportThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DataPingTraceReportThrottle, a2: 2u); /*0x10680a40f*/
}

// Address: 0x10680a415 | Name: __ZN5DFIntL68rbxImplDynInit_DataPingTraceReportThrottleIngestDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DataPingTraceReportThrottleIngestDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DataPingTraceReportThrottleIngest, a2: 2u); /*0x10680a425*/
}

// Address: 0x10680a42b | Name: __ZN5DFIntL65rbxImplDynInit_DataPingTraceReportThrottleSecDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DataPingTraceReportThrottleSecDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DataPingTraceReportThrottleSec, a2: 2u); /*0x10680a43b*/
}

// Address: 0x10680a441 | Name: __ZN5DFIntL88rbxImplDynInit_ReportSimulationToFBLatencyInfluxHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportSimulationToFBLatencyInfluxHundredthsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportSimulationToFBLatencyInfluxHundredthsPercentage, a2: 2u); /*0x10680a451*/
}

// Address: 0x10680a457 | Name: __ZN5DFIntL75rbxImplDynInit_ReplicatorAnimationTrackLimitPerAnimatorDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorAnimationTrackLimitPerAnimatorDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorAnimationTrackLimitPerAnimator, a2: 2u); /*0x10680a467*/
}

// Address: 0x10680a46d | Name: __ZN5DFIntL70rbxImplDynInit_ReplicatorGraphParamRelayIntervalMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorGraphParamRelayIntervalMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorGraphParamRelayIntervalMs, a2: 2u); /*0x10680a47d*/
}

// Address: 0x10680a483 | Name: __ZN5DFIntL81rbxImplDynInit_ReportAnimationTrackSpamInfluxHundrethsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportAnimationTrackSpamInfluxHundrethsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportAnimationTrackSpamInfluxHundrethsPercent, a2: 2u); /*0x10680a493*/
}

// Address: 0x10680a4d3 | Name: __ZN5DFIntL75rbxImplDynInit_SendRakNetStatsThrottleStreamingOverrideDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendRakNetStatsThrottleStreamingOverrideDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendRakNetStatsThrottleStreamingOverride, a2: 2u); /*0x10680a4e3*/
}

// Address: 0x10680a4e9 | Name: __ZN5DFIntL78rbxImplDynInit_ReplicatorJoinSnapInfluxHundrethsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorJoinSnapInfluxHundrethsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorJoinSnapInfluxHundrethsPercentage, a2: 2u); /*0x10680a4f9*/
}

// Address: 0x10680a590 | Name: __ZN5DFIntL72rbxImplDynInit_ReplicationVariantReportingLimitBytesDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicationVariantReportingLimitBytesDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicationVariantReportingLimitBytes, a2: 2u); /*0x10680a5a0*/
}

// Address: 0x10680a5a6 | Name: __ZN5DFIntL67rbxImplDynInit_ReplicationVariantKickLimitBytesDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicationVariantKickLimitBytesDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicationVariantKickLimitBytes, a2: 2u); /*0x10680a5b6*/
}

// Address: 0x10680a5bc | Name: __ZN5DFIntL72rbxImplDynInit_ReplicationVariantReportingLimitDepthDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicationVariantReportingLimitDepthDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicationVariantReportingLimitDepth, a2: 2u); /*0x10680a5cc*/
}

// Address: 0x10680a60c | Name: __ZN5DFIntL70rbxImplDynInit_ReplicatorDataPingReportThresholdMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorDataPingReportThresholdMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorDataPingReportThresholdMs, a2: 2u); /*0x10680a61c*/
}

// Address: 0x10680a622 | Name: __ZN5DFIntL78rbxImplDynInit_ReplicatorDataPingReportHundredthPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorDataPingReportHundredthPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorDataPingReportHundredthPercentage, a2: 2u); /*0x10680a632*/
}

// Address: 0x10680a638 | Name: __ZN5DFIntL74rbxImplDynInit_ReplicatorDataPingReportThrottleSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorDataPingReportThrottleSecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorDataPingReportThrottleSeconds, a2: 2u); /*0x10680a648*/
}

// Address: 0x10680a688 | Name: __ZN5DFIntL76rbxImplDynInit_NetworkJDIReadProcessReportingThresholdMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkJDIReadProcessReportingThresholdMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkJDIReadProcessReportingThresholdMs, a2: 2u); /*0x10680a698*/
}

// Address: 0x10680a69e | Name: __ZN5DFIntL82rbxImplDynInit_NetworkStopProducingPacketsToProcessThresholdMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkStopProducingPacketsToProcessThresholdMsDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkStopProducingPacketsToProcessThresholdMs, a2: 2u); /*0x10680a6ae*/
}

// Address: 0x10680a6b4 | Name: __ZN5DFIntL72rbxImplDynInit_NetJdiProcessReportingIntervalSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetJdiProcessReportingIntervalSecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetJdiProcessReportingIntervalSeconds, a2: 2u); /*0x10680a6c4*/
}

// Address: 0x10680a6ca | Name: __ZN5DFIntL80rbxImplDynInit_NetworkReportJDIProcessingKibanaPerHunPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkReportJDIProcessingKibanaPerHunPercentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkReportJDIProcessingKibanaPerHunPercent, a2: 2u); /*0x10680a6da*/
}

// Address: 0x10680a6fd | Name: __ZN5DFIntL69rbxImplDynInit_ReplicatorJdiReportThrottlePercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorJdiReportThrottlePercentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorJdiReportThrottlePercent, a2: 2u); /*0x10680a70d*/
}

// Address: 0x10680a713 | Name: __ZN5DFIntL85rbxImplDynInit_ReplicatorJdiReportThrottlePercentStreamingEnabledDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorJdiReportThrottlePercentStreamingEnabledDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorJdiReportThrottlePercentStreamingEnabled, a2: 2u); /*0x10680a723*/
}

// Address: 0x10680a729 | Name: __ZN5DFIntL65rbxImplDynInit_NetLimiterReportingIntervalSecDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetLimiterReportingIntervalSecDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetLimiterReportingIntervalSec, a2: 2u); /*0x10680a739*/
}

// Address: 0x10680a73f | Name: __ZN5DFIntL71rbxImplDynInit_ClientAccessStreamJobReportPerMyriadDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientAccessStreamJobReportPerMyriadDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientAccessStreamJobReportPerMyriad, a2: 2u); /*0x10680a74f*/
}

// Address: 0x10680a755 | Name: __ZN5DFIntL66rbxImplDynInit_MinSizeToCacheSharedStringBytesDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MinSizeToCacheSharedStringBytesDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MinSizeToCacheSharedStringBytes, a2: 2u); /*0x10680a765*/
}

// Address: 0x10680a7fe | Name: __ZN5DFIntL58rbxImplDynInit_ClusterCompressionLevelDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClusterCompressionLevelDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClusterCompressionLevel, a2: 2u); /*0x10680a80e*/
}

// Address: 0x10680a814 | Name: __ZN5DFIntL77rbxImplDynInit_ClusterEstimatedCompressionRatioHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClusterEstimatedCompressionRatioHundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClusterEstimatedCompressionRatioHundredths, a2: 2u); /*0x10680a824*/
}

// Address: 0x10680a82a | Name: __ZN5DFIntL57rbxImplDynInit_BufferCompressionLevelDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_BufferCompressionLevelDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::BufferCompressionLevel, a2: 2u); /*0x10680a83a*/
}

// Address: 0x10680a840 | Name: __ZN5DFIntL61rbxImplDynInit_BufferCompressionThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_BufferCompressionThresholdDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::BufferCompressionThreshold, a2: 2u); /*0x10680a850*/
}

// Address: 0x10680a856 | Name: __ZN5DFIntL48rbxImplDynInit_RatePermyriadDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RatePermyriadDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RatePermyriad, a2: 2u); /*0x10680a866*/
}

// Address: 0x10680a86c | Name: __ZN5DFIntL63rbxImplDynInit_RemoteEventSoundRateLimitMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RemoteEventSoundRateLimitMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RemoteEventSoundRateLimitMax, a2: 2u); /*0x10680a87c*/
}

// Address: 0x10680a882 | Name: __ZN5DFIntL65rbxImplDynInit_RemoteEventSpecialRateLimitMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RemoteEventSpecialRateLimitMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RemoteEventSpecialRateLimitMax, a2: 2u); /*0x10680a892*/
}

// Address: 0x10680a898 | Name: __ZN5DFIntL64rbxImplDynInit_RemoteEventGlobalRateLimitMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RemoteEventGlobalRateLimitMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RemoteEventGlobalRateLimitMax, a2: 2u); /*0x10680a8a8*/
}

// Address: 0x10680a8ae | Name: __ZN5DFIntL64rbxImplDynInit_RemoteEventReportRateLimitMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RemoteEventReportRateLimitMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RemoteEventReportRateLimitMax, a2: 2u); /*0x10680a8be*/
}

// Address: 0x10680a8c4 | Name: __ZN5DFIntL68rbxImplDynInit_UnreliableRemoteEventRateLimitMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_UnreliableRemoteEventRateLimitMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::UnreliableRemoteEventRateLimitMax, a2: 2u); /*0x10680a8d4*/
}

// Address: 0x10680a8da | Name: __ZN5DFIntL69rbxImplDynInit_RemoteEventAbuseReportRateLimitMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RemoteEventAbuseReportRateLimitMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RemoteEventAbuseReportRateLimitMax, a2: 2u); /*0x10680a8ea*/
}

// Address: 0x10680a8f0 | Name: __ZN5DFIntL72rbxImplDynInit_RemoteEventSoundRateLimitMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RemoteEventSoundRateLimitMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RemoteEventSoundRateLimitMilliseconds, a2: 2u); /*0x10680a900*/
}

// Address: 0x10680a906 | Name: __ZN5DFIntL74rbxImplDynInit_RemoteEventSpecialRateLimitMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RemoteEventSpecialRateLimitMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RemoteEventSpecialRateLimitMilliseconds, a2: 2u); /*0x10680a916*/
}

// Address: 0x10680a91c | Name: __ZN5DFIntL73rbxImplDynInit_RemoteEventGlobalRateLimitMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RemoteEventGlobalRateLimitMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RemoteEventGlobalRateLimitMilliseconds, a2: 2u); /*0x10680a92c*/
}

// Address: 0x10680a932 | Name: __ZN5DFIntL77rbxImplDynInit_UnreliableRemoteEventRateLimitMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_UnreliableRemoteEventRateLimitMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::UnreliableRemoteEventRateLimitMilliseconds, a2: 2u); /*0x10680a942*/
}

// Address: 0x10680a948 | Name: __ZN5DFIntL73rbxImplDynInit_RemoteEventReportRateLimitMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RemoteEventReportRateLimitMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RemoteEventReportRateLimitMilliseconds, a2: 2u); /*0x10680a958*/
}

// Address: 0x10680a95e | Name: __ZN5DFIntL78rbxImplDynInit_RemoteEventAbuseReportRateLimitMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RemoteEventAbuseReportRateLimitMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RemoteEventAbuseReportRateLimitMilliseconds, a2: 2u); /*0x10680a96e*/
}

// Address: 0x10680a974 | Name: __ZN5DFIntL46rbxImplDynInit_DiqLimitMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DiqLimitMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DiqLimitMax, a2: 2u); /*0x10680a984*/
}

// Address: 0x10680a98a | Name: __ZN5DFIntL55rbxImplDynInit_DiqLimitMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DiqLimitMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DiqLimitMilliseconds, a2: 2u); /*0x10680a99a*/
}

// Address: 0x10680a9a0 | Name: __ZN5DFIntL52rbxImplDynInit_DiqLimitPermyriadDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DiqLimitPermyriadDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DiqLimitPermyriad, a2: 2u); /*0x10680a9b0*/
}

// Address: 0x10680a9b6 | Name: __ZN5DFIntL41rbxImplDynInit_QLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_QLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::QLimit, a2: 2u); /*0x10680a9c6*/
}

// Address: 0x10680a9cc | Name: __ZN5DFIntL40rbxImplDynInit_QKickDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_QKickDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::QKick, a2: 2u); /*0x10680a9dc*/
}

// Address: 0x10680a9e2 | Name: __ZN5DFIntL42rbxImplDynInit_RxRlEn2DynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RxRlEn2DynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RxRlEn2, a2: 2u); /*0x10680a9f2*/
}

// Address: 0x10680a9f8 | Name: __ZN5DFIntL45rbxImplDynInit_RxRlReportDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RxRlReportDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RxRlReport, a2: 2u); /*0x10680aa08*/
}

// Address: 0x10680aa0e | Name: __ZN5DFIntL67rbxImplDynInit_ReplicatorTopContainerCountLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorTopContainerCountLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorTopContainerCountLimit, a2: 2u); /*0x10680aa1e*/
}

// Address: 0x10680aa24 | Name: __ZN5DFIntL77rbxImplDynInit_ReplicatorVariantContainerCountReportLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorVariantContainerCountReportLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorVariantContainerCountReportLimit, a2: 2u); /*0x10680aa34*/
}

// Address: 0x10680aa3a | Name: __ZN5DFIntL71rbxImplDynInit_ReplicatorVariantContainerCountLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorVariantContainerCountLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorVariantContainerCountLimit, a2: 2u); /*0x10680aa4a*/
}

// Address: 0x10680aa50 | Name: __ZN5DFIntL90rbxImplDynInit_ReplicatorCountLimitInfluxReportOnlyHundrethsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorCountLimitInfluxReportOnlyHundrethsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorCountLimitInfluxReportOnlyHundrethsPercentage, a2: 2u); /*0x10680aa60*/
}

// Address: 0x10680aa66 | Name: __ZN5DFIntL80rbxImplDynInit_ReplicatorCountLimitInfluxHundrethsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorCountLimitInfluxHundrethsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorCountLimitInfluxHundrethsPercentage, a2: 2u); /*0x10680aa76*/
}

// Address: 0x10680aa7c | Name: __ZN5DFIntL67rbxImplDynInit_ReplicatorLegacyChatRateLimitMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorLegacyChatRateLimitMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorLegacyChatRateLimitMax, a2: 2u); /*0x10680aa8c*/
}

// Address: 0x10680aa92 | Name: __ZN5DFIntL76rbxImplDynInit_ReplicatorLegacyChatRateLimitMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorLegacyChatRateLimitMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorLegacyChatRateLimitMilliseconds, a2: 2u); /*0x10680aaa2*/
}

// Address: 0x10680aaa8 | Name: __ZN5DFIntL68rbxImplDynInit_ReplicatorVariantKickRateLimitMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorVariantKickRateLimitMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorVariantKickRateLimitMax, a2: 2u); /*0x10680aab8*/
}

// Address: 0x10680aabe | Name: __ZN5DFIntL77rbxImplDynInit_ReplicatorVariantKickRateLimitMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorVariantKickRateLimitMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorVariantKickRateLimitMilliseconds, a2: 2u); /*0x10680aace*/
}

// Address: 0x10680aad4 | Name: __ZN5DFIntL70rbxImplDynInit_ReplicatorVariantReportRateLimitMaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorVariantReportRateLimitMaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorVariantReportRateLimitMax, a2: 2u); /*0x10680aae4*/
}

// Address: 0x10680aaea | Name: __ZN5DFIntL79rbxImplDynInit_ReplicatorVariantReportRateLimitMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorVariantReportRateLimitMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorVariantReportRateLimitMilliseconds, a2: 2u); /*0x10680aafa*/
}

// Address: 0x10680ab00 | Name: __ZN5DFIntL85rbxImplDynInit_ReplicatorVariantSpeedReportPerHundredthPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorVariantSpeedReportPerHundredthPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorVariantSpeedReportPerHundredthPercentage, a2: 2u); /*0x10680ab10*/
}

// Address: 0x10680ab16 | Name: __ZN5DFIntL89rbxImplDynInit_ReplicatorVariantSpeedKickReportPerHundredthPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorVariantSpeedKickReportPerHundredthPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorVariantSpeedKickReportPerHundredthPercentage, a2: 2u); /*0x10680ab26*/
}

// Address: 0x10680ab49 | Name: __ZN5DFIntL45rbxImplDynInit_DepthLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DepthLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DepthLimit, a2: 2u); /*0x10680ab59*/
}

// Address: 0x10680ab5f | Name: __ZN5DFIntL73rbxImplDynInit_InitialClusterCacheNumberChunksPerStepDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_InitialClusterCacheNumberChunksPerStepDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::InitialClusterCacheNumberChunksPerStep, a2: 2u); /*0x10680ab6f*/
}

// Address: 0x10680ab75 | Name: __ZN5DFIntL73rbxImplDynInit_InitialClusterCacheMillisecondsPerStepDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_InitialClusterCacheMillisecondsPerStepDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::InitialClusterCacheMillisecondsPerStep, a2: 2u); /*0x10680ab85*/
}

// Address: 0x10680ab8b | Name: __ZN5DFIntL68rbxImplDynInit_InitialCacheClustersBandwidthKBpSDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_InitialCacheClustersBandwidthKBpSDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::InitialCacheClustersBandwidthKBpS, a2: 2u); /*0x10680ab9b*/
}

// Address: 0x10680aba1 | Name: __ZN5DFIntL70rbxImplDynInit_InitialCacheClustersMaxBytesPerSendDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_InitialCacheClustersMaxBytesPerSendDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::InitialCacheClustersMaxBytesPerSend, a2: 2u); /*0x10680abb1*/
}

// Address: 0x10680abb7 | Name: __ZN5DFIntL55rbxImplDynInit_MaxDataOutJobScalingDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxDataOutJobScalingDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxDataOutJobScaling, a2: 2u); /*0x10680abc7*/
}

// Address: 0x10680abcd | Name: __ZN5DFIntL79rbxImplDynInit_ReplicatorJoinDiagnosticLargeInstancesToKeepDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorJoinDiagnosticLargeInstancesToKeepDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorJoinDiagnosticLargeInstancesToKeep, a2: 2u); /*0x10680abdd*/
}

// Address: 0x10680abe3 | Name: __ZN5DFIntL74rbxImplDynInit_ReplicationVariantLimitHundredthPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicationVariantLimitHundredthPercentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicationVariantLimitHundredthPercent, a2: 2u); /*0x10680abf3*/
}

// Address: 0x10680ac16 | Name: __ZN5DFIntL78rbxImplDynInit_DetailedBandwidthStatsReportIntervalSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DetailedBandwidthStatsReportIntervalSecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DetailedBandwidthStatsReportIntervalSeconds, a2: 2u); /*0x10680ac26*/
}

// Address: 0x10680ac2c | Name: __ZN5DFIntL89rbxImplDynInit_DetailedBandwidthStatsPlayerLotteryHundrethsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DetailedBandwidthStatsPlayerLotteryHundrethsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DetailedBandwidthStatsPlayerLotteryHundrethsPercentage, a2: 2u); /*0x10680ac3c*/
}

// Address: 0x10680ac42 | Name: __ZN5DFIntL82rbxImplDynInit_DetailedBandwidthStatsInfluxHundrethsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DetailedBandwidthStatsInfluxHundrethsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DetailedBandwidthStatsInfluxHundrethsPercentage, a2: 2u); /*0x10680ac52*/
}

// Address: 0x10680ac58 | Name: __ZN5DFIntL78rbxImplDynInit_RaknetBandwidthInfluxHundredthsPercentageV2DynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RaknetBandwidthInfluxHundredthsPercentageV2DynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RaknetBandwidthInfluxHundredthsPercentageV2, a2: 2u); /*0x10680ac68*/
}

// Address: 0x10680ac6e | Name: __ZN5DFIntL71rbxImplDynInit_RaknetBandwidthPingSendEveryXSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RaknetBandwidthPingSendEveryXSecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RaknetBandwidthPingSendEveryXSeconds, a2: 2u); /*0x10680ac7e*/
}

// Address: 0x10680ac84 | Name: __ZN5DFIntL61rbxImplDynInit_TerrainReplicationMaxMasksDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TerrainReplicationMaxMasksDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TerrainReplicationMaxMasks, a2: 2u); /*0x10680ac94*/
}

// Address: 0x10680ac9a | Name: __ZN5DFIntL77rbxImplDynInit_MaxReceiveToDeserializeLatencyMillisecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxReceiveToDeserializeLatencyMillisecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxReceiveToDeserializeLatencyMilliseconds, a2: 2u); /*0x10680acaa*/
}

// Address: 0x10680acb0 | Name: __ZN5DFIntL70rbxImplDynInit_MaxNumInstanceSyncMapEntriesToDecayDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxNumInstanceSyncMapEntriesToDecayDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxNumInstanceSyncMapEntriesToDecay, a2: 2u); /*0x10680acc0*/
}

// Address: 0x10680ace3 | Name: __ZN5DFIntL70rbxImplDynInit_DisconnectReasonDiagThrottlePercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DisconnectReasonDiagThrottlePercentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DisconnectReasonDiagThrottlePercent, a2: 2u); /*0x10680acf3*/
}

// Address: 0x10680acf9 | Name: __ZN5DFIntL80rbxImplDynInit_DisconnectReasonElasticThrottleHundredPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DisconnectReasonElasticThrottleHundredPercentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DisconnectReasonElasticThrottleHundredPercent, a2: 2u); /*0x10680ad09*/
}

// Address: 0x10680ad2c | Name: __ZN5DFIntL66rbxImplDynInit_SendReplicatorStatsFacsOverrideDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendReplicatorStatsFacsOverrideDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendReplicatorStatsFacsOverride, a2: 2u); /*0x10680ad3c*/
}

// Address: 0x10680ad42 | Name: __ZN5DFIntL68rbxImplDynInit_SendReplicatorStatsFacsOverrideESDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SendReplicatorStatsFacsOverrideESDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SendReplicatorStatsFacsOverrideES, a2: 2u); /*0x10680ad52*/
}

// Address: 0x10680ad75 | Name: __ZN5DFIntL88rbxImplDynInit_ReportTopReplicationContainerAndAvatarStatsHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportTopReplicationContainerAndAvatarStatsHundredthsDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportTopReplicationContainerAndAvatarStatsHundredths, a2: 2u); /*0x10680ad85*/
}

// Address: 0x10680ad8b | Name: __ZN5DFIntL91rbxImplDynInit_ConnectionLostDisconnectReasonInfluxHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ConnectionLostDisconnectReasonInfluxHundredthsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ConnectionLostDisconnectReasonInfluxHundredthsPercentage, a2: 2u); /*0x10680ad9b*/
}

// Address: 0x10680adbe | Name: __ZN5DFIntL76rbxImplDynInit_ReportPacketQueueSizeHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportPacketQueueSizeHundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportPacketQueueSizeHundredthsPercentage, a2: 2u); /*0x10680adce*/
}

// Address: 0x10680add4 | Name: __ZN5DFIntL81rbxImplDynInit_ReportLargePacketQueueSizeHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportLargePacketQueueSizeHundredthsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportLargePacketQueueSizeHundredthsPercentage, a2: 2u); /*0x10680ade4*/
}

// Address: 0x10680adea | Name: __ZN5DFIntL63rbxImplDynInit_LargePacketQueueSizeCutoffMBDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_LargePacketQueueSizeCutoffMBDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::LargePacketQueueSizeCutoffMB, a2: 2u); /*0x10680adfa*/
}

// Address: 0x10680ae00 | Name: __ZN5DFIntL75rbxImplDynInit_ServerDelayDisconnectOnPlayerMoveSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerDelayDisconnectOnPlayerMoveSecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerDelayDisconnectOnPlayerMoveSeconds, a2: 2u); /*0x10680ae10*/
}

// Address: 0x10680ae16 | Name: __ZN5DFIntL68rbxImplDynInit_ModelLodBandwidthCumulateTimeMsecDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ModelLodBandwidthCumulateTimeMsecDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ModelLodBandwidthCumulateTimeMsec, a2: 2u); /*0x10680ae26*/
}

// Address: 0x10680ae2c | Name: __ZN5DFIntL53rbxImplDynInit_CLI64234HundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_CLI64234HundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::CLI64234Hundredths, a2: 2u); /*0x10680ae3c*/
}

// Address: 0x10680ae42 | Name: __ZN5DFIntL46rbxImplDynInit_CLI64234MaxDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_CLI64234MaxDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::CLI64234Max, a2: 2u); /*0x10680ae52*/
}

// Address: 0x10680ae58 | Name: __ZN5DFIntL73rbxImplDynInit_StreamingQuotaCalculationIntervalValueDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_StreamingQuotaCalculationIntervalValueDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::StreamingQuotaCalculationIntervalValue, a2: 2u); /*0x10680ae68*/
}

// Address: 0x10680ae84 | Name: __ZN5DFIntL61rbxImplDynInit_CallsBetweenUnreliablePingDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_CallsBetweenUnreliablePingDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::CallsBetweenUnreliablePing, a2: 2u); /*0x10680ae94*/
}

// Address: 0x10680ae9a | Name: __ZN5DFIntL97rbxImplDynInit_RobloxTelemetryClientDisconnectPointsThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RobloxTelemetryClientDisconnectPointsThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RobloxTelemetryClientDisconnectPointsThrottleHundredthsPercent, a2: 2u); /*0x10680aeaa*/
}

// Address: 0x10680aeb0 | Name: __ZN5DFIntL97rbxImplDynInit_RobloxTelemetryClientDisconnectEventsThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RobloxTelemetryClientDisconnectEventsThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RobloxTelemetryClientDisconnectEventsThrottleHundredthsPercent, a2: 2u); /*0x10680aec0*/
}

// Address: 0x10680aec6 | Name: __ZN5DFIntL94rbxImplDynInit_RobloxTelemetryRccDisconnectPointsThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RobloxTelemetryRccDisconnectPointsThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RobloxTelemetryRccDisconnectPointsThrottleHundredthsPercent, a2: 2u); /*0x10680aed6*/
}

// Address: 0x10680aedc | Name: __ZN5DFIntL94rbxImplDynInit_RobloxTelemetryRccDisconnectEventsThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RobloxTelemetryRccDisconnectEventsThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RobloxTelemetryRccDisconnectEventsThrottleHundredthsPercent, a2: 2u); /*0x10680aeec*/
}

// Address: 0x10680af0f | Name: __ZN5DFIntL104rbxImplDynInit_RobloxTelemetrySharedStringReplicationPointsThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RobloxTelemetrySharedStringReplicationPointsThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt( /*0x10680af1f*/
           a1: (__int64)&DFInt::RobloxTelemetrySharedStringReplicationPointsThrottleHundredthsPercent,
           a2: 2u);
}

// Address: 0x10680af25 | Name: __ZN5DFIntL76rbxImplDynInit_PacketMissingFrameWindowReportIntervalSecDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PacketMissingFrameWindowReportIntervalSecDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PacketMissingFrameWindowReportIntervalSec, a2: 2u); /*0x10680af35*/
}

// Address: 0x10680af3b | Name: __ZN5DFIntL103rbxImplDynInit_RobloxTelemetryPacketMissFrameWindowMetricsThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RobloxTelemetryPacketMissFrameWindowMetricsThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt( /*0x10680af4b*/
           a1: (__int64)&DFInt::RobloxTelemetryPacketMissFrameWindowMetricsThrottleHundredthsPercent,
           a2: 2u);
}

// Address: 0x10680afe2 | Name: __ZN5DFIntL59rbxImplDynInit_ItemSenderApiExMaxSizeKBDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ItemSenderApiExMaxSizeKBDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ItemSenderApiExMaxSizeKB, a2: 2u); /*0x10680aff2*/
}

// Address: 0x10680b04f | Name: __ZN5DFIntL58rbxImplDynInit_UnreliableItemTimeoutMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_UnreliableItemTimeoutMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::UnreliableItemTimeoutMs, a2: 2u); /*0x10680b05f*/
}

// Address: 0x10680b082 | Name: __ZN5DFIntL63rbxImplDynInit_CollisionMeshCachingIdModuloDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_CollisionMeshCachingIdModuloDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::CollisionMeshCachingIdModulo, a2: 2u); /*0x10680b092*/
}

// Address: 0x10680b098 | Name: __ZN5DFIntL66rbxImplDynInit_CollisionMeshCachingIdRemainderDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_CollisionMeshCachingIdRemainderDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::CollisionMeshCachingIdRemainder, a2: 2u); /*0x10680b0a8*/
}

// Address: 0x10680b0ae | Name: __ZN5DFIntL68rbxImplDynInit_CollisionMeshCachingSizeThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_CollisionMeshCachingSizeThresholdDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::CollisionMeshCachingSizeThreshold, a2: 2u); /*0x10680b0be*/
}

// Address: 0x10680b0c4 | Name: __ZN5DFIntL66rbxImplDynInit_CollisionMeshCachingMaxRecordedDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_CollisionMeshCachingMaxRecordedDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::CollisionMeshCachingMaxRecorded, a2: 2u); /*0x10680b0d4*/
}

// Address: 0x10680b0da | Name: __ZN5DFIntL66rbxImplDynInit_ISRNewTimestampItemEveryNFramesDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ISRNewTimestampItemEveryNFramesDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ISRNewTimestampItemEveryNFrames, a2: 2u); /*0x10680b0ea*/
}

// Address: 0x10680b214 | Name: __ZN5DFIntL72rbxImplDynInit_ClientReplicatorStatsEventsThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientReplicatorStatsEventsThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientReplicatorStatsEventsThrottleHP, a2: 2u); /*0x10680b224*/
}

// Address: 0x10680b22a | Name: __ZN5DFIntL72rbxImplDynInit_ServerReplicatorStatsEventsThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerReplicatorStatsEventsThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerReplicatorStatsEventsThrottleHP, a2: 2u); /*0x10680b23a*/
}

// Address: 0x10680b240 | Name: __ZN5DFIntL74rbxImplDynInit_TcClientReplicatorStatsEventsThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TcClientReplicatorStatsEventsThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TcClientReplicatorStatsEventsThrottleHP, a2: 2u); /*0x10680b250*/
}

// Address: 0x10680b256 | Name: __ZN5DFIntL74rbxImplDynInit_TcServerReplicatorStatsEventsThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TcServerReplicatorStatsEventsThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TcServerReplicatorStatsEventsThrottleHP, a2: 2u); /*0x10680b266*/
}

// Address: 0x10680b26c | Name: __ZN5DFIntL75rbxImplDynInit_ClientReplicatorEarlyStatsEventsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientReplicatorEarlyStatsEventsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientReplicatorEarlyStatsEventsThrottle, a2: 2u); /*0x10680b27c*/
}

// Address: 0x10680b282 | Name: __ZN5DFIntL75rbxImplDynInit_ServerReplicatorEarlyStatsEventsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerReplicatorEarlyStatsEventsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerReplicatorEarlyStatsEventsThrottle, a2: 2u); /*0x10680b292*/
}

// Address: 0x10680b298 | Name: __ZN5DFIntL77rbxImplDynInit_TcClientReplicatorEarlyStatsEventsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TcClientReplicatorEarlyStatsEventsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TcClientReplicatorEarlyStatsEventsThrottle, a2: 2u); /*0x10680b2a8*/
}

// Address: 0x10680b2ae | Name: __ZN5DFIntL77rbxImplDynInit_TcServerReplicatorEarlyStatsEventsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TcServerReplicatorEarlyStatsEventsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TcServerReplicatorEarlyStatsEventsThrottle, a2: 2u); /*0x10680b2be*/
}

// Address: 0x10680b2e1 | Name: __ZN5DFIntL78rbxImplDynInit_ClientReplicatorSessionSummaryStatsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientReplicatorSessionSummaryStatsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientReplicatorSessionSummaryStatsThrottle, a2: 2u); /*0x10680b2f1*/
}

// Address: 0x10680b2f7 | Name: __ZN5DFIntL78rbxImplDynInit_ServerReplicatorSessionSummaryStatsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerReplicatorSessionSummaryStatsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerReplicatorSessionSummaryStatsThrottle, a2: 2u); /*0x10680b307*/
}

// Address: 0x10680b30d | Name: __ZN5DFIntL80rbxImplDynInit_TcClientReplicatorSessionSummaryStatsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TcClientReplicatorSessionSummaryStatsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TcClientReplicatorSessionSummaryStatsThrottle, a2: 2u); /*0x10680b31d*/
}

// Address: 0x10680b323 | Name: __ZN5DFIntL80rbxImplDynInit_TcServerReplicatorSessionSummaryStatsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_TcServerReplicatorSessionSummaryStatsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::TcServerReplicatorSessionSummaryStatsThrottle, a2: 2u); /*0x10680b333*/
}

// Address: 0x10680b339 | Name: __ZN5DFIntL69rbxImplDynInit_ClientReplicatorCloseStatsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientReplicatorCloseStatsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientReplicatorCloseStatsThrottle, a2: 2u); /*0x10680b349*/
}

// Address: 0x10680b34f | Name: __ZN5DFIntL69rbxImplDynInit_ServerReplicatorCloseStatsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerReplicatorCloseStatsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerReplicatorCloseStatsThrottle, a2: 2u); /*0x10680b35f*/
}

// Address: 0x10680b365 | Name: __ZN5DFIntL77rbxImplDynInit_ClientNonLocalChildrenRemovalStatsThrottleDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ClientNonLocalChildrenRemovalStatsThrottleDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ClientNonLocalChildrenRemovalStatsThrottle, a2: 2u); /*0x10680b375*/
}

// Address: 0x10680b61a | Name: __ZN5DFIntL81rbxImplDynInit_DataPingTracerFpsInfoThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DataPingTracerFpsInfoThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DataPingTracerFpsInfoThrottleHundredthsPercent, a2: 2u); /*0x10680b62a*/
}

// Address: 0x10680b71c | Name: __ZN5DFIntL64rbxImplDynInit_ReplicatorSendErrorThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorSendErrorThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorSendErrorThrottleHP, a2: 2u); /*0x10680b72c*/
}

// Address: 0x10687643c | Name: __ZN5DFIntL57rbxImplDynInit_ReplicatorStatsSketchKDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicatorStatsSketchKDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicatorStatsSketchK, a2: 2u); /*0x10687644c*/
}

// Address: 0x106878233 | Name: __ZN5DFIntL56rbxImplDynInit_NfwlTrackingPermyriadDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NfwlTrackingPermyriadDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NfwlTrackingPermyriad, a2: 2u); /*0x106878243*/
}

// Address: 0x10687825f | Name: __ZN5DFIntL75rbxImplDynInit_InfluxReportRCCStatsHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_InfluxReportRCCStatsHundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::InfluxReportRCCStatsHundredthsPercentage, a2: 2u); /*0x10687826f*/
}

// Address: 0x106878275 | Name: __ZN5DFIntL66rbxImplDynInit_ServerReportStatInitialDelaySecDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerReportStatInitialDelaySecDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerReportStatInitialDelaySec, a2: 2u); /*0x106878285*/
}

// Address: 0x10687828b | Name: __ZN5DFIntL62rbxImplDynInit_ServerReportStatIntervalSecDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerReportStatIntervalSecDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerReportStatIntervalSec, a2: 2u); /*0x10687829b*/
}

// Address: 0x1068782a1 | Name: __ZN5DFIntL91rbxImplDynInit_ServerReportRakNetBandwidthTelemetryHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerReportRakNetBandwidthTelemetryHundredthsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerReportRakNetBandwidthTelemetryHundredthsPercentage, a2: 2u); /*0x1068782b1*/
}

// Address: 0x1068782f1 | Name: __ZN5DFIntL66rbxImplDynInit_ServerBandwidthPlayerSampleRateDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerBandwidthPlayerSampleRateDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerBandwidthPlayerSampleRate, a2: 2u); /*0x106878301*/
}

// Address: 0x106878307 | Name: __ZN5DFIntL78rbxImplDynInit_ServerBandwidthPlayerSampleRateFacsOverrideDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerBandwidthPlayerSampleRateFacsOverrideDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerBandwidthPlayerSampleRateFacsOverride, a2: 2u); /*0x106878317*/
}

// Address: 0x10687831d | Name: __ZN5DFIntL72rbxImplDynInit_ServerRakNetBandwidthPlayerSampleRateDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerRakNetBandwidthPlayerSampleRateDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerRakNetBandwidthPlayerSampleRate, a2: 2u); /*0x10687832d*/
}

// Address: 0x106878366 | Name: __ZN5DFIntL66rbxImplDynInit_DynIpBlacklisBackoffTickSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DynIpBlacklisBackoffTickSecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DynIpBlacklisBackoffTickSeconds, a2: 2u); /*0x106878376*/
}

// Address: 0x10687837c | Name: __ZN5DFIntL86rbxImplDynInit_ServerRakNetStartupFailureInfluxHundrethsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerRakNetStartupFailureInfluxHundrethsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerRakNetStartupFailureInfluxHundrethsPercentage, a2: 2u); /*0x10687838c*/
}

// Address: 0x106878392 | Name: __ZN5DFIntL51rbxImplDynInit_RccMaxPayloadRcvDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RccMaxPayloadRcvDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RccMaxPayloadRcv, a2: 2u); /*0x1068783a2*/
}

// Address: 0x1068783a8 | Name: __ZN5DFIntL51rbxImplDynInit_RccMaxPayloadSndDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RccMaxPayloadSndDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RccMaxPayloadSnd, a2: 2u); /*0x1068783b8*/
}

// Address: 0x1068783be | Name: __ZN5DFIntL53rbxImplDynInit_RccTcMaxPayloadRcvDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RccTcMaxPayloadRcvDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RccTcMaxPayloadRcv, a2: 2u); /*0x1068783ce*/
}

// Address: 0x1068783d4 | Name: __ZN5DFIntL53rbxImplDynInit_RccTcMaxPayloadSndDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RccTcMaxPayloadSndDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RccTcMaxPayloadSnd, a2: 2u); /*0x1068783e4*/
}

// Address: 0x1068783ea | Name: __ZN5DFIntL85rbxImplDynInit_ReportPhysicsFPSStatsForInfluxHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportPhysicsFPSStatsForInfluxHundredthsPercentageDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportPhysicsFPSStatsForInfluxHundredthsPercentage, a2: 2u); /*0x1068783fa*/
}

// Address: 0x106878400 | Name: __ZN5DFIntL87rbxImplDynInit_ReplicationRootCycleElasticThrottleHundredthsPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReplicationRootCycleElasticThrottleHundredthsPercentDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReplicationRootCycleElasticThrottleHundredthsPercent, a2: 2u); /*0x106878410*/
}

// Address: 0x106878416 | Name: __ZN5DFIntL99rbxImplDynInit_RCCPhysicsSimulationLoadStatsReportingThresholdPercentHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RCCPhysicsSimulationLoadStatsReportingThresholdPercentHundredthsDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt( /*0x106878426*/
           a1: (__int64)&DFInt::RCCPhysicsSimulationLoadStatsReportingThresholdPercentHundredths,
           a2: 2u);
}

// Address: 0x10687842c | Name: __ZN5DFIntL69rbxImplDynInit_ServerStatsReportingPerHundPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerStatsReportingPerHundPercentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerStatsReportingPerHundPercent, a2: 2u); /*0x10687843c*/
}

// Address: 0x106878442 | Name: __ZN5DFIntL77rbxImplDynInit_ServerStatsWithFacsReportingPerHundPercentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerStatsWithFacsReportingPerHundPercentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerStatsWithFacsReportingPerHundPercent, a2: 2u); /*0x106878452*/
}

// Address: 0x106878458 | Name: __ZN5DFIntL74rbxImplDynInit_ReportBaseNetworkMetricsStatsHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ReportBaseNetworkMetricsStatsHundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ReportBaseNetworkMetricsStatsHundredths, a2: 2u); /*0x106878468*/
}

// Address: 0x10687846e | Name: __ZN5DFIntL114rbxImplDynInit_RCCSimulatingInterpolationCorrectionDistanceReportingThresholdPercentHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RCCSimulatingInterpolationCorrectionDistanceReportingThresholdPercentHundredthsDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt( /*0x10687847e*/
           a1: (__int64)&DFInt::RCCSimulatingInterpolationCorrectionDistanceReportingThresholdPercentHundredths,
           a2: 2u);
}

// Address: 0x106878601 | Name: __ZN5DFIntL70rbxImplDynInit_RbxTransportDummyServerPortOverrideDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportDummyServerPortOverrideDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RbxTransportDummyServerPortOverride, a2: 2u); /*0x106878611*/
}

// Address: 0x10687862d | Name: __ZN5DFIntL78rbxImplDynInit_RbxTransportToRepUnexpectedEventThrottleSecDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportToRepUnexpectedEventThrottleSecDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RbxTransportToRepUnexpectedEventThrottleSec, a2: 2u); /*0x10687863d*/
}

// Address: 0x106878643 | Name: __ZN5DFIntL77rbxImplDynInit_RbxTransportToRepUnexpectedEventThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportToRepUnexpectedEventThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RbxTransportToRepUnexpectedEventThrottleHP, a2: 2u); /*0x106878653*/
}

// Address: 0x106878676 | Name: __ZN5DFIntL67rbxImplDynInit_RbxTransportPendingAuthTimeoutMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RbxTransportPendingAuthTimeoutMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RbxTransportPendingAuthTimeoutMs, a2: 2u); /*0x106878686*/
}

// Address: 0x1068991c8 | Name: __ZN5DFIntL79rbxImplDynInit_ServerJoinRejectCountHundredthPercentageSentDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerJoinRejectCountHundredthPercentageSentDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerJoinRejectCountHundredthPercentageSent, a2: 2u); /*0x1068991d8*/
}

// Address: 0x106899211 | Name: __ZN5DFIntL63rbxImplDynInit_DebugProfilerFramesToCaptureDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DebugProfilerFramesToCaptureDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DebugProfilerFramesToCapture, a2: 2u); /*0x106899221*/
}

// Address: 0x106899227 | Name: __ZN5DFIntL59rbxImplDynInit_DebugProfilerCaptureTimeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DebugProfilerCaptureTimeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DebugProfilerCaptureTime, a2: 2u); /*0x106899237*/
}

// Address: 0x10689923d | Name: __ZN5DFIntL43rbxImplDynInit_ChatTimeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ChatTimeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ChatTime, a2: 2u); /*0x10689924d*/
}

// Address: 0x106899253 | Name: __ZN5DFIntL42rbxImplDynInit_ChatCapDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ChatCapDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ChatCap, a2: 2u); /*0x106899263*/
}

// Address: 0x106899269 | Name: __ZN5DFIntL53rbxImplDynInit_RejoinRateLimitCapDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RejoinRateLimitCapDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RejoinRateLimitCap, a2: 2u); /*0x106899279*/
}

// Address: 0x10689927f | Name: __ZN5DFIntL54rbxImplDynInit_RejoinRateLimitTimeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RejoinRateLimitTimeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RejoinRateLimitTime, a2: 2u); /*0x10689928f*/
}

// Address: 0x106899309 | Name: __ZN5DFIntL79rbxImplDynInit_RCCJoinTransmissionStatsHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RCCJoinTransmissionStatsHundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RCCJoinTransmissionStatsHundredthsPercentage, a2: 2u); /*0x106899319*/
}

// Address: 0x10689931f | Name: __ZN5DFIntL56rbxImplDynInit_ServerItemTimeLimitMsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerItemTimeLimitMsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerItemTimeLimitMs, a2: 2u); /*0x10689932f*/
}

// Address: 0x106899335 | Name: __ZN5DFIntL72rbxImplDynInit_ServerPropSyncExpiryTeamCreateTimeSecDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_ServerPropSyncExpiryTeamCreateTimeSecDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::ServerPropSyncExpiryTeamCreateTimeSec, a2: 2u); /*0x106899345*/
}

// Address: 0x10689934b | Name: __ZN5DFIntL75rbxImplDynInit_OldServerPropSyncExpiryTeamCreateTimeSecDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_OldServerPropSyncExpiryTeamCreateTimeSecDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::OldServerPropSyncExpiryTeamCreateTimeSec, a2: 2u); /*0x10689935b*/
}

// Address: 0x10689937e | Name: __ZN5DFIntL49rbxImplDynInit_SpawnNameLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_SpawnNameLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::SpawnNameLimit, a2: 2u); /*0x10689938e*/
}

// Address: 0x1068993b1 | Name: __ZN5DFIntL60rbxImplDynInit_JoinInfoVariantCountLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_JoinInfoVariantCountLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::JoinInfoVariantCountLimit, a2: 2u); /*0x1068993c1*/
}

// Address: 0x1068993c7 | Name: __ZN5DFIntL69rbxImplDynInit_JoinInfoVariantCountReportingLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_JoinInfoVariantCountReportingLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::JoinInfoVariantCountReportingLimit, a2: 2u); /*0x1068993d7*/
}

// Address: 0x106899417 | Name: __ZN5DFIntL52rbxImplDynInit_JoinInfoMaxLengthDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_JoinInfoMaxLengthDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::JoinInfoMaxLength, a2: 2u); /*0x106899427*/
}

// Address: 0x10689942d | Name: __ZN5DFIntL58rbxImplDynInit_JoinInfoReportingLengthDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_JoinInfoReportingLengthDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::JoinInfoReportingLength, a2: 2u); /*0x10689943d*/
}

// Address: 0x10689947d | Name: __ZN5DFIntL75rbxImplDynInit_JoinInfoLengthReportHundredthsPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_JoinInfoLengthReportHundredthsPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::JoinInfoLengthReportHundredthsPercentage, a2: 2u); /*0x10689948d*/
}

// Address: 0x106899493 | Name: __ZN5DFIntL62rbxImplDynInit_PropRejectedCountPercentageDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PropRejectedCountPercentageDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PropRejectedCountPercentage, a2: 2u); /*0x1068994a3*/
}

// Address: 0x1068994c6 | Name: __ZN5DFIntL58rbxImplDynInit_LuaKickMaxMessageLengthDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_LuaKickMaxMessageLengthDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::LuaKickMaxMessageLength, a2: 2u); /*0x1068994d6*/
}

// Address: 0x1068994dc | Name: __ZN5DFIntL59rbxImplDynInit_LuaKickMaxMetadataLengthDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_LuaKickMaxMetadataLengthDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::LuaKickMaxMetadataLength, a2: 2u); /*0x1068994ec*/
}

// Address: 0x1068aff01 | Name: __ZN5DFIntL64rbxImplDynInit_MaxSharedStringsToStoreClientDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxSharedStringsToStoreClientDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxSharedStringsToStoreClient, a2: 2u); /*0x1068aff11*/
}

// Address: 0x1068aff17 | Name: __ZN5DFIntL64rbxImplDynInit_MaxSharedStringsToStoreServerDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxSharedStringsToStoreServerDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxSharedStringsToStoreServer, a2: 2u); /*0x1068aff27*/
}

// Address: 0x1068aff2d | Name: __ZN5DFIntL64rbxImplDynInit_MaxSharedStringCacheSizeBytesDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxSharedStringCacheSizeBytesDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxSharedStringCacheSizeBytes, a2: 2u); /*0x1068aff3d*/
}

// Address: 0x1068aff43 | Name: __ZN5DFIntL76rbxImplDynInit_MaxNumberOfExperiencesInSharedStringCacheDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MaxNumberOfExperiencesInSharedStringCacheDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MaxNumberOfExperiencesInSharedStringCache, a2: 2u); /*0x1068aff53*/
}

// Address: 0x1068b8ff8 | Name: __ZN5DFIntL62rbxImplDynInit_FrustumCrossSectionalAreaHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_FrustumCrossSectionalAreaHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::FrustumCrossSectionalAreaHP, a2: 2u); /*0x1068b9008*/
}

// Address: 0x1068b900e | Name: __ZN5DFIntL66rbxImplDynInit_FrustumVelocityAwareThresholdHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_FrustumVelocityAwareThresholdHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::FrustumVelocityAwareThresholdHP, a2: 2u); /*0x1068b901e*/
}

// Address: 0x1068b9024 | Name: __ZN5DFIntL70rbxImplDynInit_FrustumClientInstanceQuotaThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_FrustumClientInstanceQuotaThresholdDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::FrustumClientInstanceQuotaThreshold, a2: 2u); /*0x1068b9034*/
}

// Address: 0x1068b903a | Name: __ZN5DFIntL57rbxImplDynInit_FrustumMaxQueueUsageHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_FrustumMaxQueueUsageHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::FrustumMaxQueueUsageHP, a2: 2u); /*0x1068b904a*/
}

// Address: 0x1068b9050 | Name: __ZN5DFIntL51rbxImplDynInit_FrustumDequeSizeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_FrustumDequeSizeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::FrustumDequeSize, a2: 2u); /*0x1068b9060*/
}

// Address: 0x1068b9066 | Name: __ZN5DFIntL56rbxImplDynInit_HysteresisThresholdMSDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_HysteresisThresholdMSDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::HysteresisThresholdMS, a2: 2u); /*0x1068b9076*/
}

// Address: 0x1068b907c | Name: __ZN5DFIntL63rbxImplDynInit_FrustumExtraRegionsForCameraDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_FrustumExtraRegionsForCameraDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::FrustumExtraRegionsForCamera, a2: 2u); /*0x1068b908c*/
}

// Address: 0x1068b9092 | Name: __ZN5DFIntL68rbxImplDynInit_FrustumCameraStabilityThresholdHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_FrustumCameraStabilityThresholdHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::FrustumCameraStabilityThresholdHP, a2: 2u); /*0x1068b90a2*/
}

// Address: 0x1068b90a8 | Name: __ZN5DFIntL56rbxImplDynInit_FrustumSpeedThresholdDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_FrustumSpeedThresholdDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::FrustumSpeedThreshold, a2: 2u); /*0x1068b90b8*/
}

// Address: 0x1068b90f1 | Name: __ZN5DFIntL72rbxImplDynInit_CameraDistThresholdPercentOfCompletedDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_CameraDistThresholdPercentOfCompletedDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::CameraDistThresholdPercentOfCompleted, a2: 2u); /*0x1068b9101*/
}

// Address: 0x1068bb72e | Name: __ZN5DFIntL77rbxImplDynInit_RegionDeltaBeforeCalculatingPerRegionStatsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_RegionDeltaBeforeCalculatingPerRegionStatsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::RegionDeltaBeforeCalculatingPerRegionStats, a2: 2u); /*0x1068bb73e*/
}

// Address: 0x1068bb744 | Name: __ZN5DFIntL77rbxImplDynInit_MinRegionDeltaForValidMemoryEstimateChangeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_MinRegionDeltaForValidMemoryEstimateChangeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::MinRegionDeltaForValidMemoryEstimateChange, a2: 2u); /*0x1068bb754*/
}

// Address: 0x1068bb75a | Name: __ZN5DFIntL74rbxImplDynInit_NumChangesBeforeResettingPerRegionStatsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NumChangesBeforeResettingPerRegionStatsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NumChangesBeforeResettingPerRegionStats, a2: 2u); /*0x1068bb76a*/
}

// Address: 0x1068bb770 | Name: __ZN5DFIntL82rbxImplDynInit_NumFocusChangesBeforeResettingTargetRegionCountDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NumFocusChangesBeforeResettingTargetRegionCountDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NumFocusChangesBeforeResettingTargetRegionCount, a2: 2u); /*0x1068bb780*/
}

// Address: 0x1068bb786 | Name: __ZN5DFIntL70rbxImplDynInit_StreamingDistanceEmergencyGcUtilityDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_StreamingDistanceEmergencyGcUtilityDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::StreamingDistanceEmergencyGcUtility, a2: 2u); /*0x1068bb796*/
}

// Address: 0x1068bb79c | Name: __ZN5DFIntL90rbxImplDynInit_StreamingDistanceTunableTotalTimeSpentForGcMicroSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_StreamingDistanceTunableTotalTimeSpentForGcMicroSecondsDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::StreamingDistanceTunableTotalTimeSpentForGcMicroSeconds, a2: 2u); /*0x1068bb7ac*/
}

// Address: 0x1068bb7b2 | Name: __ZN5DFIntL73rbxImplDynInit_DebugTunableSlowCheckAvailableMemoryMBDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DebugTunableSlowCheckAvailableMemoryMBDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DebugTunableSlowCheckAvailableMemoryMB, a2: 2u); /*0x1068bb7c2*/
}

// Address: 0x1068bef2d | Name: __ZN5DFIntL68rbxImplDynInit_InstanceObjectManagerUEThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_InstanceObjectManagerUEThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::InstanceObjectManagerUEThrottleHP, a2: 2u); /*0x1068bef3d*/
}

// Address: 0x1068bef43 | Name: __ZN5DFIntL73rbxImplDynInit_InstanceObjectManagerUEIntervalSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_InstanceObjectManagerUEIntervalSecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::InstanceObjectManagerUEIntervalSeconds, a2: 2u); /*0x1068bef53*/
}

// Address: 0x1068d2ed6 | Name: __ZN5DFIntL63rbxImplDynInit_PathPrefetchLookaheadSecondsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PathPrefetchLookaheadSecondsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PathPrefetchLookaheadSeconds, a2: 2u); /*0x1068d2ee6*/
}

// Address: 0x1068d2eec | Name: __ZN5DFIntL66rbxImplDynInit_PathPrefetchMinSpeedStudsPerSecDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PathPrefetchMinSpeedStudsPerSecDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PathPrefetchMinSpeedStudsPerSec, a2: 2u); /*0x1068d2efc*/
}

// Address: 0x1068d2f02 | Name: __ZN5DFIntL66rbxImplDynInit_PathPrefetchMaxSpeedStudsPerSecDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PathPrefetchMaxSpeedStudsPerSecDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PathPrefetchMaxSpeedStudsPerSec, a2: 2u); /*0x1068d2f12*/
}

// Address: 0x1068d2f18 | Name: __ZN5DFIntL69rbxImplDynInit_PathPrefetchVelocitySmoothingTicksDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PathPrefetchVelocitySmoothingTicksDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PathPrefetchVelocitySmoothingTicks, a2: 2u); /*0x1068d2f28*/
}

// Address: 0x1068d3459 | Name: __ZN5DFIntL69rbxImplDynInit_PathPrefetchMeasureStatsThrottleHPDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PathPrefetchMeasureStatsThrottleHPDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PathPrefetchMeasureStatsThrottleHP, a2: 2u); /*0x1068d3469*/
}

// Address: 0x1068d39fc | Name: __ZN5DFIntL64rbxImplDynInit_PathPrefetchSymmetricWalkModeDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PathPrefetchSymmetricWalkModeDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PathPrefetchSymmetricWalkMode, a2: 2u); /*0x1068d3a0c*/
}

// Address: 0x1068d3a69 | Name: __ZN5DFIntL80rbxImplDynInit_PathPrefetchTurnConfidenceThresholdHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PathPrefetchTurnConfidenceThresholdHundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PathPrefetchTurnConfidenceThresholdHundredths, a2: 2u); /*0x1068d3a79*/
}

// Address: 0x1068d3a9c | Name: __ZN5DFIntL75rbxImplDynInit_PathPrefetchColdTurnMinDensityHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PathPrefetchColdTurnMinDensityHundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PathPrefetchColdTurnMinDensityHundredths, a2: 2u); /*0x1068d3aac*/
}

// Address: 0x1068d3ab2 | Name: __ZN5DFIntL60rbxImplDynInit_PathPrefetchDistanceStudsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PathPrefetchDistanceStudsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PathPrefetchDistanceStuds, a2: 2u); /*0x1068d3ac2*/
}

// Address: 0x1068d3ac8 | Name: __ZN5DFIntL68rbxImplDynInit_PathPrefetchHeatmapYWindowRegionsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_PathPrefetchHeatmapYWindowRegionsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::PathPrefetchHeatmapYWindowRegions, a2: 2u); /*0x1068d3ad8*/
}

// Address: 0x1068d4f59 | Name: __ZN5DFIntL59rbxImplDynInit_JoinDataCompressionLevelDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_JoinDataCompressionLevelDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::JoinDataCompressionLevel, a2: 2u); /*0x1068d4f69*/
}

// Address: 0x1068d4f6f | Name: __ZN5DFIntL72rbxImplDynInit_NetworkStreamingGCMaxMicroSecondLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkStreamingGCMaxMicroSecondLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkStreamingGCMaxMicroSecondLimit, a2: 2u); /*0x1068d4f7f*/
}

// Address: 0x1068d4f85 | Name: __ZN5DFIntL78rbxImplDynInit_NetworkStreamingGCUrgentMaxMicroSecondLimitDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkStreamingGCUrgentMaxMicroSecondLimitDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkStreamingGCUrgentMaxMicroSecondLimit, a2: 2u); /*0x1068d4f95*/
}

// Address: 0x1068d4f9b | Name: __ZN5DFIntL83rbxImplDynInit_NetworkStreamingGCMaxMicroSecondLimitPartsModelsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkStreamingGCMaxMicroSecondLimitPartsModelsDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkStreamingGCMaxMicroSecondLimitPartsModels, a2: 2u); /*0x1068d4fab*/
}

// Address: 0x1068d4fb1 | Name: __ZN5DFIntL89rbxImplDynInit_NetworkStreamingGCUrgentMaxMicroSecondLimitPartsModelsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_NetworkStreamingGCUrgentMaxMicroSecondLimitPartsModelsDynInit_FlagRegister(
        DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::NetworkStreamingGCUrgentMaxMicroSecondLimitPartsModels, a2: 2u); /*0x1068d4fc1*/
}

// Address: 0x1068d4fc7 | Name: __ZN5DFIntL57rbxImplDynInit_StreamedRegionGCFactorDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_StreamedRegionGCFactorDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::StreamedRegionGCFactor, a2: 2u); /*0x1068d4fd7*/
}

// Address: 0x1068d4fdd | Name: __ZN5DFIntL63rbxImplDynInit_StreamedRegionGCUrgentFactorDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_StreamedRegionGCUrgentFactorDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::StreamedRegionGCUrgentFactor, a2: 2u); /*0x1068d4fed*/
}

// Address: 0x1068d4ff3 | Name: __ZN5DFIntL58rbxImplDynInit_DebugRestrictGCDistanceDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DebugRestrictGCDistanceDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DebugRestrictGCDistance, a2: 2u); /*0x1068d5003*/
}

// Address: 0x1068d5026 | Name: __ZN5DFIntL62rbxImplDynInit_DebugStreamingRegionMaxDrawDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_DebugStreamingRegionMaxDrawDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::DebugStreamingRegionMaxDraw, a2: 2u); /*0x1068d5036*/
}

// Address: 0x1068d503c | Name: __ZN5DFIntL68rbxImplDynInit_StreamPauseVelBufFactorHundredthsDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_StreamPauseVelBufFactorHundredthsDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::StreamPauseVelBufFactorHundredths, a2: 2u); /*0x1068d504c*/
}

// Address: 0x1068d5052 | Name: __ZN5DFIntL68rbxImplDynInit_StreamingPauseVelBufMaxDurationMSDynInit_FlagRegisterEv
__int64 __fastcall DFInt::rbxImplDynInit_StreamingPauseVelBufMaxDurationMSDynInit_FlagRegister(DFInt *this)
{
  return FLog::RegisterInt(a1: (__int64)&DFInt::StreamingPauseVelBufMaxDurationMS, a2: 2u); /*0x1068d5062*/
}

// END DFInt part 10/12, 400 functions
