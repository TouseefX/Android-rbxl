// ItemQueue -- 2022 Studio + full PDB
// tier 3, 10 functions


// Address: 0x1410499c0 | Name: ??0ItemQueue@Network@RBX@@QEAA@XZ
RBX::Network::ItemQueue *__fastcall RBX::Network::ItemQueue::ItemQueue(RBX::Network::ItemQueue *this)
{
  std::vector<enum RBX::HumanoidRigJointLabel> *p_itemTypesInQueue; // rcx
  RBX::Network::ItemQueue *result; // rax
  RBX::HumanoidRigJointLabel _Val; // [rsp+38h] [rbp+10h] BYREF

  this->itemList.data_.root_plus_size_.m_header = 0; /*0x1410499d4*/
  this->itemList.data_.root_plus_size_.size_ = 0; /*0x1410499d9*/
  this->itemList.data_.root_plus_size_.m_header.next_ = &this->itemList.data_.root_plus_size_.m_header; /*0x1410499dc*/
  this->itemList.data_.root_plus_size_.m_header.prev_ = &this->itemList.data_.root_plus_size_.m_header; /*0x1410499df*/
  p_itemTypesInQueue = (std::vector<enum RBX::HumanoidRigJointLabel> *)&this->itemTypesInQueue; /*0x1410499e3*/
  p_itemTypesInQueue->_Mypair._Myval2._Myfirst = nullptr; /*0x1410499e7*/
  p_itemTypesInQueue->_Mypair._Myval2._Mylast = nullptr; /*0x1410499ea*/
  p_itemTypesInQueue->_Mypair._Myval2._Myend = nullptr; /*0x1410499ee*/
  _Val = 0; /*0x1410499f2*/
  __wind /*0xf1c0000000000028*/
  {
    __wind /*0xf1c0000000000030*/
    {
      std::vector<enum RBX::HumanoidRigJointLabel>::_Resize_reallocate<enum RBX::HumanoidRigJointLabel>( /*0x141049a00*/
        this: p_itemTypesInQueue,
        _Newsize: 0x1Eu,
        &_Val);
      result = this; /*0x141049a06*/
    }
    __unwind
    {
      std::vector<std::pair<unsigned short,unsigned short>>::~vector<std::pair<unsigned short,unsigned short>>(this: (std::vector<enum VkPresentModeKHR> *)&this->itemTypesInQueue); /*0x1431e822b*/
    }
  }
  __unwind
  {
    boost::intrusive::list<RBX::SimJob,boost::intrusive::base_hook<boost::intrusive::list_base_hook<boost::intrusive::tag<RBX::SimJob>,void,void>>,void,void,void>::~list<RBX::SimJob,boost::intrusive::base_hook<boost::intrusive::list_base_hook<boost::intrusive::tag<RBX::SimJob>,void,void>>,void,void,void>((boost::intrusive::list<RBX::SimJob,boost::intrusive::base_hook<boost::intrusive::list_base_hook<boost::intrusive::tag<RBX::SimJob>,void,void> >,void,void,void> *)this); /*0xf1c0000000000020*/
  }
  return result; /*0x141049a09*/
}

// Address: 0x141049a50 | Name: ??1ItemQueue@Network@RBX@@QEAA@XZ
void __fastcall RBX::Network::ItemQueue::~ItemQueue(RBX::Network::ItemQueue *this)
{
  int *Myfirst; // rcx
  boost::intrusive::list_node<void *> *next; // rax
  boost::intrusive::detail::default_header_holder<boost::intrusive::list_node_traits<void *> > *i; // rcx
  boost::intrusive::list_node<void *> *v5; // rdx

  Myfirst = this->itemTypesInQueue._Mypair._Myval2._Myfirst; /*0x141049a5f*/
  if ( Myfirst != nullptr ) /*0x141049a66*/
  {
    if ( (((char *)this->itemTypesInQueue._Mypair._Myval2._Myend - (char *)Myfirst) & 0xFFFFFFFFFFFFFFFCuLL) >= 0x1000 ) /*0x141049a7a*/
    {
      if ( (unsigned __int64)Myfirst - *((_QWORD *)Myfirst - 1) - 8 > 0x1F ) /*0x141049a8f*/
        _invalid_parameter_noinfo_noreturn(); /*0x141049ae7*/
      Myfirst = *((int **)Myfirst - 1); /*0x141049a91*/
    }
    operator delete(ptr: Myfirst); /*0x141049a94*/
    this->itemTypesInQueue._Mypair._Myval2._Myfirst = nullptr; /*0x141049a99*/
    this->itemTypesInQueue._Mypair._Myval2._Mylast = nullptr; /*0x141049a9d*/
    this->itemTypesInQueue._Mypair._Myval2._Myend = nullptr; /*0x141049aa1*/
  }
  next = this->itemList.data_.root_plus_size_.m_header.next_; /*0x141049aa5*/
  for ( i = &this->itemList.data_.root_plus_size_.m_header; next != i; v5->prev_ = nullptr ) /*0x141049ab0*/
  {
    v5 = next; /*0x141049ac0*/
    next = next->next_; /*0x141049ac3*/
    v5->next_ = nullptr; /*0x141049ac6*/
  }
  this->itemList.data_.root_plus_size_.size_ = 0; /*0x141049ad2*/
  i->next_ = nullptr; /*0x141049ada*/
  this->itemList.data_.root_plus_size_.m_header.prev_ = nullptr; /*0x141049add*/
}

// Address: 0x141049e70 | Name: ?debugDump@ItemQueue@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::ItemQueue::debugDump(RBX::Network::ItemQueue *this)
{
  boost::intrusive::list_node<void *> *next; // rbx
  boost::intrusive::detail::default_header_holder<boost::intrusive::list_node_traits<void *> > *p_m_header; // rdi
  unsigned __int8 v4; // cl
  boost::intrusive::detail::default_header_holder<boost::intrusive::list_node_traits<void *> > *v5; // rax
  const void **p_prev; // r8

  if ( FLog::NetworkItemQueueDtor != 0 )
  {
    FLog::FastLog(
      level: FLog::NetworkItemQueueDtor,
      message: "[FLog::NetworkItemQueueDtor] Items queued on destruction: %d",
      arg0: (const void *)SLODWORD(this->itemList.data_.root_plus_size_.size_));
    next = this->itemList.data_.root_plus_size_.m_header.next_; /*0x141049e98*/
    p_m_header = &this->itemList.data_.root_plus_size_.m_header; /*0x141049e9c*/
    if ( next != p_m_header ) /*0x141049ea3*/
    {
      v4 = FLog::NetworkItemQueueDtor; /*0x141049ea5*/
      v5 = (boost::intrusive::detail::default_header_holder<boost::intrusive::list_node_traits<void *> > *)next; /*0x141049eac*/
      do /*0x141049ef3*/
      {
        p_prev = (const void **)&v5[-1].prev_; /*0x141049ec3*/
        if ( v5 == nullptr ) /*0x141049ec7*/
          p_prev = nullptr; /*0x141049ec7*/
        if ( v4 != 0 ) /*0x141049ecd*/
        {
          FLog::FastLog( /*0x141049ede*/
            level: v4,
            message: "[FLog::NetworkItemQueueDtor] Item %p, vtable %p",
            arg0: p_prev,
            arg1: *p_prev,
            arg2: nullptr);
          v4 = FLog::NetworkItemQueueDtor; /*0x141049ee3*/
        }
        v5 = (boost::intrusive::detail::default_header_holder<boost::intrusive::list_node_traits<void *> > *)next->next_; /*0x141049eea*/
        next = v5; /*0x141049eed*/
      }
      while ( v5 != p_m_header ); /*0x141049ef3*/
    }
  }
}

// Address: 0x141049f10 | Name: ?deleteAll@ItemQueue@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::ItemQueue::deleteAll(RBX::Network::ItemQueue *this)
{
  boost::intrusive::detail::default_header_holder<boost::intrusive::list_node_traits<void *> > *p_m_header; // rsi
  boost::intrusive::detail::default_header_holder<boost::intrusive::list_node_traits<void *> > *next; // rdx
  boost::intrusive::list_node<void *> *prev; // rax
  boost::intrusive::list_node<void *> **p_prev; // rbx
  boost::intrusive::list_node<void *> *v6; // rcx
  int v7; // eax
  int *Mylast; // r8
  int *i; // rax
  __int64 v10; // rdx

  p_m_header = &this->itemList.data_.root_plus_size_.m_header; /*0x141049f22*/
  while ( 1 ) /*0x141049f30*/
  {
    next = (boost::intrusive::detail::default_header_holder<boost::intrusive::list_node_traits<void *> > *)p_m_header->next_; /*0x141049f30*/
    if ( p_m_header->next_ == nullptr || next == p_m_header ) /*0x141049f3b*/
      break; /*0x141049f3b*/
    prev = next->prev_; /*0x141049f3d*/
    p_prev = &next[-1].prev_; /*0x141049f41*/
    v6 = next->next_; /*0x141049f45*/
    prev->next_ = next->next_; /*0x141049f48*/
    v6->prev_ = prev; /*0x141049f4b*/
    --this->itemList.data_.root_plus_size_.size_; /*0x141049f52*/
    next->next_ = nullptr; /*0x141049f55*/
    next->prev_ = nullptr; /*0x141049f58*/
    v7 = ((__int64 (__fastcall *)(boost::intrusive::list_node<void *> **))next[-1].prev_[1].next_)(a1: &next[-1].prev_); /*0x141049f5f*/
    --this->itemTypesInQueue._Mypair._Myval2._Myfirst[v7]; /*0x141049f69*/
    if ( p_prev != nullptr ) /*0x141049f6f*/
      ((void (__fastcall *)(boost::intrusive::list_node<void *> **, __int64))(*p_prev)->next_)(a1: p_prev, a2: 1); /*0x141049f7c*/
  }
  Mylast = this->itemTypesInQueue._Mypair._Myval2._Mylast; /*0x141049f80*/
  for ( i = this->itemTypesInQueue._Mypair._Myval2._Myfirst; /*0x141049f95*/
        i != Mylast;
        this->itemTypesInQueue._Mypair._Myval2._Myfirst[v10] = 0 )
  {
    v10 = *i++; /*0x141049fa0*/
  }
}

// Address: 0x141049fc0 | Name: ?empty@ItemQueue@Network@RBX@@QEBA_NXZ
bool __fastcall RBX::Network::ItemQueue::empty(RBX::Network::ItemQueue *this)
{
  boost::intrusive::list_node<void *> *next; // rax
  boost::intrusive::detail::default_header_holder<boost::intrusive::list_node_traits<void *> > *p_m_header; // rcx

  next = this->itemList.data_.root_plus_size_.m_header.next_; /*0x141049fc0*/
  p_m_header = &this->itemList.data_.root_plus_size_.m_header; /*0x141049fc4*/
  return next == nullptr || next == p_m_header; /*0x141049fd4*/
}

// Address: 0x141049fe0 | Name: ?head_time@ItemQueue@Network@RBX@@QEBA?AVTime@3@XZ
RBX::Time *__fastcall RBX::Network::ItemQueue::head_time(RBX::Network::ItemQueue *this, RBX::Time *result)
{
  boost::intrusive::list_node<void *> *next; // rax
  boost::intrusive::detail::default_header_holder<boost::intrusive::list_node_traits<void *> > *p_m_header; // rcx
  long double v4; // xmm0_8

  next = this->itemList.data_.root_plus_size_.m_header.next_; /*0x141049fe0*/
  p_m_header = &this->itemList.data_.root_plus_size_.m_header; /*0x141049fe4*/
  if ( next == nullptr || next == p_m_header ) /*0x141049ff0*/
  {
    result->sec = 0.0; /*0x141049fff*/
    return result; /*0x14104a006*/
  }
  else
  {
    v4 = *(double *)&next[2].prev_; /*0x141049ff2*/
    result->sec = v4; /*0x141049ffa*/
    return result; /*0x141049ff7*/
  }
}

// Address: 0x14104a010 | Name: ?pop_if_present@ItemQueue@Network@RBX@@QEAA_NAEAPEAVItem@23@@Z
char __fastcall RBX::Network::ItemQueue::pop_if_present(
        RBX::Network::ItemQueue *this,
        boost::intrusive::list_node<void *> ***item)
{
  boost::intrusive::list_node<void *> *next; // rax
  boost::intrusive::detail::default_header_holder<boost::intrusive::list_node_traits<void *> > *p_m_header; // r8
  boost::intrusive::list_node<void *> *v6; // r8
  boost::intrusive::list_node<void *> *prev; // rax
  boost::intrusive::list_node<void *> *v8; // rdx
  RBX::Network::Item::ItemType v9; // eax

  next = this->itemList.data_.root_plus_size_.m_header.next_; /*0x14104a016*/
  p_m_header = &this->itemList.data_.root_plus_size_.m_header; /*0x14104a01a*/
  if ( next == nullptr || next == p_m_header ) /*0x14104a02c*/
    return 0; /*0x14104a06d*/
  *item = &next[-1].prev_; /*0x14104a032*/
  v6 = p_m_header->next_; /*0x14104a035*/
  prev = v6->prev_; /*0x14104a038*/
  v8 = v6->next_; /*0x14104a03c*/
  prev->next_ = v6->next_; /*0x14104a03f*/
  v8->prev_ = prev; /*0x14104a042*/
  --this->itemList.data_.root_plus_size_.size_; /*0x14104a048*/
  v6->next_ = nullptr; /*0x14104a04b*/
  v6->prev_ = nullptr; /*0x14104a04e*/
  v9 = ((unsigned int (__fastcall *)(boost::intrusive::list_node<void *> **))(**item)[1].next_)(a1: *item); /*0x14104a058*/
  --this->itemTypesInQueue._Mypair._Myval2._Myfirst[v9]; /*0x14104a062*/
  return 1; /*0x14104a067*/
}

// Address: 0x14104a080 | Name: ?push_back@ItemQueue@Network@RBX@@QEAAXPEAVItem@23@@Z
void __fastcall RBX::Network::ItemQueue::push_back(RBX::Network::ItemQueue *this, RBX::Network::Item *item)
{
  boost::intrusive::list_node<void *> *prev; // rax
  RBX::Network::Item::ItemType v5; // eax
  RBX::Time result; // [rsp+30h] [rbp+8h] BYREF

  item->timestamp = *(RBX::Time *)&RBX::Time::now<0>(&result)->sec; /*0x14104a0a9*/
  prev = this->itemList.data_.root_plus_size_.m_header.prev_; /*0x14104a0ae*/
  item->prev_ = prev; /*0x14104a0b2*/
  item->next_ = &this->itemList.data_.root_plus_size_.m_header; /*0x14104a0b6*/
  this->itemList.data_.root_plus_size_.m_header.prev_ = &item->boost::intrusive::list_base_hook<boost::intrusive::tag<RBX::Network::ItemTag>,void,void>; /*0x14104a0b9*/
  prev->next_ = &item->boost::intrusive::list_base_hook<boost::intrusive::tag<RBX::Network::ItemTag>,void,void>; /*0x14104a0bd*/
  ++this->itemList.data_.root_plus_size_.size_; /*0x14104a0c0*/
  v5 = item->getType(this: item); /*0x14104a0c6*/
  ++this->itemTypesInQueue._Mypair._Myval2._Myfirst[v5]; /*0x14104a0d5*/
}

// Address: 0x14104a0e0 | Name: ?push_front@ItemQueue@Network@RBX@@QEAAXPEAVItem@23@@Z
void __fastcall RBX::Network::ItemQueue::push_front(RBX::Network::ItemQueue *this, RBX::Network::Item *item)
{
  boost::intrusive::list_node<void *> *next; // r8
  boost::intrusive::list_node<void *> *prev; // rax
  RBX::Network::Item::ItemType v6; // eax
  RBX::Time result; // [rsp+30h] [rbp+8h] BYREF

  item->timestamp = *(RBX::Time *)&RBX::Time::now<0>(&result)->sec; /*0x14104a105*/
  next = this->itemList.data_.root_plus_size_.m_header.next_; /*0x14104a10a*/
  prev = next->prev_; /*0x14104a10e*/
  item->prev_ = prev; /*0x14104a112*/
  item->next_ = next; /*0x14104a116*/
  next->prev_ = &item->boost::intrusive::list_base_hook<boost::intrusive::tag<RBX::Network::ItemTag>,void,void>; /*0x14104a119*/
  prev->next_ = &item->boost::intrusive::list_base_hook<boost::intrusive::tag<RBX::Network::ItemTag>,void,void>; /*0x14104a11d*/
  ++this->itemList.data_.root_plus_size_.size_; /*0x14104a120*/
  v6 = item->getType(this: item); /*0x14104a126*/
  ++this->itemTypesInQueue._Mypair._Myval2._Myfirst[v6]; /*0x14104a135*/
}

// Address: 0x14104a140 | Name: ?push_front_preserve_timestamp@ItemQueue@Network@RBX@@QEAAXPEAVItem@23@@Z
void __fastcall RBX::Network::ItemQueue::push_front_preserve_timestamp(
        RBX::Network::ItemQueue *this,
        RBX::Network::Item *item)
{
  boost::intrusive::list_node<void *> *next; // r8
  boost::intrusive::list_node<void *> *prev; // rax
  RBX::Network::Item::ItemType v5; // eax

  next = this->itemList.data_.root_plus_size_.m_header.next_; /*0x14104a146*/
  prev = next->prev_; /*0x14104a151*/
  item->prev_ = prev; /*0x14104a155*/
  item->next_ = next; /*0x14104a159*/
  next->prev_ = &item->boost::intrusive::list_base_hook<boost::intrusive::tag<RBX::Network::ItemTag>,void,void>; /*0x14104a15c*/
  prev->next_ = &item->boost::intrusive::list_base_hook<boost::intrusive::tag<RBX::Network::ItemTag>,void,void>; /*0x14104a160*/
  ++this->itemList.data_.root_plus_size_.size_; /*0x14104a163*/
  v5 = item->getType(this: item); /*0x14104a16c*/
  ++this->itemTypesInQueue._Mypair._Myval2._Myfirst[v5]; /*0x14104a176*/
}

// END ItemQueue part 1/1, 10 functions
