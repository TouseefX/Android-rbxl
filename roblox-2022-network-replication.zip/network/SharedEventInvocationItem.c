// SharedEventInvocationItem -- 2022 Studio + full PDB
// tier 3, 7 functions


// Address: 0x1405d2670 | Name: ?getType@SharedEventInvocationItem@Network@RBX@@UEBA?AW4SharedQueueItemType@SharedQueueItem@23@XZ
__int64 __fastcall RBX::Network::SharedEventInvocationItem::getType(webrtc::RtcEventAudioReceiveStreamConfig *this)
{
  return 5; /*0x1405d2675*/
}

// Address: 0x1411493a0 | Name: ??0SharedEventInvocationItem@Network@RBX@@AEAA@PEBVEventDescriptor@Reflection@2@V?$shared_ptr@$$CBVInstance@RBX@@@std@@VTargetSet@12@PEBVReplicator@12@AEBV?$vector@VVariant@Reflection@RBX@@V?$allocator@VVariant@Reflection@RBX@@@std@@@6@PEBUClassEvent@NetworkSchema@12@_KW4SharedQueueInclusionType@SharedQueueItem@12@@Z
RBX::Network::SharedEventInvocationItem *__fastcall RBX::Network::SharedEventInvocationItem::SharedEventInvocationItem(
        RBX::Network::SharedEventInvocationItem *this,
        const RBX::Reflection::EventDescriptor *descriptor,
        std::shared_ptr<RBX::File> *eventInstance,
        std::vector<RBX::Graphics::FramebufferVulkan *> *excludedPeers,
        const RBX::Network::Replicator *debounceReplicator,
        const std::vector<RBX::Reflection::Variant> *args,
        const RBX::Network::NetworkSchema::ClassEvent *sharedClassEvent,
        unsigned __int64 nextId,
        RBX::Network::SharedQueueItem::SharedQueueInclusionType inclusionType)
{
  const RBX::Network::Replicator **Myend; // r9
  const RBX::Network::Replicator **Mylast; // rcx
  const RBX::Network::Replicator **Myfirst; // rax
  std::_Ref_count_base *Rep; // rax
  std::_Ref_count_base *v17; // rbx
  const RBX::Network::Replicator **v18; // rcx
  RBX::Network::SharedEventInvocationItem *result; // rax
  RBX::Network::TargetSet v20; // [rsp+30h] [rbp-58h] BYREF

  Myend = (const RBX::Network::Replicator **)excludedPeers->_Mypair._Myval2._Myend; /*0x1411493c5*/
  excludedPeers->_Mypair._Myval2._Myend = nullptr; /*0x1411493cb*/
  Mylast = (const RBX::Network::Replicator **)excludedPeers->_Mypair._Myval2._Mylast; /*0x1411493cf*/
  excludedPeers->_Mypair._Myval2._Mylast = nullptr; /*0x1411493d3*/
  Myfirst = (const RBX::Network::Replicator **)excludedPeers->_Mypair._Myval2._Myfirst; /*0x1411493d7*/
  excludedPeers->_Mypair._Myval2._Myfirst = nullptr; /*0x1411493da*/
  v20.targets.impl.data._Mypair._Myval2._Myfirst = Myfirst; /*0x1411493dd*/
  v20.targets.impl.data._Mypair._Myval2._Mylast = Mylast; /*0x1411493e1*/
  v20.targets.impl.data._Mypair._Myval2._Myend = Myend; /*0x1411493e5*/
  v20.targets.impl.count = (unsigned __int64)excludedPeers[1]._Mypair._Myval2._Myfirst; /*0x1411493ed*/
  v20.targets.impl.empty_key = (const RBX::Network::Replicator *)excludedPeers[1]._Mypair._Myval2._Mylast; /*0x1411493f5*/
  excludedPeers[1]._Mypair._Myval2._Myfirst = nullptr; /*0x1411493f9*/
  __wind /*0xf1c0000000000054*/
  {
    __wind /*0xf1c000000000005c*/
    {
      RBX::Network::SharedQueueItem::SharedQueueItem(this, nextId, targetsIn: &v20, inclusionType, debounceReplicator); /*0x141149420*/
      this->__vftable = (RBX::Network::SharedEventInvocationItem_vtbl *)RBX::Network::SharedEventInvocationItem::`vftable'; /*0x14114942d*/
      this->instance._Ptr = nullptr; /*0x141149430*/
      this->instance._Rep = nullptr; /*0x141149437*/
      this->instance._Ptr = eventInstance->_Ptr; /*0x141149441*/
      Rep = eventInstance->_Rep; /*0x141149448*/
      this->instance._Rep = Rep; /*0x14114944c*/
      eventInstance->_Ptr = nullptr; /*0x141149453*/
      eventInstance->_Rep = nullptr; /*0x141149456*/
      this->eventDescriptor = descriptor; /*0x14114945a*/
      __wind /*0xf1c0000000000010*/
      {
        __wind /*0xf1c0000000000018*/
        {
          std::vector<RBX::Reflection::Variant>::vector<RBX::Reflection::Variant>( /*0x141149470*/
            this: (std::vector<RBX::Reflection::Variant> *)&this->eventArgs,
            _Right: args);
          this->classEventFromSharedSchema = sharedClassEvent; /*0x14114947d*/
          v17 = eventInstance->_Rep; /*0x141149484*/
          if ( v17 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v17->_Uses, 0xFFFFFFFF) == 1 ) /*0x14114949c*/
          {
            v17->_Destroy(this: v17); /*0x1411494a4*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v17->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1411494ae*/
              v17->_Delete_this(this: v17); /*0x1411494b6*/
          }
          v18 = (const RBX::Network::Replicator **)excludedPeers->_Mypair._Myval2._Myfirst; /*0x1411494ba*/
          if ( excludedPeers->_Mypair._Myval2._Myfirst != nullptr ) /*0x1411494c0*/
          {
            if ( (((char *)excludedPeers->_Mypair._Myval2._Myend - (char *)v18) & 0xFFFFFFFFFFFFFFF8uLL) >= 0x1000 ) /*0x1411494d4*/
            {
              if ( (unsigned __int64)((char *)v18 - (char *)*(v18 - 1) - 8) > 0x1F ) /*0x1411494e9*/
                _invalid_parameter_noinfo_noreturn(); /*0x14114950c*/
              v18 = (const RBX::Network::Replicator **)*(v18 - 1); /*0x1411494eb*/
            }
            operator delete(ptr: v18); /*0x1411494ee*/
            excludedPeers->_Mypair._Myval2._Myfirst = nullptr; /*0x1411494f3*/
            excludedPeers->_Mypair._Myval2._Mylast = nullptr; /*0x1411494f6*/
            excludedPeers->_Mypair._Myval2._Myend = nullptr; /*0x1411494fa*/
          }
          result = this; /*0x1411494fe*/
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->instance); /*0x1431f15de*/
        }
      }
      __unwind
      {
        RBX::Network::SharedQueueItem::~SharedQueueItem(this); /*0xf1c0000000000034*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: eventInstance); /*0xf1c0000000000040*/
    }
  }
  __unwind
  {
    std::vector<Luau::AstExpr *>::~vector<Luau::AstExpr *>(this: excludedPeers); /*0xf1c000000000004c*/
  }
  return result; /*0x141149501*/
}

// Address: 0x141149520 | Name: ??0SharedEventInvocationItem@Network@RBX@@QEAA@PEBVEventDescriptor@Reflection@2@V?$shared_ptr@$$CBVInstance@RBX@@@std@@$$QEAV?$DenseHashSet@PEBVReplicator@Network@RBX@@U?$Hash@PEBVReplicator@Network@RBX@@@3@U?$equal_to@PEBVReplicator@Network@RBX@@@std@@@2@PEBVReplicator@12@AEBV?$vector@VVariant@Reflection@RBX@@V?$allocator@VVariant@Reflection@RBX@@@std@@@6@PEBUClassEvent@NetworkSchema@12@_KW4SharedQueueInclusionType@SharedQueueItem@12@@Z
RBX::Network::SharedEventInvocationItem *__fastcall RBX::Network::SharedEventInvocationItem::SharedEventInvocationItem(
        RBX::Network::SharedEventInvocationItem *this,
        const RBX::Reflection::EventDescriptor *descriptor,
        std::shared_ptr<RBX::File> *eventInstance,
        RBX::DenseHashSet<RBX::Network::Replicator const *,RBX::Hash<RBX::Network::Replicator const *>,std::equal_to<RBX::Network::Replicator const *> > *excludedPeers,
        const RBX::Network::Replicator *debounceReplicator,
        const std::vector<RBX::Reflection::Variant> *args,
        const RBX::Network::NetworkSchema::ClassEvent *sharedClassEvent,
        unsigned __int64 nextId,
        RBX::Network::SharedQueueItem::SharedQueueInclusionType inclusionType)
{
  const RBX::Network::Replicator **Myend; // r10
  const RBX::Network::Replicator **Mylast; // r8
  const RBX::Network::Replicator **Myfirst; // rax
  std::_Ref_count_base *Rep; // rax
  std::vector<RBX::Reflection::Variant> *p_eventArgs; // rcx
  std::_Ref_count_base *v16; // rbx
  RBX::Network::SharedEventInvocationItem *result; // rax

  this->__vftable = (RBX::Network::SharedEventInvocationItem_vtbl *)RBX::Network::SharedQueueItem::`vftable'; /*0x14114953e*/
  Myend = excludedPeers->impl.data._Mypair._Myval2._Myend; /*0x141149541*/
  excludedPeers->impl.data._Mypair._Myval2._Myend = nullptr; /*0x141149547*/
  Mylast = excludedPeers->impl.data._Mypair._Myval2._Mylast; /*0x14114954b*/
  excludedPeers->impl.data._Mypair._Myval2._Mylast = nullptr; /*0x14114954f*/
  Myfirst = excludedPeers->impl.data._Mypair._Myval2._Myfirst; /*0x141149553*/
  excludedPeers->impl.data._Mypair._Myval2._Myfirst = nullptr; /*0x141149556*/
  this->peerSet_deprecated.impl.data._Mypair._Myval2._Myfirst = Myfirst; /*0x141149559*/
  this->peerSet_deprecated.impl.data._Mypair._Myval2._Mylast = Mylast; /*0x14114955d*/
  this->peerSet_deprecated.impl.data._Mypair._Myval2._Myend = Myend; /*0x141149561*/
  this->peerSet_deprecated.impl.count = excludedPeers->impl.count; /*0x141149569*/
  this->peerSet_deprecated.impl.empty_key = excludedPeers->impl.empty_key; /*0x141149571*/
  excludedPeers->impl.count = 0; /*0x141149575*/
  this->targets.targets.impl.data._Mypair._Myval2._Myfirst = nullptr; /*0x141149582*/
  this->targets.targets.impl.data._Mypair._Myval2._Mylast = nullptr; /*0x141149585*/
  this->targets.targets.impl.data._Mypair._Myval2._Myend = nullptr; /*0x141149589*/
  this->targets.targets.impl.count = 0; /*0x14114958d*/
  this->targets.targets.impl.empty_key = nullptr; /*0x141149591*/
  this->usesTargetSet = false; /*0x141149595*/
  this->peerInclusivity = inclusionType; /*0x14114959f*/
  this->debouncingTarget = debounceReplicator; /*0x1411495a7*/
  this->id = nextId; /*0x1411495b0*/
  this->timestamp.sec = 0.0; /*0x1411495b4*/
  this->cacheStream._Ptr = nullptr; /*0x1411495bb*/
  this->cacheStream._Rep = nullptr; /*0x1411495c2*/
  this->sharedStringsInfo._Mypair._Myval2._Myfirst = nullptr; /*0x1411495c9*/
  this->sharedStringsInfo._Mypair._Myval2._Mylast = nullptr; /*0x1411495d0*/
  this->sharedStringsInfo._Mypair._Myval2._Myend = nullptr; /*0x1411495d7*/
  this->__vftable = (RBX::Network::SharedEventInvocationItem_vtbl *)RBX::Network::SharedEventInvocationItem::`vftable'; /*0x1411495e5*/
  this->instance._Ptr = nullptr; /*0x1411495e8*/
  this->instance._Rep = nullptr; /*0x1411495ef*/
  this->instance._Ptr = eventInstance->_Ptr; /*0x1411495f9*/
  Rep = eventInstance->_Rep; /*0x141149600*/
  this->instance._Rep = Rep; /*0x141149604*/
  eventInstance->_Ptr = nullptr; /*0x14114960b*/
  eventInstance->_Rep = nullptr; /*0x14114960e*/
  this->eventDescriptor = descriptor; /*0x141149612*/
  p_eventArgs = (std::vector<RBX::Reflection::Variant> *)&this->eventArgs; /*0x141149619*/
  __wind /*0xf1c0000000000034*/
  {
    __wind /*0xf1c000000000003c*/
    {
      __wind /*0xf1c0000000000044*/
      {
        std::vector<RBX::Reflection::Variant>::vector<RBX::Reflection::Variant>(this: p_eventArgs, _Right: args); /*0x141149625*/
        this->classEventFromSharedSchema = sharedClassEvent; /*0x14114962f*/
        v16 = eventInstance->_Rep; /*0x141149636*/
        if ( v16 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v16->_Uses, 0xFFFFFFFF) == 1 ) /*0x14114964e*/
        {
          v16->_Destroy(this: v16); /*0x141149656*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v16->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141149660*/
            v16->_Delete_this(this: v16); /*0x141149668*/
        }
        result = this; /*0x14114966b*/
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->instance); /*0x1431f160e*/
      }
    }
    __unwind
    {
      RBX::Network::SharedQueueItem::~SharedQueueItem(this); /*0xf1c0000000000020*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: eventInstance); /*0xf1c000000000002c*/
  }
  return result; /*0x14114966e*/
}

// Address: 0x14114a080 | Name: ?isPreserializable@SharedEventInvocationItem@Network@RBX@@UEBA_NXZ
bool __fastcall RBX::Network::SharedEventInvocationItem::isPreserializable(
        RBX::Network::SharedEventInvocationItem *this)
{
  return this->eventDescriptor->isBroadcast(this: this->eventDescriptor);
}

// Address: 0x14114a1f0 | Name: ?preserializeItem@SharedEventInvocationItem@Network@RBX@@UEBA_NAEAVReplicator@23@IAEAV?$shared_ptr@VNetworkStream@Network@RBX@@@std@@AEAV?$vector@VSharedString@RBX@@V?$allocator@VSharedString@RBX@@@std@@@6@@Z
char __fastcall RBX::Network::SharedEventInvocationItem::preserializeItem(
        RBX::Network::SharedEventInvocationItem *this,
        RBX::Network::Replicator *replicator,
        unsigned int replicationPeerIdType,
        std::shared_ptr<RBX::Network::NetworkStream> *bitStream,
        std::vector<RBX::SharedString> *sharedStringInfo)
{
  const RBX::Network::NetworkSchema::ClassEvent *classEventFromSharedSchema; // r9

  classEventFromSharedSchema = this->classEventFromSharedSchema; /*0x14114a1fc*/
  if ( classEventFromSharedSchema != nullptr ) /*0x14114a209*/
    return RBX::Network::Replicator::EventInvocationItem::preserialize( /*0x14114a23e*/
             bitStream: bitStream->_Ptr,
             replicator,
             replicationPeerIdType,
             classEvent: classEventFromSharedSchema,
             instance: (RBX::Reflection::Variant *)this->instance._Ptr,
             sharedArguments: &this->eventArgs,
             sharedStringInfo);
  else
    return 1; /*0x14114a20b*/
}

// Address: 0x14114a430 | Name: ?shouldRateLimitSend@SharedEventInvocationItem@Network@RBX@@UEBA_NAEAVReplicator@23@@Z
bool __fastcall RBX::Network::SharedEventInvocationItem::shouldRateLimitSend(
        RBX::Network::SharedEventInvocationItem *this,
        RBX::Network::Replicator *replicator)
{
  return replicator->shouldRateLimitTxRemoteEvents(
           this: replicator,
           a2: this->instance._Ptr,
           a3: this->eventDescriptor,
           a4: &this->eventArgs);
}

// Address: 0x14114a670 | Name: ?write@SharedEventInvocationItem@Network@RBX@@UEBA_NAEAVReplicator@23@AEAV?$shared_ptr@VNetworkStream@Network@RBX@@@std@@@Z
char __fastcall RBX::Network::SharedEventInvocationItem::write(
        RBX::Network::SharedEventInvocationItem *this,
        RBX::Network::Replicator *replicator,
        std::shared_ptr<RBX::Network::NetworkStream> *bitStream)
{
  const RBX::Network::NetworkSchema::ClassEvent *classEventFromSharedSchema; // r8

  classEventFromSharedSchema = this->classEventFromSharedSchema; /*0x14114a67c*/
  if ( classEventFromSharedSchema != nullptr ) /*0x14114a686*/
    return RBX::Network::Replicator::EventInvocationItem::writeDirect( /*0x14114a6c1*/
             bitStream: bitStream->_Ptr,
             replicator,
             classEvent: classEventFromSharedSchema,
             instance: this->instance._Ptr,
             sharedArguments: &this->eventArgs,
             preserializedCacheStream: &this->cacheStream,
             sharedStringsInPreserializedStream: &this->sharedStringsInfo);
  else
    return 1; /*0x14114a688*/
}

// END SharedEventInvocationItem part 1/1, 7 functions
