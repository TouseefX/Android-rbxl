// Item -- 2022 Studio + full PDB
// tier 3, 7 functions


// Address: 0x141049950 | Name: ??0Item@Network@RBX@@IEAA@AEAVReplicator@12@@Z
RBX::Network::Item *__fastcall RBX::Network::Item::Item(RBX::Network::Item *this, RBX::Network::Replicator *replicator)
{
  this->replicator = replicator; /*0x141049953*/
  this->next_ = nullptr; /*0x14104995e*/
  this->__vftable = (RBX::Network::Item_vtbl *)RBX::Network::Item::`vftable'; /*0x141049962*/
  this->prev_ = nullptr; /*0x141049965*/
  this->commonQueueItemId = replicator->megaReplicator->nextCommonId; /*0x14104997a*/
  this->needReceipt = false; /*0x14104997e*/
  this->timestamp.sec = 0.0; /*0x141049982*/
  return this; /*0x141049986*/
}

// Address: 0x141049990 | Name: ??0Item@Network@RBX@@IEAA@AEAVReplicator@12@_K@Z
RBX::Network::Item *__fastcall RBX::Network::Item::Item(
        RBX::Network::Item *this,
        RBX::Network::Replicator *replicator,
        unsigned __int64 commonQueueItemId)
{
  this->replicator = replicator; /*0x141049993*/
  this->next_ = nullptr; /*0x14104999e*/
  this->__vftable = (RBX::Network::Item_vtbl *)RBX::Network::Item::`vftable'; /*0x1410499a2*/
  this->prev_ = nullptr; /*0x1410499a8*/
  this->commonQueueItemId = commonQueueItemId; /*0x1410499ac*/
  this->needReceipt = false; /*0x1410499b0*/
  this->timestamp.sec = 0.0; /*0x1410499b4*/
  return this; /*0x1410499b8*/
}

// Address: 0x141049a40 | Name: ??1Item@Network@RBX@@UEAA@XZ
void __fastcall RBX::Network::Item::~Item(RBX::Network::PooledItem *this)
{
  this->__vftable = (RBX::Network::PooledItem_vtbl *)RBX::Network::Item::`vftable'; /*0x141049a47*/
}

// Address: 0x141049d10 | Name: ?convertItemEnumToString@Item@Network@RBX@@SAPEBDW4ItemType@123@@Z
const char *__fastcall RBX::Network::Item::convertItemEnumToString(RBX::Network::Item::ItemType type)
{
  const char *result; // rax

  switch ( type ) /*0x141049d2d*/
  {
    case ItemTypeEnd: /*0x141049d2d*/
      result = "End Item"; /*0x141049d2f*/
      break; /*0x141049d36*/
    case ItemTypeDelete: /*0x141049d2d*/
      result = "Delete Items"; /*0x141049d37*/
      break; /*0x141049d3e*/
    case ItemTypeNew: /*0x141049d2d*/
      result = "New Items"; /*0x141049d3f*/
      break; /*0x141049d46*/
    case ItemTypeChangeProperty: /*0x141049d2d*/
      result = "Change Property Items"; /*0x141049d47*/
      break; /*0x141049d4e*/
    case ItemTypeMarker: /*0x141049d2d*/
      result = "Marker Items"; /*0x141049d4f*/
      break; /*0x141049d56*/
    case ItemTypePing: /*0x141049d2d*/
    case ItemTypePingBack: /*0x141049d2d*/
    case ItemTypeRocky: /*0x141049d2d*/
    case ItemTypeHash: /*0x141049d2d*/
      result = "Other Items"; /*0x141049da7*/
      break; /*0x141049dae*/
    case ItemTypeEventInvocation: /*0x141049d2d*/
      result = "Event Invocation Items"; /*0x141049d57*/
      break; /*0x141049d5e*/
    case ItemTypeRequestCharacter: /*0x141049d2d*/
      result = "Request Character Items"; /*0x141049d5f*/
      break; /*0x141049d66*/
    case ItemTypeCFrameAcknowledgement: /*0x141049d2d*/
      result = "CFrame Ack Items"; /*0x141049d67*/
      break; /*0x141049d6e*/
    case ItemTypeJoinData: /*0x141049d2d*/
      result = "Join Data Items"; /*0x141049d6f*/
      break; /*0x141049d76*/
    case ItemTypeUpdateClientQuota_deprecated: /*0x141049d2d*/
      result = "Client Quota Update Items"; /*0x141049d77*/
      break; /*0x141049d7e*/
    case ItemTypeStreamData: /*0x141049d2d*/
      result = "Stream Data Items"; /*0x141049d7f*/
      break; /*0x141049d86*/
    case ItemTypeRegionRemoval: /*0x141049d2d*/
      result = "Region Removal Items"; /*0x141049d87*/
      break; /*0x141049d8e*/
    case ItemTypeInstanceRemoval: /*0x141049d2d*/
      result = "Instance Removal Items"; /*0x141049d8f*/
      break; /*0x141049d96*/
    case ItemTypeTag: /*0x141049d2d*/
      result = "Tag Items"; /*0x141049d97*/
      break; /*0x141049d9e*/
    case ItemTypeStats: /*0x141049d2d*/
      result = "Stats Items"; /*0x141049d9f*/
      break; /*0x141049da6*/
    case ItemTypeResolveDeferredTree: /*0x141049d2d*/
      result = "Resolve Atomic Tree Items"; /*0x141049daf*/
      break; /*0x141049db6*/
    case ItemTypeStreamDataInfo: /*0x141049d2d*/
      result = "Streaming Info Items"; /*0x141049db7*/
      break; /*0x141049dbe*/
    case ItemTypeJoinDataV2: /*0x141049d2d*/
      result = "Join Data Items V2"; /*0x141049dbf*/
      break; /*0x141049dc6*/
    case ItemTypeStreamTerrain: /*0x141049d2d*/
      result = "Stream Terrain Item"; /*0x141049dc7*/
      break; /*0x141049dce*/
    case ItemTypeStreamPrefetchDataInfo: /*0x141049d2d*/
      result = "Stream Prefetch Info Items"; /*0x141049dcf*/
      break; /*0x141049dd6*/
    case ItemTypeVisualEffect: /*0x141049d2d*/
      result = "Visual Effect Items"; /*0x141049dd7*/
      break; /*0x141049dde*/
    case ItemTypeUpdateClientStreamQuota: /*0x141049d2d*/
      result = "Client Quota Stream Update Items"; /*0x141049ddf*/
      break; /*0x141049de6*/
    default:
      result = "Unknown Items"; /*0x141049de7*/
      break; /*0x141049de7*/
  }
  return result; /*0x141049d36*/
}

// Address: 0x14104a1a0 | Name: ?readItemType@Item@Network@RBX@@SAXAEAVNetworkStream@23@AEAW4ItemType@123@@Z
void __fastcall RBX::Network::Item::readItemType(
        RBX::Network::NetworkStream *stream,
        RBX::Network::Item::ItemType *value)
{
  *value = RBX::Network::NetworkStream::readByte(this: stream); /*0x14104a1b1*/
}

// Address: 0x14104a1c0 | Name: ?writeItemType@Item@Network@RBX@@QEAAXAEAVNetworkStream@23@W4ItemType@123@@Z
void __fastcall RBX::Network::Item::writeItemType(
        RBX::Network::Item *this,
        RBX::Network::NetworkStream *stream,
        RBX::Network::Item::ItemType value)
{
  char v4; // bl
  char inByteArray; // [rsp+40h] [rbp+18h] BYREF

  v4 = value; /*0x14104a1d4*/
  RBX::Network::Replicator::incrementItemTypeSentCount(this: this->replicator, type: value); /*0x14104a1d7*/
  inByteArray = v4; /*0x14104a1e2*/
  RBX::Network::NetworkStream::writeBytes(this: stream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14104a1ee*/
}

// Address: 0x14104a200 | Name: ?writeItemType@Item@Network@RBX@@SAXAEAVReplicator@23@AEAVNetworkStream@23@W4ItemType@123@@Z
void __fastcall RBX::Network::Item::writeItemType(
        RBX::Network::Replicator *replicator,
        RBX::Network::NetworkStream *stream,
        RBX::Network::Item::ItemType value)
{
  char v4; // bl
  char inByteArray; // [rsp+40h] [rbp+18h] BYREF

  v4 = value; /*0x14104a20d*/
  RBX::Network::Replicator::incrementItemTypeSentCount(this: replicator, type: value); /*0x14104a213*/
  inByteArray = v4; /*0x14104a21e*/
  RBX::Network::NetworkStream::writeBytes(this: stream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14104a22a*/
}

// END Item part 1/1, 7 functions
