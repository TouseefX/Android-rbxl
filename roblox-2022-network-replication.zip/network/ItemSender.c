// ItemSender -- 2022 Studio + full PDB
// tier 3, 7 functions


// Address: 0x14113d550 | Name: ??0ItemSender@Replicator@Network@RBX@@QEAA@AEAV123@PEAVConcurrentRakPeer@23@I@Z
RBX::Network::Replicator::ItemSender *__fastcall RBX::Network::Replicator::ItemSender::ItemSender(
        RBX::Network::Replicator::ItemSender *this,
        RBX::Network::Replicator *replicator,
        RBX::Network::ConcurrentRakPeer *rakPeer,
        unsigned int streamSize)
{
  this->replicator = replicator; /*0x14113d552*/
  this->rakPeer = rakPeer; /*0x14113d555*/
  this->bitStream._Ptr = nullptr; /*0x14113d559*/
  this->bitStream._Rep = nullptr; /*0x14113d55d*/
  this->nextPacketRequestsReceipt = false; /*0x14113d561*/
  this->bytesSentByReadyStream = 0; /*0x14113d564*/
  this->sentItems = false; /*0x14113d567*/
  this->packetPriority = MEDIUM_PRIORITY; /*0x14113d56d*/
  this->maxStreamSize = streamSize; /*0x14113d574*/
  return this; /*0x14113d578*/
}

// Address: 0x14113d580 | Name: ?getNumberOfBytesUsed@ItemSender@Replicator@Network@RBX@@QEBAHXZ
unsigned int __fastcall RBX::Network::Replicator::ItemSender::getNumberOfBytesUsed(
        RBX::Network::Replicator::ItemSender *this)
{
  RBX::Network::NetworkStream *Ptr; // rcx

  Ptr = this->bitStream._Ptr; /*0x14113d580*/
  if ( Ptr != nullptr ) /*0x14113d587*/
    return Ptr->GetNumberOfBytesUsed(this: Ptr); /*0x14113d58c*/
  else
    return 0; /*0x14113d590*/
}

// Address: 0x14113d5a0 | Name: ?openPacket@ItemSender@Replicator@Network@RBX@@AEAAXI@Z
void __fastcall RBX::Network::Replicator::ItemSender::openPacket(
        RBX::Network::Replicator::ItemSender *this,
        unsigned int streamSize)
{
  RBX::Graphics::TextureVulkan::DownloadBuffer *v4; // rax
  RBX::Graphics::TextureVulkan::DownloadBuffer *v5; // rbx
  std::_Ref_count_base *v6; // rax
  std::_Ref_count_base *Rep; // rbx
  RBX::Network::NetworkStream *Ptr; // rcx
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> inByteArray; // [rsp+30h] [rbp+8h] BYREF
  std::_Ref_count_base *v10; // [rsp+40h] [rbp+18h]

  if ( this->bitStream._Ptr == nullptr ) /*0x14113d5b9*/
  {
    v4 = (RBX::Graphics::TextureVulkan::DownloadBuffer *)operator new(size: 0x40u); /*0x14113d5c4*/
    __wind /*0xf1c000000000001c*/
    {
      inByteArray._Ptr = v4; /*0x14113d5c9*/
      if ( v4 != nullptr ) /*0x14113d5d1*/
        v5 = (RBX::Graphics::TextureVulkan::DownloadBuffer *)RBX::Network::NetworkStream::NetworkStream( /*0x14113d5dd*/
                                                               this: (RBX::Network::NetworkStream *)v4,
                                                               initialBytesToAllocate: streamSize);
      else
        v5 = nullptr; /*0x14113d5e2*/
    }
    __unwind
    {
      operator delete(ptr: inByteArray._Ptr); /*0x143167422*/
    }
    __wind /*0xf1c0000000000034*/
    {
      inByteArray._Ptr = v5; /*0x14113d5e4*/
      v6 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x14113d5ee*/
      v10 = v6; /*0x14113d5f3*/
      if ( v6 != nullptr ) /*0x14113d5fb*/
      {
        *v6 = 0; /*0x14113d600*/
        v6->_Uses = 1; /*0x14113d603*/
        v6->_Weaks = 1; /*0x14113d60a*/
        v6->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::NetworkStream>::`vftable'; /*0x14113d618*/
        v6[1].__vftable = (std::_Ref_count_base_vtbl *)v5; /*0x14113d61b*/
      }
      this->bitStream._Ptr = (RBX::Network::NetworkStream *)v5; /*0x14113d61f*/
      Rep = this->bitStream._Rep; /*0x14113d623*/
      this->bitStream._Rep = v6; /*0x14113d627*/
      if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14113d63f*/
      {
        Rep->_Destroy(this: Rep); /*0x14113d647*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113d651*/
          Rep->_Delete_this(this: Rep); /*0x14113d659*/
      }
      LOBYTE(inByteArray._Ptr) = -125; /*0x14113d65c*/
      Ptr = this->bitStream._Ptr; /*0x14113d66c*/
    }
    __unwind
    {
      RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: &inByteArray); /*0xf1c0000000000014*/
    }
    RBX::Network::NetworkStream::writeBytes(this: Ptr, &inByteArray, numberOfBytesToWrite: 1u); /*0x14113d670*/
  }
}

// Address: 0x14113d6d0 | Name: ?send@ItemSender@Replicator@Network@RBX@@QEAA?AW4SendStatus@1234@AEAVItem@34@@Z
__int64 __fastcall RBX::Network::Replicator::ItemSender::send(
        RBX::Network::Replicator::ItemSender *this,
        RBX::Network::Item *item)
{
  RBX::Network::NetworkStream *Ptr; // rcx
  int v5; // r12d
  std::_Ref_count_base *Rep; // rcx
  std::_Ref_count_base *v7; // rdi
  bool v8; // al
  RBX::Network::NetworkStream *v9; // rcx
  bool v10; // zf
  RBX::Network::NetworkStream_vtbl *v11; // rax
  int v12; // r15d
  void *arg2; // rsi
  unsigned int v14; // edi
  unsigned __int8 *v15; // rax
  RBX::Network::ConcurrentRakPeer *v16; // rcx
  RBX::Network::TimeIntervalMeter *v17; // r9
  __int128 v18; // xmm1
  __int128 v19; // xmm2
  PacketPriority v20; // r8d
  std::_Ref_count_base *v21; // rdx
  RBX::Network::ConcurrentRakPeer *rakPeer; // rcx
  RBX::Network::TimeIntervalMeter *p_dataSendMeter; // r9
  __int128 v24; // xmm1
  __int128 v25; // xmm2
  PacketPriority packetPriority; // r8d
  std::_Ref_count_base *v27; // rdx
  RakNet::SystemAddress *v28; // rax
  std::shared_ptr<RBX::File> *v29; // rdx
  void *v30; // rsi
  unsigned int v31; // edi
  unsigned __int8 *v32; // rax
  RBX::Network::ConcurrentRakPeer *v33; // rcx
  RBX::Network::TimeIntervalMeter *v34; // r9
  __int128 v35; // xmm1
  __int128 v36; // xmm2
  PacketPriority v37; // r8d
  std::_Ref_count_base *v38; // rdx
  __int128 v39; // xmm1
  __int128 v40; // xmm2
  std::_Ref_count_base *v41; // rdx
  std::_Ref_count_base *v42; // rdi
  std::_Ref_count_base *v43; // rdi
  std::shared_ptr<RBX::Network::NetworkStream> stream; // [rsp+50h] [rbp-B0h] BYREF
  std::shared_ptr<RBX::File> v46; // [rsp+60h] [rbp-A0h] BYREF
  __int128 v47; // [rsp+70h] [rbp-90h] BYREF
  std::shared_ptr<RBX::File> v48; // [rsp+80h] [rbp-80h] BYREF
  __int128 v49; // [rsp+90h] [rbp-70h] BYREF
  RakNet::SystemAddress v50; // [rsp+A0h] [rbp-60h] BYREF
  _QWORD v51[4]; // [rsp+C0h] [rbp-40h] BYREF
  RakNet::SystemAddress v52; // [rsp+E0h] [rbp-20h] BYREF
  _QWORD v53[10]; // [rsp+100h] [rbp+0h] BYREF
  char inByteArray; // [rsp+160h] [rbp+60h] BYREF

  Ptr = this->bitStream._Ptr; /*0x14113d6f2*/
  if ( Ptr != nullptr && Ptr->GetNumberOfBytesUsed(this: Ptr) >= this->maxStreamSize ) /*0x14113d704*/
    return 0; /*0x14113d704*/
  if ( item->isPacketReadyToBeSent(this: item) )
  {
    if ( this->bitStream._Ptr == nullptr )
    {
      if ( DFInt::MaxJoinDataSendPerBurstKB <= 0 ) /*0x14113d72e*/
      {
        v5 = 60000; /*0x14113d742*/
        goto LABEL_9; /*0x14113d742*/
      }
      v5 = 1000 * DFInt::MaxJoinDataSendPerBurstKB; /*0x14113d730*/
      while ( v5 > 0 )
      {
LABEL_9:
        if ( !item->isPacketReadyToBeSent(this: item) ) /*0x14113d75b*/
          break; /*0x14113d75b*/
        item->getReadyBitStreamShared(this: item, result: &stream); /*0x14113d76c*/
        __wind
        {
          this->bytesSentByReadyStream += stream._Ptr->GetNumberOfBytesUsed(this: stream._Ptr); /*0x14113d77b*/
          Rep = stream._Rep; /*0x14113d77e*/
          if ( stream._Rep != nullptr ) /*0x14113d786*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&stream._Rep->_Uses); /*0x14113d788*/
            Rep = stream._Rep; /*0x14113d78c*/
          }
          this->bitStream._Ptr = stream._Ptr; /*0x14113d796*/
          v7 = this->bitStream._Rep; /*0x14113d79a*/
          this->bitStream._Rep = Rep; /*0x14113d79e*/
          if ( v7 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Uses, 0xFFFFFFFF) == 1 ) /*0x14113d7b4*/
          {
            v7->_Destroy(this: v7); /*0x14113d7bc*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113d7cb*/
              v7->_Delete_this(this: v7); /*0x14113d7d3*/
          }
          if ( DFFlag::FixJoinBitSettingInStream.value && item->getType(this: item) == ItemTypeJoinDataV2 ) /*0x14113d7eb*/
            this->bitStream._Ptr->isJoinData = true; /*0x14113d7f1*/
          v5 -= this->bitStream._Ptr->GetNumberOfBytesUsed(this: this->bitStream._Ptr); /*0x14113d7ff*/
          v8 = item->areCachedStreamsComplete(this: item); /*0x14113d808*/
          v9 = this->bitStream._Ptr; /*0x14113d80b*/
          if ( v9 == nullptr ) /*0x14113d812*/
            goto LABEL_62; /*0x14113d812*/
          v10 = !v8; /*0x14113d818*/
          v11 = v9->__vftable; /*0x14113d81a*/
          if ( v10 )
          {
            v12 = ((__int64 (*)(void))v11->GetNumberOfBytesUsed)(); /*0x14113d97e*/
            if ( v12 > 1 )
            {
              inByteArray = 0; /*0x14113d98a*/
              RBX::Network::NetworkStream::writeBytes( /*0x14113d99c*/
                this: this->bitStream._Ptr,
                &inByteArray,
                numberOfBytesToWrite: 1u);
              if ( DFLog::ReplicationDataCaching != 0 )
              {
                v30 = (void *)this->bitStream._Ptr->GetData(this: this->bitStream._Ptr)[2]; /*0x14113d9b4*/
                v31 = this->bitStream._Ptr->GetData(this: this->bitStream._Ptr)[1]; /*0x14113d9c2*/
                v32 = this->bitStream._Ptr->GetData(this: this->bitStream._Ptr); /*0x14113d9cd*/
                FLog::FastLog(
                  level: DFLog::ReplicationDataCaching,
                  message: "[DFLog::ReplicationDataCaching] Replicator::ItemSender::closePacket() : sending packet ID=%d, Type=%d, SubType=%d",
                  arg0: (const void *)*v32,
                  arg1: (const void *)v31,
                  arg2: v30);
              }
              if ( !DFFlag::GameLoadDataStatistics.value || !this->nextPacketRequestsReceipt ) /*0x14113da00*/
              {
                rakPeer = this->rakPeer; /*0x14113da81*/
                p_dataSendMeter = &this->replicator->dataSendMeter; /*0x14113da88*/
                v39 = *(_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr6.sin6_family; /*0x14113da8f*/
                v40 = *((_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr4 + 1); /*0x14113da96*/
                packetPriority = this->packetPriority; /*0x14113da9d*/
                v49 = 0; /*0x14113daa4*/
                v41 = this->bitStream._Rep; /*0x14113daa9*/
                if ( v41 != nullptr ) /*0x14113dab0*/
                {
                  _InterlockedIncrement((volatile signed __int32 *)&v41->_Uses); /*0x14113dab2*/
                  v41 = this->bitStream._Rep; /*0x14113dab6*/
                }
                *(_QWORD *)&v49 = this->bitStream._Ptr; /*0x14113dabe*/
                *((_QWORD *)&v49 + 1) = v41; /*0x14113dac2*/
                *(_OWORD *)v53 = v39; /*0x14113dac6*/
                *(_OWORD *)&v53[2] = v40; /*0x14113daca*/
                v28 = (RakNet::SystemAddress *)v53; /*0x14113dace*/
                v29 = (std::shared_ptr<RBX::File> *)&v49; /*0x14113dad2*/
                goto LABEL_44; /*0x14113dad2*/
              }
              v33 = this->rakPeer; /*0x14113da02*/
              v34 = &this->replicator->dataSendMeter; /*0x14113da09*/
              v35 = *(_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr6.sin6_family; /*0x14113da10*/
              v36 = *((_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr4 + 1); /*0x14113da17*/
              v37 = this->packetPriority; /*0x14113da1e*/
              v48 = 0; /*0x14113da25*/
              v38 = this->bitStream._Rep; /*0x14113da2a*/
              if ( v38 != nullptr ) /*0x14113da31*/
              {
                _InterlockedIncrement((volatile signed __int32 *)&v38->_Uses); /*0x14113da33*/
                v38 = this->bitStream._Rep; /*0x14113da37*/
              }
              v48._Ptr = (RBX::File *)this->bitStream._Ptr; /*0x14113da3f*/
              v48._Rep = v38; /*0x14113da43*/
              *(_OWORD *)&v52.address.addr6.sin6_family = v35; /*0x14113da47*/
              *((_OWORD *)&v52.address.addr4 + 1) = v36; /*0x14113da4b*/
              RBX::Network::ConcurrentRakPeer::Send( /*0x14113da76*/
                this: v33,
                bitStream: &v48,
                priority: v37,
                reliability: RELIABLE_ORDERED_WITH_ACK_RECEIPT,
                orderingChannel: 0,
                systemAddress: &v52,
                broadcast: false,
                meter: v34,
                forceDirectSend: false);
              this->nextPacketRequestsReceipt = false; /*0x14113da7b*/
LABEL_45:
              RBX::RunningAverageTimeInterval<1>::sample(this: &this->replicator->replicatorStats.dataPacketsSent); /*0x14113dafa*/
              RBX::RunningAverage<int,double>::sample( /*0x14113db16*/
                this: &this->replicator->replicatorStats.dataPacketsSentSize,
                value: v12);
            }
          }
          else
          {
            v12 = ((__int64 (*)(void))v11->GetNumberOfBytesUsed)(); /*0x14113d826*/
            if ( v12 > 1 )
            {
              if ( DFLog::ReplicationDataCaching != 0 )
              {
                arg2 = (void *)this->bitStream._Ptr->GetData(this: this->bitStream._Ptr)[2]; /*0x14113d845*/
                v14 = this->bitStream._Ptr->GetData(this: this->bitStream._Ptr)[1]; /*0x14113d853*/
                v15 = this->bitStream._Ptr->GetData(this: this->bitStream._Ptr); /*0x14113d85e*/
                FLog::FastLog(
                  level: DFLog::ReplicationDataCaching,
                  message: "[DFLog::ReplicationDataCaching] Replicator::ItemSender::sendPacket() : sending packet ID=%d, Type=%d, SubType=%d",
                  arg0: (const void *)*v15,
                  arg1: (const void *)v14,
                  arg2);
              }
              if ( DFFlag::GameLoadDataStatistics.value && this->nextPacketRequestsReceipt ) /*0x14113d88d*/
              {
                v16 = this->rakPeer; /*0x14113d897*/
                v17 = &this->replicator->dataSendMeter; /*0x14113d89e*/
                v18 = *(_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr6.sin6_family; /*0x14113d8a5*/
                v19 = *((_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr4 + 1); /*0x14113d8ac*/
                v20 = this->packetPriority; /*0x14113d8b3*/
                v46 = 0; /*0x14113d8ba*/
                v21 = this->bitStream._Rep; /*0x14113d8c0*/
                if ( v21 != nullptr ) /*0x14113d8c7*/
                {
                  _InterlockedIncrement((volatile signed __int32 *)&v21->_Uses); /*0x14113d8c9*/
                  v21 = this->bitStream._Rep; /*0x14113d8cd*/
                }
                v46._Ptr = (RBX::File *)this->bitStream._Ptr; /*0x14113d8d5*/
                v46._Rep = v21; /*0x14113d8da*/
                *(_OWORD *)&v50.address.addr6.sin6_family = v18; /*0x14113d8df*/
                *((_OWORD *)&v50.address.addr4 + 1) = v19; /*0x14113d8e3*/
                RBX::Network::ConcurrentRakPeer::Send( /*0x14113d90f*/
                  this: v16,
                  bitStream: &v46,
                  priority: v20,
                  reliability: RELIABLE_ORDERED_WITH_ACK_RECEIPT,
                  orderingChannel: 0,
                  systemAddress: &v50,
                  broadcast: false,
                  meter: v17,
                  forceDirectSend: false);
                this->nextPacketRequestsReceipt = false; /*0x14113d914*/
                goto LABEL_45; /*0x14113d918*/
              }
              rakPeer = this->rakPeer; /*0x14113d91d*/
              p_dataSendMeter = &this->replicator->dataSendMeter; /*0x14113d924*/
              v24 = *(_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr6.sin6_family; /*0x14113d92b*/
              v25 = *((_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr4 + 1); /*0x14113d932*/
              packetPriority = this->packetPriority; /*0x14113d939*/
              v47 = 0; /*0x14113d940*/
              v27 = this->bitStream._Rep; /*0x14113d946*/
              if ( v27 != nullptr ) /*0x14113d94d*/
              {
                _InterlockedIncrement((volatile signed __int32 *)&v27->_Uses); /*0x14113d94f*/
                v27 = this->bitStream._Rep; /*0x14113d953*/
              }
              *(_QWORD *)&v47 = this->bitStream._Ptr; /*0x14113d95b*/
              *((_QWORD *)&v47 + 1) = v27; /*0x14113d960*/
              *(_OWORD *)v51 = v24; /*0x14113d965*/
              *(_OWORD *)&v51[2] = v25; /*0x14113d969*/
              v28 = (RakNet::SystemAddress *)v51; /*0x14113d96d*/
              v29 = (std::shared_ptr<RBX::File> *)&v47; /*0x14113d971*/
LABEL_44:
              RBX::Network::ConcurrentRakPeer::Send( /*0x14113dad6*/
                this: rakPeer,
                bitStream: v29,
                priority: packetPriority,
                reliability: RELIABLE_ORDERED,
                orderingChannel: 0,
                systemAddress: v28,
                broadcast: false,
                meter: p_dataSendMeter,
                forceDirectSend: false);
              goto LABEL_45; /*0x14113daf5*/
            }
          }
          v42 = this->bitStream._Rep; /*0x14113db1b*/
          this->bitStream._Rep = nullptr; /*0x14113db22*/
          this->bitStream._Ptr = nullptr; /*0x14113db26*/
          if ( v42 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v42->_Uses, 0xFFFFFFFF) == 1 ) /*0x14113db39*/
          {
            v42->_Destroy(this: v42); /*0x14113db41*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v42->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113db50*/
              v42->_Delete_this(this: v42); /*0x14113db58*/
          }
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&stream); /*0xf1c0000000000008*/
        }
LABEL_62:
        v43 = stream._Rep; /*0x14113db5c*/
        if ( stream._Rep != nullptr /*0x14113db73*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&stream._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v43->_Destroy(this: v43); /*0x14113db7b*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v43->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113db8a*/
            v43->_Delete_this(this: v43); /*0x14113db92*/
        }
      }
    }
    if ( !item->isPacketReadyToBeSent(this: item) ) /*0x14113dba9*/
      goto LABEL_56; /*0x14113dba9*/
    return 0; /*0x14113dc01*/
  }
  RBX::Network::Replicator::ItemSender::openPacket(this, streamSize: this->maxStreamSize); /*0x14113dbe9*/
  if ( !item->write(this: item, a2: this->bitStream._Ptr) ) /*0x14113dbfd*/
    return 0; /*0x14113dbfd*/
LABEL_56:
  if ( DFFlag::GameLoadDataStatistics.value && item->needReceipt ) /*0x14113dbb4*/
    this->nextPacketRequestsReceipt = true; /*0x14113dbbb*/
  this->sentItems = true; /*0x14113dbbf*/
  return 1; /*0x14113dbc8*/
}

// Address: 0x14113dc10 | Name: ?sendPacket@ItemSender@Replicator@Network@RBX@@AEAAXXZ
void __fastcall RBX::Network::Replicator::ItemSender::sendPacket(RBX::Network::Replicator::ItemSender *this)
{
  RBX::Network::NetworkStream *Ptr; // rcx
  int v3; // ebp
  void *arg2; // rdi
  unsigned int v5; // ebx
  unsigned __int8 *v6; // rax
  std::shared_ptr<RBX::File> v7; // rax
  RBX::Network::ConcurrentRakPeer *rakPeer; // rcx
  PacketPriority packetPriority; // r8d
  RBX::Network::TimeIntervalMeter *p_dataSendMeter; // r9
  __int128 v11; // xmm1
  __int128 v12; // xmm2
  std::shared_ptr<RBX::File> v13; // rax
  RBX::Network::ConcurrentRakPeer *v14; // rcx
  PacketPriority v15; // r8d
  RBX::Network::TimeIntervalMeter *v16; // r9
  __int128 v17; // xmm1
  __int128 v18; // xmm2
  std::_Ref_count_base *Rep; // rbx
  std::shared_ptr<RBX::File> v20; // [rsp+50h] [rbp-68h] BYREF
  std::shared_ptr<RBX::File> v21; // [rsp+60h] [rbp-58h] BYREF
  RakNet::SystemAddress v22; // [rsp+70h] [rbp-48h] BYREF
  RakNet::SystemAddress v23; // [rsp+90h] [rbp-28h] BYREF

  Ptr = this->bitStream._Ptr; /*0x14113dc1e*/
  if ( Ptr != nullptr )
  {
    v3 = Ptr->GetNumberOfBytesUsed(this: Ptr); /*0x14113dc3d*/
    if ( v3 > 1 )
    {
      if ( DFLog::ReplicationDataCaching != 0 )
      {
        arg2 = (void *)this->bitStream._Ptr->GetData(this: this->bitStream._Ptr)[2]; /*0x14113dc5f*/
        v5 = this->bitStream._Ptr->GetData(this: this->bitStream._Ptr)[1]; /*0x14113dc6d*/
        v6 = this->bitStream._Ptr->GetData(this: this->bitStream._Ptr); /*0x14113dc74*/
        FLog::FastLog(
          level: DFLog::ReplicationDataCaching,
          message: "[DFLog::ReplicationDataCaching] Replicator::ItemSender::sendPacket() : sending packet ID=%d, Type=%d, SubType=%d",
          arg0: (const void *)*v6,
          arg1: (const void *)v5,
          arg2);
      }
      if ( DFFlag::GameLoadDataStatistics.value && this->nextPacketRequestsReceipt ) /*0x14113dca3*/
      {
        v7._Rep = this->bitStream._Rep; /*0x14113dcb3*/
        rakPeer = this->rakPeer; /*0x14113dcb7*/
        packetPriority = this->packetPriority; /*0x14113dcbb*/
        p_dataSendMeter = &this->replicator->dataSendMeter; /*0x14113dcbf*/
        v11 = *(_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr6.sin6_family; /*0x14113dcc6*/
        v12 = *((_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr4 + 1); /*0x14113dccd*/
        v20 = 0; /*0x14113dcd4*/
        if ( v7._Rep != nullptr ) /*0x14113dcdd*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v7._Rep->_Uses); /*0x14113dcdf*/
          v7._Rep = this->bitStream._Rep; /*0x14113dce3*/
        }
        v7._Ptr = (RBX::File *)this->bitStream._Ptr; /*0x14113dce7*/
        v20 = v7; /*0x14113dcfb*/
        *(_OWORD *)&v22.address.addr6.sin6_family = v11; /*0x14113dd1e*/
        *((_OWORD *)&v22.address.addr4 + 1) = v12; /*0x14113dd23*/
        RBX::Network::ConcurrentRakPeer::Send( /*0x14113dd2b*/
          this: rakPeer,
          bitStream: &v20,
          priority: packetPriority,
          reliability: RELIABLE_ORDERED_WITH_ACK_RECEIPT,
          orderingChannel: 0,
          systemAddress: &v22,
          broadcast: false,
          meter: p_dataSendMeter,
          forceDirectSend: false);
        this->nextPacketRequestsReceipt = false; /*0x14113dd30*/
      }
      else
      {
        v13._Rep = this->bitStream._Rep; /*0x14113dd3f*/
        v14 = this->rakPeer; /*0x14113dd43*/
        v15 = this->packetPriority; /*0x14113dd47*/
        v16 = &this->replicator->dataSendMeter; /*0x14113dd4b*/
        v17 = *(_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr6.sin6_family; /*0x14113dd52*/
        v18 = *((_OWORD *)&this->replicator->remotePlayerRakNetAddress.address.addr4 + 1); /*0x14113dd59*/
        v21 = 0; /*0x14113dd60*/
        if ( v13._Rep != nullptr ) /*0x14113dd69*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v13._Rep->_Uses); /*0x14113dd6b*/
          v13._Rep = this->bitStream._Rep; /*0x14113dd6f*/
        }
        v13._Ptr = (RBX::File *)this->bitStream._Ptr; /*0x14113dd73*/
        v21 = v13; /*0x14113dd87*/
        *(_OWORD *)&v23.address.addr6.sin6_family = v17; /*0x14113ddad*/
        *((_OWORD *)&v23.address.addr4 + 1) = v18; /*0x14113ddb5*/
        RBX::Network::ConcurrentRakPeer::Send( /*0x14113ddbd*/
          this: v14,
          bitStream: &v21,
          priority: v15,
          reliability: RELIABLE_ORDERED,
          orderingChannel: 0,
          systemAddress: &v23,
          broadcast: false,
          meter: v16,
          forceDirectSend: false);
      }
      RBX::RunningAverageTimeInterval<1>::sample(this: &this->replicator->replicatorStats.dataPacketsSent); /*0x14113ddcc*/
      RBX::RunningAverage<int,double>::sample(this: &this->replicator->replicatorStats.dataPacketsSentSize, value: v3); /*0x14113dddd*/
    }
    Rep = this->bitStream._Rep; /*0x14113dde2*/
    this->bitStream._Ptr = nullptr; /*0x14113ddf0*/
    this->bitStream._Rep = nullptr; /*0x14113ddf4*/
    if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14113de0c*/
    {
      Rep->_Destroy(this: Rep); /*0x14113de14*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113de1e*/
        Rep->_Delete_this(this: Rep); /*0x14113de26*/
    }
  }
}

// Address: 0x14113de50 | Name: ?sendSharedQueueItem@ItemSender@Replicator@Network@RBX@@QEAA?AW4SendStatus@1234@AEAV234@AEBVSharedQueueItem@34@@Z
__int64 __fastcall RBX::Network::Replicator::ItemSender::sendSharedQueueItem(
        RBX::Network::Replicator::ItemSender *this,
        RBX::Network::Replicator *replicator,
        RBX::Network::SharedQueueItem *sharedQueueItem)
{
  RBX::Network::NetworkStream *Ptr; // rcx

  Ptr = this->bitStream._Ptr; /*0x14113de6a*/
  if ( Ptr != nullptr && Ptr->GetNumberOfBytesUsed(this: Ptr) >= this->maxStreamSize ) /*0x14113de7f*/
    return 0; /*0x14113de7f*/
  RBX::Network::Replicator::ItemSender::openPacket(this, streamSize: this->maxStreamSize); /*0x14113de87*/
  if ( !sharedQueueItem->write(this: sharedQueueItem, a2: replicator, a3: &this->bitStream) ) /*0x14113de9e*/
    return 0; /*0x14113dea0*/
  this->sentItems = true; /*0x14113dea4*/
  return 1; /*0x14113dead*/
}

// Address: 0x14113ded0 | Name: ?sendStream@ItemSender@Replicator@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::Replicator::ItemSender::sendStream(RBX::Network::Replicator::ItemSender *this)
{
  RBX::Network::NetworkStream *Ptr; // rcx
  RBX::Network::NetworkStream *v3; // rcx
  char inByteArray; // [rsp+30h] [rbp+8h] BYREF

  Ptr = this->bitStream._Ptr; /*0x14113ded9*/
  if ( Ptr != nullptr ) /*0x14113dee0*/
  {
    if ( Ptr->GetNumberOfBytesUsed(this: Ptr) > 1 ) /*0x14113deeb*/
    {
      v3 = this->bitStream._Ptr; /*0x14113deed*/
      inByteArray = 0; /*0x14113defc*/
      RBX::Network::NetworkStream::writeBytes(this: v3, &inByteArray, numberOfBytesToWrite: 1u); /*0x14113df01*/
    }
    RBX::Network::Replicator::ItemSender::sendPacket(this); /*0x14113df0e*/
  }
}

// END ItemSender part 1/1, 7 functions
