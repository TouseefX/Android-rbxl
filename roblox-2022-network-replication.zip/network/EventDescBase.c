// EventDescBase -- 2022 Studio + full PDB
// tier 3, 2 functions


// Address: 0x141014610 | Name: ?connectGeneric@?$EventDescBase@VClient@Network@RBX@@$$A6AXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@H0@ZV?$signal@$$A6AXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@H0@Z@rbx@@P8123@EAAPEAV67@_N@Z@Reflection@RBX@@UEBA?AVconnection@signals@rbx@@PEAVEventSource@23@V?$shared_ptr@VGenericSlotWrapper@Reflection@RBX@@@std@@@Z
rbx::signals::connection *__fastcall RBX::Reflection::EventDescBase<RBX::Network::Client,void (std::string,int,std::string),rbx::signal<void (std::string,int,std::string)>,rbx::signal<void (std::string,int,std::string)> * (RBX::Network::Client::*)(bool)>::connectGeneric(
        RBX::Reflection::EventDescBase<RBX::Network::Client,void __cdecl(std::string,int,std::string),rbx::signal<void __cdecl(std::string,int,std::string)>,rbx::signal<void __cdecl(std::string,int,std::string)> * (__cdecl RBX::Network::Client::*)(bool)> *this,
        rbx::signals::connection *result,
        RBX::Reflection::EventSource *source,
        std::shared_ptr<RBX::File> *wrapper)
{
  rbx::signals::connection *v5; // rsi
  volatile signed __int32 *v6; // rdi
  std::_Ref_count_base *v7; // rdi
  rbx::signals::signal_base *v8; // r12
  std::_Ref_count_base *Rep; // rbp
  RBX::Reflection::GenericSlotWrapper *Ptr; // r13
  unsigned int v11; // eax
  unsigned int parent; // ebx
  rbx::signals::slot_base *v13; // rax
  rbx::signals::slot_base *v14; // r14
  __int64 v15; // rcx
  __int64 v17; // [rsp+0h] [rbp-78h] BYREF
  int v18; // [rsp+20h] [rbp-58h]
  rbx::signals::slot_base *v19; // [rsp+28h] [rbp-50h]
  std::shared_ptr<RBX::File> v20; // [rsp+30h] [rbp-48h] BYREF
  char *v21; // [rsp+88h] [rbp+10h]
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> v22; // [rsp+90h] [rbp+18h] BYREF
  std::shared_ptr<RBX::File> *v23; // [rsp+98h] [rbp+20h]

  v23 = wrapper; /*0x141014615*/
  v21 = (char *)result; /*0x14101461a*/
  __wind /*0xf1c0000000000070*/
  {
    v5 = result; /*0x141014631*/
    v6 = nullptr; /*0x141014634*/
    v18 = 0; /*0x141014636*/
    if ( source != nullptr ) /*0x14101463d*/
    {
      LOBYTE(result) = 1; /*0x14101466f*/
      v8 = (rbx::signals::signal_base *)(*(__int64 (__fastcall **)(char *, rbx::signals::connection *))&this->getter)( /*0x141014678*/
                                          a1: (char *)source + SDWORD2(this->getter),
                                          a2: result);
      Rep = wrapper->_Rep; /*0x14101467b*/
      if ( Rep != nullptr ) /*0x141014682*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141014684*/
        Rep = wrapper->_Rep; /*0x141014688*/
      }
      __wind /*0xf1c000000000007c*/
      {
        __wind /*0xf1c0000000000084*/
        {
          Ptr = (RBX::Reflection::GenericSlotWrapper *)wrapper->_Ptr; /*0x14101468c*/
          v20._Ptr = wrapper->_Ptr; /*0x14101468f*/
          v20._Rep = Rep; /*0x141014694*/
          v11 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x14101469f*/
          __wind /*0xf1c0000000000028*/
          {
            parent = v11; /*0x1410146a4*/
            v22.parent = v11; /*0x1410146a6*/
            v13 = (rbx::signals::slot_base *)operator new(size: 0x38u); /*0x1410146b2*/
            v14 = v13; /*0x1410146b7*/
            v19 = v13; /*0x1410146ba*/
            if ( v13 != nullptr ) /*0x1410146c5*/
            {
              v13->strong._Storage._Value = 0; /*0x1410146c7*/
              v13->weak._Storage._Value = 1; /*0x1410146c9*/
              v13->call = (void (__fastcall *)(rbx::signals::slot_base *))rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (std::string,int,std::string)>>,std::string,int,std::string>::do_call; /*0x1410146d7*/
              v13->dtor = (void (__fastcall *)(rbx::signals::slot_base *))rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (enum RBX::MaterialType)>>,enum RBX::MaterialType>::do_dtor; /*0x1410146e2*/
              v13->next.px = nullptr; /*0x1410146e6*/
              v13->owner = v8; /*0x1410146ea*/
              v13[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)Ptr; /*0x1410146ee*/
              v13[1].call = (void (__fastcall *)(rbx::signals::slot_base *))Rep; /*0x1410146f2*/
              v20 = 0; /*0x1410146f9*/
              rbx::signals::signal_base::insert(this: v8, item: v13); /*0x141014702*/
              v5->weak_slot.p_ = v14; /*0x141014707*/
              _InterlockedIncrement(&v14->weak._Storage._Value); /*0x14101470f*/
              parent = v22.parent; /*0x141014714*/
            }
            else
            {
              rbx::signals::signal_base::insert(this: v8, item: nullptr); /*0x14101471f*/
              v5->weak_slot.p_ = nullptr; /*0x141014724*/
              v6 = (volatile signed __int32 *)Rep; /*0x141014727*/
            }
            v18 = 2; /*0x14101472a*/
          }
          __unwind
          {
            RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: &v22); /*0xf1c0000000000038*/
          }
          __wind /*0xf1c0000000000040*/
          {
            RBX::Memory::setCurrentCategory(category: parent); /*0x141014734*/
          }
          __unwind
          {
            __std_terminate(a1: v15, a2: &v17); /*0x142f39fa8*/
          }
        }
        __unwind
        {
          v18 &= ~2u; /*0x14315b193*/
          rbx::implementation::typed_holder<rbx::signals::connection>::destruct_func(dest: v21); /*0x14315b19e*/
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v20); /*0xf1c0000000000068*/
      }
      if ( v6 != nullptr && _InterlockedExchangeAdd(v6 + 2, 0xFFFFFFFF) == 1 ) /*0x14101474e*/
      {
        (**(void (__fastcall ***)(volatile signed __int32 *))v6)(a1: v6); /*0x141014756*/
        if ( _InterlockedExchangeAdd(v6 + 3, 0xFFFFFFFF) == 1 ) /*0x141014762*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 8LL))(a1: v6); /*0x14101476a*/
      }
      v7 = wrapper->_Rep; /*0x14101476e*/
      if ( v7 == nullptr ) /*0x141014775*/
        return v5; /*0x141014775*/
    }
    else
    {
      result->weak_slot.p_ = nullptr; /*0x14101463f*/
      v7 = wrapper->_Rep; /*0x141014642*/
      if ( v7 == nullptr ) /*0x141014649*/
        return v5; /*0x14101479e*/
    }
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Uses, 0xFFFFFFFF) == 1 ) /*0x141014781*/
    {
      v7->_Destroy(this: v7); /*0x141014789*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v7->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141014793*/
        v7->_Delete_this(this: v7); /*0x14101479b*/
    }
    return v5; /*0x14101479b*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v23); /*0xf1c0000000000020*/
  }
}

// Address: 0x1410147c0 | Name: ?connectGeneric@?$EventDescBase@VClient@Network@RBX@@$$A6AXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$shared_ptr@VInstance@RBX@@@5@@ZV?$signal@$$A6AXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$shared_ptr@VInstance@RBX@@@2@@Z@rbx@@P8123@EAAPEAV78@_N@Z@Reflection@RBX@@UEBA?AVconnection@signals@rbx@@PEAVEventSource@23@V?$shared_ptr@VGenericSlotWrapper@Reflection@RBX@@@std@@@Z
rbx::signals::connection *__fastcall RBX::Reflection::EventDescBase<RBX::Network::Client,void (std::string,std::shared_ptr<RBX::Instance>),rbx::signal<void (std::string,std::shared_ptr<RBX::Instance>)>,rbx::signal<void (std::string,std::shared_ptr<RBX::Instance>)> * (RBX::Network::Client::*)(bool)>::connectGeneric(
        RBX::Reflection::EventDescBase<RBX::Network::Client,void __cdecl(std::string,std::shared_ptr<RBX::Instance>),rbx::signal<void __cdecl(std::string,std::shared_ptr<RBX::Instance>)>,rbx::signal<void __cdecl(std::string,std::shared_ptr<RBX::Instance>)> * (__cdecl RBX::Network::Client::*)(bool)> *this,
        rbx::signals::connection *result,
        RBX::Reflection::EventSource *source,
        std::shared_ptr<RBX::Reflection::GenericSlotWrapper> *wrapper)
{
  rbx::signals::connection *v5; // rsi
  volatile signed __int32 *v6; // rdi
  std::_Ref_count_base *Rep; // rdi
  rbx::signals::signal_base *v8; // r12
  std::_Ref_count_base *v9; // rbp
  RBX::Reflection::GenericSlotWrapper *Ptr; // r13
  unsigned int v11; // ebx
  rbx::signals::slot_base *v12; // rax
  rbx::signals::slot_base *v13; // r14

  v5 = result; /*0x1410147e1*/
  v6 = nullptr; /*0x1410147e4*/
  if ( source == nullptr ) /*0x1410147ed*/
  {
    result->weak_slot.p_ = nullptr; /*0x1410147ef*/
    Rep = wrapper->_Rep; /*0x1410147f2*/
    if ( Rep == nullptr ) /*0x1410147f9*/
      return v5; /*0x1410147f9*/
    goto LABEL_14; /*0x1410147f9*/
  }
  LOBYTE(result) = 1; /*0x14101481f*/
  v8 = (rbx::signals::signal_base *)(*(__int64 (__fastcall **)(char *, rbx::signals::connection *))&this->getter)( /*0x141014828*/
                                      a1: (char *)source + SDWORD2(this->getter),
                                      a2: result);
  v9 = wrapper->_Rep; /*0x14101482b*/
  if ( v9 != nullptr ) /*0x141014832*/
  {
    _InterlockedIncrement((volatile signed __int32 *)&v9->_Uses); /*0x141014834*/
    v9 = wrapper->_Rep; /*0x141014838*/
  }
  Ptr = wrapper->_Ptr; /*0x14101483c*/
  v11 = RBX::Memory::setCurrentCategory(category: RBX::Memory::InstanceSignal); /*0x141014854*/
  v12 = (rbx::signals::slot_base *)operator new(size: 0x38u); /*0x141014862*/
  v13 = v12; /*0x141014867*/
  if ( v12 != nullptr ) /*0x141014875*/
  {
    v12->strong._Storage._Value = 0; /*0x141014877*/
    v12->weak._Storage._Value = 1; /*0x141014879*/
    v12->call = (void (__fastcall *)(rbx::signals::slot_base *))rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (std::string,std::shared_ptr<RBX::Instance>)>>,std::string,std::shared_ptr<RBX::Instance>>::do_call; /*0x141014887*/
    v12->dtor = (void (__fastcall *)(rbx::signals::slot_base *))rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (enum RBX::MaterialType)>>,enum RBX::MaterialType>::do_dtor; /*0x141014892*/
    v12->next.px = nullptr; /*0x141014896*/
    v12->owner = v8; /*0x14101489a*/
    v12[1].rbx::intrusive_ptr_target<rbx::signals::slot_base> = (rbx::intrusive_ptr_target<rbx::signals::slot_base>)Ptr; /*0x14101489e*/
    v12[1].call = (void (__fastcall *)(rbx::signals::slot_base *))v9; /*0x1410148a2*/
    rbx::signals::signal_base::insert(this: v8, item: v12); /*0x1410148b2*/
    v5->weak_slot.p_ = v13; /*0x1410148b7*/
    _InterlockedIncrement(&v13->weak._Storage._Value); /*0x1410148bf*/
  }
  else
  {
    rbx::signals::signal_base::insert(this: v8, item: nullptr); /*0x1410148cf*/
    v5->weak_slot.p_ = nullptr; /*0x1410148d4*/
    v6 = (volatile signed __int32 *)v9; /*0x1410148d7*/
  }
  RBX::Memory::setCurrentCategory(category: v11); /*0x1410148e4*/
  if ( v6 != nullptr && _InterlockedExchangeAdd(v6 + 2, 0xFFFFFFFF) == 1 ) /*0x1410148fe*/
  {
    (**(void (__fastcall ***)(volatile signed __int32 *))v6)(a1: v6); /*0x141014906*/
    if ( _InterlockedExchangeAdd(v6 + 3, 0xFFFFFFFF) == 1 ) /*0x141014912*/
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 8LL))(a1: v6); /*0x14101491a*/
  }
  Rep = wrapper->_Rep; /*0x14101491e*/
  if ( Rep != nullptr ) /*0x141014925*/
  {
LABEL_14:
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141014931*/
    {
      Rep->_Destroy(this: Rep); /*0x141014939*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141014943*/
        Rep->_Delete_this(this: Rep); /*0x14101494b*/
    }
  }
  return v5; /*0x141014951*/
}

// END EventDescBase part 1/1, 2 functions
