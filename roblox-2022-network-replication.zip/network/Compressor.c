// Compressor -- 2022 Studio + full PDB
// tier 3, 10 functions


// Address: 0x14118da30 | Name: ?readRotation@Compressor@Network@RBX@@SAXAEAVNetworkStream@23@AEAVMatrix3@3@@Z
void __fastcall RBX::Network::Compressor::readRotation(RBX::Network::NetworkStream *bitStream, RBX::Matrix3 *rotation)
{
  float v4; // xmm4_4
  float v5; // xmm3_4
  float v6; // xmm2_4
  unsigned __int64 v7; // rbx
  float v8; // xmm4_4
  float v9; // xmm0_4
  float v10; // xmm7_4
  float v11; // xmm8_4
  float v12; // xmm9_4
  float v13; // xmm10_4
  float v14; // xmm2_4
  float v15; // xmm0_4
  float qv[4]; // [rsp+20h] [rbp-71h] BYREF
  float v17; // [rsp+30h] [rbp-61h]
  float v18; // [rsp+34h] [rbp-5Dh]
  RBX::Quaternion q; // [rsp+40h] [rbp-51h] BYREF
  float v20; // [rsp+50h] [rbp-41h]
  float v21; // [rsp+54h] [rbp-3Dh]
  RBX::network_stream_exception pExceptionObject; // [rsp+58h] [rbp-39h] BYREF
  unsigned __int16 qxe; // [rsp+108h] [rbp+77h] BYREF
  unsigned int qyze; // [rsp+110h] [rbp+7Fh] BYREF

  if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &qxe, numberOfBytesToRead: 2u) ) /*0x14118da75*/
  {
    std::string::string(this: (std::string *)&qv[2], _Ptr: "readFast past end for uint16_t"); /*0x14118dc8d*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000004*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: (const std::string *)&qv[2]); /*0x14118dc9b*/
    throw &pExceptionObject; /*0x14118dcab*/
  }
  qxe = __ROL2__(qxe, 8); /*0x14118da7b*/
  if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &qyze, numberOfBytesToRead: 4u) ) /*0x14118da94*/
  {
    std::string::string(this: (std::string *)&qv[2], _Ptr: "readFast past end for uint32_t"); /*0x14118dc5e*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000000c*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, m: (const std::string *)&qv[2]); /*0x14118dc6c*/
    throw &pExceptionObject; /*0x14118dc7c*/
  }
  qyze = __ROL4__((qyze << 8) ^ ((qyze << 8) ^ (qyze >> 8)) & 0xFF00FF, 16); /*0x14118dab9*/
  v4 = (float)((float)(qxe << 17 >> 17) / 16383.0) * RBX::Network::kRotationMaxComponent; /*0x14118dae1*/
  v5 = (float)((float)((int)(4 * qyze) >> 17) / 16383.0) * RBX::Network::kRotationMaxComponent; /*0x14118dafa*/
  v6 = (float)((float)((int)(qyze << 17) >> 17) / 16383.0) * RBX::Network::kRotationMaxComponent; /*0x14118db11*/
  v7 = (unsigned __int64)qyze >> 30; /*0x14118db15*/
  qv[RBX::Network::kRotationAxisTable[v7][0] + 2] = v4; /*0x14118db28*/
  qv[RBX::Network::kRotationAxisTable[v7][1] + 2] = v5; /*0x14118db33*/
  qv[RBX::Network::kRotationAxisTable[v7][2] + 2] = v6; /*0x14118db3e*/
  v8 = fmaxf(1.0 - (float)((float)((float)(v5 * v5) + (float)(v4 * v4)) + (float)(v6 * v6)), 0.0); /*0x14118db6a*/
  if ( v8 < 0.0 ) /*0x14118db74*/
    v9 = sqrtf_0(X: v8); /*0x14118db82*/
  else
    v9 = fsqrt(v8); /*0x14118db79*/
  qv[v7 + 2] = v9; /*0x14118db87*/
  v10 = qv[3]; /*0x14118db8d*/
  v11 = qv[2]; /*0x14118db99*/
  v12 = v17; /*0x14118dbac*/
  v13 = v18; /*0x14118dbbf*/
  v14 = (float)((float)((float)(v10 * v10) + (float)(v11 * v11)) + (float)(v12 * v12)) + (float)(v13 * v13); /*0x14118dbce*/
  if ( v14 < 0.0 ) /*0x14118dbd8*/
    v15 = sqrtf_0(X: v14); /*0x14118dbe6*/
  else
    v15 = fsqrt(v14); /*0x14118dbdd*/
  q.z = v11 * (float)(1.0 / v15); /*0x14118dbf4*/
  q.w = v10 * (float)(1.0 / v15); /*0x14118dbfe*/
  v20 = v12 * (float)(1.0 / v15); /*0x14118dc08*/
  v21 = v13 * (float)(1.0 / v15); /*0x14118dc13*/
  RBX::Quaternion::toRotationMatrix(this: (RBX::Quaternion *)&q.z, rot: rotation); /*0x14118dc20*/
}

// Address: 0x14118dcc0 | Name: ?readRotationCompact@Compressor@Network@RBX@@SAXAEAVNetworkStream@23@AEAVMatrix3@3@@Z
void __fastcall RBX::Network::Compressor::readRotationCompact(
        RBX::Network::NetworkStream *bitStream,
        RBX::Matrix3 *rotation)
{
  float v3; // xmm4_4
  float v4; // xmm3_4
  float v5; // xmm2_4
  unsigned __int64 v6; // rdi
  float v7; // xmm4_4
  float v8; // xmm0_4
  RBX::Quaternion q; // [rsp+20h] [rbp-78h] BYREF
  std::string m; // [rsp+30h] [rbp-68h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+50h] [rbp-48h] BYREF
  unsigned int qxyze; // [rsp+B0h] [rbp+18h] BYREF

  if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &qxyze, numberOfBytesToRead: 4u) ) /*0x14118dce5*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint32_t"); /*0x14118de15*/
    __wind /*0xf1c0000000000004*/
    {
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118de25*/
      throw &pExceptionObject; /*0x14118de36*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c0000000000014*/
    }
  }
  qxyze = __ROL4__((qxyze << 8) ^ ((qxyze << 8) ^ (qxyze >> 8)) & 0xFF00FF, 16); /*0x14118dd0e*/
  v3 = (float)((float)((int)(4 * qxyze) >> 22) / 511.0) * RBX::Network::kRotationMaxComponent; /*0x14118dd3a*/
  v4 = (float)((float)((int)(qxyze << 12) >> 22) / 511.0) * RBX::Network::kRotationMaxComponent; /*0x14118dd51*/
  v5 = (float)((float)((int)(qxyze << 22) >> 22) / 511.0) * RBX::Network::kRotationMaxComponent; /*0x14118dd68*/
  v6 = (unsigned __int64)qxyze >> 30; /*0x14118dd6c*/
  *(&q.x + (int)RBX::Network::kRotationAxisTable[v6][0]) = v3; /*0x14118dd7f*/
  *(&q.x + (int)RBX::Network::kRotationAxisTable[v6][1]) = v4; /*0x14118dd8a*/
  *(&q.x + (int)RBX::Network::kRotationAxisTable[v6][2]) = v5; /*0x14118dd95*/
  v7 = fmaxf(1.0 - (float)((float)((float)(v4 * v4) + (float)(v3 * v3)) + (float)(v5 * v5)), 0.0); /*0x14118ddbe*/
  if ( v7 < 0.0 ) /*0x14118ddc8*/
    v8 = sqrtf_0(X: v7); /*0x14118ddd6*/
  else
    v8 = fsqrt(v7); /*0x14118ddcd*/
  *(&q.x + v6) = v8; /*0x14118dddb*/
  RBX::Quaternion::toRotationMatrix(this: &q, rot: rotation); /*0x14118ddf3*/
}

// Address: 0x14118de40 | Name: ?readTranslation@Compressor@Network@RBX@@SAXAEAVNetworkStream@23@AEAVVector3@3@@Z
void __fastcall RBX::Network::Compressor::readTranslation(
        RBX::Network::NetworkStream *bitStream,
        RBX::Vector3 *translation)
{
  unsigned int v4; // r15d
  int v5; // ebx
  int v6; // r14d
  int v7; // esi
  unsigned int v8; // edi
  unsigned int v9; // ebx
  int v10; // esi
  double v11; // xmm0_8
  float v12; // xmm2_4
  unsigned int v13; // ebx
  unsigned int v14; // r14d
  float v15; // xmm3_4
  __m128i v16; // xmm1
  __m128i v17; // xmm0
  unsigned __int16 yme[2]; // [rsp+20h] [rbp-60h] BYREF
  unsigned int yzme; // [rsp+24h] [rbp-5Ch] BYREF
  std::string m; // [rsp+28h] [rbp-58h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+48h] [rbp-38h] BYREF
  unsigned __int8 ee; // [rsp+C0h] [rbp+40h] BYREF
  unsigned int xyme; // [rsp+C8h] [rbp+48h] BYREF

  if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &ee, numberOfBytesToRead: 1u) ) /*0x14118de73*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint8_t"); /*0x14118e168*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000002c*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e176*/
    throw &pExceptionObject; /*0x14118e186*/
  }
  v4 = ee >> 3; /*0x14118de80*/
  v5 = (ee & 4) != 0; /*0x14118de89*/
  v6 = (ee & 2) != 0; /*0x14118de92*/
  v7 = ee & 1; /*0x14118de96*/
  if ( v4 <= 4 ) /*0x14118dea0*/
  {
    if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &xyme, numberOfBytesToRead: 4u) ) /*0x14118deb7*/
    {
      std::string::string(this: &m, _Ptr: "readFast past end for uint32_t"); /*0x14118e197*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000024*/
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e1a5*/
      throw &pExceptionObject; /*0x14118e1b5*/
    }
    xyme = __ROL4__((xyme << 8) ^ ((xyme << 8) ^ (xyme >> 8)) & 0xFF00FF, 16); /*0x14118dee0*/
    v8 = (int)(((v5 << 10) | (xyme >> 20)) << 21) >> 21; /*0x14118def2*/
    v9 = (v6 << 31 >> 21) | (xyme >> 10) & 0x3FF; /*0x14118df09*/
    v10 = xyme & 0x3FF | (v7 << 31 >> 21); /*0x14118df19*/
    v11 = ldexp(X: 1.0, Y: v4); /*0x14118df27*/
    v12 = 1023.0; /*0x14118df2d*/
LABEL_13:
    v16 = _mm_cvtsi32_si128(v8); /*0x14118e0ca*/
    v15 = v11; /*0x14118e0d1*/
    v17 = _mm_cvtsi32_si128(v9); /*0x14118e0d5*/
    goto LABEL_14; /*0x14118e0d5*/
  }
  if ( v4 > 0xA ) /*0x14118df3e*/
  {
    if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &xyme, numberOfBytesToRead: 4u) ) /*0x14118e014*/
    {
      std::string::string(this: &m, _Ptr: "readFast past end for uint32_t"); /*0x14118e253*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000004*/
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e261*/
      throw &pExceptionObject; /*0x14118e271*/
    }
    xyme = __ROL4__((xyme << 8) ^ ((xyme << 8) ^ (xyme >> 8)) & 0xFF00FF, 16); /*0x14118e037*/
    if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &yzme, numberOfBytesToRead: 4u) ) /*0x14118e04e*/
    {
      std::string::string(this: &m, _Ptr: "readFast past end for uint32_t"); /*0x14118e139*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000034*/
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e147*/
      throw &pExceptionObject; /*0x14118e157*/
    }
    yzme = __ROL4__((yzme << 8) ^ ((yzme << 8) ^ (yzme >> 8)) & 0xFF00FF, 16); /*0x14118e071*/
    v8 = (int)(((v5 << 21) | (xyme >> 11)) << 10) >> 10; /*0x14118e084*/
    v9 = ((xyme & 0x7FF) << 10) | ((int)(((v6 << 21) | (yzme >> 21)) << 10) >> 10); /*0x14118e0a1*/
    v10 = yzme & 0x1FFFFF | (v7 << 31 >> 10); /*0x14118e0af*/
    v11 = ldexp(X: 1.0, Y: v4); /*0x14118e0bc*/
    v12 = 2097151.0; /*0x14118e0c2*/
    goto LABEL_13; /*0x14118e0c2*/
  }
  if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &xyme, numberOfBytesToRead: 2u) ) /*0x14118df55*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint16_t"); /*0x14118e1c6*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000001c*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e1d4*/
    throw &pExceptionObject; /*0x14118e1e4*/
  }
  LOWORD(xyme) = __ROL2__(xyme, 8); /*0x14118df5b*/
  if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: yme, numberOfBytesToRead: 2u) ) /*0x14118df74*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint16_t"); /*0x14118e1f5*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000014*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e203*/
    throw &pExceptionObject; /*0x14118e213*/
  }
  yme[0] = __ROL2__(yme[0], 8); /*0x14118df7a*/
  if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &yzme, numberOfBytesToRead: 2u) ) /*0x14118df93*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint16_t"); /*0x14118e224*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000000c*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e232*/
    throw &pExceptionObject; /*0x14118e242*/
  }
  LOWORD(yzme) = __ROL2__(yzme, 8); /*0x14118dfa4*/
  v13 = ((unsigned __int16)xyme | (v5 << 16)) << 15 >> 15; /*0x14118dfb4*/
  v14 = (yme[0] | (v6 << 16)) << 15 >> 15; /*0x14118dfc6*/
  v10 = ((unsigned __int16)yzme | (v7 << 16)) << 15 >> 15; /*0x14118dfd2*/
  v15 = ldexp(X: 1.0, Y: v4); /*0x14118dfe9*/
  v16 = _mm_cvtsi32_si128(v13); /*0x14118dfed*/
  v12 = 65535.0; /*0x14118dff1*/
  v17 = _mm_cvtsi32_si128(v14); /*0x14118dff9*/
LABEL_14:
  translation->x = (float)(_mm_cvtepi32_ps(v16).m128_f32[0] / v12) * v15; /*0x14118e0d9*/
  translation->y = (float)(_mm_cvtepi32_ps(v17).m128_f32[0] / v12) * v15; /*0x14118e104*/
  translation->z = (float)((float)v10 / v12) * v15; /*0x14118e10b*/
}

// Address: 0x14118e280 | Name: ?readVelocity@Compressor@Network@RBX@@SAXAEAVNetworkStream@23@AEAVVector3@3@@Z
void __fastcall RBX::Network::Compressor::readVelocity(RBX::Network::NetworkStream *bitStream, RBX::Vector3 *velocity)
{
  int v4; // ebx
  int v5; // edi
  int v6; // esi
  float v7; // xmm3_4
  std::string m; // [rsp+20h] [rbp-78h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+40h] [rbp-58h] BYREF
  unsigned __int8 zfee; // [rsp+B0h] [rbp+18h] BYREF
  unsigned int xyzfe; // [rsp+B8h] [rbp+20h] BYREF

  if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &zfee, numberOfBytesToRead: 1u) ) /*0x14118e2ab*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint8_t"); /*0x14118e3f2*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000004*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e402*/
    throw &pExceptionObject; /*0x14118e413*/
  }
  if ( zfee != 0 ) /*0x14118e2b9*/
  {
    if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &xyzfe, numberOfBytesToRead: 4u) ) /*0x14118e2e1*/
    {
      std::string::string(this: &m, _Ptr: "readFast past end for uint32_t"); /*0x14118e3bf*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c000000000000c*/
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e3cf*/
      throw &pExceptionObject; /*0x14118e3e0*/
    }
    xyzfe = __ROL4__((xyzfe << 8) ^ ((xyzfe << 8) ^ (xyzfe >> 8)) & 0xFF00FF, 16); /*0x14118e30e*/
    v4 = (int)xyzfe >> 20; /*0x14118e328*/
    v5 = (int)(xyzfe << 12) >> 20; /*0x14118e331*/
    v6 = (int)((xyzfe << 24) | ((zfee & 0xF) << 20)) >> 20; /*0x14118e341*/
    v7 = ldexp(X: 1.0, Y: (zfee >> 4) - 1); /*0x14118e355*/
    velocity->x = (float)((float)v4 / 2047.0) * v7; /*0x14118e370*/
    velocity->y = (float)((float)v5 / 2047.0) * v7; /*0x14118e384*/
    velocity->z = (float)((float)v6 / 2047.0) * v7; /*0x14118e399*/
  }
  else
  {
    *(_QWORD *)&velocity->y = 0; /*0x14118e2bd*/
    velocity->x = 0.0; /*0x14118e2c1*/
  }
}

// Address: 0x14118e420 | Name: ?readVelocityCompact@Compressor@Network@RBX@@SAXAEAVNetworkStream@23@AEAVVector3@3@@Z
void __fastcall RBX::Network::Compressor::readVelocityCompact(
        RBX::Network::NetworkStream *bitStream,
        RBX::Vector3 *velocity)
{
  int v4; // edi
  int v5; // ebx
  int v6; // esi
  float v7; // xmm3_4
  unsigned __int8 yfeAndZfe[8]; // [rsp+20h] [rbp-78h] BYREF
  std::string m; // [rsp+28h] [rbp-70h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+48h] [rbp-50h] BYREF
  unsigned __int8 veAndXfe; // [rsp+B0h] [rbp+18h] BYREF
  unsigned __int8 xfeAndYfe; // [rsp+B8h] [rbp+20h] BYREF

  if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &veAndXfe, numberOfBytesToRead: 1u) ) /*0x14118e44b*/
  {
    std::string::string(this: &m, _Ptr: "readFast past end for uint8_t"); /*0x14118e58d*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000000c*/
    RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e59d*/
    throw &pExceptionObject; /*0x14118e5ae*/
  }
  if ( veAndXfe != 0 ) /*0x14118e459*/
  {
    if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: &xfeAndYfe, numberOfBytesToRead: 1u) ) /*0x14118e481*/
    {
      std::string::string(this: &m, _Ptr: "readFast past end for uint8_t"); /*0x14118e5c0*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000004*/
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e5d0*/
      throw &pExceptionObject; /*0x14118e5e1*/
    }
    if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: yfeAndZfe, numberOfBytesToRead: 1u) ) /*0x14118e49c*/
    {
      std::string::string(this: &m, _Ptr: "readFast past end for uint8_t"); /*0x14118e55a*/
      __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000014*/
      RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14118e56a*/
      throw &pExceptionObject; /*0x14118e57b*/
    }
    v4 = (veAndXfe << 30 >> 26) | (xfeAndYfe >> 4); /*0x14118e4c5*/
    v5 = (xfeAndYfe << 28 >> 26) | (yfeAndZfe[0] >> 6); /*0x14118e4d7*/
    v6 = yfeAndZfe[0] << 26 >> 26; /*0x14118e4dc*/
    v7 = ldexp(X: 1.0, Y: veAndXfe << 25 >> 27); /*0x14118e4f0*/
    velocity->x = (float)((float)v4 / 31.0) * v7; /*0x14118e50b*/
    velocity->y = (float)((float)v5 / 31.0) * v7; /*0x14118e51f*/
    velocity->z = (float)((float)v6 / 31.0) * v7; /*0x14118e534*/
  }
  else
  {
    *(_QWORD *)&velocity->y = 0; /*0x14118e45d*/
    velocity->x = 0.0; /*0x14118e461*/
  }
}

// Address: 0x14118e5f0 | Name: ?writeRotation@Compressor@Network@RBX@@SAXAEAVNetworkStream@23@AEBVMatrix3@3@@Z
// local variable allocation has failed, the output may be wrong!
void __fastcall RBX::Network::Compressor::writeRotation(
        RBX::Network::NetworkStream *bitStream,
        const RBX::Matrix3 *rotation)
{
  float w; // xmm6_4
  float z; // xmm7_4
  float v5; // xmm8_4
  float v6; // xmm9_4
  float v7; // xmm2_4
  float v8; // xmm0_4
  float v9; // xmm3_4
  __int64 v10; // rdi
  float v11; // xmm9_4
  float v12; // xmm7_4
  float v13; // xmm0_4
  float v14; // xmm2_4
  int v15; // ecx
  float v16; // xmm0_4
  __int16 v17; // cx
  float v18; // xmm2_4
  float v19; // xmm6_4
  int v20; // ebx
  RBX::Quaternion q; // [rsp+20h] [rbp-31h] BYREF
  _BYTE v[24]; // [rsp+30h] [rbp-21h] OVERLAPPED
  int inByteArray; // [rsp+C8h] [rbp+77h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+D0h] [rbp+7Fh] BYREF

  RBX::Quat_DEPRECATED::Quat_DEPRECATED(this: (RBX::Quat_DEPRECATED *)&q.z, rot: rotation); /*0x14118e623*/
  w = q.w; /*0x14118e628*/
  z = q.z; /*0x14118e62d*/
  v5 = *(float *)v; /*0x14118e635*/
  v6 = *(float *)&v[4]; /*0x14118e63e*/
  v7 = (float)((float)((float)(w * w) + (float)(z * z)) + (float)(v5 * v5)) + (float)(v6 * v6); /*0x14118e666*/
  if ( v7 < 0.0 ) /*0x14118e670*/
    v8 = sqrtf_0(X: v7); /*0x14118e67e*/
  else
    v8 = fsqrt(v7); /*0x14118e675*/
  *(float *)&v[8] = z * (float)(1.0 / v8); /*0x14118e6af*/
  *(float *)&v[12] = w * (float)(1.0 / v8); /*0x14118e6b9*/
  *(float *)&v[20] = (float)(1.0 / v8) * v6; /*0x14118e6c3*/
  q.z = *(float *)&v[8]; /*0x14118e6c8*/
  *(float *)&v[16] = (float)(1.0 / v8) * v5; /*0x14118e6d0*/
  q.w = *(float *)&v[12]; /*0x14118e6d5*/
  *(float *)&v[4] = *(float *)&v[20]; /*0x14118e6e0*/
  v9 = fabs(*(float *)&v[20]); /*0x14118e6e5*/
  *(float *)v = *(float *)&v[16]; /*0x14118e6e8*/
  v10 = fabs(*(float *)&v[12]) > fabs(*(float *)&v[8]); /*0x14118e6f0*/
  if ( fabs(*(float *)&v[16]) > fabs(*(float *)&v[4 * v10 + 8]) ) /*0x14118e704*/
    v10 = 2; /*0x14118e704*/
  if ( v9 > fabs(*(float *)&v[4 * v10 + 8]) ) /*0x14118e717*/
    v10 = 3; /*0x14118e717*/
  if ( *(float *)&v[4 * v10 + 8] < 0.0 ) /*0x14118e71f*/
    *(__m128 *)&v[8] = _mm_xor_ps(*(__m128 *)&v[8], (__m128)_xmm); /*0x14118e72c*/
  v11 = RBX::Network::kRotationMaxComponent; /*0x14118e730*/
  v12 = 0.5; /*0x14118e75a*/
  v13 = *(float *)&v[4 * RBX::Network::kRotationAxisTable[v10][0] + 8]; /*0x14118e762*/
  if ( v13 < 0.0 ) /*0x14118e76b*/
    v14 = -0.5; /*0x14118e772*/
  else
    v14 = 0.5; /*0x14118e76d*/
  v15 = (int)(float)((float)((float)(v13 / RBX::Network::kRotationMaxComponent) * 16383.0) + v14); /*0x14118e78c*/
  v16 = *(float *)&v[4 * RBX::Network::kRotationAxisTable[v10][1] + 8]; /*0x14118e790*/
  v17 = v15 & 0x7FFF; /*0x14118e796*/
  if ( v16 < 0.0 ) /*0x14118e79f*/
    v18 = -0.5; /*0x14118e7a6*/
  else
    v18 = 0.5; /*0x14118e7a1*/
  v19 = *(float *)&v[4 * RBX::Network::kRotationAxisTable[v10][2] + 8]; /*0x14118e7a9*/
  v20 = (int)(float)((float)((float)(v16 / RBX::Network::kRotationMaxComponent) * 16383.0) + v18) & 0x7FFF; /*0x14118e7c2*/
  if ( v19 < 0.0 ) /*0x14118e7cb*/
    v12 = -0.5; /*0x14118e7cd*/
  LOWORD(inByteArray) = v17; /*0x14118e7d0*/
  RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 2u); /*0x14118e7df*/
  RBX::Network::NetworkStream::writeBytes(this: bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 2u); /*0x14118e7ee*/
  inByteArray = ((_DWORD)v10 << 30) | (v20 << 15) | (int)(float)((float)((float)(v19 / v11) * 16383.0) + v12) & 0x7FFF; /*0x14118e822*/
  RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x14118e825*/
  RBX::Network::NetworkStream::writeBytes(this: bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x14118e837*/
}

// Address: 0x14118e870 | Name: ?writeRotationCompact@Compressor@Network@RBX@@SAXAEAVNetworkStream@23@AEBVMatrix3@3@@Z
void __fastcall RBX::Network::Compressor::writeRotationCompact(
        RBX::Network::NetworkStream *bitStream,
        const RBX::Matrix3 *rotation)
{
  float y; // xmm6_4
  float x; // xmm7_4
  float v5; // xmm2_4
  float v6; // xmm0_4
  __int64 v7; // r8
  float v8; // xmm3_4
  float v9; // xmm1_4
  float v10; // xmm0_4
  float v11; // xmm3_4
  int v12; // ecx
  float v13; // xmm0_4
  int v14; // ecx
  float v15; // xmm3_4
  int v16; // edx
  float v17; // xmm0_4
  int v18; // edx
  RBX::Quaternion q; // [rsp+20h] [rbp-50h] BYREF
  RBX::Quaternion v; // [rsp+30h] [rbp-40h]
  int inByteArray; // [rsp+90h] [rbp+20h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+98h] [rbp+28h] BYREF

  RBX::Quat_DEPRECATED::Quat_DEPRECATED(this: (RBX::Quat_DEPRECATED *)&q, rot: rotation); /*0x14118e88e*/
  y = q.y; /*0x14118e893*/
  x = q.x; /*0x14118e898*/
  v5 = (float)((float)((float)(y * y) + (float)(x * x)) + (float)(q.z * q.z)) + (float)(q.w * q.w); /*0x14118e8c5*/
  if ( v5 < 0.0 ) /*0x14118e8cf*/
    v6 = sqrtf_0(X: v5); /*0x14118e8dd*/
  else
    v6 = fsqrt(v5); /*0x14118e8d4*/
  v.y = y * (float)(1.0 / v6); /*0x14118e913*/
  v.x = x * (float)(1.0 / v6); /*0x14118e918*/
  v.z = (float)(1.0 / v6) * q.z; /*0x14118e91d*/
  v.w = (float)(1.0 / v6) * q.w; /*0x14118e922*/
  q = v; /*0x14118e927*/
  v7 = fabs(v.y) > fabs(v.x); /*0x14118e94a*/
  v8 = fabs(v.w); /*0x14118e94e*/
  if ( fabs(v.z) > fabs(*(&v.x + v7)) ) /*0x14118e963*/
    v7 = 2; /*0x14118e963*/
  if ( v8 > fabs(*(&v.x + v7)) ) /*0x14118e979*/
    v7 = 3; /*0x14118e979*/
  if ( *(&v.x + v7) < 0.0 ) /*0x14118e983*/
    v = (RBX::Quaternion)_mm_xor_ps((__m128)v, (__m128)_xmm); /*0x14118e990*/
  v9 = 0.5; /*0x14118e9a0*/
  v10 = *(&v.x + (int)RBX::Network::kRotationAxisTable[v7][0]); /*0x14118e9bd*/
  if ( v10 < 0.0 ) /*0x14118e9c6*/
    v11 = -0.5; /*0x14118e9cd*/
  else
    v11 = 0.5; /*0x14118e9c8*/
  v12 = (int)(float)((float)((float)(v10 / RBX::Network::kRotationMaxComponent) * 511.0) + v11); /*0x14118e9ec*/
  v13 = *(&v.x + (int)RBX::Network::kRotationAxisTable[v7][1]); /*0x14118e9f0*/
  v14 = v12 & 0x3FF; /*0x14118e9f6*/
  if ( v13 < 0.0 ) /*0x14118e9ff*/
    v15 = -0.5; /*0x14118ea06*/
  else
    v15 = 0.5; /*0x14118ea01*/
  v16 = (int)(float)((float)((float)(v13 / RBX::Network::kRotationMaxComponent) * 511.0) + v15); /*0x14118ea15*/
  v17 = *(&v.x + (int)RBX::Network::kRotationAxisTable[v7][2]); /*0x14118ea19*/
  v18 = v16 & 0x3FF; /*0x14118ea20*/
  if ( v17 < 0.0 ) /*0x14118ea29*/
    v9 = -0.5; /*0x14118ea2b*/
  inByteArray = ((_DWORD)v7 << 30) /*0x14118ea62*/
              | ((v18 | (v14 << 10)) << 10)
              | (int)(float)((float)((float)(v17 / RBX::Network::kRotationMaxComponent) * 511.0) + v9) & 0x3FF;
  RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x14118ea65*/
  RBX::Network::NetworkStream::writeBytes(this: bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x14118ea77*/
}

// Address: 0x14118eaa0 | Name: ?writeTranslation@Compressor@Network@RBX@@SAXAEAVNetworkStream@23@AEBVVector3@3@@Z
void __fastcall RBX::Network::Compressor::writeTranslation(
        RBX::Network::NetworkStream *bitStream,
        const RBX::Vector3 *translation)
{
  float *v2; // rax
  float z; // xmm3_4
  float v5; // xmm1_4
  float v6; // xmm3_4
  int v8; // edi
  double v9; // xmm0_8
  float x; // xmm1_4
  float v11; // xmm2_4
  float v12; // xmm3_4
  float v13; // xmm7_4
  int *p_inByteArray; // rax
  float v15; // xmm0_4
  int v16; // edi
  float y; // xmm0_4
  unsigned int v18; // edi
  float v19; // xmm7_4
  int *p_inOutByteArray; // rax
  float v21; // xmm0_4
  int v22; // esi
  float v23; // xmm0_4
  unsigned int v24; // esi
  int *v25; // rax
  float v26; // xmm2_4
  unsigned int v27; // ebx
  float v28; // xmm3_4
  float v29; // xmm7_4
  int *v30; // rax
  float v31; // xmm0_4
  int v32; // esi
  float v33; // xmm0_4
  int v34; // esi
  float v35; // xmm7_4
  int *v36; // rax
  float v37; // xmm0_4
  int v38; // edi
  float v39; // xmm0_4
  int v40; // edi
  int *v41; // rax
  float v42; // xmm2_4
  int v43; // ebx
  unsigned int v44; // r8d
  float v45; // xmm4_4
  float v46; // xmm7_4
  int *v47; // rax
  float v48; // xmm0_4
  int v49; // edi
  float v50; // xmm0_4
  unsigned int v51; // edi
  float v52; // xmm7_4
  int *v53; // rax
  float v54; // xmm0_4
  int v55; // esi
  float v56; // xmm0_4
  unsigned int v57; // edx
  int *v58; // rax
  float v59; // xmm2_4
  unsigned int v60; // esi
  unsigned int v61; // ebx
  float v62; // [rsp+20h] [rbp-48h] BYREF
  _DWORD v63[3]; // [rsp+24h] [rbp-44h] BYREF
  int inByteArray; // [rsp+98h] [rbp+30h] BYREF
  int inOutByteArray; // [rsp+A0h] [rbp+38h] BYREF
  int ve; // [rsp+A8h] [rbp+40h] BYREF

  v2 = (float *)v63; /*0x14118eab5*/
  z = translation->z; /*0x14118eac9*/
  v5 = fabs(translation->y); /*0x14118ead1*/
  v62 = fabs(translation->x); /*0x14118ead4*/
  v6 = fabs(z); /*0x14118ead9*/
  *(float *)v63 = v5; /*0x14118eadc*/
  *(float *)&v63[1] = v6; /*0x14118eae7*/
  if ( v5 <= v62 ) /*0x14118eaec*/
    v2 = &v62; /*0x14118eaec*/
  v8 = 0; /*0x14118eaf0*/
  ve = 0; /*0x14118eaf2*/
  if ( v6 <= *v2 ) /*0x14118eafc*/
    v6 = *v2; /*0x14118eafe*/
  frexp(X: v6, Y: &ve); /*0x14118eb1d*/
  if ( ve > 0 ) /*0x14118eb30*/
    v8 = ve; /*0x14118eb30*/
  if ( v8 > 31 ) /*0x14118eb3a*/
    v8 = 31; /*0x14118eb3a*/
  ve = v8; /*0x14118eb3f*/
  v9 = ldexp(X: 1.0, Y: v8); /*0x14118eb42*/
  x = translation->x; /*0x14118eb4f*/
  v11 = v9; /*0x14118eb56*/
  if ( ve <= 4 ) /*0x14118eb5e*/
  {
    v12 = 0.5; /*0x14118eb6f*/
    if ( x < 0.0 ) /*0x14118eb77*/
      v13 = -0.5; /*0x14118eb7e*/
    else
      v13 = 0.5; /*0x14118eb79*/
    p_inByteArray = &inByteArray; /*0x14118eb89*/
    inOutByteArray = -1082130432; /*0x14118eb95*/
    *(float *)&inByteArray = x / v11; /*0x14118eb9f*/
    if ( (float)(x / v11) <= -1.0 ) /*0x14118ebac*/
      p_inByteArray = &inOutByteArray; /*0x14118ebac*/
    v15 = *(float *)p_inByteArray; /*0x14118ebb0*/
    if ( *(float *)p_inByteArray >= 1.0 ) /*0x14118ebb7*/
      v15 = 1.0; /*0x14118ebb9*/
    v16 = (int)(float)((float)(v15 * 1023.0) + v13); /*0x14118ebce*/
    y = translation->y; /*0x14118ebd2*/
    v18 = v16 & 0x7FF; /*0x14118ebd7*/
    if ( y < 0.0 ) /*0x14118ebe0*/
      v19 = -0.5; /*0x14118ebe7*/
    else
      v19 = 0.5; /*0x14118ebe2*/
    p_inOutByteArray = &inByteArray; /*0x14118ebee*/
    inOutByteArray = -1082130432; /*0x14118ebf2*/
    *(float *)&inByteArray = y / v11; /*0x14118ec00*/
    if ( (float)(y / v11) <= -1.0 ) /*0x14118ec05*/
      p_inOutByteArray = &inOutByteArray; /*0x14118ec05*/
    v21 = *(float *)p_inOutByteArray; /*0x14118ec09*/
    if ( *(float *)p_inOutByteArray >= 1.0 ) /*0x14118ec10*/
      v21 = 1.0; /*0x14118ec12*/
    v22 = (int)(float)((float)(v21 * 1023.0) + v19); /*0x14118ec1e*/
    v23 = translation->z; /*0x14118ec22*/
    v24 = v22 & 0x7FF; /*0x14118ec27*/
    if ( v23 < 0.0 ) /*0x14118ec30*/
      v12 = -0.5; /*0x14118ec32*/
    v25 = &inByteArray; /*0x14118ec39*/
    inOutByteArray = -1082130432; /*0x14118ec3d*/
    *(float *)&inByteArray = v23 / v11; /*0x14118ec4b*/
    if ( (float)(v23 / v11) <= -1.0 ) /*0x14118ec50*/
      v25 = &inOutByteArray; /*0x14118ec50*/
    v26 = *(float *)v25; /*0x14118ec54*/
    if ( *(float *)v25 >= 1.0 ) /*0x14118ec5b*/
      v26 = 1.0; /*0x14118ec5d*/
    v27 = (int)(float)((float)(v26 * 1023.0) + v12) & 0x7FF; /*0x14118ec8d*/
    LOBYTE(inByteArray) = (v27 >> 10) | (2 * ((v24 >> 10) | (2 * ((2 * ve) | (v18 >> 10))))); /*0x14118ec9a*/
    RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14118eca0*/
    inByteArray = v27 & 0x3FF | ((v24 & 0x3FF | ((v18 & 0x3FF) << 10)) << 10); /*0x14118ecc1*/
LABEL_74:
    RBX::Network::NetworkStream::ReverseBytes( /*0x14118f019*/
      (unsigned __int8 *)&inByteArray,
      (unsigned __int8 *)&inOutByteArray,
      length: 4u);
    v44 = 4; /*0x14118f02c*/
    goto LABEL_75; /*0x14118f02c*/
  }
  if ( ve > 10 ) /*0x14118eccd*/
  {
    v45 = 0.5; /*0x14118ee97*/
    if ( x < 0.0 ) /*0x14118ee9f*/
      v46 = -0.5; /*0x14118eea6*/
    else
      v46 = 0.5; /*0x14118eea1*/
    v47 = &inByteArray; /*0x14118eeb1*/
    inOutByteArray = -1082130432; /*0x14118eebd*/
    *(float *)&inByteArray = x / v11; /*0x14118eec7*/
    if ( (float)(x / v11) <= -1.0 ) /*0x14118eed4*/
      v47 = &inOutByteArray; /*0x14118eed4*/
    v48 = *(float *)v47; /*0x14118eed8*/
    if ( *(float *)v47 >= 1.0 ) /*0x14118eedf*/
      v48 = 1.0; /*0x14118eee1*/
    v49 = (int)(float)((float)(v48 * 2097151.0) + v46); /*0x14118eef6*/
    v50 = translation->y; /*0x14118eefa*/
    v51 = v49 & 0x3FFFFF; /*0x14118eeff*/
    if ( v50 < 0.0 ) /*0x14118ef08*/
      v52 = -0.5; /*0x14118ef0f*/
    else
      v52 = 0.5; /*0x14118ef0a*/
    v53 = &inByteArray; /*0x14118ef16*/
    inOutByteArray = -1082130432; /*0x14118ef1a*/
    *(float *)&inByteArray = v50 / v11; /*0x14118ef28*/
    if ( (float)(v50 / v11) <= -1.0 ) /*0x14118ef2d*/
      v53 = &inOutByteArray; /*0x14118ef2d*/
    v54 = *(float *)v53; /*0x14118ef31*/
    if ( *(float *)v53 >= 1.0 ) /*0x14118ef38*/
      v54 = 1.0; /*0x14118ef3a*/
    v55 = (int)(float)((float)(v54 * 2097151.0) + v52); /*0x14118ef46*/
    v56 = translation->z; /*0x14118ef4a*/
    v57 = v55 & 0x3FFFFF; /*0x14118ef51*/
    if ( v56 < 0.0 ) /*0x14118ef5a*/
      v45 = -0.5; /*0x14118ef5c*/
    v58 = &inByteArray; /*0x14118ef63*/
    inOutByteArray = -1082130432; /*0x14118ef67*/
    *(float *)&inByteArray = v56 / v11; /*0x14118ef75*/
    if ( (float)(v56 / v11) <= -1.0 ) /*0x14118ef7a*/
      v58 = &inOutByteArray; /*0x14118ef7a*/
    v59 = *(float *)v58; /*0x14118ef7e*/
    if ( *(float *)v58 >= 1.0 ) /*0x14118ef85*/
      v59 = 1.0; /*0x14118ef87*/
    v60 = v55 & 0x1FFFFF; /*0x14118ef9a*/
    v61 = (int)(float)((float)(v59 * 2097151.0) + v45) & 0x3FFFFF; /*0x14118efbb*/
    LOBYTE(inByteArray) = (v61 >> 21) | (2 * ((v57 >> 21) | (2 * ((2 * ve) | (v51 >> 21))))); /*0x14118efc8*/
    RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14118efce*/
    inByteArray = (v60 >> 10) | (v51 << 11); /*0x14118efeb*/
    RBX::Network::NetworkStream::ReverseBytes( /*0x14118efee*/
      (unsigned __int8 *)&inByteArray,
      (unsigned __int8 *)&inOutByteArray,
      length: 4u);
    RBX::Network::NetworkStream::writeBytes(this: bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x14118f000*/
    inByteArray = v61 & 0x1FFFFF | ((v60 & 0x3FF) << 21); /*0x14118f016*/
    goto LABEL_74; /*0x14118f016*/
  }
  v28 = 0.5; /*0x14118ecde*/
  if ( x < 0.0 ) /*0x14118ece6*/
    v29 = -0.5; /*0x14118eced*/
  else
    v29 = 0.5; /*0x14118ece8*/
  v30 = &inByteArray; /*0x14118ecf8*/
  inOutByteArray = -1082130432; /*0x14118ed04*/
  *(float *)&inByteArray = x / v11; /*0x14118ed0e*/
  if ( (float)(x / v11) <= -1.0 ) /*0x14118ed1b*/
    v30 = &inOutByteArray; /*0x14118ed1b*/
  v31 = *(float *)v30; /*0x14118ed1f*/
  if ( *(float *)v30 >= 1.0 ) /*0x14118ed26*/
    v31 = 1.0; /*0x14118ed28*/
  v32 = (int)(float)((float)(v31 * 65535.0) + v29); /*0x14118ed3d*/
  v33 = translation->y; /*0x14118ed41*/
  v34 = v32 & 0x1FFFF; /*0x14118ed46*/
  if ( v33 < 0.0 ) /*0x14118ed4f*/
    v35 = -0.5; /*0x14118ed56*/
  else
    v35 = 0.5; /*0x14118ed51*/
  v36 = &inByteArray; /*0x14118ed5d*/
  inOutByteArray = -1082130432; /*0x14118ed61*/
  *(float *)&inByteArray = v33 / v11; /*0x14118ed6f*/
  if ( (float)(v33 / v11) <= -1.0 ) /*0x14118ed74*/
    v36 = &inOutByteArray; /*0x14118ed74*/
  v37 = *(float *)v36; /*0x14118ed78*/
  if ( *(float *)v36 >= 1.0 ) /*0x14118ed7f*/
    v37 = 1.0; /*0x14118ed81*/
  v38 = (int)(float)((float)(v37 * 65535.0) + v35); /*0x14118ed8d*/
  v39 = translation->z; /*0x14118ed91*/
  v40 = v38 & 0x1FFFF; /*0x14118ed96*/
  if ( v39 < 0.0 ) /*0x14118ed9f*/
    v28 = -0.5; /*0x14118eda1*/
  v41 = &inByteArray; /*0x14118eda8*/
  inOutByteArray = -1082130432; /*0x14118edac*/
  *(float *)&inByteArray = v39 / v11; /*0x14118edba*/
  if ( (float)(v39 / v11) <= -1.0 ) /*0x14118edbf*/
    v41 = &inOutByteArray; /*0x14118edbf*/
  v42 = *(float *)v41; /*0x14118edc3*/
  if ( *(float *)v41 >= 1.0 ) /*0x14118edca*/
    v42 = 1.0; /*0x14118edcc*/
  v43 = (int)(float)((float)(v42 * 65535.0) + v28) & 0x1FFFF; /*0x14118edfc*/
  LOBYTE(inByteArray) = BYTE2(v43) | (2 * (BYTE2(v40) | (2 * ((2 * ve) | BYTE2(v34))))); /*0x14118ee09*/
  RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14118ee0f*/
  LOWORD(inByteArray) = v34; /*0x14118ee1a*/
  RBX::Network::NetworkStream::ReverseBytes( /*0x14118ee26*/
    (unsigned __int8 *)&inByteArray,
    (unsigned __int8 *)&inOutByteArray,
    length: 2u);
  RBX::Network::NetworkStream::writeBytes(this: bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 2u); /*0x14118ee38*/
  LOWORD(inByteArray) = v40; /*0x14118ee43*/
  RBX::Network::NetworkStream::ReverseBytes( /*0x14118ee4f*/
    (unsigned __int8 *)&inByteArray,
    (unsigned __int8 *)&inOutByteArray,
    length: 2u);
  RBX::Network::NetworkStream::writeBytes(this: bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 2u); /*0x14118ee61*/
  LOWORD(inByteArray) = v43; /*0x14118ee6c*/
  RBX::Network::NetworkStream::ReverseBytes( /*0x14118ee78*/
    (unsigned __int8 *)&inByteArray,
    (unsigned __int8 *)&inOutByteArray,
    length: 2u);
  v44 = 2; /*0x14118ee7d*/
LABEL_75:
  RBX::Network::NetworkStream::writeBytes(this: bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: v44); /*0x14118f036*/
}

// Address: 0x14118f060 | Name: ?writeVelocity@Compressor@Network@RBX@@SAXAEAVNetworkStream@23@AEBVVector3@3@@Z
void __fastcall RBX::Network::Compressor::writeVelocity(
        RBX::Network::NetworkStream *bitStream,
        const RBX::Vector3 *velocity)
{
  float *v2; // rax
  float z; // xmm3_4
  float v5; // xmm1_4
  float v6; // xmm3_4
  int v8; // ebx
  double v9; // xmm0_8
  float v10; // xmm4_4
  float v11; // xmm7_4
  float v12; // xmm2_4
  float v13; // xmm1_4
  float *p_inByteArray; // rax
  float v15; // xmm0_4
  float v16; // xmm0_4
  float y; // xmm2_4
  int v18; // r14d
  float v19; // xmm5_4
  float *p_inOutByteArray; // rax
  float v21; // xmm0_4
  int v22; // esi
  float v23; // xmm0_4
  int v24; // esi
  float *v25; // rax
  float v26; // xmm2_4
  float v27; // xmm2_4
  unsigned int v28; // ebx
  float v29; // [rsp+20h] [rbp-40h] BYREF
  _DWORD v30[3]; // [rsp+24h] [rbp-3Ch] BYREF
  float inByteArray; // [rsp+88h] [rbp+28h] BYREF
  int ve; // [rsp+90h] [rbp+30h] BYREF
  int inOutByteArray; // [rsp+98h] [rbp+38h] BYREF

  v2 = (float *)v30; /*0x14118f074*/
  z = velocity->z; /*0x14118f088*/
  v5 = fabs(velocity->y); /*0x14118f090*/
  v29 = fabs(velocity->x); /*0x14118f093*/
  v6 = fabs(z); /*0x14118f098*/
  *(float *)v30 = v5; /*0x14118f09b*/
  *(float *)&v30[1] = v6; /*0x14118f0a6*/
  if ( v5 <= v29 ) /*0x14118f0ab*/
    v2 = &v29; /*0x14118f0ab*/
  if ( v6 <= *v2 ) /*0x14118f0b6*/
    v6 = *v2; /*0x14118f0b8*/
  if ( v6 >= 0.001 ) /*0x14118f0c6*/
  {
    v8 = 0; /*0x14118f0f8*/
    ve = 0; /*0x14118f102*/
    frexp(X: v6, Y: &ve); /*0x14118f110*/
    if ( ve > 0 ) /*0x14118f123*/
      v8 = ve; /*0x14118f123*/
    if ( v8 > 14 ) /*0x14118f12d*/
      v8 = 14; /*0x14118f12d*/
    ve = v8; /*0x14118f132*/
    v9 = ldexp(X: 1.0, Y: v8); /*0x14118f135*/
    v10 = 0.5; /*0x14118f152*/
    v11 = v9; /*0x14118f15a*/
    if ( velocity->x < 0.0 ) /*0x14118f15e*/
      v12 = -0.5; /*0x14118f165*/
    else
      v12 = 0.5; /*0x14118f160*/
    v13 = velocity->x / v11; /*0x14118f168*/
    p_inByteArray = &inByteArray; /*0x14118f16c*/
    inOutByteArray = -1082130432; /*0x14118f170*/
    inByteArray = v13; /*0x14118f182*/
    if ( v13 <= -1.0 ) /*0x14118f18f*/
      p_inByteArray = (float *)&inOutByteArray; /*0x14118f18f*/
    v15 = *p_inByteArray; /*0x14118f193*/
    if ( *p_inByteArray >= 1.0 ) /*0x14118f19a*/
      v15 = 1.0; /*0x14118f19c*/
    v16 = (float)(v15 * 2047.0) + v12; /*0x14118f1a7*/
    y = velocity->y; /*0x14118f1ab*/
    v18 = (int)v16; /*0x14118f1b4*/
    if ( y < 0.0 ) /*0x14118f1b9*/
      v19 = -0.5; /*0x14118f1c0*/
    else
      v19 = 0.5; /*0x14118f1bb*/
    p_inOutByteArray = &inByteArray; /*0x14118f1c7*/
    inOutByteArray = -1082130432; /*0x14118f1cb*/
    inByteArray = y / v11; /*0x14118f1dd*/
    if ( (float)(y / v11) <= -1.0 ) /*0x14118f1e2*/
      p_inOutByteArray = (float *)&inOutByteArray; /*0x14118f1e2*/
    v21 = *p_inOutByteArray; /*0x14118f1e6*/
    if ( *p_inOutByteArray >= 1.0 ) /*0x14118f1ed*/
      v21 = 1.0; /*0x14118f1ef*/
    v22 = (int)(float)((float)(v21 * 2047.0) + v19); /*0x14118f1fe*/
    v23 = velocity->z; /*0x14118f202*/
    v24 = v22 & 0xFFF; /*0x14118f207*/
    if ( v23 < 0.0 ) /*0x14118f217*/
      v10 = -0.5; /*0x14118f219*/
    v25 = &inByteArray; /*0x14118f220*/
    inOutByteArray = -1082130432; /*0x14118f224*/
    inByteArray = v23 / v11; /*0x14118f23b*/
    if ( (float)(v23 / v11) <= -1.0 ) /*0x14118f240*/
      v25 = (float *)&inOutByteArray; /*0x14118f240*/
    v26 = *v25; /*0x14118f244*/
    if ( *v25 >= 1.0 ) /*0x14118f24b*/
      v26 = 1.0; /*0x14118f24d*/
    v27 = (float)(v26 * 2047.0) + v10; /*0x14118f26b*/
    v28 = (int)v27 & 0xFFF; /*0x14118f273*/
    LOBYTE(inByteArray) = (int)v27 & 0xF | (16 * (ve + 1)); /*0x14118f280*/
    RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14118f286*/
    LODWORD(inByteArray) = (v28 >> 4) | ((v24 | (v18 << 12)) << 8); /*0x14118f2aa*/
    RBX::Network::NetworkStream::ReverseBytes( /*0x14118f2ae*/
      (unsigned __int8 *)&inByteArray,
      (unsigned __int8 *)&inOutByteArray,
      length: 4u);
    RBX::Network::NetworkStream::writeBytes(this: bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x14118f2c0*/
  }
  else
  {
    LOBYTE(inByteArray) = 0; /*0x14118f0ce*/
    RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14118f0d9*/
  }
}

// Address: 0x14118f2e0 | Name: ?writeVelocityCompact@Compressor@Network@RBX@@SAXAEAVNetworkStream@23@AEBVVector3@3@@Z
void __fastcall RBX::Network::Compressor::writeVelocityCompact(
        RBX::Network::NetworkStream *bitStream,
        const RBX::Vector3 *velocity)
{
  float *v2; // rax
  float z; // xmm3_4
  float v5; // xmm1_4
  float v6; // xmm3_4
  int v8; // edx
  double v9; // xmm0_8
  float x; // xmm1_4
  float v11; // xmm7_4
  float v12; // xmm5_4
  float v13; // xmm3_4
  float *p_inByteArray; // rax
  float v15; // xmm0_4
  int v16; // r14d
  float y; // xmm0_4
  unsigned int v18; // r14d
  float v19; // xmm1_4
  float *v20; // rax
  float v21; // xmm0_4
  float v22; // xmm9_4
  unsigned int v23; // ebx
  float v24; // xmm9_4
  float *v25; // rax
  float v26; // xmm0_4
  int v27; // [rsp+20h] [rbp-50h] BYREF
  float v28; // [rsp+24h] [rbp-4Ch] BYREF
  _DWORD v29[2]; // [rsp+28h] [rbp-48h] BYREF
  float inByteArray; // [rsp+98h] [rbp+28h] BYREF
  int ve; // [rsp+A0h] [rbp+30h] BYREF
  float v32; // [rsp+A8h] [rbp+38h] BYREF

  v2 = (float *)v29; /*0x14118f2f3*/
  z = velocity->z; /*0x14118f307*/
  v5 = fabs(velocity->y); /*0x14118f30f*/
  v28 = fabs(velocity->x); /*0x14118f312*/
  v6 = fabs(z); /*0x14118f317*/
  *(float *)v29 = v5; /*0x14118f31a*/
  *(float *)&v29[1] = v6; /*0x14118f325*/
  if ( v5 <= v28 ) /*0x14118f32a*/
    v2 = &v28; /*0x14118f32a*/
  if ( v6 <= *v2 ) /*0x14118f335*/
    v6 = *v2; /*0x14118f337*/
  if ( v6 >= 0.001 ) /*0x14118f345*/
  {
    ve = 0; /*0x14118f37b*/
    frexp(X: v6, Y: &ve); /*0x14118f38d*/
    v8 = -16; /*0x14118f39b*/
    if ( ve > -16 ) /*0x14118f3a8*/
      v8 = ve; /*0x14118f3a8*/
    if ( v8 > 15 ) /*0x14118f3ae*/
      v8 = 15; /*0x14118f3ae*/
    ve = v8; /*0x14118f3b1*/
    v9 = ldexp(X: 1.0, Y: v8); /*0x14118f3b4*/
    x = velocity->x; /*0x14118f3ba*/
    v11 = 0.5; /*0x14118f3cf*/
    v12 = v9; /*0x14118f3d7*/
    if ( velocity->x < 0.0 ) /*0x14118f3db*/
      v13 = -0.5; /*0x14118f3e2*/
    else
      v13 = 0.5; /*0x14118f3dd*/
    p_inByteArray = &inByteArray; /*0x14118f3ed*/
    v32 = -1.0; /*0x14118f3f9*/
    inByteArray = x / v12; /*0x14118f407*/
    if ( (float)(x / v12) <= -1.0 ) /*0x14118f40c*/
      p_inByteArray = &v32; /*0x14118f40c*/
    v15 = *p_inByteArray; /*0x14118f410*/
    if ( *p_inByteArray >= 1.0 ) /*0x14118f417*/
      v15 = 1.0; /*0x14118f419*/
    v16 = (int)(float)((float)(v15 * 31.0) + v13); /*0x14118f428*/
    y = velocity->y; /*0x14118f42d*/
    v18 = v16 & 0x3F; /*0x14118f432*/
    if ( y < 0.0 ) /*0x14118f439*/
      v19 = -0.5; /*0x14118f440*/
    else
      v19 = 0.5; /*0x14118f43b*/
    v20 = &inByteArray; /*0x14118f447*/
    v32 = -1.0; /*0x14118f44b*/
    inByteArray = y / v12; /*0x14118f45d*/
    if ( (float)(y / v12) <= -1.0 ) /*0x14118f462*/
      v20 = &v32; /*0x14118f462*/
    v21 = *v20; /*0x14118f466*/
    if ( *v20 >= 1.0 ) /*0x14118f46d*/
      v21 = 1.0; /*0x14118f46f*/
    v22 = velocity->z; /*0x14118f47a*/
    v23 = (int)(float)((float)(v21 * 31.0) + v19) & 0x3F; /*0x14118f488*/
    if ( v22 < 0.0 ) /*0x14118f48f*/
      v11 = -0.5; /*0x14118f491*/
    v24 = v22 / v12; /*0x14118f49c*/
    v27 = -1082130432; /*0x14118f4a4*/
    LOBYTE(inByteArray) = (4 * (ve | 0xE0)) | (v18 >> 4); /*0x14118f4bb*/
    v32 = v24; /*0x14118f4c1*/
    RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14118f4c7*/
    LOBYTE(inByteArray) = (16 * v18) | (v23 >> 2); /*0x14118f4e5*/
    RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14118f4e8*/
    v25 = &v32; /*0x14118f4f5*/
    if ( v24 <= -1.0 ) /*0x14118f508*/
      v25 = (float *)&v27; /*0x14118f508*/
    v26 = *v25; /*0x14118f50c*/
    if ( *v25 >= 1.0 ) /*0x14118f513*/
      v26 = 1.0; /*0x14118f515*/
    LOBYTE(inByteArray) = ((_BYTE)v23 << 6) | (int)(float)((float)(v26 * 31.0) + v11) & 0x3F; /*0x14118f53c*/
    RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14118f53f*/
  }
  else
  {
    LOBYTE(inByteArray) = 0; /*0x14118f34d*/
    RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14118f358*/
  }
}

// END Compressor part 1/1, 10 functions
