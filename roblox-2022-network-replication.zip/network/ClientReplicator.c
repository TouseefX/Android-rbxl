// ClientReplicator -- 2022 Studio + full PDB
// tier 3, 101 functions


// Address: 0x1406df310 | Name: ??$Class_getDescriptor@VClientReplicator@Network@RBX@@@@YAAEAVClassDescriptor@Reflection@RBX@@XZ
// attributes: thunk
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptor<RBX::Network::ClientReplicator>()
{
  return RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>();
}

// Address: 0x1406dfd40 | Name: ??$fastDynamicCast@VClientReplicator@Network@RBX@@@DescribedBase@Reflection@RBX@@SAPEAVClientReplicator@Network@2@PEAV012@@Z
RBX::Network::ClientReplicator *__fastcall RBX::Reflection::DescribedBase::fastDynamicCast<RBX::Network::ClientReplicator>(
        RBX::Reflection::DescribedBase *instance)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v3; // rax

  if ( instance != nullptr /*0x1406dfd7d*/
    && (descriptor = instance->descriptor,
        v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(),
        descriptor->index - (unsigned int)v3->index <= v3->descendantCount) )
  {
    return (RBX::Network::ClientReplicator *)instance; /*0x1406dfd7f*/
  }
  else
  {
    return nullptr; /*0x1406dfd88*/
  }
}

// Address: 0x1406dff20 | Name: ??$findFirstChildOfType@VClientReplicator@Network@RBX@@@Instance@RBX@@QEAAPEAVClientReplicator@Network@1@XZ
RBX::Network::ClientReplicator *__fastcall RBX::Instance::findFirstChildOfType<RBX::Network::ClientReplicator>(
        RBX::Instance *this)
{
  std::vector<std::shared_ptr<RBX::Instance>> *Ptr; // rbx
  std::shared_ptr<RBX::Instance> *Mylast; // rdi
  std::shared_ptr<RBX::Instance> *Myfirst; // rbx
  RBX::Instance *v4; // rsi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbp
  RBX::Reflection::ClassDescriptor *v6; // rax

  Ptr = this->children.object._Ptr; /*0x1406dff34*/
  if ( Ptr == nullptr ) /*0x1406dff3b*/
    return nullptr; /*0x1406dff3b*/
  Mylast = Ptr->_Mypair._Myval2._Mylast; /*0x1406dff3d*/
  Myfirst = Ptr->_Mypair._Myval2._Myfirst; /*0x1406dff41*/
  if ( Myfirst == Mylast ) /*0x1406dff47*/
    return nullptr; /*0x1406dff85*/
  while ( 1 ) /*0x1406dff50*/
  {
    v4 = Myfirst->_Ptr; /*0x1406dff50*/
    if ( Myfirst->_Ptr != nullptr ) /*0x1406dff56*/
    {
      descriptor = v4->descriptor; /*0x1406dff58*/
      v6 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(); /*0x1406dff5c*/
      if ( descriptor->index - (unsigned int)v6->index <= v6->descendantCount ) /*0x1406dff7a*/
        break; /*0x1406dff7a*/
    }
    if ( ++Myfirst == Mylast ) /*0x1406dff83*/
      return nullptr; /*0x1406dff83*/
  }
  return (RBX::Network::ClientReplicator *)v4; /*0x1406dff87*/
}

// Address: 0x14100a300 | Name: ??$Class_getDescriptorPtr@VClientReplicator@Network@RBX@@@Reflection@RBX@@YAAEAVClassDescriptor@01@XZ
RBX::ClassRegistrar<RBX::Network::ClientReplicator,0> *__fastcall RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>()
{
  RBX::ClassRegistrar<RBX::Network::ClientReplicator,0> *result; // rax
  RBX::Reflection::ClassDescriptor *v1; // rax
  RBX::Reflection::ClassDescriptor::Attributes v3; // [rsp+60h] [rbp-28h] BYREF
  RBX::Reflection::ClassDescriptor::Attributes v4; // 0:^40.32

  result = (RBX::ClassRegistrar<RBX::Network::ClientReplicator,0> *)ret_91; /*0x14100a30d*/
  if ( ret_91 == nullptr ) /*0x14100a317*/
  {
    if ( _TSS0_517 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x14100a343*/
    {
      Init_thread_header(pOnce: &_TSS0_517); /*0x14100a367*/
      if ( _TSS0_517 == -1 ) /*0x14100a373*/
      {
        v4.isDeprecated = false; /*0x14100a375*/
        v4.preferred = nullptr; /*0x14100a37c*/
        v4.threadSafety = Unset; /*0x14100a381*/
        v4.flags = INTERNAL_LOCAL; /*0x14100a385*/
        __wind /*0xf1c000000000001c*/
        {
          v1 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Replicator>(); /*0x14100a38d*/
          v3 = v4; /*0x14100a397*/
          RBX::Reflection::ClassDescriptor::ClassDescriptor( /*0x14100a3c9*/
            this: &reg_83.desc,
            base: v1,
            name: "ClientReplicator",
            isService: false,
            attributes: &v3,
            security: (RBX::Security::Permissions)0,
            memoryCategory: nullptr);
          atexit(function: RBX::Reflection::Class_getDescriptorPtr_RBX::Network::ClientReplicator__::_2_::_dynamic_atexit_destructor_for__reg__); /*0x14100a3d5*/
        }
        __unwind
        {
          Init_thread_abort(pOnce: &_TSS0_517); /*0x1431e5077*/
        }
        Init_thread_footer(pOnce: &_TSS0_517); /*0x14100a3e2*/
      }
    }
    ret_91 = (RBX::Reflection::ClassDescriptor *)&reg_83; /*0x14100a345*/
    return &reg_83; /*0x14100a34c*/
  }
  return result; /*0x14100a34f*/
}

// Address: 0x14100aad0 | Name: ??$Class_getNamePtr@VClientReplicator@Network@RBX@@@Reflection@RBX@@YAAEBVName@1@XZ
const RBX::Name *__fastcall RBX::Reflection::Class_getNamePtr<RBX::Network::ClientReplicator>()
{
  const RBX::Name *result; // rax

  result = name_47; /*0x14100aad4*/
  if ( name_47 == nullptr ) /*0x14100aade*/
  {
    result = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>()->desc.name; /*0x14100aae5*/
    name_47 = result; /*0x14100aae9*/
  }
  return result; /*0x14100aaf0*/
}

// Address: 0x14100e6b0 | Name: ??$create@VClientReplicator@Network@RBX@@AEAUReplicatorPeerInfo@Replicator@23@AEAPEAVNetworkSettings@3@PEAVMegaReplicator@23@@?$Creatable@VInstance@RBX@@@RBX@@SA?AV?$shared_ptr@VClientReplicator@Network@RBX@@@std@@AEAUReplicatorPeerInfo@Replicator@Network@1@AEAPEAVNetworkSettings@1@$$QEAPEAVMegaReplicator@61@@Z
RBX::Network::ClientReplicator *__fastcall RBX::Creatable<RBX::Instance>::create<RBX::Network::ClientReplicator,RBX::Network::Replicator::ReplicatorPeerInfo &,RBX::NetworkSettings * &,RBX::Network::MegaReplicator *>(
        RBX::Network::ClientReplicator *result,
        RBX::Network::Replicator::ReplicatorPeerInfo *<args_0>,
        RBX::NetworkSettings **<args_1>,
        RBX::Network::MegaReplicator **<args_2>)
{
  const unsigned int *memoryCategory; // rcx
  unsigned int v9; // ecx
  unsigned int v10; // eax
  RBX::Network::ClientReplicator *v11; // rax
  RBX::File *v12; // rsi
  RBX::Network::MegaReplicator *v13; // r9
  RBX::NetworkSettings *v14; // r8
  std::_Ref_count_base *Rep; // rcx
  RBX::Network::ClientReplicator *v16; // rax
  RBX::File *v17; // rdi
  std::_Ref_count_base *v18; // rax
  std::_Ref_count_base *Ptr; // rbx
  std::_Ref_count_base *v20; // rax
  std::_Ref_count_base *v21; // rax
  volatile signed __int32 *v22; // rcx
  signed __int32 v23; // eax
  signed __int32 v24; // eax
  unsigned int parent; // ecx
  __int64 v26; // rcx
  RBX::Network::ClientReplicator *v27; // rax
  __int64 v28; // [rsp+0h] [rbp-A8h] BYREF
  RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::Network::ClientReplicator,void> scope; // [rsp+20h] [rbp-88h] BYREF
  std::_Ref_count_base *v30; // [rsp+28h] [rbp-80h]
  std::_Temporary_owner_del<RBX::File *,RBX::Creatable<RBX::Instance>::Deleter<RBX::File> > v31; // [rsp+30h] [rbp-78h] BYREF
  RBX::Network::Replicator::ReplicatorPeerInfo v32; // [rsp+48h] [rbp-60h] BYREF
  RBX::Network::ClientReplicator *v33; // [rsp+B0h] [rbp+8h] BYREF

  v33 = result; /*0x14100e6ba*/
  memoryCategory = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>()->desc.memoryCategory; /*0x14100e6dc*/
  if ( memoryCategory != nullptr ) /*0x14100e6e6*/
    v9 = *memoryCategory; /*0x14100e6e8*/
  else
    v9 = RBX::Memory::InstanceObject; /*0x14100e6ec*/
  v10 = RBX::Memory::setCurrentCategory(category: v9); /*0x14100e6f2*/
  scope.parent = v10; /*0x14100e6f7*/
  __wind /*0xf1c0000000000070*/
  {
    v11 = (RBX::Network::ClientReplicator *)operator new(size: 0x3A10u); /*0x14100e700*/
    v33 = v11; /*0x14100e708*/
    __wind /*0xf1c0000000000064*/
    {
      v12 = nullptr; /*0x14100e710*/
      if ( v11 != nullptr ) /*0x14100e715*/
      {
        v13 = *<args_2>; /*0x14100e717*/
        v14 = *<args_1>; /*0x14100e71a*/
        v32.remotePeerId.peerId = <args_0>->remotePeerId.peerId; /*0x14100e71f*/
        v32.remotePlayerAddress = <args_0>->remotePlayerAddress; /*0x14100e727*/
        v32.rakPeer = 0; /*0x14100e738*/
        Rep = <args_0>->rakPeer._Rep; /*0x14100e73e*/
        if ( Rep != nullptr ) /*0x14100e745*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x14100e747*/
          Rep = <args_0>->rakPeer._Rep; /*0x14100e74b*/
        }
        v32.rakPeer._Ptr = <args_0>->rakPeer._Ptr; /*0x14100e753*/
        v32.rakPeer._Rep = Rep; /*0x14100e758*/
        v32.capability = <args_0>->capability; /*0x14100e761*/
        v16 = RBX::Network::ClientReplicator::ClientReplicator( /*0x14100e771*/
                this: v11,
                peerInfo: &v32,
                networkSettings: v14,
                megaReplicator: v13);
        v17 = (RBX::File *)v16; /*0x14100e776*/
      }
      else
      {
        v17 = nullptr; /*0x14100e77b*/
      }
    }
    __unwind
    {
      operator delete(ptr: v33); /*0x1431e5435*/
    }
    result->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>::RBX::Network::IdSerializer::RBX::Instance::RBX::Reflection::DescribedBase::RBX::Reflection::EventSource::__vftable = nullptr; /*0x14100e77e*/
    result->_Wptr._Ptr = nullptr; /*0x14100e781*/
    v31._Ptr = v17; /*0x14100e794*/
    v31._Dt = (RBX::Creatable<RBX::Instance>::Deleter<RBX::File> *)&v33; /*0x14100e7a1*/
    v31._Call_deleter = true; /*0x14100e7a6*/
    __wind /*0xf1c0000000000028*/
    {
      v18 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x14100e7b0*/
      Ptr = v18; /*0x14100e7b5*/
      v30 = v18; /*0x14100e7b8*/
      if ( v18 != nullptr ) /*0x14100e7c0*/
      {
        *v18 = 0; /*0x14100e7c5*/
        v18->_Uses = 1; /*0x14100e7c8*/
        v18->_Weaks = 1; /*0x14100e7cf*/
        v18->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count_resource<RBX::Network::ClientReplicator *,RBX::Creatable<RBX::Instance>::Deleter<RBX::Network::ClientReplicator>>::`vftable'; /*0x14100e7dd*/
        v18[1].__vftable = (std::_Ref_count_base_vtbl *)v17; /*0x14100e7e0*/
      }
      else
      {
        Ptr = nullptr; /*0x14100e7e6*/
      }
      result->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>::RBX::Network::IdSerializer::RBX::Instance::RBX::Reflection::DescribedBase::RBX::Reflection::EventSource::__vftable = (RBX::Network::ClientReplicator_vtbl *)v17; /*0x14100e7e9*/
      result->_Wptr._Ptr = (RBX::Reflection::DescribedBase *)Ptr; /*0x14100e7ec*/
      if ( v17 != nullptr ) /*0x14100e7f3*/
      {
        v20 = v17->_Wptr._Rep; /*0x14100e7f9*/
        if ( v20 == nullptr || v20->_Uses == 0 ) /*0x14100e806*/
        {
          if ( Ptr != nullptr ) /*0x14100e80b*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&Ptr->_Uses); /*0x14100e80d*/
            Ptr = (std::_Ref_count_base *)result->_Wptr._Ptr; /*0x14100e811*/
          }
          v21 = nullptr; /*0x14100e815*/
          if ( Ptr != nullptr ) /*0x14100e81b*/
          {
            v12 = v17; /*0x14100e81d*/
            v21 = Ptr; /*0x14100e820*/
            _InterlockedIncrement((volatile signed __int32 *)&Ptr->_Weaks); /*0x14100e823*/
          }
          v17->_Wptr._Ptr = v12; /*0x14100e827*/
          v22 = (volatile signed __int32 *)v17->_Wptr._Rep; /*0x14100e82b*/
          v17->_Wptr._Rep = v21; /*0x14100e82f*/
          if ( v22 != nullptr ) /*0x14100e83b*/
          {
            v23 = _InterlockedExchangeAdd(v22 + 3, 0xFFFFFFFF); /*0x14100e83f*/
            if ( v23 == 1 ) /*0x14100e847*/
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 8LL))(a1: v22); /*0x14100e84c*/
          }
          if ( Ptr != nullptr ) /*0x14100e852*/
          {
            v24 = _InterlockedExchangeAdd((volatile signed __int32 *)&Ptr->_Uses, 0xFFFFFFFF); /*0x14100e856*/
            if ( v24 == 1 ) /*0x14100e85e*/
            {
              Ptr->_Destroy(this: Ptr); /*0x14100e866*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Ptr->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14100e870*/
                Ptr->_Delete_this(this: Ptr); /*0x14100e878*/
            }
          }
        }
      }
      parent = scope.parent; /*0x14100e87c*/
    }
    __unwind
    {
      std::_Temporary_owner_del<RBX::ScriptService *,RBX::Creatable<RBX::Instance>::Deleter<RBX::ScriptService>>::~_Temporary_owner_del<RBX::ScriptService *,RBX::Creatable<RBX::Instance>::Deleter<RBX::ScriptService>>(this: &v31); /*0xf1c0000000000038*/
    }
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&scope); /*0xf1c0000000000044*/
  }
  __wind /*0xf1c000000000004c*/
  {
    RBX::Memory::setCurrentCategory(category: parent); /*0x14100e880*/
    v27 = result; /*0x14100e886*/
  }
  __unwind
  {
    __std_terminate(a1: v26, a2: &v28); /*0x142f39fa8*/
  }
  return v27; /*0x14100e889*/
}

// Address: 0x141093790 | Name: ??0ClientReplicator@Network@RBX@@QEAA@UReplicatorPeerInfo@Replicator@12@PEAVNetworkSettings@2@PEAVMegaReplicator@12@@Z
RBX::Network::ClientReplicator *__fastcall RBX::Network::ClientReplicator::ClientReplicator(
        RBX::Network::ClientReplicator *this,
        std::_Binder<std::_Unforced,void (__cdecl RBX::NavigationDebugDraw::*)(dtNavMesh *,RBX::Extents),std::shared_ptr<RBX::NavigationDebugDraw> &,std::_Ph<1> const &,RBX::Extents &> *peerInfo,
        RBX::NetworkSettings *networkSettings,
        RBX::Network::MegaReplicator *megaReplicator)
{
  std::_Ref_count_base *Rep; // rcx
  RBX::ClassRegistrar<RBX::Network::ClientReplicator,0> *v7; // rax
  RBX::Network::PropSync::Slave *p_propSync; // rdi
  rbx::timestamped_safe_queue<RBX::Network::PropSync::detail::PropertyKey> *p_expirationQueue; // rbx
  rbx::timestamped_safe_queue<RBX::Network::PropSync::detail::PropertyKey> **v10; // rax
  rbx::timestamped_safe_queue<RBX::Network::Sync::AttributeKey const *> *v11; // rbx
  rbx::timestamped_safe_queue<RBX::Network::Sync::AttributeKey const *> **v12; // rax
  std::_List_node<std::pair<std::string const ,int>,void *> *v13; // rax
  std::_List_node<std::pair<RBX::Instance const * const,RBX::Guid>,void *> *v14; // rax
  char *v15; // rax
  char *Ptr; // rcx
  RBX::AutoMemPool *v17; // rax
  RBX::AutoMemPool *v18; // r15
  boost::pool<RBX::TrackedAllocator> *v19; // rax
  boost::pool<RBX::TrackedAllocator> *Myval2; // r14
  char *v21; // rcx
  unsigned __int64 sz; // rdi
  char *v23; // rax
  char *v24; // rbx
  __int64 v25; // rcx
  RBX::AutoMemPool *v26; // rbx
  std::_Ref_count_base *v27; // rbx
  RBX::Network::ClientReplicator *result; // rax
  __int64 v29; // [rsp+0h] [rbp-89h] BYREF
  boost::details::PODptr<unsigned __int64> list; // [rsp+30h] [rbp-59h]
  std::string value; // [rsp+40h] [rbp-49h] BYREF
  RBX::Network::Replicator::ReplicatorPeerInfo v32; // [rsp+60h] [rbp-29h] BYREF
  RBX::Network::PropSync::Slave *v35; // [rsp+100h] [rbp+77h]
  RBX::Network::Sync::Slave<RBX::Network::Sync::AttributeKey> *p_attrSync; // [rsp+100h] [rbp+77h]
  std::unique_ptr<boost::pool<RBX::TrackedAllocator>> *p_pool; // [rsp+100h] [rbp+77h]

  v32.remotePeerId.peerId = (unsigned int)peerInfo->_Mypair._Myval1; /*0x1410937ba*/
  v32.remotePlayerAddress = *(RakNet::SystemAddress *)((char *)&peerInfo->_Mypair._Myval1 + 4); /*0x1410937c1*/
  v32.rakPeer = 0; /*0x1410937d0*/
  Rep = peerInfo->_Mypair._Myval2._Myfirst._Val._Rep; /*0x1410937d5*/
  if ( Rep != nullptr ) /*0x1410937dc*/
  {
    _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410937de*/
    Rep = peerInfo->_Mypair._Myval2._Myfirst._Val._Rep; /*0x1410937e2*/
  }
  __wind /*0xf1c00000000002a4*/
  {
    v32.rakPeer._Ptr = (RBX::Network::ConcurrentRakPeer *)peerInfo->_Mypair._Myval2._Myfirst._Val._Ptr; /*0x1410937ea*/
    v32.rakPeer._Rep = Rep; /*0x1410937ee*/
    v32.capability = (unsigned __int64)peerInfo[1]._Mypair._Myval1; /*0x1410937f6*/
    RBX::Network::Replicator::Replicator( /*0x141093809*/
      this,
      peerInfo: &v32,
      networkSettings,
      clusterDebounceEnabled: true,
      megaReplicator);
    __wind /*0xf1c0000000000228*/
    {
      this->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>::RBX::Network::IdSerializer::RBX::Instance::RBX::Reflection::DescribedBase::RBX::Reflection::EventSource::__vftable = (RBX::Network::ClientReplicator_vtbl *)RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::`vftable'{for `RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>'}; /*0x141093816*/
      this->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::IMetric::__vftable = (RBX::IMetric_vtbl *)RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::`vftable'{for `RBX::IMetric'}; /*0x141093820*/
      this->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::Voxel2::GridListener::__vftable = (RBX::Voxel2::GridListener_vtbl *)RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::`vftable'{for `RBX::Voxel2::GridListener'}; /*0x14109382e*/
      v7 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(); /*0x141093835*/
    }
    __unwind
    {
      RBX::Network::Replicator::~Replicator(this); /*0xf1c0000000000238*/
    }
    __wind /*0xf1c0000000000240*/
    {
      __wind /*0xf1c0000000000248*/
      {
        this->descriptor = &v7->desc; /*0x14109383a*/
        this->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>::RBX::Network::IdSerializer::RBX::Instance::RBX::Reflection::DescribedBase::RBX::Reflection::EventSource::__vftable = (RBX::Network::ClientReplicator_vtbl *)RBX::Network::ClientReplicator::`vftable'{for `RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>'}; /*0x141093845*/
        this->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::IMetric::__vftable = (RBX::IMetric_vtbl *)RBX::Network::ClientReplicator::`vftable'{for `RBX::IMetric'}; /*0x14109384f*/
        this->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::Voxel2::GridListener::__vftable = (RBX::Voxel2::GridListener_vtbl *)RBX::Network::ClientReplicator::`vftable'{for `RBX::Voxel2::GridListener'}; /*0x14109385d*/
        p_propSync = &this->propSync; /*0x141093864*/
        v35 = &this->propSync; /*0x14109386b*/
        this->propSync.expirationTime.sec = 4.0; /*0x141093879*/
        this->propSync.map.table_.current_ = false; /*0x14109387c*/
        this->propSync.map.table_.bucket_count_ = 16; /*0x141093880*/
        this->propSync.map.table_.size_ = 0; /*0x14109388b*/
        this->propSync.map.table_.mlf_ = 1.0; /*0x14109388f*/
        this->propSync.map.table_.max_load_ = 0; /*0x141093896*/
        this->propSync.map.table_.buckets_ = nullptr; /*0x14109389a*/
        p_expirationQueue = &this->propSync.expirationQueue; /*0x14109389e*/
        this->propSync.expirationQueue.queue._Mypair._Myval2._Myproxy = nullptr; /*0x1410938a6*/
        this->propSync.expirationQueue.queue._Mypair._Myval2._Map = nullptr; /*0x1410938a9*/
        this->propSync.expirationQueue.queue._Mypair._Myval2._Mapsize = 0; /*0x1410938ad*/
        this->propSync.expirationQueue.queue._Mypair._Myval2._Myoff = 0; /*0x1410938b1*/
        this->propSync.expirationQueue.queue._Mypair._Myval2._Mysize = 0; /*0x1410938b5*/
        v10 = (rbx::timestamped_safe_queue<RBX::Network::PropSync::detail::PropertyKey> **)operator new(size: 0x10u); /*0x1410938bd*/
      }
      __unwind
      {
        boost::unordered::unordered_map<RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::SlaveItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey>,std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const,RBX::Network::PropSync::detail::SlaveItem>>>::~unordered_map<RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::SlaveItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey>,std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const,RBX::Network::PropSync::detail::SlaveItem>>>(this: (boost::unordered::unordered_map<RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::MasterItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey>,std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const ,RBX::Network::PropSync::detail::MasterItem> > > *)&v35->map); /*0x1431ebb9b*/
      }
      __wind /*0xf1c0000000000260*/
      {
        __wind /*0xf1c0000000000268*/
        {
          v10[1] = nullptr; /*0x1410938c2*/
          p_expirationQueue->queue._Mypair._Myval2._Myproxy = (std::_Container_proxy *)v10; /*0x1410938c6*/
          *v10 = p_expirationQueue; /*0x1410938c9*/
          p_expirationQueue->m.flag._Storage._Storage._Value = 0; /*0x1410938ce*/
          p_propSync->ackCount = 0; /*0x1410938d1*/
          p_attrSync = &this->attrSync; /*0x1410938dc*/
          this->attrSync.expirationTime.sec = 4.0; /*0x1410938e0*/
          this->attrSync.itemMap.table_.current_ = false; /*0x1410938e3*/
          this->attrSync.itemMap.table_.bucket_count_ = 16; /*0x1410938e7*/
          this->attrSync.itemMap.table_.size_ = 0; /*0x1410938ef*/
          this->attrSync.itemMap.table_.mlf_ = 1.0; /*0x1410938f3*/
          this->attrSync.itemMap.table_.max_load_ = 0; /*0x1410938fa*/
          this->attrSync.itemMap.table_.buckets_ = nullptr; /*0x1410938fe*/
          v11 = &this->attrSync.expirationQueue; /*0x141093902*/
          this->attrSync.expirationQueue.queue._Mypair._Myval2._Myproxy = nullptr; /*0x14109390a*/
          this->attrSync.expirationQueue.queue._Mypair._Myval2._Map = nullptr; /*0x14109390d*/
          this->attrSync.expirationQueue.queue._Mypair._Myval2._Mapsize = 0; /*0x141093911*/
          this->attrSync.expirationQueue.queue._Mypair._Myval2._Myoff = 0; /*0x141093915*/
          this->attrSync.expirationQueue.queue._Mypair._Myval2._Mysize = 0; /*0x141093919*/
          v12 = (rbx::timestamped_safe_queue<RBX::Network::Sync::AttributeKey const *> **)operator new(size: 0x10u); /*0x141093921*/
        }
        __unwind
        {
          boost::unordered::unordered_map<std::string,JobInfo,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,JobInfo>>>::~unordered_map<std::string,JobInfo,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,JobInfo>>>(this: (boost::unordered::unordered_map<std::string,JobInfo,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,JobInfo> > > *)&p_attrSync->itemMap); /*0x1431ebbab*/
        }
        __wind /*0xf1c0000000000280*/
        {
          __wind /*0xf1c0000000000288*/
          {
            __wind /*0xf1c0000000000290*/
            {
              __wind /*0xf1c0000000000298*/
              {
                v12[1] = nullptr; /*0x141093926*/
                v11->queue._Mypair._Myval2._Myproxy = (std::_Container_proxy *)v12; /*0x14109392a*/
                *v12 = v11; /*0x14109392d*/
                v11->m.flag._Storage._Storage._Value = 0; /*0x141093932*/
                this->clientAddress.remoteId.peerId = -1; /*0x141093935*/
                this->receivedGlobals = false; /*0x14109393f*/
                this->cframePool._Mypair._Myval2 = nullptr; /*0x141093945*/
                this->gcJob._Ptr = nullptr; /*0x14109394c*/
                this->gcJob._Rep = nullptr; /*0x141093953*/
                this->streamingSolver._Ptr = nullptr; /*0x14109395a*/
                this->streamingSolver._Rep = nullptr; /*0x141093961*/
                this->avgInstancesPerStreamData.lerp = 0.05; /*0x141093972*/
                this->avgInstancesPerStreamData.lastSampleValue = 25.0; /*0x141093983*/
                this->avgInstancesPerStreamData.averageValue = 25.0; /*0x14109398a*/
                this->avgInstancesPerStreamData.averageVariance = 0.0; /*0x141093991*/
                this->avgInstancesPerStreamData.firstTime = true; /*0x141093998*/
                this->avgStreamDataReadTime.lerp = 0.1; /*0x1410939a9*/
                this->avgStreamDataReadTime.lastSampleValue = 0.05; /*0x1410939b0*/
                this->avgStreamDataReadTime.averageValue = 0.05; /*0x1410939b7*/
                this->avgStreamDataReadTime.averageVariance = 0.0; /*0x1410939be*/
                this->avgStreamDataReadTime.firstTime = true; /*0x1410939c5*/
                RBX::Time::now<1>(result: &this->streamDataPerSec.timer.start); /*0x1410939d3*/
                this->streamDataPerSec.interval = 1.0; /*0x1410939e2*/
                *(_QWORD *)&this->streamDataPerSec.valueLastInterval = 0; /*0x1410939e9*/
                this->avgTerrainDataReadTime.lerp = 0.05; /*0x1410939f0*/
                this->avgTerrainDataReadTime.lastSampleValue = 0.0; /*0x1410939f7*/
                this->avgTerrainDataReadTime.averageValue = 0.0; /*0x1410939fe*/
                this->avgTerrainDataReadTime.averageVariance = 0.0; /*0x141093a05*/
                this->avgTerrainDataReadTime.firstTime = true; /*0x141093a0c*/
                RBX::Time::now<1>(result: &this->terrainPerSec.timer.start); /*0x141093a1a*/
                this->terrainPerSec.interval = 1.0; /*0x141093a1f*/
                *(_QWORD *)&this->terrainPerSec.valueLastInterval = 0; /*0x141093a26*/
                this->avgRequestCount.lerp = 0.1; /*0x141093a2d*/
                this->avgRequestCount.lastSampleValue = 0; /*0x141093a34*/
                this->avgRequestCount.averageValue = 0.0; /*0x141093a3b*/
                this->avgRequestCount.averageVariance = 0.0; /*0x141093a42*/
                this->avgRequestCount.firstTime = true; /*0x141093a49*/
                this->avgMaxRegionDistance.lerp = 0.1; /*0x141093a50*/
                this->avgMaxRegionDistance.lastSampleValue = 0; /*0x141093a57*/
                this->avgMaxRegionDistance.averageValue = 0.0; /*0x141093a5f*/
                this->avgMaxRegionDistance.averageVariance = 0.0; /*0x141093a66*/
                this->avgMaxRegionDistance.firstTime = true; /*0x141093a6d*/
                this->avgFractionStreamData.lerp = 0.1; /*0x141093a74*/
                this->avgFractionStreamData.lastSampleValue = 0.0; /*0x141093a7b*/
                this->avgFractionStreamData.averageValue = 0.0; /*0x141093a82*/
                this->avgFractionStreamData.averageVariance = 0.0; /*0x141093a89*/
                this->avgFractionStreamData.firstTime = true; /*0x141093a90*/
                this->avgFractionTerrainData.lerp = 0.1; /*0x141093a97*/
                this->avgFractionTerrainData.lastSampleValue = 0.0; /*0x141093a9e*/
                this->avgFractionTerrainData.averageValue = 0.0; /*0x141093aa5*/
                this->avgFractionTerrainData.averageVariance = 0.0; /*0x141093aac*/
                this->avgFractionTerrainData.firstTime = true; /*0x141093ab3*/
                this->avgInstanceQuotaDiff.lerp = 0.1; /*0x141093aba*/
                this->avgInstanceQuotaDiff.lastSampleValue = 0; /*0x141093ac1*/
                this->avgInstanceQuotaDiff.averageValue = 0.0; /*0x141093ac8*/
                this->avgInstanceQuotaDiff.averageVariance = 0.0; /*0x141093acf*/
                this->avgInstanceQuotaDiff.firstTime = true; /*0x141093ad6*/
                this->avgIncomingPacketsProcessedPerSec.lerp = 0.1; /*0x141093add*/
                this->avgIncomingPacketsProcessedPerSec.lastSampleValue = 0; /*0x141093ae4*/
                this->avgIncomingPacketsProcessedPerSec.averageValue = 0.0; /*0x141093aeb*/
                this->avgIncomingPacketsProcessedPerSec.averageVariance = 0.0; /*0x141093af2*/
                this->avgIncomingPacketsProcessedPerSec.firstTime = true; /*0x141093af9*/
                this->memoryLevel = MEMORYLEVEL_OK; /*0x141093b00*/
                RBX::Time::now<1>(result: &this->deletedTerrainPerSec.timer.start); /*0x141093b11*/
                this->deletedTerrainPerSec.interval = 1.0; /*0x141093b16*/
                *(_QWORD *)&this->deletedTerrainPerSec.valueLastInterval = 0; /*0x141093b1d*/
                RBX::Time::now<1>(result: &this->deletedInstancesPerSec.timer.start); /*0x141093b2b*/
                this->deletedInstancesPerSec.interval = 1.0; /*0x141093b30*/
                *(_QWORD *)&this->deletedInstancesPerSec.valueLastInterval = 0; /*0x141093b37*/
                *(_QWORD *)&this->countInstanceQuotaChanged = 0; /*0x141093b3e*/
                this->instanceQuotaSourceCount._Traitsobj._Mypair._Myval2._Myval2 = 0.0; /*0x141093b50*/
                this->instanceQuotaSourceCount._List._Mypair._Myval2._Myhead = nullptr; /*0x141093b53*/
                this->instanceQuotaSourceCount._List._Mypair._Myval2._Mysize = 0; /*0x141093b57*/
                v13 = (std::_List_node<std::pair<std::string const ,int>,void *> *)operator new(size: 0x38u); /*0x141093b5f*/
                v13->_Next = v13; /*0x141093b64*/
                v13->_Prev = v13; /*0x141093b67*/
                this->instanceQuotaSourceCount._List._Mypair._Myval2._Myhead = v13; /*0x141093b6b*/
                __wind /*0xf1c000000000021c*/
                {
                  this->instanceQuotaSourceCount._Vec._Mypair._Myval2._Myfirst = nullptr; /*0x141093b73*/
                  this->instanceQuotaSourceCount._Vec._Mypair._Myval2._Mylast = nullptr; /*0x141093b76*/
                  this->instanceQuotaSourceCount._Vec._Mypair._Myval2._Myend = nullptr; /*0x141093b7a*/
                  this->instanceQuotaSourceCount._Mask = 7; /*0x141093b7e*/
                  this->instanceQuotaSourceCount._Maxidx = 8; /*0x141093b86*/
                  this->instanceQuotaSourceCount._Traitsobj._Mypair._Myval2._Myval2 = 1.0; /*0x141093b8e*/
                  __wind /*0xf1c00000000001ec*/
                  {
                    std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::shared_ptr<RBX::Graphics::Shader>>>>>>>::_Assign_grow( /*0x141093b9c*/
                      this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > > > > *)&this->instanceQuotaSourceCount._Vec,
                      _Cells: 0x10u,
                      _Val: (const std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > >)this->instanceQuotaSourceCount._List._Mypair._Myval2._Myhead);
                  }
                  __unwind
                  {
                    std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&this->instanceQuotaSourceCount._Vec); /*0x14319f51b*/
                  }
                }
                __unwind
                {
                  std::list<std::pair<std::string const,enum RBX::Studio::LaunchTask>>::~list<std::pair<std::string const,enum RBX::Studio::LaunchTask>>(this: (std::list<std::pair<std::string const ,PluginMenuRelay *>> *)&this->instanceQuotaSourceCount._List); /*0x1431ebbbb*/
                }
                __wind /*0xf1c0000000000210*/
                {
                  this->randHashFunction = 0; /*0x141093ba2*/
                  this->streamingFrameTime.lerp = (double)DFInt::StreamingReportPerformanceStatsAverageLerpValueThousands /*0x141093bc1*/
                                                / 1000.0;
                  this->streamingFrameTime.lastSampleValue = 0.0; /*0x141093bc9*/
                  this->streamingFrameTime.averageValue = 0.0; /*0x141093bd0*/
                  this->streamingFrameTime.averageVariance = 0.0; /*0x141093bd7*/
                  this->streamingFrameTime.firstTime = true; /*0x141093bde*/
                  this->streamingDataReadTime.lerp = (double)DFInt::StreamingReportPerformanceStatsAverageLerpValueThousands /*0x141093bf5*/
                                                   / 1000.0;
                  this->streamingDataReadTime.lastSampleValue = 0.0; /*0x141093bfd*/
                  this->streamingDataReadTime.averageValue = 0.0; /*0x141093c04*/
                  this->streamingDataReadTime.averageVariance = 0.0; /*0x141093c0b*/
                  this->streamingDataReadTime.firstTime = true; /*0x141093c12*/
                  this->streamingFramePortion.lerp = (double)DFInt::StreamingReportPerformanceStatsAverageLerpValueThousands /*0x141093c29*/
                                                   / 1000.0;
                  this->streamingFramePortion.lastSampleValue = 0.0; /*0x141093c31*/
                  this->streamingFramePortion.averageValue = 0.0; /*0x141093c38*/
                  this->streamingFramePortion.averageVariance = 0.0; /*0x141093c3f*/
                  this->streamingFramePortion.firstTime = true; /*0x141093c46*/
                  this->streamingDataReadPortion.lerp = (double)DFInt::StreamingReportPerformanceStatsAverageLerpValueThousands /*0x141093c5d*/
                                                      / 1000.0;
                  this->streamingDataReadPortion.lastSampleValue = 0.0; /*0x141093c65*/
                  this->streamingDataReadPortion.averageValue = 0.0; /*0x141093c6c*/
                  this->streamingDataReadPortion.averageVariance = 0.0; /*0x141093c73*/
                  this->streamingDataReadPortion.firstTime = true; /*0x141093c7a*/
                  this->avgStreamedInRadius.lerp = (double)DFInt::StreamingReportPerformanceStatsAverageLerpValueThousands /*0x141093c91*/
                                                 / 1000.0;
                  this->avgStreamedInRadius.lastSampleValue = 0; /*0x141093c99*/
                  this->avgStreamedInRadius.averageValue = 0.0; /*0x141093ca0*/
                  this->avgStreamedInRadius.averageVariance = 0.0; /*0x141093ca7*/
                  this->avgStreamedInRadius.firstTime = true; /*0x141093cae*/
                  this->avgStreamingDeferredGCNOUCount.lerp = 0.0; /*0x141093cb5*/
                  this->avgStreamingDeferredGCNOUCount.lastSampleValue = 0; /*0x141093cbc*/
                  this->avgStreamingDeferredGCNOUCount.averageValue = 0.0; /*0x141093cc3*/
                  this->avgStreamingDeferredGCNOUCount.averageVariance = 0.0; /*0x141093cca*/
                  this->avgStreamingDeferredGCNOUCount.firstTime = true; /*0x141093cd1*/
                  this->avgStreamedInRegionsCount.lerp = 0.05; /*0x141093cd8*/
                  this->avgStreamedInRegionsCount.lastSampleValue = 0; /*0x141093cdf*/
                  this->avgStreamedInRegionsCount.averageValue = 0.0; /*0x141093ce6*/
                  this->avgStreamedInRegionsCount.averageVariance = 0.0; /*0x141093ced*/
                  this->avgStreamedInRegionsCount.firstTime = true; /*0x141093cf4*/
                  this->maxStreamedInRegionsCount = 0; /*0x141093cfb*/
                  this->totalPrefetchDistance = 0.0; /*0x141093d02*/
                  this->numPrefetches = 0; /*0x141093d09*/
                  this->numGCs = 0; /*0x141093d10*/
                  this->streamingCurrentFrameTime = 0.0; /*0x141093d17*/
                  this->streamingReadDataItemFrameTime = 0.0; /*0x141093d1e*/
                  this->streamingPreviousFrameTime = 0.0; /*0x141093d25*/
                  this->streamingPreviousReadDataItemFrameTime = 0.0; /*0x141093d2c*/
                  this->sampleTimer = -1.0; /*0x141093d3d*/
                  *(_QWORD *)&this->clientInstanceQuota = 0; /*0x141093d44*/
                  *(_QWORD *)&this->lastReadStreamId.internalValue.y = 0; /*0x141093d4b*/
                  *(_QWORD *)&this->pendingInstanceRequests = 0; /*0x141093d52*/
                  this->loggedLowMemWarning = false; /*0x141093d59*/
                  *(_QWORD *)&this->cycleAtNewConnectionAccepted = 0; /*0x141093d60*/
                  RBX::Analytics::InfluxDb::Points::Points( /*0x141093d7d*/
                    this: &this->clientJoinRxStatsPoint,
                    throttleHundredthsPercentage: -1,
                    categoryType: kStandardType,
                    priorityHundredthsPercentage: 0);
                  __wind /*0xf1c00000000001e0*/
                  {
                    this->reportJoinRxStats = false; /*0x141093d83*/
                    this->replicatedParentMap._Traitsobj._Mypair._Myval2._Myval2 = 0.0; /*0x141093d97*/
                    this->replicatedParentMap._List._Mypair._Myval2._Myhead = nullptr; /*0x141093d99*/
                    this->replicatedParentMap._List._Mypair._Myval2._Mysize = 0; /*0x141093d9d*/
                    v14 = (std::_List_node<std::pair<RBX::Instance const * const,RBX::Guid>,void *> *)operator new(size: 0x20u); /*0x141093da4*/
                    __wind /*0xf1c00000000002c4*/
                    {
                      __wind /*0xf1c00000000002cc*/
                      {
                        v14->_Next = v14; /*0x141093da9*/
                        v14->_Prev = v14; /*0x141093dac*/
                        this->replicatedParentMap._List._Mypair._Myval2._Myhead = v14; /*0x141093db0*/
                        this->replicatedParentMap._Vec._Mypair._Myval2._Myfirst = nullptr; /*0x141093db8*/
                        this->replicatedParentMap._Vec._Mypair._Myval2._Mylast = nullptr; /*0x141093dbb*/
                        this->replicatedParentMap._Vec._Mypair._Myval2._Myend = nullptr; /*0x141093dbf*/
                        this->replicatedParentMap._Mask = 7; /*0x141093dc3*/
                        this->replicatedParentMap._Maxidx = 8; /*0x141093dcb*/
                        this->replicatedParentMap._Traitsobj._Mypair._Myval2._Myval2 = 1.0; /*0x141093dd3*/
                        std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const,std::shared_ptr<RBX::Graphics::Shader>>>>>>>::_Assign_grow( /*0x141093de0*/
                          this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > > > > *)&this->replicatedParentMap._Vec,
                          _Cells: 0x10u,
                          _Val: (const std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,std::shared_ptr<PluginPermissionsFetcher> > > > >)this->replicatedParentMap._List._Mypair._Myval2._Myhead);
                      }
                      __unwind
                      {
                        std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&this->replicatedParentMap._Vec); /*0xf1c00000000000b0*/
                      }
                    }
                    __unwind
                    {
                      std::list<std::pair<RBX::StreamRegion::Id const,bool>>::~list<std::pair<RBX::StreamRegion::Id const,bool>>(this: (std::list<std::pair<SearchResult * const,QuickOpenItemWidget *>> *)&this->replicatedParentMap._List); /*0x1431ebbcb*/
                    }
                    __wind /*0xf1c00000000002f0*/
                    {
                      rbx::signals::signal_base::signal_base(this: &this->receivedGlobalsSignal); /*0x141093df1*/
                      __wind /*0xf1c00000000001d4*/
                      {
                        rbx::signals::signal_base::signal_base(this: &this->gameLoadedSignal); /*0x141093e02*/
                        __wind /*0xf1c00000000001c8*/
                        {
                          rbx::signals::signal_base::signal_base(this: &this->statsReceivedSignal); /*0x141093e13*/
                          __wind /*0xf1c00000000001bc*/
                          {
                            rbx::signals::signal_base::signal_base(this: &this->rccProfilerDataCompleteSignal); /*0x141093e24*/
                            __wind /*0xf1c0000000000108*/
                            {
                              value._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141093e2a*/
                              value._Mypair._Myval2._Mysize = 0; /*0x141093e2e*/
                              value._Mypair._Myval2._Myres = 15; /*0x141093e32*/
                              v15 = (char *)operator new(size: 0x20u); /*0x141093e41*/
                              __wind /*0xf1c00000000000fc*/
                              {
                                value._Mypair._Myval2._Mysize = 16; /*0x141093e46*/
                                value._Mypair._Myval2._Myres = 31; /*0x141093e4e*/
                                strcpy(v15, "ClientReplicator"); /*0x141093e5d*/
                                value._Mypair._Myval2._Bx._Ptr = v15; /*0x141093e64*/
                                RBX::Instance::setName(this, &value); /*0x141093e6f*/
                                if ( value._Mypair._Myval2._Myres >= 0x10 ) /*0x141093e7d*/
                                {
                                  Ptr = value._Mypair._Myval2._Bx._Ptr; /*0x141093e82*/
                                  if ( value._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141093e90*/
                                  {
                                    Ptr = *((char **)value._Mypair._Myval2._Bx._Ptr - 1); /*0x141093e96*/
                                    if ( (unsigned __int64)(value._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141093ea5*/
                                      _invalid_parameter_noinfo_noreturn(); /*0x141093ea7*/
                                  }
                                  operator delete(ptr: Ptr); /*0x141093eae*/
                                }
                              }
                              __unwind
                              {
                                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&value); /*0xf1c00000000000f4*/
                              }
                              v17 = (RBX::AutoMemPool *)operator new(size: 8u); /*0x141093eb8*/
                              v18 = v17; /*0x141093ebd*/
                              p_pool = &v17->pool; /*0x141093ec0*/
                              if ( v17 != nullptr ) /*0x141093ec7*/
                              {
                                __wind /*0xf1c00000000002b0*/
                                {
                                  __wind /*0xf1c00000000002b8*/
                                  {
                                    v17->pool._Mypair._Myval2 = nullptr; /*0x141093ecd*/
                                    v19 = (boost::pool<RBX::TrackedAllocator> *)operator new(size: 0x38u); /*0x141093ed5*/
                                    if ( v19 != nullptr ) /*0x141093ee1*/
                                    {
                                      v19->first = nullptr; /*0x141093ee3*/
                                      v19->list.ptr = nullptr; /*0x141093ee6*/
                                      v19->list.sz = 0; /*0x141093eea*/
                                      v19->requested_size = 96; /*0x141093eee*/
                                      v19->next_size = 32; /*0x141093ef6*/
                                      v19->start_size = 32; /*0x141093efe*/
                                      v19->max_size = 0; /*0x141093f06*/
                                    }
                                    else
                                    {
                                      v19 = nullptr; /*0x141093f0c*/
                                    }
                                    Myval2 = v18->pool._Mypair._Myval2; /*0x141093f0f*/
                                    v18->pool._Mypair._Myval2 = v19; /*0x141093f12*/
                                    if ( Myval2 != nullptr ) /*0x141093f18*/
                                    {
                                      __wind /*0xf1c00000000000c0*/
                                      {
                                        list = Myval2->list; /*0x141093f1f*/
                                        v21 = list.ptr; /*0x141093f23*/
                                        if ( list.ptr != nullptr ) /*0x141093f2b*/
                                        {
                                          sz = list.sz; /*0x141093f2d*/
                                          do /*0x141093f48*/
                                          {
                                            v23 = &v21[sz]; /*0x141093f31*/
                                            sz = *(_QWORD *)&v21[sz - 8]; /*0x141093f35*/
                                            v24 = *((char **)v23 - 2); /*0x141093f39*/
                                            operator delete(ptr: v21); /*0x141093f3d*/
                                            v21 = v24; /*0x141093f42*/
                                          }
                                          while ( v24 != nullptr ); /*0x141093f48*/
                                          Myval2->list.ptr = nullptr; /*0x141093f4c*/
                                          Myval2->first = nullptr; /*0x141093f50*/
                                          Myval2->next_size = Myval2->start_size; /*0x141093f57*/
                                        }
                                        operator delete(ptr: Myval2); /*0x141093f63*/
                                      }
                                      __unwind
                                      {
                                        __std_terminate(a1: v25, a2: &v29); /*0x142f39fa8*/
                                      }
                                    }
                                  }
                                  __unwind
                                  {
                                    std::unique_ptr<boost::pool<RBX::TrackedAllocator>>::~unique_ptr<boost::pool<RBX::TrackedAllocator>>(this: p_pool); /*0xf1c00000000000dc*/
                                  }
                                }
                                __unwind
                                {
                                  operator delete(ptr: p_pool); /*0x1431ebb75*/
                                }
                              }
                              else
                              {
                                v18 = nullptr; /*0x141093f6b*/
                              }
                              v26 = this->cframePool._Mypair._Myval2; /*0x141093f6e*/
                              this->cframePool._Mypair._Myval2 = v18; /*0x141093f75*/
                              if ( v26 != nullptr ) /*0x141093f7f*/
                              {
                                std::unique_ptr<boost::pool<RBX::TrackedAllocator>>::~unique_ptr<boost::pool<RBX::TrackedAllocator>>(this: &v26->pool); /*0x141093f84*/
                                operator delete(ptr: v26); /*0x141093f91*/
                              }
                              this->processAllPacketsPerStep = true; /*0x141093f96*/
                              this->canTimeout = false; /*0x141093f9d*/
                              v27 = peerInfo->_Mypair._Myval2._Myfirst._Val._Rep; /*0x141093fa4*/
                              if ( v27 != nullptr /*0x141093fb9*/
                                && _InterlockedExchangeAdd((volatile signed __int32 *)&v27->_Uses, 0xFFFFFFFF) == 1 )
                              {
                                v27->_Destroy(this: v27); /*0x141093fc1*/
                                if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v27->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141093fcd*/
                                  v27->_Delete_this(this: v27); /*0x141093fd5*/
                              }
                              result = this; /*0x141093fd8*/
                            }
                            __unwind
                            {
                              rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)&this->rccProfilerDataCompleteSignal); /*0x1431ebb4e*/
                            }
                          }
                          __unwind
                          {
                            rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)&this->statsReceivedSignal); /*0x1431ebb2e*/
                          }
                        }
                        __unwind
                        {
                          rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)&this->gameLoadedSignal); /*0x1431ebb0e*/
                        }
                      }
                      __unwind
                      {
                        rbx::signal<void (std::string,std::string,std::string,std::string)>::~signal<void (std::string,std::string,std::string,std::string)>(this: (rbx::signal<void __cdecl(PluginReference)> *)&this->receivedGlobalsSignal); /*0x1431ebaee*/
                      }
                    }
                    __unwind
                    {
                      std::unordered_map<RBX::Guid,unsigned __int64,RBX::Hash<void>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const,unsigned __int64>>>::~unordered_map<RBX::Guid,unsigned __int64,RBX::Hash<void>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const,unsigned __int64>>>(this: (std::unordered_map<SearchResult *,QuickOpenItemWidget *> *)&this->replicatedParentMap); /*0x1431ebace*/
                    }
                  }
                  __unwind
                  {
                    RBX::Analytics::InfluxDb::Points::~Points(this: &this->clientJoinRxStatsPoint); /*0x1431ebaae*/
                  }
                }
                __unwind
                {
                  std::unordered_map<std::string,std::_List_iterator<std::_List_val<std::_List_simple_types<std::string>>>>::~unordered_map<std::string,std::_List_iterator<std::_List_val<std::_List_simple_types<std::string>>>>(this: (std::unordered_map<std::string,PluginMenuRelay *> *)&this->instanceQuotaSourceCount); /*0x1431eba8e*/
                }
              }
              __unwind
              {
                std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->streamingSolver); /*0x1431eba6e*/
              }
            }
            __unwind
            {
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->gcJob); /*0x1431eba4e*/
            }
          }
          __unwind
          {
            std::unique_ptr<RBX::AutoMemPool>::~unique_ptr<RBX::AutoMemPool>(this: &this->cframePool); /*0x1431eba2e*/
          }
        }
        __unwind
        {
          RBX::Network::Sync::Master<RBX::Network::Sync::AttributeKey>::~Master<RBX::Network::Sync::AttributeKey>(this: (RBX::Network::Sync::Master<RBX::Network::Sync::AttributeKey> *)&this->attrSync); /*0x1431eba0e*/
        }
      }
      __unwind
      {
        RBX::Network::PropSync::Slave::~Slave(this: (RBX::Network::PropSync::Master *)&this->propSync); /*0x1431eb9ee*/
      }
    }
    __unwind
    {
      RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::~Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>((RBX::Described<RBX::Network::ServerReplicator,RBX::Network::Replicator> *)this); /*0xf1c00000000001a8*/
    }
  }
  __unwind
  {
    rbx::signals::slot_with_functor<RBX::Reflection::ConnectGenericHelper<rbx::signal<void (enum RBX::MaterialType)>>,enum RBX::MaterialType>::do_dtor(this: peerInfo); /*0xf1c00000000001b4*/
  }
  return result; /*0x141093fdb*/
}

// Address: 0x1410941f0 | Name: ??1ClientReplicator@Network@RBX@@UEAA@XZ
void __fastcall RBX::Network::ClientReplicator::~ClientReplicator(RBX::Network::ClientReplicator *this)
{
  std::_Ref_count_base *Rep; // rbx
  std::_Ref_count_base *v3; // rbx
  RBX::AutoMemPool *Myval2; // rbx
  std::string v5; // [rsp+30h] [rbp-48h] BYREF
  std::string v6; // [rsp+50h] [rbp-28h] BYREF

  this->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>::RBX::Network::IdSerializer::RBX::Instance::RBX::Reflection::DescribedBase::RBX::Reflection::EventSource::__vftable = (RBX::Network::ClientReplicator_vtbl *)RBX::Network::ClientReplicator::`vftable'{for `RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>'}; /*0x14109420a*/
  this->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::IMetric::__vftable = (RBX::IMetric_vtbl *)RBX::Network::ClientReplicator::`vftable'{for `RBX::IMetric'}; /*0x141094214*/
  this->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::Voxel2::GridListener::__vftable = (RBX::Voxel2::GridListener_vtbl *)RBX::Network::ClientReplicator::`vftable'{for `RBX::Voxel2::GridListener'}; /*0x141094222*/
  v5._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109422b*/
  v5._Mypair._Myval2._Myres = 15; /*0x14109422f*/
  v5._Mypair._Myval2._Mysize = 0; /*0x141094237*/
  v6._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109423b*/
  v6._Mypair._Myval2._Myres = 15; /*0x14109423f*/
  v6._Mypair._Myval2._Mysize = 0; /*0x141094247*/
  RBX::Network::Replicator::sendDisconnectionSignal(this, peer: &v6, lostConnection: false, reason: &v5, errorCode: 0); /*0x14109425a*/
  RBX::Network::ItemQueue::debugDump(this: &this->pendingItems); /*0x141094266*/
  RBX::Network::ItemQueue::debugDump(this: &this->highPriorityPendingItems); /*0x141094272*/
  rbx::signals::signal_base::~signal_base(this: &this->rccProfilerDataCompleteSignal); /*0x14109427e*/
  rbx::signals::signal_base::~signal_base(this: &this->statsReceivedSignal); /*0x14109428a*/
  rbx::signals::signal_base::~signal_base(this: &this->gameLoadedSignal); /*0x141094296*/
  rbx::signals::signal_base::~signal_base(this: &this->receivedGlobalsSignal); /*0x1410942a2*/
  std::_Hash<std::_Uset_traits<RBX::StringView,std::_Uhash_compare<RBX::StringView,std::hash<RBX::StringView>,std::equal_to<RBX::StringView>>,std::allocator<RBX::StringView>,0>>::~_Hash<std::_Uset_traits<RBX::StringView,std::_Uhash_compare<RBX::StringView,std::hash<RBX::StringView>,std::equal_to<RBX::StringView>>,std::allocator<RBX::StringView>,0>>(this: (std::_Hash<std::_Umap_traits<SearchResult *,QuickOpenItemWidget *,std::_Uhash_compare<SearchResult *,std::hash<SearchResult *>,std::equal_to<SearchResult *> >,std::allocator<std::pair<SearchResult * const,QuickOpenItemWidget *> >,0> > *)&this->replicatedParentMap); /*0x1410942ae*/
  RBX::Analytics::InfluxDb::Points::~Points(this: &this->clientJoinRxStatsPoint); /*0x1410942ba*/
  std::_Hash<std::_Umap_traits<std::string,enum RBX::WinUtil::KnownFolder,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,enum RBX::WinUtil::KnownFolder>>,0>>::~_Hash<std::_Umap_traits<std::string,enum RBX::WinUtil::KnownFolder,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,enum RBX::WinUtil::KnownFolder>>,0>>(this: (std::_Hash<std::_Umap_traits<std::string,PluginMenuRelay *,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,PluginMenuRelay *> >,0> > *)&this->instanceQuotaSourceCount); /*0x1410942c6*/
  Rep = this->streamingSolver._Rep; /*0x1410942cb*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410942e6*/
  {
    Rep->_Destroy(this: Rep); /*0x1410942ee*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410942fa*/
      Rep->_Delete_this(this: Rep); /*0x141094302*/
  }
  v3 = this->gcJob._Rep; /*0x141094305*/
  if ( v3 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v3->_Uses, 0xFFFFFFFF) == 1 ) /*0x14109431b*/
  {
    v3->_Destroy(this: v3); /*0x141094323*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v3->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14109432d*/
      v3->_Delete_this(this: v3); /*0x141094335*/
  }
  Myval2 = this->cframePool._Mypair._Myval2; /*0x141094338*/
  if ( Myval2 != nullptr ) /*0x141094342*/
  {
    std::unique_ptr<boost::pool<RBX::TrackedAllocator>>::~unique_ptr<boost::pool<RBX::TrackedAllocator>>(this: &this->cframePool._Mypair._Myval2->pool); /*0x141094347*/
    operator delete(ptr: Myval2); /*0x141094354*/
  }
  std::stack<Json::Value *>::~stack<Json::Value *,std::deque<Json::Value *>>(this: (std::deque<rtc::ArrayView<unsigned char const ,-4711>> *)&this->attrSync.expirationQueue); /*0x141094360*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>,RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>>>::~table<boost::unordered::detail::map<std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>,RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>>>(this: (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const ,JobInfo> >,std::string,JobInfo,boost::hash<std::string >,std::equal_to<std::string > > > *)&this->attrSync.itemMap); /*0x14109436c*/
  std::deque<RBX::Graphics::UITextureRenderer::JobRequest>::~deque<RBX::Graphics::UITextureRenderer::JobRequest>(this: (std::deque<webrtc::TrendlineEstimator::PacketTiming> *)&this->propSync.expirationQueue); /*0x141094378*/
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const,RBX::Network::PropSync::detail::MasterItem>>,RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::MasterItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey>>>::~table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const,RBX::Network::PropSync::detail::MasterItem>>,RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::MasterItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey>>>(this: (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const ,RBX::Network::PropSync::detail::MasterItem> >,RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::MasterItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey> > > *)&this->propSync.map); /*0x141094384*/
  RBX::Network::Replicator::~Replicator(this); /*0x14109439d*/
}

// Address: 0x141095540 | Name: ??_GClientStreamCapacityUpdateItem@ClientReplicator@Network@RBX@@UEAAPEAXI@Z
RBX::Network::Replicator::StreamJob::StreamDataInfoItem *__fastcall RBX::Network::ClientReplicator::ClientStreamCapacityUpdateItem::`scalar deleting destructor'(
        RBX::Network::Replicator::StreamJob::StreamDataInfoItem *this,
        char a2)
{
  this->__vftable = (RBX::Network::Replicator::StreamJob::StreamDataInfoItem_vtbl *)RBX::Network::Item::`vftable'; /*0x141095550*/
  if ( (a2 & 1) != 0 ) /*0x141095556*/
    operator delete(ptr: this); /*0x14109555d*/
  return this; /*0x141095565*/
}

// Address: 0x141095620 | Name: ?LogInstancesDroppedFromJoin@ClientReplicator@Network@RBX@@IEAAXAEBVGuid@3@AEAUChildrenWithParentOrder@23@@Z
void __fastcall RBX::Network::ClientReplicator::LogInstancesDroppedFromJoin(
        RBX::Network::ClientReplicator *this,
        const RBX::Guid *parentGuid,
        RBX::Network::ChildrenWithParentOrder *children)
{
  void *arg2; // rbx
  const void *numOfChildren; // rsi
  std::string *Ptr; // rax
  char *v7; // rcx
  boost::unordered::detail::ptr_bucket *i; // rbx
  std::string *FullName; // rax
  const char *v10; // rdi
  std::string *v11; // rax
  char *v12; // rcx
  void *v13; // rcx
  std::string result; // [rsp+30h] [rbp-48h] BYREF
  _BYTE v15[40]; // [rsp+50h] [rbp-28h] BYREF

  if ( DFLog::ReplicationDataCaching != 0 )
  {
    arg2 = (void *)children->nextChildIndex; /*0x14109563e*/
    numOfChildren = (const void *)children->numOfChildren; /*0x141095642*/
    Ptr = RBX::Guid::toString(this: parentGuid, &result); /*0x14109564d*/
    if ( Ptr->_Mypair._Myval2._Myres >= 0x10 ) /*0x141095658*/
      Ptr = (std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x14109565a*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000064*/
    FLog::FastLog(
      level: DFLog::ReplicationDataCaching,
      message: "[DFLog::ReplicationDataCaching] Parent Key : %s , numberOfChild = %d, nextChildIndex = %d",
      arg0: Ptr,
      arg1: numOfChildren,
      arg2);
    if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141095685*/
    {
      v7 = result._Mypair._Myval2._Bx._Ptr; /*0x14109568a*/
      if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141095699*/
      {
        v7 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14109569f*/
        if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v7 - 8) > 0x1F ) /*0x1410956ae*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410956b0*/
      }
      operator delete(ptr: v7); /*0x1410956b7*/
    }
  }
  else
  {
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000005c*/
  }
  if ( children->instancesWaitingForTheirTurn.table_.size_ != 0 )
  {
    for ( i = children->instancesWaitingForTheirTurn.table_.buckets_[children->instancesWaitingForTheirTurn.table_.bucket_count_].next_;
          i != nullptr;
          i = i->next_ )
    {
      if ( DFLog::ReplicationDataCaching != 0 )
      {
        if ( __eh34_unwind(0) ) /*0xf1c0000000000050*/
        {
unwind_state_0:
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000008*/
          __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000000c*/
        }
        __eh34_exit_wind_state(0, -1); /*0xf1c0000000000054*/
        FullName = RBX::Instance::getFullName(this: (RBX::Instance *)i[13].next_, result: (std::string *)v15); /*0x1410956f6*/
        v10 = (const char *)FullName; /*0x1410956fb*/
        if ( FullName->_Mypair._Myval2._Myres >= 0x10 ) /*0x141095703*/
          v10 = FullName->_Mypair._Myval2._Bx._Ptr; /*0x141095705*/
        __wind
        {
          v11 = RBX::Guid::toString(this: (RBX::Guid *)&i[13].next_[6], &result); /*0x141095715*/
          if ( v11->_Mypair._Myval2._Myres >= 0x10 ) /*0x141095720*/
            v11 = (std::string *)v11->_Mypair._Myval2._Bx._Ptr; /*0x141095722*/
          __wind
          {
            FLog::FastLogFormatted(
              level: DFLog::ReplicationDataCaching,
              message: "[DFLog::ReplicationDataCaching]     Value : [%d] Instance %s[%s]",
              LODWORD(i[2].next_),
              v11->_Mypair._Myval2._Bx._Buf,
              v10);
            if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14109574e*/
            {
              v12 = result._Mypair._Myval2._Bx._Ptr; /*0x141095753*/
              if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141095762*/
              {
                v12 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x141095768*/
                if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v12 - 8) > 0x1F ) /*0x141095777*/
                  _invalid_parameter_noinfo_noreturn(); /*0x1410957e8*/
              }
              operator delete(ptr: v12); /*0x141095779*/
            }
            result._Mypair._Myval2._Mysize = 0; /*0x14109577e*/
            result._Mypair._Myval2._Myres = 15; /*0x141095783*/
            result._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109578c*/
            if ( *(_QWORD *)&v15[24] >= 0x10u ) /*0x14109579a*/
            {
              v13 = *(void **)v15; /*0x14109579f*/
              if ( (unsigned __int64)(*(_QWORD *)&v15[24] + 1LL) >= 0x1000 ) /*0x1410957ae*/
              {
                v13 = *(void **)(*(_QWORD *)v15 - 8LL); /*0x1410957b4*/
                if ( (unsigned __int64)(*(_QWORD *)v15 - (_QWORD)v13 - 8LL) > 0x1F ) /*0x1410957c3*/
                  _invalid_parameter_noinfo_noreturn(); /*0x1410957ef*/
              }
              operator delete(ptr: v13); /*0x1410957c5*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000028*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)v15); /*0xf1c0000000000034*/
        }
        __eh34_enter_wind_state(-1, 0); /*0xf1c000000000003c*/
      }
    }
  }
  if ( __eh34_unwind(0) ) /*0xf1c0000000000004*/
    goto unwind_state_0; /*0xf1c0000000000004*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000010*/
}

// Address: 0x141095800 | Name: ?OnReceive@ClientReplicator@Network@RBX@@UEAA?AW4PeerReceiveResult@RakNet@@PEAUPacket@5@@Z
__int64 __fastcall RBX::Network::ClientReplicator::OnReceive(
        RBX::Network::ClientReplicator *this,
        RakNet::Packet *packet)
{
  unsigned int v4; // eax
  unsigned int v5; // ebx
  RBX::Profiler *v6; // rcx
  unsigned __int8 *v7; // rdx
  RakNet::PeerReceiveResult v8; // esi
  RBX::Security::SessionCrypto *Ptr; // rcx
  unsigned __int8 *Myfirst; // rcx
  std::string *v11; // rax
  char *v12; // rcx
  std::string *p_mismatchString; // rdx
  std::string *v14; // r8
  RBX::Network::Client *v15; // r14
  int v16; // edi
  std::string *v17; // rax
  _WORD *v18; // rax
  std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *v19; // rax
  char *v20; // rcx
  std::unordered_map<std::string,std::string> *v21; // r9
  void *Myres; // rcx
  char *v23; // rcx
  RBX::Network::Item *v24; // rax
  RBX::Network::Item *v25; // rdi
  RBX::Network::Client *v26; // r14
  int v27; // edi
  std::string *v28; // rax
  char *v29; // rax
  std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *v30; // rax
  char *v31; // rcx
  std::unordered_map<std::string,std::string> *v32; // rdi
  int PayloadLimit; // eax
  std::string *v34; // r8
  std::string *v35; // r8
  RBX::Player *v36; // rax
  rbx::signal<void __cdecl(std::string)> *p_setShutdownMessageSignal; // rdi
  rtc::webrtc_checks_impl::ToStringVal *v38; // rax
  RBX::ServiceProvider *ServiceProvider; // rdi
  unsigned __int64 v40; // rax
  RBX::Described<RBX::GuiService,RBX::ServiceInstance> *v41; // rcx
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v42; // rsi
  const RBX::Name *v43; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  RBX::GuiService *v45; // rdi
  rtc::webrtc_checks_impl::ToStringVal *v46; // rax
  __int64 Int32; // rdi
  int v48; // eax
  struct tm *v49; // rax
  boost::filesystem::path *UserDirectory; // rax
  RBX::Graphics::ProfilerAdorn::Item *v51; // rax
  const char *RBXLogPrefix; // rax
  RBX::Graphics::ProfilerAdorn::Item *v53; // rax
  std::string *p_logGuid; // rax
  std::string *v55; // rax
  unsigned __int64 v56; // r8
  std::string *v57; // rax
  char *v58; // rcx
  char *v59; // rcx
  char *v60; // rcx
  wchar_t *v61; // rcx
  char *v62; // rcx
  FILE *v63; // rax
  FILE *v64; // rdi
  std::string *p_data; // rcx
  char *v66; // rcx
  RBX::Graphics::ProfilerAdorn::Item *v67; // rax
  wchar_t *v68; // rcx
  unsigned int UInt32; // edi
  unsigned int v70; // r14d
  int v71; // eax
  const RBX::ProtectedString *v72; // rax
  Luau::InternalErrorReporter *v73; // rsi
  std::_Func_base<void,char const *>_vtbl *v74; // rdi
  RakNet::AddressOrGUID *v75; // rax
  __int64 v76; // rcx
  __int64 result; // rax
  __int64 v78; // [rsp+0h] [rbp-100h] BYREF
  std::string msg; // [rsp+40h] [rbp-C0h] BYREF
  std::string logGuid; // [rsp+68h] [rbp-98h] BYREF
  boost::filesystem::path logPath; // [rsp+88h] [rbp-78h] BYREF
  std::string mismatchString; // [rsp+A8h] [rbp-58h] BYREF
  boost::system::error_code err; // [rsp+C8h] [rbp-38h] BYREF
  RBX::Network::NetworkStream bitStream; // [rsp+E0h] [rbp-20h] BYREF
  std::string data; // [rsp+120h] [rbp+20h] BYREF
  __int128 v86; // [rsp+140h] [rbp+40h]
  std::unordered_set<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<std::string,std::string > > > v87; // [rsp+160h] [rbp+60h] BYREF
  RBX::Network::NetworkStream decompressedBts; // [rsp+1A0h] [rbp+A0h] BYREF
  char fileName[64]; // [rsp+1E0h] [rbp+E0h] BYREF
  RBX::Graphics::ProfilerAdorn::Item *v90; // [rsp+220h] [rbp+120h]
  RBX::ProtectedString bytecode; // [rsp+228h] [rbp+128h] BYREF
  char addressBuffer[1088]; // [rsp+250h] [rbp+150h] BYREF
  RBX::Memory::Scope memscopeNetworkReplicator; // [rsp+6A8h] [rbp+5A8h] BYREF
  __int64 t; // [rsp+6B0h] [rbp+5B0h] BYREF
  boost::filesystem::file_status p_msg; // [rsp+6B8h] [rbp+5B8h] BYREF

  v4 = RBX::Memory::setCurrentCategory(category: RBX::Memory::NetworkReplicator); /*0x14109582b*/
  __wind
  {
    v5 = v4; /*0x141095830*/
    memscopeNetworkReplicator.parent = v4; /*0x141095832*/
    if ( DFFlag::DebugAvatarProfilerCallers.value ) /*0x14109583f*/
      RBX::AvatarProfiler::logNetPacketProcessBegin( /*0x141095852*/
        pkt: packet,
        dataID: *packet->data,
        dataSize: packet->length,
        outRef: nullptr);
    RBX::ProtectedString::ProtectedString(this: &bytecode); /*0x14109585e*/
    __wind
    {
      v7 = packet->data; /*0x141095864*/
      v8 = RR_CONTINUE_PROCESSING; /*0x141095896*/
      switch ( *v7 )
      {
        case 0x10u:
          if ( FFlag::DebugClientDumpMicroprofileForJoins.value /*0x1410958ac*/
            || RBX::Analytics::InfluxDb::canSend(throttleHundredthsPercentage: DFInt::ClientReportInitExpJobStatsHundredthPercent) )
          {
            RBX::Profiler::notifyActiveCapture(this: v6); /*0x1410958b5*/
          }
          this->cycleAtNewConnectionAccepted = RBX::TaskScheduler::cycle(); /*0x1410958bf*/
          if ( FFlag::DebugClientDumpMicroprofileForJoins.value ) /*0x1410958ce*/
          {
            this->aggregateFramesSetting = RBX::Profiler::getAggregateFrames(); /*0x1410958d5*/
            RBX::Profiler::setAggregateFrames(numFrames: 0); /*0x1410958df*/
          }
          Ptr = this->sessionCrypto._Ptr; /*0x1410958e4*/
          if ( Ptr != nullptr ) /*0x1410958ef*/
            RBX::Security::SessionCrypto::resetKeyExchangeKeys(this: Ptr, error: false); /*0x1410958f7*/
          goto LABEL_168; /*0x1410958fc*/
        case 0x83u:
          if ( DFInt::ReportClientJoinRxStatsHundrethsPercentage != 0 ) /*0x14109691f*/
          {
            v73 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14109692e*/
            v74 = v73->onInternalError._Mystorage._Ptrs[0][88].__vftable; /*0x141096934*/
            v75 = RakNet::AddressOrGUID::AddressOrGUID( /*0x141096947*/
                    this: (RakNet::AddressOrGUID *)&bitStream,
                    input: &this->remotePlayerRakNetAddress);
            if ( ((unsigned __int8 (__fastcall *)(Luau::InternalErrorReporter *, RakNet::AddressOrGUID *))v74)( /*0x141096956*/
                   a1: v73,
                   a2: v75) != 0 )
            {
              ++this->joinRxStats.totalBlobRxDuringJoin; /*0x141096958*/
              this->joinRxStats.totalBlobBytesRxDuringJoin += packet->length; /*0x141096964*/
            }
          }
          if ( this->firstDataPacketArriveTimeAfterJoinRequestInMS == 0 ) /*0x141096975*/
          {
            this->firstDataPacketArriveTimeAfterJoinRequestInMS = RakNet::GetTimeMS(); /*0x14109697c*/
            this->firstDataPacketArriveCycle = RBX::TaskScheduler::cycle(); /*0x141096989*/
          }
          v8 = RBX::Network::Replicator::OnReceive(this, packet); /*0x14109699f*/
          goto LABEL_168; /*0x1410969a1*/
        case 0x8Eu:
          v11 = RBX::Network::RakNetAddressToString( /*0x141095997*/
                  result: &msg,
                  raknetAddress: &packet->systemAddress,
                  writePort: true,
                  portDelineator: 124);
          __wind /*0xf1c00000000002dc*/
          {
            if ( v11->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410959a2*/
              v11 = (std::string *)v11->_Mypair._Myval2._Bx._Ptr; /*0x1410959a4*/
            RBX::format( /*0x1410959b5*/
              result: (RBX::Graphics::ProfilerAdorn::Item *)&mismatchString,
              fmt: "Protocol mismatch from %s",
              v11->_Mypair._Myval2._Bx._Buf);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&msg); /*0xf1c00000000002ec*/
          }
          __wind /*0xf1c00000000002f4*/
          {
            if ( msg._Mypair._Myval2._Myres >= 0x10 ) /*0x1410959c4*/
            {
              v12 = msg._Mypair._Myval2._Bx._Ptr; /*0x1410959c9*/
              if ( msg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410959d8*/
              {
                v12 = *((char **)msg._Mypair._Myval2._Bx._Ptr - 1); /*0x1410959de*/
                if ( (unsigned __int64)(msg._Mypair._Myval2._Bx._Ptr - v12 - 8) > 0x1F ) /*0x1410959ed*/
                  _invalid_parameter_noinfo_noreturn(); /*0x1410959ef*/
              }
              operator delete(ptr: v12); /*0x1410959f6*/
            }
            msg._Mypair._Myval2._Mysize = 0; /*0x1410959fe*/
            msg._Mypair._Myval2._Myres = 15; /*0x141095a03*/
            msg._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141095a0c*/
            p_mismatchString = &mismatchString; /*0x141095a11*/
            if ( mismatchString._Mypair._Myval2._Myres >= 0x10 ) /*0x141095a1a*/
              p_mismatchString = (std::string *)mismatchString._Mypair._Myval2._Bx._Ptr; /*0x141095a1a*/
            RBX::StandardOut::print( /*0x141095a27*/
              type: MESSAGE_SENSITIVE,
              message: p_mismatchString->_Mypair._Myval2._Bx._Buf,
              originGameStateType: NumStudioGameStateTypes);
            if ( FLog::Network != 0 ) /*0x141095a35*/
            {
              v14 = &mismatchString; /*0x141095a37*/
              if ( mismatchString._Mypair._Myval2._Myres >= 0x10 ) /*0x141095a40*/
                v14 = (std::string *)mismatchString._Mypair._Myval2._Bx._Ptr; /*0x141095a40*/
              FLog::FastLogS( /*0x141095a4c*/
                level: FLog::Network,
                message: "[FLog::Network] Protocol mismatch %s",
                sarg: v14->_Mypair._Myval2._Bx._Buf);
            }
            v15 = RBX::Reflection::DescribedBase::fastDynamicCast<RBX::Network::Client>(this: this->parent); /*0x141095a5b*/
            t = (__int64)&logGuid; /*0x141095a63*/
            logGuid._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141095a6a*/
            logGuid._Mypair._Myval2._Mysize = 0; /*0x141095a6f*/
            logGuid._Mypair._Myval2._Myres = 15; /*0x141095a74*/
            std::string::assign(this: &logGuid, _Ptr: "Network protocol mismatch. Please upgrade.", _Count: 0x2Au); /*0x141095a8e*/
            __wind /*0xf1c00000000002d0*/
            {
              v16 = *packet->data; /*0x141095a98*/
              v17 = RBX::Network::RakNetAddressToString( /*0x141095aa8*/
                      result: (std::string *)&bitStream,
                      raknetAddress: &packet->systemAddress,
                      writePort: true,
                      portDelineator: 124);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)t); /*0xf1c00000000002c8*/
            }
            rbx::signal<void (std::string,int,std::string)>::operator()( /*0x141095ac0*/
              this: &v15->connectionFailedSignal,
              <args_0>: v17,
              <args_1>: v16,
              <args_2>: &logGuid);
            RBX::Network::Replicator::requestDisconnect(this, reason: 259); /*0x141095acd*/
            RakNet::SystemAddress::ToStringN( /*0x141095ae9*/
              this: &packet->systemAddress,
              writePort: true,
              dest: addressBuffer,
              size: 1025,
              portDelineator: 124);
            RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x141095b0f*/
              this: v15,
              metric: "ProtocolMismatch",
              connectionFailed: true,
              serverAddress: addressBuffer,
              state: ConnectionState_Failed,
              takeLock: true);
            std::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>(this: (std::unordered_set<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<std::string,std::string > > > *)&data); /*0x141095b18*/
            __wind /*0xf1c00000000002a0*/
            {
              msg._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141095b1e*/
              msg._Mypair._Myval2._Mysize = 0; /*0x141095b23*/
              msg._Mypair._Myval2._Myres = 15; /*0x141095b28*/
              v18 = operator new(size: 0x20u); /*0x141095b3b*/
              msg._Mypair._Myval2._Mysize = 21; /*0x141095b40*/
              msg._Mypair._Myval2._Myres = 31; /*0x141095b49*/
              qmemcpy(v18, "gameJoinFailureReaso", 20); /*0x141095b59*/
              v18[10] = (unsigned __int8)aGamejoinfailur[20]; /*0x141095b6c*/
              msg._Mypair._Myval2._Bx._Ptr = (char *)v18; /*0x141095b73*/
              __wind /*0xf1c0000000000294*/
              {
                v19 = std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Try_emplace<std::string,>( /*0x141095b85*/
                        this: (std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::string > >,0> > *)&data,
                        result: (std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *)&err,
                        _Keyval_arg: &msg);
                std::string::assign(this: &v19->first->_Myval.second, _Ptr: "ProtocolMistmatch", _Count: 0x11u); /*0x141095b9e*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&msg); /*0xf1c000000000028c*/
              }
              if ( msg._Mypair._Myval2._Myres >= 0x10 ) /*0x141095bad*/
              {
                v20 = msg._Mypair._Myval2._Bx._Ptr; /*0x141095bb2*/
                if ( msg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141095bc1*/
                {
                  v20 = *((char **)msg._Mypair._Myval2._Bx._Ptr - 1); /*0x141095bc7*/
                  if ( (unsigned __int64)(msg._Mypair._Myval2._Bx._Ptr - v20 - 8) > 0x1F ) /*0x141095bd6*/
                    _invalid_parameter_noinfo_noreturn(); /*0x141095bd8*/
                }
                operator delete(ptr: v20); /*0x141095bdf*/
              }
              t = (__int64)&decompressedBts; /*0x141095beb*/
              v21 = std::unordered_map<std::string,std::string>::unordered_map<std::string,std::string>( /*0x141095c02*/
                      this: (std::unordered_map<std::string,std::string> *)&decompressedBts,
                      _Right: (const std::unordered_map<std::string,std::string> *)&data);
              __wind /*0xf1c000000000027c*/
              {
                msg._Mypair._Myval2._Myres = 15; /*0x141095c11*/
                msg._Mypair._Myval2._Mysize = 15; /*0x141095c1a*/
                qmemcpy(&msg, "GameJoinFailur", 14); /*0x141095c2b*/
                *(_WORD *)&msg._Mypair._Myval2._Bx._Alias[14] = (unsigned __int8)aGamejoinfailur_0[14]; /*0x141095c4e*/
                t = (__int64)&logGuid; /*0x141095c5c*/
                logGuid._Mypair._Myval2._Myres = 15; /*0x141095c68*/
                logGuid._Mypair._Myval2._Mysize = 6; /*0x141095c70*/
                *(_DWORD *)logGuid._Mypair._Myval2._Bx._Buf = *(_DWORD *)"report"; /*0x141095c7f*/
                *(_DWORD *)&logGuid._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"rt"; /*0x141095c8a*/
                logPath.m_pathname._Mypair._Myval2._Myres = 15; /*0x141095c98*/
                logPath.m_pathname._Mypair._Myval2._Mysize = 6; /*0x141095ca0*/
                *(_DWORD *)logPath.m_pathname._Mypair._Myval2._Bx._Buf = *(_DWORD *)"client"; /*0x141095cae*/
                *(_DWORD *)&logPath.m_pathname._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"nt"; /*0x141095cb8*/
              }
              __unwind
              {
                std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>((void *)t); /*0xf1c0000000000274*/
              }
              RBX::Analytics::EventIngest::setRBXEvent( /*0x141095cce*/
                target: (std::string *)&logPath,
                eventContext: &logGuid,
                eventName: &msg,
                additionalArgs: v21);
              Myres = (void *)data._Mypair._Myval2._Myres; /*0x141095cd8*/
              if ( (unsigned __int64)(8 * ((__int64)(v86 - data._Mypair._Myval2._Myres) >> 3)) >= 0x1000 ) /*0x141095cf5*/
              {
                Myres = *(void **)(data._Mypair._Myval2._Myres - 8); /*0x141095cfb*/
                if ( data._Mypair._Myval2._Myres - (unsigned __int64)Myres - 8 > 0x1F ) /*0x141095d0a*/
                  _invalid_parameter_noinfo_noreturn(); /*0x141095d0c*/
              }
              operator delete(ptr: Myres); /*0x141095d13*/
              data._Mypair._Myval2._Myres = 0; /*0x141095d18*/
              v86 = 0; /*0x141095d1f*/
              std::list<std::pair<std::string const,std::string>>::~list<std::pair<std::string const,std::string>>(this: (std::list<std::pair<std::string,std::string >> *)&data._Mypair._Myval2._Bx._Alias[8]); /*0x141095d28*/
              if ( mismatchString._Mypair._Myval2._Myres >= 0x10 ) /*0x141095d36*/
              {
                v23 = mismatchString._Mypair._Myval2._Bx._Ptr; /*0x141095d3b*/
                if ( mismatchString._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141095d49*/
                {
                  v23 = *((char **)mismatchString._Mypair._Myval2._Bx._Ptr - 1); /*0x141095d4f*/
                  if ( (unsigned __int64)(mismatchString._Mypair._Myval2._Bx._Ptr - v23 - 8) > 0x1F ) /*0x141095d5e*/
                    _invalid_parameter_noinfo_noreturn(); /*0x141095d60*/
                }
                operator delete(ptr: v23); /*0x141095d67*/
              }
              v8 = RR_CONTINUE_PROCESSING; /*0x141095d6c*/
            }
            __unwind
            {
              std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &data); /*0xf1c00000000002b0*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&mismatchString); /*0xf1c00000000002bc*/
          }
          goto LABEL_168; /*0xf1c00000000002b8*/
        case 0x92u:
          RBX::Network::NetworkStream::NetworkStream( /*0x141095d84*/
            this: &decompressedBts,
            _data: v7,
            lengthInBytes: packet->length,
            copyData: false);
          __eh34_enter_wind_state(1, 15); /*0xf1c0000000000268*/
          RBX::Network::NetworkStream::IgnoreBytes(this: &decompressedBts, numberOfBytes: 1u); /*0x141095d98*/
          if ( RBX::Network::NetworkStream::readBool(this: &decompressedBts) ) /*0x141095da4*/
          {
            RBX::StandardOut::printf( /*0x141095db6*/
              type: MESSAGE_INFO,
              format: "Waiting for server to authenticate the placeID before spawning...");
            v24 = (RBX::Network::Item *)operator new(size: 0x38u); /*0x141095dbe*/
            v25 = v24; /*0x141095dc3*/
            t = (__int64)v24; /*0x141095dc6*/
            __wind /*0xf1c000000000025c*/
            {
              if ( v24 != nullptr ) /*0x141095dd3*/
              {
                RBX::Network::Item::Item(this: v24, replicator: this); /*0x141095ddb*/
                v25->__vftable = (RBX::Network::Item_vtbl *)RBX::Network::ClientReplicator::RequestCharacterItem::`vftable'; /*0x141095de7*/
              }
              else
              {
                v25 = nullptr; /*0x141095dec*/
              }
            }
            __unwind
            {
              operator delete(ptr: (void *)t); /*0x1431ebcb5*/
            }
            RBX::Network::ItemQueue::push_back(this: &this->pendingItems, item: v25); /*0x141095dfa*/
            __eh34_enter_wind_state(15, 18); /*0xf1c00000000001c8*/
          }
          else
          {
            RBX::StandardOut::printf(type: MESSAGE_ERROR, format: "Place ID verification failed."); /*0x141095e10*/
            v26 = RBX::Reflection::DescribedBase::fastDynamicCast<RBX::Network::Client>(this: this->parent); /*0x141095e1f*/
            t = (__int64)&msg; /*0x141095e27*/
            msg._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141095e31*/
            msg._Mypair._Myval2._Mysize = 0; /*0x141095e36*/
            msg._Mypair._Myval2._Myres = 15; /*0x141095e3b*/
            std::string::assign(this: &msg, _Ptr: "Illegal teleport destination.", _Count: 0x1Du); /*0x141095e54*/
            __wind /*0xf1c0000000000244*/
            {
              v27 = *packet->data; /*0x141095e5e*/
              v28 = RBX::Network::RakNetAddressToString( /*0x141095e6e*/
                      result: (std::string *)&bitStream,
                      raknetAddress: &packet->systemAddress,
                      writePort: true,
                      portDelineator: 124);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)t); /*0xf1c000000000023c*/
            }
            rbx::signal<void (std::string,int,std::string)>::operator()( /*0x141095e86*/
              this: &v26->connectionFailedSignal,
              <args_0>: v28,
              <args_1>: v27,
              <args_2>: &msg);
            RBX::Network::Replicator::requestDisconnect(this, reason: 263); /*0x141095e93*/
            RakNet::SystemAddress::ToStringN( /*0x141095eaf*/
              this: &packet->systemAddress,
              writePort: true,
              dest: addressBuffer,
              size: 1025,
              portDelineator: 124);
            RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x141095ed5*/
              this: v26,
              metric: "PlaceIdFailedVerification",
              connectionFailed: true,
              serverAddress: addressBuffer,
              state: ConnectionState_Failed,
              takeLock: true);
            std::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>(this: &v87); /*0x141095ede*/
            __eh34_enter_wind_state(15, 18); /*0xf1c0000000000230*/
            msg._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141095ee4*/
            msg._Mypair._Myval2._Mysize = 0; /*0x141095ee9*/
            msg._Mypair._Myval2._Myres = 15; /*0x141095eee*/
            v29 = (char *)operator new(size: 0x20u); /*0x141095f00*/
            msg._Mypair._Myval2._Mysize = 21; /*0x141095f05*/
            msg._Mypair._Myval2._Myres = 31; /*0x141095f0e*/
            strcpy(v29, "gameJoinFailureReason"); /*0x141095f1e*/
            msg._Mypair._Myval2._Bx._Ptr = v29; /*0x141095f38*/
            __wind /*0xf1c0000000000224*/
            {
              v30 = std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Try_emplace<std::string,>( /*0x141095f4a*/
                      this: (std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,std::string > >,0> > *)&v87,
                      result: (std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *)&err,
                      _Keyval_arg: &msg);
              std::string::assign(this: &v30->first->_Myval.second, _Ptr: "PlaceIdFailedVerification", _Count: 0x19u); /*0x141095f61*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&msg); /*0xf1c000000000021c*/
            }
            if ( msg._Mypair._Myval2._Myres >= 0x10 ) /*0x141095f70*/
            {
              v31 = msg._Mypair._Myval2._Bx._Ptr; /*0x141095f75*/
              if ( msg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141095f84*/
              {
                v31 = *((char **)msg._Mypair._Myval2._Bx._Ptr - 1); /*0x141095f8a*/
                if ( (unsigned __int64)(msg._Mypair._Myval2._Bx._Ptr - v31 - 8) > 0x1F ) /*0x141095f99*/
                  _invalid_parameter_noinfo_noreturn(); /*0x141095f9b*/
              }
              operator delete(ptr: v31); /*0x141095fa2*/
            }
            t = (__int64)fileName; /*0x141095fae*/
            v32 = std::unordered_map<std::string,std::string>::unordered_map<std::string,std::string>( /*0x141095fc5*/
                    this: (std::unordered_map<std::string,std::string> *)fileName,
                    _Right: (const std::unordered_map<std::string,std::string> *)&v87);
            __wind /*0xf1c000000000020c*/
            {
              p_msg = (boost::filesystem::file_status)&msg; /*0x141095fcd*/
              msg._Mypair._Myval2._Myres = 15; /*0x141095fd4*/
              msg._Mypair._Myval2._Mysize = 15; /*0x141095fdd*/
              qmemcpy(&msg, "GameJoinFailur", 14); /*0x141095fee*/
              *(_WORD *)&msg._Mypair._Myval2._Bx._Alias[14] = (unsigned __int8)aGamejoinfailur_0[14]; /*0x141096011*/
              v90 = (RBX::Graphics::ProfilerAdorn::Item *)&mismatchString; /*0x14109601e*/
              mismatchString._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141096025*/
              mismatchString._Mypair._Myval2._Mysize = 0; /*0x141096029*/
              mismatchString._Mypair._Myval2._Myres = 15; /*0x14109602d*/
              __wind /*0xf1c0000000000200*/
              {
                std::string::assign(this: &mismatchString, _Ptr: "report", _Count: 6u); /*0x141096046*/
                __wind /*0xf1c00000000001d0*/
                {
                  logGuid._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109604c*/
                  logGuid._Mypair._Myval2._Mysize = 0; /*0x141096051*/
                  logGuid._Mypair._Myval2._Myres = 15; /*0x141096056*/
                  std::string::assign(this: &logGuid, _Ptr: "client", _Count: 6u); /*0x141096070*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: v90); /*0xf1c00000000001e0*/
                }
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: *(RBX::Graphics::ProfilerAdorn::Item **)&p_msg); /*0xf1c00000000001ec*/
              }
            }
            __unwind
            {
              std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>((void *)t); /*0xf1c00000000001f8*/
            }
            RBX::Analytics::EventIngest::setRBXEvent( /*0x141096087*/
              target: &logGuid,
              eventContext: &mismatchString,
              eventName: &msg,
              additionalArgs: v32);
            std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&v87._Vec); /*0x141096091*/
            std::list<std::pair<std::string const,std::string>>::~list<std::pair<std::string const,std::string>>(this: &v87._List); /*0x14109609a*/
          }
          RBX::Network::NetworkStream::~NetworkStream(this: &decompressedBts); /*0x1410960a7*/
          v8 = RR_STOP_PROCESSING_AND_DEALLOCATE; /*0x1410960ac*/
          if ( __eh34_unwind(18) ) /*0xf1c000000000035c*/
          {
            std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &v87); /*0xf1c0000000000360*/
            __eh34_continue_unwinding(18, 15); /*0xf1c0000000000364*/
          }
          __eh34_exit_wind_state(18, 15); /*0xf1c0000000000368*/
          goto LABEL_286; /*0xf1c000000000036c*/
        case 0x93u:
          RBX::Network::NetworkStream::NetworkStream( /*0x14109590c*/
            this: &bitStream,
            _data: v7,
            lengthInBytes: packet->length,
            copyData: false);
          __wind /*0xf1c000000000030c*/
          {
            RBX::Network::NetworkStream::IgnoreBytes(this: &bitStream, numberOfBytes: 1u); /*0x141095918*/
            RBX::Network::NetworkStream::IgnoreBytes(this: &bitStream, numberOfBytes: 1u); /*0x141095923*/
            if ( bitStream.readOffset < bitStream.numberOfBytesUsed ) /*0x14109592e*/
              this->deserializeSFFlags(this, a2: &bitStream); /*0x14109593b*/
          }
          __unwind
          {
            RBX::Network::NetworkStream::~NetworkStream(this: &bitStream); /*0xf1c0000000000304*/
          }
          Myfirst = bitStream.dataVector._Mypair._Myval2._Myfirst; /*0x141095942*/
          if ( bitStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x141095949*/
          {
            if ( (unsigned __int8 *)(bitStream.dataVector._Mypair._Myval2._Myend /*0x141095960*/
                                   - bitStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 )
            {
              Myfirst = *((unsigned __int8 **)bitStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x141095966*/
              if ( (unsigned __int64)(bitStream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x141095975*/
                _invalid_parameter_noinfo_noreturn(); /*0x141095977*/
            }
            operator delete(ptr: Myfirst); /*0x14109597e*/
          }
          goto LABEL_168; /*0x141095983*/
        case 0x98u:
          RBX::Network::NetworkStream::NetworkStream( /*0x1410960c2*/
            this: &decompressedBts,
            _data: v7,
            lengthInBytes: packet->length,
            copyData: false);
          __eh34_enter_wind_state(1, 15); /*0xf1c00000000001c0*/
          RBX::Network::NetworkStream::IgnoreBytes(this: &decompressedBts, numberOfBytes: 1u); /*0x1410960d4*/
          PayloadLimit = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1410960dc*/
          RBX::Network::NetworkStream::readString(this: &decompressedBts, result: &msg, maxStringReadSize: PayloadLimit); /*0x1410960f0*/
          __wind
          {
            if ( FLog::Player != 0 )
            {
              v34 = &msg; /*0x141096101*/
              if ( msg._Mypair._Myval2._Myres >= 0x10 ) /*0x14109610c*/
                v34 = (std::string *)msg._Mypair._Myval2._Bx._Ptr; /*0x14109610c*/
              FLog::FastLog(level: FLog::Player, message: "[FLog::Player] Server Kick Message: %s", arg0: v34);
            }
            v35 = &msg; /*0x14109611e*/
            if ( msg._Mypair._Myval2._Myres >= 0x10 ) /*0x141096129*/
              v35 = (std::string *)msg._Mypair._Myval2._Bx._Ptr; /*0x141096129*/
            RBX::StandardOut::printf(
              type: MESSAGE_ERROR,
              format: "Server Kick Message: %s",
              v35->_Mypair._Myval2._Bx._Buf);
            v36 = this->findTargetPlayer(this); /*0x141096147*/
            if ( v36 != nullptr ) /*0x141096150*/
            {
              p_setShutdownMessageSignal = &v36->setShutdownMessageSignal; /*0x141096152*/
              v38 = std::string::string( /*0x141096162*/
                      this: (rtc::webrtc_checks_impl::ToStringVal *)&bitStream,
                      __that: (const rtc::webrtc_checks_impl::ToStringVal *)&msg);
              rbx::signal<void (std::string)>::operator()(this: p_setShutdownMessageSignal, <args_0>: &v38->val); /*0x14109616d*/
            }
            else
            {
              ServiceProvider = (RBX::ServiceProvider *)RBX::ServiceProvider::findServiceProvider(context: this); /*0x14109617f*/
              if ( ServiceProvider != nullptr ) /*0x141096185*/
              {
                boost::call_once( /*0x141096199*/
                  flag: &`RBX::ServiceProvider::getClassIndex<RBX::GuiService>'::`2'::flag,
                  f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::GuiService>);
                v40 = RBX::ServiceProvider::doGetClassIndex<RBX::GuiService>(); /*0x14109619e*/
                v42 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt( /*0x1410961ae*/
                                                                                           this: ServiceProvider,
                                                                                           index: v40);
                if ( v42->_Ptr == nullptr ) /*0x1410961b5*/
                {
                  v43 = RBX::Reflection::Class_getNamePtr<RBX::GuiService>(this: v41); /*0x1410961b7*/
                  ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName(this: ServiceProvider, result: (std::shared_ptr<RBX::Instance> *)&err, className: v43); /*0x1410961c6*/
                  std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v42, _Right: ServiceByClassName); /*0x1410961d1*/
                  if ( err.m_cat != nullptr ) /*0x1410961dd*/
                    std::_Ref_count_base::_Decref(this: (std::_Ref_count_base *)err.m_cat); /*0x1410961df*/
                }
                v45 = (RBX::GuiService *)v42->_Ptr; /*0x1410961e4*/
                if ( v42->_Ptr != nullptr ) /*0x1410961ea*/
                {
                  v46 = std::string::string( /*0x1410961f5*/
                          this: (rtc::webrtc_checks_impl::ToStringVal *)&bitStream,
                          __that: (const rtc::webrtc_checks_impl::ToStringVal *)&msg);
                  RBX::GuiService::setErrorMessage(this: v45, newErrorMessage: &v46->val, errorCode: 267); /*0x141096206*/
                }
              }
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&msg); /*0xf1c00000000001ac*/
          }
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&msg); /*0x141096211*/
          RBX::Network::NetworkStream::~NetworkStream(this: &decompressedBts); /*0x14109621e*/
          v8 = RR_STOP_PROCESSING_AND_DEALLOCATE; /*0x141096226*/
          if ( __eh34_unwind(15) ) /*0xf1c0000000000348*/
          {
            RBX::Network::NetworkStream::~NetworkStream(this: &decompressedBts); /*0xf1c000000000034c*/
            __eh34_continue_unwinding(15, 1); /*0xf1c0000000000350*/
          }
LABEL_286:
          __eh34_exit_wind_state(15, 1); /*0xf1c0000000000354*/
          goto LABEL_168; /*0xf1c0000000000358*/
        case 0x9Au:
          if ( !this->isProfilingRequested ) /*0x141096237*/
          {
            v8 = RR_STOP_PROCESSING_AND_DEALLOCATE; /*0x14109623c*/
            goto LABEL_168; /*0x14109623f*/
          }
          this->isProfilingRequested = false; /*0x141096244*/
          RBX::Network::NetworkStream::NetworkStream( /*0x14109625c*/
            this: (RBX::Network::NetworkStream *)&v87,
            _data: packet->data,
            lengthInBytes: packet->length,
            copyData: false);
          __eh34_enter_wind_state(1, 27); /*0xf1c00000000001a0*/
          RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)&v87, numberOfBytes: 1u); /*0x14109626d*/
          RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)&v87); /*0x141096276*/
          Int32 = RBX::Network::NetworkStream::readInt32(this: (RBX::Network::NetworkStream *)&v87); /*0x141096284*/
          RBX::Network::NetworkStream::NetworkStream(this: &decompressedBts); /*0x14109628e*/
          __wind /*0xf1c0000000000194*/
          {
            RBX::Network::Replicator::decompressBitStream( /*0x14109629f*/
              inCompressedBitStream: (RBX::Network::NetworkStream *)&v87,
              outUncompressedBitStream: &decompressedBts);
            data._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410962a7*/
            data._Mypair._Myval2._Mysize = 0; /*0x1410962ab*/
            data._Mypair._Myval2._Myres = 15; /*0x1410962af*/
            __wind /*0xf1c0000000000164*/
            {
              v48 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1410962be*/
              RBX::Network::deserializeString(value: &data, stream: &decompressedBts, maxStringReadSize: v48); /*0x1410962d1*/
              if ( Int32 != data._Mypair._Myval2._Mysize ) /*0x1410962da*/
              {
LABEL_127:
                if ( data._Mypair._Myval2._Myres < 0x10 ) /*0x1410966bc*/
                {
LABEL_151:
                  data._Mypair._Myval2._Mysize = 0; /*0x141096827*/
                  data._Mypair._Myval2._Myres = 15; /*0x14109682b*/
                  data._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141096833*/
                  RBX::Network::NetworkStream::~NetworkStream(this: &decompressedBts); /*0x14109683e*/
                  RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v87); /*0x141096848*/
                  v8 = RR_STOP_PROCESSING_AND_DEALLOCATE; /*0x14109684d*/
                  goto LABEL_216; /*0x141096850*/
                }
                v62 = data._Mypair._Myval2._Bx._Ptr; /*0x1410966c5*/
                if ( data._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410966d3*/
                {
                  v62 = *((char **)data._Mypair._Myval2._Bx._Ptr - 1); /*0x1410966dd*/
                  if ( (unsigned __int64)(data._Mypair._Myval2._Bx._Ptr - v62 - 8) > 0x1F ) /*0x1410966ec*/
                    _invalid_parameter_noinfo_noreturn(); /*0x1410966f2*/
                }
LABEL_150:
                operator delete(ptr: v62); /*0x141096822*/
                goto LABEL_151; /*0x141096822*/
              }
              logPath.m_pathname._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410962e0*/
              *(__m128i *)&logPath.m_pathname._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x1410962ec*/
              __eh34_enter_wind_state(29, 31); /*0xf1c000000000015c*/
              if ( DFFlag::ReplicatorClientRemoteProfilerDumpRefactor.value ) /*0x1410962fd*/
              {
                if ( RBX::Network::ClientReplicator::stringToHtmlFileDumpToLogDirHelper(this, &logPath, string: &data) ) /*0x14109630a*/
                {
LABEL_140:
                  v67 = boost::filesystem::path::string( /*0x141096771*/
                          this: &logPath,
                          result: (RBX::Graphics::ProfilerAdorn::Item *)&bitStream);
                  RBX::Reflection::EventDesc<RBX::Network::ClientReplicator,void (bool,std::string),rbx::signal<void (bool,std::string)>,rbx::signal<void (bool,std::string)> RBX::Network::ClientReplicator::*>::fireEvent( /*0x14109678e*/
                    this: &RBX::Network::event_rccProfilerDataCompleteSignal,
                    instance: this,
                    <args_0>: true,
                    <args_1>: &v67->text);
                  if ( __eh34_unwind(31) ) /*0xf1c0000000000084*/
                    goto unwind_state_31; /*0xf1c0000000000084*/
                  __eh34_exit_wind_state(31, 29); /*0xf1c0000000000090*/
                  if ( logPath.m_pathname._Mypair._Myval2._Myres >= 8 ) /*0x14109679c*/
                  {
                    v68 = logPath.m_pathname._Mypair._Myval2._Bx._Ptr; /*0x1410967a6*/
                    if ( 2 * logPath.m_pathname._Mypair._Myval2._Myres + 2 >= 0x1000 ) /*0x1410967b4*/
                    {
                      v68 = *((wchar_t **)logPath.m_pathname._Mypair._Myval2._Bx._Ptr - 1); /*0x1410967ba*/
                      if ( (unsigned __int64)((char *)logPath.m_pathname._Mypair._Myval2._Bx._Ptr - (char *)v68 - 8) > 0x1F ) /*0x1410967c9*/
                        _invalid_parameter_noinfo_noreturn(); /*0x1410967cb*/
                    }
                    operator delete(ptr: v68); /*0x1410967d2*/
                  }
                  *(__m128i *)&logPath.m_pathname._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x1410967df*/
                  logPath.m_pathname._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410967e4*/
                  if ( data._Mypair._Myval2._Myres < 0x10 ) /*0x1410967f1*/
                    goto LABEL_151; /*0x1410967f1*/
                  v62 = data._Mypair._Myval2._Bx._Ptr; /*0x1410967f6*/
                  if ( data._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141096804*/
                  {
                    v62 = *((char **)data._Mypair._Myval2._Bx._Ptr - 1); /*0x14109680a*/
                    if ( (unsigned __int64)(data._Mypair._Myval2._Bx._Ptr - v62 - 8) > 0x1F ) /*0x141096819*/
                      _invalid_parameter_noinfo_noreturn(); /*0x14109681b*/
                  }
                  goto LABEL_150; /*0x141096819*/
                }
                goto LABEL_121; /*0x141096311*/
              }
              t = _time64(Time: nullptr); /*0x141096324*/
              memset(fileName, 0, sizeof(fileName)); /*0x14109632e*/
              v49 = _localtime64(Time: &t); /*0x141096351*/
              strftime(Buffer: fileName, SizeInBytes: 0x40u, Format: "microprofile_%Y%m%d-%H%M%S.html", Tm: v49); /*0x14109636d*/
              logGuid._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141096373*/
              logGuid._Mypair._Myval2._Mysize = 0; /*0x141096378*/
              logGuid._Mypair._Myval2._Myres = 15; /*0x14109637d*/
              __eh34_enter_wind_state(31, 33); /*0xf1c0000000000154*/
              RBX::getRBXLogGUID(result: &logGuid); /*0x14109638f*/
              UserDirectory = RBX::FileSystem::getUserDirectory( /*0x1410963a5*/
                                result: (boost::filesystem::path *)&msg,
                                create: true,
                                dir: DirAppData,
                                subDirectory: (const char *)&MainCrashLogManager::`vftable'[1]);
              __wind /*0xf1c0000000000148*/
              {
                v51 = boost::filesystem::path::string( /*0x1410963b2*/
                        this: UserDirectory,
                        result: (RBX::Graphics::ProfilerAdorn::Item *)&bitStream);
                __wind /*0xf1c000000000013c*/
                {
                  boost::filesystem::path::operator=<std::string>(this: &logPath, source: &v51->text); /*0x1410963bf*/
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&bitStream); /*0xf1c0000000000134*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&bitStream); /*0x1410963c9*/
                boost::filesystem::path::~path(this: (std::pair<std::wstring const ,char const *> *)&msg); /*0x1410963d4*/
              }
              __unwind
              {
                boost::filesystem::path::~path(this: (std::pair<std::wstring const ,char const *> *)&msg); /*0xf1c0000000000128*/
              }
              if ( DFFlag::UseVerboseLogPrefixEverywhere.value ) /*0x1410963e0*/
              {
                RBXLogPrefix = RBX::LogGuid::getRBXLogPrefix(); /*0x1410963e2*/
                v53 = RBX::format( /*0x1410963fc*/
                        result: (RBX::Graphics::ProfilerAdorn::Item *)&bitStream,
                        fmt: "%s_%s",
                        RBXLogPrefix,
                        fileName);
                __eh34_enter_wind_state(33, 36); /*0xf1c000000000011c*/
                boost::filesystem::path::operator/=<std::string>(this: &logPath, source: &v53->text); /*0x141096409*/
                if ( __eh34_unwind(36) ) /*0xf1c0000000000110*/
                  goto unwind_state_36; /*0xf1c0000000000110*/
                __eh34_exit_wind_state(36, 33); /*0xf1c0000000000114*/
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&bitStream); /*0x141096413*/
              }
              else
              {
                if ( 0x7FFFFFFFFFFFFFFFLL - logGuid._Mypair._Myval2._Mysize < 4 ) /*0x141096433*/
                  std::_Xlen_string(); /*0x1410969fb*/
                p_logGuid = &logGuid; /*0x141096439*/
                if ( logGuid._Mypair._Myval2._Myres >= 0x10 ) /*0x141096443*/
                  p_logGuid = (std::string *)logGuid._Mypair._Myval2._Bx._Ptr; /*0x141096443*/
                std::string::string( /*0x141096473*/
                  this: (std::string *)&bitStream,
                  __formal: (std::_String_constructor_concat_tag)memscopeNetworkReplicator.parent,
                  _Source_of_al: &logGuid,
                  _Left_ptr: "log_",
                  _Left_size: 4u,
                  _Right_ptr: p_logGuid->_Mypair._Myval2._Bx._Buf,
                  _Right_size: logGuid._Mypair._Myval2._Mysize);
                __eh34_enter_wind_state(33, 36); /*0xf1c0000000000108*/
                v55 = std::string::append(this: (std::string *)&bitStream, _Ptr: "_", _Count: 1u); /*0x141096487*/
                msg._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109648c*/
                msg._Mypair._Myval2._Mysize = 0; /*0x141096491*/
                msg._Mypair._Myval2._Myres = 0; /*0x141096496*/
                msg = *v55; /*0x14109649e*/
                v55->_Mypair._Myval2._Mysize = 0; /*0x1410964ac*/
                v55->_Mypair._Myval2._Myres = 15; /*0x1410964b0*/
                v55->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410964b8*/
                __wind /*0xf1c00000000000dc*/
                {
                  v56 = -1; /*0x1410964c2*/
                  do /*0x1410964d8*/
                    ++v56; /*0x1410964d0*/
                  while ( fileName[v56] != 0 ); /*0x1410964d8*/
                  v57 = std::string::append(this: &msg, _Ptr: fileName, _Count: v56); /*0x1410964e6*/
                  mismatchString._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410964eb*/
                  mismatchString._Mypair._Myval2._Mysize = 0; /*0x1410964ef*/
                  mismatchString._Mypair._Myval2._Myres = 0; /*0x1410964f3*/
                  mismatchString = *v57; /*0x1410964fa*/
                  v57->_Mypair._Myval2._Mysize = 0; /*0x141096506*/
                  v57->_Mypair._Myval2._Myres = 15; /*0x14109650a*/
                  v57->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x141096512*/
                  __wind /*0xf1c00000000000d0*/
                  {
                    boost::filesystem::path::operator/=<std::string>(this: &logPath, source: &mismatchString); /*0x14109651d*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&mismatchString); /*0xf1c00000000000c8*/
                  }
                  if ( mismatchString._Mypair._Myval2._Myres >= 0x10 ) /*0x14109652b*/
                  {
                    v58 = mismatchString._Mypair._Myval2._Bx._Ptr; /*0x141096530*/
                    if ( mismatchString._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109653e*/
                    {
                      v58 = *((char **)mismatchString._Mypair._Myval2._Bx._Ptr - 1); /*0x141096544*/
                      if ( (unsigned __int64)(mismatchString._Mypair._Myval2._Bx._Ptr - v58 - 8) > 0x1F ) /*0x141096553*/
                        _invalid_parameter_noinfo_noreturn(); /*0x141096555*/
                    }
                    operator delete(ptr: v58); /*0x14109655c*/
                  }
                  mismatchString._Mypair._Myval2._Mysize = 0; /*0x141096561*/
                  mismatchString._Mypair._Myval2._Myres = 15; /*0x141096565*/
                  mismatchString._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109656d*/
                  if ( msg._Mypair._Myval2._Myres >= 0x10 ) /*0x14109657a*/
                  {
                    v59 = msg._Mypair._Myval2._Bx._Ptr; /*0x14109657f*/
                    if ( msg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109658e*/
                    {
                      v59 = *((char **)msg._Mypair._Myval2._Bx._Ptr - 1); /*0x141096594*/
                      if ( (unsigned __int64)(msg._Mypair._Myval2._Bx._Ptr - v59 - 8) > 0x1F ) /*0x1410965a3*/
                        _invalid_parameter_noinfo_noreturn(); /*0x1410965a5*/
                    }
                    operator delete(ptr: v59); /*0x1410965ac*/
                  }
                  msg._Mypair._Myval2._Mysize = 0; /*0x1410965b1*/
                  msg._Mypair._Myval2._Myres = 15; /*0x1410965b6*/
                  msg._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410965bf*/
                  if ( bitStream.dataVector._Mypair._Myval2._Myfirst >= (unsigned __int8 *)0x10 ) /*0x1410965cc*/
                    std::allocator<RBX::Voxel2::Mesher::Quad>::deallocate( /*0x1410965d9*/
                      this: (std::allocator<signed char> *)&bitStream,
                      _Ptr: (char *const)bitStream.__vftable,
                      _Count: (const unsigned __int64)(bitStream.dataVector._Mypair._Myval2._Myfirst + 1));
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&msg); /*0xf1c00000000000ec*/
                }
                if ( __eh34_unwind(36) ) /*0xf1c00000000000f4*/
                {
unwind_state_36:
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&bitStream); /*0xf1c00000000000f8*/
                  __eh34_continue_unwinding(36, 33); /*0xf1c00000000000fc*/
                }
                __eh34_exit_wind_state(36, 33); /*0xf1c0000000000100*/
              }
              err.m_val = 0; /*0x1410965de*/
              err.m_cat = boost::system::system_category(); /*0x1410965e7*/
              if ( boost::filesystem::detail::status(result: &p_msg, p: &logPath, ec: &err)->m_value <= (unsigned int)file_not_found ) /*0x141096602*/
              {
                v63 = RBX::FileSystem::openFileWrite(path: &logPath); /*0x1410966fd*/
                v64 = v63; /*0x141096702*/
                if ( v63 != nullptr ) /*0x141096708*/
                {
                  p_data = &data; /*0x14109670a*/
                  if ( data._Mypair._Myval2._Myres >= 0x10 ) /*0x141096713*/
                    p_data = (std::string *)data._Mypair._Myval2._Bx._Ptr; /*0x141096713*/
                  fwrite(Buffer: p_data, ElementSize: data._Mypair._Myval2._Mysize, ElementCount: 1u, Stream: v63); /*0x141096722*/
                  fclose(Stream: v64); /*0x14109672b*/
                }
                if ( __eh34_unwind(33) ) /*0xf1c0000000000098*/
                {
unwind_state_33:
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&logGuid); /*0xf1c000000000009c*/
                  __eh34_continue_unwinding(33, 31); /*0xf1c00000000000a0*/
                }
                __eh34_exit_wind_state(33, 31); /*0xf1c00000000000a4*/
                if ( logGuid._Mypair._Myval2._Myres < 0x10 ) /*0x14109673a*/
                  goto LABEL_140; /*0x14109673a*/
                v66 = logGuid._Mypair._Myval2._Bx._Ptr; /*0x14109673f*/
                if ( logGuid._Mypair._Myval2._Myres + 1 < 0x1000 /*0x141096763*/
                  || (v66 = *((char **)logGuid._Mypair._Myval2._Bx._Ptr - 1),
                      (unsigned __int64)(logGuid._Mypair._Myval2._Bx._Ptr - v66 - 8) <= 0x1F) )
                {
                  operator delete(ptr: v66); /*0x14109676c*/
                  goto LABEL_140; /*0x14109676c*/
                }
              }
              else
              {
                this->isProfilingRequested = false; /*0x141096608*/
                if ( __eh34_unwind(33) ) /*0xf1c00000000000b8*/
                  goto unwind_state_33; /*0xf1c00000000000b8*/
                __eh34_exit_wind_state(33, 31); /*0xf1c00000000000bc*/
                if ( logGuid._Mypair._Myval2._Myres < 0x10 ) /*0x141096619*/
                  goto LABEL_120; /*0x141096619*/
                v60 = logGuid._Mypair._Myval2._Bx._Ptr; /*0x14109661e*/
                if ( logGuid._Mypair._Myval2._Myres + 1 < 0x1000 /*0x141096642*/
                  || (v60 = *((char **)logGuid._Mypair._Myval2._Bx._Ptr - 1),
                      (unsigned __int64)(logGuid._Mypair._Myval2._Bx._Ptr - v60 - 8) <= 0x1F) )
                {
                  operator delete(ptr: v60); /*0x141096648*/
LABEL_120:
                  logGuid._Mypair._Myval2._Mysize = 0; /*0x14109664d*/
                  logGuid._Mypair._Myval2._Myres = 15; /*0x141096652*/
                  logGuid._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109665a*/
LABEL_121:
                  if ( logPath.m_pathname._Mypair._Myval2._Myres >= 8 ) /*0x141096667*/
                  {
                    v61 = logPath.m_pathname._Mypair._Myval2._Bx._Ptr; /*0x141096671*/
                    if ( 2 * logPath.m_pathname._Mypair._Myval2._Myres + 2 >= 0x1000 ) /*0x14109667f*/
                    {
                      v61 = *((wchar_t **)logPath.m_pathname._Mypair._Myval2._Bx._Ptr - 1); /*0x141096685*/
                      if ( (unsigned __int64)((char *)logPath.m_pathname._Mypair._Myval2._Bx._Ptr - (char *)v61 - 8) > 0x1F ) /*0x141096694*/
                        _invalid_parameter_noinfo_noreturn(); /*0x141096696*/
                    }
                    operator delete(ptr: v61); /*0x14109669d*/
                  }
                  *(__m128i *)&logPath.m_pathname._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x1410966aa*/
                  logPath.m_pathname._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410966af*/
                  if ( __eh34_unwind(31) ) /*0xf1c00000000000ac*/
                  {
unwind_state_31:
                    boost::filesystem::path::~path(this: (std::pair<std::wstring const ,char const *> *)&logPath); /*0xf1c0000000000088*/
                    __eh34_continue_unwinding(31, 29); /*0xf1c000000000008c*/
                  }
                  __eh34_exit_wind_state(31, 29); /*0xf1c00000000000b0*/
                  goto LABEL_127; /*0xf1c00000000000b4*/
                }
              }
              _invalid_parameter_noinfo_noreturn(); /*0x141096765*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&data); /*0xf1c0000000000174*/
            }
          }
          __unwind
          {
            RBX::Network::NetworkStream::~NetworkStream(this: &decompressedBts); /*0xf1c0000000000180*/
          }
          if ( __eh34_unwind(27) ) /*0xf1c0000000000188*/
            goto unwind_state_27; /*0xf1c0000000000188*/
LABEL_216:
          __eh34_exit_wind_state(27, 1); /*0xf1c000000000018c*/
          goto LABEL_168; /*0xf1c0000000000190*/
        case 0x9Bu:
          RBX::Network::NetworkStream::NetworkStream( /*0x141096860*/
            this: (RBX::Network::NetworkStream *)&v87,
            _data: v7,
            lengthInBytes: packet->length,
            copyData: false);
          __eh34_enter_wind_state(1, 27); /*0xf1c000000000007c*/
          v8 = RR_CONTINUE_PROCESSING; /*0x141096866*/
          RBX::Network::NetworkStream::IgnoreBytes(this: (RBX::Network::NetworkStream *)&v87, numberOfBytes: 1u); /*0x141096871*/
          UInt32 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)&v87); /*0x14109687f*/
          v70 = RBX::Network::NetworkStream::readUInt32(this: (RBX::Network::NetworkStream *)&v87); /*0x14109688a*/
          v71 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x141096890*/
          RBX::Network::NetworkStream::readString( /*0x1410968a0*/
            this: (RBX::Network::NetworkStream *)&v87,
            result: (std::string *)&bitStream,
            maxStringReadSize: v71);
          __wind /*0xf1c0000000000050*/
          {
            if ( this->sessionCrypto._Ptr == nullptr ) /*0x1410968af*/
              RBX::throw_runtime_error(fmt: "Bytecode Auth Check missing or wrong version."); /*0x1410969f5*/
            v72 = RBX::ProtectedString::fromBytecode( /*0x1410968be*/
                    result: (RBX::ProtectedString *)&msg,
                    stringRef: (const std::string *)&bitStream);
            __wind /*0xf1c0000000000044*/
            {
              RBX::ProtectedString::operator=(this: &bytecode, other: v72); /*0x1410968ce*/
            }
            __unwind
            {
              RBX::ProtectedString::~ProtectedString(this: (RBX::Scripting::DebuggerEvalExpression *)&msg); /*0xf1c000000000003c*/
            }
            boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&msg._Mypair._Myval2._Mysize); /*0x1410968d9*/
            boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: (boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)&msg); /*0x1410968e3*/
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&bitStream); /*0x1410968ed*/
            RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v87); /*0x1410968f7*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&bitStream); /*0xf1c0000000000060*/
          }
          if ( __eh34_unwind(27) ) /*0xf1c0000000000068*/
          {
unwind_state_27:
            RBX::Network::NetworkStream::~NetworkStream(this: (RBX::Network::NetworkStream *)&v87); /*0xf1c000000000006c*/
            __eh34_continue_unwinding(27, 1); /*0xf1c0000000000070*/
          }
          __eh34_exit_wind_state(27, 1); /*0xf1c0000000000074*/
          RBX::Network::ClientReplicator::computeAndSendDynLuaResponse(this, key: UInt32, challenge: v70, &bytecode); /*0x14109690b*/
          goto LABEL_168; /*0x141096913*/
        default:
          v8 = RBX::Network::Replicator::OnReceive(this, packet); /*0x1410969ae*/
          goto LABEL_168; /*0xf1c0000000000374*/
      }
    }
    __unwind
    {
      RBX::ProtectedString::~ProtectedString(this: (RBX::Scripting::DebuggerEvalExpression *)&bytecode); /*0xf1c0000000000030*/
    }
LABEL_168:
    boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &bytecode.sharedBytecode.flyweight.h); /*0x1410969b7*/
    boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &bytecode.sharedSource.flyweight.h); /*0x1410969c3*/
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&memscopeNetworkReplicator); /*0xf1c0000000000334*/
  }
  __wind /*0xf1c000000000033c*/
  {
    RBX::Memory::setCurrentCategory(category: v5); /*0x1410969cb*/
    result = (unsigned int)v8; /*0x1410969d1*/
  }
  __unwind
  {
    __std_terminate(a1: v76, a2: &v78); /*0x142f39fa8*/
  }
  return result; /*0x1410969d3*/
}

// Address: 0x141096d90 | Name: ?acceptsStudioClients@ClientReplicator@Network@RBX@@MEBA_NXZ
bool __fastcall RBX::Network::ClientReplicator::acceptsStudioClients(RBX::Network::ClientReplicator *this)
{
  RBX::Instance *parent; // rdi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::ClassRegistrar<RBX::Network::Client,1> *v3; // rax
  bool result; // al

  parent = this->parent; /*0x141096d96*/
  result = parent != nullptr /*0x141096dd8*/
        && (descriptor = parent->descriptor,
            v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(),
            descriptor->index - (unsigned int)v3->desc.index <= v3->desc.descendantCount)
        && (unsigned int)(parent[13].completeness.numLocalReplicatedChildren - 1) <= 1;
  return result; /*0x141096ddb*/
}

// Address: 0x141096df0 | Name: ?addInstanceQuotaStatsAndReset@ClientReplicator@Network@RBX@@QEAAXAEAVPoints@InfluxDb@Analytics@3@@Z
void __fastcall RBX::Network::ClientReplicator::addInstanceQuotaStatsAndReset(
        RBX::Network::ClientReplicator *this,
        RBX::Analytics::InfluxDb::Points *points)
{
  std::_List_node<std::pair<std::string const ,int>,void *> *Myhead; // rdi
  std::_List_node<std::pair<std::string const ,int>,void *> *i; // rbx
  const char *Buf; // rdx

  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141096e22*/
    this: points,
    name: "AvgInstanceQuota",
    value: this->avgRequestCount.averageValue);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141096e38*/
    this: points,
    name: "CountInstanceQuotaChanged",
    value: this->countInstanceQuotaChanged);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141096e4f*/
    this: points,
    name: "AvgMaxRegionDistance",
    value: this->avgMaxRegionDistance.averageValue);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141096e65*/
    this: points,
    name: "CountMaxRegionDistanceChanged",
    value: this->countMaxRegionDistanceChanged);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141096e7c*/
    this: points,
    name: "AvgStreamDataReadTime",
    value: this->avgStreamDataReadTime.averageValue);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141096e93*/
    this: points,
    name: "AvgInstancesPerStreamData",
    value: this->avgInstancesPerStreamData.averageValue);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141096eaa*/
    this: points,
    name: "AvgTerrainDataReadTime",
    value: this->avgTerrainDataReadTime.averageValue);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141096ec1*/
    this: points,
    name: "AvgFractionStreamData",
    value: this->avgFractionStreamData.averageValue);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141096ed8*/
    this: points,
    name: "AvgFractionTerrainData",
    value: this->avgFractionTerrainData.averageValue);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141096eef*/
    this: points,
    name: "AvgInstanceQuotaDiff",
    value: this->avgInstanceQuotaDiff.averageValue);
  RBX::Analytics::InfluxDb::Points::addPoint( /*0x141096f06*/
    this: points,
    name: "AvgIncomingPacketsProcessedPerSec",
    value: this->avgIncomingPacketsProcessedPerSec.averageValue);
  Myhead = this->instanceQuotaSourceCount._List._Mypair._Myval2._Myhead; /*0x141096f0b*/
  for ( i = Myhead->_Next; i != Myhead; i = i->_Next ) /*0x141096f18*/
  {
    Buf = i->_Myval.first._Mypair._Myval2._Bx._Buf; /*0x141096f25*/
    if ( i->_Myval.first._Mypair._Myval2._Myres >= 0x10 ) /*0x141096f2d*/
      Buf = *(const char **)Buf; /*0x141096f2f*/
    RBX::Analytics::InfluxDb::Points::addPoint(this: points, name: Buf, value: i->_Myval.second); /*0x141096f35*/
  }
  std::_Hash<std::_Umap_traits<std::string,enum RBX::LSP::LuauScriptAnalyzerService::ChangeType,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,enum RBX::LSP::LuauScriptAnalyzerService::ChangeType>>,0>>::clear(this: (std::_Hash<std::_Umap_traits<std::string,ScriptingAnalysisScriptItem *,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,ScriptingAnalysisScriptItem *> >,0> > *)&this->instanceQuotaSourceCount); /*0x141096f49*/
  *(_QWORD *)&this->countInstanceQuotaChanged = 0; /*0x141096f5f*/
}

// Address: 0x141096f80 | Name: ?canSendItems@ClientReplicator@Network@RBX@@MEAA_NXZ
_BOOL8 __fastcall RBX::Network::ClientReplicator::canSendItems(RBX::Network::ClientReplicator *this)
{
  return this->receivedGlobals; /*0x141096f87*/
}

// Address: 0x141096f90 | Name: ?canUseProtocolVersion@ClientReplicator@Network@RBX@@UEBA_NH@Z
bool __fastcall RBX::Network::ClientReplicator::canUseProtocolVersion(
        RBX::Network::ClientReplicator *this,
        int protocolVersion)
{
  return protocolVersion <= 36; /*0x141096f96*/
}

// Address: 0x141097040 | Name: ?checkDistributedReceive@ClientReplicator@Network@RBX@@MEAA_NPEAVBasePart@3@@Z
bool __fastcall RBX::Network::ClientReplicator::checkDistributedReceive(
        RBX::Network::ClientReplicator *this,
        RBX::BasePart *part)
{
  const RBX::SystemAddress *NetworkOwner; // rax
  RBX::SystemAddress v5; // [rsp+30h] [rbp+8h] BYREF

  NetworkOwner = RBX::BasePart::getNetworkOwner(this: part, result: &v5); /*0x141097054*/
  return !RBX::SystemAddress::operator==(a: &NetworkOwner->remoteId.peerId, b: &this->clientAddress.remoteId.peerId); /*0x14109706d*/
}

// Address: 0x141097080 | Name: ?completenessHandleParentChange@ClientReplicator@Network@RBX@@MEAAXPEAVInstance@3@00@Z
void __fastcall RBX::Network::ClientReplicator::completenessHandleParentChange(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *child,
        RBX::Instance *oldParent,
        RBX::Instance *newParent)
{
  int v4; // eax
  int v9; // eax
  std::_List_node<std::pair<RBX::Instance const * const,RBX::Guid>,void *> *guid; // rbp
  int v11; // r15d
  std::_List_node<std::pair<RBX::Instance const * const,RBX::Guid>,void *> *first; // rcx
  int v13; // eax
  std::pair<std::_List_node<std::pair<RBX::Instance const * const,RBX::Guid>,void *> *,bool> result[2]; // [rsp+20h] [rbp-28h] BYREF
  __int64 _Keyval; // [rsp+58h] [rbp+10h] BYREF

  v4 = *((_DWORD *)&child->completeness + 2); /*0x141097088*/
  if ( (v4 & 0x40000000) != 0 ) /*0x1410970a3*/
  {
    oldParent = (RBX::Instance *)((__int64 (__fastcall *)(RBX::Network::ClientReplicator *))this->getReplicatedParent)(a1: this); /*0x1410970ae*/
    v4 = *((_DWORD *)&child->completeness + 2); /*0x1410970b1*/
  }
  if ( v4 < 0 || newParent == nullptr ) /*0x1410970be*/
  {
    RBX::Network::MegaReplicator::completenessClientChildRemoved(this: this->megaReplicator, child, oldParent); /*0x1410970cd*/
    if ( newParent == nullptr ) /*0x1410970d5*/
    {
      _Keyval = (__int64)this; /*0x1410970dc*/
      RBX::Instance::visitDescendants__lambda_e259bcea1cb1d4a5d0a8a734d994fa00___(func: (const RBX::Network::ClientReplicator::completenessHandleParentChange::__l11::<lambda_e259bcea1cb1d4a5d0a8a734d994fa00> *)child); /*0x1410970e4*/
    }
  }
  v9 = *((_DWORD *)&child->completeness + 2); /*0x1410970e9*/
  if ( (v9 & 0x20000000) != 0 ) /*0x1410970f8*/
  {
    _Keyval = (__int64)child; /*0x141097101*/
    if ( v9 >= 0 && newParent != nullptr ) /*0x141097111*/
    {
      std::_Hash<std::_Umap_traits<RBX::BasePart *,RBX::Extents,std::_Uhash_compare<RBX::BasePart *,std::hash<RBX::BasePart *>,std::equal_to<RBX::BasePart *>>,std::allocator<std::pair<RBX::BasePart * const,RBX::Extents>>,0>>::find<void>( /*0x141097128*/
        this: (std::_Hash<std::_Umap_traits<__int64,PluginMetadataStore::PluginMetadata,std::_Uhash_compare<__int64,std::hash<__int64>,std::equal_to<__int64> >,std::allocator<std::pair<__int64 const ,PluginMetadataStore::PluginMetadata> >,0> > *)&this->replicatedParentMap,
        (std::_List_const_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,PluginMetadataStore::PluginMetadata> > > > *)result,
        &_Keyval);
      if ( result[0].first == this->replicatedParentMap._List._Mypair._Myval2._Myhead ) /*0x141097139*/
      {
        if ( oldParent != nullptr ) /*0x141097143*/
        {
          guid = (std::_List_node<std::pair<RBX::Instance const * const,RBX::Guid>,void *> *)oldParent->guid; /*0x141097145*/
          result[0].first = guid; /*0x141097149*/
          v11 = HIDWORD(guid); /*0x14109714e*/
        }
        else
        {
          v11 = 0; /*0x141097155*/
          LODWORD(guid) = -1; /*0x141097158*/
        }
        first = std::_Hash<std::_Umap_traits<RBX::Instance const *,RBX::Guid,std::_Uhash_compare<RBX::Instance const *,std::hash<RBX::Instance const *>,std::equal_to<RBX::Instance const *>>,std::allocator<std::pair<RBX::Instance const * const,RBX::Guid>>,0>>::_Try_emplace<RBX::Instance const * const &,>( /*0x141097173*/
                  this: &this->replicatedParentMap,
                  result,
                  _Keyval_arg: (const RBX::Instance *const *)&_Keyval)->first;
        first->_Myval.second.index = v11; /*0x141097176*/
        first->_Myval.second.scope.peerId.peerId = (unsigned int)guid; /*0x14109717f*/
        *(_DWORD *)(_Keyval + 128) |= 0x40000000u; /*0x141097187*/
      }
      else if ( *(_QWORD *)&result[0].first->_Myval.second == *(_QWORD *)&newParent->guid ) /*0x1410971a2*/
      {
        std::_Hash<std::_Umap_traits<RBX::Instance const *,RBX::Guid,std::_Uhash_compare<RBX::Instance const *,std::hash<RBX::Instance const *>,std::equal_to<RBX::Instance const *>>,std::allocator<std::pair<RBX::Instance const * const,RBX::Guid>>,0>>::erase<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Instance const * const,RBX::Guid>>>>,0>( /*0x1410971b6*/
          this: &this->replicatedParentMap,
          (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Instance const * const,RBX::Guid> > > > *)result,
          _Plist: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Instance const * const,RBX::Guid> > > >)result[0].first);
        *(_DWORD *)(_Keyval + 128) &= ~0x40000000u; /*0x1410971c0*/
      }
    }
    else
    {
      RBX::Network::ClientReplicator::resetReplicatedParentDataForInstance(this, instance: child); /*0x1410971d2*/
    }
  }
  v13 = *((_DWORD *)&child->completeness + 2); /*0x1410971d7*/
  if ( v13 < 0 ) /*0x1410971e9*/
  {
    RBX::Network::MegaReplicator::completenessClientChildAdded(this: this->megaReplicator, child, newParent); /*0x1410971f8*/
    v13 = *((_DWORD *)&child->completeness + 2); /*0x1410971fd*/
  }
  *((_DWORD *)&child->completeness + 2) = v13 & 0x7FFFFFFF; /*0x141097207*/
}

// Address: 0x141097220 | Name: ?computeAndSendDynLuaResponse@ClientReplicator@Network@RBX@@QEAAXIIAEAVProtectedString@3@@Z
void __fastcall RBX::Network::ClientReplicator::computeAndSendDynLuaResponse(
        RBX::Network::ClientReplicator *this,
        int key,
        int challenge,
        RBX::ProtectedString *bytecode)
{
  RBX::ServiceProvider *parent; // rdi
  RBX::Instance *v8; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v10; // rax
  unsigned __int64 v11; // rax
  RBX::DescribedCreatable<RBX::ScriptContext,RBX::ServiceInstance> *v12; // rcx
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v13; // rsi
  const RBX::Name *v14; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *Rep; // rbx
  RBX::ScriptContext *Ptr; // r14
  RBX::Reflection::Variant *v18; // rbx
  __int64 v19; // rsi
  __int64 v20; // rcx
  RBX::Reflection::Variant *Myfirst; // rbx
  const RBX::Reflection::Type *type; // rsi
  double *data; // rbx
  int v24; // esi
  std::_Ref_count_base *v25; // rbx
  RBX::Reflection::Variant *v26; // r8
  RBX::Reflection::Variant *Mylast; // rdi
  rbx::placement_any<RBX::Reflection::Variant::Storage> *p_value; // rbx
  RBX::Reflection::Variant *v29; // rax
  Luau::InternalErrorReporter *v30; // rdi
  std::_Func_base<void,char const *>_vtbl *v31; // rbx
  unsigned __int8 *v32; // rcx
  std::_Ref_count_base *v33; // rbx
  RBX::Reflection::Variant *v34; // r8
  RBX::Reflection::Variant *v35; // rdi
  rbx::placement_any<RBX::Reflection::Variant::Storage> *v36; // rbx
  RBX::Reflection::Variant *v37; // rax
  __int64 v38; // [rsp+0h] [rbp-168h] BYREF
  char *name; // [rsp+20h] [rbp-148h]
  const RBX::Reflection::Tuple *arguments; // [rsp+28h] [rbp-140h]
  char v41; // [rsp+30h] [rbp-138h]
  int v42; // [rsp+38h] [rbp-130h]
  RBX::Reflection::Tuple v43; // [rsp+40h] [rbp-128h] BYREF
  unsigned __int8 inOutByteArray[4]; // [rsp+58h] [rbp-110h] BYREF
  unsigned __int8 v45[4]; // [rsp+5Ch] [rbp-10Ch] BYREF
  double rhs; // [rsp+60h] [rbp-108h] BYREF
  double v47; // [rsp+68h] [rbp-100h] BYREF
  std::shared_ptr<RBX::Reflection::Tuple> v48; // [rsp+70h] [rbp-F8h] BYREF
  std::_Uninitialized_backout_al<std::allocator<RBX::Reflection::Variant> > v49; // [rsp+80h] [rbp-E8h] BYREF
  std::_Tidy_guard<std::vector<RBX::Reflection::Variant> > v50; // [rsp+98h] [rbp-D0h] BYREF
  std::shared_ptr<RBX::Instance> result; // [rsp+A0h] [rbp-C8h] BYREF
  RBX::Network::NetworkStream v52; // [rsp+B0h] [rbp-B8h] BYREF
  RBX::Security::Identity identity; // [rsp+F0h] [rbp-78h] BYREF
  RakNet::AddressOrGUID v54; // [rsp+108h] [rbp-60h] BYREF
  int inByteArray; // [rsp+170h] [rbp+8h] BYREF
  int v56; // [rsp+180h] [rbp+18h]

  if ( this != nullptr ) /*0x141097223*/
  {
    v56 = challenge; /*0x141097233*/
    parent = (RBX::ServiceProvider *)this->parent; /*0x141097251*/
    if ( parent != nullptr ) /*0x141097258*/
    {
      v8 = parent->parent; /*0x14109725a*/
      if ( v8 != nullptr ) /*0x141097261*/
        parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v8); /*0x141097268*/
    }
    else
    {
      parent = (RBX::ServiceProvider *)this; /*0x14109726d*/
    }
    if ( parent != nullptr ) /*0x141097273*/
    {
      descriptor = parent->descriptor; /*0x141097279*/
      v10 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(); /*0x14109727d*/
      if ( descriptor->index - (unsigned int)v10->index <= v10->descendantCount ) /*0x14109729b*/
      {
        boost::call_once( /*0x1410972af*/
          flag: &`RBX::ServiceProvider::getClassIndex<RBX::ScriptContext>'::`2'::flag,
          f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::ScriptContext>);
        v11 = RBX::ServiceProvider::doGetClassIndex<RBX::ScriptContext>(); /*0x1410972b4*/
        v13 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt( /*0x1410972c4*/
                                                                                   this: parent,
                                                                                   index: v11);
        if ( v13->_Ptr == nullptr ) /*0x1410972cb*/
        {
          v14 = RBX::Reflection::Class_getNamePtr<RBX::ScriptContext>(this: v12); /*0x1410972cd*/
          ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName( /*0x1410972e0*/
                                                                                                    this: parent,
                                                                                                    &result,
                                                                                                    className: v14);
          std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v13, _Right: ServiceByClassName); /*0x1410972eb*/
          Rep = result._Rep; /*0x1410972f0*/
          if ( result._Rep != nullptr /*0x14109730c*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&result._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            Rep->_Destroy(this: Rep); /*0x141097314*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141097320*/
              Rep->_Delete_this(this: Rep); /*0x141097328*/
          }
        }
        Ptr = (RBX::ScriptContext *)v13->_Ptr; /*0x141097332*/
        if ( v13->_Ptr != nullptr ) /*0x141097338*/
        {
          __eh34_enter_try_state(-1, 0); /*0xf1c0000000000098*/
          v18 = (RBX::Reflection::Variant *)operator new(size: 0xA0u); /*0x14109735a*/
          v43.values._Mypair._Myval2._Myfirst = v18; /*0x14109735d*/
          v43.values._Mypair._Myval2._Mylast = v18; /*0x141097362*/
          v43.values._Mypair._Myval2._Myend = v18 + 2; /*0x14109736e*/
          v50._Target = (std::vector<RBX::Reflection::Variant> *)&v43; /*0x141097378*/
          __wind /*0xf1c0000000000078*/
          {
            v19 = 2; /*0x141097380*/
            v49._First = v18; /*0x141097385*/
            v49._Last = v18; /*0x14109738d*/
            v49._Al = (std::allocator<RBX::Reflection::Variant> *)&v43; /*0x14109739a*/
            while ( v19 != 0 ) /*0x1410973a5*/
            {
              __wind /*0xf1c0000000000060*/
              {
                v18->_type = RBX::Reflection::Type::getSingleton<void>(); /*0x1410973ac*/
                v18->value.holder = nullptr; /*0x1410973af*/
                v49._Last = ++v18; /*0x1410973bb*/
                --v19; /*0x1410973c3*/
              }
              __unwind
              {
                std::_Uninitialized_backout_al<std::allocator<RBX::Reflection::Variant>>::~_Uninitialized_backout_al<std::allocator<RBX::Reflection::Variant>>(this: &v49); /*0xf1c0000000000070*/
              }
            }
          }
          __unwind
          {
            std::_Tidy_guard<std::vector<RBX::Reflection::Variant>>::~_Tidy_guard<std::vector<RBX::Reflection::Variant>>(this: &v50); /*0xf1c0000000000088*/
          }
          __eh34_enter_wind_state(0, 4); /*0xf1c0000000000090*/
          v43.values._Mypair._Myval2._Mylast = v18; /*0x1410973c8*/
          rhs = (double)v56; /*0x1410973dc*/
          RBX::Reflection::Variant::operator=<double,0>(this: v43.values._Mypair._Myval2._Myfirst, &rhs); /*0x1410973ec*/
          v47 = (double)key; /*0x1410973f9*/
          RBX::Reflection::Variant::operator=<double,0>(this: v43.values._Mypair._Myval2._Myfirst + 1, rhs: &v47); /*0x14109740d*/
          RBX::Security::Identity::Identity(this: &identity, type: GameScript, assetId: 0, scriptContext: nullptr); /*0x141097424*/
          RBX::ScriptContext::callCallbackFromSource( /*0x141097452*/
            this: Ptr,
            result: &v48,
            &identity,
            script: bytecode,
            name: "challenge",
            arguments: &v43);
          __eh34_enter_wind_state(4, 5); /*0xf1c0000000000058*/
          Myfirst = v48._Ptr->values._Mypair._Myval2._Myfirst; /*0x14109745d*/
          if ( v48._Ptr->values._Mypair._Myval2._Myfirst != v48._Ptr->values._Mypair._Myval2._Mylast ) /*0x141097464*/
          {
            type = Myfirst->_type; /*0x14109746a*/
            if ( type == RBX::Reflection::Type::getSingleton<double>() && Myfirst->value.holder != nullptr ) /*0x141097480*/
            {
              data = (double *)Myfirst->value.data; /*0x141097486*/
              if ( data != nullptr ) /*0x14109748a*/
              {
                v24 = (int)*data; /*0x141097490*/
                if ( __eh34_unwind(5) ) /*0xf1c0000000000044*/
                  goto unwind_state_5; /*0xf1c0000000000044*/
                __eh34_exit_wind_state(5, 4); /*0xf1c0000000000050*/
                v25 = v48._Rep; /*0x141097495*/
                if ( v48._Rep != nullptr /*0x1410974a9*/
                  && _InterlockedExchangeAdd((volatile signed __int32 *)&v48._Rep->_Uses, 0xFFFFFFFF) == 1 )
                {
                  v25->_Destroy(this: v25); /*0x1410974b1*/
                  if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v25->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410974bb*/
                    v25->_Delete_this(this: v25); /*0x1410974c3*/
                }
                if ( __eh34_unwind(4) ) /*0xf1c00000000000dc*/
                  goto unwind_state_4; /*0xf1c00000000000dc*/
                __eh34_exit_wind_state(4, 0); /*0xf1c00000000000e8*/
                __eh34_enter_wind_state(0, 6); /*0xf1c00000000000ec*/
                v26 = v43.values._Mypair._Myval2._Myfirst; /*0x1410974c7*/
                if ( v43.values._Mypair._Myval2._Myfirst == nullptr ) /*0x1410974cf*/
                  goto LABEL_79; /*0x1410974cf*/
                Mylast = v43.values._Mypair._Myval2._Mylast; /*0x1410974d5*/
                if ( v43.values._Mypair._Myval2._Myfirst != v43.values._Mypair._Myval2._Mylast ) /*0x1410974dd*/
                {
                  p_value = &v43.values._Mypair._Myval2._Myfirst->value; /*0x1410974df*/
                  do /*0x141097501*/
                  {
                    if ( p_value->holder != nullptr ) /*0x1410974e9*/
                      p_value->holder->destruct(a1: p_value->data); /*0x1410974f3*/
                    p_value = (rbx::placement_any<RBX::Reflection::Variant::Storage> *)((char *)p_value + 80); /*0x1410974f6*/
                  }
                  while ( &p_value[-1].data[56] != (char *)Mylast ); /*0x141097501*/
                  v26 = v43.values._Mypair._Myval2._Myfirst; /*0x141097503*/
                }
                v29 = v26; /*0x141097533*/
                if ( (unsigned __int64)(80 * (v43.values._Mypair._Myval2._Myend - v26)) < 0x1000 /*0x141097552*/
                  || (v26 = *(RBX::Reflection::Variant **)&v26[-1].value.data[56],
                      (unsigned __int64)((char *)v29 - (char *)v26 - 8) <= 0x1F) )
                {
                  operator delete(ptr: (void *)v26); /*0x14109755b*/
                  if ( __eh34_unwind(6) ) /*0xf1c00000000000c8*/
                    goto unwind_state_6; /*0xf1c00000000000c8*/
LABEL_79:
                  __eh34_exit_wind_state(6, 0); /*0xf1c00000000000cc*/
                  if ( __eh34_catch(0) ) /*0xf1c00000000000d0*/
                    goto catch_state_0; /*0xf1c00000000000d0*/
                  __eh34_exit_try_state(0, -1); /*0xf1c00000000000d4*/
                  RBX::Network::NetworkStream::NetworkStream(this: &v52); /*0x141097569*/
                  __wind /*0xf1c0000000000038*/
                  {
                    LOBYTE(inByteArray) = -101; /*0x14109756f*/
                    RBX::Network::NetworkStream::writeBytes(this: &v52, &inByteArray, numberOfBytesToWrite: 1u); /*0x14109758d*/
                    inByteArray = v56; /*0x141097599*/
                    RBX::Network::NetworkStream::ReverseBytes( /*0x1410975b3*/
                      (unsigned __int8 *)&inByteArray,
                      inOutByteArray,
                      length: 4u);
                    RBX::Network::NetworkStream::writeBytes( /*0x1410975cb*/
                      this: &v52,
                      inByteArray: inOutByteArray,
                      numberOfBytesToWrite: 4u);
                    inByteArray = v24; /*0x1410975d0*/
                    RBX::Network::NetworkStream::ReverseBytes( /*0x1410975ea*/
                      (unsigned __int8 *)&inByteArray,
                      inOutByteArray: v45,
                      length: 4u);
                    RBX::Network::NetworkStream::writeBytes(this: &v52, inByteArray: v45, numberOfBytesToWrite: 4u); /*0x141097602*/
                    v30 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x141097613*/
                    v31 = v30->onInternalError._Mystorage._Ptrs[0][20].__vftable; /*0x141097619*/
                    v42 = 0; /*0x141097634*/
                    v41 = 0; /*0x14109763c*/
                    arguments = (const RBX::Reflection::Tuple *)RakNet::AddressOrGUID::AddressOrGUID( /*0x141097641*/
                                                                  this: &v54,
                                                                  input: &this->remotePlayerRakNetAddress);
                    LOBYTE(name) = 0; /*0x141097646*/
                    ((void (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::NetworkStream *, __int64))v31)( /*0x141097660*/
                      a1: v30,
                      a2: &v52,
                      a3: 2);
                  }
                  __unwind
                  {
                    RBX::Network::NetworkStream::~NetworkStream(this: &v52); /*0xf1c0000000000030*/
                  }
                  v32 = v52.dataVector._Mypair._Myval2._Myfirst; /*0x141097663*/
                  if ( v52.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x14109766e*/
                  {
                    if ( (unsigned __int8 *)(v52.dataVector._Mypair._Myval2._Myend /*0x141097689*/
                                           - v52.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 )
                    {
                      v32 = *((unsigned __int8 **)v52.dataVector._Mypair._Myval2._Myfirst - 1); /*0x14109768f*/
                      if ( (unsigned __int64)(v52.dataVector._Mypair._Myval2._Myfirst - v32 - 8) > 0x1F ) /*0x14109769e*/
                        _invalid_parameter_noinfo_noreturn(); /*0x1410976a0*/
                    }
                    operator delete(ptr: v32); /*0x1410976a7*/
                  }
                  return; /*0x1410976ac*/
                }
LABEL_54:
                _invalid_parameter_noinfo_noreturn(); /*0x141097771*/
              }
            }
          }
          if ( __eh34_unwind(5) ) /*0xf1c00000000000f4*/
          {
unwind_state_5:
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v48); /*0xf1c0000000000048*/
            __eh34_continue_unwinding(5, 4); /*0xf1c000000000004c*/
          }
          __eh34_exit_wind_state(5, 4); /*0xf1c00000000000f8*/
          if ( __eh34_unwind(4) ) /*0xf1c00000000000fc*/
          {
unwind_state_4:
            std::vector<RBX::Reflection::Variant>::~vector<RBX::Reflection::Variant>(this: &v43); /*0xf1c00000000000e0*/
            __eh34_continue_unwinding(4, 0); /*0xf1c00000000000e4*/
          }
          __eh34_exit_wind_state(4, 0); /*0xf1c0000000000100*/
          __eh34_enter_wind_state(0, 6); /*0xf1c0000000000104*/
          v33 = v48._Rep; /*0x1410976b1*/
          if ( v48._Rep != nullptr /*0x1410976c5*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&v48._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v33->_Destroy(this: v33); /*0x1410976cd*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v33->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410976d7*/
              v33->_Delete_this(this: v33); /*0x1410976df*/
          }
          v34 = v43.values._Mypair._Myval2._Myfirst; /*0x1410976e3*/
          if ( v43.values._Mypair._Myval2._Myfirst != nullptr ) /*0x1410976eb*/
          {
            v35 = v43.values._Mypair._Myval2._Mylast; /*0x1410976f1*/
            if ( v43.values._Mypair._Myval2._Myfirst != v43.values._Mypair._Myval2._Mylast ) /*0x1410976f9*/
            {
              v36 = &v43.values._Mypair._Myval2._Myfirst->value; /*0x1410976fb*/
              do /*0x14109771e*/
              {
                if ( v36->holder != nullptr ) /*0x141097706*/
                  v36->holder->destruct(a1: v36->data); /*0x141097710*/
                v36 = (rbx::placement_any<RBX::Reflection::Variant::Storage> *)((char *)v36 + 80); /*0x141097713*/
              }
              while ( &v36[-1].data[56] != (char *)v35 ); /*0x14109771e*/
              v34 = v43.values._Mypair._Myval2._Myfirst; /*0x141097720*/
            }
            v37 = v34; /*0x141097750*/
            if ( (unsigned __int64)(80 * (v43.values._Mypair._Myval2._Myend - v34)) >= 0x1000 ) /*0x14109775a*/
            {
              v34 = *(RBX::Reflection::Variant **)&v34[-1].value.data[56]; /*0x141097760*/
              if ( (unsigned __int64)((char *)v37 - (char *)v34 - 8) > 0x1F ) /*0x14109776f*/
                goto LABEL_54; /*0x14109776f*/
            }
            operator delete(ptr: (void *)v34); /*0x14109777b*/
          }
          if ( __eh34_unwind(6) ) /*0xf1c00000000000a0*/
unwind_state_6:
            __std_terminate(a1: v20, a2: &v38); /*0xf1c00000000000a4*/
          __eh34_exit_wind_state(6, 0); /*0xf1c00000000000ac*/
          if ( __eh34_catch(0) ) /*0xf1c00000000000b0*/
          {
catch_state_0:
            if ( __eh34_catch_ellipsis(0) ) /*0xf1c00000000000b4*/
              return; /*0xf1c000000000001c*/
          }
          __eh34_exit_try_state(0, -1); /*0xf1c00000000000c0*/
        }
      }
    }
  }
}

// Address: 0x1410977a0 | Name: ?containsHighLODTerrain@ClientReplicator@Network@RBX@@AEBA_NAEBVId@StreamRegion@3@@Z
bool __fastcall RBX::Network::ClientReplicator::containsHighLODTerrain(
        RBX::Network::ClientReplicator *this,
        const RBX::StreamRegion::Id *regionId)
{
  int y; // r9d
  int z; // r8d
  RBX::Voxel2::Region region; // [rsp+20h] [rbp-28h] BYREF

  y = regionId->internalValue.y; /*0x1410977a6*/
  z = regionId->internalValue.z; /*0x1410977aa*/
  region.begin_.x = 16 * regionId->internalValue.x; /*0x1410977b6*/
  region.end_.x = region.begin_.x + 16; /*0x1410977bd*/
  region.begin_.y = 16 * y; /*0x1410977c9*/
  region.begin_.z = 16 * z; /*0x1410977ce*/
  region.end_.y = 16 * y + 16; /*0x1410977d7*/
  region.end_.z = 16 * z + 16; /*0x1410977df*/
  return RBX::Voxel2::Grid::isHighLod( /*0x1410977f6*/
           this: *(RBX::Voxel2::Grid **)&this->megaClusterInstance->clusterCoordinateFrame[32],
           &region);
}

// Address: 0x141097800 | Name: ?createStatsItem@ClientReplicator@Network@RBX@@MEAA?AV?$shared_ptr@VStats@Replicator@Network@RBX@@@std@@XZ
std::shared_ptr<RBX::Network::Replicator::Stats> *__fastcall RBX::Network::ClientReplicator::createStatsItem(
        RBX::Network::ClientReplicator *this,
        std::shared_ptr<RBX::Network::Replicator::Stats> *result)
{
  std::_Ref_count_base *Rep; // r8
  signed __int32 Uses; // eax
  signed __int32 v6; // ett
  std::_Ref_count_base *v7; // rcx
  std::shared_ptr<RBX::Network::Replicator::Stats> *v8; // rax
  std::_Ref_count_base *v9; // rbx
  std::_Ref_count_base *v10; // rbx
  std::shared_ptr<RBX::Network::Replicator::Stats> *v11; // rax
  std::shared_ptr<RBX::Network::ClientReplicator> v12; // [rsp+20h] [rbp-48h] BYREF
  __int64 v13; // [rsp+38h] [rbp-30h]
  __int64 v14; // [rsp+48h] [rbp-20h]
  std::shared_ptr<RBX::Network::ClientReplicator::ClientStatsItem> v15; // [rsp+50h] [rbp-18h] BYREF

  if ( this != nullptr ) /*0x141097823*/
  {
    Rep = this->_Wptr._Rep; /*0x141097825*/
    if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x141097838*/
LABEL_18:
      std::_Throw_bad_weak_ptr(); /*0x14109792d*/
    while ( 1 ) /*0x141097843*/
    {
      v6 = Uses; /*0x141097843*/
      Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x141097843*/
      if ( v6 == Uses ) /*0x141097849*/
        break; /*0x141097849*/
      if ( Uses == 0 ) /*0x14109784d*/
        goto LABEL_18; /*0x14109784d*/
    }
    v7 = this->_Wptr._Rep; /*0x141097859*/
    v12._Ptr = (RBX::Network::ClientReplicator *)this->_Wptr._Ptr; /*0x14109785d*/
    v12._Rep = v7; /*0x141097862*/
    v13 = 0; /*0x141097869*/
  }
  else
  {
    v12._Ptr = nullptr; /*0x141097872*/
    v12._Rep = nullptr; /*0x141097877*/
    v14 = 0; /*0x14109787c*/
  }
  __wind /*0xf1c0000000000010*/
  {
    v8 = (std::shared_ptr<RBX::Network::Replicator::Stats> *)RBX::Creatable<RBX::Instance>::create<RBX::Network::ClientReplicator::ClientStatsItem,std::shared_ptr<RBX::Network::ClientReplicator>>( /*0x14109788b*/
                                                               result: &v15,
                                                               <args_0>: &v12);
    *result = *v8; /*0x141097893*/
    v8->_Ptr = nullptr; /*0x14109789e*/
    v8->_Rep = nullptr; /*0x1410978a1*/
    v9 = v15._Rep; /*0x1410978a5*/
    if ( v15._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v15._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410978b9*/
    {
      v9->_Destroy(this: v9); /*0x1410978c1*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v9->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410978cd*/
        v9->_Delete_this(this: v9); /*0x1410978d5*/
    }
    if ( v12._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v12._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410978ed*/
    {
      v10 = v12._Rep; /*0x1410978ef*/
      v12._Rep->_Destroy(this: v12._Rep); /*0x1410978fa*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141097904*/
        v12._Rep->_Delete_this(this: v12._Rep); /*0x14109790e*/
    }
    v11 = result; /*0x141097911*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v12); /*0xf1c0000000000008*/
  }
  return v11; /*0x141097914*/
}

// Address: 0x141097940 | Name: ?dataOutStep@ClientReplicator@Network@RBX@@MEAAHH@Z
__int64 __fastcall RBX::Network::ClientReplicator::dataOutStep(
        RBX::Network::ClientReplicator *this,
        int bytesToProduce)
{
  unsigned int v4; // ebx
  unsigned int v5; // edi
  __int64 v6; // rcx
  __int64 v8; // [rsp+0h] [rbp-28h] BYREF
  RBX::Memory::Scope memscopeNetworkReplicator; // [rsp+30h] [rbp+8h] BYREF

  v4 = RBX::Memory::setCurrentCategory(category: RBX::Memory::NetworkReplicator); /*0x14109795f*/
  memscopeNetworkReplicator.parent = v4; /*0x141097961*/
  __wind /*0xf1c0000000000020*/
  {
    RBX::Network::PropSync::detail::Base<RBX::Network::PropSync::detail::MasterItem>::expireItems(this: (RBX::Network::PropSync::detail::Base<RBX::Network::PropSync::detail::MasterItem> *)&this->propSync); /*0x14109796c*/
    if ( (this->peerCapability & 2) != 0 ) /*0x14109797c*/
      RBX::Network::Sync::Base<RBX::Network::Sync::MasterItem,RBX::Network::Sync::AttributeKey>::expireItems(this: (RBX::Network::Sync::Base<RBX::Network::Sync::MasterItem,RBX::Network::Sync::AttributeKey> *)&this->attrSync); /*0x141097985*/
    v5 = RBX::Network::Replicator::dataOutStep(this, bytesToProduce); /*0x141097994*/
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&memscopeNetworkReplicator); /*0xf1c0000000000030*/
  }
  __wind /*0xf1c0000000000038*/
  {
    RBX::Memory::setCurrentCategory(category: v4); /*0x141097998*/
  }
  __unwind
  {
    __std_terminate(a1: v6, a2: &v8); /*0x142f39fa8*/
  }
  return v5; /*0x1410979a0*/
}

// Address: 0x1410979b0 | Name: ?debugDumpProfile@ClientReplicator@Network@RBX@@AEAAXH@Z
void __fastcall RBX::Network::ClientReplicator::debugDumpProfile(RBX::Network::ClientReplicator *this, int numFrames)
{
  int v4; // edx
  int v5; // edx
  char *Ptr; // rcx
  wchar_t *v7; // rcx
  boost::filesystem::path dummyLogPath; // [rsp+20h] [rbp-E0h] BYREF
  std::string result; // [rsp+40h] [rbp-C0h] BYREF
  std::basic_stringstream<char,std::char_traits<char>,std::allocator<char> > profileData; // [rsp+60h] [rbp-A0h] BYREF

  *(_QWORD *)profileData.gap0 = &std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vftable'[1]; /*0x1410979de*/
  *(_QWORD *)profileData.gap10 = &std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vbtable'{for `std::ostream'}; /*0x1410979ea*/
  std::ios::ios(a1: &profileData.gap90[8]); /*0x1410979f3*/
  __wind /*0xf1c0000000000088*/
  {
    std::iostream::iostream(a1: &profileData, a2: &profileData.gap10[8], a3: 0); /*0x141097a11*/
    *(_QWORD *)&profileData.gap0[*(int *)(*(_QWORD *)profileData.gap0 + 4LL)] = std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vftable'; /*0x141097a28*/
    v4 = *(_DWORD *)(*(_QWORD *)profileData.gap0 + 4LL) - 152; /*0x141097a36*/
    *(_DWORD *)((char *)&result._Mypair._Myval2._Myres + *(int *)(*(_QWORD *)profileData.gap0 + 4LL) + 4) = v4; /*0x141097a3c*/
    __wind /*0xf1c0000000000058*/
    {
      std::streambuf::streambuf(a1: &profileData.gap10[8]); /*0x141097a45*/
      *(_QWORD *)&profileData.gap10[8] = std::stringbuf::`vftable'; /*0x141097a52*/
      *(_QWORD *)profileData._Stringbuffer = 0; /*0x141097a57*/
      *(_DWORD *)&profileData._Stringbuffer[8] = 0; /*0x141097a5b*/
      v5 = numFrames; /*0x141097a5e*/
    }
    __unwind
    {
      std::iostream::~iostream<char,std::char_traits<char>>(a1: &profileData.gap10[16]); /*0x143171c9b*/
    }
  }
  __unwind
  {
    std::ios::~ios<char,std::char_traits<char>>(a1: &profileData.gap90[8]); /*0x1431ebd58*/
  }
  __wind /*0xf1c000000000007c*/
  {
    RBX::Profiler::dumpProfilerDataToStringStream(stream: &profileData, framesRequested: v5); /*0x141097a65*/
    dummyLogPath.m_pathname._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141097a6a*/
    *(__m128i *)&dummyLogPath.m_pathname._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x141097a77*/
    __wind /*0xf1c000000000004c*/
    {
      std::stringbuf::str(this: (std::stringbuf *)&profileData.gap10[8], &result); /*0x141097a8c*/
      __wind /*0xf1c000000000001c*/
      {
        RBX::Network::ClientReplicator::stringToHtmlFileDumpToLogDirHelper( /*0x141097a9f*/
          this,
          logPath: &dummyLogPath,
          string: &result);
        if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x141097aae*/
        {
          Ptr = result._Mypair._Myval2._Bx._Ptr; /*0x141097ab3*/
          if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141097ac2*/
          {
            Ptr = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x141097ac8*/
            if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x141097ad7*/
              _invalid_parameter_noinfo_noreturn(); /*0x141097ad9*/
          }
          operator delete(ptr: Ptr); /*0x141097ae0*/
        }
        if ( dummyLogPath.m_pathname._Mypair._Myval2._Myres >= 8 ) /*0x141097aef*/
        {
          v7 = dummyLogPath.m_pathname._Mypair._Myval2._Bx._Ptr; /*0x141097af9*/
          if ( 2 * dummyLogPath.m_pathname._Mypair._Myval2._Myres + 2 >= 0x1000 ) /*0x141097b08*/
          {
            v7 = *((wchar_t **)dummyLogPath.m_pathname._Mypair._Myval2._Bx._Ptr - 1); /*0x141097b0e*/
            if ( (unsigned __int64)((char *)dummyLogPath.m_pathname._Mypair._Myval2._Bx._Ptr - (char *)v7 - 8) > 0x1F ) /*0x141097b1d*/
              _invalid_parameter_noinfo_noreturn(); /*0x141097b1f*/
          }
          operator delete(ptr: v7); /*0x141097b26*/
        }
        *(__m128i *)&dummyLogPath.m_pathname._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x141097b33*/
        dummyLogPath.m_pathname._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141097b39*/
        *(_QWORD *)&profileData.gap0[*(int *)(*(_QWORD *)profileData.gap0 + 4LL)] = std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vftable'; /*0x141097b47*/
        *(_DWORD *)((char *)&result._Mypair._Myval2._Myres + *(int *)(*(_QWORD *)profileData.gap0 + 4LL) + 4) = *(_DWORD *)(*(_QWORD *)profileData.gap0 + 4LL) - 152; /*0x141097b5b*/
        std::stringbuf::~stringbuf(this: (std::stringbuf *)&profileData.gap10[8]); /*0x141097b64*/
        std::iostream::~iostream<char,std::char_traits<char>>(a1: &profileData.gap10[16]); /*0x141097b6d*/
        std::ios::~ios<char,std::char_traits<char>>(a1: &profileData.gap90[8]); /*0x141097b77*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c000000000002c*/
      }
    }
    __unwind
    {
      boost::filesystem::path::~path(this: (std::pair<std::wstring const ,char const *> *)&dummyLogPath); /*0xf1c0000000000038*/
    }
  }
  __unwind
  {
    std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::`vbase destructor'(this: &profileData); /*0xf1c0000000000044*/
  }
}

// Address: 0x141097d70 | Name: ?deserializeItem@ClientReplicator@Network@RBX@@MEAA?AV?$shared_ptr@VDeserializedItem@Network@RBX@@@std@@AEAVNetworkStream@23@W4ItemType@Item@23@@Z
std::shared_ptr<RBX::Network::DeserializedItem> *__fastcall RBX::Network::ClientReplicator::deserializeItem(
        RBX::Network::ClientReplicator *this,
        std::shared_ptr<RBX::Network::DeserializedItem> *result,
        RBX::Network::NetworkStream *inBitstream,
        RBX::Network::Item::ItemType itemType)
{
  std::shared_ptr<RBX::Network::DeserializedStreamDataItem> *v8; // rax
  RBX::Network::DeserializedItem *v9; // rcx
  std::_Ref_count_base *v10; // rdx
  std::_Ref_count_base *v11; // rsi
  std::_Ref_count_base *v12; // rsi
  std::shared_ptr<RBX::Network::DeserializedStreamDataInfoItem> *v13; // rax
  RBX::Network::DeserializedItem *v14; // rcx
  std::_Ref_count_base *v15; // rdx
  std::_Ref_count_base *v16; // rsi
  std::shared_ptr<RBX::Network::DeserializedStreamPrefetchDataInfoItem> *v17; // rax
  RBX::Network::DeserializedItem *v18; // rcx
  std::_Ref_count_base *v19; // rdx
  std::_Ref_count_base *v20; // rsi
  std::shared_ptr<RBX::Network::DeserializedStreamPrefetchRequestItem> *v21; // rax
  RBX::Network::DeserializedItem *v22; // rcx
  std::_Ref_count_base *v23; // rdx
  std::_Ref_count_base *v24; // rsi
  std::shared_ptr<RBX::Network::DeserializedItem> *v25; // rax
  RBX::Network::DeserializedItem *v26; // rcx
  std::_Ref_count_base *v27; // rdx
  std::_Ref_count_base *v28; // rsi
  std::shared_ptr<RBX::Network::DeserializedItem> *v29; // rax
  RBX::Network::DeserializedItem *v30; // rcx
  std::_Ref_count_base *v31; // rdx
  std::_Ref_count_base *v32; // rsi
  std::shared_ptr<RBX::Network::DeserializedItem> *v33; // rax
  RBX::Network::DeserializedItem *Ptr; // rcx
  std::_Ref_count_base *Rep; // rdx
  std::_Ref_count_base *v36; // rsi
  std::shared_ptr<RBX::Network::DeserializedItem> *v37; // rax
  RBX::Network::DeserializedItem *v38; // rcx
  std::_Ref_count_base *v39; // rdx
  std::_Ref_count_base *v40; // rsi
  std::shared_ptr<RBX::Network::DeserializedItem> *v41; // rax
  RBX::Network::DeserializedItem *v42; // rcx
  std::_Ref_count_base *v43; // rdx
  std::_Ref_count_base *v44; // rsi
  std::shared_ptr<RBX::Network::DeserializedItem> *v45; // rax
  RBX::Network::DeserializedItem *v46; // rcx
  std::_Ref_count_base *v47; // rdx
  std::_Ref_count_base *v48; // rsi
  std::shared_ptr<RBX::Network::DeserializedItem> *v49; // rax
  RBX::Network::DeserializedItem *v50; // rcx
  std::_Ref_count_base *v51; // rdx
  std::_Ref_count_base *v52; // rsi
  std::shared_ptr<RBX::Network::DeserializedItem> *v53; // rax
  RBX::Network::DeserializedItem *v54; // rcx
  std::_Ref_count_base *v55; // rdx
  std::_Ref_count_base *v56; // rsi
  __int64 v57; // rcx
  std::shared_ptr<RBX::Network::DeserializedItem> *v58; // rax
  __int64 v59; // [rsp+0h] [rbp-C9h] BYREF
  int v60; // [rsp+20h] [rbp-A9h]
  RBX::Profiler::Scope profscope1715; // [rsp+28h] [rbp-A1h] BYREF
  std::shared_ptr<RBX::Network::DeserializedStreamDataItem> v62; // [rsp+38h] [rbp-91h] BYREF
  std::shared_ptr<RBX::Network::DeserializedStreamDataInfoItem> v63; // [rsp+48h] [rbp-81h] BYREF
  std::shared_ptr<RBX::Network::DeserializedStreamPrefetchDataInfoItem> v64; // [rsp+58h] [rbp-71h] BYREF
  std::shared_ptr<RBX::Network::DeserializedStreamPrefetchRequestItem> v65; // [rsp+68h] [rbp-61h] BYREF
  std::shared_ptr<RBX::Network::DeserializedItem> v66; // [rsp+78h] [rbp-51h] BYREF
  std::shared_ptr<RBX::Network::DeserializedItem> v67; // [rsp+88h] [rbp-41h] BYREF
  std::shared_ptr<RBX::Network::DeserializedItem> v68; // [rsp+98h] [rbp-31h] BYREF
  std::shared_ptr<RBX::Network::DeserializedItem> v69; // [rsp+A8h] [rbp-21h] BYREF
  std::shared_ptr<RBX::Network::DeserializedItem> v70; // [rsp+B8h] [rbp-11h] BYREF
  std::shared_ptr<RBX::Network::DeserializedItem> v71; // [rsp+C8h] [rbp-1h] BYREF
  std::shared_ptr<RBX::Network::DeserializedItem> v72; // [rsp+D8h] [rbp+Fh] BYREF
  std::shared_ptr<RBX::Network::DeserializedItem> v73; // [rsp+E8h] [rbp+1Fh] BYREF

  __wind /*0xf1c000000000007c*/
  {
    v60 = 0; /*0x141097da2*/
    if ( _TSS0_533 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x141097dcf*/
    {
      Init_thread_header(pOnce: &_TSS0_533); /*0x1410982f7*/
      if ( _TSS0_533 == -1 ) /*0x141098302*/
      {
        __wind /*0xf1c0000000000028*/
        {
          proftoken1715 = RBX::Profiler::getToken(group: "Network", name: "deserializeItem", color: -1); /*0x14109831e*/
          Init_thread_footer(pOnce: &_TSS0_533); /*0x14109832c*/
        }
        __unwind
        {
          Init_thread_abort(pOnce: &_TSS0_533); /*0x1431ebd77*/
        }
      }
    }
    profscope1715.region.token = proftoken1715; /*0x141097ddc*/
    profscope1715.region.timestamp = RBX::Profiler::enterRegion(token: proftoken1715); /*0x141097de6*/
    *result = 0; /*0x141097dee*/
    result->_Ptr = nullptr; /*0x141097df1*/
    result->_Rep = nullptr; /*0x141097df4*/
    v60 = 1; /*0x141097df8*/
    switch ( itemType ) /*0x141097e20*/
    {
      case ItemTypeRocky: /*0x141097e20*/
        v33 = RBX::Network::Replicator::RockyItem::read(result: &v68, replicator: this, bitStream: inBitstream); /*0x141098069*/
        Ptr = v33->_Ptr; /*0x14109806e*/
        Rep = v33->_Rep; /*0x141098071*/
        v33->_Ptr = nullptr; /*0x141098075*/
        v33->_Rep = nullptr; /*0x141098078*/
        result->_Ptr = Ptr; /*0x14109807c*/
        v36 = result->_Rep; /*0x14109807f*/
        result->_Rep = Rep; /*0x141098083*/
        if ( v36 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v36->_Uses, 0xFFFFFFFF) == 1 ) /*0x141098096*/
        {
          v36->_Destroy(this: v36); /*0x14109809e*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v36->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410980aa*/
            v36->_Delete_this(this: v36); /*0x1410980b2*/
        }
        v12 = v68._Rep; /*0x1410980b5*/
        break; /*0x1410980b9*/
      case ItemTypeJoinData: /*0x141097e20*/
        v37 = RBX::Network::Replicator::JoinDataItem::read(result: &v69, replicator: this, inBitstream); /*0x1410980c8*/
        v38 = v37->_Ptr; /*0x1410980cd*/
        v39 = v37->_Rep; /*0x1410980d0*/
        v37->_Ptr = nullptr; /*0x1410980d4*/
        v37->_Rep = nullptr; /*0x1410980d7*/
        result->_Ptr = v38; /*0x1410980db*/
        v40 = result->_Rep; /*0x1410980de*/
        result->_Rep = v39; /*0x1410980e2*/
        if ( v40 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v40->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410980f5*/
        {
          v40->_Destroy(this: v40); /*0x1410980fd*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v40->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141098109*/
            v40->_Delete_this(this: v40); /*0x141098111*/
        }
        v12 = v69._Rep; /*0x141098114*/
        break; /*0x141098118*/
      case ItemTypeStreamData: /*0x141097e20*/
        __wind /*0xf1c0000000000070*/
        {
          v8 = RBX::Network::Replicator::StreamJob::StreamDataItem::read(result: &v62, replicator: this, inBitstream); /*0x141097e2d*/
          v9 = v8->_Ptr; /*0x141097e32*/
          v10 = v8->_Rep; /*0x141097e35*/
          v8->_Ptr = nullptr; /*0x141097e39*/
          v8->_Rep = nullptr; /*0x141097e3c*/
          result->_Ptr = v9; /*0x141097e40*/
          v11 = result->_Rep; /*0x141097e43*/
          result->_Rep = v10; /*0x141097e47*/
          if ( v11 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v11->_Uses, 0xFFFFFFFF) == 1 ) /*0x141097e5a*/
          {
            v11->_Destroy(this: v11); /*0x141097e62*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v11->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141097e6e*/
              v11->_Delete_this(this: v11); /*0x141097e76*/
          }
          v12 = v62._Rep; /*0x141097e79*/
        }
        __unwind
        {
          RBX::Profiler::Scope::~Scope(this: &profscope1715); /*0xf1c0000000000068*/
        }
        return v58; /*0xf1c000000000006c*/
      case ItemTypeTag: /*0x141097e20*/
        v25 = RBX::Network::Replicator::TagItem::read(result: &v66, replicator: this, inBitstream); /*0x141097fab*/
        v26 = v25->_Ptr; /*0x141097fb0*/
        v27 = v25->_Rep; /*0x141097fb3*/
        v25->_Ptr = nullptr; /*0x141097fb7*/
        v25->_Rep = nullptr; /*0x141097fba*/
        result->_Ptr = v26; /*0x141097fbe*/
        v28 = result->_Rep; /*0x141097fc1*/
        result->_Rep = v27; /*0x141097fc5*/
        if ( v28 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v28->_Uses, 0xFFFFFFFF) == 1 ) /*0x141097fd8*/
        {
          v28->_Destroy(this: v28); /*0x141097fe0*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v28->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141097fec*/
            v28->_Delete_this(this: v28); /*0x141097ff4*/
        }
        v12 = v66._Rep; /*0x141097ff7*/
        break; /*0x141097ffb*/
      case ItemTypeStats: /*0x141097e20*/
        v29 = RBX::Network::Replicator::StatsItem::read(result: &v67, replicator: this, bitStream: inBitstream); /*0x14109800a*/
        v30 = v29->_Ptr; /*0x14109800f*/
        v31 = v29->_Rep; /*0x141098012*/
        v29->_Ptr = nullptr; /*0x141098016*/
        v29->_Rep = nullptr; /*0x141098019*/
        result->_Ptr = v30; /*0x14109801d*/
        v32 = result->_Rep; /*0x141098020*/
        result->_Rep = v31; /*0x141098024*/
        if ( v32 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v32->_Uses, 0xFFFFFFFF) == 1 ) /*0x141098037*/
        {
          v32->_Destroy(this: v32); /*0x14109803f*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v32->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14109804b*/
            v32->_Delete_this(this: v32); /*0x141098053*/
        }
        v12 = v67._Rep; /*0x141098056*/
        break; /*0x14109805a*/
      case ItemTypeStreamDataInfo: /*0x141097e20*/
        v13 = RBX::Network::Replicator::StreamJob::StreamDataInfoItem::read(result: &v63, replicator: this, inBitstream); /*0x141097e8e*/
        v14 = v13->_Ptr; /*0x141097e93*/
        v15 = v13->_Rep; /*0x141097e96*/
        v13->_Ptr = nullptr; /*0x141097e9a*/
        v13->_Rep = nullptr; /*0x141097e9d*/
        result->_Ptr = v14; /*0x141097ea1*/
        v16 = result->_Rep; /*0x141097ea4*/
        result->_Rep = v15; /*0x141097ea8*/
        if ( v16 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v16->_Uses, 0xFFFFFFFF) == 1 ) /*0x141097ebb*/
        {
          v16->_Destroy(this: v16); /*0x141097ec3*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v16->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141097ecf*/
            v16->_Delete_this(this: v16); /*0x141097ed7*/
        }
        v12 = v63._Rep; /*0x141097eda*/
        break; /*0x141097ede*/
      case ItemTypeJoinDataV2: /*0x141097e20*/
        v41 = RBX::Network::Replicator::readJoinDataItemV2(this, result: &v70, inBitstream); /*0x141098127*/
        v42 = v41->_Ptr; /*0x14109812c*/
        v43 = v41->_Rep; /*0x14109812f*/
        v41->_Ptr = nullptr; /*0x141098133*/
        v41->_Rep = nullptr; /*0x141098136*/
        result->_Ptr = v42; /*0x14109813a*/
        v44 = result->_Rep; /*0x14109813d*/
        result->_Rep = v43; /*0x141098141*/
        if ( v44 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v44->_Uses, 0xFFFFFFFF) == 1 ) /*0x141098154*/
        {
          v44->_Destroy(this: v44); /*0x14109815c*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v44->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141098168*/
            v44->_Delete_this(this: v44); /*0x141098170*/
        }
        v12 = v70._Rep; /*0x141098173*/
        break; /*0x141098177*/
      case ItemTypeStreamPrefetchDataInfo: /*0x141097e20*/
        v17 = RBX::Network::Replicator::StreamJob::StreamPrefetchDataInfoItem::read( /*0x141097eed*/
                result: &v64,
                replicator: this,
                inBitstream);
        v18 = v17->_Ptr; /*0x141097ef2*/
        v19 = v17->_Rep; /*0x141097ef5*/
        v17->_Ptr = nullptr; /*0x141097ef9*/
        v17->_Rep = nullptr; /*0x141097efc*/
        result->_Ptr = v18; /*0x141097f00*/
        v20 = result->_Rep; /*0x141097f03*/
        result->_Rep = v19; /*0x141097f07*/
        if ( v20 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Uses, 0xFFFFFFFF) == 1 ) /*0x141097f1a*/
        {
          v20->_Destroy(this: v20); /*0x141097f22*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v20->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141097f2e*/
            v20->_Delete_this(this: v20); /*0x141097f36*/
        }
        v12 = v64._Rep; /*0x141097f39*/
        break; /*0x141097f3d*/
      case ItemTypeStreamPrefetchRequest: /*0x141097e20*/
        v21 = RBX::Network::Replicator::StreamJob::StreamPrefetchRequestItem::read( /*0x141097f4c*/
                result: &v65,
                replicator: this,
                inBitstream);
        v22 = v21->_Ptr; /*0x141097f51*/
        v23 = v21->_Rep; /*0x141097f54*/
        v21->_Ptr = nullptr; /*0x141097f58*/
        v21->_Rep = nullptr; /*0x141097f5b*/
        result->_Ptr = v22; /*0x141097f5f*/
        v24 = result->_Rep; /*0x141097f62*/
        result->_Rep = v23; /*0x141097f66*/
        if ( v24 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v24->_Uses, 0xFFFFFFFF) == 1 ) /*0x141097f79*/
        {
          v24->_Destroy(this: v24); /*0x141097f81*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v24->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141097f8d*/
            v24->_Delete_this(this: v24); /*0x141097f95*/
        }
        v12 = v65._Rep; /*0x141097f98*/
        break; /*0x141097f9c*/
      case ItemTypeVisualEffect: /*0x141097e20*/
        v45 = RBX::Network::Replicator::ClientVisualEffectItem::read( /*0x141098186*/
                result: &v71,
                replicator: this,
                bitStream: inBitstream);
        v46 = v45->_Ptr; /*0x14109818b*/
        v47 = v45->_Rep; /*0x14109818e*/
        v45->_Ptr = nullptr; /*0x141098192*/
        v45->_Rep = nullptr; /*0x141098195*/
        result->_Ptr = v46; /*0x141098199*/
        v48 = result->_Rep; /*0x14109819c*/
        result->_Rep = v47; /*0x1410981a0*/
        if ( v48 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v48->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410981b3*/
        {
          v48->_Destroy(this: v48); /*0x1410981bb*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v48->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410981c7*/
            v48->_Delete_this(this: v48); /*0x1410981cf*/
        }
        v12 = v71._Rep; /*0x1410981d2*/
        break; /*0x1410981d6*/
      case ItemTypeDestroy: /*0x141097e20*/
        v49 = RBX::Network::SharedDestroyInstanceItem::read(result: &v72, replicator: this, inBitstream); /*0x1410981e5*/
        v50 = v49->_Ptr; /*0x1410981ea*/
        v51 = v49->_Rep; /*0x1410981ed*/
        v49->_Ptr = nullptr; /*0x1410981f1*/
        v49->_Rep = nullptr; /*0x1410981f4*/
        result->_Ptr = v50; /*0x1410981f8*/
        v52 = result->_Rep; /*0x1410981fb*/
        result->_Rep = v51; /*0x1410981ff*/
        if ( v52 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v52->_Uses, 0xFFFFFFFF) == 1 ) /*0x141098212*/
        {
          v52->_Destroy(this: v52); /*0x14109821a*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v52->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141098226*/
            v52->_Delete_this(this: v52); /*0x14109822e*/
        }
        v12 = v72._Rep; /*0x141098231*/
        break; /*0x141098235*/
      default:
        v53 = RBX::Network::Replicator::deserializeItem(this, result: &v73, inBitstream, itemType); /*0x141098244*/
        v54 = v53->_Ptr; /*0x141098249*/
        v55 = v53->_Rep; /*0x14109824c*/
        v53->_Ptr = nullptr; /*0x141098250*/
        v53->_Rep = nullptr; /*0x141098253*/
        result->_Ptr = v54; /*0x141098257*/
        v56 = result->_Rep; /*0x14109825a*/
        result->_Rep = v55; /*0x14109825e*/
        if ( v56 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v56->_Uses, 0xFFFFFFFF) == 1 ) /*0x141098271*/
        {
          v56->_Destroy(this: v56); /*0x141098279*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v56->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141098285*/
            v56->_Delete_this(this: v56); /*0x14109828d*/
        }
        v12 = v73._Rep; /*0x141098290*/
        break; /*0x141098290*/
    }
    if ( v12 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v12->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410982a3*/
    {
      v12->_Destroy(this: v12); /*0x1410982ab*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v12->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410982b5*/
        v12->_Delete_this(this: v12); /*0x1410982bd*/
    }
    __wind /*0xf1c0000000000058*/
    {
      RBX::Profiler::leaveRegion(token: profscope1715.region.token, enterTimestamp: profscope1715.region.timestamp); /*0x1410982cb*/
    }
    __unwind
    {
      __std_terminate(a1: v57, a2: &v59); /*0x142f39fa8*/
    }
    v58 = result; /*0x1410982d1*/
  }
  __unwind
  {
    if ( (v60 & 1) != 0 ) /*0x1431ebd91*/
    {
      v60 &= ~1u; /*0x1431ebd93*/
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)result); /*0x1431ebd9e*/
    }
  }
  return v58; /*0x1410982d4*/
}

// Address: 0x141098390 | Name: ?deserializePropertyVersionInfo@ClientReplicator@Network@RBX@@UEAAXAEAVNetworkStream@23@AEAUChangeVersionInfo@23@@Z
void __fastcall RBX::Network::ClientReplicator::deserializePropertyVersionInfo(
        RBX::Network::ClientReplicator *this,
        RBX::Network::NetworkStream *bitStream,
        RBX::Network::ChangeVersionInfo *out)
{
  out->versionReset = RBX::Network::NetworkStream::readBool(this: bitStream); /*0x1410983a1*/
}

// Address: 0x1410983b0 | Name: ?deserializeSFFlags@ClientReplicator@Network@RBX@@UEAAXAEAVNetworkStream@23@@Z
void __fastcall RBX::Network::ClientReplicator::deserializeSFFlags(
        RBX::Network::ClientReplicator *this,
        RBX::Network::NetworkStream *inBitStream)
{
  FLog *v4; // rcx
  unsigned __int16 i; // bx
  char *c_str; // rdx
  unsigned __int64 v7; // r8
  char *v8; // rdx
  unsigned __int64 v9; // r8
  char *Ptr; // rcx
  char *v11; // rcx
  RBX::DataModel *v12; // rax
  std::pair<boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::string > >,bool> result; // [rsp+20h] [rbp-50h] BYREF
  std::string stdName; // [rsp+30h] [rbp-40h] BYREF
  std::string stdValue; // [rsp+50h] [rbp-20h] BYREF
  RakNet::RakString varValue; // [rsp+B0h] [rbp+40h] BYREF
  RakNet::RakString name; // [rsp+B8h] [rbp+48h] BYREF

  for ( i = RBX::Network::NetworkStream::readUInt16(this: inBitStream); i != 0; --i ) /*0x1410983d7*/
  {
    RakNet::RakString::RakString(this: &name); /*0x1410983f8*/
    __wind /*0xf1c0000000000058*/
    {
      RakNet::RakString::RakString(this: &varValue); /*0x141098402*/
      __wind /*0xf1c000000000004c*/
      {
        RBX::Network::NetworkStream::readRakString_Deprecated(this: inBitStream, out: &name); /*0x14109840f*/
        RBX::Network::NetworkStream::readRakString_Deprecated(this: inBitStream, out: &varValue); /*0x14109841b*/
        c_str = name.sharedString->c_str; /*0x141098424*/
        stdName._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141098428*/
        stdName._Mypair._Myval2._Mysize = 0; /*0x14109842c*/
        stdName._Mypair._Myval2._Myres = 15; /*0x141098430*/
        v7 = -1; /*0x14109843c*/
        do /*0x14109844b*/
          ++v7; /*0x141098443*/
        while ( c_str[v7] != 0 ); /*0x14109844b*/
        std::string::assign(this: &stdName, _Ptr: c_str, _Count: v7); /*0x141098451*/
        __wind /*0xf1c000000000001c*/
        {
          v8 = varValue.sharedString->c_str; /*0x14109845b*/
          stdValue._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109845f*/
          stdValue._Mypair._Myval2._Mysize = 0; /*0x141098463*/
          stdValue._Mypair._Myval2._Myres = 15; /*0x141098467*/
          v9 = -1; /*0x141098473*/
          do /*0x141098488*/
            ++v9; /*0x141098480*/
          while ( v8[v9] != 0 ); /*0x141098488*/
          std::string::assign(this: &stdValue, _Ptr: v8, _Count: v9); /*0x14109848e*/
          __wind /*0xf1c0000000000010*/
          {
            FLog::SetValueFromServer(name: (const rtc::webrtc_checks_impl::ToStringVal *)&stdName, value: &stdValue); /*0x14109849c*/
            boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<std::string>,std::string,boost::hash<std::string>,std::equal_to<std::string>>>::emplace_impl<std::string const &>( /*0x1410984b4*/
              this: &this->remoteKnownSFFlags.table_,
              &result,
              k: &stdName,
              <args_0>: &stdName);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&stdValue); /*0xf1c0000000000008*/
          }
          if ( stdValue._Mypair._Myval2._Myres >= 0x10 ) /*0x1410984c2*/
          {
            Ptr = stdValue._Mypair._Myval2._Bx._Ptr; /*0x1410984c7*/
            if ( stdValue._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410984d5*/
            {
              Ptr = *((char **)stdValue._Mypair._Myval2._Bx._Ptr - 1); /*0x1410984db*/
              if ( (unsigned __int64)(stdValue._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410984ea*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410985a4*/
            }
            operator delete(ptr: Ptr); /*0x1410984f0*/
          }
          stdValue._Mypair._Myval2._Mysize = 0; /*0x1410984f5*/
          stdValue._Mypair._Myval2._Myres = 15; /*0x1410984f9*/
          stdValue._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141098501*/
          if ( stdName._Mypair._Myval2._Myres >= 0x10 ) /*0x14109850d*/
          {
            v11 = stdName._Mypair._Myval2._Bx._Ptr; /*0x141098512*/
            if ( stdName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141098520*/
            {
              v11 = *((char **)stdName._Mypair._Myval2._Bx._Ptr - 1); /*0x141098526*/
              if ( (unsigned __int64)(stdName._Mypair._Myval2._Bx._Ptr - v11 - 8) > 0x1F ) /*0x141098535*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410985ab*/
            }
            operator delete(ptr: v11); /*0x141098537*/
          }
          stdName._Mypair._Myval2._Mysize = 0; /*0x14109853c*/
          stdName._Mypair._Myval2._Myres = 15; /*0x141098540*/
          stdName._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141098548*/
          RakNet::RakString::~RakString(this: &varValue); /*0x141098550*/
          RakNet::RakString::~RakString(this: &name); /*0x14109855a*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&stdName); /*0xf1c000000000002c*/
        }
      }
      __unwind
      {
        RakNet::RakString::~RakString(this: &varValue); /*0xf1c0000000000038*/
      }
    }
    __unwind
    {
      RakNet::RakString::~RakString(this: &name); /*0xf1c0000000000044*/
    }
  }
  this->haveLoadedRemoteSFFlagNames = true; /*0x141098568*/
  FLog::SetSynchronizedVariablesState(this: v4); /*0x14109856f*/
  v12 = RBX::DataModel::get(context: this); /*0x141098577*/
  if ( v12 != nullptr ) /*0x14109857f*/
    RBX::DataModel::setIsSFFlagsLoaded(this: v12, val: true); /*0x141098586*/
}

// Address: 0x141098b30 | Name: ?filterReceivedChangedProperty@ClientReplicator@Network@RBX@@MEAA?AW4FilterResult@23@PEAVInstance@3@AEBVPropertyDescriptor@Reflection@3@GAEBUChangeVersionInfo@23@@Z
_BOOL8 __fastcall RBX::Network::ClientReplicator::filterReceivedChangedProperty(
        RBX::Network::ClientReplicator *this,
        RBX::LuaSourceContainer *instance,
        RBX::Reflection::PropDescriptor<RBX::ModuleScript,RBX::ProtectedString> *desc,
        unsigned __int16 propertyId)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v7; // rax
  _BOOL8 result; // rax

  result = false; /*0x141098bbd*/
  if ( (desc == (RBX::Reflection::PropDescriptor<RBX::ModuleScript,RBX::ProtectedString> *)&RBX::Script::prop_EmbeddedSourceCode /*0x141098b5b*/
     || desc == &RBX::ModuleScript::prop_Source)
    && instance != nullptr )
  {
    descriptor = instance->descriptor; /*0x141098b62*/
    v7 = RBX::Reflection::Class_getDescriptorPtr<RBX::LuaSourceContainer>(); /*0x141098b66*/
    if ( descriptor->index - (unsigned int)v7->index <= v7->descendantCount /*0x141098bbb*/
      && this->isCloudEdit(this)
      && this->players != nullptr
      && RBX::LuaSourceContainer::getCurrentEditor(this: instance) == this->players->localPlayer._Ptr )
    {
      return true; /*0x141098b56*/
    }
  }
  return result; /*0x141098bc2*/
}

// Address: 0x141098be0 | Name: ?filterReceivedParent@ClientReplicator@Network@RBX@@MEAA?AW4FilterResult@23@PEAVInstance@3@0@Z
__int64 __fastcall RBX::Network::ClientReplicator::filterReceivedParent(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *instance,
        RBX::Instance *parent)
{
  if ( !instance->isParentLocked ) /*0x141098be8*/
    return 0; /*0x141098c05*/
  RBX::StandardOut::printf(type: MESSAGE_WARNING, format: "trying to set locked parent!", parent); /*0x141098bf6*/
  return 1; /*0x141098c00*/
}

// Address: 0x141098c10 | Name: ?filterReplicatorChangedProperty@ClientReplicator@Network@RBX@@MEAA?AW4FilterResult@23@PEAVInstance@3@AEBVPropertyDescriptor@Reflection@3@@Z
__int64 __fastcall RBX::Network::ClientReplicator::filterReplicatorChangedProperty(
        RBX::Network::ClientReplicator *this,
        RBX::Humanoid *instance,
        const RBX::Reflection::PropertyDescriptor *desc)
{
  RBX::Network::FilterResult v5; // eax
  RBX::Network::FilterResult v6; // edi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::ClassRegistrar<RBX::Humanoid,1> *v8; // rax
  RBX::Humanoid *v9; // rcx
  bool v10; // zf
  __int64 result; // rax

  v5 = RBX::Network::Replicator::filterReplicatorChangedProperty(this, instance, desc); /*0x141098c25*/
  v6 = v5; /*0x141098c31*/
  if ( !this->streamingEnabled || v5 != Accept ) /*0x141098c37*/
    return (unsigned int)v6; /*0x141098c37*/
  descriptor = instance->descriptor; /*0x141098c39*/
  v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::Humanoid>(); /*0x141098c3d*/
  v9 = nullptr; /*0x141098c5b*/
  if ( descriptor->index - (unsigned int)v8->desc.index <= v8->desc.descendantCount ) /*0x141098c60*/
    v9 = instance; /*0x141098c60*/
  if ( v9 == nullptr ) /*0x141098c67*/
    return (unsigned int)v6; /*0x141098c67*/
  v10 = RBX::Humanoid::getTorsoSlow(this: v9) == nullptr; /*0x141098c6e*/
  result = (unsigned int)(v6 + 1); /*0x141098c71*/
  if ( !v10 ) /*0x141098c74*/
    return (unsigned int)v6; /*0x141098c76*/
  return result; /*0x141098c78*/
}

// Address: 0x141098c90 | Name: ?findTargetPlayer@ClientReplicator@Network@RBX@@MEBAPEAVPlayer@3@XZ
RBX::Players *__fastcall RBX::Network::ClientReplicator::findTargetPlayer(RBX::Network::ClientReplicator *this)
{
  RBX::Players *result; // rax

  result = this->players; /*0x141098c90*/
  if ( result != nullptr ) /*0x141098c9a*/
    return (RBX::Players *)result->localPlayer._Ptr; /*0x141098c9c*/
  return result; /*0x141098ca3*/
}

// Address: 0x141098d90 | Name: ?getAnalyticsPlaySessionId@ClientReplicator@Network@RBX@@UEAA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@XZ
rtc::webrtc_checks_impl::ToStringVal *__fastcall RBX::Network::ClientReplicator::getAnalyticsPlaySessionId(
        RBX::Network::ClientReplicator *this,
        rtc::webrtc_checks_impl::ToStringVal *result)
{
  RBX::Instance *parent; // rsi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::ClassRegistrar<RBX::Network::Client,1> *v5; // rax

  parent = this->parent; /*0x141098d9a*/
  if ( parent != nullptr /*0x141098dd5*/
    && (descriptor = parent->descriptor,
        v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(),
        descriptor->index - (unsigned int)v5->desc.index <= v5->desc.descendantCount) )
  {
    std::string::string(this: result, __that: (const rtc::webrtc_checks_impl::ToStringVal *)&parent[2].children); /*0x141098de1*/
    return result; /*0x141098de6*/
  }
  else
  {
    result->val._Mypair._Myval2._Bx._Ptr = nullptr; /*0x141098dfb*/
    result->val._Mypair._Myval2._Myres = 15; /*0x141098dfe*/
    result->val._Mypair._Myval2._Mysize = 0; /*0x141098e06*/
    result->val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141098e0a*/
    return result; /*0x141098e0c*/
  }
}

// Address: 0x141098e20 | Name: ?getAndReportJobsStatsReportInCaptureInterval@ClientReplicator@Network@RBX@@CAXAEAVPoints@InfluxDb@Analytics@3@@Z
void __fastcall RBX::Network::ClientReplicator::getAndReportJobsStatsReportInCaptureInterval(
        RBX::Analytics::InfluxDb::Points *basePoints)
{
  unsigned __int64 v2; // rsi
  MicroProfileTimerStat *v3; // rax
  MicroProfileTimerStat *Myfirst; // r14
  float v5; // xmm7_4
  MicroProfileTimerStat *Mylast; // r15
  MicroProfileTimerStat *Myend; // r13
  std::_String_constructor_concat_tag v8; // si
  std::_String_constructor_concat_tag v9; // r14
  std::_String_constructor_concat_tag v10; // di
  std::_String_constructor_concat_tag v11; // bl
  long double average; // xmm6_8
  unsigned __int64 _Left_size; // rcx
  const char *Ptr; // r9
  RBX::Graphics::ProfilerAdorn::Item *p_resource; // rdx
  char *v16; // rcx
  long double max; // xmm6_8
  unsigned __int64 Mysize; // rcx
  const char *v19; // r9
  RBX::Graphics::ProfilerAdorn::Item *v20; // rdx
  char *v21; // rcx
  long double callAverage; // xmm6_8
  unsigned __int64 v23; // rcx
  const char *v24; // r9
  RBX::Graphics::ProfilerAdorn::Item *v25; // rdx
  char *v26; // rcx
  long double total; // xmm6_8
  unsigned __int64 v28; // rcx
  const char *v29; // r9
  RBX::Graphics::ProfilerAdorn::Item *v30; // rdx
  char *v31; // rcx
  int v32; // ebx
  char *v33; // rax
  char *v34; // rcx
  MicroProfileTimerStat *v35; // rbx
  MicroProfileTimerStat *v36; // rdi
  unsigned __int64 Myres; // rdx
  char *v38; // rcx
  MicroProfileTimerStat *v39; // rax
  __int64 v40; // rcx
  __int64 v41; // [rsp+8h] [rbp-89h] BYREF
  RBX::Profiler::Scope profscope4313; // [rsp+40h] [rbp-51h] BYREF
  std::vector<MicroProfileTimerStat> timersStats; // [rsp+50h] [rbp-41h] BYREF
  __int64 v44; // [rsp+68h] [rbp-29h]
  RBX::Graphics::ProfilerAdorn::Item resource; // [rsp+70h] [rbp-21h] BYREF
  int framesCaptured; // [rsp+100h] [rbp+6Fh] BYREF
  unsigned __int64 v47; // [rsp+108h] [rbp+77h]

  if ( _TSS0_536 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x141098e69*/
  {
    __wind /*0xf1c000000000001c*/
    {
      Init_thread_header(pOnce: &_TSS0_536); /*0x1410993b6*/
      if ( _TSS0_536 == -1 ) /*0x1410993c2*/
      {
        proftoken4313 = RBX::Profiler::getToken(group: "Network", name: "GetJobStats", color: -1); /*0x1410993e1*/
        Init_thread_footer(pOnce: &_TSS0_536); /*0x1410993ef*/
      }
    }
    __unwind
    {
      Init_thread_abort(pOnce: &_TSS0_536); /*0x1431ebde7*/
    }
  }
  v2 = proftoken4313; /*0x141098e6f*/
  v47 = proftoken4313; /*0x141098e76*/
  profscope4313.region.timestamp = proftoken4313; /*0x141098e7a*/
  v3 = (MicroProfileTimerStat *)RBX::Profiler::enterRegion(token: proftoken4313); /*0x141098e81*/
  __wind /*0xf1c00000000000ac*/
  {
    __wind /*0xf1c00000000000b4*/
    {
      Myfirst = v3; /*0x141098e86*/
      timersStats._Mypair._Myval2._Myfirst = v3; /*0x141098e89*/
      *(_OWORD *)&timersStats._Mypair._Myval2._Mylast = 0; /*0x141098e90*/
      v44 = 0; /*0x141098e97*/
      framesCaptured = 0; /*0x141098e9b*/
      RBX::Profiler::dumpProfilerJobsTimers( /*0x141098ea6*/
        timersStats: (std::vector<MicroProfileTimerStat> *)&timersStats._Mypair._Myval2._Mylast,
        &framesCaptured);
      v5 = 0.0; /*0x141098eab*/
      Mylast = timersStats._Mypair._Myval2._Mylast; /*0x141098eae*/
      Myend = timersStats._Mypair._Myval2._Myend; /*0x141098eb2*/
      if ( timersStats._Mypair._Myval2._Mylast != timersStats._Mypair._Myval2._Myend ) /*0x141098eb9*/
      {
        v8 = (std::_String_constructor_concat_tag)framesCaptured; /*0x141098ebf*/
        v9 = (std::_String_constructor_concat_tag)framesCaptured; /*0x141098ec3*/
        v10 = (std::_String_constructor_concat_tag)framesCaptured; /*0x141098ec8*/
        v11 = (std::_String_constructor_concat_tag)framesCaptured; /*0x141098ecc*/
        do /*0x1410991a0*/
        {
          average = Mylast->timerStats.average; /*0x141098ee7*/
          _Left_size = Mylast->name._Mypair._Myval2._Mysize; /*0x141098eea*/
          if ( 0x7FFFFFFFFFFFFFFFLL - _Left_size < 4 ) /*0x141098ef5*/
            std::_Xlen_string(); /*0x1410993a9*/
          Ptr = (const char *)Mylast; /*0x141098efb*/
          if ( Mylast->name._Mypair._Myval2._Myres >= 0x10 ) /*0x141098f03*/
            Ptr = Mylast->name._Mypair._Myval2._Bx._Ptr; /*0x141098f05*/
          std::string::string( /*0x141098f26*/
            this: &resource.text,
            __formal: v8,
            _Source_of_al: &Mylast->name,
            _Left_ptr: Ptr,
            _Left_size,
            _Right_ptr: "_avg",
            _Right_size: 4u);
          __eh34_enter_wind_state(2, 3); /*0xf1c00000000000a4*/
          p_resource = &resource; /*0x141098f2c*/
          if ( resource.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141098f35*/
            p_resource = (RBX::Graphics::ProfilerAdorn::Item *)resource.text._Mypair._Myval2._Bx._Ptr; /*0x141098f35*/
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x141098f40*/
            this: basePoints,
            name: p_resource->text._Mypair._Myval2._Bx._Buf,
            value: average);
          if ( __eh34_unwind(3) ) /*0xf1c0000000000098*/
          {
unwind_state_3:
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: &resource); /*0xf1c0000000000044*/
            __eh34_continue_unwinding(3, 2); /*0xf1c0000000000048*/
          }
          __eh34_exit_wind_state(3, 2); /*0xf1c000000000009c*/
          if ( resource.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141098f4e*/
          {
            v16 = resource.text._Mypair._Myval2._Bx._Ptr; /*0x141098f53*/
            if ( resource.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141098f61*/
            {
              v16 = *((char **)resource.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141098f67*/
              if ( (unsigned __int64)(resource.text._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x141098f76*/
                _invalid_parameter_noinfo_noreturn(); /*0x141099283*/
            }
            operator delete(ptr: v16); /*0x141098f7c*/
          }
          max = Mylast->timerStats.max; /*0x141098f87*/
          Mysize = Mylast->name._Mypair._Myval2._Mysize; /*0x141098f8a*/
          if ( 0x7FFFFFFFFFFFFFFFLL - Mysize < 4 ) /*0x141098f9f*/
            std::_Xlen_string(); /*0x141099405*/
          v19 = (const char *)Mylast; /*0x141098fa5*/
          if ( Mylast->name._Mypair._Myval2._Myres >= 0x10 ) /*0x141098fad*/
            v19 = Mylast->name._Mypair._Myval2._Bx._Ptr; /*0x141098faf*/
          std::string::string( /*0x141098fd7*/
            this: &resource.text,
            __formal: v9,
            _Source_of_al: &Mylast->name,
            _Left_ptr: v19,
            _Left_size: Mysize,
            _Right_ptr: "_max",
            _Right_size: 4u);
          __eh34_enter_wind_state(2, 3); /*0xf1c0000000000090*/
          v20 = &resource; /*0x141098fdd*/
          if ( resource.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141098fe6*/
            v20 = (RBX::Graphics::ProfilerAdorn::Item *)resource.text._Mypair._Myval2._Bx._Ptr; /*0x141098fe6*/
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x141098ff1*/
            this: basePoints,
            name: v20->text._Mypair._Myval2._Bx._Buf,
            value: max);
          if ( __eh34_unwind(3) ) /*0xf1c0000000000084*/
            goto unwind_state_3; /*0xf1c0000000000084*/
          __eh34_exit_wind_state(3, 2); /*0xf1c0000000000088*/
          if ( resource.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141098fff*/
          {
            v21 = resource.text._Mypair._Myval2._Bx._Ptr; /*0x141099004*/
            if ( resource.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141099012*/
            {
              v21 = *((char **)resource.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141099018*/
              if ( (unsigned __int64)(resource.text._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x141099027*/
                _invalid_parameter_noinfo_noreturn(); /*0x14109928a*/
            }
            operator delete(ptr: v21); /*0x14109902d*/
          }
          callAverage = Mylast->timerStats.callAverage; /*0x141099038*/
          v23 = Mylast->name._Mypair._Myval2._Mysize; /*0x14109903b*/
          if ( 0x7FFFFFFFFFFFFFFFLL - v23 < 8 ) /*0x141099050*/
            std::_Xlen_string(); /*0x1410993ff*/
          v24 = (const char *)Mylast; /*0x141099056*/
          if ( Mylast->name._Mypair._Myval2._Myres >= 0x10 ) /*0x14109905e*/
            v24 = Mylast->name._Mypair._Myval2._Bx._Ptr; /*0x141099060*/
          std::string::string( /*0x141099088*/
            this: &resource.text,
            __formal: v10,
            _Source_of_al: &Mylast->name,
            _Left_ptr: v24,
            _Left_size: v23,
            _Right_ptr: "_callAvg",
            _Right_size: 8u);
          __eh34_enter_wind_state(2, 3); /*0xf1c000000000007c*/
          v25 = &resource; /*0x14109908e*/
          if ( resource.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141099097*/
            v25 = (RBX::Graphics::ProfilerAdorn::Item *)resource.text._Mypair._Myval2._Bx._Ptr; /*0x141099097*/
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x1410990a2*/
            this: basePoints,
            name: v25->text._Mypair._Myval2._Bx._Buf,
            value: callAverage);
          if ( __eh34_unwind(3) ) /*0xf1c0000000000070*/
            goto unwind_state_3; /*0xf1c0000000000070*/
          __eh34_exit_wind_state(3, 2); /*0xf1c0000000000074*/
          if ( resource.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410990b0*/
          {
            v26 = resource.text._Mypair._Myval2._Bx._Ptr; /*0x1410990b5*/
            if ( resource.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410990c3*/
            {
              v26 = *((char **)resource.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410990c9*/
              if ( (unsigned __int64)(resource.text._Mypair._Myval2._Bx._Ptr - v26 - 8) > 0x1F ) /*0x1410990d8*/
                _invalid_parameter_noinfo_noreturn(); /*0x141099291*/
            }
            operator delete(ptr: v26); /*0x1410990de*/
          }
          total = Mylast->timerStats.total; /*0x1410990e9*/
          v28 = Mylast->name._Mypair._Myval2._Mysize; /*0x1410990ec*/
          if ( 0x7FFFFFFFFFFFFFFFLL - v28 < 6 ) /*0x141099101*/
            std::_Xlen_string(); /*0x1410993f9*/
          v29 = (const char *)Mylast; /*0x141099107*/
          if ( Mylast->name._Mypair._Myval2._Myres >= 0x10 ) /*0x14109910f*/
            v29 = Mylast->name._Mypair._Myval2._Bx._Ptr; /*0x141099111*/
          std::string::string( /*0x141099138*/
            this: &resource.text,
            __formal: v11,
            _Source_of_al: &Mylast->name,
            _Left_ptr: v29,
            _Left_size: v28,
            _Right_ptr: "_total",
            _Right_size: 6u);
          __eh34_enter_wind_state(2, 3); /*0xf1c0000000000068*/
          v30 = &resource; /*0x14109913e*/
          if ( resource.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141099147*/
            v30 = (RBX::Graphics::ProfilerAdorn::Item *)resource.text._Mypair._Myval2._Bx._Ptr; /*0x141099147*/
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x141099152*/
            this: basePoints,
            name: v30->text._Mypair._Myval2._Bx._Buf,
            value: total);
          if ( __eh34_unwind(3) ) /*0xf1c000000000005c*/
            goto unwind_state_3; /*0xf1c000000000005c*/
          __eh34_exit_wind_state(3, 2); /*0xf1c0000000000060*/
          if ( resource.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141099160*/
          {
            v31 = resource.text._Mypair._Myval2._Bx._Ptr; /*0x141099165*/
            if ( resource.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141099173*/
            {
              v31 = *((char **)resource.text._Mypair._Myval2._Bx._Ptr - 1); /*0x141099179*/
              if ( (unsigned __int64)(resource.text._Mypair._Myval2._Bx._Ptr - v31 - 8) > 0x1F ) /*0x141099188*/
                _invalid_parameter_noinfo_noreturn(); /*0x141099298*/
            }
            operator delete(ptr: v31); /*0x14109918e*/
          }
          v5 = v5 + Mylast->timerStats.total; /*0x141099193*/
          ++Mylast; /*0x141099199*/
        }
        while ( Mylast != Myend ); /*0x1410991a0*/
        v2 = v47; /*0x1410991a6*/
        Myfirst = timersStats._Mypair._Myval2._Myfirst; /*0x1410991aa*/
      }
      RBX::Analytics::InfluxDb::Points::addPoint(this: basePoints, name: "DmJobTotal", value: v5); /*0x1410991bf*/
      v32 = DFInt::ClientReportInitExpJobStatsHundredthPercent; /*0x1410991c4*/
      resource.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410991cd*/
      resource.text._Mypair._Myval2._Mysize = 0; /*0x1410991d1*/
      resource.text._Mypair._Myval2._Myres = 15; /*0x1410991d5*/
      v33 = (char *)operator new(size: 0x20u); /*0x1410991e5*/
      resource.text._Mypair._Myval2._Mysize = 31; /*0x1410991ea*/
      resource.text._Mypair._Myval2._Myres = 31; /*0x1410991f2*/
      strcpy(v33, "JobTimerDuringInitialExperience"); /*0x141099201*/
      resource.text._Mypair._Myval2._Bx._Ptr = v33; /*0x141099233*/
      __eh34_enter_wind_state(2, 3); /*0xf1c0000000000054*/
      RBX::Analytics::InfluxDb::Points::report( /*0x141099244*/
        this: basePoints,
        resource: &resource.text,
        throttleHundredthsPercentage: v32,
        blocking: false);
      if ( __eh34_unwind(3) ) /*0xf1c0000000000040*/
        goto unwind_state_3; /*0xf1c0000000000040*/
      __eh34_exit_wind_state(3, 2); /*0xf1c000000000004c*/
      if ( resource.text._Mypair._Myval2._Myres >= 0x10 ) /*0x141099252*/
      {
        v34 = resource.text._Mypair._Myval2._Bx._Ptr; /*0x141099257*/
        if ( resource.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x141099265*/
        {
          v34 = *((char **)resource.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14109926b*/
          if ( (unsigned __int64)(resource.text._Mypair._Myval2._Bx._Ptr - v34 - 8) > 0x1F ) /*0x14109927a*/
            _invalid_parameter_noinfo_noreturn(); /*0x14109927c*/
        }
        operator delete(ptr: v34); /*0x14109929f*/
      }
      v35 = timersStats._Mypair._Myval2._Mylast; /*0x1410992a5*/
      if ( timersStats._Mypair._Myval2._Mylast != nullptr ) /*0x1410992ac*/
      {
        v36 = timersStats._Mypair._Myval2._Myend; /*0x1410992b2*/
        if ( timersStats._Mypair._Myval2._Mylast != timersStats._Mypair._Myval2._Myend ) /*0x1410992b9*/
        {
          do /*0x14109930c*/
          {
            Myres = v35->name._Mypair._Myval2._Myres; /*0x1410992c0*/
            if ( Myres >= 0x10 ) /*0x1410992c8*/
            {
              v38 = v35->name._Mypair._Myval2._Bx._Ptr; /*0x1410992ca*/
              if ( Myres + 1 >= 0x1000 ) /*0x1410992d7*/
              {
                if ( (unsigned __int64)&v38[-*((_QWORD *)v38 - 1) - 8] > 0x1F ) /*0x1410992ec*/
                  goto LABEL_68; /*0x1410992ec*/
                v38 = *((char **)v38 - 1); /*0x1410992ee*/
              }
              operator delete(ptr: v38); /*0x1410992f1*/
            }
            v35->name._Mypair._Myval2._Mysize = 0; /*0x1410992f6*/
            v35->name._Mypair._Myval2._Myres = 15; /*0x1410992fa*/
            v35->name._Mypair._Myval2._Bx._Buf[0] = 0; /*0x141099302*/
            ++v35; /*0x141099305*/
          }
          while ( v35 != v36 ); /*0x14109930c*/
          v35 = timersStats._Mypair._Myval2._Mylast; /*0x14109930e*/
        }
        v39 = v35; /*0x14109933c*/
        if ( (unsigned __int64)(48 * ((v44 - (__int64)v35) / 48)) >= 0x1000 ) /*0x141099346*/
        {
          v35 = *(MicroProfileTimerStat **)&v35[-1].timerStats.callAverage; /*0x14109934c*/
          if ( (unsigned __int64)((char *)v39 - (char *)v35 - 8) > 0x1F ) /*0x14109935b*/
LABEL_68:
            _invalid_parameter_noinfo_noreturn(); /*0x14109935d*/
        }
        operator delete(ptr: v35); /*0x141099367*/
        *(_OWORD *)&timersStats._Mypair._Myval2._Mylast = 0; /*0x14109936f*/
        v44 = 0; /*0x141099374*/
      }
    }
    __unwind
    {
      std::vector<Luau::ErrorSnapshot>::_Tidy(this: (std::vector<Luau::ErrorSnapshot> *)&timersStats._Mypair._Myval2._Mylast); /*0xf1c00000000000c4*/
    }
  }
  __unwind
  {
    RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)&profscope4313.region.timestamp); /*0xf1c00000000000d0*/
  }
  __wind /*0xf1c00000000000d8*/
  {
    RBX::Profiler::leaveRegion(token: v2, enterTimestamp: (unsigned __int64)Myfirst); /*0x14109937e*/
  }
  __unwind
  {
    __std_terminate(a1: v40, a2: &v41); /*0x142f39fa8*/
  }
}

// Address: 0x141099410 | Name: ?getAndResetMaxGuidsAndTotalRegionRemovalItems@ClientReplicator@Network@RBX@@QEAA?AU?$pair@IH@std@@XZ
std::pair<unsigned int,int> *__fastcall RBX::Network::ClientReplicator::getAndResetMaxGuidsAndTotalRegionRemovalItems(
        RBX::Network::ClientReplicator *this,
        std::pair<unsigned int,int> *result)
{
  result->first = this->maxGuidsPerRegionRemovalItem; /*0x141099416*/
  result->second = this->numRegionRemovalItems; /*0x14109941e*/
  *(_QWORD *)&this->numRegionRemovalItems = 0; /*0x141099423*/
  return result; /*0x14109942d*/
}

// Address: 0x141099430 | Name: ?getAvgPrefetchDistanceAndReset@ClientReplicator@Network@RBX@@QEAANXZ
double __fastcall RBX::Network::ClientReplicator::getAvgPrefetchDistanceAndReset(RBX::Network::ClientReplicator *this)
{
  int numPrefetches; // eax
  double totalPrefetchDistance; // xmm0_8

  numPrefetches = this->numPrefetches; /*0x141099430*/
  if ( numPrefetches != 0 ) /*0x141099438*/
  {
    totalPrefetchDistance = this->totalPrefetchDistance; /*0x14109943a*/
    this->totalPrefetchDistance = 0.0; /*0x14109944a*/
    return totalPrefetchDistance / (double)numPrefetches; /*0x141099455*/
  }
  else
  {
    this->totalPrefetchDistance = 0.0; /*0x14109945d*/
    return 0.0; /*0x14109945a*/
  }
}

// Address: 0x141099480 | Name: ?getGCDistance@ClientReplicator@Network@RBX@@QEBAFXZ
RBX::Network::ClientReplicator::GCJob *__fastcall RBX::Network::ClientReplicator::getGCDistance(
        RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *result; // rax

  result = this->gcJob._Ptr; /*0x141099480*/
  if ( result != nullptr ) /*0x14109948a*/
    return (RBX::Network::ClientReplicator::GCJob *)(unsigned __int16)result->gcRegionDistance; /*0x14109948c*/
  return result; /*0x141099493*/
}

// Address: 0x1410994a0 | Name: ?getNumGCsAndReset@ClientReplicator@Network@RBX@@QEAA_JXZ
__int64 __fastcall RBX::Network::ClientReplicator::getNumGCsAndReset(RBX::Network::ClientReplicator *this)
{
  __int64 result; // rax

  result = this->numGCs; /*0x1410994a0*/
  this->numGCs = 0; /*0x1410994a7*/
  return result; /*0x1410994b2*/
}

// Address: 0x1410994c0 | Name: ?getNumPrefetchesAndReset@ClientReplicator@Network@RBX@@QEAAHXZ
__int64 __fastcall RBX::Network::ClientReplicator::getNumPrefetchesAndReset(RBX::Network::ClientReplicator *this)
{
  __int64 result; // rax

  result = (unsigned int)this->numPrefetches; /*0x1410994c0*/
  this->numPrefetches = 0; /*0x1410994c6*/
  return result; /*0x1410994d0*/
}

// Address: 0x1410994e0 | Name: ?getReplicatedParent@ClientReplicator@Network@RBX@@MEBAPEAVInstance@3@PEAV43@@Z
RBX::Instance *__fastcall RBX::Network::ClientReplicator::getReplicatedParent(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *child)
{
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Instance const * const,RBX::Guid> > > > *v3; // rcx
  std::_List_node<std::pair<RBX::Instance const * const,RBX::Guid>,void *> *Ptr; // rax
  std::_List_node<std::pair<RBX::Instance const * const,RBX::Guid>,void *> *Myhead; // r8
  std::_List_node<std::pair<RBX::Instance const * const,RBX::Guid>,void *> *v6; // rcx
  RBX::GuidItem<RBX::Instance>::Registry *px; // rdi
  const RBX::Guid *p_second; // rbx
  std::_Ref_count_base *v9; // rbx
  RBX::Instance *v10; // rdi
  unsigned __int64 v11; // rdx
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> > > > > *Myfirst; // rax
  std::_List_node<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> >,void *> *v13; // rcx
  std::_List_node<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> >,void *> *v14; // r9
  std::_List_node<std::pair<RBX::Guid const ,std::weak_ptr<RBX::Instance> >,void *> *v15; // rdx
  std::_Ref_count_base *Rep; // r8
  signed __int32 Uses; // eax
  signed __int32 v18; // ett
  std::shared_ptr<RBX::Instance> replicatedParent; // [rsp+20h] [rbp-18h] BYREF
  _Mtx_t p_mx; // [rsp+50h] [rbp+18h] BYREF

  if ( (*((_DWORD *)&child->completeness + 2) & 0x40000000) == 0 ) /*0x1410994fc*/
    return child->parent; /*0x1410994fc*/
  v3 = &this->replicatedParentMap._Vec._Mypair._Myval2._Myfirst[2 /*0x1410995a6*/
                                                              * ((0x100000001B3LL
                                                                * (HIBYTE(child)
                                                                 ^ (0x100000001B3LL
                                                                  * (BYTE6(child)
                                                                   ^ (0x100000001B3LL
                                                                    * (BYTE5(child)
                                                                     ^ (0x100000001B3LL
                                                                      * (BYTE4(child)
                                                                       ^ (0x100000001B3LL
                                                                        * (BYTE3(child)
                                                                         ^ (0x100000001B3LL
                                                                          * (BYTE2(child)
                                                                           ^ (0x100000001B3LL
                                                                            * (BYTE1(child)
                                                                             ^ (0x100000001B3LL
                                                                              * ((unsigned __int8)child
                                                                               ^ 0xCBF29CE484222325uLL))))))))))))))))
                                                               & this->replicatedParentMap._Mask)];
  Ptr = v3[1]._Ptr; /*0x1410995ad*/
  Myhead = this->replicatedParentMap._List._Mypair._Myval2._Myhead; /*0x1410995b1*/
  if ( Ptr == Myhead ) /*0x1410995bb*/
    return child->parent; /*0x1410995bb*/
  v6 = v3->_Ptr; /*0x1410995c1*/
  if ( child != Ptr->_Myval.first ) /*0x1410995c8*/
  {
    while ( Ptr != v6 ) /*0x1410995d3*/
    {
      Ptr = Ptr->_Prev; /*0x1410995d9*/
      if ( child == Ptr->_Myval.first ) /*0x1410995e1*/
        goto LABEL_6; /*0x1410995e1*/
    }
    return child->parent; /*0x1410995d3*/
  }
LABEL_6:
  if ( Ptr == nullptr ) /*0x1410995e6*/
    Ptr = this->replicatedParentMap._List._Mypair._Myval2._Myhead; /*0x1410995e6*/
  if ( Ptr == Myhead ) /*0x1410995ed*/
    return child->parent; /*0x14109974b*/
  replicatedParent = 0; /*0x1410995f6*/
  px = this->guidRegistry.px; /*0x1410995fc*/
  p_second = &Ptr->_Myval.second; /*0x141099603*/
  if ( Ptr->_Myval.second.scope.peerId.peerId == -1 ) /*0x14109960a*/
  {
    replicatedParent = 0; /*0x14109960c*/
    v9 = nullptr; /*0x141099612*/
    v10 = nullptr; /*0x141099617*/
  }
  else
  {
    __wind /*0xf1c0000000000028*/
    {
      p_mx = (_Mtx_t)&px->mx; /*0x141099625*/
      RBX::InstrumentedMutex<std::mutex>::lock(this: &px->mx); /*0x14109962a*/
      __wind /*0xf1c0000000000004*/
      {
        v11 = 2 * (RBX::hash_value(guid: p_second) & px->map._Mask); /*0x14109963f*/
        Myfirst = px->map._Vec._Mypair._Myval2._Myfirst; /*0x141099642*/
        v13 = Myfirst[v11 + 1]._Ptr; /*0x141099646*/
        v14 = px->map._List._Mypair._Myval2._Myhead; /*0x14109964b*/
        if ( v13 == v14 ) /*0x141099652*/
          goto LABEL_27; /*0x141099652*/
        v15 = Myfirst[v11]._Ptr; /*0x141099654*/
        while ( p_second->index != v13->_Myval.first.index /*0x14109966b*/
             || p_second->scope.peerId.peerId != v13->_Myval.first.scope.peerId.peerId )
        {
          if ( v13 == v15 ) /*0x141099670*/
            goto LABEL_27; /*0x141099670*/
          v13 = v13->_Prev; /*0x141099672*/
        }
        if ( v13 == nullptr ) /*0x14109967b*/
          v13 = px->map._List._Mypair._Myval2._Myhead; /*0x14109967b*/
        if ( v13 == v14 ) /*0x141099682*/
        {
LABEL_27:
          replicatedParent = 0; /*0x1410996cf*/
          v9 = nullptr; /*0x1410996d8*/
          v10 = nullptr; /*0x1410996dd*/
        }
        else
        {
          v10 = nullptr; /*0x141099684*/
          v9 = nullptr; /*0x141099686*/
          Rep = v13->_Myval.second._Rep; /*0x141099688*/
          if ( Rep != nullptr ) /*0x14109968f*/
          {
            Uses = Rep->_Uses; /*0x141099691*/
            if ( Uses != 0 ) /*0x141099697*/
            {
              while ( 1 ) /*0x1410996a3*/
              {
                v18 = Uses; /*0x1410996a3*/
                Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x1410996a3*/
                if ( v18 == Uses ) /*0x1410996a9*/
                  break; /*0x1410996a9*/
                if ( Uses == 0 ) /*0x1410996ad*/
                {
                  replicatedParent._Ptr = nullptr; /*0x1410996af*/
                  replicatedParent._Rep = nullptr; /*0x1410996b4*/
                  goto LABEL_28; /*0x1410996b9*/
                }
              }
              v10 = v13->_Myval.second._Ptr; /*0x1410996bb*/
              v9 = v13->_Myval.second._Rep; /*0x1410996bf*/
            }
          }
          replicatedParent._Ptr = v10; /*0x1410996c3*/
          replicatedParent._Rep = v9; /*0x1410996c8*/
        }
LABEL_28:
        Mtx_unlock_0(a1: p_mx); /*0x1410996e2*/
      }
      __unwind
      {
        std::scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>::~scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>(this: (MicroProfileScopeLock *)&p_mx); /*0xf1c0000000000014*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&replicatedParent); /*0xf1c0000000000020*/
    }
  }
  if ( v9 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v9->_Uses, 0xFFFFFFFF) == 1 ) /*0x141099701*/
  {
    replicatedParent._Rep->_Destroy(this: replicatedParent._Rep); /*0x14109970e*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&replicatedParent._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141099718*/
      replicatedParent._Rep->_Delete_this(this: replicatedParent._Rep); /*0x141099722*/
  }
  return v10; /*0x141099728*/
}

// Address: 0x141099750 | Name: ?getStreamingPauseEnabled@ClientReplicator@Network@RBX@@QEBA_NXZ
RBX::Network::ClientReplicator::GCJob *__fastcall RBX::Network::ClientReplicator::getStreamingPauseEnabled(
        RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *result; // rax

  result = this->gcJob._Ptr; /*0x141099750*/
  if ( result != nullptr ) /*0x14109975a*/
    return (RBX::Network::ClientReplicator::GCJob *)result->pauseEnabled; /*0x14109975c*/
  return result; /*0x141099763*/
}

// Address: 0x141099770 | Name: ?getTargetAddress@ClientReplicator@Network@RBX@@UEBA?AVSystemAddress@3@XZ
RBX::SystemAddress *__fastcall RBX::Network::ClientReplicator::getTargetAddress(
        RBX::Network::ClientReplicator *this,
        RBX::SystemAddress *result)
{
  result->remoteId.peerId = (unsigned int)this->clientAddress; /*0x141099776*/
  return result; /*0x14109977b*/
}

// Address: 0x1410997b0 | Name: ?hasEnoughMemoryToReceiveInstances@ClientReplicator@Network@RBX@@IEAA_NXZ
bool __fastcall RBX::Network::ClientReplicator::hasEnoughMemoryToReceiveInstances(RBX::Network::ClientReplicator *this)
{
  return !this->gcJob._Ptr->emergencyGC && this->memoryLevel >= MEMORYLEVEL_OK; /*0x1410997cb*/
}

// Address: 0x1410998c0 | Name: ?isCloudEdit@ClientReplicator@Network@RBX@@MEBA_NXZ
bool __fastcall RBX::Network::ClientReplicator::isCloudEdit(RBX::Network::ClientReplicator *this)
{
  RBX::Network::Client *parent; // rdi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::ClassRegistrar<RBX::Network::Client,1> *v3; // rax
  bool result; // al

  parent = (RBX::Network::Client *)this->parent; /*0x1410998c6*/
  result = parent != nullptr /*0x141099908*/
        && (descriptor = parent->descriptor,
            v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(),
            descriptor->index - (unsigned int)v3->desc.index <= v3->desc.descendantCount)
        && RBX::Network::Client::isCloudEdit(this: parent);
  return result; /*0x141099903*/
}

// Address: 0x141099920 | Name: ?isCloudTest@ClientReplicator@Network@RBX@@MEBA_NXZ
bool __fastcall RBX::Network::ClientReplicator::isCloudTest(RBX::Network::ClientReplicator *this)
{
  RBX::Instance *parent; // rdi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::ClassRegistrar<RBX::Network::Client,1> *v3; // rax
  bool result; // al

  parent = this->parent; /*0x141099926*/
  result = parent != nullptr /*0x141099964*/
        && (descriptor = parent->descriptor,
            v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(),
            descriptor->index - (unsigned int)v3->desc.index <= v3->desc.descendantCount)
        && parent[13].completeness.numLocalReplicatedChildren == 1;
  return result; /*0x141099967*/
}

// Address: 0x141099980 | Name: ?isLegalSendAttribute@ClientReplicator@Network@RBX@@MEAA_NXZ
bool __fastcall RBX::Network::ClientReplicator::isLegalSendAttribute(RBX::Network::ServerReplicator *this)
{
  return ((unsigned __int8 (*)(void))this->isCloudEdit)() != 0; /*0x14109999c*/
}

// Address: 0x1410999b0 | Name: ?isLegalSendEvent@ClientReplicator@Network@RBX@@MEAA_NPEAVInstance@3@AEBVEventDescriptor@Reflection@3@@Z
bool __fastcall RBX::Network::ClientReplicator::isLegalSendEvent(
        RBX::Network::ClientReplicator *this,
        RBX::ServiceProvider *instance,
        const RBX::Reflection::EventDescriptor *desc)
{
  RBX::Network::StrictNetworkFilter *Myval2; // rcx

  Myval2 = this->strictFilter._Mypair._Myval2; /*0x1410999b4*/
  return Myval2 == nullptr /*0x1410999cc*/
      || (unsigned int)RBX::Network::StrictNetworkFilter::filterEvent(this: Myval2, instance, desc) != 1;
}

// Address: 0x1410999e0 | Name: ?isLegalSendInstance@ClientReplicator@Network@RBX@@MEAA_NPEBVInstance@3@@Z
bool __fastcall RBX::Network::ClientReplicator::isLegalSendInstance(
        RBX::Network::ClientReplicator *this,
        const RBX::Weld *instance)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v5; // rax
  unsigned int v6; // r9d
  bool result; // al
  RBX::Network::StrictNetworkFilter *Myval2; // rcx
  int v9; // eax
  bool v10; // si
  RBX::Network::PropValuePair *Myfirst; // r8
  RBX::Network::PropValuePair *Mylast; // rdi
  rbx::placement_any<RBX::Reflection::Variant::Storage> *p_value; // rbx
  RBX::Network::PropValuePair *v14; // rax
  __int64 v15; // [rsp+0h] [rbp-58h] BYREF
  std::vector<RBX::Network::PropValuePair> emptyPropList; // [rsp+30h] [rbp-28h] BYREF

  if ( instance != nullptr ) /*0x1410999f8*/
  {
    descriptor = instance->descriptor; /*0x1410999fa*/
    v5 = RBX::Reflection::Class_getDescriptorPtr<RBX::Message>(); /*0x1410999fe*/
    v6 = descriptor->index - v5->index; /*0x141099a13*/
    LODWORD(v5) = v5->descendantCount; /*0x141099a16*/
    if ( v6 <= (unsigned int)v5 ) /*0x141099a20*/
      return false; /*0x141099a22*/
  }
  __wind /*0xf1c0000000000020*/
  {
    memset(&emptyPropList, 0, sizeof(emptyPropList)); /*0x141099a37*/
    Myval2 = this->strictFilter._Mypair._Myval2; /*0x141099a44*/
    v10 = true; /*0x141099a70*/
    if ( Myval2 != nullptr ) /*0x141099a4e*/
    {
      v9 = RBX::Network::StrictNetworkFilter::filterNew( /*0x141099a66*/
             this: Myval2,
             instance,
             parent: (RBX::BasePart *)instance->parent,
             propValueList: &emptyPropList,
             toolWeldAccepted: nullptr,
             possibleTool: nullptr);
      if ( v9 == 1 ) /*0x141099a6e*/
        v10 = false; /*0x141099a4e*/
    }
  }
  __unwind
  {
    std::vector<RBX::Network::PropValuePair>::~vector<RBX::Network::PropValuePair>(this: &emptyPropList); /*0xf1c0000000000030*/
  }
  __wind /*0xf1c0000000000038*/
  {
    Myfirst = emptyPropList._Mypair._Myval2._Myfirst; /*0x141099a78*/
    if ( emptyPropList._Mypair._Myval2._Myfirst != nullptr ) /*0x141099a80*/
    {
      Mylast = emptyPropList._Mypair._Myval2._Mylast; /*0x141099a86*/
      if ( emptyPropList._Mypair._Myval2._Myfirst != emptyPropList._Mypair._Myval2._Mylast ) /*0x141099a8e*/
      {
        p_value = &emptyPropList._Mypair._Myval2._Myfirst->value.value; /*0x141099a90*/
        do /*0x141099ab2*/
        {
          if ( p_value->holder != nullptr ) /*0x141099a9a*/
            p_value->holder->destruct(a1: p_value->data); /*0x141099aa4*/
          p_value = (rbx::placement_any<RBX::Reflection::Variant::Storage> *)((char *)p_value + 96); /*0x141099aa7*/
        }
        while ( &p_value[-1].data[48] != (char *)Mylast ); /*0x141099ab2*/
        Myfirst = emptyPropList._Mypair._Myval2._Myfirst; /*0x141099ab4*/
      }
      v14 = Myfirst; /*0x141099ae4*/
      if ( (unsigned __int64)(96 * (emptyPropList._Mypair._Myval2._Myend - Myfirst)) >= 0x1000 ) /*0x141099aee*/
      {
        Myfirst = *(RBX::Network::PropValuePair **)&Myfirst[-1].useDefaultValue; /*0x141099af4*/
        if ( (unsigned __int64)((char *)v14 - (char *)Myfirst - 8) > 0x1F ) /*0x141099b03*/
          _invalid_parameter_noinfo_noreturn(); /*0x141099b05*/
      }
      operator delete(ptr: Myfirst); /*0x141099b0f*/
    }
    result = v10; /*0x141099b14*/
  }
  __unwind
  {
    __std_terminate(a1: Myval2, a2: &v15); /*0x142f39fa8*/
  }
  return result; /*0x141099a24*/
}

// Address: 0x141099b30 | Name: ?isLegalSendProperty@ClientReplicator@Network@RBX@@MEAA_NPEAVInstance@3@AEBVPropertyDescriptor@Reflection@3@@Z
bool __fastcall RBX::Network::ClientReplicator::isLegalSendProperty(
        RBX::Network::ClientReplicator *this,
        RBX::Tool *instance,
        RBX::Reflection::RefPropDescriptor<RBX::Instance,RBX::Instance> *desc)
{
  RBX::Network::StrictNetworkFilter *Myval2; // rcx
  bool result; // al
  const RBX::Reflection::ClassDescriptor *v8; // rbx
  RBX::Reflection::ClassDescriptor *v9; // rax
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v11; // rax

  Myval2 = this->strictFilter._Mypair._Myval2; /*0x141099b4a*/
  if ( Myval2 != nullptr ) /*0x141099b5a*/
  {
    if ( desc == &RBX::Instance::propParent ) /*0x141099b5f*/
      return (unsigned int)RBX::Network::StrictNetworkFilter::filterParent( /*0x141099b6c*/
                             this: Myval2,
                             instance,
                             newParent: (RBX::Backpack *)instance->parent) == 0;
    else
      return (unsigned int)RBX::Network::StrictNetworkFilter::filterChangedProperty( /*0x141099b87*/
                             this: Myval2,
                             (RBX::BasePart *)instance,
                             desc) == 0;
  }
  else if ( desc == &RBX::Instance::propParent /*0x141099bd3*/
         && instance != nullptr
         && (v8 = instance->descriptor,
             v9 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(),
             v8->index - (unsigned int)v9->index <= v9->descendantCount)
         && instance->parent != nullptr )
  {
    return false; /*0x141099bd5*/
  }
  else
  {
    result = desc != (RBX::Reflection::RefPropDescriptor<RBX::Instance,RBX::Instance> *)&RBX::Script::prop_EmbeddedSourceCode /*0x141099c35*/
          && desc != (RBX::Reflection::RefPropDescriptor<RBX::Instance,RBX::Instance> *)&RBX::ModuleScript::prop_Source
          || !this->isCloudEdit(this)
          || instance == nullptr
          || (descriptor = instance->descriptor,
              v11 = RBX::Reflection::Class_getDescriptorPtr<RBX::LuaSourceContainer>(),
              descriptor->index - (unsigned int)v11->index > v11->descendantCount)
          || RBX::LuaSourceContainer::getCurrentEditor(this: (RBX::LuaSourceContainer *)instance) == nullptr;
  }
  return result; /*0x141099b6f*/
}

// Address: 0x141099c60 | Name: ?isReplicatedFirstFinished@ClientReplicator@Network@RBX@@UEAA_NXZ
_BOOL8 __fastcall RBX::Network::ClientReplicator::isReplicatedFirstFinished(RBX::Network::ClientReplicator *this)
{
  return this->replicatedFirstFinished; /*0x141099c67*/
}

// Address: 0x141099c70 | Name: ?kickAllOtherPlayersWithId@ClientReplicator@Network@RBX@@MEAAXV?$shared_ptr@VPlayer@RBX@@@std@@PEA_N1@Z
void __fastcall RBX::Network::ClientReplicator::kickAllOtherPlayersWithId(
        RBX::Network::ClientReplicator *this,
        std::shared_ptr<RBX::File> *player,
        bool *otherReplicatorKicked,
        bool *shouldRejectPacket)
{
  __int64 UserID; // rsi
  RBX::Player *v9; // rax
  bool v10; // al
  std::_Ref_count_base *Rep; // rbx

  __wind /*0xf1c0000000000010*/
  {
    UserID = RBX::Player::getUserID(this: (RBX::Player *)player->_Ptr); /*0x141099c9c*/
    v9 = this->findTargetPlayer(this); /*0x141099ca5*/
    *otherReplicatorKicked = false; /*0x141099cac*/
    v10 = v9 != nullptr && UserID > 0 && UserID == RBX::Player::getUserID(this: v9); /*0x141099cc6*/
    *shouldRejectPacket = v10; /*0x141099ccc*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: player); /*0xf1c0000000000008*/
  }
  Rep = player->_Rep; /*0x141099ccf*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x141099ce7*/
  {
    Rep->_Destroy(this: Rep); /*0x141099cef*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141099cf9*/
      Rep->_Delete_this(this: Rep); /*0x141099d01*/
  }
}

// Address: 0x141099d20 | Name: ?kickAllOtherPlayersWithId@ClientReplicator@Network@RBX@@MEAAX_JPEA_N1@Z
void __fastcall RBX::Network::ClientReplicator::kickAllOtherPlayersWithId(
        RBX::Network::ClientReplicator *this,
        __int64 playerId,
        bool *otherReplicatorKicked,
        bool *shouldRejectPacket)
{
  RBX::Player *v7; // rax

  v7 = this->findTargetPlayer(this); /*0x141099d3b*/
  *otherReplicatorKicked = false; /*0x141099d41*/
  *shouldRejectPacket = v7 != nullptr && playerId > 0 && playerId == RBX::Player::getUserID(this: v7); /*0x141099d5b*/
}

// Address: 0x141099d90 | Name: ?needGC@ClientReplicator@Network@RBX@@IEAA_NXZ
bool __fastcall RBX::Network::ClientReplicator::needGC(RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *Ptr; // rax

  Ptr = this->gcJob._Ptr; /*0x141099d90*/
  return Ptr->numRegionToGC > 0 || Ptr->emergencyGC || this->memoryLevel <= MEMORYLEVEL_ALL_LOW; /*0x141099db4*/
}

// Address: 0x141099dc0 | Name: ?onSentTag@ClientReplicator@Network@RBX@@MEAAXW4TagItemType@23@@Z
void __fastcall RBX::Network::ClientReplicator::onSentTag(
        RBX::Network::ClientReplicator *this,
        RBX::Network::TagItemType id)
{
  if ( id == ANIMATION_CYCLE_COMPLETED_TAG ) /*0x141099dc3*/
    this->animationEventsInQueue = false; /*0x141099dc5*/
}

// Address: 0x141099dd0 | Name: ?onServiceProvider@ClientReplicator@Network@RBX@@MEAAXPEAVServiceProvider@3@0@Z
void __fastcall RBX::Network::ClientReplicator::onServiceProvider(
        RBX::Network::ClientReplicator *this,
        RBX::ServiceProvider *oldProvider,
        RBX::ServiceProvider *newProvider)
{
  RBX::Network::ClientReplicator::GCJob *Ptr; // rcx
  std::_Ref_count_base *Rep; // rax
  std::_Ref_count_base *v8; // rbx
  RBX::Player *v9; // rax
  RBX::Network::StreamingSolver *v10; // rcx
  std::_Ref_count_base *v11; // rax
  std::_Ref_count_base *v12; // rbx
  std::_Ref_count_base *v13; // rbx
  RBX::Player *v14; // rbx
  int v15; // esi
  int ClusterQueueSize; // eax
  int v17; // r15d
  __int64 UserID; // rax
  RBX::Graphics::ProfilerAdorn::Item *v19; // rbx
  std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *v20; // rax
  char *v21; // rcx
  char *v22; // rcx
  RBX::DataModel *v23; // rax
  RBX::ObscureValue<__int64,0> *Myval2; // rcx
  RBX::Graphics::ProfilerAdorn::Item *v25; // rbx
  std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *v26; // rax
  char *v27; // rcx
  char *v28; // rcx
  RBX::Graphics::ProfilerAdorn::Item *v29; // rax
  std::string *p_text; // rbx
  std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *v31; // rax
  char *v32; // rcx
  char *v33; // rcx
  RBX::Graphics::ProfilerAdorn::Item *v34; // rax
  std::string *v35; // rbx
  char *v36; // rax
  std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> *v37; // rax
  char *v38; // rcx
  char *v39; // rcx
  std::unordered_map<std::string,std::string> *v40; // rax
  std::unordered_map<std::string,std::string> *v41; // rbx
  RBX::Instance *parent; // rdi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::ClassRegistrar<RBX::Network::Client,1> *v44; // rax
  int v45; // esi
  RBX::DataModel *v46; // rax
  RBX::Graphics::ProfilerAdorn::Item *v47; // rax
  int PairIntValue; // ebx
  char *v49; // rcx
  __int64 v50; // rbx
  RBX::Graphics::ProfilerAdorn::Item *v51; // rax
  int v52; // ebx
  char *v53; // rcx
  int v54; // ebx
  RBX::DataModel *v55; // rsi
  std::string *v56; // rax
  int v57; // esi
  char *v58; // rcx
  std::string *v59; // rcx
  int v60; // esi
  char *v61; // rcx
  std::string v62; // [rsp+20h] [rbp-E0h] BYREF
  std::string _Keyval_arg; // [rsp+40h] [rbp-C0h] BYREF
  std::string v64; // [rsp+60h] [rbp-A0h] BYREF
  std::string delimiters; // [rsp+80h] [rbp-80h] BYREF
  std::string v66; // [rsp+A0h] [rbp-60h] BYREF
  std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> v67; // [rsp+C0h] [rbp-40h] BYREF
  std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> v68; // [rsp+D0h] [rbp-30h] BYREF
  std::shared_ptr<RBX::TaskScheduler::Job> v69; // [rsp+E0h] [rbp-20h] BYREF
  std::shared_ptr<RBX::TaskScheduler::Job> v70; // [rsp+F0h] [rbp-10h] BYREF
  std::shared_ptr<RBX::Network::StreamingSolver> solver; // [rsp+100h] [rbp+0h] BYREF
  std::string v72; // [rsp+110h] [rbp+10h] BYREF
  std::shared_ptr<RBX::Network::StreamingInterface> v73; // [rsp+130h] [rbp+30h] BYREF
  std::string v74; // [rsp+140h] [rbp+40h] BYREF
  std::string v75; // [rsp+160h] [rbp+60h] BYREF
  std::string v76; // [rsp+180h] [rbp+80h] BYREF
  std::unordered_map<std::string,std::string> args; // [rsp+1A0h] [rbp+A0h] BYREF
  std::string result; // [rsp+1E0h] [rbp+E0h] BYREF
  std::string v79; // [rsp+200h] [rbp+100h] BYREF
  std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> v80; // [rsp+220h] [rbp+120h] BYREF
  std::pair<std::_List_node<std::pair<std::string const ,std::string >,void *> *,bool> v81; // [rsp+230h] [rbp+130h] BYREF
  std::unordered_map<std::string,std::string> v82; // [rsp+240h] [rbp+140h] BYREF
  __int64 v83; // [rsp+2C0h] [rbp+1C0h]

  Ptr = this->gcJob._Ptr; /*0x141099df8*/
  if ( Ptr != nullptr ) /*0x141099e09*/
  {
    v69 = 0; /*0x141099e12*/
    Rep = this->gcJob._Rep; /*0x141099e17*/
    if ( Rep != nullptr ) /*0x141099e21*/
    {
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141099e23*/
      Ptr = this->gcJob._Ptr; /*0x141099e27*/
      Rep = this->gcJob._Rep; /*0x141099e2e*/
    }
    v69._Ptr = Ptr; /*0x141099e35*/
    v69._Rep = Rep; /*0x141099e39*/
    RBX::TaskScheduler::remove(job: &v69); /*0x141099e41*/
    RBX::Network::ClientReplicator::GCJob::unregisterMovementCallback(this: this->gcJob._Ptr); /*0x141099e4d*/
    this->gcJob._Ptr = nullptr; /*0x141099e52*/
    v8 = this->gcJob._Rep; /*0x141099e59*/
    this->gcJob._Rep = nullptr; /*0x141099e60*/
    if ( v8 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v8->_Uses, 0xFFFFFFFF) == 1 ) /*0x141099e76*/
    {
      v8->_Destroy(this: v8); /*0x141099e7e*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v8->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141099e8a*/
        v8->_Delete_this(this: v8); /*0x141099e92*/
    }
    v9 = this->findTargetPlayer(this); /*0x141099e9b*/
    if ( v9 != nullptr ) /*0x141099ea4*/
    {
      v73 = 0; /*0x141099ea9*/
      RBX::Player::setStreamingInterface(this: v9, provider: &v73); /*0x141099eb5*/
    }
  }
  if ( RBX::Network::StreamingSolver::isSolverEnabled() ) /*0x141099eba*/
  {
    v10 = this->streamingSolver._Ptr; /*0x141099ec7*/
    if ( v10 != nullptr ) /*0x141099ed1*/
    {
      v70 = 0; /*0x141099eda*/
      v11 = this->streamingSolver._Rep; /*0x141099edf*/
      if ( v11 != nullptr ) /*0x141099ee9*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v11->_Uses); /*0x141099eeb*/
        v10 = this->streamingSolver._Ptr; /*0x141099eef*/
        v11 = this->streamingSolver._Rep; /*0x141099ef6*/
      }
      v70._Ptr = v10; /*0x141099efd*/
      v70._Rep = v11; /*0x141099f01*/
      RBX::TaskScheduler::remove(job: &v70); /*0x141099f09*/
      if ( FFlag::ModelStreamingMode.value ) /*0x141099f15*/
      {
        solver = 0; /*0x141099f1a*/
        __wind /*0xf1c0000000000160*/
        {
          RBX::Network::MegaReplicator::setStreamingSolver(this: this->megaReplicator, &solver); /*0x141099f2a*/
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&solver); /*0xf1c0000000000158*/
        }
        v12 = solver._Rep; /*0x141099f30*/
        if ( solver._Rep != nullptr /*0x141099f43*/
          && _InterlockedExchangeAdd((volatile signed __int32 *)&solver._Rep->_Uses, 0xFFFFFFFF) == 1 )
        {
          v12->_Destroy(this: v12); /*0x141099f4b*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v12->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141099f57*/
            v12->_Delete_this(this: v12); /*0x141099f5f*/
        }
      }
      this->streamingSolver._Ptr = nullptr; /*0x141099f62*/
      v13 = this->streamingSolver._Rep; /*0x141099f69*/
      this->streamingSolver._Rep = nullptr; /*0x141099f70*/
      if ( v13 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v13->_Uses, 0xFFFFFFFF) == 1 ) /*0x141099f86*/
      {
        v13->_Destroy(this: v13); /*0x141099f8e*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v13->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141099f98*/
          v13->_Delete_this(this: v13); /*0x141099fa0*/
      }
    }
  }
  if ( DFFlag::ReportTeamCreateReplicatorShutdownMetrics.value && newProvider == nullptr && this->isCloudEdit(this) ) /*0x141099fbf*/
  {
    v14 = this->findTargetPlayer(this); /*0x141099fd9*/
    if ( v14 != nullptr ) /*0x141099fdf*/
    {
      v15 = (unsigned int)std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)&this->pendingItems); /*0x141099ff1*/
      ClusterQueueSize = RBX::Network::Replicator::getClusterQueueSize(this); /*0x141099ff7*/
      v17 = ClusterQueueSize; /*0x141099ffc*/
      if ( v15 > 0 || ClusterQueueSize > 0 ) /*0x14109a006*/
      {
        std::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>::unordered_set<std::pair<std::string,std::string>,RBX::Hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::string,std::string>>>(this: (std::unordered_set<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<std::string,std::string > > > *)&args); /*0x14109a013*/
        __wind /*0xf1c0000000000148*/
        {
          UserID = RBX::Player::getUserID(this: v14); /*0x14109a01c*/
          v19 = RBX::format((RBX::Graphics::ProfilerAdorn::Item *)&result, fmt: "%lld", UserID); /*0x14109a037*/
          __wind /*0xf1c000000000013c*/
          {
            _Keyval_arg._Mypair._Myval2._Myres = 15; /*0x14109a03f*/
            _Keyval_arg._Mypair._Myval2._Mysize = 6; /*0x14109a048*/
            strcpy(_Keyval_arg._Mypair._Myval2._Bx._Buf, "userId"); /*0x14109a057*/
            _Keyval_arg._Mypair._Myval2._Bx._Buf[7] = 0; /*0x14109a062*/
            __wind /*0xf1c0000000000118*/
            {
              v20 = std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Try_emplace<std::string,>( /*0x14109a07c*/
                      this: &args,
                      result: &v68,
                      &_Keyval_arg);
              std::string::operator=(this: &v20->first->_Myval.second, _Right: &v19->text); /*0x14109a08b*/
              if ( _Keyval_arg._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a09a*/
              {
                v21 = _Keyval_arg._Mypair._Myval2._Bx._Ptr; /*0x14109a09f*/
                if ( _Keyval_arg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a0ae*/
                {
                  v21 = *((char **)_Keyval_arg._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a0b4*/
                  if ( (unsigned __int64)(_Keyval_arg._Mypair._Myval2._Bx._Ptr - v21 - 8) > 0x1F ) /*0x14109a0c3*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14109a0c5*/
                }
                operator delete(ptr: v21); /*0x14109a0cc*/
              }
              _Keyval_arg._Mypair._Myval2._Mysize = 0; /*0x14109a0d1*/
              _Keyval_arg._Mypair._Myval2._Myres = 15; /*0x14109a0d6*/
              _Keyval_arg._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109a0df*/
              if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a0ef*/
              {
                v22 = result._Mypair._Myval2._Bx._Ptr; /*0x14109a0f4*/
                if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a105*/
                {
                  v22 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a10b*/
                  if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v22 - 8) > 0x1F ) /*0x14109a11a*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14109a11c*/
                }
                operator delete(ptr: v22); /*0x14109a123*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&_Keyval_arg); /*0xf1c0000000000128*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000134*/
          }
          v23 = RBX::DataModel::get(context: this); /*0x14109a12b*/
          if ( v23 != nullptr ) /*0x14109a133*/
          {
            Myval2 = v23->placeID.storage._Mypair._Myval2; /*0x14109a139*/
            LODWORD(v83) = Myval2->storage.asRaw[0] - (_DWORD)Myval2; /*0x14109a144*/
            HIDWORD(v83) = Myval2->storage.asRaw[1] - (_DWORD)Myval2; /*0x14109a14f*/
            v25 = RBX::format(result: (RBX::Graphics::ProfilerAdorn::Item *)&v79, fmt: "%lld", v83); /*0x14109a16f*/
            __wind /*0xf1c000000000010c*/
            {
              v66._Mypair._Myval2._Myres = 15; /*0x14109a176*/
              v66._Mypair._Myval2._Mysize = 7; /*0x14109a17e*/
              strcpy(v66._Mypair._Myval2._Bx._Buf, "placeId"); /*0x14109a18c*/
              __wind /*0xf1c00000000000e8*/
              {
                v26 = std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Try_emplace<std::string,>( /*0x14109a1b7*/
                        this: &args,
                        result: &v67,
                        _Keyval_arg: &v66);
                std::string::operator=(this: &v26->first->_Myval.second, _Right: &v25->text); /*0x14109a1c6*/
                if ( v66._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a1d4*/
                {
                  v27 = v66._Mypair._Myval2._Bx._Ptr; /*0x14109a1d9*/
                  if ( v66._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a1e7*/
                  {
                    v27 = *((char **)v66._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a1ed*/
                    if ( (unsigned __int64)(v66._Mypair._Myval2._Bx._Ptr - v27 - 8) > 0x1F ) /*0x14109a1fc*/
                      _invalid_parameter_noinfo_noreturn(); /*0x14109a1fe*/
                  }
                  operator delete(ptr: v27); /*0x14109a205*/
                }
                v66._Mypair._Myval2._Mysize = 0; /*0x14109a20a*/
                v66._Mypair._Myval2._Myres = 15; /*0x14109a20e*/
                v66._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109a216*/
                if ( v79._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a225*/
                {
                  v28 = v79._Mypair._Myval2._Bx._Ptr; /*0x14109a22a*/
                  if ( v79._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a23b*/
                  {
                    v28 = *((char **)v79._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a241*/
                    if ( (unsigned __int64)(v79._Mypair._Myval2._Bx._Ptr - v28 - 8) > 0x1F ) /*0x14109a250*/
                      _invalid_parameter_noinfo_noreturn(); /*0x14109a252*/
                  }
                  operator delete(ptr: v28); /*0x14109a259*/
                }
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v66); /*0xf1c00000000000f8*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v79); /*0xf1c0000000000104*/
            }
          }
          v29 = RBX::format(result: (RBX::Graphics::ProfilerAdorn::Item *)&v75, fmt: "%d", v15); /*0x14109a26c*/
          __wind /*0xf1c0000000000184*/
          {
            __wind /*0xf1c000000000018c*/
            {
              p_text = &v29->text; /*0x14109a271*/
              v64._Mypair._Myval2._Myres = 15; /*0x14109a274*/
              v64._Mypair._Myval2._Mysize = 12; /*0x14109a27d*/
              strcpy(v64._Mypair._Myval2._Bx._Buf, "pendingItems"); /*0x14109a28e*/
              v31 = std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Try_emplace<std::string,>( /*0x14109a2b6*/
                      this: &args,
                      result: &v80,
                      _Keyval_arg: &v64);
              std::string::operator=(this: &v31->first->_Myval.second, _Right: p_text); /*0x14109a2c5*/
              if ( v64._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a2d4*/
              {
                v32 = v64._Mypair._Myval2._Bx._Ptr; /*0x14109a2d9*/
                if ( v64._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a2e8*/
                {
                  v32 = *((char **)v64._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a2ee*/
                  if ( (unsigned __int64)(v64._Mypair._Myval2._Bx._Ptr - v32 - 8) > 0x1F ) /*0x14109a2fd*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14109a2ff*/
                }
                operator delete(ptr: v32); /*0x14109a306*/
              }
              v64._Mypair._Myval2._Mysize = 0; /*0x14109a30b*/
              v64._Mypair._Myval2._Myres = 15; /*0x14109a310*/
              v64._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109a319*/
              if ( v75._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a326*/
              {
                v33 = v75._Mypair._Myval2._Bx._Ptr; /*0x14109a32b*/
                if ( v75._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a339*/
                {
                  v33 = *((char **)v75._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a33f*/
                  if ( (unsigned __int64)(v75._Mypair._Myval2._Bx._Ptr - v33 - 8) > 0x1F ) /*0x14109a34e*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14109a350*/
                }
                operator delete(ptr: v33); /*0x14109a357*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v64); /*0xf1c0000000000170*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v75); /*0xf1c000000000017c*/
          }
          v34 = RBX::format(result: (RBX::Graphics::ProfilerAdorn::Item *)&v76, fmt: "%d", v17); /*0x14109a36d*/
          __wind /*0xf1c00000000000dc*/
          {
            v35 = &v34->text; /*0x14109a372*/
            v62._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109a375*/
            v62._Mypair._Myval2._Mysize = 0; /*0x14109a37a*/
            v62._Mypair._Myval2._Myres = 15; /*0x14109a37f*/
            v36 = (char *)operator new(size: 0x20u); /*0x14109a392*/
            __wind /*0xf1c00000000000b8*/
            {
              v62._Mypair._Myval2._Mysize = 20; /*0x14109a397*/
              v62._Mypair._Myval2._Myres = 31; /*0x14109a3a0*/
              strcpy(v36, "pendingClusterDeltas"); /*0x14109a3b0*/
              v62._Mypair._Myval2._Bx._Ptr = v36; /*0x14109a3c0*/
              v37 = std::_Hash<std::_Umap_traits<std::string,std::string,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,std::string>>,0>>::_Try_emplace<std::string,>( /*0x14109a3d8*/
                      this: &args,
                      result: &v81,
                      _Keyval_arg: &v62);
              std::string::operator=(this: &v37->first->_Myval.second, _Right: v35); /*0x14109a3e7*/
              if ( v62._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a3f6*/
              {
                v38 = v62._Mypair._Myval2._Bx._Ptr; /*0x14109a3fb*/
                if ( v62._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a40a*/
                {
                  v38 = *((char **)v62._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a410*/
                  if ( (unsigned __int64)(v62._Mypair._Myval2._Bx._Ptr - v38 - 8) > 0x1F ) /*0x14109a41f*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14109a421*/
                }
                operator delete(ptr: v38); /*0x14109a428*/
              }
              v62._Mypair._Myval2._Mysize = 0; /*0x14109a42d*/
              v62._Mypair._Myval2._Myres = 15; /*0x14109a432*/
              v62._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109a43b*/
              if ( v76._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a44b*/
              {
                v39 = v76._Mypair._Myval2._Bx._Ptr; /*0x14109a450*/
                if ( v76._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a461*/
                {
                  v39 = *((char **)v76._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a467*/
                  if ( (unsigned __int64)(v76._Mypair._Myval2._Bx._Ptr - v39 - 8) > 0x1F ) /*0x14109a476*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14109a478*/
                }
                operator delete(ptr: v39); /*0x14109a47f*/
              }
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v62); /*0xf1c00000000000c8*/
            }
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v76); /*0xf1c00000000000d4*/
          }
          v40 = std::unordered_map<std::string,std::string>::unordered_map<std::string,std::string>( /*0x14109a4a0*/
                  this: &v82,
                  _Right: &args);
          __wind /*0xf1c00000000000ac*/
          {
            v41 = v40; /*0x14109a4a5*/
            v74._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109a4b3*/
            v74._Mypair._Myval2._Mysize = 0; /*0x14109a4b7*/
            v74._Mypair._Myval2._Myres = 15; /*0x14109a4bb*/
            std::string::assign(this: &v74, _Ptr: "ReplicationPending", _Count: 0x12u); /*0x14109a4d4*/
          }
          __unwind
          {
            std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &v82); /*0xf1c00000000000a4*/
          }
          v72._Mypair._Myval2._Myres = 15; /*0x14109a4e5*/
          v72._Mypair._Myval2._Mysize = 10; /*0x14109a4ed*/
          strcpy(v72._Mypair._Myval2._Bx._Buf, "TeamCreate"); /*0x14109a4fd*/
          delimiters._Mypair._Myval2._Myres = 15; /*0x14109a515*/
          delimiters._Mypair._Myval2._Mysize = 6; /*0x14109a51d*/
          *(_DWORD *)delimiters._Mypair._Myval2._Bx._Buf = *(_DWORD *)"studio"; /*0x14109a52b*/
          *(_DWORD *)&delimiters._Mypair._Myval2._Bx._Alias[4] = *(unsigned __int16 *)"io"; /*0x14109a535*/
          RBX::Analytics::EventIngest::setRBXEvent( /*0x14109a54c*/
            target: &delimiters,
            eventContext: &v72,
            eventName: &v74,
            additionalArgs: v41);
          std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>::~_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Soundscape::SoundId const,std::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>>>>(this: (std::_Hash_vec<std::allocator<std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,std::vector<RBX::Permission> > > > > > > *)&args._Vec); /*0x14109a559*/
          std::list<std::pair<std::string const,std::string>>::~list<std::pair<std::string const,std::string>>(this: (std::list<std::pair<std::string,std::string >> *)&args._List); /*0x14109a565*/
        }
        __unwind
        {
          std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: &args); /*0xf1c0000000000098*/
        }
        RBX::Network::MegaReplicator::removeMegaJobs(this: this->megaReplicator); /*0x14109a571*/
        RBX::Network::Replicator::onServiceProvider(this, oldProvider, newProvider: nullptr); /*0x14109a57f*/
        goto LABEL_79; /*0x14109a584*/
      }
    }
  }
  RBX::Network::MegaReplicator::removeMegaJobs(this: this->megaReplicator); /*0x14109a58d*/
  RBX::Network::Replicator::onServiceProvider(this, oldProvider, newProvider); /*0x14109a59b*/
  if ( newProvider == nullptr ) /*0x14109a5a3*/
  {
LABEL_79:
    parent = this->parent; /*0x14109a5a5*/
    if ( parent != nullptr ) /*0x14109a5ac*/
    {
      descriptor = parent->descriptor; /*0x14109a5b2*/
      v44 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(); /*0x14109a5b6*/
      if ( descriptor->index - (unsigned int)v44->desc.index <= v44->desc.descendantCount ) /*0x14109a5d4*/
        *(_QWORD *)&parent[12].DEPRECATED_uniqueId.sessionId.timestamp = 0; /*0x14109a5da*/
    }
    return; /*0x14109a5e1*/
  }
  v45 = DFInt::ReportClientJoinRxStatsHundrethsPercentage; /*0x14109a5e6*/
  if ( DFString::ClientJoinRxConfigPerDC._Mypair._Myval2._Mysize != 0 ) /*0x14109a5f4*/
  {
    v46 = RBX::DataModel::get(context: this); /*0x14109a5fd*/
    if ( v46 != nullptr ) /*0x14109a605*/
    {
      delimiters._Mypair._Myval2._Bx._Ptr = (char *)44; /*0x14109a60b*/
      delimiters._Mypair._Myval2._Myres = 15; /*0x14109a60f*/
      delimiters._Mypair._Myval2._Mysize = 1; /*0x14109a617*/
      __wind /*0xf1c0000000000088*/
      {
        v47 = RBX::format(result: (RBX::Graphics::ProfilerAdorn::Item *)&v76, fmt: "%d", v46->dataCenterId); /*0x14109a63a*/
        __wind /*0xf1c000000000007c*/
        {
          PairIntValue = RBX::Network::getPairIntValue( /*0x14109a653*/
                           target: &v47->text,
                           from: &DFString::ClientJoinRxConfigPerDC,
                           &delimiters);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v76); /*0xf1c0000000000074*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v76); /*0x14109a65c*/
        if ( delimiters._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a66a*/
        {
          v49 = delimiters._Mypair._Myval2._Bx._Ptr; /*0x14109a66f*/
          if ( delimiters._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a67d*/
          {
            v49 = *((char **)delimiters._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a683*/
            if ( (unsigned __int64)(delimiters._Mypair._Myval2._Bx._Ptr - v49 - 8) > 0x1F ) /*0x14109a692*/
              _invalid_parameter_noinfo_noreturn(); /*0x14109a694*/
          }
          operator delete(ptr: v49); /*0x14109a69b*/
        }
        if ( PairIntValue != -1 ) /*0x14109a6a3*/
          v45 = PairIntValue; /*0x14109a6a3*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&delimiters); /*0xf1c0000000000068*/
      }
    }
  }
  if ( DFString::ClientJoinRxConfigUserIdPer100._Mypair._Myval2._Mysize != 0 ) /*0x14109a6b8*/
  {
    v50 = this->expectedPlayerId % 100; /*0x14109a6e0*/
    v64._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109a6e3*/
    v64._Mypair._Myval2._Mysize = 0; /*0x14109a6e8*/
    v64._Mypair._Myval2._Myres = 15; /*0x14109a6ed*/
    std::string::assign(this: &v64, _Ptr: ",", _Count: 1u); /*0x14109a70d*/
    __wind /*0xf1c0000000000058*/
    {
      v51 = RBX::format(result: (RBX::Graphics::ProfilerAdorn::Item *)&v75, fmt: "%d", v50); /*0x14109a721*/
      __wind /*0xf1c0000000000034*/
      {
        v52 = RBX::Network::getPairIntValue( /*0x14109a73b*/
                target: &v51->text,
                from: &DFString::ClientJoinRxConfigUserIdPer100,
                delimiters: &v64);
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v75); /*0x14109a741*/
        if ( v64._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a750*/
        {
          v53 = v64._Mypair._Myval2._Bx._Ptr; /*0x14109a755*/
          if ( v64._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a764*/
          {
            v53 = *((char **)v64._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a76a*/
            if ( (unsigned __int64)(v64._Mypair._Myval2._Bx._Ptr - v53 - 8) > 0x1F ) /*0x14109a779*/
              _invalid_parameter_noinfo_noreturn(); /*0x14109a77b*/
          }
          operator delete(ptr: v53); /*0x14109a782*/
        }
        if ( v52 != -1 ) /*0x14109a78a*/
          v45 = v52; /*0x14109a78a*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v75); /*0xf1c0000000000044*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v64); /*0xf1c0000000000050*/
    }
  }
  this->joinRxStats.reportingHundrethPercentage = v45; /*0x14109a78d*/
  v54 = DFInt::CliNetIngressLimiterReportingPer100K; /*0x14109a793*/
  if ( DFString::CliNetIngressLimiterReportingConfigPerDC._Mypair._Myval2._Mysize != 0 ) /*0x14109a7a1*/
  {
    v55 = RBX::DataModel::get(context: this); /*0x14109a7af*/
    if ( v55 != nullptr ) /*0x14109a7b5*/
    {
      _Keyval_arg._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109a7bb*/
      _Keyval_arg._Mypair._Myval2._Mysize = 0; /*0x14109a7c0*/
      _Keyval_arg._Mypair._Myval2._Myres = 15; /*0x14109a7c5*/
      std::string::assign(this: &_Keyval_arg, _Ptr: ",", _Count: 1u); /*0x14109a7e5*/
      __wind /*0xf1c0000000000028*/
      {
        v56 = &DFString::CliNetIngressLimiterReportingConfigPerDC; /*0x14109a7f2*/
        if ( DFString::CliNetIngressLimiterReportingConfigPerDC._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a801*/
          v56 = (std::string *)DFString::CliNetIngressLimiterReportingConfigPerDC._Mypair._Myval2._Bx._Ptr; /*0x14109a801*/
        v67.first = (std::_List_node<std::pair<std::string const ,std::string >,void *> *)v56; /*0x14109a809*/
        *(_QWORD *)&v67.second = DFString::CliNetIngressLimiterReportingConfigPerDC._Mypair._Myval2._Mysize; /*0x14109a80d*/
        v57 = RBX::Network::getPairIntValue( /*0x14109a82e*/
                target: v55->dataCenterId,
                from: (RBX::StringView *)&v67,
                delimiter: &_Keyval_arg);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&_Keyval_arg); /*0xf1c0000000000020*/
      }
      if ( _Keyval_arg._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a839*/
      {
        v58 = _Keyval_arg._Mypair._Myval2._Bx._Ptr; /*0x14109a83e*/
        if ( _Keyval_arg._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a84d*/
        {
          v58 = *((char **)_Keyval_arg._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a853*/
          if ( (unsigned __int64)(_Keyval_arg._Mypair._Myval2._Bx._Ptr - v58 - 8) > 0x1F ) /*0x14109a862*/
            _invalid_parameter_noinfo_noreturn(); /*0x14109a864*/
        }
        operator delete(ptr: v58); /*0x14109a86b*/
      }
      if ( v57 != -1 ) /*0x14109a873*/
        v54 = v57; /*0x14109a873*/
    }
  }
  if ( DFString::CliNetIngressLimiterReportingConfigUserIdPer100K._Mypair._Myval2._Mysize != 0 ) /*0x14109a87e*/
  {
    v62._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109a884*/
    v62._Mypair._Myval2._Mysize = 0; /*0x14109a889*/
    v62._Mypair._Myval2._Myres = 15; /*0x14109a88e*/
    std::string::assign(this: &v62, _Ptr: ",", _Count: 1u); /*0x14109a8ae*/
    __wind /*0xf1c0000000000010*/
    {
      v59 = &DFString::CliNetIngressLimiterReportingConfigUserIdPer100K; /*0x14109a8bb*/
      if ( DFString::CliNetIngressLimiterReportingConfigUserIdPer100K._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a8ca*/
        v59 = (std::string *)DFString::CliNetIngressLimiterReportingConfigUserIdPer100K._Mypair._Myval2._Bx._Ptr; /*0x14109a8ca*/
      v68.first = (std::_List_node<std::pair<std::string const ,std::string >,void *> *)v59; /*0x14109a8d2*/
      *(_QWORD *)&v68.second = DFString::CliNetIngressLimiterReportingConfigUserIdPer100K._Mypair._Myval2._Mysize; /*0x14109a8d6*/
      v60 = RBX::Network::getPairIntValue( /*0x14109a916*/
              target: this->expectedPlayerId % 100,
              from: (RBX::StringView *)&v68,
              delimiter: &v62);
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v62); /*0xf1c0000000000008*/
    }
    if ( v62._Mypair._Myval2._Myres >= 0x10 ) /*0x14109a921*/
    {
      v61 = v62._Mypair._Myval2._Bx._Ptr; /*0x14109a926*/
      if ( v62._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109a935*/
      {
        v61 = *((char **)v62._Mypair._Myval2._Bx._Ptr - 1); /*0x14109a93b*/
        if ( (unsigned __int64)(v62._Mypair._Myval2._Bx._Ptr - v61 - 8) > 0x1F ) /*0x14109a94a*/
          _invalid_parameter_noinfo_noreturn(); /*0x14109a94c*/
      }
      operator delete(ptr: v61); /*0x14109a953*/
    }
    if ( v60 != -1 ) /*0x14109a95b*/
      v54 = v60; /*0x14109a95b*/
  }
  this->cliNetIngressLimiterReportPer10k = v54; /*0x14109a95e*/
}

// Address: 0x14109b050 | Name: ?onTerrainRegionChanged@ClientReplicator@Network@RBX@@MEAAXAEBVRegion@Voxel2@3@IW4DeferredTerrainContents@3@@Z
void __fastcall RBX::Network::ClientReplicator::onTerrainRegionChanged(
        RBX::Network::ClientReplicator *this,
        const RBX::Voxel2::Region *region,
        unsigned int lod,
        RBX::DeferredTerrainContents deferredContentsState)
{
  SettingsDialog::PropertyItem *v7; // rcx

  if ( lod == 0 /*0x14109b08b*/
    && (BYTE1(this->bandwidthManager.feedbackMetricsNotAppLimited.bytesSentCount) != 0
     || (v7 = *(SettingsDialog::PropertyItem **)&this->soundRemoteLimiter.leakSeconds) == nullptr
     || (unsigned int)RBX::AssetImport::StatusBase<1,RBX::AssetImport::CallLocationInfo,RBX::AssetImport::DebugMessage>::getLevel(this: v7) != 1) )
  {
    RBX::Network::Replicator::onTerrainRegionChanged(this, region, lod: 0, deferredContentsState); /*0x14109b09a*/
  }
}

// Address: 0x14109b0b0 | Name: ?performUnrelatedSecurityTasks@ClientReplicator@Network@RBX@@MEAAIXZ
__int64 __fastcall RBX::Network::ClientReplicator::performUnrelatedSecurityTasks(RBX::Network::ClientReplicator *this)
{
  unsigned int LatchedSignal; // r15d
  RBX::Instance *Ptr; // rsi
  std::_Ref_count_base *Rep; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v6; // rax
  unsigned int v7; // edx
  RBX::Instance *v8; // rbx
  std::string *Myval2; // rbx
  RBX::Humanoid ***v10; // rbx
  RBX::Humanoid **v11; // rbp
  RBX::Humanoid **v12; // rbx
  RBX::Humanoid *v13; // rsi
  const RBX::Reflection::ClassDescriptor *v14; // rdi
  RBX::ClassRegistrar<RBX::Humanoid,1> *v15; // rax
  RBX::Workspace *v16; // rax
  float Gravity; // xmm6_4
  RBX::Primitive **Myfirst; // r8
  RBX::Primitive **Mylast; // rcx
  RBX::Primitive *v20; // rax
  RBX::Primitive **v21; // rax
  std::shared_ptr<RBX::Instance> v23; // [rsp+20h] [rbp-68h] BYREF
  std::vector<RBX::Primitive *> characterPrimitives; // [rsp+30h] [rbp-58h] BYREF

  LatchedSignal = (unsigned int)RBX::Reflection::EventDescBase<RBX::Humanoid,void (bool),rbx::remote_signal<void (bool)>,rbx::remote_signal<void (bool)> RBX::Humanoid::*>::getLatchedSignal(_Where: this); /*0x14109b0cd*/
  Ptr = RBX::Network::Replicator::getPlayer(this, result: &v23)->_Ptr; /*0x14109b0dd*/
  Rep = v23._Rep; /*0x14109b0e0*/
  if ( v23._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v23._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14109b0f9*/
  {
    Rep->_Destroy(this: Rep); /*0x14109b101*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14109b10b*/
      Rep->_Delete_this(this: Rep); /*0x14109b113*/
  }
  if ( Ptr == nullptr ) /*0x14109b119*/
    goto LABEL_15; /*0x14109b119*/
  descriptor = Ptr->descriptor; /*0x14109b11f*/
  v6 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(); /*0x14109b123*/
  v7 = descriptor->index - v6->index; /*0x14109b136*/
  v8 = nullptr; /*0x14109b13f*/
  if ( v7 <= v6->descendantCount ) /*0x14109b143*/
    v8 = Ptr; /*0x14109b143*/
  if ( v8 != nullptr /*0x14109b16b*/
    && (Myval2 = v8[1].xmlId._Mypair._Myval2) != nullptr
    && (v10 = *(RBX::Humanoid ****)&Myval2[2]._Mypair._Myval2._Bx._Alias[8]) != nullptr
    && (v11 = v10[1], (v12 = *v10) != v11) )
  {
    while ( 1 ) /*0x14109b170*/
    {
      v13 = *v12; /*0x14109b170*/
      if ( *v12 != nullptr ) /*0x14109b176*/
      {
        v14 = v13->descriptor; /*0x14109b178*/
        v15 = RBX::Reflection::Class_getDescriptorPtr<RBX::Humanoid>(); /*0x14109b17c*/
        if ( v14->index - (unsigned int)v15->desc.index <= v15->desc.descendantCount ) /*0x14109b19a*/
          break; /*0x14109b19a*/
      }
      v12 += 2; /*0x14109b19c*/
      if ( v12 == v11 ) /*0x14109b1a3*/
        goto LABEL_15; /*0x14109b1a3*/
    }
  }
  else
  {
LABEL_15:
    v13 = nullptr; /*0x14109b1a5*/
  }
  v16 = RBX::ServiceProvider::find<RBX::Workspace>(context: this); /*0x14109b1aa*/
  if ( v16 == nullptr || v13 == nullptr ) /*0x14109b1bb*/
    return 0; /*0x14109b2b8*/
  Gravity = RBX::Workspace::getGravity(this: v16); /*0x14109b1c9*/
  memset(&characterPrimitives, 0, sizeof(characterPrimitives)); /*0x14109b1cf*/
  __wind /*0xf1c0000000000010*/
  {
    RBX::Humanoid::getPrimitives( /*0x14109b1e6*/
      this: v13,
      primitives: (std::set<std::shared_ptr<RBX::Instance>> *)&characterPrimitives);
    Myfirst = characterPrimitives._Mypair._Myval2._Myfirst; /*0x14109b1eb*/
    Mylast = characterPrimitives._Mypair._Myval2._Mylast; /*0x14109b1f0*/
    if ( characterPrimitives._Mypair._Myval2._Myfirst != characterPrimitives._Mypair._Myval2._Mylast ) /*0x14109b1f8*/
    {
      do /*0x14109b26b*/
      {
        v20 = *Myfirst; /*0x14109b201*/
        if ( (*Myfirst)->world != nullptr && v20->uid != 0 && v20->gravity != Gravity ) /*0x14109b222*/
        {
          RBX::Security::hackFlag9 |= 0x80u; /*0x14109b259*/
          Mylast = characterPrimitives._Mypair._Myval2._Mylast; /*0x14109b25f*/
        }
        ++Myfirst; /*0x14109b264*/
      }
      while ( Myfirst != Mylast ); /*0x14109b26b*/
      Myfirst = characterPrimitives._Mypair._Myval2._Myfirst; /*0x14109b26d*/
    }
  }
  __unwind
  {
    std::vector<Luau::AstExpr *>::~vector<Luau::AstExpr *>(this: (std::vector<RBX::Graphics::FramebufferVulkan *> *)&characterPrimitives); /*0xf1c0000000000008*/
  }
  if ( Myfirst != nullptr ) /*0x14109b275*/
  {
    v21 = Myfirst; /*0x14109b283*/
    if ( (((char *)characterPrimitives._Mypair._Myval2._Myend - (char *)Myfirst) & 0xFFFFFFFFFFFFFFF8uLL) >= 0x1000 ) /*0x14109b28d*/
    {
      Myfirst = (RBX::Primitive **)*(Myfirst - 1); /*0x14109b293*/
      if ( (unsigned __int64)((char *)v21 - (char *)Myfirst - 8) > 0x1F ) /*0x14109b2a2*/
        _invalid_parameter_noinfo_noreturn(); /*0x14109b2a4*/
    }
    operator delete(ptr: Myfirst); /*0x14109b2ae*/
  }
  return LatchedSignal; /*0x14109b2ba*/
}

// Address: 0x14109b2e0 | Name: ?postProcessReceivedPackets@ClientReplicator@Network@RBX@@UEAAXXZ
void __fastcall RBX::Network::ClientReplicator::postProcessReceivedPackets(RBX::Network::ClientReplicator *this)
{
  RBX::DataModel *v2; // rax
  RBX::Stats::PerformanceStatsItem *v3; // rax
  RBX::Stats::PerformanceStatsItem *v4; // rdi
  float kiloBytesReceivedPerSecond; // xmm1_4
  float averageValue; // xmm1_4

  v2 = RBX::DataModel::get(context: this); /*0x14109b2ed*/
  v3 = RBX::Stats::PerformanceStatsItem::getFromDataModel(dataModel: v2); /*0x14109b2f5*/
  v4 = v3; /*0x14109b2fa*/
  if ( v3 != nullptr ) /*0x14109b300*/
  {
    kiloBytesReceivedPerSecond = this->replicatorStats.kiloBytesReceivedPerSecond; /*0x14109b30d*/
    RBX::Stats::PerformanceStatsItem::setLatestNetwokReceived(this: v3, kbPerSec: kiloBytesReceivedPerSecond); /*0x14109b311*/
    averageValue = this->replicatorStats.dataPing.averageValue; /*0x14109b321*/
    RBX::Stats::PerformanceStatsItem::setLatestPingTime(this: v4, msec: averageValue); /*0x14109b325*/
  }
  RBX::Network::CompletenessTrackerClient::propagate(this: &this->megaReplicator->clientCompleteness, replicator: this); /*0x14109b345*/
}

// Address: 0x14109b350 | Name: ?postProcessSentPackets@ClientReplicator@Network@RBX@@UEAAXXZ
void __fastcall RBX::Network::ClientReplicator::postProcessSentPackets(RBX::Network::ClientReplicator *this)
{
  RBX::DataModel *v2; // rax
  RBX::Stats::PerformanceStatsItem *v3; // rax
  float kiloBytesSentPerSecond; // xmm1_4

  v2 = RBX::DataModel::get(context: this); /*0x14109b359*/
  v3 = RBX::Stats::PerformanceStatsItem::getFromDataModel(dataModel: v2); /*0x14109b361*/
  if ( v3 != nullptr ) /*0x14109b369*/
  {
    kiloBytesSentPerSecond = this->replicatorStats.kiloBytesSentPerSecond; /*0x14109b376*/
    RBX::Stats::PerformanceStatsItem::setLatestNetwokSent(this: v3, kbPerSec: kiloBytesSentPerSecond); /*0x14109b37f*/
  }
}

// Address: 0x14109b390 | Name: ?preProcessReceivedPackets@ClientReplicator@Network@RBX@@UEAAXXZ
void __fastcall RBX::Network::ClientReplicator::preProcessReceivedPackets(RBX::Network::ClientReplicator *this)
{
  long double v2; // xmm6_8
  int reportingHundrethPercentage; // ebx
  std::pair<std::string,double> *v4; // rax
  long double second; // rcx
  std::pair<std::string,double> *Mylast; // rdx
  unsigned __int64 Myres; // rax
  char *Ptr; // rcx
  std::pair<std::string,double> *Myfirst; // rbx
  std::pair<std::string,double> *v10; // rdi
  unsigned __int64 v11; // rdx
  char *v12; // rcx
  std::pair<std::string,double> *v13; // rax
  std::vector<std::pair<std::string,double>> stat; // [rsp+20h] [rbp-60h] BYREF
  unsigned __int64 v15; // [rsp+38h] [rbp-48h]
  RBX::Graphics::ProfilerAdorn::Item v16; // [rsp+40h] [rbp-40h] BYREF
  RBX::Time result; // [rsp+A0h] [rbp+20h] BYREF

  if ( this->reportJoinRxStats ) /*0x14109b3b0*/
  {
    v2 = (RBX::Time::now<2>(&result)->sec - this->joinRxStats.connectionStartTime.sec) * 1000.0; /*0x14109b3d2*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109b3eb*/
      this: &this->clientJoinRxStatsPoint,
      name: "AdjustedGameLoadTimeMs",
      value: v2);
    reportingHundrethPercentage = this->joinRxStats.reportingHundrethPercentage; /*0x14109b3f0*/
    v4 = (std::pair<std::string,double> *)operator new(size: 0x20u); /*0x14109b411*/
    stat._Mypair._Myval2._Myend = (std::pair<std::string,double> *)17; /*0x14109b416*/
    v15 = 31; /*0x14109b41e*/
    strcpy(v4->first._Mypair._Myval2._Bx._Buf, "ClientJoinRxStats"); /*0x14109b42d*/
    stat._Mypair._Myval2._Myfirst = v4; /*0x14109b43e*/
    __wind /*0xf1c0000000000040*/
    {
      RBX::Analytics::InfluxDb::Points::report( /*0x14109b453*/
        this: &this->clientJoinRxStatsPoint,
        resource: (const std::string *)&stat,
        throttleHundredthsPercentage: reportingHundrethPercentage,
        blocking: false);
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&stat); /*0xf1c0000000000038*/
    }
    if ( v15 >= 0x10 ) /*0x14109b461*/
    {
      second = *(double *)&stat._Mypair._Myval2._Myfirst; /*0x14109b466*/
      if ( v15 + 1 >= 0x1000 ) /*0x14109b474*/
      {
        second = stat._Mypair._Myval2._Myfirst[-1].second; /*0x14109b47a*/
        if ( (unsigned __int64)stat._Mypair._Myval2._Myfirst - *(_QWORD *)&second - 8 > 0x1F ) /*0x14109b489*/
          _invalid_parameter_noinfo_noreturn(); /*0x14109b48b*/
      }
      operator delete(ptr: *(void **)&second); /*0x14109b492*/
    }
    __wind /*0xf1c0000000000028*/
    {
      if ( this->shouldReportToDiag ) /*0x14109b497*/
      {
        memset(&stat, 0, sizeof(stat)); /*0x14109b4a7*/
        v16.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109b4b0*/
        *(__m128i *)&v16.text._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14109b4bc*/
        std::string::assign(this: &v16.text, _Ptr: "AdjustedGameLoadTimeMs", _Count: 0x16u); /*0x14109b4d6*/
        __wind /*0xf1c000000000001c*/
        {
          *(long double *)&v16.x = v2; /*0x14109b4db*/
          Mylast = stat._Mypair._Myval2._Mylast; /*0x14109b4e0*/
          if ( stat._Mypair._Myval2._Mylast == stat._Mypair._Myval2._Myend ) /*0x14109b4e8*/
          {
            std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x14109b516*/
              this: &stat,
              _Whereptr: stat._Mypair._Myval2._Mylast,
              <_Val_0>: (std::pair<std::string,double> *)&v16);
            Myres = v16.text._Mypair._Myval2._Myres; /*0x14109b51b*/
          }
          else
          {
            stat._Mypair._Myval2._Mylast->first._Mypair._Myval2._Bx = v16.text._Mypair._Myval2._Bx; /*0x14109b4ee*/
            *(_OWORD *)&Mylast->first._Mypair._Myval2._Mysize = *(_OWORD *)&v16.text._Mypair._Myval2._Mysize; /*0x14109b4f5*/
            Myres = 15; /*0x14109b4f9*/
            v16.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109b4fe*/
            Mylast->second = v2; /*0x14109b502*/
            ++stat._Mypair._Myval2._Mylast; /*0x14109b507*/
          }
          if ( Myres >= 0x10 ) /*0x14109b523*/
          {
            Ptr = v16.text._Mypair._Myval2._Bx._Ptr; /*0x14109b529*/
            if ( Myres + 1 >= 0x1000 ) /*0x14109b537*/
            {
              Ptr = *((char **)v16.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14109b53d*/
              if ( (unsigned __int64)(v16.text._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14109b54c*/
                _invalid_parameter_noinfo_noreturn(); /*0x14109b54e*/
            }
            operator delete(ptr: Ptr); /*0x14109b555*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v16); /*0xf1c0000000000014*/
        }
        RBX::Analytics::EphemeralCounter::bulkReportStats(stats: &stat, blocking: false); /*0x14109b560*/
        Myfirst = stat._Mypair._Myval2._Myfirst; /*0x14109b566*/
        if ( stat._Mypair._Myval2._Myfirst != nullptr ) /*0x14109b56d*/
        {
          v10 = stat._Mypair._Myval2._Mylast; /*0x14109b573*/
          if ( stat._Mypair._Myval2._Myfirst != stat._Mypair._Myval2._Mylast ) /*0x14109b57a*/
          {
            do /*0x14109b5cc*/
            {
              v11 = Myfirst->first._Mypair._Myval2._Myres; /*0x14109b580*/
              if ( v11 >= 0x10 ) /*0x14109b588*/
              {
                v12 = Myfirst->first._Mypair._Myval2._Bx._Ptr; /*0x14109b58d*/
                if ( v11 + 1 >= 0x1000 ) /*0x14109b597*/
                {
                  if ( (unsigned __int64)&v12[-*((_QWORD *)v12 - 1) - 8] > 0x1F ) /*0x14109b5ac*/
                    goto LABEL_29; /*0x14109b5ac*/
                  v12 = *((char **)v12 - 1); /*0x14109b5ae*/
                }
                operator delete(ptr: v12); /*0x14109b5b1*/
              }
              Myfirst->first._Mypair._Myval2._Mysize = 0; /*0x14109b5b6*/
              Myfirst->first._Mypair._Myval2._Myres = 15; /*0x14109b5ba*/
              Myfirst->first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109b5c2*/
              ++Myfirst; /*0x14109b5c5*/
            }
            while ( Myfirst != v10 ); /*0x14109b5cc*/
            Myfirst = stat._Mypair._Myval2._Myfirst; /*0x14109b5ce*/
          }
          v13 = Myfirst; /*0x14109b5fc*/
          if ( (unsigned __int64)(40 * (stat._Mypair._Myval2._Myend - Myfirst)) >= 0x1000 ) /*0x14109b606*/
          {
            Myfirst = *(std::pair<std::string,double> **)&Myfirst[-1].second; /*0x14109b60c*/
            if ( (unsigned __int64)((char *)v13 - (char *)Myfirst - 8) > 0x1F ) /*0x14109b61b*/
LABEL_29:
              _invalid_parameter_noinfo_noreturn(); /*0x14109b61d*/
          }
          operator delete(ptr: Myfirst); /*0x14109b627*/
        }
      }
      this->reportJoinRxStats = false; /*0x14109b62c*/
    }
    __unwind
    {
      std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)&stat); /*0xf1c0000000000008*/
    }
  }
}

// Address: 0x14109b650 | Name: ?preProcessSendPackets@ClientReplicator@Network@RBX@@UEAAXXZ
// attributes: thunk
void __fastcall RBX::Network::ClientReplicator::preProcessSendPackets(RBX::Network::ClientReplicator *this)
{
  RBX::Network::Replicator::queueCoalescedAnimationEvents(this); /*0x14109b650*/
}

// Address: 0x14109b660 | Name: ?prepareDumpOrReportProfile@ClientReplicator@Network@RBX@@AEAAXXZ
void __fastcall RBX::Network::ClientReplicator::prepareDumpOrReportProfile(RBX::Network::ClientReplicator *this)
{
  RBX::DataModel *v2; // rax
  RBX::TimerService *v3; // r15
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v6; // ett
  std::_Ref_count_base *v7; // rcx
  RBX::Reflection::DescribedBase **p_Ptr; // rax
  char v9; // di
  std::_Ref_count_base *v10; // rcx
  __int64 v11; // rbx
  volatile signed __int32 *v12; // rbx
  int aggregateFramesSetting; // ebx
  double v14; // xmm6_8
  std::_Ref_count_base *v15; // r14
  _QWORD *v16; // rax
  std::_Func_base<void> *v17; // rbx
  rtc::webrtc_checks_impl::ToStringVal *v18; // rdi
  std::_Ref_count_base *v19; // rcx
  char *v20; // rcx
  std::weak_ptr<RBX::Network::ClientReplicator> weakThis; // [rsp+20h] [rbp-E0h] BYREF
  RBX::Reflection::DescribedBase *Ptr; // [rsp+30h] [rbp-D0h] BYREF
  volatile signed __int32 *v23; // [rsp+38h] [rbp-C8h]
  __int128 v24; // [rsp+40h] [rbp-C0h] BYREF
  std::weak_ptr<RBX::Network::ClientReplicator> v25; // [rsp+50h] [rbp-B0h] BYREF
  int v26; // [rsp+60h] [rbp-A0h]
  RBX::Analytics::InfluxDb::Points _Right; // [rsp+68h] [rbp-98h] BYREF
  RBX::Analytics::InfluxDb::Points jobTimerPoints; // [rsp+D0h] [rbp-30h] BYREF
  void *v29; // [rsp+140h] [rbp+40h]
  std::function<void __cdecl(void)> v30; // [rsp+148h] [rbp+48h] BYREF
  std::_Global_new::__l2::_Guard_type v31; // [rsp+1F0h] [rbp+F0h] BYREF
  std::weak_ptr<PluginPermissionsFetcher> *v32; // [rsp+1F8h] [rbp+F8h]

  v2 = RBX::DataModel::get(context: this); /*0x14109b68f*/
  v3 = RBX::ServiceProvider::create<RBX::TimerService>(this: &v2->RBX::Described<RBX::DataModel,RBX::ServiceProvider>); /*0x14109b69d*/
  if ( this != nullptr ) /*0x14109b6a3*/
  {
    Rep = this->_Wptr._Rep; /*0x14109b6a5*/
    if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x14109b6b7*/
LABEL_37:
      std::_Throw_bad_weak_ptr(); /*0x14109ba5b*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c00000000000bc*/
    while ( 1 ) /*0x14109b6c3*/
    {
      v6 = Uses; /*0x14109b6c3*/
      Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x14109b6c3*/
      if ( v6 == Uses ) /*0x14109b6c8*/
        break; /*0x14109b6c8*/
      if ( Uses == 0 ) /*0x14109b6cc*/
      {
        if ( __eh34_unwind(0) ) /*0xf1c0000000000004*/
          goto unwind_state_0; /*0xf1c0000000000004*/
        __eh34_exit_wind_state(0, -1); /*0xf1c0000000000010*/
        goto LABEL_37; /*0xf1c0000000000014*/
      }
    }
    v7 = this->_Wptr._Rep; /*0x14109b6d8*/
    Ptr = this->_Wptr._Ptr; /*0x14109b6dc*/
    v23 = (volatile signed __int32 *)v7; /*0x14109b6e1*/
    p_Ptr = &Ptr; /*0x14109b6e6*/
    v9 = 27; /*0x14109b6eb*/
  }
  else
  {
    __eh34_enter_wind_state(-1, 0); /*0xf1c00000000000b4*/
    v24 = 0; /*0x14109b6f5*/
    p_Ptr = (RBX::Reflection::DescribedBase **)&v24; /*0x14109b6fb*/
    v9 = 12; /*0x14109b700*/
  }
  weakThis = 0; /*0x14109b708*/
  v10 = (std::_Ref_count_base *)p_Ptr[1]; /*0x14109b70e*/
  if ( v10 != nullptr ) /*0x14109b715*/
  {
    weakThis._Ptr = (RBX::Network::ClientReplicator *)*p_Ptr; /*0x14109b71a*/
    weakThis._Rep = v10; /*0x14109b71f*/
    _InterlockedIncrement((volatile signed __int32 *)&v10->_Weaks); /*0x14109b724*/
  }
  if ( (v9 & 4) != 0 ) /*0x14109b731*/
  {
    v9 &= ~4u; /*0x14109b733*/
    if ( *((_QWORD *)&v24 + 1) != 0 /*0x14109b74a*/
      && _InterlockedExchangeAdd((volatile signed __int32 *)(*((_QWORD *)&v24 + 1) + 8LL), 0xFFFFFFFF) == 1 )
    {
      v11 = *((_QWORD *)&v24 + 1); /*0x14109b74c*/
      (***((void (__fastcall ****)(_QWORD))&v24 + 1))(a1: *((_QWORD *)&v24 + 1)); /*0x14109b757*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v11 + 12), 0xFFFFFFFF) == 1 ) /*0x14109b763*/
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v24 + 1) + 8LL))(a1: *((_QWORD *)&v24 + 1)); /*0x14109b76d*/
    }
  }
  if ( (v9 & 2) != 0 && v23 != nullptr && _InterlockedExchangeAdd(v23 + 2, 0xFFFFFFFF) == 1 ) /*0x14109b78a*/
  {
    v12 = v23; /*0x14109b78c*/
    (**(void (__fastcall ***)(volatile signed __int32 *))v23)(a1: v23); /*0x14109b797*/
    if ( _InterlockedExchangeAdd(v12 + 3, 0xFFFFFFFF) == 1 ) /*0x14109b7a3*/
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 8LL))(a1: v23); /*0x14109b7ad*/
  }
  aggregateFramesSetting = this->aggregateFramesSetting; /*0x14109b7b1*/
  RBX::Analytics::InfluxDb::Points::Points( /*0x14109b7c4*/
    this: &jobTimerPoints,
    throttleHundredthsPercentage: -1,
    categoryType: kStandardType,
    priorityHundredthsPercentage: 0);
  __wind /*0xf1c0000000000090*/
  {
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109b7dd*/
      this: &jobTimerPoints,
      name: "streamingEnabled",
      value: this->streamingEnabled);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109b804*/
      this: &jobTimerPoints,
      name: "deserializePacketsJob_total",
      value: this->joinRxStats.packetDeserializeTimeMs._Storage._Value);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109b81b*/
      this: &jobTimerPoints,
      name: "deserializeReportGroup",
      value: this->joinRxStats.deserializeReportingGroup);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109b832*/
      this: &jobTimerPoints,
      name: "processingReportGroup",
      value: this->joinRxStats.processingReportingGroup);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109b84b*/
      this: &jobTimerPoints,
      name: "connectionAcceptedToGameLoadTime",
      value: this->joinRxStats.connectionAcceptedToGameLoadTimeMs);
    v14 = (double)(DFInt::ClientDelayCaptureInitExpStatsMs / 1000); /*0x14109b869*/
    v25 = 0; /*0x14109b887*/
    v15 = weakThis._Rep; /*0x14109b88d*/
    if ( weakThis._Rep != nullptr ) /*0x14109b895*/
    {
      v25 = weakThis; /*0x14109b89c*/
      _InterlockedIncrement((volatile signed __int32 *)&weakThis._Rep->_Weaks); /*0x14109b8a6*/
      v15 = weakThis._Rep; /*0x14109b8ab*/
    }
    __wind /*0xf1c0000000000084*/
    {
      v26 = aggregateFramesSetting; /*0x14109b8b0*/
      v31._Result = &_Right; /*0x14109b8b9*/
      std::unordered_map<std::string,std::string>::unordered_map<std::string,std::string>( /*0x14109b8c9*/
        this: &_Right.pointList,
        _Right: &jobTimerPoints.pointList);
      __wind /*0xf1c0000000000060*/
      {
        std::string::string( /*0x14109b8d7*/
          this: (rtc::webrtc_checks_impl::ToStringVal *)&_Right.userIdOverride,
          __that: (const rtc::webrtc_checks_impl::ToStringVal *)&jobTimerPoints.userIdOverride);
        _Right.category = jobTimerPoints.category; /*0x14109b8df*/
        _Right.canSendReport = jobTimerPoints.canSendReport; /*0x14109b8e6*/
        _Right.addPriorityTag = jobTimerPoints.addPriorityTag; /*0x14109b8ed*/
      }
      __unwind
      {
        std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: v31._Result); /*0xf1c0000000000070*/
      }
    }
    __unwind
    {
      std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)&v25); /*0xf1c000000000007c*/
    }
    v30._Mystorage._Ptrs[7] = nullptr; /*0x14109b8fc*/
    __wind /*0xf1c00000000000d8*/
    {
      __wind /*0xf1c00000000000e0*/
      {
        v16 = operator new(size: 0x88u); /*0x14109b908*/
        __wind /*0xf1c00000000000c4*/
        {
          __wind /*0xf1c00000000000cc*/
          {
            v17 = (std::_Func_base<void> *)v16; /*0x14109b90d*/
            v31._Result = v16; /*0x14109b910*/
            *v16 = std::_Func_impl_no_alloc__lambda_577d35e8c2c81dabd75790ca297eaf95__void_::_vftable_; /*0x14109b91e*/
            v32 = (std::weak_ptr<PluginPermissionsFetcher> *)(v16 + 1); /*0x14109b925*/
            v16[1] = 0; /*0x14109b92c*/
            v16[2] = 0; /*0x14109b92f*/
            *(std::weak_ptr<RBX::Network::ClientReplicator> *)(v16 + 1) = v25; /*0x14109b938*/
            v25 = 0; /*0x14109b947*/
            *((_DWORD *)v16 + 6) = v26; /*0x14109b951*/
            v18 = (rtc::webrtc_checks_impl::ToStringVal *)(v16 + 4); /*0x14109b954*/
            v29 = v16 + 4; /*0x14109b958*/
            std::unordered_map<std::string,std::string>::unordered_map<std::string,std::string>( /*0x14109b964*/
              this: (std::unordered_map<std::string,std::string> *)(v16 + 4),
              _Right: &_Right.pointList);
            __wind /*0xf1c0000000000018*/
            {
              std::string::string( /*0x14109b972*/
                this: v18 + 2,
                __that: (const rtc::webrtc_checks_impl::ToStringVal *)&_Right.userIdOverride);
              *(_DWORD *)v18[3].val._Mypair._Myval2._Bx._Buf = _Right.category; /*0x14109b97a*/
              v18[3].val._Mypair._Myval2._Bx._Buf[4] = _Right.canSendReport; /*0x14109b981*/
              v18[3].val._Mypair._Myval2._Bx._Buf[5] = _Right.addPriorityTag; /*0x14109b988*/
              v30._Mystorage._Ptrs[7] = v17; /*0x14109b98b*/
              RBX::Analytics::InfluxDb::Points::~Points(this: &_Right); /*0x14109b997*/
              v19 = v25._Rep; /*0x14109b99c*/
              if ( v25._Rep != nullptr ) /*0x14109b9a4*/
              {
                if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v25._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14109b9b0*/
                  v19->_Delete_this(this: v19); /*0x14109b9b5*/
                v15 = weakThis._Rep; /*0x14109b9b8*/
              }
            }
            __unwind
            {
              std::unordered_map<RBX::Soundscape::SoundId,std::string>::~unordered_map<RBX::Soundscape::SoundId,std::string>(t: v29); /*0xf1c0000000000028*/
            }
          }
          __unwind
          {
            std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: v32); /*0xf1c0000000000034*/
          }
        }
        __unwind
        {
          `std::_Global_new<std::_Func_impl_no_alloc<_lambda_8d7edecd22d4a0c95288bc8289189ecd_,void,>,_lambda_8d7edecd22d4a0c95288bc8289189ecd_ const &>'::`2'::_Guard_type::~_Guard_type(this: &v31); /*0xf1c0000000000040*/
        }
      }
      __unwind
      {
        std::function<void (__int64)>::~function<void (__int64)>(this: (std::function<void __cdecl(std::string,std::unordered_map<__int64,std::vector<RBX::Permission>>)> *)&v30); /*0xf1c000000000004c*/
      }
    }
    __unwind
    {
      lambda_577d35e8c2c81dabd75790ca297eaf95_::__lambda_577d35e8c2c81dabd75790ca297eaf95_(a1: &v25); /*0xf1c0000000000058*/
    }
    RBX::TimerService::delay(this: v3, func: &v30, seconds: v14); /*0x14109b9c7*/
    if ( jobTimerPoints.userIdOverride._Mypair._Myval2._Myres >= 0x10 ) /*0x14109b9d5*/
    {
      v20 = jobTimerPoints.userIdOverride._Mypair._Myval2._Bx._Ptr; /*0x14109b9da*/
      if ( jobTimerPoints.userIdOverride._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109b9e8*/
      {
        v20 = *((char **)jobTimerPoints.userIdOverride._Mypair._Myval2._Bx._Ptr - 1); /*0x14109b9ee*/
        if ( (unsigned __int64)(jobTimerPoints.userIdOverride._Mypair._Myval2._Bx._Ptr - v20 - 8) > 0x1F ) /*0x14109b9fd*/
          _invalid_parameter_noinfo_noreturn(); /*0x14109b9ff*/
      }
      operator delete(ptr: v20); /*0x14109ba06*/
    }
    *(__m128i *)&jobTimerPoints.userIdOverride._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14109ba13*/
    jobTimerPoints.userIdOverride._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109ba18*/
    std::_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>::~_Hash<std::_Umap_traits<RBX::Soundscape::SoundId,std::string,std::_Uhash_compare<RBX::Soundscape::SoundId,std::hash<RBX::Soundscape::SoundId>,std::equal_to<RBX::Soundscape::SoundId>>,std::allocator<std::pair<RBX::Soundscape::SoundId const,std::string>>,0>>(this: (std::_Hash<std::_Uset_traits<std::pair<std::string,std::string >,std::_Uhash_compare<std::pair<std::string,std::string >,RBX::Hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > > >,std::allocator<std::pair<std::string,std::string > >,0> > *)&jobTimerPoints); /*0x14109ba20*/
    if ( v15 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v15->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14109ba34*/
      weakThis._Rep->_Delete_this(this: weakThis._Rep); /*0x14109ba3e*/
  }
  __unwind
  {
    RBX::Analytics::InfluxDb::Points::~Points(this: &jobTimerPoints); /*0xf1c00000000000a0*/
  }
  if ( __eh34_unwind(0) ) /*0xf1c00000000000a8*/
  {
unwind_state_0:
    std::weak_ptr<RBX::Soundscape::Sound>::~weak_ptr<RBX::Soundscape::Sound>(this: (std::weak_ptr<PluginPermissionsFetcher> *)&weakThis); /*0xf1c0000000000008*/
    __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000000c*/
  }
  __eh34_exit_wind_state(0, -1); /*0xf1c00000000000ac*/
}

// Address: 0x14109ba70 | Name: ?prepareJoinRxDataStats@ClientReplicator@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::ClientReplicator::prepareJoinRxDataStats(RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator *v1; // r15
  Luau::InternalErrorReporter *v2; // rdi
  std::_Func_base<void,char const *>_vtbl *v3; // rbx
  Luau::InternalErrorReporter *v4; // rdi
  std::_Func_base<void,char const *>_vtbl *v5; // rbx
  int framesWithJDIProcessing; // ebx
  double v7; // xmm2_8
  float v8; // xmm13_4
  float v9; // xmm8_4
  float v10; // xmm9_4
  float v11; // xmm10_4
  float v12; // xmm11_4
  float v13; // xmm7_4
  float v14; // xmm15_4
  float v15; // xmm14_4
  int totalInstancesInBlobs; // ecx
  int totalSharedStringBytesUncompressedInJoin; // ecx
  int totalBlobBytesRxDuringJoin; // r8d
  int totalSharedStringBytesRxInJoin; // edx
  int totalMetaBytesRxInJoin; // ecx
  int totalWasteBytesRxInJoin; // eax
  float joinDataReadTimeInMs; // xmm0_4
  bool v23; // r13
  unsigned int *Buckets; // rsi
  unsigned int *v25; // r14
  std::_String_constructor_concat_tag v26; // bl
  std::_String_constructor_concat_tag v27; // di
  __int64 v28; // r12
  const std::string *v29; // r8
  unsigned __int64 Mysize; // rcx
  const char *Ptr; // r9
  RBX::json::RbxWriter *writer; // rcx
  __int64 v33; // r12
  const std::string *v34; // r8
  unsigned __int64 v35; // rcx
  const char *v36; // r9
  RBX::json::RbxWriter *v37; // rcx
  std::string *v38; // rax
  char *v39; // rcx
  const std::string *v40; // rax
  char *v41; // rcx
  bool v42; // r13
  unsigned int *v43; // rsi
  unsigned int *v44; // r14
  std::_String_constructor_concat_tag v45; // bl
  std::_String_constructor_concat_tag v46; // di
  __int64 v47; // r12
  const std::string *v48; // r8
  unsigned __int64 v49; // rcx
  const char *v50; // r9
  RBX::json::RbxWriter *v51; // rcx
  __int64 v52; // r12
  const std::string *v53; // r8
  unsigned __int64 v54; // rcx
  const char *v55; // r9
  RBX::json::RbxWriter *v56; // rcx
  std::string *v57; // rax
  char *v58; // rcx
  const std::string *v59; // rax
  char *v60; // rcx
  std::_List_node<std::pair<std::string const ,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> > >,void *> *Myhead; // r13
  std::_List_node<std::pair<std::string const ,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> > >,void *> *Next; // rbx
  unsigned __int64 v63; // rcx
  _QWORD *p_Ptr; // rax
  int v65; // r12d
  unsigned int *v66; // rsi
  unsigned int *v67; // r14
  unsigned __int64 v68; // rdi
  char v69; // si
  int v70; // r12d
  int v71; // esi
  bool v72; // r14
  unsigned int *v73; // rbx
  unsigned int *v74; // rdi
  const std::string *v75; // rax
  char *v76; // rcx
  const std::string *v77; // rax
  char *v78; // rcx
  int v79; // ebx
  _WORD *v80; // rax
  char *v81; // rcx
  unsigned int *v82; // rbx
  unsigned int *v83; // rdi
  const std::string *v84; // rax
  char *v85; // rcx
  unsigned int v86; // r13d
  signed int v87; // ebx
  double connectionAcceptedToGameLoadTimeMs; // xmm0_8
  double v89; // xmm12_8
  unsigned int v90; // eax
  unsigned int v91; // ebx
  signed int v92; // edi
  signed int v93; // esi
  signed int v94; // r14d
  signed int v95; // r12d
  double v96; // xmm7_8
  double v97; // xmm8_8
  double v98; // xmm11_8
  double v99; // xmm6_8
  double v100; // xmm9_8
  std::pair<std::string,double> *Myend; // rdx
  unsigned __int64 v102; // rax
  char *v103; // rcx
  unsigned int firstDataPacketArriveCycle; // eax
  signed int v105; // ebx
  unsigned int v106; // edi
  signed int v107; // esi
  signed int v108; // r14d
  signed int v109; // r12d
  double v110; // xmm7_8
  double v111; // xmm8_8
  double v112; // xmm6_8
  double v113; // xmm9_8
  std::pair<std::string,double> *v114; // rdx
  unsigned __int64 v115; // rdi
  unsigned __int64 Myres; // rax
  char *v117; // rcx
  long double packetDeserializeUpToGameLoadTagTimeMs; // xmm6_8
  std::pair<std::string,double> *v119; // rdx
  unsigned __int64 v120; // rax
  char *v121; // rcx
  int totalBytesDeserializedUpToGameLoadedTag; // ebx
  std::pair<std::string,double> *v123; // rdx
  unsigned __int64 v124; // rax
  char *v125; // rcx
  long double *p_packetProcessingCppTimeMs; // rbx
  long double *p_packetProcessingScriptContextTimeMs; // rsi
  double v128; // xmm6_8
  std::pair<std::string,double> *v129; // rdx
  unsigned __int64 v130; // rax
  char *v131; // rcx
  double v132; // xmm6_8
  std::pair<std::string,double> *v133; // rdx
  char *v134; // rcx
  double v135; // xmm6_8
  std::pair<std::string,double> *v136; // rdx
  long double v137; // xmm1_8
  Luau::InternalErrorReporter *v138; // rax
  std::_Func_base<void,char const *>_vtbl *v139; // r9
  Luau::InternalErrorReporter *v140; // rdi
  std::_Func_base<void,char const *>_vtbl *v141; // rbx
  RakNet::AddressOrGUID *v142; // rax
  unsigned int v143; // edi
  Luau::InternalErrorReporter *v144; // rax
  unsigned int v145; // ebx
  long double v146; // xmm6_8
  Luau::InternalErrorReporter *v147; // rax
  std::_Func_base<void,char const *>_vtbl *v148; // r9
  long double v149; // xmm6_8
  float *p_joinDataProcessTimeInMs; // rdi
  float v151; // xmm10_4
  float v152; // xmm9_4
  float v153; // xmm8_4
  float v154; // xmm7_4
  float v155; // xmm6_4
  long double v156; // xmm3_8
  float *p_initialClusterProcessTimeInMs; // r14
  const char *v158; // rdx
  std::string *v159; // rax
  std::pair<std::string,double> *v160; // rax
  std::string *v161; // rax
  std::pair<std::string,double> *v162; // rax
  std::string *v163; // rax
  std::pair<std::string,double> *v164; // rax
  std::string *v165; // rax
  std::pair<std::string,float> *v166; // rax
  std::string *v167; // rax
  std::pair<std::string,float> *v168; // rax
  std::string *v169; // rax
  std::pair<std::string,double> *v170; // rax
  std::string *v171; // rax
  std::pair<std::string,double> *v172; // rax
  std::string *v173; // rax
  std::pair<std::string,double> *v174; // rax
  int v175; // ecx
  double v176; // xmm1_8
  std::string *v177; // rax
  std::pair<std::string,double> *v178; // rax
  std::string *v179; // rax
  std::pair<std::string,double> *v180; // rax
  std::string *v181; // rax
  std::pair<std::string,double> *v182; // rax
  unsigned int v183; // ecx
  unsigned __int64 _Left_size; // [rsp+28h] [rbp-E0h]
  unsigned __int64 _Right_size; // [rsp+38h] [rbp-D0h]
  __int64 v186; // [rsp+48h] [rbp-C0h]
  __int64 v187; // [rsp+58h] [rbp-B0h]
  std::vector<std::pair<std::string,double>> gameLoadStats; // [rsp+60h] [rbp-A8h] BYREF
  std::pair<std::string,double> *v189; // [rsp+78h] [rbp-90h]
  float v190; // [rsp+80h] [rbp-88h]
  float v191; // [rsp+84h] [rbp-84h]
  std::vector<std::pair<std::string,double>> stats; // [rsp+88h] [rbp-80h] BYREF
  __int64 v193; // [rsp+A0h] [rbp-68h]
  int v194; // [rsp+A8h] [rbp-60h]
  RBX::Analytics::InfluxDb::Points points; // [rsp+B0h] [rbp-58h] BYREF
  RakNet::JoinRxStats raknetJoinStats; // [rsp+128h] [rbp+20h] BYREF
  RBX::json::Writer instancesWriter; // [rsp+138h] [rbp+30h] BYREF
  RakNet::SystemAddress v198; // [rsp+150h] [rbp+48h] BYREF
  RakNet::RakNetJoinRxStats v199; // [rsp+170h] [rbp+68h] BYREF
  RBX::json::Writer v200; // [rsp+198h] [rbp+90h] BYREF
  RBX::json::Writer joinWriter; // [rsp+1B0h] [rbp+A8h] BYREF
  RBX::json::Writer topReplicationContainerWriter; // [rsp+1D0h] [rbp+C8h] BYREF
  std::string streamingTag; // [rsp+1E8h] [rbp+E0h] BYREF
  RBX::Graphics::ProfilerAdorn::Item resource; // [rsp+210h] [rbp+108h] BYREF
  std::pair<std::string,double> v205; // [rsp+248h] [rbp+140h] BYREF
  std::pair<std::string,double> v206; // [rsp+270h] [rbp+168h] BYREF
  std::pair<std::string,double> v207; // [rsp+298h] [rbp+190h] BYREF
  std::pair<std::string,double> v208; // [rsp+2C0h] [rbp+1B8h] BYREF
  std::_String_val<std::_Simple_types<char> >::_Bxty v209; // [rsp+2E8h] [rbp+1E0h] BYREF
  __m128i si128; // [rsp+2F8h] [rbp+1F0h]
  RBX::json::Writer sharedStringWriter; // [rsp+308h] [rbp+200h] BYREF
  std::pair<std::string,double> v212; // [rsp+328h] [rbp+220h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v213; // [rsp+350h] [rbp+248h] BYREF
  __int128 v214; // [rsp+388h] [rbp+280h]
  std::pair<char const *,double> _Right; // [rsp+398h] [rbp+290h] BYREF
  std::pair<char const *,double> v216; // [rsp+3A8h] [rbp+2A0h] BYREF
  std::pair<char const *,unsigned long> v217; // [rsp+3B8h] [rbp+2B0h] BYREF
  std::pair<char const *,unsigned long> v218; // [rsp+3C8h] [rbp+2C0h] BYREF
  std::pair<char const *,double> v219; // [rsp+3D8h] [rbp+2D0h] BYREF
  std::pair<char const *,unsigned long> v220; // [rsp+3E8h] [rbp+2E0h] BYREF
  std::pair<char const *,unsigned long> v221; // [rsp+3F8h] [rbp+2F0h] BYREF
  std::pair<char const *,float> v222; // [rsp+408h] [rbp+300h] BYREF
  std::pair<char const *,float> v223; // [rsp+418h] [rbp+310h] BYREF
  std::pair<char const *,unsigned long> v224; // [rsp+428h] [rbp+320h] BYREF
  std::pair<char const *,double> v225; // [rsp+438h] [rbp+330h] BYREF
  std::pair<char const *,float> v226; // [rsp+448h] [rbp+340h] BYREF
  std::pair<char const *,float> v227; // [rsp+458h] [rbp+350h] BYREF
  std::pair<char const *,float> v228; // [rsp+468h] [rbp+360h] BYREF
  std::pair<char const *,float> v229; // [rsp+478h] [rbp+370h] BYREF
  std::pair<char const *,float> v230; // [rsp+488h] [rbp+380h] BYREF
  std::pair<char const *,unsigned long> v231; // [rsp+498h] [rbp+390h] BYREF
  std::pair<char const *,unsigned long> v232; // [rsp+4A8h] [rbp+3A0h] BYREF
  std::pair<char const *,unsigned long> v233; // [rsp+4B8h] [rbp+3B0h] BYREF
  std::pair<char const *,float> v234; // [rsp+4C8h] [rbp+3C0h] BYREF
  std::string v235; // [rsp+4D8h] [rbp+3D0h] BYREF
  std::string v236; // [rsp+4F8h] [rbp+3F0h] BYREF
  _QWORD v237[4]; // [rsp+518h] [rbp+410h] BYREF
  _QWORD v238[4]; // [rsp+538h] [rbp+430h] BYREF
  std::string v239; // [rsp+558h] [rbp+450h] BYREF
  std::string result; // [rsp+578h] [rbp+470h] BYREF
  std::string v241; // [rsp+598h] [rbp+490h] BYREF
  std::string v242; // [rsp+5B8h] [rbp+4B0h] BYREF
  std::string v243; // [rsp+5D8h] [rbp+4D0h] BYREF
  RBX::Analytics::InfluxDb::Points v244; // [rsp+5F8h] [rbp+4F0h] BYREF
  std::pair<std::string,double> _Val; // [rsp+668h] [rbp+560h] BYREF
  std::pair<std::string,double> v246; // [rsp+690h] [rbp+588h] BYREF
  std::pair<std::string,double> v247; // [rsp+6B8h] [rbp+5B0h] BYREF
  std::pair<std::string,double> v248; // [rsp+6E0h] [rbp+5D8h] BYREF
  std::pair<std::string,double> v249; // [rsp+708h] [rbp+600h] BYREF
  std::pair<std::string,double> v250; // [rsp+730h] [rbp+628h] BYREF
  std::pair<std::string,double> v251; // [rsp+758h] [rbp+650h] BYREF
  std::pair<std::string,double> v252; // [rsp+780h] [rbp+678h] BYREF
  std::pair<std::string,double> v253; // [rsp+7A8h] [rbp+6A0h] BYREF
  std::pair<std::string,double> v254; // [rsp+7D0h] [rbp+6C8h] BYREF
  std::pair<std::string,double> v255; // [rsp+7F8h] [rbp+6F0h] BYREF
  std::pair<std::string,double> v256; // [rsp+820h] [rbp+718h] BYREF
  std::pair<std::string,double> v257; // [rsp+848h] [rbp+740h] BYREF
  std::pair<std::string,double> v258; // [rsp+870h] [rbp+768h] BYREF
  std::pair<std::string,double> v259; // [rsp+898h] [rbp+790h] BYREF
  std::pair<std::string,double> v260; // [rsp+8C0h] [rbp+7B8h] BYREF
  std::pair<std::string,double> v261; // [rsp+8E8h] [rbp+7E0h] BYREF
  std::pair<std::string,double> v262; // [rsp+910h] [rbp+808h] BYREF
  std::pair<std::string,double> v263; // [rsp+938h] [rbp+830h] BYREF
  std::pair<std::string,double> v264; // [rsp+960h] [rbp+858h] BYREF
  std::pair<std::string,double> v265; // [rsp+988h] [rbp+880h] BYREF
  std::pair<std::string,double> v266; // [rsp+9B0h] [rbp+8A8h] BYREF
  std::string v267; // [rsp+9D8h] [rbp+8D0h] BYREF
  std::string v268; // [rsp+9F8h] [rbp+8F0h] BYREF
  std::string v269; // [rsp+A18h] [rbp+910h] BYREF
  std::string v270; // [rsp+A38h] [rbp+930h] BYREF
  std::string v271; // [rsp+A58h] [rbp+950h] BYREF
  std::string v272; // [rsp+A78h] [rbp+970h] BYREF
  std::string v273; // [rsp+A98h] [rbp+990h] BYREF
  std::string v274; // [rsp+AB8h] [rbp+9B0h] BYREF
  std::string v275; // [rsp+AD8h] [rbp+9D0h] BYREF
  std::string v276; // [rsp+AF8h] [rbp+9F0h] BYREF
  std::string v277; // [rsp+B18h] [rbp+A10h] BYREF
  std::pair<std::string,double> v278; // [rsp+B38h] [rbp+A30h] BYREF
  std::pair<std::string,float> v279; // [rsp+B60h] [rbp+A58h] BYREF
  std::pair<std::string,float> v280; // [rsp+B88h] [rbp+A80h] BYREF
  std::pair<std::string,double> v281; // [rsp+BB0h] [rbp+AA8h] BYREF
  std::pair<std::string,double> v282; // [rsp+BD8h] [rbp+AD0h] BYREF
  std::pair<std::string,double> v283; // [rsp+C00h] [rbp+AF8h] BYREF
  std::pair<std::string,double> v284; // [rsp+C28h] [rbp+B20h] BYREF
  std::pair<std::string,double> v285; // [rsp+C50h] [rbp+B48h] BYREF
  std::pair<std::string,double> v286; // [rsp+C78h] [rbp+B70h] BYREF
  std::pair<std::string,double> v287; // [rsp+CA0h] [rbp+B98h] BYREF
  std::pair<std::string,double> v288; // [rsp+CC8h] [rbp+BC0h] BYREF
  RakNet::AddressOrGUID v289; // [rsp+CF0h] [rbp+BE8h] BYREF
  RBX::Network::ClientReplicator *v290; // [rsp+E18h] [rbp+D10h] BYREF
  double avgJdiV2ProcessedPerFrame; // [rsp+E20h] [rbp+D18h] BYREF
  long double Value; // [rsp+E28h] [rbp+D20h]
  float v293; // [rsp+E30h] [rbp+D28h]

  v290 = this; /*0x14109ba73*/
  v1 = this; /*0x14109bad6*/
  v2 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14109bae5*/
  v3 = v2->onInternalError._Mystorage._Ptrs[0][90].__vftable; /*0x14109baeb*/
  RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)&instancesWriter.writer); /*0x14109baf6*/
  RakNet::SystemAddress::SystemAddress(this: &v198); /*0x14109baff*/
  *(RakNet::RakNetGUID *)&instancesWriter.writer = RakNet::UNASSIGNED_RAKNET_GUID_22; /*0x14109bb0b*/
  RakNet::SystemAddress::operator=(this: &v198, input: &v1->remotePlayerRakNetAddress); /*0x14109bb25*/
  LODWORD(v3) = ((__int64 (__fastcall *)(Luau::InternalErrorReporter *, RBX::json::RbxWriter **))v3)( /*0x14109bb33*/
                  a1: v2,
                  a2: &instancesWriter.writer);
  v1->joinRxStats.deltaTimeBetweenJoinRequestAndFirstBlobArrivalInMs = (float)(v1->firstDataPacketArriveTimeAfterJoinRequestInMS /*0x14109bb46*/
                                                                             - (int)v3);
  v1->joinRxStats.deltaTimeBetweenJoinRequestAndJoinProcessingCompleteInMs = (float)(int)(RakNet::GetTimeMS() /*0x14109bb5e*/
                                                                                        - (_DWORD)v3);
  *(_QWORD *)&raknetJoinStats.totalRxIgnoredBytes = 0; /*0x14109bb67*/
  instancesWriter.buffer = nullptr; /*0x14109bb6f*/
  v4 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)v1->rakPeer._Ptr); /*0x14109bb83*/
  v5 = v4->onInternalError._Mystorage._Ptrs[0][37].__vftable; /*0x14109bb89*/
  RakNet::RakNetGUID::RakNetGUID(this: (RakNet::RakNetGUID *)&instancesWriter.writer); /*0x14109bb94*/
  RakNet::SystemAddress::SystemAddress(this: &v198); /*0x14109bb9d*/
  *(RakNet::RakNetGUID *)&instancesWriter.writer = RakNet::UNASSIGNED_RAKNET_GUID_22; /*0x14109bba9*/
  RakNet::SystemAddress::operator=(this: &v198, input: &v1->remotePlayerRakNetAddress); /*0x14109bbc3*/
  ((void (__fastcall *)(Luau::InternalErrorReporter *, RBX::json::RbxWriter **, unsigned int *))v5)( /*0x14109bbd3*/
    a1: v4,
    a2: &instancesWriter.writer,
    a3: &raknetJoinStats.totalRxIgnoredBytes);
  RBX::Analytics::InfluxDb::Points::Points( /*0x14109bbe6*/
    this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
    throttleHundredthsPercentage: v1->joinRxStats.reportingHundrethPercentage,
    categoryType: kStandardType,
    priorityHundredthsPercentage: 0);
  __wind
  {
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bc03*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "deltaTimeBetweenJoinRequestAndFirstBlobArrivalInMs",
      value: v1->joinRxStats.deltaTimeBetweenJoinRequestAndFirstBlobArrivalInMs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bc1f*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "deltaTimeBetweenJoinRequestAndJoinProcessingCompleteInMs",
      value: v1->joinRxStats.deltaTimeBetweenJoinRequestAndJoinProcessingCompleteInMs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bc3b*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "joinDataReadTimeInMs",
      value: v1->joinRxStats.joinDataReadTimeInMs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bc57*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "joinDataProcessTimeInMs",
      value: v1->joinRxStats.joinDataProcessTimeInMs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bc6e*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalBlobBytesRxDuringJoin",
      value: v1->joinRxStats.totalBlobBytesRxDuringJoin);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bc85*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalBlobRxDuringJoin",
      value: v1->joinRxStats.totalBlobRxDuringJoin);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bc9c*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalMetaBytesRxInJoin",
      value: v1->joinRxStats.totalMetaBytesRxInJoin);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bcb3*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalWasteBytesRxInJoin",
      value: v1->joinRxStats.totalWasteBytesRxInJoin);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bcca*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalSharedStringBytesRxDuringJoin",
      value: v1->joinRxStats.totalSharedStringBytesRxInJoin);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bcde*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalRxBytes",
      value: raknetJoinStats.totalRxIgnoredBytes);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bcf2*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalRxPackets",
      value: raknetJoinStats.totalRxIgnoredPackets);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bd06*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalRxIgnoredBytes",
      value: (unsigned int)instancesWriter.buffer);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bd1a*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalRxIgnoredPackets",
      value: HIDWORD(instancesWriter.buffer));
    avgJdiV2ProcessedPerFrame = v1->joinRxStats.packetDeserializeTimeClusterMs._Storage._Value; /*0x14109bd26*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bd41*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "initialClusterDeserializationTimeMs",
      value: avgJdiV2ProcessedPerFrame);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bd5d*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "initialClusterProcessTimeMs",
      value: v1->joinRxStats.initialClusterProcessTimeInMs);
    avgJdiV2ProcessedPerFrame = v1->joinRxStats.packetDeserializeTimeMs._Storage._Value; /*0x14109bd69*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bd84*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalDeserializationTimeMs",
      value: avgJdiV2ProcessedPerFrame);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bd9d*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "packetProcessTimeCppMs",
      value: v1->joinRxStats.packetProcessingCppTimeMs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bdb6*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "packetProcessTimeScriptContextMs",
      value: v1->joinRxStats.packetProcessingScriptContextTimeMs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bdd8*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalPacketProcessTimeMs",
      value: v1->joinRxStats.packetProcessingCppTimeMs + v1->joinRxStats.packetProcessingScriptContextTimeMs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bdf1*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "connectionAcceptedToGameLoadTimeMs",
      value: v1->joinRxStats.connectionAcceptedToGameLoadTimeMs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109be0a*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "connectionAcceptedToFirstPacketProcessMs",
      value: v1->joinRxStats.connectionAcceptedToFirstPacketProcessMs);
    framesWithJDIProcessing = v1->joinRxStats.framesWithJDIProcessing; /*0x14109be0f*/
    if ( v1->joinRxStats.frameHasJdiProcessWork._Storage._Value ) /*0x14109be16*/
      ++framesWithJDIProcessing; /*0x14109be23*/
    v7 = 0.0; /*0x14109be29*/
    if ( framesWithJDIProcessing > 0 ) /*0x14109be2e*/
      v7 = (double)(int)v1->joinRxStats.numJdiV2Processed / (double)framesWithJDIProcessing; /*0x14109be44*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109be53*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "avgJdiV2ProcessedPerFrame",
      value: v7);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109be6a*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "numJdiV2Processed",
      value: v1->joinRxStats.numJdiV2Processed);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109be7d*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "numFramesWithJdiProcessing",
      value: framesWithJDIProcessing);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109be96*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "longestSingleFrameCppPartJdiV2",
      value: v1->joinRxStats.longestSingleFrameCppTimeForJoinProcessingMs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109beaf*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "longestSingleFrameScriptPartJdiV2",
      value: v1->joinRxStats.longestSingleFrameScriptTimeForJoinProcessingMs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bec7*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "streamingEnabled",
      value: v1->streamingEnabled);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bede*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "deserializeReportGroup",
      value: v1->joinRxStats.deserializeReportingGroup);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bef5*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "processingReportGroup",
      value: v1->joinRxStats.processingReportingGroup);
    v8 = 0.0; /*0x14109befa*/
    v9 = 0.0; /*0x14109befe*/
    v293 = 0.0; /*0x14109bf02*/
    v10 = 0.0; /*0x14109bf0b*/
    v190 = 0.0; /*0x14109bf0f*/
    v11 = 0.0; /*0x14109bf16*/
    v191 = 0.0; /*0x14109bf1a*/
    v12 = 0.0; /*0x14109bf21*/
    LODWORD(stats._Mypair._Myval2._Myfirst) = 0; /*0x14109bf25*/
    v13 = 0.0; /*0x14109bf2b*/
    LODWORD(Value) = 0; /*0x14109bf2e*/
    v14 = 0.0; /*0x14109bf36*/
    v15 = 0.0; /*0x14109bf3a*/
    totalInstancesInBlobs = v1->joinRxStats.totalInstancesInBlobs; /*0x14109bf3e*/
    if ( totalInstancesInBlobs != 0 ) /*0x14109bf58*/
      v15 = (float)((float)(v1->joinRxStats.totalInstancesInBlobs - v1->joinRxStats.totalWasteInstancesInBlobs) * 100.0) /*0x14109bf70*/
          / (float)totalInstancesInBlobs;
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bf87*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "jdiv2TotalUncompressSharedStringSize",
      value: v1->joinRxStats.totalSharedStringBytesUncompressedInJoin);
    totalSharedStringBytesUncompressedInJoin = v1->joinRxStats.totalSharedStringBytesUncompressedInJoin; /*0x14109bf8c*/
    if ( totalSharedStringBytesUncompressedInJoin != 0 ) /*0x14109bf9c*/
    {
      v14 = (float)((float)(int)v1->joinRxStats.totalSharedStringBytesRxInJoin * 100.0) /*0x14109bfbb*/
          / (float)totalSharedStringBytesUncompressedInJoin;
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bfc8*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "jdiv2SharedStringEffCompressionRatio",
        value: v14);
    }
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bfdf*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "jdiv2TotalSharedStringCountInBlob",
      value: v1->joinRxStats.totalSharedStringCountInJoin);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109bff6*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "jdiv2TotalInstanceCountInBlob",
      value: v1->joinRxStats.totalInstancesInBlobs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c00d*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "jdiv2TotalInvalidInstanceCountInBlob",
      value: v1->joinRxStats.totalWasteInstancesInBlobs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c029*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "jdiv2SharedStringDeserializationMs",
      value: v1->joinRxStats.joinDataReadTimeSharedStringsInMs);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c045*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "jdiv2InstanceDeserializationMs",
      value: v1->joinRxStats.joinDataReadTimeInstanceInMs);
    totalBlobBytesRxDuringJoin = v1->joinRxStats.totalBlobBytesRxDuringJoin; /*0x14109c04a*/
    if ( totalBlobBytesRxDuringJoin != 0 ) /*0x14109c054*/
    {
      totalSharedStringBytesRxInJoin = v1->joinRxStats.totalSharedStringBytesRxInJoin; /*0x14109c05a*/
      v9 = (float)((float)totalSharedStringBytesRxInJoin * 100.0) / (float)totalBlobBytesRxDuringJoin; /*0x14109c077*/
      v293 = v9; /*0x14109c07c*/
      totalMetaBytesRxInJoin = v1->joinRxStats.totalMetaBytesRxInJoin; /*0x14109c085*/
      v10 = (float)((float)totalMetaBytesRxInJoin * 100.0) / (float)totalBlobBytesRxDuringJoin; /*0x14109c09a*/
      v190 = v10; /*0x14109c09f*/
      totalWasteBytesRxInJoin = v1->joinRxStats.totalWasteBytesRxInJoin; /*0x14109c0a6*/
      v11 = (float)((float)totalWasteBytesRxInJoin * 100.0) / (float)totalBlobBytesRxDuringJoin; /*0x14109c0bb*/
      v191 = v11; /*0x14109c0c0*/
      v12 = (float)((float)(totalBlobBytesRxDuringJoin /*0x14109c0e1*/
                          - totalSharedStringBytesRxInJoin
                          - totalWasteBytesRxInJoin
                          - totalMetaBytesRxInJoin)
                  * 100.0)
          / (float)totalBlobBytesRxDuringJoin;
      *(float *)&stats._Mypair._Myval2._Myfirst = v12; /*0x14109c0e6*/
    }
    joinDataReadTimeInMs = v1->joinRxStats.joinDataReadTimeInMs; /*0x14109c0ec*/
    if ( joinDataReadTimeInMs > 0.0 ) /*0x14109c0f9*/
    {
      v8 = (float)(v1->joinRxStats.joinDataReadTimeSharedStringsInMs * 100.0) / joinDataReadTimeInMs; /*0x14109c109*/
      v13 = (float)(v1->joinRxStats.joinDataReadTimeInstanceInMs * 100.0) / joinDataReadTimeInMs; /*0x14109c11b*/
      *(float *)&Value = v13; /*0x14109c11f*/
    }
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c136*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "percentageBlobBytesSharedStrings",
      value: v9);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c14a*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "percentageBlobBytesMeta",
      value: v10);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c15e*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "percentageBlobBytesWaste",
      value: v11);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c172*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "percentageBlobBytesInstance",
      value: v12);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c186*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "percentageUsefulInstancesCount",
      value: v15);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c19a*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "percentageReadTimeForSS",
      value: v8);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c1ad*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "percentageReadTimeForMetaInstances",
      value: v13);
    if ( DFFlag::ClientReportJoinInstanceTypeBreakdown2.value )
    {
      RBX::json::Writer::Writer(this: (RBX::json::Writer *)&joinWriter.writer, type: BasicWriter); /*0x14109c1c8*/
      __wind
      {
        RBX::json::Writer::startObject(this: (RBX::json::Writer *)&joinWriter.writer); /*0x14109c1d5*/
        v23 = false; /*0x14109c1da*/
        Buckets = (unsigned int *)v1->joinRxStats.joinBreakdown.Buckets; /*0x14109c1dd*/
        v25 = &Buckets[4 * v1->joinRxStats.joinBreakdown.NumBuckets]; /*0x14109c1ef*/
        if ( v1->joinRxStats.joinBreakdown.NumEntries != 0 && Buckets != v25 ) /*0x14109c203*/
        {
          do /*0x14109c228*/
          {
            if ( ((*(_QWORD *)Buckets + 0x2000LL) & 0xFFFFFFFFFFFFEFFFuLL) != 0 ) /*0x14109c21f*/
              break; /*0x14109c21f*/
            Buckets += 4; /*0x14109c221*/
          }
          while ( Buckets != v25 ); /*0x14109c228*/
          if ( Buckets != v25 ) /*0x14109c22d*/
          {
            v26 = (std::_String_constructor_concat_tag)v290; /*0x14109c233*/
            v27 = (std::_String_constructor_concat_tag)v290; /*0x14109c23a*/
            while ( RBX::json::Writer::size(this: (RBX::json::Writer *)&joinWriter.writer) <= DFInt::JoinInstanceTypeBreakdownJsonSizeLimit ) /*0x14109c257*/
            {
              v28 = Buckets[2]; /*0x14109c25d*/
              v29 = *(const std::string **)(*(_QWORD *)Buckets + 8LL); /*0x14109c264*/
              Mysize = v29->_Mypair._Myval2._Mysize; /*0x14109c268*/
              if ( 0x7FFFFFFFFFFFFFFFLL - Mysize < 6 ) /*0x14109c27d*/
                std::_Xlen_string(); /*0x14109ecda*/
              Ptr = *(const char **)(*(_QWORD *)Buckets + 8LL); /*0x14109c283*/
              if ( v29->_Mypair._Myval2._Myres >= 0x10 ) /*0x14109c28b*/
                Ptr = v29->_Mypair._Myval2._Bx._Ptr; /*0x14109c28d*/
              std::string::string( /*0x14109c2b1*/
                this: (std::string *)&instancesWriter.writer,
                __formal: v26,
                _Source_of_al: v29,
                _Left_ptr: Ptr,
                _Left_size: Mysize,
                _Right_ptr: "_count",
                _Right_size: 6u);
              __eh34_enter_wind_state(1, 2); /*0xf1c00000000004c4*/
              RBX::json::Writer::int64Key( /*0x14109c2c5*/
                this: (RBX::json::Writer *)&joinWriter.writer,
                key: (const std::string *)&instancesWriter.writer,
                value: v28);
              if ( __eh34_unwind(2) ) /*0xf1c00000000004b8*/
              {
unwind_state_2:
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&instancesWriter.writer); /*0xf1c00000000004a0*/
                __eh34_continue_unwinding(2, 1); /*0xf1c00000000004a4*/
              }
              __eh34_exit_wind_state(2, 1); /*0xf1c00000000004bc*/
              if ( *(_QWORD *)v198.address.addr4.sin_zero >= 0x10u ) /*0x14109c2d3*/
              {
                writer = instancesWriter.writer; /*0x14109c2d8*/
                if ( (unsigned __int64)(*(_QWORD *)v198.address.addr4.sin_zero + 1LL) >= 0x1000 ) /*0x14109c2e6*/
                {
                  writer = *(RBX::json::RbxWriter **)&instancesWriter.writer[-1].writeFlags; /*0x14109c2ec*/
                  if ( (unsigned __int64)((char *)instancesWriter.writer - (char *)writer - 8) > 0x1F ) /*0x14109c2fb*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14109c3e4*/
                }
                operator delete(ptr: writer); /*0x14109c301*/
              }
              v33 = Buckets[3]; /*0x14109c306*/
              v34 = *(const std::string **)(*(_QWORD *)Buckets + 8LL); /*0x14109c30d*/
              v35 = v34->_Mypair._Myval2._Mysize; /*0x14109c311*/
              if ( 0x7FFFFFFFFFFFFFFFLL - v35 < 6 ) /*0x14109c326*/
                std::_Xlen_string(); /*0x14109ecd4*/
              v36 = *(const char **)(*(_QWORD *)Buckets + 8LL); /*0x14109c32c*/
              if ( v34->_Mypair._Myval2._Myres >= 0x10 ) /*0x14109c334*/
                v36 = v34->_Mypair._Myval2._Bx._Ptr; /*0x14109c336*/
              std::string::string( /*0x14109c35b*/
                this: (std::string *)&instancesWriter.writer,
                __formal: v27,
                _Source_of_al: v34,
                _Left_ptr: v36,
                _Left_size: v35,
                _Right_ptr: "_bytes",
                _Right_size: 6u);
              __eh34_enter_wind_state(1, 2); /*0xf1c00000000004b0*/
              RBX::json::Writer::int64Key( /*0x14109c36f*/
                this: (RBX::json::Writer *)&joinWriter.writer,
                key: (const std::string *)&instancesWriter.writer,
                value: v33);
              if ( __eh34_unwind(2) ) /*0xf1c000000000049c*/
                goto unwind_state_2; /*0xf1c000000000049c*/
              __eh34_exit_wind_state(2, 1); /*0xf1c00000000004a8*/
              if ( *(_QWORD *)v198.address.addr4.sin_zero >= 0x10u ) /*0x14109c37d*/
              {
                v37 = instancesWriter.writer; /*0x14109c382*/
                if ( (unsigned __int64)(*(_QWORD *)v198.address.addr4.sin_zero + 1LL) >= 0x1000 ) /*0x14109c390*/
                {
                  v37 = *(RBX::json::RbxWriter **)&instancesWriter.writer[-1].writeFlags; /*0x14109c396*/
                  if ( (unsigned __int64)((char *)instancesWriter.writer - (char *)v37 - 8) > 0x1F ) /*0x14109c3a5*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14109c3eb*/
                }
                operator delete(ptr: v37); /*0x14109c3a7*/
              }
              Buckets += 4; /*0x14109c3ac*/
              if ( Buckets != v25 ) /*0x14109c3b3*/
              {
                do /*0x14109c3d8*/
                {
                  if ( ((*(_QWORD *)Buckets + 0x2000LL) & 0xFFFFFFFFFFFFEFFFuLL) != 0 ) /*0x14109c3cf*/
                    break; /*0x14109c3cf*/
                  Buckets += 4; /*0x14109c3d1*/
                }
                while ( Buckets != v25 ); /*0x14109c3d8*/
                if ( Buckets != v25 ) /*0x14109c3dd*/
                  continue; /*0x14109c3dd*/
              }
              goto LABEL_47; /*0x14109c3dd*/
            }
            v23 = true; /*0x14109c3f2*/
          }
        }
LABEL_47:
        RBX::json::Writer::endObject(this: (RBX::json::Writer *)&joinWriter.writer); /*0x14109c3f5*/
        if ( DFLog::JoinInstanceTypeBreakdown != 0 )
        {
          v38 = RBX::json::Writer::str(this: (RBX::json::Writer *)&joinWriter.writer, &result); /*0x14109c418*/
          __wind
          {
            if ( v38->_Mypair._Myval2._Myres >= 0x10 ) /*0x14109c423*/
              v38 = (std::string *)v38->_Mypair._Myval2._Bx._Ptr; /*0x14109c425*/
            FLog::FastLogFormatted(
              level: DFLog::JoinInstanceTypeBreakdown,
              message: "[DFLog::JoinInstanceTypeBreakdown] Join Blob Breakdown: %s",
              v38->_Mypair._Myval2._Bx._Buf);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&result); /*0xf1c0000000000488*/
          }
          if ( result._Mypair._Myval2._Myres >= 0x10 ) /*0x14109c44a*/
          {
            v39 = result._Mypair._Myval2._Bx._Ptr; /*0x14109c44f*/
            if ( result._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109c460*/
            {
              v39 = *((char **)result._Mypair._Myval2._Bx._Ptr - 1); /*0x14109c466*/
              if ( (unsigned __int64)(result._Mypair._Myval2._Bx._Ptr - v39 - 8) > 0x1F ) /*0x14109c475*/
                _invalid_parameter_noinfo_noreturn(); /*0x14109c477*/
            }
            operator delete(ptr: v39); /*0x14109c47e*/
          }
        }
        v40 = RBX::json::Writer::str(this: (RBX::json::Writer *)&joinWriter.writer, result: &v239); /*0x14109c491*/
        __wind /*0xf1c0000000000478*/
        {
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c4a5*/
            this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
            name: "joinBlobInstanceTypeBreakdown",
            value: v40);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v239); /*0xf1c0000000000470*/
        }
        if ( v239._Mypair._Myval2._Myres >= 0x10 ) /*0x14109c4b6*/
        {
          v41 = v239._Mypair._Myval2._Bx._Ptr; /*0x14109c4bb*/
          if ( v239._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109c4cc*/
          {
            v41 = *((char **)v239._Mypair._Myval2._Bx._Ptr - 1); /*0x14109c4d2*/
            if ( (unsigned __int64)(v239._Mypair._Myval2._Bx._Ptr - v41 - 8) > 0x1F ) /*0x14109c4e1*/
              _invalid_parameter_noinfo_noreturn(); /*0x14109c4e3*/
          }
          operator delete(ptr: v41); /*0x14109c4ea*/
        }
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c4fe*/
          this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
          name: "joinBlobBreakdownTruncated",
          value: v23);
        RBX::json::Writer::Writer(this: &v200, type: BasicWriter); /*0x14109c50c*/
        __wind
        {
          RBX::json::Writer::startObject(this: &v200); /*0x14109c519*/
          v42 = false; /*0x14109c51e*/
          v43 = (unsigned int *)v1->joinRxStats.replicatedFirstBreakdown.Buckets; /*0x14109c521*/
          v44 = &v43[4 * v1->joinRxStats.replicatedFirstBreakdown.NumBuckets]; /*0x14109c533*/
          if ( v1->joinRxStats.replicatedFirstBreakdown.NumEntries != 0 && v43 != v44 ) /*0x14109c547*/
          {
            do /*0x14109c568*/
            {
              if ( ((*(_QWORD *)v43 + 0x2000LL) & 0xFFFFFFFFFFFFEFFFuLL) != 0 ) /*0x14109c55f*/
                break; /*0x14109c55f*/
              v43 += 4; /*0x14109c561*/
            }
            while ( v43 != v44 ); /*0x14109c568*/
            if ( v43 != v44 ) /*0x14109c56d*/
            {
              v45 = (std::_String_constructor_concat_tag)v290; /*0x14109c573*/
              v46 = (std::_String_constructor_concat_tag)v290; /*0x14109c57a*/
              while ( RBX::json::Writer::size(this: &v200) <= DFInt::JoinInstanceTypeBreakdownJsonSizeLimit ) /*0x14109c597*/
              {
                v47 = v43[2]; /*0x14109c59d*/
                v48 = *(const std::string **)(*(_QWORD *)v43 + 8LL); /*0x14109c5a4*/
                v49 = v48->_Mypair._Myval2._Mysize; /*0x14109c5a8*/
                if ( 0x7FFFFFFFFFFFFFFFLL - v49 < 6 ) /*0x14109c5bd*/
                  std::_Xlen_string(); /*0x14109ecce*/
                v50 = *(const char **)(*(_QWORD *)v43 + 8LL); /*0x14109c5c3*/
                if ( v48->_Mypair._Myval2._Myres >= 0x10 ) /*0x14109c5cb*/
                  v50 = v48->_Mypair._Myval2._Bx._Ptr; /*0x14109c5cd*/
                std::string::string( /*0x14109c5f1*/
                  this: (std::string *)&instancesWriter.writer,
                  __formal: v45,
                  _Source_of_al: v48,
                  _Left_ptr: v50,
                  _Left_size: v49,
                  _Right_ptr: "_count",
                  _Right_size: 6u);
                __eh34_enter_wind_state(5, 6); /*0xf1c0000000000458*/
                RBX::json::Writer::int64Key(this: &v200, key: (const std::string *)&instancesWriter.writer, value: v47); /*0x14109c605*/
                if ( __eh34_unwind(6) ) /*0xf1c000000000044c*/
                {
unwind_state_6:
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&instancesWriter.writer); /*0xf1c0000000000434*/
                  __eh34_continue_unwinding(6, 5); /*0xf1c0000000000438*/
                }
                __eh34_exit_wind_state(6, 5); /*0xf1c0000000000450*/
                if ( *(_QWORD *)v198.address.addr4.sin_zero >= 0x10u ) /*0x14109c613*/
                {
                  v51 = instancesWriter.writer; /*0x14109c618*/
                  if ( (unsigned __int64)(*(_QWORD *)v198.address.addr4.sin_zero + 1LL) >= 0x1000 ) /*0x14109c626*/
                  {
                    v51 = *(RBX::json::RbxWriter **)&instancesWriter.writer[-1].writeFlags; /*0x14109c62c*/
                    if ( (unsigned __int64)((char *)instancesWriter.writer - (char *)v51 - 8) > 0x1F ) /*0x14109c63b*/
                      _invalid_parameter_noinfo_noreturn(); /*0x14109c724*/
                  }
                  operator delete(ptr: v51); /*0x14109c641*/
                }
                v52 = v43[3]; /*0x14109c646*/
                v53 = *(const std::string **)(*(_QWORD *)v43 + 8LL); /*0x14109c64d*/
                v54 = v53->_Mypair._Myval2._Mysize; /*0x14109c651*/
                if ( 0x7FFFFFFFFFFFFFFFLL - v54 < 6 ) /*0x14109c666*/
                  std::_Xlen_string(); /*0x14109ece0*/
                v55 = *(const char **)(*(_QWORD *)v43 + 8LL); /*0x14109c66c*/
                if ( v53->_Mypair._Myval2._Myres >= 0x10 ) /*0x14109c674*/
                  v55 = v53->_Mypair._Myval2._Bx._Ptr; /*0x14109c676*/
                std::string::string( /*0x14109c69b*/
                  this: (std::string *)&instancesWriter.writer,
                  __formal: v46,
                  _Source_of_al: v53,
                  _Left_ptr: v55,
                  _Left_size: v54,
                  _Right_ptr: "_bytes",
                  _Right_size: 6u);
                __eh34_enter_wind_state(5, 6); /*0xf1c0000000000444*/
                RBX::json::Writer::int64Key(this: &v200, key: (const std::string *)&instancesWriter.writer, value: v52); /*0x14109c6af*/
                if ( __eh34_unwind(6) ) /*0xf1c0000000000430*/
                  goto unwind_state_6; /*0xf1c0000000000430*/
                __eh34_exit_wind_state(6, 5); /*0xf1c000000000043c*/
                if ( *(_QWORD *)v198.address.addr4.sin_zero >= 0x10u ) /*0x14109c6bd*/
                {
                  v56 = instancesWriter.writer; /*0x14109c6c2*/
                  if ( (unsigned __int64)(*(_QWORD *)v198.address.addr4.sin_zero + 1LL) >= 0x1000 ) /*0x14109c6d0*/
                  {
                    v56 = *(RBX::json::RbxWriter **)&instancesWriter.writer[-1].writeFlags; /*0x14109c6d6*/
                    if ( (unsigned __int64)((char *)instancesWriter.writer - (char *)v56 - 8) > 0x1F ) /*0x14109c6e5*/
                      _invalid_parameter_noinfo_noreturn(); /*0x14109c72b*/
                  }
                  operator delete(ptr: v56); /*0x14109c6e7*/
                }
                v43 += 4; /*0x14109c6ec*/
                if ( v43 != v44 ) /*0x14109c6f3*/
                {
                  do /*0x14109c718*/
                  {
                    if ( ((*(_QWORD *)v43 + 0x2000LL) & 0xFFFFFFFFFFFFEFFFuLL) != 0 ) /*0x14109c70f*/
                      break; /*0x14109c70f*/
                    v43 += 4; /*0x14109c711*/
                  }
                  while ( v43 != v44 ); /*0x14109c718*/
                  if ( v43 != v44 ) /*0x14109c71d*/
                    continue; /*0x14109c71d*/
                }
                goto LABEL_95; /*0x14109c71d*/
              }
              v42 = true; /*0x14109c732*/
            }
          }
LABEL_95:
          RBX::json::Writer::endObject(this: &v200); /*0x14109c735*/
          if ( DFLog::JoinInstanceTypeBreakdown != 0 )
          {
            v57 = RBX::json::Writer::str(this: &v200, result: &v241); /*0x14109c758*/
            __wind
            {
              if ( v57->_Mypair._Myval2._Myres >= 0x10 ) /*0x14109c763*/
                v57 = (std::string *)v57->_Mypair._Myval2._Bx._Ptr; /*0x14109c765*/
              FLog::FastLogFormatted(
                level: DFLog::JoinInstanceTypeBreakdown,
                message: "[DFLog::JoinInstanceTypeBreakdown] Replicated First Breakdown: %s",
                v57->_Mypair._Myval2._Bx._Buf);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v241); /*0xf1c000000000041c*/
            }
            if ( v241._Mypair._Myval2._Myres >= 0x10 ) /*0x14109c78a*/
            {
              v58 = v241._Mypair._Myval2._Bx._Ptr; /*0x14109c78f*/
              if ( v241._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109c7a0*/
              {
                v58 = *((char **)v241._Mypair._Myval2._Bx._Ptr - 1); /*0x14109c7a6*/
                if ( (unsigned __int64)(v241._Mypair._Myval2._Bx._Ptr - v58 - 8) > 0x1F ) /*0x14109c7b5*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14109c7b7*/
              }
              operator delete(ptr: v58); /*0x14109c7be*/
            }
          }
          v59 = RBX::json::Writer::str(this: &v200, result: &v242); /*0x14109c7d1*/
          __wind /*0xf1c000000000040c*/
          {
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c7e5*/
              this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
              name: "replicatedFirstInstanceTypeBreakdown",
              value: v59);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v242); /*0xf1c0000000000404*/
          }
          if ( v242._Mypair._Myval2._Myres >= 0x10 ) /*0x14109c7f6*/
          {
            v60 = v242._Mypair._Myval2._Bx._Ptr; /*0x14109c7fb*/
            if ( v242._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109c80c*/
            {
              v60 = *((char **)v242._Mypair._Myval2._Bx._Ptr - 1); /*0x14109c812*/
              if ( (unsigned __int64)(v242._Mypair._Myval2._Bx._Ptr - v60 - 8) > 0x1F ) /*0x14109c821*/
                _invalid_parameter_noinfo_noreturn(); /*0x14109c823*/
            }
            operator delete(ptr: v60); /*0x14109c82a*/
          }
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c83e*/
            this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
            name: "replicatedFirstBreakdownTruncated",
            value: v42);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c855*/
            this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
            name: "jdiv2TotalInstanceBytesRxInJoin",
            value: v1->joinRxStats.totalInstanceBytesRxInJoin);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c86c*/
            this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
            name: "totalInstanceBytesRxInReplicatedFirst",
            value: v1->joinRxStats.totalInstanceBytesRxInReplicatedFirst);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c883*/
            this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
            name: "totalInstancesInReplicatedFirst",
            value: v1->joinRxStats.totalInstancesInReplicatedFirst);
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109c89a*/
            this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
            name: "terrainCompressedBytes",
            value: v1->joinRxStats.totalCompressedTerrainBytes);
        }
        __unwind
        {
          RBX::json::Writer::~Writer(this: &v200); /*0xf1c00000000003f8*/
        }
        RBX::json::Writer::~Writer(this: &v200); /*0x14109c8a7*/
        RBX::json::Writer::~Writer(this: (RBX::json::Writer *)&joinWriter.writer); /*0x14109c8b4*/
      }
      __unwind
      {
        RBX::json::Writer::~Writer(this: (RBX::json::Writer *)&joinWriter.writer); /*0xf1c00000000003ec*/
      }
    }
    if ( DFFlag::ReportTopReplicationContainerAndAvatarStats.value /*0x14109c8cc*/
      && RBX::Analytics::InfluxDb::canSend(throttleHundredthsPercentage: DFInt::ReportTopReplicationContainerAndAvatarStatsHundredths) )
    {
      RBX::Analytics::InfluxDb::Points::Points( /*0x14109c8ea*/
        this: &v244,
        throttleHundredthsPercentage: -1,
        categoryType: kStandardType,
        priorityHundredthsPercentage: 0);
      __wind /*0xf1c00000000003dc*/
      {
        v70 = 0; /*0x14109c8f0*/
        v194 = 0; /*0x14109c8f3*/
        v69 = 0; /*0x14109c8f7*/
        LOBYTE(avgJdiV2ProcessedPerFrame) = 0; /*0x14109c8fa*/
        RBX::json::Writer::Writer(this: (RBX::json::Writer *)&topReplicationContainerWriter.writer, type: BasicWriter); /*0x14109c90a*/
        __wind /*0xf1c00000000003d0*/
        {
          RBX::json::Writer::startArray(this: (RBX::json::Writer *)&topReplicationContainerWriter.writer); /*0x14109c917*/
          Myhead = v1->joinRxStats.topReplicationContainerBreakdown._List._Mypair._Myval2._Myhead; /*0x14109c91c*/
          Next = Myhead->_Next; /*0x14109c923*/
          if ( Myhead->_Next != Myhead ) /*0x14109c92a*/
          {
            do /*0x14109cade*/
            {
              if ( v69 != 0 ) /*0x14109c93a*/
                break; /*0x14109c93a*/
              RBX::json::Writer::startObject(this: (RBX::json::Writer *)&topReplicationContainerWriter.writer); /*0x14109c947*/
              v63 = Next->_Myval.first._Mypair._Myval2._Mysize; /*0x14109c94c*/
              p_Ptr = &Next->_Myval.first._Mypair._Myval2._Bx._Ptr; /*0x14109c950*/
              if ( Next->_Myval.first._Mypair._Myval2._Myres >= 0x10 ) /*0x14109c959*/
                p_Ptr = Next->_Myval.first._Mypair._Myval2._Bx._Ptr; /*0x14109c95b*/
              *(_QWORD *)&v213.width = p_Ptr; /*0x14109c95f*/
              *(_QWORD *)&v213.color = v63; /*0x14109c966*/
              *(_QWORD *)&v214 = "container"; /*0x14109c96d*/
              *((_QWORD *)&v214 + 1) = 9; /*0x14109c974*/
              *(_OWORD *)&joinWriter.writer = *(_OWORD *)&v213.width; /*0x14109c986*/
              *(_OWORD *)&v200.buffer = v214; /*0x14109c995*/
              RBX::json::Writer::stringKey( /*0x14109c9b2*/
                this: (RBX::json::Writer *)&topReplicationContainerWriter.writer,
                key: (RBX::StringView *)&v200,
                value: (RBX::StringView *)&joinWriter.writer);
              v65 = 0; /*0x14109c9b7*/
              RBX::json::Writer::Writer(this: (RBX::json::Writer *)&instancesWriter.writer, type: BasicWriter); /*0x14109c9c0*/
              __wind /*0xf1c00000000003c4*/
              {
                RBX::json::Writer::startObject(this: (RBX::json::Writer *)&instancesWriter.writer); /*0x14109c9ca*/
                v66 = (unsigned int *)Next->_Myval.second.Buckets; /*0x14109c9cf*/
                v67 = &v66[4 * Next->_Myval.second.NumBuckets]; /*0x14109c9db*/
                if ( Next->_Myval.second.NumEntries == 0 || v66 == v67 ) /*0x14109c9eb*/
                  goto LABEL_131; /*0x14109c9eb*/
                do /*0x14109ca09*/
                {
                  if ( ((*(_QWORD *)v66 + 0x2000LL) & 0xFFFFFFFFFFFFEFFFuLL) != 0 ) /*0x14109ca00*/
                    break; /*0x14109ca00*/
                  v66 += 4; /*0x14109ca02*/
                }
                while ( v66 != v67 ); /*0x14109ca09*/
                if ( v66 == v67 ) /*0x14109ca0e*/
                {
LABEL_131:
                  v69 = LOBYTE(avgJdiV2ProcessedPerFrame); /*0x14109ca7f*/
                }
                else
                {
                  while ( 1 ) /*0x14109ca19*/
                  {
                    v68 = RBX::json::Writer::size(this: (RBX::json::Writer *)&instancesWriter.writer); /*0x14109ca19*/
                    if ( v68 + RBX::json::Writer::size(this: (RBX::json::Writer *)&topReplicationContainerWriter.writer) > DFInt::TopReplicationContainerAndAvatarBreakdownJsonSizeLimit ) /*0x14109ca36*/
                      break; /*0x14109ca36*/
                    RBX::json::Writer::int64Key( /*0x14109ca4b*/
                      this: (RBX::json::Writer *)&instancesWriter.writer,
                      key: *(const std::string **)(*(_QWORD *)v66 + 8LL),
                      value: v66[2]);
                    v65 += v66[2]; /*0x14109ca50*/
                    v66 += 4; /*0x14109ca54*/
                    if ( v66 != v67 ) /*0x14109ca5b*/
                    {
                      do /*0x14109ca78*/
                      {
                        if ( ((*(_QWORD *)v66 + 0x2000LL) & 0xFFFFFFFFFFFFEFFFuLL) != 0 ) /*0x14109ca6f*/
                          break; /*0x14109ca6f*/
                        v66 += 4; /*0x14109ca71*/
                      }
                      while ( v66 != v67 ); /*0x14109ca78*/
                      if ( v66 != v67 ) /*0x14109ca7d*/
                        continue; /*0x14109ca7d*/
                    }
                    goto LABEL_131; /*0x14109ca7d*/
                  }
                  v69 = 1; /*0x14109cbd1*/
                  LOBYTE(avgJdiV2ProcessedPerFrame) = 1; /*0x14109cbd4*/
                }
                RBX::json::Writer::endObject(this: (RBX::json::Writer *)&instancesWriter.writer); /*0x14109ca8a*/
                RBX::json::Writer::int64Key( /*0x14109caa0*/
                  this: (RBX::json::Writer *)&topReplicationContainerWriter.writer,
                  key: "numInstances",
                  value: v65);
                RBX::json::Writer::writerKey( /*0x14109cab7*/
                  this: (RBX::json::Writer *)&topReplicationContainerWriter.writer,
                  key: "instances",
                  otherWriter: (const RBX::json::Writer *)&instancesWriter.writer);
                RBX::json::Writer::endObject(this: (RBX::json::Writer *)&topReplicationContainerWriter.writer); /*0x14109cac3*/
                v194 += v65; /*0x14109cac8*/
              }
              __unwind
              {
                RBX::json::Writer::~Writer(this: (RBX::json::Writer *)&instancesWriter.writer); /*0xf1c00000000003bc*/
              }
              RBX::json::Writer::~Writer(this: (RBX::json::Writer *)&instancesWriter.writer); /*0x14109cad0*/
              Next = Next->_Next; /*0x14109cad8*/
            }
            while ( Next != Myhead ); /*0x14109cade*/
            v1 = v290; /*0x14109cae4*/
            v70 = v194; /*0x14109caeb*/
          }
          RBX::json::Writer::endArray(this: (RBX::json::Writer *)&topReplicationContainerWriter.writer); /*0x14109caf6*/
          RBX::json::Writer::Writer(this: (RBX::json::Writer *)&resource.x, type: BasicWriter); /*0x14109cb04*/
          __wind /*0xf1c0000000000388*/
          {
            RBX::json::Writer::startObject(this: (RBX::json::Writer *)&resource.x); /*0x14109cb11*/
            v71 = 0; /*0x14109cb16*/
            v72 = false; /*0x14109cb18*/
            v73 = (unsigned int *)v1->joinRxStats.avatarInstancesBreakdown.Buckets; /*0x14109cb1b*/
            v74 = &v73[4 * v1->joinRxStats.avatarInstancesBreakdown.NumBuckets]; /*0x14109cb2d*/
            if ( v1->joinRxStats.avatarInstancesBreakdown.NumEntries != 0 && v73 != v74 ) /*0x14109cb40*/
            {
              do /*0x14109cb68*/
              {
                if ( ((*(_QWORD *)v73 + 0x2000LL) & 0xFFFFFFFFFFFFEFFFuLL) != 0 ) /*0x14109cb5f*/
                  break; /*0x14109cb5f*/
                v73 += 4; /*0x14109cb61*/
              }
              while ( v73 != v74 ); /*0x14109cb68*/
              if ( v73 != v74 ) /*0x14109cb6d*/
              {
                while ( RBX::json::Writer::size(this: (RBX::json::Writer *)&resource.x) <= DFInt::TopReplicationContainerAndAvatarBreakdownJsonSizeLimit ) /*0x14109cb86*/
                {
                  RBX::json::Writer::int64Key( /*0x14109cb9a*/
                    this: (RBX::json::Writer *)&resource.x,
                    key: *(const std::string **)(*(_QWORD *)v73 + 8LL),
                    value: v73[2]);
                  v71 += v73[2]; /*0x14109cb9f*/
                  v73 += 4; /*0x14109cba2*/
                  if ( v73 != v74 ) /*0x14109cba9*/
                  {
                    do /*0x14109cbc8*/
                    {
                      if ( ((*(_QWORD *)v73 + 0x2000LL) & 0xFFFFFFFFFFFFEFFFuLL) != 0 ) /*0x14109cbbf*/
                        break; /*0x14109cbbf*/
                      v73 += 4; /*0x14109cbc1*/
                    }
                    while ( v73 != v74 ); /*0x14109cbc8*/
                    if ( v73 != v74 ) /*0x14109cbcd*/
                      continue; /*0x14109cbcd*/
                  }
                  goto LABEL_149; /*0x14109cbcd*/
                }
                v72 = true; /*0x14109cbe0*/
              }
            }
LABEL_149:
            RBX::json::Writer::endObject(this: (RBX::json::Writer *)&resource.x); /*0x14109cbe3*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109cc00*/
              this: &v244,
              name: "totalTopReplicationContainerInstances",
              value: v70);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109cc1b*/
              this: &v244,
              name: "topReplicationContainerInstancesJsonTruncated",
              value: SLOBYTE(avgJdiV2ProcessedPerFrame));
            RBX::Analytics::InfluxDb::Points::addPoint(this: &v244, name: "totalAvatarInstances", value: v71); /*0x14109cc31*/
            RBX::Analytics::InfluxDb::Points::addPoint(this: &v244, name: "avatarInstancesJsonTruncated", value: v72); /*0x14109cc48*/
            v75 = RBX::json::Writer::str(this: (RBX::json::Writer *)&resource.x, result: &v243); /*0x14109cc5b*/
            __wind /*0xf1c000000000037c*/
            {
              RBX::Analytics::InfluxDb::Points::addPoint(this: &v244, name: "avatarInstances", value: v75); /*0x14109cc72*/
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v243); /*0xf1c0000000000374*/
            }
            if ( v243._Mypair._Myval2._Myres >= 0x10 ) /*0x14109cc83*/
            {
              v76 = v243._Mypair._Myval2._Bx._Ptr; /*0x14109cc88*/
              if ( v243._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109cc99*/
              {
                v76 = *((char **)v243._Mypair._Myval2._Bx._Ptr - 1); /*0x14109cc9f*/
                if ( (unsigned __int64)(v243._Mypair._Myval2._Bx._Ptr - v76 - 8) > 0x1F ) /*0x14109ccae*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14109ccb0*/
              }
              operator delete(ptr: v76); /*0x14109ccb7*/
            }
            v77 = RBX::json::Writer::str( /*0x14109ccca*/
                    this: (RBX::json::Writer *)&topReplicationContainerWriter.writer,
                    result: &v235);
            __wind /*0xf1c0000000000364*/
            {
              RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109cce1*/
                this: &v244,
                name: "topReplicationContainerInstances",
                value: v77);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v235); /*0xf1c000000000035c*/
            }
            if ( v235._Mypair._Myval2._Myres >= 0x10 ) /*0x14109ccf2*/
            {
              v78 = v235._Mypair._Myval2._Bx._Ptr; /*0x14109ccf7*/
              if ( v235._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109cd08*/
              {
                v78 = *((char **)v235._Mypair._Myval2._Bx._Ptr - 1); /*0x14109cd0e*/
                if ( (unsigned __int64)(v235._Mypair._Myval2._Bx._Ptr - v78 - 8) > 0x1F ) /*0x14109cd1d*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14109cd1f*/
              }
              operator delete(ptr: v78); /*0x14109cd26*/
            }
            v79 = DFInt::ReportTopReplicationContainerAndAvatarStatsHundredths; /*0x14109cd2b*/
            resource.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109cd31*/
            resource.text._Mypair._Myval2._Mysize = 0; /*0x14109cd3c*/
            resource.text._Mypair._Myval2._Myres = 15; /*0x14109cd47*/
            v80 = operator new(size: 0x30u); /*0x14109cd5e*/
            resource.text._Mypair._Myval2._Mysize = 37; /*0x14109cd63*/
            resource.text._Mypair._Myval2._Myres = 47; /*0x14109cd6e*/
            qmemcpy(v80, "TopReplicationContainerAndAvatarStat", 36); /*0x14109cd80*/
            v80[18] = (unsigned __int8)aTopreplication_2[36]; /*0x14109cd9e*/
            resource.text._Mypair._Myval2._Bx._Ptr = (char *)v80; /*0x14109cda5*/
            __wind /*0xf1c000000000034c*/
            {
              RBX::Analytics::InfluxDb::Points::report( /*0x14109cdc0*/
                this: &v244,
                resource: &resource.text,
                throttleHundredthsPercentage: v79,
                blocking: false);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: &resource); /*0xf1c0000000000344*/
            }
            if ( resource.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14109cdd1*/
            {
              v81 = resource.text._Mypair._Myval2._Bx._Ptr; /*0x14109cdd6*/
              if ( resource.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109cde7*/
              {
                v81 = *((char **)resource.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14109cded*/
                if ( (unsigned __int64)(resource.text._Mypair._Myval2._Bx._Ptr - v81 - 8) > 0x1F ) /*0x14109cdfc*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14109cdfe*/
              }
              operator delete(ptr: v81); /*0x14109ce05*/
            }
            RBX::json::Writer::~Writer(this: (RBX::json::Writer *)&resource.x); /*0x14109ce12*/
            RBX::json::Writer::~Writer(this: (RBX::json::Writer *)&topReplicationContainerWriter.writer); /*0x14109ce1f*/
            RBX::Analytics::InfluxDb::Points::~Points(this: &v244); /*0x14109ce2c*/
          }
          __unwind
          {
            RBX::json::Writer::~Writer(this: (RBX::json::Writer *)&resource.x); /*0xf1c0000000000398*/
          }
        }
        __unwind
        {
          RBX::json::Writer::~Writer(this: (RBX::json::Writer *)&topReplicationContainerWriter.writer); /*0xf1c00000000003a4*/
        }
      }
      __unwind
      {
        RBX::Analytics::InfluxDb::Points::~Points(this: &v244); /*0xf1c00000000003b0*/
      }
    }
    if ( DFFlag::ReportSharedStringBreakdown.value ) /*0x14109ce38*/
    {
      RBX::json::Writer::Writer(this: (RBX::json::Writer *)&sharedStringWriter.writer, type: BasicWriter); /*0x14109ce47*/
      __wind /*0xf1c0000000000334*/
      {
        RBX::json::Writer::startObject(this: (RBX::json::Writer *)&sharedStringWriter.writer); /*0x14109ce54*/
        v82 = (unsigned int *)v1->joinRxStats.sharedStringBreakdown.Buckets; /*0x14109ce59*/
        v83 = &v82[4 * v1->joinRxStats.sharedStringBreakdown.NumBuckets]; /*0x14109ce6b*/
        if ( v1->joinRxStats.sharedStringBreakdown.NumEntries != 0 && v82 != v83 ) /*0x14109ce7b*/
        {
          do /*0x14109ce98*/
          {
            if ( ((*(_QWORD *)v82 + 0x2000LL) & 0xFFFFFFFFFFFFEFFFuLL) != 0 ) /*0x14109ce8f*/
              break; /*0x14109ce8f*/
            v82 += 4; /*0x14109ce91*/
          }
          while ( v82 != v83 ); /*0x14109ce98*/
          while ( v82 != v83 ) /*0x14109ce9d*/
          {
            RBX::json::Writer::int64Key( /*0x14109ceb2*/
              this: (RBX::json::Writer *)&sharedStringWriter.writer,
              key: *(const std::string **)(*(_QWORD *)v82 + 8LL),
              value: v82[2]);
            v82 += 4; /*0x14109ceb7*/
            if ( v82 == v83 ) /*0x14109cebe*/
              break; /*0x14109cebe*/
            do /*0x14109ced8*/
            {
              if ( ((*(_QWORD *)v82 + 0x2000LL) & 0xFFFFFFFFFFFFEFFFuLL) != 0 ) /*0x14109cecf*/
                break; /*0x14109cecf*/
              v82 += 4; /*0x14109ced1*/
            }
            while ( v82 != v83 ); /*0x14109ced8*/
          }
        }
        RBX::json::Writer::endObject(this: (RBX::json::Writer *)&sharedStringWriter.writer); /*0x14109cee6*/
        v84 = RBX::json::Writer::str(this: (RBX::json::Writer *)&sharedStringWriter.writer, result: &v236); /*0x14109cef9*/
        __wind /*0xf1c0000000000328*/
        {
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109cf0d*/
            this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
            name: "sharedStringBreakdown",
            value: v84);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v236); /*0xf1c0000000000320*/
        }
        if ( v236._Mypair._Myval2._Myres >= 0x10 ) /*0x14109cf1e*/
        {
          v85 = v236._Mypair._Myval2._Bx._Ptr; /*0x14109cf23*/
          if ( v236._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109cf34*/
          {
            v85 = *((char **)v236._Mypair._Myval2._Bx._Ptr - 1); /*0x14109cf3a*/
            if ( (unsigned __int64)(v236._Mypair._Myval2._Bx._Ptr - v85 - 8) > 0x1F ) /*0x14109cf49*/
              _invalid_parameter_noinfo_noreturn(); /*0x14109cf4b*/
          }
          operator delete(ptr: v85); /*0x14109cf52*/
        }
        RBX::json::Writer::~Writer(this: (RBX::json::Writer *)&sharedStringWriter.writer); /*0x14109cf5f*/
      }
      __unwind
      {
        RBX::json::Writer::~Writer(this: (RBX::json::Writer *)&sharedStringWriter.writer); /*0xf1c0000000000314*/
      }
    }
    v86 = 1; /*0x14109cf69*/
    v87 = RBX::TaskScheduler::cycle() + 1 - v1->cycleAtNewConnectionAccepted; /*0x14109cf79*/
    LODWORD(v290) = v87; /*0x14109cf7b*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109cf8f*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "numFramesBetweenConnectionAcceptedAndGameLoadTime",
      value: v87);
    connectionAcceptedToGameLoadTimeMs = v1->joinRxStats.connectionAcceptedToGameLoadTimeMs; /*0x14109cf94*/
    if ( connectionAcceptedToGameLoadTimeMs <= 0.0 ) /*0x14109cfa2*/
      v89 = -1.0; /*0x14109cfbe*/
    else
      v89 = (double)v87 / (connectionAcceptedToGameLoadTimeMs / 1000.0); /*0x14109cfb7*/
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109cfd6*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "averageFpsDuringJoin",
      value: v89);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109cfed*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalJdiv2CountRecvDuringJoin",
      value: v1->joinRxStats.totalJdiv2ItemsRxDuringJoin);
    RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d004*/
      this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
      name: "totalJdiv2BytesRecvDuringJoin",
      value: v1->joinRxStats.totalJdiv2BytesRxDuringJoin);
    *(_OWORD *)&gameLoadStats._Mypair._Myval2._Mylast = 0; /*0x14109d00c*/
    v189 = nullptr; /*0x14109d012*/
    __wind
    {
      v90 = v1->firstDataPacketArriveTimeAfterJoinRequestInMS; /*0x14109d01b*/
      v91 = v1->joinRxStats.timeLastJdiv2SharedStringArrival - v90; /*0x14109d029*/
      v92 = v1->joinRxStats.timeLastJdiv2SharedStringDeserialize - v90; /*0x14109d032*/
      v93 = v1->joinRxStats.gameLoadedTagInfo.appArrivalTime - v90; /*0x14109d03b*/
      v94 = v1->joinRxStats.gameLoadedTagInfo.deserializationTime - v90; /*0x14109d044*/
      v95 = v1->joinRxStats.gameLoadedTagInfo.beginProcessingTime - v90; /*0x14109d04e*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d05f*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressTimeMs.lastSharedStringArrival",
        value: v91);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d072*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressTimeMs.sharedStringDeserializeComplete",
        value: v92);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d085*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressTimeMs.gameLoadTagArrival",
        value: v93);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d098*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressTimeMs.gameLoadTagDeserialized",
        value: v94);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d0ab*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressTimeMs.gameLoadTagProcessed",
        value: v95);
      v96 = (double)(int)v91 * 100.0 / (double)v95; /*0x14109d0d3*/
      v97 = (double)v92 * 100.0 / (double)v95; /*0x14109d0e7*/
      v98 = (double)v93; /*0x14109d0f2*/
      v99 = (double)v93 * 100.0 / (double)v95; /*0x14109d100*/
      v100 = (double)v94 * 100.0 / (double)v95; /*0x14109d115*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d128*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressTimePercent.lastSharedStringArrival",
        value: v96);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d13c*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressTimePercent.sharedStringDeserializeComplete",
        value: v97);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d14f*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressTimePercent.gameLoadTagArrival",
        value: v99);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d163*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressTimePercent.gameLoadTagDeserialize",
        value: v100);
      v209._Ptr = nullptr; /*0x14109d168*/
      si128 = _mm_load_si128((const __m128i *)&_xmm); /*0x14109d17b*/
      std::string::assign( /*0x14109d19e*/
        this: (std::string *)&v209,
        _Ptr: "ReplicatorGameLoadPercentTimeWhenJoinDataCompleteTransfer",
        _Count: 0x39u);
      *(double *)&sharedStringWriter.buffer = v99; /*0x14109d1a3*/
      __wind /*0xf1c00000000002f8*/
      {
        Myend = gameLoadStats._Mypair._Myval2._Myend; /*0x14109d1ab*/
        if ( gameLoadStats._Mypair._Myval2._Myend == v189 ) /*0x14109d1b5*/
        {
          std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x14109d1f8*/
            this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
            _Whereptr: gameLoadStats._Mypair._Myval2._Myend,
            <_Val_0>: (std::pair<std::string,double> *)&v209);
          v102 = si128.m128i_u64[1]; /*0x14109d1fd*/
        }
        else
        {
          *(_QWORD *)gameLoadStats._Mypair._Myval2._Myend = 0; /*0x14109d1b7*/
          Myend->first._Mypair._Myval2._Bx = v209; /*0x14109d1c5*/
          *(__m128i *)&Myend->first._Mypair._Myval2._Mysize = si128; /*0x14109d1cf*/
          v102 = 15; /*0x14109d1d3*/
          v209._Buf[0] = 0; /*0x14109d1d8*/
          Myend->second = v99; /*0x14109d1df*/
          ++gameLoadStats._Mypair._Myval2._Myend; /*0x14109d1e4*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v209); /*0xf1c00000000002f0*/
      }
      if ( v102 >= 0x10 ) /*0x14109d208*/
      {
        v103 = v209._Ptr; /*0x14109d20e*/
        if ( v102 + 1 >= 0x1000 ) /*0x14109d21f*/
        {
          v103 = *((char **)v209._Ptr - 1); /*0x14109d225*/
          if ( (unsigned __int64)(v209._Ptr - v103 - 8) > 0x1F ) /*0x14109d234*/
            goto LABEL_240; /*0x14109d234*/
        }
        operator delete(ptr: v103); /*0x14109d23a*/
      }
      if ( DFLog::JoinDataRxStats != 0 ) /*0x14109d248*/
      {
        LODWORD(_Right_size) = v93; /*0x14109d261*/
        LODWORD(_Left_size) = v92; /*0x14109d26c*/
        FLog::FastLogFormatted( /*0x14109d284*/
          level: DFLog::JoinDataRxStats,
          message: "[DFLog::JoinDataRxStats] GameLoadProgressTime,lastSSArrive,%u,%f%%,SSDeserialized,%u,%f%%,gameLoadTagArrival,%"
          "u,%f%%,gameLoadTagDeserialize,%u,%f%%,gameLoadTagProcess,%u",
          v91,
          v96,
          _Left_size,
          v97,
          _Right_size,
          v99,
          v94,
          v100,
          v95);
      }
      firstDataPacketArriveCycle = v1->firstDataPacketArriveCycle; /*0x14109d289*/
      v105 = v1->joinRxStats.gameLoadedTagInfo.beginProcessingCycle - firstDataPacketArriveCycle; /*0x14109d297*/
      v106 = v1->joinRxStats.cycleLastJdiv2SharedStringArrival - firstDataPacketArriveCycle; /*0x14109d2a0*/
      v107 = v1->joinRxStats.cycleLastJdiv2SharedStringDeserialize - firstDataPacketArriveCycle; /*0x14109d2a9*/
      v108 = v1->joinRxStats.gameLoadedTagInfo.appArrivalCycle - firstDataPacketArriveCycle; /*0x14109d2b2*/
      v109 = v1->joinRxStats.gameLoadedTagInfo.deserializationCycle - firstDataPacketArriveCycle; /*0x14109d2bc*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d2cd*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressCycle.lastSharedStringArrival",
        value: v106);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d2e0*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressCycle.lastSharedStringDeserialized",
        value: v107);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d2f3*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressCycle.gameLoadTagArrival",
        value: v108);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d306*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressCycle.gameLoadTagDeserialized",
        value: v109);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d319*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressCycle.gameLoadTagProcessed",
        value: v105);
      v110 = (double)(int)v106 * 100.0 / (double)v105; /*0x14109d337*/
      v111 = (double)v107 * 100.0 / (double)v105; /*0x14109d34b*/
      v112 = (double)v108 * 100.0 / (double)v105; /*0x14109d360*/
      v113 = (double)v109 * 100.0 / (double)v105; /*0x14109d375*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d388*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressCyclePercent.lastSharedStringArrival",
        value: v110);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d39c*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressCyclePercent.lastSharedStringDeserialized",
        value: v111);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d3af*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressCyclePercent.gameLoadTagArrival",
        value: v112);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d3c3*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameLoadProgressCyclePercent.gameLoadTagDeserialized",
        value: v113);
      if ( DFLog::JoinDataRxStats != 0 ) /*0x14109d3d1*/
      {
        LODWORD(v187) = v105; /*0x14109d3d3*/
        LODWORD(v186) = v109; /*0x14109d3de*/
        LODWORD(_Right_size) = v108; /*0x14109d3e9*/
        LODWORD(_Left_size) = v107; /*0x14109d3f5*/
        FLog::FastLogFormatted( /*0x14109d40d*/
          level: DFLog::JoinDataRxStats,
          message: "[DFLog::JoinDataRxStats] GameLoadProgressCycle,lastSSArrive,%lu,%f%%,SSDeserialized,%lu,%f%%,gameLoadTagArriva"
          "l,%lu,%f%%,gameLoadTagDeserialize,%lu,%f%%,gameLoadTagProcess,%lu",
          v106,
          v110,
          _Left_size,
          v111,
          _Right_size,
          v112,
          v186,
          v113,
          v187);
      }
      v207.first._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109d415*/
      *(__m128i *)&v207.first._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14109d424*/
      std::string::assign( /*0x14109d446*/
        this: &v207.first,
        _Ptr: "ReplicatorGameLoadPercentCycleWhenJoinDataCompleteTransfer",
        _Count: 0x3Au);
      v207.second = (double)v108 * 100.0 / (double)v105; /*0x14109d44b*/
      __wind /*0xf1c00000000002e0*/
      {
        v114 = gameLoadStats._Mypair._Myval2._Myend; /*0x14109d453*/
        if ( gameLoadStats._Mypair._Myval2._Myend == v189 ) /*0x14109d45d*/
        {
          std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x14109d49b*/
            this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
            _Whereptr: gameLoadStats._Mypair._Myval2._Myend,
            <_Val_0>: &v207);
          Myres = v207.first._Mypair._Myval2._Myres; /*0x14109d4a0*/
          v115 = 15; /*0x14109d4a7*/
        }
        else
        {
          gameLoadStats._Mypair._Myval2._Myend->first._Mypair._Myval2._Bx = v207.first._Mypair._Myval2._Bx; /*0x14109d466*/
          *(_OWORD *)&v114->first._Mypair._Myval2._Mysize = *(_OWORD *)&v207.first._Mypair._Myval2._Mysize; /*0x14109d470*/
          v115 = 15; /*0x14109d474*/
          Myres = 15; /*0x14109d479*/
          v207.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109d47b*/
          v114->second = v112; /*0x14109d482*/
          ++gameLoadStats._Mypair._Myval2._Myend; /*0x14109d487*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v207); /*0xf1c00000000002d8*/
      }
      if ( Myres >= 0x10 ) /*0x14109d4b0*/
      {
        v117 = v207.first._Mypair._Myval2._Bx._Ptr; /*0x14109d4b6*/
        if ( Myres + 1 >= 0x1000 ) /*0x14109d4c7*/
        {
          v117 = *((char **)v207.first._Mypair._Myval2._Bx._Ptr - 1); /*0x14109d4cd*/
          if ( (unsigned __int64)(v207.first._Mypair._Myval2._Bx._Ptr - v117 - 8) > 0x1F ) /*0x14109d4dc*/
            goto LABEL_240; /*0x14109d4dc*/
        }
        operator delete(ptr: v117); /*0x14109d4e2*/
      }
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d4fb*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "totalPacketsDeserializationTimeUpToGameLoadTagMs",
        value: v1->joinRxStats.packetDeserializeUpToGameLoadTagTimeMs);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d512*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "deserializedBytesByGameLoadTag",
        value: v1->joinRxStats.totalBytesDeserializedUpToGameLoadedTag);
      packetDeserializeUpToGameLoadTagTimeMs = v1->joinRxStats.packetDeserializeUpToGameLoadTagTimeMs; /*0x14109d517*/
      v205.first._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109d520*/
      *(__m128i *)&v205.first._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14109d52f*/
      std::string::assign(this: &v205.first, _Ptr: "ReplicatorDeserializeTimeUpToGameLoadTagMs", _Count: 0x2Au); /*0x14109d552*/
      v205.second = packetDeserializeUpToGameLoadTagTimeMs; /*0x14109d557*/
      __wind /*0xf1c00000000002c8*/
      {
        v119 = gameLoadStats._Mypair._Myval2._Myend; /*0x14109d55f*/
        if ( gameLoadStats._Mypair._Myval2._Myend == v189 ) /*0x14109d569*/
        {
          std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x14109d5a3*/
            this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
            _Whereptr: gameLoadStats._Mypair._Myval2._Myend,
            <_Val_0>: &v205);
          v120 = v205.first._Mypair._Myval2._Myres; /*0x14109d5a8*/
        }
        else
        {
          gameLoadStats._Mypair._Myval2._Myend->first._Mypair._Myval2._Bx = v205.first._Mypair._Myval2._Bx; /*0x14109d572*/
          *(_OWORD *)&v119->first._Mypair._Myval2._Mysize = *(_OWORD *)&v205.first._Mypair._Myval2._Mysize; /*0x14109d57c*/
          v120 = 15; /*0x14109d580*/
          v205.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109d583*/
          v119->second = packetDeserializeUpToGameLoadTagTimeMs; /*0x14109d58a*/
          ++gameLoadStats._Mypair._Myval2._Myend; /*0x14109d58f*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v205); /*0xf1c00000000002c0*/
      }
      if ( v120 >= 0x10 ) /*0x14109d5b3*/
      {
        v121 = v205.first._Mypair._Myval2._Bx._Ptr; /*0x14109d5b9*/
        if ( v120 + 1 >= 0x1000 ) /*0x14109d5ca*/
        {
          v121 = *((char **)v205.first._Mypair._Myval2._Bx._Ptr - 1); /*0x14109d5d0*/
          if ( (unsigned __int64)(v205.first._Mypair._Myval2._Bx._Ptr - v121 - 8) > 0x1F ) /*0x14109d5df*/
            goto LABEL_240; /*0x14109d5df*/
        }
        operator delete(ptr: v121); /*0x14109d5e5*/
      }
      totalBytesDeserializedUpToGameLoadedTag = v1->joinRxStats.totalBytesDeserializedUpToGameLoadedTag; /*0x14109d5ea*/
      v208.first._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109d5f1*/
      *(__m128i *)&v208.first._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14109d600*/
      std::string::assign(this: &v208.first, _Ptr: "ReplicatorBytesReceivedUpToGameLoadTag", _Count: 0x26u); /*0x14109d623*/
      v208.second = (double)totalBytesDeserializedUpToGameLoadedTag; /*0x14109d630*/
      __wind /*0xf1c00000000002b0*/
      {
        v123 = gameLoadStats._Mypair._Myval2._Myend; /*0x14109d638*/
        if ( gameLoadStats._Mypair._Myval2._Myend == v189 ) /*0x14109d642*/
        {
          std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x14109d67c*/
            this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
            _Whereptr: gameLoadStats._Mypair._Myval2._Myend,
            <_Val_0>: &v208);
          v124 = v208.first._Mypair._Myval2._Myres; /*0x14109d681*/
        }
        else
        {
          gameLoadStats._Mypair._Myval2._Myend->first._Mypair._Myval2._Bx = v208.first._Mypair._Myval2._Bx; /*0x14109d64b*/
          *(_OWORD *)&v123->first._Mypair._Myval2._Mysize = *(_OWORD *)&v208.first._Mypair._Myval2._Mysize; /*0x14109d655*/
          v124 = 15; /*0x14109d659*/
          v208.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109d65c*/
          v123->second = (double)totalBytesDeserializedUpToGameLoadedTag; /*0x14109d663*/
          ++gameLoadStats._Mypair._Myval2._Myend; /*0x14109d668*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v208); /*0xf1c00000000002a8*/
      }
      if ( v124 >= 0x10 ) /*0x14109d68c*/
      {
        v125 = v208.first._Mypair._Myval2._Bx._Ptr; /*0x14109d692*/
        if ( v124 + 1 >= 0x1000 ) /*0x14109d6a3*/
        {
          v125 = *((char **)v208.first._Mypair._Myval2._Bx._Ptr - 1); /*0x14109d6a9*/
          if ( (unsigned __int64)(v208.first._Mypair._Myval2._Bx._Ptr - v125 - 8) > 0x1F ) /*0x14109d6b8*/
            goto LABEL_240; /*0x14109d6b8*/
        }
        operator delete(ptr: v125); /*0x14109d6be*/
      }
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d6e2*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameJoinIngestSpeed.calculatedNetworkSpeed",
        value: (double)(int)v1->joinRxStats.totalBytesDeserializedUpToGameLoadedTag / v98);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d70a*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameJoinIngestSpeed.deserializeSpeed",
        value: (double)(int)v1->joinRxStats.totalBytesDeserializedUpToGameLoadedTag
      / v1->joinRxStats.packetDeserializeUpToGameLoadTagTimeMs);
      p_packetProcessingCppTimeMs = &v1->joinRxStats.packetProcessingCppTimeMs; /*0x14109d71e*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d734*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameJoinIngestSpeed.processCppSpeed",
        value: (double)(int)v1->joinRxStats.totalBytesDeserializedUpToGameLoadedTag / v1->joinRxStats.packetProcessingCppTimeMs);
      p_packetProcessingScriptContextTimeMs = &v1->joinRxStats.packetProcessingScriptContextTimeMs; /*0x14109d74c*/
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109d766*/
        this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
        name: "gameJoinIngestSpeed.processCppAndScriptSpeed",
        value: (double)(int)v1->joinRxStats.totalBytesDeserializedUpToGameLoadedTag
      / (v1->joinRxStats.packetProcessingCppTimeMs + v1->joinRxStats.packetProcessingScriptContextTimeMs));
      v128 = (double)(int)v1->joinRxStats.totalBytesDeserializedUpToGameLoadedTag / v98; /*0x14109d77a*/
      v206.first._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14109d77f*/
      *(__m128i *)&v206.first._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14109d78e*/
      std::string::assign(this: &v206.first, _Ptr: "ReplicatorCalculatedNetworkSpeedAtJoin", _Count: 0x26u); /*0x14109d7b1*/
      v206.second = v128; /*0x14109d7b6*/
      __wind /*0xf1c0000000000298*/
      {
        v129 = gameLoadStats._Mypair._Myval2._Myend; /*0x14109d7be*/
        if ( gameLoadStats._Mypair._Myval2._Myend == v189 ) /*0x14109d7c8*/
        {
          std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x14109d802*/
            this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
            _Whereptr: gameLoadStats._Mypair._Myval2._Myend,
            <_Val_0>: &v206);
          v130 = v206.first._Mypair._Myval2._Myres; /*0x14109d807*/
        }
        else
        {
          gameLoadStats._Mypair._Myval2._Myend->first._Mypair._Myval2._Bx = v206.first._Mypair._Myval2._Bx; /*0x14109d7d1*/
          *(_OWORD *)&v129->first._Mypair._Myval2._Mysize = *(_OWORD *)&v206.first._Mypair._Myval2._Mysize; /*0x14109d7db*/
          v130 = 15; /*0x14109d7df*/
          v206.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109d7e2*/
          v129->second = v128; /*0x14109d7e9*/
          ++gameLoadStats._Mypair._Myval2._Myend; /*0x14109d7ee*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v206); /*0xf1c0000000000290*/
      }
      if ( v130 < 0x10 )
      {
LABEL_233:
        v132 = (double)(int)v1->joinRxStats.totalBytesDeserializedUpToGameLoadedTag /*0x14109d849*/
             / v1->joinRxStats.packetDeserializeUpToGameLoadTagTimeMs;
        std::string::string(this: &v212.first, _Ptr: "ReplicatorCalculatedDeserialiationSpeedAtJoin"); /*0x14109d86f*/
        v212.second = v132; /*0x14109d874*/
        __wind /*0xf1c0000000000280*/
        {
          v133 = gameLoadStats._Mypair._Myval2._Myend; /*0x14109d87c*/
          if ( gameLoadStats._Mypair._Myval2._Myend == v189 ) /*0x14109d886*/
          {
            std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x14109d8bd*/
              this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
              _Whereptr: gameLoadStats._Mypair._Myval2._Myend,
              <_Val_0>: &v212);
            v115 = v212.first._Mypair._Myval2._Myres; /*0x14109d8c2*/
          }
          else
          {
            gameLoadStats._Mypair._Myval2._Myend->first._Mypair._Myval2._Bx = v212.first._Mypair._Myval2._Bx; /*0x14109d88f*/
            *(_OWORD *)&v133->first._Mypair._Myval2._Mysize = *(_OWORD *)&v212.first._Mypair._Myval2._Mysize; /*0x14109d899*/
            v212.first._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109d89d*/
            v133->second = v132; /*0x14109d8a4*/
            ++gameLoadStats._Mypair._Myval2._Myend; /*0x14109d8a9*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v212); /*0xf1c0000000000278*/
        }
        if ( v115 >= 0x10 ) /*0x14109d8cd*/
        {
          v134 = v212.first._Mypair._Myval2._Bx._Ptr; /*0x14109d8d3*/
          if ( v115 + 1 >= 0x1000 ) /*0x14109d8e4*/
          {
            v134 = *((char **)v212.first._Mypair._Myval2._Bx._Ptr - 1); /*0x14109d8ea*/
            if ( (unsigned __int64)(v212.first._Mypair._Myval2._Bx._Ptr - v134 - 8) > 0x1F ) /*0x14109d8f9*/
              goto LABEL_240; /*0x14109d8f9*/
          }
          operator delete(ptr: v134); /*0x14109d902*/
        }
        v135 = (double)(int)v1->joinRxStats.totalBytesDeserializedUpToGameLoadedTag / *p_packetProcessingCppTimeMs; /*0x14109d916*/
        std::string::string(this: &v213.text, _Ptr: "ReplicatorCalculatedProcessSpeedAtJoinCppOnly"); /*0x14109d928*/
        *(double *)&v213.x = v135; /*0x14109d92d*/
        __wind /*0xf1c0000000000268*/
        {
          v136 = gameLoadStats._Mypair._Myval2._Myend; /*0x14109d935*/
          if ( gameLoadStats._Mypair._Myval2._Myend == v189 ) /*0x14109d93f*/
          {
            std::vector<std::pair<std::string,double>>::_Emplace_reallocate<std::pair<std::string,double>>( /*0x14109d986*/
              this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
              _Whereptr: gameLoadStats._Mypair._Myval2._Myend,
              <_Val_0>: (std::pair<std::string,double> *)&v213);
          }
          else
          {
            gameLoadStats._Mypair._Myval2._Myend->first._Mypair._Myval2._Bx = v213.text._Mypair._Myval2._Bx; /*0x14109d948*/
            *(_OWORD *)&v136->first._Mypair._Myval2._Mysize = *(_OWORD *)&v213.text._Mypair._Myval2._Mysize; /*0x14109d952*/
            *(__m128i *)&v213.text._Mypair._Myval2._Mysize = _mm_load_si128((const __m128i *)&_xmm); /*0x14109d95e*/
            v213.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109d966*/
            v136->second = v135; /*0x14109d96d*/
            ++gameLoadStats._Mypair._Myval2._Myend; /*0x14109d972*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v213); /*0xf1c0000000000260*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v213); /*0x14109d993*/
        v137 = (double)(int)v1->joinRxStats.totalBytesDeserializedUpToGameLoadedTag /*0x14109d9af*/
             / (*p_packetProcessingCppTimeMs + *p_packetProcessingScriptContextTimeMs);
        _Right.first = "ReplicatorCalculatedProcessSpeedAtJoin"; /*0x14109d9ba*/
        _Right.second = v137; /*0x14109d9c1*/
        std::pair<std::string,double>::pair<std::string,double>(this: &_Val, &_Right); /*0x14109d9d7*/
        __wind /*0xf1c0000000000250*/
        {
          std::vector<std::pair<std::string,double>>::push_back( /*0x14109d9e9*/
            this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
            &_Val);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&_Val); /*0xf1c0000000000248*/
        }
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&_Val); /*0x14109d9f6*/
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109da14*/
          this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
          name: "gameLoadtagInfo.wallclockAllDataArrivalMs",
          value: v1->joinRxStats.gameLoadedTagInfo.appArrivalTime - v1->firstDataPacketArriveTimeAfterJoinRequestInMS);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109da32*/
          this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
          name: "gameLoadtagInfo.wallclockDeserializeWaitMs",
          value: v1->joinRxStats.gameLoadedTagInfo.deserializationTime - v1->joinRxStats.gameLoadedTagInfo.appArrivalTime);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109da50*/
          this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
          name: "gameLoadtagInfo.wallclockProcesssWaitMs",
          value: v1->joinRxStats.gameLoadedTagInfo.beginProcessingTime - v1->joinRxStats.gameLoadedTagInfo.deserializationTime);
        if ( DFLog::JoinDataRxStats != 0 ) /*0x14109da5e*/
          FLog::FastLogFormatted( /*0x14109da8d*/
            level: DFLog::JoinDataRxStats,
            message: "[DFLog::JoinDataRxStats] GameLoadTagProgressTime,TimeToArrive,%u,WaitForDeserialize,%u,WaitForProcess,%u",
            v1->joinRxStats.gameLoadedTagInfo.appArrivalTime - v1->firstDataPacketArriveTimeAfterJoinRequestInMS,
            v1->joinRxStats.gameLoadedTagInfo.deserializationTime - v1->joinRxStats.gameLoadedTagInfo.appArrivalTime,
            v1->joinRxStats.gameLoadedTagInfo.beginProcessingTime
          - v1->joinRxStats.gameLoadedTagInfo.deserializationTime);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109daab*/
          this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
          name: "gameLoadtagInfo.cyclesForAllTagArrival",
          value: v1->joinRxStats.gameLoadedTagInfo.appArrivalCycle - v1->firstDataPacketArriveCycle);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109dac9*/
          this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
          name: "gameLoadtagInfo.cyclesWaitedToDeserialize",
          value: v1->joinRxStats.gameLoadedTagInfo.deserializationCycle - v1->joinRxStats.gameLoadedTagInfo.appArrivalCycle);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109dae7*/
          this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
          name: "gameLoadtagInfo.cyclesWaitedToProcess",
          value: v1->joinRxStats.gameLoadedTagInfo.beginProcessingCycle
        - v1->joinRxStats.gameLoadedTagInfo.deserializationCycle);
        if ( DFLog::JoinDataRxStats != 0 ) /*0x14109daf5*/
          FLog::FastLogFormatted( /*0x14109db24*/
            level: DFLog::JoinDataRxStats,
            message: "[DFLog::JoinDataRxStats] GameLoadTagProgressCycle,CycleToArrive,%lu,WaitForDeserialize,%lu,WaitForProcess,%lu",
            v1->joinRxStats.gameLoadedTagInfo.appArrivalCycle - v1->firstDataPacketArriveCycle,
            v1->joinRxStats.gameLoadedTagInfo.deserializationCycle - v1->joinRxStats.gameLoadedTagInfo.appArrivalCycle,
            v1->joinRxStats.gameLoadedTagInfo.beginProcessingCycle
          - v1->joinRxStats.gameLoadedTagInfo.deserializationCycle);
        RakNet::RakNetJoinRxStats::RakNetJoinRxStats(this: &v199); /*0x14109db2d*/
        if ( DFFlag::RakNetSendJoinDataBit.value ) /*0x14109db39*/
        {
          v138 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)v1->rakPeer._Ptr); /*0x14109db46*/
          v139 = v138->onInternalError._Mystorage._Ptrs[0][83].__vftable; /*0x14109db4e*/
          qmemcpy(v237, &v1->remotePlayerRakNetAddress, sizeof(v237)); /*0x14109db5d*/
          if ( ((unsigned __int8 (__fastcall *)(Luau::InternalErrorReporter *, _QWORD *, __int64))v139)( /*0x14109db88*/
                 a1: v138,
                 a2: v237,
                 a3: 0x200000) != 0 )
          {
            v140 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)v1->rakPeer._Ptr); /*0x14109db9a*/
            v141 = v140->onInternalError._Mystorage._Ptrs[0][38].__vftable; /*0x14109dba0*/
            v142 = RakNet::AddressOrGUID::AddressOrGUID(this: &v289, input: &v1->remotePlayerRakNetAddress); /*0x14109dbb5*/
            ((void (__fastcall *)(Luau::InternalErrorReporter *, RakNet::AddressOrGUID *, RakNet::RakNetJoinRxStats *))v141)( /*0x14109dbc4*/
              a1: v140,
              a2: v142,
              a3: &v199);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109dbd5*/
              this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
              name: "RakNetJoinRxBytes",
              value: v199.bytes);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109dbe9*/
              this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
              name: "RakNetJoinRxPackets",
              value: v199.packets);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109dbfd*/
              this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
              name: "RakNetJoinRxIgnoredBytes",
              value: v199.ignoredBytes);
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109dc11*/
              this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
              name: "RakNetJoinRxIgnoredPackets",
              value: v199.ignoredPackets);
            if ( DFFlag::FixDivBy0ForRakNetTime.value ) /*0x14109dc1d*/
            {
              v143 = 1; /*0x14109dc2b*/
              if ( v199.timeLastJoinPacketReceivedMs - v199.timeFirstJoinPacketReceivedMs > 1 ) /*0x14109dc31*/
                v143 = v199.timeLastJoinPacketReceivedMs - v199.timeFirstJoinPacketReceivedMs; /*0x14109dc31*/
            }
            else
            {
              v143 = v199.timeLastJoinPacketReceivedMs - v199.timeFirstJoinPacketReceivedMs; /*0x14109dc3c*/
            }
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109dc50*/
              this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
              name: "RakNetJoinDataDownloadTimeMs",
              value: v143);
            raknetJoinStats.totalRxBytes = 0; /*0x14109dc55*/
            v144 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)v1->rakPeer._Ptr); /*0x14109dc60*/
            ((void (__fastcall *)(Luau::InternalErrorReporter *, RakNet::JoinRxStats *))v144->onInternalError._Mystorage._Ptrs[0][39].__vftable)( /*0x14109dc76*/
              a1: v144,
              a2: &raknetJoinStats);
            v145 = v199.timeFirstJoinPacketReceivedMs - raknetJoinStats.totalRxBytes; /*0x14109dc7f*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109dc93*/
              this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
              name: "RakNetTimeToFirstJoinDataPacketArriveMs",
              value: v199.timeFirstJoinPacketReceivedMs - raknetJoinStats.totalRxBytes);
            v146 = (double)(8 * v199.bytes) / (double)(int)(1000 * v143); /*0x14109dcb8*/
            RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109dccd*/
              this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
              name: "RakNetJoinBandwidthMbps",
              value: v146);
            v216.first = "RakNetJoinBandwidthMbps"; /*0x14109dcd2*/
            v216.second = v146; /*0x14109dcd9*/
            std::pair<std::string,double>::pair<std::string,double>(this: &v255, _Right: &v216); /*0x14109dcef*/
            __wind /*0xf1c0000000000238*/
            {
              std::vector<std::pair<std::string,double>>::push_back( /*0x14109dd01*/
                this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
                _Val: &v255);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v255); /*0xf1c0000000000230*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v255); /*0x14109dd0e*/
            v217.first = "RakNetJoinDataDownloadTimeMs"; /*0x14109dd1a*/
            v217.second = v143; /*0x14109dd21*/
            std::pair<std::string,double>::pair<std::string,double>(this: &v256, _Right: &v217); /*0x14109dd35*/
            __wind /*0xf1c0000000000220*/
            {
              std::vector<std::pair<std::string,double>>::push_back( /*0x14109dd47*/
                this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
                _Val: &v256);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v256); /*0xf1c0000000000218*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v256); /*0x14109dd54*/
            v218.first = "RakNetTimeToFirstJoinDataPacketArriveMs"; /*0x14109dd59*/
            v218.second = v145; /*0x14109dd60*/
            std::pair<std::string,double>::pair<std::string,double>(this: &v257, _Right: &v218); /*0x14109dd74*/
            __wind /*0xf1c0000000000208*/
            {
              std::vector<std::pair<std::string,double>>::push_back( /*0x14109dd86*/
                this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
                _Val: &v257);
            }
            __unwind
            {
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v257); /*0xf1c0000000000200*/
            }
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v257); /*0x14109dd93*/
            if ( DFFlag::RakNetResendDataBit.value ) /*0x14109dd9f*/
            {
              v147 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)v1->rakPeer._Ptr); /*0x14109ddac*/
              v148 = v147->onInternalError._Mystorage._Ptrs[0][83].__vftable; /*0x14109ddb4*/
              qmemcpy(v238, &v1->remotePlayerRakNetAddress, sizeof(v238)); /*0x14109ddc3*/
              if ( ((unsigned __int8 (__fastcall *)(Luau::InternalErrorReporter *, _QWORD *, __int64))v148)( /*0x14109ddee*/
                     a1: v147,
                     a2: v238,
                     a3: 0x800000) != 0 )
              {
                RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109de03*/
                  this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
                  name: "RakNetJoinRxReBytes",
                  value: v199.reBytes);
                RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109de17*/
                  this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
                  name: "RakNetJoinRxRePackets",
                  value: v199.rePackets);
                if ( v199.timeLastNonReTxJoinPacketReceivedMs != 0 ) /*0x14109de24*/
                {
                  if ( v199.timeLastNonReTxJoinPacketReceivedMs - v199.timeFirstJoinPacketReceivedMs > 1 ) /*0x14109de2f*/
                    v86 = v199.timeLastNonReTxJoinPacketReceivedMs - v199.timeFirstJoinPacketReceivedMs; /*0x14109de2f*/
                }
                else
                {
                  v86 = v143; /*0x14109de35*/
                }
                RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109de49*/
                  this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
                  name: "RakNetNonReTxJoinDataDownloadTimeMs",
                  value: v86);
                v149 = (double)(8 * (v199.bytes - v199.reBytes)) / (double)(int)(1000 * v86); /*0x14109de6e*/
                RBX::Analytics::InfluxDb::Points::addPoint( /*0x14109de83*/
                  this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List,
                  name: "RaknetEffectiveInitialBandwidthMbps",
                  value: v149);
                v219.first = "RaknetEffectiveInitialBandwidthMbps"; /*0x14109de88*/
                v219.second = v149; /*0x14109de8f*/
                std::pair<std::string,double>::pair<std::string,double>(this: &v246, _Right: &v219); /*0x14109dea5*/
                __wind /*0xf1c00000000001f0*/
                {
                  std::vector<std::pair<std::string,double>>::push_back( /*0x14109deb7*/
                    this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
                    _Val: &v246);
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v246); /*0xf1c00000000001e8*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v246); /*0x14109dec4*/
                v220.first = "RakNetNonReTxJoinDataDownloadTimeMs"; /*0x14109dec9*/
                v220.second = v86; /*0x14109ded0*/
                std::pair<std::string,double>::pair<std::string,double>(this: &v247, _Right: &v220); /*0x14109dee5*/
                __wind /*0xf1c00000000001d8*/
                {
                  std::vector<std::pair<std::string,double>>::push_back( /*0x14109def7*/
                    this: (std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
                    _Val: &v247);
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v247); /*0xf1c00000000001d0*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v247); /*0x14109df04*/
              }
            }
            p_packetProcessingCppTimeMs = &v1->joinRxStats.packetProcessingCppTimeMs; /*0x14109df0c*/
          }
          p_packetProcessingScriptContextTimeMs = &v1->joinRxStats.packetProcessingScriptContextTimeMs; /*0x14109df13*/
        }
        if ( v1->shouldReportToDiag ) /*0x14109df1a*/
          RBX::Analytics::EphemeralCounter::bulkReportStats( /*0x14109df2b*/
            stats: (const std::vector<std::pair<std::string,double>> *)&gameLoadStats._Mypair._Myval2._Mylast,
            blocking: false);
        RBX::Analytics::InfluxDb::Points::operator=( /*0x14109df3b*/
          this: &v1->clientJoinRxStatsPoint,
          __that: (const RBX::Analytics::InfluxDb::Points *)&points.pointList._List);
        v1->reportJoinRxStats = true; /*0x14109df40*/
        p_joinDataProcessTimeInMs = &v1->joinRxStats.joinDataProcessTimeInMs; /*0x14109df4f*/
        if ( DFLog::JoinDataRxStats != 0
          && (FLog::FastLogFormatted(
                level: DFLog::JoinDataRxStats,
                message: "[DFLog::JoinDataRxStats] Join Rx Times : deltaTimeBetweenJoinRequestAndFirstBlobArrival=%fms, deltaTimeB"
                "etweenJoinRequestAndJoinProcessingComplete=%fms, joinDataReadTime=%fms, joinDataProcessTime=%fms",
                v1->joinRxStats.deltaTimeBetweenJoinRequestAndFirstBlobArrivalInMs,
                v1->joinRxStats.deltaTimeBetweenJoinRequestAndJoinProcessingCompleteInMs,
                v1->joinRxStats.joinDataReadTimeInMs,
                *p_joinDataProcessTimeInMs),
              DFLog::JoinDataRxStats != 0)
          && (FLog::FastLogFormatted(
                level: DFLog::JoinDataRxStats,
                message: "[DFLog::JoinDataRxStats] JoinData read breakdown : SharedStrings=%fms, Instance=%fms",
                v1->joinRxStats.joinDataReadTimeSharedStringsInMs,
                v1->joinRxStats.joinDataReadTimeInstanceInMs),
              DFLog::JoinDataRxStats != 0) )
        {
          FLog::FastLogFormatted(
            level: DFLog::JoinDataRxStats,
            message: "[DFLog::JoinDataRxStats] JoinData count breakdown : SharedStrings=%u, TotalInstances=%u, WastedInstances=%u,"
            " PercentageUseful=%f%%",
            v1->joinRxStats.totalSharedStringCountInJoin,
            v1->joinRxStats.totalInstancesInBlobs,
            v1->joinRxStats.totalWasteInstancesInBlobs,
            v15);
          v151 = *(float *)&stats._Mypair._Myval2._Myfirst; /*0x14109e035*/
          v152 = v191; /*0x14109e03b*/
          v153 = v190; /*0x14109e042*/
          v154 = v293; /*0x14109e049*/
          if ( DFLog::JoinDataRxStats != 0 )
          {
            FLog::FastLogFormatted(
              level: DFLog::JoinDataRxStats,
              message: "[DFLog::JoinDataRxStats] JoinData byte breakdown percentage: percentageOfBytesInSS=%f%%, percentageOfBytes"
              "Meta=%f%%, percentageOfBytesWaste=%f%%, percentageOfBytesInstancesUseful=%f%%",
              v293,
              v190,
              v191,
              *(float *)&stats._Mypair._Myval2._Myfirst);
            v155 = *(float *)&Value; /*0x14109e093*/
            if ( DFLog::JoinDataRxStats != 0 )
            {
              FLog::FastLogFormatted(
                level: DFLog::JoinDataRxStats,
                message: "[DFLog::JoinDataRxStats] JoinData read time percentage : percentageReadTimeForSS=%f%%, percentageReadTim"
                "eForMetaInstances=%f%%",
                v8,
                *(float *)&Value);
              if ( DFLog::JoinDataRxStats != 0 )
              {
                FLog::FastLogFormatted(
                  level: DFLog::JoinDataRxStats,
                  message: "[DFLog::JoinDataRxStats] JoinData SharedString Compression: Compressed: %u -> Uncompressed -> %u, Comp"
                  "ressionRatio %f%%",
                  v1->joinRxStats.totalSharedStringBytesRxInJoin,
                  v1->joinRxStats.totalSharedStringBytesUncompressedInJoin,
                  v14);
                if ( DFLog::JoinDataRxStats != 0 )
                {
                  FLog::FastLogFormatted(
                    level: DFLog::JoinDataRxStats,
                    message: "[DFLog::JoinDataRxStats] Join Rx Blob Stats : totalBlobBytesRxDuringJoin=%d, totalBlobRxDuringJoin=%"
                    "d, totalMetaBytesRxInJoin=%d, totalWasteBytesRxInJoin=%d, totalSharedStringBytesRxDuringJoin=%d",
                    v1->joinRxStats.totalBlobBytesRxDuringJoin,
                    v1->joinRxStats.totalBlobRxDuringJoin,
                    v1->joinRxStats.totalMetaBytesRxInJoin,
                    v1->joinRxStats.totalWasteBytesRxInJoin,
                    v1->joinRxStats.totalSharedStringBytesRxInJoin);
                  if ( DFLog::JoinDataRxStats != 0 )
                  {
                    FLog::FastLogFormatted(
                      level: DFLog::JoinDataRxStats,
                      message: "[DFLog::JoinDataRxStats] Join Rx Packet Stats : totalRxBytes=%d, totalRxPackets=%d, totalRxIgnored"
                      "Bytes=%d, totalRxIgnoredPackets=%d",
                      raknetJoinStats.totalRxIgnoredBytes,
                      raknetJoinStats.totalRxIgnoredPackets,
                      HIDWORD(instancesWriter.buffer),
                      HIDWORD(instancesWriter.buffer));
                    if ( DFLog::JoinDataRxStats != 0 )
                    {
                      v156 = *p_packetProcessingCppTimeMs + *p_packetProcessingScriptContextTimeMs; /*0x14109e188*/
                      avgJdiV2ProcessedPerFrame = v1->joinRxStats.packetDeserializeTimeMs._Storage._Value; /*0x14109e193*/
                      FLog::FastLogFormatted(
                        level: DFLog::JoinDataRxStats,
                        message: "[DFLog::JoinDataRxStats] Total Packet Deserialization Time : %f ms   Total Process Packet Time : %f ms",
                        avgJdiV2ProcessedPerFrame,
                        v156);
                      if ( DFLog::JoinDataRxStats != 0 )
                      {
                        avgJdiV2ProcessedPerFrame = v1->joinRxStats.packetDeserializeTimeDataMs._Storage._Value; /*0x14109e1d4*/
                        Value = v1->joinRxStats.packetDeserializeTimeClusterMs._Storage._Value; /*0x14109e1e3*/
                        FLog::FastLogFormatted(
                          level: DFLog::JoinDataRxStats,
                          message: "[DFLog::JoinDataRxStats] Process Deserialization Time : Cluster : %f ms   Data : %f ms",
                          Value,
                          avgJdiV2ProcessedPerFrame);
                        if ( DFLog::JoinDataRxStats != 0 )
                        {
                          FLog::FastLogFormatted(
                            level: DFLog::JoinDataRxStats,
                            message: "[DFLog::JoinDataRxStats] Process Packet Script Time : %f ms   ProcessPacket Cpp Time : %f ms",
                            *(_QWORD *)p_packetProcessingScriptContextTimeMs,
                            *(_QWORD *)p_packetProcessingCppTimeMs);
                          p_initialClusterProcessTimeInMs = &v1->joinRxStats.initialClusterProcessTimeInMs; /*0x14109e24e*/
                          if ( DFLog::JoinDataRxStats != 0 )
                          {
                            FLog::FastLogFormatted(
                              level: DFLog::JoinDataRxStats,
                              message: "[DFLog::JoinDataRxStats] Process Cluster Time : %f ms  Process Data Time : %f ms",
                              *p_initialClusterProcessTimeInMs,
                              *p_joinDataProcessTimeInMs);
                            if ( DFLog::JoinDataRxStats != 0 )
                            {
                              FLog::FastLogFormatted(
                                level: DFLog::JoinDataRxStats,
                                message: "[DFLog::JoinDataRxStats] Total Time from connection accept to load : %f ms ",
                                v1->joinRxStats.connectionAcceptedToGameLoadTimeMs);
                              if ( DFLog::JoinDataRxStats != 0 )
                                FLog::FastLogFormatted(
                                  level: DFLog::JoinDataRxStats,
                                  message: "[DFLog::JoinDataRxStats] Time from connection accept to first process packet : %f ms ",
                                  v1->joinRxStats.connectionAcceptedToFirstPacketProcessMs);
                            }
                          }
                          goto LABEL_293; /*0x14109e2d2*/
                        }
                      }
                    }
                  }
                }
              }
            }
LABEL_292:
            p_initialClusterProcessTimeInMs = &v1->joinRxStats.initialClusterProcessTimeInMs; /*0x14109e2f8*/
LABEL_293:
            if ( v1->shouldReportToDiag ) /*0x14109e2ff*/
            {
              *(_OWORD *)&stats._Mypair._Myval2._Mylast = 0; /*0x14109e310*/
              v193 = 0; /*0x14109e315*/
              __wind /*0xf1c000000000019c*/
              {
                v158 = "_NonStreamingEnabled"; /*0x14109e320*/
                if ( v1->streamingEnabled ) /*0x14109e327*/
                  v158 = "_StreamingEnabled"; /*0x14109e32f*/
                std::string::string(this: (std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8], _Ptr: v158); /*0x14109e33a*/
                __wind /*0xf1c0000000000190*/
                {
                  avgJdiV2ProcessedPerFrame = v1->joinRxStats.packetDeserializeTimeMs._Storage._Value; /*0x14109e347*/
                  v159 = std::operator+<char>( /*0x14109e374*/
                           result: &v276,
                           _Left: "TotalPacketDeserializationTimeMsDuringJoin",
                           _Right: (const std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8]);
                  __wind /*0xf1c0000000000184*/
                  {
                    v160 = std::pair<std::string,double>::pair<std::string,double>( /*0x14109e38b*/
                             result: &v287,
                             _Val1: v159,
                             _Val2: &avgJdiV2ProcessedPerFrame);
                    __wind /*0xf1c0000000000160*/
                    {
                      std::vector<std::pair<std::string,double>>::push_back( /*0x14109e398*/
                        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                        _Val: v160);
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v287); /*0x14109e3a5*/
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v276); /*0x14109e3b2*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v287); /*0xf1c0000000000170*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v276); /*0xf1c000000000017c*/
                  }
                  avgJdiV2ProcessedPerFrame = v1->joinRxStats.joinDataReadTimeInMs; /*0x14109e3c3*/
                  v161 = std::operator+<char>( /*0x14109e3e0*/
                           result: &v271,
                           _Left: "DataDeserializationTimeMsDuringJoin",
                           _Right: (const std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8]);
                  v162 = std::pair<std::string,double>::pair<std::string,double>( /*0x14109e3f7*/
                           result: &v288,
                           _Val1: v161,
                           _Val2: &avgJdiV2ProcessedPerFrame);
                  __wind /*0xf1c0000000000630*/
                  {
                    __wind /*0xf1c0000000000638*/
                    {
                      std::vector<std::pair<std::string,double>>::push_back( /*0x14109e404*/
                        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                        _Val: v162);
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v288); /*0x14109e411*/
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v271); /*0x14109e41e*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v288); /*0xf1c000000000061c*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v271); /*0xf1c0000000000628*/
                  }
                  avgJdiV2ProcessedPerFrame = v1->joinRxStats.packetDeserializeTimeClusterMs._Storage._Value; /*0x14109e42a*/
                  v163 = std::operator+<char>( /*0x14109e457*/
                           result: &v270,
                           _Left: "ClusterDeserializationTimeMsDuringJoin",
                           _Right: (const std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8]);
                  v164 = std::pair<std::string,double>::pair<std::string,double>( /*0x14109e46e*/
                           result: &v278,
                           _Val1: v163,
                           _Val2: &avgJdiV2ProcessedPerFrame);
                  __wind /*0xf1c0000000000604*/
                  {
                    __wind /*0xf1c000000000060c*/
                    {
                      std::vector<std::pair<std::string,double>>::push_back( /*0x14109e47b*/
                        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                        _Val: v164);
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v278); /*0x14109e488*/
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v270); /*0x14109e495*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v278); /*0xf1c00000000005f0*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v270); /*0xf1c00000000005fc*/
                  }
                  v165 = std::operator+<char>( /*0x14109e4af*/
                           result: &v269,
                           _Left: "JdiProcessTimeMsDuringJoin",
                           _Right: (const std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8]);
                  v166 = std::make_pair<std::string,float>( /*0x14109e4c2*/
                           result: &v279,
                           _Val1: v165,
                           _Val2: &v1->joinRxStats.joinDataProcessTimeInMs);
                  std::pair<std::string,double>::pair<std::string,double>(this: &v248, _Right: v166); /*0x14109e4d2*/
                  __wind /*0xf1c00000000006a8*/
                  {
                    __wind /*0xf1c00000000006b0*/
                    {
                      __wind /*0xf1c00000000006b8*/
                      {
                        std::vector<std::pair<std::string,double>>::push_back( /*0x14109e4e3*/
                          this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                          _Val: &v248);
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v248); /*0x14109e4f0*/
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v279); /*0x14109e4fd*/
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v269); /*0x14109e50a*/
                      }
                      __unwind
                      {
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v248); /*0xf1c0000000000688*/
                      }
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v279); /*0xf1c0000000000694*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v269); /*0xf1c00000000006a0*/
                  }
                  v167 = std::operator+<char>( /*0x14109e524*/
                           result: &v273,
                           _Left: "ClusterProcessTimeMsDursingJoin",
                           _Right: (const std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8]);
                  v168 = std::make_pair<std::string,float>( /*0x14109e537*/
                           result: &v280,
                           _Val1: v167,
                           _Val2: p_initialClusterProcessTimeInMs);
                  std::pair<std::string,double>::pair<std::string,double>(this: &v249, _Right: v168); /*0x14109e547*/
                  __wind /*0xf1c0000000000668*/
                  {
                    __wind /*0xf1c0000000000670*/
                    {
                      __wind /*0xf1c0000000000678*/
                      {
                        std::vector<std::pair<std::string,double>>::push_back( /*0x14109e558*/
                          this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                          _Val: &v249);
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v249); /*0x14109e565*/
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v280); /*0x14109e572*/
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v273); /*0x14109e57f*/
                      }
                      __unwind
                      {
                        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v249); /*0xf1c0000000000648*/
                      }
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v280); /*0xf1c0000000000654*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v273); /*0xf1c0000000000660*/
                  }
                  avgJdiV2ProcessedPerFrame = *p_packetProcessingCppTimeMs + *p_packetProcessingScriptContextTimeMs; /*0x14109e58c*/
                  v169 = std::operator+<char>( /*0x14109e5a9*/
                           result: &v272,
                           _Left: "PacketProcessingTotalTimeMsJoin",
                           _Right: (const std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8]);
                  v170 = std::pair<std::string,double>::pair<std::string,double>( /*0x14109e5c0*/
                           result: &v281,
                           _Val1: v169,
                           _Val2: &avgJdiV2ProcessedPerFrame);
                  __wind /*0xf1c00000000005d8*/
                  {
                    __wind /*0xf1c00000000005e0*/
                    {
                      std::vector<std::pair<std::string,double>>::push_back( /*0x14109e5cd*/
                        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                        _Val: v170);
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v281); /*0x14109e5da*/
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v272); /*0x14109e5e7*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v281); /*0xf1c00000000005c4*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v272); /*0xf1c00000000005d0*/
                  }
                  v171 = std::operator+<char>( /*0x14109e601*/
                           result: &v274,
                           _Left: "PacketProcessingCppTimeMsJoin",
                           _Right: (const std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8]);
                  v172 = std::pair<std::string,double>::pair<std::string,double>( /*0x14109e614*/
                           result: &v282,
                           _Val1: v171,
                           _Val2: p_packetProcessingCppTimeMs);
                  __wind /*0xf1c00000000005ac*/
                  {
                    __wind /*0xf1c00000000005b4*/
                    {
                      std::vector<std::pair<std::string,double>>::push_back( /*0x14109e621*/
                        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                        _Val: v172);
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v282); /*0x14109e62e*/
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v274); /*0x14109e63b*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v282); /*0xf1c0000000000598*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v274); /*0xf1c00000000005a4*/
                  }
                  v173 = std::operator+<char>( /*0x14109e655*/
                           result: &v275,
                           _Left: "PacketProcessingScriptTimeMsJoin",
                           _Right: (const std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8]);
                  v174 = std::pair<std::string,double>::pair<std::string,double>( /*0x14109e668*/
                           result: &v283,
                           _Val1: v173,
                           _Val2: p_packetProcessingScriptContextTimeMs);
                  __wind /*0xf1c0000000000580*/
                  {
                    __wind /*0xf1c0000000000588*/
                    {
                      std::vector<std::pair<std::string,double>>::push_back( /*0x14109e675*/
                        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                        _Val: v174);
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v283); /*0x14109e682*/
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v275); /*0x14109e68f*/
                      v175 = v1->joinRxStats.framesWithJDIProcessing; /*0x14109e694*/
                      if ( v1->joinRxStats.frameHasJdiProcessWork._Storage._Value ) /*0x14109e69b*/
                        ++v175; /*0x14109e6a8*/
                      v176 = 0.0; /*0x14109e6aa*/
                      if ( v175 > 0 ) /*0x14109e6af*/
                        v176 = (double)(int)v1->joinRxStats.numJdiV2Processed / (double)v175; /*0x14109e6c5*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v283); /*0xf1c000000000056c*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v275); /*0xf1c0000000000578*/
                  }
                  avgJdiV2ProcessedPerFrame = v176; /*0x14109e6c9*/
                  v177 = std::operator+<char>( /*0x14109e6e6*/
                           result: &v277,
                           _Left: "avgJdiV2ProcessedPerFrame",
                           _Right: (const std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8]);
                  v178 = std::pair<std::string,double>::pair<std::string,double>( /*0x14109e6fd*/
                           result: &v284,
                           _Val1: v177,
                           _Val2: &avgJdiV2ProcessedPerFrame);
                  __wind /*0xf1c0000000000554*/
                  {
                    __wind /*0xf1c000000000055c*/
                    {
                      std::vector<std::pair<std::string,double>>::push_back( /*0x14109e70a*/
                        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                        _Val: v178);
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v284); /*0x14109e717*/
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v277); /*0x14109e724*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v284); /*0xf1c0000000000540*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v277); /*0xf1c000000000054c*/
                  }
                  v179 = std::operator+<char>( /*0x14109e73e*/
                           result: &v267,
                           _Left: "longestSingleFrameCppPartJdiV2",
                           _Right: (const std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8]);
                  v180 = std::pair<std::string,double>::pair<std::string,double>( /*0x14109e755*/
                           result: &v285,
                           _Val1: v179,
                           _Val2: &v1->joinRxStats.longestSingleFrameCppTimeForJoinProcessingMs);
                  __wind /*0xf1c0000000000528*/
                  {
                    __wind /*0xf1c0000000000530*/
                    {
                      std::vector<std::pair<std::string,double>>::push_back( /*0x14109e762*/
                        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                        _Val: v180);
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v285); /*0x14109e76f*/
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v267); /*0x14109e77c*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v285); /*0xf1c0000000000514*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v267); /*0xf1c0000000000520*/
                  }
                  v181 = std::operator+<char>( /*0x14109e796*/
                           result: &v268,
                           _Left: "longestSingleFrameScriptPartJdiV2",
                           _Right: (const std::string *)&streamingTag._Mypair._Myval2._Bx._Alias[8]);
                  v182 = std::pair<std::string,double>::pair<std::string,double>( /*0x14109e7ad*/
                           result: &v286,
                           _Val1: v181,
                           _Val2: &v1->joinRxStats.longestSingleFrameScriptTimeForJoinProcessingMs);
                  __wind /*0xf1c00000000004fc*/
                  {
                    __wind /*0xf1c0000000000504*/
                    {
                      std::vector<std::pair<std::string,double>>::push_back( /*0x14109e7ba*/
                        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                        _Val: v182);
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v286); /*0x14109e7c7*/
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v268); /*0x14109e7d4*/
                    }
                    __unwind
                    {
                      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v286); /*0xf1c00000000004e8*/
                    }
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v268); /*0xf1c00000000004f4*/
                  }
                  v221.first = "jdiv2TotalUncompressSharedStringSize"; /*0x14109e7e0*/
                  v221.second = v1->joinRxStats.totalSharedStringBytesUncompressedInJoin; /*0x14109e7ee*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v251, _Right: &v221); /*0x14109e802*/
                  __wind /*0xf1c0000000000154*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109e813*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v251);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v251); /*0x14109e820*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v251); /*0xf1c000000000014c*/
                  }
                  v234.first = "jdiv2SharedStringEffCompressionRatio"; /*0x14109e82c*/
                  v234.second = v14; /*0x14109e833*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v252, _Right: &v234); /*0x14109e84a*/
                  __wind /*0xf1c000000000013c*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109e85b*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v252);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v252); /*0x14109e868*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v252); /*0xf1c0000000000134*/
                  }
                  v232.first = "jdiv2TotalSharedStringCountInBlob"; /*0x14109e874*/
                  v232.second = v1->joinRxStats.totalSharedStringCountInJoin; /*0x14109e882*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v253, _Right: &v232); /*0x14109e896*/
                  __wind /*0xf1c0000000000124*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109e8a7*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v253);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v253); /*0x14109e8b4*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v253); /*0xf1c000000000011c*/
                  }
                  v231.first = "jdiv2TotalInstanceCountInBlob"; /*0x14109e8c0*/
                  v231.second = v1->joinRxStats.totalInstancesInBlobs; /*0x14109e8ce*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v266, _Right: &v231); /*0x14109e8e2*/
                  __wind /*0xf1c000000000010c*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109e8f3*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v266);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v266); /*0x14109e900*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v266); /*0xf1c0000000000104*/
                  }
                  v233.first = "jdiv2TotalInvalidInstanceCountInBlob"; /*0x14109e90c*/
                  v233.second = v1->joinRxStats.totalWasteInstancesInBlobs; /*0x14109e91a*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v254, _Right: &v233); /*0x14109e92e*/
                  __wind /*0xf1c00000000000f4*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109e93f*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v254);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v254); /*0x14109e94c*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v254); /*0xf1c00000000000ec*/
                  }
                  v230.first = "percentageBlobBytesSharedStrings"; /*0x14109e958*/
                  v230.second = v154; /*0x14109e95f*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v250, _Right: &v230); /*0x14109e975*/
                  __wind /*0xf1c00000000000dc*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109e986*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v250);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v250); /*0x14109e993*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v250); /*0xf1c00000000000d4*/
                  }
                  v229.first = "percentageBlobBytesMeta"; /*0x14109e99f*/
                  v229.second = v153; /*0x14109e9a6*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v258, _Right: &v229); /*0x14109e9bd*/
                  __wind /*0xf1c00000000000c4*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109e9ce*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v258);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v258); /*0x14109e9db*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v258); /*0xf1c00000000000bc*/
                  }
                  v228.first = "percentageBlobBytesWaste"; /*0x14109e9e7*/
                  v228.second = v152; /*0x14109e9ee*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v259, _Right: &v228); /*0x14109ea05*/
                  __wind /*0xf1c00000000000ac*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109ea16*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v259);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v259); /*0x14109ea23*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v259); /*0xf1c00000000000a4*/
                  }
                  v227.first = "percentageBlobBytesInstance"; /*0x14109ea2f*/
                  v227.second = v151; /*0x14109ea36*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v260, _Right: &v227); /*0x14109ea4d*/
                  __wind /*0xf1c0000000000094*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109ea5e*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v260);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v260); /*0x14109ea6b*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v260); /*0xf1c000000000008c*/
                  }
                  v226.first = "percentageUsefulInstancesCount"; /*0x14109ea77*/
                  v226.second = v15; /*0x14109ea7e*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v261, _Right: &v226); /*0x14109ea95*/
                  __wind /*0xf1c000000000007c*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109eaa6*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v261);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v261); /*0x14109eab3*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v261); /*0xf1c0000000000074*/
                  }
                  v222.first = "percentageReadTimeForSS"; /*0x14109eabf*/
                  v222.second = v8; /*0x14109eac6*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v262, _Right: &v222); /*0x14109eadd*/
                  __wind /*0xf1c0000000000064*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109eaee*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v262);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v262); /*0x14109eafb*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v262); /*0xf1c000000000005c*/
                  }
                  v223.first = "percentageReadTimeForMetaInstances"; /*0x14109eb07*/
                  v223.second = v155; /*0x14109eb0e*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v263, _Right: &v223); /*0x14109eb24*/
                  __wind /*0xf1c000000000004c*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109eb35*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v263);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v263); /*0x14109eb42*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v263); /*0xf1c0000000000044*/
                  }
                  v224.first = "numFramesBetweenConnectionAcceptedAndGameLoadTime"; /*0x14109eb4e*/
                  v224.second = (unsigned int)v290; /*0x14109eb5b*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v264, _Right: &v224); /*0x14109eb6f*/
                  __wind /*0xf1c0000000000034*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109eb80*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v264);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v264); /*0x14109eb8d*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v264); /*0xf1c000000000002c*/
                  }
                  v225.first = "averageFpsDuringJoin"; /*0x14109eb99*/
                  v225.second = v89; /*0x14109eba0*/
                  std::pair<std::string,double>::pair<std::string,double>(this: &v265, _Right: &v225); /*0x14109ebb7*/
                  __wind /*0xf1c000000000001c*/
                  {
                    std::vector<std::pair<std::string,double>>::push_back( /*0x14109ebc8*/
                      this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                      _Val: &v265);
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v265); /*0x14109ebd5*/
                  }
                  __unwind
                  {
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v265); /*0xf1c0000000000014*/
                  }
                  if ( DFFlag::ClientReportJoinInstanceTypeBreakdown2.value ) /*0x14109ebe1*/
                  {
                    v183 = v1->joinRxStats.totalInstancesInBlobs; /*0x14109ebe3*/
                    if ( v183 != 0 ) /*0x14109ebec*/
                    {
                      LODWORD(v290) = v1->joinRxStats.totalInstanceBytesRxInJoin / v183; /*0x14109ebf9*/
                      std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[23],unsigned int &>( /*0x14109ec11*/
                        this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                        <_Val_0>: (const char (*)[25])"bytesPerInstance",
                        <_Val_1>: (unsigned int *)&v290);
                    }
                  }
                  std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[23],unsigned int &>( /*0x14109ec28*/
                    this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                    <_Val_0>: (const char (*)[25])"numJdiv2RecvDuringJoin",
                    <_Val_1>: &v1->joinRxStats.totalJdiv2ItemsRxDuringJoin);
                  std::vector<std::pair<std::string,double>>::emplace_back<char const (&)[23],unsigned int &>( /*0x14109ec3f*/
                    this: (std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                    <_Val_0>: (const char (*)[25])"bytesJdiv2RecvDuringJoin",
                    <_Val_1>: &v1->joinRxStats.totalJdiv2BytesRxDuringJoin);
                  RBX::Analytics::EphemeralCounter::bulkReportStats( /*0x14109ec4a*/
                    stats: (const std::vector<std::pair<std::string,double>> *)&stats._Mypair._Myval2._Mylast,
                    blocking: false);
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&streamingTag._Mypair._Myval2._Bx._Alias[8]); /*0xf1c0000000000008*/
                }
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&streamingTag._Mypair._Myval2._Bx._Alias[8]); /*0x14109ec57*/
                std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)&stats._Mypair._Myval2._Mylast); /*0x14109ec61*/
              }
              __unwind
              {
                std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)&stats._Mypair._Myval2._Mylast); /*0xf1c00000000001ac*/
              }
            }
            goto LABEL_410; /*0xf1c00000000001a8*/
          }
        }
        else
        {
          v154 = v293; /*0x14109e2d4*/
          v153 = v190; /*0x14109e2dc*/
          v152 = v191; /*0x14109e2e3*/
          v151 = *(float *)&stats._Mypair._Myval2._Myfirst; /*0x14109e2ea*/
        }
        v155 = *(float *)&Value; /*0x14109e2f0*/
        goto LABEL_292; /*0x14109e2f0*/
      }
      v131 = v206.first._Mypair._Myval2._Bx._Ptr; /*0x14109d818*/
      if ( v130 + 1 < 0x1000 /*0x14109d83e*/
        || (v131 = *((char **)v206.first._Mypair._Myval2._Bx._Ptr - 1),
            (unsigned __int64)(v206.first._Mypair._Myval2._Bx._Ptr - v131 - 8) <= 0x1F) )
      {
        operator delete(ptr: v131); /*0x14109d844*/
        goto LABEL_233; /*0x14109d844*/
      }
LABEL_240:
      _invalid_parameter_noinfo_noreturn(); /*0x14109d8fb*/
    }
    __unwind
    {
      std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)&gameLoadStats._Mypair._Myval2._Mylast); /*0xf1c00000000001b8*/
    }
  }
  __unwind
  {
    RBX::Analytics::InfluxDb::Points::~Points(this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List); /*0xf1c00000000001c4*/
  }
LABEL_410:
  std::vector<RBX::LSP::SnippetSetting>::_Tidy(this: (std::vector<RBX::Telemetry::EphemeralStatBatchEvent> *)&gameLoadStats._Mypair._Myval2._Mylast); /*0x14109ec6c*/
  RBX::Analytics::InfluxDb::Points::~Points(this: (RBX::Analytics::InfluxDb::Points *)&points.pointList._List); /*0x14109ec76*/
}

// Address: 0x14109ecf0 | Name: ?preserveForwardRefsToGuid@ClientReplicator@Network@RBX@@UEAAXVGuid@3@_N@Z
void __fastcall RBX::Network::ClientReplicator::preserveForwardRefsToGuid(
        RBX::Network::ClientReplicator *this,
        RBX::Guid guid,
        bool preserve)
{
  RBX::Network::MegaReplicator::preserveForwardRefsToGuid(this: this->megaReplicator, guid, preserve); /*0x14109ecf7*/
}

// Address: 0x14109ed00 | Name: ?processPacket@ClientReplicator@Network@RBX@@MEAA?AU?$pair@_K_N@std@@PEAUPacket@RakNet@@_K@Z
std::pair<unsigned __int64,bool> *__fastcall RBX::Network::ClientReplicator::processPacket(
        RBX::Network::ClientReplicator *this,
        std::pair<unsigned __int64,bool> *result,
        RakNet::Packet *packet,
        unsigned __int64 offset)
{
  RakNet::Packet *v4; // rbx
  std::pair<unsigned __int64,bool> *v5; // rsi
  unsigned __int8 *data; // rdx
  unsigned int *p_bitSize; // r14
  unsigned __int8 *v9; // rcx
  double v10; // xmm6_8
  const unsigned int *p_length; // rbx
  RBX::Network::MegaReplicator *megaReplicator; // r14
  RBX::DataModel *v13; // rax
  RBX::DataModel *v14; // r8
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v17; // ett
  RBX::Reflection::DescribedBase *Ptr; // rcx
  std::_Ref_count_base *v19; // rdx
  RBX::DataModel *p_Rep; // rax
  RBX::PermissionsService *v21; // rsi
  std::_Ref_count_base *v22; // rbx
  RBX::Network::PhysicsSenderS2 *v23; // rax
  RBX::Network::PhysicsSenderS2 *v24; // rbx
  std::_Ref_count_base *v25; // rax
  std::_Ref_count_base *v26; // rbx
  RBX::Network::PhysicsReceiverS2 *v27; // rax
  RBX::Network::PhysicsReceiverS2 *v28; // rbx
  std::_Ref_count_base *v29; // rax
  std::_Ref_count_base *v30; // rbx
  RBX::Network::PhysicsTouchSerializer *v31; // rax
  RBX::Network::PhysicsTouchSerializer *v32; // rbx
  std::_Ref_count_base *v33; // rax
  std::_Ref_count_base *v34; // rbx
  bool streamingEnabled; // cl
  RBX::Network::StreamingSolver *v36; // rax
  RBX::Network::StreamingSolver *v37; // r14
  RBX::DataModel *v38; // rax
  RBX::Network::StreamingSolver *v39; // rax
  std::_Ref_count_base *v40; // rcx
  RBX::Network::ClientReplicator::GCJob *v41; // rax
  RBX::Network::ClientReplicator::GCJob *v42; // rax
  std::_Ref_count_base *v43; // rcx
  RBX::ServiceProvider *parent; // r14
  RBX::Instance *v45; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v47; // rax
  unsigned __int64 v48; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v49; // r12
  const RBX::Name *v50; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *v52; // rbx
  RBX::Graphics::FrameRateManagerStatsStringItem *v53; // rbx
  RBX::Network::StrictNetworkFilter *v54; // rax
  std::_Ref_count_base *Myval2; // rcx
  std::_Ref_count_base *v56; // rcx
  RBX::Network::StrictNetworkFilter *v57; // rax
  RBX::Network::StrictNetworkFilter *v58; // rcx
  bool v59; // r15
  bool v60; // r12
  bool v61; // r13
  RBX::ServiceProvider *RootAncestor; // r14
  RBX::Instance *v63; // rcx
  const RBX::Reflection::ClassDescriptor *v64; // rbx
  RBX::Reflection::ClassDescriptor *v65; // rax
  bool v66; // al
  RBX::Players *players; // rcx
  unsigned int v68; // edx
  unsigned int v69; // eax
  long double v70; // xmm0_8
  unsigned __int8 *Myfirst; // rcx
  unsigned int newPeerId; // [rsp+20h] [rbp-E0h] BYREF
  void *v74; // [rsp+28h] [rbp-D8h]
  std::_Temporary_owner<RBX::Network::PhysicsSenderS2> v75; // [rsp+30h] [rbp-D0h] BYREF
  unsigned int *v76; // [rsp+38h] [rbp-C8h]
  std::shared_ptr<RBX::DataModel> dm; // [rsp+40h] [rbp-C0h] BYREF
  std::shared_ptr<RBX::TaskScheduler::Job> v78; // [rsp+50h] [rbp-B0h] BYREF
  std::shared_ptr<RBX::TaskScheduler::Job> v79; // [rsp+60h] [rbp-A0h] BYREF
  std::shared_ptr<RBX::Network::StrictNetworkFilter::WhiteList> v80; // [rsp+70h] [rbp-90h] BYREF
  std::shared_ptr<RBX::Network::StrictNetworkFilter::WhiteList> v81; // [rsp+80h] [rbp-80h] BYREF
  __int64 v82; // [rsp+A0h] [rbp-60h]
  __int64 v83; // [rsp+B0h] [rbp-50h]
  RBX::Network::NetworkStream inBitstream; // [rsp+C0h] [rbp-40h] BYREF
  std::_Temporary_owner<RBX::Network::PhysicsReceiverS2> v85; // [rsp+100h] [rbp+0h] BYREF
  std::_Temporary_owner<RBX::Network::PhysicsTouchSerializer> v86; // [rsp+108h] [rbp+8h] BYREF
  std::shared_ptr<RBX::Instance> v87; // [rsp+110h] [rbp+10h] BYREF
  RBX::Network::NetworkStream bitStream; // [rsp+120h] [rbp+20h] BYREF

  v4 = packet; /*0x14109ed2a*/
  v5 = result; /*0x14109ed2d*/
  data = packet->data; /*0x14109ed33*/
  if ( *data == 129 ) /*0x14109ed40*/
  {
    if ( DFFlag::DebugAvatarProfilerCallers.value ) /*0x14109edcd*/
    {
      v10 = RBX::Time::nowFastSec(); /*0x14109edd4*/
      data = v4->data; /*0x14109edd7*/
    }
    else
    {
      v10 = *(double *)&packet; /*0x14109eddd*/
    }
    p_length = &v4->length; /*0x14109ede5*/
    v76 = (unsigned int *)p_length; /*0x14109ede9*/
    RBX::Network::NetworkStream::NetworkStream( /*0x14109edf8*/
      this: &inBitstream,
      _data: data,
      lengthInBytes: *p_length,
      copyData: false);
    __eh34_enter_wind_state(-1, 1); /*0xf1c000000000013c*/
    RBX::Network::NetworkStream::IgnoreBytes(this: &inBitstream, numberOfBytes: 1u); /*0x14109ee07*/
    megaReplicator = this->megaReplicator; /*0x14109ee0c*/
    v13 = RBX::DataModel::get(context: this); /*0x14109ee16*/
    v14 = v13; /*0x14109ee1b*/
    if ( v13 != nullptr ) /*0x14109ee27*/
    {
      Rep = v13->_Wptr._Rep; /*0x14109ee29*/
      if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x14109ee3b*/
LABEL_132:
        std::_Throw_bad_weak_ptr(); /*0x14109f5f3*/
      while ( 1 ) /*0x14109ee44*/
      {
        v17 = Uses; /*0x14109ee44*/
        Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x14109ee44*/
        if ( v17 == Uses ) /*0x14109ee49*/
          break; /*0x14109ee49*/
        if ( Uses == 0 ) /*0x14109ee4d*/
          goto LABEL_132; /*0x14109ee4d*/
        if ( __eh34_unwind(1) ) /*0xf1c0000000000160*/
          goto unwind_state_1; /*0xf1c0000000000160*/
        __eh34_exit_wind_state(1, -1); /*0xf1c0000000000164*/
        __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000168*/
        if ( __eh34_unwind(0) ) /*0xf1c0000000000170*/
        {
unwind_state_0:
          RBX::Network::NetworkStream::~NetworkStream(this: &bitStream); /*0xf1c0000000000148*/
          __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000014c*/
        }
        __eh34_exit_wind_state(0, -1); /*0xf1c0000000000174*/
        __eh34_enter_wind_state(-1, 1); /*0xf1c0000000000178*/
      }
      Ptr = v14->_Wptr._Ptr; /*0x14109ee55*/
      v19 = v14->_Wptr._Rep; /*0x14109ee59*/
      p_Rep = (RBX::DataModel *)&Ptr[-1]._Wptr._Rep; /*0x14109ee5d*/
      v21 = nullptr; /*0x14109ee61*/
      if ( Ptr == nullptr ) /*0x14109ee66*/
        p_Rep = nullptr; /*0x14109ee66*/
      dm._Ptr = p_Rep; /*0x14109ee6a*/
      dm._Rep = v19; /*0x14109ee6f*/
      v82 = 0; /*0x14109ee74*/
    }
    else
    {
      v21 = nullptr; /*0x14109ee7a*/
      dm._Ptr = nullptr; /*0x14109ee7c*/
      dm._Rep = nullptr; /*0x14109ee81*/
      v83 = 0; /*0x14109ee86*/
    }
    __wind /*0xf1c0000000000130*/
    {
      RBX::Network::MegaReplicator::startMegaJobs(this: megaReplicator, &dm); /*0x14109ee92*/
      v22 = dm._Rep; /*0x14109ee98*/
      if ( dm._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&dm._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14109eead*/
      {
        v22->_Destroy(this: v22); /*0x14109eeb5*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v22->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14109eec2*/
          v22->_Delete_this(this: v22); /*0x14109eeca*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&dm); /*0xf1c0000000000128*/
    }
    if ( !this->isCloudEdit(this) ) /*0x14109eedb*/
    {
      v23 = (RBX::Network::PhysicsSenderS2 *)operator new(size: 0xD8u); /*0x14109eee6*/
      v75._Ptr = v23; /*0x14109eeeb*/
      __wind /*0xf1c0000000000118*/
      {
        if ( v23 != nullptr ) /*0x14109eef3*/
          v24 = RBX::Network::PhysicsSenderS2::PhysicsSenderS2(this: v23, replicator: this); /*0x14109ef00*/
        else
          v24 = nullptr; /*0x14109ef05*/
      }
      __unwind
      {
        operator delete(ptr: v75._Ptr); /*0x1431e19c2*/
      }
      v75._Ptr = v24; /*0x14109ef08*/
      __wind /*0xf1c0000000000100*/
      {
        v25 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x14109ef12*/
        v74 = v25; /*0x14109ef17*/
        if ( v25 != nullptr ) /*0x14109ef1f*/
        {
          *v25 = 0; /*0x14109ef24*/
          v25->_Uses = 1; /*0x14109ef27*/
          v25->_Weaks = 1; /*0x14109ef2e*/
          v25->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::PhysicsSenderS2>::`vftable'; /*0x14109ef3c*/
          v25[1].__vftable = (std::_Ref_count_base_vtbl *)v24; /*0x14109ef3f*/
        }
        else
        {
          v25 = nullptr; /*0x14109ef45*/
        }
        this->physicsSenderS2._Ptr = v24; /*0x14109ef48*/
        v26 = this->physicsSenderS2._Rep; /*0x14109ef4f*/
        this->physicsSenderS2._Rep = v25; /*0x14109ef56*/
        if ( v26 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v26->_Uses, 0xFFFFFFFF) == 1 ) /*0x14109ef6d*/
        {
          v26->_Destroy(this: v26); /*0x14109ef75*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v26->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14109ef82*/
            v26->_Delete_this(this: v26); /*0x14109ef8a*/
        }
      }
      __unwind
      {
        std::_Temporary_owner<RBX::Network::PhysicsSenderS2>::~_Temporary_owner<RBX::Network::PhysicsSenderS2>(this: &v75); /*0xf1c00000000000f8*/
      }
      v27 = (RBX::Network::PhysicsReceiverS2 *)operator new(size: 0x30u); /*0x14109ef92*/
      __wind /*0xf1c00000000000d0*/
      {
        v74 = v27; /*0x14109ef97*/
        if ( v27 != nullptr ) /*0x14109ef9f*/
          v28 = RBX::Network::PhysicsReceiverS2::PhysicsReceiverS2(this: v27, replicator: this, isServer: false); /*0x14109efaf*/
        else
          v28 = nullptr; /*0x14109efb4*/
      }
      __unwind
      {
        operator delete(ptr: v74); /*0x1431eb892*/
      }
      __wind /*0xf1c00000000000e8*/
      {
        v85._Ptr = v28; /*0x14109efb7*/
        v29 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x14109efc0*/
        v74 = v29; /*0x14109efc5*/
        if ( v29 != nullptr ) /*0x14109efcd*/
        {
          *v29 = 0; /*0x14109efd2*/
          v29->_Uses = 1; /*0x14109efd5*/
          v29->_Weaks = 1; /*0x14109efdc*/
          v29->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::PhysicsReceiverS2>::`vftable'; /*0x14109efea*/
          v29[1].__vftable = (std::_Ref_count_base_vtbl *)v28; /*0x14109efed*/
        }
        else
        {
          v29 = nullptr; /*0x14109eff3*/
        }
        this->physicsReceiverS2._Ptr = v28; /*0x14109eff6*/
        v30 = this->physicsReceiverS2._Rep; /*0x14109effd*/
        this->physicsReceiverS2._Rep = v29; /*0x14109f004*/
        if ( v30 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v30->_Uses, 0xFFFFFFFF) == 1 ) /*0x14109f01b*/
        {
          v30->_Destroy(this: v30); /*0x14109f023*/
          if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v30->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14109f030*/
            v30->_Delete_this(this: v30); /*0x14109f038*/
        }
      }
      __unwind
      {
        std::_Temporary_owner<RBX::Network::PhysicsReceiverS2>::~_Temporary_owner<RBX::Network::PhysicsReceiverS2>(this: &v85); /*0xf1c00000000000c8*/
      }
      if ( DFFlag::SimTouchCollector3.value ) /*0x14109f042*/
      {
        RBX::Network::Replicator::getOrCreatePhysicsTouchSerializer(this); /*0x14109f047*/
      }
      else
      {
        v31 = (RBX::Network::PhysicsTouchSerializer *)operator new(size: 0x90u); /*0x14109f056*/
        v74 = v31; /*0x14109f05b*/
        __wind /*0xf1c00000000000b8*/
        {
          if ( v31 != nullptr ) /*0x14109f063*/
            v32 = RBX::Network::PhysicsTouchSerializer::PhysicsTouchSerializer(this: v31, replicator: this); /*0x14109f070*/
          else
            v32 = nullptr; /*0x14109f075*/
        }
        __unwind
        {
          operator delete(ptr: v74); /*0x1431ec062*/
        }
        v86._Ptr = v32; /*0x14109f078*/
        __wind /*0xf1c00000000000a0*/
        {
          v33 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x14109f081*/
          v74 = v33; /*0x14109f086*/
          if ( v33 != nullptr ) /*0x14109f08e*/
          {
            *v33 = 0; /*0x14109f093*/
            v33->_Uses = 1; /*0x14109f096*/
            v33->_Weaks = 1; /*0x14109f09d*/
            v33->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::PhysicsTouchSerializer>::`vftable'; /*0x14109f0ab*/
            v33[1].__vftable = (std::_Ref_count_base_vtbl *)v32; /*0x14109f0ae*/
          }
          else
          {
            v33 = nullptr; /*0x14109f0b4*/
          }
          this->physicsTouchSerializer._Ptr = v32; /*0x14109f0b7*/
          v34 = this->physicsTouchSerializer._Rep; /*0x14109f0be*/
          this->physicsTouchSerializer._Rep = v33; /*0x14109f0c5*/
          if ( v34 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v34->_Uses, 0xFFFFFFFF) == 1 ) /*0x14109f0dc*/
          {
            v34->_Destroy(this: v34); /*0x14109f0e4*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v34->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14109f0f1*/
              v34->_Delete_this(this: v34); /*0x14109f0f9*/
          }
        }
        __unwind
        {
          std::_Temporary_owner<RBX::Network::PhysicsTouchSerializer>::~_Temporary_owner<RBX::Network::PhysicsTouchSerializer>(this: &v86); /*0xf1c0000000000098*/
        }
      }
    }
    streamingEnabled = RBX::Network::NetworkStream::readBool(this: &inBitstream); /*0x14109f105*/
    this->streamingEnabled = streamingEnabled; /*0x14109f108*/
    if ( streamingEnabled ) /*0x14109f110*/
    {
      if ( RBX::Network::StreamingSolver::isSolverEnabled() ) /*0x14109f116*/
      {
        v36 = (RBX::Network::StreamingSolver *)operator new(size: 0x9F8u); /*0x14109f128*/
        v37 = v36; /*0x14109f12d*/
        v74 = v36; /*0x14109f130*/
        __wind /*0xf1c0000000000088*/
        {
          if ( v36 != nullptr ) /*0x14109f138*/
          {
            v38 = RBX::DataModel::get(context: this); /*0x14109f13d*/
            v39 = RBX::Network::StreamingSolver::StreamingSolver(this: v37, dataModel: v38, replicator: this); /*0x14109f14b*/
          }
          else
          {
            v39 = nullptr; /*0x14109f152*/
          }
        }
        __unwind
        {
          operator delete(ptr: v74); /*0x1431ec082*/
        }
        std::shared_ptr<RBX::Network::StreamingSolver>::reset<RBX::Network::StreamingSolver>( /*0x14109f15f*/
          this: &this->streamingSolver,
          _Px: v39);
        if ( FFlag::ModelStreamingMode.value ) /*0x14109f16b*/
          RBX::Network::MegaReplicator::setStreamingSolver(this: this->megaReplicator, solver: &this->streamingSolver); /*0x14109f17b*/
        v78 = 0; /*0x14109f183*/
        v40 = this->streamingSolver._Rep; /*0x14109f189*/
        if ( v40 != nullptr ) /*0x14109f193*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v40->_Uses); /*0x14109f195*/
          v40 = this->streamingSolver._Rep; /*0x14109f199*/
        }
        v78._Ptr = this->streamingSolver._Ptr; /*0x14109f1a7*/
        v78._Rep = v40; /*0x14109f1ac*/
        RBX::TaskScheduler::add(job: &v78); /*0x14109f1b6*/
      }
      v41 = (RBX::Network::ClientReplicator::GCJob *)operator new(size: 0x8A0u); /*0x14109f1c0*/
      v74 = v41; /*0x14109f1c5*/
      __wind /*0xf1c0000000000070*/
      {
        if ( v41 != nullptr ) /*0x14109f1cd*/
          v42 = RBX::Network::ClientReplicator::GCJob::GCJob(this: v41, replicator: this); /*0x14109f1d5*/
        else
          v42 = nullptr; /*0x14109f1dc*/
      }
      __unwind
      {
        operator delete(ptr: v74); /*0x1431ec0a2*/
      }
      std::shared_ptr<RBX::Network::ClientReplicator::GCJob>::reset<RBX::Network::ClientReplicator::GCJob>( /*0x14109f1e9*/
        this: &this->gcJob,
        _Px: v42);
      v79 = 0; /*0x14109f1f1*/
      v43 = this->gcJob._Rep; /*0x14109f1f7*/
      if ( v43 != nullptr ) /*0x14109f201*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v43->_Uses); /*0x14109f203*/
        v43 = this->gcJob._Rep; /*0x14109f207*/
      }
      v79._Ptr = this->gcJob._Ptr; /*0x14109f215*/
      v79._Rep = v43; /*0x14109f21a*/
      RBX::TaskScheduler::add(job: &v79); /*0x14109f224*/
      streamingEnabled = this->streamingEnabled; /*0x14109f229*/
    }
    this->megaReplicator->isStreamingEnabled = streamingEnabled; /*0x14109f237*/
    if ( RBX::Network::NetworkStream::readBool(this: &inBitstream) ) /*0x14109f241*/
    {
      parent = (RBX::ServiceProvider *)this->parent; /*0x14109f24e*/
      if ( parent == nullptr ) /*0x14109f255*/
      {
        parent = (RBX::ServiceProvider *)this; /*0x14109f273*/
LABEL_90:
        descriptor = parent->descriptor; /*0x14109f276*/
        v47 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(); /*0x14109f27a*/
        if ( descriptor->index - (unsigned int)v47->index <= v47->descendantCount ) /*0x14109f298*/
        {
          boost::call_once( /*0x14109f2ac*/
            flag: &`RBX::ServiceProvider::getClassIndex<RBX::Network::Client>'::`2'::flag,
            f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::Network::Client>);
          v48 = RBX::ServiceProvider::doGetClassIndex<RBX::Network::Client>(); /*0x14109f2b1*/
          v49 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt( /*0x14109f2c1*/
                                                                                     this: parent,
                                                                                     index: v48);
          if ( v49->_Ptr == nullptr ) /*0x14109f2c8*/
          {
            v50 = RBX::Reflection::Class_getNamePtr<RBX::Network::Client>(); /*0x14109f2ca*/
            ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName(this: parent, result: &v87, className: v50); /*0x14109f2d9*/
            std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v49, _Right: ServiceByClassName); /*0x14109f2e4*/
            v52 = v87._Rep; /*0x14109f2e9*/
            if ( v87._Rep != nullptr /*0x14109f2fd*/
              && _InterlockedExchangeAdd((volatile signed __int32 *)&v87._Rep->_Uses, 0xFFFFFFFF) == 1 )
            {
              v52->_Destroy(this: v52); /*0x14109f305*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v52->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14109f311*/
                v52->_Delete_this(this: v52); /*0x14109f319*/
            }
          }
          v53 = v49->_Ptr; /*0x14109f31c*/
          if ( v49->_Ptr != nullptr ) /*0x14109f323*/
          {
            v54 = (RBX::Network::StrictNetworkFilter *)operator new(size: 0x78u); /*0x14109f32e*/
            v74 = v54; /*0x14109f336*/
            __wind /*0xf1c0000000000058*/
            {
              if ( v54 != nullptr ) /*0x14109f33e*/
              {
                v80 = 0; /*0x14109f343*/
                Myval2 = (std::_Ref_count_base *)v53[1].onDemandPtr._Mypair._Myval2; /*0x14109f349*/
                if ( Myval2 != nullptr ) /*0x14109f353*/
                {
                  _InterlockedIncrement((volatile signed __int32 *)&Myval2->_Uses); /*0x14109f355*/
                  Myval2 = (std::_Ref_count_base *)v53[1].onDemandPtr._Mypair._Myval2; /*0x14109f359*/
                }
                v80._Ptr = *((RBX::Network::StrictNetworkFilter::WhiteList **)&v53[1].completeness + 1); /*0x14109f367*/
                v80._Rep = Myval2; /*0x14109f36c*/
                v81 = 0; /*0x14109f371*/
                v56 = *(std::_Ref_count_base **)&v53[1].completeness.numLocalReplicatedChildren; /*0x14109f376*/
                if ( v56 != nullptr ) /*0x14109f380*/
                {
                  _InterlockedIncrement((volatile signed __int32 *)&v56->_Uses); /*0x14109f382*/
                  v56 = *(std::_Ref_count_base **)&v53[1].completeness.numLocalReplicatedChildren; /*0x14109f386*/
                }
                v81._Ptr = *(RBX::Network::StrictNetworkFilter::WhiteList **)&v53[1].DEPRECATED_uniqueId.sessionId.timestamp; /*0x14109f394*/
                v81._Rep = v56; /*0x14109f398*/
                v57 = RBX::Network::StrictNetworkFilter::StrictNetworkFilter( /*0x14109f3ab*/
                        this: v54,
                        replicator: this,
                        property: &v81,
                        event: &v80);
              }
              else
              {
                v57 = nullptr; /*0x14109f3b2*/
              }
            }
            __unwind
            {
              operator delete(ptr: v74); /*0x1431c14b2*/
            }
            v58 = this->strictFilter._Mypair._Myval2; /*0x14109f3b5*/
            this->strictFilter._Mypair._Myval2 = v57; /*0x14109f3bc*/
            if ( v58 != nullptr ) /*0x14109f3c6*/
              RBX::Network::StrictNetworkFilter::`scalar deleting destructor'(this: v58, a2: 1u); /*0x14109f3cd*/
          }
        }
        goto LABEL_107; /*0x14109f3cd*/
      }
      v45 = parent->parent; /*0x14109f257*/
      if ( v45 != nullptr ) /*0x14109f25e*/
        parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v45); /*0x14109f265*/
      if ( parent != nullptr ) /*0x14109f26b*/
        goto LABEL_90; /*0x14109f26b*/
    }
LABEL_107:
    v75._Ptr = (RBX::Network::PhysicsSenderS2 *)RBX::ServiceProvider::find<RBX::Workspace>(context: this); /*0x14109f3d2*/
    v59 = RBX::Network::NetworkStream::readBool(this: &inBitstream); /*0x14109f3e8*/
    v60 = RBX::Network::NetworkStream::readBool(this: &inBitstream); /*0x14109f3f5*/
    v61 = RBX::Network::NetworkStream::readBool(this: &inBitstream); /*0x14109f402*/
    RootAncestor = (RBX::ServiceProvider *)this->parent; /*0x14109f406*/
    if ( RootAncestor != nullptr ) /*0x14109f40d*/
    {
      v63 = RootAncestor->parent; /*0x14109f40f*/
      if ( v63 != nullptr ) /*0x14109f416*/
        RootAncestor = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v63); /*0x14109f41d*/
      if ( RootAncestor == nullptr ) /*0x14109f423*/
        goto LABEL_115; /*0x14109f423*/
    }
    else
    {
      RootAncestor = (RBX::ServiceProvider *)this; /*0x14109f427*/
    }
    v64 = RootAncestor->descriptor; /*0x14109f42a*/
    v65 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(); /*0x14109f42e*/
    if ( v64->index - (unsigned int)v65->index <= v65->descendantCount ) /*0x14109f44f*/
      v21 = RBX::ServiceProvider::create<RBX::PermissionsService>(this: RootAncestor); /*0x14109f459*/
LABEL_115:
    RBX::PermissionsService::setThirdPartyAssetAllowed(this: v21, value: v59); /*0x14109f45c*/
    RBX::PermissionsService::setThirdPartyPurchaseAllowed(this: v21, value: v60); /*0x14109f46f*/
    RBX::PermissionsService::setThirdPartyTeleportAllowed(this: v21, value: v61); /*0x14109f47b*/
    v66 = RBX::Network::NetworkStream::readBool(this: &inBitstream); /*0x14109f484*/
    players = this->players; /*0x14109f489*/
    if ( players != nullptr ) /*0x14109f493*/
      RBX::Players::setCharacterAutoSpawnProperty(this: players, value: v66); /*0x14109f498*/
    RBX::Network::deserializeUnsignedVarint(value: &newPeerId, stream: &inBitstream); /*0x14109f4a6*/
    if ( FLog::Network != 0 ) /*0x14109f4b4*/
      FLog::FastLog( /*0x14109f4c2*/
        level: FLog::Network,
        message: "[FLog::Network] Assigned peer id = %u",
        arg0: (const void *)newPeerId);
    *(_DWORD *)(*(_QWORD *)&v75._Ptr[3].nextIndex + 1816LL) = newPeerId; /*0x14109f4d7*/
    v68 = newPeerId; /*0x14109f4dd*/
    this->localPeerId = newPeerId; /*0x14109f4e1*/
    RBX::Network::MegaReplicator::setReplicatingPeerId(this: this->megaReplicator, newPeerId: v68); /*0x14109f4ee*/
    v69 = newPeerId; /*0x14109f4f3*/
    this->serverAssignedPeerId.peerId = newPeerId; /*0x14109f4f7*/
    this->clientAddress.remoteId.peerId = v69; /*0x14109f4fd*/
    RBX::Network::Replicator::schemaReadTopReplicationContainerStateFromStream( /*0x14109f50d*/
      this,
      bitStream: &inBitstream,
      shallCreateMRD: true);
    this->nextCommonItemId = 2; /*0x14109f512*/
    this->receivedGlobals = true; /*0x14109f51d*/
    rbx::signal<void (void)>::operator()(this: &this->receivedGlobalsSignal); /*0x14109f52b*/
    ++this->megaReplicator->joinedReplicatorCount; /*0x14109f537*/
    this->hasCompletedJoinSnapshot = true; /*0x14109f53d*/
    if ( DFFlag::DebugAvatarProfilerCallers.value ) /*0x14109f54b*/
    {
      v70 = RBX::Time::nowFastSec(); /*0x14109f54d*/
      RBX::AvatarProfiler::logNetGlobalsReceived(applyDuration: v70 - v10); /*0x14109f556*/
    }
    RBX::Network::Replicator::enableDeserializePacketsJob(this); /*0x14109f55e*/
    if ( __eh34_unwind(1) ) /*0xf1c0000000000038*/
    {
unwind_state_1:
      RBX::Network::NetworkStream::~NetworkStream(this: &inBitstream); /*0xf1c000000000003c*/
      __eh34_propagate_exception_into_caller(1, -1); /*0xf1c0000000000040*/
    }
    __eh34_exit_wind_state(1, -1); /*0xf1c0000000000044*/
    Myfirst = inBitstream.dataVector._Mypair._Myval2._Myfirst; /*0x14109f564*/
    if ( inBitstream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x14109f56b*/
    {
      if ( (unsigned __int8 *)(inBitstream.dataVector._Mypair._Myval2._Myend /*0x14109f57e*/
                             - inBitstream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 )
      {
        Myfirst = *((unsigned __int8 **)inBitstream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x14109f584*/
        if ( (unsigned __int64)(inBitstream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x14109f593*/
          _invalid_parameter_noinfo_noreturn(); /*0x14109f595*/
      }
      operator delete(ptr: Myfirst); /*0x14109f59c*/
    }
    p_bitSize = v76; /*0x14109f5a1*/
    v5 = result; /*0x14109f5a6*/
    v4 = packet; /*0x14109f5ad*/
    goto LABEL_128; /*0x14109f5ad*/
  }
  if ( *data != 151 ) /*0x14109ed49*/
  {
    RBX::Network::Replicator::processPacket(this, result: v5, packet, offset); /*0x14109ed51*/
    return v5; /*0x14109ed56*/
  }
  p_bitSize = &packet->length; /*0x14109ed5b*/
  RBX::Network::NetworkStream::NetworkStream( /*0x14109ed69*/
    this: &bitStream,
    _data: data,
    lengthInBytes: packet->length,
    copyData: false);
  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000158*/
  RBX::Network::MegaReplicator::initializeSharedNetworkSchema(this: this->megaReplicator, networkStream: &bitStream); /*0x14109ed7a*/
  if ( __eh34_unwind(0) ) /*0xf1c0000000000144*/
    goto unwind_state_0; /*0xf1c0000000000144*/
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000150*/
  v9 = bitStream.dataVector._Mypair._Myval2._Myfirst; /*0x14109ed80*/
  if ( bitStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x14109ed87*/
  {
    if ( (unsigned __int8 *)(bitStream.dataVector._Mypair._Myval2._Myend - bitStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x14109ed9e*/
    {
      v9 = *((unsigned __int8 **)bitStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x14109eda4*/
      if ( (unsigned __int64)(bitStream.dataVector._Mypair._Myval2._Myfirst - v9 - 8) > 0x1F ) /*0x14109edb3*/
        _invalid_parameter_noinfo_noreturn(); /*0x14109edb5*/
    }
    operator delete(ptr: v9); /*0x14109edbc*/
  }
LABEL_128:
  if ( !this->refactorReceiveQueueCached ) /*0x14109f5bf*/
    p_bitSize = &v4->bitSize; /*0x14109f5bf*/
  v5->first = *p_bitSize; /*0x14109f5c6*/
  v5->second = false; /*0x14109f5c9*/
  return v5; /*0x14109f5d0*/
}

// Address: 0x14109f600 | Name: ?processPacketLimitReached@ClientReplicator@Network@RBX@@MEAA_NAEBV?$Timer@$0A@@3@@Z
bool __fastcall RBX::Network::ClientReplicator::processPacketLimitReached(
        RBX::Network::ClientReplicator *this,
        const RBX::Timer<0> *stepTimer)
{
  return !this->gameIsLoaded && RBX::Network::Replicator::joinProcessingTimeLimitReached(this) /*0x14109f624*/
      || RBX::Network::Replicator::processPacketLimitReached(this, stepTimer);
}

// Address: 0x14109f650 | Name: ?processTag@ClientReplicator@Network@RBX@@IEAAXW4TagItemType@23@@Z
// local variable allocation has failed, the output may be wrong!
void __fastcall RBX::Network::ClientReplicator::processTag(
        RBX::Network::ClientReplicator *this,
        RBX::Network::TagItemType tag)
{
  unsigned int v4; // r15d
  RBX::ServiceProvider *parent; // rbx
  RBX::Instance *v6; // rcx
  const RBX::Reflection::ClassDescriptor *descriptor; // rdi
  RBX::Reflection::ClassDescriptor *v8; // rax
  unsigned __int64 v9; // rax
  RBX::DescribedCreatable<RBX::ReplicatedFirst,RBX::ServiceInstance> *v10; // rcx
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v11; // rsi
  const RBX::Name *ClassName; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *Rep; // rdi
  unsigned __int64 v15; // rax
  RBX::AvatarProfiler *v16; // rcx
  boost::unordered::detail::ptr_bucket *i; // rdi
  std::string *Ptr; // rax
  char *v19; // rcx
  boost::unordered::detail::ptr_bucket *next; // rsi
  boost::unordered::detail::ptr_bucket *j; // r15
  std::string *FullName; // rax
  const char *v23; // rbx
  std::string *v24; // rax
  char *v25; // rcx
  char *v26; // rcx
  boost::unordered::detail::ptr_bucket *k; // rdi
  Luau::InternalErrorReporter *v28; // rbx
  std::_Func_base<void,char const *>_vtbl *v29; // rdi
  RBX::Network::Client *v30; // rbx
  const RBX::Reflection::ClassDescriptor *v31; // rdi
  RBX::ClassRegistrar<RBX::Network::Client,1> *v32; // rax
  RBX::DataModel *v33; // rax
  const char *v34; // rdx
  const char *v35; // r9
  RBX::DataModel *v36; // rdi
  long double v37; // xmm0_8
  void *v38; // rcx
  RBX::DataModel *v39; // rdi
  RBX::Network::ClientReplicator::GCJob *v40; // rcx
  RBX::Player *v41; // rdi
  std::_Ref_count_base *v42; // rdx
  RBX::Network::ClientReplicator::GCJob *v43; // rax
  RBX::Network::StreamingInterface *v44; // rcx
  _WORD *v45; // rax
  RBX::Network::JoinRxStats::BigInstance *Mylast; // rbx
  std::string *v47; // rax
  std::string *v48; // r9
  char *v49; // rcx
  RBX::Network::JoinRxStats::BigInstance *Myfirst; // rdi
  RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount> *Buckets; // rdi
  RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount> *v52; // rbx
  std::pair<RBX::Reflection::ClassDescriptor const *,float> *v53; // rdx
  const unsigned int *p_size; // r9
  unsigned __int64 Myres; // rcx
  char *v56; // rdi
  char *v57; // rdi
  int v58; // ebx
  float *v59; // rsi
  float *v60; // rdi
  double v61; // xmm2_8
  const char *v62; // r9
  const char *v63; // r8
  void *v64; // rcx
  char *v65; // rcx
  char *v66; // rax
  RBX::Network::JoinDiagnosticStats_DEPRECATED::BigInstance *v67; // rbx
  std::string *v68; // rax
  std::string *v69; // r9
  char *v70; // rcx
  RBX::Network::JoinDiagnosticStats_DEPRECATED::BigInstance *v71; // rdi
  unsigned __int64 count; // rdx
  unsigned __int64 v73; // rdi
  std::pair<RBX::Reflection::ClassDescriptor const *,float> *v74; // rax
  unsigned __int64 v75; // rsi
  std::optional<Luau::TypeVar const *> *v76; // r10
  std::pair<RBX::Reflection::ClassDescriptor const *,float> *v77; // r8
  const float *p_second; // r9
  std::pair<RBX::Reflection::ClassDescriptor const *,float> *v79; // rax
  const RBX::Reflection::ClassDescriptor **p_first; // rcx
  unsigned __int64 Mysize; // rcx
  RBX::Graphics::ProfilerAdorn::Item *p_str; // rdi
  char *v83; // rdi
  int v84; // ebx
  std::optional<Luau::TypeVar const *> *v85; // rsi
  float *v86; // rdi
  double v87; // xmm2_8
  const char *v88; // r9
  RBX::Graphics::ProfilerAdorn::Item *v89; // r8
  std::optional<Luau::TypeVar const *> *v90; // rcx
  RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount> > *p_joinBreakdown; // rdx
  unsigned int NumEntries; // eax
  __int64 NumBuckets; // rcx
  RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount> *v94; // rax
  __int64 v95; // rcx
  RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount> > *p_replicatedFirstBreakdown; // rdx
  unsigned int v97; // eax
  __int64 v98; // rcx
  RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount> *v99; // rax
  __int64 v100; // rcx
  RBX::Network::JoinRxStats::BigInstance *v101; // rbx
  RBX::Network::JoinRxStats::BigInstance *v102; // rdi
  RBX::Network::JoinDiagnosticStats_DEPRECATED::BigInstance *v103; // rbx
  RBX::Network::JoinDiagnosticStats_DEPRECATED::BigInstance *v104; // rdi
  unsigned __int64 v105; // rcx
  std::_List_node<std::pair<std::string const ,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> > >,void *> *Myhead; // rcx
  std::_List_node<std::pair<std::string const ,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> > >,void *> *v107; // rsi
  std::_List_node<std::pair<std::string const ,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> > >,void *> *v108; // rbx
  std::_List_unchecked_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> > > > > > *v109; // rdi
  unsigned __int64 v110; // rcx
  RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> > *p_avatarInstancesBreakdown; // rdx
  unsigned int v112; // eax
  __int64 v113; // rcx
  RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> *v114; // rax
  __int64 v115; // rcx
  rbx::signals::scoped_connection *v116; // rbx
  rbx::signals::scoped_connection *v117; // rdi
  volatile signed __int32 *v118; // rcx
  __int64 v119; // rcx
  _BYTE v120[32]; // [rsp+8h] [rbp-100h] BYREF
  std::string message; // [rsp+30h] [rbp-D8h] BYREF
  unsigned __int64 v122; // [rsp+50h] [rbp-B8h]
  RBX::Graphics::ProfilerAdorn::Item str; // [rsp+58h] [rbp-B0h] BYREF
  std::vector<std::optional<Luau::TypeVar const *>> v124; // [rsp+90h] [rbp-78h] BYREF
  _BYTE v125[40]; // [rsp+A8h] [rbp-60h] OVERLAPPED BYREF
  RBX::Profiler::Scope profscope1788; // [rsp+D0h] [rbp-38h] BYREF
  unsigned __int64 enterTimestamp; // [rsp+E0h] [rbp-28h]
  std::string v128; // [rsp+E8h] [rbp-20h] BYREF
  std::shared_ptr<RBX::Instance> result; // [rsp+108h] [rbp+0h] BYREF
  RakNet::RakNetGUID v130; // [rsp+118h] [rbp+10h] BYREF
  RakNet::SystemAddress v131; // [rsp+128h] [rbp+20h] BYREF
  std::string v132; // [rsp+148h] [rbp+40h] BYREF
  std::string v133; // [rsp+168h] [rbp+60h] BYREF
  std::string v134; // [rsp+188h] [rbp+80h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v135; // [rsp+1A8h] [rbp+A0h] BYREF
  RBX::Network::ClientReplicator::processTag::__l83::<lambda_e0880f3bf3bcde72bc3819cd4f24be59> v136; // [rsp+230h] [rbp+128h]
  std::optional<int> placeSizeInBytes; // [rsp+238h] [rbp+130h]
  RBX::Time v138; // [rsp+240h] [rbp+138h] BYREF

  v4 = tls_index; /*0x14109f683*/
  if ( tag == REPLICATED_FIRST_FINISHED_TAG ) /*0x14109f68e*/
  {
    if ( this != nullptr ) /*0x14109f697*/
    {
      parent = (RBX::ServiceProvider *)this->parent; /*0x14109f69d*/
      if ( parent != nullptr ) /*0x14109f6a4*/
      {
        v6 = parent->parent; /*0x14109f6a6*/
        if ( v6 != nullptr ) /*0x14109f6ad*/
          parent = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v6); /*0x14109f6b4*/
      }
      else
      {
        parent = (RBX::ServiceProvider *)this; /*0x14109f6b9*/
      }
      if ( parent != nullptr ) /*0x14109f6bf*/
      {
        descriptor = parent->descriptor; /*0x14109f6c5*/
        v8 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(); /*0x14109f6c9*/
        if ( descriptor->index - (unsigned int)v8->index <= v8->descendantCount ) /*0x14109f6e7*/
        {
          boost::call_once( /*0x14109f6fb*/
            flag: &`RBX::ServiceProvider::getClassIndex<RBX::ReplicatedFirst>'::`2'::flag,
            f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::ReplicatedFirst>);
          v9 = RBX::ServiceProvider::doGetClassIndex<RBX::ReplicatedFirst>(); /*0x14109f700*/
          v11 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt( /*0x14109f710*/
                                                                                     this: parent,
                                                                                     index: v9);
          if ( v11->_Ptr == nullptr ) /*0x14109f717*/
          {
            ClassName = RBX::DescribedCreatable<RBX::ReplicatedFirst,RBX::ServiceInstance>::getClassName(this: v10); /*0x14109f719*/
            ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName(this: parent, &result, className: ClassName); /*0x14109f728*/
            std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v11, _Right: ServiceByClassName); /*0x14109f733*/
            Rep = result._Rep; /*0x14109f738*/
            if ( result._Rep != nullptr /*0x14109f752*/
              && _InterlockedExchangeAdd((volatile signed __int32 *)&result._Rep->_Uses, 0xFFFFFFFF) == 1 )
            {
              Rep->_Destroy(this: Rep); /*0x14109f75a*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14109f766*/
                Rep->_Delete_this(this: Rep); /*0x14109f76e*/
            }
          }
          if ( v11->_Ptr != nullptr ) /*0x14109f777*/
            RBX::ReplicatedFirst::setAllInstancesHaveReplicated(this: (RBX::ReplicatedFirst *)v11->_Ptr); /*0x14109f779*/
        }
      }
    }
    if ( DFFlag::ClientReportJoinInstanceTypeBreakdown2.value ) /*0x14109f785*/
      this->replicatedFirstFinished = true; /*0x14109f78b*/
    goto LABEL_260; /*0x14109f793*/
  }
  if ( tag != TOP_REPLICATION_CONTAINER_FINISHED_TAG ) /*0x14109f79c*/
    goto LABEL_260; /*0x14109f79c*/
  if ( _TSS0_534 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x14109f7be*/
  {
    Init_thread_header(pOnce: &_TSS0_534); /*0x1410a094a*/
    if ( _TSS0_534 == -1 ) /*0x1410a0956*/
    {
      __wind /*0xf1c0000000000034*/
      {
        proftoken1788 = RBX::Profiler::getToken(group: "Network", name: "GameLoad", color: -1); /*0x1410a0972*/
        Init_thread_footer(pOnce: &_TSS0_534); /*0x1410a0980*/
      }
      __unwind
      {
        Init_thread_abort(pOnce: &_TSS0_534); /*0x1431ec0e7*/
      }
    }
  }
  profscope1788.region.timestamp = proftoken1788; /*0x14109f7cb*/
  v15 = RBX::Profiler::enterRegion(token: proftoken1788); /*0x14109f7cf*/
  __wind
  {
    enterTimestamp = v15; /*0x14109f7d4*/
    this->joinRxStats.gameLoadedTagInfo.beginProcessingCycle = RBX::TaskScheduler::cycle(); /*0x14109f7dd*/
    this->joinRxStats.gameLoadedTagInfo.beginProcessingTime = RakNet::GetTimeMS(); /*0x14109f7e9*/
    if ( DFFlag::DebugAvatarProfilerCallers.value ) /*0x14109f7f7*/
      RBX::AvatarProfiler::logNetReplicationCompleted(this: v16); /*0x14109f7f9*/
    if ( DFLog::ReplicationDataCaching != 0 )
    {
      if ( DFFlag::DontEnforceChildOrderAtJoin.value && this->childrenWaitingForTheirTurn.table_.size_ != 0 )
      {
        FLog::FastLog( /*0x14109f834*/
          level: DFLog::ReplicationDataCaching,
          message: "[DFLog::ReplicationDataCaching] childrenWaitingForTheirTurn Not empty at the end of Join. Dumping items in the"
          " map. Assert coming up...",
          arg0: nullptr);
        if ( this->childrenWaitingForTheirTurn.table_.size_ != 0 )
        {
          for ( i = this->childrenWaitingForTheirTurn.table_.buckets_[this->childrenWaitingForTheirTurn.table_.bucket_count_].next_;
                i != nullptr;
                i = i->next_ )
          {
            if ( DFLog::ReplicationDataCaching != 0 )
            {
              Ptr = RBX::Guid::toString(this: (RBX::Guid *)&i[2], result: &v132); /*0x14109f872*/
              __wind
              {
                if ( Ptr->_Mypair._Myval2._Myres >= 0x10 ) /*0x14109f87d*/
                  Ptr = (std::string *)Ptr->_Mypair._Myval2._Bx._Ptr; /*0x14109f87f*/
                FLog::FastLogFormatted(
                  level: DFLog::ReplicationDataCaching,
                  message: "[DFLog::ReplicationDataCaching] Parent Key : %s",
                  Ptr->_Mypair._Myval2._Bx._Buf);
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v132); /*0xf1c0000000000174*/
              }
              if ( v132._Mypair._Myval2._Myres >= 0x10 ) /*0x14109f8a1*/
              {
                v19 = v132._Mypair._Myval2._Bx._Ptr; /*0x14109f8a6*/
                if ( v132._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109f8b4*/
                {
                  v19 = *((char **)v132._Mypair._Myval2._Bx._Ptr - 1); /*0x14109f8ba*/
                  if ( (unsigned __int64)(v132._Mypair._Myval2._Bx._Ptr - v19 - 8) > 0x1F ) /*0x14109f8c9*/
                    _invalid_parameter_noinfo_noreturn(); /*0x14109fbf0*/
                }
                operator delete(ptr: v19); /*0x14109f8cf*/
              }
            }
            next = i[3].next_; /*0x14109f8d4*/
            for ( j = i[4].next_; next != j; next += 18 ) /*0x14109f8df*/
            {
              if ( DFLog::ReplicationDataCaching != 0 ) /*0x14109f8f7*/
              {
                FullName = RBX::Instance::getFullName(this: (RBX::Instance *)next[10].next_, result: &v133); /*0x14109f905*/
                v23 = (const char *)FullName; /*0x14109f90a*/
                __eh34_enter_wind_state(1, 3); /*0xf1c0000000000168*/
                if ( FullName->_Mypair._Myval2._Myres >= 0x10 ) /*0x14109f912*/
                  v23 = FullName->_Mypair._Myval2._Bx._Ptr; /*0x14109f914*/
                v24 = RBX::Guid::toString(this: (RBX::Guid *)&next[10].next_[6], result: &v128); /*0x14109f923*/
                __wind /*0xf1c000000000015c*/
                {
                  if ( v24->_Mypair._Myval2._Myres >= 0x10 ) /*0x14109f92e*/
                    v24 = (std::string *)v24->_Mypair._Myval2._Bx._Ptr; /*0x14109f930*/
                  FLog::FastLogFormatted( /*0x14109f947*/
                    level: DFLog::ReplicationDataCaching,
                    message: "[DFLog::ReplicationDataCaching]     Instance %s[%s]",
                    v24->_Mypair._Myval2._Bx._Buf,
                    v23);
                }
                __unwind
                {
                  RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v128); /*0xf1c0000000000154*/
                }
                if ( v128._Mypair._Myval2._Myres < 0x10 ) /*0x14109f955*/
                {
                  if ( __eh34_unwind(3) ) /*0xf1c0000000000130*/
                  {
unwind_state_3:
                    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v133); /*0xf1c0000000000134*/
                    __eh34_continue_unwinding(3, 1); /*0xf1c0000000000138*/
                  }
                  __eh34_exit_wind_state(3, 1); /*0xf1c000000000013c*/
                }
                else
                {
                  if ( __eh34_unwind(3) ) /*0xf1c0000000000144*/
                    goto unwind_state_3; /*0xf1c0000000000144*/
                  __eh34_exit_wind_state(3, 1); /*0xf1c0000000000148*/
                  v25 = v128._Mypair._Myval2._Bx._Ptr; /*0x14109f95a*/
                  if ( v128._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109f968*/
                  {
                    v25 = *((char **)v128._Mypair._Myval2._Bx._Ptr - 1); /*0x14109f96e*/
                    if ( (unsigned __int64)(v128._Mypair._Myval2._Bx._Ptr - v25 - 8) > 0x1F ) /*0x14109f97d*/
                      _invalid_parameter_noinfo_noreturn(); /*0x14109fbf7*/
                  }
                  operator delete(ptr: v25); /*0x14109f983*/
                }
                v128._Mypair._Myval2._Mysize = 0; /*0x14109f988*/
                v128._Mypair._Myval2._Myres = 15; /*0x14109f990*/
                v128._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14109f998*/
                if ( v133._Mypair._Myval2._Myres >= 0x10 ) /*0x14109f9a4*/
                {
                  v26 = v133._Mypair._Myval2._Bx._Ptr; /*0x14109f9a9*/
                  if ( v133._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109f9b7*/
                  {
                    v26 = *((char **)v133._Mypair._Myval2._Bx._Ptr - 1); /*0x14109f9bd*/
                    if ( (unsigned __int64)(v133._Mypair._Myval2._Bx._Ptr - v26 - 8) > 0x1F ) /*0x14109f9cc*/
                      _invalid_parameter_noinfo_noreturn(); /*0x14109fbfe*/
                  }
                  operator delete(ptr: v26); /*0x14109f9d2*/
                }
              }
            }
          }
        }
      }
      if ( DFLog::ReplicationDataCaching != 0 /*0x14109fa20*/
        && !DFFlag::DontEnforceChildOrderAtJoin.value
        && !RBX::Network::Replicator::getJDIv2NoOrderInfo(this)
        && this->orderedChildrenWaitingForTheirTurn_deprecated.table_.size_ != 0 )
      {
        if ( DFLog::ReplicationDataCaching == 0 /*0x14109fa44*/
          || (FLog::FastLog(
                level: DFLog::ReplicationDataCaching,
                message: "[DFLog::ReplicationDataCaching] orderedChildrenWaitingForTheirTurn Not empty at the end of Join. Dumping"
                " items in the map. Assert coming up...",
                arg0: nullptr),
              this->orderedChildrenWaitingForTheirTurn_deprecated.table_.size_ != 0) )
        {
          for ( k = this->orderedChildrenWaitingForTheirTurn_deprecated.table_.buckets_[this->orderedChildrenWaitingForTheirTurn_deprecated.table_.bucket_count_].next_; /*0x14109fa5b*/
                k != nullptr;
                k = k->next_ )
          {
            RBX::Network::ClientReplicator::LogInstancesDroppedFromJoin( /*0x14109fa6b*/
              this,
              parentGuid: (const RBX::Guid *)&k[2],
              children: (RBX::Network::ChildrenWithParentOrder *)&k[3]);
          }
        }
      }
    }
    v28 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x14109fa84*/
    v29 = v28->onInternalError._Mystorage._Ptrs[0][89].__vftable; /*0x14109fa8a*/
    RakNet::RakNetGUID::RakNetGUID(this: &v130); /*0x14109fa95*/
    RakNet::SystemAddress::SystemAddress(this: &v131); /*0x14109fa9e*/
    v130 = RakNet::UNASSIGNED_RAKNET_GUID_22; /*0x14109faaa*/
    RakNet::SystemAddress::operator=(this: &v131, input: &this->remotePlayerRakNetAddress); /*0x14109fac4*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, RakNet::RakNetGUID *, _QWORD))v29)(a1: v28, a2: &v130, a3: 0); /*0x14109fad3*/
    v30 = (RBX::Network::Client *)this->parent; /*0x14109fad5*/
    if ( v30 != nullptr ) /*0x14109fadc*/
    {
      v31 = v30->descriptor; /*0x14109fae2*/
      v32 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(); /*0x14109fae6*/
      if ( v31->index - (unsigned int)v32->desc.index <= v32->desc.descendantCount ) /*0x14109fb04*/
      {
        RBX::Network::Client::getConnectedServer(this: v30, result: (std::string *)&v125[16]); /*0x14109fb11*/
        __wind /*0xf1c0000000000124*/
        {
          v33 = RBX::DataModel::get(context: v30); /*0x14109fb1a*/
          if ( v33 != nullptr && &v33->joinData.dataCenter != (std::string *)&v125[16] ) /*0x14109fb32*/
          {
            v34 = &v125[16]; /*0x14109fb34*/
            if ( profscope1788.region.token >= 0x10 ) /*0x14109fb3d*/
              v34 = *(const char **)&v125[16]; /*0x14109fb3d*/
            std::string::assign( /*0x14109fb46*/
              this: &v33->joinData.dataCenter,
              _Ptr: v34,
              _Count: *(const unsigned __int64 *)&v125[32]);
          }
          v35 = &v125[16]; /*0x14109fb4b*/
          if ( profscope1788.region.token >= 0x10 ) /*0x14109fb54*/
            v35 = *(const char **)&v125[16]; /*0x14109fb54*/
          RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x14109fb73*/
            this: v30,
            metric: "FinishedReceivingInitialGameData",
            connectionFailed: false,
            serverAddress: v35,
            state: ConnectionState_Connected,
            takeLock: true);
          RBX::Network::Client::setJoinStateFinishedReceivingInitialGameData(this: v30); /*0x14109fb7b*/
          v36 = RBX::DataModel::get(context: v30); /*0x14109fb88*/
          v37 = RBX::Time::nowFast(result: &v138)->sec - v36->joinData.clientStartTime.sec; /*0x14109fb9b*/
          RBX::DataModel::get(context: v30)->joinData.initialGameDataTime = v37; /*0x14109fbaf*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v125[16]); /*0xf1c000000000011c*/
        }
        if ( profscope1788.region.token >= 0x10 ) /*0x14109fbbf*/
        {
          v38 = *(void **)&v125[16]; /*0x14109fbc4*/
          if ( profscope1788.region.token + 1 >= 0x1000 ) /*0x14109fbd2*/
          {
            v38 = *(void **)(*(_QWORD *)&v125[16] - 8LL); /*0x14109fbd8*/
            if ( (unsigned __int64)(*(_QWORD *)&v125[16] - (_QWORD)v38 - 8LL) > 0x1F ) /*0x14109fbe7*/
              _invalid_parameter_noinfo_noreturn(); /*0x14109fbe9*/
          }
          operator delete(ptr: v38); /*0x14109fc05*/
        }
      }
    }
    v39 = RBX::DataModel::get(context: this); /*0x14109fc12*/
    if ( v39 != nullptr ) /*0x14109fc18*/
    {
      placeSizeInBytes._Has_value = true; /*0x14109fc1a*/
      if ( DFFlag::ClientReportJoinInstanceTypeBreakdown2.value ) /*0x14109fc28*/
        placeSizeInBytes._Value = this->joinRxStats.totalInstanceBytesRxInJoin /*0x14109fc38*/
                                + this->joinRxStats.totalCompressedTerrainBytes;
      else
        placeSizeInBytes._Value = this->joinDiagnosticStats_DEPRECATED.totalCompressedInstanceBytes /*0x14109fc4e*/
                                + this->joinDiagnosticStats_DEPRECATED.totalCompressedTerrainBytes;
      RBX::DataModel::gameDmIsLoaded(this: v39, placeSizeInBytes); /*0x14109fc5e*/
    }
    this->processAllPacketsPerStep = false; /*0x14109fc63*/
    rbx::signal<void (void)>::operator()(this: &this->gameLoadedSignal); /*0x14109fc72*/
    this->gameIsLoaded = true; /*0x14109fc77*/
    RBX::Network::ClientReplicator::prepareJoinRxDataStats(this); /*0x14109fc82*/
    v40 = this->gcJob._Ptr; /*0x14109fc87*/
    if ( v40 != nullptr ) /*0x14109fc91*/
    {
      RBX::Network::ClientReplicator::GCJob::setReadyToWork(this: v40); /*0x14109fc93*/
      v41 = this->findTargetPlayer(this); /*0x14109fca4*/
      *(_OWORD *)v125 = 0; /*0x14109fcaa*/
      v42 = this->gcJob._Rep; /*0x14109fcaf*/
      if ( v42 != nullptr ) /*0x14109fcb9*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v42->_Uses); /*0x14109fcbb*/
        v42 = this->gcJob._Rep; /*0x14109fcbf*/
      }
      v43 = this->gcJob._Ptr; /*0x14109fcc6*/
      v44 = &v43->RBX::Network::StreamingInterface; /*0x14109fccd*/
      if ( v43 == nullptr ) /*0x14109fcd7*/
        v44 = nullptr; /*0x14109fcd7*/
      *(_QWORD *)v125 = v44; /*0x14109fcdb*/
      *(_QWORD *)&v125[8] = v42; /*0x14109fcdf*/
      RBX::Player::setStreamingInterface(this: v41, provider: (std::shared_ptr<RBX::Network::StreamingInterface> *)v125); /*0x14109fcea*/
    }
    if ( DFFlag::ServerCopiesPlayerGui3.value ) /*0x14109fcf6*/
      this->findTargetPlayer(this)->isServerCopyingGui = (this->peerCapability & 0x40) != 0; /*0x14109fd12*/
    this->canTimeout = !this->acceptsStudioClients(this); /*0x14109fd29*/
    this->replicatorStats.lastReceivedPingTime = (unsigned int)RakNet::GetTimeMS(); /*0x14109fd37*/
    if ( !this->networkSettings->printJoinSizeBreakdown ) /*0x14109fd4c*/
      goto LABEL_207; /*0x14109fd4c*/
    if ( DFFlag::ClientReportJoinInstanceTypeBreakdown2.value )
    {
      v45 = operator new(size: 0x20u); /*0x14109fd7c*/
      message._Mypair._Myval2._Myres = 25; /*0x14109fd81*/
      v122 = 31; /*0x14109fd8a*/
      qmemcpy(v45, "\n === Join Completed ===", 24); /*0x14109fd9a*/
      v45[12] = (unsigned __int8)aJoinCompleted[24]; /*0x14109fdb1*/
      *(_QWORD *)&message._Mypair._Myval2._Bx._Alias[8] = v45; /*0x14109fdb8*/
      __wind
      {
        RBX::append_format( /*0x14109fdd0*/
          str: (std::string *)&message._Mypair._Myval2._Bx._Alias[8],
          fmt: "Top %d Instances by Size:\n",
          DFInt::ReplicatorJoinDiagnosticLargeInstancesToKeep);
        Myfirst = this->joinRxStats.bigInstances._Mypair._Myval2._Myfirst; /*0x14109fdd5*/
        Mylast = this->joinRxStats.bigInstances._Mypair._Myval2._Mylast; /*0x14109fddc*/
        while ( Myfirst != Mylast ) /*0x14109fdee*/
        {
          v47 = RBX::Instance::getFullName(this: Myfirst->instance._Ptr, result: &v134); /*0x14109fdff*/
          v48 = v47; /*0x14109fe04*/
          __wind /*0xf1c0000000000100*/
          {
            if ( v47->_Mypair._Myval2._Myres >= 0x10 ) /*0x14109fe0c*/
              v48 = (std::string *)v47->_Mypair._Myval2._Bx._Ptr; /*0x14109fe0e*/
            RBX::append_format( /*0x14109fe46*/
              str: (std::string *)&message._Mypair._Myval2._Bx._Alias[8],
              fmt: "%.3f%% %s\n",
              (float)((float)((float)(int)Myfirst->size * 100.0)
                    / (float)(int)this->joinRxStats.totalInstanceBytesRxInJoin),
              v48);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v134); /*0xf1c00000000000f8*/
          }
          if ( v134._Mypair._Myval2._Myres >= 0x10 ) /*0x14109fe57*/
          {
            v49 = v134._Mypair._Myval2._Bx._Ptr; /*0x14109fe5c*/
            if ( v134._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14109fe6d*/
            {
              v49 = *((char **)v134._Mypair._Myval2._Bx._Ptr - 1); /*0x14109fe73*/
              if ( (unsigned __int64)(v134._Mypair._Myval2._Bx._Ptr - v49 - 8) > 0x1F ) /*0x14109fe82*/
                _invalid_parameter_noinfo_noreturn(); /*0x14109fe92*/
            }
            operator delete(ptr: v49); /*0x14109fe84*/
          }
          ++Myfirst; /*0x14109fe89*/
        }
        __wind
        {
          memset(&str.x, 0, 24); /*0x14109fe9c*/
          if ( this->joinRxStats.joinBreakdown.NumEntries != 0 ) /*0x14109feb0*/
            std::vector<RBX::ChunkResult>::_Reallocate_exactly( /*0x14109feb7*/
              this: (std::vector<std::optional<Luau::TypeVar const *>> *)&str.x,
              _Newcapacity: this->joinRxStats.joinBreakdown.NumEntries);
          Buckets = this->joinRxStats.joinBreakdown.Buckets; /*0x14109febc*/
          v52 = &Buckets[this->joinRxStats.joinBreakdown.NumBuckets]; /*0x14109fece*/
          if ( this->joinRxStats.joinBreakdown.NumEntries == 0 || Buckets == v52 ) /*0x14109fee2*/
            goto LABEL_126; /*0x14109fee2*/
          do /*0x14109ff08*/
          {
            if ( ((unsigned __int64)&Buckets->first[8].eventDescriptors.descriptorAddedCallback._Mystorage._Ptrs[1] /*0x14109feff*/
                & 0xFFFFFFFFFFFFEFFFuLL) != 0 )
              break; /*0x14109feff*/
            ++Buckets; /*0x14109ff01*/
          }
          while ( Buckets != v52 ); /*0x14109ff08*/
          if ( Buckets == v52 ) /*0x14109ff0d*/
          {
LABEL_126:
            v53 = *(std::pair<RBX::Reflection::ClassDescriptor const *,float> **)&str.width; /*0x14109ff81*/
          }
          else
          {
            v53 = *(std::pair<RBX::Reflection::ClassDescriptor const *,float> **)&str.width; /*0x14109ff0f*/
            do /*0x14109ff7d*/
            {
              p_size = &Buckets->second.size; /*0x14109ff14*/
              if ( v53 == *(std::pair<RBX::Reflection::ClassDescriptor const *,float> **)&str.color ) /*0x14109ff1c*/
              {
                std::vector<std::pair<RBX::Reflection::ClassDescriptor const *,float>>::_Emplace_reallocate<RBX::Reflection::ClassDescriptor const * const &,unsigned int const &>( /*0x14109ff4c*/
                  this: (std::vector<std::pair<RBX::Reflection::ClassDescriptor const *,float>> *)&str.x,
                  _Whereptr: v53,
                  <_Val_0>: &Buckets->first,
                  <_Val_1>: p_size);
                v53 = *(std::pair<RBX::Reflection::ClassDescriptor const *,float> **)&str.width; /*0x14109ff51*/
              }
              else
              {
                v53->first = Buckets->first; /*0x14109ff21*/
                v53->second = (float)*(int *)p_size; /*0x14109ff2f*/
                v53 = (std::pair<RBX::Reflection::ClassDescriptor const *,float> *)(*(_QWORD *)&str.width + 16LL); /*0x14109ff39*/
                *(_QWORD *)&str.width += 16LL; /*0x14109ff3d*/
              }
              if ( ++Buckets == v52 ) /*0x14109ff5d*/
                break; /*0x14109ff5d*/
              do /*0x14109ff78*/
              {
                if ( ((unsigned __int64)&Buckets->first[8].eventDescriptors.descriptorAddedCallback._Mystorage._Ptrs[1] /*0x14109ff6f*/
                    & 0xFFFFFFFFFFFFEFFFuLL) != 0 )
                  break; /*0x14109ff6f*/
                ++Buckets; /*0x14109ff71*/
              }
              while ( Buckets != v52 ); /*0x14109ff78*/
            }
            while ( Buckets != v52 ); /*0x14109ff7d*/
          }
          std::_Sort_unchecked_std::pair_RBX::Reflection::ClassDescriptor_const___float_____lambda_e0880f3bf3bcde72bc3819cd4f24be59___( /*0x14109ff9d*/
            _First: *(std::pair<RBX::Reflection::ClassDescriptor const *,float> **)&str.x,
            _Last: v53,
            _Ideal: ((__int64)v53 - *(_QWORD *)&str.x) >> 4,
            _Pred: v136);
          Myres = message._Mypair._Myval2._Myres; /*0x14109ffa2*/
          if ( v122 - message._Mypair._Myval2._Myres < 0x31 ) /*0x14109ffb6*/
          {
            std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x1410a000a*/
              this: (std::string *)&message._Mypair._Myval2._Bx._Alias[8],
              _Size_increase: 0x31u,
              _Fn: 0,
              <_Args_0>: "\nTransmission Size By Type (% of Instance Data):\n",
              <_Args_1>: 0x31u);
          }
          else
          {
            message._Mypair._Myval2._Myres += 49LL; /*0x14109ffbc*/
            v56 = &message._Mypair._Myval2._Bx._Buf[8]; /*0x14109ffc1*/
            if ( v122 >= 0x10 ) /*0x14109ffca*/
              v56 = *(char **)&message._Mypair._Myval2._Bx._Alias[8]; /*0x14109ffca*/
            v57 = &v56[Myres]; /*0x14109ffd0*/
            memmove_0(a1: v57, Src: "\nTransmission Size By Type (% of Instance Data):\n", Size: 0x31u); /*0x14109ffe3*/
            v57[49] = 0; /*0x14109ffe8*/
          }
          v58 = 0; /*0x1410a000f*/
          v59 = *(float **)&str.width; /*0x1410a0012*/
          v60 = *(float **)&str.x; /*0x1410a0017*/
          if ( *(_QWORD *)&str.x != *(_QWORD *)&str.width ) /*0x1410a001f*/
          {
            do /*0x1410a0087*/
            {
              v61 = (float)((float)(v60[2] * 100.0) / (float)(int)this->joinRxStats.totalInstanceBytesRxInJoin); /*0x1410a004c*/
              if ( v61 >= 0.1 ) /*0x1410a0053*/
              {
                v62 = *(const char **)(*(_QWORD *)v60 + 8LL); /*0x1410a005c*/
                if ( *((_QWORD *)v62 + 3) >= 0x10u ) /*0x1410a0065*/
                  v62 = *(const char **)v62; /*0x1410a0067*/
                RBX::append_format( /*0x1410a007b*/
                  str: (std::string *)&message._Mypair._Myval2._Bx._Alias[8],
                  fmt: "%.3f%% %s\n",
                  v61,
                  v62);
              }
              else
              {
                ++v58; /*0x1410a0055*/
              }
              v60 += 4; /*0x1410a0080*/
            }
            while ( v60 != v59 ); /*0x1410a0087*/
            if ( v58 != 0 ) /*0x1410a008b*/
              RBX::append_format( /*0x1410a009c*/
                str: (std::string *)&message._Mypair._Myval2._Bx._Alias[8],
                fmt: "[Skipped %d types with < 0.1%%]\n",
                v58);
          }
          RBX::append_format(
            str: (std::string *)&message._Mypair._Myval2._Bx._Alias[8],
            fmt: "\nTotal Transmitted Join Bytes (Instance + Terrain) : %u (%u + %u)",
            this->joinRxStats.totalInstanceBytesRxInJoin + this->joinRxStats.totalCompressedTerrainBytes,
            this->joinRxStats.totalInstanceBytesRxInJoin,
            this->joinRxStats.totalCompressedTerrainBytes);
          v63 = &message._Mypair._Myval2._Bx._Buf[8]; /*0x1410a00c8*/
          if ( v122 >= 0x10 ) /*0x1410a00d3*/
            v63 = *(const char **)&message._Mypair._Myval2._Bx._Alias[8]; /*0x1410a00d3*/
          RBX::StandardOut::printf(type: MESSAGE_INFO, format: "%s", v63); /*0x1410a00e5*/
        }
        __unwind
        {
          std::vector<Luau::Location>::~vector<Luau::Location>(this: (RBX::DenseHashMap<RBX::Graphics::ShaderProgram *,VkPipeline_T *,boost::hash<RBX::Graphics::ShaderProgram *>,std::equal_to<RBX::Graphics::ShaderProgram *> > *)&str.x); /*0xf1c00000000000e0*/
        }
        v64 = *(void **)&str.x; /*0x1410a00eb*/
        if ( *(_QWORD *)&str.x != 0 ) /*0x1410a00f3*/
        {
          if ( ((*(_QWORD *)&str.color - *(_QWORD *)&str.x) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x1410a010a*/
          {
            v64 = *(void **)(*(_QWORD *)&str.x - 8LL); /*0x1410a0110*/
            if ( (unsigned __int64)(*(_QWORD *)&str.x - (_QWORD)v64 - 8LL) > 0x1F ) /*0x1410a011f*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410a0121*/
          }
          operator delete(ptr: v64); /*0x1410a0128*/
          memset(&str.x, 0, 24); /*0x1410a0130*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&message._Mypair._Myval2._Bx._Alias[8]); /*0xf1c00000000000d4*/
      }
      if ( v122 < 0x10 ) /*0x1410a0143*/
        goto LABEL_207; /*0x1410a0143*/
      v65 = *(char **)&message._Mypair._Myval2._Bx._Alias[8]; /*0x1410a014c*/
      if ( v122 + 1 >= 0x1000 ) /*0x1410a015b*/
      {
        v65 = *(char **)(*(_QWORD *)&message._Mypair._Myval2._Bx._Alias[8] - 8LL); /*0x1410a0165*/
        if ( (unsigned __int64)(*(_QWORD *)&message._Mypair._Myval2._Bx._Alias[8] - (_QWORD)v65 - 8LL) > 0x1F ) /*0x1410a0174*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410a017a*/
      }
    }
    else
    {
      str.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410a0181*/
      str.text._Mypair._Myval2._Mysize = 0; /*0x1410a0186*/
      str.text._Mypair._Myval2._Myres = 15; /*0x1410a018b*/
      v66 = (char *)operator new(size: 0x20u); /*0x1410a0199*/
      __wind
      {
        str.text._Mypair._Myval2._Mysize = 25; /*0x1410a019e*/
        str.text._Mypair._Myval2._Myres = 31; /*0x1410a01a7*/
        strcpy(v66, "\n === Join Completed ===\n"); /*0x1410a01b7*/
        str.text._Mypair._Myval2._Bx._Ptr = v66; /*0x1410a01d5*/
        RBX::append_format( /*0x1410a01ed*/
          str: &str.text,
          fmt: "Top %d Instances by Size:\n",
          DFInt::ReplicatorJoinDiagnosticLargeInstancesToKeep);
        v71 = this->joinDiagnosticStats_DEPRECATED.bigInstances._Mypair._Myval2._Myfirst; /*0x1410a01f2*/
        v67 = this->joinDiagnosticStats_DEPRECATED.bigInstances._Mypair._Myval2._Mylast; /*0x1410a01f9*/
        while ( v71 != v67 ) /*0x1410a020b*/
        {
          v68 = RBX::Instance::getFullName(this: v71->instance._Ptr, result: &v135.text); /*0x1410a021c*/
          v69 = v68; /*0x1410a0221*/
          __wind /*0xf1c00000000000b8*/
          {
            if ( v68->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410a0229*/
              v69 = (std::string *)v68->_Mypair._Myval2._Bx._Ptr; /*0x1410a022b*/
            RBX::append_format( /*0x1410a025d*/
              str: &str.text,
              fmt: "%.3f%% %s\n",
              (float)((float)(v71->size * 100.0)
                    / (float)(int)this->joinDiagnosticStats_DEPRECATED.totalCompressedInstanceBytes),
              v69);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v135); /*0xf1c00000000000b0*/
          }
          if ( v135.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a026e*/
          {
            v70 = v135.text._Mypair._Myval2._Bx._Ptr; /*0x1410a0273*/
            if ( v135.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a0284*/
            {
              v70 = *((char **)v135.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a028a*/
              if ( (unsigned __int64)(v135.text._Mypair._Myval2._Bx._Ptr - v70 - 8) > 0x1F ) /*0x1410a0299*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410a02a9*/
            }
            operator delete(ptr: v70); /*0x1410a029b*/
          }
          ++v71; /*0x1410a02a0*/
        }
        __wind
        {
          memset(&v124, 0, sizeof(v124)); /*0x1410a02b3*/
          count = this->joinDiagnosticStats_DEPRECATED.compressedBytesByClass.impl.count; /*0x1410a02bc*/
          if ( count != 0 ) /*0x1410a02c6*/
          {
            if ( count > 0xFFFFFFFFFFFFFFFLL ) /*0x1410a02d5*/
              std::vector<Luau::AstNode *>::_Xlength(); /*0x1410a098a*/
            std::vector<RBX::ChunkResult>::_Reallocate_exactly(this: &v124, _Newcapacity: count); /*0x1410a02df*/
          }
          v73 = 0; /*0x1410a02e4*/
          v74 = this->joinDiagnosticStats_DEPRECATED.compressedBytesByClass.impl.data._Mypair._Myval2._Myfirst; /*0x1410a02e7*/
          v75 = this->joinDiagnosticStats_DEPRECATED.compressedBytesByClass.impl.data._Mypair._Myval2._Mylast - v74; /*0x1410a02f8*/
          if ( v75 != 0 ) /*0x1410a02ff*/
          {
            do /*0x1410a0317*/
            {
              if ( v74->first != this->joinDiagnosticStats_DEPRECATED.compressedBytesByClass.impl.empty_key ) /*0x1410a030b*/
                break; /*0x1410a030b*/
              ++v73; /*0x1410a030d*/
              ++v74; /*0x1410a0310*/
            }
            while ( v73 < v75 ); /*0x1410a0317*/
          }
          v76 = v124._Mypair._Myval2._Mylast; /*0x1410a0319*/
          while ( v73 != v75 ) /*0x1410a0323*/
          {
            v77 = &this->joinDiagnosticStats_DEPRECATED.compressedBytesByClass.impl.data._Mypair._Myval2._Myfirst[v73]; /*0x1410a0333*/
            p_second = &v77->second; /*0x1410a0336*/
            if ( v76 == v124._Mypair._Myval2._Myend ) /*0x1410a033e*/
            {
              std::vector<std::pair<RBX::Reflection::ClassDescriptor const *,float>>::_Emplace_reallocate<RBX::Reflection::ClassDescriptor const * const &,float const &>( /*0x1410a0362*/
                this: (std::vector<std::pair<RBX::Reflection::ClassDescriptor const *,float>> *)&v124,
                _Whereptr: (std::pair<RBX::Reflection::ClassDescriptor const *,float> *const)v76,
                <_Val_0>: &v77->first,
                <_Val_1>: p_second);
              v76 = v124._Mypair._Myval2._Mylast; /*0x1410a0367*/
            }
            else
            {
              v76->_Value = (const Luau::TypeVar *)v77->first; /*0x1410a0343*/
              *(float *)&v76->_Has_value = *p_second; /*0x1410a0349*/
              v76 = ++v124._Mypair._Myval2._Mylast; /*0x1410a0351*/
            }
            v79 = this->joinDiagnosticStats_DEPRECATED.compressedBytesByClass.impl.data._Mypair._Myval2._Myfirst; /*0x1410a036b*/
            p_first = &v79[v73].first; /*0x1410a0380*/
            do /*0x1410a039a*/
            {
              ++v73; /*0x1410a0384*/
              p_first += 2; /*0x1410a0387*/
            }
            while ( v73 < this->joinDiagnosticStats_DEPRECATED.compressedBytesByClass.impl.data._Mypair._Myval2._Mylast /*0x1410a039a*/
                        - v79
                 && *p_first == this->joinDiagnosticStats_DEPRECATED.compressedBytesByClass.impl.empty_key );
          }
          std::_Sort_unchecked_std::pair_RBX::Reflection::ClassDescriptor_const___float_____lambda_e0880f3bf3bcde72bc3819cd4f24be59___( /*0x1410a03b7*/
            _First: (std::pair<RBX::Reflection::ClassDescriptor const *,float> *)v124._Mypair._Myval2._Myfirst,
            _Last: (std::pair<RBX::Reflection::ClassDescriptor const *,float> *)v76,
            _Ideal: v76 - v124._Mypair._Myval2._Myfirst,
            _Pred: v136);
          Mysize = str.text._Mypair._Myval2._Mysize; /*0x1410a03bc*/
          if ( str.text._Mypair._Myval2._Myres - str.text._Mypair._Myval2._Mysize < 0x31 ) /*0x1410a03d0*/
          {
            std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x1410a0424*/
              this: &str.text,
              _Size_increase: 0x31u,
              _Fn: 0,
              <_Args_0>: "\nTransmission Size By Type (% of Instance Data):\n",
              <_Args_1>: 0x31u);
          }
          else
          {
            str.text._Mypair._Myval2._Mysize += 49LL; /*0x1410a03d6*/
            p_str = &str; /*0x1410a03db*/
            if ( str.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a03e4*/
              p_str = (RBX::Graphics::ProfilerAdorn::Item *)str.text._Mypair._Myval2._Bx._Ptr; /*0x1410a03e4*/
            v83 = &p_str->text._Mypair._Myval2._Bx._Buf[Mysize]; /*0x1410a03ea*/
            memmove_0(a1: v83, Src: "\nTransmission Size By Type (% of Instance Data):\n", Size: 0x31u); /*0x1410a03fd*/
            v83[49] = 0; /*0x1410a0402*/
          }
          v84 = 0; /*0x1410a0429*/
          v85 = v124._Mypair._Myval2._Mylast; /*0x1410a042c*/
          v86 = (float *)v124._Mypair._Myval2._Myfirst; /*0x1410a0430*/
          if ( v124._Mypair._Myval2._Myfirst != v124._Mypair._Myval2._Mylast ) /*0x1410a0437*/
          {
            do /*0x1410a04a7*/
            {
              v87 = (float)((float)(v86[2] * 100.0) /*0x1410a046c*/
                          / (float)(int)this->joinDiagnosticStats_DEPRECATED.totalCompressedInstanceBytes);
              if ( v87 >= 0.1 ) /*0x1410a0473*/
              {
                v88 = *(const char **)(*(_QWORD *)v86 + 8LL); /*0x1410a047c*/
                if ( *((_QWORD *)v88 + 3) >= 0x10u ) /*0x1410a0485*/
                  v88 = *(const char **)v88; /*0x1410a0487*/
                RBX::append_format(str: &str.text, fmt: "%.3f%% %s\n", v87, v88); /*0x1410a049b*/
              }
              else
              {
                ++v84; /*0x1410a0475*/
              }
              v86 += 4; /*0x1410a04a0*/
            }
            while ( v86 != (float *)v85 ); /*0x1410a04a7*/
            if ( v84 != 0 ) /*0x1410a04ab*/
              RBX::append_format(str: &str.text, fmt: "[Skipped %d types with < 0.1%%]\n", v84); /*0x1410a04bc*/
          }
          RBX::append_format(
            str: &str.text,
            fmt: "\nTotal Transmitted Join Bytes (Instance + Terrain) : %u (%u + %u)",
            this->joinDiagnosticStats_DEPRECATED.totalCompressedTerrainBytes
          + this->joinDiagnosticStats_DEPRECATED.totalCompressedInstanceBytes,
            this->joinDiagnosticStats_DEPRECATED.totalCompressedInstanceBytes,
            this->joinDiagnosticStats_DEPRECATED.totalCompressedTerrainBytes);
          v89 = &str; /*0x1410a04e8*/
          if ( str.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a04f3*/
            v89 = (RBX::Graphics::ProfilerAdorn::Item *)str.text._Mypair._Myval2._Bx._Ptr; /*0x1410a04f3*/
          RBX::StandardOut::printf(type: MESSAGE_INFO, format: "%s", v89->text._Mypair._Myval2._Bx._Buf); /*0x1410a0505*/
        }
        __unwind
        {
          std::vector<Luau::Location>::~vector<Luau::Location>(this: (RBX::DenseHashMap<RBX::Graphics::ShaderProgram *,VkPipeline_T *,boost::hash<RBX::Graphics::ShaderProgram *>,std::equal_to<RBX::Graphics::ShaderProgram *> > *)&v124); /*0xf1c0000000000098*/
        }
        v90 = v124._Mypair._Myval2._Myfirst; /*0x1410a050b*/
        if ( v124._Mypair._Myval2._Myfirst != nullptr ) /*0x1410a0512*/
        {
          if ( (((char *)v124._Mypair._Myval2._Myend - (char *)v124._Mypair._Myval2._Myfirst) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x1410a0529*/
          {
            v90 = *(std::optional<Luau::TypeVar const *> **)&v124._Mypair._Myval2._Myfirst[-1]._Has_value; /*0x1410a052f*/
            if ( (unsigned __int64)((char *)v124._Mypair._Myval2._Myfirst - (char *)v90 - 8) > 0x1F ) /*0x1410a053e*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410a0540*/
          }
          operator delete(ptr: v90); /*0x1410a0547*/
          memset(&v124, 0, sizeof(v124)); /*0x1410a054f*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: &str); /*0xf1c000000000008c*/
      }
      if ( str.text._Mypair._Myval2._Myres < 0x10 ) /*0x1410a0561*/
        goto LABEL_207; /*0x1410a0561*/
      v65 = str.text._Mypair._Myval2._Bx._Ptr; /*0x1410a0566*/
      if ( str.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a0575*/
      {
        v65 = *((char **)str.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a057b*/
        if ( (unsigned __int64)(str.text._Mypair._Myval2._Bx._Ptr - v65 - 8) > 0x1F ) /*0x1410a058a*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410a058c*/
      }
    }
    operator delete(ptr: v65); /*0x1410a0593*/
LABEL_207:
    if ( DFFlag::ClientReportJoinInstanceTypeBreakdown2.value ) /*0x1410a059f*/
    {
      p_joinBreakdown = &this->joinRxStats.joinBreakdown; /*0x1410a05a5*/
      NumEntries = this->joinRxStats.joinBreakdown.NumEntries; /*0x1410a05ac*/
      if ( NumEntries != 0 || this->joinRxStats.joinBreakdown.NumTombstones != 0 ) /*0x1410a05b6*/
      {
        NumBuckets = this->joinRxStats.joinBreakdown.NumBuckets; /*0x1410a05b8*/
        if ( 4 * NumEntries >= (unsigned int)NumBuckets || (unsigned int)NumBuckets <= 0x40 ) /*0x1410a05c9*/
        {
          v94 = p_joinBreakdown->Buckets; /*0x1410a05d5*/
          v95 = (__int64)&p_joinBreakdown->Buckets[NumBuckets]; /*0x1410a05dc*/
          if ( p_joinBreakdown->Buckets != (RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount> *)v95 ) /*0x1410a05e2*/
          {
            do /*0x1410a05fe*/
            {
              v94->first = (const RBX::Reflection::ClassDescriptor *)-4096LL; /*0x1410a05f0*/
              ++v94; /*0x1410a05f7*/
            }
            while ( v94 != (RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount> *)v95 ); /*0x1410a05fe*/
          }
          *(_QWORD *)&this->joinRxStats.joinBreakdown.NumEntries = 0; /*0x1410a0600*/
        }
        else
        {
          RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount>>::shrink_and_clear(this: &this->joinRxStats.joinBreakdown); /*0x1410a05ce*/
        }
      }
      p_replicatedFirstBreakdown = &this->joinRxStats.replicatedFirstBreakdown; /*0x1410a0608*/
      v97 = this->joinRxStats.replicatedFirstBreakdown.NumEntries; /*0x1410a060f*/
      if ( v97 != 0 || this->joinRxStats.replicatedFirstBreakdown.NumTombstones != 0 ) /*0x1410a0619*/
      {
        v98 = this->joinRxStats.replicatedFirstBreakdown.NumBuckets; /*0x1410a061b*/
        if ( 4 * v97 >= (unsigned int)v98 || (unsigned int)v98 <= 0x40 ) /*0x1410a062c*/
        {
          v99 = p_replicatedFirstBreakdown->Buckets; /*0x1410a0638*/
          v100 = (__int64)&p_replicatedFirstBreakdown->Buckets[v98]; /*0x1410a063f*/
          if ( p_replicatedFirstBreakdown->Buckets != (RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount> *)v100 ) /*0x1410a0645*/
          {
            do /*0x1410a065e*/
            {
              v99->first = (const RBX::Reflection::ClassDescriptor *)-4096LL; /*0x1410a0650*/
              ++v99; /*0x1410a0657*/
            }
            while ( v99 != (RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount> *)v100 ); /*0x1410a065e*/
          }
          *(_QWORD *)&this->joinRxStats.replicatedFirstBreakdown.NumEntries = 0; /*0x1410a0660*/
        }
        else
        {
          RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount>>::shrink_and_clear(this: &this->joinRxStats.replicatedFirstBreakdown); /*0x1410a0631*/
        }
      }
      v101 = this->joinRxStats.bigInstances._Mypair._Myval2._Mylast; /*0x1410a0668*/
      v102 = this->joinRxStats.bigInstances._Mypair._Myval2._Myfirst; /*0x1410a066f*/
      if ( v102 != v101 ) /*0x1410a0679*/
      {
        do /*0x1410a0690*/
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v102->instance); /*0x1410a0684*/
          ++v102; /*0x1410a0689*/
        }
        while ( v102 != v101 ); /*0x1410a0690*/
        v102 = this->joinRxStats.bigInstances._Mypair._Myval2._Myfirst; /*0x1410a0692*/
      }
      this->joinRxStats.bigInstances._Mypair._Myval2._Mylast = v102; /*0x1410a0699*/
    }
    else
    {
      v103 = this->joinDiagnosticStats_DEPRECATED.bigInstances._Mypair._Myval2._Mylast; /*0x1410a06a2*/
      v104 = this->joinDiagnosticStats_DEPRECATED.bigInstances._Mypair._Myval2._Myfirst; /*0x1410a06a9*/
      if ( v104 != v103 ) /*0x1410a06b3*/
      {
        do /*0x1410a06c5*/
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v104->instance); /*0x1410a06b9*/
          ++v104; /*0x1410a06be*/
        }
        while ( v104 != v103 ); /*0x1410a06c5*/
        v104 = this->joinDiagnosticStats_DEPRECATED.bigInstances._Mypair._Myval2._Myfirst; /*0x1410a06c7*/
      }
      this->joinDiagnosticStats_DEPRECATED.bigInstances._Mypair._Myval2._Mylast = v104; /*0x1410a06ce*/
      this->joinDiagnosticStats_DEPRECATED.compressedBytesByClass.impl.data._Mypair._Myval2._Mylast = this->joinDiagnosticStats_DEPRECATED.compressedBytesByClass.impl.data._Mypair._Myval2._Myfirst; /*0x1410a06dc*/
      this->joinDiagnosticStats_DEPRECATED.compressedBytesByClass.impl.count = 0; /*0x1410a06e3*/
      *(_QWORD *)&this->joinDiagnosticStats_DEPRECATED.totalCompressedInstanceBytes = 0; /*0x1410a06ea*/
    }
    if ( DFFlag::ClientReportJoinInstanceTypeBreakdown2.value ) /*0x1410a06fc*/
      this->topReplicationContainerFinished = true; /*0x1410a06fe*/
    if ( DFFlag::ReportTopReplicationContainerAndAvatarStats.value ) /*0x1410a070d*/
    {
      v105 = this->joinRxStats.topReplicationContainerBreakdown._List._Mypair._Myval2._Mysize; /*0x1410a071a*/
      if ( v105 != 0 ) /*0x1410a0721*/
      {
        if ( this->joinRxStats.topReplicationContainerBreakdown._Maxidx >> 3 <= v105 ) /*0x1410a0732*/
        {
          Myhead = this->joinRxStats.topReplicationContainerBreakdown._List._Mypair._Myval2._Myhead; /*0x1410a0748*/
          Myhead->_Prev->_Next = nullptr; /*0x1410a0753*/
          v107 = Myhead->_Next; /*0x1410a0756*/
          if ( Myhead->_Next != nullptr ) /*0x1410a075c*/
          {
            do /*0x1410a0788*/
            {
              v108 = v107->_Next; /*0x1410a0760*/
              operator delete(ptr: v107->_Myval.second.Buckets); /*0x1410a0767*/
              RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v107->_Myval); /*0x1410a0770*/
              operator delete(ptr: v107); /*0x1410a077d*/
              v107 = v108; /*0x1410a0782*/
            }
            while ( v108 != nullptr ); /*0x1410a0788*/
          }
          this->joinRxStats.topReplicationContainerBreakdown._List._Mypair._Myval2._Myhead->_Next = this->joinRxStats.topReplicationContainerBreakdown._List._Mypair._Myval2._Myhead; /*0x1410a0791*/
          this->joinRxStats.topReplicationContainerBreakdown._List._Mypair._Myval2._Myhead->_Prev = this->joinRxStats.topReplicationContainerBreakdown._List._Mypair._Myval2._Myhead; /*0x1410a0798*/
          this->joinRxStats.topReplicationContainerBreakdown._List._Mypair._Myval2._Mysize = 0; /*0x1410a079c*/
          v109 = this->joinRxStats.topReplicationContainerBreakdown._Vec._Mypair._Myval2._Myfirst; /*0x1410a07a0*/
          v110 = (unsigned __int64)((char *)this->joinRxStats.topReplicationContainerBreakdown._Vec._Mypair._Myval2._Mylast /*0x1410a07af*/
                                  - (char *)v109
                                  + 7) >> 3;
          if ( v109 > this->joinRxStats.topReplicationContainerBreakdown._Vec._Mypair._Myval2._Mylast ) /*0x1410a07b7*/
            v110 = 0; /*0x1410a07b7*/
          if ( v110 != 0 ) /*0x1410a07be*/
            memset64( /*0x1410a07c4*/
              v109,
              (unsigned __int64)this->joinRxStats.topReplicationContainerBreakdown._List._Mypair._Myval2._Myhead,
              v110);
        }
        else
        {
          std::_Hash<std::_Umap_traits<std::string,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int>>,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,unsigned int,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int>>>>,0>>::_Unchecked_erase( /*0x1410a0741*/
            this: &this->joinRxStats.topReplicationContainerBreakdown,
            _First: this->joinRxStats.topReplicationContainerBreakdown._List._Mypair._Myval2._Myhead->_Next,
            _Last: this->joinRxStats.topReplicationContainerBreakdown._List._Mypair._Myval2._Myhead);
        }
      }
      p_avatarInstancesBreakdown = &this->joinRxStats.avatarInstancesBreakdown; /*0x1410a07c7*/
      v112 = this->joinRxStats.avatarInstancesBreakdown.NumEntries; /*0x1410a07ce*/
      if ( v112 != 0 || this->joinRxStats.avatarInstancesBreakdown.NumTombstones != 0 ) /*0x1410a07d8*/
      {
        v113 = this->joinRxStats.avatarInstancesBreakdown.NumBuckets; /*0x1410a07da*/
        if ( 4 * v112 >= (unsigned int)v113 || (unsigned int)v113 <= 0x40 ) /*0x1410a07eb*/
        {
          v114 = p_avatarInstancesBreakdown->Buckets; /*0x1410a07f7*/
          v115 = (__int64)&p_avatarInstancesBreakdown->Buckets[v113]; /*0x1410a07fe*/
          if ( p_avatarInstancesBreakdown->Buckets != (RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> *)v115 ) /*0x1410a0804*/
          {
            do /*0x1410a081e*/
            {
              v114->first = (const RBX::Reflection::ClassDescriptor *)-4096LL; /*0x1410a0810*/
              ++v114; /*0x1410a0817*/
            }
            while ( v114 != (RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,unsigned int> *)v115 ); /*0x1410a081e*/
          }
          *(_QWORD *)&this->joinRxStats.avatarInstancesBreakdown.NumEntries = 0; /*0x1410a0820*/
        }
        else
        {
          RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount>>::shrink_and_clear(this: (RBX::DenseMap<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount,RBX::DenseMapInfo<RBX::Reflection::ClassDescriptor const *>,RBX::detail::DenseMapPair<RBX::Reflection::ClassDescriptor const *,RBX::Network::JoinRxStats::ClassSizeAndCount> > *)&this->joinRxStats.avatarInstancesBreakdown); /*0x1410a07f0*/
        }
      }
      v116 = this->joinRxStats.topReplicationContainerAndAvatarDescendantAddedSignals._Mypair._Myval2._Mylast; /*0x1410a0828*/
      v117 = this->joinRxStats.topReplicationContainerAndAvatarDescendantAddedSignals._Mypair._Myval2._Myfirst; /*0x1410a082f*/
      if ( v117 != v116 ) /*0x1410a0839*/
      {
        do /*0x1410a086a*/
        {
          __wind /*0xf1c000000000007c*/
          {
            rbx::signals::connection::disconnect(this: &v117->con); /*0x1410a0843*/
            v118 = (volatile signed __int32 *)&v117->con.weak_slot.p_->rbx::intrusive_ptr_target<rbx::signals::slot_base>; /*0x1410a0848*/
            if ( v117->con.weak_slot.p_ != nullptr && _InterlockedExchangeAdd(v118 + 1, 0xFFFFFFFF) == 1 ) /*0x1410a085b*/
              operator delete(ptr: (void *)v118); /*0x1410a085d*/
          }
          __unwind
          {
            __std_terminate(a1: v118, a2: v120); /*0x142f39fa8*/
          }
          ++v117; /*0x1410a0863*/
        }
        while ( v117 != v116 ); /*0x1410a086a*/
        v117 = this->joinRxStats.topReplicationContainerAndAvatarDescendantAddedSignals._Mypair._Myval2._Myfirst; /*0x1410a086c*/
      }
      this->joinRxStats.topReplicationContainerAndAvatarDescendantAddedSignals._Mypair._Myval2._Mylast = v117; /*0x1410a0873*/
    }
  }
  __unwind
  {
    RBX::Profiler::Scope::~Scope(this: (RBX::Profiler::Scope *)&profscope1788.region.timestamp); /*0xf1c0000000000198*/
  }
  __wind /*0xf1c00000000001a0*/
  {
    RBX::Profiler::leaveRegion(token: profscope1788.region.timestamp, enterTimestamp); /*0x1410a0882*/
    v4 = tls_index; /*0x1410a0888*/
  }
  __unwind
  {
    __std_terminate(a1: v119, a2: v120); /*0xf1c000000000002c*/
  }
LABEL_260:
  if ( (FFlag::DebugClientDumpMicroprofileForJoins.value /*0x1410a08ab*/
     || RBX::Analytics::InfluxDb::canSend(throttleHundredthsPercentage: DFInt::ClientReportInitExpJobStatsHundredthPercent))
    && tag == TOP_REPLICATION_CONTAINER_FINISHED_TAG )
  {
    if ( _TSS10_3 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + v4) + 260LL) ) /*0x1410a08cb*/
    {
      Init_thread_header(pOnce: &_TSS10_3); /*0x1410a0914*/
      if ( _TSS10_3 == -1 ) /*0x1410a0920*/
      {
        __wind /*0xf1c0000000000058*/
        {
          proflabeltoken_44 = RBX::Profiler::getLabelToken(group: "Network"); /*0x1410a092e*/
        }
        __unwind
        {
          Init_thread_abort(pOnce: &_TSS10_3); /*0x1431ec107*/
        }
        Init_thread_footer(pOnce: &_TSS10_3); /*0x1410a093c*/
      }
    }
    RBX::Profiler::addLabel(token: proflabeltoken_44, name: "GameLoaded"); /*0x1410a08db*/
    RBX::Network::ClientReplicator::prepareDumpOrReportProfile(this); /*0x1410a08e3*/
  }
}

// Address: 0x1410a0f60 | Name: ?readAttributeVersionInfo@ClientReplicator@Network@RBX@@UEAAXAEAVNetworkStream@23@AEAUChangeVersionInfo@23@@Z
void __fastcall RBX::Network::ClientReplicator::readAttributeVersionInfo(
        RBX::Network::ClientReplicator *this,
        RBX::Network::NetworkStream *bitStream,
        RBX::Network::ChangeVersionInfo *out)
{
  if ( (this->peerCapability & 2) != 0 && this->isCloudEdit(this) ) /*0x1410a0f80*/
    out->versionReset = RBX::Network::NetworkStream::readBool(this: bitStream); /*0x1410a0f92*/
}

// Address: 0x1410a0fa0 | Name: ?readChangedAttributeItem@ClientReplicator@Network@RBX@@UEAAXPEAVDeserializedChangeAttributeItem@23@@Z
void __fastcall RBX::Network::ClientReplicator::readChangedAttributeItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedChangeAttributeItem *item)
{
  RBX::Instance *Ptr; // rbp
  bool versionReset; // bl
  rtc::webrtc_checks_impl::ToStringVal *v6; // rax
  const RBX::Network::Sync::AttributeKey *v7; // rax
  rtc::webrtc_checks_impl::ToStringVal v8; // [rsp+20h] [rbp-58h] BYREF
  RBX::Network::Sync::AttributeKey v9; // [rsp+40h] [rbp-38h] BYREF

  if ( (this->peerCapability & 2) != 0 && this->isCloudEdit(this) ) /*0x1410a0fc5*/
  {
    Ptr = item->instance._Ptr; /*0x1410a0fcf*/
    if ( Ptr == nullptr ) /*0x1410a0fd6*/
      return; /*0x1410a0fd6*/
    versionReset = item->versionInfo.versionReset; /*0x1410a0fe4*/
    v6 = std::string::string(this: &v8, __that: (const rtc::webrtc_checks_impl::ToStringVal *)&item->name); /*0x1410a0ff0*/
    v7 = RBX::Network::Sync::AttributeKey::AttributeKey(this: &v9, instance: Ptr, name: &v6->val); /*0x1410a1000*/
    RBX::Network::Sync::Slave<RBX::Network::Sync::AttributeKey>::slaveOnReceivedChanged( /*0x1410a1013*/
      this: &this->attrSync,
      key: v7,
      versionReset);
  }
  RBX::Network::Replicator::readChangedAttributeItem(this, item); /*0x1410a1026*/
}

// Address: 0x1410a1040 | Name: ?readChangedPropertyItem@ClientReplicator@Network@RBX@@MEAAXPEAVDeserializedChangePropertyItem@23@VProperty@3@@Z
void __fastcall RBX::Network::ClientReplicator::readChangedPropertyItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedChangePropertyItem *item,
        RBX::Property *prop)
{
  unsigned __int64 networkId; // r13
  RBX::Instance *Ptr; // rdi
  RBX::ModelInstance *v7; // r15
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const ,RBX::Network::PropSync::detail::MasterItem> >,RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::MasterItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey> > > *p_map; // rcx
  RBX::Guid v9; // r12
  __int64 guid; // rax
  boost::unordered::detail::ptr_node<std::pair<RBX::Network::PropSync::detail::PropertyKey const ,RBX::Network::PropSync::detail::MasterItem> > *node; // rbx
  bool v12; // di
  const RBX::Network::NetworkSchema *networkSchema; // r11
  RBX::Instance *v14; // r13
  const RBX::Reflection::ClassDescriptor *descriptor; // r10
  std::pair<RBX::Reflection::ClassDescriptor const *,unsigned short> *Myfirst; // rbx
  std::pair<RBX::Reflection::ClassDescriptor const *,unsigned short> *Mylast; // r9
  const RBX::Reflection::ClassDescriptor *empty_key; // r11
  unsigned __int64 v19; // r9
  __int64 v20; // rax
  __int64 v21; // rdx
  std::pair<RBX::Reflection::ClassDescriptor const *,unsigned short> *v22; // rcx
  unsigned __int16 *p_second; // rdx
  bool streamingEnabled; // al
  RBX::Reflection::EnumPropDescriptor<RBX::ModelInstance,enum RBX::ModelStreamingMode> **v25; // rbx
  const RBX::Reflection::Type *type; // rbx
  RBX::Network::ClientReplicator::GCJob *v27; // rcx
  std::_Ref_count_base *v28; // rdx
  const RBX::Instance *instance; // r13
  RBX::AutoMemPool **v30; // rax
  RBX::Network::Item *v31; // rdi
  unsigned __int16 v32; // bx
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v35; // ett
  std::_Ref_count_base *v36; // rcx
  volatile signed __int32 *v37; // rbx
  RBX::Network::StreamingSolver *v38; // r12
  RBX::Instance *v39; // rdi
  const RBX::Reflection::ClassDescriptor *v40; // rbx
  RBX::Reflection::ClassDescriptor *v41; // rax
  RBX::Workspace *v42; // rax
  RBX::Reflection::DescribedBase *v43; // [rsp+20h] [rbp-89h] BYREF
  volatile signed __int32 *v44; // [rsp+28h] [rbp-81h]
  RBX::Network::PropSync::detail::PropertyKey value; // [rsp+30h] [rbp-79h] BYREF
  std::shared_ptr<RBX::Instance> v46; // [rsp+40h] [rbp-69h] BYREF
  std::shared_ptr<RBX::File> *v47; // [rsp+50h] [rbp-59h]
  RBX::Network::PropSync::detail::MasterItem v48; // [rsp+58h] [rbp-51h] BYREF
  RBX::Network::PropSync::detail::PropertyKey v49; // [rsp+70h] [rbp-39h]
  std::pair<boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<RBX::Network::PropSync::detail::PropertyKey const ,RBX::Network::PropSync::detail::MasterItem> > >,bool> result; // [rsp+80h] [rbp-29h] BYREF
  std::pair<RBX::Network::PropSync::detail::PropertyKey const ,RBX::Network::PropSync::detail::MasterItem> k[2]; // [rsp+90h] [rbp-19h] BYREF
  bool versionReset; // [rsp+110h] [rbp+67h]
  RBX::AutoMemPool *Myval2; // [rsp+110h] [rbp+67h]
  RBX::Time v54; // [rsp+118h] [rbp+6Fh] BYREF
  RBX::Property *v55; // [rsp+120h] [rbp+77h]
  void *v56; // [rsp+128h] [rbp+7Fh]

  v55 = prop; /*0x1410a1040*/
  versionReset = item->additionalInfo.versionReset; /*0x1410a106a*/
  networkId = item->networkId; /*0x1410a106d*/
  Ptr = item->instance._Ptr; /*0x1410a1072*/
  v7 = nullptr; /*0x1410a1076*/
  memset(&v48, 0, sizeof(v48)); /*0x1410a1079*/
  p_map = (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const ,RBX::Network::PropSync::detail::MasterItem> >,RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::MasterItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey> > > *)&this->propSync.map; /*0x1410a1081*/
  v49.networkId = networkId; /*0x1410a1090*/
  v9 = (RBX::Guid)0xFFFFFFFFLL; /*0x1410a1094*/
  if ( Ptr != nullptr ) /*0x1410a109d*/
    guid = (__int64)Ptr->guid; /*0x1410a109f*/
  else
    guid = 0xFFFFFFFFLL; /*0x1410a10a5*/
  v49.guid = (RBX::Guid)guid; /*0x1410a10a8*/
  k[0].first = v49; /*0x1410a10b0*/
  k[0].second = v48; /*0x1410a10b8*/
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::PropSync::detail::PropertyKey const,RBX::Network::PropSync::detail::SlaveItem>>,RBX::Network::PropSync::detail::PropertyKey,RBX::Network::PropSync::detail::SlaveItem,boost::hash<RBX::Network::PropSync::detail::PropertyKey>,std::equal_to<RBX::Network::PropSync::detail::PropertyKey>>>::emplace_impl<std::pair<RBX::Network::PropSync::detail::PropertyKey const,RBX::Network::PropSync::detail::SlaveItem>>( /*0x1410a10d2*/
    this: p_map,
    &result,
    k: &k[0].first,
    <args_0>: k);
  node = result.first.node_; /*0x1410a10d7*/
  *((double *)&node->value_base_.data_.data_.align_ + 3) = RBX::Time::now<0>(result: &v54)->sec /*0x1410a10f1*/
                                                         + this->propSync.expirationTime.sec;
  if ( result.second ) /*0x1410a10fa*/
  {
    value.networkId = networkId; /*0x1410a1103*/
    if ( Ptr != nullptr ) /*0x1410a110a*/
      v9 = Ptr->guid; /*0x1410a110c*/
    value.guid = v9; /*0x1410a1110*/
    rbx::timestamped_safe_queue<RBX::Network::PropSync::detail::PropertyKey>::push( /*0x1410a1118*/
      this: &this->propSync.expirationQueue,
      &value);
  }
  if ( versionReset ) /*0x1410a1121*/
    *((_DWORD *)&node->value_base_.data_.data_.align_ + 4) = 0; /*0x1410a1123*/
  else
    ++*((_DWORD *)&node->value_base_.data_.data_.align_ + 4); /*0x1410a1129*/
  node->value_base_.data_.data_.buf[32] = 0; /*0x1410a112c*/
  v12 = false; /*0x1410a1130*/
  networkSchema = this->networkSchema; /*0x1410a1133*/
  v14 = item->instance._Ptr; /*0x1410a113a*/
  descriptor = v14->descriptor; /*0x1410a113e*/
  Myfirst = networkSchema->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Myfirst; /*0x1410a1142*/
  Mylast = networkSchema->cframePropertyIdByLocalClassDescriptor.impl.data._Mypair._Myval2._Mylast; /*0x1410a1146*/
  if ( Myfirst != Mylast ) /*0x1410a114d*/
  {
    empty_key = networkSchema->cframePropertyIdByLocalClassDescriptor.impl.empty_key; /*0x1410a114f*/
    if ( descriptor != empty_key ) /*0x1410a1159*/
    {
      v19 = Mylast - Myfirst - 1; /*0x1410a1162*/
      v20 = v19 & ((unsigned __int64)descriptor + ((unsigned __int64)descriptor >> 3)); /*0x1410a116f*/
      v21 = 0; /*0x1410a1172*/
      while ( 1 ) /*0x1410a1187*/
      {
        v22 = &Myfirst[v20]; /*0x1410a1187*/
        if ( v22->first == descriptor ) /*0x1410a1190*/
          break; /*0x1410a1190*/
        if ( v22->first != empty_key ) /*0x1410a1195*/
        {
          v20 = v19 & (v21 + v20 + 1); /*0x1410a119d*/
          if ( ++v21 <= v19 ) /*0x1410a11a6*/
            continue; /*0x1410a11a6*/
        }
        goto LABEL_22; /*0x1410a11a6*/
      }
      p_second = &v22->second; /*0x1410a11aa*/
      if ( v22 == nullptr ) /*0x1410a11b1*/
        p_second = nullptr; /*0x1410a11b1*/
      if ( p_second != nullptr ) /*0x1410a11b8*/
        v12 = *p_second == item->networkId; /*0x1410a11c1*/
    }
  }
LABEL_22:
  streamingEnabled = this->streamingEnabled; /*0x1410a11c5*/
  v25 = (RBX::Reflection::EnumPropDescriptor<RBX::ModelInstance,enum RBX::ModelStreamingMode> **)v55; /*0x1410a11cd*/
  if ( !streamingEnabled || v55->descriptor != &RBX::Instance::propParent ) /*0x1410a11df*/
  {
    if ( v12 ) /*0x1410a1255*/
    {
      instance = v55->instance; /*0x1410a125b*/
      if ( instance != nullptr ) /*0x1410a1262*/
      {
        Myval2 = this->cframePool._Mypair._Myval2; /*0x1410a126f*/
        v30 = (RBX::AutoMemPool **)boost::pool<RBX::TrackedAllocator>::malloc(this: Myval2->pool._Mypair._Myval2); /*0x1410a1276*/
        *v30 = Myval2; /*0x1410a127b*/
        v31 = (RBX::Network::Item *)(v30 + 1); /*0x1410a127e*/
        v56 = v30 + 1; /*0x1410a1282*/
        __wind /*0xf1c0000000000034*/
        {
          if ( v30 == (RBX::AutoMemPool **)-8LL ) /*0x1410a1289*/
          {
            v31 = nullptr; /*0x1410a1360*/
          }
          else
          {
            v32 = item->networkId; /*0x1410a128f*/
            Rep = instance->_Wptr._Rep; /*0x1410a1293*/
            if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x1410a12a5*/
LABEL_57:
              std::_Throw_bad_weak_ptr(); /*0x1410a1425*/
            while ( 1 ) /*0x1410a12b3*/
            {
              v35 = Uses; /*0x1410a12b3*/
              Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x1410a12b3*/
              if ( v35 == Uses ) /*0x1410a12b8*/
                break; /*0x1410a12b8*/
              if ( Uses == 0 ) /*0x1410a12bc*/
                goto LABEL_57; /*0x1410a12bc*/
            }
            __wind /*0xf1c000000000001c*/
            {
              v36 = instance->_Wptr._Rep; /*0x1410a12c8*/
              v43 = instance->_Wptr._Ptr; /*0x1410a12cc*/
              v44 = (volatile signed __int32 *)v36; /*0x1410a12d1*/
              v47 = (std::shared_ptr<RBX::File> *)&v43; /*0x1410a12db*/
              RBX::Network::Item::Item(this: v31, replicator: this); /*0x1410a12e5*/
              v31->__vftable = (RBX::Network::Item_vtbl *)RBX::Network::CFrameAcknowledgementItem::`vftable'; /*0x1410a12f1*/
              v31[1].__vftable = (RBX::Network::Item_vtbl *)this; /*0x1410a12f4*/
              v31[1].next_ = nullptr; /*0x1410a12f8*/
              v31[1].prev_ = nullptr; /*0x1410a12fc*/
              if ( v44 != nullptr ) /*0x1410a1308*/
                _InterlockedIncrement(v44 + 2); /*0x1410a130a*/
              v31[1].next_ = (boost::intrusive::list_node<void *> *)v43; /*0x1410a1313*/
              v31[1].prev_ = (boost::intrusive::list_node<void *> *)v44; /*0x1410a131c*/
              LOWORD(v31[1].replicator) = v32; /*0x1410a1320*/
              v37 = v44; /*0x1410a1324*/
              if ( v44 != nullptr && _InterlockedExchangeAdd(v44 + 2, 0xFFFFFFFF) == 1 ) /*0x1410a133f*/
              {
                (**(void (__fastcall ***)(volatile signed __int32 *))v37)(a1: v37); /*0x1410a1347*/
                if ( _InterlockedExchangeAdd(v37 + 3, 0xFFFFFFFF) == 1 ) /*0x1410a1353*/
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v37 + 8LL))(a1: v37); /*0x1410a135b*/
              }
            }
            __unwind
            {
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: v47); /*0xf1c000000000002c*/
            }
          }
        }
        __unwind
        {
          RBX::AutoMemPool::Object::operator delete(p: v56, pool: Myval2); /*0x1431ec127*/
        }
        RBX::Network::ItemQueue::push_back(this: &this->pendingItems, item: v31); /*0x1410a136d*/
      }
    }
    else if ( FFlag::ModelStreamingMode.value /*0x1410a1394*/
           && streamingEnabled
           && RBX::Network::StreamingSolver::isSolverEnabled()
           && *v25 == &RBX::ModelInstance::desc_StreamingMode )
    {
      v38 = this->streamingSolver._Ptr; /*0x1410a1396*/
      v39 = item->instance._Ptr; /*0x1410a139d*/
      v40 = v39->descriptor; /*0x1410a13a1*/
      v41 = RBX::Reflection::Class_getDescriptorPtr<RBX::ModelInstance>(); /*0x1410a13a5*/
      if ( v40->index - (unsigned int)v41->index <= v41->descendantCount ) /*0x1410a13c3*/
        v7 = (RBX::ModelInstance *)v39; /*0x1410a13c3*/
      if ( v38 != nullptr && v7 != nullptr ) /*0x1410a13cf*/
      {
        v42 = RBX::Instance::findFirstAncestorOfType<RBX::Workspace>(this: item->instance._Ptr); /*0x1410a13d5*/
        RBX::Network::StreamingSolver::setModelStateChanged( /*0x1410a13ea*/
          this: v38,
          model: v7,
          workspaceDescendant: v42 != nullptr,
          validChange: true);
      }
    }
    goto LABEL_56; /*0x1410a1372*/
  }
  if ( this->gcJob._Ptr == nullptr /*0x1410a1203*/
    || v14 == nullptr
    || (type = item->value._type) != RBX::Reflection::Type::getSingleton<void>() )
  {
LABEL_56:
    value = (RBX::Network::PropSync::detail::PropertyKey)*v55; /*0x1410a13ef*/
    RBX::Network::Replicator::readChangedPropertyItem(this, item, prop: (RBX::Property *)&value); /*0x1410a140c*/
    return; /*0x1410a1424*/
  }
  v27 = this->gcJob._Ptr; /*0x1410a1209*/
  v46 = 0; /*0x1410a1213*/
  v28 = item->instance._Rep; /*0x1410a1218*/
  if ( v28 != nullptr ) /*0x1410a121f*/
  {
    _InterlockedIncrement((volatile signed __int32 *)&v28->_Uses); /*0x1410a1221*/
    v28 = item->instance._Rep; /*0x1410a1225*/
  }
  v46._Ptr = item->instance._Ptr; /*0x1410a122d*/
  v46._Rep = v28; /*0x1410a1231*/
  RBX::Network::ClientReplicator::GCJob::notifyServerGcingInstanceAndDescendants(this: v27, instance: &v46); /*0x1410a1239*/
  RBX::Network::ClientReplicator::streamOutInstance(this, instance: item->instance._Ptr, deleteImmediately: true); /*0x1410a1248*/
}

// Address: 0x1410a1430 | Name: ?readStats@ClientReplicator@Network@RBX@@AEAA?AV?$shared_ptr@V?$unordered_map@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@VVariant@Reflection@RBX@@U?$hash@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@U?$equal_to@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@V?$allocator@U?$pair@$$CBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@VVariant@Reflection@RBX@@@std@@@2@@std@@@std@@AEAVNetworkStream@23@@Z
// local variable allocation has failed, the output may be wrong!
std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > *__fastcall RBX::Network::ClientReplicator::readStats(
        RBX::Network::ClientReplicator *this,
        std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > *result,
        RBX::Network::NetworkStream *inBitstream)
{
  std::unordered_map<std::string,RBX::Reflection::Variant> *v5; // rax
  std::unordered_map<std::string,RBX::Reflection::Variant> *v6; // rax
  std::unordered_map<std::string,RBX::Reflection::Variant> *v7; // rsi
  RBX::File *v8; // rax
  std::unordered_map<std::string,RBX::Reflection::Variant> *v9; // rax
  std::unordered_map<std::string,RBX::Reflection::Variant> *v10; // rax
  std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *v11; // rbx
  RBX::File *v12; // rax
  std::unordered_map<std::string,RBX::Reflection::Variant> *v13; // rax
  std::unordered_map<std::string,RBX::Reflection::Variant> *v14; // rax
  RBX::File *v15; // rdi
  char *v16; // rax
  char *first; // r15
  std::unordered_map<std::string,RBX::Reflection::Variant> *v18; // rax
  std::unordered_map<std::string,RBX::Reflection::Variant> *v19; // rax
  RBX::File *v20; // rbx
  volatile signed __int32 *v21; // rax
  volatile signed __int32 *v22; // r13
  std::unordered_map<std::string,RBX::Reflection::Variant> *v23; // rax
  std::unordered_map<std::string,RBX::Reflection::Variant> *v24; // rax
  std::unordered_map<std::string,RBX::Reflection::Variant> *v25; // rbx
  volatile signed __int32 *v26; // rax
  int Int32; // eax
  std::string *v28; // rax
  char *v29; // rcx
  bool v30; // zf
  int PayloadLimit; // eax
  float Float; // xmm6_4
  float v33; // xmm7_4
  float v34; // xmm8_4
  RBX::Reflection::Tuple *v35; // rax
  RBX::Reflection::Tuple *v36; // rbx
  std::_Ref_count_base *v37; // rax
  std::_Ref_count_base *v38; // rdi
  const rbx::implementation::typed_holder<float> *v39; // rax
  RBX::Reflection::Variant *Mylast; // rsi
  const rbx::implementation::type_holder *holder; // rax
  __int64 v42; // rcx
  const rbx::implementation::typed_holder<float> *v43; // rax
  RBX::Reflection::Variant *v44; // rsi
  const rbx::implementation::type_holder *v45; // rax
  const rbx::implementation::typed_holder<float> *v46; // rax
  RBX::Reflection::Variant *v47; // rsi
  const rbx::implementation::type_holder *v48; // rax
  std::_Ref_count_base *Rep; // rbx
  char *Ptr; // rcx
  bool Bool; // bl
  void *v52; // rcx
  int v53; // eax
  float v54; // xmm6_4
  int v55; // r15d
  RBX::Reflection::Tuple *v56; // rax
  RBX::Reflection::Tuple *v57; // rbx
  _DWORD *v58; // rax
  _DWORD *v59; // rdi
  const rbx::implementation::typed_holder<float> *v60; // rax
  RBX::Reflection::Variant *v61; // rsi
  const rbx::implementation::type_holder *v62; // rax
  __int64 v63; // rcx
  const rbx::implementation::typed_holder<int> *v64; // rax
  RBX::Reflection::Variant *v65; // rsi
  const rbx::implementation::type_holder *v66; // rax
  std::_Ref_count_base *v67; // rbx
  char *v68; // rcx
  bool v69; // bl
  char *v70; // rcx
  float v71; // xmm6_4
  float v72; // xmm7_4
  float v73; // xmm8_4
  float v74; // xmm9_4
  float v75; // xmm10_4
  std::unordered_map<std::string,RBX::Reflection::Variant> *v76; // rax
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > *v77; // r12
  std::unordered_map<std::string,RBX::Reflection::Variant> *v78; // rcx
  std::_Ref_count_base *v79; // rbx
  std::unordered_map<std::string,RBX::Reflection::Variant> *v80; // rcx
  std::_Ref_count_base *v81; // rdi
  std::_Ref_count_base *v82; // rbx
  std::unordered_map<std::string,RBX::Reflection::Variant> *v83; // rcx
  std::_Ref_count_base *v84; // rsi
  std::_Ref_count_base *v85; // rbx
  std::unordered_map<std::string,RBX::Reflection::Variant> *v86; // rcx
  std::_Ref_count_base *v87; // rbx
  std::unordered_map<std::string,RBX::Reflection::Variant> *v88; // rbx
  __int64 v89; // rcx
  void (__fastcall *destruct)(char *); // rdx
  void *v91; // rcx
  void *v92; // rcx
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > *v93; // rax
  _BYTE v94[32]; // [rsp+8h] [rbp-100h] BYREF
  __int64 v95; // [rsp+28h] [rbp-E0h]
  RBX::Reflection::Variant *v96; // [rsp+30h] [rbp-D8h]
  volatile signed __int32 *v97; // [rsp+38h] [rbp-D0h]
  std::pair<char const *,float> v98; // [rsp+40h] [rbp-C8h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v99; // [rsp+50h] [rbp-B8h] BYREF
  std::shared_ptr<RBX::File> v100; // [rsp+60h] [rbp-A8h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > v101; // [rsp+70h] [rbp-98h] BYREF
  _BYTE v102[48]; // [rsp+80h] [rbp-88h] OVERLAPPED BYREF
  std::pair<char const *,std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > > v103; // [rsp+B0h] [rbp-58h] BYREF
  std::pair<char const *,std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > > v104; // [rsp+C8h] [rbp-40h] BYREF
  std::pair<char const *,std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > > v105; // [rsp+E0h] [rbp-28h] BYREF
  std::pair<char const *,std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > > v106; // [rsp+F8h] [rbp-10h] BYREF
  std::shared_ptr<RBX::File> v107; // [rsp+110h] [rbp+8h] BYREF
  std::shared_ptr<RBX::File> v108; // [rsp+120h] [rbp+18h] BYREF
  std::shared_ptr<RBX::File> v109; // [rsp+130h] [rbp+28h] BYREF
  RBX::Reflection::Variant v110; // [rsp+140h] [rbp+38h] BYREF
  RBX::Reflection::Variant v111; // [rsp+190h] [rbp+88h] BYREF
  RBX::Reflection::Variant v112; // [rsp+1E0h] [rbp+D8h] BYREF
  RBX::Reflection::Variant v113; // [rsp+230h] [rbp+128h] BYREF
  RBX::Reflection::Variant v114; // [rsp+280h] [rbp+178h] BYREF
  std::pair<std::string const ,std::shared_ptr<std::string const > > v115; // [rsp+2D0h] [rbp+1C8h] BYREF
  std::pair<std::string const ,std::shared_ptr<std::string const > > v116; // [rsp+300h] [rbp+1F8h] BYREF
  std::shared_ptr<RBX::File> v117; // [rsp+330h] [rbp+228h] BYREF
  std::shared_ptr<RBX::File> v118; // [rsp+340h] [rbp+238h] BYREF
  std::pair<char const *,float> v119; // [rsp+350h] [rbp+248h] BYREF
  std::pair<char const *,float> v120; // [rsp+360h] [rbp+258h] BYREF
  std::pair<char const *,float> v121; // [rsp+370h] [rbp+268h] BYREF
  std::pair<char const *,float> v122; // [rsp+380h] [rbp+278h] BYREF
  std::_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant> > v123; // [rsp+390h] [rbp+288h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > DEPRECATED_serverMemoryByDeveloperTagValueTable; // [rsp+398h] [rbp+290h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > serverMemoryBreakdownValueTable; // [rsp+3A8h] [rbp+2A0h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > dataStoreBudget; // [rsp+3B8h] [rbp+2B0h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > scripts; // [rsp+3C8h] [rbp+2C0h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > jobs; // [rsp+3D8h] [rbp+2D0h] BYREF
  std::string name; // [rsp+3E8h] [rbp+2E0h] BYREF
  unsigned __int64 v130; // [rsp+408h] [rbp+300h]
  std::string v131; // [rsp+410h] [rbp+308h] BYREF
  RBX::Reflection::Tuple *v132; // [rsp+430h] [rbp+328h] BYREF
  std::shared_ptr<std::vector<RBX::Reflection::Variant> > jobInfo; // [rsp+438h] [rbp+330h] BYREF
  std::_Ref_count_base *v134; // [rsp+448h] [rbp+340h]
  std::_Temporary_owner<RBX::Reflection::Tuple> v135; // [rsp+450h] [rbp+348h] BYREF
  std::_Temporary_owner<RBX::Reflection::Tuple> v136; // [rsp+458h] [rbp+350h] BYREF
  std::_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant> > v137; // [rsp+460h] [rbp+358h] BYREF
  std::_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant> > v138; // [rsp+468h] [rbp+360h] BYREF
  std::_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant> > v139; // [rsp+470h] [rbp+368h] BYREF
  RBX::Reflection::Variant other; // [rsp+478h] [rbp+370h] BYREF
  std::string v141; // [rsp+4C8h] [rbp+3C0h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v142; // [rsp+4E8h] [rbp+3E0h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v143; // [rsp+4F8h] [rbp+3F0h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v144; // [rsp+508h] [rbp+400h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v145; // [rsp+518h] [rbp+410h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v146; // [rsp+528h] [rbp+420h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v147; // [rsp+538h] [rbp+430h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v148; // [rsp+548h] [rbp+440h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v149; // [rsp+558h] [rbp+450h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v150; // [rsp+568h] [rbp+460h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v151; // [rsp+578h] [rbp+470h] BYREF
  std::pair<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<std::string const ,RBX::Reflection::Variant> > > >,bool> v152; // [rsp+588h] [rbp+480h] BYREF
  std::pair<char const *,RBX::Reflection::Variant> v153; // [rsp+598h] [rbp+490h] BYREF
  std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,RBX::Reflection::Variant> >,0> > *v156; // [rsp+6A0h] [rbp+598h]
  std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,RBX::Reflection::Variant> >,0> > *v157; // [rsp+6A0h] [rbp+598h]
  std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,RBX::Reflection::Variant> >,0> > *v158; // [rsp+6A0h] [rbp+598h]

  __wind /*0xf1c000000000065c*/
  {
    LODWORD(v95) = 0; /*0x1410a1478*/
    v5 = (std::unordered_map<std::string,RBX::Reflection::Variant> *)operator new(size: 0x40u); /*0x1410a1485*/
    __wind /*0xf1c0000000000620*/
    {
      v156 = v5; /*0x1410a148a*/
      if ( v5 != nullptr ) /*0x1410a1494*/
      {
        v6 = std::unordered_map<std::string,RBX::Reflection::Variant>::unordered_map<std::string,RBX::Reflection::Variant>(this: v5); /*0x1410a1499*/
        v7 = v6; /*0x1410a149e*/
      }
      else
      {
        v7 = nullptr; /*0x1410a14a3*/
      }
    }
    __unwind
    {
      operator delete(ptr: v156); /*0x1431ec155*/
    }
    __wind /*0xf1c0000000000638*/
    {
      v157 = v7; /*0x1410a14a5*/
      v123._Ptr = v7; /*0x1410a14ac*/
      v8 = (RBX::File *)operator new(size: 0x18u); /*0x1410a14b8*/
      v108._Ptr = v8; /*0x1410a14bd*/
      if ( v8 != nullptr ) /*0x1410a14cb*/
      {
        *(_OWORD *)&v8->__vftable = 0; /*0x1410a14d0*/
        LODWORD(v8->_Wptr._Ptr) = 1; /*0x1410a14d3*/
        HIDWORD(v8->_Wptr._Ptr) = 1; /*0x1410a14da*/
        v8->__vftable = (RBX::File_vtbl *)std::_Ref_count<std::unordered_map<std::string,RBX::Reflection::Variant>>::`vftable'; /*0x1410a14e1*/
        v8->_Wptr._Rep = (std::_Ref_count_base *)v7; /*0x1410a14e4*/
      }
      else
      {
        v108._Ptr = nullptr; /*0x1410a14ea*/
      }
    }
    __unwind
    {
      std::_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant>>::~_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant>>(this: &v123); /*0xf1c0000000000648*/
    }
    __wind /*0xf1c0000000000650*/
    {
      jobs._Rep = (std::_Ref_count_base *)v7; /*0x1410a14ee*/
      name._Mypair._Myval2._Bx._Ptr = (char *)v8; /*0x1410a14f5*/
      v9 = (std::unordered_map<std::string,RBX::Reflection::Variant> *)operator new(size: 0x40u); /*0x1410a1501*/
      __wind /*0xf1c00000000005e4*/
      {
        v97 = (volatile signed __int32 *)v9; /*0x1410a1506*/
        if ( v9 != nullptr ) /*0x1410a150e*/
        {
          v10 = std::unordered_map<std::string,RBX::Reflection::Variant>::unordered_map<std::string,RBX::Reflection::Variant>(this: v9); /*0x1410a1513*/
          v11 = (std::_List_node<std::pair<std::string const ,RBX::Reflection::Variant>,void *> *)v10; /*0x1410a1518*/
        }
        else
        {
          v11 = nullptr; /*0x1410a151d*/
        }
      }
      __unwind
      {
        operator delete(ptr: (void *)v97); /*0x143167422*/
      }
      __wind /*0xf1c00000000005fc*/
      {
        v99.first._Ptr = v11; /*0x1410a151f*/
        DEPRECATED_serverMemoryByDeveloperTagValueTable._Ptr = (std::unordered_map<std::string,RBX::Reflection::Variant> *)v11; /*0x1410a1524*/
        v12 = (RBX::File *)operator new(size: 0x18u); /*0x1410a1530*/
        v109._Ptr = v12; /*0x1410a1535*/
        if ( v12 != nullptr ) /*0x1410a153c*/
        {
          *(_OWORD *)&v12->__vftable = 0; /*0x1410a1541*/
          LODWORD(v12->_Wptr._Ptr) = 1; /*0x1410a1544*/
          HIDWORD(v12->_Wptr._Ptr) = 1; /*0x1410a154b*/
          v12->__vftable = (RBX::File_vtbl *)std::_Ref_count<std::unordered_map<std::string,RBX::Reflection::Variant>>::`vftable'; /*0x1410a1552*/
          v12->_Wptr._Rep = (std::_Ref_count_base *)v11; /*0x1410a1555*/
        }
        else
        {
          v109._Ptr = nullptr; /*0x1410a155b*/
        }
      }
      __unwind
      {
        std::_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant>>::~_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant>>(this: (std::_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant> > *)&DEPRECATED_serverMemoryByDeveloperTagValueTable); /*0xf1c000000000060c*/
      }
      __wind /*0xf1c0000000000614*/
      {
        scripts._Rep = (std::_Ref_count_base *)v11; /*0x1410a155f*/
        jobs._Ptr = (std::unordered_map<std::string,RBX::Reflection::Variant> *)v12; /*0x1410a1566*/
        v13 = (std::unordered_map<std::string,RBX::Reflection::Variant> *)operator new(size: 0x40u); /*0x1410a1572*/
        __wind /*0xf1c00000000005a8*/
        {
          v97 = (volatile signed __int32 *)v13; /*0x1410a1577*/
          if ( v13 != nullptr ) /*0x1410a157f*/
          {
            v14 = std::unordered_map<std::string,RBX::Reflection::Variant>::unordered_map<std::string,RBX::Reflection::Variant>(this: v13); /*0x1410a1584*/
            v15 = (RBX::File *)v14; /*0x1410a1589*/
          }
          else
          {
            v15 = nullptr; /*0x1410a158e*/
          }
        }
        __unwind
        {
          operator delete(ptr: (void *)v97); /*0xf1c000000000009c*/
        }
        __wind /*0xf1c00000000005c0*/
        {
          v107._Ptr = v15; /*0x1410a1590*/
          v139._Ptr = (std::unordered_map<std::string,RBX::Reflection::Variant> *)v15; /*0x1410a1594*/
          v16 = (char *)operator new(size: 0x18u); /*0x1410a15a0*/
          first = v16; /*0x1410a15a5*/
          v98.first = v16; /*0x1410a15a8*/
          if ( v16 != nullptr ) /*0x1410a15b0*/
          {
            *(_OWORD *)v16 = 0; /*0x1410a15b5*/
            *((_DWORD *)v16 + 2) = 1; /*0x1410a15b8*/
            *((_DWORD *)v16 + 3) = 1; /*0x1410a15bf*/
            *(_QWORD *)v16 = std::_Ref_count<std::unordered_map<std::string,RBX::Reflection::Variant>>::`vftable'; /*0x1410a15c6*/
            *((_QWORD *)v16 + 2) = v15; /*0x1410a15c9*/
          }
          else
          {
            first = nullptr; /*0x1410a15cf*/
            v98.first = nullptr; /*0x1410a15d2*/
          }
        }
        __unwind
        {
          std::_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant>>::~_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant>>(this: &v139); /*0xf1c00000000005d0*/
        }
        __wind /*0xf1c00000000005d8*/
        {
          dataStoreBudget._Rep = (std::_Ref_count_base *)v15; /*0x1410a15d7*/
          scripts._Ptr = (std::unordered_map<std::string,RBX::Reflection::Variant> *)first; /*0x1410a15de*/
          v18 = (std::unordered_map<std::string,RBX::Reflection::Variant> *)operator new(size: 0x40u); /*0x1410a15ea*/
          __wind /*0xf1c000000000056c*/
          {
            v97 = (volatile signed __int32 *)v18; /*0x1410a15ef*/
            if ( v18 != nullptr ) /*0x1410a15f7*/
            {
              v19 = std::unordered_map<std::string,RBX::Reflection::Variant>::unordered_map<std::string,RBX::Reflection::Variant>(this: v18); /*0x1410a15fc*/
              v20 = (RBX::File *)v19; /*0x1410a1601*/
            }
            else
            {
              v20 = nullptr; /*0x1410a1606*/
            }
          }
          __unwind
          {
            operator delete(ptr: (void *)v97); /*0xf1c00000000000c0*/
          }
          __wind /*0xf1c0000000000584*/
          {
            v100._Ptr = v20; /*0x1410a1608*/
            v138._Ptr = (std::unordered_map<std::string,RBX::Reflection::Variant> *)v20; /*0x1410a160d*/
            v21 = (volatile signed __int32 *)operator new(size: 0x18u); /*0x1410a1619*/
            v22 = v21; /*0x1410a161e*/
            v97 = v21; /*0x1410a1621*/
            if ( v21 != nullptr ) /*0x1410a1629*/
            {
              *(_OWORD *)v21 = 0; /*0x1410a162e*/
              *((_DWORD *)v21 + 2) = 1; /*0x1410a1631*/
              *((_DWORD *)v21 + 3) = 1; /*0x1410a1638*/
              *(_QWORD *)v21 = std::_Ref_count<std::unordered_map<std::string,RBX::Reflection::Variant>>::`vftable'; /*0x1410a1646*/
              *((_QWORD *)v21 + 2) = v20; /*0x1410a164a*/
            }
            else
            {
              v22 = nullptr; /*0x1410a1650*/
            }
          }
          __unwind
          {
            std::_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant>>::~_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant>>(this: &v138); /*0xf1c0000000000594*/
          }
          __wind /*0xf1c000000000059c*/
          {
            serverMemoryBreakdownValueTable._Rep = (std::_Ref_count_base *)v20; /*0x1410a1653*/
            dataStoreBudget._Ptr = (std::unordered_map<std::string,RBX::Reflection::Variant> *)v22; /*0x1410a165a*/
            v23 = (std::unordered_map<std::string,RBX::Reflection::Variant> *)operator new(size: 0x40u); /*0x1410a1666*/
            __wind /*0xf1c00000000004d4*/
            {
              v97 = (volatile signed __int32 *)v23; /*0x1410a166b*/
              if ( v23 != nullptr ) /*0x1410a1673*/
              {
                v24 = std::unordered_map<std::string,RBX::Reflection::Variant>::unordered_map<std::string,RBX::Reflection::Variant>(this: v23); /*0x1410a1678*/
                v25 = v24; /*0x1410a167d*/
              }
              else
              {
                v25 = nullptr; /*0x1410a1682*/
              }
            }
            __unwind
            {
              operator delete(ptr: (void *)v97); /*0xf1c00000000000e4*/
            }
            __wind /*0xf1c00000000004ec*/
            {
              v137._Ptr = v25; /*0x1410a1684*/
              v26 = (volatile signed __int32 *)operator new(size: 0x18u); /*0x1410a1690*/
              v97 = v26; /*0x1410a1695*/
              if ( v26 != nullptr ) /*0x1410a169d*/
              {
                *(_OWORD *)v26 = 0; /*0x1410a16a2*/
                *((_DWORD *)v26 + 2) = 1; /*0x1410a16a5*/
                *((_DWORD *)v26 + 3) = 1; /*0x1410a16ac*/
                *(_QWORD *)v26 = std::_Ref_count<std::unordered_map<std::string,RBX::Reflection::Variant>>::`vftable'; /*0x1410a16ba*/
                *((_QWORD *)v26 + 2) = v25; /*0x1410a16bd*/
              }
              else
              {
                v97 = nullptr; /*0x1410a16c3*/
              }
            }
            __unwind
            {
              std::_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant>>::~_Temporary_owner<std::unordered_map<std::string,RBX::Reflection::Variant>>(this: &v137); /*0xf1c00000000004fc*/
            }
            __wind /*0xf1c0000000000504*/
            {
              __wind /*0xf1c000000000050c*/
              {
                DEPRECATED_serverMemoryByDeveloperTagValueTable._Rep = (std::_Ref_count_base *)v25; /*0x1410a16c8*/
                serverMemoryBreakdownValueTable._Ptr = (std::unordered_map<std::string,RBX::Reflection::Variant> *)v26; /*0x1410a16cf*/
                *(_QWORD *)&v102[16] = 0; /*0x1410a16d8*/
                *(_QWORD *)&v102[32] = 0; /*0x1410a16dc*/
                *(_QWORD *)&v102[40] = 15; /*0x1410a16e0*/
                Int32 = RBX::Network::NetworkStream::readInt32(this: inBitstream); /*0x1410a16ee*/
                if ( Int32 < 7 ) /*0x1410a16f6*/
                {
                  if ( Int32 < 6 ) /*0x1410a1779*/
                  {
                    if ( Int32 < 3 ) /*0x1410a17af*/
                    {
LABEL_48:
                      v30 = !RBX::Network::NetworkStream::readBool(this: inBitstream); /*0x1410a17da*/
                      while ( v30 ) /*0x1410a17ea*/
                      {
                        PayloadLimit = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1410a17f7*/
                        RBX::Network::NetworkStream::readString( /*0x1410a1809*/
                          this: inBitstream,
                          result: (std::string *)&name._Mypair._Myval2._Bx._Alias[8],
                          maxStringReadSize: PayloadLimit);
                        __wind /*0xf1c00000000004c8*/
                        {
                          Float = RBX::Network::NetworkStream::readFloat(this: inBitstream); /*0x1410a1817*/
                          v33 = RBX::Network::NetworkStream::readFloat(this: inBitstream); /*0x1410a1822*/
                          v34 = RBX::Network::NetworkStream::readFloat(this: inBitstream); /*0x1410a182d*/
                          v35 = (RBX::Reflection::Tuple *)operator new(size: 0x18u); /*0x1410a1836*/
                          v36 = v35; /*0x1410a183b*/
                          if ( v35 != nullptr ) /*0x1410a1843*/
                          {
                            v35->values._Mypair._Myval2._Myfirst = nullptr; /*0x1410a1845*/
                            v35->values._Mypair._Myval2._Mylast = nullptr; /*0x1410a1848*/
                            v35->values._Mypair._Myval2._Myend = nullptr; /*0x1410a184c*/
                          }
                          else
                          {
                            v36 = nullptr; /*0x1410a1852*/
                          }
                          v136._Ptr = v36; /*0x1410a1855*/
                          __wind /*0xf1c000000000048c*/
                          {
                            v37 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x1410a1861*/
                            v38 = v37; /*0x1410a1866*/
                            v96 = (RBX::Reflection::Variant *)v37; /*0x1410a1869*/
                            if ( v37 != nullptr ) /*0x1410a1871*/
                            {
                              *v37 = 0; /*0x1410a1876*/
                              v37->_Uses = 1; /*0x1410a1879*/
                              v37->_Weaks = 1; /*0x1410a1880*/
                              v37->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<std::vector<RBX::Reflection::Variant>>::`vftable'; /*0x1410a188e*/
                              v37[1].__vftable = (std::_Ref_count_base_vtbl *)v36; /*0x1410a1891*/
                            }
                            else
                            {
                              v38 = nullptr; /*0x1410a1897*/
                            }
                          }
                          __unwind
                          {
                            std::_Temporary_owner<RBX::Reflection::Tuple>::~_Temporary_owner<RBX::Reflection::Tuple>(this: &v136); /*0xf1c000000000049c*/
                          }
                          __wind /*0xf1c00000000004a4*/
                          {
                            jobInfo._Rep = (std::_Ref_count_base *)v36; /*0x1410a189a*/
                            v134 = v38; /*0x1410a18a1*/
                            v114._type = RBX::Reflection::Type::getSingleton<float>(); /*0x1410a18ad*/
                            v114.value.holder = nullptr; /*0x1410a18b4*/
                            *(float *)v114.value.data = Float; /*0x1410a18bb*/
                            v39 = rbx::implementation::typed_holder<float>::singleton(); /*0x1410a18c3*/
                            __wind /*0xf1c000000000046c*/
                            {
                              v114.value.holder = v39; /*0x1410a18c8*/
                              Mylast = v36->values._Mypair._Myval2._Mylast; /*0x1410a18cf*/
                              if ( Mylast == v36->values._Mypair._Myval2._Myend ) /*0x1410a18d7*/
                              {
                                std::vector<RBX::Reflection::Variant>::_Emplace_reallocate<RBX::Reflection::Variant>( /*0x1410a1984*/
                                  this: &v36->values,
                                  _Whereptr: v36->values._Mypair._Myval2._Mylast,
                                  <_Val_0>: &v114);
                              }
                              else
                              {
                                v96 = v36->values._Mypair._Myval2._Mylast; /*0x1410a18dd*/
                                Mylast->_type = v114._type; /*0x1410a18e9*/
                                Mylast->value.holder = nullptr; /*0x1410a18ec*/
                                holder = v114.value.holder; /*0x1410a18f4*/
                                if ( v114.value.holder != nullptr ) /*0x1410a18fe*/
                                {
                                  v114.value.holder->moveConstruct(a1: v114.value.data, a2: Mylast->value.data); /*0x1410a190f*/
                                  holder = v114.value.holder; /*0x1410a1911*/
                                }
                                Mylast->value.holder = holder; /*0x1410a1918*/
                                if ( v114.value.holder != nullptr ) /*0x1410a1926*/
                                {
                                  v114.value.holder->destruct(a1: v114.value.data); /*0x1410a1933*/
                                  v114.value.holder = nullptr; /*0x1410a1935*/
                                }
                                __wind /*0xf1c0000000000460*/
                                {
                                  v114._type = RBX::Reflection::Type::getSingleton<void>(); /*0x1410a1945*/
                                  if ( v114.value.holder != nullptr ) /*0x1410a1956*/
                                  {
                                    v114.value.holder->destruct(a1: v114.value.data); /*0x1410a1963*/
                                    v114.value.holder = nullptr; /*0x1410a1965*/
                                  }
                                }
                                __unwind
                                {
                                  rbx::placement_any<RBX::Reflection::Variant::Storage>::~placement_any<RBX::Reflection::Variant::Storage>(this: &v96->value); /*0x1431c083b*/
                                }
                                ++v36->values._Mypair._Myval2._Mylast; /*0x1410a1970*/
                              }
                            }
                            __unwind
                            {
                              std::tuple<bool,RBX::Reflection::Variant>::~tuple<bool,RBX::Reflection::Variant>(this: (RBX::setupTweenUpdate::__l5::<lambda_fde46e4afccb457705ab91f32d9aea10> *)&v114); /*0xf1c000000000047c*/
                            }
                            __eh34_enter_wind_state(19, 22); /*0xf1c0000000000484*/
                            if ( v114.value.holder != nullptr ) /*0x1410a1994*/
                              v114.value.holder->destruct(a1: v114.value.data); /*0x1410a19a1*/
                            if ( __eh34_unwind(22) ) /*0xf1c0000000000448*/
unwind_state_22:
                              __std_terminate(a1: v42, a2: v94); /*0xf1c00000000003bc*/
                            __eh34_exit_wind_state(22, 19); /*0xf1c000000000044c*/
                            v113._type = RBX::Reflection::Type::getSingleton<float>(); /*0x1410a19a9*/
                            v113.value.holder = nullptr; /*0x1410a19b0*/
                            *(float *)v113.value.data = v33; /*0x1410a19bb*/
                            v43 = rbx::implementation::typed_holder<float>::singleton(); /*0x1410a19c3*/
                            __wind /*0xf1c0000000000428*/
                            {
                              v113.value.holder = v43; /*0x1410a19c8*/
                              v44 = v36->values._Mypair._Myval2._Mylast; /*0x1410a19cf*/
                              if ( v44 == v36->values._Mypair._Myval2._Myend ) /*0x1410a19d7*/
                              {
                                std::vector<RBX::Reflection::Variant>::_Emplace_reallocate<RBX::Reflection::Variant>( /*0x1410a1a84*/
                                  this: &v36->values,
                                  _Whereptr: v36->values._Mypair._Myval2._Mylast,
                                  <_Val_0>: &v113);
                              }
                              else
                              {
                                v96 = v36->values._Mypair._Myval2._Mylast; /*0x1410a19dd*/
                                v44->_type = v113._type; /*0x1410a19e9*/
                                v44->value.holder = nullptr; /*0x1410a19ec*/
                                v45 = v113.value.holder; /*0x1410a19f4*/
                                if ( v113.value.holder != nullptr ) /*0x1410a19fe*/
                                {
                                  v113.value.holder->moveConstruct(a1: v113.value.data, a2: v44->value.data); /*0x1410a1a0f*/
                                  v45 = v113.value.holder; /*0x1410a1a11*/
                                }
                                v44->value.holder = v45; /*0x1410a1a18*/
                                if ( v113.value.holder != nullptr ) /*0x1410a1a26*/
                                {
                                  v113.value.holder->destruct(a1: v113.value.data); /*0x1410a1a33*/
                                  v113.value.holder = nullptr; /*0x1410a1a35*/
                                }
                                __wind /*0xf1c000000000041c*/
                                {
                                  v113._type = RBX::Reflection::Type::getSingleton<void>(); /*0x1410a1a45*/
                                  if ( v113.value.holder != nullptr ) /*0x1410a1a56*/
                                  {
                                    v113.value.holder->destruct(a1: v113.value.data); /*0x1410a1a63*/
                                    v113.value.holder = nullptr; /*0x1410a1a65*/
                                  }
                                }
                                __unwind
                                {
                                  rbx::placement_any<RBX::Reflection::Variant::Storage>::~placement_any<RBX::Reflection::Variant::Storage>(this: &v96->value); /*0xf1c0000000000100*/
                                }
                                ++v36->values._Mypair._Myval2._Mylast; /*0x1410a1a70*/
                              }
                            }
                            __unwind
                            {
                              std::tuple<bool,RBX::Reflection::Variant>::~tuple<bool,RBX::Reflection::Variant>(this: (RBX::setupTweenUpdate::__l5::<lambda_fde46e4afccb457705ab91f32d9aea10> *)&v113); /*0xf1c0000000000438*/
                            }
                            __eh34_enter_wind_state(19, 22); /*0xf1c0000000000440*/
                            if ( v113.value.holder != nullptr ) /*0x1410a1a94*/
                              v113.value.holder->destruct(a1: v113.value.data); /*0x1410a1aa1*/
                            if ( __eh34_unwind(22) ) /*0xf1c0000000000404*/
                              goto unwind_state_22; /*0xf1c0000000000404*/
                            __eh34_exit_wind_state(22, 19); /*0xf1c0000000000408*/
                            v112._type = RBX::Reflection::Type::getSingleton<float>(); /*0x1410a1aa9*/
                            v112.value.holder = nullptr; /*0x1410a1ab0*/
                            *(float *)v112.value.data = v34; /*0x1410a1abb*/
                            v46 = rbx::implementation::typed_holder<float>::singleton(); /*0x1410a1ac4*/
                            __wind /*0xf1c00000000003e4*/
                            {
                              v112.value.holder = v46; /*0x1410a1ac9*/
                              v47 = v36->values._Mypair._Myval2._Mylast; /*0x1410a1ad0*/
                              if ( v47 == v36->values._Mypair._Myval2._Myend ) /*0x1410a1ad8*/
                              {
                                std::vector<RBX::Reflection::Variant>::_Emplace_reallocate<RBX::Reflection::Variant>( /*0x1410a1b85*/
                                  this: &v36->values,
                                  _Whereptr: v36->values._Mypair._Myval2._Mylast,
                                  <_Val_0>: &v112);
                              }
                              else
                              {
                                v96 = v36->values._Mypair._Myval2._Mylast; /*0x1410a1ade*/
                                v47->_type = v112._type; /*0x1410a1aea*/
                                v47->value.holder = nullptr; /*0x1410a1aed*/
                                v48 = v112.value.holder; /*0x1410a1af5*/
                                if ( v112.value.holder != nullptr ) /*0x1410a1aff*/
                                {
                                  v112.value.holder->moveConstruct(a1: v112.value.data, a2: v47->value.data); /*0x1410a1b10*/
                                  v48 = v112.value.holder; /*0x1410a1b12*/
                                }
                                v47->value.holder = v48; /*0x1410a1b19*/
                                if ( v112.value.holder != nullptr ) /*0x1410a1b27*/
                                {
                                  v112.value.holder->destruct(a1: v112.value.data); /*0x1410a1b34*/
                                  v112.value.holder = nullptr; /*0x1410a1b36*/
                                }
                                __wind /*0xf1c00000000003d8*/
                                {
                                  v112._type = RBX::Reflection::Type::getSingleton<void>(); /*0x1410a1b46*/
                                  if ( v112.value.holder != nullptr ) /*0x1410a1b57*/
                                  {
                                    v112.value.holder->destruct(a1: v112.value.data); /*0x1410a1b64*/
                                    v112.value.holder = nullptr; /*0x1410a1b66*/
                                  }
                                }
                                __unwind
                                {
                                  rbx::placement_any<RBX::Reflection::Variant::Storage>::~placement_any<RBX::Reflection::Variant::Storage>(this: &v96->value); /*0xf1c0000000000114*/
                                }
                                ++v36->values._Mypair._Myval2._Mylast; /*0x1410a1b71*/
                              }
                            }
                            __unwind
                            {
                              std::tuple<bool,RBX::Reflection::Variant>::~tuple<bool,RBX::Reflection::Variant>(this: (RBX::setupTweenUpdate::__l5::<lambda_fde46e4afccb457705ab91f32d9aea10> *)&v112); /*0xf1c00000000003f4*/
                            }
                            __eh34_enter_wind_state(19, 22); /*0xf1c00000000003fc*/
                            if ( v112.value.holder != nullptr ) /*0x1410a1b95*/
                              v112.value.holder->destruct(a1: v112.value.data); /*0x1410a1ba2*/
                            if ( __eh34_unwind(22) ) /*0xf1c00000000003b8*/
                              goto unwind_state_22; /*0xf1c00000000003b8*/
                            __eh34_exit_wind_state(22, 19); /*0xf1c00000000003c4*/
                            if ( v38 != nullptr ) /*0x1410a1ba8*/
                              _InterlockedIncrement((volatile signed __int32 *)&v38->_Uses); /*0x1410a1baa*/
                            __wind /*0xf1c00000000003ac*/
                            {
                              v117._Ptr = (RBX::File *)v36; /*0x1410a1bae*/
                              v117._Rep = v38; /*0x1410a1bb5*/
                              std::string::string( /*0x1410a1bca*/
                                this: (rtc::webrtc_checks_impl::ToStringVal *)&v116,
                                __that: (const rtc::webrtc_checks_impl::ToStringVal *)&name._Mypair._Myval2._Bx._Alias[8]);
                              __wind /*0xf1c0000000000388*/
                              {
                                v116.second._Ptr = (const std::string *)v36; /*0x1410a1bcf*/
                                v116.second._Rep = v38; /*0x1410a1bd6*/
                                v117 = 0; /*0x1410a1be0*/
                                LODWORD(v95) = v95 | 2; /*0x1410a1be8*/
                                v7 = (std::unordered_map<std::string,RBX::Reflection::Variant> *)v157; /*0x1410a1bfb*/
                                std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<std::string,std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>>( /*0x1410a1c05*/
                                  this: v157,
                                  result: &v142,
                                  <_Vals_0>: (std::pair<std::string,std::shared_ptr<std::vector<RBX::Reflection::Variant> const > > *)&v116);
                                if ( v116.second._Rep != nullptr /*0x1410a1c22*/
                                  && _InterlockedExchangeAdd(
                                       (volatile signed __int32 *)&v116.second._Rep->_Uses,
                                       0xFFFFFFFF) == 1 )
                                {
                                  Rep = v116.second._Rep; /*0x1410a1c24*/
                                  v116.second._Rep->_Destroy(this: v116.second._Rep); /*0x1410a1c31*/
                                  if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a1c3e*/
                                    v116.second._Rep->_Delete_this(this: v116.second._Rep); /*0x1410a1c4a*/
                                }
                              }
                              __unwind
                              {
                                std::pair<RBX::ContentId const,std::shared_ptr<rbx::signal<void (void)>>>::~pair<RBX::ContentId const,std::shared_ptr<rbx::signal<void (void)>>>(this: &v116); /*0xf1c0000000000398*/
                              }
                            }
                            __unwind
                            {
                              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v117); /*0xf1c00000000003a4*/
                            }
                            if ( v116.first._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a1c58*/
                            {
                              Ptr = v116.first._Mypair._Myval2._Bx._Ptr; /*0x1410a1c5d*/
                              if ( v116.first._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a1c6e*/
                              {
                                Ptr = *((char **)v116.first._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a1c74*/
                                if ( (unsigned __int64)(v116.first._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x1410a1c83*/
                                  _invalid_parameter_noinfo_noreturn(); /*0x1410a1d0f*/
                              }
                              operator delete(ptr: Ptr); /*0x1410a1c89*/
                            }
                            Bool = RBX::Network::NetworkStream::readBool(this: inBitstream); /*0x1410a1c97*/
                            if ( v38 != nullptr /*0x1410a1caa*/
                              && _InterlockedExchangeAdd((volatile signed __int32 *)&v38->_Uses, 0xFFFFFFFF) == 1 )
                            {
                              v38->_Destroy(this: v38); /*0x1410a1cb2*/
                              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v38->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a1cbf*/
                                v38->_Delete_this(this: v38); /*0x1410a1cc7*/
                            }
                            if ( v130 >= 0x10 ) /*0x1410a1cd6*/
                            {
                              v52 = *(void **)&name._Mypair._Myval2._Bx._Alias[8]; /*0x1410a1cdb*/
                              if ( v130 + 1 >= 0x1000 ) /*0x1410a1cec*/
                              {
                                v52 = *(void **)(*(_QWORD *)&name._Mypair._Myval2._Bx._Alias[8] - 8LL); /*0x1410a1cf2*/
                                if ( (unsigned __int64)(*(_QWORD *)&name._Mypair._Myval2._Bx._Alias[8] /*0x1410a1d01*/
                                                      - (_QWORD)v52
                                                      - 8LL) > 0x1F )
                                  _invalid_parameter_noinfo_noreturn(); /*0x1410a1d16*/
                              }
                              operator delete(ptr: v52); /*0x1410a1d03*/
                            }
                            v30 = !Bool; /*0x1410a1d08*/
                          }
                          __unwind
                          {
                            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&jobInfo._Rep); /*0xf1c00000000004b4*/
                          }
                        }
                        __unwind
                        {
                          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&name._Mypair._Myval2._Bx._Alias[8]); /*0xf1c00000000004c0*/
                        }
                      }
                      if ( !RBX::Network::NetworkStream::readBool(this: inBitstream) ) /*0x1410a1d20*/
                      {
                        do /*0x1410a20f8*/
                        {
                          v53 = RBX::Network::Replicator::getReadPayloadLimit(this); /*0x1410a1d37*/
                          RBX::Network::NetworkStream::readString( /*0x1410a1d49*/
                            this: inBitstream,
                            result: &v131,
                            maxStringReadSize: v53);
                          __eh34_enter_wind_state(16, 29); /*0xf1c0000000000380*/
                          v54 = RBX::Network::NetworkStream::readFloat(this: inBitstream); /*0x1410a1d57*/
                          v55 = RBX::Network::NetworkStream::readInt32(this: inBitstream); /*0x1410a1d62*/
                          v56 = (RBX::Reflection::Tuple *)operator new(size: 0x18u); /*0x1410a1d6a*/
                          v57 = v56; /*0x1410a1d6f*/
                          if ( v56 != nullptr ) /*0x1410a1d77*/
                          {
                            v56->values._Mypair._Myval2._Myfirst = nullptr; /*0x1410a1d79*/
                            v56->values._Mypair._Myval2._Mylast = nullptr; /*0x1410a1d7c*/
                            v56->values._Mypair._Myval2._Myend = nullptr; /*0x1410a1d80*/
                          }
                          else
                          {
                            v57 = nullptr; /*0x1410a1d86*/
                          }
                          v135._Ptr = v57; /*0x1410a1d89*/
                          __wind /*0xf1c0000000000360*/
                          {
                            v58 = operator new(size: 0x18u); /*0x1410a1d95*/
                            v59 = v58; /*0x1410a1d9a*/
                            v96 = (RBX::Reflection::Variant *)v58; /*0x1410a1d9d*/
                            if ( v58 != nullptr ) /*0x1410a1da5*/
                            {
                              *(_OWORD *)v58 = 0; /*0x1410a1daa*/
                              v58[2] = 1; /*0x1410a1dad*/
                              v58[3] = 1; /*0x1410a1db4*/
                              *(_QWORD *)v58 = std::_Ref_count<std::vector<RBX::Reflection::Variant>>::`vftable'; /*0x1410a1dc2*/
                              *((_QWORD *)v58 + 2) = v57; /*0x1410a1dc5*/
                            }
                            else
                            {
                              v59 = nullptr; /*0x1410a1dcb*/
                            }
                          }
                          __unwind
                          {
                            std::_Temporary_owner<RBX::Reflection::Tuple>::~_Temporary_owner<RBX::Reflection::Tuple>(this: &v135); /*0xf1c0000000000370*/
                          }
                          __eh34_enter_wind_state(29, 31); /*0xf1c0000000000378*/
                          v132 = v57; /*0x1410a1dce*/
                          jobInfo._Ptr = (std::vector<RBX::Reflection::Variant> *)v59; /*0x1410a1dd5*/
                          v111._type = RBX::Reflection::Type::getSingleton<float>(); /*0x1410a1de1*/
                          v111.value.holder = nullptr; /*0x1410a1de8*/
                          *(float *)v111.value.data = v54; /*0x1410a1def*/
                          v60 = rbx::implementation::typed_holder<float>::singleton(); /*0x1410a1df7*/
                          __wind /*0xf1c0000000000340*/
                          {
                            v111.value.holder = v60; /*0x1410a1dfc*/
                            v61 = v57->values._Mypair._Myval2._Mylast; /*0x1410a1e03*/
                            if ( v61 == v57->values._Mypair._Myval2._Myend ) /*0x1410a1e0b*/
                            {
                              std::vector<RBX::Reflection::Variant>::_Emplace_reallocate<RBX::Reflection::Variant>( /*0x1410a1eb8*/
                                this: &v57->values,
                                _Whereptr: v57->values._Mypair._Myval2._Mylast,
                                <_Val_0>: &v111);
                            }
                            else
                            {
                              v96 = v57->values._Mypair._Myval2._Mylast; /*0x1410a1e11*/
                              v61->_type = v111._type; /*0x1410a1e1d*/
                              v61->value.holder = nullptr; /*0x1410a1e20*/
                              v62 = v111.value.holder; /*0x1410a1e28*/
                              if ( v111.value.holder != nullptr ) /*0x1410a1e32*/
                              {
                                v111.value.holder->moveConstruct(a1: v111.value.data, a2: v61->value.data); /*0x1410a1e43*/
                                v62 = v111.value.holder; /*0x1410a1e45*/
                              }
                              v61->value.holder = v62; /*0x1410a1e4c*/
                              if ( v111.value.holder != nullptr ) /*0x1410a1e5a*/
                              {
                                v111.value.holder->destruct(a1: v111.value.data); /*0x1410a1e67*/
                                v111.value.holder = nullptr; /*0x1410a1e69*/
                              }
                              __wind /*0xf1c0000000000334*/
                              {
                                v111._type = RBX::Reflection::Type::getSingleton<void>(); /*0x1410a1e79*/
                                if ( v111.value.holder != nullptr ) /*0x1410a1e8a*/
                                {
                                  v111.value.holder->destruct(a1: v111.value.data); /*0x1410a1e97*/
                                  v111.value.holder = nullptr; /*0x1410a1e99*/
                                }
                              }
                              __unwind
                              {
                                rbx::placement_any<RBX::Reflection::Variant::Storage>::~placement_any<RBX::Reflection::Variant::Storage>(this: &v96->value); /*0xf1c0000000000128*/
                              }
                              ++v57->values._Mypair._Myval2._Mylast; /*0x1410a1ea4*/
                            }
                          }
                          __unwind
                          {
                            std::tuple<bool,RBX::Reflection::Variant>::~tuple<bool,RBX::Reflection::Variant>(this: (RBX::setupTweenUpdate::__l5::<lambda_fde46e4afccb457705ab91f32d9aea10> *)&v111); /*0xf1c0000000000350*/
                          }
                          __eh34_enter_wind_state(31, 34); /*0xf1c0000000000358*/
                          if ( v111.value.holder != nullptr ) /*0x1410a1ec8*/
                            v111.value.holder->destruct(a1: v111.value.data); /*0x1410a1ed5*/
                          if ( __eh34_unwind(34) ) /*0xf1c000000000031c*/
unwind_state_34:
                            __std_terminate(a1: v63, a2: v94); /*0xf1c00000000002d4*/
                          __eh34_exit_wind_state(34, 31); /*0xf1c0000000000320*/
                          v110._type = RBX::Reflection::Type::getSingleton<int>(); /*0x1410a1edd*/
                          v110.value.holder = nullptr; /*0x1410a1ee1*/
                          *(_DWORD *)v110.value.data = v55; /*0x1410a1ee9*/
                          v64 = rbx::implementation::typed_holder<int>::singleton(); /*0x1410a1eed*/
                          __wind /*0xf1c00000000002fc*/
                          {
                            v110.value.holder = v64; /*0x1410a1ef2*/
                            v65 = v57->values._Mypair._Myval2._Mylast; /*0x1410a1ef6*/
                            if ( v65 == v57->values._Mypair._Myval2._Myend ) /*0x1410a1efe*/
                            {
                              std::vector<RBX::Reflection::Variant>::_Emplace_reallocate<RBX::Reflection::Variant>( /*0x1410a1f7a*/
                                this: &v57->values,
                                _Whereptr: v57->values._Mypair._Myval2._Mylast,
                                <_Val_0>: &v110);
                            }
                            else
                            {
                              v96 = v57->values._Mypair._Myval2._Mylast; /*0x1410a1f00*/
                              v65->_type = v110._type; /*0x1410a1f09*/
                              v65->value.holder = nullptr; /*0x1410a1f0f*/
                              v66 = v110.value.holder; /*0x1410a1f13*/
                              if ( v110.value.holder != nullptr ) /*0x1410a1f1a*/
                              {
                                v110.value.holder->moveConstruct(a1: v110.value.data, a2: v65->value.data); /*0x1410a1f28*/
                                v66 = v110.value.holder; /*0x1410a1f2a*/
                              }
                              v65->value.holder = v66; /*0x1410a1f2e*/
                              if ( v110.value.holder != nullptr ) /*0x1410a1f39*/
                              {
                                v110.value.holder->destruct(a1: v110.value.data); /*0x1410a1f43*/
                                v110.value.holder = nullptr; /*0x1410a1f45*/
                              }
                              __wind /*0xf1c00000000002f0*/
                              {
                                v110._type = RBX::Reflection::Type::getSingleton<void>(); /*0x1410a1f4e*/
                                if ( v110.value.holder != nullptr ) /*0x1410a1f59*/
                                {
                                  v110.value.holder->destruct(a1: v110.value.data); /*0x1410a1f63*/
                                  v110.value.holder = nullptr; /*0x1410a1f65*/
                                }
                              }
                              __unwind
                              {
                                rbx::placement_any<RBX::Reflection::Variant::Storage>::~placement_any<RBX::Reflection::Variant::Storage>(this: &v96->value); /*0xf1c0000000000144*/
                              }
                              ++v57->values._Mypair._Myval2._Mylast; /*0x1410a1f69*/
                            }
                          }
                          __unwind
                          {
                            std::tuple<bool,RBX::Reflection::Variant>::~tuple<bool,RBX::Reflection::Variant>(this: (RBX::setupTweenUpdate::__l5::<lambda_fde46e4afccb457705ab91f32d9aea10> *)&v110); /*0xf1c000000000030c*/
                          }
                          __eh34_enter_wind_state(31, 34); /*0xf1c0000000000314*/
                          if ( v110.value.holder != nullptr ) /*0x1410a1f87*/
                            v110.value.holder->destruct(a1: v110.value.data); /*0x1410a1f91*/
                          if ( __eh34_unwind(34) ) /*0xf1c00000000002d0*/
                            goto unwind_state_34; /*0xf1c00000000002d0*/
                          __eh34_exit_wind_state(34, 31); /*0xf1c00000000002dc*/
                          if ( v59 != nullptr ) /*0x1410a1f97*/
                            _InterlockedIncrement(v59 + 2); /*0x1410a1f99*/
                          __wind /*0xf1c00000000002c4*/
                          {
                            v118._Ptr = (RBX::File *)v57; /*0x1410a1f9d*/
                            v118._Rep = (std::_Ref_count_base *)v59; /*0x1410a1fa4*/
                            std::string::string( /*0x1410a1fb9*/
                              this: (rtc::webrtc_checks_impl::ToStringVal *)&v115,
                              __that: (const rtc::webrtc_checks_impl::ToStringVal *)&v131);
                            __wind /*0xf1c00000000002a0*/
                            {
                              v115.second._Ptr = (const std::string *)v57; /*0x1410a1fbe*/
                              v115.second._Rep = (std::_Ref_count_base *)v59; /*0x1410a1fc5*/
                              v118 = 0; /*0x1410a1fcf*/
                              LODWORD(v95) = v95 | 4; /*0x1410a1fd7*/
                              std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<std::string,std::shared_ptr<std::vector<RBX::Reflection::Variant> const>>>( /*0x1410a1fef*/
                                this: (std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string >,std::equal_to<std::string > >,std::allocator<std::pair<std::string const ,RBX::Reflection::Variant> >,0> > *)v99.first._Ptr,
                                result: &v143,
                                <_Vals_0>: (std::pair<std::string,std::shared_ptr<std::vector<RBX::Reflection::Variant> const > > *)&v115);
                              if ( v115.second._Rep != nullptr /*0x1410a200c*/
                                && _InterlockedExchangeAdd(
                                     (volatile signed __int32 *)&v115.second._Rep->_Uses,
                                     0xFFFFFFFF) == 1 )
                              {
                                v67 = v115.second._Rep; /*0x1410a200e*/
                                v115.second._Rep->_Destroy(this: v115.second._Rep); /*0x1410a201b*/
                                if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v67->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a2028*/
                                  v115.second._Rep->_Delete_this(this: v115.second._Rep); /*0x1410a2034*/
                              }
                            }
                            __unwind
                            {
                              std::pair<RBX::ContentId const,std::shared_ptr<rbx::signal<void (void)>>>::~pair<RBX::ContentId const,std::shared_ptr<rbx::signal<void (void)>>>(this: &v115); /*0xf1c00000000002b0*/
                            }
                          }
                          __unwind
                          {
                            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v118); /*0xf1c00000000002bc*/
                          }
                          if ( v115.first._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a2042*/
                          {
                            v68 = v115.first._Mypair._Myval2._Bx._Ptr; /*0x1410a2047*/
                            if ( v115.first._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a2058*/
                            {
                              v68 = *((char **)v115.first._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a205e*/
                              if ( (unsigned __int64)(v115.first._Mypair._Myval2._Bx._Ptr - v68 - 8) > 0x1F ) /*0x1410a206d*/
                                _invalid_parameter_noinfo_noreturn(); /*0x1410a254f*/
                            }
                            operator delete(ptr: v68); /*0x1410a2073*/
                          }
                          v69 = RBX::Network::NetworkStream::readBool(this: inBitstream); /*0x1410a2081*/
                          if ( v59 != nullptr && _InterlockedExchangeAdd(v59 + 2, 0xFFFFFFFF) == 1 ) /*0x1410a2094*/
                          {
                            (**(void (__fastcall ***)(_DWORD *))v59)(a1: v59); /*0x1410a209c*/
                            if ( _InterlockedExchangeAdd(v59 + 3, 0xFFFFFFFF) == 1 ) /*0x1410a20a9*/
                              (*(void (__fastcall **)(_DWORD *))(*(_QWORD *)v59 + 8LL))(a1: v59); /*0x1410a20b1*/
                          }
                          if ( v131._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a20c0*/
                          {
                            v70 = v131._Mypair._Myval2._Bx._Ptr; /*0x1410a20c5*/
                            if ( v131._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a20d6*/
                            {
                              v70 = *((char **)v131._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a20dc*/
                              if ( (unsigned __int64)(v131._Mypair._Myval2._Bx._Ptr - v70 - 8) > 0x1F ) /*0x1410a20eb*/
                                _invalid_parameter_noinfo_noreturn(); /*0x1410a2556*/
                            }
                            operator delete(ptr: v70); /*0x1410a20f1*/
                          }
                          if ( __eh34_unwind(31) ) /*0xf1c000000000067c*/
                          {
unwind_state_31:
                            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v132); /*0xf1c0000000000680*/
                            __eh34_continue_unwinding(31, 29); /*0xf1c0000000000684*/
                          }
                          __eh34_exit_wind_state(31, 29); /*0xf1c0000000000688*/
                          if ( __eh34_unwind(29) ) /*0xf1c000000000068c*/
                          {
unwind_state_29:
                            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v131); /*0xf1c0000000000690*/
                            __eh34_continue_unwinding(29, 16); /*0xf1c0000000000694*/
                          }
                          __eh34_exit_wind_state(29, 16); /*0xf1c0000000000698*/
                        }
                        while ( !v69 ); /*0x1410a20f8*/
                        first = (char *)v98.first; /*0x1410a20fe*/
                        v7 = (std::unordered_map<std::string,RBX::Reflection::Variant> *)v157; /*0x1410a2103*/
                      }
                      v71 = RBX::Network::NetworkStream::readFloat(this: inBitstream); /*0x1410a2112*/
                      v72 = RBX::Network::NetworkStream::readFloat(this: inBitstream); /*0x1410a211d*/
                      v73 = RBX::Network::NetworkStream::readFloat(this: inBitstream); /*0x1410a2128*/
                      v74 = RBX::Network::NetworkStream::readFloat(this: inBitstream); /*0x1410a2134*/
                      v75 = RBX::Network::NetworkStream::readFloat(this: inBitstream); /*0x1410a2140*/
                      v76 = (std::unordered_map<std::string,RBX::Reflection::Variant> *)operator new(size: 0x40u); /*0x1410a2149*/
                      v158 = v76; /*0x1410a214e*/
                      __wind /*0xf1c0000000000294*/
                      {
                        if ( v76 != nullptr ) /*0x1410a2158*/
                          v76 = std::unordered_map<std::string,RBX::Reflection::Variant>::unordered_map<std::string,RBX::Reflection::Variant>(this: v76); /*0x1410a215d*/
                      }
                      __unwind
                      {
                        operator delete(ptr: v158); /*0xf1c0000000000164*/
                      }
                      v77 = result; /*0x1410a2166*/
                      std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant>>::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant>>( /*0x1410a2170*/
                        this: result,
                        _Px: v76);
                      LODWORD(v95) = v95 | 1; /*0x1410a2175*/
                      v98.first = "Avg Ping ms"; /*0x1410a2181*/
                      v98.second = v71; /*0x1410a2186*/
                      std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<char const *,float>>( /*0x1410a219c*/
                        this: result->_Ptr,
                        result: &v144,
                        <_Vals_0>: &v98);
                      v119.first = "Avg Physics Sender Pkt/s"; /*0x1410a21a8*/
                      v119.second = v72; /*0x1410a21af*/
                      std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<char const *,float>>( /*0x1410a21c9*/
                        this: result->_Ptr,
                        result: &v145,
                        <_Vals_0>: &v119);
                      v120.first = "Total Data KB/s"; /*0x1410a21d5*/
                      v120.second = v73; /*0x1410a21dc*/
                      std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<char const *,float>>( /*0x1410a21f7*/
                        this: result->_Ptr,
                        result: &v146,
                        <_Vals_0>: &v120);
                      v121.first = "Total Physics KB/s"; /*0x1410a2203*/
                      v121.second = v74; /*0x1410a220a*/
                      std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<char const *,float>>( /*0x1410a2225*/
                        this: result->_Ptr,
                        result: &v147,
                        <_Vals_0>: &v121);
                      v122.first = "Data Throughput ratio"; /*0x1410a2231*/
                      v122.second = v75; /*0x1410a2238*/
                      std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<char const *,float>>( /*0x1410a2253*/
                        this: result->_Ptr,
                        result: &v148,
                        <_Vals_0>: &v122);
                      v78 = result->_Ptr; /*0x1410a2258*/
                      if ( first != nullptr ) /*0x1410a225f*/
                        _InterlockedIncrement((volatile signed __int32 *)first + 2); /*0x1410a2261*/
                      __wind /*0xf1c000000000027c*/
                      {
                        v105.first = "DataStoreBudget"; /*0x1410a226d*/
                        v105.second._Ptr = (const std::unordered_map<std::string,RBX::Reflection::Variant> *)v107._Ptr; /*0x1410a2275*/
                        v105.second._Rep = (std::_Ref_count_base *)first; /*0x1410a2279*/
                        v107 = 0; /*0x1410a2280*/
                        __wind /*0xf1c00000000001d4*/
                        {
                          std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<char const *,std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>>( /*0x1410a2290*/
                            this: v78,
                            result: &v149,
                            <_Vals_0>: &v105);
                          if ( v105.second._Rep != nullptr /*0x1410a22aa*/
                            && _InterlockedExchangeAdd((volatile signed __int32 *)&v105.second._Rep->_Uses, 0xFFFFFFFF) == 1 )
                          {
                            v79 = v105.second._Rep; /*0x1410a22ac*/
                            v105.second._Rep->_Destroy(this: v105.second._Rep); /*0x1410a22b6*/
                            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v79->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a22c3*/
                              v105.second._Rep->_Delete_this(this: v105.second._Rep); /*0x1410a22cc*/
                          }
                          v80 = result->_Ptr; /*0x1410a22d0*/
                          v81 = (std::_Ref_count_base *)v108._Ptr; /*0x1410a22d4*/
                          if ( v108._Ptr != nullptr ) /*0x1410a22db*/
                            _InterlockedIncrement((volatile signed __int32 *)&v108._Ptr->std::enable_shared_from_this<RBX::Reflection::DescribedBase>); /*0x1410a22dd*/
                        }
                        __unwind
                        {
                          RBX::CageHSRFetchRequest::CageHSRAsset::~CageHSRAsset(this: (std::pair<RBX::Instance * const,std::shared_ptr<SearchResult> > *)&v105); /*0xf1c00000000001e4*/
                        }
                      }
                      __unwind
                      {
                        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v107); /*0xf1c00000000001f0*/
                      }
                      __wind /*0xf1c00000000001f8*/
                      {
                        __wind /*0xf1c0000000000200*/
                        {
                          v104.first = "Jobs"; /*0x1410a22e8*/
                          v104.second._Ptr = v7; /*0x1410a22ec*/
                          v104.second._Rep = v81; /*0x1410a22f0*/
                          v108 = 0; /*0x1410a22f7*/
                          std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<char const *,std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>>( /*0x1410a2307*/
                            this: v80,
                            result: &v150,
                            <_Vals_0>: &v104);
                          if ( v104.second._Rep != nullptr /*0x1410a2321*/
                            && _InterlockedExchangeAdd((volatile signed __int32 *)&v104.second._Rep->_Uses, 0xFFFFFFFF) == 1 )
                          {
                            v82 = v104.second._Rep; /*0x1410a2323*/
                            v104.second._Rep->_Destroy(this: v104.second._Rep); /*0x1410a232d*/
                            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v82->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a233a*/
                              v104.second._Rep->_Delete_this(this: v104.second._Rep); /*0x1410a2343*/
                          }
                          v83 = result->_Ptr; /*0x1410a2347*/
                          v84 = (std::_Ref_count_base *)v109._Ptr; /*0x1410a234b*/
                          if ( v109._Ptr != nullptr ) /*0x1410a2352*/
                            _InterlockedIncrement((volatile signed __int32 *)&v109._Ptr->std::enable_shared_from_this<RBX::Reflection::DescribedBase>); /*0x1410a2354*/
                        }
                        __unwind
                        {
                          RBX::CageHSRFetchRequest::CageHSRAsset::~CageHSRAsset(this: (std::pair<RBX::Instance * const,std::shared_ptr<SearchResult> > *)&v104); /*0xf1c0000000000210*/
                        }
                      }
                      __unwind
                      {
                        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v108); /*0xf1c000000000021c*/
                      }
                      __wind /*0xf1c0000000000224*/
                      {
                        __wind /*0xf1c000000000022c*/
                        {
                          v103.first = "Scripts"; /*0x1410a235f*/
                          v103.second._Ptr = (const std::unordered_map<std::string,RBX::Reflection::Variant> *)v99.first._Ptr; /*0x1410a2368*/
                          v103.second._Rep = v84; /*0x1410a236c*/
                          v109 = 0; /*0x1410a2373*/
                          std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<char const *,std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>>( /*0x1410a2381*/
                            this: v83,
                            result: &v99,
                            <_Vals_0>: &v103);
                          if ( v103.second._Rep != nullptr /*0x1410a239b*/
                            && _InterlockedExchangeAdd((volatile signed __int32 *)&v103.second._Rep->_Uses, 0xFFFFFFFF) == 1 )
                          {
                            v85 = v103.second._Rep; /*0x1410a239d*/
                            v103.second._Rep->_Destroy(this: v103.second._Rep); /*0x1410a23a7*/
                            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v85->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a23b4*/
                              v103.second._Rep->_Delete_this(this: v103.second._Rep); /*0x1410a23bd*/
                          }
                          v86 = result->_Ptr; /*0x1410a23c1*/
                          if ( v22 != nullptr ) /*0x1410a23c8*/
                            _InterlockedIncrement(v22 + 2); /*0x1410a23ca*/
                        }
                        __unwind
                        {
                          RBX::CageHSRFetchRequest::CageHSRAsset::~CageHSRAsset(this: (std::pair<RBX::Instance * const,std::shared_ptr<SearchResult> > *)&v103); /*0xf1c000000000023c*/
                        }
                      }
                      __unwind
                      {
                        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v109); /*0xf1c0000000000248*/
                      }
                      __wind /*0xf1c0000000000250*/
                      {
                        __wind /*0xf1c0000000000258*/
                        {
                          v106.first = "ServerMemoryTree"; /*0x1410a23d6*/
                          v106.second._Ptr = (const std::unordered_map<std::string,RBX::Reflection::Variant> *)v100._Ptr; /*0x1410a23df*/
                          v106.second._Rep = (std::_Ref_count_base *)v22; /*0x1410a23e3*/
                          v100 = 0; /*0x1410a23ea*/
                          std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<char const *,std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>>( /*0x1410a23fb*/
                            this: v86,
                            result: &v151,
                            <_Vals_0>: &v106);
                          if ( v106.second._Rep != nullptr /*0x1410a2415*/
                            && _InterlockedExchangeAdd((volatile signed __int32 *)&v106.second._Rep->_Uses, 0xFFFFFFFF) == 1 )
                          {
                            v87 = v106.second._Rep; /*0x1410a2417*/
                            v106.second._Rep->_Destroy(this: v106.second._Rep); /*0x1410a2421*/
                            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v87->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a242e*/
                              v106.second._Rep->_Delete_this(this: v106.second._Rep); /*0x1410a2437*/
                          }
                        }
                        __unwind
                        {
                          RBX::CageHSRFetchRequest::CageHSRAsset::~CageHSRAsset(this: (std::pair<RBX::Instance * const,std::shared_ptr<SearchResult> > *)&v106); /*0xf1c0000000000268*/
                        }
                      }
                      __unwind
                      {
                        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v100); /*0xf1c0000000000274*/
                      }
                      v88 = result->_Ptr; /*0x1410a243b*/
                      other._type = RBX::Reflection::Type::getSingleton<std::string>(); /*0x1410a2444*/
                      other.value.holder = nullptr; /*0x1410a244b*/
                      std::string::string( /*0x1410a2461*/
                        this: (rtc::webrtc_checks_impl::ToStringVal *)other.value.data,
                        __that: (const rtc::webrtc_checks_impl::ToStringVal *)&v102[16]);
                      if ( __TSS0__1__singleton___typed_holder_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___implementation_rbx__SAPEBV234_XZ_4HA > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x1410a2489*/
                      {
                        Init_thread_header(pOnce: &__TSS0__1__singleton___typed_holder_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___implementation_rbx__SAPEBV234_XZ_4HA); /*0x1410a26e9*/
                        if ( __TSS0__1__singleton___typed_holder_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___implementation_rbx__SAPEBV234_XZ_4HA == -1 ) /*0x1410a26f5*/
                        {
                          `rbx::implementation::typed_holder<std::string>::singleton'::`2'::s.construct = rbx::implementation::typed_holder<RBX::ContentId>::construct_func; /*0x1410a2702*/
                          `rbx::implementation::typed_holder<std::string>::singleton'::`2'::s.moveConstruct = rbx::implementation::typed_holder<RBX::ContentId>::moveConstruct_func; /*0x1410a2710*/
                          `rbx::implementation::typed_holder<std::string>::singleton'::`2'::s.destruct = (void (__fastcall *)(char *))RBX::Graphics::ProfilerAdorn::Item::~Item; /*0x1410a271e*/
                          Init_thread_footer(pOnce: &__TSS0__1__singleton___typed_holder_V__basic_string_DU__char_traits_D_std__V__allocator_D_2__std___implementation_rbx__SAPEBV234_XZ_4HA); /*0x1410a272c*/
                        }
                      }
                      other.value.holder = &`rbx::implementation::typed_holder<std::string>::singleton'::`2'::s; /*0x1410a2496*/
                      __wind /*0xf1c00000000001c8*/
                      {
                        v153.first = "ServerScriptProfilingData"; /*0x1410a24a4*/
                        RBX::Reflection::Variant::Variant(this: &v153.second, &other); /*0x1410a24b9*/
                        LODWORD(v95) = v95 | 8; /*0x1410a24be*/
                        __wind /*0xf1c0000000000184*/
                        {
                          std::_Hash<std::_Umap_traits<std::string,RBX::Reflection::Variant,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,0>>::emplace<std::pair<char const *,RBX::Reflection::Variant>>( /*0x1410a24d4*/
                            this: v88,
                            result: &v152,
                            <_Vals_0>: &v153);
                        }
                        __unwind
                        {
                          std::pair<RBX::Reflection::PropertyDescriptor const *,RBX::Reflection::Variant>::~pair<RBX::Reflection::PropertyDescriptor const *,RBX::Reflection::Variant>(this: (std::pair<unsigned __int64,RBX::LuaWebService::CachedLuaWebServiceInfo> *)&v153); /*0xf1c0000000000194*/
                        }
                        __wind /*0xf1c000000000019c*/
                        {
                          if ( v153.second.value.holder != nullptr ) /*0x1410a24e4*/
                            v153.second.value.holder->destruct(a1: v153.second.value.data); /*0x1410a24f1*/
                        }
                        __unwind
                        {
                          __std_terminate(a1: v89, a2: v94); /*0xf1c0000000000174*/
                        }
                      }
                      __unwind
                      {
                        std::tuple<bool,RBX::Reflection::Variant>::~tuple<bool,RBX::Reflection::Variant>(this: (RBX::setupTweenUpdate::__l5::<lambda_fde46e4afccb457705ab91f32d9aea10> *)&other); /*0xf1c00000000001b8*/
                      }
                      __eh34_enter_wind_state(16, 51); /*0xf1c00000000001c0*/
                      if ( other.value.holder != nullptr ) /*0x1410a24fe*/
                      {
                        if ( __eh34_unwind(51) ) /*0xf1c00000000006b4*/
                          goto unwind_state_51; /*0xf1c00000000006b4*/
                        __eh34_exit_wind_state(51, 16); /*0xf1c00000000006b8*/
                        __eh34_enter_wind_state(16, 29); /*0xf1c00000000006bc*/
                        __eh34_enter_wind_state(29, 31); /*0xf1c00000000006c0*/
                        destruct = other.value.holder->destruct; /*0x1410a2500*/
                        if ( (char *)destruct == (char *)RBX::Graphics::ProfilerAdorn::Item::~Item ) /*0x1410a250e*/
                        {
                          if ( *(_QWORD *)&other.value.data[24] >= 0x10u ) /*0x1410a251b*/
                          {
                            v91 = *(void **)other.value.data; /*0x1410a2520*/
                            if ( (unsigned __int64)(*(_QWORD *)&other.value.data[24] + 1LL) >= 0x1000 ) /*0x1410a2531*/
                            {
                              v91 = *(void **)(*(_QWORD *)other.value.data - 8LL); /*0x1410a2537*/
                              if ( (unsigned __int64)(*(_QWORD *)other.value.data - (_QWORD)v91 - 8LL) > 0x1F ) /*0x1410a2546*/
                                _invalid_parameter_noinfo_noreturn(); /*0x1410a2548*/
                            }
                            operator delete(ptr: v91); /*0x1410a255d*/
                          }
                        }
                        else
                        {
                          destruct(a1: other.value.data); /*0x1410a256b*/
                        }
                        if ( __eh34_unwind(31) ) /*0xf1c00000000006a0*/
                          goto unwind_state_31; /*0xf1c00000000006a0*/
                        __eh34_exit_wind_state(31, 29); /*0xf1c00000000006a4*/
                        if ( __eh34_unwind(29) ) /*0xf1c00000000006a8*/
                          goto unwind_state_29; /*0xf1c00000000006a8*/
                        __eh34_exit_wind_state(29, 16); /*0xf1c00000000006ac*/
                      }
                      else
                      {
                        if ( __eh34_unwind(51) ) /*0xf1c0000000000668*/
unwind_state_51:
                          __std_terminate(a1: v89, a2: v94); /*0xf1c000000000066c*/
                        __eh34_exit_wind_state(51, 16); /*0xf1c0000000000674*/
                      }
                      goto LABEL_382; /*0xf1c00000000006b0*/
                    }
LABEL_45:
                    *(_OWORD *)v102 = 0; /*0x1410a17b1*/
                    if ( first != nullptr ) /*0x1410a17bd*/
                      _InterlockedIncrement((volatile signed __int32 *)first + 2); /*0x1410a17bf*/
                    *(_QWORD *)v102 = v15; /*0x1410a17c4*/
                    *(_QWORD *)&v102[8] = first; /*0x1410a17c9*/
                    RBX::Network::Replicator::StatsItem::readDataStoreStats( /*0x1410a17d5*/
                      inBitstream,
                      dataStoreBudget: (std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> > *)v102);
                    goto LABEL_48; /*0x1410a17d5*/
                  }
                }
                else
                {
                  v28 = RBX::Network::Replicator::StatsItem::readServerScriptProfilingData( /*0x1410a1705*/
                          result: &v141,
                          replicator: this,
                          inBitstream);
                  if ( &v102[16] != (_BYTE *)v28 ) /*0x1410a1711*/
                  {
                    *(std::_String_val<std::_Simple_types<char> >::_Bxty *)&v102[16] = v28->_Mypair._Myval2._Bx; /*0x1410a1716*/
                    *(_OWORD *)&v102[32] = *(_OWORD *)&v28->_Mypair._Myval2._Mysize; /*0x1410a171e*/
                    v28->_Mypair._Myval2._Mysize = 0; /*0x1410a1722*/
                    v28->_Mypair._Myval2._Myres = 15; /*0x1410a1726*/
                    v28->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410a172e*/
                  }
                  if ( v141._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a173b*/
                  {
                    v29 = v141._Mypair._Myval2._Bx._Ptr; /*0x1410a1740*/
                    if ( v141._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a1751*/
                    {
                      v29 = *((char **)v141._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a1757*/
                      if ( (unsigned __int64)(v141._Mypair._Myval2._Bx._Ptr - v29 - 8) > 0x1F ) /*0x1410a1766*/
                        _invalid_parameter_noinfo_noreturn(); /*0x1410a1768*/
                    }
                    operator delete(ptr: v29); /*0x1410a176f*/
                  }
                }
                v101 = 0; /*0x1410a177e*/
                if ( v22 != nullptr ) /*0x1410a1787*/
                  _InterlockedIncrement(v22 + 2); /*0x1410a1789*/
                v101._Ptr = (std::unordered_map<std::string,RBX::Reflection::Variant> *)v100._Ptr; /*0x1410a1793*/
                v101._Rep = (std::_Ref_count_base *)v22; /*0x1410a1798*/
                RBX::Network::Replicator::StatsItem::readServerMemoryStats(inBitstream, serverMemoryValueTable: &v101); /*0x1410a17a5*/
                goto LABEL_45; /*0x1410a17aa*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v102[16]); /*0xf1c000000000051c*/
              }
LABEL_382:
              if ( *(_QWORD *)&v102[40] >= 0x10u ) /*0x1410a2576*/
              {
                v92 = *(void **)&v102[16]; /*0x1410a257b*/
                if ( (unsigned __int64)(*(_QWORD *)&v102[40] + 1LL) >= 0x1000 ) /*0x1410a2589*/
                {
                  v92 = *(void **)(*(_QWORD *)&v102[16] - 8LL); /*0x1410a258f*/
                  if ( (unsigned __int64)(*(_QWORD *)&v102[16] - (_QWORD)v92 - 8LL) > 0x1F ) /*0x1410a259e*/
                    _invalid_parameter_noinfo_noreturn(); /*0x1410a25a0*/
                }
                operator delete(ptr: v92); /*0x1410a25a7*/
              }
              if ( v97 != nullptr && _InterlockedExchangeAdd(v97 + 2, 0xFFFFFFFF) == 1 ) /*0x1410a25c2*/
              {
                (**(void (__fastcall ***)(volatile signed __int32 *))v97)(a1: v97); /*0x1410a25ca*/
                if ( _InterlockedExchangeAdd(v97 + 3, 0xFFFFFFFF) == 1 ) /*0x1410a25d7*/
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v97 + 8LL))(a1: v97); /*0x1410a25df*/
              }
              if ( v22 != nullptr && _InterlockedExchangeAdd(v22 + 2, 0xFFFFFFFF) == 1 ) /*0x1410a25f4*/
              {
                (**(void (__fastcall ***)(volatile signed __int32 *))v22)(a1: v22); /*0x1410a25fd*/
                if ( _InterlockedExchangeAdd(v22 + 3, 0xFFFFFFFF) == 1 ) /*0x1410a260b*/
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 8LL))(a1: v22); /*0x1410a2614*/
              }
              if ( first != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)first + 2, 0xFFFFFFFF) == 1 ) /*0x1410a2629*/
              {
                (**(void (__fastcall ***)(char *))first)(a1: first); /*0x1410a2631*/
                if ( _InterlockedExchangeAdd((volatile signed __int32 *)first + 3, 0xFFFFFFFF) == 1 ) /*0x1410a263f*/
                  (*(void (__fastcall **)(char *))(*(_QWORD *)first + 8LL))(a1: first); /*0x1410a2647*/
              }
              if ( v84 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v84->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410a265b*/
              {
                v84->_Destroy(this: v84); /*0x1410a2663*/
                if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v84->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a2670*/
                  v84->_Delete_this(this: v84); /*0x1410a2678*/
              }
              if ( v81 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v81->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410a268c*/
              {
                v81->_Destroy(this: v81); /*0x1410a2694*/
                if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v81->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a26a0*/
                  v81->_Delete_this(this: v81); /*0x1410a26a8*/
              }
              v93 = v77; /*0x1410a26ab*/
            }
            __unwind
            {
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&DEPRECATED_serverMemoryByDeveloperTagValueTable._Rep); /*0xf1c0000000000528*/
            }
          }
          __unwind
          {
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&serverMemoryBreakdownValueTable._Rep); /*0xf1c0000000000534*/
          }
        }
        __unwind
        {
          std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&dataStoreBudget._Rep); /*0xf1c0000000000540*/
        }
      }
      __unwind
      {
        std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&scripts._Rep); /*0xf1c000000000054c*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&jobs._Rep); /*0xf1c0000000000558*/
    }
  }
  __unwind
  {
    if ( (v95 & 1) != 0 ) /*0x1431ec201*/
    {
      LODWORD(v95) = v95 & 0xFFFFFFFE; /*0x1431ec203*/
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)result); /*0x1431ec20e*/
    }
  }
  return v93; /*0x1410a26ae*/
}

// Address: 0x1410a2740 | Name: ?readStreamDataInfoItem@ClientReplicator@Network@RBX@@AEAAXPEAVDeserializedStreamDataInfoItem@23@@Z
void __fastcall RBX::Network::ClientReplicator::readStreamDataInfoItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedStreamDataInfoItem *item)
{
  RBX::Network::ClientReplicator::GCJob *Ptr; // rcx

  Ptr = this->gcJob._Ptr; /*0x1410a2740*/
  if ( Ptr != nullptr ) /*0x1410a274a*/
    RBX::Network::ClientReplicator::GCJob::setServerStreamingMetadata( /*0x1410a2754*/
      this: Ptr,
      serverStreamCenter: &item->serverCenterId,
      serverCompletedRadius: &item->radiusCompleted);
}

// Address: 0x1410a2760 | Name: ?readStreamDataItem@ClientReplicator@Network@RBX@@AEAAXPEAVDeserializedStreamDataItem@23@@Z
void __fastcall RBX::Network::ClientReplicator::readStreamDataItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedStreamDataItem *item)
{
  int successorBitMask; // ecx
  int z; // eax
  RBX::Network::ClientReplicator::GCJob *Ptr; // rcx
  int v7; // eax
  int v8; // edi
  RBX::Time *v9; // rax
  __m128d v10; // xmm1
  RBX::StreamRegion::Id id; // [rsp+20h] [rbp-18h] BYREF
  RBX::Timer<2> timer; // [rsp+40h] [rbp+8h] BYREF
  RBX::Time result; // [rsp+48h] [rbp+10h] BYREF

  RBX::Time::now<2>(result: &timer.start); /*0x1410a2775*/
  successorBitMask = item->successorBitMask; /*0x1410a277f*/
  z = item->id.internalValue.z; /*0x1410a2782*/
  *(_QWORD *)&id.internalValue.x = *(_QWORD *)&item->id.internalValue.x; /*0x1410a2785*/
  id.internalValue.z = z; /*0x1410a278b*/
  switch ( successorBitMask ) /*0x1410a2792*/
  {
    case 3: /*0x1410a2792*/
      id.internalValue.x = this->lastReadStreamId.internalValue.x + 1; /*0x1410a279c*/
      id.internalValue.y = this->lastReadStreamId.internalValue.y; /*0x1410a27a6*/
      z = this->lastReadStreamId.internalValue.z; /*0x1410a27aa*/
      break;
    case 1: /*0x1410a2792*/
      id.internalValue.x = this->lastReadStreamId.internalValue.x; /*0x1410a27bd*/
      id.internalValue.y = this->lastReadStreamId.internalValue.y + 1; /*0x1410a27c9*/
      z = this->lastReadStreamId.internalValue.z; /*0x1410a27cd*/
      break;
    case 2: /*0x1410a2792*/
      id.internalValue.x = this->lastReadStreamId.internalValue.x; /*0x1410a27e0*/
      id.internalValue.y = this->lastReadStreamId.internalValue.y; /*0x1410a27ea*/
      z = this->lastReadStreamId.internalValue.z + 1; /*0x1410a27f4*/
      break;
    default:
      goto LABEL_8; /*0x1410a27d8*/
  }
  id.internalValue.z = z; /*0x1410a27f6*/
LABEL_8:
  Ptr = this->gcJob._Ptr; /*0x1410a27fa*/
  *(_QWORD *)&this->lastReadStreamId.internalValue.x = *(_QWORD *)&id.internalValue.x; /*0x1410a2807*/
  this->lastReadStreamId.internalValue.z = z; /*0x1410a280f*/
  if ( Ptr != nullptr ) /*0x1410a2818*/
    RBX::Network::ClientReplicator::GCJob::insertRegion(this: Ptr, &id, streamed: true); /*0x1410a2822*/
  if ( item->deserializedJoinDataItem._Ptr != nullptr ) /*0x1410a282e*/
  {
    v7 = ((__int64 (__fastcall *)(RBX::Network::ClientReplicator *))this->processDeserializedJoinDataItem)(a1: this); /*0x1410a283a*/
    this->numInstancesRead += v7; /*0x1410a2840*/
    v8 = v7; /*0x1410a2846*/
    if ( v7 > 0 ) /*0x1410a284a*/
    {
      if ( RBX::Time::now<1>(&result)->sec - this->streamDataPerSec.timer.start.sec >= this->streamDataPerSec.interval ) /*0x1410a286e*/
      {
        *(_QWORD *)&this->streamDataPerSec.valueLastInterval = (unsigned int)this->streamDataPerSec.valueCurrentInterval; /*0x1410a287b*/
        RBX::Time::now<1>(&result); /*0x1410a288b*/
        this->streamDataPerSec.timer.start = result; /*0x1410a2896*/
      }
      ++this->streamDataPerSec.valueCurrentInterval; /*0x1410a289e*/
      RBX::RunningAverage<double,double>::sample(this: &this->avgInstancesPerStreamData, value: (double)v8); /*0x1410a28b3*/
      v9 = RBX::Time::now<2>(&result); /*0x1410a28bd*/
      RBX::RunningAverage<double,double>::sample(this: &this->avgStreamDataReadTime, value: v9->sec - timer.start.sec); /*0x1410a28d3*/
      v10 = (__m128d)*(unsigned __int64 *)&RBX::Time::now<2>(&result)->sec; /*0x1410a28e9*/
      v10.m128d_f64[0] = (v10.m128d_f64[0] - timer.start.sec) * 1000.0; /*0x1410a28f3*/
      *(__m128d *)&this->streamingCurrentFrameTime = _mm_add_pd( /*0x1410a2903*/
                                                       *(__m128d *)&this->streamingCurrentFrameTime,
                                                       _mm_unpacklo_pd(v10, v10));
    }
  }
}

// Address: 0x1410a2920 | Name: ?readStreamPrefetchDataInfoItem@ClientReplicator@Network@RBX@@AEAAXPEAVDeserializedStreamPrefetchDataInfoItem@23@@Z
void __fastcall RBX::Network::ClientReplicator::readStreamPrefetchDataInfoItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedStreamPrefetchDataInfoItem *item)
{
  RBX::Network::ClientReplicator::GCJob *Ptr; // rcx

  Ptr = this->gcJob._Ptr; /*0x1410a2920*/
  if ( Ptr != nullptr ) /*0x1410a292d*/
    RBX::Network::ClientReplicator::GCJob::setServerStreamingPrefetchMetadata( /*0x1410a293c*/
      this: Ptr,
      serverStreamCenter: &item->serverCenterId,
      serverCompletedRadius: item->radiusCompleted,
      prefetchRequestId: item->requestId);
}

// Address: 0x1410a2950 | Name: ?readStreamPrefetchRequestItem@ClientReplicator@Network@RBX@@AEAAXPEAVDeserializedStreamPrefetchRequestItem@23@@Z
void __fastcall RBX::Network::ClientReplicator::readStreamPrefetchRequestItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedStreamPrefetchRequestItem *item)
{
  RBX::Network::ClientReplicator::GCJob *Ptr; // rcx

  Ptr = this->gcJob._Ptr; /*0x1410a2950*/
  if ( Ptr != nullptr ) /*0x1410a295d*/
  {
    if ( DFFlag::AsyncStreamingNoBlockGC.value ) /*0x1410a2966*/
      RBX::Network::ClientReplicator::GCJob::setStartedPrefetch( /*0x1410a2979*/
        this: Ptr,
        position: &item->position,
        prefetchRequestId: item->requestId,
        timeoutSeconds: item->timeOut);
    else
      RBX::Network::ClientReplicator::GCJob::setServerStartedPrefetch(this: Ptr); /*0x1410a2966*/
  }
}

// Address: 0x1410a2980 | Name: ?readTagItem@ClientReplicator@Network@RBX@@IEAAXPEAVDeserializedTagItem@23@@Z
void __fastcall RBX::Network::ClientReplicator::readTagItem(
        RBX::Network::ClientReplicator *this,
        RBX::Network::DeserializedTagItem *item)
{
  RBX::Network::ClientReplicator::processTag(this, tag: item->id); /*0x1410a2983*/
}

// Address: 0x1410a2990 | Name: ?recordRegionRemovalStats@ClientReplicator@Network@RBX@@MEAAXI@Z
void __fastcall RBX::Network::ClientReplicator::recordRegionRemovalStats(
        RBX::Network::ClientReplicator *this,
        unsigned int numGuids)
{
  unsigned int *p_maxGuidsPerRegionRemovalItem; // rax
  unsigned int v3; // eax
  unsigned int v4; // [rsp+10h] [rbp+10h] BYREF

  v4 = numGuids; /*0x1410a2997*/
  p_maxGuidsPerRegionRemovalItem = &v4; /*0x1410a299e*/
  if ( numGuids < this->maxGuidsPerRegionRemovalItem ) /*0x1410a29a3*/
    p_maxGuidsPerRegionRemovalItem = &this->maxGuidsPerRegionRemovalItem; /*0x1410a29a3*/
  v3 = *p_maxGuidsPerRegionRemovalItem; /*0x1410a29a7*/
  ++this->numRegionRemovalItems; /*0x1410a29a9*/
  this->maxGuidsPerRegionRemovalItem = v3; /*0x1410a29af*/
}

// Address: 0x1410a29c0 | Name: ?recordTerrainDataStats@ClientReplicator@Network@RBX@@EEAAXN@Z
void __fastcall RBX::Network::ClientReplicator::recordTerrainDataStats(
        RBX::Network::ClientReplicator *this,
        long double deltaSeconds)
{
  RBX::Time result; // [rsp+40h] [rbp+8h] BYREF

  if ( RBX::Time::now<1>(&result)->sec - this->terrainPerSec.timer.start.sec >= this->terrainPerSec.interval ) /*0x1410a29ef*/
  {
    *(_QWORD *)&this->terrainPerSec.valueLastInterval = (unsigned int)this->terrainPerSec.valueCurrentInterval; /*0x1410a29fc*/
    RBX::Time::now<1>(&result); /*0x1410a2a0c*/
    this->terrainPerSec.timer.start = result; /*0x1410a2a17*/
  }
  ++this->terrainPerSec.valueCurrentInterval; /*0x1410a2a1f*/
  RBX::RunningAverage<double,double>::sample(this: &this->avgTerrainDataReadTime, value: deltaSeconds); /*0x1410a2a39*/
}

// Address: 0x1410a2a40 | Name: ?renderStreamedRegions@ClientReplicator@Network@RBX@@QEAAXPEAVAdorn@3@@Z
void __fastcall RBX::Network::ClientReplicator::renderStreamedRegions(
        RBX::Network::ClientReplicator *this,
        RBX::Adorn *adorn)
{
  RBX::Network::ClientReplicator::GCJob *Ptr; // rcx

  Ptr = this->gcJob._Ptr; /*0x1410a2a40*/
  if ( Ptr != nullptr ) /*0x1410a2a4a*/
    RBX::Network::ClientReplicator::GCJob::render3dAdorn(this: Ptr, adorn); /*0x1410a2a4a*/
}

// Address: 0x1410a2a60 | Name: ?replicatorOnChildAdded@ClientReplicator@Network@RBX@@MEAAXAEBV?$shared_ptr@VInstance@RBX@@@std@@0@Z
void __fastcall RBX::Network::ClientReplicator::replicatorOnChildAdded(
        RBX::Network::ClientReplicator *this,
        const std::shared_ptr<RBX::Instance> *instance,
        const std::shared_ptr<RBX::Instance> *newParent)
{
  RBX::Network::StreamingSolver *Ptr; // rcx
  RBX::Network::ClientReplicator::GCJob *v6; // rcx

  if ( RBX::Network::StreamingSolver::isSolverEnabled() ) /*0x1410a2a70*/
  {
    Ptr = this->streamingSolver._Ptr; /*0x1410a2a79*/
    if ( Ptr != nullptr ) /*0x1410a2a83*/
      RBX::Network::StreamingSolver::onChildAdded(this: Ptr, child: instance); /*0x1410a2a92*/
  }
  else
  {
    v6 = this->gcJob._Ptr; /*0x1410a2a97*/
    if ( v6 != nullptr ) /*0x1410a2aa1*/
      RBX::Network::ClientReplicator::GCJob::onChildAdded_deprecated(this: v6, child: instance); /*0x1410a2aa6*/
  }
}

// Address: 0x1410a2ac0 | Name: ?replicatorOnChildRemoved@ClientReplicator@Network@RBX@@MEAAXAEBV?$shared_ptr@VInstance@RBX@@@std@@0@Z
void __fastcall RBX::Network::ClientReplicator::replicatorOnChildRemoved(
        RBX::Network::ClientReplicator *this,
        const std::shared_ptr<RBX::Instance> *instance,
        const std::shared_ptr<RBX::Instance> *oldParent)
{
  RBX::Network::StreamingSolver *Ptr; // rcx
  RBX::Network::ClientReplicator::GCJob *v7; // rcx

  if ( RBX::Network::StreamingSolver::isSolverEnabled() ) /*0x1410a2ad8*/
  {
    Ptr = this->streamingSolver._Ptr; /*0x1410a2ae1*/
    if ( Ptr != nullptr ) /*0x1410a2aeb*/
      RBX::Network::StreamingSolver::onChildRemoved(this: Ptr, child: instance, oldParent); /*0x1410a2b02*/
  }
  else
  {
    v7 = this->gcJob._Ptr; /*0x1410a2b07*/
    if ( v7 != nullptr ) /*0x1410a2b11*/
      RBX::Network::ClientReplicator::GCJob::onChildRemoved_deprecated(this: v7, child: instance, oldParent); /*0x1410a2b19*/
  }
}

// Address: 0x1410a2b30 | Name: ?requestProfilerData@ClientReplicator@Network@RBX@@QEAAXHH@Z
void __fastcall RBX::Network::ClientReplicator::requestProfilerData(
        RBX::Network::ClientReplicator *this,
        int profilerFrameRate,
        int profilerCaptTime)
{
  int v3; // edi
  int v4; // ebx
  int v6; // eax
  int v7; // eax
  Luau::InternalErrorReporter *v8; // rdi
  std::_Func_base<void,char const *>_vtbl *v9; // rbx
  unsigned __int8 *Myfirst; // rcx
  RakNet::RakNetGUID v11; // [rsp+40h] [rbp-29h] BYREF
  RakNet::SystemAddress v12; // [rsp+50h] [rbp-19h] BYREF
  RBX::Network::NetworkStream stream; // [rsp+70h] [rbp+7h] BYREF
  int inByteArray; // [rsp+D0h] [rbp+67h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+E8h] [rbp+7Fh] BYREF

  v3 = profilerCaptTime; /*0x1410a2b4a*/
  v4 = profilerFrameRate; /*0x1410a2b4d*/
  if ( !this->isProfilingRequested ) /*0x1410a2b59*/
  {
    this->isProfilingRequested = true; /*0x1410a2b5f*/
    if ( profilerFrameRate <= 0 ) /*0x1410a2b6b*/
      v4 = 0; /*0x1410a2b6b*/
    if ( profilerCaptTime <= 0 ) /*0x1410a2b72*/
      v3 = 0; /*0x1410a2b72*/
    RBX::Network::NetworkStream::NetworkStream(this: &stream); /*0x1410a2b7a*/
    LOBYTE(inByteArray) = -103; /*0x1410a2b80*/
    __wind /*0xf1c0000000000010*/
    {
      RBX::Network::NetworkStream::writeBytes(this: &stream, &inByteArray, numberOfBytesToWrite: 1u); /*0x1410a2b90*/
      inByteArray = 1; /*0x1410a2b95*/
      RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x1410a2ba8*/
      RBX::Network::NetworkStream::writeBytes(this: &stream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x1410a2bb9*/
      v6 = DFInt::DebugClientSvrProfilerFramesOverride; /*0x1410a2bbe*/
      if ( v4 > 0 ) /*0x1410a2bc6*/
        v6 = v4; /*0x1410a2bc6*/
      inByteArray = v6; /*0x1410a2bc9*/
      RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x1410a2bd8*/
      RBX::Network::NetworkStream::writeBytes(this: &stream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x1410a2be9*/
      v7 = DFInt::DebugClientSvrProfilerCaptTimeOverride; /*0x1410a2bee*/
      if ( v3 > 0 ) /*0x1410a2bf6*/
        v7 = v3; /*0x1410a2bf6*/
      inByteArray = v7; /*0x1410a2bf9*/
      RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x1410a2c08*/
      RBX::Network::NetworkStream::writeBytes(this: &stream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x1410a2c19*/
      v8 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410a2c2a*/
      v9 = v8->onInternalError._Mystorage._Ptrs[0][20].__vftable; /*0x1410a2c30*/
      RakNet::RakNetGUID::RakNetGUID(this: &v11); /*0x1410a2c3b*/
      RakNet::SystemAddress::SystemAddress(this: &v12); /*0x1410a2c44*/
      v11 = RakNet::UNASSIGNED_RAKNET_GUID_22; /*0x1410a2c50*/
      RakNet::SystemAddress::operator=(this: &v12, input: &this->remotePlayerRakNetAddress); /*0x1410a2c6a*/
      ((void (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::NetworkStream *, __int64, __int64, _BYTE, RakNet::RakNetGUID *, _BYTE, _DWORD))v9)( /*0x1410a2c96*/
        a1: v8,
        a2: &stream,
        a3: 2,
        a4: 3,
        a5: 0,
        a6: &v11,
        a7: 0,
        a8: 0);
    }
    __unwind
    {
      RBX::Network::NetworkStream::~NetworkStream(this: &stream); /*0xf1c0000000000008*/
    }
    Myfirst = stream.dataVector._Mypair._Myval2._Myfirst; /*0x1410a2c99*/
    if ( stream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x1410a2ca0*/
    {
      if ( (unsigned __int8 *)(stream.dataVector._Mypair._Myval2._Myend - stream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x1410a2cb3*/
      {
        Myfirst = *((unsigned __int8 **)stream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x1410a2cb9*/
        if ( (unsigned __int64)(stream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x1410a2cc8*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410a2cca*/
      }
      operator delete(ptr: Myfirst); /*0x1410a2cd1*/
    }
  }
}

// Address: 0x1410a2cf0 | Name: ?requestServerScriptProfiling@ClientReplicator@Network@RBX@@QEAAX_N@Z
void __fastcall RBX::Network::ClientReplicator::requestServerScriptProfiling(
        RBX::Network::ClientReplicator *this,
        bool start)
{
  Luau::InternalErrorReporter *v4; // rdi
  std::_Func_base<void,char const *>_vtbl *v5; // rbx
  unsigned __int8 *Myfirst; // rcx
  RakNet::RakNetGUID v7; // [rsp+40h] [rbp-78h] BYREF
  RakNet::SystemAddress v8; // [rsp+50h] [rbp-68h] BYREF
  RBX::Network::NetworkStream bitStream; // [rsp+70h] [rbp-48h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+C0h] [rbp+8h] BYREF
  int inByteArray; // [rsp+C8h] [rbp+10h] BYREF

  RBX::Network::NetworkStream::NetworkStream(this: &bitStream); /*0x1410a2d0d*/
  LOBYTE(inByteArray) = -98; /*0x1410a2d13*/
  __wind /*0xf1c0000000000010*/
  {
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x1410a2d2e*/
    inByteArray = 1; /*0x1410a2d33*/
    RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x1410a2d54*/
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x1410a2d6c*/
    LOBYTE(inByteArray) = start; /*0x1410a2d71*/
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x1410a2d8b*/
    v4 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410a2d9c*/
    v5 = v4->onInternalError._Mystorage._Ptrs[0][20].__vftable; /*0x1410a2da2*/
    RakNet::RakNetGUID::RakNetGUID(this: &v7); /*0x1410a2dae*/
    RakNet::SystemAddress::SystemAddress(this: &v8); /*0x1410a2db8*/
    v7 = RakNet::UNASSIGNED_RAKNET_GUID_22; /*0x1410a2dc4*/
    RakNet::SystemAddress::operator=(this: &v8, input: &this->remotePlayerRakNetAddress); /*0x1410a2de1*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::NetworkStream *, __int64))v5)( /*0x1410a2e14*/
      a1: v4,
      a2: &bitStream,
      a3: 2);
  }
  __unwind
  {
    RBX::Network::NetworkStream::~NetworkStream(this: &bitStream); /*0xf1c0000000000008*/
  }
  Myfirst = bitStream.dataVector._Mypair._Myval2._Myfirst; /*0x1410a2e17*/
  if ( bitStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x1410a2e22*/
  {
    if ( (unsigned __int8 *)(bitStream.dataVector._Mypair._Myval2._Myend - bitStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x1410a2e39*/
    {
      Myfirst = *((unsigned __int8 **)bitStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x1410a2e3f*/
      if ( (unsigned __int64)(bitStream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x1410a2e4e*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410a2e50*/
    }
    operator delete(ptr: Myfirst); /*0x1410a2e57*/
  }
}

// Address: 0x1410a2e80 | Name: ?requestServerStats@ClientReplicator@Network@RBX@@QEAAX_N@Z
void __fastcall RBX::Network::ClientReplicator::requestServerStats(RBX::Network::ClientReplicator *this, bool request)
{
  Luau::InternalErrorReporter *v4; // rdi
  std::_Func_base<void,char const *>_vtbl *v5; // rbx
  unsigned __int8 *Myfirst; // rcx
  RakNet::RakNetGUID v7; // [rsp+40h] [rbp-29h] BYREF
  RakNet::SystemAddress v8; // [rsp+50h] [rbp-19h] BYREF
  RBX::Network::NetworkStream bitStream; // [rsp+70h] [rbp+7h] BYREF
  unsigned __int8 inOutByteArray; // [rsp+D0h] [rbp+67h] BYREF
  int inByteArray; // [rsp+D8h] [rbp+6Fh] BYREF

  RBX::Network::NetworkStream::NetworkStream(this: &bitStream); /*0x1410a2e9e*/
  LOBYTE(inByteArray) = -106; /*0x1410a2ea4*/
  __wind /*0xf1c0000000000010*/
  {
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x1410a2eb6*/
    LOBYTE(inByteArray) = request; /*0x1410a2ebb*/
    RBX::Network::NetworkStream::writeBytes(this: &bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x1410a2ecc*/
    if ( request ) /*0x1410a2ed3*/
    {
      inByteArray = 7; /*0x1410a2eea*/
      if ( !FFlag::StatsVersion7.value ) /*0x1410a2ef1*/
        inByteArray = 6; /*0x1410a2ef3*/
      RBX::Network::NetworkStream::ReverseBytes((unsigned __int8 *)&inByteArray, &inOutByteArray, length: 4u); /*0x1410a2efa*/
      RBX::Network::NetworkStream::writeBytes(this: &bitStream, inByteArray: &inOutByteArray, numberOfBytesToWrite: 4u); /*0x1410a2f0d*/
    }
    v4 = std::shared_ptr<std::string>::operator-><std::string,0>(this: (Luau::NotNull<Luau::InternalErrorReporter> *)this->rakPeer._Ptr); /*0x1410a2f1e*/
    v5 = v4->onInternalError._Mystorage._Ptrs[0][20].__vftable; /*0x1410a2f24*/
    RakNet::RakNetGUID::RakNetGUID(this: &v7); /*0x1410a2f2f*/
    RakNet::SystemAddress::SystemAddress(this: &v8); /*0x1410a2f38*/
    v7 = RakNet::UNASSIGNED_RAKNET_GUID_22; /*0x1410a2f44*/
    RakNet::SystemAddress::operator=(this: &v8, input: &this->remotePlayerRakNetAddress); /*0x1410a2f5e*/
    ((void (__fastcall *)(Luau::InternalErrorReporter *, RBX::Network::NetworkStream *, __int64))v5)( /*0x1410a2f8f*/
      a1: v4,
      a2: &bitStream,
      a3: 2);
  }
  __unwind
  {
    RBX::Network::NetworkStream::~NetworkStream(this: &bitStream); /*0xf1c0000000000008*/
  }
  Myfirst = bitStream.dataVector._Mypair._Myval2._Myfirst; /*0x1410a2f92*/
  if ( bitStream.dataVector._Mypair._Myval2._Myfirst != nullptr ) /*0x1410a2f99*/
  {
    if ( (unsigned __int8 *)(bitStream.dataVector._Mypair._Myval2._Myend - bitStream.dataVector._Mypair._Myval2._Myfirst) >= (unsigned __int8 *)0x1000 ) /*0x1410a2fac*/
    {
      Myfirst = *((unsigned __int8 **)bitStream.dataVector._Mypair._Myval2._Myfirst - 1); /*0x1410a2fb2*/
      if ( (unsigned __int64)(bitStream.dataVector._Mypair._Myval2._Myfirst - Myfirst - 8) > 0x1F ) /*0x1410a2fc1*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410a2fc3*/
    }
    operator delete(ptr: Myfirst); /*0x1410a2fca*/
  }
}

// Address: 0x1410a2ff0 | Name: ?requireGarbageCollect@ClientReplicator@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::ClientReplicator::requireGarbageCollect(RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *Ptr; // rcx

  Ptr = this->gcJob._Ptr; /*0x1410a2ff0*/
  if ( Ptr != nullptr ) /*0x1410a2ffa*/
    RBX::Network::ClientReplicator::GCJob::triggerEmergencyGC(this: Ptr); /*0x1410a2ffa*/
}

// Address: 0x1410a3010 | Name: ?resetReplicatedParentDataForInstance@ClientReplicator@Network@RBX@@IEAAXPEAVInstance@3@@Z
void __fastcall RBX::Network::ClientReplicator::resetReplicatedParentDataForInstance(
        RBX::Network::ClientReplicator *this,
        RBX::Instance *instance)
{
  int v2; // ebx
  __int64 _Keyval; // [rsp+48h] [rbp+10h] BYREF
  std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Instance const * const,RBX::Guid> > > > iter; // [rsp+50h] [rbp+18h] BYREF

  _Keyval = (__int64)instance; /*0x1410a3010*/
  v2 = *((_DWORD *)&instance->completeness + 2); /*0x1410a301c*/
  if ( (v2 & 0x40000000) != 0 ) /*0x1410a302c*/
  {
    std::_Hash<std::_Umap_traits<RBX::BasePart *,RBX::Extents,std::_Uhash_compare<RBX::BasePart *,std::hash<RBX::BasePart *>,std::equal_to<RBX::BasePart *>>,std::allocator<std::pair<RBX::BasePart * const,RBX::Extents>>,0>>::find<void>( /*0x1410a3044*/
      this: (std::_Hash<std::_Umap_traits<__int64,PluginMetadataStore::PluginMetadata,std::_Uhash_compare<__int64,std::hash<__int64>,std::equal_to<__int64> >,std::allocator<std::pair<__int64 const ,PluginMetadataStore::PluginMetadata> >,0> > *)&this->replicatedParentMap,
      result: (std::_List_const_iterator<std::_List_val<std::_List_simple_types<std::pair<__int64 const ,PluginMetadataStore::PluginMetadata> > > > *)&iter,
      &_Keyval);
    if ( iter._Ptr != this->replicatedParentMap._List._Mypair._Myval2._Myhead ) /*0x1410a3055*/
    {
      std::_Hash<std::_Umap_traits<RBX::Instance const *,RBX::Guid,std::_Uhash_compare<RBX::Instance const *,std::hash<RBX::Instance const *>,std::equal_to<RBX::Instance const *>>,std::allocator<std::pair<RBX::Instance const * const,RBX::Guid>>,0>>::erase<std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Instance const * const,RBX::Guid>>>>,0>( /*0x1410a3063*/
        this: &this->replicatedParentMap,
        result: (std::_List_iterator<std::_List_val<std::_List_simple_types<std::pair<RBX::Instance const * const,RBX::Guid> > > > *)&_Keyval,
        _Plist: iter);
      v2 = *((_DWORD *)&instance->completeness + 2); /*0x1410a3068*/
    }
    *((_DWORD *)&instance->completeness + 2) = v2 & 0xBFFFFFFF; /*0x1410a3077*/
  }
}

// Address: 0x1410a3090 | Name: ?sampleStreamingStatistics@ClientReplicator@Network@RBX@@AEAAXXZ
void __fastcall RBX::Network::ClientReplicator::sampleStreamingStatistics(RBX::Network::ClientReplicator *this)
{
  double PreviousFrameTimeMsec; // xmm0_8
  long double v3; // xmm6_8
  double v4; // xmm7_8
  long double v5; // xmm1_8

  RBX::RunningAverage<double,double>::sample(this: &this->streamingFrameTime, value: this->streamingPreviousFrameTime); /*0x1410a30b2*/
  RBX::RunningAverage<double,double>::sample( /*0x1410a30c6*/
    this: &this->streamingDataReadTime,
    value: this->streamingPreviousReadDataItemFrameTime);
  PreviousFrameTimeMsec = RBX::TaskScheduler::getPreviousFrameTimeMsec(); /*0x1410a30cb*/
  v3 = 0.0; /*0x1410a30d0*/
  v4 = PreviousFrameTimeMsec; /*0x1410a30de*/
  if ( PreviousFrameTimeMsec <= 0.0 ) /*0x1410a30e1*/
    v5 = 0.0; /*0x1410a30f1*/
  else
    v5 = this->streamingPreviousFrameTime / PreviousFrameTimeMsec; /*0x1410a30eb*/
  RBX::RunningAverage<double,double>::sample(this: &this->streamingFramePortion, value: v5); /*0x1410a30f4*/
  if ( v4 > 0.0 ) /*0x1410a3104*/
    v3 = this->streamingPreviousReadDataItemFrameTime / v4; /*0x1410a310e*/
  RBX::RunningAverage<double,double>::sample(this: &this->streamingDataReadPortion, value: v3); /*0x1410a3115*/
  this->streamingPreviousFrameTime = this->streamingCurrentFrameTime; /*0x1410a312b*/
  this->streamingPreviousReadDataItemFrameTime = this->streamingReadDataItemFrameTime; /*0x1410a3139*/
  this->streamingCurrentFrameTime = 0.0; /*0x1410a3142*/
  this->streamingReadDataItemFrameTime = 0.0; /*0x1410a3149*/
}

// Address: 0x1410a3160 | Name: ?schemaGetBytecodeForSource@ClientReplicator@Network@RBX@@SA?AVSharedString@3@AEBVProtectedString@3@@Z
RBX::SharedString *__fastcall RBX::Network::ClientReplicator::schemaGetBytecodeForSource(
        RBX::SharedString *result,
        const RBX::ProtectedString *value)
{
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *h; // rax

  h = value->sharedBytecode.flyweight.h.h; /*0x1410a3160*/
  result->flyweight.h.h = h; /*0x1410a3164*/
  _InterlockedIncrement(&h->ref.value_); /*0x1410a3167*/
  result->readCount = value->sharedBytecode.readCount; /*0x1410a316e*/
  return result; /*0x1410a3174*/
}

// Address: 0x1410a3180 | Name: ?sendAnalyticsForLocallyInitiatedDisconnect@ClientReplicator@Network@RBX@@MEAAXHAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RBX::Network::ClientReplicator::sendAnalyticsForLocallyInitiatedDisconnect(
        RBX::Network::ClientReplicator *this,
        unsigned int reason,
        const std::string *reasonString)
{
  RBX::Network::Client *parent; // rsi
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::ClassRegistrar<RBX::Network::Client,1> *v7; // rax
  const char *LoadStateSuffix; // rax
  unsigned __int64 v9; // rdi
  unsigned __int64 Mysize; // rcx
  std::string *p_metric; // rbx
  char *v12; // rbx
  std::string *p_serverAddress; // r9
  std::string *Ptr; // rdx
  char *v15; // rcx
  char *v16; // rcx
  std::string metric; // [rsp+30h] [rbp-48h] BYREF
  std::string serverAddress; // [rsp+50h] [rbp-28h] BYREF

  parent = (RBX::Network::Client *)this->parent; /*0x1410a3199*/
  if ( parent != nullptr ) /*0x1410a31a0*/
  {
    descriptor = parent->descriptor; /*0x1410a31a6*/
    v7 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::Client>(); /*0x1410a31aa*/
    if ( descriptor->index - (unsigned int)v7->desc.index <= v7->desc.descendantCount ) /*0x1410a31cb*/
    {
      if ( reasonString->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410a31d6*/
        reasonString = (const std::string *)reasonString->_Mypair._Myval2._Bx._Ptr; /*0x1410a31d8*/
      RBX::format( /*0x1410a31ed*/
        result: (RBX::Graphics::ProfilerAdorn::Item *)&metric,
        fmt: (const char *)&RBX::Network::CFrameAcknowledgementItem::`vftable'[7],
        reason,
        reasonString);
      __wind /*0xf1c0000000000028*/
      {
        RBX::Network::Client::getConnectedServer(this: parent, result: &serverAddress); /*0x1410a31fb*/
        __wind /*0xf1c000000000001c*/
        {
          LoadStateSuffix = RBX::Network::Client::getLoadStateSuffix(this: parent); /*0x1410a3204*/
          v9 = -1; /*0x1410a320c*/
          do /*0x1410a321a*/
            ++v9; /*0x1410a3213*/
          while ( LoadStateSuffix[v9] != 0 ); /*0x1410a321a*/
          Mysize = metric._Mypair._Myval2._Mysize; /*0x1410a321c*/
          if ( v9 > metric._Mypair._Myval2._Myres - metric._Mypair._Myval2._Mysize ) /*0x1410a322f*/
          {
            std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x1410a3270*/
              this: &metric,
              _Size_increase: v9,
              _Fn: 0,
              <_Args_0>: LoadStateSuffix,
              <_Args_1>: v9);
          }
          else
          {
            metric._Mypair._Myval2._Mysize += v9; /*0x1410a3235*/
            p_metric = &metric; /*0x1410a323a*/
            if ( metric._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a3243*/
              p_metric = (std::string *)metric._Mypair._Myval2._Bx._Ptr; /*0x1410a3243*/
            v12 = &p_metric->_Mypair._Myval2._Bx._Buf[Mysize]; /*0x1410a3249*/
            memmove_0(a1: v12, Src: LoadStateSuffix, Size: v9); /*0x1410a3255*/
            v12[v9] = 0; /*0x1410a325a*/
          }
          p_serverAddress = &serverAddress; /*0x1410a3275*/
          if ( serverAddress._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a3280*/
            p_serverAddress = (std::string *)serverAddress._Mypair._Myval2._Bx._Ptr; /*0x1410a3280*/
          Ptr = &metric; /*0x1410a3286*/
          if ( metric._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a3291*/
            Ptr = (std::string *)metric._Mypair._Myval2._Bx._Ptr; /*0x1410a3291*/
          RBX::Network::Client::handleConnectionStateAndMetricReporting( /*0x1410a32aa*/
            this: parent,
            metric: Ptr->_Mypair._Myval2._Bx._Buf,
            connectionFailed: true,
            serverAddress: p_serverAddress->_Mypair._Myval2._Bx._Buf,
            state: ConnectionState_Closed,
            takeLock: true);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&serverAddress); /*0xf1c0000000000014*/
        }
        if ( serverAddress._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a32b9*/
        {
          v15 = serverAddress._Mypair._Myval2._Bx._Ptr; /*0x1410a32be*/
          if ( serverAddress._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a32cd*/
          {
            v15 = *((char **)serverAddress._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a32d3*/
            if ( (unsigned __int64)(serverAddress._Mypair._Myval2._Bx._Ptr - v15 - 8) > 0x1F ) /*0x1410a32e2*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410a32e4*/
          }
          operator delete(ptr: v15); /*0x1410a32eb*/
        }
        serverAddress._Mypair._Myval2._Mysize = 0; /*0x1410a32f0*/
        serverAddress._Mypair._Myval2._Myres = 15; /*0x1410a32f9*/
        serverAddress._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410a3302*/
        if ( metric._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a3310*/
        {
          v16 = metric._Mypair._Myval2._Bx._Ptr; /*0x1410a3315*/
          if ( metric._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a3324*/
          {
            v16 = *((char **)metric._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a332a*/
            if ( (unsigned __int64)(metric._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x1410a3339*/
              _invalid_parameter_noinfo_noreturn(); /*0x1410a333b*/
          }
          operator delete(ptr: v16); /*0x1410a3342*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&metric); /*0xf1c0000000000008*/
      }
    }
  }
}

// Address: 0x1410a3360 | Name: ?serializePropertyVersionInfo@ClientReplicator@Network@RBX@@UEAAXAEAVNetworkStream@23@PEBVInstance@3@GPEBVPropertyDescriptor@Reflection@3@@Z
void __fastcall RBX::Network::ClientReplicator::serializePropertyVersionInfo(
        RBX::Network::ClientReplicator *this,
        RBX::Network::NetworkStream *bitStream,
        const RBX::Instance *instance,
        unsigned __int16 propertyNetworkId)
{
  RBX::Guid guid; // rax
  unsigned __int64 bucket_count; // rsi
  unsigned __int64 v8; // rcx
  unsigned __int64 v9; // r11
  __int64 v10; // r9
  boost::unordered::detail::ptr_bucket *next; // rax
  boost::unordered::detail::ptr_bucket *v12; // rax
  boost::unordered::detail::ptr_bucket *v13; // rdx
  RBX::Network::NetworkStream *v14; // rcx
  int v15; // ebx
  boost::unordered::detail::ptr_bucket *v16; // [rsp+20h] [rbp-28h]
  RBX::Guid::Scope scope[2]; // [rsp+28h] [rbp-20h] BYREF
  unsigned __int64 seed; // [rsp+50h] [rbp+8h] BYREF
  char inByteArray; // [rsp+68h] [rbp+20h] BYREF

  v16 = (boost::unordered::detail::ptr_bucket *)propertyNetworkId; /*0x1410a3373*/
  if ( instance != nullptr ) /*0x1410a337e*/
    guid = instance->guid; /*0x1410a3380*/
  else
    guid = (RBX::Guid)0xFFFFFFFFLL; /*0x1410a3386*/
  seed = propertyNetworkId; /*0x1410a338b*/
  *(RBX::Guid *)&scope[0].peerId.peerId = guid; /*0x1410a339a*/
  RBX::hash_combine(&seed, scope); /*0x1410a339f*/
  bucket_count = this->propSync.map.table_.bucket_count_; /*0x1410a33b1*/
  seed ^= (int)scope[1].peerId.peerId + (seed >> 2) + (seed << 6) + 2654435769u; /*0x1410a33db*/
  v8 = 265 * ((~seed + (seed << 21)) ^ ((~seed + (seed << 21)) >> 24)); /*0x1410a33f4*/
  v9 = 2147483649u * ((21 * (v8 ^ (v8 >> 14))) ^ ((21 * (v8 ^ (v8 >> 14))) >> 28)); /*0x1410a3418*/
  v10 = v9 & (bucket_count - 1); /*0x1410a341c*/
  if ( this->propSync.map.table_.size_ == 0 /*0x1410a3447*/
    || (next = this->propSync.map.table_.buckets_[v10].next_) == nullptr
    || (v12 = next->next_) == nullptr )
  {
LABEL_15:
    v14 = bitStream; /*0x1410a34c1*/
    goto LABEL_16; /*0x1410a34cc*/
  }
  while ( 1 ) /*0x1410a3453*/
  {
    v13 = v12[1].next_; /*0x1410a3453*/
    if ( (boost::unordered::detail::ptr_bucket *)v9 != v13 ) /*0x1410a345a*/
    {
      if ( ((unsigned __int64)v13 & (bucket_count - 1)) != v10 ) /*0x1410a34b7*/
        goto LABEL_15; /*0x1410a34b7*/
      goto LABEL_14; /*0x1410a34b7*/
    }
    if ( v16 == v12[2].next_ /*0x1410a346a*/
      && scope[1].peerId.peerId == HIDWORD(v12[3].next_)
      && scope[0].peerId.peerId == LODWORD(v12[3].next_) )
    {
      break; /*0x1410a346a*/
    }
LABEL_14:
    v12 = v12->next_; /*0x1410a34b9*/
    if ( v12 == nullptr ) /*0x1410a34bf*/
      goto LABEL_15; /*0x1410a34bf*/
  }
  v14 = bitStream; /*0x1410a347b*/
  if ( LOBYTE(v12[6].next_) == 0 ) /*0x1410a347e*/
  {
    v15 = (int)v12[4].next_; /*0x1410a3480*/
    LOBYTE(v12[6].next_) = 1; /*0x1410a3483*/
    ++this->propSync.ackCount; /*0x1410a3487*/
    inByteArray = 1; /*0x1410a348d*/
    RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x1410a3492*/
    RBX::Network::serializeSignedVarint(value: v15, stream: bitStream); /*0x1410a34a8*/
    return; /*0x1410a34a8*/
  }
LABEL_16:
  inByteArray = 0; /*0x1410a34cf*/
  RBX::Network::NetworkStream::writeBytes(this: v14, &inByteArray, numberOfBytesToWrite: 1u); /*0x1410a34d4*/
}

// Address: 0x1410a34f0 | Name: ?setInstanceGuidBeingGCed_deprecated@ClientReplicator@Network@RBX@@UEAAXVGuid@3@@Z
void __fastcall RBX::Network::ClientReplicator::setInstanceGuidBeingGCed_deprecated(
        RBX::Network::ClientReplicator *this,
        RBX::Guid guid)
{
  this->megaReplicator->instanceGuidBeingGCed_deprecated = guid; /*0x1410a34f7*/
}

// Address: 0x1410a3510 | Name: ?shouldRateLimitTxRemoteEvents@ClientReplicator@Network@RBX@@EEAA_NPEBVInstance@3@AEBVEventDescriptor@Reflection@3@AEBV?$vector@VVariant@Reflection@RBX@@V?$allocator@VVariant@Reflection@RBX@@@std@@@std@@@Z
// local variable allocation has failed, the output may be wrong!
bool __fastcall RBX::Network::ClientReplicator::shouldRateLimitTxRemoteEvents(
        RBX::Network::ClientReplicator *this,
        const RBX::Instance *instance,
        const RBX::Reflection::EventDescriptor *event,
        const std::vector<RBX::Reflection::Variant> *args)
{
  float maxAmount; // xmm3_4
  float v6; // xmm6_4
  RBX::Time *v7; // rax
  float v8; // xmm6_4
  __int16 specialFail; // [rsp+30h] [rbp-48h] OVERLAPPED BYREF
  RBX::Time v11; // [rsp+38h] [rbp-40h] BYREF
  RBX::Time v12; // [rsp+40h] [rbp-38h] BYREF
  RBX::Time v13; // [rsp+48h] [rbp-30h] BYREF

  specialFail = 0; /*0x1410a3537*/
  RBX::Network::Replicator::rateLimitChecks( /*0x1410a353c*/
    this,
    instance,
    event,
    globalRateLimitReached: (bool *)&specialFail + 1,
    specialRateLimitReached: (bool *)&specialFail);
  if ( specialFail == 0 /*0x1410a3576*/
    || this->dbgReportableRateLimitDetection.leakSeconds == 0.0
    || this->dbgReportableRateLimitDetection.maxAmount == 0.0 )
  {
    return false; /*0x1410a3576*/
  }
  RBX::Time::nowFast(result: &v11); /*0x1410a3581*/
  maxAmount = this->dbgReportableRateLimitDetection.maxAmount; /*0x1410a358c*/
  v6 = this->dbgReportableRateLimitDetection.lastLevel /*0x1410a35b7*/
     - (float)((float)(v11.sec - this->dbgReportableRateLimitDetection.lastCheck.sec)
             * (float)(maxAmount / this->dbgReportableRateLimitDetection.leakSeconds));
  if ( v6 <= 0.0 ) /*0x1410a35be*/
  {
    this->dbgReportableRateLimitDetection.lastLevel = 0.0; /*0x1410a35c5*/
    v6 = 0.0; /*0x1410a35cf*/
    v7 = RBX::Time::nowFast(result: &v12); /*0x1410a35d2*/
    maxAmount = this->dbgReportableRateLimitDetection.maxAmount; /*0x1410a35d7*/
    this->dbgReportableRateLimitDetection.lastCheck = *(RBX::Time *)&v7->sec; /*0x1410a35e3*/
  }
  v8 = v6 + 1.0; /*0x1410a35eb*/
  if ( v8 <= maxAmount ) /*0x1410a35f6*/
  {
    this->dbgReportableRateLimitDetection.lastLevel = v8; /*0x1410a35fd*/
    this->dbgReportableRateLimitDetection.lastCheck = *(RBX::Time *)&RBX::Time::nowFast(result: &v13)->sec; /*0x1410a360e*/
    return false; /*0x1410a3627*/
  }
  return FFlag::TxRlEn.value; /*0x1410a362f*/
}

// Address: 0x1410a3970 | Name: ?streamOutAutoJointHelper@ClientReplicator@Network@RBX@@AEAAXV?$vector@V?$shared_ptr@VBasePart@RBX@@@std@@V?$allocator@V?$shared_ptr@VBasePart@RBX@@@std@@@2@@std@@AEBV?$shared_ptr@VInstance@RBX@@@5@@Z
void __fastcall RBX::Network::ClientReplicator::streamOutAutoJointHelper(
        RBX::Network::ClientReplicator *this,
        std::vector<std::shared_ptr<StudioCmdBase>> *pendingRemovalParts,
        const std::shared_ptr<RBX::Instance> *instance)
{
  std::vector<std::shared_ptr<StudioCmdBase>> *v3; // r14
  RBX::JointInstance *Ptr; // rbp
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v6; // rax
  RBX::BasePart *Part0; // r13
  RBX::WrapTarget *Attachment0; // rax
  RBX::WrapTarget *v9; // r12
  std::shared_ptr<StudioCmdBase> *v10; // rdi
  std::shared_ptr<StudioCmdBase> *v11; // rsi
  volatile signed __int32 *v12; // rbx
  std::shared_ptr<StudioCmdBase> *Myfirst; // rsi
  std::shared_ptr<StudioCmdBase> *Mylast; // r15
  RBX::BasePart *v15; // rax
  RBX::Reflection::RefPropDescriptor<RBX::JointInstance,RBX::BasePart> *v16; // rcx
  RBX::Instance *oldValue; // rbx
  std::shared_ptr<StudioCmdBase> *v18; // rsi
  volatile signed __int32 *Rep; // rbx
  RBX::ScopedAssign<RBX::Instance *> assign; // [rsp+20h] [rbp-48h] BYREF

  __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000028*/
  v3 = pendingRemovalParts; /*0x1410a398e*/
  Ptr = (RBX::JointInstance *)instance->_Ptr; /*0x1410a3991*/
  if ( instance->_Ptr == nullptr /*0x1410a39c3*/
    || (descriptor = Ptr->descriptor,
        v6 = RBX::Reflection::Class_getDescriptorPtr<RBX::JointInstance>(),
        descriptor->index - (unsigned int)v6->index > v6->descendantCount) )
  {
    __eh34_enter_wind_state(0, 1); /*0xf1c0000000000004*/
    goto LABEL_23; /*0xf1c0000000000008*/
  }
  Part0 = RBX::JointInstance::getPart0(this: Ptr); /*0x1410a39d1*/
  Attachment0 = RBX::Constraints::Constraint::getAttachment0(this: (RBX::Constraints::Constraint *)Ptr); /*0x1410a39d7*/
  v9 = Attachment0; /*0x1410a39dc*/
  if ( Part0 != nullptr || Attachment0 != nullptr ) /*0x1410a39e7*/
  {
    __eh34_enter_wind_state(0, 1); /*0xf1c000000000000c*/
    Myfirst = v3->_Mypair._Myval2._Myfirst; /*0x1410a3a48*/
    Mylast = v3->_Mypair._Myval2._Mylast; /*0x1410a3a4b*/
    if ( v3->_Mypair._Myval2._Myfirst != Mylast ) /*0x1410a3a52*/
    {
      while ( 1 ) /*0x1410a3a60*/
      {
        v15 = (RBX::BasePart *)Myfirst->_Ptr; /*0x1410a3a60*/
        if ( Myfirst->_Ptr != nullptr ) /*0x1410a3a66*/
        {
          if ( Part0 == v15 ) /*0x1410a3a6b*/
          {
            v16 = &RBX::JointInstance::prop_Part0; /*0x1410a3a6d*/
LABEL_20:
            assign.value = &this->removingInstance; /*0x1410a3a82*/
            assign.oldValue = this->removingInstance; /*0x1410a3a91*/
            oldValue = assign.oldValue; /*0x1410a3a8e*/
            this->removingInstance = Ptr; /*0x1410a3a96*/
            v16->setRefValue(this: v16, a2: Ptr, a3: nullptr); /*0x1410a3aa2*/
            this->removingInstance = oldValue; /*0x1410a3aa9*/
            goto LABEL_21; /*0x1410a3aa9*/
          }
          if ( v9 == (RBX::WrapTarget *)v15 ) /*0x1410a3a79*/
          {
            v16 = &RBX::JointInstance::prop_Part1; /*0x1410a3a7b*/
            goto LABEL_20; /*0x1410a3a7b*/
          }
        }
LABEL_21:
        if ( ++Myfirst == Mylast ) /*0x1410a3ab3*/
        {
          v3 = pendingRemovalParts; /*0x1410a3ab5*/
          break; /*0x1410a3ab5*/
        }
      }
    }
LABEL_23:
    v10 = v3->_Mypair._Myval2._Myfirst; /*0x1410a3aba*/
    if ( v3->_Mypair._Myval2._Myfirst == nullptr ) /*0x1410a3ac0*/
    {
      if ( __eh34_unwind(1) ) /*0xf1c0000000000030*/
      {
        RBX::ScopedAssign<unsigned __int64>::~ScopedAssign<unsigned __int64>(this: (RBX::ScopedAssign<unsigned __int64> *)&assign); /*0xf1c0000000000034*/
        __eh34_continue_unwinding(1, 0); /*0xf1c0000000000038*/
      }
LABEL_41:
      __eh34_exit_wind_state(1, 0); /*0xf1c000000000003c*/
      if ( __eh34_unwind(0) ) /*0xf1c0000000000040*/
        goto unwind_state_0; /*0xf1c0000000000040*/
      __eh34_exit_wind_state(0, -1); /*0xf1c0000000000044*/
      return; /*0xf1c0000000000044*/
    }
    v18 = v3->_Mypair._Myval2._Mylast; /*0x1410a3ac6*/
    if ( v10 != v18 ) /*0x1410a3acd*/
    {
      do /*0x1410a3b0f*/
      {
        Rep = (volatile signed __int32 *)v10->_Rep; /*0x1410a3ad0*/
        if ( Rep != nullptr && _InterlockedExchangeAdd(Rep + 2, 0xFFFFFFFF) == 1 ) /*0x1410a3ae6*/
        {
          (**(void (__fastcall ***)(volatile signed __int32 *))Rep)(a1: Rep); /*0x1410a3aee*/
          if ( _InterlockedExchangeAdd(Rep + 3, 0xFFFFFFFF) == 1 ) /*0x1410a3afd*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)Rep + 8LL))(a1: Rep); /*0x1410a3b05*/
        }
        ++v10; /*0x1410a3b08*/
      }
      while ( v10 != v18 ); /*0x1410a3b0f*/
      goto LABEL_30; /*0x1410a3b0f*/
    }
LABEL_31:
    if ( (((char *)v3->_Mypair._Myval2._Myend - (char *)v10) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x1410a3b26*/
    {
      if ( (unsigned __int64)((char *)v10 - (char *)v10[-1]._Rep - 8) > 0x1F ) /*0x1410a3b3b*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410a3b6d*/
      v10 = (std::shared_ptr<StudioCmdBase> *)v10[-1]._Rep; /*0x1410a3b3d*/
    }
    operator delete(ptr: v10); /*0x1410a3b43*/
    v3->_Mypair._Myval2._Myfirst = nullptr; /*0x1410a3b4a*/
    v3->_Mypair._Myval2._Mylast = nullptr; /*0x1410a3b4d*/
    v3->_Mypair._Myval2._Myend = nullptr; /*0x1410a3b51*/
    goto LABEL_41; /*0xf1c0000000000060*/
  }
  if ( __eh34_unwind(0) ) /*0xf1c0000000000014*/
  {
unwind_state_0:
    std::vector<std::shared_ptr<RBX::RVideo::RvPacket>>::~vector<std::shared_ptr<RBX::RVideo::RvPacket>>(this: pendingRemovalParts); /*0xf1c0000000000018*/
    __eh34_propagate_exception_into_caller(0, -1); /*0xf1c000000000001c*/
  }
  __eh34_exit_wind_state(0, -1); /*0xf1c0000000000020*/
  v10 = v3->_Mypair._Myval2._Myfirst; /*0x1410a39e9*/
  if ( v3->_Mypair._Myval2._Myfirst != nullptr ) /*0x1410a39ef*/
  {
    __eh34_enter_wind_state(-1, 0); /*0xf1c000000000004c*/
    __eh34_enter_wind_state(0, 1); /*0xf1c0000000000050*/
    v11 = v3->_Mypair._Myval2._Mylast; /*0x1410a39f5*/
    if ( v10 != v11 ) /*0x1410a39fc*/
    {
      do /*0x1410a3a41*/
      {
        v12 = (volatile signed __int32 *)v10->_Rep; /*0x1410a3a02*/
        if ( v12 != nullptr && _InterlockedExchangeAdd(v12 + 2, 0xFFFFFFFF) == 1 ) /*0x1410a3a18*/
        {
          (**(void (__fastcall ***)(volatile signed __int32 *))v12)(a1: v12); /*0x1410a3a20*/
          if ( _InterlockedExchangeAdd(v12 + 3, 0xFFFFFFFF) == 1 ) /*0x1410a3a2f*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 8LL))(a1: v12); /*0x1410a3a37*/
        }
        ++v10; /*0x1410a3a3a*/
      }
      while ( v10 != v11 ); /*0x1410a3a41*/
LABEL_30:
      v10 = v3->_Mypair._Myval2._Myfirst; /*0x1410a3b11*/
      goto LABEL_31; /*0x1410a3b11*/
    }
    goto LABEL_31; /*0x1410a39fc*/
  }
}

// Address: 0x1410a3b80 | Name: ?streamOutInstance@ClientReplicator@Network@RBX@@AEAAXPEAVInstance@3@_N@Z
void __fastcall RBX::Network::ClientReplicator::streamOutInstance(
        RBX::Network::ClientReplicator *this,
        RBX::BasePart *instance,
        bool deleteImmediately)
{
  RBX::Network::ClientReplicator *v4; // r13
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v7; // ett
  std::_Ref_count_base *v8; // rcx
  std::_Ref_count_base *v9; // rbx
  std::_Ref_count_base *guid; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // rdi
  RBX::Reflection::ClassDescriptor *v12; // rax
  RBX::Primitive *Myval2; // rcx
  int v14; // ebx
  x509_store_ctx_st *ConstJoint; // rdi
  int v16; // eax
  x509_st *current_cert; // rax
  RBX::Constraints::Constraint *p_notAfter; // r14
  RBX::Instance *parent; // rcx
  RBX::Reflection::RefPropDescriptor<RBX::JointInstance,RBX::BasePart> *v20; // rcx
  unsigned __int64 v21; // rdi
  int v22; // eax
  x509_st *v23; // rax
  RBX::Constraints::Constraint *v24; // r13
  RBX::Instance *v25; // rcx
  RBX::WrapTarget *Attachment0; // rax
  RBX::Reflection::RefPropDescriptor<RBX::Constraints::Constraint,RBX::Attachment> *v27; // rcx
  x509_st *v28; // rax
  RBX::Constraints::WeldConstraint *p_extensions; // r14
  RBX::Instance *v30; // rcx
  RBX::Reflection::RefPropDescriptor<RBX::Constraints::WeldConstraint,RBX::BasePart> *v31; // rcx
  unsigned __int64 v32; // rdi
  RBX::WrapTarget *Attachment1; // rax
  RBX::Instance *v34; // rsi
  __int64 v35; // rdi
  RBX::Network::ClientReplicator_vtbl *v36; // r8
  RBX::ServiceProvider *RootAncestor; // rsi
  RBX::Instance *v38; // rcx
  const RBX::Reflection::ClassDescriptor *v39; // rdi
  RBX::Reflection::ClassDescriptor *v40; // rax
  unsigned __int64 v41; // rax
  RBX::Described<RBX::JointsService,RBX::ServiceInstance> *v42; // rcx
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *v43; // r14
  const RBX::Name *ClassName; // rax
  std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *ServiceByClassName; // rax
  std::_Ref_count_base *v46; // rdi
  const RBX::Network::ClientReplicator::streamOutInstance::__l33::<lambda_ee06fdcfa8a292c51a096461316f2ab9> *Ptr; // rcx
  RBX::Instance *removingInstance; // rbx
  std::shared_ptr<std::vector<RBX::Guid> > v49; // [rsp+30h] [rbp-89h] BYREF
  RBX::BasePart *v50; // [rsp+40h] [rbp-79h]
  std::shared_ptr<RBX::Instance> v51; // [rsp+48h] [rbp-71h] BYREF
  RBX::Primitive *v52; // [rsp+58h] [rbp-61h]
  std::_Ref_count_base *v53; // [rsp+60h] [rbp-59h]
  __int64 v54; // [rsp+70h] [rbp-49h]
  RBX::Time result; // [rsp+78h] [rbp-41h] BYREF
  RBX::ScopedAssign<unsigned __int64> v56; // [rsp+80h] [rbp-39h] BYREF
  RBX::ScopedAssign<unsigned __int64> v57; // [rsp+90h] [rbp-29h] BYREF
  RBX::ScopedAssign<unsigned __int64> v58; // [rsp+A0h] [rbp-19h] BYREF
  std::shared_ptr<RBX::Instance> v59; // [rsp+B0h] [rbp-9h] BYREF
  RBX::ScopedAssign<RBX::Instance *> assign; // [rsp+C0h] [rbp+7h] BYREF
  RBX::Reflection::RefPropDescriptor<RBX::Constraints::Constraint,RBX::Attachment> *v62; // [rsp+128h] [rbp+6Fh]
  RBX::Time v64; // [rsp+138h] [rbp+7Fh] BYREF

  v4 = this; /*0x1410a3ba5*/
  if ( instance != nullptr ) /*0x1410a3bb0*/
  {
    Rep = instance->_Wptr._Rep; /*0x1410a3bb2*/
    if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x1410a3bc4*/
LABEL_82:
      std::_Throw_bad_weak_ptr(); /*0x1410a4107*/
    while ( 1 ) /*0x1410a3bd3*/
    {
      v7 = Uses; /*0x1410a3bd3*/
      Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x1410a3bd3*/
      if ( v7 == Uses ) /*0x1410a3bd8*/
        break; /*0x1410a3bd8*/
      if ( Uses == 0 ) /*0x1410a3bdc*/
        goto LABEL_82; /*0x1410a3bdc*/
    }
    v8 = instance->_Wptr._Rep; /*0x1410a3be8*/
    v51._Ptr = (RBX::Instance *)instance->_Wptr._Ptr; /*0x1410a3bec*/
    v51._Rep = v8; /*0x1410a3bf0*/
    v54 = 0; /*0x1410a3bf7*/
  }
  else
  {
    v51._Ptr = nullptr; /*0x1410a3c00*/
    v51._Rep = nullptr; /*0x1410a3c04*/
    v49._Rep = nullptr; /*0x1410a3c08*/
  }
  __wind /*0xf1c0000000000070*/
  {
    RBX::Network::Replicator::disconnectReplicationData(this: v4, instance: &v51); /*0x1410a3c14*/
    v9 = v51._Rep; /*0x1410a3c1a*/
    if ( v51._Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v51._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410a3c2d*/
    {
      v9->_Destroy(this: v9); /*0x1410a3c35*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v9->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a3c41*/
        v9->_Delete_this(this: v9); /*0x1410a3c49*/
    }
    guid = (std::_Ref_count_base *)instance->guid; /*0x1410a3c4c*/
    v53 = guid; /*0x1410a3c50*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v51); /*0xf1c0000000000068*/
  }
  if ( RBX::Time::now<1>(&result)->sec - v4->deletedInstancesPerSec.timer.start.sec >= v4->deletedInstancesPerSec.interval ) /*0x1410a3c73*/
  {
    v4->deletedInstancesPerSec.valueLastInterval = v4->deletedInstancesPerSec.valueCurrentInterval; /*0x1410a3c7c*/
    v4->deletedInstancesPerSec.valueCurrentInterval = 0; /*0x1410a3c83*/
    RBX::Time::now<1>(result: &v64); /*0x1410a3c8e*/
    v4->deletedInstancesPerSec.timer.start = v64; /*0x1410a3c98*/
  }
  ++v4->deletedInstancesPerSec.valueCurrentInterval; /*0x1410a3ca1*/
  descriptor = instance->descriptor; /*0x1410a3ca8*/
  v12 = RBX::Reflection::Class_getDescriptorPtr<RBX::BasePart>(); /*0x1410a3cac*/
  if ( descriptor->index - (unsigned int)v12->index > v12->descendantCount ) /*0x1410a3cca*/
  {
LABEL_79:
    assign.value = &v4->removingInstance; /*0x1410a40b7*/
    removingInstance = v4->removingInstance; /*0x1410a40c2*/
    assign.oldValue = removingInstance; /*0x1410a40c5*/
    v4->removingInstance = instance; /*0x1410a40c9*/
    __wind /*0xf1c0000000000010*/
    {
      v49 = 0; /*0x1410a40cf*/
      RBX::Instance::setParentInternal( /*0x1410a40ea*/
        this: instance,
        newParent: nullptr,
        ignoreLock: false,
        destroying: false,
        destroyedGuids: &v49);
    }
    __unwind
    {
      RBX::ScopedAssign<unsigned __int64>::~ScopedAssign<unsigned __int64>(this: (RBX::ScopedAssign<unsigned __int64> *)&assign); /*0xf1c0000000000008*/
    }
    v4->removingInstance = removingInstance; /*0x1410a40f0*/
    return; /*0x1410a40f0*/
  }
  RBX::BasePart::setIsCurrentlyStreamRemovingPart(this: instance); /*0x1410a3cd3*/
  Myval2 = instance->primitive._Mypair._Myval2; /*0x1410a3cd8*/
  v52 = Myval2; /*0x1410a3cdf*/
  if ( (int)(Myval2->joints.list._Mypair._Myval2._Mylast - Myval2->joints.list._Mypair._Myval2._Myfirst) <= 0 ) /*0x1410a3cfb*/
    goto LABEL_65; /*0x1410a3cfb*/
  v14 = 0; /*0x1410a3d01*/
  do /*0x1410a3fb3*/
  {
    ConstJoint = (x509_store_ctx_st *)RBX::Primitive::getConstJoint(this: Myval2, id: v14); /*0x1410a3d0b*/
    v16 = ((__int64 (__fastcall *)(x509_store_ctx_st *))ConstJoint->ctx->param)(a1: ConstJoint); /*0x1410a3d14*/
    if ( (unsigned int)(v16 - 1) <= 7 && (unsigned int)(v16 - 2) > 1 ) /*0x1410a3d29*/
    {
      current_cert = X509_STORE_CTX_get_current_cert(ctx: ConstJoint); /*0x1410a3d32*/
      p_notAfter = (RBX::Constraints::Constraint *)&current_cert[-1].cert_info.validity.notAfter; /*0x1410a3d3a*/
      if ( current_cert == nullptr ) /*0x1410a3d41*/
        p_notAfter = nullptr; /*0x1410a3d43*/
      parent = p_notAfter->parent; /*0x1410a3d46*/
      if ( instance != parent && (parent == nullptr || !RBX::Instance::isDescendantOf(this: parent, ancestor: instance)) ) /*0x1410a3d5b*/
      {
        if ( RBX::JointInstance::getPart0(this: (RBX::JointInstance *)p_notAfter) == instance ) /*0x1410a3d73*/
        {
          v20 = &RBX::JointInstance::prop_Part0; /*0x1410a3d75*/
        }
        else
        {
          if ( RBX::Constraints::Constraint::getAttachment0(this: p_notAfter) != (RBX::WrapTarget *)instance ) /*0x1410a3d89*/
            goto LABEL_63; /*0x1410a3d89*/
          v20 = &RBX::JointInstance::prop_Part1; /*0x1410a3d8f*/
        }
        v56.value = (unsigned __int64 *)&v4->removingInstance; /*0x1410a3d9d*/
        v21 = (unsigned __int64)v4->removingInstance; /*0x1410a3da1*/
        v56.oldValue = v21; /*0x1410a3da4*/
        v4->removingInstance = p_notAfter; /*0x1410a3da8*/
        __wind /*0xf1c0000000000058*/
        {
          v20->setRefValue(this: v20, a2: p_notAfter, a3: nullptr); /*0x1410a3db4*/
        }
        __unwind
        {
          RBX::ScopedAssign<unsigned __int64>::~ScopedAssign<unsigned __int64>(this: &v56); /*0xf1c0000000000050*/
        }
        v4->removingInstance = (RBX::Instance *)v21; /*0x1410a3dbb*/
      }
      goto LABEL_63; /*0x1410a3dbe*/
    }
    v22 = ((__int64 (__fastcall *)(x509_store_ctx_st *))ConstJoint->ctx->param)(a1: ConstJoint); /*0x1410a3dc9*/
    if ( DFFlag::SimHumanoidPhysics.value ) /*0x1410a3dd5*/
    {
      if ( (unsigned int)(v22 - 9) <= 0x13 && v22 != 16 ) /*0x1410a3de2*/
        goto LABEL_35; /*0x1410a3de2*/
    }
    else if ( (unsigned int)(v22 - 9) <= 0x13 ) /*0x1410a3e4a*/
    {
      goto LABEL_35; /*0x1410a3e4a*/
    }
    if ( v22 != 2 ) /*0x1410a3e4f*/
    {
      if ( ((unsigned int (__fastcall *)(x509_store_ctx_st *))ConstJoint->ctx->param)(a1: ConstJoint) == 3 ) /*0x1410a3e5d*/
      {
        v28 = X509_STORE_CTX_get_current_cert(ctx: ConstJoint); /*0x1410a3e66*/
        p_extensions = (RBX::Constraints::WeldConstraint *)&v28[-1].cert_info.extensions; /*0x1410a3e6e*/
        if ( v28 == nullptr ) /*0x1410a3e75*/
          p_extensions = nullptr; /*0x1410a3e77*/
        v30 = p_extensions->parent; /*0x1410a3e7a*/
        if ( instance != v30 && (v30 == nullptr || !RBX::Instance::isDescendantOf(this: v30, ancestor: instance)) ) /*0x1410a3e8f*/
        {
          if ( RBX::Constraints::WeldConstraint::getPart0(this: p_extensions) == instance ) /*0x1410a3ea7*/
          {
            v31 = &RBX::Constraints::WeldConstraint::prop_Part0Internal; /*0x1410a3ea9*/
          }
          else
          {
            if ( RBX::Constraints::WeldConstraint::getPart1(this: p_extensions) != instance ) /*0x1410a3ebd*/
              goto LABEL_63; /*0x1410a3ebd*/
            v31 = &RBX::Constraints::WeldConstraint::prop_Part1Internal; /*0x1410a3ec3*/
          }
          v57.value = (unsigned __int64 *)&v4->removingInstance; /*0x1410a3ed1*/
          v32 = (unsigned __int64)v4->removingInstance; /*0x1410a3ed5*/
          v57.oldValue = v32; /*0x1410a3ed8*/
          v4->removingInstance = p_extensions; /*0x1410a3edc*/
          __wind /*0xf1c0000000000040*/
          {
            v31->setRefValue(this: v31, a2: p_extensions, a3: nullptr); /*0x1410a3ee8*/
          }
          __unwind
          {
            RBX::ScopedAssign<unsigned __int64>::~ScopedAssign<unsigned __int64>(this: &v57); /*0xf1c0000000000038*/
          }
          v4->removingInstance = (RBX::Instance *)v32; /*0x1410a3eef*/
        }
      }
      goto LABEL_63; /*0x1410a3ef2*/
    }
LABEL_35:
    v23 = X509_STORE_CTX_get_current_cert(ctx: ConstJoint); /*0x1410a3de4*/
    v24 = (RBX::Constraints::Constraint *)&v23[-1].cert_info.extensions; /*0x1410a3def*/
    if ( v23 == nullptr ) /*0x1410a3df6*/
      v24 = nullptr; /*0x1410a3df8*/
    v25 = v24->parent; /*0x1410a3dfb*/
    if ( instance == v25 || v25 != nullptr && RBX::Instance::isDescendantOf(this: v25, ancestor: instance) ) /*0x1410a3e10*/
    {
LABEL_62:
      v4 = this; /*0x1410a3f95*/
      goto LABEL_63; /*0x1410a3f95*/
    }
    Attachment0 = RBX::Constraints::Constraint::getAttachment0(this: v24); /*0x1410a3e20*/
    if ( Attachment0 != nullptr && Attachment0->parent == instance ) /*0x1410a3e32*/
    {
      v27 = &RBX::Constraints::Constraint::prop_Attachment0; /*0x1410a3e38*/
    }
    else
    {
      Attachment1 = RBX::Constraints::Constraint::getAttachment1(this: v24); /*0x1410a3efa*/
      if ( Attachment1 == nullptr || Attachment1->parent != instance ) /*0x1410a3f0c*/
        goto LABEL_62; /*0x1410a3f0c*/
      v27 = &RBX::Constraints::Constraint::prop_Attachment1; /*0x1410a3f12*/
    }
    v62 = v27; /*0x1410a3f19*/
    v58.value = (unsigned __int64 *)&this->removingInstance; /*0x1410a3f28*/
    v34 = this->removingInstance; /*0x1410a3f2c*/
    v58.oldValue = (unsigned __int64)v34; /*0x1410a3f2f*/
    this->removingInstance = v24; /*0x1410a3f33*/
    __wind /*0xf1c0000000000028*/
    {
      v35 = (__int64)v27->getRefValue(this: v27, a2: v24); /*0x1410a3f42*/
      v36 = this->RBX::Described<RBX::Network::ClientReplicator,RBX::Network::Replicator>::RBX::Network::Replicator::RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>::RBX::Network::IdSerializer::RBX::Instance::RBX::Reflection::DescribedBase::RBX::Reflection::EventSource::__vftable; /*0x1410a3f49*/
      LOBYTE(v36) = 1; /*0x1410a3f53*/
      ((void (__fastcall *)(RBX::Network::ClientReplicator *, _QWORD, RBX::Network::ClientReplicator_vtbl *))this->preserveForwardRefsToGuid)( /*0x1410a3f5d*/
        a1: this,
        a2: *(_QWORD *)(v35 + 48),
        a3: v36);
      v62->setRefValue(this: v62, a2: v24, a3: nullptr); /*0x1410a3f74*/
      v4 = this; /*0x1410a3f77*/
      ((void (__fastcall *)(RBX::Network::ClientReplicator *, _QWORD, _QWORD))this->preserveForwardRefsToGuid)( /*0x1410a3f89*/
        a1: this,
        a2: *(_QWORD *)(v35 + 48),
        a3: 0);
    }
    __unwind
    {
      RBX::ScopedAssign<unsigned __int64>::~ScopedAssign<unsigned __int64>(this: &v58); /*0xf1c0000000000020*/
    }
    this->removingInstance = v34; /*0x1410a3f90*/
LABEL_63:
    ++v14; /*0x1410a3f99*/
    Myval2 = v52; /*0x1410a3f9b*/
  }
  while ( v14 < (int)(v52->joints.list._Mypair._Myval2._Mylast - v52->joints.list._Mypair._Myval2._Myfirst) ); /*0x1410a3fb3*/
  guid = v53; /*0x1410a3fb9*/
LABEL_65:
  if ( deleteImmediately ) /*0x1410a3fc1*/
  {
    RootAncestor = (RBX::ServiceProvider *)v4->parent; /*0x1410a3fc7*/
    if ( RootAncestor != nullptr ) /*0x1410a3fce*/
    {
      v38 = RootAncestor->parent; /*0x1410a3fd0*/
      if ( v38 != nullptr ) /*0x1410a3fd7*/
        RootAncestor = (RBX::ServiceProvider *)RBX::Instance::getRootAncestor(this: v38); /*0x1410a3fde*/
    }
    else
    {
      RootAncestor = (RBX::ServiceProvider *)v4; /*0x1410a3fe3*/
    }
    if ( RootAncestor != nullptr ) /*0x1410a3fe9*/
    {
      v39 = RootAncestor->descriptor; /*0x1410a3fef*/
      v40 = RBX::Reflection::Class_getDescriptorPtr<RBX::ServiceProvider>(); /*0x1410a3ff3*/
      if ( v39->index - (unsigned int)v40->index <= v40->descendantCount ) /*0x1410a4011*/
      {
        boost::call_once( /*0x1410a4025*/
          flag: &`RBX::ServiceProvider::getClassIndex<RBX::JointsService>'::`2'::flag,
          f: (void (__fastcall *)())RBX::ServiceProvider::callDoGetClassIndex<RBX::JointsService>);
        v41 = RBX::ServiceProvider::doGetClassIndex<RBX::JointsService>(); /*0x1410a402a*/
        v43 = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::refAt( /*0x1410a403a*/
                                                                                   this: RootAncestor,
                                                                                   index: v41);
        if ( v43->_Ptr == nullptr ) /*0x1410a4041*/
        {
          ClassName = RBX::Described<RBX::JointsService,RBX::ServiceInstance>::getClassName(this: v42); /*0x1410a4043*/
          ServiceByClassName = (std::shared_ptr<RBX::Graphics::FrameRateManagerStatsStringItem> *)RBX::ServiceProvider::findServiceByClassName( /*0x1410a4052*/
                                                                                                    this: RootAncestor,
                                                                                                    result: &v59,
                                                                                                    className: ClassName);
          std::shared_ptr<RBX::Network::CachedBitstream>::operator=(this: v43, _Right: ServiceByClassName); /*0x1410a405d*/
          v46 = v59._Rep; /*0x1410a4062*/
          if ( v59._Rep != nullptr /*0x1410a407a*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&v59._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v46->_Destroy(this: v46); /*0x1410a4082*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v46->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a408c*/
              v46->_Delete_this(this: v46); /*0x1410a4094*/
          }
        }
        Ptr = (const RBX::Network::ClientReplicator::streamOutInstance::__l33::<lambda_ee06fdcfa8a292c51a096461316f2ab9> *)v43->_Ptr; /*0x1410a4097*/
        if ( v43->_Ptr != nullptr ) /*0x1410a409d*/
        {
          v49._Ptr = (std::vector<RBX::Guid> *)v4; /*0x1410a409f*/
          v49._Rep = guid; /*0x1410a40a4*/
          v50 = instance; /*0x1410a40a9*/
          RBX::Instance::visitDescendants__lambda_ee06fdcfa8a292c51a096461316f2ab9___(func: Ptr); /*0x1410a40b2*/
        }
      }
    }
    goto LABEL_79; /*0x1410a40b2*/
  }
}

// Address: 0x1410a4110 | Name: ?streamOutPartJointInstanceHelper@ClientReplicator@Network@RBX@@AEAAXAEBVGuid@3@PEAVBasePart@3@PEAVJointInstance@3@@Z
void __fastcall RBX::Network::ClientReplicator::streamOutPartJointInstanceHelper(
        RBX::Network::ClientReplicator *this,
        const RBX::Guid *partGuid,
        RBX::WrapTarget *part,
        RBX::Constraints::Constraint *descendant)
{
  RBX::Reflection::RefPropDescriptor<RBX::JointInstance,RBX::BasePart> *v7; // rcx
  RBX::Instance **p_removingInstance; // rdi
  RBX::Instance *v9; // rbx
  RBX::ScopedAssign<RBX::Instance *> assign; // [rsp+20h] [rbp-18h] BYREF

  if ( RBX::JointInstance::getPart0(this: (RBX::JointInstance *)descendant) == (RBX::BasePart *)part ) /*0x1410a4133*/
  {
    v7 = &RBX::JointInstance::prop_Part0; /*0x1410a4135*/
  }
  else
  {
    if ( RBX::Constraints::Constraint::getAttachment0(this: descendant) != part ) /*0x1410a4149*/
      return; /*0x1410a4149*/
    v7 = &RBX::JointInstance::prop_Part1; /*0x1410a414b*/
  }
  p_removingInstance = &this->removingInstance; /*0x1410a4152*/
  assign.value = p_removingInstance; /*0x1410a4159*/
  v9 = *p_removingInstance; /*0x1410a415e*/
  assign.oldValue = *p_removingInstance; /*0x1410a4161*/
  *p_removingInstance = descendant; /*0x1410a4166*/
  __wind /*0xf1c0000000000010*/
  {
    v7->setRefValue(this: v7, a2: descendant, a3: nullptr); /*0x1410a4172*/
  }
  __unwind
  {
    RBX::ScopedAssign<unsigned __int64>::~ScopedAssign<unsigned __int64>(this: (RBX::ScopedAssign<unsigned __int64> *)&assign); /*0xf1c0000000000008*/
  }
  *p_removingInstance = v9; /*0x1410a4179*/
}

// Address: 0x1410a4190 | Name: ?streamOutTerrain@ClientReplicator@Network@RBX@@AEAAXAEBVId@StreamRegion@3@@Z
void __fastcall RBX::Network::ClientReplicator::streamOutTerrain(
        RBX::Network::ClientReplicator *this,
        const RBX::StreamRegion::Id *regionId)
{
  RBX::MegaClusterInstance *megaClusterInstance; // r9
  bool *p_clusterDebounce; // rdi
  bool clusterDebounce; // si
  int v7; // edx
  int v8; // ecx
  RBX::ScopedAssign<bool> assignment; // [rsp+20h] [rbp-38h] BYREF
  RBX::Voxel2::Region region; // [rsp+30h] [rbp-28h] BYREF
  RBX::Time result; // [rsp+60h] [rbp+8h] BYREF

  megaClusterInstance = this->megaClusterInstance; /*0x1410a41a5*/
  if ( megaClusterInstance != nullptr ) /*0x1410a41af*/
  {
    p_clusterDebounce = &this->clusterDebounce; /*0x1410a41b5*/
    assignment.value = &this->clusterDebounce; /*0x1410a41bc*/
    clusterDebounce = this->clusterDebounce; /*0x1410a41c1*/
    assignment.oldValue = clusterDebounce; /*0x1410a41c4*/
    this->clusterDebounce = true; /*0x1410a41c9*/
    v7 = 16 * regionId->internalValue.z; /*0x1410a41cf*/
    v8 = 16 * regionId->internalValue.y; /*0x1410a41d5*/
    region.begin_.x = 16 * regionId->internalValue.x; /*0x1410a41dd*/
    region.begin_.y = v8; /*0x1410a41e1*/
    region.begin_.z = v7; /*0x1410a41e5*/
    region.end_.x = region.begin_.x + 16; /*0x1410a41f2*/
    region.end_.y = v8 + 16; /*0x1410a41f6*/
    region.end_.z = v7 + 16; /*0x1410a41fa*/
    __wind /*0xf1c0000000000010*/
    {
      RBX::Voxel2::Grid::eraseHigherResolution( /*0x1410a4210*/
        this: *(RBX::Voxel2::Grid **)&megaClusterInstance->clusterCoordinateFrame[32],
        &region,
        maxLod: 3u);
      if ( RBX::Time::now<1>(&result)->sec - this->deletedTerrainPerSec.timer.start.sec >= this->deletedTerrainPerSec.interval ) /*0x1410a4233*/
      {
        *(_QWORD *)&this->deletedTerrainPerSec.valueLastInterval = (unsigned int)this->deletedTerrainPerSec.valueCurrentInterval; /*0x1410a423b*/
        RBX::Time::now<1>(&result); /*0x1410a4250*/
        this->deletedTerrainPerSec.timer.start = result; /*0x1410a425b*/
      }
      ++this->deletedTerrainPerSec.valueCurrentInterval; /*0x1410a4263*/
    }
    __unwind
    {
      RBX::ScopedAssign<unsigned char>::~ScopedAssign<unsigned char>(this: (RBX::ScopedAssign<unsigned char> *)&assignment); /*0xf1c0000000000008*/
    }
    *p_clusterDebounce = clusterDebounce; /*0x1410a4269*/
  }
}

// Address: 0x1410a4280 | Name: ?stringToHtmlFileDumpToLogDirHelper@ClientReplicator@Network@RBX@@AEAA_NAEAVpath@filesystem@boost@@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
__int64 __fastcall RBX::Network::ClientReplicator::stringToHtmlFileDumpToLogDirHelper(
        RBX::Network::ClientReplicator *this,
        boost::filesystem::path *logPath,
        const std::string *string)
{
  RBX::Network::ClientReplicator *v5; // r14
  struct tm *v6; // rax
  unsigned __int64 Mysize; // rcx
  boost::filesystem::path *UserDirectory; // rax
  const wchar_t *v9; // rbx
  const wchar_t *v10; // rdi
  const std::codecvt<wchar_t,char,_Mbstatet> *v11; // rax
  boost::filesystem::path *Ptr; // rax
  std::string *p_to; // rbx
  const char *v14; // rbx
  std::string *v15; // rdi
  const std::codecvt<wchar_t,char,_Mbstatet> *v16; // rax
  char *v17; // rcx
  const char *RBXLogPrefix; // rax
  RBX::Graphics::ProfilerAdorn::Item *v19; // rax
  wchar_t *v20; // rcx
  size_t v21; // r15
  std::string *p_logGuid; // r13
  unsigned __int64 v23; // r14
  unsigned __int64 v24; // rbx
  char *v25; // rdi
  unsigned __int64 v26; // rax
  void *v27; // rax
  unsigned __int64 v28; // rcx
  std::string *v29; // rax
  std::string *v30; // rax
  unsigned __int64 v31; // rdi
  unsigned __int64 v32; // rcx
  std::string *v33; // rbx
  char *v34; // rbx
  boost::filesystem::path *v35; // rax
  wchar_t *v36; // rcx
  char *v37; // rcx
  char *v38; // rcx
  unsigned __int8 v39; // bl
  FILE *v40; // rax
  FILE *v41; // rbx
  size_t v42; // rdx
  char *v43; // rcx
  std::string to; // [rsp+30h] [rbp-A9h] BYREF
  std::string v46; // [rsp+50h] [rbp-89h] BYREF
  boost::filesystem::path v47; // [rsp+70h] [rbp-69h] BYREF
  std::string logGuid; // [rsp+90h] [rbp-49h] BYREF
  boost::system::error_code err; // [rsp+B0h] [rbp-29h] BYREF
  char fileName[112]; // [rsp+C0h] [rbp-19h] BYREF
  boost::filesystem::file_status v52; // [rsp+148h] [rbp+6Fh] BYREF
  __int64 t; // [rsp+158h] [rbp+7Fh] BYREF

  v5 = this; /*0x1410a42a7*/
  v52.m_value = status_error; /*0x1410a42ad*/
  t = _time64(Time: nullptr); /*0x1410a42b9*/
  memset(fileName, 0, 64); /*0x1410a42c0*/
  v6 = _localtime64(Time: &t); /*0x1410a42d4*/
  strftime(Buffer: fileName, SizeInBytes: 0x40u, Format: "microprofile_%Y%m%d-%H%M%S.html", Tm: v6); /*0x1410a42ec*/
  __wind /*0xf1c0000000000094*/
  {
    logGuid._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410a42f2*/
    logGuid._Mypair._Myval2._Mysize = 0; /*0x1410a42f6*/
    logGuid._Mypair._Myval2._Myres = 15; /*0x1410a42fa*/
    RBX::getRBXLogGUID(result: &logGuid); /*0x1410a430a*/
    UserDirectory = RBX::FileSystem::getUserDirectory( /*0x1410a431f*/
                      result: &v47,
                      create: true,
                      dir: DirAppData,
                      subDirectory: (const char *)&MainCrashLogManager::`vftable'[1]);
    v9 = (const wchar_t *)UserDirectory; /*0x1410a4324*/
    __wind /*0xf1c00000000000a0*/
    {
      __wind /*0xf1c00000000000a8*/
      {
        to._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410a4327*/
        to._Mypair._Myval2._Mysize = 0; /*0x1410a432c*/
        to._Mypair._Myval2._Myres = 15; /*0x1410a4331*/
        v52.m_value = file_not_found; /*0x1410a433f*/
        Mysize = UserDirectory->m_pathname._Mypair._Myval2._Mysize; /*0x1410a4346*/
        if ( Mysize != 0 ) /*0x1410a434d*/
        {
          if ( UserDirectory->m_pathname._Mypair._Myval2._Myres >= 8 ) /*0x1410a4354*/
          {
            UserDirectory = (boost::filesystem::path *)UserDirectory->m_pathname._Mypair._Myval2._Bx._Ptr; /*0x1410a4356*/
            v9 = (const wchar_t *)UserDirectory; /*0x1410a4359*/
          }
          v10 = &UserDirectory->m_pathname._Mypair._Myval2._Bx._Buf[Mysize]; /*0x1410a435c*/
          v11 = boost::filesystem::path::codecvt(); /*0x1410a4360*/
          boost::filesystem::path_traits::convert(from: v9, from_end: v10, &to, cvt: v11); /*0x1410a4373*/
        }
        Ptr = logPath; /*0x1410a4378*/
        if ( logPath->m_pathname._Mypair._Myval2._Myres >= 8 ) /*0x1410a4380*/
          Ptr = (boost::filesystem::path *)logPath->m_pathname._Mypair._Myval2._Bx._Ptr; /*0x1410a4382*/
        logPath->m_pathname._Mypair._Myval2._Mysize = 0; /*0x1410a4385*/
        Ptr->m_pathname._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410a4389*/
        if ( to._Mypair._Myval2._Mysize != 0 ) /*0x1410a4395*/
        {
          p_to = &to; /*0x1410a4397*/
          if ( to._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a43a2*/
            p_to = (std::string *)to._Mypair._Myval2._Bx._Ptr; /*0x1410a43a2*/
          v14 = &p_to->_Mypair._Myval2._Bx._Buf[to._Mypair._Myval2._Mysize]; /*0x1410a43a8*/
          v15 = &to; /*0x1410a43ab*/
          if ( to._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a43b6*/
            v15 = (std::string *)to._Mypair._Myval2._Bx._Ptr; /*0x1410a43b6*/
          v16 = boost::filesystem::path::codecvt(); /*0x1410a43bc*/
          boost::filesystem::path_traits::convert( /*0x1410a43cd*/
            from: v15->_Mypair._Myval2._Bx._Buf,
            from_end: v14,
            to: &logPath->m_pathname,
            cvt: v16);
        }
      }
      __unwind
      {
        if ( (v52.m_value & 1) != 0 ) /*0x1431ec344*/
        {
          v52.m_value &= ~1u; /*0x1431ec346*/
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&to); /*0x1431ec351*/
        }
      }
      if ( to._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a43dc*/
      {
        v17 = to._Mypair._Myval2._Bx._Ptr; /*0x1410a43e1*/
        if ( to._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a43f0*/
        {
          v17 = *((char **)to._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a43f6*/
          if ( (unsigned __int64)(to._Mypair._Myval2._Bx._Ptr - v17 - 8) > 0x1F ) /*0x1410a4405*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410a4407*/
        }
        operator delete(ptr: v17); /*0x1410a440e*/
      }
      to._Mypair._Myval2._Mysize = 0; /*0x1410a4413*/
      to._Mypair._Myval2._Myres = 15; /*0x1410a4418*/
      to._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410a4421*/
      boost::filesystem::path::~path(this: (std::pair<std::wstring const ,char const *> *)&v47); /*0x1410a442a*/
    }
    __unwind
    {
      boost::filesystem::path::~path(this: (std::pair<std::wstring const ,char const *> *)&v47); /*0xf1c0000000000080*/
    }
    if ( DFFlag::UseVerboseLogPrefixEverywhere.value ) /*0x1410a4436*/
    {
      RBXLogPrefix = RBX::LogGuid::getRBXLogPrefix(); /*0x1410a4438*/
      v19 = RBX::format(result: (RBX::Graphics::ProfilerAdorn::Item *)&v47, fmt: "%s_%s", RBXLogPrefix, fileName); /*0x1410a444f*/
      __wind /*0xf1c0000000000070*/
      {
        boost::filesystem::path::operator/=<std::string>(this: logPath, source: &v19->text); /*0x1410a445b*/
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v47); /*0xf1c0000000000068*/
      }
      if ( v47.m_pathname._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a4469*/
      {
        v20 = v47.m_pathname._Mypair._Myval2._Bx._Ptr; /*0x1410a4472*/
        if ( v47.m_pathname._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a4480*/
        {
          v20 = *((wchar_t **)v47.m_pathname._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a4486*/
          if ( (unsigned __int64)((char *)v47.m_pathname._Mypair._Myval2._Bx._Ptr - (char *)v20 - 8) > 0x1F ) /*0x1410a4495*/
            _invalid_parameter_noinfo_noreturn(); /*0x1410a4497*/
        }
        operator delete(ptr: v20); /*0x1410a449e*/
      }
      goto LABEL_74; /*0x1410a44a3*/
    }
    v21 = logGuid._Mypair._Myval2._Mysize; /*0x1410a44a8*/
    if ( 0x7FFFFFFFFFFFFFFFLL - logGuid._Mypair._Myval2._Mysize < 4 ) /*0x1410a44c0*/
      std::_Xlen_string(); /*0x1410a487a*/
    p_logGuid = &logGuid; /*0x1410a44c6*/
    if ( logGuid._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a44cf*/
      p_logGuid = (std::string *)logGuid._Mypair._Myval2._Bx._Ptr; /*0x1410a44cf*/
    to._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410a44d6*/
    to._Mypair._Myval2._Mysize = 0; /*0x1410a44db*/
    to._Mypair._Myval2._Myres = 0; /*0x1410a44e0*/
    v23 = logGuid._Mypair._Myval2._Mysize + 4; /*0x1410a44e5*/
    v24 = 15; /*0x1410a44e9*/
    v25 = (char *)&to; /*0x1410a44ee*/
    if ( logGuid._Mypair._Myval2._Mysize + 4 <= 0xF ) /*0x1410a44f6*/
    {
LABEL_44:
      to._Mypair._Myval2._Mysize = v21 + 4; /*0x1410a456f*/
      to._Mypair._Myval2._Myres = v24; /*0x1410a4574*/
      *(_DWORD *)v25 = 1600614252; /*0x1410a4579*/
      memcpy_0(a1: v25 + 4, Src: p_logGuid, Size: v21); /*0x1410a4589*/
      v25[v23] = 0; /*0x1410a458e*/
      __wind /*0xf1c0000000000058*/
      {
        v28 = to._Mypair._Myval2._Mysize; /*0x1410a4593*/
        if ( to._Mypair._Myval2._Myres == to._Mypair._Myval2._Mysize ) /*0x1410a45a7*/
        {
          v30 = std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x1410a45ea*/
                  this: &to,
                  _Size_increase: 1u,
                  _Fn: 0,
                  <_Args_0>: "_",
                  <_Args_1>: 1u);
        }
        else
        {
          ++to._Mypair._Myval2._Mysize; /*0x1410a45ad*/
          v29 = &to; /*0x1410a45b2*/
          if ( to._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a45bb*/
            v29 = (std::string *)to._Mypair._Myval2._Bx._Ptr; /*0x1410a45bb*/
          *(_WORD *)&v29->_Mypair._Myval2._Bx._Buf[v28] = 95; /*0x1410a45c1*/
          v30 = &to; /*0x1410a45c7*/
        }
        v46._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410a45f2*/
        v46._Mypair._Myval2._Mysize = 0; /*0x1410a45f7*/
        v46._Mypair._Myval2._Myres = 0; /*0x1410a45fb*/
        v46 = *v30; /*0x1410a4602*/
        v30->_Mypair._Myval2._Mysize = 0; /*0x1410a460f*/
        v30->_Mypair._Myval2._Myres = 15; /*0x1410a4613*/
        v30->_Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410a461b*/
        __wind /*0xf1c0000000000034*/
        {
          v31 = -1; /*0x1410a4622*/
          do /*0x1410a4637*/
            ++v31; /*0x1410a4630*/
          while ( fileName[v31] != 0 ); /*0x1410a4637*/
          v32 = v46._Mypair._Myval2._Mysize; /*0x1410a4639*/
          if ( v31 > v46._Mypair._Myval2._Myres - v46._Mypair._Myval2._Mysize ) /*0x1410a464a*/
          {
            v35 = (boost::filesystem::path *)std::string::_Reallocate_grow_by<_lambda_65e615be2a453ca0576c979606f46740_,char const *,unsigned __int64>( /*0x1410a4694*/
                                               this: &v46,
                                               _Size_increase: v31,
                                               _Fn: 0,
                                               <_Args_0>: fileName,
                                               <_Args_1>: v31);
          }
          else
          {
            v46._Mypair._Myval2._Mysize += v31; /*0x1410a4650*/
            v33 = &v46; /*0x1410a4654*/
            if ( v46._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a465d*/
              v33 = (std::string *)v46._Mypair._Myval2._Bx._Ptr; /*0x1410a465d*/
            v34 = &v33->_Mypair._Myval2._Bx._Buf[v32]; /*0x1410a4663*/
            memmove_0(a1: v34, Src: fileName, Size: v31); /*0x1410a4670*/
            v34[v31] = 0; /*0x1410a4675*/
            v35 = (boost::filesystem::path *)&v46; /*0x1410a4679*/
          }
          v47.m_pathname._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410a4699*/
          v47.m_pathname._Mypair._Myval2._Mysize = 0; /*0x1410a469d*/
          v47.m_pathname._Mypair._Myval2._Myres = 0; /*0x1410a46a1*/
          v47 = *v35; /*0x1410a46a8*/
          v35->m_pathname._Mypair._Myval2._Mysize = 0; /*0x1410a46b4*/
          v35->m_pathname._Mypair._Myval2._Myres = 15; /*0x1410a46b8*/
          v35->m_pathname._Mypair._Myval2._Bx._Alias[0] = 0; /*0x1410a46c0*/
          __wind /*0xf1c0000000000028*/
          {
            boost::filesystem::path::operator/=<std::string>(this: logPath, source: (const std::string *)&v47); /*0x1410a46ca*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v47); /*0xf1c0000000000020*/
          }
          if ( v47.m_pathname._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a46d8*/
          {
            v36 = v47.m_pathname._Mypair._Myval2._Bx._Ptr; /*0x1410a46dd*/
            if ( v47.m_pathname._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a46eb*/
            {
              v36 = *((wchar_t **)v47.m_pathname._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a46f1*/
              if ( (unsigned __int64)((char *)v47.m_pathname._Mypair._Myval2._Bx._Ptr - (char *)v36 - 8) > 0x1F ) /*0x1410a4700*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410a4702*/
            }
            operator delete(ptr: v36); /*0x1410a4709*/
          }
          v47.m_pathname._Mypair._Myval2._Mysize = 0; /*0x1410a470e*/
          v47.m_pathname._Mypair._Myval2._Myres = 15; /*0x1410a4712*/
          v47.m_pathname._Mypair._Myval2._Bx._Alias[0] = 0; /*0x1410a471a*/
          if ( v46._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a4726*/
          {
            v37 = v46._Mypair._Myval2._Bx._Ptr; /*0x1410a472b*/
            if ( v46._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a473a*/
            {
              v37 = *((char **)v46._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a4740*/
              if ( (unsigned __int64)(v46._Mypair._Myval2._Bx._Ptr - v37 - 8) > 0x1F ) /*0x1410a474f*/
                _invalid_parameter_noinfo_noreturn(); /*0x1410a4751*/
            }
            operator delete(ptr: v37); /*0x1410a4758*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v46); /*0xf1c0000000000044*/
        }
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&to); /*0xf1c0000000000050*/
      }
      v46._Mypair._Myval2._Mysize = 0; /*0x1410a475d*/
      v46._Mypair._Myval2._Myres = 15; /*0x1410a4761*/
      v46._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410a4769*/
      if ( to._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a4777*/
      {
        v38 = to._Mypair._Myval2._Bx._Ptr; /*0x1410a477c*/
        if ( to._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a478b*/
        {
          v38 = *((char **)to._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a4791*/
          if ( (unsigned __int64)(to._Mypair._Myval2._Bx._Ptr - v38 - 8) > 0x1F ) /*0x1410a47a0*/
LABEL_71:
            _invalid_parameter_noinfo_noreturn(); /*0x1410a47a2*/
        }
        operator delete(ptr: v38); /*0x1410a47a9*/
      }
      v5 = this; /*0x1410a47ae*/
LABEL_74:
      err.m_val = 0; /*0x1410a47b2*/
      err.m_cat = boost::system::system_category(); /*0x1410a47bb*/
      if ( boost::filesystem::detail::status(result: &v52, p: logPath, ec: &err)->m_value <= (unsigned int)file_not_found ) /*0x1410a47d2*/
      {
        v40 = RBX::FileSystem::openFileWrite(path: logPath); /*0x1410a47e3*/
        v41 = v40; /*0x1410a47e8*/
        if ( v40 != nullptr ) /*0x1410a47ee*/
        {
          v42 = string->_Mypair._Myval2._Mysize; /*0x1410a47f0*/
          if ( string->_Mypair._Myval2._Myres >= 0x10 ) /*0x1410a47fb*/
            string = (const std::string *)string->_Mypair._Myval2._Bx._Ptr; /*0x1410a47fd*/
          fwrite(Buffer: string, ElementSize: v42, ElementCount: 1u, Stream: v40); /*0x1410a480d*/
          fclose(Stream: v41); /*0x1410a4816*/
        }
        v39 = 1; /*0x1410a481c*/
      }
      else
      {
        v5->isProfilingRequested = false; /*0x1410a47d4*/
        v39 = 0; /*0x1410a47dc*/
      }
      goto LABEL_92; /*0x1410a47de*/
    }
    v24 = v23 | 0xF; /*0x1410a44fb*/
    if ( (v23 | 0xF) <= 0x7FFFFFFFFFFFFFFFLL ) /*0x1410a4502*/
    {
      if ( v24 < 0x16 ) /*0x1410a4538*/
        v24 = 22; /*0x1410a4538*/
      if ( v24 + 1 < 0x1000 ) /*0x1410a4547*/
      {
        if ( v24 == -1 ) /*0x1410a455b*/
          v25 = nullptr; /*0x1410a4567*/
        else
          v25 = (char *)operator new(size: v24 + 1); /*0x1410a4562*/
LABEL_43:
        to._Mypair._Myval2._Bx._Ptr = v25; /*0x1410a456a*/
        goto LABEL_44; /*0x1410a456a*/
      }
      v26 = v24 + 40; /*0x1410a4549*/
      if ( v24 + 40 < v24 + 1 ) /*0x1410a4550*/
        std::_Throw_bad_array_new_length(); /*0x1410a4880*/
    }
    else
    {
      v24 = 0x7FFFFFFFFFFFFFFFLL; /*0x1410a4504*/
      v26 = 0x8000000000000027uLL; /*0x1410a4507*/
    }
    v27 = operator new(size: v26); /*0x1410a4514*/
    if ( v27 == nullptr ) /*0x1410a451c*/
      goto LABEL_71; /*0x1410a451c*/
    v25 = (char *)(((unsigned __int64)v27 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x1410a4526*/
    *((_QWORD *)v25 - 1) = v27; /*0x1410a452a*/
    goto LABEL_43; /*0x1410a452e*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&logGuid); /*0xf1c0000000000014*/
  }
LABEL_92:
  if ( logGuid._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a4826*/
  {
    v43 = logGuid._Mypair._Myval2._Bx._Ptr; /*0x1410a482b*/
    if ( logGuid._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a4839*/
    {
      v43 = *((char **)logGuid._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a483f*/
      if ( (unsigned __int64)(logGuid._Mypair._Myval2._Bx._Ptr - v43 - 8) > 0x1F ) /*0x1410a484e*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410a4850*/
    }
    operator delete(ptr: v43); /*0x1410a4857*/
  }
  return v39; /*0x1410a485f*/
}

// Address: 0x1410a4890 | Name: ?testSetSyncExpiration@ClientReplicator@Network@RBX@@UEAAXN@Z
void __fastcall RBX::Network::ClientReplicator::testSetSyncExpiration(
        RBX::Network::ClientReplicator *this,
        long double value)
{
  if ( (this->peerCapability & 2) != 0 ) /*0x1410a489b*/
  {
    this->propSync.expirationTime.sec = value; /*0x1410a489d*/
    this->attrSync.expirationTime.sec = value; /*0x1410a48a5*/
  }
  else
  {
    this->propSync.expirationTime.sec = value; /*0x1410a48ae*/
  }
}

// Address: 0x1410a4af0 | Name: ?updateClientCapacity@ClientReplicator@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::ClientReplicator::updateClientCapacity(RBX::Network::ClientReplicator *this)
{
  double v2; // xmm0_8
  char v3; // r13
  char v4; // al
  const void *v5; // rbx
  const void *v6; // rax
  int *p_clientInstanceQuota; // r12
  int clientInstanceQuota; // r15d
  float v9; // xmm12_4
  char *v10; // rax
  unsigned __int64 v11; // rsi
  unsigned __int64 v12; // r13
  char *v13; // rax
  float v14; // xmm11_4
  float averageValue; // xmm9_4
  int valueLastInterval; // ebx
  int v17; // eax
  float v18; // xmm8_4
  __int64 v19; // rax
  double v20; // xmm1_8
  int v21; // ebx
  int v22; // eax
  float v23; // xmm7_4
  __int64 v24; // rax
  float v25; // xmm6_4
  float v26; // xmm6_4
  int v27; // edx
  float v28; // xmm1_4
  int v29; // ecx
  int v30; // eax
  unsigned __int64 v31; // r15
  RBX::Graphics::ProfilerAdorn::Item *v32; // rbx
  unsigned __int64 v33; // rbx
  unsigned __int64 v34; // rax
  unsigned __int64 v35; // rax
  RBX::Graphics::ProfilerAdorn::Item *v36; // rbx
  unsigned __int64 v37; // rbx
  unsigned __int64 v38; // rax
  unsigned __int64 v39; // rax
  void *v40; // rax
  _BYTE *v41; // r14
  char v42; // al
  void *v43; // rax
  char *v44; // rcx
  int v45; // ebx
  int v46; // eax
  int v47; // ecx
  RBX::Network::ClientReplicator::GCJob *Ptr; // rax
  __m128i v49; // xmm1
  float v50; // xmm1_4
  int *v51; // rcx
  unsigned __int64 Myres; // r14
  char *v53; // rbx
  unsigned __int64 v54; // rcx
  void *v55; // rax
  char *v56; // rbx
  char *v57; // rcx
  bool updated; // al
  int v59; // r14d
  unsigned __int64 v60; // r14
  char *v61; // rbx
  unsigned __int64 v62; // rcx
  void *v63; // rax
  double v64; // xmm6_8
  double v65; // xmm7_8
  int v66; // eax
  char v67; // r13
  RBX::Network::Item *v68; // rax
  RBX::Network::Item *v69; // rsi
  __int16 MaxRegionDistance; // bx
  RBX::Network::Item *v71; // rax
  __int16 v72; // bx
  std::pair<std::_List_node<std::pair<std::string const ,int>,void *> *,bool> *v73; // rax
  __int16 v74; // bx
  double v75; // xmm6_8
  double lerp; // xmm3_8
  double v77; // xmm1_8
  double v78; // xmm2_8
  char *v79; // rcx
  std::pair<std::_List_node<std::pair<std::string const ,int>,void *> *,bool> v80; // [rsp+48h] [rbp-89h] BYREF
  RBX::Graphics::ProfilerAdorn::Item _Keyval_arg[2]; // [rsp+58h] [rbp-79h] BYREF
  char v82; // [rsp+138h] [rbp+67h]
  RBX::Network::Item *v83; // [rsp+138h] [rbp+67h]
  RBX::Network::Item *v84; // [rsp+138h] [rbp+67h]
  RBX::Time v85; // [rsp+140h] [rbp+6Fh] BYREF
  RBX::Time result; // [rsp+148h] [rbp+77h] BYREF
  RBX::Time v87; // [rsp+150h] [rbp+7Fh] BYREF

  v2 = RBX::Time::nowFastSec(); /*0x1410a4b38*/
  if ( v2 - this->sampleTimer <= 0.125 ) /*0x1410a4b50*/
    return; /*0x1410a4b50*/
  this->sampleTimer = v2; /*0x1410a4b56*/
  if ( this->gcJob._Ptr->emergencyGC || this->memoryLevel < MEMORYLEVEL_OK )
  {
    v3 = 0; /*0x1410a4b88*/
    v82 = 0; /*0x1410a4b8b*/
    v4 = 0; /*0x1410a4b8f*/
    if ( !this->loggedLowMemWarning )
    {
      if ( DFLog::PartStreamingRequests != 0 )
      {
        v5 = (const void *)((FInt::StreamingCriticalLowMemWatermarkMB << 20) - RBX::MemoryStats::freeMemoryBytes()); /*0x1410a4bb2*/
        v6 = (const void *)RBX::MemoryStats::freeMemoryBytes(); /*0x1410a4bb5*/
        FLog::FastLog(
          level: DFLog::PartStreamingRequests,
          message: "[DFLog::PartStreamingRequests] Not enough memory to request more parts: %u free, %u additional required",
          arg0: v6,
          arg1: v5,
          arg2: nullptr);
      }
      this->loggedLowMemWarning = true; /*0x1410a4bdc*/
      v4 = 1; /*0x1410a4be3*/
    }
  }
  else
  {
    v3 = 1; /*0x1410a4b77*/
    v82 = 1; /*0x1410a4b7a*/
    v4 = 0; /*0x1410a4b7e*/
    this->loggedLowMemWarning = false; /*0x1410a4b80*/
  }
  p_clientInstanceQuota = &this->clientInstanceQuota; /*0x1410a4be5*/
  clientInstanceQuota = this->clientInstanceQuota; /*0x1410a4bec*/
  LODWORD(v85.sec) = clientInstanceQuota; /*0x1410a4bf0*/
  v9 = 0.0; /*0x1410a4bf8*/
  _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410a4bfc*/
  _Keyval_arg[0].text._Mypair._Myval2._Mysize = 0; /*0x1410a4c04*/
  _Keyval_arg[0].text._Mypair._Myval2._Myres = 15; /*0x1410a4c0c*/
  __wind /*0xf1c0000000000054*/
  {
    if ( v3 == 0 && v4 != 0 ) /*0x1410a4c1f*/
    {
      *p_clientInstanceQuota = 0; /*0x1410a4c21*/
      if ( DFFlag::StreamingReportPerformanceStatsAddInstanceQuota.value ) /*0x1410a4c30*/
      {
        v10 = (char *)operator new(size: 0x30u); /*0x1410a4c3b*/
        _Keyval_arg[0].text._Mypair._Myval2._Mysize = 33; /*0x1410a4c40*/
        _Keyval_arg[0].text._Mypair._Myval2._Myres = 47; /*0x1410a4c4d*/
        strcpy(v10, "QuotaNotEnoughMemoryFirstLowCount"); /*0x1410a4c58*/
        _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr = v10; /*0x1410a4c74*/
      }
      goto LABEL_156; /*0x1410a4c78*/
    }
    v11 = 0x7FFFFFFFFFFFFFFFLL; /*0x1410a4c7d*/
    v12 = 0x8000000000000027uLL; /*0x1410a4c87*/
    if ( this->avgStreamDataReadTime.firstTime ) /*0x1410a4c91*/
    {
      *p_clientInstanceQuota = DFInt::ClientInstanceQuotaInitial; /*0x1410a4ca0*/
      if ( DFFlag::StreamingReportPerformanceStatsAddInstanceQuota.value ) /*0x1410a4cab*/
      {
        v13 = (char *)operator new(size: 0x20u); /*0x1410a4cb6*/
        _Keyval_arg[0].text._Mypair._Myval2._Mysize = 22; /*0x1410a4cbb*/
        _Keyval_arg[0].text._Mypair._Myval2._Myres = 31; /*0x1410a4cc8*/
        strcpy(v13, "QuotaInitialValueCount"); /*0x1410a4cd3*/
        _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr = v13; /*0x1410a4cee*/
      }
      goto LABEL_121; /*0x1410a4cf2*/
    }
    v14 = this->avgStreamDataReadTime.averageValue / this->avgInstancesPerStreamData.averageValue; /*0x1410a4d07*/
    averageValue = 0.0; /*0x1410a4d0c*/
    if ( !this->avgTerrainDataReadTime.firstTime ) /*0x1410a4d17*/
      averageValue = this->avgTerrainDataReadTime.averageValue; /*0x1410a4d22*/
    if ( this->incomingPacketsProcessedPerSec.interval < RBX::Time::now<1>(&result)->sec /*0x1410a4d51*/
                                                       - this->incomingPacketsProcessedPerSec.timer.start.sec
      || this->incomingPacketsProcessedPerSec.valueLastInterval <= 0 )
    {
      v18 = 0.0; /*0x1410a4dc4*/
    }
    else
    {
      if ( this->streamDataPerSec.interval < RBX::Time::now<1>(&result)->sec - this->streamDataPerSec.timer.start.sec ) /*0x1410a4d74*/
        valueLastInterval = 0; /*0x1410a4d7e*/
      else
        valueLastInterval = this->streamDataPerSec.valueLastInterval; /*0x1410a4d76*/
      if ( this->incomingPacketsProcessedPerSec.interval < RBX::Time::now<1>(result: &v87)->sec /*0x1410a4da1*/
                                                         - this->incomingPacketsProcessedPerSec.timer.start.sec )
        v17 = 0; /*0x1410a4dab*/
      else
        v17 = this->incomingPacketsProcessedPerSec.valueLastInterval; /*0x1410a4da3*/
      v18 = (float)valueLastInterval / (float)v17; /*0x1410a4dbd*/
    }
    v19 = RBX::Network::Replicator::incomingPacketsCount(this); /*0x1410a4dcb*/
    if ( v19 < 0 ) /*0x1410a4dd9*/
      v20 = (double)(int)(v19 & 1 | ((unsigned __int64)v19 >> 1)) /*0x1410a4df0*/
          + (double)(int)(v19 & 1 | ((unsigned __int64)v19 >> 1));
    else
      v20 = (double)(int)v19; /*0x1410a4ddb*/
    v9 = (float)(v20 * this->avgInstancesPerStreamData.averageValue * v18) * v14; /*0x1410a4e09*/
    if ( this->incomingPacketsProcessedPerSec.interval < RBX::Time::now<1>(&result)->sec /*0x1410a4e38*/
                                                       - this->incomingPacketsProcessedPerSec.timer.start.sec
      || this->incomingPacketsProcessedPerSec.valueLastInterval <= 0 )
    {
      v23 = 0.0; /*0x1410a4ea8*/
    }
    else
    {
      if ( this->terrainPerSec.interval < RBX::Time::now<1>(&result)->sec - this->terrainPerSec.timer.start.sec ) /*0x1410a4e5b*/
        v21 = 0; /*0x1410a4e65*/
      else
        v21 = this->terrainPerSec.valueLastInterval; /*0x1410a4e5d*/
      if ( this->incomingPacketsProcessedPerSec.interval < RBX::Time::now<1>(result: &v87)->sec /*0x1410a4e88*/
                                                         - this->incomingPacketsProcessedPerSec.timer.start.sec )
        v22 = 0; /*0x1410a4e92*/
      else
        v22 = this->incomingPacketsProcessedPerSec.valueLastInterval; /*0x1410a4e8a*/
      v23 = (float)v21 / (float)v22; /*0x1410a4ea2*/
    }
    v24 = RBX::Network::Replicator::incomingPacketsCount(this); /*0x1410a4eae*/
    if ( v24 < 0 ) /*0x1410a4ebc*/
      v25 = (float)(v24 & 1 | (unsigned int)((unsigned __int64)v24 >> 1)) /*0x1410a4ed3*/
          + (float)(v24 & 1 | (unsigned int)((unsigned __int64)v24 >> 1));
    else
      v25 = (float)(int)v24; /*0x1410a4ebe*/
    v26 = (float)(v25 * v23) * averageValue; /*0x1410a4edb*/
    if ( DFFlag::StreamingReportPerformanceStatsAddInstanceQuota.value ) /*0x1410a4ee7*/
    {
      RBX::RunningAverage<float,double>::sample(this: &this->avgFractionStreamData, value: v18); /*0x1410a4ef4*/
      RBX::RunningAverage<float,double>::sample(this: &this->avgFractionTerrainData, value: v23); /*0x1410a4f03*/
      if ( this->incomingPacketsProcessedPerSec.interval < RBX::Time::now<1>(&result)->sec /*0x1410a4f29*/
                                                         - this->incomingPacketsProcessedPerSec.timer.start.sec )
        v27 = 0; /*0x1410a4f33*/
      else
        v27 = this->incomingPacketsProcessedPerSec.valueLastInterval; /*0x1410a4f2b*/
      RBX::RunningAverage<int,double>::sample(this: &this->avgIncomingPacketsProcessedPerSec, value: v27); /*0x1410a4f3c*/
    }
    if ( DFFlag::StreamingInstanceQuotaWhenNoTerrainFix.value ) /*0x1410a4f48*/
    {
      if ( v18 > 0.0 && v14 != 0.0 || v23 > 0.0 && averageValue != 0.0 ) /*0x1410a4f6c*/
      {
        v28 = (float)(0.25 - v9) - v26; /*0x1410a4f7f*/
        if ( v14 == 0.0 ) /*0x1410a4f89*/
          v29 = 0; /*0x1410a4f8b*/
        else
          v29 = (int)(float)((float)(v28 * v18) / v14); /*0x1410a4f9c*/
        if ( averageValue == 0.0 ) /*0x1410a4fa6*/
          v30 = 0; /*0x1410a4fa8*/
        else
          v30 = (int)(float)((float)(v28 * v23) / averageValue); /*0x1410a4fb5*/
        *p_clientInstanceQuota = v29 + v30; /*0x1410a4fbb*/
        if ( !DFFlag::StreamingReportPerformanceStatsAddInstanceQuota.value ) /*0x1410a4fc6*/
        {
LABEL_117:
          if ( *p_clientInstanceQuota >= 1 ) /*0x1410a52df*/
          {
            if ( *p_clientInstanceQuota > DFInt::ClientInstanceQuotaCap ) /*0x1410a52f3*/
              *p_clientInstanceQuota = DFInt::ClientInstanceQuotaCap; /*0x1410a52f5*/
          }
          else
          {
            *p_clientInstanceQuota = 1; /*0x1410a52e1*/
          }
LABEL_121:
          if ( v82 != 0 ) /*0x1410a52fd*/
          {
LABEL_155:
            v3 = v82; /*0x1410a5503*/
LABEL_156:
            updated = RBX::Network::ClientReplicator::GCJob::updateMaxRegionDistance(this: this->gcJob._Ptr); /*0x1410a5508*/
            v59 = *p_clientInstanceQuota - clientInstanceQuota; /*0x1410a5518*/
            if ( *p_clientInstanceQuota != clientInstanceQuota || updated ) /*0x1410a551f*/
            {
              if ( DFFlag::StreamingReportPerformanceStatsAddInstanceQuota.value ) /*0x1410a552c*/
              {
                if ( v59 != 0 ) /*0x1410a5535*/
                {
                  ++this->countInstanceQuotaChanged; /*0x1410a553b*/
                  RBX::RunningAverage<int,double>::sample(this: &this->avgInstanceQuotaDiff, value: v59); /*0x1410a554b*/
                }
                else
                {
                  ++this->countMaxRegionDistanceChanged; /*0x1410a5682*/
                }
              }
              if ( this->networkSettings->printStreamInstanceQuota ) /*0x1410a568f*/
              {
                v64 = this->avgInstancesPerStreamData.averageValue; /*0x1410a5698*/
                v65 = this->avgStreamDataReadTime.averageValue; /*0x1410a56a0*/
                v66 = RBX::Network::Replicator::incomingPacketsCount(this); /*0x1410a56ab*/
                RBX::StandardOut::printf( /*0x1410a56d9*/
                  type: MESSAGE_INFO,
                  format: "clientInstanceQuota %d, packet in queue %d, predictedTotalInstanceProcessTime %f, avgStreamDataReadTim"
                  "e %f, avgInstancesPerStreamData %f",
                  *p_clientInstanceQuota,
                  v66,
                  v9,
                  v65,
                  v64);
              }
              if ( DFFlag::GameNetStreamingFixStreamOutPrefetchClient.value ) /*0x1410a56e5*/
              {
                v67 = v3 ^ 1; /*0x1410a56e7*/
                v68 = (RBX::Network::Item *)operator new(size: 0x48u); /*0x1410a56f0*/
                v69 = v68; /*0x1410a56f5*/
                v83 = v68; /*0x1410a56f8*/
                __wind /*0xf1c0000000000048*/
                {
                  if ( v68 != nullptr ) /*0x1410a56ff*/
                  {
                    MaxRegionDistance = RBX::Network::ClientReplicator::GCJob::getMaxRegionDistance(this: this->gcJob._Ptr); /*0x1410a570d*/
                    RBX::Network::Item::Item(this: v69, replicator: this); /*0x1410a5716*/
                    v69->__vftable = (RBX::Network::Item_vtbl *)RBX::Network::ClientReplicator::ClientStreamCapacityUpdateItem::`vftable'; /*0x1410a5722*/
                    LOBYTE(v69[1].__vftable) = v67; /*0x1410a5725*/
                    HIDWORD(v69[1].__vftable) = v59; /*0x1410a5729*/
                    LOWORD(v69[1].next_) = MaxRegionDistance; /*0x1410a572d*/
                  }
                  else
                  {
                    v69 = nullptr; /*0x1410a5733*/
                  }
                }
                __unwind
                {
                  operator delete(ptr: v83); /*0x143189315*/
                }
              }
              else
              {
                v71 = (RBX::Network::Item *)operator new(size: 0x40u); /*0x1410a573c*/
                v69 = v71; /*0x1410a5741*/
                v84 = v71; /*0x1410a5744*/
                __wind /*0xf1c0000000000030*/
                {
                  if ( v71 != nullptr ) /*0x1410a574b*/
                  {
                    v72 = RBX::Network::ClientReplicator::GCJob::getMaxRegionDistance(this: this->gcJob._Ptr); /*0x1410a5759*/
                    RBX::Network::Item::Item(this: v69, replicator: this); /*0x1410a5762*/
                    v69->__vftable = (RBX::Network::Item_vtbl *)RBX::Network::ClientReplicator::ClientCapacityUpdateItem::`vftable'; /*0x1410a576e*/
                    LODWORD(v69[1].__vftable) = v59; /*0x1410a5771*/
                    WORD2(v69[1].__vftable) = v72; /*0x1410a5775*/
                  }
                  else
                  {
                    v69 = nullptr; /*0x1410a577b*/
                  }
                }
                __unwind
                {
                  operator delete(ptr: v84); /*0x14319df15*/
                }
              }
              RBX::Network::ItemQueue::push_back(this: &this->pendingItems, item: v69); /*0x1410a5787*/
            }
            this->numInstancesRead = 0; /*0x1410a578c*/
            RBX::RunningAverage<int,double>::sample(this: &this->avgRequestCount, value: *p_clientInstanceQuota); /*0x1410a57a1*/
            if ( DFFlag::StreamingReportPerformanceStatsAddInstanceQuota.value ) /*0x1410a57ad*/
            {
              v73 = std::_Hash<std::_Umap_traits<std::string,int,std::_Uhash_compare<std::string,std::hash<std::string>,std::equal_to<std::string>>,std::allocator<std::pair<std::string const,int>>,0>>::_Try_emplace<std::string const &,>( /*0x1410a57c3*/
                      this: &this->instanceQuotaSourceCount,
                      result: &v80,
                      _Keyval_arg: &_Keyval_arg[0].text);
              ++v73->first->_Myval.second; /*0x1410a57cb*/
              v74 = RBX::Network::ClientReplicator::GCJob::getMaxRegionDistance(this: this->gcJob._Ptr); /*0x1410a57da*/
              v75 = (double)v74; /*0x1410a57e1*/
              if ( dclass_0(X: v75) <= 0 ) /*0x1410a57f0*/
              {
                lerp = this->avgMaxRegionDistance.lerp; /*0x1410a57f2*/
                v77 = 1.0 - lerp; /*0x1410a5802*/
                if ( this->avgMaxRegionDistance.firstTime ) /*0x1410a5806*/
                  v78 = v75; /*0x1410a580f*/
                else
                  v78 = v77 * this->avgMaxRegionDistance.averageValue + lerp * v75; /*0x1410a5826*/
                this->avgMaxRegionDistance.averageValue = v78; /*0x1410a582a*/
                this->avgMaxRegionDistance.lastSampleValue = v74; /*0x1410a5832*/
                this->avgMaxRegionDistance.firstTime = false; /*0x1410a5839*/
                this->avgMaxRegionDistance.averageVariance = lerp * ((v75 - v78) * (v75 - v78)) /*0x1410a5858*/
                                                           + v77 * this->avgMaxRegionDistance.averageVariance;
              }
            }
            goto LABEL_204; /*0xf1c0000000000060*/
          }
          if ( this->deletedInstancesPerSec.interval < RBX::Time::now<1>(result: &v85)->sec /*0x1410a5324*/
                                                     - this->deletedInstancesPerSec.timer.start.sec )
            v45 = 0; /*0x1410a532e*/
          else
            v45 = this->deletedInstancesPerSec.valueLastInterval; /*0x1410a5326*/
          if ( this->deletedTerrainPerSec.interval < RBX::Time::now<1>(&result)->sec /*0x1410a5351*/
                                                   - this->deletedTerrainPerSec.timer.start.sec )
            v46 = 0; /*0x1410a535b*/
          else
            v46 = this->deletedTerrainPerSec.valueLastInterval; /*0x1410a5353*/
          v47 = v46 + v45; /*0x1410a535d*/
          Ptr = this->gcJob._Ptr; /*0x1410a5360*/
          if ( Ptr->numRegionToGC > 0 || Ptr->emergencyGC || this->memoryLevel <= MEMORYLEVEL_ALL_LOW ) /*0x1410a5380*/
            v49 = _mm_cvtsi32_si128(DFInt::GCReducesQuotaCriticalPercent); /*0x1410a538c*/
          else
            v49 = _mm_cvtsi32_si128(DFInt::GCReducesQuotaPercent); /*0x1410a5382*/
          v50 = _mm_cvtepi32_ps(v49).m128_f32[0] / 100.0; /*0x1410a5397*/
          if ( v50 > 0.0 && v47 > DFInt::GCMinimumDeletionRateForNonZeroClientInstanceQuota ) /*0x1410a53af*/
          {
            LODWORD(v85.sec) = (int)(float)((float)v47 * v50); /*0x1410a53c4*/
            v51 = (int *)&v85; /*0x1410a53c7*/
            if ( SLODWORD(v85.sec) >= *p_clientInstanceQuota ) /*0x1410a53cf*/
              v51 = &this->clientInstanceQuota; /*0x1410a53cf*/
            *p_clientInstanceQuota = *v51; /*0x1410a53d5*/
            if ( !DFFlag::StreamingReportPerformanceStatsAddInstanceQuota.value ) /*0x1410a53e0*/
              goto LABEL_155; /*0x1410a53e0*/
            Myres = _Keyval_arg[0].text._Mypair._Myval2._Myres; /*0x1410a53e6*/
            if ( _Keyval_arg[0].text._Mypair._Myval2._Myres >= 0x26 ) /*0x1410a53ee*/
            {
              v53 = _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr; /*0x1410a53f8*/
              _Keyval_arg[0].text._Mypair._Myval2._Mysize = 38; /*0x1410a53fd*/
              memmove_0( /*0x1410a5415*/
                a1: _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr,
                Src: "QuotaNotEnoughMemoryDeletionQuotaCount",
                Size: 0x26u);
              v53[38] = 0; /*0x1410a541a*/
              goto LABEL_155; /*0x1410a541e*/
            }
            v54 = _Keyval_arg[0].text._Mypair._Myval2._Myres >> 1; /*0x1410a5426*/
            if ( _Keyval_arg[0].text._Mypair._Myval2._Myres <= 0x7FFFFFFFFFFFFFFFLL /*0x1410a5432*/
                                                             - (_Keyval_arg[0].text._Mypair._Myval2._Myres >> 1) )
            {
              v11 = 47; /*0x1410a5438*/
              if ( _Keyval_arg[0].text._Mypair._Myval2._Myres + v54 > 0x2F ) /*0x1410a5440*/
                v11 = _Keyval_arg[0].text._Mypair._Myval2._Myres + v54; /*0x1410a5440*/
              if ( v11 + 1 < 0x1000 ) /*0x1410a544f*/
              {
                if ( v11 == -1 ) /*0x1410a5480*/
                  v56 = nullptr; /*0x1410a548c*/
                else
                  v56 = (char *)operator new(size: v11 + 1); /*0x1410a5487*/
LABEL_150:
                _Keyval_arg[0].text._Mypair._Myval2._Mysize = 38; /*0x1410a548e*/
                _Keyval_arg[0].text._Mypair._Myval2._Myres = v11; /*0x1410a5496*/
                strcpy(v56, "QuotaNotEnoughMemoryDeletionQuotaCount"); /*0x1410a54a1*/
                if ( Myres < 0x10 ) /*0x1410a54cb*/
                {
LABEL_154:
                  _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr = v56; /*0x1410a54ff*/
                  goto LABEL_155; /*0x1410a54ff*/
                }
                v57 = _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr; /*0x1410a54d1*/
                if ( Myres + 1 < 0x1000 /*0x1410a54f4*/
                  || (v57 = *((char **)_Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr - 1),
                      (unsigned __int64)(_Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr - v57 - 8) <= 0x1F) )
                {
LABEL_153:
                  operator delete(ptr: v57); /*0x1410a54fa*/
                  goto LABEL_154; /*0x1410a54fa*/
                }
LABEL_177:
                _invalid_parameter_noinfo_noreturn(); /*0x1410a567b*/
              }
              v12 = v11 + 40; /*0x1410a5451*/
              if ( v11 + 40 < v11 + 1 ) /*0x1410a5458*/
LABEL_203:
                std::_Throw_bad_array_new_length(); /*0x1410a58d9*/
            }
            v55 = operator new(size: v12); /*0x1410a5461*/
            if ( v55 == nullptr ) /*0x1410a5469*/
              goto LABEL_177; /*0x1410a5469*/
            v56 = (char *)(((unsigned __int64)v55 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x1410a5473*/
            *((_QWORD *)v56 - 1) = v55; /*0x1410a5477*/
            goto LABEL_150; /*0x1410a547b*/
          }
          *p_clientInstanceQuota = 0; /*0x1410a5555*/
          if ( !DFFlag::StreamingReportPerformanceStatsAddInstanceQuota.value ) /*0x1410a5564*/
            goto LABEL_155; /*0x1410a5564*/
          v60 = _Keyval_arg[0].text._Mypair._Myval2._Myres; /*0x1410a5566*/
          if ( _Keyval_arg[0].text._Mypair._Myval2._Myres >= 0x28 ) /*0x1410a556e*/
          {
            v61 = _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr; /*0x1410a5578*/
            _Keyval_arg[0].text._Mypair._Myval2._Mysize = 40; /*0x1410a557d*/
            memmove_0( /*0x1410a5595*/
              a1: _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr,
              Src: "QuotaNotEnoughMemoryDeletionTooSlowCount",
              Size: 0x28u);
            v61[40] = 0; /*0x1410a559a*/
            goto LABEL_155; /*0x1410a559e*/
          }
          v62 = _Keyval_arg[0].text._Mypair._Myval2._Myres >> 1; /*0x1410a55a6*/
          if ( _Keyval_arg[0].text._Mypair._Myval2._Myres <= 0x7FFFFFFFFFFFFFFFLL /*0x1410a55b2*/
                                                           - (_Keyval_arg[0].text._Mypair._Myval2._Myres >> 1) )
          {
            v11 = 47; /*0x1410a55b8*/
            if ( _Keyval_arg[0].text._Mypair._Myval2._Myres + v62 > 0x2F ) /*0x1410a55c0*/
              v11 = _Keyval_arg[0].text._Mypair._Myval2._Myres + v62; /*0x1410a55c0*/
            if ( v11 + 1 < 0x1000 ) /*0x1410a55cf*/
            {
              if ( v11 == -1 ) /*0x1410a5600*/
                v56 = nullptr; /*0x1410a560c*/
              else
                v56 = (char *)operator new(size: v11 + 1); /*0x1410a5607*/
LABEL_174:
              _Keyval_arg[0].text._Mypair._Myval2._Mysize = 40; /*0x1410a560e*/
              _Keyval_arg[0].text._Mypair._Myval2._Myres = v11; /*0x1410a5616*/
              strcpy(v56, "QuotaNotEnoughMemoryDeletionTooSlowCount"); /*0x1410a5621*/
              if ( v60 < 0x10 ) /*0x1410a5644*/
                goto LABEL_154; /*0x1410a5644*/
              v57 = _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr; /*0x1410a564e*/
              if ( v60 + 1 < 0x1000 ) /*0x1410a565c*/
                goto LABEL_153; /*0x1410a565c*/
              v57 = *((char **)_Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a5666*/
              if ( (unsigned __int64)(_Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr - v57 - 8) <= 0x1F ) /*0x1410a5675*/
                goto LABEL_153; /*0x1410a5675*/
              goto LABEL_177; /*0x1410a5675*/
            }
            v12 = v11 + 40; /*0x1410a55d1*/
            if ( v11 + 40 < v11 + 1 ) /*0x1410a55d8*/
              goto LABEL_203; /*0x1410a55d8*/
          }
          v63 = operator new(size: v12); /*0x1410a55e1*/
          if ( v63 == nullptr ) /*0x1410a55e9*/
            goto LABEL_177; /*0x1410a55e9*/
          v56 = (char *)(((unsigned __int64)v63 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x1410a55f3*/
          *((_QWORD *)v56 - 1) = v63; /*0x1410a55f7*/
          goto LABEL_174; /*0x1410a55fb*/
        }
        v31 = _Keyval_arg[0].text._Mypair._Myval2._Myres; /*0x1410a4fcc*/
        if ( _Keyval_arg[0].text._Mypair._Myval2._Myres >= 0x1D ) /*0x1410a4fd4*/
          goto LABEL_63; /*0x1410a4fd4*/
        if ( _Keyval_arg[0].text._Mypair._Myval2._Myres > 0x7FFFFFFFFFFFFFFFLL /*0x1410a5018*/
                                                        - (_Keyval_arg[0].text._Mypair._Myval2._Myres >> 1) )
        {
          v33 = 0x7FFFFFFFFFFFFFFFLL; /*0x1410a501a*/
          v34 = 0x8000000000000027uLL; /*0x1410a501d*/
          goto LABEL_105; /*0x1410a5020*/
        }
        v35 = _Keyval_arg[0].text._Mypair._Myval2._Myres + (_Keyval_arg[0].text._Mypair._Myval2._Myres >> 1); /*0x1410a5025*/
LABEL_101:
        v33 = 31; /*0x1410a5202*/
        if ( v35 > 0x1F ) /*0x1410a520a*/
          v33 = v35; /*0x1410a520a*/
        if ( v33 + 1 < 0x1000 ) /*0x1410a5219*/
        {
          if ( v33 == -1 ) /*0x1410a524a*/
            v41 = nullptr; /*0x1410a5256*/
          else
            v41 = operator new(size: v33 + 1); /*0x1410a5251*/
LABEL_110:
          _Keyval_arg[0].text._Mypair._Myval2._Mysize = 29; /*0x1410a5259*/
          _Keyval_arg[0].text._Mypair._Myval2._Myres = v33; /*0x1410a5261*/
          qmemcpy(v41, "QuotaFractionProcessTimeCoun", 28); /*0x1410a526c*/
          v42 = aQuotafractionp[28]; /*0x1410a5288*/
          goto LABEL_111; /*0x1410a5288*/
        }
        v34 = v33 + 40; /*0x1410a521b*/
        if ( v33 + 40 < v33 + 1 ) /*0x1410a5222*/
          goto LABEL_203; /*0x1410a5222*/
LABEL_105:
        v43 = operator new(size: v34); /*0x1410a5228*/
        if ( v43 == nullptr ) /*0x1410a5233*/
          goto LABEL_177; /*0x1410a5233*/
        v41 = (_BYTE *)(((unsigned __int64)v43 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x1410a523d*/
        *((_QWORD *)v41 - 1) = v43; /*0x1410a5241*/
        goto LABEL_110; /*0x1410a5245*/
      }
      *p_clientInstanceQuota = DFInt::ClientInstanceQuotaInitial; /*0x1410a5034*/
      if ( !DFFlag::StreamingReportPerformanceStatsAddInstanceQuota.value ) /*0x1410a503f*/
        goto LABEL_117; /*0x1410a503f*/
      v31 = _Keyval_arg[0].text._Mypair._Myval2._Myres; /*0x1410a5045*/
      if ( _Keyval_arg[0].text._Mypair._Myval2._Myres >= 0x1D ) /*0x1410a504d*/
        goto LABEL_71; /*0x1410a504d*/
      if ( _Keyval_arg[0].text._Mypair._Myval2._Myres > 0x7FFFFFFFFFFFFFFFLL /*0x1410a5091*/
                                                      - (_Keyval_arg[0].text._Mypair._Myval2._Myres >> 1) )
      {
        v37 = 0x7FFFFFFFFFFFFFFFLL; /*0x1410a5093*/
        v38 = 0x8000000000000027uLL; /*0x1410a5096*/
        goto LABEL_81; /*0x1410a5099*/
      }
      v39 = (_Keyval_arg[0].text._Mypair._Myval2._Myres >> 1) + _Keyval_arg[0].text._Mypair._Myval2._Myres; /*0x1410a509b*/
    }
    else
    {
      if ( (v23 > 0.0 || v18 > 0.0) && v14 != 0.0 && averageValue != 0.0 ) /*0x1410a514b*/
      {
        *p_clientInstanceQuota = (int)(float)((float)((float)((float)((float)(0.25 - v9) - v26) * v23) / averageValue) /*0x1410a51c6*/
                                            + (float)((float)((float)((float)(0.25 - v9) - v26) * v18) / v14));
        if ( !DFFlag::StreamingReportPerformanceStatsAddInstanceQuota.value ) /*0x1410a51d1*/
          goto LABEL_117; /*0x1410a51d1*/
        v31 = _Keyval_arg[0].text._Mypair._Myval2._Myres; /*0x1410a51d7*/
        if ( _Keyval_arg[0].text._Mypair._Myval2._Myres >= 0x1D ) /*0x1410a51df*/
        {
LABEL_63:
          v32 = _Keyval_arg; /*0x1410a4fd6*/
          if ( v31 >= 0x10 ) /*0x1410a4fde*/
            v32 = (RBX::Graphics::ProfilerAdorn::Item *)_Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr; /*0x1410a4fde*/
          _Keyval_arg[0].text._Mypair._Myval2._Mysize = 29; /*0x1410a4fe3*/
          memmove_0(a1: v32, Src: "QuotaFractionProcessTimeCount", Size: 0x1Du); /*0x1410a4ffb*/
          BYTE5(v32->text._Mypair._Myval2._Myres) = 0; /*0x1410a5000*/
LABEL_116:
          clientInstanceQuota = LODWORD(v85.sec); /*0x1410a52d4*/
          goto LABEL_117; /*0x1410a52d4*/
        }
        if ( _Keyval_arg[0].text._Mypair._Myval2._Myres > 0x7FFFFFFFFFFFFFFFLL /*0x1410a51f4*/
                                                        - (_Keyval_arg[0].text._Mypair._Myval2._Myres >> 1) )
        {
          v33 = 0x7FFFFFFFFFFFFFFFLL; /*0x1410a51f6*/
          v34 = 0x8000000000000027uLL; /*0x1410a51f9*/
          goto LABEL_105; /*0x1410a51fc*/
        }
        v35 = (_Keyval_arg[0].text._Mypair._Myval2._Myres >> 1) + _Keyval_arg[0].text._Mypair._Myval2._Myres; /*0x1410a51fe*/
        goto LABEL_101; /*0x1410a51fe*/
      }
      *p_clientInstanceQuota = DFInt::ClientInstanceQuotaInitial; /*0x1410a5153*/
      if ( !DFFlag::StreamingReportPerformanceStatsAddInstanceQuota.value ) /*0x1410a515e*/
        goto LABEL_117; /*0x1410a515e*/
      v31 = _Keyval_arg[0].text._Mypair._Myval2._Myres; /*0x1410a5164*/
      if ( _Keyval_arg[0].text._Mypair._Myval2._Myres >= 0x1D ) /*0x1410a516c*/
      {
LABEL_71:
        v36 = _Keyval_arg; /*0x1410a504f*/
        if ( v31 >= 0x10 ) /*0x1410a5057*/
          v36 = (RBX::Graphics::ProfilerAdorn::Item *)_Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr; /*0x1410a5057*/
        _Keyval_arg[0].text._Mypair._Myval2._Mysize = 29; /*0x1410a505c*/
        memmove_0(a1: v36, Src: "QuotaNoProcessTimeValuesCount", Size: 0x1Du); /*0x1410a5074*/
        BYTE5(v36->text._Mypair._Myval2._Myres) = 0; /*0x1410a5079*/
        goto LABEL_116; /*0x1410a507d*/
      }
      if ( _Keyval_arg[0].text._Mypair._Myval2._Myres > 0x7FFFFFFFFFFFFFFFLL /*0x1410a5181*/
                                                      - (_Keyval_arg[0].text._Mypair._Myval2._Myres >> 1) )
      {
        v37 = 0x7FFFFFFFFFFFFFFFLL; /*0x1410a5183*/
        v38 = 0x8000000000000027uLL; /*0x1410a5186*/
        goto LABEL_81; /*0x1410a5189*/
      }
      v39 = _Keyval_arg[0].text._Mypair._Myval2._Myres + (_Keyval_arg[0].text._Mypair._Myval2._Myres >> 1); /*0x1410a518e*/
    }
    v37 = 31; /*0x1410a509f*/
    if ( v39 > 0x1F ) /*0x1410a50a7*/
      v37 = v39; /*0x1410a50a7*/
    if ( v37 + 1 < 0x1000 ) /*0x1410a50b6*/
    {
      if ( v37 == -1 ) /*0x1410a50e7*/
        v41 = nullptr; /*0x1410a50f3*/
      else
        v41 = operator new(size: v37 + 1); /*0x1410a50ee*/
LABEL_86:
      _Keyval_arg[0].text._Mypair._Myval2._Mysize = 29; /*0x1410a50f6*/
      _Keyval_arg[0].text._Mypair._Myval2._Myres = v37; /*0x1410a50fe*/
      qmemcpy(v41, "QuotaNoProcessTimeValuesCoun", 28); /*0x1410a5109*/
      v42 = aQuotanoprocess[28]; /*0x1410a5125*/
LABEL_111:
      v41[28] = v42; /*0x1410a528f*/
      v41[29] = 0; /*0x1410a5293*/
      if ( v31 >= 0x10 ) /*0x1410a529c*/
      {
        v44 = _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr; /*0x1410a529e*/
        if ( v31 + 1 >= 0x1000 ) /*0x1410a52b0*/
        {
          v44 = *((char **)_Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a52b2*/
          if ( (unsigned __int64)(_Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr - v44 - 8) > 0x1F ) /*0x1410a52c5*/
            goto LABEL_177; /*0x1410a52c5*/
        }
        operator delete(ptr: v44); /*0x1410a52cb*/
      }
      _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr = v41; /*0x1410a52d0*/
      goto LABEL_116; /*0x1410a52d0*/
    }
    v38 = v37 + 40; /*0x1410a50b8*/
    if ( v37 + 40 < v37 + 1 ) /*0x1410a50bf*/
      goto LABEL_203; /*0x1410a50bf*/
LABEL_81:
    v40 = operator new(size: v38); /*0x1410a50c5*/
    if ( v40 == nullptr ) /*0x1410a50d0*/
      goto LABEL_177; /*0x1410a50d0*/
    v41 = (_BYTE *)(((unsigned __int64)v40 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x1410a50da*/
    *((_QWORD *)v41 - 1) = v40; /*0x1410a50de*/
    goto LABEL_86; /*0x1410a50e2*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: _Keyval_arg); /*0xf1c000000000001c*/
  }
LABEL_204:
  if ( _Keyval_arg[0].text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a5868*/
  {
    v79 = _Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr; /*0x1410a586d*/
    if ( _Keyval_arg[0].text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a587b*/
    {
      v79 = *((char **)_Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a5881*/
      if ( (unsigned __int64)(_Keyval_arg[0].text._Mypair._Myval2._Bx._Ptr - v79 - 8) > 0x1F ) /*0x1410a5890*/
        _invalid_parameter_noinfo_noreturn(); /*0x1410a5892*/
    }
    operator delete(ptr: v79); /*0x1410a5899*/
  }
}

// Address: 0x1410a58e0 | Name: ?updateMemoryStats@ClientReplicator@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::ClientReplicator::updateMemoryStats(RBX::Network::ClientReplicator *this)
{
  RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings> *v2; // rsi
  RBX::GlobalAdvancedSettings *Ptr; // rsi
  _Mtx_internal_imp_t *p_mx; // rbx
  int v5; // eax
  std::_Ref_count_base *Rep; // rbx
  RBX::MemoryStats::MemoryLevel v7; // eax
  __int64 v8; // rcx
  __int64 v9; // [rsp+0h] [rbp-78h] BYREF
  std::shared_ptr<RBX::NetworkSettings> result; // [rsp+30h] [rbp-48h] BYREF
  RBX::Profiler::Scope profscope3052; // [rsp+40h] [rbp-38h] BYREF
  std::shared_ptr<std::vector<RBX::Guid> > v12; // [rsp+50h] [rbp-28h] BYREF
  MicroProfileScopeLock v13; // [rsp+80h] [rbp+8h] BYREF

  if ( _TSS0_535 > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x1410a5916*/
    goto LABEL_17; /*0x1410a5916*/
  while ( 1 ) /*0x1410a5923*/
  {
    profscope3052.region.token = proftoken3052; /*0x1410a5923*/
    __eh34_enter_wind_state(-1, 1); /*0xf1c0000000000070*/
    profscope3052.region.timestamp = RBX::Profiler::enterRegion(token: proftoken3052); /*0x1410a592d*/
    RBX::NetworkSettings::updateClientMemoryEmulation(this: this->networkSettings); /*0x1410a5939*/
    v2 = RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing; /*0x1410a593e*/
    if ( RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing != nullptr ) /*0x1410a5948*/
      break; /*0x1410a5948*/
    Ptr = RBX::GlobalAdvancedSettings::singleton()->_Ptr; /*0x1410a5953*/
    p_mx = (_Mtx_internal_imp_t *)&Ptr->mx; /*0x1410a5956*/
    v13.m = (std::recursive_mutex *)&Ptr->mx; /*0x1410a595d*/
    v5 = Mtx_lock_0(a1: (_Mtx_t)&Ptr->mx); /*0x1410a5968*/
    if ( v5 == 0 ) /*0x1410a596f*/
    {
      __wind /*0xf1c0000000000064*/
      {
        if ( RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing == nullptr ) /*0x1410a597d*/
        {
          RBX::Creatable<RBX::Instance>::create<RBX::NetworkSettings,>(&result); /*0x1410a5984*/
          __wind /*0xf1c0000000000058*/
          {
            v12 = 0; /*0x1410a598d*/
            RBX::Instance::setParentInternal( /*0x1410a59ab*/
              this: result._Ptr,
              newParent: Ptr,
              ignoreLock: false,
              destroying: false,
              destroyedGuids: &v12);
          }
          __unwind
          {
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&result); /*0xf1c0000000000050*/
          }
          if ( result._Rep != nullptr ) /*0x1410a59b9*/
          {
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&result._Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x1410a59c5*/
            {
              Rep = result._Rep; /*0x1410a59c7*/
              result._Rep->_Destroy(this: result._Rep); /*0x1410a59d2*/
              if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x1410a59dc*/
                result._Rep->_Delete_this(this: result._Rep); /*0x1410a59e6*/
            }
            p_mx = (_Mtx_internal_imp_t *)v13.m; /*0x1410a59e9*/
          }
        }
        v2 = RBX::GlobalAdvancedSettingsItem<RBX::NetworkSettings>::sing; /*0x1410a59f1*/
        Mtx_unlock_0(a1: p_mx); /*0x1410a59fb*/
      }
      __unwind
      {
        std::scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>::~scoped_lock<RBX::InstrumentedMutex<std::recursive_mutex>>(this: &v13); /*0xf1c0000000000044*/
      }
      break; /*0xf1c0000000000040*/
    }
    std::_Throw_C_error(a1: v5); /*0x1410a5a38*/
    if ( __eh34_unwind(1) ) /*0xf1c0000000000078*/
    {
unwind_state_1:
      RBX::Profiler::Scope::~Scope(this: &profscope3052); /*0xf1c000000000007c*/
      __eh34_propagate_exception_into_caller(1, -1); /*0xf1c0000000000080*/
    }
    __eh34_exit_wind_state(1, -1); /*0xf1c0000000000084*/
LABEL_17:
    __wind /*0xf1c000000000001c*/
    {
      Init_thread_header(pOnce: &_TSS0_535); /*0x1410a5a45*/
      if ( _TSS0_535 == -1 ) /*0x1410a5a50*/
      {
        proftoken3052 = RBX::Profiler::getToken( /*0x1410a5a6c*/
                          group: "Network",
                          name: (const char *)&RBX::Network::ClientReplicator::ClientStreamCapacityUpdateItem::`vftable'[7],
                          color: -1);
        Init_thread_footer(pOnce: &_TSS0_535); /*0x1410a5a7a*/
      }
    }
    __unwind
    {
      Init_thread_abort(pOnce: &_TSS0_535); /*0x1431ec367*/
    }
  }
  v7 = RBX::MemoryStats::slowCheckMemoryLevel(extraMemoryUsed: (__int64)SLODWORD(v2[1].ownedByActor._Ptr) << 20); /*0x1410a5a00*/
  if ( __eh34_unwind(1) ) /*0xf1c000000000008c*/
    goto unwind_state_1; /*0xf1c000000000008c*/
  __eh34_exit_wind_state(1, -1); /*0xf1c0000000000090*/
  __wind /*0xf1c0000000000094*/
  {
    this->memoryLevel = v7; /*0x1410a5a10*/
    RBX::Profiler::leaveRegion(token: profscope3052.region.token, enterTimestamp: profscope3052.region.timestamp); /*0x1410a5a20*/
  }
  __unwind
  {
    __std_terminate(a1: v8, a2: &v9); /*0x142f39fa8*/
  }
}

// Address: 0x1410a5a90 | Name: ?wantReplicate@ClientReplicator@Network@RBX@@MEBA_NPEBVInstance@3@@Z
bool __fastcall RBX::Network::ClientReplicator::wantReplicate(
        RBX::Network::ClientReplicator *this,
        const RBX::Instance *source)
{
  RBX::Player *v4; // rax
  std::vector<std::shared_ptr<RBX::Instance>> *Ptr; // rbx
  const RBX::Instance **p_Ptr; // rdi
  const RBX::Instance **v8; // rbx
  const RBX::Instance *v9; // rbp
  const RBX::Reflection::ClassDescriptor *descriptor; // rsi
  RBX::Reflection::ClassDescriptor *v11; // rax
  RBX::Instance *parent; // rcx

  if ( this->strictFilter._Mypair._Myval2 == nullptr ) /*0x1410a5aa9*/
    return RBX::Network::Replicator::wantReplicate(this, source); /*0x1410a5b89*/
  if ( !RBX::Network::Replicator::wantReplicate(this, source) ) /*0x1410a5aaf*/
    return false; /*0x1410a5b70*/
  v4 = this->findTargetPlayer(this); /*0x1410a5ac2*/
  if ( v4 == nullptr ) /*0x1410a5acb*/
    return true; /*0x1410a5acd*/
  Ptr = v4->children.object._Ptr; /*0x1410a5adb*/
  if ( Ptr == nullptr ) /*0x1410a5af1*/
    return true; /*0x1410a5af1*/
  p_Ptr = (const RBX::Instance **)&Ptr->_Mypair._Myval2._Mylast->_Ptr; /*0x1410a5af3*/
  v8 = (const RBX::Instance **)&Ptr->_Mypair._Myval2._Myfirst->_Ptr; /*0x1410a5af7*/
  if ( v8 == p_Ptr ) /*0x1410a5afd*/
    return true; /*0x1410a5afd*/
  while ( 1 ) /*0x1410a5b00*/
  {
    v9 = *v8; /*0x1410a5b00*/
    if ( *v8 != nullptr ) /*0x1410a5b06*/
    {
      descriptor = v9->descriptor; /*0x1410a5b08*/
      v11 = RBX::Reflection::Class_getDescriptorPtr<RBX::PlayerGui>(); /*0x1410a5b0c*/
      if ( descriptor->index - (unsigned int)v11->index <= v11->descendantCount ) /*0x1410a5b2a*/
        break; /*0x1410a5b2a*/
    }
    v8 += 2; /*0x1410a5b2c*/
    if ( v8 == p_Ptr ) /*0x1410a5b33*/
      return true; /*0x1410a5b33*/
  }
  parent = source->parent; /*0x1410a5b52*/
  return v9 != parent && (parent == nullptr || !RBX::Instance::isDescendantOf(this: parent, ancestor: v9)); /*0x1410a5b6c*/
}

// Address: 0x1410a5e40 | Name: ?writeAttributeVersionInfo@ClientReplicator@Network@RBX@@UEAAXAEAVNetworkStream@23@PEBVInstance@3@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RBX::Network::ClientReplicator::writeAttributeVersionInfo(
        RBX::Network::ClientReplicator *this,
        RBX::Network::NetworkStream *bitStream,
        const RBX::Instance *instance,
        const rtc::webrtc_checks_impl::ToStringVal *name)
{
  int v8; // esi
  rtc::webrtc_checks_impl::ToStringVal *v9; // rbx
  RBX::Guid guid; // rax
  unsigned __int64 Myres; // rdx
  char *Ptr; // rcx
  boost::unordered::detail::ptr_bucket *v13; // rax
  boost::unordered::detail::ptr_node<std::pair<RBX::Network::Sync::AttributeKey const ,RBX::Network::Sync::MasterItem> > *node; // rax
  char v15; // bl
  char *v16; // rcx
  rtc::webrtc_checks_impl::ToStringVal v17; // [rsp+30h] [rbp-68h] BYREF
  RBX::Graphics::ProfilerAdorn::Item k; // [rsp+50h] [rbp-48h] BYREF
  boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<RBX::Network::Sync::AttributeKey const ,RBX::Network::Sync::MasterItem> > > result; // [rsp+A0h] [rbp+8h] BYREF

  if ( (this->peerCapability & 2) != 0 && this->isCloudEdit(this) ) /*0x1410a5e75*/
  {
    v8 = 0; /*0x1410a5e83*/
    v9 = std::string::string(this: &v17, __that: name); /*0x1410a5e92*/
    k.text._Mypair._Myval2._Bx._Ptr = nullptr; /*0x1410a5e95*/
    *(_OWORD *)&k.text._Mypair._Myval2._Mysize = 0; /*0x1410a5e9d*/
    k.text = v9->val; /*0x1410a5ea6*/
    v9->val._Mypair._Myval2._Mysize = 0; /*0x1410a5eb4*/
    v9->val._Mypair._Myval2._Myres = 15; /*0x1410a5eb8*/
    v9->val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410a5ec0*/
    if ( instance != nullptr ) /*0x1410a5ec6*/
      guid = instance->guid; /*0x1410a5ec8*/
    else
      guid = (RBX::Guid)0xFFFFFFFFLL; /*0x1410a5ece*/
    *(RBX::Guid *)&k.x = guid; /*0x1410a5ed3*/
    Myres = v9->val._Mypair._Myval2._Myres; /*0x1410a5ed8*/
    if ( Myres >= 0x10 ) /*0x1410a5ee0*/
    {
      Ptr = v9->val._Mypair._Myval2._Bx._Ptr; /*0x1410a5ee2*/
      if ( Myres + 1 >= 0x1000 ) /*0x1410a5eef*/
      {
        if ( (unsigned __int64)&Ptr[-*((_QWORD *)Ptr - 1) - 8] > 0x1F ) /*0x1410a5f04*/
          goto LABEL_20; /*0x1410a5f04*/
        Ptr = *((char **)Ptr - 1); /*0x1410a5f0a*/
      }
      operator delete(ptr: Ptr); /*0x1410a5f0d*/
    }
    v9->val._Mypair._Myval2._Mysize = 0; /*0x1410a5f12*/
    v9->val._Mypair._Myval2._Myres = 15; /*0x1410a5f16*/
    v9->val._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1410a5f1e*/
    __wind /*0xf1c0000000000010*/
    {
      v13 = (boost::unordered::detail::ptr_bucket *)boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::Sync::AttributeKey const,RBX::Network::Sync::MasterItem>>,RBX::Network::Sync::AttributeKey,RBX::Network::Sync::MasterItem,boost::hash<RBX::Network::Sync::AttributeKey>,std::equal_to<RBX::Network::Sync::AttributeKey>>>::hash( /*0x1410a5f3e*/
                                                      this: (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::Sync::AttributeKey const ,RBX::Network::Sync::MasterItem> >,RBX::Network::Sync::AttributeKey,RBX::Network::Sync::MasterItem,boost::hash<RBX::Network::Sync::AttributeKey>,std::equal_to<RBX::Network::Sync::AttributeKey> > > *)&this->attrSync.itemMap,
                                                      (const RBX::Network::Sync::AttributeKey *)&k);
      boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::Sync::AttributeKey const,RBX::Network::Sync::MasterItem>>,RBX::Network::Sync::AttributeKey,RBX::Network::Sync::MasterItem,boost::hash<RBX::Network::Sync::AttributeKey>,std::equal_to<RBX::Network::Sync::AttributeKey>>>::find_node_impl<RBX::Network::Sync::AttributeKey,std::equal_to<RBX::Network::Sync::AttributeKey>>( /*0x1410a5f6a*/
        this: (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Network::Sync::AttributeKey const ,RBX::Network::Sync::MasterItem> >,RBX::Network::Sync::AttributeKey,RBX::Network::Sync::MasterItem,boost::hash<RBX::Network::Sync::AttributeKey>,std::equal_to<RBX::Network::Sync::AttributeKey> > > *)&this->attrSync.itemMap,
        &result,
        key_hash: v13,
        (const RBX::Network::Sync::AttributeKey *)&k);
      node = result.node_; /*0x1410a5f6f*/
      if ( result.node_ != nullptr ) /*0x1410a5f7a*/
      {
        if ( result.node_->value_base_.data_.data_.buf[56] != 0 ) /*0x1410a5f84*/
        {
          v15 = 0; /*0x1410a5f86*/
        }
        else
        {
          result.node_->value_base_.data_.data_.buf[56] = 1; /*0x1410a5f8a*/
          v8 = *((_DWORD *)&node->value_base_.data_.data_.align_ + 10); /*0x1410a5f8e*/
          v15 = 1; /*0x1410a5f91*/
        }
      }
      else
      {
        v15 = 0; /*0x1410a5f7c*/
      }
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: &k); /*0xf1c0000000000008*/
    }
    if ( k.text._Mypair._Myval2._Myres >= 0x10 ) /*0x1410a5f9c*/
    {
      v16 = k.text._Mypair._Myval2._Bx._Ptr; /*0x1410a5fa1*/
      if ( k.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x1410a5fb0*/
      {
        v16 = *((char **)k.text._Mypair._Myval2._Bx._Ptr - 1); /*0x1410a5fb6*/
        if ( (unsigned __int64)(k.text._Mypair._Myval2._Bx._Ptr - v16 - 8) > 0x1F ) /*0x1410a5fc5*/
LABEL_20:
          _invalid_parameter_noinfo_noreturn(); /*0x1410a5fc7*/
      }
      operator delete(ptr: v16); /*0x1410a5fce*/
    }
    LOBYTE(result.node_) = v15; /*0x1410a5fd3*/
    RBX::Network::NetworkStream::writeBytes(this: bitStream, inByteArray: &result, numberOfBytesToWrite: 1u); /*0x1410a5feb*/
    if ( v15 != 0 ) /*0x1410a5ff2*/
      RBX::Network::serializeSignedVarint(value: v8, stream: bitStream); /*0x1410a5ff9*/
  }
}

// Address: 0x1411465b0 | Name: ??$fastDynamicCast@VClientReplicator@Network@RBX@@@DescribedBase@Reflection@RBX@@QEAAPEAVClientReplicator@Network@2@XZ
RBX::Network::ClientReplicator *__fastcall RBX::Reflection::DescribedBase::fastDynamicCast<RBX::Network::ClientReplicator>(
        RBX::Reflection::DescribedBase *this)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::ClassRegistrar<RBX::Network::ClientReplicator,0> *v3; // rax
  unsigned int v4; // r8d
  unsigned int descendantCount; // edx
  RBX::Network::ClientReplicator *result; // rax

  descriptor = this->descriptor; /*0x1411465ba*/
  v3 = RBX::Reflection::Class_getDescriptorPtr<RBX::Network::ClientReplicator>(); /*0x1411465c1*/
  v4 = descriptor->index - v3->desc.index; /*0x1411465da*/
  descendantCount = v3->desc.descendantCount; /*0x1411465dd*/
  result = nullptr; /*0x1411465e4*/
  if ( v4 <= descendantCount ) /*0x1411465e9*/
    return (RBX::Network::ClientReplicator *)this; /*0x1411465e9*/
  return result; /*0x1411465ed*/
}

// Address: 0x14116f9c0 | Name: ??_GGCJob@ClientReplicator@Network@RBX@@UEAAPEAXI@Z
RBX::Network::ClientReplicator::GCJob *__fastcall RBX::Network::ClientReplicator::GCJob::`scalar deleting destructor'(
        RBX::Network::ClientReplicator::GCJob *this,
        char a2)
{
  RBX::Network::ClientReplicator::GCJob::~GCJob(this); /*0x14116f9cf*/
  if ( (a2 & 1) != 0 ) /*0x14116f9d7*/
    operator delete(ptr: this); /*0x14116f9e1*/
  return this; /*0x14116f9e6*/
}

// END ClientReplicator part 1/1, 101 functions
