// ReplicatorJob -- 2022 Studio + full PDB
// tier 3, 2 functions


// Address: 0x141059e20 | Name: ??0ReplicatorJob@Network@RBX@@IEAA@PEBDAEAVReplicator@12@W4DMTaskType@2@W4JobPriority@2@@Z
RBX::Network::ReplicatorJob *__fastcall RBX::Network::ReplicatorJob::ReplicatorJob(
        RBX::Network::ReplicatorJob *this,
        const char *name,
        RBX::Network::Replicator *replicator,
        RBX::DMTaskType taskType,
        RBX::JobPriority priority)
{
  RBX::DataModel *v9; // rax
  RBX::DataModel *v10; // r10
  std::_Ref_count_base *Rep; // rdx
  signed __int32 Uses; // eax
  signed __int32 v13; // ett
  RBX::Reflection::DescribedBase *Ptr; // rcx
  std::_Ref_count_base *v15; // rdx
  RBX::DataModel *p_Rep; // rax
  char v17; // di
  std::_Ref_count_base *v18; // rdx
  signed __int32 v19; // eax
  signed __int32 v20; // ett
  RBX::Network::Replicator *v21; // rdx
  char *v22; // rcx
  char v23; // r8
  char v24; // di
  volatile signed __int32 *v25; // rbx
  std::_Ref_count_base *v26; // rbx
  RBX::Network::ReplicatorJob *result; // rax
  std::shared_ptr<RBX::DataModel> v28; // [rsp+38h] [rbp-80h] BYREF
  char v29; // [rsp+48h] [rbp-70h] BYREF
  volatile signed __int32 *v30; // [rsp+50h] [rbp-68h]
  char v31; // [rsp+58h] [rbp-60h] BYREF
  std::_Ref_count_base *v32; // [rsp+60h] [rbp-58h]
  __int64 v33; // [rsp+70h] [rbp-48h]
  __int64 v34; // [rsp+80h] [rbp-38h]

  v9 = RBX::DataModel::get(context: replicator); /*0x141059e5b*/
  v10 = v9; /*0x141059e60*/
  if ( v9 != nullptr ) /*0x141059e6a*/
  {
    Rep = v9->_Wptr._Rep; /*0x141059e6c*/
    if ( Rep == nullptr || (Uses = Rep->_Uses) == 0 ) /*0x141059e7e*/
LABEL_31:
      std::_Throw_bad_weak_ptr(); /*0x14105a031*/
    while ( 1 ) /*0x141059e87*/
    {
      v13 = Uses; /*0x141059e87*/
      Uses = _InterlockedCompareExchange((volatile signed __int32 *)&Rep->_Uses, Uses + 1, Uses); /*0x141059e87*/
      if ( v13 == Uses ) /*0x141059e8c*/
        break; /*0x141059e8c*/
      if ( Uses == 0 ) /*0x141059e90*/
        goto LABEL_31; /*0x141059e90*/
    }
    Ptr = v10->_Wptr._Ptr; /*0x141059e98*/
    v15 = v10->_Wptr._Rep; /*0x141059e9c*/
    p_Rep = (RBX::DataModel *)&Ptr[-1]._Wptr._Rep; /*0x141059ea0*/
    if ( Ptr == nullptr ) /*0x141059ea7*/
      p_Rep = nullptr; /*0x141059ea7*/
    v28._Ptr = p_Rep; /*0x141059eab*/
    v28._Rep = v15; /*0x141059eb0*/
    v33 = 0; /*0x141059eb5*/
    v17 = 24; /*0x141059ebf*/
  }
  else
  {
    v28._Ptr = nullptr; /*0x141059ec4*/
    v28._Rep = nullptr; /*0x141059ec9*/
    v34 = 0; /*0x141059ece*/
    v17 = 8; /*0x141059ed6*/
  }
  RBX::DataModelJob::DataModelJob(this, name, taskType, isPerPlayer: true, dm: &v28, priority); /*0x141059efc*/
  __wind /*0xf1c0000000000010*/
  {
    this->__vftable = (RBX::Network::ReplicatorJob_vtbl *)RBX::Network::ReplicatorJob::`vftable'; /*0x141059f09*/
    if ( replicator != nullptr ) /*0x141059f1b*/
    {
      v18 = replicator->_Wptr._Rep; /*0x141059f1d*/
      if ( v18 == nullptr || (v19 = v18->_Uses) == 0 ) /*0x141059f2f*/
LABEL_32:
        std::_Throw_bad_weak_ptr(); /*0x14105a037*/
      while ( 1 ) /*0x141059f38*/
      {
        v20 = v19; /*0x141059f38*/
        v19 = _InterlockedCompareExchange((volatile signed __int32 *)&v18->_Uses, v19 + 1, v19); /*0x141059f38*/
        if ( v20 == v19 ) /*0x141059f3d*/
          break; /*0x141059f3d*/
        if ( v19 == 0 ) /*0x141059f41*/
          goto LABEL_32; /*0x141059f41*/
      }
      v21 = (RBX::Network::Replicator *)replicator->_Wptr._Ptr; /*0x141059f49*/
      v32 = replicator->_Wptr._Rep; /*0x141059f51*/
      v22 = &v31; /*0x141059f56*/
      v23 = 96; /*0x141059f5b*/
    }
    else
    {
      v30 = nullptr; /*0x141059f63*/
      v22 = &v29; /*0x141059f68*/
      v21 = nullptr; /*0x141059f6d*/
      v23 = 0x80; /*0x141059f70*/
    }
    this->replicator._Ptr = v21; /*0x141059f76*/
    this->replicator._Rep = *((std::_Ref_count_base **)v22 + 1); /*0x141059f7d*/
    *(_QWORD *)v22 = 0; /*0x141059f81*/
    *((_QWORD *)v22 + 1) = 0; /*0x141059f84*/
    v24 = v23 | v17; /*0x141059f88*/
    if ( v24 < 0 ) /*0x141059f8e*/
    {
      v24 &= ~0x80u; /*0x141059f90*/
      if ( v30 != nullptr && _InterlockedExchangeAdd(v30 + 2, 0xFFFFFFFF) == 1 ) /*0x141059fa8*/
      {
        v25 = v30; /*0x141059faa*/
        (**(void (__fastcall ***)(volatile signed __int32 *))v30)(a1: v30); /*0x141059fb5*/
        if ( _InterlockedExchangeAdd(v25 + 3, 0xFFFFFFFF) == 1 ) /*0x141059fc1*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v30 + 8LL))(a1: v30); /*0x141059fcb*/
      }
    }
    if ( (v24 & 0x40) != 0 /*0x141059fe8*/
      && v32 != nullptr
      && _InterlockedExchangeAdd((volatile signed __int32 *)&v32->_Uses, 0xFFFFFFFF) == 1 )
    {
      v26 = v32; /*0x141059fea*/
      v32->_Destroy(this: v32); /*0x141059ff5*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v26->_Weaks, 0xFFFFFFFF) == 1 ) /*0x141059fff*/
        v32->_Delete_this(this: v32); /*0x14105a009*/
    }
    result = this; /*0x14105a00d*/
  }
  __unwind
  {
    RBX::DataModelJob::~DataModelJob((RBX::BaseRenderJob *)this); /*0xf1c0000000000008*/
  }
  return result; /*0x14105a010*/
}

// Address: 0x14105cca0 | Name: ??1ReplicatorJob@Network@RBX@@UEAA@XZ
void __fastcall RBX::Network::ReplicatorJob::~ReplicatorJob(RBX::Network::ReplicatorJob *this)
{
  std::_Ref_count_base *Rep; // rbx

  Rep = this->replicator._Rep; /*0x14105ccaa*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14105cccd*/
  {
    Rep->_Destroy(this: Rep); /*0x14105ccd5*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14105ccdf*/
      Rep->_Delete_this(this: Rep); /*0x14105cce7*/
  }
  RBX::TaskScheduler::Job::~Job(this); /*0x14105ccfc*/
}

// END ReplicatorJob part 1/1, 2 functions
