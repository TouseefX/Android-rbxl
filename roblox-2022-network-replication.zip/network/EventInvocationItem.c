// EventInvocationItem -- 2022 Studio + full PDB
// tier 3, 6 functions


// Address: 0x14113bb50 | Name: ??0EventInvocationItem@Replicator@Network@RBX@@QEAA@PEAV123@V?$shared_ptr@$$CBVInstance@RBX@@@std@@AEBVEventDescriptor@Reflection@3@AEBUClassEvent@NetworkSchema@23@AEBV?$shared_ptr@$$CBV?$vector@VVariant@Reflection@RBX@@V?$allocator@VVariant@Reflection@RBX@@@std@@@std@@@5@@Z
RBX::Network::Replicator::EventInvocationItem *__fastcall RBX::Network::Replicator::EventInvocationItem::EventInvocationItem(
        RBX::Network::Replicator::EventInvocationItem *this,
        RBX::Network::Replicator *replicator,
        std::shared_ptr<RBX::File> *inst,
        const RBX::Reflection::EventDescriptor *desc,
        const RBX::Network::NetworkSchema::ClassEvent *classEvent,
        const std::shared_ptr<std::vector<RBX::Reflection::Variant> const > *sharedArguments)
{
  std::_Ref_count_base *Rep; // rax
  std::_Ref_count_base *v10; // rbx
  RBX::Network::Replicator::EventInvocationItem *result; // rax

  __wind /*0xf1c0000000000010*/
  {
    RBX::Network::Item::Item(this, replicator); /*0x14113bb6d*/
    this->__vftable = (RBX::Network::Replicator::EventInvocationItem_vtbl *)RBX::Network::Replicator::EventInvocationItem::`vftable'; /*0x14113bb79*/
    this->instance._Ptr = nullptr; /*0x14113bb7e*/
    this->instance._Rep = nullptr; /*0x14113bb82*/
    this->instance._Ptr = inst->_Ptr; /*0x14113bb89*/
    this->instance._Rep = inst->_Rep; /*0x14113bb91*/
    inst->_Ptr = nullptr; /*0x14113bb95*/
    inst->_Rep = nullptr; /*0x14113bb98*/
    this->desc = desc; /*0x14113bb9c*/
    this->classEvent = classEvent; /*0x14113bba5*/
    this->sharedArguments._Ptr = nullptr; /*0x14113bba9*/
    this->sharedArguments._Rep = nullptr; /*0x14113bbad*/
    Rep = sharedArguments->_Rep; /*0x14113bbb6*/
    if ( Rep != nullptr ) /*0x14113bbbd*/
      _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x14113bbbf*/
    this->sharedArguments = *sharedArguments; /*0x14113bbc6*/
    v10 = inst->_Rep; /*0x14113bbd2*/
    if ( v10 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Uses, 0xFFFFFFFF) == 1 ) /*0x14113bbea*/
    {
      v10->_Destroy(this: v10); /*0x14113bbf2*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v10->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113bbfc*/
        v10->_Delete_this(this: v10); /*0x14113bc04*/
    }
    result = this; /*0x14113bc07*/
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: inst); /*0xf1c0000000000008*/
  }
  return result; /*0x14113bc0a*/
}

// Address: 0x14113bda0 | Name: ?preserialize@EventInvocationItem@Replicator@Network@RBX@@SA_NAEAVNetworkStream@34@PEAV234@IAEBUClassEvent@NetworkSchema@34@PEBVInstance@4@AEBV?$vector@VVariant@Reflection@RBX@@V?$allocator@VVariant@Reflection@RBX@@@std@@@std@@AEAV?$vector@VSharedString@RBX@@V?$allocator@VSharedString@RBX@@@std@@@std@@@Z
char __fastcall RBX::Network::Replicator::EventInvocationItem::preserialize(
        RBX::Network::NetworkStream *bitStream,
        RBX::Network::Replicator *replicator,
        unsigned int replicationPeerIdType,
        const RBX::Network::NetworkSchema::ClassEvent *classEvent,
        RBX::Reflection::Variant *instance,
        const std::vector<RBX::Reflection::Variant> *sharedArguments,
        std::vector<RBX::SharedString> *sharedStringInfo)
{
  RBX::Network::Replicator *v8; // r14
  RBX::Guid v10; // rcx
  unsigned int v11; // r13d
  unsigned int v12; // esi
  unsigned __int64 v13; // rdx
  __int64 v14; // rax
  std::vector<RBX::SharedString> *sentSharedStrings; // r15
  const std::vector<RBX::Reflection::Variant> *v16; // r12
  unsigned int v17; // edi
  bool v18; // al
  int v19; // ebx
  _WORD *v20; // rax
  char *Ptr; // rcx
  RBX::Network::ReplicationVariantSizeLimitsMetaData metaData; // [rsp+40h] [rbp-C0h] BYREF
  std::string resource; // [rsp+60h] [rbp-A0h] BYREF
  RBX::Analytics::InfluxDb::Points eventMetaDataReport; // [rsp+80h] [rbp-80h] BYREF
  RBX::Network::Replicator::SerializerParameters params; // [rsp+F0h] [rbp-10h] BYREF
  unsigned __int8 inByteArray; // [rsp+170h] [rbp+70h] BYREF
  RBX::Network::Replicator *v28; // [rsp+178h] [rbp+78h]
  unsigned int peerIdType; // [rsp+180h] [rbp+80h] BYREF
  RBX::Guid id; // [rsp+188h] [rbp+88h] BYREF

  peerIdType = replicationPeerIdType; /*0x14113bda0*/
  v28 = replicator; /*0x14113bda5*/
  v8 = replicator; /*0x14113bdc5*/
  inByteArray = 7; /*0x14113bdcb*/
  RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 1u); /*0x14113bdd9*/
  if ( instance != nullptr ) /*0x14113bde8*/
    v10 = *(RBX::Guid *)&instance->value.data[32]; /*0x14113bdea*/
  else
    v10 = (RBX::Guid)0xFFFFFFFFLL; /*0x14113bdf0*/
  id = v10; /*0x14113bdf5*/
  RBX::Network::IdSerializer::serializeId(stream: bitStream, &peerIdType, &id); /*0x14113be0d*/
  LOWORD(instance) = classEvent->eventNetworkId; /*0x14113be15*/
  RBX::Network::NetworkStream::ReverseBytes( /*0x14113be2d*/
    inByteArray: (unsigned __int8 *)&instance,
    inOutByteArray: &inByteArray,
    length: 2u);
  RBX::Network::NetworkStream::writeBytes(this: bitStream, &inByteArray, numberOfBytesToWrite: 2u); /*0x14113be3f*/
  memset(&metaData, 0, sizeof(metaData)); /*0x14113be47*/
  if ( !v8->isCloudEdit(this: v8) && !v8->isServerReplicator(this: v8) ) /*0x14113be79*/
  {
    metaData.replicatedStringDataSizeLimit = DFInt::ClientSendEventStringDataLimitBytes; /*0x14113be81*/
    metaData.variantCountLimit = DFInt::ClientSendEventVariantCountLimit; /*0x14113be8b*/
    metaData.replicatedStringDataSizeReportingThreshold = DFInt::ClientSendEventStringDataLimitBytes; /*0x14113be8f*/
    metaData.variantCountReportingThreshold = DFInt::ClientSendEventVariantCountLimit; /*0x14113be93*/
  }
  v11 = bitStream->GetNumberOfBytesUsed(this: bitStream); /*0x14113bea0*/
  RBX::Network::Replicator::getSerializerParameters(this: v8, result: &params); /*0x14113beaa*/
  v12 = 0; /*0x14113beaf*/
  v13 = classEvent->argumentTypes._Mypair._Myval2._Mylast - classEvent->argumentTypes._Mypair._Myval2._Myfirst; /*0x14113bed5*/
  if ( v13 != 0 ) /*0x14113bed8*/
  {
    v14 = 0; /*0x14113bede*/
    sentSharedStrings = sharedStringInfo; /*0x14113bee1*/
    v16 = sharedArguments; /*0x14113bee8*/
    do /*0x14113bf75*/
    {
      instance = &v16->_Mypair._Myval2._Myfirst[v14]; /*0x14113bf0c*/
      RBX::Network::Replicator::schemaWriteValue<RBX::Network::VariantValueGetter>( /*0x14113bf4d*/
        outBitStream: bitStream,
        valueType: &classEvent->argumentTypes._Mypair._Myval2._Myfirst[v14],
        useDictionaries: true,
        vc: (const RBX::Network::VariantValueGetter *)&instance,
        depth: 0,
        sentSharedStrings,
        replicationMetaData: &metaData,
        parameters: &params);
      ++v12; /*0x14113bf52*/
      v13 = classEvent->argumentTypes._Mypair._Myval2._Mylast - classEvent->argumentTypes._Mypair._Myval2._Myfirst; /*0x14113bf6d*/
      v14 = v12; /*0x14113bf70*/
    }
    while ( v12 < v13 ); /*0x14113bf75*/
    v8 = v28; /*0x14113bf77*/
  }
  v17 = ((__int64 (__fastcall *)(RBX::Network::NetworkStream *, unsigned __int64))bitStream->GetNumberOfBytesUsed)( /*0x14113bf93*/
          a1: bitStream,
          a2: v13)
      - v11;
  if ( DFInt::EventMetaDataReportingDepthThreshold != 0 /*0x14113bfd6*/
    && metaData.maxVariantDepth >= DFInt::EventMetaDataReportingDepthThreshold
    || DFInt::EventMetaDataReportingStringSizeThreshold != 0
    && metaData.replicatedStringDataSize >= DFInt::EventMetaDataReportingStringSizeThreshold
    || DFInt::EventMetaDataReportingTotalStreamSizeThreshold != 0
    && v17 >= DFInt::EventMetaDataReportingTotalStreamSizeThreshold
    || DFInt::EventMetaDataReportingVariantCountThreshold != 0
    && metaData.variantCount >= DFInt::EventMetaDataReportingVariantCountThreshold )
  {
    RBX::Analytics::InfluxDb::Points::Points( /*0x14113bfea*/
      this: &eventMetaDataReport,
      throttleHundredthsPercentage: -1,
      categoryType: kStandardType,
      priorityHundredthsPercentage: 0);
    __wind /*0xf1c0000000000028*/
    {
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14113c017*/
        this: &eventMetaDataReport,
        name: (const char *)&RBX::Network::Replicator::EventInvocationItem::`vftable'[7],
        value: classEvent->argumentTypes._Mypair._Myval2._Mylast - classEvent->argumentTypes._Mypair._Myval2._Myfirst);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14113c02c*/
        this: &eventMetaDataReport,
        name: "MaxVariantDepth",
        value: metaData.maxVariantDepth);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14113c041*/
        this: &eventMetaDataReport,
        name: "TotalSizeOfStrings",
        value: metaData.replicatedStringDataSize);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14113c056*/
        this: &eventMetaDataReport,
        name: "TotalVariantCount",
        value: metaData.variantCount);
      RBX::Analytics::InfluxDb::Points::addPoint( /*0x14113c069*/
        this: &eventMetaDataReport,
        name: "TotalReplicatedStreamSize",
        value: v17);
      v18 = v8->isCloudEdit(this: v8); /*0x14113c074*/
      RBX::Analytics::InfluxDb::Points::addPoint(this: &eventMetaDataReport, name: "IsTeamCreate", value: v18); /*0x14113c089*/
      v19 = DFInt::ReplicatorEventReportEventMetaDataMyriad; /*0x14113c08e*/
      resource._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14113c094*/
      resource._Mypair._Myval2._Mysize = 0; /*0x14113c099*/
      resource._Mypair._Myval2._Myres = 15; /*0x14113c09e*/
      v20 = operator new(size: 0x30u); /*0x14113c0b1*/
      resource._Mypair._Myval2._Mysize = 35; /*0x14113c0b6*/
      resource._Mypair._Myval2._Myres = 47; /*0x14113c0bf*/
      qmemcpy(v20, "ReplicatorEventMetaDataPreSerializ", 34); /*0x14113c0cf*/
      v20[17] = (unsigned __int8)aReplicatoreven_1[34]; /*0x14113c0ef*/
      resource._Mypair._Myval2._Bx._Ptr = (char *)v20; /*0x14113c0f6*/
      __wind /*0xf1c000000000001c*/
      {
        RBX::Analytics::InfluxDb::Points::report( /*0x14113c10a*/
          this: &eventMetaDataReport,
          &resource,
          throttleHundredthsPercentage: v19,
          blocking: false);
      }
      __unwind
      {
        RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000014*/
      }
      if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x14113c119*/
      {
        Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x14113c11e*/
        if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14113c12d*/
        {
          Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x14113c133*/
          if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14113c142*/
            _invalid_parameter_noinfo_noreturn(); /*0x14113c144*/
        }
        operator delete(ptr: Ptr); /*0x14113c14b*/
      }
      RBX::Analytics::InfluxDb::Points::~Points(this: &eventMetaDataReport); /*0x14113c155*/
    }
    __unwind
    {
      RBX::Analytics::InfluxDb::Points::~Points(this: &eventMetaDataReport); /*0xf1c0000000000008*/
    }
  }
  return 1; /*0x14113c15c*/
}

// Address: 0x14113c390 | Name: ?read@EventInvocationItem@Replicator@Network@RBX@@SA?AV?$shared_ptr@VDeserializedItem@Network@RBX@@@std@@AEAV234@AEAVNetworkStream@34@@Z
std::shared_ptr<RBX::Network::DeserializedItem> *__fastcall RBX::Network::Replicator::EventInvocationItem::read(
        std::shared_ptr<RBX::Network::DeserializedItem> *result,
        RBX::Network::Replicator *replicator,
        RBX::Network::NetworkStream *inBitstream)
{
  RBX::Network::Replicator *v4; // r14
  char *v5; // rax
  char *v6; // rsi
  std::_Ref_count_base *v7; // rax
  std::_Ref_count_base *v8; // r15
  unsigned __int16 v9; // ax
  unsigned __int64 v10; // r8
  const RBX::Network::NetworkSchema *networkSchema; // rax
  RBX::Network::NetworkSchema::ClassEvent *Myfirst; // r9
  RBX::Network::NetworkSchema::ClassEvent *v13; // rcx
  RBX::Instance *Ptr; // rax
  RBX::Reflection::MemberDescriptor *v15; // rcx
  std::_Ref_count_base *Rep; // rcx
  volatile signed __int32 *v17; // rbx
  RBX::Network::NetworkSchema::ClassEvent *v18; // rbx
  unsigned __int64 v19; // r10
  RBX::Reflection::Variant *v20; // r11
  __int64 v21; // r9
  char *v22; // rcx
  unsigned __int64 v23; // r8
  RBX::Reflection::Variant *v24; // r14
  rbx::placement_any<RBX::Reflection::Variant::Storage> *p_value; // rbx
  std::vector<RBX::Reflection::Variant> *v26; // rcx
  __int64 v27; // r9
  RBX::Network::NetworkSchema::Type *v28; // r8
  __int64 v29; // rax
  RBX::Instance *v30; // rdx
  RBX::Reflection::Variant *v31; // rcx
  const RBX::Network::NetworkSchema::Type *v32; // r8
  const RBX::Reflection::Type **v33; // r14
  const RBX::Reflection::Type **v34; // r13
  const RBX::Reflection::Type *v35; // rbx
  char v36; // cl
  std::shared_ptr<RBX::Network::DeserializedItem> *v37; // r13
  boost::unordered::detail::ptr_bucket *buckets; // rsi
  unsigned __int64 bucket_count; // r14
  boost::unordered::detail::ptr_bucket *next; // rbx
  boost::unordered::detail::ptr_bucket *v41; // rcx
  unsigned __int64 v42; // rdx
  boost::unordered::detail::ptr_bucket *v43; // rcx
  boost::unordered::detail::ptr_bucket *v44; // rax
  std::_Ref_count_base *v45; // rbx
  boost::unordered::detail::ptr_bucket *v47; // rsi
  unsigned __int64 v48; // r14
  boost::unordered::detail::ptr_bucket *v49; // rbx
  boost::unordered::detail::ptr_bucket *v50; // rcx
  unsigned __int64 v51; // rdx
  boost::unordered::detail::ptr_bucket *v52; // rcx
  boost::unordered::detail::ptr_bucket *v53; // rax
  std::_Ref_count_base *v54; // rbx
  int SampleDescriptionCount; // eax
  int v56; // eax
  __int64 v57; // [rsp+0h] [rbp-100h] BYREF
  unsigned __int16 eventId; // [rsp+40h] [rbp-C0h] BYREF
  RBX::Reflection::Variant *v59; // [rsp+48h] [rbp-B8h]
  RBX::Network::NetworkSchema::ClassEvent *v60; // [rsp+50h] [rbp-B0h]
  RBX::Network::ReplicationVariantSizeLimitsMetaData metaData; // [rsp+58h] [rbp-A8h] BYREF
  std::shared_ptr<RBX::Instance> deseiralizedInstance; // [rsp+78h] [rbp-88h] BYREF
  boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > deferredSharedStrings; // [rsp+88h] [rbp-78h] BYREF
  RBX::Guid id; // [rsp+B8h] [rbp-48h] BYREF
  std::string v65; // [rsp+C0h] [rbp-40h] BYREF
  RBX::Network::VariantValueSetter vs; // [rsp+E0h] [rbp-20h] BYREF
  std::_Temporary_owner<RBX::Graphics::TextureVulkan::DownloadBuffer> v67; // [rsp+110h] [rbp+10h] BYREF
  std::shared_ptr<RBX::Network::DeserializedEventInvocationItem> deserializedData; // [rsp+120h] [rbp+20h] BYREF
  std::string m; // [rsp+130h] [rbp+30h] BYREF
  RBX::network_stream_exception v70; // [rsp+150h] [rbp+50h] BYREF
  RBX::network_stream_exception pExceptionObject; // [rsp+188h] [rbp+88h] BYREF
  std::_Ref_count_base *_Val; // [rsp+228h] [rbp+128h] BYREF

  v4 = replicator; /*0x14113c3bd*/
  v5 = (char *)operator new(size: 0x58u); /*0x14113c3c5*/
  v6 = v5; /*0x14113c3ca*/
  _Val = (std::_Ref_count_base *)v5; /*0x14113c3cd*/
  if ( v5 != nullptr ) /*0x14113c3d9*/
  {
    *((_DWORD *)v5 + 2) = 7; /*0x14113c3db*/
    *(_QWORD *)(v5 + 12) = 1; /*0x14113c3e2*/
    *(_QWORD *)v5 = RBX::Network::DeserializedEventInvocationItem::`vftable'; /*0x14113c3f1*/
    *((_QWORD *)v5 + 3) = 0; /*0x14113c3f4*/
    *((_QWORD *)v5 + 4) = 0; /*0x14113c3f8*/
    *((_QWORD *)v5 + 5) = 0; /*0x14113c3fc*/
    *((_QWORD *)v5 + 7) = 0; /*0x14113c400*/
    *((_QWORD *)v5 + 8) = 0; /*0x14113c404*/
    *((_QWORD *)v5 + 9) = 0; /*0x14113c408*/
    *((_QWORD *)v5 + 10) = 0; /*0x14113c40c*/
  }
  else
  {
    v6 = nullptr; /*0x14113c412*/
  }
  __wind /*0xf1c0000000000074*/
  {
    v67._Ptr = (RBX::Graphics::TextureVulkan::DownloadBuffer *)v6; /*0x14113c415*/
    v7 = (std::_Ref_count_base *)operator new(size: 0x18u); /*0x14113c41e*/
    v8 = v7; /*0x14113c423*/
    _Val = v7; /*0x14113c426*/
    if ( v7 != nullptr ) /*0x14113c430*/
    {
      *v7 = 0; /*0x14113c435*/
      v7->_Uses = 1; /*0x14113c438*/
      v7->_Weaks = 1; /*0x14113c43f*/
      v7->__vftable = (std::_Ref_count_base_vtbl *)std::_Ref_count<RBX::Network::DeserializedEventInvocationItem>::`vftable'; /*0x14113c44d*/
      v7[1].__vftable = (std::_Ref_count_base_vtbl *)v6; /*0x14113c450*/
    }
    else
    {
      v8 = nullptr; /*0x14113c456*/
    }
  }
  __unwind
  {
    RBX::BulletWedgeShapeWrapper::~BulletWedgeShapeWrapper(this: &v67); /*0xf1c0000000000084*/
  }
  __wind /*0xf1c000000000008c*/
  {
    __wind /*0xf1c0000000000094*/
    {
      deserializedData._Ptr = (RBX::Network::DeserializedEventInvocationItem *)v6; /*0x14113c459*/
      deserializedData._Rep = v8; /*0x14113c45d*/
      deseiralizedInstance = 0; /*0x14113c464*/
      id.scope.peerId.peerId = -1; /*0x14113c46a*/
      id.index = 0; /*0x14113c471*/
      RBX::Network::IdSerializer::deserializeInstanceRef( /*0x14113c483*/
        this: v4,
        stream: inBitstream,
        instance: &deseiralizedInstance,
        &id);
      eventId = 0; /*0x14113c488*/
      if ( !RBX::Network::NetworkStream::readBytes(this: inBitstream, inOutByteArray: &eventId, numberOfBytesToRead: 2u) ) /*0x14113c4a2*/
      {
        std::string::string(this: &v65, _Ptr: "readFast past end for uint16_t"); /*0x14113cc40*/
        __wind /*0xf1c0000000000014*/
        {
          RBX::network_stream_exception::network_stream_exception(this: &v70, m: &v65); /*0x14113cc4e*/
          throw &v70; /*0x14113cc5e*/
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v65); /*0xf1c0000000000024*/
        }
      }
      v9 = __ROL2__(eventId, 8); /*0x14113c4ad*/
      v10 = v9; /*0x14113c4b1*/
      eventId = v9; /*0x14113c4b5*/
      networkSchema = v4->networkSchema; /*0x14113c4bb*/
      Myfirst = networkSchema->classEventByNetworkId._Mypair._Myval2._Myfirst; /*0x14113c4c2*/
      if ( v10 >= networkSchema->classEventByNetworkId._Mypair._Myval2._Mylast - Myfirst /*0x14113c507*/
        || (v13 = &Myfirst[v10], v60 = v13, v13 == nullptr) )
      {
        SampleDescriptionCount = AP4_StsdAtom::GetSampleDescriptionCount(md: (const evp_md_st *)inBitstream); /*0x14113cc0c*/
        RBX::runtime_error( /*0x14113cc1f*/
          result: (std::runtime_error *)&v65,
          fmt: "Received invalid event id in event invocation item. Read offset=%X bytes",
          SampleDescriptionCount);
        throw (std::runtime_error *)&v65; /*0x14113cc2f*/
      }
      Ptr = deseiralizedInstance._Ptr; /*0x14113c50d*/
      if ( deseiralizedInstance._Ptr != nullptr ) /*0x14113c515*/
      {
        v15 = &v13->localDescriptor->RBX::Reflection::MemberDescriptor; /*0x14113c517*/
        if ( v15 != nullptr ) /*0x14113c51e*/
        {
          if ( !RBX::Reflection::MemberDescriptor::isMemberOf( /*0x14113c52b*/
                  this: v15,
                  classDescriptor: deseiralizedInstance._Ptr->descriptor) )
          {
            v56 = AP4_StsdAtom::GetSampleDescriptionCount(md: (const evp_md_st *)inBitstream); /*0x14113cc67*/
            RBX::runtime_error( /*0x14113cc7a*/
              result: (std::runtime_error *)&v65,
              fmt: "Received event does not belong to referenced instance. Read offset=%X bytes",
              v56);
            throw (std::runtime_error *)&v65; /*0x14113cc8a*/
          }
          Ptr = deseiralizedInstance._Ptr; /*0x14113c531*/
        }
      }
      Rep = deseiralizedInstance._Rep; /*0x14113c536*/
      if ( deseiralizedInstance._Rep != nullptr ) /*0x14113c53d*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&deseiralizedInstance._Rep->_Uses); /*0x14113c53f*/
        Rep = deseiralizedInstance._Rep; /*0x14113c543*/
        Ptr = deseiralizedInstance._Ptr; /*0x14113c547*/
      }
      *((_QWORD *)v6 + 4) = Ptr; /*0x14113c54c*/
      v17 = *((volatile signed __int32 **)v6 + 5); /*0x14113c550*/
      *((_QWORD *)v6 + 5) = Rep; /*0x14113c554*/
      if ( v17 != nullptr && _InterlockedExchangeAdd(v17 + 2, 0xFFFFFFFF) == 1 ) /*0x14113c56e*/
      {
        (**(void (__fastcall ***)(volatile signed __int32 *))v17)(a1: v17); /*0x14113c576*/
        if ( _InterlockedExchangeAdd(v17 + 3, 0xFFFFFFFF) == 1 ) /*0x14113c583*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 8LL))(a1: v17); /*0x14113c58b*/
      }
      v18 = v60; /*0x14113c58e*/
      *((_QWORD *)v6 + 6) = v60->localDescriptor; /*0x14113c597*/
      v19 = v18->argumentTypes._Mypair._Myval2._Mylast - v18->argumentTypes._Mypair._Myval2._Myfirst; /*0x14113c5be*/
      v20 = *((RBX::Reflection::Variant **)v6 + 8); /*0x14113c5c1*/
      v59 = v20; /*0x14113c5c5*/
      v21 = *((_QWORD *)v6 + 7); /*0x14113c5ca*/
      v22 = (char *)v20 - v21; /*0x14113c5d1*/
      v23 = ((__int64)v20 - v21) / 80; /*0x14113c5ef*/
      if ( v19 >= v23 ) /*0x14113c5f5*/
      {
        if ( v19 > v23 ) /*0x14113c646*/
        {
          v26 = (std::vector<RBX::Reflection::Variant> *)(v6 + 56); /*0x14113c66a*/
          if ( v19 <= (*((_QWORD *)v6 + 9) - v21) / 80 ) /*0x14113c671*/
            *((_QWORD *)v6 + 8) = std::vector<RBX::Reflection::Variant>::_Ufill( /*0x14113c69a*/
                                    this: v26,
                                    _Dest: v20,
                                    _Count: v19 - v23,
                                    __formal: (std::_Value_init_tag)_Val);
          else
            std::vector<RBX::Reflection::Variant>::_Resize_reallocate<std::_Value_init_tag>( /*0x14113c67d*/
              this: v26,
              _Newsize: v19,
              (const std::_Value_init_tag *)&_Val);
        }
      }
      else
      {
        v24 = (RBX::Reflection::Variant *)(v21 + 80 * v19); /*0x14113c5ff*/
        if ( v24 != v20 ) /*0x14113c605*/
        {
          p_value = &v24->value; /*0x14113c607*/
          do /*0x14113c632*/
          {
            __wind /*0xf1c0000000000068*/
            {
              if ( p_value->holder != nullptr ) /*0x14113c616*/
              {
                p_value->holder->destruct(a1: p_value->data); /*0x14113c620*/
                v20 = v59; /*0x14113c622*/
              }
            }
            __unwind
            {
              __std_terminate(a1: v22, a2: &v57); /*0x142f39fa8*/
            }
            p_value = (rbx::placement_any<RBX::Reflection::Variant::Storage> *)((char *)p_value + 80); /*0x14113c627*/
          }
          while ( &p_value[-1].data[56] != (char *)v20 ); /*0x14113c632*/
          v18 = v60; /*0x14113c634*/
        }
        *((_QWORD *)v6 + 8) = v24; /*0x14113c639*/
        v4 = replicator; /*0x14113c63d*/
      }
      deferredSharedStrings.table_.current_ = false; /*0x14113c69e*/
      deferredSharedStrings.table_.bucket_count_ = 16; /*0x14113c6a2*/
      deferredSharedStrings.table_.size_ = 0; /*0x14113c6aa*/
      deferredSharedStrings.table_.mlf_ = 1.0; /*0x14113c6b6*/
      *(_OWORD *)&deferredSharedStrings.table_.max_load_ = 0; /*0x14113c6be*/
      __wind /*0xf1c0000000000050*/
      {
        memset(&metaData, 0, sizeof(metaData)); /*0x14113c6c3*/
        if ( !v4->isCloudEdit(this: v4) && v4->isServerReplicator(this: v4) ) /*0x14113c6f8*/
        {
          metaData.replicatedStringDataSizeLimit = DFInt::RCCReceiveEventStringDataLimitBytes; /*0x14113c708*/
          metaData.variantCountLimit = DFInt::RCCReceiveEventVariantCountLimit; /*0x14113c712*/
          metaData.replicatedStringDataSizeReportingThreshold = DFInt::RCCReceiveEventStringDataReportingBytes; /*0x14113c71c*/
          metaData.variantCountReportingThreshold = DFInt::RCCReceiveEventVariantReportingCount; /*0x14113c726*/
        }
        LODWORD(v59) = 0; /*0x14113c72a*/
        v28 = v18->argumentTypes._Mypair._Myval2._Myfirst; /*0x14113c72e*/
        if ( v18->argumentTypes._Mypair._Myval2._Mylast - v28 != 0 ) /*0x14113c754*/
        {
          v29 = 0; /*0x14113c75a*/
          do /*0x14113c80b*/
          {
            v30 = *((RBX::Instance **)v6 + 4); /*0x14113c760*/
            v31 = (RBX::Reflection::Variant *)(*((_QWORD *)v6 + 7) + 80 * v29); /*0x14113c76c*/
            v32 = &v28[v29]; /*0x14113c774*/
            if ( v32->valueFormat == NetworkValueFormat_ProtectedStringServerIndexString ) /*0x14113c77c*/
            {
              std::string::string(this: &m, _Ptr: "Invalid variant type"); /*0x14113cbdf*/
              __wind /*0xf1c000000000002c*/
              {
                RBX::network_stream_exception::network_stream_exception(this: &pExceptionObject, &m); /*0x14113cbf0*/
                throw &pExceptionObject; /*0x14113cc03*/
              }
              __unwind
              {
                RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&m); /*0xf1c000000000003c*/
              }
            }
            vs.valueType = v32; /*0x14113c782*/
            vs.variant = v31; /*0x14113c786*/
            vs.optionalPropertyDesc = nullptr; /*0x14113c78a*/
            vs.optionalUnresolvedGuid = nullptr; /*0x14113c78e*/
            vs.optionalInstance = v30; /*0x14113c792*/
            vs.optionalNetworkId = eventId; /*0x14113c79b*/
            LOBYTE(v27) = 1; /*0x14113c7c0*/
            RBX::Network::Replicator::schemaReadValue<RBX::Network::VariantValueSetter>( /*0x14113c7cd*/
              this: v4,
              inBitStream: inBitstream,
              valueType: v32,
              useDictionaries: v27,
              out: &vs,
              depth: 0,
              &deferredSharedStrings,
              replicationMetaData: &metaData);
            v27 = (unsigned int)((_DWORD)v59 + 1); /*0x14113c7d7*/
            LODWORD(v59) = v27; /*0x14113c7da*/
            v28 = v18->argumentTypes._Mypair._Myval2._Myfirst; /*0x14113c7df*/
            v29 = (unsigned int)v27; /*0x14113c805*/
          }
          while ( (unsigned int)v27 < (unsigned __int64)(v18->argumentTypes._Mypair._Myval2._Mylast - v28) ); /*0x14113c80b*/
        }
        RBX::Network::Replicator::accumulateAndCheckVariantRecvSpeedBucket(this: v4, &metaData); /*0x14113c819*/
        RBX::Network::Replicator::readNewSharedStrings( /*0x14113c82c*/
          this: v4,
          inBitStream: inBitstream,
          deferredStrings: &deferredSharedStrings);
      }
      __unwind
      {
        boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>>::~unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::vector<RBX::Network::DeferredSharedStringSetter>>>>(this: &deferredSharedStrings); /*0xf1c0000000000048*/
      }
      v33 = *((const RBX::Reflection::Type ***)v6 + 7); /*0x14113c831*/
      v34 = *((const RBX::Reflection::Type ***)v6 + 8); /*0x14113c835*/
      if ( v33 == v34 ) /*0x14113c83c*/
      {
LABEL_45:
        v36 = 0; /*0x14113c85f*/
      }
      else
      {
        while ( 1 ) /*0x14113c840*/
        {
          v35 = *v33; /*0x14113c840*/
          if ( v35 == RBX::Reflection::Type::getSingleton<void>() ) /*0x14113c84b*/
            break; /*0x14113c84b*/
          v33 += 10; /*0x14113c851*/
          if ( v33 == v34 ) /*0x14113c858*/
          {
            v18 = v60; /*0x14113c85a*/
            goto LABEL_45; /*0x14113c85a*/
          }
        }
        v36 = 1; /*0x14113ca1a*/
        v18 = v60; /*0x14113ca1c*/
      }
      *((_DWORD *)v6 + 20) = metaData.variantCount; /*0x14113c865*/
      *((_DWORD *)v6 + 21) = metaData.replicatedStringDataSize; /*0x14113c86c*/
      if ( *((_QWORD *)v6 + 4) != 0 && v18->localDescriptor != nullptr && v36 == 0 ) /*0x14113c887*/
      {
        *((_QWORD *)v6 + 3) = metaData.replicatedStringDataSize; /*0x14113c891*/
        v37 = result; /*0x14113c895*/
        result->_Ptr = (RBX::Network::DeserializedItem *)v6; /*0x14113c89c*/
        result->_Rep = v8; /*0x14113c8a0*/
        buckets = deferredSharedStrings.table_.buckets_; /*0x14113c8a4*/
        if ( deferredSharedStrings.table_.buckets_ == nullptr ) /*0x14113c8ab*/
        {
LABEL_67:
          v45 = deseiralizedInstance._Rep; /*0x14113c9cf*/
          if ( deseiralizedInstance._Rep != nullptr /*0x14113c9e3*/
            && _InterlockedExchangeAdd((volatile signed __int32 *)&deseiralizedInstance._Rep->_Uses, 0xFFFFFFFF) == 1 )
          {
            v45->_Destroy(this: v45); /*0x14113c9eb*/
            if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v45->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113c9f7*/
              v45->_Delete_this(this: v45); /*0x14113c9ff*/
          }
          return v37; /*0xf1c00000000000d4*/
        }
        if ( deferredSharedStrings.table_.size_ != 0 ) /*0x14113c8b6*/
        {
          bucket_count = deferredSharedStrings.table_.bucket_count_; /*0x14113c8bc*/
          next = deferredSharedStrings.table_.buckets_[deferredSharedStrings.table_.bucket_count_].next_; /*0x14113c8c0*/
          do /*0x14113c984*/
          {
            buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_; /*0x14113c8d3*/
            v41 = next[6].next_; /*0x14113c8d7*/
            if ( v41 != nullptr ) /*0x14113c8de*/
            {
              if ( (((char *)next[8].next_ - (char *)v41) & 0xFFFFFFFFFFFFFFE0uLL) >= 0x1000 ) /*0x14113c8f2*/
              {
                if ( (unsigned __int64)((char *)v41 - (char *)v41[-1].next_ - 8) > 0x1F ) /*0x14113c907*/
                  goto LABEL_90; /*0x14113c907*/
                v41 = v41[-1].next_; /*0x14113c90d*/
              }
              operator delete(ptr: v41); /*0x14113c910*/
              next[6].next_ = nullptr; /*0x14113c915*/
              next[7].next_ = nullptr; /*0x14113c919*/
              next[8].next_ = nullptr; /*0x14113c91d*/
            }
            v42 = (unsigned __int64)next[5].next_; /*0x14113c921*/
            if ( v42 >= 0x10 ) /*0x14113c929*/
            {
              v43 = next[2].next_; /*0x14113c92b*/
              if ( v42 + 1 >= 0x1000 ) /*0x14113c939*/
              {
                if ( (unsigned __int64)((char *)v43 - (char *)v43[-1].next_ - 8) > 0x1F ) /*0x14113c94e*/
                  goto LABEL_90; /*0x14113c94e*/
                v43 = v43[-1].next_; /*0x14113c954*/
              }
              operator delete(ptr: v43); /*0x14113c957*/
            }
            next[4].next_ = nullptr; /*0x14113c95c*/
            next[5].next_ = (boost::unordered::detail::ptr_bucket *)15; /*0x14113c960*/
            LOBYTE(next[2].next_) = 0; /*0x14113c968*/
            operator delete(ptr: next); /*0x14113c974*/
            --deferredSharedStrings.table_.size_; /*0x14113c979*/
            next = buckets[bucket_count].next_; /*0x14113c97d*/
          }
          while ( next != nullptr ); /*0x14113c984*/
          buckets = deferredSharedStrings.table_.buckets_; /*0x14113c98a*/
        }
        v44 = buckets; /*0x14113c99a*/
        if ( 8 * deferredSharedStrings.table_.bucket_count_ + 8 < 0x1000 /*0x14113c9b9*/
          || (buckets = buckets[-1].next_, (unsigned __int64)((char *)v44 - (char *)buckets - 8) <= 0x1F) )
        {
          operator delete(ptr: buckets); /*0x14113c9c2*/
          deferredSharedStrings.table_.buckets_ = nullptr; /*0x14113c9c7*/
          deferredSharedStrings.table_.max_load_ = 0; /*0x14113c9cb*/
          goto LABEL_67; /*0x14113c9cb*/
        }
LABEL_90:
        _invalid_parameter_noinfo_noreturn(); /*0x14113cb47*/
      }
      v37 = result; /*0x14113ca26*/
      result->_Ptr = nullptr; /*0x14113ca2d*/
      result->_Rep = nullptr; /*0x14113ca31*/
      v47 = deferredSharedStrings.table_.buckets_; /*0x14113ca35*/
      if ( deferredSharedStrings.table_.buckets_ != nullptr ) /*0x14113ca3c*/
      {
        if ( deferredSharedStrings.table_.size_ != 0 ) /*0x14113ca47*/
        {
          v48 = deferredSharedStrings.table_.bucket_count_; /*0x14113ca4d*/
          v49 = deferredSharedStrings.table_.buckets_[deferredSharedStrings.table_.bucket_count_].next_; /*0x14113ca51*/
          do /*0x14113cb10*/
          {
            v47[v48] = (boost::unordered::detail::ptr_bucket)v49->next_; /*0x14113ca63*/
            v50 = v49[6].next_; /*0x14113ca67*/
            if ( v50 != nullptr ) /*0x14113ca6e*/
            {
              if ( (((char *)v49[8].next_ - (char *)v50) & 0xFFFFFFFFFFFFFFE0uLL) >= 0x1000 ) /*0x14113ca82*/
              {
                if ( (unsigned __int64)((char *)v50 - (char *)v50[-1].next_ - 8) > 0x1F ) /*0x14113ca97*/
                  goto LABEL_90; /*0x14113ca97*/
                v50 = v50[-1].next_; /*0x14113ca9d*/
              }
              operator delete(ptr: v50); /*0x14113caa0*/
              v49[6].next_ = nullptr; /*0x14113caa5*/
              v49[7].next_ = nullptr; /*0x14113caa9*/
              v49[8].next_ = nullptr; /*0x14113caad*/
            }
            v51 = (unsigned __int64)v49[5].next_; /*0x14113cab1*/
            if ( v51 >= 0x10 ) /*0x14113cab9*/
            {
              v52 = v49[2].next_; /*0x14113cabb*/
              if ( v51 + 1 >= 0x1000 ) /*0x14113cac9*/
              {
                if ( (unsigned __int64)((char *)v52 - (char *)v52[-1].next_ - 8) > 0x1F ) /*0x14113cade*/
                  goto LABEL_90; /*0x14113cade*/
                v52 = v52[-1].next_; /*0x14113cae0*/
              }
              operator delete(ptr: v52); /*0x14113cae3*/
            }
            v49[4].next_ = nullptr; /*0x14113cae8*/
            v49[5].next_ = (boost::unordered::detail::ptr_bucket *)15; /*0x14113caec*/
            LOBYTE(v49[2].next_) = 0; /*0x14113caf4*/
            operator delete(ptr: v49); /*0x14113cb00*/
            --deferredSharedStrings.table_.size_; /*0x14113cb05*/
            v49 = v47[v48].next_; /*0x14113cb09*/
          }
          while ( v49 != nullptr ); /*0x14113cb10*/
          v47 = deferredSharedStrings.table_.buckets_; /*0x14113cb16*/
        }
        v53 = v47; /*0x14113cb26*/
        if ( 8 * deferredSharedStrings.table_.bucket_count_ + 8 >= 0x1000 ) /*0x14113cb30*/
        {
          v47 = v47[-1].next_; /*0x14113cb36*/
          if ( (unsigned __int64)((char *)v53 - (char *)v47 - 8) > 0x1F ) /*0x14113cb45*/
            goto LABEL_90; /*0x14113cb45*/
        }
        operator delete(ptr: v47); /*0x14113cb51*/
        deferredSharedStrings.table_.buckets_ = nullptr; /*0x14113cb56*/
        deferredSharedStrings.table_.max_load_ = 0; /*0x14113cb5a*/
      }
      v54 = deseiralizedInstance._Rep; /*0x14113cb5e*/
      if ( deseiralizedInstance._Rep != nullptr /*0x14113cb72*/
        && _InterlockedExchangeAdd((volatile signed __int32 *)&deseiralizedInstance._Rep->_Uses, 0xFFFFFFFF) == 1 )
      {
        v54->_Destroy(this: v54); /*0x14113cb7a*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v54->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113cb87*/
          v54->_Delete_this(this: v54); /*0x14113cb8f*/
      }
      if ( v8 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v8->_Uses, 0xFFFFFFFF) == 1 ) /*0x14113cba8*/
      {
        v8->_Destroy(this: v8); /*0x14113cbb4*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v8->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113cbc0*/
          v8->_Delete_this(this: v8); /*0x14113cbcc*/
      }
      return v37; /*0x14113cbcf*/
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&deseiralizedInstance); /*0xf1c00000000000a4*/
    }
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&deserializedData); /*0xf1c00000000000b0*/
  }
}

// Address: 0x14113cc90 | Name: ?shouldRateLimitSend@EventInvocationItem@Replicator@Network@RBX@@UEAA_NXZ
bool __fastcall RBX::Network::Replicator::EventInvocationItem::shouldRateLimitSend(
        RBX::Network::Replicator::EventInvocationItem *this)
{
  return this->replicator->shouldRateLimitTxRemoteEvents(
           this: this->replicator,
           a2: this->instance._Ptr,
           a3: this->desc,
           a4: this->sharedArguments._Ptr);
}

// Address: 0x14113ccb0 | Name: ?write@EventInvocationItem@Replicator@Network@RBX@@UEAA_NAEAVNetworkStream@34@@Z
_BOOL8 __fastcall RBX::Network::Replicator::EventInvocationItem::write(
        RBX::Network::Replicator::EventInvocationItem *this,
        RBX::Network::NetworkStream *bitStream)
{
  bool v2; // al
  bool v3; // r14
  RBX::SharedString *Myfirst; // rdi
  RBX::SharedString *Mylast; // rbp
  _RTL_CRITICAL_SECTION *v6; // rbx
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *h; // rsi
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *v9; // rax
  __int64 p_node_count; // rcx
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *v11; // r9
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> **v12; // rcx
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *v13; // rdx
  _QWORD *v14; // rdx
  unsigned __int64 Myres; // rdx
  char *v16; // rcx
  RBX::SharedString *v17; // rax
  __int64 v18; // rcx
  _BOOL8 result; // rax
  __int64 v20; // [rsp+0h] [rbp-88h] BYREF
  std::shared_ptr<RBX::File> v21; // [rsp+40h] [rbp-48h] BYREF
  std::vector<RBX::SharedString> ptr; // [rsp+50h] [rbp-38h] BYREF

  __wind /*0xf1c0000000000020*/
  {
    __wind /*0xf1c0000000000028*/
    {
      memset(&ptr, 0, sizeof(ptr)); /*0x14113ccd6*/
      v21 = 0; /*0x14113cce3*/
      v2 = RBX::Network::Replicator::EventInvocationItem::writeDirect( /*0x14113cd10*/
             bitStream,
             replicator: this->replicator,
             classEvent: this->classEvent,
             instance: this->instance._Ptr,
             sharedArguments: this->sharedArguments._Ptr,
             preserializedCacheStream: (const std::shared_ptr<RBX::Network::NetworkStream> *)&v21,
             sharedStringsInPreserializedStream: &ptr);
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v21); /*0xf1c0000000000038*/
    }
  }
  __unwind
  {
    std::vector<RBX::SharedString>::_Tidy(this: &ptr); /*0xf1c0000000000044*/
  }
  __wind /*0xf1c000000000004c*/
  {
    v3 = v2; /*0x14113cd15*/
    Myfirst = ptr._Mypair._Myval2._Myfirst; /*0x14113cd19*/
    if ( ptr._Mypair._Myval2._Myfirst != nullptr ) /*0x14113cd21*/
    {
      Mylast = ptr._Mypair._Myval2._Mylast; /*0x14113cd27*/
      if ( ptr._Mypair._Myval2._Myfirst != ptr._Mypair._Myval2._Mylast ) /*0x14113cd2f*/
      {
        while ( _InterlockedExchangeAdd(&Myfirst->flyweight.h.h->ref.value_, 0xFFFFFFFF) != 1 ) /*0x14113cd50*/
        {
LABEL_22:
          if ( ++Myfirst == Mylast ) /*0x14113ce48*/
          {
            Myfirst = ptr._Mypair._Myval2._Myfirst; /*0x14113ce4e*/
            goto LABEL_24; /*0x14113ce4e*/
          }
        }
        boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init(); /*0x14113cd56*/
        v6 = boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::static_mutex_ptr; /*0x14113cd5b*/
        EnterCriticalSection(lpCriticalSection: boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::static_mutex_ptr); /*0x14113cd65*/
        if ( Myfirst->flyweight.h.h->del_ref-- != 1 ) /*0x14113cd6e*/
        {
LABEL_21:
          LeaveCriticalSection(lpCriticalSection: v6); /*0x14113ce37*/
          goto LABEL_22; /*0x14113ce3a*/
        }
        h = Myfirst->flyweight.h.h; /*0x14113cd78*/
        v9 = Myfirst->flyweight.h.h + 1; /*0x14113cd86*/
        if ( Myfirst->flyweight.h.h == nullptr ) /*0x14113cd8d*/
          v9 = nullptr; /*0x14113cd8d*/
        p_node_count = (__int64)&boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::static_factory_ptr->cont.node_count; /*0x14113cd91*/
        if ( boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::static_factory_ptr == (boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,boost::mpl::na,boost::mpl::na,boost::mpl::na> *)-24LL ) /*0x14113cd98*/
          p_node_count = 80; /*0x14113cd98*/
        --*(_QWORD *)p_node_count; /*0x14113cd9c*/
        v11 = *(const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> **)(v9->x.x.b2b.asSizet[0] + 8); /*0x14113cda2*/
        v12 = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> **)v9->x.x.b2b.asSizet[1]; /*0x14113cda6*/
        v13 = *v12; /*0x14113cdaa*/
        if ( v11 == v9 ) /*0x14113cdb0*/
        {
          *(_QWORD *)(v9->x.x.b2b.asSizet[0] + 8) = v12; /*0x14113ce87*/
          if ( v13 != v9 ) /*0x14113ce8e*/
          {
            v14 = *(_QWORD **)v9->x.x.b2b.asSizet[1]; /*0x14113ce98*/
            goto LABEL_15; /*0x14113ce9b*/
          }
        }
        else
        {
          if ( v13 != v9 ) /*0x14113cdb9*/
          {
            v11->x.x.b2b.asSizet[0] = 0; /*0x14113cdbb*/
            *(_QWORD *)(v9->x.x.b2b.asSizet[0] + 8) = v9->x.x.b2b.asSizet[1]; /*0x14113cdc5*/
            v14 = *(_QWORD **)v9->x.x.b2b.asSizet[1]; /*0x14113cdcd*/
LABEL_15:
            *v14 = v9->x.x.b2b.asSizet[0]; /*0x14113cdd9*/
            Myres = h->x.x.contents._Mypair._Myval2._Myres; /*0x14113cddf*/
            if ( Myres >= 0x10 ) /*0x14113cde7*/
            {
              v16 = h->x.x.contents._Mypair._Myval2._Bx._Ptr; /*0x14113cde9*/
              if ( Myres + 1 >= 0x1000 ) /*0x14113cdf7*/
              {
                if ( (unsigned __int64)&v16[-*((_QWORD *)v16 - 1) - 8] > 0x1F ) /*0x14113ce0c*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14113cea0*/
                v16 = *((char **)v16 - 1); /*0x14113ce12*/
              }
              operator delete(ptr: v16); /*0x14113ce15*/
            }
            h->x.x.contents._Mypair._Myval2._Mysize = 0; /*0x14113ce1a*/
            h->x.x.contents._Mypair._Myval2._Myres = 15; /*0x14113ce1e*/
            h->x.x.contents._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14113ce26*/
            operator delete(ptr: (void *)h); /*0x14113ce32*/
            goto LABEL_21; /*0x14113ce32*/
          }
          v11->x.x.b2b.asSizet[0] = (unsigned __int64)v12; /*0x14113cdd2*/
        }
        v14 = (_QWORD *)v9->x.x.b2b.asSizet[1]; /*0x14113cdd5*/
        goto LABEL_15; /*0x14113cdd5*/
      }
LABEL_24:
      v17 = Myfirst; /*0x14113ce53*/
      if ( (((char *)ptr._Mypair._Myval2._Myend - (char *)Myfirst) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x14113ce69*/
      {
        Myfirst = *(RBX::SharedString **)&Myfirst[-1].readCount; /*0x14113ce6f*/
        if ( (unsigned __int64)((char *)v17 - (char *)Myfirst - 8) > 0x1F ) /*0x14113ce7e*/
          _invalid_parameter_noinfo_noreturn(); /*0x14113ce80*/
      }
      operator delete(ptr: Myfirst); /*0x14113ceaa*/
    }
    result = v3; /*0x14113ceaf*/
  }
  __unwind
  {
    __std_terminate(a1: v18, a2: &v20); /*0x142f39fa8*/
  }
  return result; /*0x14113ceb3*/
}

// Address: 0x14113cee0 | Name: ?writeDirect@EventInvocationItem@Replicator@Network@RBX@@SA_NAEAVNetworkStream@34@PEAV234@AEBUClassEvent@NetworkSchema@34@PEBVInstance@4@AEBV?$vector@VVariant@Reflection@RBX@@V?$allocator@VVariant@Reflection@RBX@@@std@@@std@@AEBV?$shared_ptr@VNetworkStream@Network@RBX@@@std@@AEBV?$vector@VSharedString@RBX@@V?$allocator@VSharedString@RBX@@@std@@@std@@@Z
char __fastcall RBX::Network::Replicator::EventInvocationItem::writeDirect(
        RBX::Network::NetworkStream *bitStream,
        RBX::Network::Replicator *replicator,
        const RBX::Network::NetworkSchema::ClassEvent *classEvent,
        const RBX::Instance *instance,
        const std::vector<RBX::Reflection::Variant> *sharedArguments,
        const std::shared_ptr<RBX::Network::NetworkStream> *preserializedCacheStream,
        const std::vector<RBX::SharedString> *sharedStringsInPreserializedStream)
{
  const RBX::Instance *v7; // r13
  const RBX::Network::NetworkSchema::ClassEvent *v8; // r12
  const std::shared_ptr<RBX::Network::NetworkStream> *v11; // rdi
  unsigned int numberOfBytesUsed; // esi
  unsigned int v13; // ebx
  unsigned __int8 *v14; // rax
  unsigned int v15; // esi
  unsigned int v16; // ebx
  __int64 v17; // rcx
  unsigned int v18; // edi
  int v19; // ebx
  __int64 v20; // rcx
  const RBX::Name *name; // r8
  bool v22; // al
  int v23; // ebx
  char *v24; // rax
  char *Ptr; // rcx
  RBX::SharedString *Myfirst; // rsi
  RBX::SharedString *Mylast; // r12
  _RTL_CRITICAL_SECTION *v28; // rbx
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *h; // rdi
  __int64 v31; // rdx
  __int64 p_node_count; // rax
  __int64 v33; // r8
  __int64 **v34; // r9
  __int64 *v35; // rax
  __int64 v36; // r10
  __int64 *v37; // rcx
  unsigned __int64 Myres; // rdx
  char *v39; // rcx
  RBX::SharedString *v40; // rax
  __int64 v42; // [rsp+0h] [rbp-100h] BYREF
  unsigned __int8 v43[8]; // [rsp+40h] [rbp-C0h] BYREF
  unsigned __int8 inOutByteArray[4]; // [rsp+48h] [rbp-B8h] BYREF
  unsigned int v45; // [rsp+4Ch] [rbp-B4h]
  RBX::Network::ReplicationVariantSizeLimitsMetaData metaData; // [rsp+50h] [rbp-B0h] BYREF
  RBX::Network::VariantValueGetter vc; // [rsp+70h] [rbp-90h] BYREF
  std::vector<RBX::SharedString> sharedStringInfo; // [rsp+78h] [rbp-88h] BYREF
  std::string resource; // [rsp+90h] [rbp-70h] BYREF
  RBX::Analytics::InfluxDb::Points eventMetaDataReport; // [rsp+B0h] [rbp-50h] BYREF
  RBX::Network::Replicator::SerializerParameters params; // [rsp+120h] [rbp+20h] BYREF

  v7 = instance; /*0x14113cf06*/
  v8 = classEvent; /*0x14113cf09*/
  RBX::Network::Replicator::incrementItemTypeSentCount(this: replicator, type: ItemTypeEventInvocation); /*0x14113cf1a*/
  v11 = preserializedCacheStream; /*0x14113cf1f*/
  if ( preserializedCacheStream->_Ptr != nullptr /*0x14113cf36*/
    && preserializedCacheStream->_Ptr->GetNumberOfBytesUsed(this: preserializedCacheStream->_Ptr) != 0 )
  {
    numberOfBytesUsed = bitStream->numberOfBytesUsed; /*0x14113cf38*/
    v13 = v11->_Ptr->GetNumberOfBytesUsed(this: v11->_Ptr); /*0x14113cf45*/
    v14 = v11->_Ptr->GetData(this: v11->_Ptr); /*0x14113cf4d*/
    RBX::Network::NetworkStream::writeBytes(this: bitStream, inByteArray: v14, numberOfBytesToWrite: v13); /*0x14113cf59*/
    RBX::Network::Replicator::writeNewSharedStrings( /*0x14113cf6b*/
      this: replicator,
      outBitStream: bitStream,
      sentStrings: sharedStringsInPreserializedStream);
    goto LABEL_69; /*0x14113cf70*/
  }
  LOBYTE(preserializedCacheStream) = 7; /*0x14113cf75*/
  RBX::Network::NetworkStream::writeBytes( /*0x14113cf8c*/
    this: bitStream,
    inByteArray: &preserializedCacheStream,
    numberOfBytesToWrite: 1u);
  v45 = bitStream->numberOfBytesUsed; /*0x14113cf95*/
  RBX::Network::IdSerializer::serializeId(this: replicator, stream: bitStream, instance: v7); /*0x14113cfa2*/
  *(_WORD *)v43 = v8->eventNetworkId; /*0x14113cfac*/
  RBX::Network::NetworkStream::ReverseBytes(inByteArray: v43, inOutByteArray, length: 2u); /*0x14113cfc1*/
  RBX::Network::NetworkStream::writeBytes(this: bitStream, inByteArray: inOutByteArray, numberOfBytesToWrite: 2u); /*0x14113cfd4*/
  memset(&sharedStringInfo, 0, sizeof(sharedStringInfo)); /*0x14113cfdc*/
  __wind /*0xf1c0000000000068*/
  {
    memset(&metaData, 0, sizeof(metaData)); /*0x14113cfe8*/
    if ( !replicator->isCloudEdit(this: replicator) && !replicator->isServerReplicator(this: replicator) ) /*0x14113d019*/
    {
      metaData.replicatedStringDataSizeLimit = DFInt::ClientSendEventStringDataLimitBytes; /*0x14113d021*/
      metaData.variantCountLimit = DFInt::ClientSendEventVariantCountLimit; /*0x14113d02b*/
    }
    v15 = bitStream->GetNumberOfBytesUsed(this: bitStream); /*0x14113d038*/
    RBX::Network::Replicator::getSerializerParameters(this: replicator, result: &params); /*0x14113d041*/
    v16 = 0; /*0x14113d046*/
    if ( v8->argumentTypes._Mypair._Myval2._Mylast - v8->argumentTypes._Mypair._Myval2._Myfirst != 0 ) /*0x14113d06d*/
    {
      v17 = 0; /*0x14113d073*/
      do /*0x14113d108*/
      {
        vc.variant = &sharedArguments->_Mypair._Myval2._Myfirst[v17]; /*0x14113d09b*/
        RBX::Network::Replicator::schemaWriteValue<RBX::Network::VariantValueGetter>( /*0x14113d0de*/
          outBitStream: bitStream,
          valueType: &v8->argumentTypes._Mypair._Myval2._Myfirst[v17],
          useDictionaries: true,
          &vc,
          depth: 0,
          sentSharedStrings: &sharedStringInfo,
          replicationMetaData: &metaData,
          parameters: &params);
        v17 = ++v16; /*0x14113d103*/
      }
      while ( v16 < (unsigned __int64)(v8->argumentTypes._Mypair._Myval2._Mylast /*0x14113d108*/
                                     - v8->argumentTypes._Mypair._Myval2._Myfirst) );
      v7 = instance; /*0x14113d10a*/
    }
    RBX::Network::Replicator::writeNewSharedStrings( /*0x14113d11c*/
      this: replicator,
      outBitStream: bitStream,
      sentStrings: &sharedStringInfo);
    v18 = ((__int64 (__fastcall *)(RBX::Network::NetworkStream *))bitStream->GetNumberOfBytesUsed)(a1: bitStream) - v15; /*0x14113d12c*/
    if ( DFFlag::EventMetaDataReportingTypeAndMem.value ) /*0x14113d141*/
      v19 = metaData.replicatedStringDataSize + 80 * metaData.variantCount; /*0x14113d149*/
    else
      v19 = 0; /*0x14113d14d*/
    if ( DFInt::EventMetaDataReportingDepthThreshold != 0 /*0x14113d1a2*/
      && metaData.maxVariantDepth >= DFInt::EventMetaDataReportingDepthThreshold
      || DFInt::EventMetaDataReportingStringSizeThreshold != 0
      && metaData.replicatedStringDataSize >= DFInt::EventMetaDataReportingStringSizeThreshold
      || DFInt::EventMetaDataReportingTotalStreamSizeThreshold != 0
      && v18 >= DFInt::EventMetaDataReportingTotalStreamSizeThreshold
      || (v20 = (unsigned int)DFInt::EventMetaDataReportingVariantCountThreshold,
          DFInt::EventMetaDataReportingVariantCountThreshold != 0)
      && metaData.variantCount >= DFInt::EventMetaDataReportingVariantCountThreshold
      || DFFlag::EventMetaDataReportingTypeAndMem.value
      && DFInt::EventMetaDataReportingTotalMemoryThreshold != 0
      && v19 >= DFInt::EventMetaDataReportingTotalMemoryThreshold )
    {
      RBX::Analytics::InfluxDb::Points::Points( /*0x14113d1b6*/
        this: &eventMetaDataReport,
        throttleHundredthsPercentage: -1,
        categoryType: kStandardType,
        priorityHundredthsPercentage: 0);
      __wind /*0xf1c0000000000038*/
      {
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14113d1ec*/
          this: &eventMetaDataReport,
          name: (const char *)&RBX::Network::Replicator::EventInvocationItem::`vftable'[7],
          value: v8->argumentTypes._Mypair._Myval2._Mylast - v8->argumentTypes._Mypair._Myval2._Myfirst);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14113d201*/
          this: &eventMetaDataReport,
          name: "MaxVariantDepth",
          value: metaData.maxVariantDepth);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14113d216*/
          this: &eventMetaDataReport,
          name: "TotalSizeOfStrings",
          value: metaData.replicatedStringDataSize);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14113d22b*/
          this: &eventMetaDataReport,
          name: "TotalVariantCount",
          value: metaData.variantCount);
        RBX::Analytics::InfluxDb::Points::addPoint( /*0x14113d23e*/
          this: &eventMetaDataReport,
          name: "TotalReplicatedStreamSize",
          value: v18);
        if ( DFFlag::EventMetaDataReportingTypeAndMem.value ) /*0x14113d24a*/
        {
          name = v7->descriptor->RBX::Reflection::DescribedBase::name; /*0x14113d250*/
          if ( name->str._Mypair._Myval2._Myres >= 0x10 ) /*0x14113d259*/
            name = (const RBX::Name *)name->str._Mypair._Myval2._Bx._Ptr; /*0x14113d25b*/
          RBX::Analytics::InfluxDb::Points::addPoint( /*0x14113d269*/
            this: &eventMetaDataReport,
            name: "Type",
            value: name->str._Mypair._Myval2._Bx._Buf);
          RBX::Analytics::InfluxDb::Points::addPoint(this: &eventMetaDataReport, name: "TotalMemorySize", value: v19); /*0x14113d27c*/
        }
        v22 = replicator->isCloudEdit(this: replicator); /*0x14113d287*/
        RBX::Analytics::InfluxDb::Points::addPoint(this: &eventMetaDataReport, name: "IsTeamCreate", value: v22); /*0x14113d29c*/
        v23 = DFInt::ReplicatorEventReportEventMetaDataMyriad; /*0x14113d2a1*/
        resource._Mypair._Myval2._Bx._Ptr = nullptr; /*0x14113d2aa*/
        resource._Mypair._Myval2._Mysize = 0; /*0x14113d2ae*/
        resource._Mypair._Myval2._Myres = 15; /*0x14113d2b2*/
        v24 = (char *)operator new(size: 0x20u); /*0x14113d2c2*/
        resource._Mypair._Myval2._Mysize = 23; /*0x14113d2c7*/
        resource._Mypair._Myval2._Myres = 31; /*0x14113d2cf*/
        strcpy(v24, "ReplicatorEventMetaData"); /*0x14113d2de*/
        resource._Mypair._Myval2._Bx._Ptr = v24; /*0x14113d303*/
        __wind /*0xf1c000000000002c*/
        {
          RBX::Analytics::InfluxDb::Points::report( /*0x14113d315*/
            this: &eventMetaDataReport,
            &resource,
            throttleHundredthsPercentage: v23,
            blocking: false);
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&resource); /*0xf1c0000000000024*/
        }
        if ( resource._Mypair._Myval2._Myres >= 0x10 ) /*0x14113d323*/
        {
          Ptr = resource._Mypair._Myval2._Bx._Ptr; /*0x14113d328*/
          if ( resource._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14113d336*/
          {
            Ptr = *((char **)resource._Mypair._Myval2._Bx._Ptr - 1); /*0x14113d33c*/
            if ( (unsigned __int64)(resource._Mypair._Myval2._Bx._Ptr - Ptr - 8) > 0x1F ) /*0x14113d34b*/
              _invalid_parameter_noinfo_noreturn(); /*0x14113d34d*/
          }
          operator delete(ptr: Ptr); /*0x14113d354*/
        }
        RBX::Analytics::InfluxDb::Points::~Points(this: &eventMetaDataReport); /*0x14113d35e*/
      }
      __unwind
      {
        RBX::Analytics::InfluxDb::Points::~Points(this: &eventMetaDataReport); /*0xf1c0000000000048*/
      }
    }
  }
  __unwind
  {
    std::vector<RBX::SharedString>::_Tidy(this: &sharedStringInfo); /*0xf1c0000000000054*/
  }
  __wind /*0xf1c000000000005c*/
  {
    Myfirst = sharedStringInfo._Mypair._Myval2._Myfirst; /*0x14113d368*/
    if ( sharedStringInfo._Mypair._Myval2._Myfirst != nullptr ) /*0x14113d370*/
    {
      Mylast = sharedStringInfo._Mypair._Myval2._Mylast; /*0x14113d376*/
      if ( sharedStringInfo._Mypair._Myval2._Myfirst != sharedStringInfo._Mypair._Myval2._Mylast ) /*0x14113d37d*/
      {
        while ( _InterlockedExchangeAdd(&Myfirst->flyweight.h.h->ref.value_, 0xFFFFFFFF) != 1 ) /*0x14113d3a0*/
        {
LABEL_59:
          if ( ++Myfirst == Mylast ) /*0x14113d4a2*/
          {
            Myfirst = sharedStringInfo._Mypair._Myval2._Myfirst; /*0x14113d4a8*/
            goto LABEL_61; /*0x14113d4a8*/
          }
        }
        boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init(); /*0x14113d3a6*/
        v28 = boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::static_mutex_ptr; /*0x14113d3ab*/
        EnterCriticalSection(lpCriticalSection: boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::static_mutex_ptr); /*0x14113d3b5*/
        if ( Myfirst->flyweight.h.h->del_ref-- != 1 ) /*0x14113d3be*/
        {
LABEL_58:
          LeaveCriticalSection(lpCriticalSection: v28); /*0x14113d491*/
          goto LABEL_59; /*0x14113d494*/
        }
        h = Myfirst->flyweight.h.h; /*0x14113d3c8*/
        v31 = (__int64)&Myfirst->flyweight.h.h[1]; /*0x14113d3d6*/
        if ( boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::static_factory_ptr == (boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,boost::mpl::na,boost::mpl::na,boost::mpl::na> *)-24LL ) /*0x14113d3da*/
          p_node_count = 80; /*0x14113d3e2*/
        else
          p_node_count = (__int64)&boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::static_factory_ptr->cont.node_count; /*0x14113d3dc*/
        --*(_QWORD *)p_node_count; /*0x14113d3e7*/
        v33 = (__int64)&h[1].x.x.b2b.asSizet[1]; /*0x14113d3ed*/
        if ( h == nullptr ) /*0x14113d3f1*/
        {
          v33 = 8; /*0x14113d3f3*/
          v31 = 0; /*0x14113d3f9*/
        }
        v34 = *(__int64 ***)(*(_QWORD *)v31 + 8LL); /*0x14113d400*/
        v35 = *(__int64 **)v33; /*0x14113d404*/
        v36 = **(_QWORD **)v33; /*0x14113d407*/
        if ( v34 == (__int64 **)v31 ) /*0x14113d40d*/
        {
          *(_QWORD *)(*(_QWORD *)v31 + 8LL) = v35; /*0x14113d4e0*/
          if ( v36 != v31 ) /*0x14113d4e7*/
          {
            v37 = **(__int64 ***)v33; /*0x14113d4f0*/
            goto LABEL_52; /*0x14113d4f3*/
          }
        }
        else
        {
          if ( v36 != v31 ) /*0x14113d416*/
          {
            *v34 = nullptr; /*0x14113d418*/
            *(_QWORD *)(*(_QWORD *)v31 + 8LL) = *(_QWORD *)v33; /*0x14113d421*/
            v37 = **(__int64 ***)v33; /*0x14113d428*/
LABEL_52:
            *v37 = *(_QWORD *)v31; /*0x14113d433*/
            Myres = h->x.x.contents._Mypair._Myval2._Myres; /*0x14113d439*/
            if ( Myres >= 0x10 ) /*0x14113d441*/
            {
              v39 = h->x.x.contents._Mypair._Myval2._Bx._Ptr; /*0x14113d443*/
              if ( Myres + 1 >= 0x1000 ) /*0x14113d451*/
              {
                if ( (unsigned __int64)&v39[-*((_QWORD *)v39 - 1) - 8] > 0x1F ) /*0x14113d466*/
                  _invalid_parameter_noinfo_noreturn(); /*0x14113d4f8*/
                v39 = *((char **)v39 - 1); /*0x14113d46c*/
              }
              operator delete(ptr: v39); /*0x14113d46f*/
            }
            h->x.x.contents._Mypair._Myval2._Mysize = 0; /*0x14113d474*/
            h->x.x.contents._Mypair._Myval2._Myres = 15; /*0x14113d478*/
            h->x.x.contents._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14113d480*/
            operator delete(ptr: (void *)h); /*0x14113d48c*/
            goto LABEL_58; /*0x14113d48c*/
          }
          *v34 = v35; /*0x14113d42d*/
        }
        v37 = *(__int64 **)v33; /*0x14113d430*/
        goto LABEL_52; /*0x14113d430*/
      }
LABEL_61:
      v40 = Myfirst; /*0x14113d4ad*/
      if ( (((char *)sharedStringInfo._Mypair._Myval2._Myend - (char *)Myfirst) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x14113d4c2*/
      {
        Myfirst = *(RBX::SharedString **)&Myfirst[-1].readCount; /*0x14113d4c8*/
        if ( (unsigned __int64)((char *)v40 - (char *)Myfirst - 8) > 0x1F ) /*0x14113d4d7*/
          _invalid_parameter_noinfo_noreturn(); /*0x14113d4d9*/
      }
      operator delete(ptr: Myfirst); /*0x14113d502*/
      v8 = classEvent; /*0x14113d507*/
    }
    numberOfBytesUsed = v45; /*0x14113d50e*/
  }
  __unwind
  {
    __std_terminate(a1: v20, a2: &v42); /*0x142f39fa8*/
  }
LABEL_69:
  if ( DFFlag::DetailedBandwidthStatsInflux2.value ) /*0x14113d519*/
    RBX::Network::OngoingBandwidthStats::recordEventInvocation( /*0x14113d52e*/
      this: &replicator->outboundBandwidthStats,
      evt: v8->localDescriptor,
      wireSize: bitStream->numberOfBytesUsed - numberOfBytesUsed);
  return 1; /*0x14113d535*/
}

// END EventInvocationItem part 1/1, 6 functions
