// EAIVDeserializedNewInstanceItem -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x14104d000 | Name: ??$emplace_impl@AEAIVDeserializedNewInstanceItem@Network@RBX@@@?$table_impl@U?$map@V?$allocator@U?$pair@$$CBIVDeserializedNewInstanceItem@Network@RBX@@@std@@@std@@IVDeserializedNewInstanceItem@Network@RBX@@U?$hash@I@boost@@U?$equal_to@I@2@@detail@unordered@boost@@@detail@unordered@boost@@QEAA?AU?$pair@U?$iterator@U?$ptr_node@U?$pair@$$CBIVDeserializedNewInstanceItem@Network@RBX@@@std@@@detail@unordered@boost@@@iterator_detail@unordered@boost@@_N@std@@AEBIAEAI$$QEAVDeserializedNewInstanceItem@Network@RBX@@@Z
std::pair<boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<unsigned int const ,RBX::Network::DeserializedNewInstanceItem> > >,bool> *__fastcall boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<unsigned int const,RBX::Network::DeserializedNewInstanceItem>>,unsigned int,RBX::Network::DeserializedNewInstanceItem,boost::hash<unsigned int>,std::equal_to<unsigned int>>>::emplace_impl<unsigned int &,RBX::Network::DeserializedNewInstanceItem>(
        boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<unsigned int const ,RBX::Network::DeserializedNewInstanceItem> >,unsigned int,RBX::Network::DeserializedNewInstanceItem,boost::hash<unsigned int>,std::equal_to<unsigned int> > > *this,
        std::pair<boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<unsigned int const ,RBX::Network::DeserializedNewInstanceItem> > >,bool> *result,
        const unsigned int *k,
        unsigned int *<args_0>,
        RBX::Network::DeserializedNewInstanceItem *<args_1>)
{
  unsigned __int64 v8; // rsi
  unsigned __int64 *p_bucket_count; // r15
  unsigned __int64 bucket_count; // r10
  boost::unordered::detail::ptr_bucket *next; // rcx
  std::allocator<boost::unordered::detail::ptr_node<std::pair<unsigned int const ,RBX::Network::DeserializedNewInstanceItem> > > *v12; // rcx
  char *v13; // rdi
  unsigned __int64 size; // r9
  unsigned __int64 v15; // r8
  unsigned __int64 *v16; // rdx
  __int64 v17; // rdx
  unsigned __int64 v18; // rax
  boost::unordered::detail::ptr_bucket *v19; // r9
  boost::unordered::detail::ptr_bucket *i; // rcx
  boost::unordered::detail::ptr_bucket *v21; // r8
  unsigned __int64 v22; // r9
  boost::unordered::detail::ptr_bucket *buckets; // r10
  boost::unordered::detail::ptr_bucket *v24; // r8
  boost::unordered::detail::ptr_bucket *v25; // rcx
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<unsigned int const ,RBX::Network::DeserializedNewInstanceItem> > > > a; // [rsp+20h] [rbp-48h] BYREF
  unsigned __int64 v28; // [rsp+70h] [rbp+8h] BYREF

  v8 = *k; /*0x14104d01f*/
  p_bucket_count = &this->bucket_count_; /*0x14104d022*/
  bucket_count = this->bucket_count_; /*0x14104d026*/
  if ( this->size_ != 0 ) /*0x14104d038*/
  {
    next = this->buckets_[v8 % bucket_count].next_; /*0x14104d03e*/
    if ( next != nullptr ) /*0x14104d045*/
    {
      while ( 1 ) /*0x14104d047*/
      {
        next = next->next_; /*0x14104d047*/
        if ( next == nullptr ) /*0x14104d04d*/
          break; /*0x14104d04d*/
        if ( (boost::unordered::detail::ptr_bucket *)v8 == next[1].next_ ) /*0x14104d056*/
        {
          if ( (_DWORD)v8 == LODWORD(next[2].next_) ) /*0x14104d05b*/
          {
            result->first.node_ = (boost::unordered::detail::ptr_node<std::pair<unsigned int const ,RBX::Network::DeserializedNewInstanceItem> > *)next; /*0x14104d062*/
            result->second = false; /*0x14104d065*/
            return result; /*0x14104d06a*/
          }
        }
        else if ( (unsigned __int64)next[1].next_ % bucket_count != v8 % bucket_count ) /*0x14104d077*/
        {
          break; /*0x14104d077*/
        }
      }
    }
  }
  v12 = (std::allocator<boost::unordered::detail::ptr_node<std::pair<unsigned int const ,RBX::Network::DeserializedNewInstanceItem> > > *)(&this->allocators_ + 1); /*0x14104d079*/
  if ( this == (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<unsigned int const ,RBX::Network::DeserializedNewInstanceItem> >,unsigned int,RBX::Network::DeserializedNewInstanceItem,boost::hash<unsigned int>,std::equal_to<unsigned int> > > *)-3LL ) /*0x14104d087*/
    v12 = nullptr; /*0x14104d087*/
  a.alloc_ = v12; /*0x14104d08b*/
  a.node_ = nullptr; /*0x14104d090*/
  *(_WORD *)&a.node_constructed_ = 0; /*0x14104d095*/
  __wind /*0xf1c0000000000010*/
  {
    v13 = (char *)operator new(size: 0xA8u); /*0x14104d0a5*/
    a.node_ = (boost::unordered::detail::ptr_node<std::pair<unsigned int const ,RBX::Network::DeserializedNewInstanceItem> > *)v13; /*0x14104d0a8*/
    *(_QWORD *)v13 = 0; /*0x14104d0ad*/
    *((_QWORD *)v13 + 1) = 0; /*0x14104d0b0*/
    *((_OWORD *)v13 + 1) = 0; /*0x14104d0b9*/
    *((_OWORD *)v13 + 2) = 0; /*0x14104d0bd*/
    *((_OWORD *)v13 + 3) = 0; /*0x14104d0c1*/
    *((_OWORD *)v13 + 4) = 0; /*0x14104d0c5*/
    *((_OWORD *)v13 + 5) = 0; /*0x14104d0c9*/
    *((_OWORD *)v13 + 6) = 0; /*0x14104d0cd*/
    *((_OWORD *)v13 + 7) = 0; /*0x14104d0d1*/
    *((_OWORD *)v13 + 8) = 0; /*0x14104d0d5*/
    *((_OWORD *)v13 + 9) = 0; /*0x14104d0dc*/
    *((_QWORD *)v13 + 20) = 0; /*0x14104d0e3*/
    a.node_constructed_ = true; /*0x14104d0ea*/
    *((_DWORD *)v13 + 4) = *<args_0>; /*0x14104d0f2*/
    RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem( /*0x14104d101*/
      this: (RBX::Network::DeserializedNewInstanceItem *)(v13 + 24),
      __that: <args_1>);
    a.value_constructed_ = true; /*0x14104d106*/
    size = this->size_; /*0x14104d10b*/
    v15 = size + 1; /*0x14104d10f*/
    if ( this->buckets_ != nullptr ) /*0x14104d117*/
    {
      if ( v15 > this->max_load_ ) /*0x14104d149*/
      {
        v17 = 1; /*0x14104d159*/
        if ( v15 < size + (size >> 1) ) /*0x14104d161*/
          v17 = size >> 1; /*0x14104d161*/
        v18 = boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<__int64 const,std::shared_ptr<std::vector<std::shared_ptr<RBX::Instance>> const>>>,__int64,std::shared_ptr<std::vector<std::shared_ptr<RBX::Instance>> const>,boost::hash<__int64>,std::equal_to<__int64>>>::min_buckets_for_size( /*0x14104d16b*/
                (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<__int64 const ,UserFriend> >,__int64,UserFriend,boost::hash<__int64>,std::equal_to<__int64> > > *)this,
                size: size + v17);
        if ( v18 != *p_bucket_count ) /*0x14104d173*/
        {
          boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::SharedString>>,std::string,RBX::SharedString,boost::hash<std::string>,std::equal_to<std::string>>>::create_buckets( /*0x14104d17b*/
            (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const ,ForumPost> >,std::string,ForumPost,boost::hash<std::string >,std::equal_to<std::string > > > *)this,
            new_count: v18);
          v19 = &this->buckets_[*p_bucket_count]; /*0x14104d187*/
          for ( i = v19->next_; v19->next_ != nullptr; i = v19->next_ ) /*0x14104d191*/
          {
            v21 = &this->buckets_[(unsigned __int64)i[1].next_ % *p_bucket_count]; /*0x14104d1a0*/
            if ( v21->next_ != nullptr ) /*0x14104d1a8*/
            {
              v19->next_ = i->next_; /*0x14104d1b5*/
              i->next_ = v21->next_->next_; /*0x14104d1be*/
              v21->next_->next_ = i; /*0x14104d1c4*/
            }
            else
            {
              v21->next_ = v19; /*0x14104d1aa*/
              v19 = i; /*0x14104d1ad*/
            }
          }
        }
      }
    }
    else
    {
      v28 = boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<__int64 const,std::shared_ptr<std::vector<std::shared_ptr<RBX::Instance>> const>>>,__int64,std::shared_ptr<std::vector<std::shared_ptr<RBX::Instance>> const>,boost::hash<__int64>,std::equal_to<__int64>>>::min_buckets_for_size( /*0x14104d124*/
              (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<__int64 const ,UserFriend> >,__int64,UserFriend,boost::hash<__int64>,std::equal_to<__int64> > > *)this,
              size: size + 1);
      v16 = &v28; /*0x14104d129*/
      if ( *p_bucket_count >= v28 ) /*0x14104d131*/
        v16 = p_bucket_count; /*0x14104d131*/
      boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::SharedString>>,std::string,RBX::SharedString,boost::hash<std::string>,std::equal_to<std::string>>>::create_buckets( /*0x14104d13b*/
        (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const ,ForumPost> >,std::string,ForumPost,boost::hash<std::string >,std::equal_to<std::string > > > *)this,
        new_count: *v16);
    }
    *((_QWORD *)v13 + 1) = v8; /*0x14104d1cf*/
    v22 = *p_bucket_count; /*0x14104d1d3*/
    buckets = this->buckets_; /*0x14104d1d6*/
    v24 = &buckets[v8 % *p_bucket_count]; /*0x14104d1e2*/
    if ( v24->next_ != nullptr ) /*0x14104d1ec*/
    {
      *(_QWORD *)v13 = v24->next_->next_; /*0x14104d218*/
      v24->next_->next_ = (boost::unordered::detail::ptr_bucket *)v13; /*0x14104d21e*/
    }
    else
    {
      v25 = &buckets[v22]; /*0x14104d1ee*/
      if ( v25->next_ != nullptr ) /*0x14104d1f8*/
        buckets[(unsigned __int64)v25->next_[1].next_ % v22].next_ = (boost::unordered::detail::ptr_bucket *)v13; /*0x14104d203*/
      v24->next_ = v25; /*0x14104d207*/
      *(boost::unordered::detail::ptr_bucket *)v13 = (boost::unordered::detail::ptr_bucket)v25->next_; /*0x14104d20d*/
      v25->next_ = (boost::unordered::detail::ptr_bucket *)v13; /*0x14104d210*/
    }
    ++this->size_; /*0x14104d221*/
    result->first.node_ = (boost::unordered::detail::ptr_node<std::pair<unsigned int const ,RBX::Network::DeserializedNewInstanceItem> > *)v13; /*0x14104d225*/
    result->second = true; /*0x14104d228*/
  }
  __unwind
  {
    boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<unsigned int const,RBX::Network::DeserializedNewInstanceItem>>>>::~node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<unsigned int const,RBX::Network::DeserializedNewInstanceItem>>>>(this: &a); /*0xf1c0000000000008*/
  }
  return result; /*0x14104d230*/
}

// END EAIVDeserializedNewInstanceItem part 1/1, 1 functions
