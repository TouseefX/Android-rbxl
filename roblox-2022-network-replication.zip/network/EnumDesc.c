// EnumDesc -- 2022 Studio + full PDB
// tier 3, 5 functions


// Address: 0x14100b220 | Name: ?convertIntValueToTypedVariantIfValidValue@?$EnumDesc@W4FilterResult@Network@RBX@@@Reflection@RBX@@UEBAXHAEAVVariant@23@@Z
void __fastcall RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::convertIntValueToTypedVariantIfValidValue(
        RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *this,
        int intValue,
        RBX::Reflection::Variant *variant)
{
  const RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *v4; // rax
  __int64 v5; // rcx
  const rbx::implementation::type_holder *holder; // rax
  RBX::Network::FilterResult value; // [rsp+48h] [rbp+20h] BYREF

  if ( RBX::Reflection::EnumDescriptor::mapIntValue(this, intValue, (int *)&value) ) /*0x14100b22e*/
  {
    v4 = RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::singleton(); /*0x14100b23c*/
    v5 = (unsigned int)tls_index; /*0x14100b241*/
    variant->_type = v4; /*0x14100b247*/
    if ( __TSS0__1__singleton___typed_holder_W4FilterResult_Network_RBX___implementation_rbx__SAPEBV234_XZ_4HA > *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + v5) + 260LL) ) /*0x14100b265*/
    {
      Init_thread_header(pOnce: &__TSS0__1__singleton___typed_holder_W4FilterResult_Network_RBX___implementation_rbx__SAPEBV234_XZ_4HA); /*0x14100b2a0*/
      if ( __TSS0__1__singleton___typed_holder_W4FilterResult_Network_RBX___implementation_rbx__SAPEBV234_XZ_4HA == -1 ) /*0x14100b2ac*/
      {
        `rbx::implementation::typed_holder<enum RBX::Network::FilterResult>::singleton'::`2'::s = (__int64)rbx::implementation::typed_holder<enum RBX::CharacterMesh::BodyPart>::construct_func; /*0x14100b2b5*/
        qword_14557A6F8 = (__int64)rbx::implementation::typed_holder<enum RBX::CharacterMesh::BodyPart>::construct_func; /*0x14100b2ca*/
        qword_14557A700 = (__int64)RBX::LSP::ILSPEditor::onSignalQuiescenceResponse; /*0x14100b2d8*/
        Init_thread_footer(pOnce: &__TSS0__1__singleton___typed_holder_W4FilterResult_Network_RBX___implementation_rbx__SAPEBV234_XZ_4HA); /*0x14100b2df*/
      }
    }
    holder = variant->value.holder; /*0x14100b267*/
    if ( holder != (const rbx::implementation::type_holder *)&`rbx::implementation::typed_holder<enum RBX::Network::FilterResult>::singleton'::`2'::s ) /*0x14100b275*/
    {
      if ( holder != nullptr ) /*0x14100b27a*/
        holder->destruct(a1: variant->value.data); /*0x14100b280*/
      variant->value.holder = (const rbx::implementation::type_holder *)&`rbx::implementation::typed_holder<enum RBX::Network::FilterResult>::singleton'::`2'::s; /*0x14100b283*/
    }
    *(_DWORD *)variant->value.data = value; /*0x14100b290*/
  }
}

// Address: 0x14100b750 | Name: ?convertTypedVariantToIntValue@?$EnumDesc@W4FilterResult@Network@RBX@@@Reflection@RBX@@UEBAXAEBVVariant@23@AEAH@Z
void __fastcall RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::convertTypedVariantToIntValue(
        RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *this,
        const RBX::Reflection::Variant *variant,
        int *value)
{
  const RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *type; // rbx
  char *data; // rax

  type = (const RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *)variant->_type; /*0x14100b75f*/
  if ( type != RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::singleton() ) /*0x14100b770*/
    RBX::throw_runtime_error(fmt: "Variant cast failed"); /*0x14100b79b*/
  data = variant->value.data; /*0x14100b777*/
  if ( variant->value.holder == nullptr ) /*0x14100b781*/
    data = nullptr; /*0x14100b781*/
  *value = *(_DWORD *)data; /*0x14100b787*/
}

// Address: 0x14100c490 | Name: ?lookupByEnumValueInVariant@?$EnumDesc@W4FilterResult@Network@RBX@@@Reflection@RBX@@UEBAPEBVItem@EnumDescriptor@23@AEBVVariant@23@@Z
const RBX::Reflection::EnumDescriptor::Item *__fastcall RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::lookupByEnumValueInVariant(
        RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *this,
        const RBX::Reflection::Variant *value)
{
  const RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *type; // rbx
  int *data; // rax

  type = (const RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *)value->_type; /*0x14100c49f*/
  if ( type != RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::singleton() ) /*0x14100c4b0*/
    RBX::throw_runtime_error(fmt: "Variant cast failed"); /*0x14100c4e0*/
  data = (int *)value->value.data; /*0x14100c4b4*/
  if ( value->value.holder == nullptr ) /*0x14100c4bc*/
    data = nullptr; /*0x14100c4bc*/
  return RBX::Reflection::EnumDescriptor::_convertToItem(this, intValue: *data); /*0x14100c4c5*/
}

// Address: 0x14100c850 | Name: ?singleton@?$EnumDesc@W4FilterResult@Network@RBX@@@Reflection@RBX@@SAAEBV123@XZ
const RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *__fastcall RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::singleton()
{
  const RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *result; // rax

  if ( __TSS0__1__singleton___EnumDesc_W4FilterResult_Network_RBX___Reflection_RBX__SAAEBV234_XZ_4HA <= *(_DWORD *)(*((_QWORD *)NtCurrentTeb()->Reserved1[11] + (unsigned int)tls_index) + 260LL) ) /*0x14100c877*/
    return &`RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::singleton'::`2'::obj; /*0x14100c877*/
  Init_thread_header(pOnce: &__TSS0__1__singleton___EnumDesc_W4FilterResult_Network_RBX___Reflection_RBX__SAAEBV234_XZ_4HA); /*0x14100c88d*/
  if ( __TSS0__1__singleton___EnumDesc_W4FilterResult_Network_RBX___Reflection_RBX__SAAEBV234_XZ_4HA != -1 ) /*0x14100c899*/
    return &`RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::singleton'::`2'::obj; /*0x14100c879*/
  __wind /*0xf1c000000000001c*/
  {
    RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::EnumDesc<enum RBX::Network::FilterResult>(this: &`RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::singleton'::`2'::obj); /*0x14100c8a5*/
    atexit(function: `RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::singleton'::`2'::`dynamic atexit destructor for 'obj''); /*0x14100c8b1*/
    Init_thread_footer(pOnce: &__TSS0__1__singleton___EnumDesc_W4FilterResult_Network_RBX___Reflection_RBX__SAAEBV234_XZ_4HA); /*0x14100c8be*/
    result = &`RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::singleton'::`2'::obj; /*0x14100c8c3*/
  }
  __unwind
  {
    Init_thread_abort(pOnce: &__TSS0__1__singleton___EnumDesc_W4FilterResult_Network_RBX___Reflection_RBX__SAAEBV234_XZ_4HA); /*0x1431e5157*/
  }
  return result; /*0x14100c880*/
}

// Address: 0x1410a87f0 | Name: ??0?$EnumDesc@W4FilterResult@Network@RBX@@@Reflection@RBX@@AEAA@XZ
RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *__fastcall RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::EnumDesc<enum RBX::Network::FilterResult>(
        RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult> *this)
{
  RBX::Reflection::EnumDescriptor::EnumDescriptor(this, typeName: "FilterResult"); /*0x1410a8804*/
  this->__vftable = (RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>_vtbl *)RBX::Reflection::EnumDesc<enum RBX::Network::FilterResult>::`vftable'; /*0x1410a8811*/
  RBX::Reflection::EnumDescriptor::_addPairs(this, ep: &enums_5, count: 2); /*0x1410a8824*/
  return this; /*0x1410a882d*/
}

// END EnumDesc part 1/1, 5 functions
