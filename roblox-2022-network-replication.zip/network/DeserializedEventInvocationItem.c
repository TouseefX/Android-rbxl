// DeserializedEventInvocationItem -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x14113c170 | Name: ?process@DeserializedEventInvocationItem@Network@RBX@@UEAA?AW4ProcessResult@DeserializedItem@23@AEAVReplicator@23@@Z
__int64 __fastcall RBX::Network::DeserializedEventInvocationItem::process(
        RBX::Network::DeserializedEventInvocationItem *this,
        RBX::Network::Replicator *replicator)
{
  __int64 result; // rax

  result = ((__int64 (__fastcall *)(RBX::Instance *, const RBX::Reflection::EventDescriptor *, RBX::RemoteInvocationMetadata *, _QWORD))this->instance._Ptr->filterEventInvocation)( /*0x14113c196*/
             a1: this->instance._Ptr,
             a2: this->eventDescriptor,
             a3: &this->remoteMetaData,
             a4: replicator->remotePlayerAddress.remoteId.peerId);
  if ( (_DWORD)result != 1 ) /*0x14113c19f*/
    return 2 - (unsigned int)(RBX::Network::Replicator::readEventInvocationItem(this: replicator, item: this) != 0); /*0x14113c1c0*/
  return result; /*0x14113c1a1*/
}

// END DeserializedEventInvocationItem part 1/1, 1 functions
