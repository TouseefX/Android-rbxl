// EventDesc -- 2022 Studio + full PDB
// tier 3, 4 functions


// Address: 0x140616790 | Name: ?fireEvent@?$EventDesc@VClientReplicator@Network@RBX@@$$A6AX_NV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@ZV?$signal@$$A6AX_NV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z@rbx@@PEQ123@V67@@Reflection@RBX@@QEBAXPEAVClientReplicator@Network@3@_NV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RBX::Reflection::EventDesc<RBX::Network::ClientReplicator,void (bool,std::string),rbx::signal<void (bool,std::string)>,rbx::signal<void (bool,std::string)> RBX::Network::ClientReplicator::*>::fireEvent(
        RBX::Reflection::EventDesc<RBX::Network::ClientReplicator,void __cdecl(bool,std::string),rbx::signal<void __cdecl(bool,std::string)>,rbx::signal<void __cdecl(bool,std::string)> RBX::Network::ClientReplicator::*> *this,
        RBX::Network::ClientReplicator *instance,
        bool <args_0>,
        RBX::Graphics::ProfilerAdorn::Item *<args_1>)
{
  rbx::signal<void __cdecl(bool,std::string)> *v5; // rcx
  unsigned __int64 Myres; // rdx
  char *Ptr; // rcx
  std::string text; // [rsp+20h] [rbp-28h] BYREF

  v5 = (rbx::signal<void __cdecl(bool,std::string)> *)((char *)instance + (int)this->getter); /*0x1406167a5*/
  text = <args_1>->text; /*0x1406167ac*/
  <args_1>->text._Mypair._Myval2._Mysize = 0; /*0x1406167bb*/
  <args_1>->text._Mypair._Myval2._Myres = 15; /*0x1406167c3*/
  <args_1>->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x1406167cb*/
  __wind /*0xf1c0000000000010*/
  {
    rbx::signal<void (bool,std::string)>::operator()(this: v5, <args_0>, <args_1>: &text); /*0x1406167d7*/
    Myres = <args_1>->text._Mypair._Myval2._Myres; /*0x1406167dd*/
    if ( Myres >= 0x10 ) /*0x1406167e5*/
    {
      Ptr = <args_1>->text._Mypair._Myval2._Bx._Ptr; /*0x1406167ea*/
      if ( Myres + 1 >= 0x1000 ) /*0x1406167f4*/
      {
        if ( (unsigned __int64)&Ptr[-*((_QWORD *)Ptr - 1) - 8] > 0x1F ) /*0x140616809*/
          _invalid_parameter_noinfo_noreturn(); /*0x14061682c*/
        Ptr = *((char **)Ptr - 1); /*0x14061680b*/
      }
      operator delete(ptr: Ptr); /*0x14061680e*/
    }
    <args_1>->text._Mypair._Myval2._Mysize = 0; /*0x140616813*/
    <args_1>->text._Mypair._Myval2._Myres = 15; /*0x14061681b*/
    <args_1>->text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x140616823*/
  }
  __unwind
  {
    RBX::Graphics::ProfilerAdorn::Item::~Item(this: <args_1>); /*0xf1c0000000000008*/
  }
}

// Address: 0x141015930 | Name: ?fireEventGeneric@?$EventDesc@VClient@Network@RBX@@$$A6AXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@H0@ZV?$signal@$$A6AXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@H0@Z@rbx@@P8123@EAAPEAV67@_N@Z@Reflection@RBX@@UEBAXPEAVEventSource@23@AEBV?$vector@VVariant@Reflection@RBX@@V?$allocator@VVariant@Reflection@RBX@@@std@@@std@@@Z
void __fastcall RBX::Reflection::EventDesc<RBX::Network::Client,void (std::string,int,std::string),rbx::signal<void (std::string,int,std::string)>,rbx::signal<void (std::string,int,std::string)> * (RBX::Network::Client::*)(bool)>::fireEventGeneric(
        RBX::Reflection::EventDesc<RBX::Network::Client,void __cdecl(std::string,int,std::string),rbx::signal<void __cdecl(std::string,int,std::string)>,rbx::signal<void __cdecl(std::string,int,std::string)> * (__cdecl RBX::Network::Client::*)(bool)> *this,
        RBX::Network::Client *source,
        const std::vector<RBX::Reflection::Variant> *args)
{
  RBX::integer_sequence<unsigned __int64,0,1,2> v3; // [rsp+10h] [rbp+10h]

  RBX::Reflection::EventDesc<RBX::Network::Client,void (std::string,int,std::string),rbx::signal<void (std::string,int,std::string)>,rbx::signal<void (std::string,int,std::string)> * (RBX::Network::Client::*)(bool)>::unpackGenericEventArgs<0,1,2>( /*0x141015936*/
    this,
    instance: source,
    args,
    __formal: v3);
}

// Address: 0x141015940 | Name: ?fireEventGeneric@?$EventDesc@VClient@Network@RBX@@$$A6AXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$shared_ptr@VInstance@RBX@@@5@@ZV?$signal@$$A6AXV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$shared_ptr@VInstance@RBX@@@2@@Z@rbx@@P8123@EAAPEAV78@_N@Z@Reflection@RBX@@UEBAXPEAVEventSource@23@AEBV?$vector@VVariant@Reflection@RBX@@V?$allocator@VVariant@Reflection@RBX@@@std@@@std@@@Z
void __fastcall RBX::Reflection::EventDesc<RBX::Network::Client,void (std::string,std::shared_ptr<RBX::Instance>),rbx::signal<void (std::string,std::shared_ptr<RBX::Instance>)>,rbx::signal<void (std::string,std::shared_ptr<RBX::Instance>)> * (RBX::Network::Client::*)(bool)>::fireEventGeneric(
        RBX::Reflection::EventDesc<RBX::Network::Client,void __cdecl(std::string,std::shared_ptr<RBX::Instance>),rbx::signal<void __cdecl(std::string,std::shared_ptr<RBX::Instance>)>,rbx::signal<void __cdecl(std::string,std::shared_ptr<RBX::Instance>)> * (__cdecl RBX::Network::Client::*)(bool)> *this,
        RBX::Network::Client *source,
        const std::vector<RBX::Reflection::Variant> *args)
{
  RBX::integer_sequence<unsigned __int64,0,1> v3; // [rsp+10h] [rbp+10h]

  RBX::Reflection::EventDesc<RBX::Network::Client,void (std::string,std::shared_ptr<RBX::Instance>),rbx::signal<void (std::string,std::shared_ptr<RBX::Instance>)>,rbx::signal<void (std::string,std::shared_ptr<RBX::Instance>)> * (RBX::Network::Client::*)(bool)>::unpackGenericEventArgs<0,1>( /*0x141015946*/
    this,
    instance: source,
    args,
    __formal: v3);
}

// Address: 0x141098cb0 | Name: ?fireEventGeneric@?$EventDesc@VClientReplicator@Network@RBX@@$$A6AXV?$shared_ptr@$$CBV?$unordered_map@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@VVariant@Reflection@RBX@@U?$hash@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@U?$equal_to@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@V?$allocator@U?$pair@$$CBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@VVariant@Reflection@RBX@@@std@@@2@@std@@@std@@@ZV?$signal@$$A6AXV?$shared_ptr@$$CBV?$unordered_map@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@VVariant@Reflection@RBX@@U?$hash@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@U?$equal_to@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@V?$allocator@U?$pair@$$CBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@VVariant@Reflection@RBX@@@std@@@2@@std@@@std@@@Z@rbx@@PEQ123@V67@@Reflection@RBX@@UEBAXPEAVEventSource@23@AEBV?$vector@VVariant@Reflection@RBX@@V?$allocator@VVariant@Reflection@RBX@@@std@@@std@@@Z
void __fastcall RBX::Reflection::EventDesc<RBX::Network::ClientReplicator,void (std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>),rbx::signal<void (std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>)>,rbx::signal<void (std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>)> RBX::Network::ClientReplicator::*>::fireEventGeneric(
        RBX::Reflection::EventDesc<RBX::HumanoidDescription,void __cdecl(std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const >),rbx::signal<void __cdecl(std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const >)>,rbx::signal<void __cdecl(std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const >)> RBX::HumanoidDescription::*> *this,
        RBX::Reflection::EventSource *source,
        const std::vector<RBX::Reflection::Variant> *args)
{
  RBX::Reflection::Variant *Myfirst; // rdi
  const RBX::Reflection::Type *type; // rbx
  std::shared_ptr<RBX::File> *data; // rcx
  std::_Ref_count_base *Rep; // rax
  rbx::signal<void __cdecl(std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const >)> *v9; // rcx
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > v10; // [rsp+20h] [rbp-38h] BYREF
  std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const > v11; // [rsp+30h] [rbp-28h] BYREF

  Myfirst = args->_Mypair._Myval2._Myfirst; /*0x141098cc2*/
  type = args->_Mypair._Myval2._Myfirst->_type; /*0x141098cc5*/
  if ( type != RBX::Reflection::Type::getSingleton<std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>>() ) /*0x141098cd0*/
    RBX::throw_runtime_error(fmt: "Variant cast failed"); /*0x141098d85*/
  data = (std::shared_ptr<RBX::File> *)Myfirst->value.data; /*0x141098cd6*/
  if ( Myfirst->value.holder == nullptr ) /*0x141098ce0*/
    data = nullptr; /*0x141098ce0*/
  v10 = 0; /*0x141098ce7*/
  Rep = data->_Rep; /*0x141098ced*/
  if ( Rep != nullptr ) /*0x141098cf4*/
    _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x141098cf6*/
  __wind /*0xf1c0000000000010*/
  {
    v10 = (std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const >)*data; /*0x141098cfd*/
    v9 = (rbx::signal<void __cdecl(std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const >)> *)((char *)source + (int)this->getter); /*0x141098d19*/
    v11 = v10; /*0x141098d21*/
    v10 = 0; /*0x141098d2a*/
    rbx::signal<void (std::shared_ptr<std::unordered_map<std::string,RBX::Reflection::Variant> const>)>::operator()( /*0x141098d35*/
      this: v9,
      <args_0>: &v11);
  }
  __unwind
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&v10); /*0xf1c0000000000008*/
  }
}

// END EventDesc part 1/1, 4 functions
