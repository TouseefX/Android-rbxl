// ReplicatorStats -- 2022 Studio + full PDB
// tier 3, 12 functions


// Address: 0x14105cd10 | Name: ??1ReplicatorStats@Network@RBX@@QEAA@XZ
void __fastcall RBX::Network::ReplicatorStats::~ReplicatorStats(RBX::Network::ReplicatorStats *this, _BOOL8 a2)
{
  std::function<void __cdecl(RBX::Network::ConnectionStats const &)> *p_callback; // rbx
  std::_Func_base<void,RBX::Network::ConnectionStats const &> *v3; // rcx

  p_callback = &this->peerStats.metaData.callback; /*0x14105cd16*/
  v3 = this->peerStats.metaData.callback._Mystorage._Ptrs[7]; /*0x14105cd1d*/
  if ( v3 != nullptr ) /*0x14105cd24*/
  {
    LOBYTE(a2) = v3 != (std::_Func_base<void,RBX::Network::ConnectionStats const &> *)p_callback; /*0x14105cd2c*/
    v3->_Delete_this(this: v3, a2); /*0x14105cd2f*/
    p_callback->_Mystorage._Ptrs[7] = nullptr; /*0x14105cd32*/
  }
}

// Address: 0x141131810 | Name: ??0ReplicatorStats@Network@RBX@@QEAA@XZ
RBX::Network::ReplicatorStats *__fastcall RBX::Network::ReplicatorStats::ReplicatorStats(
        RBX::Network::ReplicatorStats *this)
{
  __int64 v2; // rdi
  __int64 v3; // rbp
  int *p_valueLastInterval; // rbx
  RBX::TotalCountTimeInterval<int,1> *dataPacketReceiveTypes; // rbx
  __int64 i; // rbp
  RBX::RunningAverage<int,double> *dataPacketSizeSentTypes; // rax
  __int64 j; // rcx
  RBX::RunningAverage<int,double> *dataPacketSizeReceiveTypes; // rax
  long double v10; // xmm6_8
  long double v11; // xmm6_8
  long double v12; // xmm6_8
  long double v13; // xmm6_8
  long double v14; // xmm6_8
  long double v15; // xmm6_8
  long double v16; // xmm6_8
  long double v17; // xmm6_8
  long double v18; // xmm6_8
  long double v19; // xmm6_8
  long double v20; // xmm0_8
  RBX::Network::TimeIntervalMeter *totalPropertyChanges; // rbx
  __int64 k; // rbp
  RBX::Network::TimeIntervalMeter *coalescedPropertyChanges; // rbx
  __int64 v24; // rdi
  std::function<void __cdecl(RBX::GImage const *,bool,bool)> v26; // [rsp+20h] [rbp-78h] BYREF

  v2 = 12; /*0x141131833*/
  v3 = 12; /*0x141131838*/
  p_valueLastInterval = &this->dataPacketSentTypes[0].valueLastInterval; /*0x14113183a*/
  do /*0x141131868*/
  {
    RBX::Time::now<1>(result: (RBX::Time *)p_valueLastInterval - 2); /*0x141131854*/
    *((_QWORD *)p_valueLastInterval - 1) = 0x3FF0000000000000LL; /*0x141131859*/
    *(_QWORD *)p_valueLastInterval = 0; /*0x14113185d*/
    p_valueLastInterval += 6; /*0x141131860*/
    --v3; /*0x141131864*/
  }
  while ( v3 != 0 ); /*0x141131868*/
  dataPacketReceiveTypes = this->dataPacketReceiveTypes; /*0x14113186a*/
  for ( i = 12; i != 0; --i ) /*0x141131871*/
  {
    RBX::Time::now<1>(result: &dataPacketReceiveTypes->timer.start); /*0x141131877*/
    dataPacketReceiveTypes->interval = 1.0; /*0x14113187c*/
    *(_QWORD *)&dataPacketReceiveTypes->valueLastInterval = 0; /*0x141131880*/
    ++dataPacketReceiveTypes; /*0x141131884*/
  }
  dataPacketSizeSentTypes = this->dataPacketSizeSentTypes; /*0x14113188e*/
  for ( j = 12; j != 0; --j ) /*0x141131895*/
  {
    dataPacketSizeSentTypes->lerp = 0.05; /*0x1411318b0*/
    dataPacketSizeSentTypes->lastSampleValue = 0; /*0x1411318b3*/
    dataPacketSizeSentTypes->averageValue = 0.0; /*0x1411318b7*/
    dataPacketSizeSentTypes->averageVariance = 0.0; /*0x1411318bb*/
    dataPacketSizeSentTypes->firstTime = true; /*0x1411318bf*/
    ++dataPacketSizeSentTypes; /*0x1411318c3*/
  }
  dataPacketSizeReceiveTypes = this->dataPacketSizeReceiveTypes; /*0x1411318cd*/
  do /*0x1411318fb*/
  {
    dataPacketSizeReceiveTypes->lerp = 0.05; /*0x1411318e0*/
    dataPacketSizeReceiveTypes->lastSampleValue = 0; /*0x1411318e3*/
    dataPacketSizeReceiveTypes->averageValue = 0.0; /*0x1411318e7*/
    dataPacketSizeReceiveTypes->averageVariance = 0.0; /*0x1411318eb*/
    dataPacketSizeReceiveTypes->firstTime = true; /*0x1411318ef*/
    ++dataPacketSizeReceiveTypes; /*0x1411318f3*/
    --v2; /*0x1411318f7*/
  }
  while ( v2 != 0 ); /*0x1411318fb*/
  v10 = RBX::Network::lerp_0; /*0x1411318fd*/
  this->kiloBytesReceivedPerSecond = RBX::Network::lerp_0; /*0x141131905*/
  RBX::Time::now<1>(result: &this->packetsReceived.timer.start); /*0x141131917*/
  this->packetsReceived.firstTime = true; /*0x14113191c*/
  this->packetsReceived.average.lerp = v10; /*0x141131920*/
  this->packetsReceived.average.lastSampleValue = 0.0; /*0x141131925*/
  this->packetsReceived.average.averageValue = 0.0; /*0x141131929*/
  this->packetsReceived.average.averageVariance = 0.0; /*0x14113192d*/
  this->packetsReceived.average.firstTime = true; /*0x141131931*/
  this->packetsReceived.ignoreTimeSinceLastSample = &RBX::Network::packetStatsHandleBursts; /*0x14113193c*/
  v11 = RBX::Network::lerp_0; /*0x141131947*/
  RBX::Time::now<1>(result: &this->dataPacketsReceived.timer.start); /*0x141131952*/
  this->dataPacketsReceived.firstTime = true; /*0x141131957*/
  this->dataPacketsReceived.average.lerp = v11; /*0x14113195b*/
  this->dataPacketsReceived.average.lastSampleValue = 0.0; /*0x141131960*/
  this->dataPacketsReceived.average.averageValue = 0.0; /*0x141131964*/
  this->dataPacketsReceived.average.averageVariance = 0.0; /*0x141131968*/
  this->dataPacketsReceived.average.firstTime = true; /*0x14113196c*/
  this->dataPacketsReceived.ignoreTimeSinceLastSample = &RBX::Network::packetStatsHandleBursts; /*0x141131970*/
  this->dataPacketsReceivedSize.lerp = 0.05; /*0x141131974*/
  this->dataPacketsReceivedSize.lastSampleValue = 0.0; /*0x14113197b*/
  this->dataPacketsReceivedSize.averageValue = 0.0; /*0x141131982*/
  this->dataPacketsReceivedSize.averageVariance = 0.0; /*0x141131989*/
  this->dataPacketsReceivedSize.firstTime = true; /*0x141131990*/
  v12 = RBX::Network::lerp_0; /*0x14113199e*/
  RBX::Time::now<1>(result: &this->physicsPacketsReceived.timer.start); /*0x1411319a9*/
  this->physicsPacketsReceived.firstTime = true; /*0x1411319ae*/
  this->physicsPacketsReceived.average.lerp = v12; /*0x1411319b2*/
  this->physicsPacketsReceived.average.lastSampleValue = 0.0; /*0x1411319b7*/
  this->physicsPacketsReceived.average.averageValue = 0.0; /*0x1411319bb*/
  this->physicsPacketsReceived.average.averageVariance = 0.0; /*0x1411319bf*/
  this->physicsPacketsReceived.average.firstTime = true; /*0x1411319c3*/
  this->physicsPacketsReceived.ignoreTimeSinceLastSample = &RBX::Network::packetStatsHandleBursts; /*0x1411319c7*/
  this->physicsPacketsReceivedSize.lerp = 0.05; /*0x1411319cb*/
  this->physicsPacketsReceivedSize.lastSampleValue = 0.0; /*0x1411319d2*/
  this->physicsPacketsReceivedSize.averageValue = 0.0; /*0x1411319d9*/
  this->physicsPacketsReceivedSize.averageVariance = 0.0; /*0x1411319e0*/
  this->physicsPacketsReceivedSize.firstTime = true; /*0x1411319e7*/
  v13 = RBX::Network::lerp_0; /*0x1411319f5*/
  RBX::Time::now<1>(result: &this->clusterPacketsReceived.timer.start); /*0x141131a00*/
  this->clusterPacketsReceived.firstTime = true; /*0x141131a05*/
  this->clusterPacketsReceived.average.lerp = v13; /*0x141131a09*/
  this->clusterPacketsReceived.average.lastSampleValue = 0.0; /*0x141131a0e*/
  this->clusterPacketsReceived.average.averageValue = 0.0; /*0x141131a12*/
  this->clusterPacketsReceived.average.averageVariance = 0.0; /*0x141131a16*/
  this->clusterPacketsReceived.average.firstTime = true; /*0x141131a1a*/
  this->clusterPacketsReceived.ignoreTimeSinceLastSample = &RBX::Network::packetStatsHandleBursts; /*0x141131a1e*/
  this->clusterPacketsReceivedSize.lerp = 0.05; /*0x141131a22*/
  this->clusterPacketsReceivedSize.lastSampleValue = 0.0; /*0x141131a29*/
  this->clusterPacketsReceivedSize.averageValue = 0.0; /*0x141131a30*/
  this->clusterPacketsReceivedSize.averageVariance = 0.0; /*0x141131a37*/
  this->clusterPacketsReceivedSize.firstTime = true; /*0x141131a3e*/
  v14 = RBX::Network::lerp_0; /*0x141131a4c*/
  RBX::Time::now<1>(result: &this->touchPacketsReceived.timer.start); /*0x141131a57*/
  this->touchPacketsReceived.firstTime = true; /*0x141131a5c*/
  this->touchPacketsReceived.average.lerp = v14; /*0x141131a60*/
  this->touchPacketsReceived.average.lastSampleValue = 0.0; /*0x141131a65*/
  this->touchPacketsReceived.average.averageValue = 0.0; /*0x141131a69*/
  this->touchPacketsReceived.average.averageVariance = 0.0; /*0x141131a6d*/
  this->touchPacketsReceived.average.firstTime = true; /*0x141131a71*/
  this->touchPacketsReceived.ignoreTimeSinceLastSample = nullptr; /*0x141131a75*/
  v15 = RBX::Network::lerp_0; /*0x141131a79*/
  this->touchPacketsReceivedSize.lerp = RBX::Network::lerp_0; /*0x141131a81*/
  this->touchPacketsReceivedSize.lastSampleValue = 0.0; /*0x141131a89*/
  this->touchPacketsReceivedSize.averageValue = 0.0; /*0x141131a90*/
  this->touchPacketsReceivedSize.averageVariance = 0.0; /*0x141131a97*/
  this->touchPacketsReceivedSize.firstTime = true; /*0x141131a9e*/
  this->kiloBytesSentPerSecond = v15; /*0x141131aa5*/
  this->bufferHealth = 1.0; /*0x141131aad*/
  RBX::Time::now<1>(result: &this->dataPacketsSent.timer.start); /*0x141131abe*/
  this->dataPacketsSent.firstTime = true; /*0x141131ac3*/
  this->dataPacketsSent.average.lerp = v15; /*0x141131ac7*/
  this->dataPacketsSent.average.lastSampleValue = 0.0; /*0x141131acc*/
  this->dataPacketsSent.average.averageValue = 0.0; /*0x141131ad0*/
  this->dataPacketsSent.average.averageVariance = 0.0; /*0x141131ad4*/
  this->dataPacketsSent.average.firstTime = true; /*0x141131ad8*/
  this->dataPacketsSent.ignoreTimeSinceLastSample = &RBX::Network::packetStatsHandleBursts; /*0x141131adc*/
  this->dataPacketSendThrottle.lerp = 0.05; /*0x141131ae0*/
  this->dataPacketSendThrottle.lastSampleValue = 0.0; /*0x141131ae7*/
  this->dataPacketSendThrottle.averageValue = 0.0; /*0x141131aee*/
  this->dataPacketSendThrottle.averageVariance = 0.0; /*0x141131af5*/
  this->dataPacketSendThrottle.firstTime = true; /*0x141131afc*/
  this->dataPacketsSentSize.lerp = RBX::Network::lerp_0; /*0x141131b0b*/
  this->dataPacketsSentSize.lastSampleValue = 0; /*0x141131b13*/
  this->dataPacketsSentSize.averageValue = 0.0; /*0x141131b1a*/
  this->dataPacketsSentSize.averageVariance = 0.0; /*0x141131b21*/
  this->dataPacketsSentSize.firstTime = true; /*0x141131b28*/
  this->dataTimeInQueue.lerp = 0.05; /*0x141131b2f*/
  this->dataTimeInQueue.lastSampleValue = 0.0; /*0x141131b36*/
  this->dataTimeInQueue.averageValue = 0.0; /*0x141131b3d*/
  this->dataTimeInQueue.averageVariance = 0.0; /*0x141131b44*/
  this->dataTimeInQueue.firstTime = true; /*0x141131b4b*/
  this->dataTimeInAllQueues.lerp = 0.05; /*0x141131b52*/
  this->dataTimeInAllQueues.lastSampleValue = 0.0; /*0x141131b59*/
  this->dataTimeInAllQueues.averageValue = 0.0; /*0x141131b60*/
  this->dataTimeInAllQueues.averageVariance = 0.0; /*0x141131b67*/
  this->dataTimeInAllQueues.firstTime = true; /*0x141131b6e*/
  RBX::Time::now<1>(result: &this->dataNewItemsPerSec.timer.start); /*0x141131b7c*/
  this->dataNewItemsPerSec.interval = 1.0; /*0x141131b81*/
  *(_QWORD *)&this->dataNewItemsPerSec.valueLastInterval = 0; /*0x141131b88*/
  RBX::Time::now<1>(result: &this->dataItemsSentPerSec.timer.start); /*0x141131b96*/
  this->dataItemsSentPerSec.interval = 1.0; /*0x141131b9b*/
  *(_QWORD *)&this->dataItemsSentPerSec.valueLastInterval = 0; /*0x141131ba2*/
  v16 = RBX::Network::lerp_0; /*0x141131bb0*/
  RBX::Time::now<1>(result: &this->clusterPacketsSent.timer.start); /*0x141131bbb*/
  this->clusterPacketsSent.firstTime = true; /*0x141131bc0*/
  this->clusterPacketsSent.average.lerp = v16; /*0x141131bc4*/
  this->clusterPacketsSent.average.lastSampleValue = 0.0; /*0x141131bc9*/
  this->clusterPacketsSent.average.averageValue = 0.0; /*0x141131bcd*/
  this->clusterPacketsSent.average.averageVariance = 0.0; /*0x141131bd1*/
  this->clusterPacketsSent.average.firstTime = true; /*0x141131bd5*/
  this->clusterPacketsSent.ignoreTimeSinceLastSample = &RBX::Network::packetStatsHandleBursts; /*0x141131bd9*/
  this->clusterPacketsSentSize.lerp = RBX::Network::lerp_0; /*0x141131be5*/
  this->clusterPacketsSentSize.lastSampleValue = 0; /*0x141131bed*/
  this->clusterPacketsSentSize.averageValue = 0.0; /*0x141131bf4*/
  this->clusterPacketsSentSize.averageVariance = 0.0; /*0x141131bfb*/
  this->clusterPacketsSentSize.firstTime = true; /*0x141131c02*/
  this->dataPing.lerp = 0.25; /*0x141131c13*/
  this->dataPing.lastSampleValue = 0; /*0x141131c1a*/
  this->dataPing.averageValue = 0.0; /*0x141131c21*/
  this->dataPing.averageVariance = 0.0; /*0x141131c28*/
  this->dataPing.firstTime = true; /*0x141131c2f*/
  this->dataPingMax = 0; /*0x141131c36*/
  this->dataPingMin = 1000000; /*0x141131c3d*/
  this->rakPing.lerp = 0.25; /*0x141131c47*/
  this->rakPing.lastSampleValue = 0; /*0x141131c4e*/
  this->rakPing.averageValue = 0.0; /*0x141131c55*/
  this->rakPing.averageVariance = 0.0; /*0x141131c5c*/
  this->rakPing.firstTime = true; /*0x141131c63*/
  this->rakPingMax = 0; /*0x141131c6a*/
  *(_QWORD *)&this->rakPingMin = 1000000; /*0x141131c71*/
  this->lastSampledRakNetTotalBytesReceived = 0; /*0x141131c7c*/
  RBX::Time::now<0>(result: &this->lastRakNetBandwidthSampleTime); /*0x141131c8a*/
  v17 = RBX::Network::lerp_0; /*0x141131c96*/
  RBX::Time::now<1>(result: &this->physicsSenderStats.physicsPacketsSent.timer.start); /*0x141131ca1*/
  this->physicsSenderStats.physicsPacketsSent.firstTime = true; /*0x141131ca6*/
  this->physicsSenderStats.physicsPacketsSent.average.lerp = v17; /*0x141131caa*/
  this->physicsSenderStats.physicsPacketsSent.average.lastSampleValue = 0.0; /*0x141131caf*/
  this->physicsSenderStats.physicsPacketsSent.average.averageValue = 0.0; /*0x141131cb3*/
  this->physicsSenderStats.physicsPacketsSent.average.averageVariance = 0.0; /*0x141131cb7*/
  this->physicsSenderStats.physicsPacketsSent.average.firstTime = true; /*0x141131cbb*/
  this->physicsSenderStats.physicsPacketsSent.ignoreTimeSinceLastSample = nullptr; /*0x141131cbf*/
  v18 = RBX::Network::lerp_smooth; /*0x141131cc3*/
  RBX::Time::now<1>(result: &this->physicsSenderStats.physicsPacketsSentSmooth.timer.start); /*0x141131ccf*/
  this->physicsSenderStats.physicsPacketsSentSmooth.firstTime = true; /*0x141131cd4*/
  this->physicsSenderStats.physicsPacketsSentSmooth.average.lerp = v18; /*0x141131cd8*/
  this->physicsSenderStats.physicsPacketsSentSmooth.average.lastSampleValue = 0.0; /*0x141131cdd*/
  this->physicsSenderStats.physicsPacketsSentSmooth.average.averageValue = 0.0; /*0x141131ce1*/
  this->physicsSenderStats.physicsPacketsSentSmooth.average.averageVariance = 0.0; /*0x141131ce5*/
  this->physicsSenderStats.physicsPacketsSentSmooth.average.firstTime = true; /*0x141131ce9*/
  this->physicsSenderStats.physicsPacketsSentSmooth.ignoreTimeSinceLastSample = nullptr; /*0x141131ced*/
  this->physicsSenderStats.physicsSentThrottle.lerp = 0.05; /*0x141131cf1*/
  this->physicsSenderStats.physicsSentThrottle.lastSampleValue = 0.0; /*0x141131cf8*/
  this->physicsSenderStats.physicsSentThrottle.averageValue = 0.0; /*0x141131cff*/
  this->physicsSenderStats.physicsSentThrottle.averageVariance = 0.0; /*0x141131d06*/
  this->physicsSenderStats.physicsSentThrottle.firstTime = true; /*0x141131d0d*/
  v19 = RBX::Network::lerp_0; /*0x141131d14*/
  this->physicsSenderStats.physicsPacketsSentSize.lerp = RBX::Network::lerp_0; /*0x141131d1c*/
  this->physicsSenderStats.physicsPacketsSentSize.lastSampleValue = 0; /*0x141131d24*/
  this->physicsSenderStats.physicsPacketsSentSize.averageValue = 0.0; /*0x141131d2b*/
  this->physicsSenderStats.physicsPacketsSentSize.averageVariance = 0.0; /*0x141131d32*/
  this->physicsSenderStats.physicsPacketsSentSize.firstTime = true; /*0x141131d39*/
  this->physicsSenderStats.physicsItemsPerPacket.lerp = 0.05; /*0x141131d40*/
  this->physicsSenderStats.physicsItemsPerPacket.lastSampleValue = 0; /*0x141131d47*/
  this->physicsSenderStats.physicsItemsPerPacket.averageValue = 0.0; /*0x141131d4e*/
  this->physicsSenderStats.physicsItemsPerPacket.averageVariance = 0.0; /*0x141131d55*/
  this->physicsSenderStats.physicsItemsPerPacket.firstTime = true; /*0x141131d5c*/
  RBX::Time::now<1>(result: &this->physicsSenderStats.touchPacketsSent.timer.start); /*0x141131d6d*/
  this->physicsSenderStats.touchPacketsSent.firstTime = true; /*0x141131d72*/
  this->physicsSenderStats.touchPacketsSent.average.lerp = v19; /*0x141131d76*/
  this->physicsSenderStats.touchPacketsSent.average.lastSampleValue = 0.0; /*0x141131d7b*/
  this->physicsSenderStats.touchPacketsSent.average.averageValue = 0.0; /*0x141131d7f*/
  this->physicsSenderStats.touchPacketsSent.average.averageVariance = 0.0; /*0x141131d83*/
  this->physicsSenderStats.touchPacketsSent.average.firstTime = true; /*0x141131d87*/
  this->physicsSenderStats.touchPacketsSent.ignoreTimeSinceLastSample = nullptr; /*0x141131d8b*/
  v20 = RBX::Network::lerp_0; /*0x141131d8f*/
  this->physicsSenderStats.touchPacketsSentSize.lerp = RBX::Network::lerp_0; /*0x141131d97*/
  this->physicsSenderStats.touchPacketsSentSize.lastSampleValue = 0; /*0x141131d9f*/
  this->physicsSenderStats.touchPacketsSentSize.averageValue = 0.0; /*0x141131da6*/
  this->physicsSenderStats.touchPacketsSentSize.averageVariance = 0.0; /*0x141131dad*/
  this->physicsSenderStats.touchPacketsSentSize.firstTime = true; /*0x141131db4*/
  this->physicsSenderStats.waitingTouches.lerp = v20; /*0x141131dbb*/
  this->physicsSenderStats.waitingTouches.lastSampleValue = 0; /*0x141131dc3*/
  this->physicsSenderStats.waitingTouches.averageValue = 0.0; /*0x141131dca*/
  this->physicsSenderStats.waitingTouches.averageVariance = 0.0; /*0x141131dd1*/
  this->physicsSenderStats.waitingTouches.firstTime = true; /*0x141131dd8*/
  RBX::Network::ReplicatorStats::PhysicsPacketDetailedStats::PhysicsPacketDetailedStats(this: &this->physicsSenderStats.details); /*0x141131de6*/
  this->physicsReceiverStats.physicsReceiverAverageLag.lerp = 0.05; /*0x141131deb*/
  this->physicsReceiverStats.physicsReceiverAverageLag.lastSampleValue = 0.0; /*0x141131df2*/
  this->physicsReceiverStats.physicsReceiverAverageLag.averageValue = 0.0; /*0x141131df9*/
  this->physicsReceiverStats.physicsReceiverAverageLag.averageVariance = 0.0; /*0x141131e00*/
  this->physicsReceiverStats.physicsReceiverAverageLag.firstTime = true; /*0x141131e07*/
  this->physicsReceiverStats.simulationToFrameBufferAverageLatency.lerp = 0.05; /*0x141131e0e*/
  this->physicsReceiverStats.simulationToFrameBufferAverageLatency.lastSampleValue = 0.0; /*0x141131e15*/
  this->physicsReceiverStats.simulationToFrameBufferAverageLatency.averageValue = 0.0; /*0x141131e1c*/
  this->physicsReceiverStats.simulationToFrameBufferAverageLatency.averageVariance = 0.0; /*0x141131e23*/
  this->physicsReceiverStats.simulationToFrameBufferAverageLatency.firstTime = true; /*0x141131e2a*/
  RBX::Network::ReplicatorStats::PhysicsPacketDetailedStats::PhysicsPacketDetailedStats(this: &this->physicsReceiverStats.details); /*0x141131e38*/
  *(_QWORD *)&this->dataPingBreakdownStats.localQueueToSerializeTime = 0; /*0x141131e3d*/
  *(_QWORD *)&this->dataPingBreakdownStats.localLastKnownRakNetPing = 0; /*0x141131e44*/
  *(_QWORD *)&this->dataPingBreakdownStats.remoteAppPopToDeserializeTime = 0; /*0x141131e4b*/
  *(_QWORD *)&this->dataPingBreakdownStats.remoteQueueToSerializeTime = 0; /*0x141131e52*/
  *(_QWORD *)&this->dataPingBreakdownStats.localRakNetRecvToAppPopTime = 0; /*0x141131e59*/
  this->dataPingBreakdownStats.localDeserializeTimeToProcessTime = 0; /*0x141131e60*/
  v26._Mystorage._Ptrs[7] = nullptr; /*0x141131e6e*/
  RBX::Network::ConnectionStats::ConnectionStats(this: &this->peerStats, raknetindex: -1, call: &v26); /*0x141131e7d*/
  __wind /*0xf1c000000000001c*/
  {
    this->lastReceivedPingTime = (unsigned int)RakNet::GetTimeMS(); /*0x141131e8a*/
    this->lastReceivedHashTime = (unsigned int)RakNet::GetTimeMS(); /*0x141131e98*/
    this->lastReceivedMccTime = (unsigned int)RakNet::GetTimeMS(); /*0x141131ea6*/
    this->lastPingCheckTime = (unsigned int)RakNet::GetTimeMS(); /*0x141131eb4*/
    this->lastPossibleBotTransitionTime.sec = 0.0; /*0x141131ebb*/
    this->totalPossibleBotTime.sec = 0.0; /*0x141131ec2*/
    *(_QWORD *)&this->lastBitsSent = 0; /*0x141131ec9*/
    this->lastItem = ItemTypeEnd; /*0x141131ed0*/
    this->lastPacketType = -1; /*0x141131ed7*/
    RBX::Time::nowFast(result: &this->startTime); /*0x141131ee8*/
    this->avgMccTime.lerp = 0.25; /*0x141131eed*/
    this->avgMccTime.lastSampleValue = 0; /*0x141131ef4*/
    this->avgMccTime.averageValue = 0.0; /*0x141131efb*/
    this->avgMccTime.averageVariance = 0.0; /*0x141131f02*/
    this->avgMccTime.firstTime = true; /*0x141131f09*/
    this->maxMccTime = 0; /*0x141131f10*/
    this->minMccTime = 1000000; /*0x141131f17*/
    this->avgHashTime.lerp = 0.25; /*0x141131f21*/
    this->avgHashTime.lastSampleValue = 0; /*0x141131f28*/
    this->avgHashTime.averageValue = 0.0; /*0x141131f2f*/
    this->avgHashTime.averageVariance = 0.0; /*0x141131f36*/
    this->avgHashTime.firstTime = true; /*0x141131f3d*/
    this->maxHashTime = 0; /*0x141131f44*/
    this->minHashTime = 1000000; /*0x141131f4b*/
    this->avgPingTime.lerp = 0.25; /*0x141131f55*/
    this->avgPingTime.lastSampleValue = 0; /*0x141131f5c*/
    this->avgPingTime.averageValue = 0.0; /*0x141131f63*/
    this->avgPingTime.averageVariance = 0.0; /*0x141131f6a*/
    this->avgPingTime.firstTime = true; /*0x141131f71*/
    this->maxPingTime = 0; /*0x141131f78*/
    this->minPingTime = 1000000; /*0x141131f7f*/
    totalPropertyChanges = this->totalPropertyChanges; /*0x141131f89*/
    v24 = 55; /*0x141131f90*/
    for ( k = 55; k != 0; --k ) /*0x141131f95*/
      RBX::Network::TimeIntervalMeter::TimeIntervalMeter(this: totalPropertyChanges++); /*0x141131f9a*/
    coalescedPropertyChanges = this->coalescedPropertyChanges; /*0x141131fa9*/
    do /*0x141131fc0*/
    {
      RBX::Network::TimeIntervalMeter::TimeIntervalMeter(this: coalescedPropertyChanges++); /*0x141131fb3*/
      --v24; /*0x141131fbc*/
    }
    while ( v24 != 0 ); /*0x141131fc0*/
    this->maxCoalesceIntervalMs = 0.0; /*0x141131fc2*/
    RBX::Network::TimeIntervalMeter::TimeIntervalMeter(this: &this->newInstanceCoalescedChanges); /*0x141131fd0*/
    *(_QWORD *)&this->lastKnownPacketReceivedToPopTime = 0; /*0x141131fd5*/
    this->avgPacketDeserializeWaitTimeMs.lerp = 0.05; /*0x141131fdc*/
    this->avgPacketDeserializeWaitTimeMs.lastSampleValue = 0; /*0x141131fe3*/
    this->avgPacketDeserializeWaitTimeMs.averageValue = 0.0; /*0x141131fea*/
    this->avgPacketDeserializeWaitTimeMs.averageVariance = 0.0; /*0x141131ff1*/
    this->avgPacketDeserializeWaitTimeMs.firstTime = true; /*0x141131ff8*/
    this->avgPacketProcessWaitTimeMs.lerp = 0.05; /*0x141131fff*/
    this->avgPacketProcessWaitTimeMs.lastSampleValue = 0; /*0x141132006*/
    this->avgPacketProcessWaitTimeMs.averageValue = 0.0; /*0x14113200d*/
    this->avgPacketProcessWaitTimeMs.averageVariance = 0.0; /*0x141132014*/
    this->avgPacketProcessWaitTimeMs.firstTime = true; /*0x14113201b*/
  }
  __unwind
  {
    std::_Binder<std::_Unforced,void (RBX::MockMarketplaceApiClient::*)(std::string const &,std::function<void (std::string)>),RBX::MockMarketplaceApiClient *,std::_Ph<1> const &,std::function<void (std::string)> &>::~_Binder<std::_Unforced,void (RBX::MockMarketplaceApiClient::*)(std::string const &,std::function<void (std::string)>),RBX::MockMarketplaceApiClient *,std::_Ph<1> const &,std::function<void (std::string)> &>(this: (boost::_bi::storage3<boost::_bi::value<RBX::MockMarketplaceApiClient *>,boost::arg<1>,boost::_bi::value<std::function<void __cdecl(bool)> > > *)&this->peerStats); /*0x1431f0a4e*/
  }
  return this; /*0x141132025*/
}

// Address: 0x141132500 | Name: ?incrementPacketsReceived@ReplicatorStats@Network@RBX@@QEAAXW4PacketType@123@@Z
void __fastcall RBX::Network::ReplicatorStats::incrementPacketsReceived(RBX::Network::ReplicatorStats *this, int type)
{
  __int64 v3; // rdi
  RBX::Time result; // [rsp+30h] [rbp+8h] BYREF

  v3 = type + 12LL; /*0x141132519*/
  if ( RBX::Time::now<1>(&result)->sec - this->dataPacketReceiveTypes[type].timer.start.sec >= this->dataPacketReceiveTypes[type].interval ) /*0x141132531*/
  {
    *(_QWORD *)&this->dataPacketSentTypes[v3].valueLastInterval = (unsigned int)this->dataPacketSentTypes[v3].valueCurrentInterval; /*0x14113253c*/
    RBX::Time::now<1>(&result); /*0x141132548*/
    this->dataPacketSentTypes[v3].timer.start = result; /*0x141132553*/
  }
  ++this->dataPacketSentTypes[v3].valueCurrentInterval; /*0x141132558*/
}

// Address: 0x141132570 | Name: ?incrementPacketsSent@ReplicatorStats@Network@RBX@@QEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@Z
void __fastcall RBX::Network::ReplicatorStats::incrementPacketsSent(
        RBX::Network::ReplicatorStats *this,
        const std::string *categoryName)
{
  unsigned __int64 Myres; // r15
  const void **v3; // rdi
  size_t Mysize; // rbp
  unsigned int v7; // ebx
  _BYTE *v8; // rdx
  __int64 v9; // rax
  const std::string *Ptr; // rcx
  __int64 v11; // rbx
  RBX::Time result; // [rsp+50h] [rbp+18h] BYREF

  Myres = categoryName->_Mypair._Myval2._Myres; /*0x141132588*/
  v3 = (const void **)RBX::Network::ReplicatorStats::kPacketTypeNames; /*0x14113258c*/
  Mysize = categoryName->_Mypair._Myval2._Mysize; /*0x141132593*/
  v7 = 0; /*0x14113259d*/
  while ( 1 ) /*0x1411325a0*/
  {
    v8 = *v3; /*0x1411325a0*/
    v9 = -1; /*0x1411325a3*/
    do /*0x1411325b7*/
      ++v9; /*0x1411325b0*/
    while ( v8[v9] != 0 ); /*0x1411325b7*/
    Ptr = categoryName; /*0x1411325b9*/
    if ( Myres >= 0x10 ) /*0x1411325c0*/
      Ptr = (const std::string *)categoryName->_Mypair._Myval2._Bx._Ptr; /*0x1411325c2*/
    if ( Mysize == v9 && memcmp_0(Buf1: Ptr, Buf2: v8, Size: Mysize) == 0 ) /*0x1411325d4*/
      break; /*0x1411325d4*/
    ++v7; /*0x1411325d6*/
    ++v3; /*0x1411325d8*/
    if ( v7 >= 0xC ) /*0x1411325df*/
      return; /*0x1411325df*/
  }
  v11 = (int)v7; /*0x1411325eb*/
  if ( RBX::Time::now<1>(&result)->sec - this->dataPacketSentTypes[v11].timer.start.sec >= this->dataPacketSentTypes[v11].interval ) /*0x141132603*/
  {
    *(_QWORD *)&this->dataPacketSentTypes[v11].valueLastInterval = (unsigned int)this->dataPacketSentTypes[v11].valueCurrentInterval; /*0x14113260e*/
    RBX::Time::now<1>(&result); /*0x14113261a*/
    this->dataPacketSentTypes[v11].timer.start = result; /*0x141132625*/
  }
  ++this->dataPacketSentTypes[v11].valueCurrentInterval; /*0x14113262a*/
}

// Address: 0x141132650 | Name: ?incrementPacketsSent@ReplicatorStats@Network@RBX@@QEAAXW4PacketType@123@@Z
void __fastcall RBX::Network::ReplicatorStats::incrementPacketsSent(
        RBX::Network::ReplicatorStats *this,
        RBX::Network::ReplicatorStats::PacketType type)
{
  __int64 v3; // rdi
  RBX::Time result; // [rsp+30h] [rbp+8h] BYREF

  v3 = type; /*0x141132665*/
  if ( RBX::Time::now<1>(&result)->sec - this->dataPacketSentTypes[type].timer.start.sec >= this->dataPacketSentTypes[type].interval ) /*0x14113267d*/
  {
    *(_QWORD *)&this->dataPacketSentTypes[v3].valueLastInterval = (unsigned int)this->dataPacketSentTypes[v3].valueCurrentInterval; /*0x141132688*/
    RBX::Time::now<1>(&result); /*0x141132694*/
    this->dataPacketSentTypes[v3].timer.start = result; /*0x14113269f*/
  }
  ++this->dataPacketSentTypes[v3].valueCurrentInterval; /*0x1411326a4*/
}

// Address: 0x1411326c0 | Name: ?recordPropertyChange@ReplicatorStats@Network@RBX@@QEAAXW4NetworkValueFormat@23@@Z
void __fastcall RBX::Network::ReplicatorStats::recordPropertyChange(
        RBX::Network::ReplicatorStats *this,
        unsigned __int8 valueFormat)
{
  ++this->totalPropertyChanges[valueFormat].count; /*0x1411326cc*/
}

// Address: 0x1411326e0 | Name: ?recordPropertyCoalesceWithInstance@ReplicatorStats@Network@RBX@@QEAAXW4NetworkValueFormat@23@@Z
void __fastcall RBX::Network::ReplicatorStats::recordPropertyCoalesceWithInstance(
        RBX::Network::ReplicatorStats *this,
        unsigned __int8 valueFormat)
{
  ++this->totalPropertyChanges[valueFormat].count; /*0x1411326ec*/
  ++this->newInstanceCoalescedChanges.count; /*0x1411326f0*/
}

// Address: 0x141132700 | Name: ?recordPropertyCoalesceWithProperty@ReplicatorStats@Network@RBX@@QEAAXW4NetworkValueFormat@23@N@Z
void __fastcall RBX::Network::ReplicatorStats::recordPropertyCoalesceWithProperty(
        RBX::Network::ReplicatorStats *this,
        unsigned __int8 valueFormat,
        long double interval)
{
  ++this->totalPropertyChanges[valueFormat].count; /*0x14113270e*/
  ++this->coalescedPropertyChanges[valueFormat].count; /*0x14113271c*/
  if ( interval > this->maxCoalesceIntervalMs ) /*0x141132728*/
    this->maxCoalesceIntervalMs = interval; /*0x14113272a*/
}

// Address: 0x141132740 | Name: ?resetSecurityTimes@ReplicatorStats@Network@RBX@@QEAAXXZ
void __fastcall RBX::Network::ReplicatorStats::resetSecurityTimes(RBX::Network::ReplicatorStats *this)
{
  unsigned int TimeMS; // eax

  TimeMS = RakNet::GetTimeMS(); /*0x14113274e*/
  this->lastReceivedPingTime = TimeMS; /*0x141132750*/
  this->lastReceivedHashTime = TimeMS; /*0x141132757*/
  this->lastReceivedMccTime = TimeMS; /*0x14113275e*/
}

// Address: 0x141132770 | Name: ?samplePacketsReceived@ReplicatorStats@Network@RBX@@QEAAXW4PacketType@123@H@Z
void __fastcall RBX::Network::ReplicatorStats::samplePacketsReceived(
        RBX::Network::ReplicatorStats *this,
        RBX::Network::ReplicatorStats::PacketType type,
        int size)
{
  RBX::RunningAverage<int,double>::sample(this: &this->dataPacketSizeReceiveTypes[type], value: size); /*0x141132785*/
}

// Address: 0x141132790 | Name: ?samplePacketsSent@ReplicatorStats@Network@RBX@@QEAAXAEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@H@Z
void __fastcall RBX::Network::ReplicatorStats::samplePacketsSent(
        RBX::Network::ReplicatorStats *this,
        const std::string *categoryName,
        int size)
{
  unsigned __int64 Myres; // r14
  const void **v4; // rdi
  size_t Mysize; // rbp
  unsigned int v9; // ebx
  _BYTE *v10; // rdx
  __int64 v11; // rax
  const std::string *Ptr; // rcx

  Myres = categoryName->_Mypair._Myval2._Myres; /*0x1411327ae*/
  v4 = (const void **)RBX::Network::ReplicatorStats::kPacketTypeNames; /*0x1411327b2*/
  Mysize = categoryName->_Mypair._Myval2._Mysize; /*0x1411327b9*/
  v9 = 0; /*0x1411327c6*/
  while ( 1 ) /*0x1411327d0*/
  {
    v10 = *v4; /*0x1411327d0*/
    v11 = -1; /*0x1411327d3*/
    do /*0x1411327e7*/
      ++v11; /*0x1411327e0*/
    while ( v10[v11] != 0 ); /*0x1411327e7*/
    Ptr = categoryName; /*0x1411327e9*/
    if ( Myres >= 0x10 ) /*0x1411327f0*/
      Ptr = (const std::string *)categoryName->_Mypair._Myval2._Bx._Ptr; /*0x1411327f2*/
    if ( Mysize == v11 && memcmp_0(Buf1: Ptr, Buf2: v10, Size: Mysize) == 0 ) /*0x141132804*/
      break; /*0x141132804*/
    ++v9; /*0x141132806*/
    ++v4; /*0x141132808*/
    if ( v9 >= 0xC ) /*0x14113280f*/
      return; /*0x14113280f*/
  }
  RBX::RunningAverage<int,double>::sample( /*0x141132825*/
    this: (RBX::RunningAverage<int,double> *)((char *)this->dataPacketSizeSentTypes + 32 * (int)v9 + 8 * (int)v9),
    value: size);
}

// Address: 0x141132850 | Name: ?samplePacketsSent@ReplicatorStats@Network@RBX@@QEAAXW4PacketType@123@H@Z
void __fastcall RBX::Network::ReplicatorStats::samplePacketsSent(
        RBX::Network::ReplicatorStats *this,
        RBX::Network::ReplicatorStats::PacketType type,
        int size)
{
  RBX::RunningAverage<int,double>::sample(this: &this->dataPacketSizeSentTypes[type], value: size); /*0x141132865*/
}

// END ReplicatorStats part 1/1, 12 functions
