// DeserializedChangePropertyItem -- 2022 Studio + full PDB
// tier 3, 1 functions


// Address: 0x14113a290 | Name: ?process@DeserializedChangePropertyItem@Network@RBX@@UEAA?AW4ProcessResult@DeserializedItem@23@AEAVReplicator@23@@Z
__int64 __fastcall RBX::Network::DeserializedChangePropertyItem::process(
        RBX::Network::DeserializedChangePropertyItem *this,
        RBX::Network::Replicator *replicator)
{
  RBX::Network::Replicator::readChangedPropertyItem(this: replicator, item: this); /*0x14113a29d*/
  return 1; /*0x14113a2a7*/
}

// END DeserializedChangePropertyItem part 1/1, 1 functions
