// DeserializedNewInstanceItem -- 2022 Studio + full PDB
// tier 3, 8 functions


// Address: 0x14104b020 | Name: ??$_Emplace_reallocate@VDeserializedNewInstanceItem@Network@RBX@@@?$vector@VDeserializedNewInstanceItem@Network@RBX@@V?$allocator@VDeserializedNewInstanceItem@Network@RBX@@@std@@@std@@QEAAPEAVDeserializedNewInstanceItem@Network@RBX@@QEAV234@$$QEAV234@@Z
RBX::Network::DeserializedNewInstanceItem *__fastcall std::vector<RBX::Network::DeserializedNewInstanceItem>::_Emplace_reallocate<RBX::Network::DeserializedNewInstanceItem>(
        std::vector<RBX::Network::DeserializedNewInstanceItem> *this,
        RBX::Network::DeserializedNewInstanceItem *const _Whereptr,
        RBX::Network::DeserializedNewInstanceItem *<_Val_0>)
{
  __int64 v6; // rbx
  signed __int64 v7; // rdx
  unsigned __int64 v8; // r8
  unsigned __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  unsigned __int64 v11; // r15
  unsigned __int64 v12; // rcx
  std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *v13; // rax
  RBX::Network::DeserializedNewInstanceItem *v14; // rsi
  RBX::Network::DeserializedNewInstanceItem *v15; // rbx
  RBX::Network::DeserializedNewInstanceItem *v16; // rdi
  RBX::Network::DeserializedNewInstanceItem *Mylast; // r12
  RBX::Network::DeserializedNewInstanceItem *Myfirst; // rbx
  RBX::Network::DeserializedNewInstanceItem *v19; // rdi
  RBX::Network::DeserializedNewInstanceItem *Myend; // rbx
  RBX::Network::DeserializedNewInstanceItem *v21; // rdi
  signed __int64 v23; // [rsp+20h] [rbp-78h]
  RBX::Network::DeserializedNewInstanceItem *v24; // [rsp+28h] [rbp-70h]
  RBX::Network::DeserializedNewInstanceItem *_Constructed_last; // [rsp+30h] [rbp-68h]
  std::_Uninitialized_backout_al<std::allocator<RBX::Network::DeserializedNewInstanceItem> > v27; // [rsp+48h] [rbp-50h] BYREF
  RBX::Network::DeserializedNewInstanceItem *_Constructed_first; // [rsp+A8h] [rbp+10h]
  unsigned __int64 _Newcapacity; // [rsp+B8h] [rbp+20h]

  v6 = _Whereptr - this->_Mypair._Myval2._Myfirst; /*0x14104b069*/
  v7 = this->_Mypair._Myval2._Mylast - this->_Mypair._Myval2._Myfirst; /*0x14104b084*/
  if ( v7 == 0x1C71C71C71C71C7LL ) /*0x14104b094*/
    std::vector<Luau::AstNode *>::_Xlength(); /*0x14104b2c5*/
  v8 = v7 + 1; /*0x14104b09a*/
  v23 = v7 + 1; /*0x14104b09e*/
  v9 = this->_Mypair._Myval2._Myend - this->_Mypair._Myval2._Myfirst; /*0x14104b0bb*/
  v10 = v9 >> 1; /*0x14104b0c1*/
  if ( v9 <= 0x1C71C71C71C71C7LL - (v9 >> 1) ) /*0x14104b0cd*/
  {
    v11 = v8; /*0x14104b0d7*/
    if ( v10 + v9 >= v8 ) /*0x14104b0dd*/
      v11 = v10 + v9; /*0x14104b0dd*/
    if ( v11 <= 0x1C71C71C71C71C7LL ) /*0x14104b0e4*/
    {
      v12 = 144 * v11; /*0x14104b0ee*/
      _Newcapacity = v11; /*0x14104b0f2*/
      if ( 144 * v11 < 0x1000 ) /*0x14104b101*/
      {
        if ( v12 != 0 ) /*0x14104b132*/
          v14 = (RBX::Network::DeserializedNewInstanceItem *)operator new(size: v12); /*0x14104b139*/
        else
          v14 = nullptr; /*0x14104b13e*/
        _Newcapacity = v11; /*0x14104b140*/
        goto LABEL_14; /*0x14104b140*/
      }
      if ( v12 + 39 >= v12 ) /*0x14104b10a*/
      {
        v13 = (std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *)operator new(size: v12 + 39); /*0x14104b113*/
        if ( v13 == nullptr ) /*0x14104b11b*/
          goto LABEL_29; /*0x14104b11b*/
        v14 = (RBX::Network::DeserializedNewInstanceItem *)(((unsigned __int64)&v13[2].first.index + 3) /*0x14104b125*/
                                                          & 0xFFFFFFFFFFFFFFE0uLL);
        v14[-1].unresolvedInstanceReferences._Mypair._Myval2._Myend = v13; /*0x14104b129*/
LABEL_14:
        v15 = &v14[v6]; /*0x14104b148*/
        v24 = v15; /*0x14104b158*/
        v16 = v15 + 1; /*0x14104b15d*/
        _Constructed_last = v15 + 1; /*0x14104b164*/
        try /*0xf1c0000000000038*/
        {
          RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem(this: v15, __that: <_Val_0>); /*0x14104b177*/
          _Constructed_first = v15; /*0x14104b17c*/
          Mylast = this->_Mypair._Myval2._Mylast; /*0x14104b184*/
          Myfirst = this->_Mypair._Myval2._Myfirst; /*0x14104b188*/
          if ( _Whereptr == Mylast ) /*0x14104b18e*/
          {
            v27._First = v14; /*0x14104b190*/
            v19 = v14; /*0x14104b195*/
            v27._Last = v14; /*0x14104b198*/
            v27._Al = (std::allocator<RBX::Network::DeserializedNewInstanceItem> *)this; /*0x14104b19d*/
            __wind /*0xf1c000000000002c*/
            {
              while ( Myfirst != Mylast ) /*0x14104b1a5*/
              {
                RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem(this: v19++, __that: Myfirst); /*0x14104b1ad*/
                v27._Last = v19; /*0x14104b1b9*/
                ++Myfirst; /*0x14104b1be*/
              }
            }
            __unwind
            {
              std::_Uninitialized_backout_al<std::allocator<RBX::Network::DeserializedNewInstanceItem>>::~_Uninitialized_backout_al<std::allocator<RBX::Network::DeserializedNewInstanceItem>>(this: &v27); /*0xf1c0000000000024*/
            }
          }
          else
          {
            std::vector<RBX::Network::DeserializedNewInstanceItem>::_Umove( /*0x14104b1d5*/
              this,
              _First: this->_Mypair._Myval2._Myfirst,
              _Last: _Whereptr,
              _Dest: v14);
            _Constructed_first = v14; /*0x14104b1da*/
            std::vector<RBX::Network::DeserializedNewInstanceItem>::_Umove( /*0x14104b1ef*/
              this,
              _First: _Whereptr,
              _Last: this->_Mypair._Myval2._Mylast,
              _Dest: v16);
          }
        }
        catch ( ... )
        {
          std::vector<RBX::Network::DeserializedNewInstanceItem>::_Destroy( /*0x1431e833f*/
            this,
            _First: _Constructed_first,
            _Last: _Constructed_last);
          std::allocator<RBX::PostMidPhaseBuffer>::deallocate( /*0x1431e8353*/
            (std::allocator<webm::Element<webm::ChapterAtom> > *)this,
            _Ptr: (webm::Element<webm::ChapterAtom> *const)v14,
            _Count: _Newcapacity);
          throw; /*0x1431e835c*/
        }
        Myend = this->_Mypair._Myval2._Myfirst; /*0x14104b1f5*/
        if ( this->_Mypair._Myval2._Myfirst != nullptr ) /*0x14104b1fb*/
        {
          v21 = this->_Mypair._Myval2._Mylast; /*0x14104b201*/
          if ( Myend != v21 ) /*0x14104b208*/
          {
            do /*0x14104b225*/
            {
              ((void (__fastcall *)(RBX::Network::DeserializedNewInstanceItem *, _QWORD))Myend->dtr_DeserializedItem)( /*0x14104b218*/
                a1: Myend,
                a2: 0);
              ++Myend; /*0x14104b21b*/
            }
            while ( Myend != v21 ); /*0x14104b225*/
            Myend = this->_Mypair._Myval2._Myfirst; /*0x14104b227*/
          }
          if ( (unsigned __int64)(144 * (this->_Mypair._Myval2._Myend - Myend)) < 0x1000 ) /*0x14104b25b*/
            goto LABEL_27; /*0x14104b25b*/
          if ( (unsigned __int64)((char *)Myend /*0x14104b270*/
                                - (char *)Myend[-1].unresolvedInstanceReferences._Mypair._Myval2._Myend
                                - 8) <= 0x1F )
          {
            Myend = (RBX::Network::DeserializedNewInstanceItem *)Myend[-1].unresolvedInstanceReferences._Mypair._Myval2._Myend; /*0x14104b272*/
LABEL_27:
            operator delete(ptr: Myend); /*0x14104b275*/
            goto LABEL_28; /*0x14104b278*/
          }
LABEL_29:
          _invalid_parameter_noinfo_noreturn(); /*0x14104b2b8*/
        }
LABEL_28:
        this->_Mypair._Myval2._Myfirst = v14; /*0x14104b27d*/
        this->_Mypair._Myval2._Mylast = &v14[v23]; /*0x14104b290*/
        this->_Mypair._Myval2._Myend = &v14[v11]; /*0x14104b29f*/
        return v24; /*0x14104b2a8*/
      }
    }
  }
  std::_Throw_bad_array_new_length(); /*0x14104b2bf*/
}

// Address: 0x141058200 | Name: ??0DeserializedNewInstanceItem@Network@RBX@@QEAA@AEBV012@@Z
RBX::Network::DeserializedNewInstanceItem *__fastcall RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem(
        RBX::Network::DeserializedNewInstanceItem *this,
        const RBX::Network::DeserializedNewInstanceItem *__that)
{
  std::vector<RBX::Network::PropValuePair> *p_propValueList; // r15
  std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *v5; // rbp
  RBX::Network::PropValuePair *Myfirst; // rdi
  RBX::Network::PropValuePair *Mylast; // r12
  unsigned __int64 v8; // rdx
  unsigned __int64 v9; // rbx
  void *v10; // rax
  void *v11; // rcx
  RBX::Network::PropValuePair *v12; // rax
  void (__fastcall **holder)(__int64, __int64); // rax
  RBX::Network::PropValuePair *v14; // rbx
  rbx::placement_any<RBX::Reflection::Variant::Storage> *p_value; // rdi
  std::_Ref_count_base *Rep; // rax
  std::_Ref_count_base *v17; // rax
  std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *v18; // rbx
  std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *v19; // r14
  unsigned __int64 v20; // rdi
  unsigned __int64 v21; // rdi
  const RBX::Reflection::PropertyDescriptor *v22; // rax
  std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *v23; // rax
  std::_Uninitialized_backout_al<std::allocator<RBX::Network::PropValuePair> > v25; // [rsp+20h] [rbp-48h] BYREF
  std::_Tidy_guard<std::vector<RBX::Network::PropValuePair> > v27; // [rsp+78h] [rbp+10h] BYREF

  __wind /*0xf1c000000000009c*/
  {
    this->__vftable = (RBX::Network::DeserializedNewInstanceItem_vtbl *)RBX::Network::DeserializedItem::`vftable'; /*0x141058228*/
    this->analyticsItemType = __that->analyticsItemType; /*0x14105822e*/
    this->analyticsLogicalCount = __that->analyticsLogicalCount; /*0x141058234*/
    this->analyticsWireSize = __that->analyticsWireSize; /*0x14105823a*/
    this->__vftable = (RBX::Network::DeserializedNewInstanceItem_vtbl *)RBX::Network::DeserializedNewInstanceItem::`vftable'; /*0x141058244*/
    p_propValueList = &this->propValueList; /*0x141058247*/
    v5 = nullptr; /*0x14105824b*/
    this->propValueList._Mypair._Myval2._Myfirst = nullptr; /*0x14105824d*/
    this->propValueList._Mypair._Myval2._Mylast = nullptr; /*0x141058250*/
    this->propValueList._Mypair._Myval2._Myend = nullptr; /*0x141058254*/
    Myfirst = __that->propValueList._Mypair._Myval2._Myfirst; /*0x141058258*/
    Mylast = __that->propValueList._Mypair._Myval2._Mylast; /*0x14105825c*/
    if ( Myfirst == Mylast ) /*0x141058263*/
      goto LABEL_42; /*0x141058263*/
    v8 = Mylast - Myfirst; /*0x141058287*/
    if ( v8 <= 0x2AAAAAAAAAAAAAALL ) /*0x141058297*/
    {
      v9 = 96 * v8; /*0x1410582a1*/
      if ( 96 * v8 < 0x1000 ) /*0x1410582ac*/
      {
        if ( v9 != 0 ) /*0x1410582e0*/
          v12 = (RBX::Network::PropValuePair *)operator new(size: 96 * v8); /*0x1410582e5*/
        else
          v12 = nullptr; /*0x1410582ec*/
LABEL_12:
        p_propValueList->_Mypair._Myval2._Myfirst = v12; /*0x1410582ef*/
        p_propValueList->_Mypair._Myval2._Mylast = v12; /*0x1410582f2*/
        p_propValueList->_Mypair._Myval2._Myend = &v12[v9 / 0x60]; /*0x1410582f9*/
        v27._Target = p_propValueList; /*0x1410582fd*/
        __wind /*0xf1c0000000000090*/
        {
          v14 = p_propValueList->_Mypair._Myval2._Myfirst; /*0x141058302*/
          v25._First = v14; /*0x141058305*/
          v25._Last = v14; /*0x14105830a*/
          v25._Al = (std::allocator<RBX::Network::PropValuePair> *)p_propValueList; /*0x14105830f*/
          p_value = &Myfirst->value.value; /*0x141058314*/
          __wind /*0xf1c0000000000020*/
          {
            do /*0x14105836a*/
            {
              v14->descriptor = *(const RBX::Reflection::PropertyDescriptor **)&p_value[-1].data[48]; /*0x141058324*/
              v14->value._type = *(const RBX::Reflection::Type **)&p_value[-1].data[56]; /*0x14105832b*/
              v14->value.value.holder = nullptr; /*0x14105832f*/
              holder = (void (__fastcall **)(__int64, __int64))p_value->holder; /*0x141058333*/
              if ( p_value->holder != nullptr ) /*0x141058339*/
              {
                (*holder)(a1: (__int64)p_value->data, a2: (__int64)v14->value.value.data); /*0x141058346*/
                holder = (void (__fastcall **)(__int64, __int64))p_value->holder; /*0x141058348*/
              }
              v14->value.value.holder = (const rbx::implementation::type_holder *)holder; /*0x14105834b*/
              v14->useDefaultValue = (bool)p_value[1].holder; /*0x141058353*/
              v25._Last = ++v14; /*0x14105835a*/
              p_value = (rbx::placement_any<RBX::Reflection::Variant::Storage> *)((char *)p_value + 96); /*0x14105835f*/
            }
            while ( &p_value[-1].data[48] != (char *)Mylast ); /*0x14105836a*/
            p_propValueList->_Mypair._Myval2._Mylast = v14; /*0x14105836c*/
          }
          __unwind
          {
            std::_Uninitialized_backout_al<std::allocator<RBX::Network::PropValuePair>>::~_Uninitialized_backout_al<std::allocator<RBX::Network::PropValuePair>>(this: &v25); /*0xf1c0000000000030*/
          }
        }
        __unwind
        {
          std::_Tidy_guard<std::vector<RBX::Network::PropValuePair>>::~_Tidy_guard<std::vector<RBX::Network::PropValuePair>>(this: &v27); /*0xf1c000000000003c*/
        }
LABEL_42:
        __wind /*0xf1c0000000000044*/
        {
          __wind /*0xf1c000000000004c*/
          {
            __wind /*0xf1c0000000000054*/
            {
              this->id = __that->id; /*0x141058374*/
              this->parentId = __that->parentId; /*0x14105837c*/
              this->classInfo = __that->classInfo; /*0x141058384*/
              this->numberOfChildren_deprecated = __that->numberOfChildren_deprecated; /*0x14105838c*/
              this->indexInParent_deprecated = __that->indexInParent_deprecated; /*0x141058393*/
              this->instance._Ptr = nullptr; /*0x141058396*/
              this->instance._Rep = nullptr; /*0x14105839a*/
              Rep = __that->instance._Rep; /*0x14105839e*/
              if ( Rep != nullptr ) /*0x1410583a5*/
                _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x1410583a7*/
              this->instance._Ptr = __that->instance._Ptr; /*0x1410583af*/
              this->instance._Rep = __that->instance._Rep; /*0x1410583b7*/
              this->parent._Ptr = nullptr; /*0x1410583bb*/
              this->parent._Rep = nullptr; /*0x1410583bf*/
              v17 = __that->parent._Rep; /*0x1410583c3*/
              if ( v17 != nullptr ) /*0x1410583ca*/
                _InterlockedIncrement((volatile signed __int32 *)&v17->_Uses); /*0x1410583cc*/
              this->parent._Ptr = __that->parent._Ptr; /*0x1410583d4*/
              this->parent._Rep = __that->parent._Rep; /*0x1410583dc*/
              this->newInstance = __that->newInstance; /*0x1410583e5*/
              this->isAnAtomicReplicationRoot = __that->isAnAtomicReplicationRoot; /*0x1410583ed*/
              this->unresolvedInstanceReferences._Mypair._Myval2._Myfirst = nullptr; /*0x1410583f0*/
              this->unresolvedInstanceReferences._Mypair._Myval2._Mylast = nullptr; /*0x1410583f4*/
              this->unresolvedInstanceReferences._Mypair._Myval2._Myend = nullptr; /*0x1410583fb*/
              v18 = __that->unresolvedInstanceReferences._Mypair._Myval2._Myfirst; /*0x141058402*/
              v19 = __that->unresolvedInstanceReferences._Mypair._Myval2._Mylast; /*0x141058406*/
              if ( v18 == v19 ) /*0x141058410*/
                return this; /*0x141058410*/
              v20 = v19 - v18; /*0x14105841c*/
              if ( v20 <= 0xFFFFFFFFFFFFFFFLL ) /*0x14105842d*/
              {
                v21 = 16 * v20; /*0x141058433*/
                if ( v21 < 0x1000 ) /*0x14105843e*/
                {
                  if ( v21 != 0 ) /*0x14105846f*/
                    v5 = (std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *)operator new(size: v21); /*0x141058479*/
                  goto LABEL_30; /*0x141058479*/
                }
                if ( v21 + 39 >= v21 ) /*0x141058447*/
                {
                  v22 = (const RBX::Reflection::PropertyDescriptor *)operator new(size: v21 + 39); /*0x14105844d*/
                  if ( v22 == nullptr ) /*0x141058455*/
                    _invalid_parameter_noinfo_noreturn(); /*0x141058465*/
                  v5 = (std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *)(((unsigned __int64)&v22->attributes.threadSafety /*0x14105845b*/
                                                                                           + 7)
                                                                                          & 0xFFFFFFFFFFFFFFE0uLL);
                  v5[-1].second = v22; /*0x14105845f*/
LABEL_30:
                  this->unresolvedInstanceReferences._Mypair._Myval2._Myfirst = v5; /*0x14105847c*/
                  this->unresolvedInstanceReferences._Mypair._Myval2._Mylast = v5; /*0x141058480*/
                  this->unresolvedInstanceReferences._Mypair._Myval2._Myend = &v5[v21 / 0x10]; /*0x14105848b*/
                  v23 = this->unresolvedInstanceReferences._Mypair._Myval2._Myfirst; /*0x141058492*/
                  do /*0x1410584b1*/
                    *v23++ = *v18++; /*0x1410584a3*/
                  while ( v18 != v19 ); /*0x1410584b1*/
                  this->unresolvedInstanceReferences._Mypair._Myval2._Mylast = v23; /*0x1410584b3*/
                  return this; /*0xf1c00000000000b4*/
                }
              }
              std::_Throw_bad_array_new_length(); /*0x1410584dc*/
            }
            __unwind
            {
              std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->parent); /*0x1431ce2cb*/
            }
          }
          __unwind
          {
            std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&this->instance); /*0x143189b3b*/
          }
        }
        __unwind
        {
          std::vector<RBX::Network::PropValuePair>::~vector<RBX::Network::PropValuePair>(this: &this->propValueList); /*0x1431e876b*/
        }
      }
      if ( v9 + 39 >= v9 ) /*0x1410582b5*/
      {
        v10 = operator new(size: v9 + 39); /*0x1410582bb*/
        v11 = v10; /*0x1410582c0*/
        if ( v10 == nullptr ) /*0x1410582c6*/
          _invalid_parameter_noinfo_noreturn(); /*0x1410582d6*/
        v12 = (RBX::Network::PropValuePair *)(((unsigned __int64)v10 + 39) & 0xFFFFFFFFFFFFFFE0uLL); /*0x1410582cc*/
        *(_QWORD *)&v12[-1].useDefaultValue = v11; /*0x1410582d0*/
        goto LABEL_12; /*0x1410582d4*/
      }
    }
    std::_Throw_bad_array_new_length(); /*0x1410584d6*/
  }
  __unwind
  {
    RBX::Network::DeserializedItem::~DeserializedItem(this); /*0xf1c0000000000088*/
  }
}

// Address: 0x14105bde0 | Name: ??1DeserializedNewInstanceItem@Network@RBX@@UEAA@XZ
void __fastcall RBX::Network::DeserializedNewInstanceItem::~DeserializedNewInstanceItem(
        RBX::Network::DeserializedNewInstanceItem *this)
{
  std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *Myfirst; // rcx
  std::_Ref_count_base *Rep; // rbx
  std::_Ref_count_base *v4; // rbx

  this->__vftable = (RBX::Network::DeserializedNewInstanceItem_vtbl *)RBX::Network::DeserializedNewInstanceItem::`vftable'; /*0x14105bdf0*/
  Myfirst = this->unresolvedInstanceReferences._Mypair._Myval2._Myfirst; /*0x14105bdf3*/
  if ( Myfirst != nullptr ) /*0x14105bdfa*/
  {
    if ( (((char *)this->unresolvedInstanceReferences._Mypair._Myval2._Myend - (char *)Myfirst) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x14105be11*/
    {
      if ( (unsigned __int64)((char *)Myfirst - (char *)Myfirst[-1].second - 8) > 0x1F ) /*0x14105be26*/
        _invalid_parameter_noinfo_noreturn(); /*0x14105bedc*/
      Myfirst = (std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *)Myfirst[-1].second; /*0x14105be2c*/
    }
    operator delete(ptr: Myfirst); /*0x14105be2f*/
    this->unresolvedInstanceReferences._Mypair._Myval2._Myfirst = nullptr; /*0x14105be36*/
    this->unresolvedInstanceReferences._Mypair._Myval2._Mylast = nullptr; /*0x14105be3a*/
    this->unresolvedInstanceReferences._Mypair._Myval2._Myend = nullptr; /*0x14105be41*/
  }
  Rep = this->parent._Rep; /*0x14105be4d*/
  if ( Rep != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Uses, 0xFFFFFFFF) == 1 ) /*0x14105be6a*/
  {
    Rep->_Destroy(this: Rep); /*0x14105be72*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14105be7e*/
      Rep->_Delete_this(this: Rep); /*0x14105be86*/
  }
  v4 = this->instance._Rep; /*0x14105be89*/
  if ( v4 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Uses, 0xFFFFFFFF) == 1 ) /*0x14105be9c*/
  {
    v4->_Destroy(this: v4); /*0x14105bea4*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v4->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14105beae*/
      v4->_Delete_this(this: v4); /*0x14105beb6*/
  }
  std::vector<RBX::Network::PropValuePair>::_Tidy(this: &this->propValueList); /*0x14105bebd*/
  this->__vftable = (RBX::Network::DeserializedNewInstanceItem_vtbl *)RBX::Network::DeserializedItem::`vftable'; /*0x14105bed3*/
}

// Address: 0x14113e340 | Name: ??0DeserializedNewInstanceItem@Network@RBX@@QEAA@XZ
RBX::Network::DeserializedNewInstanceItem *__fastcall RBX::Network::DeserializedNewInstanceItem::DeserializedNewInstanceItem(
        RBX::Network::DeserializedNewInstanceItem *this)
{
  this->analyticsItemType = 2; /*0x14113e342*/
  *(_QWORD *)&this->analyticsLogicalCount = 1; /*0x14113e349*/
  this->__vftable = (RBX::Network::DeserializedNewInstanceItem_vtbl *)RBX::Network::DeserializedNewInstanceItem::`vftable'; /*0x14113e358*/
  this->propValueList._Mypair._Myval2._Myfirst = nullptr; /*0x14113e35e*/
  this->propValueList._Mypair._Myval2._Mylast = nullptr; /*0x14113e362*/
  this->propValueList._Mypair._Myval2._Myend = nullptr; /*0x14113e366*/
  this->id.scope.peerId.peerId = -1; /*0x14113e36a*/
  this->id.index = 0; /*0x14113e371*/
  this->parentId.scope.peerId.peerId = -1; /*0x14113e374*/
  this->parentId.index = 0; /*0x14113e37b*/
  this->classInfo = nullptr; /*0x14113e37e*/
  *(_QWORD *)&this->numberOfChildren_deprecated = 0; /*0x14113e382*/
  this->instance._Ptr = nullptr; /*0x14113e386*/
  this->instance._Rep = nullptr; /*0x14113e38a*/
  this->parent._Ptr = nullptr; /*0x14113e38e*/
  this->parent._Rep = nullptr; /*0x14113e392*/
  *(_WORD *)&this->newInstance = 0; /*0x14113e396*/
  this->unresolvedInstanceReferences._Mypair._Myval2._Myfirst = nullptr; /*0x14113e39a*/
  this->unresolvedInstanceReferences._Mypair._Myval2._Mylast = nullptr; /*0x14113e39e*/
  this->unresolvedInstanceReferences._Mypair._Myval2._Myend = nullptr; /*0x14113e3a5*/
  return this; /*0x14113e3ac*/
}

// Address: 0x14113ecf0 | Name: ?fillDefaultValues@DeserializedNewInstanceItem@Network@RBX@@QEAAXAEAVReplicator@23@W4PropertyGroup@23@GG@Z
void __fastcall RBX::Network::DeserializedNewInstanceItem::fillDefaultValues(
        RBX::Network::DeserializedNewInstanceItem *this,
        RBX::Network::Replicator *replicator,
        RBX::Network::PropertyGroup propertyGroup,
        unsigned __int16 fromId,
        unsigned __int16 toId)
{
  unsigned __int64 v8; // r14
  __int64 v9; // rsi
  __int64 v10; // r15
  __int64 v11; // r9
  const RBX::Network::NetworkSchema *networkSchema; // rax
  RBX::Network::NetworkSchema::ClassProperty *Myfirst; // r8
  RBX::Network::NetworkSchema::ClassProperty *v14; // rbp
  unsigned __int64 valueFormat; // rax
  unsigned __int8 v16; // cf
  int v17; // eax
  RBX::Network::PropValuePair *v18; // r8
  unsigned __int64 v19; // r9
  RBX::Network::PropValuePair *Mylast; // rdx
  std::vector<RBX::Network::PropValuePair> *p_propValueList; // rcx
  __int64 v22; // rcx
  RBX::Network::PropValuePair *v23; // rcx
  __int64 v24; // [rsp+0h] [rbp-B8h] BYREF
  RBX::Network::PropValuePair v25; // [rsp+28h] [rbp-90h] BYREF

  if ( fromId < toId ) /*0x14113ed24*/
  {
    v8 = fromId; /*0x14113ed2a*/
    v9 = fromId; /*0x14113ed32*/
    v10 = (unsigned __int16)(toId - fromId); /*0x14113ed3a*/
    v11 = 0x800610000048LL; /*0x14113ed4b*/
    do /*0x14113eea0*/
    {
      networkSchema = replicator->networkSchema; /*0x14113ed60*/
      Myfirst = networkSchema->classPropertyByNetworkId._Mypair._Myval2._Myfirst; /*0x14113ed67*/
      v14 = &Myfirst[v9]; /*0x14113ed8c*/
      if ( v8 >= networkSchema->classPropertyByNetworkId._Mypair._Myval2._Mylast - Myfirst ) /*0x14113ed93*/
        v14 = nullptr; /*0x14113ed93*/
      if ( propertyGroup == 0 ) /*0x14113ed9a*/
        goto LABEL_10; /*0x14113ed9a*/
      valueFormat = (unsigned __int8)v14->valueType.valueFormat; /*0x14113ed9c*/
      if ( (unsigned __int8)valueFormat > 0x2Fu || (v16 = _bittest64(&v11, valueFormat), v17 = 2, !v16) ) /*0x14113edad*/
        v17 = 1; /*0x14113edaf*/
      if ( v17 == propertyGroup ) /*0x14113edb7*/
      {
LABEL_10:
        v18 = this->propValueList._Mypair._Myval2._Myfirst; /*0x14113edbd*/
        if ( v18 == this->propValueList._Mypair._Myval2._Mylast ) /*0x14113edc5*/
        {
          v19 = this->classInfo->endPropertyId - (unsigned int)this->classInfo->beginPropertyId; /*0x14113edd7*/
          if ( v19 > this->propValueList._Mypair._Myval2._Myend - v18 ) /*0x14113edf8*/
            std::vector<RBX::Network::PropValuePair>::_Reallocate_exactly( /*0x14113ee01*/
              this: &this->propValueList,
              _Newcapacity: (unsigned int)v19);
        }
        v25.descriptor = nullptr; /*0x14113ee09*/
        v25.value._type = RBX::Reflection::Type::getSingleton<void>(); /*0x14113ee13*/
        v25.value.value.holder = nullptr; /*0x14113ee18*/
        v25.useDefaultValue = false; /*0x14113ee21*/
        __wind /*0xf1c0000000000020*/
        {
          Mylast = this->propValueList._Mypair._Myval2._Mylast; /*0x14113ee29*/
          p_propValueList = &this->propValueList; /*0x14113ee32*/
          if ( Mylast == this->propValueList._Mypair._Myval2._Myend ) /*0x14113ee3a*/
          {
            std::vector<RBX::Network::PropValuePair>::_Emplace_reallocate<RBX::Network::PropValuePair>( /*0x14113ee48*/
              this: p_propValueList,
              _Whereptr: Mylast,
              <_Val_0>: &v25);
          }
          else
          {
            std::_Default_allocator_traits<std::allocator<RBX::Network::PropValuePair>>::construct<RBX::Network::PropValuePair,RBX::Network::PropValuePair>( /*0x14113ee3c*/
              __formal: (std::allocator<RBX::Network::PropValuePair> *)p_propValueList,
              _Ptr: Mylast,
              <_Args_0>: &v25);
            ++this->propValueList._Mypair._Myval2._Mylast; /*0x14113ee41*/
          }
        }
        __unwind
        {
          std::pair<RBX::Reflection::PropertyDescriptor const *,RBX::Reflection::Variant>::~pair<RBX::Reflection::PropertyDescriptor const *,RBX::Reflection::Variant>(this: (std::pair<unsigned __int64,RBX::LuaWebService::CachedLuaWebServiceInfo> *)&v25); /*0xf1c0000000000030*/
        }
        __wind /*0xf1c0000000000038*/
        {
          if ( v25.value.value.holder != nullptr ) /*0x14113ee56*/
            v25.value.value.holder->destruct(a1: v25.value.value.data); /*0x14113ee61*/
        }
        __unwind
        {
          __std_terminate(a1: v22, a2: &v24); /*0x142f39fa8*/
        }
        v23 = this->propValueList._Mypair._Myval2._Mylast; /*0x14113ee64*/
        v23[-1].descriptor = v14->localDescriptor; /*0x14113ee6c*/
        v23[-1].useDefaultValue = true; /*0x14113ee70*/
        v11 = 0x800610000048LL; /*0x14113ee77*/
      }
      ++v8; /*0x14113ee8b*/
      ++v9; /*0x14113ee8e*/
      --v10; /*0x14113ee92*/
    }
    while ( v10 != 0 ); /*0x14113eea0*/
  }
}

// Address: 0x14113eee0 | Name: ?process@DeserializedNewInstanceItem@Network@RBX@@UEAA?AW4ProcessResult@DeserializedItem@23@AEAVReplicator@23@@Z
__int64 __fastcall RBX::Network::DeserializedNewInstanceItem::process(
        RBX::Network::DeserializedNewInstanceItem *this,
        RBX::Network::Replicator *replicator)
{
  char v4; // r12
  std::shared_ptr<RBX::Instance> *p_instance; // r14
  RBX::Instance *Ptr; // rdx
  RBX::Network::Replicator_vtbl *v7; // rax
  std::vector<RBX::Network::PropValuePair> *p_propValueList; // r13
  bool v9; // al
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v11; // rax
  unsigned int v12; // ebx
  unsigned int *memoryCategory; // rax
  unsigned int v14; // ecx
  unsigned int parent; // edi
  RBX::Network::PropValuePair *Myfirst; // r15
  unsigned int humanoid; // r12d
  RBX::Reflection::PropDescriptor<RBX::Player,std::string > *v18; // rax
  RBX::Humanoid *v19; // r13
  const RBX::Reflection::ClassDescriptor *v20; // rbx
  RBX::ClassRegistrar<RBX::Humanoid,1> *v21; // rax
  unsigned int v22; // edx
  RBX::Humanoid *v23; // rbx
  __int64 v24; // rcx
  const RBX::Reflection::ClassDescriptor *v25; // rbx
  RBX::Reflection::ClassDescriptor *v26; // rax
  RBX::Player *v27; // rdi
  std::_Ref_count_base *Rep; // rax
  _WORD *v29; // rax
  char *v30; // rcx
  RBX::Player *v31; // r15
  __int64 UserID; // rbx
  _WORD *v33; // rax
  const RBX::Reflection::ClassDescriptor *v34; // rbx
  RBX::Reflection::ClassDescriptor *v35; // rax
  RBX::Instance *v36; // rdi
  volatile signed __int32 *v37; // rax
  char *v38; // rax
  char v39; // r12
  std::_Ref_count_base *v40; // rbx
  volatile signed __int32 *v41; // rbx
  volatile signed __int32 *v42; // rbx
  RBX::Network::Replicator_vtbl *v43; // rax
  const RBX::Reflection::ClassDescriptor *v44; // rbx
  RBX::Reflection::ClassDescriptor *v45; // rax
  RBX::Instance *v46; // r15
  volatile signed __int32 *v47; // rax
  char *v48; // rax
  char v49; // r12
  std::_Ref_count_base *v50; // rdi
  volatile signed __int32 *v51; // rbx
  volatile signed __int32 *v52; // rbx
  RBX::Network::DeserializedNewInstanceItem *v53; // r12
  RBX::Players *players; // rcx
  const std::string *v55; // rax
  char *v56; // rcx
  char *v57; // rcx
  char v58; // r13
  RBX::Network::DeserializedNewInstanceItem *v59; // r15
  std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *v60; // rdi
  std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *i; // rbx
  bool isAncestorSentInJoinCache; // di
  bool v64; // al
  const std::shared_ptr<RBX::Instance> *node; // r15
  boost::unordered::detail::ptr_bucket *next; // rbx
  RBX::Reflection::ClassDescriptor *v67; // rax
  RBX::Instance *v68; // rdi
  const RBX::Reflection::ClassDescriptor *v69; // rbx
  RBX::Reflection::ClassDescriptor *v70; // rax
  RBX::Workspace *v71; // r8
  RBX::Network::MegaReplicator *megaReplicator; // rcx
  bool isStreamingEnabled; // di
  bool v74; // bl
  bool setAliveForAllReplicators; // bl
  RBX::ReplicatedFirst *v76; // rax
  RBX::Instance *v77; // rcx
  RBX::Network::MegaReplicator *v78; // rbx
  bool isInstanceCacheableForJoin; // al
  RBX::Network::MegaReplicator *v80; // rcx
  std::string *v81; // rax
  char *v82; // rcx
  std::_Ref_count_base *v83; // r15
  RBX::Instance *v84; // rbx
  RBX::Guid id; // rax
  volatile signed __int32 *v86; // rbx
  std::shared_ptr<RBX::Instance> *v87; // rdi
  std::shared_ptr<RBX::Instance> *Mylast; // r12
  volatile signed __int32 *v89; // rbx
  std::shared_ptr<RBX::Instance> *v90; // rax
  std::_Ref_count_base *v91; // rcx
  __int64 v92; // rcx
  RBX::Instance *RootAncestor; // rax
  RBX::Instance *v94; // rcx
  boost::unordered::detail::ptr_node<std::pair<RBX::Guid const ,RBX::Network::Replicator::DeferredTree> > *v95; // rax
  std::_Ref_count_base *v96; // rdx
  RBX::GuidItem<RBX::Instance> *v97; // rdx
  unsigned int v98; // ebx
  std::pair<RBX::Guid const ,RBX::Network::Replicator::DeferredTree> *v99; // rax
  std::vector<std::shared_ptr<RBX::Graphics::ShaderProgram>> *p_allDesendants; // rcx
  std::shared_ptr<RBX::Graphics::ShaderProgram> *v101; // rdx
  std::_Ref_count_base *v102; // rax
  __int64 v103; // rcx
  std::string *v104; // rax
  const char *v105; // rax
  _BYTE v106[32]; // [rsp+0h] [rbp-100h] BYREF
  RBX::Instance *out; // [rsp+20h] [rbp-E0h]
  bool v108; // [rsp+40h] [rbp-C0h]
  RBX::Memory::Scope memscopeNetworkDeferredTrees; // [rsp+44h] [rbp-BCh] BYREF
  std::shared_ptr<RBX::File> v110; // [rsp+48h] [rbp-B8h] BYREF
  std::shared_ptr<RBX::File> v111; // [rsp+58h] [rbp-A8h] BYREF
  RBX::Humanoid::ScopedHumanoidNiiSetter scopedHumanoidNiiSetter; // [rsp+68h] [rbp-98h] BYREF
  RBX::Memory::Scope ms; // [rsp+70h] [rbp-90h] BYREF
  boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<RBX::Guid const ,RBX::Network::Replicator::DeferredTree> > > atomicTreeRoot; // [rsp+78h] [rbp-88h] BYREF
  std::shared_ptr<RBX::Player> player; // [rsp+80h] [rbp-80h] BYREF
  std::shared_ptr<RBX::Instance> replicationRoot; // [rsp+90h] [rbp-70h] BYREF
  char v117; // [rsp+A0h] [rbp-60h] BYREF
  volatile signed __int32 *v118; // [rsp+A8h] [rbp-58h]
  char v119; // [rsp+B0h] [rbp-50h] BYREF
  volatile signed __int32 *v120; // [rsp+B8h] [rbp-48h]
  __int128 v121; // [rsp+C0h] [rbp-40h] BYREF
  char v122; // [rsp+D0h] [rbp-30h] BYREF
  volatile signed __int32 *v123; // [rsp+D8h] [rbp-28h]
  char v124; // [rsp+E0h] [rbp-20h] BYREF
  volatile signed __int32 *v125; // [rsp+E8h] [rbp-18h]
  std::shared_ptr<RBX::Player> v126; // [rsp+F0h] [rbp-10h] BYREF
  std::string counterName; // [rsp+100h] [rbp+0h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v128; // [rsp+120h] [rbp+20h] BYREF
  std::pair<RBX::Guid,RBX::Network::Replicator::DeferredTree> v129; // [rsp+158h] [rbp+58h] BYREF
  std::pair<boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<RBX::Guid const ,RBX::Network::Replicator::DeferredTree> > >,bool> instance; // [rsp+188h] [rbp+88h] BYREF
  volatile signed __int32 *v131; // [rsp+1A8h] [rbp+A8h]
  RBX::Graphics::ProfilerAdorn::Item v132; // [rsp+1B0h] [rbp+B0h] BYREF
  std::vector<std::shared_ptr<RBX::Graphics::PersistentBufferVulkan>> v133; // [rsp+1E8h] [rbp+E8h] BYREF
  rtc::webrtc_checks_impl::ToStringVal v134; // [rsp+200h] [rbp+100h] BYREF
  RBX::Network::Replicator::DeferredTree deferredTree; // [rsp+220h] [rbp+120h] BYREF
  std::string message; // [rsp+248h] [rbp+148h] BYREF
  std::string v137; // [rsp+268h] [rbp+168h] BYREF
  RBX::Graphics::ProfilerAdorn::Item v138; // [rsp+288h] [rbp+188h] BYREF
  RBX::Network::DeserializedNewInstanceItem *v139; // [rsp+2F0h] [rbp+1F0h] BYREF
  bool reject; // [rsp+300h] [rbp+200h] BYREF
  unsigned int otherReplicatorKicked; // [rsp+308h] [rbp+208h] BYREF

  v139 = this; /*0x14113eee5*/
  v4 = 0; /*0x14113ef0c*/
  memscopeNetworkDeferredTrees.parent = 0; /*0x14113ef0f*/
  p_instance = &this->instance; /*0x14113ef13*/
  Ptr = this->instance._Ptr; /*0x14113ef17*/
  if ( Ptr == nullptr )
  {
    v104 = RBX::Guid::readableString(this: &this->id, result: &v138.text, scopeLength: 4); /*0x141140029*/
    __wind
    {
      std::operator+<char>(result: &message, _Left: "Replication: deserialized item contain null object ", _Right: v104);
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v138); /*0x14114004d*/
      v105 = std::string::c_str(this: (RBX::ContentId *)&message); /*0x141140059*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v138); /*0xf1c0000000000044*/
    }
    __wind /*0xf1c000000000004c*/
    {
      RBX::StandardOut::print(type: MESSAGE_ERROR, message: v105, originGameStateType: NumStudioGameStateTypes); /*0x141140069*/
      std::runtime_error::runtime_error(this: (std::runtime_error *)&v128.x, _Message: &message); /*0x141140079*/
      throw (std::runtime_error *)&v128.x; /*0x141140089*/
    }
    __unwind
    {
      RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&message); /*0xf1c000000000005c*/
    }
  }
  if ( DFFlag::DebugAvatarProfilerCallers.value ) /*0x14113ef29*/
  {
    RBX::AvatarProfiler::logNetInstanceProcess(inst: Ptr); /*0x14113ef2e*/
    Ptr = p_instance->_Ptr; /*0x14113ef33*/
  }
  if ( DFFlag::DetailedBandwidthStatsInflux2.value ) /*0x14113ef3d*/
    RBX::Network::OngoingBandwidthStats::recordNewInstance( /*0x14113ef4f*/
      this: &replicator->inboundBandwidthStats,
      cls: Ptr->descriptor,
      wireSize: this->analyticsWireSize);
  if ( DFFlag::ClientReportJoinInstanceTypeBreakdown2.value /*0x14113ef6b*/
    && ((unsigned __int8 (__fastcall *)(RBX::Network::Replicator *, RBX::Instance *))replicator->isReplicatedFirstFinished)(
         a1: replicator,
         a2: Ptr) == 0 )
  {
    RBX::Network::JoinRxStats::recordReplicatedFirstInstance( /*0x14113ef7d*/
      this: &replicator->joinRxStats,
      instance: p_instance,
      compressedSize: (int)this->analyticsWireSize);
  }
  v7 = replicator->RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>::RBX::Network::IdSerializer::RBX::Instance::RBX::Reflection::DescribedBase::RBX::Reflection::EventSource::__vftable; /*0x14113ef82*/
  instance.first.node_ = (boost::unordered::detail::ptr_node<std::pair<RBX::Guid const ,RBX::Network::Replicator::DeferredTree> > *)&this->parent; /*0x14113ef89*/
  p_propValueList = &this->propValueList; /*0x14113ef90*/
  v9 = v7->isLegalReceiveInstance( /*0x14113efa0*/
         this: replicator,
         a2: p_instance->_Ptr,
         a3: this->parent._Ptr,
         a4: &this->propValueList);
  reject = !v9; /*0x14113efa8*/
  if ( v9 ) /*0x14113efb1*/
  {
    if ( RBX::Network::Replicator::resetChildrenOnNIIProcess(this: replicator) ) /*0x14113efba*/
      RBX::Network::Replicator::removeAllNonLocalChildren(this: replicator, instance: p_instance, parent: &this->parent); /*0x14113efcc*/
    descriptor = p_instance->_Ptr->descriptor; /*0x14113efd4*/
    v11 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(); /*0x14113efd8*/
    v12 = descriptor->index - v11->index; /*0x14113efeb*/
    otherReplicatorKicked = v12; /*0x14113efed*/
    LODWORD(scopedHumanoidNiiSetter.humanoid) = v11->descendantCount; /*0x14113effa*/
    memoryCategory = (unsigned int *)p_instance->_Ptr->descriptor->memoryCategory; /*0x14113f005*/
    if ( memoryCategory != nullptr ) /*0x14113f00f*/
      v14 = *memoryCategory; /*0x14113f011*/
    else
      v14 = RBX::Memory::InstanceObject; /*0x14113f015*/
    parent = RBX::Memory::setCurrentCategory(category: v14); /*0x14113f020*/
    ms.parent = parent; /*0x14113f022*/
    __wind /*0xf1c00000000001c0*/
    {
      Myfirst = p_propValueList->_Mypair._Myval2._Myfirst; /*0x14113f026*/
      atomicTreeRoot.node_ = (boost::unordered::detail::ptr_node<std::pair<RBX::Guid const ,RBX::Network::Replicator::DeferredTree> > *)p_propValueList->_Mypair._Myval2._Mylast; /*0x14113f02e*/
      if ( Myfirst != (RBX::Network::PropValuePair *)atomicTreeRoot.node_ ) /*0x14113f036*/
      {
        humanoid = (unsigned int)scopedHumanoidNiiSetter.humanoid; /*0x14113f05f*/
        while ( v12 <= humanoid ) /*0x14113f069*/
        {
          v18 = (RBX::Reflection::PropDescriptor<RBX::Player,std::string > *)Myfirst->descriptor; /*0x14113f06b*/
          if ( FFlag::LocaleIdRefactor2.value ) /*0x14113f075*/
          {
            if ( v18 != &RBX::Player::prop_VRDevice && v18 != &RBX::Player::prop_countryRegionCodeReplicate ) /*0x14113f083*/
              break; /*0x14113f083*/
          }
          else if ( v18 != &RBX::Player::prop_ReplicatedLocaleId_deprecated /*0x14113f0a8*/
                 && v18 != &RBX::Player::prop_ReplicatedLocaleIdInternal_deprecated
                 && v18 != &RBX::Player::prop_VRDevice
                 && v18 != &RBX::Player::prop_countryRegionCodeReplicate )
          {
            break; /*0x14113f0a8*/
          }
LABEL_37:
          if ( ++Myfirst == (RBX::Network::PropValuePair *)atomicTreeRoot.node_ ) /*0x14113f165*/
          {
            parent = ms.parent; /*0x14113f16b*/
            v4 = memscopeNetworkDeferredTrees.parent; /*0x14113f16f*/
            goto LABEL_311; /*0xf1c00000000002bc*/
          }
        }
        v19 = (RBX::Humanoid *)p_instance->_Ptr; /*0x14113f0b5*/
        if ( DFFlag::HumanoidDontWalkUnderNII.value && Myfirst->descriptor == &RBX::Humanoid::propWalkToPoint ) /*0x14113f0c4*/
        {
          v20 = v19->descriptor; /*0x14113f0c6*/
          v21 = RBX::Reflection::Class_getDescriptorPtr<RBX::Humanoid>(); /*0x14113f0ca*/
          v22 = v20->index - v21->desc.index; /*0x14113f0dd*/
          v23 = nullptr; /*0x14113f0e6*/
          if ( v22 <= v21->desc.descendantCount ) /*0x14113f0eb*/
            v23 = v19; /*0x14113f0eb*/
          scopedHumanoidNiiSetter.humanoid = v23; /*0x14113f0ef*/
          if ( v23 != nullptr ) /*0x14113f0f7*/
            v23->initiateWalkingOnWalkToPoint = false; /*0x14113f0f9*/
        }
        else
        {
          v23 = nullptr; /*0x14113f102*/
          scopedHumanoidNiiSetter.humanoid = nullptr; /*0x14113f105*/
        }
        __wind /*0xf1c00000000001b4*/
        {
          RBX::Network::Replicator::schemaApplyStoredPropertyToInstance( /*0x14113f121*/
            this: replicator,
            propDesc: Myfirst->descriptor,
            variant: &Myfirst->value,
            useDefaultValue: Myfirst->useDefaultValue,
            out: p_instance->_Ptr);
        }
        __unwind
        {
          RBX::Humanoid::ScopedHumanoidNiiSetter::~ScopedHumanoidNiiSetter(this: &scopedHumanoidNiiSetter); /*0xf1c00000000001ac*/
        }
        if ( v23 != nullptr ) /*0x14113f146*/
          v23->initiateWalkingOnWalkToPoint = true; /*0x14113f148*/
        v12 = otherReplicatorKicked; /*0x14113f14f*/
        goto LABEL_37; /*0x14113f14f*/
      }
    }
    __unwind
    {
      RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&ms); /*0xf1c00000000001d0*/
    }
LABEL_311:
    __wind /*0xf1c00000000001d8*/
    {
      RBX::Memory::setCurrentCategory(category: parent); /*0x14113f176*/
    }
    __unwind
    {
      __std_terminate(a1: v24, a2: v106); /*0x142f39fa8*/
    }
  }
  LODWORD(out) = 0; /*0x14113f17f*/
  v108 = _RTDynamicCast_0() != 0; /*0x14113f19f*/
  if ( DFFlag::LegacyRedundantPlayerCheckAnalytics.value ) /*0x14113f1ab*/
  {
    if ( p_instance->_Ptr != nullptr /*0x14113f1db*/
      && (v25 = p_instance->_Ptr->descriptor,
          v26 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(),
          v25->index - (unsigned int)v26->index <= v26->descendantCount) )
    {
      v27 = (RBX::Player *)p_instance->_Ptr; /*0x14113f1dd*/
      Rep = p_instance->_Rep; /*0x14113f1e0*/
      if ( Rep != nullptr ) /*0x14113f1e7*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&Rep->_Uses); /*0x14113f1e9*/
        Rep = p_instance->_Rep; /*0x14113f1ed*/
      }
      player._Ptr = v27; /*0x14113f1f1*/
      player._Rep = Rep; /*0x14113f1f5*/
      v131 = nullptr; /*0x14113f1f9*/
      v4 = 5; /*0x14113f200*/
    }
    else
    {
      player._Ptr = nullptr; /*0x14113f208*/
      player._Rep = nullptr; /*0x14113f20c*/
      *(_QWORD *)&v128.width = 0; /*0x14113f210*/
      v4 = 4; /*0x14113f214*/
      v27 = nullptr; /*0x14113f21a*/
    }
    if ( (v4 & 1) != 0 ) /*0x14113f221*/
    {
      v4 &= ~1u; /*0x14113f223*/
      if ( v131 != nullptr && _InterlockedExchangeAdd(v131 + 2, 0xFFFFFFFF) == 1 ) /*0x14113f240*/
      {
        (**(void (__fastcall ***)(volatile signed __int32 *))v131)(a1: v131); /*0x14113f24f*/
        if ( _InterlockedExchangeAdd(v131 + 3, 0xFFFFFFFF) == 1 ) /*0x14113f25e*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v131 + 8LL))(a1: v131); /*0x14113f26a*/
      }
    }
    __wind /*0xf1c0000000000190*/
    {
      if ( v27 != nullptr ) /*0x14113f271*/
      {
        if ( replicator->isServerReplicator(this: replicator) ) /*0x14113f27d*/
        {
          v29 = operator new(size: 0x30u); /*0x14113f2a4*/
          counterName._Mypair._Myval2._Mysize = 43; /*0x14113f2a9*/
          counterName._Mypair._Myval2._Myres = 47; /*0x14113f2b1*/
          qmemcpy(v29, "Server_LegacyRedundantPlayerCheck_Reachabl", 42); /*0x14113f2c0*/
          v29[21] = (unsigned __int8)aServerLegacyre[42]; /*0x14113f2ed*/
          counterName._Mypair._Myval2._Bx._Ptr = (char *)v29; /*0x14113f2f4*/
          __wind /*0xf1c0000000000184*/
          {
            RBX::Analytics::EphemeralCounter::reportCounter(&counterName, amount: 1, blocking: false); /*0x14113f303*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&counterName); /*0xf1c000000000017c*/
          }
          if ( counterName._Mypair._Myval2._Myres < 0x10 ) /*0x14113f311*/
            goto LABEL_67; /*0x14113f311*/
          v30 = counterName._Mypair._Myval2._Bx._Ptr; /*0x14113f31a*/
          if ( counterName._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14113f328*/
          {
            v30 = *((char **)counterName._Mypair._Myval2._Bx._Ptr - 1); /*0x14113f332*/
            if ( (unsigned __int64)(counterName._Mypair._Myval2._Bx._Ptr - v30 - 8) > 0x1F ) /*0x14113f341*/
              _invalid_parameter_noinfo_noreturn(); /*0x14113f347*/
          }
        }
        else
        {
          v31 = replicator->findTargetPlayer(this: replicator); /*0x14113f35a*/
          if ( v31 == nullptr ) /*0x14113f360*/
            goto LABEL_67; /*0x14113f360*/
          if ( RBX::Player::getUserID(this: v27) <= 0 ) /*0x14113f371*/
            goto LABEL_67; /*0x14113f371*/
          UserID = RBX::Player::getUserID(this: v27); /*0x14113f37f*/
          if ( UserID != RBX::Player::getUserID(this: v31) ) /*0x14113f38d*/
            goto LABEL_67; /*0x14113f38d*/
          v33 = operator new(size: 0x30u); /*0x14113f3ac*/
          v128.text._Mypair._Myval2._Mysize = 43; /*0x14113f3b1*/
          v128.text._Mypair._Myval2._Myres = 47; /*0x14113f3b9*/
          qmemcpy(v33, "Client_LegacyRedundantPlayerCheck_Reachabl", 42); /*0x14113f3c8*/
          v33[21] = (unsigned __int8)aClientLegacyre[42]; /*0x14113f3f5*/
          v128.text._Mypair._Myval2._Bx._Ptr = (char *)v33; /*0x14113f3fc*/
          __wind /*0xf1c000000000016c*/
          {
            RBX::Analytics::EphemeralCounter::reportCounter(counterName: &v128.text, amount: 1, blocking: false); /*0x14113f40b*/
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v128); /*0xf1c0000000000164*/
          }
          if ( v128.text._Mypair._Myval2._Myres < 0x10 ) /*0x14113f419*/
            goto LABEL_67; /*0x14113f419*/
          v30 = v128.text._Mypair._Myval2._Bx._Ptr; /*0x14113f41e*/
          if ( v128.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14113f42c*/
          {
            v30 = *((char **)v128.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14113f432*/
            if ( (unsigned __int64)(v128.text._Mypair._Myval2._Bx._Ptr - v30 - 8) > 0x1F ) /*0x14113f441*/
              _invalid_parameter_noinfo_noreturn(); /*0x14113f443*/
          }
        }
        operator delete(ptr: v30); /*0x14113f44a*/
      }
LABEL_67:
      if ( player._Rep != nullptr /*0x14113f466*/
        && _InterlockedExchangeAdd((volatile signed __int32 *)&player._Rep->_Uses, 0xFFFFFFFF) == 1 )
      {
        player._Rep->_Destroy(this: player._Rep); /*0x14113f472*/
        if ( _InterlockedExchangeAdd((volatile signed __int32 *)&player._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113f481*/
          player._Rep->_Delete_this(this: player._Rep); /*0x14113f48a*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&player); /*0xf1c0000000000158*/
    }
  }
  if ( !DFFlag::RemoveLegacyRedundantPlayerCheck.value && replicator->isCloudEdit(this: replicator) ) /*0x14113f4a0*/
  {
    if ( reject ) /*0x14113f4b5*/
    {
LABEL_277:
      __eh34_enter_wind_state(-1, 10); /*0xf1c00000000000fc*/
      v53 = v139; /*0x14113f960*/
      goto LABEL_146; /*0xf1c0000000000100*/
    }
    if ( p_instance->_Ptr != nullptr /*0x14113f4e5*/
      && (v34 = p_instance->_Ptr->descriptor,
          v35 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(),
          v34->index - (unsigned int)v35->index <= v35->descendantCount) )
    {
      v36 = p_instance->_Ptr; /*0x14113f4e7*/
      v37 = (volatile signed __int32 *)p_instance->_Rep; /*0x14113f4ea*/
      if ( v37 != nullptr ) /*0x14113f4f1*/
      {
        _InterlockedIncrement(v37 + 2); /*0x14113f4f3*/
        v37 = (volatile signed __int32 *)p_instance->_Rep; /*0x14113f4f7*/
      }
      v120 = v37; /*0x14113f4fb*/
      v38 = &v119; /*0x14113f4ff*/
      v39 = v4 | 8; /*0x14113f503*/
    }
    else
    {
      v118 = nullptr; /*0x14113f509*/
      v38 = &v117; /*0x14113f50d*/
      v39 = v4 | 0x10; /*0x14113f511*/
      v36 = nullptr; /*0x14113f515*/
    }
    v110._Ptr = (RBX::File *)v36; /*0x14113f518*/
    v40 = *((std::_Ref_count_base **)v38 + 1); /*0x14113f51d*/
    v110._Rep = v40; /*0x14113f521*/
    *(_QWORD *)v38 = 0; /*0x14113f526*/
    *((_QWORD *)v38 + 1) = 0; /*0x14113f529*/
    v4 = v39 | 0x20; /*0x14113f52d*/
    if ( (v4 & 0x10) != 0 ) /*0x14113f535*/
    {
      v4 &= ~0x10u; /*0x14113f537*/
      if ( v118 != nullptr ) /*0x14113f542*/
      {
        if ( _InterlockedExchangeAdd(v118 + 2, 0xFFFFFFFF) == 1 ) /*0x14113f551*/
        {
          v41 = v118; /*0x14113f553*/
          (**(void (__fastcall ***)(volatile signed __int32 *))v118)(a1: v118); /*0x14113f55d*/
          if ( _InterlockedExchangeAdd(v41 + 3, 0xFFFFFFFF) == 1 ) /*0x14113f56c*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v118 + 8LL))(a1: v118); /*0x14113f575*/
        }
        v40 = v110._Rep; /*0x14113f578*/
      }
    }
    if ( (v4 & 8) != 0 ) /*0x14113f581*/
    {
      v4 &= ~8u; /*0x14113f583*/
      if ( v120 != nullptr ) /*0x14113f58e*/
      {
        if ( _InterlockedExchangeAdd(v120 + 2, 0xFFFFFFFF) == 1 ) /*0x14113f59d*/
        {
          v42 = v120; /*0x14113f59f*/
          (**(void (__fastcall ***)(volatile signed __int32 *))v120)(a1: v120); /*0x14113f5a9*/
          if ( _InterlockedExchangeAdd(v42 + 3, 0xFFFFFFFF) == 1 ) /*0x14113f5b8*/
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v120 + 8LL))(a1: v120); /*0x14113f5c1*/
        }
        v40 = v110._Rep; /*0x14113f5c4*/
      }
    }
    __wind /*0xf1c0000000000148*/
    {
      if ( v36 != nullptr ) /*0x14113f5cc*/
      {
        LOBYTE(otherReplicatorKicked) = 0; /*0x14113f5ce*/
        v43 = replicator->RBX::Described<RBX::Network::Replicator,RBX::Network::IdSerializer>::RBX::Network::IdSerializer::RBX::Instance::RBX::Reflection::DescribedBase::RBX::Reflection::EventSource::__vftable; /*0x14113f5d5*/
        v121 = 0; /*0x14113f5db*/
        if ( v40 != nullptr ) /*0x14113f5e3*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v40->_Uses); /*0x14113f5e5*/
          v40 = v110._Rep; /*0x14113f5e9*/
        }
        *(_QWORD *)&v121 = v36; /*0x14113f5ee*/
        *((_QWORD *)&v121 + 1) = v40; /*0x14113f5f2*/
        ((void (__fastcall *)(RBX::Network::Replicator *, __int128 *, unsigned int *, bool *, _DWORD))v43->kickAllOtherPlayersWithId_2)( /*0x14113f60b*/
          a1: replicator,
          a2: &v121,
          a3: &otherReplicatorKicked,
          a4: &reject,
          a5: (_DWORD)out);
        if ( (_BYTE)otherReplicatorKicked != 0 ) /*0x14113f618*/
          *(&v36[12].ancestorPermissionMask + 3) = 1; /*0x14113f61a*/
      }
    }
    __unwind
    {
      std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v110); /*0xf1c0000000000140*/
    }
    if ( v40 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v40->_Uses, 0xFFFFFFFF) == 1 ) /*0x14113f633*/
    {
      v110._Rep->_Destroy(this: v110._Rep); /*0x14113f640*/
      if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v110._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113f64f*/
        v110._Rep->_Delete_this(this: v110._Rep); /*0x14113f659*/
    }
  }
  if ( reject ) /*0x14113f663*/
    goto LABEL_277; /*0x14113f663*/
  if ( p_instance->_Ptr != nullptr /*0x14113f693*/
    && (v44 = p_instance->_Ptr->descriptor,
        v45 = RBX::Reflection::Class_getDescriptorPtr<RBX::Player>(),
        v44->index - (unsigned int)v45->index <= v45->descendantCount) )
  {
    v46 = p_instance->_Ptr; /*0x14113f695*/
    v47 = (volatile signed __int32 *)p_instance->_Rep; /*0x14113f698*/
    if ( v47 != nullptr ) /*0x14113f69f*/
    {
      _InterlockedIncrement(v47 + 2); /*0x14113f6a1*/
      v47 = (volatile signed __int32 *)p_instance->_Rep; /*0x14113f6a5*/
    }
    v125 = v47; /*0x14113f6a9*/
    v48 = &v124; /*0x14113f6ad*/
    v49 = v4 | 0x40; /*0x14113f6b1*/
  }
  else
  {
    v123 = nullptr; /*0x14113f6b7*/
    v48 = &v122; /*0x14113f6bb*/
    v49 = v4 | 0x80; /*0x14113f6bf*/
    v46 = nullptr; /*0x14113f6c4*/
  }
  v111._Ptr = (RBX::File *)v46; /*0x14113f6c7*/
  v50 = *((std::_Ref_count_base **)v48 + 1); /*0x14113f6cc*/
  v111._Rep = v50; /*0x14113f6d0*/
  *(_QWORD *)v48 = 0; /*0x14113f6d5*/
  *((_QWORD *)v48 + 1) = 0; /*0x14113f6d8*/
  if ( v49 < 0 ) /*0x14113f6e4*/
  {
    v49 &= ~0x80u; /*0x14113f6e6*/
    if ( v123 != nullptr ) /*0x14113f6f2*/
    {
      if ( _InterlockedExchangeAdd(v123 + 2, 0xFFFFFFFF) == 1 ) /*0x14113f701*/
      {
        v51 = v123; /*0x14113f703*/
        (**(void (__fastcall ***)(volatile signed __int32 *))v123)(a1: v123); /*0x14113f70d*/
        if ( _InterlockedExchangeAdd(v51 + 3, 0xFFFFFFFF) == 1 ) /*0x14113f71c*/
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v123 + 8LL))(a1: v123); /*0x14113f725*/
      }
      v50 = v111._Rep; /*0x14113f728*/
    }
  }
  if ( (v49 & 0x40) != 0 && v125 != nullptr ) /*0x14113f73a*/
  {
    if ( _InterlockedExchangeAdd(v125 + 2, 0xFFFFFFFF) == 1 ) /*0x14113f749*/
    {
      v52 = v125; /*0x14113f74b*/
      (**(void (__fastcall ***)(volatile signed __int32 *))v125)(a1: v125); /*0x14113f755*/
      if ( _InterlockedExchangeAdd(v52 + 3, 0xFFFFFFFF) == 1 ) /*0x14113f764*/
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v125 + 8LL))(a1: v125); /*0x14113f76d*/
    }
    v50 = v111._Rep; /*0x14113f770*/
  }
  __eh34_enter_wind_state(-1, 10); /*0xf1c0000000000134*/
  if ( v46 == nullptr || replicator->isServerReplicator(this: replicator) ) /*0x14113f784*/
  {
    v53 = v139; /*0x14113f91c*/
  }
  else
  {
    if ( replicator->players->localPlayer._Ptr != nullptr ) /*0x14113f7a1*/
    {
      v53 = v139; /*0x14113f90c*/
    }
    else
    {
      if ( replicator->expectedPlayerId != 0 /*0x14113f7c0*/
        && RBX::Player::getUserID(this: (RBX::Player *)v46) != replicator->expectedPlayerId )
      {
        std::runtime_error::runtime_error( /*0x14113ffff*/
          this: (std::runtime_error *)&v128.x,
          _Message: "Received unexpected player instance!");
        throw (std::runtime_error *)&v128.x; /*0x14114000f*/
      }
      v53 = v139; /*0x14113f7db*/
      RBX::Network::Replicator::addReplicationData( /*0x14113f7ea*/
        this: replicator,
        classInfo: v139->classInfo,
        instance: p_instance,
        listenToChanges: true,
        replicateChildren: true,
        setAliveForAllReplicators: true,
        shallCreateMRD: true);
      players = replicator->players; /*0x14113f7ef*/
      v126 = 0; /*0x14113f7f9*/
      if ( v50 != nullptr ) /*0x14113f801*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v50->_Uses); /*0x14113f803*/
        v50 = v111._Rep; /*0x14113f807*/
      }
      v126._Ptr = (RBX::Player *)v46; /*0x14113f80c*/
      v126._Rep = v50; /*0x14113f810*/
      RBX::Players::setServerCreatedPlayer(this: players, player: &v126); /*0x14113f818*/
      if ( DFFlag::ReportOSInRakNetHighwaterMark.value ) /*0x14113f824*/
      {
        std::string::string(this: &v134, __that: (const rtc::webrtc_checks_impl::ToStringVal *)&v46[11].ownedByActor); /*0x14113f838*/
        __wind /*0xf1c0000000000128*/
        {
          v55 = RBX::SystemUtil::osPlatform(result: &v132.text); /*0x14113f845*/
          __wind /*0xf1c000000000011c*/
          {
            RBX::Network::NetworkBandwidthManager::setReplicatorReportInfo( /*0x14113f85c*/
              this: &replicator->bandwidthManager,
              playerOs: v55,
              playerCountryCode: &v134.val);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: &v132); /*0xf1c0000000000114*/
          }
          if ( v132.text._Mypair._Myval2._Myres >= 0x10 ) /*0x14113f86d*/
          {
            v56 = v132.text._Mypair._Myval2._Bx._Ptr; /*0x14113f872*/
            if ( v132.text._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14113f883*/
            {
              v56 = *((char **)v132.text._Mypair._Myval2._Bx._Ptr - 1); /*0x14113f889*/
              if ( (unsigned __int64)(v132.text._Mypair._Myval2._Bx._Ptr - v56 - 8) > 0x1F ) /*0x14113f898*/
                _invalid_parameter_noinfo_noreturn(); /*0x14113f89a*/
            }
            operator delete(ptr: v56); /*0x14113f8a1*/
          }
        }
        __unwind
        {
          RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v134); /*0xf1c0000000000108*/
        }
        v132.text._Mypair._Myval2._Mysize = 0; /*0x14113f8a6*/
        v132.text._Mypair._Myval2._Myres = 15; /*0x14113f8ad*/
        v132.text._Mypair._Myval2._Bx._Buf[0] = 0; /*0x14113f8b8*/
        if ( v134.val._Mypair._Myval2._Myres >= 0x10 ) /*0x14113f8ca*/
        {
          v57 = v134.val._Mypair._Myval2._Bx._Ptr; /*0x14113f8cf*/
          if ( v134.val._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14113f8e0*/
          {
            v57 = *((char **)v134.val._Mypair._Myval2._Bx._Ptr - 1); /*0x14113f8e6*/
            if ( (unsigned __int64)(v134.val._Mypair._Myval2._Bx._Ptr - v57 - 8) > 0x1F ) /*0x14113f8f5*/
              _invalid_parameter_noinfo_noreturn(); /*0x14113f8f7*/
          }
          operator delete(ptr: v57); /*0x14113f8fe*/
          reject = false; /*0x14113f903*/
          goto LABEL_142; /*0x14113f90a*/
        }
      }
    }
    reject = false; /*0x14113f913*/
  }
LABEL_142:
  if ( v50 != nullptr && _InterlockedExchangeAdd((volatile signed __int32 *)&v50->_Uses, 0xFFFFFFFF) == 1 ) /*0x14113f935*/
  {
    v111._Rep->_Destroy(this: v111._Rep); /*0x14113f942*/
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)&v111._Rep->_Weaks, 0xFFFFFFFF) == 1 ) /*0x14113f951*/
      v111._Rep->_Delete_this(this: v111._Rep); /*0x14113f95b*/
  }
LABEL_146:
  v58 = 0; /*0x14113f967*/
  replicationRoot = 0; /*0x14113f96d*/
  if ( v108 ) /*0x14113f977*/
  {
    if ( __eh34_unwind(10) ) /*0xf1c00000000001f0*/
      goto unwind_state_10; /*0xf1c00000000001f0*/
    __eh34_exit_wind_state(10, -1); /*0xf1c00000000001f4*/
    __eh34_enter_wind_state(-1, 13); /*0xf1c00000000001f8*/
    if ( RBX::Network::Replicator::isReplicationContainer(this: replicator, instance: p_instance->_Ptr) ) /*0x14113f983*/
      RBX::Network::Replicator::synchronizeReceivedInstance(this: replicator, instance: p_instance); /*0x14113f992*/
    goto LABEL_150; /*0x14113f992*/
  }
  if ( __eh34_unwind(10) ) /*0xf1c00000000000d4*/
  {
unwind_state_10:
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: &v111); /*0xf1c00000000000d8*/
    __eh34_propagate_exception_into_caller(10, -1); /*0xf1c00000000000dc*/
  }
  __eh34_exit_wind_state(10, -1); /*0xf1c00000000000e0*/
  if ( !reject ) /*0x14113fa4a*/
  {
    __eh34_enter_wind_state(-1, 13); /*0xf1c00000000000cc*/
    isAncestorSentInJoinCache = false; /*0x14113fa50*/
    v64 = replicator->isServerReplicator(this: replicator); /*0x14113fa59*/
    node = (const std::shared_ptr<RBX::Instance> *)instance.first.node_; /*0x14113fa5f*/
    if ( v64 && instance.first.node_->next_ != nullptr ) /*0x14113fa74*/
    {
      next = instance.first.node_->next_[3].next_; /*0x14113fa7a*/
      v67 = RBX::Reflection::Class_getDescriptorPtr<RBX::Workspace>(); /*0x14113fa7e*/
      v68 = node->_Ptr; /*0x14113fa83*/
      if ( LOWORD(next[111].next_) - (unsigned int)v67->index > v67->descendantCount ) /*0x14113fa9f*/
      {
        v71 = RBX::Instance::findFirstAncestorOfType<RBX::Workspace>(this: node->_Ptr); /*0x14113fad4*/
      }
      else
      {
        v69 = v68->descriptor; /*0x14113faa1*/
        v70 = RBX::Reflection::Class_getDescriptorPtr<RBX::Workspace>(); /*0x14113faa5*/
        v71 = nullptr; /*0x14113fac1*/
        if ( v69->index - (unsigned int)v70->index <= v70->descendantCount ) /*0x14113fac6*/
          v71 = (RBX::Workspace *)v68; /*0x14113fac6*/
      }
      megaReplicator = replicator->megaReplicator; /*0x14113fad7*/
      isStreamingEnabled = megaReplicator->isStreamingEnabled; /*0x14113fade*/
      v74 = v71 != nullptr; /*0x14113fae8*/
      RBX::Network::MegaReplicator::shouldInstanceBeSentInJoin( /*0x14113faf6*/
        this: megaReplicator,
        instance: p_instance->_Ptr,
        isDescendantOfWorkspace: v71 != nullptr,
        isStreamingOn: isStreamingEnabled);
      isAncestorSentInJoinCache = RBX::Network::MegaReplicator::isAncestorSentInJoinCache( /*0x14113fb1a*/
                                    this: replicator->megaReplicator,
                                    instance: p_instance->_Ptr,
                                    isDescendantOfWorkspace: v74,
                                    isStreamingOn: isStreamingEnabled,
                                    parent: node->_Ptr);
    }
    else
    {
      replicator->isServerReplicator(this: replicator); /*0x14113fb25*/
    }
    if ( replicator->isServerReplicator(this: replicator) ) /*0x14113fb31*/
    {
      ++node->_Ptr->completeness.numLocalReplicatedChildren; /*0x14113fb3e*/
      RBX::Network::MegaReplicator::enqueueExpectedChildrenChange(this: replicator->megaReplicator, instance: node); /*0x14113fb4b*/
    }
    setAliveForAllReplicators = !replicator->isServerReplicator(this: replicator); /*0x14113fb5e*/
    if ( replicator->isCloudEdit(this: replicator) /*0x14113fb97*/
      || (v76 = RBX::ServiceProvider::find<RBX::ReplicatedFirst>(context: node->_Ptr)) == nullptr
      || node->_Ptr != v76
      && (v77 = node->_Ptr->parent, v76 != v77)
      && (v77 == nullptr || !RBX::Instance::isDescendantOf(this: v77, ancestor: v76)) )
    {
      RBX::Network::Replicator::addReplicationData( /*0x14113fbbc*/
        this: replicator,
        classInfo: v53->classInfo,
        instance: p_instance,
        listenToChanges: true,
        replicateChildren: true,
        setAliveForAllReplicators,
        shallCreateMRD: true);
      RBX::Network::Replicator::synchronizeReceivedInstance(this: replicator, instance: p_instance); /*0x14113fbc7*/
    }
    if ( isAncestorSentInJoinCache ) /*0x14113fbcf*/
    {
      v78 = replicator->megaReplicator; /*0x14113fbd1*/
      isInstanceCacheableForJoin = RBX::Network::MegaReplicator::isInstanceCacheableForJoin( /*0x14113fbde*/
                                     this: v78,
                                     instance: p_instance->_Ptr);
      RBX::Network::MegaReplicator::cacheInstanceForJoin( /*0x14113fbf9*/
        this: v78,
        instance: p_instance,
        listenToChanges: true,
        replicateChildren: true,
        cacheable: isInstanceCacheableForJoin,
        overwriteCommonIdAtCaching: false);
    }
    if ( p_instance->_Ptr == replicator->megaClusterInstance ) /*0x14113fc08*/
      replicator->readyToExchangeTerrainData = true; /*0x14113fc0a*/
    v80 = replicator->megaReplicator; /*0x14113fc11*/
    if ( v80->server == nullptr ) /*0x14113fc1d*/
      RBX::Network::CompletenessTrackerClient::newInstanceAdded(this: &v80->clientCompleteness, instance: p_instance); /*0x14113fc29*/
    if ( (replicator->peerCapability & 0x40) != 0 ) /*0x14113fc3a*/
    {
      if ( v53->isAnAtomicReplicationRoot ) /*0x14113fc40*/
      {
        if ( DFLog::NetworkInstances != 0 ) /*0x14113fc53*/
        {
          v81 = RBX::Guid::toString(this: &p_instance->_Ptr->guid, result: &v137); /*0x14113fc63*/
          __wind /*0xf1c00000000000c0*/
          {
            if ( v81->_Mypair._Myval2._Myres >= 0x10 ) /*0x14113fc6e*/
              v81 = (std::string *)v81->_Mypair._Myval2._Bx._Ptr; /*0x14113fc70*/
            FLog::FastLog( /*0x14113fc84*/
              level: DFLog::NetworkInstances,
              message: "[DFLog::NetworkInstances] Atomic Replication started for %s",
              arg0: v81);
          }
          __unwind
          {
            RBX::Graphics::ProfilerAdorn::Item::~Item(this: (RBX::Graphics::ProfilerAdorn::Item *)&v137); /*0xf1c00000000000b8*/
          }
          if ( v137._Mypair._Myval2._Myres >= 0x10 ) /*0x14113fc95*/
          {
            v82 = v137._Mypair._Myval2._Bx._Ptr; /*0x14113fc9a*/
            if ( v137._Mypair._Myval2._Myres + 1 >= 0x1000 ) /*0x14113fcab*/
            {
              v82 = *((char **)v137._Mypair._Myval2._Bx._Ptr - 1); /*0x14113fcb1*/
              if ( (unsigned __int64)(v137._Mypair._Myval2._Bx._Ptr - v82 - 8) > 0x1F ) /*0x14113fcc0*/
                _invalid_parameter_noinfo_noreturn(); /*0x14113fcc2*/
            }
            operator delete(ptr: v82); /*0x14113fcc9*/
          }
        }
        memset(&deferredTree.allDesendants, 0, sizeof(deferredTree.allDesendants)); /*0x14113fcd1*/
        v83 = p_instance->_Rep; /*0x14113fce2*/
        if ( v83 != nullptr ) /*0x14113fce9*/
        {
          _InterlockedIncrement((volatile signed __int32 *)&v83->_Uses); /*0x14113fceb*/
          v83 = p_instance->_Rep; /*0x14113fcf0*/
        }
        __wind /*0xf1c000000000009c*/
        {
          v84 = p_instance->_Ptr; /*0x14113fcf4*/
          deferredTree.root._Ptr = p_instance->_Ptr; /*0x14113fcf7*/
          deferredTree.root._Rep = v83; /*0x14113fcfe*/
          memscopeNetworkDeferredTrees.parent = RBX::Memory::setCurrentCategory(category: RBX::Memory::NetworkDeferredTrees); /*0x14113fd10*/
          id = v53->id; /*0x14113fd1b*/
          v129.first = id; /*0x14113fd20*/
          v129.second.root = 0; /*0x14113fd27*/
          if ( v83 != nullptr ) /*0x14113fd2f*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&v83->_Uses); /*0x14113fd31*/
            id = v129.first; /*0x14113fd36*/
          }
          __wind /*0xf1c0000000000200*/
          {
            __wind /*0xf1c0000000000208*/
            {
              __wind /*0xf1c0000000000210*/
              {
                *(RBX::Guid *)&v132.x = id; /*0x14113fd3a*/
                *(_QWORD *)&v132.width = v84; /*0x14113fd41*/
                *(_QWORD *)&v132.color = v83; /*0x14113fd48*/
                memset(&v129.second, 0, sizeof(v129.second)); /*0x14113fd4f*/
                memset(&v133, 0, sizeof(v133)); /*0x14113fd63*/
                boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Guid const,RBX::Network::Replicator::DeferredTree>>,RBX::Guid const,RBX::Network::Replicator::DeferredTree,boost::hash<RBX::Guid const>,std::equal_to<RBX::Guid const>>>::emplace_impl<std::pair<RBX::Guid const,RBX::Network::Replicator::DeferredTree>>( /*0x14113fd87*/
                  this: &replicator->deferredInstanceTrees.table_,
                  result: &instance,
                  k: (const RBX::Guid *)&v132.x,
                  <args_0>: (std::pair<RBX::Guid const ,RBX::Network::Replicator::DeferredTree> *)&v132.x);
                std::vector<std::shared_ptr<RBX::GuiBase>>::~vector<std::shared_ptr<RBX::GuiBase>>(this: &v133); /*0x14113fd94*/
                v86 = *(volatile signed __int32 **)&v132.color; /*0x14113fd99*/
                if ( *(_QWORD *)&v132.color != 0 /*0x14113fdb2*/
                  && _InterlockedExchangeAdd((volatile signed __int32 *)(*(_QWORD *)&v132.color + 8LL), 0xFFFFFFFF) == 1 )
                {
                  (**(void (__fastcall ***)(volatile signed __int32 *))v86)(a1: v86); /*0x14113fdba*/
                  if ( _InterlockedExchangeAdd(v86 + 3, 0xFFFFFFFF) == 1 ) /*0x14113fdc9*/
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v86 + 8LL))(a1: v86); /*0x14113fdd1*/
                }
                v87 = v129.second.allDesendants._Mypair._Myval2._Myfirst; /*0x14113fdd5*/
                if ( v129.second.allDesendants._Mypair._Myval2._Myfirst != nullptr ) /*0x14113fddc*/
                {
                  Mylast = v129.second.allDesendants._Mypair._Myval2._Mylast; /*0x14113fde2*/
                  if ( v129.second.allDesendants._Mypair._Myval2._Myfirst != v129.second.allDesendants._Mypair._Myval2._Mylast ) /*0x14113fde9*/
                  {
                    do /*0x14113fe2f*/
                    {
                      v89 = (volatile signed __int32 *)v87->_Rep; /*0x14113fdf0*/
                      if ( v89 != nullptr && _InterlockedExchangeAdd(v89 + 2, 0xFFFFFFFF) == 1 ) /*0x14113fe06*/
                      {
                        (**(void (__fastcall ***)(volatile signed __int32 *))v89)(a1: v89); /*0x14113fe0e*/
                        if ( _InterlockedExchangeAdd(v89 + 3, 0xFFFFFFFF) == 1 ) /*0x14113fe1d*/
                          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v89 + 8LL))(a1: v89); /*0x14113fe25*/
                      }
                      ++v87; /*0x14113fe28*/
                    }
                    while ( v87 != Mylast ); /*0x14113fe2f*/
                    v87 = v129.second.allDesendants._Mypair._Myval2._Myfirst; /*0x14113fe31*/
                  }
                  v90 = v87; /*0x14113fe43*/
                  if ( (((char *)v129.second.allDesendants._Mypair._Myval2._Myend - (char *)v87) & 0xFFFFFFFFFFFFFFF0uLL) >= 0x1000 ) /*0x14113fe4d*/
                  {
                    v87 = (std::shared_ptr<RBX::Instance> *)v87[-1]._Rep; /*0x14113fe53*/
                    if ( (unsigned __int64)((char *)v90 - (char *)v87 - 8) > 0x1F ) /*0x14113fe62*/
                      _invalid_parameter_noinfo_noreturn(); /*0x14113fe64*/
                  }
                  operator delete(ptr: v87); /*0x14113fe6e*/
                  memset(&v129.second.allDesendants, 0, sizeof(v129.second.allDesendants)); /*0x14113fe76*/
                }
                if ( v129.second.root._Rep != nullptr ) /*0x14113fe8b*/
                  std::_Ref_count_base::_Decref(this: v129.second.root._Rep); /*0x14113fe8d*/
                v91 = p_instance->_Rep; /*0x14113fe92*/
                if ( v91 != nullptr ) /*0x14113fe99*/
                {
                  _InterlockedIncrement((volatile signed __int32 *)&v91->_Uses); /*0x14113fe9b*/
                  v91 = p_instance->_Rep; /*0x14113fe9f*/
                }
              }
              __unwind
              {
                std::pair<RBX::Guid const,RBX::Network::Replicator::DeferredTree>::~pair<RBX::Guid const,RBX::Network::Replicator::DeferredTree>(this: (std::pair<RBX::Guid const ,RBX::Network::Replicator::DeferredTree> *)&v132.x); /*0xf1c0000000000220*/
              }
            }
            __unwind
            {
              std::pair<RBX::Guid,RBX::Network::Replicator::DeferredTree>::~pair<RBX::Guid,RBX::Network::Replicator::DeferredTree>(this: &v129); /*0xf1c000000000022c*/
            }
          }
          __unwind
          {
            RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&memscopeNetworkDeferredTrees); /*0xf1c0000000000238*/
          }
          __wind /*0xf1c0000000000240*/
          {
            replicationRoot._Ptr = p_instance->_Ptr; /*0x14113fea6*/
            replicationRoot._Rep = v91; /*0x14113feaa*/
            RBX::Memory::setCurrentCategory(category: memscopeNetworkDeferredTrees.parent); /*0x14113feb2*/
            if ( v83 != nullptr ) /*0x14113febb*/
              std::_Ref_count_base::_Decref(this: v83); /*0x14113fec4*/
          }
          __unwind
          {
            __std_terminate(a1: v92, a2: v106); /*0xf1c0000000000024*/
          }
        }
        __unwind
        {
          RBX::Network::Replicator::DeferredTree::~DeferredTree(this: &deferredTree); /*0xf1c00000000000ac*/
        }
        goto LABEL_150; /*0xf1c00000000000a8*/
      }
      if ( node->_Ptr != nullptr && RBX::DataModel::get(context: node->_Ptr) == nullptr ) /*0x14113fede*/
      {
        RootAncestor = node->_Ptr; /*0x14113fee0*/
        v94 = node->_Ptr->parent; /*0x14113fee3*/
        if ( v94 != nullptr ) /*0x14113feea*/
          RootAncestor = RBX::Instance::getRootAncestor(this: v94); /*0x14113feec*/
        boost::unordered::unordered_map<RBX::Guid const,RBX::Network::Replicator::DeferredTree,boost::hash<RBX::Guid const>,std::equal_to<RBX::Guid const>,std::allocator<std::pair<RBX::Guid const,RBX::Network::Replicator::DeferredTree>>>::find( /*0x14113ff01*/
          this: &replicator->deferredInstanceTrees,
          result: &atomicTreeRoot,
          k: &RootAncestor->guid);
        v95 = atomicTreeRoot.node_; /*0x14113ff06*/
        if ( atomicTreeRoot.node_ != nullptr ) /*0x14113ff0e*/
        {
          v58 = 1; /*0x14113ff10*/
          v96 = *((std::_Ref_count_base **)&atomicTreeRoot.node_->value_base_.data_.data_.align_ + 2); /*0x14113ff13*/
          if ( v96 != nullptr ) /*0x14113ff1a*/
          {
            _InterlockedIncrement((volatile signed __int32 *)&v96->_Uses); /*0x14113ff1c*/
            v96 = *((std::_Ref_count_base **)&v95->value_base_.data_.data_.align_ + 2); /*0x14113ff20*/
          }
          replicationRoot._Ptr = *((RBX::Instance **)&v95->value_base_.data_.data_.align_ + 1); /*0x14113ff28*/
          replicationRoot._Rep = v96; /*0x14113ff2c*/
        }
      }
    }
    RBX::Network::Replicator::assignParent(this: replicator, instance: p_instance->_Ptr, parent: node->_Ptr); /*0x14113ff39*/
LABEL_150:
    v59 = v139; /*0x14113f997*/
    goto LABEL_151; /*0x14113f997*/
  }
  __eh34_enter_wind_state(-1, 13); /*0xf1c0000000000094*/
  v59 = v139; /*0x14113ff43*/
  if ( v139->newInstance ) /*0x14113ff4a*/
  {
    v97 = &p_instance->_Ptr->RBX::GuidItem<RBX::Instance>; /*0x14113ff58*/
    if ( p_instance->_Ptr == nullptr ) /*0x14113ff65*/
      v97 = nullptr; /*0x14113ff65*/
    RBX::GuidItem<RBX::Instance>::Registry::unregister(this: replicator->guidRegistry.px, item: v97); /*0x14113ff70*/
  }
LABEL_151:
  if ( reject ) /*0x14113f9a8*/
    goto LABEL_274; /*0x14113f9a8*/
  v60 = v59->unresolvedInstanceReferences._Mypair._Myval2._Mylast; /*0x14113f9aa*/
  for ( i = v59->unresolvedInstanceReferences._Mypair._Myval2._Myfirst; i != v60; ++i ) /*0x14113f9b8*/
  {
    if ( !replicator->megaReplicatorHaveDisconnected ) /*0x14113f9c7*/
      RBX::Network::MegaReplicator::updateInstanceReferences( /*0x14113f9de*/
        this: replicator->megaReplicator,
        referringInstanceGuid: p_instance->_Ptr->guid,
        instanceGuid: i->first,
        propDesc: i->second);
  }
  if ( (replicator->peerCapability & 0x40) == 0 ) /*0x14113f9f8*/
  {
LABEL_159:
    RBX::Network::NewInstanceItem::resolveForwardReferencesToInstance(replicator, instance: p_instance); /*0x14113fa09*/
    goto LABEL_274; /*0xf1c0000000000268*/
  }
  if ( v58 == 0 ) /*0x14113f9fd*/
  {
    if ( v59->isAnAtomicReplicationRoot ) /*0x14113fa03*/
      goto LABEL_274; /*0x14113fa07*/
    goto LABEL_159; /*0x14113fa07*/
  }
  v98 = RBX::Memory::setCurrentCategory(category: RBX::Memory::NetworkDeferredTrees); /*0x14113ff85*/
  LODWORD(v139) = v98; /*0x14113ff87*/
  __wind /*0xf1c0000000000070*/
  {
    v99 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Guid const,RBX::Network::Replicator::DeferredTree>>,RBX::Guid const,RBX::Network::Replicator::DeferredTree,boost::hash<RBX::Guid const>,std::equal_to<RBX::Guid const>>>::operator[]( /*0x14113ff9c*/
            this: &replicator->deferredInstanceTrees.table_,
            k: &replicationRoot._Ptr->guid);
    p_allDesendants = (std::vector<std::shared_ptr<RBX::Graphics::ShaderProgram>> *)&v99->second.allDesendants; /*0x14113ffa1*/
    v101 = (std::shared_ptr<RBX::Graphics::ShaderProgram> *)v99->second.allDesendants._Mypair._Myval2._Mylast; /*0x14113ffa5*/
    if ( v101 == (std::shared_ptr<RBX::Graphics::ShaderProgram> *)v99->second.allDesendants._Mypair._Myval2._Myend ) /*0x14113ffad*/
    {
      std::vector<std::shared_ptr<RBX::Attachment>>::_Emplace_reallocate<std::shared_ptr<RBX::Attachment> const &>( /*0x14113ffe1*/
        this: p_allDesendants,
        _Whereptr: v101,
        <_Val_0>: (const std::shared_ptr<RBX::Graphics::ShaderProgram> *)p_instance);
    }
    else
    {
      v101->_Ptr = nullptr; /*0x14113ffaf*/
      v101->_Rep = nullptr; /*0x14113ffb2*/
      v102 = v59->instance._Rep; /*0x14113ffb6*/
      if ( v102 != nullptr ) /*0x14113ffbd*/
      {
        _InterlockedIncrement((volatile signed __int32 *)&v102->_Uses); /*0x14113ffbf*/
        v98 = (unsigned int)v139; /*0x14113ffc3*/
      }
      v101->_Ptr = (RBX::Graphics::ShaderProgram *)p_instance->_Ptr; /*0x14113ffcc*/
      v101->_Rep = v59->instance._Rep; /*0x14113ffd3*/
      ++p_allDesendants->_Mypair._Myval2._Mylast; /*0x14113ffd7*/
    }
  }
  __unwind
  {
    RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::VirtualUser,void>::~InstanceMemoryScope<RBX::VirtualUser,void>(this: (RBX::Creatable<RBX::Instance>::InstanceMemoryScope<RBX::File,void> *)&v139); /*0xf1c0000000000080*/
  }
  __wind /*0xf1c0000000000088*/
  {
    RBX::Memory::setCurrentCategory(category: v98); /*0x14113ffe9*/
  }
  __unwind
  {
    __std_terminate(a1: v103, a2: v106); /*0xf1c000000000002c*/
  }
  if ( __eh34_unwind(13) ) /*0xf1c00000000000e8*/
  {
    std::shared_ptr<RBX::Timer<0>>::~shared_ptr<RBX::Timer<0>>(this: (std::shared_ptr<RBX::File> *)&replicationRoot); /*0xf1c00000000000ec*/
    __eh34_propagate_exception_into_caller(13, -1); /*0xf1c00000000000f0*/
  }
LABEL_274:
  __eh34_exit_wind_state(13, -1); /*0xf1c00000000000f4*/
  if ( replicationRoot._Rep != nullptr ) /*0x14113fa1c*/
    std::_Ref_count_base::_Decref(this: replicationRoot._Rep); /*0x14113fa1e*/
  return 1; /*0x14113fa28*/
}

// Address: 0x141141280 | Name: ?schemaReadPropertyGroup@DeserializedNewInstanceItem@Network@RBX@@QEAAXAEAVReplicator@23@AEAVNetworkStream@23@W4PropertyGroup@23@_NAEAV?$unordered_map@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$vector@UDeferredSharedStringSetter@Network@RBX@@V?$allocator@UDeferredSharedStringSetter@Network@RBX@@@std@@@2@U?$hash@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@boost@@U?$equal_to@V?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@@2@V?$allocator@U?$pair@$$CBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@V?$vector@UDeferredSharedStringSetter@Network@RBX@@V?$allocator@UDeferredSharedStringSetter@Network@RBX@@@std@@@2@@std@@@2@@unordered@boost@@AEAUReplicationVariantSizeLimitsMetaData@23@@Z
void __fastcall RBX::Network::DeserializedNewInstanceItem::schemaReadPropertyGroup(
        RBX::Network::DeserializedNewInstanceItem *this,
        RBX::Network::Replicator *replicator,
        RBX::Network::NetworkStream *bitStream,
        RBX::Network::PropertyGroup propertyGroup,
        bool allowDictionaries,
        boost::unordered::unordered_map<std::string,std::vector<RBX::Network::DeferredSharedStringSetter>,boost::hash<std::string >,std::equal_to<std::string >,std::allocator<std::pair<std::string const ,std::vector<RBX::Network::DeferredSharedStringSetter> > > > *deferredSharedStrings,
        RBX::Network::ReplicationVariantSizeLimitsMetaData *metaData)
{
  RBX::Network::PropertyGroup v7; // esi
  unsigned __int16 beginPropertyId; // r12
  unsigned __int8 v11; // cl
  bool v12; // r14
  const RBX::Network::NetworkSchema::ClassInfo *classInfo; // rax
  unsigned __int16 v14; // bx
  bool newInstance; // r8
  const RBX::Network::NetworkSchema *networkSchema; // rax
  RBX::Network::NetworkSchema::ClassProperty *Myfirst; // r9
  RBX::Network::NetworkSchema::ClassProperty *v18; // rsi
  unsigned __int16 v19; // dx
  const RBX::Reflection::PropertyDescriptor *localDescriptor; // rcx
  RBX::Network::PropValuePair *v21; // r8
  unsigned __int64 v22; // r9
  RBX::Network::PropValuePair *Mylast; // rdx
  std::vector<RBX::Network::PropValuePair> *p_propValueList; // rcx
  __int64 v25; // rcx
  RBX::Network::PropValuePair *v26; // r9
  unsigned __int16 propertyNetworkId; // dx
  RBX::Instance *Ptr; // rcx
  const RBX::Reflection::Type **p_type; // rbx
  const RBX::Reflection::Type *v30; // rbx
  std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *v31; // rdx
  const RBX::Reflection::PropertyDescriptor *v32; // rsi
  RBX::Instance *v33; // r15
  unsigned int Mysize; // r14d
  const RBX::Reflection::Type *type; // rbx
  RBX::ProtectedString *p_ps; // rcx
  const RBX::Reflection::Type *v37; // rbx
  __int64 v38; // [rsp+0h] [rbp-100h] BYREF
  unsigned __int8 deltaId[8]; // [rsp+40h] [rbp-C0h] BYREF
  RBX::Guid unresolvedGuid; // [rsp+48h] [rbp-B8h] BYREF
  RBX::ProtectedString ps; // [rsp+50h] [rbp-B0h] BYREF
  unsigned __int16 v42; // [rsp+78h] [rbp-88h]
  std::optional<Luau::TypeVar const *> v43; // [rsp+80h] [rbp-80h] BYREF
  RBX::SharedString v44; // [rsp+90h] [rbp-70h] BYREF
  RBX::Network::PropValuePair pExceptionObject; // [rsp+A0h] [rbp-60h] BYREF

  v7 = propertyGroup; /*0x1411412a6*/
  if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: deltaId, numberOfBytesToRead: 1u) ) /*0x1411412c7*/
  {
    std::string::string(this: (std::string *)&ps, _Ptr: "readFast past end for uint8_t"); /*0x14114171c*/
    __eh34_enter_wind_state(-1, 0); /*0xf1c0000000000014*/
    RBX::network_stream_exception::network_stream_exception( /*0x14114172b*/
      this: (RBX::network_stream_exception *)&pExceptionObject,
      m: (const std::string *)&ps);
    throw (RBX::network_stream_exception *)&pExceptionObject; /*0x14114173b*/
  }
  beginPropertyId = this->classInfo->beginPropertyId; /*0x1411412d1*/
  v11 = deltaId[0]; /*0x1411412d6*/
  if ( deltaId[0] != RBX::Network::NetworkSchema::kInvalidRelativeNetworkId )
  {
    v12 = allowDictionaries; /*0x1411412f4*/
    while ( 1 )
    {
      classInfo = this->classInfo; /*0x141141300*/
      v14 = classInfo->beginPropertyId + v11; /*0x141141307*/
      if ( v14 >= classInfo->endPropertyId || v14 < beginPropertyId )
        RBX::throw_runtime_error(fmt: "Invalid property id: out of bounds or out of order");
      newInstance = this->newInstance; /*0x14114131f*/
      if ( !newInstance ) /*0x141141327*/
      {
        RBX::Network::DeserializedNewInstanceItem::fillDefaultValues( /*0x14114133b*/
          this,
          replicator,
          propertyGroup: v7,
          fromId: beginPropertyId,
          toId: classInfo->beginPropertyId + v11);
        newInstance = this->newInstance; /*0x141141340*/
      }
      beginPropertyId = v14 + 1; /*0x14114134f*/
      networkSchema = replicator->networkSchema; /*0x141141353*/
      Myfirst = networkSchema->classPropertyByNetworkId._Mypair._Myval2._Myfirst; /*0x14114135a*/
      if ( v14 >= (unsigned __int64)(networkSchema->classPropertyByNetworkId._Mypair._Myval2._Mylast - Myfirst) ) /*0x14114138c*/
        v18 = nullptr; /*0x141141398*/
      else
        v18 = &Myfirst[v14]; /*0x141141392*/
      if ( !newInstance || v18->valueType.valueFormat == NetworkValueFormat_InstanceGuid ) /*0x1411413a8*/
      {
        v21 = this->propValueList._Mypair._Myval2._Myfirst; /*0x1411413fd*/
        if ( v21 == this->propValueList._Mypair._Myval2._Mylast ) /*0x141141405*/
        {
          v22 = this->classInfo->endPropertyId - (unsigned int)this->classInfo->beginPropertyId; /*0x141141417*/
          if ( v22 > this->propValueList._Mypair._Myval2._Myend - v21 ) /*0x141141438*/
            std::vector<RBX::Network::PropValuePair>::_Reallocate_exactly( /*0x141141441*/
              this: &this->propValueList,
              _Newcapacity: (unsigned int)v22);
        }
        pExceptionObject.descriptor = nullptr; /*0x141141446*/
        pExceptionObject.value._type = RBX::Reflection::Type::getSingleton<void>(); /*0x14114144f*/
        pExceptionObject.value.value.holder = nullptr; /*0x141141453*/
        pExceptionObject.useDefaultValue = false; /*0x141141457*/
        __wind /*0xf1c0000000000074*/
        {
          Mylast = this->propValueList._Mypair._Myval2._Mylast; /*0x14114145b*/
          p_propValueList = &this->propValueList; /*0x141141463*/
          if ( Mylast == this->propValueList._Mypair._Myval2._Myend ) /*0x14114146b*/
          {
            std::vector<RBX::Network::PropValuePair>::_Emplace_reallocate<RBX::Network::PropValuePair>( /*0x141141479*/
              this: p_propValueList,
              _Whereptr: Mylast,
              <_Val_0>: &pExceptionObject);
          }
          else
          {
            std::_Default_allocator_traits<std::allocator<RBX::Network::PropValuePair>>::construct<RBX::Network::PropValuePair,RBX::Network::PropValuePair>( /*0x14114146d*/
              __formal: (std::allocator<RBX::Network::PropValuePair> *)p_propValueList,
              _Ptr: Mylast,
              <_Args_0>: &pExceptionObject);
            ++this->propValueList._Mypair._Myval2._Mylast; /*0x141141472*/
          }
        }
        __unwind
        {
          std::pair<RBX::Reflection::PropertyDescriptor const *,RBX::Reflection::Variant>::~pair<RBX::Reflection::PropertyDescriptor const *,RBX::Reflection::Variant>(this: (std::pair<unsigned __int64,RBX::LuaWebService::CachedLuaWebServiceInfo> *)&pExceptionObject); /*0xf1c0000000000084*/
        }
        __wind /*0xf1c000000000008c*/
        {
          if ( pExceptionObject.value.value.holder != nullptr ) /*0x141141486*/
            pExceptionObject.value.value.holder->destruct(a1: pExceptionObject.value.value.data); /*0x141141490*/
        }
        __unwind
        {
          __std_terminate(a1: v25, a2: &v38); /*0x142f39fa8*/
        }
        v26 = this->propValueList._Mypair._Myval2._Mylast; /*0x141141493*/
        v26[-1].descriptor = v18->localDescriptor; /*0x14114149b*/
        v26[-1].useDefaultValue = false; /*0x14114149f*/
        unresolvedGuid.scope.peerId.peerId = -1; /*0x1411414a4*/
        unresolvedGuid.index = 0; /*0x1411414ac*/
        propertyNetworkId = v18->propertyNetworkId; /*0x1411414b1*/
        Ptr = this->instance._Ptr; /*0x1411414b4*/
        ps.sharedSource.flyweight.h.h = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *)&v18->valueType; /*0x1411414bc*/
        p_type = &v26[-1].value._type; /*0x1411414c1*/
        *(_QWORD *)&ps.sharedSource.readCount = (char *)v26 - 88; /*0x1411414c5*/
        ps.sharedBytecode.flyweight.h.h = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *)v18->localDescriptor; /*0x1411414ce*/
        *(_QWORD *)&ps.sharedBytecode.readCount = Ptr; /*0x1411414d3*/
        *(_QWORD *)&ps.replicates = &unresolvedGuid; /*0x1411414dd*/
        v42 = propertyNetworkId; /*0x1411414e2*/
        RBX::Network::Replicator::schemaReadValue<RBX::Network::VariantValueSetter>( /*0x141141516*/
          this: replicator,
          inBitStream: bitStream,
          valueType: &v18->valueType,
          useDictionaries: v12,
          out: (RBX::Network::VariantValueSetter *)&ps,
          depth: 0,
          deferredSharedStrings,
          replicationMetaData: metaData);
        v30 = *p_type; /*0x14114151b*/
        if ( v30 == RBX::Reflection::Type::getSingleton<void>() && unresolvedGuid.scope.peerId.peerId != -1 ) /*0x14114152d*/
        {
          v43.___u0 = ($E589B3A0A1611D1A6FE4785D3F167C74)unresolvedGuid; /*0x141141538*/
          *(_QWORD *)&v43._Has_value = v18->localDescriptor; /*0x141141540*/
          v31 = this->unresolvedInstanceReferences._Mypair._Myval2._Mylast; /*0x141141544*/
          if ( v31 == this->unresolvedInstanceReferences._Mypair._Myval2._Myend ) /*0x141141552*/
          {
            std::vector<std::pair<RBX::Ray const *,float>>::_Emplace_reallocate<std::pair<RBX::Ray const *,float>>( /*0x141141566*/
              this: (std::vector<std::optional<Luau::TypeVar const *>> *)&this->unresolvedInstanceReferences,
              _Whereptr: (std::optional<Luau::TypeVar const *> *const)v31,
              <_Val_0>: &v43);
          }
          else
          {
            *(std::optional<Luau::TypeVar const *> *)v31 = v43; /*0x141141558*/
            ++this->unresolvedInstanceReferences._Mypair._Myval2._Mylast; /*0x14114155b*/
          }
        }
      }
      else
      {
        v19 = v18->propertyNetworkId; /*0x1411413aa*/
        localDescriptor = v18->localDescriptor; /*0x1411413ad*/
        ps.sharedSource.flyweight.h.h = (const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *)this->instance._Ptr; /*0x1411413b5*/
        *(_QWORD *)&ps.sharedSource.readCount = localDescriptor; /*0x1411413ba*/
        LOWORD(ps.sharedBytecode.flyweight.h.h) = v19; /*0x1411413bf*/
        RBX::Network::Replicator::schemaReadValue<RBX::Network::InstanceValueSetter>( /*0x1411413f3*/
          this: replicator,
          inBitStream: bitStream,
          valueType: &v18->valueType,
          useDictionaries: v12,
          out: (RBX::Network::InstanceValueSetter *)&ps,
          depth: 0,
          deferredSharedStrings,
          replicationMetaData: metaData);
      }
      if ( !DFFlag::ReportSharedStringBreakdown.value ) /*0x141141572*/
        goto LABEL_45; /*0x141141572*/
      v32 = v18->localDescriptor; /*0x141141578*/
      if ( v32 == nullptr ) /*0x14114157f*/
        goto LABEL_45; /*0x14114157f*/
      v33 = this->instance._Ptr; /*0x141141585*/
      Mysize = 0; /*0x141141589*/
      type = v32->type; /*0x14114158c*/
      if ( type == RBX::Reflection::Type::getSingleton<RBX::SharedString>() ) /*0x141141598*/
        break; /*0x141141598*/
      v37 = v32->type; /*0x1411415cd*/
      if ( v37 == RBX::Reflection::Type::getSingleton<RBX::ProtectedString>() ) /*0x1411415d9*/
      {
        (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::ProtectedString *, RBX::Instance *))v32[1].dtr_Descriptor /*0x1411415ea*/
         + 3))(
          a1: v32[1].__vftable,
          a2: &ps,
          a3: v33);
        __wind /*0xf1c0000000000044*/
        {
          if ( RBX::ModuleScript::PerVMState::getCurrentState(this: (ScriptingAnalysisScriptItem *)&ps) == 1 ) /*0x1411415fb*/
            Mysize = RBX::SharedString::getContents(this: &ps.sharedSource)->_Mypair._Myval2._Mysize; /*0x141141607*/
          if ( RBX::ModuleScript::PerVMState::getCurrentState(this: (ScriptingAnalysisScriptItem *)&ps.sharedBytecode) == 1 ) /*0x141141618*/
            Mysize = RBX::SharedString::getContents(this: &ps.sharedBytecode)->_Mypair._Myval2._Mysize; /*0x141141624*/
        }
        __unwind
        {
          RBX::ProtectedString::~ProtectedString(this: (RBX::Scripting::DebuggerEvalExpression *)&ps); /*0xf1c000000000003c*/
        }
        boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &ps.sharedBytecode.flyweight.h); /*0x14114162d*/
        p_ps = &ps; /*0x141141632*/
        goto LABEL_42; /*0x141141632*/
      }
LABEL_44:
      v12 = allowDictionaries; /*0x141141654*/
LABEL_45:
      if ( !RBX::Network::NetworkStream::readBytes(this: bitStream, inOutByteArray: deltaId, numberOfBytesToRead: 1u) ) /*0x141141672*/
      {
        std::string::string(this: (std::string *)&ps, _Ptr: "readFast past end for uint8_t"); /*0x1411416de*/
        __eh34_enter_wind_state(-1, 0); /*0xf1c000000000001c*/
        RBX::network_stream_exception::network_stream_exception( /*0x1411416ed*/
          this: (RBX::network_stream_exception *)&pExceptionObject,
          m: (const std::string *)&ps);
        throw (RBX::network_stream_exception *)&pExceptionObject; /*0x1411416fd*/
      }
      v11 = deltaId[0]; /*0x141141674*/
      v7 = propertyGroup; /*0x14114167f*/
      if ( deltaId[0] == RBX::Network::NetworkSchema::kInvalidRelativeNetworkId ) /*0x14114168c*/
        goto LABEL_47; /*0x14114168c*/
    }
    (*((void (__fastcall **)(RBX::Reflection::PropertyDescriptor_vtbl *, RBX::SharedString *, RBX::Instance *))v32[1].dtr_Descriptor /*0x1411415a8*/
     + 3))(
      a1: v32[1].__vftable,
      a2: &v44,
      a3: v33);
    __wind /*0xf1c000000000005c*/
    {
      if ( RBX::ModuleScript::PerVMState::getCurrentState(this: (ScriptingAnalysisScriptItem *)&v44) == 1 ) /*0x1411415b8*/
        Mysize = RBX::SharedString::getContents(this: &v44)->_Mypair._Myval2._Mysize; /*0x1411415c3*/
    }
    __unwind
    {
      RBX::SharedString::~SharedString(this: &v44); /*0xf1c0000000000054*/
    }
    p_ps = (RBX::ProtectedString *)&v44; /*0x1411415c7*/
LABEL_42:
    boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,boost::mpl::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<boost::mpl::na,boost::mpl::na,boost::mpl::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>(this: &p_ps->sharedSource.flyweight.h); /*0x141141637*/
    if ( Mysize != 0 ) /*0x14114163f*/
      RBX::Network::Replicator::registerSharedStringUsage( /*0x14114164f*/
        this: replicator,
        desc: this->instance._Ptr->descriptor,
        uncompressedSize: Mysize);
    goto LABEL_44; /*0x14114164f*/
  }
LABEL_47:
  if ( !this->newInstance ) /*0x141141696*/
    RBX::Network::DeserializedNewInstanceItem::fillDefaultValues( /*0x1411416b2*/
      this,
      replicator,
      propertyGroup: v7,
      fromId: beginPropertyId,
      toId: this->classInfo->endPropertyId);
}

// Address: 0x141141b90 | Name: ?updateUnresolvedReferenceToMegareplicator@DeserializedNewInstanceItem@Network@RBX@@QEAAXAEAVReplicator@23@@Z
void __fastcall RBX::Network::DeserializedNewInstanceItem::updateUnresolvedReferenceToMegareplicator(
        RBX::Network::DeserializedNewInstanceItem *this,
        RBX::Network::Replicator *replicator)
{
  std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *Myfirst; // rbx
  std::pair<RBX::Guid,RBX::Reflection::PropertyDescriptor const *> *Mylast; // rbp

  Myfirst = this->unresolvedInstanceReferences._Mypair._Myval2._Myfirst; /*0x141141ba4*/
  Mylast = this->unresolvedInstanceReferences._Mypair._Myval2._Mylast; /*0x141141bab*/
  if ( Myfirst == Mylast ) /*0x141141bb8*/
  {
    this->unresolvedInstanceReferences._Mypair._Myval2._Mylast = Myfirst; /*0x141141bfa*/
  }
  else
  {
    do /*0x141141beb*/
    {
      if ( !replicator->megaReplicatorHaveDisconnected ) /*0x141141bc7*/
        RBX::Network::MegaReplicator::updateInstanceReferences( /*0x141141bdf*/
          this: replicator->megaReplicator,
          referringInstanceGuid: this->instance._Ptr->guid,
          instanceGuid: Myfirst->first,
          propDesc: Myfirst->second);
      ++Myfirst; /*0x141141be4*/
    }
    while ( Myfirst != Mylast ); /*0x141141beb*/
    this->unresolvedInstanceReferences._Mypair._Myval2._Mylast = this->unresolvedInstanceReferences._Mypair._Myval2._Myfirst; /*0x141141bf1*/
  }
}

// END DeserializedNewInstanceItem part 1/1, 8 functions
