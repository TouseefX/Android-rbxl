// Crypto -- 2022 Studio + full PDB
// tier 3, 20 functions


// Address: 0x1401b39c0 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kHashPrimeSecure__
void RBX::Security::Crypto::_dynamic_initializer_for__kHashPrimeSecure__()
{
  ; /*0x1401b39c0*/
}

// Address: 0x1401b39d0 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure1__
void RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure1__()
{
  ; /*0x1401b39d0*/
}

// Address: 0x1401b39e0 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure2__
void RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure2__()
{
  ; /*0x1401b39e0*/
}

// Address: 0x1401b39f0 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kTeaDeltaSecure__
void RBX::Security::Crypto::_dynamic_initializer_for__kTeaDeltaSecure__()
{
  ; /*0x1401b39f0*/
}

// Address: 0x1401b3a00 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kTeaRoundsSecure__
void RBX::Security::Crypto::_dynamic_initializer_for__kTeaRoundsSecure__()
{
  ; /*0x1401b3a00*/
}

// Address: 0x1401b6c70 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kHashPrimeSecure___0
void RBX::Security::Crypto::_dynamic_initializer_for__kHashPrimeSecure___0()
{
  ; /*0x1401b6c70*/
}

// Address: 0x1401b6c80 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure1___0
void RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure1___0()
{
  ; /*0x1401b6c80*/
}

// Address: 0x1401b6c90 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure2___0
void RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure2___0()
{
  ; /*0x1401b6c90*/
}

// Address: 0x1401b6ca0 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kTeaDeltaSecure___0
void RBX::Security::Crypto::_dynamic_initializer_for__kTeaDeltaSecure___0()
{
  ; /*0x1401b6ca0*/
}

// Address: 0x1401b6cb0 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kTeaRoundsSecure___0
void RBX::Security::Crypto::_dynamic_initializer_for__kTeaRoundsSecure___0()
{
  ; /*0x1401b6cb0*/
}

// Address: 0x1401bc4d0 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kHashPrimeSecure___1
void RBX::Security::Crypto::_dynamic_initializer_for__kHashPrimeSecure___1()
{
  ; /*0x1401bc4d0*/
}

// Address: 0x1401bc4e0 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure1___1
void RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure1___1()
{
  ; /*0x1401bc4e0*/
}

// Address: 0x1401bc4f0 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure2___1
void RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure2___1()
{
  ; /*0x1401bc4f0*/
}

// Address: 0x1401bc500 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kTeaDeltaSecure___1
void RBX::Security::Crypto::_dynamic_initializer_for__kTeaDeltaSecure___1()
{
  ; /*0x1401bc500*/
}

// Address: 0x1401bc510 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kTeaRoundsSecure___1
void RBX::Security::Crypto::_dynamic_initializer_for__kTeaRoundsSecure___1()
{
  ; /*0x1401bc510*/
}

// Address: 0x1401c8020 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kHashPrimeSecure___2
void RBX::Security::Crypto::_dynamic_initializer_for__kHashPrimeSecure___2()
{
  ; /*0x1401c8020*/
}

// Address: 0x1401c8030 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure1___2
void RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure1___2()
{
  ; /*0x1401c8030*/
}

// Address: 0x1401c8040 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure2___2
void RBX::Security::Crypto::_dynamic_initializer_for__kSumSecure2___2()
{
  ; /*0x1401c8040*/
}

// Address: 0x1401c8050 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kTeaDeltaSecure___2
void RBX::Security::Crypto::_dynamic_initializer_for__kTeaDeltaSecure___2()
{
  ; /*0x1401c8050*/
}

// Address: 0x1401c8060 | Name: RBX::Security::Crypto::_dynamic_initializer_for__kTeaRoundsSecure___2
void RBX::Security::Crypto::_dynamic_initializer_for__kTeaRoundsSecure___2()
{
  ; /*0x1401c8060*/
}

// END Crypto part 1/1, 20 functions
