// _free_o -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 400 functions, part 3 of 7


// Address: 0x102ce9f00 | Name: _OSSL_PARAM_set_all_unmodified
void __fastcall OSSL_PARAM_set_all_unmodified(_QWORD *a1)
{
  _QWORD *v1; // rdi
  bool v2; // zf

  if ( a1 != nullptr && *a1 != 0 ) /*0x102ce9f09*/
  {
    v1 = a1 + 5; /*0x102ce9f0f*/
    do /*0x102ce9f30*/
    {
      *(v1 - 1) = -1; /*0x102ce9f20*/
      v2 = *v1 == 0; /*0x102ce9f28*/
      v1 += 5; /*0x102ce9f2c*/
    }
    while ( !v2 ); /*0x102ce9f30*/
  }
}

// Address: 0x102ce9f40 | Name: _OSSL_PARAM_get_int
__int64 OSSL_PARAM_get_int()
{
  return OSSL_PARAM_get_int32(); /*0x102ce9f44*/
}

// Address: 0x102ce9f50 | Name: _OSSL_PARAM_get_int32
__int64 __fastcall OSSL_PARAM_get_int32(__int64 a1, char *a2)
{
  int v2; // esi
  unsigned __int64 *v3; // rax
  int v4; // ecx
  __int64 v5; // rcx
  int v6; // eax
  unsigned int v7; // ebx
  __int64 v8; // rsi
  __int64 v10; // rcx
  int v11; // esi
  __m128d v12; // xmm0
  unsigned __int64 v13; // rax

  if ( a2 == nullptr || a1 == 0 ) /*0x102ce9f5f*/
  {
    ERR_new(); /*0x102ce9f66*/
    v2 = 395; /*0x102ce9f79*/
LABEL_11:
    ERR_set_debug(__s: "crypto/params.c", a2: v2, a3: "OSSL_PARAM_get_int32"); /*0x102ce9fda*/
    v7 = 0; /*0x102ce9fdf*/
    v8 = 786690; /*0x102ce9fe6*/
LABEL_12:
    ERR_set_error(a1: 15, a2: v8, a3: 0); /*0x102ce9feb*/
    return v7; /*0x102ce9ffc*/
  }
  v3 = *(unsigned __int64 **)(a1 + 16); /*0x102ce9f80*/
  if ( v3 == nullptr ) /*0x102ce9f87*/
  {
    ERR_new(); /*0x102ce9fc2*/
    v2 = 400; /*0x102ce9fd5*/
    goto LABEL_11; /*0x102ce9fd5*/
  }
  v4 = *(_DWORD *)(a1 + 8); /*0x102ce9f89*/
  if ( v4 == 3 ) /*0x102ce9f8f*/
  {
    if ( *(_QWORD *)(a1 + 24) != 8 ) /*0x102cea03d*/
    {
      ERR_new(); /*0x102cea0c5*/
      ERR_set_debug(__s: "crypto/params.c", a2: 464, a3: "OSSL_PARAM_get_int32"); /*0x102cea0dd*/
      v7 = 0; /*0x102cea0e2*/
      v8 = 130; /*0x102cea0e9*/
      goto LABEL_12; /*0x102cea0ee*/
    }
    v12 = (__m128d)*v3; /*0x102cea043*/
    if ( v12.f64[0] >= -2147483648.0 /*0x102cea073*/
      && v12.f64[0] <= 2147483647.0
      && v12.f64[0] == _mm_cvtepi32_pd(_mm_cvttpd_epi32(v12)).f64[0] )
    {
      v6 = (int)v12.f64[0]; /*0x102cea077*/
      goto LABEL_23; /*0x102cea077*/
    }
    ERR_new(); /*0x102cea0f3*/
    v11 = 461; /*0x102cea106*/
    goto LABEL_33; /*0x102cea10b*/
  }
  if ( v4 == 2 ) /*0x102ce9f98*/
  {
    v10 = *(_QWORD *)(a1 + 24); /*0x102ce9ffd*/
    if ( v10 == 8 ) /*0x102cea005*/
    {
      v13 = *v3; /*0x102cea10d*/
      if ( v13 <= 0x7FFFFFFF ) /*0x102cea116*/
      {
LABEL_31:
        *(_DWORD *)a2 = v13; /*0x102cea13d*/
        return 1; /*0x102cea144*/
      }
      ERR_new(); /*0x102cea118*/
      v11 = 444; /*0x102cea12b*/
    }
    else
    {
      if ( v10 != 4 ) /*0x102cea00f*/
        return general_get_int(a1, a2, a3: 4u); /*0x102cea00f*/
      v6 = *(_DWORD *)v3; /*0x102cea015*/
      if ( v6 >= 0 ) /*0x102cea019*/
        goto LABEL_23; /*0x102cea019*/
      ERR_new(); /*0x102cea01b*/
      v11 = 436; /*0x102cea02e*/
    }
LABEL_33:
    ERR_set_debug(__s: "crypto/params.c", a2: v11, a3: "OSSL_PARAM_get_int32"); /*0x102cea161*/
    v7 = 0; /*0x102cea166*/
    v8 = 126; /*0x102cea16d*/
    goto LABEL_12; /*0x102cea172*/
  }
  if ( v4 != 1 ) /*0x102ce9f9d*/
  {
    ERR_new(); /*0x102cea087*/
    ERR_set_debug(__s: "crypto/params.c", a2: 468, a3: "OSSL_PARAM_get_int32"); /*0x102cea09f*/
    v7 = 0; /*0x102cea0a4*/
    v8 = 129; /*0x102cea0ab*/
    goto LABEL_12; /*0x102cea0b0*/
  }
  v5 = *(_QWORD *)(a1 + 24); /*0x102ce9fa3*/
  if ( v5 == 8 ) /*0x102ce9fab*/
  {
    v13 = *v3; /*0x102cea132*/
    if ( (int)v13 == v13 ) /*0x102cea13b*/
      goto LABEL_31; /*0x102cea13b*/
    ERR_new(); /*0x102cea149*/
    v11 = 418; /*0x102cea15c*/
    goto LABEL_33; /*0x102cea15c*/
  }
  if ( v5 == 4 ) /*0x102ce9fb5*/
  {
    v6 = *(_DWORD *)v3; /*0x102ce9fbb*/
LABEL_23:
    *(_DWORD *)a2 = v6; /*0x102cea07b*/
    return 1; /*0x102cea082*/
  }
  return general_get_int(a1, a2, a3: 4u); /*0x102ce9ffa*/
}

// Address: 0x102cea180 | Name: _OSSL_PARAM_set_int
__int64 OSSL_PARAM_set_int()
{
  return OSSL_PARAM_set_int32(); /*0x102cea184*/
}

// Address: 0x102cea190 | Name: _OSSL_PARAM_set_int32
__int64 __fastcall OSSL_PARAM_set_int32(__int64 a1, int a2)
{
  int v2; // eax
  _QWORD *v3; // rax
  unsigned int v4; // ebx
  __int64 v5; // rcx
  __int64 v6; // rsi
  __int64 v8; // rcx
  double *v9; // rax
  int v10[3]; // [rsp+0h] [rbp-Ch] BYREF

  v10[0] = a2; /*0x102cea196*/
  if ( a1 == 0 ) /*0x102cea19c*/
  {
    ERR_new(); /*0x102cea1dc*/
    ERR_set_debug(__s: "crypto/params.c", a2: 475, a3: "OSSL_PARAM_set_int32"); /*0x102cea1f4*/
    v4 = 0; /*0x102cea1f9*/
    v6 = 786690; /*0x102cea200*/
    goto LABEL_8; /*0x102cea200*/
  }
  *(_QWORD *)(a1 + 32) = 0; /*0x102cea19e*/
  v2 = *(_DWORD *)(a1 + 8); /*0x102cea1a6*/
  if ( v2 != 1 ) /*0x102cea1ac*/
  {
    if ( v2 == 2 && a2 >= 0 ) /*0x102cea21f*/
    {
      *(_QWORD *)(a1 + 32) = 4; /*0x102cea226*/
      v3 = *(_QWORD **)(a1 + 16); /*0x102cea22e*/
      v4 = 1; /*0x102cea232*/
      if ( v3 == nullptr ) /*0x102cea23a*/
        return v4; /*0x102cea23a*/
      v8 = *(_QWORD *)(a1 + 24); /*0x102cea23c*/
      if ( v8 == 8 ) /*0x102cea244*/
      {
        *(_QWORD *)(a1 + 32) = 8; /*0x102cea2cf*/
        *v3 = (unsigned int)a2; /*0x102cea2d9*/
        return v4; /*0x102cea2dc*/
      }
      if ( v8 == 4 ) /*0x102cea24e*/
        goto LABEL_6; /*0x102cea24e*/
      return (unsigned int)general_set_int(a1, a2: v10, a3: 4u); /*0x102cea24e*/
    }
    if ( v2 == 3 ) /*0x102cea265*/
    {
      *(_QWORD *)(a1 + 32) = 8; /*0x102cea267*/
      v9 = *(double **)(a1 + 16); /*0x102cea26f*/
      v4 = 1; /*0x102cea273*/
      if ( v9 == nullptr ) /*0x102cea27b*/
        return v4; /*0x102cea27b*/
      if ( *(_QWORD *)(a1 + 24) == 8 ) /*0x102cea282*/
      {
        *v9 = (double)a2; /*0x102cea288*/
        return v4; /*0x102cea28c*/
      }
      ERR_new(); /*0x102cea2e1*/
      ERR_set_debug(__s: "crypto/params.c", a2: 532, a3: "OSSL_PARAM_set_int32"); /*0x102cea2f9*/
      v4 = 0; /*0x102cea2fe*/
      v6 = 130; /*0x102cea305*/
    }
    else
    {
      ERR_new(); /*0x102cea28e*/
      ERR_set_debug(__s: "crypto/params.c", a2: 536, a3: "OSSL_PARAM_set_int32"); /*0x102cea2a6*/
      v4 = 0; /*0x102cea2ab*/
      v6 = 129; /*0x102cea2b2*/
    }
LABEL_8:
    ERR_set_error(a1: 15, a2: v6, a3: 0); /*0x102cea205*/
    return v4; /*0x102cea209*/
  }
  *(_QWORD *)(a1 + 32) = 4; /*0x102cea1ae*/
  v3 = *(_QWORD **)(a1 + 16); /*0x102cea1b6*/
  v4 = 1; /*0x102cea1ba*/
  if ( v3 != nullptr ) /*0x102cea1c2*/
  {
    v5 = *(_QWORD *)(a1 + 24); /*0x102cea1c4*/
    if ( v5 == 8 ) /*0x102cea1cc*/
    {
      *(_QWORD *)(a1 + 32) = 8; /*0x102cea2bc*/
      *v3 = a2; /*0x102cea2c7*/
      return v4; /*0x102cea2ca*/
    }
    if ( v5 == 4 ) /*0x102cea1d6*/
    {
LABEL_6:
      *(_DWORD *)v3 = a2; /*0x102cea1d8*/
      return v4; /*0x102cea1da*/
    }
    return (unsigned int)general_set_int(a1, a2: v10, a3: 4u); /*0x102cea250*/
  }
  return v4; /*0x102cea214*/
}

// Address: 0x102cea310 | Name: _OSSL_PARAM_construct_int
__int64 __fastcall OSSL_PARAM_construct_int(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = a2; /*0x102cea317*/
  *(_DWORD *)(a1 + 8) = 1; /*0x102cea31a*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102cea321*/
  *(_QWORD *)(a1 + 24) = 4; /*0x102cea325*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102cea32d*/
  return a1; /*0x102cea335*/
}

// Address: 0x102cea340 | Name: _OSSL_PARAM_get_uint
__int64 __fastcall OSSL_PARAM_get_uint(__int64 a1, __int64 a2)
{
  return OSSL_PARAM_get_uint32(a1, a2); /*0x102cea344*/
}

// Address: 0x102cea350 | Name: _OSSL_PARAM_get_uint32
__int64 __fastcall OSSL_PARAM_get_uint32(__int64 a1, char *a2)
{
  int v2; // esi
  double *v3; // rax
  int v4; // ecx
  __int64 v5; // rcx
  int v6; // eax
  unsigned int v7; // ebx
  __int64 v8; // rsi
  double v10; // xmm0_8
  double v11; // rax
  __int64 v12; // rcx
  double v13; // rbx
  int v14; // esi
  int v15; // esi

  if ( a2 == nullptr || a1 == 0 ) /*0x102cea35f*/
  {
    ERR_new(); /*0x102cea366*/
    v2 = 549; /*0x102cea379*/
LABEL_11:
    ERR_set_debug(__s: "crypto/params.c", a2: v2, a3: "OSSL_PARAM_get_uint32"); /*0x102cea3da*/
    v7 = 0; /*0x102cea3df*/
    v8 = 786690; /*0x102cea3e6*/
LABEL_12:
    ERR_set_error(a1: 15, a2: v8, a3: 0); /*0x102cea3eb*/
    return v7; /*0x102cea3fc*/
  }
  v3 = *(double **)(a1 + 16); /*0x102cea380*/
  if ( v3 == nullptr ) /*0x102cea387*/
  {
    ERR_new(); /*0x102cea3c2*/
    v2 = 554; /*0x102cea3d5*/
    goto LABEL_11; /*0x102cea3d5*/
  }
  v4 = *(_DWORD *)(a1 + 8); /*0x102cea389*/
  if ( v4 == 1 ) /*0x102cea38f*/
  {
    v12 = *(_QWORD *)(a1 + 24); /*0x102cea46a*/
    if ( v12 == 8 ) /*0x102cea472*/
    {
      v13 = *v3; /*0x102cea500*/
      if ( HIDWORD(*(_QWORD *)v3) == 0 ) /*0x102cea50a*/
      {
        *(_DWORD *)a2 = LODWORD(v13); /*0x102cea50c*/
        return 1; /*0x102cea513*/
      }
      ERR_new(); /*0x102cea530*/
      if ( v13 >= 0.0 ) /*0x102cea546*/
      {
        v14 = 600; /*0x102cea548*/
        goto LABEL_33; /*0x102cea54d*/
      }
      v15 = 598; /*0x102cea597*/
    }
    else
    {
      if ( v12 != 4 ) /*0x102cea47c*/
        return general_get_uint(a1, a2, a3: 4u); /*0x102cea47c*/
      v6 = *(_DWORD *)v3; /*0x102cea47e*/
      if ( v6 >= 0 ) /*0x102cea482*/
        goto LABEL_22; /*0x102cea482*/
      ERR_new(); /*0x102cea57d*/
      v15 = 589; /*0x102cea590*/
    }
    ERR_set_debug(__s: "crypto/params.c", a2: v15, a3: "OSSL_PARAM_get_uint32"); /*0x102cea59c*/
    v7 = 0; /*0x102cea5a1*/
    v8 = 125; /*0x102cea5a8*/
    goto LABEL_12; /*0x102cea5ad*/
  }
  if ( v4 == 3 ) /*0x102cea398*/
  {
    if ( *(_QWORD *)(a1 + 24) != 8 ) /*0x102cea402*/
    {
      ERR_new(); /*0x102cea4d2*/
      ERR_set_debug(__s: "crypto/params.c", a2: 619, a3: "OSSL_PARAM_get_uint32"); /*0x102cea4ea*/
      v7 = 0; /*0x102cea4ef*/
      v8 = 130; /*0x102cea4f6*/
      goto LABEL_12; /*0x102cea4fb*/
    }
    v10 = *v3; /*0x102cea408*/
    if ( *v3 < 0.0 || v10 > 4294967295.0 || (LODWORD(v11) = (int)v10, v10 != (double)(int)v10) ) /*0x102cea437*/
    {
      ERR_new(); /*0x102cea43f*/
      ERR_set_debug(__s: "crypto/params.c", a2: 616, a3: "OSSL_PARAM_get_uint32"); /*0x102cea457*/
      v7 = 0; /*0x102cea45c*/
      v8 = 123; /*0x102cea463*/
      goto LABEL_12; /*0x102cea468*/
    }
LABEL_29:
    *(_DWORD *)a2 = LODWORD(v11); /*0x102cea524*/
    return 1; /*0x102cea52b*/
  }
  if ( v4 != 2 ) /*0x102cea39d*/
  {
    ERR_new(); /*0x102cea494*/
    ERR_set_debug(__s: "crypto/params.c", a2: 623, a3: "OSSL_PARAM_get_uint32"); /*0x102cea4ac*/
    v7 = 0; /*0x102cea4b1*/
    v8 = 129; /*0x102cea4b8*/
    goto LABEL_12; /*0x102cea4bd*/
  }
  v5 = *(_QWORD *)(a1 + 24); /*0x102cea3a3*/
  if ( v5 == 8 ) /*0x102cea3ab*/
  {
    v11 = *v3; /*0x102cea518*/
    if ( HIDWORD(*(_QWORD *)&v11) == 0 ) /*0x102cea522*/
      goto LABEL_29; /*0x102cea522*/
    ERR_new(); /*0x102cea54f*/
    v14 = 572; /*0x102cea562*/
LABEL_33:
    ERR_set_debug(__s: "crypto/params.c", a2: v14, a3: "OSSL_PARAM_get_uint32"); /*0x102cea567*/
    v7 = 0; /*0x102cea56c*/
    v8 = 126; /*0x102cea573*/
    goto LABEL_12; /*0x102cea578*/
  }
  if ( v5 == 4 ) /*0x102cea3b5*/
  {
    v6 = *(_DWORD *)v3; /*0x102cea3bb*/
LABEL_22:
    *(_DWORD *)a2 = v6; /*0x102cea488*/
    return 1; /*0x102cea48f*/
  }
  return general_get_uint(a1, a2, a3: 4u); /*0x102cea3fa*/
}

// Address: 0x102cea5c0 | Name: _OSSL_PARAM_set_uint
__int64 OSSL_PARAM_set_uint()
{
  return OSSL_PARAM_set_uint32(); /*0x102cea5c4*/
}

// Address: 0x102cea5d0 | Name: _OSSL_PARAM_set_uint32
__int64 __fastcall OSSL_PARAM_set_uint32(__int64 a1, int a2)
{
  int v2; // eax
  int *v3; // rax
  unsigned int v4; // ebx
  size_t v5; // r8
  __int64 v6; // r14
  int v8; // eax
  __int64 v9; // rcx
  __int64 v10; // rsi
  double *v11; // rax
  size_t v12; // r8
  int v15; // eax
  _DWORD __src[7]; // [rsp+0h] [rbp-1Ch] BYREF

  __src[0] = a2; /*0x102cea5da*/
  if ( a1 == 0 ) /*0x102cea5e0*/
  {
    ERR_new(); /*0x102cea673*/
    ERR_set_debug(__s: "crypto/params.c", a2: 630, a3: "OSSL_PARAM_set_uint32"); /*0x102cea68b*/
    v4 = 0; /*0x102cea690*/
    v10 = 786690; /*0x102cea697*/
    goto LABEL_23; /*0x102cea69c*/
  }
  *(_QWORD *)(a1 + 32) = 0; /*0x102cea5e6*/
  v2 = *(_DWORD *)(a1 + 8); /*0x102cea5ee*/
  if ( v2 == 1 ) /*0x102cea5f4*/
  {
    *(_QWORD *)(a1 + 32) = 4; /*0x102cea6d2*/
    v3 = *(int **)(a1 + 16); /*0x102cea6da*/
    v4 = 1; /*0x102cea6de*/
    if ( v3 == nullptr ) /*0x102cea6e6*/
      return v4; /*0x102cea6e6*/
    v12 = *(_QWORD *)(a1 + 24); /*0x102cea6ec*/
    if ( v12 == 8 ) /*0x102cea6f4*/
      goto LABEL_21; /*0x102cea6f4*/
    if ( v12 != 4 ) /*0x102cea6fa*/
    {
      v6 = 4; /*0x102cea789*/
      v4 = 0; /*0x102cea78f*/
      v15 = copy_integer(__dst: *(char **)(a1 + 16), __n: v12, __src, a4: 4u, a5: 0, a6: 1); /*0x102cea7a8*/
      v9 = a1; /*0x102cea7ad*/
      if ( v15 == 0 ) /*0x102cea7b2*/
      {
LABEL_27:
        *(_QWORD *)(v9 + 32) = v6; /*0x102cea7bd*/
        return v4; /*0x102cea7c1*/
      }
LABEL_26:
      v6 = *(_QWORD *)(v9 + 24); /*0x102cea7b4*/
      v4 = 1; /*0x102cea7b8*/
      goto LABEL_27; /*0x102cea7b8*/
    }
    if ( a2 >= 0 ) /*0x102cea702*/
      goto LABEL_19; /*0x102cea702*/
    ERR_new(); /*0x102cea7c3*/
    ERR_set_debug(__s: "crypto/params.c", a2: 662, a3: "OSSL_PARAM_set_uint32"); /*0x102cea7db*/
    v4 = 0; /*0x102cea7e0*/
    v10 = 126; /*0x102cea7e7*/
LABEL_23:
    ERR_set_error(a1: 15, a2: v10, a3: 0); /*0x102cea76f*/
    return v4; /*0x102cea773*/
  }
  if ( v2 == 3 ) /*0x102cea5fd*/
  {
    v11 = *(double **)(a1 + 16); /*0x102cea6a1*/
    if ( v11 != nullptr ) /*0x102cea6a8*/
    {
      if ( *(_QWORD *)(a1 + 24) != 8 ) /*0x102cea6af*/
      {
        ERR_new(); /*0x102cea746*/
        ERR_set_debug(__s: "crypto/params.c", a2: 690, a3: "OSSL_PARAM_set_uint32"); /*0x102cea75e*/
        v4 = 0; /*0x102cea763*/
        v10 = 130; /*0x102cea76a*/
        goto LABEL_23; /*0x102cea76a*/
      }
      *v11 = (double)a2; /*0x102cea6bc*/
    }
    *(_QWORD *)(a1 + 32) = 8; /*0x102cea6c0*/
    return 1; /*0x102cea6cd*/
  }
  if ( v2 != 2 ) /*0x102cea606*/
  {
    ERR_new(); /*0x102cea70c*/
    ERR_set_debug(__s: "crypto/params.c", a2: 694, a3: "OSSL_PARAM_set_uint32"); /*0x102cea724*/
    v4 = 0; /*0x102cea729*/
    v10 = 129; /*0x102cea730*/
    goto LABEL_23; /*0x102cea735*/
  }
  *(_QWORD *)(a1 + 32) = 4; /*0x102cea60c*/
  v3 = *(int **)(a1 + 16); /*0x102cea614*/
  v4 = 1; /*0x102cea618*/
  if ( v3 != nullptr ) /*0x102cea620*/
  {
    v5 = *(_QWORD *)(a1 + 24); /*0x102cea626*/
    if ( v5 != 8 ) /*0x102cea62e*/
    {
      if ( v5 != 4 ) /*0x102cea638*/
      {
        v6 = 4; /*0x102cea642*/
        v4 = 0; /*0x102cea648*/
        v8 = copy_integer(__dst: *(char **)(a1 + 16), __n: v5, __src, a4: 4u, a5: 0, a6: 0); /*0x102cea65e*/
        v9 = a1; /*0x102cea663*/
        if ( v8 == 0 ) /*0x102cea668*/
          goto LABEL_27; /*0x102cea668*/
        goto LABEL_26; /*0x102cea668*/
      }
LABEL_19:
      *v3 = a2; /*0x102cea708*/
      return v4; /*0x102cea70a*/
    }
LABEL_21:
    *(_QWORD *)(a1 + 32) = 8; /*0x102cea737*/
    *(_QWORD *)v3 = (unsigned int)a2; /*0x102cea741*/
  }
  return v4; /*0x102cea77e*/
}

// Address: 0x102cea7f0 | Name: _OSSL_PARAM_construct_uint
__int64 __fastcall OSSL_PARAM_construct_uint(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = a2; /*0x102cea7f7*/
  *(_DWORD *)(a1 + 8) = 2; /*0x102cea7fa*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102cea801*/
  *(_QWORD *)(a1 + 24) = 4; /*0x102cea805*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102cea80d*/
  return a1; /*0x102cea815*/
}

// Address: 0x102cea820 | Name: _OSSL_PARAM_get_long
__int64 OSSL_PARAM_get_long()
{
  return OSSL_PARAM_get_int64(); /*0x102cea824*/
}

// Address: 0x102cea830 | Name: _OSSL_PARAM_get_int64
__int64 __fastcall OSSL_PARAM_get_int64(__int64 a1, char *a2)
{
  int v2; // esi
  double *v3; // rax
  int v4; // ecx
  __int64 v5; // rcx
  double v6; // rax
  unsigned int v7; // ebx
  __int64 v8; // rsi
  __int64 v10; // rcx
  double v11; // xmm0_8

  if ( a2 == nullptr || a1 == 0 ) /*0x102cea83f*/
  {
    ERR_new(); /*0x102cea846*/
    v2 = 707; /*0x102cea859*/
LABEL_11:
    ERR_set_debug(__s: "crypto/params.c", a2: v2, a3: "OSSL_PARAM_get_int64"); /*0x102cea8bb*/
    v7 = 0; /*0x102cea8c0*/
    v8 = 786690; /*0x102cea8c7*/
LABEL_12:
    ERR_set_error(a1: 15, a2: v8, a3: 0); /*0x102cea8cc*/
    return v7; /*0x102cea8dd*/
  }
  v3 = *(double **)(a1 + 16); /*0x102cea860*/
  if ( v3 == nullptr ) /*0x102cea867*/
  {
    ERR_new(); /*0x102cea8a3*/
    v2 = 712; /*0x102cea8b6*/
    goto LABEL_11; /*0x102cea8b6*/
  }
  v4 = *(_DWORD *)(a1 + 8); /*0x102cea869*/
  if ( v4 == 3 ) /*0x102cea86f*/
  {
    if ( *(_QWORD *)(a1 + 24) != 8 ) /*0x102cea902*/
    {
      ERR_new(); /*0x102cea9a9*/
      ERR_set_debug(__s: "crypto/params.c", a2: 768, a3: "OSSL_PARAM_get_int64"); /*0x102cea9c1*/
      v7 = 0; /*0x102cea9c6*/
      v8 = 130; /*0x102cea9cd*/
      goto LABEL_12; /*0x102cea9d2*/
    }
    v11 = *v3; /*0x102cea908*/
    if ( *v3 < -9.223372036854776e18 /*0x102cea935*/
      || v11 >= 9.223372036854776e18
      || (*(_QWORD *)&v6 = (unsigned int)(int)v11, v11 != (double)SLODWORD(v6)) )
    {
      ERR_new(); /*0x102cea93d*/
      ERR_set_debug(__s: "crypto/params.c", a2: 765, a3: "OSSL_PARAM_get_int64"); /*0x102cea955*/
      v7 = 0; /*0x102cea95a*/
      v8 = 123; /*0x102cea961*/
      goto LABEL_12; /*0x102cea966*/
    }
    goto LABEL_28; /*0x102cea935*/
  }
  if ( v4 == 2 ) /*0x102cea878*/
  {
    v10 = *(_QWORD *)(a1 + 24); /*0x102cea8de*/
    if ( v10 != 8 ) /*0x102cea8e6*/
    {
      if ( v10 == 4 ) /*0x102cea8f0*/
      {
        *(_QWORD *)&v6 = *(unsigned int *)v3; /*0x102cea8f6*/
        goto LABEL_28; /*0x102cea8f8*/
      }
      return general_get_int(a1, a2, a3: 8u); /*0x102cea8f0*/
    }
    v6 = *v3; /*0x102cea9d7*/
    if ( v6 < 0.0 ) /*0x102cea9dd*/
    {
      ERR_new(); /*0x102cea9df*/
      ERR_set_debug(__s: "crypto/params.c", a2: 742, a3: "OSSL_PARAM_get_int64"); /*0x102cea9f7*/
      v7 = 0; /*0x102cea9fc*/
      v8 = 126; /*0x102ceaa03*/
      goto LABEL_12; /*0x102ceaa08*/
    }
LABEL_28:
    *(double *)a2 = v6; /*0x102ceaa10*/
    return 1; /*0x102ceaa18*/
  }
  if ( v4 != 1 ) /*0x102cea87d*/
  {
    ERR_new(); /*0x102cea96b*/
    ERR_set_debug(__s: "crypto/params.c", a2: 772, a3: "OSSL_PARAM_get_int64"); /*0x102cea983*/
    v7 = 0; /*0x102cea988*/
    v8 = 129; /*0x102cea98f*/
    goto LABEL_12; /*0x102cea994*/
  }
  v5 = *(_QWORD *)(a1 + 24); /*0x102cea883*/
  if ( v5 == 8 ) /*0x102cea88b*/
  {
    v6 = *v3; /*0x102ceaa0d*/
    goto LABEL_28; /*0x102ceaa0d*/
  }
  if ( v5 == 4 ) /*0x102cea895*/
  {
    *(_QWORD *)&v6 = *(int *)v3; /*0x102cea89b*/
    goto LABEL_28; /*0x102cea89e*/
  }
  return general_get_int(a1, a2, a3: 8u); /*0x102cea8db*/
}

// Address: 0x102ceaa20 | Name: _OSSL_PARAM_set_long
__int64 OSSL_PARAM_set_long()
{
  return OSSL_PARAM_set_int64(); /*0x102ceaa24*/
}

// Address: 0x102ceaa30 | Name: _OSSL_PARAM_set_int64
__int64 __fastcall OSSL_PARAM_set_int64(__int64 a1, __int64 a2)
{
  int v2; // eax
  _DWORD *v3; // rax
  __int64 v4; // rcx
  int v5; // esi
  unsigned int v6; // ebx
  __int64 v7; // rsi
  __int64 v8; // rcx
  double *v9; // rax
  unsigned __int64 v10; // rcx
  __int64 v12; // [rsp+0h] [rbp-10h] BYREF

  v12 = a2; /*0x102ceaa36*/
  if ( a1 != 0 ) /*0x102ceaa3d*/
  {
    *(_QWORD *)(a1 + 32) = 0; /*0x102ceaa3f*/
    v2 = *(_DWORD *)(a1 + 8); /*0x102ceaa47*/
    if ( v2 == 1 ) /*0x102ceaa4d*/
    {
      v3 = *(_DWORD **)(a1 + 16); /*0x102ceaa53*/
      if ( v3 != nullptr ) /*0x102ceaa5a*/
      {
        v4 = *(_QWORD *)(a1 + 24); /*0x102ceaa60*/
        if ( v4 != 8 ) /*0x102ceaa68*/
        {
          if ( v4 == 4 ) /*0x102ceaa72*/
          {
            if ( (int)a2 != a2 ) /*0x102ceaa7e*/
            {
              ERR_new(); /*0x102ceaa84*/
              v5 = 796; /*0x102ceaa97*/
LABEL_30:
              ERR_set_debug(__s: "crypto/params.c", a2: v5, a3: "OSSL_PARAM_set_int64"); /*0x102ceac16*/
              v6 = 0; /*0x102ceac1b*/
              v7 = 126; /*0x102ceac22*/
              goto LABEL_9; /*0x102ceac27*/
            }
            goto LABEL_15; /*0x102ceaa7e*/
          }
          return (unsigned int)general_set_int(a1, a2: &v12, a3: 8u); /*0x102ceaa72*/
        }
        goto LABEL_24; /*0x102ceaa68*/
      }
      goto LABEL_23; /*0x102ceaa5a*/
    }
    if ( v2 == 2 && a2 >= 0 ) /*0x102ceaae1*/
    {
      v3 = *(_DWORD **)(a1 + 16); /*0x102ceaae8*/
      if ( v3 != nullptr ) /*0x102ceaaef*/
      {
        v8 = *(_QWORD *)(a1 + 24); /*0x102ceaaf1*/
        if ( v8 != 8 ) /*0x102ceaaf9*/
        {
          if ( v8 == 4 ) /*0x102ceaaff*/
          {
            if ( HIDWORD(a2) != 0 ) /*0x102ceab0c*/
            {
              ERR_new(); /*0x102ceabfe*/
              v5 = 818; /*0x102ceac11*/
              goto LABEL_30; /*0x102ceac11*/
            }
LABEL_15:
            *(_QWORD *)(a1 + 32) = 4; /*0x102ceab12*/
            *v3 = a2; /*0x102ceab1a*/
            return 1; /*0x102ceab21*/
          }
          return (unsigned int)general_set_int(a1, a2: &v12, a3: 8u); /*0x102ceab97*/
        }
LABEL_24:
        *(_QWORD *)(a1 + 32) = 8; /*0x102ceab77*/
        *(_QWORD *)v3 = a2; /*0x102ceab7f*/
        return 1; /*0x102ceab87*/
      }
LABEL_23:
      *(_QWORD *)(a1 + 32) = 8; /*0x102ceab68*/
      return 1; /*0x102ceab75*/
    }
    if ( v2 == 3 ) /*0x102ceab26*/
    {
      v9 = *(double **)(a1 + 16); /*0x102ceab28*/
      if ( v9 != nullptr ) /*0x102ceab2f*/
      {
        if ( *(_QWORD *)(a1 + 24) == 8 ) /*0x102ceab36*/
        {
          v10 = -a2; /*0x102ceab3f*/
          if ( a2 > 0 ) /*0x102ceab42*/
            v10 = a2; /*0x102ceab42*/
          if ( v10 >> 53 == 0 ) /*0x102ceab4a*/
          {
            *(_QWORD *)(a1 + 32) = 8; /*0x102ceab50*/
            *v9 = (double)(int)a2; /*0x102ceab5d*/
            return 1; /*0x102ceab66*/
          }
          ERR_new(); /*0x102ceac2c*/
          ERR_set_debug(__s: "crypto/params.c", a2: 843, a3: "OSSL_PARAM_set_int64"); /*0x102ceac44*/
          v6 = 0; /*0x102ceac49*/
          v7 = 123; /*0x102ceac50*/
        }
        else
        {
          ERR_new(); /*0x102ceabd0*/
          ERR_set_debug(__s: "crypto/params.c", a2: 846, a3: "OSSL_PARAM_set_int64"); /*0x102ceabe8*/
          v6 = 0; /*0x102ceabed*/
          v7 = 130; /*0x102ceabf4*/
        }
        goto LABEL_9; /*0x102ceac55*/
      }
      goto LABEL_23; /*0x102ceab2f*/
    }
    ERR_new(); /*0x102ceaba2*/
    ERR_set_debug(__s: "crypto/params.c", a2: 850, a3: "OSSL_PARAM_set_int64"); /*0x102ceabba*/
    v6 = 0; /*0x102ceabbf*/
    v7 = 129; /*0x102ceabc6*/
  }
  else
  {
    ERR_new(); /*0x102ceaaa1*/
    ERR_set_debug(__s: "crypto/params.c", a2: 779, a3: "OSSL_PARAM_set_int64"); /*0x102ceaab9*/
    v6 = 0; /*0x102ceaabe*/
    v7 = 786690; /*0x102ceaac5*/
  }
LABEL_9:
  ERR_set_error(a1: 15, a2: v7, a3: 0); /*0x102ceaaca*/
  return v6; /*0x102ceab9f*/
}

// Address: 0x102ceac60 | Name: _OSSL_PARAM_construct_long
__int64 __fastcall OSSL_PARAM_construct_long(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = a2; /*0x102ceac67*/
  *(_DWORD *)(a1 + 8) = 1; /*0x102ceac6a*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102ceac71*/
  *(_QWORD *)(a1 + 24) = 8; /*0x102ceac75*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102ceac7d*/
  return a1; /*0x102ceac85*/
}

// Address: 0x102ceac90 | Name: _OSSL_PARAM_get_ulong
__int64 __fastcall OSSL_PARAM_get_ulong(__int64 a1, __int64 a2)
{
  return OSSL_PARAM_get_uint64(a1, a2); /*0x102ceac94*/
}

// Address: 0x102ceaca0 | Name: _OSSL_PARAM_get_uint64
__int64 __fastcall OSSL_PARAM_get_uint64(__int64 a1, char *a2)
{
  int v2; // esi
  double *v3; // rax
  int v4; // ecx
  __int64 v5; // rcx
  double v6; // rax
  unsigned int v7; // ebx
  __int64 v8; // rsi
  double v10; // xmm0_8
  __m128d v11; // xmm1
  __int64 v12; // rcx
  int v13; // esi

  if ( a2 == nullptr || a1 == 0 ) /*0x102ceacaf*/
  {
    ERR_new(); /*0x102ceacb6*/
    v2 = 862; /*0x102ceacc9*/
LABEL_11:
    ERR_set_debug(__s: "crypto/params.c", a2: v2, a3: "OSSL_PARAM_get_uint64"); /*0x102cead2a*/
    v7 = 0; /*0x102cead2f*/
    v8 = 786690; /*0x102cead36*/
LABEL_12:
    ERR_set_error(a1: 15, a2: v8, a3: 0); /*0x102cead3b*/
    return v7; /*0x102cead4c*/
  }
  v3 = *(double **)(a1 + 16); /*0x102ceacd0*/
  if ( v3 == nullptr ) /*0x102ceacd7*/
  {
    ERR_new(); /*0x102cead12*/
    v2 = 867; /*0x102cead25*/
    goto LABEL_11; /*0x102cead25*/
  }
  v4 = *(_DWORD *)(a1 + 8); /*0x102ceacd9*/
  if ( v4 == 1 ) /*0x102ceacdf*/
  {
    v12 = *(_QWORD *)(a1 + 24); /*0x102ceadf2*/
    if ( v12 == 8 ) /*0x102ceadfa*/
    {
      v6 = *v3; /*0x102ceae9b*/
      if ( v6 >= 0.0 ) /*0x102ceaea1*/
        goto LABEL_30; /*0x102ceaea1*/
      ERR_new(); /*0x102ceaea3*/
      v13 = 903; /*0x102ceaeb6*/
    }
    else
    {
      if ( v12 != 4 ) /*0x102ceae04*/
        return general_get_uint(a1, a2, a3: 8u); /*0x102ceae04*/
      *(_QWORD *)&v6 = *(int *)v3; /*0x102ceae06*/
      if ( v6 >= 0.0 ) /*0x102ceae0c*/
        goto LABEL_30; /*0x102ceae0c*/
      ERR_new(); /*0x102ceae12*/
      v13 = 895; /*0x102ceae25*/
    }
    ERR_set_debug(__s: "crypto/params.c", a2: v13, a3: "OSSL_PARAM_get_uint64"); /*0x102ceaebb*/
    v7 = 0; /*0x102ceaec0*/
    v8 = 125; /*0x102ceaec7*/
    goto LABEL_12; /*0x102ceaecc*/
  }
  if ( v4 == 3 ) /*0x102ceace8*/
  {
    if ( *(_QWORD *)(a1 + 24) != 8 ) /*0x102cead52*/
    {
      ERR_new(); /*0x102ceae6d*/
      ERR_set_debug(__s: "crypto/params.c", a2: 929, a3: "OSSL_PARAM_get_uint64"); /*0x102ceae85*/
      v7 = 0; /*0x102ceae8a*/
      v8 = 130; /*0x102ceae91*/
      goto LABEL_12; /*0x102ceae96*/
    }
    v10 = *v3; /*0x102cead58*/
    if ( *v3 < 0.0 /*0x102ceadbc*/
      || v10 >= 1.844674407370955e19
      || (*(_QWORD *)&v6 = (unsigned int)(int)v10,
          v11 = _mm_sub_pd(
                  (__m128d)_mm_unpacklo_epi32((__m128i)(unsigned int)(int)v10, (__m128i)xmmword_108F2F9A0),
                  (__m128d)xmmword_108F2F9B0),
          v10 != _mm_unpackhi_pd(v11, v11).f64[0] + v11.f64[0]) )
    {
      ERR_new(); /*0x102ceadc4*/
      ERR_set_debug(__s: "crypto/params.c", a2: 926, a3: "OSSL_PARAM_get_uint64"); /*0x102ceaddc*/
      v7 = 0; /*0x102ceade1*/
      v8 = 123; /*0x102ceade8*/
      goto LABEL_12; /*0x102ceaded*/
    }
LABEL_30:
    *(double *)a2 = v6; /*0x102ceaed4*/
    return 1; /*0x102ceaedc*/
  }
  if ( v4 != 2 ) /*0x102ceaced*/
  {
    ERR_new(); /*0x102ceae2f*/
    ERR_set_debug(__s: "crypto/params.c", a2: 933, a3: "OSSL_PARAM_get_uint64"); /*0x102ceae47*/
    v7 = 0; /*0x102ceae4c*/
    v8 = 129; /*0x102ceae53*/
    goto LABEL_12; /*0x102ceae58*/
  }
  v5 = *(_QWORD *)(a1 + 24); /*0x102ceacf3*/
  if ( v5 == 8 ) /*0x102ceacfb*/
  {
    v6 = *v3; /*0x102ceaed1*/
    goto LABEL_30; /*0x102ceaed1*/
  }
  if ( v5 == 4 ) /*0x102cead05*/
  {
    *(_QWORD *)&v6 = *(unsigned int *)v3; /*0x102cead0b*/
    goto LABEL_30; /*0x102cead0d*/
  }
  return general_get_uint(a1, a2, a3: 8u); /*0x102cead4a*/
}

// Address: 0x102ceaef0 | Name: _OSSL_PARAM_set_ulong
__int64 OSSL_PARAM_set_ulong()
{
  return OSSL_PARAM_set_uint64(); /*0x102ceaef4*/
}

// Address: 0x102ceaf00 | Name: _OSSL_PARAM_set_uint64
__int64 __fastcall OSSL_PARAM_set_uint64(__int64 a1, unsigned __int64 a2)
{
  int v2; // eax
  unsigned __int64 *v3; // rax
  size_t v4; // r8
  int v5; // esi
  unsigned int v6; // ebx
  __int64 v7; // rsi
  size_t v8; // r8
  __int64 v9; // r14
  int v11; // eax
  __int64 v12; // rcx
  int v14; // eax
  _QWORD __src[4]; // [rsp+0h] [rbp-20h] BYREF

  __src[0] = a2; /*0x102ceaf0a*/
  if ( a1 == 0 ) /*0x102ceaf11*/
  {
    ERR_new(); /*0x102ceaf88*/
    ERR_set_debug(__s: "crypto/params.c", a2: 940, a3: "OSSL_PARAM_set_uint64"); /*0x102ceafa0*/
    v6 = 0; /*0x102ceafa5*/
    v7 = 786690; /*0x102ceafac*/
    goto LABEL_33; /*0x102ceafb1*/
  }
  *(_QWORD *)(a1 + 32) = 0; /*0x102ceaf13*/
  v2 = *(_DWORD *)(a1 + 8); /*0x102ceaf1b*/
  if ( v2 == 1 ) /*0x102ceaf21*/
  {
    v3 = *(unsigned __int64 **)(a1 + 16); /*0x102ceafed*/
    if ( v3 != nullptr ) /*0x102ceaff4*/
    {
      v8 = *(_QWORD *)(a1 + 24); /*0x102ceaff6*/
      if ( v8 != 8 ) /*0x102ceaffe*/
      {
        if ( v8 == 4 ) /*0x102ceb008*/
        {
          if ( a2 > 0x7FFFFFFF ) /*0x102ceb015*/
          {
            ERR_new(); /*0x102ceb155*/
            v5 = 980; /*0x102ceb168*/
            goto LABEL_32; /*0x102ceb16d*/
          }
          goto LABEL_18; /*0x102ceb015*/
        }
        v9 = 8; /*0x102ceb0ed*/
        v6 = 0; /*0x102ceb0f3*/
        v11 = copy_integer(__dst: *(char **)(a1 + 16), __n: v8, __src, a4: 8u, a5: 0, a6: 1); /*0x102ceb10c*/
        v12 = a1; /*0x102ceb111*/
        if ( v11 == 0 ) /*0x102ceb116*/
        {
LABEL_27:
          *(_QWORD *)(v12 + 32) = v9; /*0x102ceb121*/
          return v6; /*0x102ceb125*/
        }
LABEL_26:
        v9 = *(_QWORD *)(v12 + 24); /*0x102ceb118*/
        v6 = 1; /*0x102ceb11c*/
        goto LABEL_27; /*0x102ceb11c*/
      }
      if ( (a2 & 0x8000000000000000LL) != 0LL ) /*0x102ceb0ce*/
      {
        ERR_new(); /*0x102ceb16f*/
        v5 = 988; /*0x102ceb182*/
        goto LABEL_32; /*0x102ceb182*/
      }
LABEL_24:
      *(_QWORD *)(a1 + 32) = 8; /*0x102ceb0d4*/
      *v3 = a2; /*0x102ceb0dc*/
      return 1; /*0x102ceb0e4*/
    }
LABEL_20:
    *(_QWORD *)(a1 + 32) = 8; /*0x102ceb05d*/
    return 1; /*0x102ceb06a*/
  }
  if ( v2 != 3 ) /*0x102ceaf2a*/
  {
    if ( v2 == 2 ) /*0x102ceaf33*/
    {
      v3 = *(unsigned __int64 **)(a1 + 16); /*0x102ceaf39*/
      if ( v3 != nullptr ) /*0x102ceaf40*/
      {
        v4 = *(_QWORD *)(a1 + 24); /*0x102ceaf46*/
        if ( v4 != 8 ) /*0x102ceaf4e*/
        {
          if ( v4 == 4 ) /*0x102ceaf58*/
          {
            if ( HIDWORD(a2) != 0 ) /*0x102ceaf65*/
            {
              ERR_new(); /*0x102ceaf6b*/
              v5 = 958; /*0x102ceaf7e*/
LABEL_32:
              ERR_set_debug(__s: "crypto/params.c", a2: v5, a3: "OSSL_PARAM_set_uint64"); /*0x102ceb187*/
              v6 = 0; /*0x102ceb18c*/
              v7 = 126; /*0x102ceb193*/
              goto LABEL_33; /*0x102ceb193*/
            }
LABEL_18:
            *(_QWORD *)(a1 + 32) = 4; /*0x102ceb01b*/
            *(_DWORD *)v3 = a2; /*0x102ceb023*/
            return 1; /*0x102ceb02a*/
          }
          v9 = 8; /*0x102ceb12b*/
          v6 = 0; /*0x102ceb131*/
          v14 = copy_integer(__dst: *(char **)(a1 + 16), __n: v4, __src, a4: 8u, a5: 0, a6: 0); /*0x102ceb147*/
          v12 = a1; /*0x102ceb14c*/
          if ( v14 == 0 ) /*0x102ceb151*/
            goto LABEL_27; /*0x102ceb151*/
          goto LABEL_26; /*0x102ceb151*/
        }
        goto LABEL_24; /*0x102ceaf4e*/
      }
      goto LABEL_20; /*0x102ceaf40*/
    }
    ERR_new(); /*0x102ceb02f*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1009, a3: "OSSL_PARAM_set_uint64"); /*0x102ceb047*/
    v6 = 0; /*0x102ceb04c*/
    v7 = 129; /*0x102ceb053*/
LABEL_33:
    ERR_set_error(a1: 15, a2: v7, a3: 0); /*0x102ceb198*/
    return v6; /*0x102ceb19c*/
  }
  if ( *(_QWORD *)(a1 + 24) != 8 ) /*0x102ceafbb*/
  {
    ERR_new(); /*0x102ceb06f*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1005, a3: "OSSL_PARAM_set_uint64"); /*0x102ceb087*/
    v6 = 0; /*0x102ceb08c*/
    v7 = 130; /*0x102ceb093*/
    goto LABEL_33; /*0x102ceb098*/
  }
  if ( a2 >> 53 != 0 ) /*0x102ceafc8*/
  {
    ERR_new(); /*0x102ceb09d*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1002, a3: "OSSL_PARAM_set_uint64"); /*0x102ceb0b5*/
    v6 = 0; /*0x102ceb0ba*/
    v7 = 123; /*0x102ceb0c1*/
    goto LABEL_33; /*0x102ceb0c6*/
  }
  *(_QWORD *)(a1 + 32) = 8; /*0x102ceafd3*/
  **(double **)(a1 + 16) = (double)(int)a2; /*0x102ceafdf*/
  return 1; /*0x102ceb1a7*/
}

// Address: 0x102ceb1b0 | Name: _OSSL_PARAM_construct_ulong
__int64 __fastcall OSSL_PARAM_construct_ulong(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = a2; /*0x102ceb1b7*/
  *(_DWORD *)(a1 + 8) = 2; /*0x102ceb1ba*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102ceb1c1*/
  *(_QWORD *)(a1 + 24) = 8; /*0x102ceb1c5*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102ceb1cd*/
  return a1; /*0x102ceb1d5*/
}

// Address: 0x102ceb3a0 | Name: _OSSL_PARAM_construct_int32
__int64 __fastcall OSSL_PARAM_construct_int32(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = a2; /*0x102ceb3a7*/
  *(_DWORD *)(a1 + 8) = 1; /*0x102ceb3aa*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102ceb3b1*/
  *(_QWORD *)(a1 + 24) = 4; /*0x102ceb3b5*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102ceb3bd*/
  return a1; /*0x102ceb3c5*/
}

// Address: 0x102ceb4a0 | Name: _OSSL_PARAM_construct_uint32
__int64 __fastcall OSSL_PARAM_construct_uint32(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = a2; /*0x102ceb4a7*/
  *(_DWORD *)(a1 + 8) = 2; /*0x102ceb4aa*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102ceb4b1*/
  *(_QWORD *)(a1 + 24) = 4; /*0x102ceb4b5*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102ceb4bd*/
  return a1; /*0x102ceb4c5*/
}

// Address: 0x102ceb4d0 | Name: _OSSL_PARAM_construct_int64
__int64 __fastcall OSSL_PARAM_construct_int64(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = a2; /*0x102ceb4d7*/
  *(_DWORD *)(a1 + 8) = 1; /*0x102ceb4da*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102ceb4e1*/
  *(_QWORD *)(a1 + 24) = 8; /*0x102ceb4e5*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102ceb4ed*/
  return a1; /*0x102ceb4f5*/
}

// Address: 0x102ceb500 | Name: _OSSL_PARAM_construct_uint64
__int64 __fastcall OSSL_PARAM_construct_uint64(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = a2; /*0x102ceb507*/
  *(_DWORD *)(a1 + 8) = 2; /*0x102ceb50a*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102ceb511*/
  *(_QWORD *)(a1 + 24) = 8; /*0x102ceb515*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102ceb51d*/
  return a1; /*0x102ceb525*/
}

// Address: 0x102ceb530 | Name: _OSSL_PARAM_get_size_t
__int64 __fastcall OSSL_PARAM_get_size_t(__int64 a1, char *a2)
{
  return OSSL_PARAM_get_uint64(a1, a2); /*0x102ceb534*/
}

// Address: 0x102ceb540 | Name: _OSSL_PARAM_set_size_t
__int64 __fastcall OSSL_PARAM_set_size_t(__int64 a1, unsigned __int64 a2)
{
  return OSSL_PARAM_set_uint64(a1, a2); /*0x102ceb544*/
}

// Address: 0x102ceb550 | Name: _OSSL_PARAM_construct_size_t
__int64 __fastcall OSSL_PARAM_construct_size_t(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = a2; /*0x102ceb557*/
  *(_DWORD *)(a1 + 8) = 2; /*0x102ceb55a*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102ceb561*/
  *(_QWORD *)(a1 + 24) = 8; /*0x102ceb565*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102ceb56d*/
  return a1; /*0x102ceb575*/
}

// Address: 0x102ceb580 | Name: _OSSL_PARAM_get_time_t
__int64 __fastcall OSSL_PARAM_get_time_t(__int64 a1, char *a2)
{
  return OSSL_PARAM_get_int64(a1, a2); /*0x102ceb584*/
}

// Address: 0x102ceb590 | Name: _OSSL_PARAM_set_time_t
__int64 __fastcall OSSL_PARAM_set_time_t(__int64 a1, __int64 a2)
{
  return OSSL_PARAM_set_int64(a1, a2); /*0x102ceb594*/
}

// Address: 0x102ceb5a0 | Name: _OSSL_PARAM_construct_time_t
__int64 __fastcall OSSL_PARAM_construct_time_t(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = a2; /*0x102ceb5a7*/
  *(_DWORD *)(a1 + 8) = 1; /*0x102ceb5aa*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102ceb5b1*/
  *(_QWORD *)(a1 + 24) = 8; /*0x102ceb5b5*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102ceb5bd*/
  return a1; /*0x102ceb5c5*/
}

// Address: 0x102ceb5d0 | Name: _OSSL_PARAM_get_BN
__int64 __fastcall OSSL_PARAM_get_BN(__int64 a1, BIGNUM **a2)
{
  int v2; // ecx
  BIGNUM **v3; // rbx
  BIGNUM *v4; // rax
  unsigned int v5; // ebx
  __int64 v6; // rsi

  if ( a2 == nullptr || a1 == 0 || *(_QWORD *)(a1 + 16) == 0 ) /*0x102ceb5ed*/
  {
    ERR_new(); /*0x102ceb616*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1087, a3: "OSSL_PARAM_get_BN"); /*0x102ceb62e*/
    v5 = 0; /*0x102ceb633*/
    v6 = 786690; /*0x102ceb63a*/
LABEL_12:
    ERR_set_error(a1: 15, a2: v6, a3: 0); /*0x102ceb6bc*/
    return v5; /*0x102ceb6c0*/
  }
  v2 = *(_DWORD *)(a1 + 8); /*0x102ceb5ef*/
  if ( v2 == 1 ) /*0x102ceb5f5*/
  {
    v3 = a2; /*0x102ceb644*/
    v4 = BN_signed_native2bn(a1: *(char **)(a1 + 16), a2: *(_DWORD *)(a1 + 24), a3: *a2); /*0x102ceb64f*/
    if ( v4 != nullptr ) /*0x102ceb657*/
      goto LABEL_9; /*0x102ceb657*/
LABEL_11:
    ERR_new(); /*0x102ceb693*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1104, a3: "OSSL_PARAM_get_BN"); /*0x102ceb6ab*/
    v5 = 0; /*0x102ceb6b0*/
    v6 = 524291; /*0x102ceb6b7*/
    goto LABEL_12; /*0x102ceb6b7*/
  }
  if ( v2 != 2 ) /*0x102ceb5fa*/
  {
    ERR_new(); /*0x102ceb663*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1099, a3: "OSSL_PARAM_get_BN"); /*0x102ceb67b*/
    ERR_set_error(a1: 15, a2: 129, a3: 0); /*0x102ceb68e*/
    goto LABEL_11; /*0x102ceb68e*/
  }
  v3 = a2; /*0x102ceb5ff*/
  v4 = BN_native2bn(a1: *(char **)(a1 + 16), a2: *(_DWORD *)(a1 + 24), a3: *a2); /*0x102ceb60a*/
  if ( v4 == nullptr ) /*0x102ceb612*/
    goto LABEL_11; /*0x102ceb612*/
LABEL_9:
  *v3 = v4; /*0x102ceb659*/
  return 1; /*0x102ceb6cb*/
}

// Address: 0x102ceb6d0 | Name: _OSSL_PARAM_set_BN
__int64 __fastcall OSSL_PARAM_set_BN(__int64 a1, const BIGNUM *a2)
{
  const BIGNUM *v3; // r14
  _BOOL4 is_negative; // eax
  int v5; // esi
  unsigned int v6; // ebx
  __int64 v7; // rsi
  int v8; // esi
  BIGNUM *v9; // r14
  int v10; // eax
  int v11; // ecx
  int v12; // eax
  __int64 v13; // rcx
  int v14; // eax
  unsigned __int64 v15; // rcx
  unsigned __int8 *v16; // rsi
  unsigned __int64 v17; // rdx
  int v19; // esi

  if ( a1 == 0 ) /*0x102ceb6da*/
  {
    ERR_new(); /*0x102ceb736*/
    v8 = 1117; /*0x102ceb749*/
LABEL_14:
    ERR_set_debug(__s: "crypto/params.c", a2: v8, a3: "OSSL_PARAM_set_BN"); /*0x102ceb7de*/
    v6 = 0; /*0x102ceb7e3*/
    v7 = 786690; /*0x102ceb7ea*/
    goto LABEL_15; /*0x102ceb7ea*/
  }
  *(_QWORD *)(a1 + 32) = 0; /*0x102ceb6df*/
  if ( a2 == nullptr ) /*0x102ceb6ea*/
  {
    ERR_new(); /*0x102ceb7c6*/
    v8 = 1122; /*0x102ceb7d9*/
    goto LABEL_14; /*0x102ceb7d9*/
  }
  if ( *(_DWORD *)(a1 + 8) != 2 || (v3 = a2, is_negative = BN_is_negative(a1: (__int64)a2), a2 = v3, !is_negative) ) /*0x102ceb706*/
  {
    v9 = (BIGNUM *)a2; /*0x102ceb753*/
    v10 = BN_num_bits(a: a2); /*0x102ceb759*/
    v11 = v10 + 7; /*0x102ceb75e*/
    v12 = v10 + 14; /*0x102ceb761*/
    if ( v11 >= 0 ) /*0x102ceb766*/
      v12 = v11; /*0x102ceb766*/
    v13 = v12 >> 3; /*0x102ceb76c*/
    v14 = *(_DWORD *)(a1 + 8); /*0x102ceb76f*/
    v15 = (v14 == 1) + (v13 + (v14 == 1) == 0) + v13; /*0x102ceb782*/
    v16 = *(unsigned __int8 **)(a1 + 16); /*0x102ceb785*/
    if ( v16 == nullptr ) /*0x102ceb78c*/
    {
      *(_QWORD *)(a1 + 32) = v15; /*0x102ceb7ff*/
      return 1; /*0x102ceb808*/
    }
    v17 = *(_QWORD *)(a1 + 24); /*0x102ceb78e*/
    if ( v17 < v15 ) /*0x102ceb795*/
    {
      *(_QWORD *)(a1 + 32) = v15; /*0x102ceb797*/
      ERR_new(); /*0x102ceb79b*/
      ERR_set_debug(__s: "crypto/params.c", a2: 1165, a3: "OSSL_PARAM_set_BN"); /*0x102ceb7b3*/
      v6 = 0; /*0x102ceb7b8*/
      v7 = 116; /*0x102ceb7bf*/
      goto LABEL_15; /*0x102ceb7c4*/
    }
    if ( v14 == 1 ) /*0x102ceb80d*/
    {
      if ( (int)BN_signed_bn2native(a1: v9, a2: v16, a3: v17) < 0 ) /*0x102ceb844*/
      {
        ERR_new(); /*0x102ceb872*/
        v19 = 1153; /*0x102ceb885*/
        goto LABEL_26; /*0x102ceb885*/
      }
    }
    else
    {
      if ( v14 != 2 ) /*0x102ceb812*/
      {
        ERR_new(); /*0x102ceb855*/
        v5 = 1158; /*0x102ceb868*/
        goto LABEL_6; /*0x102ceb86d*/
      }
      if ( (int)BN_bn2nativepad(a1: v9, a2: v16, a3: v17) < 0 ) /*0x102ceb81e*/
      {
        ERR_new(); /*0x102ceb820*/
        v19 = 1147; /*0x102ceb833*/
LABEL_26:
        ERR_set_debug(__s: "crypto/params.c", a2: v19, a3: "OSSL_PARAM_set_BN"); /*0x102ceb88a*/
        v6 = 0; /*0x102ceb88f*/
        v7 = 127; /*0x102ceb896*/
        goto LABEL_15; /*0x102ceb89b*/
      }
    }
    *(_QWORD *)(a1 + 32) = *(_QWORD *)(a1 + 24); /*0x102ceb84a*/
    return 1; /*0x102ceb853*/
  }
  ERR_new(); /*0x102ceb708*/
  v5 = 1126; /*0x102ceb71b*/
LABEL_6:
  ERR_set_debug(__s: "crypto/params.c", a2: v5, a3: "OSSL_PARAM_set_BN"); /*0x102ceb720*/
  v6 = 0; /*0x102ceb725*/
  v7 = 129; /*0x102ceb72c*/
LABEL_15:
  ERR_set_error(a1: 15, a2: v7, a3: 0); /*0x102ceb7ef*/
  return v6; /*0x102ceb7fa*/
}

// Address: 0x102ceb8a0 | Name: _OSSL_PARAM_construct_BN
__int64 __fastcall OSSL_PARAM_construct_BN(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  *(_QWORD *)a1 = a2; /*0x102ceb8a7*/
  *(_DWORD *)(a1 + 8) = 2; /*0x102ceb8aa*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102ceb8b1*/
  *(_QWORD *)(a1 + 24) = a4; /*0x102ceb8b5*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102ceb8b9*/
  return a1; /*0x102ceb8c1*/
}

// Address: 0x102ceb8d0 | Name: _OSSL_PARAM_get_double
__int64 __fastcall OSSL_PARAM_get_double(__int64 a1, double *a2)
{
  __int64 v2; // rax
  int v3; // ecx
  double v4; // xmm0_8
  unsigned int v5; // ebx
  __int64 v6; // rsi
  __int64 v8; // rcx
  __int64 v9; // rcx
  int v10; // esi
  unsigned __int64 v11; // rcx

  if ( a2 == nullptr || a1 == 0 || (v2 = *(_QWORD *)(a1 + 16)) == 0 ) /*0x102ceb8ed*/
  {
    ERR_new(); /*0x102ceb919*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1183, a3: "OSSL_PARAM_get_double"); /*0x102ceb931*/
    v5 = 0; /*0x102ceb936*/
    v6 = 786690; /*0x102ceb93d*/
    goto LABEL_9; /*0x102ceb93d*/
  }
  v3 = *(_DWORD *)(a1 + 8); /*0x102ceb8ef*/
  if ( v3 == 1 ) /*0x102ceb8f5*/
  {
    v9 = *(_QWORD *)(a1 + 24); /*0x102ceb96f*/
    if ( v9 != 8 ) /*0x102ceb977*/
    {
      if ( v9 == 4 ) /*0x102ceb981*/
      {
        v4 = (double)*(int *)v2; /*0x102ceb983*/
        goto LABEL_25; /*0x102ceb987*/
      }
      goto LABEL_17; /*0x102ceb981*/
    }
    v2 = *(_QWORD *)v2; /*0x102ceba0b*/
    v11 = -v2; /*0x102ceba11*/
    if ( v2 > 0 ) /*0x102ceba14*/
      v11 = v2; /*0x102ceba14*/
    if ( v11 >> 53 == 0 ) /*0x102ceba1c*/
      goto LABEL_24; /*0x102ceba1c*/
    ERR_new(); /*0x102ceba31*/
    v10 = 1221; /*0x102ceba44*/
    goto LABEL_27; /*0x102ceba44*/
  }
  if ( v3 == 2 ) /*0x102ceb8fa*/
  {
    v8 = *(_QWORD *)(a1 + 24); /*0x102ceb954*/
    if ( v8 != 8 ) /*0x102ceb95c*/
    {
      if ( v8 != 4 ) /*0x102ceb966*/
        goto LABEL_17; /*0x102ceb966*/
      LODWORD(v2) = *(_DWORD *)v2; /*0x102ceb968*/
LABEL_24:
      v4 = (double)(int)v2; /*0x102ceba1e*/
      goto LABEL_25; /*0x102ceba1e*/
    }
    v2 = *(_QWORD *)v2; /*0x102ceb9e5*/
    if ( (unsigned __int64)v2 >> 53 == 0 ) /*0x102ceb9ef*/
      goto LABEL_24; /*0x102ceb9ef*/
    ERR_new(); /*0x102ceb9f1*/
    v10 = 1206; /*0x102ceba04*/
LABEL_27:
    ERR_set_debug(__s: "crypto/params.c", a2: v10, a3: "OSSL_PARAM_get_double"); /*0x102ceba49*/
    v5 = 0; /*0x102ceba4e*/
    v6 = 123; /*0x102ceba55*/
    goto LABEL_9; /*0x102ceba5a*/
  }
  if ( v3 != 3 ) /*0x102ceb8ff*/
  {
LABEL_17:
    ERR_new(); /*0x102ceb98c*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1225, a3: "OSSL_PARAM_get_double"); /*0x102ceb9a4*/
    v5 = 0; /*0x102ceb9a9*/
    v6 = 129; /*0x102ceb9b0*/
    goto LABEL_9; /*0x102ceb9b5*/
  }
  if ( *(_QWORD *)(a1 + 24) == 8 ) /*0x102ceb90a*/
  {
    v4 = *(double *)v2; /*0x102ceb910*/
LABEL_25:
    *a2 = v4; /*0x102ceba23*/
    return 1; /*0x102ceba2c*/
  }
  ERR_new(); /*0x102ceb9b7*/
  ERR_set_debug(__s: "crypto/params.c", a2: 1193, a3: "OSSL_PARAM_get_double"); /*0x102ceb9cf*/
  v5 = 0; /*0x102ceb9d4*/
  v6 = 130; /*0x102ceb9db*/
LABEL_9:
  ERR_set_error(a1: 15, a2: v6, a3: 0); /*0x102ceb942*/
  return v5; /*0x102ceb951*/
}

// Address: 0x102ceba60 | Name: _OSSL_PARAM_set_double
__int64 __fastcall OSSL_PARAM_set_double(__int64 a1, double a2)
{
  int v2; // eax
  double *v3; // rax
  unsigned int v4; // ebx
  __int64 v5; // rsi
  _DWORD *v6; // rax
  __int64 v7; // rcx
  __m128d v8; // xmm1
  int v9; // esi
  __int64 v10; // rdx
  __int64 v11; // rdx
  int v13; // esi

  if ( a1 == 0 ) /*0x102ceba69*/
  {
    ERR_new(); /*0x102cebabb*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1238, a3: "OSSL_PARAM_set_double"); /*0x102cebad3*/
    v4 = 0; /*0x102cebad8*/
    v5 = 786690; /*0x102cebadf*/
LABEL_29:
    ERR_set_error(a1: 15, a2: v5, a3: 0); /*0x102cebca9*/
    return v4; /*0x102cebcad*/
  }
  *(_QWORD *)(a1 + 32) = 0; /*0x102ceba6b*/
  v2 = *(_DWORD *)(a1 + 8); /*0x102ceba73*/
  if ( v2 == 1 ) /*0x102ceba79*/
  {
    v6 = *(_DWORD **)(a1 + 16); /*0x102cebb60*/
    if ( v6 == nullptr ) /*0x102cebb67*/
      goto LABEL_16; /*0x102cebb67*/
    v7 = (unsigned int)(int)a2; /*0x102cebb69*/
    if ( (double)(int)v7 != a2 ) /*0x102cebb77*/
    {
      ERR_new(); /*0x102cebb7f*/
      v9 = 1297; /*0x102cebb92*/
      goto LABEL_15; /*0x102cebb92*/
    }
    v11 = *(_QWORD *)(a1 + 24); /*0x102cebc37*/
    if ( v11 != 8 ) /*0x102cebc3f*/
    {
      if ( v11 != 4 ) /*0x102cebc49*/
        goto LABEL_28; /*0x102cebc49*/
      if ( a2 >= -2147483648.0 && a2 < 2147483648.0 ) /*0x102cebc65*/
      {
        *(_QWORD *)(a1 + 32) = 4; /*0x102cebc6b*/
        *v6 = (int)a2; /*0x102cebc77*/
        return 1; /*0x102cebc7e*/
      }
      ERR_new(); /*0x102cebd31*/
      v13 = 1307; /*0x102cebd44*/
      goto LABEL_40; /*0x102cebd49*/
    }
    if ( a2 < -9.223372036854776e18 || a2 >= 9.223372036854776e18 ) /*0x102cebd03*/
    {
      ERR_new(); /*0x102cebd4b*/
      v13 = 1315; /*0x102cebd5e*/
      goto LABEL_40; /*0x102cebd5e*/
    }
LABEL_36:
    *(_QWORD *)(a1 + 32) = 8; /*0x102cebd05*/
    *(_QWORD *)v6 = v7; /*0x102cebd0d*/
    return 1; /*0x102cebd15*/
  }
  if ( v2 == 2 ) /*0x102ceba82*/
  {
    v6 = *(_DWORD **)(a1 + 16); /*0x102cebae9*/
    if ( v6 == nullptr ) /*0x102cebaf0*/
      goto LABEL_16; /*0x102cebaf0*/
    v7 = (unsigned int)(int)a2; /*0x102cebb16*/
    v8 = _mm_sub_pd( /*0x102cebb26*/
           (__m128d)_mm_unpacklo_epi32((__m128i)(unsigned int)(int)a2, (__m128i)xmmword_108F2F9A0),
           (__m128d)xmmword_108F2F9B0);
    if ( _mm_unpackhi_pd(v8, v8).f64[0] + v8.f64[0] != a2 ) /*0x102cebb3e*/
    {
      ERR_new(); /*0x102cebb46*/
      v9 = 1266; /*0x102cebb59*/
LABEL_15:
      ERR_set_debug(__s: "crypto/params.c", a2: v9, a3: "OSSL_PARAM_set_double"); /*0x102cebb97*/
      v4 = 0; /*0x102cebb9c*/
      v5 = 123; /*0x102cebba3*/
      goto LABEL_29; /*0x102cebba8*/
    }
    v10 = *(_QWORD *)(a1 + 24); /*0x102cebbed*/
    if ( v10 != 8 ) /*0x102cebbf5*/
    {
      if ( v10 != 4 ) /*0x102cebbff*/
        goto LABEL_28; /*0x102cebbff*/
      if ( a2 >= 0.0 && a2 < 4294967296.0 ) /*0x102cebc1b*/
      {
        *(_QWORD *)(a1 + 32) = 4; /*0x102cebc21*/
        *v6 = (int)a2; /*0x102cebc2e*/
        return 1; /*0x102cebc35*/
      }
      ERR_new(); /*0x102cebd17*/
      v13 = 1276; /*0x102cebd2a*/
LABEL_40:
      ERR_set_debug(__s: "crypto/params.c", a2: v13, a3: "OSSL_PARAM_set_double"); /*0x102cebd63*/
      v4 = 0; /*0x102cebd68*/
      v5 = 126; /*0x102cebd6f*/
      goto LABEL_29; /*0x102cebd74*/
    }
    if ( a2 < 0.0 || a2 >= 1.844674407370955e19 ) /*0x102cebcd1*/
    {
      ERR_new(); /*0x102cebcd3*/
      v13 = 1284; /*0x102cebce6*/
      goto LABEL_40; /*0x102cebceb*/
    }
    goto LABEL_36; /*0x102cebcd1*/
  }
  if ( v2 != 3 ) /*0x102ceba87*/
  {
LABEL_28:
    ERR_new(); /*0x102cebc80*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1319, a3: "OSSL_PARAM_set_double"); /*0x102cebc98*/
    v4 = 0; /*0x102cebc9d*/
    v5 = 129; /*0x102cebca4*/
    goto LABEL_29; /*0x102cebca4*/
  }
  v3 = *(double **)(a1 + 16); /*0x102ceba8d*/
  if ( v3 == nullptr ) /*0x102ceba94*/
  {
LABEL_16:
    *(_QWORD *)(a1 + 32) = 8; /*0x102cebbad*/
    return 1; /*0x102cebbba*/
  }
  if ( *(_QWORD *)(a1 + 24) != 8 ) /*0x102ceba9f*/
  {
    ERR_new(); /*0x102cebbbf*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1254, a3: "OSSL_PARAM_set_double"); /*0x102cebbd7*/
    v4 = 0; /*0x102cebbdc*/
    v5 = 130; /*0x102cebbe3*/
    goto LABEL_29; /*0x102cebbe8*/
  }
  *(_QWORD *)(a1 + 32) = 8; /*0x102cebaa5*/
  *v3 = a2; /*0x102cebaad*/
  return 1; /*0x102cebcb8*/
}

// Address: 0x102cebd80 | Name: _OSSL_PARAM_construct_double
__int64 __fastcall OSSL_PARAM_construct_double(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = a2; /*0x102cebd87*/
  *(_DWORD *)(a1 + 8) = 3; /*0x102cebd8a*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102cebd91*/
  *(_QWORD *)(a1 + 24) = 8; /*0x102cebd95*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102cebd9d*/
  return a1; /*0x102cebda5*/
}

// Address: 0x102cebdb0 | Name: _OSSL_PARAM_get_utf8_string
__int64 __fastcall OSSL_PARAM_get_utf8_string(__int64 a1, void **a2, size_t a3)
{
  unsigned int v5; // r14d
  _BYTE *v6; // rax
  size_t v7; // r14
  size_t v9[4]; // [rsp+0h] [rbp-20h] BYREF

  v9[0] = a3; /*0x102cebdc0*/
  v5 = 0; /*0x102cebdc4*/
  if ( (unsigned int)get_string_internal(a1, a2, a3: v9, a4: nullptr, a5: 4) != 0 ) /*0x102cebdda*/
  {
    v6 = *(_BYTE **)(a1 + 24); /*0x102cebddc*/
    v7 = v9[0]; /*0x102cebde0*/
    if ( (unsigned __int64)v6 >= v9[0] ) /*0x102cebde7*/
      v6 = OPENSSL_strnlen(a1: *(_BYTE **)(a1 + 16), a2: *(_QWORD *)(a1 + 24)); /*0x102cebdf0*/
    if ( (unsigned __int64)v6 >= v7 ) /*0x102cebdf8*/
    {
      ERR_new(); /*0x102cebe09*/
      ERR_set_debug(__s: "crypto/params.c", a2: 1402, a3: "OSSL_PARAM_get_utf8_string"); /*0x102cebe21*/
      v5 = 0; /*0x102cebe26*/
      ERR_set_error(a1: 15, a2: 128, a3: 0); /*0x102cebe37*/
    }
    else
    {
      v6[(_QWORD)*a2] = 0; /*0x102cebdfd*/
      return 1; /*0x102cebe01*/
    }
  }
  return v5; /*0x102cebe43*/
}

// Address: 0x102cebfe0 | Name: _OSSL_PARAM_get_octet_string
__int64 __fastcall OSSL_PARAM_get_octet_string(__int64 a1, void **a2, size_t a3, size_t *a4)
{
  size_t v5; // [rsp+8h] [rbp-8h] BYREF

  v5 = a3; /*0x102cebfe8*/
  return get_string_internal(a1, a2, a3: &v5, a4, a5: 5); /*0x102cebffb*/
}

// Address: 0x102cec010 | Name: _OSSL_PARAM_set_utf8_string
__int64 __fastcall OSSL_PARAM_set_utf8_string(__int64 a1, const char *a2)
{
  size_t v5; // rax

  if ( a2 != nullptr && a1 != 0 ) /*0x102cec01a*/
  {
    *(_QWORD *)(a1 + 32) = 0; /*0x102cec05e*/
    v5 = strlen(__s: a2); /*0x102cec06f*/
    return set_string_internal(a1, a2, a3: v5, a4: 4); /*0x102cec086*/
  }
  else
  {
    ERR_new(); /*0x102cec027*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1442, a3: "OSSL_PARAM_set_utf8_string"); /*0x102cec03f*/
    ERR_set_error(a1: 15, a2: 786690, a3: 0); /*0x102cec052*/
    return 0; /*0x102cec057*/
  }
}

// Address: 0x102cec150 | Name: _OSSL_PARAM_set_octet_string
__int64 __fastcall OSSL_PARAM_set_octet_string(__int64 a1, __int64 a2, __int64 a3)
{
  if ( a2 != 0 && a1 != 0 ) /*0x102cec153*/
  {
    *(_QWORD *)(a1 + 32) = 0; /*0x102cec198*/
    return set_string_internal(a1, a2, a3, a4: 5); /*0x102cec1a5*/
  }
  else
  {
    ERR_new(); /*0x102cec164*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1453, a3: "OSSL_PARAM_set_octet_string"); /*0x102cec17c*/
    ERR_set_error(a1: 15, a2: 786690, a3: 0); /*0x102cec18f*/
    return 0; /*0x102cec194*/
  }
}

// Address: 0x102cec1b0 | Name: _OSSL_PARAM_construct_utf8_string
__int64 __fastcall OSSL_PARAM_construct_utf8_string(__int64 a1, __int64 a2, const char *a3, size_t a4)
{
  if ( a3 != nullptr && a4 == 0 ) /*0x102cec1cc*/
    a4 = strlen(__s: a3); /*0x102cec1db*/
  *(_QWORD *)a1 = a2; /*0x102cec1de*/
  *(_DWORD *)(a1 + 8) = 4; /*0x102cec1e1*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102cec1e8*/
  *(_QWORD *)(a1 + 24) = a4; /*0x102cec1ec*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102cec1f0*/
  return a1; /*0x102cec1ff*/
}

// Address: 0x102cec210 | Name: _OSSL_PARAM_construct_octet_string
__int64 __fastcall OSSL_PARAM_construct_octet_string(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  *(_QWORD *)a1 = a2; /*0x102cec217*/
  *(_DWORD *)(a1 + 8) = 5; /*0x102cec21a*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102cec221*/
  *(_QWORD *)(a1 + 24) = a4; /*0x102cec225*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102cec229*/
  return a1; /*0x102cec231*/
}

// Address: 0x102cec240 | Name: _OSSL_PARAM_get_utf8_ptr
__int64 __fastcall OSSL_PARAM_get_utf8_ptr(__int64 a1, _QWORD *a2)
{
  unsigned int v2; // ebx
  __int64 v3; // rsi

  if ( a2 == nullptr || a1 == 0 ) /*0x102cec24f*/
  {
    ERR_new(); /*0x102cec256*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1478, a3: "get_ptr_internal"); /*0x102cec26e*/
    v2 = 0; /*0x102cec273*/
    v3 = 786690; /*0x102cec27a*/
LABEL_6:
    ERR_set_error(a1: 15, a2: v3, a3: 0); /*0x102cec2c1*/
    return v2; /*0x102cec2c5*/
  }
  if ( *(_DWORD *)(a1 + 8) != 6 ) /*0x102cec285*/
  {
    ERR_new(); /*0x102cec298*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1482, a3: "get_ptr_internal"); /*0x102cec2b0*/
    v2 = 0; /*0x102cec2b5*/
    v3 = 129; /*0x102cec2bc*/
    goto LABEL_6; /*0x102cec2bc*/
  }
  *a2 = **(_QWORD **)(a1 + 16); /*0x102cec28e*/
  return 1; /*0x102cec2d0*/
}

// Address: 0x102cec2e0 | Name: _OSSL_PARAM_get_octet_ptr
__int64 __fastcall OSSL_PARAM_get_octet_ptr(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  unsigned int v3; // ebx
  __int64 v4; // rsi

  if ( a2 == nullptr || a1 == 0 ) /*0x102cec2ef*/
  {
    ERR_new(); /*0x102cec2f6*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1478, a3: "get_ptr_internal"); /*0x102cec30e*/
    v3 = 0; /*0x102cec313*/
    v4 = 786690; /*0x102cec31a*/
LABEL_8:
    ERR_set_error(a1: 15, a2: v4, a3: 0); /*0x102cec36d*/
    return v3; /*0x102cec371*/
  }
  if ( *(_DWORD *)(a1 + 8) != 7 ) /*0x102cec325*/
  {
    ERR_new(); /*0x102cec344*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1482, a3: "get_ptr_internal"); /*0x102cec35c*/
    v3 = 0; /*0x102cec361*/
    v4 = 129; /*0x102cec368*/
    goto LABEL_8; /*0x102cec368*/
  }
  if ( a3 != nullptr ) /*0x102cec32a*/
    *a3 = *(_QWORD *)(a1 + 24); /*0x102cec330*/
  *a2 = **(_QWORD **)(a1 + 16); /*0x102cec33a*/
  return 1; /*0x102cec37c*/
}

// Address: 0x102cec380 | Name: _OSSL_PARAM_set_utf8_ptr
__int64 __fastcall OSSL_PARAM_set_utf8_ptr(__int64 a1, const char *a2)
{
  int v2; // eax
  const char **v5; // rax
  unsigned int v6; // ebx
  __int64 v7; // rsi
  _QWORD *v8; // rax

  if ( a1 == 0 ) /*0x102cec38a*/
  {
    ERR_new(); /*0x102cec3c6*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1518, a3: "OSSL_PARAM_set_utf8_ptr"); /*0x102cec3de*/
    v6 = 0; /*0x102cec3e3*/
    v7 = 786690; /*0x102cec3ea*/
LABEL_11:
    ERR_set_error(a1: 15, a2: v7, a3: 0); /*0x102cec436*/
    return v6; /*0x102cec43a*/
  }
  *(_QWORD *)(a1 + 32) = 0; /*0x102cec38c*/
  v2 = *(_DWORD *)(a1 + 8); /*0x102cec394*/
  if ( a2 != nullptr ) /*0x102cec39a*/
  {
    if ( v2 == 6 ) /*0x102cec39f*/
    {
      *(_QWORD *)(a1 + 32) = strlen(__s: a2); /*0x102cec3af*/
      v5 = *(const char ***)(a1 + 16); /*0x102cec3b3*/
      v6 = 1; /*0x102cec3b7*/
      if ( v5 != nullptr ) /*0x102cec3bf*/
        *v5 = a2; /*0x102cec3c1*/
      return v6; /*0x102cec3c4*/
    }
  }
  else if ( v2 == 6 ) /*0x102cec3f4*/
  {
    v8 = *(_QWORD **)(a1 + 16); /*0x102cec3f6*/
    v6 = 1; /*0x102cec3fa*/
    if ( v8 != nullptr ) /*0x102cec402*/
      *v8 = 0; /*0x102cec404*/
    return v6; /*0x102cec441*/
  }
  ERR_new(); /*0x102cec40d*/
  ERR_set_debug(__s: "crypto/params.c", a2: 1506, a3: "set_ptr_internal"); /*0x102cec425*/
  v6 = 0; /*0x102cec42a*/
  v7 = 129; /*0x102cec431*/
  goto LABEL_11; /*0x102cec431*/
}

// Address: 0x102cec450 | Name: _OSSL_PARAM_set_octet_ptr
__int64 __fastcall OSSL_PARAM_set_octet_ptr(__int64 a1, __int64 a2, __int64 a3)
{
  _QWORD *v3; // rax
  unsigned int v4; // ebx
  __int64 v5; // rsi

  if ( a1 == 0 ) /*0x102cec459*/
  {
    ERR_new(); /*0x102cec480*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1530, a3: "OSSL_PARAM_set_octet_ptr"); /*0x102cec498*/
    v4 = 0; /*0x102cec49d*/
    v5 = 786690; /*0x102cec4a4*/
LABEL_7:
    ERR_set_error(a1: 15, a2: v5, a3: 0); /*0x102cec4d4*/
    return v4; /*0x102cec4d8*/
  }
  *(_QWORD *)(a1 + 32) = 0; /*0x102cec45b*/
  if ( *(_DWORD *)(a1 + 8) != 7 ) /*0x102cec467*/
  {
    ERR_new(); /*0x102cec4ab*/
    ERR_set_debug(__s: "crypto/params.c", a2: 1506, a3: "set_ptr_internal"); /*0x102cec4c3*/
    v4 = 0; /*0x102cec4c8*/
    v5 = 129; /*0x102cec4cf*/
    goto LABEL_7; /*0x102cec4cf*/
  }
  *(_QWORD *)(a1 + 32) = a3; /*0x102cec469*/
  v3 = *(_QWORD **)(a1 + 16); /*0x102cec46d*/
  v4 = 1; /*0x102cec471*/
  if ( v3 != nullptr ) /*0x102cec479*/
    *v3 = a2; /*0x102cec47b*/
  return v4; /*0x102cec4e3*/
}

// Address: 0x102cec4f0 | Name: _OSSL_PARAM_construct_utf8_ptr
__int64 __fastcall OSSL_PARAM_construct_utf8_ptr(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  *(_QWORD *)a1 = a2; /*0x102cec4f7*/
  *(_DWORD *)(a1 + 8) = 6; /*0x102cec4fa*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102cec501*/
  *(_QWORD *)(a1 + 24) = a4; /*0x102cec505*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102cec509*/
  return a1; /*0x102cec511*/
}

// Address: 0x102cec520 | Name: _OSSL_PARAM_construct_octet_ptr
__int64 __fastcall OSSL_PARAM_construct_octet_ptr(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  *(_QWORD *)a1 = a2; /*0x102cec527*/
  *(_DWORD *)(a1 + 8) = 7; /*0x102cec52a*/
  *(_QWORD *)(a1 + 16) = a3; /*0x102cec531*/
  *(_QWORD *)(a1 + 24) = a4; /*0x102cec535*/
  *(_QWORD *)(a1 + 32) = -1; /*0x102cec539*/
  return a1; /*0x102cec541*/
}

// Address: 0x102cec550 | Name: _ossl_param_get1_octet_string
__int64 __fastcall ossl_param_get1_octet_string(const char **a1, const char *a2, void **a3, size_t *a4)
{
  const char **v6; // r15
  const char *v7; // rsi
  size_t v10; // [rsp+8h] [rbp-38h] BYREF
  void *v11; // [rsp+10h] [rbp-30h] BYREF
  size_t v12[5]; // [rsp+18h] [rbp-28h] BYREF

  if ( a1 == nullptr || a2 == nullptr ) /*0x102cec56b*/
    return 0xFFFFFFFFLL; /*0x102cec570*/
  v6 = a1; /*0x102cec575*/
  v7 = *a1; /*0x102cec578*/
  if ( *a1 == nullptr ) /*0x102cec57e*/
    return 0xFFFFFFFFLL; /*0x102cec5a9*/
  while ( strcmp(__s1: a2, __s2: v7) != 0 ) /*0x102cec59a*/
  {
    v7 = v6[5]; /*0x102cec59c*/
    v6 += 5; /*0x102cec5a0*/
    if ( v7 == nullptr ) /*0x102cec5a7*/
      return 0xFFFFFFFFLL; /*0x102cec5a7*/
  }
  v11 = nullptr; /*0x102cec5bb*/
  v12[0] = 0; /*0x102cec5c3*/
  if ( v6[2] != nullptr && v6[3] != nullptr ) /*0x102cec5d7*/
  {
    v10 = 0; /*0x102cec5d9*/
    if ( (unsigned int)get_string_internal(a1: (__int64)v6, a2: &v11, a3: &v10, a4: v12, a5: 5) == 0 ) /*0x102cec5fd*/
      return 0; /*0x102cec62b*/
  }
  CRYPTO_clear_free(a1: *a3, a2: *a4); /*0x102cec611*/
  *a3 = v11; /*0x102cec61a*/
  *a4 = v12[0]; /*0x102cec621*/
  return 1; /*0x102cec5ae*/
}

// Address: 0x102cec640 | Name: _ossl_param_get1_concat_octet_string
__int64 __fastcall ossl_param_get1_concat_octet_string(
        const char **a1,
        const char *a2,
        void **a3,
        size_t *a4,
        unsigned __int64 a5)
{
  const char **v7; // r13
  const char *v8; // rsi
  unsigned int v11; // r15d
  void *v13; // rax
  void *v14; // rbx
  size_t *v15; // [rsp+8h] [rbp-38h]
  int num[2]; // [rsp+10h] [rbp-30h] BYREF

  if ( a1 == nullptr || a2 == nullptr ) /*0x102cec65d*/
    return (unsigned int)-1; /*0x102cec662*/
  v7 = a1; /*0x102cec667*/
  v8 = *a1; /*0x102cec66a*/
  if ( *a1 == nullptr ) /*0x102cec670*/
  {
    return (unsigned int)-1; /*0x102cec699*/
  }
  else
  {
    while ( strcmp(__s1: a2, __s2: v8) != 0 ) /*0x102cec68a*/
    {
      v8 = v7[5]; /*0x102cec68c*/
      v7 += 5; /*0x102cec690*/
      if ( v8 == nullptr ) /*0x102cec697*/
        return (unsigned int)-1; /*0x102cec697*/
    }
    v15 = a4; /*0x102cec6b1*/
    *(_QWORD *)num = 0; /*0x102cec6b5*/
    v11 = 0; /*0x102cec6bd*/
    if ( (unsigned int)setbuf_fromparams(a1: v7, a2, a3: 0, a4: num) != 0 && (*(_QWORD *)num <= a5 || a5 == 0) ) /*0x102cec6d8*/
    {
      if ( *(_QWORD *)num == 0 ) /*0x102cec6f3*/
      {
        v14 = CRYPTO_zalloc(__size: 1u, __s: "crypto/params.c", line: 1631); /*0x102cec749*/
        if ( v14 == nullptr ) /*0x102cec74f*/
          return v11; /*0x102cec74f*/
        goto LABEL_14; /*0x102cec74f*/
      }
      v13 = CRYPTO_malloc(num: num[0], file: "crypto/params.c", line: 1637); /*0x102cec6fa*/
      if ( v13 != nullptr ) /*0x102cec702*/
      {
        v14 = v13; /*0x102cec704*/
        if ( (unsigned int)setbuf_fromparams(a1: v7, a2, a3: v13, a4: num) == 0 ) /*0x102cec71b*/
        {
          CRYPTO_clear_free(a1: v14, a2: *(size_t *)num); /*0x102cec730*/
          return v11; /*0x102cec735*/
        }
LABEL_14:
        CRYPTO_clear_free(a1: *a3, a2: *v15); /*0x102cec755*/
        *a3 = v14; /*0x102cec770*/
        *v15 = *(_QWORD *)num; /*0x102cec777*/
        return 1; /*0x102cec77a*/
      }
    }
  }
  return v11; /*0x102cec6a2*/
}

// Address: 0x102cec8c0 | Name: _OSSL_PARAM_construct_end
__int64 __fastcall OSSL_PARAM_construct_end(__int64 a1)
{
  *(_OWORD *)(a1 + 16) = 0; /*0x102cec8ca*/
  *(_OWORD *)a1 = 0; /*0x102cec8ce*/
  *(_QWORD *)(a1 + 32) = 0; /*0x102cec8d1*/
  return a1; /*0x102cec8d9*/
}

// Address: 0x102cec8e0 | Name: _OSSL_PARAM_get_utf8_string_ptr
__int64 __fastcall OSSL_PARAM_get_utf8_string_ptr(__int64 a1, _QWORD *a2)
{
  int utf8_ptr; // r12d
  unsigned int v5; // ebx
  __int64 v6; // rsi

  ERR_set_mark(); /*0x102cec8f1*/
  utf8_ptr = OSSL_PARAM_get_utf8_ptr(a1, a2); /*0x102cec901*/
  ERR_pop_to_mark(); /*0x102cec904*/
  v5 = 1; /*0x102cec909*/
  if ( utf8_ptr == 0 ) /*0x102cec911*/
  {
    if ( a2 == nullptr || a1 == 0 ) /*0x102cec91c*/
    {
      ERR_new(); /*0x102cec923*/
      ERR_set_debug(__s: "crypto/params.c", a2: 1665, a3: "get_string_ptr_internal"); /*0x102cec93b*/
      v5 = 0; /*0x102cec940*/
      v6 = 786690; /*0x102cec947*/
LABEL_7:
      ERR_set_error(a1: 15, a2: v6, a3: 0); /*0x102cec987*/
      return v5; /*0x102cec98b*/
    }
    if ( *(_DWORD *)(a1 + 8) != 4 ) /*0x102cec953*/
    {
      ERR_new(); /*0x102cec95e*/
      ERR_set_debug(__s: "crypto/params.c", a2: 1669, a3: "get_string_ptr_internal"); /*0x102cec976*/
      v5 = 0; /*0x102cec97b*/
      v6 = 129; /*0x102cec982*/
      goto LABEL_7; /*0x102cec982*/
    }
    *a2 = *(_QWORD *)(a1 + 16); /*0x102cec959*/
  }
  return v5; /*0x102cec992*/
}

// Address: 0x102cec9a0 | Name: _OSSL_PARAM_get_octet_string_ptr
__int64 __fastcall OSSL_PARAM_get_octet_string_ptr(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  int octet_ptr; // r13d
  unsigned int v7; // ebx
  __int64 v8; // rsi

  ERR_set_mark(); /*0x102cec9b7*/
  octet_ptr = OSSL_PARAM_get_octet_ptr(a1, a2, a3); /*0x102cec9ca*/
  ERR_pop_to_mark(); /*0x102cec9cd*/
  v7 = 1; /*0x102cec9d2*/
  if ( octet_ptr == 0 ) /*0x102cec9da*/
  {
    if ( a2 == nullptr || a1 == 0 ) /*0x102cec9e9*/
    {
      ERR_new(); /*0x102cec9f0*/
      ERR_set_debug(__s: "crypto/params.c", a2: 1665, a3: "get_string_ptr_internal"); /*0x102ceca08*/
      v7 = 0; /*0x102ceca0d*/
      v8 = 786690; /*0x102ceca14*/
LABEL_9:
      ERR_set_error(a1: 15, a2: v8, a3: 0); /*0x102ceca61*/
      return v7; /*0x102ceca65*/
    }
    if ( *(_DWORD *)(a1 + 8) != 5 ) /*0x102ceca20*/
    {
      ERR_new(); /*0x102ceca38*/
      ERR_set_debug(__s: "crypto/params.c", a2: 1669, a3: "get_string_ptr_internal"); /*0x102ceca50*/
      v7 = 0; /*0x102ceca55*/
      v8 = 129; /*0x102ceca5c*/
      goto LABEL_9; /*0x102ceca5c*/
    }
    if ( a3 != nullptr ) /*0x102ceca25*/
      *a3 = *(_QWORD *)(a1 + 24); /*0x102ceca2b*/
    *a2 = *(_QWORD *)(a1 + 16); /*0x102ceca33*/
  }
  return v7; /*0x102ceca70*/
}

// Address: 0x102cecb30 | Name: _ossl_param_bytes_to_blocks
unsigned __int64 __fastcall ossl_param_bytes_to_blocks(__int64 a1)
{
  return (unsigned __int64)(a1 + 7) >> 3; /*0x102cecb3c*/
}

// Address: 0x102cecb40 | Name: _ossl_param_set_secure_block
void __fastcall ossl_param_set_secure_block(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = 0; /*0x102cecb44*/
  *(_QWORD *)(a1 + 24) = a3; /*0x102cecb4b*/
  *(_QWORD *)(a1 + 16) = a2; /*0x102cecb4f*/
  *(_DWORD *)(a1 + 8) = 127; /*0x102cecb53*/
}

// Address: 0x102cecb60 | Name: _OSSL_PARAM_dup
_QWORD *__fastcall OSSL_PARAM_dup(_QWORD *a1)
{
  _QWORD *v1; // rbx
  __int64 v2; // r14
  __int64 v3; // r15
  bool v4; // zf
  int v5; // eax
  __int64 v6; // rcx
  __int64 v7; // rdi
  __int64 v8; // rbx
  char *v10; // rax
  _QWORD *v11; // r14
  __int64 v12; // r15
  char *v13; // rax
  __int64 v14; // r12
  int v15; // eax
  __int128 v16; // xmm1
  __int64 v17; // r15
  _QWORD *v18; // r13
  int v19; // eax
  size_t v20; // r12
  char *v21; // [rsp+8h] [rbp-88h]
  _QWORD *v22; // [rsp+10h] [rbp-80h]
  __int64 v23; // [rsp+18h] [rbp-78h]
  void *__dst[2]; // [rsp+20h] [rbp-70h]
  __int128 v25; // [rsp+30h] [rbp-60h]
  __int128 v26; // [rsp+40h] [rbp-50h]
  __int128 v27; // [rsp+50h] [rbp-40h]

  if ( a1 != nullptr ) /*0x102cecb82*/
  {
    v1 = a1; /*0x102cecb88*/
    v27 = 0; /*0x102cecb8e*/
    v26 = 0; /*0x102cecb92*/
    v25 = 0; /*0x102cecb96*/
    *(_OWORD *)__dst = 0; /*0x102cecb9a*/
    if ( *a1 != 0 ) /*0x102cecba2*/
    {
      v2 = 5; /*0x102cecba8*/
      do /*0x102cecbd7*/
      {
        v5 = CRYPTO_secure_allocated(a1: (char *)v1[v2 - 3]); /*0x102cecbde*/
        v6 = 15; /*0x102cecbed*/
        if ( (v1[v2 - 4] & 0xFFFFFFFE) != 6 ) /*0x102cecbf5*/
          v6 = v1[v2 - 2] + 7LL; /*0x102cecbfc*/
        *((_QWORD *)&v25 + 4 * v5) += (v6 + (unsigned __int64)(LODWORD(v1[v2 - 4]) == 4)) >> 3; /*0x102cecbc6*/
        v3 = v2 * 8 + 40; /*0x102cecbcb*/
        v4 = v1[v2] == 0; /*0x102cecbcf*/
        v2 += 5; /*0x102cecbd4*/
      }
      while ( !v4 ); /*0x102cecbd7*/
      v7 = 8 * v25; /*0x102cecc06*/
    }
    else
    {
      v3 = 40; /*0x102cecc64*/
      v7 = 0; /*0x102cecc6a*/
    }
    v10 = (char *)CRYPTO_zalloc(__size: v3 + v7, __s: "crypto/params_dup.c", line: 39); /*0x102cecc7b*/
    if ( v10 != nullptr ) /*0x102cecc83*/
    {
      v11 = v10; /*0x102cecc89*/
      __dst[1] = &v10[v3]; /*0x102cecc8f*/
      if ( (_QWORD)v27 == 0 ) /*0x102cecc9a*/
      {
        v23 = 0; /*0x102ceccdb*/
        v21 = nullptr; /*0x102cecce5*/
        v22 = v10; /*0x102ceccf0*/
        if ( *v1 == 0 ) /*0x102ceccf4*/
        {
LABEL_22:
          *v11 = 0; /*0x102cecd9a*/
          v11[3] = v23; /*0x102cecda5*/
          v11[2] = v21; /*0x102cecdb0*/
          *((_DWORD *)v11 + 2) = 127; /*0x102cecdb4*/
          return v22; /*0x102cecdce*/
        }
LABEL_17:
        v11 = v22; /*0x102ceccfa*/
        do /*0x102cecd3b*/
        {
          v15 = CRYPTO_secure_allocated(a1: (char *)v1[2]); /*0x102cecd41*/
          v16 = *((_OWORD *)v1 + 1); /*0x102cecd49*/
          *(_OWORD *)v11 = *(_OWORD *)v1; /*0x102cecd4d*/
          *((_OWORD *)v11 + 1) = v16; /*0x102cecd51*/
          v11[4] = v1[4]; /*0x102cecd5a*/
          v17 = 4LL * v15; /*0x102cecd61*/
          v18 = __dst[v17 + 1]; /*0x102cecd65*/
          v11[2] = v18; /*0x102cecd6a*/
          v19 = *((_DWORD *)v1 + 2); /*0x102cecd6e*/
          if ( (v19 & 0xFFFFFFFE) == 6 ) /*0x102cecd79*/
          {
            *v18 = *(_QWORD *)v1[2]; /*0x102cecd07*/
            v14 = 15; /*0x102cecd0b*/
          }
          else
          {
            v20 = v1[3]; /*0x102cecd7f*/
            memcpy(__dst: v18, __src: (const void *)v1[2], __n: v20); /*0x102cecd89*/
            v14 = v20 + 7; /*0x102cecd8e*/
            v19 = *((_DWORD *)v1 + 2); /*0x102cecd92*/
          }
          v11 += 5; /*0x102cecd24*/
          __dst[v17 + 1] = (char *)v18 + ((v14 + (v19 == 4)) & 0xFFFFFFFFFFFFFFF8LL); /*0x102cecd2f*/
          v4 = v1[5] == 0; /*0x102cecd32*/
          v1 += 5; /*0x102cecd37*/
        }
        while ( !v4 ); /*0x102cecd3b*/
        goto LABEL_22; /*0x102cecd3b*/
      }
      v12 = 8 * v27; /*0x102cecc9c*/
      v13 = CRYPTO_secure_zalloc(a1: 8 * v27, a2: "crypto/params_dup.c", a3: 39); /*0x102ceccaf*/
      if ( v13 != nullptr ) /*0x102ceccb7*/
      {
        v23 = v12; /*0x102ceccbd*/
        *((_QWORD *)&v26 + 1) = v13; /*0x102ceccc1*/
        v21 = v13; /*0x102ceccc5*/
        v22 = v11; /*0x102ceccd0*/
        if ( *v1 == 0 ) /*0x102ceccd4*/
          goto LABEL_22; /*0x102ceccd4*/
        goto LABEL_17; /*0x102ceccd4*/
      }
      CRYPTO_free(a1: v11); /*0x102cecde5*/
    }
    return nullptr; /*0x102cecdfa*/
  }
  ERR_new(); /*0x102cecc0c*/
  ERR_set_debug(__s: "crypto/params_dup.c", a2: 106, a3: "OSSL_PARAM_dup"); /*0x102cecc24*/
  v8 = 0; /*0x102cecc29*/
  ERR_set_error(a1: 15, a2: 786690, a3: 0); /*0x102cecc39*/
  return (_QWORD *)v8; /*0x102cecc55*/
}

// Address: 0x102cece10 | Name: _OSSL_PARAM_merge
_QWORD *__fastcall OSSL_PARAM_merge(__int128 a1)
{
  unsigned int v1; // r14d
  int v2; // ebx
  unsigned __int64 v3; // rax
  size_t v4; // rbx
  bool v5; // cf
  unsigned __int64 v6; // rax
  size_t v7; // r12
  __int128 **v8; // r14
  __int64 **v9; // r15
  _QWORD *v10; // rax
  _QWORD *v11; // rbx
  __int128 *v12; // rax
  _QWORD *v13; // r12
  __int64 *v14; // rax
  __int128 v15; // xmm0
  int v16; // eax
  __int128 *v17; // rax
  __int128 v18; // xmm0
  __int64 *v19; // rax
  __int128 v20; // xmm0
  __int64 *v21; // rax
  __int64 **v22; // r15
  __int128 v23; // xmm0
  __int128 **v25; // r14
  __int128 v26; // xmm0
  _QWORD v27[130]; // [rsp+0h] [rbp-850h] BYREF
  _QWORD __base[130]; // [rsp+410h] [rbp-440h] BYREF

  if ( a1 == 0 ) /*0x102cece38*/
  {
    v1 = 786690; /*0x102cece3a*/
    v2 = 157; /*0x102cece40*/
LABEL_35:
    ERR_new(); /*0x102ced073*/
    ERR_set_debug(__s: "crypto/params_dup.c", a2: v2, a3: "OSSL_PARAM_merge"); /*0x102ced088*/
    v11 = nullptr; /*0x102ced08d*/
    ERR_set_error(a1: 15, a2: v1, a3: 0); /*0x102ced09b*/
    return v11; /*0x102ced09b*/
  }
  if ( (_QWORD)a1 != 0 ) /*0x102cece4d*/
  {
    if ( *(_QWORD *)a1 == 0 ) /*0x102cece53*/
    {
      v4 = 0; /*0x102ceced2*/
      __base[0] = 0; /*0x102ceced4*/
      if ( *((_QWORD *)&a1 + 1) != 0 ) /*0x102cecee3*/
        goto LABEL_11; /*0x102cecee3*/
LABEL_17:
      v7 = 0; /*0x102cecee5*/
      goto LABEL_18; /*0x102cecee5*/
    }
    v3 = 0; /*0x102cece55*/
    do /*0x102cece7e*/
    {
      v4 = v3 + 1; /*0x102cece60*/
      __base[v3] = a1; /*0x102cece64*/
      if ( *(_QWORD *)(a1 + 40) == 0 ) /*0x102cece71*/
        break; /*0x102cece71*/
      *(_QWORD *)&a1 = a1 + 40; /*0x102cece73*/
      v5 = v3++ < 0x7F; /*0x102cece77*/
    }
    while ( v5 ); /*0x102cece7e*/
  }
  else
  {
    v4 = 0; /*0x102cece82*/
  }
  __base[v4] = 0; /*0x102cece84*/
  if ( *((_QWORD *)&a1 + 1) == 0 ) /*0x102cece93*/
    goto LABEL_17; /*0x102cece93*/
LABEL_11:
  if ( **((_QWORD **)&a1 + 1) == 0 ) /*0x102cece99*/
  {
    v7 = 0; /*0x102ced04d*/
    v27[0] = 0; /*0x102ced050*/
    if ( v4 != 0 ) /*0x102ced062*/
      goto LABEL_19; /*0x102ced062*/
LABEL_34:
    v1 = 131; /*0x102ced068*/
    v2 = 175; /*0x102ced06e*/
    goto LABEL_35; /*0x102ced06e*/
  }
  v6 = 0; /*0x102cece9f*/
  do /*0x102cecece*/
  {
    v7 = v6 + 1; /*0x102ceceb0*/
    v27[v6] = *((_QWORD *)&a1 + 1); /*0x102ceceb4*/
    if ( *(_QWORD *)(*((_QWORD *)&a1 + 1) + 40LL) == 0 ) /*0x102cecec1*/
      break; /*0x102cecec1*/
    *((_QWORD *)&a1 + 1) += 40LL; /*0x102cecec3*/
    v5 = v6++ < 0x7F; /*0x102cecec7*/
  }
  while ( v5 ); /*0x102cecece*/
LABEL_18:
  v27[v7] = 0; /*0x102cecee8*/
  if ( (v4 | v7) == 0 ) /*0x102cecefa*/
    goto LABEL_34; /*0x102cecefa*/
LABEL_19:
  v8 = (__int128 **)__base; /*0x102cecf00*/
  qsort(__base, __nel: v4, __width: 8u, __compar: (int (__cdecl *)(const void *, const void *))compare_params); /*0x102cecf1c*/
  v9 = (__int64 **)v27; /*0x102cecf21*/
  qsort(__base: v27, __nel: v7, __width: 8u, __compar: (int (__cdecl *)(const void *, const void *))compare_params); /*0x102cecf36*/
  v10 = CRYPTO_zalloc(__size: 40 * (v4 + v7) + 40, __s: "crypto/params_dup.c", line: 184); /*0x102cecf56*/
  if ( v10 == nullptr ) /*0x102cecf5e*/
    return nullptr; /*0x102ced0c7*/
  v11 = v10; /*0x102cecf64*/
  v12 = (__int128 *)__base[0]; /*0x102cecf67*/
  v13 = v11; /*0x102cecf6e*/
  if ( __base[0] == 0 ) /*0x102cecf74*/
  {
LABEL_30:
    v21 = *v9; /*0x102ced018*/
    v22 = v9 + 1; /*0x102ced01b*/
    do /*0x102ced049*/
    {
      v13[4] = v21[4]; /*0x102ced024*/
      v23 = *(_OWORD *)v21; /*0x102ced029*/
      *((_OWORD *)v13 + 1) = *((_OWORD *)v21 + 1); /*0x102ced030*/
      *(_OWORD *)v13 = v23; /*0x102ced036*/
      v13 += 5; /*0x102ced03b*/
      v21 = *v22++; /*0x102ced03f*/
    }
    while ( v21 != nullptr ); /*0x102ced049*/
    return v11; /*0x102ced049*/
  }
  v13 = v11; /*0x102cecf7a*/
  while ( *v9 != nullptr ) /*0x102cecfb4*/
  {
    v16 = OPENSSL_strcasecmp(a1: *(_QWORD *)v12, a2: **v9); /*0x102cecfc0*/
    if ( v16 == 0 ) /*0x102cecfc7*/
    {
      v19 = *v9; /*0x102cecff0*/
      v13[4] = (*v9)[4]; /*0x102cecff7*/
      v20 = *(_OWORD *)v19; /*0x102cecffc*/
      *((_OWORD *)v13 + 1) = *((_OWORD *)v19 + 1); /*0x102ced003*/
      *(_OWORD *)v13 = v20; /*0x102ced009*/
      ++v9; /*0x102ced00e*/
      goto LABEL_29; /*0x102ced00e*/
    }
    if ( v16 <= 0 ) /*0x102cecfc9*/
    {
      v17 = *v8; /*0x102cecfcb*/
      v13[4] = *((_QWORD *)*v8 + 4); /*0x102cecfd2*/
      v18 = *v17; /*0x102cecfd7*/
      *((_OWORD *)v13 + 1) = v17[1]; /*0x102cecfde*/
      *(_OWORD *)v13 = v18; /*0x102cecfe4*/
LABEL_29:
      ++v8; /*0x102ced012*/
      goto LABEL_23; /*0x102ced016*/
    }
    v14 = *v9; /*0x102cecf80*/
    v13[4] = (*v9)[4]; /*0x102cecf87*/
    v15 = *(_OWORD *)v14; /*0x102cecf8c*/
    *((_OWORD *)v13 + 1) = *((_OWORD *)v14 + 1); /*0x102cecf93*/
    *(_OWORD *)v13 = v15; /*0x102cecf99*/
    ++v9; /*0x102cecf9e*/
LABEL_23:
    v13 += 5; /*0x102cecfa2*/
    v12 = *v8; /*0x102cecfa6*/
    if ( *v8 == nullptr ) /*0x102cecfac*/
      goto LABEL_30; /*0x102cecfac*/
  }
  v25 = v8 + 1; /*0x102ced0c9*/
  do /*0x102ced0f9*/
  {
    v13[4] = *((_QWORD *)v12 + 4); /*0x102ced0d4*/
    v26 = *v12; /*0x102ced0d9*/
    *((_OWORD *)v13 + 1) = v12[1]; /*0x102ced0e0*/
    *(_OWORD *)v13 = v26; /*0x102ced0e6*/
    v13 += 5; /*0x102ced0eb*/
    v12 = *v25++; /*0x102ced0ef*/
  }
  while ( v12 != nullptr ); /*0x102ced0f9*/
  return v11; /*0x102ced0b3*/
}

// Address: 0x102ced130 | Name: _OSSL_PARAM_free
void __fastcall OSSL_PARAM_free(_QWORD *a1)
{
  _QWORD *v1; // rcx
  bool v2; // zf
  _QWORD *v3; // rbx

  if ( a1 != nullptr ) /*0x102ced133*/
  {
    v1 = a1; /*0x102ced13b*/
    do /*0x102ced148*/
    {
      v2 = *v1 == 0; /*0x102ced140*/
      v1 += 5; /*0x102ced144*/
    }
    while ( !v2 ); /*0x102ced148*/
    if ( *((_DWORD *)v1 - 8) == 127 ) /*0x102ced14e*/
    {
      v3 = a1; /*0x102ced15f*/
      CRYPTO_secure_clear_free(ptr: (char *)*(v1 - 3), a2: *(v1 - 2)); /*0x102ced16a*/
      a1 = v3; /*0x102ced16f*/
    }
    CRYPTO_free(a1); /*0x102ced184*/
  }
}

// Address: 0x102ced190 | Name: _OSSL_PARAM_print_to_bio
__int64 __fastcall OSSL_PARAM_print_to_bio(const char **a1, BIO *a2, int a3)
{
  const char *v4; // rdx
  __int64 v6; // r15
  unsigned int v7; // ebx
  int v8; // edx
  int v9; // eax
  const char **v10; // r15
  __int64 v12; // [rsp+8h] [rbp-48h] BYREF
  __int64 v13; // [rsp+10h] [rbp-40h] BYREF
  double v14; // [rsp+18h] [rbp-38h] BYREF
  BIGNUM *a; // [rsp+20h] [rbp-30h] BYREF

  v4 = *a1; /*0x102ced1a3*/
  if ( *a1 != nullptr )
  {
    v6 = (__int64)a1; /*0x102ced1b2*/
    if ( a3 != 0 )
    {
      v7 = 0; /*0x102ced1c4*/
      while ( BIO_printf(bio: a2, format: "%s: ", v4) != -1 )
      {
        v8 = *(_DWORD *)(v6 + 8); /*0x102ced1e6*/
        switch ( v8 ) /*0x102ced1fa*/
        {
          case 1: /*0x102ced1fa*/
            if ( *(_QWORD *)(v6 + 24) >= 9u ) /*0x102ced260*/
              goto LABEL_14; /*0x102ced260*/
            if ( (unsigned int)OSSL_PARAM_get_int64(a1: v6, a2: (char *)&v12) == 0 ) /*0x102ced270*/
              goto LABEL_18; /*0x102ced270*/
            v9 = BIO_printf(bio: a2, format: "%lld\n", v12); /*0x102ced280*/
            break; /*0x102ced280*/
          case 2: /*0x102ced1fa*/
            if ( *(_QWORD *)(v6 + 24) < 9u ) /*0x102ced287*/
            {
              if ( (unsigned int)OSSL_PARAM_get_uint64(a1: v6, a2: (char *)&v13) == 0 ) /*0x102ced2b5*/
                goto LABEL_18; /*0x102ced2b5*/
              v9 = BIO_printf(bio: a2, format: "%llu\n", v13); /*0x102ced2c7*/
            }
            else
            {
LABEL_14:
              if ( (unsigned int)OSSL_PARAM_get_BN(a1: v6, a2: &a) == 0 ) /*0x102ced297*/
                goto LABEL_18; /*0x102ced297*/
              v9 = BN_print(fp: a2, a); /*0x102ced2a0*/
            }
            break; /*0x102ced2a5*/
          case 3: /*0x102ced1fa*/
            if ( (unsigned int)OSSL_PARAM_get_double(a1: v6, a2: &v14) == 1 ) /*0x102ced23a*/
              v9 = BIO_printf(bio: a2, format: "%f\n", v14); /*0x102ced251*/
            else
LABEL_18:
              v9 = BIO_printf(bio: a2, format: "error getting value\n"); /*0x102ced2ce*/
            break; /*0x102ced256*/
          case 4: /*0x102ced1fa*/
          case 5: /*0x102ced1fa*/
          case 6: /*0x102ced1fa*/
          case 7: /*0x102ced1fa*/
            v9 = BIO_dump(b: a2, bytes: *(const char **)(v6 + 16), len: *(_DWORD *)(v6 + 24)); /*0x102ced207*/
            break; /*0x102ced20c*/
          default:
            v9 = BIO_printf(bio: a2, format: "unknown type (%u) of %zu bytes\n", v8, *(_QWORD *)(v6 + 24)); /*0x102ced221*/
            break; /*0x102ced226*/
        }
        if ( v9 == -1 ) /*0x102ced2e3*/
          break; /*0x102ced2e3*/
        v4 = *(const char **)(v6 + 40); /*0x102ced2e5*/
        v6 += 40; /*0x102ced2e9*/
        if ( v4 == nullptr ) /*0x102ced2f0*/
          return 1; /*0x102ced2f0*/
      }
    }
    else
    {
      v10 = a1 + 5; /*0x102ced2fc*/
      v7 = 0; /*0x102ced30e*/
      while ( BIO_printf(bio: a2, format: "%s: ", v4) != -1 )
      {
        BIO_printf(bio: a2, format: "\n"); /*0x102ced32a*/
        v4 = *v10; /*0x102ced32f*/
        v10 += 5; /*0x102ced332*/
        if ( v4 == nullptr ) /*0x102ced339*/
          return 1; /*0x102ced33b*/
      }
    }
  }
  else
  {
    return 0; /*0x102ced2f8*/
  }
  return v7; /*0x102ced342*/
}

// Address: 0x102ced370 | Name: _OSSL_PARAM_allocate_from_text
__int64 __fastcall OSSL_PARAM_allocate_from_text(
        __int64 a1,
        const char **a2,
        _BYTE *a3,
        char *a4,
        unsigned __int64 a5,
        _DWORD *a6)
{
  __int64 result; // rax
  bool v11; // zf
  __int64 v12; // rax
  const char **v13; // rax
  const char **v14; // r14
  int v15; // eax
  size_t v16; // rax
  BIGNUM *v17; // rdi
  int v18; // eax
  __int64 v19; // rsi
  char *v20; // rax
  int v21; // ecx
  char *v22; // rsi
  char *v23; // r12
  BIGNUM *v24; // r12
  char *v25; // r13
  unsigned __int64 v26; // rdx
  char *v27; // rsi
  unsigned __int64 v28; // rcx
  const char *v29; // rsi
  char *v30; // r12
  _BOOL4 is_negative; // eax
  unsigned __int64 v32; // rcx
  unsigned __int64 v33; // rax
  __int64 v34; // rcx
  char *v35; // r12
  int v36; // ecx
  __int64 v37; // rdx
  __m128i v38; // xmm2
  unsigned __int64 v39; // rdi
  __int64 v40; // rcx
  unsigned __int64 v41; // [rsp+0h] [rbp-40h] BYREF
  BIGNUM *a; // [rsp+8h] [rbp-38h] BYREF
  bool v43; // [rsp+17h] [rbp-29h]

  a = nullptr; /*0x102ced387*/
  result = 0; /*0x102ced39c*/
  if ( a1 != 0 && a2 != nullptr ) /*0x102ced398*/
  {
    v43 = true; /*0x102ced3ad*/
    if ( *a3 == 104 && a3[1] == 101 ) /*0x102ced3ba*/
    {
      v11 = a3[2] == 120; /*0x102ced3be*/
      v43 = a3[2] != 120; /*0x102ced3c2*/
      v12 = 3LL * v11; /*0x102ced3c9*/
    }
    else
    {
      v12 = 0; /*0x102ced3cf*/
    }
    v13 = OSSL_PARAM_locate_const(a1: a2, a2: &a3[v12]); /*0x102ced3da*/
    v14 = v13; /*0x102ced3df*/
    if ( a6 != nullptr ) /*0x102ced3e5*/
      *a6 = v13 != nullptr; /*0x102ced3ef*/
    if ( v13 == nullptr ) /*0x102ced3f6*/
      goto LABEL_56; /*0x102ced3f6*/
    v15 = *((_DWORD *)v13 + 2); /*0x102ced3fc*/
    if ( (unsigned int)(v15 - 1) < 2 ) /*0x102ced406*/
    {
      if ( v43 ) /*0x102ced441*/
      {
        if ( (unsigned int)BN_asc2bn(&a, a2: a4) == 0 ) /*0x102ced451*/
          goto LABEL_56; /*0x102ced451*/
      }
      else if ( BN_hex2bn(&a, str: a4) == 0 ) /*0x102ced480*/
      {
        goto LABEL_56; /*0x102ced480*/
      }
      v17 = a; /*0x102ced486*/
      if ( a == nullptr ) /*0x102ced48d*/
        goto LABEL_56; /*0x102ced48d*/
      v18 = *((_DWORD *)v14 + 2); /*0x102ced493*/
      if ( v18 == 2 ) /*0x102ced49a*/
      {
        if ( BN_is_negative(a1: (__int64)a) ) /*0x102ced4a0*/
        {
          ERR_new(); /*0x102ced4ad*/
          ERR_set_debug(__s: "crypto/params_from_text.c", a2: 60, a3: "prepare_from_text"); /*0x102ced4c5*/
          v19 = 122; /*0x102ced4cf*/
          goto LABEL_55; /*0x102ced4d4*/
        }
        v18 = *((_DWORD *)v14 + 2); /*0x102ced617*/
        v17 = a; /*0x102ced61b*/
      }
      if ( v18 == 1 ) /*0x102ced622*/
      {
        is_negative = BN_is_negative(a1: (__int64)v17); /*0x102ced624*/
        v17 = a; /*0x102ced629*/
        if ( is_negative ) /*0x102ced62f*/
        {
          if ( BN_add_word(a, w: 1u) == 0 ) /*0x102ced63d*/
            goto LABEL_56; /*0x102ced63d*/
          v17 = a; /*0x102ced63f*/
        }
      }
      v32 = BN_num_bits(a: v17); /*0x102ced648*/
      v33 = v32 + 8; /*0x102ced64b*/
      if ( (v32 & 7) != 0 ) /*0x102ced652*/
        v33 = v32; /*0x102ced652*/
      if ( *((_DWORD *)v14 + 2) != 1 ) /*0x102ced65b*/
        v33 = v32; /*0x102ced65b*/
      a5 = (unsigned __int64)v14[3]; /*0x102ced65f*/
      if ( a5 != 0 ) /*0x102ced666*/
      {
        if ( v33 > 8 * a5 ) /*0x102ced673*/
        {
          ERR_new(); /*0x102ced679*/
          ERR_set_debug(__s: "crypto/params_from_text.c", a2: 102, a3: "prepare_from_text"); /*0x102ced691*/
          v19 = 116; /*0x102ced69b*/
          goto LABEL_55; /*0x102ced69b*/
        }
      }
      else
      {
        a5 = (v33 + 7) >> 3; /*0x102ced6cb*/
      }
    }
    else if ( v15 == 4 ) /*0x102ced40b*/
    {
      if ( !v43 ) /*0x102ced45c*/
      {
        ERR_new(); /*0x102ced54f*/
        ERR_set_debug(__s: "crypto/params_from_text.c", a2: 112, a3: "prepare_from_text"); /*0x102ced567*/
        v19 = 524550; /*0x102ced571*/
        goto LABEL_55; /*0x102ced576*/
      }
      a5 = strlen(__s: a4) + 1; /*0x102ced46d*/
    }
    else
    {
      if ( v15 == 5 ) /*0x102ced410*/
      {
        if ( v43 ) /*0x102ced41a*/
          goto LABEL_26; /*0x102ced41a*/
        v16 = strlen(__s: a4); /*0x102ced423*/
        if ( (v16 & 1) == 0 ) /*0x102ced42f*/
        {
          a5 = v16 >> 1; /*0x102ced435*/
          goto LABEL_26; /*0x102ced438*/
        }
        ERR_new(); /*0x102ced5cf*/
        ERR_set_debug(__s: "crypto/params_from_text.c", a2: 122, a3: "prepare_from_text"); /*0x102ced5e7*/
        v19 = 103; /*0x102ced5f1*/
LABEL_55:
        ERR_set_error(a1: 15, a2: v19, a3: 0); /*0x102ced6a0*/
        goto LABEL_56; /*0x102ced6a4*/
      }
      a5 = 0; /*0x102ced4d9*/
    }
LABEL_26:
    v20 = (char *)CRYPTO_zalloc(__size: (a5 == 0) + a5, __s: "crypto/params_from_text.c", line: 325); /*0x102ced4dc*/
    if ( v20 != nullptr ) /*0x102ced4fb*/
    {
      if ( a5 == 0 ) /*0x102ced504*/
      {
        a5 = 0; /*0x102ced547*/
        goto LABEL_73; /*0x102ced54a*/
      }
      v21 = *((_DWORD *)v14 + 2); /*0x102ced506*/
      if ( (unsigned int)(v21 - 1) >= 2 ) /*0x102ced510*/
      {
        if ( v21 == 4 ) /*0x102ced515*/
        {
          v29 = a4; /*0x102ced5fe*/
          v30 = v20; /*0x102ced604*/
          strncpy(__dst: v20, __src: v29, __n: a5); /*0x102ced607*/
          v20 = v30; /*0x102ced60c*/
          --a5; /*0x102ced60f*/
          goto LABEL_73; /*0x102ced612*/
        }
        if ( v21 != 5 ) /*0x102ced51e*/
        {
LABEL_73:
          *(_OWORD *)a1 = *(_OWORD *)v14; /*0x102ced7a3*/
          *(_QWORD *)(a1 + 16) = v20; /*0x102ced7aa*/
          *(_QWORD *)(a1 + 24) = a5; /*0x102ced7ae*/
          *(_QWORD *)(a1 + 32) = -1; /*0x102ced7b2*/
          BN_free(a); /*0x102ced7be*/
          return 1; /*0x102ced7c3*/
        }
        if ( v43 ) /*0x102ced528*/
        {
          v22 = a4; /*0x102ced531*/
          v23 = v20; /*0x102ced537*/
          memcpy(__dst: v20, __src: v22, __n: a5); /*0x102ced53a*/
          v20 = v23; /*0x102ced53f*/
          goto LABEL_73; /*0x102ced542*/
        }
        v41 = 0; /*0x102ced6d3*/
        v34 = (__int64)a4; /*0x102ced6e5*/
        v35 = v20; /*0x102ced6ee*/
        v36 = OPENSSL_hexstr2buf_ex(a1: v20, a2: a5, a3: &v41, a4: v34, a5: 58); /*0x102ced6f6*/
        v20 = v35; /*0x102ced6f8*/
        if ( v36 != 0 ) /*0x102ced6fd*/
          goto LABEL_73; /*0x102ced6fd*/
        BN_free(a); /*0x102ced70a*/
        CRYPTO_free(a1: v35); /*0x102ced71e*/
        return 0; /*0x102ced723*/
      }
      v24 = a; /*0x102ced57b*/
      v25 = v20; /*0x102ced582*/
      BN_bn2nativepad(a1: a, a2: (unsigned __int8 *)v20, a3: a5); /*0x102ced58b*/
      if ( *((_DWORD *)v14 + 2) != 1 || !BN_is_negative(a1: (__int64)v24) ) /*0x102ced59a*/
      {
        v20 = v25; /*0x102ced5c7*/
        goto LABEL_73; /*0x102ced5ca*/
      }
      v26 = a5; /*0x102ced5a3*/
      v20 = v25; /*0x102ced5a6*/
      v27 = v25; /*0x102ced5a9*/
      if ( a5 >= 4 ) /*0x102ced5b0*/
      {
        if ( a5 < 0x20 ) /*0x102ced5ba*/
        {
          v28 = 0; /*0x102ced5c0*/
          goto LABEL_66; /*0x102ced5c2*/
        }
        v28 = a5 & 0xFFFFFFFFFFFFFFE0LL; /*0x102ced728*/
        v37 = 0; /*0x102ced72c*/
        do /*0x102ced757*/
        {
          v38 = _mm_xor_si128(_mm_loadu_si128((const __m128i *)&v25[v37 + 16]), (__m128i)-1LL); /*0x102ced741*/
          *(__m128i *)&v25[v37] = _mm_xor_si128(_mm_loadu_si128((const __m128i *)&v25[v37]), (__m128i)-1LL); /*0x102ced745*/
          *(__m128i *)&v25[v37 + 16] = v38; /*0x102ced74a*/
          v37 += 32; /*0x102ced750*/
        }
        while ( v28 != v37 ); /*0x102ced757*/
        if ( a5 == v28 ) /*0x102ced75c*/
          goto LABEL_73; /*0x102ced75c*/
        if ( (a5 & 0x1C) != 0 ) /*0x102ced762*/
        {
LABEL_66:
          v39 = a5 & 0xFFFFFFFFFFFFFFFCLL; /*0x102ced764*/
          v26 = a5 & 3; /*0x102ced76e*/
          v27 = &v25[a5 & 0xFFFFFFFFFFFFFFFCLL]; /*0x102ced774*/
          do /*0x102ced781*/
          {
            *(_DWORD *)&v25[v28] = ~*(_DWORD *)&v25[v28]; /*0x102ced777*/
            v28 += 4LL; /*0x102ced77a*/
          }
          while ( v39 != v28 ); /*0x102ced781*/
          if ( a5 == v39 ) /*0x102ced786*/
            goto LABEL_73; /*0x102ced786*/
          goto LABEL_71; /*0x102ced786*/
        }
        v27 = &v25[v28]; /*0x102ced78d*/
        v26 = a5 & 0x1F; /*0x102ced793*/
      }
LABEL_71:
      v40 = 0; /*0x102ced796*/
      do /*0x102ced7a1*/
      {
        v27[v40] = ~v27[v40]; /*0x102ced798*/
        ++v40; /*0x102ced79b*/
      }
      while ( v26 != v40 ); /*0x102ced7a1*/
      goto LABEL_73; /*0x102ced7a1*/
    }
LABEL_56:
    BN_free(a); /*0x102ced6a9*/
    return 0; /*0x102ced6b2*/
  }
  return result; /*0x102ced6b4*/
}

// Address: 0x102ced7d0 | Name: _ossl_param_find_pidx
__int64 __fastcall ossl_param_find_pidx(__int64 a1)
{
  int v1; // ecx
  __int64 result; // rax
  int v3; // eax
  int v4; // eax
  int v5; // eax
  unsigned int v6; // eax
  int v7; // eax
  int v8; // eax
  int v9; // eax
  int v10; // eax
  int v11; // eax
  int v12; // eax
  int v13; // eax
  int v14; // eax
  int v15; // eax
  int v16; // eax
  unsigned int v17; // eax
  int v18; // eax
  int v19; // eax
  int v20; // eax
  int v21; // eax
  int v22; // eax
  unsigned int v23; // eax
  int v24; // eax
  int v25; // eax
  int v26; // eax
  int v27; // eax
  int v28; // eax
  int v29; // eax
  int v30; // eax
  int v31; // eax
  int v32; // eax
  int v33; // eax
  int v34; // eax
  int v35; // eax
  int v36; // eax
  int v37; // eax
  int v38; // eax
  int v39; // eax
  int v40; // eax
  int v41; // eax
  int v42; // eax
  int v43; // eax
  int v44; // eax
  int v45; // eax
  int v46; // eax
  int v47; // eax
  int v48; // eax
  int v49; // eax
  int v50; // eax
  int v51; // eax
  int v52; // eax
  int v53; // eax
  int v54; // eax
  int v55; // eax
  int v56; // eax
  int v57; // eax
  int v58; // eax
  int v59; // eax
  int v60; // eax
  int v61; // eax
  int v62; // eax
  int v63; // eax
  unsigned int v64; // eax
  int v65; // eax
  int v66; // eax
  int v67; // eax
  int v68; // eax
  int v69; // eax
  int v70; // eax
  int v71; // eax
  unsigned int v72; // eax
  int v73; // eax
  int v74; // eax
  int v75; // eax
  int v76; // eax
  int v77; // eax
  int v78; // eax
  int v79; // eax
  int v80; // eax
  int v81; // eax
  int v82; // eax
  int v83; // eax
  int v84; // eax
  int v85; // eax
  int v86; // eax
  int v87; // eax
  int v88; // eax
  int v89; // eax
  int v90; // eax
  int v91; // eax
  int v92; // eax
  int v93; // eax
  int v94; // eax
  int v95; // eax
  int v96; // eax
  int v97; // eax
  int v98; // eax
  unsigned int v99; // eax
  int v100; // eax
  int v101; // eax
  int v102; // eax
  int v103; // eax
  int v104; // eax
  int v105; // eax
  int v106; // eax
  int v107; // eax
  int v108; // eax
  int v109; // eax
  int v110; // eax
  int v111; // eax
  int v112; // eax
  int v113; // eax
  int v114; // eax
  int v115; // eax
  int v116; // eax
  int v117; // eax
  int v118; // eax
  int v119; // eax
  int v120; // eax
  int v121; // eax
  int v122; // eax
  int v123; // eax
  int v124; // eax
  int v125; // eax
  int v126; // eax
  int v127; // eax
  int v128; // eax
  int v129; // eax
  int v130; // eax
  int v131; // eax
  int v132; // eax
  int v133; // eax
  int v134; // eax
  int v135; // eax
  int v136; // eax
  int v137; // eax
  int v138; // eax
  int v139; // eax
  int v140; // eax
  int v141; // eax
  int v142; // eax
  int v143; // eax
  int v144; // eax
  int v145; // eax
  int v146; // eax

  switch ( *(_BYTE *)a1 ) /*0x102ced7f4*/
  {
    case 'a': /*0x102ced7f4*/
      v1 = *(unsigned __int8 *)(a1 + 1); /*0x102ced7f6*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102ced814*/
      {
        case 'c': /*0x102ced814*/
          if ( strcmp(__s1: "vp-info", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102ced828*/
            return 0xFFFFFFFFLL; /*0x102ced828*/
          return 146; /*0x102ced834*/
        case 'd': /*0x102ced814*/
          if ( *(_BYTE *)(a1 + 2) == 0 ) /*0x102cee29f*/
            return 112; /*0x102cef375*/
          if ( *(_BYTE *)(a1 + 2) == 100 && strcmp(__s1: "itional-random", __s2: (const char *)(a1 + 3)) == 0 ) /*0x102cee2c0*/
            return 327; /*0x102cee2cc*/
          return 0xFFFFFFFFLL; /*0x102cee2c0*/
        case 'e': /*0x102ced814*/
          v32 = *(unsigned __int8 *)(a1 + 2) - 97; /*0x102cee1c6*/
          if ( *(_BYTE *)(a1 + 2) == 97 ) /*0x102cee1c9*/
          {
            v32 = *(unsigned __int8 *)(a1 + 3) - 100; /*0x102cee1cf*/
            if ( *(_BYTE *)(a1 + 3) == 100 ) /*0x102cee1d2*/
              v32 = *(unsigned __int8 *)(a1 + 4); /*0x102cee1d4*/
          }
          if ( v32 != 0 ) /*0x102cee1dc*/
            return 0xFFFFFFFFLL; /*0x102cee1dc*/
          return 34; /*0x102cee1e8*/
        case 'f': /*0x102ced814*/
        case 'g': /*0x102ced814*/
        case 'h': /*0x102ced814*/
        case 'i': /*0x102ced814*/
        case 'j': /*0x102ced814*/
        case 'k': /*0x102ced814*/
          return 0xFFFFFFFFLL;
        case 'l': /*0x102ced814*/
          v33 = *(unsigned __int8 *)(a1 + 2); /*0x102cee1e9*/
          if ( v33 == 105 ) /*0x102cee1f0*/
          {
            v84 = *(unsigned __int8 *)(a1 + 3) - 97; /*0x102cef34c*/
            if ( *(_BYTE *)(a1 + 3) == 97 ) /*0x102cef34f*/
            {
              v84 = *(unsigned __int8 *)(a1 + 4) - 115; /*0x102cef355*/
              if ( *(_BYTE *)(a1 + 4) == 115 ) /*0x102cef358*/
                v84 = *(unsigned __int8 *)(a1 + 5); /*0x102cef35a*/
            }
            if ( v84 == 0 ) /*0x102cef362*/
              return 341; /*0x102cef36e*/
            return 0xFFFFFFFFLL; /*0x102cef362*/
          }
          if ( v33 != 103 ) /*0x102cee1f9*/
            return 0xFFFFFFFFLL; /*0x102cee1f9*/
          v34 = *(unsigned __int8 *)(a1 + 3); /*0x102cee1ff*/
          if ( v34 == 111 ) /*0x102cee206*/
          {
            if ( *(_BYTE *)(a1 + 4) == 114 /*0x102cefcf1*/
              && *(_BYTE *)(a1 + 5) == 105
              && *(_BYTE *)(a1 + 6) == 116
              && *(_BYTE *)(a1 + 7) == 104
              && *(_BYTE *)(a1 + 8) == 109
              && *(_BYTE *)(a1 + 9) == 45
              && *(_BYTE *)(a1 + 10) == 105
              && *(_BYTE *)(a1 + 11) == 100 )
            {
              result = *(unsigned __int8 *)(a1 + 12); /*0x102cefcf7*/
              if ( *(_BYTE *)(a1 + 12) == 0 ) /*0x102cefcfd*/
                return result; /*0x102cefcfd*/
              if ( (_DWORD)result == 45 && strcmp(__s1: "params", __s2: (const char *)(a1 + 13)) == 0 ) /*0x102cefd1e*/
                return 1; /*0x102cefd2a*/
            }
            return 0xFFFFFFFFLL; /*0x102cefd1e*/
          }
          if ( v34 != 105 ) /*0x102cee20f*/
          {
            if ( v34 == 95 && strcmp(__s1: "id_param", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102cee230*/
              return 44; /*0x102cee23c*/
            return 0xFFFFFFFFLL; /*0x102cee230*/
          }
          if ( strcmp(__s1: "d-absent", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cefc9a*/
            return 0xFFFFFFFFLL; /*0x102cefc9a*/
          result = 78; /*0x102cefca0*/
          break; /*0x102cefca6*/
        default:
          result = 183; /*0x102cee028*/
          goto LABEL_455; /*0x102cee02d*/
      }
      return result; /*0x102cefca6*/
    case 'b': /*0x102ced7f4*/
      v1 = *(unsigned __int8 *)(a1 + 1); /*0x102cedc5f*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102cedc7d*/
      {
        case 'a': /*0x102cedc7d*/
          if ( strcmp(__s1: "sis-type", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cedc91*/
            return 0xFFFFFFFFLL; /*0x102cedc91*/
          return 190; /*0x102cedc9d*/
        case 'b': /*0x102cedc7d*/
        case 'c': /*0x102cedc7d*/
        case 'd': /*0x102cedc7d*/
        case 'e': /*0x102cedc7d*/
        case 'f': /*0x102cedc7d*/
        case 'g': /*0x102cedc7d*/
        case 'h': /*0x102cedc7d*/
        case 'j': /*0x102cedc7d*/
        case 'k': /*0x102cedc7d*/
        case 'm': /*0x102cedc7d*/
        case 'n': /*0x102cedc7d*/
        case 'o': /*0x102cedc7d*/
        case 'p': /*0x102cedc7d*/
        case 'q': /*0x102cedc7d*/
        case 'r': /*0x102cedc7d*/
        case 's': /*0x102cedc7d*/
        case 't': /*0x102cedc7d*/
          return 0xFFFFFFFFLL;
        case 'i': /*0x102cedc7d*/
          v36 = *(unsigned __int8 *)(a1 + 2) - 116; /*0x102cee2f0*/
          if ( *(_BYTE *)(a1 + 2) == 116 ) /*0x102cee2f3*/
          {
            v36 = *(unsigned __int8 *)(a1 + 3) - 115; /*0x102cee2f9*/
            if ( *(_BYTE *)(a1 + 3) == 115 ) /*0x102cee2fc*/
              v36 = *(unsigned __int8 *)(a1 + 4); /*0x102cee2fe*/
          }
          if ( v36 != 0 ) /*0x102cee306*/
            return 0xFFFFFFFFLL; /*0x102cee306*/
          return 176; /*0x102cee312*/
        case 'l': /*0x102cedc7d*/
          if ( *(_BYTE *)(a1 + 2) != 111 || *(_BYTE *)(a1 + 3) != 99 || *(_BYTE *)(a1 + 4) != 107 ) /*0x102cee255*/
            return 0xFFFFFFFFLL; /*0x102cee255*/
          v35 = *(unsigned __int8 *)(a1 + 5); /*0x102cee25b*/
          if ( v35 == 115 ) /*0x102cee262*/
          {
            if ( strcmp(__s1: "ize", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf03ca*/
              return 0xFFFFFFFFLL; /*0x102cf03ca*/
            result = 45; /*0x102cf03d0*/
          }
          else
          {
            if ( v35 != 95 ) /*0x102cee26b*/
            {
              if ( v35 == 45 && strcmp(__s1: "size", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cee28c*/
                return 164; /*0x102cee298*/
              return 0xFFFFFFFFLL; /*0x102cee28c*/
            }
            if ( strcmp(__s1: "padding", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf03ab*/
              return 0xFFFFFFFFLL; /*0x102cf03ab*/
            result = 154; /*0x102cf03b1*/
          }
          break; /*0x102cf03b7*/
        case 'u': /*0x102cedc7d*/
          if ( strcmp(__s1: "ildinfo", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee2df*/
            return 0xFFFFFFFFLL; /*0x102cee2df*/
          return 284; /*0x102cee2eb*/
        default:
          result = 184; /*0x102cee032*/
          goto LABEL_455; /*0x102cee037*/
      }
      return result; /*0x102cf03b7*/
    case 'c': /*0x102ced7f4*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102ced9b3*/
      {
        case 'e': /*0x102ced9b3*/
          if ( strcmp(__s1: "kalg", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102ced9c7*/
            return 0xFFFFFFFFLL; /*0x102ced9c7*/
          return 116; /*0x102ced9d3*/
        case 'f': /*0x102ced9b3*/
        case 'g': /*0x102ced9b3*/
        case 'h': /*0x102ced9b3*/
        case 'j': /*0x102ced9b3*/
        case 'k': /*0x102ced9b3*/
        case 'l': /*0x102ced9b3*/
        case 'm': /*0x102ced9b3*/
        case 'n': /*0x102ced9b3*/
        case 'p': /*0x102ced9b3*/
        case 'q': /*0x102ced9b3*/
        case 'r': /*0x102ced9b3*/
        case 's': /*0x102ced9b3*/
          return 0xFFFFFFFFLL;
        case 'i': /*0x102ced9b3*/
          if ( strcmp(__s1: "pher", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee621*/
            return 0xFFFFFFFFLL; /*0x102cee621*/
          return 2; /*0x102cee62d*/
        case 'o': /*0x102ced9b3*/
          v42 = *(unsigned __int8 *)(a1 + 2); /*0x102cee5bb*/
          if ( v42 != 110 ) /*0x102cee5c2*/
          {
            if ( v42 == 102 && strcmp(__s1: "actor", __s2: (const char *)(a1 + 3)) == 0 ) /*0x102cee5e3*/
              return 191; /*0x102cee5ef*/
            return 0xFFFFFFFFLL; /*0x102cee5e3*/
          }
          v85 = *(unsigned __int8 *)(a1 + 3); /*0x102cef3b4*/
          if ( v85 != 116 ) /*0x102cef3bb*/
          {
            if ( v85 == 115 && strcmp(__s1: "tant", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102cef3dc*/
              return 117; /*0x102cef3e8*/
            return 0xFFFFFFFFLL; /*0x102cef3dc*/
          }
          if ( strcmp(__s1: "ext-string", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cefc7b*/
            return 0xFFFFFFFFLL; /*0x102cefc7b*/
          return 328; /*0x102cefc87*/
        case 't': /*0x102ced9b3*/
          if ( *(_BYTE *)(a1 + 2) != 115 ) /*0x102cee6df*/
            return 0xFFFFFFFFLL; /*0x102cee6df*/
          if ( *(_BYTE *)(a1 + 3) == 0 ) /*0x102cee6eb*/
            return 46; /*0x102cefa8c*/
          if ( *(_BYTE *)(a1 + 3) == 95 && strcmp(__s1: "mode", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102cee70c*/
            return 47; /*0x102cee718*/
          return 0xFFFFFFFFLL; /*0x102cee70c*/
        case 'u': /*0x102ced9b3*/
          if ( *(_BYTE *)(a1 + 2) != 115 /*0x102cee55a*/
            || *(_BYTE *)(a1 + 3) != 116
            || *(_BYTE *)(a1 + 4) != 111
            || *(_BYTE *)(a1 + 5) != 109 )
          {
            return 0xFFFFFFFFLL; /*0x102cee55a*/
          }
          if ( *(_BYTE *)(a1 + 6) == 0 ) /*0x102cee566*/
            return 165; /*0x102cf0501*/
          if ( *(_BYTE *)(a1 + 6) == 45 ) /*0x102cee56f*/
          {
            v41 = *(unsigned __int8 *)(a1 + 7) - 105; /*0x102cee579*/
            if ( *(_BYTE *)(a1 + 7) == 105 ) /*0x102cee57c*/
            {
              v41 = *(unsigned __int8 *)(a1 + 8) - 118; /*0x102cee582*/
              if ( *(_BYTE *)(a1 + 8) == 118 ) /*0x102cee585*/
                v41 = *(unsigned __int8 *)(a1 + 9); /*0x102cee587*/
            }
            if ( v41 == 0 ) /*0x102cee58f*/
              return 48; /*0x102cee59b*/
          }
          break; /*0x102cee59b*/
        default:
          if ( *(_BYTE *)(a1 + 1) != 45 || strcmp(__s1: "rounds", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee149*/
            return 0xFFFFFFFFLL; /*0x102cee149*/
          return 166; /*0x102cee155*/
      }
      return 0xFFFFFFFFLL; /*0x102cee58f*/
    case 'd': /*0x102ced7f4*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102cedbff*/
      {
        case 'a': /*0x102cedbff*/
          if ( *(_BYTE *)(a1 + 2) != 116 || *(_BYTE *)(a1 + 3) != 97 ) /*0x102cedc0f*/
            return 0xFFFFFFFFLL; /*0x102cedc0f*/
          if ( *(_BYTE *)(a1 + 4) == 0 ) /*0x102cedc1b*/
            return 118; /*0x102ceff5d*/
          if ( *(_BYTE *)(a1 + 4) != 45 ) /*0x102cedc24*/
            return 0xFFFFFFFFLL; /*0x102cedc24*/
          v16 = *(unsigned __int8 *)(a1 + 5); /*0x102cedc2a*/
          if ( v16 != 116 ) /*0x102cedc31*/
          {
            if ( v16 == 115 && strcmp(__s1: "tructure", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cedc52*/
              return 171; /*0x102cedc5e*/
            return 0xFFFFFFFFLL; /*0x102cedc52*/
          }
          if ( strcmp(__s1: "ype", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf04cf*/
            return 0xFFFFFFFFLL; /*0x102cf04cf*/
          return 172; /*0x102cf04db*/
        case 'b': /*0x102cedbff*/
        case 'c': /*0x102cedbff*/
        case 'd': /*0x102cedbff*/
        case 'f': /*0x102cedbff*/
        case 'g': /*0x102cedbff*/
        case 'j': /*0x102cedbff*/
        case 'k': /*0x102cedbff*/
        case 'l': /*0x102cedbff*/
        case 'm': /*0x102cedbff*/
        case 'n': /*0x102cedbff*/
        case 'o': /*0x102cedbff*/
        case 'p': /*0x102cedbff*/
        case 'q': /*0x102cedbff*/
          return 0xFFFFFFFFLL;
        case 'e': /*0x102cedbff*/
          switch ( *(_BYTE *)(a1 + 2) ) /*0x102ceed86*/
          {
            case 'c': /*0x102ceed86*/
              v66 = *(unsigned __int8 *)(a1 + 3); /*0x102ceed88*/
              if ( v66 != 114 ) /*0x102ceed8f*/
              {
                if ( v66 == 111 && strcmp(__s1: "ded-from-explicit", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102ceedb0*/
                  return 192; /*0x102ceedbc*/
                return 0xFFFFFFFFLL; /*0x102ceedb0*/
              }
              if ( strcmp(__s1: "ypt-only", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cf001c*/
                return 0xFFFFFFFFLL; /*0x102cf001c*/
              result = 49; /*0x102cf0022*/
              break; /*0x102cf0028*/
            case 'f': /*0x102ceed86*/
              if ( strcmp(__s1: "ault-digest", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cefac4*/
                return 0xFFFFFFFFLL; /*0x102cefac4*/
              return 177; /*0x102cefad0*/
            case 's': /*0x102ceed86*/
              v104 = *(unsigned __int8 *)(a1 + 3) - 99; /*0x102cefa98*/
              if ( *(_BYTE *)(a1 + 3) == 99 ) /*0x102cefa9b*/
                v104 = *(unsigned __int8 *)(a1 + 4); /*0x102cefa9d*/
              if ( v104 != 0 ) /*0x102cefaa5*/
                return 0xFFFFFFFFLL; /*0x102cefaa5*/
              return 173; /*0x102cefab1*/
            case 't': /*0x102ceed86*/
              if ( strcmp(__s1: "erministic", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cefae3*/
                return 0xFFFFFFFFLL; /*0x102cefae3*/
              return 329; /*0x102cefaef*/
            default:
              return 0xFFFFFFFFLL;
          }
          return result; /*0x102cf0028*/
        case 'h': /*0x102cedbff*/
          if ( strcmp(__s1: "kem-ikm", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102ceedee*/
            return 0xFFFFFFFFLL; /*0x102ceedee*/
          return 178; /*0x102ceedfa*/
        case 'i': /*0x102cedbff*/
          v65 = *(unsigned __int8 *)(a1 + 2); /*0x102ceed00*/
          if ( v65 == 115 ) /*0x102ceed07*/
          {
            if ( strcmp(__s1: "tid", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef58d*/
              return 0xFFFFFFFFLL; /*0x102cef58d*/
            return 182; /*0x102cef593*/
          }
          else
          {
            if ( v65 != 103 || *(_BYTE *)(a1 + 3) != 101 || *(_BYTE *)(a1 + 4) != 115 || *(_BYTE *)(a1 + 5) != 116 ) /*0x102ceed22*/
              return 0xFFFFFFFFLL; /*0x102ceed22*/
            if ( *(_BYTE *)(a1 + 6) != 0 ) /*0x102ceed2a*/
            {
              if ( *(_BYTE *)(a1 + 6) != 45 ) /*0x102ceed33*/
                return 0xFFFFFFFFLL; /*0x102ceed33*/
              switch ( *(_BYTE *)(a1 + 7) ) /*0x102ceed4f*/
              {
                case 'c': /*0x102ceed4f*/
                  if ( strcmp(__s1: "heck", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102ceed63*/
                    return 0xFFFFFFFFLL; /*0x102ceed63*/
                  result = 214; /*0x102ceed65*/
                  break; /*0x102ceed6b*/
                case 'n': /*0x102ceed4f*/
                  if ( strcmp(__s1: "oinit", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf0c38*/
                    return 0xFFFFFFFFLL; /*0x102cf0c38*/
                  result = 167; /*0x102cf0c3e*/
                  break; /*0x102cf0c44*/
                case 'o': /*0x102ceed4f*/
                  if ( strcmp(__s1: "neshot", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf0c19*/
                    return 0xFFFFFFFFLL; /*0x102cf0c19*/
                  result = 168; /*0x102cf0c1f*/
                  break; /*0x102cf0c25*/
                case 'p': /*0x102ceed4f*/
                  if ( strcmp(__s1: "rops", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf0c57*/
                    return 0xFFFFFFFFLL; /*0x102cf0c57*/
                  result = 9; /*0x102cf0c5d*/
                  break; /*0x102cf0c63*/
                case 's': /*0x102ceed4f*/
                  if ( strcmp(__s1: "ize", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf0c76*/
                    return 0xFFFFFFFFLL; /*0x102cf0c76*/
                  result = 181; /*0x102cf0c7c*/
                  break; /*0x102cf0c82*/
                default:
                  return 0xFFFFFFFFLL;
              }
            }
            else
            {
              return 3; /*0x102cf06ed*/
            }
          }
          return result; /*0x102cf0c82*/
        case 'r': /*0x102cedbff*/
          if ( strcmp(__s1: "bg-no-trunc-md", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102ceedcf*/
            return 0xFFFFFFFFLL; /*0x102ceedcf*/
          return 288; /*0x102ceeddb*/
        case 's': /*0x102cedbff*/
          if ( strcmp(__s1: "a-sign-disabled", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102ceee0d*/
            return 0xFFFFFFFFLL; /*0x102ceee0d*/
          return 289; /*0x102ceee19*/
        default:
          if ( *(_BYTE *)(a1 + 1) == 0 ) /*0x102cedffa*/
            return 245; /*0x102cef11c*/
          if ( *(_BYTE *)(a1 + 1) == 45 && strcmp(__s1: "rounds", __s2: (const char *)(a1 + 2)) == 0 ) /*0x102cee01b*/
            return 169; /*0x102cee027*/
          break; /*0x102cee027*/
      }
      return 0xFFFFFFFFLL; /*0x102cee01b*/
    case 'e': /*0x102ced7f4*/
      v1 = *(unsigned __int8 *)(a1 + 1); /*0x102ced9d4*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102ced9f2*/
      {
        case 'a': /*0x102ced9f2*/
          if ( strcmp(__s1: "rly_clean", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102ceda06*/
            return 0xFFFFFFFFLL; /*0x102ceda06*/
          return 119; /*0x102ceda12*/
        case 'b': /*0x102ced9f2*/
        case 'd': /*0x102ced9f2*/
        case 'e': /*0x102ced9f2*/
        case 'f': /*0x102ced9f2*/
        case 'g': /*0x102ced9f2*/
        case 'h': /*0x102ced9f2*/
        case 'i': /*0x102ced9f2*/
        case 'j': /*0x102ced9f2*/
        case 'k': /*0x102ced9f2*/
        case 'l': /*0x102ced9f2*/
        case 'o': /*0x102ced9f2*/
        case 'p': /*0x102ced9f2*/
        case 'q': /*0x102ced9f2*/
        case 'r': /*0x102ced9f2*/
        case 's': /*0x102ced9f2*/
        case 't': /*0x102ced9f2*/
        case 'u': /*0x102ced9f2*/
        case 'v': /*0x102ced9f2*/
        case 'w': /*0x102ced9f2*/
          return 0xFFFFFFFFLL;
        case 'c': /*0x102ced9f2*/
          if ( *(_BYTE *)(a1 + 2) != 100 /*0x102cee6a0*/
            || *(_BYTE *)(a1 + 3) != 104
            || *(_BYTE *)(a1 + 4) != 45
            || *(_BYTE *)(a1 + 5) != 99
            || *(_BYTE *)(a1 + 6) != 111
            || *(_BYTE *)(a1 + 7) != 102
            || *(_BYTE *)(a1 + 8) != 97
            || *(_BYTE *)(a1 + 9) != 99
            || *(_BYTE *)(a1 + 10) != 116
            || *(_BYTE *)(a1 + 11) != 111
            || *(_BYTE *)(a1 + 12) != 114
            || *(_BYTE *)(a1 + 13) != 45 )
          {
            return 0xFFFFFFFFLL; /*0x102cee6a0*/
          }
          v43 = *(unsigned __int8 *)(a1 + 14); /*0x102cee6a6*/
          if ( v43 != 109 ) /*0x102cee6ad*/
          {
            if ( v43 == 99 && strcmp(__s1: "heck", __s2: (const char *)(a1 + 15)) == 0 ) /*0x102cee6ce*/
              return 290; /*0x102cee6da*/
            return 0xFFFFFFFFLL; /*0x102cee6ce*/
          }
          if ( strcmp(__s1: "ode", __s2: (const char *)(a1 + 15)) != 0 ) /*0x102cf0f5e*/
            return 0xFFFFFFFFLL; /*0x102cf0f5e*/
          return 103; /*0x102cf0f6a*/
        case 'm': /*0x102ced9f2*/
          if ( strcmp(__s1: "s_check", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee602*/
            return 0xFFFFFFFFLL; /*0x102cee602*/
          return 120; /*0x102cee60e*/
        case 'n': /*0x102ced9f2*/
          v44 = *(unsigned __int8 *)(a1 + 2); /*0x102cee719*/
          if ( v44 == 116 ) /*0x102cee720*/
          {
            if ( *(_BYTE *)(a1 + 3) == 114 /*0x102cef645*/
              && *(_BYTE *)(a1 + 4) == 111
              && *(_BYTE *)(a1 + 5) == 112
              && *(_BYTE *)(a1 + 6) == 121 )
            {
              if ( *(_BYTE *)(a1 + 7) == 0 ) /*0x102cef651*/
                return 121; /*0x102cf09d9*/
              if ( *(_BYTE *)(a1 + 7) == 95 && strcmp(__s1: "required", __s2: (const char *)(a1 + 8)) == 0 ) /*0x102cef672*/
                return 85; /*0x102cef67e*/
            }
            return 0xFFFFFFFFLL; /*0x102cef672*/
          }
          if ( v44 == 103 ) /*0x102cee729*/
          {
            if ( strcmp(__s1: "ine", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef616*/
              return 0xFFFFFFFFLL; /*0x102cef616*/
            return 4; /*0x102cef622*/
          }
          if ( v44 != 99 ) /*0x102cee732*/
            return 0xFFFFFFFFLL; /*0x102cee732*/
          v45 = *(unsigned __int8 *)(a1 + 3); /*0x102cee738*/
          if ( v45 != 114 ) /*0x102cee73f*/
          {
            if ( v45 == 111 && *(_BYTE *)(a1 + 4) == 100 ) /*0x102cee752*/
            {
              v46 = *(unsigned __int8 *)(a1 + 5); /*0x102cee758*/
              if ( v46 == 105 ) /*0x102cee75f*/
              {
                v124 = *(unsigned __int8 *)(a1 + 6) - 110; /*0x102cf066d*/
                if ( *(_BYTE *)(a1 + 6) == 110 ) /*0x102cf0670*/
                {
                  v124 = *(unsigned __int8 *)(a1 + 7) - 103; /*0x102cf0676*/
                  if ( *(_BYTE *)(a1 + 7) == 103 ) /*0x102cf0679*/
                    v124 = *(unsigned __int8 *)(a1 + 8); /*0x102cf067b*/
                }
                if ( v124 == 0 ) /*0x102cf0683*/
                  return 193; /*0x102cf068f*/
              }
              else if ( v46 == 101 && strcmp(__s1: "d-pub-key", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cee780*/
              {
                return 202; /*0x102cee78c*/
              }
            }
            return 0xFFFFFFFFLL; /*0x102cee780*/
          }
          if ( *(_BYTE *)(a1 + 4) != 121 /*0x102cefdc4*/
            || *(_BYTE *)(a1 + 5) != 112
            || *(_BYTE *)(a1 + 6) != 116
            || *(_BYTE *)(a1 + 7) != 45 )
          {
            return 0xFFFFFFFFLL; /*0x102cefdc4*/
          }
          v112 = *(unsigned __int8 *)(a1 + 8); /*0x102cefdca*/
          if ( v112 != 108 ) /*0x102cefdd1*/
          {
            if ( v112 == 99 && strcmp(__s1: "heck", __s2: (const char *)(a1 + 9)) == 0 ) /*0x102cefdf2*/
              return 50; /*0x102cefdfe*/
            return 0xFFFFFFFFLL; /*0x102cefdf2*/
          }
          if ( strcmp(__s1: "evel", __s2: (const char *)(a1 + 9)) != 0 ) /*0x102cf0c95*/
            return 0xFFFFFFFFLL; /*0x102cf0c95*/
          result = 101; /*0x102cf0c9b*/
          break; /*0x102cf0ca1*/
        case 'x': /*0x102ced9f2*/
          if ( strcmp(__s1: "pect", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee5ae*/
            return 0xFFFFFFFFLL; /*0x102cee5ae*/
          return 342; /*0x102cee5ba*/
        default:
          result = 247; /*0x102cee156*/
          goto LABEL_455; /*0x102cee15b*/
      }
      return result; /*0x102cf0ca1*/
    case 'f': /*0x102ced7f4*/
      if ( *(_BYTE *)(a1 + 1) != 105 ) /*0x102cedb56*/
        return 0xFFFFFFFFLL; /*0x102cedb56*/
      v13 = *(unsigned __int8 *)(a1 + 2); /*0x102cedb5c*/
      if ( v13 == 112 ) /*0x102cedb63*/
      {
        if ( strcmp(__s1: "s-indicator", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102ceec17*/
          return 0xFFFFFFFFLL; /*0x102ceec17*/
        return 5; /*0x102ceec1d*/
      }
      else
      {
        if ( v13 != 110 ) /*0x102cedb6c*/
        {
          if ( v13 == 101 && strcmp(__s1: "ld-type", __s2: (const char *)(a1 + 3)) == 0 ) /*0x102cedb8d*/
            return 194; /*0x102cedb99*/
          return 0xFFFFFFFFLL; /*0x102cedb8d*/
        }
        if ( strcmp(__s1: "gerprint", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102ceebf8*/
          return 0xFFFFFFFFLL; /*0x102ceebf8*/
        return 343; /*0x102ceebfe*/
      }
    case 'g': /*0x102ced7f4*/
      v17 = *(unsigned __int8 *)(a1 + 1); /*0x102cedc9e*/
      if ( v17 > 0x68 ) /*0x102cedca5*/
      {
        if ( v17 == 105 ) /*0x102cedf2c*/
        {
          if ( strcmp(__s1: "ndex", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee1b5*/
            return 0xFFFFFFFFLL; /*0x102cee1b5*/
          return 205; /*0x102cee1c1*/
        }
        if ( v17 == 114 && *(_BYTE *)(a1 + 2) == 111 && *(_BYTE *)(a1 + 3) == 117 && *(_BYTE *)(a1 + 4) == 112 ) /*0x102cedf53*/
        {
          if ( *(_BYTE *)(a1 + 5) == 0 ) /*0x102cedf5f*/
            return 217; /*0x102ceffcb*/
          if ( *(_BYTE *)(a1 + 5) == 45 && strcmp(__s1: "check", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cedf80*/
            return 196; /*0x102cedf8c*/
        }
      }
      else
      {
        if ( *(_BYTE *)(a1 + 1) == 0 ) /*0x102cedcad*/
          return 204; /*0x102cee1a2*/
        if ( v17 == 101 /*0x102cedce8*/
          && *(_BYTE *)(a1 + 2) == 110
          && *(_BYTE *)(a1 + 3) == 101
          && *(_BYTE *)(a1 + 4) == 114
          && *(_BYTE *)(a1 + 5) == 97
          && *(_BYTE *)(a1 + 6) == 116 )
        {
          v18 = *(unsigned __int8 *)(a1 + 7); /*0x102cedcee*/
          if ( v18 == 111 ) /*0x102cedcf5*/
          {
            v123 = *(unsigned __int8 *)(a1 + 8) - 114; /*0x102cf0630*/
            if ( *(_BYTE *)(a1 + 8) == 114 ) /*0x102cf0633*/
              v123 = *(unsigned __int8 *)(a1 + 9); /*0x102cf0635*/
            if ( v123 == 0 ) /*0x102cf063d*/
              return 195; /*0x102cf0649*/
          }
          else if ( v18 == 101 && *(_BYTE *)(a1 + 8) == 0 ) /*0x102cedd08*/
          {
            return 321; /*0x102cedd14*/
          }
        }
      }
      return 0xFFFFFFFFLL; /*0x102cedd08*/
    case 'h': /*0x102ced7f4*/
      switch ( __ROR4__(*(char *)(a1 + 1) - 97, 1) ) /*0x102cedd35*/
      {
        case 0: /*0x102cedd35*/
          if ( strcmp(__s1: "s-randkey", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cedd49*/
            return 0xFFFFFFFFLL; /*0x102cedd49*/
          return 51; /*0x102cedd55*/
        case 4: /*0x102cedd35*/
          if ( strcmp(__s1: "ndex", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee4ed*/
            return 0xFFFFFFFFLL; /*0x102cee4ed*/
          return 206; /*0x102cee4f9*/
        case 5: /*0x102cedd35*/
          if ( *(_BYTE *)(a1 + 2) != 100 || *(_BYTE *)(a1 + 3) != 102 || *(_BYTE *)(a1 + 4) != 45 ) /*0x102cee496*/
            return 0xFFFFFFFFLL; /*0x102cee496*/
          v40 = *(unsigned __int8 *)(a1 + 5); /*0x102cee49c*/
          if ( v40 != 107 ) /*0x102cee4a3*/
          {
            if ( v40 == 100 && strcmp(__s1: "igest-check", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cee4c4*/
              return 291; /*0x102cee4d0*/
            return 0xFFFFFFFFLL; /*0x102cee4c4*/
          }
          if ( strcmp(__s1: "ey-check", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf013f*/
            return 0xFFFFFFFFLL; /*0x102cf013f*/
          result = 292; /*0x102cf0145*/
          break; /*0x102cf014b*/
        case 6: /*0x102cedd35*/
          if ( strcmp(__s1: "ac-key-check", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee50c*/
            return 0xFFFFFFFFLL; /*0x102cee50c*/
          return 293; /*0x102cee518*/
        case 9: /*0x102cedd35*/
          if ( strcmp(__s1: "_padding", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee52b*/
            return 0xFFFFFFFFLL; /*0x102cee52b*/
          return 155; /*0x102cee537*/
        default:
          return 0xFFFFFFFFLL;
      }
      return result; /*0x102cf014b*/
    case 'i': /*0x102ced7f4*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102ceddf4*/
      {
        case 'd': /*0x102ceddf4*/
          if ( *(_BYTE *)(a1 + 2) != 0 ) /*0x102ceddfa*/
            return 0xFFFFFFFFLL; /*0x102ceddfa*/
          return 132; /*0x102cede06*/
        case 'k': /*0x102ceddf4*/
          v51 = *(unsigned __int8 *)(a1 + 2) - 109; /*0x102cee8cf*/
          if ( *(_BYTE *)(a1 + 2) == 109 ) /*0x102cee8d2*/
          {
            v51 = *(unsigned __int8 *)(a1 + 3) - 101; /*0x102cee8d8*/
            if ( *(_BYTE *)(a1 + 3) == 101 ) /*0x102cee8db*/
              v51 = *(unsigned __int8 *)(a1 + 4); /*0x102cee8dd*/
          }
          if ( v51 != 0 ) /*0x102cee8e5*/
            return 0xFFFFFFFFLL; /*0x102cee8e5*/
          return 152; /*0x102cee8f1*/
        case 'm': /*0x102ceddf4*/
          if ( strcmp(__s1: "plicit-rejection", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee881*/
            return 0xFFFFFFFFLL; /*0x102cee881*/
          return 8; /*0x102cee88d*/
        case 'n': /*0x102ceddf4*/
          switch ( *(_BYTE *)(a1 + 2) ) /*0x102cee936*/
          {
            case 'c': /*0x102cee936*/
              if ( strcmp(__s1: "lude-public", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cee94a*/
                return 0xFFFFFFFFLL; /*0x102cee94a*/
              result = 197; /*0x102cee950*/
              break; /*0x102cee956*/
            case 'f': /*0x102cee936*/
              v98 = *(unsigned __int8 *)(a1 + 3) - 111; /*0x102cef847*/
              if ( *(_BYTE *)(a1 + 3) == 111 ) /*0x102cef84a*/
                v98 = *(unsigned __int8 *)(a1 + 4); /*0x102cef84c*/
              if ( v98 != 0 ) /*0x102cef854*/
                return 0xFFFFFFFFLL; /*0x102cef854*/
              result = 123; /*0x102cef85a*/
              break; /*0x102cef860*/
            case 'p': /*0x102cee936*/
              if ( strcmp(__s1: "ut-type", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef836*/
                return 0xFFFFFFFFLL; /*0x102cef836*/
              result = 174; /*0x102cef83c*/
              break; /*0x102cef842*/
            case 's': /*0x102cee936*/
              if ( strcmp(__s1: "tance", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef873*/
                return 0xFFFFFFFFLL; /*0x102cef873*/
              result = 332; /*0x102cef879*/
              break; /*0x102cef87f*/
            default:
              return 0xFFFFFFFFLL;
          }
          return result; /*0x102cef87f*/
        case 't': /*0x102ceddf4*/
          if ( *(_BYTE *)(a1 + 2) != 101 || *(_BYTE *)(a1 + 3) != 114 ) /*0x102cee965*/
            return 0xFFFFFFFFLL; /*0x102cee965*/
          if ( *(_BYTE *)(a1 + 4) == 0 ) /*0x102cee971*/
            return 124; /*0x102cefe05*/
          if ( *(_BYTE *)(a1 + 4) == 97 && strcmp(__s1: "tion", __s2: (const char *)(a1 + 5)) == 0 ) /*0x102cee992*/
            return 110; /*0x102cee99e*/
          return 0xFFFFFFFFLL; /*0x102cee992*/
        case 'v': /*0x102ceddf4*/
          v50 = *(unsigned __int8 *)(a1 + 2); /*0x102cee88e*/
          if ( *(_BYTE *)(a1 + 2) == 0 ) /*0x102cee894*/
            return 52; /*0x102cef6dc*/
          if ( v50 == 108 ) /*0x102cee89d*/
          {
            v93 = *(unsigned __int8 *)(a1 + 3) - 101; /*0x102cef6b3*/
            if ( *(_BYTE *)(a1 + 3) == 101 ) /*0x102cef6b6*/
            {
              v93 = *(unsigned __int8 *)(a1 + 4) - 110; /*0x102cef6bc*/
              if ( *(_BYTE *)(a1 + 4) == 110 ) /*0x102cef6bf*/
                v93 = *(unsigned __int8 *)(a1 + 5); /*0x102cef6c1*/
            }
            if ( v93 == 0 ) /*0x102cef6c9*/
              return 53; /*0x102cef6d5*/
          }
          else if ( v50 == 45 && strcmp(__s1: "generated", __s2: (const char *)(a1 + 3)) == 0 ) /*0x102cee8be*/
          {
            return 35; /*0x102cee8ca*/
          }
          break; /*0x102cee8ca*/
        default:
          return 0xFFFFFFFFLL;
      }
      return 0xFFFFFFFFLL; /*0x102cee8be*/
    case 'j': /*0x102ced7f4*/
      if ( *(_BYTE *)(a1 + 1) != 0 ) /*0x102ceddc9*/
        return 0xFFFFFFFFLL; /*0x102ceddc9*/
      return 203; /*0x102ceddd5*/
    case 'k': /*0x102ced7f4*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102ced982*/
      {
        case '1': /*0x102ced982*/
          if ( *(_BYTE *)(a1 + 2) != 0 ) /*0x102ced988*/
            return 0xFFFFFFFFLL; /*0x102ced988*/
          return 186; /*0x102ced994*/
        case '2': /*0x102ced982*/
          if ( *(_BYTE *)(a1 + 2) != 0 ) /*0x102cef03f*/
            return 0xFFFFFFFFLL; /*0x102cef03f*/
          return 187; /*0x102cef04b*/
        case '3': /*0x102ced982*/
          if ( *(_BYTE *)(a1 + 2) != 0 ) /*0x102cef0cc*/
            return 0xFFFFFFFFLL; /*0x102cef0cc*/
          return 188; /*0x102cef0d8*/
        case 'a': /*0x102ced982*/
          v74 = *(unsigned __int8 *)(a1 + 2) - 116; /*0x102cef0dd*/
          if ( *(_BYTE *)(a1 + 2) == 116 ) /*0x102cef0e0*/
            v74 = *(unsigned __int8 *)(a1 + 3); /*0x102cef0e2*/
          if ( v74 != 0 ) /*0x102cef0ea*/
            return 0xFFFFFFFFLL; /*0x102cef0ea*/
          return 333; /*0x102cef0f6*/
        case 'b': /*0x102ced982*/
          if ( strcmp(__s1: "kdf-key-check", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cef109*/
            return 0xFFFFFFFFLL; /*0x102cef109*/
          return 294; /*0x102cef115*/
        case 'd': /*0x102ced982*/
          if ( *(_BYTE *)(a1 + 2) == 102 && *(_BYTE *)(a1 + 3) == 45 ) /*0x102ceefaf*/
          {
            switch ( *(_BYTE *)(a1 + 4) ) /*0x102ceefd3*/
            {
              case 'd': /*0x102ceefd3*/
                if ( *(_BYTE *)(a1 + 5) != 105 /*0x102cef001*/
                  || *(_BYTE *)(a1 + 6) != 103
                  || *(_BYTE *)(a1 + 7) != 101
                  || *(_BYTE *)(a1 + 8) != 115
                  || *(_BYTE *)(a1 + 9) != 116 )
                {
                  return 0xFFFFFFFFLL; /*0x102cef001*/
                }
                if ( *(_BYTE *)(a1 + 10) == 0 ) /*0x102cef00d*/
                  return 104; /*0x102cf0d2c*/
                if ( *(_BYTE *)(a1 + 10) == 45 && strcmp(__s1: "props", __s2: (const char *)(a1 + 11)) == 0 ) /*0x102cef02e*/
                  return 105; /*0x102cef03a*/
                break; /*0x102cef03a*/
              case 'o': /*0x102ceefd3*/
                if ( strcmp(__s1: "utlen", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf035e*/
                  return 0xFFFFFFFFLL; /*0x102cf035e*/
                return 106; /*0x102cf036a*/
              case 't': /*0x102ceefd3*/
                if ( strcmp(__s1: "ype", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf033f*/
                  return 0xFFFFFFFFLL; /*0x102cf033f*/
                return 107; /*0x102cf034b*/
              case 'u': /*0x102ceefd3*/
                v120 = *(unsigned __int8 *)(a1 + 5) - 107; /*0x102cf0376*/
                if ( *(_BYTE *)(a1 + 5) == 107 ) /*0x102cf0379*/
                {
                  v120 = *(unsigned __int8 *)(a1 + 6) - 109; /*0x102cf037f*/
                  if ( *(_BYTE *)(a1 + 6) == 109 ) /*0x102cf0382*/
                    v120 = *(unsigned __int8 *)(a1 + 7); /*0x102cf0384*/
                }
                if ( v120 != 0 ) /*0x102cf038c*/
                  return 0xFFFFFFFFLL; /*0x102cf038c*/
                return 108; /*0x102cf0398*/
              default:
                return 0xFFFFFFFFLL;
            }
          }
          return 0xFFFFFFFFLL; /*0x102cef02e*/
        case 'e': /*0x102ced982*/
          if ( *(_BYTE *)(a1 + 2) != 121 ) /*0x102cef050*/
            return 0xFFFFFFFFLL; /*0x102cef050*/
          v72 = *(unsigned __int8 *)(a1 + 3); /*0x102cef056*/
          if ( v72 > 0x61 ) /*0x102cef05d*/
          {
            if ( v72 != 98 ) /*0x102cef93e*/
            {
              if ( v72 == 108 ) /*0x102cef947*/
              {
                v100 = *(unsigned __int8 *)(a1 + 4) - 101; /*0x102cef951*/
                if ( *(_BYTE *)(a1 + 4) == 101 ) /*0x102cef954*/
                {
                  v100 = *(unsigned __int8 *)(a1 + 5) - 110; /*0x102cef95a*/
                  if ( *(_BYTE *)(a1 + 5) == 110 ) /*0x102cef95d*/
                    v100 = *(unsigned __int8 *)(a1 + 6); /*0x102cef95f*/
                }
                if ( v100 == 0 ) /*0x102cef967*/
                  return 54; /*0x102cef973*/
              }
              return 0xFFFFFFFFLL; /*0x102cef967*/
            }
            if ( strcmp(__s1: "its", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cefe1f*/
              return 0xFFFFFFFFLL; /*0x102cefe1f*/
            result = 60; /*0x102cefe25*/
          }
          else
          {
            if ( *(_BYTE *)(a1 + 3) == 0 ) /*0x102cef065*/
              return 128; /*0x102cefe0c*/
            if ( v72 != 45 ) /*0x102cef06e*/
              return 0xFFFFFFFFLL; /*0x102cef06e*/
            v73 = *(unsigned __int8 *)(a1 + 4); /*0x102cef074*/
            if ( v73 != 108 ) /*0x102cef07b*/
            {
              if ( v73 == 99 && strcmp(__s1: "heck", __s2: (const char *)(a1 + 5)) == 0 ) /*0x102cef09c*/
                return 215; /*0x102cef0a8*/
              return 0xFFFFFFFFLL; /*0x102cef09c*/
            }
            if ( strcmp(__s1: "ength", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf0472*/
              return 0xFFFFFFFFLL; /*0x102cf0472*/
            result = 339; /*0x102cf0478*/
          }
          break; /*0x102cf047e*/
        case 'm': /*0x102ced982*/
          if ( strcmp(__s1: "ac-key-check", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cef0bb*/
            return 0xFFFFFFFFLL; /*0x102cef0bb*/
          return 295; /*0x102cef0c7*/
        default:
          return 0xFFFFFFFFLL;
      }
      return result; /*0x102cf047e*/
    case 'l': /*0x102ced7f4*/
      if ( *(_BYTE *)(a1 + 1) != 97 ) /*0x102cedb9e*/
        return 0xFFFFFFFFLL; /*0x102cedb9e*/
      v14 = *(unsigned __int8 *)(a1 + 2); /*0x102cedba4*/
      if ( v14 == 110 ) /*0x102cedbab*/
      {
        v39 = *(unsigned __int8 *)(a1 + 3) - 101; /*0x102cee45b*/
        if ( *(_BYTE *)(a1 + 3) == 101 ) /*0x102cee45e*/
        {
          v39 = *(unsigned __int8 *)(a1 + 4) - 115; /*0x102cee464*/
          if ( *(_BYTE *)(a1 + 4) == 115 ) /*0x102cee467*/
            v39 = *(unsigned __int8 *)(a1 + 5); /*0x102cee469*/
        }
        if ( v39 == 0 ) /*0x102cee471*/
          return 113; /*0x102cee47d*/
      }
      else if ( v14 == 98 ) /*0x102cedbb4*/
      {
        v15 = *(unsigned __int8 *)(a1 + 3) - 101; /*0x102cedbbe*/
        if ( *(_BYTE *)(a1 + 3) == 101 ) /*0x102cedbc1*/
        {
          v15 = *(unsigned __int8 *)(a1 + 4) - 108; /*0x102cedbc7*/
          if ( *(_BYTE *)(a1 + 4) == 108 ) /*0x102cedbca*/
            v15 = *(unsigned __int8 *)(a1 + 5); /*0x102cedbcc*/
        }
        if ( v15 == 0 ) /*0x102cedbd4*/
          return 129; /*0x102cedbe0*/
      }
      return 0xFFFFFFFFLL; /*0x102cedbd4*/
    case 'm': /*0x102ced7f4*/
      v1 = *(unsigned __int8 *)(a1 + 1); /*0x102ceda68*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102ceda86*/
      {
        case 'a': /*0x102ceda86*/
          v9 = *(unsigned __int8 *)(a1 + 2); /*0x102ceda88*/
          if ( v9 != 120 ) /*0x102ceda8f*/
          {
            if ( v9 == 110 ) /*0x102ceda98*/
            {
              if ( strcmp(__s1: "datory-digest", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef892*/
                return 0xFFFFFFFFLL; /*0x102cef892*/
              return 218; /*0x102cef89e*/
            }
            if ( v9 != 99 ) /*0x102cedaa1*/
              return 0xFFFFFFFFLL; /*0x102cedaa1*/
            v10 = *(unsigned __int8 *)(a1 + 3); /*0x102cedaa7*/
            if ( *(_BYTE *)(a1 + 3) == 0 ) /*0x102cedaad*/
              return 6; /*0x102cf0056*/
            if ( v10 == 108 ) /*0x102cedab6*/
            {
              v117 = *(unsigned __int8 *)(a1 + 4) - 101; /*0x102cf002d*/
              if ( *(_BYTE *)(a1 + 4) == 101 ) /*0x102cf0030*/
              {
                v117 = *(unsigned __int8 *)(a1 + 5) - 110; /*0x102cf0036*/
                if ( *(_BYTE *)(a1 + 5) == 110 ) /*0x102cf0039*/
                  v117 = *(unsigned __int8 *)(a1 + 6); /*0x102cf003b*/
              }
              if ( v117 == 0 ) /*0x102cf0043*/
                return 130; /*0x102cf004f*/
            }
            else if ( v10 == 107 ) /*0x102cedabf*/
            {
              v11 = *(unsigned __int8 *)(a1 + 4) - 101; /*0x102cedac9*/
              if ( *(_BYTE *)(a1 + 4) == 101 ) /*0x102cedacc*/
              {
                v11 = *(unsigned __int8 *)(a1 + 5) - 121; /*0x102cedad2*/
                if ( *(_BYTE *)(a1 + 5) == 121 ) /*0x102cedad5*/
                  v11 = *(unsigned __int8 *)(a1 + 6); /*0x102cedad7*/
              }
              if ( v11 == 0 ) /*0x102cedadf*/
                return 36; /*0x102cedaeb*/
            }
            return 0xFFFFFFFFLL; /*0x102cedadf*/
          }
          v99 = *(unsigned __int8 *)(a1 + 3); /*0x102cef89f*/
          if ( v99 > 0x68 ) /*0x102cef8a6*/
          {
            if ( v99 != 105 ) /*0x102cefd2e*/
            {
              if ( v99 == 109 && strcmp(__s1: "em_bytes", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102cefd4f*/
                return 136; /*0x102cefd5b*/
              return 0xFFFFFFFFLL; /*0x102cefd4f*/
            }
            if ( strcmp(__s1: "um_length", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cf0320*/
              return 0xFFFFFFFFLL; /*0x102cf0320*/
            return 88; /*0x102cf0326*/
          }
          else if ( v99 == 45 ) /*0x102cef8af*/
          {
            if ( strcmp(__s1: "size", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cf0301*/
              return 0xFFFFFFFFLL; /*0x102cf0301*/
            return 220; /*0x102cf0307*/
          }
          else
          {
            if ( v99 != 95 ) /*0x102cef8b8*/
              return 0xFFFFFFFFLL; /*0x102cef8b8*/
            switch ( *(_BYTE *)(a1 + 4) ) /*0x102cef8dc*/
            {
              case 'a': /*0x102cef8dc*/
                if ( strcmp(__s1: "dinlen", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cef8f0*/
                  return 0xFFFFFFFFLL; /*0x102cef8f0*/
                return 86; /*0x102cef8fc*/
              case 'e': /*0x102cef8dc*/
                v130 = *(unsigned __int8 *)(a1 + 5); /*0x102cf0960*/
                if ( v130 != 110 ) /*0x102cf0967*/
                {
                  if ( v130 == 97 && strcmp(__s1: "rly_data", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cf0988*/
                    return 156; /*0x102cf0994*/
                  return 0xFFFFFFFFLL; /*0x102cf0988*/
                }
                if ( strcmp(__s1: "tropylen", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf0bfa*/
                  return 0xFFFFFFFFLL; /*0x102cf0bfa*/
                result = 87; /*0x102cf0c00*/
                break; /*0x102cf0c06*/
              case 'f': /*0x102cef8dc*/
                if ( strcmp(__s1: "rag_len", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf0934*/
                  return 0xFFFFFFFFLL; /*0x102cf0934*/
                return 157; /*0x102cf0940*/
              case 'n': /*0x102cef8dc*/
                if ( strcmp(__s1: "oncelen", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf09a7*/
                  return 0xFFFFFFFFLL; /*0x102cf09a7*/
                return 89; /*0x102cf09b3*/
              case 'p': /*0x102cef8dc*/
                if ( strcmp(__s1: "erslen", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf09c6*/
                  return 0xFFFFFFFFLL; /*0x102cf09c6*/
                return 90; /*0x102cf09d2*/
              case 'r': /*0x102cef8dc*/
                if ( strcmp(__s1: "equest", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf0953*/
                  return 0xFFFFFFFFLL; /*0x102cf0953*/
                return 322; /*0x102cf095f*/
              default:
                return 0xFFFFFFFFLL;
            }
          }
          return result; /*0x102cf0c06*/
        case 'b': /*0x102ceda86*/
        case 'c': /*0x102ceda86*/
        case 'd': /*0x102ceda86*/
        case 'f': /*0x102ceda86*/
        case 'h': /*0x102ceda86*/
        case 'j': /*0x102ceda86*/
        case 'k': /*0x102ceda86*/
        case 'm': /*0x102ceda86*/
        case 'n': /*0x102ceda86*/
        case 'p': /*0x102ceda86*/
        case 'q': /*0x102ceda86*/
        case 'r': /*0x102ceda86*/
        case 's': /*0x102ceda86*/
        case 't': /*0x102ceda86*/
          return 0xFFFFFFFFLL;
        case 'e': /*0x102ceda86*/
          v69 = *(unsigned __int8 *)(a1 + 2); /*0x102ceeebe*/
          if ( v69 != 115 ) /*0x102ceeec5*/
          {
            if ( v69 == 109 && strcmp(__s1: "cost", __s2: (const char *)(a1 + 3)) == 0 ) /*0x102ceeee6*/
              return 114; /*0x102ceeef2*/
            return 0xFFFFFFFFLL; /*0x102ceeee6*/
          }
          if ( strcmp(__s1: "sage-encoding", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef5f7*/
            return 0xFFFFFFFFLL; /*0x102cef5f7*/
          return 334; /*0x102cef603*/
        case 'g': /*0x102ceda86*/
          if ( *(_BYTE *)(a1 + 2) != 102 ) /*0x102ceee2f*/
            return 0xFFFFFFFFLL; /*0x102ceee2f*/
          if ( *(_BYTE *)(a1 + 3) == 0 ) /*0x102ceee3b*/
            return 219; /*0x102cefbd6*/
          if ( *(_BYTE *)(a1 + 3) != 49 || *(_BYTE *)(a1 + 4) != 45 ) /*0x102ceee4e*/
            return 0xFFFFFFFFLL; /*0x102ceee4e*/
          v67 = *(unsigned __int8 *)(a1 + 5); /*0x102ceee54*/
          if ( v67 != 112 ) /*0x102ceee5b*/
          {
            if ( v67 == 100 && strcmp(__s1: "igest", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102ceee7c*/
              return 221; /*0x102ceee88*/
            return 0xFFFFFFFFLL; /*0x102ceee7c*/
          }
          if ( strcmp(__s1: "roperties", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf04ee*/
            return 0xFFFFFFFFLL; /*0x102cf04ee*/
          return 222; /*0x102cf04fa*/
        case 'i': /*0x102ceda86*/
          v68 = *(unsigned __int8 *)(a1 + 2); /*0x102ceee89*/
          if ( v68 != 110 ) /*0x102ceee90*/
          {
            if ( v68 == 99 && strcmp(__s1: "alg", __s2: (const char *)(a1 + 3)) == 0 ) /*0x102ceeeb1*/
              return 79; /*0x102ceeebd*/
            return 0xFFFFFFFFLL; /*0x102ceeeb1*/
          }
          v91 = *(unsigned __int8 *)(a1 + 3); /*0x102cef59a*/
          if ( v91 == 105 ) /*0x102cef5a1*/
          {
            if ( strcmp(__s1: "um_length", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cefd95*/
              return 0xFFFFFFFFLL; /*0x102cefd95*/
            return 92; /*0x102cefd9b*/
          }
          else
          {
            if ( v91 != 95 ) /*0x102cef5aa*/
              return 0xFFFFFFFFLL; /*0x102cef5aa*/
            v92 = *(unsigned __int8 *)(a1 + 4); /*0x102cef5b0*/
            if ( v92 != 110 ) /*0x102cef5b7*/
            {
              if ( v92 == 101 && strcmp(__s1: "ntropylen", __s2: (const char *)(a1 + 5)) == 0 ) /*0x102cef5d8*/
                return 91; /*0x102cef5e4*/
              return 0xFFFFFFFFLL; /*0x102cef5d8*/
            }
            if ( strcmp(__s1: "oncelen", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf0453*/
              return 0xFFFFFFFFLL; /*0x102cf0453*/
            return 93; /*0x102cf0459*/
          }
        case 'l': /*0x102ceda86*/
          if ( *(_BYTE *)(a1 + 2) != 45 ) /*0x102ceeef7*/
            return 0xFFFFFFFFLL; /*0x102ceeef7*/
          v70 = *(unsigned __int8 *)(a1 + 3); /*0x102ceeefd*/
          if ( v70 == 107 ) /*0x102ceef04*/
          {
            if ( *(_BYTE *)(a1 + 4) != 101 || *(_BYTE *)(a1 + 5) != 109 || *(_BYTE *)(a1 + 6) != 46 ) /*0x102cefbef*/
              return 0xFFFFFFFFLL; /*0x102cefbef*/
            switch ( *(_BYTE *)(a1 + 7) ) /*0x102cefc13*/
            {
              case 'i': /*0x102cefc13*/
                v110 = *(unsigned __int8 *)(a1 + 8); /*0x102cefc15*/
                if ( v110 != 110 ) /*0x102cefc1c*/
                {
                  if ( v110 == 109 && strcmp(__s1: "port_pct_type", __s2: (const char *)(a1 + 9)) == 0 ) /*0x102cefc3d*/
                    return 227; /*0x102cefc49*/
                  return 0xFFFFFFFFLL; /*0x102cefc3d*/
                }
                if ( strcmp(__s1: "put_formats", __s2: (const char *)(a1 + 9)) != 0 ) /*0x102cf0cb4*/
                  return 0xFFFFFFFFLL; /*0x102cf0cb4*/
                result = 228; /*0x102cf0cba*/
                break; /*0x102cf0cc0*/
              case 'o': /*0x102cefc13*/
                if ( strcmp(__s1: "utput_formats", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf0b35*/
                  return 0xFFFFFFFFLL; /*0x102cf0b35*/
                return 229; /*0x102cf0b41*/
              case 'p': /*0x102cefc13*/
                if ( strcmp(__s1: "refer_seed", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf0af7*/
                  return 0xFFFFFFFFLL; /*0x102cf0af7*/
                return 230; /*0x102cf0b03*/
              case 'r': /*0x102cefc13*/
                if ( strcmp(__s1: "etain_seed", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf0b73*/
                  return 0xFFFFFFFFLL; /*0x102cf0b73*/
                return 231; /*0x102cf0b7f*/
              default:
                return 0xFFFFFFFFLL;
            }
          }
          else
          {
            if ( v70 != 100 || *(_BYTE *)(a1 + 4) != 115 || *(_BYTE *)(a1 + 5) != 97 || *(_BYTE *)(a1 + 6) != 46 ) /*0x102ceef2b*/
              return 0xFFFFFFFFLL; /*0x102ceef2b*/
            switch ( *(_BYTE *)(a1 + 7) ) /*0x102ceef4f*/
            {
              case 'i': /*0x102ceef4f*/
                if ( strcmp(__s1: "nput_formats", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102ceef63*/
                  return 0xFFFFFFFFLL; /*0x102ceef63*/
                result = 223; /*0x102ceef69*/
                break; /*0x102ceef6f*/
              case 'o': /*0x102ceef4f*/
                if ( strcmp(__s1: "utput_formats", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf0b16*/
                  return 0xFFFFFFFFLL; /*0x102cf0b16*/
                result = 224; /*0x102cf0b1c*/
                break; /*0x102cf0b22*/
              case 'p': /*0x102ceef4f*/
                if ( strcmp(__s1: "refer_seed", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf0ad8*/
                  return 0xFFFFFFFFLL; /*0x102cf0ad8*/
                result = 225; /*0x102cf0ade*/
                break; /*0x102cf0ae4*/
              case 'r': /*0x102ceef4f*/
                if ( strcmp(__s1: "etain_seed", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf0b54*/
                  return 0xFFFFFFFFLL; /*0x102cf0b54*/
                result = 226; /*0x102cf0b5a*/
                break; /*0x102cf0b60*/
              default:
                return 0xFFFFFFFFLL;
            }
          }
          return result; /*0x102cf0b60*/
        case 'o': /*0x102ceda86*/
          if ( *(_BYTE *)(a1 + 2) != 100 ) /*0x102ceef74*/
            return 0xFFFFFFFFLL; /*0x102ceef74*/
          v71 = *(unsigned __int8 *)(a1 + 3); /*0x102ceef7a*/
          if ( v71 != 117 ) /*0x102ceef81*/
          {
            if ( v71 == 101 && *(_BYTE *)(a1 + 4) == 0 ) /*0x102ceef94*/
              return 55; /*0x102ceefa0*/
            return 0xFFFFFFFFLL; /*0x102ceef94*/
          }
          if ( strcmp(__s1: "le-filename", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cefc5c*/
            return 0xFFFFFFFFLL; /*0x102cefc5c*/
          result = 285; /*0x102cefc62*/
          break; /*0x102cefc68*/
        case 'u': /*0x102ceda86*/
          if ( *(_BYTE *)(a1 + 2) != 0 ) /*0x102ceee1e*/
            return 0xFFFFFFFFLL; /*0x102ceee1e*/
          return 335; /*0x102ceee2a*/
        default:
          result = 185; /*0x102cee4d1*/
          goto LABEL_455; /*0x102cee4d6*/
      }
      return result; /*0x102cefc68*/
    case 'n': /*0x102ced7f4*/
      v6 = *(unsigned __int8 *)(a1 + 1); /*0x102ced91f*/
      if ( v6 > 0x6E ) /*0x102ced926*/
      {
        if ( v6 == 111 ) /*0x102cedefc*/
        {
          v31 = *(unsigned __int8 *)(a1 + 2); /*0x102cee167*/
          if ( v31 == 110 ) /*0x102cee16e*/
          {
            if ( *(_BYTE *)(a1 + 3) == 99 && *(_BYTE *)(a1 + 4) == 101 ) /*0x102cef30e*/
            {
              if ( *(_BYTE *)(a1 + 5) == 0 ) /*0x102cef31a*/
                return 122; /*0x102cf0371*/
              if ( *(_BYTE *)(a1 + 5) == 45 && strcmp(__s1: "type", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cef33b*/
                return 336; /*0x102cef347*/
            }
          }
          else if ( v31 == 45 && strcmp(__s1: "short-mac", __s2: (const char *)(a1 + 3)) == 0 ) /*0x102cee18f*/
          {
            return 297; /*0x102cee19b*/
          }
        }
        else if ( v6 == 117 ) /*0x102cedf05*/
        {
          v26 = *(unsigned __int8 *)(a1 + 2) - 109; /*0x102cedf0f*/
          if ( *(_BYTE *)(a1 + 2) == 109 ) /*0x102cedf12*/
            v26 = *(unsigned __int8 *)(a1 + 3); /*0x102cedf14*/
          if ( v26 == 0 ) /*0x102cedf1c*/
            return 56; /*0x102cedf28*/
        }
      }
      else
      {
        if ( *(_BYTE *)(a1 + 1) == 0 ) /*0x102ced92e*/
          return 137; /*0x102cee166*/
        if ( v6 == 97 ) /*0x102ced937*/
        {
          v7 = *(unsigned __int8 *)(a1 + 2) - 109; /*0x102ced941*/
          if ( *(_BYTE *)(a1 + 2) == 109 ) /*0x102ced944*/
          {
            v7 = *(unsigned __int8 *)(a1 + 3) - 101; /*0x102ced94a*/
            if ( *(_BYTE *)(a1 + 3) == 101 ) /*0x102ced94d*/
              v7 = *(unsigned __int8 *)(a1 + 4); /*0x102ced94f*/
          }
          if ( v7 == 0 ) /*0x102ced957*/
            return 296; /*0x102ced963*/
        }
      }
      return 0xFFFFFFFFLL; /*0x102ced957*/
    case 'o': /*0x102ced7f4*/
      v19 = *(unsigned __int8 *)(a1 + 1); /*0x102cedd56*/
      if ( v19 == 114 ) /*0x102cedd5d*/
      {
        if ( strcmp(__s1: "der", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee0a3*/
          return 0xFFFFFFFFLL; /*0x102cee0a3*/
        return 198; /*0x102cee0a9*/
      }
      else
      {
        if ( v19 != 112 ) /*0x102cedd66*/
        {
          if ( v19 == 97 && strcmp(__s1: "ep-label", __s2: (const char *)(a1 + 2)) == 0 ) /*0x102cedd87*/
            return 10; /*0x102cedd93*/
          return 0xFFFFFFFFLL; /*0x102cedd87*/
        }
        v28 = *(unsigned __int8 *)(a1 + 2); /*0x102cee046*/
        if ( v28 == 116 ) /*0x102cee04d*/
        {
          if ( strcmp(__s1: "ions", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef2f3*/
            return 0xFFFFFFFFLL; /*0x102cef2f3*/
          return 158; /*0x102cef2f9*/
        }
        else
        {
          if ( v28 != 101 ) /*0x102cee056*/
            return 0xFFFFFFFFLL; /*0x102cee056*/
          v29 = *(unsigned __int8 *)(a1 + 3); /*0x102cee05c*/
          if ( v29 != 114 ) /*0x102cee063*/
          {
            if ( v29 == 110 && strcmp(__s1: "ssl-version", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102cee084*/
              return 287; /*0x102cee090*/
            return 0xFFFFFFFFLL; /*0x102cee084*/
          }
          if ( strcmp(__s1: "ation", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cef986*/
            return 0xFFFFFFFFLL; /*0x102cef986*/
          return 153; /*0x102cef98c*/
        }
      }
    case 'p': /*0x102ced7f4*/
      v1 = *(unsigned __int8 *)(a1 + 1); /*0x102cedd94*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102ceddb2*/
      {
        case '1': /*0x102ceddb2*/
          if ( *(_BYTE *)(a1 + 2) != 0 ) /*0x102ceddb8*/
            return 0xFFFFFFFFLL; /*0x102ceddb8*/
          return 272; /*0x102ceddc4*/
        case '2': /*0x102ceddb2*/
          if ( *(_BYTE *)(a1 + 2) != 0 ) /*0x102cef121*/
            return 0xFFFFFFFFLL; /*0x102cef121*/
          return 273; /*0x102cef12d*/
        case '3': /*0x102ceddb2*/
        case '4': /*0x102ceddb2*/
        case '5': /*0x102ceddb2*/
        case '6': /*0x102ceddb2*/
        case '7': /*0x102ceddb2*/
        case '8': /*0x102ceddb2*/
        case '9': /*0x102ceddb2*/
        case ':': /*0x102ceddb2*/
        case ';': /*0x102ceddb2*/
        case '<': /*0x102ceddb2*/
        case '=': /*0x102ceddb2*/
        case '>': /*0x102ceddb2*/
        case '?': /*0x102ceddb2*/
        case '@': /*0x102ceddb2*/
        case 'A': /*0x102ceddb2*/
        case 'B': /*0x102ceddb2*/
        case 'C': /*0x102ceddb2*/
        case 'D': /*0x102ceddb2*/
        case 'E': /*0x102ceddb2*/
        case 'F': /*0x102ceddb2*/
        case 'G': /*0x102ceddb2*/
        case 'H': /*0x102ceddb2*/
        case 'I': /*0x102ceddb2*/
        case 'J': /*0x102ceddb2*/
        case 'K': /*0x102ceddb2*/
        case 'L': /*0x102ceddb2*/
        case 'M': /*0x102ceddb2*/
        case 'N': /*0x102ceddb2*/
        case 'O': /*0x102ceddb2*/
        case 'P': /*0x102ceddb2*/
        case 'Q': /*0x102ceddb2*/
        case 'R': /*0x102ceddb2*/
        case 'S': /*0x102ceddb2*/
        case 'T': /*0x102ceddb2*/
        case 'U': /*0x102ceddb2*/
        case 'V': /*0x102ceddb2*/
        case 'W': /*0x102ceddb2*/
        case 'X': /*0x102ceddb2*/
        case 'Y': /*0x102ceddb2*/
        case 'Z': /*0x102ceddb2*/
        case '[': /*0x102ceddb2*/
        case '\\': /*0x102ceddb2*/
        case ']': /*0x102ceddb2*/
        case '^': /*0x102ceddb2*/
        case '_': /*0x102ceddb2*/
        case '`': /*0x102ceddb2*/
        case 'd': /*0x102ceddb2*/
        case 'e': /*0x102ceddb2*/
        case 'f': /*0x102ceddb2*/
        case 'g': /*0x102ceddb2*/
        case 'h': /*0x102ceddb2*/
        case 'j': /*0x102ceddb2*/
        case 'l': /*0x102ceddb2*/
        case 'm': /*0x102ceddb2*/
        case 'n': /*0x102ceddb2*/
        case 'p': /*0x102ceddb2*/
        case 'q': /*0x102ceddb2*/
        case 's': /*0x102ceddb2*/
        case 't': /*0x102ceddb2*/
          return 0xFFFFFFFFLL;
        case 'a': /*0x102ceddb2*/
          v76 = *(unsigned __int8 *)(a1 + 2); /*0x102cef16b*/
          switch ( v76 ) /*0x102cef172*/
          {
            case 's': /*0x102cef172*/
              v106 = *(unsigned __int8 *)(a1 + 3) - 115; /*0x102cefb3d*/
              if ( *(_BYTE *)(a1 + 3) == 115 ) /*0x102cefb40*/
                v106 = *(unsigned __int8 *)(a1 + 4); /*0x102cefb42*/
              if ( v106 == 0 ) /*0x102cefb4a*/
                return 131; /*0x102cefb56*/
              return 0xFFFFFFFFLL; /*0x102cefb4a*/
            case 'r': /*0x102cef172*/
              if ( *(_BYTE *)(a1 + 3) != 116 || *(_BYTE *)(a1 + 4) != 121 ) /*0x102cefafe*/
                return 0xFFFFFFFFLL; /*0x102cefafe*/
              v105 = *(unsigned __int8 *)(a1 + 5); /*0x102cefb04*/
              if ( v105 != 118 ) /*0x102cefb0b*/
              {
                if ( v105 == 117 && strcmp(__s1: "-info", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cefb2c*/
                  return 147; /*0x102cefb38*/
                return 0xFFFFFFFFLL; /*0x102cefb2c*/
              }
              if ( strcmp(__s1: "-info", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf06a2*/
                return 0xFFFFFFFFLL; /*0x102cf06a2*/
              return 148; /*0x102cf06a8*/
            case 'd': /*0x102cef172*/
              v77 = *(unsigned __int8 *)(a1 + 3); /*0x102cef18a*/
              if ( *(_BYTE *)(a1 + 3) == 0 ) /*0x102cef190*/
                return 109; /*0x102cf03fc*/
              if ( v77 == 100 ) /*0x102cef199*/
              {
                if ( strcmp(__s1: "ing", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cf03e9*/
                  return 0xFFFFFFFFLL; /*0x102cf03e9*/
                return 57; /*0x102cf03ef*/
              }
              else
              {
                if ( v77 != 45 ) /*0x102cef1a2*/
                  return 0xFFFFFFFFLL; /*0x102cef1a2*/
                v78 = *(unsigned __int8 *)(a1 + 4); /*0x102cef1a8*/
                if ( v78 != 116 ) /*0x102cef1af*/
                {
                  if ( v78 == 109 && strcmp(__s1: "ode", __s2: (const char *)(a1 + 5)) == 0 ) /*0x102cef1d0*/
                    return 232; /*0x102cef1dc*/
                  return 0xFFFFFFFFLL; /*0x102cef1d0*/
                }
                if ( strcmp(__s1: "ype", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf06c1*/
                  return 0xFFFFFFFFLL; /*0x102cf06c1*/
                return 80; /*0x102cf06c7*/
              }
            default:
              return 0xFFFFFFFFLL; /*0x102cef184*/
          }
        case 'b': /*0x102ceddb2*/
          v79 = *(unsigned __int8 *)(a1 + 2); /*0x102cef1fc*/
          if ( v79 != 107 ) /*0x102cef203*/
          {
            if ( v79 == 105 ) /*0x102cef20c*/
            {
              v80 = *(unsigned __int8 *)(a1 + 3) - 116; /*0x102cef216*/
              if ( *(_BYTE *)(a1 + 3) == 116 ) /*0x102cef219*/
              {
                v80 = *(unsigned __int8 *)(a1 + 4) - 115; /*0x102cef21f*/
                if ( *(_BYTE *)(a1 + 4) == 115 ) /*0x102cef222*/
                  v80 = *(unsigned __int8 *)(a1 + 5); /*0x102cef224*/
              }
              if ( v80 == 0 ) /*0x102cef22c*/
                return 207; /*0x102cef238*/
            }
            return 0xFFFFFFFFLL; /*0x102cef22c*/
          }
          if ( strcmp(__s1: "df2-lower-bound-check", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef90f*/
            return 0xFFFFFFFFLL; /*0x102cef90f*/
          return 298; /*0x102cef91b*/
        case 'c': /*0x102ceddb2*/
          if ( strcmp(__s1: "ounter", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cef140*/
            return 0xFFFFFFFFLL; /*0x102cef140*/
          return 208; /*0x102cef14c*/
        case 'i': /*0x102ceddb2*/
          if ( strcmp(__s1: "peline-tag", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cef1ef*/
            return 0xFFFFFFFFLL; /*0x102cef1ef*/
          return 58; /*0x102cef1fb*/
        case 'k': /*0x102ceddb2*/
          if ( strcmp(__s1: "cs5", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cef24b*/
            return 0xFFFFFFFFLL; /*0x102cef24b*/
          return 133; /*0x102cef257*/
        case 'o': /*0x102ceddb2*/
          v81 = *(unsigned __int8 *)(a1 + 2); /*0x102cef258*/
          if ( v81 != 116 ) /*0x102cef25f*/
          {
            if ( v81 == 105 && strcmp(__s1: "nt-format", __s2: (const char *)(a1 + 3)) == 0 ) /*0x102cef280*/
              return 199; /*0x102cef28c*/
            return 0xFFFFFFFFLL; /*0x102cef280*/
          }
          if ( strcmp(__s1: "ential", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef92e*/
            return 0xFFFFFFFFLL; /*0x102cef92e*/
          return 111; /*0x102cef93a*/
        case 'r': /*0x102ceddb2*/
          v82 = *(unsigned __int8 *)(a1 + 2); /*0x102cef28d*/
          if ( v82 != 111 ) /*0x102cef294*/
          {
            if ( v82 == 105 ) /*0x102cef29d*/
            {
              v107 = *(unsigned __int8 *)(a1 + 3); /*0x102cefb57*/
              if ( v107 == 118 ) /*0x102cefb5e*/
              {
                if ( *(_BYTE *)(a1 + 4) == 0 ) /*0x102cf005d*/
                  return 233; /*0x102cf060c*/
                if ( *(_BYTE *)(a1 + 4) == 95 && strcmp(__s1: "len", __s2: (const char *)(a1 + 5)) == 0 ) /*0x102cf007e*/
                  return 180; /*0x102cf008a*/
              }
              else if ( v107 == 109 ) /*0x102cefb67*/
              {
                v108 = *(unsigned __int8 *)(a1 + 4) - 101; /*0x102cefb71*/
                if ( *(_BYTE *)(a1 + 4) == 101 ) /*0x102cefb74*/
                {
                  v108 = *(unsigned __int8 *)(a1 + 5) - 115; /*0x102cefb7a*/
                  if ( *(_BYTE *)(a1 + 5) == 115 ) /*0x102cefb7d*/
                    v108 = *(unsigned __int8 *)(a1 + 6); /*0x102cefb7f*/
                }
                if ( v108 == 0 ) /*0x102cefb87*/
                  return 270; /*0x102cefb93*/
              }
            }
            else
            {
              if ( v82 != 101 ) /*0x102cef2a6*/
                return 0xFFFFFFFFLL; /*0x102cef2a6*/
              v83 = *(unsigned __int8 *)(a1 + 3); /*0x102cef2ac*/
              if ( v83 == 102 ) /*0x102cef2b3*/
              {
                v118 = *(unsigned __int8 *)(a1 + 4) - 105; /*0x102cf00ae*/
                if ( *(_BYTE *)(a1 + 4) == 105 ) /*0x102cf00b1*/
                {
                  v118 = *(unsigned __int8 *)(a1 + 5) - 120; /*0x102cf00b7*/
                  if ( *(_BYTE *)(a1 + 5) == 120 ) /*0x102cf00ba*/
                    v118 = *(unsigned __int8 *)(a1 + 6); /*0x102cf00bc*/
                }
                if ( v118 == 0 ) /*0x102cf00c4*/
                  return 134; /*0x102cf00d0*/
              }
              else if ( v83 == 100 && strcmp(__s1: "iction_resistance", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102cef2d4*/
              {
                return 94; /*0x102cef2e0*/
              }
            }
            return 0xFFFFFFFFLL; /*0x102cef2d4*/
          }
          v109 = *(unsigned __int8 *)(a1 + 3); /*0x102cefb94*/
          if ( v109 != 118 ) /*0x102cefb9b*/
          {
            if ( v109 == 112 && strcmp(__s1: "erties", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102cefbbc*/
              return 7; /*0x102cefbc8*/
            return 0xFFFFFFFFLL; /*0x102cefbbc*/
          }
          if ( strcmp(__s1: "ider-name", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cf009d*/
            return 0xFFFFFFFFLL; /*0x102cf009d*/
          result = 286; /*0x102cf00a3*/
          break; /*0x102cf00a9*/
        case 'u': /*0x102ceddb2*/
          v75 = *(unsigned __int8 *)(a1 + 2) - 98; /*0x102cef151*/
          if ( *(_BYTE *)(a1 + 2) == 98 ) /*0x102cef154*/
            v75 = *(unsigned __int8 *)(a1 + 3); /*0x102cef156*/
          if ( v75 != 0 ) /*0x102cef15e*/
            return 0xFFFFFFFFLL; /*0x102cef15e*/
          return 234; /*0x102cef16a*/
        default:
          result = 138; /*0x102ceecf0*/
          goto LABEL_455; /*0x102ceecf0*/
      }
      return result; /*0x102cf00a9*/
    case 'q': /*0x102ced7f4*/
      v23 = *(unsigned __int8 *)(a1 + 1); /*0x102cede84*/
      if ( v23 > 0x61 ) /*0x102cede8b*/
      {
        if ( v23 == 98 ) /*0x102cedf90*/
        {
          if ( strcmp(__s1: "its", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee90b*/
            return 0xFFFFFFFFLL; /*0x102cee90b*/
          return 210; /*0x102cee911*/
        }
        else
        {
          if ( v23 != 120 ) /*0x102cedf99*/
          {
            if ( v23 == 121 && *(_BYTE *)(a1 + 2) == 0 ) /*0x102cedfac*/
              return 201; /*0x102cedfb8*/
            return 0xFFFFFFFFLL; /*0x102cedfac*/
          }
          if ( *(_BYTE *)(a1 + 2) != 0 ) /*0x102cee9b4*/
            return 0xFFFFFFFFLL; /*0x102cee9b4*/
          return 200; /*0x102cee9ba*/
        }
      }
      else
      {
        if ( *(_BYTE *)(a1 + 1) == 0 ) /*0x102cede93*/
          return 209; /*0x102cee8f8*/
        if ( v23 != 49 ) /*0x102cede9c*/
        {
          if ( v23 == 50 && *(_BYTE *)(a1 + 2) == 0 ) /*0x102cedeaf*/
            return 275; /*0x102cedebb*/
          return 0xFFFFFFFFLL; /*0x102cedeaf*/
        }
        if ( *(_BYTE *)(a1 + 2) != 0 ) /*0x102cee9a3*/
          return 0xFFFFFFFFLL; /*0x102cee9a3*/
        return 274; /*0x102cee9a9*/
      }
    case 'r': /*0x102ced7f4*/
      v1 = *(unsigned __int8 *)(a1 + 1); /*0x102cede07*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102cede25*/
      {
        case 'a': /*0x102cede25*/
          v20 = *(unsigned __int8 *)(a1 + 2); /*0x102cede27*/
          if ( v20 == 119 ) /*0x102cede2e*/
          {
            if ( strcmp(__s1: "-bytes", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef388*/
              return 0xFFFFFFFFLL; /*0x102cef388*/
            return 340; /*0x102cef38e*/
          }
          else
          {
            if ( v20 != 110 || *(_BYTE *)(a1 + 3) != 100 ) /*0x102cede41*/
              return 0xFFFFFFFFLL; /*0x102cede41*/
            v21 = *(unsigned __int8 *)(a1 + 4); /*0x102cede47*/
            if ( v21 != 111 ) /*0x102cede4e*/
            {
              if ( v21 == 107 ) /*0x102cede57*/
              {
                v22 = *(unsigned __int8 *)(a1 + 5) - 101; /*0x102cede61*/
                if ( *(_BYTE *)(a1 + 5) == 101 ) /*0x102cede64*/
                {
                  v22 = *(unsigned __int8 *)(a1 + 6) - 121; /*0x102cede6a*/
                  if ( *(_BYTE *)(a1 + 6) == 121 ) /*0x102cede6d*/
                    v22 = *(unsigned __int8 *)(a1 + 7); /*0x102cede6f*/
                }
                if ( v22 == 0 ) /*0x102cede77*/
                  return 59; /*0x102cede83*/
              }
              return 0xFFFFFFFFLL; /*0x102cede77*/
            }
            if ( strcmp(__s1: "m_data", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102ceff4a*/
              return 0xFFFFFFFFLL; /*0x102ceff4a*/
            return 95; /*0x102ceff50*/
          }
        case 'b': /*0x102cede25*/
        case 'c': /*0x102cede25*/
        case 'd': /*0x102cede25*/
        case 'f': /*0x102cede25*/
        case 'g': /*0x102cede25*/
        case 'h': /*0x102cede25*/
        case 'i': /*0x102cede25*/
        case 'j': /*0x102cede25*/
        case 'k': /*0x102cede25*/
        case 'l': /*0x102cede25*/
        case 'm': /*0x102cede25*/
        case 'n': /*0x102cede25*/
        case 'p': /*0x102cede25*/
        case 'q': /*0x102cede25*/
        case 'r': /*0x102cede25*/
          return 0xFFFFFFFFLL;
        case 'e': /*0x102cede25*/
          v37 = *(unsigned __int8 *)(a1 + 2); /*0x102cee3ef*/
          if ( v37 == 115 ) /*0x102cee3f6*/
          {
            if ( *(_BYTE *)(a1 + 3) != 101 /*0x102cef491*/
              || *(_BYTE *)(a1 + 4) != 101
              || *(_BYTE *)(a1 + 5) != 100
              || *(_BYTE *)(a1 + 6) != 95 )
            {
              return 0xFFFFFFFFLL; /*0x102cef491*/
            }
            v87 = *(unsigned __int8 *)(a1 + 7); /*0x102cef497*/
            if ( v87 == 116 ) /*0x102cef49e*/
            {
              if ( *(_BYTE *)(a1 + 8) == 105 && *(_BYTE *)(a1 + 9) == 109 && *(_BYTE *)(a1 + 10) == 101 ) /*0x102cf0a11*/
              {
                if ( *(_BYTE *)(a1 + 11) == 0 ) /*0x102cf0a1d*/
                  return 98; /*0x102cf0d78*/
                if ( *(_BYTE *)(a1 + 11) == 95 && strcmp(__s1: "interval", __s2: (const char *)(a1 + 12)) == 0 ) /*0x102cf0a3e*/
                  return 99; /*0x102cf0a4a*/
              }
              return 0xFFFFFFFFLL; /*0x102cf0a3e*/
            }
            if ( v87 != 114 ) /*0x102cef4a7*/
            {
              if ( v87 == 99 && strcmp(__s1: "ounter", __s2: (const char *)(a1 + 8)) == 0 ) /*0x102cef4c8*/
                return 96; /*0x102cef4d4*/
              return 0xFFFFFFFFLL; /*0x102cef4c8*/
            }
            if ( strcmp(__s1: "equests", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf09ec*/
              return 0xFFFFFFFFLL; /*0x102cf09ec*/
            result = 97; /*0x102cf09f2*/
          }
          else if ( v37 == 102 ) /*0x102cee3ff*/
          {
            if ( strcmp(__s1: "erence", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef462*/
              return 0xFFFFFFFFLL; /*0x102cef462*/
            result = 175; /*0x102cef468*/
          }
          else
          {
            if ( v37 != 97 || *(_BYTE *)(a1 + 3) != 100 || *(_BYTE *)(a1 + 4) != 95 ) /*0x102cee41c*/
              return 0xFFFFFFFFLL; /*0x102cee41c*/
            v38 = *(unsigned __int8 *)(a1 + 5); /*0x102cee422*/
            if ( v38 != 98 ) /*0x102cee429*/
            {
              if ( v38 == 97 && strcmp(__s1: "head", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cee44a*/
                return 159; /*0x102cee456*/
              return 0xFFFFFFFFLL; /*0x102cee44a*/
            }
            if ( strcmp(__s1: "uffer_len", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf0491*/
              return 0xFFFFFFFFLL; /*0x102cf0491*/
            result = 163; /*0x102cf0497*/
          }
          break; /*0x102cf049d*/
        case 'o': /*0x102cede25*/
          if ( strcmp(__s1: "unds", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee325*/
            return 0xFFFFFFFFLL; /*0x102cee325*/
          return 61; /*0x102cee331*/
        case 's': /*0x102cede25*/
          if ( *(_BYTE *)(a1 + 2) != 97 || *(_BYTE *)(a1 + 3) != 45 ) /*0x102cee340*/
            return 0xFFFFFFFFLL; /*0x102cee340*/
          switch ( *(_BYTE *)(a1 + 4) ) /*0x102cee364*/
          {
            case 'c': /*0x102cee364*/
              if ( *(_BYTE *)(a1 + 5) != 111 /*0x102cee3c4*/
                || *(_BYTE *)(a1 + 6) != 101
                || *(_BYTE *)(a1 + 7) != 102
                || *(_BYTE *)(a1 + 8) != 102
                || *(_BYTE *)(a1 + 9) != 105
                || *(_BYTE *)(a1 + 10) != 99
                || *(_BYTE *)(a1 + 11) != 105
                || *(_BYTE *)(a1 + 12) != 101
                || *(_BYTE *)(a1 + 13) != 110
                || *(_BYTE *)(a1 + 14) != 116 )
              {
                return 0xFFFFFFFFLL; /*0x102cee3c4*/
              }
              switch ( *(_BYTE *)(a1 + 15) ) /*0x102cee3e6*/
              {
                case 0: /*0x102cee3e6*/
                  result = 235; /*0x102cee3e8*/
                  break; /*0x102cee3ee*/
                case 0x31: /*0x102cee3e6*/
                  if ( *(_BYTE *)(a1 + 16) != 0 ) /*0x102cf12e6*/
                    return 0xFFFFFFFFLL; /*0x102cf12e6*/
                  result = 236; /*0x102cf12ec*/
                  break; /*0x102cf12f2*/
                case 0x32: /*0x102cee3e6*/
                  if ( *(_BYTE *)(a1 + 16) != 0 ) /*0x102cf12f7*/
                    return 0xFFFFFFFFLL; /*0x102cf12f7*/
                  result = 237; /*0x102cf12fd*/
                  break; /*0x102cf1303*/
                case 0x33: /*0x102cee3e6*/
                  if ( *(_BYTE *)(a1 + 16) != 0 ) /*0x102cf133b*/
                    return 0xFFFFFFFFLL; /*0x102cf133b*/
                  result = 238; /*0x102cf1341*/
                  break; /*0x102cf1347*/
                case 0x34: /*0x102cee3e6*/
                  if ( *(_BYTE *)(a1 + 16) != 0 ) /*0x102cf134c*/
                    return 0xFFFFFFFFLL; /*0x102cf134c*/
                  result = 239; /*0x102cf1352*/
                  break; /*0x102cf1358*/
                case 0x35: /*0x102cee3e6*/
                  if ( *(_BYTE *)(a1 + 16) != 0 ) /*0x102cf1308*/
                    return 0xFFFFFFFFLL; /*0x102cf1308*/
                  result = 240; /*0x102cf130e*/
                  break; /*0x102cf1314*/
                case 0x36: /*0x102cee3e6*/
                  if ( *(_BYTE *)(a1 + 16) != 0 ) /*0x102cf1319*/
                    return 0xFFFFFFFFLL; /*0x102cf1319*/
                  result = 241; /*0x102cf131f*/
                  break; /*0x102cf1325*/
                case 0x37: /*0x102cee3e6*/
                  if ( *(_BYTE *)(a1 + 16) != 0 ) /*0x102cf132a*/
                    return 0xFFFFFFFFLL; /*0x102cf132a*/
                  result = 242; /*0x102cf1330*/
                  break; /*0x102cf1336*/
                case 0x38: /*0x102cee3e6*/
                  if ( *(_BYTE *)(a1 + 16) != 0 ) /*0x102cf135d*/
                    return 0xFFFFFFFFLL; /*0x102cf135d*/
                  result = 243; /*0x102cf1363*/
                  break; /*0x102cf1369*/
                case 0x39: /*0x102cee3e6*/
                  if ( *(_BYTE *)(a1 + 16) != 0 ) /*0x102cf136e*/
                    return 0xFFFFFFFFLL; /*0x102cf136e*/
                  result = 244; /*0x102cf1374*/
                  break; /*0x102cf137a*/
                default:
                  return 0xFFFFFFFFLL;
              }
              return result; /*0x102cf137a*/
            case 'd': /*0x102cee364*/
              if ( strcmp(__s1: "erive-from-pq", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf0256*/
                return 0xFFFFFFFFLL; /*0x102cf0256*/
              return 246; /*0x102cf0262*/
            case 'e': /*0x102cee364*/
              if ( *(_BYTE *)(a1 + 5) == 120 /*0x102cf01fa*/
                && *(_BYTE *)(a1 + 6) == 112
                && *(_BYTE *)(a1 + 7) == 111
                && *(_BYTE *)(a1 + 8) == 110
                && *(_BYTE *)(a1 + 9) == 101
                && *(_BYTE *)(a1 + 10) == 110
                && *(_BYTE *)(a1 + 11) == 116 )
              {
                switch ( *(_BYTE *)(a1 + 12) ) /*0x102cf021c*/
                {
                  case 0: /*0x102cf021c*/
                    return 248; /*0x102cf0224*/
                  case 0x31: /*0x102cf021c*/
                    if ( *(_BYTE *)(a1 + 13) == 0 ) /*0x102cf1032*/
                      return 249; /*0x102cf1244*/
                    if ( *(_BYTE *)(a1 + 13) == 48 && *(_BYTE *)(a1 + 14) == 0 ) /*0x102cf1045*/
                      return 250; /*0x102cf1051*/
                    break; /*0x102cf1051*/
                  case 0x32: /*0x102cf021c*/
                    if ( *(_BYTE *)(a1 + 13) != 0 ) /*0x102cf100e*/
                      return 0xFFFFFFFFLL; /*0x102cf100e*/
                    return 251; /*0x102cf101a*/
                  case 0x33: /*0x102cf021c*/
                    if ( *(_BYTE *)(a1 + 13) != 0 ) /*0x102cf1078*/
                      return 0xFFFFFFFFLL; /*0x102cf1078*/
                    return 252; /*0x102cf1084*/
                  case 0x34: /*0x102cf021c*/
                    if ( *(_BYTE *)(a1 + 13) != 0 ) /*0x102cf1089*/
                      return 0xFFFFFFFFLL; /*0x102cf1089*/
                    return 253; /*0x102cf1095*/
                  case 0x35: /*0x102cf021c*/
                    if ( *(_BYTE *)(a1 + 13) != 0 ) /*0x102cf101f*/
                      return 0xFFFFFFFFLL; /*0x102cf101f*/
                    return 254; /*0x102cf102b*/
                  case 0x36: /*0x102cf021c*/
                    if ( *(_BYTE *)(a1 + 13) != 0 ) /*0x102cf1056*/
                      return 0xFFFFFFFFLL; /*0x102cf1056*/
                    return 255; /*0x102cf1062*/
                  case 0x37: /*0x102cf021c*/
                    if ( *(_BYTE *)(a1 + 13) != 0 ) /*0x102cf1067*/
                      return 0xFFFFFFFFLL; /*0x102cf1067*/
                    return 256; /*0x102cf1073*/
                  case 0x38: /*0x102cf021c*/
                    if ( *(_BYTE *)(a1 + 13) != 0 ) /*0x102cf10ab*/
                      return 0xFFFFFFFFLL; /*0x102cf10ab*/
                    return 257; /*0x102cf10b7*/
                  case 0x39: /*0x102cf021c*/
                    if ( *(_BYTE *)(a1 + 13) != 0 ) /*0x102cf109a*/
                      return 0xFFFFFFFFLL; /*0x102cf109a*/
                    return 258; /*0x102cf10a6*/
                  default:
                    return 0xFFFFFFFFLL;
                }
              }
              return 0xFFFFFFFFLL; /*0x102cf1045*/
            case 'f': /*0x102cee364*/
              if ( *(_BYTE *)(a1 + 5) == 97 /*0x102cf028f*/
                && *(_BYTE *)(a1 + 6) == 99
                && *(_BYTE *)(a1 + 7) == 116
                && *(_BYTE *)(a1 + 8) == 111
                && *(_BYTE *)(a1 + 9) == 114 )
              {
                switch ( *(_BYTE *)(a1 + 10) ) /*0x102cf02b1*/
                {
                  case 0: /*0x102cf02b1*/
                    return 259; /*0x102cf02b9*/
                  case 0x31: /*0x102cf02b1*/
                    if ( *(_BYTE *)(a1 + 11) == 0 ) /*0x102cf0e0e*/
                      return 260; /*0x102cf1009*/
                    if ( *(_BYTE *)(a1 + 11) == 48 && *(_BYTE *)(a1 + 12) == 0 ) /*0x102cf0e21*/
                      return 261; /*0x102cf0e2d*/
                    break; /*0x102cf0e2d*/
                  case 0x32: /*0x102cf02b1*/
                    if ( *(_BYTE *)(a1 + 11) != 0 ) /*0x102cf0dea*/
                      return 0xFFFFFFFFLL; /*0x102cf0dea*/
                    return 262; /*0x102cf0df6*/
                  case 0x33: /*0x102cf02b1*/
                    if ( *(_BYTE *)(a1 + 11) != 0 ) /*0x102cf0e54*/
                      return 0xFFFFFFFFLL; /*0x102cf0e54*/
                    return 263; /*0x102cf0e60*/
                  case 0x34: /*0x102cf02b1*/
                    if ( *(_BYTE *)(a1 + 11) != 0 ) /*0x102cf0e65*/
                      return 0xFFFFFFFFLL; /*0x102cf0e65*/
                    return 264; /*0x102cf0e71*/
                  case 0x35: /*0x102cf02b1*/
                    if ( *(_BYTE *)(a1 + 11) != 0 ) /*0x102cf0dfb*/
                      return 0xFFFFFFFFLL; /*0x102cf0dfb*/
                    return 265; /*0x102cf0e07*/
                  case 0x36: /*0x102cf02b1*/
                    if ( *(_BYTE *)(a1 + 11) != 0 ) /*0x102cf0e32*/
                      return 0xFFFFFFFFLL; /*0x102cf0e32*/
                    return 266; /*0x102cf0e3e*/
                  case 0x37: /*0x102cf02b1*/
                    if ( *(_BYTE *)(a1 + 11) != 0 ) /*0x102cf0e43*/
                      return 0xFFFFFFFFLL; /*0x102cf0e43*/
                    return 267; /*0x102cf0e4f*/
                  case 0x38: /*0x102cf02b1*/
                    if ( *(_BYTE *)(a1 + 11) != 0 ) /*0x102cf0e87*/
                      return 0xFFFFFFFFLL; /*0x102cf0e87*/
                    return 268; /*0x102cf0e93*/
                  case 0x39: /*0x102cf02b1*/
                    if ( *(_BYTE *)(a1 + 11) != 0 ) /*0x102cf0e76*/
                      return 0xFFFFFFFFLL; /*0x102cf0e76*/
                    return 269; /*0x102cf0e82*/
                  default:
                    return 0xFFFFFFFFLL;
                }
              }
              return 0xFFFFFFFFLL; /*0x102cf0e21*/
            case 'p': /*0x102cee364*/
              v119 = *(unsigned __int8 *)(a1 + 5); /*0x102cf02ba*/
              if ( v119 != 115 ) /*0x102cf02c1*/
              {
                if ( v119 == 107 && strcmp(__s1: "cs15-pad-disabled", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cf02e2*/
                  return 299; /*0x102cf02ee*/
                return 0xFFFFFFFFLL; /*0x102cf02e2*/
              }
              if ( strcmp(__s1: "s-saltlen-check", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf065c*/
                return 0xFFFFFFFFLL; /*0x102cf065c*/
              result = 300; /*0x102cf0662*/
              break; /*0x102cf0668*/
            case 's': /*0x102cee364*/
              if ( strcmp(__s1: "ign-x931-pad-disabled", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf0237*/
                return 0xFFFFFFFFLL; /*0x102cf0237*/
              return 301; /*0x102cf0243*/
            default:
              return 0xFFFFFFFFLL;
          }
          return result; /*0x102cf0668*/
        default:
          result = 125; /*0x102cee03c*/
LABEL_455:
          if ( v1 != 0 ) /*0x102ceecf7*/
            return 0xFFFFFFFFLL; /*0x102ceecf7*/
          return result; /*0x102ceecf7*/
      }
      return result; /*0x102cf049d*/
    case 's': /*0x102ced7f4*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102ced853*/
      {
        case 'a': /*0x102ced853*/
          v3 = *(unsigned __int8 *)(a1 + 2); /*0x102ced855*/
          if ( v3 == 118 ) /*0x102ced85c*/
          {
            if ( strcmp(__s1: "e-parameters", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef7a5*/
              return 0xFFFFFFFFLL; /*0x102cef7a5*/
            return 102; /*0x102cef7b1*/
          }
          if ( v3 == 108 ) /*0x102ced865*/
          {
            if ( *(_BYTE *)(a1 + 3) != 116 ) /*0x102cef751*/
              return 0xFFFFFFFFLL; /*0x102cef751*/
            if ( *(_BYTE *)(a1 + 4) == 0 ) /*0x102cef75d*/
              return 135; /*0x102cf0440*/
            if ( *(_BYTE *)(a1 + 4) == 108 ) /*0x102cef766*/
            {
              v96 = *(unsigned __int8 *)(a1 + 5) - 101; /*0x102cef770*/
              if ( *(_BYTE *)(a1 + 5) == 101 ) /*0x102cef773*/
              {
                v96 = *(unsigned __int8 *)(a1 + 6) - 110; /*0x102cef779*/
                if ( *(_BYTE *)(a1 + 6) == 110 ) /*0x102cef77c*/
                  v96 = *(unsigned __int8 *)(a1 + 7); /*0x102cef77e*/
              }
              if ( v96 == 0 ) /*0x102cef786*/
                return 271; /*0x102cef792*/
            }
          }
          else if ( v3 == 102 && strcmp(__s1: "eprime-generator", __s2: (const char *)(a1 + 3)) == 0 ) /*0x102ced886*/
          {
            return 179; /*0x102ced892*/
          }
          return 0xFFFFFFFFLL; /*0x102ced886*/
        case 'e': /*0x102ced853*/
          switch ( *(_BYTE *)(a1 + 2) ) /*0x102ceea3c*/
          {
            case 'c': /*0x102ceea3c*/
              v54 = *(unsigned __int8 *)(a1 + 3); /*0x102ceea3e*/
              if ( v54 != 117 ) /*0x102ceea45*/
              {
                if ( v54 == 114 ) /*0x102ceea4e*/
                {
                  v55 = *(unsigned __int8 *)(a1 + 4) - 101; /*0x102ceea58*/
                  if ( *(_BYTE *)(a1 + 4) == 101 ) /*0x102ceea5b*/
                  {
                    v55 = *(unsigned __int8 *)(a1 + 5) - 116; /*0x102ceea61*/
                    if ( *(_BYTE *)(a1 + 5) == 116 ) /*0x102ceea64*/
                      v55 = *(unsigned __int8 *)(a1 + 6); /*0x102ceea66*/
                  }
                  if ( v55 == 0 ) /*0x102ceea6e*/
                    return 139; /*0x102ceea7a*/
                }
                return 0xFFFFFFFFLL; /*0x102ceea6e*/
              }
              if ( *(_BYTE *)(a1 + 4) != 114 /*0x102ceff8a*/
                || *(_BYTE *)(a1 + 5) != 105
                || *(_BYTE *)(a1 + 6) != 116
                || *(_BYTE *)(a1 + 7) != 121
                || *(_BYTE *)(a1 + 8) != 45 )
              {
                return 0xFFFFFFFFLL; /*0x102ceff8a*/
              }
              v116 = *(unsigned __int8 *)(a1 + 9); /*0x102ceff90*/
              if ( v116 != 99 ) /*0x102ceff97*/
              {
                if ( v116 == 98 && strcmp(__s1: "its", __s2: (const char *)(a1 + 10)) == 0 ) /*0x102ceffb8*/
                  return 282; /*0x102ceffc4*/
                return 0xFFFFFFFFLL; /*0x102ceffb8*/
              }
              if ( strcmp(__s1: "hecks", __s2: (const char *)(a1 + 10)) != 0 ) /*0x102cf0d19*/
                return 0xFFFFFFFFLL; /*0x102cf0d19*/
              result = 302; /*0x102cf0d1f*/
              break; /*0x102cf0d25*/
            case 'e': /*0x102ceea3c*/
              v103 = *(unsigned __int8 *)(a1 + 3) - 100; /*0x102cefa4d*/
              if ( *(_BYTE *)(a1 + 3) == 100 ) /*0x102cefa50*/
                v103 = *(unsigned __int8 *)(a1 + 4); /*0x102cefa52*/
              if ( v103 != 0 ) /*0x102cefa5a*/
                return 0xFFFFFFFFLL; /*0x102cefa5a*/
              return 140; /*0x102cefa66*/
            case 'r': /*0x102ceea3c*/
              if ( strcmp(__s1: "ial", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cefa3c*/
                return 0xFFFFFFFFLL; /*0x102cefa3c*/
              return 344; /*0x102cefa48*/
            case 's': /*0x102ceea3c*/
              if ( strcmp(__s1: "sion_id", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cefa79*/
                return 0xFFFFFFFFLL; /*0x102cefa79*/
              return 141; /*0x102cefa85*/
            default:
              return 0xFFFFFFFFLL;
          }
          return result; /*0x102cf0d25*/
        case 'i': /*0x102ced853*/
          v57 = *(unsigned __int8 *)(a1 + 2); /*0x102ceeab0*/
          if ( v57 == 122 ) /*0x102ceeab7*/
          {
            v89 = *(unsigned __int8 *)(a1 + 3) - 101; /*0x102cef52c*/
            if ( *(_BYTE *)(a1 + 3) == 101 ) /*0x102cef52f*/
              v89 = *(unsigned __int8 *)(a1 + 4); /*0x102cef531*/
            if ( v89 == 0 ) /*0x102cef539*/
              return 81; /*0x102cef545*/
            return 0xFFFFFFFFLL; /*0x102cef539*/
          }
          if ( v57 != 103 || *(_BYTE *)(a1 + 3) != 110 ) /*0x102ceeaca*/
            return 0xFFFFFFFFLL; /*0x102ceeaca*/
          v58 = *(unsigned __int8 *)(a1 + 4); /*0x102ceead0*/
          if ( v58 == 97 ) /*0x102ceead7*/
          {
            if ( *(_BYTE *)(a1 + 5) == 116 /*0x102cf00f3*/
              && *(_BYTE *)(a1 + 6) == 117
              && *(_BYTE *)(a1 + 7) == 114
              && *(_BYTE *)(a1 + 8) == 101 )
            {
              if ( *(_BYTE *)(a1 + 9) == 0 ) /*0x102cf00ff*/
                return 337; /*0x102cf0cc7*/
              if ( *(_BYTE *)(a1 + 9) == 45 && strcmp(__s1: "digest-check", __s2: (const char *)(a1 + 10)) == 0 ) /*0x102cf0120*/
                return 306; /*0x102cf012c*/
            }
            return 0xFFFFFFFFLL; /*0x102cf0120*/
          }
          if ( v58 != 45 ) /*0x102ceeae0*/
            return 0xFFFFFFFFLL; /*0x102ceeae0*/
          v59 = *(unsigned __int8 *)(a1 + 5); /*0x102ceeae6*/
          if ( v59 != 120 ) /*0x102ceeaed*/
          {
            if ( v59 == 99 && strcmp(__s1: "heck", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102ceeb0e*/
              return 216; /*0x102ceeb1a*/
            return 0xFFFFFFFFLL; /*0x102ceeb0e*/
          }
          if ( strcmp(__s1: "931-pad-check", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf061f*/
            return 0xFFFFFFFFLL; /*0x102cf061f*/
          return 330; /*0x102cf062b*/
        case 'p': /*0x102ced853*/
          if ( strcmp(__s1: "eed", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102ceeb2d*/
            return 0xFFFFFFFFLL; /*0x102ceeb2d*/
          return 62; /*0x102ceeb39*/
        case 's': /*0x102ced853*/
          v60 = *(unsigned __int8 *)(a1 + 2); /*0x102ceeb3a*/
          if ( v60 == 108 ) /*0x102ceeb41*/
          {
            if ( strcmp(__s1: "3-ms", __s2: (const char *)(a1 + 3)) != 0 ) /*0x102cef817*/
              return 0xFFFFFFFFLL; /*0x102cef817*/
            return 82; /*0x102cef81d*/
          }
          else if ( v60 == 107 ) /*0x102ceeb4a*/
          {
            if ( *(_BYTE *)(a1 + 3) != 100 || *(_BYTE *)(a1 + 4) != 102 || *(_BYTE *)(a1 + 5) != 45 ) /*0x102cef7ca*/
              return 0xFFFFFFFFLL; /*0x102cef7ca*/
            v97 = *(unsigned __int8 *)(a1 + 6); /*0x102cef7d0*/
            if ( v97 != 107 ) /*0x102cef7d7*/
            {
              if ( v97 == 100 && strcmp(__s1: "igest-check", __s2: (const char *)(a1 + 7)) == 0 ) /*0x102cef7f8*/
                return 309; /*0x102cef804*/
              return 0xFFFFFFFFLL; /*0x102cef7f8*/
            }
            if ( strcmp(__s1: "ey-check", __s2: (const char *)(a1 + 7)) != 0 ) /*0x102cf0706*/
              return 0xFFFFFFFFLL; /*0x102cf0706*/
            return 310; /*0x102cf070c*/
          }
          else
          {
            if ( v60 != 104 /*0x102ceeb7b*/
              || *(_BYTE *)(a1 + 3) != 107
              || *(_BYTE *)(a1 + 4) != 100
              || *(_BYTE *)(a1 + 5) != 102
              || *(_BYTE *)(a1 + 6) != 45 )
            {
              return 0xFFFFFFFFLL; /*0x102ceeb7b*/
            }
            v61 = *(unsigned __int8 *)(a1 + 7); /*0x102ceeb81*/
            if ( v61 != 107 ) /*0x102ceeb88*/
            {
              if ( v61 == 100 && strcmp(__s1: "igest-check", __s2: (const char *)(a1 + 8)) == 0 ) /*0x102ceeba9*/
                return 307; /*0x102ceebb5*/
              return 0xFFFFFFFFLL; /*0x102ceeba9*/
            }
            if ( strcmp(__s1: "ey-check", __s2: (const char *)(a1 + 8)) != 0 ) /*0x102cf0a9a*/
              return 0xFFFFFFFFLL; /*0x102cf0a9a*/
            return 308; /*0x102cf0aa0*/
          }
        case 't': /*0x102ced853*/
          v52 = *(unsigned __int8 *)(a1 + 2); /*0x102cee9c1*/
          switch ( v52 ) /*0x102cee9c8*/
          {
            case 'r': /*0x102cee9c8*/
              if ( *(_BYTE *)(a1 + 3) != 101 ) /*0x102cef712*/
                return 0xFFFFFFFFLL; /*0x102cef712*/
              v95 = *(unsigned __int8 *)(a1 + 4); /*0x102cef718*/
              if ( v95 != 110 ) /*0x102cef71f*/
              {
                if ( v95 == 97 && strcmp(__s1: "m_mac", __s2: (const char *)(a1 + 5)) == 0 ) /*0x102cef740*/
                  return 160; /*0x102cef74c*/
                return 0xFFFFFFFFLL; /*0x102cef740*/
              }
              if ( strcmp(__s1: "gth", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf042d*/
                return 0xFFFFFFFFLL; /*0x102cf042d*/
              return 324; /*0x102cf0433*/
            case 'a': /*0x102cee9c8*/
              if ( *(_BYTE *)(a1 + 3) != 116 ) /*0x102cef6e1*/
                return 0xFFFFFFFFLL; /*0x102cef6e1*/
              v94 = *(unsigned __int8 *)(a1 + 4); /*0x102cef6e7*/
              if ( v94 == 117 ) /*0x102cef6ee*/
              {
                v121 = *(unsigned __int8 *)(a1 + 5) - 115; /*0x102cf0401*/
                if ( *(_BYTE *)(a1 + 5) == 115 ) /*0x102cf0404*/
                  v121 = *(unsigned __int8 *)(a1 + 6); /*0x102cf0406*/
                if ( v121 == 0 ) /*0x102cf040e*/
                  return 311; /*0x102cf041a*/
              }
              else if ( v94 == 101 && *(_BYTE *)(a1 + 5) == 0 ) /*0x102cef701*/
              {
                return 323; /*0x102cef70d*/
              }
              return 0xFFFFFFFFLL; /*0x102cef701*/
            case '-': /*0x102cee9c8*/
              v53 = *(unsigned __int8 *)(a1 + 3); /*0x102cee9e0*/
              if ( v53 == 116 ) /*0x102cee9e7*/
              {
                if ( strcmp(__s1: "ype", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102cefffd*/
                  return 0xFFFFFFFFLL; /*0x102cefffd*/
                return 305; /*0x102cf0003*/
              }
              else
              {
                if ( v53 != 112 ) /*0x102cee9f0*/
                {
                  if ( v53 == 100 && strcmp(__s1: "esc", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102ceea11*/
                    return 303; /*0x102ceea1d*/
                  return 0xFFFFFFFFLL; /*0x102ceea11*/
                }
                if ( strcmp(__s1: "hase", __s2: (const char *)(a1 + 4)) != 0 ) /*0x102ceffde*/
                  return 0xFFFFFFFFLL; /*0x102ceffde*/
                return 304; /*0x102ceffe4*/
              }
            default:
              return 0xFFFFFFFFLL; /*0x102cee9da*/
          }
        case 'u': /*0x102ced853*/
          v56 = *(unsigned __int8 *)(a1 + 2); /*0x102ceea7b*/
          if ( v56 != 112 ) /*0x102ceea82*/
          {
            if ( v56 == 98 && strcmp(__s1: "ject", __s2: (const char *)(a1 + 3)) == 0 ) /*0x102ceeaa3*/
              return 345; /*0x102ceeaaf*/
            return 0xFFFFFFFFLL; /*0x102ceeaa3*/
          }
          if ( *(_BYTE *)(a1 + 3) != 112 || *(_BYTE *)(a1 + 4) != 45 || *(_BYTE *)(a1 + 5) != 112 ) /*0x102cef4ed*/
            return 0xFFFFFFFFLL; /*0x102cef4ed*/
          v88 = *(unsigned __int8 *)(a1 + 6); /*0x102cef4f3*/
          if ( v88 != 117 ) /*0x102cef4fa*/
          {
            if ( v88 == 114 && strcmp(__s1: "ivinfo", __s2: (const char *)(a1 + 7)) == 0 ) /*0x102cef51b*/
              return 149; /*0x102cef527*/
            return 0xFFFFFFFFLL; /*0x102cef51b*/
          }
          if ( strcmp(__s1: "binfo", __s2: (const char *)(a1 + 7)) != 0 ) /*0x102cf06e0*/
            return 0xFFFFFFFFLL; /*0x102cf06e0*/
          result = 150; /*0x102cf06e6*/
          break; /*0x102cf06ec*/
        default:
          return 0xFFFFFFFFLL;
      }
      return result; /*0x102cf06ec*/
    case 't': /*0x102ced7f4*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102cedb0a*/
      {
        case 'a': /*0x102cedb0a*/
          if ( *(_BYTE *)(a1 + 2) != 103 ) /*0x102cedb10*/
            return 0xFFFFFFFFLL; /*0x102cedb10*/
          if ( *(_BYTE *)(a1 + 3) == 0 ) /*0x102cedb1c*/
            return 37; /*0x102cefbcf*/
          if ( *(_BYTE *)(a1 + 3) == 108 ) /*0x102cedb25*/
          {
            v12 = *(unsigned __int8 *)(a1 + 4) - 101; /*0x102cedb2f*/
            if ( *(_BYTE *)(a1 + 4) == 101 ) /*0x102cedb32*/
            {
              v12 = *(unsigned __int8 *)(a1 + 5) - 110; /*0x102cedb38*/
              if ( *(_BYTE *)(a1 + 5) == 110 ) /*0x102cedb3b*/
                v12 = *(unsigned __int8 *)(a1 + 6); /*0x102cedb3d*/
            }
            if ( v12 == 0 ) /*0x102cedb45*/
              return 38; /*0x102cedb51*/
          }
          return 0xFFFFFFFFLL; /*0x102cedb45*/
        case 'd': /*0x102cedb0a*/
          if ( strcmp(__s1: "es-encrypt-disabled", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102ceebd9*/
            return 0xFFFFFFFFLL; /*0x102ceebd9*/
          return 312; /*0x102ceebe5*/
        case 'e': /*0x102cedb0a*/
          if ( *(_BYTE *)(a1 + 2) != 115 || *(_BYTE *)(a1 + 3) != 116 ) /*0x102ceec59*/
            return 0xFFFFFFFFLL; /*0x102ceec59*/
          v63 = *(unsigned __int8 *)(a1 + 4); /*0x102ceec5f*/
          if ( v63 != 95 ) /*0x102ceec66*/
          {
            if ( v63 == 45 && strcmp(__s1: "entropy", __s2: (const char *)(a1 + 5)) == 0 ) /*0x102ceec87*/
              return 338; /*0x102ceec8f*/
            return 0xFFFFFFFFLL; /*0x102ceec87*/
          }
          v114 = *(unsigned __int8 *)(a1 + 5); /*0x102cefe7c*/
          if ( v114 != 110 ) /*0x102cefe83*/
          {
            if ( v114 == 101 && strcmp(__s1: "ntropy", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cefea4*/
              return 325; /*0x102cefeb0*/
            return 0xFFFFFFFFLL; /*0x102cefea4*/
          }
          if ( strcmp(__s1: "once", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf04b0*/
            return 0xFFFFFFFFLL; /*0x102cf04b0*/
          return 326; /*0x102cf04bc*/
        case 'h': /*0x102cedb0a*/
          if ( strcmp(__s1: "reads", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102ceeca2*/
            return 0xFFFFFFFFLL; /*0x102ceeca2*/
          return 144; /*0x102ceecaa*/
        case 'l': /*0x102cedb0a*/
          if ( *(_BYTE *)(a1 + 2) != 115 ) /*0x102ceecaf*/
            return 0xFFFFFFFFLL; /*0x102ceecaf*/
          v64 = *(unsigned __int8 *)(a1 + 3); /*0x102ceecb1*/
          if ( v64 > 0x60 ) /*0x102ceecb8*/
          {
            if ( v64 == 97 ) /*0x102ceecc1*/
            {
              if ( *(_BYTE *)(a1 + 4) == 97 && *(_BYTE *)(a1 + 5) == 100 ) /*0x102cefe3a*/
              {
                if ( *(_BYTE *)(a1 + 6) == 0 ) /*0x102cefe46*/
                  return 39; /*0x102cf0921*/
                if ( *(_BYTE *)(a1 + 6) == 112 ) /*0x102cefe4f*/
                {
                  v113 = *(unsigned __int8 *)(a1 + 7) - 97; /*0x102cefe59*/
                  if ( *(_BYTE *)(a1 + 7) == 97 ) /*0x102cefe5c*/
                  {
                    v113 = *(unsigned __int8 *)(a1 + 8) - 100; /*0x102cefe62*/
                    if ( *(_BYTE *)(a1 + 8) == 100 ) /*0x102cefe65*/
                      v113 = *(unsigned __int8 *)(a1 + 9); /*0x102cefe67*/
                  }
                  if ( v113 == 0 ) /*0x102cefe6f*/
                    return 40; /*0x102cefe7b*/
                }
              }
            }
            else if ( v64 == 105 ) /*0x102ceecca*/
            {
              if ( *(_BYTE *)(a1 + 4) != 118 ) /*0x102cefeb5*/
                return 0xFFFFFFFFLL; /*0x102cefeb5*/
              v115 = *(unsigned __int8 *)(a1 + 5); /*0x102cefebb*/
              if ( v115 == 105 ) /*0x102cefec2*/
              {
                v126 = *(unsigned __int8 *)(a1 + 6) - 110; /*0x102cf07d8*/
                if ( *(_BYTE *)(a1 + 6) == 110 ) /*0x102cf07db*/
                {
                  v126 = *(unsigned __int8 *)(a1 + 7) - 118; /*0x102cf07e1*/
                  if ( *(_BYTE *)(a1 + 7) == 118 ) /*0x102cf07e4*/
                    v126 = *(unsigned __int8 *)(a1 + 8); /*0x102cf07e6*/
                }
                if ( v126 == 0 ) /*0x102cf07ee*/
                  return 43; /*0x102cf07fa*/
              }
              else if ( v115 == 103 ) /*0x102cefecb*/
              {
                v125 = *(unsigned __int8 *)(a1 + 6) - 101; /*0x102cf0792*/
                if ( *(_BYTE *)(a1 + 6) == 101 ) /*0x102cf0795*/
                {
                  v125 = *(unsigned __int8 *)(a1 + 7) - 110; /*0x102cf079b*/
                  if ( *(_BYTE *)(a1 + 7) == 110 ) /*0x102cf079e*/
                    v125 = *(unsigned __int8 *)(a1 + 8); /*0x102cf07a0*/
                }
                if ( v125 == 0 ) /*0x102cf07a8*/
                  return 41; /*0x102cf07b4*/
              }
              else if ( v115 == 102 && strcmp(__s1: "ixed", __s2: (const char *)(a1 + 6)) == 0 ) /*0x102cefeec*/
              {
                return 42; /*0x102cefef8*/
              }
            }
            else if ( v64 == 116 && strcmp(__s1: "ree", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102ceece7*/
            {
              return 161; /*0x102ceecef*/
            }
            return 0xFFFFFFFFLL; /*0x102ceece7*/
          }
          if ( v64 == 45 ) /*0x102cef996*/
          {
            switch ( *(_BYTE *)(a1 + 4) ) /*0x102ceff17*/
            {
              case 'c': /*0x102ceff17*/
                if ( strcmp(__s1: "lient-version", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102ceff2b*/
                  return 0xFFFFFFFFLL; /*0x102ceff2b*/
                return 11; /*0x102ceff37*/
              case 'd': /*0x102ceff17*/
                if ( strcmp(__s1: "ata-size", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf07c7*/
                  return 0xFFFFFFFFLL; /*0x102cf07c7*/
                return 170; /*0x102cf07d3*/
              case 'g': /*0x102ceff17*/
                if ( *(_BYTE *)(a1 + 5) == 114 /*0x102cf0846*/
                  && *(_BYTE *)(a1 + 6) == 111
                  && *(_BYTE *)(a1 + 7) == 117
                  && *(_BYTE *)(a1 + 8) == 112
                  && *(_BYTE *)(a1 + 9) == 45 )
                {
                  switch ( *(_BYTE *)(a1 + 10) ) /*0x102cf086a*/
                  {
                    case 'a': /*0x102cf086a*/
                      v127 = *(unsigned __int8 *)(a1 + 11) - 108; /*0x102cf0870*/
                      if ( *(_BYTE *)(a1 + 11) == 108 ) /*0x102cf0873*/
                      {
                        v127 = *(unsigned __int8 *)(a1 + 12) - 103; /*0x102cf0879*/
                        if ( *(_BYTE *)(a1 + 12) == 103 ) /*0x102cf087c*/
                          v127 = *(unsigned __int8 *)(a1 + 13); /*0x102cf087e*/
                      }
                      if ( v127 != 0 ) /*0x102cf0886*/
                        return 0xFFFFFFFFLL; /*0x102cf0886*/
                      return 13; /*0x102cf0892*/
                    case 'i': /*0x102cf086a*/
                      v139 = *(unsigned __int8 *)(a1 + 11); /*0x102cf0fbd*/
                      if ( v139 != 115 ) /*0x102cf0fc4*/
                      {
                        if ( v139 == 100 && *(_BYTE *)(a1 + 12) == 0 ) /*0x102cf0fd7*/
                          return 14; /*0x102cf0fe3*/
                        return 0xFFFFFFFFLL; /*0x102cf0fd7*/
                      }
                      if ( strcmp(__s1: "-kem", __s2: (const char *)(a1 + 12)) != 0 ) /*0x102cf10ca*/
                        return 0xFFFFFFFFLL; /*0x102cf10ca*/
                      return 15; /*0x102cf10d6*/
                    case 'n': /*0x102cf086a*/
                      if ( *(_BYTE *)(a1 + 11) != 97 || *(_BYTE *)(a1 + 12) != 109 || *(_BYTE *)(a1 + 13) != 101 ) /*0x102cf0f83*/
                        return 0xFFFFFFFFLL; /*0x102cf0f83*/
                      if ( *(_BYTE *)(a1 + 14) == 0 ) /*0x102cf0f8f*/
                        return 20; /*0x102cf1381*/
                      if ( *(_BYTE *)(a1 + 14) == 45 && strcmp(__s1: "internal", __s2: (const char *)(a1 + 15)) == 0 ) /*0x102cf0fb0*/
                        return 21; /*0x102cf0fbc*/
                      break; /*0x102cf0fbc*/
                    case 's': /*0x102cf086a*/
                      if ( strcmp(__s1: "ec-bits", __s2: (const char *)(a1 + 11)) != 0 ) /*0x102cf0ff6*/
                        return 0xFFFFFFFFLL; /*0x102cf0ff6*/
                      return 22; /*0x102cf1002*/
                    default:
                      return 0xFFFFFFFFLL;
                  }
                }
                return 0xFFFFFFFFLL; /*0x102cf0fb0*/
              case 'm': /*0x102ceff17*/
                v128 = *(unsigned __int8 *)(a1 + 5); /*0x102cf0893*/
                switch ( v128 ) /*0x102cf089a*/
                {
                  case 'u': /*0x102cf089a*/
                    if ( strcmp(__s1: "lti", __s2: (const char *)(a1 + 6)) != 0 ) /*0x102cf0bdb*/
                      return 0xFFFFFFFFLL; /*0x102cf0bdb*/
                    return 63; /*0x102cf0be7*/
                  case 'i': /*0x102cf089a*/
                    if ( *(_BYTE *)(a1 + 6) == 110 && *(_BYTE *)(a1 + 7) == 45 ) /*0x102cf0b8e*/
                    {
                      v132 = *(unsigned __int8 *)(a1 + 8); /*0x102cf0b94*/
                      if ( v132 == 116 ) /*0x102cf0b9b*/
                      {
                        v134 = *(unsigned __int8 *)(a1 + 9) - 108; /*0x102cf0d9c*/
                        if ( *(_BYTE *)(a1 + 9) == 108 ) /*0x102cf0d9f*/
                        {
                          v134 = *(unsigned __int8 *)(a1 + 10) - 115; /*0x102cf0da5*/
                          if ( *(_BYTE *)(a1 + 10) == 115 ) /*0x102cf0da8*/
                            v134 = *(unsigned __int8 *)(a1 + 11); /*0x102cf0daa*/
                        }
                        if ( v134 == 0 ) /*0x102cf0db2*/
                          return 19; /*0x102cf0dbe*/
                      }
                      else if ( v132 == 100 && strcmp(__s1: "tls", __s2: (const char *)(a1 + 9)) == 0 ) /*0x102cf0bbc*/
                      {
                        return 18; /*0x102cf0bc8*/
                      }
                    }
                    break;
                  case 'a': /*0x102cf089a*/
                    v129 = *(unsigned __int8 *)(a1 + 6); /*0x102cf08b2*/
                    if ( v129 == 120 ) /*0x102cf08b9*/
                    {
                      if ( *(_BYTE *)(a1 + 7) != 45 ) /*0x102cf0ccc*/
                        return 0xFFFFFFFFLL; /*0x102cf0ccc*/
                      v133 = *(unsigned __int8 *)(a1 + 8); /*0x102cf0cd2*/
                      if ( v133 == 116 ) /*0x102cf0cd9*/
                      {
                        v135 = *(unsigned __int8 *)(a1 + 9) - 108; /*0x102cf0dc3*/
                        if ( *(_BYTE *)(a1 + 9) == 108 ) /*0x102cf0dc6*/
                        {
                          v135 = *(unsigned __int8 *)(a1 + 10) - 115; /*0x102cf0dcc*/
                          if ( *(_BYTE *)(a1 + 10) == 115 ) /*0x102cf0dcf*/
                            v135 = *(unsigned __int8 *)(a1 + 11); /*0x102cf0dd1*/
                        }
                        if ( v135 == 0 ) /*0x102cf0dd9*/
                          return 17; /*0x102cf0de5*/
                      }
                      else if ( v133 == 100 && strcmp(__s1: "tls", __s2: (const char *)(a1 + 9)) == 0 ) /*0x102cf0cfa*/
                      {
                        return 16; /*0x102cf0d06*/
                      }
                    }
                    else
                    {
                      if ( v129 != 99 ) /*0x102cf08c2*/
                        return 0xFFFFFFFFLL; /*0x102cf08c2*/
                      if ( *(_BYTE *)(a1 + 7) == 0 ) /*0x102cf08ce*/
                        return 72; /*0x102cf0d71*/
                      if ( *(_BYTE *)(a1 + 7) == 45 && strcmp(__s1: "size", __s2: (const char *)(a1 + 8)) == 0 ) /*0x102cf08ef*/
                        return 73; /*0x102cf08fb*/
                    }
                    break;
                  default:
                    return 0xFFFFFFFFLL; /*0x102cf08ac*/
                }
                break; /*0x102cf08fb*/
              case 'n': /*0x102ceff17*/
                if ( strcmp(__s1: "egotiated-version", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf090e*/
                  return 0xFFFFFFFFLL; /*0x102cf090e*/
                return 12; /*0x102cf091a*/
              case 's': /*0x102ceff17*/
                if ( *(_BYTE *)(a1 + 5) == 105 /*0x102cf0749*/
                  && *(_BYTE *)(a1 + 6) == 103
                  && *(_BYTE *)(a1 + 7) == 97
                  && *(_BYTE *)(a1 + 8) == 108
                  && *(_BYTE *)(a1 + 9) == 103
                  && *(_BYTE *)(a1 + 10) == 45 )
                {
                  switch ( *(_BYTE *)(a1 + 11) ) /*0x102cf076d*/
                  {
                    case 'c': /*0x102cf076d*/
                      if ( strcmp(__s1: "ode-point", __s2: (const char *)(a1 + 12)) != 0 ) /*0x102cf0781*/
                        return 0xFFFFFFFFLL; /*0x102cf0781*/
                      return 23; /*0x102cf078d*/
                    case 'h': /*0x102cf076d*/
                      if ( *(_BYTE *)(a1 + 12) != 97 /*0x102cf10f9*/
                        || *(_BYTE *)(a1 + 13) != 115
                        || *(_BYTE *)(a1 + 14) != 104
                        || *(_BYTE *)(a1 + 15) != 45 )
                      {
                        return 0xFFFFFFFFLL; /*0x102cf10f9*/
                      }
                      v140 = *(unsigned __int8 *)(a1 + 16); /*0x102cf10ff*/
                      if ( v140 == 111 ) /*0x102cf1106*/
                      {
                        v146 = *(unsigned __int8 *)(a1 + 17) - 105; /*0x102cf13ad*/
                        if ( *(_BYTE *)(a1 + 17) == 105 ) /*0x102cf13b0*/
                        {
                          v146 = *(unsigned __int8 *)(a1 + 18) - 100; /*0x102cf13b6*/
                          if ( *(_BYTE *)(a1 + 18) == 100 ) /*0x102cf13b9*/
                            v146 = *(unsigned __int8 *)(a1 + 19); /*0x102cf13bb*/
                        }
                        if ( v146 == 0 ) /*0x102cf13c3*/
                          return 25; /*0x102cf13cf*/
                      }
                      else if ( v140 == 110 && strcmp(__s1: "ame", __s2: (const char *)(a1 + 17)) == 0 ) /*0x102cf1127*/
                      {
                        return 24; /*0x102cf1133*/
                      }
                      return 0xFFFFFFFFLL; /*0x102cf1127*/
                    case 'i': /*0x102cf076d*/
                      if ( strcmp(__s1: "ana-name", __s2: (const char *)(a1 + 12)) != 0 ) /*0x102cf11a2*/
                        return 0xFFFFFFFFLL; /*0x102cf11a2*/
                      return 26; /*0x102cf11ae*/
                    case 'k': /*0x102cf076d*/
                      if ( *(_BYTE *)(a1 + 12) != 101 /*0x102cf11e5*/
                        || *(_BYTE *)(a1 + 13) != 121
                        || *(_BYTE *)(a1 + 14) != 116
                        || *(_BYTE *)(a1 + 15) != 121
                        || *(_BYTE *)(a1 + 16) != 112
                        || *(_BYTE *)(a1 + 17) != 101 )
                      {
                        return 0xFFFFFFFFLL; /*0x102cf11e5*/
                      }
                      if ( *(_BYTE *)(a1 + 18) == 0 ) /*0x102cf11f1*/
                        return 27; /*0x102cf13d0*/
                      if ( *(_BYTE *)(a1 + 18) == 45 && strcmp(__s1: "oid", __s2: (const char *)(a1 + 19)) == 0 ) /*0x102cf1212*/
                        return 28; /*0x102cf121e*/
                      return 0xFFFFFFFFLL; /*0x102cf1212*/
                    case 'n': /*0x102cf076d*/
                      if ( strcmp(__s1: "ame", __s2: (const char *)(a1 + 12)) != 0 ) /*0x102cf1231*/
                        return 0xFFFFFFFFLL; /*0x102cf1231*/
                      return 29; /*0x102cf123d*/
                    case 'o': /*0x102cf076d*/
                      v141 = *(unsigned __int8 *)(a1 + 12) - 105; /*0x102cf1138*/
                      if ( *(_BYTE *)(a1 + 12) == 105 ) /*0x102cf113b*/
                      {
                        v141 = *(unsigned __int8 *)(a1 + 13) - 100; /*0x102cf1141*/
                        if ( *(_BYTE *)(a1 + 13) == 100 ) /*0x102cf1144*/
                          v141 = *(unsigned __int8 *)(a1 + 14); /*0x102cf1146*/
                      }
                      if ( v141 != 0 ) /*0x102cf114e*/
                        return 0xFFFFFFFFLL; /*0x102cf114e*/
                      return 30; /*0x102cf115a*/
                    case 's': /*0x102cf076d*/
                      v142 = *(unsigned __int8 *)(a1 + 12); /*0x102cf115b*/
                      if ( v142 == 105 ) /*0x102cf1162*/
                      {
                        if ( *(_BYTE *)(a1 + 13) == 103 && *(_BYTE *)(a1 + 14) == 45 ) /*0x102cf12a7*/
                        {
                          v144 = *(unsigned __int8 *)(a1 + 15); /*0x102cf12ad*/
                          if ( v144 == 111 ) /*0x102cf12b4*/
                          {
                            v145 = *(unsigned __int8 *)(a1 + 16) - 105; /*0x102cf1386*/
                            if ( *(_BYTE *)(a1 + 16) == 105 ) /*0x102cf1389*/
                            {
                              v145 = *(unsigned __int8 *)(a1 + 17) - 100; /*0x102cf138f*/
                              if ( *(_BYTE *)(a1 + 17) == 100 ) /*0x102cf1392*/
                                v145 = *(unsigned __int8 *)(a1 + 18); /*0x102cf1394*/
                            }
                            if ( v145 == 0 ) /*0x102cf139c*/
                              return 33; /*0x102cf13a8*/
                          }
                          else if ( v144 == 110 && strcmp(__s1: "ame", __s2: (const char *)(a1 + 16)) == 0 ) /*0x102cf12d5*/
                          {
                            return 32; /*0x102cf12e1*/
                          }
                        }
                      }
                      else if ( v142 == 101 && strcmp(__s1: "c-bits", __s2: (const char *)(a1 + 13)) == 0 ) /*0x102cf1183*/
                      {
                        return 31; /*0x102cf118f*/
                      }
                      break; /*0x102cf118f*/
                    default:
                      return 0xFFFFFFFFLL;
                  }
                }
                return 0xFFFFFFFFLL; /*0x102cf1183*/
              case 'v': /*0x102ceff17*/
                if ( strcmp(__s1: "ersion", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf080d*/
                  return 0xFFFFFFFFLL; /*0x102cf080d*/
                return 74; /*0x102cf0819*/
              default:
                return 0xFFFFFFFFLL;
            }
            return 0xFFFFFFFFLL; /*0x102cf08ef*/
          }
          if ( v64 != 49 ) /*0x102cef99f*/
            return 0xFFFFFFFFLL; /*0x102cef99f*/
          v101 = *(unsigned __int8 *)(a1 + 4); /*0x102cef9a5*/
          if ( v101 == 109 ) /*0x102cef9ac*/
          {
            if ( *(_BYTE *)(a1 + 5) != 117 /*0x102cf0595*/
              || *(_BYTE *)(a1 + 6) != 108
              || *(_BYTE *)(a1 + 7) != 116
              || *(_BYTE *)(a1 + 8) != 105
              || *(_BYTE *)(a1 + 9) != 95 )
            {
              return 0xFFFFFFFFLL; /*0x102cf0595*/
            }
            switch ( __ROL4__(*(char *)(a1 + 10) - 97, 30) ) /*0x102cf05bc*/
            {
              case 0: /*0x102cf05bc*/
                if ( *(_BYTE *)(a1 + 11) != 97 || *(_BYTE *)(a1 + 12) != 100 ) /*0x102cf05cc*/
                  return 0xFFFFFFFFLL; /*0x102cf05cc*/
                if ( *(_BYTE *)(a1 + 13) == 0 ) /*0x102cf05d8*/
                  return 64; /*0x102cf124b*/
                if ( *(_BYTE *)(a1 + 13) == 112 && strcmp(__s1: "acklen", __s2: (const char *)(a1 + 14)) == 0 ) /*0x102cf05f9*/
                  return 65; /*0x102cf0605*/
                return 0xFFFFFFFFLL; /*0x102cf05f9*/
              case 1: /*0x102cf05bc*/
                if ( *(_BYTE *)(a1 + 11) != 110 || *(_BYTE *)(a1 + 12) != 99 ) /*0x102cf0f0a*/
                  return 0xFFFFFFFFLL; /*0x102cf0f0a*/
                v137 = *(unsigned __int8 *)(a1 + 13); /*0x102cf0f10*/
                if ( *(_BYTE *)(a1 + 13) == 0 ) /*0x102cf0f16*/
                  return 66; /*0x102cf1298*/
                if ( v137 == 108 ) /*0x102cf0f1f*/
                {
                  v143 = *(unsigned __int8 *)(a1 + 14) - 101; /*0x102cf126f*/
                  if ( *(_BYTE *)(a1 + 14) == 101 ) /*0x102cf1272*/
                  {
                    v143 = *(unsigned __int8 *)(a1 + 15) - 110; /*0x102cf1278*/
                    if ( *(_BYTE *)(a1 + 15) == 110 ) /*0x102cf127b*/
                      v143 = *(unsigned __int8 *)(a1 + 16); /*0x102cf127d*/
                  }
                  if ( v143 == 0 ) /*0x102cf1285*/
                    return 68; /*0x102cf1291*/
                }
                else if ( v137 == 105 ) /*0x102cf0f28*/
                {
                  v138 = *(unsigned __int8 *)(a1 + 14) - 110; /*0x102cf0f32*/
                  if ( *(_BYTE *)(a1 + 14) == 110 ) /*0x102cf0f35*/
                    v138 = *(unsigned __int8 *)(a1 + 15); /*0x102cf0f37*/
                  if ( v138 == 0 ) /*0x102cf0f3f*/
                    return 67; /*0x102cf0f4b*/
                }
                return 0xFFFFFFFFLL; /*0x102cf0f3f*/
              case 2: /*0x102cf05bc*/
                if ( strcmp(__s1: "nterleave", __s2: (const char *)(a1 + 11)) != 0 ) /*0x102cf0ea6*/
                  return 0xFFFFFFFFLL; /*0x102cf0ea6*/
                return 69; /*0x102cf0eb2*/
              case 3: /*0x102cf05bc*/
                if ( *(_BYTE *)(a1 + 11) != 97 || *(_BYTE *)(a1 + 12) != 120 ) /*0x102cf0ec1*/
                  return 0xFFFFFFFFLL; /*0x102cf0ec1*/
                v136 = *(unsigned __int8 *)(a1 + 13); /*0x102cf0ec7*/
                if ( v136 != 115 ) /*0x102cf0ece*/
                {
                  if ( v136 == 98 && strcmp(__s1: "ufsz", __s2: (const char *)(a1 + 14)) == 0 ) /*0x102cf0eef*/
                    return 70; /*0x102cf0efb*/
                  return 0xFFFFFFFFLL; /*0x102cf0eef*/
                }
                if ( strcmp(__s1: "ndfrag", __s2: (const char *)(a1 + 14)) != 0 ) /*0x102cf125e*/
                  return 0xFFFFFFFFLL; /*0x102cf125e*/
                result = 71; /*0x102cf1264*/
                break; /*0x102cf126a*/
              default:
                return 0xFFFFFFFFLL;
            }
          }
          else if ( v101 == 51 ) /*0x102cef9b5*/
          {
            if ( *(_BYTE *)(a1 + 5) != 45 /*0x102cf052e*/
              || *(_BYTE *)(a1 + 6) != 107
              || *(_BYTE *)(a1 + 7) != 100
              || *(_BYTE *)(a1 + 8) != 102
              || *(_BYTE *)(a1 + 9) != 45 )
            {
              return 0xFFFFFFFFLL; /*0x102cf052e*/
            }
            v122 = *(unsigned __int8 *)(a1 + 10); /*0x102cf0534*/
            if ( v122 != 107 ) /*0x102cf053b*/
            {
              if ( v122 == 100 && strcmp(__s1: "igest-check", __s2: (const char *)(a1 + 11)) == 0 ) /*0x102cf055c*/
                return 313; /*0x102cf0568*/
              return 0xFFFFFFFFLL; /*0x102cf055c*/
            }
            if ( strcmp(__s1: "ey-check", __s2: (const char *)(a1 + 11)) != 0 ) /*0x102cf0d8b*/
              return 0xFFFFFFFFLL; /*0x102cf0d8b*/
            result = 314; /*0x102cf0d91*/
          }
          else
          {
            if ( v101 != 45 /*0x102cef9e6*/
              || *(_BYTE *)(a1 + 5) != 112
              || *(_BYTE *)(a1 + 6) != 114
              || *(_BYTE *)(a1 + 7) != 102
              || *(_BYTE *)(a1 + 8) != 45 )
            {
              return 0xFFFFFFFFLL; /*0x102cef9e6*/
            }
            v102 = *(unsigned __int8 *)(a1 + 9); /*0x102cef9ec*/
            if ( v102 == 107 ) /*0x102cef9f3*/
            {
              if ( strcmp(__s1: "ey-check", __s2: (const char *)(a1 + 10)) != 0 ) /*0x102cf0d5e*/
                return 0xFFFFFFFFLL; /*0x102cf0d5e*/
              result = 317; /*0x102cf0d64*/
            }
            else
            {
              if ( v102 != 101 ) /*0x102cef9fc*/
              {
                if ( v102 == 100 && strcmp(__s1: "igest-check", __s2: (const char *)(a1 + 10)) == 0 ) /*0x102cefa1d*/
                  return 315; /*0x102cefa29*/
                return 0xFFFFFFFFLL; /*0x102cefa1d*/
              }
              if ( strcmp(__s1: "ms-check", __s2: (const char *)(a1 + 10)) != 0 ) /*0x102cf0d3f*/
                return 0xFFFFFFFFLL; /*0x102cf0d3f*/
              result = 316; /*0x102cf0d45*/
            }
          }
          break; /*0x102cf0d4b*/
        case 'p': /*0x102cedb0a*/
          if ( *(_BYTE *)(a1 + 2) != 0 ) /*0x102ceebba*/
            return 0xFFFFFFFFLL; /*0x102ceebba*/
          return 189; /*0x102ceebc6*/
        case 'y': /*0x102cedb0a*/
          v62 = *(unsigned __int8 *)(a1 + 2) - 112; /*0x102ceec28*/
          if ( *(_BYTE *)(a1 + 2) == 112 ) /*0x102ceec2b*/
          {
            v62 = *(unsigned __int8 *)(a1 + 3) - 101; /*0x102ceec31*/
            if ( *(_BYTE *)(a1 + 3) == 101 ) /*0x102ceec34*/
              v62 = *(unsigned __int8 *)(a1 + 4); /*0x102ceec36*/
          }
          if ( v62 != 0 ) /*0x102ceec3e*/
            return 0xFFFFFFFFLL; /*0x102ceec3e*/
          return 142; /*0x102ceec4a*/
        default:
          return 0xFFFFFFFFLL;
      }
      return result; /*0x102cf0d4b*/
    case 'u': /*0x102ced7f4*/
      v24 = *(unsigned __int8 *)(a1 + 1); /*0x102cedebc*/
      if ( v24 != 115 ) /*0x102cedec3*/
      {
        if ( v24 != 112 ) /*0x102cedecc*/
        {
          if ( v24 == 107 ) /*0x102ceded5*/
          {
            v25 = *(unsigned __int8 *)(a1 + 2) - 109; /*0x102cededf*/
            if ( *(_BYTE *)(a1 + 2) == 109 ) /*0x102cedee2*/
              v25 = *(unsigned __int8 *)(a1 + 3); /*0x102cedee4*/
            if ( v25 == 0 ) /*0x102cedeec*/
              return 145; /*0x102cedef8*/
          }
          return 0xFFFFFFFFLL; /*0x102cedeec*/
        }
        if ( strcmp(__s1: "dated-iv", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee0c2*/
          return 0xFFFFFFFFLL; /*0x102cee0c2*/
        return 75; /*0x102cee0ce*/
      }
      if ( *(_BYTE *)(a1 + 2) != 101 ) /*0x102cee0d3*/
        return 0xFFFFFFFFLL; /*0x102cee0d3*/
      v30 = *(unsigned __int8 *)(a1 + 3); /*0x102cee0d9*/
      if ( v30 != 95 ) /*0x102cee0e0*/
      {
        if ( v30 != 45 ) /*0x102cee0e9*/
          return 0xFFFFFFFFLL; /*0x102cee0e9*/
        switch ( *(_BYTE *)(a1 + 4) ) /*0x102cee10d*/
        {
          case 'b': /*0x102cee10d*/
            if ( strcmp(__s1: "its", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cee121*/
              return 0xFFFFFFFFLL; /*0x102cee121*/
            result = 76; /*0x102cee127*/
            break; /*0x102cee12d*/
          case 'c': /*0x102cee10d*/
            if ( strcmp(__s1: "ofactor-flag", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf017d*/
              return 0xFFFFFFFFLL; /*0x102cf017d*/
            result = 283; /*0x102cf0183*/
            break; /*0x102cf0189*/
          case 'k': /*0x102cee10d*/
            if ( strcmp(__s1: "eybits", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf015e*/
              return 0xFFFFFFFFLL; /*0x102cf015e*/
            result = 151; /*0x102cf0164*/
            break; /*0x102cf016a*/
          case 'l': /*0x102cee10d*/
            if ( *(_BYTE *)(a1 + 5) != 0 ) /*0x102cf018e*/
              return 0xFFFFFFFFLL; /*0x102cf018e*/
            result = 126; /*0x102cf0194*/
            break; /*0x102cf019a*/
          case 's': /*0x102cee10d*/
            if ( strcmp(__s1: "eparator", __s2: (const char *)(a1 + 5)) != 0 ) /*0x102cf01ad*/
              return 0xFFFFFFFFLL; /*0x102cf01ad*/
            result = 127; /*0x102cf01b3*/
            break; /*0x102cf01b9*/
          default:
            return 0xFFFFFFFFLL;
        }
        return result; /*0x102cf01b9*/
      }
      v90 = *(unsigned __int8 *)(a1 + 4); /*0x102cef546*/
      if ( v90 == 101 ) /*0x102cef54d*/
      {
        v111 = *(unsigned __int8 *)(a1 + 5) - 116; /*0x102cefd60*/
        if ( *(_BYTE *)(a1 + 5) == 116 ) /*0x102cefd63*/
        {
          v111 = *(unsigned __int8 *)(a1 + 6) - 109; /*0x102cefd69*/
          if ( *(_BYTE *)(a1 + 6) == 109 ) /*0x102cefd6c*/
            v111 = *(unsigned __int8 *)(a1 + 7); /*0x102cefd6e*/
        }
        if ( v111 == 0 ) /*0x102cefd76*/
          return 162; /*0x102cefd82*/
      }
      else if ( v90 == 100 && strcmp(__s1: "erivation_function", __s2: (const char *)(a1 + 5)) == 0 ) /*0x102cef56e*/
      {
        return 100; /*0x102cef57a*/
      }
      return 0xFFFFFFFFLL; /*0x102cef56e*/
    case 'v': /*0x102ced7f4*/
      v4 = *(unsigned __int8 *)(a1 + 1); /*0x102ced893*/
      if ( v4 == 101 ) /*0x102ced89a*/
      {
        if ( *(_BYTE *)(a1 + 2) == 114 ) /*0x102cedfbd*/
        {
          v27 = *(unsigned __int8 *)(a1 + 3); /*0x102cedfc3*/
          if ( v27 != 115 ) /*0x102cedfca*/
          {
            if ( v27 == 105 && strcmp(__s1: "fy-message", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102cedfeb*/
              return 331; /*0x102cedff7*/
            return 0xFFFFFFFFLL; /*0x102cedfeb*/
          }
          if ( strcmp(__s1: "ion", __s2: (const char *)(a1 + 4)) == 0 ) /*0x102cef3a7*/
            return 115; /*0x102cef3b3*/
        }
        return 0xFFFFFFFFLL; /*0x102cef3a7*/
      }
      if ( v4 != 97 /*0x102ced8e9*/
        || *(_BYTE *)(a1 + 2) != 108
        || *(_BYTE *)(a1 + 3) != 105
        || *(_BYTE *)(a1 + 4) != 100
        || *(_BYTE *)(a1 + 5) != 97
        || *(_BYTE *)(a1 + 6) != 116
        || *(_BYTE *)(a1 + 7) != 101
        || *(_BYTE *)(a1 + 8) != 45 )
      {
        return 0xFFFFFFFFLL; /*0x102ced8e9*/
      }
      v5 = *(unsigned __int8 *)(a1 + 9); /*0x102ced8ef*/
      if ( v5 != 112 ) /*0x102ced8f6*/
      {
        if ( v5 != 108 ) /*0x102ced8ff*/
        {
          if ( v5 == 103 && *(_BYTE *)(a1 + 10) == 0 ) /*0x102ced912*/
            return 211; /*0x102ced91e*/
          return 0xFFFFFFFFLL; /*0x102ced912*/
        }
        if ( strcmp(__s1: "egacy", __s2: (const char *)(a1 + 10)) == 0 ) /*0x102cf0a5d*/
          return 212; /*0x102cf0a69*/
        return 0xFFFFFFFFLL; /*0x102ceecf9*/
      }
      v131 = *(unsigned __int8 *)(a1 + 10) - 113; /*0x102cf0a6e*/
      if ( *(_BYTE *)(a1 + 10) == 113 ) /*0x102cf0a71*/
        v131 = *(unsigned __int8 *)(a1 + 11); /*0x102cf0a73*/
      if ( v131 != 0 ) /*0x102cf0a7b*/
        return 0xFFFFFFFFLL; /*0x102cf0a7b*/
      return 213; /*0x102ced833*/
    case 'x': /*0x102ced7f4*/
      switch ( *(_BYTE *)(a1 + 1) ) /*0x102ceda31*/
      {
        case '9': /*0x102ceda31*/
          v8 = *(unsigned __int8 *)(a1 + 2); /*0x102ceda33*/
          if ( v8 != 54 ) /*0x102ceda3a*/
          {
            if ( v8 == 52 && strcmp(__s1: "2kdf-key-check", __s2: (const char *)(a1 + 3)) == 0 ) /*0x102ceda5b*/
              return 318; /*0x102ceda67*/
            return 0xFFFFFFFFLL; /*0x102ceda5b*/
          }
          if ( *(_BYTE *)(a1 + 3) != 51 /*0x102cef415*/
            || *(_BYTE *)(a1 + 4) != 107
            || *(_BYTE *)(a1 + 5) != 100
            || *(_BYTE *)(a1 + 6) != 102
            || *(_BYTE *)(a1 + 7) != 45 )
          {
            return 0xFFFFFFFFLL; /*0x102cef415*/
          }
          v86 = *(unsigned __int8 *)(a1 + 8); /*0x102cef41b*/
          if ( v86 != 107 ) /*0x102cef422*/
          {
            if ( v86 == 100 && strcmp(__s1: "igest-check", __s2: (const char *)(a1 + 9)) == 0 ) /*0x102cef443*/
              return 319; /*0x102cef44f*/
            return 0xFFFFFFFFLL; /*0x102cef443*/
          }
          if ( strcmp(__s1: "ey-check", __s2: (const char *)(a1 + 9)) != 0 ) /*0x102cf0ab9*/
            return 0xFFFFFFFFLL; /*0x102cf0ab9*/
          return 320; /*0x102cf0ac5*/
        case 'c': /*0x102ceda31*/
          if ( strcmp(__s1: "ghash", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee804*/
            return 0xFFFFFFFFLL; /*0x102cee804*/
          return 143; /*0x102cee810*/
        case 'o': /*0x102ceda31*/
          if ( *(_BYTE *)(a1 + 2) != 102 ) /*0x102cee791*/
            return 0xFFFFFFFFLL; /*0x102cee791*/
          if ( *(_BYTE *)(a1 + 3) == 0 ) /*0x102cee79d*/
            return 83; /*0x102cefa93*/
          if ( *(_BYTE *)(a1 + 3) == 108 ) /*0x102cee7a6*/
          {
            v47 = *(unsigned __int8 *)(a1 + 4) - 101; /*0x102cee7b0*/
            if ( *(_BYTE *)(a1 + 4) == 101 ) /*0x102cee7b3*/
            {
              v47 = *(unsigned __int8 *)(a1 + 5) - 110; /*0x102cee7b9*/
              if ( *(_BYTE *)(a1 + 5) == 110 ) /*0x102cee7bc*/
                v47 = *(unsigned __int8 *)(a1 + 6); /*0x102cee7be*/
            }
            if ( v47 == 0 ) /*0x102cee7c6*/
              return 84; /*0x102cee7d2*/
          }
          return 0xFFFFFFFFLL; /*0x102cee7c6*/
        case 'p': /*0x102ceda31*/
          v48 = *(unsigned __int8 *)(a1 + 2); /*0x102cee811*/
          if ( *(_BYTE *)(a1 + 2) == 0 ) /*0x102cee817*/
            return 276; /*0x102cef6a7*/
          if ( v48 != 50 ) /*0x102cee820*/
          {
            if ( v48 == 49 && *(_BYTE *)(a1 + 3) == 0 ) /*0x102cee833*/
              return 277; /*0x102cee83f*/
            return 0xFFFFFFFFLL; /*0x102cee833*/
          }
          if ( *(_BYTE *)(a1 + 3) != 0 ) /*0x102cef683*/
            return 0xFFFFFFFFLL; /*0x102cef683*/
          return 278; /*0x102cef68f*/
        case 'q': /*0x102ceda31*/
          v49 = *(unsigned __int8 *)(a1 + 2); /*0x102cee840*/
          if ( *(_BYTE *)(a1 + 2) == 0 ) /*0x102cee846*/
            return 279; /*0x102cef6ae*/
          if ( v49 != 50 ) /*0x102cee84f*/
          {
            if ( v49 == 49 && *(_BYTE *)(a1 + 3) == 0 ) /*0x102cee862*/
              return 280; /*0x102cee86e*/
            return 0xFFFFFFFFLL; /*0x102cee862*/
          }
          if ( *(_BYTE *)(a1 + 3) != 0 ) /*0x102cef694*/
            return 0xFFFFFFFFLL; /*0x102cef694*/
          result = 281; /*0x102cef69a*/
          break; /*0x102cef6a0*/
        case 't': /*0x102ceda31*/
          if ( strcmp(__s1: "s_standard", __s2: (const char *)(a1 + 2)) != 0 ) /*0x102cee7e5*/
            return 0xFFFFFFFFLL; /*0x102cee7e5*/
          return 77; /*0x102cee7f1*/
        default:
          return 0xFFFFFFFFLL;
      }
      return result; /*0x102cef6a0*/
    default:
      return 0xFFFFFFFFLL;
  }
}

// Address: 0x102cf2090 | Name: _ossl_pw_clear_passphrase_data
void __fastcall ossl_pw_clear_passphrase_data(__int64 a1)
{
  if ( a1 != 0 ) /*0x102cf2093*/
  {
    if ( *(_DWORD *)a1 == 1 ) /*0x102cf20a1*/
      CRYPTO_clear_free(a1: *(void **)(a1 + 8), a2: *(_QWORD *)(a1 + 16)); /*0x102cf20b7*/
    CRYPTO_clear_free(a1: *(void **)(a1 + 32), a2: *(_QWORD *)(a1 + 40)); /*0x102cf20d0*/
    *(_OWORD *)(a1 + 32) = 0; /*0x102cf20d8*/
    *(_OWORD *)(a1 + 16) = 0; /*0x102cf20dc*/
    *(_OWORD *)a1 = 0; /*0x102cf20e0*/
  }
}

// Address: 0x102cf20f0 | Name: _ossl_pw_clear_passphrase_cache
void __fastcall ossl_pw_clear_passphrase_cache(__int64 a1)
{
  CRYPTO_clear_free(a1: *(void **)(a1 + 32), a2: *(_QWORD *)(a1 + 40)); /*0x102cf210d*/
  *(_QWORD *)(a1 + 32) = 0; /*0x102cf2112*/
}

// Address: 0x102cf2130 | Name: _ossl_pw_set_passphrase
__int64 __fastcall ossl_pw_set_passphrase(__int64 a1, void *a2, size_t a3)
{
  void *v6; // rax
  void *v7; // rax

  if ( a1 != 0 && a2 != nullptr ) /*0x102cf2149*/
  {
    if ( *(_DWORD *)a1 == 1 ) /*0x102cf2158*/
      CRYPTO_clear_free(a1: *(void **)(a1 + 8), a2: *(_QWORD *)(a1 + 16)); /*0x102cf216e*/
    CRYPTO_clear_free(a1: *(void **)(a1 + 32), a2: *(_QWORD *)(a1 + 40)); /*0x102cf2187*/
    *(_OWORD *)a1 = 0; /*0x102cf218f*/
    *(_OWORD *)(a1 + 32) = 0; /*0x102cf2193*/
    *(_OWORD *)(a1 + 16) = 0; /*0x102cf2198*/
    *(_DWORD *)a1 = 1; /*0x102cf219d*/
    if ( a3 != 0 ) /*0x102cf21a7*/
    {
      v6 = CRYPTO_memdup(__src: a2, __n: a3, file: "crypto/passphrase.c", line: 44); /*0x102cf21bb*/
      *(_QWORD *)(a1 + 8) = v6; /*0x102cf21c0*/
      if ( v6 == nullptr ) /*0x102cf21c7*/
        return 0; /*0x102cf21c7*/
LABEL_9:
      *(_QWORD *)(a1 + 16) = a3; /*0x102cf21ea*/
      return 1; /*0x102cf21f3*/
    }
    v7 = CRYPTO_malloc(num: 1, file: "crypto/passphrase.c", line: 45); /*0x102cf21dc*/
    *(_QWORD *)(a1 + 8) = v7; /*0x102cf21e1*/
    if ( v7 != nullptr ) /*0x102cf21e8*/
      goto LABEL_9; /*0x102cf21e8*/
  }
  else
  {
    ossl_pw_set_passphrase_cold_1(a1); /*0x102cf21f5*/
  }
  return 0; /*0x102cf2200*/
}

// Address: 0x102cf2210 | Name: _ossl_pw_set_pem_password_cb
__int64 __fastcall ossl_pw_set_pem_password_cb(__int64 a1, __int64 a2, __int64 a3)
{
  if ( a1 != 0 && a2 != 0 ) /*0x102cf2225*/
  {
    if ( *(_DWORD *)a1 == 1 ) /*0x102cf2230*/
      CRYPTO_clear_free(a1: *(void **)(a1 + 8), a2: *(_QWORD *)(a1 + 16)); /*0x102cf2246*/
    CRYPTO_clear_free(a1: *(void **)(a1 + 32), a2: *(_QWORD *)(a1 + 40)); /*0x102cf225f*/
    *(_OWORD *)a1 = 0; /*0x102cf2267*/
    *(_OWORD *)(a1 + 16) = 0; /*0x102cf226b*/
    *(_OWORD *)(a1 + 32) = 0; /*0x102cf2270*/
    *(_DWORD *)a1 = 2; /*0x102cf2275*/
    *(_QWORD *)(a1 + 8) = a2; /*0x102cf227c*/
    *(_QWORD *)(a1 + 16) = a3; /*0x102cf2280*/
    return 1; /*0x102cf2284*/
  }
  else
  {
    ossl_pw_set_pem_password_cb_cold_1(a1); /*0x102cf2294*/
    return 0; /*0x102cf2299*/
  }
}

// Address: 0x102cf22a0 | Name: _ossl_pw_set_ossl_passphrase_cb
__int64 __fastcall ossl_pw_set_ossl_passphrase_cb(__int64 a1, __int64 a2, __int64 a3)
{
  if ( a1 != 0 && a2 != 0 ) /*0x102cf22b5*/
  {
    if ( *(_DWORD *)a1 == 1 ) /*0x102cf22c0*/
      CRYPTO_clear_free(a1: *(void **)(a1 + 8), a2: *(_QWORD *)(a1 + 16)); /*0x102cf22d6*/
    CRYPTO_clear_free(a1: *(void **)(a1 + 32), a2: *(_QWORD *)(a1 + 40)); /*0x102cf22ef*/
    *(_OWORD *)a1 = 0; /*0x102cf22f7*/
    *(_OWORD *)(a1 + 16) = 0; /*0x102cf22fb*/
    *(_OWORD *)(a1 + 32) = 0; /*0x102cf2300*/
    *(_DWORD *)a1 = 3; /*0x102cf2305*/
    *(_QWORD *)(a1 + 8) = a2; /*0x102cf230c*/
    *(_QWORD *)(a1 + 16) = a3; /*0x102cf2310*/
    return 1; /*0x102cf2314*/
  }
  else
  {
    ossl_pw_set_ossl_passphrase_cb_cold_1(a1); /*0x102cf2324*/
    return 0; /*0x102cf2329*/
  }
}

// Address: 0x102cf2330 | Name: _ossl_pw_set_ui_method
__int64 __fastcall ossl_pw_set_ui_method(__int64 a1, __int64 a2, __int64 a3)
{
  if ( a1 != 0 && a2 != 0 ) /*0x102cf2345*/
  {
    if ( *(_DWORD *)a1 == 1 ) /*0x102cf2350*/
      CRYPTO_clear_free(a1: *(void **)(a1 + 8), a2: *(_QWORD *)(a1 + 16)); /*0x102cf2366*/
    CRYPTO_clear_free(a1: *(void **)(a1 + 32), a2: *(_QWORD *)(a1 + 40)); /*0x102cf237f*/
    *(_OWORD *)a1 = 0; /*0x102cf2387*/
    *(_OWORD *)(a1 + 16) = 0; /*0x102cf238b*/
    *(_OWORD *)(a1 + 32) = 0; /*0x102cf2390*/
    *(_DWORD *)a1 = 4; /*0x102cf2395*/
    *(_QWORD *)(a1 + 8) = a2; /*0x102cf239c*/
    *(_QWORD *)(a1 + 16) = a3; /*0x102cf23a0*/
    return 1; /*0x102cf23a4*/
  }
  else
  {
    ossl_pw_set_ui_method_cold_1(a1); /*0x102cf23b4*/
    return 0; /*0x102cf23b9*/
  }
}

// Address: 0x102cf23c0 | Name: _ossl_pw_enable_passphrase_caching
__int64 __fastcall ossl_pw_enable_passphrase_caching(__int64 a1)
{
  *(_BYTE *)(a1 + 24) |= 1u; /*0x102cf23c4*/
  return 1; /*0x102cf23cd*/
}

// Address: 0x102cf23d0 | Name: _ossl_pw_disable_passphrase_caching
__int64 __fastcall ossl_pw_disable_passphrase_caching(__int64 a1)
{
  *(_BYTE *)(a1 + 24) &= ~1u; /*0x102cf23d4*/
  return 1; /*0x102cf23dd*/
}

// Address: 0x102cf23e0 | Name: _ossl_pw_get_passphrase
__int64 __fastcall ossl_pw_get_passphrase(void *a1, size_t a2, size_t *a3, const char **a4, unsigned int a5, int *a6)
{
  size_t *v8; // rbx
  const void *v10; // rsi
  size_t *v11; // r14
  unsigned int v12; // r12d
  const char **v13; // rax
  char *v14; // rcx
  int v15; // eax
  const UI_METHOD *v16; // r12
  __int64 pem_callback; // rax
  UI *v18; // rax
  UI *v19; // rbx
  char *v20; // rax
  const char *v21; // rbx
  char *v22; // rax
  int v23; // eax
  char *v24; // rax
  size_t *v25; // rbx
  char *v26; // r13
  size_t v27; // r15
  const char *v28; // rdx
  char *v29; // rdi
  int v30; // eax
  __int64 v31; // rsi
  int v32; // esi
  int result_length; // eax
  char *v34; // rdi
  size_t v35; // rdx
  size_t v36; // rsi
  char *v37; // rax
  UI_METHOD *ui_method; // [rsp+10h] [rbp-70h]
  int v40; // [rsp+1Ch] [rbp-64h]
  size_t *v41; // [rsp+20h] [rbp-60h]
  char *test_buf; // [rsp+28h] [rbp-58h]
  void *__dst; // [rsp+30h] [rbp-50h]
  char *object_name; // [rsp+38h] [rbp-48h]
  char *object_namea; // [rsp+38h] [rbp-48h]
  char *v46; // [rsp+40h] [rbp-40h]
  void *user_data; // [rsp+48h] [rbp-38h]
  UI *user_dataa; // [rsp+48h] [rbp-38h]

  v8 = a3; /*0x102cf23f7*/
  if ( *a6 != 1 ) /*0x102cf2403*/
  {
    if ( (a6[6] & 1) != 0 ) /*0x102cf2419*/
    {
      v10 = *((const void **)a6 + 4); /*0x102cf241b*/
      if ( v10 != nullptr ) /*0x102cf2422*/
      {
        v11 = (size_t *)(a6 + 10); /*0x102cf2424*/
        goto LABEL_7; /*0x102cf2424*/
      }
    }
    if ( *a6 == 3 ) /*0x102cf244b*/
    {
      __dst = a1; /*0x102cf2451*/
      v12 = (*((__int64 (__fastcall **)(void *, size_t, size_t *, const char **, _QWORD))a6 + 1))( /*0x102cf245f*/
              a1,
              a2,
              a3,
              a4,
              a5: *((_QWORD *)a6 + 2));
      if ( v12 == 0 ) /*0x102cf2465*/
        return 0; /*0x102cf2465*/
LABEL_56:
      if ( (a6[6] & 1) == 0 ) /*0x102cf28d5*/
        return v12; /*0x102cf28d5*/
      v34 = *((char **)a6 + 4); /*0x102cf28d7*/
      if ( v34 != nullptr ) /*0x102cf28de*/
      {
        v35 = *v8; /*0x102cf28e0*/
        v36 = *((_QWORD *)a6 + 5); /*0x102cf28e3*/
        if ( *v8 <= v36 ) /*0x102cf28ea*/
          goto LABEL_63; /*0x102cf28ea*/
      }
      else
      {
        v36 = *((_QWORD *)a6 + 5); /*0x102cf28ee*/
        v35 = *v8; /*0x102cf28f2*/
      }
      v37 = (char *)CRYPTO_clear_realloc(__src: v34, __n: v36, __size: v35 + 1, __s: "crypto/passphrase.c", line: 292); /*0x102cf2905*/
      if ( v37 != nullptr ) /*0x102cf290d*/
      {
        v34 = v37; /*0x102cf290f*/
        *((_QWORD *)a6 + 4) = v37; /*0x102cf2912*/
        v35 = *v8; /*0x102cf2916*/
LABEL_63:
        memcpy(__dst: v34, __src: __dst, __n: v35); /*0x102cf2919*/
        *(_BYTE *)(*((_QWORD *)a6 + 4) + *v8) = 0; /*0x102cf2929*/
        *((_QWORD *)a6 + 5) = *v8; /*0x102cf2930*/
        return v12; /*0x102cf2934*/
      }
      OPENSSL_cleanse(ptr: __dst, len: *v8); /*0x102cf293d*/
      return 0; /*0x102cf2942*/
    }
LABEL_13:
    __dst = a1; /*0x102cf2470*/
    v13 = OSSL_PARAM_locate_const(a1: a4, a2: "info"); /*0x102cf247e*/
    if ( v13 != nullptr ) /*0x102cf2486*/
    {
      if ( *((_DWORD *)v13 + 2) != 4 ) /*0x102cf248c*/
      {
        ERR_new(); /*0x102cf2670*/
        ERR_set_debug(__s: "crypto/passphrase.c", a2: 250, a3: "ossl_pw_get_passphrase"); /*0x102cf2688*/
        v28 = "Prompt info data type incorrect"; /*0x102cf268d*/
        goto LABEL_36; /*0x102cf268d*/
      }
      v14 = (char *)v13[2]; /*0x102cf2492*/
      v15 = *a6; /*0x102cf2496*/
      if ( *a6 == 4 ) /*0x102cf249c*/
        goto LABEL_16; /*0x102cf249c*/
    }
    else
    {
      v14 = nullptr; /*0x102cf24b3*/
      v15 = *a6; /*0x102cf24b5*/
      if ( *a6 == 4 ) /*0x102cf24bb*/
      {
LABEL_16:
        v16 = *((const UI_METHOD **)a6 + 1); /*0x102cf249e*/
        if ( v16 != nullptr ) /*0x102cf24a5*/
        {
          object_name = v14; /*0x102cf24ab*/
          pem_callback = 0; /*0x102cf24af*/
          goto LABEL_21; /*0x102cf24b1*/
        }
LABEL_34:
        ERR_new(); /*0x102cf264a*/
        ERR_set_debug(__s: "crypto/passphrase.c", a2: 275, a3: "ossl_pw_get_passphrase"); /*0x102cf2662*/
        v28 = "No password method specified"; /*0x102cf2667*/
LABEL_36:
        v12 = 0; /*0x102cf2694*/
        ERR_set_error(a1: 15, a2: 524550, a3: (__int64)v28); /*0x102cf26a3*/
        return v12; /*0x102cf26a8*/
      }
    }
    if ( v15 == 2 ) /*0x102cf24c0*/
    {
      object_name = v14; /*0x102cf24c6*/
      pem_callback = UI_UTIL_wrap_read_pem_callback(a1: *((_QWORD *)a6 + 1), a2: a5); /*0x102cf24d1*/
      v16 = (const UI_METHOD *)pem_callback; /*0x102cf24d6*/
      if ( pem_callback == 0 ) /*0x102cf24dc*/
      {
        ERR_new(); /*0x102cf26e5*/
        ERR_set_debug(__s: "crypto/passphrase.c", a2: 266, a3: "ossl_pw_get_passphrase"); /*0x102cf26fd*/
        v12 = 0; /*0x102cf2702*/
        ERR_set_error(a1: 15, a2: 524328, a3: 0); /*0x102cf2711*/
        return v12; /*0x102cf2711*/
      }
LABEL_21:
      ui_method = (UI_METHOD *)pem_callback; /*0x102cf24e2*/
      v41 = v8; /*0x102cf24eb*/
      if ( __dst == nullptr || a2 == 0 || v8 == nullptr ) /*0x102cf2501*/
      {
        ossl_pw_get_passphrase_cold_1(); /*0x102cf2957*/
        v12 = 0; /*0x102cf295c*/
LABEL_55:
        UI_destroy_method(ui_method); /*0x102cf28be*/
        v8 = v41; /*0x102cf28c7*/
        if ( v12 == 0 ) /*0x102cf28ce*/
          return 0; /*0x102cf28ce*/
        goto LABEL_56; /*0x102cf28ce*/
      }
      user_data = *((void **)a6 + 2); /*0x102cf250b*/
      v18 = UI_new(); /*0x102cf250f*/
      if ( v18 == nullptr ) /*0x102cf2517*/
      {
        ERR_new(); /*0x102cf26ad*/
        ERR_set_debug(__s: "crypto/passphrase.c", a2: 131, a3: "do_ui_passphrase"); /*0x102cf26c5*/
        v12 = 0; /*0x102cf26ca*/
        ERR_set_error(a1: 15, a2: 524328, a3: 0); /*0x102cf26db*/
        goto LABEL_55; /*0x102cf26e0*/
      }
      v19 = v18; /*0x102cf251d*/
      UI_set_method(ui: v18, meth: v16); /*0x102cf2526*/
      if ( user_data != nullptr ) /*0x102cf2532*/
        UI_add_user_data(ui: v19, user_data); /*0x102cf2537*/
      user_dataa = v19; /*0x102cf2543*/
      v20 = UI_construct_prompt(ui_method: v19, object_desc: "pass phrase", object_name); /*0x102cf254e*/
      object_namea = v20; /*0x102cf2556*/
      if ( v20 != nullptr ) /*0x102cf255a*/
      {
        v21 = v20; /*0x102cf2560*/
        v22 = (char *)CRYPTO_zalloc(__size: a2 + 1, __s: "crypto/passphrase.c", line: 149); /*0x102cf2577*/
        if ( v22 != nullptr ) /*0x102cf257f*/
        {
          v12 = 0; /*0x102cf2585*/
          test_buf = v22; /*0x102cf2594*/
          v23 = UI_add_input_string(ui: user_dataa, prompt: v21, flags: 2, result_buf: v22, minsize: 0, maxsize: a2); /*0x102cf25a1*/
          if ( v23 <= 0 ) /*0x102cf25a8*/
          {
            ERR_new(); /*0x102cf2764*/
            ERR_set_debug(__s: "crypto/passphrase.c", a2: 157, a3: "do_ui_passphrase"); /*0x102cf277c*/
            ERR_set_error(a1: 15, a2: 524328, a3: 0); /*0x102cf278f*/
            v29 = nullptr; /*0x102cf2794*/
            v26 = test_buf; /*0x102cf2796*/
            v27 = a2 + 1; /*0x102cf279a*/
          }
          else
          {
            v12 = 0; /*0x102cf25ae*/
            v40 = v23; /*0x102cf25b4*/
            if ( a5 == 0 ) /*0x102cf25b7*/
            {
              v46 = nullptr; /*0x102cf27a3*/
              v25 = v41; /*0x102cf27ab*/
              v26 = test_buf; /*0x102cf27af*/
              goto LABEL_43; /*0x102cf27af*/
            }
            v24 = (char *)CRYPTO_zalloc(__size: a2 + 1, __s: "crypto/passphrase.c", line: 163); /*0x102cf25cd*/
            v25 = v41; /*0x102cf25d5*/
            v26 = test_buf; /*0x102cf25d9*/
            if ( v24 != nullptr ) /*0x102cf25dd*/
            {
              v12 = 0; /*0x102cf25e7*/
              v46 = v24; /*0x102cf25fa*/
              if ( UI_add_verify_string( /*0x102cf260b*/
                     ui: user_dataa,
                     prompt: object_namea,
                     flags: 2,
                     result_buf: v24,
                     minsize: 0,
                     maxsize: a2,
                     test_buf) <= 0 )
              {
                ERR_new(); /*0x102cf2611*/
                ERR_set_debug(__s: "crypto/passphrase.c", a2: 171, a3: "do_ui_passphrase"); /*0x102cf2629*/
                ERR_set_error(a1: 15, a2: 524328, a3: 0); /*0x102cf263c*/
                v27 = a2 + 1; /*0x102cf2641*/
LABEL_53:
                v29 = v46; /*0x102cf2876*/
                goto LABEL_54; /*0x102cf2876*/
              }
LABEL_43:
              v27 = a2 + 1; /*0x102cf27b3*/
              v30 = UI_process(ui: user_dataa); /*0x102cf27bb*/
              if ( v30 == -1 ) /*0x102cf27c3*/
              {
                ERR_new(); /*0x102cf27fe*/
                v32 = 181; /*0x102cf2811*/
              }
              else
              {
                if ( v30 == -2 ) /*0x102cf27c8*/
                {
                  ERR_new(); /*0x102cf27ca*/
                  ERR_set_debug(__s: "crypto/passphrase.c", a2: 178, a3: "do_ui_passphrase"); /*0x102cf27e2*/
                  v12 = 0; /*0x102cf27e7*/
                  v31 = 524553; /*0x102cf27ef*/
LABEL_52:
                  ERR_set_error(a1: 15, a2: v31, a3: 0); /*0x102cf286d*/
                  goto LABEL_53; /*0x102cf2871*/
                }
                result_length = UI_get_result_length(a1: user_dataa, a2: (unsigned int)(v40 - 1)); /*0x102cf2821*/
                if ( result_length >= 0 ) /*0x102cf2828*/
                {
                  *v25 = (unsigned int)result_length; /*0x102cf282c*/
                  memcpy(__dst, __src: v26, __n: (unsigned int)result_length); /*0x102cf2836*/
                  v12 = 1; /*0x102cf283b*/
                  goto LABEL_53; /*0x102cf2841*/
                }
                ERR_new(); /*0x102cf2843*/
                v32 = 186; /*0x102cf2856*/
              }
              ERR_set_debug(__s: "crypto/passphrase.c", a2: v32, a3: "do_ui_passphrase"); /*0x102cf285b*/
              v12 = 0; /*0x102cf2860*/
              v31 = 524328; /*0x102cf2868*/
              goto LABEL_52; /*0x102cf2868*/
            }
            v29 = nullptr; /*0x102cf27f6*/
            v27 = a2 + 1; /*0x102cf27f8*/
          }
        }
        else
        {
          v26 = nullptr; /*0x102cf2753*/
          v29 = nullptr; /*0x102cf2756*/
          v12 = 0; /*0x102cf2758*/
          v27 = a2 + 1; /*0x102cf275b*/
        }
      }
      else
      {
        ERR_new(); /*0x102cf2713*/
        ERR_set_debug(__s: "crypto/passphrase.c", a2: 144, a3: "do_ui_passphrase"); /*0x102cf272b*/
        v26 = nullptr; /*0x102cf2730*/
        ERR_set_error(a1: 15, a2: 524328, a3: 0); /*0x102cf2741*/
        v27 = a2 + 1; /*0x102cf2746*/
        v29 = nullptr; /*0x102cf2749*/
        v12 = 0; /*0x102cf274b*/
      }
LABEL_54:
      CRYPTO_clear_free(a1: v29, a2: v27); /*0x102cf287a*/
      CRYPTO_clear_free(a1: v26, a2: v27); /*0x102cf289f*/
      CRYPTO_free(a1: object_namea); /*0x102cf28b0*/
      UI_free(ui: user_dataa); /*0x102cf28b9*/
      goto LABEL_55; /*0x102cf28b9*/
    }
    goto LABEL_34; /*0x102cf24c0*/
  }
  v10 = *((const void **)a6 + 1); /*0x102cf2405*/
  if ( v10 == nullptr ) /*0x102cf240c*/
    goto LABEL_13; /*0x102cf240c*/
  v11 = (size_t *)(a6 + 4); /*0x102cf240e*/
LABEL_7:
  if ( *v11 < a2 ) /*0x102cf242e*/
    a2 = *v11; /*0x102cf242e*/
  memcpy(__dst: a1, __src: v10, __n: a2); /*0x102cf2435*/
  *v8 = a2; /*0x102cf243a*/
  return 1; /*0x102cf2948*/
}

// Address: 0x102cf2970 | Name: _ossl_pw_pem_password
size_t __fastcall ossl_pw_pem_password(char *a1, int a2, unsigned int a3, int *a4)
{
  int passphrase; // eax
  size_t v6; // [rsp+8h] [rbp-68h] BYREF
  __int128 v7; // [rsp+10h] [rbp-60h] BYREF
  const char *v8; // [rsp+20h] [rbp-50h]
  __int64 v9; // [rsp+28h] [rbp-48h]
  __int128 v10; // [rsp+30h] [rbp-40h]
  __int128 v11; // [rsp+40h] [rbp-30h]
  __int128 v12; // [rsp+50h] [rbp-20h]

  v6 = 0; /*0x102cf298c*/
  v9 = *((_QWORD *)&xmmword_10C85CD20 + 1); /*0x102cf299b*/
  v12 = xmmword_10C85CD50; /*0x102cf29a6*/
  v11 = xmmword_10C85CD40; /*0x102cf29b1*/
  v10 = xmmword_10C85CD30; /*0x102cf29bc*/
  v7 = *(_OWORD *)&off_10C85CD10; /*0x102cf29c7*/
  v8 = "PEM"; /*0x102cf29d2*/
  passphrase = ossl_pw_get_passphrase(a1, a2, a3: &v6, a4: (const char **)&v7, a5: a3, a6: a4); /*0x102cf29e1*/
  return passphrase == 0 ? -1 : (unsigned int)v6;
}

// Address: 0x102cf2a10 | Name: _ossl_pw_pvk_password
size_t __fastcall ossl_pw_pvk_password(void *a1, int a2, unsigned int a3, int *a4)
{
  int passphrase; // eax
  size_t v6; // [rsp+8h] [rbp-68h] BYREF
  __int128 v7; // [rsp+10h] [rbp-60h] BYREF
  const char *v8; // [rsp+20h] [rbp-50h]
  __int64 v9; // [rsp+28h] [rbp-48h]
  __int128 v10; // [rsp+30h] [rbp-40h]
  __int128 v11; // [rsp+40h] [rbp-30h]
  __int128 v12; // [rsp+50h] [rbp-20h]

  v6 = 0; /*0x102cf2a2c*/
  v9 = *((_QWORD *)&xmmword_10C85CD20 + 1); /*0x102cf2a3b*/
  v12 = xmmword_10C85CD50; /*0x102cf2a46*/
  v11 = xmmword_10C85CD40; /*0x102cf2a51*/
  v10 = xmmword_10C85CD30; /*0x102cf2a5c*/
  v7 = *(_OWORD *)&off_10C85CD10; /*0x102cf2a67*/
  v8 = "PVK"; /*0x102cf2a72*/
  passphrase = ossl_pw_get_passphrase(a1, a2, a3: &v6, a4: (const char **)&v7, a5: a3, a6: a4); /*0x102cf2a81*/
  return passphrase == 0 ? -1 : (unsigned int)v6;
}

// Address: 0x102cf2ab0 | Name: _ossl_pw_passphrase_callback_enc
__int64 __fastcall ossl_pw_passphrase_callback_enc(void *a1, size_t a2, size_t *a3, const char **a4, int *a5)
{
  return ossl_pw_get_passphrase(a1, a2, a3, a4, a5: 1u, a6: a5); /*0x102cf2abd*/
}

// Address: 0x102cf2ad0 | Name: _ossl_pw_passphrase_callback_dec
__int64 __fastcall ossl_pw_passphrase_callback_dec(void *a1, size_t a2, size_t *a3, const char **a4, int *a5)
{
  return ossl_pw_get_passphrase(a1, a2, a3, a4, a5: 0, a6: a5); /*0x102cf2ada*/
}

// Address: 0x102cf2ae0 | Name: _OSSL_PROVIDER_try_load_ex
void *__fastcall OSSL_PROVIDER_try_load_ex(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v6; // rax
  void *v7; // rbx
  __int64 v8; // r15
  __int64 v9; // rax

  v6 = ossl_provider_find(a1, a2, a3: 0); /*0x102cf2aff*/
  if ( v6 != 0 ) /*0x102cf2b07*/
  {
    v7 = (void *)v6; /*0x102cf2b09*/
    v8 = v6; /*0x102cf2b1b*/
    if ( (unsigned int)ossl_provider_activate(a1: v6, a2: 1, a3: 0) == 0 ) /*0x102cf2b20*/
      goto LABEL_9; /*0x102cf2b20*/
  }
  else
  {
    v8 = 0; /*0x102cf2b2c*/
    v9 = ossl_provider_new(a1, a2, a3: 0, a4: a3, a5: 0); /*0x102cf2b3d*/
    if ( v9 != 0 ) /*0x102cf2b45*/
    {
      v7 = (void *)v9; /*0x102cf2b47*/
      if ( (unsigned int)ossl_provider_activate(a1: v9, a2: 1, a3: 0) != 0 ) /*0x102cf2b5b*/
      {
        if ( (unsigned int)ossl_provider_add_to_store(a1: v7) != 0 ) /*0x102cf2b72*/
          return v7; /*0x102cf2b7b*/
        ossl_provider_deactivate(a1: v7, a2: 1); /*0x102cf2ba1*/
      }
LABEL_9:
      ossl_provider_free(a1: v7); /*0x102cf2ba6*/
      return nullptr; /*0x102cf2bae*/
    }
  }
  return (void *)v8; /*0x102cf2bb4*/
}

// Address: 0x102cf2bd0 | Name: _OSSL_PROVIDER_try_load
void *__fastcall OSSL_PROVIDER_try_load(__int64 a1, __int64 a2)
{
  return OSSL_PROVIDER_try_load_ex(a1, a2, a3: 0); /*0x102cf2bd8*/
}

// Address: 0x102cf2be0 | Name: _OSSL_PROVIDER_load_ex
void *__fastcall OSSL_PROVIDER_load_ex(__int64 a1, __int64 a2, __int64 a3)
{
  if ( (unsigned int)ossl_provider_disable_fallback_loading(a1) != 0 ) /*0x102cf2bfa*/
    return OSSL_PROVIDER_try_load_ex(a1, a2, a3); /*0x102cf2c11*/
  else
    return nullptr; /*0x102cf2c16*/
}

// Address: 0x102cf2c30 | Name: _OSSL_PROVIDER_load
void *__fastcall OSSL_PROVIDER_load(__int64 a1, __int64 a2)
{
  if ( (unsigned int)ossl_provider_disable_fallback_loading(a1) != 0 ) /*0x102cf2c44*/
    return OSSL_PROVIDER_try_load_ex(a1, a2, a3: 0); /*0x102cf2c54*/
  else
    return nullptr; /*0x102cf2c59*/
}

// Address: 0x102cf2c60 | Name: _OSSL_PROVIDER_unload
__int64 __fastcall OSSL_PROVIDER_unload(void *a1)
{
  unsigned int v2; // ebx

  v2 = 1; /*0x102cf2c6a*/
  if ( (unsigned int)ossl_provider_deactivate(a1, a2: 1) != 0 ) /*0x102cf2c7b*/
    ossl_provider_free(a1); /*0x102cf2c80*/
  else
    return 0; /*0x102cf2c87*/
  return v2; /*0x102cf2c8b*/
}

// Address: 0x102cf2c90 | Name: _OSSL_PROVIDER_gettable_params
__int64 OSSL_PROVIDER_gettable_params()
{
  return ossl_provider_gettable_params(); /*0x102cf2c94*/
}

// Address: 0x102cf2ca0 | Name: _OSSL_PROVIDER_get_params
__int64 OSSL_PROVIDER_get_params()
{
  return ossl_provider_get_params(); /*0x102cf2ca4*/
}

// Address: 0x102cf2cb0 | Name: _OSSL_PROVIDER_query_operation
__int64 __fastcall OSSL_PROVIDER_query_operation(__int64 a1, __int64 a2, __int64 a3)
{
  return ossl_provider_query_operation(a1, a2, a3); /*0x102cf2cb4*/
}

// Address: 0x102cf2cc0 | Name: _OSSL_PROVIDER_unquery_operation
__int64 __fastcall OSSL_PROVIDER_unquery_operation(__int64 a1, __int64 a2, __int64 a3)
{
  return ossl_provider_unquery_operation(a1, a2, a3); /*0x102cf2cc4*/
}

// Address: 0x102cf2cd0 | Name: _OSSL_PROVIDER_get0_provider_ctx
__int64 __fastcall OSSL_PROVIDER_get0_provider_ctx(__int64 a1)
{
  return ossl_provider_ctx(a1); /*0x102cf2cd4*/
}

// Address: 0x102cf2ce0 | Name: _OSSL_PROVIDER_get0_dispatch
__int64 OSSL_PROVIDER_get0_dispatch()
{
  return ossl_provider_get0_dispatch(); /*0x102cf2ce4*/
}

// Address: 0x102cf2cf0 | Name: _OSSL_PROVIDER_self_test
__int64 OSSL_PROVIDER_self_test()
{
  return ossl_provider_self_test(); /*0x102cf2cf4*/
}

// Address: 0x102cf2d00 | Name: _OSSL_PROVIDER_get_capabilities
__int64 OSSL_PROVIDER_get_capabilities()
{
  return ossl_provider_get_capabilities(); /*0x102cf2d04*/
}

// Address: 0x102cf2d10 | Name: _OSSL_PROVIDER_add_builtin
__int64 __fastcall OSSL_PROVIDER_add_builtin(__int64 a1, const char *a2, __int64 a3)
{
  unsigned int v3; // r14d
  char *v7; // [rsp+0h] [rbp-40h] BYREF
  __int128 v8; // [rsp+8h] [rbp-38h]
  __int128 v9; // [rsp+18h] [rbp-28h]

  if ( a3 != 0 && a2 != nullptr ) /*0x102cf2d20*/
  {
    v9 = 0; /*0x102cf2d6b*/
    v8 = 0; /*0x102cf2d6f*/
    v7 = CRYPTO_strdup(str: a2, file: "crypto/provider.c", line: 136); /*0x102cf2d8a*/
    v3 = 0; /*0x102cf2d8e*/
    if ( v7 != nullptr ) /*0x102cf2d94*/
    {
      *((_QWORD *)&v8 + 1) = a3; /*0x102cf2d96*/
      v3 = 1; /*0x102cf2da6*/
      if ( (unsigned int)((__int64 (__fastcall *)(__int64, char **))ossl_provider_info_add_to_store)(a1, a2: &v7) == 0 ) /*0x102cf2dae*/
      {
        ossl_provider_info_clear(a1: &v7); /*0x102cf2db4*/
        return 0; /*0x102cf2db9*/
      }
    }
  }
  else
  {
    ERR_new(); /*0x102cf2d2d*/
    ERR_set_debug(__s: "crypto/provider.c", a2: 132, a3: "OSSL_PROVIDER_add_builtin"); /*0x102cf2d45*/
    v3 = 0; /*0x102cf2d4a*/
    ERR_set_error(a1: 15, a2: 786690, a3: 0); /*0x102cf2d5b*/
  }
  return v3; /*0x102cf2dbf*/
}

// Address: 0x102cf2dd0 | Name: _OSSL_PROVIDER_get0_name
__int64 __fastcall OSSL_PROVIDER_get0_name(__int64 a1)
{
  return ossl_provider_name(a1); /*0x102cf2dd4*/
}

// Address: 0x102cf2de0 | Name: _OSSL_PROVIDER_do_all
__int64 OSSL_PROVIDER_do_all()
{
  return ossl_provider_doall_activated(); /*0x102cf2de4*/
}

// Address: 0x102cf2df0 | Name: _ossl_child_prov_ctx_new
void *ossl_child_prov_ctx_new()
{
  return CRYPTO_zalloc(__size: 0x58u, __s: "crypto/provider_child.c", line: 39); /*0x102cf2e05*/
}

// Address: 0x102cf2e10 | Name: _ossl_child_prov_ctx_free
void __fastcall ossl_child_prov_ctx_free(pthread_rwlock_t **a1)
{
  CRYPTO_THREAD_lock_free(a1: a1[2]); /*0x102cf2e1d*/
  CRYPTO_free(a1); /*0x102cf2e37*/
}

// Address: 0x102cf2e40 | Name: _ossl_provider_init_as_child
__int64 __fastcall ossl_provider_init_as_child(void **a1, void *a2, __int64 a3)
{
  unsigned int v3; // ebx
  void **data; // rax
  _QWORD *v7; // r15
  _QWORD *v8; // r13
  int v9; // r14d
  void **v10; // r14
  pthread_rwlock_t *v11; // rax

  v3 = 0; /*0x102cf2e4e*/
  if ( a1 == nullptr ) /*0x102cf2e53*/
    return v3; /*0x102cf2e53*/
  data = ossl_lib_ctx_get_data(a1, a2: 18); /*0x102cf2e68*/
  if ( data == nullptr ) /*0x102cf2e70*/
    return v3; /*0x102cf2e70*/
  *data = a2; /*0x102cf2e76*/
  v7 = (_QWORD *)(a3 + 8); /*0x102cf2e9c*/
  while ( 2 ) /*0x102cf2ebb*/
  {
    v9 = *((_DWORD *)v7 - 2); /*0x102cf2ebb*/
    switch ( v9 ) /*0x102cf2ed0*/
    {
      case 'i': /*0x102cf2ed0*/
        v8 = data + 4; /*0x102cf2ed3*/
        goto LABEL_5; /*0x102cf2ed6*/
      case 'j': /*0x102cf2ed0*/
        v8 = data + 5; /*0x102cf2efa*/
        goto LABEL_5; /*0x102cf2efd*/
      case 'k': /*0x102cf2ed0*/
        v8 = data + 6; /*0x102cf2ef0*/
        goto LABEL_5; /*0x102cf2ef3*/
      case 'l': /*0x102cf2ed0*/
        v8 = data + 7; /*0x102cf2ef5*/
        goto LABEL_5; /*0x102cf2ef8*/
      case 'm': /*0x102cf2ed0*/
        v8 = data + 8; /*0x102cf2ea9*/
        goto LABEL_5; /*0x102cf2ea9*/
      case 'n': /*0x102cf2ed0*/
        v8 = data + 9; /*0x102cf2eff*/
        goto LABEL_5; /*0x102cf2f02*/
      case 'o': /*0x102cf2ed0*/
        v8 = data + 10; /*0x102cf2f04*/
        goto LABEL_5; /*0x102cf2f07*/
      default:
        v8 = data + 3; /*0x102cf2ee0*/
        if ( v9 == 4 ) /*0x102cf2ee7*/
        {
LABEL_5:
          *v8 = *v7; /*0x102cf2eb0*/
        }
        else if ( v9 == 0 ) /*0x102cf2eec*/
        {
          if ( data[3] != nullptr /*0x102cf2f31*/
            && data[4] != nullptr
            && data[6] != nullptr
            && data[7] != nullptr
            && data[8] != nullptr
            && data[9] != nullptr
            && data[10] != nullptr )
          {
            v10 = data; /*0x102cf2f33*/
            v11 = CRYPTO_THREAD_lock_new(); /*0x102cf2f36*/
            v10[2] = v11; /*0x102cf2f3b*/
            if ( v11 != nullptr ) /*0x102cf2f42*/
              return ((unsigned int (__fastcall *)(void *, __int64 (__fastcall *)(), __int64 (__fastcall *)(), __int64 (__fastcall *)(), void **))v10[4])( /*0x102cf2f68*/
                       a1: *v10,
                       a2: provider_create_child_cb,
                       a3: provider_remove_child_cb,
                       a4: provider_global_props_cb,
                       a5: a1) != 0;
          }
          return v3; /*0x102cf2f71*/
        }
        v7 += 2; /*0x102cf2eb7*/
        continue; /*0x102cf2eb7*/
    }
  }
}

// Address: 0x102cf3160 | Name: _ossl_provider_deinit_child
void **__fastcall ossl_provider_deinit_child(void **a1)
{
  void **result; // rax

  result = ossl_lib_ctx_get_data(a1, a2: 18); /*0x102cf3169*/
  if ( result != nullptr ) /*0x102cf3171*/
    return (void **)((__int64 (__fastcall *)(void *))result[5])(a1: *result); /*0x102cf3177*/
  return result; /*0x102cf317a*/
}

// Address: 0x102cf3180 | Name: _ossl_provider_up_ref_parent
__int64 __fastcall ossl_provider_up_ref_parent(__int64 a1, unsigned int a2)
{
  void **v4; // rax
  void **data; // rax
  void **v6; // r15
  __int64 parent; // rax

  v4 = (void **)ossl_provider_libctx(a1); /*0x102cf318f*/
  data = ossl_lib_ctx_get_data(a1: v4, a2: 18); /*0x102cf319c*/
  if ( data == nullptr ) /*0x102cf31a4*/
    return 0; /*0x102cf31cb*/
  v6 = data; /*0x102cf31a6*/
  parent = ossl_provider_get_parent(a1); /*0x102cf31ac*/
  if ( (void *)parent == *v6 ) /*0x102cf31b4*/
    return 1; /*0x102cf31cf*/
  else
    return ((__int64 (__fastcall *)(__int64, _QWORD))v6[9])(a1: parent, a2); /*0x102cf31c9*/
}

// Address: 0x102cf31e0 | Name: _ossl_provider_free_parent
__int64 __fastcall ossl_provider_free_parent(__int64 a1, unsigned int a2)
{
  void **v4; // rax
  void **data; // rax
  void **v6; // r15
  __int64 (__fastcall *v7)(__int64, _QWORD); // r15
  __int64 parent; // rax

  v4 = (void **)ossl_provider_libctx(a1); /*0x102cf31ef*/
  data = ossl_lib_ctx_get_data(a1: v4, a2: 18); /*0x102cf31fc*/
  if ( data == nullptr ) /*0x102cf3204*/
    return 0; /*0x102cf3236*/
  v6 = data; /*0x102cf3206*/
  if ( (void *)ossl_provider_get_parent(a1) == *data ) /*0x102cf3214*/
    return 1; /*0x102cf323a*/
  v7 = (__int64 (__fastcall *)(__int64, _QWORD))v6[10]; /*0x102cf3216*/
  parent = ossl_provider_get_parent(a1); /*0x102cf321d*/
  return v7(a1: parent, a2); /*0x102cf322f*/
}

// Address: 0x102cf3250 | Name: _ossl_child_provider_init
__int64 __fastcall ossl_child_provider_init(__int64 a1, __int64 a2, _QWORD *a3, _QWORD *a4)
{
  __int64 (__fastcall **v6)(_QWORD); // rsi
  __int64 (__fastcall *v7)(__int64); // rax
  int v8; // ecx
  unsigned int v9; // r15d
  void **v10; // rax
  void **data; // rax
  void **v12; // r15

  v6 = (__int64 (__fastcall **)(_QWORD))(a2 + 8); /*0x102cf3260*/
  v7 = nullptr; /*0x102cf3264*/
  while ( 1 ) /*0x102cf3277*/
  {
    v8 = *((_DWORD *)v6 - 2); /*0x102cf3277*/
    if ( v8 == 4 ) /*0x102cf327d*/
    {
      v7 = *v6; /*0x102cf3270*/
      goto LABEL_3; /*0x102cf3270*/
    }
    if ( v8 == 0 ) /*0x102cf3281*/
      break; /*0x102cf3281*/
LABEL_3:
    v6 += 2; /*0x102cf3273*/
  }
  v9 = 0; /*0x102cf3283*/
  if ( v7 != nullptr ) /*0x102cf3289*/
  {
    v10 = (void **)v7(a1); /*0x102cf328b*/
    data = ossl_lib_ctx_get_data(a1: v10, a2: 18); /*0x102cf3295*/
    if ( data != nullptr ) /*0x102cf329d*/
    {
      v12 = data; /*0x102cf32a3*/
      *a4 = ((__int64 (__fastcall *)(void *))data[7])(a1: data[1]); /*0x102cf32a9*/
      *a3 = ((__int64 (__fastcall *)(void *))v12[8])(a1: v12[1]); /*0x102cf32b4*/
      return 1; /*0x102cf32b7*/
    }
  }
  return v9; /*0x102cf32c4*/
}

// Address: 0x102cf32d0 | Name: _ossl_prov_conf_ctx_new
pthread_rwlock_t **ossl_prov_conf_ctx_new()
{
  pthread_rwlock_t **v0; // rax
  pthread_rwlock_t **v1; // rbx
  pthread_rwlock_t *v2; // rcx
  pthread_rwlock_t **result; // rax

  v0 = (pthread_rwlock_t **)CRYPTO_zalloc(__size: 0x10u, __s: "crypto/provider_conf.c", line: 32); /*0x102cf32e7*/
  if ( v0 != nullptr ) /*0x102cf32ef*/
  {
    v1 = v0; /*0x102cf32f1*/
    v2 = CRYPTO_THREAD_lock_new(); /*0x102cf32f9*/
    result = v1; /*0x102cf32fc*/
    *v1 = v2; /*0x102cf32ff*/
    if ( v2 != nullptr ) /*0x102cf3305*/
      return result; /*0x102cf3305*/
    CRYPTO_free(a1: v1); /*0x102cf331d*/
  }
  return nullptr; /*0x102cf330b*/
}

// Address: 0x102cf3330 | Name: _ossl_prov_conf_ctx_free
void __fastcall ossl_prov_conf_ctx_free(void **a1)
{
  OPENSSL_sk_pop_free(a1: a1[1]); /*0x102cf3344*/
  CRYPTO_THREAD_lock_free(a1: (pthread_rwlock_t *)*a1); /*0x102cf334c*/
  CRYPTO_free(a1); /*0x102cf3366*/
}

// Address: 0x102cf3370 | Name: _ossl_provider_add_conf_module
int ossl_provider_add_conf_module()
{
  return CONF_module_add(name: "providers", ifunc: provider_conf_init, ffunc: nullptr); /*0x102cf3384*/
}

// Address: 0x102cf3f20 | Name: _ossl_provider_info_clear
__int64 __fastcall ossl_provider_info_clear(void **a1)
{
  CRYPTO_free(a1: *a1); /*0x102cf3f3c*/
  CRYPTO_free(a1: a1[1]); /*0x102cf3f4d*/
  return OPENSSL_sk_pop_free(a1: a1[3]); /*0x102cf3f5d*/
}

// Address: 0x102cf3fc0 | Name: _ossl_provider_store_free
void __fastcall ossl_provider_store_free(void *a1)
{
  __int64 v2; // r12
  unsigned __int64 v3; // r13
  __int64 v4; // r15

  if ( a1 != nullptr ) /*0x102cf3fc3*/
  {
    *((_BYTE *)a1 + 72) |= 2u; /*0x102cf3fda*/
    CRYPTO_free(a1: *((void **)a1 + 5)); /*0x102cf3fee*/
    OPENSSL_sk_pop_free(a1: *((void **)a1 + 1)); /*0x102cf3ffe*/
    OPENSSL_sk_pop_free(a1: *((void **)a1 + 2)); /*0x102cf400e*/
    CRYPTO_THREAD_lock_free(a1: *((pthread_rwlock_t **)a1 + 3)); /*0x102cf4017*/
    CRYPTO_THREAD_lock_free(a1: *((pthread_rwlock_t **)a1 + 4)); /*0x102cf4020*/
    if ( *((_QWORD *)a1 + 7) != 0 ) /*0x102cf402a*/
    {
      v2 = 0; /*0x102cf402c*/
      v3 = 0; /*0x102cf4036*/
      do /*0x102cf4083*/
      {
        v4 = *((_QWORD *)a1 + 6); /*0x102cf4040*/
        CRYPTO_free(a1: *(void **)(v4 + v2)); /*0x102cf4050*/
        CRYPTO_free(a1: *(void **)(v4 + v2 + 8)); /*0x102cf4062*/
        OPENSSL_sk_pop_free(a1: *(void **)(v4 + v2 + 24)); /*0x102cf4073*/
        ++v3; /*0x102cf4078*/
        v2 += 40; /*0x102cf407b*/
      }
      while ( v3 < *((_QWORD *)a1 + 7) ); /*0x102cf4083*/
    }
    CRYPTO_free(a1: *((void **)a1 + 6)); /*0x102cf4098*/
    CRYPTO_free(a1); /*0x102cf40b6*/
  }
}

// Address: 0x102cf4110 | Name: _ossl_provider_child_cb_free
void __fastcall ossl_provider_child_cb_free(void *a1)
{
  CRYPTO_free(a1); /*0x102cf4121*/
}

// Address: 0x102cf4130 | Name: _ossl_provider_store_new
_QWORD *__fastcall ossl_provider_store_new(__int64 a1)
{
  _QWORD *v2; // rbx
  __int64 v3; // rax
  pthread_rwlock_t *v4; // rax
  __int64 v5; // rdi
  __int64 v6; // rsi
  __int64 v7; // rax
  pthread_rwlock_t *v8; // rax

  v2 = CRYPTO_zalloc(__size: 0x50u, __s: "crypto/provider_core.c", line: 311); /*0x102cf4150*/
  if ( v2 == nullptr ) /*0x102cf4156*/
    goto LABEL_7; /*0x102cf4156*/
  v3 = OPENSSL_sk_new(a1: ossl_provider_cmp); /*0x102cf415f*/
  v2[1] = v3; /*0x102cf4164*/
  if ( v3 == 0 ) /*0x102cf416b*/
    goto LABEL_7; /*0x102cf416b*/
  v4 = CRYPTO_THREAD_lock_new(); /*0x102cf416d*/
  v2[3] = v4; /*0x102cf4172*/
  if ( v4 != nullptr /*0x102cf4195*/
    && (v7 = OPENSSL_sk_new_null(a1: v5, a2: v6), v2[2] = v7, v7 != 0)
    && (v8 = CRYPTO_THREAD_lock_new(), v2[4] = v8, v8 != nullptr) )
  {
    *v2 = a1; /*0x102cf4197*/
    *((_BYTE *)v2 + 72) |= 1u; /*0x102cf419a*/
  }
  else
  {
LABEL_7:
    ossl_provider_store_free(a1: v2); /*0x102cf41a3*/
    return nullptr; /*0x102cf41a8*/
  }
  return v2; /*0x102cf41ad*/
}

// Address: 0x102cf41c0 | Name: _ossl_provider_cmp
int __fastcall ossl_provider_cmp(__int64 a1, __int64 a2)
{
  return strcmp(__s1: *(const char **)(*(_QWORD *)a1 + 40LL), __s2: *(const char **)(*(_QWORD *)a2 + 40LL)); /*0x102cf41d2*/
}

// Address: 0x102cf41e0 | Name: _ossl_provider_disable_fallback_loading
__int64 __fastcall ossl_provider_disable_fallback_loading(void **a1)
{
  void **data; // rax
  void **v2; // rbx
  unsigned int v3; // ebx

  data = ossl_lib_ctx_get_data(a1, a2: 1); /*0x102cf41eb*/
  if ( data != nullptr ) /*0x102cf41f3*/
  {
    v2 = data; /*0x102cf41f5*/
    if ( CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)data[4]) ) /*0x102cf41fc*/
    {
      *((_BYTE *)v2 + 72) &= ~1u; /*0x102cf4205*/
      CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v2[4]); /*0x102cf420d*/
      return 1; /*0x102cf4212*/
    }
    else
    {
      return 0; /*0x102cf424d*/
    }
  }
  else
  {
    ERR_new(); /*0x102cf4219*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf4231*/
    v3 = 0; /*0x102cf4236*/
    ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf4246*/
  }
  return v3; /*0x102cf4255*/
}

// Address: 0x102cf4260 | Name: _ossl_provider_info_add_to_store
__int64 __fastcall ossl_provider_info_add_to_store(void **a1, __int128 *a2)
{
  void **data; // rax
  void **v4; // r14
  char *v5; // r15
  _QWORD *v6; // rax
  unsigned int v7; // r15d
  __int64 v8; // rsi
  __int64 v9; // rcx
  __int128 v10; // xmm0

  data = ossl_lib_ctx_get_data(a1, a2: 1); /*0x102cf4272*/
  if ( data == nullptr ) /*0x102cf427a*/
  {
    ERR_new(); /*0x102cf42ec*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf4304*/
    v7 = 0; /*0x102cf4309*/
    ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf431a*/
    if ( *(_QWORD *)a2 != 0 ) /*0x102cf4323*/
    {
      ERR_new(); /*0x102cf4325*/
      ERR_set_debug(__s: "crypto/provider_core.c", a2: 367, a3: "ossl_provider_info_add_to_store"); /*0x102cf433d*/
      v8 = 786691; /*0x102cf4347*/
LABEL_11:
      ERR_set_error(a1: 15, a2: v8, a3: 0); /*0x102cf4378*/
      return v7; /*0x102cf4381*/
    }
LABEL_10:
    ERR_new(); /*0x102cf434e*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 362, a3: "ossl_provider_info_add_to_store"); /*0x102cf4366*/
    v7 = 0; /*0x102cf436b*/
    v8 = 786690; /*0x102cf4373*/
    goto LABEL_11; /*0x102cf4373*/
  }
  if ( *(_QWORD *)a2 == 0 ) /*0x102cf4280*/
    goto LABEL_10; /*0x102cf4280*/
  v4 = data; /*0x102cf4286*/
  if ( CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)data[4]) ) /*0x102cf428d*/
  {
    v5 = (char *)v4[8]; /*0x102cf429a*/
    if ( v5 != nullptr ) /*0x102cf42a1*/
    {
      if ( v4[7] != v5 ) /*0x102cf42ab*/
      {
        v6 = v4[6]; /*0x102cf43b1*/
        goto LABEL_16; /*0x102cf43b1*/
      }
      v6 = CRYPTO_realloc(addr: v4[6], num: 5 * (8 * (int)v5 + 80), file: "crypto/provider_core.c", line: 384); /*0x102cf42cd*/
      if ( v6 != nullptr ) /*0x102cf42d5*/
      {
        v4[6] = v6; /*0x102cf42df*/
        v4[8] = v5 + 10; /*0x102cf42e3*/
LABEL_16:
        v9 = 5LL * (_QWORD)v4[7]; /*0x102cf43b5*/
        v6[v9 + 4] = *((_QWORD *)a2 + 4); /*0x102cf43c1*/
        v10 = *a2; /*0x102cf43c6*/
        *(_OWORD *)&v6[v9 + 2] = a2[1]; /*0x102cf43cd*/
        *(_OWORD *)&v6[v9] = v10; /*0x102cf43d2*/
        v4[7] = (char *)v4[7] + 1; /*0x102cf43d6*/
        v7 = 1; /*0x102cf43da*/
LABEL_18:
        CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v4[4]); /*0x102cf43e5*/
        return v7; /*0x102cf43e9*/
      }
    }
    else
    {
      v6 = CRYPTO_zalloc(__size: 0x190u, __s: "crypto/provider_core.c", line: 375); /*0x102cf4399*/
      v4[6] = v6; /*0x102cf439e*/
      if ( v6 != nullptr ) /*0x102cf43a5*/
      {
        v4[8] = (void *)10; /*0x102cf43a7*/
        goto LABEL_16; /*0x102cf43af*/
      }
    }
    v7 = 0; /*0x102cf43e2*/
    goto LABEL_18; /*0x102cf43e2*/
  }
  return 0; /*0x102cf43f5*/
}

// Address: 0x102cf4400 | Name: _ossl_provider_find
__int64 __fastcall ossl_provider_find(void **a1, __int64 a2)
{
  void **data; // rax
  void **v4; // r14
  unsigned int v5; // eax
  __int64 v6; // rbx
  signed __int32 v7; // r14d
  _QWORD v9[4]; // [rsp+0h] [rbp-100h] BYREF
  __int64 v10; // [rsp+20h] [rbp-E0h]
  __int64 v11; // [rsp+28h] [rbp-D8h]
  __int128 v12; // [rsp+30h] [rbp-D0h]
  __int128 v13; // [rsp+40h] [rbp-C0h]
  __int128 v14; // [rsp+50h] [rbp-B0h]
  __int128 v15; // [rsp+60h] [rbp-A0h]
  __int128 v16; // [rsp+70h] [rbp-90h]
  __int128 v17; // [rsp+80h] [rbp-80h]
  __int128 v18; // [rsp+90h] [rbp-70h]
  __int128 v19; // [rsp+A0h] [rbp-60h]
  __int128 v20; // [rsp+B0h] [rbp-50h]
  __int128 v21; // [rsp+C0h] [rbp-40h]
  __int128 v22; // [rsp+D0h] [rbp-30h]
  __int64 v23; // [rsp+E0h] [rbp-20h]

  data = ossl_lib_ctx_get_data(a1, a2: 1); /*0x102cf4416*/
  if ( data == nullptr ) /*0x102cf441e*/
  {
    ERR_new(); /*0x102cf44ff*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf4517*/
    v6 = 0; /*0x102cf451c*/
    ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf452c*/
    return v6; /*0x102cf4531*/
  }
  v4 = data; /*0x102cf4424*/
  v10 = 0; /*0x102cf442a*/
  v22 = 0; /*0x102cf4431*/
  v21 = 0; /*0x102cf4435*/
  v20 = 0; /*0x102cf4439*/
  v19 = 0; /*0x102cf443d*/
  v18 = 0; /*0x102cf4441*/
  v17 = 0; /*0x102cf4445*/
  v16 = 0; /*0x102cf4449*/
  v15 = 0; /*0x102cf4450*/
  v14 = 0; /*0x102cf4457*/
  v13 = 0; /*0x102cf445e*/
  v12 = 0; /*0x102cf4465*/
  memset(v9, 0, sizeof(v9)); /*0x102cf4473*/
  v23 = 0; /*0x102cf447a*/
  v11 = a2; /*0x102cf4482*/
  if ( !CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)data[4]) ) /*0x102cf448d*/
    return 0; /*0x102cf448d*/
  OPENSSL_sk_sort(a1: v4[1]); /*0x102cf449e*/
  v5 = OPENSSL_sk_find(a1: v4[1], a2: v9); /*0x102cf44ae*/
  if ( v5 == -1 ) /*0x102cf44b6*/
  {
    CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v4[4]); /*0x102cf4537*/
    return 0; /*0x102cf4537*/
  }
  v6 = OPENSSL_sk_value(a1: v4[1], a2: v5); /*0x102cf44c3*/
  CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v4[4]); /*0x102cf44ca*/
  if ( v6 == 0 ) /*0x102cf44d2*/
    return 0; /*0x102cf453c*/
  v7 = _InterlockedExchangeAdd((volatile signed __int32 *)(v6 + 16), 1u); /*0x102cf44da*/
  if ( (*(_BYTE *)(v6 + 208) & 1) != 0 && (unsigned int)ossl_provider_up_ref_parent(a1: v6, a2: 0) == 0 ) /*0x102cf44f5*/
  {
    ossl_provider_free(a1: (void *)v6); /*0x102cf4550*/
    return 0; /*0x102cf4555*/
  }
  if ( v7 == -1 ) /*0x102cf44fb*/
    return 0; /*0x102cf44fb*/
  return v6; /*0x102cf4541*/
}

// Address: 0x102cf4560 | Name: _ossl_provider_up_ref
__int64 __fastcall ossl_provider_up_ref(volatile signed __int32 *a1)
{
  unsigned __int32 v1; // ebx

  v1 = _InterlockedIncrement(a1 + 4); /*0x102cf4571*/
  if ( (a1[52] & 1) != 0 && (unsigned int)ossl_provider_up_ref_parent((__int64)a1, a2: 0) == 0 ) /*0x102cf4588*/
  {
    ossl_provider_free((void *)a1); /*0x102cf458d*/
    return 0; /*0x102cf4592*/
  }
  return v1; /*0x102cf4596*/
}

// Address: 0x102cf45a0 | Name: _ossl_provider_free
void __fastcall ossl_provider_free(__int64 a1)
{
  void (__fastcall *v1)(_QWORD); // rax
  _BYTE *v2; // rbx
  ERR_STRING_DATA *v3; // rsi
  __int64 v4; // rbx

  if ( a1 != 0 ) /*0x102cf45a3*/
  {
    if ( _InterlockedDecrement((volatile signed __int32 *)(a1 + 16)) != 0 ) /*0x102cf45ad*/
    {
      if ( (*(_BYTE *)(a1 + 208) & 1) != 0 ) /*0x102cf46bc*/
        ossl_provider_free_parent(a1, a2: 0); /*0x102cf46c1*/
    }
    else
    {
      if ( (*(_BYTE *)a1 & 1) != 0 ) /*0x102cf45bd*/
      {
        v1 = *(void (__fastcall **)(_QWORD))(a1 + 112); /*0x102cf45bf*/
        v2 = (_BYTE *)a1; /*0x102cf45c6*/
        if ( v1 != nullptr && (*(_BYTE *)(a1 + 208) & 1) == 0 ) /*0x102cf45d2*/
        {
          v1(a1: *(_QWORD *)(a1 + 216)); /*0x102cf45db*/
          a1 = (__int64)v2; /*0x102cf45dd*/
        }
        v3 = *(ERR_STRING_DATA **)(a1 + 104); /*0x102cf45e0*/
        if ( v3 != nullptr ) /*0x102cf45e7*/
        {
          ERR_unload_strings(lib: *(_DWORD *)(a1 + 96), str: v3); /*0x102cf45ec*/
          CRYPTO_free(a1: *((void **)v2 + 13)); /*0x102cf4601*/
          a1 = (__int64)v2; /*0x102cf4606*/
          *((_QWORD *)v2 + 13) = 0; /*0x102cf4609*/
        }
        CRYPTO_free(a1: *(void **)(a1 + 176)); /*0x102cf4624*/
        a1 = (__int64)v2; /*0x102cf4629*/
        *((_OWORD *)v2 + 11) = 0; /*0x102cf462f*/
        *v2 &= ~1u; /*0x102cf4636*/
      }
      v4 = a1; /*0x102cf4639*/
      ossl_init_thread_deregister(a1); /*0x102cf463c*/
      DSO_free(dso: *(DSO **)(v4 + 56)); /*0x102cf4645*/
      CRYPTO_free(a1: *(void **)(v4 + 40)); /*0x102cf465d*/
      CRYPTO_free(a1: *(void **)(v4 + 48)); /*0x102cf466e*/
      OPENSSL_sk_pop_free(a1: *(void **)(v4 + 72)); /*0x102cf467e*/
      CRYPTO_THREAD_lock_free(a1: *(pthread_rwlock_t **)(v4 + 192)); /*0x102cf468a*/
      CRYPTO_THREAD_lock_free(a1: *(pthread_rwlock_t **)(v4 + 8)); /*0x102cf4693*/
      CRYPTO_THREAD_lock_free(a1: *(pthread_rwlock_t **)(v4 + 24)); /*0x102cf469c*/
      CRYPTO_free(a1: (void *)v4); /*0x102cf46b0*/
    }
  }
}

// Address: 0x102cf46d0 | Name: _ossl_provider_new
__int64 __fastcall ossl_provider_new(void **a1, char *a2, __int64 a3, const char **a4)
{
  void **v7; // rbx
  void **data; // rax
  __int64 v9; // rdi
  __int64 v10; // rsi
  __int64 v11; // r14
  void **v12; // r12
  char **v13; // r13
  const char *v14; // rdi
  __int128 v15; // xmm0
  char *v16; // rbx
  char *v17; // r13
  __int128 v18; // xmm0
  const char *v19; // rsi
  const char **v20; // r15
  void *v21; // r15
  char *v22; // rax
  __int64 v24; // rdi
  void **v25; // [rsp+8h] [rbp-68h]
  char *str[2]; // [rsp+10h] [rbp-60h]
  void *v27[2]; // [rsp+20h] [rbp-50h] BYREF
  char *v28; // [rsp+30h] [rbp-40h]
  int v29; // [rsp+44h] [rbp-2Ch]

  v7 = a1; /*0x102cf46ea*/
  data = ossl_lib_ctx_get_data(a1, a2: 1); /*0x102cf46f2*/
  if ( data != nullptr ) /*0x102cf46fa*/
  {
    *(_OWORD *)v27 = 0; /*0x102cf46ff*/
    *(_OWORD *)str = 0; /*0x102cf4703*/
    v28 = nullptr; /*0x102cf4707*/
    if ( a3 != 0 ) /*0x102cf4712*/
    {
      if ( a4 == nullptr ) /*0x102cf471b*/
        goto LABEL_30; /*0x102cf471b*/
    }
    else
    {
      v12 = data; /*0x102cf475e*/
      v13 = &ossl_predefined_providers; /*0x102cf4761*/
      v14 = ossl_predefined_providers; /*0x102cf4768*/
      LOBYTE(data) = 1; /*0x102cf476c*/
      v29 = (int)data; /*0x102cf476e*/
      if ( ossl_predefined_providers != nullptr ) /*0x102cf4774*/
      {
        while ( strcmp(__s1: v14, __s2: a2) != 0 ) /*0x102cf478a*/
        {
          v14 = v13[5]; /*0x102cf478c*/
          v13 += 5; /*0x102cf4790*/
          if ( v14 == nullptr ) /*0x102cf4797*/
            goto LABEL_9; /*0x102cf4797*/
        }
        v28 = v13[4]; /*0x102cf47b0*/
        v15 = *(_OWORD *)v13; /*0x102cf47b4*/
        *(_OWORD *)v27 = *((_OWORD *)v13 + 1); /*0x102cf47be*/
        str[1] = *((char **)&v15 + 1); /*0x102cf47c2*/
        v29 = 0; /*0x102cf47c6*/
        if ( !CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)v12[4]) ) /*0x102cf47d9*/
          return 0; /*0x102cf47d9*/
      }
      else
      {
LABEL_9:
        if ( !CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)v12[4]) ) /*0x102cf479e*/
          return 0; /*0x102cf47a5*/
      }
      v25 = v7; /*0x102cf47df*/
      v16 = (char *)v12[7]; /*0x102cf47e3*/
      if ( v16 != nullptr ) /*0x102cf47eb*/
      {
        v17 = (char *)v12[6]; /*0x102cf47ed*/
        while ( strcmp(__s1: *(const char **)v17, __s2: a2) != 0 ) /*0x102cf480e*/
        {
          v17 += 40; /*0x102cf4810*/
          if ( --v16 == nullptr ) /*0x102cf4817*/
            goto LABEL_21; /*0x102cf4817*/
        }
        if ( (_BYTE)v29 != 0 ) /*0x102cf481f*/
        {
          v28 = *((char **)v17 + 4); /*0x102cf4825*/
          v18 = *(_OWORD *)v17; /*0x102cf4829*/
          *(_OWORD *)v27 = *((_OWORD *)v17 + 1); /*0x102cf4833*/
          str[1] = *((char **)&v18 + 1); /*0x102cf4837*/
        }
        if ( a4 != nullptr || (v24 = *((_QWORD *)v17 + 3)) == 0 ) /*0x102cf496d*/
        {
          v27[1] = nullptr; /*0x102cf4844*/
        }
        else
        {
          v27[1] = (void *)OPENSSL_sk_deep_copy(a1: v24, a2: infopair_copy, a3: infopair_free); /*0x102cf4986*/
          if ( v27[1] == nullptr ) /*0x102cf498d*/
            return 0; /*0x102cf498d*/
        }
      }
LABEL_21:
      CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v12[4]); /*0x102cf484c*/
      v7 = v25; /*0x102cf4856*/
      if ( a4 == nullptr ) /*0x102cf485d*/
      {
LABEL_30:
        v21 = v27[1]; /*0x102cf48c8*/
        v11 = provider_new(str: a2); /*0x102cf48db*/
        if ( v21 != nullptr ) /*0x102cf48e1*/
          OPENSSL_sk_pop_free(a1: v21); /*0x102cf48ed*/
        if ( v11 != 0 ) /*0x102cf48f5*/
        {
          CRYPTO_free(a1: *(void **)(v11 + 48)); /*0x102cf490b*/
          *(_QWORD *)(v11 + 48) = 0; /*0x102cf4910*/
          if ( str[1] == nullptr /*0x102cf4938*/
            || (v22 = CRYPTO_strdup(str: str[1], file: "crypto/provider_core.c", line: 790),
                *(_QWORD *)(v11 + 48) = v22,
                v22 != nullptr) )
          {
            *(_QWORD *)(v11 + 80) = v7; /*0x102cf493a*/
            *(_DWORD *)(v11 + 96) = ERR_get_next_error_library(); /*0x102cf4943*/
            return v11; /*0x102cf4947*/
          }
          ossl_provider_free(a1: v11); /*0x102cf494c*/
        }
        return 0; /*0x102cf4951*/
      }
    }
    if ( v27[1] == nullptr ) /*0x102cf4864*/
    {
      v27[1] = (void *)OPENSSL_sk_new_null(a1: v9, a2: v10); /*0x102cf486b*/
      if ( v27[1] == nullptr ) /*0x102cf4872*/
        return 0; /*0x102cf4872*/
    }
    v19 = *a4; /*0x102cf4878*/
    if ( *a4 != nullptr ) /*0x102cf487e*/
    {
      v20 = a4 + 5; /*0x102cf4884*/
      while ( *((_DWORD *)v20 - 8) != 4 /*0x102cf48b1*/
           || (unsigned int)infopair_add(a1: (__int64 *)&v27[1], a2: v19, a3: *(v20 - 3)) != 0 )
      {
        v19 = *v20; /*0x102cf4890*/
        v20 += 5; /*0x102cf4893*/
        if ( v19 == nullptr ) /*0x102cf489a*/
          goto LABEL_30; /*0x102cf489a*/
      }
      OPENSSL_sk_pop_free(a1: v27[1]); /*0x102cf48be*/
      return 0; /*0x102cf48c3*/
    }
    goto LABEL_30; /*0x102cf487e*/
  }
  ERR_new(); /*0x102cf4726*/
  ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf473e*/
  v11 = 0; /*0x102cf4743*/
  ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf4754*/
  return v11; /*0x102cf4957*/
}

// Address: 0x102cf4a50 | Name: _ossl_provider_info_add_parameter
__int64 __fastcall ossl_provider_info_add_parameter(__int64 a1, const char *a2, const char *a3)
{
  return infopair_add(a1: (__int64 *)(a1 + 24), a2, a3); /*0x102cf4a58*/
}

// Address: 0x102cf4b90 | Name: _ossl_provider_set_module_path
_BOOL8 __fastcall ossl_provider_set_module_path(__int64 a1, const char *a2)
{
  char *v4; // rax

  CRYPTO_free(a1: *(void **)(a1 + 48)); /*0x102cf4bad*/
  *(_QWORD *)(a1 + 48) = 0; /*0x102cf4bb2*/
  if ( a2 == nullptr ) /*0x102cf4bbd*/
    return true; /*0x102cf4be7*/
  v4 = CRYPTO_strdup(str: a2, file: "crypto/provider_core.c", line: 790); /*0x102cf4bce*/
  *(_QWORD *)(a1 + 48) = v4; /*0x102cf4bd6*/
  return v4 != nullptr; /*0x102cf4be2*/
}

// Address: 0x102cf4c00 | Name: _ossl_provider_add_to_store
__int64 __fastcall ossl_provider_add_to_store(void ***a1, volatile signed __int32 **a2, int a3)
{
  volatile signed __int32 **v4; // r12
  void **data; // rax
  void **v7; // r13
  unsigned int v8; // r14d
  unsigned int v9; // eax
  void *v10; // rdi
  volatile signed __int32 *v11; // r15
  int v12; // eax
  signed __int32 v13; // r14d
  int v14; // r13d
  bool v15; // zf
  __int64 v16; // rcx
  __int64 v17; // r8
  __int64 v18; // r9
  __int64 v19; // rsi
  int v20; // eax
  int v21; // r12d
  unsigned int v22; // r14d
  int v23; // r15d
  __int64 v24; // rax
  __int64 v25; // rdx
  __int64 v26; // rcx
  __int64 v27; // r8
  __int64 v28; // r9
  __int128 v30; // [rsp+0h] [rbp-120h] BYREF
  __int128 v31; // [rsp+10h] [rbp-110h]
  __int128 v32; // [rsp+20h] [rbp-100h]
  __int128 v33; // [rsp+30h] [rbp-F0h]
  __int128 v34; // [rsp+40h] [rbp-E0h]
  __int128 v35; // [rsp+50h] [rbp-D0h]
  __int128 v36; // [rsp+60h] [rbp-C0h]
  __int128 v37; // [rsp+70h] [rbp-B0h]
  __int128 v38; // [rsp+80h] [rbp-A0h]
  __int128 v39; // [rsp+90h] [rbp-90h]
  __int128 v40; // [rsp+A0h] [rbp-80h]
  __int128 v41; // [rsp+B0h] [rbp-70h]
  __int128 v42; // [rsp+C0h] [rbp-60h]
  __int128 v43; // [rsp+D0h] [rbp-50h]
  __int64 v44; // [rsp+E0h] [rbp-40h]
  volatile signed __int32 **v45; // [rsp+E8h] [rbp-38h]
  int v46; // [rsp+F0h] [rbp-30h]
  int v47; // [rsp+F4h] [rbp-2Ch]

  v4 = a2; /*0x102cf4c17*/
  v43 = 0; /*0x102cf4c20*/
  v42 = 0; /*0x102cf4c24*/
  v41 = 0; /*0x102cf4c28*/
  v40 = 0; /*0x102cf4c2c*/
  v39 = 0; /*0x102cf4c30*/
  v38 = 0; /*0x102cf4c37*/
  v37 = 0; /*0x102cf4c3e*/
  v36 = 0; /*0x102cf4c45*/
  v35 = 0; /*0x102cf4c4c*/
  v34 = 0; /*0x102cf4c53*/
  v33 = 0; /*0x102cf4c5a*/
  v32 = 0; /*0x102cf4c61*/
  v31 = 0; /*0x102cf4c68*/
  v30 = 0; /*0x102cf4c6f*/
  v44 = 0; /*0x102cf4c76*/
  if ( a2 != nullptr ) /*0x102cf4c81*/
    *a2 = nullptr; /*0x102cf4c83*/
  data = ossl_lib_ctx_get_data(a1: a1[10], a2: 1); /*0x102cf4c94*/
  if ( data == nullptr ) /*0x102cf4c9c*/
  {
    ERR_new(); /*0x102cf4d59*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf4d71*/
    v8 = 0; /*0x102cf4d76*/
    v19 = 786691; /*0x102cf4d7e*/
    goto LABEL_27; /*0x102cf4d83*/
  }
  v7 = data; /*0x102cf4ca2*/
  v8 = 0; /*0x102cf4cae*/
  if ( !CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)data[4]) ) /*0x102cf4cb3*/
    return v8; /*0x102cf4cb3*/
  *((_QWORD *)&v32 + 1) = a1[5]; /*0x102cf4cbd*/
  v9 = OPENSSL_sk_find(a1: v7[1], a2: &v30); /*0x102cf4ccf*/
  v10 = v7[1]; /*0x102cf4cd4*/
  v46 = v9; /*0x102cf4cdb*/
  if ( v9 != -1 ) /*0x102cf4cde*/
  {
    v11 = (volatile signed __int32 *)OPENSSL_sk_value(a1: v10, a2: v9); /*0x102cf4ceb*/
    goto LABEL_7; /*0x102cf4ceb*/
  }
  if ( (unsigned int)OPENSSL_sk_push(a1: v10, a2: a1) == 0 ) /*0x102cf4d92*/
  {
LABEL_30:
    CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v7[4]); /*0x102cf4e74*/
    return v8; /*0x102cf4e7d*/
  }
  v47 = a3; /*0x102cf4d98*/
  v45 = v4; /*0x102cf4d9c*/
  a1[11] = v7; /*0x102cf4da0*/
  v20 = OPENSSL_sk_num(a1: v7[2]); /*0x102cf4da8*/
  if ( v20 > 0 ) /*0x102cf4daf*/
  {
    v21 = v20; /*0x102cf4db1*/
    v22 = 0; /*0x102cf4db4*/
    v23 = 1; /*0x102cf4db7*/
    do /*0x102cf4ddf*/
    {
      v24 = OPENSSL_sk_value(a1: v7[2], a2: v22); /*0x102cf4dc7*/
      v23 &= (*(__int64 (__fastcall **)(void ***, _QWORD, __int64, __int64, __int64, __int64, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))(v24 + 8))( /*0x102cf4dd6*/
               a1,
               a2: *(_QWORD *)(v24 + 32),
               a3: v25,
               a4: v26,
               a5: v27,
               a6: v28,
               a7: v30,
               a8: *((_QWORD *)&v30 + 1),
               a9: v31,
               a10: *((_QWORD *)&v31 + 1),
               a11: v32);
      ++v22; /*0x102cf4dd9*/
    }
    while ( v21 != v22 ); /*0x102cf4ddf*/
    if ( v23 == 0 ) /*0x102cf4de4*/
    {
      OPENSSL_sk_delete_ptr(a1: v7[1], a2: a1); /*0x102cf4e6c*/
      v8 = 0; /*0x102cf4e71*/
      goto LABEL_30; /*0x102cf4e71*/
    }
  }
  v11 = (volatile signed __int32 *)a1; /*0x102cf4de6*/
  v4 = v45; /*0x102cf4ded*/
  if ( v47 == 0 ) /*0x102cf4df1*/
  {
    *((_BYTE *)v7 + 72) &= ~1u; /*0x102cf4df7*/
    v11 = (volatile signed __int32 *)a1; /*0x102cf4dfc*/
  }
LABEL_7:
  CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v7[4]); /*0x102cf4cee*/
  v12 = v46; /*0x102cf4cfa*/
  if ( v4 != nullptr ) /*0x102cf4cfd*/
  {
    v13 = _InterlockedExchangeAdd(v11 + 4, 1u); /*0x102cf4d05*/
    if ( (v11[52] & 1) != 0 /*0x102cf4d27*/
      && (v14 = v12, v15 = (unsigned int)ossl_provider_up_ref_parent(a1: (__int64)v11, a2: 0) == 0, v12 = v14, v15) )
    {
      ossl_provider_free(a1: (__int64)v11); /*0x102cf4e18*/
    }
    else if ( v13 != -1 ) /*0x102cf4d31*/
    {
      *v4 = v11; /*0x102cf4d37*/
      goto LABEL_12; /*0x102cf4d37*/
    }
    ERR_new(); /*0x102cf4e1d*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 686, a3: "ossl_provider_add_to_store"); /*0x102cf4e35*/
    v8 = 0; /*0x102cf4e3a*/
    v19 = 524303; /*0x102cf4e42*/
LABEL_27:
    ERR_set_error( /*0x102cf4e47*/
      a1: 15,
      a2: v19,
      a3: 0,
      v16,
      v17,
      v18,
      v30,
      v31,
      v32,
      v33,
      v34,
      v35,
      v36,
      v37,
      v38,
      v39,
      v40,
      v41,
      v42,
      v43,
      v44);
    return v8; /*0x102cf4e4b*/
  }
LABEL_12:
  if ( v12 < 0 ) /*0x102cf4d3d*/
  {
    ossl_decoder_cache_flush(a1: (__int64)a1[10]); /*0x102cf4e08*/
  }
  else
  {
    if ( a1 != nullptr && (unsigned int)provider_deactivate(a1, a2: 1, a3: 0) == 0 ) /*0x102cf4e90*/
      provider_remove_store_methods(a1); /*0x102cf4e99*/
    ossl_provider_free((__int64)a1); /*0x102cf4d4f*/
  }
  return 1; /*0x102cf4e53*/
}

// Address: 0x102cf4eb0 | Name: _ossl_provider_deactivate
__int64 __fastcall ossl_provider_deactivate(__int64 a1, unsigned int a2)
{
  __int64 result; // rax
  int v4; // ecx

  result = 0; /*0x102cf4eb6*/
  if ( a1 != 0 ) /*0x102cf4ebb*/
  {
    v4 = provider_deactivate(a1, a2: 1, a3: a2); /*0x102cf4ed3*/
    result = 0; /*0x102cf4ed5*/
    if ( v4 >= 0 ) /*0x102cf4ed9*/
    {
      result = 1; /*0x102cf4edb*/
      if ( v4 == 0 ) /*0x102cf4ee0*/
        return provider_remove_store_methods(a1); /*0x102cf4eeb*/
    }
  }
  return result; /*0x102cf4ec1*/
}

// Address: 0x102cf4ef0 | Name: _ossl_provider_teardown
__int64 (__fastcall *__fastcall ossl_provider_teardown(__int64 a1))(_QWORD)
{
  __int64 (__fastcall *result)(_QWORD); // rax

  result = *(__int64 (__fastcall **)(_QWORD))(a1 + 112); /*0x102cf4ef4*/
  if ( result != nullptr && (*(_BYTE *)(a1 + 208) & 1) == 0 ) /*0x102cf4f04*/
    return (__int64 (__fastcall *)(_QWORD))result(a1: *(_QWORD *)(a1 + 216)); /*0x102cf4f0e*/
  return result; /*0x102cf4f10*/
}

// Address: 0x102cf4f20 | Name: _OSSL_PROVIDER_add_conf_parameter
__int64 __fastcall OSSL_PROVIDER_add_conf_parameter(__int64 a1, const char *a2, const char *a3)
{
  return infopair_add(a1: (__int64 *)(a1 + 72), a2, a3); /*0x102cf4f28*/
}

// Address: 0x102cf5040 | Name: _OSSL_PROVIDER_get_conf_parameters
__int64 __fastcall OSSL_PROVIDER_get_conf_parameters(__int64 a1, const char **a2)
{
  __int64 v3; // rdi
  unsigned int v4; // ebx
  unsigned int v6; // r12d
  const char **v7; // r13
  const char **v8; // rax

  v3 = *(_QWORD *)(a1 + 72); /*0x102cf5051*/
  v4 = 1; /*0x102cf5055*/
  if ( v3 != 0 && (int)OPENSSL_sk_num(a1: v3) > 0 ) /*0x102cf5069*/
  {
    v6 = 0; /*0x102cf506b*/
    while ( 1 ) /*0x102cf508d*/
    {
      v7 = (const char **)OPENSSL_sk_value(a1: *(_QWORD *)(a1 + 72), a2: v6); /*0x102cf508d*/
      v8 = OSSL_PARAM_locate(a1: a2, a2: *v7); /*0x102cf5096*/
      if ( v8 != nullptr && (unsigned int)OSSL_PARAM_set_utf8_ptr(a1: (__int64)v8, a2: v7[1]) == 0 ) /*0x102cf50ae*/
        break; /*0x102cf50ae*/
      if ( (int)++v6 >= (int)OPENSSL_sk_num(a1: *(_QWORD *)(a1 + 72)) ) /*0x102cf507f*/
        return v4; /*0x102cf507f*/
    }
    return 0; /*0x102cf50b0*/
  }
  return v4; /*0x102cf50b8*/
}

// Address: 0x102cf50d0 | Name: _OSSL_PROVIDER_conf_get_bool
__int64 __fastcall OSSL_PROVIDER_conf_get_bool(__int64 a1, const char *a2, unsigned int a3)
{
  __int64 v5; // rdi
  unsigned int v6; // r15d
  const char **v7; // r13
  const char **v8; // rax
  int v9; // eax
  int v10; // ecx
  __int64 result; // rax
  bool v12; // zf
  int v13; // ecx
  _BYTE *v14; // [rsp+8h] [rbp-88h] BYREF
  const char *v15[10]; // [rsp+10h] [rbp-80h] BYREF

  v14 = nullptr; /*0x102cf50f4*/
  memset(&v15[6], 0, 32); /*0x102cf5112*/
  v15[0] = a2; /*0x102cf5116*/
  v15[1] = (const char *)6; /*0x102cf511a*/
  v15[2] = (const char *)&v14; /*0x102cf5128*/
  v15[3] = (const char *)8; /*0x102cf512c*/
  *(_OWORD *)&v15[4] = 0xFFFFFFFFFFFFFFFFLL; /*0x102cf5134*/
  v5 = *(_QWORD *)(a1 + 72); /*0x102cf513c*/
  if ( v5 != 0 && (int)OPENSSL_sk_num(a1: v5) > 0 ) /*0x102cf514c*/
  {
    v6 = 0; /*0x102cf514e*/
    do /*0x102cf517d*/
    {
      v7 = (const char **)OPENSSL_sk_value(a1: *(_QWORD *)(a1 + 72), a2: v6); /*0x102cf517d*/
      v8 = OSSL_PARAM_locate(a1: v15, a2: *v7); /*0x102cf5186*/
      if ( v8 != nullptr && (unsigned int)OSSL_PARAM_set_utf8_ptr(a1: (__int64)v8, a2: v7[1]) == 0 ) /*0x102cf519e*/
        return a3; /*0x102cf519e*/
    }
    while ( (int)++v6 < (int)OPENSSL_sk_num(a1: *(_QWORD *)(a1 + 72)) ); /*0x102cf517d*/
  }
  LOBYTE(v9) = OSSL_PARAM_modified(a1: (__int64)v15); /*0x102cf51a5*/
  if ( v9 == 0 || v14 == nullptr ) /*0x102cf51bd*/
    return a3; /*0x102cf5295*/
  if ( *v14 == 49 && v14[1] == 0 ) /*0x102cf51d4*/
    return 1; /*0x102cf51d4*/
  v10 = OPENSSL_strcasecmp(a1: (__int64)v14, a2: (__int64)"yes"); /*0x102cf51e6*/
  result = 1; /*0x102cf51e8*/
  if ( v10 == 0 ) /*0x102cf51ef*/
    return result; /*0x102cf51ef*/
  if ( (unsigned int)OPENSSL_strcasecmp(a1: (__int64)v14, a2: (__int64)"true") == 0 ) /*0x102cf520a*/
    return 1; /*0x102cf5299*/
  v12 = (unsigned int)OPENSSL_strcasecmp(a1: (__int64)v14, a2: (__int64)"on") == 0; /*0x102cf5223*/
  result = 1; /*0x102cf5225*/
  if ( v12 ) /*0x102cf522a*/
    return result; /*0x102cf522a*/
  if ( *v14 != 48 || v14[1] != 0 ) /*0x102cf523c*/
  {
    v13 = OPENSSL_strcasecmp(a1: (__int64)v14, a2: (__int64)"no"); /*0x102cf524a*/
    result = 0; /*0x102cf524c*/
    if ( v13 == 0 ) /*0x102cf5250*/
      return result; /*0x102cf5250*/
    if ( (unsigned int)OPENSSL_strcasecmp(a1: (__int64)v14, a2: (__int64)"false") != 0 ) /*0x102cf5267*/
    {
      v12 = (unsigned int)OPENSSL_strcasecmp(a1: (__int64)v14, a2: (__int64)"off") == 0; /*0x102cf527c*/
      result = 0; /*0x102cf527e*/
      if ( !v12 ) /*0x102cf5283*/
        return a3; /*0x102cf5283*/
      return result; /*0x102cf52ae*/
    }
  }
  return 0; /*0x102cf52bd*/
}

// Address: 0x102cf52e0 | Name: _OSSL_PROVIDER_set_default_search_path
__int64 __fastcall OSSL_PROVIDER_set_default_search_path(void **a1, const char *a2)
{
  unsigned int v2; // ebx
  char *v4; // rax
  void **v5; // rdi
  char *v6; // r14
  void **data; // rax
  void **v8; // r15

  v2 = 0; /*0x102cf52ea*/
  if ( a2 == nullptr ) /*0x102cf52ef*/
  {
    v6 = nullptr; /*0x102cf5362*/
    data = ossl_lib_ctx_get_data(a1, a2: 1); /*0x102cf536a*/
    if ( data != nullptr ) /*0x102cf5372*/
    {
LABEL_4:
      v8 = data; /*0x102cf5329*/
      if ( CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)data[3]) ) /*0x102cf5330*/
      {
        CRYPTO_free(a1: v8[5]); /*0x102cf5349*/
        v8[5] = v6; /*0x102cf534e*/
        CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v8[3]); /*0x102cf5356*/
        return 1; /*0x102cf5360*/
      }
LABEL_8:
      CRYPTO_free(a1: v6); /*0x102cf53a4*/
      return v2; /*0x102cf53b3*/
    }
LABEL_7:
    ERR_new(); /*0x102cf5374*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf538c*/
    ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf539f*/
    goto LABEL_8; /*0x102cf539f*/
  }
  v4 = CRYPTO_strdup(str: a2, file: "crypto/provider_core.c", line: 906); /*0x102cf5306*/
  v5 = a1; /*0x102cf530b*/
  v6 = v4; /*0x102cf530e*/
  if ( v4 != nullptr ) /*0x102cf5314*/
  {
    data = ossl_lib_ctx_get_data(a1: v5, a2: 1); /*0x102cf531f*/
    if ( data != nullptr ) /*0x102cf5327*/
      goto LABEL_4; /*0x102cf5327*/
    goto LABEL_7; /*0x102cf5327*/
  }
  return v2; /*0x102cf53be*/
}

// Address: 0x102cf53d0 | Name: _OSSL_PROVIDER_get0_default_search_path
void *__fastcall OSSL_PROVIDER_get0_default_search_path(void **a1)
{
  void **data; // rax
  void **v2; // rbx
  pthread_rwlock_t *v3; // rdi
  void *v4; // rbx

  data = ossl_lib_ctx_get_data(a1, a2: 1); /*0x102cf53db*/
  if ( data != nullptr ) /*0x102cf53e3*/
  {
    v2 = data; /*0x102cf53e5*/
    if ( CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)data[3]) ) /*0x102cf53ec*/
    {
      v3 = (pthread_rwlock_t *)v2[3]; /*0x102cf53f5*/
      v4 = v2[5]; /*0x102cf53f9*/
      CRYPTO_THREAD_unlock(a1: v3); /*0x102cf53fd*/
    }
    else
    {
      return nullptr; /*0x102cf5438*/
    }
  }
  else
  {
    ERR_new(); /*0x102cf5404*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf541c*/
    v4 = nullptr; /*0x102cf5421*/
    ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf5431*/
  }
  return v4; /*0x102cf5441*/
}

// Address: 0x102cf5450 | Name: _ossl_provider_activate
__int64 __fastcall ossl_provider_activate(__int64 a1, unsigned int a2, int a3)
{
  unsigned int v4; // r14d
  int v5; // eax
  void **data; // rax
  void **v7; // r15
  pthread_rwlock_t *v8; // rdi
  char v9; // r15
  int v10; // r14d
  int v11; // r15d
  int v12; // r14d

  if ( a1 != 0 ) /*0x102cf545d*/
  {
    if ( a3 != 0 ) /*0x102cf546a*/
    {
      v4 = 1; /*0x102cf546c*/
      if ( (*(_BYTE *)(a1 + 208) & 1) == 0 ) /*0x102cf5479*/
        return v4; /*0x102cf5479*/
    }
    v4 = 1; /*0x102cf547f*/
    v5 = provider_activate(a1, a2: 1, a3: a2); /*0x102cf548f*/
    if ( v5 > 0 ) /*0x102cf5496*/
    {
      if ( v5 == 1 ) /*0x102cf549f*/
      {
        data = ossl_lib_ctx_get_data(a1: *(void ***)(a1 + 80), a2: 1); /*0x102cf54ae*/
        if ( data != nullptr ) /*0x102cf54b6*/
        {
          v7 = data; /*0x102cf54bc*/
          v4 = 0; /*0x102cf54c8*/
          if ( CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)data[4]) ) /*0x102cf54c3*/
          {
            v8 = (pthread_rwlock_t *)v7[4]; /*0x102cf54d2*/
            v9 = *((_BYTE *)v7 + 72); /*0x102cf54d6*/
            CRYPTO_THREAD_unlock(a1: v8); /*0x102cf54db*/
            v4 = 1; /*0x102cf54e0*/
            if ( (v9 & 2) == 0 ) /*0x102cf54ea*/
            {
              v10 = evp_method_store_cache_flush(a1: *(_QWORD *)(a1 + 80)); /*0x102cf54f5*/
              v11 = v10 + ossl_encoder_store_cache_flush(a1: *(_QWORD *)(a1 + 80)); /*0x102cf5504*/
              v12 = ossl_decoder_store_cache_flush(a1: *(_QWORD *)(a1 + 80)); /*0x102cf5510*/
              return v11 + v12 + (unsigned int)ossl_store_loader_store_cache_flush(a1: *(_QWORD *)(a1 + 80)) == 4; /*0x102cf5528*/
            }
          }
        }
        else
        {
          ERR_new(); /*0x102cf553f*/
          ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf5557*/
          v4 = 0; /*0x102cf555c*/
          ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf556d*/
        }
      }
      return v4; /*0x102cf5538*/
    }
  }
  return 0; /*0x102cf552e*/
}

// Address: 0x102cf5d70 | Name: _ossl_provider_ctx
__int64 __fastcall ossl_provider_ctx(__int64 a1)
{
  if ( a1 != 0 ) /*0x102cf5d77*/
    return *(_QWORD *)(a1 + 216); /*0x102cf5d79*/
  else
    return 0; /*0x102cf5d82*/
}

// Address: 0x102cf5d90 | Name: _ossl_provider_doall_activated
__int64 __fastcall ossl_provider_doall_activated(
        void **a1,
        unsigned int (__fastcall *a2)(__int64, __int64),
        __int64 a3)
{
  unsigned int v5; // r13d
  void **data; // rax
  void **v7; // r12
  __int64 v8; // rax
  void *v9; // rbx
  int v10; // r13d
  int v11; // r15d
  unsigned int v12; // r13d
  __int64 v13; // r14
  int v14; // ebx
  unsigned int v15; // r14d
  __int64 v16; // rax
  __int64 v17; // r14
  __int64 v19; // [rsp+8h] [rbp-48h]
  unsigned int (__fastcall *v20)(__int64, __int64); // [rsp+10h] [rbp-40h]
  void *v21; // [rsp+18h] [rbp-38h]
  int v22; // [rsp+20h] [rbp-30h]
  int v23; // [rsp+20h] [rbp-30h]
  _DWORD v24[11]; // [rsp+24h] [rbp-2Ch] BYREF

  v24[0] = 0; /*0x102cf5da7*/
  v5 = 1; /*0x102cf5dae*/
  data = ossl_lib_ctx_get_data(a1, a2: 1); /*0x102cf5db9*/
  if ( data != nullptr ) /*0x102cf5dc1*/
  {
    v7 = data; /*0x102cf5dc7*/
    v5 = 0; /*0x102cf5dd2*/
    if ( (unsigned int)provider_activate_fallbacks(a1: data) != 0 /*0x102cf5de2*/
      && CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)v7[4]) )
    {
      v8 = OPENSSL_sk_dup(a1: v7[1]); /*0x102cf5df4*/
      if ( v8 != 0 ) /*0x102cf5dfc*/
      {
        v9 = (void *)v8; /*0x102cf5e02*/
        v10 = OPENSSL_sk_num(a1: v8); /*0x102cf5e0d*/
        v21 = v9; /*0x102cf5e12*/
        if ( v10 <= 0 ) /*0x102cf5e16*/
        {
          v14 = 1; /*0x102cf5f02*/
          v11 = 0; /*0x102cf5f07*/
          goto LABEL_23; /*0x102cf5f0a*/
        }
        v20 = a2; /*0x102cf5e1c*/
        v19 = a3; /*0x102cf5e20*/
        v22 = v10; /*0x102cf5e24*/
        v11 = v10; /*0x102cf5e28*/
        while ( 1 ) /*0x102cf5e5c*/
        {
          v12 = v11 - 1; /*0x102cf5e5c*/
          v13 = OPENSSL_sk_value(a1: v9, a2: (unsigned int)(v11 - 1)); /*0x102cf5e6b*/
          v14 = 0; /*0x102cf5e77*/
          if ( !CRYPTO_THREAD_read_lock(a1: *(pthread_rwlock_t **)(v13 + 8)) ) /*0x102cf5e7b*/
            goto LABEL_22; /*0x102cf5e7b*/
          if ( (*(_BYTE *)v13 & 2) != 0 ) /*0x102cf5e85*/
            break; /*0x102cf5e85*/
          v9 = v21; /*0x102cf5e30*/
          OPENSSL_sk_delete(a1: v21, a2: v12); /*0x102cf5e3a*/
          --v22; /*0x102cf5e3f*/
LABEL_8:
          CRYPTO_THREAD_unlock(a1: *(pthread_rwlock_t **)(v13 + 8)); /*0x102cf5e42*/
          --v11; /*0x102cf5e50*/
          if ( v12 + 1 <= 1 ) /*0x102cf5e56*/
          {
            CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v7[4]); /*0x102cf5f11*/
            v14 = 1; /*0x102cf5f16*/
            v10 = v22; /*0x102cf5f1b*/
            v11 = 0; /*0x102cf5f1f*/
            if ( v22 <= 0 ) /*0x102cf5f25*/
              goto LABEL_24; /*0x102cf5f25*/
            v15 = 0; /*0x102cf5f27*/
            while ( 1 ) /*0x102cf5f37*/
            {
              v16 = OPENSSL_sk_value(a1: v21, a2: v15); /*0x102cf5f37*/
              if ( v20(a1: v16, a2: v19) == 0 ) /*0x102cf5f48*/
                break; /*0x102cf5f48*/
              if ( v22 == ++v15 ) /*0x102cf5f54*/
                goto LABEL_24; /*0x102cf5f54*/
            }
            v14 = 0; /*0x102cf6021*/
            goto LABEL_25; /*0x102cf6026*/
          }
        }
        v24[0] = _InterlockedIncrement((volatile signed __int32 *)(v13 + 16)); /*0x102cf5e94*/
        if ( (unsigned int)CRYPTO_atomic_add(a1: (volatile signed __int32 *)(v13 + 32), a2: 1u, a3: v24) != 0 ) /*0x102cf5eb2*/
        {
          v9 = v21; /*0x102cf5eb8*/
          goto LABEL_8; /*0x102cf5ebc*/
        }
        v24[0] = _InterlockedDecrement((volatile signed __int32 *)(v13 + 16)); /*0x102cf5f65*/
        CRYPTO_THREAD_unlock(a1: *(pthread_rwlock_t **)(v13 + 8)); /*0x102cf5f6e*/
LABEL_22:
        v10 = v22; /*0x102cf5f73*/
LABEL_23:
        CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v7[4]); /*0x102cf5f77*/
LABEL_24:
        if ( v11 < v10 ) /*0x102cf5f84*/
        {
LABEL_25:
          v23 = v10; /*0x102cf5f8a*/
          while ( 1 ) /*0x102cf5fac*/
          {
            v17 = OPENSSL_sk_value(a1: v21, a2: (unsigned int)v11); /*0x102cf5fac*/
            v5 = 0; /*0x102cf5fc8*/
            if ( (unsigned int)CRYPTO_atomic_add(a1: (volatile signed __int32 *)(v17 + 32), a2: 0xFFFFFFFF, a3: v24) != 0 ) /*0x102cf5fd0*/
              break; /*0x102cf5fd0*/
LABEL_26:
            ++v11; /*0x102cf5f90*/
            v14 = v5; /*0x102cf5f93*/
            if ( v23 == v11 ) /*0x102cf5f9a*/
              goto LABEL_35; /*0x102cf5f9a*/
          }
          if ( v24[0] <= 0 ) /*0x102cf5fd6*/
          {
            v5 = 0; /*0x102cf5ff5*/
            if ( (unsigned int)CRYPTO_atomic_add(a1: (volatile signed __int32 *)(v17 + 32), a2: 1u, a3: v24) == 0 ) /*0x102cf5ffa*/
              goto LABEL_31; /*0x102cf5ffa*/
            provider_deactivate(a1: v17, a2: 0, a3: 1); /*0x102cf601a*/
          }
          v5 = v14; /*0x102cf5fd8*/
LABEL_31:
          v24[0] = _InterlockedDecrement((volatile signed __int32 *)(v17 + 16)); /*0x102cf5ffc*/
          goto LABEL_26; /*0x102cf600e*/
        }
        v5 = v14; /*0x102cf602c*/
LABEL_35:
        OPENSSL_sk_free(a1: v21); /*0x102cf602f*/
      }
      else
      {
        CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v7[4]); /*0x102cf5ef8*/
      }
    }
  }
  else
  {
    ERR_new(); /*0x102cf5ebe*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf5ed6*/
    ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf5ee9*/
  }
  return v5; /*0x102cf603b*/
}

// Address: 0x102cf61d0 | Name: _OSSL_PROVIDER_available
_BOOL8 __fastcall OSSL_PROVIDER_available(void **a1, __int64 a2)
{
  void **data; // rax
  _BOOL4 v5; // ebx
  __int64 v6; // rax
  __int64 v7; // r14

  data = ossl_lib_ctx_get_data(a1, a2: 1); /*0x102cf61e5*/
  if ( data != nullptr ) /*0x102cf61ed*/
  {
    v5 = false; /*0x102cf61f7*/
    if ( (unsigned int)provider_activate_fallbacks(a1: data) != 0 ) /*0x102cf61fb*/
    {
      v6 = ossl_provider_find(a1, a2); /*0x102cf6203*/
      if ( v6 != 0 ) /*0x102cf620b*/
      {
        v7 = v6; /*0x102cf620d*/
        if ( CRYPTO_THREAD_read_lock(a1: *(pthread_rwlock_t **)(v6 + 8)) ) /*0x102cf6214*/
        {
          v5 = (*(_DWORD *)v7 & 2) != 0; /*0x102cf6222*/
          CRYPTO_THREAD_unlock(a1: *(pthread_rwlock_t **)(v7 + 8)); /*0x102cf6229*/
          ossl_provider_free(a1: v7); /*0x102cf6231*/
        }
      }
    }
  }
  else
  {
    ERR_new(); /*0x102cf6238*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf6250*/
    v5 = false; /*0x102cf6255*/
    ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf6265*/
  }
  return v5; /*0x102cf6270*/
}

// Address: 0x102cf6280 | Name: _ossl_provider_name
__int64 __fastcall ossl_provider_name(__int64 a1)
{
  return *(_QWORD *)(a1 + 40); /*0x102cf6288*/
}

// Address: 0x102cf6290 | Name: _ossl_provider_dso
__int64 __fastcall ossl_provider_dso(__int64 a1)
{
  return *(_QWORD *)(a1 + 56); /*0x102cf6298*/
}

// Address: 0x102cf62a0 | Name: _ossl_provider_module_name
const char *__fastcall ossl_provider_module_name(__int64 a1)
{
  return DSO_get_filename(dso: *(DSO **)(a1 + 56)); /*0x102cf62a8*/
}

// Address: 0x102cf62b0 | Name: _ossl_provider_module_path
const char *__fastcall ossl_provider_module_path(__int64 a1)
{
  return DSO_get_filename(dso: *(DSO **)(a1 + 56)); /*0x102cf62b8*/
}

// Address: 0x102cf62c0 | Name: _ossl_provider_get0_dispatch
__int64 __fastcall ossl_provider_get0_dispatch(__int64 a1)
{
  if ( a1 != 0 ) /*0x102cf62c7*/
    return *(_QWORD *)(a1 + 224); /*0x102cf62c9*/
  else
    return 0; /*0x102cf62d2*/
}

// Address: 0x102cf62e0 | Name: _ossl_provider_libctx
__int64 __fastcall ossl_provider_libctx(__int64 a1)
{
  if ( a1 != 0 ) /*0x102cf62e7*/
    return *(_QWORD *)(a1 + 80); /*0x102cf62e9*/
  else
    return 0; /*0x102cf62ef*/
}

// Address: 0x102cf6300 | Name: _ossl_provider_gettable_params
__int64 __fastcall ossl_provider_gettable_params(__int64 a1)
{
  __int64 (__fastcall *v1)(_QWORD); // rax

  v1 = *(__int64 (__fastcall **)(_QWORD))(a1 + 120); /*0x102cf6304*/
  if ( v1 != nullptr ) /*0x102cf630b*/
    return v1(a1: *(_QWORD *)(a1 + 216)); /*0x102cf6315*/
  else
    return 0; /*0x102cf6317*/
}

// Address: 0x102cf6320 | Name: _ossl_provider_get_params
__int64 __fastcall ossl_provider_get_params(__int64 a1)
{
  __int64 (__fastcall *v1)(_QWORD); // rax

  v1 = *(__int64 (__fastcall **)(_QWORD))(a1 + 128); /*0x102cf6324*/
  if ( v1 != nullptr ) /*0x102cf632e*/
    return v1(a1: *(_QWORD *)(a1 + 216)); /*0x102cf6338*/
  else
    return 0; /*0x102cf633a*/
}

// Address: 0x102cf6340 | Name: _ossl_provider_self_test
__int64 __fastcall ossl_provider_self_test(__int64 a1)
{
  __int64 (__fastcall *v1)(_QWORD); // rax
  __int64 result; // rax

  v1 = *(__int64 (__fastcall **)(_QWORD))(a1 + 144); /*0x102cf6340*/
  if ( v1 == nullptr ) /*0x102cf634a*/
    return 1; /*0x102cf6369*/
  result = v1(a1: *(_QWORD *)(a1 + 216)); /*0x102cf635c*/
  if ( (_DWORD)result == 0 ) /*0x102cf6360*/
  {
    provider_remove_store_methods(a1); /*0x102cf6372*/
    return 0; /*0x102cf6377*/
  }
  return result; /*0x102cf6368*/
}

// Address: 0x102cf6380 | Name: _ossl_provider_random_bytes
__int64 __fastcall ossl_provider_random_bytes(__int64 a1)
{
  __int64 (__fastcall *v1)(_QWORD); // rax

  v1 = *(__int64 (__fastcall **)(_QWORD))(a1 + 152); /*0x102cf6384*/
  if ( v1 != nullptr ) /*0x102cf638e*/
    return v1(a1: *(_QWORD *)(a1 + 216)); /*0x102cf6398*/
  else
    return 0; /*0x102cf639a*/
}

// Address: 0x102cf63a0 | Name: _ossl_provider_get_capabilities
__int64 __fastcall ossl_provider_get_capabilities(__int64 a1)
{
  __int64 (__fastcall *v1)(_QWORD); // rax

  v1 = *(__int64 (__fastcall **)(_QWORD))(a1 + 136); /*0x102cf63a4*/
  if ( v1 != nullptr ) /*0x102cf63ae*/
    return v1(a1: *(_QWORD *)(a1 + 216)); /*0x102cf63b8*/
  else
    return 1; /*0x102cf63ba*/
}

// Address: 0x102cf63d0 | Name: _ossl_provider_query_operation
__int64 __fastcall ossl_provider_query_operation(__int64 a1)
{
  __int64 (__fastcall *v1)(_QWORD); // rax

  v1 = *(__int64 (__fastcall **)(_QWORD))(a1 + 160); /*0x102cf63d4*/
  if ( v1 != nullptr ) /*0x102cf63de*/
    return v1(a1: *(_QWORD *)(a1 + 216)); /*0x102cf63e8*/
  else
    return 0; /*0x102cf63ea*/
}

// Address: 0x102cf63f0 | Name: _ossl_provider_unquery_operation
__int64 (__fastcall *__fastcall ossl_provider_unquery_operation(__int64 a1))(_QWORD)
{
  __int64 (__fastcall *result)(_QWORD); // rax

  result = *(__int64 (__fastcall **)(_QWORD))(a1 + 168); /*0x102cf63f4*/
  if ( result != nullptr ) /*0x102cf63fe*/
    return (__int64 (__fastcall *)(_QWORD))result(a1: *(_QWORD *)(a1 + 216)); /*0x102cf6408*/
  return result; /*0x102cf640a*/
}

// Address: 0x102cf6410 | Name: _ossl_provider_set_operation_bit
__int64 __fastcall ossl_provider_set_operation_bit(__int64 a1, unsigned __int64 a2)
{
  char v4; // r12
  unsigned __int64 v5; // r14
  unsigned __int64 v6; // r15
  void *v7; // rax
  unsigned int v8; // r14d

  v4 = 1 << (a2 & 7); /*0x102cf642a*/
  if ( !CRYPTO_THREAD_write_lock(a1: *(pthread_rwlock_t **)(a1 + 192)) ) /*0x102cf643b*/
    return 0; /*0x102cf64b3*/
  v5 = a2 >> 3; /*0x102cf643d*/
  if ( *(_QWORD *)(a1 + 184) <= v5 ) /*0x102cf6448*/
  {
    v6 = v5 + 1; /*0x102cf6451*/
    v7 = CRYPTO_realloc(addr: *(void **)(a1 + 176), num: (int)v5 + 1, file: "crypto/provider_core.c", line: 2013); /*0x102cf6464*/
    if ( v7 == nullptr ) /*0x102cf646c*/
    {
      v8 = 0; /*0x102cf64c2*/
      goto LABEL_6; /*0x102cf64c5*/
    }
    *(_QWORD *)(a1 + 176) = v7; /*0x102cf646e*/
    __bzero(a1: (__int64)v7 + *(_QWORD *)(a1 + 184), a2: v6 - *(_QWORD *)(a1 + 184)); /*0x102cf6488*/
    *(_QWORD *)(a1 + 184) = v6; /*0x102cf648d*/
  }
  *(_BYTE *)(*(_QWORD *)(a1 + 176) + v5) |= v4; /*0x102cf649b*/
  v8 = 1; /*0x102cf649f*/
LABEL_6:
  CRYPTO_THREAD_unlock(a1: *(pthread_rwlock_t **)(a1 + 192)); /*0x102cf64a5*/
  return v8; /*0x102cf64b9*/
}

// Address: 0x102cf64d0 | Name: _ossl_provider_test_operation_bit
__int64 __fastcall ossl_provider_test_operation_bit(__int64 a1, unsigned __int64 a2, _DWORD *a3)
{
  unsigned __int8 v4; // r12
  unsigned __int64 v7; // r15

  v4 = 1 << (a2 & 7); /*0x102cf64e7*/
  if ( a3 == nullptr ) /*0x102cf64ed*/
  {
    ossl_provider_test_operation_bit_cold_1(); /*0x102cf653e*/
    return 0; /*0x102cf653e*/
  }
  *a3 = 0; /*0x102cf64f5*/
  if ( !CRYPTO_THREAD_read_lock(a1: *(pthread_rwlock_t **)(a1 + 192)) ) /*0x102cf6509*/
    return 0; /*0x102cf6543*/
  v7 = a2 >> 3; /*0x102cf650b*/
  if ( *(_QWORD *)(a1 + 184) > v7 ) /*0x102cf6516*/
    *a3 = (v4 & *(_BYTE *)(*(_QWORD *)(a1 + 176) + v7)) != 0; /*0x102cf6528*/
  CRYPTO_THREAD_unlock(a1: *(pthread_rwlock_t **)(a1 + 192)); /*0x102cf6532*/
  return 1; /*0x102cf6545*/
}

// Address: 0x102cf6550 | Name: _ossl_provider_get_parent
__int64 __fastcall ossl_provider_get_parent(__int64 a1)
{
  return *(_QWORD *)(a1 + 200); /*0x102cf655b*/
}

// Address: 0x102cf6560 | Name: _ossl_provider_is_child
__int64 __fastcall ossl_provider_is_child(__int64 a1)
{
  return *(_BYTE *)(a1 + 208) & 1; /*0x102cf656e*/
}

// Address: 0x102cf6570 | Name: _ossl_provider_set_child
__int64 __fastcall ossl_provider_set_child(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a1 + 200) = a2; /*0x102cf6574*/
  *(_BYTE *)(a1 + 208) |= 1u; /*0x102cf657b*/
  return 1; /*0x102cf6587*/
}

// Address: 0x102cf6590 | Name: _ossl_provider_default_props_update
__int64 __fastcall ossl_provider_default_props_update(void **a1, __int64 a2)
{
  void **data; // rax
  void **v4; // r14
  int v5; // eax
  int v6; // r15d
  unsigned int i; // r12d
  __int64 v8; // rax
  unsigned int v9; // ebx

  data = ossl_lib_ctx_get_data(a1, a2: 1); /*0x102cf65a3*/
  if ( data != nullptr ) /*0x102cf65ab*/
  {
    v4 = data; /*0x102cf65ad*/
    if ( CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)data[4]) ) /*0x102cf65b4*/
    {
      v5 = OPENSSL_sk_num(a1: v4[2]); /*0x102cf65c1*/
      if ( v5 > 0 ) /*0x102cf65c8*/
      {
        v6 = v5; /*0x102cf65ca*/
        for ( i = 0; i != v6; ++i ) /*0x102cf65cd*/
        {
          v8 = OPENSSL_sk_value(a1: v4[2], a2: i); /*0x102cf65d7*/
          (*(void (__fastcall **)(__int64, _QWORD))(v8 + 24))(a1: a2, a2: *(_QWORD *)(v8 + 32)); /*0x102cf65e3*/
        }
      }
      CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v4[4]); /*0x102cf65f2*/
      return 1; /*0x102cf65f7*/
    }
    else
    {
      return 0; /*0x102cf6632*/
    }
  }
  else
  {
    ERR_new(); /*0x102cf65fe*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf6616*/
    v9 = 0; /*0x102cf661b*/
    ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf662b*/
  }
  return v9; /*0x102cf6636*/
}

// Address: 0x102cf68d0 | Name: _ossl_provider_register_child_cb
__int64 __fastcall ossl_provider_register_child_cb(
        __int64 a1,
        unsigned int (__fastcall *a2)(__int64, __int64),
        void (__fastcall *a3)(__int64, __int64),
        void (__fastcall *a4)(char *, __int64),
        __int64 a5)
{
  void **v8; // r12
  void **data; // rax
  void **v10; // rbx
  _QWORD *v11; // rax
  unsigned int v12; // r15d
  void *v13; // r13
  int v14; // r13d
  char *global_properties_str; // rax
  char *v16; // r15
  int v17; // r14d
  __int64 v18; // r15
  char v19; // r12
  __int64 v20; // rax
  void (__fastcall *v24)(__int64, __int64); // [rsp+10h] [rbp-40h]
  void *v25; // [rsp+18h] [rbp-38h]

  v8 = *(void ***)(a1 + 80); /*0x102cf68f2*/
  data = ossl_lib_ctx_get_data(a1: v8, a2: 1); /*0x102cf68fe*/
  if ( data != nullptr ) /*0x102cf6906*/
  {
    v10 = data; /*0x102cf690c*/
    v24 = a3; /*0x102cf690f*/
    v11 = CRYPTO_malloc(num: 40, file: "crypto/provider_core.c", line: 2119); /*0x102cf6924*/
    v12 = 0; /*0x102cf6929*/
    if ( v11 != nullptr ) /*0x102cf692f*/
    {
      *v11 = a1; /*0x102cf6935*/
      v11[1] = a2; /*0x102cf693c*/
      v13 = v11; /*0x102cf6940*/
      v11[2] = v24; /*0x102cf6947*/
      v11[3] = a4; /*0x102cf694b*/
      v11[4] = a5; /*0x102cf6953*/
      if ( CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)v10[4]) ) /*0x102cf695b*/
      {
        v25 = v13; /*0x102cf6968*/
        v14 = 0; /*0x102cf696c*/
        global_properties_str = evp_get_global_properties_str(a1: (__int64)v8, a2: 0); /*0x102cf6974*/
        if ( global_properties_str != nullptr ) /*0x102cf697c*/
        {
          v16 = global_properties_str; /*0x102cf697e*/
          a4(a1: global_properties_str, a2: a5); /*0x102cf6988*/
          CRYPTO_free(a1: v16); /*0x102cf699a*/
        }
        v17 = OPENSSL_sk_num(a1: v10[1]); /*0x102cf69a8*/
        if ( v17 > 0 ) /*0x102cf69ad*/
        {
          v14 = 0; /*0x102cf69af*/
          while ( 1 ) /*0x102cf69d8*/
          {
            v18 = OPENSSL_sk_value(a1: v10[1], a2: (unsigned int)v14); /*0x102cf69d8*/
            if ( !CRYPTO_THREAD_read_lock(a1: *(pthread_rwlock_t **)(v18 + 8)) ) /*0x102cf69df*/
              break; /*0x102cf69df*/
            v19 = *(_BYTE *)v18; /*0x102cf69ec*/
            CRYPTO_THREAD_unlock(a1: *(pthread_rwlock_t **)(v18 + 8)); /*0x102cf69f0*/
            if ( (v19 & 2) != 0 && a2(a1: v18, a2: a5) == 0 ) /*0x102cf6a07*/
              break; /*0x102cf6a07*/
            if ( v17 == ++v14 ) /*0x102cf69c6*/
            {
              v14 = v17; /*0x102cf6a5e*/
              goto LABEL_17; /*0x102cf6a5e*/
            }
          }
        }
        if ( v14 == v17 ) /*0x102cf6a0c*/
        {
LABEL_17:
          v12 = OPENSSL_sk_push(a1: v10[2], a2: v25); /*0x102cf6a61*/
          if ( v14 == v17 && (int)v12 > 0 ) /*0x102cf6a7a*/
          {
LABEL_21:
            CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v10[4]); /*0x102cf6ad3*/
            return v12; /*0x102cf6ad7*/
          }
        }
        if ( v14 >= 0 ) /*0x102cf6a8f*/
        {
          do /*0x102cf6ab9*/
          {
            v20 = OPENSSL_sk_value(a1: v10[1], a2: (unsigned int)v14); /*0x102cf6aa7*/
            v24(a1: v20, a2: a5); /*0x102cf6ab2*/
          }
          while ( v14-- != 0 ); /*0x102cf6ab9*/
        }
        CRYPTO_free(a1: v25); /*0x102cf6acb*/
        v12 = 0; /*0x102cf6ad0*/
        goto LABEL_21; /*0x102cf6ad0*/
      }
      CRYPTO_free(a1: v13); /*0x102cf6a57*/
    }
  }
  else
  {
    ERR_new(); /*0x102cf6a10*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf6a28*/
    v12 = 0; /*0x102cf6a2d*/
    ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf6a3e*/
  }
  return v12; /*0x102cf6adf*/
}

// Address: 0x102cf6af0 | Name: _ossl_provider_deregister_child_cb
__int64 __fastcall ossl_provider_deregister_child_cb(__int64 a1)
{
  void **data; // rax
  void **v3; // rbx
  __int64 result; // rax
  int v5; // eax
  int v6; // r12d
  unsigned int v7; // r15d
  _QWORD *v8; // rax
  void *v9; // r14

  data = ossl_lib_ctx_get_data(a1: *(void ***)(a1 + 80), a2: 1); /*0x102cf6b07*/
  if ( data != nullptr ) /*0x102cf6b0f*/
  {
    v3 = data; /*0x102cf6b11*/
    result = CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)data[4]); /*0x102cf6b18*/
    if ( (_DWORD)result != 0 ) /*0x102cf6b1f*/
    {
      v5 = OPENSSL_sk_num(a1: v3[2]); /*0x102cf6b25*/
      if ( v5 > 0 ) /*0x102cf6b2c*/
      {
        v6 = v5; /*0x102cf6b32*/
        v7 = 0; /*0x102cf6b35*/
        while ( 1 ) /*0x102cf6b47*/
        {
          v8 = (_QWORD *)OPENSSL_sk_value(a1: v3[2], a2: v7); /*0x102cf6b47*/
          if ( *v8 == a1 ) /*0x102cf6b4f*/
            break; /*0x102cf6b4f*/
          if ( v6 == ++v7 ) /*0x102cf6b57*/
            return CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v3[4]); /*0x102cf6b57*/
        }
        v9 = v8; /*0x102cf6ba3*/
        OPENSSL_sk_delete(a1: v3[2], a2: v7); /*0x102cf6ba6*/
        CRYPTO_free(a1: v9); /*0x102cf6bba*/
      }
      return CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)v3[4]); /*0x102cf6bbf*/
    }
  }
  else
  {
    ERR_new(); /*0x102cf6b5b*/
    ERR_set_debug(__s: "crypto/provider_core.c", a2: 335, a3: "get_provider_store"); /*0x102cf6b73*/
    return ERR_set_error(a1: 15, a2: 786691, a3: 0); /*0x102cf6b8e*/
  }
  return result; /*0x102cf6b86*/
}

// Address: 0x102cf6db0 | Name: _ossl_punycode_decode
__int64 __fastcall ossl_punycode_decode(__int64 a1, unsigned __int64 a2, __int64 a3, _DWORD *a4)
{
  unsigned __int64 v5; // rdi
  __int64 v6; // rax
  unsigned int v7; // r13d
  unsigned int v8; // r9d
  unsigned __int64 v9; // r8
  unsigned __int64 v10; // rcx
  __int64 i; // rax
  int v12; // edi
  unsigned int v13; // r13d
  int v14; // edi
  unsigned int v15; // r12d
  unsigned int v16; // edx
  unsigned __int64 v17; // rax
  unsigned int v18; // ebx
  unsigned int v19; // r8d
  unsigned int v20; // edi
  int v21; // r10d
  signed int v22; // r10d
  unsigned int v23; // eax
  unsigned __int64 v24; // rbx
  unsigned int v25; // edi
  unsigned __int64 v26; // r11
  int v27; // r12d
  unsigned int v28; // eax
  unsigned int v29; // r8d
  bool v30; // cc
  unsigned int v31; // edi
  int v32; // r15d
  unsigned __int64 v35; // [rsp+10h] [rbp-50h]
  unsigned __int64 v37; // [rsp+20h] [rbp-40h]
  unsigned __int64 v38; // [rsp+28h] [rbp-38h]
  int v39; // [rsp+34h] [rbp-2Ch]

  v5 = (unsigned int)*a4; /*0x102cf6dc8*/
  if ( a2 != 0 ) /*0x102cf6dcd*/
  {
    v6 = 0; /*0x102cf6dcf*/
    v7 = 0; /*0x102cf6dd1*/
    do /*0x102cf6df1*/
    {
      if ( *(_BYTE *)(a1 + v6) == 45 ) /*0x102cf6de5*/
        v7 = v6; /*0x102cf6de5*/
      ++v6; /*0x102cf6de9*/
    }
    while ( (unsigned int)v6 < a2 ); /*0x102cf6df1*/
    if ( v7 != 0 ) /*0x102cf6df6*/
    {
      v8 = 0; /*0x102cf6df8*/
      if ( v7 > (unsigned int)v5 ) /*0x102cf6dfe*/
        return v8; /*0x102cf6dfe*/
      v9 = (unsigned int)*a4; /*0x102cf6e04*/
      v10 = v7; /*0x102cf6e07*/
      v8 = 0; /*0x102cf6e0a*/
      for ( i = 0; i != v7; *(_DWORD *)(a3 + 4 * i++) = v12 ) /*0x102cf6e0d*/
      {
        v12 = *(char *)(a1 + i); /*0x102cf6e10*/
        if ( v12 < 0 ) /*0x102cf6e17*/
          return v8; /*0x102cf6e17*/
      }
      v13 = v7 + 1; /*0x102cf6e28*/
      v5 = v9; /*0x102cf6e2b*/
      if ( v13 < a2 ) /*0x102cf6e34*/
      {
LABEL_15:
        v37 = v5; /*0x102cf6e56*/
        v15 = 72; /*0x102cf6e5e*/
        v39 = 128; /*0x102cf6e64*/
        v16 = 0; /*0x102cf6e6b*/
        while ( 1 ) /*0x102cf6e6d*/
        {
          v17 = v13; /*0x102cf6e6d*/
          if ( v13 >= a2 ) /*0x102cf6e73*/
            return 0; /*0x102cf707c*/
          ++v13; /*0x102cf6e84*/
          v18 = 1; /*0x102cf6e88*/
          v19 = 36; /*0x102cf6e8d*/
          v20 = v16; /*0x102cf6e96*/
          while ( 1 ) /*0x102cf6ea0*/
          {
            v21 = *(unsigned __int8 *)(a1 + v17); /*0x102cf6ea0*/
            if ( (unsigned __int8)(v21 - 65) > 0x19u ) /*0x102cf6eab*/
            {
              if ( (unsigned __int8)(v21 - 97) > 0x19u ) /*0x102cf6ec6*/
              {
                if ( (unsigned __int8)(v21 - 48) > 9u ) /*0x102cf6ee6*/
                  return 0; /*0x102cf6ee6*/
                v22 = v21 - 22; /*0x102cf6eec*/
                if ( v22 < 0 ) /*0x102cf6ef3*/
                  return 0; /*0x102cf6ef3*/
              }
              else
              {
                v22 = v21 - 97; /*0x102cf6ec8*/
                if ( v22 < 0 ) /*0x102cf6ecf*/
                  return 0; /*0x102cf6ecf*/
              }
            }
            else
            {
              v22 = v21 - 65; /*0x102cf6ead*/
              if ( v22 < 0 ) /*0x102cf6eb4*/
                return 0; /*0x102cf6eb4*/
            }
            v8 = 0; /*0x102cf6efd*/
            if ( v22 > ~v20 / v18 ) /*0x102cf6f07*/
              return v8; /*0x102cf6f07*/
            v20 += v18 * v22; /*0x102cf6f13*/
            v23 = v19 - v15; /*0x102cf6f15*/
            if ( v19 >= v15 + 26 ) /*0x102cf6f21*/
              v23 = 26; /*0x102cf6f21*/
            if ( v19 <= v15 ) /*0x102cf6f2c*/
              v23 = 1; /*0x102cf6f2c*/
            if ( v22 < v23 ) /*0x102cf6f32*/
              break; /*0x102cf6f32*/
            if ( is_mul_ok(v18, 36 - v23) ) /*0x102cf6f40*/
            {
              v18 *= 36 - v23; /*0x102cf6f48*/
              v19 += 36; /*0x102cf6f4c*/
              v17 = v13++; /*0x102cf6f50*/
              if ( v17 < a2 ) /*0x102cf6f59*/
                continue; /*0x102cf6f59*/
            }
            return v8; /*0x102cf6f59*/
          }
          v24 = v20; /*0x102cf6f64*/
          if ( v16 != 0 ) /*0x102cf6f6b*/
            v25 = (v20 - v16) >> 1; /*0x102cf6f6f*/
          else
            v25 = v20 / 0x2BC; /*0x102cf6f7a*/
          v26 = v10 + 1; /*0x102cf6f88*/
          v27 = 0; /*0x102cf6f8c*/
          v28 = v25 + v25 / ((int)v10 + 1); /*0x102cf6f96*/
          if ( v28 < 0x1C8 ) /*0x102cf6f9d*/
          {
            LOWORD(v29) = v25 + v25 / ((int)v10 + 1); /*0x102cf6fea*/
            if ( v24 < v26 ) /*0x102cf6ff0*/
              goto LABEL_44; /*0x102cf6ff0*/
          }
          else
          {
            v27 = 0; /*0x102cf6f9f*/
            do /*0x102cf6fd6*/
            {
              v29 = v28 / 0x23; /*0x102cf6fc6*/
              v27 += 36; /*0x102cf6fca*/
              v30 = v28 <= 0x3E57; /*0x102cf6fce*/
              v28 /= 0x23u; /*0x102cf6fd3*/
            }
            while ( !v30 ); /*0x102cf6fd6*/
            if ( v24 < v26 ) /*0x102cf6fdb*/
            {
LABEL_44:
              v31 = 0; /*0x102cf6ff2*/
              goto LABEL_45; /*0x102cf6ff2*/
            }
          }
          v31 = (unsigned int)v24 / (unsigned int)v26; /*0x102cf6fe4*/
          v24 = (unsigned int)v24 % (unsigned int)v26; /*0x102cf6fe6*/
LABEL_45:
          v8 = 0; /*0x102cf6ff4*/
          if ( v31 > ~v39 || v10 >= v37 ) /*0x102cf7003*/
            return v8; /*0x102cf7003*/
          v15 = (unsigned __int16)((unsigned __int16)(36 * v29) / (unsigned __int16)(v29 + 38)) + v27; /*0x102cf701d*/
          v32 = v31 + v39; /*0x102cf7024*/
          v38 = a2; /*0x102cf703e*/
          v35 = v10 + 1; /*0x102cf7048*/
          memmove(__dst: (void *)(a3 + 4 * v24 + 4), __src: (const void *)(a3 + 4 * v24), __len: 4 * (v10 - v24)); /*0x102cf704c*/
          v14 = v35; /*0x102cf7051*/
          a2 = v38; /*0x102cf7055*/
          v39 = v32; /*0x102cf7059*/
          *(_DWORD *)(a3 + 4 * v24) = v32; /*0x102cf7061*/
          v16 = v24 + 1; /*0x102cf7065*/
          v10 = v35; /*0x102cf706b*/
          if ( v13 >= v38 ) /*0x102cf7071*/
            goto LABEL_13; /*0x102cf7071*/
        }
      }
LABEL_12:
      v14 = v10; /*0x102cf6e36*/
LABEL_13:
      *a4 = v14; /*0x102cf6e38*/
      return 1; /*0x102cf7082*/
    }
  }
  v13 = 0; /*0x102cf6e49*/
  v10 = 0; /*0x102cf6e4c*/
  if ( a2 == 0 ) /*0x102cf6e54*/
    goto LABEL_12; /*0x102cf6e54*/
  goto LABEL_15; /*0x102cf6e54*/
}

// Address: 0x102cf70a0 | Name: _ossl_self_test_set_callback_new
void *ossl_self_test_set_callback_new()
{
  return CRYPTO_zalloc(__size: 0x10u, __s: "crypto/self_test_core.c", line: 38); /*0x102cf70b5*/
}

// Address: 0x102cf70c0 | Name: _ossl_self_test_set_callback_free
void __fastcall ossl_self_test_set_callback_free(void *a1)
{
  CRYPTO_free(a1); /*0x102cf70d1*/
}

// Address: 0x102cf70e0 | Name: _OSSL_SELF_TEST_set_callback
void **__fastcall OSSL_SELF_TEST_set_callback(void **a1, void *a2, void *a3)
{
  void **result; // rax

  result = ossl_lib_ctx_get_data(a1, a2: 12); /*0x102cf70f2*/
  if ( result != nullptr ) /*0x102cf70fa*/
  {
    *result = a2; /*0x102cf70fc*/
    result[1] = a3; /*0x102cf70ff*/
  }
  return result; /*0x102cf7103*/
}

// Address: 0x102cf7110 | Name: _OSSL_SELF_TEST_get_callback
void **__fastcall OSSL_SELF_TEST_get_callback(void **a1, _QWORD *a2, void ***a3)
{
  void **result; // rax
  void *v6; // rcx

  result = ossl_lib_ctx_get_data(a1, a2: 12); /*0x102cf7122*/
  if ( a2 != nullptr ) /*0x102cf712a*/
  {
    if ( result != nullptr ) /*0x102cf712f*/
      v6 = *result; /*0x102cf7131*/
    else
      v6 = nullptr; /*0x102cf7136*/
    *a2 = v6; /*0x102cf7138*/
  }
  if ( a3 != nullptr ) /*0x102cf713e*/
  {
    if ( result != nullptr ) /*0x102cf7143*/
      result = (void **)result[1]; /*0x102cf7145*/
    else
      result = nullptr; /*0x102cf714b*/
    *a3 = result; /*0x102cf714d*/
  }
  return result; /*0x102cf7150*/
}

// Address: 0x102cf7160 | Name: _OSSL_SELF_TEST_new
_QWORD *__fastcall OSSL_SELF_TEST_new(__int64 a1, __int64 a2)
{
  _QWORD *v4; // rax
  _QWORD *v5; // rbx
  __int128 v6; // xmm0
  __int128 v7; // xmm0
  __int128 v8; // xmm0
  __int64 v9; // rax
  __int64 v10; // r14
  __int128 v11; // xmm0
  __int128 v13; // [rsp+0h] [rbp-40h] BYREF
  __int128 v14; // [rsp+10h] [rbp-30h]
  __int64 v15; // [rsp+20h] [rbp-20h]

  v4 = CRYPTO_zalloc(__size: 0xC8u, __s: "crypto/self_test_core.c", line: 95); /*0x102cf7184*/
  v5 = v4; /*0x102cf7189*/
  if ( v4 != nullptr ) /*0x102cf718f*/
  {
    v4[3] = a1; /*0x102cf7195*/
    v4[24] = a2; /*0x102cf7199*/
    *v4 = ""; /*0x102cf71a7*/
    v4[1] = ""; /*0x102cf71aa*/
    v4[2] = ""; /*0x102cf71ae*/
    if ( a1 != 0 ) /*0x102cf71b5*/
    {
      OSSL_PARAM_construct_utf8_string(a1: (__int64)&v13, a2: (__int64)"st-phase", a3: "", a4: 0); /*0x102cf71d2*/
      v5[8] = v15; /*0x102cf71db*/
      v6 = v13; /*0x102cf71df*/
      *((_OWORD *)v5 + 3) = v14; /*0x102cf71e7*/
      *((_OWORD *)v5 + 2) = v6; /*0x102cf71eb*/
      OSSL_PARAM_construct_utf8_string(a1: (__int64)&v13, a2: (__int64)"st-type", a3: "", a4: 0); /*0x102cf71ff*/
      v5[13] = v15; /*0x102cf7208*/
      v7 = v13; /*0x102cf720c*/
      *(_OWORD *)(v5 + 11) = v14; /*0x102cf7214*/
      *(_OWORD *)(v5 + 9) = v7; /*0x102cf7218*/
      OSSL_PARAM_construct_utf8_string(a1: (__int64)&v13, a2: (__int64)"st-desc", a3: "", a4: 0); /*0x102cf722c*/
      v5[18] = v15; /*0x102cf7235*/
      v8 = v13; /*0x102cf723c*/
      *((_OWORD *)v5 + 8) = v14; /*0x102cf7244*/
      *((_OWORD *)v5 + 7) = v8; /*0x102cf724b*/
      v9 = 3; /*0x102cf724f*/
    }
    else
    {
      v9 = 0; /*0x102cf7256*/
    }
    v10 = 5 * v9; /*0x102cf7258*/
    OSSL_PARAM_construct_end(a1: (__int64)&v13); /*0x102cf7260*/
    v5[v10 + 8] = v15; /*0x102cf7269*/
    v11 = v13; /*0x102cf726e*/
    *(_OWORD *)&v5[v10 + 6] = v14; /*0x102cf7276*/
    *(_OWORD *)&v5[v10 + 4] = v11; /*0x102cf727c*/
  }
  return v5; /*0x102cf7285*/
}

// Address: 0x102cf7290 | Name: _OSSL_SELF_TEST_free
void __fastcall OSSL_SELF_TEST_free(void *a1)
{
  CRYPTO_free(a1); /*0x102cf72a1*/
}

// Address: 0x102cf72b0 | Name: _OSSL_SELF_TEST_onbegin
__int64 __fastcall OSSL_SELF_TEST_onbegin(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v3; // rbx
  __int128 v5; // xmm0
  __int128 v6; // xmm0
  __int128 v7; // xmm0
  __int128 v8; // xmm0
  __int64 result; // rax
  _QWORD v10[8]; // [rsp-40h] [rbp-40h] BYREF

  if ( a1 != 0 && *(_QWORD *)(a1 + 24) != 0 ) /*0x102cf72be*/
  {
    *(_QWORD *)a1 = "Start"; /*0x102cf72d6*/
    *(_QWORD *)(a1 + 8) = a2; /*0x102cf72d9*/
    *(_QWORD *)(a1 + 16) = a3; /*0x102cf72dd*/
    v3 = a1 + 32; /*0x102cf72e1*/
    OSSL_PARAM_construct_utf8_string(a1: (__int64)v10, a2: (__int64)"st-phase", a3: "Start", a4: 0); /*0x102cf72fb*/
    *(_QWORD *)(a1 + 64) = v10[4]; /*0x102cf7304*/
    v5 = *(_OWORD *)v10; /*0x102cf7308*/
    *(_OWORD *)(a1 + 48) = *(_OWORD *)&v10[2]; /*0x102cf7310*/
    *(_OWORD *)(a1 + 32) = v5; /*0x102cf7315*/
    OSSL_PARAM_construct_utf8_string(a1: (__int64)v10, a2: (__int64)"st-type", a3: *(const char **)(a1 + 8), a4: 0); /*0x102cf732b*/
    *(_QWORD *)(a1 + 104) = v10[4]; /*0x102cf7334*/
    v6 = *(_OWORD *)v10; /*0x102cf7338*/
    *(_OWORD *)(a1 + 88) = *(_OWORD *)&v10[2]; /*0x102cf7340*/
    *(_OWORD *)(a1 + 72) = v6; /*0x102cf7345*/
    OSSL_PARAM_construct_utf8_string(a1: (__int64)v10, a2: (__int64)"st-desc", a3: *(const char **)(a1 + 16), a4: 0); /*0x102cf735b*/
    *(_QWORD *)(a1 + 144) = v10[4]; /*0x102cf7364*/
    v7 = *(_OWORD *)v10; /*0x102cf736b*/
    *(_OWORD *)(a1 + 128) = *(_OWORD *)&v10[2]; /*0x102cf7373*/
    *(_OWORD *)(a1 + 112) = v7; /*0x102cf737b*/
    OSSL_PARAM_construct_end(a1: (__int64)v10); /*0x102cf7384*/
    *(_QWORD *)(a1 + 184) = v10[4]; /*0x102cf738d*/
    v8 = *(_OWORD *)v10; /*0x102cf7394*/
    *(_OWORD *)(a1 + 168) = *(_OWORD *)&v10[2]; /*0x102cf739c*/
    *(_OWORD *)(a1 + 152) = v8; /*0x102cf73a4*/
    return (*(__int64 (__fastcall **)(__int64, _QWORD))(a1 + 24))(a1: v3, a2: *(_QWORD *)(a1 + 192)); /*0x102cf73b6*/
  }
  return result; /*0x102cf73c2*/
}

// Address: 0x102cf73d0 | Name: _OSSL_SELF_TEST_onend
const char *__fastcall OSSL_SELF_TEST_onend(__int64 a1, int a2)
{
  const char *v2; // rdx
  __int64 v3; // rbx
  __int128 v5; // xmm0
  __int128 v6; // xmm0
  __int128 v7; // xmm0
  __int128 v8; // xmm0
  const char *result; // rax
  _QWORD v10[8]; // [rsp-40h] [rbp-40h] BYREF

  if ( a1 != 0 && *(_QWORD *)(a1 + 24) != 0 ) /*0x102cf73de*/
  {
    v2 = "Fail"; /*0x102cf73f9*/
    if ( a2 == 1 ) /*0x102cf7400*/
      v2 = "Pass"; /*0x102cf7400*/
    *(_QWORD *)a1 = v2; /*0x102cf7404*/
    v3 = a1 + 32; /*0x102cf7407*/
    OSSL_PARAM_construct_utf8_string(a1: (__int64)v10, a2: (__int64)"st-phase", a3: v2, a4: 0); /*0x102cf741e*/
    *(_QWORD *)(a1 + 64) = v10[4]; /*0x102cf7427*/
    v5 = *(_OWORD *)v10; /*0x102cf742b*/
    *(_OWORD *)(a1 + 48) = *(_OWORD *)&v10[2]; /*0x102cf7433*/
    *(_OWORD *)(a1 + 32) = v5; /*0x102cf7438*/
    OSSL_PARAM_construct_utf8_string(a1: (__int64)v10, a2: (__int64)"st-type", a3: *(const char **)(a1 + 8), a4: 0); /*0x102cf744e*/
    *(_QWORD *)(a1 + 104) = v10[4]; /*0x102cf7457*/
    v6 = *(_OWORD *)v10; /*0x102cf745b*/
    *(_OWORD *)(a1 + 88) = *(_OWORD *)&v10[2]; /*0x102cf7463*/
    *(_OWORD *)(a1 + 72) = v6; /*0x102cf7468*/
    OSSL_PARAM_construct_utf8_string(a1: (__int64)v10, a2: (__int64)"st-desc", a3: *(const char **)(a1 + 16), a4: 0); /*0x102cf747e*/
    *(_QWORD *)(a1 + 144) = v10[4]; /*0x102cf7487*/
    v7 = *(_OWORD *)v10; /*0x102cf748e*/
    *(_OWORD *)(a1 + 128) = *(_OWORD *)&v10[2]; /*0x102cf7496*/
    *(_OWORD *)(a1 + 112) = v7; /*0x102cf749e*/
    OSSL_PARAM_construct_end(a1: (__int64)v10); /*0x102cf74a7*/
    *(_QWORD *)(a1 + 184) = v10[4]; /*0x102cf74b0*/
    v8 = *(_OWORD *)v10; /*0x102cf74b7*/
    *(_OWORD *)(a1 + 168) = *(_OWORD *)&v10[2]; /*0x102cf74bf*/
    *(_OWORD *)(a1 + 152) = v8; /*0x102cf74c7*/
    (*(void (__fastcall **)(__int64, _QWORD))(a1 + 24))(a1: v3, a2: *(_QWORD *)(a1 + 192)); /*0x102cf74d9*/
    *(_QWORD *)a1 = "None"; /*0x102cf74e4*/
    *(_QWORD *)(a1 + 8) = "None"; /*0x102cf74e7*/
    *(_QWORD *)(a1 + 16) = "None"; /*0x102cf74eb*/
    return "None"; /*0x102cf74dd*/
  }
  return result; /*0x102cf74f7*/
}

// Address: 0x102cf7500 | Name: _OSSL_SELF_TEST_oncorrupt_byte
__int64 __fastcall OSSL_SELF_TEST_oncorrupt_byte(__int64 a1, _BYTE *a2)
{
  unsigned int v2; // r14d
  __int64 v4; // r15
  __int128 v6; // xmm0
  __int128 v7; // xmm0
  __int128 v8; // xmm0
  __int128 v9; // xmm0
  __int128 v11; // [rsp+8h] [rbp-48h] BYREF
  __int128 v12; // [rsp+18h] [rbp-38h]
  __int64 v13; // [rsp+28h] [rbp-28h]

  v2 = 0; /*0x102cf750f*/
  if ( a1 != 0 && *(_QWORD *)(a1 + 24) != 0 ) /*0x102cf7520*/
  {
    *(_QWORD *)a1 = "Corrupt"; /*0x102cf7530*/
    v4 = a1 + 32; /*0x102cf7533*/
    v2 = 0; /*0x102cf753e*/
    OSSL_PARAM_construct_utf8_string(a1: (__int64)&v11, a2: (__int64)"st-phase", a3: "Corrupt", a4: 0); /*0x102cf754d*/
    *(_QWORD *)(a1 + 64) = v13; /*0x102cf7556*/
    v6 = v11; /*0x102cf755b*/
    *(_OWORD *)(a1 + 48) = v12; /*0x102cf7563*/
    *(_OWORD *)(a1 + 32) = v6; /*0x102cf7569*/
    OSSL_PARAM_construct_utf8_string(a1: (__int64)&v11, a2: (__int64)"st-type", a3: *(const char **)(a1 + 8), a4: 0); /*0x102cf7581*/
    *(_QWORD *)(a1 + 104) = v13; /*0x102cf758a*/
    v7 = v11; /*0x102cf758f*/
    *(_OWORD *)(a1 + 88) = v12; /*0x102cf7597*/
    *(_OWORD *)(a1 + 72) = v7; /*0x102cf759d*/
    OSSL_PARAM_construct_utf8_string(a1: (__int64)&v11, a2: (__int64)"st-desc", a3: *(const char **)(a1 + 16), a4: 0); /*0x102cf75b5*/
    *(_QWORD *)(a1 + 144) = v13; /*0x102cf75be*/
    v8 = v11; /*0x102cf75c6*/
    *(_OWORD *)(a1 + 128) = v12; /*0x102cf75ce*/
    *(_OWORD *)(a1 + 112) = v8; /*0x102cf75d7*/
    OSSL_PARAM_construct_end(a1: (__int64)&v11); /*0x102cf75e1*/
    *(_QWORD *)(a1 + 184) = v13; /*0x102cf75ea*/
    v9 = v11; /*0x102cf75f2*/
    *(_OWORD *)(a1 + 168) = v12; /*0x102cf75fa*/
    *(_OWORD *)(a1 + 152) = v9; /*0x102cf7603*/
    if ( (*(unsigned int (__fastcall **)(__int64, _QWORD))(a1 + 24))(a1: v4, a2: *(_QWORD *)(a1 + 192)) == 0 ) /*0x102cf761e*/
    {
      *a2 ^= 1u; /*0x102cf7620*/
      return 1; /*0x102cf7623*/
    }
  }
  return v2; /*0x102cf762c*/
}

// Address: 0x102cf7640 | Name: _OSSL_sleep
int __fastcall OSSL_sleep(unsigned __int64 a1)
{
  timespec __rqtp; // [rsp+0h] [rbp-10h] BYREF

  __rqtp.tv_sec = a1 / 0x3E8; /*0x102cf7660*/
  __rqtp.tv_nsec = 1000000 * (a1 % 0x3E8); /*0x102cf7675*/
  return nanosleep(&__rqtp, __rmtp: nullptr); /*0x102cf7684*/
}

// Address: 0x102cf7690 | Name: _ossl_sa_new
void *ossl_sa_new()
{
  return CRYPTO_zalloc(__size: 0x20u, __s: "crypto/sparse_array.c", line: 60); /*0x102cf76a5*/
}

// Address: 0x102cf76b0 | Name: _ossl_sa_free
void __fastcall ossl_sa_free(void **a1)
{
  int v2; // r15d
  __int64 v3; // rax
  __int64 v4; // rcx
  _QWORD *v5; // rdi
  void *v6; // rcx
  void *v7[16]; // [rsp+0h] [rbp-E0h]
  _DWORD v8[16]; // [rsp+80h] [rbp-60h]

  if ( a1 != nullptr ) /*0x102cf76d1*/
  {
    v8[0] = 0; /*0x102cf76da*/
    v7[0] = a1[3]; /*0x102cf76e5*/
    v2 = 0; /*0x102cf76ec*/
    do /*0x102cf7706*/
    {
      v3 = (unsigned int)v2; /*0x102cf7708*/
      v4 = (int)v8[v2]; /*0x102cf770b*/
      v5 = v7[v2]; /*0x102cf7710*/
      if ( v4 <= 15 ) /*0x102cf771c*/
      {
        v8[v2] = v4 + 1; /*0x102cf7743*/
        if ( v5 != nullptr ) /*0x102cf774a*/
        {
          v6 = (void *)v5[v4]; /*0x102cf774c*/
          if ( v6 != nullptr && v2 < *(_DWORD *)a1 - 1 ) /*0x102cf775c*/
          {
            ++v2; /*0x102cf775e*/
            v8[v3 + 1] = 0; /*0x102cf7761*/
            v7[v3 + 1] = v6; /*0x102cf7769*/
          }
        }
      }
      else
      {
        if ( v5 != nullptr ) /*0x102cf7721*/
          CRYPTO_free(a1: v5); /*0x102cf772b*/
        --v2; /*0x102cf7700*/
      }
    }
    while ( v2 >= 0 ); /*0x102cf7706*/
    CRYPTO_free(a1); /*0x102cf779f*/
  }
}

// Address: 0x102cf77c0 | Name: _ossl_sa_free_leaves
void __fastcall ossl_sa_free_leaves(void **a1)
{
  int v2; // r15d
  __int64 v3; // rax
  __int64 v4; // rcx
  _QWORD *v5; // rdi
  void *v6; // rdi
  void *v7[16]; // [rsp+0h] [rbp-E0h]
  _DWORD v8[16]; // [rsp+80h] [rbp-60h]

  v8[0] = 0; /*0x102cf77e1*/
  v7[0] = a1[3]; /*0x102cf77ec*/
  v2 = 0; /*0x102cf77f3*/
  do /*0x102cf7806*/
  {
    v3 = (unsigned int)v2; /*0x102cf7808*/
    v4 = (int)v8[v2]; /*0x102cf780b*/
    v5 = v7[v2]; /*0x102cf7810*/
    if ( v4 < 16 ) /*0x102cf781c*/
    {
      v8[v2] = v4 + 1; /*0x102cf7843*/
      if ( v5 != nullptr ) /*0x102cf784a*/
      {
        v6 = (void *)v5[v4]; /*0x102cf784c*/
        if ( v6 != nullptr ) /*0x102cf7853*/
        {
          if ( v2 >= *(_DWORD *)a1 - 1 ) /*0x102cf785c*/
          {
            CRYPTO_free(a1: v6); /*0x102cf787b*/
          }
          else
          {
            ++v2; /*0x102cf785e*/
            v8[v3 + 1] = 0; /*0x102cf7861*/
            v7[v3 + 1] = v6; /*0x102cf7869*/
          }
        }
      }
    }
    else
    {
      if ( v5 != nullptr ) /*0x102cf7821*/
        CRYPTO_free(a1: v5); /*0x102cf782b*/
      --v2; /*0x102cf7800*/
    }
  }
  while ( v2 >= 0 ); /*0x102cf7806*/
  CRYPTO_free(a1); /*0x102cf78ae*/
}

// Address: 0x102cf78c0 | Name: _ossl_sa_doall
__int64 __fastcall ossl_sa_doall(__int64 a1, void (__fastcall *a2)(unsigned __int64))
{
  unsigned __int64 v4; // r15
  int v5; // r12d
  __int64 v6; // rax
  __int64 v7; // rcx
  __int64 v8; // rdx
  __int64 v9; // rsi
  _QWORD v11[16]; // [rsp+0h] [rbp-F0h]
  _DWORD v12[18]; // [rsp+80h] [rbp-70h]

  if ( a1 != 0 ) /*0x102cf78e3*/
  {
    v12[0] = 0; /*0x102cf78ef*/
    v11[0] = *(_QWORD *)(a1 + 24); /*0x102cf78fa*/
    v4 = 0; /*0x102cf7901*/
    v5 = 0; /*0x102cf7904*/
    do /*0x102cf791a*/
    {
      v6 = (unsigned int)v5; /*0x102cf791c*/
      v7 = (int)v12[v5]; /*0x102cf791f*/
      if ( v7 > 15 ) /*0x102cf7928*/
      {
        --v5; /*0x102cf7910*/
        v4 >>= 4; /*0x102cf7913*/
      }
      else
      {
        v8 = v11[v5]; /*0x102cf792a*/
        v12[v5] = v7 + 1; /*0x102cf7935*/
        if ( v8 != 0 ) /*0x102cf793c*/
        {
          v9 = *(_QWORD *)(v8 + 8 * v7); /*0x102cf793e*/
          if ( v9 != 0 ) /*0x102cf7945*/
          {
            v4 = v7 | v4 & 0xFFFFFFFFFFFFFFF0LL; /*0x102cf794b*/
            if ( v5 >= *(_DWORD *)a1 - 1 ) /*0x102cf7956*/
            {
              a2(a1: v4); /*0x102cf7974*/
            }
            else
            {
              ++v5; /*0x102cf7958*/
              v12[v6 + 1] = 0; /*0x102cf795b*/
              v11[v6 + 1] = v9; /*0x102cf7963*/
              v4 *= 16LL; /*0x102cf796b*/
            }
          }
        }
      }
    }
    while ( v5 >= 0 ); /*0x102cf791a*/
  }
  return __stack_chk_guard; /*0x102cf7988*/
}

// Address: 0x102cf79a0 | Name: _ossl_sa_doall_arg
__int64 __fastcall ossl_sa_doall_arg(__int64 a1, void (__fastcall *a2)(unsigned __int64, __int64, __int64), __int64 a3)
{
  unsigned __int64 v6; // r12
  int v7; // r13d
  __int64 v8; // rax
  __int64 v9; // rcx
  __int64 v10; // rdx
  __int64 v11; // rsi
  int v12; // eax
  __int64 v13; // rcx
  __int64 v14; // rdx
  __int64 v15; // rsi
  __int64 v16; // rdx
  _QWORD v18[16]; // [rsp+0h] [rbp-F0h]
  _DWORD v19[16]; // [rsp+80h] [rbp-70h]

  if ( a1 != 0 ) /*0x102cf79c5*/
  {
    v19[0] = 0; /*0x102cf79d1*/
    v18[0] = *(_QWORD *)(a1 + 24); /*0x102cf79dc*/
    if ( a2 != nullptr ) /*0x102cf79e6*/
    {
      v6 = 0; /*0x102cf79ef*/
      v7 = 0; /*0x102cf79f2*/
      do /*0x102cf7a0a*/
      {
        v8 = (unsigned int)v7; /*0x102cf7a10*/
        v9 = (int)v19[v7]; /*0x102cf7a13*/
        if ( v9 > 15 ) /*0x102cf7a1c*/
        {
          --v7; /*0x102cf7a00*/
          v6 >>= 4; /*0x102cf7a03*/
        }
        else
        {
          v10 = v18[v7]; /*0x102cf7a1e*/
          v19[v7] = v9 + 1; /*0x102cf7a29*/
          if ( v10 != 0 ) /*0x102cf7a30*/
          {
            v11 = *(_QWORD *)(v10 + 8 * v9); /*0x102cf7a32*/
            if ( v11 != 0 ) /*0x102cf7a39*/
            {
              v6 = v9 | v6 & 0xFFFFFFFFFFFFFFF0LL; /*0x102cf7a3f*/
              if ( v7 >= *(_DWORD *)a1 - 1 ) /*0x102cf7a49*/
              {
                a2(a1: v6, a2: v11, a3); /*0x102cf7a6a*/
              }
              else
              {
                ++v7; /*0x102cf7a4b*/
                v19[v8 + 1] = 0; /*0x102cf7a4e*/
                v18[v8 + 1] = v11; /*0x102cf7a56*/
                v6 *= 16LL; /*0x102cf7a5e*/
              }
            }
          }
        }
      }
      while ( v7 >= 0 ); /*0x102cf7a0a*/
    }
    else
    {
      v12 = 0; /*0x102cf7a6f*/
      do /*0x102cf7a84*/
      {
        v13 = (unsigned int)v12; /*0x102cf7a86*/
        v14 = (int)v19[v12]; /*0x102cf7a88*/
        if ( v14 > 15 ) /*0x102cf7a91*/
        {
          --v12; /*0x102cf7a80*/
        }
        else
        {
          v15 = v18[v12]; /*0x102cf7a93*/
          v19[v12] = v14 + 1; /*0x102cf7a9e*/
          if ( v15 != 0 ) /*0x102cf7aa5*/
          {
            v16 = *(_QWORD *)(v15 + 8 * v14); /*0x102cf7aa7*/
            if ( v16 != 0 && v12 < *(_DWORD *)a1 - 1 ) /*0x102cf7ab6*/
            {
              ++v12; /*0x102cf7ab8*/
              v19[v13 + 1] = 0; /*0x102cf7aba*/
              v18[v13 + 1] = v16; /*0x102cf7ac2*/
            }
          }
        }
      }
      while ( v12 >= 0 ); /*0x102cf7a84*/
    }
  }
  return __stack_chk_guard; /*0x102cf7adc*/
}

// Address: 0x102cf7b00 | Name: _ossl_sa_num
__int64 __fastcall ossl_sa_num(__int64 a1)
{
  if ( a1 != 0 ) /*0x102cf7b07*/
    return *(_QWORD *)(a1 + 16); /*0x102cf7b09*/
  else
    return 0; /*0x102cf7b0f*/
}

// Address: 0x102cf7b20 | Name: _ossl_sa_get
__int64 __fastcall ossl_sa_get(int *a1, unsigned __int64 a2)
{
  unsigned int v3; // ecx
  __int64 v4; // rax
  unsigned __int64 v5; // rdx
  char v6; // cl

  if ( a1 == nullptr || *((_QWORD *)a1 + 2) == 0 || *((_QWORD *)a1 + 1) < a2 ) /*0x102cf7b30*/
    return 0; /*0x102cf7b32*/
  v3 = *a1; /*0x102cf7b39*/
  v4 = *((_QWORD *)a1 + 3); /*0x102cf7b3b*/
  if ( v4 != 0 && *a1 >= 2 ) /*0x102cf7b48*/
  {
    v5 = v3; /*0x102cf7b55*/
    v6 = 4 * v3 - 4; /*0x102cf7b57*/
    do /*0x102cf7b81*/
    {
      v4 = *(_QWORD *)(v4 + 8 * ((a2 >> v6) & 0xF)); /*0x102cf7b69*/
      if ( v4 == 0 ) /*0x102cf7b70*/
        break; /*0x102cf7b70*/
      v6 -= 4; /*0x102cf7b76*/
    }
    while ( v5-- > 2 ); /*0x102cf7b81*/
  }
  if ( v4 != 0 ) /*0x102cf7b86*/
    return *(_QWORD *)(v4 + 8 * (a2 & 0xF)); /*0x102cf7b8b*/
  else
    return 0; /*0x102cf7b91*/
}

// Address: 0x102cf7ba0 | Name: _ossl_sa_set
__int64 __fastcall ossl_sa_set(__int64 a1, unsigned __int64 a2, __int64 a3)
{
  unsigned int v3; // r13d
  int v6; // r12d
  unsigned __int64 v7; // rax
  unsigned int v8; // ecx
  bool v9; // cf
  int v10; // eax
  _QWORD *v11; // rax
  unsigned __int64 v12; // rdi
  _QWORD *v13; // rbx
  char v14; // r13
  unsigned __int64 v15; // r12
  __int64 v16; // r14
  _QWORD *v17; // rax
  unsigned __int64 v18; // rdi
  __int64 v19; // rdx
  __int64 v20; // rcx
  __int64 v22; // [rsp+8h] [rbp-38h]

  v3 = 0; /*0x102cf7bb1*/
  if ( a1 == 0 ) /*0x102cf7bb7*/
    return v3; /*0x102cf7bb7*/
  v6 = 1; /*0x102cf7bc3*/
  if ( a2 >= 0x10 ) /*0x102cf7bcd*/
  {
    v7 = a2; /*0x102cf7bcf*/
    do /*0x102cf7bfc*/
    {
      v8 = v6++; /*0x102cf7be0*/
      if ( v8 > 0xE ) /*0x102cf7bea*/
        break; /*0x102cf7bea*/
      v9 = v7 < 0x100; /*0x102cf7bf3*/
      v7 >>= 4; /*0x102cf7bf9*/
    }
    while ( !v9 ); /*0x102cf7bfc*/
  }
  v10 = *(_DWORD *)a1; /*0x102cf7c02*/
  if ( *(_DWORD *)a1 >= v6 ) /*0x102cf7c08*/
  {
LABEL_9:
    v22 = a3; /*0x102cf7c53*/
    v12 = a2; /*0x102cf7c57*/
    if ( *(_QWORD *)(a1 + 8) < a2 ) /*0x102cf7c5f*/
      *(_QWORD *)(a1 + 8) = a2; /*0x102cf7c61*/
    v13 = *(_QWORD **)(a1 + 24); /*0x102cf7c65*/
    if ( v10 >= 2 ) /*0x102cf7c6c*/
    {
      v14 = 4 * v10 - 4; /*0x102cf7c71*/
      v15 = (unsigned int)v10 + 1LL; /*0x102cf7c79*/
      while ( 1 ) /*0x102cf7c99*/
      {
        v16 = (v12 >> v14) & 0xF; /*0x102cf7c99*/
        v17 = (_QWORD *)v13[v16]; /*0x102cf7ca0*/
        if ( v17 == nullptr ) /*0x102cf7ca7*/
        {
          v17 = CRYPTO_zalloc(__size: 0x80u, __s: "crypto/sparse_array.c", line: 176); /*0x102cf7cba*/
          v12 = a2; /*0x102cf7cbf*/
          v13[v16] = v17; /*0x102cf7cc3*/
          if ( v17 == nullptr ) /*0x102cf7cca*/
            return 0; /*0x102cf7ccf*/
        }
        --v15; /*0x102cf7c80*/
        v14 -= 4; /*0x102cf7c83*/
        v13 = v17; /*0x102cf7c87*/
        if ( v15 <= 2 ) /*0x102cf7c8e*/
          goto LABEL_18; /*0x102cf7c8e*/
      }
    }
    v17 = *(_QWORD **)(a1 + 24); /*0x102cf7cd1*/
LABEL_18:
    v18 = v12 & 0xF; /*0x102cf7cd4*/
    v19 = v17[(unsigned int)v18]; /*0x102cf7cd9*/
    if ( v22 != 0 ) /*0x102cf7ce4*/
    {
      if ( v19 == 0 ) /*0x102cf7ce9*/
      {
        v20 = 1; /*0x102cf7ceb*/
LABEL_22:
        *(_QWORD *)(a1 + 16) += v20; /*0x102cf7cfe*/
      }
    }
    else
    {
      v20 = -1; /*0x102cf7cf2*/
      if ( v19 != 0 ) /*0x102cf7cfc*/
        goto LABEL_22; /*0x102cf7cfc*/
    }
    v17[v18] = v22; /*0x102cf7d02*/
    return 1; /*0x102cf7d06*/
  }
  while ( 1 ) /*0x102cf7c2d*/
  {
    v11 = CRYPTO_zalloc(__size: 0x80u, __s: "crypto/sparse_array.c", line: 176); /*0x102cf7c2d*/
    if ( v11 == nullptr ) /*0x102cf7c35*/
      return v3; /*0x102cf7d0f*/
    *v11 = *(_QWORD *)(a1 + 24); /*0x102cf7c3f*/
    *(_QWORD *)(a1 + 24) = v11; /*0x102cf7c42*/
    v10 = *(_DWORD *)a1 + 1; /*0x102cf7c49*/
    *(_DWORD *)a1 = v10; /*0x102cf7c4b*/
    if ( v10 >= v6 ) /*0x102cf7c51*/
      goto LABEL_9; /*0x102cf7c51*/
  }
}

// Address: 0x102cf7d20 | Name: _ossl_err_load_SSL_strings
__int64 ossl_err_load_SSL_strings()
{
  if ( ERR_reason_error_string(e: 0xA000123u) == nullptr ) /*0x102cf7d31*/
    ERR_load_strings_const(a1: &SSL_str_reasons); /*0x102cf7d41*/
  return 1; /*0x102cf7d38*/
}

// Address: 0x102cf7d50 | Name: _ossl_rcu_read_lock
_QWORD *__fastcall ossl_rcu_read_lock(__int64 a1)
{
  void **rcukey; // r14
  _QWORD *result; // rax
  _QWORD *v4; // rax
  pthread_key_t v5; // rdi
  _QWORD *v6; // r14
  bool v7; // cl
  bool v8; // si
  int v9; // edi
  int v10; // edx
  int v11; // ecx
  int v12; // edx
  int v13; // ecx
  int v14; // edx
  int v15; // ecx
  __int64 v16; // rsi
  bool v17; // di
  __int64 v18; // rdx
  __int64 v19; // rdx
  __int64 v20; // rcx

  rcukey = ossl_lib_ctx_get_rcukey(a1: *(_QWORD *)(a1 + 8)); /*0x102cf7d63*/
  result = pthread_getspecific(a1: (pthread_key_t)*rcukey); /*0x102cf7d69*/
  if ( result != nullptr )
  {
    if ( result[2] == a1 ) /*0x102cf7d77*/
      goto LABEL_61; /*0x102cf7d77*/
  }
  else
  {
    v4 = CRYPTO_zalloc(__size: 0xF0u, __s: "crypto/threads_pthread.c", line: 315); /*0x102cf7d8f*/
    if ( v4 == nullptr )
      OPENSSL_die(a1: "assertion failed: data != NULL", a2: "crypto/threads_pthread.c", a3: 316);
    v5 = (pthread_key_t)*rcukey; /*0x102cf7d9d*/
    v6 = v4; /*0x102cf7da3*/
    pthread_setspecific(a1: v5, a2: v4); /*0x102cf7da6*/
    ossl_init_thread_start(a1: 0, a2: *(_QWORD *)(a1 + 8), a3: (__int64)ossl_rcu_free_local_data); /*0x102cf7db8*/
    result = v6; /*0x102cf7dbd*/
    if ( v6[2] == a1 ) /*0x102cf7dc4*/
      goto LABEL_61; /*0x102cf7dc4*/
  }
  if ( result[5] == a1 ) /*0x102cf7dce*/
  {
    result += 3; /*0x102cf7f5f*/
LABEL_61:
    ++*((_DWORD *)result + 2); /*0x102cf7f9b*/
    return result; /*0x102cf7fa2*/
  }
  if ( result[8] == a1 ) /*0x102cf7dd8*/
  {
    result += 6; /*0x102cf7f65*/
    goto LABEL_61; /*0x102cf7f69*/
  }
  if ( result[11] == a1 ) /*0x102cf7de2*/
  {
    result += 9; /*0x102cf7f6b*/
    goto LABEL_61; /*0x102cf7f6f*/
  }
  if ( result[14] == a1 ) /*0x102cf7dec*/
  {
    result += 12; /*0x102cf7f71*/
    goto LABEL_61; /*0x102cf7f75*/
  }
  if ( result[17] == a1 ) /*0x102cf7df9*/
  {
    result += 15; /*0x102cf7f77*/
    goto LABEL_61; /*0x102cf7f7b*/
  }
  if ( result[20] == a1 ) /*0x102cf7e06*/
  {
    result += 18; /*0x102cf7f7d*/
    goto LABEL_61; /*0x102cf7f83*/
  }
  if ( result[23] == a1 ) /*0x102cf7e13*/
  {
    result += 21; /*0x102cf7f85*/
    goto LABEL_61; /*0x102cf7f8b*/
  }
  if ( result[26] == a1 ) /*0x102cf7e20*/
  {
    result += 24; /*0x102cf7f8d*/
    goto LABEL_61; /*0x102cf7f93*/
  }
  if ( result[29] == a1 ) /*0x102cf7e2d*/
  {
    result += 27; /*0x102cf7f95*/
    goto LABEL_61; /*0x102cf7f95*/
  }
  v7 = result[3] == 0; /*0x102cf7e38*/
  v8 = *result != 0; /*0x102cf7e46*/
  v9 = 1; /*0x102cf7e4f*/
  if ( !v7 || !v8 ) /*0x102cf7e4c*/
    v9 = -(*result != 0); /*0x102cf7e54*/
  v10 = 2; /*0x102cf7e5a*/
  if ( *result == 0 ) /*0x102cf7e5f*/
    v10 = v9; /*0x102cf7e5f*/
  if ( v7 && v8 ) /*0x102cf7e62*/
    v10 = v9; /*0x102cf7e65*/
  if ( result[6] != 0 ) /*0x102cf7e6d*/
    v10 = v9; /*0x102cf7e6d*/
  v11 = 3; /*0x102cf7e73*/
  if ( v10 != -1 ) /*0x102cf7e78*/
    v11 = v10; /*0x102cf7e78*/
  if ( result[9] != 0 ) /*0x102cf7e80*/
    v11 = v10; /*0x102cf7e80*/
  v12 = 4; /*0x102cf7e86*/
  if ( v11 != -1 ) /*0x102cf7e8b*/
    v12 = v11; /*0x102cf7e8b*/
  if ( result[12] != 0 ) /*0x102cf7e93*/
    v12 = v11; /*0x102cf7e93*/
  v13 = 5; /*0x102cf7e99*/
  if ( v12 != -1 ) /*0x102cf7e9e*/
    v13 = v12; /*0x102cf7e9e*/
  if ( result[15] != 0 ) /*0x102cf7ea6*/
    v13 = v12; /*0x102cf7ea6*/
  v14 = 6; /*0x102cf7eac*/
  if ( v13 != -1 ) /*0x102cf7eb1*/
    v14 = v13; /*0x102cf7eb1*/
  if ( result[18] != 0 ) /*0x102cf7ebc*/
    v14 = v13; /*0x102cf7ebc*/
  v15 = 7; /*0x102cf7ec2*/
  if ( v14 != -1 ) /*0x102cf7ec7*/
    v15 = v14; /*0x102cf7ec7*/
  if ( result[21] != 0 ) /*0x102cf7ed2*/
    v15 = v14; /*0x102cf7ed2*/
  LODWORD(v16) = 8; /*0x102cf7ed8*/
  if ( v15 != -1 ) /*0x102cf7edd*/
    LODWORD(v16) = v15; /*0x102cf7edd*/
  if ( result[24] != 0 ) /*0x102cf7ee8*/
    LODWORD(v16) = v15; /*0x102cf7ee8*/
  v17 = result[27] == 0; /*0x102cf7ef3*/
  v18 = *(unsigned int *)(a1 + 32); /*0x102cf7efd*/
  _InterlockedIncrement64((volatile signed __int64 *)(*(_QWORD *)(a1 + 16) + 8 * v18)); /*0x102cf7f04*/
  v16 = (int)v16; /*0x102cf7f0c*/
  while ( (_DWORD)v18 != *(_DWORD *)(a1 + 32) ) /*0x102cf7f14*/
  {
    _InterlockedDecrement64((volatile signed __int64 *)(*(_QWORD *)(a1 + 16) + 8 * v18)); /*0x102cf7f1a*/
    v18 = *(unsigned int *)(a1 + 32); /*0x102cf7f1f*/
    _InterlockedIncrement64((volatile signed __int64 *)(*(_QWORD *)(a1 + 16) + 8 * v18)); /*0x102cf7f26*/
  }
  v19 = *(_QWORD *)(a1 + 16) + 8 * v18; /*0x102cf7f36*/
  if ( v17 && (_DWORD)v16 == -1 ) /*0x102cf7efa*/
    v16 = 9; /*0x102cf7f41*/
  v20 = 3 * v16; /*0x102cf7f45*/
  result[v20] = v19; /*0x102cf7f49*/
  LODWORD(result[v20 + 1]) = 1; /*0x102cf7f4d*/
  result[v20 + 2] = a1; /*0x102cf7f55*/
  return result; /*0x102cf7f5a*/
}

// Address: 0x102cf7ff0 | Name: _ossl_rcu_free_local_data
int __fastcall ossl_rcu_free_local_data(__int64 a1)
{
  void **rcukey; // rbx
  void *v2; // rax

  rcukey = ossl_lib_ctx_get_rcukey(a1); /*0x102cf7ffb*/
  v2 = pthread_getspecific(a1: (pthread_key_t)*rcukey); /*0x102cf8001*/
  CRYPTO_free(a1: v2); /*0x102cf8015*/
  return pthread_setspecific(a1: (pthread_key_t)*rcukey, a2: nullptr); /*0x102cf8023*/
}

// Address: 0x102cf8030 | Name: _ossl_rcu_read_unlock
_QWORD *__fastcall ossl_rcu_read_unlock(__int64 a1)
{
  void **rcukey; // rax
  _QWORD *result; // rax

  rcukey = ossl_lib_ctx_get_rcukey(a1: *(_QWORD *)(a1 + 8)); /*0x102cf803d*/
  result = pthread_getspecific(a1: (pthread_key_t)*rcukey); /*0x102cf8045*/
  if ( result[2] != a1 ) /*0x102cf804e*/
  {
    if ( result[5] == a1 ) /*0x102cf8058*/
    {
      result += 3; /*0x102cf80a1*/
    }
    else if ( result[8] == a1 ) /*0x102cf805e*/
    {
      result += 6; /*0x102cf80a7*/
    }
    else if ( result[11] == a1 ) /*0x102cf8064*/
    {
      result += 9; /*0x102cf80ad*/
    }
    else if ( result[14] == a1 ) /*0x102cf806a*/
    {
      result += 12; /*0x102cf80b3*/
    }
    else if ( result[17] == a1 ) /*0x102cf8073*/
    {
      result += 15; /*0x102cf80b9*/
    }
    else if ( result[20] == a1 ) /*0x102cf807c*/
    {
      result += 18; /*0x102cf80bf*/
    }
    else if ( result[23] == a1 ) /*0x102cf8085*/
    {
      result += 21; /*0x102cf80c7*/
    }
    else if ( result[26] == a1 ) /*0x102cf808e*/
    {
      result += 24; /*0x102cf80cf*/
    }
    else
    {
      if ( result[29] != a1 ) /*0x102cf8097*/
        return result; /*0x102cf8097*/
      result += 27; /*0x102cf8099*/
    }
  }
  if ( (*((_DWORD *)result + 2))-- == 1 )
  {
    if ( _InterlockedExchangeAdd64((volatile signed __int64 *)*result, 0xFFFFFFFFFFFFFFFFLL) == 0 )
      OPENSSL_die(a1: "assertion failed: ret != UINT64_MAX", a2: "crypto/threads_pthread.c", a3: 361);
    *result = 0; /*0x102cf80f5*/
    result[2] = 0; /*0x102cf80fc*/
  }
  return result; /*0x102cf80de*/
}

// Address: 0x102cf8130 | Name: _ossl_rcu_write_lock
int __fastcall ossl_rcu_write_lock(__int64 a1)
{
  return pthread_mutex_lock(a1: (pthread_mutex_t *)(a1 + 48)); /*0x102cf8138*/
}

// Address: 0x102cf8140 | Name: _ossl_rcu_write_unlock
int __fastcall ossl_rcu_write_unlock(__int64 a1)
{
  return pthread_mutex_unlock(a1: (pthread_mutex_t *)(a1 + 48)); /*0x102cf8148*/
}

// Address: 0x102cf8150 | Name: _ossl_synchronize_rcu
void __fastcall ossl_synchronize_rcu(__int64 a1)
{
  pthread_mutex_t *v2; // r15
  _QWORD *v3; // rbx
  unsigned int v4; // ecx
  int v5; // eax
  __int64 v6; // r12
  __int64 v7; // rdx
  __int64 v8; // r13
  pthread_mutex_t *v9; // r15
  __int64 i; // rax
  pthread_mutex_t *v11; // rsi
  pthread_mutex_t *v12; // r12
  __int64 v13; // r15
  _QWORD *v14; // r15
  pthread_mutex_t *v15; // [rsp+10h] [rbp-40h]
  __int64 v16; // [rsp+20h] [rbp-30h]

  v2 = (pthread_mutex_t *)(a1 + 48); /*0x102cf8164*/
  pthread_mutex_lock(a1: (pthread_mutex_t *)(a1 + 48)); /*0x102cf816b*/
  v3 = *(_QWORD **)a1; /*0x102cf8170*/
  *(_QWORD *)a1 = 0; /*0x102cf8173*/
  pthread_mutex_unlock(a1: v2); /*0x102cf817d*/
  pthread_mutex_lock(a1: (pthread_mutex_t *)(a1 + 112)); /*0x102cf8189*/
  v4 = *(_DWORD *)(a1 + 28); /*0x102cf818e*/
  v5 = *(_DWORD *)(a1 + 44); /*0x102cf8192*/
  if ( v4 - v5 <= 1 ) /*0x102cf819d*/
  {
    do /*0x102cf81ca*/
    {
      pthread_cond_wait(a1: (pthread_cond_t *)(a1 + 176), a2: (pthread_mutex_t *)(a1 + 112)); /*0x102cf81b6*/
      v4 = *(_DWORD *)(a1 + 28); /*0x102cf81bb*/
      v5 = *(_DWORD *)(a1 + 44); /*0x102cf81bf*/
    }
    while ( v4 - v5 < 2 ); /*0x102cf81ca*/
  }
  v6 = *(unsigned int *)(a1 + 24); /*0x102cf81cc*/
  v7 = *(unsigned int *)(a1 + 40); /*0x102cf81d0*/
  *(_DWORD *)(a1 + 44) = v5 + 1; /*0x102cf81d6*/
  v16 = v7; /*0x102cf81da*/
  LODWORD(v7) = ((int)v7 + 1) % v4; /*0x102cf81e3*/
  *(_DWORD *)(a1 + 40) = v7; /*0x102cf81e5*/
  *(_DWORD *)(a1 + 24) = v6 + 1; /*0x102cf81ee*/
  *(_DWORD *)(a1 + 32) = v7; /*0x102cf81f2*/
  pthread_cond_signal(a1: (pthread_cond_t *)(a1 + 176)); /*0x102cf8201*/
  v15 = (pthread_mutex_t *)(a1 + 112); /*0x102cf8206*/
  pthread_mutex_unlock(a1: (pthread_mutex_t *)(a1 + 112)); /*0x102cf820d*/
  v8 = *(_QWORD *)(a1 + 16); /*0x102cf8212*/
  v9 = (pthread_mutex_t *)(a1 + 224); /*0x102cf8216*/
  pthread_mutex_lock(a1: (pthread_mutex_t *)(a1 + 224)); /*0x102cf8220*/
  for ( i = v6; *(_DWORD *)(a1 + 36) != (_DWORD)i; v9 = v12 ) /*0x102cf822c*/
  {
    v11 = v9; /*0x102cf8244*/
    v12 = v9; /*0x102cf8247*/
    v13 = i; /*0x102cf824a*/
    pthread_cond_wait(a1: (pthread_cond_t *)(a1 + 288), a2: v11); /*0x102cf824d*/
    i = v13; /*0x102cf8252*/
  }
  while ( *(_QWORD *)(v8 + 8 * v16) != 0 ) /*0x102cf8278*/
    ; /*0x102cf8270*/
  ++*(_DWORD *)(a1 + 36); /*0x102cf827a*/
  pthread_cond_broadcast(a1: (pthread_cond_t *)(a1 + 288)); /*0x102cf8285*/
  pthread_mutex_unlock(a1: v9); /*0x102cf828d*/
  pthread_mutex_lock(a1: v15); /*0x102cf8299*/
  --*(_DWORD *)(a1 + 44); /*0x102cf829e*/
  pthread_cond_signal(a1: (pthread_cond_t *)(a1 + 176)); /*0x102cf82a6*/
  pthread_mutex_unlock(a1: v15); /*0x102cf82ae*/
  if ( v3 != nullptr ) /*0x102cf82b6*/
  {
    do /*0x102cf82e0*/
    {
      v14 = (_QWORD *)v3[2]; /*0x102cf82c4*/
      ((void (__fastcall *)(_QWORD))*v3)(a1: v3[1]); /*0x102cf82c8*/
      CRYPTO_free(a1: v3); /*0x102cf82d5*/
      v3 = v14; /*0x102cf82da*/
    }
    while ( v14 != nullptr ); /*0x102cf82e0*/
  }
}

// Address: 0x102cf8300 | Name: _ossl_rcu_call
__int64 __fastcall ossl_rcu_call(_QWORD *a1, __int64 a2, __int64 a3)
{
  _QWORD *v6; // rax

  v6 = CRYPTO_zalloc(__size: 0x18u, __s: "crypto/threads_pthread.c", line: 506); /*0x102cf8324*/
  if ( v6 == nullptr ) /*0x102cf832c*/
    return 0; /*0x102cf8346*/
  v6[1] = a3; /*0x102cf832e*/
  *v6 = a2; /*0x102cf8332*/
  v6[2] = *a1; /*0x102cf8338*/
  *a1 = v6; /*0x102cf833c*/
  return 1; /*0x102cf834c*/
}

// Address: 0x102cf8360 | Name: _ossl_rcu_uptr_deref
__int64 __fastcall ossl_rcu_uptr_deref(__int64 a1)
{
  return *(_QWORD *)a1; /*0x102cf8367*/
}

// Address: 0x102cf8370 | Name: _ossl_rcu_assign_uptr
__int64 __fastcall ossl_rcu_assign_uptr(__int64 *a1, __int64 *a2)
{
  __int64 result; // rax

  result = *a2; /*0x102cf8374*/
  *a1 = *a2; /*0x102cf8377*/
  return result; /*0x102cf837a*/
}

// Address: 0x102cf8380 | Name: _ossl_rcu_lock_new
char *__fastcall ossl_rcu_lock_new(int a1, __int64 a2)
{
  unsigned int v2; // r14d
  void **concrete; // rax
  void **v4; // rbx
  char *v5; // rax
  char *v6; // rbx
  void *v7; // rcx
  char *result; // rax

  v2 = 2; /*0x102cf838a*/
  if ( a1 >= 3 ) /*0x102cf8390*/
    v2 = a1; /*0x102cf8390*/
  concrete = ossl_lib_ctx_get_concrete(a1: a2); /*0x102cf8397*/
  if ( concrete != nullptr ) /*0x102cf839f*/
  {
    v4 = concrete; /*0x102cf83a5*/
    v5 = (char *)CRYPTO_zalloc(__size: 0x150u, __s: "crypto/threads_pthread.c", line: 544); /*0x102cf83b9*/
    if ( v5 != nullptr ) /*0x102cf83c1*/
    {
      *((_QWORD *)v5 + 1) = v4; /*0x102cf83c7*/
      v6 = v5; /*0x102cf83d1*/
      pthread_mutex_init(a1: (pthread_mutex_t *)(v5 + 48), a2: nullptr); /*0x102cf83d4*/
      pthread_mutex_init(a1: (pthread_mutex_t *)(v6 + 224), a2: nullptr); /*0x102cf83e2*/
      pthread_mutex_init(a1: (pthread_mutex_t *)(v6 + 112), a2: nullptr); /*0x102cf83ed*/
      pthread_cond_init(a1: (pthread_cond_t *)v6 + 6, a2: nullptr); /*0x102cf83fb*/
      pthread_cond_init(a1: (pthread_cond_t *)(v6 + 176), a2: nullptr); /*0x102cf840c*/
      v7 = CRYPTO_zalloc(__size: 8LL * v2, __s: "crypto/threads_pthread.c", line: 434); /*0x102cf8429*/
      result = v6; /*0x102cf842c*/
      *((_DWORD *)v6 + 7) = v2; /*0x102cf842f*/
      *((_QWORD *)v6 + 2) = v7; /*0x102cf8433*/
      if ( v7 != nullptr ) /*0x102cf843a*/
        return result; /*0x102cf843a*/
      CRYPTO_free(a1: v6); /*0x102cf8450*/
    }
  }
  return nullptr; /*0x102cf843c*/
}

// Address: 0x102cf8460 | Name: _ossl_rcu_lock_free
void __fastcall ossl_rcu_lock_free(void **a1)
{
  if ( a1 != nullptr ) /*0x102cf8463*/
  {
    ossl_synchronize_rcu((__int64)a1); /*0x102cf846f*/
    CRYPTO_free(a1: a1[2]); /*0x102cf8487*/
    CRYPTO_free(a1); /*0x102cf849b*/
  }
}

// Address: 0x102cf8700 | Name: _openssl_init_fork_handlers
__int64 openssl_init_fork_handlers()
{
  return 1; /*0x102cf8709*/
}

// Address: 0x102cf8710 | Name: _openssl_get_fork_id
pid_t openssl_get_fork_id()
{
  return getpid(); /*0x102cf8714*/
}

// Address: 0x102cf8720 | Name: _ossl_time_now
__int64 ossl_time_now()
{
  __int64 v0; // rbx
  int *v1; // rax
  timeval v3; // [rsp+8h] [rbp-18h] BYREF

  if ( gettimeofday(a1: &v3, a2: nullptr) < 0 ) /*0x102cf8736*/
  {
    ERR_new(); /*0x102cf8758*/
    ERR_set_debug(__s: "crypto/time.c", a2: 39, a3: "ossl_time_now"); /*0x102cf8770*/
    v1 = __error(); /*0x102cf8775*/
    v0 = 0; /*0x102cf8783*/
    ERR_set_error(a1: 2, a2: (unsigned int)*v1, a3: (__int64)"calling gettimeofday()"); /*0x102cf878c*/
  }
  else if ( v3.tv_sec <= 0 ) /*0x102cf873f*/
  {
    v0 = 0; /*0x102cf879e*/
    if ( v3.tv_usec > 0 ) /*0x102cf87a3*/
      return 1000LL * v3.tv_usec; /*0x102cf87a3*/
  }
  else
  {
    return 1000 * (1000000 * v3.tv_sec + v3.tv_usec); /*0x102cf874f*/
  }
  return v0; /*0x102cf87aa*/
}

// Address: 0x102cf87c0 | Name: _OSSL_trace_get_category_num
__int64 __fastcall OSSL_trace_get_category_num(__int64 a1)
{
  __int64 result; // rax
  bool v3; // zf
  char **v4; // rax

  result = 0xFFFFFFFFLL; /*0x102cf87c0*/
  if ( a1 != 0 ) /*0x102cf87c8*/
  {
    if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"ALL") != 0 ) /*0x102cf87e5*/
    {
      if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"TRACE") != 0 ) /*0x102cf87fc*/
      {
        if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"INIT") != 0 ) /*0x102cf8813*/
        {
          if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"TLS") != 0 ) /*0x102cf882a*/
          {
            if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"TLS_CIPHER") != 0 ) /*0x102cf8841*/
            {
              if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"CONF") != 0 ) /*0x102cf8858*/
              {
                if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"ENGINE_TABLE") != 0 ) /*0x102cf886f*/
                {
                  if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"ENGINE_REF_COUNT") != 0 ) /*0x102cf8886*/
                  {
                    if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"PKCS5V2") != 0 ) /*0x102cf889d*/
                    {
                      if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"PKCS12_KEYGEN") != 0 ) /*0x102cf88b4*/
                      {
                        if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"PKCS12_DECRYPT") != 0 ) /*0x102cf88cb*/
                        {
                          if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"X509V3_POLICY") != 0 ) /*0x102cf88e2*/
                          {
                            if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"BN_CTX") != 0 ) /*0x102cf88f9*/
                            {
                              if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"CMP") != 0 ) /*0x102cf8910*/
                              {
                                if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"STORE") != 0 ) /*0x102cf8927*/
                                {
                                  if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"DECODER") != 0 ) /*0x102cf893e*/
                                  {
                                    if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"ENCODER") != 0 ) /*0x102cf8955*/
                                    {
                                      if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"REF_COUNT") != 0 ) /*0x102cf896c*/
                                      {
                                        if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"HTTP") != 0 ) /*0x102cf8983*/
                                        {
                                          if ( (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"PROVIDER") != 0 ) /*0x102cf899a*/
                                          {
                                            v3 = (unsigned int)OPENSSL_strcasecmp(a1, a2: (__int64)"QUERY") == 0; /*0x102cf89af*/
                                            result = 0xFFFFFFFFLL; /*0x102cf89b1*/
                                            if ( !v3 ) /*0x102cf89b6*/
                                              return result; /*0x102cf89b6*/
                                            v4 = &off_10C85E990; /*0x102cf89bc*/
                                          }
                                          else
                                          {
                                            v4 = &off_10C85E980; /*0x102cf8a82*/
                                          }
                                        }
                                        else
                                        {
                                          v4 = &off_10C85E970; /*0x102cf8a79*/
                                        }
                                      }
                                      else
                                      {
                                        v4 = &off_10C85E960; /*0x102cf8a70*/
                                      }
                                    }
                                    else
                                    {
                                      v4 = &off_10C85E950; /*0x102cf8a67*/
                                    }
                                  }
                                  else
                                  {
                                    v4 = &off_10C85E940; /*0x102cf8a5e*/
                                  }
                                }
                                else
                                {
                                  v4 = &off_10C85E930; /*0x102cf8a55*/
                                }
                              }
                              else
                              {
                                v4 = &off_10C85E920; /*0x102cf8a4c*/
                              }
                            }
                            else
                            {
                              v4 = &off_10C85E910; /*0x102cf8a43*/
                            }
                          }
                          else
                          {
                            v4 = &off_10C85E900; /*0x102cf8a3a*/
                          }
                        }
                        else
                        {
                          v4 = &off_10C85E8F0; /*0x102cf8a31*/
                        }
                      }
                      else
                      {
                        v4 = &off_10C85E8E0; /*0x102cf8a28*/
                      }
                    }
                    else
                    {
                      v4 = &off_10C85E8D0; /*0x102cf8a1f*/
                    }
                  }
                  else
                  {
                    v4 = &off_10C85E8C0; /*0x102cf8a16*/
                  }
                }
                else
                {
                  v4 = &off_10C85E8B0; /*0x102cf8a0d*/
                }
              }
              else
              {
                v4 = &off_10C85E8A0; /*0x102cf8a04*/
              }
            }
            else
            {
              v4 = &off_10C85E890; /*0x102cf89f8*/
            }
          }
          else
          {
            v4 = &off_10C85E880; /*0x102cf89ec*/
          }
        }
        else
        {
          v4 = &off_10C85E870; /*0x102cf89e0*/
        }
      }
      else
      {
        v4 = &off_10C85E860; /*0x102cf89d4*/
      }
    }
    else
    {
      v4 = &trace_categories; /*0x102cf89c8*/
    }
    return *((unsigned int *)v4 + 2); /*0x102cf8a89*/
  }
  return result; /*0x102cf8a92*/
}

// Address: 0x102cf8aa0 | Name: _ossl_trace_cleanup
void ossl_trace_cleanup()
{
  ; /*0x102cf8aa0*/
}

// Address: 0x102cf8ab0 | Name: _OSSL_trace_set_channel
__int64 OSSL_trace_set_channel()
{
  return 0; /*0x102cf8ab6*/
}

// Address: 0x102cf8ac0 | Name: _OSSL_trace_set_callback
__int64 OSSL_trace_set_callback()
{
  return 0; /*0x102cf8ac6*/
}

// Address: 0x102cf8ad0 | Name: _OSSL_trace_set_prefix
__int64 OSSL_trace_set_prefix()
{
  return 0; /*0x102cf8ad6*/
}

// Address: 0x102cf8ae0 | Name: _OSSL_trace_set_suffix
__int64 OSSL_trace_set_suffix()
{
  return 0; /*0x102cf8ae6*/
}

// Address: 0x102cf8af0 | Name: _OSSL_trace_enabled
__int64 OSSL_trace_enabled()
{
  return 0; /*0x102cf8af6*/
}

// Address: 0x102cf8b00 | Name: _OSSL_trace_begin
__int64 OSSL_trace_begin()
{
  return 0; /*0x102cf8b06*/
}

// Address: 0x102cf8b10 | Name: _OSSL_trace_end
void OSSL_trace_end()
{
  ; /*0x102cf8b10*/
}

// Address: 0x102cf8b20 | Name: _OSSL_trace_string
int __fastcall OSSL_trace_string(BIO *bio, int a2, int a3, const char *a4, unsigned __int64 a5)
{
  int v8; // r12d
  __int64 i; // r15
  unsigned int v10; // edi
  char v11; // cl
  _BOOL4 v12; // eax
  __int64 v13; // rax
  _BYTE v15[96]; // [rsp+0h] [rbp-90h] BYREF

  if ( a5 < 0x51 || a3 != 0 ) /*0x102cf8b4a*/
  {
    if ( a2 != 0 ) /*0x102cf8b87*/
      return BIO_printf(bio, format: "%.*s", a5, a4); /*0x102cf8b87*/
    if ( (int)a5 <= 0 ) /*0x102cf8b8c*/
    {
      if ( (_DWORD)a5 == 0 ) /*0x102cf8c2b*/
      {
        LODWORD(a5) = 0; /*0x102cf8c2d*/
        goto LABEL_14; /*0x102cf8c30*/
      }
LABEL_13:
      if ( *(a4 - 1) == 10 ) /*0x102cf8bde*/
      {
LABEL_15:
        a4 = v15; /*0x102cf8bee*/
        return BIO_printf(bio, format: "%.*s", a5, a4); /*0x102cf8bee*/
      }
LABEL_14:
      v13 = (int)a5; /*0x102cf8be0*/
      LODWORD(a5) = a5 + 1; /*0x102cf8be3*/
      v15[v13] = 10; /*0x102cf8be6*/
      goto LABEL_15; /*0x102cf8be6*/
    }
    v8 = a5; /*0x102cf8b92*/
LABEL_7:
    for ( i = 0; i != v8; v15[i++] = v11 ) /*0x102cf8b98*/
    {
      v10 = (unsigned __int8)a4[i]; /*0x102cf8bb0*/
      v11 = 10; /*0x102cf8bb5*/
      if ( v10 != 10 ) /*0x102cf8bba*/
      {
        v12 = ossl_ctype_check(a1: v10, a2: 64); /*0x102cf8bc1*/
        v11 = 32; /*0x102cf8bc6*/
        if ( !v12 ) /*0x102cf8bca*/
          v11 = a4[i]; /*0x102cf8bcc*/
      }
    }
    a4 += i; /*0x102cf8bd3*/
    LODWORD(a5) = v8; /*0x102cf8bd6*/
    goto LABEL_13; /*0x102cf8bd6*/
  }
  v8 = 80; /*0x102cf8b5f*/
  BIO_printf(bio, format: "[len %zu limited to %d]: ", a5, 80);
  if ( a2 == 0 ) /*0x102cf8b7a*/
    goto LABEL_7; /*0x102cf8b7a*/
  LODWORD(a5) = 80; /*0x102cf8b7c*/
  return BIO_printf(bio, format: "%.*s", a5, a4); /*0x102cf8c1c*/
}

// Address: 0x102cf8c40 | Name: _OPENSSL_issetugid
int OPENSSL_issetugid(void)
{
  uid_t v0; // ebx
  uid_t v1; // ecx
  __int64 v2; // rax
  gid_t v3; // ebx

  v0 = getuid(); /*0x102cf8c4b*/
  v1 = geteuid(); /*0x102cf8c52*/
  LODWORD(v2) = 1; /*0x102cf8c54*/
  if ( v0 == v1 ) /*0x102cf8c5b*/
  {
    v3 = getgid(); /*0x102cf8c62*/
    return v3 != getegid(); /*0x102cf8c6f*/
  }
  return v2; /*0x102cf8c76*/
}

// Address: 0x102cf8c80 | Name: _OPENSSL_atomic_add
__int64 __fastcall OPENSSL_atomic_add(volatile signed __int32 *a1, int a2)
{
  signed __int32 v2; // eax
  int v3; // r8d
  signed __int32 v4; // ett

  v2 = *a1; /*0x102cf8c84*/
  do /*0x102cf8c8f*/
  {
    v3 = a2 + v2; /*0x102cf8c86*/
    v4 = v2; /*0x102cf8c8a*/
    v2 = _InterlockedCompareExchange(a1, a2 + v2, v2); /*0x102cf8c8a*/
  }
  while ( v4 != v2 ); /*0x102cf8c8f*/
  return v3; /*0x102cf8c96*/
}

// Address: 0x102cf8ca0 | Name: _OPENSSL_rdtsc
unsigned __int64 OPENSSL_rdtsc()
{
  return __rdtsc(); /*0x102cf8cad*/
}

// Address: 0x102cf8cb0 | Name: _OPENSSL_ia32_cpuid
__int64 __fastcall OPENSSL_ia32_cpuid(__int64 a1, __m128i a2)
{
  unsigned int v7; // r11d
  _BOOL4 v8; // eax
  int v9; // r9d
  _BOOL4 v10; // r10d
  int v11; // r10d
  unsigned int v17; // r10d
  unsigned __int8 v28; // r10
  unsigned int v34; // r10d
  __int64 v42; // r9
  unsigned int v43; // r10d
  __m128i v49; // xmm1
  int v58; // eax

  _RAX = 0; /*0x102cf8cb7*/
  *(_QWORD *)(a1 + 8) = 0; /*0x102cf8cb9*/
  __asm { cpuid } /*0x102cf8cbd*/
  v7 = _RAX; /*0x102cf8cbf*/
  v8 = _RCX != 1818588270; /*0x102cf8ce2*/
  v9 = v8 || (_DWORD)_RDX != 1231384169 || (_DWORD)_RBX != 1970169159; /*0x102cf8ce5*/
  if ( v9 == 0 ) /*0x102cf8ce8*/
    goto LABEL_8; /*0x102cf8ce8*/
  LOBYTE(v8) = (_DWORD)_RBX != 1752462657; /*0x102cf8cf4*/
  v10 = v8; /*0x102cf8cf7*/
  LOBYTE(v8) = (_DWORD)_RDX != 1769238117; /*0x102cf8d00*/
  v11 = v8 || v10; /*0x102cf8d03*/
  LOBYTE(v8) = (_DWORD)_RCX != 1145913699; /*0x102cf8d0c*/
  if ( (v8 | v11) != 0 ) /*0x102cf8d12*/
    goto LABEL_8; /*0x102cf8d12*/
  _RAX = 0x80000000LL; /*0x102cf8d14*/
  __asm { cpuid } /*0x102cf8d19*/
  if ( (unsigned int)_RAX < 0x80000001 ) /*0x102cf8d20*/
    goto LABEL_8; /*0x102cf8d20*/
  v17 = _RAX; /*0x102cf8d22*/
  _RAX = 2147483649LL; /*0x102cf8d25*/
  __asm { cpuid } /*0x102cf8d2a*/
  v9 = ((unsigned __int16)_RCX | (unsigned __int16)v9) & 0x801; /*0x102cf8d2f*/
  if ( v17 < 0x80000008 ) /*0x102cf8d3d*/
  {
LABEL_8:
    v34 = -1; /*0x102cf8d79*/
    if ( v7 >= 4 ) /*0x102cf8d7f*/
    {
      _RAX = 4; /*0x102cf8d81*/
      __asm { cpuid } /*0x102cf8d8b*/
      v34 = ((unsigned int)_RAX >> 14) & 0xFFF; /*0x102cf8d94*/
    }
    _RAX = 1; /*0x102cf8d9b*/
    __asm { cpuid } /*0x102cf8da0*/
    a2 = _mm_cvtsi32_si128(_RAX); /*0x102cf8da2*/
    LODWORD(_RDX) = _RDX & 0xBFEFFFFF; /*0x102cf8da6*/
    if ( v9 == 0 ) /*0x102cf8db0*/
    {
      LODWORD(_RDX) = _RDX | 0x40000000; /*0x102cf8db2*/
      BYTE1(_RAX) &= 0xFu; /*0x102cf8db8*/
      if ( BYTE1(_RAX) == 15 ) /*0x102cf8dbe*/
        LODWORD(_RDX) = _RDX | 0x100000; /*0x102cf8dc0*/
      if ( BYTE1(_RAX) == 6 ) /*0x102cf8dc9*/
      {
        LODWORD(_RAX) = _RAX & 0xFFF0FF0; /*0x102cf8dcb*/
        if ( (_DWORD)_RAX == 329328 || (_DWORD)_RAX == 525904 ) /*0x102cf8ddc*/
          LODWORD(_RCX) = _RCX & 0xFBFFFFFF; /*0x102cf8dde*/
      }
    }
    if ( (_RDX & 0x10000000) != 0 ) /*0x102cf8de8*/
    {
      LODWORD(_RDX) = _RDX & 0xEFFFFFFF; /*0x102cf8dea*/
      if ( v34 != 0 ) /*0x102cf8df4*/
      {
        LODWORD(_RDX) = _RDX | 0x10000000; /*0x102cf8df6*/
        if ( BYTE2(_RBX) <= 1u ) /*0x102cf8e02*/
          LODWORD(_RDX) = _RDX & 0xEFFFFFFF; /*0x102cf8e04*/
      }
    }
  }
  else
  {
    _RAX = 2147483656LL; /*0x102cf8d3f*/
    __asm { cpuid } /*0x102cf8d44*/
    v28 = _RCX + 1; /*0x102cf8d4a*/
    _RAX = 1; /*0x102cf8d4d*/
    __asm { cpuid } /*0x102cf8d52*/
    if ( (_RDX & 0x10000000) != 0 && BYTE2(_RBX) <= v28 ) /*0x102cf8d64*/
      LODWORD(_RDX) = _RDX & 0xEFFFFFFF; /*0x102cf8d6a*/
  }
  v42 = _RCX & 0xFFFFF7FF | v9 & 0x800; /*0x102cf8e17*/
  v43 = _RDX; /*0x102cf8e1a*/
  if ( v7 >= 7 ) /*0x102cf8e21*/
  {
    _RAX = 7; /*0x102cf8e23*/
    __asm { cpuid } /*0x102cf8e2a*/
    v49 = _mm_cvtsi32_si128(_RAX); /*0x102cf8e2c*/
    if ( (v42 & 0x4000000) == 0 ) /*0x102cf8e35*/
      LODWORD(_RBX) = _RBX & 0xFFF7FFFF; /*0x102cf8e37*/
    if ( (_mm_cvtsi128_si32(a2) & 0xFFF0FF0) == 0x50650 ) /*0x102cf8e4b*/
      LODWORD(_RBX) = _RBX & 0xFFFEFFFF; /*0x102cf8e4d*/
    *(_DWORD *)(a1 + 8) = _RBX; /*0x102cf8e53*/
    *(_DWORD *)(a1 + 12) = _RCX; /*0x102cf8e56*/
    *(_DWORD *)(a1 + 16) = _RDX; /*0x102cf8e59*/
    LODWORD(_RAX) = _mm_cvtsi128_si32(v49); /*0x102cf8e5c*/
    if ( (_DWORD)_RAX != 0 ) /*0x102cf8e63*/
    {
      _RAX = 7; /*0x102cf8e65*/
      __asm { cpuid } /*0x102cf8e6f*/
      *(_DWORD *)(a1 + 20) = _RAX; /*0x102cf8e71*/
      *(_DWORD *)(a1 + 24) = _RDX; /*0x102cf8e74*/
      *(_DWORD *)(a1 + 28) = _RBX; /*0x102cf8e77*/
      *(_DWORD *)(a1 + 32) = _RCX; /*0x102cf8e7a*/
      if ( (_RDX & 0x80000) != 0 ) /*0x102cf8e86*/
      {
        _RAX = 36; /*0x102cf8e88*/
        __asm { cpuid } /*0x102cf8e92*/
        *(_DWORD *)(a1 + 36) = _RBX; /*0x102cf8e94*/
      }
    }
  }
  if ( (v42 & 0x8000000) == 0 ) /*0x102cf8e9c*/
    goto LABEL_32; /*0x102cf8e9c*/
  __asm { xgetbv } /*0x102cf8ea0*/
  v58 = _RAX & 0xE6; /*0x102cf8ea3*/
  if ( v58 != 230 ) /*0x102cf8ead*/
  {
    *(_DWORD *)(a1 + 8) &= 0x3FDEFFFFu; /*0x102cf8eaf*/
    if ( (v58 & 6) != 6 ) /*0x102cf8ebc*/
    {
LABEL_32:
      *(_DWORD *)(a1 + 20) &= ~0x800000u; /*0x102cf8ebe*/
      v42 = (unsigned int)v42 & 0xEFFFE7FF; /*0x102cf8eca*/
      *(_DWORD *)(a1 + 8) &= 0x3FDEFFDFu; /*0x102cf8ed2*/
    }
  }
  return (v42 << 32) | v43; /*0x102cf8ee2*/
}

// Address: 0x102cf8ef0 | Name: _OPENSSL_cleanse
void __cdecl OPENSSL_cleanse(void *ptr, size_t len)
{
  if ( len < 0xF ) /*0x102cf8efb*/
  {
    if ( len == 0 ) /*0x102cf8f01*/
      return; /*0x102cf8f01*/
    goto LABEL_3; /*0x102cf8f01*/
  }
  while ( ((unsigned __int8)ptr & 7) != 0 ) /*0x102cf8f27*/
  {
    *(_BYTE *)ptr = 0; /*0x102cf8f29*/
    --len; /*0x102cf8f2b*/
    ptr = (char *)ptr + 1; /*0x102cf8f2f*/
  }
  do /*0x102cf8f47*/
  {
    *(_QWORD *)ptr = 0; /*0x102cf8f35*/
    len -= 8LL; /*0x102cf8f38*/
    ptr = (char *)ptr + 8; /*0x102cf8f43*/
  }
  while ( (len & 0xFFFFFFFFFFFFFFF8LL) != 0 ); /*0x102cf8f47*/
  for ( ; len != 0; ptr = (char *)ptr + 1 ) /*0x102cf8f4d*/
  {
LABEL_3:
    *(_BYTE *)ptr = 0; /*0x102cf8f03*/
    --len; /*0x102cf8f05*/
  }
}

// Address: 0x102cf8fc0 | Name: _OPENSSL_wipe_cpu
char *__fastcall OPENSSL_wipe_cpu(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6, char a7)
{
  return &a7; /*0x102cf9029*/
}

// Address: 0x102cf9030 | Name: _OPENSSL_instrument_bus
__int64 __fastcall OPENSSL_instrument_bus(char *a1, __int64 a2)
{
  char *v2; // r10
  __int64 v3; // rcx
  unsigned __int64 v4; // rax
  int v5; // r8d
  unsigned __int64 v6; // rax
  int v7; // edx

  v2 = a1; /*0x102cf9034*/
  v3 = a2; /*0x102cf9037*/
  v4 = __rdtsc(); /*0x102cf903d*/
  v5 = v4; /*0x102cf903f*/
  _mm_clflush(a1); /*0x102cf9048*/
  _InterlockedAdd((volatile signed __int32 *)a1, 0); /*0x102cf904c*/
  do /*0x102cf907d*/
  {
    v6 = __rdtsc(); /*0x102cf9060*/
    v7 = v6; /*0x102cf9062*/
    LODWORD(v6) = v6 - v5; /*0x102cf9064*/
    v5 = v7; /*0x102cf9067*/
    _mm_clflush(v2); /*0x102cf906d*/
    _InterlockedAdd((volatile signed __int32 *)v2, v6); /*0x102cf9071*/
    v2 += 4; /*0x102cf9075*/
    --v3; /*0x102cf9079*/
  }
  while ( v3 != 0 ); /*0x102cf907d*/
  return a2; /*0x102cf9082*/
}

// Address: 0x102cf9090 | Name: _OPENSSL_instrument_bus2
__int64 __fastcall OPENSSL_instrument_bus2(char *a1, __int64 a2, __int64 a3)
{
  char *v3; // r10
  __int64 v4; // rcx
  unsigned __int64 v6; // rax
  int v7; // r8d
  unsigned __int64 v8; // rax
  int v9; // edx
  unsigned int v10; // eax
  int v11; // r8d
  unsigned int v12; // r9d
  unsigned __int64 v13; // rax
  int v14; // edx
  bool v15; // zf
  __int64 v16; // rdx

  v3 = a1; /*0x102cf9094*/
  v4 = a2; /*0x102cf9097*/
  v6 = __rdtsc(); /*0x102cf90a2*/
  v7 = v6; /*0x102cf90a4*/
  _mm_clflush(a1); /*0x102cf90ad*/
  _InterlockedAdd((volatile signed __int32 *)a1, 0); /*0x102cf90b1*/
  v8 = __rdtsc(); /*0x102cf90b5*/
  v9 = v8; /*0x102cf90b7*/
  v10 = v8 - v7; /*0x102cf90b9*/
  v11 = v9; /*0x102cf90bc*/
  v12 = v10; /*0x102cf90bf*/
  do /*0x102cf90ef*/
  {
    _mm_clflush(v3); /*0x102cf90c2*/
    _InterlockedAdd((volatile signed __int32 *)v3, v10); /*0x102cf90c6*/
    if ( --a3 == 0 ) /*0x102cf90ce*/
      break; /*0x102cf90ce*/
    v13 = __rdtsc(); /*0x102cf90d0*/
    v14 = v13; /*0x102cf90d2*/
    v10 = v13 - v11; /*0x102cf90d4*/
    v11 = v14; /*0x102cf90d7*/
    v15 = v10 == v12; /*0x102cf90da*/
    v12 = v10; /*0x102cf90dd*/
    v16 = !v15; /*0x102cf90e5*/
    v4 -= v16; /*0x102cf90e8*/
    v3 += 4 * v16; /*0x102cf90eb*/
  }
  while ( v4 != 0 ); /*0x102cf90ef*/
  return a2 - v4; /*0x102cf90f9*/
}

// Address: 0x102cf9100 | Name: _OPENSSL_ia32_rdrand_bytes
__int64 __fastcall OPENSSL_ia32_rdrand_bytes(unsigned __int64 *a1, unsigned __int64 a2)
{
  __int64 result; // rax
  __int64 i; // r11

  result = 0; /*0x102cf9104*/
  if ( a2 != 0 ) /*0x102cf910b*/
  {
    for ( i = 8; ; i = 8 ) /*0x102cf910d*/
    {
      while ( 1 ) /*0x102cf9114*/
      {
        __asm { rdrand r10 } /*0x102cf9114*/
        if ( _CF ) /*0x102cf9118*/
          break; /*0x102cf9118*/
        if ( --i == 0 ) /*0x102cf911d*/
          return result; /*0x102cf911d*/
      }
      if ( a2 < 8 ) /*0x102cf9134*/
        break; /*0x102cf9134*/
      *a1++ = _R10; /*0x102cf9136*/
      result += 8; /*0x102cf913d*/
      a2 -= 8LL; /*0x102cf9141*/
      if ( a2 == 0 ) /*0x102cf9145*/
        return result; /*0x102cf9145*/
    }
    do /*0x102cf9161*/
    {
      *(_BYTE *)a1 = _R10; /*0x102cf9150*/
      a1 = (unsigned __int64 *)((char *)a1 + 1); /*0x102cf9153*/
      ++result; /*0x102cf9157*/
      _R10 >>= 8; /*0x102cf915a*/
      --a2; /*0x102cf915e*/
    }
    while ( a2 != 0 ); /*0x102cf9161*/
  }
  return result; /*0x102cf9166*/
}

// Address: 0x102cf9170 | Name: _OPENSSL_ia32_rdseed_bytes
__int64 __fastcall OPENSSL_ia32_rdseed_bytes(unsigned __int64 *a1, unsigned __int64 a2)
{
  __int64 result; // rax
  __int64 i; // r11

  result = 0; /*0x102cf9174*/
  if ( a2 != 0 ) /*0x102cf917b*/
  {
    for ( i = 8; ; i = 8 ) /*0x102cf917d*/
    {
      while ( 1 ) /*0x102cf9184*/
      {
        __asm { rdseed r10 } /*0x102cf9184*/
        if ( _CF ) /*0x102cf9188*/
          break; /*0x102cf9188*/
        if ( --i == 0 ) /*0x102cf918d*/
          return result; /*0x102cf918d*/
      }
      if ( a2 < 8 ) /*0x102cf91a4*/
        break; /*0x102cf91a4*/
      *a1++ = _R10; /*0x102cf91a6*/
      result += 8; /*0x102cf91ad*/
      a2 -= 8LL; /*0x102cf91b1*/
      if ( a2 == 0 ) /*0x102cf91b5*/
        return result; /*0x102cf91b5*/
    }
    do /*0x102cf91d1*/
    {
      *(_BYTE *)a1 = _R10; /*0x102cf91c0*/
      a1 = (unsigned __int64 *)((char *)a1 + 1); /*0x102cf91c3*/
      ++result; /*0x102cf91c7*/
      _R10 >>= 8; /*0x102cf91ca*/
      --a2; /*0x102cf91ce*/
    }
    while ( a2 != 0 ); /*0x102cf91d1*/
  }
  return result; /*0x102cf91d6*/
}

// Address: 0x102cf9a00 | Name: _ossl_md5_block_asm_data_order
__int64 __fastcall ossl_md5_block_asm_data_order(unsigned int *a1, _DWORD *a2, __int64 a3)
{
  _DWORD *v4; // rdi
  __int64 result; // rax
  unsigned int v6; // ebx
  unsigned int v7; // ecx
  unsigned int v8; // edx
  int v9; // r8d
  unsigned int v10; // r9d
  unsigned int v11; // r14d
  unsigned int v12; // r15d
  unsigned int v13; // eax
  unsigned int v14; // edx
  unsigned int v15; // ecx
  unsigned int v16; // ebx
  unsigned int v17; // eax
  unsigned int v18; // edx
  unsigned int v19; // ecx
  unsigned int v20; // ebx
  int v21; // eax
  int v22; // edx
  int v23; // ecx
  int v24; // ebx
  int v25; // eax
  int v26; // edx
  int v27; // ecx
  int v28; // ebx
  int v29; // eax
  int v30; // edx
  int v31; // ecx
  int v32; // ebx
  int v33; // eax
  int v34; // edx
  int v35; // ecx
  int v36; // ebx
  int v37; // eax
  int v38; // edx
  int v39; // ecx
  int v40; // ebx
  int v41; // eax
  int v42; // edx
  int v43; // ecx
  int v44; // ebx
  int v45; // eax
  int v46; // edx
  int v47; // ecx
  int v48; // ebx
  int v49; // eax
  int v50; // edx
  int v51; // ecx
  int v52; // ebx
  int v53; // eax
  int v54; // edx
  int v55; // ecx
  int v56; // ebx
  int v57; // eax
  int v58; // edx
  int v59; // ecx
  int v60; // ebx
  int v61; // eax
  int v62; // edx
  int v63; // ecx
  int v64; // ebx
  int v65; // eax
  int v66; // edx
  int v67; // ecx
  int v68; // ebx
  int v69; // eax
  int v70; // edx
  int v71; // ecx
  int v72; // ebx
  int v73; // eax
  int v74; // edx
  int v75; // ecx
  int v76; // ebx

  v4 = &a2[16 * a3]; /*0x102cf9a0f*/
  result = *a1; /*0x102cf9a13*/
  v6 = a1[1]; /*0x102cf9a16*/
  v7 = a1[2]; /*0x102cf9a19*/
  v8 = a1[3]; /*0x102cf9a1c*/
  if ( a2 != v4 ) /*0x102cf9a22*/
  {
    do /*0x102cfa2bb*/
    {
      v9 = result; /*0x102cf9a28*/
      v10 = v6; /*0x102cf9a2b*/
      v11 = v7; /*0x102cf9a2e*/
      v12 = v8; /*0x102cf9a31*/
      v13 = v6 + __ROL4__((v8 ^ v6 & (v7 ^ v8)) + result + *a2 - 680876936, 7); /*0x102cf9a58*/
      v14 = v13 + __ROL4__((v7 ^ v13 & (v6 ^ v7)) + v8 + a2[1] - 389564586, 12); /*0x102cf9a78*/
      v15 = v14 + __ROL4__((v6 ^ v14 & (v13 ^ v6)) + v7 + a2[2] + 606105819, 17); /*0x102cf9a98*/
      v16 = v15 + __ROL4__((v13 ^ v15 & (v14 ^ v13)) + v6 + a2[3] - 1044525330, 22); /*0x102cf9ab8*/
      v17 = v16 + __ROL4__((v14 ^ v16 & (v15 ^ v14)) + v13 + a2[4] - 176418897, 7); /*0x102cf9ad8*/
      v18 = v17 + __ROL4__((v15 ^ v17 & (v16 ^ v15)) + v14 + a2[5] + 1200080426, 12); /*0x102cf9af8*/
      v19 = v18 + __ROL4__((v16 ^ v18 & (v17 ^ v16)) + v15 + a2[6] - 1473231341, 17); /*0x102cf9b18*/
      v20 = v19 + __ROL4__((v17 ^ v19 & (v18 ^ v17)) + v16 + a2[7] - 45705983, 22); /*0x102cf9b38*/
      v21 = v20 + __ROL4__((v18 ^ v20 & (v19 ^ v18)) + v17 + a2[8] + 1770035416, 7); /*0x102cf9b58*/
      v22 = v21 + __ROL4__((v19 ^ v21 & (v20 ^ v19)) + v18 + a2[9] - 1958414417, 12); /*0x102cf9b78*/
      v23 = v22 + __ROL4__((v20 ^ v22 & (v21 ^ v20)) + v19 + a2[10] - 42063, 17); /*0x102cf9b98*/
      v24 = v23 + __ROL4__((v21 ^ v23 & (v22 ^ v21)) + v20 + a2[11] - 1990404162, 22); /*0x102cf9bb8*/
      v25 = v24 + __ROL4__((v22 ^ v24 & (v23 ^ v22)) + v21 + a2[12] + 1804603682, 7); /*0x102cf9bd8*/
      v26 = v25 + __ROL4__((v23 ^ v25 & (v24 ^ v23)) + v22 + a2[13] - 40341101, 12); /*0x102cf9bf8*/
      v27 = v26 + __ROL4__((v24 ^ v26 & (v25 ^ v24)) + v23 + a2[14] - 1502002290, 17); /*0x102cf9c18*/
      v28 = v27 + __ROL4__((v25 ^ v27 & (v26 ^ v25)) + v24 + a2[15] + 1236535329, 22); /*0x102cf9c38*/
      v29 = v28 + __ROL4__((v28 & v26) + (v27 & ~v26) + v25 + a2[1] - 165796510, 5); /*0x102cf9c64*/
      v30 = v29 + __ROL4__((v29 & v27) + (v28 & ~v27) + v26 + a2[6] - 1069501632, 9); /*0x102cf9c8a*/
      v31 = v30 + __ROL4__((v30 & v28) + (v29 & ~v28) + v27 + a2[11] + 643717713, 14); /*0x102cf9caf*/
      v32 = v31 + __ROL4__((v31 & v29) + (v30 & ~v29) + v28 + *a2 - 373897302, 20); /*0x102cf9cd5*/
      v33 = v32 + __ROL4__((v32 & v30) + (v31 & ~v30) + v29 + a2[5] - 701558691, 5); /*0x102cf9cfb*/
      v34 = v33 + __ROL4__((v33 & v31) + (v32 & ~v31) + v30 + a2[10] + 38016083, 9); /*0x102cf9d21*/
      v35 = v34 + __ROL4__((v34 & v32) + (v33 & ~v32) + v31 + a2[15] - 660478335, 14); /*0x102cf9d47*/
      v36 = v35 + __ROL4__((v35 & v33) + (v34 & ~v33) + v32 + a2[4] - 405537848, 20); /*0x102cf9d6d*/
      v37 = v36 + __ROL4__((v36 & v34) + (v35 & ~v34) + v33 + a2[9] + 568446438, 5); /*0x102cf9d93*/
      v38 = v37 + __ROL4__((v37 & v35) + (v36 & ~v35) + v34 + a2[14] - 1019803690, 9); /*0x102cf9db9*/
      v39 = v38 + __ROL4__((v38 & v36) + (v37 & ~v36) + v35 + a2[3] - 187363961, 14); /*0x102cf9ddf*/
      v40 = v39 + __ROL4__((v39 & v37) + (v38 & ~v37) + v36 + a2[8] + 1163531501, 20); /*0x102cf9e05*/
      v41 = v40 + __ROL4__((v40 & v38) + (v39 & ~v38) + v37 + a2[13] - 1444681467, 5); /*0x102cf9e2b*/
      v42 = v41 + __ROL4__((v41 & v39) + (v40 & ~v39) + v38 + a2[2] - 51403784, 9); /*0x102cf9e51*/
      v43 = v42 + __ROL4__((v42 & v40) + (v41 & ~v40) + v39 + a2[7] + 1735328473, 14); /*0x102cf9e77*/
      v44 = v43 + __ROL4__((v43 & v41) + (v42 & ~v41) + v40 + a2[12] - 1926607734, 20); /*0x102cf9e9d*/
      v45 = v44 + __ROL4__((v44 ^ v42 ^ v43) + v41 + a2[5] - 378558, 4); /*0x102cf9ebd*/
      v46 = v45 + __ROL4__((v45 ^ v43 ^ v44) + v42 + a2[8] - 2022574463, 11); /*0x102cf9eda*/
      v47 = v46 + __ROL4__((v46 ^ v44 ^ v45) + v43 + a2[11] + 1839030562, 16); /*0x102cf9ef7*/
      v48 = v47 + __ROL4__((v47 ^ v45 ^ v46) + v44 + a2[14] - 35309556, 23); /*0x102cf9f14*/
      v49 = v48 + __ROL4__((v48 ^ v46 ^ v47) + v45 + a2[1] - 1530992060, 4); /*0x102cf9f31*/
      v50 = v49 + __ROL4__((v49 ^ v47 ^ v48) + v46 + a2[4] + 1272893353, 11); /*0x102cf9f4e*/
      v51 = v50 + __ROL4__((v50 ^ v48 ^ v49) + v47 + a2[7] - 155497632, 16); /*0x102cf9f6b*/
      v52 = v51 + __ROL4__((v51 ^ v49 ^ v50) + v48 + a2[10] - 1094730640, 23); /*0x102cf9f88*/
      v53 = v52 + __ROL4__((v52 ^ v50 ^ v51) + v49 + a2[13] + 681279174, 4); /*0x102cf9fa4*/
      v54 = v53 + __ROL4__((v53 ^ v51 ^ v52) + v50 + *a2 - 358537222, 11); /*0x102cf9fc1*/
      v55 = v54 + __ROL4__((v54 ^ v52 ^ v53) + v51 + a2[3] - 722521979, 16); /*0x102cf9fde*/
      v56 = v55 + __ROL4__((v55 ^ v53 ^ v54) + v52 + a2[6] + 76029189, 23); /*0x102cf9ffb*/
      v57 = v56 + __ROL4__((v56 ^ v54 ^ v55) + v53 + a2[9] - 640364487, 4); /*0x102cfa018*/
      v58 = v57 + __ROL4__((v57 ^ v55 ^ v56) + v54 + a2[12] - 421815835, 11); /*0x102cfa035*/
      v59 = v58 + __ROL4__((v58 ^ v56 ^ v57) + v55 + a2[15] + 530742520, 16); /*0x102cfa052*/
      v60 = v59 + __ROL4__((v59 ^ v57 ^ v58) + v56 + a2[2] - 995338651, 23); /*0x102cfa06e*/
      v61 = v60 + __ROL4__((v59 ^ (v60 | ~v58)) + v57 + *a2 - 198630844, 6); /*0x102cfa09a*/
      v62 = v61 + __ROL4__((v60 ^ (v61 | ~v59)) + v58 + a2[7] + 1126891415, 10); /*0x102cfa0bd*/
      v63 = v62 + __ROL4__((v61 ^ (v62 | ~v60)) + v59 + a2[14] - 1416354905, 15); /*0x102cfa0e0*/
      v64 = v63 + __ROL4__((v62 ^ (v63 | ~v61)) + v60 + a2[5] - 57434055, 21); /*0x102cfa103*/
      v65 = v64 + __ROL4__((v63 ^ (v64 | ~v62)) + v61 + a2[12] + 1700485571, 6); /*0x102cfa126*/
      v66 = v65 + __ROL4__((v64 ^ (v65 | ~v63)) + v62 + a2[3] - 1894986606, 10); /*0x102cfa149*/
      v67 = v66 + __ROL4__((v65 ^ (v66 | ~v64)) + v63 + a2[10] - 1051523, 15); /*0x102cfa16c*/
      v68 = v67 + __ROL4__((v66 ^ (v67 | ~v65)) + v64 + a2[1] - 2054922799, 21); /*0x102cfa18f*/
      v69 = v68 + __ROL4__((v67 ^ (v68 | ~v66)) + v65 + a2[8] + 1873313359, 6); /*0x102cfa1b2*/
      v70 = v69 + __ROL4__((v68 ^ (v69 | ~v67)) + v66 + a2[15] - 30611744, 10); /*0x102cfa1d5*/
      v71 = v70 + __ROL4__((v69 ^ (v70 | ~v68)) + v67 + a2[6] - 1560198380, 15); /*0x102cfa1f8*/
      v72 = v71 + __ROL4__((v70 ^ (v71 | ~v69)) + v68 + a2[13] + 1309151649, 21); /*0x102cfa21b*/
      v73 = v72 + __ROL4__((v71 ^ (v72 | ~v70)) + v69 + a2[4] - 145523070, 6); /*0x102cfa23e*/
      v74 = v73 + __ROL4__((v72 ^ (v73 | ~v71)) + v70 + a2[11] - 1120210379, 10); /*0x102cfa261*/
      v75 = v74 + __ROL4__((v73 ^ (v74 | ~v72)) + v71 + a2[2] + 718787259, 15); /*0x102cfa284*/
      v76 = __ROL4__((v74 ^ (v75 | ~v73)) + v72 + a2[9] - 343485551, 21); /*0x102cfa2a0*/
      result = (unsigned int)(v9 + v73); /*0x102cfa2a8*/
      v6 = v10 + v75 + v76; /*0x102cfa2ab*/
      v7 = v11 + v75; /*0x102cfa2ae*/
      v8 = v12 + v74; /*0x102cfa2b1*/
      a2 += 16; /*0x102cfa2b4*/
    }
    while ( a2 < v4 ); /*0x102cfa2bb*/
  }
  *a1 = result; /*0x102cfa2c1*/
  a1[1] = v6; /*0x102cfa2c4*/
  a1[2] = v7; /*0x102cfa2c7*/
  a1[3] = v8; /*0x102cfa2ca*/
  return result; /*0x102cfa2e9*/
}

// Address: 0x102cfa5a0 | Name: _ossl_md5_sha1_init
int __fastcall ossl_md5_sha1_init(__int64 a1)
{
  if ( MD5_Init(c: (_MD5_CTX *)a1) != 0 ) /*0x102cfa5b0*/
    return SHA1_Init(c: (SHA_CTX *)(a1 + 92)); /*0x102cfa5bf*/
  else
    return 0; /*0x102cfa5c4*/
}

// Address: 0x102cfa5d0 | Name: _ossl_md5_sha1_update
int __fastcall ossl_md5_sha1_update(__int64 a1, const void *a2, size_t a3)
{
  if ( MD5_Update(c: (_MD5_CTX *)a1, data: a2, len: a3) != 0 ) /*0x102cfa5ea*/
    return SHA1_Update(c: (SHA_CTX *)(a1 + 92), data: a2, len: a3); /*0x102cfa603*/
  else
    return 0; /*0x102cfa608*/
}

// Address: 0x102cfa620 | Name: _ossl_md5_sha1_final
int __fastcall ossl_md5_sha1_final(unsigned __int8 *a1, __int64 a2)
{
  if ( MD5_Final(md: a1, c: (_MD5_CTX *)a2) != 0 ) /*0x102cfa634*/
    return SHA1_Final(md: a1 + 16, c: (SHA_CTX *)(a2 + 92)); /*0x102cfa648*/
  else
    return 0; /*0x102cfa64d*/
}

// Address: 0x102cfa660 | Name: _ossl_md5_sha1_ctrl
__int64 __fastcall ossl_md5_sha1_ctrl(_MD5_CTX *c, int a2, int a3, const void *a4)
{
  __int64 result; // rax
  bool v7; // zf
  unsigned __int8 ptr[32]; // [rsp+0h] [rbp-80h] BYREF
  unsigned __int8 md[16]; // [rsp+20h] [rbp-60h] BYREF
  _QWORD data[6]; // [rsp+30h] [rbp-50h] BYREF

  result = 4294967294LL; /*0x102cfa67b*/
  if ( a2 == 29 ) /*0x102cfa683*/
  {
    result = 0; /*0x102cfa699*/
    if ( c != nullptr && a3 == 48 ) /*0x102cfa696*/
    {
      if ( MD5_Update(c, data: a4, len: 0x30u) != 0 /*0x102cfa7d0*/
        && SHA1_Update(c: (SHA_CTX *)&c[1], data: a4, len: 0x30u) > 0
        && (memset(data, 54, sizeof(data)), MD5_Update(c, data, len: 0x30u) != 0)
        && MD5_Final(md, c) != 0
        && SHA1_Update(c: (SHA_CTX *)&c[1], data, len: 0x28u) != 0
        && SHA1_Final(md: ptr, c: (SHA_CTX *)&c[1]) != 0
        && MD5_Init(c) != 0
        && SHA1_Init(c: (SHA_CTX *)&c[1]) != 0
        && ossl_md5_sha1_update(a1: (__int64)c, a2: a4, a3: 0x30u) > 0
        && (memset(data, 92, sizeof(data)), MD5_Update(c, data, len: 0x30u) != 0)
        && MD5_Update(c, data: md, len: 0x10u) != 0
        && SHA1_Update(c: (SHA_CTX *)&c[1], data, len: 0x28u) != 0 )
      {
        v7 = SHA1_Update(c: (SHA_CTX *)&c[1], data: ptr, len: 0x14u) == 0; /*0x102cfa7e3*/
        result = 0; /*0x102cfa7e5*/
        if ( !v7 ) /*0x102cfa7ea*/
        {
          OPENSSL_cleanse(ptr: md, len: 0x10u); /*0x102cfa7f5*/
          OPENSSL_cleanse(ptr, len: 0x14u); /*0x102cfa803*/
          return 1; /*0x102cfa808*/
        }
      }
      else
      {
        return 0; /*0x102cfa80f*/
      }
    }
  }
  return result; /*0x102cfa821*/
}

// Address: 0x102cfa840 | Name: _ossl_ml_dsa_pk_encode
__int64 __fastcall ossl_ml_dsa_pk_encode(__int64 a1)
{
  __int64 v2; // r13
  __int64 v3; // r15
  __int64 v4; // r12
  void *v5; // rax
  void *v6; // r14
  __int64 v7; // rdx
  unsigned int v8; // r12d
  __int64 v9; // r13
  __int64 v10; // r12
  unsigned __int64 v11; // rax
  int v12; // esi
  unsigned int v13; // edi
  unsigned int v14; // edx
  unsigned int v15; // ecx
  _BYTE *v16; // r8
  _BYTE *v17; // rsi
  _BYTE *v18; // rdi
  _BYTE *v19; // rdx
  _BYTE *v20; // rdx
  _BYTE v22[56]; // [rsp+8h] [rbp-78h] BYREF
  __int64 v23; // [rsp+40h] [rbp-40h]
  __int64 v24; // [rsp+48h] [rbp-38h] BYREF
  _BYTE *v25; // [rsp+50h] [rbp-30h] BYREF

  v24 = 0; /*0x102cfa854*/
  v2 = *(_QWORD *)(a1 + 192); /*0x102cfa860*/
  v3 = *(_QWORD *)(a1 + 200); /*0x102cfa867*/
  v4 = *(_QWORD *)(*(_QWORD *)(a1 + 8) + 72LL); /*0x102cfa86e*/
  v5 = CRYPTO_malloc(num: v4, file: "crypto/ml_dsa/ml_dsa_encoders.c", line: 629); /*0x102cfa881*/
  if ( v5 != nullptr ) /*0x102cfa889*/
  {
    v6 = v5; /*0x102cfa88f*/
    v7 = v4; /*0x102cfa892*/
    v8 = 0; /*0x102cfa895*/
    v23 = v7; /*0x102cfa89f*/
    if ( (unsigned int)WPACKET_init_static_len(a1: v22, a2: v5, a3: v7, a4: 0) == 0 /*0x102cfa8c6*/
      || (unsigned int)WPACKET_memcpy(a1: v22, a2: a1 + 32) == 0 )
    {
      goto LABEL_15; /*0x102cfa8c6*/
    }
    if ( v3 != 0 ) /*0x102cfa8cf*/
    {
      v9 = v2 + 12; /*0x102cfa8d5*/
      v10 = 0; /*0x102cfa8d9*/
      while ( (unsigned int)WPACKET_allocate_bytes(a1: v22, a2: 320, a3: &v25) != 0 ) /*0x102cfa8f4*/
      {
        v11 = -16; /*0x102cfa8fa*/
        do /*0x102cfa99d*/
        {
          v12 = *(_DWORD *)(v9 + v11 + 4); /*0x102cfa910*/
          v13 = *(_DWORD *)(v9 + v11 + 8); /*0x102cfa915*/
          v14 = *(_DWORD *)(v9 + v11 + 12); /*0x102cfa91a*/
          v15 = *(_DWORD *)(v9 + v11 + 16); /*0x102cfa91f*/
          v16 = v25++; /*0x102cfa924*/
          *v16 = v12; /*0x102cfa930*/
          LOBYTE(v16) = BYTE1(v12) | (4 * v13); /*0x102cfa93e*/
          v17 = v25++; /*0x102cfa941*/
          *v17 = (_BYTE)v16; /*0x102cfa94d*/
          LOBYTE(v17) = (v13 >> 6) | (16 * v14); /*0x102cfa958*/
          v18 = v25++; /*0x102cfa95a*/
          *v18 = (_BYTE)v17; /*0x102cfa966*/
          LOBYTE(v17) = (v14 >> 4) | ((_BYTE)v15 << 6); /*0x102cfa971*/
          v19 = v25++; /*0x102cfa973*/
          *v19 = (_BYTE)v17; /*0x102cfa97f*/
          v20 = v25++; /*0x102cfa985*/
          *v20 = v15 >> 2; /*0x102cfa991*/
          v11 += 16LL; /*0x102cfa993*/
        }
        while ( v11 < 0x3F0 ); /*0x102cfa99d*/
        ++v10; /*0x102cfa9a3*/
        v9 += 1024; /*0x102cfa9a6*/
        if ( v10 == v3 ) /*0x102cfa9b0*/
          goto LABEL_10; /*0x102cfa9b0*/
      }
      v8 = 0; /*0x102cfaa0c*/
      goto LABEL_15; /*0x102cfaa0c*/
    }
LABEL_10:
    v8 = 0; /*0x102cfa9c5*/
    if ( (unsigned int)WPACKET_get_total_written(a1: v22, a2: &v24) == 0 || v24 != v23 ) /*0x102cfa9d5*/
    {
LABEL_15:
      WPACKET_finish(a1: v22); /*0x102cfaa0f*/
      CRYPTO_free(a1: v6); /*0x102cfaa27*/
      return v8; /*0x102cfaa27*/
    }
    CRYPTO_free(a1: *(void **)(a1 + 160)); /*0x102cfa9ea*/
    *(_QWORD *)(a1 + 160) = v6; /*0x102cfa9ef*/
    WPACKET_finish(a1: v22); /*0x102cfa9fa*/
    return 1; /*0x102cfa9ff*/
  }
  else
  {
    return 0; /*0x102cfaa07*/
  }
}

// Address: 0x102cfaa40 | Name: _ossl_ml_dsa_pk_decode
_BOOL8 __fastcall ossl_ml_dsa_pk_decode(__int64 a1, __int128 *a2, signed __int64 a3)
{
  _BOOL8 result; // rax
  int v6; // ecx
  EVP_MD_CTX *v7; // rdi
  _BOOL4 v8; // r13d
  __int128 v9; // xmm0
  unsigned __int64 v10; // r8
  _OWORD *v11; // r15
  __int64 v12; // r9
  __int64 v13; // r10
  unsigned __int64 v14; // r11
  bool v15; // cf
  _OWORD *v16; // r13
  unsigned int v17; // r12d
  unsigned int v18; // r15d
  EVP_MD_CTX *v19; // r15
  int v20; // eax
  void *v21; // rax
  __int64 v22; // [rsp-40h] [rbp-40h]

  result = false; /*0x102cfaa40*/
  if ( *(_QWORD *)(a1 + 168) == 0 && *(_QWORD *)(a1 + 160) == 0 && *(_QWORD *)(*(_QWORD *)(a1 + 8) + 72LL) == a3 ) /*0x102cfaa70*/
  {
    v6 = ossl_ml_dsa_key_pub_alloc(); /*0x102cfaa81*/
    result = false; /*0x102cfaa83*/
    if ( v6 != 0 ) /*0x102cfaa87*/
    {
      v7 = (EVP_MD_CTX *)EVP_MD_CTX_new(); /*0x102cfaa8e*/
      if ( v7 != nullptr && a3 >= 32 ) /*0x102cfaa9b*/
      {
        v9 = *a2; /*0x102cfaac2*/
        *(_OWORD *)(a1 + 48) = a2[1]; /*0x102cfaacf*/
        *(_OWORD *)(a1 + 32) = v9; /*0x102cfaad3*/
        v22 = *(_QWORD *)(a1 + 200); /*0x102cfaade*/
        if ( v22 == 0 ) /*0x102cfaae5*/
        {
LABEL_16:
          v8 = false; /*0x102cfab82*/
          v19 = v7; /*0x102cfab8d*/
          v20 = shake_xof(ctx: v7); /*0x102cfab90*/
          v7 = v19; /*0x102cfab95*/
          if ( v20 != 0 ) /*0x102cfab9a*/
          {
            v21 = CRYPTO_memdup(__src: a2, __n: a3, file: "crypto/ml_dsa/ml_dsa_encoders.c", line: 692); /*0x102cfabb2*/
            v7 = v19; /*0x102cfabb7*/
            *(_QWORD *)(a1 + 160) = v21; /*0x102cfabbe*/
            v8 = v21 != nullptr; /*0x102cfabcb*/
          }
          goto LABEL_8; /*0x102cfabcf*/
        }
        v10 = a3 - 32; /*0x102cfaaeb*/
        v11 = a2 + 2; /*0x102cfaaef*/
        v12 = *(_QWORD *)(a1 + 192) + 12LL; /*0x102cfaafa*/
        v13 = 0; /*0x102cfaafe*/
LABEL_12:
        v14 = -16; /*0x102cfab01*/
        while ( 1 ) /*0x102cfab10*/
        {
          v15 = v10 < 5; /*0x102cfab10*/
          v10 -= 5LL; /*0x102cfab10*/
          if ( v15 ) /*0x102cfab14*/
            break; /*0x102cfab14*/
          v16 = (_OWORD *)((char *)v11 + 5); /*0x102cfab16*/
          v17 = *(_DWORD *)v11; /*0x102cfab1a*/
          v18 = *((unsigned __int8 *)v11 + 4); /*0x102cfab1d*/
          *(_DWORD *)(v12 + v14 + 4) = v17 & 0x3FF; /*0x102cfab2b*/
          *(_DWORD *)(v12 + v14 + 8) = (v17 >> 10) & 0x3FF; /*0x102cfab41*/
          *(_DWORD *)(v12 + v14 + 12) = (v17 >> 20) & 0x3FF; /*0x102cfab51*/
          *(_DWORD *)(v12 + v14 + 16) = __PAIR64__(v18, v17) >> 30; /*0x102cfab56*/
          v14 += 16LL; /*0x102cfab5b*/
          v11 = v16; /*0x102cfab5f*/
          if ( v14 >= 0x3F0 ) /*0x102cfab69*/
          {
            ++v13; /*0x102cfab6b*/
            v12 += 1024; /*0x102cfab6e*/
            v11 = v16; /*0x102cfab75*/
            if ( v13 != v22 ) /*0x102cfab7c*/
              goto LABEL_12; /*0x102cfab7c*/
            goto LABEL_16; /*0x102cfab7c*/
          }
        }
      }
      v8 = false; /*0x102cfaaa2*/
LABEL_8:
      EVP_MD_CTX_free(ctx: v7); /*0x102cfaaa5*/
      return v8; /*0x102cfaaaa*/
    }
  }
  return result; /*0x102cfaa4c*/
}

// Address: 0x102cfac50 | Name: _ossl_ml_dsa_sk_encode
__int64 __fastcall ossl_ml_dsa_sk_encode(__int64 a1)
{
  __int64 v2; // rbx
  __int64 v3; // r15
  size_t v4; // r13
  __int64 v5; // r12
  void *v6; // rax
  bool v7; // zf
  __int64 (__fastcall *v8)(); // rbx
  __int64 v9; // r13
  __int64 v10; // r13
  __int64 v11; // r15
  __int64 v12; // rbx
  unsigned __int64 v13; // r13
  int v14; // ecx
  int v15; // eax
  unsigned __int64 v16; // rax
  int v17; // edx
  int v18; // ecx
  unsigned __int64 v19; // rcx
  int v20; // edx
  __int64 v21; // rdx
  unsigned __int64 v22; // rax
  __int64 v23; // rcx
  int v24; // esi
  unsigned __int64 v25; // rsi
  unsigned __int64 *v26; // rcx
  _BYTE v28[56]; // [rsp+8h] [rbp-88h] BYREF
  unsigned __int64 *v29; // [rsp+40h] [rbp-50h] BYREF
  __int64 v30; // [rsp+48h] [rbp-48h] BYREF
  void *v31; // [rsp+50h] [rbp-40h]
  __int64 v32; // [rsp+58h] [rbp-38h]
  size_t v33; // [rsp+60h] [rbp-30h]

  v2 = *(_QWORD *)(a1 + 8); /*0x102cfac64*/
  v30 = 0; /*0x102cfac68*/
  v32 = *(_QWORD *)(v2 + 32); /*0x102cfac74*/
  v3 = *(_QWORD *)(v2 + 40); /*0x102cfac78*/
  v4 = *(_QWORD *)(v2 + 64); /*0x102cfac7c*/
  v5 = *(_QWORD *)(a1 + 208); /*0x102cfac80*/
  v6 = CRYPTO_malloc(num: v4, file: "crypto/ml_dsa/ml_dsa_encoders.c", line: 716); /*0x102cfac96*/
  if ( v6 != nullptr ) /*0x102cfac9e*/
  {
    v7 = *(_DWORD *)(v2 + 48) == 4; /*0x102cfaca4*/
    v8 = poly_encode_signed_2; /*0x102cfacaf*/
    if ( v7 ) /*0x102cfacb6*/
      v8 = poly_encode_signed_4; /*0x102cfacb6*/
    v31 = v6; /*0x102cfacc1*/
    v33 = v4; /*0x102cfacc8*/
    if ( (unsigned int)WPACKET_init_static_len(a1: v28, a2: v6, a3: v4, a4: 0) != 0 /*0x102cfad32*/
      && (unsigned int)WPACKET_memcpy(a1: v28, a2: a1 + 32) != 0
      && (unsigned int)WPACKET_memcpy(a1: v28, a2: a1 + 128) != 0
      && (unsigned int)WPACKET_memcpy(a1: v28, a2: a1 + 64) != 0 )
    {
      if ( v3 != 0 ) /*0x102cfad3b*/
      {
        v9 = 0; /*0x102cfad3d*/
        while ( ((unsigned int (__fastcall *)(__int64, _BYTE *))v8)(a1: v9 + *(_QWORD *)(a1 + 240), a2: v28) != 0 ) /*0x102cfad55*/
        {
          v9 += 1024; /*0x102cfad5b*/
          if ( --v3 == 0 ) /*0x102cfad65*/
            goto LABEL_12; /*0x102cfad65*/
        }
      }
      else
      {
LABEL_12:
        v10 = v32; /*0x102cfad67*/
        if ( v32 != 0 ) /*0x102cfad6e*/
        {
          v11 = 0; /*0x102cfad74*/
          while ( ((unsigned int (__fastcall *)(__int64, _BYTE *))v8)(a1: v11 + *(_QWORD *)(a1 + 224), a2: v28) != 0 ) /*0x102cfad95*/
          {
            v11 += 1024; /*0x102cfad9b*/
            if ( --v10 == 0 ) /*0x102cfada5*/
            {
              v12 = 0; /*0x102cfada7*/
LABEL_17:
              v13 = -32; /*0x102cfadb0*/
              while ( (unsigned int)WPACKET_allocate_bytes(a1: v28, a2: 13, a3: &v29) != 0 ) /*0x102cfadd3*/
              {
                v14 = *(_DWORD *)(v5 + v13 + 32); /*0x102cfadd9*/
                v15 = *(_DWORD *)(v5 + v13 + 36); /*0x102cfadde*/
                v16 = (8384513 - v14) & (((4096 - v14) & (v14 - 8384514)) >> 31) /*0x102cfae2c*/
                    | (4096 - v14) & (unsigned int)~(((4096 - v14) & (v14 - 8384514)) >> 31)
                    | ((unsigned __int64)((8384513 - v15) & (((4096 - v15) & (v15 - 8384514)) >> 31)
                                        | (4096 - v15) & (unsigned int)~(((4096 - v15) & (v15 - 8384514)) >> 31)) << 13);
                v17 = *(_DWORD *)(v5 + v13 + 40); /*0x102cfae2f*/
                v18 = *(_DWORD *)(v5 + v13 + 44); /*0x102cfae5b*/
                v19 = v16 /*0x102cfae8d*/
                    | ((unsigned __int64)((8384513 - v17) & (((4096 - v17) & (v17 - 8384514)) >> 31)
                                        | (4096 - v17) & (unsigned int)~(((4096 - v17) & (v17 - 8384514)) >> 31)) << 26)
                    | ((unsigned __int64)((8384513 - v18) & (((4096 - v18) & (v18 - 8384514)) >> 31)
                                        | (4096 - v18) & (unsigned int)~(((4096 - v18) & (v18 - 8384514)) >> 31)) << 39);
                v20 = *(_DWORD *)(v5 + v13 + 48); /*0x102cfae90*/
                v21 = (8384513 - v20) & (((4096 - v20) & (v20 - 8384514)) >> 31) /*0x102cfaeb6*/
                    | (4096 - v20) & (unsigned int)~(((4096 - v20) & (v20 - 8384514)) >> 31);
                v22 = v19 | (v21 << 52); /*0x102cfaebf*/
                LODWORD(v19) = *(_DWORD *)(v5 + v13 + 52); /*0x102cfaec5*/
                v23 = ((unsigned int)v21 >> 12) /*0x102cfaef3*/
                    | (2LL
                     * ((8384513 - (_DWORD)v19) & ((int)((4096 - v19) & (v19 - 8384514)) >> 31)
                      | (4096 - (_DWORD)v19) & (unsigned int)~((int)((4096 - v19) & (v19 - 8384514)) >> 31)));
                LODWORD(v21) = *(_DWORD *)(v5 + v13 + 56); /*0x102cfaef6*/
                v24 = *(_DWORD *)(v5 + v13 + 60); /*0x102cfaf25*/
                v25 = v23 /*0x102cfaf5b*/
                    | ((unsigned __int64)((8384513 - (_DWORD)v21) & ((int)((4096 - v21) & (v21 - 8384514)) >> 31)
                                        | (4096 - (_DWORD)v21)
                                        & (unsigned int)~((int)((4096 - v21) & (v21 - 8384514)) >> 31)) << 14)
                    | ((unsigned __int64)((8384513 - v24) & (((4096 - v24) & (v24 - 8384514)) >> 31)
                                        | (4096 - v24) & (unsigned int)~(((4096 - v24) & (v24 - 8384514)) >> 31)) << 27);
                v26 = v29; /*0x102cfaf5e*/
                *v29 = v22; /*0x102cfaf62*/
                *((_DWORD *)v26 + 2) = v25; /*0x102cfaf65*/
                *((_BYTE *)v26 + 12) = BYTE4(v25); /*0x102cfaf6c*/
                v13 += 32LL; /*0x102cfaf70*/
                if ( v13 >= 0x3E0 ) /*0x102cfaf7b*/
                {
                  v5 += 1024; /*0x102cfaf81*/
                  if ( ++v12 != v32 ) /*0x102cfaf8f*/
                    goto LABEL_17; /*0x102cfaf8f*/
                  goto LABEL_21; /*0x102cfaf8f*/
                }
              }
              break; /*0x102cfadd3*/
            }
          }
        }
        else
        {
LABEL_21:
          if ( (unsigned int)WPACKET_get_total_written(a1: v28, a2: &v30) != 0 && v30 == v33 ) /*0x102cfafb1*/
          {
            CRYPTO_clear_free(a1: *(void **)(a1 + 168), a2: v33); /*0x102cfafca*/
            *(_QWORD *)(a1 + 168) = v31; /*0x102cfafd3*/
            WPACKET_finish(a1: v28); /*0x102cfafe1*/
            return 1; /*0x102cfafeb*/
          }
        }
      }
    }
    WPACKET_finish(a1: v28); /*0x102cfafed*/
    CRYPTO_clear_free(a1: v31, a2: v33); /*0x102cfb00d*/
  }
  return 0; /*0x102cfb014*/
}

// Address: 0x102cfb2e0 | Name: _ossl_ml_dsa_sk_decode
__int64 __fastcall ossl_ml_dsa_sk_decode(__int64 a1, __int128 *a2, signed __int64 a3)
{
  __int64 v6; // r13
  __int64 v7; // r12
  __int128 *v8; // rax
  bool v9; // cl
  bool v10; // dl
  __int64 result; // rax
  __int64 (__fastcall *v12)(); // rcx
  __int128 v13; // xmm0
  __int128 v14; // xmm0
  __int128 v15; // xmm0
  __int128 v16; // xmm1
  __int128 v17; // xmm2
  __int64 v18; // r13
  __int64 (__fastcall *v19)(); // r12
  __int64 v20; // r13
  __int64 *v21; // rsi
  unsigned __int64 v22; // rax
  __int64 v23; // rcx
  __int64 v24; // rdi
  __int64 *v25; // r8
  bool v26; // cf
  unsigned __int64 v27; // r9
  unsigned int v28; // r10d
  unsigned int v29; // r8d
  void *v30; // rcx
  __int64 (__fastcall *v31)(); // [rsp+0h] [rbp-90h]
  __int64 *v32; // [rsp+8h] [rbp-88h] BYREF
  signed __int64 v33; // [rsp+10h] [rbp-80h]
  __int64 (__fastcall *v34)(); // [rsp+18h] [rbp-78h]
  _QWORD __s1[8]; // [rsp+20h] [rbp-70h] BYREF

  v6 = *(_QWORD *)(a1 + 8); /*0x102cfb308*/
  v31 = *(__int64 (__fastcall **)())(v6 + 32); /*0x102cfb310*/
  v7 = *(_QWORD *)(v6 + 40); /*0x102cfb317*/
  CRYPTO_clear_free(a1: *(void **)(a1 + 176), a2: 0x20u); /*0x102cfb333*/
  *(_QWORD *)(a1 + 176) = 0; /*0x102cfb338*/
  v8 = *(__int128 **)(a1 + 168); /*0x102cfb343*/
  v9 = v8 != nullptr; /*0x102cfb34d*/
  v10 = v8 != a2; /*0x102cfb353*/
  result = 0; /*0x102cfb356*/
  if ( v10 && v9 || *(_QWORD *)(a1 + 160) != 0 || *(_QWORD *)(*(_QWORD *)(a1 + 8) + 64LL) != a3 ) /*0x102cfb376*/
    return result; /*0x102cfb376*/
  if ( (unsigned int)ossl_ml_dsa_key_priv_alloc(a1) == 0 ) /*0x102cfb386*/
    return 0; /*0x102cfb386*/
  v12 = poly_decode_signed_2; /*0x102cfb398*/
  if ( *(_DWORD *)(v6 + 48) == 4 ) /*0x102cfb39f*/
    v12 = poly_decode_signed_4; /*0x102cfb39f*/
  v34 = v12; /*0x102cfb3a3*/
  result = 0; /*0x102cfb3aa*/
  if ( a3 < 32 ) /*0x102cfb3af*/
    return result; /*0x102cfb3af*/
  v13 = *a2; /*0x102cfb3c9*/
  *(_OWORD *)(a1 + 48) = a2[1]; /*0x102cfb3d2*/
  *(_OWORD *)(a1 + 32) = v13; /*0x102cfb3d6*/
  if ( (a3 & 0x7FFFFFFFFFFFFFE0LL) == 0x20 ) /*0x102cfb3e5*/
    return result; /*0x102cfb3e5*/
  v14 = a2[2]; /*0x102cfb3eb*/
  *(_OWORD *)(a1 + 144) = a2[3]; /*0x102cfb3f5*/
  *(_OWORD *)(a1 + 128) = v14; /*0x102cfb3fc*/
  if ( (a3 & 0x7FFFFFFFFFFFFFC0LL) == 0x40 ) /*0x102cfb40a*/
    return result; /*0x102cfb40a*/
  v15 = a2[4]; /*0x102cfb410*/
  v16 = a2[5]; /*0x102cfb415*/
  v17 = a2[6]; /*0x102cfb41a*/
  *(_OWORD *)&__s1[6] = a2[7]; /*0x102cfb424*/
  *(_OWORD *)&__s1[4] = v17; /*0x102cfb428*/
  *(_OWORD *)&__s1[2] = v16; /*0x102cfb42c*/
  *(_OWORD *)__s1 = v15; /*0x102cfb430*/
  v32 = (__int64 *)(a2 + 8); /*0x102cfb43b*/
  v33 = a3 - 128; /*0x102cfb446*/
  if ( v7 != 0 ) /*0x102cfb44d*/
  {
    v18 = 0; /*0x102cfb44f*/
    while ( ((unsigned int (__fastcall *)(__int64, __int64 **))v34)(a1: v18 + *(_QWORD *)(a1 + 240), a2: &v32) != 0 ) /*0x102cfb468*/
    {
      v18 += 1024; /*0x102cfb46e*/
      if ( --v7 == 0 ) /*0x102cfb478*/
        goto LABEL_14; /*0x102cfb478*/
    }
    return 0; /*0x102cfb468*/
  }
LABEL_14:
  v19 = v31; /*0x102cfb47a*/
  if ( v31 != nullptr ) /*0x102cfb484*/
  {
    v20 = 0; /*0x102cfb48a*/
    while ( ((unsigned int (__fastcall *)(__int64, __int64 **))v34)(a1: v20 + *(_QWORD *)(a1 + 224), a2: &v32) != 0 ) /*0x102cfb4a3*/
    {
      v20 += 1024; /*0x102cfb4a9*/
      v19 = (__int64 (__fastcall *)())((char *)v19 - 1); /*0x102cfb4b0*/
      if ( v19 == nullptr ) /*0x102cfb4b3*/
      {
        v21 = v32; /*0x102cfb4b5*/
        v22 = v33; /*0x102cfb4bc*/
        v23 = *(_QWORD *)(a1 + 208); /*0x102cfb4c0*/
        v34 = nullptr; /*0x102cfb4c7*/
LABEL_19:
        v24 = 0; /*0x102cfb4cf*/
        v25 = v21; /*0x102cfb4d1*/
        while ( 1 ) /*0x102cfb4d4*/
        {
          v26 = v22 < 0xD; /*0x102cfb4d4*/
          v22 -= 13LL; /*0x102cfb4d4*/
          if ( v26 ) /*0x102cfb4d8*/
            return 0; /*0x102cfb4d8*/
          v21 = (__int64 *)((char *)v25 + 13); /*0x102cfb4de*/
          v32 = (__int64 *)((char *)v25 + 13); /*0x102cfb4e2*/
          v33 = v22; /*0x102cfb4e9*/
          v27 = *v25; /*0x102cfb4ed*/
          v28 = *((_DWORD *)v25 + 2); /*0x102cfb4f0*/
          v29 = *((unsigned __int8 *)v25 + 12); /*0x102cfb4f4*/
          *(_DWORD *)(v23 + v24) = (8384513 - (v27 & 0x1FFF)) & ((int)(4096 - (v27 & 0x1FFF)) >> 31) /*0x102cfb52b*/
                                 | (4096 - (v27 & 0x1FFF)) & ~((int)(4096 - (v27 & 0x1FFF)) >> 31);
          *(_DWORD *)(v23 + v24 + 4) = (8384513 - (((unsigned int)v27 >> 13) & 0x1FFF)) /*0x102cfb561*/
                                     & ((int)(4096 - (((unsigned int)v27 >> 13) & 0x1FFF)) >> 31)
                                     | (4096 - (((unsigned int)v27 >> 13) & 0x1FFF))
                                     & ~((int)(4096 - (((unsigned int)v27 >> 13) & 0x1FFF)) >> 31);
          *(_DWORD *)(v23 + v24 + 8) = (8384513 - ((v27 >> 26) & 0x1FFF)) & ((int)(4096 - ((v27 >> 26) & 0x1FFF)) >> 31) /*0x102cfb598*/
                                     | (4096 - ((v27 >> 26) & 0x1FFF)) & ~((int)(4096 - ((v27 >> 26) & 0x1FFF)) >> 31);
          *(_DWORD *)(v23 + v24 + 12) = (8384513 - ((v27 >> 39) & 0x1FFF)) /*0x102cfb5cf*/
                                      & ((int)(4096 - ((v27 >> 39) & 0x1FFF)) >> 31)
                                      | (4096 - ((v27 >> 39) & 0x1FFF)) & ~((int)(4096 - ((v27 >> 39) & 0x1FFF)) >> 31);
          LODWORD(v27) = ((v28 & 1) << 12) | (v27 >> 52); /*0x102cfb5ea*/
          *(_DWORD *)(v23 + v24 + 16) = (8384513 - v27) & ((4096 - (int)v27) >> 31) /*0x102cfb614*/
                                      | (4096 - v27) & ~((4096 - (int)v27) >> 31);
          *(_DWORD *)(v23 + v24 + 20) = (8384513 - ((v28 >> 1) & 0x1FFF)) & ((int)(4096 - ((v28 >> 1) & 0x1FFF)) >> 31) /*0x102cfb64a*/
                                      | (4096 - ((v28 >> 1) & 0x1FFF)) & ~((int)(4096 - ((v28 >> 1) & 0x1FFF)) >> 31);
          *(_DWORD *)(v23 + v24 + 24) = (8384513 - ((v28 >> 14) & 0x1FFF)) /*0x102cfb681*/
                                      & ((int)(4096 - ((v28 >> 14) & 0x1FFF)) >> 31)
                                      | (4096 - ((v28 >> 14) & 0x1FFF)) & ~((int)(4096 - ((v28 >> 14) & 0x1FFF)) >> 31);
          *(_DWORD *)(v23 + v24 + 28) = (8384513 - (__PAIR64__(v29, v28) >> 27)) /*0x102cfb6ad*/
                                      & ((int)(4096 - (__PAIR64__(v29, v28) >> 27)) >> 31)
                                      | (4096 - (__PAIR64__(v29, v28) >> 27))
                                      & ~((int)(4096 - (__PAIR64__(v29, v28) >> 27)) >> 31);
          v24 += 32; /*0x102cfb6b2*/
          v25 = v21; /*0x102cfb6b6*/
          if ( (_DWORD)v24 == 1024 ) /*0x102cfb6bf*/
          {
            v23 += 1024; /*0x102cfb6cc*/
            v34 = (__int64 (__fastcall *)())((char *)v34 + 1); /*0x102cfb6d3*/
            if ( v34 != v31 ) /*0x102cfb6de*/
              goto LABEL_19; /*0x102cfb6de*/
            goto LABEL_23; /*0x102cfb6de*/
          }
        }
      }
    }
    return 0; /*0x102cfb4a3*/
  }
LABEL_23:
  if ( v33 != 0 ) /*0x102cfb6e9*/
    return 0; /*0x102cfb787*/
  if ( *(_QWORD *)(a1 + 168) != 0 /*0x102cfb71f*/
    || (v30 = CRYPTO_memdup(__src: a2, __n: a3, file: "crypto/ml_dsa/ml_dsa_encoders.c", line: 809),
        result = 0,
        *(_QWORD *)(a1 + 168) = v30,
        v30 != nullptr) )
  {
    if ( (unsigned int)ossl_ml_dsa_key_public_from_private(a1) != 0 /*0x102cfb741*/
      && memcmp(__s1, __s2: (const void *)(a1 + 64), __n: 0x40u) == 0 )
    {
      return 1; /*0x102cfb7a8*/
    }
    ERR_new(); /*0x102cfb743*/
    ERR_set_debug(__s: "crypto/ml_dsa/ml_dsa_encoders.c", a2: 817, a3: "ossl_ml_dsa_sk_decode"); /*0x102cfb75b*/
    ERR_set_error( /*0x102cfb77a*/
      a1: 57,
      a2: 158,
      a3: (__int64)"%s private key does not match its pubkey part",
      **(const char ***)(a1 + 8));
    ossl_ml_dsa_key_reset(a1); /*0x102cfb782*/
    return 0; /*0x102cfb782*/
  }
  return result; /*0x102cfb799*/
}

// Address: 0x102cfbc30 | Name: _ossl_ml_dsa_sig_encode
__int64 __fastcall ossl_ml_dsa_sig_encode(_QWORD *a1, __int64 a2, __int64 a3)
{
  __int64 (__fastcall *v5)(); // r13
  unsigned int v6; // ebx
  __int64 v7; // rbx
  unsigned __int64 v8; // r15
  int v9; // r15d
  __int64 v10; // r12
  __int64 v11; // r13
  __int64 v12; // r13
  __int64 v13; // rax
  __int64 v14; // rcx
  __int64 i; // rdx
  _BYTE v17[56]; // [rsp+0h] [rbp-70h] BYREF
  __int64 v18; // [rsp+38h] [rbp-38h]
  __int64 v19[6]; // [rsp+40h] [rbp-30h] BYREF

  if ( a3 != 0 ) /*0x102cfbc44*/
  {
    v5 = poly_encode_signed_two_to_power_17; /*0x102cfbc5e*/
    if ( *(_DWORD *)(a2 + 20) == 0x80000 ) /*0x102cfbc65*/
      v5 = poly_encode_signed_two_to_power_19; /*0x102cfbc65*/
    v6 = 0; /*0x102cfbc6d*/
    if ( (unsigned int)WPACKET_init_static_len(a1: v17, a2: a3, a3: *(_QWORD *)(a2 + 80), a4: 0) == 0 /*0x102cfbc9b*/
      || (unsigned int)WPACKET_memcpy(a1: v17, a2: a1[4]) == 0 )
    {
      goto LABEL_23; /*0x102cfbc9b*/
    }
    v18 = a2; /*0x102cfbca1*/
    if ( a1[1] != 0 ) /*0x102cfbcaa*/
    {
      v7 = 0; /*0x102cfbcac*/
      v8 = 0; /*0x102cfbcb2*/
      while ( ((unsigned int (__fastcall *)(__int64, _BYTE *))v5)(a1: v7 + *a1, a2: v17) != 0 ) /*0x102cfbcce*/
      {
        ++v8; /*0x102cfbcd4*/
        v7 += 1024; /*0x102cfbcd7*/
        if ( v8 >= a1[1] ) /*0x102cfbce2*/
          goto LABEL_10; /*0x102cfbce2*/
      }
    }
    else
    {
LABEL_10:
      v9 = *(_DWORD *)(v18 + 56); /*0x102cfbce4*/
      v10 = a1[2]; /*0x102cfbcec*/
      v11 = a1[3]; /*0x102cfbcf0*/
      if ( (unsigned int)WPACKET_allocate_bytes(a1: v17, a2: (unsigned int)(v9 + v11), a3: v19) != 0 ) /*0x102cfbd0a*/
      {
        __bzero(a1: v19[0], a2: (unsigned int)(v9 + v11)); /*0x102cfbd17*/
        if ( (int)v11 > 0 ) /*0x102cfbd1f*/
        {
          v12 = v11 & 0x7FFFFFFF; /*0x102cfbd21*/
          v13 = 0; /*0x102cfbd28*/
          v14 = 0; /*0x102cfbd2a*/
          do /*0x102cfbd48*/
          {
            for ( i = 0; i != 256; i += 2 ) /*0x102cfbd4a*/
            {
              if ( *(_DWORD *)(v10 + 4 * i) != 0 ) /*0x102cfbd62*/
                *(_BYTE *)(v19[0] + v14++) = i; /*0x102cfbd68*/
              if ( *(_DWORD *)(v10 + 4 * i + 4) != 0 ) /*0x102cfbd74*/
                *(_BYTE *)(v19[0] + v14++) = i + 1; /*0x102cfbd7d*/
            }
            *(_BYTE *)(v19[0] + (unsigned int)(v9 + v13++)) = v14; /*0x102cfbd38*/
            v10 += 1024; /*0x102cfbd3e*/
          }
          while ( v13 != v12 ); /*0x102cfbd48*/
        }
        v6 = 1; /*0x102cfbd8e*/
        goto LABEL_23; /*0x102cfbd8e*/
      }
    }
    v6 = 0; /*0x102cfbd8a*/
LABEL_23:
    WPACKET_finish(a1: v17); /*0x102cfbd93*/
    return v6; /*0x102cfbd97*/
  }
  return 0; /*0x102cfbd9e*/
}

// Address: 0x102cfc010 | Name: _ossl_ml_dsa_sig_decode
_BOOL8 __fastcall ossl_ml_dsa_sig_decode(__int64 a1, char *a2, __int64 a3, __int64 a4)
{
  __int64 (__fastcall *v4)(); // r13
  _BOOL8 result; // rax
  size_t v7; // r14
  bool v8; // cf
  size_t v9; // rdx
  size_t v11; // rbx
  __int64 v12; // r12
  unsigned __int64 v13; // rbx
  size_t v14; // r9
  unsigned __int64 v15; // rbx
  unsigned __int64 v16; // r14
  size_t v17; // rbx
  unsigned __int64 v18; // r15
  char *v19; // r13
  char *v20; // r12
  char *v21; // rcx
  __int64 v22; // r14
  size_t v23; // rbx
  unsigned __int64 v24; // r14
  unsigned __int64 v25; // r8
  unsigned __int64 v26; // rcx
  __int64 v27; // rdx
  int v28; // esi
  char *v30; // [rsp+8h] [rbp-38h] BYREF
  size_t v31; // [rsp+10h] [rbp-30h]

  v4 = poly_decode_signed_two_to_power_17; /*0x102cfc02f*/
  if ( *(_DWORD *)(a4 + 20) == 0x80000 ) /*0x102cfc036*/
    v4 = poly_decode_signed_two_to_power_19; /*0x102cfc036*/
  result = false; /*0x102cfc03a*/
  if ( a3 >= 0 ) /*0x102cfc03f*/
  {
    v7 = *(_QWORD *)(a1 + 40); /*0x102cfc048*/
    v8 = a3 < v7; /*0x102cfc04c*/
    v9 = a3 - v7; /*0x102cfc04c*/
    if ( !v8 ) /*0x102cfc04f*/
    {
      v11 = v9; /*0x102cfc060*/
      memcpy(__dst: *(void **)(a1 + 32), __src: a2, __n: v7); /*0x102cfc066*/
      v30 = &a2[v7]; /*0x102cfc06e*/
      v31 = v11; /*0x102cfc072*/
      if ( *(_QWORD *)(a1 + 8) != 0 ) /*0x102cfc07b*/
      {
        v12 = 0; /*0x102cfc07d*/
        v13 = 0; /*0x102cfc084*/
        while ( ((unsigned int (__fastcall *)(__int64, char **))v4)(a1: v12 + *(_QWORD *)a1, a2: &v30) != 0 ) /*0x102cfc09e*/
        {
          ++v13; /*0x102cfc0a0*/
          v12 += 1024; /*0x102cfc0a3*/
          if ( v13 >= *(_QWORD *)(a1 + 8) ) /*0x102cfc0ae*/
          {
            v11 = v31; /*0x102cfc0b0*/
            goto LABEL_10; /*0x102cfc0b0*/
          }
        }
        return false; /*0x102cfc10b*/
      }
      else
      {
LABEL_10:
        v14 = *(unsigned int *)(a4 + 56); /*0x102cfc0b4*/
        v8 = v11 < v14; /*0x102cfc0bc*/
        v15 = v11 - v14; /*0x102cfc0bc*/
        result = false; /*0x102cfc0bf*/
        if ( !v8 ) /*0x102cfc0c4*/
        {
          v16 = *(_QWORD *)(a1 + 24); /*0x102cfc0c6*/
          v8 = v15 < v16; /*0x102cfc0ca*/
          v17 = v15 - v16; /*0x102cfc0ca*/
          if ( !v8 ) /*0x102cfc0cd*/
          {
            v18 = *(_QWORD *)(a1 + 16); /*0x102cfc0cf*/
            v19 = v30; /*0x102cfc0d3*/
            v20 = &v30[v14]; /*0x102cfc0d7*/
            v21 = &v30[v14 + v16]; /*0x102cfc0db*/
            v22 = v16 << 10; /*0x102cfc0df*/
            v30 = v21; /*0x102cfc0e3*/
            v31 = v17; /*0x102cfc0e7*/
            if ( v18 != 0 ) /*0x102cfc0ee*/
            {
              v23 = v14; /*0x102cfc0f6*/
              __bzero(a1: v18, a2: v22); /*0x102cfc0f9*/
              v14 = v23; /*0x102cfc0fe*/
            }
            v24 = v18 + v22; /*0x102cfc101*/
            result = false; /*0x102cfc104*/
            v25 = 0; /*0x102cfc106*/
            while ( 1 ) /*0x102cfc12e*/
            {
              v26 = (unsigned __int8)*v20; /*0x102cfc12e*/
              if ( v25 > v26 || (unsigned int)v14 < (unsigned int)v26 ) /*0x102cfc13b*/
                break; /*0x102cfc13b*/
              if ( v25 < v26 ) /*0x102cfc140*/
              {
                LODWORD(v27) = -1; /*0x102cfc142*/
                while ( 1 ) /*0x102cfc150*/
                {
                  v28 = v27; /*0x102cfc150*/
                  v27 = (unsigned __int8)v19[v25]; /*0x102cfc152*/
                  if ( v28 >= 0 && v28 >= (int)v27 ) /*0x102cfc160*/
                    return result; /*0x102cfc16b*/
                  ++v25; /*0x102cfc16d*/
                  *(_DWORD *)(v18 + 4 * v27) = 1; /*0x102cfc170*/
                  if ( v26 == v25 ) /*0x102cfc17b*/
                  {
                    v25 = v26; /*0x102cfc11c*/
                    break; /*0x102cfc17d*/
                  }
                }
              }
              ++v20; /*0x102cfc11f*/
              v18 += 1024LL; /*0x102cfc122*/
              if ( v18 >= v24 ) /*0x102cfc12c*/
              {
                if ( v25 >= v14 ) /*0x102cfc182*/
                  return v31 == 0; /*0x102cfc194*/
                while ( v19[v25] == 0 ) /*0x102cfc18a*/
                {
                  if ( v14 == ++v25 ) /*0x102cfc192*/
                    return v31 == 0; /*0x102cfc192*/
                }
                return result; /*0x102cfc18a*/
              }
            }
          }
        }
      }
    }
  }
  return result; /*0x102cfc10d*/
}

// Address: 0x102cfc430 | Name: _ossl_ml_dsa_poly_decode_expand_mask
__int64 __fastcall ossl_ml_dsa_poly_decode_expand_mask(__int64 a1, __int64 a2, __int64 a3, int a4)
{
  _QWORD v5[3]; // [rsp-18h] [rbp-18h] BYREF

  if ( a3 < 0 ) /*0x102cfc433*/
    return 0; /*0x102cfc45c*/
  v5[0] = a2; /*0x102cfc43d*/
  v5[1] = a3; /*0x102cfc441*/
  if ( a4 == 0x80000 ) /*0x102cfc44f*/
    return poly_decode_signed_two_to_power_19(a1, a2: v5); /*0x102cfc451*/
  else
    return poly_decode_signed_two_to_power_17(a1, a2: v5); /*0x102cfc45f*/
}

// Address: 0x102cfc470 | Name: _ossl_ml_dsa_w1_encode
__int64 __fastcall ossl_ml_dsa_w1_encode(_QWORD *a1, int a2, __int64 a3, __int64 a4)
{
  unsigned int v6; // ebx
  __int64 (__fastcall *v7)(); // r12
  __int64 v8; // r13
  unsigned __int64 v9; // rbx
  _BYTE v11[96]; // [rsp+0h] [rbp-60h] BYREF

  v6 = 0; /*0x102cfc487*/
  if ( (unsigned int)WPACKET_init_static_len(a1: v11, a2: a3, a3: a4, a4: 0) != 0 ) /*0x102cfc49c*/
  {
    v7 = poly_encode_6_bits; /*0x102cfc4ac*/
    if ( a2 == 261888 ) /*0x102cfc4b3*/
      v7 = poly_encode_4_bits; /*0x102cfc4b3*/
    v6 = 1; /*0x102cfc4b7*/
    if ( a1[1] != 0 ) /*0x102cfc4c1*/
    {
      v8 = 0; /*0x102cfc4c3*/
      v9 = 0; /*0x102cfc4ca*/
      while ( ((unsigned int (__fastcall *)(__int64, _BYTE *))v7)(a1: v8 + *a1, a2: v11) != 0 ) /*0x102cfc4de*/
      {
        ++v9; /*0x102cfc4e0*/
        v8 += 1024; /*0x102cfc4e3*/
        if ( v9 >= a1[1] ) /*0x102cfc4ee*/
        {
          v6 = 1; /*0x102cfc4f0*/
          goto LABEL_10; /*0x102cfc4f5*/
        }
      }
      v6 = 0; /*0x102cfc4f7*/
    }
LABEL_10:
    WPACKET_finish(a1: v11); /*0x102cfc4f9*/
  }
  return v6; /*0x102cfc504*/
}

// Address: 0x102cfc660 | Name: _ossl_ml_dsa_key_params
__int64 __fastcall ossl_ml_dsa_key_params(__int64 a1)
{
  return *(_QWORD *)(a1 + 8); /*0x102cfc668*/
}

// Address: 0x102cfc670 | Name: _ossl_ml_dsa_key_get_seed
__int64 __fastcall ossl_ml_dsa_key_get_seed(__int64 a1)
{
  return *(_QWORD *)(a1 + 176); /*0x102cfc67b*/
}

// Address: 0x102cfc680 | Name: _ossl_ml_dsa_key_get_prov_flags
__int64 __fastcall ossl_ml_dsa_key_get_prov_flags(__int64 a1)
{
  return *(unsigned int *)(a1 + 184); /*0x102cfc68a*/
}

// Address: 0x102cfc690 | Name: _ossl_ml_dsa_set_prekey
__int64 __fastcall ossl_ml_dsa_set_prekey(__int64 a1, int a2, int a3, void *a4, size_t a5, void *a6, size_t a7)
{
  __int64 result; // rax
  void **v8; // r15
  int v9; // ebx
  int v10; // r12d
  void *v11; // r13
  size_t v12; // r14
  void *v13; // rax
  int v14; // ebx
  int v15; // r12d
  void *v16; // rax
  void *v17; // rdi
  __int64 v18; // [rsp-38h] [rbp-38h]

  result = 0; /*0x102cfc690*/
  if ( a1 != 0 /*0x102cfc6f0*/
    && *(_QWORD *)(a1 + 160) == 0
    && *(_QWORD *)(a1 + 168) == 0
    && (a6 == nullptr || *(_QWORD *)(*(_QWORD *)(a1 + 8) + 64LL) == a7)
    && (a5 == 32 || a4 == nullptr)
    && *(_QWORD *)(a1 + 176) == 0 )
  {
    v8 = (void **)(a1 + 168); /*0x102cfc6f6*/
    v18 = a1; /*0x102cfc700*/
    if ( a6 == nullptr ) /*0x102cfc704*/
      goto LABEL_19; /*0x102cfc704*/
    v9 = a2; /*0x102cfc710*/
    v10 = a3; /*0x102cfc715*/
    v11 = a4; /*0x102cfc71b*/
    v12 = a5; /*0x102cfc723*/
    v13 = CRYPTO_memdup(__src: a6, __n: a7, file: "crypto/ml_dsa/ml_dsa_key.c", line: 52); /*0x102cfc726*/
    a4 = v11; /*0x102cfc72b*/
    a5 = v12; /*0x102cfc72e*/
    a2 = v9; /*0x102cfc731*/
    a3 = v10; /*0x102cfc733*/
    a1 = v18; /*0x102cfc736*/
    *v8 = v13; /*0x102cfc73a*/
    if ( v13 == nullptr ) /*0x102cfc740*/
    {
      v17 = nullptr; /*0x102cfc792*/
    }
    else
    {
LABEL_19:
      if ( a4 == nullptr /*0x102cfc779*/
        || (v14 = a2,
            v15 = a3,
            v16 = CRYPTO_memdup(__src: a4, __n: a5, file: "crypto/ml_dsa/ml_dsa_key.c", line: 55),
            a2 = v14,
            a3 = v15,
            a1 = v18,
            *(_QWORD *)(v18 + 176) = v16,
            v16 != nullptr) )
      {
        *(_DWORD *)(a1 + 184) = (*(_DWORD *)(a1 + 184) | a2) & ~a3; /*0x102cfc785*/
        return 1; /*0x102cfc790*/
      }
      v17 = *v8; /*0x102cfc796*/
    }
    CRYPTO_free(a1: v17); /*0x102cfc7a8*/
    CRYPTO_free(a1: *(void **)(v18 + 176)); /*0x102cfc7c0*/
    *(_OWORD *)v8 = 0; /*0x102cfc7c8*/
    return 0; /*0x102cfc7cc*/
  }
  return result; /*0x102cfc6a1*/
}

// Address: 0x102cfc7e0 | Name: _ossl_ml_dsa_key_new
_QWORD *__fastcall ossl_ml_dsa_key_new(__int64 a1, int a2, unsigned int a3)
{
  __int64 v5; // rax
  __int64 v6; // r15
  _QWORD *v7; // rax
  _QWORD *v8; // r12
  __int64 v9; // r15
  __int64 v10; // rbx
  _QWORD *result; // rax

  v5 = ossl_ml_dsa_params_get(a1: a3); /*0x102cfc7f3*/
  if ( v5 != 0 ) /*0x102cfc7fb*/
  {
    v6 = v5; /*0x102cfc801*/
    v7 = CRYPTO_zalloc(__size: 0x100u, __s: "crypto/ml_dsa/ml_dsa_key.c", line: 87); /*0x102cfc815*/
    if ( v7 != nullptr ) /*0x102cfc81d*/
    {
      *v7 = a1; /*0x102cfc823*/
      v7[1] = v6; /*0x102cfc826*/
      *((_DWORD *)v7 + 46) = 3; /*0x102cfc82a*/
      v8 = v7; /*0x102cfc841*/
      v9 = EVP_MD_fetch(a1, a2: (int)"SHAKE-128", a3: a2); /*0x102cfc849*/
      v8[2] = v9; /*0x102cfc84c*/
      v10 = EVP_MD_fetch(a1, a2: (int)"SHAKE-256", a3: a2); /*0x102cfc863*/
      result = v8; /*0x102cfc866*/
      v8[3] = v10; /*0x102cfc869*/
      if ( v9 != 0 && v10 != 0 ) /*0x102cfc877*/
        return result; /*0x102cfc87f*/
      EVP_MD_free(a1: v9); /*0x102cfc887*/
      EVP_MD_free(a1: v10); /*0x102cfc88f*/
      ossl_ml_dsa_key_reset(a1: v8); /*0x102cfc897*/
      CRYPTO_free(a1: v8); /*0x102cfc8ab*/
    }
  }
  return nullptr; /*0x102cfc8b2*/
}

// Address: 0x102cfc8c0 | Name: _ossl_ml_dsa_key_free
void __fastcall ossl_ml_dsa_key_free(_QWORD *a1)
{
  if ( a1 != nullptr ) /*0x102cfc8c3*/
  {
    EVP_MD_free(a1: a1[2]); /*0x102cfc8d5*/
    EVP_MD_free(a1: a1[3]); /*0x102cfc8de*/
    ossl_ml_dsa_key_reset(a1); /*0x102cfc8e6*/
    CRYPTO_free(a1); /*0x102cfc900*/
  }
}

// Address: 0x102cfc910 | Name: _ossl_ml_dsa_key_pub_alloc
__int64 __fastcall ossl_ml_dsa_key_pub_alloc(_QWORD *a1)
{
  unsigned int v1; // ebx
  __int64 v3; // r15
  void *v4; // rax

  v1 = 0; /*0x102cfc91a*/
  if ( a1[24] == 0 ) /*0x102cfc924*/
  {
    v3 = *(_QWORD *)(a1[1] + 32LL); /*0x102cfc92d*/
    v4 = CRYPTO_malloc(num: (_DWORD)v3 << 10, file: "crypto/ml_dsa/ml_dsa_vector.h", line: 36); /*0x102cfc944*/
    a1[24] = v4; /*0x102cfc949*/
    if ( v4 != nullptr ) /*0x102cfc953*/
    {
      a1[25] = v3; /*0x102cfc955*/
      return 1; /*0x102cfc95c*/
    }
  }
  return v1; /*0x102cfc967*/
}

// Address: 0x102cfc970 | Name: _ossl_ml_dsa_key_priv_alloc
__int64 __fastcall ossl_ml_dsa_key_priv_alloc(_QWORD *a1)
{
  unsigned int v1; // r14d
  __int64 v3; // rax
  __int64 v4; // r15
  __int64 v5; // r12
  char *v6; // rax
  char *v7; // rax

  v1 = 0; /*0x102cfc97e*/
  if ( a1[30] == 0 ) /*0x102cfc989*/
  {
    v3 = a1[1]; /*0x102cfc98e*/
    v4 = *(_QWORD *)(v3 + 32); /*0x102cfc992*/
    v5 = *(_QWORD *)(v3 + 40); /*0x102cfc996*/
    v6 = (char *)CRYPTO_malloc( /*0x102cfc9b7*/
                   num: ((_DWORD)v5 << 10) + (*(_DWORD *)(v3 + 32) << 11),
                   file: "crypto/ml_dsa/ml_dsa_vector.h",
                   line: 36);
    a1[30] = v6; /*0x102cfc9bc*/
    if ( v6 != nullptr ) /*0x102cfc9c6*/
    {
      a1[31] = v5; /*0x102cfc9c8*/
      v7 = &v6[1024 * v5]; /*0x102cfc9cf*/
      a1[28] = v7; /*0x102cfc9d2*/
      a1[29] = v4; /*0x102cfc9d9*/
      a1[26] = &v7[1024 * v4]; /*0x102cfc9ea*/
      a1[27] = v4; /*0x102cfc9f1*/
      return 1; /*0x102cfc9f8*/
    }
  }
  return v1; /*0x102cfca05*/
}

// Address: 0x102cfca10 | Name: _ossl_ml_dsa_key_reset
void __fastcall ossl_ml_dsa_key_reset(__int64 a1)
{
  __int64 v2; // rdi
  __int64 v3; // rdi
  __int64 v4; // rdi
  void *v5; // rdi
  void *v6; // rdi

  v2 = *(_QWORD *)(a1 + 240); /*0x102cfca1a*/
  if ( v2 != 0 ) /*0x102cfca24*/
  {
    __bzero(a1: v2, a2: *(_QWORD *)(a1 + 248) << 10); /*0x102cfca35*/
    v3 = *(_QWORD *)(a1 + 224); /*0x102cfca3a*/
    if ( v3 != 0 ) /*0x102cfca44*/
      __bzero(a1: v3, a2: *(_QWORD *)(a1 + 232) << 10); /*0x102cfca51*/
    v4 = *(_QWORD *)(a1 + 208); /*0x102cfca5d*/
    if ( v4 != 0 ) /*0x102cfca67*/
      __bzero(a1: v4, a2: *(_QWORD *)(a1 + 216) << 10); /*0x102cfca74*/
    CRYPTO_free(a1: *(void **)(a1 + 240)); /*0x102cfca8c*/
    *(_OWORD *)(a1 + 240) = 0; /*0x102cfca94*/
    *(_QWORD *)(a1 + 224) = 0; /*0x102cfca98*/
    *(_QWORD *)(a1 + 208) = 0; /*0x102cfcaa3*/
  }
  CRYPTO_free(a1: *(void **)(a1 + 192)); /*0x102cfcac1*/
  *(_OWORD *)(a1 + 192) = 0; /*0x102cfcac9*/
  OPENSSL_cleanse(ptr: (void *)(a1 + 128), len: 0x20u); /*0x102cfcadc*/
  CRYPTO_free(a1: *(void **)(a1 + 160)); /*0x102cfcaf4*/
  *(_QWORD *)(a1 + 160) = 0; /*0x102cfcaf9*/
  v5 = *(void **)(a1 + 168); /*0x102cfcb04*/
  if ( v5 != nullptr ) /*0x102cfcb0e*/
    CRYPTO_clear_free(a1: v5, a2: *(_QWORD *)(*(_QWORD *)(a1 + 8) + 64LL)); /*0x102cfcb24*/
  *(_QWORD *)(a1 + 168) = 0; /*0x102cfcb29*/
  v6 = *(void **)(a1 + 176); /*0x102cfcb34*/
  if ( v6 != nullptr ) /*0x102cfcb3e*/
    CRYPTO_clear_free(a1: v6, a2: 0x20u); /*0x102cfcb51*/
  *(_QWORD *)(a1 + 176) = 0; /*0x102cfcb56*/
}

// Address: 0x102cfcb70 | Name: _ossl_ml_dsa_key_dup
_OWORD *__fastcall ossl_ml_dsa_key_dup(__int64 a1, char a2)
{
  _QWORD *v4; // rax
  __int64 v5; // rcx
  _OWORD *v6; // r12
  void *v7; // rdi
  __int128 v8; // xmm0
  __int128 v9; // xmm0
  __int128 v10; // xmm1
  __int128 v11; // xmm2
  __int64 v12; // r15
  void *v13; // rdi
  void *v14; // rcx
  void *v16; // rdi
  __int128 v17; // xmm0
  __int64 v18; // rax
  __int64 v19; // r13
  __int64 v20; // r15
  char *v21; // rdi
  char *v22; // r14
  void *v23; // rcx
  void *v24; // rdi
  void *v25; // rcx
  __int64 *v26; // rbx

  if ( a1 == 0 ) /*0x102cfcb73*/
    return nullptr; /*0x102cfcced*/
  if ( *(_QWORD *)(a1 + 160) != 0 || *(_QWORD *)(a1 + 168) == 0 && *(_QWORD *)(a1 + 176) == 0 ) /*0x102cfcd04*/
  {
    v4 = CRYPTO_zalloc(__size: 0x100u, __s: "crypto/ml_dsa/ml_dsa_key.c", line: 191); /*0x102cfcbac*/
    if ( v4 != nullptr ) /*0x102cfcbb4*/
    {
      *v4 = *(_QWORD *)a1; /*0x102cfcbbd*/
      v5 = *(_QWORD *)(a1 + 8); /*0x102cfcbc0*/
      v4[1] = v5; /*0x102cfcbc4*/
      *((_DWORD *)v4 + 46) = *(_DWORD *)(a1 + 184); /*0x102cfcbce*/
      v6 = v4; /*0x102cfcbd8*/
      if ( (a2 & 3) == 0 ) /*0x102cfcbdb*/
      {
LABEL_12:
        EVP_MD_up_ref(a1: *(_QWORD *)(a1 + 16)); /*0x102cfccc7*/
        EVP_MD_up_ref(a1: *(_QWORD *)(a1 + 24)); /*0x102cfccd4*/
        v6[1] = *(_OWORD *)(a1 + 16); /*0x102cfcce0*/
        return v6; /*0x102cfcce6*/
      }
      v7 = *(void **)(a1 + 160); /*0x102cfcbe1*/
      if ( v7 == nullptr ) /*0x102cfcbeb*/
        goto LABEL_11; /*0x102cfcbeb*/
      v8 = *(_OWORD *)(a1 + 32); /*0x102cfcbf1*/
      *((_OWORD *)v4 + 3) = *(_OWORD *)(a1 + 48); /*0x102cfcbf9*/
      *((_OWORD *)v4 + 2) = v8; /*0x102cfcbfd*/
      v9 = *(_OWORD *)(a1 + 64); /*0x102cfcc01*/
      v10 = *(_OWORD *)(a1 + 80); /*0x102cfcc05*/
      v11 = *(_OWORD *)(a1 + 96); /*0x102cfcc09*/
      *((_OWORD *)v4 + 7) = *(_OWORD *)(a1 + 112); /*0x102cfcc11*/
      *((_OWORD *)v4 + 6) = v11; /*0x102cfcc15*/
      *((_OWORD *)v4 + 5) = v10; /*0x102cfcc19*/
      *((_OWORD *)v4 + 4) = v9; /*0x102cfcc1d*/
      if ( *(_QWORD *)(a1 + 192) != 0 ) /*0x102cfcc29*/
      {
        if ( v4[24] != 0 ) /*0x102cfcc33*/
          goto LABEL_25; /*0x102cfcc33*/
        v12 = *(_QWORD *)(v5 + 32); /*0x102cfcc39*/
        v13 = CRYPTO_malloc(num: (_DWORD)v12 << 10, file: "crypto/ml_dsa/ml_dsa_vector.h", line: 36); /*0x102cfcc55*/
        v4 = v6; /*0x102cfcc58*/
        *((_QWORD *)v6 + 24) = v13; /*0x102cfcc5b*/
        if ( v13 == nullptr ) /*0x102cfcc66*/
          goto LABEL_25; /*0x102cfcc66*/
        *((_QWORD *)v6 + 25) = v12; /*0x102cfcc6c*/
        memcpy(__dst: v13, __src: *(const void **)(a1 + 192), __n: *(_QWORD *)(a1 + 200) << 10); /*0x102cfcc85*/
        v5 = *(_QWORD *)(a1 + 8); /*0x102cfcc8a*/
        v7 = *(void **)(a1 + 160); /*0x102cfcc8e*/
      }
      v14 = CRYPTO_memdup(__src: v7, __n: *(_QWORD *)(v5 + 72), file: "crypto/ml_dsa/ml_dsa_key.c", line: 207); /*0x102cfccaa*/
      v4 = v6; /*0x102cfccad*/
      *((_QWORD *)v6 + 20) = v14; /*0x102cfccb0*/
      if ( v14 != nullptr ) /*0x102cfccbb*/
      {
LABEL_11:
        if ( (a2 & 1) == 0 ) /*0x102cfccc5*/
          goto LABEL_12; /*0x102cfccc5*/
        v16 = *(void **)(a1 + 168); /*0x102cfcd0f*/
        if ( v16 == nullptr ) /*0x102cfcd19*/
          goto LABEL_23; /*0x102cfcd19*/
        v17 = *(_OWORD *)(a1 + 128); /*0x102cfcd1f*/
        *((_OWORD *)v4 + 9) = *(_OWORD *)(a1 + 144); /*0x102cfcd2d*/
        *((_OWORD *)v4 + 8) = v17; /*0x102cfcd34*/
        if ( *(_QWORD *)(a1 + 240) != 0 ) /*0x102cfcd43*/
        {
          if ( v4[30] != 0 ) /*0x102cfcd51*/
            goto LABEL_25; /*0x102cfcd51*/
          v18 = v4[1]; /*0x102cfcd57*/
          v19 = *(_QWORD *)(v18 + 32); /*0x102cfcd5b*/
          v20 = *(_QWORD *)(v18 + 40); /*0x102cfcd5f*/
          v21 = (char *)CRYPTO_malloc( /*0x102cfcd85*/
                          num: ((_DWORD)v20 << 10) + (*(_DWORD *)(v18 + 32) << 11),
                          file: "crypto/ml_dsa/ml_dsa_vector.h",
                          line: 36);
          v4 = v6; /*0x102cfcd88*/
          *((_QWORD *)v6 + 30) = v21; /*0x102cfcd8b*/
          if ( v21 == nullptr ) /*0x102cfcd96*/
            goto LABEL_25; /*0x102cfcd96*/
          *((_QWORD *)v6 + 31) = v20; /*0x102cfcd9c*/
          v22 = &v21[1024 * v20]; /*0x102cfcda3*/
          *((_QWORD *)v6 + 28) = v22; /*0x102cfcda6*/
          *((_QWORD *)v6 + 29) = v19; /*0x102cfcdad*/
          *((_QWORD *)v6 + 26) = &v22[1024 * v19]; /*0x102cfcdbe*/
          *((_QWORD *)v6 + 27) = v19; /*0x102cfcdc5*/
          memcpy(__dst: v21, __src: *(const void **)(a1 + 240), __n: *(_QWORD *)(a1 + 248) << 10); /*0x102cfcdde*/
          memcpy(__dst: v22, __src: *(const void **)(a1 + 224), __n: *(_QWORD *)(a1 + 232) << 10); /*0x102cfcdf8*/
          memcpy(__dst: &v22[1024 * v19], __src: *(const void **)(a1 + 208), __n: *(_QWORD *)(a1 + 216) << 10); /*0x102cfce12*/
          v16 = *(void **)(a1 + 168); /*0x102cfce17*/
        }
        v23 = CRYPTO_memdup( /*0x102cfce37*/
                __src: v16,
                __n: *(_QWORD *)(*(_QWORD *)(a1 + 8) + 64LL),
                file: "crypto/ml_dsa/ml_dsa_key.c",
                line: 222);
        v4 = v6; /*0x102cfce3a*/
        *((_QWORD *)v6 + 21) = v23; /*0x102cfce3d*/
        if ( v23 != nullptr ) /*0x102cfce48*/
        {
LABEL_23:
          v24 = *(void **)(a1 + 176); /*0x102cfce4a*/
          if ( v24 == nullptr ) /*0x102cfce54*/
            goto LABEL_12; /*0x102cfce54*/
          v25 = CRYPTO_memdup(__src: v24, __n: 0x20u, file: "crypto/ml_dsa/ml_dsa_key.c", line: 227); /*0x102cfce70*/
          v4 = v6; /*0x102cfce73*/
          *((_QWORD *)v6 + 22) = v25; /*0x102cfce76*/
          if ( v25 != nullptr ) /*0x102cfce81*/
            goto LABEL_12; /*0x102cfce81*/
        }
      }
LABEL_25:
      v26 = v4; /*0x102cfce87*/
      EVP_MD_free(a1: v4[2]); /*0x102cfce8e*/
      EVP_MD_free(a1: v26[3]); /*0x102cfce97*/
      ossl_ml_dsa_key_reset(a1: (__int64)v26); /*0x102cfce9f*/
      CRYPTO_free(a1: v26); /*0x102cfceb3*/
    }
  }
  return nullptr; /*0x102cfcced*/
}

// Address: 0x102cfced0 | Name: _ossl_ml_dsa_key_equal
__int64 __fastcall ossl_ml_dsa_key_equal(_QWORD *a1, _QWORD *a2, char a3)
{
  __int64 v3; // r8
  __int64 result; // rax
  size_t v5; // rdx
  const void *v6; // rdi
  const void *v7; // rsi
  int v8; // ecx

  v3 = a1[1]; /*0x102cfced0*/
  result = 0; /*0x102cfced4*/
  if ( v3 == a2[1] ) /*0x102cfceda*/
  {
    if ( (a3 & 3) == 0 ) /*0x102cfcee0*/
      return 1; /*0x102cfcf46*/
    if ( (a3 & 2) != 0 && a1[20] != 0 && a2[20] != 0 ) /*0x102cfcf01*/
    {
      v5 = *(_QWORD *)(v3 + 72); /*0x102cfcf03*/
      v6 = (const void *)a1[20]; /*0x102cfcf07*/
      v7 = (const void *)a2[20]; /*0x102cfcf0a*/
      goto LABEL_11; /*0x102cfcf0d*/
    }
    result = 0; /*0x102cfcf0f*/
    if ( (a3 & 1) != 0 ) /*0x102cfcf14*/
    {
      v6 = (const void *)a1[21]; /*0x102cfcf16*/
      if ( v6 != nullptr ) /*0x102cfcf20*/
      {
        v7 = (const void *)a2[21]; /*0x102cfcf22*/
        if ( v7 != nullptr ) /*0x102cfcf2c*/
        {
          v5 = *(_QWORD *)(v3 + 64); /*0x102cfcf2e*/
LABEL_11:
          v8 = memcmp(__s1: v6, __s2: v7, __n: v5); /*0x102cfcf32*/
          result = 0; /*0x102cfcf39*/
          if ( v8 == 0 ) /*0x102cfcf3d*/
            return 1; /*0x102cfcf47*/
        }
      }
    }
  }
  return result; /*0x102cfcedc*/
}

// Address: 0x102cfcf50 | Name: _ossl_ml_dsa_key_has
__int64 __fastcall ossl_ml_dsa_key_has(__int64 a1, char a2)
{
  __int64 result; // rax

  result = 0; /*0x102cfcf54*/
  if ( (a2 & 3) != 0 && *(_QWORD *)(a1 + 160) != 0 && ((a2 & 1) == 0 || *(_QWORD *)(a1 + 168) != 0) ) /*0x102cfcf74*/
    return 1; /*0x102cfcf76*/
  return result; /*0x102cfcf7b*/
}

// Address: 0x102cfcf80 | Name: _ossl_ml_dsa_key_get_pub
__int64 __fastcall ossl_ml_dsa_key_get_pub(__int64 a1)
{
  return *(_QWORD *)(a1 + 160); /*0x102cfcf8b*/
}

// Address: 0x102cfcf90 | Name: _ossl_ml_dsa_key_get_priv
__int64 __fastcall ossl_ml_dsa_key_get_priv(__int64 a1)
{
  return *(_QWORD *)(a1 + 168); /*0x102cfcf9b*/
}

// Address: 0x102cfcfa0 | Name: _ossl_ml_dsa_key_public_from_private
_BOOL8 __fastcall ossl_ml_dsa_key_public_from_private(_QWORD *a1)
{
  __int64 v2; // r13
  char *v3; // rax
  char *v4; // rbx
  EVP_MD_CTX *v5; // rax
  EVP_MD_CTX *v6; // r14
  _BOOL4 v7; // r15d
  __int64 v9; // r14
  void *v10; // rax
  __int64 v11; // r14
  int v12; // eax
  const void *v13; // r13
  _QWORD v14[2]; // [rsp+8h] [rbp-48h] BYREF
  size_t cnt; // [rsp+18h] [rbp-38h]
  EVP_MD_CTX *ctx; // [rsp+20h] [rbp-30h]

  v2 = *(_QWORD *)(a1[1] + 32LL); /*0x102cfcfb8*/
  v3 = (char *)CRYPTO_malloc(num: (_DWORD)v2 << 10, file: "crypto/ml_dsa/ml_dsa_vector.h", line: 36); /*0x102cfcfcf*/
  v14[0] = v3; /*0x102cfcfd4*/
  if ( v3 != nullptr ) /*0x102cfcfdb*/
  {
    v4 = v3; /*0x102cfcfdd*/
    v14[1] = v2; /*0x102cfcfe0*/
    v5 = (EVP_MD_CTX *)EVP_MD_CTX_new(); /*0x102cfcfe4*/
    v6 = v5; /*0x102cfcfe9*/
    v7 = false; /*0x102cfcfec*/
    if ( v5 != nullptr && a1[24] == 0 ) /*0x102cfcffd*/
    {
      ctx = v5; /*0x102cfd032*/
      v9 = *(_QWORD *)(a1[1] + 32LL); /*0x102cfd03b*/
      v10 = CRYPTO_malloc(num: (_DWORD)v9 << 10, file: "crypto/ml_dsa/ml_dsa_vector.h", line: 36); /*0x102cfd052*/
      a1[24] = v10; /*0x102cfd057*/
      if ( v10 != nullptr ) /*0x102cfd062*/
      {
        a1[25] = v9; /*0x102cfd070*/
        v6 = ctx; /*0x102cfd07f*/
        if ( (unsigned int)public_from_private(a1, a2: ctx, a3: a1 + 24, a4: v14) != 0 && v2 == a1[27] ) /*0x102cfd09b*/
        {
          if ( v2 != 0 ) /*0x102cfd0a4*/
          {
            v11 = 0; /*0x102cfd0a6*/
            while ( (unsigned int)CRYPTO_memcmp(a1: &v4[v11], a2: (_OWORD *)(v11 + a1[26]), a3: 1024) == 0 ) /*0x102cfd0cb*/
            {
              v11 += 1024; /*0x102cfd0d1*/
              if ( --v2 == 0 ) /*0x102cfd0db*/
                goto LABEL_14; /*0x102cfd0db*/
            }
            v7 = false; /*0x102cfd165*/
            v6 = ctx; /*0x102cfd168*/
          }
          else
          {
LABEL_14:
            v12 = ossl_ml_dsa_pk_encode((__int64)a1); /*0x102cfd0dd*/
            v6 = ctx; /*0x102cfd0e7*/
            if ( v12 != 0 ) /*0x102cfd0eb*/
            {
              v13 = (const void *)a1[20]; /*0x102cfd0fb*/
              cnt = *(_QWORD *)(a1[1] + 72LL); /*0x102cfd107*/
              v7 = false; /*0x102cfd10b*/
              if ( (unsigned int)EVP_DigestInit_ex2(a1: ctx) == 1 && EVP_DigestUpdate(ctx: v6, d: v13, cnt) == 1 ) /*0x102cfd133*/
                v7 = EVP_DigestSqueeze(a1: (__int64)v6, a2: (__int64)(a1 + 8), a3: 64) == 1; /*0x102cfd153*/
            }
          }
        }
      }
      else
      {
        v6 = ctx; /*0x102cfd15c*/
      }
    }
    CRYPTO_free(a1: v4); /*0x102cfd00e*/
    EVP_MD_CTX_free(ctx: v6); /*0x102cfd016*/
  }
  else
  {
    return false; /*0x102cfd01d*/
  }
  return v7; /*0x102cfd023*/
}

// Address: 0x102cfd400 | Name: _ossl_ml_dsa_key_pairwise_check
_BOOL8 __fastcall ossl_ml_dsa_key_pairwise_check(_QWORD *a1)
{
  _BOOL4 v1; // r15d
  __int64 v3; // r12
  char *v4; // rax
  char *v5; // rbx
  EVP_MD_CTX *v6; // rax
  unsigned __int64 v7; // r13
  __int64 v8; // r12
  __int64 v9; // r12
  _QWORD v11[2]; // [rsp+0h] [rbp-60h] BYREF
  _QWORD v12[2]; // [rsp+10h] [rbp-50h] BYREF
  char *v13; // [rsp+20h] [rbp-40h]
  __int64 v14; // [rsp+28h] [rbp-38h]
  EVP_MD_CTX *v15; // [rsp+30h] [rbp-30h]

  v1 = false; /*0x102cfd411*/
  if ( a1[20] != 0 && a1[21] != 0 ) /*0x102cfd42d*/
  {
    v3 = *(_QWORD *)(a1[1] + 32LL); /*0x102cfd437*/
    v4 = (char *)CRYPTO_malloc(num: (_DWORD)v3 << 11, file: "crypto/ml_dsa/ml_dsa_key.c", line: 383); /*0x102cfd454*/
    if ( v4 != nullptr ) /*0x102cfd45c*/
    {
      v5 = v4; /*0x102cfd462*/
      v6 = (EVP_MD_CTX *)EVP_MD_CTX_new(); /*0x102cfd465*/
      v1 = false; /*0x102cfd46a*/
      if ( v6 != nullptr ) /*0x102cfd470*/
      {
        v3 = (unsigned int)v3; /*0x102cfd476*/
        v11[0] = v5; /*0x102cfd479*/
        v11[1] = v3; /*0x102cfd47d*/
        v7 = (unsigned __int64)(unsigned int)v3 << 10; /*0x102cfd484*/
        v13 = &v5[v7]; /*0x102cfd48c*/
        v12[0] = &v5[v7]; /*0x102cfd490*/
        v12[1] = (unsigned int)v3; /*0x102cfd494*/
        v15 = v6; /*0x102cfd4a3*/
        if ( (unsigned int)public_from_private(a1, a2: v6, a3: v11, a4: v12) == 0 ) /*0x102cfd4b1*/
        {
LABEL_18:
          v6 = v15; /*0x102cfd568*/
          goto LABEL_19; /*0x102cfd568*/
        }
        v6 = v15; /*0x102cfd4be*/
        if ( (unsigned int)v3 == a1[25] ) /*0x102cfd4c2*/
        {
          if ( (_DWORD)v3 != 0 ) /*0x102cfd4cb*/
          {
            v14 = (unsigned int)v3; /*0x102cfd4d1*/
            v1 = false; /*0x102cfd4d5*/
            v8 = 0; /*0x102cfd4d8*/
            while ( (unsigned int)CRYPTO_memcmp(a1: &v5[v8], a2: (_OWORD *)(v8 + a1[24]), a3: 1024) == 0 ) /*0x102cfd4fa*/
            {
              v8 += 1024; /*0x102cfd4fc*/
              if ( v7 == v8 ) /*0x102cfd506*/
              {
                v6 = v15; /*0x102cfd513*/
                if ( v14 != a1[27] ) /*0x102cfd517*/
                  goto LABEL_19; /*0x102cfd517*/
                v9 = 0; /*0x102cfd519*/
                while ( (unsigned int)CRYPTO_memcmp(a1: &v13[v9], a2: (_OWORD *)(v9 + a1[26]), a3: 1024) == 0 ) /*0x102cfd53a*/
                {
                  v9 += 1024; /*0x102cfd53c*/
                  v1 = true; /*0x102cfd543*/
                  v6 = v15; /*0x102cfd54c*/
                  if ( v7 == v9 ) /*0x102cfd550*/
                    goto LABEL_19; /*0x102cfd550*/
                }
                v1 = false; /*0x102cfd565*/
                goto LABEL_18; /*0x102cfd565*/
              }
            }
            goto LABEL_18; /*0x102cfd4fa*/
          }
          v1 = a1[27] == 0; /*0x102cfd55f*/
        }
      }
LABEL_19:
      EVP_MD_CTX_free(ctx: v6); /*0x102cfd56c*/
      CRYPTO_free(a1: v5); /*0x102cfd583*/
    }
  }
  return v1; /*0x102cfd58b*/
}

// Address: 0x102cfd5a0 | Name: _ossl_ml_dsa_generate_key
__int64 __fastcall ossl_ml_dsa_generate_key(__int64 a1)
{
  void *v2; // r14
  __int64 result; // rax
  const char *v4; // rcx
  unsigned int v5; // ebx
  void *v6; // rax

  if ( *(_QWORD *)(a1 + 176) != 0 ) /*0x102cfd5b2*/
    goto LABEL_2; /*0x102cfd5b2*/
  v6 = CRYPTO_malloc(num: 32, file: "crypto/ml_dsa/ml_dsa_key.c", line: 464); /*0x102cfd65b*/
  *(_QWORD *)(a1 + 176) = v6; /*0x102cfd660*/
  if ( v6 == nullptr ) /*0x102cfd66a*/
    return 0; /*0x102cfd6ba*/
  if ( (int)RAND_priv_bytes_ex(a1: *(_QWORD *)a1, a2: v6, a3: 32, a4: 0) > 0 ) /*0x102cfd680*/
  {
LABEL_2:
    v2 = *(void **)(a1 + 168); /*0x102cfd5b8*/
    *(_QWORD *)(a1 + 168) = 0; /*0x102cfd5bf*/
    result = keygen_internal(a1); /*0x102cfd5cd*/
    if ( v2 != nullptr ) /*0x102cfd5d5*/
    {
      if ( (_DWORD)result != 0 ) /*0x102cfd5dd*/
      {
        if ( memcmp(__s1: *(const void **)(a1 + 168), __s2: v2, __n: *(_QWORD *)(*(_QWORD *)(a1 + 8) + 64LL)) == 0 ) /*0x102cfd5fc*/
        {
          v5 = 1; /*0x102cfd6bb*/
        }
        else
        {
          ossl_ml_dsa_key_reset(a1); /*0x102cfd605*/
          ERR_new(); /*0x102cfd60a*/
          ERR_set_debug(__s: "crypto/ml_dsa/ml_dsa_key.c", a2: 482, a3: "ossl_ml_dsa_generate_key"); /*0x102cfd622*/
          v4 = **(const char ***)(a1 + 8); /*0x102cfd62b*/
          v5 = 0; /*0x102cfd635*/
          ERR_set_error(a1: 57, a2: 158, a3: (__int64)"explicit %s private key does not match seed", v4); /*0x102cfd643*/
        }
      }
      else
      {
        v5 = 0; /*0x102cfd6b0*/
      }
      CRYPTO_free(a1: v2); /*0x102cfd6cf*/
      return v5; /*0x102cfd6d4*/
    }
  }
  else
  {
    CRYPTO_free(a1: *(void **)(a1 + 176)); /*0x102cfd699*/
    *(_QWORD *)(a1 + 176) = 0; /*0x102cfd69e*/
    return 0; /*0x102cfd6a9*/
  }
  return result; /*0x102cfd6ab*/
}

// Address: 0x102cfda20 | Name: _ossl_ml_dsa_key_matches
_BOOL8 __fastcall ossl_ml_dsa_key_matches(__int64 a1, int a2)
{
  return *(_DWORD *)(*(_QWORD *)(a1 + 8) + 8LL) == a2; /*0x102cfda30*/
}

// Address: 0x102cfda40 | Name: _ossl_ml_dsa_key_get_pub_len
__int64 __fastcall ossl_ml_dsa_key_get_pub_len(__int64 a1)
{
  return *(_QWORD *)(*(_QWORD *)(a1 + 8) + 72LL); /*0x102cfda4c*/
}

// Address: 0x102cfda50 | Name: _ossl_ml_dsa_key_get_collision_strength_bits
__int64 __fastcall ossl_ml_dsa_key_get_collision_strength_bits(__int64 a1)
{
  return *(int *)(*(_QWORD *)(a1 + 8) + 16LL); /*0x102cfda5c*/
}

// Address: 0x102cfda60 | Name: _ossl_ml_dsa_key_get_priv_len
__int64 __fastcall ossl_ml_dsa_key_get_priv_len(__int64 a1)
{
  return *(_QWORD *)(*(_QWORD *)(a1 + 8) + 64LL); /*0x102cfda6c*/
}

// Address: 0x102cfda70 | Name: _ossl_ml_dsa_key_get_sig_len
__int64 __fastcall ossl_ml_dsa_key_get_sig_len(__int64 a1)
{
  return *(_QWORD *)(*(_QWORD *)(a1 + 8) + 80LL); /*0x102cfda7c*/
}

// Address: 0x102cfda80 | Name: _ossl_ml_dsa_key_get0_libctx
__int64 __fastcall ossl_ml_dsa_key_get0_libctx(__int64 a1)
{
  if ( a1 != 0 ) /*0x102cfda87*/
    return *(_QWORD *)a1; /*0x102cfda89*/
  else
    return 0; /*0x102cfda8e*/
}

// Address: 0x102cfdaa0 | Name: _ossl_ml_dsa_key_get_name
__int64 __fastcall ossl_ml_dsa_key_get_name(__int64 a1)
{
  return **(_QWORD **)(a1 + 8); /*0x102cfdaab*/
}

// Address: 0x102cfdab0 | Name: _ossl_ml_dsa_key_compress_power2_round
__int64 __fastcall ossl_ml_dsa_key_compress_power2_round(unsigned int a1, _DWORD *a2, unsigned int *a3)
{
  unsigned int v3; // eax
  int v4; // edi
  int v5; // r8d
  __int64 result; // rax

  *a2 = a1 >> 13; /*0x102cfdab9*/
  v3 = a1 & 0x1FFF; /*0x102cfdabd*/
  *a3 = v3; /*0x102cfdac2*/
  v4 = *a2 + 1; /*0x102cfdae6*/
  v5 = (v3 < 0x1001) - 1; /*0x102cfdaf0*/
  result = v5 & (v3 + 8372225) | ~v5 & v3; /*0x102cfdafa*/
  *a3 = result; /*0x102cfdafd*/
  *a2 = v4 & v5 | *a2 & ~v5; /*0x102cfdb07*/
  return result; /*0x102cfdb09*/
}

// Address: 0x102cfdb10 | Name: _ossl_ml_dsa_key_compress_high_bits
__int64 __fastcall ossl_ml_dsa_key_compress_high_bits(int a1, int a2)
{
  unsigned int v2; // edi
  unsigned int v3; // eax
  __int64 result; // rax
  unsigned int v5; // ecx

  v2 = a1 + 127; /*0x102cfdb14*/
  v3 = v2 >> 7; /*0x102cfdb19*/
  if ( a2 == 261888 ) /*0x102cfdb22*/
    return ((1025 * v3 + 0x200000) >> 22) & 0xF; /*0x102cfdb33*/
  v5 = (11275 * v3 + 0x800000) >> 24; /*0x102cfdb44*/
  result = 0; /*0x102cfdb47*/
  if ( v2 < 0x7E6C80 ) /*0x102cfdb4f*/
    return v5; /*0x102cfdb4f*/
  return result; /*0x102cfdb36*/
}

// Address: 0x102cfdb60 | Name: _ossl_ml_dsa_key_compress_decompose
__int64 __fastcall ossl_ml_dsa_key_compress_decompose(int a1, int a2, unsigned int *a3, _DWORD *a4)
{
  unsigned int v4; // eax
  unsigned int v5; // eax
  unsigned int v6; // r9d
  int v7; // edi
  __int64 result; // rax

  v4 = (unsigned int)(a1 + 127) >> 7; /*0x102cfdb6b*/
  if ( a2 == 261888 ) /*0x102cfdb74*/
  {
    v5 = ((1025 * v4 + 0x200000) >> 22) & 0xF; /*0x102cfdb88*/
  }
  else
  {
    v6 = (11275 * v4 + 0x800000) >> 24; /*0x102cfdb9b*/
    v5 = 0; /*0x102cfdb9f*/
    if ( (unsigned int)(a1 + 127) < 0x7E6C80 ) /*0x102cfdba8*/
      v5 = v6; /*0x102cfdba8*/
  }
  *a3 = v5; /*0x102cfdbac*/
  v7 = a1 - 2 * v5 * a2; /*0x102cfdbb3*/
  result = (unsigned int)(v7 - 8380417); /*0x102cfdbb5*/
  if ( v7 < 4190209 ) /*0x102cfdbc1*/
    result = (unsigned int)v7; /*0x102cfdbc1*/
  *a4 = result; /*0x102cfdbc4*/
  return result; /*0x102cfdbc6*/
}

// Address: 0x102cfdbd0 | Name: _ossl_ml_dsa_key_compress_low_bits
__int64 __fastcall ossl_ml_dsa_key_compress_low_bits(int a1, int a2)
{
  unsigned int v2; // eax
  unsigned int v3; // eax
  unsigned int v4; // edx
  int v5; // edi
  __int64 result; // rax

  v2 = (unsigned int)(a1 + 127) >> 7; /*0x102cfdbd9*/
  if ( a2 == 261888 ) /*0x102cfdbe2*/
  {
    v3 = ((1025 * v2 + 0x200000) >> 22) & 0xF; /*0x102cfdbf3*/
  }
  else
  {
    v4 = (11275 * v2 + 0x800000) >> 24; /*0x102cfdc04*/
    v3 = 0; /*0x102cfdc07*/
    if ( (unsigned int)(a1 + 127) < 0x7E6C80 ) /*0x102cfdc0f*/
      v3 = v4; /*0x102cfdc0f*/
  }
  v5 = a1 - 2 * v3 * a2; /*0x102cfdc17*/
  result = (unsigned int)(v5 - 8380417); /*0x102cfdc19*/
  if ( v5 < 4190209 ) /*0x102cfdc25*/
    return (unsigned int)v5; /*0x102cfdc25*/
  return result; /*0x102cfdc28*/
}

// Address: 0x102cfdc30 | Name: _ossl_ml_dsa_key_compress_make_hint
_BOOL8 __fastcall ossl_ml_dsa_key_compress_make_hint(int a1, int a2, int a3, int a4)
{
  int v4; // eax
  unsigned int v5; // esi
  unsigned int v6; // ecx
  unsigned int v7; // ecx
  unsigned int v8; // edx
  unsigned int v9; // eax

  v4 = (a4 - a2 + 8380417) & (((a4 - a2) & (-8380418 - (a4 - a2))) >> 31) /*0x102cfdc52*/
     | (a4 - a2) & ~(((a4 - a2) & (-8380418 - (a4 - a2))) >> 31);
  v5 = ((v4 + a1) & (((v4 + a1 - 8380417) & ~(v4 + a1)) >> 31) /*0x102cfdc76*/
      | (v4 + a1 - 8380417) & ~(((v4 + a1 - 8380417) & ~(v4 + a1)) >> 31))
     + 127;
  v6 = v5 >> 7; /*0x102cfdc7b*/
  if ( a3 == 261888 ) /*0x102cfdc84*/
  {
    v7 = ((1025 * v6 + 0x200000) >> 22) & 0xF; /*0x102cfdc96*/
    v8 = ((1025 * ((unsigned int)(v4 + 127) >> 7) + 0x200000) >> 22) & 0xF; /*0x102cfdcaf*/
  }
  else
  {
    v7 = (11275 * v6 + 0x800000) >> 24; /*0x102cfdcc0*/
    if ( v5 >= 0x7E6C80 ) /*0x102cfdccb*/
      v7 = 0; /*0x102cfdccb*/
    v9 = v4 + 127; /*0x102cfdcce*/
    v8 = (11275 * (v9 >> 7) + 0x800000) >> 24; /*0x102cfdce2*/
    if ( v9 >= 0x7E6C80 ) /*0x102cfdcea*/
      v8 = 0; /*0x102cfdcea*/
  }
  return v7 != v8; /*0x102cfdcf4*/
}

// Address: 0x102cfdd00 | Name: _ossl_ml_dsa_key_compress_use_hint
__int64 __fastcall ossl_ml_dsa_key_compress_use_hint(int a1, int a2, int a3)
{
  unsigned int v3; // eax
  __int64 result; // rax
  unsigned int v5; // r8d
  int v6; // esi
  int v7; // ecx
  char v8; // dl
  char v9; // al
  unsigned int v10; // edx
  bool v11; // cf
  unsigned int v12; // eax
  unsigned int v13; // ecx

  v3 = (unsigned int)(a2 + 127) >> 7; /*0x102cfdd09*/
  if ( a3 == 261888 ) /*0x102cfdd12*/
  {
    result = ((1025 * v3 + 0x200000) >> 22) & 0xF; /*0x102cfdd23*/
  }
  else
  {
    v5 = (11275 * v3 + 0x800000) >> 24; /*0x102cfdd36*/
    result = 0; /*0x102cfdd3a*/
    if ( (unsigned int)(a2 + 127) < 0x7E6C80 ) /*0x102cfdd42*/
      result = v5; /*0x102cfdd42*/
  }
  v6 = a2 - 2 * result * a3; /*0x102cfdd4d*/
  v7 = v6 - 8380417; /*0x102cfdd4f*/
  if ( v6 < 4190209 ) /*0x102cfdd5b*/
    v7 = v6; /*0x102cfdd5b*/
  if ( a1 != 0 ) /*0x102cfdd60*/
  {
    if ( a3 == 261888 ) /*0x102cfdd68*/
    {
      v8 = result + 1; /*0x102cfdd6a*/
      v9 = result - 1; /*0x102cfdd6d*/
      if ( v7 > 0 ) /*0x102cfdd71*/
        v9 = v8; /*0x102cfdd71*/
      return v9 & 0xF; /*0x102cfdd74*/
    }
    else if ( v7 <= 0 ) /*0x102cfdd7b*/
    {
      v11 = (_DWORD)result == 0; /*0x102cfdd8c*/
      v12 = result - 1; /*0x102cfdd8c*/
      v13 = 43; /*0x102cfdd8f*/
      if ( !v11 ) /*0x102cfdd94*/
        return v12; /*0x102cfdd94*/
      return v13; /*0x102cfdd97*/
    }
    else
    {
      v10 = 0; /*0x102cfdd80*/
      if ( (_DWORD)result != 43 ) /*0x102cfdd85*/
        return (unsigned int)(result + 1); /*0x102cfdd85*/
      return v10; /*0x102cfdd88*/
    }
  }
  return result; /*0x102cfdd77*/
}

// Address: 0x102cfdda0 | Name: _ossl_ml_dsa_matrix_mult_vector
unsigned __int64 __fastcall ossl_ml_dsa_matrix_mult_vector(__int64 *a1, _QWORD *a2, __int64 *a3)
{
  __int64 v5; // r12
  unsigned __int64 result; // rax
  unsigned __int64 v7; // rcx
  __int64 v8; // r13
  unsigned __int64 v9; // rdx
  unsigned __int64 i; // r14
  __int64 v11; // rax
  __int64 j; // rcx
  int v13; // edx
  _DWORD v14[256]; // [rsp+8h] [rbp-438h] BYREF
  _QWORD *v15; // [rsp+408h] [rbp-38h]
  unsigned __int64 v16; // [rsp+410h] [rbp-30h]

  v15 = a2; /*0x102cfddb7*/
  v5 = *a1; /*0x102cfddbe*/
  if ( *a3 != 0 ) /*0x102cfddc7*/
    __bzero(a1: *a3, a2: a3[1] << 10); /*0x102cfddd1*/
  result = a1[1]; /*0x102cfddd6*/
  if ( result != 0 && a1[2] != 0 ) /*0x102cfdde8*/
  {
    v7 = 1; /*0x102cfddee*/
    v8 = 0; /*0x102cfddf3*/
    v9 = 0; /*0x102cfddf6*/
    do /*0x102cfdec2*/
    {
      while ( v7 == 0 ) /*0x102cfde18*/
      {
        v7 = 0; /*0x102cfde00*/
        ++v9; /*0x102cfde02*/
        v8 += 1024; /*0x102cfde05*/
        if ( v9 >= result ) /*0x102cfde0f*/
          return result; /*0x102cfde0f*/
      }
      v16 = v9; /*0x102cfde1a*/
      for ( i = 0; i < v7; ++i ) /*0x102cfde1e*/
      {
        ossl_ml_dsa_poly_ntt_mult(a1: v5, a2: *v15 + (i << 10), a3: v14); /*0x102cfde48*/
        v11 = v8 + *a3; /*0x102cfde50*/
        for ( j = 0; j != 256; ++j ) /*0x102cfde53*/
        {
          v13 = *(_DWORD *)(v11 + 4 * j) + v14[j] - 8380417; /*0x102cfde6f*/
          *(_DWORD *)(v11 + 4 * j) = (*(_DWORD *)(v11 + 4 * j) + v14[j]) /*0x102cfde8b*/
                                   & ((v13 & ~(*(_DWORD *)(v11 + 4 * j) + v14[j])) >> 31)
                                   | v13 & ~((v13 & ~(*(_DWORD *)(v11 + 4 * j) + v14[j])) >> 31);
        }
        v5 += 1024; /*0x102cfde9a*/
        v7 = a1[2]; /*0x102cfdea4*/
      }
      result = a1[1]; /*0x102cfdead*/
      v9 = v16 + 1; /*0x102cfdeb5*/
      v8 += 1024; /*0x102cfdeb8*/
    }
    while ( v16 + 1 < result ); /*0x102cfdec2*/
  }
  return result; /*0x102cfdec8*/
}

// Address: 0x102cfdee0 | Name: _ossl_ml_dsa_poly_ntt_mult
__int64 __fastcall ossl_ml_dsa_poly_ntt_mult(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  unsigned __int64 v4; // r8
  unsigned __int64 v5; // rcx

  for ( result = 0; result != 256; ++result ) /*0x102cfdee4*/
  {
    v4 = *(unsigned int *)(a1 + 4 * result) * (unsigned __int64)*(unsigned int *)(a2 + 4 * result); /*0x102cfdef7*/
    v5 = (v4 + 8380417LL * (unsigned int)(-58728449 * v4)) >> 32; /*0x102cfdf0c*/
    *(_DWORD *)(a3 + 4 * result) = v5 & ((int)((v5 - 8380417) & ~(_DWORD)v5) >> 31) /*0x102cfdf33*/
                                 | (v5 - 8380417) & ~((int)((v5 - 8380417) & ~(_DWORD)v5) >> 31);
  }
  return result; /*0x102cfdf42*/
}

// Address: 0x102cfdf50 | Name: _ossl_ml_dsa_poly_ntt
__int64 __fastcall ossl_ml_dsa_poly_ntt(__int64 a1)
{
  __int64 result; // rax
  unsigned int v2; // edx
  __int64 v3; // r10
  __int64 v4; // r11
  unsigned __int64 v5; // rbx
  __int64 v6; // r15
  unsigned __int64 v7; // r12
  int v8; // r13d
  __int64 v9; // rsi
  unsigned __int64 v10; // rax
  __int16 v11; // [rsp+8h] [rbp-38h]
  __int64 v12; // [rsp+8h] [rbp-38h]
  unsigned int v13; // [rsp+10h] [rbp-30h]
  unsigned int v14; // [rsp+14h] [rbp-2Ch]

  LODWORD(result) = 1; /*0x102cfdf5d*/
  v11 = 256; /*0x102cfdf67*/
  v2 = 256; /*0x102cfdf6b*/
  do /*0x102cfdf93*/
  {
    v14 = v2 >> 1; /*0x102cfdf9b*/
    v13 = result; /*0x102cfdf9e*/
    if ( (int)result > 0 ) /*0x102cfdfa3*/
    {
      v12 = v11 & 0x1FE; /*0x102cfdfae*/
      v3 = a1 + 4LL * v14; /*0x102cfdfbd*/
      v4 = 0; /*0x102cfdfc1*/
      v5 = 0; /*0x102cfdfc4*/
      do /*0x102cfe08a*/
      {
        v6 = zetas_montgomery[v4 + v13]; /*0x102cfdfe3*/
        v7 = v5; /*0x102cfdfe7*/
        do /*0x102cfe07a*/
        {
          v8 = *(_DWORD *)(a1 + 4 * v7); /*0x102cfdff0*/
          v9 = v6 * *(unsigned int *)(v3 + 4 * v7); /*0x102cfdff8*/
          v10 = (v9 + 8380417 * (unsigned __int64)(unsigned int)(-58728449 * v9)) >> 32; /*0x102cfe00c*/
          LODWORD(v9) = (int)((v10 - 8380417) /*0x102cfe01c*/
                            & ~((v9 + 8380417 * (unsigned __int64)(unsigned int)(-58728449 * v9)) >> 32)) >> 31;
          LODWORD(v9) = v10 & v9 | (v10 - 8380417) & ~(_DWORD)v9; /*0x102cfe027*/
          *(_DWORD *)(a1 + 4 * v7) = (v9 + v8) & ((int)((v9 + v8 - 8380417) & ~(v9 + v8)) >> 31) /*0x102cfe04d*/
                                   | (v9 + v8 - 8380417) & ~((int)((v9 + v8 - 8380417) & ~(v9 + v8)) >> 31);
          *(_DWORD *)(v3 + 4 * v7++) = (v8 - v9 + 8380417) & ((int)((v8 - v9) & ~(v8 - v9 + 8380417)) >> 31) /*0x102cfe070*/
                                     | (v8 - v9) & ~((int)((v8 - v9) & ~(v8 - v9 + 8380417)) >> 31);
        }
        while ( v7 < v5 + v14 ); /*0x102cfe07a*/
        v5 += v12; /*0x102cfe080*/
        ++v4; /*0x102cfe084*/
      }
      while ( v4 != v13 ); /*0x102cfe08a*/
    }
    result = 2 * v13; /*0x102cfdf83*/
    v2 >>= 1; /*0x102cfdf85*/
    v11 = v14; /*0x102cfdf8a*/
  }
  while ( (int)result < 256 ); /*0x102cfdf93*/
  return result; /*0x102cfe095*/
}

// Address: 0x102cfe0a0 | Name: _ossl_ml_dsa_poly_ntt_inverse
__int64 __fastcall ossl_ml_dsa_poly_ntt_inverse(__int64 a1)
{
  int v1; // ecx
  __int16 v2; // si
  __int64 v3; // rsi
  __int64 v4; // r10
  __int64 v5; // r11
  __int64 v6; // rbx
  __int64 v7; // r15
  __int64 v8; // r12
  int v9; // r13d
  int v10; // edx
  __int64 v11; // r13
  unsigned __int64 v12; // rax
  __int64 result; // rax
  unsigned __int64 v14; // rcx
  int v15; // [rsp+14h] [rbp-34h]
  __int64 v16; // [rsp+18h] [rbp-30h]

  v1 = 1; /*0x102cfe0ad*/
  LODWORD(v16) = 256; /*0x102cfe0b7*/
  do /*0x102cfe1b5*/
  {
    v2 = v16; /*0x102cfe0c2*/
    v16 = (unsigned int)v16 >> 1; /*0x102cfe0ca*/
    v3 = v2 & 0x1FE; /*0x102cfe0ce*/
    v15 = 2 * v1; /*0x102cfe0da*/
    v4 = a1 + 4LL * v1; /*0x102cfe0e7*/
    v5 = 0; /*0x102cfe0eb*/
    v6 = 0; /*0x102cfe0ee*/
    do /*0x102cfe1a6*/
    {
      v7 = 8380417 - zetas_montgomery[v3 + ~v5]; /*0x102cfe10e*/
      v8 = v6; /*0x102cfe112*/
      do /*0x102cfe199*/
      {
        v9 = *(_DWORD *)(a1 + 4 * v8); /*0x102cfe120*/
        v10 = *(_DWORD *)(v4 + 4 * v8); /*0x102cfe124*/
        *(_DWORD *)(a1 + 4 * v8) = (v10 + v9) & (((v10 + v9 - 8380417) & ~(v10 + v9)) >> 31) /*0x102cfe14c*/
                                 | (v10 + v9 - 8380417) & ~(((v10 + v9 - 8380417) & ~(v10 + v9)) >> 31);
        v11 = v7 * (unsigned int)(v9 - v10 + 8380417); /*0x102cfe15a*/
        v12 = (v11 + 8380417 * (unsigned __int64)(unsigned int)(-58728449 * v11)) >> 32; /*0x102cfe16f*/
        *(_DWORD *)(v4 + 4 * v8++) = v12 /*0x102cfe18f*/
                                   & ((int)((v12 - 8380417)
                                          & ~((v11 + 8380417 * (unsigned __int64)(unsigned int)(-58728449 * v11)) >> 32)) >> 31)
                                   | (v12 - 8380417)
                                   & ~((int)((v12 - 8380417)
                                           & ~((v11 + 8380417 * (unsigned __int64)(unsigned int)(-58728449 * v11)) >> 32)) >> 31);
      }
      while ( v8 < v6 + v1 ); /*0x102cfe199*/
      v6 += 2 * v1; /*0x102cfe19b*/
      ++v5; /*0x102cfe19f*/
    }
    while ( v5 != v16 ); /*0x102cfe1a6*/
    v1 *= 2; /*0x102cfe1ac*/
  }
  while ( v15 < 256 ); /*0x102cfe1b5*/
  for ( result = 0; result != 256; ++result ) /*0x102cfe1bb*/
  {
    v14 = (41978LL * *(unsigned int *)(a1 + 4 * result) /*0x102cfe1da*/
         + 8380417 * (unsigned __int64)(unsigned int)(8395782 * *(_DWORD *)(a1 + 4 * result))) >> 32;
    *(_DWORD *)(a1 + 4 * result) = v14 /*0x102cfe1fa*/
                                 & ((int)((v14 - 8380417)
                                        & ~((41978LL * *(unsigned int *)(a1 + 4 * result)
                                           + 8380417
                                           * (unsigned __int64)(unsigned int)(8395782 * *(_DWORD *)(a1 + 4 * result))) >> 32)) >> 31)
                                 | (v14 - 8380417)
                                 & ~((int)((v14 - 8380417)
                                         & ~((41978LL * *(unsigned int *)(a1 + 4 * result)
                                            + 8380417
                                            * (unsigned __int64)(unsigned int)(8395782 * *(_DWORD *)(a1 + 4 * result))) >> 32)) >> 31);
  }
  return result; /*0x102cfe208*/
}

// Address: 0x102cfe220 | Name: _ossl_ml_dsa_params_get
char *__fastcall ossl_ml_dsa_params_get(int a1)
{
  unsigned int v1; // edi

  v1 = a1 - 1457; /*0x102cfe224*/
  if ( v1 > 2 ) /*0x102cfe22d*/
    return nullptr; /*0x102cfe241*/
  else
    return (char *)dword_10949DBF0 + dword_10949DBF0[v1]; /*0x102cfe23c*/
}

// Address: 0x102cfe250 | Name: _ossl_ml_dsa_matrix_expand_A
__int64 __fastcall ossl_ml_dsa_matrix_expand_A(EVP_MD_CTX *ctx, __int64 a2, __int128 *a3, __int64 *a4)
{
  __int64 v4; // r15
  __int128 v5; // xmm0
  unsigned __int64 v6; // rdx
  __int64 result; // rax
  unsigned __int64 v9; // rax
  __int64 v10; // rdi
  unsigned __int64 v11; // rbx
  unsigned __int64 v12; // rcx
  int v13; // r14d
  bool v14; // cf
  unsigned int v15; // esi
  int v16; // eax
  __int64 v17; // [rsp+8h] [rbp-128h]
  _QWORD d[4]; // [rsp+20h] [rbp-110h] BYREF
  char v20; // [rsp+40h] [rbp-F0h]
  char v21; // [rsp+41h] [rbp-EFh]
  _WORD v22[88]; // [rsp+50h] [rbp-E0h] BYREF

  v4 = *a4; /*0x102cfe272*/
  v5 = *a3; /*0x102cfe275*/
  *(_OWORD *)&d[2] = a3[1]; /*0x102cfe27c*/
  *(_OWORD *)d = v5; /*0x102cfe283*/
  v6 = a4[1]; /*0x102cfe28a*/
  result = 1; /*0x102cfe28e*/
  if ( v6 != 0 && a4[2] != 0 ) /*0x102cfe2a1*/
  {
    v9 = 1; /*0x102cfe2aa*/
    v10 = 0; /*0x102cfe2af*/
    while ( 1 ) /*0x102cfe2c9*/
    {
      while ( v9 == 0 ) /*0x102cfe2c9*/
      {
        v9 = 0; /*0x102cfe3e0*/
        if ( ++v10 >= v6 ) /*0x102cfe3e8*/
          return 1; /*0x102cfe3e8*/
      }
      v11 = 0; /*0x102cfe2cf*/
      v17 = v10; /*0x102cfe2d1*/
      while ( 2 ) /*0x102cfe30c*/
      {
        v21 = v10; /*0x102cfe30c*/
        v20 = v11; /*0x102cfe313*/
        if ( (unsigned int)EVP_DigestInit_ex2(a1: ctx) != 1 /*0x102cfe35c*/
          || EVP_DigestUpdate(ctx, d, cnt: 0x22u) != 1
          || (unsigned int)EVP_DigestSqueeze(a1: (__int64)ctx, a2: (__int64)v22, a3: 168) != 1 )
        {
          return 0; /*0x102cfe407*/
        }
        v12 = 0; /*0x102cfe362*/
        v13 = 0; /*0x102cfe364*/
        while ( 1 ) /*0x102cfe399*/
        {
          v15 = *(unsigned __int16 *)((char *)v22 + v12) | ((*((_BYTE *)&v22[1] + v12) & 0x7F) << 16); /*0x102cfe399*/
          *(_DWORD *)(v4 + 4LL * v13) = v15; /*0x102cfe39b*/
          if ( v15 <= 0x7FE000 ) /*0x102cfe3a5*/
          {
            if ( v13 > 254 ) /*0x102cfe3ae*/
              break; /*0x102cfe3ae*/
            ++v13; /*0x102cfe3b4*/
          }
          v14 = v12 < 0xA5; /*0x102cfe370*/
          v12 += 3LL; /*0x102cfe37b*/
          if ( !v14 ) /*0x102cfe37e*/
          {
            v16 = EVP_DigestSqueeze(a1: (__int64)ctx, a2: (__int64)v22, a3: 168); /*0x102cfe3cb*/
            v12 = 0; /*0x102cfe3d0*/
            if ( v16 == 0 ) /*0x102cfe3d7*/
              return 0; /*0x102cfe3d7*/
          }
        }
        v4 += 1024; /*0x102cfe2e0*/
        ++v11; /*0x102cfe2e7*/
        v9 = a4[2]; /*0x102cfe2f1*/
        LOBYTE(v10) = v17; /*0x102cfe2ff*/
        if ( v11 < v9 ) /*0x102cfe306*/
          continue; /*0x102cfe306*/
        break;
      }
      v6 = a4[1]; /*0x102cfe3f0*/
      v10 = v17 + 1; /*0x102cfe3f4*/
      if ( v17 + 1 >= v6 ) /*0x102cfe3fa*/
        return 1; /*0x102cfe405*/
    }
  }
  return result; /*0x102cfe419*/
}

// Address: 0x102cfe430 | Name: _ossl_ml_dsa_vector_expand_S
__int64 __fastcall ossl_ml_dsa_vector_expand_S(
        EVP_MD_CTX *ctx,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  __int64 v7; // r13
  __int64 v8; // rbx
  __int64 v9; // r14
  __int64 result; // rax
  __int64 v11; // r13
  char v12; // [rsp+60h] [rbp-40h]

  v7 = *(_QWORD *)(a5 + 8); /*0x102cfe460*/
  v8 = *(_QWORD *)(a6 + 8); /*0x102cfe46b*/
  v12 = 0; /*0x102cfe4a3*/
  if ( v7 != 0 ) /*0x102cfe4ac*/
  {
    v9 = 0; /*0x102cfe4ae*/
    while ( (unsigned int)rej_bounded_poly(ctx) != 0 ) /*0x102cfe4e5*/
    {
      ++v12; /*0x102cfe4e7*/
      v9 += 1024; /*0x102cfe4ea*/
      if ( --v7 == 0 ) /*0x102cfe4f4*/
        goto LABEL_5; /*0x102cfe4f4*/
    }
    return 0; /*0x102cfe556*/
  }
  else
  {
LABEL_5:
    result = 1; /*0x102cfe4f6*/
    if ( v8 != 0 ) /*0x102cfe4fe*/
    {
      v11 = 0; /*0x102cfe500*/
      while ( (unsigned int)rej_bounded_poly(ctx) != 0 ) /*0x102cfe52e*/
      {
        ++v12; /*0x102cfe530*/
        v11 += 1024; /*0x102cfe533*/
        if ( --v8 == 0 ) /*0x102cfe53d*/
          return 1; /*0x102cfe552*/
      }
      return 0; /*0x102cfe577*/
    }
  }
  return result; /*0x102cfe568*/
}

// Address: 0x102cfe780 | Name: _ossl_ml_dsa_poly_expand_mask
__int64 __fastcall ossl_ml_dsa_poly_expand_mask(__int64 a1, const void *a2, size_t a3, int a4, EVP_MD_CTX *a5)
{
  int v8; // r12d
  unsigned int v9; // ebx
  __int64 v10; // r12
  bool v14; // [rsp+Fh] [rbp-2B1h]
  _BYTE v15[640]; // [rsp+10h] [rbp-2B0h] BYREF

  v8 = 0; /*0x102cfe7b2*/
  v14 = a4 == 0x80000; /*0x102cfe7c1*/
  v9 = 0; /*0x102cfe7c8*/
  if ( (unsigned int)EVP_DigestInit_ex2(a1: a5) == 1 && EVP_DigestUpdate(ctx: a5, d: a2, cnt: a3) == 1 ) /*0x102cfe7ed*/
  {
    LOBYTE(v8) = v14; /*0x102cfe7f6*/
    v10 = (unsigned int)(v8 << 6) + 576LL; /*0x102cfe7fd*/
    if ( (unsigned int)EVP_DigestSqueeze(a1: (__int64)a5, a2: (__int64)v15, a3: v10) == 1 ) /*0x102cfe819*/
      return (unsigned int)ossl_ml_dsa_poly_decode_expand_mask(a1, a2: (__int64)v15, a3: v10, a4) != 0; /*0x102cfe83b*/
  }
  return v9; /*0x102cfe850*/
}

// Address: 0x102cfe870 | Name: _ossl_ml_dsa_poly_sample_in_ball
__int64 __fastcall ossl_ml_dsa_poly_sample_in_ball(
        __int64 a1,
        const void *a2,
        int a3,
        EVP_MD_CTX *a4,
        __int64 a5,
        int a6)
{
  unsigned int v10; // r15d
  unsigned __int64 v11; // r14
  unsigned __int64 v12; // r13
  int v13; // eax
  __int64 v14; // rax
  unsigned __int64 v15; // rax
  _QWORD v18[18]; // [rsp+10h] [rbp-C0h] BYREF

  v10 = 0; /*0x102cfe8a5*/
  if ( (unsigned int)EVP_DigestInit_ex2(a1: a4) == 1 /*0x102cfe8ec*/
    && EVP_DigestUpdate(ctx: a4, d: a2, cnt: a3) == 1
    && (unsigned int)EVP_DigestSqueeze(a1: (__int64)a4, a2: (__int64)v18, a3: 136) == 1 )
  {
    v11 = v18[0]; /*0x102cfe8f2*/
    __bzero(a1, a2: 1024); /*0x102cfe905*/
    v10 = 1; /*0x102cfe912*/
    if ( (unsigned int)(256 - a6) <= 0xFF ) /*0x102cfe91d*/
    {
      v12 = (unsigned int)(256 - a6); /*0x102cfe923*/
      v13 = 8; /*0x102cfe926*/
LABEL_7:
      v10 = v13; /*0x102cfe982*/
      while ( 1 ) /*0x102cfe9aa*/
      {
        if ( v10 == 136 ) /*0x102cfe9aa*/
        {
          v10 = 0; /*0x102cfe9bc*/
          if ( (unsigned int)EVP_DigestSqueeze(a1: (__int64)a4, a2: (__int64)v18, a3: 136) == 0 ) /*0x102cfe9c1*/
            break; /*0x102cfe9c1*/
        }
        v14 = (int)v10++; /*0x102cfe990*/
        v15 = *((unsigned __int8 *)v18 + v14); /*0x102cfe996*/
        if ( v12 >= v15 ) /*0x102cfe9a1*/
        {
          *(_DWORD *)(a1 + 4 * v12) = *(_DWORD *)(a1 + 4 * v15); /*0x102cfe93f*/
          *(_DWORD *)(a1 + 4 * v15) = ((2 * (_BYTE)v11) & 2 ^ 0x7FE002) & ((1 - ((2 * (unsigned __int8)v11) & 2)) >> 31) /*0x102cfe966*/
                                    | (1 - ((2 * (_BYTE)v11) & 2)) & ~((1 - ((2 * (unsigned __int8)v11) & 2)) >> 31);
          v11 >>= 1; /*0x102cfe96a*/
          ++v12; /*0x102cfe96d*/
          v13 = v10; /*0x102cfe970*/
          v10 = 1; /*0x102cfe973*/
          if ( v12 == 256 ) /*0x102cfe980*/
            return v10; /*0x102cfe980*/
          goto LABEL_7; /*0x102cfe980*/
        }
      }
    }
  }
  return v10; /*0x102cfe9d6*/
}

// Address: 0x102cfe9f0 | Name: _ossl_ml_dsa_sign
__int64 __fastcall ossl_ml_dsa_sign(
        __int64 a1,
        int a2,
        void *a3,
        size_t a4,
        const void *a5,
        size_t a6,
        void *d,
        size_t cnt,
        int a9,
        __int64 a10,
        _QWORD *a11,
        unsigned __int64 a12)
{
  __int64 v15; // r13
  unsigned int v16; // ebx
  int *v17; // rdx
  _QWORD *v18; // rax
  _BYTE *v19; // rax
  _BYTE *v20; // rbx
  _BYTE *v21; // rsi
  void *v22; // rcx
  __int64 v23; // r15
  __int64 v24; // r13
  int v25; // r14d
  __int64 v26; // rbx
  __int64 v27; // r13
  __int64 v28; // rax
  EVP_MD_CTX *v29; // r14
  char *v30; // rax
  unsigned __int64 v31; // rdi
  char *v32; // r15
  char *v33; // rdx
  const __m128i *v34; // rbx
  __int64 v35; // rbx
  EVP_MD_CTX *v36; // r13
  __int64 v37; // rbx
  char *v38; // r12
  __int64 v39; // r13
  __int64 v40; // rbx
  __int64 i; // r14
  __int64 v42; // rbx
  char *v43; // r14
  size_t v44; // r13
  __int64 v45; // rbx
  size_t j; // r14
  size_t v47; // rbx
  __int64 v49; // rbx
  __int64 v50; // rax
  __int64 v51; // r13
  int v52; // r8d
  __int64 v53; // r9
  __m128i v54; // xmm0
  __m128i v55; // xmm1
  __m128i v56; // xmm2
  bool v57; // zf
  EVP_MD_CTX *v58; // r13
  int v59; // ecx
  char *v60; // r15
  __int64 v61; // r12
  __int64 v62; // rbx
  unsigned __int64 k; // r14
  __int64 v64; // rbx
  size_t m; // r14
  __int64 v66; // rbx
  size_t v67; // rax
  char *v68; // r12
  char *v69; // r13
  __int64 v70; // r14
  int v71; // r15d
  __int64 v72; // rbx
  int v73; // eax
  size_t v74; // r12
  __int64 v75; // r15
  __int64 v76; // r13
  void *v77; // r14
  __int64 v78; // rbx
  size_t v79; // r12
  __int64 v80; // rbx
  unsigned __int64 n; // r14
  char *v82; // r11
  char *v83; // rbx
  size_t v84; // r14
  __int64 v85; // r12
  __int64 v86; // rbx
  size_t v87; // r14
  _DWORD *v88; // rax
  _DWORD *v89; // rcx
  __int64 v90; // rdx
  __int64 ii; // rsi
  int v92; // edi
  size_t v93; // rax
  __int64 v94; // rcx
  char *v95; // rdx
  __int64 v96; // rsi
  __int64 v97; // rdi
  __int64 jj; // r8
  int v99; // r9d
  __int64 v100; // rbx
  size_t kk; // r15
  char *v102; // r12
  __int64 v103; // r14
  int v104; // r13d
  size_t v105; // rax
  int v106; // ecx
  int v107; // edx
  __int64 v108; // r15
  __int64 v109; // rdi
  char *v110; // r8
  __int64 mm; // r9
  int v112; // r11d
  int v113; // r10d
  char *v114; // rsi
  __int64 v115; // rdi
  __int64 nn; // r8
  int v117; // r9d
  int v118; // esi
  unsigned __int64 v119; // r14
  char *v120; // r12
  __int64 v121; // rbx
  __int64 v122; // rbx
  size_t v123; // r15
  size_t v124; // rcx
  size_t v125; // r15
  const __m128i *v126; // r12
  __int64 v127; // r13
  __int64 v128; // rdx
  __int64 v129; // rsi
  char *v130; // rbx
  __int64 v131; // r14
  int v132; // r15d
  unsigned int v133; // edx
  int v134; // eax
  char *v135; // rsi
  __int64 v136; // rdi
  __int64 i1; // r8
  int v138; // r10d
  int v139; // r9d
  const __m128i *v140; // rcx
  __m128i v141; // xmm1
  __m128i v142; // xmm2
  __m128i v143; // xmm0
  __int64 v144; // [rsp+0h] [rbp-6B0h] BYREF
  size_t v145; // [rsp+8h] [rbp-6A8h]
  __int64 v146; // [rsp+10h] [rbp-6A0h]
  size_t v147; // [rsp+18h] [rbp-698h]
  __int64 v148; // [rsp+20h] [rbp-690h]
  __int64 v149; // [rsp+28h] [rbp-688h]
  size_t v150; // [rsp+30h] [rbp-680h]
  __int64 v151; // [rsp+38h] [rbp-678h]
  char *v152; // [rsp+40h] [rbp-670h]
  char *v153; // [rsp+48h] [rbp-668h] BYREF
  __int64 v154; // [rsp+50h] [rbp-660h]
  const __m128i *v155; // [rsp+58h] [rbp-658h]
  size_t v156; // [rsp+60h] [rbp-650h]
  _BYTE *v157; // [rsp+68h] [rbp-648h]
  __int64 v158; // [rsp+70h] [rbp-640h]
  void *v159; // [rsp+78h] [rbp-638h]
  __int64 v160; // [rsp+80h] [rbp-630h]
  __int64 v161; // [rsp+88h] [rbp-628h]
  __int64 v162; // [rsp+90h] [rbp-620h]
  unsigned __int64 v163; // [rsp+98h] [rbp-618h]
  size_t v164; // [rsp+A0h] [rbp-610h]
  int *v165; // [rsp+A8h] [rbp-608h]
  __int64 v166; // [rsp+B0h] [rbp-600h]
  char *v167; // [rsp+B8h] [rbp-5F8h]
  void *v168; // [rsp+C0h] [rbp-5F0h]
  void *v169; // [rsp+C8h] [rbp-5E8h]
  size_t v170; // [rsp+D0h] [rbp-5E0h]
  EVP_MD_CTX *ctx; // [rsp+D8h] [rbp-5D8h]
  char *v172; // [rsp+E0h] [rbp-5D0h] BYREF
  size_t v173; // [rsp+E8h] [rbp-5C8h]
  void *v174; // [rsp+F0h] [rbp-5C0h]
  void *__dst; // [rsp+F8h] [rbp-5B8h]
  size_t v176; // [rsp+100h] [rbp-5B0h]
  __int64 v177; // [rsp+108h] [rbp-5A8h]
  void *v178; // [rsp+110h] [rbp-5A0h] BYREF
  unsigned __int64 v179; // [rsp+118h] [rbp-598h]
  size_t v180; // [rsp+120h] [rbp-590h]
  __int64 v181; // [rsp+128h] [rbp-588h]
  int v182; // [rsp+134h] [rbp-57Ch]
  void *__src; // [rsp+138h] [rbp-578h]
  char *v184; // [rsp+140h] [rbp-570h] BYREF
  size_t v185; // [rsp+148h] [rbp-568h]
  __int64 v186; // [rsp+150h] [rbp-560h]
  size_t __n; // [rsp+158h] [rbp-558h]
  _BYTE *v188; // [rsp+160h] [rbp-550h]
  __int64 v189; // [rsp+168h] [rbp-548h]
  _BYTE v190[1024]; // [rsp+170h] [rbp-540h] BYREF
  _BYTE v191[64]; // [rsp+570h] [rbp-140h] BYREF
  __m128i ptr; // [rsp+5B0h] [rbp-100h] BYREF
  __m128i v193; // [rsp+5C0h] [rbp-F0h] BYREF
  __m128i v194; // [rsp+5D0h] [rbp-E0h] BYREF
  __m128i v195; // [rsp+5E0h] [rbp-D0h] BYREF
  _BYTE v196[64]; // [rsp+5F0h] [rbp-C0h] BYREF
  _QWORD v197[8]; // [rsp+630h] [rbp-80h] BYREF
  char v198; // [rsp+670h] [rbp-40h]
  char v199; // [rsp+671h] [rbp-3Fh]

  __n = a4; /*0x102cfea0a*/
  __src = a3; /*0x102cfea11*/
  v15 = a1; /*0x102cfea1b*/
  v16 = 0; /*0x102cfea31*/
  if ( ossl_ml_dsa_key_get_priv(a1) != 0 ) /*0x102cfea36*/
  {
    if ( a10 == 0 ) /*0x102cfea41*/
    {
      v16 = 1; /*0x102cfea7c*/
      v18 = a11; /*0x102cfea81*/
      if ( a11 == nullptr ) /*0x102cfea88*/
        return v16; /*0x102cfea88*/
      goto LABEL_43; /*0x102cfea88*/
    }
    v17 = *(int **)(v15 + 8); /*0x102cfea47*/
    if ( *((_QWORD *)v17 + 10) <= a12 ) /*0x102cfea4f*/
    {
      v186 = v15; /*0x102cfea58*/
      if ( a2 != 0 ) /*0x102cfea5f*/
      {
        v189 = 0; /*0x102cfea61*/
        v159 = nullptr; /*0x102cfea6c*/
      }
      else
      {
        if ( a9 != 0 ) /*0x102cfea97*/
        {
          v16 = 0; /*0x102cfea99*/
          if ( a6 > 0xFF ) /*0x102cfeaa2*/
            return v16; /*0x102cfeaa2*/
          v180 = a6 + __n + 2; /*0x102cfeabe*/
          if ( v180 >= 0x401 ) /*0x102cfeac5*/
          {
            v189 = 0; /*0x102cfeb00*/
            v19 = CRYPTO_malloc(num: (int)a6 + (int)__n + 2, file: "crypto/ml_dsa/ml_dsa_sign.c", line: 351); /*0x102cfeb1a*/
            if ( v19 == nullptr ) /*0x102cfeb22*/
              return v16; /*0x102cfeb22*/
          }
          else
          {
            v189 = 0; /*0x102cfeac7*/
            v19 = v190; /*0x102cfead2*/
          }
          v188 = v19; /*0x102cfeb28*/
          *v19 = 0; /*0x102cfeb33*/
          v19[1] = a6; /*0x102cfeb36*/
          memcpy(__dst: v19 + 2, __src: a5, __n: a6); /*0x102cfeb44*/
          v20 = __src; /*0x102cfeb53*/
          memcpy(__dst: &v188[a6 + 2], __src, __n); /*0x102cfeb64*/
          v21 = v188; /*0x102cfeb69*/
          v17 = *(int **)(v15 + 8); /*0x102cfeb70*/
          __n = v180; /*0x102cfeb7b*/
        }
        else
        {
          v189 = 0; /*0x102cfeadb*/
          v20 = __src; /*0x102cfeae6*/
          v21 = __src; /*0x102cfeaed*/
          if ( __src == nullptr ) /*0x102cfeaf3*/
            return 0; /*0x102cfeafb*/
        }
        v22 = nullptr; /*0x102cfeb8e*/
        if ( v21 != v190 ) /*0x102cfeb93*/
          v22 = v21; /*0x102cfeb93*/
        if ( v21 == v20 ) /*0x102cfeb9a*/
          v22 = nullptr; /*0x102cfeb9a*/
        v159 = v22; /*0x102cfeb9e*/
        __src = v21; /*0x102cfeba5*/
      }
      v23 = *((_QWORD *)v17 + 4); /*0x102cfebac*/
      v24 = *((_QWORD *)v17 + 5); /*0x102cfebb0*/
      LODWORD(v180) = v17[5]; /*0x102cfebb7*/
      v25 = v17[6]; /*0x102cfebbd*/
      v26 = (unsigned int)(3 * v24); /*0x102cfebc9*/
      v160 = v24; /*0x102cfebce*/
      v27 = (unsigned int)(v23 * v24); /*0x102cfebd5*/
      v165 = v17; /*0x102cfebd9*/
      v182 = v17[4]; /*0x102cfebe3*/
      __dst = (void *)(unsigned int)(5 * v23); /*0x102cfebff*/
      v28 = ((_QWORD)__dst + (unsigned int)(2 * v23) + v26 + v27) << 10; /*0x102cfec0f*/
      v164 = (unsigned int)v23 * (((v25 == 95232) | 2) << 6); /*0x102cfec13*/
      v147 = v28 + v164 + 1024; /*0x102cfec2c*/
      v174 = CRYPTO_malloc(num: (int)v28 + (int)v164 + 1024, file: "crypto/ml_dsa/ml_dsa_sign.c", line: 85); /*0x102cfec3d*/
      if ( v174 == nullptr ) /*0x102cfec47*/
        goto LABEL_42; /*0x102cfec47*/
      LODWORD(v188) = v25; /*0x102cfec4d*/
      v29 = (EVP_MD_CTX *)EVP_MD_CTX_new(); /*0x102cfec59*/
      v189 = 0; /*0x102cfec5c*/
      if ( v29 != nullptr ) /*0x102cfec6a*/
      {
        v182 >>= 2; /*0x102cfec79*/
        v145 = (unsigned int)v23; /*0x102cfecad*/
        v146 = (unsigned int)v160; /*0x102cfecb4*/
        v144 = (__int64)v174 + v164 + 1024; /*0x102cfecbb*/
        v166 = (__int64)v174 + v164; /*0x102cfecc6*/
        v30 = (char *)v174 + 1024 * v27 + v164 + 1024; /*0x102cfecd1*/
        v31 = (unsigned __int64)(unsigned int)v23 << 10; /*0x102cfecda*/
        v32 = &v30[v31]; /*0x102cfecde*/
        v172 = &v30[v31 + v31]; /*0x102cfece6*/
        v173 = v145; /*0x102cfeced*/
        v177 = (__int64)&v172[v31]; /*0x102cfecf7*/
        v184 = &v172[v31]; /*0x102cfecfe*/
        v185 = v145; /*0x102cfed05*/
        v168 = v30; /*0x102cfed17*/
        v33 = &v30[1024 * (_QWORD)__dst]; /*0x102cfed1e*/
        v178 = &v33[1024 * (unsigned __int64)(unsigned int)(2 * v160)]; /*0x102cfed2b*/
        v179 = (unsigned int)v160; /*0x102cfed32*/
        __dst = v33; /*0x102cfed3d*/
        v34 = (const __m128i *)&v33[1024 * v26]; /*0x102cfed44*/
        v163 = v31; /*0x102cfed47*/
        v167 = &v34->i8[v31]; /*0x102cfed52*/
        v153 = &v34->i8[v31]; /*0x102cfed59*/
        v181 = (unsigned int)v160; /*0x102cfed60*/
        v154 = (unsigned int)v160; /*0x102cfed67*/
        v155 = v34; /*0x102cfed6e*/
        v176 = v145; /*0x102cfed75*/
        v156 = v145; /*0x102cfed7c*/
        v157 = v191; /*0x102cfed8a*/
        v149 = v182; /*0x102cfed91*/
        v158 = v182; /*0x102cfed98*/
        v35 = v186; /*0x102cfed9f*/
        v36 = v29; /*0x102cfedbf*/
        if ( (unsigned int)ossl_ml_dsa_matrix_expand_A( /*0x102cfedc2*/
                             ctx: v29,
                             a2: *(_QWORD *)(v186 + 16),
                             a3: (__int128 *)(v186 + 32),
                             a4: &v144) != 0 )
        {
          if ( a2 != 0 ) /*0x102cfedcb*/
          {
            if ( __n == 64 ) /*0x102cfedd9*/
              goto LABEL_26; /*0x102cfedd9*/
          }
          else
          {
            v189 = 0; /*0x102cff00c*/
            if ( (unsigned int)EVP_DigestInit_ex2(a1: v29) != 0 /*0x102cff05a*/
              && EVP_DigestUpdate(ctx: v29, d: (const void *)(v35 + 64), cnt: 0x40u) != 0
              && EVP_DigestUpdate(ctx: v29, d: __src, cnt: __n) != 0 )
            {
              __src = v196; /*0x102cff06f*/
              if ( (unsigned int)EVP_DigestSqueeze(a1: (__int64)v29, a2: (__int64)v196, a3: 64) != 0 ) /*0x102cff07d*/
              {
LABEL_26:
                v37 = v186; /*0x102cfeddf*/
                v189 = 0; /*0x102cfedea*/
                if ( (unsigned int)EVP_DigestInit_ex2(a1: v29) != 0 /*0x102cfee6d*/
                  && EVP_DigestUpdate(ctx: v29, d: (const void *)(v37 + 128), cnt: 0x20u) != 0
                  && EVP_DigestUpdate(ctx: v29, d, cnt) != 0
                  && EVP_DigestUpdate(ctx: v29, d: __src, cnt: 0x40u) != 0
                  && (unsigned int)EVP_DigestSqueeze(a1: (__int64)v29, a2: (__int64)&ptr, a3: 64) != 0 )
                {
                  ctx = v29; /*0x102cfee73*/
                  v38 = (char *)__dst; /*0x102cfee93*/
                  memcpy(__dst, __src: *(const void **)(v186 + 240), __n: *(_QWORD *)(v186 + 248) << 10); /*0x102cfee9d*/
                  v39 = v181; /*0x102cfeea2*/
                  if ( v181 != 0 ) /*0x102cfeeac*/
                  {
                    v40 = (__int64)v38; /*0x102cfeeae*/
                    for ( i = v181; i != 0; --i ) /*0x102cfeeb1*/
                    {
                      ossl_ml_dsa_poly_ntt(a1: v40); /*0x102cfeeb7*/
                      v40 += 1024; /*0x102cfeebc*/
                    }
                  }
                  v170 = v39 << 10; /*0x102cfeecc*/
                  v42 = v186; /*0x102cfeed3*/
                  v43 = (char *)v168; /*0x102cfeeec*/
                  memcpy(__dst: v168, __src: *(const void **)(v186 + 224), __n: *(_QWORD *)(v186 + 232) << 10); /*0x102cfeef6*/
                  v44 = v176; /*0x102cfeefb*/
                  if ( v176 != 0 ) /*0x102cfef05*/
                  {
                    v45 = (__int64)v43; /*0x102cfef0b*/
                    for ( j = v176; j != 0; --j ) /*0x102cfef0e*/
                    {
                      ossl_ml_dsa_poly_ntt(a1: v45); /*0x102cfef14*/
                      v45 += 1024; /*0x102cfef19*/
                    }
                    memcpy(__dst: v32, __src: *(const void **)(v186 + 208), __n: *(_QWORD *)(v186 + 216) << 10); /*0x102cfef41*/
                    v47 = v44; /*0x102cfef46*/
                    v43 = (char *)v168; /*0x102cfef49*/
                    do /*0x102cfef62*/
                    {
                      ossl_ml_dsa_poly_ntt(a1: (__int64)v32); /*0x102cfef53*/
                      v32 += 1024; /*0x102cfef58*/
                      --v47; /*0x102cfef5f*/
                    }
                    while ( v47 != 0 ); /*0x102cfef62*/
                  }
                  else
                  {
                    memcpy(__dst: v32, __src: *(const void **)(v42 + 208), __n: *(_QWORD *)(v42 + 216) << 10); /*0x102cff09d*/
                  }
                  v177 += v163; /*0x102cff0a9*/
                  v169 = &v38[v170]; /*0x102cff0ba*/
                  v151 = v44 << 12; /*0x102cff0c5*/
                  v152 = &v43[v163]; /*0x102cff0cf*/
                  v49 = 0; /*0x102cff0d6*/
                  v50 = 0; /*0x102cff0dc*/
                  v51 = v181; /*0x102cff0de*/
                  while ( 1 ) /*0x102cff156*/
                  {
                    v53 = *(_QWORD *)(v186 + 24); /*0x102cff156*/
                    v54 = _mm_load_si128(&ptr); /*0x102cff15a*/
                    v55 = _mm_load_si128(&v193); /*0x102cff162*/
                    v56 = _mm_load_si128(&v194); /*0x102cff16a*/
                    *(__m128i *)&v197[6] = _mm_load_si128(&v195); /*0x102cff17a*/
                    *(__m128i *)&v197[4] = v56; /*0x102cff17f*/
                    *(__m128i *)&v197[2] = v55; /*0x102cff184*/
                    *(__m128i *)v197 = v54; /*0x102cff189*/
                    v57 = v51 == 0; /*0x102cff18e*/
                    v58 = ctx; /*0x102cff191*/
                    v59 = v180; /*0x102cff198*/
                    v161 = v49; /*0x102cff19e*/
                    v162 = v50; /*0x102cff1a5*/
                    if ( !v57 ) /*0x102cff1ac*/
                    {
                      v60 = (char *)v169; /*0x102cff1ae*/
                      v61 = 0; /*0x102cff1b5*/
                      do /*0x102cff206*/
                      {
                        v198 = v49 + v61; /*0x102cff1c6*/
                        v199 = (unsigned __int16)(v61 + v162) >> 8; /*0x102cff1c9*/
                        v49 = v53; /*0x102cff1da*/
                        ossl_ml_dsa_poly_expand_mask(a1: (__int64)v60, a2: v197, a3: 0x42u, a4: v59, a5: v58); /*0x102cff1dd*/
                        v59 = v180; /*0x102cff1e2*/
                        v53 = v49; /*0x102cff1ef*/
                        LOBYTE(v49) = v161; /*0x102cff1f2*/
                        ++v61; /*0x102cff1f9*/
                        v60 += 1024; /*0x102cff1fc*/
                      }
                      while ( v181 != v61 ); /*0x102cff206*/
                    }
                    memcpy(__dst: v178, __src: v169, __n: v170); /*0x102cff21d*/
                    if ( v179 != 0 ) /*0x102cff22a*/
                    {
                      v62 = 0; /*0x102cff22c*/
                      for ( k = 0; k < v179; ++k ) /*0x102cff22e*/
                      {
                        ossl_ml_dsa_poly_ntt(a1: (__int64)v178 + v62); /*0x102cff23b*/
                        v62 += 1024; /*0x102cff243*/
                      }
                    }
                    ossl_ml_dsa_matrix_mult_vector(a1: &v144, a2: &v178, a3: (__int64 *)&v172); /*0x102cff268*/
                    if ( v173 != 0 ) /*0x102cff275*/
                    {
                      v64 = 0; /*0x102cff277*/
                      for ( m = 0; m < v173; ++m ) /*0x102cff279*/
                      {
                        ossl_ml_dsa_poly_ntt_inverse(a1: (__int64)&v172[v64]); /*0x102cff286*/
                        v64 += 1024; /*0x102cff28e*/
                      }
                    }
                    if ( v185 != 0 ) /*0x102cff2a6*/
                    {
                      v66 = 0; /*0x102cff2a8*/
                      v67 = 0; /*0x102cff2aa*/
                      do /*0x102cff315*/
                      {
                        __n = v67; /*0x102cff2ac*/
                        v68 = &v184[v66]; /*0x102cff2ba*/
                        v69 = &v172[v66]; /*0x102cff2c4*/
                        v70 = 0; /*0x102cff2c7*/
                        v71 = (int)v188; /*0x102cff2ca*/
                        do /*0x102cff2fb*/
                        {
                          *(_DWORD *)&v68[4 * v70] = ossl_ml_dsa_key_compress_high_bits( /*0x102cff2ed*/
                                                       a1: *(_DWORD *)&v69[4 * v70],
                                                       a2: v71);
                          ++v70; /*0x102cff2f1*/
                        }
                        while ( v70 != 256 ); /*0x102cff2fb*/
                        v67 = __n + 1; /*0x102cff304*/
                        v66 += 1024; /*0x102cff307*/
                      }
                      while ( __n + 1 < v185 ); /*0x102cff315*/
                    }
                    ossl_ml_dsa_w1_encode(a1: &v184, a2: (int)v188, a3: (__int64)v174, a4: v164); /*0x102cff332*/
                    v72 = v186; /*0x102cff337*/
                    v189 = 0; /*0x102cff342*/
                    v36 = ctx; /*0x102cff34d*/
                    if ( (unsigned int)EVP_DigestInit_ex2(a1: ctx) == 0 ) /*0x102cff360*/
                      break; /*0x102cff360*/
                    if ( EVP_DigestUpdate(ctx: v36, d: __src, cnt: 0x40u) == 0 ) /*0x102cff37c*/
                      break; /*0x102cff37c*/
                    v73 = EVP_DigestUpdate(ctx: v36, d: v174, cnt: v164); /*0x102cff393*/
                    v74 = v170; /*0x102cff39a*/
                    if ( v73 == 0 /*0x102cff3f1*/
                      || (unsigned int)EVP_DigestSqueeze(a1: (__int64)v36, a2: (__int64)v191, a3: v149) == 0
                      || (unsigned int)ossl_ml_dsa_poly_sample_in_ball(
                                         a1: v166,
                                         a2: v191,
                                         a3: v182,
                                         a4: v36,
                                         a5: *(_QWORD *)(v72 + 24),
                                         a6: v165[3]) == 0 )
                    {
                      break; /*0x102cff3f1*/
                    }
                    v75 = v166; /*0x102cff3f7*/
                    ossl_ml_dsa_poly_ntt(a1: v166); /*0x102cff401*/
                    v76 = v181; /*0x102cff406*/
                    v77 = __dst; /*0x102cff410*/
                    if ( v181 != 0 ) /*0x102cff417*/
                    {
                      v78 = 0; /*0x102cff419*/
                      do /*0x102cff43b*/
                      {
                        ossl_ml_dsa_poly_ntt_mult(a1: (__int64)v77 + v78, a2: v75, a3: (__int64)v178 + v78); /*0x102cff42c*/
                        v78 += 1024; /*0x102cff431*/
                      }
                      while ( v74 != v78 ); /*0x102cff43b*/
                    }
                    v79 = v176; /*0x102cff445*/
                    if ( v179 != 0 ) /*0x102cff44c*/
                    {
                      v80 = 0; /*0x102cff44e*/
                      for ( n = 0; n < v179; ++n ) /*0x102cff450*/
                      {
                        ossl_ml_dsa_poly_ntt_inverse(a1: (__int64)v178 + v80); /*0x102cff45d*/
                        v80 += 1024; /*0x102cff465*/
                      }
                    }
                    v82 = v167; /*0x102cff478*/
                    if ( v79 != 0 ) /*0x102cff47f*/
                    {
                      v83 = (char *)v168; /*0x102cff481*/
                      v84 = v79; /*0x102cff488*/
                      v85 = v151; /*0x102cff48b*/
                      do /*0x102cff4ab*/
                      {
                        ossl_ml_dsa_poly_ntt_mult(a1: (__int64)v83, a2: v75, a3: (__int64)&v83[v85]); /*0x102cff49c*/
                        v83 += 1024; /*0x102cff4a1*/
                        --v84; /*0x102cff4a8*/
                      }
                      while ( v84 != 0 ); /*0x102cff4ab*/
                      v86 = v177; /*0x102cff4ad*/
                      v87 = v176; /*0x102cff4b4*/
                      do /*0x102cff4cd*/
                      {
                        ossl_ml_dsa_poly_ntt_inverse(a1: v86); /*0x102cff4be*/
                        v86 += 1024; /*0x102cff4c3*/
                        --v87; /*0x102cff4ca*/
                      }
                      while ( v87 != 0 ); /*0x102cff4cd*/
                      v82 = v153; /*0x102cff4cf*/
                    }
                    if ( v76 != 0 ) /*0x102cff4d9*/
                    {
                      v88 = v178; /*0x102cff4db*/
                      v89 = v169; /*0x102cff4e2*/
                      v90 = 0; /*0x102cff4e9*/
                      do /*0x102cff54a*/
                      {
                        for ( ii = 0; ii != 256; ++ii ) /*0x102cff4eb*/
                        {
                          v92 = v88[ii] + v89[ii] - 8380417; /*0x102cff4fe*/
                          *(_DWORD *)&v82[4 * ii] = (v88[ii] + v89[ii]) & ((v92 & ~(v88[ii] + v89[ii])) >> 31) /*0x102cff520*/
                                                  | v92 & ~((v92 & ~(v88[ii] + v89[ii])) >> 31);
                        }
                        ++v90; /*0x102cff530*/
                        v82 += 1024; /*0x102cff533*/
                        v88 += 256; /*0x102cff53a*/
                        v89 += 256; /*0x102cff540*/
                      }
                      while ( v90 != v76 ); /*0x102cff54a*/
                    }
                    v93 = v173; /*0x102cff54c*/
                    if ( v173 != 0 ) /*0x102cff556*/
                    {
                      v94 = (__int64)v172; /*0x102cff55c*/
                      v95 = v184; /*0x102cff563*/
                      v96 = v177; /*0x102cff56a*/
                      v97 = 0; /*0x102cff571*/
                      do /*0x102cff5d6*/
                      {
                        for ( jj = 0; jj != 256; ++jj ) /*0x102cff573*/
                        {
                          v99 = *(_DWORD *)(v94 + 4 * jj) - *(_DWORD *)(v96 + 4 * jj); /*0x102cff584*/
                          *(_DWORD *)&v95[4 * jj] = (v99 + 8380417) & ((v99 & ~(v99 + 8380417)) >> 31) /*0x102cff5ab*/
                                                  | v99 & ~((v99 & ~(v99 + 8380417)) >> 31);
                        }
                        ++v97; /*0x102cff5bb*/
                        v95 += 1024; /*0x102cff5be*/
                        v96 += 1024; /*0x102cff5c5*/
                        v94 += 1024; /*0x102cff5cc*/
                      }
                      while ( v97 != v93 ); /*0x102cff5d6*/
                    }
                    if ( v185 != 0 ) /*0x102cff5e0*/
                    {
                      v100 = 0; /*0x102cff5e2*/
                      for ( kk = 0; kk < v185; ++kk ) /*0x102cff5e4*/
                      {
                        v102 = &v184[v100]; /*0x102cff5ee*/
                        v103 = 0; /*0x102cff5f1*/
                        v104 = (int)v188; /*0x102cff5f4*/
                        do /*0x102cff61a*/
                        {
                          *(_DWORD *)&v102[4 * v103] = ossl_ml_dsa_key_compress_low_bits( /*0x102cff60c*/
                                                         a1: *(_DWORD *)&v102[4 * v103],
                                                         a2: v104);
                          ++v103; /*0x102cff610*/
                        }
                        while ( v103 != 256 ); /*0x102cff61a*/
                        v105 = v185; /*0x102cff61f*/
                        v100 += 1024; /*0x102cff626*/
                      }
                    }
                    else
                    {
                      v105 = 0; /*0x102cff634*/
                    }
                    v167 = v153; /*0x102cff63d*/
                    v106 = 0; /*0x102cff64b*/
                    v107 = 0; /*0x102cff64d*/
                    v108 = v166; /*0x102cff655*/
                    v51 = v181; /*0x102cff663*/
                    if ( v154 != 0 ) /*0x102cff66a*/
                    {
                      v109 = 0; /*0x102cff66c*/
                      v110 = v167; /*0x102cff66e*/
                      v107 = 0; /*0x102cff675*/
                      do /*0x102cff6e7*/
                      {
                        for ( mm = 0; mm != 256; ++mm ) /*0x102cff677*/
                        {
                          v112 = *(_DWORD *)&v110[4 * mm]; /*0x102cff680*/
                          v113 = (8380417 - v112) & ((v112 | (4190208 - v112)) >> 31) /*0x102cff6a8*/
                               | v112 & ~((v112 | (4190208 - v112)) >> 31);
                          v107 = v113 & ((v107 ^ (v107 ^ v113 | v113 ^ (v107 - v113))) >> 31) /*0x102cff6cb*/
                               | ~((v107 ^ (v107 ^ v113 | v113 ^ (v107 - v113))) >> 31) & v107;
                        }
                        ++v109; /*0x102cff6da*/
                        v110 += 1024; /*0x102cff6dd*/
                      }
                      while ( v109 != v154 ); /*0x102cff6e7*/
                    }
                    if ( v105 != 0 ) /*0x102cff6f2*/
                    {
                      v114 = v184; /*0x102cff6f4*/
                      v115 = 0; /*0x102cff6fb*/
                      v106 = 0; /*0x102cff6fd*/
                      do /*0x102cff771*/
                      {
                        for ( nn = 0; nn != 256; ++nn ) /*0x102cff6ff*/
                        {
                          v117 = *(_DWORD *)&v114[4 * nn] & (~*(_DWORD *)&v114[4 * nn] >> 31) /*0x102cff72d*/
                               | -*(_DWORD *)&v114[4 * nn] & ~(~*(_DWORD *)&v114[4 * nn] >> 31);
                          v106 = v117 & ((v106 ^ (v106 ^ v117 | v117 ^ (v106 - v117))) >> 31) /*0x102cff755*/
                               | ~((v106 ^ (v106 ^ v117 | v117 ^ (v106 - v117))) >> 31) & v106;
                        }
                        ++v115; /*0x102cff764*/
                        v114 += 1024; /*0x102cff767*/
                      }
                      while ( v115 != v105 ); /*0x102cff771*/
                    }
                    v118 = v165[13]; /*0x102cff77a*/
                    if ( ((v107 /*0x102cff7b0*/
                         ^ (v107 ^ (v180 - v118) | (v180 - v118) ^ (v107 - (v180 - v118))))
                        & (v106
                         ^ (v106 ^ ((_DWORD)v188 - v118) | ((_DWORD)v188 - v118) ^ (v106 - ((_DWORD)v188 - v118))))
                        & 0x80000000) != 0LL )
                    {
                      v119 = v163; /*0x102cff7b9*/
                      v120 = v152; /*0x102cff7c0*/
                      if ( v176 != 0 ) /*0x102cff7c7*/
                      {
                        v121 = 0; /*0x102cff7c9*/
                        do /*0x102cff7eb*/
                        {
                          ossl_ml_dsa_poly_ntt_mult(a1: (__int64)&v120[v121], a2: v108, a3: (__int64)&v184[v121]); /*0x102cff7dc*/
                          v121 += 1024; /*0x102cff7e1*/
                        }
                        while ( v119 != v121 ); /*0x102cff7eb*/
                        v105 = v185; /*0x102cff7ed*/
                      }
                      if ( v105 != 0 ) /*0x102cff7f7*/
                      {
                        v122 = 0; /*0x102cff7f9*/
                        v123 = 0; /*0x102cff7fb*/
                        do /*0x102cff821*/
                        {
                          ossl_ml_dsa_poly_ntt_inverse(a1: (__int64)&v184[v122]); /*0x102cff808*/
                          ++v123; /*0x102cff80d*/
                          v124 = v185; /*0x102cff810*/
                          v122 += 1024; /*0x102cff817*/
                        }
                        while ( v123 < v185 ); /*0x102cff821*/
                      }
                      else
                      {
                        v124 = 0; /*0x102cff825*/
                      }
                      v125 = v156; /*0x102cff827*/
                      if ( v156 != 0 ) /*0x102cff831*/
                      {
                        v126 = v155; /*0x102cff837*/
                        v127 = v177; /*0x102cff83e*/
                        v128 = 0; /*0x102cff845*/
                        v129 = 0; /*0x102cff847*/
                        v150 = v156; /*0x102cff849*/
                        do /*0x102cff8ec*/
                        {
                          v148 = v129; /*0x102cff850*/
                          __n = (size_t)&v172[v128]; /*0x102cff861*/
                          v189 = v128; /*0x102cff86f*/
                          v130 = &v184[v128]; /*0x102cff876*/
                          v131 = 0; /*0x102cff879*/
                          v132 = (int)v188; /*0x102cff87c*/
                          do /*0x102cff8ba*/
                          {
                            v126->i32[v131] = ossl_ml_dsa_key_compress_make_hint( /*0x102cff8ac*/
                                                a1: *(_DWORD *)&v130[4 * v131],
                                                a2: *(_DWORD *)(v127 + 4 * v131),
                                                a3: v132,
                                                a4: *(_DWORD *)(__n + 4 * v131));
                            ++v131; /*0x102cff8b0*/
                          }
                          while ( v131 != 256 ); /*0x102cff8ba*/
                          v129 = v148 + 1; /*0x102cff8c3*/
                          v126 += 64; /*0x102cff8c6*/
                          v128 = v189 + 1024; /*0x102cff8d4*/
                          v127 += 1024; /*0x102cff8db*/
                          v125 = v150; /*0x102cff8e2*/
                        }
                        while ( v148 + 1 != v150 ); /*0x102cff8ec*/
                        v124 = v185; /*0x102cff8f2*/
                        v51 = v181; /*0x102cff8f9*/
                      }
                      v133 = 0; /*0x102cff900*/
                      v134 = 0; /*0x102cff902*/
                      if ( v124 != 0 ) /*0x102cff90a*/
                      {
                        v135 = v184; /*0x102cff910*/
                        v136 = 0; /*0x102cff917*/
                        v134 = 0; /*0x102cff919*/
                        do /*0x102cff98d*/
                        {
                          for ( i1 = 0; i1 != 256; ++i1 ) /*0x102cff91b*/
                          {
                            v138 = *(_DWORD *)&v135[4 * i1]; /*0x102cff920*/
                            v139 = (8380417 - v138) & ((v138 | (4190208 - v138)) >> 31) /*0x102cff949*/
                                 | v138 & ~((v138 | (4190208 - v138)) >> 31);
                            v134 = v139 & ((v134 ^ (v134 ^ v139 | v139 ^ (v134 - v139))) >> 31) /*0x102cff971*/
                                 | ~((v134 ^ (v134 ^ v139 | v139 ^ (v134 - v139))) >> 31) & v134;
                          }
                          ++v136; /*0x102cff980*/
                          v135 += 1024; /*0x102cff983*/
                        }
                        while ( v136 != v124 ); /*0x102cff98d*/
                      }
                      if ( v125 != 0 ) /*0x102cff992*/
                      {
                        v140 = v155 + 63; /*0x102cff99f*/
                        v133 = 0; /*0x102cff9a6*/
                        do /*0x102cffcb0*/
                        {
                          v141 = _mm_add_epi32( /*0x102cffc7c*/
                                   _mm_add_epi32(
                                     _mm_loadu_si128(v140 - 1),
                                     _mm_add_epi32(
                                       _mm_loadu_si128(v140 - 3),
                                       _mm_add_epi32(_mm_loadu_si128(v140 - 5), _mm_loadu_si128(v140 - 7)))),
                                   _mm_add_epi32(
                                     _mm_add_epi32(
                                       _mm_loadu_si128(v140 - 9),
                                       _mm_add_epi32(
                                         _mm_loadu_si128(v140 - 11),
                                         _mm_add_epi32(
                                           _mm_loadu_si128(v140 - 13),
                                           _mm_add_epi32(
                                             _mm_loadu_si128(v140 - 15),
                                             _mm_add_epi32(
                                               _mm_loadu_si128(v140 - 17),
                                               _mm_add_epi32(_mm_loadu_si128(v140 - 19), _mm_loadu_si128(v140 - 21))))))),
                                     _mm_add_epi32(
                                       _mm_add_epi32(
                                         _mm_loadu_si128(v140 - 23),
                                         _mm_add_epi32(
                                           _mm_loadu_si128(v140 - 25),
                                           _mm_add_epi32(
                                             _mm_loadu_si128(v140 - 27),
                                             _mm_add_epi32(
                                               _mm_loadu_si128(v140 - 29),
                                               _mm_add_epi32(_mm_loadu_si128(v140 - 31), _mm_loadu_si128(v140 - 33)))))),
                                       _mm_add_epi32(
                                         _mm_add_epi32(
                                           _mm_loadu_si128(v140 - 35),
                                           _mm_add_epi32(
                                             _mm_loadu_si128(v140 - 37),
                                             _mm_add_epi32(
                                               _mm_loadu_si128(v140 - 39),
                                               _mm_add_epi32(_mm_loadu_si128(v140 - 41), _mm_loadu_si128(v140 - 43))))),
                                         _mm_add_epi32(
                                           _mm_add_epi32(
                                             _mm_loadu_si128(v140 - 45),
                                             _mm_add_epi32(
                                               _mm_loadu_si128(v140 - 47),
                                               _mm_add_epi32(_mm_loadu_si128(v140 - 49), _mm_loadu_si128(v140 - 51)))),
                                           _mm_add_epi32(
                                             _mm_add_epi32(
                                               _mm_loadu_si128(v140 - 53),
                                               _mm_add_epi32(_mm_loadu_si128(v140 - 55), _mm_loadu_si128(v140 - 57))),
                                             _mm_add_epi32(
                                               _mm_add_epi32(_mm_loadu_si128(v140 - 59), _mm_loadu_si128(v140 - 61)),
                                               _mm_add_epi32(_mm_loadu_si128(v140 - 63), _mm_cvtsi32_si128(v133)))))))));
                          v142 = _mm_add_epi32( /*0x102cffc8c*/
                                   _mm_add_epi32(
                                     _mm_add_epi32(
                                       _mm_loadu_si128(v140),
                                       _mm_add_epi32(_mm_loadu_si128(v140 - 2), _mm_loadu_si128(v140 - 4))),
                                     _mm_add_epi32(
                                       _mm_add_epi32(
                                         _mm_loadu_si128(v140 - 6),
                                         _mm_add_epi32(
                                           _mm_loadu_si128(v140 - 8),
                                           _mm_add_epi32(
                                             _mm_loadu_si128(v140 - 10),
                                             _mm_add_epi32(
                                               _mm_loadu_si128(v140 - 12),
                                               _mm_add_epi32(
                                                 _mm_loadu_si128(v140 - 14),
                                                 _mm_add_epi32(_mm_loadu_si128(v140 - 16), _mm_loadu_si128(v140 - 18))))))),
                                       _mm_add_epi32(
                                         _mm_add_epi32(
                                           _mm_loadu_si128(v140 - 20),
                                           _mm_add_epi32(
                                             _mm_loadu_si128(v140 - 22),
                                             _mm_add_epi32(
                                               _mm_loadu_si128(v140 - 24),
                                               _mm_add_epi32(
                                                 _mm_loadu_si128(v140 - 26),
                                                 _mm_add_epi32(_mm_loadu_si128(v140 - 28), _mm_loadu_si128(v140 - 30)))))),
                                         _mm_add_epi32(
                                           _mm_add_epi32(
                                             _mm_loadu_si128(v140 - 32),
                                             _mm_add_epi32(
                                               _mm_loadu_si128(v140 - 34),
                                               _mm_add_epi32(
                                                 _mm_loadu_si128(v140 - 36),
                                                 _mm_add_epi32(_mm_loadu_si128(v140 - 38), _mm_loadu_si128(v140 - 40))))),
                                           _mm_add_epi32(
                                             _mm_add_epi32(
                                               _mm_loadu_si128(v140 - 42),
                                               _mm_add_epi32(
                                                 _mm_loadu_si128(v140 - 44),
                                                 _mm_add_epi32(_mm_loadu_si128(v140 - 46), _mm_loadu_si128(v140 - 48)))),
                                             _mm_add_epi32(
                                               _mm_add_epi32(
                                                 _mm_loadu_si128(v140 - 50),
                                                 _mm_add_epi32(_mm_loadu_si128(v140 - 52), _mm_loadu_si128(v140 - 54))),
                                               _mm_add_epi32(
                                                 _mm_add_epi32(_mm_loadu_si128(v140 - 56), _mm_loadu_si128(v140 - 58)),
                                                 _mm_add_epi32(_mm_loadu_si128(v140 - 60), _mm_loadu_si128(v140 - 62))))))))),
                                   v141);
                          v143 = _mm_add_epi32(_mm_shuffle_epi32(v142, 238), v142); /*0x102cffc95*/
                          v133 = _mm_cvtsi128_si32(_mm_add_epi32(_mm_shuffle_epi32(v143, 85), v143)); /*0x102cffca2*/
                          v140 += 64; /*0x102cffca6*/
                          --v125; /*0x102cffcad*/
                        }
                        while ( v125 != 0 ); /*0x102cffcb0*/
                      }
                      v52 = (int)(v165[14] ^ (v133 ^ v165[14] | v133 ^ (v165[14] - v133))) >> 31; /*0x102cff11a*/
                      if ( ((v134 /*0x102cff126*/
                           ^ ((unsigned int)v188 ^ v134 | (unsigned int)v188 ^ (v134 - (_DWORD)v188)))
                          & 0x80000000) == 0 )
                        v52 = -1; /*0x102cff126*/
                      if ( v52 == 0 ) /*0x102cff12d*/
                      {
                        v189 = ossl_ml_dsa_sig_encode(a1: &v153, a2: (__int64)v165, a3: a10); /*0x102cffccb*/
                        v36 = ctx; /*0x102cffcd2*/
                        break; /*0x102cffcd9*/
                      }
                    }
                    v50 = v51 + v162; /*0x102cff13a*/
                    v49 = v160 + v161; /*0x102cff144*/
                  }
                }
              }
            }
          }
        }
      }
      else
      {
        v36 = nullptr; /*0x102cfef69*/
      }
      EVP_MD_CTX_free(ctx: v36); /*0x102cfef6c*/
      CRYPTO_clear_free(a1: v174, a2: v147); /*0x102cfef8e*/
      OPENSSL_cleanse(&ptr, len: 0x40u); /*0x102cfef9f*/
LABEL_42:
      CRYPTO_free(a1: v159); /*0x102cfefa4*/
      v16 = v189; /*0x102cfefc3*/
      v15 = v186; /*0x102cfefc5*/
      v18 = a11; /*0x102cfefcc*/
      if ( a11 != nullptr ) /*0x102cfefd3*/
LABEL_43:
        *v18 = *(_QWORD *)(*(_QWORD *)(v15 + 8) + 80LL); /*0x102cfefd5*/
    }
  }
  return v16; /*0x102cfeff6*/
}

// Address: 0x102cffcf0 | Name: _ossl_ml_dsa_verify
__int64 __fastcall ossl_ml_dsa_verify(
        __int64 a1,
        int a2,
        _BYTE *a3,
        size_t a4,
        const void *a5,
        size_t a6,
        int a7,
        char *a8,
        __int64 a9)
{
  __int64 v13; // r13
  unsigned int v14; // r14d
  _BYTE *v15; // r13
  void *v16; // rcx
  __int64 v17; // rcx
  __int64 v18; // r15
  __int64 v19; // r14
  int v20; // edx
  __int64 v21; // rsi
  unsigned __int64 v22; // r13
  __int64 v23; // r14
  int v24; // ebx
  size_t v25; // rdi
  __int64 v26; // rbx
  char *v27; // r15
  __int64 v28; // r15
  __int64 v29; // r13
  EVP_MD_CTX *v30; // r12
  int v31; // eax
  unsigned __int64 v32; // r12
  __int64 v33; // r15
  __int64 v34; // rax
  __int64 v35; // rcx
  char *v36; // r14
  __int64 v37; // rdx
  char *v38; // rsi
  __int64 i; // rdi
  const __m128i *v41; // r9
  __m128i *v42; // r8
  __m128i v43; // xmm1
  __m128i v44; // xmm1
  __m128i v45; // xmm1
  __m128i v46; // xmm1
  __m128i v47; // xmm1
  __m128i v48; // xmm1
  __m128i v49; // xmm1
  __m128i v50; // xmm1
  __m128i v51; // xmm1
  __m128i v52; // xmm1
  __m128i v53; // xmm1
  __m128i v54; // xmm1
  __m128i v55; // xmm1
  __m128i v56; // xmm1
  __m128i v57; // xmm1
  __m128i v58; // xmm1
  __m128i v59; // xmm1
  __m128i v60; // xmm1
  __m128i v61; // xmm1
  __m128i v62; // xmm1
  __m128i v63; // xmm1
  __m128i v64; // xmm1
  __m128i v65; // xmm1
  __m128i v66; // xmm1
  __m128i v67; // xmm1
  __m128i v68; // xmm1
  __m128i v69; // xmm1
  __m128i v70; // xmm1
  __m128i v71; // xmm1
  __m128i v72; // xmm1
  __m128i v73; // xmm1
  __m128i v74; // xmm1
  __int64 j; // r8
  unsigned __int64 v76; // r13
  __int64 v77; // r12
  __int64 v78; // r14
  unsigned __int64 k; // rbx
  __int64 v80; // r14
  char *v81; // rcx
  __int64 v82; // rdx
  unsigned int v83; // r14d
  __int64 m; // rsi
  int v85; // r8d
  int v86; // edi
  __int64 v87; // rbx
  unsigned __int64 n; // r12
  unsigned __int64 v89; // rax
  int v90; // edx
  __int64 v91; // rcx
  __int64 v92; // rdx
  __int64 ii; // rsi
  int v94; // edi
  __int64 v95; // r15
  unsigned __int64 v96; // rbx
  __int64 v97; // r15
  _BOOL8 v98; // rax
  __int64 v99; // r13
  char *v100; // rbx
  __int64 jj; // r12
  int v102; // eax
  __int64 v103; // [rsp+0h] [rbp-5D0h] BYREF
  unsigned __int64 v104; // [rsp+8h] [rbp-5C8h]
  unsigned __int64 v105; // [rsp+10h] [rbp-5C0h]
  unsigned __int64 v106; // [rsp+18h] [rbp-5B8h]
  __int64 v107; // [rsp+20h] [rbp-5B0h]
  char *v108; // [rsp+28h] [rbp-5A8h] BYREF
  unsigned __int64 v109; // [rsp+30h] [rbp-5A0h]
  char *v110; // [rsp+38h] [rbp-598h]
  unsigned __int64 v111; // [rsp+40h] [rbp-590h]
  void *__s2; // [rsp+48h] [rbp-588h]
  size_t v113; // [rsp+50h] [rbp-580h]
  void *v114; // [rsp+58h] [rbp-578h]
  __int64 v115; // [rsp+60h] [rbp-570h]
  int *v116; // [rsp+68h] [rbp-568h]
  unsigned __int64 v117; // [rsp+70h] [rbp-560h]
  size_t v118; // [rsp+78h] [rbp-558h]
  int v119; // [rsp+84h] [rbp-54Ch]
  __int64 v120; // [rsp+88h] [rbp-548h]
  __int64 v121; // [rsp+90h] [rbp-540h]
  __int64 v122; // [rsp+98h] [rbp-538h] BYREF
  unsigned __int64 v123; // [rsp+A0h] [rbp-530h]
  size_t cnt; // [rsp+A8h] [rbp-528h]
  size_t v125; // [rsp+B0h] [rbp-520h]
  size_t __n; // [rsp+B8h] [rbp-518h]
  void *d; // [rsp+C0h] [rbp-510h]
  void *__src; // [rsp+C8h] [rbp-508h]
  EVP_MD_CTX *ctx; // [rsp+D0h] [rbp-500h]
  _BOOL8 v130; // [rsp+D8h] [rbp-4F8h]
  _BYTE v131[1024]; // [rsp+E0h] [rbp-4F0h] BYREF
  _BYTE v132[64]; // [rsp+4E0h] [rbp-F0h] BYREF
  _BYTE __s1[64]; // [rsp+520h] [rbp-B0h] BYREF
  _BYTE v134[64]; // [rsp+560h] [rbp-70h] BYREF

  __n = a4; /*0x102cffd0a*/
  v13 = a1; /*0x102cffd17*/
  if ( ossl_ml_dsa_key_get_pub(a1) == 0 ) /*0x102cffd30*/
    return 0; /*0x102cffdc8*/
  v120 = v13; /*0x102cffd39*/
  if ( a2 != 0 ) /*0x102cffd40*/
  {
    v130 = false; /*0x102cffd42*/
    __src = a3; /*0x102cffd4d*/
    v114 = nullptr; /*0x102cffd54*/
    goto LABEL_17; /*0x102cffd5f*/
  }
  if ( a7 == 0 ) /*0x102cffd68*/
  {
    v130 = false; /*0x102cffdb2*/
    v15 = a3; /*0x102cffdbd*/
    if ( a3 != nullptr ) /*0x102cffdc3*/
    {
LABEL_12:
      v16 = nullptr; /*0x102cffe3e*/
      if ( v15 != v131 ) /*0x102cffe4f*/
        v16 = v15; /*0x102cffe4f*/
      if ( v15 == a3 ) /*0x102cffe56*/
        v16 = nullptr; /*0x102cffe56*/
      v114 = v16; /*0x102cffe5a*/
      __src = v15; /*0x102cffe61*/
      v13 = v120; /*0x102cffe68*/
LABEL_17:
      v17 = *(_QWORD *)(v13 + 8); /*0x102cffe6f*/
      v18 = *(_QWORD *)(v17 + 32); /*0x102cffe73*/
      v19 = *(_QWORD *)(v17 + 40); /*0x102cffe77*/
      v20 = *(_DWORD *)(v17 + 24); /*0x102cffe7b*/
      v21 = (unsigned int)(v19 + v18); /*0x102cffe7e*/
      v22 = (unsigned int)v19; /*0x102cffe86*/
      v23 = (unsigned int)(v18 * v19); /*0x102cffe89*/
      v116 = (int *)v17; /*0x102cffe8d*/
      v24 = *(_DWORD *)(v17 + 16); /*0x102cffe94*/
      LODWORD(v125) = v20; /*0x102cffe99*/
      v115 = v21; /*0x102cffeb5*/
      cnt = (unsigned int)v18 * (((v20 == 95232) | 2) << 6); /*0x102cffec6*/
      d = CRYPTO_malloc( /*0x102cffee9*/
            num: (((int)v23 + (int)v21 + (int)v22 + 2 * (int)v18) << 10) + (int)cnt + 1024,
            file: "crypto/ml_dsa/ml_dsa_sign.c",
            line: 240);
      if ( d == nullptr ) /*0x102cffef3*/
      {
LABEL_28:
        CRYPTO_free(a1: v114); /*0x102d00130*/
        return v130; /*0x102d0014f*/
      }
      v130 = false; /*0x102cffefe*/
      ctx = (EVP_MD_CTX *)EVP_MD_CTX_new(); /*0x102cfff09*/
      if ( ctx == nullptr ) /*0x102cfff13*/
        goto LABEL_26; /*0x102cfff13*/
      v119 = v24 >> 2; /*0x102cfff24*/
      v25 = v24 >> 2; /*0x102cfff2a*/
      v104 = (unsigned int)v18; /*0x102cfff4a*/
      v105 = v22; /*0x102cfff51*/
      v103 = (__int64)d + cnt + 1024; /*0x102cfff58*/
      v26 = v23 << 10; /*0x102cfff62*/
      v121 = (__int64)d + cnt; /*0x102cfff66*/
      v27 = (char *)d + 1024 * v23 + cnt + 1024; /*0x102cfff71*/
      v106 = v104 << 10; /*0x102cfff7f*/
      v108 = &v27[1024 * v104]; /*0x102cfff89*/
      v109 = v22; /*0x102cfff90*/
      v110 = v27; /*0x102cfff97*/
      v111 = v104; /*0x102cfff9e*/
      __s2 = v132; /*0x102cfffac*/
      v118 = v25; /*0x102cfffb3*/
      v113 = v25; /*0x102cfffba*/
      v107 = v115 << 10; /*0x102cfffcc*/
      v28 = (__int64)&v27[1024 * v115]; /*0x102cfffd3*/
      v122 = v28; /*0x102cfffd6*/
      v117 = v104; /*0x102cfffdd*/
      v123 = v104; /*0x102cfffe4*/
      v29 = v120; /*0x102cfffeb*/
      if ( !ossl_ml_dsa_sig_decode(a1: (__int64)&v108, a2: a8, a3: a9, a4: *(_QWORD *)(v120 + 8)) ) /*0x102cffffd*/
        goto LABEL_26; /*0x102cffffd*/
      if ( (unsigned int)ossl_ml_dsa_matrix_expand_A( /*0x102d00027*/
                           ctx,
                           a2: *(_QWORD *)(v29 + 16),
                           a3: (__int128 *)(v29 + 32),
                           a4: &v103) != 0 )
      {
        if ( a2 != 0 ) /*0x102d00030*/
        {
          v30 = ctx; /*0x102d0003e*/
          if ( __n == 64 ) /*0x102d00045*/
            goto LABEL_23; /*0x102d00045*/
        }
        else
        {
          v130 = false; /*0x102d00789*/
          v30 = ctx; /*0x102d00794*/
          if ( (unsigned int)EVP_DigestInit_ex2(a1: ctx) != 0 /*0x102d007de*/
            && EVP_DigestUpdate(ctx: v30, d: (const void *)(v29 + 64), cnt: 0x40u) != 0
            && EVP_DigestUpdate(ctx: v30, d: __src, cnt: __n) != 0 )
          {
            __src = v134; /*0x102d007f0*/
            if ( (unsigned int)EVP_DigestSqueeze(a1: (__int64)v30, a2: (__int64)v134, a3: 64) != 0 ) /*0x102d007fe*/
            {
LABEL_23:
              v31 = ossl_ml_dsa_poly_sample_in_ball( /*0x102d0004b*/
                      a1: v121,
                      a2: v132,
                      a3: v119,
                      a4: v30,
                      a5: *(_QWORD *)(v29 + 24),
                      a6: v116[3]);
              v130 = false; /*0x102d0007b*/
              if ( v31 != 0 ) /*0x102d00084*/
              {
                v32 = v106; /*0x102d0008a*/
                v33 = v106 + v28; /*0x102d00091*/
                ossl_ml_dsa_poly_ntt(a1: v121); /*0x102d0009b*/
                v34 = *(_QWORD *)(v29 + 200); /*0x102d000a0*/
                if ( v34 != 0 ) /*0x102d000aa*/
                {
                  v35 = *(_QWORD *)(v29 + 192); /*0x102d000b0*/
                  v36 = (char *)d + 1024 * v115 + 1024 * v117 + 1024 * v23 + cnt - v35 + 1024; /*0x102d000e0*/
                  v37 = v35 + 12; /*0x102d000e7*/
                  v38 = (char *)d + cnt + v26 + v107 + v32 + 1036; /*0x102d000fb*/
                  for ( i = 0; i != v34; ++i ) /*0x102d00102*/
                  {
                    if ( (unsigned __int64)v36 > 0x1F ) /*0x102d00735*/
                    {
                      v41 = (const __m128i *)(v35 + (i << 10)); /*0x102d00182*/
                      v42 = (__m128i *)(v33 + (i << 10)); /*0x102d00186*/
                      v43 = _mm_slli_epi32(_mm_loadu_si128(v41 + 1), 0xDu); /*0x102d00199*/
                      *v42 = _mm_slli_epi32(_mm_loadu_si128(v41), 0xDu); /*0x102d0019e*/
                      v42[1] = v43; /*0x102d001a3*/
                      v44 = _mm_slli_epi32(_mm_loadu_si128(v41 + 3), 0xDu); /*0x102d001ba*/
                      v42[2] = _mm_slli_epi32(_mm_loadu_si128(v41 + 2), 0xDu); /*0x102d001bf*/
                      v42[3] = v44; /*0x102d001c5*/
                      v45 = _mm_slli_epi32(_mm_loadu_si128(v41 + 5), 0xDu); /*0x102d001dc*/
                      v42[4] = _mm_slli_epi32(_mm_loadu_si128(v41 + 4), 0xDu); /*0x102d001e1*/
                      v42[5] = v45; /*0x102d001e7*/
                      v46 = _mm_slli_epi32(_mm_loadu_si128(v41 + 7), 0xDu); /*0x102d001fe*/
                      v42[6] = _mm_slli_epi32(_mm_loadu_si128(v41 + 6), 0xDu); /*0x102d00203*/
                      v42[7] = v46; /*0x102d00209*/
                      v47 = _mm_slli_epi32(_mm_loadu_si128(v41 + 9), 0xDu); /*0x102d00226*/
                      v42[8] = _mm_slli_epi32(_mm_loadu_si128(v41 + 8), 0xDu); /*0x102d0022b*/
                      v42[9] = v47; /*0x102d00234*/
                      v48 = _mm_slli_epi32(_mm_loadu_si128(v41 + 11), 0xDu); /*0x102d00254*/
                      v42[10] = _mm_slli_epi32(_mm_loadu_si128(v41 + 10), 0xDu); /*0x102d00259*/
                      v42[11] = v48; /*0x102d00262*/
                      v49 = _mm_slli_epi32(_mm_loadu_si128(v41 + 13), 0xDu); /*0x102d00282*/
                      v42[12] = _mm_slli_epi32(_mm_loadu_si128(v41 + 12), 0xDu); /*0x102d00287*/
                      v42[13] = v49; /*0x102d00290*/
                      v50 = _mm_slli_epi32(_mm_loadu_si128(v41 + 15), 0xDu); /*0x102d002b0*/
                      v42[14] = _mm_slli_epi32(_mm_loadu_si128(v41 + 14), 0xDu); /*0x102d002b5*/
                      v42[15] = v50; /*0x102d002be*/
                      v51 = _mm_slli_epi32(_mm_loadu_si128(v41 + 17), 0xDu); /*0x102d002de*/
                      v42[16] = _mm_slli_epi32(_mm_loadu_si128(v41 + 16), 0xDu); /*0x102d002e3*/
                      v42[17] = v51; /*0x102d002ec*/
                      v52 = _mm_slli_epi32(_mm_loadu_si128(v41 + 19), 0xDu); /*0x102d0030c*/
                      v42[18] = _mm_slli_epi32(_mm_loadu_si128(v41 + 18), 0xDu); /*0x102d00311*/
                      v42[19] = v52; /*0x102d0031a*/
                      v53 = _mm_slli_epi32(_mm_loadu_si128(v41 + 21), 0xDu); /*0x102d0033a*/
                      v42[20] = _mm_slli_epi32(_mm_loadu_si128(v41 + 20), 0xDu); /*0x102d0033f*/
                      v42[21] = v53; /*0x102d00348*/
                      v54 = _mm_slli_epi32(_mm_loadu_si128(v41 + 23), 0xDu); /*0x102d00368*/
                      v42[22] = _mm_slli_epi32(_mm_loadu_si128(v41 + 22), 0xDu); /*0x102d0036d*/
                      v42[23] = v54; /*0x102d00376*/
                      v55 = _mm_slli_epi32(_mm_loadu_si128(v41 + 25), 0xDu); /*0x102d00396*/
                      v42[24] = _mm_slli_epi32(_mm_loadu_si128(v41 + 24), 0xDu); /*0x102d0039b*/
                      v42[25] = v55; /*0x102d003a4*/
                      v56 = _mm_slli_epi32(_mm_loadu_si128(v41 + 27), 0xDu); /*0x102d003c4*/
                      v42[26] = _mm_slli_epi32(_mm_loadu_si128(v41 + 26), 0xDu); /*0x102d003c9*/
                      v42[27] = v56; /*0x102d003d2*/
                      v57 = _mm_slli_epi32(_mm_loadu_si128(v41 + 29), 0xDu); /*0x102d003f2*/
                      v42[28] = _mm_slli_epi32(_mm_loadu_si128(v41 + 28), 0xDu); /*0x102d003f7*/
                      v42[29] = v57; /*0x102d00400*/
                      v58 = _mm_slli_epi32(_mm_loadu_si128(v41 + 31), 0xDu); /*0x102d00420*/
                      v42[30] = _mm_slli_epi32(_mm_loadu_si128(v41 + 30), 0xDu); /*0x102d00425*/
                      v42[31] = v58; /*0x102d0042e*/
                      v59 = _mm_slli_epi32(_mm_loadu_si128(v41 + 33), 0xDu); /*0x102d0044e*/
                      v42[32] = _mm_slli_epi32(_mm_loadu_si128(v41 + 32), 0xDu); /*0x102d00453*/
                      v42[33] = v59; /*0x102d0045c*/
                      v60 = _mm_slli_epi32(_mm_loadu_si128(v41 + 35), 0xDu); /*0x102d0047c*/
                      v42[34] = _mm_slli_epi32(_mm_loadu_si128(v41 + 34), 0xDu); /*0x102d00481*/
                      v42[35] = v60; /*0x102d0048a*/
                      v61 = _mm_slli_epi32(_mm_loadu_si128(v41 + 37), 0xDu); /*0x102d004aa*/
                      v42[36] = _mm_slli_epi32(_mm_loadu_si128(v41 + 36), 0xDu); /*0x102d004af*/
                      v42[37] = v61; /*0x102d004b8*/
                      v62 = _mm_slli_epi32(_mm_loadu_si128(v41 + 39), 0xDu); /*0x102d004d8*/
                      v42[38] = _mm_slli_epi32(_mm_loadu_si128(v41 + 38), 0xDu); /*0x102d004dd*/
                      v42[39] = v62; /*0x102d004e6*/
                      v63 = _mm_slli_epi32(_mm_loadu_si128(v41 + 41), 0xDu); /*0x102d00506*/
                      v42[40] = _mm_slli_epi32(_mm_loadu_si128(v41 + 40), 0xDu); /*0x102d0050b*/
                      v42[41] = v63; /*0x102d00514*/
                      v64 = _mm_slli_epi32(_mm_loadu_si128(v41 + 43), 0xDu); /*0x102d00534*/
                      v42[42] = _mm_slli_epi32(_mm_loadu_si128(v41 + 42), 0xDu); /*0x102d00539*/
                      v42[43] = v64; /*0x102d00542*/
                      v65 = _mm_slli_epi32(_mm_loadu_si128(v41 + 45), 0xDu); /*0x102d00562*/
                      v42[44] = _mm_slli_epi32(_mm_loadu_si128(v41 + 44), 0xDu); /*0x102d00567*/
                      v42[45] = v65; /*0x102d00570*/
                      v66 = _mm_slli_epi32(_mm_loadu_si128(v41 + 47), 0xDu); /*0x102d00590*/
                      v42[46] = _mm_slli_epi32(_mm_loadu_si128(v41 + 46), 0xDu); /*0x102d00595*/
                      v42[47] = v66; /*0x102d0059e*/
                      v67 = _mm_slli_epi32(_mm_loadu_si128(v41 + 49), 0xDu); /*0x102d005be*/
                      v42[48] = _mm_slli_epi32(_mm_loadu_si128(v41 + 48), 0xDu); /*0x102d005c3*/
                      v42[49] = v67; /*0x102d005cc*/
                      v68 = _mm_slli_epi32(_mm_loadu_si128(v41 + 51), 0xDu); /*0x102d005ec*/
                      v42[50] = _mm_slli_epi32(_mm_loadu_si128(v41 + 50), 0xDu); /*0x102d005f1*/
                      v42[51] = v68; /*0x102d005fa*/
                      v69 = _mm_slli_epi32(_mm_loadu_si128(v41 + 53), 0xDu); /*0x102d0061a*/
                      v42[52] = _mm_slli_epi32(_mm_loadu_si128(v41 + 52), 0xDu); /*0x102d0061f*/
                      v42[53] = v69; /*0x102d00628*/
                      v70 = _mm_slli_epi32(_mm_loadu_si128(v41 + 55), 0xDu); /*0x102d00648*/
                      v42[54] = _mm_slli_epi32(_mm_loadu_si128(v41 + 54), 0xDu); /*0x102d0064d*/
                      v42[55] = v70; /*0x102d00656*/
                      v71 = _mm_slli_epi32(_mm_loadu_si128(v41 + 57), 0xDu); /*0x102d00676*/
                      v42[56] = _mm_slli_epi32(_mm_loadu_si128(v41 + 56), 0xDu); /*0x102d0067b*/
                      v42[57] = v71; /*0x102d00684*/
                      v72 = _mm_slli_epi32(_mm_loadu_si128(v41 + 59), 0xDu); /*0x102d006a4*/
                      v42[58] = _mm_slli_epi32(_mm_loadu_si128(v41 + 58), 0xDu); /*0x102d006a9*/
                      v42[59] = v72; /*0x102d006b2*/
                      v73 = _mm_slli_epi32(_mm_loadu_si128(v41 + 61), 0xDu); /*0x102d006d2*/
                      v42[60] = _mm_slli_epi32(_mm_loadu_si128(v41 + 60), 0xDu); /*0x102d006d7*/
                      v42[61] = v73; /*0x102d006e0*/
                      v74 = _mm_slli_epi32(_mm_loadu_si128(v41 + 63), 0xDu); /*0x102d00700*/
                      v42[62] = _mm_slli_epi32(_mm_loadu_si128(v41 + 62), 0xDu); /*0x102d00705*/
                      v42[63] = v74; /*0x102d0070e*/
                    }
                    else
                    {
                      for ( j = 0; j != 256; j += 4 ) /*0x102d0073b*/
                      {
                        *(_DWORD *)&v38[4 * j - 12] = *(_DWORD *)(v37 + 4 * j - 12) << 13; /*0x102d00749*/
                        *(_DWORD *)&v38[4 * j - 8] = *(_DWORD *)(v37 + 4 * j - 8) << 13; /*0x102d00757*/
                        *(_DWORD *)&v38[4 * j - 4] = *(_DWORD *)(v37 + 4 * j - 4) << 13; /*0x102d00765*/
                        *(_DWORD *)&v38[4 * j] = *(_DWORD *)(v37 + 4 * j) << 13; /*0x102d00772*/
                      }
                    }
                    v37 += 1024; /*0x102d0071a*/
                    v38 += 1024; /*0x102d00721*/
                  }
                }
                v76 = v117; /*0x102d00809*/
                v77 = v121; /*0x102d00813*/
                if ( v117 != 0 ) /*0x102d0081a*/
                {
                  v78 = v33; /*0x102d0081c*/
                  for ( k = v117; k != 0; --k ) /*0x102d0081f*/
                  {
                    ossl_ml_dsa_poly_ntt(a1: v78); /*0x102d00833*/
                    v78 += 1024; /*0x102d00838*/
                  }
                  v80 = v33; /*0x102d00844*/
                  do /*0x102d00868*/
                  {
                    ossl_ml_dsa_poly_ntt_mult(a1: v80, a2: v77, a3: v80); /*0x102d00859*/
                    v80 += 1024; /*0x102d0085e*/
                    --v76; /*0x102d00865*/
                  }
                  while ( v76 != 0 ); /*0x102d00868*/
                }
                if ( v109 != 0 ) /*0x102d00874*/
                {
                  v81 = v108; /*0x102d0087a*/
                  v82 = 0; /*0x102d00881*/
                  v83 = 0; /*0x102d00883*/
                  do /*0x102d0090a*/
                  {
                    for ( m = 0; m != 256; ++m ) /*0x102d00890*/
                    {
                      v85 = *(_DWORD *)&v81[4 * m]; /*0x102d008a0*/
                      v86 = (8380417 - v85) & ((v85 | (4190208 - v85)) >> 31) | v85 & ~((v85 | (4190208 - v85)) >> 31); /*0x102d008c6*/
                      v83 = v86 & ((int)(v83 ^ (v83 ^ v86 | v86 ^ (v83 - v86))) >> 31) /*0x102d008ee*/
                          | ~((int)(v83 ^ (v83 ^ v86 | v86 ^ (v83 - v86))) >> 31) & v83;
                    }
                    ++v82; /*0x102d008fd*/
                    v81 += 1024; /*0x102d00900*/
                  }
                  while ( v82 != v109 ); /*0x102d0090a*/
                  v87 = 0; /*0x102d0090c*/
                  for ( n = 0; n < v109; ++n ) /*0x102d0090e*/
                  {
                    ossl_ml_dsa_poly_ntt(a1: (__int64)&v108[v87]); /*0x102d0092a*/
                    v87 += 1024; /*0x102d00932*/
                  }
                }
                else
                {
                  v83 = 0; /*0x102d00944*/
                }
                ossl_ml_dsa_matrix_mult_vector(a1: &v103, a2: &v108, a3: &v122); /*0x102d0095c*/
                v89 = v123; /*0x102d00961*/
                v90 = v125; /*0x102d0096b*/
                if ( v123 != 0 ) /*0x102d00971*/
                {
                  v91 = v122; /*0x102d00977*/
                  v92 = 0; /*0x102d0097e*/
                  do /*0x102d009de*/
                  {
                    for ( ii = 0; ii != 256; ++ii ) /*0x102d00980*/
                    {
                      v94 = *(_DWORD *)(v91 + 4 * ii) - *(_DWORD *)(v33 + 4 * ii); /*0x102d00993*/
                      *(_DWORD *)(v91 + 4 * ii) = (v94 + 8380417) & ((v94 & ~(v94 + 8380417)) >> 31) /*0x102d009ba*/
                                                | v94 & ~((v94 & ~(v94 + 8380417)) >> 31);
                    }
                    ++v92; /*0x102d009ca*/
                    v33 += 1024; /*0x102d009cd*/
                    v91 += 1024; /*0x102d009d4*/
                  }
                  while ( v92 != v89 ); /*0x102d009de*/
                  v95 = 0; /*0x102d009e0*/
                  v96 = 0; /*0x102d009e3*/
                  do /*0x102d00a13*/
                  {
                    ossl_ml_dsa_poly_ntt_inverse(a1: v95 + v122); /*0x102d009fa*/
                    ++v96; /*0x102d009ff*/
                    v95 += 1024; /*0x102d00a09*/
                  }
                  while ( v96 < v123 ); /*0x102d00a13*/
                  v90 = v125; /*0x102d00a18*/
                  if ( v123 != 0 ) /*0x102d00a1e*/
                  {
                    v97 = 0; /*0x102d00a20*/
                    v98 = false; /*0x102d00a23*/
                    do /*0x102d00a8d*/
                    {
                      v130 = v98; /*0x102d00a30*/
                      v99 = v97 + v122; /*0x102d00a3e*/
                      v100 = &v110[v97]; /*0x102d00a48*/
                      for ( jj = 0; jj != 256; ++jj ) /*0x102d00a4b*/
                      {
                        v102 = ossl_ml_dsa_key_compress_use_hint( /*0x102d00a59*/
                                 a1: *(_DWORD *)&v100[4 * jj],
                                 a2: *(_DWORD *)(v99 + 4 * jj),
                                 a3: v90);
                        v90 = v125; /*0x102d00a5e*/
                        *(_DWORD *)(v99 + 4 * jj) = v102; /*0x102d00a64*/
                      }
                      v98 = v130 + 1; /*0x102d00a7c*/
                      v97 += 1024; /*0x102d00a7f*/
                    }
                    while ( v130 + 1 < v123 ); /*0x102d00a8d*/
                  }
                }
                ossl_ml_dsa_w1_encode(a1: &v122, a2: v90, a3: (__int64)d, a4: cnt); /*0x102d00aa6*/
                v130 = false; /*0x102d00ab6*/
                v30 = ctx; /*0x102d00ac1*/
                if ( (unsigned int)EVP_DigestInit_ex2(a1: ctx) != 0 /*0x102d00b0e*/
                  && EVP_DigestUpdate(ctx: v30, d: __src, cnt: 0x40u) != 0
                  && EVP_DigestUpdate(ctx: v30, d, cnt) != 0 )
                {
                  v130 = false; /*0x102d00b14*/
                  if ( EVP_DigestUpdate(ctx: v30, d: nullptr, cnt: 0) != 0 /*0x102d00b61*/
                    && (unsigned int)EVP_DigestSqueeze(a1: (__int64)v30, a2: (__int64)__s1, a3: v118) != 0
                    && v83 < v116[5] - v116[13] )
                  {
                    v130 = memcmp(__s1, __s2, __n: v118) == 0; /*0x102d00b88*/
                  }
                }
              }
            }
          }
        }
      }
      else
      {
LABEL_26:
        v30 = ctx; /*0x102d00109*/
      }
      CRYPTO_free(a1: d); /*0x102d00110*/
      EVP_MD_CTX_free(ctx: v30); /*0x102d0012b*/
      goto LABEL_28; /*0x102d0012b*/
    }
    return 0; /*0x102cffdc3*/
  }
  __src = a3; /*0x102cffd6a*/
  v14 = 0; /*0x102cffd71*/
  if ( a6 <= 0xFF ) /*0x102cffd7b*/
  {
    v125 = a6 + __n + 2; /*0x102cffd95*/
    if ( v125 < 0x401 ) /*0x102cffd9c*/
    {
      v130 = false; /*0x102cffd9e*/
      v15 = v131; /*0x102cffda9*/
LABEL_11:
      *v15 = 0; /*0x102cffdf8*/
      v15[1] = a6; /*0x102cffe01*/
      memcpy(__dst: v15 + 2, __src: a5, __n: a6); /*0x102cffe0f*/
      a3 = __src; /*0x102cffe1a*/
      memcpy(__dst: &v15[a6 + 2], __src, __n); /*0x102cffe2b*/
      __n = v125; /*0x102cffe37*/
      goto LABEL_12; /*0x102cffe37*/
    }
    v130 = false; /*0x102cffdcd*/
    v15 = CRYPTO_malloc(num: (int)a6 + (int)__n + 2, file: "crypto/ml_dsa/ml_dsa_sign.c", line: 351); /*0x102cffdec*/
    if ( v15 != nullptr ) /*0x102cffdf2*/
      goto LABEL_11; /*0x102cffdf2*/
  }
  return v14; /*0x102d00169*/
}

// Address: 0x102d00ba0 | Name: _ossl_ml_kem_key_reset
void __fastcall ossl_ml_kem_key_reset(__int64 a1)
{
  void *v1; // rax
  __int64 v2; // rbx

  v1 = *(void **)(a1 + 64); /*0x102d00ba0*/
  if ( v1 != nullptr ) /*0x102d00ba7*/
  {
    v2 = a1 + 64; /*0x102d00bb0*/
    if ( *(_QWORD *)(a1 + 80) != 0 ) /*0x102d00bbb*/
    {
      OPENSSL_cleanse(ptr: *(void **)(a1 + 80), len: *(_QWORD *)(*(_QWORD *)a1 + 48LL) + 64LL); /*0x102d00bce*/
      v1 = *(void **)(a1 + 64); /*0x102d00bd3*/
    }
    CRYPTO_free(a1: v1); /*0x102d00be6*/
    *(_OWORD *)(v2 + 16) = 0; /*0x102d00bee*/
    *(_OWORD *)v2 = 0; /*0x102d00bf2*/
    *(_QWORD *)(v2 + 32) = 0; /*0x102d00bf5*/
  }
}

// Address: 0x102d00c10 | Name: _ossl_ml_kem_get_vinfo
char **__fastcall ossl_ml_kem_get_vinfo(int a1)
{
  unsigned int v1; // edi

  v1 = a1 - 1454; /*0x102d00c14*/
  if ( v1 > 2 ) /*0x102d00c1d*/
    return nullptr; /*0x102d00c2e*/
  else
    return off_10C85EC08[v1]; /*0x102d00c28*/
}

// Address: 0x102d00c40 | Name: _ossl_ml_kem_key_new
_QWORD *__fastcall ossl_ml_kem_key_new(__int64 a1, int a2, int a3)
{
  unsigned int v3; // edx
  char **v6; // r15
  _QWORD *v7; // rax
  _QWORD *v8; // r12
  __int64 v9; // r15
  __int64 v10; // r13
  __int64 v11; // rcx
  _QWORD *result; // rax
  __int64 v13; // [rsp-38h] [rbp-38h]

  v3 = a3 - 1454; /*0x102d00c40*/
  if ( v3 > 2 ) /*0x102d00c49*/
    return nullptr; /*0x102d00d76*/
  v6 = off_10C85EC08[v3]; /*0x102d00c6c*/
  v7 = CRYPTO_malloc(num: 184, file: "crypto/ml_kem/ml_kem.c", line: 1588); /*0x102d00c81*/
  if ( v7 == nullptr ) /*0x102d00c89*/
    return nullptr; /*0x102d00c89*/
  *v7 = v6; /*0x102d00c8f*/
  v7[1] = a1; /*0x102d00c92*/
  *((_DWORD *)v7 + 26) = 13; /*0x102d00c96*/
  v8 = v7; /*0x102d00caa*/
  v9 = EVP_MD_fetch(a1, a2: (int)"SHAKE128", a3: a2); /*0x102d00cb2*/
  v8[2] = v9; /*0x102d00cb5*/
  v10 = EVP_MD_fetch(a1, a2: (int)"SHAKE256", a3: a2); /*0x102d00ccc*/
  v8[3] = v10; /*0x102d00ccf*/
  v13 = EVP_MD_fetch(a1, a2: (int)"SHA3-256", a3: a2); /*0x102d00ce6*/
  v8[4] = v13; /*0x102d00cea*/
  v11 = EVP_MD_fetch(a1, a2: (int)"SHA3-512", a3: a2); /*0x102d00d01*/
  result = v8; /*0x102d00d04*/
  v8[5] = v11; /*0x102d00d07*/
  v8[22] = 0; /*0x102d00d0c*/
  *((_OWORD *)v8 + 3) = 0; /*0x102d00d21*/
  *((_OWORD *)v8 + 4) = 0; /*0x102d00d27*/
  *((_OWORD *)v8 + 5) = 0; /*0x102d00d2d*/
  v8[12] = 0; /*0x102d00d33*/
  if ( v9 == 0 || v10 == 0 || v13 == 0 || v11 == 0 ) /*0x102d00d53*/
  {
    ossl_ml_kem_key_free(a1: v8); /*0x102d00d60*/
    return nullptr; /*0x102d00d65*/
  }
  return result; /*0x102d00d75*/
}

// Address: 0x102d00d80 | Name: _ossl_ml_kem_key_free
void __fastcall ossl_ml_kem_key_free(char *a1)
{
  void *v2; // rdi
  void *v3; // rdi

  if ( a1 != nullptr ) /*0x102d00d83*/
  {
    EVP_MD_free(a1: *((_QWORD *)a1 + 2)); /*0x102d00d93*/
    EVP_MD_free(a1: *((_QWORD *)a1 + 3)); /*0x102d00d9c*/
    EVP_MD_free(a1: *((_QWORD *)a1 + 4)); /*0x102d00da5*/
    EVP_MD_free(a1: *((_QWORD *)a1 + 5)); /*0x102d00dae*/
    if ( *((_QWORD *)a1 + 22) != 0 || *((_QWORD *)a1 + 10) == 0 && *((_QWORD *)a1 + 12) != 0 ) /*0x102d00e74*/
    {
      OPENSSL_cleanse(ptr: a1 + 108, len: 0x40u); /*0x102d00dc6*/
      v2 = *((void **)a1 + 22); /*0x102d00dcb*/
      if ( v2 != nullptr ) /*0x102d00dd5*/
      {
        OPENSSL_cleanse(ptr: v2, len: *(_QWORD *)(*(_QWORD *)a1 + 8LL)); /*0x102d00dde*/
        CRYPTO_free(a1: *((void **)a1 + 22)); /*0x102d00df6*/
      }
    }
    v3 = *((void **)a1 + 8); /*0x102d00e05*/
    if ( v3 != nullptr ) /*0x102d00e0c*/
    {
      if ( *((_QWORD *)a1 + 10) != 0 ) /*0x102d00e19*/
      {
        OPENSSL_cleanse(ptr: *((void **)a1 + 10), len: *(_QWORD *)(*(_QWORD *)a1 + 48LL) + 64LL); /*0x102d00e29*/
        v3 = *((void **)a1 + 8); /*0x102d00e2e*/
      }
      CRYPTO_free(a1: v3); /*0x102d00e3e*/
      *((_OWORD *)a1 + 5) = 0; /*0x102d00e46*/
      *((_OWORD *)a1 + 4) = 0; /*0x102d00e4b*/
      *((_QWORD *)a1 + 12) = 0; /*0x102d00e4f*/
    }
    CRYPTO_free(a1); /*0x102d00e6a*/
  }
}

// Address: 0x102d00e80 | Name: _ossl_ml_kem_key_dup
__int64 *__fastcall ossl_ml_kem_key_dup(_QWORD *a1, char a2)
{
  char *v5; // rax
  void *v6; // rdi
  _QWORD *v7; // rcx
  char v8; // dl
  _QWORD *v9; // r14
  char *v10; // rax
  char *v11; // rcx
  __int64 v12; // rdx
  __int64 v13; // rsi
  char *v14; // rcx
  char *v15; // rdx
  int v16; // ecx
  _QWORD *v17; // rbx
  char *v18; // rax
  char *v19; // rcx
  __int64 v20; // rsi
  __int64 *v21; // rbx

  if ( a1[22] != 0 || a1[10] == 0 && a1[12] != 0 ) /*0x102d00fac*/
    return nullptr; /*0x102d00e8c*/
  v5 = (char *)CRYPTO_memdup(__src: a1, __n: 0xB8u, file: "crypto/ml_kem/ml_kem.c", line: 1624); /*0x102d00eb6*/
  if ( v5 != nullptr ) /*0x102d00ebe*/
  {
    *((_OWORD *)v5 + 5) = 0; /*0x102d00ec7*/
    *((_OWORD *)v5 + 4) = 0; /*0x102d00ecb*/
    *((_OWORD *)v5 + 3) = 0; /*0x102d00ecf*/
    *((_QWORD *)v5 + 12) = 0; /*0x102d00ed3*/
    v6 = (void *)a1[8]; /*0x102d00edb*/
    if ( v6 == nullptr ) /*0x102d00ee2*/
    {
LABEL_21:
      v21 = (__int64 *)v5; /*0x102d01053*/
      EVP_MD_up_ref(a1: *((_QWORD *)v5 + 2)); /*0x102d0105a*/
      EVP_MD_up_ref(a1: v21[3]); /*0x102d01063*/
      EVP_MD_up_ref(a1: v21[4]); /*0x102d0106c*/
      EVP_MD_up_ref(a1: v21[5]); /*0x102d01075*/
      return v21; /*0x102d01081*/
    }
    v7 = a1; /*0x102d00ee8*/
    v8 = a2 & 2; /*0x102d00eee*/
    if ( a1[10] != 0 ) /*0x102d00ef6*/
      v8 = a2; /*0x102d00ef6*/
    switch ( v8 & 3 ) /*0x102d00f0b*/
    {
      case 0: /*0x102d00f0b*/
        goto LABEL_21;
      case 1: /*0x102d00f0b*/
        v9 = v5; /*0x102d00f0d*/
        v10 = (char *)CRYPTO_memdup(__src: v6, __n: *(_QWORD *)(*a1 + 16LL), file: "crypto/ml_kem/ml_kem.c", line: 1645); /*0x102d00f23*/
        if ( v10 != nullptr ) /*0x102d00f2b*/
        {
          v11 = v10; /*0x102d00f31*/
          v5 = (char *)v9; /*0x102d00f34*/
          v12 = *(int *)(*v9 + 72LL); /*0x102d00f3a*/
          *(_OWORD *)((char *)v9 + 108) = 0; /*0x102d00f45*/
          *(_OWORD *)((char *)v9 + 124) = 0; /*0x102d00f4a*/
          *(_OWORD *)((char *)v9 + 140) = 0; /*0x102d00f4f*/
          *(_OWORD *)((char *)v9 + 156) = 0; /*0x102d00f57*/
          v9[6] = (char *)v9 + 108; /*0x102d00f5f*/
          v9[7] = (char *)v9 + 140; /*0x102d00f6d*/
          v9[12] = 0; /*0x102d00f71*/
          v9[8] = v11; /*0x102d00f79*/
          v13 = v12 << 9; /*0x102d00f80*/
          v14 = &v11[512 * v12]; /*0x102d00f84*/
          v9[9] = v14; /*0x102d00f87*/
          v15 = &v14[512 * (unsigned __int64)(unsigned int)(v12 * v12)]; /*0x102d00f92*/
          v9[10] = v15; /*0x102d00f95*/
          v9[11] = &v15[v13]; /*0x102d00f9c*/
          v16 = 1; /*0x102d00fa0*/
        }
        else
        {
          v16 = 0; /*0x102d0101a*/
          v5 = (char *)v9; /*0x102d0101c*/
        }
        if ( a1[12] != 0 ) /*0x102d01024*/
          *((_QWORD *)v5 + 12) = *((_QWORD *)v5 + 11) + 32LL; /*0x102d0102e*/
        goto LABEL_20; /*0x102d01032*/
      case 2: /*0x102d00f0b*/
        v17 = v5; /*0x102d00fb7*/
        v18 = (char *)CRYPTO_memdup(__src: v6, __n: *(_QWORD *)(*v7 + 32LL), file: "crypto/ml_kem/ml_kem.c", line: 1640); /*0x102d00fcd*/
        if ( v18 != nullptr ) /*0x102d00fd5*/
        {
          v19 = v18; /*0x102d00fd7*/
          v5 = (char *)v17; /*0x102d00fda*/
          v20 = *(int *)(*v17 + 72LL); /*0x102d00fe4*/
          *(_OWORD *)((char *)v17 + 108) = 0; /*0x102d00feb*/
          *(_OWORD *)((char *)v17 + 124) = 0; /*0x102d00fef*/
          *(_OWORD *)((char *)v17 + 140) = 0; /*0x102d00ff3*/
          *(_OWORD *)((char *)v17 + 156) = 0; /*0x102d00ffa*/
          *(_OWORD *)(v17 + 11) = 0; /*0x102d01001*/
          v17[8] = v19; /*0x102d01004*/
          v17[9] = &v19[512 * v20]; /*0x102d0100f*/
          v16 = 1; /*0x102d01013*/
        }
        else
        {
          v16 = 0; /*0x102d01034*/
          v5 = (char *)v17; /*0x102d01036*/
        }
        *((_QWORD *)v5 + 6) = v5 + 108; /*0x102d0103d*/
        *((_QWORD *)v5 + 7) = v5 + 140; /*0x102d0104b*/
LABEL_20:
        if ( v16 != 0 ) /*0x102d01051*/
          goto LABEL_21; /*0x102d01051*/
        goto LABEL_22; /*0x102d01051*/
      case 3: /*0x102d00f0b*/
LABEL_22:
        CRYPTO_free(a1: v5); /*0x102d01082*/
        break; /*0x102d01091*/
    }
  }
  return nullptr; /*0x102d00e8c*/
}

// Address: 0x102d010b0 | Name: _ossl_ml_kem_encode_public_key
__int64 __fastcall ossl_ml_kem_encode_public_key(__int64 *a1, __int64 a2, _QWORD *a3)
{
  __int64 v3; // r8
  __int64 result; // rax
  __int64 v5; // r9
  int v6; // esi
  __int64 *v7; // r10
  unsigned __int64 v9; // rbx
  unsigned __int64 v10; // r11
  __int64 *v11; // r14
  int v12; // eax
  unsigned __int64 v13; // r12
  int v14; // r15d
  __int64 v15; // rax
  __int128 *v16; // rcx
  __int128 v17; // xmm0
  __int64 v18; // [rsp-8h] [rbp-8h]

  v3 = a3[8]; /*0x102d010b0*/
  result = 0; /*0x102d010b4*/
  if ( v3 != 0 ) /*0x102d010b9*/
  {
    v5 = *a3; /*0x102d010bf*/
    if ( *(_QWORD *)(*a3 + 24LL) == a2 ) /*0x102d010c6*/
    {
      *(&v18 - 6) = a3[6]; /*0x102d010dd*/
      v6 = *(_DWORD *)(v5 + 72); /*0x102d010e1*/
      if ( v6 > 0 ) /*0x102d010e7*/
      {
        v7 = a1; /*0x102d010ed*/
        do /*0x102d01116*/
        {
          v9 = 0; /*0x102d01118*/
          v10 = -2; /*0x102d0111a*/
          v11 = v7; /*0x102d01121*/
          v12 = 0; /*0x102d01124*/
          do /*0x102d01146*/
          {
            v13 = *(unsigned __int16 *)(v3 + v10 + 2); /*0x102d01148*/
            v14 = v12 + 12; /*0x102d0114e*/
            if ( v12 <= 51 ) /*0x102d01155*/
            {
              v9 |= v13 << v12; /*0x102d01135*/
            }
            else
            {
              *v11 = v9 | (v13 << v12); /*0x102d01166*/
              if ( v12 == 52 ) /*0x102d0116d*/
              {
                v9 = 0; /*0x102d0116f*/
                ++v11; /*0x102d01171*/
                v14 = 0; /*0x102d01174*/
              }
              else
              {
                v9 = v13 >> -(char)v12; /*0x102d01183*/
                ++v11; /*0x102d01186*/
                v14 = v12 - 52; /*0x102d01189*/
              }
            }
            v10 += 2LL; /*0x102d01138*/
            v12 = v14; /*0x102d0113c*/
          }
          while ( v10 < 0x1FE ); /*0x102d01146*/
          v3 += 512; /*0x102d01103*/
          v7 += 48; /*0x102d0110a*/
        }
        while ( v6-- > 1 ); /*0x102d01116*/
      }
      v15 = *(_QWORD *)(v5 + 48); /*0x102d0118e*/
      v16 = (__int128 *)*(&v18 - 6); /*0x102d01192*/
      v17 = *v16; /*0x102d01196*/
      *(_OWORD *)((char *)a1 + v15 + 16) = v16[1]; /*0x102d0119d*/
      *(_OWORD *)((char *)a1 + v15) = v17; /*0x102d011a2*/
      return 1; /*0x102d011a6*/
    }
  }
  return result; /*0x102d011b5*/
}

// Address: 0x102d011c0 | Name: _ossl_ml_kem_encode_private_key
__int64 __fastcall ossl_ml_kem_encode_private_key(__int64 *a1, __int64 a2, __int64 *a3)
{
  __int64 v3; // r9
  __int64 result; // rax
  __int64 v5; // rcx
  int v6; // esi
  __int64 *v7; // r10
  bool v8; // cc
  unsigned __int64 v9; // rbx
  unsigned __int64 v10; // r11
  __int64 *v11; // r14
  int v12; // eax
  unsigned __int64 v13; // r12
  int v14; // r15d
  __int64 v15; // rax
  __int128 *v16; // rsi
  int v17; // r10d
  __int64 *v18; // r8
  __int64 v19; // r11
  __int64 *v20; // rdi
  unsigned __int64 v21; // r9
  unsigned __int64 v22; // r14
  __int64 *v23; // rbx
  int v24; // eax
  unsigned __int64 v25; // r15
  int v26; // r13d
  __int64 v27; // rax
  __int128 v28; // xmm0
  __int64 v29; // rax
  __int128 *v30; // rcx
  __int128 v31; // xmm0
  _OWORD *v32; // rcx
  __int128 v33; // xmm1
  __int64 v34; // [rsp-8h] [rbp-8h]

  v3 = a3[10]; /*0x102d011c0*/
  result = 0; /*0x102d011c4*/
  if ( v3 != 0 ) /*0x102d011c9*/
  {
    v5 = *a3; /*0x102d011cf*/
    if ( *(_QWORD *)(*a3 + 8) == a2 ) /*0x102d011d6*/
    {
      v6 = *(_DWORD *)(v5 + 72); /*0x102d011ec*/
      if ( v6 <= 0 ) /*0x102d011f1*/
      {
        v18 = (__int64 *)((char *)a1 + *(_QWORD *)(v5 + 48)); /*0x102d0135d*/
        v16 = (__int128 *)a3[6]; /*0x102d01361*/
        v15 = *a3; /*0x102d01365*/
      }
      else
      {
        *(&v34 - 6) = v5; /*0x102d011f7*/
        v7 = a1; /*0x102d011fb*/
        do /*0x102d01216*/
        {
          v9 = 0; /*0x102d01218*/
          v10 = -2; /*0x102d0121a*/
          v11 = v7; /*0x102d01221*/
          v12 = 0; /*0x102d01224*/
          do /*0x102d01246*/
          {
            v13 = *(unsigned __int16 *)(v3 + v10 + 2); /*0x102d01248*/
            v14 = v12 + 12; /*0x102d0124e*/
            if ( v12 <= 51 ) /*0x102d01255*/
            {
              v9 |= v13 << v12; /*0x102d01235*/
            }
            else
            {
              *v11 = v9 | (v13 << v12); /*0x102d01266*/
              if ( v12 == 52 ) /*0x102d0126d*/
              {
                v9 = 0; /*0x102d0126f*/
                ++v11; /*0x102d01271*/
                v14 = 0; /*0x102d01274*/
              }
              else
              {
                v9 = v13 >> -(char)v12; /*0x102d01283*/
                ++v11; /*0x102d01286*/
                v14 = v12 - 52; /*0x102d01289*/
              }
            }
            v10 += 2LL; /*0x102d01238*/
            v12 = v14; /*0x102d0123c*/
          }
          while ( v10 < 0x1FE ); /*0x102d01246*/
          v3 += 512; /*0x102d01203*/
          v7 += 48; /*0x102d0120a*/
          v8 = v6-- <= 1; /*0x102d01211*/
        }
        while ( !v8 ); /*0x102d01216*/
        v15 = *a3; /*0x102d0128e*/
        v16 = (__int128 *)a3[6]; /*0x102d01291*/
        v17 = *(_DWORD *)(*a3 + 72); /*0x102d01295*/
        v5 = *(&v34 - 6); /*0x102d01299*/
        v18 = (__int64 *)((char *)a1 + *(_QWORD *)(v5 + 48)); /*0x102d0129d*/
        if ( v17 > 0 ) /*0x102d012a4*/
        {
          *(&v34 - 7) = v15; /*0x102d012aa*/
          *(&v34 - 8) = (__int64)v16; /*0x102d012ae*/
          v19 = a3[8]; /*0x102d012b2*/
          v20 = v18; /*0x102d012b6*/
          do /*0x102d012d9*/
          {
            v21 = 0; /*0x102d012db*/
            v22 = -2; /*0x102d012de*/
            v23 = v20; /*0x102d012e5*/
            v24 = 0; /*0x102d012e8*/
            do /*0x102d01306*/
            {
              v25 = *(unsigned __int16 *)(v19 + v22 + 2); /*0x102d01308*/
              v26 = v24 + 12; /*0x102d0130e*/
              if ( v24 <= 51 ) /*0x102d01315*/
              {
                v21 |= v25 << v24; /*0x102d012f5*/
              }
              else
              {
                *v23 = v21 | (v25 << v24); /*0x102d01326*/
                if ( v24 == 52 ) /*0x102d0132d*/
                {
                  v21 = 0; /*0x102d0132f*/
                  ++v23; /*0x102d01332*/
                  v26 = 0; /*0x102d01335*/
                }
                else
                {
                  v21 = v25 >> -(char)v24; /*0x102d01344*/
                  ++v23; /*0x102d01347*/
                  v26 = v24 - 52; /*0x102d0134a*/
                }
              }
              v22 += 2LL; /*0x102d012f8*/
              v24 = v26; /*0x102d012fc*/
            }
            while ( v22 < 0x1FE ); /*0x102d01306*/
            v19 += 512; /*0x102d012c4*/
            v20 += 48; /*0x102d012cb*/
            v8 = v17-- <= 1; /*0x102d012d2*/
          }
          while ( !v8 ); /*0x102d012d9*/
          v5 = *(&v34 - 6); /*0x102d0134f*/
          v16 = (__int128 *)*(&v34 - 8); /*0x102d01353*/
          v15 = *(&v34 - 7); /*0x102d01357*/
        }
      }
      v27 = *(_QWORD *)(v15 + 48); /*0x102d01368*/
      v28 = *v16; /*0x102d0136c*/
      *(_OWORD *)((char *)v18 + v27 + 16) = v16[1]; /*0x102d01373*/
      *(_OWORD *)((char *)v18 + v27) = v28; /*0x102d01379*/
      v29 = *(_QWORD *)(v5 + 24); /*0x102d0137e*/
      v30 = (__int128 *)a3[7]; /*0x102d01382*/
      v31 = *v30; /*0x102d01386*/
      *(_OWORD *)((char *)v18 + v29 + 16) = v30[1]; /*0x102d0138d*/
      *(_OWORD *)((char *)v18 + v29) = v31; /*0x102d01393*/
      v32 = (_OWORD *)a3[11]; /*0x102d01398*/
      v33 = v32[1]; /*0x102d0139f*/
      *(_OWORD *)((char *)v18 + v29 + 32) = *v32; /*0x102d013a3*/
      *(_OWORD *)((char *)v18 + v29 + 48) = v33; /*0x102d013a9*/
      return 1; /*0x102d013af*/
    }
  }
  return result; /*0x102d013be*/
}

// Address: 0x102d013c0 | Name: _ossl_ml_kem_encode_seed
__int64 __fastcall ossl_ml_kem_encode_seed(_OWORD *a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  __int128 *v4; // rcx
  __int128 v5; // xmm0
  __int128 *v6; // rax
  __int128 v7; // xmm0

  result = 0; /*0x102d013c0*/
  if ( a3 != 0 ) /*0x102d013c5*/
  {
    v4 = *(__int128 **)(a3 + 96); /*0x102d013c7*/
    if ( v4 != nullptr && a2 == 64 ) /*0x102d013d6*/
    {
      v5 = *v4; /*0x102d013e3*/
      a1[1] = v4[1]; /*0x102d013ea*/
      *a1 = v5; /*0x102d013ee*/
      v6 = *(__int128 **)(a3 + 88); /*0x102d013f1*/
      v7 = *v6; /*0x102d013f5*/
      a1[3] = v6[1]; /*0x102d013fc*/
      a1[2] = v7; /*0x102d01400*/
      return 1; /*0x102d01404*/
    }
  }
  return result; /*0x102d0140a*/
}

// Address: 0x102d01410 | Name: _ossl_ml_kem_set_seed
__int64 __fastcall ossl_ml_kem_set_seed(_OWORD *a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  __int128 v4; // xmm1
  __int128 v5; // xmm1

  if ( a3 == 0 || *(_QWORD *)(a3 + 64) != 0 ) /*0x102d0141e*/
    return 0; /*0x102d01420*/
  result = 0; /*0x102d01424*/
  if ( a2 == 64 && *(_QWORD *)(a3 + 96) == 0 ) /*0x102d01431*/
  {
    *(_QWORD *)(a3 + 88) = a3 + 108; /*0x102d01437*/
    *(_QWORD *)(a3 + 96) = a3 + 140; /*0x102d01442*/
    v4 = a1[1]; /*0x102d01449*/
    *(_OWORD *)(a3 + 140) = *a1; /*0x102d0144d*/
    *(_OWORD *)(a3 + 156) = v4; /*0x102d01454*/
    v5 = a1[3]; /*0x102d0145f*/
    *(_OWORD *)(a3 + 108) = a1[2]; /*0x102d01463*/
    *(_OWORD *)(a3 + 124) = v5; /*0x102d01467*/
    return a3; /*0x102d0146b*/
  }
  return result; /*0x102d01422*/
}

// Address: 0x102d01470 | Name: _ossl_ml_kem_parse_public_key
__int64 __fastcall ossl_ml_kem_parse_public_key(void *a1, __int64 a2, _QWORD *a3)
{
  __int64 result; // rax
  __int64 v4; // r12
  EVP_MD_CTX *v7; // rbx
  char *v8; // rax
  __int64 v9; // rcx
  int v10; // eax
  int v11; // ecx
  EVP_MD_CTX *v12; // rdi
  unsigned int v13; // ebx

  result = 0; /*0x102d01470*/
  if ( a3 != nullptr && a3[8] == 0 && a3[22] == 0 ) /*0x102d01487*/
  {
    v4 = *a3; /*0x102d01494*/
    if ( *(_QWORD *)(*a3 + 24LL) == a2 ) /*0x102d0149c*/
    {
      v7 = (EVP_MD_CTX *)EVP_MD_CTX_new(); /*0x102d014ad*/
      result = 0; /*0x102d014b0*/
      if ( v7 != nullptr ) /*0x102d014b5*/
      {
        v8 = (char *)CRYPTO_malloc(num: *(_QWORD *)(v4 + 32), file: "crypto/ml_kem/ml_kem.c", line: 1765); /*0x102d014cc*/
        if ( v8 == nullptr ) /*0x102d014d4*/
          goto LABEL_9; /*0x102d014d4*/
        v9 = *(int *)(*a3 + 72LL); /*0x102d014dc*/
        *(_OWORD *)((char *)a3 + 108) = 0; /*0x102d014e7*/
        *(_OWORD *)((char *)a3 + 124) = 0; /*0x102d014ec*/
        *(_OWORD *)((char *)a3 + 140) = 0; /*0x102d014f1*/
        *(_OWORD *)((char *)a3 + 156) = 0; /*0x102d014f9*/
        a3[6] = (char *)a3 + 108; /*0x102d01501*/
        a3[7] = (char *)a3 + 140; /*0x102d0150c*/
        *(_OWORD *)(a3 + 11) = 0; /*0x102d01510*/
        a3[8] = v8; /*0x102d01515*/
        a3[9] = &v8[512 * v9]; /*0x102d01520*/
        v10 = parse_pubkey(d: a1, ctx: v7); /*0x102d0152a*/
        v11 = 1; /*0x102d0152f*/
        if ( v10 == 0 ) /*0x102d01536*/
        {
LABEL_9:
          ossl_ml_kem_key_reset(a1: (__int64)a3); /*0x102d0153b*/
          v11 = 0; /*0x102d01540*/
        }
        v12 = v7; /*0x102d01542*/
        v13 = v11; /*0x102d01545*/
        EVP_MD_CTX_free(ctx: v12); /*0x102d01547*/
        return v13; /*0x102d0154c*/
      }
    }
  }
  return result; /*0x102d0147e*/
}

// Address: 0x102d01670 | Name: _ossl_ml_kem_parse_private_key
__int64 __fastcall ossl_ml_kem_parse_private_key(__int64 a1, __int64 a2, _QWORD *a3)
{
  __int64 result; // rax
  __int64 v4; // r12
  EVP_MD_CTX *v7; // rbx
  char *v8; // rax
  __int64 v9; // rcx
  __int64 v10; // rsi
  char *v11; // rax
  char *v12; // rcx
  int v13; // eax
  int v14; // ecx
  EVP_MD_CTX *v15; // rdi
  unsigned int v16; // ebx

  result = 0; /*0x102d01670*/
  if ( a3 != nullptr && a3[8] == 0 && a3[22] == 0 ) /*0x102d01687*/
  {
    v4 = *a3; /*0x102d01694*/
    if ( *(_QWORD *)(*a3 + 8LL) == a2 ) /*0x102d0169c*/
    {
      v7 = (EVP_MD_CTX *)EVP_MD_CTX_new(); /*0x102d016ad*/
      result = 0; /*0x102d016b0*/
      if ( v7 != nullptr ) /*0x102d016b5*/
      {
        v8 = (char *)CRYPTO_malloc(num: *(_QWORD *)(v4 + 16), file: "crypto/ml_kem/ml_kem.c", line: 1793); /*0x102d016cc*/
        if ( v8 == nullptr ) /*0x102d016d4*/
          goto LABEL_9; /*0x102d016d4*/
        v9 = *(int *)(*a3 + 72LL); /*0x102d016dc*/
        *(_OWORD *)((char *)a3 + 108) = 0; /*0x102d016e7*/
        *(_OWORD *)((char *)a3 + 124) = 0; /*0x102d016ec*/
        *(_OWORD *)((char *)a3 + 140) = 0; /*0x102d016f1*/
        *(_OWORD *)((char *)a3 + 156) = 0; /*0x102d016f9*/
        a3[6] = (char *)a3 + 108; /*0x102d01701*/
        a3[7] = (char *)a3 + 140; /*0x102d0170c*/
        a3[12] = 0; /*0x102d01710*/
        a3[8] = v8; /*0x102d01718*/
        v10 = v9 << 9; /*0x102d0171f*/
        v11 = &v8[512 * v9]; /*0x102d01723*/
        a3[9] = v11; /*0x102d01726*/
        v12 = &v11[512 * (unsigned __int64)(unsigned int)(v9 * v9)]; /*0x102d01731*/
        a3[10] = v12; /*0x102d01734*/
        a3[11] = &v12[v10]; /*0x102d0173b*/
        v13 = parse_prvkey(a1, a2: v7, a3); /*0x102d01745*/
        v14 = 1; /*0x102d0174a*/
        if ( v13 == 0 ) /*0x102d01751*/
        {
LABEL_9:
          ossl_ml_kem_key_reset(a1: (__int64)a3); /*0x102d01756*/
          v14 = 0; /*0x102d0175b*/
        }
        v15 = v7; /*0x102d0175d*/
        v16 = v14; /*0x102d01760*/
        EVP_MD_CTX_free(ctx: v15); /*0x102d01762*/
        return v16; /*0x102d01767*/
      }
    }
  }
  return result; /*0x102d0167e*/
}

// Address: 0x102d01990 | Name: _ossl_ml_kem_genkey
__int64 __fastcall ossl_ml_kem_genkey(void *a1, __int64 a2, _QWORD *a3)
{
  __int64 result; // rax
  __int64 v4; // r12
  __m128i *v6; // rax
  __m128i v7; // xmm0
  __m128i *v8; // rax
  __m128i v9; // xmm0
  __int64 *v10; // r14
  EVP_MD_CTX *v11; // rax
  EVP_MD_CTX *v12; // r15
  char *v13; // rax
  __int64 v14; // rdx
  __int64 v15; // rsi
  char *v16; // rax
  __int64 v17; // rdx
  int v18; // ebx
  __m128i ptr[4]; // [rsp+0h] [rbp-70h] BYREF

  result = 0; /*0x102d019ad*/
  if ( a3 != nullptr && a3[8] == 0 && a3[22] == 0 ) /*0x102d019cb*/
  {
    v4 = *a3; /*0x102d019d1*/
    if ( a1 == nullptr || *(_QWORD *)(v4 + 24) == a2 ) /*0x102d019de*/
    {
      v6 = (__m128i *)a3[12]; /*0x102d019e7*/
      if ( v6 != nullptr ) /*0x102d019ee*/
      {
        v7 = *v6; /*0x102d019f0*/
        ptr[1] = v6[1]; /*0x102d019f7*/
        ptr[0] = v7; /*0x102d019fb*/
        v8 = (__m128i *)a3[11]; /*0x102d019ff*/
        v9 = *v8; /*0x102d01a03*/
        ptr[3] = v8[1]; /*0x102d01a0a*/
        ptr[2] = v9; /*0x102d01a0e*/
        v10 = a3; /*0x102d01a15*/
        *(_OWORD *)(a3 + 11) = 0; /*0x102d01a18*/
      }
      else
      {
        v10 = a3; /*0x102d01a1e*/
        if ( (int)RAND_priv_bytes_ex(a1: a3[1], a2: ptr, a3: 64, a4: *(unsigned int *)(v4 + 84)) <= 0 ) /*0x102d01a3a*/
          return 0; /*0x102d01b2b*/
      }
      v11 = (EVP_MD_CTX *)EVP_MD_CTX_new(); /*0x102d01a40*/
      if ( v11 != nullptr ) /*0x102d01a48*/
      {
        v12 = v11; /*0x102d01a4e*/
        v13 = (char *)CRYPTO_malloc(num: *(_QWORD *)(v4 + 16), file: "crypto/ml_kem/ml_kem.c", line: 1840); /*0x102d01a62*/
        if ( v13 != nullptr ) /*0x102d01a6a*/
        {
          v14 = *(int *)(*v10 + 72); /*0x102d01a76*/
          *(_OWORD *)((char *)v10 + 108) = 0; /*0x102d01a81*/
          *(_OWORD *)((char *)v10 + 124) = 0; /*0x102d01a86*/
          *(_OWORD *)((char *)v10 + 140) = 0; /*0x102d01a8b*/
          *(_OWORD *)((char *)v10 + 156) = 0; /*0x102d01a93*/
          v10[6] = (__int64)v10 + 108; /*0x102d01a9b*/
          v10[7] = (__int64)v10 + 140; /*0x102d01aa6*/
          v10[12] = 0; /*0x102d01aaa*/
          v10[8] = (__int64)v13; /*0x102d01ab2*/
          v15 = v14 << 9; /*0x102d01ab9*/
          v16 = &v13[512 * v14]; /*0x102d01abd*/
          v10[9] = (__int64)v16; /*0x102d01ac0*/
          v17 = (__int64)&v16[512 * (unsigned __int64)(unsigned int)(v14 * v14)]; /*0x102d01acb*/
          v10[10] = v17; /*0x102d01ace*/
          v10[11] = v15 + v17; /*0x102d01ad5*/
          v18 = genkey(a1: ptr, a2: v12, a3: a1, a4: v10); /*0x102d01aeb*/
          OPENSSL_cleanse(ptr, len: 0x40u); /*0x102d01af5*/
          EVP_MD_CTX_free(ctx: v12); /*0x102d01afd*/
          result = 1; /*0x102d01b02*/
          if ( v18 != 0 ) /*0x102d01b09*/
            return result; /*0x102d01b09*/
        }
        else
        {
          OPENSSL_cleanse(ptr, len: 0x40u); /*0x102d01b16*/
          EVP_MD_CTX_free(ctx: v12); /*0x102d01b1e*/
        }
        ossl_ml_kem_key_reset(a1: (__int64)v10); /*0x102d01b26*/
      }
      return 0; /*0x102d01b26*/
    }
  }
  return result; /*0x102d01b3d*/
}

// Address: 0x102d02a60 | Name: _ossl_ml_kem_encap_seed
__int64 __fastcall ossl_ml_kem_encap_seed(
        __int64 a1,
        __int64 a2,
        _OWORD *a3,
        __int64 a4,
        _OWORD *a5,
        __int64 a6,
        _QWORD *a7)
{
  __int64 result; // rax
  __int64 v8; // rbx
  EVP_MD_CTX *v12; // r8
  int v13; // eax
  _OWORD *v14; // rdx
  unsigned int v15; // r15d
  EVP_MD_CTX *v16; // rbx
  size_t v17; // rsi
  _BYTE ptr[4096]; // [rsp+0h] [rbp-1030h] BYREF

  result = 0; /*0x102d02a86*/
  if ( a7 != nullptr && a7[8] != 0 && a1 != 0 && a6 == 32 && a5 != nullptr && a4 == 32 && a3 != nullptr ) /*0x102d02ac5*/
  {
    v8 = *a7; /*0x102d02acb*/
    if ( *(_QWORD *)(*a7 + 40LL) == a2 ) /*0x102d02ad2*/
    {
      v12 = (EVP_MD_CTX *)EVP_MD_CTX_new(); /*0x102d02ae6*/
      result = 0; /*0x102d02ae9*/
      if ( v12 != nullptr ) /*0x102d02aee*/
      {
        v13 = *(_DWORD *)(v8 + 64); /*0x102d02af4*/
        if ( v13 == 1456 ) /*0x102d02afc*/
        {
          v16 = v12; /*0x102d02b6c*/
          v15 = encap(a1, a2: a3, a3: a5, a4: (__int64)ptr, a5: v12, a6: (__int64)a7); /*0x102d02b77*/
          v17 = 4096; /*0x102d02b7a*/
        }
        else
        {
          v14 = a5; /*0x102d02b03*/
          if ( v13 == 1455 ) /*0x102d02b09*/
          {
            v16 = v12; /*0x102d02b44*/
            v15 = encap(a1, a2: a3, a3: a5, a4: (__int64)ptr, a5: v12, a6: (__int64)a7); /*0x102d02b4f*/
            v17 = 3072; /*0x102d02b52*/
          }
          else
          {
            v15 = 0; /*0x102d02b0b*/
            if ( v13 != 1454 ) /*0x102d02b13*/
            {
LABEL_17:
              EVP_MD_CTX_free(ctx: v12); /*0x102d02b8a*/
              return v15; /*0x102d02b92*/
            }
            v16 = v12; /*0x102d02b22*/
            v15 = encap(a1, a2: a3, a3: v14, a4: (__int64)ptr, a5: v12, a6: (__int64)a7); /*0x102d02b2d*/
            v17 = 2048; /*0x102d02b30*/
          }
        }
        OPENSSL_cleanse(ptr, len: v17); /*0x102d02b82*/
        v12 = v16; /*0x102d02b87*/
        goto LABEL_17; /*0x102d02b87*/
      }
    }
  }
  return result; /*0x102d02ba5*/
}

// Address: 0x102d02cc0 | Name: _ossl_ml_kem_encap_rand
__int64 __fastcall ossl_ml_kem_encap_rand(__int64 a1, __int64 a2, _OWORD *a3, __int64 a4, _QWORD *a5)
{
  unsigned int v5; // ebx
  _QWORD v12[4]; // [rsp+10h] [rbp-50h] BYREF

  v5 = 0; /*0x102d02cdf*/
  if ( a5 != nullptr && (int)RAND_bytes_ex(a1: a5[1], a2: v12, a3: 32, a4: *(unsigned int *)(*a5 + 84LL)) > 0 ) /*0x102d02d10*/
    return (unsigned int)ossl_ml_kem_encap_seed(a1, a2, a3, a4, a5: v12, a6: 32, a7: a5); /*0x102d02d32*/
  return v5; /*0x102d02d46*/
}

// Address: 0x102d02d60 | Name: _ossl_ml_kem_decap
__int64 __fastcall ossl_ml_kem_decap(__m128i *a1, __int64 a2, void *a3, __int64 a4, _QWORD *a5)
{
  unsigned int v5; // ebx
  __int64 v7; // r12
  _QWORD *v8; // r14
  EVP_MD_CTX *v10; // rax
  EVP_MD_CTX *v11; // r14
  int v12; // eax
  size_t v13; // rsi
  _BYTE ptr[4096]; // [rsp+0h] [rbp-1650h] BYREF
  _OWORD v16[98]; // [rsp+1000h] [rbp-650h] BYREF

  v5 = 0; /*0x102d02d82*/
  if ( a5[10] != 0 ) /*0x102d02d89*/
  {
    v7 = *a5; /*0x102d02d92*/
    if ( a2 == 32 && a1 != nullptr && a3 != nullptr && *(_QWORD *)(v7 + 40) == a4 ) /*0x102d02db7*/
    {
      v8 = a5; /*0x102d02db9*/
      v10 = (EVP_MD_CTX *)EVP_MD_CTX_new(); /*0x102d02dbf*/
      a5 = v8; /*0x102d02dc4*/
      if ( v10 != nullptr ) /*0x102d02dca*/
      {
        v11 = v10; /*0x102d02dcf*/
        v12 = *(_DWORD *)(v7 + 64); /*0x102d02dd2*/
        if ( v12 == 1456 ) /*0x102d02ddc*/
        {
          v5 = decap(a1, a2: a3, a3: v16, a4: (__int64)ptr, a5: v11, a6: a5); /*0x102d02ea6*/
          v13 = 4096; /*0x102d02ea8*/
        }
        else if ( v12 == 1455 ) /*0x102d02de7*/
        {
          v5 = decap(a1, a2: a3, a3: v16, a4: (__int64)ptr, a5: v11, a6: a5); /*0x102d02e7e*/
          v13 = 3072; /*0x102d02e80*/
        }
        else
        {
          v5 = 0; /*0x102d02de9*/
          if ( v12 != 1454 ) /*0x102d02df0*/
          {
LABEL_14:
            EVP_MD_CTX_free(ctx: v11); /*0x102d02eb5*/
            return v5; /*0x102d02ecb*/
          }
          v5 = decap(a1, a2: a3, a3: v16, a4: (__int64)ptr, a5: v11, a6: a5); /*0x102d02e15*/
          v13 = 2048; /*0x102d02e17*/
        }
        OPENSSL_cleanse(ptr, len: v13); /*0x102d02eb0*/
        goto LABEL_14; /*0x102d02eb0*/
      }
    }
    RAND_bytes_ex(a1: a5[1], a2: a1, a3: 32, a4: *(unsigned int *)(v7 + 84)); /*0x102d02e32*/
  }
  return v5; /*0x102d02e4d*/
}

// Address: 0x102d03a40 | Name: _ossl_ml_kem_pubkey_cmp
_BOOL8 __fastcall ossl_ml_kem_pubkey_cmp(__int64 a1, __int64 a2)
{
  __int64 v2; // rax
  __int64 v3; // rcx
  bool v5; // cl

  v2 = *(_QWORD *)(a1 + 64); /*0x102d03a40*/
  v3 = *(_QWORD *)(a2 + 64); /*0x102d03a44*/
  if ( v2 != 0 ) /*0x102d03a4b*/
  {
    if ( v3 != 0 ) /*0x102d03a50*/
      return _mm_movemask_epi8( /*0x102d03a8c*/
               _mm_and_si128(
                 _mm_cmpeq_epi8(
                   _mm_loadu_si128((const __m128i *)(*(_QWORD *)(a2 + 56) + 16LL)),
                   _mm_loadu_si128((const __m128i *)(*(_QWORD *)(a1 + 56) + 16LL))),
                 _mm_cmpeq_epi8(
                   _mm_loadu_si128((const __m128i *)*(_QWORD *)(a2 + 56)),
                   _mm_loadu_si128((const __m128i *)*(_QWORD *)(a1 + 56))))) == 0xFFFF;
    v5 = false; /*0x102d03a95*/
  }
  else
  {
    v5 = v3 != 0; /*0x102d03a90*/
  }
  return v5 ^ (unsigned __int8)(v2 != 0); /*0x102d03a8c*/
}

// Address: 0x102d09600 | Name: _ossl_vaes_vpclmulqdq_capable
__int64 ossl_vaes_vpclmulqdq_capable()
{
  __int64 result; // rax

  result = 0; /*0x102d09611*/
  if ( (qword_10D87FA98 & 0x600C0030000LL) == 0x600C0030000LL ) /*0x102d09619*/
    return 0x600C0030000LL; /*0x102d09619*/
  return result; /*0x102d0961d*/
}

// Address: 0x102d09620 | Name: _ossl_aes_gcm_init_avx512
__int64 __fastcall ossl_aes_gcm_init_avx512(__int64 a1, __int64 _RSI, double a3, double a4, double a5, __m128 _XMM3)
{
  __int64 result; // rax

  __asm { vpxorq xmm16, xmm16, xmm16 } /*0x102d09624*/
  result = *(unsigned int *)(a1 + 240); /*0x102d0962a*/
  switch ( (_DWORD)result ) /*0x102d09633*/
  {
    case 9: /*0x102d09633*/
      __asm /*0x102d09660*/
      {
        vpxorq xmm16, xmm16, xmmword ptr [rdi]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+10h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+20h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+30h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+40h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+50h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+60h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+70h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+80h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+90h]
        vaesenclast xmm16, xmm16, xmmword ptr [rdi+0A0h]
      }
      break;
    case 0xB: /*0x102d09633*/
      __asm /*0x102d096c0*/
      {
        vpxorq xmm16, xmm16, xmmword ptr [rdi]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+10h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+20h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+30h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+40h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+50h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+60h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+70h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+80h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+90h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+0A0h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+0B0h]
        vaesenclast xmm16, xmm16, xmmword ptr [rdi+0C0h]
      }
      break;
    case 0xD: /*0x102d09633*/
      __asm /*0x102d09720*/
      {
        vpxorq xmm16, xmm16, xmmword ptr [rdi]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+10h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+20h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+30h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+40h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+50h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+60h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+70h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+80h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+90h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+0A0h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+0B0h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+0C0h]
        vaesenc xmm16, xmm16, xmmword ptr [rdi+0D0h]
        vaesenclast xmm16, xmm16, xmmword ptr [rdi+0E0h]
      }
      break;
    default:
      break; /*0x102d09633*/
  }
  __asm /*0x102d0978a*/
  {
    vpshufb xmm16, xmm16, xmmword ptr cs:SHUF_MASK
    vmovdqa64 xmm2, xmm16
    vpsllq xmm16, xmm16, 1
    vpsrlq xmm2, xmm2, 3Fh ; '?'
    vmovdqa xmm1, xmm2
    vpslldq xmm2, xmm2, 8
    vpsrldq xmm1, xmm1, 8
    vporq xmm16, xmm16, xmm2
    vpshufd xmm2, xmm1, 24h ; '$'
    vpcmpeqd xmm2, xmm2, cs:TWOONE
    vpand xmm2, xmm2, cs:POLY
    vpxorq xmm16, xmm16, xmm2
    vmovdqu64 xmmword ptr [rsi+150h], xmm16
    vshufi32x4 ymm4, ymm16, ymm16, 0
    vmovdqa ymm3, ymm4
    vpclmulqdq ymm0, ymm3, ymm4, 11h
    vpclmulqdq ymm1, ymm3, ymm4, 0
    vpclmulqdq ymm2, ymm3, ymm4, 1
    vpclmulqdq ymm3, ymm3, ymm4, 10h
    vpxorq ymm3, ymm3, ymm2
    vpsrldq ymm2, ymm3, 8
    vpslldq ymm3, ymm3, 8
    vpxorq ymm0, ymm0, ymm2
    vpxorq ymm3, ymm3, ymm1
    vmovdqu64 ymm2, ymmword ptr cs:POLY2
    vpclmulqdq ymm1, ymm2, ymm3, 1
    vpslldq ymm1, ymm1, 8
    vpxorq ymm3, ymm3, ymm1
    vpclmulqdq ymm1, ymm2, ymm3, 0
    vpsrldq ymm1, ymm1, 4
    vpclmulqdq ymm3, ymm2, ymm3, 10h
    vpslldq ymm3, ymm3, 4
    vpternlogq ymm3, ymm0, ymm1, 96h
    vmovdqu64 xmmword ptr [rsi+140h], xmm3
    vinserti64x2 ymm4, ymm3, xmm16, 1
    vmovdqa64 ymm5, ymm4
    vpclmulqdq ymm0, ymm4, ymm3, 11h
    vpclmulqdq ymm1, ymm4, ymm3, 0
    vpclmulqdq ymm2, ymm4, ymm3, 1
    vpclmulqdq ymm4, ymm4, ymm3, 10h
    vpxorq ymm4, ymm4, ymm2
    vpsrldq ymm2, ymm4, 8
    vpslldq ymm4, ymm4, 8
    vpxorq ymm0, ymm0, ymm2
    vpxorq ymm4, ymm4, ymm1
    vmovdqu64 ymm2, ymmword ptr cs:POLY2
    vpclmulqdq ymm1, ymm2, ymm4, 1
    vpslldq ymm1, ymm1, 8
    vpxorq ymm4, ymm4, ymm1
    vpclmulqdq ymm1, ymm2, ymm4, 0
    vpsrldq ymm1, ymm1, 4
    vpclmulqdq ymm4, ymm2, ymm4, 10h
    vpslldq ymm4, ymm4, 4
    vpternlogq ymm4, ymm0, ymm1, 96h
    vmovdqu64 ymmword ptr [rsi+120h], ymm4
    vinserti64x4 zmm4, zmm4, ymm5, 1
    vshufi64x2 zmm3, zmm4, zmm4, 0
    vmovdqa64 zmm5, zmm4
    vpclmulqdq zmm0, zmm4, zmm3, 11h
    vpclmulqdq zmm1, zmm4, zmm3, 0
    vpclmulqdq zmm2, zmm4, zmm3, 1
    vpclmulqdq zmm4, zmm4, zmm3, 10h
    vpxorq zmm4, zmm4, zmm2
    vpsrldq zmm2, zmm4, 8
    vpslldq zmm4, zmm4, 8
    vpxorq zmm0, zmm0, zmm2
    vpxorq zmm4, zmm4, zmm1
    vmovdqu64 zmm2, zmmword ptr cs:POLY2
    vpclmulqdq zmm1, zmm2, zmm4, 1
    vpslldq zmm1, zmm1, 8
    vpxorq zmm4, zmm4, zmm1
    vpclmulqdq zmm1, zmm2, zmm4, 0
    vpsrldq zmm1, zmm1, 4
    vpclmulqdq zmm4, zmm2, zmm4, 10h
    vpslldq zmm4, zmm4, 4
    vpternlogq zmm4, zmm0, zmm1, 96h
    vmovdqu64 zmmword ptr [rsi+0E0h], zmm4
    vshufi64x2 zmm3, zmm4, zmm4, 0
    vpclmulqdq zmm0, zmm5, zmm3, 11h
    vpclmulqdq zmm1, zmm5, zmm3, 0
    vpclmulqdq zmm2, zmm5, zmm3, 1
    vpclmulqdq zmm5, zmm5, zmm3, 10h
    vpxorq zmm5, zmm5, zmm2
    vpsrldq zmm2, zmm5, 8
    vpslldq zmm5, zmm5, 8
    vpxorq zmm0, zmm0, zmm2
    vpxorq zmm5, zmm5, zmm1
    vmovdqu64 zmm2, zmmword ptr cs:POLY2
    vpclmulqdq zmm1, zmm2, zmm5, 1
    vpslldq zmm1, zmm1, 8
    vpxorq zmm5, zmm5, zmm1
    vpclmulqdq zmm1, zmm2, zmm5, 0
    vpsrldq zmm1, zmm1, 4
    vpclmulqdq zmm5, zmm2, zmm5, 10h
    vpslldq zmm5, zmm5, 4
    vpternlogq zmm5, zmm0, zmm1, 96h
    vmovdqu64 zmmword ptr [rsi+0A0h], zmm5
    vpclmulqdq zmm0, zmm4, zmm3, 11h
    vpclmulqdq zmm1, zmm4, zmm3, 0
    vpclmulqdq zmm2, zmm4, zmm3, 1
    vpclmulqdq zmm4, zmm4, zmm3, 10h
    vpxorq zmm4, zmm4, zmm2
    vpsrldq zmm2, zmm4, 8
    vpslldq zmm4, zmm4, 8
    vpxorq zmm0, zmm0, zmm2
    vpxorq zmm4, zmm4, zmm1
    vmovdqu64 zmm2, zmmword ptr cs:POLY2
    vpclmulqdq zmm1, zmm2, zmm4, 1
    vpslldq zmm1, zmm1, 8
    vpxorq zmm4, zmm4, zmm1
    vpclmulqdq zmm1, zmm2, zmm4, 0
    vpsrldq zmm1, zmm1, 4
    vpclmulqdq zmm4, zmm2, zmm4, 10h
    vpslldq zmm4, zmm4, 4
    vpternlogq zmm4, zmm0, zmm1, 96h
    vmovdqu64 zmmword ptr [rsi+60h], zmm4
    vzeroupper
  }
  return result; /*0x102d09a8d*/
}

// Address: 0x102d09aa0 | Name: _ossl_aes_gcm_setiv_avx512
__int64 __fastcall ossl_aes_gcm_setiv_avx512(
        __int64 a1,
        _BYTE **_RSI,
        __int64 a3,
        __int64 a4,
        double a5,
        __m128 _XMM1,
        __m128 _XMM2,
        double a8,
        double a9,
        double a10,
        __m128 _XMM6)
{
  __int64 v19; // r11
  __int64 v20; // rbx
  unsigned int v509; // r11d
  __m512i v1285; // 0:rt1.64
  __m512i v1286; // 0:rt1.64
  __m512i v1287; // 0:rt1.64
  __m512i v1288; // 0:rt1.64
  __m512i v1289; // 0:rt1.64
  __m512i v1290; // 0:rt1.64
  __m512i v1291; // 0:rt1.64
  __m512i v1292; // 0:rt1.64
  __m512i v1293; // 0:rt1.64
  __m512i v1294; // 0:rt1.64
  __m512i v1295; // 0:rt1.64
  __m512i v1296; // 0:rt1.64
  __m512i v1297; // 0:rt1.64
  __m512i v1298; // 0:rt1.64
  __m512i v1299; // 0:rt1.64
  __m512i v1300; // 0:rt1.64
  __m512i v1301; // 0:rt1.64
  __m512i v1302; // 0:rt1.64
  __m512i v1303; // 0:rt1.64
  __m512i v1304; // 0:rt1.64
  __m512i v1305; // 0:rt1.64
  __m512i v1306; // 0:rt1.64
  __m512i v1307; // 0:rt1.64
  __m512i v1308; // 0:rt1.64
  __m512i v1309; // 0:rt1.64
  __m512i v1310; // 0:rt1.64
  __m512i v1311; // 0:rt1.64
  __m512i v1312; // 0:rt1.64
  __m512i v1313; // 0:rt1.64
  __m512i v1314; // 0:rt1.64
  __m512i v1315; // 0:rt1.64
  __m512i v1316; // 0:rt1.64
  __m512i v1317; // 0:rt1.64
  __m512i v1318; // 0:rt1.64
  __m512i v1319; // 0:rt1.64
  __m512i v1320; // 0:rt1.64
  __m512i v1321; // 0:rt1.64
  __m512i v1322; // 0:rt1.64
  __m512i v1323; // 0:rt1.64
  __m512i v1324; // 0:rt1.64
  __m512i v1325; // 0:rt1.64
  __m512i v1326; // 0:rt1.64
  __m512i v1327; // 0:rt1.64
  __m512i v1328; // 0:rt1.64
  __m512i v1329; // 0:rt1.64
  __m512i v1330; // 0:rt1.64
  __m512i v1331; // 0:rt1.64
  __m512i v1332; // 0:rt1.64
  __m512i v1333; // 0:rt1.64

  if ( a4 != 12 ) /*0x102d09ac1*/
  {
    __asm { vpxor xmm2, xmm2, xmm2 } /*0x102d09ac7*/
    _R10 = a3; /*0x102d09acb*/
    v19 = a4; /*0x102d09ace*/
    if ( a4 != 0 ) /*0x102d09ad4*/
    {
      v20 = 0; /*0x102d09ada*/
      __asm { vmovdqa64 zmm16, zmmword ptr cs:SHUF_MASK } /*0x102d09add*/
      while ( v19 >= 768 ) /*0x102d09aee*/
      {
        v1285 = *(__m512i *)_R10; /*0x102d09af4*/
        __asm { vmovdqu64 zmm11, zmmword ptr [r10] } /*0x102d09af4*/
        v1286 = *(__m512i *)(_R10 + 64); /*0x102d09afa*/
        __asm { vmovdqu64 zmm3, zmmword ptr [r10+40h] } /*0x102d09afa*/
        v1287 = *(__m512i *)(_R10 + 128); /*0x102d09b01*/
        __asm { vmovdqu64 zmm4, zmmword ptr [r10+80h] } /*0x102d09b01*/
        v1288 = *(__m512i *)(_R10 + 192); /*0x102d09b08*/
        __asm /*0x102d09b08*/
        {
          vmovdqu64 zmm5, zmmword ptr [r10+0C0h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb zmm4, zmm4, zmm16
          vpshufb zmm5, zmm5, zmm16
        }
        if ( v20 == 0 ) /*0x102d09b2a*/
        {
          __asm /*0x102d09b30*/
          {
            vmovdqu64 zmm1, zmmword ptr [rsi+120h]
            vmovdqu64 zmmword ptr [rsp+364h+var_A4], zmm1
            vmovdqu64 zmm9, zmmword ptr [rsi+0E0h]
            vmovdqu64 zmmword ptr [rsp+364h+var_E4], zmm9
            vshufi64x2 zmm9, zmm9, zmm9, 0
            vmovdqu64 zmm10, zmmword ptr [rsi+0A0h]
            vmovdqu64 zmmword ptr [rsp+364h+var_124], zmm10
            vmovdqu64 zmm12, zmmword ptr [rsi+60h]
            vmovdqu64 zmmword ptr [rsp+364h+var_164], zmm12
            vpclmulqdq zmm13, zmm10, zmm9, 11h
            vpclmulqdq zmm15, zmm10, zmm9, 0
            vpclmulqdq zmm17, zmm10, zmm9, 1
            vpclmulqdq zmm10, zmm10, zmm9, 10h
            vpxorq zmm10, zmm10, zmm17
            vpsrldq zmm17, zmm10, 8
            vpslldq zmm10, zmm10, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm10, zmm10, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm10, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm10, zmm10, zmm15
            vpclmulqdq zmm15, zmm17, zmm10, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm10, zmm17, zmm10, 10h
            vpslldq zmm10, zmm10, 4
            vpternlogq zmm10, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_1A4], zmm10
            vpclmulqdq zmm13, zmm12, zmm9, 11h
            vpclmulqdq zmm15, zmm12, zmm9, 0
            vpclmulqdq zmm17, zmm12, zmm9, 1
            vpclmulqdq zmm12, zmm12, zmm9, 10h
            vpxorq zmm12, zmm12, zmm17
            vpsrldq zmm17, zmm12, 8
            vpslldq zmm12, zmm12, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm12, zmm12, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm12, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm12, zmm12, zmm15
            vpclmulqdq zmm15, zmm17, zmm12, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm12, zmm17, zmm12, 10h
            vpslldq zmm12, zmm12, 4
            vpternlogq zmm12, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_1E4], zmm12
            vpclmulqdq zmm13, zmm10, zmm9, 11h
            vpclmulqdq zmm15, zmm10, zmm9, 0
            vpclmulqdq zmm17, zmm10, zmm9, 1
            vpclmulqdq zmm10, zmm10, zmm9, 10h
            vpxorq zmm10, zmm10, zmm17
            vpsrldq zmm17, zmm10, 8
            vpslldq zmm10, zmm10, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm10, zmm10, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm10, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm10, zmm10, zmm15
            vpclmulqdq zmm15, zmm17, zmm10, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm10, zmm17, zmm10, 10h
            vpslldq zmm10, zmm10, 4
            vpternlogq zmm10, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_224], zmm10
            vpclmulqdq zmm13, zmm12, zmm9, 11h
            vpclmulqdq zmm15, zmm12, zmm9, 0
            vpclmulqdq zmm17, zmm12, zmm9, 1
            vpclmulqdq zmm12, zmm12, zmm9, 10h
            vpxorq zmm12, zmm12, zmm17
            vpsrldq zmm17, zmm12, 8
            vpslldq zmm12, zmm12, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm12, zmm12, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm12, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm12, zmm12, zmm15
            vpclmulqdq zmm15, zmm17, zmm12, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm12, zmm17, zmm12, 10h
            vpslldq zmm12, zmm12, 4
            vpternlogq zmm12, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_264], zmm12
            vpclmulqdq zmm13, zmm10, zmm9, 11h
            vpclmulqdq zmm15, zmm10, zmm9, 0
            vpclmulqdq zmm17, zmm10, zmm9, 1
            vpclmulqdq zmm10, zmm10, zmm9, 10h
            vpxorq zmm10, zmm10, zmm17
            vpsrldq zmm17, zmm10, 8
            vpslldq zmm10, zmm10, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm10, zmm10, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm10, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm10, zmm10, zmm15
            vpclmulqdq zmm15, zmm17, zmm10, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm10, zmm17, zmm10, 10h
            vpslldq zmm10, zmm10, 4
            vpternlogq zmm10, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_2A4], zmm10
            vpclmulqdq zmm13, zmm12, zmm9, 11h
            vpclmulqdq zmm15, zmm12, zmm9, 0
            vpclmulqdq zmm17, zmm12, zmm9, 1
            vpclmulqdq zmm12, zmm12, zmm9, 10h
            vpxorq zmm12, zmm12, zmm17
            vpsrldq zmm17, zmm12, 8
            vpslldq zmm12, zmm12, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm12, zmm12, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm12, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm12, zmm12, zmm15
            vpclmulqdq zmm15, zmm17, zmm12, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm12, zmm17, zmm12, 10h
            vpslldq zmm12, zmm12, 4
            vpternlogq zmm12, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_2E4], zmm12
            vpclmulqdq zmm13, zmm10, zmm9, 11h
            vpclmulqdq zmm15, zmm10, zmm9, 0
            vpclmulqdq zmm17, zmm10, zmm9, 1
            vpclmulqdq zmm10, zmm10, zmm9, 10h
            vpxorq zmm10, zmm10, zmm17
            vpsrldq zmm17, zmm10, 8
            vpslldq zmm10, zmm10, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm10, zmm10, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm10, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm10, zmm10, zmm15
            vpclmulqdq zmm15, zmm17, zmm10, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm10, zmm17, zmm10, 10h
            vpslldq zmm10, zmm10, 4
            vpternlogq zmm10, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_324], zmm10
            vpclmulqdq zmm13, zmm12, zmm9, 11h
            vpclmulqdq zmm15, zmm12, zmm9, 0
            vpclmulqdq zmm17, zmm12, zmm9, 1
            vpclmulqdq zmm12, zmm12, zmm9, 10h
            vpxorq zmm12, zmm12, zmm17
            vpsrldq zmm17, zmm12, 8
            vpslldq zmm12, zmm12, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm12, zmm12, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm12, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm12, zmm12, zmm15
            vpclmulqdq zmm15, zmm17, zmm12, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm12, zmm17, zmm12, 10h
            vpslldq zmm12, zmm12, 4
            vpternlogq zmm12, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_364], zmm12
          }
        }
        v20 = 1; /*0x102d09fa6*/
        __asm /*0x102d09fad*/
        {
          vpxorq zmm11, zmm11, zmm2
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_364]
          vpclmulqdq zmm1, zmm11, zmm19, 11h
          vpclmulqdq zmm9, zmm11, zmm19, 0
          vpclmulqdq zmm10, zmm11, zmm19, 1
          vpclmulqdq zmm12, zmm11, zmm19, 10h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_324]
          vpclmulqdq zmm13, zmm3, zmm19, 11h
          vpclmulqdq zmm15, zmm3, zmm19, 0
          vpclmulqdq zmm17, zmm3, zmm19, 1
          vpclmulqdq zmm18, zmm3, zmm19, 10h
          vpxorq zmm7, zmm10, zmm17
          vpxorq zmm6, zmm1, zmm13
          vpxorq zmm8, zmm9, zmm15
          vpternlogq zmm7, zmm12, zmm18, 96h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_2E4]
          vpclmulqdq zmm1, zmm4, zmm19, 11h
          vpclmulqdq zmm9, zmm4, zmm19, 0
          vpclmulqdq zmm10, zmm4, zmm19, 1
          vpclmulqdq zmm12, zmm4, zmm19, 10h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_2A4]
          vpclmulqdq zmm13, zmm5, zmm19, 11h
          vpclmulqdq zmm15, zmm5, zmm19, 0
          vpclmulqdq zmm17, zmm5, zmm19, 1
          vpclmulqdq zmm18, zmm5, zmm19, 10h
          vpternlogq zmm7, zmm10, zmm17, 96h
          vpternlogq zmm6, zmm1, zmm13, 96h
          vpternlogq zmm8, zmm9, zmm15, 96h
          vpternlogq zmm7, zmm12, zmm18, 96h
        }
        v1289 = *(__m512i *)(_R10 + 256); /*0x102d0a077*/
        __asm { vmovdqu64 zmm11, zmmword ptr [r10+100h] } /*0x102d0a077*/
        v1290 = *(__m512i *)(_R10 + 320); /*0x102d0a07e*/
        __asm { vmovdqu64 zmm3, zmmword ptr [r10+140h] } /*0x102d0a07e*/
        v1291 = *(__m512i *)(_R10 + 384); /*0x102d0a085*/
        __asm { vmovdqu64 zmm4, zmmword ptr [r10+180h] } /*0x102d0a085*/
        v1292 = *(__m512i *)(_R10 + 448); /*0x102d0a08c*/
        __asm /*0x102d0a08c*/
        {
          vmovdqu64 zmm5, zmmword ptr [r10+1C0h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb zmm4, zmm4, zmm16
          vpshufb zmm5, zmm5, zmm16
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_264]
          vpclmulqdq zmm1, zmm11, zmm19, 11h
          vpclmulqdq zmm9, zmm11, zmm19, 0
          vpclmulqdq zmm10, zmm11, zmm19, 1
          vpclmulqdq zmm12, zmm11, zmm19, 10h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_224]
          vpclmulqdq zmm13, zmm3, zmm19, 11h
          vpclmulqdq zmm15, zmm3, zmm19, 0
          vpclmulqdq zmm17, zmm3, zmm19, 1
          vpclmulqdq zmm18, zmm3, zmm19, 10h
          vpternlogq zmm7, zmm10, zmm17, 96h
          vpternlogq zmm6, zmm1, zmm13, 96h
          vpternlogq zmm8, zmm9, zmm15, 96h
          vpternlogq zmm7, zmm12, zmm18, 96h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_1E4]
          vpclmulqdq zmm1, zmm4, zmm19, 11h
          vpclmulqdq zmm9, zmm4, zmm19, 0
          vpclmulqdq zmm10, zmm4, zmm19, 1
          vpclmulqdq zmm12, zmm4, zmm19, 10h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_1A4]
          vpclmulqdq zmm13, zmm5, zmm19, 11h
          vpclmulqdq zmm15, zmm5, zmm19, 0
          vpclmulqdq zmm17, zmm5, zmm19, 1
          vpclmulqdq zmm18, zmm5, zmm19, 10h
          vpternlogq zmm7, zmm10, zmm17, 96h
          vpternlogq zmm6, zmm1, zmm13, 96h
          vpternlogq zmm8, zmm9, zmm15, 96h
          vpternlogq zmm7, zmm12, zmm18, 96h
        }
        v1293 = *(__m512i *)(_R10 + 512); /*0x102d0a173*/
        __asm { vmovdqu64 zmm11, zmmword ptr [r10+200h] } /*0x102d0a173*/
        v1294 = *(__m512i *)(_R10 + 576); /*0x102d0a17a*/
        __asm { vmovdqu64 zmm3, zmmword ptr [r10+240h] } /*0x102d0a17a*/
        v1295 = *(__m512i *)(_R10 + 640); /*0x102d0a181*/
        __asm { vmovdqu64 zmm4, zmmword ptr [r10+280h] } /*0x102d0a181*/
        v1296 = *(__m512i *)(_R10 + 704); /*0x102d0a188*/
        __asm /*0x102d0a188*/
        {
          vmovdqu64 zmm5, zmmword ptr [r10+2C0h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb zmm4, zmm4, zmm16
          vpshufb zmm5, zmm5, zmm16
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_164]
          vpclmulqdq zmm1, zmm11, zmm19, 11h
          vpclmulqdq zmm9, zmm11, zmm19, 0
          vpclmulqdq zmm10, zmm11, zmm19, 1
          vpclmulqdq zmm12, zmm11, zmm19, 10h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_124]
          vpclmulqdq zmm13, zmm3, zmm19, 11h
          vpclmulqdq zmm15, zmm3, zmm19, 0
          vpclmulqdq zmm17, zmm3, zmm19, 1
          vpclmulqdq zmm18, zmm3, zmm19, 10h
          vpternlogq zmm7, zmm10, zmm17, 96h
          vpternlogq zmm6, zmm1, zmm13, 96h
          vpternlogq zmm8, zmm9, zmm15, 96h
          vpternlogq zmm7, zmm12, zmm18, 96h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_E4]
          vpclmulqdq zmm1, zmm4, zmm19, 11h
          vpclmulqdq zmm9, zmm4, zmm19, 0
          vpclmulqdq zmm10, zmm4, zmm19, 1
          vpclmulqdq zmm12, zmm4, zmm19, 10h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_A4]
          vpclmulqdq zmm13, zmm5, zmm19, 11h
          vpclmulqdq zmm15, zmm5, zmm19, 0
          vpclmulqdq zmm17, zmm5, zmm19, 1
          vpclmulqdq zmm18, zmm5, zmm19, 10h
          vpternlogq zmm7, zmm10, zmm17, 96h
          vpternlogq zmm6, zmm1, zmm13, 96h
          vpternlogq zmm8, zmm9, zmm15, 96h
          vpternlogq zmm7, zmm12, zmm18, 96h
          vpsrldq zmm1, zmm7, 8
          vpslldq zmm9, zmm7, 8
          vpxorq zmm6, zmm6, zmm1
          vpxorq zmm8, zmm8, zmm9
          vextracti64x4 ymm1, zmm6, 1
          vpxorq ymm6, ymm6, ymm1
          vextracti32x4 xmm1, ymm6, 1
          vpxorq xmm6, xmm6, xmm1
          vextracti64x4 ymm9, zmm8, 1
          vpxorq ymm8, ymm8, ymm9
          vextracti32x4 xmm9, ymm8, 1
          vpxorq xmm8, xmm8, xmm9
          vmovdqa64 xmm10, xmmword ptr cs:POLY2
          vpclmulqdq xmm1, xmm10, xmm8, 1
          vpslldq xmm1, xmm1, 8
          vpxorq xmm1, xmm8, xmm1
          vpclmulqdq xmm9, xmm10, xmm1, 0
          vpsrldq xmm9, xmm9, 4
          vpclmulqdq xmm2, xmm10, xmm1, 10h
          vpslldq xmm2, xmm2, 4
          vpternlogq xmm2, xmm9, xmm6, 96h
        }
        v19 -= 768; /*0x102d0a2f6*/
        if ( v19 == 0 ) /*0x102d0a2fd*/
          goto LABEL_48; /*0x102d0a2fd*/
        _R10 += 768; /*0x102d0a303*/
      }
      if ( v19 >= 512 ) /*0x102d0a316*/
      {
        v1297 = *(__m512i *)_R10; /*0x102d0a31c*/
        __asm { vmovdqu64 zmm11, zmmword ptr [r10] } /*0x102d0a31c*/
        v1298 = *(__m512i *)(_R10 + 64); /*0x102d0a322*/
        __asm { vmovdqu64 zmm3, zmmword ptr [r10+40h] } /*0x102d0a322*/
        v1299 = *(__m512i *)(_R10 + 128); /*0x102d0a329*/
        __asm { vmovdqu64 zmm4, zmmword ptr [r10+80h] } /*0x102d0a329*/
        v1300 = *(__m512i *)(_R10 + 192); /*0x102d0a330*/
        __asm /*0x102d0a330*/
        {
          vmovdqu64 zmm5, zmmword ptr [r10+0C0h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb zmm4, zmm4, zmm16
          vpshufb zmm5, zmm5, zmm16
        }
        if ( v20 == 0 ) /*0x102d0a352*/
        {
          __asm /*0x102d0a358*/
          {
            vmovdqu64 zmm1, zmmword ptr [rsi+120h]
            vmovdqu64 zmmword ptr [rsp+364h+var_A4], zmm1
            vmovdqu64 zmm9, zmmword ptr [rsi+0E0h]
            vmovdqu64 zmmword ptr [rsp+364h+var_E4], zmm9
            vshufi64x2 zmm9, zmm9, zmm9, 0
            vmovdqu64 zmm10, zmmword ptr [rsi+0A0h]
            vmovdqu64 zmmword ptr [rsp+364h+var_124], zmm10
            vmovdqu64 zmm12, zmmword ptr [rsi+60h]
            vmovdqu64 zmmword ptr [rsp+364h+var_164], zmm12
            vpclmulqdq zmm13, zmm10, zmm9, 11h
            vpclmulqdq zmm15, zmm10, zmm9, 0
            vpclmulqdq zmm17, zmm10, zmm9, 1
            vpclmulqdq zmm10, zmm10, zmm9, 10h
            vpxorq zmm10, zmm10, zmm17
            vpsrldq zmm17, zmm10, 8
            vpslldq zmm10, zmm10, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm10, zmm10, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm10, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm10, zmm10, zmm15
            vpclmulqdq zmm15, zmm17, zmm10, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm10, zmm17, zmm10, 10h
            vpslldq zmm10, zmm10, 4
            vpternlogq zmm10, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_1A4], zmm10
            vpclmulqdq zmm13, zmm12, zmm9, 11h
            vpclmulqdq zmm15, zmm12, zmm9, 0
            vpclmulqdq zmm17, zmm12, zmm9, 1
            vpclmulqdq zmm12, zmm12, zmm9, 10h
            vpxorq zmm12, zmm12, zmm17
            vpsrldq zmm17, zmm12, 8
            vpslldq zmm12, zmm12, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm12, zmm12, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm12, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm12, zmm12, zmm15
            vpclmulqdq zmm15, zmm17, zmm12, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm12, zmm17, zmm12, 10h
            vpslldq zmm12, zmm12, 4
            vpternlogq zmm12, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_1E4], zmm12
            vpclmulqdq zmm13, zmm10, zmm9, 11h
            vpclmulqdq zmm15, zmm10, zmm9, 0
            vpclmulqdq zmm17, zmm10, zmm9, 1
            vpclmulqdq zmm10, zmm10, zmm9, 10h
            vpxorq zmm10, zmm10, zmm17
            vpsrldq zmm17, zmm10, 8
            vpslldq zmm10, zmm10, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm10, zmm10, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm10, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm10, zmm10, zmm15
            vpclmulqdq zmm15, zmm17, zmm10, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm10, zmm17, zmm10, 10h
            vpslldq zmm10, zmm10, 4
            vpternlogq zmm10, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_224], zmm10
            vpclmulqdq zmm13, zmm12, zmm9, 11h
            vpclmulqdq zmm15, zmm12, zmm9, 0
            vpclmulqdq zmm17, zmm12, zmm9, 1
            vpclmulqdq zmm12, zmm12, zmm9, 10h
            vpxorq zmm12, zmm12, zmm17
            vpsrldq zmm17, zmm12, 8
            vpslldq zmm12, zmm12, 8
            vpxorq zmm13, zmm13, zmm17
            vpxorq zmm12, zmm12, zmm15
            vmovdqu64 zmm17, zmmword ptr cs:POLY2
            vpclmulqdq zmm15, zmm17, zmm12, 1
            vpslldq zmm15, zmm15, 8
            vpxorq zmm12, zmm12, zmm15
            vpclmulqdq zmm15, zmm17, zmm12, 0
            vpsrldq zmm15, zmm15, 4
            vpclmulqdq zmm12, zmm17, zmm12, 10h
            vpslldq zmm12, zmm12, 4
            vpternlogq zmm12, zmm13, zmm15, 96h
            vmovdqu64 zmmword ptr [rsp+364h+var_264], zmm12
          }
        }
        __asm /*0x102d0a5c2*/
        {
          vpxorq zmm11, zmm11, zmm2
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_264]
          vpclmulqdq zmm1, zmm11, zmm19, 11h
          vpclmulqdq zmm9, zmm11, zmm19, 0
          vpclmulqdq zmm10, zmm11, zmm19, 1
          vpclmulqdq zmm12, zmm11, zmm19, 10h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_224]
          vpclmulqdq zmm13, zmm3, zmm19, 11h
          vpclmulqdq zmm15, zmm3, zmm19, 0
          vpclmulqdq zmm17, zmm3, zmm19, 1
          vpclmulqdq zmm18, zmm3, zmm19, 10h
          vpxorq zmm7, zmm10, zmm17
          vpxorq zmm6, zmm1, zmm13
          vpxorq zmm8, zmm9, zmm15
          vpternlogq zmm7, zmm12, zmm18, 96h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_1E4]
          vpclmulqdq zmm1, zmm4, zmm19, 11h
          vpclmulqdq zmm9, zmm4, zmm19, 0
          vpclmulqdq zmm10, zmm4, zmm19, 1
          vpclmulqdq zmm12, zmm4, zmm19, 10h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_1A4]
          vpclmulqdq zmm13, zmm5, zmm19, 11h
          vpclmulqdq zmm15, zmm5, zmm19, 0
          vpclmulqdq zmm17, zmm5, zmm19, 1
          vpclmulqdq zmm18, zmm5, zmm19, 10h
          vpternlogq zmm7, zmm10, zmm17, 96h
          vpternlogq zmm6, zmm1, zmm13, 96h
          vpternlogq zmm8, zmm9, zmm15, 96h
          vpternlogq zmm7, zmm12, zmm18, 96h
        }
        v1301 = *(__m512i *)(_R10 + 256); /*0x102d0a68d*/
        __asm { vmovdqu64 zmm11, zmmword ptr [r10+100h] } /*0x102d0a68d*/
        v1302 = *(__m512i *)(_R10 + 320); /*0x102d0a694*/
        __asm { vmovdqu64 zmm3, zmmword ptr [r10+140h] } /*0x102d0a694*/
        v1303 = *(__m512i *)(_R10 + 384); /*0x102d0a69b*/
        __asm { vmovdqu64 zmm4, zmmword ptr [r10+180h] } /*0x102d0a69b*/
        v1304 = *(__m512i *)(_R10 + 448); /*0x102d0a6a2*/
        __asm /*0x102d0a6a2*/
        {
          vmovdqu64 zmm5, zmmword ptr [r10+1C0h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb zmm4, zmm4, zmm16
          vpshufb zmm5, zmm5, zmm16
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_164]
          vpclmulqdq zmm1, zmm11, zmm19, 11h
          vpclmulqdq zmm9, zmm11, zmm19, 0
          vpclmulqdq zmm10, zmm11, zmm19, 1
          vpclmulqdq zmm12, zmm11, zmm19, 10h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_124]
          vpclmulqdq zmm13, zmm3, zmm19, 11h
          vpclmulqdq zmm15, zmm3, zmm19, 0
          vpclmulqdq zmm17, zmm3, zmm19, 1
          vpclmulqdq zmm18, zmm3, zmm19, 10h
          vpternlogq zmm7, zmm10, zmm17, 96h
          vpternlogq zmm6, zmm1, zmm13, 96h
          vpternlogq zmm8, zmm9, zmm15, 96h
          vpternlogq zmm7, zmm12, zmm18, 96h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_E4]
          vpclmulqdq zmm1, zmm4, zmm19, 11h
          vpclmulqdq zmm9, zmm4, zmm19, 0
          vpclmulqdq zmm10, zmm4, zmm19, 1
          vpclmulqdq zmm12, zmm4, zmm19, 10h
          vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_A4]
          vpclmulqdq zmm13, zmm5, zmm19, 11h
          vpclmulqdq zmm15, zmm5, zmm19, 0
          vpclmulqdq zmm17, zmm5, zmm19, 1
          vpclmulqdq zmm18, zmm5, zmm19, 10h
          vpternlogq zmm7, zmm10, zmm17, 96h
          vpternlogq zmm6, zmm1, zmm13, 96h
          vpternlogq zmm8, zmm9, zmm15, 96h
          vpternlogq zmm7, zmm12, zmm18, 96h
          vpsrldq zmm1, zmm7, 8
          vpslldq zmm9, zmm7, 8
          vpxorq zmm6, zmm6, zmm1
          vpxorq zmm8, zmm8, zmm9
          vextracti64x4 ymm1, zmm6, 1
          vpxorq ymm6, ymm6, ymm1
          vextracti32x4 xmm1, ymm6, 1
          vpxorq xmm6, xmm6, xmm1
          vextracti64x4 ymm9, zmm8, 1
          vpxorq ymm8, ymm8, ymm9
          vextracti32x4 xmm9, ymm8, 1
          vpxorq xmm8, xmm8, xmm9
          vmovdqa64 xmm10, xmmword ptr cs:POLY2
          vpclmulqdq xmm1, xmm10, xmm8, 1
          vpslldq xmm1, xmm1, 8
          vpxorq xmm1, xmm8, xmm1
          vpclmulqdq xmm9, xmm10, xmm1, 0
          vpsrldq xmm9, xmm9, 4
          vpclmulqdq xmm2, xmm10, xmm1, 10h
          vpslldq xmm2, xmm2, 4
          vpternlogq xmm2, xmm9, xmm6, 96h
        }
        v19 -= 512; /*0x102d0a810*/
        if ( v19 == 0 ) /*0x102d0a817*/
          goto LABEL_48; /*0x102d0a817*/
        _R10 += 512; /*0x102d0a81d*/
        goto LABEL_17; /*0x102d0a824*/
      }
      if ( v19 < 256 ) /*0x102d0a830*/
      {
LABEL_17:
        _R12 = (char *)&byte64_len_to_mask_table + 8 * v19; /*0x102d0a9d7*/
        v509 = (unsigned int)(v19 + 15) >> 4; /*0x102d0a9e6*/
        if ( v509 < 2 ) /*0x102d0a9ee*/
        {
          __asm /*0x102d0bd69*/
          {
            kmovq k1, qword ptr [r12]
            vmovdqu8 xmm11{k1}{z}, xmmword ptr [r10]
            vpshufb xmm11, xmm11, xmm16
            vpxorq zmm11, zmm11, zmm2
            vmovdqu64 xmm15, xmmword ptr [rsi+150h]
            vpclmulqdq xmm7, xmm11, xmm15, 1
            vpclmulqdq xmm8, xmm11, xmm15, 10h
            vpclmulqdq xmm1, xmm11, xmm15, 11h
            vpclmulqdq xmm6, xmm11, xmm15, 0
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 == 2 ) /*0x102d0a9f4*/
        {
          __asm /*0x102d0bca0*/
          {
            kmovq k1, qword ptr [r12]
            vmovdqu8 ymm11{k1}{z}, ymmword ptr [r10]
            vpshufb ymm11, ymm11, ymm16
            vpxorq zmm11, zmm11, zmm2
            vmovdqu64 ymm15, ymmword ptr [rsi+140h]
            vpclmulqdq ymm7, ymm11, ymm15, 1
            vpclmulqdq ymm8, ymm11, ymm15, 10h
            vpclmulqdq ymm1, ymm11, ymm15, 11h
            vpclmulqdq ymm6, ymm11, ymm15, 0
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 < 4 ) /*0x102d0a9fe*/
        {
          __asm { kmovq k1, qword ptr [r12] } /*0x102d0bbc8*/
          v1333 = *(__m512i *)_R10; /*0x102d0bbce*/
          __asm /*0x102d0bbce*/
          {
            vmovdqu8 zmm11{k1}{z}, zmmword ptr [r10]
            vpshufb zmm11, zmm11, zmm16
            vpxorq zmm11, zmm11, zmm2
            vmovdqu64 ymm15, ymmword ptr [rsi+130h]
            vinserti64x2 zmm15, zmm15, xmmword ptr [rsi+150h], 2
            vpclmulqdq zmm7, zmm11, zmm15, 1
            vpclmulqdq zmm8, zmm11, zmm15, 10h
            vpclmulqdq zmm1, zmm11, zmm15, 11h
            vpclmulqdq zmm6, zmm11, zmm15, 0
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 == 4 ) /*0x102d0aa04*/
        {
          __asm /*0x102d0baf8*/
          {
            kmovq k1, qword ptr [r12]
            vmovdqu8 zmm11{k1}{z}, zmmword ptr [r10]
            vpshufb zmm11, zmm11, zmm16
            vpxorq zmm11, zmm11, zmm2
            vmovdqu64 zmm15, zmmword ptr [rsi+120h]
            vpclmulqdq zmm9, zmm11, zmm15, 11h
            vpclmulqdq zmm10, zmm11, zmm15, 0
            vpclmulqdq zmm12, zmm11, zmm15, 1
            vpclmulqdq zmm13, zmm11, zmm15, 10h
            vpxorq zmm12, zmm12, zmm13
            vpsrldq zmm7, zmm12, 8
            vpslldq zmm8, zmm12, 8
            vpxorq zmm1, zmm9, zmm7
            vpxorq zmm6, zmm10, zmm8
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 < 6 ) /*0x102d0aa0e*/
        {
          _R12 = _R12 - 512; /*0x102d0b9dd*/
          __asm { kmovq k1, qword ptr [r12] } /*0x102d0b9e4*/
          v1331 = *(__m512i *)_R10; /*0x102d0b9ea*/
          __asm /*0x102d0b9ea*/
          {
            vmovdqu8 zmm11, zmmword ptr [r10]
            vmovdqu8 xmm3{k1}{z}, xmmword ptr [r10+40h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb xmm3, xmm3, xmm16
            vpxorq zmm11, zmm11, zmm2
          }
          v1332 = *(__m512i *)(_RSI + 34); /*0x102d0ba09*/
          __asm /*0x102d0ba09*/
          {
            vmovdqu64 zmm15, zmmword ptr [rsi+110h]
            vpclmulqdq zmm9, zmm11, zmm15, 11h
            vpclmulqdq zmm10, zmm11, zmm15, 0
            vpclmulqdq zmm12, zmm11, zmm15, 1
            vpclmulqdq zmm13, zmm11, zmm15, 10h
            vmovdqu64 xmm15, xmmword ptr [rsi+150h]
            vpclmulqdq xmm7, xmm3, xmm15, 1
            vpclmulqdq xmm8, xmm3, xmm15, 10h
            vpclmulqdq xmm1, xmm3, xmm15, 11h
            vpclmulqdq xmm6, xmm3, xmm15, 0
            vpxorq zmm7, zmm7, zmm12
            vpxorq zmm8, zmm8, zmm13
            vpxorq zmm1, zmm1, zmm9
            vpxorq zmm6, zmm6, zmm10
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 == 6 ) /*0x102d0aa14*/
        {
          _R12 = _R12 - 512; /*0x102d0b8c5*/
          __asm /*0x102d0b8cc*/
          {
            kmovq k1, qword ptr [r12]
            vmovdqu8 zmm11, zmmword ptr [r10]
            vmovdqu8 ymm3{k1}{z}, ymmword ptr [r10+40h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb ymm3, ymm3, ymm16
            vpxorq zmm11, zmm11, zmm2
            vmovdqu64 zmm15, zmmword ptr [rsi+100h]
            vpclmulqdq zmm9, zmm11, zmm15, 11h
            vpclmulqdq zmm10, zmm11, zmm15, 0
            vpclmulqdq zmm12, zmm11, zmm15, 1
            vpclmulqdq zmm13, zmm11, zmm15, 10h
            vmovdqu64 ymm15, ymmword ptr [rsi+140h]
            vpclmulqdq ymm7, ymm3, ymm15, 1
            vpclmulqdq ymm8, ymm3, ymm15, 10h
            vpclmulqdq ymm1, ymm3, ymm15, 11h
            vpclmulqdq ymm6, ymm3, ymm15, 0
            vpxorq zmm7, zmm7, zmm12
            vpxorq zmm8, zmm8, zmm13
            vpxorq zmm1, zmm1, zmm9
            vpxorq zmm6, zmm6, zmm10
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 < 8 ) /*0x102d0aa1e*/
        {
          _R12 = _R12 - 512; /*0x102d0b79b*/
          __asm { kmovq k1, qword ptr [r12] } /*0x102d0b7a2*/
          v1328 = *(__m512i *)_R10; /*0x102d0b7a8*/
          __asm { vmovdqu8 zmm11, zmmword ptr [r10] } /*0x102d0b7a8*/
          v1329 = *(__m512i *)(_R10 + 64); /*0x102d0b7ae*/
          __asm /*0x102d0b7ae*/
          {
            vmovdqu8 zmm3{k1}{z}, zmmword ptr [r10+40h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb zmm3, zmm3, zmm16
            vpxorq zmm11, zmm11, zmm2
          }
          v1330 = *(__m512i *)(_RSI + 30); /*0x102d0b7c7*/
          __asm /*0x102d0b7c7*/
          {
            vmovdqu64 zmm15, zmmword ptr [rsi+0F0h]
            vpclmulqdq zmm9, zmm11, zmm15, 11h
            vpclmulqdq zmm10, zmm11, zmm15, 0
            vpclmulqdq zmm12, zmm11, zmm15, 1
            vpclmulqdq zmm13, zmm11, zmm15, 10h
            vmovdqu64 ymm15, ymmword ptr [rsi+130h]
            vinserti64x2 zmm15, zmm15, xmmword ptr [rsi+150h], 2
            vpclmulqdq zmm7, zmm3, zmm15, 1
            vpclmulqdq zmm8, zmm3, zmm15, 10h
            vpclmulqdq zmm1, zmm3, zmm15, 11h
            vpclmulqdq zmm6, zmm3, zmm15, 0
            vpxorq zmm7, zmm7, zmm12
            vpxorq zmm8, zmm8, zmm13
            vpxorq zmm1, zmm1, zmm9
            vpxorq zmm6, zmm6, zmm10
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 == 8 ) /*0x102d0aa24*/
        {
          _R12 = _R12 - 512; /*0x102d0b679*/
          __asm /*0x102d0b680*/
          {
            kmovq k1, qword ptr [r12]
            vmovdqu8 zmm11, zmmword ptr [r10]
            vmovdqu8 zmm3{k1}{z}, zmmword ptr [r10+40h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb zmm3, zmm3, zmm16
            vpxorq zmm11, zmm11, zmm2
            vmovdqu64 zmm15, zmmword ptr [rsi+0E0h]
            vpclmulqdq zmm1, zmm11, zmm15, 11h
            vpclmulqdq zmm6, zmm11, zmm15, 0
            vpclmulqdq zmm7, zmm11, zmm15, 1
            vpclmulqdq zmm8, zmm11, zmm15, 10h
            vmovdqu64 zmm15, zmmword ptr [rsi+120h]
            vpclmulqdq zmm9, zmm3, zmm15, 11h
            vpclmulqdq zmm10, zmm3, zmm15, 0
            vpclmulqdq zmm12, zmm3, zmm15, 1
            vpclmulqdq zmm13, zmm3, zmm15, 10h
            vpxorq zmm9, zmm1, zmm9
            vpxorq zmm10, zmm6, zmm10
            vpxorq zmm12, zmm7, zmm12
            vpxorq zmm13, zmm8, zmm13
            vpxorq zmm12, zmm12, zmm13
            vpsrldq zmm7, zmm12, 8
            vpslldq zmm8, zmm12, 8
            vpxorq zmm1, zmm9, zmm7
            vpxorq zmm6, zmm10, zmm8
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 < 0xA ) /*0x102d0aa2e*/
        {
          _R12 = _R12 - 1024; /*0x102d0b513*/
          __asm { kmovq k1, qword ptr [r12] } /*0x102d0b51a*/
          v1324 = *(__m512i *)_R10; /*0x102d0b520*/
          __asm { vmovdqu8 zmm11, zmmword ptr [r10] } /*0x102d0b520*/
          v1325 = *(__m512i *)(_R10 + 64); /*0x102d0b526*/
          __asm /*0x102d0b526*/
          {
            vmovdqu8 zmm3, zmmword ptr [r10+40h]
            vmovdqu8 xmm4{k1}{z}, xmmword ptr [r10+80h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb zmm3, zmm3, zmm16
            vpshufb xmm4, xmm4, xmm16
            vpxorq zmm11, zmm11, zmm2
          }
          v1326 = *(__m512i *)(_RSI + 26); /*0x102d0b54c*/
          __asm /*0x102d0b54c*/
          {
            vmovdqu64 zmm15, zmmword ptr [rsi+0D0h]
            vpclmulqdq zmm1, zmm11, zmm15, 11h
            vpclmulqdq zmm6, zmm11, zmm15, 0
            vpclmulqdq zmm7, zmm11, zmm15, 1
            vpclmulqdq zmm8, zmm11, zmm15, 10h
          }
          v1327 = *(__m512i *)(_RSI + 34); /*0x102d0b572*/
          __asm /*0x102d0b572*/
          {
            vmovdqu64 zmm15, zmmword ptr [rsi+110h]
            vpclmulqdq zmm9, zmm3, zmm15, 11h
            vpclmulqdq zmm10, zmm3, zmm15, 0
            vpclmulqdq zmm12, zmm3, zmm15, 1
            vpclmulqdq zmm13, zmm3, zmm15, 10h
            vpxorq zmm9, zmm1, zmm9
            vpxorq zmm10, zmm6, zmm10
            vpxorq zmm12, zmm7, zmm12
            vpxorq zmm13, zmm8, zmm13
            vmovdqu64 xmm15, xmmword ptr [rsi+150h]
            vpclmulqdq xmm7, xmm4, xmm15, 1
            vpclmulqdq xmm8, xmm4, xmm15, 10h
            vpclmulqdq xmm1, xmm4, xmm15, 11h
            vpclmulqdq xmm6, xmm4, xmm15, 0
            vpxorq zmm7, zmm7, zmm12
            vpxorq zmm8, zmm8, zmm13
            vpxorq zmm1, zmm1, zmm9
            vpxorq zmm6, zmm6, zmm10
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 == 10 ) /*0x102d0aa34*/
        {
          _R12 = _R12 - 1024; /*0x102d0b3b3*/
          __asm /*0x102d0b3ba*/
          {
            kmovq k1, qword ptr [r12]
            vmovdqu8 zmm11, zmmword ptr [r10]
            vmovdqu8 zmm3, zmmword ptr [r10+40h]
            vmovdqu8 ymm4{k1}{z}, ymmword ptr [r10+80h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb zmm3, zmm3, zmm16
            vpshufb ymm4, ymm4, ymm16
            vpxorq zmm11, zmm11, zmm2
            vmovdqu64 zmm15, zmmword ptr [rsi+0C0h]
            vpclmulqdq zmm1, zmm11, zmm15, 11h
            vpclmulqdq zmm6, zmm11, zmm15, 0
            vpclmulqdq zmm7, zmm11, zmm15, 1
            vpclmulqdq zmm8, zmm11, zmm15, 10h
            vmovdqu64 zmm15, zmmword ptr [rsi+100h]
            vpclmulqdq zmm9, zmm3, zmm15, 11h
            vpclmulqdq zmm10, zmm3, zmm15, 0
            vpclmulqdq zmm12, zmm3, zmm15, 1
            vpclmulqdq zmm13, zmm3, zmm15, 10h
            vpxorq zmm9, zmm1, zmm9
            vpxorq zmm10, zmm6, zmm10
            vpxorq zmm12, zmm7, zmm12
            vpxorq zmm13, zmm8, zmm13
            vmovdqu64 ymm15, ymmword ptr [rsi+140h]
            vpclmulqdq ymm7, ymm4, ymm15, 1
            vpclmulqdq ymm8, ymm4, ymm15, 10h
            vpclmulqdq ymm1, ymm4, ymm15, 11h
            vpclmulqdq ymm6, ymm4, ymm15, 0
            vpxorq zmm7, zmm7, zmm12
            vpxorq zmm8, zmm8, zmm13
            vpxorq zmm1, zmm1, zmm9
            vpxorq zmm6, zmm6, zmm10
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 < 0xC ) /*0x102d0aa3e*/
        {
          _R12 = _R12 - 1024; /*0x102d0b23e*/
          __asm { kmovq k1, qword ptr [r12] } /*0x102d0b245*/
          v1319 = *(__m512i *)_R10; /*0x102d0b24b*/
          __asm { vmovdqu8 zmm11, zmmword ptr [r10] } /*0x102d0b24b*/
          v1320 = *(__m512i *)(_R10 + 64); /*0x102d0b251*/
          __asm { vmovdqu8 zmm3, zmmword ptr [r10+40h] } /*0x102d0b251*/
          v1321 = *(__m512i *)(_R10 + 128); /*0x102d0b258*/
          __asm /*0x102d0b258*/
          {
            vmovdqu8 zmm4{k1}{z}, zmmword ptr [r10+80h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb zmm3, zmm3, zmm16
            vpshufb zmm4, zmm4, zmm16
            vpxorq zmm11, zmm11, zmm2
          }
          v1322 = *(__m512i *)(_RSI + 22); /*0x102d0b277*/
          __asm /*0x102d0b277*/
          {
            vmovdqu64 zmm15, zmmword ptr [rsi+0B0h]
            vpclmulqdq zmm1, zmm11, zmm15, 11h
            vpclmulqdq zmm6, zmm11, zmm15, 0
            vpclmulqdq zmm7, zmm11, zmm15, 1
            vpclmulqdq zmm8, zmm11, zmm15, 10h
          }
          v1323 = *(__m512i *)(_RSI + 30); /*0x102d0b29d*/
          __asm /*0x102d0b29d*/
          {
            vmovdqu64 zmm15, zmmword ptr [rsi+0F0h]
            vpclmulqdq zmm9, zmm3, zmm15, 11h
            vpclmulqdq zmm10, zmm3, zmm15, 0
            vpclmulqdq zmm12, zmm3, zmm15, 1
            vpclmulqdq zmm13, zmm3, zmm15, 10h
            vpxorq zmm9, zmm1, zmm9
            vpxorq zmm10, zmm6, zmm10
            vpxorq zmm12, zmm7, zmm12
            vpxorq zmm13, zmm8, zmm13
            vmovdqu64 ymm15, ymmword ptr [rsi+130h]
            vinserti64x2 zmm15, zmm15, xmmword ptr [rsi+150h], 2
            vpclmulqdq zmm7, zmm4, zmm15, 1
            vpclmulqdq zmm8, zmm4, zmm15, 10h
            vpclmulqdq zmm1, zmm4, zmm15, 11h
            vpclmulqdq zmm6, zmm4, zmm15, 0
            vpxorq zmm7, zmm7, zmm12
            vpxorq zmm8, zmm8, zmm13
            vpxorq zmm1, zmm1, zmm9
            vpxorq zmm6, zmm6, zmm10
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 == 12 ) /*0x102d0aa44*/
        {
          _R12 = _R12 - 1024; /*0x102d0b0e5*/
          __asm /*0x102d0b0ec*/
          {
            kmovq k1, qword ptr [r12]
            vmovdqu8 zmm11, zmmword ptr [r10]
            vmovdqu8 zmm3, zmmword ptr [r10+40h]
            vmovdqu8 zmm4{k1}{z}, zmmword ptr [r10+80h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb zmm3, zmm3, zmm16
            vpshufb zmm4, zmm4, zmm16
            vpxorq zmm11, zmm11, zmm2
            vmovdqu64 zmm15, zmmword ptr [rsi+0A0h]
            vpclmulqdq zmm1, zmm11, zmm15, 11h
            vpclmulqdq zmm6, zmm11, zmm15, 0
            vpclmulqdq zmm7, zmm11, zmm15, 1
            vpclmulqdq zmm8, zmm11, zmm15, 10h
            vmovdqu64 zmm15, zmmword ptr [rsi+0E0h]
            vpclmulqdq zmm9, zmm3, zmm15, 11h
            vpclmulqdq zmm10, zmm3, zmm15, 0
            vpclmulqdq zmm12, zmm3, zmm15, 1
            vpclmulqdq zmm13, zmm3, zmm15, 10h
            vmovdqu64 zmm15, zmmword ptr [rsi+120h]
            vpclmulqdq zmm11, zmm4, zmm15, 11h
            vpclmulqdq zmm3, zmm4, zmm15, 0
            vpternlogq zmm9, zmm11, zmm1, 96h
            vpternlogq zmm10, zmm3, zmm6, 96h
            vpclmulqdq zmm11, zmm4, zmm15, 1
            vpclmulqdq zmm3, zmm4, zmm15, 10h
            vpternlogq zmm12, zmm11, zmm7, 96h
            vpternlogq zmm13, zmm3, zmm8, 96h
            vpxorq zmm12, zmm12, zmm13
            vpsrldq zmm7, zmm12, 8
            vpslldq zmm8, zmm12, 8
            vpxorq zmm1, zmm9, zmm7
            vpxorq zmm6, zmm10, zmm8
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 < 0xE ) /*0x102d0aa4e*/
        {
          _R12 = _R12 - 1536; /*0x102d0af48*/
          __asm { kmovq k1, qword ptr [r12] } /*0x102d0af4f*/
          v1313 = *(__m512i *)_R10; /*0x102d0af55*/
          __asm { vmovdqu8 zmm11, zmmword ptr [r10] } /*0x102d0af55*/
          v1314 = *(__m512i *)(_R10 + 64); /*0x102d0af5b*/
          __asm { vmovdqu8 zmm3, zmmword ptr [r10+40h] } /*0x102d0af5b*/
          v1315 = *(__m512i *)(_R10 + 128); /*0x102d0af62*/
          __asm /*0x102d0af62*/
          {
            vmovdqu8 zmm4, zmmword ptr [r10+80h]
            vmovdqu8 xmm5{k1}{z}, xmmword ptr [r10+0C0h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb zmm3, zmm3, zmm16
            vpshufb zmm4, zmm4, zmm16
            vpshufb xmm5, xmm5, xmm16
            vpxorq zmm11, zmm11, zmm2
          }
          v1316 = *(__m512i *)(_RSI + 18); /*0x102d0af8e*/
          __asm /*0x102d0af8e*/
          {
            vmovdqu64 zmm15, zmmword ptr [rsi+90h]
            vpclmulqdq zmm1, zmm11, zmm15, 11h
            vpclmulqdq zmm6, zmm11, zmm15, 0
            vpclmulqdq zmm7, zmm11, zmm15, 1
            vpclmulqdq zmm8, zmm11, zmm15, 10h
          }
          v1317 = *(__m512i *)(_RSI + 26); /*0x102d0afb4*/
          __asm /*0x102d0afb4*/
          {
            vmovdqu64 zmm15, zmmword ptr [rsi+0D0h]
            vpclmulqdq zmm9, zmm3, zmm15, 11h
            vpclmulqdq zmm10, zmm3, zmm15, 0
            vpclmulqdq zmm12, zmm3, zmm15, 1
            vpclmulqdq zmm13, zmm3, zmm15, 10h
          }
          v1318 = *(__m512i *)(_RSI + 34); /*0x102d0afda*/
          __asm /*0x102d0afda*/
          {
            vmovdqu64 zmm15, zmmword ptr [rsi+110h]
            vpclmulqdq zmm11, zmm4, zmm15, 11h
            vpclmulqdq zmm3, zmm4, zmm15, 0
            vpternlogq zmm9, zmm11, zmm1, 96h
            vpternlogq zmm10, zmm3, zmm6, 96h
            vpclmulqdq zmm11, zmm4, zmm15, 1
            vpclmulqdq zmm3, zmm4, zmm15, 10h
            vpternlogq zmm12, zmm11, zmm7, 96h
            vpternlogq zmm13, zmm3, zmm8, 96h
            vmovdqu64 xmm15, xmmword ptr [rsi+150h]
            vpclmulqdq xmm7, xmm5, xmm15, 1
            vpclmulqdq xmm8, xmm5, xmm15, 10h
            vpclmulqdq xmm1, xmm5, xmm15, 11h
            vpclmulqdq xmm6, xmm5, xmm15, 0
            vpxorq zmm7, zmm7, zmm12
            vpxorq zmm8, zmm8, zmm13
            vpxorq zmm1, zmm1, zmm9
            vpxorq zmm6, zmm6, zmm10
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else if ( v509 == 14 ) /*0x102d0aa54*/
        {
          _R12 = _R12 - 1536; /*0x102d0adb4*/
          __asm /*0x102d0adbb*/
          {
            kmovq k1, qword ptr [r12]
            vmovdqu8 zmm11, zmmword ptr [r10]
            vmovdqu8 zmm3, zmmword ptr [r10+40h]
            vmovdqu8 zmm4, zmmword ptr [r10+80h]
            vmovdqu8 ymm5{k1}{z}, ymmword ptr [r10+0C0h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb zmm3, zmm3, zmm16
            vpshufb zmm4, zmm4, zmm16
            vpshufb ymm5, ymm5, ymm16
            vpxorq zmm11, zmm11, zmm2
            vmovdqu64 zmm15, zmmword ptr [rsi+80h]
            vpclmulqdq zmm1, zmm11, zmm15, 11h
            vpclmulqdq zmm6, zmm11, zmm15, 0
            vpclmulqdq zmm7, zmm11, zmm15, 1
            vpclmulqdq zmm8, zmm11, zmm15, 10h
            vmovdqu64 zmm15, zmmword ptr [rsi+0C0h]
            vpclmulqdq zmm9, zmm3, zmm15, 11h
            vpclmulqdq zmm10, zmm3, zmm15, 0
            vpclmulqdq zmm12, zmm3, zmm15, 1
            vpclmulqdq zmm13, zmm3, zmm15, 10h
            vmovdqu64 zmm15, zmmword ptr [rsi+100h]
            vpclmulqdq zmm11, zmm4, zmm15, 11h
            vpclmulqdq zmm3, zmm4, zmm15, 0
            vpternlogq zmm9, zmm11, zmm1, 96h
            vpternlogq zmm10, zmm3, zmm6, 96h
            vpclmulqdq zmm11, zmm4, zmm15, 1
            vpclmulqdq zmm3, zmm4, zmm15, 10h
            vpternlogq zmm12, zmm11, zmm7, 96h
            vpternlogq zmm13, zmm3, zmm8, 96h
            vmovdqu64 ymm15, ymmword ptr [rsi+140h]
            vpclmulqdq ymm7, ymm5, ymm15, 1
            vpclmulqdq ymm8, ymm5, ymm15, 10h
            vpclmulqdq ymm1, ymm5, ymm15, 11h
            vpclmulqdq ymm6, ymm5, ymm15, 0
            vpxorq zmm7, zmm7, zmm12
            vpxorq zmm8, zmm8, zmm13
            vpxorq zmm1, zmm1, zmm9
            vpxorq zmm6, zmm6, zmm10
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm2, xmm15, xmm7, 10h
            vpslldq xmm2, xmm2, 4
            vpternlogq xmm2, xmm8, xmm1, 96h
          }
        }
        else
        {
          _R12 = _R12 - 1536; /*0x102d0aa64*/
          if ( v509 == 15 ) /*0x102d0aa5e*/
          {
            __asm /*0x102d0ac0f*/
            {
              kmovq k1, qword ptr [r12]
              vmovdqu8 zmm11, zmmword ptr [r10]
              vmovdqu8 zmm3, zmmword ptr [r10+40h]
              vmovdqu8 zmm4, zmmword ptr [r10+80h]
              vmovdqu8 zmm5{k1}{z}, zmmword ptr [r10+0C0h]
              vpshufb zmm11, zmm11, zmm16
              vpshufb zmm3, zmm3, zmm16
              vpshufb zmm4, zmm4, zmm16
              vpshufb zmm5, zmm5, zmm16
              vpxorq zmm11, zmm11, zmm2
              vmovdqu64 zmm15, zmmword ptr [rsi+70h]
              vpclmulqdq zmm1, zmm11, zmm15, 11h
              vpclmulqdq zmm6, zmm11, zmm15, 0
              vpclmulqdq zmm7, zmm11, zmm15, 1
              vpclmulqdq zmm8, zmm11, zmm15, 10h
              vmovdqu64 zmm15, zmmword ptr [rsi+0B0h]
              vpclmulqdq zmm9, zmm3, zmm15, 11h
              vpclmulqdq zmm10, zmm3, zmm15, 0
              vpclmulqdq zmm12, zmm3, zmm15, 1
              vpclmulqdq zmm13, zmm3, zmm15, 10h
              vmovdqu64 zmm15, zmmword ptr [rsi+0F0h]
              vpclmulqdq zmm11, zmm4, zmm15, 11h
              vpclmulqdq zmm3, zmm4, zmm15, 0
              vpternlogq zmm9, zmm11, zmm1, 96h
              vpternlogq zmm10, zmm3, zmm6, 96h
              vpclmulqdq zmm11, zmm4, zmm15, 1
              vpclmulqdq zmm3, zmm4, zmm15, 10h
              vpternlogq zmm12, zmm11, zmm7, 96h
              vpternlogq zmm13, zmm3, zmm8, 96h
              vmovdqu64 ymm15, ymmword ptr [rsi+130h]
              vinserti64x2 zmm15, zmm15, xmmword ptr [rsi+150h], 2
              vpclmulqdq zmm7, zmm5, zmm15, 1
              vpclmulqdq zmm8, zmm5, zmm15, 10h
              vpclmulqdq zmm1, zmm5, zmm15, 11h
              vpclmulqdq zmm6, zmm5, zmm15, 0
              vpxorq zmm7, zmm7, zmm12
              vpxorq zmm8, zmm8, zmm13
              vpxorq zmm1, zmm1, zmm9
              vpxorq zmm6, zmm6, zmm10
              vpxorq zmm7, zmm7, zmm8
              vpsrldq zmm12, zmm7, 8
              vpslldq zmm13, zmm7, 8
              vpxorq zmm1, zmm1, zmm12
              vpxorq zmm6, zmm6, zmm13
              vextracti64x4 ymm12, zmm1, 1
              vpxorq ymm1, ymm1, ymm12
              vextracti32x4 xmm12, ymm1, 1
              vpxorq xmm1, xmm1, xmm12
              vextracti64x4 ymm13, zmm6, 1
              vpxorq ymm6, ymm6, ymm13
              vextracti32x4 xmm13, ymm6, 1
              vpxorq xmm6, xmm6, xmm13
              vmovdqa64 xmm15, xmmword ptr cs:POLY2
              vpclmulqdq xmm7, xmm15, xmm6, 1
              vpslldq xmm7, xmm7, 8
              vpxorq xmm7, xmm6, xmm7
              vpclmulqdq xmm8, xmm15, xmm7, 0
              vpsrldq xmm8, xmm8, 4
              vpclmulqdq xmm2, xmm15, xmm7, 10h
              vpslldq xmm2, xmm2, 4
              vpternlogq xmm2, xmm8, xmm1, 96h
            }
          }
          else
          {
            __asm /*0x102d0aa6b*/
            {
              kmovq k1, qword ptr [r12]
              vmovdqu8 zmm11, zmmword ptr [r10]
              vmovdqu8 zmm3, zmmword ptr [r10+40h]
              vmovdqu8 zmm4, zmmword ptr [r10+80h]
              vmovdqu8 zmm5{k1}{z}, zmmword ptr [r10+0C0h]
              vpshufb zmm11, zmm11, zmm16
              vpshufb zmm3, zmm3, zmm16
              vpshufb zmm4, zmm4, zmm16
              vpshufb zmm5, zmm5, zmm16
              vpxorq zmm11, zmm11, zmm2
              vmovdqu64 zmm15, zmmword ptr [rsi+60h]
              vpclmulqdq zmm1, zmm11, zmm15, 11h
              vpclmulqdq zmm6, zmm11, zmm15, 0
              vpclmulqdq zmm7, zmm11, zmm15, 1
              vpclmulqdq zmm8, zmm11, zmm15, 10h
              vmovdqu64 zmm15, zmmword ptr [rsi+0A0h]
              vpclmulqdq zmm9, zmm3, zmm15, 11h
              vpclmulqdq zmm10, zmm3, zmm15, 0
              vpclmulqdq zmm12, zmm3, zmm15, 1
              vpclmulqdq zmm13, zmm3, zmm15, 10h
              vmovdqu64 zmm15, zmmword ptr [rsi+0E0h]
              vpclmulqdq zmm11, zmm4, zmm15, 11h
              vpclmulqdq zmm3, zmm4, zmm15, 0
              vpternlogq zmm1, zmm11, zmm9, 96h
              vpternlogq zmm6, zmm3, zmm10, 96h
              vpclmulqdq zmm11, zmm4, zmm15, 1
              vpclmulqdq zmm3, zmm4, zmm15, 10h
              vpternlogq zmm7, zmm11, zmm12, 96h
              vpternlogq zmm8, zmm3, zmm13, 96h
              vmovdqu64 zmm15, zmmword ptr [rsi+120h]
              vpclmulqdq zmm9, zmm5, zmm15, 11h
              vpclmulqdq zmm10, zmm5, zmm15, 0
              vpclmulqdq zmm12, zmm5, zmm15, 1
              vpclmulqdq zmm13, zmm5, zmm15, 10h
              vpxorq zmm9, zmm1, zmm9
              vpxorq zmm10, zmm6, zmm10
              vpxorq zmm12, zmm7, zmm12
              vpxorq zmm13, zmm8, zmm13
              vpxorq zmm12, zmm12, zmm13
              vpsrldq zmm7, zmm12, 8
              vpslldq zmm8, zmm12, 8
              vpxorq zmm1, zmm9, zmm7
              vpxorq zmm6, zmm10, zmm8
              vextracti64x4 ymm12, zmm1, 1
              vpxorq ymm1, ymm1, ymm12
              vextracti32x4 xmm12, ymm1, 1
              vpxorq xmm1, xmm1, xmm12
              vextracti64x4 ymm13, zmm6, 1
              vpxorq ymm6, ymm6, ymm13
              vextracti32x4 xmm13, ymm6, 1
              vpxorq xmm6, xmm6, xmm13
              vmovdqa64 xmm15, xmmword ptr cs:POLY2
              vpclmulqdq xmm7, xmm15, xmm6, 1
              vpslldq xmm7, xmm7, 8
              vpxorq xmm7, xmm6, xmm7
              vpclmulqdq xmm8, xmm15, xmm7, 0
              vpsrldq xmm8, xmm8, 4
              vpclmulqdq xmm2, xmm15, xmm7, 10h
              vpslldq xmm2, xmm2, 4
              vpternlogq xmm2, xmm8, xmm1, 96h
            }
          }
        }
        goto LABEL_48; /*0x102d0ac03*/
      }
      v1305 = *(__m512i *)_R10; /*0x102d0a836*/
      __asm { vmovdqu64 zmm11, zmmword ptr [r10] } /*0x102d0a836*/
      v1306 = *(__m512i *)(_R10 + 64); /*0x102d0a83c*/
      __asm { vmovdqu64 zmm3, zmmword ptr [r10+40h] } /*0x102d0a83c*/
      v1307 = *(__m512i *)(_R10 + 128); /*0x102d0a843*/
      __asm { vmovdqu64 zmm4, zmmword ptr [r10+80h] } /*0x102d0a843*/
      v1308 = *(__m512i *)(_R10 + 192); /*0x102d0a84a*/
      __asm /*0x102d0a84a*/
      {
        vmovdqu64 zmm5, zmmword ptr [r10+0C0h]
        vpshufb zmm11, zmm11, zmm16
        vpshufb zmm3, zmm3, zmm16
        vpshufb zmm4, zmm4, zmm16
        vpshufb zmm5, zmm5, zmm16
        vpxorq zmm11, zmm11, zmm2
      }
      v1309 = *(__m512i *)(_RSI + 12); /*0x102d0a86f*/
      __asm /*0x102d0a86f*/
      {
        vmovdqu64 zmm19, zmmword ptr [rsi+60h]
        vpclmulqdq zmm1, zmm11, zmm19, 11h
        vpclmulqdq zmm9, zmm11, zmm19, 0
        vpclmulqdq zmm10, zmm11, zmm19, 1
        vpclmulqdq zmm12, zmm11, zmm19, 10h
      }
      v1310 = *(__m512i *)(_RSI + 20); /*0x102d0a895*/
      __asm /*0x102d0a895*/
      {
        vmovdqu64 zmm19, zmmword ptr [rsi+0A0h]
        vpclmulqdq zmm13, zmm3, zmm19, 11h
        vpclmulqdq zmm15, zmm3, zmm19, 0
        vpclmulqdq zmm17, zmm3, zmm19, 1
        vpclmulqdq zmm18, zmm3, zmm19, 10h
        vpxorq zmm7, zmm10, zmm17
        vpxorq zmm6, zmm1, zmm13
        vpxorq zmm8, zmm9, zmm15
        vpternlogq zmm7, zmm12, zmm18, 96h
      }
      v1311 = *(__m512i *)(_RSI + 28); /*0x102d0a8d4*/
      __asm /*0x102d0a8d4*/
      {
        vmovdqu64 zmm19, zmmword ptr [rsi+0E0h]
        vpclmulqdq zmm1, zmm4, zmm19, 11h
        vpclmulqdq zmm9, zmm4, zmm19, 0
        vpclmulqdq zmm10, zmm4, zmm19, 1
        vpclmulqdq zmm12, zmm4, zmm19, 10h
      }
      v1312 = *(__m512i *)(_RSI + 36); /*0x102d0a8fa*/
      __asm /*0x102d0a8fa*/
      {
        vmovdqu64 zmm19, zmmword ptr [rsi+120h]
        vpclmulqdq zmm13, zmm5, zmm19, 11h
        vpclmulqdq zmm15, zmm5, zmm19, 0
        vpclmulqdq zmm17, zmm5, zmm19, 1
        vpclmulqdq zmm18, zmm5, zmm19, 10h
        vpternlogq zmm7, zmm10, zmm17, 96h
        vpternlogq zmm6, zmm1, zmm13, 96h
        vpternlogq zmm8, zmm9, zmm15, 96h
        vpternlogq zmm7, zmm12, zmm18, 96h
        vpsrldq zmm1, zmm7, 8
        vpslldq zmm9, zmm7, 8
        vpxorq zmm6, zmm6, zmm1
        vpxorq zmm8, zmm8, zmm9
        vextracti64x4 ymm1, zmm6, 1
        vpxorq ymm6, ymm6, ymm1
        vextracti32x4 xmm1, ymm6, 1
        vpxorq xmm6, xmm6, xmm1
        vextracti64x4 ymm9, zmm8, 1
        vpxorq ymm8, ymm8, ymm9
        vextracti32x4 xmm9, ymm8, 1
        vpxorq xmm8, xmm8, xmm9
        vmovdqa64 xmm10, xmmword ptr cs:POLY2
        vpclmulqdq xmm1, xmm10, xmm8, 1
        vpslldq xmm1, xmm1, 8
        vpxorq xmm1, xmm8, xmm1
        vpclmulqdq xmm9, xmm10, xmm1, 0
        vpsrldq xmm9, xmm9, 4
        vpclmulqdq xmm2, xmm10, xmm1, 10h
        vpslldq xmm2, xmm2, 4
        vpternlogq xmm2, xmm9, xmm6, 96h
      }
      v19 -= 256; /*0x102d0a9c3*/
      if ( v19 != 0 ) /*0x102d0a9ca*/
      {
        _R10 += 256; /*0x102d0a9d0*/
        goto LABEL_17; /*0x102d0a9d0*/
      }
    }
LABEL_48:
    _R10 = 8 * a4; /*0x102d0be2d*/
    __asm /*0x102d0be34*/
    {
      vmovq xmm3, r10
      vpxorq xmm2, xmm3, xmm2
      vmovdqu64 xmm1, xmmword ptr [rsi+150h]
      vpclmulqdq xmm11, xmm2, xmm1, 11h
      vpclmulqdq xmm3, xmm2, xmm1, 0
      vpclmulqdq xmm4, xmm2, xmm1, 1
      vpclmulqdq xmm2, xmm2, xmm1, 10h
      vpxorq xmm2, xmm2, xmm4
      vpsrldq xmm4, xmm2, 8
      vpslldq xmm2, xmm2, 8
      vpxorq xmm11, xmm11, xmm4
      vpxorq xmm2, xmm2, xmm3
      vmovdqu64 xmm4, xmmword ptr cs:POLY2
      vpclmulqdq xmm3, xmm4, xmm2, 1
      vpslldq xmm3, xmm3, 8
      vpxorq xmm2, xmm2, xmm3
      vpclmulqdq xmm3, xmm4, xmm2, 0
      vpsrldq xmm3, xmm3, 4
      vpclmulqdq xmm2, xmm4, xmm2, 10h
      vpslldq xmm2, xmm2, 4
      vpternlogq xmm2, xmm11, xmm3, 96h
      vpshufb xmm2, xmm2, xmmword ptr cs:SHUF_MASK
    }
    return skip_iv_len_12_init_IV(a1: a5, a2: *(double *)&_XMM1, a3: *(double *)&_XMM2); /*0x102d0bebb*/
  }
  return iv_len_12_init_IV(a1: a5, a2: *(double *)_XMM1.i64, a3: a1, a4: (__int64)_RSI, a5: a3);
}

// Address: 0x102d0c100 | Name: _ossl_aes_gcm_update_aad_avx512
void __fastcall ossl_aes_gcm_update_aad_avx512(
        _BYTE **_RDI,
        __int64 a2,
        unsigned __int64 a3,
        __m128 _XMM0,
        __m128 _XMM1,
        double a6,
        double a7,
        double a8,
        double a9,
        __m128 _XMM6)
{
  __int64 v19; // r11
  __int64 v20; // rbx
  unsigned int v505; // r11d
  __m512i v1254; // 0:rt1.64
  __m512i v1255; // 0:rt1.64
  __m512i v1256; // 0:rt1.64
  __m512i v1257; // 0:rt1.64
  __m512i v1258; // 0:rt1.64
  __m512i v1259; // 0:rt1.64
  __m512i v1260; // 0:rt1.64
  __m512i v1261; // 0:rt1.64
  __m512i v1262; // 0:rt1.64
  __m512i v1263; // 0:rt1.64
  __m512i v1264; // 0:rt1.64
  __m512i v1265; // 0:rt1.64
  __m512i v1266; // 0:rt1.64
  __m512i v1267; // 0:rt1.64
  __m512i v1268; // 0:rt1.64
  __m512i v1269; // 0:rt1.64
  __m512i v1270; // 0:rt1.64
  __m512i v1271; // 0:rt1.64
  __m512i v1272; // 0:rt1.64
  __m512i v1273; // 0:rt1.64
  __m512i v1274; // 0:rt1.64
  __m512i v1275; // 0:rt1.64
  __m512i v1276; // 0:rt1.64
  __m512i v1277; // 0:rt1.64
  __m512i v1278; // 0:rt1.64
  __m512i v1279; // 0:rt1.64
  __m512i v1280; // 0:rt1.64
  __m512i v1281; // 0:rt1.64
  __m512i v1282; // 0:rt1.64
  __m512i v1283; // 0:rt1.64
  __m512i v1284; // 0:rt1.64
  __m512i v1285; // 0:rt1.64
  __m512i v1286; // 0:rt1.64
  __m512i v1287; // 0:rt1.64
  __m512i v1288; // 0:rt1.64
  __m512i v1289; // 0:rt1.64
  __m512i v1290; // 0:rt1.64
  __m512i v1291; // 0:rt1.64
  __m512i v1292; // 0:rt1.64
  __m512i v1293; // 0:rt1.64
  __m512i v1294; // 0:rt1.64
  __m512i v1295; // 0:rt1.64
  __m512i v1296; // 0:rt1.64
  __m512i v1297; // 0:rt1.64
  __m512i v1298; // 0:rt1.64
  __m512i v1299; // 0:rt1.64
  __m512i v1300; // 0:rt1.64
  __m512i v1301; // 0:rt1.64
  __m512i v1302; // 0:rt1.64

  __asm { vmovdqu64 xmm14, xmmword ptr [rdi+40h] } /*0x102d0c11d*/
  _R10 = a2; /*0x102d0c124*/
  v19 = a3; /*0x102d0c127*/
  if ( a3 != 0 ) /*0x102d0c12d*/
  {
    v20 = 0; /*0x102d0c133*/
    __asm { vmovdqa64 zmm16, zmmword ptr cs:SHUF_MASK } /*0x102d0c136*/
    while ( v19 >= 768 ) /*0x102d0c147*/
    {
      v1254 = *(__m512i *)_R10; /*0x102d0c14d*/
      __asm { vmovdqu64 zmm11, zmmword ptr [r10] } /*0x102d0c14d*/
      v1255 = *(__m512i *)(_R10 + 64); /*0x102d0c153*/
      __asm { vmovdqu64 zmm3, zmmword ptr [r10+40h] } /*0x102d0c153*/
      v1256 = *(__m512i *)(_R10 + 128); /*0x102d0c15a*/
      __asm { vmovdqu64 zmm4, zmmword ptr [r10+80h] } /*0x102d0c15a*/
      v1257 = *(__m512i *)(_R10 + 192); /*0x102d0c161*/
      __asm /*0x102d0c161*/
      {
        vmovdqu64 zmm5, zmmword ptr [r10+0C0h]
        vpshufb zmm11, zmm11, zmm16
        vpshufb zmm3, zmm3, zmm16
        vpshufb zmm4, zmm4, zmm16
        vpshufb zmm5, zmm5, zmm16
      }
      if ( v20 == 0 ) /*0x102d0c183*/
      {
        __asm /*0x102d0c189*/
        {
          vmovdqu64 zmm1, zmmword ptr [rdi+120h]
          vmovdqu64 zmmword ptr [rsp+364h+var_A4], zmm1
          vmovdqu64 zmm9, zmmword ptr [rdi+0E0h]
          vmovdqu64 zmmword ptr [rsp+364h+var_E4], zmm9
          vshufi64x2 zmm9, zmm9, zmm9, 0
          vmovdqu64 zmm10, zmmword ptr [rdi+0A0h]
          vmovdqu64 zmmword ptr [rsp+364h+var_124], zmm10
          vmovdqu64 zmm12, zmmword ptr [rdi+60h]
          vmovdqu64 zmmword ptr [rsp+364h+var_164], zmm12
          vpclmulqdq zmm13, zmm10, zmm9, 11h
          vpclmulqdq zmm15, zmm10, zmm9, 0
          vpclmulqdq zmm17, zmm10, zmm9, 1
          vpclmulqdq zmm10, zmm10, zmm9, 10h
          vpxorq zmm10, zmm10, zmm17
          vpsrldq zmm17, zmm10, 8
          vpslldq zmm10, zmm10, 8
          vpxorq zmm13, zmm13, zmm17
          vpxorq zmm10, zmm10, zmm15
          vmovdqu64 zmm17, zmmword ptr cs:POLY2
          vpclmulqdq zmm15, zmm17, zmm10, 1
          vpslldq zmm15, zmm15, 8
          vpxorq zmm10, zmm10, zmm15
          vpclmulqdq zmm15, zmm17, zmm10, 0
          vpsrldq zmm15, zmm15, 4
          vpclmulqdq zmm10, zmm17, zmm10, 10h
          vpslldq zmm10, zmm10, 4
          vpternlogq zmm10, zmm13, zmm15, 96h
          vmovdqu64 zmmword ptr [rsp+364h+var_1A4], zmm10
          vpclmulqdq zmm13, zmm12, zmm9, 11h
          vpclmulqdq zmm15, zmm12, zmm9, 0
          vpclmulqdq zmm17, zmm12, zmm9, 1
          vpclmulqdq zmm12, zmm12, zmm9, 10h
          vpxorq zmm12, zmm12, zmm17
          vpsrldq zmm17, zmm12, 8
          vpslldq zmm12, zmm12, 8
          vpxorq zmm13, zmm13, zmm17
          vpxorq zmm12, zmm12, zmm15
          vmovdqu64 zmm17, zmmword ptr cs:POLY2
          vpclmulqdq zmm15, zmm17, zmm12, 1
          vpslldq zmm15, zmm15, 8
          vpxorq zmm12, zmm12, zmm15
          vpclmulqdq zmm15, zmm17, zmm12, 0
          vpsrldq zmm15, zmm15, 4
          vpclmulqdq zmm12, zmm17, zmm12, 10h
          vpslldq zmm12, zmm12, 4
          vpternlogq zmm12, zmm13, zmm15, 96h
          vmovdqu64 zmmword ptr [rsp+364h+var_1E4], zmm12
          vpclmulqdq zmm13, zmm10, zmm9, 11h
          vpclmulqdq zmm15, zmm10, zmm9, 0
          vpclmulqdq zmm17, zmm10, zmm9, 1
          vpclmulqdq zmm10, zmm10, zmm9, 10h
          vpxorq zmm10, zmm10, zmm17
          vpsrldq zmm17, zmm10, 8
          vpslldq zmm10, zmm10, 8
          vpxorq zmm13, zmm13, zmm17
          vpxorq zmm10, zmm10, zmm15
          vmovdqu64 zmm17, zmmword ptr cs:POLY2
          vpclmulqdq zmm15, zmm17, zmm10, 1
          vpslldq zmm15, zmm15, 8
          vpxorq zmm10, zmm10, zmm15
          vpclmulqdq zmm15, zmm17, zmm10, 0
          vpsrldq zmm15, zmm15, 4
          vpclmulqdq zmm10, zmm17, zmm10, 10h
          vpslldq zmm10, zmm10, 4
          vpternlogq zmm10, zmm13, zmm15, 96h
          vmovdqu64 zmmword ptr [rsp+364h+var_224], zmm10
          vpclmulqdq zmm13, zmm12, zmm9, 11h
          vpclmulqdq zmm15, zmm12, zmm9, 0
          vpclmulqdq zmm17, zmm12, zmm9, 1
          vpclmulqdq zmm12, zmm12, zmm9, 10h
          vpxorq zmm12, zmm12, zmm17
          vpsrldq zmm17, zmm12, 8
          vpslldq zmm12, zmm12, 8
          vpxorq zmm13, zmm13, zmm17
          vpxorq zmm12, zmm12, zmm15
          vmovdqu64 zmm17, zmmword ptr cs:POLY2
          vpclmulqdq zmm15, zmm17, zmm12, 1
          vpslldq zmm15, zmm15, 8
          vpxorq zmm12, zmm12, zmm15
          vpclmulqdq zmm15, zmm17, zmm12, 0
          vpsrldq zmm15, zmm15, 4
          vpclmulqdq zmm12, zmm17, zmm12, 10h
          vpslldq zmm12, zmm12, 4
          vpternlogq zmm12, zmm13, zmm15, 96h
          vmovdqu64 zmmword ptr [rsp+364h+var_264], zmm12
          vpclmulqdq zmm13, zmm10, zmm9, 11h
          vpclmulqdq zmm15, zmm10, zmm9, 0
          vpclmulqdq zmm17, zmm10, zmm9, 1
          vpclmulqdq zmm10, zmm10, zmm9, 10h
          vpxorq zmm10, zmm10, zmm17
          vpsrldq zmm17, zmm10, 8
          vpslldq zmm10, zmm10, 8
          vpxorq zmm13, zmm13, zmm17
          vpxorq zmm10, zmm10, zmm15
          vmovdqu64 zmm17, zmmword ptr cs:POLY2
          vpclmulqdq zmm15, zmm17, zmm10, 1
          vpslldq zmm15, zmm15, 8
          vpxorq zmm10, zmm10, zmm15
          vpclmulqdq zmm15, zmm17, zmm10, 0
          vpsrldq zmm15, zmm15, 4
          vpclmulqdq zmm10, zmm17, zmm10, 10h
          vpslldq zmm10, zmm10, 4
          vpternlogq zmm10, zmm13, zmm15, 96h
          vmovdqu64 zmmword ptr [rsp+364h+var_2A4], zmm10
          vpclmulqdq zmm13, zmm12, zmm9, 11h
          vpclmulqdq zmm15, zmm12, zmm9, 0
          vpclmulqdq zmm17, zmm12, zmm9, 1
          vpclmulqdq zmm12, zmm12, zmm9, 10h
          vpxorq zmm12, zmm12, zmm17
          vpsrldq zmm17, zmm12, 8
          vpslldq zmm12, zmm12, 8
          vpxorq zmm13, zmm13, zmm17
          vpxorq zmm12, zmm12, zmm15
          vmovdqu64 zmm17, zmmword ptr cs:POLY2
          vpclmulqdq zmm15, zmm17, zmm12, 1
          vpslldq zmm15, zmm15, 8
          vpxorq zmm12, zmm12, zmm15
          vpclmulqdq zmm15, zmm17, zmm12, 0
          vpsrldq zmm15, zmm15, 4
          vpclmulqdq zmm12, zmm17, zmm12, 10h
          vpslldq zmm12, zmm12, 4
          vpternlogq zmm12, zmm13, zmm15, 96h
          vmovdqu64 zmmword ptr [rsp+364h+var_2E4], zmm12
          vpclmulqdq zmm13, zmm10, zmm9, 11h
          vpclmulqdq zmm15, zmm10, zmm9, 0
          vpclmulqdq zmm17, zmm10, zmm9, 1
          vpclmulqdq zmm10, zmm10, zmm9, 10h
          vpxorq zmm10, zmm10, zmm17
          vpsrldq zmm17, zmm10, 8
          vpslldq zmm10, zmm10, 8
          vpxorq zmm13, zmm13, zmm17
          vpxorq zmm10, zmm10, zmm15
          vmovdqu64 zmm17, zmmword ptr cs:POLY2
          vpclmulqdq zmm15, zmm17, zmm10, 1
          vpslldq zmm15, zmm15, 8
          vpxorq zmm10, zmm10, zmm15
          vpclmulqdq zmm15, zmm17, zmm10, 0
          vpsrldq zmm15, zmm15, 4
          vpclmulqdq zmm10, zmm17, zmm10, 10h
          vpslldq zmm10, zmm10, 4
          vpternlogq zmm10, zmm13, zmm15, 96h
          vmovdqu64 zmmword ptr [rsp+364h+var_324], zmm10
          vpclmulqdq zmm13, zmm12, zmm9, 11h
          vpclmulqdq zmm15, zmm12, zmm9, 0
          vpclmulqdq zmm17, zmm12, zmm9, 1
          vpclmulqdq zmm12, zmm12, zmm9, 10h
          vpxorq zmm12, zmm12, zmm17
          vpsrldq zmm17, zmm12, 8
          vpslldq zmm12, zmm12, 8
          vpxorq zmm13, zmm13, zmm17
          vpxorq zmm12, zmm12, zmm15
          vmovdqu64 zmm17, zmmword ptr cs:POLY2
          vpclmulqdq zmm15, zmm17, zmm12, 1
          vpslldq zmm15, zmm15, 8
          vpxorq zmm12, zmm12, zmm15
          vpclmulqdq zmm15, zmm17, zmm12, 0
          vpsrldq zmm15, zmm15, 4
          vpclmulqdq zmm12, zmm17, zmm12, 10h
          vpslldq zmm12, zmm12, 4
          vpternlogq zmm12, zmm13, zmm15, 96h
          vmovdqu64 zmmword ptr [rsp+364h+var_364], zmm12
        }
      }
      v20 = 1; /*0x102d0c5ff*/
      __asm /*0x102d0c606*/
      {
        vpxorq zmm11, zmm11, zmm14
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_364]
        vpclmulqdq zmm1, zmm11, zmm19, 11h
        vpclmulqdq zmm9, zmm11, zmm19, 0
        vpclmulqdq zmm10, zmm11, zmm19, 1
        vpclmulqdq zmm12, zmm11, zmm19, 10h
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_324]
        vpclmulqdq zmm13, zmm3, zmm19, 11h
        vpclmulqdq zmm15, zmm3, zmm19, 0
        vpclmulqdq zmm17, zmm3, zmm19, 1
        vpclmulqdq zmm18, zmm3, zmm19, 10h
        vpxorq zmm7, zmm10, zmm17
        vpxorq zmm6, zmm1, zmm13
        vpxorq zmm8, zmm9, zmm15
        vpternlogq zmm7, zmm12, zmm18, 96h
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_2E4]
        vpclmulqdq zmm1, zmm4, zmm19, 11h
        vpclmulqdq zmm9, zmm4, zmm19, 0
        vpclmulqdq zmm10, zmm4, zmm19, 1
        vpclmulqdq zmm12, zmm4, zmm19, 10h
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_2A4]
        vpclmulqdq zmm13, zmm5, zmm19, 11h
        vpclmulqdq zmm15, zmm5, zmm19, 0
        vpclmulqdq zmm17, zmm5, zmm19, 1
        vpclmulqdq zmm18, zmm5, zmm19, 10h
        vpternlogq zmm7, zmm10, zmm17, 96h
        vpternlogq zmm6, zmm1, zmm13, 96h
        vpternlogq zmm8, zmm9, zmm15, 96h
        vpternlogq zmm7, zmm12, zmm18, 96h
      }
      v1258 = *(__m512i *)(_R10 + 256); /*0x102d0c6d0*/
      __asm { vmovdqu64 zmm11, zmmword ptr [r10+100h] } /*0x102d0c6d0*/
      v1259 = *(__m512i *)(_R10 + 320); /*0x102d0c6d7*/
      __asm { vmovdqu64 zmm3, zmmword ptr [r10+140h] } /*0x102d0c6d7*/
      v1260 = *(__m512i *)(_R10 + 384); /*0x102d0c6de*/
      __asm { vmovdqu64 zmm4, zmmword ptr [r10+180h] } /*0x102d0c6de*/
      v1261 = *(__m512i *)(_R10 + 448); /*0x102d0c6e5*/
      __asm /*0x102d0c6e5*/
      {
        vmovdqu64 zmm5, zmmword ptr [r10+1C0h]
        vpshufb zmm11, zmm11, zmm16
        vpshufb zmm3, zmm3, zmm16
        vpshufb zmm4, zmm4, zmm16
        vpshufb zmm5, zmm5, zmm16
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_264]
        vpclmulqdq zmm1, zmm11, zmm19, 11h
        vpclmulqdq zmm9, zmm11, zmm19, 0
        vpclmulqdq zmm10, zmm11, zmm19, 1
        vpclmulqdq zmm12, zmm11, zmm19, 10h
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_224]
        vpclmulqdq zmm13, zmm3, zmm19, 11h
        vpclmulqdq zmm15, zmm3, zmm19, 0
        vpclmulqdq zmm17, zmm3, zmm19, 1
        vpclmulqdq zmm18, zmm3, zmm19, 10h
        vpternlogq zmm7, zmm10, zmm17, 96h
        vpternlogq zmm6, zmm1, zmm13, 96h
        vpternlogq zmm8, zmm9, zmm15, 96h
        vpternlogq zmm7, zmm12, zmm18, 96h
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_1E4]
        vpclmulqdq zmm1, zmm4, zmm19, 11h
        vpclmulqdq zmm9, zmm4, zmm19, 0
        vpclmulqdq zmm10, zmm4, zmm19, 1
        vpclmulqdq zmm12, zmm4, zmm19, 10h
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_1A4]
        vpclmulqdq zmm13, zmm5, zmm19, 11h
        vpclmulqdq zmm15, zmm5, zmm19, 0
        vpclmulqdq zmm17, zmm5, zmm19, 1
        vpclmulqdq zmm18, zmm5, zmm19, 10h
        vpternlogq zmm7, zmm10, zmm17, 96h
        vpternlogq zmm6, zmm1, zmm13, 96h
        vpternlogq zmm8, zmm9, zmm15, 96h
        vpternlogq zmm7, zmm12, zmm18, 96h
      }
      v1262 = *(__m512i *)(_R10 + 512); /*0x102d0c7cc*/
      __asm { vmovdqu64 zmm11, zmmword ptr [r10+200h] } /*0x102d0c7cc*/
      v1263 = *(__m512i *)(_R10 + 576); /*0x102d0c7d3*/
      __asm { vmovdqu64 zmm3, zmmword ptr [r10+240h] } /*0x102d0c7d3*/
      v1264 = *(__m512i *)(_R10 + 640); /*0x102d0c7da*/
      __asm { vmovdqu64 zmm4, zmmword ptr [r10+280h] } /*0x102d0c7da*/
      v1265 = *(__m512i *)(_R10 + 704); /*0x102d0c7e1*/
      __asm /*0x102d0c7e1*/
      {
        vmovdqu64 zmm5, zmmword ptr [r10+2C0h]
        vpshufb zmm11, zmm11, zmm16
        vpshufb zmm3, zmm3, zmm16
        vpshufb zmm4, zmm4, zmm16
        vpshufb zmm5, zmm5, zmm16
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_164]
        vpclmulqdq zmm1, zmm11, zmm19, 11h
        vpclmulqdq zmm9, zmm11, zmm19, 0
        vpclmulqdq zmm10, zmm11, zmm19, 1
        vpclmulqdq zmm12, zmm11, zmm19, 10h
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_124]
        vpclmulqdq zmm13, zmm3, zmm19, 11h
        vpclmulqdq zmm15, zmm3, zmm19, 0
        vpclmulqdq zmm17, zmm3, zmm19, 1
        vpclmulqdq zmm18, zmm3, zmm19, 10h
        vpternlogq zmm7, zmm10, zmm17, 96h
        vpternlogq zmm6, zmm1, zmm13, 96h
        vpternlogq zmm8, zmm9, zmm15, 96h
        vpternlogq zmm7, zmm12, zmm18, 96h
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_E4]
        vpclmulqdq zmm1, zmm4, zmm19, 11h
        vpclmulqdq zmm9, zmm4, zmm19, 0
        vpclmulqdq zmm10, zmm4, zmm19, 1
        vpclmulqdq zmm12, zmm4, zmm19, 10h
        vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_A4]
        vpclmulqdq zmm13, zmm5, zmm19, 11h
        vpclmulqdq zmm15, zmm5, zmm19, 0
        vpclmulqdq zmm17, zmm5, zmm19, 1
        vpclmulqdq zmm18, zmm5, zmm19, 10h
        vpternlogq zmm7, zmm10, zmm17, 96h
        vpternlogq zmm6, zmm1, zmm13, 96h
        vpternlogq zmm8, zmm9, zmm15, 96h
        vpternlogq zmm7, zmm12, zmm18, 96h
        vpsrldq zmm1, zmm7, 8
        vpslldq zmm9, zmm7, 8
        vpxorq zmm6, zmm6, zmm1
        vpxorq zmm8, zmm8, zmm9
        vextracti64x4 ymm1, zmm6, 1
        vpxorq ymm6, ymm6, ymm1
        vextracti32x4 xmm1, ymm6, 1
        vpxorq xmm6, xmm6, xmm1
        vextracti64x4 ymm9, zmm8, 1
        vpxorq ymm8, ymm8, ymm9
        vextracti32x4 xmm9, ymm8, 1
        vpxorq xmm8, xmm8, xmm9
        vmovdqa64 xmm10, xmmword ptr cs:POLY2
        vpclmulqdq xmm1, xmm10, xmm8, 1
        vpslldq xmm1, xmm1, 8
        vpxorq xmm1, xmm8, xmm1
        vpclmulqdq xmm9, xmm10, xmm1, 0
        vpsrldq xmm9, xmm9, 4
        vpclmulqdq xmm14, xmm10, xmm1, 10h
        vpslldq xmm14, xmm14, 4
        vpternlogq xmm14, xmm9, xmm6, 96h
      }
      v19 -= 768; /*0x102d0c950*/
      if ( v19 == 0 ) /*0x102d0c957*/
        goto LABEL_47; /*0x102d0c957*/
      _R10 += 768; /*0x102d0c95d*/
    }
    if ( v19 < 512 ) /*0x102d0c970*/
    {
      if ( v19 >= 256 ) /*0x102d0ce8b*/
      {
        v1274 = *(__m512i *)_R10; /*0x102d0ce91*/
        __asm { vmovdqu64 zmm11, zmmword ptr [r10] } /*0x102d0ce91*/
        v1275 = *(__m512i *)(_R10 + 64); /*0x102d0ce97*/
        __asm { vmovdqu64 zmm3, zmmword ptr [r10+40h] } /*0x102d0ce97*/
        v1276 = *(__m512i *)(_R10 + 128); /*0x102d0ce9e*/
        __asm { vmovdqu64 zmm4, zmmword ptr [r10+80h] } /*0x102d0ce9e*/
        v1277 = *(__m512i *)(_R10 + 192); /*0x102d0cea5*/
        __asm /*0x102d0cea5*/
        {
          vmovdqu64 zmm5, zmmword ptr [r10+0C0h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb zmm4, zmm4, zmm16
          vpshufb zmm5, zmm5, zmm16
          vpxorq zmm11, zmm11, zmm14
        }
        v1278 = *(__m512i *)(_RDI + 12); /*0x102d0ceca*/
        __asm /*0x102d0ceca*/
        {
          vmovdqu64 zmm19, zmmword ptr [rdi+60h]
          vpclmulqdq zmm1, zmm11, zmm19, 11h
          vpclmulqdq zmm9, zmm11, zmm19, 0
          vpclmulqdq zmm10, zmm11, zmm19, 1
          vpclmulqdq zmm12, zmm11, zmm19, 10h
        }
        v1279 = *(__m512i *)(_RDI + 20); /*0x102d0cef0*/
        __asm /*0x102d0cef0*/
        {
          vmovdqu64 zmm19, zmmword ptr [rdi+0A0h]
          vpclmulqdq zmm13, zmm3, zmm19, 11h
          vpclmulqdq zmm15, zmm3, zmm19, 0
          vpclmulqdq zmm17, zmm3, zmm19, 1
          vpclmulqdq zmm18, zmm3, zmm19, 10h
          vpxorq zmm7, zmm10, zmm17
          vpxorq zmm6, zmm1, zmm13
          vpxorq zmm8, zmm9, zmm15
          vpternlogq zmm7, zmm12, zmm18, 96h
        }
        v1280 = *(__m512i *)(_RDI + 28); /*0x102d0cf2f*/
        __asm /*0x102d0cf2f*/
        {
          vmovdqu64 zmm19, zmmword ptr [rdi+0E0h]
          vpclmulqdq zmm1, zmm4, zmm19, 11h
          vpclmulqdq zmm9, zmm4, zmm19, 0
          vpclmulqdq zmm10, zmm4, zmm19, 1
          vpclmulqdq zmm12, zmm4, zmm19, 10h
        }
        v1281 = *(__m512i *)(_RDI + 36); /*0x102d0cf55*/
        __asm /*0x102d0cf55*/
        {
          vmovdqu64 zmm19, zmmword ptr [rdi+120h]
          vpclmulqdq zmm13, zmm5, zmm19, 11h
          vpclmulqdq zmm15, zmm5, zmm19, 0
          vpclmulqdq zmm17, zmm5, zmm19, 1
          vpclmulqdq zmm18, zmm5, zmm19, 10h
          vpternlogq zmm7, zmm10, zmm17, 96h
          vpternlogq zmm6, zmm1, zmm13, 96h
          vpternlogq zmm8, zmm9, zmm15, 96h
          vpternlogq zmm7, zmm12, zmm18, 96h
          vpsrldq zmm1, zmm7, 8
          vpslldq zmm9, zmm7, 8
          vpxorq zmm6, zmm6, zmm1
          vpxorq zmm8, zmm8, zmm9
          vextracti64x4 ymm1, zmm6, 1
          vpxorq ymm6, ymm6, ymm1
          vextracti32x4 xmm1, ymm6, 1
          vpxorq xmm6, xmm6, xmm1
          vextracti64x4 ymm9, zmm8, 1
          vpxorq ymm8, ymm8, ymm9
          vextracti32x4 xmm9, ymm8, 1
          vpxorq xmm8, xmm8, xmm9
          vmovdqa64 xmm10, xmmword ptr cs:POLY2
          vpclmulqdq xmm1, xmm10, xmm8, 1
          vpslldq xmm1, xmm1, 8
          vpxorq xmm1, xmm8, xmm1
          vpclmulqdq xmm9, xmm10, xmm1, 0
          vpsrldq xmm9, xmm9, 4
          vpclmulqdq xmm14, xmm10, xmm1, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm9, xmm6, 96h
        }
        v19 -= 256; /*0x102d0d01f*/
        if ( v19 == 0 ) /*0x102d0d026*/
          goto LABEL_47; /*0x102d0d026*/
        _R10 += 256; /*0x102d0d02c*/
      }
      goto LABEL_16; /*0x102d0d02c*/
    }
    v1266 = *(__m512i *)_R10; /*0x102d0c976*/
    __asm { vmovdqu64 zmm11, zmmword ptr [r10] } /*0x102d0c976*/
    v1267 = *(__m512i *)(_R10 + 64); /*0x102d0c97c*/
    __asm { vmovdqu64 zmm3, zmmword ptr [r10+40h] } /*0x102d0c97c*/
    v1268 = *(__m512i *)(_R10 + 128); /*0x102d0c983*/
    __asm { vmovdqu64 zmm4, zmmword ptr [r10+80h] } /*0x102d0c983*/
    v1269 = *(__m512i *)(_R10 + 192); /*0x102d0c98a*/
    __asm /*0x102d0c98a*/
    {
      vmovdqu64 zmm5, zmmword ptr [r10+0C0h]
      vpshufb zmm11, zmm11, zmm16
      vpshufb zmm3, zmm3, zmm16
      vpshufb zmm4, zmm4, zmm16
      vpshufb zmm5, zmm5, zmm16
    }
    if ( v20 == 0 ) /*0x102d0c9ac*/
    {
      __asm /*0x102d0c9b2*/
      {
        vmovdqu64 zmm1, zmmword ptr [rdi+120h]
        vmovdqu64 zmmword ptr [rsp+364h+var_A4], zmm1
        vmovdqu64 zmm9, zmmword ptr [rdi+0E0h]
        vmovdqu64 zmmword ptr [rsp+364h+var_E4], zmm9
        vshufi64x2 zmm9, zmm9, zmm9, 0
        vmovdqu64 zmm10, zmmword ptr [rdi+0A0h]
        vmovdqu64 zmmword ptr [rsp+364h+var_124], zmm10
        vmovdqu64 zmm12, zmmword ptr [rdi+60h]
        vmovdqu64 zmmword ptr [rsp+364h+var_164], zmm12
        vpclmulqdq zmm13, zmm10, zmm9, 11h
        vpclmulqdq zmm15, zmm10, zmm9, 0
        vpclmulqdq zmm17, zmm10, zmm9, 1
        vpclmulqdq zmm10, zmm10, zmm9, 10h
        vpxorq zmm10, zmm10, zmm17
        vpsrldq zmm17, zmm10, 8
        vpslldq zmm10, zmm10, 8
        vpxorq zmm13, zmm13, zmm17
        vpxorq zmm10, zmm10, zmm15
        vmovdqu64 zmm17, zmmword ptr cs:POLY2
        vpclmulqdq zmm15, zmm17, zmm10, 1
        vpslldq zmm15, zmm15, 8
        vpxorq zmm10, zmm10, zmm15
        vpclmulqdq zmm15, zmm17, zmm10, 0
        vpsrldq zmm15, zmm15, 4
        vpclmulqdq zmm10, zmm17, zmm10, 10h
        vpslldq zmm10, zmm10, 4
        vpternlogq zmm10, zmm13, zmm15, 96h
        vmovdqu64 zmmword ptr [rsp+364h+var_1A4], zmm10
        vpclmulqdq zmm13, zmm12, zmm9, 11h
        vpclmulqdq zmm15, zmm12, zmm9, 0
        vpclmulqdq zmm17, zmm12, zmm9, 1
        vpclmulqdq zmm12, zmm12, zmm9, 10h
        vpxorq zmm12, zmm12, zmm17
        vpsrldq zmm17, zmm12, 8
        vpslldq zmm12, zmm12, 8
        vpxorq zmm13, zmm13, zmm17
        vpxorq zmm12, zmm12, zmm15
        vmovdqu64 zmm17, zmmword ptr cs:POLY2
        vpclmulqdq zmm15, zmm17, zmm12, 1
        vpslldq zmm15, zmm15, 8
        vpxorq zmm12, zmm12, zmm15
        vpclmulqdq zmm15, zmm17, zmm12, 0
        vpsrldq zmm15, zmm15, 4
        vpclmulqdq zmm12, zmm17, zmm12, 10h
        vpslldq zmm12, zmm12, 4
        vpternlogq zmm12, zmm13, zmm15, 96h
        vmovdqu64 zmmword ptr [rsp+364h+var_1E4], zmm12
        vpclmulqdq zmm13, zmm10, zmm9, 11h
        vpclmulqdq zmm15, zmm10, zmm9, 0
        vpclmulqdq zmm17, zmm10, zmm9, 1
        vpclmulqdq zmm10, zmm10, zmm9, 10h
        vpxorq zmm10, zmm10, zmm17
        vpsrldq zmm17, zmm10, 8
        vpslldq zmm10, zmm10, 8
        vpxorq zmm13, zmm13, zmm17
        vpxorq zmm10, zmm10, zmm15
        vmovdqu64 zmm17, zmmword ptr cs:POLY2
        vpclmulqdq zmm15, zmm17, zmm10, 1
        vpslldq zmm15, zmm15, 8
        vpxorq zmm10, zmm10, zmm15
        vpclmulqdq zmm15, zmm17, zmm10, 0
        vpsrldq zmm15, zmm15, 4
        vpclmulqdq zmm10, zmm17, zmm10, 10h
        vpslldq zmm10, zmm10, 4
        vpternlogq zmm10, zmm13, zmm15, 96h
        vmovdqu64 zmmword ptr [rsp+364h+var_224], zmm10
        vpclmulqdq zmm13, zmm12, zmm9, 11h
        vpclmulqdq zmm15, zmm12, zmm9, 0
        vpclmulqdq zmm17, zmm12, zmm9, 1
        vpclmulqdq zmm12, zmm12, zmm9, 10h
        vpxorq zmm12, zmm12, zmm17
        vpsrldq zmm17, zmm12, 8
        vpslldq zmm12, zmm12, 8
        vpxorq zmm13, zmm13, zmm17
        vpxorq zmm12, zmm12, zmm15
        vmovdqu64 zmm17, zmmword ptr cs:POLY2
        vpclmulqdq zmm15, zmm17, zmm12, 1
        vpslldq zmm15, zmm15, 8
        vpxorq zmm12, zmm12, zmm15
        vpclmulqdq zmm15, zmm17, zmm12, 0
        vpsrldq zmm15, zmm15, 4
        vpclmulqdq zmm12, zmm17, zmm12, 10h
        vpslldq zmm12, zmm12, 4
        vpternlogq zmm12, zmm13, zmm15, 96h
        vmovdqu64 zmmword ptr [rsp+364h+var_264], zmm12
      }
    }
    __asm /*0x102d0cc1c*/
    {
      vpxorq zmm11, zmm11, zmm14
      vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_264]
      vpclmulqdq zmm1, zmm11, zmm19, 11h
      vpclmulqdq zmm9, zmm11, zmm19, 0
      vpclmulqdq zmm10, zmm11, zmm19, 1
      vpclmulqdq zmm12, zmm11, zmm19, 10h
      vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_224]
      vpclmulqdq zmm13, zmm3, zmm19, 11h
      vpclmulqdq zmm15, zmm3, zmm19, 0
      vpclmulqdq zmm17, zmm3, zmm19, 1
      vpclmulqdq zmm18, zmm3, zmm19, 10h
      vpxorq zmm7, zmm10, zmm17
      vpxorq zmm6, zmm1, zmm13
      vpxorq zmm8, zmm9, zmm15
      vpternlogq zmm7, zmm12, zmm18, 96h
      vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_1E4]
      vpclmulqdq zmm1, zmm4, zmm19, 11h
      vpclmulqdq zmm9, zmm4, zmm19, 0
      vpclmulqdq zmm10, zmm4, zmm19, 1
      vpclmulqdq zmm12, zmm4, zmm19, 10h
      vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_1A4]
      vpclmulqdq zmm13, zmm5, zmm19, 11h
      vpclmulqdq zmm15, zmm5, zmm19, 0
      vpclmulqdq zmm17, zmm5, zmm19, 1
      vpclmulqdq zmm18, zmm5, zmm19, 10h
      vpternlogq zmm7, zmm10, zmm17, 96h
      vpternlogq zmm6, zmm1, zmm13, 96h
      vpternlogq zmm8, zmm9, zmm15, 96h
      vpternlogq zmm7, zmm12, zmm18, 96h
    }
    v1270 = *(__m512i *)(_R10 + 256); /*0x102d0cce7*/
    __asm { vmovdqu64 zmm11, zmmword ptr [r10+100h] } /*0x102d0cce7*/
    v1271 = *(__m512i *)(_R10 + 320); /*0x102d0ccee*/
    __asm { vmovdqu64 zmm3, zmmword ptr [r10+140h] } /*0x102d0ccee*/
    v1272 = *(__m512i *)(_R10 + 384); /*0x102d0ccf5*/
    __asm { vmovdqu64 zmm4, zmmword ptr [r10+180h] } /*0x102d0ccf5*/
    v1273 = *(__m512i *)(_R10 + 448); /*0x102d0ccfc*/
    __asm /*0x102d0ccfc*/
    {
      vmovdqu64 zmm5, zmmword ptr [r10+1C0h]
      vpshufb zmm11, zmm11, zmm16
      vpshufb zmm3, zmm3, zmm16
      vpshufb zmm4, zmm4, zmm16
      vpshufb zmm5, zmm5, zmm16
      vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_164]
      vpclmulqdq zmm1, zmm11, zmm19, 11h
      vpclmulqdq zmm9, zmm11, zmm19, 0
      vpclmulqdq zmm10, zmm11, zmm19, 1
      vpclmulqdq zmm12, zmm11, zmm19, 10h
      vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_124]
      vpclmulqdq zmm13, zmm3, zmm19, 11h
      vpclmulqdq zmm15, zmm3, zmm19, 0
      vpclmulqdq zmm17, zmm3, zmm19, 1
      vpclmulqdq zmm18, zmm3, zmm19, 10h
      vpternlogq zmm7, zmm10, zmm17, 96h
      vpternlogq zmm6, zmm1, zmm13, 96h
      vpternlogq zmm8, zmm9, zmm15, 96h
      vpternlogq zmm7, zmm12, zmm18, 96h
      vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_E4]
      vpclmulqdq zmm1, zmm4, zmm19, 11h
      vpclmulqdq zmm9, zmm4, zmm19, 0
      vpclmulqdq zmm10, zmm4, zmm19, 1
      vpclmulqdq zmm12, zmm4, zmm19, 10h
      vmovdqu64 zmm19, zmmword ptr [rsp+364h+var_A4]
      vpclmulqdq zmm13, zmm5, zmm19, 11h
      vpclmulqdq zmm15, zmm5, zmm19, 0
      vpclmulqdq zmm17, zmm5, zmm19, 1
      vpclmulqdq zmm18, zmm5, zmm19, 10h
      vpternlogq zmm7, zmm10, zmm17, 96h
      vpternlogq zmm6, zmm1, zmm13, 96h
      vpternlogq zmm8, zmm9, zmm15, 96h
      vpternlogq zmm7, zmm12, zmm18, 96h
      vpsrldq zmm1, zmm7, 8
      vpslldq zmm9, zmm7, 8
      vpxorq zmm6, zmm6, zmm1
      vpxorq zmm8, zmm8, zmm9
      vextracti64x4 ymm1, zmm6, 1
      vpxorq ymm6, ymm6, ymm1
      vextracti32x4 xmm1, ymm6, 1
      vpxorq xmm6, xmm6, xmm1
      vextracti64x4 ymm9, zmm8, 1
      vpxorq ymm8, ymm8, ymm9
      vextracti32x4 xmm9, ymm8, 1
      vpxorq xmm8, xmm8, xmm9
      vmovdqa64 xmm10, xmmword ptr cs:POLY2
      vpclmulqdq xmm1, xmm10, xmm8, 1
      vpslldq xmm1, xmm1, 8
      vpxorq xmm1, xmm8, xmm1
      vpclmulqdq xmm9, xmm10, xmm1, 0
      vpsrldq xmm9, xmm9, 4
      vpclmulqdq xmm14, xmm10, xmm1, 10h
      vpslldq xmm14, xmm14, 4
      vpternlogq xmm14, xmm9, xmm6, 96h
    }
    v19 -= 512; /*0x102d0ce6b*/
    if ( v19 != 0 ) /*0x102d0ce72*/
    {
      _R10 += 512; /*0x102d0ce78*/
LABEL_16:
      _R12 = (char *)&byte64_len_to_mask_table + 8 * v19; /*0x102d0d033*/
      v505 = (unsigned int)(v19 + 15) >> 4; /*0x102d0d042*/
      if ( v505 < 2 ) /*0x102d0d04a*/
      {
        __asm /*0x102d0e3d4*/
        {
          kmovq k1, qword ptr [r12]
          vmovdqu8 xmm11{k1}{z}, xmmword ptr [r10]
          vpshufb xmm11, xmm11, xmm16
          vpxorq zmm11, zmm11, zmm14
          vmovdqu64 xmm15, xmmword ptr [rdi+150h]
          vpclmulqdq xmm7, xmm11, xmm15, 1
          vpclmulqdq xmm8, xmm11, xmm15, 10h
          vpclmulqdq xmm1, xmm11, xmm15, 11h
          vpclmulqdq xmm6, xmm11, xmm15, 0
          vpxorq zmm7, zmm7, zmm8
          vpsrldq zmm12, zmm7, 8
          vpslldq zmm13, zmm7, 8
          vpxorq zmm1, zmm1, zmm12
          vpxorq zmm6, zmm6, zmm13
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 == 2 ) /*0x102d0d050*/
      {
        __asm /*0x102d0e30a*/
        {
          kmovq k1, qword ptr [r12]
          vmovdqu8 ymm11{k1}{z}, ymmword ptr [r10]
          vpshufb ymm11, ymm11, ymm16
          vpxorq zmm11, zmm11, zmm14
          vmovdqu64 ymm15, ymmword ptr [rdi+140h]
          vpclmulqdq ymm7, ymm11, ymm15, 1
          vpclmulqdq ymm8, ymm11, ymm15, 10h
          vpclmulqdq ymm1, ymm11, ymm15, 11h
          vpclmulqdq ymm6, ymm11, ymm15, 0
          vpxorq zmm7, zmm7, zmm8
          vpsrldq zmm12, zmm7, 8
          vpslldq zmm13, zmm7, 8
          vpxorq zmm1, zmm1, zmm12
          vpxorq zmm6, zmm6, zmm13
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 < 4 ) /*0x102d0d05a*/
      {
        __asm { kmovq k1, qword ptr [r12] } /*0x102d0e231*/
        v1302 = *(__m512i *)_R10; /*0x102d0e237*/
        __asm /*0x102d0e237*/
        {
          vmovdqu8 zmm11{k1}{z}, zmmword ptr [r10]
          vpshufb zmm11, zmm11, zmm16
          vpxorq zmm11, zmm11, zmm14
          vmovdqu64 ymm15, ymmword ptr [rdi+130h]
          vinserti64x2 zmm15, zmm15, xmmword ptr [rdi+150h], 2
          vpclmulqdq zmm7, zmm11, zmm15, 1
          vpclmulqdq zmm8, zmm11, zmm15, 10h
          vpclmulqdq zmm1, zmm11, zmm15, 11h
          vpclmulqdq zmm6, zmm11, zmm15, 0
          vpxorq zmm7, zmm7, zmm8
          vpsrldq zmm12, zmm7, 8
          vpslldq zmm13, zmm7, 8
          vpxorq zmm1, zmm1, zmm12
          vpxorq zmm6, zmm6, zmm13
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 == 4 ) /*0x102d0d060*/
      {
        __asm /*0x102d0e160*/
        {
          kmovq k1, qword ptr [r12]
          vmovdqu8 zmm11{k1}{z}, zmmword ptr [r10]
          vpshufb zmm11, zmm11, zmm16
          vpxorq zmm11, zmm11, zmm14
          vmovdqu64 zmm15, zmmword ptr [rdi+120h]
          vpclmulqdq zmm9, zmm11, zmm15, 11h
          vpclmulqdq zmm10, zmm11, zmm15, 0
          vpclmulqdq zmm12, zmm11, zmm15, 1
          vpclmulqdq zmm13, zmm11, zmm15, 10h
          vpxorq zmm12, zmm12, zmm13
          vpsrldq zmm7, zmm12, 8
          vpslldq zmm8, zmm12, 8
          vpxorq zmm1, zmm9, zmm7
          vpxorq zmm6, zmm10, zmm8
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 < 6 ) /*0x102d0d06a*/
      {
        _R12 = _R12 - 512; /*0x102d0e044*/
        __asm { kmovq k1, qword ptr [r12] } /*0x102d0e04b*/
        v1300 = *(__m512i *)_R10; /*0x102d0e051*/
        __asm /*0x102d0e051*/
        {
          vmovdqu8 zmm11, zmmword ptr [r10]
          vmovdqu8 xmm3{k1}{z}, xmmword ptr [r10+40h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb xmm3, xmm3, xmm16
          vpxorq zmm11, zmm11, zmm14
        }
        v1301 = *(__m512i *)(_RDI + 34); /*0x102d0e070*/
        __asm /*0x102d0e070*/
        {
          vmovdqu64 zmm15, zmmword ptr [rdi+110h]
          vpclmulqdq zmm9, zmm11, zmm15, 11h
          vpclmulqdq zmm10, zmm11, zmm15, 0
          vpclmulqdq zmm12, zmm11, zmm15, 1
          vpclmulqdq zmm13, zmm11, zmm15, 10h
          vmovdqu64 xmm15, xmmword ptr [rdi+150h]
          vpclmulqdq xmm7, xmm3, xmm15, 1
          vpclmulqdq xmm8, xmm3, xmm15, 10h
          vpclmulqdq xmm1, xmm3, xmm15, 11h
          vpclmulqdq xmm6, xmm3, xmm15, 0
          vpxorq zmm7, zmm7, zmm12
          vpxorq zmm8, zmm8, zmm13
          vpxorq zmm1, zmm1, zmm9
          vpxorq zmm6, zmm6, zmm10
          vpxorq zmm7, zmm7, zmm8
          vpsrldq zmm12, zmm7, 8
          vpslldq zmm13, zmm7, 8
          vpxorq zmm1, zmm1, zmm12
          vpxorq zmm6, zmm6, zmm13
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 == 6 ) /*0x102d0d070*/
      {
        _R12 = _R12 - 512; /*0x102d0df2b*/
        __asm /*0x102d0df32*/
        {
          kmovq k1, qword ptr [r12]
          vmovdqu8 zmm11, zmmword ptr [r10]
          vmovdqu8 ymm3{k1}{z}, ymmword ptr [r10+40h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb ymm3, ymm3, ymm16
          vpxorq zmm11, zmm11, zmm14
          vmovdqu64 zmm15, zmmword ptr [rdi+100h]
          vpclmulqdq zmm9, zmm11, zmm15, 11h
          vpclmulqdq zmm10, zmm11, zmm15, 0
          vpclmulqdq zmm12, zmm11, zmm15, 1
          vpclmulqdq zmm13, zmm11, zmm15, 10h
          vmovdqu64 ymm15, ymmword ptr [rdi+140h]
          vpclmulqdq ymm7, ymm3, ymm15, 1
          vpclmulqdq ymm8, ymm3, ymm15, 10h
          vpclmulqdq ymm1, ymm3, ymm15, 11h
          vpclmulqdq ymm6, ymm3, ymm15, 0
          vpxorq zmm7, zmm7, zmm12
          vpxorq zmm8, zmm8, zmm13
          vpxorq zmm1, zmm1, zmm9
          vpxorq zmm6, zmm6, zmm10
          vpxorq zmm7, zmm7, zmm8
          vpsrldq zmm12, zmm7, 8
          vpslldq zmm13, zmm7, 8
          vpxorq zmm1, zmm1, zmm12
          vpxorq zmm6, zmm6, zmm13
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 < 8 ) /*0x102d0d07a*/
      {
        _R12 = _R12 - 512; /*0x102d0de00*/
        __asm { kmovq k1, qword ptr [r12] } /*0x102d0de07*/
        v1297 = *(__m512i *)_R10; /*0x102d0de0d*/
        __asm { vmovdqu8 zmm11, zmmword ptr [r10] } /*0x102d0de0d*/
        v1298 = *(__m512i *)(_R10 + 64); /*0x102d0de13*/
        __asm /*0x102d0de13*/
        {
          vmovdqu8 zmm3{k1}{z}, zmmword ptr [r10+40h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpxorq zmm11, zmm11, zmm14
        }
        v1299 = *(__m512i *)(_RDI + 30); /*0x102d0de2c*/
        __asm /*0x102d0de2c*/
        {
          vmovdqu64 zmm15, zmmword ptr [rdi+0F0h]
          vpclmulqdq zmm9, zmm11, zmm15, 11h
          vpclmulqdq zmm10, zmm11, zmm15, 0
          vpclmulqdq zmm12, zmm11, zmm15, 1
          vpclmulqdq zmm13, zmm11, zmm15, 10h
          vmovdqu64 ymm15, ymmword ptr [rdi+130h]
          vinserti64x2 zmm15, zmm15, xmmword ptr [rdi+150h], 2
          vpclmulqdq zmm7, zmm3, zmm15, 1
          vpclmulqdq zmm8, zmm3, zmm15, 10h
          vpclmulqdq zmm1, zmm3, zmm15, 11h
          vpclmulqdq zmm6, zmm3, zmm15, 0
          vpxorq zmm7, zmm7, zmm12
          vpxorq zmm8, zmm8, zmm13
          vpxorq zmm1, zmm1, zmm9
          vpxorq zmm6, zmm6, zmm10
          vpxorq zmm7, zmm7, zmm8
          vpsrldq zmm12, zmm7, 8
          vpslldq zmm13, zmm7, 8
          vpxorq zmm1, zmm1, zmm12
          vpxorq zmm6, zmm6, zmm13
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 == 8 ) /*0x102d0d080*/
      {
        _R12 = _R12 - 512; /*0x102d0dcdd*/
        __asm /*0x102d0dce4*/
        {
          kmovq k1, qword ptr [r12]
          vmovdqu8 zmm11, zmmword ptr [r10]
          vmovdqu8 zmm3{k1}{z}, zmmword ptr [r10+40h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpxorq zmm11, zmm11, zmm14
          vmovdqu64 zmm15, zmmword ptr [rdi+0E0h]
          vpclmulqdq zmm1, zmm11, zmm15, 11h
          vpclmulqdq zmm6, zmm11, zmm15, 0
          vpclmulqdq zmm7, zmm11, zmm15, 1
          vpclmulqdq zmm8, zmm11, zmm15, 10h
          vmovdqu64 zmm15, zmmword ptr [rdi+120h]
          vpclmulqdq zmm9, zmm3, zmm15, 11h
          vpclmulqdq zmm10, zmm3, zmm15, 0
          vpclmulqdq zmm12, zmm3, zmm15, 1
          vpclmulqdq zmm13, zmm3, zmm15, 10h
          vpxorq zmm9, zmm1, zmm9
          vpxorq zmm10, zmm6, zmm10
          vpxorq zmm12, zmm7, zmm12
          vpxorq zmm13, zmm8, zmm13
          vpxorq zmm12, zmm12, zmm13
          vpsrldq zmm7, zmm12, 8
          vpslldq zmm8, zmm12, 8
          vpxorq zmm1, zmm9, zmm7
          vpxorq zmm6, zmm10, zmm8
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 < 0xA ) /*0x102d0d08a*/
      {
        _R12 = _R12 - 1024; /*0x102d0db76*/
        __asm { kmovq k1, qword ptr [r12] } /*0x102d0db7d*/
        v1293 = *(__m512i *)_R10; /*0x102d0db83*/
        __asm { vmovdqu8 zmm11, zmmword ptr [r10] } /*0x102d0db83*/
        v1294 = *(__m512i *)(_R10 + 64); /*0x102d0db89*/
        __asm /*0x102d0db89*/
        {
          vmovdqu8 zmm3, zmmword ptr [r10+40h]
          vmovdqu8 xmm4{k1}{z}, xmmword ptr [r10+80h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb xmm4, xmm4, xmm16
          vpxorq zmm11, zmm11, zmm14
        }
        v1295 = *(__m512i *)(_RDI + 26); /*0x102d0dbaf*/
        __asm /*0x102d0dbaf*/
        {
          vmovdqu64 zmm15, zmmword ptr [rdi+0D0h]
          vpclmulqdq zmm1, zmm11, zmm15, 11h
          vpclmulqdq zmm6, zmm11, zmm15, 0
          vpclmulqdq zmm7, zmm11, zmm15, 1
          vpclmulqdq zmm8, zmm11, zmm15, 10h
        }
        v1296 = *(__m512i *)(_RDI + 34); /*0x102d0dbd5*/
        __asm /*0x102d0dbd5*/
        {
          vmovdqu64 zmm15, zmmword ptr [rdi+110h]
          vpclmulqdq zmm9, zmm3, zmm15, 11h
          vpclmulqdq zmm10, zmm3, zmm15, 0
          vpclmulqdq zmm12, zmm3, zmm15, 1
          vpclmulqdq zmm13, zmm3, zmm15, 10h
          vpxorq zmm9, zmm1, zmm9
          vpxorq zmm10, zmm6, zmm10
          vpxorq zmm12, zmm7, zmm12
          vpxorq zmm13, zmm8, zmm13
          vmovdqu64 xmm15, xmmword ptr [rdi+150h]
          vpclmulqdq xmm7, xmm4, xmm15, 1
          vpclmulqdq xmm8, xmm4, xmm15, 10h
          vpclmulqdq xmm1, xmm4, xmm15, 11h
          vpclmulqdq xmm6, xmm4, xmm15, 0
          vpxorq zmm7, zmm7, zmm12
          vpxorq zmm8, zmm8, zmm13
          vpxorq zmm1, zmm1, zmm9
          vpxorq zmm6, zmm6, zmm10
          vpxorq zmm7, zmm7, zmm8
          vpsrldq zmm12, zmm7, 8
          vpslldq zmm13, zmm7, 8
          vpxorq zmm1, zmm1, zmm12
          vpxorq zmm6, zmm6, zmm13
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 == 10 ) /*0x102d0d090*/
      {
        _R12 = _R12 - 1024; /*0x102d0da15*/
        __asm /*0x102d0da1c*/
        {
          kmovq k1, qword ptr [r12]
          vmovdqu8 zmm11, zmmword ptr [r10]
          vmovdqu8 zmm3, zmmword ptr [r10+40h]
          vmovdqu8 ymm4{k1}{z}, ymmword ptr [r10+80h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb ymm4, ymm4, ymm16
          vpxorq zmm11, zmm11, zmm14
          vmovdqu64 zmm15, zmmword ptr [rdi+0C0h]
          vpclmulqdq zmm1, zmm11, zmm15, 11h
          vpclmulqdq zmm6, zmm11, zmm15, 0
          vpclmulqdq zmm7, zmm11, zmm15, 1
          vpclmulqdq zmm8, zmm11, zmm15, 10h
          vmovdqu64 zmm15, zmmword ptr [rdi+100h]
          vpclmulqdq zmm9, zmm3, zmm15, 11h
          vpclmulqdq zmm10, zmm3, zmm15, 0
          vpclmulqdq zmm12, zmm3, zmm15, 1
          vpclmulqdq zmm13, zmm3, zmm15, 10h
          vpxorq zmm9, zmm1, zmm9
          vpxorq zmm10, zmm6, zmm10
          vpxorq zmm12, zmm7, zmm12
          vpxorq zmm13, zmm8, zmm13
          vmovdqu64 ymm15, ymmword ptr [rdi+140h]
          vpclmulqdq ymm7, ymm4, ymm15, 1
          vpclmulqdq ymm8, ymm4, ymm15, 10h
          vpclmulqdq ymm1, ymm4, ymm15, 11h
          vpclmulqdq ymm6, ymm4, ymm15, 0
          vpxorq zmm7, zmm7, zmm12
          vpxorq zmm8, zmm8, zmm13
          vpxorq zmm1, zmm1, zmm9
          vpxorq zmm6, zmm6, zmm10
          vpxorq zmm7, zmm7, zmm8
          vpsrldq zmm12, zmm7, 8
          vpslldq zmm13, zmm7, 8
          vpxorq zmm1, zmm1, zmm12
          vpxorq zmm6, zmm6, zmm13
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 < 0xC ) /*0x102d0d09a*/
      {
        _R12 = _R12 - 1024; /*0x102d0d89f*/
        __asm { kmovq k1, qword ptr [r12] } /*0x102d0d8a6*/
        v1288 = *(__m512i *)_R10; /*0x102d0d8ac*/
        __asm { vmovdqu8 zmm11, zmmword ptr [r10] } /*0x102d0d8ac*/
        v1289 = *(__m512i *)(_R10 + 64); /*0x102d0d8b2*/
        __asm { vmovdqu8 zmm3, zmmword ptr [r10+40h] } /*0x102d0d8b2*/
        v1290 = *(__m512i *)(_R10 + 128); /*0x102d0d8b9*/
        __asm /*0x102d0d8b9*/
        {
          vmovdqu8 zmm4{k1}{z}, zmmword ptr [r10+80h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb zmm4, zmm4, zmm16
          vpxorq zmm11, zmm11, zmm14
        }
        v1291 = *(__m512i *)(_RDI + 22); /*0x102d0d8d8*/
        __asm /*0x102d0d8d8*/
        {
          vmovdqu64 zmm15, zmmword ptr [rdi+0B0h]
          vpclmulqdq zmm1, zmm11, zmm15, 11h
          vpclmulqdq zmm6, zmm11, zmm15, 0
          vpclmulqdq zmm7, zmm11, zmm15, 1
          vpclmulqdq zmm8, zmm11, zmm15, 10h
        }
        v1292 = *(__m512i *)(_RDI + 30); /*0x102d0d8fe*/
        __asm /*0x102d0d8fe*/
        {
          vmovdqu64 zmm15, zmmword ptr [rdi+0F0h]
          vpclmulqdq zmm9, zmm3, zmm15, 11h
          vpclmulqdq zmm10, zmm3, zmm15, 0
          vpclmulqdq zmm12, zmm3, zmm15, 1
          vpclmulqdq zmm13, zmm3, zmm15, 10h
          vpxorq zmm9, zmm1, zmm9
          vpxorq zmm10, zmm6, zmm10
          vpxorq zmm12, zmm7, zmm12
          vpxorq zmm13, zmm8, zmm13
          vmovdqu64 ymm15, ymmword ptr [rdi+130h]
          vinserti64x2 zmm15, zmm15, xmmword ptr [rdi+150h], 2
          vpclmulqdq zmm7, zmm4, zmm15, 1
          vpclmulqdq zmm8, zmm4, zmm15, 10h
          vpclmulqdq zmm1, zmm4, zmm15, 11h
          vpclmulqdq zmm6, zmm4, zmm15, 0
          vpxorq zmm7, zmm7, zmm12
          vpxorq zmm8, zmm8, zmm13
          vpxorq zmm1, zmm1, zmm9
          vpxorq zmm6, zmm6, zmm10
          vpxorq zmm7, zmm7, zmm8
          vpsrldq zmm12, zmm7, 8
          vpslldq zmm13, zmm7, 8
          vpxorq zmm1, zmm1, zmm12
          vpxorq zmm6, zmm6, zmm13
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 == 12 ) /*0x102d0d0a0*/
      {
        _R12 = _R12 - 1024; /*0x102d0d745*/
        __asm /*0x102d0d74c*/
        {
          kmovq k1, qword ptr [r12]
          vmovdqu8 zmm11, zmmword ptr [r10]
          vmovdqu8 zmm3, zmmword ptr [r10+40h]
          vmovdqu8 zmm4{k1}{z}, zmmword ptr [r10+80h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb zmm4, zmm4, zmm16
          vpxorq zmm11, zmm11, zmm14
          vmovdqu64 zmm15, zmmword ptr [rdi+0A0h]
          vpclmulqdq zmm1, zmm11, zmm15, 11h
          vpclmulqdq zmm6, zmm11, zmm15, 0
          vpclmulqdq zmm7, zmm11, zmm15, 1
          vpclmulqdq zmm8, zmm11, zmm15, 10h
          vmovdqu64 zmm15, zmmword ptr [rdi+0E0h]
          vpclmulqdq zmm9, zmm3, zmm15, 11h
          vpclmulqdq zmm10, zmm3, zmm15, 0
          vpclmulqdq zmm12, zmm3, zmm15, 1
          vpclmulqdq zmm13, zmm3, zmm15, 10h
          vmovdqu64 zmm15, zmmword ptr [rdi+120h]
          vpclmulqdq zmm11, zmm4, zmm15, 11h
          vpclmulqdq zmm3, zmm4, zmm15, 0
          vpternlogq zmm9, zmm11, zmm1, 96h
          vpternlogq zmm10, zmm3, zmm6, 96h
          vpclmulqdq zmm11, zmm4, zmm15, 1
          vpclmulqdq zmm3, zmm4, zmm15, 10h
          vpternlogq zmm12, zmm11, zmm7, 96h
          vpternlogq zmm13, zmm3, zmm8, 96h
          vpxorq zmm12, zmm12, zmm13
          vpsrldq zmm7, zmm12, 8
          vpslldq zmm8, zmm12, 8
          vpxorq zmm1, zmm9, zmm7
          vpxorq zmm6, zmm10, zmm8
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 < 0xE ) /*0x102d0d0aa*/
      {
        _R12 = _R12 - 1536; /*0x102d0d5a7*/
        __asm { kmovq k1, qword ptr [r12] } /*0x102d0d5ae*/
        v1282 = *(__m512i *)_R10; /*0x102d0d5b4*/
        __asm { vmovdqu8 zmm11, zmmword ptr [r10] } /*0x102d0d5b4*/
        v1283 = *(__m512i *)(_R10 + 64); /*0x102d0d5ba*/
        __asm { vmovdqu8 zmm3, zmmword ptr [r10+40h] } /*0x102d0d5ba*/
        v1284 = *(__m512i *)(_R10 + 128); /*0x102d0d5c1*/
        __asm /*0x102d0d5c1*/
        {
          vmovdqu8 zmm4, zmmword ptr [r10+80h]
          vmovdqu8 xmm5{k1}{z}, xmmword ptr [r10+0C0h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb zmm4, zmm4, zmm16
          vpshufb xmm5, xmm5, xmm16
          vpxorq zmm11, zmm11, zmm14
        }
        v1285 = *(__m512i *)(_RDI + 18); /*0x102d0d5ed*/
        __asm /*0x102d0d5ed*/
        {
          vmovdqu64 zmm15, zmmword ptr [rdi+90h]
          vpclmulqdq zmm1, zmm11, zmm15, 11h
          vpclmulqdq zmm6, zmm11, zmm15, 0
          vpclmulqdq zmm7, zmm11, zmm15, 1
          vpclmulqdq zmm8, zmm11, zmm15, 10h
        }
        v1286 = *(__m512i *)(_RDI + 26); /*0x102d0d613*/
        __asm /*0x102d0d613*/
        {
          vmovdqu64 zmm15, zmmword ptr [rdi+0D0h]
          vpclmulqdq zmm9, zmm3, zmm15, 11h
          vpclmulqdq zmm10, zmm3, zmm15, 0
          vpclmulqdq zmm12, zmm3, zmm15, 1
          vpclmulqdq zmm13, zmm3, zmm15, 10h
        }
        v1287 = *(__m512i *)(_RDI + 34); /*0x102d0d639*/
        __asm /*0x102d0d639*/
        {
          vmovdqu64 zmm15, zmmword ptr [rdi+110h]
          vpclmulqdq zmm11, zmm4, zmm15, 11h
          vpclmulqdq zmm3, zmm4, zmm15, 0
          vpternlogq zmm9, zmm11, zmm1, 96h
          vpternlogq zmm10, zmm3, zmm6, 96h
          vpclmulqdq zmm11, zmm4, zmm15, 1
          vpclmulqdq zmm3, zmm4, zmm15, 10h
          vpternlogq zmm12, zmm11, zmm7, 96h
          vpternlogq zmm13, zmm3, zmm8, 96h
          vmovdqu64 xmm15, xmmword ptr [rdi+150h]
          vpclmulqdq xmm7, xmm5, xmm15, 1
          vpclmulqdq xmm8, xmm5, xmm15, 10h
          vpclmulqdq xmm1, xmm5, xmm15, 11h
          vpclmulqdq xmm6, xmm5, xmm15, 0
          vpxorq zmm7, zmm7, zmm12
          vpxorq zmm8, zmm8, zmm13
          vpxorq zmm1, zmm1, zmm9
          vpxorq zmm6, zmm6, zmm10
          vpxorq zmm7, zmm7, zmm8
          vpsrldq zmm12, zmm7, 8
          vpslldq zmm13, zmm7, 8
          vpxorq zmm1, zmm1, zmm12
          vpxorq zmm6, zmm6, zmm13
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else if ( v505 == 14 ) /*0x102d0d0b0*/
      {
        _R12 = _R12 - 1536; /*0x102d0d412*/
        __asm /*0x102d0d419*/
        {
          kmovq k1, qword ptr [r12]
          vmovdqu8 zmm11, zmmword ptr [r10]
          vmovdqu8 zmm3, zmmword ptr [r10+40h]
          vmovdqu8 zmm4, zmmword ptr [r10+80h]
          vmovdqu8 ymm5{k1}{z}, ymmword ptr [r10+0C0h]
          vpshufb zmm11, zmm11, zmm16
          vpshufb zmm3, zmm3, zmm16
          vpshufb zmm4, zmm4, zmm16
          vpshufb ymm5, ymm5, ymm16
          vpxorq zmm11, zmm11, zmm14
          vmovdqu64 zmm15, zmmword ptr [rdi+80h]
          vpclmulqdq zmm1, zmm11, zmm15, 11h
          vpclmulqdq zmm6, zmm11, zmm15, 0
          vpclmulqdq zmm7, zmm11, zmm15, 1
          vpclmulqdq zmm8, zmm11, zmm15, 10h
          vmovdqu64 zmm15, zmmword ptr [rdi+0C0h]
          vpclmulqdq zmm9, zmm3, zmm15, 11h
          vpclmulqdq zmm10, zmm3, zmm15, 0
          vpclmulqdq zmm12, zmm3, zmm15, 1
          vpclmulqdq zmm13, zmm3, zmm15, 10h
          vmovdqu64 zmm15, zmmword ptr [rdi+100h]
          vpclmulqdq zmm11, zmm4, zmm15, 11h
          vpclmulqdq zmm3, zmm4, zmm15, 0
          vpternlogq zmm9, zmm11, zmm1, 96h
          vpternlogq zmm10, zmm3, zmm6, 96h
          vpclmulqdq zmm11, zmm4, zmm15, 1
          vpclmulqdq zmm3, zmm4, zmm15, 10h
          vpternlogq zmm12, zmm11, zmm7, 96h
          vpternlogq zmm13, zmm3, zmm8, 96h
          vmovdqu64 ymm15, ymmword ptr [rdi+140h]
          vpclmulqdq ymm7, ymm5, ymm15, 1
          vpclmulqdq ymm8, ymm5, ymm15, 10h
          vpclmulqdq ymm1, ymm5, ymm15, 11h
          vpclmulqdq ymm6, ymm5, ymm15, 0
          vpxorq zmm7, zmm7, zmm12
          vpxorq zmm8, zmm8, zmm13
          vpxorq zmm1, zmm1, zmm9
          vpxorq zmm6, zmm6, zmm10
          vpxorq zmm7, zmm7, zmm8
          vpsrldq zmm12, zmm7, 8
          vpslldq zmm13, zmm7, 8
          vpxorq zmm1, zmm1, zmm12
          vpxorq zmm6, zmm6, zmm13
          vextracti64x4 ymm12, zmm1, 1
          vpxorq ymm1, ymm1, ymm12
          vextracti32x4 xmm12, ymm1, 1
          vpxorq xmm1, xmm1, xmm12
          vextracti64x4 ymm13, zmm6, 1
          vpxorq ymm6, ymm6, ymm13
          vextracti32x4 xmm13, ymm6, 1
          vpxorq xmm6, xmm6, xmm13
          vmovdqa64 xmm15, xmmword ptr cs:POLY2
          vpclmulqdq xmm7, xmm15, xmm6, 1
          vpslldq xmm7, xmm7, 8
          vpxorq xmm7, xmm6, xmm7
          vpclmulqdq xmm8, xmm15, xmm7, 0
          vpsrldq xmm8, xmm8, 4
          vpclmulqdq xmm14, xmm15, xmm7, 10h
          vpslldq xmm14, xmm14, 4
          vpternlogq xmm14, xmm8, xmm1, 96h
        }
      }
      else
      {
        _R12 = _R12 - 1536; /*0x102d0d0c0*/
        if ( v505 == 15 ) /*0x102d0d0ba*/
        {
          __asm /*0x102d0d26c*/
          {
            kmovq k1, qword ptr [r12]
            vmovdqu8 zmm11, zmmword ptr [r10]
            vmovdqu8 zmm3, zmmword ptr [r10+40h]
            vmovdqu8 zmm4, zmmword ptr [r10+80h]
            vmovdqu8 zmm5{k1}{z}, zmmword ptr [r10+0C0h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb zmm3, zmm3, zmm16
            vpshufb zmm4, zmm4, zmm16
            vpshufb zmm5, zmm5, zmm16
            vpxorq zmm11, zmm11, zmm14
            vmovdqu64 zmm15, zmmword ptr [rdi+70h]
            vpclmulqdq zmm1, zmm11, zmm15, 11h
            vpclmulqdq zmm6, zmm11, zmm15, 0
            vpclmulqdq zmm7, zmm11, zmm15, 1
            vpclmulqdq zmm8, zmm11, zmm15, 10h
            vmovdqu64 zmm15, zmmword ptr [rdi+0B0h]
            vpclmulqdq zmm9, zmm3, zmm15, 11h
            vpclmulqdq zmm10, zmm3, zmm15, 0
            vpclmulqdq zmm12, zmm3, zmm15, 1
            vpclmulqdq zmm13, zmm3, zmm15, 10h
            vmovdqu64 zmm15, zmmword ptr [rdi+0F0h]
            vpclmulqdq zmm11, zmm4, zmm15, 11h
            vpclmulqdq zmm3, zmm4, zmm15, 0
            vpternlogq zmm9, zmm11, zmm1, 96h
            vpternlogq zmm10, zmm3, zmm6, 96h
            vpclmulqdq zmm11, zmm4, zmm15, 1
            vpclmulqdq zmm3, zmm4, zmm15, 10h
            vpternlogq zmm12, zmm11, zmm7, 96h
            vpternlogq zmm13, zmm3, zmm8, 96h
            vmovdqu64 ymm15, ymmword ptr [rdi+130h]
            vinserti64x2 zmm15, zmm15, xmmword ptr [rdi+150h], 2
            vpclmulqdq zmm7, zmm5, zmm15, 1
            vpclmulqdq zmm8, zmm5, zmm15, 10h
            vpclmulqdq zmm1, zmm5, zmm15, 11h
            vpclmulqdq zmm6, zmm5, zmm15, 0
            vpxorq zmm7, zmm7, zmm12
            vpxorq zmm8, zmm8, zmm13
            vpxorq zmm1, zmm1, zmm9
            vpxorq zmm6, zmm6, zmm10
            vpxorq zmm7, zmm7, zmm8
            vpsrldq zmm12, zmm7, 8
            vpslldq zmm13, zmm7, 8
            vpxorq zmm1, zmm1, zmm12
            vpxorq zmm6, zmm6, zmm13
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm14, xmm15, xmm7, 10h
            vpslldq xmm14, xmm14, 4
            vpternlogq xmm14, xmm8, xmm1, 96h
          }
        }
        else
        {
          __asm /*0x102d0d0c7*/
          {
            kmovq k1, qword ptr [r12]
            vmovdqu8 zmm11, zmmword ptr [r10]
            vmovdqu8 zmm3, zmmword ptr [r10+40h]
            vmovdqu8 zmm4, zmmword ptr [r10+80h]
            vmovdqu8 zmm5{k1}{z}, zmmword ptr [r10+0C0h]
            vpshufb zmm11, zmm11, zmm16
            vpshufb zmm3, zmm3, zmm16
            vpshufb zmm4, zmm4, zmm16
            vpshufb zmm5, zmm5, zmm16
            vpxorq zmm11, zmm11, zmm14
            vmovdqu64 zmm15, zmmword ptr [rdi+60h]
            vpclmulqdq zmm1, zmm11, zmm15, 11h
            vpclmulqdq zmm6, zmm11, zmm15, 0
            vpclmulqdq zmm7, zmm11, zmm15, 1
            vpclmulqdq zmm8, zmm11, zmm15, 10h
            vmovdqu64 zmm15, zmmword ptr [rdi+0A0h]
            vpclmulqdq zmm9, zmm3, zmm15, 11h
            vpclmulqdq zmm10, zmm3, zmm15, 0
            vpclmulqdq zmm12, zmm3, zmm15, 1
            vpclmulqdq zmm13, zmm3, zmm15, 10h
            vmovdqu64 zmm15, zmmword ptr [rdi+0E0h]
            vpclmulqdq zmm11, zmm4, zmm15, 11h
            vpclmulqdq zmm3, zmm4, zmm15, 0
            vpternlogq zmm1, zmm11, zmm9, 96h
            vpternlogq zmm6, zmm3, zmm10, 96h
            vpclmulqdq zmm11, zmm4, zmm15, 1
            vpclmulqdq zmm3, zmm4, zmm15, 10h
            vpternlogq zmm7, zmm11, zmm12, 96h
            vpternlogq zmm8, zmm3, zmm13, 96h
            vmovdqu64 zmm15, zmmword ptr [rdi+120h]
            vpclmulqdq zmm9, zmm5, zmm15, 11h
            vpclmulqdq zmm10, zmm5, zmm15, 0
            vpclmulqdq zmm12, zmm5, zmm15, 1
            vpclmulqdq zmm13, zmm5, zmm15, 10h
            vpxorq zmm9, zmm1, zmm9
            vpxorq zmm10, zmm6, zmm10
            vpxorq zmm12, zmm7, zmm12
            vpxorq zmm13, zmm8, zmm13
            vpxorq zmm12, zmm12, zmm13
            vpsrldq zmm7, zmm12, 8
            vpslldq zmm8, zmm12, 8
            vpxorq zmm1, zmm9, zmm7
            vpxorq zmm6, zmm10, zmm8
            vextracti64x4 ymm12, zmm1, 1
            vpxorq ymm1, ymm1, ymm12
            vextracti32x4 xmm12, ymm1, 1
            vpxorq xmm1, xmm1, xmm12
            vextracti64x4 ymm13, zmm6, 1
            vpxorq ymm6, ymm6, ymm13
            vextracti32x4 xmm13, ymm6, 1
            vpxorq xmm6, xmm6, xmm13
            vmovdqa64 xmm15, xmmword ptr cs:POLY2
            vpclmulqdq xmm7, xmm15, xmm6, 1
            vpslldq xmm7, xmm7, 8
            vpxorq xmm7, xmm6, xmm7
            vpclmulqdq xmm8, xmm15, xmm7, 0
            vpsrldq xmm8, xmm8, 4
            vpclmulqdq xmm14, xmm15, xmm7, 10h
            vpslldq xmm14, xmm14, 4
            vpternlogq xmm14, xmm8, xmm1, 96h
          }
        }
      }
    }
  }
LABEL_47:
  __asm { vmovdqu64 xmmword ptr [rdi+40h], xmm14 } /*0x102d0e499*/
  if ( a3 > 0x100 ) /*0x102d0e4a7*/
  {
    __asm /*0x102d0e4a9*/
    {
      vpxor xmm0, xmm0, xmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_364], zmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_324], zmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_2E4], zmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_2A4], zmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_264], zmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_224], zmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_1E4], zmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_1A4], zmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_164], zmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_124], zmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_E4], zmm0
      vmovdqa64 zmmword ptr [rsp+364h+var_A4], zmm0
    }
  }
  __asm { vzeroupper } /*0x102d0e50c*/
}

// Address: 0x102d0e520 | Name: _ossl_aes_gcm_encrypt_avx512
// DECOMPILATION RETURNED NOTHING

// Address: 0x102d60c20 | Name: _ossl_aes_gcm_decrypt_avx512
// DECOMPILATION RETURNED NOTHING

// Address: 0x102db3320 | Name: _ossl_aes_gcm_finalize_avx512
void __fastcall ossl_aes_gcm_finalize_avx512(__int64 _RDI, __int64 a2)
{
  __asm /*0x102db3324*/
  {
    vmovdqu xmm2, xmmword ptr [rdi+150h]
    vmovdqu xmm3, xmmword ptr [rdi+20h]
    vmovdqu xmm4, xmmword ptr [rdi+40h]
  }
  if ( a2 != 0 ) /*0x102db333a*/
  {
    __asm /*0x102db333c*/
    {
      vpclmulqdq xmm0, xmm4, xmm2, 11h
      vpclmulqdq xmm16, xmm4, xmm2, 0
      vpclmulqdq xmm17, xmm4, xmm2, 1
      vpclmulqdq xmm4, xmm4, xmm2, 10h
      vpxorq xmm4, xmm4, xmm17
      vpsrldq xmm17, xmm4, 8
      vpslldq xmm4, xmm4, 8
      vpxorq xmm0, xmm0, xmm17
      vpxorq xmm4, xmm4, xmm16
      vmovdqu64 xmm17, xmmword ptr cs:POLY2
      vpclmulqdq xmm16, xmm17, xmm4, 1
      vpslldq xmm16, xmm16, 8
      vpxorq xmm4, xmm4, xmm16
      vpclmulqdq xmm16, xmm17, xmm4, 0
      vpsrldq xmm16, xmm16, 4
      vpclmulqdq xmm4, xmm17, xmm4, 10h
      vpslldq xmm4, xmm4, 4
      vpternlogq xmm4, xmm0, xmm16, 96h
    }
  }
  __asm /*0x102db33b3*/
  {
    vmovq xmm5, qword ptr [rdi+38h]
    vpinsrq xmm5, xmm5, qword ptr [rdi+30h], 1
    vpsllq xmm5, xmm5, 3
    vpxor xmm4, xmm4, xmm5
    vpclmulqdq xmm0, xmm4, xmm2, 11h
    vpclmulqdq xmm16, xmm4, xmm2, 0
    vpclmulqdq xmm17, xmm4, xmm2, 1
    vpclmulqdq xmm4, xmm4, xmm2, 10h
    vpxorq xmm4, xmm4, xmm17
    vpsrldq xmm17, xmm4, 8
    vpslldq xmm4, xmm4, 8
    vpxorq xmm0, xmm0, xmm17
    vpxorq xmm4, xmm4, xmm16
    vmovdqu64 xmm17, xmmword ptr cs:POLY2
    vpclmulqdq xmm16, xmm17, xmm4, 1
    vpslldq xmm16, xmm16, 8
    vpxorq xmm4, xmm4, xmm16
    vpclmulqdq xmm16, xmm17, xmm4, 0
    vpsrldq xmm16, xmm16, 4
    vpclmulqdq xmm4, xmm17, xmm4, 10h
    vpslldq xmm4, xmm4, 4
    vpternlogq xmm4, xmm0, xmm16, 96h
    vpshufb xmm4, xmm4, xmmword ptr cs:SHUF_MASK
    vpxor xmm3, xmm3, xmm4
    vmovdqu xmmword ptr [rdi+40h], xmm3
  }
}

// Address: 0x102db3460 | Name: _ossl_gcm_gmult_avx512
void __fastcall ossl_gcm_gmult_avx512(__int64 _RDI, __int64 _RSI)
{
  __asm /*0x102db3464*/
  {
    vmovdqu64 xmm1, xmmword ptr [rdi]
    vmovdqu64 xmm2, xmmword ptr [rsi+150h]
    vpclmulqdq xmm3, xmm1, xmm2, 11h
    vpclmulqdq xmm4, xmm1, xmm2, 0
    vpclmulqdq xmm5, xmm1, xmm2, 1
    vpclmulqdq xmm1, xmm1, xmm2, 10h
    vpxorq xmm1, xmm1, xmm5
    vpsrldq xmm5, xmm1, 8
    vpslldq xmm1, xmm1, 8
    vpxorq xmm3, xmm3, xmm5
    vpxorq xmm1, xmm1, xmm4
    vmovdqu64 xmm5, xmmword ptr cs:POLY2
    vpclmulqdq xmm4, xmm5, xmm1, 1
    vpslldq xmm4, xmm4, 8
    vpxorq xmm1, xmm1, xmm4
    vpclmulqdq xmm4, xmm5, xmm1, 0
    vpsrldq xmm4, xmm4, 4
    vpclmulqdq xmm1, xmm5, xmm1, 10h
    vpslldq xmm1, xmm1, 4
    vpternlogq xmm1, xmm3, xmm4, 96h
    vmovdqu64 xmmword ptr [rdi], xmm1
    vzeroupper
  }
}

// Address: 0x102db6180 | Name: _ossl_gcm_init_4bit
__int64 __fastcall ossl_gcm_init_4bit(__int64 a1, __int64 a2, __int64 a3)
{
  int v3; // eax
  unsigned __int64 (__fastcall *v4)(__int64, unsigned __int64 *); // rcx
  bool v5; // zf
  unsigned __int64 (__fastcall *v6)(__int64, unsigned __int64 *); // rax

  v3 = HIDWORD(OPENSSL_ia32cap_P); /*0x102db618b*/
  if ( (~v3 & 0x10400000) != 0 ) /*0x102db6198*/
    v4 = (unsigned __int64 (__fastcall *)(__int64, unsigned __int64 *))gcm_init_clmul; /*0x102db61a3*/
  else
    v4 = (unsigned __int64 (__fastcall *)(__int64, unsigned __int64 *))gcm_init_avx; /*0x102db619a*/
  v5 = (v3 & 2) == 0; /*0x102db61aa*/
  v6 = gcm_init_4bit; /*0x102db61ac*/
  if ( !v5 ) /*0x102db61b3*/
    v6 = v4; /*0x102db61b3*/
  return ((__int64 (__fastcall *)(__int64, __int64, __int64, unsigned __int64 (__fastcall *)(__int64, unsigned __int64 *)))v6)(
           a1,
           a2,
           a3,
           a4: v4);
}

// Address: 0x102db61c0 | Name: _ossl_gcm_gmult_4bit
void ossl_gcm_gmult_4bit()
{
  int v0; // ecx
  void (__cdecl *v1)(); // rax

  v0 = HIDWORD(OPENSSL_ia32cap_P); /*0x102db61cb*/
  if ( (~v0 & 0x10400000) == 0 ) /*0x102db61d7*/
  {
    v1 = gcm_gmult_avx; /*0x102db61d9*/
    if ( (v0 & 2) != 0 ) /*0x102db61e3*/
      goto LABEL_6; /*0x102db61e3*/
    goto LABEL_5; /*0x102db61e3*/
  }
  v1 = (void (__cdecl *)())gcm_gmult_clmul; /*0x102db61e7*/
  if ( (v0 & 2) == 0 ) /*0x102db61f1*/
LABEL_5:
    v1 = (void (__cdecl *)())gcm_gmult_4bit; /*0x102db61f3*/
LABEL_6:
  v1(); /*0x102db61fa*/
}

// Address: 0x102db6200 | Name: _ossl_gcm_ghash_4bit
void __fastcall ossl_gcm_ghash_4bit(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        unsigned __int64 a4,
        __m128 a5,
        __m128 a6,
        __m128 a7)
{
  int v7; // r8d
  void (__fastcall *v8)(__int64, __int64, __int64, unsigned __int64, __m128, __m128, __m128); // rax

  v7 = HIDWORD(OPENSSL_ia32cap_P); /*0x102db620b*/
  if ( (~v7 & 0x10400000) == 0 ) /*0x102db6219*/
  {
    v8 = gcm_ghash_avx; /*0x102db621b*/
    if ( (v7 & 2) != 0 ) /*0x102db6226*/
      goto LABEL_6; /*0x102db6226*/
    goto LABEL_5; /*0x102db6226*/
  }
  v8 = (void (__fastcall *)(__int64, __int64, __int64, unsigned __int64, __m128, __m128, __m128))gcm_ghash_clmul; /*0x102db622a*/
  if ( (v7 & 2) == 0 ) /*0x102db6235*/
LABEL_5:
    v8 = (void (__fastcall *)(__int64, __int64, __int64, unsigned __int64, __m128, __m128, __m128))gcm_ghash_4bit; /*0x102db6237*/
LABEL_6:
  v8(_RDI: a1, a2, _RDX: a3, _RCX: a4, _XMM0: a5, _XMM1: a6, _XMM2: a7); /*0x102db623e*/
}

// Address: 0x102dba240 | Name: _ocb_lookup_l
__int64 __fastcall ocb_lookup_l(__int64 a1, unsigned __int64 a2)
{
  unsigned __int64 v2; // rax
  unsigned __int64 v3; // rbx
  unsigned __int64 v4; // rcx
  unsigned __int64 v6; // rsi
  __int64 v7; // r15
  void *v8; // rax
  __int64 v9; // rcx
  __m128i si128; // xmm0
  __m128i v11; // xmm1
  __int64 v12; // rdx
  unsigned __int8 v13; // r8
  char v14; // si
  unsigned __int8 v15; // r9
  unsigned __int8 v16; // r8
  __m128i v17; // xmm2
  unsigned __int64 v18; // r8

  v2 = a2; /*0x102dba24a*/
  v3 = *(_QWORD *)(a1 + 40); /*0x102dba24d*/
  if ( v3 < a2 ) /*0x102dba254*/
  {
    v4 = *(_QWORD *)(a1 + 48); /*0x102dba25a*/
    if ( a2 >= v4 ) /*0x102dba264*/
    {
      v6 = v4 + ((a2 - v4) & 0xFFFFFFFFFFFFFFFCLL) + 4; /*0x102dba271*/
      *(_QWORD *)(a1 + 48) = v6; /*0x102dba275*/
      v7 = a1; /*0x102dba279*/
      v8 = CRYPTO_realloc(addr: *(void **)(a1 + 88), num: 16 * (int)v6, file: "crypto/modes/ocb128.c", line: 113); /*0x102dba290*/
      if ( v8 == nullptr ) /*0x102dba298*/
        return 0; /*0x102dba3aa*/
      a1 = v7; /*0x102dba29e*/
      *(_QWORD *)(v7 + 88) = v8; /*0x102dba2a1*/
      v2 = a2; /*0x102dba2a5*/
    }
    v9 = 16 * v3 + 31; /*0x102dba2af*/
    si128 = _mm_load_si128((const __m128i *)&xmmword_1097F7C50); /*0x102dba2b3*/
    v11 = _mm_loadl_epi64((const __m128i *)&qword_10949E0A0); /*0x102dba2bb*/
    do /*0x102dba38d*/
    {
      v12 = *(_QWORD *)(a1 + 88); /*0x102dba2d0*/
      v13 = *(_BYTE *)(v12 + v9 - 16); /*0x102dba2d4*/
      v14 = 2 * v13; /*0x102dba2da*/
      v15 = *(_BYTE *)(v12 + v9 - 17); /*0x102dba2de*/
      *(_BYTE *)(v12 + v9 - 1) = (v13 >> 7) | (2 * v15); /*0x102dba2ef*/
      v16 = *(_BYTE *)(v12 + v9 - 18); /*0x102dba2f4*/
      *(_BYTE *)(v12 + v9 - 2) = (v15 >> 7) | (2 * v16); /*0x102dba305*/
      *(_BYTE *)(v12 + v9 - 3) = (v16 >> 7) | (2 * *(_BYTE *)(v12 + v9 - 19)); /*0x102dba31a*/
      v17 = _mm_cvtsi32_si128(*(_DWORD *)(v12 + v9 - 23)); /*0x102dba31f*/
      *(_DWORD *)(v12 + v9 - 7) = _mm_cvtsi128_si32( /*0x102dba340*/
                                    _mm_or_si128(
                                      _mm_add_epi8(v17, v17),
                                      _mm_and_si128(
                                        _mm_srli_epi16(_mm_cvtsi32_si128(*(_DWORD *)(v12 + v9 - 22)), 7u),
                                        si128)));
      v18 = *(_QWORD *)(v12 + v9 - 31); /*0x102dba346*/
      *(_QWORD *)(v12 + v9 - 15) = _mm_or_si128( /*0x102dba379*/
                                     _mm_add_epi8((__m128i)v18, (__m128i)v18),
                                     _mm_and_si128(
                                       _mm_srli_epi16(_mm_shuffle_epi8(_mm_unpacklo_epi8((__m128i)v18, v17), v11), 7u),
                                       si128)).u64[0];
      *(_BYTE *)(v12 + v9) = v14 ^ ((char)v18 >> 7) & 0x87; /*0x102dba37f*/
      ++v3; /*0x102dba383*/
      v9 += 16; /*0x102dba386*/
    }
    while ( v2 != v3 ); /*0x102dba38d*/
    *(_QWORD *)(a1 + 40) = v2; /*0x102dba393*/
  }
  return *(_QWORD *)(a1 + 88) + 16 * v2; /*0x102dba3a3*/
}

// Address: 0x102dbac40 | Name: _ossl_siv128_new
void *__fastcall ossl_siv128_new(int a1, int a2, int a3, int a4, int a5, __int64 a6)
{
  void *v11; // rax
  void *v12; // r12
  __int64 v14; // [rsp+0h] [rbp-40h]

  v11 = CRYPTO_malloc(num: 64, file: "crypto/modes/siv128.c", line: 150); /*0x102dbac75*/
  if ( v11 != nullptr ) /*0x102dbac7d*/
  {
    v14 = a6; /*0x102dbac7f*/
    v12 = v11; /*0x102dbac83*/
    if ( (unsigned int)ossl_siv128_init(a1: (_DWORD)v11, a2: a1, a3: a2, a4: a3, a5: a4, a6: a5, a7: v14) != 0 ) /*0x102dbaca0*/
      return v12; /*0x102dbaca5*/
    CRYPTO_free(a1: v12); /*0x102dbacb6*/
  }
  return nullptr; /*0x102dbacbd*/
}

// Address: 0x102dbacd0 | Name: _ossl_siv128_init
__int64 __fastcall ossl_siv128_init(__int64 a1, __int64 a2, int a3, __int64 a4, EVP_CIPHER *a5, __int64 a6, __int64 a7)
{
  __int64 result; // rax
  const char *v13; // rax
  EVP_CIPHER_CTX *v14; // rax
  _QWORD *v15; // r15
  __int64 v16; // rax
  _QWORD *v17; // rax
  _QWORD *v18; // rax
  __int128 v19; // [rsp+0h] [rbp-F0h] BYREF
  __int128 v20; // [rsp+10h] [rbp-E0h]
  __int64 v21; // [rsp+20h] [rbp-D0h]
  __int64 v22; // [rsp+28h] [rbp-C8h] BYREF
  __int64 v23; // [rsp+30h] [rbp-C0h]
  EVP_CIPHER *cipher; // [rsp+38h] [rbp-B8h]
  _BYTE v25[40]; // [rsp+40h] [rbp-B0h] BYREF
  __int128 v26; // [rsp+68h] [rbp-88h]
  __int128 v27; // [rsp+78h] [rbp-78h]
  __int64 v28; // [rsp+88h] [rbp-68h]
  __int128 v29; // [rsp+90h] [rbp-60h]
  __int128 v30; // [rsp+A0h] [rbp-50h]
  __int64 v31; // [rsp+B0h] [rbp-40h]

  v22 = 16; /*0x102dbacf2*/
  result = 0; /*0x102dbacfd*/
  if ( a1 != 0 ) /*0x102dbad02*/
  {
    v23 = a6; /*0x102dbad17*/
    *(_OWORD *)a1 = 0; /*0x102dbad21*/
    EVP_CIPHER_CTX_free(a: *(EVP_CIPHER_CTX **)(a1 + 32)); /*0x102dbad28*/
    EVP_MAC_CTX_free(a1: *(_QWORD **)(a1 + 48)); /*0x102dbad31*/
    EVP_MAC_free(a1: *(void **)(a1 + 40)); /*0x102dbad3a*/
    result = 0; /*0x102dbad55*/
    *(_OWORD *)(a1 + 32) = 0; /*0x102dbad5d*/
    *(_QWORD *)(a1 + 48) = 0; /*0x102dbad61*/
    if ( a2 != 0 && a4 != 0 && a5 != nullptr ) /*0x102dbad50*/
    {
      cipher = a5; /*0x102dbad6f*/
      v13 = EVP_CIPHER_get0_name(a1: a4); /*0x102dbad7d*/
      OSSL_PARAM_construct_utf8_string(a1: (__int64)v25, a2: (__int64)"cipher", a3: v13, a4: 0); /*0x102dbad95*/
      OSSL_PARAM_construct_octet_string(a1: (__int64)&v19, a2: (__int64)"key", a3: a2, a4: a3); /*0x102dbadb4*/
      v28 = v21; /*0x102dbadc0*/
      v27 = v20; /*0x102dbadd2*/
      v26 = v19; /*0x102dbadd6*/
      OSSL_PARAM_construct_end(a1: (__int64)&v19); /*0x102dbade4*/
      v31 = v21; /*0x102dbadf0*/
      v30 = v20; /*0x102dbae02*/
      v29 = v19; /*0x102dbae06*/
      v14 = EVP_CIPHER_CTX_new(); /*0x102dbae0a*/
      *(_QWORD *)(a1 + 32) = v14; /*0x102dbae0f*/
      v15 = nullptr; /*0x102dbae12*/
      if ( v14 != nullptr ) /*0x102dbae1b*/
      {
        v16 = EVP_MAC_fetch(a1: v23, a2: (int)"CMAC", a3: a7); /*0x102dbae33*/
        *(_QWORD *)(a1 + 40) = v16; /*0x102dbae38*/
        if ( v16 == 0 /*0x102dbae6b*/
          || (v17 = EVP_MAC_CTX_new(a1: v16), *(_QWORD *)(a1 + 48) = v17, v17 == nullptr)
          || (unsigned int)EVP_MAC_CTX_set_params(a1: v17) == 0 )
        {
LABEL_12:
          v15 = nullptr; /*0x102dbaef3*/
          goto LABEL_13; /*0x102dbaef3*/
        }
        v15 = nullptr; /*0x102dbae77*/
        if ( EVP_EncryptInit_ex( /*0x102dbae90*/
               ctx: *(EVP_CIPHER_CTX **)(a1 + 32),
               cipher,
               impl: nullptr,
               key: (const unsigned __int8 *)(a3 + a2),
               iv: nullptr) != 0 )
        {
          v18 = EVP_MAC_CTX_dup(a1: *(_QWORD **)(a1 + 48)); /*0x102dbae96*/
          if ( v18 != nullptr ) /*0x102dbae9e*/
          {
            v15 = v18; /*0x102dbaea0*/
            if ( (unsigned int)EVP_MAC_update(a1: v18) != 0 /*0x102dbaed4*/
              && (unsigned int)EVP_MAC_final(a1: (__int64)v15, a2: a1, a3: (__int64)&v22, a4: 16) != 0 )
            {
              EVP_MAC_CTX_free(a1: v15); /*0x102dbaed9*/
              *(_QWORD *)(a1 + 56) = 0x1FFFFFFFFLL; /*0x102dbaee8*/
              return 1; /*0x102dbaef1*/
            }
            goto LABEL_13; /*0x102dbaed4*/
          }
          goto LABEL_12; /*0x102dbae9e*/
        }
      }
LABEL_13:
      EVP_CIPHER_CTX_free(a: *(EVP_CIPHER_CTX **)(a1 + 32)); /*0x102dbaef6*/
      EVP_MAC_CTX_free(a1: *(_QWORD **)(a1 + 48)); /*0x102dbaf03*/
      EVP_MAC_CTX_free(a1: v15); /*0x102dbaf0b*/
      EVP_MAC_free(a1: *(void **)(a1 + 40)); /*0x102dbaf14*/
      return 0; /*0x102dbaf19*/
    }
  }
  return result; /*0x102dbaf2b*/
}

// Address: 0x102dbaf50 | Name: _ossl_siv128_copy_ctx
__int64 __fastcall ossl_siv128_copy_ctx(__int64 a1, __int64 a2)
{
  EVP_CIPHER_CTX *v4; // rdi
  unsigned int v5; // r15d
  _QWORD *v6; // rax
  __int64 v7; // rdi

  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x102dbaf63*/
  v4 = *(EVP_CIPHER_CTX **)(a1 + 32); /*0x102dbaf66*/
  if ( v4 != nullptr || (v4 = EVP_CIPHER_CTX_new(), *(_QWORD *)(a1 + 32) = v4, v4 != nullptr) ) /*0x102dbaf7e*/
  {
    v5 = 0; /*0x102dbaf89*/
    if ( (unsigned int)EVP_CIPHER_CTX_copy(__dst: v4, __src: *(__int64 **)(a2 + 32)) != 0 ) /*0x102dbaf8e*/
    {
      EVP_MAC_CTX_free(a1: *(_QWORD **)(a1 + 48)); /*0x102dbaf94*/
      v6 = EVP_MAC_CTX_dup(a1: *(_QWORD **)(a2 + 48)); /*0x102dbaf9d*/
      *(_QWORD *)(a1 + 48) = v6; /*0x102dbafa2*/
      if ( v6 != nullptr ) /*0x102dbafa9*/
      {
        v7 = *(_QWORD *)(a2 + 40); /*0x102dbafab*/
        *(_QWORD *)(a1 + 40) = v7; /*0x102dbafaf*/
        v5 = 1; /*0x102dbafb3*/
        if ( v7 != 0 ) /*0x102dbafbc*/
          EVP_MAC_up_ref(a1: v7); /*0x102dbafbe*/
      }
    }
  }
  else
  {
    return 0; /*0x102dbafc5*/
  }
  return v5; /*0x102dbafcf*/
}

// Address: 0x102dbafe0 | Name: _ossl_siv128_aad
__int64 __fastcall ossl_siv128_aad(__int64 a1)
{
  __int128 v2; // rt0
  _QWORD *v3; // rax
  _QWORD *v4; // r15
  __m128 v6; // [rsp+0h] [rbp-40h] BYREF
  __int64 v7[5]; // [rsp+18h] [rbp-28h] BYREF

  v7[0] = 16; /*0x102dbaff8*/
  *((_QWORD *)&v2 + 1) = _byteswap_uint64(*(_QWORD *)a1); /*0x102dbb01a*/
  *(_QWORD *)&v2 = _byteswap_uint64(*(_QWORD *)(a1 + 8)); /*0x102dbb01a*/
  *(_QWORD *)a1 = _byteswap_uint64(v2 >> 63); /*0x102dbb028*/
  *(_QWORD *)(a1 + 8) = _byteswap_uint64((*((__int64 *)&v2 + 1) >> 63) & 0x87 ^ (2 * v2)); /*0x102dbb02e*/
  v3 = EVP_MAC_CTX_dup(a1: *(_QWORD **)(a1 + 48)); /*0x102dbb036*/
  v4 = v3; /*0x102dbb03b*/
  if ( v3 != nullptr /*0x102dbb073*/
    && (unsigned int)EVP_MAC_update(a1: v3) != 0
    && (unsigned int)EVP_MAC_final(a1: (__int64)v4, a2: (__int64)&v6, a3: (__int64)v7, a4: 16) != 0
    && v7[0] == 16 )
  {
    EVP_MAC_CTX_free(a1: v4); /*0x102dbb078*/
    *(__m128 *)a1 = _mm_xor_ps(*(__m128 *)a1, v6); /*0x102dbb084*/
    return 1; /*0x102dbb087*/
  }
  else
  {
    EVP_MAC_CTX_free(a1: v4); /*0x102dbb091*/
    return 0; /*0x102dbb096*/
  }
}

// Address: 0x102dbb0b0 | Name: _ossl_siv128_encrypt
__int64 __fastcall ossl_siv128_encrypt(__int64 a1, const unsigned __int8 *a2, unsigned __int8 *a3, int a4)
{
  int v4; // eax
  unsigned int v5; // r14d
  EVP_CIPHER_CTX *v10; // r13
  unsigned __int8 *out; // [rsp+8h] [rbp-48h]
  unsigned __int8 iv[20]; // [rsp+10h] [rbp-40h] BYREF
  int outl[11]; // [rsp+24h] [rbp-2Ch] BYREF

  v4 = *(_DWORD *)(a1 + 60); /*0x102dbb0c1*/
  v5 = 0; /*0x102dbb0c4*/
  if ( v4 != 0 ) /*0x102dbb0c9*/
  {
    *(_DWORD *)(a1 + 60) = v4 - 1; /*0x102dbb0dd*/
    if ( (unsigned int)siv128_do_s2v_p(a1, a2: iv, a3: a2) != 0 ) /*0x102dbb0ee*/
    {
      out = a3; /*0x102dbb0f0*/
      *(_OWORD *)(a1 + 16) = *(_OWORD *)iv; /*0x102dbb0f8*/
      iv[8] &= ~0x80u; /*0x102dbb0fc*/
      iv[12] &= ~0x80u; /*0x102dbb100*/
      v10 = *(EVP_CIPHER_CTX **)(a1 + 32); /*0x102dbb104*/
      outl[0] = a4; /*0x102dbb108*/
      v5 = 0; /*0x102dbb10c*/
      if ( EVP_CipherInit_ex(ctx: v10, cipher: nullptr, impl: nullptr, key: nullptr, iv, enc: 1) != 0 /*0x102dbb143*/
        && EVP_EncryptUpdate(ctx: v10, out, outl, in: a2, inl: a4) != 0 )
      {
        *(_DWORD *)(a1 + 56) = 0; /*0x102dbb145*/
        return 1; /*0x102dbb14c*/
      }
    }
  }
  return v5; /*0x102dbb155*/
}

// Address: 0x102dbb2c0 | Name: _ossl_siv128_decrypt
__int64 __fastcall ossl_siv128_decrypt(__m128 *a1, const unsigned __int8 *a2, void *a3, size_t a4)
{
  __int32 v4; // eax
  EVP_CIPHER_CTX *v8; // r15
  unsigned int v9; // ebx
  unsigned __int8 iv[16]; // [rsp+10h] [rbp-50h] BYREF
  int outl[4]; // [rsp+20h] [rbp-40h] BYREF

  v4 = a1[3].i32[3]; /*0x102dbb2d1*/
  if ( v4 != 0 ) /*0x102dbb2d6*/
  {
    a1[3].i32[3] = v4 - 1; /*0x102dbb2eb*/
    *(__m128 *)iv = a1[1]; /*0x102dbb2f2*/
    iv[8] &= ~0x80u; /*0x102dbb2f6*/
    iv[12] &= ~0x80u; /*0x102dbb2fa*/
    v8 = (EVP_CIPHER_CTX *)a1[2].i64[0]; /*0x102dbb2fe*/
    outl[0] = a4; /*0x102dbb302*/
    v9 = 0; /*0x102dbb306*/
    if ( EVP_CipherInit_ex(ctx: v8, cipher: nullptr, impl: nullptr, key: nullptr, iv, enc: 1) != 0 /*0x102dbb355*/
      && EVP_EncryptUpdate(ctx: v8, out: (unsigned __int8 *)a3, outl, in: a2, inl: a4) != 0
      && (unsigned int)siv128_do_s2v_p(a1, a2: outl, a3) != 0 )
    {
      *(__m128 *)outl = _mm_xor_ps(a1[1], *(__m128 *)outl); /*0x102dbb363*/
      if ( *(_OWORD *)outl == 0 ) /*0x102dbb36f*/
      {
        a1[3].i32[2] = 0; /*0x102dbb391*/
        return 1; /*0x102dbb39a*/
      }
      else
      {
        OPENSSL_cleanse(ptr: a3, len: a4); /*0x102dbb377*/
      }
    }
  }
  else
  {
    return 0; /*0x102dbb37e*/
  }
  return v9; /*0x102dbb382*/
}

// Address: 0x102dbb3b0 | Name: _ossl_siv128_finish
__int64 __fastcall ossl_siv128_finish(__int64 a1)
{
  return *(unsigned int *)(a1 + 56); /*0x102dbb3b7*/
}

// Address: 0x102dbb3c0 | Name: _ossl_siv128_set_tag
__int64 __fastcall ossl_siv128_set_tag(__int64 a1, _OWORD *a2, __int64 a3)
{
  __int64 result; // rax

  result = 0; /*0x102dbb3c4*/
  if ( a3 == 16 ) /*0x102dbb3ca*/
  {
    *(_OWORD *)(a1 + 16) = *a2; /*0x102dbb3cf*/
    return 1; /*0x102dbb3d3*/
  }
  return result; /*0x102dbb3d8*/
}

// Address: 0x102dbb3e0 | Name: _ossl_siv128_get_tag
__int64 __fastcall ossl_siv128_get_tag(__int64 a1, _OWORD *a2, __int64 a3)
{
  __int64 result; // rax

  result = 0; /*0x102dbb3e4*/
  if ( a3 == 16 ) /*0x102dbb3ea*/
  {
    *a2 = *(_OWORD *)(a1 + 16); /*0x102dbb3f0*/
    return 1; /*0x102dbb3f3*/
  }
  return result; /*0x102dbb3f8*/
}

// Address: 0x102dbb400 | Name: _ossl_siv128_cleanup
__int64 __fastcall ossl_siv128_cleanup(char *ptr)
{
  if ( ptr != nullptr ) /*0x102dbb403*/
  {
    EVP_CIPHER_CTX_free(a: *((EVP_CIPHER_CTX **)ptr + 4)); /*0x102dbb415*/
    *((_QWORD *)ptr + 4) = 0; /*0x102dbb41a*/
    EVP_MAC_CTX_free(a1: *((_QWORD **)ptr + 6)); /*0x102dbb426*/
    *((_QWORD *)ptr + 6) = 0; /*0x102dbb42b*/
    EVP_MAC_free(a1: *((void **)ptr + 5)); /*0x102dbb437*/
    *((_QWORD *)ptr + 5) = 0; /*0x102dbb43c*/
    OPENSSL_cleanse(ptr, len: 0x10u); /*0x102dbb44c*/
    OPENSSL_cleanse(ptr: ptr + 16, len: 0x10u); /*0x102dbb45a*/
    *((_QWORD *)ptr + 7) = 0x1FFFFFFFFLL; /*0x102dbb469*/
  }
  return 1; /*0x102dbb478*/
}

// Address: 0x102dbb480 | Name: _ossl_siv128_speed
__int64 __fastcall ossl_siv128_speed(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 60) = 2 * (a2 != 1) - 1; /*0x102dbb493*/
  return 1; /*0x102dbb49b*/
}

// Address: 0x102dbc380 | Name: _OBJ_NAME_init
int OBJ_NAME_init(void)
{
  int result; // eax

  result = CRYPTO_THREAD_run_once(a1: &init_2, a2: (void (*)(void))o_names_init_ossl_); /*0x102dbc392*/
  if ( result != 0 ) /*0x102dbc399*/
    return o_names_init_ossl_ret_; /*0x102dbc39b*/
  return result; /*0x102dbc3a1*/
}

// Address: 0x102dbc3b0 | Name: _o_names_init_ossl_
__int64 o_names_init_ossl_()
{
  _QWORD *v0; // rax
  pthread_rwlock_t *v1; // rdi
  bool v2; // cl

  names_lh = nullptr; /*0x102dbc3b4*/
  obj_lock = CRYPTO_THREAD_lock_new(); /*0x102dbc3c4*/
  if ( obj_lock == nullptr ) /*0x102dbc3ce*/
  {
    v1 = nullptr; /*0x102dbc453*/
    v2 = true; /*0x102dbc455*/
    if ( names_lh != nullptr ) /*0x102dbc45a*/
      goto LABEL_4; /*0x102dbc45a*/
    goto LABEL_3; /*0x102dbc45a*/
  }
  v0 = OPENSSL_LH_new(a1: (unsigned __int64)obj_name_hash, a2: (unsigned __int64)obj_name_cmp); /*0x102dbc3de*/
  names_lh = OPENSSL_LH_set_thunks( /*0x102dbc407*/
               a1: v0,
               a2: (__int64)lh_OBJ_NAME_hfn_thunk,
               a3: (__int64)lh_OBJ_NAME_cfn_thunk,
               a4: (__int64)lh_OBJ_NAME_doall_thunk,
               a5: (__int64)lh_OBJ_NAME_doall_arg_thunk);
  v1 = (pthread_rwlock_t *)obj_lock; /*0x102dbc40e*/
  v2 = true; /*0x102dbc415*/
  if ( names_lh == nullptr ) /*0x102dbc41a*/
  {
LABEL_3:
    CRYPTO_THREAD_lock_free(a1: v1); /*0x102dbc41c*/
    obj_lock = nullptr; /*0x102dbc421*/
    v2 = names_lh != nullptr; /*0x102dbc434*/
    v1 = nullptr; /*0x102dbc437*/
  }
LABEL_4:
  o_names_init_ossl_ret_ = v2 && v1 != nullptr; /*0x102dbc439*/
  return v2 & (unsigned __int8)(v1 != nullptr); /*0x102dbc44a*/
}

// Address: 0x102dbc460 | Name: _OBJ_NAME_new_index
int __cdecl OBJ_NAME_new_index(
        unsigned __int64 (__cdecl *hash_func)(const char *),
        int (__cdecl *cmp_func)(const char *, const char *),
        void (__cdecl *free_func)(const char *, int, const char *))
{
  unsigned int v6; // ebx
  __int64 v7; // rsi
  void *v8; // rdi
  int v9; // eax
  int v10; // r13d
  _QWORD *v11; // rax
  void *v12; // r14
  unsigned __int64 (__cdecl **v13)(const char *); // rax
  void (__cdecl *v15)(const char *, int, const char *); // [rsp+0h] [rbp-40h]

  v6 = 0; /*0x102dbc48d*/
  if ( CRYPTO_THREAD_run_once(a1: &init_2, a2: (void (*)(void))o_names_init_ossl_) /*0x102dbc4ab*/
    && o_names_init_ossl_ret_ != 0
    && CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)obj_lock) )
  {
    v8 = name_funcs_stack; /*0x102dbc4b8*/
    if ( name_funcs_stack != nullptr /*0x102dbc4d6*/
      || (v8 = (void *)OPENSSL_sk_new_null(a1: 0, a2: v7), name_funcs_stack = v8, v8 != nullptr) )
    {
      v15 = free_func; /*0x102dbc4e4*/
      v6 = names_type_num++; /*0x102dbc4e8*/
      v9 = OPENSSL_sk_num(a1: v8); /*0x102dbc4f7*/
      if ( v9 >= names_type_num ) /*0x102dbc502*/
      {
LABEL_11:
        v13 = (unsigned __int64 (__cdecl **)(const char *))OPENSSL_sk_value(a1: name_funcs_stack, a2: v6); /*0x102dbc564*/
        if ( hash_func != nullptr ) /*0x102dbc579*/
          *v13 = hash_func; /*0x102dbc57b*/
        if ( cmp_func != nullptr ) /*0x102dbc589*/
          v13[1] = (unsigned __int64 (__cdecl *)(const char *))cmp_func; /*0x102dbc58b*/
        if ( v15 != nullptr ) /*0x102dbc592*/
          v13[2] = (unsigned __int64 (__cdecl *)(const char *))v15; /*0x102dbc594*/
        goto LABEL_19; /*0x102dbc598*/
      }
      v10 = v9; /*0x102dbc504*/
      while ( 1 ) /*0x102dbc531*/
      {
        v11 = CRYPTO_zalloc(__size: 0x18u, __s: "crypto/objects/o_names.c", line: 90); /*0x102dbc531*/
        if ( v11 == nullptr ) /*0x102dbc539*/
          break; /*0x102dbc539*/
        v12 = v11; /*0x102dbc53b*/
        *v11 = ossl_lh_strcasehash; /*0x102dbc53e*/
        v11[1] = OPENSSL_strcasecmp; /*0x102dbc541*/
        if ( (unsigned int)OPENSSL_sk_push(a1: name_funcs_stack, a2: v11) == 0 ) /*0x102dbc556*/
        {
          ERR_new(); /*0x102dbc59e*/
          ERR_set_debug(__s: "crypto/objects/o_names.c", a2: 100, a3: "OBJ_NAME_new_index"); /*0x102dbc5b9*/
          v6 = 0; /*0x102dbc5be*/
          ERR_set_error(a1: 8, a2: 524303, a3: 0); /*0x102dbc5ce*/
          CRYPTO_free(a1: v12); /*0x102dbc5de*/
          goto LABEL_19; /*0x102dbc5de*/
        }
        if ( ++v10 >= names_type_num ) /*0x102dbc562*/
          goto LABEL_11; /*0x102dbc562*/
      }
    }
    v6 = 0; /*0x102dbc59a*/
LABEL_19:
    CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)obj_lock); /*0x102dbc5e3*/
  }
  return v6; /*0x102dbc5f1*/
}

// Address: 0x102dbc600 | Name: _OBJ_NAME_get
const char *__cdecl OBJ_NAME_get(const char *name, int type)
{
  _BOOL4 v4; // ecx
  const char *result; // rax
  __int64 v6; // rax
  const char *v7; // rbx
  _QWORD v8[6]; // [rsp-30h] [rbp-30h] BYREF

  if ( name == nullptr ) /*0x102dbc603*/
    return nullptr; /*0x102dbc825*/
  v4 = CRYPTO_THREAD_run_once(a1: &init_2, a2: (void (*)(void))o_names_init_ossl_); /*0x102dbc62c*/
  result = nullptr; /*0x102dbc62e*/
  if ( v4 && o_names_init_ossl_ret_ != 0 ) /*0x102dbc63f*/
  {
    if ( CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)obj_lock) ) /*0x102dbc64c*/
    {
      v8[1] = name; /*0x102dbc660*/
      LODWORD(v8[0]) = type & 0xFFFF7FFF; /*0x102dbc664*/
      v6 = OPENSSL_LH_retrieve(a1: (__int64)names_lh, a2: (__int64)v8); /*0x102dbc672*/
      if ( v6 == 0 ) /*0x102dbc67a*/
        goto LABEL_28; /*0x102dbc67a*/
      if ( (type & 0x8000u) != 0 ) /*0x102dbc683*/
        goto LABEL_31; /*0x102dbc683*/
      if ( *(_DWORD *)(v6 + 4) == 0 ) /*0x102dbc68d*/
        goto LABEL_31; /*0x102dbc68d*/
      v8[1] = *(_QWORD *)(v6 + 16); /*0x102dbc697*/
      v6 = OPENSSL_LH_retrieve(a1: (__int64)names_lh, a2: (__int64)v8); /*0x102dbc6a6*/
      if ( v6 == 0 ) /*0x102dbc6ae*/
        goto LABEL_28; /*0x102dbc6ae*/
      if ( *(_DWORD *)(v6 + 4) == 0 ) /*0x102dbc6b8*/
        goto LABEL_31; /*0x102dbc6b8*/
      v8[1] = *(_QWORD *)(v6 + 16); /*0x102dbc6c2*/
      v6 = OPENSSL_LH_retrieve(a1: (__int64)names_lh, a2: (__int64)v8); /*0x102dbc6d1*/
      if ( v6 == 0 ) /*0x102dbc6d9*/
        goto LABEL_28; /*0x102dbc6d9*/
      if ( *(_DWORD *)(v6 + 4) == 0 ) /*0x102dbc6e3*/
        goto LABEL_31; /*0x102dbc6e3*/
      v8[1] = *(_QWORD *)(v6 + 16); /*0x102dbc6ed*/
      v6 = OPENSSL_LH_retrieve(a1: (__int64)names_lh, a2: (__int64)v8); /*0x102dbc6fc*/
      if ( v6 == 0 ) /*0x102dbc704*/
        goto LABEL_28; /*0x102dbc704*/
      if ( *(_DWORD *)(v6 + 4) == 0 ) /*0x102dbc70e*/
        goto LABEL_31; /*0x102dbc70e*/
      v8[1] = *(_QWORD *)(v6 + 16); /*0x102dbc718*/
      v6 = OPENSSL_LH_retrieve(a1: (__int64)names_lh, a2: (__int64)v8); /*0x102dbc727*/
      if ( v6 == 0 ) /*0x102dbc72f*/
        goto LABEL_28; /*0x102dbc72f*/
      if ( *(_DWORD *)(v6 + 4) == 0 ) /*0x102dbc739*/
        goto LABEL_31; /*0x102dbc739*/
      v8[1] = *(_QWORD *)(v6 + 16); /*0x102dbc743*/
      v6 = OPENSSL_LH_retrieve(a1: (__int64)names_lh, a2: (__int64)v8); /*0x102dbc752*/
      if ( v6 == 0 ) /*0x102dbc75a*/
        goto LABEL_28; /*0x102dbc75a*/
      if ( *(_DWORD *)(v6 + 4) == 0 ) /*0x102dbc764*/
        goto LABEL_31; /*0x102dbc764*/
      v8[1] = *(_QWORD *)(v6 + 16); /*0x102dbc76e*/
      v6 = OPENSSL_LH_retrieve(a1: (__int64)names_lh, a2: (__int64)v8); /*0x102dbc77d*/
      if ( v6 == 0 ) /*0x102dbc785*/
        goto LABEL_28; /*0x102dbc785*/
      if ( *(_DWORD *)(v6 + 4) == 0 ) /*0x102dbc78f*/
        goto LABEL_31; /*0x102dbc78f*/
      v8[1] = *(_QWORD *)(v6 + 16); /*0x102dbc799*/
      v6 = OPENSSL_LH_retrieve(a1: (__int64)names_lh, a2: (__int64)v8); /*0x102dbc7a8*/
      if ( v6 == 0 ) /*0x102dbc7b0*/
        goto LABEL_28; /*0x102dbc7b0*/
      if ( *(_DWORD *)(v6 + 4) == 0 /*0x102dbc81f*/
        || (v8[1] = *(_QWORD *)(v6 + 16), (v6 = OPENSSL_LH_retrieve(a1: (__int64)names_lh, a2: (__int64)v8)) != 0)
        && (*(_DWORD *)(v6 + 4) == 0
         || (v8[1] = *(_QWORD *)(v6 + 16), (v6 = OPENSSL_LH_retrieve(a1: (__int64)names_lh, a2: (__int64)v8)) != 0)
         && (*(_DWORD *)(v6 + 4) == 0
          || (v8[1] = *(_QWORD *)(v6 + 16), (v6 = OPENSSL_LH_retrieve(a1: (__int64)names_lh, a2: (__int64)v8)) != 0)
          && *(_DWORD *)(v6 + 4) == 0)) )
      {
LABEL_31:
        v7 = *(const char **)(v6 + 16); /*0x102dbc82c*/
      }
      else
      {
LABEL_28:
        v7 = nullptr; /*0x102dbc821*/
      }
      CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)obj_lock); /*0x102dbc837*/
      return v7; /*0x102dbc83c*/
    }
    else
    {
      return nullptr; /*0x102dbc828*/
    }
  }
  return result; /*0x102dbc827*/
}

// Address: 0x102dbc850 | Name: _OBJ_NAME_add
int __cdecl OBJ_NAME_add(const char *name, int type, const char *data)
{
  int v6; // ebx
  _DWORD *v7; // rax
  void *v8; // r14
  __int64 v9; // rax
  _QWORD *v10; // rbx
  int v11; // eax
  __int64 v12; // rsi
  __int64 v13; // rax

  v6 = 0; /*0x102dbc87a*/
  if ( CRYPTO_THREAD_run_once(a1: &init_2, a2: (void (*)(void))o_names_init_ossl_) && o_names_init_ossl_ret_ != 0 ) /*0x102dbc88b*/
  {
    v7 = CRYPTO_malloc(num: 24, file: "crypto/objects/o_names.c", line: 199); /*0x102dbc8a2*/
    if ( v7 != nullptr ) /*0x102dbc8aa*/
    {
      v8 = v7; /*0x102dbc8b0*/
      *((_QWORD *)v7 + 1) = name; /*0x102dbc8c2*/
      v7[1] = type & 0x8000; /*0x102dbc8c6*/
      *v7 = type & 0xFFFF7FFF; /*0x102dbc8ca*/
      *((_QWORD *)v7 + 2) = data; /*0x102dbc8cd*/
      if ( CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)obj_lock) ) /*0x102dbc8d8*/
      {
        v9 = OPENSSL_LH_insert(a1: (__int64)names_lh, a2: (__int64)v8); /*0x102dbc8eb*/
        if ( v9 != 0 ) /*0x102dbc8f3*/
        {
          v10 = (_QWORD *)v9; /*0x102dbc8f5*/
          if ( name_funcs_stack != nullptr ) /*0x102dbc902*/
          {
            v11 = OPENSSL_sk_num(a1: name_funcs_stack); /*0x102dbc904*/
            v12 = *(unsigned int *)v10; /*0x102dbc909*/
            if ( v11 > (int)v12 ) /*0x102dbc90d*/
            {
              v13 = OPENSSL_sk_value(a1: name_funcs_stack, a2: v12); /*0x102dbc916*/
              (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(v13 + 16))( /*0x102dbc925*/
                a1: v10[1],
                a2: *(unsigned int *)v10,
                a3: v10[2]);
            }
          }
          CRYPTO_free(a1: v10); /*0x102dbc937*/
        }
        else if ( (unsigned int)OPENSSL_LH_error(a1: (__int64)names_lh) != 0 ) /*0x102dbc967*/
        {
          CRYPTO_free(a1: v8); /*0x102dbc978*/
          v6 = 0; /*0x102dbc97d*/
          goto LABEL_14; /*0x102dbc97d*/
        }
        v6 = 1; /*0x102dbc93c*/
LABEL_14:
        CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)obj_lock); /*0x102dbc97f*/
        return v6; /*0x102dbc986*/
      }
      CRYPTO_free(a1: v8); /*0x102dbc952*/
    }
  }
  return v6; /*0x102dbc991*/
}

// Address: 0x102dbc9a0 | Name: _OBJ_NAME_remove
int __cdecl OBJ_NAME_remove(const char *name, int type)
{
  int v4; // ebx
  __int64 v5; // rax
  _QWORD *v6; // rbx
  int v7; // eax
  __int64 v8; // rsi
  __int64 v9; // rax
  unsigned int v11; // [rsp+0h] [rbp-30h] BYREF
  const char *v12; // [rsp+8h] [rbp-28h]

  v4 = 0; /*0x102dbc9c6*/
  if ( CRYPTO_THREAD_run_once(a1: &init_2, a2: (void (*)(void))o_names_init_ossl_) /*0x102dbc9e4*/
    && o_names_init_ossl_ret_ != 0
    && CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)obj_lock) )
  {
    v12 = name; /*0x102dbc9f8*/
    v11 = type & 0xFFFF7FFF; /*0x102dbc9fc*/
    v5 = OPENSSL_LH_delete(a1: (char **)names_lh, a2: (__int64)&v11); /*0x102dbca0b*/
    if ( v5 != 0 ) /*0x102dbca13*/
    {
      v6 = (_QWORD *)v5; /*0x102dbca15*/
      if ( name_funcs_stack != nullptr ) /*0x102dbca22*/
      {
        v7 = OPENSSL_sk_num(a1: name_funcs_stack); /*0x102dbca24*/
        v8 = *(unsigned int *)v6; /*0x102dbca29*/
        if ( v7 > (int)v8 ) /*0x102dbca2d*/
        {
          v9 = OPENSSL_sk_value(a1: name_funcs_stack, a2: v8); /*0x102dbca36*/
          (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(v9 + 16))(a1: v6[1], a2: *(unsigned int *)v6, a3: v6[2]); /*0x102dbca45*/
        }
      }
      CRYPTO_free(a1: v6); /*0x102dbca57*/
      v4 = 1; /*0x102dbca5c*/
    }
    else
    {
      v4 = 0; /*0x102dbca63*/
    }
    CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)obj_lock); /*0x102dbca6c*/
  }
  return v4; /*0x102dbca73*/
}

// Address: 0x102dbca80 | Name: _OBJ_NAME_do_all
void __cdecl OBJ_NAME_do_all(int type, void (__cdecl *fn)(const OBJ_NAME *, void *), void *arg)
{
  int v3; // [rsp+8h] [rbp-18h] BYREF
  void (__cdecl *v4)(const OBJ_NAME *, void *); // [rsp+10h] [rbp-10h]
  void *v5; // [rsp+18h] [rbp-8h]

  v3 = type; /*0x102dbca88*/
  v4 = fn; /*0x102dbca8b*/
  v5 = arg; /*0x102dbca8f*/
  OPENSSL_LH_doall_arg_thunk( /*0x102dbcaac*/
    a1: (__int64)names_lh,
    a2: (void (__fastcall *)(__int64, __int64, __int64))lh_OBJ_NAME_doall_OBJ_DOALL_thunk,
    a3: (__int64)do_all_fn,
    a4: (__int64)&v3);
}

// Address: 0x102dbcae0 | Name: _OBJ_NAME_do_all_sorted
void __cdecl OBJ_NAME_do_all_sorted(int type, void (__cdecl *fn)(const OBJ_NAME *, void *), void *arg)
{
  int v6; // eax
  __int64 i; // r15
  int v8; // [rsp+0h] [rbp-40h] BYREF
  __int64 (__fastcall *v9)(unsigned int *, __int64); // [rsp+8h] [rbp-38h]
  int *v10; // [rsp+10h] [rbp-30h]
  int v11; // [rsp+18h] [rbp-28h] BYREF
  int v12; // [rsp+1Ch] [rbp-24h]
  void *__base; // [rsp+20h] [rbp-20h]

  v11 = type; /*0x102dbcaf6*/
  v6 = OPENSSL_LH_num_items(a1: (__int64)names_lh); /*0x102dbcb00*/
  __base = CRYPTO_malloc(num: 8 * v6, file: "crypto/objects/o_names.c", line: 336); /*0x102dbcb1e*/
  if ( __base != nullptr ) /*0x102dbcb25*/
  {
    v12 = 0; /*0x102dbcb2b*/
    v8 = type; /*0x102dbcb32*/
    v9 = do_all_sorted_fn; /*0x102dbcb3d*/
    v10 = &v11; /*0x102dbcb45*/
    OPENSSL_LH_doall_arg_thunk( /*0x102dbcb62*/
      a1: (__int64)names_lh,
      a2: (void (__fastcall *)(__int64, __int64, __int64))lh_OBJ_NAME_doall_OBJ_DOALL_thunk,
      a3: (__int64)do_all_fn,
      a4: (__int64)&v8);
    qsort(__base, __nel: v12, __width: 8u, __compar: (int (__cdecl *)(const void *, const void *))do_all_sorted_cmp); /*0x102dbcb7b*/
    if ( v12 > 0 ) /*0x102dbcb84*/
    {
      for ( i = 0; i < v12; ((void (__fastcall *)(_QWORD, void *))fn)(a1: *((_QWORD *)__base + i++), a2: arg) ) /*0x102dbcb86*/
        ; /*0x102dbcb9b*/
    }
    CRYPTO_free(a1: __base); /*0x102dbcbba*/
  }
}

// Address: 0x102dbcc10 | Name: _OBJ_NAME_cleanup
void __cdecl OBJ_NAME_cleanup(int type)
{
  __int64 down_load; // rbx

  if ( names_lh != nullptr ) /*0x102dbcc21*/
  {
    free_type = type; /*0x102dbcc27*/
    down_load = OPENSSL_LH_get_down_load(a1: (__int64)names_lh); /*0x102dbcc38*/
    OPENSSL_LH_set_down_load(a1: (__int64)names_lh, a2: 0); /*0x102dbcc44*/
    OPENSSL_LH_doall(a1: (__int64)names_lh, a2: (__int64)names_lh_free_doall); /*0x102dbcc57*/
    if ( type < 0 ) /*0x102dbcc66*/
    {
      OPENSSL_LH_free(a1: names_lh); /*0x102dbcc74*/
      OPENSSL_sk_pop_free(a1: name_funcs_stack); /*0x102dbcc87*/
      CRYPTO_THREAD_lock_free(a1: (pthread_rwlock_t *)obj_lock); /*0x102dbcc93*/
      names_lh = nullptr; /*0x102dbcc98*/
      name_funcs_stack = nullptr; /*0x102dbcca3*/
      obj_lock = nullptr; /*0x102dbccae*/
    }
    else
    {
      OPENSSL_LH_set_down_load(a1: (__int64)names_lh, a2: down_load); /*0x102dbcc6f*/
    }
  }
}

// Address: 0x102dbcd10 | Name: _obj_name_hash
unsigned __int64 __fastcall obj_name_hash(unsigned int *a1)
{
  int v2; // eax
  __int64 v3; // rsi
  __int64 (__fastcall **v4)(_QWORD); // rax
  unsigned __int64 v5; // rax

  if ( name_funcs_stack != nullptr && (v2 = OPENSSL_sk_num(a1: name_funcs_stack), v3 = *a1, v2 > (int)v3) ) /*0x102dbcd2e*/
  {
    v4 = (__int64 (__fastcall **)(_QWORD))OPENSSL_sk_value(a1: name_funcs_stack, a2: v3); /*0x102dbcd37*/
    v5 = (*v4)(a1: *((_QWORD *)a1 + 1)); /*0x102dbcd40*/
  }
  else
  {
    v5 = ossl_lh_strcasehash(a1: *((char **)a1 + 1)); /*0x102dbcd48*/
  }
  return v5 ^ (int)*a1; /*0x102dbcd5a*/
}

// Address: 0x102dbcd60 | Name: _obj_name_cmp
__int64 __fastcall obj_name_cmp(unsigned int *a1, __int64 a2)
{
  __int64 result; // rax
  unsigned int *v3; // rbx
  __int64 v4; // r14
  signed int v5; // eax
  __int64 v6; // rax

  result = *a1 - *(_DWORD *)a2; /*0x102dbcd69*/
  if ( *a1 == *(_DWORD *)a2 ) /*0x102dbcd6b*/
  {
    if ( name_funcs_stack != nullptr /*0x102dbcd96*/
      && (v3 = a1, v4 = a2, v5 = OPENSSL_sk_num(a1: name_funcs_stack), a1 = v3, a2 = v4, v5 > (int)*v3) )
    {
      v6 = OPENSSL_sk_value(a1: name_funcs_stack, a2: *v3); /*0x102dbcdaa*/
      return (*(__int64 (__fastcall **)(_QWORD, _QWORD))(v6 + 8))(a1: *((_QWORD *)v3 + 1), a2: *(_QWORD *)(v4 + 8)); /*0x102dbcdbf*/
    }
    else
    {
      return OPENSSL_strcasecmp(a1: *((_QWORD *)a1 + 1), a2: *(_QWORD *)(a2 + 8)); /*0x102dbcdcd*/
    }
  }
  return result; /*0x102dbcd6d*/
}

// Address: 0x102dbce30 | Name: _ossl_obj_cleanup_int
void ossl_obj_cleanup_int()
{
  if ( added != nullptr ) /*0x102dbce3e*/
  {
    OPENSSL_LH_set_down_load(a1: (__int64)added, a2: 0); /*0x102dbce42*/
    OPENSSL_LH_doall(a1: (__int64)added, a2: (__int64)cleanup1_doall); /*0x102dbce55*/
    OPENSSL_LH_doall(a1: (__int64)added, a2: (__int64)cleanup2_doall); /*0x102dbce68*/
    OPENSSL_LH_doall(a1: (__int64)added, a2: (__int64)cleanup3_doall); /*0x102dbce7b*/
    OPENSSL_LH_free(a1: added); /*0x102dbce87*/
    added = nullptr; /*0x102dbce8c*/
  }
  CRYPTO_THREAD_lock_free(a1: (pthread_rwlock_t *)ossl_obj_lock); /*0x102dbce9e*/
  ossl_obj_lock = nullptr; /*0x102dbcea3*/
}

// Address: 0x102dbcf30 | Name: _OBJ_new_nid
int __cdecl OBJ_new_nid(int num)
{
  return _InterlockedExchangeAdd(&obj_new_nid_unlocked_new_nid, num); /*0x102dbcf3e*/
}

// Address: 0x102dbcf40 | Name: _OBJ_nid2obj
ASN1_OBJECT *__cdecl OBJ_nid2obj(int n)
{
  __int64 v1; // rax
  __int64 v2; // rbx
  ASN1_OBJECT *v3; // rbx
  __int64 v4; // rsi
  char v6; // [rsp+0h] [rbp-40h] BYREF
  int v7; // [rsp+10h] [rbp-30h]
  int v8; // [rsp+28h] [rbp-18h] BYREF
  char *v9; // [rsp+30h] [rbp-10h]

  if ( n == 0 ) /*0x102dbcf4b*/
  {
    v1 = 0; /*0x102dbcfde*/
    return (ASN1_OBJECT *)&nid_objs[5 * v1]; /*0x102dbcfef*/
  }
  if ( (unsigned int)n <= 0x5CE ) /*0x102dbcf57*/
  {
    v1 = (unsigned int)n; /*0x102dbcf59*/
    if ( LODWORD(nid_objs[5 * (unsigned int)n + 2]) != 0 ) /*0x102dbcf6b*/
      return (ASN1_OBJECT *)&nid_objs[5 * v1]; /*0x102dbcf6b*/
  }
  v8 = 3; /*0x102dbcf6d*/
  v9 = &v6; /*0x102dbcf78*/
  v7 = n; /*0x102dbcf7c*/
  if ( !CRYPTO_THREAD_run_once(a1: &ossl_obj_lock_init, a2: (void (*)(void))obj_lock_initialise_ossl_) /*0x102dbcfa6*/
    || obj_lock_initialise_ossl_ret_ == 0
    || !CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)ossl_obj_lock) )
  {
    ERR_new(); /*0x102dbcff1*/
    ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 343, a3: "OBJ_nid2obj"); /*0x102dbd009*/
    v3 = nullptr; /*0x102dbd00e*/
    v4 = 786703; /*0x102dbd015*/
LABEL_15:
    ERR_set_error(a1: 8, a2: v4, a3: 0); /*0x102dbd051*/
    return v3; /*0x102dbd055*/
  }
  if ( added == nullptr ) /*0x102dbcfb9*/
  {
    CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)ossl_obj_lock); /*0x102dbd023*/
    goto LABEL_14; /*0x102dbd023*/
  }
  v2 = OPENSSL_LH_retrieve(a1: (__int64)added, a2: (__int64)&v8); /*0x102dbcfc4*/
  CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)ossl_obj_lock); /*0x102dbcfce*/
  if ( v2 == 0 ) /*0x102dbcfd6*/
  {
LABEL_14:
    ERR_new(); /*0x102dbd028*/
    ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 352, a3: "OBJ_nid2obj"); /*0x102dbd040*/
    v3 = nullptr; /*0x102dbd045*/
    v4 = 101; /*0x102dbd04c*/
    goto LABEL_15; /*0x102dbd04c*/
  }
  return *(ASN1_OBJECT **)(v2 + 8); /*0x102dbd05d*/
}

// Address: 0x102dbd070 | Name: _OBJ_nid2sn
const char *__cdecl OBJ_nid2sn(int n)
{
  ASN1_OBJECT *v1; // rax

  v1 = OBJ_nid2obj(n); /*0x102dbd074*/
  if ( v1 != nullptr ) /*0x102dbd07c*/
    return v1->sn; /*0x102dbd07e*/
  else
    return nullptr; /*0x102dbd083*/
}

// Address: 0x102dbd090 | Name: _OBJ_nid2ln
const char *__cdecl OBJ_nid2ln(int n)
{
  ASN1_OBJECT *v1; // rax

  v1 = OBJ_nid2obj(n); /*0x102dbd094*/
  if ( v1 != nullptr ) /*0x102dbd09c*/
    return v1->ln; /*0x102dbd09e*/
  else
    return nullptr; /*0x102dbd0a4*/
}

// Address: 0x102dbd0b0 | Name: _OBJ_txt2obj
ASN1_OBJECT *__cdecl OBJ_txt2obj(const char *s, int no_name)
{
  ASN1_OBJECT *v3; // r14
  int v4; // eax
  int v5; // r15d
  int v6; // eax
  __int64 v7; // r14
  unsigned __int8 *v8; // rax
  unsigned __int8 *v9; // r12
  int v10; // eax
  unsigned __int8 *v12; // [rsp+0h] [rbp-30h] BYREF
  unsigned __int8 *pp; // [rsp+8h] [rbp-28h] BYREF

  if ( no_name != 0 ) /*0x102dbd0c4*/
    goto LABEL_2; /*0x102dbd0c4*/
  v10 = OBJ_sn2nid(s); /*0x102dbd181*/
  if ( v10 != 0 ) /*0x102dbd188*/
    return OBJ_nid2obj(n: v10); /*0x102dbd188*/
  v10 = OBJ_ln2nid(s); /*0x102dbd18d*/
  if ( v10 != 0 ) /*0x102dbd194*/
    return OBJ_nid2obj(n: v10); /*0x102dbd1a4*/
  if ( ossl_isdigit(a1: *s) ) /*0x102dbd1bf*/
  {
LABEL_2:
    v3 = nullptr; /*0x102dbd0ca*/
    v4 = a2d_ASN1_OBJECT(out: nullptr, olen: 0, buf: s, num: -1); /*0x102dbd0d9*/
    if ( v4 > 0 ) /*0x102dbd0e0*/
    {
      v5 = v4; /*0x102dbd0e6*/
      v3 = nullptr; /*0x102dbd0e9*/
      v6 = ASN1_object_size(constructed: 0, length: v4, tag: 6); /*0x102dbd0f5*/
      if ( v6 >= 0 ) /*0x102dbd0fc*/
      {
        v7 = (unsigned int)v6; /*0x102dbd102*/
        v8 = (unsigned __int8 *)CRYPTO_malloc(num: v6, file: "crypto/objects/obj_dat.c", line: 453); /*0x102dbd114*/
        if ( v8 != nullptr ) /*0x102dbd11c*/
        {
          pp = v8; /*0x102dbd122*/
          v9 = v8; /*0x102dbd137*/
          ASN1_put_object(&pp, constructed: 0, length: v5, tag: 6, xclass: 0); /*0x102dbd13a*/
          a2d_ASN1_OBJECT(out: pp, olen: v5, buf: s, num: -1); /*0x102dbd14e*/
          v12 = v9; /*0x102dbd153*/
          v3 = d2i_ASN1_OBJECT(a: nullptr, pp: (const unsigned __int8 **)&v12, length: v7); /*0x102dbd165*/
          CRYPTO_free(a1: v9); /*0x102dbd177*/
        }
        else
        {
          return nullptr; /*0x102dbd1a9*/
        }
      }
    }
  }
  else
  {
    ERR_new(); /*0x102dbd1cc*/
    ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 438, a3: "OBJ_txt2obj"); /*0x102dbd1e4*/
    v3 = nullptr; /*0x102dbd1e9*/
    ERR_set_error(a1: 8, a2: 103, a3: 0); /*0x102dbd1fa*/
  }
  return v3; /*0x102dbd198*/
}

// Address: 0x102dbd210 | Name: _OBJ_sn2nid
int __cdecl OBJ_sn2nid(const char *s)
{
  unsigned int *v1; // rax
  int v2; // ebx
  __int64 v3; // rax
  _QWORD v5[5]; // [rsp+0h] [rbp-50h] BYREF
  int v6; // [rsp+28h] [rbp-28h] BYREF
  _QWORD *v7; // [rsp+30h] [rbp-20h]
  _QWORD *v8; // [rsp+38h] [rbp-18h] BYREF

  v8 = v5; /*0x102dbd21f*/
  v5[0] = s; /*0x102dbd223*/
  v1 = (unsigned int *)ossl_bsearch( /*0x102dbd246*/
                         a1: (__int64)&v8,
                         a2: (__int64)&sn_objs,
                         a3: 1478,
                         a4: 4,
                         a5: (__int64 (__fastcall *)(__int64, __int64))sn_cmp_BSEARCH_CMP_FN,
                         a6: 0);
  if ( v1 != nullptr ) /*0x102dbd24e*/
    return (int)nid_objs[5 * *v1 + 2]; /*0x102dbd25d*/
  if ( CRYPTO_THREAD_run_once(a1: &ossl_obj_lock_init, a2: (void (*)(void))obj_lock_initialise_ossl_) /*0x102dbd28d*/
    && obj_lock_initialise_ossl_ret_ != 0
    && CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)ossl_obj_lock) )
  {
    v2 = 0; /*0x102dbd29d*/
    if ( added != nullptr ) /*0x102dbd2a2*/
    {
      v6 = 1; /*0x102dbd2a4*/
      v7 = v5; /*0x102dbd2ab*/
      v3 = OPENSSL_LH_retrieve(a1: (__int64)added, a2: (__int64)&v6); /*0x102dbd2b3*/
      if ( v3 != 0 ) /*0x102dbd2bb*/
        v2 = *(_DWORD *)(*(_QWORD *)(v3 + 8) + 16LL); /*0x102dbd2c1*/
    }
    CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)ossl_obj_lock); /*0x102dbd2cb*/
  }
  else
  {
    ERR_new(); /*0x102dbd2d2*/
    ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 676, a3: "OBJ_sn2nid"); /*0x102dbd2ea*/
    v2 = 0; /*0x102dbd2ef*/
    ERR_set_error(a1: 8, a2: 786703, a3: 0); /*0x102dbd2ff*/
  }
  return v2; /*0x102dbd306*/
}

// Address: 0x102dbd310 | Name: _OBJ_ln2nid
int __cdecl OBJ_ln2nid(const char *s)
{
  unsigned int *v1; // rax
  int v2; // ebx
  __int64 v3; // rax
  char v5; // [rsp+0h] [rbp-50h] BYREF
  const char *v6; // [rsp+8h] [rbp-48h]
  int v7; // [rsp+28h] [rbp-28h] BYREF
  char *v8; // [rsp+30h] [rbp-20h]
  char *v9; // [rsp+38h] [rbp-18h] BYREF

  v9 = &v5; /*0x102dbd31f*/
  v6 = s; /*0x102dbd323*/
  v1 = (unsigned int *)ossl_bsearch( /*0x102dbd346*/
                         a1: (__int64)&v9,
                         a2: (__int64)&ln_objs,
                         a3: 1478,
                         a4: 4,
                         a5: (__int64 (__fastcall *)(__int64, __int64))ln_cmp_BSEARCH_CMP_FN,
                         a6: 0);
  if ( v1 != nullptr ) /*0x102dbd34e*/
    return (int)nid_objs[5 * *v1 + 2]; /*0x102dbd35d*/
  if ( CRYPTO_THREAD_run_once(a1: &ossl_obj_lock_init, a2: (void (*)(void))obj_lock_initialise_ossl_) /*0x102dbd38d*/
    && obj_lock_initialise_ossl_ret_ != 0
    && CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)ossl_obj_lock) )
  {
    v2 = 0; /*0x102dbd39d*/
    if ( added != nullptr ) /*0x102dbd3a2*/
    {
      v7 = 2; /*0x102dbd3a4*/
      v8 = &v5; /*0x102dbd3ab*/
      v3 = OPENSSL_LH_retrieve(a1: (__int64)added, a2: (__int64)&v7); /*0x102dbd3b3*/
      if ( v3 != 0 ) /*0x102dbd3bb*/
        v2 = *(_DWORD *)(*(_QWORD *)(v3 + 8) + 16LL); /*0x102dbd3c1*/
    }
    CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)ossl_obj_lock); /*0x102dbd3cb*/
  }
  else
  {
    ERR_new(); /*0x102dbd3d2*/
    ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 649, a3: "OBJ_ln2nid"); /*0x102dbd3ea*/
    v2 = 0; /*0x102dbd3ef*/
    ERR_set_error(a1: 8, a2: 786703, a3: 0); /*0x102dbd3ff*/
  }
  return v2; /*0x102dbd406*/
}

// Address: 0x102dbd410 | Name: _OBJ_obj2txt
int __cdecl OBJ_obj2txt(char *buf, int buf_len, const ASN1_OBJECT *a, int no_name)
{
  char *v4; // r12
  int v5; // r14d
  int length; // r13d
  BIGNUM *v7; // r15
  unsigned __int8 *data; // rcx
  char v10; // dl
  char v11; // al
  bool v12; // bl
  unsigned __int64 v13; // r12
  int v14; // r14d
  unsigned __int8 v15; // al
  int v16; // ecx
  int v17; // ecx
  int v18; // eax
  char v19; // dl
  bool v20; // dl
  char *v21; // rax
  char *v22; // r12
  int v23; // eax
  int v24; // ecx
  char *v25; // rbx
  int v26; // r12d
  const ASN1_OBJECT *v27; // rbx
  int v28; // eax
  int v29; // r15d
  ASN1_OBJECT *v30; // rax
  const char *ln; // r14
  ASN1_OBJECT *v32; // rax
  int v33; // [rsp+8h] [rbp-88h]
  char v34; // [rsp+10h] [rbp-80h]
  int v35; // [rsp+10h] [rbp-80h]
  unsigned __int8 *v36; // [rsp+18h] [rbp-78h]
  int v37; // [rsp+20h] [rbp-70h]
  __int64 v38; // [rsp+20h] [rbp-70h]
  char *v39; // [rsp+28h] [rbp-68h]
  char bufa[48]; // [rsp+30h] [rbp-60h] BYREF

  v4 = buf; /*0x102dbd421*/
  if ( buf != nullptr && buf_len > 0 ) /*0x102dbd43a*/
    *buf = 0; /*0x102dbd443*/
  v5 = 0; /*0x102dbd448*/
  if ( a != nullptr && a->data != nullptr ) /*0x102dbd455*/
  {
    v37 = buf_len; /*0x102dbd457*/
    if ( no_name == 0 ) /*0x102dbd45c*/
    {
      v27 = a; /*0x102dbd7a8*/
      v28 = ossl_obj_obj2nid(a1: a, a2: 1); /*0x102dbd7ab*/
      a = v27; /*0x102dbd7b0*/
      if ( v28 != 0 ) /*0x102dbd7b5*/
      {
        if ( (v29 = v28, (v30 = OBJ_nid2obj(n: v28)) != nullptr) && (ln = v30->ln) != nullptr /*0x102dbd7ed*/
          || (v32 = OBJ_nid2obj(n: v29), a = v27, v32 != nullptr) && (ln = v32->sn, v32->sn != nullptr) )
        {
          if ( v4 != nullptr ) /*0x102dbd7f6*/
            OPENSSL_strlcpy(a1: v4, a2: ln, a3: v37); /*0x102dbd802*/
          return strlen(__s: ln); /*0x102dbd812*/
        }
      }
    }
    length = a->length; /*0x102dbd462*/
    v5 = 0; /*0x102dbd466*/
    if ( length > 586 ) /*0x102dbd470*/
    {
LABEL_7:
      v7 = nullptr; /*0x102dbd472*/
      goto LABEL_8; /*0x102dbd472*/
    }
    if ( length <= 0 ) /*0x102dbd4ac*/
    {
      v7 = nullptr; /*0x102dbd817*/
      goto LABEL_73; /*0x102dbd817*/
    }
    data = a->data; /*0x102dbd4b2*/
    v7 = nullptr; /*0x102dbd4b6*/
    v10 = 0; /*0x102dbd4b9*/
    v5 = 0; /*0x102dbd4bb*/
LABEL_12:
    v11 = *data; /*0x102dbd4be*/
    v12 = (*data & 0x80u) == 0; /*0x102dbd4c3*/
    if ( --length == 0 && v11 < 0 ) /*0x102dbd4cd*/
    {
LABEL_8:
      BN_free(a: v7); /*0x102dbd475*/
      return -1; /*0x102dbd47d*/
    }
    v34 = v10; /*0x102dbd4cf*/
    v33 = v5; /*0x102dbd4d3*/
    v39 = v4; /*0x102dbd4da*/
    v36 = data + 1; /*0x102dbd4e1*/
    v13 = 0; /*0x102dbd4e5*/
    v14 = 0; /*0x102dbd4e8*/
    while ( 1 ) /*0x102dbd4f0*/
    {
      v15 = v11 & 0x7F; /*0x102dbd4f0*/
      if ( v14 != 0 ) /*0x102dbd4f8*/
      {
        if ( BN_add_word(a: v7, w: v15) == 0 ) /*0x102dbd504*/
          goto LABEL_8; /*0x102dbd504*/
        if ( v12 ) /*0x102dbd50a*/
        {
LABEL_32:
          v17 = v37; /*0x102dbd5ca*/
          if ( (v34 & 1) == 0 ) /*0x102dbd5d1*/
          {
            if ( v13 < 0x50 ) /*0x102dbd5d7*/
            {
              v20 = v13 >= 0x28; /*0x102dbd602*/
              if ( v13 >= 0x28 ) /*0x102dbd605*/
                v13 -= 40LL; /*0x102dbd605*/
              v19 = v20 | 0x30; /*0x102dbd609*/
            }
            else if ( v14 != 0 ) /*0x102dbd5dc*/
            {
              v18 = BN_sub_word(a: v7, w: 0x50u); /*0x102dbd5e6*/
              v17 = v37; /*0x102dbd5eb*/
              v19 = 50; /*0x102dbd5ee*/
              if ( v18 == 0 ) /*0x102dbd5f2*/
                goto LABEL_8; /*0x102dbd5f2*/
            }
            else
            {
              v13 -= 80LL; /*0x102dbd60e*/
              v19 = 50; /*0x102dbd612*/
            }
            if ( v39 != nullptr && v17 >= 2 ) /*0x102dbd61e*/
            {
              *v39 = v19; /*0x102dbd624*/
              v39[1] = 0; /*0x102dbd626*/
              --v17; /*0x102dbd62d*/
              ++v39; /*0x102dbd62f*/
            }
            ++v33; /*0x102dbd63c*/
          }
          v37 = v17; /*0x102dbd643*/
          if ( v14 != 0 ) /*0x102dbd649*/
          {
            v21 = BN_bn2dec(a: v7); /*0x102dbd64e*/
            if ( v21 == nullptr ) /*0x102dbd65d*/
              goto LABEL_8; /*0x102dbd65d*/
            v22 = v21; /*0x102dbd663*/
            v23 = strlen(__s: v21); /*0x102dbd669*/
            if ( v39 != nullptr ) /*0x102dbd673*/
            {
              v24 = v37; /*0x102dbd679*/
              v35 = v23; /*0x102dbd67f*/
              if ( v37 < 2 ) /*0x102dbd683*/
              {
                v25 = v39; /*0x102dbd71a*/
              }
              else
              {
                *(_WORD *)v39 = 46; /*0x102dbd68d*/
                v25 = v39 + 1; /*0x102dbd692*/
                v24 = v37 - 1; /*0x102dbd695*/
              }
              v38 = v24; /*0x102dbd721*/
              OPENSSL_strlcpy(a1: v25, a2: v22, a3: v24); /*0x102dbd72b*/
              v23 = v35; /*0x102dbd736*/
              if ( (int)v38 >= v35 ) /*0x102dbd73c*/
              {
                v37 = v38 - v35; /*0x102dbd74e*/
                v39 = &v25[v35]; /*0x102dbd757*/
              }
              else
              {
                v39 = &v25[v38]; /*0x102dbd741*/
                v37 = 0; /*0x102dbd745*/
              }
            }
            else
            {
              v39 = nullptr; /*0x102dbd710*/
            }
            v5 = v23 + v33 + 1; /*0x102dbd75e*/
            CRYPTO_free(a1: v22); /*0x102dbd770*/
            data = v36; /*0x102dbd775*/
          }
          else
          {
            BIO_snprintf(buf: bufa, n: 0x25u, format: ".%lu", v13); /*0x102dbd6b4*/
            v26 = strlen(__s: bufa); /*0x102dbd6c1*/
            if ( v39 != nullptr && v37 > 0 ) /*0x102dbd6db*/
            {
              OPENSSL_strlcpy(a1: v39, a2: bufa, a3: (unsigned int)v37); /*0x102dbd6f2*/
              if ( v37 >= v26 ) /*0x102dbd6fd*/
              {
                v37 -= v26; /*0x102dbd77b*/
                v39 += v26; /*0x102dbd784*/
              }
              else
              {
                v39 += (unsigned int)v37; /*0x102dbd703*/
                v37 = 0; /*0x102dbd707*/
              }
            }
            data = v36; /*0x102dbd788*/
            v5 = v26 + v33; /*0x102dbd78c*/
          }
          v10 = 1; /*0x102dbd78f*/
          v4 = v39; /*0x102dbd794*/
          if ( length <= 0 ) /*0x102dbd798*/
          {
LABEL_73:
            BN_free(a: v7); /*0x102dbd81a*/
            return v5; /*0x102dbd822*/
          }
          goto LABEL_12; /*0x102dbd798*/
        }
      }
      else
      {
        v13 |= v15; /*0x102dbd520*/
        if ( v12 ) /*0x102dbd523*/
          goto LABEL_32; /*0x102dbd526*/
      }
      if ( v14 == 0 && v13 >> 57 != 0 ) /*0x102dbd538*/
        break; /*0x102dbd538*/
      if ( v14 != 0 ) /*0x102dbd573*/
        goto LABEL_27; /*0x102dbd573*/
      v13 <<= 7; /*0x102dbd5c1*/
      v14 = 0; /*0x102dbd5c5*/
LABEL_28:
      v11 = *v36; /*0x102dbd58d*/
      v16 = length - 1; /*0x102dbd594*/
      v12 = (*v36++ & 0x80u) == 0; /*0x102dbd59a*/
      if ( --length == 0 ) /*0x102dbd5ab*/
      {
        length = v16; /*0x102dbd5b1*/
        if ( v11 < 0 ) /*0x102dbd5b6*/
          goto LABEL_8; /*0x102dbd5b6*/
      }
    }
    if ( v7 == nullptr ) /*0x102dbd53d*/
    {
      v7 = BN_new(); /*0x102dbd544*/
      if ( v7 == nullptr ) /*0x102dbd54a*/
        goto LABEL_7; /*0x102dbd54a*/
    }
    v14 = 1; /*0x102dbd55b*/
    if ( BN_set_word(a: v7, w: v13) == 0 ) /*0x102dbd563*/
      goto LABEL_8; /*0x102dbd563*/
LABEL_27:
    if ( BN_lshift(r: v7, a: v7, n: 7) == 0 ) /*0x102dbd587*/
      goto LABEL_8; /*0x102dbd587*/
    goto LABEL_28; /*0x102dbd587*/
  }
  return v5; /*0x102dbd49a*/
}

// Address: 0x102dbd830 | Name: _OBJ_obj2nid
int __cdecl OBJ_obj2nid(const ASN1_OBJECT *o)
{
  return ossl_obj_obj2nid(a1: o, a2: 1); /*0x102dbd839*/
}

// Address: 0x102dbd840 | Name: _OBJ_txt2nid
int __cdecl OBJ_txt2nid(const char *s)
{
  ASN1_OBJECT *v1; // rax
  ASN1_OBJECT *v2; // rbx
  int v3; // r14d

  v1 = OBJ_txt2obj(s, no_name: 0); /*0x102dbd849*/
  if ( v1 == nullptr ) /*0x102dbd851*/
    return 0; /*0x102dbd876*/
  v2 = v1; /*0x102dbd853*/
  v3 = ossl_obj_obj2nid(a1: v1, a2: 1); /*0x102dbd863*/
  ASN1_OBJECT_free(a: v2); /*0x102dbd869*/
  return v3; /*0x102dbd871*/
}

// Address: 0x102dbd880 | Name: _OBJ_bsearch_
const char *__cdecl OBJ_bsearch_(
        const char *key,
        const char *base,
        int num,
        int size,
        int (__cdecl *cmp)(const void *, const void *))
{
  return (const char *)ossl_bsearch( /*0x102dbd887*/
                         a1: (__int64)key,
                         a2: (__int64)base,
                         a3: num,
                         a4: size,
                         a5: (__int64 (__fastcall *)(__int64, __int64))cmp,
                         a6: 0);
}

// Address: 0x102dbd890 | Name: _OBJ_bsearch_ex_
const char *__cdecl OBJ_bsearch_ex_(
        const char *key,
        const char *base,
        int num,
        int size,
        int (__cdecl *cmp)(const void *, const void *),
        int flags)
{
  return (const char *)ossl_bsearch( /*0x102dbd894*/
                         a1: (__int64)key,
                         a2: (__int64)base,
                         a3: num,
                         a4: size,
                         a5: (__int64 (__fastcall *)(__int64, __int64))cmp,
                         a6: flags);
}

// Address: 0x102dbd8a0 | Name: _OBJ_create_objects
int __cdecl OBJ_create_objects(BIO *in)
{
  BIO *v1; // rbx
  int v2; // eax
  const char *v3; // r12
  int v4; // r14d
  char *i; // r13
  unsigned int v6; // edi
  char v7; // al
  char *v8; // rbx
  unsigned int v9; // edi
  BIO *v11; // [rsp+8h] [rbp-238h]
  char buf[512]; // [rsp+10h] [rbp-230h] BYREF

  v1 = in; /*0x102dbd8b4*/
  v2 = BIO_gets(bp: in, buf, size: 512); /*0x102dbd8d4*/
  if ( v2 <= 0 ) /*0x102dbd8db*/
    return 0; /*0x102dbda32*/
  v3 = nullptr; /*0x102dbd8e1*/
  v4 = 0; /*0x102dbd8e4*/
  v11 = v1; /*0x102dbd8e7*/
  while ( 1 ) /*0x102dbd8f2*/
  {
    buf[v2 - 1] = 0; /*0x102dbd8f2*/
    if ( !ossl_ctype_check(a1: buf[0], a2: 7) ) /*0x102dbd906*/
      return v4; /*0x102dbda48*/
    for ( i = buf; ossl_isdigit(a1: *i) || *i == 46; ++i ) /*0x102dbd913*/
      ; /*0x102dbd920*/
    if ( *i == 0 ) /*0x102dbd93d*/
      goto LABEL_16; /*0x102dbd93d*/
    *i = 0; /*0x102dbd93f*/
    do /*0x102dbd95d*/
      v6 = *++i; /*0x102dbd950*/
    while ( ossl_ctype_check(a1: v6, a2: 8) ); /*0x102dbd95d*/
    v7 = *i; /*0x102dbd966*/
    if ( *i != 0 ) /*0x102dbd96d*/
    {
      v8 = i; /*0x102dbd96f*/
      while ( !ossl_ctype_check(a1: v7, a2: 8) ) /*0x102dbd98f*/
      {
        v7 = *++v8; /*0x102dbd991*/
        if ( v7 == 0 ) /*0x102dbd99a*/
          goto LABEL_24; /*0x102dbd99a*/
      }
      if ( *v8 == 0 ) /*0x102dbd9b4*/
      {
LABEL_24:
        v3 = nullptr; /*0x102dbd9f0*/
        goto LABEL_25; /*0x102dbd9f0*/
      }
      *v8 = 0; /*0x102dbd9b6*/
      do /*0x102dbd9cc*/
        v9 = *++v8; /*0x102dbd9c0*/
      while ( ossl_ctype_check(a1: v9, a2: 8) ); /*0x102dbd9cc*/
      v3 = nullptr; /*0x102dbd9d8*/
      if ( *v8 != 0 ) /*0x102dbd9de*/
        v3 = v8; /*0x102dbd9de*/
LABEL_25:
      v1 = v11; /*0x102dbd9f3*/
      if ( buf[0] == 0 ) /*0x102dbda01*/
        return v4; /*0x102dbda01*/
    }
    else
    {
LABEL_16:
      i = nullptr; /*0x102dbd9a0*/
      if ( buf[0] == 0 ) /*0x102dbd9aa*/
        return v4; /*0x102dbd9aa*/
    }
    if ( OBJ_create(oid: buf, sn: i, ln: v3) != 0 ) /*0x102dbda13*/
    {
      ++v4; /*0x102dbda15*/
      v2 = BIO_gets(bp: v1, buf, size: 512); /*0x102dbda23*/
      if ( v2 > 0 ) /*0x102dbda2a*/
        continue; /*0x102dbda2a*/
    }
    return v4; /*0x102dbda2a*/
  }
}

// Address: 0x102dbda60 | Name: _OBJ_create
int __cdecl OBJ_create(const char *oid, const char *sn, const char *ln)
{
  int v3; // r14d
  __int64 v4; // rsi
  ASN1_OBJECT *v9; // rax
  ASN1_OBJECT *v10; // rbx
  unsigned int *v11; // rax
  __int64 v12; // rax
  signed __int32 v13; // eax
  int v14; // [rsp+8h] [rbp-38h] BYREF
  ASN1_OBJECT *v15; // [rsp+10h] [rbp-30h]
  ASN1_OBJECT *v16; // [rsp+18h] [rbp-28h] BYREF

  if ( ((unsigned __int64)ln | (unsigned __int64)sn | (unsigned __int64)oid) != 0 ) /*0x102dbda78*/
  {
    if ( sn != nullptr && OBJ_sn2nid(s: sn) != 0 || ln != nullptr && OBJ_ln2nid(s: ln) != 0 ) /*0x102dbdacf*/
    {
      ERR_new(); /*0x102dbdad1*/
      ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 793, a3: "OBJ_create"); /*0x102dbdae9*/
      v3 = 0; /*0x102dbdaee*/
      v4 = 102; /*0x102dbdaf6*/
      goto LABEL_8; /*0x102dbdaf6*/
    }
    if ( oid != nullptr ) /*0x102dbdb17*/
    {
      v9 = OBJ_txt2obj(s: oid, no_name: 1); /*0x102dbdb21*/
      if ( v9 == nullptr ) /*0x102dbdb29*/
        return 0; /*0x102dbdb2e*/
    }
    else
    {
      v9 = ASN1_OBJECT_new(); /*0x102dbdb30*/
      if ( v9 == nullptr ) /*0x102dbdb38*/
      {
        ERR_new(); /*0x102dbdbf8*/
        ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 806, a3: "OBJ_create"); /*0x102dbdc10*/
        v3 = 0; /*0x102dbdc15*/
        v4 = 524301; /*0x102dbdc1d*/
        goto LABEL_8; /*0x102dbdc22*/
      }
    }
    v10 = v9; /*0x102dbdb3e*/
    if ( !CRYPTO_THREAD_run_once(a1: &ossl_obj_lock_init, a2: (void (*)(void))obj_lock_initialise_ossl_) /*0x102dbdb68*/
      || obj_lock_initialise_ossl_ret_ == 0
      || !CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)ossl_obj_lock) )
    {
      ERR_new(); /*0x102dbdbc0*/
      ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 812, a3: "OBJ_create"); /*0x102dbdbd8*/
      v3 = 0; /*0x102dbdbdd*/
      ERR_set_error(a1: 8, a2: 786704, a3: 0); /*0x102dbdbee*/
LABEL_33:
      ASN1_OBJECT_free(a: v10); /*0x102dbdcf3*/
      return v3; /*0x102dbdcfb*/
    }
    if ( oid != nullptr ) /*0x102dbdb74*/
    {
      v16 = v10; /*0x102dbdb7a*/
      if ( v10->nid != 0 ) /*0x102dbdb82*/
      {
LABEL_19:
        ERR_new(); /*0x102dbdb88*/
        ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 820, a3: "OBJ_create"); /*0x102dbdba0*/
        v3 = 0; /*0x102dbdba5*/
        ERR_set_error(a1: 8, a2: 102, a3: 0); /*0x102dbdbb6*/
LABEL_32:
        CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)ossl_obj_lock); /*0x102dbdce7*/
        goto LABEL_33; /*0x102dbdcee*/
      }
      if ( v10->length != 0 ) /*0x102dbdc2b*/
      {
        v11 = (unsigned int *)ossl_bsearch( /*0x102dbdc50*/
                                a1: (__int64)&v16,
                                a2: (__int64)&obj_objs,
                                a3: 1344,
                                a4: 4,
                                a5: (__int64 (__fastcall *)(__int64, __int64))obj_cmp_BSEARCH_CMP_FN,
                                a6: 0);
        if ( v11 != nullptr ) /*0x102dbdc58*/
        {
          if ( LODWORD(nid_objs[5 * *v11 + 2]) != 0 ) /*0x102dbdc72*/
            goto LABEL_19; /*0x102dbdc72*/
        }
        else if ( added != nullptr ) /*0x102dbdc84*/
        {
          v14 = 0; /*0x102dbdc86*/
          v15 = v16; /*0x102dbdc91*/
          v12 = OPENSSL_LH_retrieve(a1: (__int64)added, a2: (__int64)&v14); /*0x102dbdc99*/
          if ( v12 != 0 && *(_DWORD *)(*(_QWORD *)(v12 + 8) + 16LL) != 0 ) /*0x102dbdcae*/
            goto LABEL_19; /*0x102dbdcae*/
        }
      }
    }
    v13 = _InterlockedExchangeAdd(&obj_new_nid_unlocked_new_nid, 1u); /*0x102dbdcb9*/
    v10->nid = v13; /*0x102dbdcc1*/
    if ( v13 != 0 ) /*0x102dbdcc6*/
    {
      v10->sn = sn; /*0x102dbdcc8*/
      v10->ln = ln; /*0x102dbdccb*/
      v3 = ossl_obj_add_object(a1: v10, a2: 0); /*0x102dbdcd9*/
      *(_OWORD *)&v10->sn = 0; /*0x102dbdcdf*/
    }
    else
    {
      v3 = 0; /*0x102dbdce4*/
    }
    goto LABEL_32; /*0x102dbdce2*/
  }
  ERR_new(); /*0x102dbda7a*/
  ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 786, a3: "OBJ_create"); /*0x102dbda92*/
  v3 = 0; /*0x102dbda97*/
  v4 = 524550; /*0x102dbda9f*/
LABEL_8:
  ERR_set_error(a1: 8, a2: v4, a3: 0); /*0x102dbdafb*/
  return v3; /*0x102dbdb07*/
}

// Address: 0x102dbdd00 | Name: _ossl_obj_obj2nid
__int64 __fastcall ossl_obj_obj2nid(__int64 a1, int a2)
{
  unsigned int v2; // ebx
  unsigned int *v5; // rax
  __int64 v6; // rax
  int v7; // [rsp+8h] [rbp-28h] BYREF
  __int64 v8; // [rsp+10h] [rbp-20h]
  _QWORD v9[3]; // [rsp+18h] [rbp-18h] BYREF

  v9[0] = a1; /*0x102dbdd0b*/
  v2 = 0; /*0x102dbdd0f*/
  if ( a1 != 0 ) /*0x102dbdd14*/
  {
    v2 = *(_DWORD *)(a1 + 16); /*0x102dbdd16*/
    if ( v2 == 0 ) /*0x102dbdd1b*/
    {
      v2 = 0; /*0x102dbdd2c*/
      if ( *(_DWORD *)(a1 + 20) != 0 ) /*0x102dbdd31*/
      {
        v5 = (unsigned int *)ossl_bsearch( /*0x102dbdd55*/
                               a1: (__int64)v9,
                               a2: (__int64)&obj_objs,
                               a3: 1344,
                               a4: 4,
                               a5: (__int64 (__fastcall *)(__int64, __int64))obj_cmp_BSEARCH_CMP_FN,
                               a6: 0);
        if ( v5 != nullptr ) /*0x102dbdd5d*/
        {
          return LODWORD(nid_objs[5 * *v5 + 2]); /*0x102dbdd6c*/
        }
        else if ( a2 == 0 /*0x102dbdd9e*/
               || CRYPTO_THREAD_run_once(a1: &ossl_obj_lock_init, a2: (void (*)(void))obj_lock_initialise_ossl_)
               && obj_lock_initialise_ossl_ret_ != 0
               && CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)ossl_obj_lock) )
        {
          v2 = 0; /*0x102dbddae*/
          if ( added != nullptr ) /*0x102dbddb3*/
          {
            v7 = 0; /*0x102dbddb5*/
            v8 = v9[0]; /*0x102dbddc0*/
            v6 = OPENSSL_LH_retrieve(a1: (__int64)added, a2: (__int64)&v7); /*0x102dbddc8*/
            if ( v6 != 0 ) /*0x102dbddd0*/
              v2 = *(_DWORD *)(*(_QWORD *)(v6 + 8) + 16LL); /*0x102dbddd6*/
          }
          if ( a2 != 0 ) /*0x102dbdddc*/
            CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)ossl_obj_lock); /*0x102dbdde9*/
        }
        else
        {
          ERR_new(); /*0x102dbddf3*/
          ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 403, a3: "ossl_obj_obj2nid"); /*0x102dbde0b*/
          v2 = 0; /*0x102dbde10*/
          ERR_set_error(a1: 8, a2: 786703, a3: 0); /*0x102dbde20*/
        }
      }
    }
  }
  return v2; /*0x102dbdd1f*/
}

// Address: 0x102dbde30 | Name: _ossl_obj_add_object
__int64 __fastcall ossl_obj_add_object(const ASN1_OBJECT *a1, int a2)
{
  ASN1_OBJECT *v4; // rax
  ASN1_OBJECT *v5; // rbx
  _QWORD *v6; // r15
  _DWORD *v7; // rax
  _QWORD *v8; // r12
  _QWORD *v9; // r13
  void *v10; // rdi
  _QWORD *v11; // rdi
  _QWORD *v12; // rax
  _DWORD *v13; // rax
  _DWORD *v14; // r14
  _DWORD *v15; // rcx
  char v16; // al
  __int64 v17; // r14
  _DWORD *v18; // rax
  _DWORD *v19; // r14
  _DWORD *v20; // rax
  _DWORD *v21; // r14
  _DWORD *v22; // rax
  _DWORD *v23; // r14
  int v24; // r14d
  __int64 v26; // r14
  bool v27; // cc
  _DWORD *v28; // rax
  int v29; // [rsp+Ch] [rbp-84h]
  _DWORD *v30; // [rsp+10h] [rbp-80h]
  bool v31; // [rsp+1Fh] [rbp-71h]
  _QWORD v32[4]; // [rsp+20h] [rbp-70h]
  _QWORD v33[2]; // [rsp+40h] [rbp-50h]
  __int128 v34; // [rsp+50h] [rbp-40h]

  v34 = 0; /*0x102dbde58*/
  *(_OWORD *)v33 = 0; /*0x102dbde5c*/
  v4 = OBJ_dup(o: a1); /*0x102dbde60*/
  if ( v4 == nullptr ) /*0x102dbde68*/
    return 0; /*0x102dbde68*/
  v5 = v4; /*0x102dbde6e*/
  v6 = CRYPTO_malloc(num: 16, file: "crypto/objects/obj_dat.c", line: 271); /*0x102dbde87*/
  *((_QWORD *)&v34 + 1) = v6; /*0x102dbde8a*/
  if ( v6 == nullptr ) /*0x102dbde91*/
    goto LABEL_6; /*0x102dbde91*/
  if ( v5->length == 0 ) /*0x102dbde97*/
  {
    v7 = nullptr; /*0x102dbded0*/
    goto LABEL_8; /*0x102dbded0*/
  }
  if ( a1->data != nullptr ) /*0x102dbde9e*/
  {
    v7 = CRYPTO_malloc(num: 16, file: "crypto/objects/obj_dat.c", line: 274); /*0x102dbdeb5*/
    v33[0] = v7; /*0x102dbdeba*/
    if ( v7 == nullptr ) /*0x102dbdec1*/
    {
LABEL_6:
      v8 = nullptr; /*0x102dbdec3*/
      v9 = nullptr; /*0x102dbdec6*/
      v10 = nullptr; /*0x102dbdec9*/
LABEL_51:
      CRYPTO_free(a1: v10); /*0x102dbe218*/
      CRYPTO_free(a1: v9); /*0x102dbe237*/
      CRYPTO_free(a1: v8); /*0x102dbe247*/
      CRYPTO_free(a1: v6); /*0x102dbe257*/
      ASN1_OBJECT_free(a: v5); /*0x102dbe25f*/
      return 0; /*0x102dbe288*/
    }
LABEL_8:
    v30 = v7; /*0x102dbded2*/
    v29 = a2; /*0x102dbded6*/
    if ( v5->sn != nullptr ) /*0x102dbdee1*/
      goto LABEL_9; /*0x102dbdee1*/
LABEL_14:
    v9 = nullptr; /*0x102dbdf4d*/
    if ( v5->ln != nullptr ) /*0x102dbdf55*/
      goto LABEL_11; /*0x102dbdf55*/
LABEL_15:
    v8 = nullptr; /*0x102dbdf57*/
    goto LABEL_16; /*0x102dbdf57*/
  }
  v30 = nullptr; /*0x102dbdf3c*/
  v29 = a2; /*0x102dbdf40*/
  if ( v5->sn == nullptr ) /*0x102dbdf4b*/
    goto LABEL_14; /*0x102dbdf4b*/
LABEL_9:
  v9 = CRYPTO_malloc(num: 16, file: "crypto/objects/obj_dat.c", line: 276); /*0x102dbdee3*/
  v33[1] = v9; /*0x102dbdefc*/
  if ( v9 == nullptr ) /*0x102dbdf03*/
  {
    v8 = nullptr; /*0x102dbe08a*/
    v9 = nullptr; /*0x102dbe08d*/
    goto LABEL_50; /*0x102dbe090*/
  }
  if ( v5->ln == nullptr ) /*0x102dbdf0e*/
    goto LABEL_15; /*0x102dbdf0e*/
LABEL_11:
  v8 = CRYPTO_malloc(num: 16, file: "crypto/objects/obj_dat.c", line: 278); /*0x102dbdf10*/
  *(_QWORD *)&v34 = v8; /*0x102dbdf29*/
  if ( v8 == nullptr ) /*0x102dbdf30*/
  {
    v8 = nullptr; /*0x102dbdf32*/
LABEL_50:
    v10 = v30; /*0x102dbe214*/
    goto LABEL_51; /*0x102dbe214*/
  }
LABEL_16:
  if ( v29 != 0 /*0x102dbdf92*/
    && (!CRYPTO_THREAD_run_once(a1: &ossl_obj_lock_init, a2: (void (*)(void))obj_lock_initialise_ossl_)
     || obj_lock_initialise_ossl_ret_ == 0
     || !CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)ossl_obj_lock)) )
  {
    ERR_new(); /*0x102dbe055*/
    ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: 282, a3: "ossl_obj_add_object"); /*0x102dbe06d*/
    ERR_set_error(a1: 8, a2: 786704, a3: 0); /*0x102dbe080*/
    goto LABEL_50; /*0x102dbe085*/
  }
  v11 = added; /*0x102dbdf9f*/
  if ( added == nullptr ) /*0x102dbdfa9*/
  {
    v12 = OPENSSL_LH_new(a1: (unsigned __int64)added_obj_hash, a2: (unsigned __int64)added_obj_cmp); /*0x102dbdfb9*/
    v11 = OPENSSL_LH_set_thunks( /*0x102dbdfe2*/
            a1: v12,
            a2: (__int64)lh_ADDED_OBJ_hfn_thunk,
            a3: (__int64)lh_ADDED_OBJ_cfn_thunk,
            a4: (__int64)lh_ADDED_OBJ_doall_thunk,
            a5: (__int64)lh_ADDED_OBJ_doall_arg_thunk);
    added = v11; /*0x102dbdfe5*/
    if ( v11 == nullptr ) /*0x102dbdfef*/
    {
      v24 = 288; /*0x102dbe2c4*/
LABEL_48:
      ERR_new(); /*0x102dbe1d1*/
      ERR_set_debug(__s: "crypto/objects/obj_dat.c", a2: v24, a3: "ossl_obj_add_object"); /*0x102dbe1e7*/
      ERR_set_error(a1: 8, a2: 524303, a3: 0); /*0x102dbe1fa*/
      if ( v29 != 0 ) /*0x102dbe206*/
        CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)ossl_obj_lock); /*0x102dbe20f*/
      goto LABEL_50; /*0x102dbe20f*/
    }
  }
  if ( v30 != nullptr ) /*0x102dbdffc*/
  {
    *v30 = 0; /*0x102dbe002*/
    *((_QWORD *)v30 + 1) = v5; /*0x102dbe008*/
    v13 = (_DWORD *)OPENSSL_LH_retrieve(a1: (__int64)v11, a2: (__int64)v30); /*0x102dbe00c*/
    v14 = v13; /*0x102dbe011*/
    v32[0] = v13; /*0x102dbe014*/
    v31 = v13 == nullptr; /*0x102dbe01b*/
    if ( v13 != nullptr ) /*0x102dbe01f*/
      *v13 = -1; /*0x102dbe021*/
    OPENSSL_LH_insert(a1: (__int64)added, a2: (__int64)v30); /*0x102dbe033*/
    if ( (unsigned int)OPENSSL_LH_error(a1: (__int64)added) != 0 ) /*0x102dbe046*/
    {
      v15 = v14; /*0x102dbe048*/
      v16 = 1; /*0x102dbe04b*/
      v17 = 0; /*0x102dbe04d*/
LABEL_44:
      if ( !v31 ) /*0x102dbe1be*/
        *v15 = v17; /*0x102dbe1c0*/
      if ( v16 == 0 ) /*0x102dbe1c5*/
      {
        v26 = v17 - 1; /*0x102dbe289*/
        do /*0x102dbe29e*/
        {
          OPENSSL_LH_delete(a1: (char **)added, a2: v33[v26]); /*0x102dbe2b0*/
          v28 = (_DWORD *)v32[v26]; /*0x102dbe2b5*/
          if ( v28 != nullptr ) /*0x102dbe2bd*/
            *v28 = v26; /*0x102dbe2bf*/
          v27 = v26 == -1 || v26 == 0; /*0x102dbe297*/
          --v26; /*0x102dbe29b*/
        }
        while ( !v27 ); /*0x102dbe29e*/
      }
      v24 = 309; /*0x102dbe1cb*/
      goto LABEL_48; /*0x102dbe1cb*/
    }
  }
  if ( v9 != nullptr ) /*0x102dbe098*/
  {
    *(_DWORD *)v9 = 1; /*0x102dbe09a*/
    v9[1] = v5; /*0x102dbe0a2*/
    v18 = (_DWORD *)OPENSSL_LH_retrieve(a1: (__int64)added, a2: (__int64)v9); /*0x102dbe0b0*/
    v19 = v18; /*0x102dbe0b5*/
    v32[1] = v18; /*0x102dbe0b8*/
    v31 = v18 == nullptr; /*0x102dbe0bf*/
    if ( v18 != nullptr ) /*0x102dbe0c3*/
      *v18 = -1; /*0x102dbe0c5*/
    OPENSSL_LH_insert(a1: (__int64)added, a2: (__int64)v9); /*0x102dbe0d6*/
    if ( (unsigned int)OPENSSL_LH_error(a1: (__int64)added) != 0 ) /*0x102dbe0e9*/
    {
      v15 = v19; /*0x102dbe0eb*/
      v17 = 1; /*0x102dbe0ee*/
LABEL_43:
      v16 = 0; /*0x102dbe1b8*/
      goto LABEL_44; /*0x102dbe1b8*/
    }
  }
  if ( v8 != nullptr ) /*0x102dbe0fc*/
  {
    *(_DWORD *)v8 = 2; /*0x102dbe101*/
    v8[1] = v5; /*0x102dbe109*/
    v20 = (_DWORD *)OPENSSL_LH_retrieve(a1: (__int64)added, a2: (__int64)v8); /*0x102dbe115*/
    v21 = v20; /*0x102dbe11a*/
    v32[2] = v20; /*0x102dbe11d*/
    v31 = v20 == nullptr; /*0x102dbe124*/
    if ( v20 != nullptr ) /*0x102dbe128*/
      *v20 = -1; /*0x102dbe12a*/
    OPENSSL_LH_insert(a1: (__int64)added, a2: (__int64)v8); /*0x102dbe13b*/
    if ( (unsigned int)OPENSSL_LH_error(a1: (__int64)added) != 0 ) /*0x102dbe14e*/
    {
      v15 = v21; /*0x102dbe150*/
      v17 = 2; /*0x102dbe153*/
      goto LABEL_43; /*0x102dbe159*/
    }
  }
  *(_DWORD *)v6 = 3; /*0x102dbe15b*/
  v6[1] = v5; /*0x102dbe162*/
  v22 = (_DWORD *)OPENSSL_LH_retrieve(a1: (__int64)added, a2: (__int64)v6); /*0x102dbe170*/
  v23 = v22; /*0x102dbe175*/
  v32[3] = v22; /*0x102dbe178*/
  v31 = v22 == nullptr; /*0x102dbe17f*/
  if ( v22 != nullptr ) /*0x102dbe183*/
    *v22 = -1; /*0x102dbe185*/
  OPENSSL_LH_insert(a1: (__int64)added, a2: (__int64)v6); /*0x102dbe196*/
  if ( (unsigned int)OPENSSL_LH_error(a1: (__int64)added) != 0 ) /*0x102dbe1a9*/
  {
    v15 = v23; /*0x102dbe1af*/
    v17 = 3; /*0x102dbe1b2*/
    goto LABEL_43; /*0x102dbe1b2*/
  }
  LOBYTE(v5->flags) &= 0xF2u; /*0x102dbe2cf*/
  if ( v29 != 0 ) /*0x102dbe2da*/
    CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)ossl_obj_lock); /*0x102dbe2e3*/
  return (unsigned int)v5->nid; /*0x102dbe27a*/
}

// Address: 0x102dbe310 | Name: _OBJ_length
__int64 __fastcall OBJ_length(__int64 a1)
{
  if ( a1 != 0 ) /*0x102dbe317*/
    return *(int *)(a1 + 20); /*0x102dbe319*/
  else
    return 0; /*0x102dbe31f*/
}

// Address: 0x102dbe330 | Name: _OBJ_get0_data
__int64 __fastcall OBJ_get0_data(__int64 a1)
{
  if ( a1 != 0 ) /*0x102dbe337*/
    return *(_QWORD *)(a1 + 24); /*0x102dbe339*/
  else
    return 0; /*0x102dbe33f*/
}

// Address: 0x102dbe350 | Name: _OBJ_add_object
int __cdecl OBJ_add_object(const ASN1_OBJECT *obj)
{
  return ossl_obj_add_object(a1: obj, a2: 1); /*0x102dbe359*/
}

// Address: 0x102dbe360 | Name: _obj_lock_initialise_ossl_
pthread_rwlock_t *obj_lock_initialise_ossl_()
{
  pthread_rwlock_t *result; // rax

  result = CRYPTO_THREAD_lock_new(); /*0x102dbe364*/
  ossl_obj_lock = result; /*0x102dbe369*/
  obj_lock_initialise_ossl_ret_ = result != nullptr; /*0x102dbe378*/
  return result; /*0x102dbe37e*/
}

// Address: 0x102dbe3e0 | Name: _obj_cmp_BSEARCH_CMP_FN
int __fastcall obj_cmp_BSEARCH_CMP_FN(__int64 a1, unsigned int *a2)
{
  __int64 v2; // rsi
  size_t v3; // rdx
  int result; // eax

  v2 = 5LL * *a2; /*0x102dbe3e9*/
  v3 = *(int *)(*(_QWORD *)a1 + 20LL); /*0x102dbe3f4*/
  result = *(_DWORD *)(*(_QWORD *)a1 + 20LL) - HIDWORD(nid_objs[v2 + 2]); /*0x102dbe3ff*/
  if ( result == 0 ) /*0x102dbe402*/
  {
    if ( (_DWORD)v3 != 0 ) /*0x102dbe408*/
      return memcmp(__s1: *(const void **)(*(_QWORD *)a1 + 24LL), __s2: nid_objs[v2 + 3], __n: v3); /*0x102dbe417*/
    else
      return 0; /*0x102dbe41c*/
  }
  return result; /*0x102dbe404*/
}

// Address: 0x102dbe650 | Name: _ossl_err_load_OBJ_strings
__int64 ossl_err_load_OBJ_strings()
{
  if ( ERR_reason_error_string(e: 0x4000066u) == nullptr ) /*0x102dbe661*/
    ERR_load_strings_const(a1: &OBJ_str_reasons); /*0x102dbe671*/
  return 1; /*0x102dbe668*/
}

// Address: 0x102dbe680 | Name: _OBJ_dup
ASN1_OBJECT *__cdecl OBJ_dup(const ASN1_OBJECT *o)
{
  const ASN1_OBJECT *v1; // rbx
  ASN1_OBJECT *v2; // rax
  ASN1_OBJECT *v3; // r14
  signed __int64 length; // rsi
  unsigned __int8 *v5; // rax
  const char *ln; // rdi
  char *v7; // rax
  char *v8; // rax

  if ( o == nullptr ) /*0x102dbe68a*/
    return nullptr; /*0x102dbe68a*/
  v1 = o; /*0x102dbe690*/
  if ( (o->flags & 1) != 0 ) /*0x102dbe697*/
  {
    v2 = ASN1_OBJECT_new(); /*0x102dbe69d*/
    if ( v2 == nullptr ) /*0x102dbe6a5*/
    {
      ERR_new(); /*0x102dbe73a*/
      ERR_set_debug(__s: "crypto/objects/obj_lib.c", a2: 28, a3: "OBJ_dup"); /*0x102dbe752*/
      v1 = nullptr; /*0x102dbe757*/
      ERR_set_error(a1: 8, a2: 524301, a3: 0); /*0x102dbe767*/
      return (ASN1_OBJECT *)v1; /*0x102dbe76c*/
    }
    v3 = v2; /*0x102dbe6ab*/
    v2->flags = v1->flags | 0xD; /*0x102dbe6b4*/
    length = v1->length; /*0x102dbe6b8*/
    if ( length > 0 ) /*0x102dbe6bf*/
    {
      v5 = (unsigned __int8 *)CRYPTO_memdup(__src: v1->data, __n: length, file: "crypto/objects/obj_lib.c", line: 38); /*0x102dbe6d1*/
      v3->data = v5; /*0x102dbe6d6*/
      if ( v5 == nullptr ) /*0x102dbe6dd*/
      {
LABEL_13:
        ASN1_OBJECT_free(a: v3); /*0x102dbe76e*/
        return nullptr; /*0x102dbe776*/
      }
      LODWORD(length) = v1->length; /*0x102dbe6e3*/
    }
    v3->length = length; /*0x102dbe6e6*/
    v3->nid = v1->nid; /*0x102dbe6ed*/
    ln = v1->ln; /*0x102dbe6f1*/
    if ( ln == nullptr /*0x102dbe712*/
      || (v7 = CRYPTO_strdup(str: ln, file: "crypto/objects/obj_lib.c", line: 44), v3->ln = v7, v7 != nullptr) )
    {
      if ( v1->sn == nullptr ) /*0x102dbe71a*/
        return v3; /*0x102dbe71a*/
      v8 = CRYPTO_strdup(str: v1->sn, file: "crypto/objects/obj_lib.c", line: 47); /*0x102dbe728*/
      v3->sn = v8; /*0x102dbe72d*/
      if ( v8 != nullptr ) /*0x102dbe733*/
        return v3; /*0x102dbe738*/
    }
    goto LABEL_13; /*0x102dbe733*/
  }
  return (ASN1_OBJECT *)v1; /*0x102dbe77b*/
}

// Address: 0x102dbe780 | Name: _OBJ_cmp
int __cdecl OBJ_cmp(const ASN1_OBJECT *a, const ASN1_OBJECT *b)
{
  int result; // eax

  result = a->length - b->length; /*0x102dbe78d*/
  if ( result == 0 ) /*0x102dbe78f*/
    return memcmp(__s1: a->data, __s2: b->data, __n: a->length); /*0x102dbe79c*/
  return result; /*0x102dbe791*/
}

// Address: 0x102dbe7b0 | Name: _OBJ_find_sigid_algs
__int64 __fastcall OBJ_find_sigid_algs(__int64 a1, __int64 a2, __int64 a3)
{
  return ossl_obj_find_sigid_algs(a1, a2, a3, a4: 1); /*0x102dbe7b9*/
}

// Address: 0x102dbe7c0 | Name: _ossl_obj_find_sigid_algs
__int64 __fastcall ossl_obj_find_sigid_algs(int a1, _DWORD *a2, _DWORD *a3, int a4)
{
  unsigned int v4; // r12d
  const char *v8; // rax
  unsigned int v10; // eax
  const char *v11; // r15
  char key[44]; // [rsp+4h] [rbp-2Ch] BYREF

  v4 = 0; /*0x102dbe7cf*/
  if ( a1 == 0 ) /*0x102dbe7d4*/
    return v4; /*0x102dbe7d4*/
  *(_DWORD *)key = a1; /*0x102dbe7df*/
  v8 = OBJ_bsearch_(key, base: "\a", num: 68, size: 12, cmp: sig_cmp_BSEARCH_CMP_FN); /*0x102dbe7fe*/
  if ( v8 == nullptr ) /*0x102dbe806*/
  {
    if ( !CRYPTO_THREAD_run_once(a1: &sig_init, a2: (void (*)(void))o_sig_init_ossl_) || o_sig_init_ossl_ret_ == 0 ) /*0x102dbe851*/
      return v4; /*0x102dbe851*/
    if ( a4 != 0 && !CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)sig_lock) ) /*0x102dbe866*/
    {
      ERR_new(); /*0x102dbe8c0*/
      ERR_set_debug(__s: "crypto/objects/obj_xref.c", a2: 82, a3: "ossl_obj_find_sigid_algs"); /*0x102dbe8d8*/
      v4 = 0; /*0x102dbe8dd*/
      ERR_set_error(a1: 8, a2: 786703, a3: 0); /*0x102dbe8ee*/
      return v4; /*0x102dbe8f3*/
    }
    if ( sig_app != nullptr && ((v10 = OPENSSL_sk_find(a1: sig_app, a2: key)) & 0x80000000) == 0 ) /*0x102dbe87f*/
    {
      v8 = (const char *)OPENSSL_sk_value(a1: sig_app, a2: v10); /*0x102dbe88a*/
      if ( a4 == 0 ) /*0x102dbe892*/
      {
LABEL_18:
        if ( v8 == nullptr ) /*0x102dbe8b2*/
          return 0; /*0x102dbe8bb*/
        goto LABEL_3; /*0x102dbe8b2*/
      }
    }
    else
    {
      v8 = nullptr; /*0x102dbe896*/
      if ( a4 == 0 ) /*0x102dbe89b*/
        goto LABEL_18; /*0x102dbe89b*/
    }
    v11 = v8; /*0x102dbe8a4*/
    CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)sig_lock); /*0x102dbe8a7*/
    v8 = v11; /*0x102dbe8ac*/
    goto LABEL_18; /*0x102dbe8ac*/
  }
LABEL_3:
  if ( a2 != nullptr ) /*0x102dbe80b*/
    *a2 = *((_DWORD *)v8 + 1); /*0x102dbe810*/
  v4 = 1; /*0x102dbe813*/
  if ( a3 != nullptr ) /*0x102dbe81c*/
    *a3 = *((_DWORD *)v8 + 2); /*0x102dbe821*/
  return v4; /*0x102dbe826*/
}

// Address: 0x102dbe900 | Name: _OBJ_find_sigid_by_algs
__int64 __fastcall OBJ_find_sigid_by_algs(_DWORD *a1, int a2, int a3)
{
  unsigned int v3; // ebx
  const char *v5; // rax
  unsigned int v7; // eax
  _BYTE v8[4]; // [rsp+4h] [rbp-2Ch] BYREF
  int v9; // [rsp+8h] [rbp-28h]
  int v10; // [rsp+Ch] [rbp-24h]
  char key[32]; // [rsp+10h] [rbp-20h] BYREF

  *(_QWORD *)key = v8; /*0x102dbe911*/
  v3 = 0; /*0x102dbe915*/
  if ( a3 != 0 ) /*0x102dbe919*/
  {
    v9 = a2; /*0x102dbe91e*/
    v10 = a3; /*0x102dbe921*/
    v5 = OBJ_bsearch_(key, base: &sigoid_srt_xref, num: 48, size: 8, cmp: sigx_cmp_BSEARCH_CMP_FN); /*0x102dbe943*/
    if ( v5 != nullptr ) /*0x102dbe94b*/
    {
      v3 = 1; /*0x102dbe94d*/
      if ( a1 != nullptr ) /*0x102dbe955*/
LABEL_4:
        *a1 = **(_DWORD **)v5; /*0x102dbe957*/
    }
    else if ( CRYPTO_THREAD_run_once(a1: &sig_init, a2: (void (*)(void))o_sig_init_ossl_) && o_sig_init_ossl_ret_ != 0 ) /*0x102dbe98a*/
    {
      if ( !CRYPTO_THREAD_read_lock(a1: (pthread_rwlock_t *)sig_lock) ) /*0x102dbe99a*/
      {
        ERR_new(); /*0x102dbe9fa*/
        ERR_set_debug(__s: "crypto/objects/obj_xref.c", a2: 127, a3: "OBJ_find_sigid_by_algs"); /*0x102dbea12*/
        v3 = 0; /*0x102dbea17*/
        ERR_set_error(a1: 8, a2: 786703, a3: 0); /*0x102dbea27*/
        return v3; /*0x102dbea2c*/
      }
      if ( sigx_app == nullptr || ((v7 = OPENSSL_sk_find(a1: sigx_app, a2: v8)) & 0x80000000) != 0 ) /*0x102dbe9b3*/
      {
        CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)sig_lock); /*0x102dbe9f0*/
        return v3; /*0x102dbe9f5*/
      }
      *(_QWORD *)key = OPENSSL_sk_value(a1: sigx_app, a2: v7); /*0x102dbe9c3*/
      CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)sig_lock); /*0x102dbe9ce*/
      v5 = key; /*0x102dbe9d3*/
      v3 = 1; /*0x102dbe9d6*/
      if ( a1 == nullptr ) /*0x102dbe9de*/
        return v3; /*0x102dbe9de*/
      goto LABEL_4; /*0x102dbe9de*/
    }
  }
  return v3; /*0x102dbe961*/
}

// Address: 0x102dbea40 | Name: _OBJ_add_sigid
_BOOL8 __fastcall OBJ_add_sigid(int a1, unsigned int a2, unsigned int a3)
{
  _BOOL4 v3; // r12d
  _DWORD *v8; // rax
  void *v9; // rbx
  const char *v10; // rax
  int v11; // eax
  void *v12; // rdi
  char key[52]; // [rsp+Ch] [rbp-34h] BYREF

  v3 = false; /*0x102dbea5b*/
  if ( a1 != 0 /*0x102dbea9b*/
    && a3 != 0
    && CRYPTO_THREAD_run_once(a1: &sig_init, a2: (void (*)(void))o_sig_init_ossl_)
    && o_sig_init_ossl_ret_ != 0 )
  {
    v8 = CRYPTO_malloc(num: 12, file: "crypto/objects/obj_xref.c", line: 158); /*0x102dbeaae*/
    if ( v8 != nullptr ) /*0x102dbeab6*/
    {
      v9 = v8; /*0x102dbeab8*/
      *v8 = a1; /*0x102dbeabb*/
      v8[1] = a2; /*0x102dbeabe*/
      v8[2] = a3; /*0x102dbeac2*/
      if ( CRYPTO_THREAD_write_lock(a1: (pthread_rwlock_t *)sig_lock) ) /*0x102dbeacd*/
      {
        *(_DWORD *)key = a1; /*0x102dbead6*/
        v10 = OBJ_bsearch_(key, base: "\a", num: 68, size: 12, cmp: sig_cmp_BSEARCH_CMP_FN); /*0x102dbeaf6*/
        if ( v10 != nullptr ) /*0x102dbeafe*/
        {
LABEL_8:
          v3 = *(_QWORD *)(v10 + 4) == __PAIR64__(a3, a2); /*0x102dbeb00*/
LABEL_25:
          CRYPTO_free(a1: v9); /*0x102dbec48*/
          CRYPTO_THREAD_unlock(a1: (pthread_rwlock_t *)sig_lock); /*0x102dbec63*/
          return v3; /*0x102dbec68*/
        }
        if ( CRYPTO_THREAD_run_once(a1: &sig_init, a2: (void (*)(void))o_sig_init_ossl_) && o_sig_init_ossl_ret_ != 0 ) /*0x102dbeb80*/
        {
          if ( sig_app == nullptr ) /*0x102dbeb8c*/
            goto LABEL_16; /*0x102dbeb8c*/
          v11 = OPENSSL_sk_find(a1: sig_app, a2: key); /*0x102dbeb92*/
          if ( v11 >= 0 ) /*0x102dbeb99*/
          {
            v10 = (const char *)OPENSSL_sk_value(a1: sig_app, a2: (unsigned int)v11); /*0x102dbeba4*/
            if ( v10 != nullptr ) /*0x102dbebac*/
              goto LABEL_8; /*0x102dbebac*/
          }
        }
        v12 = sig_app; /*0x102dbebb2*/
        if ( sig_app != nullptr ) /*0x102dbebbc*/
        {
LABEL_17:
          if ( sigx_app == nullptr ) /*0x102dbebe1*/
          {
            sigx_app = (void *)OPENSSL_sk_new(a1: sigx_cmp); /*0x102dbebef*/
            if ( sigx_app == nullptr ) /*0x102dbebf9*/
              goto LABEL_24; /*0x102dbebf9*/
            v12 = sig_app; /*0x102dbebfb*/
          }
          if ( (unsigned int)OPENSSL_sk_push(a1: v12, a2: v9) != 0 ) /*0x102dbec0c*/
          {
            if ( (unsigned int)OPENSSL_sk_push(a1: sigx_app, a2: v9) != 0 ) /*0x102dbec1f*/
            {
              OPENSSL_sk_sort(a1: sig_app); /*0x102dbec28*/
              OPENSSL_sk_sort(a1: sigx_app); /*0x102dbec34*/
              v3 = true; /*0x102dbec39*/
              v9 = nullptr; /*0x102dbec3f*/
              goto LABEL_25; /*0x102dbec41*/
            }
            v9 = nullptr; /*0x102dbec43*/
          }
LABEL_24:
          v3 = false; /*0x102dbec45*/
          goto LABEL_25; /*0x102dbec45*/
        }
LABEL_16:
        v12 = (void *)OPENSSL_sk_new(a1: sig_sk_cmp); /*0x102dbebbe*/
        sig_app = v12; /*0x102dbebcd*/
        if ( v12 == nullptr ) /*0x102dbebd7*/
          goto LABEL_24; /*0x102dbebd7*/
        goto LABEL_17; /*0x102dbebd7*/
      }
      ERR_new(); /*0x102dbeb17*/
      ERR_set_debug(__s: "crypto/objects/obj_xref.c", a2: 165, a3: "OBJ_add_sigid"); /*0x102dbeb32*/
      v3 = false; /*0x102dbeb37*/
      ERR_set_error(a1: 8, a2: 786704, a3: 0); /*0x102dbeb48*/
      CRYPTO_free(a1: v9); /*0x102dbeb58*/
    }
  }
  return v3; /*0x102dbea65*/
}

// Address: 0x102dbecb0 | Name: _OBJ_sigid_free
void OBJ_sigid_free()
{
  OPENSSL_sk_pop_free(a1: sig_app); /*0x102dbecc2*/
  OPENSSL_sk_free(a1: sigx_app); /*0x102dbecce*/
  CRYPTO_THREAD_lock_free(a1: (pthread_rwlock_t *)sig_lock); /*0x102dbecda*/
  sig_app = nullptr; /*0x102dbecdf*/
  sigx_app = nullptr; /*0x102dbecea*/
  sig_lock = nullptr; /*0x102dbecf5*/
}

// Address: 0x102dbed70 | Name: _o_sig_init_ossl_
pthread_rwlock_t *o_sig_init_ossl_()
{
  pthread_rwlock_t *result; // rax

  result = CRYPTO_THREAD_lock_new(); /*0x102dbed74*/
  sig_lock = result; /*0x102dbed79*/
  o_sig_init_ossl_ret_ = result != nullptr; /*0x102dbed88*/
  return result; /*0x102dbed8e*/
}

// Address: 0x102dbede0 | Name: _OCSP_SIGNATURE_new
OCSP_SIGNATURE *OCSP_SIGNATURE_new(void)
{
  return (OCSP_SIGNATURE *)ASN1_item_new(it: &OCSP_SIGNATURE_it_local_it); /*0x102dbedeb*/
}

// Address: 0x102dbee00 | Name: _OCSP_SIGNATURE_free
void __cdecl OCSP_SIGNATURE_free(OCSP_SIGNATURE *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_SIGNATURE_it_local_it); /*0x102dbee0c*/
}

// Address: 0x102dbee70 | Name: _OCSP_CERTID_new
OCSP_CERTID *OCSP_CERTID_new(void)
{
  return (OCSP_CERTID *)ASN1_item_new(it: &OCSP_CERTID_it_local_it); /*0x102dbee7b*/
}

// Address: 0x102dbee90 | Name: _OCSP_CERTID_free
void __cdecl OCSP_CERTID_free(OCSP_CERTID *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_CERTID_it_local_it); /*0x102dbee9c*/
}

// Address: 0x102dbef00 | Name: _OCSP_ONEREQ_new
OCSP_ONEREQ *OCSP_ONEREQ_new(void)
{
  return (OCSP_ONEREQ *)ASN1_item_new(it: &OCSP_ONEREQ_it_local_it); /*0x102dbef0b*/
}

// Address: 0x102dbef20 | Name: _OCSP_ONEREQ_free
void __cdecl OCSP_ONEREQ_free(OCSP_ONEREQ *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_ONEREQ_it_local_it); /*0x102dbef2c*/
}

// Address: 0x102dbef90 | Name: _OCSP_REQINFO_new
OCSP_REQINFO *OCSP_REQINFO_new(void)
{
  return (OCSP_REQINFO *)ASN1_item_new(it: &OCSP_REQINFO_it_local_it); /*0x102dbef9b*/
}

// Address: 0x102dbefb0 | Name: _OCSP_REQINFO_free
void __cdecl OCSP_REQINFO_free(OCSP_REQINFO *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_REQINFO_it_local_it); /*0x102dbefbc*/
}

// Address: 0x102dbf020 | Name: _OCSP_REQUEST_new
OCSP_REQUEST *OCSP_REQUEST_new(void)
{
  return (OCSP_REQUEST *)ASN1_item_new(it: &OCSP_REQUEST_it_local_it); /*0x102dbf02b*/
}

// Address: 0x102dbf040 | Name: _OCSP_REQUEST_free
void __cdecl OCSP_REQUEST_free(OCSP_REQUEST *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_REQUEST_it_local_it); /*0x102dbf04c*/
}

// Address: 0x102dbf0b0 | Name: _OCSP_RESPBYTES_new
OCSP_RESPBYTES *OCSP_RESPBYTES_new(void)
{
  return (OCSP_RESPBYTES *)ASN1_item_new(it: &OCSP_RESPBYTES_it_local_it); /*0x102dbf0bb*/
}

// Address: 0x102dbf0d0 | Name: _OCSP_RESPBYTES_free
void __cdecl OCSP_RESPBYTES_free(OCSP_RESPBYTES *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_RESPBYTES_it_local_it); /*0x102dbf0dc*/
}

// Address: 0x102dbf140 | Name: _OCSP_RESPONSE_new
OCSP_RESPONSE *OCSP_RESPONSE_new(void)
{
  return (OCSP_RESPONSE *)ASN1_item_new(it: &OCSP_RESPONSE_it_local_it); /*0x102dbf14b*/
}

// Address: 0x102dbf160 | Name: _OCSP_RESPONSE_free
void __cdecl OCSP_RESPONSE_free(OCSP_RESPONSE *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_RESPONSE_it_local_it); /*0x102dbf16c*/
}

// Address: 0x102dbf1d0 | Name: _OCSP_RESPID_new
OCSP_RESPID *OCSP_RESPID_new(void)
{
  return (OCSP_RESPID *)ASN1_item_new(it: &OCSP_RESPID_it_local_it); /*0x102dbf1db*/
}

// Address: 0x102dbf1f0 | Name: _OCSP_RESPID_free
void __cdecl OCSP_RESPID_free(OCSP_RESPID *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_RESPID_it_local_it); /*0x102dbf1fc*/
}

// Address: 0x102dbf260 | Name: _OCSP_REVOKEDINFO_new
OCSP_REVOKEDINFO *OCSP_REVOKEDINFO_new(void)
{
  return (OCSP_REVOKEDINFO *)ASN1_item_new(it: &OCSP_REVOKEDINFO_it_local_it); /*0x102dbf26b*/
}

// Address: 0x102dbf280 | Name: _OCSP_REVOKEDINFO_free
void __cdecl OCSP_REVOKEDINFO_free(OCSP_REVOKEDINFO *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_REVOKEDINFO_it_local_it); /*0x102dbf28c*/
}

// Address: 0x102dbf2f0 | Name: _OCSP_CERTSTATUS_new
OCSP_CERTSTATUS *OCSP_CERTSTATUS_new(void)
{
  return (OCSP_CERTSTATUS *)ASN1_item_new(it: &OCSP_CERTSTATUS_it_local_it); /*0x102dbf2fb*/
}

// Address: 0x102dbf310 | Name: _OCSP_CERTSTATUS_free
void __cdecl OCSP_CERTSTATUS_free(OCSP_CERTSTATUS *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_CERTSTATUS_it_local_it); /*0x102dbf31c*/
}

// Address: 0x102dbf380 | Name: _OCSP_SINGLERESP_new
OCSP_SINGLERESP *OCSP_SINGLERESP_new(void)
{
  return (OCSP_SINGLERESP *)ASN1_item_new(it: &OCSP_SINGLERESP_it_local_it); /*0x102dbf38b*/
}

// Address: 0x102dbf3a0 | Name: _OCSP_SINGLERESP_free
void __cdecl OCSP_SINGLERESP_free(OCSP_SINGLERESP *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_SINGLERESP_it_local_it); /*0x102dbf3ac*/
}

// Address: 0x102dbf410 | Name: _OCSP_RESPDATA_new
OCSP_RESPDATA *OCSP_RESPDATA_new(void)
{
  return (OCSP_RESPDATA *)ASN1_item_new(it: &OCSP_RESPDATA_it_local_it); /*0x102dbf41b*/
}

// Address: 0x102dbf430 | Name: _OCSP_RESPDATA_free
void __cdecl OCSP_RESPDATA_free(OCSP_RESPDATA *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_RESPDATA_it_local_it); /*0x102dbf43c*/
}

// Address: 0x102dbf4a0 | Name: _OCSP_BASICRESP_new
OCSP_BASICRESP *OCSP_BASICRESP_new(void)
{
  return (OCSP_BASICRESP *)ASN1_item_new(it: &OCSP_BASICRESP_it_local_it); /*0x102dbf4ab*/
}

// Address: 0x102dbf4c0 | Name: _OCSP_BASICRESP_free
void __cdecl OCSP_BASICRESP_free(OCSP_BASICRESP *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_BASICRESP_it_local_it); /*0x102dbf4cc*/
}

// Address: 0x102dbf530 | Name: _OCSP_CRLID_new
OCSP_CRLID *OCSP_CRLID_new(void)
{
  return (OCSP_CRLID *)ASN1_item_new(it: &OCSP_CRLID_it_local_it); /*0x102dbf53b*/
}

// Address: 0x102dbf550 | Name: _OCSP_CRLID_free
void __cdecl OCSP_CRLID_free(OCSP_CRLID *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_CRLID_it_local_it); /*0x102dbf55c*/
}

// Address: 0x102dbf5c0 | Name: _OCSP_SERVICELOC_new
OCSP_SERVICELOC *OCSP_SERVICELOC_new(void)
{
  return (OCSP_SERVICELOC *)ASN1_item_new(it: &OCSP_SERVICELOC_it_local_it); /*0x102dbf5cb*/
}

// Address: 0x102dbf5e0 | Name: _OCSP_SERVICELOC_free
void __cdecl OCSP_SERVICELOC_free(OCSP_SERVICELOC *a)
{
  ASN1_item_free(val: (ASN1_VALUE *)a, it: &OCSP_SERVICELOC_it_local_it); /*0x102dbf5ec*/
}

// Address: 0x102dbf600 | Name: _OCSP_request_add0_id
OCSP_ONEREQ *__cdecl OCSP_request_add0_id(OCSP_REQUEST *req, OCSP_CERTID *cid)
{
  OCSP_ONEREQ *v4; // rax
  OCSP_ONEREQ *v5; // rbx

  v4 = OCSP_ONEREQ_new(); /*0x102dbf610*/
  if ( v4 == nullptr ) /*0x102dbf618*/
    return nullptr; /*0x102dbf618*/
  v5 = v4; /*0x102dbf61a*/
  OCSP_CERTID_free(a: v4->reqCert); /*0x102dbf620*/
  v5->reqCert = cid; /*0x102dbf625*/
  if ( req != nullptr && (unsigned int)OPENSSL_sk_push(a1: req[1].tbsRequest, a2: v5) == 0 ) /*0x102dbf63b*/
  {
    v5->reqCert = nullptr; /*0x102dbf63d*/
    OCSP_ONEREQ_free(a: v5); /*0x102dbf647*/
    return nullptr; /*0x102dbf64c*/
  }
  return v5; /*0x102dbf655*/
}

// Address: 0x102dbf660 | Name: _OCSP_request_set1_name
int __cdecl OCSP_request_set1_name(OCSP_REQUEST *req, X509_NAME *nm)
{
  GENERAL_NAME *v4; // rax
  int v5; // ebx
  OCSP_SIGNATURE *v6; // r15

  v4 = GENERAL_NAME_new(); /*0x102dbf671*/
  v5 = 0; /*0x102dbf676*/
  if ( v4 != nullptr ) /*0x102dbf67b*/
  {
    v6 = (OCSP_SIGNATURE *)v4; /*0x102dbf67d*/
    if ( X509_NAME_set(xn: (X509_NAME **)&v4->d, name: nm) != 0 ) /*0x102dbf691*/
    {
      LODWORD(v6->signatureAlgorithm) = 4; /*0x102dbf693*/
      GENERAL_NAME_free(a: (GENERAL_NAME *)req->optionalSignature); /*0x102dbf69e*/
      req->optionalSignature = v6; /*0x102dbf6a3*/
      return 1; /*0x102dbf6a7*/
    }
    else
    {
      GENERAL_NAME_free(a: (GENERAL_NAME *)v6); /*0x102dbf6b1*/
    }
  }
  return v5; /*0x102dbf6b8*/
}

// Address: 0x102dbf6d0 | Name: _OCSP_request_add1_cert
int __cdecl OCSP_request_add1_cert(OCSP_REQUEST *req, X509 *cert)
{
  OCSP_REQINFO *tbsRequest; // rdi
  X509 *v4; // r14
  OCSP_REQINFO *v5; // rax

  tbsRequest = req[2].tbsRequest; /*0x102dbf6da*/
  if ( tbsRequest == nullptr ) /*0x102dbf6e1*/
  {
    v4 = cert; /*0x102dbf6e3*/
    v5 = (OCSP_REQINFO *)OCSP_SIGNATURE_new(); /*0x102dbf6e6*/
    cert = v4; /*0x102dbf6eb*/
    tbsRequest = v5; /*0x102dbf6ee*/
    req[2].tbsRequest = v5; /*0x102dbf6f1*/
    if ( v5 == nullptr ) /*0x102dbf6f8*/
      return 0; /*0x102dbf71b*/
  }
  if ( cert != nullptr ) /*0x102dbf6fd*/
    return ossl_x509_add_cert_new(a1: &tbsRequest->requestExtensions, a2: cert, a3: 1); /*0x102dbf70c*/
  return 1; /*0x102dbf708*/
}

// Address: 0x102dbf730 | Name: _OCSP_request_sign
int __cdecl OCSP_request_sign(
        OCSP_REQUEST *req,
        X509 *signer,
        EVP_PKEY *key,
        const EVP_MD *dgst,
        STACK *certs,
        unsigned __int64 flags)
{
  X509_NAME *subject_name; // r14
  GENERAL_NAME *v10; // rax
  OCSP_SIGNATURE *v11; // r12
  OCSP_REQINFO *v12; // rax
  __int64 v13; // rax
  int result; // eax
  OCSP_REQINFO *tbsRequest; // rdi
  int v16; // ecx
  char v17; // [rsp+20h] [rbp-40h]

  v17 = flags; /*0x102dbf741*/
  subject_name = X509_get_subject_name(a: signer); /*0x102dbf75e*/
  v10 = GENERAL_NAME_new(); /*0x102dbf761*/
  if ( v10 == nullptr ) /*0x102dbf769*/
    goto LABEL_16; /*0x102dbf769*/
  v11 = (OCSP_SIGNATURE *)v10; /*0x102dbf76f*/
  if ( X509_NAME_set(xn: (X509_NAME **)&v10->d, name: subject_name) != 0 ) /*0x102dbf783*/
  {
    LODWORD(v11->signatureAlgorithm) = 4; /*0x102dbf789*/
    GENERAL_NAME_free(a: (GENERAL_NAME *)req->optionalSignature); /*0x102dbf795*/
    req->optionalSignature = v11; /*0x102dbf79a*/
    v12 = (OCSP_REQINFO *)OCSP_SIGNATURE_new(); /*0x102dbf79e*/
    req[2].tbsRequest = v12; /*0x102dbf7a3*/
    if ( v12 != nullptr ) /*0x102dbf7aa*/
    {
      if ( key == nullptr ) /*0x102dbf7b3*/
        goto LABEL_7; /*0x102dbf7b3*/
      if ( X509_check_private_key(x509: signer, pkey: key) == 0 ) /*0x102dbf7c2*/
      {
        ERR_new(); /*0x102dbf88f*/
        ERR_set_debug(__s: "crypto/ocsp/ocsp_cl.c", a2: 94, a3: "OCSP_request_sign"); /*0x102dbf8a7*/
        ERR_set_error(a1: 39, a2: 110, a3: 0); /*0x102dbf8ba*/
        goto LABEL_16; /*0x102dbf8bf*/
      }
      v13 = (*(__int64 (**)(void))&OCSP_REQINFO_it.itype)(); /*0x102dbf7c8*/
      if ( (unsigned int)ASN1_item_sign_ex( /*0x102dbf801*/
                           a1: v13,
                           a2: (__int64)req[2].tbsRequest,
                           a3: 0,
                           a4: (__int64)req[2].tbsRequest->requestList,
                           a5: (__int64)req,
                           a6: 0,
                           a7: (__int64)key,
                           a8: (__int64)dgst,
                           a9: *(_QWORD *)&signer[2].ex_data.dummy,
                           a10: signer[2].ex_pathlen) != 0 )
      {
LABEL_7:
        result = 1; /*0x102dbf803*/
        if ( (v17 & 1) != 0 ) /*0x102dbf80c*/
          return result; /*0x102dbf80c*/
        tbsRequest = req[2].tbsRequest; /*0x102dbf80e*/
        if ( tbsRequest != nullptr /*0x102dbf826*/
          || (tbsRequest = (OCSP_REQINFO *)OCSP_SIGNATURE_new(), req[2].tbsRequest = tbsRequest, tbsRequest != nullptr) )
        {
          if ( signer == nullptr ) /*0x102dbf82b*/
            goto LABEL_13; /*0x102dbf82b*/
          if ( ossl_x509_add_cert_new(a1: &tbsRequest->requestExtensions, a2: signer, a3: 1) != 0 ) /*0x102dbf840*/
          {
            tbsRequest = req[2].tbsRequest; /*0x102dbf842*/
LABEL_13:
            v16 = X509_add_certs(a1: tbsRequest->requestExtensions, a2: certs, a3: 1); /*0x102dbf846*/
            result = 1; /*0x102dbf85a*/
            if ( v16 != 0 ) /*0x102dbf861*/
              return result; /*0x102dbf861*/
          }
        }
      }
    }
  }
  else
  {
    GENERAL_NAME_free(a: (GENERAL_NAME *)v11); /*0x102dbf868*/
  }
LABEL_16:
  OCSP_SIGNATURE_free(a: (OCSP_SIGNATURE *)req[2].tbsRequest); /*0x102dbf86d*/
  req[2].tbsRequest = nullptr; /*0x102dbf876*/
  return 0; /*0x102dbf880*/
}

// Address: 0x102dbf8d0 | Name: _OCSP_response_status
int __cdecl OCSP_response_status(OCSP_RESPONSE *resp)
{
  return ASN1_ENUMERATED_get(a: resp->responseStatus); /*0x102dbf8d7*/
}

// Address: 0x102dbf8e0 | Name: _OCSP_response_get1_basic
OCSP_BASICRESP *__cdecl OCSP_response_get1_basic(OCSP_RESPONSE *resp)
{
  OCSP_RESPBYTES *responseBytes; // rbx
  __int64 v2; // rdi
  ASN1_STRING *response; // rbx
  const ASN1_ITEM *v4; // rax
  __int64 v6; // rsi

  responseBytes = resp->responseBytes; /*0x102dbf8e6*/
  if ( responseBytes != nullptr ) /*0x102dbf8ed*/
  {
    if ( OBJ_obj2nid(o: responseBytes->responseType) == 365 ) /*0x102dbf8fc*/
    {
      response = responseBytes->response; /*0x102dbf8fe*/
      v4 = (const ASN1_ITEM *)(*(__int64 (__fastcall **)(__int64))&OCSP_BASICRESP_it.itype)(a1: v2); /*0x102dbf902*/
      return (OCSP_BASICRESP *)ASN1_item_unpack(oct: response, it: v4); /*0x102dbf913*/
    }
    ERR_new(); /*0x102dbf941*/
    ERR_set_debug(__s: "crypto/ocsp/ocsp_cl.c", a2: 134, a3: "OCSP_response_get1_basic"); /*0x102dbf959*/
    v6 = 104; /*0x102dbf963*/
  }
  else
  {
    ERR_new(); /*0x102dbf918*/
    ERR_set_debug(__s: "crypto/ocsp/ocsp_cl.c", a2: 130, a3: "OCSP_response_get1_basic"); /*0x102dbf930*/
    v6 = 108; /*0x102dbf93a*/
  }
  ERR_set_error(a1: 39, a2: v6, a3: 0); /*0x102dbf96c*/
  return nullptr; /*0x102dbf911*/
}

// Address: 0x102dbf980 | Name: _OCSP_resp_get0_signature
__int64 __fastcall OCSP_resp_get0_signature(__int64 a1)
{
  return *(_QWORD *)(a1 + 64); /*0x102dbf988*/
}

// Address: 0x102dbf990 | Name: _OCSP_resp_get0_tbs_sigalg
__int64 __fastcall OCSP_resp_get0_tbs_sigalg(__int64 a1)
{
  return a1 + 48; /*0x102dbf998*/
}

// Address: 0x102dbf9a0 | Name: _OCSP_resp_get0_respdata
__int64 __fastcall OCSP_resp_get0_respdata(__int64 a1)
{
  return a1; /*0x102dbf9a7*/
}

// Address: 0x102dbf9b0 | Name: _OCSP_resp_count
int __cdecl OCSP_resp_count(OCSP_BASICRESP *bs)
{
  if ( bs != nullptr ) /*0x102dbf9b7*/
    return OPENSSL_sk_num(a1: bs[1].tbsResponseData); /*0x102dbf9be*/
  else
    return -1; /*0x102dbf9c3*/
}

// Address: 0x102dbf9d0 | Name: _OCSP_resp_get0
OCSP_SINGLERESP *__cdecl OCSP_resp_get0(OCSP_BASICRESP *bs, int idx)
{
  if ( bs != nullptr ) /*0x102dbf9d7*/
    return (OCSP_SINGLERESP *)OPENSSL_sk_value(a1: bs[1].tbsResponseData, a2: idx); /*0x102dbf9de*/
  else
    return nullptr; /*0x102dbf9e3*/
}

// Address: 0x102dbf9f0 | Name: _OCSP_resp_get0_produced_at
__int64 __fastcall OCSP_resp_get0_produced_at(__int64 a1)
{
  return *(_QWORD *)(a1 + 24); /*0x102dbf9f8*/
}

// Address: 0x102dbfa00 | Name: _OCSP_resp_get0_certs
__int64 __fastcall OCSP_resp_get0_certs(__int64 a1)
{
  return *(_QWORD *)(a1 + 72); /*0x102dbfa08*/
}

// Address: 0x102dbfa10 | Name: _OCSP_resp_get0_id
__int64 __fastcall OCSP_resp_get0_id(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  int v3; // ecx
  __int64 result; // rax
  _QWORD *v5; // rax

  v3 = *(_DWORD *)(a1 + 8); /*0x102dbfa10*/
  if ( v3 != 0 ) /*0x102dbfa15*/
  {
    result = 0; /*0x102dbfa17*/
    if ( v3 != 1 ) /*0x102dbfa1c*/
      return result; /*0x102dbfa1c*/
    v5 = a2; /*0x102dbfa1e*/
  }
  else
  {
    v5 = a3; /*0x102dbfa23*/
    a3 = a2; /*0x102dbfa26*/
  }
  *v5 = *(_QWORD *)(a1 + 16); /*0x102dbfa31*/
  *a3 = 0; /*0x102dbfa34*/
  return 1; /*0x102dbfa41*/
}

// Address: 0x102dbfa50 | Name: _OCSP_resp_get1_id
__int64 __fastcall OCSP_resp_get1_id(__int64 a1, ASN1_OCTET_STRING **a2, X509_NAME **a3)
{
  int v5; // eax
  unsigned int v6; // ebx
  X509_NAME *v7; // rax
  ASN1_OCTET_STRING *v9; // rax

  v5 = *(_DWORD *)(a1 + 8); /*0x102dbfa60*/
  v6 = 0; /*0x102dbfa63*/
  if ( v5 == 1 ) /*0x102dbfa68*/
  {
    v9 = ASN1_OCTET_STRING_dup(a: *(ASN1_OCTET_STRING **)(a1 + 16)); /*0x102dbfa9c*/
    *a2 = v9; /*0x102dbfaa1*/
    *a3 = nullptr; /*0x102dbfaa4*/
    if ( v9 == nullptr ) /*0x102dbfaae*/
      return v6; /*0x102dbfaae*/
  }
  else
  {
    if ( v5 != 0 ) /*0x102dbfa6c*/
      return v6; /*0x102dbfa6c*/
    v7 = X509_NAME_dup(xn: *(X509_NAME **)(a1 + 16)); /*0x102dbfa72*/
    *a3 = v7; /*0x102dbfa77*/
    *a2 = nullptr; /*0x102dbfa7a*/
    if ( v7 == nullptr ) /*0x102dbfa84*/
      return v6; /*0x102dbfa91*/
  }
  return 1; /*0x102dbfa86*/
}

// Address: 0x102dbfac0 | Name: _OCSP_resp_find
int __cdecl OCSP_resp_find(OCSP_BASICRESP *bs, OCSP_CERTID *id, int last)
{
  int v3; // ebx
  int v5; // r15d
  OCSP_RESPDATA *tbsResponseData; // r12
  OCSP_CERTID **v7; // rax

  v3 = -1; /*0x102dbfacb*/
  if ( bs != nullptr ) /*0x102dbfad3*/
  {
    v5 = 0; /*0x102dbfadb*/
    if ( last >= 0 ) /*0x102dbfae0*/
      v5 = last + 1; /*0x102dbfae0*/
    tbsResponseData = bs[1].tbsResponseData; /*0x102dbfae4*/
    if ( v5 < (int)OPENSSL_sk_num(a1: tbsResponseData) ) /*0x102dbfaf3*/
    {
      while ( 1 ) /*0x102dbfb06*/
      {
        v7 = (OCSP_CERTID **)OPENSSL_sk_value(a1: tbsResponseData, a2: (unsigned int)v5); /*0x102dbfb06*/
        if ( OCSP_id_cmp(a: id, b: *v7) == 0 ) /*0x102dbfb18*/
          break; /*0x102dbfb18*/
        if ( ++v5 >= (int)OPENSSL_sk_num(a1: tbsResponseData) ) /*0x102dbfb28*/
          return v3; /*0x102dbfb28*/
      }
      return v5; /*0x102dbfb2c*/
    }
  }
  return v3; /*0x102dbfb31*/
}

// Address: 0x102dbfb40 | Name: _OCSP_single_get0_status
int __cdecl OCSP_single_get0_status(
        OCSP_SINGLERESP *single,
        int *reason,
        ASN1_GENERALIZEDTIME **revtime,
        ASN1_GENERALIZEDTIME **thisupd,
        ASN1_GENERALIZEDTIME **nextupd)
{
  OCSP_CERTSTATUS *certStatus; // r9
  int result; // eax
  ASN1_GENERALIZEDTIME **good; // r9
  ASN1_ENUMERATED *v8; // rdx
  OCSP_SINGLERESP *v9; // r14
  ASN1_GENERALIZEDTIME **v10; // r12
  ASN1_GENERALIZEDTIME **v11; // r15
  int *v12; // r13
  int v13; // eax
  int v14; // edx

  if ( single == nullptr ) /*0x102dbfb43*/
    return -1; /*0x102dbfbb3*/
  certStatus = single->certStatus; /*0x102dbfb45*/
  result = certStatus->type; /*0x102dbfb49*/
  if ( certStatus->type == 1 ) /*0x102dbfb4f*/
  {
    good = (ASN1_GENERALIZEDTIME **)certStatus->value.good; /*0x102dbfb51*/
    if ( revtime != nullptr ) /*0x102dbfb58*/
      *revtime = *good; /*0x102dbfb5d*/
    if ( reason != nullptr ) /*0x102dbfb63*/
    {
      v8 = good[1]; /*0x102dbfb65*/
      if ( v8 != nullptr ) /*0x102dbfb6c*/
      {
        v9 = single; /*0x102dbfb7c*/
        v10 = nextupd; /*0x102dbfb84*/
        v11 = thisupd; /*0x102dbfb87*/
        v12 = reason; /*0x102dbfb8a*/
        v13 = ASN1_ENUMERATED_get(a: v8); /*0x102dbfb8d*/
        reason = v12; /*0x102dbfb92*/
        thisupd = v11; /*0x102dbfb95*/
        single = v9; /*0x102dbfb98*/
        nextupd = v10; /*0x102dbfb9b*/
        v14 = v13; /*0x102dbfb9e*/
        result = 1; /*0x102dbfba1*/
      }
      else
      {
        v14 = -1; /*0x102dbfbb9*/
      }
      *reason = v14; /*0x102dbfbbe*/
    }
  }
  if ( thisupd != nullptr ) /*0x102dbfbc3*/
    *thisupd = single->thisUpdate; /*0x102dbfbc9*/
  if ( nextupd != nullptr ) /*0x102dbfbcf*/
    *nextupd = single->nextUpdate; /*0x102dbfbd5*/
  return result; /*0x102dbfbb8*/
}

// Address: 0x102dbfbe0 | Name: _OCSP_resp_find_status
int __cdecl OCSP_resp_find_status(
        OCSP_BASICRESP *bs,
        OCSP_CERTID *id,
        int *status,
        int *reason,
        ASN1_GENERALIZEDTIME **revtime,
        ASN1_GENERALIZEDTIME **thisupd,
        ASN1_GENERALIZEDTIME **nextupd)
{
  int v7; // r15d
  OCSP_RESPDATA *tbsResponseData; // rbx
  unsigned int v12; // r15d
  OCSP_CERTID **v13; // rax
  __int64 v14; // rax
  __int64 v15; // rcx
  int v16; // ebx
  ASN1_GENERALIZEDTIME **v17; // rcx
  ASN1_ENUMERATED *v18; // rdi
  __int64 v19; // r15
  int v20; // ecx
  int *v21; // rdx

  v7 = 0; /*0x102dbfbf1*/
  if ( bs != nullptr ) /*0x102dbfbf7*/
  {
    tbsResponseData = bs[1].tbsResponseData; /*0x102dbfc12*/
    if ( (int)OPENSSL_sk_num(a1: tbsResponseData) > 0 ) /*0x102dbfc20*/
    {
      v12 = 0; /*0x102dbfc26*/
      while ( 1 ) /*0x102dbfc36*/
      {
        v13 = (OCSP_CERTID **)OPENSSL_sk_value(a1: tbsResponseData, a2: v12); /*0x102dbfc36*/
        if ( OCSP_id_cmp(a: id, b: *v13) == 0 ) /*0x102dbfc48*/
          break; /*0x102dbfc48*/
        if ( (int)++v12 >= (int)OPENSSL_sk_num(a1: tbsResponseData) ) /*0x102dbfc58*/
          return 0; /*0x102dbfc5d*/
      }
      v14 = OPENSSL_sk_value(a1: bs[1].tbsResponseData, a2: v12); /*0x102dbfc6a*/
      if ( v14 != 0 ) /*0x102dbfc72*/
      {
        v15 = *(_QWORD *)(v14 + 8); /*0x102dbfc74*/
        v16 = *(_DWORD *)v15; /*0x102dbfc78*/
        if ( *(_DWORD *)v15 == 1 ) /*0x102dbfc7d*/
        {
          v17 = *(ASN1_GENERALIZEDTIME ***)(v15 + 8); /*0x102dbfc7f*/
          if ( revtime != nullptr ) /*0x102dbfc8a*/
            *revtime = *v17; /*0x102dbfc8f*/
          if ( reason != nullptr ) /*0x102dbfc97*/
          {
            v18 = v17[1]; /*0x102dbfc99*/
            if ( v18 != nullptr ) /*0x102dbfca0*/
            {
              v19 = v14; /*0x102dbfca2*/
              v20 = ASN1_ENUMERATED_get(a: v18); /*0x102dbfcaa*/
              v14 = v19; /*0x102dbfcad*/
            }
            else
            {
              v20 = -1; /*0x102dbfcbd*/
            }
            *reason = v20; /*0x102dbfcc6*/
          }
        }
        v21 = status; /*0x102dbfccb*/
        if ( thisupd != nullptr ) /*0x102dbfccf*/
          *thisupd = *(ASN1_GENERALIZEDTIME **)(v14 + 16); /*0x102dbfcd5*/
        if ( nextupd != nullptr ) /*0x102dbfcdf*/
          *nextupd = *(ASN1_GENERALIZEDTIME **)(v14 + 24); /*0x102dbfce5*/
      }
      else
      {
        v16 = -1; /*0x102dbfcb2*/
        v21 = status; /*0x102dbfcb7*/
      }
      v7 = 1; /*0x102dbfce8*/
      if ( v21 != nullptr ) /*0x102dbfcf1*/
        *v21 = v16; /*0x102dbfcf3*/
    }
  }
  return v7; /*0x102dbfcf8*/
}

// Address: 0x102dbfd10 | Name: _OCSP_check_validity
int __cdecl OCSP_check_validity(
        ASN1_GENERALIZEDTIME *thisupd,
        ASN1_GENERALIZEDTIME *nextupd,
        __int64 sec,
        __int64 maxsec)
{
  int v8; // r12d
  unsigned int v9; // r13d
  int v10; // r12d
  unsigned int v11; // r15d
  int v12; // r12d
  time_t v14; // [rsp+8h] [rbp-38h] BYREF
  time_t t[6]; // [rsp+10h] [rbp-30h] BYREF

  time(a1: &v14); /*0x102dbfd31*/
  if ( ASN1_GENERALIZEDTIME_check(a: thisupd) == 0 ) /*0x102dbfd40*/
  {
    v9 = 123; /*0x102dbfd97*/
    v10 = 319; /*0x102dbfd9d*/
LABEL_9:
    ERR_new(); /*0x102dbfdd7*/
    ERR_set_debug(__s: "crypto/ocsp/ocsp_cl.c", a2: v10, a3: "OCSP_check_validity"); /*0x102dbfded*/
    v8 = 0; /*0x102dbfdf2*/
    ERR_set_error(a1: 39, a2: v9, a3: 0); /*0x102dbfe01*/
    goto LABEL_10; /*0x102dbfe01*/
  }
  t[0] = sec + v14; /*0x102dbfd49*/
  if ( X509_cmp_time(s: thisupd, t) <= 0 ) /*0x102dbfd5b*/
  {
    v8 = 1; /*0x102dbfda5*/
    if ( maxsec < 0 ) /*0x102dbfdae*/
      goto LABEL_10; /*0x102dbfdae*/
    goto LABEL_7; /*0x102dbfdae*/
  }
  ERR_new(); /*0x102dbfd5d*/
  ERR_set_debug(__s: "crypto/ocsp/ocsp_cl.c", a2: 324, a3: "OCSP_check_validity"); /*0x102dbfd75*/
  v8 = 0; /*0x102dbfd7a*/
  ERR_set_error(a1: 39, a2: 126, a3: 0); /*0x102dbfd8b*/
  if ( maxsec >= 0 ) /*0x102dbfd93*/
  {
LABEL_7:
    t[0] = v14 - maxsec; /*0x102dbfdb0*/
    if ( X509_cmp_time(s: thisupd, t) >= 0 ) /*0x102dbfdc9*/
      goto LABEL_10; /*0x102dbfdc9*/
    v9 = 127; /*0x102dbfdcb*/
    v10 = 335; /*0x102dbfdd1*/
    goto LABEL_9; /*0x102dbfdd1*/
  }
LABEL_10:
  if ( nextupd == nullptr ) /*0x102dbfe09*/
    return v8; /*0x102dbfe09*/
  if ( ASN1_GENERALIZEDTIME_check(a: nextupd) != 0 ) /*0x102dbfe19*/
  {
    t[0] = v14 - sec; /*0x102dbfe22*/
    if ( X509_cmp_time(s: nextupd, t) >= 0 ) /*0x102dbfe34*/
      goto LABEL_16; /*0x102dbfe34*/
    v11 = 125; /*0x102dbfe36*/
    v12 = 351; /*0x102dbfe3c*/
  }
  else
  {
    v11 = 122; /*0x102dbfe44*/
    v12 = 346; /*0x102dbfe4a*/
  }
  ERR_new(); /*0x102dbfe50*/
  ERR_set_debug(__s: "crypto/ocsp/ocsp_cl.c", a2: v12, a3: "OCSP_check_validity"); /*0x102dbfe66*/
  v8 = 0; /*0x102dbfe6b*/
  ERR_set_error(a1: 39, a2: v11, a3: 0); /*0x102dbfe7a*/
LABEL_16:
  if ( ASN1_STRING_cmp(a: nextupd, b: thisupd) < 0 ) /*0x102dbfe8c*/
  {
    ERR_new(); /*0x102dbfe8e*/
    ERR_set_debug(__s: "crypto/ocsp/ocsp_cl.c", a2: 358, a3: "OCSP_check_validity"); /*0x102dbfea6*/
    v8 = 0; /*0x102dbfeab*/
    ERR_set_error(a1: 39, a2: 124, a3: 0); /*0x102dbfebc*/
  }
  return v8; /*0x102dbfec4*/
}

// Address: 0x102dbfee0 | Name: _OCSP_SINGLERESP_get0_id
__int64 __fastcall OCSP_SINGLERESP_get0_id(__int64 a1)
{
  return *(_QWORD *)a1; /*0x102dbfee7*/
}

// Address: 0x102dbfef0 | Name: _ossl_err_load_OCSP_strings
__int64 ossl_err_load_OCSP_strings()
{
  if ( ERR_reason_error_string(e: 0x13800065u) == nullptr ) /*0x102dbff01*/
    ERR_load_strings_const(a1: &OCSP_str_reasons); /*0x102dbff11*/
  return 1; /*0x102dbff08*/
}

// Address: 0x102dbff20 | Name: _OCSP_REQUEST_get_ext_count
int __cdecl OCSP_REQUEST_get_ext_count(OCSP_REQUEST *x)
{
  return X509v3_get_ext_count(x: (const STACK *)x[1].optionalSignature); /*0x102dbff28*/
}

// Address: 0x102dbff30 | Name: _OCSP_REQUEST_get_ext_by_NID
int __cdecl OCSP_REQUEST_get_ext_by_NID(OCSP_REQUEST *x, int nid, int lastpos)
{
  return X509v3_get_ext_by_NID(x: (const STACK *)x[1].optionalSignature, nid, lastpos); /*0x102dbff38*/
}

// Address: 0x102dbff40 | Name: _OCSP_REQUEST_get_ext_by_OBJ
int __cdecl OCSP_REQUEST_get_ext_by_OBJ(OCSP_REQUEST *x, ASN1_OBJECT *obj, int lastpos)
{
  return X509v3_get_ext_by_OBJ(x: (const STACK *)x[1].optionalSignature, obj, lastpos); /*0x102dbff48*/
}

// Address: 0x102dbff50 | Name: _OCSP_REQUEST_get_ext_by_critical
int __cdecl OCSP_REQUEST_get_ext_by_critical(OCSP_REQUEST *x, int crit, int lastpos)
{
  return X509v3_get_ext_by_critical(x: (const STACK *)x[1].optionalSignature, crit, lastpos); /*0x102dbff58*/
}

// Address: 0x102dbff60 | Name: _OCSP_REQUEST_get_ext
X509_EXTENSION *__cdecl OCSP_REQUEST_get_ext(OCSP_REQUEST *x, int loc)
{
  return X509v3_get_ext(x: (const STACK *)x[1].optionalSignature, loc); /*0x102dbff68*/
}

// Address: 0x102dbff70 | Name: _OCSP_REQUEST_delete_ext
X509_EXTENSION *__cdecl OCSP_REQUEST_delete_ext(OCSP_REQUEST *x, int loc)
{
  return X509v3_delete_ext(x: (STACK *)x[1].optionalSignature, loc); /*0x102dbff78*/
}

// Address: 0x102dbff80 | Name: _OCSP_REQUEST_get1_ext_d2i
void *__cdecl OCSP_REQUEST_get1_ext_d2i(OCSP_REQUEST *x, int nid, int *crit, int *idx)
{
  return X509V3_get_d2i(x: (STACK *)x[1].optionalSignature, nid, crit, idx); /*0x102dbff88*/
}

// Address: 0x102dbff90 | Name: _OCSP_REQUEST_add1_ext_i2d
int __cdecl OCSP_REQUEST_add1_ext_i2d(OCSP_REQUEST *x, int nid, void *value, int crit, unsigned __int64 flags)
{
  return X509V3_add1_i2d(x: (STACK **)&x[1].optionalSignature, nid, value, crit, flags); /*0x102dbff98*/
}

// Address: 0x102dbffa0 | Name: _OCSP_REQUEST_add_ext
int __cdecl OCSP_REQUEST_add_ext(OCSP_REQUEST *x, X509_EXTENSION *ex, int loc)
{
  return X509v3_add_ext(x: (STACK **)&x[1].optionalSignature, ex, loc) != nullptr; /*0x102dbffb7*/
}

// Address: 0x102dbffc0 | Name: _OCSP_ONEREQ_get_ext_count
int __cdecl OCSP_ONEREQ_get_ext_count(OCSP_ONEREQ *x)
{
  return X509v3_get_ext_count(x: x->singleRequestExtensions); /*0x102dbffc8*/
}

// Address: 0x102dbffd0 | Name: _OCSP_ONEREQ_get_ext_by_NID
int __cdecl OCSP_ONEREQ_get_ext_by_NID(OCSP_ONEREQ *x, int nid, int lastpos)
{
  return X509v3_get_ext_by_NID(x: x->singleRequestExtensions, nid, lastpos); /*0x102dbffd8*/
}

// Address: 0x102dbffe0 | Name: _OCSP_ONEREQ_get_ext_by_OBJ
int __cdecl OCSP_ONEREQ_get_ext_by_OBJ(OCSP_ONEREQ *x, ASN1_OBJECT *obj, int lastpos)
{
  return X509v3_get_ext_by_OBJ(x: x->singleRequestExtensions, obj, lastpos); /*0x102dbffe8*/
}

// Address: 0x102dbfff0 | Name: _OCSP_ONEREQ_get_ext_by_critical
int __cdecl OCSP_ONEREQ_get_ext_by_critical(OCSP_ONEREQ *x, int crit, int lastpos)
{
  return X509v3_get_ext_by_critical(x: x->singleRequestExtensions, crit, lastpos); /*0x102dbfff8*/
}

// END _free_o part 3/7, 400 functions
