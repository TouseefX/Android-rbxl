// _free_n -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 400 functions, part 2 of 5


// Address: 0x103122b86 | Name: _nghttp2_session_close_stream
__int64 __fastcall nghttp2_session_close_stream(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v6; // rdx
  __int64 v7; // r14
  __int64 result; // rax
  __int64 (__fastcall *v9)(__int64, _QWORD, _QWORD, _QWORD); // rax
  int v10; // ecx
  __int64 v11; // r12
  char v12; // al
  __int64 v13; // rcx

  v7 = nghttp2_map_find(a1, a2); /*0x103122ba2*/
  result = 4294966795LL; /*0x103122ba5*/
  if ( v7 != 0 && (*(_BYTE *)(v7 + 116) & 2) == 0 && *(_DWORD *)v7 != 5 ) /*0x103122bc2*/
  {
    v9 = *(__int64 (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD))(a1 + 2224); /*0x103122bc8*/
    if ( v9 == nullptr || (v10 = v9(a1, a2, a3, a4: *(_QWORD *)(a1 + 2416)), result = 4294966394LL, v10 == 0) ) /*0x103122bef*/
    {
      v11 = *(_QWORD *)(v7 + 64); /*0x103122bf5*/
      if ( v11 != 0 ) /*0x103122bfc*/
      {
        session_detach_stream_item(a1, a2: v7); /*0x103122c04*/
        if ( *(_BYTE *)(v11 + 152) == 0 && v11 != *(_QWORD *)(a1 + 448) ) /*0x103122c1b*/
        {
          nghttp2_outbound_item_free(a1: v11, a2: a1 + 2376); /*0x103122c2a*/
          nghttp2_mem_free(a1: a1 + 2376, a2: v11); /*0x103122c35*/
        }
      }
      if ( a2 != 0 ) /*0x103122c3d*/
      {
        v12 = *(_BYTE *)(v7 + 116); /*0x103122c46*/
        LOBYTE(v6) = a2 ^ (*(_BYTE *)(a1 + 2739) == 0); /*0x103122c4d*/
        if ( (v12 & 1) == 0 ) /*0x103122c52*/
        {
          v13 = 2504; /*0x103122c54*/
          if ( (v6 & 1) == 0 ) /*0x103122c5c*/
            goto LABEL_17; /*0x103122c5c*/
          goto LABEL_15; /*0x103122c5c*/
        }
        v13 = 2520; /*0x103122c74*/
        if ( (v6 & 1) == 0 ) /*0x103122c7c*/
        {
LABEL_18:
          *(_BYTE *)(v7 + 116) = v12 | 2; /*0x103122c82*/
          nghttp2_session_destroy_stream(a1, a2: v7, a3: v6, a4: v13); /*0x103122c8e*/
          return 0; /*0x103122c93*/
        }
      }
      else
      {
        v12 = *(_BYTE *)(v7 + 116); /*0x103122c60*/
        v13 = 2520; /*0x103122c64*/
        if ( (v12 & 1) == 0 ) /*0x103122c6b*/
LABEL_15:
          v13 = 2512; /*0x103122c6d*/
      }
LABEL_17:
      --*(_QWORD *)(a1 + v13); /*0x103122c7e*/
      goto LABEL_18; /*0x103122c7e*/
    }
  }
  return result; /*0x103122c99*/
}

// Address: 0x103122ce7 | Name: _nghttp2_session_destroy_stream
__int64 __fastcall nghttp2_session_destroy_stream(__int64 a1, __int64 a2)
{
  if ( *(_BYTE *)(a2 + 118) != 0 ) /*0x103122cfb*/
  {
    nghttp2_pq_remove(a1: a1 + 40LL * (*(_BYTE *)(a2 + 120) & 0x7F) + 128, a2: (unsigned __int64 *)(a2 + 8)); /*0x103122d17*/
    *(_BYTE *)(a2 + 118) = 0; /*0x103122d1c*/
  }
  nghttp2_map_remove(a1, a2: *(_DWORD *)(a2 + 80)); /*0x103122d2d*/
  nghttp2_stream_free(a1: a2); /*0x103122d35*/
  return nghttp2_mem_free(a1: a1 + 2376, a2); /*0x103122d44*/
}

// Address: 0x103122d4f | Name: _nghttp2_session_close_stream_if_shut_rdwr
__int64 __fastcall nghttp2_session_close_stream_if_shut_rdwr(__int64 a1, __int64 a2)
{
  if ( (~*(_BYTE *)(a2 + 117) & 3) != 0 ) /*0x103122d5a*/
    return 0; /*0x103122d67*/
  else
    return nghttp2_session_close_stream(a1, a2: *(_DWORD *)(a2 + 80), a3: 0); /*0x103122d62*/
}

// Address: 0x103122d6b | Name: _nghttp2_session_check_request_allowed
__int64 __fastcall nghttp2_session_check_request_allowed(__int64 a1)
{
  __int64 result; // rax

  result = 0; /*0x103122d6b*/
  if ( *(_BYTE *)(a1 + 2739) == 0 && *(int *)(a1 + 2608) >= 0 && (*(_BYTE *)(a1 + 2740) & 8) == 0 ) /*0x103122d87*/
    return (unsigned int)session_is_closing() ^ 1; /*0x103122d92*/
  return result; /*0x103122d76*/
}

// Address: 0x103122dcd | Name: _nghttp2_session_get_next_ob_item
__int64 __fastcall nghttp2_session_get_next_ob_item(__int64 a1)
{
  __int64 v1; // r14
  __int64 v4; // r15
  __int64 v5; // rax

  v1 = *(_QWORD *)(a1 + 56); /*0x103122dd7*/
  if ( v1 == 0 ) /*0x103122dde*/
  {
    v1 = *(_QWORD *)(a1 + 80); /*0x103122de3*/
    if ( v1 == 0 /*0x103122e10*/
      && (*(_QWORD *)(a1 + 2504) >= (unsigned __int64)*(unsigned int *)(a1 + 2668) || (v1 = *(_QWORD *)(a1 + 104)) == 0) )
    {
      if ( *(int *)(a1 + 2636) <= 0 ) /*0x103122e19*/
      {
        return 0; /*0x103122e41*/
      }
      else
      {
        v4 = 128; /*0x103122e1b*/
        v1 = 0; /*0x103122e21*/
        while ( 1 ) /*0x103122e28*/
        {
          v5 = nghttp2_pq_top(a1: (_QWORD *)(a1 + v4)); /*0x103122e28*/
          if ( v5 != 0 ) /*0x103122e30*/
            break; /*0x103122e30*/
          v4 += 40; /*0x103122e32*/
          if ( v4 == 448 ) /*0x103122e3d*/
            return v1; /*0x103122e3d*/
        }
        return *(_QWORD *)(v5 + 56); /*0x103122e46*/
      }
    }
  }
  return v1; /*0x103122df3*/
}

// Address: 0x103122e4c | Name: _nghttp2_session_pop_next_ob_item
__int64 __fastcall nghttp2_session_pop_next_ob_item(__int64 a1)
{
  __int64 v2; // rbx
  __int64 *v3; // r14
  __int64 v5; // r15
  __int64 v6; // rax

  v2 = *(_QWORD *)(a1 + 56); /*0x103122e59*/
  if ( v2 != 0 ) /*0x103122e60*/
  {
    v3 = (__int64 *)(a1 + 56); /*0x103122e62*/
LABEL_5:
    nghttp2_outbound_queue_pop(a1: v3); /*0x103122e75*/
    *(_BYTE *)(v2 + 152) = 0; /*0x103122e7d*/
    return v2; /*0x103122e7d*/
  }
  v2 = *(_QWORD *)(a1 + 80); /*0x103122e68*/
  if ( v2 != 0 ) /*0x103122e6f*/
  {
    v3 = (__int64 *)(a1 + 80); /*0x103122e71*/
    goto LABEL_5; /*0x103122e71*/
  }
  if ( *(_QWORD *)(a1 + 2504) < (unsigned __int64)*(unsigned int *)(a1 + 2668) ) /*0x103122ea0*/
  {
    v2 = *(_QWORD *)(a1 + 104); /*0x103122ea2*/
    if ( v2 != 0 ) /*0x103122ea9*/
    {
      v3 = (__int64 *)(a1 + 104); /*0x103122eab*/
      goto LABEL_5; /*0x103122eaf*/
    }
  }
  if ( *(int *)(a1 + 2636) <= 0 ) /*0x103122eb9*/
    return 0; /*0x103122ee0*/
  v5 = 128; /*0x103122ebb*/
  v2 = 0; /*0x103122ec1*/
  while ( 1 ) /*0x103122ec7*/
  {
    v6 = nghttp2_pq_top(a1: (_QWORD *)(a1 + v5)); /*0x103122ec7*/
    if ( v6 != 0 ) /*0x103122ecf*/
      break; /*0x103122ecf*/
    v5 += 40; /*0x103122ed1*/
    if ( v5 == 448 ) /*0x103122edc*/
      return v2; /*0x103122edc*/
  }
  return *(_QWORD *)(v6 + 56); /*0x103122e8b*/
}

// Address: 0x103122eea | Name: _nghttp2_session_mem_send
__int64 nghttp2_session_mem_send()
{
  return nghttp2_session_mem_send2(); /*0x103122eee*/
}

// Address: 0x103122ef4 | Name: _nghttp2_session_mem_send2
__int64 __fastcall nghttp2_session_mem_send2(__int64 a1, _QWORD *a2)
{
  __int64 v3; // rbx
  int v4; // eax

  *a2 = 0; /*0x103122efe*/
  v3 = nghttp2_session_mem_send_internal(a1, a2, a3: 1); /*0x103122f0f*/
  if ( v3 > 0 && *(_QWORD *)(a1 + 448) != 0 ) /*0x103122f1f*/
  {
    v4 = session_after_frame_sent1(a1); /*0x103122f24*/
    if ( v4 < 0 ) /*0x103122f2d*/
      return v4; /*0x103122f2d*/
  }
  return v3; /*0x103122f34*/
}

// Address: 0x103122f39 | Name: _nghttp2_session_mem_send_internal
__int64 __fastcall nghttp2_session_mem_send_internal(__int64 a1, _QWORD *a2, int a3)
{
  int v3; // ebx
  __int64 ob_item; // rax
  __int64 v6; // r14
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // r13
  int v10; // eax
  __int64 v11; // r15
  __int64 v12; // rax
  __int64 v13; // rdi
  __int64 v14; // rsi
  __int64 v15; // r13
  __int64 v16; // rax
  __int64 v17; // r14
  int v18; // r15d
  int v19; // eax
  __int64 v20; // rax
  __int64 v21; // rcx
  int v22; // r13d
  __int64 v23; // rax
  int v24; // ecx
  int v25; // eax
  int v26; // esi
  __int64 v27; // rax
  __int64 v28; // r13
  int v29; // eax
  __int64 v30; // rax
  int v31; // eax
  __int64 v32; // rax
  __int64 v33; // r13
  int v34; // eax
  int v35; // eax
  int v36; // r13d
  __int64 v37; // rax
  int v38; // eax
  __int64 v39; // rax
  __int64 v40; // r13
  __int64 v41; // rdx
  int v42; // eax
  int v43; // eax
  __int64 v44; // rdi
  __int64 v45; // rsi
  __int64 v46; // rdx
  __int64 v47; // rax
  __int64 v48; // rsi
  unsigned __int64 v49; // r13
  __int64 (__fastcall *v50)(__int64, __int64, unsigned __int64, __int64, _QWORD); // rax
  unsigned __int64 v51; // rax
  __int64 v52; // rdi
  __int64 (__fastcall *v53)(__int64, __int64, _QWORD); // rax
  int v54; // eax
  unsigned int (__fastcall *v55)(__int64, __int64, __int64, _QWORD); // rax
  int v56; // eax
  unsigned int v57; // edx
  __int64 v58; // rax
  unsigned int v59; // esi
  int v60; // r13d
  __int64 v61; // rax
  __int64 v62; // rax
  int v63; // eax
  char v64; // al
  int v65; // r13d
  unsigned int (__fastcall *v66)(__int64, __int64, _QWORD, _QWORD); // r8
  unsigned int v67; // esi
  unsigned int v68; // edx
  __int64 v70; // [rsp+0h] [rbp-60h]
  __int64 v73; // [rsp+18h] [rbp-48h]
  _QWORD *v74; // [rsp+20h] [rbp-40h]
  __int64 v75; // [rsp+28h] [rbp-38h]
  __int64 ***v76; // [rsp+30h] [rbp-30h]

  v3 = a3; /*0x103122f4a*/
  v75 = a1 + 2376; /*0x103122f5a*/
  v74 = (_QWORD *)(a1 + 448); /*0x103122f65*/
  v76 = (__int64 ***)(a1 + 456); /*0x103122f70*/
  v73 = a1 + 792; /*0x103122f7b*/
  while ( 2 ) /*0x103122f9f*/
  {
    while ( 2 ) /*0x103122f9f*/
    {
      switch ( *(_DWORD *)(a1 + 520) ) /*0x103122f9f*/
      {
        case 0: /*0x103122f9f*/
          ob_item = nghttp2_session_pop_next_ob_item(a1); /*0x103122fa4*/
          if ( ob_item == 0 ) /*0x103122fac*/
            return 0; /*0x103122fac*/
          break; /*0x103122fac*/
        case 1: /*0x103122f9f*/
          v20 = *(_QWORD *)(a1 + 464); /*0x103123119*/
          v21 = *(_QWORD *)(v20 + 24); /*0x103123121*/
          if ( v21 != *(_QWORD *)(v20 + 32) ) /*0x103123129*/
            goto LABEL_206; /*0x103123129*/
          if ( v3 == 0 ) /*0x103123131*/
          {
            v19 = session_after_frame_sent1(a1); /*0x103123136*/
            if ( v19 < 0 ) /*0x10312313d*/
              return v19; /*0x10312313d*/
          }
          session_after_frame_sent2(a1); /*0x103123146*/
          continue; /*0x10312314b*/
        case 2: /*0x103122f9f*/
          v15 = *(_QWORD *)(a1 + 448); /*0x103123032*/
          v16 = nghttp2_map_find(a1, a2: *(_DWORD *)(v15 + 8)); /*0x103123041*/
          if ( v16 == 0 ) /*0x103123049*/
            goto LABEL_22; /*0x103123049*/
          v17 = v16; /*0x10312304f*/
          if ( (*(_BYTE *)(v16 + 116) & 2) != 0 || *(_DWORD *)v16 == 5 ) /*0x103123060*/
            goto LABEL_22; /*0x103123060*/
          v18 = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD, __int64, _QWORD))(a1 + 2312))( /*0x103123098*/
                  a1,
                  a2: *(_QWORD *)(a1 + 448),
                  a3: *(_QWORD *)(*(_QWORD *)(a1 + 464) + 24LL),
                  a4: **(_QWORD **)(a1 + 448) - *(_QWORD *)(*(_QWORD *)(a1 + 448) + 16LL),
                  a5: *(_QWORD *)(a1 + 448) + 104LL,
                  a6: *(_QWORD *)(a1 + 2416));
          if ( v18 > -505 ) /*0x1031230a0*/
          {
            if ( v18 != 0 ) /*0x103123531*/
            {
              if ( v18 == -504 ) /*0x103123c1b*/
                return 0; /*0x103123c1b*/
              return -902; /*0x103123c53*/
            }
          }
          else if ( v18 != -526 ) /*0x1031230ad*/
          {
            if ( v18 != -521 ) /*0x1031230ba*/
              return -902; /*0x1031230ba*/
            session_detach_stream_item(a1, a2: v17); /*0x1031230c6*/
            v19 = nghttp2_session_add_rst_stream_continue(a1, a2: *(_DWORD *)(v15 + 8), a3: 2, a4: 1); /*0x1031230dc*/
            if ( v19 <= -901 ) /*0x1031230e6*/
              return v19; /*0x103123c0d*/
            goto LABEL_22; /*0x1031230e6*/
          }
          v19 = session_after_frame_sent1(a1); /*0x10312353a*/
          if ( v19 < 0 ) /*0x103123541*/
            return v19; /*0x103123541*/
          session_after_frame_sent2(a1); /*0x10312354a*/
          if ( v18 == -526 ) /*0x10312355d*/
            return 0; /*0x10312355d*/
          continue; /*0x10312355d*/
        case 3: /*0x103122f9f*/
          v20 = *(_QWORD *)(a1 + 464); /*0x1031230f1*/
          v21 = *(_QWORD *)(v20 + 24); /*0x1031230f9*/
          if ( v21 == *(_QWORD *)(v20 + 32) ) /*0x103123101*/
            goto LABEL_22; /*0x103123101*/
LABEL_206:
          *a2 = v21; /*0x103123bed*/
          v11 = *(_QWORD *)(v20 + 32) - *(_QWORD *)(v20 + 24); /*0x103123bfb*/
          *(_QWORD *)(v20 + 24) = *(_QWORD *)(v20 + 32); /*0x103123bff*/
          return v11; /*0x103123c03*/
        default:
          continue;
      }
      break;
    }
    v6 = ob_item; /*0x103122fb2*/
    v7 = *(unsigned __int8 *)(ob_item + 12); /*0x103122fb5*/
    switch ( v7 ) /*0x103122fd1*/
    {
      case 0LL: /*0x103122fd1*/
        v8 = nghttp2_map_find(a1, a2: *(_DWORD *)(v6 + 8)); /*0x103122fda*/
        if ( v8 == 0 || (v9 = v8, (*(_BYTE *)(v8 + 116) & 2) != 0) || *(_DWORD *)v8 == 5 ) /*0x103122ff2*/
          v9 = 0; /*0x103122ff4*/
        v10 = nghttp2_session_predicate_data_send(a1, a2: v9); /*0x103122ffd*/
        if ( v10 != 0 ) /*0x103123004*/
        {
          LODWORD(v11) = v10; /*0x10312300a*/
          v12 = nghttp2_map_find(a1, a2: *(_DWORD *)(v6 + 8)); /*0x103123014*/
          if ( v12 == 0 ) /*0x10312301c*/
            goto LABEL_89; /*0x10312301c*/
          v13 = a1; /*0x103123022*/
          v14 = v12; /*0x103123025*/
          goto LABEL_12; /*0x103123025*/
        }
        v41 = *(unsigned int *)(v9 + 84); /*0x1031235ef*/
        v42 = *(_DWORD *)(a1 + 2636); /*0x1031235f3*/
        if ( (int)v41 >= v42 ) /*0x1031235fd*/
          v41 = (unsigned int)v42; /*0x1031235ff*/
        v43 = *(_DWORD *)(a1 + 2676); /*0x103123601*/
        if ( (int)v41 >= v43 ) /*0x10312360b*/
          v41 = (unsigned int)v43; /*0x10312360d*/
        if ( (int)v41 <= 0 ) /*0x103123611*/
        {
          v44 = a1; /*0x103123908*/
          v45 = v9; /*0x10312390b*/
          v46 = 4; /*0x10312390e*/
LABEL_158:
          session_defer_stream_item(a1: v44, a2: v45, a3: v46); /*0x103123913*/
          *(_QWORD *)(a1 + 448) = 0; /*0x103123918*/
          goto LABEL_22; /*0x103123918*/
        }
        if ( (unsigned int)v41 >= 0x4000 ) /*0x10312361e*/
          v41 = 0x4000; /*0x10312361e*/
        LODWORD(v11) = nghttp2_session_pack_data(a1, a2: v76, a3: v41, a4: v6, a5: v6 + 96, a6: v9); /*0x10312363a*/
        if ( (int)v11 > -509 ) /*0x103123642*/
        {
          if ( (_DWORD)v11 != 0 ) /*0x10312364b*/
          {
            if ( (_DWORD)v11 != -508 ) /*0x103123658*/
              goto LABEL_180; /*0x103123658*/
            v44 = a1; /*0x10312365e*/
            v45 = v9; /*0x103123661*/
            v46 = 8; /*0x103123664*/
            goto LABEL_158; /*0x103123669*/
          }
          goto LABEL_126; /*0x10312364b*/
        }
        if ( (_DWORD)v11 != -521 ) /*0x103123944*/
        {
          if ( (_DWORD)v11 != -526 ) /*0x103123a95*/
          {
LABEL_180:
            v13 = a1; /*0x103123a9b*/
            v14 = v9; /*0x103123a9e*/
LABEL_12:
            session_detach_stream_item(a1: v13, a2: v14); /*0x103123028*/
            goto LABEL_89; /*0x10312302d*/
          }
          return 0; /*0x103123c1d*/
        }
        session_detach_stream_item(a1, a2: v9); /*0x103123950*/
        v31 = nghttp2_session_add_rst_stream_continue(a1, a2: *(_DWORD *)(v6 + 8), a3: 2, a4: 1); /*0x103123966*/
        LODWORD(v11) = -521; /*0x10312396b*/
        if ( v31 > -901 ) /*0x103123976*/
          goto LABEL_183; /*0x103123976*/
        goto LABEL_88; /*0x103123976*/
      case 1LL: /*0x103122fd1*/
        v26 = *(_DWORD *)(v6 + 8); /*0x103123218*/
        if ( *(_DWORD *)(v6 + 56) != 0 ) /*0x10312321c*/
        {
          v27 = nghttp2_map_find(a1, a2: v26); /*0x103123225*/
          if ( v27 == 0 || (v28 = v27, (*(_BYTE *)(v27 + 116) & 2) != 0) || (v29 = *(_DWORD *)v27) == 5 ) /*0x103123247*/
          {
            *(_DWORD *)(v6 + 56) = 3; /*0x103123568*/
LABEL_98:
            LODWORD(v11) = -510; /*0x103123570*/
            goto LABEL_183; /*0x103123576*/
          }
          if ( v29 == 4 ) /*0x103123253*/
          {
            LODWORD(v11) = -530; /*0x10312325e*/
            if ( (unsigned int)session_is_closing(a1) != 0 ) /*0x103123266*/
              goto LABEL_183; /*0x103123266*/
            LODWORD(v11) = -512; /*0x10312326c*/
            if ( (*(_BYTE *)(v28 + 117) & 2) != 0 ) /*0x103123277*/
              goto LABEL_183; /*0x103123277*/
            LODWORD(v11) = -505; /*0x10312327d*/
            if ( *(_BYTE *)(a1 + 2739) == 0 ) /*0x10312328c*/
              goto LABEL_183; /*0x10312328c*/
            if ( *(_DWORD *)v28 != 4 ) /*0x103123297*/
              goto LABEL_183; /*0x103123297*/
            LODWORD(v11) = -516; /*0x10312329d*/
            if ( (*(_BYTE *)(a1 + 2740) & 8) != 0 ) /*0x1031232ac*/
              goto LABEL_183; /*0x1031232ac*/
            *(_DWORD *)(v6 + 56) = 2; /*0x1031232b2*/
            v30 = *(_QWORD *)(v6 + 120); /*0x1031232ba*/
            if ( v30 != 0 ) /*0x1031232c1*/
              *(_QWORD *)(v28 + 56) = v30; /*0x1031232c7*/
          }
          else if ( (unsigned int)session_is_closing(a1) != 0 /*0x1031239b3*/
                 || (*(_BYTE *)(v28 + 117) & 2) != 0
                 || *(_BYTE *)(a1 + 2739) == 0
                 || (*(_DWORD *)(v28 + 80) & 1) == 0 && *(_DWORD *)(v28 + 80) != 0
                 || *(_DWORD *)v28 != 1 )
          {
            *(_DWORD *)(v6 + 56) = 3; /*0x1031239bf*/
            LODWORD(v11) = -530; /*0x1031239cf*/
            if ( (unsigned int)session_is_closing(a1) != 0 ) /*0x1031239d7*/
              goto LABEL_183; /*0x1031239d7*/
            LODWORD(v11) = -512; /*0x1031239dd*/
            if ( (*(_BYTE *)(v28 + 117) & 2) != 0 ) /*0x1031239e8*/
              goto LABEL_183; /*0x1031239e8*/
            if ( *(_DWORD *)v28 != 2 ) /*0x1031239f5*/
            {
              LODWORD(v11) = -511; /*0x1031239f7*/
              if ( *(_DWORD *)v28 == 3 ) /*0x103123a00*/
                goto LABEL_183; /*0x103123a00*/
              v63 = *(_DWORD *)(v28 + 80); /*0x103123a06*/
              LODWORD(v11) = -514; /*0x103123a0a*/
              if ( v63 == 0 || (((unsigned __int8)v63 ^ (*(_BYTE *)(a1 + 2739) == 0)) & 1) != 0 ) /*0x103123a29*/
                goto LABEL_183; /*0x103123a29*/
            }
          }
          else
          {
            *(_DWORD *)(v6 + 56) = 1; /*0x1031239b5*/
          }
LABEL_175:
          LODWORD(v11) = -522; /*0x103123a2f*/
          if ( (unsigned __int64)(nghttp2_hd_deflate_bound(a1: v73, a2: *(_QWORD *)(v6 + 40), a3: *(_QWORD *)(v6 + 48)) /*0x103123a52*/
                                + 5) > *(_QWORD *)(a1 + 2576) )
            goto LABEL_183; /*0x103123a52*/
          v31 = nghttp2_frame_pack_headers(a1: v76, a2: v6, a3: v73); /*0x103123a5f*/
          if ( v31 == 0 ) /*0x103123a66*/
          {
            v34 = session_headers_add_pad(a1, a2: v6); /*0x103123a72*/
            if ( v34 == 0 ) /*0x103123a80*/
            {
              if ( *(_DWORD *)(v6 + 56) == 0 ) /*0x103123bd6*/
              {
                v35 = *(_DWORD *)(v6 + 8); /*0x103123bdc*/
LABEL_205:
                *(_DWORD *)(a1 + 2612) = v35; /*0x103123be0*/
              }
              goto LABEL_126; /*0x103123be8*/
            }
LABEL_178:
            LODWORD(v11) = v34; /*0x103123a86*/
            goto LABEL_89; /*0x103123a89*/
          }
LABEL_88:
          LODWORD(v11) = v31; /*0x1031234fc*/
LABEL_89:
          if ( (_DWORD)v11 != -508 ) /*0x10312350d*/
          {
            if ( (_DWORD)v11 == -526 ) /*0x10312351a*/
              return 0; /*0x10312351a*/
            if ( (int)v11 < 0 ) /*0x103123523*/
              goto LABEL_183; /*0x103123523*/
LABEL_126:
            *(_QWORD *)(a1 + 448) = v6; /*0x103123728*/
            *(_QWORD *)(a1 + 464) = *(_QWORD *)(a1 + 456); /*0x103123738*/
            if ( *(_BYTE *)(v6 + 12) != 0 ) /*0x103123745*/
            {
              v53 = *(__int64 (__fastcall **)(__int64, __int64, _QWORD))(a1 + 2200); /*0x10312374b*/
              if ( v53 != nullptr && (v54 = v53(a1, a2: v6, a3: *(_QWORD *)(a1 + 2416))) != 0 ) /*0x103123775*/
              {
                v11 = -902; /*0x10312377b*/
                if ( v54 != -535 ) /*0x103123787*/
                  return v11; /*0x103123787*/
                v55 = *(unsigned int (__fastcall **)(__int64, __int64, __int64, _QWORD))(a1 + 2216); /*0x10312378d*/
                if ( v55 != nullptr && v55(a1, a2: v6, a3: 4294966761LL, a4: *(_QWORD *)(a1 + 2416)) != 0 ) /*0x1031237b1*/
                  return v11; /*0x1031237b1*/
                v56 = *(unsigned __int8 *)(v6 + 12); /*0x1031237b7*/
                if ( v56 == 5 ) /*0x1031237bf*/
                {
                  v57 = 2; /*0x103123811*/
                  v58 = 40; /*0x103123816*/
                }
                else
                {
                  if ( v56 != 1 || *(_DWORD *)(v6 + 56) != 0 ) /*0x1031237cf*/
                    goto LABEL_22; /*0x1031237cf*/
                  v57 = 7; /*0x1031237d5*/
                  v58 = 8; /*0x1031237da*/
                }
                v59 = *(_DWORD *)(v6 + v58); /*0x10312381b*/
                if ( v59 != 0 ) /*0x103123821*/
                {
                  v19 = nghttp2_session_close_stream(a1, a2: v59, a3: v57); /*0x10312382a*/
                  if ( v19 <= -901 ) /*0x103123834*/
                    return v19; /*0x103123834*/
                }
LABEL_22:
                active_outbound_item_reset(a1: v74, a2: v75); /*0x103123107*/
              }
              else
              {
LABEL_138:
                *(_DWORD *)(a1 + 520) = 1; /*0x103123800*/
              }
            }
            else
            {
              if ( *(_BYTE *)(v6 + 122) == 0 ) /*0x1031237ed*/
                goto LABEL_138; /*0x1031237ed*/
              *(_DWORD *)(a1 + 520) = 2; /*0x1031237ef*/
            }
          }
          continue; /*0x103123114*/
        }
        v39 = nghttp2_session_open_stream(a1, a2: v26, a3: 0, a4: 0, a5: *(_QWORD *)(v6 + 120)); /*0x103123586*/
        if ( v39 == 0 ) /*0x10312358e*/
        {
          LODWORD(v11) = -901; /*0x1031238fd*/
          goto LABEL_183; /*0x103123903*/
        }
        LODWORD(v11) = -511; /*0x103123594*/
        if ( *(_BYTE *)(v6 + 132) == 0 ) /*0x1031235a2*/
        {
          LODWORD(v11) = -516; /*0x1031235a8*/
          if ( (*(_BYTE *)(a1 + 2740) & 8) == 0 ) /*0x1031235b7*/
          {
            v40 = v39; /*0x1031235bd*/
            if ( (unsigned int)session_is_closing(a1) == 0 ) /*0x1031235ca*/
            {
              if ( (*(_BYTE *)(a1 + 2724) & 4) == 0 ) /*0x1031235d9*/
                nghttp2_http_record_request_method(a1: v40, a2: v6); /*0x1031235e5*/
              goto LABEL_175; /*0x1031235ea*/
            }
          }
        }
LABEL_183:
        v64 = *(_BYTE *)(v6 + 12); /*0x103123ab4*/
        v65 = 0; /*0x103123ab8*/
        if ( v64 == 0 ) /*0x103123abd*/
          goto LABEL_197; /*0x103123abd*/
        v66 = *(unsigned int (__fastcall **)(__int64, __int64, _QWORD, _QWORD))(a1 + 2216); /*0x103123ac3*/
        if ( v66 != nullptr && (unsigned int)v11 >= 0xFFFFFC7D && v64 != 8 ) /*0x103123adc*/
        {
          if ( v64 == 3 && (_DWORD)v11 == -510 ) /*0x103123aef*/
            goto LABEL_197; /*0x103123af4*/
          if ( v66(a1, a2: v6, a3: (unsigned int)v11, a4: *(_QWORD *)(a1 + 2416)) != 0 ) /*0x103123b0c*/
          {
            nghttp2_outbound_item_free(a1: v6, a2: v75); /*0x103123c3c*/
            nghttp2_mem_free(a1: v75, a2: v6); /*0x103123c47*/
            return -902; /*0x103123c47*/
          }
          v64 = *(_BYTE *)(v6 + 12); /*0x103123b12*/
        }
        if ( v64 == 5 ) /*0x103123b18*/
        {
          v67 = *(_DWORD *)(v6 + 40); /*0x103123b44*/
          v68 = 2; /*0x103123b48*/
        }
        else
        {
          if ( v64 != 1 || *(_DWORD *)(v6 + 56) != 0 ) /*0x103123b27*/
            goto LABEL_197; /*0x103123b27*/
          v67 = *(_DWORD *)(v6 + 8); /*0x103123b29*/
          if ( *(_BYTE *)(v6 + 132) != 0 ) /*0x103123b35*/
            v68 = *(_DWORD *)(v6 + 128); /*0x103123b3b*/
          else
            v68 = 7; /*0x103123bc7*/
        }
        if ( v67 != 0 ) /*0x103123b4f*/
          v65 = nghttp2_session_close_stream(a1, a2: v67, a3: v68); /*0x103123b59*/
LABEL_197:
        nghttp2_outbound_item_free(a1: v6, a2: v75); /*0x103123b5c*/
        nghttp2_mem_free(a1: v75, a2: v6); /*0x103123b71*/
        active_outbound_item_reset(a1: v74, a2: v75); /*0x103123b7d*/
        if ( v65 <= -901 ) /*0x103123b89*/
          return v65; /*0x103123c08*/
        if ( (_DWORD)v11 == -523 ) /*0x103123b92*/
          LODWORD(v11) = session_terminate_session(a1, a2: *(unsigned int *)(a1 + 2620), a3: 2, a4: 0); /*0x103123bab*/
        v3 = a3; /*0x103123bb5*/
        if ( (int)v11 > -901 ) /*0x103123bbf*/
          continue; /*0x103123bbf*/
        return (int)v11; /*0x103123c23*/
      case 2LL: /*0x103122fd1*/
        LODWORD(v11) = -530; /*0x1031232d8*/
        if ( (unsigned int)session_is_closing(a1) != 0 ) /*0x1031232e0*/
          goto LABEL_183; /*0x1031232e0*/
        nghttp2_frame_pack_priority(a1: (__int64 *)v76, a2: v6); /*0x1031232ed*/
        goto LABEL_126; /*0x1031232f2*/
      case 3LL: /*0x103122fd1*/
        LODWORD(v11) = -530; /*0x103123158*/
        if ( (unsigned int)session_is_closing(a1) != 0 ) /*0x103123160*/
          goto LABEL_183; /*0x103123160*/
        if ( *(_BYTE *)(v6 + 96) == 0 ) /*0x10312316b*/
        {
          v62 = nghttp2_map_find(a1, a2: *(_DWORD *)(v6 + 8)); /*0x1031238d1*/
          LODWORD(v11) = -510; /*0x1031238d6*/
          if ( v62 == 0 || (*(_BYTE *)(v62 + 116) & 2) != 0 || *(_DWORD *)v62 == 5 ) /*0x1031238f2*/
            goto LABEL_183; /*0x1031238f2*/
        }
        nghttp2_frame_pack_rst_stream(a1: (__int64 *)v76, a2: v6); /*0x103123178*/
        goto LABEL_126; /*0x10312317d*/
      case 4LL: /*0x103122fd1*/
        if ( (*(_BYTE *)(v6 + 13) & 1) != 0 ) /*0x103123331*/
        {
          --*(_QWORD *)(a1 + 2560); /*0x103123333*/
          LODWORD(v11) = -530; /*0x103123343*/
          if ( (unsigned int)session_is_closing(a1) != 0 ) /*0x10312334b*/
            goto LABEL_183; /*0x10312334b*/
        }
        v31 = nghttp2_frame_pack_settings(a1: (__int64 *)v76, a2: (_QWORD *)v6); /*0x103123358*/
        goto LABEL_88; /*0x10312335d*/
      case 5LL: /*0x103122fd1*/
        v32 = nghttp2_map_find(a1, a2: *(_DWORD *)(v6 + 8)); /*0x103123369*/
        if ( v32 == 0 || (v33 = v32, (*(_BYTE *)(v32 + 116) & 2) != 0) || *(_DWORD *)v32 == 5 ) /*0x103123381*/
          v33 = 0; /*0x103123383*/
        if ( *(_BYTE *)(a1 + 2739) == 0 ) /*0x10312338f*/
        {
          LODWORD(v11) = -505; /*0x10312366e*/
          goto LABEL_183; /*0x103123674*/
        }
        if ( v33 == 0 ) /*0x103123398*/
          goto LABEL_98; /*0x103123398*/
        LODWORD(v11) = -530; /*0x1031233a6*/
        if ( (unsigned int)session_is_closing(a1) != 0 ) /*0x1031233ae*/
          goto LABEL_183; /*0x1031233ae*/
        LODWORD(v11) = -512; /*0x1031233b4*/
        if ( (*(_BYTE *)(v33 + 117) & 2) != 0 ) /*0x1031233bf*/
          goto LABEL_183; /*0x1031233bf*/
        if ( *(_DWORD *)(a1 + 2664) == 0 ) /*0x1031233ce*/
        {
          LODWORD(v11) = -528; /*0x103123aae*/
          goto LABEL_183; /*0x103123aae*/
        }
        LODWORD(v11) = -511; /*0x1031233d4*/
        if ( *(_DWORD *)v33 == 3 ) /*0x1031233df*/
          goto LABEL_183; /*0x1031233df*/
        LODWORD(v11) = -516; /*0x1031233e5*/
        if ( (*(_BYTE *)(a1 + 2740) & 8) != 0 ) /*0x1031233f4*/
          goto LABEL_183; /*0x1031233f4*/
        LODWORD(v11) = -522; /*0x10312340b*/
        if ( (unsigned __int64)nghttp2_hd_deflate_bound(a1: v73, a2: *(_QWORD *)(v6 + 24), a3: *(_QWORD *)(v6 + 32)) > *(_QWORD *)(a1 + 2576) ) /*0x103123419*/
          goto LABEL_183; /*0x103123419*/
        v31 = nghttp2_frame_pack_push_promise(a1: v76, a2: v6, a3: v73); /*0x10312342a*/
        if ( v31 != 0 ) /*0x103123431*/
          goto LABEL_88; /*0x103123431*/
        v34 = session_headers_add_pad(a1, a2: v6); /*0x10312343d*/
        if ( v34 != 0 ) /*0x10312344b*/
          goto LABEL_178; /*0x10312344b*/
        v35 = *(_DWORD *)(v6 + 40); /*0x103123451*/
        goto LABEL_205; /*0x103123455*/
      case 6LL: /*0x103122fd1*/
        if ( (*(_BYTE *)(v6 + 13) & 1) != 0 ) /*0x1031232fc*/
          --*(_QWORD *)(a1 + 2560); /*0x1031232fe*/
        LODWORD(v11) = -530; /*0x103123306*/
        if ( (*(_BYTE *)(a1 + 2740) & 1) != 0 ) /*0x103123315*/
          goto LABEL_183; /*0x103123315*/
        nghttp2_frame_pack_ping(a1: (__int64 *)v76, a2: v6); /*0x103123322*/
        goto LABEL_126; /*0x103123327*/
      case 7LL: /*0x103122fd1*/
        v31 = nghttp2_frame_pack_goaway(a1: (__int64)v76, a2: v6); /*0x1031234ef*/
        if ( v31 != 0 ) /*0x1031234f6*/
          goto LABEL_88; /*0x1031234f6*/
        *(_DWORD *)(a1 + 2628) = *(_DWORD *)(v6 + 16); /*0x103123720*/
        goto LABEL_126; /*0x103123720*/
      case 8LL: /*0x103122fd1*/
        v22 = *(_DWORD *)(v6 + 8); /*0x103123182*/
        LODWORD(v11) = -530; /*0x10312318e*/
        if ( (unsigned int)session_is_closing(a1) != 0 ) /*0x103123196*/
          goto LABEL_183; /*0x103123196*/
        if ( v22 != 0 ) /*0x10312319f*/
        {
          v23 = nghttp2_map_find(a1, a2: v22); /*0x1031231a7*/
          LODWORD(v11) = -510; /*0x1031231ac*/
          if ( v23 == 0 || (*(_BYTE *)(v23 + 116) & 2) != 0 ) /*0x1031231bf*/
            goto LABEL_183; /*0x1031231bf*/
          v24 = *(_DWORD *)v23; /*0x1031231c5*/
          if ( *(_DWORD *)v23 == 3 ) /*0x1031231ca*/
            goto LABEL_181; /*0x1031231ca*/
          if ( v24 == 5 ) /*0x1031231d3*/
            goto LABEL_183; /*0x1031231d3*/
          if ( v24 == 4 ) /*0x1031231dc*/
          {
            v25 = *(_DWORD *)(v23 + 80); /*0x1031231de*/
            if ( v25 != 0 ) /*0x1031231e3*/
            {
              LODWORD(v11) = -514; /*0x1031231f3*/
              if ( (((unsigned __int8)v25 ^ (*(_BYTE *)(a1 + 2739) == 0)) & 1) == 0 ) /*0x1031231fc*/
                goto LABEL_183; /*0x1031231fc*/
            }
          }
        }
        nghttp2_frame_pack_window_update(a1: (__int64 *)v76, a2: v6); /*0x103123202*/
        goto LABEL_126; /*0x10312320e*/
      case 9LL: /*0x103122fd1*/
        goto LABEL_126;
      default:
        if ( *(_BYTE *)(v6 + 96) == 0 ) /*0x10312345f*/
        {
          LODWORD(v11) = -530; /*0x103123681*/
          if ( (unsigned int)session_is_closing(a1) != 0 ) /*0x103123689*/
            goto LABEL_183; /*0x103123689*/
          v47 = *(_QWORD *)(a1 + 456); /*0x10312368f*/
          v70 = v47; /*0x10312369b*/
          v48 = *(_QWORD *)(v47 + 32); /*0x10312369f*/
          v49 = *(_QWORD *)(v47 + 16) - v48; /*0x1031236a3*/
          if ( v49 >= 0x4000 ) /*0x1031236ae*/
            v49 = 0x4000; /*0x1031236ae*/
          v50 = *(__int64 (__fastcall **)(__int64, __int64, unsigned __int64, __int64, _QWORD))(a1 + 2328); /*0x1031236b2*/
          if ( v50 == nullptr ) /*0x1031236bd*/
            v50 = *(__int64 (__fastcall **)(__int64, __int64, unsigned __int64, __int64, _QWORD))(a1 + 2320); /*0x1031236bf*/
          v51 = v50(a1, a2: v48, a3: v49, a4: v6, a5: *(_QWORD *)(a1 + 2416)); /*0x1031236d8*/
          LODWORD(v11) = -535; /*0x1031236da*/
          if ( v51 == -535 ) /*0x1031236e6*/
            goto LABEL_183; /*0x1031236e6*/
          LODWORD(v11) = -902; /*0x1031236ec*/
          if ( v51 > v49 ) /*0x1031236f5*/
            goto LABEL_183; /*0x1031236f5*/
          *(_QWORD *)v6 = v51; /*0x1031236fb*/
          *(_QWORD *)(v70 + 32) += v51; /*0x103123702*/
          v52 = *(_QWORD *)(v70 + 24) - 9LL; /*0x10312370a*/
          *(_QWORD *)(v70 + 24) = v52; /*0x10312370e*/
          nghttp2_frame_pack_frame_hd(a1: v52, a2: v6); /*0x103123715*/
          goto LABEL_126; /*0x10312371a*/
        }
        if ( (_DWORD)v7 != 16 ) /*0x103123468*/
        {
          if ( (_DWORD)v7 != 12 ) /*0x103123471*/
          {
            if ( (_DWORD)v7 == 10 ) /*0x10312347a*/
            {
              v36 = *(_DWORD *)(v6 + 8); /*0x103123480*/
              LODWORD(v11) = -530; /*0x10312348c*/
              if ( (unsigned int)session_is_closing(a1) != 0 ) /*0x103123494*/
                goto LABEL_183; /*0x103123494*/
              if ( v36 != 0 ) /*0x10312349d*/
              {
                v37 = nghttp2_map_find(a1, a2: v36); /*0x1031234a5*/
                LODWORD(v11) = -510; /*0x1031234aa*/
                if ( v37 == 0 || (*(_BYTE *)(v37 + 116) & 2) != 0 ) /*0x1031234bd*/
                  goto LABEL_183; /*0x1031234bd*/
                v38 = *(_DWORD *)v37; /*0x1031234c3*/
                if ( v38 == 3 ) /*0x1031234c8*/
                  goto LABEL_181; /*0x1031234c8*/
                if ( v38 == 5 ) /*0x1031234d1*/
                  goto LABEL_183; /*0x1031234d1*/
              }
              nghttp2_frame_pack_altsvc(a1: (__int64)v76, a2: v6); /*0x1031234de*/
            }
            goto LABEL_126; /*0x1031234e3*/
          }
          LODWORD(v11) = -530; /*0x103123847*/
          if ( (unsigned int)session_is_closing(a1) != 0 ) /*0x10312384f*/
            goto LABEL_183; /*0x10312384f*/
          v31 = nghttp2_frame_pack_origin(a1: (__int64 *)v76, a2: (_QWORD *)v6); /*0x10312385c*/
          goto LABEL_88; /*0x103123861*/
        }
        v60 = **(_DWORD **)(v6 + 16); /*0x10312386a*/
        LODWORD(v11) = -530; /*0x103123875*/
        if ( (unsigned int)session_is_closing(a1) != 0 ) /*0x10312387d*/
          goto LABEL_183; /*0x10312387d*/
        v61 = nghttp2_map_find(a1, a2: v60); /*0x103123889*/
        if ( v61 != 0 && (*(_BYTE *)(v61 + 116) & 2) == 0 ) /*0x103123897*/
        {
          if ( *(_DWORD *)v61 == 3 ) /*0x10312389e*/
          {
LABEL_181:
            LODWORD(v11) = -511; /*0x103123aa6*/
            goto LABEL_183; /*0x103123aac*/
          }
          if ( *(_DWORD *)v61 != 5 ) /*0x1031238a7*/
          {
            LODWORD(v11) = -514; /*0x1031238a9*/
            if ( (*(_BYTE *)(v61 + 117) & 1) != 0 ) /*0x1031238b3*/
              goto LABEL_183; /*0x1031238b3*/
          }
        }
        nghttp2_frame_pack_priority_update(a1: (__int64)v76, a2: v6); /*0x1031238c0*/
        goto LABEL_126; /*0x1031238c5*/
    }
  }
}

// Address: 0x103124024 | Name: _nghttp2_session_send
__int64 __fastcall nghttp2_session_send(__int64 a1)
{
  __int64 v2; // r14
  __int64 (__fastcall *v3)(__int64, _QWORD, __int64, _QWORD, _QWORD); // rax
  __int64 v4; // rax
  unsigned int v5; // ecx
  _QWORD v7[4]; // [rsp+0h] [rbp-20h] BYREF

  v7[0] = 0; /*0x103124035*/
  v2 = nghttp2_session_mem_send_internal(a1, a2: v7, a3: 0); /*0x103124043*/
  if ( v2 <= 0 )
  {
    return (unsigned int)v2; /*0x1031240b3*/
  }
  else
  {
    while ( 1 )
    {
      v3 = *(__int64 (__fastcall **)(__int64, _QWORD, __int64, _QWORD, _QWORD))(a1 + 2152); /*0x10312404f*/
      v4 = v3 != nullptr
         ? v3(a1, a2: v7[0], a3: v2, a4: 0, a5: *(_QWORD *)(a1 + 2416))
         : (*(__int64 (__fastcall **)(__int64, _QWORD, __int64, _QWORD, _QWORD))(a1 + 2144))(
             a1,
             a2: v7[0],
             a3: v2,
             a4: 0,
             a5: *(_QWORD *)(a1 + 2416));
      if ( v4 < 0 ) /*0x10312408e*/
        break; /*0x10312408e*/
      *(_QWORD *)(*(_QWORD *)(a1 + 464) + 24LL) += v4 - v2; /*0x10312409a*/
      v2 = nghttp2_session_mem_send_internal(a1, a2: v7, a3: 0); /*0x1031240ab*/
      if ( v2 <= 0 ) /*0x1031240b1*/
        return (unsigned int)v2; /*0x1031240b1*/
    }
    v5 = -902; /*0x1031240c3*/
    if ( v4 == -504 ) /*0x1031240ce*/
    {
      *(_QWORD *)(*(_QWORD *)(a1 + 464) + 24LL) -= v2; /*0x1031240d7*/
      return 0; /*0x1031240db*/
    }
  }
  return v5; /*0x1031240bc*/
}

// Address: 0x1031240df | Name: _nghttp2_session_on_request_headers_received
__int64 __fastcall nghttp2_session_on_request_headers_received(__int64 a1, __int64 a2)
{
  __int64 v3; // r14
  int v4; // esi
  unsigned __int64 v5; // rax
  unsigned int v6; // r15d
  __int64 v7; // rsi
  const char *v8; // rcx
  __int64 v9; // rax
  __int64 v10; // rsi
  __int64 v11; // rdx
  int v12; // eax
  __int64 (__fastcall *v14)(__int64, __int64, _QWORD); // rax
  int v15; // eax

  v3 = a1; /*0x1031240ec*/
  v4 = *(_DWORD *)(a2 + 8); /*0x1031240ef*/
  if ( v4 == 0 )
  {
    v8 = "request HEADERS: stream_id == 0";
    goto LABEL_21; /*0x10312415d*/
  }
  if ( *(_BYTE *)(a1 + 2739) == 0 )
  {
    v6 = -103; /*0x10312416e*/
    if ( (v4 & 1) != 0 ) /*0x103124178*/
    {
      if ( *(_DWORD *)(a1 + 2612) >= v4 ) /*0x103124181*/
        return v6; /*0x103124181*/
    }
    else if ( *(_DWORD *)(a1 + 2616) >= v4 ) /*0x1031241b9*/
    {
      return v6; /*0x1031241b9*/
    }
    v8 = "request HEADERS: client received request";
    goto LABEL_21; /*0x1031241c2*/
  }
  if ( (v4 & 1) == 0 || *(_DWORD *)(a1 + 2616) >= v4 )
  {
    if ( (v4 & 1) != 0 )
    {
      v9 = nghttp2_map_find(a1, a2: v4); /*0x103124188*/
      v6 = -103; /*0x10312418d*/
      if ( v9 == 0 || (*(_BYTE *)(v9 + 117) & 1) == 0 ) /*0x10312419c*/
        return v6; /*0x10312419c*/
      v8 = "HEADERS: stream closed";
      a1 = v3; /*0x1031241a5*/
      v10 = a2; /*0x1031241a8*/
      v11 = 4294966786LL; /*0x1031241ab*/
      goto LABEL_22; /*0x1031241b0*/
    }
    v8 = "request HEADERS: invalid stream_id";
LABEL_21:
    v10 = a2; /*0x1031241cb*/
    v11 = 4294966791LL; /*0x1031241d1*/
LABEL_22:
    v12 = session_handle_invalid_connection(a1, a2: v10, a3: v11, a4: v8); /*0x1031241d6*/
    goto LABEL_23; /*0x1031241d6*/
  }
  *(_DWORD *)(a1 + 2616) = v4; /*0x10312410f*/
  v5 = *(_QWORD *)(a1 + 2512); /*0x10312411d*/
  if ( v5 >= *(unsigned int *)(a1 + 2700) )
  {
    v8 = "request HEADERS: max concurrent streams exceeded";
    goto LABEL_21; /*0x1031241c4*/
  }
  v6 = -103; /*0x10312412d*/
  if ( (*(_BYTE *)(a1 + 2740) & 5) != 0 ) /*0x10312413b*/
    return v6; /*0x10312413b*/
  v7 = *(unsigned int *)(a2 + 8); /*0x103124141*/
  if ( *(_DWORD *)(a2 + 24) == (_DWORD)v7 )
  {
    v8 = "request HEADERS: depend on itself";
    goto LABEL_21; /*0x103124154*/
  }
  if ( v5 >= *(unsigned int *)(a1 + 2728) ) /*0x103124202*/
  {
    v12 = session_handle_invalid_stream2(a1, a2: v7, a3: a2, a4: 4294966763LL); /*0x103124269*/
LABEL_23:
    v6 = -103; /*0x1031241db*/
    if ( v12 < -900 ) /*0x1031241e6*/
      return (unsigned int)v12; /*0x1031241e6*/
    return v6; /*0x1031241e6*/
  }
  v6 = 0; /*0x103124204*/
  if ( nghttp2_session_open_stream(a1, a2: v7, a3: 0, a4: 1, a5: 0) != 0 ) /*0x10312421c*/
  {
    *(_DWORD *)(v3 + 2620) = *(_DWORD *)(v3 + 2616); /*0x103124225*/
    v14 = *(__int64 (__fastcall **)(__int64, __int64, _QWORD))(v3 + 2232); /*0x10312422c*/
    if ( v14 != nullptr ) /*0x103124236*/
    {
      v15 = v14(a1: v3, a2, a3: *(_QWORD *)(v3 + 2416)); /*0x103124245*/
      v6 = -902; /*0x103124249*/
      if ( v15 == 0 ) /*0x10312424f*/
        v6 = 0; /*0x10312424f*/
      if ( v15 == -521 ) /*0x103124258*/
        return (unsigned int)-521; /*0x103124258*/
    }
  }
  else
  {
    return (unsigned int)-901; /*0x103124273*/
  }
  return v6; /*0x1031241f1*/
}

// Address: 0x10312427e | Name: _nghttp2_session_on_response_headers_received
__int64 __fastcall nghttp2_session_on_response_headers_received(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 (__fastcall *v3)(__int64, __int64, _QWORD); // rax
  int v4; // ecx
  __int64 result; // rax
  const char *v6; // rcx
  __int64 v7; // rdx
  int v8; // ecx

  if ( *(_DWORD *)(a2 + 8) != 0 )
  {
    if ( (*(_BYTE *)(a3 + 117) & 1) == 0 ) /*0x10312428c*/
    {
      *(_DWORD *)a3 = 2; /*0x10312428e*/
      v3 = *(__int64 (__fastcall **)(__int64, __int64, _QWORD))(a1 + 2232); /*0x103124294*/
      if ( v3 == nullptr ) /*0x10312429e*/
        return 0; /*0x1031242f0*/
      v4 = v3(a1, a2, a3: *(_QWORD *)(a1 + 2416)); /*0x1031242a9*/
      result = 4294966394LL; /*0x1031242ad*/
      if ( v4 == 0 ) /*0x1031242b2*/
        result = 0; /*0x1031242b2*/
      if ( v4 == -521 ) /*0x1031242bb*/
        return 4294966775LL; /*0x1031242bb*/
      return result; /*0x1031242bb*/
    }
    v6 = "HEADERS: stream closed";
    v7 = 4294966786LL; /*0x1031242d5*/
  }
  else
  {
    v6 = "response HEADERS: stream_id == 0";
    v7 = 4294966791LL; /*0x1031242c7*/
  }
  v8 = session_handle_invalid_connection(a1, a2, a3: v7, a4: v6); /*0x1031242df*/
  result = 4294967193LL; /*0x1031242e6*/
  if ( v8 < -900 ) /*0x1031242eb*/
    return (unsigned int)v8; /*0x1031242eb*/
  return result; /*0x1031242ee*/
}

// Address: 0x1031242f4 | Name: _nghttp2_session_on_push_response_headers_received
__int64 __fastcall nghttp2_session_on_push_response_headers_received(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v5; // rsi
  const char *v6; // rcx
  unsigned __int64 v7; // rcx
  __int64 result; // rax
  int v10; // eax
  __int64 (__fastcall *v11)(__int64, __int64, _QWORD); // rax
  int v12; // ecx
  int v13; // eax
  unsigned int v14; // ecx
  bool v15; // cc

  v5 = *(unsigned int *)(a2 + 8); /*0x103124304*/
  if ( (_DWORD)v5 == 0 )
  {
    v6 = "push response HEADERS: stream_id == 0";
    goto LABEL_18; /*0x103124328*/
  }
  if ( *(_BYTE *)(a1 + 2739) != 0 )
  {
    v6 = "HEADERS: no HEADERS allowed from client in reserved state";
LABEL_18:
    v13 = session_handle_invalid_connection(a1, a2, a3: 4294966791LL, a4: v6); /*0x1031243d2*/
    goto LABEL_19; /*0x1031243dd*/
  }
  v7 = *(_QWORD *)(a1 + 2512); /*0x103124334*/
  if ( v7 >= *(unsigned int *)(a1 + 2700) )
  {
    v6 = "push response HEADERS: max concurrent streams exceeded";
    goto LABEL_18; /*0x1031243cb*/
  }
  result = 4294967193LL; /*0x103124344*/
  if ( (*(_BYTE *)(a1 + 2740) & 5) != 0 ) /*0x103124351*/
    return result; /*0x103124351*/
  if ( v7 >= *(unsigned int *)(a1 + 2728) ) /*0x103124361*/
  {
    v13 = session_handle_invalid_stream2(a1, a2: v5, a3: a2, a4: 4294966763LL); /*0x103124407*/
LABEL_19:
    v14 = v13; /*0x1031243e2*/
    v15 = v13 < -900; /*0x1031243e4*/
    result = 4294967193LL; /*0x1031243e9*/
    if ( v15 ) /*0x1031243ee*/
      return v14; /*0x1031243ee*/
    return result; /*0x1031243ee*/
  }
  nghttp2_stream_promise_fulfilled(a1: a3); /*0x10312436d*/
  v10 = *(_DWORD *)(a3 + 80); /*0x103124372*/
  if ( v10 == 0 || (*(_BYTE *)(a1 + 2739) == 0) != (v10 & 1) ) /*0x103124389*/
    --*(_QWORD *)(a1 + 2520); /*0x10312438b*/
  ++*(_QWORD *)(a1 + 2512); /*0x103124392*/
  v11 = *(__int64 (__fastcall **)(__int64, __int64, _QWORD))(a1 + 2232); /*0x103124399*/
  if ( v11 == nullptr ) /*0x1031243a3*/
    return 0; /*0x10312440e*/
  v12 = v11(a1, a2, a3: *(_QWORD *)(a1 + 2416)); /*0x1031243b4*/
  result = 4294966394LL; /*0x1031243b8*/
  if ( v12 == 0 ) /*0x1031243bd*/
    result = 0; /*0x1031243bd*/
  if ( v12 == -521 ) /*0x1031243c6*/
    return 4294966775LL; /*0x1031243c6*/
  return result; /*0x1031243f5*/
}

// Address: 0x103124412 | Name: _nghttp2_session_on_headers_received
__int64 __fastcall nghttp2_session_on_headers_received(__int64 a1, __int64 a2, int *a3)
{
  int v3; // eax
  char v4; // r8
  int v5; // ecx
  __int64 result; // rax
  const char *v7; // rcx
  __int64 v8; // rdx
  int v9; // ecx
  __int64 (__fastcall *v10)(__int64, __int64, _QWORD); // rax
  int v11; // ecx

  v3 = *(_DWORD *)(a2 + 8); /*0x103124416*/
  if ( v3 == 0 )
  {
    v7 = "HEADERS: stream_id == 0";
    v8 = 4294966791LL; /*0x10312444c*/
    goto LABEL_8; /*0x103124451*/
  }
  if ( (*((_BYTE *)a3 + 117) & 1) != 0 )
  {
    v7 = "HEADERS: stream closed";
    v8 = 4294966786LL; /*0x10312445a*/
LABEL_8:
    v9 = session_handle_invalid_connection(a1, a2, a3: v8, a4: v7); /*0x10312445f*/
    result = 4294967193LL; /*0x10312446b*/
    if ( v9 < -900 ) /*0x103124470*/
      return (unsigned int)v9; /*0x103124470*/
    return result; /*0x103124470*/
  }
  v4 = v3 ^ (*(_BYTE *)(a1 + 2739) == 0); /*0x10312442e*/
  v5 = *a3; /*0x103124431*/
  result = 4294967193LL; /*0x103124433*/
  if ( (v4 & 1) != 0 ) /*0x10312443c*/
  {
    if ( v5 == 3 ) /*0x103124441*/
      return result; /*0x103124441*/
  }
  else if ( v5 != 2 ) /*0x103124478*/
  {
    return result; /*0x103124478*/
  }
  v10 = *(__int64 (__fastcall **)(__int64, __int64, _QWORD))(a1 + 2232); /*0x10312447a*/
  if ( v10 == nullptr ) /*0x103124484*/
    return 0; /*0x1031244a6*/
  v11 = v10(a1, a2, a3: *(_QWORD *)(a1 + 2416)); /*0x10312448f*/
  result = 4294966394LL; /*0x103124493*/
  if ( v11 == 0 ) /*0x103124498*/
    result = 0; /*0x103124498*/
  if ( v11 == -521 ) /*0x1031244a1*/
    return 4294966775LL; /*0x1031244a1*/
  return result; /*0x103124473*/
}

// Address: 0x1031244aa | Name: _nghttp2_session_on_rst_stream_received
__int64 __fastcall nghttp2_session_on_rst_stream_received(__int64 a1, __int64 a2)
{
  int v4; // esi
  __int64 v5; // rax
  unsigned int (__fastcall *v6)(__int64, __int64, _QWORD); // rax
  unsigned int v7; // r15d
  __int64 v8; // rdi
  unsigned __int64 v9; // rax
  const char *v11; // rcx

  v4 = *(_DWORD *)(a2 + 8); /*0x1031244ba*/
  if ( v4 == 0 )
  {
    v11 = "RST_STREAM: stream_id == 0";
    return session_handle_invalid_connection(a1, a2, a3: 4294966791LL, a4: v11); /*0x1031245ee*/
  }
  if ( (*(_BYTE *)(a1 + 2739) == 0) != (v4 & 1) ) /*0x1031244d5*/
  {
    if ( *(_DWORD *)(a1 + 2616) >= v4 ) /*0x1031244e1*/
      goto LABEL_4; /*0x1031244e1*/
  }
  else if ( *(_DWORD *)(a1 + 2612) >= v4 ) /*0x1031245cc*/
  {
LABEL_4:
    v5 = nghttp2_map_find(a1, a2: v4); /*0x1031244e7*/
    if ( v5 != 0 && (*(_BYTE *)(v5 + 116) & 2) == 0 && *(_DWORD *)v5 != 5 ) /*0x1031244fd*/
      nghttp2_stream_shutdown(a1: v5, a2: 1); /*0x103124507*/
    v6 = *(unsigned int (__fastcall **)(__int64, __int64, _QWORD))(a1 + 2176); /*0x10312450c*/
    if ( v6 != nullptr ) /*0x103124516*/
    {
      v7 = -902; /*0x103124527*/
      if ( v6(a1, a2, a3: *(_QWORD *)(a1 + 2416)) != 0 ) /*0x10312452f*/
        return v7; /*0x10312452f*/
    }
    v7 = nghttp2_session_close_stream(a1, a2: *(_DWORD *)(a2 + 8), a3: *(_DWORD *)(a2 + 16)); /*0x103124545*/
    if ( (int)v7 < -900 ) /*0x10312454d*/
      return v7; /*0x10312454d*/
    v7 = 0; /*0x103124553*/
    if ( *(_BYTE *)(a1 + 2739) == 0 ) /*0x10312455d*/
      return v7; /*0x10312455d*/
    if ( (*(_BYTE *)(a1 + 2740) & 0x10) != 0 ) /*0x10312456a*/
      return v7; /*0x10312456a*/
    v9 = nghttp2_time_now_sec(a1: v8); /*0x103124577*/
    nghttp2_ratelim_update(a1: (unsigned __int64 *)(a1 + 2432), a2: v9); /*0x103124582*/
    if ( (unsigned int)nghttp2_ratelim_drain(a1: a1 + 2432, a2: 1u) == 0 ) /*0x103124596*/
      return v7; /*0x1031245f3*/
    else
      return nghttp2_session_add_goaway(a1, a2: *(unsigned int *)(a1 + 2616), a3: 2, a4: 0, a5: 0, a6: 0); /*0x1031245b8*/
  }
  v11 = "RST_STREAM: stream in idle";
  return session_handle_invalid_connection(a1, a2, a3: 4294966791LL, a4: v11); /*0x1031245d2*/
}

// Address: 0x103124669 | Name: _nghttp2_session_update_local_settings
__int64 __fastcall nghttp2_session_update_local_settings(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v6; // rcx
  unsigned int v7; // r13d
  unsigned int v8; // eax
  char v9; // dl
  int v10; // r12d
  __int64 v11; // rsi
  int v12; // edi
  __int64 v13; // rdi
  __int64 result; // rax
  unsigned int v15; // eax
  _DWORD *v16; // rax
  _DWORD *v17; // rcx
  _DWORD *v18; // rdx
  _DWORD *v19; // rsi
  _DWORD *v20; // rdi
  _DWORD *v21; // r8
  _DWORD *v22; // r9
  _DWORD *v23; // r15
  __int64 v24; // r10
  _DWORD *v25; // r12
  _QWORD v26[8]; // [rsp-40h] [rbp-40h] BYREF

  if ( a3 == 0 ) /*0x10312466c*/
    return 0; /*0x1031247ef*/
  v6 = -a3; /*0x10312468f*/
  v7 = 0; /*0x103124692*/
  v8 = -1; /*0x103124695*/
  v9 = 1; /*0x10312469a*/
  v10 = -1; /*0x10312469c*/
  v11 = 0; /*0x1031246a2*/
  while ( 2 ) /*0x1031246a4*/
  {
    ++v11; /*0x1031246a4*/
    while ( 1 ) /*0x1031246a7*/
    {
      v12 = *(_DWORD *)(a2 + 8 * v11 - 8); /*0x1031246a7*/
      if ( v12 == 4 ) /*0x1031246af*/
      {
        v10 = *(_DWORD *)(a2 + 8 * v11 - 4); /*0x1031246b8*/
        goto LABEL_8; /*0x1031246b8*/
      }
      if ( v12 == 1 ) /*0x1031246b4*/
        break; /*0x1031246b4*/
LABEL_8:
      v13 = v6 + v11++ + 1; /*0x1031246bd*/
      if ( v13 == 1 ) /*0x1031246cb*/
      {
        if ( (v9 & 1) != 0 ) /*0x1031246ea*/
          goto LABEL_18; /*0x1031246ea*/
        goto LABEL_15; /*0x1031246ea*/
      }
    }
    v7 = *(_DWORD *)(a2 + 8 * v11 - 4); /*0x1031246cf*/
    if ( v8 >= v7 ) /*0x1031246d7*/
      v8 = *(_DWORD *)(a2 + 8 * v11 - 4); /*0x1031246d7*/
    v9 = 0; /*0x1031246db*/
    if ( v11 + v6 != 0 ) /*0x1031246e3*/
      continue; /*0x1031246e3*/
    break;
  }
LABEL_15:
  if ( v8 < v7 ) /*0x1031246ef*/
  {
    result = nghttp2_hd_inflate_change_table_size(a1: a1 + 1904, a2: v8); /*0x1031246fa*/
    if ( (_DWORD)result != 0 ) /*0x103124701*/
      return result; /*0x103124701*/
  }
  result = nghttp2_hd_inflate_change_table_size(a1: a1 + 1904, a2: v7); /*0x103124711*/
  if ( (_DWORD)result != 0 ) /*0x103124718*/
    return result; /*0x103124718*/
LABEL_18:
  if ( v10 == -1 /*0x10312474a*/
    || (v15 = *(_DWORD *)(a1 + 2704),
        v26[0] = a1,
        v26[1] = __PAIR64__(v15, v10),
        (_DWORD)(result = nghttp2_map_each(
                            (_QWORD *)a1,
                            a2: (__int64 (__fastcall *)(_QWORD, __int64))update_local_initial_window_size_func,
                            a3: (__int64)v26)) == 0) )
  {
    v16 = (_DWORD *)(a1 + 2720); /*0x103124750*/
    v17 = (_DWORD *)(a1 + 2716); /*0x103124757*/
    v18 = (_DWORD *)(a1 + 2712); /*0x10312475e*/
    v19 = (_DWORD *)(a1 + 2708); /*0x103124765*/
    v20 = (_DWORD *)(a1 + 2704); /*0x10312476c*/
    v21 = (_DWORD *)(a1 + 2700); /*0x103124773*/
    v22 = (_DWORD *)(a1 + 2696); /*0x10312477a*/
    v23 = (_DWORD *)(a1 + 2692); /*0x103124781*/
    v24 = 0; /*0x103124788*/
    do /*0x1031247dc*/
    {
      v25 = v23; /*0x1031247a6*/
      switch ( *(_DWORD *)(a2 + 8 * v24) ) /*0x1031247a9*/
      {
        case 1: /*0x1031247a9*/
          goto LABEL_29;
        case 2: /*0x1031247a9*/
          v25 = v22; /*0x1031247ac*/
          goto LABEL_29; /*0x1031247af*/
        case 3: /*0x1031247a9*/
          v25 = v21; /*0x1031247c0*/
          goto LABEL_29; /*0x1031247c3*/
        case 4: /*0x1031247a9*/
          v25 = v20; /*0x1031247c5*/
          goto LABEL_29; /*0x1031247c8*/
        case 5: /*0x1031247a9*/
          v25 = v19; /*0x1031247ca*/
          goto LABEL_29; /*0x1031247ca*/
        case 6: /*0x1031247a9*/
          v25 = v18; /*0x1031247b1*/
          goto LABEL_29; /*0x1031247b4*/
        case 8: /*0x1031247a9*/
          v25 = v17; /*0x1031247b6*/
          goto LABEL_29; /*0x1031247b9*/
        case 9: /*0x1031247a9*/
          v25 = v16; /*0x1031247bb*/
LABEL_29:
          *v25 = *(_DWORD *)(a2 + 8 * v24 + 4); /*0x1031247cd*/
          break; /*0x1031247d2*/
        default:
          break;
      }
      ++v24; /*0x1031247d6*/
    }
    while ( a3 != v24 ); /*0x1031247dc*/
    return 0; /*0x1031247de*/
  }
  return result; /*0x1031247ee*/
}

// Address: 0x103124818 | Name: _nghttp2_session_on_settings_received
__int64 __fastcall nghttp2_session_on_settings_received(__int64 a1, __int64 a2, int a3)
{
  const char *v5; // rcx
  __int64 v6; // rdx
  __int64 v8; // r12
  __int64 v9; // r15
  int v10; // eax
  unsigned int v11; // eax
  unsigned int v12; // eax
  unsigned int v13; // eax
  int v14; // ecx
  int v15; // eax
  unsigned int updated; // r13d
  int v17; // eax
  int v18; // eax
  __int64 v19; // rdi
  __int64 v20; // rsi
  __int64 v21; // rdx
  _QWORD *v22; // r15
  unsigned int (__fastcall *v23)(__int64, __int64, _QWORD); // rax
  const char *v24; // rcx
  __int64 v25; // [rsp+8h] [rbp-48h] BYREF
  int v26; // [rsp+10h] [rbp-40h]
  int v27; // [rsp+14h] [rbp-3Ch]
  __int64 v28; // [rsp+18h] [rbp-38h]
  int v29; // [rsp+24h] [rbp-2Ch]

  if ( *(_DWORD *)(a2 + 8) != 0 )
  {
    v5 = "SETTINGS: stream_id != 0";
LABEL_3:
    v6 = 4294966791LL; /*0x10312483c*/
    return session_handle_invalid_connection(a1, a2, a3: v6, a4: v5); /*0x103124855*/
  }
  if ( (*(_BYTE *)(a2 + 13) & 1) != 0 )
  {
    if ( *(_QWORD *)(a2 + 16) != 0 )
    {
      v5 = "SETTINGS: ACK and payload != 0";
      v6 = 4294966774LL; /*0x103124a98*/
      return session_handle_invalid_connection(a1, a2, a3: v6, a4: v5); /*0x103124a9d*/
    }
    v22 = *(_QWORD **)(a1 + 2424); /*0x103124aa2*/
    if ( v22 == nullptr )
    {
      v5 = "SETTINGS: unexpected ACK";
      goto LABEL_3; /*0x103124b47*/
    }
    updated = nghttp2_session_update_local_settings(a1, a2: v22[1], a3: v22[2]); /*0x103124ac9*/
    *(_QWORD *)(a1 + 2424) = *v22; /*0x103124acf*/
    nghttp2_mem_free(a1: a1 + 2376, a2: v22[1]); /*0x103124add*/
    nghttp2_mem_free(a1: a1 + 2376, a2: (__int64)v22); /*0x103124ae8*/
    if ( updated != 0 ) /*0x103124af0*/
    {
      if ( (int)updated < -900 ) /*0x103124af9*/
        return updated; /*0x103124af9*/
      return session_handle_invalid_connection(a1, a2, a3: updated, a4: 0); /*0x103124b0a*/
    }
LABEL_50:
    v23 = *(unsigned int (__fastcall **)(__int64, __int64, _QWORD))(a1 + 2176); /*0x103124b0f*/
    if ( v23 == nullptr ) /*0x103124b19*/
      return 0; /*0x103124b19*/
    updated = -902; /*0x103124b2a*/
    if ( v23(a1, a2, a3: *(_QWORD *)(a1 + 2416)) == 0 ) /*0x103124b32*/
      return 0; /*0x103124b38*/
    return updated; /*0x103124b3b*/
  }
  v29 = a3; /*0x103124864*/
  if ( *(_BYTE *)(a1 + 2656) == 0 ) /*0x10312486f*/
  {
    *(_DWORD *)(a1 + 2668) = -1; /*0x103124871*/
    *(_BYTE *)(a1 + 2656) = 1; /*0x10312487c*/
  }
  if ( *(_QWORD *)(a2 + 16) == 0 ) /*0x103124889*/
  {
LABEL_37:
    if ( *(_DWORD *)(a1 + 2688) == -1 ) /*0x103124a26*/
      *(_DWORD *)(a1 + 2688) = 0; /*0x103124a28*/
    if ( v29 == 0 && (unsigned int)session_is_closing(a1) == 0 ) /*0x103124a47*/
    {
      v18 = nghttp2_session_add_settings(a1, a2: 1, a3: 0, a4: 0); /*0x103124a59*/
      if ( v18 != 0 ) /*0x103124a60*/
      {
        updated = v18; /*0x103124a66*/
        if ( v18 >= -900 ) /*0x103124a6e*/
        {
          v19 = a1; /*0x103124a74*/
          v20 = a2; /*0x103124a77*/
          v21 = 4294966762LL; /*0x103124a7a*/
          goto LABEL_64; /*0x103124a7f*/
        }
        return updated; /*0x103124a6e*/
      }
    }
    goto LABEL_50; /*0x103124a60*/
  }
  v28 = a1 + 792; /*0x103124896*/
  v8 = 0; /*0x10312489a*/
  while ( 1 )
  {
    v9 = *(_QWORD *)(a2 + 24); /*0x1031248a4*/
    switch ( *(_DWORD *)(v9 + 8 * v8) )
    {
      case 1:
        v10 = nghttp2_hd_deflate_change_table_size(a1: v28, a2: *(unsigned int *)(v9 + 8 * v8 + 4)); /*0x1031248c9*/
        if ( v10 == 0 ) /*0x1031248d0*/
        {
          *(_DWORD *)(a1 + 2660) = *(_DWORD *)(v9 + 8 * v8 + 4); /*0x1031248db*/
          break; /*0x1031248e2*/
        }
        updated = v10; /*0x103124b4c*/
        if ( v10 >= -900 ) /*0x103124b54*/
        {
          v19 = a1; /*0x103124b5a*/
          v20 = a2; /*0x103124b5d*/
          v21 = 4294966773LL; /*0x103124b60*/
          goto LABEL_64; /*0x103124b65*/
        }
        return updated; /*0x103124b54*/
      case 2:
        v11 = *(_DWORD *)(v9 + 8 * v8 + 4); /*0x1031248f8*/
        if ( v11 >= 2 )
        {
          v24 = "SETTINGS: invalid SETTINGS_ENBLE_PUSH";
        }
        else
        {
          if ( v11 == 0 || *(_BYTE *)(a1 + 2739) != 0 ) /*0x103124912*/
          {
            *(_DWORD *)(a1 + 2664) = v11; /*0x103124918*/
            break; /*0x10312491f*/
          }
          v24 = "SETTINGS: server attempted to enable push";
        }
        goto LABEL_66; /*0x103124ba6*/
      case 3:
        *(_DWORD *)(a1 + 2668) = *(_DWORD *)(v9 + 8 * v8 + 4); /*0x10312498d*/
        break; /*0x103124994*/
      case 4:
        v15 = *(_DWORD *)(v9 + 8 * v8 + 4); /*0x103124996*/
        if ( v15 < 0 )
        {
          v24 = "SETTINGS: too large SETTINGS_INITIAL_WINDOW_SIZE";
          v19 = a1; /*0x103124b80*/
          v20 = a2; /*0x103124b83*/
          v21 = 4294966772LL; /*0x103124b86*/
          return (unsigned int)session_handle_invalid_connection(a1: v19, a2: v20, a3: v21, a4: v24); /*0x103124b8b*/
        }
        v25 = a1; /*0x1031249a3*/
        v26 = v15; /*0x1031249a7*/
        v27 = *(_DWORD *)(a1 + 2672); /*0x1031249b1*/
        updated = nghttp2_map_each( /*0x1031249c7*/
                    (_QWORD *)a1,
                    a2: (__int64 (__fastcall *)(_QWORD, __int64))update_remote_initial_window_size_func,
                    a3: (__int64)&v25);
        if ( (int)updated < -900 ) /*0x1031249cf*/
          return updated; /*0x1031249cf*/
        if ( updated == 0 ) /*0x1031249d8*/
        {
          *(_DWORD *)(a1 + 2672) = *(_DWORD *)(v9 + 8 * v8 + 4); /*0x1031249e3*/
          break; /*0x1031249e3*/
        }
        v19 = a1; /*0x103124bb1*/
        v20 = a2; /*0x103124bb4*/
        v21 = 4294966772LL; /*0x103124bb7*/
LABEL_64:
        v24 = nullptr; /*0x103124bbc*/
        return (unsigned int)session_handle_invalid_connection(a1: v19, a2: v20, a3: v21, a4: v24); /*0x103124847*/
      case 5:
        v17 = *(_DWORD *)(v9 + 8 * v8 + 4); /*0x1031249f3*/
        if ( (unsigned int)(v17 - 0x1000000) <= 0xFF003FFF )
        {
          v24 = "SETTINGS: invalid SETTINGS_MAX_FRAME_SIZE";
          goto LABEL_66; /*0x103124b9d*/
        }
        *(_DWORD *)(a1 + 2676) = v17; /*0x103124a0a*/
        break; /*0x103124a0a*/
      case 6:
        *(_DWORD *)(a1 + 2680) = *(_DWORD *)(v9 + 8 * v8 + 4); /*0x1031248ec*/
        break; /*0x1031248f3*/
      case 8:
        v12 = *(_DWORD *)(v9 + 8 * v8 + 4); /*0x103124924*/
        if ( v12 >= 2 )
        {
          v24 = "SETTINGS: invalid SETTINGS_ENABLE_CONNECT_PROTOCOL";
LABEL_66:
          v19 = a1; /*0x103124bc7*/
          v20 = a2; /*0x103124bca*/
          v21 = 4294966791LL; /*0x103124bcd*/
          return (unsigned int)session_handle_invalid_connection(a1: v19, a2: v20, a3: v21, a4: v24); /*0x103124bcd*/
        }
        if ( *(_BYTE *)(a1 + 2739) == 0 && v12 == 0 && *(_DWORD *)(a1 + 2684) != 0 )
        {
          v24 = "SETTINGS: server attempted to disable SETTINGS_ENABLE_CONNECT_PROTOCOL";
          goto LABEL_66; /*0x103124bc0*/
        }
        *(_DWORD *)(a1 + 2684) = v12; /*0x10312494e*/
        break; /*0x103124955*/
      case 9:
        v13 = *(_DWORD *)(v9 + 8 * v8 + 4); /*0x10312495a*/
        if ( v13 >= 2 )
        {
          v24 = "SETTINGS: invalid SETTINGS_NO_RFC7540_PRIORITIES";
          goto LABEL_66; /*0x103124b77*/
        }
        v14 = *(_DWORD *)(a1 + 2688); /*0x103124968*/
        if ( v14 != -1 && v14 != v13 )
        {
          v24 = "SETTINGS: SETTINGS_NO_RFC7540_PRIORITIES cannot be changed";
          goto LABEL_66; /*0x103124baf*/
        }
        *(_DWORD *)(a1 + 2688) = v13; /*0x10312497c*/
        break; /*0x103124983*/
      default:
        break;
    }
    if ( (unsigned __int64)++v8 >= *(_QWORD *)(a2 + 16) ) /*0x103124a18*/
      goto LABEL_37; /*0x103124a18*/
  }
}

// Address: 0x103124c10 | Name: _nghttp2_session_add_settings
__int64 __fastcall nghttp2_session_add_settings(__int64 a1, char a2, _BYTE *a3, __int64 a4)
{
  __int64 v4; // r14
  unsigned __int8 v6; // bl
  char v7; // r13
  __int64 v8; // r12
  int v9; // eax
  unsigned int v10; // r8d
  __int64 i; // rax
  int v12; // eax
  __int64 v13; // r12
  __int64 v14; // rax
  __int64 v15; // rcx
  void *v16; // rcx
  __int64 v17; // r12
  __int64 v18; // r13
  __int64 v19; // rax
  __int64 v20; // rcx
  _QWORD *v21; // r12
  __int64 v22; // rdi
  __int64 v23; // rsi
  void *v24; // rax
  bool v25; // zf
  __int64 v26; // r12
  unsigned int v27; // eax
  unsigned int v28; // ebx
  __int64 v29; // rdx
  __int64 *v30; // rax
  __int64 *v31; // rcx
  __int64 v32; // rax
  __int64 v33; // rax
  unsigned __int8 v34; // al
  __int64 v36; // [rsp+8h] [rbp-58h]
  __int64 v37; // [rsp+10h] [rbp-50h]
  char v38; // [rsp+1Ch] [rbp-44h]
  __int64 v39; // [rsp+20h] [rbp-40h]
  __int64 v40; // [rsp+28h] [rbp-38h]
  __int64 v41; // [rsp+28h] [rbp-38h]
  bool v42; // [rsp+37h] [rbp-29h]

  v4 = a4; /*0x103124c21*/
  v6 = *(_BYTE *)(a1 + 2738); /*0x103124c27*/
  if ( (a2 & 1) != 0 ) /*0x103124c31*/
  {
    v10 = -501; /*0x103124c87*/
    if ( a4 != 0 ) /*0x103124c90*/
      return v10; /*0x103124c90*/
    v10 = -904; /*0x103124c9d*/
    if ( *(_QWORD *)(a1 + 2560) >= *(_QWORD *)(a1 + 2568) ) /*0x103124caa*/
      return v10; /*0x103124caa*/
    v7 = a2; /*0x103124cb0*/
    v8 = a1; /*0x103124cb3*/
    v12 = nghttp2_iv_check(a1: (__int64)a3, a2: 0); /*0x103124cbc*/
    v42 = true; /*0x103124cc1*/
    v10 = -501; /*0x103124cc5*/
    if ( v12 == 0 ) /*0x103124ccd*/
      return v10; /*0x103124ccd*/
  }
  else
  {
    v7 = a2; /*0x103124c33*/
    v8 = a1; /*0x103124c36*/
    v9 = nghttp2_iv_check(a1: (__int64)a3, a2: a4); /*0x103124c3f*/
    v10 = -501; /*0x103124c44*/
    if ( v9 == 0 ) /*0x103124c4c*/
      return v10; /*0x103124c4c*/
    v42 = v4 == 0; /*0x103124c55*/
    if ( v4 != 0 ) /*0x103124c59*/
    {
      for ( i = 0; i != v4; ++i ) /*0x103124c5b*/
      {
        if ( *(_DWORD *)&a3[8 * i] == 9 ) /*0x103124c62*/
        {
          if ( v6 == 0xFF ) /*0x103124c67*/
          {
            v6 = a3[8 * i + 4]; /*0x103124c78*/
          }
          else if ( *(_DWORD *)&a3[8 * i + 4] != v6 ) /*0x103124c71*/
          {
            return v10; /*0x103124c71*/
          }
        }
      }
    }
    else
    {
      v42 = true; /*0x103124cd4*/
    }
  }
  v37 = v8; /*0x103124cd8*/
  v13 = v8 + 2376; /*0x103124cdc*/
  v14 = nghttp2_mem_malloc(a1: v13, a2: 160); /*0x103124ceb*/
  v10 = -901; /*0x103124cf0*/
  if ( v14 == 0 ) /*0x103124cf9*/
    return v10; /*0x103124cf9*/
  v39 = v13; /*0x103124cff*/
  if ( v42 ) /*0x103124d07*/
  {
    v16 = nullptr; /*0x103124d09*/
  }
  else
  {
    v17 = v14; /*0x103124d17*/
    v16 = nghttp2_frame_iv_copy(__src: a3, a2: v4, a3: v39, a4: v15); /*0x103124d1f*/
    v14 = v17; /*0x103124d22*/
    if ( v16 == nullptr ) /*0x103124d28*/
    {
      v22 = v39; /*0x103124d7c*/
      v23 = v17; /*0x103124d80*/
LABEL_56:
      nghttp2_mem_free(a1: v22, a2: v23); /*0x103124edd*/
      return (unsigned int)-901; /*0x103124ee2*/
    }
  }
  v36 = (__int64)v16; /*0x103124d2a*/
  if ( (v7 & 1) != 0 ) /*0x103124d32*/
  {
    v41 = 0; /*0x103124d72*/
    goto LABEL_29; /*0x103124d7a*/
  }
  v40 = v14; /*0x103124d34*/
  v38 = v7; /*0x103124d38*/
  v18 = v39; /*0x103124d41*/
  v19 = nghttp2_mem_malloc(a1: v39, a2: 24); /*0x103124d48*/
  if ( v19 == 0 ) /*0x103124d50*/
  {
LABEL_55:
    nghttp2_mem_free(a1: v18, a2: v36); /*0x103124eca*/
    v22 = v18; /*0x103124ed6*/
    v23 = v40; /*0x103124ed9*/
    goto LABEL_56; /*0x103124ed9*/
  }
  v21 = (_QWORD *)v19; /*0x103124d56*/
  if ( !v42 ) /*0x103124d5d*/
  {
    v24 = nghttp2_frame_iv_copy(__src: a3, a2: v4, a3: v39, a4: v20); /*0x103124d92*/
    v21[1] = v24; /*0x103124d97*/
    v25 = v24 == nullptr; /*0x103124d9c*/
    v7 = v38; /*0x103124d9f*/
    v14 = v40; /*0x103124da3*/
    if ( !v25 ) /*0x103124da7*/
      goto LABEL_28; /*0x103124da7*/
    v18 = v39; /*0x103124ebb*/
    nghttp2_mem_free(a1: v39, a2: (__int64)v21); /*0x103124ec5*/
    goto LABEL_55; /*0x103124ec5*/
  }
  *(_QWORD *)(v19 + 8) = 0; /*0x103124d5f*/
  v7 = v38; /*0x103124d68*/
  v14 = v40; /*0x103124d6c*/
LABEL_28:
  v21[2] = v4; /*0x103124dad*/
  v41 = (__int64)v21; /*0x103124db2*/
  *v21 = 0; /*0x103124db6*/
LABEL_29:
  v26 = v14; /*0x103124dbe*/
  nghttp2_outbound_item_init(a1: v14); /*0x103124dc4*/
  nghttp2_frame_settings_init(a1: v26, a2: v7, a3: v36, a4: v4); /*0x103124dd7*/
  v27 = nghttp2_session_add_item(a1: v37, a2: v26); /*0x103124de3*/
  if ( v27 != 0 ) /*0x103124dea*/
  {
    v28 = v27; /*0x103124df7*/
    inflight_settings_del(a1: v41, a2: v39); /*0x103124df9*/
    nghttp2_frame_settings_free(a1: v26, a2: v39); /*0x103124e04*/
    nghttp2_mem_free(a1: v39, a2: v26); /*0x103124e0f*/
    return v28; /*0x103124e14*/
  }
  else
  {
    if ( (v7 & 1) != 0 ) /*0x103124e20*/
    {
      v29 = v37; /*0x103124e41*/
      ++*(_QWORD *)(v37 + 2560); /*0x103124e45*/
    }
    else
    {
      v29 = v37; /*0x103124e22*/
      v30 = (__int64 *)(v37 + 2424); /*0x103124e26*/
      do /*0x103124e36*/
      {
        v31 = v30; /*0x103124e2d*/
        v30 = (__int64 *)*v30; /*0x103124e30*/
      }
      while ( v30 != nullptr ); /*0x103124e36*/
      *v31 = v41; /*0x103124e3c*/
    }
    if ( !v42 ) /*0x103124e50*/
    {
      v32 = v4; /*0x103124e52*/
      while ( *(_DWORD *)&a3[8 * v32 - 8] != 3 ) /*0x103124e5b*/
      {
        if ( --v32 == 0 ) /*0x103124e60*/
          goto LABEL_42; /*0x103124e60*/
      }
      *(_DWORD *)(v29 + 2728) = *(_DWORD *)&a3[8 * v32 - 4]; /*0x103124e69*/
LABEL_42:
      v33 = v4; /*0x103124e6f*/
      do /*0x103124e7d*/
      {
        if ( *(_DWORD *)&a3[8 * v33 - 8] == 2 ) /*0x103124e78*/
        {
          *(_BYTE *)(v29 + 2736) = a3[8 * v33 - 4]; /*0x103124e86*/
          break; /*0x103124e86*/
        }
        --v33; /*0x103124e7a*/
      }
      while ( v33 != 0 ); /*0x103124e7d*/
      while ( *(_DWORD *)&a3[8 * v4 - 8] != 8 ) /*0x103124e92*/
      {
        if ( --v4 == 0 ) /*0x103124e97*/
          goto LABEL_51; /*0x103124e97*/
      }
      *(_BYTE *)(v29 + 2737) = a3[8 * v4 - 4]; /*0x103124ea0*/
    }
LABEL_51:
    v10 = 0; /*0x103124ea6*/
    v34 = v6; /*0x103124eac*/
    if ( v6 == 0xFF ) /*0x103124eaf*/
      v34 = 0; /*0x103124eaf*/
    *(_BYTE *)(v29 + 2738) = v34; /*0x103124eb3*/
  }
  return v10; /*0x103124eeb*/
}

// Address: 0x103124efa | Name: _nghttp2_session_on_push_promise_received
__int64 __fastcall nghttp2_session_on_push_promise_received(__int64 a1, __int64 a2)
{
  __int64 v2; // rbx
  __int64 v3; // r14
  int v4; // eax
  const char *v5; // rcx
  __int64 v6; // rdx
  int v7; // eax
  unsigned int v8; // r15d
  int v10; // ecx
  __int64 stream; // rax
  __int64 (__fastcall *v12)(__int64, __int64, _QWORD); // rax
  int v13; // eax
  unsigned int v14; // eax

  v2 = a2; /*0x103124f04*/
  v3 = a1; /*0x103124f07*/
  v4 = *(_DWORD *)(a2 + 8); /*0x103124f0a*/
  if ( v4 == 0 )
  {
    v5 = "PUSH_PROMISE: stream_id == 0";
    goto LABEL_5; /*0x103124f24*/
  }
  if ( *(_BYTE *)(a1 + 2739) != 0 || *(_DWORD *)(a1 + 2696) == 0 )
  {
    v5 = "PUSH_PROMISE: push disabled";
LABEL_5:
    v6 = 4294966791LL; /*0x103124f2b*/
    goto LABEL_6; /*0x103124f31*/
  }
  if ( (v4 & 1) == 0 )
  {
    v5 = "PUSH_PROMISE: invalid stream_id";
    goto LABEL_5; /*0x103124f6d*/
  }
  v8 = -103; /*0x103124f6f*/
  if ( (*(_BYTE *)(a1 + 2740) & 5) != 0 ) /*0x103124f7d*/
    return v8; /*0x103124f7d*/
  v10 = *(_DWORD *)(a2 + 40); /*0x103124f7f*/
  if ( (v10 != 0) == (v10 & 1) || *(_DWORD *)(a1 + 2616) >= v10 )
  {
    v5 = "PUSH_PROMISE: invalid promised_stream_id";
    goto LABEL_5; /*0x103124fb7*/
  }
  if ( *(_DWORD *)(a1 + 2612) < v4 )
  {
    v5 = "PUSH_PROMISE: stream in idle";
    goto LABEL_5; /*0x103124fab*/
  }
  *(_DWORD *)(a1 + 2616) = v10; /*0x103124fbc*/
  stream = nghttp2_session_get_stream(a1, a2: *(_DWORD *)(a2 + 8)); /*0x103124fc9*/
  if ( stream != 0
    && *(_DWORD *)stream != 3
    && *(_BYTE *)(v3 + 2736) != 0
    && *(_QWORD *)(v3 + 2520) < *(_QWORD *)(v3 + 2528) )
  {
    if ( (*(_BYTE *)(stream + 117) & 1) != 0 )
    {
      v5 = "PUSH_PROMISE: stream closed";
      a1 = v3; /*0x10312509a*/
      a2 = v2; /*0x10312509d*/
      v6 = 4294966786LL; /*0x1031250a0*/
LABEL_6:
      v7 = session_handle_invalid_connection(a1, a2, a3: v6, a4: v5); /*0x103124f36*/
      v8 = -103; /*0x103124f40*/
      if ( v7 < -900 ) /*0x103124f46*/
        return (unsigned int)v7; /*0x103124f46*/
      return v8; /*0x103124f46*/
    }
    v8 = 0; /*0x10312500b*/
    if ( nghttp2_session_open_stream(a1: v3, a2: *(_DWORD *)(v2 + 40), a3: 0, a4: 4, a5: 0) != 0 ) /*0x103125023*/
    {
      *(_DWORD *)(v3 + 2620) = *(_DWORD *)(v3 + 2616); /*0x103125030*/
      v12 = *(__int64 (__fastcall **)(__int64, __int64, _QWORD))(v3 + 2232); /*0x103125037*/
      if ( v12 != nullptr ) /*0x103125041*/
      {
        v13 = v12(a1: v3, a2: v2, a3: *(_QWORD *)(v3 + 2416)); /*0x103125054*/
        v8 = -902; /*0x103125058*/
        if ( v13 == 0 ) /*0x10312505e*/
          v8 = 0; /*0x10312505e*/
        if ( v13 == -521 ) /*0x103125067*/
          return (unsigned int)-521; /*0x103125067*/
      }
    }
    else
    {
      return (unsigned int)-901; /*0x1031250aa*/
    }
  }
  else
  {
    v14 = session_handle_invalid_stream2(a1: v3, a2: *(unsigned int *)(v2 + 40), a3: 0, a4: 4294967189LL); /*0x10312507d*/
    v8 = -103; /*0x103125084*/
    if ( v14 != 0 ) /*0x10312508a*/
      return v14; /*0x10312508a*/
  }
  return v8; /*0x103124f51*/
}

// Address: 0x103125120 | Name: _nghttp2_session_on_ping_received
__int64 __fastcall nghttp2_session_on_ping_received(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  __int64 (__fastcall *v5)(__int64, __int64, _QWORD); // rax
  int v6; // ecx

  if ( *(_DWORD *)(a2 + 8) != 0 )
    return session_handle_invalid_connection(a1, a2, a3: 4294966791LL, a4: "PING: stream_id != 0");
  if ( (*(_BYTE *)(a1 + 2724) & 8) != 0 /*0x1031251aa*/
    || (*(_BYTE *)(a2 + 13) & 1) != 0
    || (unsigned int)session_is_closing(a1) != 0
    || (_DWORD)(result = nghttp2_session_add_ping(a1, a2: 1, a3: a2 + 16)) == 0 )
  {
    v5 = *(__int64 (__fastcall **)(__int64, __int64, _QWORD))(a1 + 2176); /*0x10312516a*/
    if ( v5 == nullptr ) /*0x103125174*/
      return 0; /*0x103125174*/
    v6 = v5(a1, a2, a3: *(_QWORD *)(a1 + 2416)); /*0x103125185*/
    result = 4294966394LL; /*0x103125187*/
    if ( v6 == 0 ) /*0x10312518e*/
      return 0; /*0x103125190*/
  }
  return result; /*0x103125145*/
}

// Address: 0x1031251ae | Name: _nghttp2_session_add_ping
__int64 __fastcall nghttp2_session_add_ping(__int64 a1, char a2, __int64 *a3)
{
  unsigned int v5; // r12d
  __int64 v7; // rax
  __int64 v8; // r13
  unsigned int v9; // eax

  if ( (a2 & 1) == 0 || (v5 = -904, *(_QWORD *)(a1 + 2560) < *(_QWORD *)(a1 + 2568)) ) /*0x1031251dc*/
  {
    v7 = nghttp2_mem_malloc(a1: a1 + 2376, a2: 160); /*0x1031251f0*/
    if ( v7 != 0 ) /*0x1031251f8*/
    {
      v8 = v7; /*0x1031251fa*/
      nghttp2_outbound_item_init(a1: v7); /*0x103125200*/
      nghttp2_frame_ping_init(a1: v8, a2, a3); /*0x10312520f*/
      v9 = nghttp2_session_add_item(a1, a2: v8); /*0x10312521a*/
      if ( v9 != 0 ) /*0x103125221*/
      {
        v5 = v9; /*0x103125223*/
        nghttp2_frame_ping_free(); /*0x103125229*/
        nghttp2_mem_free(a1: a1 + 2376, a2: v8); /*0x103125234*/
      }
      else
      {
        v5 = 0; /*0x103125243*/
        if ( (a2 & 1) != 0 ) /*0x10312524a*/
          ++*(_QWORD *)(a1 + 2560); /*0x10312524c*/
      }
    }
    else
    {
      return (unsigned int)-901; /*0x10312523b*/
    }
  }
  return v5; /*0x10312525a*/
}

// Address: 0x103125265 | Name: _nghttp2_session_on_goaway_received
__int64 __fastcall nghttp2_session_on_goaway_received(__int64 a1, __int64 a2)
{
  const char *v4; // rcx
  int v5; // eax
  __int64 v7; // rsi
  unsigned int (__fastcall *v8)(__int64, __int64, _QWORD); // rax

  if ( *(_DWORD *)(a2 + 8) != 0 )
  {
    v4 = "GOAWAY: stream_id != 0";
    return session_handle_invalid_connection(a1, a2, a3: 4294966791LL, a4: v4); /*0x1031252b8*/
  }
  v5 = *(_DWORD *)(a2 + 16); /*0x103125281*/
  if ( v5 > 0 && (((unsigned __int8)v5 ^ (*(_BYTE *)(a1 + 2739) == 0)) & 1) != 0 || *(_DWORD *)(a1 + 2632) < v5 )
  {
    v4 = "GOAWAY: invalid last_stream_id";
    return session_handle_invalid_connection(a1, a2, a3: 4294966791LL, a4: v4); /*0x1031252a2*/
  }
  *(_BYTE *)(a1 + 2740) |= 8u; /*0x1031252bd*/
  v7 = *(unsigned int *)(a2 + 16); /*0x1031252c4*/
  *(_DWORD *)(a1 + 2632) = v7; /*0x1031252c8*/
  v8 = *(unsigned int (__fastcall **)(__int64, __int64, _QWORD))(a1 + 2176); /*0x1031252ce*/
  if ( v8 != nullptr ) /*0x1031252d8*/
  {
    if ( v8(a1, a2, a3: *(_QWORD *)(a1 + 2416)) != 0 ) /*0x1031252eb*/
      return 4294966394LL; /*0x1031252f6*/
    v7 = *(unsigned int *)(a2 + 16); /*0x1031252f7*/
  }
  return session_close_stream_on_goaway(a1, a2: v7, a3: 0); /*0x1031252b4*/
}

// Address: 0x103125392 | Name: _nghttp2_session_on_window_update_received
__int64 __fastcall nghttp2_session_on_window_update_received(__int64 a1, __int64 a2)
{
  __int64 v3; // r14
  int v4; // esi
  __int64 v5; // r15
  __int64 result; // rax
  int v7; // eax
  const char *v8; // rcx
  int v9; // eax
  int v10; // ecx
  __int64 v11; // rsi
  __int64 v12; // rdx
  __int64 (__fastcall *v13)(__int64, __int64, _QWORD); // rax
  int v14; // ecx
  int v15; // eax
  int v16; // ecx

  v3 = a1; /*0x10312539f*/
  v4 = *(_DWORD *)(a2 + 8); /*0x1031253a2*/
  if ( v4 == 0 )
  {
    v9 = *(_DWORD *)(a2 + 16); /*0x103125430*/
    if ( v9 != 0 ) /*0x103125435*/
    {
      v10 = *(_DWORD *)(a1 + 2636); /*0x103125443*/
      if ( (v9 ^ 0x7FFFFFFF) < v10 ) /*0x10312544c*/
      {
        v11 = a2; /*0x103125451*/
        v12 = 4294966772LL; /*0x103125454*/
        v8 = nullptr; /*0x103125459*/
        return session_handle_invalid_connection(a1, a2: v11, a3: v12, a4: v8); /*0x1031254f9*/
      }
      *(_DWORD *)(a1 + 2636) = v9 + v10; /*0x103125478*/
      goto LABEL_17; /*0x103125478*/
    }
LABEL_24:
    v8 = "WINDOW_UPDATE: window_size_increment == 0";
    goto LABEL_25; /*0x1031254dd*/
  }
  if ( (*(_BYTE *)(a1 + 2739) == 0) == (v4 & 1) ) /*0x1031253be*/
  {
    if ( *(_DWORD *)(a1 + 2612) >= v4 ) /*0x103125467*/
      goto LABEL_4; /*0x103125467*/
LABEL_15:
    v8 = "WINDOW_UPDATE to idle stream"; /*0x10312546d*/
    goto LABEL_25; /*0x103125474*/
  }
  if ( *(_DWORD *)(a1 + 2616) < v4 ) /*0x1031253cb*/
    goto LABEL_15; /*0x1031253cb*/
LABEL_4:
  v5 = nghttp2_map_find(a1, a2: v4); /*0x1031253d1*/
  result = 0; /*0x1031253dc*/
  if ( v5 == 0 || (*(_BYTE *)(v5 + 116) & 2) != 0 || *(_DWORD *)v5 == 5 ) /*0x1031253f8*/
    return result; /*0x1031253f8*/
  if ( *(_DWORD *)v5 == 4 ) /*0x103125401*/
  {
    v7 = *(_DWORD *)(v5 + 80); /*0x103125407*/
    if ( v7 == 0 || (*(_BYTE *)(v3 + 2739) == 0) != (v7 & 1) ) /*0x10312541e*/
    {
      v8 = "WINDOW_UPADATE to reserved stream"; /*0x103125424*/
LABEL_25:
      a1 = v3; /*0x1031254e4*/
      v11 = a2; /*0x1031254e7*/
      v12 = 4294966791LL; /*0x1031254ea*/
      return session_handle_invalid_connection(a1, a2: v11, a3: v12, a4: v8); /*0x1031254ea*/
    }
  }
  v15 = *(_DWORD *)(a2 + 16); /*0x1031254b2*/
  if ( v15 == 0 ) /*0x1031254b7*/
    goto LABEL_24; /*0x1031254b7*/
  v16 = *(_DWORD *)(v5 + 84); /*0x1031254c1*/
  if ( (v15 ^ 0x7FFFFFFF) < v16 )
    return session_handle_invalid_connection(a1: v3, a2, a3: 4294966772LL, a4: "WINDOW_UPDATE: window size overflow");
  *(_DWORD *)(v5 + 84) = v15 + v16; /*0x103125500*/
  if ( (v15 + v16 < 0) ^ __OFADD__(v15, v16) | (v15 + v16 == 0) /*0x10312552f*/
    || (unsigned int)nghttp2_stream_check_deferred_by_flow_control(a1: v5) == 0
    || (int)(result = session_resume_deferred_stream_item(a1: v3, a2: v5, a3: 4)) >= -900 )
  {
LABEL_17:
    v13 = *(__int64 (__fastcall **)(__int64, __int64, _QWORD))(v3 + 2176); /*0x10312547f*/
    if ( v13 == nullptr ) /*0x103125489*/
      return 0; /*0x103125489*/
    v14 = v13(a1: v3, a2, a3: *(_QWORD *)(v3 + 2416)); /*0x10312549a*/
    result = 4294966394LL; /*0x10312549c*/
    if ( v14 == 0 ) /*0x1031254a3*/
      return 0; /*0x1031254a5*/
  }
  return result; /*0x1031254ab*/
}

// Address: 0x10312553a | Name: _nghttp2_session_on_altsvc_received
__int64 __fastcall nghttp2_session_on_altsvc_received(_QWORD *a1, __int64 a2)
{
  __int64 v4; // r15
  int v5; // esi
  __int64 v6; // rax
  __int64 v7; // rcx
  __int64 result; // rax
  int v9; // ecx
  __int64 (__fastcall *v10)(_QWORD *, __int64, _QWORD); // rax
  int v11; // eax
  __int64 (__fastcall *v12)(_QWORD *, __int64, __int64, _QWORD); // rax
  int v13; // ecx

  v4 = *(_QWORD *)(a2 + 16); /*0x10312554a*/
  v5 = *(_DWORD *)(a2 + 8); /*0x10312554e*/
  v6 = *(_QWORD *)(v4 + 8); /*0x103125551*/
  if ( v5 == 0 ) /*0x103125557*/
  {
    if ( v6 == 0 ) /*0x103125587*/
      goto LABEL_12; /*0x103125587*/
    goto LABEL_9; /*0x103125587*/
  }
  if ( v6 != 0 ) /*0x10312555c*/
    goto LABEL_12; /*0x10312555c*/
  v7 = nghttp2_map_find((__int64)a1, a2: v5); /*0x103125566*/
  result = 0; /*0x103125569*/
  if ( v7 != 0 && (*(_BYTE *)(v7 + 116) & 2) == 0 ) /*0x103125574*/
  {
    v9 = *(_DWORD *)v7; /*0x103125576*/
    if ( v9 != 3 && v9 != 5 ) /*0x103125580*/
    {
LABEL_9:
      if ( *(_QWORD *)(v4 + 24) != 0 ) /*0x10312558e*/
      {
        v10 = (__int64 (__fastcall *)(_QWORD *, __int64, _QWORD))a1[272]; /*0x103125590*/
        if ( v10 != nullptr ) /*0x10312559a*/
        {
          v11 = v10(a1, a2, a3: a1[302]); /*0x1031255a9*/
          goto LABEL_14; /*0x1031255ab*/
        }
        return 0; /*0x10312559a*/
      }
LABEL_12:
      v12 = (__int64 (__fastcall *)(_QWORD *, __int64, __int64, _QWORD))a1[273]; /*0x1031255ad*/
      if ( v12 != nullptr ) /*0x1031255b7*/
      {
        v11 = v12(a1, a2, a3: 4294966791LL, a4: a1[302]); /*0x1031255cb*/
LABEL_14:
        v13 = v11; /*0x1031255cd*/
        result = 4294966394LL; /*0x1031255cf*/
        if ( v13 != 0 ) /*0x1031255d6*/
          return result; /*0x1031255d6*/
      }
      return 0; /*0x1031255d8*/
    }
  }
  return result; /*0x1031255de*/
}

// Address: 0x1031255e5 | Name: _nghttp2_session_on_origin_received
__int64 __fastcall nghttp2_session_on_origin_received(__int64 a1, __int64 a2)
{
  __int64 (__fastcall *v2)(__int64, __int64, _QWORD); // rax
  int v3; // ecx
  __int64 result; // rax

  v2 = *(__int64 (__fastcall **)(__int64, __int64, _QWORD))(a1 + 2176); /*0x1031255e5*/
  if ( v2 == nullptr ) /*0x1031255ef*/
    return 0; /*0x1031255ef*/
  v3 = v2(a1, a2, a3: *(_QWORD *)(a1 + 2416)); /*0x1031255fe*/
  result = 4294966394LL; /*0x103125600*/
  if ( v3 == 0 ) /*0x103125608*/
    return 0; /*0x10312560b*/
  return result; /*0x10312560a*/
}

// Address: 0x10312560e | Name: _nghttp2_session_on_priority_update_received
__int64 __fastcall nghttp2_session_on_priority_update_received(__int64 a1, __int64 a2)
{
  const char *v4; // rcx
  __int64 result; // rax
  int *v6; // r12
  int v7; // esi
  __int64 v8; // rax
  __int64 v9; // r15
  unsigned __int8 v10; // al
  int v11; // esi
  __int64 (__fastcall *v12)(__int64, __int64, _QWORD); // rax
  int v13; // ecx
  int v14[10]; // [rsp+8h] [rbp-28h] BYREF

  if ( *(_DWORD *)(a2 + 8) != 0 )
  {
    v4 = "PRIORITY_UPDATE: stream_id == 0";
    return session_handle_invalid_connection(a1, a2, a3: 4294966791LL, a4: v4); /*0x103125647*/
  }
  v6 = *(int **)(a2 + 16); /*0x10312564c*/
  v7 = *v6; /*0x103125650*/
  if ( *v6 != 0 && (((unsigned __int8)v7 ^ (*(_BYTE *)(a1 + 2739) == 0)) & 1) == 0 )
  {
    if ( *(_DWORD *)(a1 + 2612) < v7 )
    {
      v4 = "PRIORITY_UPDATE: prioritizing idle push is not allowed";
      return session_handle_invalid_connection(a1, a2, a3: 4294966791LL, a4: v4); /*0x1031256ce*/
    }
    goto LABEL_16; /*0x1031256c5*/
  }
  v8 = nghttp2_map_find(a1, a2: v7); /*0x10312566d*/
  if ( v8 != 0 )
  {
    v9 = v8; /*0x103125677*/
    if ( (*(_BYTE *)(v8 + 116) & 0x20) == 0 ) /*0x10312567e*/
      goto LABEL_8; /*0x10312567e*/
  }
  else
  {
    v11 = *v6; /*0x1031256d3*/
    if ( *v6 != 0 )
    {
      if ( (*(_BYTE *)(a1 + 2739) == 0) == (v11 & 1) ) /*0x1031256ec*/
      {
        if ( *(_DWORD *)(a1 + 2612) >= v11 ) /*0x103125733*/
          goto LABEL_16; /*0x103125733*/
      }
      else if ( *(_DWORD *)(a1 + 2616) >= v11 ) /*0x1031256f5*/
      {
        goto LABEL_16; /*0x1031256f5*/
      }
      if ( *(_QWORD *)(a1 + 2544) + *(_QWORD *)(a1 + 2512) >= (unsigned __int64)*(unsigned int *)(a1 + 2700) )
      {
        v4 = "PRIORITY_UPDATE: max concurrent streams exceeded";
        return session_handle_invalid_connection(a1, a2, a3: 4294966791LL, a4: v4); /*0x10312577b*/
      }
      v9 = nghttp2_session_open_stream(a1, a2: v11, a3: 0, a4: 5, a5: 0); /*0x103125761*/
      if ( v9 == 0 ) /*0x103125767*/
        return 4294966395LL; /*0x103125772*/
LABEL_8:
      *(_QWORD *)v14 = 3; /*0x103125680*/
      if ( (unsigned int)nghttp2_http_parse_priority(a1: v14) == 0 ) /*0x10312569c*/
      {
        v10 = nghttp2_extpri_to_uint8(a1: (unsigned __int8 *)v14); /*0x1031256a2*/
        result = session_update_stream_priority(a1, a2: v9, a3: v10); /*0x1031256b0*/
        if ( (int)result < -900 ) /*0x1031256ba*/
          return result; /*0x1031256ba*/
      }
    }
  }
LABEL_16:
  v12 = *(__int64 (__fastcall **)(__int64, __int64, _QWORD))(a1 + 2176); /*0x1031256f7*/
  if ( v12 == nullptr ) /*0x103125701*/
    return 0; /*0x103125701*/
  v13 = v12(a1, a2, a3: *(_QWORD *)(a1 + 2416)); /*0x103125712*/
  result = 4294966394LL; /*0x103125714*/
  if ( v13 == 0 ) /*0x10312571b*/
    return 0; /*0x10312571d*/
  return result; /*0x10312563b*/
}

// Address: 0x1031257eb | Name: _nghttp2_session_on_data_received
__int64 __fastcall nghttp2_session_on_data_received(__int64 a1, __int64 a2)
{
  __int64 v4; // rax
  unsigned int v5; // r14d
  __int64 v6; // r15
  int v7; // eax
  unsigned int updated; // eax
  unsigned int (__fastcall *v9)(__int64, __int64, _QWORD); // rax

  v4 = nghttp2_map_find(a1, a2: *(_DWORD *)(a2 + 8)); /*0x1031257ff*/
  v5 = 0; /*0x103125804*/
  if ( v4 == 0 ) /*0x10312580a*/
    return v5; /*0x10312580a*/
  v6 = v4; /*0x103125810*/
  if ( (*(_BYTE *)(v4 + 116) & 2) != 0 ) /*0x103125817*/
    return v5; /*0x103125817*/
  v7 = *(_DWORD *)v4; /*0x10312581d*/
  if ( v7 == 3 || v7 == 5 ) /*0x10312582c*/
    return v5; /*0x10312582c*/
  if ( (*(_BYTE *)(a1 + 2724) & 4) != 0 /*0x10312584d*/
    || (*(_BYTE *)(a2 + 13) & 1) == 0
    || (unsigned int)nghttp2_http_on_remote_end_stream(a1: v6) == 0 )
  {
    v9 = *(unsigned int (__fastcall **)(__int64, __int64, _QWORD))(a1 + 2176); /*0x103125892*/
    if ( v9 != nullptr ) /*0x10312589c*/
    {
      v5 = -902; /*0x1031258ad*/
      if ( v9(a1, a2, a3: *(_QWORD *)(a1 + 2416)) != 0 ) /*0x1031258b5*/
        return v5; /*0x1031258b5*/
    }
    if ( (*(_BYTE *)(a2 + 13) & 1) == 0 ) /*0x1031258bd*/
      return 0; /*0x1031258bd*/
    nghttp2_stream_shutdown(a1: v6, a2: 1); /*0x1031258c7*/
    if ( (~*(_BYTE *)(v6 + 117) & 3) != 0 ) /*0x1031258d4*/
      return 0; /*0x1031258d4*/
    updated = nghttp2_session_close_stream(a1, a2: *(_DWORD *)(v6 + 80), a3: 0); /*0x1031258df*/
    if ( (int)updated >= -900 ) /*0x1031258e9*/
      return 0; /*0x1031258ee*/
    return updated; /*0x1031258f0*/
  }
  updated = session_handle_invalid_stream2(a1, a2: *(unsigned int *)(v6 + 80), a3: a2, a4: 4294966764LL); /*0x10312585e*/
  if ( (int)updated < -900 ) /*0x103125868*/
    return updated; /*0x103125868*/
  updated = session_update_glitch_ratelim(a1); /*0x103125871*/
  if ( updated != 0 ) /*0x103125878*/
    return updated; /*0x103125878*/
  if ( *(_DWORD *)(a1 + 752) != 15 ) /*0x103125881*/
    nghttp2_stream_shutdown(a1: v6, a2: 1); /*0x10312588b*/
  return v5; /*0x1031258f6*/
}

// Address: 0x10312595a | Name: _nghttp2_session_update_recv_stream_window_size
__int64 __fastcall nghttp2_session_update_recv_stream_window_size(__int64 a1, __int64 a2, int a3, int a4)
{
  int v6; // esi
  int v7; // edi
  int v9; // esi
  unsigned int v10; // r15d

  v6 = *(_DWORD *)(a2 + 88); /*0x10312596a*/
  v7 = *(_DWORD *)(a2 + 100); /*0x10312596d*/
  if ( v6 > v7 - a3 || v6 > (a3 ^ 0x7FFFFFFF) ) /*0x103125986*/
    return session_terminate_session(a1, a2: *(unsigned int *)(a1 + 2620), a3: 3, a4: 0); /*0x1031259ae*/
  v9 = a3 + v6; /*0x1031259b3*/
  *(_DWORD *)(a2 + 88) = v9; /*0x1031259b5*/
  v10 = 0; /*0x1031259b8*/
  if ( a4 != 0 /*0x1031259dd*/
    && (*(_BYTE *)(a1 + 2724) & 1) == 0
    && *(_BYTE *)(a2 + 119) == 0
    && nghttp2_should_send_window_update(a1: v7, a2: v9) )
  {
    v10 = nghttp2_session_add_window_update(a1, a2: 0, a3: *(unsigned int *)(a2 + 80), a4: *(unsigned int *)(a2 + 88)); /*0x1031259f6*/
    if ( v10 == 0 ) /*0x1031259fb*/
    {
      *(_DWORD *)(a2 + 88) = 0; /*0x1031259fd*/
      return 0; /*0x103125a04*/
    }
  }
  return v10; /*0x1031259a8*/
}

// Address: 0x103125a09 | Name: _nghttp2_session_add_window_update
__int64 __fastcall nghttp2_session_add_window_update(__int64 a1, char a2, int a3, int a4)
{
  __int64 v7; // rbx
  __int64 v8; // rax
  __int64 v9; // r14
  unsigned int v10; // eax
  unsigned int v11; // r15d

  v7 = a1 + 2376; /*0x103125a23*/
  v8 = nghttp2_mem_malloc(a1: a1 + 2376, a2: 160); /*0x103125a32*/
  if ( v8 != 0 ) /*0x103125a3a*/
  {
    v9 = v8; /*0x103125a3c*/
    nghttp2_outbound_item_init(a1: v8); /*0x103125a42*/
    nghttp2_frame_window_update_init(a1: v9, a2, a3, a4); /*0x103125a54*/
    v10 = nghttp2_session_add_item(a1, a2: v9); /*0x103125a5f*/
    if ( v10 != 0 ) /*0x103125a66*/
    {
      v11 = v10; /*0x103125a68*/
      nghttp2_frame_window_update_free(); /*0x103125a6e*/
      nghttp2_mem_free(a1: v7, a2: v9); /*0x103125a79*/
    }
    else
    {
      return 0; /*0x103125a88*/
    }
  }
  else
  {
    return (unsigned int)-901; /*0x103125a80*/
  }
  return v11; /*0x103125a92*/
}

// Address: 0x103125a9d | Name: _nghttp2_session_update_recv_connection_window_size
__int64 __fastcall nghttp2_session_update_recv_connection_window_size(__int64 a1, int a2)
{
  int v4; // esi
  int v5; // edi
  int v7; // esi
  unsigned int v8; // r14d

  v4 = *(_DWORD *)(a1 + 2640); /*0x103125aaa*/
  v5 = *(_DWORD *)(a1 + 2652); /*0x103125ab0*/
  if ( v4 > v5 - a2 || v4 > (a2 ^ 0x7FFFFFFF) ) /*0x103125ac9*/
    return session_terminate_session(a1, a2: *(unsigned int *)(a1 + 2620), a3: 3, a4: 0); /*0x103125ae7*/
  v7 = a2 + v4; /*0x103125aec*/
  *(_DWORD *)(a1 + 2640) = v7; /*0x103125aee*/
  v8 = 0; /*0x103125af4*/
  if ( (*(_BYTE *)(a1 + 2724) & 1) == 0 /*0x103125b11*/
    && *(_BYTE *)(a1 + 2741) == 0
    && nghttp2_should_send_window_update(a1: v5, a2: v7) )
  {
    v8 = nghttp2_session_add_window_update(a1, a2: 0, a3: 0, a4: *(_DWORD *)(a1 + 2640)); /*0x103125b2c*/
    if ( v8 == 0 ) /*0x103125b31*/
    {
      *(_DWORD *)(a1 + 2640) = 0; /*0x103125b33*/
      return 0; /*0x103125b3d*/
    }
  }
  return v8; /*0x103125ae3*/
}

// Address: 0x103125b42 | Name: _nghttp2_session_mem_recv
__int64 nghttp2_session_mem_recv()
{
  return nghttp2_session_mem_recv2(); /*0x103125b46*/
}

// Address: 0x103125b4c | Name: _nghttp2_session_mem_recv2
size_t __fastcall nghttp2_session_mem_recv2(__int64 a1, char *a2, size_t a3)
{
  char *v5; // r13
  char *v6; // r12
  char *v7; // r10
  __int64 v8; // r11
  _QWORD *v9; // kr00_8
  unsigned __int64 v10; // r13
  unsigned __int64 v11; // rbx
  unsigned __int64 v12; // rbx
  __int64 *v13; // r15
  unsigned __int64 v14; // rax
  __int64 v15; // rdx
  bool v16; // bl
  __int64 v17; // r12
  __int64 v18; // rax
  unsigned __int64 v19; // rcx
  int v20; // ebx
  unsigned __int64 v21; // rax
  char *v22; // rdi
  size_t v23; // rbx
  char *v24; // rax
  __int64 v25; // rcx
  __int64 v26; // rax
  unsigned int (__fastcall *v27)(__int64, __int64 *, _QWORD); // rax
  char *v28; // r15
  __int64 v29; // r13
  bool v30; // zf
  unsigned __int64 v31; // r12
  unsigned __int64 v32; // rax
  unsigned __int64 v33; // rax
  char *v34; // r15
  __int64 (__fastcall *v35)(__int64, __int64 *, char *, unsigned __int64, _QWORD); // r9
  int v36; // eax
  __int64 v37; // rbx
  unsigned __int64 v38; // rax
  __int64 v39; // rax
  char *v40; // r15
  __int64 v41; // r13
  int updated; // eax
  unsigned __int64 v43; // rax
  unsigned __int64 v44; // rcx
  unsigned __int64 v45; // rdx
  unsigned int v46; // eax
  int v47; // ecx
  __int64 v48; // rdi
  __int64 v49; // rax
  __int64 v50; // rbx
  char *v51; // rdi
  size_t v52; // rbx
  char *v53; // rax
  __int64 v54; // rdi
  char *v55; // r15
  __int64 v56; // r13
  __int64 v57; // rax
  _BOOL4 v58; // ecx
  int v59; // edx
  __int64 v60; // rbx
  unsigned __int64 v61; // rax
  unsigned __int64 v62; // rcx
  unsigned __int64 v63; // rcx
  __int64 v64; // rbx
  size_t v65; // rbx
  size_t v66; // rax
  char *v67; // rax
  char *v68; // r15
  __int64 *v69; // rbx
  __int64 v70; // r13
  size_t v71; // rbx
  size_t v72; // rax
  char *v73; // rax
  unsigned __int16 v74; // ax
  __int64 *v75; // rbx
  char *v76; // rdi
  size_t v77; // rbx
  char *v78; // rax
  char *v79; // rdx
  size_t v80; // rcx
  char *v81; // rbx
  __int64 v82; // rax
  __int64 v83; // rsi
  __int64 v84; // rcx
  size_t v85; // r12
  char *v86; // rdi
  size_t v87; // rbx
  char *v88; // rax
  __int64 v89; // rdi
  __int64 v90; // rcx
  char *v91; // rbx
  __int64 v92; // r14
  size_t v93; // r15
  size_t v94; // r12
  size_t v95; // rbx
  char *v96; // r14
  __int64 v97; // r13
  char *v98; // r15
  size_t v99; // rbx
  char *v100; // rax
  char *v101; // rbx
  __int64 v102; // rax
  unsigned __int64 v103; // rsi
  unsigned int v104; // eax
  char *v105; // rdi
  size_t v106; // rbx
  char *v107; // rax
  __int64 v108; // rsi
  char *v109; // rdx
  size_t v110; // rcx
  __int64 v111; // rdx
  char *v112; // rbx
  size_t v113; // rbx
  size_t v114; // rax
  char *v115; // rax
  __int64 v116; // rbx
  __int64 v117; // rax
  _DWORD *v118; // rdx
  char v119; // al
  _DWORD *v120; // rax
  char *v121; // rcx
  int v122; // eax
  __int64 v123; // rax
  __int64 v124; // r15
  int v125; // eax
  __int64 v126; // rax
  int v127; // eax
  __int64 v128; // rbx
  __int64 v129; // rbx
  char v130; // cl
  unsigned __int64 v131; // rax
  __int64 v132; // rdx
  __int64 v133; // rsi
  unsigned __int64 v134; // rbx
  char v135; // al
  char v136; // al
  unsigned int v137; // r15d
  int v138; // eax
  int v139; // ecx
  __int64 v140; // r15
  unsigned __int64 v141; // rax
  unsigned __int64 v142; // rax
  char *v143; // r13
  __int64 v144; // r12
  _BOOL4 v145; // ecx
  __int64 v146; // rax
  unsigned __int64 v147; // r12
  unsigned __int64 v148; // rax
  __int64 v149; // rdx
  __int64 v150; // r13
  bool v151; // cc
  __int64 v152; // r15
  __int64 v153; // rdx
  __int64 v154; // r15
  _QWORD *v155; // rcx
  int v156; // eax
  __int64 v157; // rbx
  __int64 v158; // rbx
  __int64 v159; // r15
  char *v160; // rbx
  char *v161; // rax
  char *v162; // r13
  _QWORD *v163; // r10
  _QWORD *v164; // rdi
  int v165; // eax
  __int64 (__fastcall *v166)(_QWORD *, __int64 *, __int64, __int64, _QWORD, _QWORD); // rax
  __int64 (__fastcall *v167)(_QWORD *, __int64 *, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  __int64 (__fastcall *v168)(__int64, __int64 *, __int64, __int64, _QWORD, _QWORD); // rax
  __int64 (__fastcall *v169)(__int64, __int64 *, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  int v170; // eax
  __int64 v171; // rdi
  int v172; // ecx
  unsigned __int64 v173; // r13
  __int64 v174; // rdx
  char *v175; // rbx
  __int64 v176; // r13
  __int64 (__fastcall *v177)(__int64, __int64 *, _QWORD); // rax
  int v178; // eax
  int v179; // eax
  __int64 v180; // rdi
  __int64 (__fastcall *v181)(__int64, __int64 *, _QWORD); // rax
  int v182; // eax
  __int64 *v183; // rbx
  __int64 v184; // rbx
  __int64 v185; // rax
  char v186; // al
  __int64 v187; // rax
  unsigned __int64 v188; // rbx
  unsigned __int64 v189; // rax
  unsigned __int64 v190; // rcx
  __int64 *v191; // rbx
  unsigned __int16 uint16; // ax
  __int64 *v193; // rbx
  __int64 v194; // r13
  __int64 v195; // rsi
  __int64 *v196; // rbx
  __int64 *v197; // rbx
  unsigned int (__fastcall *v198)(__int64, __int64 *, _QWORD); // rax
  char *v199; // r12
  __int64 v200; // r13
  char v201; // al
  char *v202; // r12
  __int64 v203; // r13
  unsigned __int64 v204; // rax
  __int64 v205; // rax
  __int64 v206; // rcx
  __int64 v207; // rax
  __int64 v208; // rcx
  __int64 v209; // rax
  __int64 v210; // rbx
  __int64 (__fastcall *v211)(__int64, _QWORD, _QWORD, _QWORD *, __int64, _QWORD); // rax
  __int64 v212; // rbx
  int v213; // eax
  __int64 v214; // rbx
  __int64 v215; // rdi
  __int64 (__fastcall *v216)(__int64, __int64 *, _QWORD); // rax
  int v217; // eax
  __int64 v218; // rbx
  __int64 v219; // rax
  __int64 v220; // rcx
  char *v221; // rbx
  __int64 v222; // rsi
  __int64 v223; // rax
  __int64 v224; // rax
  __int64 v225; // rcx
  __int64 v226; // rdi
  __int64 *v227; // rbx
  __int64 v228; // r12
  size_t v229; // rax
  __int64 v230; // rax
  __int64 v231; // rcx
  __int64 v232; // rbx
  __int64 v233; // rbx
  __int64 v234; // rbx
  __int64 v235; // rbx
  unsigned __int64 v236; // rbx
  __int64 v237; // rbx
  __int64 v238; // r13
  int v239; // eax
  int v240; // eax
  char *v241; // r12
  __int64 v242; // r13
  __int64 (__fastcall *v243)(__int64, __int64 *, _QWORD); // rax
  int v244; // eax
  __int64 v245; // rdi
  __int64 v246; // rdx
  __int64 v248; // rbx
  int v249; // eax
  __int64 v251; // rsi
  const char *v252; // rcx
  __int64 v253; // [rsp+8h] [rbp-E8h] BYREF
  int v254; // [rsp+10h] [rbp-E0h]
  char v255; // [rsp+14h] [rbp-DCh]
  char v256; // [rsp+15h] [rbp-DBh]
  __int64 v257; // [rsp+18h] [rbp-D8h]
  __int64 v258; // [rsp+20h] [rbp-D0h]
  __int64 v259; // [rsp+28h] [rbp-C8h]
  int v260; // [rsp+34h] [rbp-BCh]
  __int64 v261; // [rsp+38h] [rbp-B8h]
  __int64 *v262; // [rsp+40h] [rbp-B0h]
  char *v263; // [rsp+48h] [rbp-A8h]
  _QWORD *v264; // [rsp+50h] [rbp-A0h]
  __int64 v265; // [rsp+58h] [rbp-98h]
  _BOOL8 v266; // [rsp+60h] [rbp-90h]
  int v267; // [rsp+6Ch] [rbp-84h] BYREF
  unsigned __int64 v268; // [rsp+70h] [rbp-80h]
  __int64 v269; // [rsp+78h] [rbp-78h] BYREF
  __int64 v270; // [rsp+80h] [rbp-70h]
  unsigned __int8 v271; // [rsp+8Ch] [rbp-64h]
  _DWORD *v272; // [rsp+90h] [rbp-60h]
  char *v273; // [rsp+98h] [rbp-58h]
  __int64 *v274; // [rsp+A0h] [rbp-50h]
  char *v275; // [rsp+A8h] [rbp-48h]
  __int64 *v276; // [rsp+B0h] [rbp-40h]
  size_t __n; // [rsp+B8h] [rbp-38h]
  __int64 v278; // [rsp+C0h] [rbp-30h]

  v5 = (char *)&static_in; /*0x103125b69*/
  if ( a2 != nullptr ) /*0x103125b70*/
    v5 = a2; /*0x103125b70*/
  if ( (unsigned int)nghttp2_session_want_read(a1) == 0 ) /*0x103125b7b*/
    return a3; /*0x103125b7b*/
  v276 = (__int64 *)(a1 + 528); /*0x103125b88*/
  __n = a3; /*0x103125b8c*/
  v6 = &v5[a3]; /*0x103125b90*/
  v265 = a1 + 2376; /*0x103125b9b*/
  v264 = (_QWORD *)(a1 + 672); /*0x103125ba9*/
  v258 = a1 + 2644; /*0x103125bb7*/
  v259 = a1 + 2640; /*0x103125bc5*/
  v262 = (__int64 *)(a1 + 720); /*0x103125bd3*/
  v274 = (__int64 *)(a1 + 632); /*0x103125be1*/
  v257 = a1 + 1904; /*0x103125bec*/
  v261 = a1 + 592; /*0x103125bfa*/
  v7 = v5; /*0x103125c01*/
  v273 = v5; /*0x103125c04*/
  v275 = &v5[a3]; /*0x103125c08*/
  v8 = a1; /*0x103125c0c*/
  v278 = a1; /*0x103125c0f*/
  while ( 2 )
  {
    v9 = (_QWORD *)a3; /*0x103125c24*/
    a3 = (size_t)v7; /*0x103125c32*/
    switch ( *(_DWORD *)(v8 + 752) )
    {
      case 0:
        v93 = *(_QWORD *)(v8 + 736); /*0x103126469*/
        v94 = __n; /*0x103126470*/
        v95 = v93; /*0x103126477*/
        if ( __n < v93 ) /*0x10312647a*/
          v95 = __n; /*0x10312647a*/
        v96 = v7; /*0x103126492*/
        v97 = v8; /*0x103126495*/
        if ( memcmp(__s1: &aPriHttp20Sm[-v93 + 24], __s2: v7, __n: v95) != 0 ) /*0x10312649f*/
          return -903; /*0x103128142*/
        *(_QWORD *)(v97 + 736) = v93 - v95; /*0x1031264ab*/
        a3 = (size_t)&v96[v95]; /*0x1031264b2*/
        v7 = (char *)a3; /*0x1031264b8*/
        v8 = v97; /*0x1031264bb*/
        if ( v93 <= v94 ) /*0x1031264be*/
        {
          session_inbound_frame_reset(a1: v97); /*0x1031264c6*/
          v8 = v278; /*0x1031264cb*/
          v7 = (char *)a3; /*0x1031264cf*/
          *(_DWORD *)(v278 + 752) = 1; /*0x1031264d2*/
        }
        v20 = 0; /*0x1031264dd*/
        v6 = v275; /*0x1031264df*/
LABEL_377:
        v5 = v273; /*0x10312780a*/
        goto LABEL_465; /*0x10312780e*/
      case 1:
        v85 = v6 - v7; /*0x1031263f5*/
        v86 = *(char **)(v8 + 656); /*0x1031263f8*/
        v87 = *(_QWORD *)(v8 + 664) - (_QWORD)v86; /*0x103126406*/
        if ( v85 < v87 ) /*0x10312640c*/
          v87 = v85; /*0x10312640c*/
        v88 = nghttp2_cpymem(__dst: v86, a2: v7, a3: v87); /*0x103126416*/
        v89 = v278; /*0x10312641b*/
        *(_QWORD *)(v278 + 656) = v88; /*0x103126422*/
        v7 = (char *)(v87 + a3); /*0x103126429*/
        if ( *(char **)(v89 + 664) != v88 ) /*0x103126433*/
          return v7 - v5; /*0x103126433*/
        v90 = *(_QWORD *)(v89 + 648); /*0x103126439*/
        if ( *(_BYTE *)(v90 + 3) == 4 && (*(_BYTE *)(v90 + 4) & 1) == 0 )
        {
          *(_DWORD *)(v89 + 752) = 2; /*0x103126454*/
          v91 = v88; /*0x10312645e*/
          v92 = v89; /*0x103126461*/
LABEL_121:
          v98 = v7; /*0x1031264f9*/
          v99 = v91 - v88; /*0x103126503*/
          if ( v275 - v7 < v99 ) /*0x103126509*/
            v99 = v275 - v7; /*0x103126509*/
          v100 = nghttp2_cpymem(__dst: v88, a2: v7, a3: v99); /*0x103126516*/
          *(_QWORD *)(v92 + 656) = v100; /*0x10312651b*/
          v101 = &v98[v99]; /*0x103126522*/
          if ( *(char **)(v92 + 664) != v100 ) /*0x10312652c*/
            return v101 - v5; /*0x1031280bb*/
          v102 = v92; /*0x103126532*/
          a3 = (size_t)v101; /*0x103126535*/
          nghttp2_frame_unpack_frame_hd(a1: (__int64)v276, a2: *(_QWORD *)(v102 + 648)); /*0x103126543*/
          v8 = v278; /*0x103126548*/
          v103 = *(_QWORD *)(v278 + 528); /*0x10312654c*/
          *(_QWORD *)(v278 + 736) = v103; /*0x103126553*/
          if ( v103 > *(unsigned int *)(v8 + 2708) ) /*0x103126564*/
          {
            v251 = *(unsigned int *)(v8 + 2620); /*0x1031280f3*/
            v252 = "too large frame size"; /*0x1031280fa*/
            v245 = v8; /*0x103128101*/
            v246 = 6; /*0x103128104*/
            goto LABEL_521; /*0x103128109*/
          }
          v104 = *(unsigned __int8 *)(v8 + 540); /*0x10312656a*/
          v6 = v275; /*0x103126589*/
          switch ( *(_BYTE *)(v8 + 540) )
          {
            case 0:
              *(_BYTE *)(v8 + 541) &= 9u; /*0x1031268ea*/
              v129 = v8; /*0x1031268f5*/
              updated = session_on_data_received_fail_fast(a1: v8); /*0x1031268f8*/
              if ( updated <= -901 ) /*0x103126902*/
                return updated; /*0x103126902*/
              if ( *(_DWORD *)(v129 + 752) == 15 ) /*0x10312690f*/
                return __n; /*0x10312690f*/
              v7 = (char *)a3; /*0x103126915*/
              v8 = v129; /*0x103126918*/
              if ( updated == -104 ) /*0x10312691e*/
              {
                *(_DWORD *)(v129 + 752) = 14; /*0x103126924*/
LABEL_433:
                v20 = 1; /*0x103127c16*/
                goto LABEL_465; /*0x103127c1b*/
              }
              v201 = *(_BYTE *)(v129 + 541); /*0x10312747c*/
              if ( (v201 & 8) == 0 ) /*0x103127485*/
              {
                v20 = 1; /*0x103127496*/
                v137 = 13; /*0x10312749b*/
                if ( (v201 & 1 | (*(_QWORD *)(v8 + 736) != 0)) == 0 ) /*0x1031274a6*/
                {
                  v202 = v5; /*0x1031274ac*/
                  v203 = v8; /*0x1031274b2*/
                  updated = session_update_glitch_ratelim(a1: v8); /*0x1031274b5*/
                  if ( updated != 0 ) /*0x1031274bc*/
                    return updated; /*0x1031274bc*/
                  v30 = *(_DWORD *)(v203 + 752) == 15; /*0x1031274c2*/
                  v7 = (char *)a3; /*0x1031274ca*/
                  v8 = v203; /*0x1031274cd*/
                  v5 = v202; /*0x1031274d0*/
                  if ( v30 ) /*0x1031274d3*/
                    return __n; /*0x1031274d3*/
                }
                goto LABEL_320; /*0x1031274d3*/
              }
              if ( *v276 != 0 ) /*0x1031276f6*/
              {
                nghttp2_buf_reset(a1: v274); /*0x103127700*/
                v8 = v278; /*0x103127705*/
                v7 = (char *)a3; /*0x103127709*/
                ++*(_QWORD *)(v278 + 664); /*0x10312770c*/
                v20 = 1; /*0x103127713*/
                v137 = 12; /*0x103127718*/
LABEL_320:
                *(_DWORD *)(v8 + 752) = v137; /*0x1031273f0*/
LABEL_321:
                v198 = *(unsigned int (__fastcall **)(__int64, __int64 *, _QWORD))(v8 + 2304); /*0x1031273f7*/
                if ( v198 != nullptr ) /*0x103127401*/
                {
                  v199 = v5; /*0x103127403*/
                  v200 = v8; /*0x103127414*/
                  if ( v198(a1: v8, a2: v276, a3: *(_QWORD *)(v8 + 2416)) != 0 ) /*0x10312741b*/
                    return -902; /*0x10312741b*/
                  v137 = *(_DWORD *)(v200 + 752); /*0x103127421*/
                  v7 = (char *)a3; /*0x103127428*/
                  v8 = v200; /*0x10312742b*/
                  v5 = v199; /*0x10312742e*/
                }
                v6 = v275; /*0x103127435*/
                if ( v137 == 15 ) /*0x103127439*/
                  return __n; /*0x103127439*/
                goto LABEL_465; /*0x103127439*/
              }
              v251 = *(unsigned int *)(v129 + 2620); /*0x1031281d5*/
              v252 = "DATA: insufficient padding space";
              break; /*0x1031281e3*/
            case 1:
              v130 = *(_BYTE *)(v8 + 541); /*0x103126934*/
              *(_BYTE *)(v8 + 541) = v130 & 0x2D; /*0x10312693f*/
              if ( (v130 & 8) != 0 )
              {
                if ( v103 == 0 )
                {
                  v251 = *(unsigned int *)(v8 + 2620); /*0x1031281af*/
                  v252 = "HEADERS: insufficient padding space";
                  break; /*0x1031281bd*/
                }
                goto LABEL_318; /*0x1031273c1*/
              }
              v131 = nghttp2_frame_priority_len(a1: v130 & 0x2D); /*0x103126952*/
              if ( v131 != 0 ) /*0x10312695a*/
              {
                v134 = v131; /*0x103126960*/
                v8 = v278; /*0x103126963*/
                if ( *(_QWORD *)(v278 + 736) < v131 ) /*0x10312696e*/
                  goto LABEL_305; /*0x10312696e*/
                *(_DWORD *)(v278 + 752) = 3; /*0x103126974*/
                nghttp2_buf_reset(a1: v274); /*0x103126983*/
                v8 = v278; /*0x103126988*/
                *(_QWORD *)(v278 + 664) += v134; /*0x10312698c*/
                goto LABEL_191; /*0x103126993*/
              }
              v215 = v278; /*0x103127813*/
              v216 = *(__int64 (__fastcall **)(__int64, __int64 *, _QWORD))(v278 + 2304); /*0x103127817*/
              if ( v216 != nullptr ) /*0x103127821*/
              {
                v217 = v216(a1: v278, a2: v276, a3: *(_QWORD *)(v278 + 2416)); /*0x10312782e*/
                v215 = v278; /*0x103127830*/
                if ( v217 != 0 ) /*0x103127836*/
                  return -902; /*0x103127836*/
              }
              if ( *(_DWORD *)(v215 + 752) == 15 ) /*0x103127843*/
                return __n; /*0x103127843*/
              v218 = v215; /*0x103127849*/
              updated = session_process_headers_frame(a1: v215, a2: v133, a3: v132); /*0x10312784c*/
              if ( updated <= -901 ) /*0x103127856*/
                return updated; /*0x103127856*/
              if ( *(_DWORD *)(v218 + 752) == 15 ) /*0x103127863*/
                return __n; /*0x103127863*/
              v8 = v218; /*0x103127869*/
              if ( updated == -103 ) /*0x10312786f*/
              {
                updated = session_update_glitch_ratelim(a1: v218); /*0x10312787b*/
                if ( updated != 0 ) /*0x103127882*/
                  return updated; /*0x103127882*/
                if ( *(_DWORD *)(v218 + 752) == 15 ) /*0x10312788f*/
                  return __n; /*0x10312788f*/
                v7 = (char *)a3; /*0x103127895*/
                v8 = v218; /*0x103127898*/
                *(_DWORD *)(v218 + 752) = 5; /*0x10312789b*/
                goto LABEL_433; /*0x1031278a5*/
              }
              goto LABEL_454; /*0x10312786f*/
            case 2:
              *(_BYTE *)(v8 + 541) = 0; /*0x103126894*/
              if ( v103 != 5 ) /*0x1031268a0*/
                goto LABEL_305; /*0x1031268a0*/
              v128 = v8; /*0x1031268a9*/
              updated = session_update_glitch_ratelim(a1: v8); /*0x1031268ac*/
              if ( updated != 0 ) /*0x1031268b3*/
                return updated; /*0x1031268b3*/
              if ( *(_DWORD *)(v128 + 752) == 15 ) /*0x1031268c0*/
                return __n; /*0x1031268c0*/
              *(_DWORD *)(v128 + 752) = 3; /*0x1031268c6*/
              nghttp2_buf_reset(a1: v274); /*0x1031268d4*/
              v8 = v278; /*0x1031268d9*/
              *(_QWORD *)(v278 + 664) += 5LL; /*0x1031268dd*/
              goto LABEL_191; /*0x1031268e5*/
            case 3:
            case 8:
              *(_BYTE *)(v8 + 541) = 0; /*0x10312658f*/
              if ( v103 != 4 ) /*0x10312659b*/
                goto LABEL_305; /*0x10312659b*/
              goto LABEL_127; /*0x10312659b*/
            case 4:
              v135 = *(_BYTE *)(v8 + 541) & 1; /*0x1031269b2*/
              *(_BYTE *)(v8 + 541) = v135; /*0x1031269b4*/
              v7 = v101; /*0x1031269c9*/
              if ( __ROR4__(-1431655765 * v103, 1) > 0x2AAAAAAAu ) /*0x1031269cc*/
                goto LABEL_185; /*0x1031269cc*/
              if ( v135 != 0 ) /*0x1031274e7*/
              {
                if ( v103 != 0 ) /*0x1031278ad*/
                {
LABEL_185:
                  *(_DWORD *)(v8 + 752) = 7; /*0x1031269d2*/
                  goto LABEL_433; /*0x1031269dd*/
                }
                *(_DWORD *)(v8 + 752) = 8; /*0x1031278b3*/
LABEL_389:
                nghttp2_buf_reset(a1: v274); /*0x1031278be*/
                v8 = v278; /*0x1031278c7*/
                goto LABEL_390; /*0x1031278c7*/
              }
              if ( *(_QWORD *)(v8 + 2560) >= *(_QWORD *)(v8 + 2568) ) /*0x1031274fb*/
                return -904; /*0x103128215*/
              *(_DWORD *)(v8 + 752) = 8; /*0x103127501*/
              if ( v103 == 0 ) /*0x10312750f*/
                goto LABEL_389; /*0x10312750f*/
              v204 = (unsigned int)v103 / 6; /*0x103127524*/
              *(_QWORD *)(v8 + 728) = v204 + 1; /*0x10312752a*/
              if ( *(_QWORD *)(v8 + 2584) < v204 )
              {
                v251 = *(unsigned int *)(v8 + 2620); /*0x10312822a*/
                v252 = "SETTINGS: too many setting entries";
                v245 = v8; /*0x103128238*/
                v246 = 11; /*0x10312823b*/
                goto LABEL_521; /*0x103128240*/
              }
              v205 = nghttp2_mem_malloc(a1: v265, a2: 8 * (v204 + 1)); /*0x103127549*/
              v206 = v278; /*0x10312754e*/
              *(_QWORD *)(v278 + 624) = v205; /*0x103127552*/
              if ( v205 == 0 ) /*0x10312755c*/
                return -901; /*0x10312755c*/
              *(_QWORD *)(v205 + 8LL * *(_QWORD *)(v206 + 728) - 8) = 0xFFFFFFFF00000001LL; /*0x103127573*/
              nghttp2_buf_reset(a1: v274); /*0x10312757c*/
              v8 = v278; /*0x103127581*/
              *(_QWORD *)(v278 + 664) += 6LL; /*0x103127585*/
              goto LABEL_191; /*0x10312758d*/
            case 5:
              v136 = *(_BYTE *)(v8 + 541); /*0x1031269e2*/
              *(_BYTE *)(v8 + 541) = v136 & 0xC; /*0x1031269ee*/
              if ( (v136 & 8) == 0 ) /*0x1031269f7*/
              {
                if ( v103 <= 3 ) /*0x103126a01*/
                  goto LABEL_305; /*0x103126a01*/
LABEL_127:
                *(_DWORD *)(v8 + 752) = 3; /*0x1031265a1*/
                nghttp2_buf_reset(a1: v274); /*0x1031265b0*/
                v8 = v278; /*0x1031265b5*/
                *(_QWORD *)(v278 + 664) += 4LL; /*0x1031265b9*/
LABEL_191:
                v20 = 0; /*0x103126a3e*/
LABEL_192:
                v137 = *(_DWORD *)(v8 + 752); /*0x103126a40*/
                if ( v137 > 0xF ) /*0x103126a4b*/
                {
                  v7 = (char *)a3; /*0x1031276e6*/
                }
                else
                {
                  v138 = 49376; /*0x103126a51*/
                  v7 = (char *)a3; /*0x103126a5a*/
                  if ( _bittest(&v138, v137) ) /*0x103126a5d*/
                    goto LABEL_289; /*0x103126a5d*/
                }
                goto LABEL_321; /*0x103126a5d*/
              }
              if ( v103 != 0 ) /*0x1031273cb*/
              {
LABEL_318:
                nghttp2_buf_reset(a1: v274); /*0x1031273d1*/
                v8 = v278; /*0x1031273da*/
                ++*(_QWORD *)(v278 + 664); /*0x1031273de*/
                v20 = 0; /*0x1031273e5*/
                v137 = 3; /*0x1031273e7*/
LABEL_319:
                v7 = (char *)a3; /*0x1031273ed*/
                goto LABEL_320; /*0x1031273ed*/
              }
              v251 = *(unsigned int *)(v8 + 2620); /*0x1031281c2*/
              v252 = "PUSH_PROMISE: insufficient padding space";
              break; /*0x1031281d0*/
            case 6:
              *(_BYTE *)(v8 + 541) &= 1u; /*0x103126998*/
              if ( v103 != 8 ) /*0x1031269a4*/
                goto LABEL_305; /*0x1031269a4*/
              goto LABEL_190; /*0x1031269a4*/
            case 7:
              *(_BYTE *)(v8 + 541) = 0; /*0x103126a0c*/
              if ( v103 <= 7 ) /*0x103126a18*/
                goto LABEL_305; /*0x103126a18*/
LABEL_190:
              *(_DWORD *)(v8 + 752) = 3; /*0x103126a1e*/
              nghttp2_buf_reset(a1: v274); /*0x103126a2d*/
              v8 = v278; /*0x103126a32*/
              *(_QWORD *)(v278 + 664) += 8LL; /*0x103126a36*/
              goto LABEL_191; /*0x103126a36*/
            case 9:
              v251 = *(unsigned int *)(v8 + 2620); /*0x103128193*/
              v252 = "CONTINUATION: unexpected";
              break; /*0x1031281a1*/
            default:
              v139 = *(unsigned __int8 *)(v8 + (v104 >> 3) + 2742); /*0x103126a6d*/
              v6 = v275; /*0x103126a7e*/
              if ( _bittest(&v139, v104 & 7) ) /*0x103126a7b*/
              {
                if ( *(_QWORD *)(v8 + 2336) != 0 ) /*0x103126a90*/
                {
                  v7 = v101; /*0x103126a96*/
                  v20 = 1; /*0x103126a99*/
                  v137 = 18; /*0x103126a9e*/
                  goto LABEL_320; /*0x103126aa4*/
                }
                v210 = v8; /*0x103127726*/
                updated = session_update_glitch_ratelim(a1: v8); /*0x103127729*/
                if ( updated != 0 ) /*0x103127730*/
                  return updated; /*0x103127730*/
                if ( *(_DWORD *)(v210 + 752) == 15 ) /*0x10312773d*/
                  return __n; /*0x10312773d*/
                v8 = v210; /*0x103127743*/
                *(_DWORD *)(v210 + 752) = 6; /*0x103127746*/
                v20 = 1; /*0x103127750*/
                goto LABEL_501; /*0x103127755*/
              }
              switch ( v104 ) /*0x103127595*/
              {
                case 0x10u: /*0x103127595*/
                  if ( (*(_BYTE *)(v8 + 2732) & 4) == 0 ) /*0x103127be0*/
                    goto LABEL_430; /*0x103127be0*/
                  *(_BYTE *)(v8 + 541) = 0; /*0x103127cf5*/
                  *(_QWORD *)(v8 + 544) = v261; /*0x103127d04*/
                  if ( *(_BYTE *)(v8 + 2739) == 0 ) /*0x103127d13*/
                  {
                    v251 = *(unsigned int *)(v8 + 2620); /*0x103128245*/
                    v252 = "PRIORITY_UPDATE is received from server"; /*0x10312824c*/
                    goto LABEL_509; /*0x103128253*/
                  }
                  if ( v103 > 3 ) /*0x103127d1d*/
                  {
                    v235 = v8; /*0x103127d26*/
                    updated = session_update_glitch_ratelim(a1: v8); /*0x103127d29*/
                    if ( updated != 0 ) /*0x103127d30*/
                      return updated; /*0x103127d30*/
                    if ( *(_DWORD *)(v235 + 752) == 15 ) /*0x103127d3d*/
                      return __n; /*0x103127d3d*/
                    v8 = v235; /*0x103127d43*/
                    v236 = *(_QWORD *)(v235 + 736); /*0x103127d46*/
                    if ( v236 < 0x21 ) /*0x103127d51*/
                    {
                      *(_DWORD *)(v8 + 752) = 3; /*0x103127d57*/
                      nghttp2_buf_reset(a1: v274); /*0x103127d66*/
                      v8 = v278; /*0x103127d6b*/
                      *(_QWORD *)(v278 + 664) += v236; /*0x103127d6f*/
                      goto LABEL_390; /*0x103127d76*/
                    }
                    goto LABEL_437; /*0x103127d51*/
                  }
                  break;
                case 0xCu: /*0x103127595*/
                  if ( (*(_BYTE *)(v8 + 2732) & 2) == 0 /*0x103127b7e*/
                    || (*(_QWORD *)(v8 + 544) = v261, *(_BYTE *)(v8 + 2739) != 0)
                    || *(_DWORD *)(v8 + 536) != 0
                    || *(_BYTE *)(v8 + 541) >= 0x10u )
                  {
LABEL_430:
                    v232 = v8; /*0x103127be6*/
                    updated = session_update_glitch_ratelim(a1: v8); /*0x103127bec*/
                    if ( updated != 0 ) /*0x103127bf3*/
                      return updated; /*0x103127bf3*/
                    if ( *(_DWORD *)(v232 + 752) == 15 ) /*0x103127c00*/
                      return __n; /*0x103127c00*/
                    v7 = (char *)a3; /*0x103127c06*/
                    v8 = v232; /*0x103127c09*/
                    *(_DWORD *)(v232 + 752) = 6; /*0x103127c0c*/
                    goto LABEL_433; /*0x103127c0c*/
                  }
                  *(_BYTE *)(v8 + 541) = 0; /*0x103127b80*/
                  v137 = 17; /*0x103127b88*/
                  if ( v103 != 0 ) /*0x103127b91*/
                  {
                    v230 = nghttp2_mem_malloc(a1: v265, a2: v103); /*0x103127b9e*/
                    v231 = v278; /*0x103127ba3*/
                    *(_QWORD *)(v278 + 712) = v230; /*0x103127ba7*/
                    if ( v230 == 0 ) /*0x103127bb1*/
                      return -901; /*0x1031281ad*/
                    nghttp2_buf_wrap_init(a1: v264, a2: v230, a3: *(_QWORD *)(v231 + 736)); /*0x103127bc8*/
                    v8 = v278; /*0x103127bcd*/
                    v20 = 0; /*0x103127bd1*/
                  }
                  else
                  {
                    v20 = 1; /*0x103128068*/
                  }
                  goto LABEL_319; /*0x103127bd3*/
                case 0xAu: /*0x103127595*/
                  if ( (*(_BYTE *)(v8 + 2732) & 1) == 0 ) /*0x1031275b5*/
                    goto LABEL_430; /*0x1031275b5*/
                  *(_BYTE *)(v8 + 541) = 0; /*0x1031275bb*/
                  *(_QWORD *)(v8 + 544) = v261; /*0x1031275ca*/
                  if ( *(_BYTE *)(v8 + 2739) != 0 ) /*0x1031275d9*/
                    goto LABEL_430; /*0x1031275d9*/
                  if ( v103 > 1 ) /*0x1031275e3*/
                  {
                    *(_DWORD *)(v8 + 752) = 3; /*0x1031275e9*/
                    nghttp2_buf_reset(a1: v274); /*0x1031275f8*/
                    v8 = v278; /*0x1031275fd*/
                    *(_QWORD *)(v278 + 664) += 2LL; /*0x103127601*/
LABEL_390:
                    v20 = 1; /*0x1031278cb*/
                    goto LABEL_192; /*0x1031278d0*/
                  }
                  break;
                default:
                  v233 = v8; /*0x103127c23*/
                  updated = session_update_glitch_ratelim(a1: v8); /*0x103127c26*/
                  if ( updated != 0 ) /*0x103127c2d*/
                    return updated; /*0x103127c2d*/
                  if ( *(_DWORD *)(v233 + 752) == 15 ) /*0x103127c3a*/
                    return __n; /*0x103127c3a*/
                  v8 = v233; /*0x103127c40*/
LABEL_437:
                  *(_DWORD *)(v8 + 752) = 6; /*0x103127c43*/
                  goto LABEL_463; /*0x103127c4e*/
              }
              goto LABEL_305; /*0x1031275e3*/
          }
LABEL_509:
          v245 = v8; /*0x103128089*/
          goto LABEL_510; /*0x103128089*/
        }
        v248 = v89; /*0x1031280ce*/
        updated = session_call_error_callback( /*0x1031280d1*/
                    a1: v89,
                    a2: 4294966760LL,
                    a3: "Remote peer returned unexpected data while we expected SETTINGS frame.  Perhaps, peer does not suppo"
                    "rt HTTP/2 properly.");
        if ( updated <= -901 ) /*0x1031280db*/
          return updated; /*0x1031280db*/
        v251 = *(unsigned int *)(v248 + 2620); /*0x1031280e1*/
        v252 = "SETTINGS expected"; /*0x1031280e7*/
        v245 = v248; /*0x1031280ee*/
LABEL_510:
        v246 = 1; /*0x10312808c*/
LABEL_521:
        v249 = session_terminate_session(a1: v245, a2: v251, a3: v246, a4: v252); /*0x103128125*/
        a3 = __n; /*0x103128131*/
        if ( v249 < -900 ) /*0x103128135*/
          return v249; /*0x103128135*/
        return a3; /*0x10312817d*/
      case 2:
        v88 = *(char **)(v8 + 656); /*0x1031264e8*/
        v91 = *(char **)(v8 + 664); /*0x1031264ef*/
        v92 = v8; /*0x1031264f6*/
        goto LABEL_121; /*0x1031264f6*/
      case 3:
        v105 = *(char **)(v8 + 656); /*0x1031265cc*/
        v106 = *(_QWORD *)(v8 + 664) - (_QWORD)v105; /*0x1031265da*/
        if ( v6 - v7 < v106 ) /*0x1031265e0*/
          v106 = v6 - v7; /*0x1031265e0*/
        v107 = nghttp2_cpymem(__dst: v105, a2: v7, a3: v106); /*0x1031265ea*/
        v8 = v278; /*0x1031265ef*/
        *(_QWORD *)(v278 + 656) = v107; /*0x1031265f6*/
        v7 = (char *)(v106 + a3); /*0x1031265fd*/
        v109 = *(char **)(v8 + 664); /*0x103126600*/
        v110 = *(_QWORD *)(v8 + 736) - v106; /*0x10312660e*/
        *(_QWORD *)(v8 + 736) = v110; /*0x103126611*/
        if ( v109 != v107 ) /*0x10312661b*/
          return v7 - v5; /*0x10312809e*/
        v111 = (unsigned int)*(unsigned __int8 *)(v8 + 540) - 1; /*0x103126629*/
        switch ( *(_BYTE *)(v8 + 540) )
        {
          case 1:
            a3 += v106; /*0x1031271e3*/
            if ( *(_QWORD *)(v8 + 744) != 0 ) /*0x1031271ee*/
              goto LABEL_451; /*0x1031271ee*/
            v186 = *(_BYTE *)(v8 + 541); /*0x1031271f4*/
            if ( (v186 & 8) == 0 ) /*0x1031271fd*/
              goto LABEL_451; /*0x1031271fd*/
            v187 = nghttp2_frame_priority_len(a1: v186); /*0x103127206*/
            v8 = v278; /*0x10312720b*/
            v188 = v187; /*0x10312720f*/
            v189 = *(_QWORD *)(v278 + 736); /*0x103127219*/
            v190 = **(unsigned __int8 **)(v278 + 648); /*0x103127220*/
            if ( v189 < v190 || (*(_QWORD *)(v278 + 744) = v190 + 1, v188 + v190 + 1 > v189 + 1) )
            {
              v251 = *(unsigned int *)(v8 + 2620); /*0x1031281fb*/
              v252 = "HEADERS: invalid padding";
              goto LABEL_509; /*0x103128209*/
            }
            *(_QWORD *)(v8 + 544) = v190 + 1; /*0x10312724a*/
            if ( v188 != 0 ) /*0x103127254*/
            {
              if ( v189 >= v188 ) /*0x10312725d*/
              {
                *(_DWORD *)(v8 + 752) = 3; /*0x10312725f*/
                nghttp2_buf_reset(a1: v274); /*0x10312726e*/
                v8 = v278; /*0x103127273*/
                *(_QWORD *)(v278 + 664) += v188; /*0x103127277*/
LABEL_276:
                v20 = 0; /*0x1031270ab*/
                goto LABEL_464; /*0x1031270ad*/
              }
LABEL_305:
              *(_DWORD *)(v8 + 752) = 7; /*0x1031272d2*/
              goto LABEL_463; /*0x1031272dd*/
            }
            nghttp2_buf_reset(a1: v274); /*0x103127d8b*/
            v8 = v278; /*0x103127d90*/
LABEL_451:
            v237 = v8; /*0x103127d94*/
            updated = session_process_headers_frame(a1: v8, a2: v108, a3: v111); /*0x103127d9a*/
            if ( updated <= -901 ) /*0x103127da4*/
              return updated; /*0x103127da4*/
            if ( *(_DWORD *)(v237 + 752) == 15 ) /*0x103127db1*/
              return __n; /*0x103127db1*/
            v8 = v237; /*0x103127db7*/
            if ( updated == -103 ) /*0x103127dbd*/
            {
              updated = session_update_glitch_ratelim(a1: v237); /*0x103127e1b*/
              if ( updated != 0 ) /*0x103127e22*/
                return updated; /*0x103127e22*/
              if ( *(_DWORD *)(v237 + 752) == 15 ) /*0x103127e2f*/
                return __n; /*0x103127e2f*/
              v8 = v237; /*0x103127e35*/
LABEL_462:
              *(_DWORD *)(v8 + 752) = 5; /*0x103127e38*/
            }
            else
            {
LABEL_454:
              if ( updated == -521 ) /*0x103127dc4*/
              {
                v68 = v5; /*0x103127dc6*/
                v195 = *(unsigned int *)(v8 + 536); /*0x103127dc9*/
                goto LABEL_456; /*0x103127dc9*/
              }
              *(_DWORD *)(v8 + 752) = 4; /*0x103127e08*/
            }
            break; /*0x103127e13*/
          case 3:
            v68 = v5; /*0x10312715b*/
            a3 += v106; /*0x10312715e*/
            v183 = v276; /*0x103127168*/
            v70 = v8; /*0x10312716f*/
            nghttp2_frame_unpack_rst_stream_payload(a1: (__int64)v276, a2: *(_QWORD *)(v8 + 648)); /*0x103127172*/
            updated = nghttp2_session_on_rst_stream_received(a1: v70, a2: (__int64)v183); /*0x10312717d*/
            goto LABEL_407; /*0x103127182*/
          case 5:
            if ( *(_QWORD *)(v8 + 744) == 0 && (*(_BYTE *)(v8 + 541) & 8) != 0 )
            {
              v229 = **(unsigned __int8 **)(v8 + 648); /*0x103127aed*/
              if ( v110 >= v229 ) /*0x103127af3*/
              {
                *(_QWORD *)(v8 + 744) = v229 + 1; /*0x103127afd*/
                if ( v229 + 5 <= v110 + 1 ) /*0x103127b0e*/
                {
                  *(_QWORD *)(v8 + 544) = v229 + 1; /*0x103127b14*/
                  *(_DWORD *)(v8 + 752) = 3; /*0x103127b1b*/
                  nghttp2_buf_reset(a1: v274); /*0x103127b2d*/
                  v8 = v278; /*0x103127b32*/
                  v7 = (char *)(v106 + a3); /*0x103127b36*/
                  *(_QWORD *)(v278 + 664) += 4LL; /*0x103127b39*/
LABEL_396:
                  v20 = 0; /*0x10312792c*/
                  goto LABEL_465; /*0x10312792e*/
                }
              }
              v251 = *(unsigned int *)(v8 + 2620); /*0x1031281e8*/
              v252 = "PUSH_PROMISE: invalid padding";
              goto LABEL_509; /*0x1031281f6*/
            }
            v68 = v5; /*0x1031272fa*/
            a3 += v106; /*0x1031272fd*/
            v193 = v276; /*0x103127307*/
            v194 = v8; /*0x10312730e*/
            nghttp2_frame_unpack_push_promise_payload(a1: (__int64)v276, a2: *(_QWORD *)(v8 + 648)); /*0x103127311*/
            updated = nghttp2_session_on_push_promise_received(a1: v194, a2: (__int64)v193); /*0x10312731c*/
            if ( updated <= -901 ) /*0x103127326*/
              return updated; /*0x103127326*/
            if ( *(_DWORD *)(v194 + 752) == 15 ) /*0x103127334*/
              return __n; /*0x103127334*/
            v7 = (char *)a3; /*0x10312733a*/
            v8 = v194; /*0x10312733d*/
            if ( updated == -103 ) /*0x103127343*/
            {
              *(_DWORD *)(v194 + 752) = 5; /*0x103127a20*/
            }
            else
            {
              if ( updated == -521 ) /*0x10312734e*/
              {
                v195 = *(unsigned int *)(v194 + 568); /*0x103127354*/
LABEL_456:
                v238 = v8; /*0x103127dd0*/
                updated = session_handle_invalid_stream2(a1: v8, a2: v195, a3: 0, a4: 4294966762LL); /*0x103127ddd*/
                if ( updated <= -901 ) /*0x103127de7*/
                  return updated; /*0x103127de7*/
                *(_DWORD *)(v238 + 752) = 5; /*0x103127ded*/
                v20 = 1; /*0x103127df8*/
                v7 = (char *)a3; /*0x103127dfd*/
                v8 = v238; /*0x103127e00*/
                goto LABEL_410; /*0x103127e03*/
              }
              *(_DWORD *)(v194 + 752) = 4; /*0x103127a2d*/
            }
            v20 = 1; /*0x103127a38*/
LABEL_410:
            v5 = v68; /*0x103127a18*/
            goto LABEL_465; /*0x103127a1b*/
          case 6:
            v68 = v5; /*0x103127360*/
            a3 += v106; /*0x103127363*/
            v196 = v276; /*0x10312736d*/
            v70 = v8; /*0x103127374*/
            nghttp2_frame_unpack_ping_payload(a1: (__int64)v276, a2: *(__int64 **)(v8 + 648)); /*0x103127377*/
            updated = nghttp2_session_on_ping_received(a1: v70, a2: (__int64)v196); /*0x103127382*/
            goto LABEL_407; /*0x103127387*/
          case 7:
            v184 = *v276 - 8; /*0x10312718e*/
            if ( *v276 != 8 ) /*0x103127192*/
            {
              a3 = (size_t)v7; /*0x103127194*/
              v185 = nghttp2_mem_malloc(a1: v265, a2: *v276 - 8); /*0x1031271a1*/
              *(_QWORD *)(v278 + 712) = v185; /*0x1031271aa*/
              if ( v185 == 0 ) /*0x1031271b4*/
                return -901; /*0x1031271b4*/
              nghttp2_buf_wrap_init(a1: v264, a2: v185, a3: v184); /*0x1031271c7*/
              v8 = v278; /*0x1031271cc*/
              v7 = (char *)a3; /*0x1031271d0*/
            }
            *(_DWORD *)(v8 + 752) = 9; /*0x1031271d3*/
            goto LABEL_433; /*0x1031271de*/
          case 8:
            v68 = v5; /*0x103127283*/
            a3 += v106; /*0x103127286*/
            v191 = v276; /*0x103127290*/
            v70 = v8; /*0x103127297*/
            nghttp2_frame_unpack_window_update_payload(a1: (__int64)v276, a2: *(_QWORD *)(v8 + 648)); /*0x10312729a*/
            updated = nghttp2_session_on_window_update_received(a1: v70, a2: (__int64)v191); /*0x1031272a5*/
            goto LABEL_407; /*0x1031272aa*/
          case 0xA:
            a3 += v106; /*0x1031272af*/
            uint16 = nghttp2_get_uint16(a1: *(_WORD **)(v8 + 648)); /*0x1031272b9*/
            v8 = v278; /*0x1031272be*/
            if ( *(_QWORD *)(v278 + 736) < (unsigned __int64)uint16 ) /*0x1031272cc*/
              goto LABEL_305; /*0x1031272cc*/
            if ( (unsigned __int64)*v276 >= 3 ) /*0x103127696*/
            {
              v209 = nghttp2_mem_malloc(a1: v265, a2: *v276 - 2); /*0x1031276a3*/
              *(_QWORD *)(v278 + 712) = v209; /*0x1031276ac*/
              if ( v209 == 0 ) /*0x1031276b6*/
                return -901; /*0x1031276b6*/
              nghttp2_buf_wrap_init(a1: v264, a2: v209, a3: *v276); /*0x1031276cd*/
              v8 = v278; /*0x1031276d2*/
            }
            *(_DWORD *)(v8 + 752) = 16; /*0x1031276d6*/
            goto LABEL_463; /*0x1031276e1*/
          case 0x10:
            v68 = v5; /*0x10312738c*/
            a3 += v106; /*0x10312738f*/
            v197 = v276; /*0x10312739c*/
            v70 = v8; /*0x1031273a6*/
            nghttp2_frame_unpack_priority_update_payload( /*0x1031273a9*/
              a1: (__int64)v276,
              a2: *(_QWORD *)(v8 + 648),
              a3: (unsigned __int64)&v107[-*(_QWORD *)(v8 + 648)]);
            updated = nghttp2_session_on_priority_update_received(a1: v70, a2: (__int64)v197); /*0x1031273b4*/
            goto LABEL_407; /*0x1031273b9*/
          default:
            goto LABEL_132;
        }
        goto LABEL_463; /*0x103127e13*/
      case 4:
      case 5:
        v10 = v6 - v7; /*0x103125c3a*/
        v11 = *(_QWORD *)(v8 + 736); /*0x103125c3d*/
        if ( v6 - v7 >= v11 ) /*0x103125c4e*/
          v10 = *(_QWORD *)(v8 + 736); /*0x103125c4e*/
        v12 = v11 - v10; /*0x103125c52*/
        v13 = v276; /*0x103125c55*/
        v14 = nghttp2_frame_trail_padlen(a1: (__int64)v276, a2: *(_QWORD *)(v8 + 744)); /*0x103125c5c*/
        v15 = v10 - (v14 - v12); /*0x103125c6a*/
        if ( v10 < v14 - v12 ) /*0x103125c74*/
          v15 = -1; /*0x103125c74*/
        if ( v14 <= v12 ) /*0x103125c7b*/
          v15 = v10; /*0x103125c7b*/
        v16 = false; /*0x103125c7f*/
        v17 = 0; /*0x103125c85*/
        if ( v15 != -1 ) /*0x103125c8b*/
          v17 = v15; /*0x103125c8b*/
        v18 = nghttp2_frame_trail_padlen(a1: (__int64)v13, a2: *(_QWORD *)(v278 + 744)); /*0x103125c9d*/
        v8 = v278; /*0x103125ca2*/
        if ( (*(_BYTE *)(v278 + 541) & 4) != 0 ) /*0x103125cae*/
          v16 = *(_QWORD *)(v278 + 736) - v17 == v18; /*0x103125cbd*/
        if ( v17 <= 0 && (!v16 || v17 != 0) ) /*0x103125cc3*/
        {
          v7 = (char *)(v10 + a3); /*0x103125cd7*/
          v19 = *(_QWORD *)(v278 + 736) - v10; /*0x103125ce1*/
          *(_QWORD *)(v278 + 736) = v19; /*0x103125ce4*/
          v5 = v273; /*0x103125ceb*/
          v6 = v275; /*0x103125cef*/
          goto LABEL_19; /*0x103125cef*/
        }
        v260 = *(_DWORD *)(v278 + 752); /*0x1031266f6*/
        v117 = nghttp2_map_find(a1: v278, a2: *(_DWORD *)(v278 + 536)); /*0x103126706*/
        if ( v117 == 0 || (v118 = (_DWORD *)v117, (*(_BYTE *)(v117 + 116) & 2) != 0) ) /*0x103126717*/
        {
          v118 = nullptr; /*0x103126727*/
        }
        else if ( *(_DWORD *)v117 == 5 ) /*0x103126721*/
        {
          v118 = nullptr; /*0x103126721*/
        }
        v119 = *(_BYTE *)(v278 + 540); /*0x10312672d*/
        v268 = v10; /*0x103126735*/
        if ( v119 == 5 ) /*0x103126739*/
        {
          v120 = (_DWORD *)nghttp2_map_find(a1: v278, a2: *(_DWORD *)(v278 + 568)); /*0x103126741*/
          if ( v120 != nullptr ) /*0x103126749*/
          {
            v121 = (char *)a3; /*0x103126753*/
            if ( (v120[29] & 2) != 0 ) /*0x103126756*/
            {
              v272 = nullptr; /*0x103126cc4*/
              v266 = false; /*0x103126ccc*/
            }
            else
            {
              v30 = *v120 == 5; /*0x10312675e*/
              v266 = false; /*0x103126766*/
              if ( v30 ) /*0x10312676d*/
                v120 = nullptr; /*0x10312676d*/
              v272 = v120; /*0x103126771*/
            }
          }
          else
          {
            v272 = nullptr; /*0x10312686c*/
            v266 = false; /*0x103126874*/
            v121 = (char *)a3; /*0x10312687f*/
          }
        }
        else
        {
          v266 = false; /*0x10312677a*/
          v121 = (char *)a3; /*0x103126788*/
          if ( v118 != nullptr ) /*0x10312678b*/
          {
            v272 = v118; /*0x103126793*/
            if ( v119 == 1 ) /*0x103126797*/
            {
              v122 = *(_DWORD *)(v278 + 584); /*0x1031267a4*/
              if ( *(_BYTE *)(v278 + 2739) != 0 ) /*0x1031267aa*/
              {
                v266 = v122 == 3; /*0x1031267b8*/
              }
              else if ( v122 == 3 ) /*0x103127670*/
              {
                v266 = (*((_BYTE *)v118 + 113) & 0x40) == 0; /*0x10312767f*/
              }
            }
          }
          else
          {
            v272 = nullptr; /*0x103126887*/
          }
        }
        LODWORD(v263) = v16; /*0x103126cda*/
        v159 = 0; /*0x103126ce0*/
        v160 = v121; /*0x103126ce3*/
        while ( 2 )
        {
          v267 = 0; /*0x103126ce6*/
          v161 = nghttp2_hd_inflate_hd_nv(a1: v257, a2: (__int64)&v269, a3: &v267, a4: v160, a5: v17, a6: (int)v263); /*0x103126d0f*/
          v162 = v161; /*0x103126d14*/
          if ( (int)v161 < -900 ) /*0x103126d1e*/
            return (int)v162; /*0x103126d1e*/
          if ( (__int64)v161 < 0 ) /*0x103126d27*/
          {
            v171 = v278; /*0x103126f20*/
            v6 = v275; /*0x103126f2b*/
            if ( *(_DWORD *)(v278 + 752) == 4 && v272 != nullptr && *v272 != 3 ) /*0x103126f3d*/
            {
              updated = nghttp2_session_add_rst_stream_continue(a1: v278, a2: v272[20], a3: 9, a4: 1); /*0x103126f4c*/
              v171 = v278; /*0x103126f51*/
              if ( updated < -900 ) /*0x103126f5a*/
                return updated; /*0x103126f5a*/
            }
            v172 = session_terminate_session(a1: v171, a2: *(unsigned int *)(v171 + 2620), a3: 9, a4: 0); /*0x103126f72*/
            updated = -523; /*0x103126f74*/
            if ( v172 > -901 ) /*0x103126f7f*/
            {
LABEL_258:
              v163 = (_QWORD *)a3; /*0x103126f85*/
              goto LABEL_261; /*0x103126f88*/
            }
            return v172; /*0x103128191*/
          }
          v159 += (__int64)v161; /*0x103126d2d*/
          v163 = (_QWORD *)a3; /*0x103126d37*/
          v164 = (_QWORD *)v278; /*0x103126d3a*/
          if ( v260 != 4 || (v267 & 2) == 0 || v272 == nullptr ) /*0x103126d56*/
            goto LABEL_250; /*0x103126d56*/
          if ( (*(_BYTE *)(v278 + 2724) & 4) != 0 ) /*0x103126d63*/
            goto LABEL_238; /*0x103126d63*/
          v165 = nghttp2_http_on_header(a1: v278, a2: (__int64)v272, a3: (__int64)v276, a4: (__int64)&v269, a5: v266); /*0x103126d78*/
          if ( v165 == -105 )
          {
            v8 = v278; /*0x103126e1c*/
            v168 = *(__int64 (__fastcall **)(__int64, __int64 *, __int64, __int64, _QWORD, _QWORD))(v278 + 2264); /*0x103126e20*/
            if ( v168 != nullptr )
            {
              updated = v168(a1: v278, a2: v276, a3: v269, a4: v270, a5: v271, a6: *(_QWORD *)(v278 + 2416)); /*0x103126e47*/
LABEL_248:
              v8 = v278; /*0x103126e8a*/
              if ( updated != 0 )
              {
                if ( updated == -526 ) /*0x103127a44*/
                {
                  v6 = v275; /*0x103127d7b*/
                  v163 = (_QWORD *)a3; /*0x103127d7f*/
                  goto LABEL_262; /*0x103127d82*/
                }
                LODWORD(v162) = -902; /*0x103127a4a*/
                if ( updated == -521 )
                {
                  v228 = v278; /*0x103127a5b*/
                  updated = session_call_error_callback(
                              a1: v278,
                              a2: 4294966765LL,
                              a3: "Invalid HTTP header field was received: frame type: %u, stream: %d, name: [%.*s], value: [%.*s]",
                              *(unsigned __int8 *)(v278 + 540),
                              *(_DWORD *)(v278 + 536),
                              *(_DWORD *)(v269 + 24),
                              *(const char **)(v269 + 16),
                              *(_DWORD *)(v270 + 24),
                              *(const char **)(v270 + 16));
                  if ( updated < -900 ) /*0x103127aac*/
                    return updated; /*0x103127aac*/
                  v172 = session_handle_invalid_stream2( /*0x103127aca*/
                           a1: v228,
                           a2: (unsigned int)v272[20],
                           a3: v276,
                           a4: 4294966765LL);
                  updated = -521; /*0x103127acc*/
                  v6 = v275; /*0x103127ad7*/
                  if ( v172 > -901 ) /*0x103127adb*/
                    goto LABEL_258; /*0x103127adb*/
                  return v172; /*0x103127adb*/
                }
                return (int)v162; /*0x103128174*/
              }
            }
            else
            {
              v169 = *(__int64 (__fastcall **)(__int64, __int64 *, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))(v278 + 2256); /*0x103126e4b*/
              if ( v169 != nullptr ) /*0x103126e55*/
              {
                updated = v169( /*0x103126e84*/
                            a1: v278,
                            a2: v276,
                            a3: *(_QWORD *)(v269 + 16),
                            a4: *(_QWORD *)(v269 + 24),
                            a5: *(_QWORD *)(v270 + 16),
                            a6: *(_QWORD *)(v270 + 24),
                            a7: v271,
                            a8: *(_QWORD *)(v278 + 2416));
                goto LABEL_248; /*0x103126e84*/
              }
            }
            v170 = session_call_error_callback(
                     a1: v278,
                     a2: 4294966765LL,
                     a3: "Ignoring received invalid HTTP header field: frame type: %u, stream: %d, name: [%.*s], value: [%.*s]",
                     *(unsigned __int8 *)(v8 + 540),
                     *(_DWORD *)(v8 + 536),
                     *(_DWORD *)(v269 + 24),
                     *(const char **)(v269 + 16),
                     *(_DWORD *)(v270 + 24),
                     *(const char **)(v270 + 16));
            v163 = (_QWORD *)a3; /*0x103126eee*/
            if ( v170 <= -901 ) /*0x103126ef1*/
            {
              LODWORD(v162) = v170; /*0x103128171*/
              return (int)v162; /*0x103128171*/
            }
            goto LABEL_250; /*0x103126ef1*/
          }
          v163 = (_QWORD *)a3; /*0x103126d88*/
          v164 = (_QWORD *)v278; /*0x103126d8b*/
          if ( v165 != 0 )
          {
            if ( v165 == -531 )
            {
              v234 = v278; /*0x103127c65*/
              updated = session_call_error_callback(
                          a1: v278,
                          a2: 4294966765LL,
                          a3: "Invalid HTTP header field was received: frame type: %u, stream: %d, name: [%.*s], value: [%.*s]",
                          *(unsigned __int8 *)(v278 + 540),
                          *(_DWORD *)(v278 + 536),
                          *(_DWORD *)(v269 + 24),
                          *(const char **)(v269 + 16),
                          *(_DWORD *)(v270 + 24),
                          *(const char **)(v270 + 16));
              if ( updated >= -900 ) /*0x103127c9e*/
              {
                updated = session_handle_invalid_stream2( /*0x103127cb7*/
                            a1: v234,
                            a2: (unsigned int)v272[20],
                            a3: v276,
                            a4: 4294966765LL);
                v6 = v275; /*0x103127cc1*/
                v173 = v268; /*0x103127cc5*/
                if ( updated >= -900 ) /*0x103127cc9*/
                {
                  updated = session_update_glitch_ratelim(a1: v234); /*0x103127cd2*/
                  if ( updated == 0 ) /*0x103127cd9*/
                  {
                    updated = -521; /*0x103127e68*/
                    if ( *(_DWORD *)(v234 + 752) == 15 ) /*0x103127e72*/
                      updated = 0; /*0x103127e72*/
                    v163 = (_QWORD *)a3; /*0x103127e75*/
                    v8 = v234; /*0x103127e78*/
                    goto LABEL_263; /*0x103127e7b*/
                  }
                  v163 = (_QWORD *)a3; /*0x103127ce4*/
                  v8 = v234; /*0x103127ce7*/
                  if ( updated > -901 ) /*0x103127cea*/
                    goto LABEL_263; /*0x103127cea*/
                }
              }
              return updated; /*0x103127cea*/
            }
          }
          else
          {
LABEL_238:
            v166 = (__int64 (__fastcall *)(_QWORD *, __int64 *, __int64, __int64, _QWORD, _QWORD))v164[281]; /*0x103126da1*/
            if ( v166 != nullptr ) /*0x103126dab*/
            {
              updated = v166(a1: v164, a2: v276, a3: v269, a4: v270, a5: v271, a6: v164[302]); /*0x103126dc5*/
            }
            else
            {
              v167 = (__int64 (__fastcall *)(_QWORD *, __int64 *, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))v164[280]; /*0x103126dc9*/
              if ( v167 == nullptr ) /*0x103126dd3*/
                goto LABEL_250; /*0x103126dd3*/
              updated = v167( /*0x103126e02*/
                          a1: v164,
                          a2: v276,
                          a3: *(_QWORD *)(v269 + 16),
                          a4: *(_QWORD *)(v269 + 24),
                          a5: *(_QWORD *)(v270 + 16),
                          a6: *(_QWORD *)(v270 + 24),
                          a7: v271,
                          a8: v164[302]);
            }
            v163 = (_QWORD *)a3; /*0x103126e0a*/
            v8 = v278; /*0x103126e0d*/
            if ( updated != 0 ) /*0x103126e11*/
            {
              if ( updated == -526 ) /*0x103127449*/
              {
                v6 = v275; /*0x1031278d5*/
                goto LABEL_262; /*0x1031278d9*/
              }
              v6 = v275; /*0x103127454*/
              v173 = v268; /*0x103127458*/
              if ( updated == -521 ) /*0x10312745c*/
                goto LABEL_263; /*0x10312745c*/
              return -902; /*0x103128177*/
            }
          }
LABEL_250:
          if ( (v267 & 1) == 0 ) /*0x103126eff*/
          {
            v160 = &v160[(_QWORD)v162]; /*0x103126f05*/
            v17 -= (__int64)v162; /*0x103126f08*/
            if ( (v267 & 2) == 0 && v17 == 0 ) /*0x103126f13*/
              goto LABEL_260; /*0x103126f18*/
            continue; /*0x103126f18*/
          }
          break;
        }
        nghttp2_hd_inflate_end_headers(a1: v257); /*0x103126f91*/
        v163 = (_QWORD *)a3; /*0x103126f96*/
LABEL_260:
        updated = 0; /*0x103126f99*/
        v6 = v275; /*0x103126f9b*/
LABEL_261:
        v8 = v278; /*0x103126f9f*/
LABEL_262:
        v173 = v268; /*0x103126fa3*/
LABEL_263:
        if ( *(_DWORD *)(v8 + 752) == 15 ) /*0x103126faf*/
          return __n; /*0x103126faf*/
        if ( updated == -521 ) /*0x103126fba*/
        {
          *(_QWORD *)(v8 + 736) -= v159; /*0x103127007*/
          v176 = v8; /*0x103127033*/
          updated = nghttp2_session_add_rst_stream_continue( /*0x103127036*/
                      a1: v8,
                      a2: *(_DWORD *)(v8 + 32 * (unsigned int)(*(_BYTE *)(v8 + 540) == 5) + 536),
                      a3: 2,
                      a4: 1);
          if ( updated > -901 ) /*0x103127040*/
          {
            v7 = (char *)(v159 + a3); /*0x103127049*/
            *(_DWORD *)(v176 + 752) = 5; /*0x10312704c*/
            v20 = 1; /*0x103127057*/
            v8 = v176; /*0x10312705c*/
            goto LABEL_377; /*0x10312705f*/
          }
          return updated; /*0x103127040*/
        }
        if ( updated == -526 ) /*0x103126fc1*/
        {
          *(_QWORD *)(v8 + 736) -= v159; /*0x10312815e*/
          return (char *)v163 + v159 - v273; /*0x1031280a4*/
        }
        v7 = (char *)v163 + v173; /*0x103126fc7*/
        v174 = *(_QWORD *)(v8 + 736); /*0x103126fca*/
        v19 = v174 - v173; /*0x103126fd4*/
        *(_QWORD *)(v8 + 736) = v174 - v173; /*0x103126fd7*/
        if ( updated == -523 ) /*0x103126fe3*/
        {
          if ( v174 == v173 ) /*0x103126fe8*/
          {
            v175 = v7; /*0x103126ff1*/
            session_inbound_frame_reset(a1: v8); /*0x103126ff4*/
            v8 = v278; /*0x103126ff9*/
            v7 = v175; /*0x103126ffd*/
            v20 = 0; /*0x103127000*/
          }
          else
          {
            *(_DWORD *)(v8 + 752) = 6; /*0x103127467*/
            v20 = 1; /*0x103127472*/
          }
          goto LABEL_377; /*0x103127002*/
        }
        v5 = v273; /*0x103127064*/
LABEL_19:
        v20 = 0; /*0x103125cf3*/
        if ( v19 == 0 ) /*0x103125cf8*/
        {
          a3 = (size_t)v7; /*0x103125cfe*/
          if ( (*(_BYTE *)(v8 + 541) & 4) == 0 ) /*0x103125d09*/
          {
            nghttp2_buf_reset(a1: v274); /*0x103125d13*/
            v8 = v278; /*0x103125d18*/
            *(_QWORD *)(v278 + 664) += 9LL; /*0x103125d1c*/
            *(_QWORD *)(v8 + 744) = 0; /*0x103125d24*/
            if ( *(_DWORD *)(v8 + 752) == 4 ) /*0x103125d37*/
              *(_DWORD *)(v8 + 752) = 10; /*0x103125d3d*/
            else
              *(_DWORD *)(v8 + 752) = 11; /*0x10312714b*/
            goto LABEL_464; /*0x103125d48*/
          }
          if ( *(_DWORD *)(v8 + 752) != 4 ) /*0x1031267cc*/
            goto LABEL_500; /*0x1031267cc*/
          v123 = nghttp2_map_find(a1: v8, a2: *(_DWORD *)(v8 + 536)); /*0x1031267dc*/
          v8 = v278; /*0x1031267e1*/
          if ( v123 == 0 ) /*0x1031267e8*/
            goto LABEL_499; /*0x1031267e8*/
          v124 = v123; /*0x1031267ee*/
          if ( (*(_BYTE *)(v123 + 116) & 2) != 0 ) /*0x1031267f5*/
            goto LABEL_499; /*0x1031267f5*/
          v125 = *(_DWORD *)v123; /*0x1031267fb*/
          if ( v125 == 3 || v125 == 5 ) /*0x10312680a*/
            goto LABEL_499; /*0x10312680a*/
          if ( (*(_BYTE *)(v278 + 2724) & 4) != 0 ) /*0x103126818*/
            goto LABEL_487; /*0x103126818*/
          if ( *(_BYTE *)(v278 + 540) == 5 ) /*0x103126826*/
          {
            v126 = nghttp2_map_find(a1: v278, a2: *(_DWORD *)(v278 + 568)); /*0x103126836*/
            v8 = v278; /*0x10312683b*/
            if ( v126 != 0 && (*(_BYTE *)(v126 + 116) & 2) == 0 && *(_DWORD *)v126 != 5 ) /*0x103126855*/
            {
              v127 = nghttp2_http_on_request_headers(a1: v126, a2: (__int64)v276); /*0x103126862*/
              goto LABEL_481; /*0x103126867*/
            }
            goto LABEL_487; /*0x103126855*/
          }
          v239 = *(_DWORD *)(v278 + 584); /*0x103127e80*/
          if ( (unsigned int)(v239 - 1) < 2 ) /*0x103127e8d*/
            goto LABEL_477; /*0x103127e8d*/
          if ( v239 != 3 ) /*0x103127e92*/
          {
            if ( v239 == 0 ) /*0x103127e96*/
            {
              v240 = nghttp2_http_on_request_headers(a1: v124, a2: (__int64)v276); /*0x103127e9f*/
              goto LABEL_478; /*0x103127ea4*/
            }
LABEL_479:
            if ( (*(_BYTE *)(v8 + 541) & 1) == 0 ) /*0x103127ed3*/
              goto LABEL_487; /*0x103127ed3*/
            v127 = nghttp2_http_on_remote_end_stream(a1: v124); /*0x103127ed8*/
LABEL_481:
            v8 = v278; /*0x103127edf*/
            if ( v127 != 0 ) /*0x103127ee3*/
            {
LABEL_482:
              v241 = v5; /*0x103127ee5*/
              v242 = v8; /*0x103127f0c*/
              updated = session_handle_invalid_stream2( /*0x103127f0f*/
                          a1: v8,
                          a2: *(unsigned int *)(v8 + 32 * (unsigned int)(*(_BYTE *)(v8 + 540) == 5) + 536),
                          a3: v276,
                          a4: 4294966764LL);
              if ( updated < -900 ) /*0x103127f19*/
                return updated; /*0x103127f19*/
              updated = session_update_glitch_ratelim(a1: v242); /*0x103127f22*/
              if ( updated != 0 ) /*0x103127f29*/
              {
                v5 = v241; /*0x103127f2f*/
LABEL_485:
                v8 = v278; /*0x103127f32*/
                if ( updated <= -901 ) /*0x103127f3b*/
                  return updated; /*0x103127f3b*/
                goto LABEL_499; /*0x103127f3b*/
              }
              v8 = v278; /*0x103128030*/
              if ( *(_DWORD *)(v278 + 752) == 15 ) /*0x10312803c*/
                return __n; /*0x10312803c*/
              v5 = v241; /*0x10312803e*/
              if ( *(_BYTE *)(v278 + 540) == 1 ) /*0x103128049*/
              {
                if ( (*(_BYTE *)(v278 + 541) & 1) != 0 ) /*0x103128053*/
                {
                  nghttp2_stream_shutdown(a1: v124, a2: 1); /*0x10312805d*/
                  v8 = v278; /*0x103128062*/
                }
                goto LABEL_499; /*0x103128066*/
              }
            }
            else
            {
LABEL_487:
              v243 = *(__int64 (__fastcall **)(__int64, __int64 *, _QWORD))(v8 + 2176); /*0x103127f46*/
              if ( v243 != nullptr ) /*0x103127f50*/
              {
                v244 = v243(a1: v8, a2: v276, a3: *(_QWORD *)(v8 + 2416)); /*0x103127f60*/
                v8 = v278; /*0x103127f62*/
                if ( v244 != 0 ) /*0x103127f68*/
                  return -902; /*0x103127f68*/
              }
              if ( *(_BYTE *)(v8 + 540) == 1 ) /*0x103127f76*/
              {
                if ( *(_BYTE *)(v8 + 2739) != 0 /*0x103127fa6*/
                  && (*(_BYTE *)(v8 + 2724) & 4) == 0
                  && *(_DWORD *)(v8 + 584) == 0
                  && (*(_BYTE *)(v124 + 116) & 0x20) == 0
                  && (*(_BYTE *)(v124 + 114) & 1) != 0 )
                {
                  updated = session_update_stream_priority(a1: v8, a2: v124, a3: *(unsigned __int8 *)(v124 + 121)); /*0x103127fb3*/
                  v8 = v278; /*0x103127fb8*/
                  if ( updated != 0 ) /*0x103127fbe*/
                    goto LABEL_485; /*0x103127fbe*/
                }
                if ( (*(_BYTE *)(v8 + 541) & 1) != 0 ) /*0x103127fcc*/
                {
                  nghttp2_stream_shutdown(a1: v124, a2: 1); /*0x103127fd6*/
                  v8 = v278; /*0x103127fdb*/
                  if ( (~*(_BYTE *)(v124 + 117) & 3) == 0 ) /*0x103127fe7*/
                  {
                    updated = nghttp2_session_close_stream(a1: v278, a2: *(_DWORD *)(v124 + 80), a3: 0); /*0x103127ff2*/
                    v8 = v278; /*0x103127ff7*/
                    if ( updated <= -901 ) /*0x103128000*/
                      return updated; /*0x103128000*/
                  }
                }
              }
LABEL_499:
              if ( *(_DWORD *)(v8 + 752) == 15 ) /*0x10312800e*/
                return __n; /*0x10312800e*/
            }
LABEL_500:
            session_inbound_frame_reset(a1: v8); /*0x103128010*/
            v8 = v278; /*0x103128018*/
            *(_QWORD *)(v278 + 2600) = 0; /*0x10312801c*/
LABEL_501:
            v6 = v275; /*0x103128027*/
            goto LABEL_464; /*0x10312802b*/
          }
          if ( (*(_BYTE *)(v124 + 113) & 0x40) != 0 ) /*0x103127eab*/
LABEL_477:
            v240 = nghttp2_http_on_response_headers(a1: v124); /*0x103127ebe*/
          else
            v240 = nghttp2_http_on_trailer_headers(a1: v124, a2: (__int64)v276); /*0x103127eb4*/
LABEL_478:
          v8 = v278; /*0x103127ec3*/
          if ( v240 == 0 ) /*0x103127ec9*/
            goto LABEL_479; /*0x103127ec9*/
          goto LABEL_482; /*0x103127ec9*/
        }
LABEL_465:
        if ( v20 == 0 && v7 == v6 ) /*0x103127e56*/
          return __n; /*0x103127e56*/
        continue; /*0x103127e56*/
      case 6:
        v43 = v6 - v7; /*0x103125fd5*/
        v44 = *(_QWORD *)(v8 + 736); /*0x103125fd8*/
        v45 = v44; /*0x103125fe2*/
        if ( v6 - v7 < v44 ) /*0x103125fe5*/
          v45 = v6 - v7; /*0x103125fe5*/
        *(_QWORD *)(v8 + 736) = v44 - v45; /*0x103125fef*/
        v7 += v45; /*0x103125ff6*/
        if ( v44 > v43 ) /*0x103125ffc*/
          goto LABEL_396; /*0x103125ffc*/
        a3 = (size_t)v7; /*0x103126002*/
        v46 = *(unsigned __int8 *)(v8 + 540); /*0x103126005*/
        if ( v46 <= 9 ) /*0x103126010*/
        {
          v47 = 546; /*0x103126012*/
          if ( _bittest(&v47, v46) ) /*0x103126017*/
            *(_BYTE *)(v8 + 1964) = 1; /*0x10312601c*/
        }
        v48 = v8; /*0x103126024*/
        goto LABEL_275; /*0x103126027*/
      case 7:
        v251 = *(unsigned int *)(v8 + 2620); /*0x103128114*/
        v245 = v8; /*0x10312811b*/
        v246 = 6; /*0x10312811e*/
        v252 = nullptr; /*0x103128123*/
        goto LABEL_521; /*0x103128123*/
      case 8:
        v76 = *(char **)(v8 + 656); /*0x103126332*/
        v77 = *(_QWORD *)(v8 + 664) - (_QWORD)v76; /*0x103126340*/
        if ( v6 - v7 < v77 ) /*0x103126346*/
          v77 = v6 - v7; /*0x103126346*/
        v78 = nghttp2_cpymem(__dst: v76, a2: v7, a3: v77); /*0x103126350*/
        v8 = v278; /*0x103126355*/
        *(_QWORD *)(v278 + 656) = v78; /*0x10312635c*/
        v79 = *(char **)(v8 + 664); /*0x103126363*/
        v80 = *(_QWORD *)(v8 + 736) - v77; /*0x103126371*/
        *(_QWORD *)(v8 + 736) = v80; /*0x103126374*/
        v7 = (char *)(v77 + a3); /*0x10312637b*/
        if ( v79 != v78 ) /*0x103126381*/
          goto LABEL_396; /*0x103126381*/
        if ( v77 == 0 ) /*0x10312638a*/
          goto LABEL_394; /*0x10312638a*/
        v81 = (char *)(v77 + a3); /*0x103126390*/
        a3 = v8; /*0x10312639e*/
        nghttp2_frame_unpack_settings_entry(a1: &v269, a2: *(_QWORD *)(v8 + 648)); /*0x1031263a1*/
        if ( (unsigned int)(v269 - 1) >= 6 && (unsigned int)(v269 - 8) >= 2 ) /*0x1031263b7*/
        {
          v219 = *(_QWORD *)(a3 + 624); /*0x1031278de*/
          v220 = *(_QWORD *)(a3 + 720); /*0x1031278e5*/
          *(_QWORD *)(a3 + 720) = v220 + 1; /*0x1031278f0*/
          *(_QWORD *)(v219 + 8 * v220) = v269; /*0x1031278fb*/
          v7 = v81; /*0x1031278ff*/
          v8 = a3; /*0x103127902*/
          goto LABEL_393; /*0x103127902*/
        }
        v82 = *(_QWORD *)(a3 + 624); /*0x1031263bd*/
        v83 = *(_QWORD *)(a3 + 720); /*0x1031263c4*/
        v7 = v81; /*0x1031263ce*/
        v8 = a3; /*0x1031263d1*/
        if ( v83 != 0 ) /*0x1031263d4*/
        {
          v84 = 0; /*0x1031263da*/
          while ( *(_DWORD *)(v82 + 8 * v84) != (_DWORD)v269 ) /*0x1031263df*/
          {
            if ( v83 == ++v84 ) /*0x1031263eb*/
            {
              v84 = *(_QWORD *)(a3 + 720); /*0x1031263ed*/
              goto LABEL_351; /*0x1031263f0*/
            }
          }
          *(_QWORD *)(v82 + 8 * v84) = v269; /*0x103127612*/
          if ( *v262 != v84 ) /*0x103127620*/
            goto LABEL_352; /*0x103127620*/
          v82 = *(_QWORD *)(a3 + 624); /*0x103127622*/
        }
        else
        {
          v84 = 0; /*0x1031274de*/
        }
LABEL_351:
        *v262 = v84 + 1; /*0x103127629*/
        *(_QWORD *)(v82 + 8 * v84) = v269; /*0x10312763b*/
LABEL_352:
        if ( (_DWORD)v269 == 1 ) /*0x103127643*/
        {
          v207 = *(_QWORD *)(a3 + 624); /*0x103127649*/
          v208 = *(_QWORD *)(a3 + 728); /*0x103127650*/
          if ( HIDWORD(v269) < *(_DWORD *)(v207 + 8 * v208 - 4) ) /*0x10312765e*/
            *(_DWORD *)(v207 + 8 * v208 - 4) = HIDWORD(v269); /*0x103127664*/
        }
LABEL_393:
        v80 = *(_QWORD *)(v8 + 736); /*0x103127905*/
LABEL_394:
        if ( v80 != 0 ) /*0x10312790f*/
        {
          v221 = v7; /*0x103127915*/
          nghttp2_buf_reset(a1: v274); /*0x103127918*/
          v8 = v278; /*0x10312791d*/
          v7 = v221; /*0x103127921*/
          *(_QWORD *)(v278 + 664) += 6LL; /*0x103127924*/
          goto LABEL_396; /*0x103127924*/
        }
        v222 = *(_QWORD *)(v8 + 624); /*0x103127933*/
        v223 = *(_QWORD *)(v8 + 728); /*0x10312793a*/
        if ( v223 == 0 || (v224 = *(_QWORD *)(v222 + 8 * v223 - 8), HIDWORD(v224) == -1) ) /*0x103127955*/
        {
          v68 = v5; /*0x1031279ab*/
          a3 = (size_t)v7; /*0x1031279ae*/
        }
        else
        {
          v225 = *v262; /*0x10312795e*/
          v226 = 0; /*0x103127961*/
          if ( *v262 != 0 ) /*0x103127966*/
          {
            while ( *(_DWORD *)(v222 + 8 * v226) != 1 ) /*0x10312796c*/
            {
              if ( v225 == ++v226 ) /*0x103127974*/
              {
                v226 = *v262; /*0x103127976*/
                break; /*0x103127976*/
              }
            }
          }
          v68 = v5; /*0x103127979*/
          a3 = (size_t)v7; /*0x10312797c*/
          if ( HIDWORD(v224) != *(_DWORD *)(v222 + 8 * v226 + 4) ) /*0x103127983*/
          {
            *(_QWORD *)(v8 + 720) = v225 + 1; /*0x10312798e*/
            *(_QWORD *)(v222 + 8 * v225) = *(_QWORD *)(v222 + 8 * v226); /*0x103127999*/
            v222 = *(_QWORD *)(v8 + 624); /*0x10312799d*/
            *(_QWORD *)(v222 + 8 * v226) = v224; /*0x1031279a4*/
          }
        }
        v227 = v276; /*0x1031279b8*/
        v70 = v8; /*0x1031279bf*/
        nghttp2_frame_unpack_settings_payload(a1: (__int64)v276, a2: v222, a3: *(_QWORD *)(v8 + 720)); /*0x1031279c2*/
        *(_QWORD *)(v70 + 624) = 0; /*0x1031279c7*/
        *(_OWORD *)v262 = 0; /*0x1031279dd*/
        updated = nghttp2_session_on_settings_received(a1: v70, a2: (__int64)v227, a3: 0); /*0x1031279e9*/
LABEL_407:
        if ( updated <= -901 ) /*0x1031279f3*/
          return updated; /*0x1031279f3*/
        if ( *(_DWORD *)(v70 + 752) == 15 ) /*0x103127a01*/
          return __n; /*0x103127a01*/
        session_inbound_frame_reset(a1: v70); /*0x103127a0a*/
        v8 = v278; /*0x103127a0f*/
        v20 = 0; /*0x103127a13*/
        v7 = (char *)a3; /*0x103127a15*/
        goto LABEL_410; /*0x103127a15*/
      case 9:
        v65 = v6 - v7; /*0x1031261e1*/
        v66 = *(_QWORD *)(v8 + 736); /*0x1031261e4*/
        if ( v6 - v7 >= v66 ) /*0x1031261ee*/
          v65 = *(_QWORD *)(v8 + 736); /*0x1031261ee*/
        if ( v65 != 0 ) /*0x1031261f5*/
        {
          v67 = nghttp2_cpymem(__dst: *(char **)(v8 + 696), a2: v7, a3: v65); /*0x103126204*/
          v8 = v278; /*0x103126209*/
          *(_QWORD *)(v278 + 696) = v67; /*0x103126210*/
          v66 = *(_QWORD *)(v8 + 736) - v65; /*0x10312621e*/
          *(_QWORD *)(v8 + 736) = v66; /*0x103126221*/
          v7 = (char *)(v65 + a3); /*0x103126228*/
        }
        if ( v66 != 0 ) /*0x10312622e*/
          goto LABEL_396; /*0x10312622e*/
        v68 = v5; /*0x103126234*/
        a3 = (size_t)v7; /*0x103126237*/
        v69 = v276; /*0x103126252*/
        v70 = v8; /*0x103126259*/
        nghttp2_frame_unpack_goaway_payload( /*0x10312625c*/
          a1: (__int64)v276,
          a2: *(_QWORD *)(v8 + 648),
          a3: *(_QWORD *)(v8 + 688),
          a4: *(_QWORD *)(v8 + 696) - *(_QWORD *)(v8 + 688));
        nghttp2_buf_wrap_init(a1: v264, a2: 0, a3: 0); /*0x10312626c*/
        updated = nghttp2_session_on_goaway_received(a1: v70, a2: (__int64)v69); /*0x103126277*/
        goto LABEL_407; /*0x10312627c*/
      case 0xA:
      case 0xB:
        v21 = *(_QWORD *)(v8 + 2600) + 1LL; /*0x103125d54*/
        *(_QWORD *)(v8 + 2600) = v21; /*0x103125d57*/
        if ( v21 > *(_QWORD *)(v8 + 2592) ) /*0x103125d65*/
          return -905; /*0x1031280b0*/
        v22 = *(char **)(v8 + 656); /*0x103125d71*/
        v23 = *(_QWORD *)(v8 + 664) - (_QWORD)v22; /*0x103125d7f*/
        if ( v6 - v7 < v23 ) /*0x103125d85*/
          v23 = v6 - v7; /*0x103125d85*/
        v24 = nghttp2_cpymem(__dst: v22, a2: v7, a3: v23); /*0x103125d8f*/
        v25 = v278; /*0x103125d94*/
        *(_QWORD *)(v278 + 656) = v24; /*0x103125d98*/
        a3 += v23; /*0x103125d9f*/
        if ( *(char **)(v25 + 664) != v24 ) /*0x103125da9*/
        {
LABEL_511:
          a3 -= (unsigned __int64)v5; /*0x103128096*/
          return a3; /*0x103128099*/
        }
        nghttp2_frame_unpack_frame_hd(a1: (__int64)&v253, a2: *(_QWORD *)(v25 + 648)); /*0x103125dbd*/
        v8 = v278; /*0x103125dc2*/
        v26 = v253; /*0x103125dc6*/
        *(_QWORD *)(v278 + 736) = v253; /*0x103125dcd*/
        if ( v255 != 9 || v254 != *(_DWORD *)(v8 + 536) ) /*0x103125dee*/
        {
          v251 = *(unsigned int *)(v8 + 2620); /*0x10312807b*/
          v252 = "unexpected non-CONTINUATION frame or stream_id is invalid"; /*0x103128082*/
          goto LABEL_509; /*0x103128082*/
        }
        *(_BYTE *)(v8 + 541) |= v256 & 4; /*0x103125dfd*/
        *(_QWORD *)(v8 + 528) += v26; /*0x103125e04*/
        if ( *(_DWORD *)(v8 + 752) != 10 ) /*0x103125e13*/
          goto LABEL_462; /*0x103125e13*/
        *(_DWORD *)(v8 + 752) = 4; /*0x103125e19*/
        v27 = *(unsigned int (__fastcall **)(__int64, __int64 *, _QWORD))(v8 + 2304); /*0x103125e24*/
        v20 = 1; /*0x103125e2b*/
        if ( v27 == nullptr ) /*0x103125e33*/
          goto LABEL_464; /*0x103125e33*/
        v28 = v5; /*0x103125e39*/
        v29 = v8; /*0x103125e4d*/
        if ( v27(a1: v8, a2: &v253, a3: *(_QWORD *)(v8 + 2416)) != 0 ) /*0x103125e54*/
          return -902; /*0x103125e54*/
        v30 = *(_DWORD *)(v29 + 752) == 15; /*0x103125e5a*/
        v7 = (char *)a3; /*0x103125e62*/
        v8 = v29; /*0x103125e65*/
        v5 = v28; /*0x103125e68*/
        if ( v30 ) /*0x103125e6b*/
          return __n; /*0x103125e6b*/
        goto LABEL_465; /*0x103125e6b*/
      case 0xC:
        v51 = *(char **)(v8 + 656); /*0x10312606c*/
        v52 = *(_QWORD *)(v8 + 664) - (_QWORD)v51; /*0x10312607a*/
        if ( v6 - v7 < v52 ) /*0x103126080*/
          v52 = v6 - v7; /*0x103126080*/
        v53 = nghttp2_cpymem(__dst: v51, a2: v7, a3: v52); /*0x10312608a*/
        v54 = v278; /*0x10312608f*/
        *(_QWORD *)(v278 + 656) = v53; /*0x103126093*/
        *(_QWORD *)(v54 + 736) -= v52; /*0x10312609a*/
        a3 += v52; /*0x1031260a1*/
        if ( *(char **)(v54 + 664) != v53 ) /*0x1031260ab*/
          goto LABEL_511; /*0x1031260ab*/
        v55 = v5; /*0x1031260b1*/
        v56 = v54; /*0x1031260b7*/
        updated = nghttp2_session_update_recv_connection_window_size(a1: v54, a2: v52); /*0x1031260ba*/
        if ( updated <= -901 ) /*0x1031260c4*/
          return updated; /*0x1031260c4*/
        if ( *(_DWORD *)(v56 + 752) == 15 ) /*0x1031260d2*/
          return __n; /*0x1031260d2*/
        updated = nghttp2_session_consume(a1: v56, a2: *(unsigned int *)(v56 + 536), a3: v52); /*0x1031260e5*/
        if ( updated <= -901 ) /*0x1031260ef*/
          return updated; /*0x1031260ef*/
        if ( *(_DWORD *)(v56 + 752) == 15 ) /*0x1031260fd*/
          return __n; /*0x1031260fd*/
        v57 = nghttp2_map_find(a1: v56, a2: *(_DWORD *)(v56 + 536)); /*0x10312610d*/
        v8 = v278; /*0x103126112*/
        v5 = v55; /*0x103126119*/
        if ( v57 != 0 && (*(_BYTE *)(v57 + 116) & 2) == 0 && *(_DWORD *)v57 != 5 ) /*0x103126127*/
        {
          v58 = true; /*0x103126129*/
          if ( *(_QWORD *)(v278 + 736) == 0 ) /*0x103126136*/
            v58 = (*(_BYTE *)(v278 + 541) & 1) == 0; /*0x103126142*/
          v59 = v52; /*0x10312614b*/
          v60 = v278; /*0x10312614e*/
          updated = nghttp2_session_update_recv_stream_window_size(a1: v278, a2: v57, a3: v59, a4: v58); /*0x103126151*/
          if ( updated <= -901 ) /*0x10312615b*/
            return updated; /*0x10312615b*/
          v8 = v60; /*0x103126168*/
          if ( *(_DWORD *)(v60 + 752) == 15 ) /*0x10312616b*/
            return __n; /*0x10312616b*/
        }
        v61 = *(_QWORD *)(v8 + 736); /*0x103126171*/
        v62 = **(unsigned __int8 **)(v8 + 648); /*0x10312617f*/
        if ( v61 < v62 )
        {
          v251 = *(unsigned int *)(v8 + 2620); /*0x10312814b*/
          v252 = "DATA: invalid padding";
          goto LABEL_509; /*0x103128159*/
        }
        v63 = v62 + 1; /*0x10312618b*/
        *(_QWORD *)(v8 + 744) = v63; /*0x10312618e*/
        *(_QWORD *)(v8 + 544) = v63; /*0x103126195*/
        if ( v61 == 0 && (*(_BYTE *)(v8 + 541) & 1) == 0 ) /*0x1031261a9*/
        {
          v64 = v8; /*0x1031261ae*/
          updated = session_update_glitch_ratelim(a1: v8); /*0x1031261b1*/
          if ( updated != 0 ) /*0x1031261b8*/
            return updated; /*0x1031261b8*/
          v8 = v64; /*0x1031261c5*/
          if ( *(_DWORD *)(v64 + 752) == 15 ) /*0x1031261c8*/
            return __n; /*0x1031261c8*/
        }
        *(_DWORD *)(v8 + 752) = 13; /*0x1031261ce*/
        goto LABEL_463; /*0x1031261d9*/
      case 0xD:
        v49 = nghttp2_map_find(a1: v8, a2: *(_DWORD *)(v8 + 536)); /*0x103126036*/
        if ( v49 == 0 || (v50 = v49, (*(_BYTE *)(v49 + 116) & 2) != 0) || *(_DWORD *)v49 == 5 ) /*0x10312604c*/
        {
          v8 = v278; /*0x103126052*/
          *(_DWORD *)(v278 + 752) = 14; /*0x103126056*/
LABEL_463:
          v20 = 1; /*0x103127e43*/
LABEL_464:
          v7 = (char *)a3; /*0x103127e48*/
          goto LABEL_465; /*0x103127e48*/
        }
        v140 = (__int64)&v6[-a3]; /*0x103126aac*/
        v8 = v278; /*0x103126aaf*/
        v141 = *(_QWORD *)(v278 + 736); /*0x103126ab3*/
        if ( (unsigned __int64)&v6[-a3] >= v141 ) /*0x103126abd*/
          v140 = *(_QWORD *)(v278 + 736); /*0x103126abd*/
        v142 = v141 - v140; /*0x103126ac1*/
        *(_QWORD *)(v278 + 736) = v142; /*0x103126ac4*/
        v143 = (char *)(a3 + v140); /*0x103126acb*/
        if ( v140 == 0 ) /*0x103126ad2*/
          goto LABEL_372; /*0x103126ad2*/
        v144 = v8; /*0x103126ade*/
        updated = nghttp2_session_update_recv_connection_window_size(a1: v8, a2: v140); /*0x103126ae1*/
        if ( updated <= -901 ) /*0x103126aeb*/
          return updated; /*0x103126aeb*/
        if ( *(_DWORD *)(v144 + 752) == 15 ) /*0x103126afa*/
          return __n; /*0x103126afa*/
        v145 = true; /*0x103126b03*/
        if ( *(_QWORD *)(v144 + 736) == 0 ) /*0x103126b11*/
          v145 = (*(_BYTE *)(v144 + 541) & 1) == 0; /*0x103126b1c*/
        updated = nghttp2_session_update_recv_stream_window_size(a1: v144, a2: v50, a3: v140, a4: v145); /*0x103126b28*/
        if ( updated <= -901 ) /*0x103126b32*/
          return updated; /*0x103126b32*/
        if ( *(_DWORD *)(v144 + 752) == 15 ) /*0x103126b41*/
          return __n; /*0x103126b41*/
        v146 = v144; /*0x103126b47*/
        v263 = (char *)(a3 + v140); /*0x103126b4a*/
        v147 = *(_QWORD *)(v144 + 736); /*0x103126b51*/
        v148 = nghttp2_frame_trail_padlen(a1: (__int64)v276, a2: *(_QWORD *)(v146 + 744)); /*0x103126b64*/
        v8 = v278; /*0x103126b69*/
        v149 = v140 - (v148 - v147); /*0x103126b76*/
        if ( v140 < v148 - v147 ) /*0x103126b80*/
          v149 = -1; /*0x103126b80*/
        if ( v148 <= v147 ) /*0x103126b87*/
          v149 = v140; /*0x103126b87*/
        v150 = 0; /*0x103126b8f*/
        if ( v149 != -1 ) /*0x103126b95*/
          v150 = v149; /*0x103126b95*/
        v151 = v140 <= v150; /*0x103126b99*/
        v152 = v140 - v150; /*0x103126b99*/
        if ( !v151 ) /*0x103126b9c*/
        {
          v153 = v152; /*0x103126ba8*/
          v154 = v278; /*0x103126bab*/
          updated = nghttp2_session_consume(a1: v278, a2: *(unsigned int *)(v278 + 536), a3: v153); /*0x103126bae*/
          if ( updated <= -901 ) /*0x103126bb8*/
            return updated; /*0x103126bb8*/
          v8 = v154; /*0x103126bc6*/
          if ( *(_DWORD *)(v154 + 752) == 15 ) /*0x103126bc9*/
            return __n; /*0x103126bc9*/
        }
        if ( v150 <= 0 ) /*0x103126bd2*/
          goto LABEL_371; /*0x103126bd2*/
        v155 = (_QWORD *)a3; /*0x103126bd8*/
        if ( (*(_BYTE *)(v8 + 2724) & 4) != 0 /*0x103126bfd*/
          || (v156 = nghttp2_http_on_data_chunk(a1: v50, a2: v150), v8 = v278, v155 = (_QWORD *)a3, v156 == 0) )
        {
          v211 = *(__int64 (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD *, __int64, _QWORD))(v8 + 2192); /*0x10312775a*/
          if ( v211 != nullptr ) /*0x103127764*/
          {
            v212 = v8; /*0x103127782*/
            v213 = v211( /*0x103127785*/
                     a1: v8,
                     a2: *(unsigned __int8 *)(v8 + 541),
                     a3: *(unsigned int *)(v8 + 536),
                     a4: v155,
                     a5: v150,
                     a6: *(_QWORD *)(v8 + 2416));
            if ( v213 < -900 ) /*0x10312778c*/
              return -902; /*0x10312778c*/
            if ( *(_DWORD *)(v212 + 752) == 15 ) /*0x103127799*/
              return __n; /*0x103127799*/
            v8 = v212; /*0x10312779f*/
            if ( v213 == -526 ) /*0x1031277a7*/
              return v263 - v273; /*0x103128225*/
          }
LABEL_371:
          v142 = *(_QWORD *)(v8 + 736); /*0x1031277ad*/
          v143 = v263; /*0x1031277b4*/
LABEL_372:
          if ( v142 != 0 ) /*0x1031277be*/
          {
            v20 = 0; /*0x1031277c0*/
            v7 = v143; /*0x1031277c2*/
            v5 = v273; /*0x1031277c5*/
LABEL_289:
            v6 = v275; /*0x103127142*/
            goto LABEL_465; /*0x103127146*/
          }
          v214 = v8; /*0x1031277d5*/
          updated = nghttp2_session_on_data_received(a1: v8, a2: (__int64)v276); /*0x1031277d8*/
          v6 = v275; /*0x1031277e2*/
          if ( updated <= -901 ) /*0x1031277e6*/
            return updated; /*0x1031277e6*/
          if ( *(_DWORD *)(v214 + 752) != 15 ) /*0x1031277f3*/
          {
            session_inbound_frame_reset(a1: v214); /*0x1031277fc*/
            v8 = v278; /*0x103127801*/
            v20 = 0; /*0x103127805*/
            v7 = v143; /*0x103127807*/
            goto LABEL_377; /*0x103127807*/
          }
        }
        else
        {
          v6 = v275; /*0x103126c0b*/
          if ( (*(_BYTE *)(v278 + 2724) & 1) == 0 ) /*0x103126c0f*/
            goto LABEL_222; /*0x103126c0f*/
          v157 = v278; /*0x103126c3c*/
          updated = session_update_consumed_size( /*0x103126c3f*/
                      a1: v278,
                      a2: v258,
                      a3: v259,
                      a4: *(unsigned __int8 *)(v278 + 2741),
                      a5: 0,
                      a6: v150,
                      a7: *(_DWORD *)(v278 + 2652));
          if ( updated <= -901 ) /*0x103126c4d*/
            return updated; /*0x103126c4d*/
          v8 = v157; /*0x103126c5a*/
          if ( *(_DWORD *)(v157 + 752) != 14 ) /*0x103126c5d*/
          {
LABEL_222:
            v158 = v8; /*0x103126c76*/
            updated = session_handle_invalid_stream2( /*0x103126c79*/
                        a1: v8,
                        a2: *(unsigned int *)(v8 + 536),
                        a3: v276,
                        a4: 4294966791LL);
            if ( updated <= -901 ) /*0x103126c83*/
              return updated; /*0x103126c83*/
            updated = session_update_glitch_ratelim(a1: v158); /*0x103126c8c*/
            if ( updated != 0 ) /*0x103126c93*/
              return updated; /*0x103126c93*/
            if ( *(_DWORD *)(v158 + 752) != 15 ) /*0x103126ca0*/
            {
              v8 = v158; /*0x103126ca6*/
              *(_DWORD *)(v158 + 752) = 14; /*0x103126ca9*/
              v20 = 1; /*0x103126cb3*/
              v7 = v263; /*0x103126cb8*/
              goto LABEL_377; /*0x103126cbf*/
            }
          }
        }
        return __n; /*0x103128076*/
      case 0xE:
        v37 = v6 - v7; /*0x103125f06*/
        v38 = *(_QWORD *)(v8 + 736); /*0x103125f09*/
        if ( v6 - v7 >= v38 ) /*0x103125f13*/
          v37 = *(_QWORD *)(v8 + 736); /*0x103125f13*/
        v39 = v38 - v37; /*0x103125f17*/
        *(_QWORD *)(v8 + 736) = v39; /*0x103125f1a*/
        if ( v37 == 0 ) /*0x103125f24*/
          goto LABEL_52; /*0x103125f24*/
        v40 = v5; /*0x103125f2a*/
        v41 = v8; /*0x103125f33*/
        updated = nghttp2_session_update_recv_connection_window_size(a1: v8, a2: v37); /*0x103125f36*/
        if ( updated <= -901 ) /*0x103125f40*/
          return updated; /*0x103125f40*/
        if ( *(_DWORD *)(v41 + 752) == 15 ) /*0x103125f4e*/
          return __n; /*0x103125f4e*/
        v8 = v41; /*0x103125f54*/
        if ( (*(_BYTE *)(v41 + 2724) & 1) != 0 ) /*0x103125f5f*/
        {
          updated = session_update_consumed_size( /*0x103125f8f*/
                      a1: v41,
                      a2: v258,
                      a3: v259,
                      a4: *(unsigned __int8 *)(v41 + 2741),
                      a5: 0,
                      a6: v37,
                      a7: *(_DWORD *)(v41 + 2652));
          if ( updated <= -901 ) /*0x103125f9d*/
            return updated; /*0x103125f9d*/
          v8 = v41; /*0x103125fab*/
          if ( *(_DWORD *)(v41 + 752) == 15 ) /*0x103125fae*/
            return __n; /*0x103125fae*/
        }
        v39 = *(_QWORD *)(v8 + 736); /*0x103125fb4*/
        v7 = (char *)a3; /*0x103125fbb*/
        v5 = v40; /*0x103125fbe*/
LABEL_52:
        v7 += v37; /*0x103125fc1*/
        if ( v39 == 0 ) /*0x103125fc7*/
        {
LABEL_132:
          v112 = v7; /*0x103126640*/
          session_inbound_frame_reset(a1: v8); /*0x103126646*/
          v8 = v278; /*0x10312664b*/
          v7 = v112; /*0x10312664f*/
        }
        goto LABEL_396; /*0x103126652*/
      case 0xF:
        return __n;
      case 0x10:
        v71 = v6 - v7; /*0x103126284*/
        v72 = *(_QWORD *)(v8 + 736); /*0x103126287*/
        if ( v6 - v7 >= v72 ) /*0x103126291*/
          v71 = *(_QWORD *)(v8 + 736); /*0x103126291*/
        if ( v71 != 0 ) /*0x103126298*/
        {
          v73 = nghttp2_cpymem(__dst: *(char **)(v8 + 696), a2: v7, a3: v71); /*0x1031262a7*/
          v8 = v278; /*0x1031262ac*/
          *(_QWORD *)(v278 + 696) = v73; /*0x1031262b3*/
          v72 = *(_QWORD *)(v8 + 736) - v71; /*0x1031262c1*/
          *(_QWORD *)(v8 + 736) = v72; /*0x1031262c4*/
          v7 = (char *)(v71 + a3); /*0x1031262cb*/
        }
        if ( v72 != 0 ) /*0x1031262d1*/
          goto LABEL_396; /*0x1031262d1*/
        v68 = v5; /*0x1031262d7*/
        a3 = (size_t)v7; /*0x1031262da*/
        v70 = v8; /*0x1031262e4*/
        v74 = nghttp2_get_uint16(a1: *(_WORD **)(v8 + 648)); /*0x1031262e7*/
        v75 = v276; /*0x103126300*/
        nghttp2_frame_unpack_altsvc_payload( /*0x103126307*/
          a1: (__int64)v276,
          a2: v74,
          a3: *(_QWORD *)(v70 + 688),
          a4: *(_QWORD *)(v70 + 696) - *(_QWORD *)(v70 + 688));
        nghttp2_buf_wrap_init(a1: v264, a2: 0, a3: 0); /*0x103126317*/
        updated = nghttp2_session_on_altsvc_received(a1: (_QWORD *)v70, a2: (__int64)v75); /*0x103126322*/
        goto LABEL_407; /*0x103126327*/
      case 0x11:
        v113 = v6 - v7; /*0x10312665a*/
        v114 = *(_QWORD *)(v8 + 736); /*0x10312665d*/
        if ( v6 - v7 >= v114 ) /*0x103126667*/
          v113 = *(_QWORD *)(v8 + 736); /*0x103126667*/
        if ( v113 != 0 ) /*0x10312666e*/
        {
          v115 = nghttp2_cpymem(__dst: *(char **)(v8 + 696), a2: v7, a3: v113); /*0x10312667d*/
          v8 = v278; /*0x103126682*/
          *(_QWORD *)(v278 + 696) = v115; /*0x103126689*/
          v114 = *(_QWORD *)(v8 + 736) - v113; /*0x103126697*/
          *(_QWORD *)(v8 + 736) = v114; /*0x10312669a*/
          v7 = (char *)(v113 + a3); /*0x1031266a1*/
        }
        if ( v114 != 0 ) /*0x1031266a7*/
          goto LABEL_396; /*0x1031266a7*/
        a3 = (size_t)v7; /*0x1031266ad*/
        v116 = v8; /*0x1031266cc*/
        updated = nghttp2_frame_unpack_origin_payload( /*0x1031266cf*/
                    a1: (__int64)v276,
                    a2: *(_QWORD *)(v8 + 688),
                    a3: *(_QWORD *)(v8 + 696) - *(_QWORD *)(v8 + 688),
                    a4: v265);
        if ( updated != 0 ) /*0x1031266d6*/
        {
          v48 = v116; /*0x1031266e1*/
          if ( updated <= -901 ) /*0x1031266e4*/
            return updated; /*0x1031266e4*/
        }
        else
        {
          v177 = *(__int64 (__fastcall **)(__int64, __int64 *, _QWORD))(v116 + 2176); /*0x10312706d*/
          v48 = v116; /*0x103127077*/
          if ( v177 != nullptr ) /*0x10312707a*/
          {
            v178 = v177(a1: v116, a2: v276, a3: *(_QWORD *)(v116 + 2416)); /*0x103127087*/
            v48 = v278; /*0x103127089*/
            if ( v178 != 0 ) /*0x10312708f*/
              return -902; /*0x10312708f*/
          }
        }
        if ( *(_DWORD *)(v48 + 752) == 15 ) /*0x10312709c*/
          return __n; /*0x10312709c*/
LABEL_275:
        session_inbound_frame_reset(a1: v48); /*0x1031270a2*/
        v8 = v278; /*0x1031270a7*/
        goto LABEL_276; /*0x1031270a7*/
      case 0x12:
        v31 = v6 - v7; /*0x103125e76*/
        v32 = *(_QWORD *)(v8 + 736); /*0x103125e79*/
        if ( v31 >= v32 ) /*0x103125e83*/
          v31 = *(_QWORD *)(v8 + 736); /*0x103125e83*/
        v33 = v32 - v31; /*0x103125e87*/
        *(_QWORD *)(v8 + 736) = v33; /*0x103125e8a*/
        v34 = &v7[v31]; /*0x103125e91*/
        if ( v31 == 0 ) /*0x103125e98*/
          goto LABEL_278; /*0x103125e98*/
        v35 = *(__int64 (__fastcall **)(__int64, __int64 *, char *, unsigned __int64, _QWORD))(v8 + 2344); /*0x103125e9e*/
        if ( v35 == nullptr ) /*0x103125ea8*/
          goto LABEL_278; /*0x103125ea8*/
        v36 = v35(a1: v8, a2: v276, a3: v7, a4: v31, a5: *(_QWORD *)(v8 + 2416)); /*0x103125ec2*/
        if ( v36 != 0 && v36 != -535 ) /*0x103125ece*/
          return -902; /*0x103125ece*/
        v8 = v278; /*0x103125ed4*/
        if ( *(_DWORD *)(v278 + 752) == 15 ) /*0x103125ee0*/
          return __n; /*0x103125ee0*/
        if ( v36 != 0 ) /*0x103125ee8*/
        {
          *(_DWORD *)(v278 + 752) = 6; /*0x103125eee*/
          v20 = 1; /*0x103125ef9*/
        }
        else
        {
          v33 = *(_QWORD *)(v278 + 736); /*0x1031270b2*/
LABEL_278:
          if ( v33 == 0 ) /*0x1031270bc*/
          {
            v269 = 0; /*0x1031270be*/
            v179 = (*(__int64 (__fastcall **)(__int64, __int64 *, __int64 *, _QWORD))(v8 + 2336))( /*0x1031270d8*/
                     a1: v8,
                     a2: &v269,
                     a3: v276,
                     a4: *(_QWORD *)(v8 + 2416));
            if ( v179 == -535 ) /*0x1031270e4*/
            {
              v180 = v278; /*0x103127123*/
            }
            else
            {
              if ( v179 != 0 ) /*0x1031270e8*/
                return -902; /*0x1031270e8*/
              v180 = v278; /*0x1031270f2*/
              *(_QWORD *)(v278 + 544) = v269; /*0x1031270f6*/
              v181 = *(__int64 (__fastcall **)(__int64, __int64 *, _QWORD))(v180 + 2176); /*0x1031270fd*/
              if ( v181 != nullptr ) /*0x103127107*/
              {
                v182 = v181(a1: v180, a2: v276, a3: *(_QWORD *)(v180 + 2416)); /*0x103127114*/
                v180 = v278; /*0x103127116*/
                if ( v182 != 0 ) /*0x10312711c*/
                  return -902; /*0x103128112*/
              }
            }
            if ( *(_DWORD *)(v180 + 752) == 15 ) /*0x10312712e*/
              return __n; /*0x10312712e*/
            session_inbound_frame_reset(a1: v180); /*0x103127134*/
            v8 = v278; /*0x103127139*/
          }
          v20 = 0; /*0x10312713d*/
        }
        v7 = v34; /*0x10312713f*/
        goto LABEL_289; /*0x10312713f*/
      default:
        a3 = (size_t)v9; /*0xf1c0000000000004*/
        goto LABEL_396; /*0xf1c0000000000004*/
    }
  }
}

// Address: 0x10312830c | Name: _nghttp2_session_want_read
_BOOL8 __fastcall nghttp2_session_want_read(__int64 a1)
{
  _BOOL8 result; // rax
  __int64 v3; // rcx

  result = false; /*0x10312830c*/
  if ( (*(_BYTE *)(a1 + 2740) & 2) == 0 ) /*0x103128315*/
  {
    v3 = nghttp2_map_size(a1); /*0x103128325*/
    result = true; /*0x103128336*/
    if ( v3 == *(_QWORD *)(a1 + 2536) + *(_QWORD *)(a1 + 2544) ) /*0x10312833e*/
      return (*(_BYTE *)(a1 + 2740) & 0xC) == 0; /*0x103128349*/
  }
  return result; /*0x103128352*/
}

// Address: 0x103128713 | Name: _nghttp2_session_consume
__int64 __fastcall nghttp2_session_consume(__int64 a1, int a2, int a3)
{
  __int64 result; // rax
  __int64 v7; // rax
  __int64 v8; // rdi
  int updated; // ecx

  if ( a2 == 0 ) /*0x103128715*/
    return 4294966795LL; /*0x1031287cb*/
  result = 4294966777LL; /*0x103128728*/
  if ( (*(_BYTE *)(a1 + 2724) & 1) != 0 ) /*0x103128734*/
  {
    result = session_update_consumed_size( /*0x103128769*/
               a1,
               a2: (int)a1 + 2644,
               a3: (int)a1 + 2640,
               a4: *(unsigned __int8 *)(a1 + 2741),
               a5: 0,
               a6: a3,
               a7: *(_DWORD *)(a1 + 2652));
    if ( (int)result >= -900 ) /*0x103128773*/
    {
      v7 = nghttp2_map_find(a1, a2); /*0x10312877b*/
      if ( v7 == 0 ) /*0x103128783*/
        return 0; /*0x103128783*/
      v8 = v7; /*0x103128785*/
      if ( (*(_BYTE *)(v7 + 116) & 2) != 0 ) /*0x10312878c*/
      {
        return 0; /*0x1031287d1*/
      }
      else
      {
        result = 0; /*0x103128791*/
        if ( *(_DWORD *)v8 != 5 ) /*0x103128796*/
        {
          updated = session_update_consumed_size( /*0x1031287bc*/
                      a1,
                      a2: (int)v8 + 92,
                      a3: (int)v8 + 88,
                      a4: *(unsigned __int8 *)(v8 + 119),
                      a5: *(_DWORD *)(v8 + 80),
                      a6: a3,
                      a7: *(_DWORD *)(v8 + 100));
          result = 0; /*0x1031287be*/
          if ( updated < -900 ) /*0x1031287c6*/
            return (unsigned int)updated; /*0x1031287c6*/
        }
      }
    }
  }
  return result; /*0x1031287d0*/
}

// Address: 0x1031287de | Name: _nghttp2_session_recv
signed __int64 __fastcall nghttp2_session_recv(_QWORD *a1)
{
  __int64 (__fastcall *v2)(_QWORD *, char *, __int64, _QWORD, _QWORD); // rax
  signed __int64 v3; // rax
  signed __int64 v4; // rdx
  signed __int64 result; // rax
  char v6[16392]; // [rsp+0h] [rbp-4020h] BYREF

  while ( 1 ) /*0x103128804*/
  {
    v2 = (__int64 (__fastcall *)(_QWORD *, char *, __int64, _QWORD, _QWORD))a1[271]; /*0x103128804*/
    if ( v2 == nullptr ) /*0x10312880e*/
      v2 = (__int64 (__fastcall *)(_QWORD *, char *, __int64, _QWORD, _QWORD))a1[270]; /*0x103128810*/
    v3 = v2(a1, a2: v6, a3: 0x4000, a4: 0, a5: a1[302]); /*0x10312882b*/
    v4 = v3; /*0x10312882d*/
    if ( v3 <= 0 ) /*0x103128833*/
      break; /*0x103128833*/
    if ( (unsigned __int64)v3 > 0x4000 ) /*0x10312883c*/
      return 4294966394LL; /*0x10312883c*/
    result = nghttp2_session_mem_recv2((__int64)a1, a2: v6, a3: v3); /*0x103128844*/
    if ( result < 0 ) /*0x10312884c*/
      return result; /*0x10312884c*/
  }
  result = 0; /*0x103128850*/
  if ( v4 != 0 && v4 != -504 ) /*0x10312885e*/
  {
    if ( v4 == -507 ) /*0x103128867*/
      return 4294966789LL; /*0x10312886e*/
    return 4294966394LL; /*0x103128870*/
  }
  return result; /*0x103128885*/
}

// Address: 0x103128896 | Name: _nghttp2_session_want_write
__int64 __fastcall nghttp2_session_want_write(__int64 a1)
{
  unsigned int v1; // ebx
  __int64 v3; // r15

  v1 = 0; /*0x1031288a0*/
  if ( (*(_BYTE *)(a1 + 2740) & 2) == 0 ) /*0x1031288a9*/
  {
    v1 = 1; /*0x1031288ae*/
    if ( *(_QWORD *)(a1 + 448) == 0 && *(_QWORD *)(a1 + 56) == 0 && *(_QWORD *)(a1 + 80) == 0 ) /*0x1031288c9*/
    {
      v3 = 128; /*0x1031288cb*/
      while ( nghttp2_pq_empty(a1: a1 + v3) ) /*0x1031288dc*/
      {
        v3 += 40; /*0x1031288de*/
        if ( v3 == 448 ) /*0x1031288e9*/
          goto LABEL_10; /*0x1031288e9*/
      }
      if ( *(int *)(a1 + 2636) > 0 ) /*0x1031288f5*/
        return v1; /*0x1031288f5*/
LABEL_10:
      v1 = 0; /*0x1031288f7*/
      if ( *(_QWORD *)(a1 + 104) != 0 ) /*0x103128901*/
        return *(_QWORD *)(a1 + 2504) < (unsigned __int64)*(unsigned int *)(a1 + 2668); /*0x103128913*/
    }
  }
  return v1; /*0x10312891c*/
}

// Address: 0x103128923 | Name: _nghttp2_session_add_goaway
__int64 __fastcall nghttp2_session_add_goaway(__int64 a1, int a2, int a3, const void *a4, size_t a5, char a6)
{
  unsigned int v10; // r13d
  __int64 v11; // rdi
  void *v12; // rax
  __int64 v13; // r13
  __int64 v14; // rax
  __int64 v15; // r15
  int v16; // esi
  unsigned int v17; // eax
  __int64 v19; // [rsp+0h] [rbp-40h]
  __int64 v20; // [rsp+8h] [rbp-38h]
  char v21; // [rsp+10h] [rbp-30h]
  int v22; // [rsp+14h] [rbp-2Ch]

  if ( a2 != 0 ) /*0x103128942*/
  {
    v10 = -501; /*0x103128953*/
    if ( (*(_BYTE *)(a1 + 2739) == 0) == (a2 & 1) ) /*0x10312895b*/
      return v10; /*0x10312895b*/
  }
  v11 = a1 + 2376; /*0x103128961*/
  if ( a5 != 0 ) /*0x10312896b*/
  {
    v10 = -501; /*0x103128975*/
    if ( a5 - 16377 < 0xFFFFFFFFFFFFBFFFLL ) /*0x103128981*/
      return v10; /*0x103128981*/
    v22 = a3; /*0x103128987*/
    v21 = a6; /*0x10312898a*/
    v12 = (void *)nghttp2_mem_malloc(a1: v11, a2: a5); /*0x103128994*/
    if ( v12 == nullptr ) /*0x10312899c*/
      return (unsigned int)-901; /*0x103128a4f*/
    v20 = (__int64)v12; /*0x1031289a2*/
    memcpy(__dst: v12, __src: a4, __n: a5); /*0x1031289af*/
    v11 = a1 + 2376; /*0x1031289b4*/
  }
  else
  {
    v22 = a3; /*0x1031289b9*/
    v21 = a6; /*0x1031289bc*/
    v20 = 0; /*0x1031289c0*/
  }
  v13 = v11; /*0x1031289cd*/
  v14 = nghttp2_mem_malloc(a1: v11, a2: 160); /*0x1031289d0*/
  if ( v14 == 0 ) /*0x1031289d8*/
  {
    nghttp2_mem_free(a1: v13, a2: v20); /*0x103128a44*/
    return (unsigned int)-901; /*0x103128a44*/
  }
  v15 = v14; /*0x1031289da*/
  v19 = v13; /*0x1031289dd*/
  nghttp2_outbound_item_init(a1: v14); /*0x1031289e4*/
  v16 = *(_DWORD *)(a1 + 2628); /*0x1031289e9*/
  if ( a2 < v16 ) /*0x1031289f2*/
    v16 = a2; /*0x1031289f2*/
  nghttp2_frame_goaway_init(a1: v15, a2: v16, a3: v22, a4: v20, a5); /*0x103128a03*/
  *(_BYTE *)(v15 + 96) = v21; /*0x103128a0b*/
  v17 = nghttp2_session_add_item(a1, a2: v15); /*0x103128a15*/
  if ( v17 != 0 ) /*0x103128a1c*/
  {
    v10 = v17; /*0x103128a1e*/
    nghttp2_frame_goaway_free(a1: v15, a2: v19); /*0x103128a2b*/
    nghttp2_mem_free(a1: v19, a2: v15); /*0x103128a36*/
  }
  else
  {
    *(_BYTE *)(a1 + 2740) |= 0x10u; /*0x103128a51*/
    return 0; /*0x103128a58*/
  }
  return v10; /*0x103128a5e*/
}

// Address: 0x103128a6d | Name: _nghttp2_session_pack_data
__int64 __fastcall nghttp2_session_pack_data(
        __int64 a1,
        __int64 *a2,
        unsigned __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  unsigned __int64 v8; // r10
  _QWORD *v10; // r13
  __int64 (__fastcall *v11)(__int64, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  __int64 v12; // r14
  int v13; // eax
  __int64 v14; // rcx
  int v15; // eax
  __int64 v16; // rdx
  unsigned __int64 v17; // rbx
  int v18; // eax
  __int64 result; // rax
  unsigned __int64 v20; // r14
  __int64 v21; // rbx
  __int64 v22; // rcx
  __int64 v23; // rcx
  char v24; // cl
  unsigned __int64 v25; // rdx
  __int64 *v26; // rax
  __int64 v27; // r12
  __int64 *v28; // rbx
  __int64 v30; // [rsp+10h] [rbp-40h]
  __int64 v32; // [rsp+18h] [rbp-38h]
  int v33[11]; // [rsp+24h] [rbp-2Ch] BYREF

  v8 = a3; /*0x103128a84*/
  v10 = (_QWORD *)a2[1]; /*0x103128a8e*/
  v11 = *(__int64 (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))(a1 + 2296); /*0x103128a92*/
  if ( v11 != nullptr /*0x103128aa8*/
    || (v11 = *(__int64 (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD, _QWORD))(a1 + 2288)) != nullptr )
  {
    v12 = a4; /*0x103128ab2*/
    v13 = v11( /*0x103128adc*/
            a1,
            a2: *(unsigned __int8 *)(a4 + 12),
            a3: *(unsigned int *)(a6 + 80),
            a4: *(unsigned int *)(a1 + 2636),
            a5: *(unsigned int *)(a6 + 84),
            a6: *(unsigned int *)(a1 + 2676),
            a7: *(_QWORD *)(a1 + 2416));
    v14 = *(unsigned int *)(a6 + 84); /*0x103128ade*/
    if ( v13 < (int)v14 ) /*0x103128ae3*/
      v14 = (unsigned int)v13; /*0x103128ae3*/
    v15 = *(_DWORD *)(a1 + 2636); /*0x103128ae6*/
    v16 = *(unsigned int *)(a1 + 2676); /*0x103128aed*/
    if ( (int)v14 >= v15 ) /*0x103128af6*/
      v14 = (unsigned int)v15; /*0x103128af6*/
    if ( (int)v14 >= (int)v16 ) /*0x103128afb*/
      v14 = (unsigned int)v16; /*0x103128afb*/
    if ( (int)v14 <= 0 ) /*0x103128b00*/
      return 4294966394LL; /*0x103128b43*/
    v30 = a6; /*0x103128b02*/
    v17 = (int)v14; /*0x103128b06*/
    if ( v10[2] - v10[4] >= (unsigned __int64)(int)v14 ) /*0x103128b14*/
    {
      v8 = (int)v14; /*0x103128b45*/
      a4 = v12; /*0x103128b48*/
    }
    else
    {
      v18 = nghttp2_bufs_realloc(a1: (_QWORD *)(a1 + 456), a2: (int)v14 + 10LL, a3: v16, a4: v14); /*0x103128b21*/
      a4 = v12; /*0x103128b28*/
      v8 = a3; /*0x103128b2b*/
      if ( v18 == 0 ) /*0x103128b2f*/
      {
        v10 = (_QWORD *)a2[1]; /*0x103128b35*/
        v8 = v17; /*0x103128b39*/
      }
    }
  }
  else
  {
    v30 = a6; /*0x103128b4d*/
  }
  v33[0] = 0; /*0x103128b51*/
  if ( (unsigned int)(*(_DWORD *)a5 - 1) >= 2 ) /*0x103128b61*/
    abort(); /*0x103128d00*/
  v32 = a4; /*0x103128b6c*/
  v20 = v8; /*0x103128b89*/
  v21 = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD, unsigned __int64, int *, __int64, _QWORD))(a5 + 16))( /*0x103128b94*/
          a1,
          a2: *(unsigned int *)(a4 + 8),
          a3: v10[3],
          a4: v8,
          a5: v33,
          a6: a5 + 8,
          a7: *(_QWORD *)(a1 + 2416));
  if ( (unsigned __int64)(v21 + 526) <= 0x12 ) /*0x103128ba1*/
  {
    v22 = 262177; /*0x103128ba3*/
    if ( _bittest64(&v22, v21 + 526) ) /*0x103128ba8*/
      return (unsigned int)v21; /*0x103128bae*/
  }
  result = 4294966394LL; /*0x103128bbf*/
  if ( v21 >= 0 && v20 >= v21 ) /*0x103128bcc*/
  {
    v23 = v10[3]; /*0x103128bd1*/
    v10[4] = v23 + v21; /*0x103128bd9*/
    v10[3] = v23 - 9; /*0x103128be1*/
    *(_BYTE *)(v32 + 13) = 0; /*0x103128be9*/
    v24 = v33[0]; /*0x103128bed*/
    if ( (v33[0] & 1) != 0 ) /*0x103128bf3*/
    {
      *(_BYTE *)(a5 + 25) = 1; /*0x103128bf5*/
      if ( (v24 & 2) == 0 && (*(_BYTE *)(a5 + 24) & 1) != 0 ) /*0x103128c08*/
        *(_BYTE *)(v32 + 13) |= 1u; /*0x103128c0a*/
    }
    if ( (v24 & 4) != 0 ) /*0x103128c11*/
    {
      if ( *(_QWORD *)(a1 + 2312) == 0 ) /*0x103128c1b*/
        return result; /*0x103128c1b*/
      *(_BYTE *)(a5 + 26) = 1; /*0x103128c1d*/
    }
    *(_QWORD *)v32 = v21; /*0x103128c23*/
    *(_QWORD *)(v32 + 16) = 0; /*0x103128c26*/
    v25 = v21 + 256; /*0x103128c2e*/
    if ( v20 < v21 + 256 ) /*0x103128c38*/
      v25 = v20; /*0x103128c38*/
    result = session_call_select_padding(a1, a2: v32, a3: v25); /*0x103128c3f*/
    if ( (int)result >= -900 ) /*0x103128c4d*/
    {
      *(_QWORD *)(v32 + 16) = result - v21; /*0x103128c56*/
      nghttp2_frame_pack_frame_hd(a1: v10[3], a2: v32); /*0x103128c61*/
      nghttp2_frame_add_pad(a1: a2, a2: v32, a3: *(_QWORD *)(v32 + 16), a4: *(unsigned __int8 *)(a5 + 26)); /*0x103128c77*/
      v26 = *(__int64 **)(v30 + 64); /*0x103128c80*/
      v27 = *v26; /*0x103128c84*/
      *(_QWORD *)(v30 + 72) = *v26; /*0x103128c87*/
      if ( *(_BYTE *)(a1 + 2739) != 0 && *(char *)(v30 + 120) < 0 ) /*0x103128c9c*/
      {
        v28 = (__int64 *)(a1 + 40LL * (*(_BYTE *)(v30 + 120) & 0x7F) + 128); /*0x103128ca9*/
        if ( nghttp2_pq_size(a1: (__int64)v28) != 1 ) /*0x103128cbc*/
        {
          nghttp2_pq_remove(a1: (__int64)v28, a2: (unsigned __int64 *)(v30 + 8)); /*0x103128cc8*/
          *(_QWORD *)(v30 + 32) += v27; /*0x103128ccd*/
          nghttp2_pq_push(a1: v28, a2: (unsigned __int64 *)(v30 + 8)); /*0x103128cd7*/
        }
      }
      if ( *(_QWORD *)v32 != 0 ) /*0x103128ce4*/
        return 0; /*0x103128ce4*/
      result = 4294966761LL; /*0x103128ceb*/
      if ( (~LOBYTE(v33[0]) & 3) != 0 ) /*0x103128cf3*/
        return 0; /*0x103128cf9*/
    }
  }
  return result; /*0x103128bb0*/
}

// Address: 0x103128d6f | Name: _nghttp2_session_get_stream_user_data
__int64 __fastcall nghttp2_session_get_stream_user_data(__int64 a1, int a2)
{
  __int64 v2; // rax

  v2 = nghttp2_map_find(a1, a2); /*0x103128d73*/
  if ( v2 == 0 || (*(_BYTE *)(v2 + 116) & 2) != 0 || *(_DWORD *)v2 == 5 ) /*0x103128d86*/
    return 0; /*0x103128d88*/
  else
    return *(_QWORD *)(v2 + 56); /*0x103128d8c*/
}

// Address: 0x103128d92 | Name: _nghttp2_session_set_stream_user_data
__int64 __fastcall nghttp2_session_set_stream_user_data(__int64 a1, int a2, __int64 a3)
{
  __int64 v6; // rax
  __int64 result; // rax
  __int64 v8; // rcx
  _QWORD *v9; // rcx

  v6 = nghttp2_map_find(a1, a2); /*0x103128da5*/
  if ( v6 != 0 && (*(_BYTE *)(v6 + 116) & 2) == 0 && *(_DWORD *)v6 != 5 ) /*0x103128dbb*/
  {
    v9 = (_QWORD *)(v6 + 56); /*0x103128dfe*/
LABEL_13:
    *v9 = a3; /*0x103128e02*/
    return 0; /*0x103128e05*/
  }
  result = 4294966795LL; /*0x103128dbd*/
  if ( (a2 & 1) != 0 && *(_BYTE *)(a1 + 2739) == 0 ) /*0x103128dd0*/
  {
    v8 = *(_QWORD *)(a1 + 104); /*0x103128dd2*/
    if ( v8 != 0 && *(_DWORD *)(v8 + 8) <= a2 && *(_DWORD *)(a1 + 2608) > (unsigned int)a2 ) /*0x103128de8*/
    {
      while ( *(_DWORD *)(v8 + 8) < a2 ) /*0x103128dee*/
      {
        v8 = *(_QWORD *)(v8 + 144); /*0x103128df0*/
        if ( v8 == 0 ) /*0x103128dfa*/
          return result; /*0x103128dfa*/
      }
      if ( *(_DWORD *)(v8 + 8) <= a2 ) /*0x103128e12*/
      {
        v9 = (_QWORD *)(v8 + 120); /*0x103128e14*/
        goto LABEL_13; /*0x103128e18*/
      }
    }
  }
  return result; /*0x103128e0b*/
}

// Address: 0x103128e1a | Name: _nghttp2_session_resume_data
__int64 __fastcall nghttp2_session_resume_data(__int64 a1, int a2)
{
  __int64 v3; // rax
  unsigned int v4; // ebx
  __int64 v5; // r15
  int v6; // eax

  v3 = nghttp2_map_find(a1, a2); /*0x103128e27*/
  v4 = -501; /*0x103128e2c*/
  if ( v3 != 0 ) /*0x103128e34*/
  {
    v5 = v3; /*0x103128e36*/
    if ( (*(_BYTE *)(v3 + 116) & 2) == 0 /*0x103128e4f*/
      && *(_DWORD *)v3 != 5
      && (unsigned int)nghttp2_stream_check_deferred_item(a1: v3) != 0 )
    {
      v6 = session_resume_deferred_stream_item(a1, a2: v5, a3: 8); /*0x103128e5c*/
      v4 = 0; /*0x103128e61*/
      if ( v6 < -900 ) /*0x103128e68*/
        return (unsigned int)v6; /*0x103128e68*/
    }
  }
  return v4; /*0x103128e71*/
}

// Address: 0x103128eab | Name: _nghttp2_session_get_outbound_queue_size
__int64 __fastcall nghttp2_session_get_outbound_queue_size(_QWORD *a1)
{
  return a1[15] + a1[9] + a1[12]; /*0x103128ebb*/
}

// Address: 0x103128ebd | Name: _nghttp2_session_get_stream_effective_recv_data_length
__int64 __fastcall nghttp2_session_get_stream_effective_recv_data_length(__int64 a1, int a2)
{
  __int64 v2; // rax
  __int64 result; // rax
  int v4; // ecx

  v2 = nghttp2_map_find(a1, a2); /*0x103128ec1*/
  if ( v2 == 0 || (*(_BYTE *)(v2 + 116) & 2) != 0 || *(_DWORD *)v2 == 5 ) /*0x103128ed4*/
    return 0xFFFFFFFFLL; /*0x103128ed6*/
  v4 = *(_DWORD *)(v2 + 88); /*0x103128edd*/
  result = 0; /*0x103128ee0*/
  if ( v4 > 0 ) /*0x103128ee4*/
    return (unsigned int)v4; /*0x103128ee4*/
  return result; /*0x103128edb*/
}

// Address: 0x103128ee9 | Name: _nghttp2_session_get_stream_effective_local_window_size
__int64 __fastcall nghttp2_session_get_stream_effective_local_window_size(__int64 a1, int a2)
{
  __int64 v2; // rcx
  __int64 result; // rax

  v2 = nghttp2_map_find(a1, a2); /*0x103128ef2*/
  result = 0xFFFFFFFFLL; /*0x103128ef5*/
  if ( v2 != 0 && (*(_BYTE *)(v2 + 116) & 2) == 0 && *(_DWORD *)v2 != 5 ) /*0x103128f08*/
    return *(unsigned int *)(v2 + 100); /*0x103128f0a*/
  return result; /*0x103128f0d*/
}

// Address: 0x103128f0f | Name: _nghttp2_session_get_stream_local_window_size
__int64 __fastcall nghttp2_session_get_stream_local_window_size(__int64 a1, int a2)
{
  __int64 v2; // rax
  __int64 result; // rax
  int v4; // ecx

  v2 = nghttp2_map_find(a1, a2); /*0x103128f13*/
  if ( v2 == 0 || (*(_BYTE *)(v2 + 116) & 2) != 0 || *(_DWORD *)v2 == 5 ) /*0x103128f26*/
    return 0xFFFFFFFFLL; /*0x103128f28*/
  v4 = *(_DWORD *)(v2 + 100) - *(_DWORD *)(v2 + 88); /*0x103128f32*/
  result = 0; /*0x103128f35*/
  if ( v4 > 0 ) /*0x103128f39*/
    return (unsigned int)v4; /*0x103128f39*/
  return result; /*0x103128f2d*/
}

// Address: 0x103128f3e | Name: _nghttp2_session_get_effective_recv_data_length
__int64 __fastcall nghttp2_session_get_effective_recv_data_length(__int64 a1)
{
  int v1; // ecx
  __int64 result; // rax

  v1 = *(_DWORD *)(a1 + 2640); /*0x103128f42*/
  result = 0; /*0x103128f48*/
  if ( v1 > 0 ) /*0x103128f4c*/
    return (unsigned int)v1; /*0x103128f4c*/
  return result; /*0x103128f4f*/
}

// Address: 0x103128f51 | Name: _nghttp2_session_get_effective_local_window_size
__int64 __fastcall nghttp2_session_get_effective_local_window_size(__int64 a1)
{
  return *(unsigned int *)(a1 + 2652); /*0x103128f5b*/
}

// Address: 0x103128f5d | Name: _nghttp2_session_get_local_window_size
__int64 __fastcall nghttp2_session_get_local_window_size(__int64 a1)
{
  return (unsigned int)(*(_DWORD *)(a1 + 2652) - *(_DWORD *)(a1 + 2640)); /*0x103128f6d*/
}

// Address: 0x103128f6f | Name: _nghttp2_session_get_stream_remote_window_size
__int64 __fastcall nghttp2_session_get_stream_remote_window_size(__int64 a1, int a2)
{
  __int64 v2; // rax
  __int64 result; // rax
  int v4; // ecx

  v2 = nghttp2_map_find(a1, a2); /*0x103128f73*/
  if ( v2 == 0 || (*(_BYTE *)(v2 + 116) & 2) != 0 || *(_DWORD *)v2 == 5 ) /*0x103128f86*/
    return 0xFFFFFFFFLL; /*0x103128f88*/
  v4 = *(_DWORD *)(v2 + 84); /*0x103128f8f*/
  result = 0; /*0x103128f92*/
  if ( v4 > 0 ) /*0x103128f96*/
    return (unsigned int)v4; /*0x103128f96*/
  return result; /*0x103128f8d*/
}

// Address: 0x103128f9b | Name: _nghttp2_session_get_remote_window_size
__int64 __fastcall nghttp2_session_get_remote_window_size(__int64 a1)
{
  return *(unsigned int *)(a1 + 2636); /*0x103128fa5*/
}

// Address: 0x103128fa7 | Name: _nghttp2_session_get_remote_settings
__int64 __fastcall nghttp2_session_get_remote_settings(__int64 a1, int a2)
{
  unsigned int v2; // esi
  int v3; // eax

  v2 = a2 - 1; /*0x103128fa7*/
  if ( v2 >= 9 || (v3 = 447, !_bittest(&v3, v2)) ) /*0x103128fb3*/
    abort(); /*0x103128fcd*/
  return *(unsigned int *)(a1 + qword_1094C6280[v2]); /*0x103128fc8*/
}

// Address: 0x103128fd2 | Name: _nghttp2_session_get_local_settings
__int64 __fastcall nghttp2_session_get_local_settings(__int64 a1, int a2)
{
  unsigned int v2; // esi
  int v3; // eax

  v2 = a2 - 1; /*0x103128fd2*/
  if ( v2 >= 9 || (v3 = 447, !_bittest(&v3, v2)) ) /*0x103128fde*/
    abort(); /*0x103128ff8*/
  return *(unsigned int *)(a1 + qword_1094C62C8[v2]); /*0x103128ff3*/
}

// Address: 0x103128ffd | Name: _nghttp2_session_upgrade
__int64 __fastcall nghttp2_session_upgrade(__int64 a1)
{
  unsigned int v2; // ebx
  _DWORD *v3; // rax
  _DWORD *v4; // rcx

  v2 = nghttp2_session_upgrade_internal(); /*0x10312900c*/
  if ( v2 == 0 ) /*0x103129010*/
  {
    v3 = (_DWORD *)nghttp2_map_find(a1, a2: 1); /*0x10312901a*/
    v4 = nullptr; /*0x10312901f*/
    if ( *v3 != 5 ) /*0x103129024*/
      v4 = v3; /*0x103129024*/
    v4[28] |= 0x400u; /*0x103129028*/
  }
  return v2; /*0x103129031*/
}

// Address: 0x103129036 | Name: _nghttp2_session_upgrade_internal
__int64 __fastcall nghttp2_session_upgrade_internal(__int64 a1, __int64 a2, unsigned __int64 a3, __int64 a4)
{
  unsigned int v7; // r13d
  unsigned __int128 v8; // rax
  unsigned int v9; // eax
  __int64 v10; // rax
  _QWORD v12[8]; // [rsp+8h] [rbp-78h] BYREF
  unsigned __int64 v13; // [rsp+48h] [rbp-38h] BYREF
  __int64 v14[6]; // [rsp+50h] [rbp-30h] BYREF

  if ( *(_BYTE *)(a1 + 2739) != 0 ) /*0x10312905a*/
  {
    v7 = -505; /*0x10312905c*/
    if ( *(int *)(a1 + 2616) > 0 ) /*0x103129069*/
      return v7; /*0x103129069*/
  }
  else
  {
    v7 = -505; /*0x103129071*/
    if ( *(_DWORD *)(a1 + 2608) != 1 ) /*0x10312907e*/
      return v7; /*0x10312907e*/
  }
  v8 = 0xAAAAAAAAAAAAAAABLL * (unsigned __int128)a3; /*0x103129091*/
  v7 = -501; /*0x103129097*/
  if ( __ROR8__(v8, 1) <= 0x2AAAAAAAAAAAAAAAuLL ) /*0x1031290aa*/
  {
    v7 = -537; /*0x1031290b4*/
    if ( *((_QWORD *)&v8 + 1) >> 2 <= *(_QWORD *)(a1 + 2584) ) /*0x1031290c1*/
    {
      v7 = nghttp2_frame_unpack_settings_payload2(a1: v14, a2: &v13, a3: a2, a4: a3, a5: a1 + 2376); /*0x1031290e4*/
      if ( v7 == 0 ) /*0x1031290e9*/
      {
        if ( *(_BYTE *)(a1 + 2739) != 0 ) /*0x1031290f6*/
        {
          nghttp2_frame_hd_init(a1: (__int64)v12, a2: a3, a3: 4, a4: 0, a5: 0); /*0x10312910c*/
          v12[3] = v14[0]; /*0x103129115*/
          v12[2] = v13; /*0x10312911d*/
          v9 = nghttp2_session_on_settings_received(a1, a2: (__int64)v12, a3: 1); /*0x10312912c*/
        }
        else
        {
          v9 = nghttp2_submit_settings(a1, a2: 0, a3: v14[0], a4: v13); /*0x103129140*/
        }
        v7 = v9; /*0x103129145*/
        nghttp2_mem_free(a1: a1 + 2376, a2: v14[0]); /*0x10312914f*/
        if ( v7 == 0 ) /*0x103129157*/
        {
          if ( *(_BYTE *)(a1 + 2739) != 0 ) /*0x103129162*/
            a4 = 0; /*0x103129162*/
          v10 = nghttp2_session_open_stream(a1, a2: 1, a3: 0, a4: 1, a5: a4); /*0x103129178*/
          if ( v10 != 0 ) /*0x103129180*/
          {
            if ( *(_BYTE *)(a1 + 2739) != 0 ) /*0x103129189*/
            {
              nghttp2_stream_shutdown(a1: v10, a2: 1); /*0x103129193*/
              *(_QWORD *)(a1 + 2616) = 0x100000001LL; /*0x1031291a2*/
            }
            else
            {
              nghttp2_stream_shutdown(a1: v10, a2: 2); /*0x1031291bb*/
              *(_DWORD *)(a1 + 2612) = 1; /*0x1031291c0*/
              *(_DWORD *)(a1 + 2608) += 2; /*0x1031291ca*/
            }
            return 0; /*0x1031291d1*/
          }
          else
          {
            return (unsigned int)-901; /*0x1031291ab*/
          }
        }
      }
    }
  }
  return v7; /*0x1031291d7*/
}

// Address: 0x1031291e6 | Name: _nghttp2_session_upgrade2
__int64 __fastcall nghttp2_session_upgrade2(__int64 a1, __int64 a2, unsigned __int64 a3, int a4, __int64 a5)
{
  unsigned int v7; // r14d
  __int64 v8; // rax

  v7 = nghttp2_session_upgrade_internal(a1, a2, a3, a4: a5); /*0x1031291fd*/
  if ( v7 == 0 ) /*0x103129202*/
  {
    v8 = nghttp2_map_find(a1, a2: 1); /*0x10312920c*/
    if ( v8 == 0 || (*(_BYTE *)(v8 + 116) & 2) != 0 ) /*0x10312921a*/
    {
      v8 = 0; /*0x103129227*/
    }
    else if ( *(_DWORD *)v8 == 5 ) /*0x103129221*/
    {
      v8 = 0; /*0x103129221*/
    }
    if ( a4 != 0 ) /*0x10312922b*/
      *(_BYTE *)(v8 + 113) |= 1u; /*0x10312922d*/
  }
  return v7; /*0x103129238*/
}

// Address: 0x10312923f | Name: _nghttp2_session_get_stream_local_close
__int64 __fastcall nghttp2_session_get_stream_local_close(__int64 a1, int a2)
{
  __int64 v2; // rcx
  __int64 result; // rax

  v2 = nghttp2_map_find(a1, a2); /*0x103129248*/
  result = 0xFFFFFFFFLL; /*0x10312924b*/
  if ( v2 != 0 && (*(_BYTE *)(v2 + 116) & 2) == 0 && *(_DWORD *)v2 != 5 ) /*0x10312925e*/
    return (*(_BYTE *)(v2 + 117) & 2) != 0; /*0x103129266*/
  return result; /*0x103129269*/
}

// Address: 0x10312926b | Name: _nghttp2_session_get_stream_remote_close
__int64 __fastcall nghttp2_session_get_stream_remote_close(__int64 a1, int a2)
{
  __int64 v2; // rcx
  __int64 result; // rax

  v2 = nghttp2_map_find(a1, a2); /*0x103129274*/
  result = 0xFFFFFFFFLL; /*0x103129277*/
  if ( v2 != 0 && (*(_BYTE *)(v2 + 116) & 2) == 0 && *(_DWORD *)v2 != 5 ) /*0x10312928a*/
    return *(_BYTE *)(v2 + 117) & 1; /*0x103129290*/
  return result; /*0x103129293*/
}

// Address: 0x103129295 | Name: _nghttp2_session_consume_connection
__int64 __fastcall nghttp2_session_consume_connection(__int64 a1, int a2)
{
  __int64 result; // rax

  result = 4294966777LL; /*0x103129295*/
  if ( (*(_BYTE *)(a1 + 2724) & 1) != 0 ) /*0x1031292a1*/
  {
    result = session_update_consumed_size( /*0x1031292cf*/
               a1,
               a2: (int)a1 + 2644,
               a3: (int)a1 + 2640,
               a4: *(unsigned __int8 *)(a1 + 2741),
               a5: 0,
               a6: a2,
               a7: *(_DWORD *)(a1 + 2652));
    if ( (int)result >= -900 ) /*0x1031292d9*/
      return 0; /*0x1031292d9*/
  }
  return result; /*0x1031292e2*/
}

// Address: 0x1031292e3 | Name: _nghttp2_session_consume_stream
__int64 __fastcall nghttp2_session_consume_stream(__int64 a1, int a2, int a3)
{
  int v3; // r14d
  __int64 result; // rax
  __int64 v6; // rdi
  int updated; // ecx

  if ( a2 == 0 ) /*0x1031292e5*/
    return 4294966795LL; /*0x10312935d*/
  v3 = a1; /*0x1031292f2*/
  result = 4294966777LL; /*0x1031292f5*/
  if ( (*(_BYTE *)(a1 + 2724) & 1) != 0 ) /*0x103129301*/
  {
    v6 = nghttp2_map_find(a1, a2); /*0x10312930e*/
    result = 0; /*0x103129311*/
    if ( v6 != 0 && (*(_BYTE *)(v6 + 116) & 2) == 0 && *(_DWORD *)v6 != 5 ) /*0x103129321*/
    {
      updated = session_update_consumed_size( /*0x103129347*/
                  a1: v3,
                  a2: (int)v6 + 92,
                  a3: (int)v6 + 88,
                  a4: *(unsigned __int8 *)(v6 + 119),
                  a5: *(_DWORD *)(v6 + 80),
                  a6: a3,
                  a7: *(_DWORD *)(v6 + 100));
      result = 0; /*0x103129349*/
      if ( updated < -900 ) /*0x103129351*/
        return (unsigned int)updated; /*0x103129351*/
    }
  }
  return result; /*0x10312935c*/
}

// Address: 0x103129363 | Name: _nghttp2_session_set_next_stream_id
__int64 __fastcall nghttp2_session_set_next_stream_id(__int64 a1, int a2)
{
  __int64 result; // rax

  result = 4294966795LL; /*0x103129367*/
  if ( a2 > 0 && *(_DWORD *)(a1 + 2608) <= (unsigned int)a2 ) /*0x103129376*/
  {
    if ( *(_BYTE *)(a1 + 2739) != 0 ) /*0x10312937f*/
    {
      if ( (a2 & 1) != 0 ) /*0x103129385*/
        return result; /*0x103129385*/
    }
    else if ( (a2 & 1) == 0 ) /*0x103129395*/
    {
      return result; /*0x103129395*/
    }
    *(_DWORD *)(a1 + 2608) = a2; /*0x103129387*/
    return 0; /*0x10312938d*/
  }
  return result; /*0x10312938f*/
}

// Address: 0x103129399 | Name: _nghttp2_session_get_next_stream_id
__int64 __fastcall nghttp2_session_get_next_stream_id(__int64 a1)
{
  return *(unsigned int *)(a1 + 2608); /*0x1031293a3*/
}

// Address: 0x1031293a5 | Name: _nghttp2_session_get_last_proc_stream_id
__int64 __fastcall nghttp2_session_get_last_proc_stream_id(__int64 a1)
{
  return *(unsigned int *)(a1 + 2620); /*0x1031293af*/
}

// Address: 0x1031293b1 | Name: _nghttp2_session_find_stream
void *__fastcall nghttp2_session_find_stream(__int64 a1, int a2)
{
  if ( a2 != 0 ) /*0x1031293b7*/
    return (void *)nghttp2_map_find(a1, a2); /*0x1031293ba*/
  else
    return &nghttp2_stream_root; /*0x1031293bf*/
}

// Address: 0x1031293c8 | Name: _nghttp2_session_get_root_stream
void *nghttp2_session_get_root_stream()
{
  return &nghttp2_stream_root; /*0x1031293d3*/
}

// Address: 0x1031293d5 | Name: _nghttp2_session_check_server_session
__int64 __fastcall nghttp2_session_check_server_session(__int64 a1)
{
  return *(unsigned __int8 *)(a1 + 2739); /*0x1031293e0*/
}

// Address: 0x1031293e2 | Name: _nghttp2_session_change_stream_priority
__int64 nghttp2_session_change_stream_priority()
{
  return 0; /*0x1031293e8*/
}

// Address: 0x1031293ea | Name: _nghttp2_session_create_idle_stream
__int64 nghttp2_session_create_idle_stream()
{
  return 0; /*0x1031293f0*/
}

// Address: 0x1031293f2 | Name: _nghttp2_session_get_hd_inflate_dynamic_table_size
__int64 __fastcall nghttp2_session_get_hd_inflate_dynamic_table_size(__int64 a1)
{
  return nghttp2_hd_inflate_get_dynamic_table_size(a1: a1 + 1904); /*0x1031293fd*/
}

// Address: 0x103129403 | Name: _nghttp2_session_get_hd_deflate_dynamic_table_size
__int64 __fastcall nghttp2_session_get_hd_deflate_dynamic_table_size(__int64 a1)
{
  return nghttp2_hd_deflate_get_dynamic_table_size(a1: a1 + 792); /*0x10312940e*/
}

// Address: 0x103129414 | Name: _nghttp2_session_set_user_data
void __fastcall nghttp2_session_set_user_data(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a1 + 2416) = a2; /*0x103129418*/
}

// Address: 0x103129421 | Name: _nghttp2_session_change_extpri_stream_priority
__int64 __fastcall nghttp2_session_change_extpri_stream_priority(__int64 a1, int a2, __int64 *a3, int a4)
{
  __int64 v4; // rax
  __int64 v5; // r13
  unsigned int v7; // r15d
  __int64 v9; // rax
  __int64 v10; // r12
  unsigned __int8 v11; // al
  unsigned __int8 v13[48]; // [rsp+0h] [rbp-30h] BYREF

  *(_QWORD *)v13 = v4; /*0x10312942e*/
  v5 = *a3; /*0x10312942f*/
  *(_QWORD *)v13 = *a3; /*0x103129432*/
  if ( *(_BYTE *)(a1 + 2739) != 0 ) /*0x10312943d*/
  {
    v7 = 0; /*0x103129442*/
    if ( *(_BYTE *)(a1 + 2738) == 1 ) /*0x10312944c*/
    {
      v7 = -501; /*0x10312944e*/
      if ( a2 != 0 ) /*0x103129456*/
      {
        v9 = nghttp2_map_find(a1, a2); /*0x10312945e*/
        if ( v9 != 0 ) /*0x103129466*/
        {
          v10 = v9; /*0x103129468*/
          if ( (v5 & 0xFFFFFFF8) != 0 ) /*0x103129472*/
            *(_DWORD *)v13 = 7; /*0x103129474*/
          if ( a4 != 0 ) /*0x10312947e*/
            *(_BYTE *)(v9 + 116) |= 0x20u; /*0x103129480*/
          v11 = nghttp2_extpri_to_uint8(a1: v13); /*0x10312948a*/
          return (unsigned int)session_update_stream_priority(a1, a2: v10, a3: v11); /*0x10312949d*/
        }
      }
    }
  }
  else
  {
    return (unsigned int)-519; /*0x1031294a2*/
  }
  return v7; /*0x1031294af*/
}

// Address: 0x1031294ba | Name: _nghttp2_session_get_extpri_stream_priority
__int64 __fastcall nghttp2_session_get_extpri_stream_priority(__int64 a1, _QWORD *a2, int a3)
{
  unsigned int v3; // ebx
  __int64 v5; // rax

  if ( *(_BYTE *)(a1 + 2739) != 0 ) /*0x1031294c8*/
  {
    v3 = 0; /*0x1031294ca*/
    if ( *(_BYTE *)(a1 + 2738) == 1 ) /*0x1031294d3*/
    {
      v3 = -501; /*0x1031294d5*/
      if ( a3 != 0 ) /*0x1031294dc*/
      {
        v5 = nghttp2_map_find(a1, a2: a3); /*0x1031294e3*/
        if ( v5 != 0 ) /*0x1031294eb*/
        {
          nghttp2_extpri_from_uint8(a1: a2, a2: *(_BYTE *)(v5 + 120)); /*0x1031294f4*/
          return 0; /*0x1031294f9*/
        }
      }
    }
  }
  else
  {
    return (unsigned int)-519; /*0x1031294fd*/
  }
  return v3; /*0x103129504*/
}

// Address: 0x103129671 | Name: _nghttp2_session_predicate_data_send
__int64 __fastcall nghttp2_session_predicate_data_send(__int64 a1, __int64 a2)
{
  int is_closing; // ecx
  __int64 result; // rax
  int v6; // eax
  unsigned int v7; // edx
  bool v8; // zf

  if ( a2 == 0 ) /*0x103129674*/
    return 4294966786LL; /*0x1031296d1*/
  is_closing = session_is_closing(a1); /*0x103129688*/
  result = 4294966766LL; /*0x10312968a*/
  if ( is_closing == 0 ) /*0x103129691*/
  {
    result = 4294966784LL; /*0x103129693*/
    if ( (*(_BYTE *)(a2 + 117) & 2) == 0 ) /*0x10312969c*/
    {
      v6 = *(_DWORD *)(a2 + 80); /*0x10312969e*/
      if ( v6 != 0 && (((unsigned __int8)v6 ^ (*(_BYTE *)(a1 + 2739) == 0)) & 1) == 0 ) /*0x1031296b5*/
      {
        v7 = -514; /*0x1031296de*/
        if ( *(_DWORD *)a2 != 4 ) /*0x1031296e3*/
          v7 = 0; /*0x1031296e3*/
        v8 = *(_DWORD *)a2 == 3; /*0x1031296e6*/
        result = 4294966785LL; /*0x1031296e9*/
      }
      else
      {
        v7 = 3 * (*(_DWORD *)a2 == 3) - 514; /*0x1031296c4*/
        result = 0; /*0x1031296ca*/
        v8 = *(_DWORD *)a2 == 2; /*0x1031296cc*/
      }
      if ( !v8 ) /*0x1031296ee*/
        return v7; /*0x1031296ee*/
    }
  }
  return result; /*0x1031296d6*/
}

// Address: 0x103129a35 | Name: _nghttp2_stream_init
__int64 __fastcall nghttp2_stream_init(__int64 a1, int a2, char a3, int a4, int a5, int a6, __int64 a7)
{
  *(_DWORD *)(a1 + 80) = a2; /*0x103129a3d*/
  *(_BYTE *)(a1 + 116) = a3; /*0x103129a40*/
  *(_DWORD *)a1 = a4; /*0x103129a43*/
  *(_BYTE *)(a1 + 117) = 0; /*0x103129a45*/
  *(_QWORD *)(a1 + 56) = a7; /*0x103129a49*/
  *(_OWORD *)(a1 + 64) = 0; /*0x103129a50*/
  *(_DWORD *)(a1 + 84) = a5; /*0x103129a54*/
  *(_DWORD *)(a1 + 100) = a6; /*0x103129a58*/
  *(_QWORD *)(a1 + 88) = 0; /*0x103129a5e*/
  *(_DWORD *)(a1 + 96) = 0; /*0x103129a62*/
  *(_QWORD *)(a1 + 48) = 0; /*0x103129a65*/
  *(_DWORD *)(a1 + 112) = 0; /*0x103129a69*/
  *(_QWORD *)(a1 + 16) = -1; /*0x103129a6c*/
  *(_QWORD *)(a1 + 24) = 0; /*0x103129a74*/
  *(_WORD *)(a1 + 108) = -1; /*0x103129a78*/
  *(_WORD *)(a1 + 118) = 0; /*0x103129a7e*/
  *(_DWORD *)(a1 + 104) = 0; /*0x103129a84*/
  *(_OWORD *)(a1 + 32) = 0; /*0x103129a87*/
  *(_BYTE *)(a1 + 121) = 3; /*0x103129a8d*/
  *(_BYTE *)(a1 + 120) = 3; /*0x103129a90*/
  return 3; /*0x103129a93*/
}

// Address: 0x103129a95 | Name: _nghttp2_stream_free
void nghttp2_stream_free()
{
  ; /*0x103129a95*/
}

// Address: 0x103129a9b | Name: _nghttp2_stream_shutdown
void __fastcall nghttp2_stream_shutdown(__int64 a1, char a2)
{
  *(_BYTE *)(a1 + 117) |= a2; /*0x103129a9f*/
}

// Address: 0x103129aa5 | Name: _nghttp2_stream_attach_item
void __fastcall nghttp2_stream_attach_item(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a1 + 64) = a2; /*0x103129aa9*/
}

// Address: 0x103129aaf | Name: _nghttp2_stream_detach_item
void __fastcall nghttp2_stream_detach_item(__int64 a1)
{
  *(_QWORD *)(a1 + 64) = 0; /*0x103129ab3*/
  *(_BYTE *)(a1 + 116) &= 0xF3u; /*0x103129abb*/
}

// Address: 0x103129ac1 | Name: _nghttp2_stream_defer_item
void __fastcall nghttp2_stream_defer_item(__int64 a1, char a2)
{
  *(_BYTE *)(a1 + 116) |= a2; /*0x103129ac5*/
}

// Address: 0x103129acb | Name: _nghttp2_stream_resume_deferred_item
void __fastcall nghttp2_stream_resume_deferred_item(__int64 a1, char a2)
{
  *(_BYTE *)(a1 + 116) &= ~a2; /*0x103129ad2*/
}

// Address: 0x103129ad8 | Name: _nghttp2_stream_check_deferred_item
_BOOL8 __fastcall nghttp2_stream_check_deferred_item(__int64 a1)
{
  return *(_QWORD *)(a1 + 64) != 0 && (*(_BYTE *)(a1 + 116) & 0xC) != 0; /*0x103129ae9*/
}

// Address: 0x103129af2 | Name: _nghttp2_stream_check_deferred_by_flow_control
_BOOL8 __fastcall nghttp2_stream_check_deferred_by_flow_control(__int64 a1)
{
  return *(_QWORD *)(a1 + 64) != 0 && (*(_DWORD *)(a1 + 116) & 4) != 0; /*0x103129b03*/
}

// Address: 0x103129b0c | Name: _nghttp2_stream_update_remote_initial_window_size
__int64 __fastcall nghttp2_stream_update_remote_initial_window_size(__int64 a1, int a2, int a3)
{
  __int64 v3; // rcx
  __int64 result; // rax

  v3 = *(int *)(a1 + 84) + a2 - (__int64)a3; /*0x103129b1d*/
  result = 0xFFFFFFFFLL; /*0x103129b23*/
  if ( (int)v3 == v3 ) /*0x103129b2b*/
  {
    *(_DWORD *)(a1 + 84) = v3; /*0x103129b2d*/
    return 0; /*0x103129b30*/
  }
  return result; /*0x103129b32*/
}

// Address: 0x103129b34 | Name: _nghttp2_stream_update_local_initial_window_size
__int64 __fastcall nghttp2_stream_update_local_initial_window_size(__int64 a1, int a2, int a3)
{
  __int64 v3; // rcx
  __int64 result; // rax

  v3 = *(int *)(a1 + 100) + a2 - (__int64)a3; /*0x103129b45*/
  result = 0xFFFFFFFFLL; /*0x103129b4b*/
  if ( (int)v3 == v3 ) /*0x103129b53*/
  {
    *(_DWORD *)(a1 + 100) = v3; /*0x103129b55*/
    return 0; /*0x103129b58*/
  }
  return result; /*0x103129b5a*/
}

// Address: 0x103129b5c | Name: _nghttp2_stream_promise_fulfilled
void __fastcall nghttp2_stream_promise_fulfilled(__int64 a1)
{
  *(_DWORD *)a1 = 2; /*0x103129b60*/
  *(_BYTE *)(a1 + 116) &= ~1u; /*0x103129b66*/
}

// Address: 0x103129b6c | Name: _nghttp2_stream_get_state
__int64 __fastcall nghttp2_stream_get_state(__int64 a1)
{
  char v1; // dl
  __int64 result; // rax
  char v3; // cl

  if ( (_UNKNOWN *)a1 == &nghttp2_stream_root ) /*0x103129b77*/
    return 1; /*0x103129bb0*/
  v1 = *(_BYTE *)(a1 + 116); /*0x103129b79*/
  result = 7; /*0x103129b7d*/
  if ( (v1 & 2) == 0 ) /*0x103129b85*/
  {
    v3 = *(_BYTE *)(a1 + 117); /*0x103129b87*/
    if ( (v1 & 1) == 0 || (result = 3, (v3 & 1) == 0) && (result = 4, (v3 & 2) == 0) ) /*0x103129bc9*/
    {
      result = 6; /*0x103129b90*/
      if ( (v3 & 1) == 0 ) /*0x103129b98*/
      {
        result = 5; /*0x103129b9a*/
        if ( (v3 & 2) == 0 ) /*0x103129ba2*/
          return (unsigned int)(*(_DWORD *)a1 != 5) + 1; /*0x103129bac*/
      }
    }
  }
  return result; /*0x103129bb5*/
}

// Address: 0x103129bcd | Name: _nghttp2_stream_get_parent
__int64 nghttp2_stream_get_parent()
{
  return 0; /*0x103129bd3*/
}

// Address: 0x103129bd5 | Name: _nghttp2_stream_get_next_sibling
__int64 nghttp2_stream_get_next_sibling()
{
  return 0; /*0x103129bdb*/
}

// Address: 0x103129bdd | Name: _nghttp2_stream_get_previous_sibling
__int64 nghttp2_stream_get_previous_sibling()
{
  return 0; /*0x103129be3*/
}

// Address: 0x103129be5 | Name: _nghttp2_stream_get_first_child
__int64 nghttp2_stream_get_first_child()
{
  return 0; /*0x103129beb*/
}

// Address: 0x103129bed | Name: _nghttp2_stream_get_weight
__int64 nghttp2_stream_get_weight()
{
  return 16; /*0x103129bf6*/
}

// Address: 0x103129bf8 | Name: _nghttp2_stream_get_sum_dependency_weight
__int64 nghttp2_stream_get_sum_dependency_weight()
{
  return 0; /*0x103129bfe*/
}

// Address: 0x103129c00 | Name: _nghttp2_stream_get_stream_id
__int64 __fastcall nghttp2_stream_get_stream_id(__int64 a1)
{
  return *(unsigned int *)(a1 + 80); /*0x103129c07*/
}

// Address: 0x103129c09 | Name: _nghttp2_submit_trailer
__int64 __fastcall nghttp2_submit_trailer(int a1, int a2, int a3, int a4)
{
  if ( a2 <= 0 ) /*0x103129c0b*/
    return 4294966795LL; /*0x103129c38*/
  else
    return submit_headers_shared_nva(a1, a2: 1, a3: a2, a4: a3, a5: a4, a6: 0, a7: 0); /*0x103129c2d*/
}

// Address: 0x103129d8c | Name: _nghttp2_submit_headers
__int64 __fastcall nghttp2_submit_headers(__int64 a1, char a2, int a3, __int64 a4, int a5, int a6, __int64 a7)
{
  __int64 result; // rax

  if ( a3 == -1 ) /*0x103129d93*/
  {
    result = 4294966791LL; /*0x103129da0*/
    if ( *(_BYTE *)(a1 + 2739) != 0 ) /*0x103129dac*/
      return result; /*0x103129dac*/
  }
  else if ( a3 <= 0 ) /*0x103129d97*/
  {
    return 4294966795LL; /*0x103129d9e*/
  }
  return submit_headers_shared_nva(a1, a2: a2 & 1, a3, a4: a5, a5: a6, a6: 0, a7); /*0x103129dae*/
}

// Address: 0x103129dc7 | Name: _nghttp2_submit_ping
__int64 __fastcall nghttp2_submit_ping(__int64 a1, char a2, __int64 *a3)
{
  return nghttp2_session_add_ping(a1, a2: a2 & 1, a3); /*0x103129dce*/
}

// Address: 0x103129dd4 | Name: _nghttp2_submit_priority
__int64 nghttp2_submit_priority()
{
  return 0; /*0x103129dda*/
}

// Address: 0x103129ddc | Name: _nghttp2_submit_rst_stream
__int64 __fastcall nghttp2_submit_rst_stream(__int64 a1, __int64 a2, int a3, int a4)
{
  if ( a3 != 0 ) /*0x103129de2*/
    return nghttp2_session_add_rst_stream_continue(a1, a2: a3, a3: a4, a4: 0); /*0x103129deb*/
  else
    return 4294966795LL; /*0x103129df0*/
}

// Address: 0x103129df7 | Name: _nghttp2_submit_goaway
__int64 __fastcall nghttp2_submit_goaway(__int64 a1, __int64 a2, int a3, int a4, const void *a5, size_t a6)
{
  if ( (*(_BYTE *)(a1 + 2740) & 1) != 0 ) /*0x103129e02*/
    return 0; /*0x103129e17*/
  else
    return nghttp2_session_add_goaway(a1, a2: a3, a3: a4, a4: a5, a5: a6, a6: 0); /*0x103129e12*/
}

// Address: 0x103129e1b | Name: _nghttp2_submit_shutdown_notice
__int64 __fastcall nghttp2_submit_shutdown_notice(__int64 a1)
{
  __int64 result; // rax

  if ( *(_BYTE *)(a1 + 2739) == 0 ) /*0x103129e26*/
    return 4294966777LL; /*0x103129e4b*/
  result = 0; /*0x103129e28*/
  if ( *(_BYTE *)(a1 + 2740) == 0 ) /*0x103129e31*/
    return nghttp2_session_add_goaway(a1, a2: 0x7FFFFFFF, a3: 0, a4: nullptr, a5: 0, a6: 2); /*0x103129e46*/
  return result; /*0x103129e45*/
}

// Address: 0x103129e52 | Name: _nghttp2_submit_settings
__int64 __fastcall nghttp2_submit_settings(__int64 a1, __int64 a2, _BYTE *a3, __int64 a4)
{
  return nghttp2_session_add_settings(a1, a2: 0, a3, a4); /*0x103129e58*/
}

// Address: 0x103129e5e | Name: _nghttp2_submit_push_promise
__int64 __fastcall nghttp2_submit_push_promise(__int64 a1, __int64 a2, int a3, __int64 a4, __int64 a5, __int64 a6)
{
  unsigned int v6; // r14d
  __int64 v12; // rax
  __int64 v13; // r12
  int v14; // eax
  __int64 v15; // r13
  unsigned int v16; // eax
  unsigned int v17; // ebx
  __int64 v18; // r15
  __int64 v19; // [rsp+8h] [rbp-48h] BYREF
  __int64 v20; // [rsp+10h] [rbp-40h]
  __int64 v21; // [rsp+18h] [rbp-38h]
  __int64 v22; // [rsp+20h] [rbp-30h]

  v6 = -501; /*0x103129e6f*/
  if ( a3 > 0 ) /*0x103129e77*/
  {
    v20 = a5; /*0x103129e84*/
    if ( (unsigned int)nghttp2_session_is_my_stream_id(a1, a2: a3) == 0 ) /*0x103129e91*/
    {
      if ( *(_BYTE *)(a1 + 2739) == 0 ) /*0x103129ead*/
        return (unsigned int)-505; /*0x103129f6e*/
      if ( *(int *)(a1 + 2608) < 0 ) /*0x103129ebb*/
        return (unsigned int)-509; /*0x103129f79*/
      v12 = nghttp2_mem_malloc(a1: a1 + 2376, a2: 160); /*0x103129ed0*/
      if ( v12 == 0 ) /*0x103129ed8*/
        return (unsigned int)-901; /*0x103129f84*/
      v22 = v12; /*0x103129ee1*/
      nghttp2_outbound_item_init(a1: v12); /*0x103129ee5*/
      *(_QWORD *)(v22 + 120) = a6; /*0x103129eee*/
      v13 = v20; /*0x103129ef9*/
      v21 = a1 + 2376; /*0x103129f00*/
      v14 = nghttp2_nv_array_copy(a1: &v19, a2: a4, a3: v20, a4: a1 + 2376); /*0x103129f07*/
      if ( v14 < 0 ) /*0x103129f0e*/
      {
        v6 = v14; /*0x103129f89*/
        v18 = v21; /*0x103129f8c*/
        v15 = v22; /*0x103129f90*/
      }
      else
      {
        v6 = *(_DWORD *)(a1 + 2608); /*0x103129f10*/
        *(_DWORD *)(a1 + 2608) = v6 + 2; /*0x103129f1b*/
        v15 = v22; /*0x103129f26*/
        nghttp2_frame_push_promise_init(a1: v22, a2: 4, a3, a4: v6, a5: v19, a6: v13); /*0x103129f3a*/
        v16 = nghttp2_session_add_item(a1, a2: v15); /*0x103129f45*/
        if ( v16 == 0 ) /*0x103129f4c*/
          return v6; /*0x103129f4c*/
        v17 = v16; /*0x103129f52*/
        v18 = v21; /*0x103129f57*/
        nghttp2_frame_push_promise_free(a1: v15, a2: v21); /*0x103129f5e*/
        v6 = v17; /*0x103129f63*/
      }
      nghttp2_mem_free(a1: v18, a2: v15); /*0x103129f9a*/
    }
  }
  return v6; /*0x103129e96*/
}

// Address: 0x103129fa4 | Name: _nghttp2_submit_window_update
__int64 __fastcall nghttp2_submit_window_update(int *a1, __int64 a2, int a3, int a4)
{
  unsigned int v4; // r15d
  int *stream; // rax
  int *v8; // r12
  unsigned int v9; // eax
  int v10; // ecx
  _DWORD *v11; // r12
  int v12; // eax
  int v14[9]; // [rsp+Ch] [rbp-24h] BYREF

  v14[0] = a4; /*0x103129fb3*/
  v4 = 0; /*0x103129fb6*/
  if ( a4 == 0 ) /*0x103129fbb*/
    return v4; /*0x103129fbb*/
  if ( a3 != 0 ) /*0x103129fc8*/
  {
    stream = (int *)nghttp2_session_get_stream((__int64)a1, a2: a3); /*0x103129fcf*/
    if ( stream == nullptr ) /*0x103129fd7*/
      return v4; /*0x103129fd7*/
    v8 = stream; /*0x103129fd9*/
    v9 = nghttp2_adjust_local_window_size(a1: stream + 25, a2: stream + 22, a3: stream + 24, a4: v14); /*0x103129fec*/
    if ( v9 == 0 ) /*0x103129ff3*/
    {
      v10 = v14[0]; /*0x103129ff5*/
      if ( v14[0] > 0 ) /*0x103129ffa*/
      {
        v11 = v8 + 23; /*0x103129ffc*/
LABEL_10:
        v12 = *v11 - v10; /*0x10312a032*/
        if ( v12 <= 0 ) /*0x10312a03c*/
          v12 = 0; /*0x10312a03c*/
        *v11 = v12; /*0x10312a03f*/
        return (unsigned int)nghttp2_session_add_window_update((__int64)a1, a2: 0, a3, a4: v10); /*0x10312a04a*/
      }
      return v4; /*0x103129ffa*/
    }
    return v9; /*0x10312a04f*/
  }
  v9 = nghttp2_adjust_local_window_size(a1: a1 + 663, a2: a1 + 660, a3: a1 + 662, a4: v14); /*0x10312a01b*/
  if ( v9 != 0 ) /*0x10312a022*/
    return v9; /*0x10312a022*/
  v10 = v14[0]; /*0x10312a024*/
  if ( v14[0] > 0 ) /*0x10312a029*/
  {
    v11 = a1 + 661; /*0x10312a02b*/
    goto LABEL_10; /*0x10312a02b*/
  }
  return v4; /*0x10312a055*/
}

// Address: 0x10312a062 | Name: _nghttp2_session_set_local_window_size
__int64 __fastcall nghttp2_session_set_local_window_size(__int64 a1, __int64 a2, int a3, int a4)
{
  __int64 stream; // r12
  __int64 result; // rax
  int v9; // r15d
  int *v10; // rdi
  int *v11; // rsi
  int *v12; // rdx
  int v13; // ecx
  __int64 v14; // rdi
  int v15; // edx
  int v16; // r15d
  int v17[11]; // [rsp-2Ch] [rbp-2Ch] BYREF

  if ( a4 < 0 ) /*0x10312a064*/
    return 4294966795LL; /*0x10312a0e3*/
  if ( a3 != 0 ) /*0x10312a080*/
  {
    stream = nghttp2_session_get_stream(a1, a2: a3); /*0x10312a08d*/
    result = 0; /*0x10312a090*/
    if ( stream == 0 ) /*0x10312a095*/
      return result; /*0x10312a095*/
    v9 = a4 - *(_DWORD *)(stream + 100); /*0x10312a09b*/
    v17[0] = v9; /*0x10312a0a0*/
    if ( v9 == 0 ) /*0x10312a0a4*/
      return result; /*0x10312a0a4*/
    v10 = (int *)(stream + 100); /*0x10312a0aa*/
    v11 = (int *)(stream + 88); /*0x10312a0af*/
    v12 = (int *)(stream + 96); /*0x10312a0b7*/
    if ( v9 >= 0 ) /*0x10312a0be*/
    {
      result = nghttp2_increase_local_window_size(a1: v10, a2: v11, a3: v12, a4: v17); /*0x10312a0c4*/
      if ( (_DWORD)result == 0 ) /*0x10312a0cb*/
      {
        v13 = v17[0]; /*0x10312a0cd*/
        v14 = a1; /*0x10312a0d0*/
        if ( v17[0] > 0 ) /*0x10312a0d5*/
        {
          v15 = a3; /*0x10312a0d9*/
          return nghttp2_session_add_window_update(a1: v14, a2: 0, a3: v15, a4: v13); /*0x10312a12d*/
        }
        return nghttp2_session_update_recv_stream_window_size(a1, a2: stream, a3: 0, a4: 1); /*0x10312a14f*/
      }
      return result; /*0x10312a154*/
    }
    return nghttp2_adjust_local_window_size(a1: v10, a2: v11, a3: v12, a4: v17); /*0x10312a133*/
  }
  result = 0; /*0x10312a0e4*/
  v16 = a4 - *(_DWORD *)(a1 + 2652); /*0x10312a0e6*/
  v17[0] = v16; /*0x10312a0ed*/
  if ( v16 == 0 ) /*0x10312a0f1*/
    return result; /*0x10312a0f1*/
  v10 = (int *)(a1 + 2652); /*0x10312a0f3*/
  v11 = (int *)(a1 + 2640); /*0x10312a0fa*/
  v12 = (int *)(a1 + 2648); /*0x10312a101*/
  if ( v16 < 0 ) /*0x10312a10b*/
    return nghttp2_adjust_local_window_size(a1: v10, a2: v11, a3: v12, a4: v17); /*0x10312a10b*/
  result = nghttp2_increase_local_window_size(a1: v10, a2: v11, a3: v12, a4: v17); /*0x10312a111*/
  if ( (_DWORD)result == 0 ) /*0x10312a118*/
  {
    v13 = v17[0]; /*0x10312a11a*/
    v14 = a1; /*0x10312a11d*/
    if ( v17[0] > 0 ) /*0x10312a122*/
    {
      v15 = 0; /*0x10312a126*/
      return nghttp2_session_add_window_update(a1: v14, a2: 0, a3: v15, a4: v13); /*0x10312a126*/
    }
    return nghttp2_session_update_recv_connection_window_size(a1, a2: 0); /*0x10312a158*/
  }
  return result; /*0x10312a0e3*/
}

// Address: 0x10312a15f | Name: _nghttp2_submit_altsvc
__int64 __fastcall nghttp2_submit_altsvc(
        __int64 a1,
        __int64 a2,
        int a3,
        const void *a4,
        size_t a5,
        const void *a6,
        size_t a7)
{
  unsigned __int64 v8; // rsi
  unsigned int v9; // r13d
  __int64 v12; // rdi
  _BYTE *v13; // r13
  char *v16; // rax
  char *v17; // r13
  char *v18; // rax
  __int64 v19; // rax
  __int64 v20; // rbx
  unsigned int v21; // eax
  __int64 v22; // r14
  __int64 v23; // rsi
  const void *v24; // [rsp+0h] [rbp-40h]
  __int64 v25; // [rsp+8h] [rbp-38h]
  __int64 v26; // [rsp+10h] [rbp-30h]

  if ( *(_BYTE *)(a1 + 2739) == 0 ) /*0x10312a177*/
    return (unsigned int)-519; /*0x10312a1cb*/
  v8 = a5 + a7 + 2; /*0x10312a184*/
  v9 = -501; /*0x10312a188*/
  if ( v8 <= 0x4000 ) /*0x10312a195*/
  {
    v12 = a1 + 2376; /*0x10312a19d*/
    if ( a3 != 0 ) /*0x10312a1a6*/
    {
      if ( a5 != 0 ) /*0x10312a1ab*/
        return v9; /*0x10312a1ab*/
      v24 = a6; /*0x10312a1ad*/
      v26 = v12; /*0x10312a1b1*/
      v13 = (_BYTE *)nghttp2_mem_malloc(a1: v12, a2: v8); /*0x10312a1ba*/
      v25 = (__int64)v13; /*0x10312a1bd*/
      if ( v13 == nullptr ) /*0x10312a1c4*/
        return (unsigned int)-901; /*0x10312a1c4*/
    }
    else
    {
      if ( a5 == 0 ) /*0x10312a1e6*/
        return v9; /*0x10312a1e6*/
      v24 = a6; /*0x10312a1eb*/
      v26 = v12; /*0x10312a1ef*/
      v16 = (char *)nghttp2_mem_malloc(a1: v12, a2: v8); /*0x10312a1f3*/
      if ( v16 == nullptr ) /*0x10312a1fb*/
        return (unsigned int)-901; /*0x10312a2ab*/
      v25 = (__int64)v16; /*0x10312a201*/
      v13 = nghttp2_cpymem(__dst: v16, a2: a4, a3: a5); /*0x10312a213*/
    }
    *v13 = 0; /*0x10312a216*/
    v17 = v13 + 1; /*0x10312a21b*/
    v18 = v17; /*0x10312a21e*/
    if ( a7 != 0 ) /*0x10312a228*/
      v18 = nghttp2_cpymem(__dst: v17, a2: v24, a3: a7); /*0x10312a231*/
    *v18 = 0; /*0x10312a236*/
    v19 = nghttp2_mem_malloc(a1: v26, a2: 160); /*0x10312a242*/
    if ( v19 != 0 ) /*0x10312a24a*/
    {
      v20 = v19; /*0x10312a24c*/
      nghttp2_outbound_item_init(a1: v19); /*0x10312a252*/
      *(_BYTE *)(v20 + 96) = 1; /*0x10312a257*/
      *(_QWORD *)(v20 + 16) = v20 + 64; /*0x10312a262*/
      nghttp2_frame_altsvc_init(a1: v20, a2: a3, a3: v25, a4: a5, a5: (__int64)v17, a6: a7); /*0x10312a27a*/
      v21 = nghttp2_session_add_item(a1, a2: v20); /*0x10312a285*/
      if ( v21 == 0 ) /*0x10312a28c*/
        return 0; /*0x10312a2ce*/
      v9 = v21; /*0x10312a28e*/
      v22 = v26; /*0x10312a294*/
      nghttp2_frame_altsvc_free(a1: v20, a2: v26); /*0x10312a29b*/
      v23 = v20; /*0x10312a2a0*/
    }
    else
    {
      v9 = -901; /*0x10312a2b0*/
      v22 = v26; /*0x10312a2b6*/
      v23 = v25; /*0x10312a2ba*/
    }
    nghttp2_mem_free(a1: v22, a2: v23); /*0x10312a2c1*/
  }
  return v9; /*0x10312a1d4*/
}

// Address: 0x10312a2d3 | Name: _nghttp2_submit_origin
__int64 __fastcall nghttp2_submit_origin(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v4; // r14
  __int64 v5; // rbx
  _QWORD *v7; // rax
  __int64 v8; // rsi
  __int64 i; // rdx
  unsigned int v10; // r13d
  __int64 v11; // r15
  __int64 v12; // rax
  __int64 v13; // r13
  char *v14; // r15
  __int64 v15; // r14
  __int64 j; // rbx
  size_t v17; // rdx
  char *v18; // rax
  __int64 v19; // rax
  __int64 v20; // r15
  unsigned int v21; // eax
  __int64 v23; // [rsp+0h] [rbp-40h]
  __int64 v24; // [rsp+8h] [rbp-38h]
  __int64 v25; // [rsp+10h] [rbp-30h]

  if ( *(_BYTE *)(a1 + 2739) == 0 ) /*0x10312a2eb*/
    return (unsigned int)-519; /*0x10312a3a9*/
  v4 = a1; /*0x10312a2f1*/
  v5 = a1 + 2376; /*0x10312a2f4*/
  if ( a4 == 0 ) /*0x10312a2fe*/
  {
    v25 = 0; /*0x10312a3ae*/
    v13 = 0; /*0x10312a3b2*/
    goto LABEL_12; /*0x10312a3b2*/
  }
  v7 = (_QWORD *)(a3 + 8); /*0x10312a307*/
  v8 = 0; /*0x10312a30b*/
  for ( i = a4; i != 0; --i ) /*0x10312a30d*/
  {
    v8 += *v7; /*0x10312a310*/
    v7 += 2; /*0x10312a313*/
  }
  v10 = -501; /*0x10312a320*/
  if ( (unsigned __int64)(v8 + 2 * a4) <= 0x4000 ) /*0x10312a32c*/
  {
    v11 = 16 * a4; /*0x10312a335*/
    v25 = a4; /*0x10312a342*/
    v12 = nghttp2_mem_malloc(a1: a1 + 2376, a2: 16 * a4 + a4 + v8); /*0x10312a346*/
    if ( v12 == 0 ) /*0x10312a34e*/
      return (unsigned int)-901; /*0x10312a34e*/
    v13 = v12; /*0x10312a354*/
    v24 = v4; /*0x10312a357*/
    v23 = v5; /*0x10312a35b*/
    v14 = (char *)(v12 + v11); /*0x10312a35f*/
    v15 = 8; /*0x10312a362*/
    for ( j = v25; j != 0; --j ) /*0x10312a368*/
    {
      *(_QWORD *)(v13 + v15 - 8) = v14; /*0x10312a36c*/
      v17 = *(_QWORD *)(a3 + v15); /*0x10312a371*/
      *(_QWORD *)(v13 + v15) = v17; /*0x10312a375*/
      v18 = nghttp2_cpymem(__dst: v14, a2: *(const void **)(a3 + v15 - 8), a3: v17); /*0x10312a382*/
      *v18 = 0; /*0x10312a38a*/
      v14 = v18 + 1; /*0x10312a38d*/
      v15 += 16; /*0x10312a390*/
    }
    v5 = v23; /*0x10312a399*/
    v4 = v24; /*0x10312a39d*/
LABEL_12:
    v19 = nghttp2_mem_malloc(a1: v5, a2: 160); /*0x10312a3b5*/
    if ( v19 != 0 ) /*0x10312a3c5*/
    {
      v20 = v19; /*0x10312a3c7*/
      nghttp2_outbound_item_init(a1: v19); /*0x10312a3cd*/
      *(_BYTE *)(v20 + 96) = 1; /*0x10312a3d2*/
      *(_QWORD *)(v20 + 16) = v20 + 64; /*0x10312a3de*/
      nghttp2_frame_origin_init(a1: v20, a2: v13, a3: v25); /*0x10312a3ec*/
      v21 = nghttp2_session_add_item(a1: v4, a2: v20); /*0x10312a3f7*/
      if ( v21 != 0 ) /*0x10312a3fe*/
      {
        v10 = v21; /*0x10312a400*/
        nghttp2_frame_origin_free(a1: v20, a2: v5); /*0x10312a409*/
        nghttp2_mem_free(a1: v5, a2: v20); /*0x10312a414*/
      }
      else
      {
        return 0; /*0x10312a42e*/
      }
      return v10; /*0x10312a419*/
    }
    nghttp2_mem_free(a1: v5, a2: v13); /*0x10312a421*/
    return (unsigned int)-901; /*0x10312a426*/
  }
  return v10; /*0x10312a434*/
}

// Address: 0x10312a443 | Name: _nghttp2_submit_priority_update
__int64 __fastcall nghttp2_submit_priority_update(__int64 a1, __int64 a2, int a3, const void *a4, size_t a5)
{
  unsigned int v5; // r13d
  __int64 v10; // rdi
  char *v11; // rax
  __int64 v12; // r13
  __int64 v13; // rax
  __int64 v14; // r15
  unsigned int v15; // eax
  __int64 v17; // [rsp+8h] [rbp-38h]
  __int64 v18; // [rsp+10h] [rbp-30h]

  v5 = -519; /*0x10312a454*/
  if ( *(_BYTE *)(a1 + 2739) == 0 ) /*0x10312a461*/
  {
    if ( *(_DWORD *)(a1 + 2688) == 0 ) /*0x10312a471*/
      return 0; /*0x10312a471*/
    v5 = -501; /*0x10312a498*/
    if ( a3 != 0 && a5 - 16381 >= 0xFFFFFFFFFFFFBFFFLL ) /*0x10312a493*/
    {
      v10 = a1 + 2376; /*0x10312a4a4*/
      if ( a5 != 0 ) /*0x10312a4ae*/
      {
        v11 = (char *)nghttp2_mem_malloc(a1: v10, a2: a5 + 1); /*0x10312a4b7*/
        if ( v11 == nullptr ) /*0x10312a4bf*/
          return (unsigned int)-901; /*0x10312a4bf*/
        v18 = (__int64)v11; /*0x10312a4c5*/
        *nghttp2_cpymem(__dst: v11, a2: a4, a3: a5) = 0; /*0x10312a4d7*/
        v10 = a1 + 2376; /*0x10312a4da*/
      }
      else
      {
        v18 = 0; /*0x10312a4df*/
      }
      v12 = v10; /*0x10312a4ec*/
      v13 = nghttp2_mem_malloc(a1: v10, a2: 160); /*0x10312a4ef*/
      if ( v13 != 0 ) /*0x10312a4f7*/
      {
        v14 = v13; /*0x10312a4f9*/
        v17 = v12; /*0x10312a4fc*/
        nghttp2_outbound_item_init(a1: v13); /*0x10312a503*/
        *(_BYTE *)(v14 + 96) = 1; /*0x10312a508*/
        *(_QWORD *)(v14 + 16) = v14 + 64; /*0x10312a514*/
        nghttp2_frame_priority_update_init(a1: v14, a2: a3, a3: v18, a4: a5); /*0x10312a525*/
        v15 = nghttp2_session_add_item(a1, a2: v14); /*0x10312a530*/
        if ( v15 != 0 ) /*0x10312a537*/
        {
          v5 = v15; /*0x10312a539*/
          nghttp2_frame_priority_update_free(a1: v14, a2: v17); /*0x10312a546*/
          nghttp2_mem_free(a1: v17, a2: v14); /*0x10312a551*/
          return v5; /*0x10312a556*/
        }
        return 0; /*0x10312a55b*/
      }
      nghttp2_mem_free(a1: v12, a2: v18); /*0x10312a564*/
      return (unsigned int)-901; /*0x10312a569*/
    }
  }
  return v5; /*0x10312a572*/
}

// Address: 0x10312a581 | Name: _nghttp2_submit_request
__int64 __fastcall nghttp2_submit_request(__int64 a1, __int64 a2, __int64 a3, __int64 a4, _OWORD *a5, __int64 a6)
{
  __int64 v10; // rax
  _BYTE v12[56]; // [rsp+8h] [rbp-38h] BYREF

  v10 = nghttp2_data_provider_wrap_v1(a1: (__int64)v12, a2: a5); /*0x10312a5a3*/
  return submit_request_shared(a1, a2: a3, a3: a4, a4: v10, a5: a6); /*0x10312a5bc*/
}

// Address: 0x10312a638 | Name: _nghttp2_submit_request2
__int64 __fastcall nghttp2_submit_request2(__int64 a1, __int64 a2, __int64 a3, __int64 a4, _OWORD *a5, __int64 a6)
{
  __int64 v10; // rax
  _BYTE v12[56]; // [rsp+8h] [rbp-38h] BYREF

  v10 = nghttp2_data_provider_wrap_v2(a1: (__int64)v12, a2: a5); /*0x10312a65a*/
  return submit_request_shared(a1, a2: a3, a3: a4, a4: v10, a5: a6); /*0x10312a673*/
}

// Address: 0x10312a680 | Name: _nghttp2_submit_response
__int64 __fastcall nghttp2_submit_response(__int64 a1, unsigned int a2, __int64 a3, __int64 a4, _OWORD *a5)
{
  __int64 v9; // rax
  _BYTE v11[56]; // [rsp+8h] [rbp-38h] BYREF

  v9 = nghttp2_data_provider_wrap_v1(a1: (__int64)v11, a2: a5); /*0x10312a6a2*/
  return submit_response_shared(a1, a2, a3, a4, a5: v9); /*0x10312a6bb*/
}

// Address: 0x10312a745 | Name: _nghttp2_submit_response2
__int64 __fastcall nghttp2_submit_response2(__int64 a1, unsigned int a2, __int64 a3, __int64 a4, _OWORD *a5)
{
  __int64 v9; // rax
  _BYTE v11[56]; // [rsp+8h] [rbp-38h] BYREF

  v9 = nghttp2_data_provider_wrap_v2(a1: (__int64)v11, a2: a5); /*0x10312a767*/
  return submit_response_shared(a1, a2, a3, a4, a5: v9); /*0x10312a780*/
}

// Address: 0x10312a78d | Name: _nghttp2_submit_data_shared
__int64 __fastcall nghttp2_submit_data_shared(__int64 a1, char a2, int a3, __int64 a4)
{
  __int64 v8; // rax
  __int64 v9; // r14
  unsigned int v10; // ebx
  unsigned int v11; // eax
  unsigned int v12; // r15d
  __int64 v14; // [rsp+0h] [rbp-30h]

  if ( a3 != 0 ) /*0x10312a79d*/
  {
    v14 = a1 + 2376; /*0x10312a7bb*/
    v8 = nghttp2_mem_malloc(a1: a1 + 2376, a2: 160); /*0x10312a7bf*/
    if ( v8 != 0 ) /*0x10312a7c7*/
    {
      v9 = v8; /*0x10312a7c9*/
      nghttp2_outbound_item_init(a1: v8); /*0x10312a7d3*/
      *(_QWORD *)(v9 + 112) = *(_QWORD *)(a4 + 16); /*0x10312a7dc*/
      *(_OWORD *)(v9 + 96) = *(_OWORD *)a4; /*0x10312a7e3*/
      *(_BYTE *)(v9 + 121) = 0; /*0x10312a7e8*/
      *(_BYTE *)(v9 + 120) = a2 & 1; /*0x10312a7ed*/
      v10 = 0; /*0x10312a7f1*/
      nghttp2_frame_data_init(a1: v9, a2: 0, a3); /*0x10312a7fb*/
      v11 = nghttp2_session_add_item(a1, a2: v9); /*0x10312a806*/
      if ( v11 != 0 ) /*0x10312a80d*/
      {
        v12 = v11; /*0x10312a80f*/
        nghttp2_frame_data_free(); /*0x10312a815*/
        nghttp2_mem_free(a1: v14, a2: v9); /*0x10312a821*/
        return v12; /*0x10312a826*/
      }
    }
    else
    {
      return (unsigned int)-901; /*0x10312a832*/
    }
  }
  else
  {
    return (unsigned int)-501; /*0x10312a82b*/
  }
  return v10; /*0x10312a83d*/
}

// Address: 0x10312a848 | Name: _nghttp2_submit_data
__int64 __fastcall nghttp2_submit_data(__int64 a1, char a2, int a3, _OWORD *a4)
{
  __int64 v7; // rax
  _BYTE v9[48]; // [rsp+0h] [rbp-30h] BYREF

  v7 = nghttp2_data_provider_wrap_v1(a1: (__int64)v9, a2: a4); /*0x10312a864*/
  return nghttp2_submit_data_shared(a1, a2, a3, a4: v7); /*0x10312a879*/
}

// Address: 0x10312a884 | Name: _nghttp2_submit_data2
__int64 __fastcall nghttp2_submit_data2(__int64 a1, char a2, int a3, _OWORD *a4)
{
  __int64 v7; // rax
  _BYTE v9[48]; // [rsp+0h] [rbp-30h] BYREF

  v7 = nghttp2_data_provider_wrap_v2(a1: (__int64)v9, a2: a4); /*0x10312a8a0*/
  return nghttp2_submit_data_shared(a1, a2, a3, a4: v7); /*0x10312a8b5*/
}

// Address: 0x10312a8c0 | Name: _nghttp2_pack_settings_payload
__int64 nghttp2_pack_settings_payload()
{
  return nghttp2_pack_settings_payload2(); /*0x10312a8c4*/
}

// Address: 0x10312a8ca | Name: _nghttp2_pack_settings_payload2
__int64 __fastcall nghttp2_pack_settings_payload2(__int64 a1, unsigned __int64 a2, __int64 a3, __int64 a4)
{
  __int64 result; // rax

  if ( (unsigned int)nghttp2_iv_check(a1: a3, a2: a4) == 0 ) /*0x10312a8ee*/
    return -501; /*0x10312a91a*/
  result = -525; /*0x10312a8f8*/
  if ( 6 * a4 <= a2 ) /*0x10312a902*/
    return nghttp2_frame_pack_settings_payload(a1, a2: a3, a3: a4); /*0x10312a915*/
  return result; /*0x10312a90d*/
}

// Address: 0x10312a92a | Name: _nghttp2_submit_extension
__int64 __fastcall nghttp2_submit_extension(__int64 a1, char a2, char a3, int a4, __int64 a5)
{
  unsigned int v6; // r12d
  __int64 v10; // rax
  __int64 v11; // r13
  unsigned int v12; // eax
  __int64 v15; // [rsp+10h] [rbp-30h]

  v6 = -501; /*0x10312a93e*/
  if ( (unsigned __int8)a2 >= 0xAu ) /*0x10312a948*/
  {
    if ( *(_QWORD *)(a1 + 2328) != 0 || *(_QWORD *)(a1 + 2320) != 0 ) /*0x10312a966*/
    {
      v15 = a1 + 2376; /*0x10312a97b*/
      v10 = nghttp2_mem_malloc(a1: a1 + 2376, a2: 160); /*0x10312a97f*/
      if ( v10 != 0 ) /*0x10312a987*/
      {
        v11 = v10; /*0x10312a989*/
        nghttp2_outbound_item_init(a1: v10); /*0x10312a98f*/
        nghttp2_frame_extension_init(a1: v11, a2, a3, a4, a5); /*0x10312a9a6*/
        v12 = nghttp2_session_add_item(a1, a2: v11); /*0x10312a9b1*/
        if ( v12 != 0 ) /*0x10312a9b8*/
        {
          v6 = v12; /*0x10312a9ba*/
          nghttp2_frame_extension_free(); /*0x10312a9c0*/
          nghttp2_mem_free(a1: v15, a2: v11); /*0x10312a9cc*/
        }
        else
        {
          return 0; /*0x10312a9db*/
        }
      }
      else
      {
        return (unsigned int)-901; /*0x10312a9d3*/
      }
    }
    else
    {
      return (unsigned int)-519; /*0x10312a9e0*/
    }
  }
  return v6; /*0x10312a9e9*/
}

// Address: 0x10312a9f8 | Name: _nghttp2_time_now_sec
time_t nghttp2_time_now_sec()
{
  time_t result; // rax
  timespec __tp; // [rsp+8h] [rbp-18h] BYREF

  if ( clock_gettime(__clock_id: _CLOCK_MONOTONIC, &__tp) != -1 ) /*0x10312aa12*/
    return __tp.tv_sec; /*0x10312aa14*/
  result = time(a1: nullptr); /*0x10312aa1e*/
  if ( result == -1 ) /*0x10312aa27*/
    return 0; /*0x10312aa27*/
  return result; /*0x10312aa2b*/
}

// Address: 0x10312aa32 | Name: _nghttp2_version
void *__fastcall nghttp2_version(int a1)
{
  void *result; // rax

  result = nullptr; /*0x10312aa36*/
  if ( a1 < 83201 ) /*0x10312aa45*/
    return &version; /*0x10312aa45*/
  return result; /*0x10312aa49*/
}

// Address: 0x10312c46c | Name: _nghttp3_balloc_init
__int64 __fastcall nghttp3_balloc_init(_QWORD *a1, __int64 a2, __int64 a3)
{
  *a1 = a3; /*0x10312c470*/
  a1[1] = a2; /*0x10312c473*/
  a1[2] = 0; /*0x10312c477*/
  return nghttp3_buf_wrap_init(a1: a1 + 3, a2: "", a3: 0); /*0x10312c48c*/
}

// Address: 0x10312c492 | Name: _nghttp3_balloc_free
__int64 __fastcall nghttp3_balloc_free(__int64 a1)
{
  __int64 result; // rax

  if ( a1 != 0 ) /*0x10312c499*/
    return nghttp3_balloc_clear(); /*0x10312c49c*/
  return result; /*0x10312c49b*/
}

// Address: 0x10312c4a3 | Name: _nghttp3_balloc_clear
__int64 __fastcall nghttp3_balloc_clear(_QWORD *a1)
{
  _QWORD *v2; // rsi
  _QWORD *v3; // r14

  v2 = (_QWORD *)a1[2]; /*0x10312c4ad*/
  if ( v2 != nullptr ) /*0x10312c4b4*/
  {
    do /*0x10312c4c7*/
    {
      v3 = (_QWORD *)*v2; /*0x10312c4b6*/
      nghttp3_mem_free(a1: *a1, a2: v2); /*0x10312c4bc*/
      v2 = v3; /*0x10312c4c1*/
    }
    while ( v3 != nullptr ); /*0x10312c4c7*/
  }
  a1[2] = 0; /*0x10312c4c9*/
  return nghttp3_buf_wrap_init(a1: a1 + 3, a2: "", a3: 0); /*0x10312c4e1*/
}

// Address: 0x10312c4ea | Name: _nghttp3_balloc_get
__int64 __fastcall nghttp3_balloc_get(_QWORD *a1, _QWORD *a2, unsigned __int64 a3)
{
  _QWORD *v6; // r12
  __int64 v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // r8
  _QWORD *v10; // rax
  __int64 v11; // rax

  v6 = a1 + 3; /*0x10312c4fe*/
  if ( nghttp3_buf_left(a1: a1 + 3) >= a3 ) /*0x10312c50d*/
    goto LABEL_4; /*0x10312c50d*/
  v10 = (_QWORD *)nghttp3_mem_malloc(a1: *a1, a2: a1[1] + 16LL, a3: v7, a4: v8, a5: v9); /*0x10312c51a*/
  if ( v10 != nullptr ) /*0x10312c522*/
  {
    *v10 = a1[2]; /*0x10312c528*/
    a1[2] = v10; /*0x10312c52b*/
    nghttp3_buf_wrap_init(a1: v6, a2: ((unsigned __int64)v10 + 23) & 0xFFFFFFFFFFFFFFF0LL, a3: a1[1]); /*0x10312c541*/
LABEL_4:
    v11 = a1[6]; /*0x10312c546*/
    *a2 = v11; /*0x10312c54a*/
    a1[6] = v11 + ((a3 + 15) & 0xFFFFFFFFFFFFFFF0LL); /*0x10312c558*/
    return 0; /*0x10312c566*/
  }
  return 4294966395LL; /*0x10312c55e*/
}

// Address: 0x10312c56e | Name: _nghttp3_buf_init
void __fastcall nghttp3_buf_init(_OWORD *a1)
{
  a1[1] = 0; /*0x10312c575*/
  *a1 = 0; /*0x10312c579*/
}

// Address: 0x10312c57e | Name: _nghttp3_buf_wrap_init
void __fastcall nghttp3_buf_wrap_init(_QWORD *a1, __int64 a2, __int64 a3)
{
  a1[3] = a2; /*0x10312c582*/
  a1[2] = a2; /*0x10312c586*/
  *a1 = a2; /*0x10312c58a*/
  a1[1] = a2 + a3; /*0x10312c590*/
}

// Address: 0x10312c596 | Name: _nghttp3_buf_free
__int64 __fastcall nghttp3_buf_free(_QWORD *a1, __int64 a2)
{
  return nghttp3_mem_free(a1: a2, a2: *a1); /*0x10312c5a3*/
}

// Address: 0x10312c5a9 | Name: _nghttp3_buf_left
__int64 __fastcall nghttp3_buf_left(__int64 a1)
{
  return *(_QWORD *)(a1 + 8) - *(_QWORD *)(a1 + 24); /*0x10312c5b5*/
}

// Address: 0x10312c5b7 | Name: _nghttp3_buf_len
__int64 __fastcall nghttp3_buf_len(__int64 a1)
{
  return *(_QWORD *)(a1 + 24) - *(_QWORD *)(a1 + 16); /*0x10312c5c3*/
}

// Address: 0x10312c5c5 | Name: _nghttp3_buf_cap
__int64 __fastcall nghttp3_buf_cap(_QWORD *a1)
{
  return a1[1] - *a1; /*0x10312c5d0*/
}

// Address: 0x10312c5d2 | Name: _nghttp3_buf_offset
__int64 __fastcall nghttp3_buf_offset(_QWORD *a1)
{
  return a1[2] - *a1; /*0x10312c5dd*/
}

// Address: 0x10312c5df | Name: _nghttp3_buf_reset
__int64 __fastcall nghttp3_buf_reset(__int64 *a1)
{
  __int64 result; // rax

  result = *a1; /*0x10312c5e3*/
  a1[3] = *a1; /*0x10312c5e6*/
  a1[2] = result; /*0x10312c5ea*/
  return result; /*0x10312c5ee*/
}

// Address: 0x10312c5f0 | Name: _nghttp3_buf_reserve
__int64 __fastcall nghttp3_buf_reserve(__int64 *a1, unsigned __int64 a2, __int64 a3)
{
  __int64 v3; // r12
  __int64 result; // rax
  __int64 v7; // rbx
  __int64 v8; // r13
  __int64 v9; // rax

  v3 = *a1; /*0x10312c5fe*/
  result = 0; /*0x10312c608*/
  if ( a1[1] - *a1 < a2 ) /*0x10312c60d*/
  {
    v7 = a1[2]; /*0x10312c615*/
    v8 = a1[3]; /*0x10312c619*/
    v9 = nghttp3_mem_realloc(a1: a3, a2: v3, a3: a2); /*0x10312c626*/
    if ( v9 != 0 ) /*0x10312c62e*/
    {
      *a1 = v9; /*0x10312c63f*/
      a1[1] = v9 + a2; /*0x10312c642*/
      a1[2] = v9 + v7 - v3; /*0x10312c646*/
      a1[3] = v9 + v8 - v3; /*0x10312c64a*/
      return 0; /*0x10312c64e*/
    }
    else
    {
      return 4294966395LL; /*0x10312c652*/
    }
  }
  return result; /*0x10312c65b*/
}

// Address: 0x10312c666 | Name: _nghttp3_buf_swap
void __fastcall nghttp3_buf_swap(__int128 *a1, __int128 *a2)
{
  __int128 v2; // xmm0
  __int128 v3; // [rsp+0h] [rbp-20h]
  __int128 v4; // [rsp+10h] [rbp-10h]

  v4 = a1[1]; /*0x10312c671*/
  v3 = *a1; /*0x10312c675*/
  v2 = *a2; /*0x10312c679*/
  a1[1] = a2[1]; /*0x10312c680*/
  *a1 = v2; /*0x10312c684*/
  a2[1] = v4; /*0x10312c68f*/
  *a2 = v3; /*0x10312c693*/
}

// Address: 0x10312c698 | Name: _nghttp3_typed_buf_init
__int64 __fastcall nghttp3_typed_buf_init(__int64 a1, __int128 *a2, int a3)
{
  __int128 v3; // xmm0
  __int64 result; // rax

  v3 = *a2; /*0x10312c69c*/
  *(_OWORD *)(a1 + 16) = a2[1]; /*0x10312c6a3*/
  *(_OWORD *)a1 = v3; /*0x10312c6a7*/
  *(_DWORD *)(a1 + 32) = a3; /*0x10312c6aa*/
  result = *(_QWORD *)(a1 + 16); /*0x10312c6ad*/
  *(_QWORD *)a1 = result; /*0x10312c6b1*/
  return result; /*0x10312c6b4*/
}

// Address: 0x10312c6b6 | Name: _nghttp3_typed_buf_shared_init
__int64 __fastcall nghttp3_typed_buf_shared_init(__int64 a1, __int128 *a2)
{
  __int128 v2; // xmm0
  __int64 result; // rax

  v2 = *a2; /*0x10312c6ba*/
  *(_OWORD *)(a1 + 16) = a2[1]; /*0x10312c6c1*/
  *(_OWORD *)a1 = v2; /*0x10312c6c5*/
  *(_DWORD *)(a1 + 32) = 1; /*0x10312c6c8*/
  result = *(_QWORD *)(a1 + 24); /*0x10312c6cf*/
  *(_QWORD *)(a1 + 16) = result; /*0x10312c6d3*/
  *(_QWORD *)a1 = result; /*0x10312c6d7*/
  return result; /*0x10312c6da*/
}

// Address: 0x10312c6dc | Name: _nghttp3_callbacks_convert_to_latest
_OWORD *__fastcall nghttp3_callbacks_convert_to_latest(_OWORD *a1, int a2, const void *a3)
{
  _OWORD *v3; // rbx

  if ( a2 == 3 ) /*0x10312c6e5*/
    return a3; /*0x10312c6e7*/
  v3 = a1; /*0x10312c6ee*/
  a1[8] = 0; /*0x10312c6f4*/
  a1[7] = 0; /*0x10312c6fb*/
  a1[6] = 0; /*0x10312c6ff*/
  a1[5] = 0; /*0x10312c703*/
  a1[4] = 0; /*0x10312c707*/
  a1[3] = 0; /*0x10312c70b*/
  a1[2] = 0; /*0x10312c70f*/
  a1[1] = 0; /*0x10312c713*/
  *a1 = 0; /*0x10312c717*/
  *((_QWORD *)a1 + 18) = 0; /*0x10312c71a*/
  callbacks_copy(a1, a2: a3, a3: a2); /*0x10312c72a*/
  return v3; /*0x10312c736*/
}

// Address: 0x10312c76e | Name: _nghttp3_callbacks_convert_to_old
void *__fastcall nghttp3_callbacks_convert_to_old(int a1, void *a2, const void *a3)
{
  return callbacks_copy(a1: a2, a2: a3, a3: a1); /*0x10312c77c*/
}

// Address: 0x10312c782 | Name: _nghttp3_callbackslen_version
__int64 __fastcall nghttp3_callbackslen_version(int a1)
{
  unsigned int v1; // edi

  v1 = a1 - 1; /*0x10312c782*/
  if ( v1 >= 3 ) /*0x10312c787*/
    nghttp3_unreachable_fail(a1: "nghttp3_callbacks.c", a2: 75, a3: "nghttp3_callbackslen_version"); /*0x10312c7ae*/
  return qword_1094C6898[v1]; /*0x10312c796*/
}

// Address: 0x10312c7b4 | Name: _nghttp3_objalloc_chunk_get
__int64 __fastcall nghttp3_objalloc_chunk_get(_QWORD *a1)
{
  __int64 v1; // rax
  __int64 result; // rax
  __int64 v4; // [rsp+0h] [rbp-10h] BYREF

  v4 = v1; /*0x10312c7b9*/
  result = nghttp3_opl_pop(a1: a1 + 7); /*0x10312c7c1*/
  if ( result == 0 ) /*0x10312c7c9*/
  {
    if ( (unsigned int)nghttp3_balloc_get(a1, a2: &v4, a3: 8u) != 0 ) /*0x10312c7de*/
      return 0; /*0x10312c7e6*/
    else
      return v4; /*0x10312c7e0*/
  }
  return result; /*0x10312c7ec*/
}

// Address: 0x10312c7ef | Name: _nghttp3_objalloc_chunk_len_get
__int64 __fastcall nghttp3_objalloc_chunk_len_get(_QWORD *a1, unsigned __int64 a2)
{
  __int64 result; // rax
  _QWORD v5[3]; // [rsp+8h] [rbp-18h] BYREF

  result = nghttp3_opl_pop(a1: a1 + 7); /*0x10312c804*/
  if ( result == 0 ) /*0x10312c80c*/
  {
    if ( (unsigned int)nghttp3_balloc_get(a1, a2: v5, a3: a2) != 0 ) /*0x10312c81f*/
      return 0; /*0x10312c827*/
    else
      return v5[0]; /*0x10312c821*/
  }
  return result; /*0x10312c829*/
}

// Address: 0x10312c832 | Name: _nghttp3_conn_client_new_versioned
__int64 __fastcall nghttp3_conn_client_new_versioned(
        __int64 *a1,
        unsigned int a2,
        __int64 a3,
        unsigned int a4,
        __int64 a5,
        __int64 a6,
        __int64 a7)
{
  return conn_new_0(a1, a2: 0, a3: a2, a4: a3, a5: a4, a6: a5, a7: a6, a8: a7); /*0x10312c853*/
}

// Address: 0x10312cbd2 | Name: _nghttp3_conn_server_new_versioned
__int64 __fastcall nghttp3_conn_server_new_versioned(
        __int64 *a1,
        unsigned int a2,
        __int64 a3,
        unsigned int a4,
        __int64 a5,
        __int64 a6,
        __int64 a7)
{
  return conn_new_0(a1, a2: 1, a3: a2, a4: a3, a5: a4, a6: a5, a7: a6, a8: a7); /*0x10312cbf6*/
}

// Address: 0x10312cbf8 | Name: _nghttp3_conn_del
__int64 __fastcall nghttp3_conn_del(__int64 *a1)
{
  _QWORD *v2; // r14
  __int64 i; // r14
  __int64 result; // rax

  if ( a1 != nullptr ) /*0x10312cbfb*/
  {
    v2 = a1 + 306; /*0x10312cc0b*/
    nghttp3_buf_free(a1: a1 + 310, a2: a1[260]); /*0x10312cc20*/
    nghttp3_buf_free(a1: v2, a2: a1[260]); /*0x10312cc2f*/
    nghttp3_idtr_free(a1: a1 + 277); /*0x10312cc3b*/
    for ( i = 220; i != 260; i += 5 ) /*0x10312cc40*/
      nghttp3_pq_free(a1: &a1[i]); /*0x10312cc4a*/
    nghttp3_pq_free(a1: a1 + 210); /*0x10312cc63*/
    nghttp3_qpack_encoder_free(a1: a1 + 81); /*0x10312cc6f*/
    nghttp3_qpack_decoder_free(a1: a1 + 42); /*0x10312cc7b*/
    nghttp3_map_each(a1: a1 + 35, a2: free_stream, a3: 0); /*0x10312cc93*/
    nghttp3_map_free(a1: a1 + 35); /*0x10312cc9b*/
    nghttp3_objalloc_free(a1: a1 + 8); /*0x10312cca4*/
    nghttp3_objalloc_free(a1); /*0x10312ccac*/
    nghttp3_mem_free(a1: a1[260], a2: a1[304]); /*0x10312ccbf*/
    nghttp3_mem_free(a1: a1[260], a2: a1[274]); /*0x10312ccd2*/
    return nghttp3_mem_free(a1: a1[260], a2: a1); /*0x10312cce5*/
  }
  return result; /*0x10312ccea*/
}

// Address: 0x10312ccf8 | Name: _nghttp3_conn_read_stream
__int64 __fastcall nghttp3_conn_read_stream(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5)
{
  return nghttp3_conn_read_stream2(a1, a2, a3, a4, a5, a6: -1); /*0x10312cd03*/
}

// Address: 0x10312cd09 | Name: _nghttp3_conn_read_stream2
__int64 __fastcall nghttp3_conn_read_stream2(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        unsigned int a5,
        __int64 a6)
{
  __int64 v10; // r12
  __int64 result; // rax
  unsigned int v12; // eax
  unsigned int v13; // r12d
  int v14; // ecx
  __int64 v15; // rax
  __int64 v16; // rdx
  __int64 v17; // rsi
  char v18; // [rsp+8h] [rbp-48h] BYREF
  __int64 v19; // [rsp+10h] [rbp-40h]
  __int64 v20; // [rsp+18h] [rbp-38h]
  _QWORD v21[6]; // [rsp+20h] [rbp-30h] BYREF

  v19 = a6; /*0x10312cd1a*/
  v20 = a3; /*0x10312cd24*/
  v10 = nghttp3_map_find(a1: a1 + 280); /*0x10312cd3a*/
  v21[0] = v10; /*0x10312cd3d*/
  if ( v10 == 0 ) /*0x10312cd44*/
  {
    if ( *(_DWORD *)(a1 + 2096) != 0 ) /*0x10312cd98*/
    {
      if ( (unsigned int)nghttp3_client_stream_bidi(a1: a2) != 0 ) /*0x10312cda4*/
      {
        v12 = conn_bidi_idtr_open(a1); /*0x10312cdb0*/
        if ( v12 != 0 ) /*0x10312cdb7*/
        {
          v13 = v12; /*0x10312cdbd*/
          if ( (unsigned int)nghttp3_err_is_fatal(a1: v12) != 0 ) /*0x10312cdc9*/
            return (int)v13; /*0x10312cdce*/
        }
        v15 = *(_QWORD *)(a1 + 2408); /*0x10312ce4a*/
        if ( v15 <= a2 ) /*0x10312ce54*/
          v15 = a2; /*0x10312ce54*/
        *(_QWORD *)(a1 + 2408) = v15; /*0x10312ce58*/
        LODWORD(result) = nghttp3_conn_create_stream(a1, a2: v21, a3: a2); /*0x10312ce69*/
        if ( (_DWORD)result == 0 ) /*0x10312ce70*/
        {
          v14 = 1; /*0x10312ce72*/
          if ( (*(_BYTE *)(a1 + 2100) & 0x40) == 0 ) /*0x10312ce7f*/
            goto LABEL_31; /*0x10312ce7f*/
          if ( *(_QWORD *)(a1 + 2536) > a2 ) /*0x10312ce88*/
            goto LABEL_31; /*0x10312ce88*/
          v17 = v21[0]; /*0x10312ce8a*/
          *(_DWORD *)(v21[0] + 584LL) = 5; /*0x10312ce8e*/
          LODWORD(result) = nghttp3_conn_reject_stream(a1, a2: v17, a3: v16, a4: 1); /*0x10312ce9b*/
          v14 = 1; /*0x10312cea0*/
          if ( (_DWORD)result == 0 ) /*0x10312cea7*/
            goto LABEL_31; /*0x10312cea7*/
        }
        return (int)result; /*0x10312cef6*/
      }
      if ( (unsigned int)nghttp3_client_stream_uni(a1: a2) != 0 ) /*0x10312ceb5*/
      {
        if ( a5 != 0 && a4 == 0 ) /*0x10312ceba*/
          return 0; /*0x10312cec4*/
        LODWORD(result) = nghttp3_conn_create_stream(a1, a2: v21, a3: a2); /*0x10312cedd*/
        if ( (_DWORD)result != 0 ) /*0x10312cee4*/
          return (int)result; /*0x10312cee4*/
        v14 = 1; /*0x10312cef7*/
        goto LABEL_31; /*0x10312cef7*/
      }
    }
    else if ( (unsigned int)nghttp3_server_stream_uni(a1: a2) != 0 ) /*0x10312cddd*/
    {
      if ( a5 != 0 && a4 == 0 ) /*0x10312cde6*/
        return 0; /*0x10312cdf0*/
      LODWORD(result) = nghttp3_conn_create_stream(a1, a2: v21, a3: a2); /*0x10312ce00*/
      if ( (_DWORD)result != 0 ) /*0x10312ce07*/
        return (int)result; /*0x10312ce07*/
      v14 = 9; /*0x10312ce0d*/
LABEL_31:
      v10 = v21[0]; /*0x10312cefc*/
      *(_DWORD *)(v21[0] + 608LL) = v14; /*0x10312cf00*/
      goto LABEL_2; /*0x10312cf08*/
    }
    return -609; /*0x10312ced1*/
  }
LABEL_2:
  if ( a5 == 0 && a4 == 0 ) /*0x10312cd49*/
    return 0; /*0x10312cec8*/
  if ( (unsigned int)nghttp3_stream_uni(a1: a2) != 0 ) /*0x10312cd63*/
    return nghttp3_conn_read_uni(a1, a2: v10, a3: v20, a4, a5, a6: v19); /*0x10312cd8b*/
  if ( a5 != 0 ) /*0x10312ce19*/
    *(_BYTE *)(v10 + 648) |= 0x20u; /*0x10312ce1b*/
  return nghttp3_conn_read_bidi(a1, a2: (unsigned int)&v18, a3: v10, a4: v20, a5: a4, a6: a5, a7: v19); /*0x10312cd7d*/
}

// Address: 0x10312cf0d | Name: _nghttp3_conn_find_stream
__int64 __fastcall nghttp3_conn_find_stream(__int64 a1)
{
  return nghttp3_map_find(a1: a1 + 280); /*0x10312cf18*/
}

// Address: 0x10312cf5c | Name: _nghttp3_conn_create_stream
__int64 __fastcall nghttp3_conn_create_stream(__int64 a1, _QWORD *a2, __int64 a3)
{
  unsigned int v6; // r12d
  __int64 v7; // rdx
  unsigned int v8; // eax
  __int64 (__fastcall *v10)(__int64, __int64, __int64, __int64); // [rsp+0h] [rbp-30h] BYREF
  _QWORD v11[5]; // [rsp+8h] [rbp-28h] BYREF

  v10 = conn_stream_acked_data; /*0x10312cf7f*/
  v6 = ((__int64 (__fastcall *)(_QWORD *, __int64, __int64 (__fastcall **)(__int64, __int64, __int64, __int64), __int64, __int64, _QWORD))nghttp3_stream_new)( /*0x10312cf9c*/
         a1: v11,
         a2: a3,
         a3: &v10,
         a4: a1,
         a5: a1 + 64,
         a6: *(_QWORD *)(a1 + 2080));
  if ( v6 == 0 ) /*0x10312cfa1*/
  {
    v7 = v11[0]; /*0x10312cfa3*/
    *(_QWORD *)(v11[0] + 448LL) = a1; /*0x10312cfa7*/
    v8 = nghttp3_map_insert(a1: a1 + 280, a2: *(_QWORD *)(v7 + 32)); /*0x10312cfb9*/
    if ( v8 != 0 ) /*0x10312cfc0*/
    {
      v6 = v8; /*0x10312cfc2*/
      nghttp3_stream_del(a1: v11[0]); /*0x10312cfc9*/
    }
    else
    {
      if ( *(_DWORD *)(a1 + 2096) != 0 && (unsigned int)nghttp3_client_stream_bidi(a1: a3) != 0 ) /*0x10312cfe4*/
        ++*(_QWORD *)(a1 + 2360); /*0x10312cfe6*/
      *a2 = v11[0]; /*0x10312cff1*/
      return 0; /*0x10312cff4*/
    }
  }
  return v6; /*0x10312cffa*/
}

// Address: 0x10312d007 | Name: _nghttp3_conn_reject_stream
__int64 __fastcall nghttp3_conn_reject_stream(_QWORD *a1, __int64 a2)
{
  __int64 (__fastcall *v4)(_QWORD *, _QWORD, __int64, _QWORD, _QWORD); // rax
  int v5; // ecx
  __int64 result; // rax
  __int64 (__fastcall *v7)(_QWORD *, _QWORD, __int64, _QWORD, _QWORD); // rax
  int v8; // ecx

  v4 = (__int64 (__fastcall *)(_QWORD *, _QWORD, __int64, _QWORD, _QWORD))a1[26]; /*0x10312d014*/
  if ( v4 == nullptr /*0x10312d045*/
    || (v5 = v4(a1, a2: *(_QWORD *)(a2 + 32), a3: 267, a4: a1[261], a5: *(_QWORD *)(a2 + 456)),
        result = 4294966394LL,
        v5 == 0) )
  {
    v7 = (__int64 (__fastcall *)(_QWORD *, _QWORD, __int64, _QWORD, _QWORD))a1[28]; /*0x10312d047*/
    if ( v7 != nullptr ) /*0x10312d051*/
    {
      v8 = v7(a1, a2: *(_QWORD *)(a2 + 32), a3: 267, a4: a1[261], a5: *(_QWORD *)(a2 + 456)); /*0x10312d06f*/
      result = 4294966394LL; /*0x10312d073*/
      if ( v8 == 0 ) /*0x10312d078*/
        return 0; /*0x10312d078*/
    }
    else
    {
      return 0; /*0x10312d07d*/
    }
  }
  return result; /*0x10312d07f*/
}

// Address: 0x10312d084 | Name: _nghttp3_conn_read_uni
__int64 __fastcall nghttp3_conn_read_uni(__int64 a1, __int64 a2, __int64 a3, __int64 a4, unsigned int a5, __int64 a6)
{
  __int64 v7; // rbx
  __int64 v8; // r8
  __int64 v10; // r12
  __int64 result; // rax
  int v12; // ecx
  __int64 v13; // r15
  __int64 control; // rax
  __int64 *v15; // r12
  __int64 varint; // rax
  __int64 v17; // rcx
  __int64 v18; // r8
  int v19; // ecx
  int v20; // ecx
  int v21; // ecx
  int v22; // eax
  int v23; // ecx
  __int64 (__fastcall *v24)(__int64, _QWORD, __int64, _QWORD, _QWORD, __int64); // rax
  int v25; // eax
  int v26; // ecx
  __int64 v27; // [rsp+8h] [rbp-48h]
  __int64 v29; // [rsp+18h] [rbp-38h]

  v7 = a4; /*0x10312d098*/
  v8 = a3; /*0x10312d09b*/
  v10 = a1; /*0x10312d0a1*/
  if ( (*(_BYTE *)(a2 + 648) & 1) != 0 ) /*0x10312d0ab*/
  {
    v13 = 0; /*0x10312d114*/
    goto LABEL_8; /*0x10312d114*/
  }
  LOBYTE(a4) = a4 != 0 || a5 == 0; /*0x10312d0b9*/
  if ( v7 == 0 && a5 != 0 ) /*0x10312d0b6*/
  {
    result = -606; /*0x10312d0c1*/
    if ( *(_QWORD *)(a2 + 520) == 0 ) /*0x10312d0d0*/
    {
      if ( a6 == -1 || (v12 = nghttp3_ratelim_drain(a1: a1 + 1720, a2: 1, a3: a6, a4, a5: a3), result = -610, v12 == 0) ) /*0x10312d0fc*/
      {
        conn_delete_stream(a1: v10, (_QWORD *)a2); /*0x10312d108*/
        return 0; /*0x10312d10d*/
      }
    }
    return result; /*0x10312d10f*/
  }
  v29 = a6; /*0x10312d164*/
  v15 = (__int64 *)(a2 + 512); /*0x10312d16c*/
  varint = nghttp3_read_varint(a1: a2 + 512, a2: a3, a3: a3 + v7, a4: a5); /*0x10312d184*/
  if ( varint < 0 ) /*0x10312d18c*/
    return -606; /*0x10312d216*/
  v13 = varint; /*0x10312d192*/
  if ( *(_QWORD *)(a2 + 520) != 0 ) /*0x10312d19d*/
  {
    v10 = a1; /*0x10312d1ab*/
    a6 = v29; /*0x10312d1af*/
    v18 = a3; /*0x10312d1b3*/
    if ( (*(_BYTE *)(a2 + 648) & 1) == 0 ) /*0x10312d1b7*/
      return v7; /*0x10312d1c0*/
LABEL_34:
    if ( *(_QWORD *)(a2 + 504) != -1 ) /*0x10312d31c*/
      goto LABEL_35; /*0x10312d31c*/
    if ( a6 == -1 /*0x10312d35d*/
      || (v22 = nghttp3_ratelim_drain(a1: v10 + 1720, a2: 1, a3: a6, a4: v17, a5: v18),
          v18 = a3,
          a6 = v29,
          v23 = v22,
          result = -610,
          v23 == 0) )
    {
      if ( a5 != 0 /*0x10312d3a5*/
        || (v24 = *(__int64 (__fastcall **)(__int64, _QWORD, __int64, _QWORD, _QWORD, __int64))(v10 + 208)) == nullptr
        || (v25 = v24(
                    a1: v10,
                    a2: *(_QWORD *)(a2 + 32),
                    a3: 259,
                    a4: *(_QWORD *)(v10 + 2088),
                    a5: *(_QWORD *)(a2 + 456),
                    a6),
            v18 = a3,
            a6 = v29,
            v26 = v25,
            result = -902,
            v26 == 0) )
      {
LABEL_35:
        v7 -= v13; /*0x10312d31e*/
        if ( v7 == 0 ) /*0x10312d321*/
          return v13; /*0x10312d214*/
        v8 = v13 + v18; /*0x10312d327*/
LABEL_8:
        switch ( *(_QWORD *)(a2 + 504) ) /*0x10312d139*/
        {
          case 0xFFFFFFFFFFFFFFFFLL: /*0x10312d139*/
            goto LABEL_20;
          case 0LL: /*0x10312d139*/
            result = -605; /*0x10312d13b*/
            if ( a5 != 0 ) /*0x10312d145*/
              return result; /*0x10312d145*/
            control = nghttp3_conn_read_control(a1: v10, a2, a3: v8, a4: v7, a5: a6); /*0x10312d15a*/
            break; /*0x10312d15f*/
          case 2LL: /*0x10312d139*/
            result = -605; /*0x10312d1c2*/
            if ( a5 != 0 ) /*0x10312d1cc*/
              return result; /*0x10312d1cc*/
            control = nghttp3_conn_read_qpack_encoder(a1: v10, a2: v8, a3: v7, a4: a6); /*0x10312d1da*/
            break; /*0x10312d1df*/
          case 3LL: /*0x10312d139*/
            result = -605; /*0x10312d1e1*/
            if ( a5 != 0 ) /*0x10312d1eb*/
              return result; /*0x10312d1eb*/
            control = nghttp3_qpack_encoder_read_decoder(a1: v10 + 648, a2: v8, a3: v7); /*0x10312d1fd*/
            break; /*0x10312d1fd*/
          default:
            nghttp3_unreachable_fail(a1: "nghttp3_conn.c", a2: 781, a3: "nghttp3_conn_read_uni"); /*0x10312d3c3*/
        }
        v7 = control; /*0x10312d202*/
LABEL_20:
        if ( v7 < 0 ) /*0x10312d20a*/
          v13 = 0; /*0x10312d20a*/
        v13 += v7; /*0x10312d20e*/
        return v13; /*0x10312d20e*/
      }
    }
  }
  else
  {
    v27 = *v15; /*0x10312d230*/
    nghttp3_varint_read_state_reset(a1: a2 + 512); /*0x10312d237*/
    result = -609; /*0x10312d24a*/
    v10 = a1; /*0x10312d25f*/
    a6 = v29; /*0x10312d263*/
    v18 = a3; /*0x10312d267*/
    switch ( v27 ) /*0x10312d26b*/
    {
      case 0LL: /*0x10312d26b*/
        v19 = *(unsigned __int16 *)(a1 + 2100); /*0x10312d26d*/
        if ( (v19 & 2) == 0 ) /*0x10312d279*/
        {
          v17 = v19 | 2u; /*0x10312d27b*/
          *(_WORD *)(a1 + 2100) = v17; /*0x10312d27e*/
          *(_QWORD *)(a2 + 504) = 0; /*0x10312d287*/
          *(_DWORD *)(a2 + 584) = 0; /*0x10312d292*/
          goto LABEL_33; /*0x10312d29d*/
        }
        break; /*0x10312d29d*/
      case 1LL: /*0x10312d26b*/
        return result;
      case 2LL: /*0x10312d26b*/
        v20 = *(unsigned __int16 *)(a1 + 2100); /*0x10312d29f*/
        if ( (v20 & 4) == 0 ) /*0x10312d2ab*/
        {
          v17 = v20 | 4u; /*0x10312d2b1*/
          *(_WORD *)(a1 + 2100) = v17; /*0x10312d2b4*/
          *(_QWORD *)(a2 + 504) = 2; /*0x10312d2bd*/
          goto LABEL_33; /*0x10312d2c8*/
        }
        break; /*0x10312d2c8*/
      case 3LL: /*0x10312d26b*/
        v21 = *(unsigned __int16 *)(a1 + 2100); /*0x10312d2ca*/
        if ( (v21 & 8) == 0 ) /*0x10312d2d6*/
        {
          v17 = v21 | 8u; /*0x10312d2dc*/
          *(_WORD *)(a1 + 2100) = v17; /*0x10312d2df*/
          *(_QWORD *)(a2 + 504) = 3; /*0x10312d2e8*/
          goto LABEL_33; /*0x10312d2e8*/
        }
        break; /*0x10312d2e8*/
      default:
        *(_QWORD *)(a2 + 504) = -1; /*0x10312d2f5*/
        v10 = a1; /*0x10312d300*/
        a6 = v29; /*0x10312d304*/
        v18 = a3; /*0x10312d308*/
LABEL_33:
        *(_BYTE *)(a2 + 648) |= 1u; /*0x10312d30c*/
        goto LABEL_34; /*0x10312d30c*/
    }
  }
  return result; /*0x10312d21d*/
}

// Address: 0x10312d3ec | Name: _nghttp3_conn_read_bidi
__int64 __fastcall nghttp3_conn_read_bidi(
        __int64 a1,
        __int64 *a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        unsigned int a6,
        __int64 a7)
{
  __int64 result; // rax
  __int64 v9; // rdx
  __int16 v10; // r8
  unsigned int v11; // r13d
  __int64 v12; // r14
  __int64 v13; // rbx
  __int64 v14; // r12
  __int64 varint; // rax
  __int64 v16; // rax
  __int64 v17; // r8
  unsigned __int64 v18; // rcx
  char v19; // al
  __int64 v20; // rax
  __int64 v21; // rcx
  bool v22; // cc
  __int64 v23; // rdx
  __int64 v24; // r14
  bool v25; // zf
  __int64 v26; // rax
  __int64 v27; // rcx
  __int64 v28; // r8
  __int64 v29; // rcx
  int v30; // eax
  __int64 v31; // rdi
  __int64 (__fastcall *v32)(__int64, _QWORD, _QWORD, _QWORD); // rax
  __int64 v33; // rdi
  unsigned int (__fastcall *v34)(__int64, _QWORD, _QWORD, _QWORD, _QWORD); // rax
  __int64 v35; // rdi
  __int64 v36; // rsi
  int v37; // eax
  int v38; // ecx
  __int64 (__fastcall *v39)(__int64, _QWORD, _QWORD, _QWORD); // rax
  int v40; // ecx
  __int64 v41; // [rsp+8h] [rbp-78h]
  __int64 v42; // [rsp+10h] [rbp-70h]
  __int64 v44; // [rsp+28h] [rbp-58h]
  __int64 v48; // [rsp+48h] [rbp-38h]
  __int64 v49; // [rsp+50h] [rbp-30h]

  result = a5; /*0x10312d3fd*/
  v9 = a4 + a5; /*0x10312d403*/
  if ( a4 == 0 ) /*0x10312d40a*/
    v9 = 0; /*0x10312d40a*/
  v10 = *(_WORD *)(a3 + 648); /*0x10312d40e*/
  if ( (v10 & 0x200) != 0 ) /*0x10312d41b*/
  {
    *a2 = result; /*0x10312d8e0*/
    return result; /*0x10312d8e3*/
  }
  if ( (v10 & 0x10) != 0 ) /*0x10312d425*/
  {
    *a2 = 0; /*0x10312d8e8*/
    if ( result == 0 ) /*0x10312d8f2*/
      return 0; /*0x10312d999*/
    LODWORD(result) = nghttp3_stream_buffer_data(a1: a3, a2: a4, a3: v9 - a4); /*0x10312d901*/
    return (int)result; /*0x10312d901*/
  }
  v11 = a6; /*0x10312d42b*/
  if ( v9 == a4 ) /*0x10312d440*/
  {
    v13 = 0; /*0x10312d90d*/
    v14 = a4; /*0x10312d90f*/
    goto LABEL_72; /*0x10312d90f*/
  }
  v42 = v9 - a4; /*0x10312d446*/
  v12 = a3 + 512; /*0x10312d44a*/
  v44 = a3 + 616; /*0x10312d458*/
  v41 = a1 + 1720; /*0x10312d46e*/
  v13 = 0; /*0x10312d472*/
  v14 = a4; /*0x10312d474*/
  v49 = v9; /*0x10312d477*/
  v48 = a3 + 512; /*0x10312d47b*/
  while ( 2 ) /*0x10312d4a2*/
  {
    switch ( *(_DWORD *)(a3 + 584) ) /*0x10312d4a2*/
    {
      case 0: /*0x10312d4a2*/
        varint = nghttp3_read_varint(a1: v12, a2: v14, a3: v9, a4: v11); /*0x10312d4ad*/
        if ( varint < 0 ) /*0x10312d4b5*/
          return -606; /*0x10312d9c1*/
        v14 += varint; /*0x10312d4bb*/
        v13 += varint; /*0x10312d4be*/
        if ( *(_QWORD *)(a3 + 520) != 0 ) /*0x10312d4c9*/
          goto LABEL_72; /*0x10312d4c9*/
        *(_QWORD *)(a3 + 544) = *(_QWORD *)(a3 + 512); /*0x10312d4d6*/
        v12 = a3 + 512; /*0x10312d4dd*/
        nghttp3_varint_read_state_reset(a1: v48); /*0x10312d4e4*/
        *(_DWORD *)(a3 + 584) = 1; /*0x10312d4e9*/
        v9 = v49; /*0x10312d4f4*/
        if ( v14 != v49 ) /*0x10312d4fb*/
        {
LABEL_11:
          v16 = nghttp3_read_varint(a1: v12, a2: v14, a3: v9, a4: v11); /*0x10312d501*/
          if ( v16 < 0 ) /*0x10312d512*/
            return -602; /*0x10312d9a2*/
          v14 += v16; /*0x10312d518*/
          v13 += v16; /*0x10312d51b*/
          if ( *(_QWORD *)(a3 + 520) != 0 ) /*0x10312d526*/
            goto LABEL_72; /*0x10312d526*/
          *(_QWORD *)(a3 + 576) = *(_QWORD *)(a3 + 512); /*0x10312d533*/
          nghttp3_varint_read_state_reset(a1: v48); /*0x10312d53e*/
          v18 = *(_QWORD *)(a3 + 544); /*0x10312d543*/
          result = -601; /*0x10312d54a*/
          switch ( v18 ) /*0x10312d569*/
          {
            case 0uLL: /*0x10312d569*/
              LODWORD(result) = nghttp3_stream_transit_rx_http_state(a1: a3, a2: 0); /*0x10312d570*/
              if ( (_DWORD)result != 0 ) /*0x10312d577*/
                return (int)result; /*0x10312d577*/
              if ( *(_QWORD *)(a3 + 576) != 0 ) /*0x10312d585*/
              {
                *(_DWORD *)(a3 + 584) = 2; /*0x10312d58b*/
                v19 = 0; /*0x10312d596*/
                goto LABEL_41; /*0x10312d598*/
              }
              v35 = a3; /*0x10312d882*/
              v36 = 1; /*0x10312d885*/
              goto LABEL_57; /*0x10312d88a*/
            case 1uLL: /*0x10312d569*/
              LODWORD(result) = nghttp3_stream_transit_rx_http_state(a1: a3, a2: 2); /*0x10312d6f0*/
              if ( (_DWORD)result != 0 ) /*0x10312d6f7*/
                return (int)result; /*0x10312d6f7*/
              if ( *(_QWORD *)(a3 + 576) != 0 ) /*0x10312d705*/
              {
                v9 = v49; /*0x10312d72f*/
                v12 = a3 + 512; /*0x10312d733*/
                switch ( __ROL4__(*(_DWORD *)(a3 + 608) - 2, 30) ) /*0x10312d737*/
                {
                  case 0: /*0x10312d737*/
                  case 2: /*0x10312d737*/
                    v31 = a1; /*0x10312d739*/
                    v32 = *(__int64 (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD))(a1 + 160); /*0x10312d73d*/
                    break; /*0x10312d744*/
                  case 1: /*0x10312d737*/
                  case 3: /*0x10312d737*/
                    v31 = a1; /*0x10312d88c*/
                    v32 = *(__int64 (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD))(a1 + 184); /*0x10312d890*/
                    break; /*0x10312d890*/
                  default:
                    nghttp3_unreachable_fail(a1: "nghttp3_conn.c", a2: 1685, a3: "nghttp3_conn_read_bidi"); /*0x10312da70*/
                }
                if ( v32 != nullptr ) /*0x10312d89a*/
                {
                  v37 = v32(a1: v31, a2: *(_QWORD *)(a3 + 32), a3: *(_QWORD *)(v31 + 2088), a4: *(_QWORD *)(a3 + 456)); /*0x10312d8ae*/
                  v12 = a3 + 512; /*0x10312d8b0*/
                  v9 = v49; /*0x10312d8b4*/
                  if ( v37 != 0 ) /*0x10312d8ba*/
                    return -902; /*0x10312da06*/
                }
                *(_DWORD *)(a3 + 584) = 3; /*0x10312d8c0*/
LABEL_64:
                v19 = 0; /*0x10312d8cb*/
              }
              else
              {
                LODWORD(result) = nghttp3_stream_empty_headers_allowed(a1: a3); /*0x10312d854*/
                if ( (_DWORD)result != 0 ) /*0x10312d85b*/
                  return (int)result; /*0x10312d85b*/
LABEL_56:
                v35 = a3; /*0x10312d861*/
                v36 = 3; /*0x10312d864*/
LABEL_57:
                nghttp3_stream_transit_rx_http_state(a1: v35, a2: v36); /*0x10312d869*/
                v12 = a3 + 512; /*0x10312d86e*/
                nghttp3_stream_read_state_reset(a1: v48); /*0x10312d875*/
                v19 = 0; /*0x10312d87a*/
LABEL_58:
                v9 = v49; /*0x10312d87c*/
              }
              goto LABEL_65; /*0x10312d8cb*/
            case 2uLL: /*0x10312d569*/
            case 3uLL: /*0x10312d569*/
            case 4uLL: /*0x10312d569*/
            case 5uLL: /*0x10312d569*/
            case 6uLL: /*0x10312d569*/
            case 7uLL: /*0x10312d569*/
            case 8uLL: /*0x10312d569*/
            case 9uLL: /*0x10312d569*/
            case 0xDuLL: /*0x10312d569*/
              return result;
            case 0xAuLL: /*0x10312d569*/
            case 0xBuLL: /*0x10312d569*/
            case 0xCuLL: /*0x10312d569*/
              goto LABEL_38;
            default:
              v18 -= 984832LL; /*0x10312d749*/
              if ( v18 < 2 ) /*0x10312d754*/
                return result; /*0x10312d754*/
LABEL_38:
              if ( a7 != -1 && (unsigned int)nghttp3_ratelim_drain(a1: v41, a2: 1, a3: a7, a4: v18, a5: v17) != 0 ) /*0x10312d775*/
                return -610; /*0x10312da0f*/
              *(_DWORD *)(a3 + 584) = 4; /*0x10312d77b*/
              v19 = 1; /*0x10312d786*/
LABEL_41:
              v9 = v49; /*0x10312d788*/
              v12 = a3 + 512; /*0x10312d78c*/
LABEL_65:
              if ( ((unsigned __int8)v19 | (v14 != v9)) == 0 ) /*0x10312d8d5*/
                goto LABEL_66; /*0x10312d8d5*/
              break; /*0x10312d8d5*/
          }
          continue; /*0x10312d8d5*/
        }
LABEL_66:
        v14 = v9; /*0x10312d8db*/
LABEL_72:
        if ( v11 == 0 || (v38 = *(_DWORD *)(a3 + 584)) == 5 ) /*0x10312d925*/
        {
LABEL_87:
          *a2 = v14 - a4; /*0x10312d9e2*/
          return v13; /*0x10312d9ed*/
        }
        result = -602; /*0x10312d92b*/
        if ( v38 == 0 ) /*0x10312d934*/
        {
          result = -606; /*0x10312d93a*/
          if ( *(_QWORD *)(a3 + 520) == 0 ) /*0x10312d949*/
          {
            LODWORD(result) = nghttp3_stream_transit_rx_http_state(a1: a3, a2: 4); /*0x10312d957*/
            if ( (_DWORD)result == 0 ) /*0x10312d95e*/
            {
              v39 = *(__int64 (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD))(a1 + 216); /*0x10312d964*/
              if ( v39 == nullptr ) /*0x10312d96e*/
                goto LABEL_87; /*0x10312d96e*/
              v40 = v39(a1, a2: *(_QWORD *)(a3 + 32), a3: *(_QWORD *)(a1 + 2088), a4: *(_QWORD *)(a3 + 456)); /*0x10312d988*/
              result = -902; /*0x10312d98a*/
              if ( v40 == 0 ) /*0x10312d993*/
                goto LABEL_87; /*0x10312d993*/
              return result; /*0x10312d993*/
            }
            return (int)result; /*0x10312d906*/
          }
        }
        return result; /*0x10312d9f0*/
      case 1: /*0x10312d4a2*/
        goto LABEL_11;
      case 2: /*0x10312d4a2*/
        v24 = v9 - v14; /*0x10312d5f7*/
        if ( *(_QWORD *)(a3 + 576) < v9 - v14 ) /*0x10312d5fd*/
          v24 = *(_QWORD *)(a3 + 576); /*0x10312d5fd*/
        LODWORD(result) = nghttp3_conn_on_data(a1, a2: a3, a3: v14, a4: v24); /*0x10312d60a*/
        if ( (_DWORD)result != 0 ) /*0x10312d611*/
          return (int)result; /*0x10312d611*/
        v14 += v24; /*0x10312d617*/
        v25 = *(_QWORD *)(a3 + 576) == v24; /*0x10312d61a*/
        *(_QWORD *)(a3 + 576) -= v24; /*0x10312d61a*/
        if ( !v25 ) /*0x10312d621*/
        {
          v11 = a6; /*0x10312d9c6*/
          goto LABEL_72; /*0x10312d9ca*/
        }
        nghttp3_stream_transit_rx_http_state(a1: a3, a2: 1); /*0x10312d62f*/
        v12 = a3 + 512; /*0x10312d634*/
        nghttp3_stream_read_state_reset(a1: v48); /*0x10312d63b*/
        v19 = 0; /*0x10312d640*/
        v11 = a6; /*0x10312d645*/
        goto LABEL_58; /*0x10312d649*/
      case 3: /*0x10312d4a2*/
        v26 = *(_QWORD *)(a3 + 576); /*0x10312d64e*/
        v27 = v9 - v14; /*0x10312d658*/
        v28 = 0; /*0x10312d65b*/
        if ( v26 < v9 - v14 ) /*0x10312d661*/
          v27 = *(_QWORD *)(a3 + 576); /*0x10312d661*/
        LOBYTE(v28) = v26 <= v9 - v14; /*0x10312d665*/
        result = nghttp3_conn_on_headers(a1, a2: a3, a3: v14, a4: v27, a5: v28); /*0x10312d673*/
        if ( result < 0 ) /*0x10312d67b*/
          return result; /*0x10312d67b*/
        v14 += result; /*0x10312d681*/
        v13 += result; /*0x10312d684*/
        v29 = *(_QWORD *)(a3 + 576); /*0x10312d687*/
        *(_QWORD *)(a3 + 576) = v29 - result; /*0x10312d694*/
        if ( (*(_BYTE *)(a3 + 648) & 0x10) == 0 ) /*0x10312d6a3*/
        {
          if ( v29 != result ) /*0x10312d6ac*/
            goto LABEL_72; /*0x10312d6ac*/
          v30 = *(_DWORD *)(a3 + 608) - 2; /*0x10312d6b9*/
          switch ( __ROL4__(v30, 30) ) /*0x10312d6d8*/
          {
            case 0: /*0x10312d6d8*/
              LODWORD(result) = nghttp3_http_on_request_headers(a1: v44); /*0x10312d6de*/
              goto LABEL_43; /*0x10312d6e3*/
            case 1: /*0x10312d6d8*/
            case 3: /*0x10312d6d8*/
              goto LABEL_45;
            case 2: /*0x10312d6d8*/
              LODWORD(result) = nghttp3_http_on_response_headers(a1: v44); /*0x10312d799*/
LABEL_43:
              if ( (_DWORD)result == 0 ) /*0x10312d7a0*/
              {
                v30 = *(_DWORD *)(a3 + 608) - 2; /*0x10312d7ad*/
LABEL_45:
                switch ( __ROL4__(v30, 30) ) /*0x10312d7ca*/
                {
                  case 0: /*0x10312d7ca*/
                    if ( *(_DWORD *)(a1 + 2096) == 0 ) /*0x10312d7e4*/
                      goto LABEL_51; /*0x10312d7e4*/
                    if ( *(char *)(a3 + 645) >= 0 ) /*0x10312d7ee*/
                      goto LABEL_51; /*0x10312d7ee*/
                    if ( (*(_BYTE *)(a3 + 649) & 0xC) != 0 ) /*0x10312d7f8*/
                      goto LABEL_51; /*0x10312d7f8*/
                    LODWORD(result) = conn_update_stream_priority(a1, a2: a3, a3: (_QWORD *)(a3 + 632)); /*0x10312d805*/
                    if ( (_DWORD)result == 0 ) /*0x10312d80c*/
                      goto LABEL_51; /*0x10312d80c*/
                    return (int)result; /*0x10312d80c*/
                  case 1: /*0x10312d7ca*/
                  case 3: /*0x10312d7ca*/
                    v33 = a1; /*0x10312d7cc*/
                    v34 = *(unsigned int (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD, _QWORD))(a1 + 200); /*0x10312d7d0*/
                    goto LABEL_52; /*0x10312d7d7*/
                  case 2: /*0x10312d7ca*/
LABEL_51:
                    v33 = a1; /*0x10312d812*/
                    v34 = *(unsigned int (__fastcall **)(__int64, _QWORD, _QWORD, _QWORD, _QWORD))(a1 + 176); /*0x10312d816*/
LABEL_52:
                    if ( v34 != nullptr /*0x10312d84a*/
                      && v34(
                           a1: v33,
                           a2: *(_QWORD *)(a3 + 32),
                           a3: (v11 != 0) & (unsigned __int8)(v14 == v49),
                           a4: *(_QWORD *)(v33 + 2088),
                           a5: *(_QWORD *)(a3 + 456)) != 0 )
                    {
                      return -902; /*0x10312d84a*/
                    }
                    goto LABEL_56; /*0x10312d84a*/
                  default:
                    nghttp3_unreachable_fail(a1: "nghttp3_conn.c", a2: 1805, a3: "nghttp3_conn_read_bidi"); /*0x10312da58*/
                }
              }
              return result; /*0x10312da58*/
            default:
              nghttp3_unreachable_fail(a1: "nghttp3_conn.c", a2: 1776, a3: "nghttp3_conn_read_bidi"); /*0x10312da40*/
          }
        }
        if ( v14 != v49 && nghttp3_stream_get_buffered_datalen(a1: a3) == 0 ) /*0x10312d9e0*/
        {
          LODWORD(result) = nghttp3_stream_buffer_data(a1: a3, a2: v14, a3: v49 - v14); /*0x10312da1e*/
          if ( (_DWORD)result != 0 ) /*0x10312da25*/
            return (int)result; /*0x10312da25*/
        }
        goto LABEL_87; /*0x10312da25*/
      case 4: /*0x10312d4a2*/
        v20 = *(_QWORD *)(a3 + 576); /*0x10312d59d*/
        v21 = v9 - v14; /*0x10312d5a7*/
        v22 = v20 < v9 - v14; /*0x10312d5aa*/
        v23 = v9 - v14; /*0x10312d5ad*/
        if ( v22 ) /*0x10312d5b0*/
          v23 = *(_QWORD *)(a3 + 576); /*0x10312d5b0*/
        v14 += v23; /*0x10312d5b4*/
        v13 += v23; /*0x10312d5b7*/
        *(_QWORD *)(a3 + 576) = v20 - v23; /*0x10312d5c0*/
        if ( v20 > v21 ) /*0x10312d5ca*/
          goto LABEL_72; /*0x10312d5ca*/
        nghttp3_stream_read_state_reset(a1: v48); /*0x10312d5d4*/
        v12 = a3 + 512; /*0x10312d5d9*/
        v9 = v49; /*0x10312d5dd*/
        goto LABEL_64; /*0x10312d5e1*/
      case 5: /*0x10312d4a2*/
        *a2 = v42; /*0x10312d9b2*/
        return v13 + v9 - v14; /*0x10312d9b8*/
      default:
        goto LABEL_64;
    }
  }
}

// Address: 0x10312dc02 | Name: _nghttp3_conn_read_control
__int64 __fastcall nghttp3_conn_read_control(__int64 a1, __int64 a2, __int64 a3, __int64 a4, char *a5)
{
  char *v5; // r9
  __int64 v6; // r15
  __int64 v7; // r14
  __int64 v8; // rcx
  __int64 v9; // r10
  __int64 v10; // r12
  char *v11; // rbx
  __int64 varint; // rax
  char *v13; // rbx
  __int64 v14; // r12
  __int64 v15; // rbx
  char *v16; // r12
  __int64 v17; // rax
  __int64 v18; // r13
  __int64 v19; // rbx
  __int64 v20; // rax
  char *v21; // r9
  __int64 v22; // rdi
  size_t v23; // r13
  char *v24; // rbx
  __int64 v25; // r12
  size_t v26; // rcx
  size_t v27; // rax
  __int64 v28; // r12
  char v29; // al
  __int64 v30; // rbx
  __int64 v31; // rax
  __int64 v32; // rdx
  char *v33; // r12
  __int64 v34; // rax
  __int64 v35; // r8
  __int64 v36; // r13
  unsigned __int64 v37; // rcx
  unsigned __int64 v38; // rax
  char *v39; // rsi
  char *v40; // r12
  __int64 v41; // r12
  __int64 v42; // rax
  __int64 v43; // rdx
  char *v44; // rbx
  __int64 v45; // rax
  __int64 v46; // r12
  char *v47; // rbx
  __int64 v48; // rax
  size_t v49; // r13
  __int64 v50; // rdi
  __int64 v51; // r12
  __int64 v52; // rax
  __int64 v53; // r15
  char *v54; // r13
  __int64 v55; // rax
  __int64 v56; // rbx
  __int64 v57; // rax
  __int64 v58; // r15
  char *v59; // rbx
  __int64 v60; // rax
  char *v61; // rbx
  int v62; // eax
  __int64 v63; // r12
  __int64 v64; // rax
  __int64 v65; // rdx
  char *v66; // rbx
  __int64 v67; // rax
  __int64 v68; // r8
  __int64 v69; // r13
  __int64 v70; // r12
  int v71; // eax
  __int64 v72; // rcx
  __int64 v73; // rax
  unsigned int (__fastcall *v74)(__int64, _QWORD, _QWORD); // rax
  __int64 v75; // rax
  __int64 v76; // rdi
  __int64 v77; // rax
  char *v78; // rbx
  __int64 v79; // r12
  __int64 v80; // rbx
  __int64 v81; // rax
  __int64 v82; // rdx
  char *v83; // r12
  __int64 v84; // rax
  __int64 v85; // r13
  __int64 v86; // rdx
  char *v87; // r13
  __int64 v88; // rax
  __int64 v89; // r12
  unsigned __int64 v90; // rbx
  unsigned __int64 v91; // rdi
  __int64 v92; // r8
  int v93; // edx
  unsigned __int64 v94; // rax
  int v95; // edx
  unsigned __int64 v96; // r13
  __int64 v97; // rdx
  __int64 v98; // rsi
  unsigned __int64 v99; // rdx
  size_t v100; // r12
  unsigned int (__fastcall *v101)(__int64, char *, unsigned __int64, _QWORD); // rax
  char *v102; // rbx
  __int64 v103; // r13
  __int64 v104; // rsi
  size_t v105; // r12
  char *v106; // r12
  char *v107; // r12
  int v108; // eax
  char *v109; // rbx
  __int64 v110; // rcx
  size_t v111; // rax
  char *v112; // rbx
  __int64 v113; // r12
  unsigned int (__fastcall *v114)(__int64, _QWORD, __int64, size_t, char *, char *); // rax
  char *v115; // r12
  int v116; // eax
  char *v117; // r12
  int v118; // eax
  char *v119; // rbx
  unsigned int (__fastcall *v120)(__int64, _QWORD, unsigned __int64, __int64); // rax
  unsigned int (__fastcall *v121)(__int64, _QWORD, __int64, __int64); // rax
  __int64 v123; // r13
  void *v124; // rdi
  __int64 v125; // rax
  __int64 v126; // [rsp+0h] [rbp-90h]
  __int64 v127; // [rsp+8h] [rbp-88h]
  __int64 v128; // [rsp+10h] [rbp-80h]
  __int64 v129; // [rsp+18h] [rbp-78h]
  unsigned __int64 *v130; // [rsp+20h] [rbp-70h]
  __int64 v131; // [rsp+28h] [rbp-68h]
  __int64 v132; // [rsp+30h] [rbp-60h]
  __int64 *v133; // [rsp+38h] [rbp-58h]
  char *v134; // [rsp+40h] [rbp-50h]
  __int64 v135; // [rsp+40h] [rbp-50h]
  __int64 v136; // [rsp+40h] [rbp-50h]
  __int64 v137; // [rsp+48h] [rbp-48h]
  char *v138; // [rsp+50h] [rbp-40h]
  __int64 v139; // [rsp+58h] [rbp-38h]
  _QWORD *v140; // [rsp+60h] [rbp-30h]
  char *v141; // [rsp+60h] [rbp-30h]

  if ( a4 == 0 ) /*0x10312dc16*/
    return 0; /*0x10312e9da*/
  v5 = (char *)a3; /*0x10312dc1c*/
  v6 = a2; /*0x10312dc1f*/
  v7 = a1; /*0x10312dc22*/
  v138 = a5; /*0x10312dc25*/
  v8 = a3 + a4; /*0x10312dc29*/
  v140 = (_QWORD *)(a2 + 512); /*0x10312dc33*/
  v130 = (unsigned __int64 *)(a1 + 2416); /*0x10312dc3e*/
  v131 = a2 + 560; /*0x10312dc49*/
  v133 = (__int64 *)(a2 + 544); /*0x10312dc54*/
  v137 = a1 + 1720; /*0x10312dc5f*/
  v126 = a2 + 528; /*0x10312dc6a*/
  v128 = 0; /*0x10312dc71*/
  v129 = 0; /*0x10312dc79*/
  v9 = 0; /*0x10312dc81*/
  v139 = v8; /*0x10312dc84*/
  while ( 2 ) /*0x10312dca7*/
  {
    switch ( *(_DWORD *)(v6 + 584) ) /*0x10312dca7*/
    {
      case 0: /*0x10312dca7*/
        v10 = v9; /*0x10312dca9*/
        v11 = v5; /*0x10312dcb0*/
        varint = nghttp3_read_varint(a1: v140, a2: v5, a3: v8, a4: 0); /*0x10312dcbb*/
        if ( varint < 0 ) /*0x10312dcc3*/
          return -606; /*0x10312dcc3*/
        v9 = varint + v10; /*0x10312dccc*/
        if ( *(_QWORD *)(v6 + 520) != 0 ) /*0x10312dcd7*/
          return v9; /*0x10312dcd7*/
        v13 = &v11[varint]; /*0x10312dcdd*/
        *(_QWORD *)(v6 + 544) = *(_QWORD *)(v6 + 512); /*0x10312dce7*/
        v14 = varint + v10; /*0x10312dcf2*/
        nghttp3_varint_read_state_reset(a1: v140); /*0x10312dcf5*/
        v9 = v14; /*0x10312dcfa*/
        v5 = v13; /*0x10312dcfd*/
        *(_DWORD *)(v6 + 584) = 1; /*0x10312dd00*/
        v8 = v139; /*0x10312dd0b*/
        if ( v13 == (char *)v139 ) /*0x10312dd12*/
          return v9; /*0x10312dd12*/
LABEL_7:
        v15 = v9; /*0x10312dd18*/
        v16 = v5; /*0x10312dd1f*/
        v17 = nghttp3_read_varint(a1: v140, a2: v5, a3: v8, a4: 0); /*0x10312dd2a*/
        if ( v17 < 0 ) /*0x10312dd32*/
          return -602; /*0x10312dd32*/
        v18 = v17; /*0x10312dd38*/
        v19 = v17 + v15; /*0x10312dd3b*/
        if ( *(_QWORD *)(v6 + 520) != 0 ) /*0x10312dd46*/
          return v19; /*0x10312dd46*/
        *(_QWORD *)(v6 + 576) = *(_QWORD *)(v6 + 512); /*0x10312dd53*/
        nghttp3_varint_read_state_reset(a1: v140); /*0x10312dd5e*/
        a3 = *(unsigned __int16 *)(v7 + 2100); /*0x10312dd63*/
        v20 = *(_QWORD *)(v6 + 544); /*0x10312dd6b*/
        if ( (a3 & 1) != 0 ) /*0x10312dd75*/
        {
          v21 = v16; /*0x10312e5c3*/
          v8 = v139; /*0x10312e5c6*/
          if ( v20 == 4 ) /*0x10312e5ca*/
            return -601; /*0x10312e5ca*/
        }
        else
        {
          v8 = v139; /*0x10312dd7f*/
          if ( v20 != 4 ) /*0x10312dd83*/
            return -603; /*0x10312ead1*/
          v21 = v16; /*0x10312dd89*/
          a3 = (unsigned int)a3 | 1; /*0x10312dd8c*/
          *(_WORD *)(v7 + 2100) = a3; /*0x10312dd8f*/
          v20 = *v133; /*0x10312dd9b*/
        }
        v5 = &v21[v18]; /*0x10312e5d0*/
        switch ( v20 ) /*0x10312e5eb*/
        {
          case 0LL: /*0x10312e5eb*/
          case 1LL: /*0x10312e5eb*/
          case 2LL: /*0x10312e5eb*/
          case 3LL: /*0x10312e5eb*/
          case 5LL: /*0x10312e5eb*/
          case 6LL: /*0x10312e5eb*/
          case 8LL: /*0x10312e5eb*/
          case 9LL: /*0x10312e5eb*/
            return -601;
          case 4LL: /*0x10312e5eb*/
            if ( *(_QWORD *)(v6 + 576) == 0 ) /*0x10312e5f5*/
              goto LABEL_112; /*0x10312e5f5*/
            *(_QWORD *)(v6 + 560) = v126; /*0x10312e5fe*/
            *(_DWORD *)(v6 + 584) = 2; /*0x10312e605*/
            goto LABEL_159; /*0x10312e610*/
          case 7LL: /*0x10312e5eb*/
            v9 = -602; /*0x10312e812*/
            if ( *(_QWORD *)(v6 + 576) == 0 ) /*0x10312e819*/
              return v9; /*0x10312e819*/
            *(_DWORD *)(v6 + 584) = 3; /*0x10312e81f*/
            goto LABEL_159; /*0x10312e82a*/
          case 10LL: /*0x10312e5eb*/
          case 11LL: /*0x10312e5eb*/
            goto LABEL_116;
          case 12LL: /*0x10312e5eb*/
            a3 = (__int64)v138; /*0x10312e82f*/
            if ( v138 != (char *)-1LL ) /*0x10312e837*/
            {
              v115 = v5; /*0x10312e842*/
              v116 = nghttp3_ratelim_drain(a1: v137, a2: 1, a3: v138, a4: v8, a5); /*0x10312e845*/
              v8 = v139; /*0x10312e84a*/
              v5 = v115; /*0x10312e84e*/
              if ( v116 != 0 ) /*0x10312e853*/
                return -610; /*0x10312e853*/
            }
            if ( *(_DWORD *)(v7 + 2096) != 0 || *(_QWORD *)(v7 + 248) == 0 && *(_QWORD *)(v7 + 256) == 0 ) /*0x10312e962*/
              goto LABEL_141; /*0x10312e962*/
            if ( *(_QWORD *)(v6 + 576) != 0 ) /*0x10312e970*/
            {
              *(_QWORD *)(v7 + 2416) = 0; /*0x10312e972*/
              *(_WORD *)(v7 + 2424) = 0; /*0x10312e97d*/
              *(_DWORD *)(v6 + 584) = 10; /*0x10312e987*/
              goto LABEL_159; /*0x10312e987*/
            }
            v106 = v5; /*0x10312e9aa*/
            v121 = *(unsigned int (__fastcall **)(__int64, _QWORD, __int64, __int64))(v7 + 256); /*0x10312e9ad*/
            if ( v121 != nullptr && v121(a1: v7, a2: *(_QWORD *)(v7 + 2088), a3, a4: v8) != 0 ) /*0x10312e9cb*/
              return -902; /*0x10312e9cb*/
LABEL_113:
            nghttp3_stream_read_state_reset(a1: v140); /*0x10312e648*/
            v29 = 0; /*0x10312e651*/
            v9 = v19; /*0x10312e653*/
            v5 = v106; /*0x10312e656*/
            goto LABEL_154; /*0x10312e659*/
          case 13LL: /*0x10312e5eb*/
            if ( *(_DWORD *)(v7 + 2096) == 0 ) /*0x10312e7df*/
              return -601; /*0x10312e7df*/
            v9 = -602; /*0x10312e7ed*/
            if ( *(_QWORD *)(v6 + 576) == 0 ) /*0x10312e7f4*/
              return v9; /*0x10312e7f4*/
            *(_DWORD *)(v6 + 584) = 4; /*0x10312e7fa*/
            goto LABEL_159; /*0x10312e805*/
          default:
            if ( v20 == 984832 ) /*0x10312e664*/
            {
              if ( *(_DWORD *)(v7 + 2096) == 0 ) /*0x10312e881*/
                return -601; /*0x10312ea81*/
              v9 = -602; /*0x10312e88f*/
              if ( *(_QWORD *)(v6 + 576) == 0 ) /*0x10312e896*/
                return v9; /*0x10312e896*/
              a3 = (__int64)v138; /*0x10312e89c*/
              if ( v138 != (char *)-1LL ) /*0x10312e8a4*/
              {
                v117 = v5; /*0x10312e8af*/
                v118 = nghttp3_ratelim_drain(a1: v137, a2: 1, a3: v138, a4: v8, a5); /*0x10312e8b2*/
                v8 = v139; /*0x10312e8b7*/
                v5 = v117; /*0x10312e8bb*/
                if ( v118 != 0 ) /*0x10312e8c0*/
                  return -610; /*0x10312eac5*/
              }
              *(_DWORD *)(v6 + 584) = 8; /*0x10312e8c6*/
LABEL_159:
              v29 = 0; /*0x10312e992*/
            }
            else
            {
              if ( v20 == 984833 ) /*0x10312e670*/
                return -607; /*0x10312eab9*/
LABEL_116:
              a3 = (__int64)v138; /*0x10312e676*/
              if ( v138 != (char *)-1LL ) /*0x10312e67e*/
              {
                v107 = v5; /*0x10312e68d*/
                v108 = nghttp3_ratelim_drain(a1: v137, a2: 1, a3: v138, a4: v8, a5); /*0x10312e690*/
                v8 = v139; /*0x10312e695*/
                v5 = v107; /*0x10312e699*/
                if ( v108 != 0 ) /*0x10312e69e*/
                  return -610; /*0x10312e69e*/
              }
LABEL_141:
              *(_DWORD *)(v6 + 584) = 5; /*0x10312e867*/
              v29 = 1; /*0x10312e872*/
            }
            v9 = v19; /*0x10312e994*/
            break; /*0x10312e994*/
        }
        goto LABEL_161; /*0x10312e994*/
      case 1: /*0x10312dca7*/
        goto LABEL_7;
      case 2: /*0x10312dca7*/
        v51 = v9; /*0x10312e04d*/
        v132 = v6; /*0x10312e050*/
        v127 = v7; /*0x10312e054*/
LABEL_42:
        v52 = *(_QWORD *)(v6 + 576); /*0x10312e05b*/
        if ( v52 == 0 ) /*0x10312e065*/
        {
          v119 = v5; /*0x10312e909*/
          v62 = conn_call_recv_settings(a1: v7, a2, a3, a4: v8, (__int64)a5, a6: (__int64)v5); /*0x10312e90f*/
          if ( v62 != 0 ) /*0x10312e916*/
            return v62; /*0x10312e9fb*/
          nghttp3_stream_read_state_reset(a1: v140); /*0x10312e920*/
          v29 = 0; /*0x10312e925*/
          v9 = v51; /*0x10312e927*/
LABEL_152:
          v5 = v119; /*0x10312e92a*/
LABEL_154:
          v8 = v139; /*0x10312e94a*/
LABEL_161:
          if ( v29 == 0 && v5 == (char *)v8 ) /*0x10312e9a2*/
            return v9; /*0x10312e9a2*/
          continue; /*0x10312e9a2*/
        }
        if ( v5 == (char *)v8 ) /*0x10312e06e*/
          return v51; /*0x10312e06e*/
        v53 = v8 - (_QWORD)v5; /*0x10312e07d*/
        if ( v52 < v8 - (__int64)v5 ) /*0x10312e080*/
          v53 = v52; /*0x10312e080*/
        v54 = v5; /*0x10312e094*/
        v134 = &v5[v53]; /*0x10312e09a*/
        v55 = nghttp3_read_varint(a1: v140, a2: v5, a3: &v5[v53], a4: v8 - (__int64)v5 >= v52); /*0x10312e09e*/
        v9 = -602; /*0x10312e0a3*/
        if ( v55 < 0 ) /*0x10312e0ad*/
          return v9; /*0x10312e0ad*/
        v56 = v55; /*0x10312e0b3*/
        *(_QWORD *)(v132 + 576) -= v55; /*0x10312e0ba*/
        v51 += v55; /*0x10312e0c1*/
        if ( *(_QWORD *)(v132 + 520) != 0 ) /*0x10312e0cc*/
        {
          *(_DWORD *)(v132 + 584) = 6; /*0x10312ea86*/
          return v51; /*0x10312ea91*/
        }
        **(_QWORD **)(v132 + 560) = *(_QWORD *)(v132 + 512); /*0x10312e0e0*/
        nghttp3_varint_read_state_reset(a1: v140); /*0x10312e0e7*/
        v57 = *(_QWORD *)(v132 + 576); /*0x10312e0ec*/
        if ( v57 == 0 ) /*0x10312e0f6*/
          return -602; /*0x10312e9f6*/
        v5 = &v54[v56]; /*0x10312e0ff*/
        v58 = v53 - v56; /*0x10312e102*/
        if ( v58 == 0 ) /*0x10312e105*/
        {
          v6 = v132; /*0x10312e92f*/
          *(_DWORD *)(v132 + 584) = 7; /*0x10312e933*/
          v29 = 0; /*0x10312e93e*/
          v9 = v51; /*0x10312e940*/
          v7 = v127; /*0x10312e943*/
          goto LABEL_154; /*0x10312e943*/
        }
        v59 = &v54[v56]; /*0x10312e11e*/
        v60 = nghttp3_read_varint(a1: v140, a2: v59, a3: v134, a4: v57 <= v58); /*0x10312e121*/
        v6 = v132; /*0x10312e129*/
        v7 = v127; /*0x10312e12d*/
        v9 = -602; /*0x10312e134*/
        if ( v60 < 0 ) /*0x10312e13b*/
          return v9; /*0x10312e13b*/
        *(_QWORD *)(v132 + 576) -= v60; /*0x10312e141*/
        v51 += v60; /*0x10312e148*/
        if ( *(_QWORD *)(v132 + 520) == 0 ) /*0x10312e153*/
        {
          *(_QWORD *)(*(_QWORD *)v131 + 8LL) = *v140; /*0x10312e16d*/
          v61 = &v59[v60]; /*0x10312e171*/
          nghttp3_varint_read_state_reset(a1: v140); /*0x10312e174*/
          v62 = nghttp3_conn_on_settings_entry_received(a1: v127, a2: v133); /*0x10312e180*/
          v8 = v139; /*0x10312e185*/
          v5 = v61; /*0x10312e189*/
          if ( v62 != 0 ) /*0x10312e18e*/
            return v62; /*0x10312e18e*/
          goto LABEL_42; /*0x10312e18e*/
        }
        *(_DWORD *)(v132 + 584) = 7; /*0x10312ea93*/
        return v51; /*0x10312e9e0*/
      case 3: /*0x10312dca7*/
        v63 = v9; /*0x10312e199*/
        v64 = *(_QWORD *)(v6 + 576); /*0x10312e19c*/
        v65 = v8 - (_QWORD)v5; /*0x10312e1ac*/
        if ( v64 < v8 - (__int64)v5 ) /*0x10312e1af*/
          v65 = *(_QWORD *)(v6 + 576); /*0x10312e1af*/
        v66 = v5; /*0x10312e1c2*/
        v67 = nghttp3_read_varint(a1: v140, a2: v5, a3: &v5[v65], a4: v8 - (__int64)v5 >= v64); /*0x10312e1c8*/
        if ( v67 < 0 ) /*0x10312e1d0*/
          return -602; /*0x10312e1d0*/
        v69 = v67; /*0x10312e1d6*/
        *(_QWORD *)(v6 + 576) -= v67; /*0x10312e1d9*/
        v9 = v67 + v63; /*0x10312e1e3*/
        if ( *(_QWORD *)(v6 + 520) != 0 ) /*0x10312e1ee*/
          return v9; /*0x10312e1ee*/
        if ( *(_DWORD *)(v7 + 2096) == 0 ) /*0x10312e1fc*/
        {
          v70 = v67 + v63; /*0x10312e205*/
          v71 = nghttp3_client_stream_bidi(a1: *v140); /*0x10312e208*/
          v9 = v70; /*0x10312e20d*/
          if ( v71 == 0 ) /*0x10312e212*/
            return -607; /*0x10312e212*/
        }
        v72 = *(_QWORD *)(v7 + 2400); /*0x10312e218*/
        v73 = *v140; /*0x10312e223*/
        if ( v72 < *v140 ) /*0x10312e229*/
          return -607; /*0x10312e229*/
        v46 = v9; /*0x10312e22f*/
        LOBYTE(v72) = v138 + 1 == nullptr || v72 != v73; /*0x10312e240*/
        if ( (_BYTE)v72 == 0 ) /*0x10312e242*/
        {
          if ( (unsigned int)nghttp3_ratelim_drain(a1: v137, a2: 1, a3: v138, a4: v72, a5: v68) != 0 ) /*0x10312e258*/
            return -610; /*0x10312e258*/
          v73 = *v140; /*0x10312e262*/
        }
        *(_BYTE *)(v7 + 2100) |= 0x20u; /*0x10312e265*/
        *(_QWORD *)(v7 + 2400) = v73; /*0x10312e26d*/
        nghttp3_varint_read_state_reset(a1: v140); /*0x10312e278*/
        v74 = *(unsigned int (__fastcall **)(__int64, _QWORD, _QWORD))(v7 + 232); /*0x10312e27d*/
        if ( v74 != nullptr && v74(a1: v7, a2: *(_QWORD *)(v7 + 2400), a3: *(_QWORD *)(v7 + 2088)) != 0 ) /*0x10312e29e*/
          return -902; /*0x10312e29e*/
        nghttp3_stream_read_state_reset(a1: v140); /*0x10312e2ab*/
        v5 = &v66[v69]; /*0x10312e2b0*/
        v29 = 0; /*0x10312e2b3*/
        goto LABEL_132; /*0x10312e2b5*/
      case 4: /*0x10312dca7*/
        v30 = v9; /*0x10312de7e*/
        v31 = *(_QWORD *)(v6 + 576); /*0x10312de81*/
        v32 = v8 - (_QWORD)v5; /*0x10312de91*/
        if ( v31 < v8 - (__int64)v5 ) /*0x10312de94*/
          v32 = *(_QWORD *)(v6 + 576); /*0x10312de94*/
        v33 = v5; /*0x10312dea7*/
        v34 = nghttp3_read_varint(a1: v140, a2: v5, a3: &v5[v32], a4: v8 - (__int64)v5 >= v31); /*0x10312dead*/
        if ( v34 < 0 ) /*0x10312deb5*/
          return -602; /*0x10312deb5*/
        v36 = v34; /*0x10312debb*/
        *(_QWORD *)(v6 + 576) -= v34; /*0x10312debe*/
        v19 = v34 + v30; /*0x10312dec5*/
        if ( *(_QWORD *)(v6 + 520) != 0 ) /*0x10312ded0*/
          return v19; /*0x10312ded0*/
        v37 = *(_QWORD *)(v7 + 2208); /*0x10312ded6*/
        v38 = *v140 + 1LL; /*0x10312dee4*/
        v9 = -602; /*0x10312dee7*/
        if ( v37 > v38 ) /*0x10312def1*/
          return v9; /*0x10312def1*/
        v39 = v33; /*0x10312def7*/
        LOBYTE(v37) = v138 + 1 == nullptr || v37 != v38; /*0x10312df08*/
        if ( (_BYTE)v37 == 0 ) /*0x10312df0a*/
        {
          if ( (unsigned int)nghttp3_ratelim_drain(a1: v137, a2: 1, a3: v138, a4: v37, a5: v35) != 0 ) /*0x10312df20*/
            return -610; /*0x10312df20*/
          v38 = *v140 + 1LL; /*0x10312df2d*/
          v39 = v33; /*0x10312df30*/
        }
        *(_QWORD *)(v7 + 2208) = v38; /*0x10312df33*/
        v40 = &v39[v36]; /*0x10312df44*/
        nghttp3_varint_read_state_reset(a1: v140); /*0x10312df47*/
        nghttp3_stream_read_state_reset(a1: v140); /*0x10312df4f*/
        v5 = v40; /*0x10312df54*/
        goto LABEL_85; /*0x10312df57*/
      case 5: /*0x10312dca7*/
        v76 = *(_QWORD *)(v6 + 576); /*0x10312e2c9*/
        v77 = v8 - (_QWORD)v5; /*0x10312e2d9*/
        if ( v76 < v8 - (__int64)v5 ) /*0x10312e2dc*/
          v77 = *(_QWORD *)(v6 + 576); /*0x10312e2dc*/
        v9 += v77; /*0x10312e2e0*/
        *(_QWORD *)(v6 + 576) = v76 - v77; /*0x10312e2e9*/
        if ( v76 > v8 - (__int64)v5 ) /*0x10312e2f3*/
          return v9; /*0x10312e2f3*/
        v78 = &v5[v77]; /*0x10312e300*/
        v79 = v9; /*0x10312e303*/
        nghttp3_stream_read_state_reset(a1: v140); /*0x10312e306*/
        v9 = v79; /*0x10312e30b*/
        v8 = v139; /*0x10312e30e*/
        v5 = v78; /*0x10312e312*/
        v29 = 0; /*0x10312e315*/
        goto LABEL_161; /*0x10312e317*/
      case 6: /*0x10312dca7*/
        v80 = v9; /*0x10312e31c*/
        v81 = *(_QWORD *)(v6 + 576); /*0x10312e31f*/
        v82 = v8 - (_QWORD)v5; /*0x10312e32f*/
        if ( v81 < v8 - (__int64)v5 ) /*0x10312e332*/
          v82 = *(_QWORD *)(v6 + 576); /*0x10312e332*/
        v83 = v5; /*0x10312e345*/
        v84 = nghttp3_read_varint(a1: v140, a2: v5, a3: &v5[v82], a4: v8 - (__int64)v5 >= v81); /*0x10312e34b*/
        if ( v84 < 0 ) /*0x10312e353*/
          return -602; /*0x10312e353*/
        v85 = v84; /*0x10312e359*/
        *(_QWORD *)(v6 + 576) -= v84; /*0x10312e35c*/
        v19 = v84 + v80; /*0x10312e363*/
        if ( *(_QWORD *)(v6 + 520) != 0 ) /*0x10312e36e*/
          return v19; /*0x10312e36e*/
        **(_QWORD **)(v6 + 560) = *(_QWORD *)(v6 + 512); /*0x10312e382*/
        nghttp3_varint_read_state_reset(a1: v140); /*0x10312e389*/
        v75 = *(_QWORD *)(v6 + 576); /*0x10312e38e*/
        v9 = -602; /*0x10312e395*/
        v8 = v139; /*0x10312e39f*/
        if ( v75 == 0 ) /*0x10312e3a3*/
          return v9; /*0x10312e3a3*/
        v5 = &v83[v85]; /*0x10312e3ac*/
        *(_DWORD *)(v6 + 584) = 7; /*0x10312e3af*/
        v9 = v19; /*0x10312e3ba*/
        if ( &v83[v85] == (char *)v139 ) /*0x10312e3c0*/
          return v9; /*0x10312e3c0*/
LABEL_78:
        v86 = v8 - (_QWORD)v5; /*0x10312e3c6*/
        if ( v75 < v8 - (__int64)v5 ) /*0x10312e3d2*/
          v86 = v75; /*0x10312e3d2*/
        v87 = v5; /*0x10312e3e5*/
        v88 = nghttp3_read_varint(a1: v140, a2: v5, a3: &v5[v86], a4: v8 - (__int64)v5 >= v75); /*0x10312e3eb*/
        if ( v88 < 0 ) /*0x10312e3f3*/
          return -602; /*0x10312e3f3*/
        v89 = v88; /*0x10312e3f9*/
        *(_QWORD *)(v6 + 576) -= v88; /*0x10312e3fc*/
        v19 += v88; /*0x10312e403*/
        if ( *(_QWORD *)(v6 + 520) != 0 ) /*0x10312e40e*/
          return v19; /*0x10312e40e*/
        *(_QWORD *)(*(_QWORD *)v131 + 8LL) = *v140; /*0x10312e422*/
        nghttp3_varint_read_state_reset(a1: v140); /*0x10312e426*/
        v62 = nghttp3_conn_on_settings_entry_received(a1: v7, a2: v133); /*0x10312e432*/
        if ( v62 != 0 ) /*0x10312e439*/
          return v62; /*0x10312e439*/
        v5 = &v87[v89]; /*0x10312e442*/
        if ( *(_QWORD *)(v6 + 576) != 0 ) /*0x10312e44d*/
        {
          *(_DWORD *)(v6 + 584) = 2; /*0x10312e453*/
LABEL_85:
          v29 = 0; /*0x10312e45e*/
          v9 = v19; /*0x10312e460*/
          goto LABEL_154; /*0x10312e463*/
        }
LABEL_112:
        v106 = v5; /*0x10312e635*/
        v62 = conn_call_recv_settings(a1: v7, a2, a3, a4: v8, (__int64)a5, a6: (__int64)v5); /*0x10312e63b*/
        if ( v62 != 0 ) /*0x10312e642*/
          return v62; /*0x10312e642*/
        goto LABEL_113; /*0x10312e642*/
      case 7: /*0x10312dca7*/
        v75 = *(_QWORD *)(v6 + 576); /*0x10312e2ba*/
        v19 = v9; /*0x10312e2c1*/
        goto LABEL_78; /*0x10312e2c4*/
      case 8: /*0x10312dca7*/
        v41 = v9; /*0x10312df5c*/
        v42 = *(_QWORD *)(v6 + 576); /*0x10312df5f*/
        v43 = v8 - (_QWORD)v5; /*0x10312df6f*/
        if ( v42 < v8 - (__int64)v5 ) /*0x10312df72*/
          v43 = *(_QWORD *)(v6 + 576); /*0x10312df72*/
        v44 = v5; /*0x10312df85*/
        v45 = nghttp3_read_varint(a1: v140, a2: v5, a3: &v5[v43], a4: v8 - (__int64)v5 >= v42); /*0x10312df8b*/
        if ( v45 < 0 ) /*0x10312df93*/
          return -602; /*0x10312df93*/
        *(_QWORD *)(v6 + 576) -= v45; /*0x10312df99*/
        v9 = v45 + v41; /*0x10312dfa3*/
        if ( *(_QWORD *)(v6 + 520) != 0 ) /*0x10312dfae*/
          return v9; /*0x10312dfae*/
        v46 = v45 + v41; /*0x10312dfb4*/
        v47 = &v44[v45]; /*0x10312dfb7*/
        *(_QWORD *)(v6 + 552) = *(_QWORD *)(v6 + 512); /*0x10312dfc1*/
        nghttp3_varint_read_state_reset(a1: v140); /*0x10312dfcc*/
        if ( *(_QWORD *)(v6 + 576) != 0 ) /*0x10312dfd9*/
        {
          *(_QWORD *)(v7 + 2424) = 0; /*0x10312dfdf*/
          *(_DWORD *)(v6 + 584) = 9; /*0x10312dfea*/
          v8 = v139; /*0x10312dff5*/
          v5 = v47; /*0x10312dffc*/
          v9 = v46; /*0x10312dfff*/
          if ( v47 == (char *)v139 ) /*0x10312e002*/
            return v9; /*0x10312e002*/
LABEL_35:
          v48 = *(_QWORD *)(v6 + 576); /*0x10312e008*/
          a3 = v8 - (_QWORD)v5; /*0x10312e012*/
          v49 = v8 - (_QWORD)v5; /*0x10312e018*/
          if ( v48 < v8 - (__int64)v5 ) /*0x10312e01b*/
            v49 = *(_QWORD *)(v6 + 576); /*0x10312e01b*/
          v50 = *(_QWORD *)(v7 + 2424); /*0x10312e01f*/
          if ( v50 != 0 || v48 > a3 ) /*0x10312e032*/
          {
            if ( v50 + v49 >= 9 ) /*0x10312e61d*/
            {
LABEL_111:
              *(_DWORD *)(v6 + 584) = 5; /*0x10312e623*/
              v29 = 1; /*0x10312e62e*/
              goto LABEL_161; /*0x10312e630*/
            }
            v109 = v5; /*0x10312e6b6*/
            v135 = v9; /*0x10312e6b9*/
            memcpy(__dst: (char *)v130 + v50, __src: v5, __n: v49); /*0x10312e6bd*/
            v9 = v135; /*0x10312e6c2*/
            v5 = v109; /*0x10312e6c6*/
            v110 = v49 + *(_QWORD *)(v7 + 2424); /*0x10312e6d0*/
            *(_QWORD *)(v7 + 2424) = v110; /*0x10312e6d3*/
            v48 = *(_QWORD *)(v6 + 576); /*0x10312e6da*/
            a2 = v129; /*0x10312e6e4*/
            if ( v48 == v49 ) /*0x10312e6e8*/
              a2 = (__int64)v130; /*0x10312e6e8*/
            a3 = v128; /*0x10312e6ec*/
            if ( v48 == v49 ) /*0x10312e6f0*/
              a3 = v110; /*0x10312e6f0*/
          }
          else
          {
            a2 = (__int64)v5; /*0x10312e038*/
            a3 = v49; /*0x10312e03b*/
            if ( v49 >= 9 ) /*0x10312e042*/
              goto LABEL_111; /*0x10312e042*/
          }
          v9 += v49; /*0x10312e6f4*/
          v111 = v48 - v49; /*0x10312e6f7*/
          *(_QWORD *)(v6 + 576) = v111; /*0x10312e6fa*/
          if ( v111 != 0 ) /*0x10312e701*/
            return v9; /*0x10312e701*/
          v136 = v9; /*0x10312e707*/
          v112 = v5; /*0x10312e70b*/
          *(_DWORD *)(v6 + 560) = 3; /*0x10312e70e*/
          *(_BYTE *)(v6 + 564) = 0; /*0x10312e719*/
          v113 = a2; /*0x10312e725*/
          v128 = a3; /*0x10312e728*/
          if ( (unsigned int)nghttp3_http_parse_priority(a1: v131) != 0 ) /*0x10312e733*/
            return -606; /*0x10312eaad*/
          v62 = nghttp3_conn_on_priority_update(a1: v7, a2: v133); /*0x10312e740*/
          if ( v62 != 0 ) /*0x10312e747*/
            return v62; /*0x10312e747*/
          nghttp3_stream_read_state_reset(a1: v140); /*0x10312e754*/
          v5 = &v112[v49]; /*0x10312e759*/
          v29 = 0; /*0x10312e75c*/
          v129 = v113; /*0x10312e75e*/
          v8 = v139; /*0x10312e762*/
          v9 = v136; /*0x10312e766*/
        }
        else
        {
          *(_DWORD *)(v6 + 560) = 3; /*0x10312e796*/
          *(_BYTE *)(v6 + 564) = 0; /*0x10312e7a1*/
          v62 = nghttp3_conn_on_priority_update(a1: v7, a2: v133); /*0x10312e7b0*/
          if ( v62 != 0 ) /*0x10312e7b7*/
            return v62; /*0x10312e7b7*/
LABEL_131:
          nghttp3_stream_read_state_reset(a1: v140); /*0x10312e7bd*/
          v29 = 0; /*0x10312e7c6*/
          v5 = v47; /*0x10312e7c8*/
LABEL_132:
          v8 = v139; /*0x10312e7cb*/
          v9 = v46; /*0x10312e7cf*/
        }
        goto LABEL_161; /*0x10312e76a*/
      case 9: /*0x10312dca7*/
        goto LABEL_35;
      case 0xA: /*0x10312dca7*/
        v90 = v8 - (_QWORD)v5; /*0x10312e472*/
        if ( *(_QWORD *)(v6 + 576) < v8 - (__int64)v5 ) /*0x10312e478*/
          v90 = *(_QWORD *)(v6 + 576); /*0x10312e478*/
        v91 = *v130; /*0x10312e480*/
        v92 = v9; /*0x10312e483*/
        while ( 2 ) /*0x10312e48f*/
        {
          if ( v91 <= 1 && v90 != 0 ) /*0x10312e48f*/
          {
            v93 = *(unsigned __int16 *)(v7 + 2424); /*0x10312e491*/
            v94 = 0; /*0x10312e499*/
            do /*0x10312e4d2*/
            {
              v95 = v93 << 8; /*0x10312e49b*/
              *(_WORD *)(v7 + 2424) = v95; /*0x10312e49e*/
              v93 = v95 | (unsigned __int8)v5[v94]; /*0x10312e4ad*/
              *(_WORD *)(v7 + 2424) = v93; /*0x10312e4af*/
              *(_QWORD *)(v7 + 2416) = v91 + 1; /*0x10312e4bb*/
              ++v94; /*0x10312e4c2*/
              if ( v91 != 0 ) /*0x10312e4c8*/
                break; /*0x10312e4c8*/
              v91 = 1; /*0x10312e4ca*/
            }
            while ( v94 < v90 ); /*0x10312e4d2*/
            v5 += v94; /*0x10312e4d4*/
          }
          else
          {
            v94 = 0; /*0x10312e4d9*/
          }
          v96 = v94 + v92; /*0x10312e4db*/
          v97 = *(_QWORD *)(v6 + 576); /*0x10312e4df*/
          v98 = v97 - v94; /*0x10312e4e9*/
          *(_QWORD *)(v6 + 576) = v97 - v94; /*0x10312e4ec*/
          if ( *v130 <= 1 ) /*0x10312e4fb*/
          {
            if ( v97 == v94 ) /*0x10312ea07*/
              return -602; /*0x10312ea07*/
            return v96; /*0x10312ea0e*/
          }
          v99 = *(unsigned __int16 *)(v7 + 2424); /*0x10312e501*/
          v9 = -602; /*0x10312e509*/
          if ( *(_WORD *)(v7 + 2424) == 0 || v98 < (__int64)v99 ) /*0x10312e51c*/
            return v9; /*0x10312e51c*/
          v100 = v90 - v94; /*0x10312e525*/
          if ( v90 - v94 < v99 ) /*0x10312e52b*/
          {
            v123 = v92; /*0x10312ea10*/
            v124 = *(void **)(v7 + 2432); /*0x10312ea13*/
            if ( v124 == nullptr ) /*0x10312ea1d*/
            {
              v141 = v5; /*0x10312ea2b*/
              v125 = nghttp3_mem_malloc(a1: *(_QWORD *)(v7 + 2080), a2: 0xFFFF, a3: v99, a4: v8, a5: v92); /*0x10312ea2f*/
              v5 = v141; /*0x10312ea34*/
              v124 = (void *)v125; /*0x10312ea38*/
              *(_QWORD *)(v7 + 2432) = v125; /*0x10312ea3b*/
              if ( v125 == 0 ) /*0x10312ea45*/
                return -901; /*0x10312ead6*/
            }
            memcpy(__dst: v124, __src: v5, __n: v100); /*0x10312ea51*/
            *(_QWORD *)(v6 + 576) -= v100; /*0x10312ea56*/
            v19 = v123 + v90; /*0x10312ea5d*/
            *(_QWORD *)(v7 + 2440) = v100; /*0x10312ea60*/
            *(_DWORD *)(v6 + 584) = 11; /*0x10312ea67*/
            return v19; /*0x10312ea75*/
          }
          v101 = *(unsigned int (__fastcall **)(__int64, char *, unsigned __int64, _QWORD))(v7 + 248); /*0x10312e531*/
          if ( v101 != nullptr ) /*0x10312e53b*/
          {
            v102 = v5; /*0x10312e547*/
            if ( v101(a1: v7, a2: v5, a3: v99, a4: *(_QWORD *)(v7 + 2088)) != 0 ) /*0x10312e551*/
              return -902; /*0x10312e551*/
            v99 = *(unsigned __int16 *)(v7 + 2424); /*0x10312e557*/
            v98 = *(_QWORD *)(v6 + 576); /*0x10312e55f*/
            v5 = v102; /*0x10312e566*/
            v8 = v139; /*0x10312e569*/
          }
          v5 += v99; /*0x10312e56d*/
          v103 = v99 + v96; /*0x10312e570*/
          v104 = v98 - v99; /*0x10312e573*/
          *(_QWORD *)(v6 + 576) = v104; /*0x10312e576*/
          if ( v104 != 0 ) /*0x10312e57d*/
          {
            v105 = v100 - *(unsigned __int16 *)(v7 + 2424); /*0x10312e58b*/
            *(_QWORD *)(v7 + 2416) = 0; /*0x10312e58e*/
            *(_WORD *)(v7 + 2424) = 0; /*0x10312e599*/
            v91 = 0; /*0x10312e5a3*/
            v92 = v103; /*0x10312e5a8*/
            v90 = v105; /*0x10312e5ab*/
            v9 = v103; /*0x10312e5ae*/
            if ( v5 == (char *)v8 ) /*0x10312e5b4*/
              return v9; /*0x10312e5b4*/
            continue; /*0x10312e5b4*/
          }
          break;
        }
        v119 = v5; /*0x10312e8d6*/
        v120 = *(unsigned int (__fastcall **)(__int64, _QWORD, unsigned __int64, __int64))(v7 + 256); /*0x10312e8d9*/
        if ( v120 != nullptr && v120(a1: v7, a2: *(_QWORD *)(v7 + 2088), a3: v99, a4: v8) != 0 ) /*0x10312e8f3*/
          return -902; /*0x10312e9d8*/
        nghttp3_stream_read_state_reset(a1: v140); /*0x10312e8fd*/
        v29 = 0; /*0x10312e902*/
        v9 = v103; /*0x10312e904*/
        goto LABEL_152; /*0x10312e907*/
      case 0xB: /*0x10312dca7*/
        v22 = *(_QWORD *)(v7 + 2440); /*0x10312ddab*/
        v23 = v8 - (_QWORD)v5; /*0x10312ddb8*/
        if ( (unsigned __int64)*(unsigned __int16 *)(v7 + 2424) - v22 < v8 - (__int64)v5 ) /*0x10312ddbe*/
          v23 = *(unsigned __int16 *)(v7 + 2424) - v22; /*0x10312ddbe*/
        v24 = v5; /*0x10312ddc9*/
        v25 = v9; /*0x10312ddd2*/
        memcpy(__dst: (void *)(*(_QWORD *)(v7 + 2432) + v22), __src: v5, __n: v23); /*0x10312ddd5*/
        v26 = v23 + *(_QWORD *)(v7 + 2440); /*0x10312dde4*/
        *(_QWORD *)(v7 + 2440) = v26; /*0x10312dde7*/
        v9 = v23 + v25; /*0x10312ddee*/
        v27 = *(_QWORD *)(v6 + 576) - v23; /*0x10312ddf8*/
        *(_QWORD *)(v6 + 576) = v27; /*0x10312ddfb*/
        a3 = *(unsigned __int16 *)(v7 + 2424); /*0x10312de02*/
        if ( v26 < a3 ) /*0x10312de0d*/
          return v9; /*0x10312de0d*/
        a5 = *(char **)(v7 + 248); /*0x10312de13*/
        if ( a5 != nullptr ) /*0x10312de1d*/
        {
          v28 = v23 + v25; /*0x10312de1f*/
          if ( ((unsigned int (__fastcall *)(__int64, _QWORD, __int64, _QWORD))a5)( /*0x10312de38*/
                 a1: v7,
                 a2: *(_QWORD *)(v7 + 2432),
                 a3,
                 a4: *(_QWORD *)(v7 + 2088)) != 0 )
            return -902; /*0x10312de38*/
          v27 = *(_QWORD *)(v6 + 576); /*0x10312de3e*/
          v9 = v28; /*0x10312de45*/
        }
        v5 = &v24[v23]; /*0x10312de48*/
        if ( v27 != 0 ) /*0x10312de51*/
        {
          *(_QWORD *)(v7 + 2416) = 0; /*0x10312de57*/
          *(_WORD *)(v7 + 2424) = 0; /*0x10312de62*/
          *(_DWORD *)(v6 + 584) = 10; /*0x10312de6c*/
          v29 = 0; /*0x10312de77*/
          goto LABEL_154; /*0x10312de79*/
        }
        v46 = v9; /*0x10312e76f*/
        v47 = &v24[v23]; /*0x10312e772*/
        v114 = *(unsigned int (__fastcall **)(__int64, _QWORD, __int64, size_t, char *, char *))(v7 + 256); /*0x10312e775*/
        if ( v114 != nullptr && v114(a1: v7, a2: *(_QWORD *)(v7 + 2088), a3, a4: v26, a5, a6: v5) != 0 ) /*0x10312e78f*/
          return -902; /*0x10312e78f*/
        goto LABEL_131; /*0x10312e78f*/
      default:
        nghttp3_unreachable_fail(a1: "nghttp3_conn.c", a2: 1403, a3: "nghttp3_conn_read_control"); /*0x10312eaf5*/
    }
  }
}

// Address: 0x10312eb64 | Name: _nghttp3_conn_read_qpack_encoder
__int64 __fastcall nghttp3_conn_read_qpack_encoder(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 result; // rax
  __int64 v6; // r14
  __int64 v7; // r12
  unsigned __int64 ricnt; // rbx
  __int64 v9; // rbx
  unsigned int v10; // r13d
  _QWORD *v11; // r14
  __int64 v12; // r15
  __int64 v13; // rax
  __int64 v14; // rbx
  unsigned int (__fastcall *v15)(__int64, _QWORD, __int64, _QWORD, _QWORD); // r9
  __int64 v16; // [rsp+8h] [rbp-68h] BYREF
  __int64 v17; // [rsp+10h] [rbp-60h]
  __int64 v18; // [rsp+18h] [rbp-58h]
  __int64 v19; // [rsp+20h] [rbp-50h]
  __int64 v20; // [rsp+28h] [rbp-48h]
  __int64 *v21; // [rsp+30h] [rbp-40h]
  __int64 v22; // [rsp+38h] [rbp-38h]
  __int64 v23; // [rsp+40h] [rbp-30h]

  v17 = a4; /*0x10312eb75*/
  v19 = a1 + 336; /*0x10312eb83*/
  result = nghttp3_qpack_decoder_read_encoder(); /*0x10312eb87*/
  if ( result >= 0 ) /*0x10312eb8f*/
  {
    v23 = result; /*0x10312eb95*/
    v6 = a1 + 1680; /*0x10312eb99*/
    v18 = a1; /*0x10312eba0*/
    v20 = a1 + 1680; /*0x10312eba4*/
    while ( 2 ) /*0x10312ebb2*/
    {
      if ( (unsigned int)nghttp3_pq_empty(a1: v6) != 0 ) /*0x10312ebb2*/
        return v23; /*0x10312ebb2*/
      v7 = nghttp3_pq_top(a1: v6); /*0x10312ebc0*/
      ricnt = nghttp3_qpack_stream_context_get_ricnt(a1: v7 + 208); /*0x10312ebcf*/
      if ( ricnt > nghttp3_qpack_decoder_get_icnt(a1: v19) ) /*0x10312ebde*/
      {
        return v23; /*0x10312ed0a*/
      }
      else
      {
        v21 = (__int64 *)(v7 - 56); /*0x10312ebe9*/
        nghttp3_pq_pop(a1: v6); /*0x10312ebf0*/
        *(_QWORD *)v7 = -1; /*0x10312ebf5*/
        *(_BYTE *)(v7 + 592) &= ~0x10u; /*0x10312ebfd*/
        v22 = v7 + 160; /*0x10312ec0f*/
        do /*0x10312ece9*/
        {
          v9 = *(_QWORD *)(v7 + 200); /*0x10312ec13*/
          if ( v9 == 0 ) /*0x10312ec1e*/
            break; /*0x10312ec1e*/
          v10 = 0; /*0x10312ec24*/
          v11 = (_QWORD *)nghttp3_ringbuf_get(a1: v22, a2: 0); /*0x10312ec32*/
          v12 = v11[2]; /*0x10312ec35*/
          v13 = nghttp3_buf_len(a1: (__int64)v11); /*0x10312ec3c*/
          if ( v9 == 1 ) /*0x10312ec45*/
            v10 = (*(_DWORD *)(v7 + 592) & 0x20) != 0; /*0x10312ec53*/
          v14 = v18; /*0x10312ec5f*/
          result = nghttp3_conn_read_bidi(a1: v18, a2: &v16, a3: (__int64)v21, a4: v12, a5: v13, a6: v10, a7: v17); /*0x10312ec77*/
          if ( result < 0 ) /*0x10312ec7f*/
            goto LABEL_17; /*0x10312ec7f*/
          v11[2] += v16; /*0x10312ec85*/
          if ( result != 0 ) /*0x10312ec8c*/
          {
            v15 = *(unsigned int (__fastcall **)(__int64, _QWORD, __int64, _QWORD, _QWORD))(v14 + 152); /*0x10312ec8e*/
            if ( v15 != nullptr /*0x10312ecb9*/
              && v15(
                   a1: v14,
                   a2: *(_QWORD *)(v7 - 24),
                   a3: result,
                   a4: *(_QWORD *)(v14 + 2088),
                   a5: *(_QWORD *)(v7 + 400)) != 0 )
            {
              return -902; /*0x10312ed08*/
            }
          }
          if ( nghttp3_buf_len(a1: (__int64)v11) == 0 ) /*0x10312ecc6*/
          {
            nghttp3_buf_free(a1: v11, a2: *v21); /*0x10312ecd2*/
            nghttp3_ringbuf_pop_front(a1: v22); /*0x10312ecdb*/
          }
        }
        while ( (*(_BYTE *)(v7 + 592) & 0x10) == 0 ); /*0x10312ece9*/
        LODWORD(result) = 0; /*0x10312ecef*/
LABEL_17:
        v6 = v20; /*0x10312ecf1*/
        if ( (_DWORD)result == 0 ) /*0x10312ecf7*/
          continue; /*0x10312ecf7*/
        return (int)result; /*0x10312ecfd*/
      }
    }
  }
  return result; /*0x10312ed0e*/
}

// Address: 0x10312ed1d | Name: _nghttp3_conn_read_qpack_decoder
__int64 __fastcall nghttp3_conn_read_qpack_decoder(__int64 a1, __int64 a2, __int64 a3)
{
  return nghttp3_qpack_encoder_read_decoder(a1: a1 + 648, a2, a3); /*0x10312ed28*/
}

// Address: 0x10312edb8 | Name: _nghttp3_conn_on_settings_entry_received
__int64 __fastcall nghttp3_conn_on_settings_entry_received(__int64 a1, __int64 a2)
{
  _QWORD *v2; // rcx
  __int64 result; // rax
  __int64 v4; // rsi
  unsigned __int64 v5; // rcx
  __int64 v6; // rcx
  unsigned __int64 v7; // rax
  __int64 v8; // rdi
  __int64 v9; // rsi

  v2 = *(_QWORD **)(a2 + 16); /*0x10312edbc*/
  result = 4294966688LL; /*0x10312edc3*/
  switch ( *v2 ) /*0x10312ede0*/
  {
    case 1LL: /*0x10312ede0*/
      if ( *(_QWORD *)(a1 + 2376) == 0 ) /*0x10312edea*/
      {
        v4 = v2[1]; /*0x10312edec*/
        if ( v4 != 0 ) /*0x10312edf3*/
        {
          *(_QWORD *)(a1 + 2376) = v4; /*0x10312edf5*/
          nghttp3_qpack_encoder_set_max_dtable_capacity(a1: a1 + 648); /*0x10312ee03*/
        }
        return 0; /*0x10312ee08*/
      }
      return result; /*0x10312edea*/
    case 2LL: /*0x10312ede0*/
    case 3LL: /*0x10312ede0*/
    case 4LL: /*0x10312ede0*/
    case 5LL: /*0x10312ede0*/
      return result;
    case 6LL: /*0x10312ede0*/
      *(_QWORD *)(a1 + 2368) = v2[1]; /*0x10312ee4f*/
      return 0; /*0x10312ee4f*/
    case 7LL: /*0x10312ede0*/
      if ( *(_QWORD *)(a1 + 2384) != 0 ) /*0x10312ee62*/
        return result; /*0x10312ee62*/
      v7 = v2[1]; /*0x10312ee64*/
      if ( v7 != 0 ) /*0x10312ee6b*/
      {
        *(_QWORD *)(a1 + 2384) = v7; /*0x10312ee6d*/
        v8 = a1 + 648; /*0x10312ee74*/
        v9 = 100; /*0x10312ee7f*/
        if ( v7 < 0x64 ) /*0x10312ee84*/
          v9 = v7; /*0x10312ee84*/
        nghttp3_qpack_encoder_set_max_blocked_streams(a1: v8, a2: v9); /*0x10312ee88*/
      }
      return 0; /*0x10312ee8d*/
    case 8LL: /*0x10312ede0*/
      if ( *(_DWORD *)(a1 + 2096) != 0 ) /*0x10312ee29*/
        return 0; /*0x10312ee29*/
      v6 = v2[1]; /*0x10312ee2b*/
      if ( v6 != 1 && (v6 != 0 || *(_BYTE *)(a1 + 2392) != 0) ) /*0x10312ee41*/
        return result; /*0x10312ee41*/
      *(_BYTE *)(a1 + 2392) = v6; /*0x10312ee43*/
      break; /*0x10312ee49*/
    default:
      if ( *v2 != 51 ) /*0x10312ee0e*/
        return 0; /*0x10312ee0e*/
      v5 = v2[1]; /*0x10312ee10*/
      if ( v5 > 1 ) /*0x10312ee18*/
        return result; /*0x10312ee18*/
      *(_BYTE *)(a1 + 2393) = v5; /*0x10312ee1a*/
      break; /*0x10312ee20*/
  }
  return 0; /*0x10312ee58*/
}

// Address: 0x10312eeb0 | Name: _nghttp3_conn_on_priority_update
__int64 __fastcall nghttp3_conn_on_priority_update(__int64 a1, __int64 a2)
{
  __int64 v4; // r15
  unsigned int stream; // r12d
  __int64 v6; // rax
  int v7; // ecx
  unsigned int v9; // eax
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12[5]; // [rsp+8h] [rbp-28h] BYREF

  v4 = *(_QWORD *)(a2 + 8); /*0x10312eec5*/
  stream = -607; /*0x10312eed1*/
  if ( (unsigned int)nghttp3_client_stream_bidi(a1: v4) == 0 /*0x10312eeee*/
    || (unsigned __int64)nghttp3_ord_stream_id(a1: v4) > *(_QWORD *)(a1 + 2352) )
  {
    return stream; /*0x10312eeee*/
  }
  v6 = nghttp3_map_find(a1: a1 + 280); /*0x10312eefe*/
  v12[0] = v6; /*0x10312ef03*/
  if ( v6 != 0 ) /*0x10312ef0a*/
  {
    v7 = *(_DWORD *)(v6 + 648); /*0x10312ef0c*/
    if ( (v7 & 0x400) == 0 ) /*0x10312ef16*/
    {
      *(_WORD *)(v6 + 648) = v7 | 0x800; /*0x10312ef22*/
      return conn_update_stream_priority(a1, a2: v6, a3: (_QWORD *)(a2 + 16)); /*0x10312ef42*/
    }
  }
  else if ( (*(_BYTE *)(a1 + 2100) & 0x40) == 0 || *(_QWORD *)(a1 + 2536) > v4 ) /*0x10312ef58*/
  {
    v9 = conn_bidi_idtr_open(a1); /*0x10312ef60*/
    if ( v9 != 0 ) /*0x10312ef67*/
    {
      stream = v9; /*0x10312ef69*/
      if ( (unsigned int)nghttp3_err_is_fatal(a1: v9) == 0 ) /*0x10312ef75*/
        return 0; /*0x10312ef75*/
      return stream; /*0x10312ef75*/
    }
    v10 = *(_QWORD *)(a1 + 2408); /*0x10312ef7b*/
    if ( v10 <= v4 ) /*0x10312ef85*/
      v10 = v4; /*0x10312ef85*/
    *(_QWORD *)(a1 + 2408) = v10; /*0x10312ef89*/
    stream = nghttp3_conn_create_stream(a1, a2: v12, a3: v4); /*0x10312ef9f*/
    if ( stream != 0 ) /*0x10312efa4*/
      return stream; /*0x10312efa4*/
    v11 = v12[0]; /*0x10312efa6*/
    *(_QWORD *)(v12[0] + 48) = *(_QWORD *)(a2 + 16); /*0x10312efae*/
    *(_BYTE *)(v11 + 649) |= 8u; /*0x10312efb2*/
    *(_DWORD *)(v11 + 608) = 1; /*0x10312efb9*/
  }
  return 0; /*0x10312ef36*/
}

// Address: 0x10312efd6 | Name: _nghttp3_conn_qpack_blocked_streams_pop
__int64 __fastcall nghttp3_conn_qpack_blocked_streams_pop(__int64 a1)
{
  return nghttp3_pq_pop(a1: a1 + 1680); /*0x10312efe1*/
}

// Address: 0x10312efe7 | Name: _nghttp3_conn_on_data
__int64 __fastcall nghttp3_conn_on_data(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 result; // rax
  __int64 (__fastcall *v9)(__int64, _QWORD, __int64, __int64, _QWORD, _QWORD); // rax
  int v10; // ecx

  result = nghttp3_http_on_data_chunk(a1: a2, a2: a4); /*0x10312f004*/
  if ( (_DWORD)result == 0 ) /*0x10312f00b*/
  {
    v9 = *(__int64 (__fastcall **)(__int64, _QWORD, __int64, __int64, _QWORD, _QWORD))(a1 + 144); /*0x10312f00d*/
    if ( v9 != nullptr ) /*0x10312f017*/
    {
      v10 = v9(a1, a2: *(_QWORD *)(a2 + 32), a3, a4, a5: *(_QWORD *)(a1 + 2088), a6: *(_QWORD *)(a2 + 456)); /*0x10312f038*/
      result = 4294966394LL; /*0x10312f03c*/
      if ( v10 == 0 ) /*0x10312f041*/
        return 0; /*0x10312f041*/
    }
    else
    {
      return 0; /*0x10312f046*/
    }
  }
  return result; /*0x10312f048*/
}

// Address: 0x10312f051 | Name: _nghttp3_conn_on_headers
__int64 __fastcall nghttp3_conn_on_headers(__int64 a1, __int64 a2, __int64 a3, __int64 a4, int a5)
{
  __int64 v6; // r10
  int v7; // r9d
  __int64 v8; // rax
  int v9; // r14d
  __int64 v10; // r12
  __int64 v11; // r15
  int v12; // eax
  __int64 request; // rax
  __int64 v14; // r12
  unsigned int v15; // r15d
  int v16; // ebx
  _BOOL8 v17; // r8
  int v18; // eax
  int v19; // ebx
  int v20; // eax
  unsigned __int64 v21; // rbx
  __int64 v22; // r12
  unsigned __int64 v23; // rax
  __int64 v24; // rsi
  int v25; // eax
  _QWORD v27[2]; // [rsp+18h] [rbp-A8h] BYREF
  __int64 v28; // [rsp+28h] [rbp-98h]
  __int64 v29; // [rsp+30h] [rbp-90h]
  __int64 v30; // [rsp+38h] [rbp-88h]
  __int64 (__fastcall *v31)(__int64, _QWORD, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD); // [rsp+40h] [rbp-80h]
  __int64 v32; // [rsp+48h] [rbp-78h]
  __int64 v33; // [rsp+50h] [rbp-70h]
  __int64 v34; // [rsp+58h] [rbp-68h] BYREF
  __int64 v35; // [rsp+60h] [rbp-60h]
  unsigned int v36; // [rsp+68h] [rbp-58h]
  unsigned __int8 v37; // [rsp+6Ch] [rbp-54h]
  __int64 v38; // [rsp+70h] [rbp-50h]
  __int64 v39; // [rsp+78h] [rbp-48h]
  __int64 v40; // [rsp+80h] [rbp-40h]
  __int64 v41; // [rsp+88h] [rbp-38h]
  unsigned int v42; // [rsp+90h] [rbp-30h]
  _BYTE v43[41]; // [rsp+97h] [rbp-29h] BYREF

  v6 = 0; /*0x10312f075*/
  if ( a5 != 0 || a4 != 0 ) /*0x10312f06b*/
  {
    v7 = __ROL4__(*(_DWORD *)(a2 + 608) - 2, 30); /*0x10312f08c*/
    v38 = a1 + 336; /*0x10312f0a1*/
    v8 = 168; /*0x10312f0a5*/
    v40 = a2; /*0x10312f0b8*/
    switch ( v7 ) /*0x10312f0bc*/
    {
      case 0: /*0x10312f0bc*/
        v41 = 0; /*0x10312f0bf*/
        v42 = 1; /*0x10312f0c7*/
        goto LABEL_7; /*0x10312f0ce*/
      case 1: /*0x10312f0bc*/
        LODWORD(v6) = 1; /*0x10312f0d0*/
        goto LABEL_5; /*0x10312f0d0*/
      case 2: /*0x10312f0bc*/
        v41 = 0; /*0x10312f0ea*/
        v42 = 0; /*0x10312f0f2*/
        goto LABEL_7; /*0x10312f0f2*/
      case 3: /*0x10312f0bc*/
LABEL_5:
        v8 = 192; /*0x10312f0d6*/
        v42 = v6; /*0x10312f0db*/
        v41 = 1; /*0x10312f0e4*/
LABEL_7:
        v32 = a1; /*0x10312f0f9*/
        v31 = *(__int64 (__fastcall **)(__int64, _QWORD, _QWORD, __int64, __int64, _QWORD, _QWORD, _QWORD))(a1 + v8); /*0x10312f101*/
        v33 = a3; /*0x10312f10f*/
        nghttp3_buf_wrap_init(a1: v27, a2: a3, a3: a4); /*0x10312f119*/
        v9 = v28; /*0x10312f122*/
        v29 = v27[1]; /*0x10312f126*/
        v10 = v40; /*0x10312f12a*/
        v11 = v40 + 264; /*0x10312f12e*/
        v12 = nghttp3_buf_len(a1: (__int64)v27); /*0x10312f139*/
        v39 = v11; /*0x10312f14e*/
        request = nghttp3_qpack_decoder_read_request( /*0x10312f15b*/
                    a1: v38,
                    a2: v11,
                    a3: (unsigned int)&v34,
                    a4: (unsigned int)v43,
                    a5: v9,
                    a6: v12,
                    a7: a5);
        if ( request < 0 ) /*0x10312f163*/
          return (int)request; /*0x10312f163*/
        v30 = v10 + 616; /*0x10312f171*/
        v14 = v32; /*0x10312f17e*/
        v15 = v41; /*0x10312f182*/
        break; /*0x10312f182*/
      default:
        nghttp3_unreachable_fail(a1: "nghttp3_conn.c", a2: 1924, a3: "conn_decode_headers"); /*0x10312f34b*/
    }
    while ( 1 ) /*0x10312f18d*/
    {
      v16 = request + v28; /*0x10312f18d*/
      v28 += request; /*0x10312f190*/
      if ( (v43[0] & 4) != 0 ) /*0x10312f19e*/
      {
        v21 = *(_QWORD *)(v14 + 2144); /*0x10312f2af*/
        v22 = v14 + 1680; /*0x10312f2b7*/
        v23 = nghttp3_pq_size(a1: v22); /*0x10312f2c1*/
        v6 = -401; /*0x10312f2c6*/
        if ( v21 <= v23 ) /*0x10312f2d0*/
          return v6; /*0x10312f2d0*/
        v24 = v40; /*0x10312f2d2*/
        *(_BYTE *)(v40 + 648) |= 0x10u; /*0x10312f2d6*/
        v25 = nghttp3_pq_push(a1: v22, a2: v24 + 56); /*0x10312f2e4*/
        if ( v25 != 0 ) /*0x10312f2eb*/
          return v25; /*0x10312f2f0*/
        return v28 - v33; /*0x10312f2eb*/
      }
      if ( (v43[0] & 2) != 0 ) /*0x10312f1a7*/
      {
        nghttp3_qpack_stream_context_reset(a1: v39); /*0x10312f2f6*/
        return v28 - v33; /*0x10312f302*/
      }
      if ( request == 0 ) /*0x10312f1b0*/
        return v28 - v33; /*0x10312f1b0*/
      if ( (v43[0] & 1) != 0 ) /*0x10312f1b9*/
        break; /*0x10312f1b9*/
LABEL_27:
      v20 = nghttp3_buf_len(a1: (__int64)v27); /*0x10312f276*/
      request = nghttp3_qpack_decoder_read_request( /*0x10312f29c*/
                  a1: v38,
                  a2: v39,
                  a3: (unsigned int)&v34,
                  a4: (unsigned int)v43,
                  a5: v16,
                  a6: v20,
                  a7: a5);
      if ( request < 0 ) /*0x10312f2a4*/
        return (int)request; /*0x10312f2ad*/
    }
    v17 = *(_DWORD *)(v14 + 2096) != 0 && *(_BYTE *)(v14 + 2152) != 0; /*0x10312f1d6*/
    v18 = nghttp3_http_on_header(a1: v30, a2: &v34, a3: v42, a4: v15, a5: v17); /*0x10312f1f0*/
    if ( v18 != 0 ) /*0x10312f1f7*/
    {
      v19 = v18; /*0x10312f1f9*/
      if ( v18 == -105 ) /*0x10312f1fe*/
      {
LABEL_25:
        nghttp3_rcbuf_decref(a1: v34); /*0x10312f255*/
        nghttp3_rcbuf_decref(a1: v35); /*0x10312f262*/
        if ( v19 != 0 ) /*0x10312f269*/
          return v19; /*0x10312f31e*/
        v16 = v28; /*0x10312f26f*/
        goto LABEL_27; /*0x10312f26f*/
      }
      if ( v18 != -106 ) /*0x10312f203*/
        nghttp3_unreachable_fail(a1: "nghttp3_conn.c", a2: 1985, a3: "conn_decode_headers"); /*0x10312f333*/
    }
    else if ( v31 != nullptr ) /*0x10312f211*/
    {
      v19 = v31( /*0x10312f249*/
              a1: v14,
              a2: *(_QWORD *)(v40 + 32),
              a3: v36,
              a4: v34,
              a5: v35,
              a6: v37,
              a7: *(_QWORD *)(v14 + 2088),
              a8: *(_QWORD *)(v40 + 456));
      if ( v19 != 0 ) /*0x10312f24d*/
        v19 = -902; /*0x10312f24d*/
      goto LABEL_25; /*0x10312f24d*/
    }
    v19 = 0; /*0x10312f253*/
    goto LABEL_25; /*0x10312f253*/
  }
  return v6; /*0x10312f309*/
}

// Address: 0x10312f43a | Name: _nghttp3_conn_bind_control_stream
__int64 __fastcall nghttp3_conn_bind_control_stream(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  __int64 v4; // r14
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // r9
  __int64 v9; // rdx
  __int64 v10; // r8
  __int64 v11; // r9
  __int128 *v12; // rax
  __int128 v13; // xmm0
  __int64 v14; // [rsp-40h] [rbp-40h] BYREF
  _QWORD v15[3]; // [rsp-38h] [rbp-38h] BYREF
  __int64 v16; // [rsp-20h] [rbp-20h] BYREF

  result = 4294967194LL; /*0x10312f43a*/
  if ( *(_QWORD *)(a1 + 2512) == 0 ) /*0x10312f447*/
  {
    result = nghttp3_conn_create_stream(a1, a2: &v16, a3: a2); /*0x10312f45f*/
    if ( (_DWORD)result == 0 ) /*0x10312f466*/
    {
      v4 = v16; /*0x10312f468*/
      *(_QWORD *)(v16 + 504) = 0; /*0x10312f46c*/
      *(_QWORD *)(a1 + 2512) = v4; /*0x10312f477*/
      result = nghttp3_stream_write_stream_type(a1: v4); /*0x10312f481*/
      if ( (_DWORD)result == 0 ) /*0x10312f488*/
      {
        v14 = 4; /*0x10312f495*/
        *(_OWORD *)v15 = 0; /*0x10312f49f*/
        v15[2] = a1 + 2120; /*0x10312f4a3*/
        result = nghttp3_stream_frq_add(a1: v4, a2: &v14, a3: v5, a4: v6, a5: v7, a6: v8); /*0x10312f4aa*/
        if ( (_DWORD)result == 0 ) /*0x10312f4b1*/
        {
          v12 = *(__int128 **)(a1 + 2160); /*0x10312f4b3*/
          if ( v12 == nullptr ) /*0x10312f4bd*/
            return 0; /*0x10312f4bd*/
          v13 = *v12; /*0x10312f4c3*/
          v14 = 12; /*0x10312f4ca*/
          *(_OWORD *)v15 = v13; /*0x10312f4d2*/
          result = nghttp3_stream_frq_add(a1: v4, a2: &v14, a3: v9, a4: v15, a5: v10, a6: v11); /*0x10312f4dc*/
          if ( (_DWORD)result == 0 ) /*0x10312f4e3*/
            return 0; /*0x10312f4e5*/
        }
      }
    }
  }
  return result; /*0x10312f449*/
}

// Address: 0x10312f4f0 | Name: _nghttp3_conn_bind_qpack_streams
__int64 __fastcall nghttp3_conn_bind_qpack_streams(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  __int64 v6; // rdi
  __int64 v7; // rdi
  _QWORD v8[3]; // [rsp+8h] [rbp-18h] BYREF

  result = 4294967194LL; /*0x10312f4fb*/
  if ( *(_QWORD *)(a1 + 2520) == 0 && *(_QWORD *)(a1 + 2528) == 0 ) /*0x10312f515*/
  {
    result = nghttp3_conn_create_stream(a1, a2: v8, a3: a2); /*0x10312f524*/
    if ( (_DWORD)result == 0 ) /*0x10312f52b*/
    {
      v6 = v8[0]; /*0x10312f52d*/
      *(_QWORD *)(v8[0] + 504LL) = 2; /*0x10312f531*/
      *(_QWORD *)(a1 + 2520) = v6; /*0x10312f53c*/
      result = nghttp3_stream_write_stream_type(a1: v6); /*0x10312f543*/
      if ( (_DWORD)result == 0 ) /*0x10312f54a*/
      {
        result = nghttp3_conn_create_stream(a1, a2: v8, a3); /*0x10312f556*/
        if ( (_DWORD)result == 0 ) /*0x10312f55d*/
        {
          v7 = v8[0]; /*0x10312f568*/
          *(_QWORD *)(v8[0] + 504LL) = 3; /*0x10312f56c*/
          *(_QWORD *)(a1 + 2528) = v7; /*0x10312f577*/
          return nghttp3_stream_write_stream_type(a1: v7); /*0x10312f586*/
        }
      }
    }
  }
  return result; /*0x10312f55f*/
}

// Address: 0x10312f58b | Name: _nghttp3_conn_writev_stream
__int64 __fastcall nghttp3_conn_writev_stream(__int64 *a1, _QWORD *a2, _DWORD *a3, __int64 a4, __int64 a5)
{
  __int64 v9; // r15
  __int64 next_tx_stream; // rax
  __int64 v11; // r14
  __int64 v12; // r15
  __int64 v13; // rax
  int v14; // eax

  *a2 = -1; /*0x10312f599*/
  *a3 = 0; /*0x10312f5a0*/
  if ( a5 == 0 ) /*0x10312f5a9*/
    return 0; /*0x10312f5a9*/
  if ( a1[314] != 0 && (unsigned int)nghttp3_stream_is_blocked() == 0 ) /*0x10312f5d2*/
  {
    v13 = conn_writev_stream((__int64)a1, a2, a3, a4, a5, a6: a1[314]); /*0x10312f6a5*/
    if ( v13 != 0 ) /*0x10312f6ad*/
      return v13; /*0x10312f6ad*/
  }
  if ( a1[316] != 0 && (unsigned int)nghttp3_stream_is_blocked() == 0 ) /*0x10312f5eb*/
  {
    v14 = nghttp3_stream_write_qpack_decoder_stream(a1: a1[316]); /*0x10312f6bb*/
    if ( v14 != 0 ) /*0x10312f6c2*/
      return v14; /*0x10312f6c7*/
    v13 = conn_writev_stream((__int64)a1, a2, a3, a4, a5, a6: a1[316]); /*0x10312f706*/
    if ( v13 != 0 ) /*0x10312f70e*/
      return v13; /*0x10312f70e*/
  }
  if ( a1[315] != 0 && (unsigned int)nghttp3_stream_is_blocked() == 0 ) /*0x10312f604*/
  {
    v13 = conn_writev_stream((__int64)a1, a2, a3, a4, a5, a6: a1[315]); /*0x10312f6e0*/
    if ( v13 != 0 ) /*0x10312f6e8*/
      return v13; /*0x10312f714*/
  }
  v9 = a5; /*0x10312f60a*/
  next_tx_stream = nghttp3_conn_get_next_tx_stream(a1); /*0x10312f610*/
  if ( next_tx_stream == 0 ) /*0x10312f618*/
    return 0; /*0x10312f686*/
  v11 = next_tx_stream; /*0x10312f61a*/
  v12 = conn_writev_stream((__int64)a1, a2, a3, a4, a5: v9, a6: next_tx_stream); /*0x10312f635*/
  if ( v12 >= 0 /*0x10312f65c*/
    && (unsigned int)nghttp3_client_stream_bidi(a1: *(_QWORD *)(v11 + 32)) != 0
    && (unsigned int)nghttp3_stream_require_schedule(a1: v11) == 0 )
  {
    nghttp3_tnode_unschedule(a1: v11 + 24, a2: &a1[5 * *(unsigned int *)(v11 + 48) + 220]); /*0x10312f67c*/
  }
  return v12; /*0x10312f71e*/
}

// Address: 0x10312f7e7 | Name: _nghttp3_conn_get_next_tx_stream
__int64 __fastcall nghttp3_conn_get_next_tx_stream(__int64 a1)
{
  __int64 v1; // r14
  __int64 v2; // rbx
  __int64 v3; // r12

  v1 = a1 + 1760; /*0x10312f7f5*/
  v2 = 0; /*0x10312f7fc*/
  v3 = 0; /*0x10312f7fe*/
  while ( (unsigned int)nghttp3_pq_empty(a1: v1 + v3) != 0 ) /*0x10312f80f*/
  {
    v3 += 40; /*0x10312f811*/
    if ( v3 == 320 ) /*0x10312f81c*/
      return v2; /*0x10312f81c*/
  }
  return nghttp3_pq_top(a1: v1 + v3) - 24; /*0x10312f832*/
}

// Address: 0x10312f83b | Name: _nghttp3_conn_unschedule_stream
__int64 __fastcall nghttp3_conn_unschedule_stream(__int64 a1, __int64 a2)
{
  return nghttp3_tnode_unschedule(a1: a2 + 24, a2: a1 + 40LL * *(unsigned int *)(a2 + 48) + 1760); /*0x10312f858*/
}

// Address: 0x10312f85e | Name: _nghttp3_conn_add_write_offset
__int64 __fastcall nghttp3_conn_add_write_offset(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v5; // rax
  unsigned int v6; // r15d
  __int64 v7; // rbx
  unsigned __int64 v8; // rdx

  v5 = nghttp3_map_find(a1: a1 + 280); /*0x10312f876*/
  v6 = 0; /*0x10312f87b*/
  if ( v5 != 0 ) /*0x10312f881*/
  {
    v7 = v5; /*0x10312f887*/
    nghttp3_stream_add_outq_offset(a1: v5, a2: a3); /*0x10312f890*/
    *(_QWORD *)(v7 + 496) += a3; /*0x10312f895*/
    if ( (unsigned int)nghttp3_client_stream_bidi(a1: *(_QWORD *)(v7 + 32)) != 0 ) /*0x10312f8a7*/
    {
      if ( (unsigned int)nghttp3_stream_require_schedule(a1: v7) == 0 ) /*0x10312f8b3*/
      {
        nghttp3_tnode_unschedule(a1: v7 + 24, a2: a1 + 40LL * *(unsigned int *)(v7 + 48) + 1760); /*0x10312f910*/
        return 0; /*0x10312f910*/
      }
      v8 = *(_QWORD *)(v7 + 496); /*0x10312f8b5*/
      if ( v8 >= 0x320 ) /*0x10312f8c3*/
      {
        v6 = nghttp3_tnode_schedule(a1: v7 + 24, a2: a1 + 40LL * *(unsigned int *)(v7 + 48) + 1760, a3: v8); /*0x10312f8e3*/
        if ( v6 == 0 ) /*0x10312f8e8*/
        {
          *(_QWORD *)(v7 + 496) = 0; /*0x10312f8ea*/
          return 0; /*0x10312f915*/
        }
      }
    }
  }
  return v6; /*0x10312f91b*/
}

// Address: 0x10312f924 | Name: _nghttp3_conn_schedule_stream
__int64 __fastcall nghttp3_conn_schedule_stream(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  result = nghttp3_tnode_schedule( /*0x10312f94d*/
             a1: a2 + 24,
             a2: a1 + 40LL * *(unsigned int *)(a2 + 48) + 1760,
             a3: *(_QWORD *)(a2 + 496));
  if ( (_DWORD)result == 0 ) /*0x10312f954*/
    *(_QWORD *)(a2 + 496) = 0; /*0x10312f956*/
  return result; /*0x10312f965*/
}

// Address: 0x10312f968 | Name: _nghttp3_conn_add_ack_offset
__int64 __fastcall nghttp3_conn_add_ack_offset(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rax

  v4 = nghttp3_map_find(a1: a1 + 280); /*0x10312f978*/
  if ( v4 != 0 ) /*0x10312f980*/
    return nghttp3_stream_update_ack_offset(a1: v4, a2: *(_QWORD *)(v4 + 488) + a3); /*0x10312f995*/
  else
    return 0; /*0x10312f99a*/
}

// Address: 0x10312f9a3 | Name: _nghttp3_conn_update_ack_offset
__int64 __fastcall nghttp3_conn_update_ack_offset(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  __int64 v4; // rax
  unsigned int v5; // ecx

  v4 = nghttp3_map_find(a1: a1 + 280); /*0x10312f9b3*/
  if ( v4 != 0 ) /*0x10312f9bb*/
  {
    v5 = -101; /*0x10312f9bd*/
    if ( *(_QWORD *)(v4 + 488) <= a3 ) /*0x10312f9c9*/
      return nghttp3_stream_update_ack_offset(a1: v4, a2: a3); /*0x10312f9d7*/
  }
  else
  {
    return 0; /*0x10312f9dc*/
  }
  return v5; /*0x10312f9d5*/
}

// Address: 0x10312f9e7 | Name: _nghttp3_conn_ensure_stream_scheduled
__int64 __fastcall nghttp3_conn_ensure_stream_scheduled(__int64 a1, __int64 a2)
{
  __int64 v4; // r14
  int is_scheduled; // ecx
  __int64 result; // rax

  v4 = a2 + 24; /*0x10312f9f7*/
  is_scheduled = nghttp3_tnode_is_scheduled(a1: a2 + 24); /*0x10312fa03*/
  result = 0; /*0x10312fa05*/
  if ( is_scheduled == 0 ) /*0x10312fa09*/
  {
    result = nghttp3_tnode_schedule( /*0x10312fa27*/
               a1: v4,
               a2: a1 + 40LL * *(unsigned int *)(a2 + 48) + 1760,
               a3: *(_QWORD *)(a2 + 496));
    if ( (_DWORD)result == 0 ) /*0x10312fa2e*/
    {
      *(_QWORD *)(a2 + 496) = 0; /*0x10312fa30*/
      return 0; /*0x10312fa3b*/
    }
  }
  return result; /*0x10312fa41*/
}

// Address: 0x10312fa48 | Name: _nghttp3_conn_submit_request
__int64 __fastcall nghttp3_conn_submit_request(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 *a5, __int64 a6)
{
  __int64 result; // rax
  __int64 v12; // rbx
  __int64 v14[6]; // [rsp+10h] [rbp-30h] BYREF

  result = 4294967185LL; /*0x10312fa5d*/
  if ( (*(_BYTE *)(a1 + 2100) & 0x20) == 0 ) /*0x10312fa69*/
  {
    v14[0] = nghttp3_map_find(a1: a1 + 280); /*0x10312fa89*/
    result = 4294967192LL; /*0x10312fa8d*/
    if ( v14[0] == 0 ) /*0x10312fa95*/
    {
      result = nghttp3_conn_create_stream(a1, a2: v14, a3: a2); /*0x10312faa1*/
      if ( (_DWORD)result == 0 ) /*0x10312faa8*/
      {
        v12 = v14[0]; /*0x10312fab9*/
        *(_DWORD *)(v14[0] + 608) = 9; /*0x10312fabd*/
        *(_QWORD *)(v12 + 456) = a6; /*0x10312fac7*/
        *(_BYTE *)(v12 + 52) = 1; /*0x10312face*/
        nghttp3_http_record_request_method(a1: v12, a2: a3, a3: a4); /*0x10312fadb*/
        if ( a5 == nullptr ) /*0x10312fae7*/
          *(_BYTE *)(v12 + 648) |= 8u; /*0x10312fae9*/
        return conn_submit_headers_data(a1, a2: v12, a3, a4, a5); /*0x10312fb0a*/
      }
    }
  }
  return result; /*0x10312faaa*/
}

// Address: 0x10312fbfd | Name: _nghttp3_conn_submit_info
__int64 __fastcall nghttp3_conn_submit_info(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v7; // rax

  v7 = nghttp3_map_find(a1: a1 + 280); /*0x10312fc17*/
  if ( v7 != 0 ) /*0x10312fc1f*/
    return conn_submit_headers_data(a1, a2: v7, a3, a4, a5: nullptr); /*0x10312fc3a*/
  else
    return 4294967186LL; /*0x10312fc3f*/
}

// Address: 0x10312fc4f | Name: _nghttp3_conn_submit_response
__int64 __fastcall nghttp3_conn_submit_response(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 *a5)
{
  __int64 v9; // rax

  v9 = nghttp3_map_find(a1: a1 + 280); /*0x10312fc6d*/
  if ( v9 == 0 ) /*0x10312fc75*/
    return 4294967186LL; /*0x10312fc9f*/
  if ( a5 == nullptr ) /*0x10312fc7a*/
    *(_BYTE *)(v9 + 648) |= 8u; /*0x10312fc7c*/
  return conn_submit_headers_data(a1, a2: v9, a3, a4, a5); /*0x10312fc92*/
}

// Address: 0x10312fcad | Name: _nghttp3_conn_submit_trailers
__int64 __fastcall nghttp3_conn_submit_trailers(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v7; // rax
  __int16 v8; // dx
  unsigned int v9; // ecx

  v7 = nghttp3_map_find(a1: a1 + 280); /*0x10312fcc7*/
  if ( v7 != 0 ) /*0x10312fccf*/
  {
    v8 = *(_WORD *)(v7 + 648); /*0x10312fcd1*/
    v9 = -102; /*0x10312fcd8*/
    if ( (v8 & 8) == 0 ) /*0x10312fce0*/
    {
      *(_WORD *)(v7 + 648) = v8 | 8; /*0x10312fce5*/
      return conn_submit_headers_data(a1, a2: v7, a3, a4, a5: nullptr); /*0x10312fd05*/
    }
  }
  else
  {
    return (unsigned int)-110; /*0x10312fd0a*/
  }
  return v9; /*0x10312fcff*/
}

// Address: 0x10312fd1c | Name: _nghttp3_conn_submit_shutdown_notice
__int64 __fastcall nghttp3_conn_submit_shutdown_notice(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  __int64 v7; // rcx
  __int64 result; // rax
  __int64 v9; // [rsp+8h] [rbp-28h] BYREF
  __int64 v10; // [rsp+10h] [rbp-20h]

  v7 = 0x3FFFFFFFFFFFFFFFLL; /*0x10312fd32*/
  if ( *(_DWORD *)(a1 + 2096) != 0 ) /*0x10312fd3d*/
    v7 = 0x3FFFFFFFFFFFFFFCLL; /*0x10312fd3d*/
  v9 = 7; /*0x10312fd45*/
  v10 = v7; /*0x10312fd4c*/
  result = nghttp3_stream_frq_add(a1: *(_QWORD *)(a1 + 2512), a2: &v9, a3, a4: v7, a5, a6); /*0x10312fd57*/
  if ( (_DWORD)result == 0 ) /*0x10312fd5e*/
  {
    *(_QWORD *)(a1 + 2536) = v10; /*0x10312fd64*/
    *(_BYTE *)(a1 + 2100) |= 0x40u; /*0x10312fd6b*/
  }
  return result; /*0x10312fd72*/
}

// Address: 0x10312fd79 | Name: _nghttp3_conn_shutdown
__int64 __fastcall nghttp3_conn_shutdown(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6)
{
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 result; // rax
  __int64 v10; // [rsp+8h] [rbp-28h] BYREF
  __int64 v11; // [rsp+10h] [rbp-20h]

  if ( *(_DWORD *)(a1 + 2096) != 0 ) /*0x10312fd8c*/
  {
    a4 = *(_QWORD *)(a1 + 2408); /*0x10312fd8e*/
    v7 = 0x3FFFFFFFFFFFFFF8LL; /*0x10312fd95*/
    if ( a4 < 0x3FFFFFFFFFFFFFF8LL ) /*0x10312fda2*/
      v7 = *(_QWORD *)(a1 + 2408); /*0x10312fda2*/
    v8 = v7 + 4; /*0x10312fda6*/
  }
  else
  {
    v8 = 0; /*0x10312fdac*/
  }
  v10 = 7; /*0x10312fdb2*/
  v11 = v8; /*0x10312fdb9*/
  result = nghttp3_stream_frq_add(a1: *(_QWORD *)(a1 + 2512), a2: &v10, a3, a4, a5, a6); /*0x10312fdc4*/
  if ( (_DWORD)result == 0 ) /*0x10312fdcb*/
  {
    *(_QWORD *)(a1 + 2536) = v11; /*0x10312fdd1*/
    *(_BYTE *)(a1 + 2100) |= 0x50u; /*0x10312fdd8*/
  }
  return result; /*0x10312fddf*/
}

// Address: 0x10312fde6 | Name: _nghttp3_conn_block_stream
__int64 __fastcall nghttp3_conn_block_stream(__int64 a1)
{
  __int64 result; // rax
  __int64 v3; // r14

  result = nghttp3_map_find(a1: a1 + 280); /*0x10312fdf7*/
  if ( result != 0 ) /*0x10312fdff*/
  {
    v3 = result; /*0x10312fe01*/
    *(_BYTE *)(result + 648) |= 2u; /*0x10312fe04*/
    *(_QWORD *)(result + 496) = 0; /*0x10312fe0b*/
    result = nghttp3_client_stream_bidi(a1: *(_QWORD *)(result + 32)); /*0x10312fe1a*/
    if ( (_DWORD)result != 0 ) /*0x10312fe21*/
      return nghttp3_tnode_unschedule(a1: v3 + 24, a2: a1 + 40LL * *(unsigned int *)(v3 + 48) + 1760); /*0x10312fe41*/
  }
  return result; /*0x10312fe3d*/
}

// Address: 0x10312fe4b | Name: _nghttp3_conn_shutdown_stream_write
__int64 __fastcall nghttp3_conn_shutdown_stream_write(__int64 a1)
{
  __int64 result; // rax
  __int64 v3; // r14

  result = nghttp3_map_find(a1: a1 + 280); /*0x10312fe5c*/
  if ( result != 0 ) /*0x10312fe64*/
  {
    v3 = result; /*0x10312fe66*/
    *(_BYTE *)(result + 649) |= 1u; /*0x10312fe69*/
    *(_QWORD *)(result + 496) = 0; /*0x10312fe70*/
    result = nghttp3_client_stream_bidi(a1: *(_QWORD *)(result + 32)); /*0x10312fe7f*/
    if ( (_DWORD)result != 0 ) /*0x10312fe86*/
      return nghttp3_tnode_unschedule(a1: v3 + 24, a2: a1 + 40LL * *(unsigned int *)(v3 + 48) + 1760); /*0x10312fea6*/
  }
  return result; /*0x10312fea2*/
}

// Address: 0x10312feb0 | Name: _nghttp3_conn_unblock_stream
__int64 __fastcall nghttp3_conn_unblock_stream(__int64 a1)
{
  __int64 v2; // rax
  __int64 v3; // r14

  v2 = nghttp3_map_find(a1: a1 + 280); /*0x10312fec1*/
  if ( v2 != 0 /*0x10312feec*/
    && (v3 = v2, *(_BYTE *)(v2 + 648) &= ~2u, (unsigned int)nghttp3_client_stream_bidi(a1: *(_QWORD *)(v2 + 32)) != 0)
    && (unsigned int)nghttp3_stream_require_schedule(a1: v3) != 0 )
  {
    return nghttp3_conn_ensure_stream_scheduled(a1, a2: v3); /*0x10312fef8*/
  }
  else
  {
    return 0; /*0x10312fefd*/
  }
}

// Address: 0x10312ff04 | Name: _nghttp3_conn_is_stream_writable
_BOOL8 __fastcall nghttp3_conn_is_stream_writable(__int64 a1)
{
  __int64 v1; // rax

  v1 = nghttp3_map_find(a1: a1 + 280); /*0x10312ff0f*/
  return v1 != 0 && (*(_WORD *)(v1 + 648) & 0x106) == 0; /*0x10312ff28*/
}

// Address: 0x10312ff31 | Name: _nghttp3_conn_resume_stream
__int64 __fastcall nghttp3_conn_resume_stream(__int64 a1)
{
  __int64 v2; // rax
  __int64 v3; // r14

  v2 = nghttp3_map_find(a1: a1 + 280); /*0x10312ff42*/
  if ( v2 != 0 /*0x10312ff6d*/
    && (v3 = v2, *(_BYTE *)(v2 + 648) &= ~4u, (unsigned int)nghttp3_client_stream_bidi(a1: *(_QWORD *)(v2 + 32)) != 0)
    && (unsigned int)nghttp3_stream_require_schedule(a1: v3) != 0 )
  {
    return nghttp3_conn_ensure_stream_scheduled(a1, a2: v3); /*0x10312ff79*/
  }
  else
  {
    return 0; /*0x10312ff7e*/
  }
}

// Address: 0x10312ff85 | Name: _nghttp3_conn_close_stream
__int64 __fastcall nghttp3_conn_close_stream(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v6; // rax
  __int64 v7; // r14
  __int64 result; // rax

  v6 = nghttp3_map_find(a1: a1 + 280); /*0x10312ffa0*/
  if ( v6 == 0 ) /*0x10312ffa8*/
    return 4294967186LL; /*0x103130001*/
  v7 = v6; /*0x10312ffaa*/
  if ( (unsigned int)nghttp3_stream_uni(a1: a2) == 0 || (result = 4294966691LL, *(_QWORD *)(v7 + 504) == -1) ) /*0x10312ffc6*/
  {
    *(_QWORD *)(v7 + 592) = a3; /*0x10312ffc8*/
    nghttp3_tnode_unschedule(a1: v7 + 24, a2: a1 + 40LL * *(unsigned int *)(v7 + 48) + 1760); /*0x10312ffe9*/
    return conn_delete_stream(a1, a2: (_QWORD *)v7); /*0x10312fffc*/
  }
  return result; /*0x10312fff4*/
}

// Address: 0x10313000f | Name: _nghttp3_conn_shutdown_stream_read
__int64 __fastcall nghttp3_conn_shutdown_stream_read(__int64 a1, __int64 a2)
{
  __int64 v4; // rax
  int v5; // ecx

  if ( (unsigned int)nghttp3_client_stream_bidi(a1: a2) != 0 ) /*0x103130026*/
  {
    v4 = nghttp3_map_find(a1: a1 + 280); /*0x103130032*/
    if ( v4 == 0 ) /*0x10313003a*/
      return nghttp3_qpack_decoder_cancel_stream(a1: a1 + 336, a2); /*0x103130066*/
    v5 = *(_DWORD *)(v4 + 648); /*0x10313003c*/
    if ( (v5 & 0x200) == 0 ) /*0x103130046*/
    {
      *(_WORD *)(v4 + 648) = v5 | 0x200; /*0x10313004e*/
      return nghttp3_qpack_decoder_cancel_stream(a1: a1 + 336, a2); /*0x10313004e*/
    }
  }
  return 0; /*0x103130062*/
}

// Address: 0x103130072 | Name: _nghttp3_conn_qpack_blocked_streams_push
__int64 __fastcall nghttp3_conn_qpack_blocked_streams_push(__int64 a1, __int64 a2)
{
  return nghttp3_pq_push(a1: a1 + 1680, a2: a2 + 56); /*0x103130081*/
}

// Address: 0x103130087 | Name: _nghttp3_conn_qpack_blocked_streams_remove
__int64 __fastcall nghttp3_conn_qpack_blocked_streams_remove(__int64 a1, __int64 a2)
{
  return nghttp3_pq_remove(a1: a1 + 1680, a2: a2 + 56); /*0x103130096*/
}

// Address: 0x10313009c | Name: _nghttp3_conn_set_max_client_streams_bidi
void __fastcall nghttp3_conn_set_max_client_streams_bidi(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a1 + 2352) = a2; /*0x1031300a0*/
}

// Address: 0x1031300a9 | Name: _nghttp3_conn_set_max_concurrent_streams
__int64 __fastcall nghttp3_conn_set_max_concurrent_streams(__int64 a1)
{
  return nghttp3_qpack_decoder_set_max_concurrent_streams(a1: a1 + 336); /*0x1031300b4*/
}

// Address: 0x1031300ba | Name: _nghttp3_conn_set_stream_user_data
__int64 __fastcall nghttp3_conn_set_stream_user_data(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rax

  v4 = nghttp3_map_find(a1: a1 + 280); /*0x1031300ca*/
  if ( v4 == 0 ) /*0x1031300d2*/
    return 4294967186LL; /*0x1031300df*/
  *(_QWORD *)(v4 + 456) = a3; /*0x1031300d4*/
  return 0; /*0x1031300e8*/
}

// Address: 0x1031300eb | Name: _nghttp3_conn_get_frame_payload_left
__int64 __fastcall nghttp3_conn_get_frame_payload_left(__int64 a1, __int64 a2)
{
  char v2; // bl
  __int64 v4; // rax
  __int64 result; // rax

  v2 = a2; /*0x1031300f2*/
  if ( (unsigned int)nghttp3_client_stream_bidi(a1: a2) != 0 ) /*0x103130102*/
  {
    v4 = nghttp3_map_find(a1: a1 + 280); /*0x103130111*/
    if ( v4 != 0 ) /*0x103130119*/
      return *(_QWORD *)(v4 + 576); /*0x103130122*/
  }
  else
  {
    result = 0; /*0x103130129*/
    if ( (v2 & 3) != (*(_DWORD *)(a1 + 2096) == 0) + 2 ) /*0x10313013d*/
      return result; /*0x10313013d*/
    v4 = nghttp3_map_find(a1: a1 + 280); /*0x10313014c*/
    if ( v4 != 0 && *(_QWORD *)(v4 + 504) == 0 ) /*0x10313015e*/
      return *(_QWORD *)(v4 + 576); /*0x10313015e*/
  }
  return 0; /*0x103130162*/
}

// Address: 0x103130167 | Name: _nghttp3_conn_get_stream_priority_versioned
__int64 __fastcall nghttp3_conn_get_stream_priority_versioned(__int64 a1, __int64 a2, _QWORD *a3, __int64 a4)
{
  __int64 v6; // rax

  if ( (unsigned int)nghttp3_client_stream_bidi(a1: a4) == 0 ) /*0x103130184*/
    return 4294967195LL; /*0x1031301a8*/
  v6 = nghttp3_map_find(a1: a1 + 280); /*0x103130193*/
  if ( v6 == 0 ) /*0x10313019b*/
    return 4294967186LL; /*0x1031301af*/
  *a3 = *(_QWORD *)(v6 + 48); /*0x1031301a1*/
  return 0; /*0x1031301b8*/
}

// Address: 0x1031301bf | Name: _nghttp3_conn_set_client_stream_priority
__int64 __fastcall nghttp3_conn_set_client_stream_priority(__int64 a1, __int64 a2, const void *a3, size_t a4)
{
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // r8
  __int64 v11; // r9
  void *v12; // rax
  void *v13; // r13
  _QWORD v15[9]; // [rsp+8h] [rbp-48h] BYREF

  if ( (unsigned int)nghttp3_client_stream_bidi(a1: a2) == 0 ) /*0x1031301e6*/
    return 4294967195LL; /*0x10313022d*/
  if ( nghttp3_map_find(a1: a1 + 280) == 0 ) /*0x1031301fa*/
    return 4294967186LL; /*0x103130234*/
  if ( a4 == 0 ) /*0x1031301ff*/
  {
    v13 = nullptr; /*0x103130236*/
    goto LABEL_9; /*0x103130236*/
  }
  v12 = (void *)nghttp3_mem_malloc(a1: *(_QWORD *)(a1 + 2080), a2: a4, a3: v8, a4: v9, a5: v10); /*0x10313020b*/
  if ( v12 != nullptr ) /*0x103130213*/
  {
    v13 = v12; /*0x103130215*/
    memcpy(__dst: v12, __src: a3, __n: a4); /*0x103130221*/
LABEL_9:
    v15[0] = 984832; /*0x103130239*/
    v15[1] = a2; /*0x103130244*/
    v15[2] = v13; /*0x103130248*/
    v15[3] = a4; /*0x10313024c*/
    return nghttp3_stream_frq_add(a1: *(_QWORD *)(a1 + 2512), a2: v15, a3: v8, a4: v9, a5: v10, a6: v11); /*0x10313025c*/
  }
  return 4294966395LL; /*0x103130263*/
}

// Address: 0x103130272 | Name: _nghttp3_conn_set_server_stream_priority_versioned
__int64 __fastcall nghttp3_conn_set_server_stream_priority_versioned(__int64 a1, __int64 a2, __int64 a3, _QWORD *a4)
{
  __int64 v6; // rax

  if ( (unsigned int)nghttp3_client_stream_bidi(a1: a2) == 0 ) /*0x10313028f*/
    return 4294967195LL; /*0x1031302c4*/
  v6 = nghttp3_map_find(a1: a1 + 280); /*0x10313029b*/
  if ( v6 == 0 ) /*0x1031302a3*/
    return 4294967186LL; /*0x1031302cb*/
  *(_BYTE *)(v6 + 649) |= 4u; /*0x1031302a5*/
  return conn_update_stream_priority(a1, a2: v6, a3: a4); /*0x1031302b9*/
}

// Address: 0x1031302db | Name: _nghttp3_conn_is_drained
__int64 __fastcall nghttp3_conn_is_drained(__int64 a1)
{
  unsigned int v1; // ebx

  v1 = 0; /*0x1031302e2*/
  if ( (*(_BYTE *)(a1 + 2100) & 0x10) != 0 /*0x103130308*/
    && *(_QWORD *)(a1 + 2360) == 0
    && (unsigned int)nghttp3_stream_outq_write_done(a1: *(_QWORD *)(a1 + 2512)) != 0 )
  {
    return *(_QWORD *)(*(_QWORD *)(a1 + 2512) + 112LL) == 0; /*0x103130318*/
  }
  return v1; /*0x10313031d*/
}

// Address: 0x103130364 | Name: _nghttp3_get_varint
_WORD *__fastcall nghttp3_get_varint(_QWORD *a1, _WORD *a2)
{
  _WORD *result; // rax

  switch ( *(unsigned __int8 *)a2 >> 6 ) /*0x103130381*/
  {
    case 0: /*0x103130381*/
      *a1 = *(unsigned __int8 *)a2; /*0x103130386*/
      result = (_WORD *)((char *)a2 + 1); /*0x103130383*/
      break; /*0x103130389*/
    case 1: /*0x103130381*/
      *a1 = (unsigned __int16)__ROL2__(*a2 & 0xFF3F, 8); /*0x1031303c3*/
      result = a2 + 1; /*0x1031303c6*/
      break; /*0x1031303c6*/
    case 2: /*0x103130381*/
      *a1 = _byteswap_ulong(*(_DWORD *)a2 & 0xFFFFFF3F); /*0x103130394*/
      result = a2 + 2; /*0x103130397*/
      break; /*0x10313039b*/
    case 3: /*0x103130381*/
      *a1 = _byteswap_uint64(*(_QWORD *)a2 & 0xFFFFFFFFFFFFFF3FLL); /*0x1031303aa*/
      result = a2 + 4; /*0x1031303ad*/
      break; /*0x1031303b1*/
  }
  return result; /*0x1031303ca*/
}

// Address: 0x1031303dc | Name: _nghttp3_get_varintlen
__int64 __fastcall nghttp3_get_varintlen(_BYTE *a1)
{
  return 1LL << (*a1 >> 6); /*0x1031303ee*/
}

// Address: 0x1031303f0 | Name: _nghttp3_put_uint64be
__int64 __fastcall nghttp3_put_uint64be(__int64 a1, unsigned __int64 a2)
{
  unsigned __int64 v3; // [rsp+8h] [rbp-8h] BYREF

  v3 = _byteswap_uint64(a2); /*0x1031303ff*/
  return nghttp3_cpymem(a1, a2: &v3, a3: 8); /*0x10313040f*/
}

// Address: 0x103130415 | Name: _nghttp3_put_uint32be
__int64 __fastcall nghttp3_put_uint32be(__int64 a1, unsigned int a2)
{
  unsigned __int32 v3; // [rsp+Ch] [rbp-4h] BYREF

  v3 = _byteswap_ulong(a2); /*0x103130423*/
  return nghttp3_cpymem(a1, a2: &v3, a3: 4); /*0x103130432*/
}

// Address: 0x103130438 | Name: _nghttp3_put_uint16be
__int64 __fastcall nghttp3_put_uint16be(__int64 a1, __int16 a2)
{
  __int16 v3; // [rsp+Eh] [rbp-2h] BYREF

  v3 = __ROL2__(a2, 8); /*0x103130448*/
  return nghttp3_cpymem(a1, a2: &v3, a3: 2); /*0x103130458*/
}

// Address: 0x10313045e | Name: _nghttp3_put_varint
__int64 __fastcall nghttp3_put_varint(_BYTE *a1, __int64 a2)
{
  __int64 result; // rax
  unsigned __int64 v4; // [rsp+8h] [rbp-18h] BYREF
  unsigned __int32 v5; // [rsp+10h] [rbp-10h] BYREF
  _WORD v6[5]; // [rsp+16h] [rbp-Ah] BYREF

  if ( a2 > 63 ) /*0x10313046e*/
  {
    if ( (unsigned __int64)a2 > 0x3FFF ) /*0x10313047d*/
    {
      if ( (unsigned __int64)a2 > 0x3FFFFFFF ) /*0x1031304aa*/
      {
        v4 = _byteswap_uint64(a2); /*0x1031304d4*/
        result = nghttp3_cpymem(a1, a2: &v4, a3: 8); /*0x1031304e2*/
        LOBYTE(a2) = *a1 | 0xC0; /*0x1031304ea*/
      }
      else
      {
        v5 = _byteswap_ulong(a2); /*0x1031304b2*/
        result = nghttp3_cpymem(a1, a2: &v5, a3: 4); /*0x1031304bf*/
        LOBYTE(a2) = *a1 | 0x80; /*0x1031304c7*/
      }
    }
    else
    {
      v6[0] = __ROL2__(a2, 8); /*0x103130487*/
      result = nghttp3_cpymem(a1, a2: v6, a3: 2); /*0x103130495*/
      LOBYTE(a2) = *a1 | 0x40; /*0x10313049d*/
    }
  }
  else
  {
    result = (__int64)(a1 + 1); /*0x103130470*/
  }
  *a1 = a2; /*0x1031304ee*/
  return result; /*0x1031304f1*/
}

// Address: 0x1031304f8 | Name: _nghttp3_put_varintlen
__int64 __fastcall nghttp3_put_varintlen(__int64 a1)
{
  __int64 result; // rax

  result = 1; /*0x1031304fc*/
  if ( a1 >= 64 ) /*0x103130505*/
  {
    result = 2; /*0x103130507*/
    if ( (unsigned __int64)a1 >= 0x4000 ) /*0x103130513*/
      return 4LL * ((unsigned __int64)a1 >= 0x40000000) + 4; /*0x103130521*/
  }
  return result; /*0x103130529*/
}

// Address: 0x10313052b | Name: _nghttp3_ord_stream_id
__int64 __fastcall nghttp3_ord_stream_id(__int64 a1)
{
  return (a1 >> 2) + 1; /*0x103130537*/
}

// Address: 0x10313053c | Name: _nghttp3_strerror
const char *__fastcall nghttp3_strerror(int a1)
{
  const char *result; // rax

  if ( a1 <= -403 ) /*0x103130546*/
  {
    if ( a1 <= -611 ) /*0x103130572*/
    {
      if ( a1 == -902 ) /*0x1031305c5*/
      {
        return "ERR_CALLBACK_FAILURE"; /*0x103130664*/
      }
      else if ( a1 == -901 ) /*0x1031305d1*/
      {
        return "ERR_NOMEM"; /*0x1031305d7*/
      }
      else
      {
        return "(unknown)"; /*0x1031306d9*/
      }
    }
    else
    {
      switch ( a1 ) /*0x10313058d*/
      {
        case -610: /*0x10313058d*/
          result = "ERR_H3_EXCESSIVE_LOAD"; /*0x10313058f*/
          break; /*0x103130596*/
        case -609: /*0x10313058d*/
          result = "ERR_H3_STREAM_CREATION_ERROR"; /*0x103130676*/
          break; /*0x10313067d*/
        case -608: /*0x10313058d*/
          result = "ERR_H3_SETTINGS_ERROR"; /*0x10313062b*/
          break; /*0x103130632*/
        case -607: /*0x10313058d*/
          result = "ERR_H3_ID_ERROR"; /*0x10313064f*/
          break; /*0x103130656*/
        case -606: /*0x10313058d*/
          result = "ERR_H3_GENERAL_PROTOCOL_ERROR"; /*0x1031305fb*/
          break; /*0x103130602*/
        case -605: /*0x10313058d*/
          result = "ERR_CLOSED_CRITICAL_STREAM"; /*0x103130691*/
          break; /*0x103130698*/
        case -604: /*0x10313058d*/
          result = "ERR_H3_INTERNAL_ERROR"; /*0x1031306a3*/
          break; /*0x1031306aa*/
        case -603: /*0x10313058d*/
          result = "ERR_H3_MISSING_SETTINGS"; /*0x10313065b*/
          break; /*0x103130662*/
        case -602: /*0x10313058d*/
          result = "ERR_H3_FRAME_ERROR"; /*0x1031306ac*/
          break; /*0x1031306b3*/
        case -601: /*0x10313058d*/
          result = "ERR_H3_FRAME_UNEXPECTED"; /*0x103130613*/
          break; /*0x10313061a*/
        default:
          if ( a1 != -403 ) /*0x1031305e9*/
            return "(unknown)"; /*0x1031305e9*/
          result = "ERR_QPACK_DECODER_STREAM_ERROR"; /*0x1031305ef*/
          break; /*0x1031305f6*/
      }
    }
  }
  else
  {
    switch ( a1 ) /*0x10313055e*/
    {
      case -112: /*0x10313055e*/
        result = "ERR_STREAM_DATA_OVERFLOW"; /*0x103130560*/
        break; /*0x103130567*/
      case -111: /*0x10313055e*/
        result = "ERR_CONN_CLOSING"; /*0x10313069a*/
        break; /*0x1031306a1*/
      case -110: /*0x10313055e*/
        result = "ERR_STREAM_NOT_FOUND"; /*0x10313066d*/
        break; /*0x103130674*/
      case -109: /*0x10313055e*/
        result = "ERR_QPACK_HEADER_TOO_LARGE"; /*0x10313067f*/
        break; /*0x103130686*/
      case -108: /*0x10313055e*/
        result = "ERR_QPACK_FATAL"; /*0x10313061f*/
        break; /*0x103130626*/
      case -107: /*0x10313055e*/
        result = "ERR_MALFORMED_HTTP_MESSAGING"; /*0x1031306b5*/
        break; /*0x1031306bc*/
      case -106: /*0x10313055e*/
        result = "ERR_REMOVE_HTTP_HEADER"; /*0x1031306be*/
        break; /*0x1031306c5*/
      case -105: /*0x10313055e*/
        result = "ERR_MALFORMED_HTTP_HEADER"; /*0x103130688*/
        break; /*0x10313068f*/
      case -104: /*0x10313055e*/
        result = "ERR_STREAM_IN_USE"; /*0x1031306d0*/
        break; /*0x1031306d7*/
      case -103: /*0x10313055e*/
        result = "ERR_WOULDBLOCK"; /*0x103130643*/
        break; /*0x10313064a*/
      case -102: /*0x10313055e*/
        result = "ERR_INVALID_STATE"; /*0x1031306c7*/
        break; /*0x1031306ce*/
      case -101: /*0x10313055e*/
        result = "ERR_INVALID_ARGUMENT"; /*0x103130607*/
        break; /*0x10313060e*/
      default:
        if ( a1 == -402 ) /*0x1031305a1*/
        {
          result = "ERR_QPACK_ENCODER_STREAM_ERROR"; /*0x103130637*/
        }
        else
        {
          if ( a1 != -401 ) /*0x1031305ad*/
            return "(unknown)"; /*0x1031305ad*/
          result = "ERR_QPACK_DECOMPRESSION_FAILED"; /*0x1031305b3*/
        }
        break; /*0x1031305ba*/
    }
  }
  return result; /*0x1031306e0*/
}

// Address: 0x10313073c | Name: _nghttp3_err_infer_quic_app_error_code
__int64 __fastcall nghttp3_err_infer_quic_app_error_code(int a1)
{
  __int64 result; // rax
  unsigned int v2; // eax
  int v3; // ecx
  int v4; // ecx

  if ( a1 <= -404 ) /*0x103130746*/
  {
    switch ( a1 ) /*0x103130761*/
    {
      case -610: /*0x103130761*/
        result = 263; /*0x103130763*/
        break; /*0x103130768*/
      case -609: /*0x103130761*/
        result = 259; /*0x1031307e4*/
        break; /*0x1031307e9*/
      case -608: /*0x103130761*/
        result = 265; /*0x1031307d6*/
        break; /*0x1031307db*/
      case -607: /*0x103130761*/
        result = 264; /*0x1031307f2*/
        break; /*0x1031307f7*/
      case -606: /*0x103130761*/
        return 257;
      case -605: /*0x103130761*/
        result = 260; /*0x103130800*/
        break; /*0x103130805*/
      case -604: /*0x103130761*/
        return 258;
      case -603: /*0x103130761*/
        result = 266; /*0x1031307eb*/
        break; /*0x1031307f0*/
      case -602: /*0x103130761*/
        result = 262; /*0x10313080e*/
        break; /*0x10313080e*/
      case -601: /*0x103130761*/
        result = 261; /*0x1031307dd*/
        break; /*0x1031307e2*/
      default:
        if ( (unsigned int)(a1 + 902) < 2 ) /*0x1031307bd*/
          return 258; /*0x1031307bd*/
        return 257; /*0x1031307bd*/
    }
    return result; /*0x1031307e2*/
  }
  if ( a1 <= -113 ) /*0x103130770*/
  {
    switch ( a1 ) /*0x10313079b*/
    {
      case -403: /*0x10313079b*/
        return 514; /*0x1031307fe*/
      case -402: /*0x10313079b*/
        return 513; /*0x10313080c*/
      case -401: /*0x10313079b*/
        return 512; /*0x1031307b2*/
      default:
        break; /*0x1031307d4*/
    }
    return 257; /*0x1031307d4*/
  }
  v2 = a1 + 112; /*0x103130772*/
  if ( (unsigned int)(a1 + 112) <= 7 ) /*0x103130778*/
  {
    v3 = 25; /*0x10313077a*/
    if ( _bittest(&v3, v2) ) /*0x103130782*/
      return 258; /*0x1031307c4*/
    v4 = 160; /*0x103130784*/
    if ( _bittest(&v4, v2) ) /*0x103130789*/
      return 270; /*0x103130793*/
  }
  result = 256; /*0x1031307c6*/
  if ( a1 != 0 ) /*0x1031307cd*/
    return 257; /*0x1031307cd*/
  return result; /*0x103130813*/
}

// Address: 0x103130840 | Name: _nghttp3_err_is_fatal
_BOOL8 __fastcall nghttp3_err_is_fatal(int a1)
{
  return a1 < -900; /*0x10313084f*/
}

// Address: 0x103130851 | Name: _nghttp3_frame_write_hd
__int64 __fastcall nghttp3_frame_write_hd(_BYTE *a1, __int64 a2, __int64 a3)
{
  _BYTE *v4; // rax

  v4 = (_BYTE *)nghttp3_put_varint(a1, a2); /*0x10313085a*/
  return nghttp3_put_varint(a1: v4, a2: a3); /*0x103130869*/
}

// Address: 0x103130870 | Name: _nghttp3_frame_write_hd_len
__int64 __fastcall nghttp3_frame_write_hd_len(__int64 a1, __int64 a2)
{
  __int64 v3; // r14

  v3 = nghttp3_put_varintlen(a1); /*0x10313087f*/
  return v3 + nghttp3_put_varintlen(a1: a2); /*0x10313088d*/
}

// Address: 0x103130892 | Name: _nghttp3_frame_write_settings
_BYTE *__fastcall nghttp3_frame_write_settings(_BYTE *a1, __int64 *a2, __int64 a3)
{
  _BYTE *v5; // rax
  _BYTE *result; // rax
  __int64 v7; // r14
  unsigned __int64 v8; // r15
  _BYTE *v9; // rax

  v5 = (_BYTE *)nghttp3_put_varint(a1, a2: *a2); /*0x1031308a5*/
  result = (_BYTE *)nghttp3_put_varint(a1: v5, a2: a3); /*0x1031308b0*/
  if ( a2[1] != 0 ) /*0x1031308ba*/
  {
    v7 = 0; /*0x1031308bc*/
    v8 = 0; /*0x1031308bf*/
    do /*0x1031308ee*/
    {
      v9 = (_BYTE *)nghttp3_put_varint(a1: result, a2: *(_QWORD *)(a2[2] + v7)); /*0x1031308cd*/
      result = (_BYTE *)nghttp3_put_varint(a1: v9, a2: *(_QWORD *)(a2[2] + v7 + 8)); /*0x1031308de*/
      ++v8; /*0x1031308e3*/
      v7 += 16; /*0x1031308e6*/
    }
    while ( v8 < a2[1] ); /*0x1031308ee*/
  }
  return result; /*0x1031308f4*/
}

// Address: 0x1031308fb | Name: _nghttp3_frame_write_settings_len
__int64 __fastcall nghttp3_frame_write_settings_len(__int64 *a1, __int64 a2)
{
  __int64 v3; // r12
  unsigned __int64 v4; // r13
  __int64 v5; // rbx
  __int64 v6; // r15
  __int64 v7; // r15
  __int64 v8; // rbx

  if ( *(_QWORD *)(a2 + 8) != 0 ) /*0x103130912*/
  {
    v3 = 0; /*0x103130917*/
    v4 = 0; /*0x10313091a*/
    v5 = 0; /*0x10313091d*/
    do /*0x103130951*/
    {
      v6 = nghttp3_put_varintlen(a1: *(_QWORD *)(*(_QWORD *)(a2 + 16) + v3)); /*0x10313092c*/
      v7 = nghttp3_put_varintlen(a1: *(_QWORD *)(*(_QWORD *)(a2 + 16) + v3 + 8)) + v5 + v6; /*0x103130940*/
      ++v4; /*0x103130943*/
      v3 += 16; /*0x103130946*/
      v5 = v7; /*0x10313094a*/
    }
    while ( v4 < *(_QWORD *)(a2 + 8) ); /*0x103130951*/
  }
  else
  {
    v7 = 0; /*0x103130955*/
  }
  *a1 = v7; /*0x10313095c*/
  v8 = nghttp3_put_varintlen(a1: 4); /*0x103130969*/
  return v7 + v8 + nghttp3_put_varintlen(a1: v7); /*0x10313097e*/
}

// Address: 0x103130989 | Name: _nghttp3_frame_write_goaway
__int64 __fastcall nghttp3_frame_write_goaway(_BYTE *a1, __int64 *a2, __int64 a3)
{
  _BYTE *v5; // rax
  _BYTE *v6; // rax

  v5 = (_BYTE *)nghttp3_put_varint(a1, a2: *a2); /*0x103130999*/
  v6 = (_BYTE *)nghttp3_put_varint(a1: v5, a2: a3); /*0x1031309a4*/
  return nghttp3_put_varint(a1: v6, a2: a2[1]); /*0x1031309b0*/
}

// Address: 0x1031309b9 | Name: _nghttp3_frame_write_goaway_len
__int64 __fastcall nghttp3_frame_write_goaway_len(__int64 *a1, __int64 a2)
{
  __int64 v3; // r14
  __int64 v4; // rbx

  v3 = nghttp3_put_varintlen(a1: *(_QWORD *)(a2 + 8)); /*0x1031309cc*/
  *a1 = v3; /*0x1031309cf*/
  v4 = nghttp3_put_varintlen(a1: 7); /*0x1031309dc*/
  return v3 + v4 + nghttp3_put_varintlen(a1: v3); /*0x1031309ed*/
}

// Address: 0x1031309f2 | Name: _nghttp3_frame_write_priority_update
__int64 __fastcall nghttp3_frame_write_priority_update(_BYTE *a1, __int64 *a2, __int64 a3)
{
  _BYTE *v5; // rax
  _BYTE *v6; // rax
  __int64 result; // rax
  __int64 v8; // rdx

  v5 = (_BYTE *)nghttp3_put_varint(a1, a2: *a2); /*0x103130a02*/
  v6 = (_BYTE *)nghttp3_put_varint(a1: v5, a2: a3); /*0x103130a0d*/
  result = nghttp3_put_varint(a1: v6, a2: a2[1]); /*0x103130a19*/
  v8 = a2[3]; /*0x103130a1e*/
  if ( v8 != 0 ) /*0x103130a25*/
    return nghttp3_cpymem(a1: result, a2: a2[2], a3: v8); /*0x103130a32*/
  return result; /*0x103130a2e*/
}

// Address: 0x103130a3c | Name: _nghttp3_frame_write_priority_update_len
__int64 __fastcall nghttp3_frame_write_priority_update_len(__int64 *a1, __int64 *a2)
{
  __int64 v4; // r15
  __int64 v5; // rbx

  v4 = a2[3] + nghttp3_put_varintlen(a1: a2[1]); /*0x103130a58*/
  *a1 = v4; /*0x103130a5c*/
  v5 = nghttp3_put_varintlen(a1: *a2); /*0x103130a67*/
  return v4 + v5 + nghttp3_put_varintlen(a1: v4); /*0x103130a7c*/
}

// Address: 0x103130a83 | Name: _nghttp3_frame_write_origin
__int64 __fastcall nghttp3_frame_write_origin(_BYTE *a1, __int64 *a2, __int64 a3)
{
  _BYTE *v5; // rax
  __int64 result; // rax
  __int64 v7; // rdx

  v5 = (_BYTE *)nghttp3_put_varint(a1, a2: *a2); /*0x103130a93*/
  result = nghttp3_put_varint(a1: v5, a2: a3); /*0x103130a9e*/
  v7 = a2[2]; /*0x103130aa3*/
  if ( v7 != 0 ) /*0x103130aaa*/
    return nghttp3_cpymem(a1: result, a2: a2[1], a3: v7); /*0x103130ab7*/
  return result; /*0x103130ab3*/
}

// Address: 0x103130ac1 | Name: _nghttp3_frame_write_origin_len
__int64 __fastcall nghttp3_frame_write_origin_len(__int64 *a1, __int64 *a2)
{
  __int64 v2; // rbx
  __int64 v3; // r14

  v2 = a2[2]; /*0x103130ac8*/
  *a1 = v2; /*0x103130acc*/
  v3 = nghttp3_put_varintlen(a1: *a2); /*0x103130ad7*/
  return v2 + v3 + nghttp3_put_varintlen(a1: v2); /*0x103130ae8*/
}

// Address: 0x103130aed | Name: _nghttp3_nva_copy
__int64 __fastcall nghttp3_nva_copy(__int64 *a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5)
{
  __int64 v6; // rbx
  _BYTE *v8; // rax
  __int64 v9; // rsi
  __int64 v10; // rax
  __int64 v11; // r12
  char *v12; // r15
  __int64 v13; // r13
  char v14; // al
  size_t v15; // rdx
  __int64 v16; // rax
  size_t v17; // rdx
  __int64 v18; // rax

  if ( a3 == 0 ) /*0x103130b01*/
  {
    *a1 = 0; /*0x103130c3b*/
    return 0; /*0x103130c45*/
  }
  v6 = a3; /*0x103130b07*/
  v8 = (_BYTE *)(a2 + 32); /*0x103130b0d*/
  v9 = 0; /*0x103130b11*/
  do /*0x103130b3d*/
  {
    if ( (*v8 & 2) == 0 ) /*0x103130b1a*/
    {
      a5 = *((_QWORD *)v8 - 2); /*0x103130b1c*/
      v9 += a5 + 1; /*0x103130b23*/
    }
    if ( (*v8 & 4) == 0 ) /*0x103130b2a*/
      v9 += *((_QWORD *)v8 - 1) + 1LL; /*0x103130b33*/
    v8 += 40; /*0x103130b36*/
    --a3; /*0x103130b3a*/
  }
  while ( a3 != 0 ); /*0x103130b3d*/
  v10 = nghttp3_mem_malloc(a1: a4, a2: 40 * v6 + v9, a3: 0, a4, a5); /*0x103130b51*/
  *a1 = v10; /*0x103130b56*/
  if ( v10 != 0 ) /*0x103130b5d*/
  {
    v11 = v10; /*0x103130b63*/
    v12 = (char *)(v10 + 40 * v6); /*0x103130b66*/
    v13 = 0; /*0x103130b69*/
    do /*0x103130c33*/
    {
      v14 = *(_BYTE *)(a2 + v13 + 32); /*0x103130b6c*/
      *(_BYTE *)(v11 + v13 + 32) = v14; /*0x103130b71*/
      if ( (v14 & 2) != 0 ) /*0x103130b78*/
      {
        *(_QWORD *)(v11 + v13) = *(_QWORD *)(a2 + v13); /*0x103130ba8*/
        *(_QWORD *)(v11 + v13 + 16) = *(_QWORD *)(a2 + v13 + 16); /*0x103130bb1*/
      }
      else
      {
        v15 = *(_QWORD *)(a2 + v13 + 16); /*0x103130b7a*/
        if ( v15 != 0 ) /*0x103130b82*/
        {
          memcpy(__dst: v12, __src: *(const void **)(a2 + v13), __n: v15); /*0x103130b8b*/
          nghttp3_downcase(a1: v12, a2: *(_QWORD *)(a2 + v13 + 16)); /*0x103130b98*/
          v16 = *(_QWORD *)(a2 + v13 + 16); /*0x103130b9d*/
        }
        else
        {
          v16 = 0; /*0x103130bb8*/
        }
        *(_QWORD *)(v11 + v13) = v12; /*0x103130bba*/
        *(_QWORD *)(v11 + v13 + 16) = v16; /*0x103130bbe*/
        v12[v16] = 0; /*0x103130bc3*/
        v12 += *(_QWORD *)(a2 + v13 + 16) + 1; /*0x103130bd0*/
        v14 = *(_BYTE *)(a2 + v13 + 32); /*0x103130bd3*/
      }
      if ( (v14 & 4) != 0 ) /*0x103130bda*/
      {
        *(_QWORD *)(v11 + v13 + 8) = *(_QWORD *)(a2 + v13 + 8); /*0x103130bff*/
        *(_QWORD *)(v11 + v13 + 24) = *(_QWORD *)(a2 + v13 + 24); /*0x103130c09*/
      }
      else
      {
        v17 = *(_QWORD *)(a2 + v13 + 24); /*0x103130bdc*/
        if ( v17 != 0 ) /*0x103130be4*/
        {
          memcpy(__dst: v12, __src: *(const void **)(a2 + v13 + 8), __n: v17); /*0x103130bee*/
          v18 = *(_QWORD *)(a2 + v13 + 24); /*0x103130bf3*/
        }
        else
        {
          v18 = 0; /*0x103130c10*/
        }
        *(_QWORD *)(v11 + v13 + 8) = v12; /*0x103130c12*/
        *(_QWORD *)(v11 + v13 + 24) = v18; /*0x103130c17*/
        v12[v18] = 0; /*0x103130c1c*/
        v12 += *(_QWORD *)(a2 + v13 + 24) + 1; /*0x103130c29*/
      }
      v13 += 40; /*0x103130c2c*/
      --v6; /*0x103130c30*/
    }
    while ( v6 != 0 ); /*0x103130c33*/
    return 0; /*0x103130c33*/
  }
  return 4294966395LL; /*0x103130c50*/
}

// Address: 0x103130c5b | Name: _nghttp3_nva_del
__int64 __fastcall nghttp3_nva_del(__int64 a1, __int64 a2)
{
  return nghttp3_mem_free(a1: a2, a2: a1); /*0x103130c68*/
}

// Address: 0x103130c6e | Name: _nghttp3_frame_headers_free
__int64 __fastcall nghttp3_frame_headers_free(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  if ( a1 != 0 ) /*0x103130c75*/
    return nghttp3_mem_free(a1: a2, a2: *(_QWORD *)(a1 + 8)); /*0x103130c82*/
  return result; /*0x103130c81*/
}

// Address: 0x103130c89 | Name: _nghttp3_frame_priority_update_free
__int64 __fastcall nghttp3_frame_priority_update_free(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  if ( a1 != 0 ) /*0x103130c90*/
    return nghttp3_mem_free(a1: a2, a2: *(_QWORD *)(a1 + 16)); /*0x103130c9d*/
  return result; /*0x103130c9c*/
}

// Address: 0x103130ca4 | Name: _nghttp3_gaptr_init
__int64 __fastcall nghttp3_gaptr_init(__int64 a1, __int64 a2)
{
  __int64 result; // rax

  result = nghttp3_ksl_init(a1, a2: nghttp3_ksl_range_compar, a3: nghttp3_ksl_range_search, a4: 16, a5: a2); /*0x103130cc7*/
  *(_QWORD *)(a1 + 128) = a2; /*0x103130ccc*/
  return result; /*0x103130cd3*/
}

// Address: 0x103130cd8 | Name: _nghttp3_gaptr_free
__int64 __fastcall nghttp3_gaptr_free(__int64 a1)
{
  __int64 result; // rax

  if ( a1 != 0 ) /*0x103130cdf*/
    return nghttp3_ksl_free(); /*0x103130ce2*/
  return result; /*0x103130ce1*/
}

// Address: 0x103130ce9 | Name: _nghttp3_gaptr_push
__int64 __fastcall nghttp3_gaptr_push(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v3; // rax
  __int64 v4; // rdx
  __int64 v5; // rdx
  __int64 result; // rax
  __int64 v7; // rcx
  _BYTE v8[16]; // [rsp+0h] [rbp-90h] BYREF
  _BYTE v9[16]; // [rsp+10h] [rbp-80h] BYREF
  __int128 v10; // [rsp+20h] [rbp-70h] BYREF
  _QWORD v11[2]; // [rsp+30h] [rbp-60h] BYREF
  _QWORD v12[2]; // [rsp+40h] [rbp-50h] BYREF
  __int64 v13; // [rsp+50h] [rbp-40h] BYREF
  __int64 v14; // [rsp+58h] [rbp-38h]
  __int64 v15; // [rsp+60h] [rbp-30h]

  v12[0] = a2; /*0x103130cfa*/
  v12[1] = a2 + a3; /*0x103130d01*/
  v15 = a1; /*0x103130d05*/
  if ( nghttp3_ksl_len(a1) != 0 /*0x103130ead*/
    || (*(_QWORD *)&v10 = 0,
        *((_QWORD *)&v10 + 1) = -1,
        (_DWORD)(result = nghttp3_ksl_insert(a1: v15, a2: 0, a3: &v10, a4: 0)) == 0) )
  {
    v3 = nghttp3_ksl_lower_bound_search(a1: v15, a2: v12, a3: nghttp3_ksl_range_exclusive_search); /*0x103130d26*/
    v13 = v3; /*0x103130d2f*/
    v14 = v4; /*0x103130d32*/
    while ( v4 != *(_DWORD *)(v3 + 280) || *(_QWORD *)v3 != 0 ) /*0x103130d52*/
    {
      v10 = *(_OWORD *)(*(_QWORD *)(v3 + 272) + *(unsigned __int16 *)(v3 + 284) * v4); /*0x103130d74*/
      v11[0] = nghttp3_range_intersect(a1: v12, a2: &v10); /*0x103130d84*/
      v11[1] = v5; /*0x103130d88*/
      if ( nghttp3_range_len(a1: v11) == 0 ) /*0x103130d97*/
        break; /*0x103130d97*/
      if ( (unsigned int)nghttp3_range_eq(a1: &v10, a2: v11) != 0 ) /*0x103130daa*/
      {
        nghttp3_ksl_remove_hint(a1: v15, a2: &v13, a3: &v13, a4: &v10); /*0x103130db9*/
        v3 = v13; /*0x103130dbe*/
        v4 = v14; /*0x103130dc2*/
      }
      else
      {
        nghttp3_range_cut(a1: v8, a2: v9, a3: &v10, a4: v11); /*0x103130dd7*/
        if ( nghttp3_range_len(a1: v8) != 0 ) /*0x103130de7*/
        {
          nghttp3_ksl_update_key(a1: v15, a2: &v10, a3: v8); /*0x103130df3*/
          if ( nghttp3_range_len(a1: v9) != 0 ) /*0x103130e07*/
          {
            result = nghttp3_ksl_insert(a1: v15, a2: &v13, a3: v9, a4: 0); /*0x103130e15*/
            if ( (_DWORD)result != 0 ) /*0x103130e1c*/
              return result; /*0x103130e1c*/
          }
        }
        else if ( nghttp3_range_len(a1: v9) != 0 ) /*0x103130e32*/
        {
          nghttp3_ksl_update_key(a1: v15, a2: &v10, a3: v9); /*0x103130e3e*/
        }
        v3 = v13; /*0x103130e43*/
        v4 = v14 + 1; /*0x103130e4b*/
        v14 = v4; /*0x103130e4e*/
        if ( v4 == *(_DWORD *)(v13 + 280) ) /*0x103130e5f*/
        {
          v7 = *(_QWORD *)v13; /*0x103130e65*/
          if ( *(_QWORD *)v13 != 0 ) /*0x103130e6b*/
          {
            v13 = *(_QWORD *)v13; /*0x103130e71*/
            v14 = 0; /*0x103130e75*/
            v4 = 0; /*0x103130e7d*/
            v3 = v7; /*0x103130e7f*/
          }
        }
      }
    }
    return 0; /*0x103130e87*/
  }
  return result; /*0x103130eb3*/
}

// Address: 0x103130ec2 | Name: _nghttp3_gaptr_first_gap_offset
__int64 __fastcall nghttp3_gaptr_first_gap_offset(__int64 a1)
{
  __int64 v2; // rax
  __int64 v3; // rdx

  if ( nghttp3_ksl_len(a1) == 0 ) /*0x103130ed3*/
    return 0; /*0x103130ef5*/
  v2 = nghttp3_ksl_begin(a1); /*0x103130ed8*/
  return *(_QWORD *)(*(_QWORD *)(v2 + 272) + v3 * *(unsigned __int16 *)(v2 + 284)); /*0x103130efb*/
}

// Address: 0x103130efe | Name: _nghttp3_gaptr_get_first_gap_after
__int64 __fastcall nghttp3_gaptr_get_first_gap_after(__int64 a1, __int64 a2)
{
  __int64 v4; // rax
  __int64 v5; // rdx
  _QWORD v7[4]; // [rsp+0h] [rbp-20h] BYREF

  if ( nghttp3_ksl_len(a1) == 0 ) /*0x103130f17*/
    return 0; /*0x103130f5a*/
  v7[0] = a2; /*0x103130f1d*/
  v7[1] = a2 + 1; /*0x103130f23*/
  v4 = nghttp3_ksl_lower_bound_search(a1, a2: v7, a3: nghttp3_ksl_range_exclusive_search); /*0x103130f31*/
  return *(_QWORD *)(*(_QWORD *)(v4 + 272) + v5 * *(unsigned __int16 *)(v4 + 284)); /*0x103130f5c*/
}

// Address: 0x103130f65 | Name: _nghttp3_gaptr_is_pushed
_BOOL8 __fastcall nghttp3_gaptr_is_pushed(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rax
  __int64 v5; // rdx
  __int64 v6; // rdx
  _QWORD v8[2]; // [rsp+0h] [rbp-30h] BYREF
  _QWORD v9[4]; // [rsp+10h] [rbp-20h] BYREF

  v9[0] = a2; /*0x103130f73*/
  v9[1] = a2 + a3; /*0x103130f7a*/
  if ( nghttp3_ksl_len(a1) == 0 ) /*0x103130f86*/
    return false; /*0x103130fd5*/
  v4 = nghttp3_ksl_lower_bound_search(a1, a2: v9, a3: nghttp3_ksl_range_exclusive_search); /*0x103130f99*/
  v8[0] = nghttp3_range_intersect(a1: v9, a2: *(_QWORD *)(v4 + 272) + v5 * *(unsigned __int16 *)(v4 + 284)); /*0x103130fbc*/
  v8[1] = v6; /*0x103130fbf*/
  return nghttp3_range_len(a1: v8) == 0; /*0x103130fd7*/
}

// Address: 0x103130fe0 | Name: _nghttp3_gaptr_drop_first_gap
__int64 __fastcall nghttp3_gaptr_drop_first_gap(__int64 a1)
{
  __int64 result; // rax
  __int64 v3; // rdx
  _QWORD v4[2]; // [rsp+0h] [rbp-30h] BYREF
  __int128 v5; // [rsp+10h] [rbp-20h] BYREF

  result = nghttp3_ksl_len(a1); /*0x103130fec*/
  if ( result != 0 ) /*0x103130ff4*/
  {
    v4[0] = nghttp3_ksl_begin(a1); /*0x103131002*/
    v4[1] = v3; /*0x103131005*/
    v5 = *(_OWORD *)(*(_QWORD *)(v4[0] + 272LL) + v3 * *(unsigned __int16 *)(v4[0] + 284LL)); /*0x103131023*/
    return nghttp3_ksl_remove_hint(a1, a2: 0, a3: v4, a4: &v5); /*0x10313102e*/
  }
  return result; /*0x103131033*/
}

// Address: 0x10313103c | Name: _nghttp3_http_parse_priority
__int64 __fastcall nghttp3_http_parse_priority(unsigned int *a1)
{
  char *v2; // r13
  int v3; // eax
  int v4; // eax
  __int64 result; // rax
  _BYTE v6[24]; // [rsp+8h] [rbp-78h] BYREF
  _QWORD v7[2]; // [rsp+20h] [rbp-60h] BYREF
  int v8; // [rsp+30h] [rbp-50h] BYREF
  unsigned __int64 v9; // [rsp+38h] [rbp-48h]
  unsigned __int64 v10; // [rsp+48h] [rbp-38h]
  __int16 v11; // [rsp+54h] [rbp-2Ch]
  char v12; // [rsp+56h] [rbp-2Ah]
  char v13; // [rsp+57h] [rbp-29h]

  v10 = *a1; /*0x103131052*/
  v13 = *((_BYTE *)a1 + 4); /*0x103131059*/
  v2 = (char *)a1 + 5; /*0x10313105c*/
  v12 = *((_BYTE *)a1 + 7); /*0x103131063*/
  v11 = *(_WORD *)((char *)a1 + 5); /*0x10313106a*/
  sfparse_parser_init(a1: v6); /*0x103131075*/
  while ( 1 ) /*0x10313108b*/
  {
    v3 = sfparse_parser_dict(a1: v6, a2: v7, a3: &v8); /*0x10313108b*/
    if ( v3 != 0 ) /*0x103131092*/
      break; /*0x103131092*/
    if ( v7[1] == 1 ) /*0x103131099*/
    {
      v4 = *(unsigned __int8 *)v7[0]; /*0x10313109f*/
      if ( v4 == 117 ) /*0x1031310a5*/
      {
        result = 4294967195LL; /*0x1031310be*/
        if ( v8 != 1 || v9 > 7 ) /*0x1031310cd*/
          return result; /*0x1031310cd*/
        v10 = v9; /*0x1031310cf*/
      }
      else if ( v4 == 105 ) /*0x1031310aa*/
      {
        if ( v8 != 0 ) /*0x1031310b0*/
          return 4294967195LL; /*0x1031310b0*/
        v13 = v9; /*0x1031310b5*/
      }
    }
  }
  if ( v3 == -2 ) /*0x1031310d8*/
  {
    *a1 = v10; /*0x1031310de*/
    *((_BYTE *)a1 + 4) = v13; /*0x1031310e3*/
    v2[2] = v12; /*0x1031310e9*/
    *(_WORD *)v2 = v11; /*0x1031310f1*/
    return 0; /*0x1031310f8*/
  }
  return 4294967195LL; /*0x1031310ff*/
}

// Address: 0x10313110e | Name: _nghttp3_pri_parse_priority_versioned
__int64 __fastcall nghttp3_pri_parse_priority_versioned(__int64 a1, unsigned int *a2)
{
  return nghttp3_http_parse_priority(a1: a2); /*0x10313111b*/
}

// Address: 0x103131121 | Name: _nghttp3_http_on_header
__int64 __fastcall nghttp3_http_on_header(__int64 a1, __int64 a2, int a3, int a4, int a5)
{
  __int64 v5; // rax
  __int64 v8; // rcx
  _BYTE *v9; // rax
  unsigned int v10; // r14d
  int v11; // r13d
  __int64 v13; // rdi
  int v14; // r10d
  __int64 v15; // rcx
  __int64 v16; // rax
  __int64 v17; // rcx
  __int64 v18; // rdx
  int v19; // r13d
  int v20; // ecx
  __int64 v21; // rax
  __int64 v22; // rax
  __int64 v23; // rcx
  char v24; // di
  __int64 v25; // rcx
  __int64 v26; // rax
  __int64 v27; // rcx
  __int64 v28; // rdx
  int v29; // eax
  __int64 v30; // rax
  char v31; // al
  char v32; // cl
  __int64 v33; // rax
  __int64 v34; // rax
  __int64 v35; // rcx
  _BYTE *v36; // rax
  __int64 v37; // rcx
  __int64 v38; // rax
  char *v39; // rcx
  __int64 v40; // rdx
  char v41; // cl
  __int64 v42; // rax
  __int64 v43; // rcx
  __int64 v44; // rax
  __int64 v45; // rdx
  __int64 v46; // rax
  __int64 v47; // r15
  __int64 v48; // rax
  __int64 v49; // rax
  __int64 v50; // rcx
  char v51; // di
  __int64 v52; // rax
  __int64 v53; // rcx
  __int64 v54; // rax
  __int64 v55; // rdx
  __int64 v56; // rcx
  __int64 v57; // rcx
  __int64 v58; // r8
  __int64 v59; // rdx
  __int64 v60; // rsi
  unsigned int v61; // edi
  __int64 v62; // rcx
  char v63; // di
  int v64; // ecx
  __int64 v65; // rcx
  char v66; // di
  unsigned int v67[12]; // [rsp+0h] [rbp-30h] BYREF

  *(_QWORD *)v67 = v5; /*0x10313112e*/
  v8 = *(_QWORD *)(*(_QWORD *)a2 + 16LL); /*0x103131138*/
  if ( v8 == 0 ) /*0x10313113f*/
  {
    *(_BYTE *)(a1 + 28) |= 0x40u; /*0x103131167*/
    return (unsigned int)-106; /*0x10313116b*/
  }
  v9 = *(_BYTE **)(*(_QWORD *)a2 + 8LL); /*0x103131141*/
  if ( *v9 == 58 ) /*0x103131148*/
  {
    v10 = -105; /*0x10313114a*/
    if ( a4 != 0 ) /*0x103131153*/
      return v10; /*0x103131153*/
    if ( *(_DWORD *)(a2 + 16) == -1 ) /*0x103131159*/
      return v10; /*0x103131159*/
    v11 = *(_DWORD *)(a1 + 28); /*0x10313115b*/
    if ( (v11 & 0x40) != 0 ) /*0x103131163*/
      return v10; /*0x103131163*/
  }
  else
  {
    v11 = *(_DWORD *)(a1 + 28) | 0x40; /*0x103131187*/
    *(_DWORD *)(a1 + 28) = v11; /*0x10313118b*/
    v13 = 0; /*0x10313118f*/
    while ( 1 ) /*0x10313119d*/
    {
      v14 = VALID_HD_NAME_CHARS_0[(unsigned __int8)v9[v13]]; /*0x10313119d*/
      if ( v14 != 1 ) /*0x1031311a6*/
        break; /*0x1031311a6*/
      if ( v8 == ++v13 ) /*0x1031311ae*/
        goto LABEL_17; /*0x1031311ae*/
    }
    if ( VALID_HD_NAME_CHARS_0[(unsigned __int8)v9[v13]] == 0 ) /*0x1031311b5*/
      return (unsigned int)-106; /*0x1031311b5*/
    if ( v14 == 255 ) /*0x1031311be*/
      return (unsigned int)-105; /*0x1031311be*/
  }
LABEL_17:
  if ( a3 != 0 ) /*0x1031311ca*/
  {
    v10 = -105; /*0x1031311cf*/
    switch ( *(_DWORD *)(a2 + 16) ) /*0x1031311f2*/
    {
      case 0x3E8: /*0x1031311f2*/
        v15 = *(_QWORD *)(a2 + 8); /*0x1031311f4*/
        v16 = *(_QWORD *)(v15 + 16); /*0x1031311f8*/
        if ( v16 == 0 ) /*0x1031311ff*/
          return v10; /*0x1031311ff*/
        v17 = *(_QWORD *)(v15 + 8); /*0x103131205*/
        v18 = 0; /*0x103131209*/
        while ( VALID_AUTHORITY_CHARS_1[*(unsigned __int8 *)(v17 + v18)] != 0 ) /*0x10313121a*/
        {
          if ( v16 == ++v18 ) /*0x103131226*/
          {
            v10 = -105; /*0x103131228*/
            if ( (v11 & 0x10) != 0 ) /*0x103131232*/
              return v10; /*0x103131232*/
            v19 = v11 | 0x10; /*0x103131238*/
            goto LABEL_86; /*0x10313123c*/
          }
        }
        return (unsigned int)-106; /*0x10313121a*/
      case 0x3E9: /*0x1031311f2*/
      case 0x3EA: /*0x1031311f2*/
      case 0x3EB: /*0x1031311f2*/
      case 0x3EC: /*0x1031311f2*/
      case 0x3ED: /*0x1031311f2*/
        return v10;
      case 0x3EE: /*0x1031311f2*/
        v48 = *(_QWORD *)(a2 + 8); /*0x103131578*/
        if ( *(_QWORD *)(v48 + 16) != 8 ) /*0x103131581*/
          return v10; /*0x103131581*/
        v49 = *(_QWORD *)(v48 + 8); /*0x103131587*/
        v50 = 0; /*0x10313158b*/
        while ( 1 ) /*0x1031315a6*/
        {
          v51 = *(_BYTE *)(v49 + v50) | 0x20; /*0x1031315a6*/
          if ( (unsigned __int8)(*(_BYTE *)(v49 + v50) - 65) >= 0x1Au ) /*0x1031315aa*/
            v51 = *(_BYTE *)(v49 + v50); /*0x1031315aa*/
          if ( aTrailers[v50] != v51 ) /*0x1031315b1*/
            break; /*0x1031315b1*/
          if ( ++v50 == 8 ) /*0x1031315be*/
            return 0; /*0x1031315be*/
        }
        return (unsigned int)-105; /*0x1031315b1*/
      case 0x3EF: /*0x1031311f2*/
        if ( a5 == 0 ) /*0x10313152f*/
          return v10; /*0x10313152f*/
        v46 = *(_QWORD *)(a2 + 8); /*0x103131535*/
        v47 = *(_QWORD *)(v46 + 16); /*0x10313153d*/
        if ( (unsigned int)nghttp3_check_header_value(a1: *(_QWORD *)(v46 + 8), a2: v47) == 0 /*0x103131562*/
          || v47 == 0
          || (v11 & 0x4000) != 0 )
        {
          return v10; /*0x103131562*/
        }
        v19 = v11 | 0x4000; /*0x103131568*/
        goto LABEL_86; /*0x103131568*/
      case 0x3F0: /*0x1031311f2*/
        if ( (unsigned int)nghttp3_check_header_value( /*0x1031315de*/
                             a1: *(_QWORD *)(*(_QWORD *)(a2 + 8) + 8LL),
                             a2: *(_QWORD *)(*(_QWORD *)(a2 + 8) + 16LL)) == 0 )
        {
          *(_DWORD *)(a1 + 28) = v11 & 0xFFFE7FFF | 0x10000; /*0x1031316f0*/
          return (unsigned int)-106; /*0x1031316f4*/
        }
        if ( a4 == 0 && (v11 & 0x10000) == 0 ) /*0x1031315f2*/
        {
          *(_QWORD *)v67 = *(_QWORD *)(a1 + 16); /*0x103131600*/
          if ( (unsigned int)nghttp3_http_parse_priority(a1: v67) != 0 ) /*0x103131610*/
          {
            *(_DWORD *)(a1 + 28) = *(_DWORD *)(a1 + 28) & 0xFFFE7FFF | 0x10000; /*0x103131623*/
          }
          else
          {
            *(_QWORD *)(a1 + 16) = *(_QWORD *)v67; /*0x103131835*/
            *(_BYTE *)(a1 + 29) |= 0x80u; /*0x103131839*/
          }
        }
        return 0; /*0x103131626*/
      default:
        switch ( *(_DWORD *)(a2 + 16) ) /*0x1031312d7*/
        {
          case 0: /*0x1031312d7*/
            v25 = *(_QWORD *)(a2 + 8); /*0x1031312d9*/
            v26 = *(_QWORD *)(v25 + 16); /*0x1031312dd*/
            if ( v26 == 0 ) /*0x1031312e4*/
              return v10; /*0x1031312e4*/
            v27 = *(_QWORD *)(v25 + 8); /*0x1031312ea*/
            v28 = 0; /*0x1031312ee*/
            while ( VALID_AUTHORITY_CHARS_1[*(unsigned __int8 *)(v27 + v28)] != 0 ) /*0x1031312ff*/
            {
              if ( v26 == ++v28 ) /*0x10313130b*/
              {
                v10 = -105; /*0x10313130d*/
                if ( (v11 & 1) != 0 ) /*0x103131317*/
                  return v10; /*0x103131317*/
                v19 = v11 | 1; /*0x10313131d*/
                goto LABEL_86; /*0x103131321*/
              }
            }
            return v10; /*0x1031312ff*/
          case 1: /*0x1031312d7*/
            v42 = *(_QWORD *)(a2 + 8); /*0x1031314b6*/
            v43 = *(_QWORD *)(v42 + 16); /*0x1031314ba*/
            if ( v43 == 0 ) /*0x1031314c1*/
              return v10; /*0x1031314c1*/
            v44 = *(_QWORD *)(v42 + 8); /*0x1031314c7*/
            v45 = 0; /*0x1031314cb*/
            while ( VALID_METHOD_CHARS_0[*(unsigned __int8 *)(v44 + v45)] != 0 ) /*0x1031314dc*/
            {
              if ( v43 == ++v45 ) /*0x1031314e8*/
              {
                v10 = -105; /*0x1031314ea*/
                if ( (v11 & 4) != 0 ) /*0x1031314f4*/
                  return v10; /*0x1031314f4*/
                *(_DWORD *)(a1 + 28) = v11 | 4; /*0x103131500*/
                if ( v43 != 7 ) /*0x103131507*/
                {
                  if ( v43 == 4 && *(_DWORD *)v44 == 1145128264 ) /*0x10313151d*/
                  {
                    v19 = v11 | 0x104; /*0x103131523*/
                    goto LABEL_86; /*0x10313152a*/
                  }
                  return 0; /*0x10313151d*/
                }
                v64 = *(unsigned __int8 *)(v44 + 6); /*0x103131804*/
                if ( v64 != 83 ) /*0x10313180b*/
                {
                  if ( v64 == 84 && (*(_DWORD *)v44 ^ 0x4E4E4F43 | *(_DWORD *)(v44 + 3) ^ 0x5443454E) == 0 ) /*0x103131823*/
                  {
                    v19 = v11 | 0x84; /*0x103131825*/
                    goto LABEL_86; /*0x10313182c*/
                  }
                  return 0; /*0x103131823*/
                }
                if ( (*(_DWORD *)v44 ^ 0x4954504F | *(_DWORD *)(v44 + 3) ^ 0x534E4F49) != 0 ) /*0x10313188d*/
                  return 0; /*0x10313188d*/
                v19 = v11 | 0x204; /*0x103131897*/
                goto LABEL_86; /*0x10313189e*/
              }
            }
            return v10; /*0x1031314dc*/
          case 2: /*0x1031312d7*/
          case 3: /*0x1031312d7*/
          case 4: /*0x1031312d7*/
          case 5: /*0x1031312d7*/
          case 6: /*0x1031312d7*/
          case 7: /*0x1031312d7*/
            goto LABEL_57;
          case 8: /*0x1031312d7*/
            v37 = *(_QWORD *)(a2 + 8); /*0x103131452*/
            v38 = *(_QWORD *)(v37 + 16); /*0x103131456*/
            if ( v38 == 0 ) /*0x10313145d*/
              return v10; /*0x10313145d*/
            v39 = *(char **)(v37 + 8); /*0x103131463*/
            v40 = 0; /*0x103131467*/
            while ( VALID_PATH_CHARS_0[(unsigned __int8)v39[v40]] != 0 ) /*0x103131478*/
            {
              if ( v38 == ++v40 ) /*0x103131484*/
              {
                v10 = -105; /*0x103131486*/
                if ( (v11 & 2) != 0 ) /*0x103131490*/
                  return v10; /*0x103131490*/
                *(_DWORD *)(a1 + 28) = v11 | 2; /*0x10313149c*/
                v41 = *v39; /*0x10313149f*/
                if ( v41 == 47 ) /*0x1031314a4*/
                {
                  v19 = v11 | 0x402; /*0x1031314aa*/
                  goto LABEL_86; /*0x1031314b1*/
                }
                if ( v38 == 1 && v41 == 42 ) /*0x1031317ed*/
                {
                  v19 = v11 | 0x802; /*0x1031317f8*/
                  goto LABEL_86; /*0x1031317ff*/
                }
                return 0; /*0x1031317f2*/
              }
            }
            return v10; /*0x103131478*/
          case 9: /*0x1031312d7*/
            v34 = *(_QWORD *)(a2 + 8); /*0x10313140f*/
            v35 = *(_QWORD *)(v34 + 16); /*0x103131413*/
            if ( v35 == 0 ) /*0x10313141a*/
              return v10; /*0x10313141a*/
            v36 = *(_BYTE **)(v34 + 8); /*0x103131420*/
            if ( (unsigned __int8)((*v36 & 0xDF) - 65) > 0x19u ) /*0x10313142f*/
              return v10; /*0x10313142f*/
            if ( v35 == 1 ) /*0x103131439*/
            {
              if ( (v11 & 8) != 0 ) /*0x103131443*/
                return v10; /*0x103131443*/
              v19 = v11 | 8; /*0x103131449*/
LABEL_86:
              *(_DWORD *)(a1 + 28) = v19; /*0x10313156f*/
            }
            else
            {
              v59 = 1; /*0x103131725*/
              v60 = 0x680000000000LL; /*0x10313172a*/
              do /*0x10313176e*/
              {
                v61 = (unsigned __int8)v36[v59]; /*0x103131734*/
                if ( (unsigned __int8)(v61 - 48) >= 0xAu /*0x10313175e*/
                  && (unsigned __int8)((v61 & 0xDF) - 65) >= 0x1Au
                  && (v61 > 0x2E || !_bittest64(&v60, (unsigned __int8)v36[v59])) )
                {
                  return (unsigned int)-105; /*0x103131762*/
                }
                ++v59; /*0x103131768*/
              }
              while ( v35 != v59 ); /*0x10313176e*/
              v10 = -105; /*0x103131770*/
              if ( (v11 & 8) != 0 ) /*0x10313177a*/
                return v10; /*0x10313177a*/
              *(_DWORD *)(a1 + 28) = v11 | 8; /*0x103131786*/
              if ( v35 == 4 ) /*0x10313178d*/
              {
                v65 = 0; /*0x10313183f*/
                while ( 1 ) /*0x10313185a*/
                {
                  v66 = v36[v65] | 0x20; /*0x10313185a*/
                  if ( (unsigned __int8)(v36[v65] - 65) >= 0x1Au ) /*0x10313185e*/
                    v66 = v36[v65]; /*0x10313185e*/
                  if ( aHttp_1[v65] != v66 ) /*0x103131865*/
                    break; /*0x103131865*/
                  if ( ++v65 == 4 ) /*0x10313186e*/
                  {
LABEL_142:
                    v19 = v11 | 0x1008; /*0x103131870*/
                    goto LABEL_86; /*0x103131877*/
                  }
                }
              }
              else
              {
                if ( v35 != 5 ) /*0x103131797*/
                  return 0; /*0x103131797*/
                v62 = 0; /*0x10313179d*/
                while ( 1 ) /*0x1031317b8*/
                {
                  v63 = v36[v62] | 0x20; /*0x1031317b8*/
                  if ( (unsigned __int8)(v36[v62] - 65) >= 0x1Au ) /*0x1031317bc*/
                    v63 = v36[v62]; /*0x1031317bc*/
                  if ( aHttps[v62] != v63 ) /*0x1031317c3*/
                    break; /*0x1031317c3*/
                  if ( ++v62 == 5 ) /*0x1031317d0*/
                    goto LABEL_142; /*0x1031317d0*/
                }
              }
            }
            break; /*0x103131573*/
          default:
            if ( *(_DWORD *)(a2 + 16) != 55 ) /*0x1031313a4*/
              goto LABEL_57; /*0x1031313a4*/
            v10 = -106; /*0x1031313a6*/
            if ( a4 == 0 ) /*0x1031313af*/
              goto LABEL_54; /*0x1031313af*/
            return v10; /*0x1031313af*/
        }
        break; /*0x1031313af*/
    }
    return 0; /*0x103131573*/
  }
  v20 = *(_DWORD *)(a2 + 16); /*0x103131241*/
  v10 = -105; /*0x103131244*/
  if ( v20 > 1000 ) /*0x103131250*/
  {
    if ( (unsigned int)(v20 - 1001) < 5 ) /*0x10313125f*/
      return v10; /*0x10313125f*/
    if ( v20 == 1006 ) /*0x10313126b*/
    {
      v21 = *(_QWORD *)(a2 + 8); /*0x103131271*/
      if ( *(_QWORD *)(v21 + 16) != 8 ) /*0x10313127a*/
        return v10; /*0x10313127a*/
      v22 = *(_QWORD *)(v21 + 8); /*0x103131280*/
      v23 = 0; /*0x103131284*/
      while ( 1 ) /*0x10313129f*/
      {
        v24 = *(_BYTE *)(v22 + v23) | 0x20; /*0x10313129f*/
        if ( (unsigned __int8)(*(_BYTE *)(v22 + v23) - 65) >= 0x1Au ) /*0x1031312a3*/
          v24 = *(_BYTE *)(v22 + v23); /*0x1031312a3*/
        if ( aTrailers[v23] != v24 ) /*0x1031312aa*/
          break; /*0x1031312aa*/
        if ( ++v23 == 8 ) /*0x1031312b7*/
          return 0; /*0x1031312b7*/
      }
      return (unsigned int)-105; /*0x1031312aa*/
    }
    goto LABEL_57; /*0x10313126b*/
  }
  if ( v20 == 11 ) /*0x103131329*/
  {
    if ( (v11 & 0x20) == 0 ) /*0x10313162f*/
    {
      v52 = *(_QWORD *)(a2 + 8); /*0x103131635*/
      v53 = *(_QWORD *)(v52 + 16); /*0x103131639*/
      if ( v53 != 0 ) /*0x103131640*/
      {
        *(_DWORD *)(a1 + 28) = v11 | 0x20; /*0x10313164a*/
        if ( v53 == 3 ) /*0x103131652*/
        {
          v54 = *(_QWORD *)(v52 + 8); /*0x103131658*/
          v55 = 0; /*0x10313165c*/
          v56 = 0; /*0x103131672*/
          do /*0x1031316b4*/
          {
            if ( (unsigned __int8)(*(_BYTE *)(v54 + v55) - 58) < 0xF6u /*0x1031316a4*/
              || v56 > 0x666666666666666LL
              || (v57 = 10 * v56, v58 = *(_BYTE *)(v54 + v55) & 0xF, v57 > (v58 ^ 0x3FFFFFFFFFFFFFFFLL)) )
            {
              *(_DWORD *)(a1 + 24) = -1; /*0x1031317d7*/
              return (unsigned int)-105; /*0x1031317de*/
            }
            v56 = v58 + v57; /*0x1031316aa*/
            ++v55; /*0x1031316ad*/
          }
          while ( v55 != 3 ); /*0x1031316b4*/
          *(_DWORD *)(a1 + 24) = (__int16)v56; /*0x1031316be*/
          v10 = -105; /*0x1031316d1*/
          if ( (__int16)v56 < 100 || (_DWORD)v56 << 16 == 6619136 ) /*0x1031316cc*/
            return v10; /*0x1031316d7*/
          return 0; /*0x1031316d7*/
        }
      }
    }
    return v10; /*0x103131652*/
  }
  if ( v20 != 55 ) /*0x103131332*/
  {
LABEL_57:
    if ( *v9 == 58 ) /*0x1031313eb*/
      return v10; /*0x1031313eb*/
    if ( (unsigned int)nghttp3_check_header_value( /*0x103131404*/
                         a1: *(_QWORD *)(*(_QWORD *)(a2 + 8) + 8LL),
                         a2: *(_QWORD *)(*(_QWORD *)(a2 + 8) + 16LL)) != 0 )
      return 0; /*0x103131892*/
    return (unsigned int)-106; /*0x103131404*/
  }
  v10 = -106; /*0x103131338*/
  if ( a4 != 0 ) /*0x103131341*/
    return v10; /*0x103131341*/
  v29 = *(_DWORD *)(a1 + 24); /*0x103131347*/
  if ( v29 != 204 ) /*0x10313134f*/
  {
    if ( (unsigned int)(v29 - 100) < 0x64 || (unsigned int)(v29 - 300) >= 0xFFFFFF9C && (v11 & 0x80) != 0 ) /*0x10313171a*/
      return v10; /*0x10313171a*/
LABEL_54:
    if ( *(_QWORD *)a1 == -1 ) /*0x1031313b9*/
    {
      v33 = parse_uint_0(a1: *(_QWORD *)(*(_QWORD *)(a2 + 8) + 8LL), a2: *(_QWORD *)(*(_QWORD *)(a2 + 8) + 16LL)); /*0x1031313cb*/
      *(_QWORD *)a1 = v33; /*0x1031313d0*/
      v10 = -105; /*0x1031313d3*/
      if ( v33 == -1 ) /*0x1031313dd*/
        return v10; /*0x1031313dd*/
      return 0; /*0x1031313dd*/
    }
    return (unsigned int)-105; /*0x1031311c6*/
  }
  if ( *(_QWORD *)a1 != -1 ) /*0x103131359*/
    return (unsigned int)-105; /*0x103131359*/
  v30 = *(_QWORD *)(a2 + 8); /*0x10313135f*/
  if ( *(_QWORD *)(v30 + 16) != 1 ) /*0x103131368*/
    return (unsigned int)-105; /*0x103131368*/
  v31 = **(_BYTE **)(v30 + 8); /*0x103131372*/
  v32 = v31 | 0x20; /*0x103131380*/
  if ( (unsigned __int8)(v31 - 65) >= 0x1Au ) /*0x103131383*/
    v32 = v31; /*0x103131383*/
  v10 = -105; /*0x103131386*/
  if ( v32 == 48 ) /*0x10313138f*/
  {
    *(_QWORD *)a1 = 0; /*0x103131395*/
    return (unsigned int)-106; /*0x10313139c*/
  }
  return v10; /*0x103131178*/
}

// Address: 0x1031318f0 | Name: _nghttp3_http_on_request_headers
__int64 __fastcall nghttp3_http_on_request_headers(__int64 a1)
{
  unsigned int v1; // ecx
  __int64 result; // rax
  __int16 v3; // dx

  v1 = *(_DWORD *)(a1 + 28); /*0x1031318f4*/
  if ( (v1 & 0x4080) == 0x80 ) /*0x103131903*/
  {
    result = 4294967191LL; /*0x103131908*/
    if ( (v1 & 0xB) != 1 ) /*0x103131910*/
      return result; /*0x103131910*/
    *(_QWORD *)a1 = -1; /*0x103131912*/
    return 0; /*0x103131912*/
  }
  v3 = ~(_WORD)v1; /*0x10313191f*/
  result = 4294967191LL; /*0x103131931*/
  if ( (~(_BYTE)v1 & 0xE) == 0 /*0x103131955*/
    && (v1 & 0x11) != 0
    && (((v3 & 0x81) != 0) & (unsigned __int8)(v1 >> 14)) == 0
    && ((v3 & 0xA00) == 0 || (v1 & 0x1400) != 4096) )
  {
    return 0; /*0x103131919*/
  }
  return result; /*0x103131965*/
}

// Address: 0x103131967 | Name: _nghttp3_http_on_response_headers
__int64 __fastcall nghttp3_http_on_response_headers(__int64 a1)
{
  int v1; // ecx
  __int64 result; // rax
  int v3; // eax

  v1 = *(_DWORD *)(a1 + 28); /*0x10313196b*/
  result = 4294967191LL; /*0x10313196e*/
  if ( (v1 & 0x20) != 0 ) /*0x103131976*/
  {
    v3 = *(_DWORD *)(a1 + 24); /*0x103131978*/
    if ( (unsigned int)(v3 - 100) <= 0x63 ) /*0x103131981*/
    {
      *(_DWORD *)(a1 + 28) = *(_DWORD *)(a1 + 28) & 0x380 | 0x2000; /*0x10313198f*/
      *(_QWORD *)a1 = -1; /*0x103131992*/
      *(_DWORD *)(a1 + 24) = -1; /*0x103131999*/
      return 0; /*0x1031319c8*/
    }
    *(_DWORD *)(a1 + 28) = v1 & 0xFFFFDFFF; /*0x1031319aa*/
    if ( (v1 & 0x100) != 0 || v3 == 304 || v3 == 204 ) /*0x1031319bf*/
    {
      *(_QWORD *)a1 = 0; /*0x1031319c1*/
      return 0; /*0x1031319c1*/
    }
    result = 0; /*0x1031319cc*/
    if ( (v1 & 0x80u) != 0 ) /*0x1031319d0*/
      *(_QWORD *)a1 = -1; /*0x1031319d2*/
  }
  return result; /*0x1031319ca*/
}

// Address: 0x1031319db | Name: _nghttp3_http_on_remote_end_stream
__int64 __fastcall nghttp3_http_on_remote_end_stream(__int64 a1)
{
  __int64 result; // rax
  __int64 v2; // rcx

  result = 4294967189LL; /*0x1031319df*/
  if ( (*(_BYTE *)(a1 + 645) & 0x20) == 0 ) /*0x1031319eb*/
  {
    v2 = *(_QWORD *)(a1 + 616); /*0x1031319ed*/
    if ( v2 == -1 || v2 == *(_QWORD *)(a1 + 624) ) /*0x103131a01*/
      return 0; /*0x103131a03*/
  }
  return result; /*0x103131a05*/
}

// Address: 0x103131a07 | Name: _nghttp3_http_on_data_chunk
__int64 __fastcall nghttp3_http_on_data_chunk(__int64 a1, __int64 a2)
{
  __int64 v2; // rsi
  __int64 result; // rax
  __int64 v4; // rcx

  v2 = *(_QWORD *)(a1 + 624) + a2; /*0x103131a0b*/
  *(_QWORD *)(a1 + 624) = v2; /*0x103131a12*/
  result = 4294967189LL; /*0x103131a19*/
  if ( (*(_BYTE *)(a1 + 645) & 0x20) == 0 ) /*0x103131a25*/
  {
    v4 = *(_QWORD *)(a1 + 616); /*0x103131a27*/
    if ( v2 <= v4 ) /*0x103131a33*/
      result = 0; /*0x103131a33*/
    if ( v4 == -1 ) /*0x103131a3a*/
      return 0; /*0x103131a3a*/
  }
  return result; /*0x103131a3d*/
}

// Address: 0x103131a3f | Name: _nghttp3_http_record_request_method
void __fastcall nghttp3_http_record_request_method(__int64 a1, __int64 a2, __int64 a3)
{
  _QWORD *i; // rsi
  __int64 v4; // rcx
  int v5; // eax

  if ( a3 != 0 ) /*0x103131a42*/
  {
    for ( i = (_QWORD *)(a2 + 24); ; i += 5 ) /*0x103131a48*/
    {
      if ( *(i - 1) == 7 ) /*0x103131a56*/
      {
        v4 = *(i - 3); /*0x103131a58*/
        if ( *(_BYTE *)(v4 + 6) == 100 && (*(_DWORD *)v4 ^ 0x74656D3A | *(unsigned __int16 *)(v4 + 4) ^ 0x6F68) == 0 ) /*0x103131a75*/
          break; /*0x103131a75*/
      }
      if ( --a3 == 0 ) /*0x103131a7e*/
        return; /*0x103131a7e*/
    }
    if ( *i == 4 ) /*0x103131a89*/
    {
      if ( *(_DWORD *)*(i - 2) == 1145128264 ) /*0x103131ab9*/
      {
        v5 = 256; /*0x103131abb*/
        goto LABEL_14; /*0x103131abb*/
      }
    }
    else if ( *i == 7 && (*(_DWORD *)*(i - 2) ^ 0x4E4E4F43 | *(_DWORD *)(*(i - 2) + 3LL) ^ 0x5443454E) == 0 ) /*0x103131aa6*/
    {
      v5 = 128; /*0x103131aa8*/
LABEL_14:
      *(_DWORD *)(a1 + 644) |= v5; /*0x103131ac0*/
    }
  }
}

// Address: 0x103131ac8 | Name: _nghttp3_check_header_name
__int64 __fastcall nghttp3_check_header_name(_BYTE *a1, __int64 a2)
{
  __int64 result; // rax
  __int64 v3; // rdx

  result = 0; /*0x103131ac8*/
  if ( a2 != 0 ) /*0x103131acd*/
  {
    if ( *a1 == 58 ) /*0x103131ad2*/
    {
      if ( a2 == 1 ) /*0x103131ad8*/
        return result; /*0x103131ad8*/
      ++a1; /*0x103131ada*/
      --a2; /*0x103131add*/
    }
    result = 0; /*0x103131ae4*/
    v3 = 0; /*0x103131aed*/
    while ( VALID_HD_NAME_CHARS_0[(unsigned __int8)a1[v3]] != 0 ) /*0x103131af9*/
    {
      if ( a2 == ++v3 ) /*0x103131b01*/
        return 1; /*0x103131b03*/
    }
  }
  return result; /*0x103131b09*/
}

// Address: 0x103131b0a | Name: _nghttp3_check_header_value
__int64 __fastcall nghttp3_check_header_value(unsigned __int8 *a1, __int64 a2)
{
  int v2; // ecx
  __int64 result; // rax
  int v4; // ecx
  __int64 v5; // rdx

  if ( a2 == 0 ) /*0x103131b11*/
    return 1; /*0x103131b5d*/
  if ( a2 == 1 ) /*0x103131b17*/
  {
    v2 = *a1; /*0x103131b19*/
    result = 0; /*0x103131b1c*/
  }
  else
  {
    v4 = *a1; /*0x103131b20*/
    result = 0; /*0x103131b23*/
    if ( v4 == 9 || v4 == 32 ) /*0x103131b2d*/
      return result; /*0x103131b2d*/
    v2 = a1[a2 - 1]; /*0x103131b2f*/
  }
  if ( v2 != 9 && v2 != 32 ) /*0x103131b3c*/
  {
    result = 0; /*0x103131b3e*/
    v5 = 0; /*0x103131b47*/
    while ( VALID_HD_VALUE_CHARS_0[a1[v5]] != 0 ) /*0x103131b53*/
    {
      if ( a2 == ++v5 ) /*0x103131b5b*/
        return 1; /*0x103131b5b*/
    }
  }
  return result; /*0x103131b62*/
}

// Address: 0x103131b64 | Name: _nghttp3_pri_eq
_BOOL8 __fastcall nghttp3_pri_eq(__int64 a1, __int64 a2)
{
  _BOOL8 result; // rax

  result = false; /*0x103131b6a*/
  if ( *(_DWORD *)a1 == *(_DWORD *)a2 ) /*0x103131b6e*/
    return *(_BYTE *)(a1 + 4) == *(_BYTE *)(a2 + 4); /*0x103131b78*/
  return result; /*0x103131b7b*/
}

// Address: 0x103131bde | Name: _nghttp3_idtr_init
__int64 __fastcall nghttp3_idtr_init(__int64 a1, __int64 a2)
{
  return nghttp3_gaptr_init(a1, a2); /*0x103131be2*/
}

// Address: 0x103131be8 | Name: _nghttp3_idtr_free
__int64 __fastcall nghttp3_idtr_free(__int64 a1)
{
  __int64 result; // rax

  if ( a1 != 0 ) /*0x103131bef*/
    return nghttp3_gaptr_free(a1); /*0x103131bf2*/
  return result; /*0x103131bf1*/
}

// Address: 0x103131bf9 | Name: _nghttp3_idtr_open
__int64 __fastcall nghttp3_idtr_open(__int64 a1, __int64 a2)
{
  __int64 v3; // rbx

  v3 = a2 >> 2; /*0x103131c06*/
  if ( nghttp3_gaptr_is_pushed(a1, a2: a2 >> 2, a3: 1) ) /*0x103131c12*/
    return 4294967192LL; /*0x103131c1b*/
  else
    return nghttp3_gaptr_push(a1, a2: v3, a3: 1); /*0x103131c34*/
}

// Address: 0x103131c39 | Name: _nghttp3_idtr_is_open
_BOOL8 __fastcall nghttp3_idtr_is_open(__int64 a1, __int64 a2)
{
  return nghttp3_gaptr_is_pushed(a1, a2: a2 >> 2, a3: 1); /*0x103131c46*/
}

// Address: 0x103131c4c | Name: _nghttp3_objalloc_ksl_blk_get
__int64 __fastcall nghttp3_objalloc_ksl_blk_get(_QWORD *a1)
{
  __int64 v1; // rax
  __int64 result; // rax
  __int64 v4; // [rsp+0h] [rbp-10h] BYREF

  v4 = v1; /*0x103131c51*/
  result = nghttp3_opl_pop(a1: a1 + 7); /*0x103131c59*/
  if ( result == 0 ) /*0x103131c61*/
  {
    if ( (unsigned int)nghttp3_balloc_get(a1, a2: &v4, a3: 0x120u) != 0 ) /*0x103131c76*/
      return 0; /*0x103131c7e*/
    else
      return v4; /*0x103131c78*/
  }
  return result; /*0x103131c84*/
}

// Address: 0x103131c87 | Name: _nghttp3_objalloc_ksl_blk_len_get
__int64 __fastcall nghttp3_objalloc_ksl_blk_len_get(_QWORD *a1, unsigned __int64 a2)
{
  __int64 result; // rax
  _QWORD v5[3]; // [rsp+8h] [rbp-18h] BYREF

  result = nghttp3_opl_pop(a1: a1 + 7); /*0x103131c9c*/
  if ( result == 0 ) /*0x103131ca4*/
  {
    if ( (unsigned int)nghttp3_balloc_get(a1, a2: v5, a3: a2) != 0 ) /*0x103131cb7*/
      return 0; /*0x103131cbf*/
    else
      return v5[0]; /*0x103131cb9*/
  }
  return result; /*0x103131cc1*/
}

// Address: 0x103131cca | Name: _nghttp3_ksl_init
__int64 __fastcall nghttp3_ksl_init(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5)
{
  __int64 v9; // r13

  v9 = ((_DWORD)a4 + 7) & 0xFFFFFFF8; /*0x103131ce8*/
  nghttp3_objalloc_init(a1, a2: (32 * v9 + 303) & 0x7FFFFFFF20LL, a3: a5); /*0x103131d04*/
  *(_QWORD *)(a1 + 80) = 0; /*0x103131d0b*/
  *(_OWORD *)(a1 + 64) = 0; /*0x103131d13*/
  *(_QWORD *)(a1 + 88) = a2; /*0x103131d19*/
  *(_QWORD *)(a1 + 96) = a3; /*0x103131d1e*/
  *(_QWORD *)(a1 + 104) = 0; /*0x103131d23*/
  *(_QWORD *)(a1 + 112) = a4; /*0x103131d28*/
  *(_QWORD *)(a1 + 120) = v9; /*0x103131d2d*/
  return 0; /*0x103131d36*/
}

// Address: 0x103131d41 | Name: _nghttp3_ksl_free
__int64 __fastcall nghttp3_ksl_free(__int64 a1)
{
  __int64 result; // rax

  if ( a1 != 0 && *(_QWORD *)(a1 + 64) != 0 ) /*0x103131d4f*/
    return nghttp3_objalloc_free(a1); /*0x103131d52*/
  return result; /*0x103131d51*/
}

// Address: 0x103131d59 | Name: _nghttp3_ksl_insert
__int64 __fastcall nghttp3_ksl_insert(__int64 a1, __int64 *a2, const void *a3, __int64 a4)
{
  __int64 v7; // r13
  __int64 v8; // rax
  __int64 v9; // rax
  unsigned int v10; // r15d
  __int64 v11; // rbx
  __int64 v12; // r12
  __int64 v13; // rax
  __int64 v14; // r15
  unsigned __int64 v15; // rbx
  __int64 v16; // r12
  unsigned int v17; // eax
  __int64 v18; // rbx
  unsigned int v19; // eax
  unsigned int *v20; // rax
  __int64 v21; // rcx
  __int64 v23; // [rsp+0h] [rbp-40h]
  const void *v24; // [rsp+8h] [rbp-38h]

  v7 = *(_QWORD *)(a1 + 64); /*0x103131d77*/
  if ( v7 == 0 ) /*0x103131d7e*/
  {
    v8 = nghttp3_objalloc_ksl_blk_len_get((_QWORD *)a1, a2: 32LL * *(_QWORD *)(a1 + 120) + 288); /*0x103131d92*/
    if ( v8 == 0 ) /*0x103131d9a*/
      return (unsigned int)-901; /*0x103132072*/
    v7 = v8; /*0x103131da0*/
    *(_QWORD *)(v8 + 272) = v8 + 288; /*0x103131da9*/
    *(_WORD *)(v8 + 284) = *(_WORD *)(a1 + 120); /*0x103131db5*/
    *(_DWORD *)(v8 + 280) = 0; /*0x103131dbd*/
    *(_OWORD *)v8 = 0; /*0x103131dcb*/
    *(_BYTE *)(v8 + 286) = 1; /*0x103131dd0*/
    *(_QWORD *)(a1 + 64) = v8; /*0x103131dd8*/
    *(_QWORD *)(a1 + 80) = v8; /*0x103131ddc*/
    *(_QWORD *)(a1 + 72) = v8; /*0x103131de0*/
  }
  v23 = a4; /*0x103131de4*/
  v24 = a3; /*0x103131df0*/
  if ( *(_DWORD *)(v7 + 280) != 32 ) /*0x103131df4*/
    goto LABEL_8; /*0x103131df4*/
  v9 = ksl_split_blk(a1, a2: v7); /*0x103131e00*/
  v10 = -901; /*0x103131e05*/
  if ( v9 != 0 ) /*0x103131e0e*/
  {
    v11 = v9; /*0x103131e14*/
    v12 = *(_QWORD *)(a1 + 64); /*0x103131e17*/
    v13 = nghttp3_objalloc_ksl_blk_len_get((_QWORD *)a1, a2: 32LL * *(_QWORD *)(a1 + 120) + 288); /*0x103131e2d*/
    if ( v13 != 0 ) /*0x103131e35*/
    {
      v7 = v13; /*0x103131e3b*/
      v14 = v13 + 288; /*0x103131e41*/
      *(_QWORD *)(v13 + 272) = v13 + 288; /*0x103131e48*/
      *(_WORD *)(v13 + 284) = *(_WORD *)(a1 + 120); /*0x103131e54*/
      *(_OWORD *)v13 = 0; /*0x103131e5f*/
      *(_DWORD *)(v13 + 280) = 2; /*0x103131e64*/
      *(_BYTE *)(v13 + 286) = 0; /*0x103131e6f*/
      memcpy( /*0x103131e9d*/
        __dst: (void *)(v13 + 288),
        __src: (const void *)(*(_QWORD *)(v12 + 272)
                     + (unsigned int)(*(_DWORD *)(v12 + 280) - 1) * (unsigned __int64)*(unsigned __int16 *)(v12 + 284)),
        __n: *(_QWORD *)(a1 + 112));
      *(_QWORD *)(v7 + 16) = v12; /*0x103131ea2*/
      memcpy( /*0x103131ecb*/
        __dst: (void *)(*(_QWORD *)(a1 + 120) + v14),
        __src: (const void *)(*(_QWORD *)(v11 + 272)
                     + (unsigned int)(*(_DWORD *)(v11 + 280) - 1) * (unsigned __int64)*(unsigned __int16 *)(v11 + 284)),
        __n: *(_QWORD *)(a1 + 112));
      *(_QWORD *)(v7 + 24) = v11; /*0x103131ed0*/
      *(_QWORD *)(a1 + 64) = v7; /*0x103131ed4*/
      a3 = v24; /*0x103131ed8*/
      while ( 1 ) /*0x103131ee9*/
      {
LABEL_8:
        v15 = (*(__int64 (__fastcall **)(__int64, __int64, const void *))(a1 + 96))(a1, a2: v7, a3); /*0x103131edc*/
        if ( *(_BYTE *)(v7 + 286) != 0 ) /*0x103131ef4*/
        {
          if ( v15 >= *(unsigned int *)(v7 + 280) /*0x10313203c*/
            || (*(unsigned int (__fastcall **)(const void *, unsigned __int64))(a1 + 88))(
                 a1: a3,
                 a2: *(_QWORD *)(v7 + 272) + v15 * *(unsigned __int16 *)(v7 + 284)) != 0 )
          {
            ksl_insert_node(a1, a2: v7, a3: v15, a4: a3, a5: v23); /*0x10313204e*/
            ++*(_QWORD *)(a1 + 104); /*0x103132053*/
            v10 = 0; /*0x103132057*/
            if ( a2 != nullptr ) /*0x103132061*/
            {
              *a2 = v7; /*0x103132063*/
              a2[1] = v15; /*0x103132066*/
            }
          }
          else
          {
            v10 = -101; /*0x103132085*/
            if ( a2 != nullptr ) /*0x103132092*/
            {
              if ( *(_QWORD *)(a1 + 64) != 0 ) /*0x103132099*/
              {
                v20 = *(unsigned int **)(a1 + 80); /*0x10313209b*/
                v21 = v20[70]; /*0x10313209f*/
              }
              else
              {
                v20 = (unsigned int *)&null_blk; /*0x1031320ac*/
                v21 = 0; /*0x1031320b3*/
              }
              *a2 = (__int64)v20; /*0x1031320b5*/
              a2[1] = v21; /*0x1031320b8*/
            }
          }
          return v10; /*0x10313206a*/
        }
        if ( v15 == *(_DWORD *)(v7 + 280) ) /*0x103131f04*/
          break; /*0x103131f04*/
        v16 = v7 + 8 * v15 + 16; /*0x103131f0e*/
        if ( *(_DWORD *)(*(_QWORD *)v16 + 280LL) == 32 ) /*0x103131f1c*/
        {
          v17 = ksl_split_node(a1, a2: v7, a3: v15); /*0x103131f27*/
          if ( v17 != 0 ) /*0x103131f2e*/
            return v17; /*0x1031320aa*/
          a3 = v24; /*0x103131f47*/
          if ( (*(unsigned int (__fastcall **)(unsigned __int64, const void *))(a1 + 88))( /*0x103131f54*/
                 a1: *(_QWORD *)(v7 + 272) + v15 * *(unsigned __int16 *)(v7 + 284),
                 a2: v24) != 0 )
            v16 = v7 + 16 + 8 * v15 + 8; /*0x103131f62*/
        }
        v7 = *(_QWORD *)v16; /*0x103131f65*/
      }
      do /*0x103131fd0*/
      {
        v18 = (unsigned int)(*(_DWORD *)(v7 + 280) - 1); /*0x103131f75*/
        if ( *(_DWORD *)(*(_QWORD *)(v7 + 8 * v18 + 16) + 280LL) == 32 ) /*0x103131f83*/
        {
          v17 = ksl_split_node(a1, a2: v7, a3: (unsigned int)(*(_DWORD *)(v7 + 280) - 1)); /*0x103131f8e*/
          if ( v17 != 0 ) /*0x103131f95*/
            return v17; /*0x103131f95*/
          v18 = (unsigned int)(*(_DWORD *)(v7 + 280) - 1); /*0x103131fa2*/
          a3 = v24; /*0x103131fa4*/
        }
        memcpy( /*0x103131fbe*/
          __dst: (void *)(*(_QWORD *)(v7 + 272) + v18 * *(_QWORD *)(a1 + 120)),
          __src: a3,
          __n: *(_QWORD *)(a1 + 112));
        v7 = *(_QWORD *)(v7 + 8 * v18 + 16); /*0x103131fc3*/
      }
      while ( *(_BYTE *)(v7 + 286) == 0 ); /*0x103131fd0*/
      ksl_insert_node(a1, a2: v7, a3: *(unsigned int *)(v7 + 280), a4: a3, a5: v23); /*0x103131fe6*/
      ++*(_QWORD *)(a1 + 104); /*0x103131feb*/
      v10 = 0; /*0x103131fef*/
      if ( a2 != nullptr ) /*0x103131ff9*/
      {
        v19 = *(_DWORD *)(v7 + 280) - 1; /*0x103132006*/
        *a2 = v7; /*0x103132008*/
        a2[1] = v19; /*0x10313200b*/
      }
    }
    else
    {
      nghttp3_opl_push(a1: a1 + 56, a2: v11); /*0x10313207e*/
    }
  }
  return v10; /*0x1031320bf*/
}

// Address: 0x1031320ce | Name: _nghttp3_ksl_end
void *__fastcall nghttp3_ksl_end(__int64 a1)
{
  if ( *(_QWORD *)(a1 + 64) != 0 ) /*0x1031320d3*/
    return *(void **)(a1 + 80); /*0x1031320d9*/
  else
    return &null_blk; /*0x1031320e5*/
}

// Address: 0x1031321a3 | Name: _nghttp3_ksl_it_init
void __fastcall nghttp3_ksl_it_init(_QWORD *a1, __int64 a2, __int64 a3)
{
  *a1 = a2; /*0x1031321a7*/
  a1[1] = a3; /*0x1031321aa*/
}

// Address: 0x1031322a8 | Name: _nghttp3_ksl_remove_hint
__int64 __fastcall nghttp3_ksl_remove_hint(__int64 a1, __int64 *a2, __int64 *a3, __int64 a4)
{
  __int64 v7; // r14
  __int64 v9; // rax

  v7 = *a3; /*0x1031322bc*/
  if ( *a3 != *(_QWORD *)(a1 + 64) && *(_DWORD *)(v7 + 280) == 16 ) /*0x1031322cd*/
    return nghttp3_ksl_remove(a1, a2, a3: a4); /*0x1031322e0*/
  ksl_remove_node(a1, a2: v7, a3: a3[1]); /*0x1031322ef*/
  --*(_QWORD *)(a1 + 104); /*0x1031322f4*/
  if ( a2 != nullptr ) /*0x1031322fc*/
  {
    v9 = a3[1]; /*0x1031322fe*/
    if ( v9 == *(_DWORD *)(v7 + 280) && *(_QWORD *)v7 != 0 ) /*0x103132314*/
    {
      *a2 = *(_QWORD *)v7; /*0x103132316*/
      a2[1] = 0; /*0x103132319*/
    }
    else
    {
      *a2 = v7; /*0x103132323*/
      a2[1] = v9; /*0x103132326*/
    }
  }
  return 0; /*0x1031322d8*/
}

// Address: 0x103132335 | Name: _nghttp3_ksl_remove
__int64 __fastcall nghttp3_ksl_remove(_QWORD *a1, _QWORD *a2, __int64 a3)
{
  _BYTE *v3; // r14
  __int64 result; // rax
  __int64 v6; // r15
  __int64 v7; // rbx
  unsigned __int64 v8; // rax
  __int64 v9; // r12
  unsigned __int64 v10; // rdx
  __int64 v11; // r13
  int v12; // esi
  __int64 v13; // r15
  __int64 v14; // rsi
  size_t v15; // rdx
  __int64 v16; // rsi
  __int64 v17; // r13
  int v18; // esi
  __int64 v19; // r15
  __int64 v20; // rax
  __int64 v21; // rdx
  const void *v22; // rsi
  size_t v23; // rdx
  _QWORD *v24; // rcx
  __int64 v26; // [rsp+18h] [rbp-38h]
  __int64 v27; // [rsp+20h] [rbp-30h]

  v3 = (_BYTE *)a1[8]; /*0x103132346*/
  result = 4294967195LL; /*0x10313234a*/
  if ( v3 == nullptr ) /*0x103132352*/
    return result; /*0x103132352*/
  v6 = (__int64)a1; /*0x10313235b*/
  if ( v3[286] == 0 /*0x10313238e*/
    && *((_DWORD *)v3 + 70) == 2
    && *(_DWORD *)(*((_QWORD *)v3 + 2) + 280LL) == 16
    && *(_DWORD *)(*((_QWORD *)v3 + 3) + 280LL) == 16 )
  {
    v3 = (_BYTE *)ksl_merge_node(a1, a2: (__int64)v3, a3: 0); /*0x10313239d*/
  }
  v7 = (*(__int64 (__fastcall **)(__int64, _BYTE *, __int64))(v6 + 96))(a1: v6, a2: v3, a3); /*0x1031323ad*/
  v8 = *((unsigned int *)v3 + 70); /*0x1031323b0*/
  if ( v7 != v8 ) /*0x1031323ba*/
  {
    v27 = v6; /*0x1031323c0*/
    v26 = a3; /*0x1031323c4*/
    while ( 1 ) /*0x1031323c8*/
    {
      if ( v3[286] != 0 ) /*0x1031323d0*/
      {
        if ( (*(unsigned int (__fastcall **)(__int64, __int64))(v6 + 88))( /*0x103132675*/
               a1: a3,
               a2: *((_QWORD *)v3 + 34) + v7 * *((unsigned __int16 *)v3 + 142)) != 0 )
          goto LABEL_25; /*0x103132675*/
        ksl_remove_node(a1: v6, a2: (__int64)v3, a3: v7); /*0x1031326ad*/
        --*(_QWORD *)(v6 + 104); /*0x1031326b2*/
        v24 = a2; /*0x1031326b6*/
        if ( a2 == nullptr ) /*0x1031326bd*/
          return 0; /*0x1031326f0*/
        if ( v7 == *((_DWORD *)v3 + 70) && *(_QWORD *)v3 != 0 ) /*0x1031326d1*/
        {
          v7 = 0; /*0x1031326d3*/
          v3 = *(_BYTE **)v3; /*0x1031326d5*/
        }
        result = 0; /*0x1031326d8*/
LABEL_34:
        *v24 = v3; /*0x1031326da*/
        v24[1] = v7; /*0x1031326dd*/
        return result; /*0x1031326dd*/
      }
      v9 = *(_QWORD *)&v3[8 * v7 + 16]; /*0x1031323d6*/
      v10 = *(unsigned int *)(v9 + 280); /*0x1031323db*/
      if ( v10 <= 0x10 ) /*0x1031323e7*/
        break; /*0x1031323e7*/
LABEL_22:
      v7 = (*(__int64 (__fastcall **)(__int64, __int64, __int64))(v6 + 96))(a1: v6, a2: v9, a3); /*0x103132633*/
      v8 = *(unsigned int *)(v9 + 280); /*0x103132643*/
      v3 = (_BYTE *)v9; /*0x10313264b*/
      if ( v7 == v8 ) /*0x103132651*/
        goto LABEL_25; /*0x103132651*/
    }
    if ( v7 + 1 >= v8 || (v11 = *(_QWORD *)&v3[8 * v7 + 24], (unsigned int)(v12 = *(_DWORD *)(v11 + 280)) < 0x11) ) /*0x103132409*/
    {
      if ( v7 == 0 || (v17 = *(_QWORD *)&v3[8 * v7 + 8], (unsigned int)(v18 = *(_DWORD *)(v17 + 280)) < 0x11) ) /*0x103132519*/
      {
        if ( v7 + 1 >= v8 ) /*0x103132619*/
          --v7; /*0x10313261b*/
        v9 = ksl_merge_node(a1: (_QWORD *)v6, a2: (__int64)v3, a3: v7); /*0x10313262c*/
        goto LABEL_21; /*0x10313262c*/
      }
      v19 = ((unsigned int)(v10 + v18 + 1) >> 1) - (unsigned int)v10; /*0x103132531*/
      memmove(__dst: (void *)(v9 + 8 * v19 + 16), __src: (const void *)(v9 + 16), __len: 8 * v10); /*0x103132549*/
      memmove( /*0x103132571*/
        __dst: (void *)(*(_QWORD *)(v9 + 272) + v19 * *(_QWORD *)(v27 + 120)),
        __src: *(const void **)(v9 + 272),
        __len: *(_QWORD *)(v27 + 120) * *(unsigned int *)(v9 + 280));
      *(_DWORD *)(v9 + 280) += v19; /*0x103132576*/
      v20 = (unsigned int)(*(_DWORD *)(v17 + 280) - v19); /*0x103132585*/
      *(_DWORD *)(v17 + 280) = v20; /*0x103132588*/
      memcpy(__dst: (void *)(v9 + 16), __src: (const void *)(v17 + 8 * v20 + 16), __n: 8 * v19); /*0x1031325a6*/
      v21 = *(_QWORD *)(v27 + 120); /*0x1031325be*/
      v22 = (const void *)(*(_QWORD *)(v17 + 272) + v21 * *(unsigned int *)(v17 + 280)); /*0x1031325c6*/
      v23 = v19 * v21; /*0x1031325cd*/
      v6 = v27; /*0x1031325d1*/
      memcpy(__dst: *(void **)(v9 + 272), __src: v22, __n: v23); /*0x1031325d5*/
      memcpy( /*0x10313260a*/
        __dst: (void *)(*((_QWORD *)v3 + 34) + *(_QWORD *)(v6 + 120) * (v7 - 1)),
        __src: (const void *)(*(_QWORD *)(v17 + 272)
                     + (unsigned int)(*(_DWORD *)(v17 + 280) - 1) * (unsigned __int64)*(unsigned __int16 *)(v17 + 284)),
        __n: *(_QWORD *)(v6 + 112));
    }
    else
    {
      v13 = ((unsigned int)(v10 + v12 + 1) >> 1) - (unsigned int)v10; /*0x103132419*/
      memcpy(__dst: (void *)(v9 + 8 * v10 + 16), __src: (const void *)(v11 + 16), __n: 8 * v13); /*0x103132434*/
      memcpy( /*0x103132460*/
        __dst: (void *)(*(_QWORD *)(v9 + 272) + *(_QWORD *)(v27 + 120) * *(unsigned int *)(v9 + 280)),
        __src: *(const void **)(v11 + 272),
        __n: v13 * *(_QWORD *)(v27 + 120));
      *(_DWORD *)(v9 + 280) += v13; /*0x103132465*/
      *(_DWORD *)(v11 + 280) -= v13; /*0x10313246d*/
      memcpy( /*0x1031324ae*/
        __dst: (void *)(*((_QWORD *)v3 + 34) + v7 * *(_QWORD *)(v27 + 120)),
        __src: (const void *)(*(_QWORD *)(v9 + 272)
                     + (unsigned int)(*(_DWORD *)(v9 + 280) - 1) * (unsigned __int64)*(unsigned __int16 *)(v9 + 284)),
        __n: *(_QWORD *)(v27 + 112));
      memmove( /*0x1031324cd*/
        __dst: (void *)(v11 + 16),
        __src: (const void *)(v11 + 8 * v13 + 16),
        __len: 8LL * *(unsigned int *)(v11 + 280));
      v14 = *(_QWORD *)(v27 + 120); /*0x1031324dd*/
      v15 = v14 * *(unsigned int *)(v11 + 280); /*0x1031324e8*/
      v16 = v13 * v14; /*0x1031324ec*/
      v6 = v27; /*0x1031324f0*/
      memmove(__dst: *(void **)(v11 + 272), __src: (const void *)(*(_QWORD *)(v11 + 272) + v16), __len: v15); /*0x1031324f7*/
    }
    v9 = *(_QWORD *)&v3[8 * v7 + 16]; /*0x10313260f*/
LABEL_21:
    a3 = v26; /*0x10313262f*/
    goto LABEL_22; /*0x10313262f*/
  }
LABEL_25:
  v24 = a2; /*0x103132677*/
  result = 4294967195LL; /*0x10313267e*/
  if ( a2 != nullptr ) /*0x103132683*/
  {
    if ( *(_QWORD *)(v6 + 64) != 0 ) /*0x10313268a*/
    {
      v3 = *(_BYTE **)(v6 + 80); /*0x10313268c*/
      v7 = *((unsigned int *)v3 + 70); /*0x103132690*/
    }
    else
    {
      v3 = &null_blk; /*0x103132699*/
      v7 = 0; /*0x1031326a0*/
    }
    goto LABEL_34; /*0x103132697*/
  }
  return result; /*0x1031326e1*/
}

// Address: 0x103132894 | Name: _nghttp3_ksl_lower_bound
__int64 __fastcall nghttp3_ksl_lower_bound(__int64 a1, __int64 a2)
{
  return nghttp3_ksl_lower_bound_search(a1, a2, a3: *(_QWORD *)(a1 + 96)); /*0x10313289c*/
}

// Address: 0x1031328a2 | Name: _nghttp3_ksl_lower_bound_search
void *__fastcall nghttp3_ksl_lower_bound_search(
        __int64 a1,
        __int64 a2,
        __int64 (__fastcall *a3)(__int64, __int64, __int64))
{
  __int64 v3; // rbx
  __int64 v7; // rdx
  void *result; // rax

  v3 = *(_QWORD *)(a1 + 64); /*0x1031328ad*/
  if ( v3 == 0 ) /*0x1031328b4*/
    return &null_blk; /*0x10313292c*/
  while ( 1 ) /*0x1031328cb*/
  {
    v7 = a3(a1, a2: v3, a3: a2); /*0x1031328cb*/
    if ( *(_BYTE *)(v3 + 286) != 0 ) /*0x1031328d5*/
      break; /*0x1031328d5*/
    if ( v7 == *(_DWORD *)(v3 + 280) ) /*0x1031328e0*/
    {
      do /*0x1031328fd*/
        v3 = *(_QWORD *)(v3 + 8LL * (unsigned int)(*(_DWORD *)(v3 + 280) - 1) + 16); /*0x1031328f1*/
      while ( *(_BYTE *)(v3 + 286) == 0 ); /*0x1031328fd*/
      result = *(void **)v3; /*0x1031328ff*/
      if ( *(_QWORD *)v3 == 0 ) /*0x103132905*/
        return (void *)v3; /*0x103132905*/
      return result; /*0x103132905*/
    }
    v3 = *(_QWORD *)(v3 + 8 * v7 + 16); /*0x1031328e2*/
  }
  if ( v7 != *(_DWORD *)(v3 + 280) ) /*0x103132918*/
    return (void *)v3; /*0x103132937*/
  result = *(void **)v3; /*0x10313291a*/
  if ( *(_QWORD *)v3 == 0 ) /*0x103132922*/
    return (void *)v3; /*0x103132922*/
  return result; /*0x10313293a*/
}

// Address: 0x103132943 | Name: _nghttp3_ksl_update_key
void *__fastcall nghttp3_ksl_update_key(__int64 a1, __int64 a2, const void *a3)
{
  __int64 v3; // r15
  __int64 v5; // r13
  __int64 v6; // r12
  __int64 v7; // rax
  _QWORD *v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // r13
  unsigned int (__fastcall *v11)(__int64, __int64); // rbx
  __int64 v12; // rbx
  _QWORD *v14; // [rsp+8h] [rbp-48h]
  _QWORD *v15; // [rsp+10h] [rbp-40h]
  __int64 v16; // [rsp+18h] [rbp-38h]

  v3 = a2; /*0x103132958*/
  v5 = *(_QWORD *)(a1 + 64); /*0x10313295e*/
  v6 = (*(__int64 (__fastcall **)(__int64, __int64, __int64))(a1 + 96))(a1, a2: v5, a3: a2); /*0x10313296b*/
  v7 = *(_QWORD *)(v5 + 272); /*0x10313296e*/
  if ( *(_BYTE *)(v5 + 286) == 0 ) /*0x10313297d*/
  {
    v8 = (_QWORD *)(v5 + 272); /*0x103132983*/
    v9 = v5 + 8 * v6 + 16; /*0x1031329a1*/
    v10 = v6 * *(unsigned __int16 *)(v5 + 284) + v7; /*0x1031329a4*/
    v16 = v3; /*0x1031329a7*/
    do /*0x103132a42*/
    {
      v15 = v8; /*0x1031329ab*/
      v14 = (_QWORD *)v9; /*0x1031329af*/
      v11 = *(unsigned int (__fastcall **)(__int64, __int64))(a1 + 88); /*0x1031329b3*/
      if ( v11(a1: v10, a2: v3) == 0 && v11(a1: v16, a2: v10) == 0 /*0x1031329dd*/
        || (*(unsigned int (__fastcall **)(__int64, const void *))(a1 + 88))(a1: v10, a2: a3) != 0 )
      {
        memcpy(__dst: (void *)(*v15 + *(_QWORD *)(a1 + 120) * v6), __src: a3, __n: *(_QWORD *)(a1 + 112)); /*0x1031329f6*/
      }
      v12 = *v14; /*0x1031329ff*/
      v3 = v16; /*0x103132a08*/
      v6 = (*(__int64 (__fastcall **)(__int64, _QWORD, __int64))(a1 + 96))(a1, a2: *v14, a3: v16); /*0x103132a13*/
      v9 = v12 + 8 * v6 + 16; /*0x103132a1a*/
      v8 = (_QWORD *)(v12 + 272); /*0x103132a1e*/
      v7 = *(_QWORD *)(v12 + 272); /*0x103132a25*/
      v10 = v7 + v6 * *(unsigned __int16 *)(v12 + 284); /*0x103132a38*/
    }
    while ( *(_BYTE *)(v12 + 286) == 0 ); /*0x103132a42*/
  }
  return memcpy(__dst: (void *)(v7 + *(_QWORD *)(a1 + 120) * v6), __src: a3, __n: *(_QWORD *)(a1 + 112)); /*0x103132a5b*/
}

// Address: 0x103132a6e | Name: _nghttp3_ksl_len
__int64 __fastcall nghttp3_ksl_len(__int64 a1)
{
  return *(_QWORD *)(a1 + 104); /*0x103132a76*/
}

// Address: 0x103132a78 | Name: _nghttp3_ksl_clear
__int64 __fastcall nghttp3_ksl_clear(__int64 a1)
{
  __int64 result; // rax

  if ( *(_QWORD *)(a1 + 64) != 0 ) /*0x103132a81*/
  {
    *(_QWORD *)(a1 + 104) = 0; /*0x103132a89*/
    *(_QWORD *)(a1 + 80) = 0; /*0x103132a8d*/
    *(_OWORD *)(a1 + 64) = 0; /*0x103132a94*/
    return nghttp3_objalloc_clear(); /*0x103132a98*/
  }
  return result; /*0x103132a97*/
}

// Address: 0x103132a9f | Name: _nghttp3_ksl_print
int __fastcall nghttp3_ksl_print(__int64 a1)
{
  __int64 v1; // rdi
  int result; // eax

  v1 = *(_QWORD *)(a1 + 64); /*0x103132aa3*/
  if ( v1 != 0 ) /*0x103132aaa*/
    return ksl_print(a1: v1, a2: 0); /*0x103132aaf*/
  return result; /*0x103132aae*/
}

// Address: 0x103132b79 | Name: _nghttp3_ksl_begin
void *__fastcall nghttp3_ksl_begin(__int64 a1)
{
  if ( *(_QWORD *)(a1 + 64) != 0 ) /*0x103132b82*/
    return *(void **)(a1 + 72); /*0x103132b84*/
  else
    return &null_blk; /*0x103132b8a*/
}

// Address: 0x103132b95 | Name: _nghttp3_ksl_it_prev
__int64 __fastcall nghttp3_ksl_it_prev(_QWORD *a1)
{
  __int64 v1; // rax
  __int64 result; // rax
  __int64 v3; // rax

  v1 = a1[1]; /*0x103132b95*/
  if ( v1 != 0 ) /*0x103132b9c*/
  {
    result = v1 - 1; /*0x103132b9e*/
  }
  else
  {
    v3 = *(_QWORD *)(*a1 + 8LL); /*0x103132baa*/
    *a1 = v3; /*0x103132bae*/
    result = (unsigned int)(*(_DWORD *)(v3 + 280) - 1); /*0x103132bb7*/
  }
  a1[1] = result; /*0x103132bba*/
  return result; /*0x103132bbe*/
}

// Address: 0x103132bbf | Name: _nghttp3_ksl_it_begin
_BOOL8 __fastcall nghttp3_ksl_it_begin(_QWORD *a1)
{
  _BOOL8 result; // rax

  result = false; /*0x103132bbf*/
  if ( a1[1] == 0 ) /*0x103132bc6*/
    return *(_QWORD *)(*a1 + 8LL) == 0; /*0x103132bd7*/
  return result; /*0x103132bc8*/
}

// Address: 0x103132bdc | Name: _nghttp3_ksl_range_compar
_BOOL8 __fastcall nghttp3_ksl_range_compar(_QWORD *a1, _QWORD *a2)
{
  return *a1 < *a2; /*0x103132beb*/
}

// Address: 0x103132bed | Name: _nghttp3_ksl_range_search
__int64 __fastcall nghttp3_ksl_range_search(__int64 a1, __int64 a2, unsigned __int64 *a3)
{
  __int64 v3; // rcx
  unsigned __int64 *v4; // rsi
  unsigned __int64 v5; // rdx
  __int64 result; // rax

  v3 = *(unsigned int *)(a2 + 280); /*0x103132bed*/
  if ( *(_DWORD *)(a2 + 280) == 0 ) /*0x103132bf6*/
    return 0; /*0x103132c1e*/
  v4 = *(unsigned __int64 **)(a2 + 272); /*0x103132bfc*/
  v5 = *a3; /*0x103132c03*/
  result = 0; /*0x103132c06*/
  while ( *v4 < v5 ) /*0x103132c0b*/
  {
    ++result; /*0x103132c0d*/
    v4 = (unsigned __int64 *)((char *)v4 + *(_QWORD *)(a1 + 120)); /*0x103132c10*/
    if ( v3 == result ) /*0x103132c17*/
      return v3; /*0x103132c19*/
  }
  return result; /*0x103132c1d*/
}

// Address: 0x103132c21 | Name: _nghttp3_ksl_range_exclusive_compar
_BOOL8 __fastcall nghttp3_ksl_range_exclusive_compar(unsigned __int64 *a1, unsigned __int64 *a2)
{
  _BOOL8 result; // rax
  unsigned __int64 v3; // rdx

  result = false; /*0x103132c28*/
  if ( *a1 < *a2 ) /*0x103132c2d*/
  {
    v3 = a2[1]; /*0x103132c33*/
    if ( a1[1] < v3 ) /*0x103132c3a*/
      v3 = a1[1]; /*0x103132c3a*/
    return *a2 >= v3; /*0x103132c43*/
  }
  return result; /*0x103132c46*/
}

// Address: 0x103132c48 | Name: _nghttp3_ksl_range_exclusive_search
__int64 __fastcall nghttp3_ksl_range_exclusive_search(__int64 a1, __int64 a2, unsigned __int64 *a3)
{
  __int64 v3; // rcx
  unsigned __int64 *v4; // rsi
  unsigned __int64 v5; // r8
  __int64 result; // rax
  unsigned __int64 v7; // r10

  v3 = *(unsigned int *)(a2 + 280); /*0x103132c48*/
  if ( *(_DWORD *)(a2 + 280) == 0 ) /*0x103132c51*/
    return 0; /*0x103132c8d*/
  v4 = *(unsigned __int64 **)(a2 + 272); /*0x103132c57*/
  v5 = *a3; /*0x103132c5e*/
  result = 0; /*0x103132c61*/
  while ( *v4 < v5 ) /*0x103132c63*/
  {
    v7 = a3[1]; /*0x103132c6c*/
    if ( v4[1] < v7 ) /*0x103132c73*/
      v7 = v4[1]; /*0x103132c73*/
    if ( v5 < v7 ) /*0x103132c7a*/
      break; /*0x103132c7a*/
    ++result; /*0x103132c7c*/
    v4 = (unsigned __int64 *)((char *)v4 + *(_QWORD *)(a1 + 120)); /*0x103132c7f*/
    if ( v3 == result ) /*0x103132c86*/
      return v3; /*0x103132c88*/
  }
  return result; /*0x103132c8c*/
}

// Address: 0x103132c90 | Name: _nghttp3_ksl_uint64_less
_BOOL8 __fastcall nghttp3_ksl_uint64_less(_QWORD *a1, _QWORD *a2)
{
  return *a1 < *a2; /*0x103132c9f*/
}

// Address: 0x103132ca1 | Name: _nghttp3_ksl_uint64_less_search
__int64 __fastcall nghttp3_ksl_uint64_less_search(__int64 a1, __int64 a2, unsigned __int64 *a3)
{
  __int64 v3; // rcx
  unsigned __int64 *v4; // rsi
  unsigned __int64 v5; // rdx
  __int64 result; // rax

  v3 = *(unsigned int *)(a2 + 280); /*0x103132ca1*/
  if ( *(_DWORD *)(a2 + 280) == 0 ) /*0x103132caa*/
    return 0; /*0x103132cd2*/
  v4 = *(unsigned __int64 **)(a2 + 272); /*0x103132cb0*/
  v5 = *a3; /*0x103132cb7*/
  result = 0; /*0x103132cba*/
  while ( *v4 < v5 ) /*0x103132cbf*/
  {
    ++result; /*0x103132cc1*/
    v4 = (unsigned __int64 *)((char *)v4 + *(_QWORD *)(a1 + 120)); /*0x103132cc4*/
    if ( v3 == result ) /*0x103132ccb*/
      return v3; /*0x103132ccd*/
  }
  return result; /*0x103132cd1*/
}

// Address: 0x103132cd5 | Name: _nghttp3_ksl_int64_greater
_BOOL8 __fastcall nghttp3_ksl_int64_greater(_QWORD *a1, _QWORD *a2)
{
  return *a1 > *a2; /*0x103132ce4*/
}

// Address: 0x103132ce6 | Name: _nghttp3_ksl_int64_greater_search
__int64 __fastcall nghttp3_ksl_int64_greater_search(__int64 a1, __int64 a2, __int64 *a3)
{
  __int64 v3; // rcx
  _QWORD *v4; // rsi
  __int64 v5; // rdx
  __int64 result; // rax

  v3 = *(unsigned int *)(a2 + 280); /*0x103132ce6*/
  if ( *(_DWORD *)(a2 + 280) == 0 ) /*0x103132cef*/
    return 0; /*0x103132d17*/
  v4 = *(_QWORD **)(a2 + 272); /*0x103132cf5*/
  v5 = *a3; /*0x103132cfc*/
  result = 0; /*0x103132cff*/
  while ( *v4 > v5 ) /*0x103132d04*/
  {
    ++result; /*0x103132d06*/
    v4 = (_QWORD *)((char *)v4 + *(_QWORD *)(a1 + 120)); /*0x103132d09*/
    if ( v3 == result ) /*0x103132d10*/
      return v3; /*0x103132d12*/
  }
  return result; /*0x103132d16*/
}

// Address: 0x103132e19 | Name: _nghttp3_map_init
void __fastcall nghttp3_map_init(__int64 a1, __int64 a2, __int64 a3)
{
  *(_OWORD *)a1 = 0; /*0x103132e20*/
  *(_QWORD *)(a1 + 16) = 0; /*0x103132e23*/
  *(_QWORD *)(a1 + 24) = a3; /*0x103132e2b*/
  *(_QWORD *)(a1 + 32) = a2; /*0x103132e2f*/
  *(_OWORD *)(a1 + 40) = 0; /*0x103132e33*/
}

// Address: 0x103132e39 | Name: _nghttp3_map_free
__int64 __fastcall nghttp3_map_free(_QWORD *a1)
{
  __int64 result; // rax

  if ( a1 != nullptr ) /*0x103132e40*/
    return nghttp3_mem_free(a1: a1[3], a2: *a1); /*0x103132e4a*/
  return result; /*0x103132e49*/
}

// Address: 0x103132e51 | Name: _nghttp3_map_each
__int64 __fastcall nghttp3_map_each(_QWORD *a1, __int64 (__fastcall *a2)(_QWORD, __int64), __int64 a3)
{
  __int64 result; // rax
  __int64 v7; // r13
  unsigned __int64 v8; // rbx
  unsigned __int64 v9; // rax

  result = 0; /*0x103132e51*/
  if ( a1[5] != 0 ) /*0x103132e58*/
  {
    v7 = a1[6]; /*0x103132e71*/
    v8 = 1; /*0x103132e75*/
    while ( 1 ) /*0x103132e7a*/
    {
      if ( *(_BYTE *)(a1[2] + v8 - 1) != 0 ) /*0x103132e84*/
      {
        result = a2(a1: *(_QWORD *)(a1[1] + 8 * v8 - 8), a2: a3); /*0x103132e93*/
        if ( (_DWORD)result != 0 ) /*0x103132e98*/
          break; /*0x103132e98*/
      }
      v9 = v8++ >> v7; /*0x103132ea0*/
      if ( v9 != 0 ) /*0x103132ea9*/
        return 0; /*0x103132eab*/
    }
  }
  return result; /*0x103132ebb*/
}

// Address: 0x103132ebc | Name: _nghttp3_map_print_distance
unsigned __int64 __fastcall nghttp3_map_print_distance(_QWORD *a1)
{
  unsigned __int64 result; // rax
  __int64 v3; // r14
  unsigned __int64 v4; // r13
  __int64 v5; // rax

  if ( a1[5] != 0 ) /*0x103132ec1*/
  {
    v3 = a1[6]; /*0x103132ed8*/
    v4 = 0; /*0x103132eea*/
    do /*0x103132f5a*/
    {
      v5 = a1[2]; /*0x103132eed*/
      if ( *(_BYTE *)(v5 + v4) != 0 ) /*0x103132ef9*/
        fprintf( /*0x103132f30*/
          a1: __stderrp,
          a2: "@%zu key=%llu base=%zu distance=%u\n",
          v4,
          *(_QWORD *)(*a1 + 8 * v4),
          (0x9C7EAAC866455929LL * (*(_QWORD *)(*a1 + 8 * v4) + a1[4])) >> -*((_BYTE *)a1 + 48),
          *(unsigned __int8 *)(v5 + v4) - 1);
      else
        fprintf(a1: __stderrp, a2: "@%zu <EMPTY>\n", v4); /*0x103132f46*/
      result = ++v4 >> v3; /*0x103132f54*/
    }
    while ( v4 >> v3 == 0 ); /*0x103132f5a*/
  }
  return result; /*0x103132f6a*/
}

// Address: 0x103132f6b | Name: _nghttp3_map_insert
__int64 __fastcall nghttp3_map_insert(__int64 *a1, __int64 a2, __int64 a3)
{
  __int64 v6; // rcx
  __int64 result; // rax
  __int64 v8; // rcx
  unsigned __int64 v9; // rsi
  __int64 inserted; // rax

  v6 = a1[6]; /*0x103132f82*/
  if ( a1[5] + 1 >= (1LL << v6) - ((unsigned __int64)(1LL << v6) >> 3) ) /*0x103132f9e*/
  {
    v9 = 4; /*0x103132fe2*/
    if ( v6 != 0 ) /*0x103132fe7*/
      v9 = v6 + 1; /*0x103132fe7*/
    result = map_resize_0(a1, a2: v9); /*0x103132fee*/
    if ( (_DWORD)result == 0 ) /*0x103132ff5*/
    {
      inserted = map_insert_0((__int64)a1, a2, a3); /*0x103133000*/
      return (unsigned int)inserted & (unsigned int)(inserted >> 63); /*0x10313300c*/
    }
  }
  else
  {
    result = map_insert_0((__int64)a1, a2, a3); /*0x103132fa9*/
    v8 = result; /*0x103132fae*/
    if ( result < 0 ) /*0x103132fb4*/
    {
      return (unsigned int)result; /*0x103133010*/
    }
    else
    {
      result = 0; /*0x103132fba*/
      if ( *(_BYTE *)(a1[2] + v8) >= 0x81u ) /*0x103132fc0*/
        return map_resize_0(a1, a2: a1[6] + 1); /*0x103132fd6*/
    }
  }
  return result; /*0x103132fd0*/
}

// Address: 0x1031331ea | Name: _nghttp3_map_find
__int64 __fastcall nghttp3_map_find(__int64 a1, __int64 a2)
{
  unsigned __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 result; // rax
  __int64 v5; // r10

  if ( *(_QWORD *)(a1 + 40) == 0 ) /*0x1031331ef*/
    return 0; /*0x103133250*/
  v2 = (0x9C7EAAC866455929LL * (a2 + *(_QWORD *)(a1 + 32))) >> -*(_BYTE *)(a1 + 48); /*0x103133211*/
  v3 = *(_QWORD *)(a1 + 16); /*0x103133220*/
  if ( *(_BYTE *)(v3 + v2) == 0 ) /*0x103133228*/
    return 0; /*0x103133253*/
  result = 0; /*0x103133230*/
  v5 = 0; /*0x103133232*/
  while ( *(_QWORD *)(*(_QWORD *)a1 + 8 * v2) != a2 ) /*0x103133239*/
  {
    v2 = ~(-1LL << *(_BYTE *)(a1 + 48)) & (v2 + 1); /*0x10313323e*/
    if ( ++v5 >= (unsigned __int64)*(unsigned __int8 *)(v3 + v2) ) /*0x10313324c*/
      return result; /*0x10313324c*/
  }
  return *(_QWORD *)(*(_QWORD *)(a1 + 8) + 8 * v2); /*0x103133252*/
}

// Address: 0x103133261 | Name: _nghttp3_map_remove
__int64 __fastcall nghttp3_map_remove(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  unsigned __int64 v3; // r9
  __int64 v4; // rcx
  __int64 v5; // r8
  __int64 v6; // r10
  __int64 v7; // rsi
  unsigned __int8 v8; // dl
  unsigned __int64 v9; // rax
  __int64 v10; // rsi
  __int64 v11; // r11

  result = 4294967195LL; /*0x103133261*/
  if ( *(_QWORD *)(a1 + 40) != 0 ) /*0x10313326b*/
  {
    v3 = (0x9C7EAAC866455929LL * (a2 + *(_QWORD *)(a1 + 32))) >> -*(_BYTE *)(a1 + 48); /*0x103133291*/
    v4 = *(_QWORD *)(a1 + 16); /*0x1031332a0*/
    if ( *(_BYTE *)(v4 + v3) != 0 ) /*0x1031332a9*/
    {
      v5 = ~(-1LL << *(_BYTE *)(a1 + 48)); /*0x1031332ab*/
      v6 = 0; /*0x1031332b1*/
      while ( *(_QWORD *)(*(_QWORD *)a1 + 8 * v3) != a2 ) /*0x1031332b8*/
      {
        v3 = v5 & (v3 + 1); /*0x1031332bd*/
        if ( ++v6 >= (unsigned __int64)*(unsigned __int8 *)(v4 + v3) ) /*0x1031332cb*/
          return result; /*0x1031332cb*/
      }
      v7 = v5 & (v3 + 1); /*0x1031332d3*/
      v8 = *(_BYTE *)(v4 + v7); /*0x1031332d6*/
      if ( v8 >= 2u ) /*0x1031332dc*/
      {
        do /*0x10313331b*/
        {
          v9 = v7; /*0x1031332e3*/
          v10 = *(_QWORD *)(a1 + 8); /*0x1031332e9*/
          v11 = *(_QWORD *)(v10 + 8 * v9); /*0x1031332f1*/
          *(_QWORD *)(*(_QWORD *)a1 + 8 * v3) = *(_QWORD *)(*(_QWORD *)a1 + 8 * v9); /*0x1031332f7*/
          *(_QWORD *)(v10 + 8 * v3) = v11; /*0x1031332fb*/
          *(_BYTE *)(*(_QWORD *)(a1 + 16) + v3) = v8 - 1; /*0x103133303*/
          v7 = v5 & (v9 + 1); /*0x10313330b*/
          v4 = *(_QWORD *)(a1 + 16); /*0x10313330e*/
          v8 = *(_BYTE *)(v4 + v7); /*0x103133312*/
          v3 = v9; /*0x103133315*/
        }
        while ( v8 >= 2u ); /*0x10313331b*/
      }
      else
      {
        v9 = v3; /*0x1031332de*/
      }
      *(_BYTE *)(v4 + v9) = 0; /*0x10313331d*/
      --*(_QWORD *)(a1 + 40); /*0x103133321*/
      return 0; /*0x103133325*/
    }
  }
  return result; /*0x103133328*/
}

// Address: 0x103133329 | Name: _nghttp3_map_clear
__int64 __fastcall nghttp3_map_clear(__int64 a1)
{
  __int64 result; // rax

  if ( *(_QWORD *)(a1 + 40) != 0 ) /*0x10313332e*/
  {
    result = __bzero(a1: *(_QWORD *)(a1 + 16), a2: 1LL << *(_BYTE *)(a1 + 48)); /*0x103133348*/
    *(_QWORD *)(a1 + 40) = 0; /*0x10313334d*/
  }
  return result; /*0x10313335b*/
}

// Address: 0x10313335c | Name: _nghttp3_map_size
__int64 __fastcall nghttp3_map_size(__int64 a1)
{
  return *(_QWORD *)(a1 + 40); /*0x103133364*/
}

// Address: 0x103133366 | Name: _nghttp3_mem_default
void *nghttp3_mem_default()
{
  return &mem_default_1; /*0x103133371*/
}

// Address: 0x103133373 | Name: _nghttp3_mem_malloc
__int64 __fastcall nghttp3_mem_malloc(__int64 a1, __int64 a2)
{
  return (*(__int64 (__fastcall **)(__int64, _QWORD))(a1 + 8))(a1: a2, a2: *(_QWORD *)a1);
}

// Address: 0x103133387 | Name: _nghttp3_mem_free
__int64 __fastcall nghttp3_mem_free(__int64 a1, __int64 a2)
{
  return (*(__int64 (__fastcall **)(__int64, _QWORD))(a1 + 16))(a1: a2, a2: *(_QWORD *)a1);
}

// Address: 0x10313339b | Name: _nghttp3_mem_calloc
__int64 __fastcall nghttp3_mem_calloc(__int64 a1, __int64 a2, __int64 a3)
{
  return (*(__int64 (__fastcall **)(__int64, __int64, _QWORD))(a1 + 24))(a1: a2, a2: a3, a3: *(_QWORD *)a1);
}

// Address: 0x1031333b2 | Name: _nghttp3_mem_realloc
__int64 __fastcall nghttp3_mem_realloc(__int64 a1, __int64 a2, __int64 a3)
{
  return (*(__int64 (__fastcall **)(__int64, __int64, _QWORD))(a1 + 32))(a1: a2, a2: a3, a3: *(_QWORD *)a1);
}

// Address: 0x1031333f1 | Name: _nghttp3_objalloc_init
__int64 __fastcall nghttp3_objalloc_init(_QWORD *a1, __int64 a2, __int64 a3)
{
  nghttp3_balloc_init(a1, a2, a3); /*0x1031333fa*/
  return nghttp3_opl_init(a1: a1 + 7); /*0x10313340a*/
}

// Address: 0x103133411 | Name: _nghttp3_objalloc_free
__int64 __fastcall nghttp3_objalloc_free(__int64 a1)
{
  return nghttp3_balloc_free(a1); /*0x103133415*/
}

// Address: 0x10313341b | Name: _nghttp3_objalloc_clear
__int64 __fastcall nghttp3_objalloc_clear(_QWORD *a1)
{
  nghttp3_opl_clear(a1: a1 + 7); /*0x103133428*/
  return nghttp3_balloc_clear(a1); /*0x103133434*/
}

// Address: 0x10313343b | Name: _nghttp3_opl_init
void __fastcall nghttp3_opl_init(_QWORD *a1)
{
  *a1 = 0; /*0x10313343f*/
}

// Address: 0x103133448 | Name: _nghttp3_opl_push
__int64 __fastcall nghttp3_opl_push(__int64 *a1, __int64 *a2)
{
  __int64 result; // rax

  result = *a1; /*0x10313344c*/
  *a2 = *a1; /*0x10313344f*/
  *a1 = (__int64)a2; /*0x103133452*/
  return result; /*0x103133455*/
}

// Address: 0x103133457 | Name: _nghttp3_opl_pop
_QWORD *__fastcall nghttp3_opl_pop(_QWORD **a1)
{
  _QWORD *result; // rax

  result = *a1; /*0x103133457*/
  if ( *a1 != nullptr ) /*0x10313345d*/
    *a1 = (_QWORD *)*result; /*0x103133466*/
  return result; /*0x10313346a*/
}

// Address: 0x10313346b | Name: _nghttp3_opl_clear
void __fastcall nghttp3_opl_clear(_QWORD *a1)
{
  *a1 = 0; /*0x10313346f*/
}

// Address: 0x103133478 | Name: _nghttp3_pq_init
void __fastcall nghttp3_pq_init(__int64 a1, __int64 a2, __int64 a3)
{
  *(_QWORD *)a1 = 0; /*0x10313347c*/
  *(_QWORD *)(a1 + 8) = a3; /*0x103133483*/
  *(_OWORD *)(a1 + 16) = 0; /*0x10313348a*/
  *(_QWORD *)(a1 + 32) = a2; /*0x10313348e*/
}

// Address: 0x103133494 | Name: _nghttp3_pq_free
__int64 __fastcall nghttp3_pq_free(__int64 *a1)
{
  __int64 result; // rax

  if ( a1 != nullptr ) /*0x10313349b*/
    return nghttp3_mem_free(a1: a1[1], a2: *a1); /*0x1031334a5*/
  return result; /*0x1031334a4*/
}

// Address: 0x1031334ac | Name: _nghttp3_pq_push
__int64 __fastcall nghttp3_pq_push(__int64 *a1, unsigned __int64 *a2)
{
  unsigned __int64 v4; // rcx
  __int64 v5; // rax
  unsigned __int64 v6; // rsi
  unsigned __int64 v7; // rcx
  __int64 v8; // r15

  v4 = a1[3]; /*0x1031334bc*/
  v5 = *a1; /*0x1031334c0*/
  v6 = a1[2]; /*0x1031334c3*/
  if ( v4 <= v6 ) /*0x1031334ca*/
  {
    v7 = 2 * v4; /*0x1031334cc*/
    v8 = 4; /*0x1031334d3*/
    if ( v7 >= 5 ) /*0x1031334d9*/
      v8 = v7; /*0x1031334d9*/
    v5 = nghttp3_mem_realloc(a1: a1[1], a2: v5, a3: 8 * v8); /*0x1031334ec*/
    if ( v5 == 0 ) /*0x1031334f4*/
      return 4294966395LL; /*0x103133525*/
    a1[3] = v8; /*0x1031334f6*/
    *a1 = v5; /*0x1031334fa*/
    v6 = a1[2]; /*0x1031334fd*/
  }
  *(_QWORD *)(v5 + 8 * v6) = a2; /*0x103133501*/
  *a2 = v6; /*0x103133505*/
  a1[2] = v6 + 1; /*0x10313350c*/
  bubble_up_0((__int64)a1, a2: v6); /*0x103133513*/
  return 0; /*0x10313351e*/
}

// Address: 0x10313358c | Name: _nghttp3_pq_top
__int64 __fastcall nghttp3_pq_top(__int64 a1)
{
  return **(_QWORD **)a1; /*0x103133596*/
}

// Address: 0x103133598 | Name: _nghttp3_pq_pop
__int64 __fastcall nghttp3_pq_pop(__int64 a1)
{
  __int64 v1; // rcx

  v1 = *(_QWORD *)(a1 + 16); /*0x10313359f*/
  **(_QWORD **)a1 = *(_QWORD *)(*(_QWORD *)a1 + 8 * v1 - 8); /*0x1031335a8*/
  ***(_QWORD ***)a1 = 0; /*0x1031335b1*/
  *(_QWORD *)(a1 + 16) = v1 - 1; /*0x1031335bb*/
  return bubble_down_0(a1, a2: 0); /*0x1031335c1*/
}

// Address: 0x103133648 | Name: _nghttp3_pq_remove
void __fastcall nghttp3_pq_remove(__int64 a1, unsigned __int64 *a2)
{
  __int64 v2; // rbx
  unsigned __int64 v3; // rax
  __int64 v4; // rdx
  __int64 v5; // rcx
  __int64 v6; // rcx
  unsigned __int64 v7; // rsi
  _QWORD *v9; // rdx
  int v10; // eax

  v2 = a1; /*0x10313364f*/
  v3 = *a2; /*0x103133652*/
  if ( *a2 == 0 ) /*0x103133658*/
  {
    v6 = *(_QWORD *)(a1 + 16); /*0x103133673*/
    **(_QWORD **)a1 = *(_QWORD *)(*(_QWORD *)a1 + 8 * v6 - 8); /*0x10313367c*/
    ***(_QWORD ***)a1 = 0; /*0x103133685*/
    *(_QWORD *)(a1 + 16) = v6 - 1; /*0x10313368f*/
    v7 = 0; /*0x103133696*/
LABEL_6:
    bubble_down_0(a1, a2: v7); /*0x1031336ce*/
    return; /*0x1031336d2*/
  }
  v4 = *(_QWORD *)(a1 + 16); /*0x10313365a*/
  v5 = v4 - 1; /*0x10313365e*/
  if ( v3 == v4 - 1 ) /*0x103133665*/
  {
    *(_QWORD *)(a1 + 16) = v3; /*0x103133667*/
    return; /*0x10313366f*/
  }
  *(_QWORD *)(*(_QWORD *)a1 + 8 * v3) = *(_QWORD *)(*(_QWORD *)a1 + 8 * v4 - 8); /*0x1031336a5*/
  v9 = *(_QWORD **)a1; /*0x1031336a9*/
  **(_QWORD **)(*(_QWORD *)a1 + 8 * v3) = v3; /*0x1031336b0*/
  *(_QWORD *)(a1 + 16) = v5; /*0x1031336b3*/
  v10 = (*(__int64 (__fastcall **)(unsigned __int64 *, _QWORD))(a1 + 32))(a1: a2, a2: v9[*a2]); /*0x1031336c1*/
  v7 = *a2; /*0x1031336c4*/
  a1 = v2; /*0x1031336c7*/
  if ( v10 != 0 ) /*0x1031336cc*/
    goto LABEL_6; /*0x1031336cc*/
  bubble_up_0(a1: v2, a2: v7); /*0x1031336db*/
}

// Address: 0x1031336e0 | Name: _nghttp3_pq_empty
_BOOL8 __fastcall nghttp3_pq_empty(__int64 a1)
{
  return *(_QWORD *)(a1 + 16) == 0; /*0x1031336ee*/
}

// Address: 0x1031336f0 | Name: _nghttp3_pq_size
__int64 __fastcall nghttp3_pq_size(__int64 a1)
{
  return *(_QWORD *)(a1 + 16); /*0x1031336f8*/
}

// Address: 0x1031336fa | Name: _nghttp3_pq_clear
void __fastcall nghttp3_pq_clear(__int64 a1)
{
  *(_QWORD *)(a1 + 16) = 0; /*0x1031336fe*/
}

// Address: 0x103133708 | Name: _nghttp3_qpack_encoder_init
void __fastcall nghttp3_qpack_encoder_init(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  nghttp3_ringbuf_init(a1, a2: 0, a3: 8); /*0x103133726*/
  *(_QWORD *)(a1 + 48) = a4; /*0x10313372b*/
  *(_OWORD *)(a1 + 56) = 0; /*0x103133732*/
  *(_QWORD *)(a1 + 72) = a2; /*0x103133736*/
  *(_OWORD *)(a1 + 80) = 0; /*0x103133741*/
  *(_OWORD *)(a1 + 89) = 0; /*0x103133745*/
  nghttp3_map_init(a1: a1 + 624, a2: a3, a3: a4); /*0x10313374f*/
  nghttp3_ksl_init(a1: a1 + 680, a2: (__int64)max_cnt_greater, a3: (__int64)ksl_max_cnt_greater_search, a4: 16, a5: a4); /*0x103133771*/
  __bzero(a1: a1 + 112, a2: 512); /*0x10313377f*/
  nghttp3_pq_init(a1: a1 + 808, a2: (__int64)ref_min_cnt_less, a3: a4); /*0x103133795*/
  *(_OWORD *)(a1 + 848) = 0; /*0x10313379d*/
  *(_QWORD *)(a1 + 1000) = -1; /*0x1031337a4*/
  *(_OWORD *)(a1 + 936) = 0; /*0x1031337b6*/
  *(_OWORD *)(a1 + 1008) = 0; /*0x1031337bd*/
  *(_QWORD *)(a1 + 1021) = 0; /*0x1031337c4*/
  nghttp3_buf_init(a1: (_OWORD *)(a1 + 872)); /*0x1031337cf*/
  nghttp3_buf_init(a1: (_OWORD *)(a1 + 904)); /*0x1031337db*/
  *(_OWORD *)(a1 + 980) = 0; /*0x1031337e3*/
  *(_OWORD *)(a1 + 968) = 0; /*0x1031337ea*/
  *(_OWORD *)(a1 + 952) = 0; /*0x1031337f1*/
}

// Address: 0x10313387e | Name: _nghttp3_qpack_read_state_reset
void __fastcall nghttp3_qpack_read_state_reset(__int64 a1)
{
  *(_OWORD *)(a1 + 72) = 0; /*0x10313388e*/
  nghttp3_buf_init(a1: (_OWORD *)(a1 + 8)); /*0x103133892*/
  nghttp3_buf_init(a1: (_OWORD *)(a1 + 40)); /*0x10313389b*/
  *(_OWORD *)(a1 + 116) = 0; /*0x1031338a3*/
  *(_OWORD *)(a1 + 104) = 0; /*0x1031338a7*/
  *(_OWORD *)(a1 + 88) = 0; /*0x1031338ab*/
}

// Address: 0x1031338b6 | Name: _nghttp3_qpack_encoder_free
__int64 __fastcall nghttp3_qpack_encoder_free(__int64 *a1)
{
  nghttp3_pq_free(a1: a1 + 101); /*0x1031338c7*/
  nghttp3_ksl_free(a1: (__int64)(a1 + 85)); /*0x1031338d3*/
  nghttp3_map_each(a1: a1 + 78, a2: (__int64 (__fastcall *)(_QWORD, __int64))map_stream_free, a3: a1[6]); /*0x1031338ed*/
  nghttp3_map_free(a1: a1 + 78); /*0x1031338f5*/
  return qpack_context_free(a1); /*0x1031338fd*/
}

// Address: 0x103133970 | Name: _nghttp3_qpack_encoder_set_max_dtable_capacity
unsigned __int64 __fastcall nghttp3_qpack_encoder_set_max_dtable_capacity(__int64 a1, unsigned __int64 a2)
{
  unsigned __int64 result; // rax

  result = *(_QWORD *)(a1 + 72); /*0x103133974*/
  if ( a2 < result ) /*0x10313397b*/
    result = a2; /*0x10313397b*/
  if ( *(_QWORD *)(a1 + 80) != result ) /*0x103133983*/
  {
    *(_BYTE *)(a1 + 1028) |= 1u; /*0x103133985*/
    if ( *(_QWORD *)(a1 + 1000) > result ) /*0x103133993*/
    {
      *(_QWORD *)(a1 + 1000) = result; /*0x103133995*/
      *(_QWORD *)(a1 + 80) = result; /*0x10313399c*/
    }
    *(_QWORD *)(a1 + 1008) = result; /*0x1031339a0*/
  }
  return result; /*0x1031339a7*/
}

// Address: 0x1031339a9 | Name: _nghttp3_qpack_encoder_set_max_blocked_streams
void __fastcall nghttp3_qpack_encoder_set_max_blocked_streams(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a1 + 88) = a2; /*0x1031339ad*/
}

// Address: 0x1031339b3 | Name: _nghttp3_qpack_encoder_set_indexing_strat
void __fastcall nghttp3_qpack_encoder_set_indexing_strat(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1024) = a2; /*0x1031339b7*/
}

// Address: 0x1031339bf | Name: _nghttp3_qpack_encoder_get_min_cnt
__int64 __fastcall nghttp3_qpack_encoder_get_min_cnt(__int64 a1)
{
  return *(_QWORD *)(nghttp3_pq_top(a1: a1 + 808) + 16); /*0x1031339d3*/
}

// Address: 0x1031339d5 | Name: _nghttp3_qpack_encoder_shrink_dtable
unsigned __int64 __fastcall nghttp3_qpack_encoder_shrink_dtable(_QWORD *a1)
{
  unsigned __int64 result; // rax
  __int64 v3; // r14
  __int64 v4; // r15
  __int64 v5; // r12
  __int64 v6; // rax
  _QWORD *v7; // r15
  __int64 v8; // rax
  _QWORD *v9; // rcx
  _QWORD *v10; // rax
  _QWORD *v11; // rax

  result = a1[7]; /*0x1031339d5*/
  if ( result > a1[10] ) /*0x1031339dd*/
  {
    v3 = a1[6]; /*0x1031339f4*/
    v4 = (__int64)(a1 + 101); /*0x1031339f8*/
    v5 = -1; /*0x103133a07*/
    if ( !nghttp3_pq_empty(a1: (__int64)(a1 + 101)) ) /*0x103133a02*/
      v5 = *(_QWORD *)(nghttp3_pq_top(a1: v4) + 16); /*0x103133a1a*/
    for ( result = a1[7]; result > a1[10]; result = a1[7] ) /*0x103133a26*/
    {
      v6 = nghttp3_ringbuf_get(a1, a2: a1[5] - 1LL); /*0x103133a3a*/
      v7 = *(_QWORD **)v6; /*0x103133a3f*/
      result = *(_QWORD *)(*(_QWORD *)v6 + 40LL) + 1LL; /*0x103133a46*/
      if ( result == v5 ) /*0x103133a4c*/
        break; /*0x103133a4c*/
      a1[7] = a1[7] - (*(_QWORD *)(v7[1] + 16LL) + *(_QWORD *)(*v7 + 16LL)) - 32LL; /*0x103133a6f*/
      nghttp3_ringbuf_pop_back(a1); /*0x103133a76*/
      v8 = v7[6] & 0x3F; /*0x103133a82*/
      v9 = (_QWORD *)a1[v8 + 14]; /*0x103133a85*/
      if ( v9 != nullptr ) /*0x103133a8d*/
      {
        if ( v9 == v7 ) /*0x103133a92*/
        {
          v11 = &a1[v8 + 14]; /*0x103133aab*/
LABEL_12:
          *v11 = v7[3]; /*0x103133aae*/
          v7[3] = 0; /*0x103133ab5*/
        }
        else
        {
          while ( 1 ) /*0x103133a94*/
          {
            v10 = v9; /*0x103133a94*/
            v9 = (_QWORD *)v9[3]; /*0x103133a97*/
            if ( v9 == nullptr ) /*0x103133a9e*/
              break; /*0x103133a9e*/
            if ( v9 == v7 ) /*0x103133aa3*/
            {
              v11 = v10 + 3; /*0x103133aa5*/
              goto LABEL_12; /*0x103133aa9*/
            }
          }
        }
      }
      nghttp3_rcbuf_decref(a1: v7[1]); /*0x103133ac1*/
      nghttp3_rcbuf_decref(a1: *v7); /*0x103133ac9*/
      nghttp3_mem_free(a1: v3, a2: (__int64)v7); /*0x103133ad4*/
    }
  }
  return result; /*0x103133af5*/
}

// Address: 0x103133af6 | Name: _nghttp3_qpack_entry_free
__int64 __fastcall nghttp3_qpack_entry_free(_QWORD *a1)
{
  nghttp3_rcbuf_decref(a1: a1[1]); /*0x103133b03*/
  return nghttp3_rcbuf_decref(a1: *a1); /*0x103133b0f*/
}

// Address: 0x103133b16 | Name: _nghttp3_qpack_encoder_encode
__int64 __fastcall nghttp3_qpack_encoder_encode(
        unsigned __int64 a1,
        __int64 a2,
        unsigned __int64 a3,
        __int64 a4,
        __int64 a5,
        int a6,
        __int64 a7)
{
  unsigned int v7; // r14d
  int v10; // r12d
  unsigned __int64 v11; // r13
  unsigned int v12; // eax
  __int64 v13; // rsi
  __int64 v14; // rbx
  unsigned __int64 v15; // r14
  _BOOL4 v16; // r13d
  unsigned int v17; // eax
  unsigned __int64 v18; // rbx
  _QWORD *v19; // r12
  __int64 *v20; // r15
  __int64 v21; // rbx
  unsigned __int64 max_cnt; // r13
  unsigned __int64 v23; // rbx
  unsigned __int64 v24; // rax
  __int64 v25; // r15
  __int64 v26; // rax
  unsigned __int64 v27; // r13
  __int64 v28; // rbx
  unsigned int v29; // eax
  unsigned int v30; // r12d
  bool v32; // cf
  __int64 v33; // r15
  __int64 *v34; // r15
  __int64 *v35; // r15
  unsigned int v36; // eax
  unsigned int v37; // ebx
  _QWORD v38[2]; // [rsp+8h] [rbp-88h] BYREF
  __int64 *v39; // [rsp+18h] [rbp-78h]
  __int64 *v40; // [rsp+20h] [rbp-70h] BYREF
  unsigned __int64 v41; // [rsp+28h] [rbp-68h] BYREF
  __int64 v42; // [rsp+30h] [rbp-60h] BYREF
  unsigned __int64 v43; // [rsp+38h] [rbp-58h]
  __int64 v44; // [rsp+40h] [rbp-50h]
  unsigned __int64 v45; // [rsp+48h] [rbp-48h]
  __int64 *v46; // [rsp+50h] [rbp-40h]
  __int64 v47; // [rsp+58h] [rbp-38h]
  unsigned __int64 v48; // [rsp+60h] [rbp-30h]

  v41 = 0; /*0x103133b27*/
  v42 = -1; /*0x103133b2f*/
  v7 = -108; /*0x103133b37*/
  if ( *(_BYTE *)(a1 + 104) != 0 ) /*0x103133b41*/
    return v7; /*0x103133b41*/
  v10 = a4; /*0x103133b4d*/
  v11 = a1; /*0x103133b50*/
  v43 = a3; /*0x103133b53*/
  v44 = a2; /*0x103133b57*/
  v12 = nghttp3_qpack_encoder_process_dtable_update(a1, a2: a4); /*0x103133b5e*/
  if ( v12 == 0 ) /*0x103133b65*/
  {
    v13 = a5; /*0x103133b6f*/
    v14 = a7; /*0x103133b72*/
    v47 = *(_QWORD *)(v11 + 96); /*0x103133b7a*/
    v39 = (__int64 *)(v11 + 624); /*0x103133b85*/
    v45 = v13; /*0x103133b89*/
    v46 = (__int64 *)nghttp3_map_find(a1: v11 + 624, a2: v13); /*0x103133b92*/
    v15 = v11; /*0x103133b99*/
    if ( v46 == nullptr || (v48 = *(_QWORD *)(v11 + 848), v16 = true, v48 >= nghttp3_qpack_stream_get_max_cnt(a1: v46)) ) /*0x103133bbc*/
    {
      v48 = *(_QWORD *)(v15 + 88); /*0x103133bc2*/
      v16 = v48 > nghttp3_ksl_len(a1: v15 + 680); /*0x103133bd9*/
    }
    v48 = v15; /*0x103133bdd*/
    if ( a7 == 0 ) /*0x103133be4*/
    {
      v7 = 0; /*0x103133d0e*/
      nghttp3_qpack_encoder_write_field_section_prefix(a1: v48, a2: v44, a3: 0, a4: v47); /*0x103133d22*/
      *(_QWORD *)(v48 + 1016) = 0; /*0x103133d27*/
      return v7; /*0x103133d32*/
    }
    do /*0x103133c1d*/
    {
      v17 = nghttp3_qpack_encoder_encode_nv( /*0x103133c05*/
              a1: v48,
              a2: (unsigned int)&v41,
              a3: (unsigned int)&v42,
              a4: v43,
              a5: v10,
              a6,
              a7: v47,
              a8: v16);
      if ( v17 != 0 ) /*0x103133c10*/
        goto LABEL_19; /*0x103133c10*/
      a6 += 40; /*0x103133c16*/
      --v14; /*0x103133c1a*/
    }
    while ( v14 != 0 ); /*0x103133c1d*/
    v18 = v41; /*0x103133c1f*/
    v19 = (_QWORD *)v48; /*0x103133c23*/
    nghttp3_qpack_encoder_write_field_section_prefix(a1: v48, a2: v44, a3: v41, a4: v47); /*0x103133c35*/
    v19[127] = 0; /*0x103133c3a*/
    v7 = 0; /*0x103133c46*/
    if ( v18 == 0 ) /*0x103133c4c*/
      return v7; /*0x103133c4c*/
    v43 = v18; /*0x103133c52*/
    v44 = v42; /*0x103133c5a*/
    v20 = v46; /*0x103133c5e*/
    v40 = v46; /*0x103133c62*/
    v21 = v19[6]; /*0x103133c66*/
    if ( v46 != nullptr ) /*0x103133c6e*/
    {
      v47 = v19[6]; /*0x103133c74*/
      max_cnt = nghttp3_qpack_stream_get_max_cnt(a1: v46); /*0x103133c80*/
      v23 = v19[106]; /*0x103133c83*/
      v24 = nghttp3_qpack_stream_get_max_cnt(a1: v20); /*0x103133c8e*/
      v45 = max_cnt; /*0x103133c99*/
      if ( v23 < v24 && max_cnt < v43 ) /*0x103133ca1*/
        nghttp3_qpack_encoder_unblock_stream(a1: v19, a2: v20); /*0x103133cb1*/
    }
    else
    {
      v17 = nghttp3_qpack_stream_new(a1: &v40, a2: v45, a3: v21); /*0x103133d3f*/
      if ( v17 != 0 ) /*0x103133d46*/
      {
LABEL_19:
        v7 = v17; /*0x103133d4c*/
        goto LABEL_20; /*0x103133d4c*/
      }
      v47 = v21; /*0x103133dec*/
      v35 = v40; /*0x103133df0*/
      v36 = nghttp3_map_insert(a1: v39, a2: *v40, a3: (__int64)v40); /*0x103133dfe*/
      if ( v36 != 0 ) /*0x103133e05*/
      {
        v37 = v36; /*0x103133e07*/
        nghttp3_qpack_stream_del(a1: v35, a2: v47); /*0x103133e10*/
        v7 = v37; /*0x103133e15*/
        goto LABEL_20; /*0x103133e18*/
      }
      v46 = v35; /*0x103133e1d*/
      v45 = 0; /*0x103133e21*/
    }
    v25 = v47; /*0x103133cbb*/
    v26 = nghttp3_mem_malloc(a1: v47, a2: 32); /*0x103133cc2*/
    v27 = v43; /*0x103133cca*/
    if ( v26 != 0 ) /*0x103133cce*/
    {
      v28 = v26; /*0x103133cd4*/
      *(_OWORD *)v26 = -1; /*0x103133cdb*/
      *(_QWORD *)(v26 + 16) = v27; /*0x103133cdf*/
      *(_QWORD *)(v26 + 24) = v44; /*0x103133ce7*/
      v29 = nghttp3_qpack_stream_add_ref(a1: v46, a2: v26); /*0x103133cf2*/
      if ( v29 == 0 ) /*0x103133cf9*/
      {
        v32 = v45 < v27; /*0x103133d72*/
        v11 = v48; /*0x103133d76*/
        if ( !v32 /*0x103133dc6*/
          || (v33 = *(_QWORD *)(v48 + 848)) >= (unsigned __int64)nghttp3_qpack_stream_get_max_cnt(a1: v46)
          || (v34 = v46,
              v38[0] = *(_QWORD *)(nghttp3_pq_top(a1: (__int64)(v46 + 7)) + 16),
              v38[1] = *v34,
              (v12 = nghttp3_ksl_insert(a1: v11 + 680, a2: nullptr, a3: v38, a4: (__int64)v34)) == 0) )
        {
          v12 = nghttp3_pq_push(a1: (__int64 *)(v11 + 808), a2: (unsigned __int64 *)(v28 + 8)); /*0x103133dda*/
          if ( v12 == 0 ) /*0x103133de1*/
            return v7; /*0x103133de1*/
        }
        goto LABEL_3; /*0x103133de1*/
      }
      v30 = v29; /*0x103133cfb*/
      nghttp3_mem_free(a1: v25, a2: v28); /*0x103133d04*/
      v7 = v30; /*0x103133d09*/
    }
    else
    {
      v7 = -901; /*0x103133d6a*/
    }
LABEL_20:
    v11 = v48; /*0x103133d4f*/
    goto LABEL_21; /*0x103133d4f*/
  }
LABEL_3:
  v7 = v12; /*0x103133b67*/
LABEL_21:
  *(_BYTE *)(v11 + 104) = 1; /*0x103133d53*/
  return v7; /*0x103133d5b*/
}

// Address: 0x103133e2e | Name: _nghttp3_qpack_encoder_process_dtable_update
__int64 __fastcall nghttp3_qpack_encoder_process_dtable_update(__int64 a1, __int64 a2)
{
  unsigned int v4; // ebx
  unsigned __int64 v5; // rdx
  unsigned int v6; // eax

  nghttp3_qpack_encoder_shrink_dtable((_QWORD *)a1); /*0x103133e3e*/
  v4 = 0; /*0x103133e47*/
  if ( *(_QWORD *)(a1 + 80) >= *(_QWORD *)(a1 + 56) && (*(_BYTE *)(a1 + 1028) & 1) != 0 ) /*0x103133e57*/
  {
    v5 = *(_QWORD *)(a1 + 1008); /*0x103133e60*/
    if ( *(_QWORD *)(a1 + 1000) < v5 ) /*0x103133e6a*/
    {
      v6 = qpack_write_number(a1: a2, a2: 32, a3: *(_QWORD *)(a1 + 1000), a4: 5, a5: *(_QWORD *)(a1 + 48)); /*0x103133e80*/
      if ( v6 != 0 ) /*0x103133e87*/
        return v6; /*0x103133eac*/
      v5 = *(_QWORD *)(a1 + 1008); /*0x103133e89*/
    }
    v6 = qpack_write_number(a1: a2, a2: 32, a3: v5, a4: 5, a5: *(_QWORD *)(a1 + 48)); /*0x103133ea1*/
    if ( v6 == 0 ) /*0x103133ea8*/
    {
      *(_BYTE *)(a1 + 1028) &= ~1u; /*0x103133eae*/
      *(_QWORD *)(a1 + 1000) = -1; /*0x103133eb6*/
      *(_QWORD *)(a1 + 80) = *(_QWORD *)(a1 + 1008); /*0x103133ec8*/
      return v4; /*0x103133ec8*/
    }
    return v6; /*0x103133ea8*/
  }
  return v4; /*0x103133ed2*/
}

// Address: 0x103133ed9 | Name: _nghttp3_qpack_encoder_find_stream
__int64 __fastcall nghttp3_qpack_encoder_find_stream(__int64 a1, __int64 a2)
{
  return nghttp3_map_find(a1: a1 + 624, a2); /*0x103133ee4*/
}

// Address: 0x103133eea | Name: _nghttp3_qpack_encoder_stream_is_blocked
_BOOL8 __fastcall nghttp3_qpack_encoder_stream_is_blocked(__int64 a1, __int64 a2)
{
  unsigned __int64 v2; // rbx

  if ( a2 == 0 ) /*0x103133eed*/
    return false; /*0x103133f16*/
  v2 = *(_QWORD *)(a1 + 848); /*0x103133ef5*/
  return v2 < nghttp3_qpack_stream_get_max_cnt(a1: a2); /*0x103133f15*/
}

// Address: 0x103133f19 | Name: _nghttp3_qpack_encoder_encode_nv
__int64 __fastcall nghttp3_qpack_encoder_encode_nv(
        __int64 a1,
        unsigned __int64 *a2,
        unsigned __int64 *a3,
        __int64 a4,
        __int64 a5,
        __int64 *a6,
        __int64 a7,
        unsigned int a8)
{
  __int64 v10; // r15
  __int64 v11; // rbx
  int v12; // eax
  __int64 *v13; // rsi
  int v14; // r12d
  char v15; // al
  unsigned int v16; // r14d
  int v17; // edx
  int v18; // edx
  __int64 v19; // r15
  __int64 result; // rax
  unsigned int v21; // r13d
  int v22; // ecx
  __int64 i; // rax
  __int64 v24; // rbx
  __int64 v25; // rdx
  __int64 v26; // r12
  unsigned __int64 v27; // rax
  unsigned __int64 v28; // r14
  __int64 v29; // r13
  __int64 v30; // rbx
  __int64 v31; // rax
  __int64 v32; // r15
  unsigned __int64 v33; // r14
  __int64 v34; // rax
  __int64 v35; // rcx
  __int64 *v36; // r9
  bool v37; // al
  __int64 *v38; // rbx
  int can_index; // eax
  __int64 v40; // r15
  __int64 *v41; // rbx
  __int64 v42; // r14
  __int64 v43; // rax
  unsigned __int64 v44; // rdx
  unsigned __int64 v45; // rdx
  __int64 v46; // rdi
  __int64 v47; // r14
  unsigned __int64 v48; // rdx
  unsigned __int64 v49; // rax
  unsigned __int64 v50; // rcx
  __int64 v51; // rsi
  __int64 *v52; // rbx
  int v53; // eax
  __int64 v54; // r14
  __int64 *v55; // rbx
  __int64 *v56; // rbx
  int v57; // eax
  __int64 v58; // rsi
  __int64 v59; // r14
  __int64 v60; // rax
  unsigned __int64 v61; // rdx
  unsigned __int64 v62; // rdx
  unsigned __int64 v63; // rcx
  unsigned __int64 v64; // rax
  unsigned __int64 v65; // rcx
  __int64 v66; // [rsp+0h] [rbp-80h] BYREF
  int v67; // [rsp+8h] [rbp-78h]
  __int64 v68; // [rsp+10h] [rbp-70h]
  __int64 *v69; // [rsp+18h] [rbp-68h]
  __int64 v70; // [rsp+20h] [rbp-60h]
  __int64 v71; // [rsp+28h] [rbp-58h]
  unsigned __int64 *v72; // [rsp+30h] [rbp-50h]
  __int64 v73; // [rsp+38h] [rbp-48h]
  unsigned __int64 *v74; // [rsp+40h] [rbp-40h]
  __int64 v75; // [rsp+48h] [rbp-38h]
  __int64 v76; // [rsp+50h] [rbp-30h]

  v70 = a5; /*0x103133f2d*/
  v74 = a3; /*0x103133f34*/
  v72 = a2; /*0x103133f38*/
  v76 = a1; /*0x103133f3c*/
  v73 = a8; /*0x103133f43*/
  v71 = a7; /*0x103133f4b*/
  v10 = *a6; /*0x103133f4f*/
  v11 = a6[2]; /*0x103133f52*/
  v12 = qpack_lookup_token(a1: *a6, a2: v11); /*0x103133f5c*/
  v13 = a6; /*0x103133f61*/
  v14 = v12; /*0x103133f64*/
  v15 = *((_BYTE *)a6 + 32); /*0x103133f67*/
  v16 = 2; /*0x103133f6c*/
  v69 = v13; /*0x103133f74*/
  if ( (v15 & 1) != 0 ) /*0x103133f78*/
  {
LABEL_22:
    if ( (unsigned int)v14 <= 0x62 ) /*0x103134033*/
      goto LABEL_23; /*0x103134033*/
LABEL_26:
    switch ( v14 ) /*0x1031340a0*/
    {
      case 1000: /*0x1031340a0*/
        v19 = -1; /*0x1031340a2*/
        v75 = a4; /*0x1031340a9*/
        v21 = -1342266001; /*0x1031340ad*/
        break; /*0x1031340b3*/
      case 1006: /*0x1031340a0*/
        v19 = -1; /*0x1031340ea*/
        v75 = a4; /*0x1031340f1*/
        v21 = 1011170994; /*0x1031340f5*/
        break; /*0x1031340fb*/
      case 1007: /*0x1031340a0*/
        v19 = -1; /*0x1031340d4*/
        v75 = a4; /*0x1031340db*/
        v21 = 1128642621; /*0x1031340df*/
        break; /*0x1031340e5*/
      case 1008: /*0x1031340a0*/
        v19 = -1; /*0x1031340fd*/
        v75 = a4; /*0x103134104*/
        v21 = -1796938999; /*0x103134108*/
        break; /*0x10313410e*/
      default:
        goto LABEL_35;
    }
    goto LABEL_40; /*0x10313410e*/
  }
  if ( v14 <= 54 ) /*0x103133f82*/
  {
    if ( v14 > 42 ) /*0x103133fac*/
    {
      if ( v14 != 43 ) /*0x103133fe3*/
      {
        if ( v14 == 45 ) /*0x103133fe9*/
          goto LABEL_23; /*0x103133fe9*/
        goto LABEL_18; /*0x103133fe9*/
      }
    }
    else
    {
      if ( v14 == -1 ) /*0x103133fb2*/
      {
        v22 = *(_DWORD *)(v76 + 1024); /*0x103134114*/
        if ( v22 != 1 ) /*0x10313411d*/
        {
          if ( v22 != 0 ) /*0x103134125*/
            nghttp3_unreachable_fail(a1: "nghttp3_qpack.c", a2: 1332, a3: "qpack_encoder_decide_indexing_mode"); /*0x103134688*/
          v16 = 0; /*0x10313412b*/
          if ( (v15 & 8) == 0 ) /*0x103134130*/
          {
LABEL_35:
            v75 = a4; /*0x103134136*/
            if ( v11 != 0 ) /*0x10313413d*/
            {
              v21 = -2128831035; /*0x10313413f*/
              for ( i = 0; i != v11; ++i ) /*0x103134145*/
                v21 = 16777619 * (v21 ^ *(unsigned __int8 *)(v10 + i)); /*0x10313414f*/
              v19 = -1; /*0x10313415e*/
            }
            else
            {
              v19 = -1; /*0x103134167*/
              v21 = -2128831035; /*0x10313416e*/
            }
            goto LABEL_40; /*0x103134165*/
          }
        }
        goto LABEL_21; /*0x103134130*/
      }
      if ( v14 != 8 ) /*0x103133fbc*/
        goto LABEL_18; /*0x103133fbc*/
    }
    goto LABEL_20; /*0x103133fbc*/
  }
  if ( (unsigned int)(v14 - 68) <= 0x11 ) /*0x103133f8c*/
  {
    v17 = 133320; /*0x103133f8e*/
    if ( _bittest(&v17, v14 - 68) ) /*0x103133f96*/
      goto LABEL_20; /*0x103133f96*/
    if ( v14 == 68 ) /*0x103133f9a*/
    {
      if ( (unsigned __int64)v13[3] >= 0x14 ) /*0x103133fa1*/
      {
LABEL_21:
        v16 = v11 + v13[3] + 32 <= (unsigned __int64)(3LL * *(_QWORD *)(v76 + 80)) >> 2; /*0x10313400a*/
        goto LABEL_22; /*0x10313402b*/
      }
LABEL_23:
      nghttp3_qpack_lookup_stable(a1: &v66, a2: v13, a3: (unsigned int)v14, a4: v16); /*0x103134035*/
      v19 = v66; /*0x103134047*/
      if ( v66 != -1 && v67 != 0 ) /*0x103134054*/
        return qpack_write_number(a1: a4, a2: 192, a3: v66, a4: 6, a5: *(_QWORD *)(v76 + 48)); /*0x10313407c*/
      v75 = a4; /*0x1031340b8*/
      v21 = token_stable[4 * v14 + 3]; /*0x1031340ca*/
LABEL_40:
      v24 = v76; /*0x103134174*/
      if ( (unsigned __int64)nghttp3_map_size(a1: v76 + 624) > 0x7CF ) /*0x10313418a*/
      {
        v35 = v19; /*0x1031342c1*/
        v36 = v69; /*0x1031342c8*/
        if ( v19 != -1 ) /*0x1031342cc*/
          return qpack_encoder_write_indexed_name( /*0x1031342cc*/
                   a1: v24,
                   a2: v75,
                   a3: (32 * *((_BYTE *)v36 + 32)) & 0x20 | 0x50u,
                   a4: v35,
                   a5: 4,
                   a6: v36);
        return qpack_encoder_write_literal( /*0x1031342cc*/
                 a1: v24,
                 a2: v75,
                 a3: (16 * *((_BYTE *)v36 + 32)) & 0x10 | 0x20u,
                 a4: 3,
                 a5: v36);
      }
      nghttp3_qpack_encoder_lookup_dtable( /*0x1031341b0*/
        a1: (unsigned int)&v66,
        a2: v24,
        a3: (_DWORD)v69,
        a4: v14,
        a5: v21,
        a6: v16,
        a7: *(_QWORD *)(v24 + 848),
        a8: v73);
      v25 = v66; /*0x1031341b9*/
      if ( v66 == -1 || v67 == 0 ) /*0x1031341d9*/
      {
        v37 = v68 != -1 || v16 != 1; /*0x103134300*/
        if ( v19 != -1 ) /*0x103134306*/
        {
          v35 = v19; /*0x10313430c*/
          v36 = v69; /*0x103134311*/
          v24 = v76; /*0x103134315*/
          if ( !v37 ) /*0x103134319*/
          {
            v38 = v69; /*0x103134335*/
            can_index = qpack_encoder_can_index(a1: v76, a2: v69[2] + v69[3] + 32, a3: *v74); /*0x103134338*/
            v35 = v19; /*0x10313433d*/
            v36 = v38; /*0x103134340*/
            v24 = v76; /*0x103134343*/
            if ( can_index != 0 ) /*0x103134349*/
            {
              v40 = v76; /*0x10313435d*/
              v41 = v36; /*0x103134360*/
              v42 = v35; /*0x103134363*/
              result = qpack_encoder_write_indexed_name(a1: v76, a2: v70, a3: 192, a4: v35, a5: 6, a6: v36); /*0x103134366*/
              if ( (_DWORD)result != 0 ) /*0x10313436d*/
                return result; /*0x10313436d*/
              result = nghttp3_qpack_encoder_dtable_static_add(a1: v40, a2: v42, a3: v41, a4: v21); /*0x10313437f*/
              if ( (_DWORD)result != 0 ) /*0x103134386*/
                return result; /*0x103134386*/
              v36 = v41; /*0x103134390*/
              v35 = v42; /*0x103134393*/
              v24 = v40; /*0x103134396*/
              if ( (_DWORD)v73 != 0 ) /*0x103134399*/
                goto LABEL_59; /*0x103134399*/
            }
          }
          return qpack_encoder_write_indexed_name( /*0x1031342fb*/
                   a1: v24,
                   a2: v75,
                   a3: (32 * *((_BYTE *)v36 + 32)) & 0x20 | 0x50u,
                   a4: v35,
                   a5: 4,
                   a6: v36);
        }
        v36 = v69; /*0x1031343f1*/
        if ( v66 != -1 ) /*0x1031343f5*/
        {
          if ( !v37 ) /*0x1031343f9*/
          {
            if ( (_DWORD)v73 != 0 ) /*0x103134403*/
            {
              v47 = v66; /*0x103134409*/
              v48 = *v74; /*0x103134410*/
            }
            else
            {
              v47 = v66; /*0x103134515*/
              v48 = *v74; /*0x103134520*/
              if ( v66 + 1 < *v74 ) /*0x103134526*/
                v48 = v66 + 1; /*0x103134526*/
            }
            v56 = v69; /*0x10313453e*/
            v57 = qpack_encoder_can_index(a1: v76, a2: v69[2] + v69[3] + 32, a3: v48); /*0x103134541*/
            v36 = v56; /*0x103134546*/
            v25 = v47; /*0x10313454b*/
            if ( v57 != 0 ) /*0x10313454e*/
            {
              result = qpack_encoder_write_indexed_name( /*0x103134574*/
                         a1: v76,
                         a2: v70,
                         a3: 128,
                         a4: *(_QWORD *)(v76 + 96) + ~v47,
                         a5: 6,
                         a6: v56);
              if ( (_DWORD)result != 0 ) /*0x10313457b*/
                return result; /*0x10313457b*/
              v58 = v47; /*0x10313458c*/
              if ( (_DWORD)v73 != 0 ) /*0x103134593*/
              {
                v59 = v76; /*0x103134595*/
                result = nghttp3_qpack_encoder_dtable_dynamic_add(a1: v76, a2: v58, a3: v56, a4: v21); /*0x1031345a2*/
                if ( (_DWORD)result != 0 ) /*0x1031345a9*/
                  return result; /*0x1031345a9*/
                v60 = *(_QWORD *)nghttp3_ringbuf_get(a1: v59, a2: 0); /*0x1031345b5*/
                v61 = *(_QWORD *)(v60 + 40) + 1LL; /*0x1031345c3*/
                if ( *v72 > v61 ) /*0x1031345c9*/
                  v61 = *v72; /*0x1031345c9*/
                *v72 = v61; /*0x1031345cd*/
                v62 = *(_QWORD *)(v60 + 40) + 1LL; /*0x1031345db*/
                if ( *v74 < v62 ) /*0x1031345e1*/
                  v62 = *v74; /*0x1031345e1*/
                *v74 = v62; /*0x1031345e5*/
                v25 = *(_QWORD *)(v60 + 40); /*0x1031345e8*/
                v46 = v59; /*0x1031345ec*/
LABEL_94:
                v51 = v75; /*0x1031345ef*/
                return nghttp3_qpack_encoder_write_dynamic_indexed(a1: v46, a2: v51, a3: v25, a4: v71); /*0x10313445b*/
              }
              v63 = v47 + 1; /*0x103134602*/
              if ( *v74 < v47 + 1 ) /*0x103134609*/
                v63 = *v74; /*0x103134609*/
              *v74 = v63; /*0x10313460d*/
              result = nghttp3_qpack_encoder_dtable_dynamic_add(a1: v76, a2: v47, a3: v56, a4: v21); /*0x10313461a*/
              v25 = v47; /*0x10313461f*/
              v36 = v56; /*0x103134622*/
              if ( (_DWORD)result != 0 ) /*0x103134627*/
                return result; /*0x103134627*/
            }
          }
          v64 = *v72; /*0x103134631*/
          v65 = v25 + 1; /*0x103134634*/
          if ( *v72 <= v25 + 1 ) /*0x10313463b*/
            v64 = v25 + 1; /*0x10313463b*/
          *v72 = v64; /*0x10313463f*/
          if ( *v74 < v65 ) /*0x10313464c*/
            v65 = *v74; /*0x10313464c*/
          *v74 = v65; /*0x103134650*/
          return nghttp3_qpack_encoder_write_dynamic_indexed_name(a1: v76, a2: v75, a3: v25, a4: v71, a5: v36); /*0x103134670*/
        }
        v24 = v76; /*0x103134462*/
        if ( !v37 ) /*0x103134466*/
        {
          v52 = v69; /*0x103134482*/
          v53 = qpack_encoder_can_index(a1: v76, a2: v69[2] + v69[3] + 32, a3: *v74); /*0x103134485*/
          v36 = v52; /*0x10313448a*/
          v24 = v76; /*0x10313448d*/
          if ( v53 != 0 ) /*0x103134493*/
          {
            v54 = v76; /*0x1031344a1*/
            v55 = v36; /*0x1031344a4*/
            result = nghttp3_qpack_encoder_dtable_literal_add(a1: v76, a2: v36, a3: (unsigned int)v14, a4: v21); /*0x1031344a7*/
            if ( (_DWORD)result != 0 ) /*0x1031344ae*/
              return result; /*0x1031344ae*/
            result = qpack_encoder_write_literal(a1: v54, a2: v70, a3: 64, a4: 5, a5: v55); /*0x1031344c8*/
            if ( (_DWORD)result != 0 ) /*0x1031344cf*/
              return result; /*0x1031344cf*/
            v36 = v55; /*0x1031344d9*/
            v24 = v54; /*0x1031344dc*/
            if ( (_DWORD)v73 != 0 ) /*0x1031344df*/
            {
LABEL_59:
              v43 = *(_QWORD *)nghttp3_ringbuf_get(a1: v24, a2: 0); /*0x10313439f*/
              v44 = *(_QWORD *)(v43 + 40) + 1LL; /*0x1031343b7*/
              if ( *v72 > v44 ) /*0x1031343bd*/
                v44 = *v72; /*0x1031343bd*/
              *v72 = v44; /*0x1031343c1*/
              v45 = *(_QWORD *)(v43 + 40) + 1LL; /*0x1031343cf*/
              if ( *v74 < v45 ) /*0x1031343d5*/
                v45 = *v74; /*0x1031343d5*/
              *v74 = v45; /*0x1031343d9*/
              v25 = *(_QWORD *)(v43 + 40); /*0x1031343dc*/
              v46 = v24; /*0x1031343e0*/
              goto LABEL_94; /*0x1031343e3*/
            }
          }
        }
        return qpack_encoder_write_literal( /*0x103134510*/
                 a1: v24,
                 a2: v75,
                 a3: (16 * *((_BYTE *)v36 + 32)) & 0x10 | 0x20u,
                 a4: 3,
                 a5: v36);
      }
      if ( (_DWORD)v73 == 0 ) /*0x1031341e3*/
      {
        v32 = v75; /*0x103134418*/
        goto LABEL_70; /*0x103134418*/
      }
      v26 = v76; /*0x1031341e9*/
      v27 = *(_QWORD *)(v76 + 80) >> 3; /*0x1031341f5*/
      if ( v27 >= 0x200 ) /*0x103134201*/
        v27 = 512; /*0x103134201*/
      v28 = *(_QWORD *)(v76 + 80) - v27; /*0x103134205*/
      v29 = v66; /*0x103134208*/
      v30 = ~v66; /*0x10313420e*/
      v31 = nghttp3_ringbuf_get(a1: v76, a2: ~v66 + *(_QWORD *)(v76 + 96)); /*0x10313421c*/
      v32 = v75; /*0x103134230*/
      if ( *(_QWORD *)(v26 + 64) - *(_QWORD *)(*(_QWORD *)v31 + 32LL) <= v28 /*0x103134278*/
        || (v33 = *v74,
            v34 = nghttp3_ringbuf_get(a1: v26, a2: *(_QWORD *)(v26 + 96) + v30),
            (unsigned int)qpack_encoder_can_index(
                            a1: v26,
                            a2: *(_QWORD *)(**(_QWORD **)v34 + 16LL)
                          + *(_QWORD *)(*(_QWORD *)(*(_QWORD *)v34 + 8LL) + 16LL)
                          + 32LL,
                            a3: v33) == 0) )
      {
        v25 = v29; /*0x1031343e8*/
        goto LABEL_70; /*0x1031343eb*/
      }
      result = nghttp3_qpack_encoder_write_duplicate_insert(a1: v26, a2: v70, a3: v29); /*0x10313428b*/
      if ( (_DWORD)result == 0 ) /*0x103134292*/
      {
        result = nghttp3_qpack_encoder_dtable_duplicate_add(a1: v26, a2: v29); /*0x10313429e*/
        if ( (_DWORD)result == 0 ) /*0x1031342a5*/
        {
          v25 = *(_QWORD *)(*(_QWORD *)nghttp3_ringbuf_get(a1: v26, a2: 0) + 40LL); /*0x1031342b8*/
LABEL_70:
          v49 = *v72; /*0x10313441c*/
          v50 = v25 + 1; /*0x103134423*/
          if ( *v72 <= v25 + 1 ) /*0x10313442a*/
            v49 = v25 + 1; /*0x10313442a*/
          *v72 = v49; /*0x10313442e*/
          if ( *v74 < v50 ) /*0x10313443b*/
            v50 = *v74; /*0x10313443b*/
          *v74 = v50; /*0x10313443f*/
          v46 = v76; /*0x103134442*/
          v51 = v32; /*0x103134446*/
          return nghttp3_qpack_encoder_write_dynamic_indexed(a1: v46, a2: v51, a3: v25, a4: v71); /*0x103134446*/
        }
      }
      return result; /*0x10313406e*/
    }
  }
  if ( (unsigned int)(v14 - 1000) <= 8 ) /*0x103133fcb*/
  {
    v18 = 449; /*0x103133fcd*/
    if ( _bittest(&v18, v14 - 1000) ) /*0x103133fd5*/
      goto LABEL_21; /*0x103133fd5*/
  }
  if ( v14 != 55 ) /*0x103133fdb*/
  {
LABEL_18:
    v16 = 0; /*0x103133feb*/
    if ( (v15 & 8) == 0 && (unsigned int)v14 >= 0x3E8 ) /*0x103133ff7*/
      goto LABEL_26; /*0x103133fff*/
    goto LABEL_21; /*0x103133fff*/
  }
LABEL_20:
  v16 = 0; /*0x103134003*/
  if ( (v15 & 8) == 0 ) /*0x103134008*/
    goto LABEL_23; /*0x103134008*/
  goto LABEL_21; /*0x103134008*/
}

// Address: 0x1031346b4 | Name: _nghttp3_qpack_encoder_write_field_section_prefix
__int64 __fastcall nghttp3_qpack_encoder_write_field_section_prefix(
        __int64 a1,
        __int64 a2,
        unsigned __int64 a3,
        unsigned __int64 a4)
{
  __int64 v6; // rsi
  char v7; // r13
  unsigned __int64 v9; // rdx
  unsigned __int64 v10; // r12
  unsigned __int64 v11; // rax
  bool v12; // cf
  char v13; // r15
  unsigned __int64 v14; // rdx
  __int64 v15; // rax
  unsigned __int64 v16; // rcx
  bool v17; // cc
  unsigned __int64 v18; // rcx
  unsigned __int64 v19; // rdx
  __int64 result; // rax
  _BYTE *v21; // rcx
  _BYTE *v22; // rax
  unsigned __int64 v23; // r12
  unsigned __int64 v24; // rcx
  char v25; // r15
  _BYTE *v26; // rcx
  unsigned __int64 v27; // r14
  unsigned __int64 v28; // rax

  v6 = 1; /*0x1031346c8*/
  v7 = 1; /*0x1031346cd*/
  if ( a3 == 0 ) /*0x1031346d3*/
  {
    v13 = 0; /*0x10313473d*/
    v10 = 0; /*0x103134740*/
LABEL_10:
    v15 = 1; /*0x103134743*/
    goto LABEL_11; /*0x103134743*/
  }
  v9 = a3 % ((*(_QWORD *)(a1 + 72) >> 4) & 0xFFFFFFFFFFFFFFFELL); /*0x1031346e9*/
  v10 = v9 + 1; /*0x1031346ec*/
  v11 = a3 + ~a4; /*0x1031346f6*/
  v12 = a4 < a3; /*0x1031346f9*/
  a4 -= a3; /*0x1031346f9*/
  v13 = v12; /*0x1031346fc*/
  if ( v12 ) /*0x103134700*/
    a4 = v11; /*0x103134700*/
  if ( v9 < 0xFE ) /*0x10313470b*/
    goto LABEL_10; /*0x10313470b*/
  v14 = v9 - 254; /*0x10313470d*/
  v15 = 2; /*0x103134714*/
  if ( v14 >= 0x80 ) /*0x103134720*/
  {
    v16 = v14; /*0x103134722*/
    do /*0x103134736*/
    {
      v16 >>= 7; /*0x103134725*/
      ++v15; /*0x103134729*/
      v17 = v14 <= 0x3FFF; /*0x10313472c*/
      v14 = v16; /*0x103134733*/
    }
    while ( !v17 ); /*0x103134736*/
  }
  v7 = 0; /*0x103134738*/
LABEL_11:
  if ( a4 >= 0x7F ) /*0x10313474c*/
  {
    v18 = a4 - 127; /*0x10313474e*/
    v6 = 2; /*0x103134752*/
    if ( a4 - 127 >= 0x80 ) /*0x10313475e*/
    {
      v19 = a4 - 127; /*0x103134760*/
      do /*0x103134774*/
      {
        v19 >>= 7; /*0x103134763*/
        ++v6; /*0x103134767*/
        v17 = v18 <= 0x3FFF; /*0x10313476a*/
        v18 = v19; /*0x103134771*/
      }
      while ( !v17 ); /*0x103134774*/
    }
  }
  result = reserve_buf(a1: a2, a2: v15 + v6, a3: *(_QWORD *)(a1 + 48)); /*0x103134780*/
  if ( (_DWORD)result == 0 ) /*0x103134787*/
  {
    v21 = *(_BYTE **)(a2 + 24); /*0x10313478d*/
    v22 = v21 + 1; /*0x103134791*/
    if ( v7 != 0 ) /*0x103134798*/
    {
      *v21 = v10; /*0x10313479a*/
    }
    else
    {
      *v21 = -1; /*0x10313479f*/
      v23 = v10 - 255; /*0x1031347a2*/
      if ( v23 >= 0x80 ) /*0x1031347b0*/
      {
        do /*0x1031347ca*/
        {
          v24 = v23; /*0x1031347b2*/
          *v22 = v23 | 0x80; /*0x1031347ba*/
          v23 >>= 7; /*0x1031347bc*/
          ++v22; /*0x1031347c0*/
        }
        while ( v24 > 0x3FFF ); /*0x1031347ca*/
        v21 = v22 - 1; /*0x1031347cc*/
      }
      *v22 = v23; /*0x1031347d4*/
      v22 = v21 + 2; /*0x1031347d7*/
    }
    v25 = v13 << 7; /*0x1031347da*/
    v26 = v22 + 1; /*0x1031347de*/
    if ( a4 > 0x7E ) /*0x1031347e6*/
    {
      *v22 = v25 | 0x7F; /*0x1031347f4*/
      v27 = a4 - 127; /*0x1031347f7*/
      if ( v27 >= 0x80 ) /*0x103134802*/
      {
        do /*0x10313481b*/
        {
          v28 = v27; /*0x103134804*/
          *v26 = v27 | 0x80; /*0x10313480c*/
          v27 >>= 7; /*0x10313480e*/
          ++v26; /*0x103134812*/
        }
        while ( v28 > 0x3FFF ); /*0x10313481b*/
        v22 = v26 - 1; /*0x10313481d*/
      }
      *v26 = v27; /*0x103134825*/
      v26 = v22 + 2; /*0x103134828*/
    }
    else
    {
      *v22 = a4 | v25; /*0x1031347eb*/
    }
    *(_QWORD *)(a2 + 24) = v26; /*0x10313482b*/
    return 0; /*0x10313482f*/
  }
  return result; /*0x103134835*/
}

// Address: 0x103134840 | Name: _nghttp3_qpack_encoder_write_set_dtable_cap
__int64 __fastcall nghttp3_qpack_encoder_write_set_dtable_cap(__int64 a1, __int64 a2, __int64 a3)
{
  return qpack_write_number(a1: a2, a2: 32, a3, a4: 5, a5: *(_QWORD *)(a1 + 48)); /*0x103134855*/
}

// Address: 0x1031348e7 | Name: _nghttp3_qpack_stream_get_max_cnt
__int64 __fastcall nghttp3_qpack_stream_get_max_cnt(__int64 a1)
{
  __int64 v1; // rbx

  v1 = a1 + 56; /*0x1031348f0*/
  if ( nghttp3_pq_empty(a1: a1 + 56) ) /*0x1031348f7*/
    return 0; /*0x103134900*/
  else
    return *(_QWORD *)(nghttp3_pq_top(a1: v1) + 16); /*0x10313490c*/
}

// Address: 0x10313556c | Name: _nghttp3_qpack_lookup_stable
__int64 __fastcall nghttp3_qpack_lookup_stable(__int64 a1, __int64 a2, signed int a3, int a4)
{
  __int64 v5; // r9
  __int64 v6; // rax
  __int64 v7; // r12
  _DWORD *i; // r13
  __int64 v9; // rbx
  size_t v10; // rdx
  int v11; // eax

  v5 = a2; /*0x103135580*/
  v6 = 4LL * a3; /*0x103135589*/
  *(_QWORD *)a1 = *(_QWORD *)&token_stable[v6]; /*0x103135598*/
  *(_DWORD *)(a1 + 8) = 0; /*0x10313559b*/
  *(_QWORD *)(a1 + 16) = -1; /*0x1031355a6*/
  if ( a4 != 2 && (unsigned int)a3 < 0x63 ) /*0x1031355b8*/
  {
    v7 = a3 - 99LL; /*0x1031355c1*/
    for ( i = &token_stable[v6 + 2]; *i == a3; i += 4 ) /*0x1031355c9*/
    {
      v9 = *((_QWORD *)i - 1); /*0x1031355de*/
      v10 = *((_QWORD *)&stable + 9 * v9 + 6); /*0x1031355e6*/
      if ( v10 == *(_QWORD *)(v5 + 24) ) /*0x1031355ef*/
      {
        if ( v10 == 0 /*0x103135611*/
          || (v11 = memcmp(__s1: *((const void **)&stable + 9 * v9 + 5), __s2: *(const void **)(v5 + 8), __n: v10),
              v5 = a2,
              v11 == 0) )
        {
          *(_QWORD *)a1 = v9; /*0x103135622*/
          *(_DWORD *)(a1 + 8) = 1; /*0x103135625*/
          return a1; /*0x103135625*/
        }
      }
      if ( ++v7 == 0 ) /*0x10313561a*/
        return a1; /*0x10313561a*/
    }
  }
  return a1; /*0x103135630*/
}

// Address: 0x10313563f | Name: _nghttp3_qpack_encoder_write_static_indexed
__int64 __fastcall nghttp3_qpack_encoder_write_static_indexed(__int64 a1, __int64 a2, __int64 a3)
{
  return qpack_write_number(a1: a2, a2: 192, a3, a4: 6, a5: *(_QWORD *)(a1 + 48)); /*0x103135654*/
}

// Address: 0x10313565a | Name: _nghttp3_qpack_encoder_lookup_dtable
__int64 __fastcall nghttp3_qpack_encoder_lookup_dtable(
        __int64 a1,
        _QWORD *a2,
        __int64 a3,
        int a4,
        int a5,
        int a6,
        unsigned __int64 a7,
        int a8)
{
  _QWORD *v8; // r14
  _QWORD *v12; // r12
  bool v13; // zf
  _QWORD *v14; // rax
  size_t v15; // rdx
  int v16; // eax
  _QWORD *v17; // rdx
  __int64 v19; // [rsp+0h] [rbp-40h]
  _QWORD *v22; // [rsp+10h] [rbp-30h]

  *(_OWORD *)a1 = xmmword_1094C74E0; /*0x103135676*/
  *(_QWORD *)(a1 + 16) = -1; /*0x103135679*/
  v8 = (_QWORD *)a2[(a5 & 0x3F) + 14]; /*0x10313568b*/
  if ( v8 != nullptr ) /*0x103135693*/
  {
    v19 = a1; /*0x1031356a2*/
    v12 = nullptr; /*0x1031356a6*/
    v22 = nullptr; /*0x1031356a9*/
    do /*0x103135777*/
    {
      if ( *((_DWORD *)v8 + 4) == a4 /*0x1031356e3*/
        && (a4 != -1
         || *((_DWORD *)v8 + 12) == a5
         && (v15 = *(_QWORD *)(*v8 + 16LL)) == *(_QWORD *)(a3 + 16)
         && (v15 == 0 || memcmp(__s1: *(const void **)(*v8 + 8LL), __s2: *(const void **)a3, __n: v15) == 0))
        && a2[8] - *(_QWORD *)(*(_QWORD *)nghttp3_ringbuf_get(a1: a2, a2: a2[12] + ~v8[5]) + 32LL) <= a2[10] )
      {
        if ( a8 != 0 || v8[5] + 1LL <= a7 ) /*0x1031356fa*/
        {
          if ( a6 == 2 && v12 == nullptr ) /*0x103135758*/
          {
            v16 = 0; /*0x1031357c2*/
            goto LABEL_25; /*0x1031357c4*/
          }
          if ( v12 == nullptr ) /*0x10313575d*/
            v12 = v8; /*0x10313575d*/
          if ( (unsigned int)qpack_nv_value_eq(a1: v8, a2: a3) != 0 ) /*0x10313576e*/
          {
            v16 = 1; /*0x1031357c6*/
            goto LABEL_25; /*0x1031357cb*/
          }
        }
        else if ( v22 == nullptr ) /*0x103135701*/
        {
          v13 = (unsigned int)qpack_nv_value_eq(a1: v8, a2: a3) == 0; /*0x10313570e*/
          v14 = nullptr; /*0x103135710*/
          if ( !v13 ) /*0x103135715*/
            v14 = v8; /*0x103135715*/
          v22 = v14; /*0x103135719*/
        }
      }
      v8 = (_QWORD *)v8[3]; /*0x103135770*/
    }
    while ( v8 != nullptr ); /*0x103135777*/
    if ( v12 != nullptr ) /*0x103135780*/
    {
      v16 = 0; /*0x103135782*/
      v8 = v12; /*0x103135784*/
LABEL_25:
      v17 = v22; /*0x103135787*/
      a1 = v19; /*0x10313578f*/
      *(_QWORD *)v19 = v8[5]; /*0x103135793*/
      *(_DWORD *)(v19 + 8) = v16; /*0x103135796*/
      goto LABEL_27; /*0x103135799*/
    }
    a1 = v19; /*0x10313579b*/
    v17 = v22; /*0x10313579f*/
LABEL_27:
    if ( v17 != nullptr ) /*0x1031357a6*/
      *(_QWORD *)(a1 + 16) = v17[5]; /*0x1031357ac*/
  }
  return a1; /*0x1031357b3*/
}

// Address: 0x1031357cd | Name: _nghttp3_qpack_encoder_write_duplicate_insert
__int64 __fastcall nghttp3_qpack_encoder_write_duplicate_insert(__int64 a1, __int64 a2, __int64 a3)
{
  unsigned __int64 v4; // r14
  __int64 v5; // rsi
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rcx
  bool v8; // cf
  bool v9; // zf
  __int64 result; // rax
  _BYTE *v11; // rcx
  _BYTE *v12; // rax
  unsigned __int64 v13; // r14
  unsigned __int64 v14; // rcx

  v4 = *(_QWORD *)(a1 + 96) + ~a3; /*0x1031357dd*/
  v5 = 1; /*0x1031357e1*/
  if ( v4 >= 0x1F ) /*0x1031357ea*/
  {
    v6 = v4 - 31; /*0x1031357ec*/
    v5 = 2; /*0x1031357f0*/
    if ( v4 - 31 >= 0x80 ) /*0x1031357fb*/
    {
      v7 = v4 - 31; /*0x1031357fd*/
      do /*0x103135810*/
      {
        v7 >>= 7; /*0x103135800*/
        ++v5; /*0x103135804*/
        v8 = v6 < 0x3FFF; /*0x103135807*/
        v9 = v6 == 0x3FFF; /*0x103135807*/
        v6 = v7; /*0x10313580d*/
      }
      while ( !v8 && !v9 ); /*0x103135810*/
    }
  }
  result = reserve_buf(a1: a2, a2: v5, a3: *(_QWORD *)(a1 + 48)); /*0x103135819*/
  if ( (_DWORD)result == 0 ) /*0x103135820*/
  {
    v11 = *(_BYTE **)(a2 + 24); /*0x103135822*/
    v12 = v11 + 1; /*0x103135826*/
    if ( v4 > 0x1E ) /*0x10313582e*/
    {
      *v11 = 31; /*0x103135835*/
      v13 = v4 - 31; /*0x103135838*/
      if ( v13 >= 0x80 ) /*0x103135843*/
      {
        do /*0x10313585d*/
        {
          v14 = v13; /*0x103135845*/
          *v12 = v13 | 0x80; /*0x10313584d*/
          v13 >>= 7; /*0x10313584f*/
          ++v12; /*0x103135853*/
        }
        while ( v14 > 0x3FFF ); /*0x10313585d*/
        v11 = v12 - 1; /*0x10313585f*/
      }
      *v12 = v13; /*0x103135867*/
      v12 = v11 + 2; /*0x10313586a*/
    }
    else
    {
      *v11 = v4; /*0x103135830*/
    }
    *(_QWORD *)(a2 + 24) = v12; /*0x10313586d*/
    return 0; /*0x103135871*/
  }
  return result; /*0x103135873*/
}

// Address: 0x103135878 | Name: _nghttp3_qpack_encoder_dtable_duplicate_add
__int64 __fastcall nghttp3_qpack_encoder_dtable_duplicate_add(__int64 a1, __int64 a2)
{
  __int64 v2; // rbx
  __int128 **v3; // rax
  __int128 *v4; // r13
  __int64 v5; // r15
  __int64 v6; // r12
  __int128 v8; // [rsp+0h] [rbp-40h] BYREF
  __int64 v9; // [rsp+10h] [rbp-30h]

  v2 = a1; /*0x103135889*/
  v3 = (__int128 **)nghttp3_ringbuf_get(a1, a2: *(_QWORD *)(a1 + 96) + ~a2); /*0x103135893*/
  v4 = *v3; /*0x103135898*/
  v8 = **v3; /*0x1031358a4*/
  v9 = *((_QWORD *)v4 + 2); /*0x1031358ac*/
  v5 = v8; /*0x1031358b0*/
  nghttp3_rcbuf_incref(a1: v8); /*0x1031358b6*/
  v6 = *((_QWORD *)&v8 + 1); /*0x1031358bb*/
  nghttp3_rcbuf_incref(a1: *((_QWORD *)&v8 + 1)); /*0x1031358c2*/
  LODWORD(v2) = nghttp3_qpack_context_dtable_add(a1: v2, a2: &v8, a3: v2 + 112, a4: *((unsigned int *)v4 + 12)); /*0x1031358da*/
  nghttp3_rcbuf_decref(a1: v5); /*0x1031358df*/
  nghttp3_rcbuf_decref(a1: v6); /*0x1031358e7*/
  return (unsigned int)v2; /*0x1031358ee*/
}

// Address: 0x1031358fd | Name: _nghttp3_qpack_context_dtable_top
__int64 __fastcall nghttp3_qpack_context_dtable_top(__int64 a1)
{
  return *(_QWORD *)nghttp3_ringbuf_get(a1, a2: 0); /*0x10313590b*/
}

// Address: 0x10313590d | Name: _nghttp3_qpack_encoder_write_dynamic_indexed
__int64 __fastcall nghttp3_qpack_encoder_write_dynamic_indexed(
        __int64 a1,
        __int64 a2,
        unsigned __int64 a3,
        unsigned __int64 a4)
{
  if ( a3 >= a4 ) /*0x103135917*/
    return qpack_write_number(a1: a2, a2: 16, a3: a3 - a4, a4: 4, a5: *(_QWORD *)(a1 + 48)); /*0x10313594b*/
  else
    return qpack_write_number(a1: a2, a2: 128, a3: a4 + ~a3, a4: 6, a5: *(_QWORD *)(a1 + 48)); /*0x103135931*/
}

// Address: 0x103135950 | Name: _nghttp3_qpack_encoder_write_static_insert
__int64 __fastcall nghttp3_qpack_encoder_write_static_insert(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  return qpack_encoder_write_indexed_name(a1, a2, a3: 192, a4: a3, a5: 6, a6: a4); /*0x103135965*/
}

// Address: 0x10313596b | Name: _nghttp3_qpack_encoder_dtable_static_add
__int64 __fastcall nghttp3_qpack_encoder_dtable_static_add(__int64 a1, __int64 a2, __int64 a3, unsigned int a4)
{
  unsigned int v7; // r12d
  char *v9; // [rsp+8h] [rbp-38h] BYREF
  __int64 v10; // [rsp+10h] [rbp-30h] BYREF
  int v11; // [rsp+18h] [rbp-28h]
  char v12; // [rsp+1Ch] [rbp-24h]

  v7 = nghttp3_rcbuf_new2(a1: &v10, a2: *(_QWORD *)(a3 + 8), a3: *(_QWORD *)(a3 + 24), a4: *(_QWORD *)(a1 + 48)); /*0x103135997*/
  if ( v7 == 0 ) /*0x10313599c*/
  {
    v9 = (char *)&stable + 72 * a2; /*0x1031359b1*/
    v11 = *((_DWORD *)v9 + 16); /*0x1031359b7*/
    v12 = 0; /*0x1031359bb*/
    v7 = nghttp3_qpack_context_dtable_add(a1, a2: &v9, a3: a1 + 112, a4); /*0x1031359d1*/
    nghttp3_rcbuf_decref(a1: v10); /*0x1031359d8*/
  }
  return v7; /*0x1031359e0*/
}

// Address: 0x1031359ed | Name: _nghttp3_qpack_encoder_write_static_indexed_name
__int64 __fastcall nghttp3_qpack_encoder_write_static_indexed_name(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  return qpack_encoder_write_indexed_name(a1, a2, a3: (32 * *(_BYTE *)(a4 + 32)) & 0x20 | 0x50u, a4: a3, a5: 4, a6: a4); /*0x103135a0b*/
}

// Address: 0x103135a11 | Name: _nghttp3_qpack_encoder_write_dynamic_insert
__int64 __fastcall nghttp3_qpack_encoder_write_dynamic_insert(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  return qpack_encoder_write_indexed_name(a1, a2, a3: 128, a4: *(_QWORD *)(a1 + 96) + ~a3, a5: 6, a6: a4); /*0x103135a2d*/
}

// Address: 0x103135a33 | Name: _nghttp3_qpack_encoder_dtable_dynamic_add
__int64 __fastcall nghttp3_qpack_encoder_dtable_dynamic_add(__int64 a1, __int64 a2, __int64 a3, unsigned int a4)
{
  unsigned int v7; // r12d
  __int64 *v8; // rax
  __int64 v10; // [rsp+8h] [rbp-38h] BYREF
  __int64 v11; // [rsp+10h] [rbp-30h] BYREF
  int v12; // [rsp+18h] [rbp-28h]
  char v13; // [rsp+1Ch] [rbp-24h]

  v7 = nghttp3_rcbuf_new2(a1: &v11, a2: *(_QWORD *)(a3 + 8), a3: *(_QWORD *)(a3 + 24), a4: *(_QWORD *)(a1 + 48)); /*0x103135a5f*/
  if ( v7 == 0 ) /*0x103135a64*/
  {
    v8 = *(__int64 **)nghttp3_ringbuf_get(a1, a2: *(_QWORD *)(a1 + 96) + ~a2); /*0x103135a78*/
    v10 = *v8; /*0x103135a82*/
    v12 = *((_DWORD *)v8 + 4); /*0x103135a88*/
    v13 = 0; /*0x103135a8c*/
    nghttp3_rcbuf_incref(a1: v10); /*0x103135a91*/
    v7 = nghttp3_qpack_context_dtable_add(a1, a2: &v10, a3: a1 + 112, a4); /*0x103135aa7*/
    nghttp3_rcbuf_decref(a1: v11); /*0x103135aae*/
    nghttp3_rcbuf_decref(a1: v10); /*0x103135ab6*/
  }
  return v7; /*0x103135abe*/
}

// Address: 0x103135acb | Name: _nghttp3_qpack_encoder_write_dynamic_indexed_name
__int64 __fastcall nghttp3_qpack_encoder_write_dynamic_indexed_name(
        __int64 a1,
        __int64 a2,
        unsigned __int64 a3,
        unsigned __int64 a4,
        __int64 a5)
{
  char v7; // dl
  bool v8; // cf
  unsigned __int64 v9; // r10

  v7 = *(_BYTE *)(a5 + 32); /*0x103135ad8*/
  v8 = a3 < a4; /*0x103135adc*/
  v9 = a3 - a4; /*0x103135adc*/
  if ( v8 ) /*0x103135adf*/
    return qpack_encoder_write_indexed_name(a1, a2, a3: (32 * v7) & 0x20 | 0x40u, a4: a4 + ~a3, a5: 4, a6: a5); /*0x103135afd*/
  else
    return qpack_encoder_write_indexed_name(a1, a2, a3: (8 * v7) & 8, a4: v9, a5: 3, a6: a5); /*0x103135b15*/
}

// Address: 0x103135b1a | Name: _nghttp3_qpack_encoder_dtable_literal_add
__int64 __fastcall nghttp3_qpack_encoder_dtable_literal_add(__int64 a1, _QWORD *a2, int a3, unsigned int a4)
{
  __int64 v7; // r13
  unsigned int v8; // r12d
  __int64 v10; // [rsp+8h] [rbp-48h] BYREF
  __int64 v11; // [rsp+10h] [rbp-40h] BYREF
  int v12; // [rsp+18h] [rbp-38h]
  char v13; // [rsp+1Ch] [rbp-34h]
  unsigned int v14; // [rsp+24h] [rbp-2Ch]

  v14 = a4; /*0x103135b2b*/
  v7 = *(_QWORD *)(a1 + 48); /*0x103135b37*/
  v8 = nghttp3_rcbuf_new2(a1: &v10, a2: *a2, a3: a2[2], a4: v7); /*0x103135b4e*/
  if ( v8 == 0 ) /*0x103135b53*/
  {
    v8 = nghttp3_rcbuf_new2(a1: &v11, a2: a2[1], a3: a2[3], a4: v7); /*0x103135b69*/
    if ( v8 == 0 ) /*0x103135b6e*/
    {
      v12 = a3; /*0x103135b74*/
      v13 = 0; /*0x103135b78*/
      v8 = nghttp3_qpack_context_dtable_add(a1, a2: &v10, a3: a1 + 112, a4: v14); /*0x103135b8e*/
      nghttp3_rcbuf_decref(a1: v11); /*0x103135b95*/
    }
    nghttp3_rcbuf_decref(a1: v10); /*0x103135b9e*/
  }
  return v8; /*0x103135ba6*/
}

// Address: 0x103135bb5 | Name: _nghttp3_qpack_encoder_write_literal_insert
__int64 __fastcall nghttp3_qpack_encoder_write_literal_insert(__int64 a1, __int64 a2, __int64 a3)
{
  return qpack_encoder_write_literal(a1, a2, a3: 64, a4: 5, a5: a3); /*0x103135bc6*/
}

// Address: 0x103135bcc | Name: _nghttp3_qpack_encoder_write_literal
__int64 __fastcall nghttp3_qpack_encoder_write_literal(__int64 a1, __int64 a2, __int64 a3)
{
  return qpack_encoder_write_literal(a1, a2, a3: (16 * *(_BYTE *)(a3 + 32)) & 0x10 | 0x20u, a4: 3, a5: a3); /*0x103135be5*/
}

// Address: 0x103135beb | Name: _nghttp3_qpack_header_block_ref_new
__int64 __fastcall nghttp3_qpack_header_block_ref_new(__int64 *a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v7; // rax

  v7 = nghttp3_mem_malloc(a1: a4, a2: 32); /*0x103135c06*/
  if ( v7 == 0 ) /*0x103135c0e*/
    return 4294966395LL; /*0x103135c27*/
  *(_OWORD *)v7 = -1; /*0x103135c14*/
  *(_QWORD *)(v7 + 16) = a2; /*0x103135c18*/
  *(_QWORD *)(v7 + 24) = a3; /*0x103135c1c*/
  *a1 = v7; /*0x103135c20*/
  return 0; /*0x103135c30*/
}

// Address: 0x103135c37 | Name: _nghttp3_qpack_header_block_ref_del
__int64 __fastcall nghttp3_qpack_header_block_ref_del(__int64 a1, __int64 a2)
{
  return nghttp3_mem_free(a1: a2, a2: a1); /*0x103135c44*/
}

// Address: 0x103135c4a | Name: _nghttp3_qpack_stream_new
__int64 __fastcall nghttp3_qpack_stream_new(_QWORD *a1, __int64 a2, __int64 a3)
{
  __int64 v6; // rax
  _QWORD *v7; // r12
  unsigned int v8; // r13d

  v6 = nghttp3_mem_malloc(a1: a3, a2: 96); /*0x103135c69*/
  if ( v6 != 0 ) /*0x103135c71*/
  {
    v7 = (_QWORD *)v6; /*0x103135c73*/
    v8 = 0; /*0x103135c7a*/
    nghttp3_ringbuf_init(a1: v6 + 8, a2: 0, a3: 8); /*0x103135c87*/
    nghttp3_pq_init(a1: (__int64)(v7 + 7), a2: (__int64)ref_max_cnt_greater, a3); /*0x103135c9d*/
    *v7 = a2; /*0x103135ca2*/
    *a1 = v7; /*0x103135ca6*/
  }
  else
  {
    return (unsigned int)-901; /*0x103135cab*/
  }
  return v8; /*0x103135cb8*/
}

// Address: 0x103135cd6 | Name: _nghttp3_qpack_stream_del
__int64 __fastcall nghttp3_qpack_stream_del(__int64 a1, __int64 a2)
{
  __int64 v4; // r13
  __int64 i; // r12
  __int64 *v6; // rax
  __int64 result; // rax

  if ( a1 != 0 ) /*0x103135cd9*/
  {
    nghttp3_pq_free(a1: (__int64 *)(a1 + 56)); /*0x103135cf3*/
    v4 = *(_QWORD *)(a1 + 48); /*0x103135cfc*/
    if ( v4 != 0 ) /*0x103135d03*/
    {
      for ( i = 0; i != v4; ++i ) /*0x103135d05*/
      {
        v6 = (__int64 *)nghttp3_ringbuf_get(a1: a1 + 8, a2: i); /*0x103135d0e*/
        nghttp3_mem_free(a1: a2, a2: *v6); /*0x103135d19*/
      }
    }
    nghttp3_ringbuf_free(a1: a1 + 8); /*0x103135d29*/
    return nghttp3_mem_free(a1: a2, a2: a1); /*0x103135d42*/
  }
  return result; /*0x103135d47*/
}

// Address: 0x103135d48 | Name: _nghttp3_qpack_stream_add_ref
__int64 __fastcall nghttp3_qpack_stream_add_ref(__int64 a1, unsigned __int64 *a2)
{
  __int64 v4; // r14
  __int64 v5; // rsi
  __int64 result; // rax

  v4 = a1 + 8; /*0x103135d58*/
  if ( (unsigned int)nghttp3_ringbuf_full(a1: a1 + 8) == 0 ) /*0x103135d66*/
    goto LABEL_5; /*0x103135d66*/
  v5 = 4; /*0x103135d73*/
  if ( (unsigned __int64)(2LL * *(_QWORD *)(a1 + 48)) >= 5 ) /*0x103135d78*/
    v5 = 2LL * *(_QWORD *)(a1 + 48); /*0x103135d78*/
  result = nghttp3_ringbuf_reserve(a1: v4, a2: v5); /*0x103135d7f*/
  if ( (_DWORD)result == 0 ) /*0x103135d86*/
  {
LABEL_5:
    result = nghttp3_pq_push(a1: (__int64 *)(a1 + 56), a2); /*0x103135d92*/
    if ( (_DWORD)result == 0 ) /*0x103135d99*/
    {
      *(_QWORD *)nghttp3_ringbuf_push_back(a1: v4) = a2; /*0x103135da3*/
      return 0; /*0x103135da6*/
    }
  }
  return result; /*0x103135dac*/
}

// Address: 0x103135db3 | Name: _nghttp3_qpack_stream_pop_ref
__int64 __fastcall nghttp3_qpack_stream_pop_ref(__int64 a1)
{
  __int64 v2; // r14
  unsigned __int64 **v3; // rax

  v2 = a1 + 8; /*0x103135dbd*/
  v3 = (unsigned __int64 **)nghttp3_ringbuf_get(a1: a1 + 8, a2: 0); /*0x103135dc6*/
  nghttp3_pq_remove(a1: a1 + 56, a2: *v3); /*0x103135dd5*/
  return nghttp3_ringbuf_pop_front(a1: v2); /*0x103135ddd*/
}

// Address: 0x103136257 | Name: _nghttp3_qpack_put_varint_len
__int64 __fastcall nghttp3_qpack_put_varint_len(unsigned __int64 a1, char a2)
{
  unsigned __int64 v2; // rdx
  __int64 result; // rax
  bool v4; // cf
  unsigned __int64 v5; // rdi
  unsigned __int64 v6; // rcx
  bool v7; // cc

  v2 = (unsigned int)~(-1 << a2); /*0x103136265*/
  result = 1; /*0x103136267*/
  v4 = a1 < v2; /*0x10313626c*/
  v5 = a1 - v2; /*0x10313626c*/
  if ( !v4 ) /*0x10313626f*/
  {
    result = 2; /*0x103136271*/
    if ( v5 >= 0x80 ) /*0x10313627d*/
    {
      v6 = v5; /*0x10313627f*/
      do /*0x103136293*/
      {
        v6 >>= 7; /*0x103136282*/
        ++result; /*0x103136286*/
        v7 = v5 <= 0x3FFF; /*0x103136289*/
        v5 = v6; /*0x103136290*/
      }
      while ( !v7 ); /*0x103136293*/
    }
  }
  return result; /*0x103136295*/
}

// Address: 0x103136311 | Name: _nghttp3_qpack_put_varint
_BYTE *__fastcall nghttp3_qpack_put_varint(_BYTE *a1, unsigned __int64 a2, char a3)
{
  int v3; // edx
  unsigned __int64 v5; // rdi
  char v6; // dl
  unsigned __int64 v7; // rcx
  _BYTE *v9; // rdx
  unsigned __int64 v10; // rax

  v3 = -1 << a3; /*0x103136319*/
  v5 = (unsigned int)~v3; /*0x103136320*/
  v6 = *a1 & v3; /*0x103136322*/
  v7 = a2 - v5; /*0x103136327*/
  if ( a2 >= v5 ) /*0x10313632a*/
  {
    *a1 = v5 | v6; /*0x10313633c*/
    v9 = a1 + 1; /*0x10313633e*/
    if ( v7 >= 0x80 ) /*0x103136349*/
    {
      do /*0x103136364*/
      {
        v10 = v7; /*0x10313634b*/
        *v9 = v7 | 0x80; /*0x103136354*/
        v7 >>= 7; /*0x103136357*/
        ++v9; /*0x10313635b*/
      }
      while ( v10 > 0x3FFF ); /*0x103136364*/
      a1 = v9 - 1; /*0x103136366*/
    }
    *v9 = v7; /*0x10313636e*/
    return a1 + 2; /*0x10313636a*/
  }
  else
  {
    *a1 = a2 | v6; /*0x10313632f*/
    return a1 + 1; /*0x103136331*/
  }
}

// Address: 0x103136372 | Name: _nghttp3_qpack_context_dtable_add
__int64 __fastcall nghttp3_qpack_context_dtable_add(__int64 a1, const __m128i *a2, __int64 a3, int a4)
{
  __int64 v6; // r15
  __int64 v7; // r13
  __int64 v8; // rax
  __int64 v9; // r12
  __int64 v10; // rax
  __int64 v11; // rcx
  __int64 v12; // rax
  _QWORD *v13; // rax
  __int64 v14; // rax
  __int64 v15; // r12
  __int64 v16; // rax
  __int64 v17; // rcx
  __int64 v18; // rsi
  unsigned int v19; // eax
  unsigned int v20; // ebx
  __int64 v22; // rax
  __int64 v23; // rcx

  v6 = *(_QWORD *)(a1 + 48); /*0x10313638c*/
  v7 = *(_QWORD *)(a2->i64[0] + 16) + *(_QWORD *)(a2->i64[1] + 16) + 32LL; /*0x1031363a7*/
  while ( (unsigned __int64)(v7 + *(_QWORD *)(a1 + 56)) > *(_QWORD *)(a1 + 80) ) /*0x1031363b6*/
  {
    v8 = nghttp3_ringbuf_get(a1, a2: *(_QWORD *)(a1 + 40) - 1LL); /*0x1031363c6*/
    v9 = *(_QWORD *)v8; /*0x1031363cb*/
    *(_QWORD *)(a1 + 56) = *(_QWORD *)(a1 + 56) /*0x1031363ed*/
                         - (*(_QWORD *)(*(_QWORD *)(*(_QWORD *)v8 + 8LL) + 16LL)
                          + *(_QWORD *)(**(_QWORD **)v8 + 16LL))
                         - 32LL;
    nghttp3_ringbuf_pop_back(a1); /*0x1031363f4*/
    if ( a3 != 0 ) /*0x1031363fc*/
    {
      v10 = *(_DWORD *)(v9 + 48) & 0x3F; /*0x103136403*/
      v11 = *(_QWORD *)(a3 + 8 * v10); /*0x103136406*/
      if ( v11 != 0 ) /*0x10313640d*/
      {
        if ( v11 == v9 ) /*0x103136412*/
        {
          v13 = (_QWORD *)(a3 + 8 * v10); /*0x10313642b*/
LABEL_9:
          *v13 = *(_QWORD *)(v9 + 24); /*0x10313642f*/
          *(_QWORD *)(v9 + 24) = 0; /*0x103136437*/
        }
        else
        {
          while ( 1 ) /*0x103136414*/
          {
            v12 = v11; /*0x103136414*/
            v11 = *(_QWORD *)(v11 + 24); /*0x103136417*/
            if ( v11 == 0 ) /*0x10313641e*/
              break; /*0x10313641e*/
            if ( v11 == v9 ) /*0x103136423*/
            {
              v13 = (_QWORD *)(v12 + 24); /*0x103136425*/
              goto LABEL_9; /*0x103136429*/
            }
          }
        }
      }
    }
    nghttp3_rcbuf_decref(a1: *(_QWORD *)(v9 + 8)); /*0x103136445*/
    nghttp3_rcbuf_decref(a1: *(_QWORD *)v9); /*0x10313644e*/
    nghttp3_mem_free(a1: v6, a2: v9); /*0x103136459*/
  }
  v14 = nghttp3_mem_malloc(a1: v6, a2: 56); /*0x103136477*/
  if ( v14 == 0 ) /*0x10313647f*/
    return 4294966395LL; /*0x103136577*/
  v15 = v14; /*0x103136485*/
  v16 = *(_QWORD *)(a1 + 64); /*0x103136488*/
  v17 = *(_QWORD *)(a1 + 96); /*0x10313648c*/
  *(_QWORD *)(a1 + 96) = v17 + 1; /*0x103136494*/
  *(__m128i *)v15 = _mm_loadu_si128(a2); /*0x1031364a0*/
  *(_QWORD *)(v15 + 16) = a2[1].i64[0]; /*0x1031364aa*/
  *(_QWORD *)(v15 + 24) = 0; /*0x1031364af*/
  *(_QWORD *)(v15 + 32) = v16; /*0x1031364b8*/
  *(_QWORD *)(v15 + 40) = v17; /*0x1031364bd*/
  *(_DWORD *)(v15 + 48) = a4; /*0x1031364c5*/
  nghttp3_rcbuf_incref(a1: *(_QWORD *)v15); /*0x1031364ce*/
  nghttp3_rcbuf_incref(a1: *(_QWORD *)(v15 + 8)); /*0x1031364d8*/
  if ( (unsigned int)nghttp3_ringbuf_full(a1) == 0 ) /*0x1031364e7*/
    goto LABEL_17; /*0x1031364e7*/
  v18 = 128; /*0x1031364f6*/
  if ( (unsigned __int64)(2LL * *(_QWORD *)(a1 + 40)) >= 0x81 ) /*0x1031364fb*/
    v18 = 2LL * *(_QWORD *)(a1 + 40); /*0x1031364fb*/
  v19 = nghttp3_ringbuf_reserve(a1, a2: v18); /*0x103136502*/
  if ( v19 != 0 ) /*0x103136509*/
  {
    v20 = v19; /*0x103136510*/
    nghttp3_rcbuf_decref(a1: *(_QWORD *)(v15 + 8)); /*0x103136512*/
    nghttp3_rcbuf_decref(a1: *(_QWORD *)v15); /*0x10313651b*/
    nghttp3_mem_free(a1: v6, a2: v15); /*0x103136526*/
    return v20; /*0x10313652b*/
  }
  else
  {
LABEL_17:
    *(_QWORD *)nghttp3_ringbuf_push_front(a1) = v15; /*0x103136537*/
    if ( a3 != 0 ) /*0x10313653d*/
    {
      v22 = *(_DWORD *)(v15 + 48) & 0x3F; /*0x103136544*/
      v23 = *(_QWORD *)(a3 + 8 * v22); /*0x103136549*/
      if ( v23 != 0 ) /*0x103136550*/
        *(_QWORD *)(v15 + 24) = v23; /*0x103136552*/
      *(_QWORD *)(a3 + 8 * v22) = v15; /*0x103136557*/
    }
    *(__m128i *)(a1 + 56) = _mm_add_epi64( /*0x10313656e*/
                              _mm_shuffle_epi32((__m128i)(unsigned __int64)v7, 68),
                              _mm_loadu_si128((const __m128i *)(a1 + 56)));
    return 0; /*0x103136573*/
  }
}

// Address: 0x10313658b | Name: _nghttp3_qpack_entry_init
__int64 __fastcall nghttp3_qpack_entry_init(__int64 a1, __int64 a2, __int64 a3, __int64 a4, int a5)
{
  *(_OWORD *)a1 = *(_OWORD *)a2; /*0x103136597*/
  *(_QWORD *)(a1 + 16) = *(_QWORD *)(a2 + 16); /*0x10313659e*/
  *(_QWORD *)(a1 + 24) = 0; /*0x1031365a2*/
  *(_QWORD *)(a1 + 32) = a3; /*0x1031365aa*/
  *(_QWORD *)(a1 + 40) = a4; /*0x1031365ae*/
  *(_DWORD *)(a1 + 48) = a5; /*0x1031365b2*/
  nghttp3_rcbuf_incref(a1: *(_QWORD *)a1); /*0x1031365b9*/
  return nghttp3_rcbuf_incref(a1: *(_QWORD *)(a1 + 8)); /*0x1031365c6*/
}

// Address: 0x1031365cd | Name: _nghttp3_qpack_context_dtable_get
__int64 __fastcall nghttp3_qpack_context_dtable_get(__int64 a1, __int64 a2)
{
  return *(_QWORD *)nghttp3_ringbuf_get(a1, a2: *(_QWORD *)(a1 + 96) + ~a2); /*0x1031365e0*/
}

// Address: 0x1031365e2 | Name: _nghttp3_qpack_encoder_block_stream
__int64 __fastcall nghttp3_qpack_encoder_block_stream(__int64 a1, _QWORD *a2)
{
  _QWORD v5[4]; // [rsp+0h] [rbp-20h] BYREF

  v5[0] = *(_QWORD *)(nghttp3_pq_top(a1: (__int64)(a2 + 7)) + 16); /*0x103136604*/
  v5[1] = *a2; /*0x10313660a*/
  return nghttp3_ksl_insert(a1: a1 + 680, a2: nullptr, a3: v5, a4: (__int64)a2); /*0x103136622*/
}

// Address: 0x10313662b | Name: _nghttp3_qpack_encoder_unblock_stream
__int64 __fastcall nghttp3_qpack_encoder_unblock_stream(__int64 a1, _QWORD *a2)
{
  __int64 v4; // rdx
  _QWORD v6[2]; // [rsp+8h] [rbp-38h] BYREF
  __int64 v7[5]; // [rsp+18h] [rbp-28h] BYREF

  v6[0] = *(_QWORD *)(nghttp3_pq_top(a1: (__int64)(a2 + 7)) + 16); /*0x10313664f*/
  v6[1] = *a2; /*0x103136655*/
  a1 += 680; /*0x103136659*/
  v7[0] = nghttp3_ksl_lower_bound(a1, a2: (__int64)v6); /*0x10313666f*/
  v7[1] = v4; /*0x103136672*/
  return nghttp3_ksl_remove_hint(a1, a2: nullptr, a3: v7, a4: (__int64)v6); /*0x103136686*/
}

// Address: 0x103136691 | Name: _nghttp3_qpack_encoder_unblock
__int64 __fastcall nghttp3_qpack_encoder_unblock(__int64 a1, unsigned __int64 a2)
{
  __int64 v2; // rbx
  __int64 result; // rax
  __int64 v4; // rdx
  _QWORD v5[2]; // [rsp+0h] [rbp-40h] BYREF
  __int64 v6; // [rsp+18h] [rbp-28h] BYREF
  __int64 v7; // [rsp+20h] [rbp-20h]

  *(_OWORD *)v5 = a2; /*0x1031366a5*/
  v2 = a1 + 680; /*0x1031366b0*/
  result = nghttp3_ksl_lower_bound(a1: a1 + 680, a2: (__int64)v5); /*0x1031366bd*/
  v6 = result; /*0x1031366c6*/
  v7 = v4; /*0x1031366c9*/
  while ( v4 != *(_DWORD *)(result + 280) || *(_QWORD *)result != 0 ) /*0x1031366dc*/
  {
    *(_OWORD *)v5 = *(_OWORD *)(*(_QWORD *)(result + 272) + *(unsigned __int16 *)(result + 284) * v4); /*0x1031366f4*/
    nghttp3_ksl_remove_hint(a1: v2, a2: &v6, a3: &v6, a4: (__int64)v5); /*0x103136704*/
    result = v6; /*0x103136709*/
    v4 = v7; /*0x10313670d*/
  }
  return result; /*0x103136713*/
}

// Address: 0x10313671e | Name: _nghttp3_qpack_encoder_ack_header
__int64 __fastcall nghttp3_qpack_encoder_ack_header(__int64 a1, __int64 a2)
{
  __int64 v3; // rax
  __int64 v4; // r15
  __int64 v5; // r12
  unsigned int v6; // ebx
  __int64 v7; // rax
  __int64 v8; // r13
  unsigned __int64 v9; // rsi

  v3 = nghttp3_map_find(a1: a1 + 624, a2); /*0x103136736*/
  if ( v3 != 0 ) /*0x10313673e*/
  {
    v4 = v3; /*0x103136740*/
    v5 = *(_QWORD *)(a1 + 48); /*0x103136743*/
    v6 = 0; /*0x10313674e*/
    v7 = nghttp3_ringbuf_get(a1: v3 + 8, a2: 0); /*0x103136752*/
    v8 = *(_QWORD *)v7; /*0x103136757*/
    v9 = *(_QWORD *)(*(_QWORD *)v7 + 16LL); /*0x10313675a*/
    if ( *(_QWORD *)(a1 + 848) < v9 ) /*0x103136765*/
    {
      *(_QWORD *)(a1 + 848) = v9; /*0x103136767*/
      nghttp3_qpack_encoder_unblock(a1, a2: v9); /*0x103136771*/
    }
    nghttp3_qpack_stream_pop_ref(a1: v4); /*0x103136779*/
    nghttp3_pq_remove(a1: a1 + 808, a2: (unsigned __int64 *)(v8 + 8)); /*0x103136789*/
    nghttp3_mem_free(a1: v5, a2: v8); /*0x103136794*/
    if ( *(_QWORD *)(v4 + 48) == 0 ) /*0x10313679e*/
    {
      qpack_encoder_remove_stream(a1, a2: v4); /*0x1031367a6*/
      nghttp3_qpack_stream_del(a1: v4, a2: v5); /*0x1031367b1*/
    }
  }
  else
  {
    return (unsigned int)-403; /*0x1031367b8*/
  }
  return v6; /*0x1031367c3*/
}

// Address: 0x103136830 | Name: _nghttp3_qpack_encoder_add_icnt
__int64 __fastcall nghttp3_qpack_encoder_add_icnt(__int64 a1, unsigned __int64 a2)
{
  __int64 result; // rax
  __int64 v3; // rcx
  unsigned __int64 v4; // rcx

  result = 4294966893LL; /*0x103136830*/
  if ( a2 != 0 ) /*0x103136838*/
  {
    v3 = *(_QWORD *)(a1 + 848); /*0x10313683e*/
    if ( *(_QWORD *)(a1 + 96) - v3 >= a2 ) /*0x10313684b*/
    {
      v4 = a2 + v3; /*0x103136851*/
      *(_QWORD *)(a1 + 848) = v4; /*0x103136854*/
      nghttp3_qpack_encoder_unblock(a1, a2: v4); /*0x10313685e*/
      return 0; /*0x103136863*/
    }
  }
  return result; /*0x103136866*/
}

// Address: 0x103136867 | Name: _nghttp3_qpack_encoder_ack_everything
__int64 __fastcall nghttp3_qpack_encoder_ack_everything(_QWORD *a1)
{
  _QWORD *v1; // rbx
  __int64 v2; // rdx

  v1 = a1; /*0x10313686d*/
  a1[106] = a1[12]; /*0x103136874*/
  nghttp3_ksl_clear(a1: (__int64)(a1 + 85)); /*0x103136882*/
  nghttp3_pq_clear(a1: (__int64)(v1 + 101)); /*0x10313688e*/
  v2 = v1[6]; /*0x103136893*/
  v1 += 78; /*0x103136897*/
  nghttp3_map_each(a1: v1, a2: (__int64 (__fastcall *)(_QWORD, __int64))map_stream_free, a3: v2); /*0x1031368a8*/
  return nghttp3_map_clear(a1: (__int64)v1); /*0x1031368b4*/
}

// Address: 0x1031368bb | Name: _nghttp3_qpack_encoder_cancel_stream
__int64 __fastcall nghttp3_qpack_encoder_cancel_stream(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  _QWORD *v4; // r14
  __int64 v5; // r15
  unsigned __int64 v6; // r12

  result = nghttp3_map_find(a1: a1 + 624, a2); /*0x1031368d0*/
  if ( result != 0 ) /*0x1031368d8*/
  {
    v4 = (_QWORD *)result; /*0x1031368da*/
    v5 = *(_QWORD *)(a1 + 48); /*0x1031368dd*/
    v6 = *(_QWORD *)(a1 + 848); /*0x1031368e1*/
    if ( v6 < nghttp3_qpack_stream_get_max_cnt(a1: result) ) /*0x1031368f3*/
      nghttp3_qpack_encoder_unblock_stream(a1, a2: v4); /*0x1031368fb*/
    qpack_encoder_remove_stream(a1, a2: v4); /*0x103136906*/
    return nghttp3_qpack_stream_del(a1: (__int64)v4, a2: v5); /*0x103136919*/
  }
  return result; /*0x103136911*/
}

// Address: 0x103136927 | Name: _nghttp3_qpack_encoder_get_num_blocked_streams
__int64 __fastcall nghttp3_qpack_encoder_get_num_blocked_streams(__int64 a1)
{
  return nghttp3_ksl_len(a1: a1 + 680); /*0x103136932*/
}

// Address: 0x103136938 | Name: _nghttp3_qpack_encoder_read_decoder
unsigned __int8 *__fastcall nghttp3_qpack_encoder_read_decoder(__int64 a1, unsigned __int8 *a2, __int64 a3)
{
  __int64 v3; // r12
  unsigned __int64 v7; // rax
  unsigned __int8 *v8; // r13
  unsigned __int64 *v9; // r14
  unsigned __int8 *v10; // r12
  int v11; // eax
  unsigned int v12; // eax
  int v13; // ecx
  __int64 v14; // rax
  __int64 varint; // rcx
  int v16; // eax
  int v17; // ecx
  unsigned __int64 v18; // rcx
  __int64 v19; // rsi
  unsigned __int64 v20; // rsi
  __int64 v21; // [rsp+8h] [rbp-58h]
  _OWORD *v22; // [rsp+10h] [rbp-50h]
  _OWORD *v23; // [rsp+18h] [rbp-48h]
  _OWORD *v24; // [rsp+20h] [rbp-40h]
  int v26[11]; // [rsp+34h] [rbp-2Ch] BYREF

  v3 = -108; /*0x103136949*/
  if ( *(_BYTE *)(a1 + 104) == 0 ) /*0x103136954*/
  {
    if ( a3 != 0 ) /*0x10313696e*/
    {
      v7 = a3 + *(_QWORD *)(a1 + 1016); /*0x10313697e*/
      *(_QWORD *)(a1 + 1016) = v7; /*0x103136981*/
      v3 = -403; /*0x103136988*/
      if ( v7 <= 0x1000 ) /*0x103136995*/
      {
        v8 = &a2[a3]; /*0x103136997*/
        v21 = a1 + 864; /*0x1031369a2*/
        v9 = (unsigned __int64 *)(a1 + 952); /*0x1031369a6*/
        v22 = (_OWORD *)(a1 + 936); /*0x1031369b4*/
        v23 = (_OWORD *)(a1 + 872); /*0x1031369bf*/
        v24 = (_OWORD *)(a1 + 904); /*0x1031369ca*/
        v10 = a2; /*0x1031369d2*/
        while ( 1 ) /*0x1031369d5*/
        {
          v11 = *(_DWORD *)(a1 + 856); /*0x1031369d5*/
          if ( v11 != 1 ) /*0x1031369de*/
          {
            if ( v11 != 0 ) /*0x1031369e2*/
              nghttp3_unreachable_fail(a1: "nghttp3_qpack.c", a2: 2632, a3: "nghttp3_qpack_encoder_read_decoder"); /*0x103136b38*/
            v12 = *v10 >> 6; /*0x1031369ed*/
            v13 = *((_DWORD *)&xmmword_10905E990 + v12); /*0x1031369f7*/
            v14 = qword_1094C74F8[v12]; /*0x103136a01*/
            *(_DWORD *)(a1 + 860) = v13; /*0x103136a05*/
            *(_QWORD *)(a1 + 960) = v14; /*0x103136a0b*/
            *(_DWORD *)(a1 + 856) = 1; /*0x103136a12*/
          }
          varint = qpack_read_varint(a1: v26, a2: v21, a3: v10, a4: v8); /*0x103136a2f*/
          v16 = -403; /*0x103136a32*/
          if ( varint < 0 ) /*0x103136a3a*/
          {
LABEL_23:
            *(_BYTE *)(a1 + 104) = 1; /*0x103136b10*/
            return (unsigned __int8 *)v16; /*0x103136b17*/
          }
          v10 += varint; /*0x103136a40*/
          if ( v26[0] == 0 ) /*0x103136a47*/
            return (unsigned __int8 *)(v10 - a2); /*0x103136b1c*/
          v17 = *(_DWORD *)(a1 + 860); /*0x103136a4d*/
          switch ( v17 ) /*0x103136a56*/
          {
            case 2: /*0x103136a56*/
              nghttp3_qpack_encoder_cancel_stream(a1, a2: *(_QWORD *)(a1 + 952)); /*0x103136abb*/
              break;
            case 1: /*0x103136a56*/
              v16 = nghttp3_qpack_encoder_ack_header(a1, a2: *(_QWORD *)(a1 + 952)); /*0x103136aa6*/
              if ( v16 != 0 ) /*0x103136aad*/
                goto LABEL_23; /*0x103136aad*/
              break;
            case 0: /*0x103136a56*/
              v18 = *v9; /*0x103136a65*/
              if ( *v9 == 0 ) /*0x103136a6b*/
                goto LABEL_23; /*0x103136a6b*/
              v19 = *(_QWORD *)(a1 + 848); /*0x103136a75*/
              if ( *(_QWORD *)(a1 + 96) - v19 < v18 ) /*0x103136a82*/
                goto LABEL_23; /*0x103136a82*/
              v20 = v18 + v19; /*0x103136a88*/
              *(_QWORD *)(a1 + 848) = v20; /*0x103136a8b*/
              nghttp3_qpack_encoder_unblock(a1, a2: v20); /*0x103136a95*/
              break;
            default:
              nghttp3_unreachable_fail(a1: "nghttp3_qpack.c", a2: 2625, a3: "nghttp3_qpack_encoder_read_decoder"); /*0x103136b50*/
          }
          *(_DWORD *)(a1 + 856) = 0; /*0x103136ac0*/
          *v22 = 0; /*0x103136ad1*/
          nghttp3_buf_init(a1: v23); /*0x103136ad8*/
          nghttp3_buf_init(a1: v24); /*0x103136ae1*/
          *(_OWORD *)(a1 + 980) = 0; /*0x103136ae9*/
          *(_OWORD *)(a1 + 968) = 0; /*0x103136aee*/
          *(_OWORD *)v9 = 0; /*0x103136af3*/
          if ( v10 == v8 ) /*0x103136afa*/
            return (unsigned __int8 *)a3; /*0x103136b03*/
        }
      }
    }
    else
    {
      return nullptr; /*0x103136b08*/
    }
  }
  return (unsigned __int8 *)v3; /*0x103136959*/
}

// Address: 0x103136c51 | Name: _nghttp3_qpack_read_state_free
__int64 __fastcall nghttp3_qpack_read_state_free(__int64 a1)
{
  nghttp3_rcbuf_decref(a1: *(_QWORD *)(a1 + 80)); /*0x103136c5e*/
  return nghttp3_rcbuf_decref(a1: *(_QWORD *)(a1 + 72)); /*0x103136c6b*/
}

// Address: 0x103136c72 | Name: _nghttp3_qpack_decoder_init
void __fastcall nghttp3_qpack_decoder_init(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  nghttp3_ringbuf_init(a1, a2: 0, a3: 8); /*0x103136c96*/
  *(_QWORD *)(a1 + 48) = a4; /*0x103136c9b*/
  *(_OWORD *)(a1 + 56) = 0; /*0x103136ca2*/
  *(_QWORD *)(a1 + 72) = a2; /*0x103136ca6*/
  *(_QWORD *)(a1 + 80) = 0; /*0x103136caa*/
  *(_QWORD *)(a1 + 88) = a3; /*0x103136cae*/
  *(_QWORD *)(a1 + 96) = 0; /*0x103136cb2*/
  *(_BYTE *)(a1 + 104) = 0; /*0x103136cb6*/
  *(_QWORD *)(a1 + 112) = 0; /*0x103136cba*/
  *(_OWORD *)(a1 + 192) = 0; /*0x103136cc5*/
  *(_OWORD *)(a1 + 288) = 0; /*0x103136ccc*/
  *(_QWORD *)(a1 + 304) = 0; /*0x103136cd3*/
  nghttp3_buf_init(a1: (_OWORD *)(a1 + 128)); /*0x103136cda*/
  nghttp3_buf_init(a1: (_OWORD *)(a1 + 160)); /*0x103136ce6*/
  *(_OWORD *)(a1 + 236) = 0; /*0x103136cee*/
  *(_OWORD *)(a1 + 224) = 0; /*0x103136cf5*/
  *(_OWORD *)(a1 + 208) = 0; /*0x103136cfc*/
  nghttp3_buf_init(a1: (_OWORD *)(a1 + 256)); /*0x103136d1b*/
}

// Address: 0x103136d20 | Name: _nghttp3_qpack_decoder_free
__int64 __fastcall nghttp3_qpack_decoder_free(__int64 *a1)
{
  nghttp3_buf_free(a1: a1 + 32, a2: a1[6]); /*0x103136d34*/
  nghttp3_rcbuf_decref(a1: a1[25]); /*0x103136d40*/
  nghttp3_rcbuf_decref(a1: a1[24]); /*0x103136d4c*/
  return qpack_context_free(a1); /*0x103136d58*/
}

// Address: 0x103136d5f | Name: _nghttp3_qpack_decoder_read_encoder
_BYTE *__fastcall nghttp3_qpack_decoder_read_encoder(__int64 a1, _BYTE *a2, __int64 a3)
{
  __int64 v3; // r14
  unsigned __int64 v6; // rax
  _BYTE *v7; // r15
  __int64 v8; // r13
  __int64 v9; // r12
  _BYTE *v10; // r14
  __int64 huffman_string; // rax
  __int64 v12; // r13
  _BYTE *v13; // rax
  __int64 v14; // rcx
  int v15; // eax
  int v16; // eax
  __int64 v17; // rax
  __int64 v18; // rsi
  __int64 v19; // rsi
  int v20; // eax
  __int64 v21; // rax
  __int64 v22; // rsi
  __int64 v23; // rsi
  __int64 varint; // rax
  int v25; // eax
  _BYTE *v26; // rax
  __int64 v27; // rcx
  __int64 v28; // rax
  int v29; // eax
  int v30; // eax
  char v31; // al
  int v32; // eax
  __int64 v33; // rax
  _BYTE *v34; // [rsp+8h] [rbp-78h]
  __int64 v36; // [rsp+18h] [rbp-68h]
  __int64 v37; // [rsp+20h] [rbp-60h]
  __int64 v39; // [rsp+30h] [rbp-50h]
  _OWORD *v40; // [rsp+38h] [rbp-48h]
  _OWORD *v41; // [rsp+40h] [rbp-40h]
  _OWORD *v42; // [rsp+48h] [rbp-38h]
  _DWORD v43[11]; // [rsp+54h] [rbp-2Ch] BYREF

  v3 = -108; /*0x103136d70*/
  if ( *(_BYTE *)(a1 + 104) == 0 ) /*0x103136d7b*/
  {
    if ( a3 == 0 ) /*0x103136d92*/
      return nullptr; /*0x10313735e*/
    v36 = *(_QWORD *)(a1 + 48); /*0x103136d9f*/
    v6 = a3 + *(_QWORD *)(a1 + 304); /*0x103136daa*/
    *(_QWORD *)(a1 + 304) = v6; /*0x103136dad*/
    v3 = -402; /*0x103136db4*/
    if ( v6 <= 0x20000 ) /*0x103136dc1*/
    {
      v7 = &a2[a3]; /*0x103136dc7*/
      v40 = (_OWORD *)(a1 + 208); /*0x103136dd2*/
      v41 = (_OWORD *)(a1 + 160); /*0x103136ddd*/
      v8 = a1 + 200; /*0x103136de1*/
      v9 = a1 + 192; /*0x103136de8*/
      v42 = (_OWORD *)(a1 + 128); /*0x103136df6*/
      v39 = a1 + 120; /*0x103136dfe*/
      v10 = a2; /*0x103136e06*/
      v37 = a1 + 200; /*0x103136e09*/
      v34 = &a2[a3]; /*0x103136e0d*/
      while ( 1 ) /*0x103136e2c*/
      {
        switch ( *(_DWORD *)(a1 + 112) ) /*0x103136e2c*/
        {
          case 0: /*0x103136e2c*/
            switch ( (unsigned __int8)*v10 >> 5 ) /*0x103136e43*/
            {
              case 0: /*0x103136e43*/
                *(_DWORD *)(a1 + 244) = 1; /*0x103137308*/
                *(_QWORD *)(a1 + 216) = 5; /*0x103137312*/
                v33 = 0x200000001LL; /*0x10313731d*/
                goto LABEL_65; /*0x103137327*/
              case 1: /*0x103136e43*/
                *(_QWORD *)(a1 + 216) = 5; /*0x103137329*/
                v33 = 0x300000001LL; /*0x103137334*/
                goto LABEL_65; /*0x103137334*/
              case 2: /*0x103136e43*/
              case 3: /*0x103136e43*/
                *(_DWORD *)(a1 + 244) = 0; /*0x1031372d0*/
                *(_QWORD *)(a1 + 216) = 5; /*0x1031372da*/
                v33 = 0x100000002LL; /*0x1031372e5*/
LABEL_65:
                *(_QWORD *)(a1 + 112) = v33; /*0x10313733e*/
                break; /*0x10313733e*/
              case 4: /*0x103136e43*/
              case 5: /*0x103136e43*/
              case 6: /*0x103136e43*/
              case 7: /*0x103136e43*/
                *(_DWORD *)(a1 + 116) = 0; /*0x103136e45*/
                *(_DWORD *)(a1 + 244) = (*v10 & 0x40) == 0; /*0x103136e55*/
                *(_QWORD *)(a1 + 216) = 6; /*0x103136e5b*/
                *(_DWORD *)(a1 + 112) = 1; /*0x103136e66*/
                break; /*0x103136e6d*/
            }
            goto LABEL_66; /*0x103136e6d*/
          case 1: /*0x103136e2c*/
            varint = qpack_read_varint(a1: v43, a2: v39, a3: v10, a4: v7); /*0x1031370a5*/
            LODWORD(v12) = -402; /*0x1031370aa*/
            if ( varint < 0 ) /*0x1031370b3*/
              goto LABEL_74; /*0x1031370b3*/
            v10 += varint; /*0x1031370b9*/
            if ( v43[0] == 0 ) /*0x1031370c0*/
              return (_BYTE *)(v10 - a2); /*0x1031370c0*/
            if ( *(_DWORD *)(a1 + 116) == 3 ) /*0x1031370ca*/
            {
              v25 = nghttp3_qpack_decoder_set_max_dtable_capacity(a1, a2: *(_QWORD *)(a1 + 208)); /*0x1031370da*/
LABEL_47:
              if ( v25 != 0 ) /*0x1031371da*/
                goto LABEL_74; /*0x1031371da*/
LABEL_48:
              *(_DWORD *)(a1 + 112) = 0; /*0x1031371e0*/
              *(_OWORD *)v9 = 0; /*0x1031371ea*/
              nghttp3_buf_init(a1: v42); /*0x1031371f3*/
              nghttp3_buf_init(a1: v41); /*0x1031371fc*/
              *(_OWORD *)((char *)v40 + 28) = 0; /*0x103137208*/
              v40[1] = 0; /*0x10313720c*/
              *v40 = 0; /*0x103137210*/
              goto LABEL_52; /*0x103137213*/
            }
            v30 = nghttp3_qpack_decoder_rel2abs(a1, a2: v39); /*0x10313729e*/
            if ( v30 < 0 ) /*0x1031372a5*/
              goto LABEL_72; /*0x1031372a5*/
            v32 = *(_DWORD *)(a1 + 116); /*0x1031372ab*/
            if ( v32 != 0 ) /*0x1031372b0*/
            {
              if ( v32 != 2 ) /*0x1031372b5*/
                nghttp3_unreachable_fail(a1: "nghttp3_qpack.c", a2: 2930, a3: "nghttp3_qpack_decoder_read_encoder"); /*0x1031373ce*/
              v30 = nghttp3_qpack_decoder_dtable_duplicate_add(a1); /*0x1031372be*/
              if ( v30 != 0 ) /*0x1031372c5*/
              {
LABEL_72:
                LODWORD(v12) = v30; /*0x103137374*/
LABEL_74:
                *(_BYTE *)(a1 + 104) = 1; /*0x10313737f*/
                return (_BYTE *)(int)v12; /*0x103137386*/
              }
              goto LABEL_48; /*0x1031372c5*/
            }
            *(_QWORD *)(a1 + 216) = 7; /*0x1031372f1*/
            *(_DWORD *)(a1 + 112) = 6; /*0x1031372fc*/
LABEL_52:
            v31 = 0; /*0x103137248*/
            v8 = v37; /*0x10313724a*/
LABEL_67:
            if ( ((unsigned __int8)v31 | (v10 != v7)) == 0 ) /*0x10313734c*/
              return (_BYTE *)a3; /*0x103137356*/
            break; /*0x103137356*/
          case 2: /*0x103136e2c*/
            v16 = (unsigned __int8)*v10; /*0x103136f5a*/
            *(_DWORD *)(a1 + 248) = _bittest(&v16, *(_DWORD *)(a1 + 216)); /*0x103136f6c*/
            *(_DWORD *)(a1 + 112) = 3; /*0x103136f72*/
            *(_QWORD *)(a1 + 208) = 0; /*0x103136f7b*/
            *(_QWORD *)(a1 + 224) = 0; /*0x103136f82*/
            goto LABEL_20; /*0x103136f82*/
          case 3: /*0x103136e2c*/
LABEL_20:
            v17 = qpack_read_varint(a1: v43, a2: v39, a3: v10, a4: v7); /*0x103136f89*/
            if ( v17 < 0 ) /*0x103136f9f*/
              goto LABEL_71; /*0x103136f9f*/
            v10 += v17; /*0x103136fa5*/
            if ( v43[0] == 0 ) /*0x103136fac*/
              return (_BYTE *)(v10 - a2); /*0x103136fac*/
            v18 = *(_QWORD *)v40; /*0x103136fb6*/
            if ( *(_QWORD *)v40 > 0x100u ) /*0x103136fc0*/
              goto LABEL_73; /*0x103136fc0*/
            if ( *(_DWORD *)(a1 + 248) != 0 ) /*0x103136fcd*/
            {
              *(_DWORD *)(a1 + 112) = 4; /*0x103136fd3*/
              nghttp3_qpack_huffman_decode_context_init(a1: v39); /*0x103136fde*/
              v19 = 2LL * *(_QWORD *)(a1 + 208) + 1; /*0x103136fea*/
            }
            else
            {
              *(_DWORD *)(a1 + 112) = 5; /*0x103137215*/
              v19 = v18 + 1; /*0x10313721c*/
            }
            v30 = nghttp3_rcbuf_new(a1: v9, a2: v19, a3: v36); /*0x103137226*/
            if ( v30 != 0 ) /*0x10313722d*/
              goto LABEL_72; /*0x10313722d*/
            nghttp3_buf_wrap_init(a1: v42, a2: *(_QWORD *)(*(_QWORD *)v9 + 8LL), a3: *(_QWORD *)(*(_QWORD *)v9 + 16LL)); /*0x103137243*/
            goto LABEL_52; /*0x103137243*/
          case 4: /*0x103136e2c*/
            huffman_string = qpack_read_huffman_string(a1: v39, a2: v42, a3: v10, a4: v7); /*0x103136e80*/
            if ( huffman_string < 0 ) /*0x103136e88*/
              goto LABEL_71; /*0x103136e88*/
            v10 += huffman_string; /*0x103136e8e*/
            if ( *(_QWORD *)v40 != 0 ) /*0x103136e99*/
              return (_BYTE *)(v10 - a2); /*0x103136e99*/
            **(_BYTE **)(a1 + 152) = 0; /*0x103136ea6*/
            *(_QWORD *)(*(_QWORD *)(a1 + 192) + 16LL) = nghttp3_buf_len(a1: (__int64)v42); /*0x103136eb9*/
            *(_DWORD *)(a1 + 112) = 6; /*0x103136ebd*/
            *(_QWORD *)(a1 + 216) = 7; /*0x103136ec4*/
            goto LABEL_66; /*0x103136ecf*/
          case 5: /*0x103136e2c*/
            v12 = v7 - v10; /*0x1031370e7*/
            if ( (unsigned __int64)(v7 - v10) >= *(_QWORD *)(a1 + 208) ) /*0x1031370fb*/
              v12 = *(_QWORD *)(a1 + 208); /*0x1031370fb*/
            v26 = (_BYTE *)nghttp3_cpymem(a1: *(_QWORD *)(a1 + 152), a2: v10, a3: v12); /*0x103137105*/
            *(_QWORD *)(a1 + 152) = v26; /*0x10313710a*/
            v27 = *(_QWORD *)(a1 + 208); /*0x103137111*/
            *(_QWORD *)(a1 + 208) = v27 - v12; /*0x10313711e*/
            if ( v12 < 0 ) /*0x103137128*/
              goto LABEL_74; /*0x103137128*/
            v10 += v12; /*0x10313712e*/
            if ( v27 != v12 ) /*0x103137134*/
              return (_BYTE *)(v10 - a2); /*0x103137134*/
            *v26 = 0; /*0x10313713a*/
            *(_QWORD *)(*(_QWORD *)(a1 + 192) + 16LL) = nghttp3_buf_len(a1: (__int64)v42); /*0x10313714d*/
            *(_DWORD *)(a1 + 112) = 6; /*0x103137151*/
            *(_QWORD *)(a1 + 216) = 7; /*0x103137158*/
            goto LABEL_52; /*0x103137163*/
          case 6: /*0x103136e2c*/
            v20 = (unsigned __int8)*v10; /*0x103136ff7*/
            *(_DWORD *)(a1 + 248) = _bittest(&v20, *(_DWORD *)(a1 + 216)); /*0x103137009*/
            *(_DWORD *)(a1 + 112) = 7; /*0x10313700f*/
            *(_QWORD *)(a1 + 208) = 0; /*0x103137018*/
            *(_QWORD *)(a1 + 224) = 0; /*0x10313701f*/
            goto LABEL_26; /*0x10313701f*/
          case 7: /*0x103136e2c*/
LABEL_26:
            v21 = qpack_read_varint(a1: v43, a2: v39, a3: v10, a4: v7); /*0x103137026*/
            if ( v21 < 0 ) /*0x10313703c*/
              goto LABEL_71; /*0x10313703c*/
            v10 += v21; /*0x103137042*/
            if ( v43[0] == 0 ) /*0x103137049*/
              return (_BYTE *)(v10 - a2); /*0x103137049*/
            v22 = *(_QWORD *)v40; /*0x103137053*/
            if ( *(_QWORD *)v40 > 0x10000u ) /*0x10313705d*/
            {
LABEL_73:
              LODWORD(v12) = -109; /*0x103137379*/
              goto LABEL_74; /*0x103137379*/
            }
            if ( *(_DWORD *)(a1 + 248) != 0 ) /*0x10313706a*/
            {
              *(_DWORD *)(a1 + 112) = 8; /*0x103137073*/
              nghttp3_qpack_huffman_decode_context_init(a1: v39); /*0x10313707e*/
              v23 = 2LL * *(_QWORD *)(a1 + 208) + 1; /*0x10313708a*/
            }
            else
            {
              *(_DWORD *)(a1 + 112) = 9; /*0x103137256*/
              v23 = v22 + 1; /*0x10313725d*/
            }
            v30 = nghttp3_rcbuf_new(a1: v8, a2: v23, a3: v36); /*0x103137267*/
            if ( v30 != 0 ) /*0x10313726e*/
              goto LABEL_72; /*0x10313726e*/
            nghttp3_buf_wrap_init(a1: v41, a2: *(_QWORD *)(*(_QWORD *)v8 + 8LL), a3: *(_QWORD *)(*(_QWORD *)v8 + 16LL)); /*0x103137284*/
            v31 = 1; /*0x103137289*/
            v7 = v34; /*0x10313728e*/
            goto LABEL_67; /*0x103137292*/
          case 8: /*0x103136e2c*/
            v28 = qpack_read_huffman_string(a1: v39, a2: v41, a3: v10, a4: v7); /*0x103137176*/
            if ( v28 < 0 ) /*0x10313717e*/
            {
LABEL_71:
              LODWORD(v12) = -402; /*0x10313736c*/
              goto LABEL_74; /*0x103137372*/
            }
            v10 += v28; /*0x103137184*/
            if ( *(_QWORD *)v40 != 0 ) /*0x10313718f*/
              return (_BYTE *)(v10 - a2); /*0x103137367*/
            **(_BYTE **)(a1 + 184) = 0; /*0x10313719c*/
            *(_QWORD *)(*(_QWORD *)(a1 + 200) + 16LL) = nghttp3_buf_len(a1: (__int64)v41); /*0x1031371af*/
            v29 = *(_DWORD *)(a1 + 116); /*0x1031371b3*/
            if ( v29 == 1 ) /*0x1031371b9*/
            {
LABEL_45:
              v25 = nghttp3_qpack_decoder_dtable_literal_add(a1); /*0x1031371cd*/
            }
            else
            {
              if ( v29 != 0 ) /*0x1031371bd*/
                nghttp3_unreachable_fail(a1: "nghttp3_qpack.c", a2: 3087, a3: "nghttp3_qpack_decoder_read_encoder"); /*0x1031373b6*/
LABEL_44:
              v25 = nghttp3_qpack_decoder_dtable_indexed_add(a1); /*0x1031371c3*/
            }
            LODWORD(v12) = v25; /*0x1031371d5*/
            goto LABEL_47; /*0x1031371d5*/
          case 9: /*0x103136e2c*/
            v12 = v7 - v10; /*0x103136ed7*/
            if ( (unsigned __int64)(v7 - v10) >= *(_QWORD *)(a1 + 208) ) /*0x103136eeb*/
              v12 = *(_QWORD *)(a1 + 208); /*0x103136eeb*/
            v13 = (_BYTE *)nghttp3_cpymem(a1: *(_QWORD *)(a1 + 184), a2: v10, a3: v12); /*0x103136ef5*/
            *(_QWORD *)(a1 + 184) = v13; /*0x103136efa*/
            v14 = *(_QWORD *)(a1 + 208); /*0x103136f01*/
            *(_QWORD *)(a1 + 208) = v14 - v12; /*0x103136f0e*/
            if ( v12 < 0 ) /*0x103136f18*/
              goto LABEL_74; /*0x103136f18*/
            v10 += v12; /*0x103136f1e*/
            if ( v14 != v12 ) /*0x103136f24*/
              return (_BYTE *)(v10 - a2); /*0x103136f24*/
            *v13 = 0; /*0x103136f2a*/
            *(_QWORD *)(*(_QWORD *)(a1 + 200) + 16LL) = nghttp3_buf_len(a1: (__int64)v41); /*0x103136f3d*/
            v15 = *(_DWORD *)(a1 + 116); /*0x103136f41*/
            if ( v15 == 1 ) /*0x103136f47*/
              goto LABEL_45; /*0x103136f47*/
            if ( v15 != 0 ) /*0x103136f4f*/
              nghttp3_unreachable_fail(a1: "nghttp3_qpack.c", a2: 3120, a3: "nghttp3_qpack_decoder_read_encoder"); /*0x10313739e*/
            goto LABEL_44; /*0x103136f4f*/
          default:
LABEL_66:
            v31 = 0; /*0x103137342*/
            goto LABEL_67; /*0x103137342*/
        }
      }
    }
  }
  return (_BYTE *)v3; /*0x103136d80*/
}

// Address: 0x10313741c | Name: _nghttp3_qpack_decoder_set_max_dtable_capacity
__int64 __fastcall nghttp3_qpack_decoder_set_max_dtable_capacity(_QWORD *a1, unsigned __int64 a2)
{
  unsigned int v2; // ebx
  __int64 v6; // r12
  __int64 v7; // rax
  _QWORD *v8; // r13

  v2 = -101; /*0x10313742a*/
  if ( a1[9] >= a2 ) /*0x103137433*/
  {
    v6 = a1[6]; /*0x10313744c*/
    a1[10] = a2; /*0x103137450*/
    v2 = 0; /*0x103137454*/
    while ( a1[7] > a2 ) /*0x10313745a*/
    {
      v7 = nghttp3_ringbuf_get(a1, a2: a1[5] - 1LL); /*0x103137466*/
      v8 = *(_QWORD **)v7; /*0x10313746b*/
      a1[7] = a1[7] /*0x10313748c*/
            - (*(_QWORD *)(*(_QWORD *)(*(_QWORD *)v7 + 8LL) + 16LL)
             + *(_QWORD *)(**(_QWORD **)v7 + 16LL))
            - 32LL;
      nghttp3_ringbuf_pop_back(a1); /*0x103137493*/
      nghttp3_rcbuf_decref(a1: v8[1]); /*0x10313749c*/
      nghttp3_rcbuf_decref(a1: *v8); /*0x1031374a5*/
      nghttp3_mem_free(a1: v6, a2: (__int64)v8); /*0x1031374b0*/
    }
  }
  return v2; /*0x10313743b*/
}

// Address: 0x1031374b7 | Name: _nghttp3_qpack_decoder_rel2abs
__int64 __fastcall nghttp3_qpack_decoder_rel2abs(__int64 a1, __int64 a2)
{
  unsigned __int64 v2; // rdx
  unsigned __int64 v3; // rcx
  __int64 result; // rax
  unsigned __int64 v5; // rax

  if ( *(_DWORD *)(a2 + 124) != 0 ) /*0x1031374bf*/
  {
    v2 = *(_QWORD *)(a1 + 96); /*0x1031374c1*/
    v3 = *(_QWORD *)(a2 + 88); /*0x1031374c5*/
    result = 4294966894LL; /*0x1031374cd*/
    if ( v2 < v3 + 1 ) /*0x1031374d5*/
      return result; /*0x1031374d5*/
    *(_QWORD *)(a2 + 112) = ~v3 + v2; /*0x1031374e0*/
    if ( !__CFADD__(~v3, v2) || v3 >= *(_QWORD *)(a1 + 40) ) /*0x1031374ea*/
      return 4294966894LL; /*0x1031374ea*/
  }
  else
  {
    v5 = *(_QWORD *)(a2 + 88); /*0x1031374f3*/
    *(_QWORD *)(a2 + 112) = v5; /*0x1031374f7*/
    if ( v5 >= 0x63 ) /*0x1031374ff*/
      return 4294966894LL; /*0x1031374f1*/
  }
  return 0; /*0x103137503*/
}

// Address: 0x103137505 | Name: _nghttp3_qpack_decoder_dtable_duplicate_add
__int64 __fastcall nghttp3_qpack_decoder_dtable_duplicate_add(_QWORD *a1)
{
  _QWORD *v2; // rax
  unsigned int v3; // r14d
  __int64 v4; // r15
  __int64 v5; // r12
  __m128i v7; // [rsp+0h] [rbp-40h] BYREF
  __int64 v8; // [rsp+10h] [rbp-30h]

  v2 = *(_QWORD **)nghttp3_ringbuf_get(a1, a2: a1[12] + ~a1[29]); /*0x10313752a*/
  v3 = -402; /*0x103137543*/
  if ( (unsigned __int64)(*(_QWORD *)(v2[1] + 16LL) + *(_QWORD *)(*v2 + 16LL) + 32LL) <= a1[10] ) /*0x10313754d*/
  {
    v7 = *(__m128i *)v2; /*0x103137556*/
    v8 = v2[2]; /*0x10313755e*/
    v4 = v7.i64[0]; /*0x103137562*/
    nghttp3_rcbuf_incref(a1: v7.i64[0]); /*0x103137568*/
    v5 = v7.i64[1]; /*0x10313756d*/
    nghttp3_rcbuf_incref(a1: v7.i64[1]); /*0x103137574*/
    v3 = nghttp3_qpack_context_dtable_add((__int64)a1, a2: &v7, a3: 0, a4: 0); /*0x103137588*/
    nghttp3_rcbuf_decref(a1: v5); /*0x10313758e*/
    nghttp3_rcbuf_decref(a1: v4); /*0x103137596*/
  }
  return v3; /*0x10313759e*/
}

// Address: 0x103137616 | Name: _nghttp3_qpack_decoder_dtable_indexed_add
__int64 __fastcall nghttp3_qpack_decoder_dtable_indexed_add(__int64 a1)
{
  if ( *(_DWORD *)(a1 + 244) != 0 ) /*0x103137621*/
    return nghttp3_qpack_decoder_dtable_dynamic_add(); /*0x103137624*/
  else
    return nghttp3_qpack_decoder_dtable_static_add(); /*0x10313762a*/
}

// Address: 0x10313762f | Name: _nghttp3_qpack_decoder_dtable_literal_add
__int64 __fastcall nghttp3_qpack_decoder_dtable_literal_add(_QWORD *a1)
{
  __int64 v1; // r14
  __int64 v2; // r15
  __int64 v3; // rsi
  unsigned int v4; // r12d
  __m128i v7; // [rsp+0h] [rbp-40h] BYREF
  int v8; // [rsp+10h] [rbp-30h]
  char v9; // [rsp+14h] [rbp-2Ch]

  v1 = a1[24]; /*0x103137640*/
  v2 = a1[25]; /*0x103137647*/
  v3 = *(_QWORD *)(v1 + 16); /*0x10313764e*/
  v4 = -402; /*0x10313765d*/
  if ( (unsigned __int64)(v3 + *(_QWORD *)(v2 + 16) + 32) <= a1[10] ) /*0x103137667*/
  {
    v7.i64[0] = a1[24]; /*0x103137670*/
    v7.i64[1] = v2; /*0x103137674*/
    v8 = qpack_lookup_token(a1: *(_QWORD *)(v1 + 8), a2: v3); /*0x103137682*/
    v9 = 0; /*0x103137687*/
    v4 = nghttp3_qpack_context_dtable_add((__int64)a1, a2: &v7, a3: 0, a4: 0); /*0x10313769f*/
    nghttp3_rcbuf_decref(a1: v2); /*0x1031376a5*/
    a1[25] = 0; /*0x1031376aa*/
    nghttp3_rcbuf_decref(a1: v1); /*0x1031376b4*/
    a1[24] = 0; /*0x1031376b9*/
  }
  return v4; /*0x1031376c3*/
}

// Address: 0x1031376d2 | Name: _nghttp3_qpack_decoder_dtable_dynamic_add
__int64 __fastcall nghttp3_qpack_decoder_dtable_dynamic_add(_QWORD *a1)
{
  _DWORD *v2; // rax
  __int64 v3; // r14
  __int64 v4; // r15
  unsigned int v5; // r12d
  __m128i v7; // [rsp+8h] [rbp-38h] BYREF
  int v8; // [rsp+18h] [rbp-28h]
  char v9; // [rsp+1Ch] [rbp-24h]

  v2 = *(_DWORD **)nghttp3_ringbuf_get(a1, a2: a1[12] + ~a1[29]); /*0x1031376f7*/
  v3 = *(_QWORD *)v2; /*0x1031376fa*/
  v4 = a1[25]; /*0x103137701*/
  v5 = -402; /*0x103137713*/
  if ( (unsigned __int64)(*(_QWORD *)(v4 + 16) + *(_QWORD *)(*(_QWORD *)v2 + 16LL) + 32LL) <= a1[10] ) /*0x10313771d*/
  {
    v7.i64[0] = *(_QWORD *)v2; /*0x103137723*/
    v7.i64[1] = v4; /*0x103137727*/
    v8 = v2[4]; /*0x10313772f*/
    v9 = 0; /*0x103137734*/
    nghttp3_rcbuf_incref(a1: v3); /*0x10313773d*/
    v5 = nghttp3_qpack_context_dtable_add((__int64)a1, a2: &v7, a3: 0, a4: 0); /*0x103137751*/
    nghttp3_rcbuf_decref(a1: v4); /*0x103137757*/
    a1[25] = 0; /*0x10313775c*/
    nghttp3_rcbuf_decref(a1: v3); /*0x10313776a*/
  }
  return v5; /*0x103137772*/
}

// Address: 0x10313777f | Name: _nghttp3_qpack_decoder_dtable_static_add
__int64 __fastcall nghttp3_qpack_decoder_dtable_static_add(_QWORD *a1)
{
  __int64 v1; // r14
  unsigned int v2; // r15d
  __m128i v5; // [rsp+0h] [rbp-30h] BYREF
  int v6; // [rsp+10h] [rbp-20h]
  char v7; // [rsp+14h] [rbp-1Ch]

  v1 = a1[25]; /*0x10313778c*/
  v2 = -402; /*0x1031377b5*/
  if ( (unsigned __int64)(*(_QWORD *)(v1 + 16) + *((_QWORD *)&stable + 9 * a1[29] + 2) + 32LL) <= a1[10] ) /*0x1031377bf*/
  {
    v5.i64[0] = (__int64)&stable + 72 * a1[29]; /*0x1031377cc*/
    v5.i64[1] = v1; /*0x1031377cf*/
    v6 = *(_DWORD *)(v5.i64[0] + 64); /*0x1031377d6*/
    v7 = 0; /*0x1031377d9*/
    v2 = nghttp3_qpack_context_dtable_add((__int64)a1, a2: &v5, a3: 0, a4: 0); /*0x1031377e6*/
    nghttp3_rcbuf_decref(a1: v1); /*0x1031377ec*/
    a1[25] = 0; /*0x1031377f1*/
  }
  return v2; /*0x1031377ff*/
}

// Address: 0x10313780a | Name: _nghttp3_qpack_decoder_set_max_concurrent_streams
unsigned __int64 __fastcall nghttp3_qpack_decoder_set_max_concurrent_streams(__int64 a1, unsigned __int64 a2)
{
  unsigned __int64 result; // rax

  result = *(_QWORD *)(a1 + 296); /*0x10313780e*/
  if ( result > a2 ) /*0x103137818*/
    a2 = *(_QWORD *)(a1 + 296); /*0x103137818*/
  *(_QWORD *)(a1 + 296) = a2; /*0x10313781c*/
  return result; /*0x103137823*/
}

// Address: 0x103137825 | Name: _nghttp3_qpack_stream_context_init
void __fastcall nghttp3_qpack_stream_context_init(__int64 a1, __int64 a2, __int64 a3)
{
  *(_OWORD *)(a1 + 72) = 0; /*0x10313783f*/
  nghttp3_buf_init(a1: (_OWORD *)(a1 + 8)); /*0x103137844*/
  nghttp3_buf_init(a1: (_OWORD *)(a1 + 40)); /*0x10313784d*/
  *(_OWORD *)(a1 + 88) = 0; /*0x103137855*/
  *(_OWORD *)(a1 + 116) = 0; /*0x10313785a*/
  *(_OWORD *)(a1 + 104) = 0; /*0x10313785f*/
  *(_QWORD *)(a1 + 136) = a3; /*0x103137864*/
  *(_QWORD *)(a1 + 96) = 8; /*0x10313786b*/
  *(_QWORD *)(a1 + 168) = 0; /*0x103137873*/
  *(_QWORD *)(a1 + 144) = a2; /*0x10313787e*/
  *(_DWORD *)(a1 + 176) = 0; /*0x103137885*/
  *(_OWORD *)(a1 + 152) = 0; /*0x103137890*/
}

// Address: 0x1031378a3 | Name: _nghttp3_qpack_stream_context_free
__int64 __fastcall nghttp3_qpack_stream_context_free(__int64 a1)
{
  nghttp3_rcbuf_decref(a1: *(_QWORD *)(a1 + 80)); /*0x1031378b0*/
  return nghttp3_rcbuf_decref(a1: *(_QWORD *)(a1 + 72)); /*0x1031378bd*/
}

// Address: 0x1031378c4 | Name: _nghttp3_qpack_stream_context_reset
void __fastcall nghttp3_qpack_stream_context_reset(__int64 a1)
{
  __int128 v2; // [rsp+0h] [rbp-20h]

  v2 = *(_OWORD *)(a1 + 136); /*0x1031378d7*/
  *(_OWORD *)(a1 + 72) = 0; /*0x1031378e2*/
  nghttp3_buf_init(a1: (_OWORD *)(a1 + 8)); /*0x1031378e6*/
  nghttp3_buf_init(a1: (_OWORD *)(a1 + 40)); /*0x1031378ef*/
  *(_OWORD *)(a1 + 88) = 0; /*0x1031378f7*/
  *(_OWORD *)(a1 + 116) = 0; /*0x1031378fb*/
  *(_OWORD *)(a1 + 104) = 0; /*0x1031378ff*/
  *(_OWORD *)(a1 + 136) = v2; /*0x103137907*/
  *(_QWORD *)(a1 + 96) = 8; /*0x10313790e*/
  *(_QWORD *)(a1 + 168) = 0; /*0x103137916*/
  *(_DWORD *)(a1 + 176) = 0; /*0x103137921*/
  *(_OWORD *)(a1 + 152) = 0; /*0x10313792b*/
}

// Address: 0x103137939 | Name: _nghttp3_qpack_stream_context_get_ricnt
__int64 __fastcall nghttp3_qpack_stream_context_get_ricnt(__int64 a1)
{
  return *(_QWORD *)(a1 + 152); /*0x103137944*/
}

// Address: 0x103137946 | Name: _nghttp3_qpack_decoder_read_request
char *__fastcall nghttp3_qpack_decoder_read_request(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        _BYTE *a4,
        char *a5,
        __int64 a6,
        int a7)
{
  char *v7; // rbx
  __int64 v8; // r15
  char *v9; // r14
  char *v11; // r15
  __int64 v12; // r13
  __int64 varint; // rax
  int v14; // eax
  __int64 v15; // rax
  __int64 v16; // rax
  __int64 v17; // r13
  unsigned __int64 v18; // rcx
  unsigned __int64 v19; // rax
  char v20; // al
  __int64 huffman_string; // rax
  int v22; // eax
  __int64 v23; // rax
  __int64 v24; // rsi
  __int64 v25; // rsi
  int v26; // eax
  __int64 v27; // rax
  __int64 v28; // rsi
  __int64 v29; // rsi
  _BYTE *v30; // rax
  __int64 v31; // rcx
  __int64 v32; // rax
  __int64 v33; // rdi
  int v34; // eax
  __int64 v36; // rbx
  _BYTE *v37; // rax
  __int64 v38; // rcx
  int v39; // eax
  __int64 v40; // rbx
  __int64 v42; // [rsp+10h] [rbp-80h]
  _QWORD *v43; // [rsp+18h] [rbp-78h]
  __int64 v44; // [rsp+20h] [rbp-70h]
  _QWORD *v45; // [rsp+28h] [rbp-68h]
  _QWORD *v46; // [rsp+30h] [rbp-60h]
  __int64 v47; // [rsp+38h] [rbp-58h]
  __int64 v48; // [rsp+40h] [rbp-50h]
  _BYTE *v51; // [rsp+58h] [rbp-38h]
  _DWORD v52[11]; // [rsp+64h] [rbp-2Ch] BYREF

  v7 = &a5[a6]; /*0x10313795a*/
  if ( a5 == nullptr ) /*0x103137960*/
    v7 = nullptr; /*0x103137960*/
  v8 = -108; /*0x103137964*/
  if ( *(_BYTE *)(a1 + 104) != 0 ) /*0x10313796f*/
    return (char *)v8; /*0x10313796f*/
  v9 = a5; /*0x103137975*/
  v42 = *(_QWORD *)(a1 + 48); /*0x10313797f*/
  *a4 = 0; /*0x103137983*/
  v11 = a5; /*0x103137986*/
  if ( v7 == a5 ) /*0x103137990*/
    goto LABEL_69; /*0x103137990*/
  v51 = a4; /*0x10313799a*/
  v43 = (_QWORD *)(a2 + 152); /*0x1031379a6*/
  v12 = a2 + 72; /*0x1031379aa*/
  v45 = (_QWORD *)(a2 + 8); /*0x1031379b4*/
  v46 = (_QWORD *)(a2 + 40); /*0x1031379bd*/
  v47 = a2 + 88; /*0x1031379c6*/
  v44 = a2 + 80; /*0x1031379cf*/
  v11 = a5; /*0x1031379d3*/
  v48 = a2 + 72; /*0x1031379d6*/
  while ( 2 ) /*0x103137a01*/
  {
    switch ( *(_DWORD *)(a2 + 168) ) /*0x103137a01*/
    {
      case 0: /*0x103137a01*/
        varint = qpack_read_varint(a1: v52, a2, a3: v11, a4: v7); /*0x103137a10*/
        if ( varint < 0 ) /*0x103137a18*/
          goto LABEL_84; /*0x103137a18*/
        v11 += varint; /*0x103137a1e*/
        if ( v52[0] == 0 ) /*0x103137a25*/
          goto LABEL_68; /*0x103137a25*/
        v14 = nghttp3_qpack_decoder_reconstruct_ricnt(a1, a2: v43, a3: *(_QWORD *)v47); /*0x103137a3a*/
        if ( v14 != 0 ) /*0x103137a41*/
          goto LABEL_73; /*0x103137a41*/
        *(_DWORD *)(a2 + 168) = 1; /*0x103137a47*/
        goto LABEL_58; /*0x103137a53*/
      case 1: /*0x103137a01*/
        if ( *v11 < 0 ) /*0x103137ab7*/
          *(_DWORD *)(a2 + 176) = 1; /*0x103137ab9*/
        *(_DWORD *)(a2 + 168) = 2; /*0x103137ac5*/
        *(_QWORD *)(a2 + 88) = 0; /*0x103137ad3*/
        *(_QWORD *)(a2 + 96) = 7; /*0x103137ad8*/
        *(_QWORD *)(a2 + 104) = 0; /*0x103137ae1*/
        goto LABEL_18; /*0x103137ae1*/
      case 2: /*0x103137a01*/
LABEL_18:
        v16 = qpack_read_varint(a1: v52, a2, a3: v11, a4: v7); /*0x103137ae6*/
        LODWORD(v17) = -401; /*0x103137af8*/
        if ( v16 < 0 ) /*0x103137b01*/
          goto LABEL_85; /*0x103137b01*/
        v11 += v16; /*0x103137b07*/
        if ( v52[0] == 0 ) /*0x103137b0e*/
          goto LABEL_68; /*0x103137b0e*/
        v18 = *(_QWORD *)(a2 + 88); /*0x103137b1d*/
        v19 = *(_QWORD *)(a2 + 152); /*0x103137b22*/
        if ( *(_DWORD *)(a2 + 176) != 0 ) /*0x103137b2a*/
        {
          if ( v19 <= v18 ) /*0x103137b2f*/
            goto LABEL_85; /*0x103137b2f*/
          v18 = ~v18; /*0x103137b35*/
        }
        *(_QWORD *)(a2 + 160) = v19 + v18; /*0x103137b38*/
        v12 = v48; /*0x103137b4b*/
        if ( v19 > *(_QWORD *)(a1 + 96) ) /*0x103137b4f*/
        {
          *(_DWORD *)(a2 + 168) = 13; /*0x10313801a*/
LABEL_77:
          *v51 |= 4u; /*0x103138026*/
          return (char *)(v11 - v9); /*0x103138030*/
        }
        *(_DWORD *)(a2 + 168) = 3; /*0x103137b55*/
        v20 = 0; /*0x103137b61*/
        *(_QWORD *)(a2 + 88) = 0; /*0x103137b63*/
        *(_QWORD *)(a2 + 104) = 0; /*0x103137b68*/
        goto LABEL_63; /*0x103137b6d*/
      case 3: /*0x103137a01*/
        switch ( (unsigned __int8)*v11 >> 4 ) /*0x103137b87*/
        {
          case 0: /*0x103137b87*/
            *(_DWORD *)(a2 + 172) = 3; /*0x103137f5e*/
            *(_DWORD *)(a2 + 120) = *v11 & 8; /*0x103137f71*/
            *(_DWORD *)(a2 + 124) = 1; /*0x103137f76*/
            *(_QWORD *)(a2 + 96) = 3; /*0x103137f7f*/
            goto LABEL_61; /*0x103137f88*/
          case 1: /*0x103137b87*/
            *(_DWORD *)(a2 + 124) = 1; /*0x103137f8d*/
            *(_QWORD *)(a2 + 96) = 4; /*0x103137f96*/
            *(_QWORD *)(a2 + 168) = &dword_100000004; /*0x103137fa9*/
            goto LABEL_62; /*0x103137fb1*/
          case 2: /*0x103137b87*/
          case 3: /*0x103137b87*/
            *(_DWORD *)(a2 + 172) = 4; /*0x103137f26*/
            *(_QWORD *)(a2 + 120) = *v11 & 0x10; /*0x103137f39*/
            *(_QWORD *)(a2 + 96) = 3; /*0x103137f47*/
            *(_DWORD *)(a2 + 168) = 5; /*0x103137f50*/
            goto LABEL_62; /*0x103137f5c*/
          case 4: /*0x103137b87*/
          case 5: /*0x103137b87*/
          case 6: /*0x103137b87*/
          case 7: /*0x103137b87*/
            *(_DWORD *)(a2 + 172) = 2; /*0x103137ed6*/
            *(_DWORD *)(a2 + 120) = *v11 & 0x20; /*0x103137ee9*/
            *(_DWORD *)(a2 + 124) = (*v11 & 0x10) == 0; /*0x103137ef7*/
            *(_QWORD *)(a2 + 96) = 4; /*0x103137efc*/
            goto LABEL_61; /*0x103137efc*/
          case 8: /*0x103137b87*/
          case 9: /*0x103137b87*/
          case 0xA: /*0x103137b87*/
          case 0xB: /*0x103137b87*/
          case 0xC: /*0x103137b87*/
          case 0xD: /*0x103137b87*/
          case 0xE: /*0x103137b87*/
          case 0xF: /*0x103137b87*/
            *(_DWORD *)(a2 + 172) = 0; /*0x103137b89*/
            *(_DWORD *)(a2 + 124) = (*v11 & 0x40) == 0; /*0x103137b9e*/
            *(_QWORD *)(a2 + 96) = 6; /*0x103137ba3*/
LABEL_61:
            *(_DWORD *)(a2 + 168) = 4; /*0x103137f05*/
            break; /*0x103137f05*/
        }
        goto LABEL_62; /*0x103137f05*/
      case 4: /*0x103137a01*/
        v15 = qpack_read_varint(a1: v52, a2, a3: v11, a4: v7); /*0x103137a65*/
        if ( v15 < 0 ) /*0x103137a6d*/
          goto LABEL_84; /*0x103137a6d*/
        v11 += v15; /*0x103137a73*/
        if ( v52[0] == 0 ) /*0x103137a7a*/
          goto LABEL_68; /*0x103137a7a*/
        switch ( *(_DWORD *)(a2 + 172) ) /*0x103137aa0*/
        {
          case 0: /*0x103137aa0*/
            v40 = a1; /*0x103138157*/
            v14 = nghttp3_qpack_decoder_brel2abs(a1, a2); /*0x103138161*/
            goto LABEL_96; /*0x103138166*/
          case 1: /*0x103137aa0*/
            v40 = a1; /*0x103138168*/
            v14 = nghttp3_qpack_decoder_pbrel2abs(a1, a2); /*0x103138172*/
LABEL_96:
            if ( v14 != 0 ) /*0x103138179*/
              goto LABEL_73; /*0x103138179*/
            nghttp3_qpack_decoder_emit_indexed(a1: v40, a2, a3); /*0x103138189*/
            goto LABEL_101; /*0x10313818e*/
          case 2: /*0x103137aa0*/
            v14 = nghttp3_qpack_decoder_brel2abs(a1, a2); /*0x103137aa9*/
            goto LABEL_56; /*0x103137aae*/
          case 3: /*0x103137aa0*/
            v14 = nghttp3_qpack_decoder_pbrel2abs(a1, a2); /*0x103137eac*/
LABEL_56:
            if ( v14 != 0 ) /*0x103137eb3*/
              goto LABEL_73; /*0x103137eb3*/
            *(_QWORD *)(a2 + 96) = 7; /*0x103137eb9*/
            *(_DWORD *)(a2 + 168) = 9; /*0x103137ec2*/
            break; /*0x103137ec2*/
          default:
            nghttp3_unreachable_fail(a1: "nghttp3_qpack.c", a2: 3527, a3: "nghttp3_qpack_decoder_read_request"); /*0x1031381dc*/
        }
        goto LABEL_58; /*0x103137ec2*/
      case 5: /*0x103137a01*/
        v22 = (unsigned __int8)*v11; /*0x103137c11*/
        *(_DWORD *)(a2 + 128) = _bittest(&v22, *(_DWORD *)(a2 + 96)); /*0x103137c22*/
        *(_DWORD *)(a2 + 168) = 6; /*0x103137c2a*/
        *(_QWORD *)(a2 + 88) = 0; /*0x103137c38*/
        *(_QWORD *)(a2 + 104) = 0; /*0x103137c3d*/
        goto LABEL_31; /*0x103137c3d*/
      case 6: /*0x103137a01*/
LABEL_31:
        v23 = qpack_read_varint(a1: v52, a2, a3: v11, a4: v7); /*0x103137c42*/
        if ( v23 < 0 ) /*0x103137c57*/
          goto LABEL_84; /*0x103137c57*/
        v11 += v23; /*0x103137c5d*/
        if ( v52[0] == 0 ) /*0x103137c64*/
          goto LABEL_68; /*0x103137c64*/
        v24 = *(_QWORD *)v47; /*0x103137c6e*/
        if ( *(_QWORD *)v47 > 0x100u ) /*0x103137c78*/
          goto LABEL_75; /*0x103137c78*/
        if ( *(_DWORD *)(a2 + 128) != 0 ) /*0x103137c87*/
        {
          *(_DWORD *)(a2 + 168) = 7; /*0x103137c8d*/
          nghttp3_qpack_huffman_decode_context_init(a1: a2); /*0x103137c9c*/
          v25 = 2LL * *(_QWORD *)(a2 + 88) + 1; /*0x103137ca6*/
        }
        else
        {
          *(_DWORD *)(a2 + 168) = 8; /*0x103137e62*/
          v25 = v24 + 1; /*0x103137e6e*/
        }
        v14 = nghttp3_rcbuf_new(a1: v12, a2: v25, a3: v42); /*0x103137e78*/
        if ( v14 != 0 ) /*0x103137e7f*/
          goto LABEL_73; /*0x103137e7f*/
        nghttp3_buf_wrap_init(a1: v45, a2: *(_QWORD *)(*(_QWORD *)v12 + 8LL), a3: *(_QWORD *)(*(_QWORD *)v12 + 16LL)); /*0x103137e95*/
        v20 = 0; /*0x103137e9a*/
        v9 = a5; /*0x103137e9c*/
        goto LABEL_63; /*0x103137ea3*/
      case 7: /*0x103137a01*/
        huffman_string = qpack_read_huffman_string(a1: a2, a2: v45, a3: v11, a4: v7); /*0x103137bbe*/
        if ( huffman_string < 0 ) /*0x103137bc6*/
          goto LABEL_84; /*0x103137bc6*/
        v11 += huffman_string; /*0x103137bcc*/
        if ( *(_QWORD *)v47 != 0 ) /*0x103137bd7*/
          goto LABEL_68; /*0x103137bd7*/
        **(_BYTE **)(a2 + 32) = 0; /*0x103137be2*/
        *(_QWORD *)(*(_QWORD *)(a2 + 72) + 16LL) = nghttp3_buf_len(a1: (__int64)v45); /*0x103137bf3*/
        *(_DWORD *)(a2 + 168) = 9; /*0x103137bf7*/
        *(_QWORD *)(a2 + 96) = 7; /*0x103137c03*/
        goto LABEL_62; /*0x103137c0c*/
      case 8: /*0x103137a01*/
        v17 = v7 - v11; /*0x103137d58*/
        if ( (unsigned __int64)(v7 - v11) >= *(_QWORD *)(a2 + 88) ) /*0x103137d68*/
          v17 = *(_QWORD *)(a2 + 88); /*0x103137d68*/
        v30 = (_BYTE *)nghttp3_cpymem(a1: *(_QWORD *)(a2 + 32), a2: v11, a3: v17); /*0x103137d72*/
        *(_QWORD *)(a2 + 32) = v30; /*0x103137d77*/
        v31 = *(_QWORD *)(a2 + 88); /*0x103137d7c*/
        *(_QWORD *)(a2 + 88) = v31 - v17; /*0x103137d87*/
        if ( v17 < 0 ) /*0x103137d8f*/
          goto LABEL_85; /*0x103137d8f*/
        v11 += v17; /*0x103137d95*/
        if ( v31 != v17 ) /*0x103137d9b*/
          goto LABEL_68; /*0x103137d9b*/
        *v30 = 0; /*0x103137da1*/
        *(_QWORD *)(*(_QWORD *)(a2 + 72) + 16LL) = nghttp3_buf_len(a1: (__int64)v45); /*0x103137db2*/
        *(_DWORD *)(a2 + 168) = 9; /*0x103137db6*/
        *(_QWORD *)(a2 + 96) = 7; /*0x103137dc2*/
LABEL_58:
        v20 = 0; /*0x103137ece*/
        goto LABEL_59; /*0x103137ece*/
      case 9: /*0x103137a01*/
        v26 = (unsigned __int8)*v11; /*0x103137cb3*/
        *(_DWORD *)(a2 + 128) = _bittest(&v26, *(_DWORD *)(a2 + 96)); /*0x103137cc4*/
        *(_DWORD *)(a2 + 168) = 10; /*0x103137ccc*/
        *(_QWORD *)(a2 + 88) = 0; /*0x103137cda*/
        *(_QWORD *)(a2 + 104) = 0; /*0x103137cdf*/
        goto LABEL_37; /*0x103137cdf*/
      case 0xA: /*0x103137a01*/
LABEL_37:
        v27 = qpack_read_varint(a1: v52, a2, a3: v11, a4: v7); /*0x103137ce4*/
        if ( v27 < 0 ) /*0x103137cf9*/
          goto LABEL_84; /*0x103137cf9*/
        v11 += v27; /*0x103137cff*/
        if ( v52[0] == 0 ) /*0x103137d06*/
          goto LABEL_68; /*0x103137d06*/
        v28 = *(_QWORD *)v47; /*0x103137d10*/
        if ( *(_QWORD *)v47 <= 0x10000u ) /*0x103137d1a*/
        {
          if ( *(_DWORD *)(a2 + 128) != 0 ) /*0x103137d29*/
          {
            *(_DWORD *)(a2 + 168) = 11; /*0x103137d2f*/
            nghttp3_qpack_huffman_decode_context_init(a1: a2); /*0x103137d3e*/
            v29 = 2LL * *(_QWORD *)(a2 + 88) + 1; /*0x103137d48*/
          }
          else
          {
            *(_DWORD *)(a2 + 168) = 12; /*0x103137e22*/
            v29 = v28 + 1; /*0x103137e2e*/
          }
          v14 = nghttp3_rcbuf_new(a1: v44, a2: v29, a3: v42); /*0x103137e3c*/
          if ( v14 != 0 ) /*0x103137e43*/
            goto LABEL_73; /*0x103137e43*/
          nghttp3_buf_wrap_init(a1: v46, a2: *(_QWORD *)(*(_QWORD *)v44 + 8LL), a3: *(_QWORD *)(*(_QWORD *)v44 + 16LL)); /*0x103137e59*/
          v20 = 1; /*0x103137e5e*/
LABEL_59:
          v12 = v48; /*0x103137ed0*/
LABEL_63:
          if ( ((unsigned __int8)v20 | (v11 != v7)) == 0 ) /*0x103137f1b*/
          {
            v11 = v7; /*0x103137fb6*/
LABEL_68:
            a4 = v51; /*0x103137fb9*/
LABEL_69:
            if ( a7 != 0 ) /*0x103137fc1*/
            {
              LODWORD(v17) = -401; /*0x103137fc3*/
              if ( *(_DWORD *)(a2 + 168) != 3 ) /*0x103137fd2*/
                goto LABEL_85; /*0x103137fd2*/
              *a4 |= 2u; /*0x103137fd8*/
              if ( *(_QWORD *)(a2 + 152) != 0 ) /*0x103137fe4*/
              {
                v14 = nghttp3_qpack_decoder_write_section_ack(a1, a2); /*0x103137fed*/
                if ( v14 != 0 ) /*0x103137ff4*/
                {
LABEL_73:
                  LODWORD(v17) = v14; /*0x103137ff6*/
                  goto LABEL_85; /*0x103137ff9*/
                }
              }
              *(_QWORD *)(a1 + 304) = 0; /*0x103138002*/
            }
            return (char *)(v11 - v9); /*0x10313800d*/
          }
          continue; /*0x103137f1b*/
        }
LABEL_75:
        LODWORD(v17) = -109; /*0x10313800f*/
LABEL_85:
        *(_BYTE *)(a1 + 104) = 1; /*0x1031380b2*/
        return (char *)(int)v17; /*0x1031380c0*/
      case 0xB: /*0x103137a01*/
        v32 = qpack_read_huffman_string(a1: a2, a2: v46, a3: v11, a4: v7); /*0x103138042*/
        if ( v32 < 0 ) /*0x10313804a*/
        {
LABEL_84:
          LODWORD(v17) = -401; /*0x1031380ac*/
          goto LABEL_85; /*0x1031380ac*/
        }
        v11 += v32; /*0x10313804c*/
        if ( *(_QWORD *)v47 != 0 ) /*0x103138057*/
          goto LABEL_68; /*0x103138057*/
        **(_BYTE **)(a2 + 64) = 0; /*0x103138062*/
        *(_QWORD *)(*(_QWORD *)(a2 + 80) + 16LL) = nghttp3_buf_len(a1: (__int64)v46); /*0x103138073*/
        v34 = *(_DWORD *)(a2 + 172); /*0x103138077*/
        if ( (unsigned int)(v34 - 2) < 2 ) /*0x103138085*/
          goto LABEL_92; /*0x103138085*/
        if ( v34 != 4 ) /*0x10313808e*/
          nghttp3_unreachable_fail(a1: "nghttp3_qpack.c", a2: 3685, a3: "nghttp3_qpack_decoder_read_request"); /*0x1031380a7*/
        goto LABEL_100; /*0x10313808e*/
      case 0xC: /*0x103137a01*/
        v36 = v7 - v11; /*0x1031380cf*/
        if ( (unsigned __int64)v36 >= *(_QWORD *)(a2 + 88) ) /*0x1031380df*/
          v36 = *(_QWORD *)(a2 + 88); /*0x1031380df*/
        v37 = (_BYTE *)nghttp3_cpymem(a1: *(_QWORD *)(a2 + 64), a2: v11, a3: v36); /*0x1031380e9*/
        *(_QWORD *)(a2 + 64) = v37; /*0x1031380ee*/
        v38 = *(_QWORD *)(a2 + 88); /*0x1031380f3*/
        *(_QWORD *)(a2 + 88) = v38 - v36; /*0x1031380fe*/
        if ( v36 < 0 ) /*0x103138106*/
        {
          LODWORD(v17) = v36; /*0x103138190*/
          goto LABEL_85; /*0x103138193*/
        }
        v11 += v36; /*0x10313810c*/
        if ( v38 != v36 ) /*0x103138112*/
          goto LABEL_68; /*0x103138112*/
        *v37 = 0; /*0x103138118*/
        *(_QWORD *)(*(_QWORD *)(a2 + 80) + 16LL) = nghttp3_buf_len(a1: (__int64)v46); /*0x103138129*/
        v39 = *(_DWORD *)(a2 + 172); /*0x10313812d*/
        if ( (unsigned int)(v39 - 2) >= 2 ) /*0x10313813b*/
        {
          if ( v39 != 4 ) /*0x10313819b*/
            nghttp3_unreachable_fail(a1: "nghttp3_qpack.c", a2: 3722, a3: "nghttp3_qpack_decoder_read_request"); /*0x1031381f4*/
LABEL_100:
          nghttp3_qpack_decoder_emit_literal(a1: v33, a2, a3); /*0x10313819d*/
        }
        else
        {
LABEL_92:
          v14 = nghttp3_qpack_decoder_emit_indexed_name(a1, a2, a3); /*0x10313813d*/
          if ( v14 != 0 ) /*0x10313814f*/
            goto LABEL_73; /*0x10313814f*/
        }
LABEL_101:
        *v51 |= 1u; /*0x1031381a9*/
        *(_DWORD *)(a2 + 168) = 3; /*0x1031381b0*/
        nghttp3_qpack_read_state_reset(a1: a2); /*0x1031381bf*/
        return (char *)(v11 - v9); /*0x1031381c4*/
      case 0xD: /*0x103137a01*/
        if ( *v43 > *(_QWORD *)(a1 + 96) ) /*0x103137ddf*/
          goto LABEL_77; /*0x103137ddf*/
        *(_DWORD *)(a2 + 168) = 3; /*0x103137de5*/
        *(_OWORD *)v12 = 0; /*0x103137df4*/
        nghttp3_buf_init(a1: v45); /*0x103137dfd*/
        nghttp3_buf_init(a1: v46); /*0x103137e06*/
        *(_OWORD *)(v47 + 28) = 0; /*0x103137e12*/
        *(_OWORD *)(v47 + 16) = 0; /*0x103137e16*/
        *(_OWORD *)v47 = 0; /*0x103137e1a*/
LABEL_62:
        v20 = 0; /*0x103137f11*/
        goto LABEL_63; /*0x103137f11*/
      default:
        goto LABEL_62;
    }
  }
}

// Address: 0x103138284 | Name: _nghttp3_qpack_decoder_reconstruct_ricnt
__int64 __fastcall nghttp3_qpack_decoder_reconstruct_ricnt(__int64 a1, unsigned __int64 *a2, unsigned __int64 a3)
{
  __int64 v3; // r8
  unsigned __int64 v4; // r10
  unsigned int v5; // r9d
  unsigned __int64 v6; // r8
  unsigned __int64 v7; // rcx
  bool v8; // cc

  if ( a3 == 0 ) /*0x10313828b*/
  {
    v7 = 0; /*0x1031382cd*/
LABEL_8:
    *a2 = v7; /*0x1031382cf*/
    return 0; /*0x1031382d2*/
  }
  v3 = *(_QWORD *)(a1 + 72) >> 5; /*0x103138294*/
  v4 = 2 * v3; /*0x103138298*/
  v5 = -401; /*0x10313829c*/
  if ( 2 * v3 >= a3 ) /*0x1031382a5*/
  {
    v6 = *(_QWORD *)(a1 + 96) + v3; /*0x1031382a7*/
    v7 = ~(v6 % v4) + v6 + a3; /*0x1031382b9*/
    if ( v7 <= v6 || (v8 = v7 <= v4, v7 -= v4, !v8) ) /*0x1031382c4*/
    {
      if ( v7 != 0 ) /*0x1031382c9*/
        goto LABEL_8; /*0x1031382c9*/
    }
  }
  return v5; /*0x1031382d8*/
}

// Address: 0x1031382da | Name: _nghttp3_qpack_decoder_brel2abs
__int64 __fastcall nghttp3_qpack_decoder_brel2abs(__int64 a1, __int64 a2)
{
  __int64 v2; // rcx
  unsigned __int64 v3; // rdx
  __int64 result; // rax
  unsigned __int64 v5; // r8
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax

  if ( *(_DWORD *)(a2 + 124) == 0 ) /*0x1031382e2*/
  {
    v7 = *(_QWORD *)(a2 + 88); /*0x10313832f*/
    *(_QWORD *)(a2 + 112) = v7; /*0x103138333*/
    if ( v7 >= 0x63 ) /*0x10313833b*/
      return 4294966895LL; /*0x10313832d*/
    return 0; /*0x10313833b*/
  }
  v2 = *(_QWORD *)(a2 + 88); /*0x1031382e4*/
  v3 = *(_QWORD *)(a2 + 160); /*0x1031382e8*/
  result = 4294966895LL; /*0x1031382f3*/
  if ( v3 >= v2 + 1 ) /*0x1031382fb*/
  {
    v5 = v3 + ~v2; /*0x103138303*/
    *(_QWORD *)(a2 + 112) = v5; /*0x103138306*/
    if ( v5 < *(_QWORD *)(a2 + 152) ) /*0x103138311*/
    {
      v6 = *(_QWORD *)(a1 + 96); /*0x103138313*/
      if ( v5 >= v6 || v2 - v3 + v6 >= *(_QWORD *)(a1 + 40) ) /*0x103138326*/
        return 4294966895LL; /*0x103138326*/
      return 0; /*0x10313833d*/
    }
  }
  return result; /*0x10313833f*/
}

// Address: 0x103138341 | Name: _nghttp3_qpack_decoder_emit_indexed
__int64 __fastcall nghttp3_qpack_decoder_emit_indexed(__int64 a1, __int64 a2, __int64 a3)
{
  bool v4; // zf
  __int64 v5; // rsi
  __int64 v6; // rax
  __int64 result; // rax

  v4 = *(_DWORD *)(a2 + 124) == 0; /*0x10313834a*/
  v5 = *(_QWORD *)(a2 + 112); /*0x10313834e*/
  if ( v4 ) /*0x103138352*/
  {
    *(_QWORD *)a3 = (char *)&stable + 72 * v5; /*0x103138397*/
    *(_QWORD *)(a3 + 8) = (char *)&stable + 72 * v5 + 32; /*0x1031383a2*/
    result = *((unsigned int *)&stable + 18 * v5 + 16); /*0x1031383a6*/
    *(_DWORD *)(a3 + 16) = result; /*0x1031383a9*/
    *(_BYTE *)(a3 + 20) = 0; /*0x1031383ac*/
  }
  else
  {
    v6 = *(_QWORD *)nghttp3_ringbuf_get(a1, a2: *(_QWORD *)(a1 + 96) + ~v5); /*0x103138360*/
    *(_OWORD *)a3 = *(_OWORD *)v6; /*0x103138366*/
    *(_QWORD *)(a3 + 16) = *(_QWORD *)(v6 + 16); /*0x10313836d*/
    nghttp3_rcbuf_incref(a1: *(_QWORD *)a3); /*0x103138374*/
    return nghttp3_rcbuf_incref(a1: *(_QWORD *)(a3 + 8)); /*0x103138383*/
  }
  return result; /*0x103138381*/
}

// Address: 0x1031383b7 | Name: _nghttp3_qpack_decoder_pbrel2abs
__int64 __fastcall nghttp3_qpack_decoder_pbrel2abs(__int64 a1, __int64 a2)
{
  unsigned __int64 v2; // rcx
  __int64 result; // rax
  unsigned __int64 v4; // rdx

  v2 = *(_QWORD *)(a2 + 88) + *(_QWORD *)(a2 + 160); /*0x1031383c2*/
  *(_QWORD *)(a2 + 112) = v2; /*0x1031383c6*/
  result = 4294966895LL; /*0x1031383ca*/
  if ( v2 < *(_QWORD *)(a2 + 152) ) /*0x1031383d6*/
  {
    if ( *(_DWORD *)(a2 + 124) != 0 ) /*0x1031383dc*/
    {
      v4 = *(_QWORD *)(a1 + 96); /*0x1031383de*/
      if ( v2 >= v4 || ~v2 + v4 >= *(_QWORD *)(a1 + 40) ) /*0x1031383f1*/
        return result; /*0x1031383f1*/
    }
    else if ( v2 >= 0x63 ) /*0x1031383f9*/
    {
      return result; /*0x1031383f9*/
    }
    return 0; /*0x1031383fb*/
  }
  return result; /*0x1031383fd*/
}

// Address: 0x1031383ff | Name: _nghttp3_qpack_decoder_emit_indexed_name
__int64 __fastcall nghttp3_qpack_decoder_emit_indexed_name(__int64 a1, __int64 a2, __int64 a3)
{
  unsigned __int64 v5; // rcx
  unsigned __int64 v6; // rsi
  __int64 result; // rax
  unsigned __int64 v8; // rsi
  __int64 *v9; // rax
  __int64 v10; // rdi
  bool v11; // zf
  _QWORD *v12; // r14
  char *v13; // rax

  v5 = *(_QWORD *)(a2 + 112); /*0x103138410*/
  if ( *(_DWORD *)(a2 + 124) == 0 ) /*0x103138414*/
  {
    v13 = (char *)&stable + 72 * v5; /*0x10313846b*/
    *(_QWORD *)a3 = v13; /*0x10313846f*/
    *(_QWORD *)(a3 + 8) = *(_QWORD *)(a2 + 80); /*0x103138476*/
    *(_DWORD *)(a3 + 16) = *((_DWORD *)v13 + 16); /*0x10313847d*/
    v12 = (_QWORD *)(a2 + 80); /*0x103138485*/
    *(_BYTE *)(a3 + 20) = *(_DWORD *)(a2 + 120) != 0; /*0x103138489*/
    goto LABEL_6; /*0x103138489*/
  }
  v6 = *(_QWORD *)(a1 + 96); /*0x103138416*/
  result = 4294966895LL; /*0x10313841a*/
  if ( v5 < v6 ) /*0x103138422*/
  {
    v8 = ~v5 + v6; /*0x103138427*/
    if ( v8 < *(_QWORD *)(a1 + 40) ) /*0x10313842e*/
    {
      v9 = *(__int64 **)nghttp3_ringbuf_get(a1, a2: v8); /*0x103138435*/
      v10 = *v9; /*0x103138438*/
      *(_QWORD *)a3 = *v9; /*0x10313843b*/
      *(_QWORD *)(a3 + 8) = *(_QWORD *)(a2 + 80); /*0x103138442*/
      *(_DWORD *)(a3 + 16) = *((_DWORD *)v9 + 4); /*0x103138449*/
      v11 = *(_DWORD *)(a2 + 120) == 0; /*0x10313844c*/
      v12 = (_QWORD *)(a2 + 80); /*0x103138451*/
      *(_BYTE *)(a3 + 20) = !v11; /*0x103138455*/
      nghttp3_rcbuf_incref(a1: v10); /*0x103138459*/
LABEL_6:
      *v12 = 0; /*0x10313848d*/
      return 0; /*0x103138494*/
    }
  }
  return result; /*0x103138496*/
}

// Address: 0x10313849b | Name: _nghttp3_qpack_decoder_emit_literal
__int64 __fastcall nghttp3_qpack_decoder_emit_literal(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v5; // rax
  __int64 result; // rax

  v5 = *(_QWORD *)(a2 + 72); /*0x1031384a8*/
  *(_OWORD *)a3 = *(_OWORD *)(a2 + 72); /*0x1031384b0*/
  result = qpack_lookup_token(a1: *(_QWORD *)(v5 + 8), a2: *(_QWORD *)(v5 + 16)); /*0x1031384bb*/
  *(_DWORD *)(a3 + 16) = result; /*0x1031384c0*/
  *(_BYTE *)(a3 + 20) = *(_DWORD *)(a2 + 120) != 0; /*0x1031384c8*/
  *(_OWORD *)(a2 + 72) = 0; /*0x1031384cf*/
  return result; /*0x1031384d4*/
}

// Address: 0x1031384d9 | Name: _nghttp3_qpack_decoder_write_section_ack
__int64 __fastcall nghttp3_qpack_decoder_write_section_ack(_QWORD *a1, __int64 a2)
{
  __int64 v4; // r12
  _QWORD *v5; // r15
  unsigned __int64 v6; // rcx
  __int64 result; // rax
  unsigned __int64 v8; // rax
  __int64 v9; // rsi
  unsigned __int64 v10; // rax
  unsigned __int64 v11; // rcx
  bool v12; // cc
  _BYTE *v13; // rcx
  unsigned __int64 v14; // rax
  _BYTE *v15; // rcx
  unsigned __int64 v16; // rax
  _BYTE *v17; // rdx
  unsigned __int64 v18; // rcx
  unsigned __int64 v19; // rcx

  v4 = 100; /*0x1031384f5*/
  if ( a1[37] >= 0x65u ) /*0x1031384fb*/
    v4 = a1[37]; /*0x1031384fb*/
  v5 = a1 + 32; /*0x1031384ff*/
  v6 = nghttp3_buf_len(a1: (__int64)(a1 + 32)); /*0x10313850e*/
  result = 4294967188LL; /*0x103138519*/
  if ( v6 <= 20 * v4 ) /*0x103138521*/
  {
    v8 = *(_QWORD *)(a2 + 144); /*0x103138527*/
    v9 = 1; /*0x10313852e*/
    if ( v8 >= 0x7F ) /*0x103138537*/
    {
      v10 = v8 - 127; /*0x103138539*/
      v9 = 2; /*0x10313853d*/
      if ( v10 >= 0x80 ) /*0x103138548*/
      {
        v11 = v10; /*0x10313854a*/
        do /*0x10313855d*/
        {
          v11 >>= 7; /*0x10313854d*/
          ++v9; /*0x103138551*/
          v12 = v10 <= 0x3FFF; /*0x103138554*/
          v10 = v11; /*0x10313855a*/
        }
        while ( !v12 ); /*0x10313855d*/
      }
    }
    result = reserve_buf(a1: v5, a2: v9, a3: a1[6]); /*0x103138566*/
    if ( (_DWORD)result == 0 ) /*0x10313856d*/
    {
      v13 = (_BYTE *)a1[35]; /*0x10313856f*/
      *v13 = 0x80; /*0x103138576*/
      v14 = *(_QWORD *)(a2 + 144); /*0x103138579*/
      if ( v14 > 0x7E ) /*0x103138584*/
      {
        *v13 = -1; /*0x10313858f*/
        v16 = v14 - 127; /*0x103138592*/
        v17 = v13 + 1; /*0x103138596*/
        if ( v16 >= 0x80 ) /*0x1031385a0*/
        {
          do /*0x1031385bc*/
          {
            v18 = v16; /*0x1031385a2*/
            *v17 = v16 | 0x80; /*0x1031385ab*/
            v16 >>= 7; /*0x1031385ae*/
            ++v17; /*0x1031385b2*/
          }
          while ( v18 > 0x3FFF ); /*0x1031385bc*/
          v13 = v17 - 1; /*0x1031385be*/
        }
        v15 = v13 + 2; /*0x1031385c2*/
        *v17 = v16; /*0x1031385c6*/
      }
      else
      {
        *v13 = v14 | 0x80; /*0x103138588*/
        v15 = v13 + 1; /*0x10313858a*/
      }
      a1[35] = v15; /*0x1031385c8*/
      v19 = *(_QWORD *)(a2 + 152); /*0x1031385cf*/
      result = 0; /*0x1031385d6*/
      if ( a1[36] < v19 ) /*0x1031385df*/
        a1[36] = v19; /*0x1031385e1*/
    }
  }
  return result; /*0x1031385e8*/
}

// Address: 0x1031385f1 | Name: _nghttp3_qpack_decoder_get_decoder_streamlen
__int64 __fastcall nghttp3_qpack_decoder_get_decoder_streamlen(__int64 a1)
{
  unsigned __int64 v1; // rax
  bool v2; // cc
  unsigned __int64 v3; // rax
  __int64 v4; // rbx
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rcx

  v1 = *(_QWORD *)(a1 + 96); /*0x1031385f7*/
  v2 = v1 <= *(_QWORD *)(a1 + 288); /*0x1031385fb*/
  v3 = v1 - *(_QWORD *)(a1 + 288); /*0x1031385fb*/
  if ( v2 ) /*0x103138602*/
  {
    v4 = 0; /*0x103138637*/
  }
  else
  {
    v4 = 1; /*0x103138604*/
    if ( v3 >= 0x3F ) /*0x10313860d*/
    {
      v5 = v3 - 63; /*0x10313860f*/
      v4 = 2; /*0x103138613*/
      if ( v5 >= 0x80 ) /*0x10313861e*/
      {
        v6 = v5; /*0x103138620*/
        do /*0x103138633*/
        {
          v6 >>= 7; /*0x103138623*/
          ++v4; /*0x103138627*/
          v2 = v5 <= 0x3FFF; /*0x10313862a*/
          v5 = v6; /*0x103138630*/
        }
        while ( !v2 ); /*0x103138633*/
      }
    }
  }
  return v4 + nghttp3_buf_len(a1: a1 + 256); /*0x10313864c*/
}

// Address: 0x10313864f | Name: _nghttp3_qpack_decoder_write_decoder
__int64 __fastcall nghttp3_qpack_decoder_write_decoder(_QWORD *a1, __int64 a2)
{
  unsigned __int64 v3; // r15
  unsigned __int64 v4; // r12
  unsigned __int64 v5; // r14
  __int64 *v6; // r13
  __int64 v7; // rax
  _BYTE *v8; // rcx
  _BYTE *v9; // rax
  unsigned __int64 v10; // r14
  unsigned __int64 v11; // rcx
  __int64 v13; // [rsp+0h] [rbp-40h]
  __int64 v14; // [rsp+8h] [rbp-38h]

  v3 = a1[12]; /*0x103138667*/
  v4 = a1[36]; /*0x10313866b*/
  v5 = 0; /*0x103138672*/
  if ( v3 >= v4 ) /*0x10313867b*/
    v5 = v3 - v4; /*0x10313867b*/
  v6 = a1 + 32; /*0x10313867f*/
  if ( nghttp3_buf_len(a1: (__int64)(a1 + 32)) != 0 ) /*0x103138691*/
  {
    v13 = *(_QWORD *)(a2 + 24); /*0x10313869b*/
    v14 = a1[34]; /*0x1031386a6*/
    v7 = nghttp3_buf_len(a1: (__int64)v6); /*0x1031386ad*/
    *(_QWORD *)(a2 + 24) = nghttp3_cpymem(a1: v13, a2: v14, a3: v7); /*0x1031386c6*/
  }
  if ( v3 > v4 ) /*0x1031386cd*/
  {
    v8 = *(_BYTE **)(a2 + 24); /*0x1031386d3*/
    v9 = v8 + 1; /*0x1031386d7*/
    if ( v5 > 0x3E ) /*0x1031386df*/
    {
      *v8 = 63; /*0x1031386e6*/
      v10 = v5 - 63; /*0x1031386e9*/
      if ( v10 >= 0x80 ) /*0x1031386f4*/
      {
        do /*0x10313870e*/
        {
          v11 = v10; /*0x1031386f6*/
          *v9 = v10 | 0x80; /*0x1031386fe*/
          v10 >>= 7; /*0x103138700*/
          ++v9; /*0x103138704*/
        }
        while ( v11 > 0x3FFF ); /*0x10313870e*/
        v8 = v9 - 1; /*0x103138710*/
      }
      *v9 = v10; /*0x103138718*/
      v9 = v8 + 2; /*0x10313871b*/
    }
    else
    {
      *v8 = v5; /*0x1031386e1*/
    }
    *(_QWORD *)(a2 + 24) = v9; /*0x103138722*/
    a1[36] = a1[12]; /*0x10313872a*/
  }
  return nghttp3_buf_reset(a1: v6); /*0x103138734*/
}

// Address: 0x103138747 | Name: _nghttp3_qpack_decoder_cancel_stream
__int64 __fastcall nghttp3_qpack_decoder_cancel_stream(_QWORD *a1, unsigned __int64 a2)
{
  __int64 v4; // r12
  _QWORD *v5; // r15
  unsigned __int64 v6; // rcx
  __int64 result; // rax
  __int64 v8; // rsi
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rcx
  bool v11; // cc
  _BYTE *v12; // rax
  _BYTE *v13; // rax
  unsigned __int64 v14; // r14
  _BYTE *v15; // rcx
  unsigned __int64 v16; // rax

  v4 = 100; /*0x103138763*/
  if ( a1[37] >= 0x65u ) /*0x103138769*/
    v4 = a1[37]; /*0x103138769*/
  v5 = a1 + 32; /*0x10313876d*/
  v6 = nghttp3_buf_len(a1: (__int64)(a1 + 32)); /*0x10313877c*/
  result = 4294967188LL; /*0x103138787*/
  if ( v6 <= 20 * v4 ) /*0x10313878f*/
  {
    v8 = 1; /*0x103138795*/
    if ( a2 >= 0x3F ) /*0x10313879e*/
    {
      v9 = a2 - 63; /*0x1031387a0*/
      v8 = 2; /*0x1031387a4*/
      if ( a2 - 63 >= 0x80 ) /*0x1031387af*/
      {
        v10 = a2 - 63; /*0x1031387b1*/
        do /*0x1031387c4*/
        {
          v10 >>= 7; /*0x1031387b4*/
          ++v8; /*0x1031387b8*/
          v11 = v9 <= 0x3FFF; /*0x1031387bb*/
          v9 = v10; /*0x1031387c1*/
        }
        while ( !v11 ); /*0x1031387c4*/
      }
    }
    result = reserve_buf(a1: v5, a2: v8, a3: a1[6]); /*0x1031387cd*/
    if ( (_DWORD)result == 0 ) /*0x1031387d4*/
    {
      v12 = (_BYTE *)a1[35]; /*0x1031387d6*/
      if ( a2 > 0x3E ) /*0x1031387e1*/
      {
        *v12 = 127; /*0x1031387ef*/
        v14 = a2 - 63; /*0x1031387f2*/
        v15 = v12 + 1; /*0x1031387f6*/
        if ( v14 >= 0x80 ) /*0x103138801*/
        {
          do /*0x10313881a*/
          {
            v16 = v14; /*0x103138803*/
            *v15 = v14 | 0x80; /*0x10313880b*/
            v14 >>= 7; /*0x10313880d*/
            ++v15; /*0x103138811*/
          }
          while ( v16 > 0x3FFF ); /*0x10313881a*/
          v12 = v15 - 1; /*0x10313881c*/
        }
        v13 = v12 + 2; /*0x103138820*/
        *v15 = v14; /*0x103138824*/
      }
      else
      {
        *v12 = a2 | 0x40; /*0x1031387e7*/
        v13 = v12 + 1; /*0x1031387ea*/
      }
      a1[35] = v13; /*0x103138827*/
      return 0; /*0x10313882e*/
    }
  }
  return result; /*0x103138830*/
}

// Address: 0x103138839 | Name: _nghttp3_qpack_encoder_new2
__int64 __fastcall nghttp3_qpack_encoder_new2(__int64 *a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v8; // rax
  __int64 v9; // r13

  v8 = nghttp3_mem_malloc(a1: a4, a2: 1032); /*0x10313885b*/
  if ( v8 == 0 ) /*0x103138863*/
    return 4294966395LL; /*0x103138880*/
  v9 = v8; /*0x103138865*/
  nghttp3_qpack_encoder_init(a1: v8, a2, a3, a4); /*0x103138874*/
  *a1 = v9; /*0x103138879*/
  return 0; /*0x103138889*/
}

// Address: 0x103138894 | Name: _nghttp3_qpack_encoder_new
__int64 __fastcall nghttp3_qpack_encoder_new(__int64 *a1, __int64 a2, __int64 a3)
{
  return nghttp3_qpack_encoder_new2(a1, a2, a3: 0, a4: a3); /*0x10313889d*/
}

// Address: 0x1031388a3 | Name: _nghttp3_qpack_encoder_del
__int64 __fastcall nghttp3_qpack_encoder_del(__int64 *a1)
{
  __int64 v2; // r14
  __int64 result; // rax

  if ( a1 != nullptr ) /*0x1031388a6*/
  {
    v2 = a1[6]; /*0x1031388b2*/
    nghttp3_qpack_encoder_free(a1); /*0x1031388b6*/
    return nghttp3_mem_free(a1: v2, a2: (__int64)a1); /*0x1031388c5*/
  }
  return result; /*0x1031388ca*/
}

// Address: 0x1031388cb | Name: _nghttp3_qpack_stream_context_new
__int64 __fastcall nghttp3_qpack_stream_context_new(__int64 *a1, __int64 a2, __int64 a3)
{
  __int64 v6; // rax
  __int64 v7; // r12

  v6 = nghttp3_mem_malloc(a1: a3, a2: 184); /*0x1031388e7*/
  if ( v6 == 0 ) /*0x1031388ef*/
    return 4294966395LL; /*0x103138966*/
  v7 = v6; /*0x1031388f1*/
  *(_OWORD *)(v6 + 72) = 0; /*0x1031388fb*/
  nghttp3_buf_init(a1: (_OWORD *)(v6 + 8)); /*0x1031388ff*/
  nghttp3_buf_init(a1: (_OWORD *)(v7 + 40)); /*0x10313890b*/
  *(_OWORD *)(v7 + 88) = 0; /*0x103138913*/
  *(_OWORD *)(v7 + 116) = 0; /*0x103138919*/
  *(_OWORD *)(v7 + 104) = 0; /*0x10313891f*/
  *(_QWORD *)(v7 + 136) = a3; /*0x103138925*/
  *(_QWORD *)(v7 + 96) = 8; /*0x10313892d*/
  *(_QWORD *)(v7 + 168) = 0; /*0x103138936*/
  *(_QWORD *)(v7 + 144) = a2; /*0x103138942*/
  *(_DWORD *)(v7 + 176) = 0; /*0x10313894a*/
  *(_OWORD *)(v7 + 152) = 0; /*0x103138956*/
  *a1 = v7; /*0x10313895f*/
  return 0; /*0x10313896b*/
}

// Address: 0x103138974 | Name: _nghttp3_qpack_stream_context_del
__int64 __fastcall nghttp3_qpack_stream_context_del(_QWORD *a1)
{
  __int64 v2; // r14
  __int64 result; // rax

  if ( a1 != nullptr ) /*0x103138977*/
  {
    v2 = a1[17]; /*0x103138987*/
    nghttp3_rcbuf_decref(a1: a1[10]); /*0x10313898e*/
    nghttp3_rcbuf_decref(a1: a1[9]); /*0x103138997*/
    return nghttp3_mem_free(a1: v2, a2: (__int64)a1); /*0x1031389a6*/
  }
  return result; /*0x1031389ab*/
}

// Address: 0x1031389ac | Name: _nghttp3_qpack_decoder_new
__int64 __fastcall nghttp3_qpack_decoder_new(__int64 *a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v8; // rax
  __int64 v9; // r13

  v8 = nghttp3_mem_malloc(a1: a4, a2: 312); /*0x1031389ce*/
  if ( v8 == 0 ) /*0x1031389d6*/
    return 4294966395LL; /*0x1031389f3*/
  v9 = v8; /*0x1031389d8*/
  nghttp3_qpack_decoder_init(a1: v8, a2, a3, a4); /*0x1031389e7*/
  *a1 = v9; /*0x1031389ec*/
  return 0; /*0x1031389fc*/
}

// Address: 0x103138a07 | Name: _nghttp3_qpack_decoder_del
__int64 __fastcall nghttp3_qpack_decoder_del(__int64 *a1)
{
  __int64 v2; // r14
  __int64 result; // rax

  if ( a1 != nullptr ) /*0x103138a0a*/
  {
    v2 = a1[6]; /*0x103138a16*/
    nghttp3_qpack_decoder_free(a1); /*0x103138a1a*/
    return nghttp3_mem_free(a1: v2, a2: (__int64)a1); /*0x103138a29*/
  }
  return result; /*0x103138a2e*/
}

// Address: 0x103138a2f | Name: _nghttp3_qpack_decoder_get_icnt
__int64 __fastcall nghttp3_qpack_decoder_get_icnt(__int64 a1)
{
  return *(_QWORD *)(a1 + 96); /*0x103138a37*/
}

// Address: 0x103138b1c | Name: _nghttp3_qpack_huffman_encode_count
unsigned __int64 __fastcall nghttp3_qpack_huffman_encode_count(__int64 a1, __int64 a2)
{
  __int64 v2; // rax
  __int64 i; // rdx

  if ( a2 == 0 ) /*0x103138b1f*/
    return 0; /*0x103138b4e*/
  v2 = 0; /*0x103138b25*/
  for ( i = 0; i != a2; ++i ) /*0x103138b2e*/
    v2 += huffman_sym_table[2 * *(unsigned __int8 *)(a1 + i)]; /*0x103138b39*/
  return (unsigned __int64)(v2 + 7) >> 3; /*0x103138b4d*/
}

// Address: 0x103138b51 | Name: _nghttp3_qpack_huffman_encode
_BYTE *__fastcall nghttp3_qpack_huffman_encode(_BYTE *a1, __int64 a2, __int64 a3)
{
  _BYTE *result; // rax
  __int64 v4; // r9
  unsigned __int64 v5; // r8
  __int64 v6; // rdi
  unsigned __int64 v7; // rbx
  __int64 v8; // r8

  result = a1; /*0x103138b51*/
  if ( a3 != 0 ) /*0x103138b57*/
  {
    v4 = 0; /*0x103138b62*/
    v5 = 0; /*0x103138b6c*/
    v6 = 0; /*0x103138b6f*/
    do /*0x103138bb8*/
    {
      v7 = v5; /*0x103138b74*/
      v8 = *(unsigned __int8 *)(a2 + v4); /*0x103138b77*/
      v6 |= (unsigned __int64)huffman_sym_table[2 * v8 + 1] << -(char)(v7 + 32); /*0x103138b8f*/
      v5 = v7 + huffman_sym_table[2 * v8]; /*0x103138b92*/
      if ( v5 >= 0x20 ) /*0x103138b99*/
      {
        *(_DWORD *)result = _byteswap_ulong(HIDWORD(v6)); /*0x103138ba4*/
        result += 4; /*0x103138ba6*/
        v6 <<= 32; /*0x103138baa*/
        v5 -= 32LL; /*0x103138bae*/
      }
      ++v4; /*0x103138bb2*/
    }
    while ( a3 != v4 ); /*0x103138bb8*/
    if ( v5 >= 8 ) /*0x103138bbe*/
    {
      do /*0x103138bd8*/
      {
        *result++ = HIBYTE(v6); /*0x103138bc7*/
        v6 <<= 8; /*0x103138bcc*/
        v5 -= 8LL; /*0x103138bd0*/
      }
      while ( v5 > 7 ); /*0x103138bd8*/
    }
    if ( v5 != 0 ) /*0x103138bdd*/
      *result++ = HIBYTE(v6) | ~(-1 << (8 - v5)); /*0x103138bf3*/
  }
  return result; /*0x103138bfa*/
}

// Address: 0x103138bfb | Name: _nghttp3_qpack_huffman_decode_context_init
void __fastcall nghttp3_qpack_huffman_decode_context_init(__int64 a1)
{
  *(_WORD *)a1 = 0; /*0x103138bff*/
  *(_BYTE *)(a1 + 2) = 1; /*0x103138c04*/
}

// Address: 0x103138c0a | Name: _nghttp3_qpack_huffman_decode
__int64 __fastcall nghttp3_qpack_huffman_decode(unsigned __int16 *a1, _BYTE *a2, __int64 a3, __int64 a4, int a5)
{
  unsigned __int16 v5; // r11
  __int64 v6; // rax
  _BYTE *v7; // r9
  unsigned __int8 v8; // bl
  __int64 v9; // r14
  char *v10; // r11
  int v11; // r15d
  __int64 v12; // rbx
  char *v13; // r15
  char v14; // r14
  _BYTE *v15; // r9
  __int64 result; // rax

  v5 = *a1; /*0x103138c13*/
  if ( a4 != 0 ) /*0x103138c1a*/
  {
    v6 = 0; /*0x103138c1c*/
    v7 = a2; /*0x103138c25*/
    do /*0x103138c86*/
    {
      v8 = *(_BYTE *)(a3 + v6); /*0x103138c28*/
      v9 = v8 >> 4; /*0x103138c2f*/
      v10 = (char *)&qpack_huffman_decode_table + 64 * v5; /*0x103138c3b*/
      v11 = *(unsigned __int16 *)&v10[4 * v9]; /*0x103138c3e*/
      if ( (v10[4 * v9 + 2] & 2) != 0 ) /*0x103138c49*/
        *v7++ = v10[4 * v9 + 3]; /*0x103138c53*/
      v12 = v8 & 0xF; /*0x103138c59*/
      v13 = (char *)&qpack_huffman_decode_table + (unsigned int)(v11 << 6); /*0x103138c60*/
      v5 = *(_WORD *)&v13[4 * v12]; /*0x103138c63*/
      v14 = v13[4 * v12 + 2]; /*0x103138c68*/
      if ( (v14 & 2) != 0 ) /*0x103138c71*/
        *v7++ = v13[4 * v12 + 3]; /*0x103138c7a*/
      ++v6; /*0x103138c80*/
    }
    while ( a4 != v6 ); /*0x103138c86*/
  }
  else
  {
    v14 = *((_BYTE *)a1 + 2); /*0x103138c8a*/
    v7 = a2; /*0x103138c8e*/
  }
  *a1 = v5; /*0x103138c91*/
  *((_BYTE *)a1 + 2) = v14; /*0x103138c95*/
  v15 = (_BYTE *)(v7 - a2); /*0x103138c99*/
  result = -108; /*0x103138ca0*/
  if ( (v14 & 1) != 0 ) /*0x103138ca7*/
    result = (__int64)v15; /*0x103138ca7*/
  if ( a5 == 0 ) /*0x103138cae*/
    return (__int64)v15; /*0x103138cae*/
  return result; /*0x103138cb2*/
}

// Address: 0x103138cb9 | Name: _nghttp3_qpack_huffman_decode_failure_state
_BOOL8 __fastcall nghttp3_qpack_huffman_decode_failure_state(_WORD *a1)
{
  return *a1 == 256; /*0x103138cc7*/
}

// Address: 0x103138cc9 | Name: _nghttp3_range_init
void __fastcall nghttp3_range_init(_QWORD *a1, __int64 a2, __int64 a3)
{
  *a1 = a2; /*0x103138ccd*/
  a1[1] = a3; /*0x103138cd0*/
}

// Address: 0x103138cd6 | Name: _nghttp3_range_intersect
unsigned __int64 __fastcall nghttp3_range_intersect(unsigned __int64 *a1, unsigned __int64 *a2)
{
  unsigned __int64 v2; // rcx
  unsigned __int64 v3; // rdi
  unsigned __int64 result; // rax
  unsigned __int64 v5; // rdx

  v2 = *a1; /*0x103138cda*/
  v3 = a1[1]; /*0x103138cdd*/
  result = *a2; /*0x103138ce1*/
  if ( v2 > *a2 ) /*0x103138ce7*/
    result = v2; /*0x103138ce7*/
  v5 = a2[1]; /*0x103138ceb*/
  if ( v3 < v5 ) /*0x103138cf2*/
    v5 = v3; /*0x103138cf2*/
  if ( result >= v5 ) /*0x103138cfb*/
    return 0; /*0x103138cff*/
  return result; /*0x103138d03*/
}

// Address: 0x103138d05 | Name: _nghttp3_range_len
__int64 __fastcall nghttp3_range_len(_QWORD *a1)
{
  return a1[1] - *a1; /*0x103138d10*/
}

// Address: 0x103138d12 | Name: _nghttp3_range_eq
_BOOL8 __fastcall nghttp3_range_eq(_QWORD *a1, _QWORD *a2)
{
  _BOOL8 result; // rax

  result = false; /*0x103138d19*/
  if ( *a1 == *a2 ) /*0x103138d1e*/
    return a1[1] == a2[1]; /*0x103138d2a*/
  return result; /*0x103138d2d*/
}

// Address: 0x103138d2f | Name: _nghttp3_range_cut
__int64 __fastcall nghttp3_range_cut(_QWORD *a1, _QWORD *a2, _QWORD *a3, __int64 *a4)
{
  __int64 v4; // r8
  __int64 result; // rax
  __int64 v6; // rcx

  v4 = *a4; /*0x103138d36*/
  *a1 = *a3; /*0x103138d39*/
  a1[1] = v4; /*0x103138d3c*/
  result = a4[1]; /*0x103138d40*/
  v6 = a3[1]; /*0x103138d44*/
  *a2 = result; /*0x103138d48*/
  a2[1] = v6; /*0x103138d4b*/
  return result; /*0x103138d4f*/
}

// Address: 0x103138d51 | Name: _nghttp3_range_not_after
_BOOL8 __fastcall nghttp3_range_not_after(__int64 a1, __int64 a2)
{
  return *(_QWORD *)(a1 + 8) <= *(_QWORD *)(a2 + 8); /*0x103138d62*/
}

// Address: 0x103138d64 | Name: _nghttp3_ratelim_init
void __fastcall nghttp3_ratelim_init(_QWORD *a1, __int64 a2, __int64 a3, __int64 a4)
{
  *a1 = a2; /*0x103138d68*/
  a1[1] = a3; /*0x103138d6b*/
  a1[2] = a2; /*0x103138d6f*/
  a1[3] = 0; /*0x103138d73*/
  a1[4] = a4; /*0x103138d7b*/
}

// Address: 0x103138d81 | Name: _nghttp3_ratelim_drain
__int64 __fastcall nghttp3_ratelim_drain(unsigned __int64 *a1, unsigned __int64 a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // r9
  unsigned __int64 v4; // rcx
  unsigned __int64 v5; // r8
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // r9
  bool v8; // cc
  unsigned __int64 v9; // r8
  unsigned __int64 v10; // rdx
  unsigned __int64 v11; // rax
  unsigned __int64 v12; // r8
  unsigned __int64 v13; // rax
  __int64 result; // rax
  bool v15; // cf
  unsigned __int64 v16; // rcx

  v3 = a3 - a1[4]; /*0x103138d88*/
  if ( a3 == a1[4] ) /*0x103138d8c*/
  {
    v4 = a1[2]; /*0x103138d8e*/
  }
  else
  {
    a1[4] = a3; /*0x103138d94*/
    v4 = *a1; /*0x103138d98*/
    v5 = a1[1]; /*0x103138d9b*/
    v6 = ~a1[3] / v3; /*0x103138dab*/
    v7 = a1[3] + v5 * v3; /*0x103138db2*/
    v8 = v5 <= v6; /*0x103138db5*/
    v9 = -1; /*0x103138db8*/
    if ( v8 ) /*0x103138dbf*/
      v9 = v7; /*0x103138dbf*/
    v10 = v9 / 0x3B9ACA00; /*0x103138dd7*/
    if ( v4 <= v9 / 0x3B9ACA00 || (v11 = a1[2]) >= v4 - v9 / 0x3B9ACA00 ) /*0x103138dea*/
    {
      a1[2] = v4; /*0x103138e02*/
      v12 = 0; /*0x103138e06*/
    }
    else
    {
      v12 = v9 % 0x3B9ACA00; /*0x103138df3*/
      v13 = v10 + v11; /*0x103138df6*/
      a1[2] = v13; /*0x103138df9*/
      v4 = v13; /*0x103138dfd*/
    }
    a1[3] = v12; /*0x103138e09*/
  }
  result = 0xFFFFFFFFLL; /*0x103138e0d*/
  v15 = v4 < a2; /*0x103138e12*/
  v16 = v4 - a2; /*0x103138e12*/
  if ( !v15 ) /*0x103138e15*/
  {
    a1[2] = v16; /*0x103138e17*/
    return 0; /*0x103138e1b*/
  }
  return result; /*0x103138e1d*/
}

// Address: 0x103138e1f | Name: _nghttp3_rcbuf_new
__int64 __fastcall nghttp3_rcbuf_new(__int64 *a1, __int64 a2, __int64 a3)
{
  _QWORD *v6; // rax
  __int64 v7; // rax

  v6 = (_QWORD *)nghttp3_mem_malloc(a1: a3, a2: a2 + 32); /*0x103138e39*/
  if ( v6 == nullptr ) /*0x103138e41*/
    return 4294966395LL; /*0x103138e66*/
  *a1 = (__int64)v6; /*0x103138e43*/
  *v6 = a3; /*0x103138e46*/
  *(_QWORD *)(*a1 + 8) = v6 + 4; /*0x103138e50*/
  v7 = *a1; /*0x103138e54*/
  *(_QWORD *)(v7 + 16) = a2; /*0x103138e57*/
  *(_DWORD *)(v7 + 24) = 1; /*0x103138e5b*/
  return 0; /*0x103138e6f*/
}

// Address: 0x103138e76 | Name: _nghttp3_rcbuf_new2
__int64 __fastcall nghttp3_rcbuf_new2(__int64 *a1, __int64 a2, __int64 a3, __int64 a4)
{
  _QWORD *v8; // rax
  __int64 v9; // rax
  _BYTE *v10; // rax

  v8 = (_QWORD *)nghttp3_mem_malloc(a1: a4, a2: a3 + 33); /*0x103138e94*/
  if ( v8 == nullptr ) /*0x103138e9c*/
    return 4294966395LL; /*0x103138edb*/
  *a1 = (__int64)v8; /*0x103138e9e*/
  *v8 = a4; /*0x103138ea1*/
  *(_QWORD *)(*a1 + 8) = v8 + 4; /*0x103138eab*/
  v9 = *a1; /*0x103138eaf*/
  *(_DWORD *)(v9 + 24) = 1; /*0x103138eb2*/
  *(_QWORD *)(v9 + 16) = a3; /*0x103138eb9*/
  v10 = *(_BYTE **)(v9 + 8); /*0x103138ebd*/
  if ( a3 != 0 ) /*0x103138ec4*/
    v10 = (_BYTE *)nghttp3_cpymem(a1: v10, a2, a3); /*0x103138ecf*/
  *v10 = 0; /*0x103138ed4*/
  return 0; /*0x103138ee0*/
}

// Address: 0x103138ee9 | Name: _nghttp3_rcbuf_del
__int64 __fastcall nghttp3_rcbuf_del(__int64 *a1)
{
  return nghttp3_mem_free(a1: *a1, a2: (__int64)a1); /*0x103138ef3*/
}

// Address: 0x103138ef9 | Name: _nghttp3_rcbuf_incref
__int64 __fastcall nghttp3_rcbuf_incref(__int64 a1)
{
  __int64 result; // rax

  result = *(unsigned int *)(a1 + 24); /*0x103138efd*/
  if ( (_DWORD)result != -1 ) /*0x103138f03*/
  {
    result = (unsigned int)(result + 1); /*0x103138f05*/
    *(_DWORD *)(a1 + 24) = result; /*0x103138f07*/
  }
  return result; /*0x103138f0a*/
}

// Address: 0x103138f0c | Name: _nghttp3_rcbuf_decref
void __fastcall nghttp3_rcbuf_decref(__int64 a1)
{
  int v1; // eax
  int v2; // eax

  if ( a1 != 0 ) /*0x103138f13*/
  {
    v1 = *(_DWORD *)(a1 + 24); /*0x103138f18*/
    if ( v1 != -1 ) /*0x103138f1e*/
    {
      v2 = v1 - 1; /*0x103138f20*/
      *(_DWORD *)(a1 + 24) = v2; /*0x103138f22*/
      if ( v2 == 0 ) /*0x103138f25*/
        nghttp3_mem_free(a1: *(_QWORD *)a1, a2: a1); /*0x103138f2d*/
    }
  }
}

// END _free_n part 2/5, 400 functions
