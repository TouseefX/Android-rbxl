// _free_c -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 400 functions, part 76 of 166


// Address: 0x102feeca3 | Name: _crypto_secretstream_xchacha20poly1305_tag_message
__int64 crypto_secretstream_xchacha20poly1305_tag_message()
{
  return 0; /*0x102feeca9*/
}

// Address: 0x102feecab | Name: _crypto_secretstream_xchacha20poly1305_tag_push
__int64 crypto_secretstream_xchacha20poly1305_tag_push()
{
  return 1; /*0x102feecb4*/
}

// Address: 0x102feecb6 | Name: _crypto_secretstream_xchacha20poly1305_tag_rekey
__int64 crypto_secretstream_xchacha20poly1305_tag_rekey()
{
  return 2; /*0x102feecbf*/
}

// Address: 0x102feecc1 | Name: _crypto_secretstream_xchacha20poly1305_tag_final
__int64 crypto_secretstream_xchacha20poly1305_tag_final()
{
  return 3; /*0x102feecca*/
}

// Address: 0x102feeccc | Name: _crypto_sign_statebytes
__int64 crypto_sign_statebytes()
{
  return 208; /*0x102feecd5*/
}

// Address: 0x102feecd7 | Name: _crypto_sign_bytes
__int64 crypto_sign_bytes()
{
  return 64; /*0x102feece0*/
}

// Address: 0x102feece2 | Name: _crypto_sign_seedbytes
__int64 crypto_sign_seedbytes()
{
  return 32; /*0x102feeceb*/
}

// Address: 0x102feeced | Name: _crypto_sign_publickeybytes
__int64 crypto_sign_publickeybytes()
{
  return 32; /*0x102feecf6*/
}

// Address: 0x102feecf8 | Name: _crypto_sign_secretkeybytes
__int64 crypto_sign_secretkeybytes()
{
  return 64; /*0x102feed01*/
}

// Address: 0x102feed03 | Name: _crypto_sign_messagebytes_max
__int64 crypto_sign_messagebytes_max()
{
  return -65; /*0x102feed0e*/
}

// Address: 0x102feed10 | Name: _crypto_sign_primitive
const char *crypto_sign_primitive()
{
  return "ed25519"; /*0x102feed1b*/
}

// Address: 0x102feed1d | Name: _crypto_sign_seed_keypair
__int64 crypto_sign_seed_keypair()
{
  return crypto_sign_ed25519_seed_keypair(); /*0x102feed21*/
}

// Address: 0x102feed27 | Name: _crypto_sign_keypair
__int64 crypto_sign_keypair()
{
  return crypto_sign_ed25519_keypair(); /*0x102feed2b*/
}

// Address: 0x102feed31 | Name: _crypto_sign
__int64 crypto_sign()
{
  return crypto_sign_ed25519(); /*0x102feed35*/
}

// Address: 0x102feed3b | Name: _crypto_sign_open
__int64 __fastcall crypto_sign_open(void *a1)
{
  return crypto_sign_ed25519_open(__dst: a1); /*0x102feed3f*/
}

// Address: 0x102feed45 | Name: _crypto_sign_detached
__int64 crypto_sign_detached()
{
  return crypto_sign_ed25519_detached(); /*0x102feed49*/
}

// Address: 0x102feed4f | Name: _crypto_sign_verify_detached
__int64 crypto_sign_verify_detached()
{
  return crypto_sign_ed25519_verify_detached(); /*0x102feed53*/
}

// Address: 0x102feed59 | Name: _crypto_sign_init
__int64 crypto_sign_init()
{
  return crypto_sign_ed25519ph_init(); /*0x102feed5d*/
}

// Address: 0x102feed63 | Name: _crypto_sign_update
__int64 crypto_sign_update()
{
  return crypto_sign_ed25519ph_update(); /*0x102feed67*/
}

// Address: 0x102feed6d | Name: _crypto_sign_final_create
__int64 crypto_sign_final_create()
{
  return crypto_sign_ed25519ph_final_create(); /*0x102feed71*/
}

// Address: 0x102feed77 | Name: _crypto_sign_final_verify
__int64 crypto_sign_final_verify()
{
  return crypto_sign_ed25519ph_final_verify(); /*0x102feed7b*/
}

// Address: 0x102feed81 | Name: _crypto_sign_ed25519ph_statebytes
__int64 crypto_sign_ed25519ph_statebytes()
{
  return 208; /*0x102feed8a*/
}

// Address: 0x102feed8c | Name: _crypto_sign_ed25519_bytes
__int64 crypto_sign_ed25519_bytes()
{
  return 64; /*0x102feed95*/
}

// Address: 0x102feed97 | Name: _crypto_sign_ed25519_seedbytes
__int64 crypto_sign_ed25519_seedbytes()
{
  return 32; /*0x102feeda0*/
}

// Address: 0x102feeda2 | Name: _crypto_sign_ed25519_publickeybytes
__int64 crypto_sign_ed25519_publickeybytes()
{
  return 32; /*0x102feedab*/
}

// Address: 0x102feedad | Name: _crypto_sign_ed25519_secretkeybytes
__int64 crypto_sign_ed25519_secretkeybytes()
{
  return 64; /*0x102feedb6*/
}

// Address: 0x102feedb8 | Name: _crypto_sign_ed25519_messagebytes_max
__int64 crypto_sign_ed25519_messagebytes_max()
{
  return -65; /*0x102feedc3*/
}

// Address: 0x102feedc5 | Name: _crypto_sign_ed25519_sk_to_seed
__int64 __fastcall crypto_sign_ed25519_sk_to_seed(_OWORD *a1, __int128 *a2)
{
  __int128 v2; // xmm0

  v2 = *a2; /*0x102feedc9*/
  a1[1] = a2[1]; /*0x102feedd0*/
  *a1 = v2; /*0x102feedd4*/
  return 0; /*0x102feedd9*/
}

// Address: 0x102feeddb | Name: _crypto_sign_ed25519_sk_to_pk
__int64 __fastcall crypto_sign_ed25519_sk_to_pk(_OWORD *a1, __int64 a2)
{
  __int128 v2; // xmm0

  v2 = *(_OWORD *)(a2 + 32); /*0x102feeddf*/
  a1[1] = *(_OWORD *)(a2 + 48); /*0x102feede7*/
  *a1 = v2; /*0x102feedeb*/
  return 0; /*0x102feedf0*/
}

// Address: 0x102feedf2 | Name: _crypto_sign_ed25519ph_init
__int64 __fastcall crypto_sign_ed25519ph_init(_OWORD *a1)
{
  crypto_hash_sha512_init(a1); /*0x102feedf6*/
  return 0; /*0x102feedfd*/
}

// Address: 0x102feedff | Name: _crypto_sign_ed25519ph_update
__int64 __fastcall crypto_sign_ed25519ph_update(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  return crypto_hash_sha512_update(a1, a2, a3); /*0x102feee03*/
}

// Address: 0x102feee09 | Name: _crypto_sign_ed25519ph_final_create
__int64 __fastcall crypto_sign_ed25519ph_final_create(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  _BYTE v8[72]; // [rsp+0h] [rbp-70h] BYREF

  crypto_hash_sha512_final(a1, a2: (__int64)v8); /*0x102feee36*/
  return _crypto_sign_ed25519_detached(a1: a2, a2: a3, a3: v8, a4: 64, a5: a4, a6: 1); /*0x102feee67*/
}

// Address: 0x102feee79 | Name: _crypto_sign_ed25519ph_final_verify
__int64 __fastcall crypto_sign_ed25519ph_final_verify(__int64 a1, __int64 a2, __int64 a3)
{
  _BYTE v6[64]; // [rsp+0h] [rbp-60h] BYREF

  crypto_hash_sha512_final(a1, a2: (__int64)v6); /*0x102feeea1*/
  return _crypto_sign_ed25519_verify_detached(a1: a2, a2: v6, a3: 64, a4: a3, a5: 1); /*0x102feeecf*/
}

// Address: 0x102feeedf | Name: _crypto_sign_ed25519_seed_keypair
__int64 __fastcall crypto_sign_ed25519_seed_keypair(__int128 *a1, __int64 a2, __int128 *a3)
{
  __int128 v6; // xmm0
  __int128 v7; // xmm0
  _BYTE v9[192]; // [rsp+0h] [rbp-C0h] BYREF

  crypto_hash_sha512(a1: a2, a2: (__int64)a3, a3: 0x20u); /*0x102feef05*/
  *(_BYTE *)a2 &= 0xF8u; /*0x102feef0a*/
  *(_BYTE *)(a2 + 31) = *(_BYTE *)(a2 + 31) & 0x3F | 0x40; /*0x102feef14*/
  _sodium_ge25519_scalarmult_base(a1: v9, a2); /*0x102feef24*/
  _sodium_ge25519_p3_tobytes(a1, a2: v9); /*0x102feef2f*/
  v6 = *a3; /*0x102feef34*/
  *(_OWORD *)(a2 + 16) = a3[1]; /*0x102feef3d*/
  *(_OWORD *)a2 = v6; /*0x102feef41*/
  v7 = *a1; /*0x102feef44*/
  *(_OWORD *)(a2 + 48) = a1[1]; /*0x102feef4d*/
  *(_OWORD *)(a2 + 32) = v7; /*0x102feef51*/
  return 0; /*0x102feef57*/
}

// Address: 0x102feef67 | Name: _crypto_sign_ed25519_keypair
__int64 __fastcall crypto_sign_ed25519_keypair(__int128 *a1, __int64 a2)
{
  __int128 v5[2]; // [rsp+0h] [rbp-40h] BYREF

  randombytes_buf(a1: v5, a2: 32); /*0x102feef94*/
  crypto_sign_ed25519_seed_keypair(a1, a2, a3: v5); /*0x102feefa2*/
  sodium_memzero(a1: v5, a2: 32); /*0x102feefaf*/
  return 0; /*0x102feefc6*/
}

// Address: 0x102feefd6 | Name: _crypto_sign_ed25519_pk_to_curve25519
__int64 __fastcall crypto_sign_ed25519_pk_to_curve25519(__int64 a1)
{
  unsigned int v2; // r14d
  __int64 v3; // r13
  __m128i v4; // xmm1
  __int32 v5; // r15d
  __int64 v6; // r10
  __int64 v7; // rdi
  __int64 v8; // r13
  __int64 v9; // r9
  __int64 v10; // rdx
  __int64 v11; // r12
  __int64 v12; // rcx
  __int64 v13; // r15
  __int64 v14; // r9
  __int64 v15; // r13
  __int64 v16; // r8
  __int64 v17; // rdx
  __int64 v18; // r14
  __int64 v19; // r11
  __int64 v20; // r13
  __int64 v21; // r10
  __int64 v22; // rcx
  __int64 v23; // r9
  __int64 v24; // rdi
  __int64 v25; // r10
  __int64 v26; // r12
  __int64 v27; // r11
  __int64 v28; // r8
  __int64 v29; // r13
  __int64 v30; // rdx
  __int64 v31; // r15
  unsigned __int64 v32; // r14
  __int64 v33; // rax
  __int64 v34; // r8
  __int64 v35; // r9
  __int64 v36; // r11
  unsigned __int64 v37; // r12
  __int64 v38; // rbx
  __int64 v39; // r15
  unsigned __int64 v40; // r10
  _BYTE v42[40]; // [rsp+8h] [rbp-258h] BYREF
  __m128i v43; // [rsp+30h] [rbp-230h] BYREF
  __m128i v44; // [rsp+40h] [rbp-220h] BYREF
  __int64 v45; // [rsp+50h] [rbp-210h]
  __int64 v46; // [rsp+A8h] [rbp-1B8h]
  __int64 v47; // [rsp+B0h] [rbp-1B0h]
  __int64 v48; // [rsp+B8h] [rbp-1A8h]
  __int64 v49; // [rsp+C0h] [rbp-1A0h]
  __int64 v50; // [rsp+C8h] [rbp-198h]
  __int64 v51; // [rsp+D0h] [rbp-190h]
  __int64 v52; // [rsp+D8h] [rbp-188h]
  __int64 v53; // [rsp+E0h] [rbp-180h]
  __int64 v54; // [rsp+E8h] [rbp-178h]
  __int64 v55; // [rsp+F0h] [rbp-170h]
  __int64 v56; // [rsp+F8h] [rbp-168h]
  __int64 v57; // [rsp+100h] [rbp-160h]
  __int64 v58; // [rsp+108h] [rbp-158h]
  __int64 v59; // [rsp+110h] [rbp-150h]
  __int64 v60; // [rsp+118h] [rbp-148h]
  __int64 v61; // [rsp+120h] [rbp-140h]
  __int64 v62; // [rsp+128h] [rbp-138h]
  __int64 v63; // [rsp+130h] [rbp-130h]
  __int64 v64; // [rsp+138h] [rbp-128h]
  __int64 v65; // [rsp+140h] [rbp-120h]
  __int64 v66; // [rsp+148h] [rbp-118h]
  __int64 v67; // [rsp+150h] [rbp-110h]
  __int64 v68; // [rsp+158h] [rbp-108h]
  __int64 v69; // [rsp+160h] [rbp-100h]
  __int64 v70; // [rsp+168h] [rbp-F8h]
  __int64 v71; // [rsp+170h] [rbp-F0h]
  __int64 v72; // [rsp+178h] [rbp-E8h]
  __int64 v73; // [rsp+180h] [rbp-E0h]
  __int64 v74; // [rsp+188h] [rbp-D8h]
  __int64 v75; // [rsp+190h] [rbp-D0h]
  __int64 v76; // [rsp+198h] [rbp-C8h]
  __int64 v77; // [rsp+1A0h] [rbp-C0h]
  __int64 v78; // [rsp+1A8h] [rbp-B8h]
  __int64 v79; // [rsp+1B0h] [rbp-B0h]
  __int64 v80; // [rsp+1B8h] [rbp-A8h]
  __int64 v81; // [rsp+1C0h] [rbp-A0h]
  __int64 v82; // [rsp+1C8h] [rbp-98h]
  __m128i v83; // [rsp+1D0h] [rbp-90h] BYREF
  __m128i v84; // [rsp+1E0h] [rbp-80h]
  unsigned __int64 v85; // [rsp+1F0h] [rbp-70h]
  _DWORD v86[12]; // [rsp+200h] [rbp-60h] BYREF

  v2 = -1; /*0x102fef007*/
  if ( (unsigned int)_sodium_ge25519_frombytes_negate_vartime(a1: v42) == 0 /*0x102fef037*/
    && (unsigned int)_sodium_ge25519_has_small_order(a1: v42) == 0
    && (unsigned int)_sodium_ge25519_is_on_main_subgroup(a1: v42) != 0 )
  {
    v60 = v43.i32[3]; /*0x102fef044*/
    v3 = v43.i32[1]; /*0x102fef04b*/
    v46 = a1; /*0x102fef052*/
    v64 = v43.i32[2]; /*0x102fef060*/
    v4 = _mm_loadu_si128(&v44); /*0x102fef083*/
    v83 = _mm_sub_epi32(_mm_cvtepi8_epi64(1), _mm_loadu_si128(&v43)); /*0x102fef092*/
    v59 = v44.i32[3]; /*0x102fef09e*/
    v79 = v44.i32[1]; /*0x102fef0ac*/
    v63 = v44.i32[2]; /*0x102fef0ba*/
    v70 = v44.i32[0]; /*0x102fef0c8*/
    v84 = _mm_sub_epi32((__m128i)0LL, v4); /*0x102fef0db*/
    v61 = v45; /*0x102fef0e8*/
    v85 = _mm_sub_epi32((__m128i)0LL, (__m128i)(unsigned __int64)v45).u64[0]; /*0x102fef0f8*/
    v5 = v43.i32[0] + 1; /*0x102fef0fe*/
    _sodium_fe25519_invert(a1: &v83, a2: &v83); /*0x102fef107*/
    v58 = v83.i32[1]; /*0x102fef113*/
    v48 = v5 * (__int64)v83.i32[0]; /*0x102fef16c*/
    v73 = v5 * (__int64)v83.i32[3]; /*0x102fef18c*/
    v75 = v5 * (__int64)v84.i32[1]; /*0x102fef1a8*/
    v66 = v5 * (__int64)v84.i32[3]; /*0x102fef1c1*/
    v47 = v5 * (__int64)(int)v85; /*0x102fef1d6*/
    v51 = v5 * (__int64)SHIDWORD(v85); /*0x102fef1e1*/
    v50 = v5 * (__int64)v83.i32[1] + v3 * v83.i32[0]; /*0x102fef1f5*/
    v6 = 2 * (int)v3; /*0x102fef204*/
    v62 = v5 * (__int64)v84.i32[0] + v6 * v83.i32[3]; /*0x102fef20e*/
    v49 = v5 * (__int64)v84.i32[2] + v6 * v84.i32[1]; /*0x102fef21c*/
    v65 = v3 * v84.i32[0]; /*0x102fef249*/
    v7 = v3 * v84.i32[2]; /*0x102fef253*/
    v82 = v3 * (int)v85; /*0x102fef25b*/
    v52 = v5 * (__int64)v83.i32[2] + v6 * v83.i32[1] + v64 * v83.i32[0]; /*0x102fef28b*/
    v53 = v73 + v3 * v83.i32[2] + v64 * v83.i32[1] + v60 * v83.i32[0]; /*0x102fef2b7*/
    v8 = v64 * v83.i32[3] + v60 * v83.i32[2]; /*0x102fef2da*/
    v9 = 2 * (int)v60; /*0x102fef2eb*/
    v67 = v64 * v84.i32[0] + v9 * v83.i32[3]; /*0x102fef2f5*/
    v56 = v7 + v64 * v84.i32[1] + v60 * v84.i32[0]; /*0x102fef314*/
    v55 = v6 * v84.i32[3] + v64 * v84.i32[2] + v9 * v84.i32[1]; /*0x102fef341*/
    v73 = 19 * v84.i32[3]; /*0x102fef362*/
    v10 = 19 * HIDWORD(v85); /*0x102fef370*/
    v54 = v10 * v6 + v64 * 19 * (int)v85 + v9 * v73; /*0x102fef37e*/
    v11 = v60 * v84.i32[2]; /*0x102fef393*/
    v76 = 19 * (int)v85; /*0x102fef39b*/
    v81 = v10; /*0x102fef3ae*/
    v60 = v10 * v64 + (int)v76 * v60; /*0x102fef3b8*/
    v62 += v9 * v83.i32[1] + v64 * v83.i32[2] + v70 * v83.i32[0]; /*0x102fef3ef*/
    v71 = v82 + v64 * v84.i32[3] + v11 + v70 * v84.i32[1]; /*0x102fef416*/
    v64 = v10 * v9 + v70 * (int)v76; /*0x102fef42b*/
    v65 += v75 + v8 + v70 * v83.i32[1] + v79 * v83.i32[0]; /*0x102fef461*/
    v12 = 2 * (int)v79; /*0x102fef499*/
    v57 = v70 * v84.i32[0] + v12 * v83.i32[3]; /*0x102fef4a6*/
    v67 += v12 * v83.i32[1] + v70 * v83.i32[2] + v63 * v83.i32[0]; /*0x102fef4d9*/
    v78 = 19 * v84.i32[1]; /*0x102fef4f0*/
    v82 = 19 * v84.i32[0]; /*0x102fef4fe*/
    v75 = 19 * v84.i32[2]; /*0x102fef516*/
    v68 = v70 * v75 + v12 * v78 + v63 * v82; /*0x102fef527*/
    v69 = v70 * v73 + v79 * v75 + v63 * v78; /*0x102fef550*/
    v74 = v10 * v70 + (int)v76 * v79 + v63 * v73; /*0x102fef57e*/
    v13 = v66 + v56 + v70 * v83.i32[3] + v79 * v83.i32[2] + v63 * v83.i32[1] + v59 * v83.i32[0]; /*0x102fef5aa*/
    LODWORD(v70) = 19 * v83.i32[3]; /*0x102fef5d3*/
    v72 = v79 * v84.i32[0] + v63 * v83.i32[3] + v59 * v83.i32[2]; /*0x102fef5ea*/
    v14 = 2 * (int)v59; /*0x102fef603*/
    v77 = v12 * v73 + v63 * v75 + v14 * v78; /*0x102fef621*/
    v66 = v10 * v12 + v63 * (int)v76 + v14 * v73; /*0x102fef64e*/
    v15 = v59 * v82; /*0x102fef65c*/
    v16 = v59 * v75; /*0x102fef663*/
    v59 = v10 * v63 + (int)v76 * v59; /*0x102fef679*/
    v17 = (int)v61; /*0x102fef687*/
    v18 = v55 + v57 + v14 * v83.i32[1] + v63 * v83.i32[2] + (int)v61 * (__int64)v83.i32[0]; /*0x102fef6af*/
    v79 = v14 * 19 * v83.i32[3] + (int)v61 * (__int64)(19 * v83.i32[2]); /*0x102fef6d5*/
    v19 = v15 + (int)v61 * (__int64)(19 * v83.i32[3]); /*0x102fef6e3*/
    v63 = v16 + (int)v61 * v78; /*0x102fef6ed*/
    HIDWORD(v7) = HIDWORD(v61); /*0x102fef6f7*/
    v20 = v61 >> 32; /*0x102fef6fa*/
    v80 = (v61 >> 32) * v83.i32[0]; /*0x102fef702*/
    v21 = (v61 >> 32) * 19 * v83.i32[2]; /*0x102fef709*/
    v61 = v82; /*0x102fef714*/
    v82 *= v20; /*0x102fef71f*/
    v22 = v81 * v14 + v17 * (int)v76; /*0x102fef74b*/
    v80 += v51 + v71 + v72 + v17 * v83.i32[1]; /*0x102fef77c*/
    v23 = 2 * HIDWORD(v7); /*0x102fef789*/
    v24 = v54 + v68 + v79 + v48 + v23 * 19 * v83.i32[1]; /*0x102fef7a8*/
    v25 = v60 + v69 + v19 + v50 + v21; /*0x102fef7c0*/
    v26 = v64 + v77 + v52 + v17 * v61 + v23 * 19 * v83.i32[3]; /*0x102fef7e7*/
    v82 += v74 + v63 + v53; /*0x102fef80a*/
    v27 = v66 + v62 + v17 * v75 + v23 * v78; /*0x102fef82a*/
    v28 = v59 + v65 + v17 * v73 + v20 * v75; /*0x102fef84c*/
    v29 = v13 + v81 * v17 + (int)v76 * v20; /*0x102fef879*/
    v81 = v18 + v47 + v23 * v81; /*0x102fef88a*/
    v30 = v25 + ((v24 + 0x2000000) >> 26); /*0x102fef8a1*/
    v31 = v28 + ((v27 + 0x2000000) >> 26); /*0x102fef8bc*/
    v32 = v27 - ((v27 + 0x2000000) & 0xFFFFFFFFFC000000LL); /*0x102fef8c5*/
    v33 = v26 + ((v30 + 0x1000000) >> 25); /*0x102fef8d8*/
    v34 = v22 + v67 + v49 + v23 * v73 + ((v31 + 0x1000000) >> 25); /*0x102fef8f8*/
    v35 = v82 + ((v33 + 0x2000000) >> 26); /*0x102fef90c*/
    v36 = v29 + ((v34 + 0x2000000) >> 26); /*0x102fef92a*/
    v37 = v32 + ((v35 + 0x1000000) >> 25); /*0x102fef93e*/
    v38 = v81 + ((v36 + 0x1000000) >> 25); /*0x102fef958*/
    LODWORD(v29) = v31 - ((v31 + 0x1000000) & 0xFE000000) + ((v37 + 0x2000000) >> 26); /*0x102fef970*/
    v39 = v80 + ((v38 + 0x2000000) >> 26); /*0x102fef98a*/
    v40 = v24 - ((v24 + 0x2000000) & 0xFFFFFFFFFC000000LL) + 19 * ((v39 + 0x1000000) >> 25); /*0x102fef9a9*/
    v86[0] = v40 - ((v40 + 0x2000000) & 0xFC000000); /*0x102fef9d0*/
    v86[1] = v30 - ((v30 + 0x1000000) & 0xFE000000) + ((v40 + 0x2000000) >> 26); /*0x102fef9d3*/
    v86[2] = v33 - ((v33 + 0x2000000) & 0xFC000000); /*0x102fef9d6*/
    v86[3] = v35 - ((v35 + 0x1000000) & 0xFE000000); /*0x102fef9d9*/
    v86[4] = v37 - ((v37 + 0x2000000) & 0xFC000000); /*0x102fef9dd*/
    v86[5] = v29; /*0x102fef9e1*/
    v86[6] = v34 - ((v34 + 0x2000000) & 0xFC000000); /*0x102fef9e5*/
    v86[7] = v36 - ((v36 + 0x1000000) & 0xFE000000); /*0x102fef9e9*/
    v86[8] = v38 - ((v38 + 0x2000000) & 0xFC000000); /*0x102fef9ed*/
    v86[9] = v39 - ((v39 + 0x1000000) & 0xFE000000); /*0x102fef9f0*/
    _sodium_fe25519_tobytes(a1: v46, a2: v86); /*0x102fef9fb*/
    return 0; /*0x102fefa00*/
  }
  return v2; /*0x102fefa16*/
}

// Address: 0x102fefa2d | Name: _crypto_sign_ed25519_sk_to_curve25519
__int64 __fastcall crypto_sign_ed25519_sk_to_curve25519(__int64 a1, __int64 a2)
{
  __int128 v4; // [rsp+0h] [rbp-60h] BYREF
  __int64 v5; // [rsp+10h] [rbp-50h]
  int v6; // [rsp+18h] [rbp-48h]
  __int16 v7; // [rsp+1Ch] [rbp-44h]
  char v8; // [rsp+1Eh] [rbp-42h]
  char v9; // [rsp+1Fh] [rbp-41h]

  crypto_hash_sha512(a1: (__int64)&v4, a2, a3: 0x20u); /*0x102fefa55*/
  LOBYTE(v4) = v4 & 0xF8; /*0x102fefa5a*/
  v9 = v9 & 0x3F | 0x40; /*0x102fefa66*/
  *(_OWORD *)a1 = v4; /*0x102fefa6e*/
  *(_QWORD *)(a1 + 16) = v5; /*0x102fefa75*/
  *(_DWORD *)(a1 + 24) = v6; /*0x102fefa7d*/
  *(_WORD *)(a1 + 28) = v7; /*0x102fefa85*/
  *(_BYTE *)(a1 + 30) = v8; /*0x102fefa8d*/
  *(_BYTE *)(a1 + 31) = v9; /*0x102fefa94*/
  sodium_memzero(a1: &v4, a2: 64); /*0x102fefa9f*/
  return 0; /*0x102fefab6*/
}

// Address: 0x102fefac4 | Name: __crypto_sign_ed25519_verify_detached
__int64 __fastcall _crypto_sign_ed25519_verify_detached(
        __int64 a1,
        __int64 a2,
        unsigned __int64 a3,
        __int64 a4,
        unsigned int a5)
{
  unsigned int v10; // r14d
  _BYTE v12[160]; // [rsp+0h] [rbp-440h] BYREF
  _BYTE v13[160]; // [rsp+A0h] [rbp-3A0h] BYREF
  _BYTE v14[120]; // [rsp+140h] [rbp-300h] BYREF
  _BYTE v15[160]; // [rsp+1B8h] [rbp-288h] BYREF
  _BYTE v16[160]; // [rsp+258h] [rbp-1E8h] BYREF
  unsigned __int64 v17; // [rsp+2F8h] [rbp-148h]
  _BYTE v18[64]; // [rsp+300h] [rbp-140h] BYREF
  _BYTE v19[208]; // [rsp+340h] [rbp-100h] BYREF

  if ( *(_BYTE *)(a1 + 63) < 0x10u || (unsigned int)_sodium_sc25519_is_canonical(a1: a1 + 32) != 0 ) /*0x102fefb06*/
  {
    v17 = a3; /*0x102fefb0c*/
    v10 = -1; /*0x102fefb1b*/
    if ( (unsigned int)_sodium_ge25519_is_canonical(a1: a4) != 0 /*0x102fefb79*/
      && (unsigned int)_sodium_ge25519_frombytes_negate_vartime(a1: v16) == 0
      && (unsigned int)_sodium_ge25519_has_small_order(a1: v16) == 0
      && (unsigned int)_sodium_ge25519_frombytes(a1: v15, a2: a1) == 0
      && (unsigned int)_sodium_ge25519_has_small_order(a1: v15) == 0 )
    {
      _crypto_sign_ed25519_ref10_hinit(a1: v19, a2: a5); /*0x102fefb8c*/
      crypto_hash_sha512_update(a1: (__int64)v19, a2: a1, a3: 0x20u); /*0x102fefb9c*/
      crypto_hash_sha512_update(a1: (__int64)v19, a2: a4, a3: 0x20u); /*0x102fefbac*/
      crypto_hash_sha512_update(a1: (__int64)v19, a2, a3: v17); /*0x102fefbbe*/
      crypto_hash_sha512_final(a1: (__int64)v19, a2: (__int64)v18); /*0x102fefbd0*/
      _sodium_sc25519_reduce(a1: v18); /*0x102fefbd8*/
      _sodium_ge25519_double_scalarmult_vartime(a1: v14, a2: v18, a3: v16, a4: a1 + 32); /*0x102fefbf8*/
      _sodium_ge25519_p2_to_p3(a1: v13, a2: v14); /*0x102fefc0a*/
      _sodium_ge25519_p3_sub(a1: v12, a2: v15, a3: v13); /*0x102fefc23*/
      return (unsigned int)_sodium_ge25519_has_small_order(a1: v12) - 1; /*0x102fefc33*/
    }
  }
  else
  {
    return (unsigned int)-1; /*0x102fefc38*/
  }
  return v10; /*0x102fefc51*/
}

// Address: 0x102fefc68 | Name: _crypto_sign_ed25519_verify_detached
__int64 __fastcall crypto_sign_ed25519_verify_detached(__int64 a1, __int64 a2, unsigned __int64 a3, __int64 a4)
{
  return _crypto_sign_ed25519_verify_detached(a1, a2, a3, a4, a5: 0); /*0x102fefc6f*/
}

// Address: 0x102fefc75 | Name: _crypto_sign_ed25519_open
__int64 __fastcall crypto_sign_ed25519_open(void *__dst, size_t *a2, __int64 a3, unsigned __int64 a4, __int64 a5)
{
  size_t v7; // rbx
  const void *v8; // r12
  unsigned int v9; // r13d

  if ( a4 < 0x40 ) /*0x102fefc8a*/
  {
LABEL_5:
    v9 = -1; /*0x102fefcc2*/
    if ( a2 != nullptr ) /*0x102fefccb*/
      *a2 = 0; /*0x102fefccd*/
    return v9; /*0x102fefccd*/
  }
  v7 = a4 - 64; /*0x102fefc92*/
  v8 = (const void *)(a3 + 64); /*0x102fefc96*/
  if ( (unsigned int)_crypto_sign_ed25519_verify_detached(a1: a3, a2: a3 + 64, a3: a4 - 64, a4: a5, a5: 0) != 0 ) /*0x102fefcb0*/
  {
    if ( __dst != nullptr ) /*0x102fefcb5*/
      __bzero(a1: (__int64)__dst, a2: v7); /*0x102fefcbd*/
    goto LABEL_5; /*0x102fefcbd*/
  }
  if ( a2 != nullptr ) /*0x102fefce9*/
    *a2 = v7; /*0x102fefceb*/
  v9 = 0; /*0x102fefcee*/
  if ( __dst != nullptr ) /*0x102fefcf4*/
    memmove(__dst, __src: v8, __len: v7); /*0x102fefcff*/
  return v9; /*0x102fefcdb*/
}

// Address: 0x102fefd06 | Name: __crypto_sign_ed25519_ref10_hinit
__int64 __fastcall _crypto_sign_ed25519_ref10_hinit(_OWORD *a1, int a2)
{
  __int64 result; // rax

  result = crypto_hash_sha512_init(a1); /*0x102fefd13*/
  if ( a2 != 0 ) /*0x102fefd1b*/
    return crypto_hash_sha512_update((__int64)a1, a2: (__int64)&_crypto_sign_ed25519_ref10_hinit_DOM2PREFIX, a3: 0x22u); /*0x102fefd30*/
  return result; /*0x102fefd2c*/
}

// Address: 0x102fefd3a | Name: __crypto_sign_ed25519_detached
__int64 __fastcall _crypto_sign_ed25519_detached(
        __int64 a1,
        _QWORD *a2,
        __int64 a3,
        unsigned __int64 a4,
        __int64 a5,
        int a6)
{
  __int128 v10; // xmm1
  _BYTE v12[160]; // [rsp+0h] [rbp-280h] BYREF
  _QWORD *v13; // [rsp+A0h] [rbp-1E0h]
  unsigned __int64 v14; // [rsp+A8h] [rbp-1D8h]
  __int64 v15; // [rsp+B0h] [rbp-1D0h]
  int v16; // [rsp+BCh] [rbp-1C4h]
  _BYTE v17[64]; // [rsp+C0h] [rbp-1C0h] BYREF
  _BYTE v18[64]; // [rsp+100h] [rbp-180h] BYREF
  _BYTE v19[31]; // [rsp+140h] [rbp-140h] BYREF
  char v20; // [rsp+15Fh] [rbp-121h]
  _BYTE v21[32]; // [rsp+160h] [rbp-120h] BYREF
  _OWORD v22[13]; // [rsp+180h] [rbp-100h] BYREF

  v16 = a6; /*0x102fefd4e*/
  v14 = a4; /*0x102fefd5b*/
  v15 = a3; /*0x102fefd65*/
  v13 = a2; /*0x102fefd6c*/
  _crypto_sign_ed25519_ref10_hinit(a1: v22, a2: a6); /*0x102fefd91*/
  crypto_hash_sha512(a1: (__int64)v19, a2: a5, a3: 0x20u); /*0x102fefda5*/
  crypto_hash_sha512_update(a1: (__int64)v22, a2: (__int64)v21, a3: 0x20u); /*0x102fefdb9*/
  crypto_hash_sha512_update(a1: (__int64)v22, a2: a3, a3: a4); /*0x102fefdc7*/
  crypto_hash_sha512_final(a1: (__int64)v22, a2: (__int64)v18); /*0x102fefdd9*/
  v10 = *(_OWORD *)(a5 + 48); /*0x102fefde7*/
  *(_OWORD *)(a1 + 32) = *(_OWORD *)(a5 + 32); /*0x102fefdec*/
  *(_OWORD *)(a1 + 48) = v10; /*0x102fefdf0*/
  _sodium_sc25519_reduce(a1: v18); /*0x102fefdf7*/
  _sodium_ge25519_scalarmult_base(a1: v12, a2: v18); /*0x102fefe09*/
  _sodium_ge25519_p3_tobytes(a1, a2: v12); /*0x102fefe14*/
  _crypto_sign_ed25519_ref10_hinit(a1: v22, a2: v16); /*0x102fefe22*/
  crypto_hash_sha512_update(a1: (__int64)v22, a2: a1, a3: 0x40u); /*0x102fefe32*/
  crypto_hash_sha512_update(a1: (__int64)v22, a2: v15, a3: v14); /*0x102fefe48*/
  crypto_hash_sha512_final(a1: (__int64)v22, a2: (__int64)v17); /*0x102fefe5a*/
  _sodium_sc25519_reduce(a1: v17); /*0x102fefe62*/
  v19[0] &= 0xF8u; /*0x102fefe6e*/
  v20 = v20 & 0x3F | 0x40; /*0x102fefe79*/
  _sodium_sc25519_muladd(a1: a1 + 32, a2: v17, a3: v19, a4: v18); /*0x102fefe8f*/
  sodium_memzero(a1: v19, a2: 64); /*0x102fefe9c*/
  sodium_memzero(a1: v18, a2: 64); /*0x102fefea9*/
  if ( v13 != nullptr ) /*0x102fefeb8*/
    *v13 = 64; /*0x102fefeba*/
  return 0; /*0x102fefed3*/
}

// Address: 0x102fefeea | Name: _crypto_sign_ed25519_detached
__int64 __fastcall crypto_sign_ed25519_detached(__int64 a1, _QWORD *a2, __int64 a3, unsigned __int64 a4, __int64 a5)
{
  _crypto_sign_ed25519_detached(a1, a2, a3, a4, a5, a6: 0); /*0x102fefef1*/
  return 0; /*0x102fefef8*/
}

// Address: 0x102fefefa | Name: _crypto_sign_ed25519
__int64 __fastcall crypto_sign_ed25519(__int64 a1, _QWORD *a2, const void *a3, size_t a4, __int64 a5)
{
  __int64 v8; // r14
  unsigned int v9; // r12d
  __int64 v11; // [rsp+8h] [rbp-38h] BYREF
  _QWORD *v12; // [rsp+10h] [rbp-30h]

  v12 = a2; /*0x102feff11*/
  v8 = a1 + 64; /*0x102feff18*/
  memmove(__dst: (void *)(a1 + 64), __src: a3, __len: a4); /*0x102feff25*/
  v9 = 0; /*0x102feff2e*/
  _crypto_sign_ed25519_detached(a1, a2: &v11, a3: v8, a4, a5, a6: 0); /*0x102feff40*/
  if ( v11 == 64 ) /*0x102feff4d*/
  {
    if ( v12 != nullptr ) /*0x102feff56*/
      *v12 = a4 + 64; /*0x102feff5c*/
  }
  else
  {
    if ( v12 != nullptr ) /*0x102feff68*/
      *v12 = 0; /*0x102feff6a*/
    __bzero(a1, a2: a4 + 64); /*0x102feff7b*/
    return (unsigned int)-1; /*0x102feff80*/
  }
  return v9; /*0x102feff89*/
}

// Address: 0x102feff98 | Name: _crypto_stream_chacha20_keybytes
__int64 crypto_stream_chacha20_keybytes()
{
  return 32; /*0x102feffa1*/
}

// Address: 0x102feffa3 | Name: _crypto_stream_chacha20_noncebytes
__int64 crypto_stream_chacha20_noncebytes()
{
  return 8; /*0x102feffac*/
}

// Address: 0x102feffae | Name: _crypto_stream_chacha20_messagebytes_max
__int64 crypto_stream_chacha20_messagebytes_max()
{
  return -1; /*0x102feffb9*/
}

// Address: 0x102feffbb | Name: _crypto_stream_chacha20_ietf_keybytes
__int64 crypto_stream_chacha20_ietf_keybytes()
{
  return 32; /*0x102feffc4*/
}

// Address: 0x102feffc6 | Name: _crypto_stream_chacha20_ietf_noncebytes
__int64 crypto_stream_chacha20_ietf_noncebytes()
{
  return 12; /*0x102feffcf*/
}

// Address: 0x102feffd1 | Name: _crypto_stream_chacha20_ietf_messagebytes_max
__int64 crypto_stream_chacha20_ietf_messagebytes_max()
{
  return 0x4000000000LL; /*0x102feffdf*/
}

// Address: 0x102feffe1 | Name: _crypto_stream_chacha20
__int64 crypto_stream_chacha20()
{
  return (*(__int64 (**)(void))implementation_2[0])();
}

// Address: 0x102fefff2 | Name: _crypto_stream_chacha20_xor_ic
__int64 crypto_stream_chacha20_xor_ic()
{
  return (*((__int64 (**)(void))implementation_2[0] + 2))();
}

// Address: 0x102ff0004 | Name: _crypto_stream_chacha20_xor
__int64 __fastcall crypto_stream_chacha20_xor(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5)
{
  return (*((__int64 (__fastcall **)(__int64, __int64, __int64, __int64, _QWORD, __int64))implementation_2[0] + 2))(
           a1,
           a2,
           a3,
           a4,
           a5: 0,
           a6: a5);
}

// Address: 0x102ff001c | Name: _crypto_stream_chacha20_ietf_ext
__int64 crypto_stream_chacha20_ietf_ext()
{
  return (*((__int64 (**)(void))implementation_2[0] + 1))();
}

// Address: 0x102ff002e | Name: _crypto_stream_chacha20_ietf_ext_xor_ic
__int64 crypto_stream_chacha20_ietf_ext_xor_ic()
{
  return (*((__int64 (**)(void))implementation_2[0] + 3))();
}

// Address: 0x102ff0040 | Name: _crypto_stream_chacha20_ietf
__int64 __fastcall crypto_stream_chacha20_ietf(__int64 a1, unsigned __int64 a2, __int64 a3, __int64 a4)
{
  if ( a2 >= 0x4000000001LL ) /*0x102ff004d*/
    sodium_misuse(a1, a2, a3, a4); /*0x102ff0060*/
  return (*((__int64 (**)(void))implementation_2[0] + 1))();
}

// Address: 0x102ff0065 | Name: _crypto_stream_chacha20_ietf_xor_ic
__int64 __fastcall crypto_stream_chacha20_ietf_xor_ic(__int64 a1, __int64 a2, __int64 a3, __int64 a4, unsigned int a5)
{
  if ( (unsigned __int64)&_mh_execute_header - ((unsigned __int64)(a3 + 63) >> 6) < a5 ) /*0x102ff0080*/
    sodium_misuse(a1, a2, a3, a4); /*0x102ff0093*/
  return (*((__int64 (**)(void))implementation_2[0] + 3))();
}

// Address: 0x102ff0098 | Name: _crypto_stream_chacha20_ietf_xor
__int64 __fastcall crypto_stream_chacha20_ietf_xor(__int64 a1, __int64 a2, unsigned __int64 a3, __int64 a4, __int64 a5)
{
  if ( a3 >= 0x4000000001LL ) /*0x102ff00a5*/
    sodium_misuse(a1, a2, a3, a4); /*0x102ff00be*/
  return (*((__int64 (__fastcall **)(__int64, __int64, unsigned __int64, __int64, _QWORD, __int64))implementation_2[0]
          + 3))(
           a1,
           a2,
           a3,
           a4,
           a5: 0,
           a6: a5);
}

// Address: 0x102ff00c3 | Name: _crypto_stream_chacha20_ietf_keygen
__int64 __fastcall crypto_stream_chacha20_ietf_keygen(__int64 a1)
{
  return randombytes_buf(a1, a2: 32); /*0x102ff00cc*/
}

// Address: 0x102ff00d2 | Name: _crypto_stream_chacha20_keygen
__int64 __fastcall crypto_stream_chacha20_keygen(__int64 a1)
{
  return randombytes_buf(a1, a2: 32); /*0x102ff00db*/
}

// Address: 0x102ff00e1 | Name: __crypto_stream_chacha20_pick_best_implementation
__int64 _crypto_stream_chacha20_pick_best_implementation()
{
  __int64 (__fastcall **v0)(); // rax

  implementation_2[0] = (__int64 (__fastcall *)())crypto_stream_chacha20_ref_implementation; /*0x102ff00ec*/
  if ( (unsigned int)sodium_runtime_has_avx2() != 0 ) /*0x102ff00fa*/
  {
    v0 = crypto_stream_chacha20_dolbeau_avx2_implementation; /*0x102ff00fc*/
LABEL_5:
    implementation_2[0] = (__int64 (__fastcall *)())v0; /*0x102ff0115*/
    return 0; /*0x102ff0115*/
  }
  if ( (unsigned int)sodium_runtime_has_ssse3() != 0 ) /*0x102ff010c*/
  {
    v0 = crypto_stream_chacha20_dolbeau_ssse3_implementation; /*0x102ff010e*/
    goto LABEL_5; /*0x102ff010e*/
  }
  return 0; /*0x102ff011e*/
}

// Address: 0x102ff02e3 | Name: _chacha20_encrypt_bytes
__int64 __fastcall chacha20_encrypt_bytes(__int64 a1, _QWORD *a2, _QWORD *a3, unsigned __int64 a4)
{
  int v4; // r9d
  __m128i v5; // xmm1
  __m128i v6; // xmm0
  int v7; // ebx
  unsigned int v8; // eax
  unsigned int v9; // r8d
  unsigned __int64 v10; // r10
  __m128i inserted; // xmm5
  __m128i v12; // xmm2
  __m128i v13; // xmm4
  __m128i v14; // xmm0
  _QWORD *v15; // r14
  __m128i si128; // xmm7
  __m128i v17; // xmm8
  __m128i v18; // xmm9
  __m128i v19; // xmm10
  unsigned __int64 v20; // kr00_8
  _QWORD *v21; // r15
  __int64 v22; // rbx
  __m128i v23; // xmm3
  int v24; // edx
  __m128i v25; // xmm12
  __m128i v26; // xmm13
  __m128i v27; // xmm6
  __m128i v28; // xmm1
  __m128i v29; // xmm15
  __m128i v30; // xmm14
  __m128i v31; // xmm3
  __m128i v32; // xmm3
  __m128i v33; // xmm13
  __m128i v34; // xmm15
  __m128i v35; // xmm14
  __m128i v36; // xmm12
  __m128i v37; // xmm12
  __m128i v38; // xmm13
  __m128i v39; // xmm15
  __m128i v40; // xmm14
  __m128i v41; // xmm12
  __m128i v42; // xmm12
  __m128i v43; // xmm12
  __m128i v44; // xmm14
  int v45; // r12d
  int v46; // r13d
  int v47; // ebx
  __m128i v48; // xmm14
  __m128i v49; // xmm1
  __m128i v50; // xmm3
  __m128i v51; // xmm6
  unsigned __int64 i; // rdx
  __m128i v54; // [rsp+0h] [rbp-B0h]
  __m128i v55; // [rsp+10h] [rbp-A0h]
  __m128i v56; // [rsp+20h] [rbp-90h] BYREF
  __int64 v57; // [rsp+38h] [rbp-78h]
  _QWORD v58[8]; // [rsp+40h] [rbp-70h] BYREF

  v4 = *(_DWORD *)a1; /*0x102ff0305*/
  v5 = _mm_loadu_si128((const __m128i *)(a1 + 4)); /*0x102ff0308*/
  v6 = _mm_loadl_epi64((const __m128i *)(a1 + 36)); /*0x102ff0312*/
  v7 = *(_DWORD *)(a1 + 44); /*0x102ff0317*/
  v8 = *(_DWORD *)(a1 + 48); /*0x102ff031a*/
  v9 = *(_DWORD *)(a1 + 52); /*0x102ff031d*/
  v57 = a1; /*0x102ff0321*/
  v10 = *(_QWORD *)(a1 + 56); /*0x102ff0325*/
  v56 = (__m128i)v10; /*0x102ff032e*/
  inserted = _mm_insert_epi32(_mm_shuffle_epi32(v5, 78), v4, 1); /*0x102ff033f*/
  v55 = _mm_loadu_si128((const __m128i *)(a1 + 20)); /*0x102ff034a*/
  v12 = _mm_insert_epi32(_mm_blend_epi16(v6, v55, 240), v7, 2); /*0x102ff0358*/
  v54 = v5; /*0x102ff035e*/
  v13 = _mm_alignr_epi8(v55, v5, 12); /*0x102ff0366*/
  v14 = _mm_insert_epi32(v6, v7, 2); /*0x102ff036f*/
  v15 = nullptr; /*0x102ff0379*/
  si128 = _mm_load_si128((const __m128i *)&xmmword_1094B9E20); /*0x102ff037c*/
  v17 = _mm_load_si128((const __m128i *)&xmmword_1094B9E30); /*0x102ff0384*/
  v18 = _mm_load_si128((const __m128i *)&xmmword_1094B9E40); /*0x102ff038d*/
  v19 = _mm_load_si128((const __m128i *)&xmmword_1094BA1B0); /*0x102ff0396*/
  v20 = __PAIR64__(v9, v8); /*0x102ff0396*/
  while ( 1 ) /*0x102ff03ab*/
  {
    if ( a4 <= 0x3F ) /*0x102ff03ab*/
    {
      memset(v58, 0, sizeof(v58)); /*0x102ff03c1*/
      if ( a4 != 0 ) /*0x102ff03c9*/
      {
        v22 = 0; /*0x102ff03cb*/
        do /*0x102ff03df*/
        {
          *((_BYTE *)v58 + v22) = *((_BYTE *)a2 + v22); /*0x102ff03d1*/
          ++v22; /*0x102ff03d6*/
        }
        while ( a4 > (unsigned int)v22 ); /*0x102ff03df*/
      }
      v21 = v58; /*0x102ff03e1*/
      a2 = v58; /*0x102ff03e4*/
      v15 = a3; /*0x102ff03e7*/
    }
    else
    {
      v21 = a3; /*0x102ff03ad*/
    }
    v23 = _mm_insert_epi32(_mm_insert_epi32(_mm_load_si128(&v56), v20, 2), SHIDWORD(v20), 3); /*0x102ff03f8*/
    v24 = -20; /*0x102ff03ff*/
    v25 = v13; /*0x102ff0404*/
    v26 = inserted; /*0x102ff0409*/
    v27 = v12; /*0x102ff040e*/
    do /*0x102ff051f*/
    {
      v28 = _mm_add_epi32(_mm_shuffle_epi32(v25, 147), v26); /*0x102ff0418*/
      v29 = _mm_xor_si128(_mm_shuffle_epi8(v28, v17), _mm_shuffle_epi8(v23, si128)); /*0x102ff042d*/
      v30 = _mm_add_epi32(_mm_shuffle_epi32(v29, 78), v27); /*0x102ff0438*/
      v31 = _mm_xor_si128(_mm_shuffle_epi32(v30, 147), v25); /*0x102ff0443*/
      v32 = _mm_or_si128(_mm_slli_epi32(v31, 0xCu), _mm_srli_epi32(v31, 0x14u)); /*0x102ff0456*/
      v33 = _mm_add_epi32(_mm_shuffle_epi32(v32, 147), v28); /*0x102ff0460*/
      v34 = _mm_xor_si128(_mm_shuffle_epi8(v29, v18), _mm_shuffle_epi8(v33, v18)); /*0x102ff0476*/
      v35 = _mm_add_epi32(v30, v34); /*0x102ff047b*/
      v36 = _mm_xor_si128(_mm_shuffle_epi32(v35, 147), v32); /*0x102ff0486*/
      v37 = _mm_or_si128(_mm_slli_epi32(v36, 7u), _mm_srli_epi32(v36, 0x19u)); /*0x102ff049b*/
      v38 = _mm_add_epi32(v33, v37); /*0x102ff04a0*/
      v39 = _mm_xor_si128(_mm_shuffle_epi8(v34, si128), _mm_shuffle_epi8(v38, v17)); /*0x102ff04b6*/
      v40 = _mm_add_epi32(v35, v39); /*0x102ff04bb*/
      v41 = _mm_xor_si128(v37, v40); /*0x102ff04c0*/
      v42 = _mm_or_si128(_mm_slli_epi32(v41, 0xCu), _mm_srli_epi32(v41, 0x14u)); /*0x102ff04d5*/
      v26 = _mm_add_epi32(v38, v42); /*0x102ff04da*/
      v23 = _mm_xor_si128(_mm_shuffle_epi8(v39, v19), _mm_shuffle_epi8(v26, v19)); /*0x102ff04f5*/
      v27 = _mm_add_epi32(v40, v23); /*0x102ff04fe*/
      v43 = _mm_xor_si128(v42, v27); /*0x102ff0502*/
      v25 = _mm_or_si128(_mm_slli_epi32(v43, 7u), _mm_srli_epi32(v43, 0x19u)); /*0x102ff0517*/
      v24 += 2; /*0x102ff051c*/
    }
    while ( v24 != 0 ); /*0x102ff051f*/
    v44 = _mm_insert_epi32(v14, v20, 3); /*0x102ff055d*/
    v45 = *((_DWORD *)a2 + 13) ^ (HIDWORD(v20) + _mm_extract_epi32(v23, 3)); /*0x102ff058f*/
    v46 = *((_DWORD *)a2 + 14) ^ (v10 + _mm_cvtsi128_si32(v23)); /*0x102ff0593*/
    v47 = *((_DWORD *)a2 + 15) ^ (HIDWORD(v10) + _mm_extract_epi32(v23, 1)); /*0x102ff0597*/
    ++v20; /*0x102ff05a3*/
    v48 = _mm_add_epi32(v44, _mm_blend_epi16(_mm_shuffle_epi32(v23, 170), v27, 63)); /*0x102ff05a7*/
    v49 = _mm_xor_si128( /*0x102ff05b1*/
            _mm_loadu_si128((const __m128i *)((char *)a2 + 4)),
            _mm_add_epi32(_mm_blend_epi16(_mm_shuffle_epi32(v26, 78), _mm_shuffle_epi32(v25, 0), 192), v54));
    v50 = _mm_xor_si128( /*0x102ff05bb*/
            _mm_loadu_si128((const __m128i *)((char *)a2 + 20)),
            _mm_add_epi32(_mm_blend_epi16(_mm_shuffle_epi32(v25, 249), v27, 192), v55));
    v51 = _mm_xor_si128(_mm_loadu_si128((const __m128i *)((char *)a2 + 36)), v48); /*0x102ff05c5*/
    *(_DWORD *)v21 = *(_DWORD *)a2 ^ (v4 + _mm_extract_epi32(v26, 1)); /*0x102ff05ca*/
    *(__m128i *)((char *)v21 + 4) = v49; /*0x102ff05cd*/
    *(__m128i *)((char *)v21 + 20) = v50; /*0x102ff05d3*/
    *(__m128i *)((char *)v21 + 36) = v51; /*0x102ff05d9*/
    *((_DWORD *)v21 + 13) = v45; /*0x102ff05df*/
    *((_DWORD *)v21 + 14) = v46; /*0x102ff05e3*/
    *((_DWORD *)v21 + 15) = v47; /*0x102ff05e7*/
    if ( a4 <= 0x40 ) /*0x102ff05f3*/
      break; /*0x102ff05f3*/
    a2 += 8; /*0x102ff05f9*/
    a4 -= 64LL; /*0x102ff05fd*/
    a3 = v21 + 8; /*0x102ff0600*/
  }
  if ( a4 - 64 >= 0xFFFFFFFFFFFFFFC1LL ) /*0x102ff060c*/
  {
    for ( i = 0; i < a4; ++i ) /*0x102ff060e*/
      *((_BYTE *)v15 + i) = *((_BYTE *)v21 + i); /*0x102ff0614*/
  }
  *(_QWORD *)(v57 + 48) = v20; /*0x102ff0624*/
  return __stack_chk_guard; /*0x102ff063b*/
}

// Address: 0x102ff0652 | Name: _crypto_stream_salsa20_keybytes
__int64 crypto_stream_salsa20_keybytes()
{
  return 32; /*0x102ff065b*/
}

// Address: 0x102ff065d | Name: _crypto_stream_salsa20_noncebytes
__int64 crypto_stream_salsa20_noncebytes()
{
  return 8; /*0x102ff0666*/
}

// Address: 0x102ff0668 | Name: _crypto_stream_salsa20_messagebytes_max
__int64 crypto_stream_salsa20_messagebytes_max()
{
  return -1; /*0x102ff0673*/
}

// Address: 0x102ff0675 | Name: _crypto_stream_salsa20
__int64 crypto_stream_salsa20()
{
  return ((__int64 (*)(void))*implementation_3)();
}

// Address: 0x102ff0686 | Name: _crypto_stream_salsa20_xor_ic
__int64 crypto_stream_salsa20_xor_ic()
{
  return ((__int64 (*)(void))implementation_3[1])();
}

// Address: 0x102ff0698 | Name: _crypto_stream_salsa20_xor
__int64 __fastcall crypto_stream_salsa20_xor(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5)
{
  return ((__int64 (__fastcall *)(__int64, __int64, __int64, __int64, _QWORD, __int64))implementation_3[1])(
           a1,
           a2,
           a3,
           a4,
           a5: 0,
           a6: a5);
}

// Address: 0x102ff06b0 | Name: _crypto_stream_salsa20_keygen
__int64 __fastcall crypto_stream_salsa20_keygen(__int64 a1)
{
  return randombytes_buf(a1, a2: 32); /*0x102ff06b9*/
}

// Address: 0x102ff06bf | Name: __crypto_stream_salsa20_pick_best_implementation
__int64 _crypto_stream_salsa20_pick_best_implementation()
{
  implementation_3 = crypto_stream_salsa20_xmm6_implementation; /*0x102ff06ca*/
  if ( (unsigned int)sodium_runtime_has_avx2() != 0 ) /*0x102ff06d8*/
    implementation_3 = (__int64 (__fastcall **)(int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, int, __int64, __int64, __int64, __int64, __int64, __int64, __int64, __int64))crypto_stream_salsa20_xmm6int_avx2_implementation; /*0x102ff06e1*/
  return 0; /*0x102ff06ea*/
}

// Address: 0x102ff06ec | Name: _crypto_verify_16_bytes
__int64 crypto_verify_16_bytes()
{
  return 16; /*0x102ff06f5*/
}

// Address: 0x102ff06f7 | Name: _crypto_verify_32_bytes
__int64 crypto_verify_32_bytes()
{
  return 32; /*0x102ff0700*/
}

// Address: 0x102ff0702 | Name: _crypto_verify_64_bytes
__int64 crypto_verify_64_bytes()
{
  return 64; /*0x102ff070b*/
}

// Address: 0x102ff070d | Name: _crypto_verify_16
__int64 __fastcall crypto_verify_16(__m128i *a1, __m128i *a2)
{
  __m128i v3; // [rsp+0h] [rbp-50h] BYREF
  __m128i v4; // [rsp+10h] [rbp-40h]
  __m128i v5; // [rsp+20h] [rbp-30h] BYREF
  __m128i *v6; // [rsp+38h] [rbp-18h]
  __m128i *v7; // [rsp+40h] [rbp-10h]

  v6 = a1; /*0x102ff0711*/
  v7 = a2; /*0x102ff0715*/
  v3 = *a1; /*0x102ff0720*/
  v4 = *a2; /*0x102ff072b*/
  v5 = _mm_xor_si128(_mm_load_si128(&v3), v4); /*0x102ff0739*/
  return ((unsigned int)(_mm_movemask_epi8(_mm_cmpeq_epi32(_mm_load_si128(&v5), (__m128i)0LL)) + 1) >> 16) - 1; /*0x102ff076b*/
}

// Address: 0x102ff076d | Name: _crypto_verify_32
__int64 __fastcall crypto_verify_32(__m128i *a1, __m128i *a2)
{
  __m128 v3; // [rsp+0h] [rbp-50h] BYREF
  __m128 v4; // [rsp+10h] [rbp-40h]
  __m128 v5; // [rsp+20h] [rbp-30h] BYREF
  __m128i *v6; // [rsp+38h] [rbp-18h]
  __m128i *v7; // [rsp+40h] [rbp-10h]

  v6 = a1; /*0x102ff0771*/
  v7 = a2; /*0x102ff0775*/
  v3 = *(__m128 *)a1; /*0x102ff0780*/
  v4 = *(__m128 *)a2; /*0x102ff078b*/
  v5 = _mm_xor_ps(v3, v4); /*0x102ff0797*/
  v3 = (__m128)a1[1]; /*0x102ff07a3*/
  v4 = (__m128)a2[1]; /*0x102ff07af*/
  v5 = (__m128)_mm_or_si128( /*0x102ff07c6*/
                 _mm_xor_si128(_mm_load_si128((const __m128i *)&v3), (__m128i)v4),
                 _mm_load_si128((const __m128i *)&v5));
  return ((unsigned int)(_mm_movemask_epi8(_mm_cmpeq_epi32(_mm_load_si128((const __m128i *)&v5), (__m128i)0LL)) + 1) >> 16) /*0x102ff07f8*/
       - 1;
}

// Address: 0x102ff07fa | Name: _crypto_verify_64
__int64 __fastcall crypto_verify_64(__m128i *a1, __m128i *a2)
{
  __int64 i; // rax
  __m128i v4; // [rsp+0h] [rbp-50h] BYREF
  __m128i v5; // [rsp+10h] [rbp-40h]
  __m128i v6; // [rsp+20h] [rbp-30h] BYREF
  __m128i *v7; // [rsp+38h] [rbp-18h]
  __m128i *v8; // [rsp+40h] [rbp-10h]

  v7 = a1; /*0x102ff07fe*/
  v8 = a2; /*0x102ff0802*/
  v4 = *a1; /*0x102ff080d*/
  v5 = *a2; /*0x102ff0818*/
  v6 = _mm_xor_si128(_mm_load_si128(&v4), v5); /*0x102ff0826*/
  for ( i = 1; i != 4; ++i ) /*0x102ff082b*/
  {
    v4 = v7[i]; /*0x102ff0838*/
    v5 = v8[i]; /*0x102ff0844*/
    v6 = _mm_or_si128(_mm_xor_si128(_mm_load_si128(&v4), v5), _mm_load_si128(&v6)); /*0x102ff085b*/
  }
  return ((unsigned int)(_mm_movemask_epi8(_mm_cmpeq_epi32(_mm_load_si128(&v6), (__m128i)0LL)) + 1) >> 16) - 1; /*0x102ff0897*/
}

// Address: 0x102ff16c8 | Name: _crypto_scalarmult_curve25519_sandy2x
__int64 __fastcall crypto_scalarmult_curve25519_sandy2x(int a1, __int128 *a2, __int64 a3)
{
  __int128 v4; // xmm1
  int v5; // ecx
  int v6; // r8d
  int v7; // r9d
  int v8; // edx
  int v9; // ecx
  int v10; // r8d
  int v11; // r9d
  __int64 v13; // [rsp+0h] [rbp-190h] BYREF
  __int64 v14; // [rsp+8h] [rbp-188h]
  __int64 v15; // [rsp+10h] [rbp-180h]
  __int64 v16; // [rsp+18h] [rbp-178h]
  __int64 v17; // [rsp+20h] [rbp-170h]
  __int64 v18; // [rsp+28h] [rbp-168h] BYREF
  __int64 v19; // [rsp+30h] [rbp-160h]
  __int64 v20; // [rsp+38h] [rbp-158h]
  __int64 v21; // [rsp+40h] [rbp-150h]
  __int64 v22; // [rsp+48h] [rbp-148h]
  _QWORD v23[30]; // [rsp+50h] [rbp-140h] BYREF
  __int128 v24; // [rsp+140h] [rbp-50h] BYREF
  __int128 v25; // [rsp+150h] [rbp-40h]

  v4 = a2[1]; /*0x102ff16f0*/
  v24 = *a2; /*0x102ff16f8*/
  v25 = v4; /*0x102ff16fb*/
  LOBYTE(v24) = v24 & 0xF8; /*0x102ff16ff*/
  HIBYTE(v25) = HIBYTE(v4) & 0x3F | 0x40; /*0x102ff1709*/
  _sodium_scalarmult_curve25519_sandy2x_fe_frombytes(a1: v23, a2: a3); /*0x102ff1719*/
  _sodium_scalarmult_curve25519_sandy2x_ladder(a1: v23, a2: &v24); /*0x102ff1724*/
  v18 = v23[20] + (v23[21] << 26); /*0x102ff1746*/
  v19 = v23[22] + (v23[23] << 26); /*0x102ff175c*/
  v20 = v23[24] + (v23[25] << 26); /*0x102ff1785*/
  v21 = v23[26] + (v23[27] << 26); /*0x102ff178a*/
  v22 = v23[28] + (v23[29] << 26); /*0x102ff17a1*/
  v13 = v23[10] + (v23[11] << 26); /*0x102ff17b5*/
  v14 = v23[12] + (v23[13] << 26); /*0x102ff17d1*/
  v15 = v23[14] + (v23[15] << 26); /*0x102ff17d5*/
  v16 = v23[16] + (v23[17] << 26); /*0x102ff17eb*/
  v17 = v23[18] + (v23[19] << 26); /*0x102ff1801*/
  _sodium_scalarmult_curve25519_sandy2x_fe51_invert(a1: &v18, a2: &v18); /*0x102ff180b*/
  _sodium_scalarmult_curve25519_sandy2x_fe51_mul( /*0x102ff1819*/
    a1: (unsigned int)&v13,
    a2: (unsigned int)&v13,
    a3: (unsigned int)&v18,
    a4: v5,
    a5: v6,
    a6: v7,
    a7: v13,
    a8: v14,
    a9: v15,
    a10: v16,
    a11: v17,
    a12: v18,
    a13: v19,
    a14: v20,
    a15: v21);
  _sodium_scalarmult_curve25519_sandy2x_fe51_pack(a1, a2: (unsigned int)&v13, a3: v8, a4: v9, a5: v10, a6: v11, a7: v13); /*0x102ff1824*/
  sodium_memzero(a1: &v24, a2: 32); /*0x102ff1831*/
  return 0; /*0x102ff1848*/
}

// Address: 0x102ffda3a | Name: _chacha20_encrypt_bytes_0
__int64 __fastcall chacha20_encrypt_bytes_0(const __m128i *a1, const __m128i *a2, __m128i *a3, unsigned __int64 a4)
{
  __m128i v4; // xmm2
  __m128i v5; // xmm3
  __m128i v6; // xmm4
  __m128i v7; // xmm5
  __m128i v8; // xmm7
  __m128i v9; // xmm8
  __m128i v10; // xmm6
  __m128i v11; // xmm9
  __m128i v12; // xmm10
  __m128i v13; // xmm11
  __m128i v14; // xmm13
  __m128i v15; // xmm12
  __int64 v16; // r8
  __m128i v17; // xmm0
  __m128i v18; // xmm1
  __m128i v19; // xmm0
  __m128i v20; // xmm14
  __m128i v21; // xmm1
  __m128i v22; // xmm15
  __m128i v23; // xmm14
  unsigned int v24; // r8d
  __m128i v25; // xmm12
  __m128i v26; // xmm0
  __m128i v27; // xmm6
  __m128i v28; // xmm1
  __m128i v29; // xmm8
  __m128i v30; // xmm0
  __m128i v31; // xmm2
  __m128i v32; // xmm8
  __m128i v33; // xmm6
  __m128i v34; // xmm6
  __m128i v35; // xmm2
  __m128i si128; // xmm15
  __m128i v37; // xmm8
  __m128i v38; // xmm6
  __m128i v39; // xmm6
  __m128i v40; // xmm3
  __m128i v41; // xmm14
  __m128i v42; // xmm9
  __m128i v43; // xmm5
  __m128i v44; // xmm5
  __m128i v45; // xmm3
  __m128i v46; // xmm14
  __m128i v47; // xmm9
  __m128i v48; // xmm5
  __m128i v49; // xmm5
  __m128i v50; // xmm4
  __m128i v51; // xmm0
  __m128i v52; // xmm10
  __m128i v53; // xmm7
  __m128i v54; // xmm7
  __m128i v55; // xmm4
  __m128i v56; // xmm10
  __m128i v57; // xmm7
  __m128i v58; // xmm7
  __m128i v59; // xmm12
  __m128i v60; // xmm13
  __m128i v61; // xmm11
  __m128i v62; // xmm1
  __m128i v63; // xmm1
  __m128i v64; // xmm12
  __m128i v65; // xmm13
  __m128i v66; // xmm11
  __m128i v67; // xmm1
  __m128i v68; // xmm1
  __m128i v69; // xmm2
  __m128i v70; // xmm13
  __m128i v71; // xmm10
  __m128i v72; // xmm5
  __m128i v73; // xmm5
  __m128i v74; // xmm5
  __m128i v75; // xmm3
  __m128i v76; // xmm15
  __m128i v77; // xmm11
  __m128i v78; // xmm7
  __m128i v79; // xmm7
  __m128i v80; // xmm13
  __m128i v81; // xmm7
  __m128i v82; // xmm4
  __m128i v83; // xmm14
  __m128i v84; // xmm8
  __m128i v85; // xmm1
  __m128i v86; // xmm1
  __m128i v87; // xmm1
  __m128i v88; // xmm12
  __m128i v89; // xmm0
  __m128i v90; // xmm9
  __m128i v91; // xmm6
  __m128i v92; // xmm6
  __m128i v93; // xmm6
  __m128i v94; // xmm2
  __m128i v95; // xmm3
  __m128i v96; // xmm13
  __m128i v97; // xmm2
  __m128i v98; // xmm4
  __m128i v99; // xmm12
  __m128i v100; // xmm3
  __m128i v101; // xmm4
  __m128i v102; // xmm6
  __m128i v103; // xmm3
  __m128i v104; // xmm5
  __m128i v105; // xmm4
  __m128i v106; // xmm7
  __m128i v107; // xmm12
  __m128i v108; // xmm1
  __m128i v109; // xmm2
  __m128i v110; // xmm6
  __m128i v111; // xmm3
  __m128i v112; // xmm7
  __m128i v113; // xmm1
  __m128i v114; // xmm2
  __m128i v115; // xmm3
  __m128i v116; // xmm6
  __m128i v117; // xmm8
  __m128i v118; // xmm2
  __m128i v119; // xmm9
  __m128i v120; // xmm4
  __m128i v121; // xmm10
  __m128i v122; // xmm3
  __m128i v123; // xmm11
  __m128i v124; // xmm1
  __m128i v125; // xmm8
  __m128i v126; // xmm2
  __m128i v127; // xmm10
  __m128i v128; // xmm3
  __m128i v129; // xmm1
  __m128i v130; // xmm2
  __m128i v131; // xmm8
  __m128i v132; // xmm1
  __m128i v133; // xmm1
  __m128i v134; // xmm2
  __m128i v135; // xmm0
  __m128i v136; // xmm3
  __m128i v137; // xmm14
  __m128i v138; // xmm1
  __m128i v139; // xmm2
  __m128i v140; // xmm0
  __m128i v141; // xmm3
  __m128i v142; // xmm14
  __m128i v143; // xmm2
  __m128i v144; // xmm1
  __m128i v145; // xmm0
  __m128i v146; // xmm0
  __m128i v147; // xmm0
  __m128i v148; // xmm1
  __m128i v149; // xmm6
  __m128i v150; // xmm5
  __m128i v151; // xmm4
  __m128i v152; // xmm3
  unsigned int v153; // eax
  __m128i v154; // xmm9
  __m128i v155; // xmm7
  __m128i v156; // xmm2
  __m128i v157; // xmm8
  __m128i v158; // xmm8
  __m128i v159; // xmm9
  __m128i v160; // xmm7
  __m128i v161; // xmm2
  __m128i v162; // xmm2
  __m128i v163; // xmm8
  __m128i v164; // xmm9
  __m128i v165; // xmm7
  __m128i v166; // xmm2
  __m128i v167; // xmm2
  __m128i v168; // xmm10
  __m128i v169; // xmm9
  __m128i v170; // xmm7
  __m128i v171; // xmm2
  __m128i v172; // xmm2
  __m128i v173; // xmm10
  __m128i v174; // xmm10
  __m128i v175; // xmm7
  __m128i v176; // xmm2
  __m128i v177; // xmm7
  __m128i v178; // xmm4
  __m128i v179; // xmm2
  __m128i v180; // xmm5
  __m128i v181; // xmm3
  __m128i v182; // xmm2
  __m128i v183; // xmm1
  __m128i v184; // xmm0
  unsigned int v185; // eax
  __m128i v186; // xmm5
  __m128i v187; // xmm6
  __m128i v188; // xmm9
  __m128i v189; // xmm8
  __m128i v190; // xmm4
  __m128i v191; // xmm7
  __m128i v192; // xmm7
  __m128i v193; // xmm9
  __m128i v194; // xmm8
  __m128i v195; // xmm4
  __m128i v196; // xmm4
  __m128i v197; // xmm7
  __m128i v198; // xmm9
  __m128i v199; // xmm8
  __m128i v200; // xmm4
  __m128i v201; // xmm4
  __m128i v202; // xmm10
  __m128i v203; // xmm9
  __m128i v204; // xmm8
  __m128i v205; // xmm4
  __m128i v206; // xmm4
  __m128i v207; // xmm10
  __m128i v208; // xmm10
  __m128i v209; // xmm8
  __m128i v210; // xmm4
  __int64 i; // rax
  __m128i v213; // [rsp+0h] [rbp-180h] BYREF
  __m128i v214; // [rsp+10h] [rbp-170h] BYREF
  __m128i v215; // [rsp+20h] [rbp-160h] BYREF
  __m128i v216; // [rsp+30h] [rbp-150h] BYREF
  __m128i v217; // [rsp+40h] [rbp-140h] BYREF
  __m128i v218; // [rsp+50h] [rbp-130h] BYREF
  __m128i v219; // [rsp+60h] [rbp-120h] BYREF
  __m128i v220; // [rsp+70h] [rbp-110h] BYREF
  __m128i v221; // [rsp+80h] [rbp-100h] BYREF
  __m128i v222; // [rsp+90h] [rbp-F0h] BYREF
  __m128i v223; // [rsp+A0h] [rbp-E0h] BYREF
  __m128i v224; // [rsp+B0h] [rbp-D0h] BYREF
  __m128i v225; // [rsp+C0h] [rbp-C0h] BYREF
  __m128i v226; // [rsp+D0h] [rbp-B0h] BYREF
  __m128i v227; // [rsp+E0h] [rbp-A0h] BYREF
  __m128i v228; // [rsp+F0h] [rbp-90h] BYREF
  __m128i v229; // [rsp+100h] [rbp-80h] BYREF
  __m128i v230; // [rsp+110h] [rbp-70h] BYREF
  __m128i v231; // [rsp+120h] [rbp-60h] BYREF
  _QWORD v232[8]; // [rsp+130h] [rbp-50h] BYREF

  if ( a4 >= 0x100 ) /*0x102ffda5a*/
  {
    v4 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1->i32[0]), 0); /*0x102ffda64*/
    v5 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1->u32[1]), 0); /*0x102ffda6e*/
    v6 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1->u32[2]), 0); /*0x102ffda78*/
    v226 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1->u32[3]), 0); /*0x102ffda87*/
    v227 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1[1].u32[0]), 0); /*0x102ffda99*/
    v7 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1[1].u32[1]), 0); /*0x102ffdaa6*/
    v8 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1[1].u32[2]), 0); /*0x102ffdab0*/
    v9 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1[1].u32[3]), 0); /*0x102ffdaba*/
    v10 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1[2].u32[0]), 0); /*0x102ffdac5*/
    v11 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1[2].u32[1]), 0); /*0x102ffdacf*/
    v12 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1[2].u32[2]), 0); /*0x102ffdada*/
    v13 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1[2].u32[3]), 0); /*0x102ffdae5*/
    v14 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1[3].u32[2]), 0); /*0x102ffdaf0*/
    v15 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a1[3].u32[3]), 0); /*0x102ffdafb*/
    v223 = v4; /*0x102ffdb06*/
    v224 = v5; /*0x102ffdb0e*/
    v225 = v6; /*0x102ffdb16*/
    v215 = v7; /*0x102ffdb1e*/
    v216 = v8; /*0x102ffdb26*/
    v217 = v9; /*0x102ffdb2e*/
    v218 = v10; /*0x102ffdb37*/
    v219 = v11; /*0x102ffdb3f*/
    v220 = v12; /*0x102ffdb48*/
    v221 = v13; /*0x102ffdb51*/
    v222 = v14; /*0x102ffdb5a*/
    v228 = v15; /*0x102ffdb63*/
    do /*0x102ffe29b*/
    {
      v16 = a1[3].i64[0]; /*0x102ffdb6c*/
      v17 = _mm_shuffle_epi32((__m128i)(unsigned __int64)v16, 68); /*0x102ffdb75*/
      v18 = _mm_add_epi64(v17, (__m128i)xmmword_108F246B0); /*0x102ffdb7e*/
      v19 = _mm_add_epi64(v17, xmmword_108F4EAB0); /*0x102ffdb86*/
      v20 = _mm_unpacklo_epi32(v18, v19); /*0x102ffdb93*/
      v21 = _mm_unpackhi_epi32(v18, v19); /*0x102ffdb98*/
      v22 = _mm_unpacklo_epi32(v20, v21); /*0x102ffdba1*/
      v23 = _mm_unpackhi_epi32(v20, v21); /*0x102ffdba6*/
      a1[3].i64[0] = v16 + 4; /*0x102ffdbaf*/
      v24 = -2; /*0x102ffdbb3*/
      v25 = _mm_load_si128(&v226); /*0x102ffdbb9*/
      v26 = v10; /*0x102ffdbc2*/
      v27 = _mm_load_si128(&v227); /*0x102ffdbc6*/
      v28 = v9; /*0x102ffdbce*/
      v29 = v26; /*0x102ffdbd3*/
      v213 = v22; /*0x102ffdbd8*/
      v214 = v23; /*0x102ffdbe1*/
      v30 = v14; /*0x102ffdbea*/
      v230 = v228; /*0x102ffdbf7*/
      do /*0x102ffdfa9*/
      {
        v231 = v12; /*0x102ffdbfc*/
        v31 = _mm_add_epi32(v4, v27); /*0x102ffdc02*/
        v229 = _mm_shufflehi_epi16(_mm_shufflelo_epi16(_mm_xor_si128(v22, v31), 177), 177); /*0x102ffdc17*/
        v32 = _mm_add_epi32(v29, v229); /*0x102ffdc1d*/
        v33 = _mm_xor_si128(v27, v32); /*0x102ffdc22*/
        v34 = _mm_or_si128(_mm_slli_epi32(v33, 0xCu), _mm_srli_epi32(v33, 0x14u)); /*0x102ffdc37*/
        v35 = _mm_add_epi32(v31, v34); /*0x102ffdc3c*/
        si128 = _mm_load_si128((const __m128i *)&xmmword_1094BA1B0); /*0x102ffdc45*/
        v229 = _mm_xor_si128(_mm_shuffle_epi8(_mm_load_si128(&v229), si128), _mm_shuffle_epi8(v35, si128)); /*0x102ffdc6a*/
        v37 = _mm_add_epi32(v32, v229); /*0x102ffdc75*/
        v38 = _mm_xor_si128(v34, v37); /*0x102ffdc80*/
        v39 = _mm_or_si128(_mm_slli_epi32(v38, 7u), _mm_srli_epi32(v38, 0x19u)); /*0x102ffdc95*/
        v40 = _mm_add_epi32(v5, v7); /*0x102ffdc9a*/
        v41 = _mm_shufflehi_epi16(_mm_shufflelo_epi16(_mm_xor_si128(v23, v40), 177), 177); /*0x102ffdca9*/
        v42 = _mm_add_epi32(v11, v41); /*0x102ffdcaf*/
        v43 = _mm_xor_si128(v7, v42); /*0x102ffdcb4*/
        v44 = _mm_or_si128(_mm_slli_epi32(v43, 0xCu), _mm_srli_epi32(v43, 0x14u)); /*0x102ffdcc9*/
        v45 = _mm_add_epi32(v40, v44); /*0x102ffdcce*/
        v46 = _mm_xor_si128(_mm_shuffle_epi8(v41, si128), _mm_shuffle_epi8(v45, si128)); /*0x102ffdce3*/
        v47 = _mm_add_epi32(v42, v46); /*0x102ffdce8*/
        v48 = _mm_xor_si128(v44, v47); /*0x102ffdced*/
        v49 = _mm_or_si128(_mm_slli_epi32(v48, 7u), _mm_srli_epi32(v48, 0x19u)); /*0x102ffdd02*/
        v50 = _mm_add_epi32(v6, v8); /*0x102ffdd07*/
        v51 = _mm_shufflehi_epi16(_mm_shufflelo_epi16(_mm_xor_si128(v30, v50), 177), 177); /*0x102ffdd14*/
        v52 = _mm_add_epi32(_mm_load_si128(&v231), v51); /*0x102ffdd19*/
        v53 = _mm_xor_si128(v8, v52); /*0x102ffdd1e*/
        v54 = _mm_or_si128(_mm_slli_epi32(v53, 0xCu), _mm_srli_epi32(v53, 0x14u)); /*0x102ffdd33*/
        v55 = _mm_add_epi32(v50, v54); /*0x102ffdd38*/
        v231 = _mm_xor_si128(_mm_shuffle_epi8(v51, si128), _mm_shuffle_epi8(v55, si128)); /*0x102ffdd52*/
        v56 = _mm_add_epi32(v52, v231); /*0x102ffdd57*/
        v57 = _mm_xor_si128(v54, v56); /*0x102ffdd5c*/
        v58 = _mm_or_si128(_mm_slli_epi32(v57, 7u), _mm_srli_epi32(v57, 0x19u)); /*0x102ffdd71*/
        v59 = _mm_add_epi32(v25, v28); /*0x102ffdd76*/
        v60 = _mm_shufflehi_epi16(_mm_shufflelo_epi16(_mm_xor_si128(_mm_load_si128(&v230), v59), 177), 177); /*0x102ffdd8b*/
        v61 = _mm_add_epi32(v13, v60); /*0x102ffdd91*/
        v62 = _mm_xor_si128(v28, v61); /*0x102ffdd96*/
        v63 = _mm_or_si128(_mm_slli_epi32(v62, 0xCu), _mm_srli_epi32(v62, 0x14u)); /*0x102ffdda9*/
        v64 = _mm_add_epi32(v59, v63); /*0x102ffddad*/
        v65 = _mm_xor_si128(_mm_shuffle_epi8(v60, si128), _mm_shuffle_epi8(v64, si128)); /*0x102ffddc3*/
        v66 = _mm_add_epi32(v61, v65); /*0x102ffddc8*/
        v67 = _mm_xor_si128(v63, v66); /*0x102ffddcd*/
        v68 = _mm_or_si128(_mm_slli_epi32(v67, 7u), _mm_srli_epi32(v67, 0x19u)); /*0x102ffdde0*/
        v69 = _mm_add_epi32(v35, v49); /*0x102ffdde4*/
        v70 = _mm_shufflehi_epi16(_mm_shufflelo_epi16(_mm_xor_si128(v65, v69), 177), 177); /*0x102ffddf3*/
        v71 = _mm_add_epi32(v56, v70); /*0x102ffddf9*/
        v72 = _mm_xor_si128(v49, v71); /*0x102ffddfe*/
        v73 = _mm_or_si128(_mm_slli_epi32(v72, 0xCu), _mm_srli_epi32(v72, 0x14u)); /*0x102ffde11*/
        v4 = _mm_add_epi32(v69, v73); /*0x102ffde15*/
        v230 = _mm_xor_si128(_mm_shuffle_epi8(v70, si128), _mm_shuffle_epi8(v4, si128)); /*0x102ffde2e*/
        v12 = _mm_add_epi32(v71, v230); /*0x102ffde34*/
        v74 = _mm_xor_si128(v73, v12); /*0x102ffde39*/
        v7 = _mm_or_si128(_mm_slli_epi32(v74, 7u), _mm_srli_epi32(v74, 0x19u)); /*0x102ffde4c*/
        v75 = _mm_add_epi32(v45, v58); /*0x102ffde50*/
        v76 = _mm_shufflehi_epi16(_mm_shufflelo_epi16(_mm_xor_si128(_mm_load_si128(&v229), v75), 177), 177); /*0x102ffde62*/
        v77 = _mm_add_epi32(v66, v76); /*0x102ffde68*/
        v78 = _mm_xor_si128(v58, v77); /*0x102ffde6d*/
        v79 = _mm_or_si128(_mm_slli_epi32(v78, 0xCu), _mm_srli_epi32(v78, 0x14u)); /*0x102ffde80*/
        v5 = _mm_add_epi32(v75, v79); /*0x102ffde84*/
        v80 = _mm_load_si128((const __m128i *)&xmmword_1094BA1B0); /*0x102ffde8c*/
        v22 = _mm_xor_si128(_mm_shuffle_epi8(v76, v80), _mm_shuffle_epi8(v5, v80)); /*0x102ffdea1*/
        v13 = _mm_add_epi32(v77, v22); /*0x102ffdea6*/
        v81 = _mm_xor_si128(v79, v13); /*0x102ffdeab*/
        v8 = _mm_or_si128(_mm_slli_epi32(v81, 7u), _mm_srli_epi32(v81, 0x19u)); /*0x102ffdebe*/
        v82 = _mm_add_epi32(v55, v68); /*0x102ffdec2*/
        v83 = _mm_shufflehi_epi16(_mm_shufflelo_epi16(_mm_xor_si128(v46, v82), 177), 177); /*0x102ffded1*/
        v84 = _mm_add_epi32(v37, v83); /*0x102ffded7*/
        v85 = _mm_xor_si128(v68, v84); /*0x102ffdedc*/
        v86 = _mm_or_si128(_mm_slli_epi32(v85, 0xCu), _mm_srli_epi32(v85, 0x14u)); /*0x102ffdeef*/
        v6 = _mm_add_epi32(v82, v86); /*0x102ffdef3*/
        v23 = _mm_xor_si128(_mm_shuffle_epi8(v83, v80), _mm_shuffle_epi8(v6, v80)); /*0x102ffdf07*/
        v29 = _mm_add_epi32(v84, v23); /*0x102ffdf0c*/
        v87 = _mm_xor_si128(v86, v29); /*0x102ffdf11*/
        v28 = _mm_or_si128(_mm_slli_epi32(v87, 7u), _mm_srli_epi32(v87, 0x19u)); /*0x102ffdf24*/
        v88 = _mm_add_epi32(v64, v39); /*0x102ffdf28*/
        v89 = _mm_shufflehi_epi16(_mm_shufflelo_epi16(_mm_xor_si128(_mm_load_si128(&v231), v88), 177), 177); /*0x102ffdf3c*/
        v90 = _mm_add_epi32(v47, v89); /*0x102ffdf41*/
        v91 = _mm_xor_si128(v39, v90); /*0x102ffdf46*/
        v92 = _mm_or_si128(_mm_slli_epi32(v91, 0xCu), _mm_srli_epi32(v91, 0x14u)); /*0x102ffdf5b*/
        v25 = _mm_add_epi32(v88, v92); /*0x102ffdf60*/
        v30 = _mm_xor_si128( /*0x102ffdf7d*/
                _mm_shuffle_epi8(v89, (__m128i)xmmword_1094BA1B0),
                _mm_shuffle_epi8(v25, (__m128i)xmmword_1094BA1B0));
        v11 = _mm_add_epi32(v90, v30); /*0x102ffdf82*/
        v93 = _mm_xor_si128(v92, v11); /*0x102ffdf87*/
        v27 = _mm_or_si128(_mm_slli_epi32(v93, 7u), _mm_srli_epi32(v93, 0x19u)); /*0x102ffdf9c*/
        v24 += 2; /*0x102ffdfa1*/
      }
      while ( v24 < 0x12 ); /*0x102ffdfa9*/
      v94 = _mm_add_epi32(v4, v223); /*0x102ffdfaf*/
      v95 = _mm_add_epi32(v5, v224); /*0x102ffdfb7*/
      v96 = _mm_unpacklo_epi32(v94, v95); /*0x102ffdfc4*/
      v97 = _mm_unpackhi_epi32(v94, v95); /*0x102ffdfc9*/
      v98 = _mm_add_epi32(v6, v225); /*0x102ffdfcd*/
      v99 = _mm_add_epi32(v25, v226); /*0x102ffdfd5*/
      v100 = _mm_unpacklo_epi32(v98, v99); /*0x102ffdfe2*/
      v101 = _mm_unpackhi_epi32(v98, v99); /*0x102ffdfe7*/
      *a3 = _mm_xor_si128(_mm_loadu_si128(a2), _mm_unpacklo_epi64(v96, v100)); /*0x102ffe010*/
      a3[4] = _mm_xor_si128(_mm_loadu_si128(a2 + 4), _mm_unpackhi_epi64(v96, v100)); /*0x102ffe01e*/
      a3[8] = _mm_xor_si128(_mm_loadu_si128(a2 + 8), _mm_unpacklo_epi64(v97, v101)); /*0x102ffe02f*/
      a3[12] = _mm_xor_si128(_mm_loadu_si128(a2 + 12), _mm_unpackhi_epi64(v97, v101)); /*0x102ffe043*/
      v102 = _mm_add_epi32(v27, v227); /*0x102ffe04b*/
      v103 = _mm_load_si128(&v215); /*0x102ffe053*/
      v104 = _mm_add_epi32(v7, v103); /*0x102ffe05b*/
      v105 = _mm_load_si128(&v216); /*0x102ffe05f*/
      v106 = _mm_add_epi32(v8, v105); /*0x102ffe067*/
      v107 = _mm_load_si128(&v217); /*0x102ffe06b*/
      v108 = _mm_add_epi32(v28, v107); /*0x102ffe074*/
      v109 = _mm_unpacklo_epi32(v102, v104); /*0x102ffe07d*/
      v110 = _mm_unpackhi_epi32(v102, v104); /*0x102ffe081*/
      v7 = v103; /*0x102ffe085*/
      v111 = _mm_unpacklo_epi32(v106, v108); /*0x102ffe08d*/
      v112 = _mm_unpackhi_epi32(v106, v108); /*0x102ffe091*/
      v113 = _mm_unpacklo_epi64(v109, v111); /*0x102ffe099*/
      v114 = _mm_unpackhi_epi64(v109, v111); /*0x102ffe09d*/
      v115 = _mm_unpacklo_epi64(v110, v112); /*0x102ffe0a5*/
      v116 = _mm_unpackhi_epi64(v110, v112); /*0x102ffe0a9*/
      v8 = v105; /*0x102ffe0ad*/
      a3[1] = _mm_xor_si128(_mm_loadu_si128(a2 + 1), v113); /*0x102ffe0ba*/
      a3[5] = _mm_xor_si128(_mm_loadu_si128(a2 + 5), v114); /*0x102ffe0c8*/
      a3[9] = _mm_xor_si128(_mm_loadu_si128(a2 + 9), v115); /*0x102ffe0d9*/
      a3[13] = _mm_xor_si128(_mm_loadu_si128(a2 + 13), v116); /*0x102ffe0ed*/
      v10 = _mm_load_si128(&v218); /*0x102ffe0f5*/
      v117 = _mm_add_epi32(v29, v10); /*0x102ffe0fd*/
      v118 = _mm_load_si128(&v219); /*0x102ffe102*/
      v119 = _mm_add_epi32(v11, v118); /*0x102ffe10a*/
      v120 = _mm_load_si128(&v220); /*0x102ffe10f*/
      v121 = _mm_add_epi32(v12, v120); /*0x102ffe117*/
      v122 = _mm_load_si128(&v221); /*0x102ffe11c*/
      v123 = _mm_add_epi32(v13, v122); /*0x102ffe124*/
      v124 = _mm_unpacklo_epi32(v117, v119); /*0x102ffe12e*/
      v125 = _mm_unpackhi_epi32(v117, v119); /*0x102ffe133*/
      v11 = v118; /*0x102ffe138*/
      v126 = _mm_unpacklo_epi32(v121, v123); /*0x102ffe142*/
      v127 = _mm_unpackhi_epi32(v121, v123); /*0x102ffe147*/
      v13 = v122; /*0x102ffe14c*/
      v128 = _mm_unpacklo_epi64(v124, v126); /*0x102ffe155*/
      v129 = _mm_unpackhi_epi64(v124, v126); /*0x102ffe159*/
      v130 = _mm_unpacklo_epi64(v125, v127); /*0x102ffe162*/
      v131 = _mm_unpackhi_epi64(v125, v127); /*0x102ffe167*/
      v12 = v120; /*0x102ffe16c*/
      a3[2] = _mm_xor_si128(_mm_loadu_si128(a2 + 2), v128); /*0x102ffe17a*/
      v6 = _mm_load_si128(&v225); /*0x102ffe17f*/
      a3[6] = _mm_xor_si128(_mm_loadu_si128(a2 + 6), v129); /*0x102ffe190*/
      a3[10] = _mm_xor_si128(_mm_loadu_si128(a2 + 10), v130); /*0x102ffe1a1*/
      v132 = _mm_xor_si128(_mm_loadu_si128(a2 + 14), v131); /*0x102ffe1b1*/
      v9 = v107; /*0x102ffe1b6*/
      a3[14] = v132; /*0x102ffe1bb*/
      v133 = _mm_add_epi32(_mm_load_si128(&v213), v22); /*0x102ffe1cb*/
      v134 = _mm_add_epi32(_mm_load_si128(&v214), v23); /*0x102ffe1d8*/
      v14 = _mm_load_si128(&v222); /*0x102ffe1dd*/
      v135 = _mm_add_epi32(v30, v14); /*0x102ffe1e6*/
      v136 = _mm_add_epi32(_mm_load_si128(&v230), _mm_load_si128(&v228)); /*0x102ffe1f9*/
      v137 = _mm_unpacklo_epi32(v133, v134); /*0x102ffe203*/
      v138 = _mm_unpackhi_epi32(v133, v134); /*0x102ffe208*/
      v139 = _mm_unpacklo_epi32(v135, v136); /*0x102ffe210*/
      v140 = _mm_unpackhi_epi32(v135, v136); /*0x102ffe214*/
      v141 = _mm_unpacklo_epi64(v137, v139); /*0x102ffe21d*/
      v142 = _mm_unpackhi_epi64(v137, v139); /*0x102ffe221*/
      v143 = _mm_unpacklo_epi64(v138, v140); /*0x102ffe22a*/
      v144 = _mm_unpackhi_epi64(v138, v140); /*0x102ffe22e*/
      v145 = _mm_xor_si128(_mm_loadu_si128(a2 + 3), v141); /*0x102ffe237*/
      v5 = _mm_load_si128(&v224); /*0x102ffe23b*/
      a3[3] = v145; /*0x102ffe243*/
      a3[7] = _mm_xor_si128(_mm_loadu_si128(a2 + 7), v142); /*0x102ffe252*/
      v146 = _mm_xor_si128(_mm_loadu_si128(a2 + 11), v143); /*0x102ffe25f*/
      v4 = _mm_load_si128(&v223); /*0x102ffe263*/
      a3[11] = v146; /*0x102ffe26b*/
      a3[15] = _mm_xor_si128(_mm_loadu_si128(a2 + 15), v144); /*0x102ffe27f*/
      a4 -= 256LL; /*0x102ffe287*/
      a3 += 16; /*0x102ffe28e*/
      a2 += 16; /*0x102ffe291*/
    }
    while ( a4 > 0xFF ); /*0x102ffe29b*/
  }
  if ( a4 >= 0x40 ) /*0x102ffe2a5*/
  {
    v147 = _mm_load_si128((const __m128i *)&xmmword_1094BA1B0); /*0x102ffe2ab*/
    v148 = _mm_load_si128((const __m128i *)&xmmword_1094BA1C0); /*0x102ffe2b3*/
    do /*0x102ffe43f*/
    {
      v149 = _mm_loadu_si128(a1); /*0x102ffe2bb*/
      v150 = _mm_loadu_si128(a1 + 1); /*0x102ffe2bf*/
      v151 = _mm_loadu_si128(a1 + 2); /*0x102ffe2c4*/
      v152 = _mm_loadu_si128(a1 + 3); /*0x102ffe2c9*/
      v153 = -2; /*0x102ffe2ce*/
      v154 = v152; /*0x102ffe2d3*/
      v155 = v151; /*0x102ffe2d8*/
      v156 = v150; /*0x102ffe2dc*/
      v157 = v149; /*0x102ffe2e0*/
      do /*0x102ffe3d7*/
      {
        v158 = _mm_add_epi32(v157, v156); /*0x102ffe2e5*/
        v159 = _mm_shufflehi_epi16(_mm_shufflelo_epi16(_mm_xor_si128(v154, v158), 177), 177); /*0x102ffe2f5*/
        v160 = _mm_add_epi32(v155, v159); /*0x102ffe2fb*/
        v161 = _mm_xor_si128(v156, v160); /*0x102ffe300*/
        v162 = _mm_or_si128(_mm_slli_epi32(v161, 0xCu), _mm_srli_epi32(v161, 0x14u)); /*0x102ffe314*/
        v163 = _mm_add_epi32(v158, v162); /*0x102ffe319*/
        v164 = _mm_xor_si128(_mm_shuffle_epi8(v159, v147), _mm_shuffle_epi8(v163, v147)); /*0x102ffe330*/
        v165 = _mm_add_epi32(v160, v164); /*0x102ffe335*/
        v166 = _mm_xor_si128(v162, v165); /*0x102ffe33a*/
        v167 = _mm_or_si128(_mm_slli_epi32(v166, 7u), _mm_srli_epi32(v166, 0x19u)); /*0x102ffe353*/
        v168 = _mm_add_epi32(_mm_shuffle_epi32(v163, 147), v167); /*0x102ffe358*/
        v169 = _mm_xor_si128(_mm_shuffle_epi8(v164, v148), _mm_shufflehi_epi16(_mm_shufflelo_epi16(v168, 177), 177)); /*0x102ffe36f*/
        v170 = _mm_add_epi32(_mm_shuffle_epi32(v165, 57), v169); /*0x102ffe374*/
        v171 = _mm_xor_si128(v167, v170); /*0x102ffe379*/
        v172 = _mm_or_si128(_mm_slli_epi32(v171, 0xCu), _mm_srli_epi32(v171, 0x14u)); /*0x102ffe38d*/
        v173 = _mm_add_epi32(v168, v172); /*0x102ffe392*/
        v157 = _mm_shuffle_epi32(v173, 57); /*0x102ffe397*/
        v174 = _mm_shuffle_epi8(_mm_xor_si128(v173, v169), v147); /*0x102ffe3a2*/
        v175 = _mm_add_epi32(v170, v174); /*0x102ffe3a8*/
        v154 = _mm_shuffle_epi32(v174, 78); /*0x102ffe3ad*/
        v176 = _mm_xor_si128(v172, v175); /*0x102ffe3b3*/
        v155 = _mm_shuffle_epi32(v175, 147); /*0x102ffe3b7*/
        v156 = _mm_or_si128(_mm_slli_epi32(v176, 7u), _mm_srli_epi32(v176, 0x19u)); /*0x102ffe3cc*/
        v153 += 2; /*0x102ffe3d1*/
      }
      while ( v153 < 0x12 ); /*0x102ffe3d7*/
      v177 = _mm_add_epi32(v155, v151); /*0x102ffe3e6*/
      v178 = _mm_xor_si128(_mm_loadu_si128(a2 + 1), _mm_add_epi32(v156, v150)); /*0x102ffe3fd*/
      v179 = _mm_xor_si128(_mm_loadu_si128(a2 + 2), v177); /*0x102ffe406*/
      v180 = _mm_xor_si128(_mm_loadu_si128(a2 + 3), _mm_add_epi32(v154, v152)); /*0x102ffe40f*/
      *a3 = _mm_xor_si128(_mm_loadu_si128(a2), _mm_add_epi32(v157, v149)); /*0x102ffe414*/
      a3[1] = v178; /*0x102ffe418*/
      a3[2] = v179; /*0x102ffe41d*/
      a3[3] = v180; /*0x102ffe422*/
      ++a1[3].i64[0]; /*0x102ffe427*/
      a4 -= 64LL; /*0x102ffe42f*/
      a3 += 4; /*0x102ffe433*/
      a2 += 4; /*0x102ffe437*/
    }
    while ( a4 > 0x3F ); /*0x102ffe43f*/
  }
  if ( a4 != 0 ) /*0x102ffe448*/
  {
    v181 = _mm_loadu_si128(a1); /*0x102ffe44e*/
    v182 = _mm_loadu_si128(a1 + 1); /*0x102ffe452*/
    v183 = _mm_loadu_si128(a1 + 2); /*0x102ffe457*/
    v184 = _mm_loadu_si128(a1 + 3); /*0x102ffe45c*/
    v185 = -2; /*0x102ffe461*/
    v186 = _mm_load_si128((const __m128i *)&xmmword_1094BA1B0); /*0x102ffe466*/
    v187 = _mm_load_si128((const __m128i *)&xmmword_1094BA1C0); /*0x102ffe46e*/
    v188 = v184; /*0x102ffe476*/
    v189 = v183; /*0x102ffe47b*/
    v190 = v182; /*0x102ffe480*/
    v191 = v181; /*0x102ffe484*/
    do /*0x102ffe576*/
    {
      v192 = _mm_add_epi32(v191, v190); /*0x102ffe488*/
      v193 = _mm_shufflehi_epi16(_mm_shufflelo_epi16(_mm_xor_si128(v188, v192), 177), 177); /*0x102ffe497*/
      v194 = _mm_add_epi32(v189, v193); /*0x102ffe49d*/
      v195 = _mm_xor_si128(v190, v194); /*0x102ffe4a2*/
      v196 = _mm_or_si128(_mm_slli_epi32(v195, 0xCu), _mm_srli_epi32(v195, 0x14u)); /*0x102ffe4b7*/
      v197 = _mm_add_epi32(v192, v196); /*0x102ffe4bc*/
      v198 = _mm_xor_si128(_mm_shuffle_epi8(v193, v186), _mm_shuffle_epi8(v197, v186)); /*0x102ffe4d1*/
      v199 = _mm_add_epi32(v194, v198); /*0x102ffe4d6*/
      v200 = _mm_xor_si128(v196, v199); /*0x102ffe4db*/
      v201 = _mm_or_si128(_mm_slli_epi32(v200, 7u), _mm_srli_epi32(v200, 0x19u)); /*0x102ffe4f4*/
      v202 = _mm_add_epi32(_mm_shuffle_epi32(v197, 147), v201); /*0x102ffe4f8*/
      v203 = _mm_xor_si128(_mm_shuffle_epi8(v198, v187), _mm_shufflehi_epi16(_mm_shufflelo_epi16(v202, 177), 177)); /*0x102ffe50e*/
      v204 = _mm_add_epi32(_mm_shuffle_epi32(v199, 57), v203); /*0x102ffe513*/
      v205 = _mm_xor_si128(v201, v204); /*0x102ffe518*/
      v206 = _mm_or_si128(_mm_slli_epi32(v205, 0xCu), _mm_srli_epi32(v205, 0x14u)); /*0x102ffe52b*/
      v207 = _mm_add_epi32(v202, v206); /*0x102ffe52f*/
      v191 = _mm_shuffle_epi32(v207, 57); /*0x102ffe534*/
      v208 = _mm_shuffle_epi8(_mm_xor_si128(v207, v203), v186); /*0x102ffe53f*/
      v209 = _mm_add_epi32(v204, v208); /*0x102ffe545*/
      v188 = _mm_shuffle_epi32(v208, 78); /*0x102ffe54a*/
      v210 = _mm_xor_si128(v206, v209); /*0x102ffe550*/
      v189 = _mm_shuffle_epi32(v209, 147); /*0x102ffe555*/
      v190 = _mm_or_si128(_mm_slli_epi32(v210, 7u), _mm_srli_epi32(v210, 0x19u)); /*0x102ffe56b*/
      v185 += 2; /*0x102ffe570*/
    }
    while ( v185 < 0x12 ); /*0x102ffe576*/
    *(__m128i *)v232 = _mm_add_epi32(v191, v181); /*0x102ffe58e*/
    *(__m128i *)&v232[2] = _mm_add_epi32(v190, v182); /*0x102ffe593*/
    *(__m128i *)&v232[4] = _mm_add_epi32(v189, v183); /*0x102ffe598*/
    *(__m128i *)&v232[6] = _mm_add_epi32(v188, v184); /*0x102ffe59e*/
    for ( i = 0; i != a4; ++i ) /*0x102ffe5a4*/
      a3->i8[i] = a2->i8[i] ^ *((_BYTE *)v232 + i); /*0x102ffe5af*/
    sodium_memzero(a1: v232, a2: 64); /*0x102ffe5c4*/
  }
  return __stack_chk_guard; /*0x102ffe5d9*/
}

// Address: 0x102ffe7a2 | Name: _chacha20_encrypt_bytes_1
__int64 __fastcall chacha20_encrypt_bytes_1(__int64 _RDI, __int64 a2, __int64 _RDX, unsigned __int64 a4)
{
  unsigned int v29; // r8d
  unsigned int v304; // r8d
  unsigned int v532; // eax
  unsigned int v588; // eax
  __int64 i; // rax
  __int64 result; // rax
  _QWORD v697[8]; // [rsp+360h] [rbp-60h] BYREF
  __int64 v698; // [rsp+3A8h] [rbp-18h]

  if ( a4 >= 0x200 ) /*0x102ffe7ca*/
  {
    __asm /*0x102ffe7d0*/
    {
      vpbroadcastd ymm10, dword ptr [rdi]
      vpbroadcastd ymm12, dword ptr [rdi+4]
      vpbroadcastd ymm11, dword ptr [rdi+8]
      vpbroadcastd ymm13, dword ptr [rdi+0Ch]
      vpbroadcastd ymm14, dword ptr [rdi+10h]
      vpbroadcastd ymm3, dword ptr [rdi+14h]
      vpbroadcastd ymm4, dword ptr [rdi+18h]
      vpbroadcastd ymm5, dword ptr [rdi+1Ch]
      vbroadcastss ymm0, dword ptr [rdi+20h]
      vmovaps [rsp+3C0h+var_280], ymm0
      vpbroadcastd ymm6, dword ptr [rdi+24h]
      vpbroadcastd ymm7, dword ptr [rdi+28h]
      vpbroadcastd ymm0, dword ptr [rdi+2Ch]
      vmovdqa [rsp+3C0h+var_2A0], ymm0
      vpbroadcastd ymm15, dword ptr [rdi+38h]
      vpbroadcastd ymm9, dword ptr [rdi+3Ch]
    }
    __asm
    {
      vmovdqa [rsp+3C0h+var_1E0], ymm10
      vmovdqa [rsp+3C0h+var_200], ymm12
      vmovdqa [rsp+3C0h+var_220], ymm11
      vmovdqa [rsp+3C0h+var_80], ymm13
      vmovdqa [rsp+3C0h+var_A0], ymm14
      vmovdqa [rsp+3C0h+var_240], ymm3
      vmovdqa [rsp+3C0h+var_260], ymm4
      vmovdqa [rsp+3C0h+var_C0], ymm5
      vmovdqa [rsp+3C0h+var_E0], ymm6
      vmovdqa [rsp+3C0h+var_100], ymm7
      vmovdqa [rsp+3C0h+var_120], ymm15
      vmovdqa [rsp+3C0h+var_140], ymm9
    }
    do /*0x102ffeff3*/
    {
      _R8 = *(_QWORD *)(_RDI + 48); /*0x102ffe8a6*/
      __asm /*0x102ffe8aa*/
      {
        vmovq xmm0, r8
        vpbroadcastq ymm0, xmm0
        vpaddq ymm1, ymm0, cs:ymmword_1094BA1E0
        vpaddq ymm0, ymm0, cs:ymmword_1094BA200
        vpunpckldq ymm2, ymm1, ymm0
        vpunpckhdq ymm0, ymm1, ymm0
        vpunpckldq ymm1, ymm2, ymm0
        vpermq ymm8, ymm1, 0D8h
        vpunpckhdq ymm0, ymm2, ymm0
        vpermq ymm0, ymm0, 0D8h
      }
      *(_QWORD *)(_RDI + 48) = _R8 + 8; /*0x102ffe8e4*/
      v29 = -2; /*0x102ffe8e8*/
      __asm /*0x102ffe8ee*/
      {
        vmovdqa [rsp+3C0h+var_320], ymm12
        vmovdqa [rsp+3C0h+var_340], ymm13
        vmovdqa ymm2, ymm4
        vmovdqa [rsp+3C0h+var_3C0], ymm5
        vmovdqa ymm5, [rsp+3C0h+var_280]
        vmovdqa ymm1, ymm6
        vmovdqa [rsp+3C0h+var_300], ymm7
        vmovaps ymm4, [rsp+3C0h+var_2A0]
        vmovaps [rsp+3C0h+var_380], ymm4
        vmovdqa [rsp+3C0h+var_180], ymm8
        vmovdqa [rsp+3C0h+var_3A0], ymm8
        vmovdqa [rsp+3C0h+var_1A0], ymm0
        vmovdqa ymm6, ymm0
        vmovdqa [rsp+3C0h+var_360], ymm15
        vmovdqa ymm8, ymm9
      }
      do /*0x102ffecfa*/
      {
        __asm /*0x102ffe955*/
        {
          vpaddd ymm10, ymm10, ymm14
          vpxor ymm0, ymm10, [rsp+3C0h+var_3A0]
          vpshuflw ymm0, ymm0, 0B1h
          vpshufhw ymm15, ymm0, 0B1h
          vpaddd ymm0, ymm15, ymm5
          vmovdqa [rsp+3C0h+var_3A0], ymm0
          vpxor ymm0, ymm14, ymm0
          vpsrld ymm7, ymm0, 14h
          vpslld ymm0, ymm0, 0Ch
          vpor ymm5, ymm0, ymm7
          vpaddd ymm7, ymm3, [rsp+3C0h+var_320]
          vpxor ymm0, ymm6, ymm7
          vpshuflw ymm0, ymm0, 0B1h
          vpshufhw ymm9, ymm0, 0B1h
          vpaddd ymm0, ymm9, ymm1
          vmovdqa [rsp+3C0h+var_2C0], ymm0
          vpxor ymm0, ymm0, ymm3
          vpsrld ymm1, ymm0, 14h
          vpslld ymm0, ymm0, 0Ch
          vpor ymm0, ymm0, ymm1
          vmovdqa [rsp+3C0h+var_2E0], ymm0
          vpaddd ymm6, ymm11, ymm2
          vpxor ymm0, ymm6, [rsp+3C0h+var_360]
          vpshuflw ymm0, ymm0, 0B1h
          vpshufhw ymm4, ymm0, 0B1h
          vpaddd ymm13, ymm4, [rsp+3C0h+var_300]
          vpxor ymm0, ymm13, ymm2
          vpsrld ymm1, ymm0, 14h
          vpslld ymm0, ymm0, 0Ch
          vpor ymm11, ymm0, ymm1
          vmovdqa ymm0, [rsp+3C0h+var_3C0]
          vpaddd ymm3, ymm0, [rsp+3C0h+var_340]
          vpxor ymm1, ymm8, ymm3
          vpshuflw ymm1, ymm1, 0B1h
          vpshufhw ymm2, ymm1, 0B1h
          vpaddd ymm14, ymm2, [rsp+3C0h+var_380]
          vpxor ymm1, ymm14, ymm0
          vpsrld ymm0, ymm1, 14h
          vpslld ymm1, ymm1, 0Ch
          vpor ymm12, ymm1, ymm0
          vpaddd ymm1, ymm10, ymm5
          vmovdqa [rsp+3C0h+var_3C0], ymm1
          vmovdqa ymm10, ymm5
          vbroadcasti128 ymm8, cs:xmmword_1094BA1B0
          vpshufb ymm0, ymm15, ymm8
          vpshufb ymm15, ymm1, ymm8
          vpxor ymm15, ymm15, ymm0
          vmovdqa ymm5, [rsp+3C0h+var_2E0]
          vpaddd ymm7, ymm5, ymm7
          vpshufb ymm0, ymm9, ymm8
          vpshufb ymm9, ymm7, ymm8
          vpxor ymm1, ymm9, ymm0
          vmovdqa [rsp+3C0h+var_340], ymm1
          vpaddd ymm6, ymm11, ymm6
          vmovdqa [rsp+3C0h+var_380], ymm6
          vpshufb ymm0, ymm4, ymm8
          vpshufb ymm4, ymm6, ymm8
          vpxor ymm4, ymm0, ymm4
          vmovdqa [rsp+3C0h+var_320], ymm4
          vpaddd ymm3, ymm12, ymm3
          vmovdqa [rsp+3C0h+var_360], ymm3
          vpshufb ymm0, ymm2, ymm8
          vpshufb ymm2, ymm3, ymm8
          vpxor ymm2, ymm0, ymm2
          vpaddd ymm9, ymm15, [rsp+3C0h+var_3A0]
          vpxor ymm0, ymm9, ymm10
          vpsrld ymm3, ymm0, 19h
          vpslld ymm0, ymm0, 7
          vpor ymm0, ymm0, ymm3
          vmovdqa [rsp+3C0h+var_3A0], ymm0
          vpaddd ymm0, ymm1, [rsp+3C0h+var_2C0]
          vmovdqa [rsp+3C0h+var_300], ymm0
          vpxor ymm0, ymm0, ymm5
          vpsrld ymm3, ymm0, 19h
          vpslld ymm0, ymm0, 7
          vpor ymm3, ymm0, ymm3
          vpaddd ymm13, ymm13, ymm4
          vpxor ymm0, ymm13, ymm11
          vpsrld ymm10, ymm0, 19h
          vpslld ymm0, ymm0, 7
          vpor ymm11, ymm10, ymm0
          vpaddd ymm4, ymm14, ymm2
          vpxor ymm0, ymm12, ymm4
          vpsrld ymm1, ymm0, 19h
          vpslld ymm0, ymm0, 7
          vpor ymm0, ymm0, ymm1
          vpaddd ymm10, ymm3, [rsp+3C0h+var_3C0]
          vpxor ymm1, ymm10, ymm2
          vpshuflw ymm1, ymm1, 0B1h
          vpshufhw ymm12, ymm1, 0B1h
          vpaddd ymm1, ymm13, ymm12
          vmovdqa [rsp+3C0h+var_3C0], ymm1
          vpxor ymm1, ymm1, ymm3
          vpsrld ymm2, ymm1, 14h
          vpslld ymm1, ymm1, 0Ch
          vpor ymm14, ymm1, ymm2
          vmovdqa [rsp+3C0h+var_1C0], ymm14
          vpaddd ymm6, ymm11, ymm7
          vpxor ymm3, ymm15, ymm6
          vpshuflw ymm3, ymm3, 0B1h
          vpshufhw ymm15, ymm3, 0B1h
          vpaddd ymm1, ymm15, ymm4
          vmovdqa [rsp+3C0h+var_2C0], ymm1
          vpxor ymm3, ymm11, ymm1
          vpsrld ymm7, ymm3, 14h
          vpslld ymm3, ymm3, 0Ch
          vpor ymm1, ymm3, ymm7
          vpaddd ymm11, ymm0, [rsp+3C0h+var_380]
          vpxor ymm3, ymm11, [rsp+3C0h+var_340]
          vpshuflw ymm3, ymm3, 0B1h
          vpshufhw ymm3, ymm3, 0B1h
          vpaddd ymm2, ymm9, ymm3
          vmovdqa [rsp+3C0h+var_2E0], ymm2
          vpxor ymm0, ymm2, ymm0
          vpsrld ymm7, ymm0, 14h
          vpslld ymm0, ymm0, 0Ch
          vpor ymm0, ymm0, ymm7
          vmovdqa [rsp+3C0h+var_160], ymm0
          vmovdqa ymm0, [rsp+3C0h+var_3A0]
          vpaddd ymm2, ymm0, [rsp+3C0h+var_360]
          vpxor ymm7, ymm2, [rsp+3C0h+var_320]
          vpshuflw ymm7, ymm7, 0B1h
          vpshufhw ymm5, ymm7, 0B1h
          vpaddd ymm13, ymm5, [rsp+3C0h+var_300]
          vpxor ymm7, ymm13, ymm0
          vpsrld ymm0, ymm7, 14h
          vpslld ymm7, ymm7, 0Ch
          vpor ymm9, ymm7, ymm0
          vpaddd ymm10, ymm14, ymm10
          vpshufb ymm0, ymm12, ymm8
          vpshufb ymm12, ymm10, ymm8
          vpxor ymm7, ymm12, ymm0
          vpaddd ymm6, ymm1, ymm6
          vmovdqa ymm14, ymm1
          vpshufb ymm0, ymm15, ymm8
          vmovdqa [rsp+3C0h+var_320], ymm6
          vpshufb ymm4, ymm6, ymm8
          vpxor ymm12, ymm0, ymm4
          vmovdqa ymm15, [rsp+3C0h+var_160]
          vpaddd ymm11, ymm15, ymm11
          vpshufb ymm0, ymm3, ymm8
          vpshufb ymm3, ymm11, ymm8
          vpxor ymm6, ymm0, ymm3
          vpaddd ymm2, ymm9, ymm2
          vmovdqa [rsp+3C0h+var_340], ymm2
          vpshufb ymm0, ymm5, ymm8
          vpshufb ymm1, ymm2, ymm8
          vpxor ymm4, ymm0, ymm1
          vpaddd ymm0, ymm7, [rsp+3C0h+var_3C0]
          vmovdqa [rsp+3C0h+var_300], ymm0
          vpxor ymm0, ymm0, [rsp+3C0h+var_1C0]
          vpsrld ymm1, ymm0, 19h
          vpslld ymm0, ymm0, 7
          vpor ymm3, ymm0, ymm1
          vmovdqa [rsp+3C0h+var_3A0], ymm12
          vpaddd ymm0, ymm12, [rsp+3C0h+var_2C0]
          vmovdqa [rsp+3C0h+var_380], ymm0
          vpxor ymm0, ymm14, ymm0
          vpsrld ymm1, ymm0, 19h
          vpslld ymm0, ymm0, 7
          vpor ymm2, ymm0, ymm1
          vpaddd ymm5, ymm6, [rsp+3C0h+var_2E0]
          vpxor ymm0, ymm15, ymm5
          vpsrld ymm1, ymm0, 19h
          vpslld ymm0, ymm0, 7
          vpor ymm0, ymm0, ymm1
          vmovdqa [rsp+3C0h+var_3C0], ymm0
          vmovdqa [rsp+3C0h+var_360], ymm4
          vpaddd ymm1, ymm13, ymm4
          vmovdqa ymm8, ymm7
          vpxor ymm0, ymm9, ymm1
          vpsrld ymm4, ymm0, 19h
          vpslld ymm0, ymm0, 7
          vpor ymm14, ymm0, ymm4
        }
        v29 += 2; /*0x102ffecf2*/
      }
      while ( v29 < 0x12 ); /*0x102ffecfa*/
      __asm /*0x102ffed00*/
      {
        vpaddd ymm0, ymm10, [rsp+3C0h+var_1E0]
        vmovdqa ymm4, [rsp+3C0h+var_200]
        vpaddd ymm4, ymm4, [rsp+3C0h+var_320]
        vpunpckldq ymm9, ymm0, ymm4
        vpunpckhdq ymm0, ymm0, ymm4
        vmovdqa ymm15, ymm6
        vpaddd ymm4, ymm11, [rsp+3C0h+var_220]
        vmovdqa ymm11, [rsp+3C0h+var_80]
        vpaddd ymm6, ymm11, [rsp+3C0h+var_340]
        vpunpckldq ymm7, ymm4, ymm6
        vpunpckhdq ymm4, ymm4, ymm6
        vpunpcklqdq ymm6, ymm9, ymm7
        vpunpckhqdq ymm13, ymm9, ymm7
        vpunpcklqdq ymm7, ymm0, ymm4
        vpunpckhqdq ymm0, ymm0, ymm4
        vmovdqa ymm9, [rsp+3C0h+var_A0]
        vpaddd ymm4, ymm14, ymm9
        vmovdqa ymm14, ymm9
        vpaddd ymm3, ymm3, [rsp+3C0h+var_240]
        vpunpckldq ymm9, ymm4, ymm3
        vpunpckhdq ymm3, ymm4, ymm3
        vpaddd ymm2, ymm2, [rsp+3C0h+var_260]
        vmovdqa ymm12, [rsp+3C0h+var_C0]
        vpaddd ymm4, ymm12, [rsp+3C0h+var_3C0]
        vpunpckldq ymm10, ymm2, ymm4
        vpunpckhdq ymm2, ymm2, ymm4
        vpunpcklqdq ymm4, ymm9, ymm10
        vpunpckhqdq ymm9, ymm9, ymm10
        vpunpcklqdq ymm10, ymm3, ymm2
        vpunpckhqdq ymm2, ymm3, ymm2
        vinserti128 ymm3, ymm6, xmm4, 1
        vperm2i128 ymm4, ymm6, ymm4, 31h ; '1'
        vinserti128 ymm6, ymm13, xmm9, 1
        vperm2i128 ymm13, ymm13, ymm9, 31h ; '1'
        vinserti128 ymm9, ymm7, xmm10, 1
        vperm2i128 ymm7, ymm7, ymm10, 31h ; '1'
        vinserti128 ymm10, ymm0, xmm2, 1
        vperm2i128 ymm0, ymm0, ymm2, 31h ; '1'
        vpxor ymm2, ymm3, ymmword ptr [rsi]
        vpxor ymm3, ymm6, ymmword ptr [rsi+40h]
        vpxor ymm6, ymm9, ymmword ptr [rsi+80h]
        vpxor ymm9, ymm10, ymmword ptr [rsi+0C0h]
        vpxor ymm4, ymm4, ymmword ptr [rsi+100h]
        vpxor ymm10, ymm13, ymmword ptr [rsi+140h]
        vpxor ymm7, ymm7, ymmword ptr [rsi+180h]
        vpxor ymm0, ymm0, ymmword ptr [rsi+1C0h]
        vmovdqu ymmword ptr [rdx], ymm2
        vmovdqu ymmword ptr [rdx+40h], ymm3
        vmovdqu ymmword ptr [rdx+80h], ymm6
        vmovdqu ymmword ptr [rdx+0C0h], ymm9
        vmovdqu ymmword ptr [rdx+100h], ymm4
        vmovdqu ymmword ptr [rdx+140h], ymm10
        vmovdqu ymmword ptr [rdx+180h], ymm7
        vmovdqu ymmword ptr [rdx+1C0h], ymm0
        vpaddd ymm0, ymm5, [rsp+3C0h+var_280]
        vmovdqa ymm13, ymm11
        vmovdqa ymm10, [rsp+3C0h+var_E0]
        vpaddd ymm1, ymm10, ymm1
        vmovdqa ymm11, [rsp+3C0h+var_100]
        vpaddd ymm2, ymm11, [rsp+3C0h+var_300]
        vmovdqa ymm3, [rsp+3C0h+var_2A0]
        vpaddd ymm3, ymm3, [rsp+3C0h+var_380]
        vpunpckldq ymm4, ymm0, ymm1
        vpunpckhdq ymm0, ymm0, ymm1
        vpunpckldq ymm1, ymm2, ymm3
        vpunpckhdq ymm2, ymm2, ymm3
        vpunpcklqdq ymm3, ymm4, ymm1
        vpunpckhqdq ymm1, ymm4, ymm1
        vpunpcklqdq ymm4, ymm0, ymm2
        vpunpckhqdq ymm0, ymm0, ymm2
        vmovdqa ymm2, [rsp+3C0h+var_3A0]
        vpaddd ymm2, ymm2, [rsp+3C0h+var_180]
        vpaddd ymm5, ymm15, [rsp+3C0h+var_1A0]
        vmovdqa ymm15, [rsp+3C0h+var_120]
        vpaddd ymm6, ymm15, [rsp+3C0h+var_360]
        vmovdqa ymm9, [rsp+3C0h+var_140]
        vpaddd ymm7, ymm9, ymm8
        vpunpckldq ymm8, ymm2, ymm5
        vpunpckhdq ymm2, ymm2, ymm5
        vpunpckldq ymm5, ymm6, ymm7
        vpunpckhdq ymm6, ymm6, ymm7
        vpunpcklqdq ymm7, ymm8, ymm5
        vpunpckhqdq ymm5, ymm8, ymm5
        vpunpcklqdq ymm8, ymm2, ymm6
        vpunpckhqdq ymm2, ymm2, ymm6
        vinserti128 ymm6, ymm3, xmm7, 1
        vperm2i128 ymm3, ymm3, ymm7, 31h ; '1'
        vinserti128 ymm7, ymm1, xmm5, 1
        vperm2i128 ymm1, ymm1, ymm5, 31h ; '1'
        vinserti128 ymm5, ymm4, xmm8, 1
        vperm2i128 ymm4, ymm4, ymm8, 31h ; '1'
        vinserti128 ymm8, ymm0, xmm2, 1
        vperm2i128 ymm0, ymm0, ymm2, 31h ; '1'
        vpxor ymm2, ymm6, ymmword ptr [rsi+20h]
        vpxor ymm6, ymm7, ymmword ptr [rsi+60h]
        vpxor ymm5, ymm5, ymmword ptr [rsi+0A0h]
        vpxor ymm7, ymm8, ymmword ptr [rsi+0E0h]
        vpxor ymm3, ymm3, ymmword ptr [rsi+120h]
        vpxor ymm1, ymm1, ymmword ptr [rsi+160h]
        vpxor ymm4, ymm4, ymmword ptr [rsi+1A0h]
        vpxor ymm0, ymm0, ymmword ptr [rsi+1E0h]
        vmovdqu ymmword ptr [rdx+20h], ymm2
        vmovdqu ymmword ptr [rdx+60h], ymm6
        vmovdqa ymm6, ymm10
        vmovdqa ymm10, [rsp+3C0h+var_1E0]
        vmovdqu ymmword ptr [rdx+0A0h], ymm5
        vmovdqa ymm5, ymm12
        vmovdqa ymm12, [rsp+3C0h+var_200]
        vmovdqu ymmword ptr [rdx+0E0h], ymm7
        vmovdqa ymm7, ymm11
        vmovdqa ymm11, [rsp+3C0h+var_220]
        vmovdqu ymmword ptr [rdx+120h], ymm3
        vmovdqa ymm3, [rsp+3C0h+var_240]
        vmovdqu ymmword ptr [rdx+160h], ymm1
        vmovdqu ymmword ptr [rdx+1A0h], ymm4
        vmovdqa ymm4, [rsp+3C0h+var_260]
        vmovdqu ymmword ptr [rdx+1E0h], ymm0
      }
      a4 -= 512LL; /*0x102ffefdf*/
      _RDX += 512; /*0x102ffefe6*/
      a2 += 512; /*0x102ffefe9*/
    }
    while ( a4 > 0x1FF ); /*0x102ffeff3*/
  }
  if ( a4 >= 0x100 ) /*0x102fff000*/
  {
    __asm /*0x102fff006*/
    {
      vpbroadcastd xmm10, dword ptr [rdi]
      vpbroadcastd xmm3, dword ptr [rdi+4]
      vpbroadcastd xmm4, dword ptr [rdi+8]
      vpbroadcastd xmm13, dword ptr [rdi+0Ch]
      vbroadcastss xmm0, dword ptr [rdi+10h]
      vmovaps xmmword ptr [rsp+3C0h+var_2C0], xmm0
      vpbroadcastd xmm15, dword ptr [rdi+14h]
      vpbroadcastd xmm7, dword ptr [rdi+18h]
      vpbroadcastd xmm9, dword ptr [rdi+1Ch]
      vpbroadcastd xmm6, dword ptr [rdi+20h]
      vpbroadcastd xmm8, dword ptr [rdi+24h]
      vpbroadcastd xmm0, dword ptr [rdi+28h]
      vmovdqa xmmword ptr [rsp+3C0h+var_2E0], xmm0
      vpbroadcastd xmm11, dword ptr [rdi+2Ch]
      vpbroadcastd xmm5, dword ptr [rdi+38h]
      vpbroadcastd xmm14, dword ptr [rdi+3Ch]
    }
    __asm
    {
      vmovdqa xmmword ptr [rsp+3C0h+var_200], xmm10
      vmovdqa xmmword ptr [rsp+3C0h+var_3C0], xmm3
      vmovdqa xmmword ptr [rsp+3C0h+var_320], xmm4
      vmovdqa xmmword ptr [rsp+3C0h+var_340], xmm13
      vmovdqa xmmword ptr [rsp+3C0h+var_220], xmm15
      vmovdqa xmmword ptr [rsp+3C0h+var_240], xmm7
      vmovdqa xmmword ptr [rsp+3C0h+var_260], xmm9
      vmovdqa xmmword ptr [rsp+3C0h+var_280], xmm6
      vmovdqa xmmword ptr [rsp+3C0h+var_2A0], xmm8
      vmovdqa xmmword ptr [rsp+3C0h+var_180], xmm11
      vmovdqa xmmword ptr [rsp+3C0h+var_1C0], xmm5
      vmovdqa xmmword ptr [rsp+3C0h+var_1A0], xmm14
    }
    do /*0x102fff6b0*/
    {
      _R8 = *(_QWORD *)(_RDI + 48); /*0x102fff0d8*/
      __asm /*0x102fff0dc*/
      {
        vmovq xmm0, r8
        vpbroadcastq xmm0, xmm0
        vpaddq xmm1, xmm0, cs:xmmword_108F246B0
        vpaddq xmm0, xmm0, cs:xmmword_108F4EAB0
        vpunpckldq xmm2, xmm1, xmm0
        vpunpckhdq xmm0, xmm1, xmm0
        vmovdqa xmm5, xmm15
        vpunpckldq xmm15, xmm2, xmm0
        vpunpckhdq xmm12, xmm2, xmm0
      }
      *(_QWORD *)(_RDI + 48) = _R8 + 4; /*0x102fff10e*/
      v304 = -2; /*0x102fff112*/
      __asm /*0x102fff118*/
      {
        vmovdqa xmm0, xmm8
        vmovdqa xmm8, xmm10
        vmovdqa xmm1, xmm3
        vmovdqa xmm2, xmm4
        vmovdqa xmm3, xmm13
        vmovdqa xmm13, xmmword ptr [rsp+3C0h+var_2C0]
        vmovdqa xmm4, xmm6
        vmovdqa xmm6, xmm0
        vmovaps xmm10, xmmword ptr [rsp+3C0h+var_2E0]
        vmovaps xmmword ptr [rsp+3C0h+var_380], xmm10
        vmovdqa xmmword ptr [rsp+3C0h+var_160], xmm15
        vmovdqa xmm10, xmm15
        vmovdqa xmmword ptr [rsp+3C0h+var_1E0], xmm12
        vmovdqa xmm0, xmm12
        vmovdqa xmm12, xmmword ptr [rsp+3C0h+var_1C0]
        vmovdqa xmmword ptr [rsp+3C0h+var_360], xmm14
      }
      do /*0x102fff45c*/
      {
        __asm /*0x102fff177*/
        {
          vpaddd xmm8, xmm8, xmm13
          vpxor xmm15, xmm10, xmm8
          vpshuflw xmm15, xmm15, 0B1h
          vpshufhw xmm15, xmm15, 0B1h
          vpaddd xmm4, xmm15, xmm4
          vpxor xmm13, xmm13, xmm4
          vpsrld xmm14, xmm13, 14h
          vpslld xmm13, xmm13, 0Ch
          vpor xmm13, xmm13, xmm14
          vpaddd xmm8, xmm13, xmm8
          vmovdqa xmm10, cs:xmmword_1094BA1B0
          vpshufb xmm14, xmm15, xmm10
          vpshufb xmm15, xmm8, xmm10
          vpxor xmm14, xmm14, xmm15
          vmovdqa xmmword ptr [rsp+3C0h+var_3A0], xmm14
          vpaddd xmm4, xmm14, xmm4
          vmovdqa xmmword ptr [rsp+3C0h+var_300], xmm4
          vpxor xmm13, xmm13, xmm4
          vpsrld xmm14, xmm13, 19h
          vpslld xmm13, xmm13, 7
          vpor xmm13, xmm13, xmm14
          vpaddd xmm1, xmm1, xmm5
          vpxor xmm0, xmm0, xmm1
          vpshuflw xmm0, xmm0, 0B1h
          vpshufhw xmm0, xmm0, 0B1h
          vpaddd xmm6, xmm6, xmm0
          vpxor xmm5, xmm6, xmm5
          vpsrld xmm14, xmm5, 14h
          vpslld xmm5, xmm5, 0Ch
          vpor xmm5, xmm14, xmm5
          vpaddd xmm1, xmm5, xmm1
          vmovdqa xmm15, xmm10
          vpshufb xmm0, xmm0, xmm10
          vpshufb xmm14, xmm1, xmm10
          vpxor xmm4, xmm14, xmm0
          vpaddd xmm6, xmm6, xmm4
          vpxor xmm5, xmm6, xmm5
          vpsrld xmm14, xmm5, 19h
          vpslld xmm5, xmm5, 7
          vpor xmm5, xmm14, xmm5
          vpaddd xmm2, xmm2, xmm7
          vpxor xmm12, xmm12, xmm2
          vpshuflw xmm12, xmm12, 0B1h
          vpshufhw xmm12, xmm12, 0B1h
          vpaddd xmm10, xmm12, xmmword ptr [rsp+3C0h+var_380]
          vpxor xmm7, xmm10, xmm7
          vpsrld xmm14, xmm7, 14h
          vpslld xmm7, xmm7, 0Ch
          vpor xmm7, xmm14, xmm7
          vpaddd xmm2, xmm7, xmm2
          vpshufb xmm12, xmm12, xmm15
          vpshufb xmm14, xmm2, xmm15
          vpxor xmm12, xmm12, xmm14
          vpaddd xmm10, xmm10, xmm12
          vpxor xmm7, xmm10, xmm7
          vpsrld xmm14, xmm7, 19h
          vpslld xmm7, xmm7, 7
          vpor xmm7, xmm14, xmm7
          vpaddd xmm3, xmm9, xmm3
          vpxor xmm14, xmm3, xmmword ptr [rsp+3C0h+var_360]
          vpshuflw xmm14, xmm14, 0B1h
          vpshufhw xmm14, xmm14, 0B1h
          vpaddd xmm11, xmm11, xmm14
          vpxor xmm9, xmm11, xmm9
          vpsrld xmm0, xmm9, 14h
          vpslld xmm9, xmm9, 0Ch
          vpor xmm0, xmm9, xmm0
          vpaddd xmm3, xmm0, xmm3
          vpshufb xmm9, xmm14, xmm15
          vpshufb xmm14, xmm3, xmm15
          vpxor xmm14, xmm9, xmm14
          vpaddd xmm11, xmm11, xmm14
          vpxor xmm0, xmm11, xmm0
          vpsrld xmm9, xmm0, 19h
          vpslld xmm0, xmm0, 7
          vpor xmm9, xmm9, xmm0
          vpaddd xmm0, xmm8, xmm5
          vpxor xmm8, xmm14, xmm0
          vpshuflw xmm8, xmm8, 0B1h
          vpshufhw xmm14, xmm8, 0B1h
          vpaddd xmm10, xmm10, xmm14
          vpxor xmm5, xmm10, xmm5
          vpsrld xmm8, xmm5, 14h
          vpslld xmm5, xmm5, 0Ch
          vpor xmm5, xmm8, xmm5
          vpaddd xmm8, xmm5, xmm0
          vpshufb xmm0, xmm14, xmm15
          vpshufb xmm14, xmm8, xmm15
          vpxor xmm0, xmm14, xmm0
          vmovdqa xmmword ptr [rsp+3C0h+var_360], xmm0
          vpaddd xmm0, xmm10, xmm0
          vmovdqa xmmword ptr [rsp+3C0h+var_380], xmm0
          vpxor xmm0, xmm0, xmm5
          vpsrld xmm5, xmm0, 19h
          vpslld xmm0, xmm0, 7
          vpor xmm5, xmm0, xmm5
          vpaddd xmm0, xmm7, xmm1
          vpxor xmm1, xmm0, xmmword ptr [rsp+3C0h+var_3A0]
          vpshuflw xmm1, xmm1, 0B1h
          vpshufhw xmm14, xmm1, 0B1h
          vpaddd xmm11, xmm11, xmm14
          vpxor xmm1, xmm11, xmm7
          vpsrld xmm7, xmm1, 14h
          vpslld xmm1, xmm1, 0Ch
          vpor xmm7, xmm1, xmm7
          vpaddd xmm1, xmm7, xmm0
          vpshufb xmm0, xmm14, xmm15
          vpshufb xmm14, xmm1, xmm15
          vpxor xmm10, xmm14, xmm0
          vpaddd xmm11, xmm11, xmm10
          vpxor xmm0, xmm11, xmm7
          vpsrld xmm7, xmm0, 19h
          vpslld xmm0, xmm0, 7
          vpor xmm7, xmm0, xmm7
          vpaddd xmm0, xmm9, xmm2
          vpxor xmm2, xmm4, xmm0
          vpshuflw xmm2, xmm2, 0B1h
          vpshufhw xmm4, xmm2, 0B1h
          vpaddd xmm14, xmm4, xmmword ptr [rsp+3C0h+var_300]
          vpxor xmm2, xmm14, xmm9
          vpsrld xmm9, xmm2, 14h
          vpslld xmm2, xmm2, 0Ch
          vpor xmm9, xmm9, xmm2
          vpaddd xmm2, xmm9, xmm0
          vpshufb xmm0, xmm4, xmm15
          vpshufb xmm4, xmm2, xmm15
          vpxor xmm0, xmm0, xmm4
          vpaddd xmm4, xmm14, xmm0
          vpxor xmm9, xmm9, xmm4
          vpsrld xmm14, xmm9, 19h
          vpslld xmm9, xmm9, 7
          vpor xmm9, xmm9, xmm14
          vpaddd xmm3, xmm13, xmm3
          vpxor xmm12, xmm12, xmm3
          vpshuflw xmm12, xmm12, 0B1h
          vpshufhw xmm12, xmm12, 0B1h
          vpaddd xmm6, xmm12, xmm6
          vpxor xmm13, xmm13, xmm6
          vpsrld xmm14, xmm13, 14h
          vpslld xmm13, xmm13, 0Ch
          vpor xmm13, xmm13, xmm14
          vpaddd xmm3, xmm13, xmm3
          vpshufb xmm12, xmm12, xmm15
          vpshufb xmm14, xmm3, xmm15
          vpxor xmm12, xmm12, xmm14
          vpaddd xmm6, xmm12, xmm6
          vpxor xmm13, xmm13, xmm6
          vpsrld xmm14, xmm13, 19h
          vpslld xmm13, xmm13, 7
          vpor xmm13, xmm13, xmm14
        }
        v304 += 2; /*0x102fff454*/
      }
      while ( v304 < 0x12 ); /*0x102fff45c*/
      __asm /*0x102fff462*/
      {
        vmovdqa xmm15, xmmword ptr [rsp+3C0h+var_200]
        vpaddd xmm8, xmm8, xmm15
        vpaddd xmm1, xmm1, xmmword ptr [rsp+3C0h+var_3C0]
        vpunpckldq xmm14, xmm8, xmm1
        vpunpckhdq xmm1, xmm8, xmm1
        vpaddd xmm2, xmm2, xmmword ptr [rsp+3C0h+var_320]
        vpaddd xmm3, xmm3, xmmword ptr [rsp+3C0h+var_340]
        vpunpckldq xmm8, xmm2, xmm3
        vpunpckhdq xmm2, xmm2, xmm3
        vpunpcklqdq xmm3, xmm14, xmm8
        vpunpckhqdq xmm8, xmm14, xmm8
        vpxor xmm3, xmm3, xmmword ptr [rsi]
        vmovdqu xmmword ptr [rdx], xmm3
        vpxor xmm3, xmm8, xmmword ptr [rsi+40h]
        vpunpcklqdq xmm8, xmm1, xmm2
        vpunpckhqdq xmm1, xmm1, xmm2
        vmovdqu xmmword ptr [rdx+40h], xmm3
        vpxor xmm2, xmm8, xmmword ptr [rsi+80h]
        vmovdqa xmm14, xmm15
        vmovdqu xmmword ptr [rdx+80h], xmm2
        vpxor xmm1, xmm1, xmmword ptr [rsi+0C0h]
        vmovdqu xmmword ptr [rdx+0C0h], xmm1
        vpaddd xmm1, xmm13, xmmword ptr [rsp+3C0h+var_2C0]
        vmovdqa xmm15, xmmword ptr [rsp+3C0h+var_220]
        vpaddd xmm2, xmm15, xmm5
        vmovdqa xmm8, xmmword ptr [rsp+3C0h+var_240]
        vpaddd xmm3, xmm8, xmm7
        vmovdqa xmm7, xmmword ptr [rsp+3C0h+var_260]
        vpaddd xmm5, xmm9, xmm7
        vmovdqa xmm9, xmm7
        vpunpckldq xmm7, xmm1, xmm2
        vpunpckhdq xmm1, xmm1, xmm2
        vpunpckldq xmm2, xmm3, xmm5
        vpunpckhdq xmm3, xmm3, xmm5
        vpunpcklqdq xmm5, xmm7, xmm2
        vpunpckhqdq xmm2, xmm7, xmm2
        vmovdqa xmm7, xmm8
        vpxor xmm5, xmm5, xmmword ptr [rsi+10h]
        vmovdqu xmmword ptr [rdx+10h], xmm5
        vpunpcklqdq xmm5, xmm1, xmm3
        vpxor xmm2, xmm2, xmmword ptr [rsi+50h]
        vpunpckhqdq xmm1, xmm1, xmm3
        vmovdqu xmmword ptr [rdx+50h], xmm2
        vpxor xmm2, xmm5, xmmword ptr [rsi+90h]
        vmovdqu xmmword ptr [rdx+90h], xmm2
        vpxor xmm1, xmm1, xmmword ptr [rsi+0D0h]
        vmovdqu xmmword ptr [rdx+0D0h], xmm1
        vmovdqa xmm3, xmmword ptr [rsp+3C0h+var_280]
        vpaddd xmm1, xmm4, xmm3
        vmovdqa xmm8, xmmword ptr [rsp+3C0h+var_2A0]
        vpaddd xmm2, xmm8, xmm6
        vmovdqa xmm6, xmm3
        vmovdqa xmm3, xmmword ptr [rsp+3C0h+var_2E0]
        vpaddd xmm3, xmm3, xmmword ptr [rsp+3C0h+var_380]
        vmovdqa xmm5, xmmword ptr [rsp+3C0h+var_180]
        vpaddd xmm4, xmm11, xmm5
        vmovdqa xmm11, xmm5
        vpunpckldq xmm5, xmm1, xmm2
        vpunpckhdq xmm1, xmm1, xmm2
        vpunpckldq xmm2, xmm3, xmm4
        vpunpckhdq xmm3, xmm3, xmm4
        vpunpcklqdq xmm4, xmm5, xmm2
        vpunpckhqdq xmm2, xmm5, xmm2
        vmovdqa xmm13, xmmword ptr [rsp+3C0h+var_340]
        vpxor xmm4, xmm4, xmmword ptr [rsi+20h]
        vmovdqu xmmword ptr [rdx+20h], xmm4
        vpunpcklqdq xmm4, xmm1, xmm3
        vpxor xmm2, xmm2, xmmword ptr [rsi+60h]
        vpunpckhqdq xmm1, xmm1, xmm3
        vmovdqu xmmword ptr [rdx+60h], xmm2
        vpxor xmm2, xmm4, xmmword ptr [rsi+0A0h]
        vmovdqu xmmword ptr [rdx+0A0h], xmm2
        vpxor xmm1, xmm1, xmmword ptr [rsi+0E0h]
        vmovdqu xmmword ptr [rdx+0E0h], xmm1
        vpaddd xmm1, xmm10, xmmword ptr [rsp+3C0h+var_160]
        vmovdqa xmm10, xmm14
        vpaddd xmm0, xmm0, xmmword ptr [rsp+3C0h+var_1E0]
        vmovdqa xmm3, xmmword ptr [rsp+3C0h+var_1C0]
        vpaddd xmm2, xmm12, xmm3
        vmovdqa xmm14, xmmword ptr [rsp+3C0h+var_1A0]
        vpaddd xmm3, xmm14, xmmword ptr [rsp+3C0h+var_360]
        vpunpckldq xmm4, xmm1, xmm0
        vpunpckhdq xmm0, xmm1, xmm0
        vpunpckldq xmm1, xmm2, xmm3
        vpunpckhdq xmm2, xmm2, xmm3
        vpunpcklqdq xmm3, xmm4, xmm1
        vpunpckhqdq xmm1, xmm4, xmm1
        vmovdqa xmm4, xmmword ptr [rsp+3C0h+var_320]
        vpxor xmm3, xmm3, xmmword ptr [rsi+30h]
        vmovdqu xmmword ptr [rdx+30h], xmm3
        vpunpcklqdq xmm3, xmm0, xmm2
        vpxor xmm1, xmm1, xmmword ptr [rsi+70h]
        vpunpckhqdq xmm0, xmm0, xmm2
        vmovdqu xmmword ptr [rdx+70h], xmm1
        vpxor xmm1, xmm3, xmmword ptr [rsi+0B0h]
        vmovdqa xmm3, xmmword ptr [rsp+3C0h+var_3C0]
        vmovdqu xmmword ptr [rdx+0B0h], xmm1
        vpxor xmm0, xmm0, xmmword ptr [rsi+0F0h]
        vmovdqu xmmword ptr [rdx+0F0h], xmm0
      }
      a4 -= 256LL; /*0x102fff69c*/
      _RDX += 256; /*0x102fff6a3*/
      a2 += 256; /*0x102fff6a6*/
    }
    while ( a4 > 0xFF ); /*0x102fff6b0*/
  }
  if ( a4 >= 0x40 ) /*0x102fff6ba*/
  {
    __asm /*0x102fff6c0*/
    {
      vmovdqa xmm0, cs:xmmword_1094BA1B0
      vmovdqa xmm1, cs:xmmword_1094BA1C0
    }
    do /*0x102fff81f*/
    {
      __asm /*0x102fff6d0*/
      {
        vmovdqu xmm2, xmmword ptr [rdi]
        vmovdqu xmm3, xmmword ptr [rdi+10h]
        vmovdqu xmm4, xmmword ptr [rdi+20h]
        vmovdqu xmm5, xmmword ptr [rdi+30h]
      }
      v532 = -2; /*0x102fff6e3*/
      __asm /*0x102fff6e8*/
      {
        vmovdqa xmm6, xmm5
        vmovdqa xmm7, xmm4
        vmovdqa xmm9, xmm3
        vmovdqa xmm8, xmm2
      }
      do /*0x102fff7cb*/
      {
        __asm /*0x102fff6f8*/
        {
          vpaddd xmm8, xmm9, xmm8
          vpxor xmm6, xmm8, xmm6
          vpshuflw xmm6, xmm6, 0B1h
          vpshufhw xmm6, xmm6, 0B1h
          vpaddd xmm7, xmm7, xmm6
          vpxor xmm9, xmm9, xmm7
          vpsrld xmm10, xmm9, 14h
          vpslld xmm9, xmm9, 0Ch
          vpor xmm9, xmm9, xmm10
          vpaddd xmm8, xmm9, xmm8
          vpshufd xmm10, xmm8, 93h
          vpshufb xmm8, xmm8, xmm0
          vpshufb xmm6, xmm6, xmm0
          vpxor xmm6, xmm8, xmm6
          vpaddd xmm7, xmm7, xmm6
          vpxor xmm8, xmm9, xmm7
          vpshufd xmm7, xmm7, 39h ; '9'
          vpsrld xmm9, xmm8, 19h
          vpslld xmm8, xmm8, 7
          vpor xmm8, xmm8, xmm9
          vpaddd xmm9, xmm8, xmm10
          vpshuflw xmm10, xmm9, 0B1h
          vpshufhw xmm10, xmm10, 0B1h
          vpshufb xmm6, xmm6, xmm1
          vpxor xmm6, xmm10, xmm6
          vpaddd xmm7, xmm7, xmm6
          vpxor xmm8, xmm8, xmm7
          vpsrld xmm10, xmm8, 14h
          vpslld xmm8, xmm8, 0Ch
          vpor xmm10, xmm8, xmm10
          vpaddd xmm9, xmm10, xmm9
          vpshufd xmm8, xmm9, 39h ; '9'
          vpxor xmm6, xmm9, xmm6
          vpshufb xmm6, xmm6, xmm0
          vpaddd xmm7, xmm7, xmm6
          vpshufd xmm6, xmm6, 4Eh ; 'N'
          vpxor xmm9, xmm10, xmm7
          vpshufd xmm7, xmm7, 93h
          vpsrld xmm10, xmm9, 19h
          vpslld xmm9, xmm9, 7
          vpor xmm9, xmm9, xmm10
        }
        v532 += 2; /*0x102fff7c5*/
      }
      while ( v532 < 0x12 ); /*0x102fff7cb*/
      __asm /*0x102fff7d1*/
      {
        vpaddd xmm2, xmm8, xmm2
        vpaddd xmm3, xmm9, xmm3
        vpaddd xmm4, xmm7, xmm4
        vpaddd xmm5, xmm6, xmm5
        vpxor xmm2, xmm2, xmmword ptr [rsi]
        vpxor xmm3, xmm3, xmmword ptr [rsi+10h]
        vpxor xmm4, xmm4, xmmword ptr [rsi+20h]
        vpxor xmm5, xmm5, xmmword ptr [rsi+30h]
        vmovdqu xmmword ptr [rdx], xmm2
        vmovdqu xmmword ptr [rdx+10h], xmm3
        vmovdqu xmmword ptr [rdx+20h], xmm4
        vmovdqu xmmword ptr [rdx+30h], xmm5
      }
      ++*(_QWORD *)(_RDI + 48); /*0x102fff807*/
      a4 -= 64LL; /*0x102fff80f*/
      _RDX += 64; /*0x102fff813*/
      a2 += 64; /*0x102fff817*/
    }
    while ( a4 > 0x3F ); /*0x102fff81f*/
  }
  if ( a4 != 0 ) /*0x102fff828*/
  {
    __asm /*0x102fff82e*/
    {
      vmovdqu xmm0, xmmword ptr [rdi]
      vmovdqu xmm1, xmmword ptr [rdi+10h]
      vmovdqu xmm2, xmmword ptr [rdi+20h]
      vmovdqu xmm3, xmmword ptr [rdi+30h]
    }
    v588 = -2; /*0x102fff841*/
    __asm /*0x102fff846*/
    {
      vmovdqa xmm4, cs:xmmword_1094BA1B0
      vmovdqa xmm5, cs:xmmword_1094BA1C0
      vmovdqa xmm6, xmm3
      vmovdqa xmm7, xmm2
      vmovdqa xmm9, xmm1
      vmovdqa xmm8, xmm0
    }
    do /*0x102fff939*/
    {
      __asm /*0x102fff866*/
      {
        vpaddd xmm8, xmm9, xmm8
        vpxor xmm6, xmm8, xmm6
        vpshuflw xmm6, xmm6, 0B1h
        vpshufhw xmm6, xmm6, 0B1h
        vpaddd xmm7, xmm7, xmm6
        vpxor xmm9, xmm9, xmm7
        vpsrld xmm10, xmm9, 14h
        vpslld xmm9, xmm9, 0Ch
        vpor xmm9, xmm9, xmm10
        vpaddd xmm8, xmm9, xmm8
        vpshufd xmm10, xmm8, 93h
        vpshufb xmm8, xmm8, xmm4
        vpshufb xmm6, xmm6, xmm4
        vpxor xmm6, xmm8, xmm6
        vpaddd xmm7, xmm7, xmm6
        vpxor xmm8, xmm9, xmm7
        vpshufd xmm7, xmm7, 39h ; '9'
        vpsrld xmm9, xmm8, 19h
        vpslld xmm8, xmm8, 7
        vpor xmm8, xmm8, xmm9
        vpaddd xmm9, xmm8, xmm10
        vpshuflw xmm10, xmm9, 0B1h
        vpshufhw xmm10, xmm10, 0B1h
        vpshufb xmm6, xmm6, xmm5
        vpxor xmm6, xmm10, xmm6
        vpaddd xmm7, xmm7, xmm6
        vpxor xmm8, xmm8, xmm7
        vpsrld xmm10, xmm8, 14h
        vpslld xmm8, xmm8, 0Ch
        vpor xmm10, xmm8, xmm10
        vpaddd xmm9, xmm10, xmm9
        vpshufd xmm8, xmm9, 39h ; '9'
        vpxor xmm6, xmm9, xmm6
        vpshufb xmm6, xmm6, xmm4
        vpaddd xmm7, xmm7, xmm6
        vpshufd xmm6, xmm6, 4Eh ; 'N'
        vpxor xmm9, xmm10, xmm7
        vpshufd xmm7, xmm7, 93h
        vpsrld xmm10, xmm9, 19h
        vpslld xmm9, xmm9, 7
        vpor xmm9, xmm9, xmm10
      }
      v588 += 2; /*0x102fff933*/
    }
    while ( v588 < 0x12 ); /*0x102fff939*/
    __asm /*0x102fff93f*/
    {
      vpaddd xmm0, xmm8, xmm0
      vpaddd xmm1, xmm9, xmm1
      vpaddd xmm2, xmm7, xmm2
      vpaddd xmm3, xmm6, xmm3
      vmovdqa [rsp+3C0h+var_60], xmm0
      vmovdqa [rsp+3C0h+var_50], xmm1
      vmovdqa [rsp+3C0h+var_40], xmm2
      vmovdqa [rsp+3C0h+var_30], xmm3
    }
    for ( i = 0; i != a4; ++i ) /*0x102fff973*/
      *(_BYTE *)(_RDX + i) = *(_BYTE *)(a2 + i) ^ *((_BYTE *)v697 + i); /*0x102fff981*/
    __asm { vzeroupper } /*0x102fff99a*/
    sodium_memzero(a1: v697, a2: 64); /*0x102fff99d*/
  }
  result = __stack_chk_guard; /*0x102fff9a9*/
  if ( __stack_chk_guard != v698 ) /*0x102fff9b4*/
    __asm { vzeroupper } /*0x102fff9be*/
  __asm { vzeroupper } /*0x102fff9ba*/
  return result; /*0x102fff9bd*/
}

// Address: 0x10300275f | Name: _crypto_aead_aes256gcm_beforenm
__int64 __fastcall crypto_aead_aes256gcm_beforenm(__int64 _RDI, __int64 _RSI)
{
  __int64 i; // rax

  __asm /*0x10300275f*/
  {
    vmovdqu xmm0, xmmword ptr [rsi]
    vmovdqu xmm1, xmmword ptr [rsi+10h]
    vmovdqa xmmword ptr [rdi], xmm0
    vmovdqa xmmword ptr [rdi+10h], xmm1
    vaeskeygenassist xmm2, xmm1, 1
    vpslldq xmm3, xmm0, 4
    vpxor xmm3, xmm0, xmm3
    vpslldq xmm4, xmm3, 8
    vpshufd xmm2, xmm2, 0FFh
    vpxor xmm3, xmm4, xmm3
    vpxor xmm2, xmm3, xmm2
    vmovdqa xmmword ptr [rdi+20h], xmm2
    vaeskeygenassist xmm3, xmm2, 1
    vpslldq xmm4, xmm1, 4
    vpxor xmm1, xmm1, xmm4
    vpslldq xmm4, xmm1, 8
    vpshufd xmm3, xmm3, 0AAh
    vpxor xmm1, xmm4, xmm1
    vpxor xmm1, xmm1, xmm3
    vmovdqa xmmword ptr [rdi+30h], xmm1
    vaeskeygenassist xmm3, xmm1, 2
    vpslldq xmm4, xmm2, 4
    vpxor xmm2, xmm2, xmm4
    vpslldq xmm4, xmm2, 8
    vpshufd xmm3, xmm3, 0FFh
    vpxor xmm2, xmm4, xmm2
    vpxor xmm2, xmm2, xmm3
    vmovdqa xmmword ptr [rdi+40h], xmm2
    vaeskeygenassist xmm3, xmm2, 2
    vpslldq xmm4, xmm1, 4
    vpxor xmm1, xmm1, xmm4
    vpslldq xmm4, xmm1, 8
    vpshufd xmm3, xmm3, 0AAh
    vpxor xmm1, xmm4, xmm1
    vpxor xmm1, xmm1, xmm3
    vmovdqa xmmword ptr [rdi+50h], xmm1
    vaeskeygenassist xmm3, xmm1, 4
    vpslldq xmm4, xmm2, 4
    vpxor xmm2, xmm2, xmm4
    vpslldq xmm4, xmm2, 8
    vpshufd xmm3, xmm3, 0FFh
    vpxor xmm2, xmm4, xmm2
    vpxor xmm2, xmm2, xmm3
    vmovdqa xmmword ptr [rdi+60h], xmm2
    vaeskeygenassist xmm3, xmm2, 4
    vpslldq xmm4, xmm1, 4
    vpxor xmm1, xmm1, xmm4
    vpslldq xmm4, xmm1, 8
    vpshufd xmm3, xmm3, 0AAh
    vpxor xmm1, xmm4, xmm1
    vpxor xmm1, xmm1, xmm3
    vmovdqa xmmword ptr [rdi+70h], xmm1
    vaeskeygenassist xmm3, xmm1, 8
    vpslldq xmm4, xmm2, 4
    vpxor xmm2, xmm2, xmm4
    vpslldq xmm4, xmm2, 8
    vpshufd xmm3, xmm3, 0FFh
    vpxor xmm2, xmm4, xmm2
    vpxor xmm2, xmm2, xmm3
    vmovdqa xmmword ptr [rdi+80h], xmm2
    vaeskeygenassist xmm3, xmm2, 8
    vpslldq xmm4, xmm1, 4
    vpxor xmm1, xmm1, xmm4
    vpslldq xmm4, xmm1, 8
    vpshufd xmm3, xmm3, 0AAh
    vpxor xmm1, xmm4, xmm1
    vpxor xmm1, xmm1, xmm3
    vmovdqa xmmword ptr [rdi+90h], xmm1
    vaeskeygenassist xmm3, xmm1, 10h
    vpslldq xmm4, xmm2, 4
    vpxor xmm2, xmm2, xmm4
    vpslldq xmm4, xmm2, 8
    vpshufd xmm3, xmm3, 0FFh
    vpxor xmm2, xmm4, xmm2
    vpxor xmm2, xmm2, xmm3
    vmovdqa xmmword ptr [rdi+0A0h], xmm2
    vaeskeygenassist xmm3, xmm2, 10h
    vpslldq xmm4, xmm1, 4
    vpxor xmm1, xmm1, xmm4
    vpslldq xmm4, xmm1, 8
    vpshufd xmm3, xmm3, 0AAh
    vpxor xmm1, xmm4, xmm1
    vpxor xmm1, xmm1, xmm3
    vmovdqa xmmword ptr [rdi+0B0h], xmm1
    vaeskeygenassist xmm3, xmm1, 20h ; ' '
    vpslldq xmm4, xmm2, 4
    vpxor xmm2, xmm2, xmm4
    vpslldq xmm4, xmm2, 8
    vpshufd xmm3, xmm3, 0FFh
    vpxor xmm2, xmm4, xmm2
    vpxor xmm2, xmm2, xmm3
    vmovdqa xmmword ptr [rdi+0C0h], xmm2
    vaeskeygenassist xmm3, xmm2, 20h ; ' '
    vpslldq xmm4, xmm1, 4
    vpxor xmm1, xmm1, xmm4
    vpslldq xmm4, xmm1, 8
    vpshufd xmm3, xmm3, 0AAh
    vpxor xmm1, xmm4, xmm1
    vpxor xmm1, xmm1, xmm3
    vmovdqa xmmword ptr [rdi+0D0h], xmm1
    vaeskeygenassist xmm1, xmm1, 40h ; '@'
    vpslldq xmm3, xmm2, 4
    vpxor xmm2, xmm2, xmm3
    vpslldq xmm3, xmm2, 8
    vpshufd xmm1, xmm1, 0FFh
    vpxor xmm2, xmm3, xmm2
    vpxor xmm1, xmm2, xmm1
    vmovdqa xmmword ptr [rdi+0E0h], xmm1
  }
  for ( i = 16; i != 224; i += 16 ) /*0x103002974*/
    __asm { vaesenc xmm0, xmm0, xmmword ptr [rdi+rax] } /*0x103002979*/
  __asm /*0x10300298f*/
  {
    vaesenclast xmm0, xmm0, xmm1
    vpshufb xmm0, xmm0, cs:xmmword_1094BA2A0
    vpxor xmm1, xmm1, xmm1
    vpcmpgtq xmm1, xmm1, xmm0
    vpshufd xmm1, xmm1, 0FFh
    vpand xmm1, xmm1, cs:xmmword_1094BA2B0
    vpslldq xmm2, xmm0, 8
    vpsrlq xmm2, xmm2, 3Fh ; '?'
    vpaddq xmm0, xmm0, xmm0
    vpor xmm0, xmm0, xmm2
    vpxor xmm0, xmm1, xmm0
    vmovdqa xmmword ptr [rdi+0F0h], xmm0
    vpclmulqdq xmm2, xmm0, xmm0, 0
    vpclmulqdq xmm3, xmm0, xmm0, 11h
  }
  _RAX = 0xC200000000000000LL; /*0x1030029dd*/
  __asm /*0x1030029e7*/
  {
    vmovq xmm1, rax
    vpclmulqdq xmm4, xmm2, xmm1, 0
    vpshufd xmm2, xmm2, 4Eh ; 'N'
    vpxor xmm2, xmm4, xmm2
    vpclmulqdq xmm4, xmm2, xmm1, 0
    vpshufd xmm2, xmm2, 4Eh ; 'N'
    vpxor xmm2, xmm3, xmm2
    vpxor xmm2, xmm4, xmm2
    vmovdqa xmmword ptr [rdi+100h], xmm2
  }
  _RAX = _RDI + 288; /*0x103002a16*/
  for ( _RCX = 0; _RCX < 0xC; _RCX += 2LL ) /*0x103002a1d*/
  {
    __asm /*0x103002a1f*/
    {
      vmovdqa xmm2, xmmword ptr [rax-20h]
      vpclmulqdq xmm3, xmm2, xmm0, 11h
      vpclmulqdq xmm4, xmm2, xmm0, 0
      vpclmulqdq xmm5, xmm2, xmm0, 1
      vpclmulqdq xmm2, xmm2, xmm0, 10h
      vpxor xmm2, xmm2, xmm5
      vpsrldq xmm5, xmm2, 8
      vpxor xmm3, xmm3, xmm5
      vpslldq xmm2, xmm2, 8
      vpxor xmm2, xmm4, xmm2
      vpclmulqdq xmm4, xmm2, xmm1, 0
      vpshufd xmm2, xmm2, 4Eh ; 'N'
      vpxor xmm2, xmm4, xmm2
      vpclmulqdq xmm4, xmm2, xmm1, 0
      vpshufd xmm2, xmm2, 4Eh ; 'N'
      vpxor xmm2, xmm3, xmm2
      vpxor xmm2, xmm4, xmm2
      vmovdqa xmmword ptr [rax-10h], xmm2
      vmovdqa xmm2, xmmword ptr [rdi+rcx*8+100h]
      vpclmulqdq xmm3, xmm2, xmm2, 0
      vpclmulqdq xmm2, xmm2, xmm2, 11h
      vpclmulqdq xmm4, xmm3, xmm1, 0
      vpshufd xmm3, xmm3, 4Eh ; 'N'
      vpxor xmm3, xmm4, xmm3
      vpclmulqdq xmm4, xmm3, xmm1, 0
      vpshufd xmm3, xmm3, 4Eh ; 'N'
      vpxor xmm2, xmm2, xmm3
      vpxor xmm2, xmm4, xmm2
      vmovdqa xmmword ptr [rax], xmm2
    }
    _RAX += 32; /*0x103002ab8*/
  }
  return 0; /*0x103002ac9*/
}

// Address: 0x103002aca | Name: _crypto_aead_aes256gcm_encrypt_detached_afternm
__int64 __fastcall crypto_aead_aes256gcm_encrypt_detached_afternm(
        __int64 a1,
        __int64 _RSI,
        _QWORD *a3,
        __int64 a4,
        unsigned __int64 a5,
        __int64 a6,
        __m128 _XMM0,
        unsigned __int64 a8,
        int a9,
        __int64 a10,
        __int64 a11)
{
  __int64 i; // rax
  __int64 result; // rax
  __int64 v73; // rcx
  __int64 v74; // rdi
  __int64 v75; // rsi
  __int64 v78; // r10
  __int64 j; // rdx
  const char *v90; // r10
  __int64 k; // rdx
  __int64 m; // rcx
  __int64 v225; // r8
  __int64 v228; // rdx
  __int64 n; // r8
  __int64 v318; // rdi
  __int64 ii; // r8
  __int64 jj; // r10
  __int64 v367; // rdx
  __int64 v373; // rcx
  char v378; // si
  __int64 kk; // r8
  bool v385; // zf
  __int64 v416; // rcx
  __int64 v421; // rbx
  __int64 mm; // rcx
  __int64 v451; // rax
  const void *v474; // rsi
  unsigned __int64 v475; // r14
  __int64 nn; // rax
  size_t v484; // rdx
  _QWORD *v521; // [rsp+8h] [rbp-158h]
  __int64 v523; // [rsp+28h] [rbp-138h]
  __int128 v524; // [rsp+30h] [rbp-130h]
  __int128 v525; // [rsp+40h] [rbp-120h] BYREF
  __m256 __dst; // [rsp+C0h] [rbp-A0h] BYREF
  __int64 v530; // [rsp+130h] [rbp-30h]

  _R12 = a5; /*0x103002ae1*/
  _R15 = a1; /*0x103002ae7*/
  if ( a3 != nullptr ) /*0x103002afb*/
    *a3 = 0; /*0x103002afd*/
  if ( a5 > 0xFFFFFFFFFFFFFF1FLL /*0x103002b52*/
    || a8 > 0xFFFFFFFFFFFFFF1FLL
    || (a8 + 15) >> 4 > a8
    || a5 > 0xFFFFFFFD0LL
    || (a5 + 15) >> 4 > a5 )
  {
    __asm /*0x103002dcd*/
    {
      vbroadcastss xmm0, cs:dword_1094BA308
      vmovdqu xmmword ptr [rsi], xmm0
    }
    __bzero(a1, a2: a5); /*0x103002de0*/
    result = 0xFFFFFFFFLL; /*0x103002de5*/
  }
  else
  {
    v523 = _RSI; /*0x103002b58*/
    v521 = a3; /*0x103002b5f*/
    _R13 = a11; /*0x103002b66*/
    _RAX = a10; /*0x103002b6a*/
    __asm /*0x103002b6e*/
    {
      vxorps xmm0, xmm0, xmm0
      vmovaps [rbp+var_120], xmm0
      vmovq xmm0, qword ptr [rax]
      vpinsrd xmm0, xmm0, dword ptr [rax+8], 2
      vpblendw xmm11, xmm0, cs:xmmword_1094BA2C0, 0C0h
    }
    _R11 = 0xC200000000000000LL; /*0x103002b9b*/
    if ( a8 != 0 && a6 != 0 ) /*0x103002b92*/
    {
      __asm { vmovdqa [rbp+var_130], xmm11 } /*0x103002bc1*/
      gh_ad_blocks(a1: a11, a2: &v525, a3: a6, a4: a8 & 0xFFFFFFFFFFFFFFF0LL); /*0x103002bc9*/
      __asm { vmovdqa xmm11, [rbp+var_130] } /*0x103002bd2*/
      _R11 = 0xC200000000000000LL; /*0x103002bda*/
      if ( (a8 & 0xF) != 0 ) /*0x103002beb*/
      {
        __asm { vpxor xmm0, xmm0, xmm0 } /*0x103002bf1*/
        _RCX = &__dst; /*0x103002bf5*/
        __asm { vmovdqa xmmword ptr [rcx], xmm0 } /*0x103002bfc*/
        __memcpy_chk(a1: &__dst, a2: a8 + a6 - (a8 & 0xF), a3: a8 & 0xF, a4: 16); /*0x103002c11*/
        __asm { vmovdqa xmm11, [rbp+var_130] } /*0x103002c16*/
        _R11 = 0xC200000000000000LL; /*0x103002c1e*/
        __asm { vmovdqa xmm0, xmmword ptr [r13+0F0h] } /*0x103002c28*/
        _RAX = &__dst; /*0x103002c31*/
        __asm /*0x103002c38*/
        {
          vmovdqa xmm1, xmmword ptr [rax]
          vpshufb xmm1, xmm1, cs:xmmword_1094BA2A0
          vpxor xmm1, xmm1, [rbp+var_120]
          vpclmulqdq xmm2, xmm1, xmm0, 11h
          vpclmulqdq xmm3, xmm1, xmm0, 0
          vpclmulqdq xmm4, xmm1, xmm0, 1
          vpclmulqdq xmm0, xmm1, xmm0, 10h
          vpxor xmm0, xmm0, xmm4
          vpsrldq xmm1, xmm0, 8
          vpxor xmm1, xmm2, xmm1
          vpslldq xmm0, xmm0, 8
          vpxor xmm0, xmm3, xmm0
          vmovq xmm2, r11
          vpclmulqdq xmm3, xmm0, xmm2, 0
          vpshufd xmm0, xmm0, 4Eh ; 'N'
          vpxor xmm0, xmm3, xmm0
          vpclmulqdq xmm2, xmm0, xmm2, 0
          vpshufd xmm0, xmm0, 4Eh ; 'N'
          vpxor xmm0, xmm1, xmm0
          vpxor xmm0, xmm2, xmm0
          vmovdqa [rbp+var_120], xmm0
        }
      }
    }
    __asm { vpshufb xmm12, xmm11, cs:xmmword_1094BA2A0 } /*0x103002caa*/
    _RAX = 0; /*0x103002cb3*/
    if ( _R12 >= 0xE0 ) /*0x103002cbc*/
    {
      __asm /*0x103002cc2*/
      {
        vmovdqa xmm0, cs:xmmword_1094BA2A0
        vpmovsxbq xmm1, cs:word_1094BA300
      }
      do /*0x103002ced*/
      {
        __asm /*0x103002cd3*/
        {
          vpshufb xmm2, xmm12, xmm0
          vmovdqa [rbp+rax+var_110], xmm2
          vpaddq xmm12, xmm12, xmm1
        }
        _RAX += 16; /*0x103002ce5*/
      }
      while ( _RAX != 112 ); /*0x103002ced*/
      __asm { vmovdqa xmm2, xmmword ptr [r13+0] } /*0x103002cef*/
      for ( _RAX = 0; _RAX != 112; _RAX += 16 ) /*0x103002cf5*/
      {
        __asm /*0x103002cf7*/
        {
          vpxor xmm3, xmm2, [rbp+rax+var_110]
          vmovdqa xmmword ptr [rbp+rax+__dst], xmm3
        }
      }
      for ( i = 1; i != 14; ++i ) /*0x103002d13*/
      {
        _RCX = 16 * i; /*0x103002d1b*/
        __asm { vmovdqa xmm2, xmmword ptr [r13+rcx+0] } /*0x103002d1f*/
        for ( _RCX = 0; _RCX != 112; _RCX += 16 ) /*0x103002d26*/
        {
          __asm /*0x103002d28*/
          {
            vmovdqa xmm3, xmmword ptr [rbp+rcx+__dst]
            vaesenc xmm3, xmm3, xmm2
            vmovdqa xmmword ptr [rbp+rcx+__dst], xmm3
          }
        }
      }
      __asm { vmovdqa xmm2, xmmword ptr [r13+0E0h] } /*0x103002d52*/
      for ( _RAX = 0; _RAX != 112; _RAX += 16 ) /*0x103002d5b*/
      {
        __asm /*0x103002d5d*/
        {
          vmovdqa xmm3, xmmword ptr [rbp+rax+__dst]
          vaesenclast xmm3, xmm3, xmm2
          vpxor xmm3, xmm3, xmmword ptr [r14+rax]
          vmovdqa xmmword ptr [rbp+rax+__dst], xmm3
        }
      }
      __asm /*0x103002d84*/
      {
        vmovups ymm2, [rbp+__dst]
        vmovdqu ymm3, [rbp+var_80]
        vmovdqu ymm4, ymmword ptr [rbp+var_60]
        vmovdqu ymm5, ymmword ptr [rbp+var_60+10h]
        vmovdqu ymmword ptr [r15+50h], ymm5
        vmovdqu ymmword ptr [r15+40h], ymm4
        vmovdqu ymmword ptr [r15+20h], ymm3
        vmovups ymmword ptr [r15], ymm2
      }
      if ( _R12 > 0x14F ) /*0x103002db9*/
      {
        __asm { vmovdqa xmm2, [rbp+var_120] } /*0x103002e13*/
        v73 = a4 + 112; /*0x103002e1b*/
        v74 = _R15 + 16; /*0x103002e1f*/
        v75 = a4 + 224; /*0x103002e23*/
        *(_QWORD *)&v524 = a11 + 336; /*0x103002e31*/
        _R8 = _R15 + 112; /*0x103002e38*/
        _RBX = 112; /*0x103002e3c*/
        v78 = 336; /*0x103002e41*/
        do /*0x103003176*/
        {
          _RAX = v78; /*0x103002e4d*/
          for ( _RDX = 0; _RDX != 112; _RDX += 16 ) /*0x103002e50*/
          {
            __asm /*0x103002e52*/
            {
              vpshufb xmm3, xmm12, xmm0
              vmovdqa [rbp+rdx+var_110], xmm3
              vpaddq xmm12, xmm12, xmm1
            }
          }
          __asm { vmovdqa xmm3, xmmword ptr [r13+0] } /*0x103002e6e*/
          for ( _RDX = 0; _RDX != 112; _RDX += 16 ) /*0x103002e74*/
          {
            __asm /*0x103002e76*/
            {
              vpxor xmm4, xmm3, [rbp+rdx+var_110]
              vmovdqa xmmword ptr [rbp+rdx+__dst], xmm4
            }
          }
          for ( j = 1; j != 14; ++j ) /*0x103002e92*/
          {
            _R10 = 16 * j; /*0x103002e9a*/
            __asm { vmovdqa xmm3, xmmword ptr [r13+r10+0] } /*0x103002e9e*/
            for ( _R10 = 0; _R10 != 112; _R10 += 16 ) /*0x103002ea5*/
            {
              __asm /*0x103002ea8*/
              {
                vmovdqa xmm4, xmmword ptr [rbp+r10+__dst]
                vaesenc xmm4, xmm4, xmm3
                vmovdqa xmmword ptr [rbp+r10+__dst], xmm4
              }
            }
          }
          v90 = (const char *)(a4 + _RBX); /*0x103002ed4*/
          __asm { vmovdqa xmm3, xmmword ptr [r13+0E0h] } /*0x103002ed8*/
          for ( _RDX = 0; _RDX != 112; _RDX += 16 ) /*0x103002ee1*/
          {
            __asm /*0x103002ee3*/
            {
              vmovdqa xmm4, xmmword ptr [rbp+rdx+__dst]
              vaesenclast xmm4, xmm4, xmm3
              vpxor xmm4, xmm4, xmmword ptr [rcx+rdx]
              vmovdqa xmmword ptr [rbp+rdx+__dst], xmm4
            }
          }
          _R11 = _R15 + _RBX; /*0x103002f09*/
          __asm /*0x103002f0d*/
          {
            vmovups ymm3, [rbp+__dst]
            vmovups ymm4, [rbp+var_80]
            vmovups ymm5, ymmword ptr [rbp+var_60]
            vmovups ymm6, ymmword ptr [rbp+var_60+10h]
            vmovups ymmword ptr [r15+rbx+50h], ymm6
            vmovups ymmword ptr [r15+rbx+40h], ymm5
            vmovups ymmword ptr [r15+rbx+20h], ymm4
            vmovups ymmword ptr [r15+rbx], ymm3
          }
          _mm_prefetch(v90 + 112, 2); /*0x103002f3f*/
          _mm_prefetch(v90 + 176, 2); /*0x103002f44*/
          __asm /*0x103002f4c*/
          {
            vmovdqa xmm4, xmmword ptr [r13+1C0h]
            vmovdqu xmm3, xmmword ptr [r15+rbx-70h]
            vpshufb xmm3, xmm3, xmm0
            vpxor xmm5, xmm2, xmm3
            vpclmulqdq xmm2, xmm5, xmm4, 11h
            vpclmulqdq xmm3, xmm5, xmm4, 0
            vpclmulqdq xmm6, xmm5, xmm4, 1
            vpclmulqdq xmm4, xmm5, xmm4, 10h
            vpxor xmm4, xmm4, xmm6
          }
          _RBX = 432; /*0x103002f81*/
          _RDX = v74; /*0x103002f86*/
          do /*0x103002fd0*/
          {
            __asm /*0x103002f89*/
            {
              vmovdqa xmm5, xmmword ptr [r13+rbx+0]
              vmovdqu xmm6, xmmword ptr [rdx]
              vpshufb xmm6, xmm6, xmm0
              vpclmulqdq xmm7, xmm6, xmm5, 11h
              vpxor xmm2, xmm7, xmm2
              vpclmulqdq xmm7, xmm6, xmm5, 0
              vpxor xmm3, xmm7, xmm3
              vpclmulqdq xmm7, xmm6, xmm5, 1
              vpxor xmm4, xmm7, xmm4
              vpclmulqdq xmm5, xmm6, xmm5, 10h
              vpxor xmm4, xmm4, xmm5
            }
            _RBX -= 16; /*0x103002fc1*/
            _RDX += 16; /*0x103002fc5*/
          }
          while ( _RBX != 336 ); /*0x103002fd0*/
          for ( _RDX = 0; _RDX != 112; _RDX += 16 ) /*0x103002fd2*/
          {
            __asm /*0x103002fd4*/
            {
              vpshufb xmm5, xmm12, xmm0
              vmovdqa [rbp+rdx+var_110], xmm5
              vpaddq xmm12, xmm12, xmm1
            }
          }
          __asm { vmovdqa xmm5, xmmword ptr [r13+0] } /*0x103002ff0*/
          for ( _RDX = 0; _RDX != 112; _RDX += 16 ) /*0x103002ff6*/
          {
            __asm /*0x103002ff8*/
            {
              vpxor xmm6, xmm5, [rbp+rdx+var_110]
              vmovdqa xmmword ptr [rbp+rdx+__dst], xmm6
            }
          }
          for ( k = 1; k != 14; ++k ) /*0x103003014*/
          {
            _RBX = 16 * k; /*0x10300301c*/
            __asm { vmovdqa xmm5, xmmword ptr [r13+rbx+0] } /*0x103003020*/
            for ( _RBX = 0; _RBX != 112; _RBX += 16 ) /*0x103003027*/
            {
              __asm /*0x103003029*/
              {
                vmovdqa xmm6, xmmword ptr [rbp+rbx+__dst]
                vaesenc xmm6, xmm6, xmm5
                vmovdqa xmmword ptr [rbp+rbx+__dst], xmm6
              }
            }
          }
          __asm { vmovdqa xmm5, xmmword ptr [r13+0E0h] } /*0x103003053*/
          for ( _RDX = 0; _RDX != 112; _RDX += 16 ) /*0x10300305c*/
          {
            __asm /*0x10300305e*/
            {
              vmovdqa xmm6, xmmword ptr [rbp+rdx+__dst]
              vaesenclast xmm6, xmm6, xmm5
              vpxor xmm6, xmm6, xmmword ptr [rsi+rdx]
              vmovdqa xmmword ptr [rbp+rdx+__dst], xmm6
            }
          }
          __asm /*0x103003084*/
          {
            vmovups ymm5, [rbp+__dst]
            vmovups ymm6, [rbp+var_80]
            vmovups ymm7, ymmword ptr [rbp+var_60]
            vmovdqu ymm8, ymmword ptr [rbp+var_60+10h]
            vmovdqu ymmword ptr [r11+0C0h], ymm8
            vmovups ymmword ptr [r11+0B0h], ymm7
            vmovups ymmword ptr [r11+90h], ymm6
            vmovups ymmword ptr [r11+70h], ymm5
          }
          _mm_prefetch(v90 + 224, 2); /*0x1030030bc*/
          _mm_prefetch(v90 + 288, 2); /*0x1030030c4*/
          _RDX = -112; /*0x1030030cc*/
          _R10 = v524; /*0x1030030d3*/
          do /*0x10300311b*/
          {
            __asm /*0x1030030da*/
            {
              vmovdqa xmm5, xmmword ptr [r10]
              vmovdqu xmm6, xmmword ptr [r8+rdx+70h]
              vpshufb xmm6, xmm6, xmm0
              vpclmulqdq xmm7, xmm6, xmm5, 11h
              vpxor xmm2, xmm7, xmm2
              vpclmulqdq xmm7, xmm6, xmm5, 0
              vpxor xmm3, xmm7, xmm3
              vpclmulqdq xmm7, xmm6, xmm5, 1
              vpxor xmm4, xmm7, xmm4
              vpclmulqdq xmm5, xmm6, xmm5, 10h
              vpxor xmm4, xmm4, xmm5
            }
            _R10 -= 16; /*0x103003113*/
            _RDX += 16; /*0x103003117*/
          }
          while ( _RDX != 0 ); /*0x10300311b*/
          __asm /*0x10300311d*/
          {
            vpsrldq xmm5, xmm4, 8
            vpslldq xmm4, xmm4, 8
            vpxor xmm3, xmm3, xmm4
          }
          _R11 = 0xC200000000000000LL; /*0x10300312b*/
          __asm /*0x103003135*/
          {
            vmovq xmm4, r11
            vpclmulqdq xmm6, xmm3, xmm4, 0
            vpshufd xmm3, xmm3, 4Eh ; 'N'
            vpxor xmm3, xmm6, xmm3
            vpclmulqdq xmm4, xmm3, xmm4, 0
            vpshufd xmm3, xmm3, 4Eh ; 'N'
            vpxor xmm3, xmm5, xmm3
            vpxor xmm2, xmm3, xmm2
            vpxor xmm2, xmm4, xmm2
          }
          v78 = _RAX + 224; /*0x103003160*/
          v73 += 224; /*0x103003164*/
          v74 += 224; /*0x103003167*/
          v75 += 224; /*0x10300316a*/
          _R8 += 224; /*0x10300316d*/
          _RBX = _RAX; /*0x103003170*/
        }
        while ( _RAX + 224 <= _R12 ); /*0x103003176*/
      }
      else
      {
        _RAX = 112; /*0x103002dbb*/
        __asm { vmovdqa xmm2, [rbp+var_120] } /*0x103002dc0*/
      }
      _RCX = _R15 + _RAX; /*0x10300317c*/
      __asm /*0x103003180*/
      {
        vmovdqa xmm3, xmmword ptr [r13+150h]
        vmovdqu xmm1, xmmword ptr [r15+rax-70h]
        vpshufb xmm1, xmm1, cs:xmmword_1094BA2A0
        vpxor xmm4, xmm2, xmm1
        vpclmulqdq xmm1, xmm4, xmm3, 11h
        vpclmulqdq xmm2, xmm4, xmm3, 0
        vpclmulqdq xmm5, xmm4, xmm3, 1
        vpclmulqdq xmm3, xmm4, xmm3, 10h
        vpxor xmm3, xmm3, xmm5
      }
      _RDX = a11 + 320; /*0x1030031b9*/
      for ( _RSI = -96; _RSI != 0; _RSI += 16 ) /*0x1030031c0*/
      {
        __asm /*0x1030031c7*/
        {
          vmovdqa xmm4, xmmword ptr [rdx]
          vmovdqu xmm5, xmmword ptr [rcx+rsi]
          vpshufb xmm5, xmm5, xmm0
          vpclmulqdq xmm6, xmm5, xmm4, 11h
          vpxor xmm1, xmm6, xmm1
          vpclmulqdq xmm6, xmm5, xmm4, 0
          vpxor xmm2, xmm6, xmm2
          vpclmulqdq xmm6, xmm5, xmm4, 1
          vpxor xmm3, xmm6, xmm3
          vpclmulqdq xmm4, xmm5, xmm4, 10h
          vpxor xmm3, xmm3, xmm4
        }
        _RDX -= 16; /*0x1030031fd*/
      }
      __asm /*0x103003207*/
      {
        vpsrldq xmm0, xmm3, 8
        vpslldq xmm3, xmm3, 8
        vpxor xmm2, xmm2, xmm3
        vmovq xmm3, r11
        vpclmulqdq xmm4, xmm2, xmm3, 0
        vpshufd xmm2, xmm2, 4Eh ; 'N'
        vpxor xmm2, xmm4, xmm2
        vpclmulqdq xmm3, xmm2, xmm3, 0
        vpshufd xmm2, xmm2, 4Eh ; 'N'
        vpxor xmm0, xmm0, xmm2
        vpxor xmm0, xmm0, xmm1
        vpxor xmm0, xmm3, xmm0
        vmovdqa [rbp+var_120], xmm0
      }
    }
    if ( _R12 - _RAX < 0x70 ) /*0x103003252*/
    {
      _RCX = _RAX; /*0x103003377*/
    }
    else
    {
      _RCX = 0; /*0x103003258*/
      __asm /*0x10300325a*/
      {
        vmovdqa xmm0, cs:xmmword_1094BA2A0
        vpmovsxbq xmm1, cs:word_1094BA300
      }
      do /*0x103003285*/
      {
        __asm /*0x10300326b*/
        {
          vpshufb xmm2, xmm12, xmm0
          vmovdqa [rbp+rcx+var_110], xmm2
          vpaddq xmm12, xmm12, xmm1
        }
        _RCX += 16; /*0x10300327d*/
      }
      while ( _RCX != 112 ); /*0x103003285*/
      __asm { vmovdqa xmm2, xmmword ptr [r13+0] } /*0x103003287*/
      for ( _RCX = 0; _RCX != 112; _RCX += 16 ) /*0x10300328d*/
      {
        __asm /*0x10300328f*/
        {
          vpxor xmm3, xmm2, [rbp+rcx+var_110]
          vmovdqa xmmword ptr [rbp+rcx+__dst], xmm3
        }
      }
      for ( m = 1; m != 14; ++m ) /*0x1030032ab*/
      {
        _RDX = 16 * m; /*0x1030032b3*/
        __asm { vmovdqa xmm2, xmmword ptr [r13+rdx+0] } /*0x1030032b7*/
        for ( _RDX = 0; _RDX != 112; _RDX += 16 ) /*0x1030032be*/
        {
          __asm /*0x1030032c0*/
          {
            vmovdqa xmm3, xmmword ptr [rbp+rdx+__dst]
            vaesenc xmm3, xmm3, xmm2
            vmovdqa xmmword ptr [rbp+rdx+__dst], xmm3
          }
        }
      }
      __asm { vmovdqa xmm2, xmmword ptr [r13+0E0h] } /*0x1030032ee*/
      for ( _RDX = 0; _RDX != 112; _RDX += 16 ) /*0x1030032f7*/
      {
        __asm /*0x1030032f9*/
        {
          vmovdqa xmm3, xmmword ptr [rbp+rdx+__dst]
          vaesenclast xmm3, xmm3, xmm2
          vpxor xmm3, xmm3, xmmword ptr [rcx+rdx]
          vmovdqa xmmword ptr [rbp+rdx+__dst], xmm3
        }
      }
      __asm /*0x10300331f*/
      {
        vmovdqu ymm2, [rbp+__dst]
        vmovups ymm3, [rbp+var_80]
        vmovdqu ymm4, ymmword ptr [rbp+var_60]
        vmovdqu ymm5, ymmword ptr [rbp+var_60+10h]
        vmovdqu ymmword ptr [r15+rax+50h], ymm5
        vmovdqu ymmword ptr [r15+rax+40h], ymm4
        vmovups ymmword ptr [r15+rax+20h], ymm3
        vmovdqu ymmword ptr [r15+rax], ymm2
      }
      _RCX = _RAX + 112; /*0x103003351*/
      v225 = _RAX + 224; /*0x103003355*/
      if ( _RAX + 224 <= _R12 ) /*0x10300335f*/
      {
        __asm { vmovdqa xmm3, [rbp+var_120] } /*0x10300337f*/
        v228 = a4 + _RCX; /*0x103003387*/
        _RAX = _R15 + _RAX; /*0x103003392*/
        __asm { vmovq xmm2, r11 } /*0x103003395*/
        _RDI = _RCX; /*0x10300339a*/
        do /*0x103003559*/
        {
          _RCX = v225; /*0x10300339d*/
          for ( _R8 = 0; _R8 != 112; _R8 += 16 ) /*0x1030033a0*/
          {
            __asm /*0x1030033a3*/
            {
              vpshufb xmm4, xmm12, xmm0
              vmovdqa [rbp+r8+var_110], xmm4
              vpaddq xmm12, xmm12, xmm1
            }
          }
          __asm { vmovdqa xmm4, xmmword ptr [r13+0] } /*0x1030033c0*/
          for ( _R8 = 0; _R8 != 112; _R8 += 16 ) /*0x1030033c6*/
          {
            __asm /*0x1030033c9*/
            {
              vpxor xmm5, xmm4, [rbp+r8+var_110]
              vmovdqa xmmword ptr [rbp+r8+__dst], xmm5
            }
          }
          for ( n = 1; n != 14; ++n ) /*0x1030033e7*/
          {
            _R9 = 16 * n; /*0x1030033f0*/
            __asm { vmovdqa xmm4, xmmword ptr [r13+r9+0] } /*0x1030033f4*/
            for ( _R9 = 0; _R9 != 112; _R9 += 16 ) /*0x1030033fb*/
            {
              __asm /*0x1030033fe*/
              {
                vmovdqa xmm5, xmmword ptr [rbp+r9+__dst]
                vaesenc xmm5, xmm5, xmm4
                vmovdqa xmmword ptr [rbp+r9+__dst], xmm5
              }
            }
          }
          __asm { vmovdqa xmm4, xmmword ptr [r13+0E0h] } /*0x10300342a*/
          for ( _R8 = 0; _R8 != 112; _R8 += 16 ) /*0x103003433*/
          {
            __asm /*0x103003436*/
            {
              vmovdqa xmm5, xmmword ptr [rbp+r8+__dst]
              vaesenclast xmm5, xmm5, xmm4
              vpxor xmm5, xmm5, xmmword ptr [rdx+r8]
              vmovdqa xmmword ptr [rbp+r8+__dst], xmm5
            }
          }
          __asm /*0x10300345f*/
          {
            vmovups ymm4, [rbp+__dst]
            vmovups ymm5, [rbp+var_80]
            vmovups ymm6, ymmword ptr [rbp+var_60]
            vmovups ymm7, ymmword ptr [rbp+var_60+10h]
            vmovups ymmword ptr [r15+rdi+50h], ymm7
            vmovups ymmword ptr [r15+rdi+40h], ymm6
            vmovups ymmword ptr [r15+rdi+20h], ymm5
            vmovups ymmword ptr [r15+rdi], ymm4
            vmovdqa xmm4, xmmword ptr [r13+150h]
            vmovdqu xmm5, xmmword ptr [r15+rdi-70h]
            vpshufb xmm5, xmm5, xmm0
            vpxor xmm6, xmm3, xmm5
            vpclmulqdq xmm3, xmm6, xmm4, 11h
            vpclmulqdq xmm5, xmm6, xmm4, 0
            vpclmulqdq xmm7, xmm6, xmm4, 1
            vpclmulqdq xmm6, xmm6, xmm4, 10h
            vpxor xmm6, xmm6, xmm7
          }
          _RDI = 16; /*0x1030034c6*/
          _R8 = a11 + 320; /*0x1030034cb*/
          do /*0x103003511*/
          {
            __asm /*0x1030034ce*/
            {
              vmovdqa xmm7, xmmword ptr [r8]
              vmovdqu xmm8, xmmword ptr [rax+rdi]
              vpshufb xmm8, xmm8, xmm0
              vpclmulqdq xmm9, xmm8, xmm7, 11h
              vpxor xmm3, xmm9, xmm3
              vpclmulqdq xmm9, xmm8, xmm7, 0
              vpxor xmm5, xmm9, xmm5
              vpclmulqdq xmm9, xmm8, xmm7, 1
              vpxor xmm6, xmm9, xmm6
              vpclmulqdq xmm7, xmm8, xmm7, 10h
              vpxor xmm6, xmm6, xmm7
            }
            _RDI += 16; /*0x103003505*/
            _R8 -= 16; /*0x103003509*/
          }
          while ( _RDI != 112 ); /*0x103003511*/
          __asm /*0x103003513*/
          {
            vpsrldq xmm7, xmm6, 8
            vpslldq xmm6, xmm6, 8
            vpxor xmm5, xmm5, xmm6
            vpclmulqdq xmm6, xmm5, xmm2, 0
            vpshufd xmm5, xmm5, 4Eh ; 'N'
            vpxor xmm5, xmm6, xmm5
            vpclmulqdq xmm6, xmm5, xmm2, 0
            vpshufd xmm5, xmm5, 4Eh ; 'N'
            vpxor xmm5, xmm7, xmm5
            vpxor xmm3, xmm5, xmm3
            vpxor xmm3, xmm6, xmm3
          }
          v225 = _RCX + 112; /*0x103003547*/
          v228 += 112; /*0x10300354b*/
          _RAX += 112; /*0x10300354f*/
          _RDI = _RCX; /*0x103003553*/
        }
        while ( _RCX + 112 <= _R12 ); /*0x103003559*/
      }
      else
      {
        __asm /*0x103003361*/
        {
          vmovdqa xmm3, [rbp+var_120]
          vmovdqa xmm4, xmmword ptr [r13+150h]
        }
      }
      _RAX = _R15 + _RCX; /*0x10300355f*/
      __asm /*0x103003563*/
      {
        vmovdqu xmm1, xmmword ptr [r15+rcx-70h]
        vpshufb xmm1, xmm1, cs:xmmword_1094BA2A0
        vpxor xmm3, xmm3, xmm1
        vpclmulqdq xmm1, xmm3, xmm4, 11h
        vpclmulqdq xmm2, xmm3, xmm4, 0
        vpclmulqdq xmm5, xmm3, xmm4, 1
        vpclmulqdq xmm3, xmm3, xmm4, 10h
        vpxor xmm3, xmm3, xmm5
      }
      _RDX = a11 + 320; /*0x103003593*/
      for ( _RSI = -96; _RSI != 0; _RSI += 16 ) /*0x10300359a*/
      {
        __asm /*0x1030035a1*/
        {
          vmovdqa xmm4, xmmword ptr [rdx]
          vmovdqu xmm5, xmmword ptr [rax+rsi]
          vpshufb xmm5, xmm5, xmm0
          vpclmulqdq xmm6, xmm5, xmm4, 11h
          vpxor xmm1, xmm6, xmm1
          vpclmulqdq xmm6, xmm5, xmm4, 0
          vpxor xmm2, xmm6, xmm2
          vpclmulqdq xmm6, xmm5, xmm4, 1
          vpxor xmm3, xmm6, xmm3
          vpclmulqdq xmm4, xmm5, xmm4, 10h
          vpxor xmm3, xmm3, xmm4
        }
        _RDX -= 16; /*0x1030035d7*/
      }
      __asm /*0x1030035e1*/
      {
        vpsrldq xmm0, xmm3, 8
        vpslldq xmm3, xmm3, 8
        vpxor xmm2, xmm2, xmm3
        vmovq xmm3, r11
        vpclmulqdq xmm4, xmm2, xmm3, 0
        vpshufd xmm2, xmm2, 4Eh ; 'N'
        vpxor xmm2, xmm4, xmm2
        vpclmulqdq xmm3, xmm2, xmm3, 0
        vpshufd xmm2, xmm2, 4Eh ; 'N'
        vpxor xmm0, xmm0, xmm2
        vpxor xmm0, xmm0, xmm1
        vpxor xmm0, xmm3, xmm0
        vmovdqa [rbp+var_120], xmm0
      }
    }
    v318 = _RCX + 64; /*0x103003622*/
    if ( _RCX + 64 <= _R12 ) /*0x103003629*/
    {
      __asm { vmovdqa xmm2, [rbp+var_120] } /*0x103003633*/
      _RSI = _R15 + _RCX; /*0x103003642*/
      __asm /*0x103003646*/
      {
        vmovdqa xmm0, cs:xmmword_1094BA2A0
        vpmovsxbq xmm1, cs:word_1094BA300
      }
      do /*0x103003796*/
      {
        _RAX = v318; /*0x103003657*/
        for ( _RDI = 0; _RDI != 64; _RDI += 16 ) /*0x10300365a*/
        {
          __asm /*0x10300365c*/
          {
            vpshufb xmm3, xmm12, xmm0
            vmovdqa [rbp+rdi+var_110], xmm3
            vpaddq xmm12, xmm12, xmm1
          }
        }
        _RDI = _R15 + _RCX; /*0x103003678*/
        for ( ii = 0; ii != 4; ++ii ) /*0x10300367f*/
        {
          _R9 = 16 * ii; /*0x103003685*/
          __asm /*0x103003689*/
          {
            vmovdqa xmm3, xmmword ptr [r13+0]
            vpxor xmm3, xmm3, [rbp+r9+var_110]
          }
          for ( jj = 16; jj != 224; jj += 16 ) /*0x103003699*/
            __asm { vaesenc xmm3, xmm3, xmmword ptr [r13+r10+0] } /*0x10300369f*/
          __asm /*0x1030036b3*/
          {
            vaesenclast xmm3, xmm3, xmmword ptr [r13+0E0h]
            vpxor xmm3, xmm3, xmmword ptr [rcx+r9]
            vmovdqu xmmword ptr [rdi+r9], xmm3
          }
        }
        __asm /*0x1030036d1*/
        {
          vmovdqa xmm4, xmmword ptr [r13+120h]
          vmovdqu xmm3, xmmword ptr [rdi]
          vpshufb xmm3, xmm3, xmm0
          vpxor xmm5, xmm2, xmm3
          vpclmulqdq xmm2, xmm5, xmm4, 11h
          vpclmulqdq xmm3, xmm5, xmm4, 0
          vpclmulqdq xmm6, xmm5, xmm4, 1
          vpclmulqdq xmm4, xmm5, xmm4, 10h
          vpxor xmm4, xmm4, xmm6
        }
        _RCX = 16; /*0x103003703*/
        _RDI = a11 + 272; /*0x103003708*/
        do /*0x10300374d*/
        {
          __asm /*0x10300370b*/
          {
            vmovdqa xmm5, xmmword ptr [rdi]
            vmovdqu xmm6, xmmword ptr [rsi+rcx]
            vpshufb xmm6, xmm6, xmm0
            vpclmulqdq xmm7, xmm6, xmm5, 11h
            vpxor xmm2, xmm7, xmm2
            vpclmulqdq xmm7, xmm6, xmm5, 0
            vpxor xmm3, xmm7, xmm3
            vpclmulqdq xmm7, xmm6, xmm5, 1
            vpxor xmm4, xmm7, xmm4
            vpclmulqdq xmm5, xmm6, xmm5, 10h
            vpxor xmm4, xmm4, xmm5
          }
          _RCX += 16; /*0x103003741*/
          _RDI -= 16; /*0x103003745*/
        }
        while ( _RCX != 64 ); /*0x10300374d*/
        __asm /*0x10300374f*/
        {
          vpsrldq xmm5, xmm4, 8
          vpslldq xmm4, xmm4, 8
          vpxor xmm3, xmm3, xmm4
          vmovq xmm4, r11
          vpclmulqdq xmm6, xmm3, xmm4, 0
          vpshufd xmm3, xmm3, 4Eh ; 'N'
          vpxor xmm3, xmm6, xmm3
          vpclmulqdq xmm4, xmm3, xmm4, 0
          vpshufd xmm3, xmm3, 4Eh ; 'N'
          vpxor xmm3, xmm5, xmm3
          vpxor xmm2, xmm3, xmm2
          vpxor xmm2, xmm4, xmm2
        }
        v318 = _RAX + 64; /*0x103003788*/
        _RSI += 64; /*0x10300378c*/
        _RCX = _RAX; /*0x103003790*/
      }
      while ( _RAX + 64 <= _R12 ); /*0x103003796*/
      __asm { vmovdqa [rbp+var_120], xmm2 } /*0x10300379c*/
    }
    else
    {
      _RAX = _RCX; /*0x10300362b*/
    }
    v367 = _RAX + 32; /*0x1030037a4*/
    if ( _RAX + 32 <= _R12 ) /*0x1030037ab*/
    {
      __asm /*0x1030037b1*/
      {
        vmovdqa xmm4, [rbp+var_120]
        vmovdqa xmm0, cs:xmmword_1094BA2A0
        vpmovsxbq xmm1, cs:word_1094BA300
        vpmovsxbq xmm2, cs:word_1094BA302
        vmovq xmm3, r11
      }
      do /*0x103003901*/
      {
        v373 = _RAX; /*0x1030037d8*/
        _RAX = v367; /*0x1030037db*/
        __asm /*0x1030037de*/
        {
          vpshufb xmm5, xmm12, xmm0
          vmovdqa [rbp+var_110], xmm5
          vpaddq xmm5, xmm12, xmm1
          vpshufb xmm5, xmm5, xmm0
          vmovdqa [rbp+var_100], xmm5
        }
        _RDX = _R15 + v373; /*0x1030037fc*/
        v378 = 1; /*0x103003803*/
        _RDI = 0; /*0x103003806*/
        do /*0x103003852*/
        {
          __asm /*0x103003808*/
          {
            vmovdqa xmm5, xmmword ptr [r13+0]
            vpxor xmm5, xmm5, [rbp+rdi+var_110]
          }
          for ( kk = 16; kk != 224; kk += 16 ) /*0x103003817*/
            __asm { vaesenc xmm5, xmm5, xmmword ptr [r13+r8+0] } /*0x10300381d*/
          __asm /*0x103003831*/
          {
            vaesenclast xmm5, xmm5, xmmword ptr [r13+0E0h]
            vpxor xmm5, xmm5, xmmword ptr [rcx+rdi]
            vmovdqu xmmword ptr [rdx+rdi], xmm5
          }
          _RDI = 16; /*0x103003844*/
          v385 = (v378 & 1) == 0; /*0x103003849*/
          v378 = 0; /*0x10300384d*/
        }
        while ( !v385 ); /*0x103003852*/
        __asm /*0x103003854*/
        {
          vpaddq xmm12, xmm12, xmm2
          vmovdqa xmm5, xmmword ptr [r13+0F0h]
          vmovdqa xmm6, xmmword ptr [r13+100h]
          vmovdqu xmm7, xmmword ptr [rdx]
          vmovdqu xmm8, xmmword ptr [rdx+10h]
          vpshufb xmm7, xmm7, xmm0
          vpxor xmm4, xmm4, xmm7
          vpclmulqdq xmm7, xmm4, xmm6, 11h
          vpclmulqdq xmm9, xmm4, xmm6, 0
          vpclmulqdq xmm10, xmm4, xmm6, 1
          vpclmulqdq xmm4, xmm4, xmm6, 10h
          vpxor xmm4, xmm10, xmm4
          vpshufb xmm6, xmm8, xmm0
          vpclmulqdq xmm8, xmm6, xmm5, 11h
          vpxor xmm7, xmm8, xmm7
          vpclmulqdq xmm8, xmm6, xmm5, 0
          vpxor xmm8, xmm8, xmm9
          vpclmulqdq xmm9, xmm6, xmm5, 1
          vpclmulqdq xmm5, xmm6, xmm5, 10h
          vpxor xmm5, xmm9, xmm5
          vpxor xmm4, xmm4, xmm5
          vpsrldq xmm5, xmm4, 8
          vpxor xmm5, xmm7, xmm5
          vpslldq xmm4, xmm4, 8
          vpxor xmm4, xmm8, xmm4
          vpclmulqdq xmm6, xmm4, xmm3, 0
          vpshufd xmm4, xmm4, 4Eh ; 'N'
          vpxor xmm4, xmm6, xmm4
          vpclmulqdq xmm6, xmm4, xmm3, 0
          vpshufd xmm4, xmm4, 4Eh ; 'N'
          vpxor xmm4, xmm5, xmm4
          vpxor xmm4, xmm4, xmm6
        }
        v367 = _RAX + 32; /*0x1030038fa*/
      }
      while ( _RAX + 32 <= _R12 ); /*0x103003901*/
      __asm { vmovdqa [rbp+var_120], xmm4 } /*0x103003907*/
    }
    v416 = _RAX + 16; /*0x10300390f*/
    if ( _RAX + 16 >= _R12 ) /*0x103003916*/
    {
      v421 = _RAX; /*0x1030039f6*/
    }
    else
    {
      __asm /*0x10300391c*/
      {
        vmovdqa xmm3, [rbp+var_120]
        vmovdqa xmm0, cs:xmmword_1094BA2A0
        vmovq xmm1, r11
        vpmovsxbq xmm2, cs:word_1094BA300
      }
      do /*0x1030039e6*/
      {
        v421 = v416; /*0x10300393a*/
        __asm /*0x10300393d*/
        {
          vpshufb xmm4, xmm12, xmm0
          vpxor xmm4, xmm4, xmmword ptr [r13+0]
        }
        for ( mm = 16; mm != 224; mm += 16 ) /*0x103003948*/
          __asm { vaesenc xmm4, xmm4, xmmword ptr [r13+rcx+0] } /*0x10300394d*/
        __asm /*0x103003961*/
        {
          vaesenclast xmm4, xmm4, xmmword ptr [r13+0E0h]
          vpxor xmm4, xmm4, xmmword ptr [r14+rax]
          vmovdqu xmmword ptr [r15+rax], xmm4
          vmovdqa xmm5, xmmword ptr [r13+0F0h]
          vpshufb xmm4, xmm4, xmm0
          vpxor xmm3, xmm3, xmm4
          vpclmulqdq xmm4, xmm3, xmm5, 11h
          vpclmulqdq xmm6, xmm3, xmm5, 0
          vpclmulqdq xmm7, xmm3, xmm5, 1
          vpclmulqdq xmm3, xmm3, xmm5, 10h
          vpxor xmm3, xmm3, xmm7
          vpsrldq xmm5, xmm3, 8
          vpxor xmm4, xmm4, xmm5
          vpslldq xmm3, xmm3, 8
          vpxor xmm3, xmm6, xmm3
          vpclmulqdq xmm5, xmm3, xmm1, 0
          vpshufd xmm3, xmm3, 4Eh ; 'N'
          vpxor xmm3, xmm5, xmm3
          vpclmulqdq xmm5, xmm3, xmm1, 0
          vpshufd xmm3, xmm3, 4Eh ; 'N'
          vpxor xmm3, xmm4, xmm3
          vpxor xmm3, xmm5, xmm3
          vpaddq xmm12, xmm12, xmm2
        }
        v416 = v421 + 16; /*0x1030039dc*/
        _RAX = v421; /*0x1030039e0*/
      }
      while ( v421 + 16 < _R12 ); /*0x1030039e6*/
      __asm { vmovdqa [rbp+var_120], xmm3 } /*0x1030039ec*/
    }
    __asm /*0x1030039f9*/
    {
      vmovq xmm0, [rbp+arg_0]
      vmovq xmm1, r12
      vpunpcklqdq xmm0, xmm1, xmm0
      vpblendw xmm2, xmm11, cs:xmmword_1096F8570, 0C0h
      vpsllq xmm1, xmm0, 3
      vpxor xmm0, xmm2, xmmword ptr [r13+0]
    }
    v451 = 16; /*0x103003a1c*/
    _RCX = v523; /*0x103003a21*/
    do /*0x103003a39*/
    {
      __asm { vaesenc xmm0, xmm0, xmmword ptr [r13+rax+0] } /*0x103003a28*/
      v451 += 16; /*0x103003a2f*/
    }
    while ( v451 != 224 ); /*0x103003a39*/
    __asm /*0x103003a3b*/
    {
      vaesenclast xmm0, xmm0, xmmword ptr [r13+0E0h]
      vmovdqu xmmword ptr [rcx], xmm0
    }
    if ( _R12 == v421 ) /*0x103003a4e*/
    {
      __asm /*0x103003a50*/
      {
        vmovdqa xmm2, xmmword ptr [r13+0F0h]
        vpxor xmm1, xmm1, [rbp+var_120]
        vpclmulqdq xmm3, xmm1, xmm2, 11h
        vpclmulqdq xmm4, xmm1, xmm2, 0
        vpclmulqdq xmm5, xmm1, xmm2, 1
        vpclmulqdq xmm1, xmm1, xmm2, 10h
        vpxor xmm1, xmm1, xmm5
        vpsrldq xmm2, xmm1, 8
        vpxor xmm2, xmm3, xmm2
        vpslldq xmm1, xmm1, 8
        vpxor xmm1, xmm4, xmm1
        vmovq xmm3, r11
        vpclmulqdq xmm4, xmm1, xmm3, 0
        vpshufd xmm1, xmm1, 4Eh ; 'N'
        vpxor xmm1, xmm4, xmm1
        vpclmulqdq xmm3, xmm1, xmm3, 0
        vpshufd xmm1, xmm1, 4Eh ; 'N'
        vpxor xmm1, xmm2, xmm1
        vpxor xmm1, xmm3, xmm1
      }
    }
    else
    {
      __asm /*0x103003abb*/
      {
        vpshufb xmm0, xmm1, cs:xmmword_1094BA2A0
        vmovdqa [rbp+var_130], xmm0
      }
      v474 = (const void *)(v421 + a4); /*0x103003ad6*/
      v475 = _R12 - v421; /*0x103003ad9*/
      __asm /*0x103003adf*/
      {
        vmovdqa [rbp+var_150], xmm12
        vzeroupper
      }
      memcpy(&__dst, __src: v474, __n: _R12 - v421); /*0x103003aea*/
      __asm { vmovaps xmm0, [rbp+var_130] } /*0x103003aef*/
      _RAX = &__dst; /*0x103003af7*/
      __asm /*0x103003afe*/
      {
        vmovaps xmmword ptr [rax+10h], xmm0
        vmovdqa xmm0, [rbp+var_150]
        vpshufb xmm0, xmm0, cs:xmmword_1094BA2A0
        vpxor xmm0, xmm0, xmmword ptr [r13+0]
      }
      for ( nn = 16; nn != 224; nn += 16 ) /*0x103003b1a*/
        __asm { vaesenc xmm0, xmm0, xmmword ptr [r13+rax+0] } /*0x103003b1f*/
      __asm /*0x103003b32*/
      {
        vaesenclast xmm0, xmm0, xmmword ptr [r13+0E0h]
        vpxor xmm1, xmm0, xmmword ptr [rbp+__dst]
        vmovdqa xmmword ptr [rbp+__dst], xmm1
      }
      v484 = _R12 - v421; /*0x103003b4b*/
      if ( v475 <= 0xF ) /*0x103003b52*/
      {
        __bzero(a1: (__int64)&__dst + v475, a2: v421 - _R12 + 16); /*0x103003b69*/
        v484 = _R12 - v421; /*0x103003b6e*/
        __asm /*0x103003b71*/
        {
          vmovdqa xmm1, xmmword ptr [rbp+__dst]
          vmovdqa xmm0, xmmword ptr [rbp+__dst+10h]
          vmovdqa [rbp+var_130], xmm0
        }
      }
      __asm { vmovdqa [rbp+var_150], xmm1 } /*0x103003b89*/
      memcpy(__dst: (void *)(v421 + _R15), __src: &__dst, __n: v484); /*0x103003b9e*/
      __asm /*0x103003ba3*/
      {
        vmovdqa xmm0, xmmword ptr [r13+0F0h]
        vmovdqa xmm6, cs:xmmword_1094BA2A0
        vmovdqa xmm1, [rbp+var_150]
        vpshufb xmm1, xmm1, xmm6
        vpxor xmm1, xmm1, [rbp+var_120]
        vmovdqa xmm2, xmmword ptr [r13+100h]
        vpclmulqdq xmm3, xmm1, xmm2, 11h
        vpclmulqdq xmm4, xmm1, xmm2, 0
        vpclmulqdq xmm5, xmm1, xmm2, 1
        vpclmulqdq xmm1, xmm1, xmm2, 10h
        vpxor xmm1, xmm1, xmm5
        vmovdqa xmm2, [rbp+var_130]
        vpshufb xmm2, xmm2, xmm6
        vpclmulqdq xmm5, xmm2, xmm0, 11h
        vpxor xmm3, xmm5, xmm3
        vpclmulqdq xmm5, xmm2, xmm0, 0
        vpxor xmm4, xmm5, xmm4
        vpclmulqdq xmm5, xmm2, xmm0, 1
        vpclmulqdq xmm0, xmm2, xmm0, 10h
        vpxor xmm0, xmm5, xmm0
        vpxor xmm0, xmm1, xmm0
        vpsrldq xmm1, xmm0, 8
        vpxor xmm1, xmm3, xmm1
        vpslldq xmm0, xmm0, 8
        vpxor xmm0, xmm4, xmm0
      }
      _RAX = 0xC200000000000000LL; /*0x103003c35*/
      __asm /*0x103003c3f*/
      {
        vmovq xmm2, rax
        vpclmulqdq xmm3, xmm0, xmm2, 0
        vpshufd xmm0, xmm0, 4Eh ; 'N'
        vpxor xmm0, xmm3, xmm0
        vpclmulqdq xmm2, xmm0, xmm2, 0
        vpshufd xmm0, xmm0, 4Eh ; 'N'
        vpxor xmm0, xmm1, xmm0
        vpxor xmm1, xmm0, xmm2
      }
      _RCX = v523; /*0x103003c66*/
      __asm { vmovdqu xmm0, xmmword ptr [rcx] } /*0x103003c6d*/
    }
    __asm { vpshufb xmm1, xmm1, cs:xmmword_1094BA2A0 } /*0x103003c71*/
    result = 0; /*0x103003c7a*/
    __asm /*0x103003c7c*/
    {
      vpxor xmm0, xmm0, xmm1
      vmovdqu xmmword ptr [rcx], xmm0
    }
    if ( v521 != nullptr ) /*0x103003c8e*/
      *v521 = 16; /*0x103003c94*/
  }
  if ( __stack_chk_guard != v530 ) /*0x103002df8*/
    __asm { vzeroupper } /*0x103003ca0*/
  __asm { vzeroupper } /*0x103002e0f*/
  return result; /*0x103002e12*/
}

// Address: 0x103003ca8 | Name: _crypto_aead_aes256gcm_encrypt
__int64 __fastcall crypto_aead_aes256gcm_encrypt(
        int a1,
        _QWORD *a2,
        int a3,
        __int64 a4,
        int a5,
        __int64 a6,
        int a7,
        __int128 a8)
{
  __int64 result; // rax
  __int64 v12; // rbx
  __int64 v13; // rcx

  __asm { vmovups xmm0, [rbp+arg_8] } /*0x103003cbf*/
  __asm { vmovups [rsp+30h+var_20], xmm0 }
  result = crypto_aead_aes256gcm_encrypt_detached(a1, a2: a1 + (int)a4, a3: 0, a4: a3, a5: a4, a6: a5, a7: a6); /*0x103003cda*/
  if ( a2 != nullptr ) /*0x103003ce2*/
  {
    v12 = a4 + 16; /*0x103003ce4*/
    v13 = 0; /*0x103003ce8*/
    if ( (_DWORD)result == 0 ) /*0x103003cec*/
      v13 = v12; /*0x103003cec*/
    *a2 = v13; /*0x103003cf0*/
  }
  return result; /*0x103003cf3*/
}

// Address: 0x103003cfc | Name: _crypto_aead_aes256gcm_encrypt_detached
__int64 __fastcall crypto_aead_aes256gcm_encrypt_detached(
        const char *a1,
        __int64 a2,
        _QWORD *a3,
        const char *a4,
        unsigned __int64 a5,
        const char *a6,
        unsigned __int64 a7,
        __int64 a8,
        __int64 a9,
        __int64 a10)
{
  __int64 v10; // rbx
  __m128 v14; // xmm0
  int v16; // [rsp+8h] [rbp-258h]
  _BYTE v19[512]; // [rsp+30h] [rbp-230h] BYREF

  v10 = (__int64)a6; /*0x103003d10*/
  _mm_prefetch(a1, 2); /*0x103003d3c*/
  _mm_prefetch(a4, 2); /*0x103003d3f*/
  _mm_prefetch(a6, 2); /*0x103003d42*/
  crypto_aead_aes256gcm_beforenm(_RDI: (__int64)v19, _RSI: a10); /*0x103003d50*/
  LODWORD(v10) = crypto_aead_aes256gcm_encrypt_detached_afternm( /*0x103003d8a*/
                   (__int64)a1,
                   _RSI: a2,
                   a3,
                   (__int64)a4,
                   a5,
                   a6: v10,
                   _XMM0: v14,
                   a8: a7,
                   a9: v16,
                   a10: a9,
                   a11: (__int64)v19);
  sodium_memzero(a1: v19, a2: 512); /*0x103003d94*/
  return (unsigned int)v10; /*0x103003dab*/
}

// Address: 0x103003dc2 | Name: _crypto_aead_aes256gcm_encrypt_afternm
__int64 __fastcall crypto_aead_aes256gcm_encrypt_afternm(
        __int64 a1,
        _QWORD *a2,
        __int64 a3,
        unsigned __int64 a4,
        __int64 a5,
        unsigned __int64 a6,
        int a7,
        __int128 a8)
{
  __int64 result; // rax
  int v12; // [rsp+8h] [rbp-28h]
  __int128 v13; // [rsp+10h] [rbp-20h]

  __asm { vmovups xmm0, [rbp+arg_8] } /*0x103003dd9*/
  __asm { vmovups [rsp+30h+var_20], xmm0 }
  result = crypto_aead_aes256gcm_encrypt_detached_afternm( /*0x103003df4*/
             a1,
             _RSI: a1 + a4,
             a3: nullptr,
             a4: a3,
             a5: a4,
             a6: a5,
             _XMM0,
             a8: a6,
             a9: v12,
             a10: v13,
             a11: *((__int64 *)&v13 + 1));
  if ( a2 != nullptr ) /*0x103003dfc*/
    *a2 = a4 + 16; /*0x103003e02*/
  return result; /*0x103003e05*/
}

// Address: 0x103003e0e | Name: _crypto_aead_aes256gcm_decrypt_detached_afternm
__int64 __fastcall crypto_aead_aes256gcm_decrypt_detached_afternm(
        char *__b,
        __m128 _XMM0,
        __int64 a3,
        __int64 a4,
        unsigned __int64 a5,
        __m128i *a6,
        __int64 a7,
        unsigned __int64 a8,
        __int64 a9,
        __int64 a10)
{
  __int64 result; // rax
  __int64 nn; // rax
  unsigned int v138; // r14d
  unsigned __int64 v139; // r12
  __int64 v141; // rax
  __int64 v142; // rdx
  __int64 v146; // rdi
  __int64 v147; // r9
  __int64 i; // r9
  __int64 j; // r9
  __int64 v236; // rdi
  __int64 v240; // rdx
  __int64 v241; // rsi
  __int64 k; // rdi
  __int64 v297; // rsi
  __int64 v299; // rcx
  __int64 m; // rdi
  __int64 n; // r9
  __int64 v346; // rdx
  char v386; // si
  __int64 ii; // r9
  bool v393; // zf
  __int64 v395; // rcx
  __int64 v400; // r12
  __int64 jj; // rcx
  __int64 kk; // rax
  size_t v456; // rdx
  __int64 mm; // rax
  __m128i *v507; // [rsp+68h] [rbp-138h]
  __int128 v508; // [rsp+70h] [rbp-130h] BYREF
  __m128i v509; // [rsp+80h] [rbp-120h] BYREF
  __m128i v510[7]; // [rsp+90h] [rbp-110h] BYREF
  __m256 __dst; // [rsp+100h] [rbp-A0h] BYREF

  _R14 = a5; /*0x103003e25*/
  _RBX = a4; /*0x103003e28*/
  _R15 = a10; /*0x103003e2b*/
  _RDX = a9; /*0x103003e2f*/
  _R11 = a8; /*0x103003e33*/
  result = 0xFFFFFFFFLL; /*0x103003e45*/
  if ( __b != nullptr ) /*0x103003e4d*/
  {
    if ( a5 <= 0xFFFFFFFFFFFFFF1FLL /*0x103003e9c*/
      && a8 <= 0xFFFFFFFFFFFFFF1FLL
      && (a8 + 15) >> 4 <= a8
      && a5 <= 0xFFFFFFFD0LL
      && (a5 + 15) >> 4 <= a5 )
    {
      _R13 = __b; /*0x103003ea2*/
      __asm /*0x103003ea5*/
      {
        vxorps xmm0, xmm0, xmm0
        vmovaps [rbp+var_130], xmm0
        vmovq xmm0, qword ptr [rdx]
        vpinsrd xmm0, xmm0, dword ptr [rdx+8], 2
        vpblendw xmm12, xmm0, cs:xmmword_1094BA2C0, 0C0h
      }
      v507 = a6; /*0x103003ed4*/
      if ( a7 != 0 && a8 != 0 ) /*0x103003ecf*/
      {
        __asm { vmovdqa [rbp+var_150], xmm12 } /*0x103003ef5*/
        gh_ad_blocks(a1: a10, a2: &v508, a3: a7, a4: a8 & 0xFFFFFFFFFFFFFFF0LL); /*0x103003efd*/
        __asm { vmovdqa xmm12, [rbp+var_150] } /*0x103003f02*/
        _R11 = a8; /*0x103003f0a*/
        a6 = v507; /*0x103003f0e*/
        if ( (a8 & 0xF) != 0 ) /*0x103003f1c*/
        {
          __asm { vpxor xmm0, xmm0, xmm0 } /*0x103003f22*/
          _RAX = &__dst; /*0x103003f26*/
          __asm { vmovdqa xmmword ptr [rax], xmm0 } /*0x103003f2d*/
          __memcpy_chk(a1: &__dst, a2: a8 + a7 - (a8 & 0xF), a3: a8 & 0xF, a4: 16); /*0x103003f42*/
          __asm { vmovdqa xmm12, [rbp+var_150] } /*0x103003f47*/
          _R11 = a8; /*0x103003f4f*/
          a6 = v507; /*0x103003f53*/
          __asm { vmovdqa xmm0, xmmword ptr [r15+0F0h] } /*0x103003f5a*/
          _RAX = &__dst; /*0x103003f63*/
          __asm /*0x103003f6a*/
          {
            vmovdqa xmm1, xmmword ptr [rax]
            vpshufb xmm1, xmm1, cs:xmmword_1094BA2A0
            vpxor xmm1, xmm1, [rbp+var_130]
            vpclmulqdq xmm2, xmm1, xmm0, 11h
            vpclmulqdq xmm3, xmm1, xmm0, 0
            vpclmulqdq xmm4, xmm1, xmm0, 1
            vpclmulqdq xmm0, xmm1, xmm0, 10h
            vpxor xmm0, xmm0, xmm4
            vpsrldq xmm1, xmm0, 8
            vpxor xmm1, xmm2, xmm1
            vpslldq xmm0, xmm0, 8
            vpxor xmm0, xmm3, xmm0
          }
          _RAX = 0xC200000000000000LL; /*0x103003fad*/
          __asm /*0x103003fb7*/
          {
            vmovq xmm2, rax
            vpclmulqdq xmm3, xmm0, xmm2, 0
            vpshufd xmm0, xmm0, 4Eh ; 'N'
            vpxor xmm0, xmm3, xmm0
            vpclmulqdq xmm2, xmm0, xmm2, 0
            vpshufd xmm0, xmm0, 4Eh ; 'N'
            vpxor xmm0, xmm1, xmm0
            vpxor xmm0, xmm2, xmm0
            vmovdqa [rbp+var_130], xmm0
          }
        }
      }
      __asm { vpshufb xmm11, xmm12, cs:xmmword_1094BA2A0 } /*0x103003fe6*/
      if ( _R14 >= 0xE0 ) /*0x103003ff6*/
      {
        v139 = _R11; /*0x10300432e*/
        __asm { vmovdqa xmm2, [rbp+var_130] } /*0x103004331*/
        v141 = _RBX + 16; /*0x103004339*/
        v142 = _RBX + 112; /*0x10300433d*/
        _R11 = 0; /*0x103004346*/
        __asm /*0x103004349*/
        {
          vmovdqa xmm0, cs:xmmword_1094BA2A0
          vpmovsxbq xmm1, cs:word_1094BA304
        }
        v146 = _RBX; /*0x10300435a*/
        v147 = 224; /*0x10300435d*/
        do /*0x103004678*/
        {
          _RCX = v147; /*0x103004363*/
          for ( _R9 = 0; _R9 != 112; _R9 += 16 ) /*0x103004366*/
          {
            __asm /*0x103004369*/
            {
              vpshufb xmm3, xmm11, xmm0
              vmovdqa [rbp+r9+var_110], xmm3
              vpaddq xmm11, xmm11, xmm1
            }
          }
          __asm /*0x103004386*/
          {
            vmovdqa xmm4, xmmword ptr [r15+1C0h]
            vmovdqu xmm3, xmmword ptr [rbx+r11]
            vpshufb xmm3, xmm3, xmm0
            vpxor xmm5, xmm2, xmm3
            vpclmulqdq xmm2, xmm5, xmm4, 11h
            vpclmulqdq xmm3, xmm5, xmm4, 0
            vpclmulqdq xmm6, xmm5, xmm4, 1
            vpclmulqdq xmm4, xmm5, xmm4, 10h
            vpxor xmm4, xmm4, xmm6
          }
          _R9 = 432; /*0x1030043ba*/
          _R10 = v141; /*0x1030043c0*/
          do /*0x10300440a*/
          {
            __asm /*0x1030043c3*/
            {
              vmovdqa xmm5, xmmword ptr [r15+r9]
              vmovdqu xmm6, xmmword ptr [r10]
              vpshufb xmm6, xmm6, xmm0
              vpclmulqdq xmm7, xmm6, xmm5, 11h
              vpxor xmm2, xmm7, xmm2
              vpclmulqdq xmm7, xmm6, xmm5, 0
              vpxor xmm3, xmm7, xmm3
              vpclmulqdq xmm7, xmm6, xmm5, 1
              vpxor xmm4, xmm7, xmm4
              vpclmulqdq xmm5, xmm6, xmm5, 10h
              vpxor xmm4, xmm4, xmm5
            }
            _R9 -= 16; /*0x1030043fb*/
            _R10 += 16; /*0x1030043ff*/
          }
          while ( _R9 != 336 ); /*0x10300440a*/
          __asm { vmovdqa xmm5, xmmword ptr [r15] } /*0x10300440c*/
          for ( _R9 = 0; _R9 != 112; _R9 += 16 ) /*0x103004411*/
          {
            __asm /*0x103004414*/
            {
              vpxor xmm6, xmm5, [rbp+r9+var_110]
              vmovdqa xmmword ptr [rbp+r9+__dst], xmm6
            }
          }
          for ( i = 1; i != 14; ++i ) /*0x103004432*/
          {
            _R10 = 16 * i; /*0x10300443b*/
            __asm { vmovdqa xmm5, xmmword ptr [r15+r10] } /*0x10300443f*/
            for ( _R10 = 0; _R10 != 112; _R10 += 16 ) /*0x103004445*/
            {
              __asm /*0x103004448*/
              {
                vmovdqa xmm6, xmmword ptr [rbp+r10+__dst]
                vaesenc xmm6, xmm6, xmm5
                vmovdqa xmmword ptr [rbp+r10+__dst], xmm6
              }
            }
          }
          __asm { vmovdqa xmm5, xmmword ptr [r15+0E0h] } /*0x103004474*/
          for ( _R9 = 0; _R9 != 112; _R9 += 16 ) /*0x10300447d*/
          {
            __asm /*0x103004480*/
            {
              vmovdqa xmm6, xmmword ptr [rbp+r9+__dst]
              vaesenclast xmm6, xmm6, xmm5
              vpxor xmm6, xmm6, xmmword ptr [rdi+r9]
              vmovdqa xmmword ptr [rbp+r9+__dst], xmm6
            }
          }
          __asm /*0x1030044a9*/
          {
            vmovups ymm5, [rbp+__dst]
            vmovdqu ymm6, [rbp+var_80]
            vmovdqu ymm7, ymmword ptr [rbp+var_60]
            vmovdqu ymm8, ymmword ptr [rbp+var_60+10h]
            vmovdqu ymmword ptr [r13+r11+50h], ymm8
            vmovdqu ymmword ptr [r13+r11+40h], ymm7
            vmovdqu ymmword ptr [r13+r11+20h], ymm6
            vmovups ymmword ptr [r13+r11+0], ymm5
          }
          for ( _R9 = 0; _R9 != 112; _R9 += 16 ) /*0x1030044dc*/
          {
            __asm /*0x1030044df*/
            {
              vpshufb xmm5, xmm11, xmm0
              vmovdqa [rbp+r9+var_110], xmm5
              vpaddq xmm11, xmm11, xmm1
            }
          }
          _R11 = _R11 + 112; /*0x1030044fc*/
          _R9 = 336; /*0x103004500*/
          _R10 = v142; /*0x103004506*/
          do /*0x103004550*/
          {
            __asm /*0x103004509*/
            {
              vmovdqa xmm5, xmmword ptr [r15+r9]
              vmovdqu xmm6, xmmword ptr [r10]
              vpshufb xmm6, xmm6, xmm0
              vpclmulqdq xmm7, xmm6, xmm5, 11h
              vpxor xmm2, xmm7, xmm2
              vpclmulqdq xmm7, xmm6, xmm5, 0
              vpxor xmm3, xmm7, xmm3
              vpclmulqdq xmm7, xmm6, xmm5, 1
              vpxor xmm4, xmm7, xmm4
              vpclmulqdq xmm5, xmm6, xmm5, 10h
              vpxor xmm4, xmm4, xmm5
            }
            _R9 -= 16; /*0x103004541*/
            _R10 += 16; /*0x103004545*/
          }
          while ( _R9 != 224 ); /*0x103004550*/
          __asm /*0x103004552*/
          {
            vpsrldq xmm5, xmm4, 8
            vpslldq xmm4, xmm4, 8
            vpxor xmm3, xmm3, xmm4
          }
          _R9 = 0xC200000000000000LL; /*0x103004560*/
          __asm /*0x10300456a*/
          {
            vmovq xmm4, r9
            vpclmulqdq xmm6, xmm3, xmm4, 0
            vpshufd xmm3, xmm3, 4Eh ; 'N'
            vpxor xmm3, xmm6, xmm3
            vpclmulqdq xmm4, xmm3, xmm4, 0
            vpshufd xmm3, xmm3, 4Eh ; 'N'
            vpxor xmm3, xmm5, xmm3
            vpxor xmm2, xmm3, xmm2
            vpxor xmm2, xmm4, xmm2
            vmovdqa xmm3, xmmword ptr [r15]
          }
          for ( _R9 = 0; _R9 != 112; _R9 += 16 ) /*0x10300459a*/
          {
            __asm /*0x10300459d*/
            {
              vpxor xmm4, xmm3, [rbp+r9+var_110]
              vmovdqa xmmword ptr [rbp+r9+__dst], xmm4
            }
          }
          for ( j = 1; j != 14; ++j ) /*0x1030045bb*/
          {
            _R10 = 16 * j; /*0x1030045c4*/
            __asm { vmovdqa xmm3, xmmword ptr [r15+r10] } /*0x1030045c8*/
            for ( _R10 = 0; _R10 != 112; _R10 += 16 ) /*0x1030045ce*/
            {
              __asm /*0x1030045d1*/
              {
                vmovdqa xmm4, xmmword ptr [rbp+r10+__dst]
                vaesenc xmm4, xmm4, xmm3
                vmovdqa xmmword ptr [rbp+r10+__dst], xmm4
              }
            }
          }
          __asm { vmovdqa xmm3, xmmword ptr [r15+0E0h] } /*0x1030045fd*/
          for ( _R9 = 0; _R9 != 112; _R9 += 16 ) /*0x103004606*/
          {
            __asm /*0x103004609*/
            {
              vmovdqa xmm4, xmmword ptr [rbp+r9+__dst]
              vaesenclast xmm4, xmm4, xmm3
              vpxor xmm4, xmm4, xmmword ptr [rdx+r9]
              vmovdqa xmmword ptr [rbp+r9+__dst], xmm4
            }
          }
          __asm /*0x103004632*/
          {
            vmovdqu ymm3, [rbp+__dst]
            vmovdqu ymm4, [rbp+var_80]
            vmovdqu ymm5, ymmword ptr [rbp+var_60]
            vmovdqu ymm6, ymmword ptr [rbp+var_60+10h]
            vmovdqu ymmword ptr [r13+r11+50h], ymm6
            vmovdqu ymmword ptr [r13+r11+40h], ymm5
            vmovdqu ymmword ptr [r13+r11+20h], ymm4
            vmovdqu ymmword ptr [r13+r11+0], ymm3
          }
          v147 = _RCX + 224; /*0x103004665*/
          v141 += 224; /*0x103004669*/
          v146 += 224; /*0x10300466c*/
          v142 += 224; /*0x10300466f*/
          _R11 = _RCX; /*0x103004672*/
        }
        while ( _RCX + 224 <= _R14 ); /*0x103004678*/
        __asm { vmovdqa [rbp+var_130], xmm2 } /*0x10300467e*/
        _R11 = v139; /*0x103004686*/
      }
      else
      {
        _RCX = 0; /*0x103003ffc*/
      }
      v236 = _RCX + 112; /*0x103004689*/
      _R12 = 0xC200000000000000LL; /*0x103004690*/
      if ( _RCX + 112 <= _R14 ) /*0x10300469a*/
      {
        __asm { vmovdqa xmm2, [rbp+var_130] } /*0x1030046a4*/
        v240 = _RBX + _RCX + 16; /*0x1030046b0*/
        v241 = _RBX + _RCX; /*0x1030046b4*/
        __asm /*0x1030046b8*/
        {
          vmovdqa xmm0, cs:xmmword_1094BA2A0
          vpmovsxbq xmm1, cs:word_1094BA304
        }
        do /*0x103004881*/
        {
          _RAX = v236; /*0x1030046c9*/
          for ( _RDI = 0; _RDI != 112; _RDI += 16 ) /*0x1030046cc*/
          {
            __asm /*0x1030046ce*/
            {
              vpshufb xmm3, xmm11, xmm0
              vmovdqa [rbp+rdi+var_110], xmm3
              vpaddq xmm11, xmm11, xmm1
            }
          }
          __asm /*0x1030046ea*/
          {
            vmovdqa xmm4, xmmword ptr [r15+150h]
            vmovdqu xmm3, xmmword ptr [rbx+rcx]
            vpshufb xmm3, xmm3, xmm0
            vpxor xmm5, xmm2, xmm3
            vpclmulqdq xmm2, xmm5, xmm4, 11h
            vpclmulqdq xmm3, xmm5, xmm4, 0
            vpclmulqdq xmm6, xmm5, xmm4, 1
            vpclmulqdq xmm4, xmm5, xmm4, 10h
            vpxor xmm4, xmm4, xmm6
          }
          _RDI = 320; /*0x10300471d*/
          _R9 = v240; /*0x103004722*/
          do /*0x10300476c*/
          {
            __asm /*0x103004725*/
            {
              vmovdqa xmm5, xmmword ptr [r15+rdi]
              vmovdqu xmm6, xmmword ptr [r9]
              vpshufb xmm6, xmm6, xmm0
              vpclmulqdq xmm7, xmm6, xmm5, 11h
              vpxor xmm2, xmm7, xmm2
              vpclmulqdq xmm7, xmm6, xmm5, 0
              vpxor xmm3, xmm7, xmm3
              vpclmulqdq xmm7, xmm6, xmm5, 1
              vpxor xmm4, xmm7, xmm4
              vpclmulqdq xmm5, xmm6, xmm5, 10h
              vpxor xmm4, xmm4, xmm5
            }
            _RDI -= 16; /*0x10300475d*/
            _R9 += 16; /*0x103004761*/
          }
          while ( _RDI != 224 ); /*0x10300476c*/
          __asm /*0x10300476e*/
          {
            vpsrldq xmm5, xmm4, 8
            vpslldq xmm4, xmm4, 8
            vpxor xmm3, xmm3, xmm4
            vmovq xmm4, r12
            vpclmulqdq xmm6, xmm3, xmm4, 0
            vpshufd xmm3, xmm3, 4Eh ; 'N'
            vpxor xmm3, xmm6, xmm3
            vpclmulqdq xmm4, xmm3, xmm4, 0
            vpshufd xmm3, xmm3, 4Eh ; 'N'
            vpxor xmm3, xmm5, xmm3
            vpxor xmm3, xmm4, xmm3
            vmovdqa xmm4, xmmword ptr [r15]
          }
          for ( _RDI = 0; _RDI != 112; _RDI += 16 ) /*0x1030047a8*/
          {
            __asm /*0x1030047aa*/
            {
              vpxor xmm5, xmm4, [rbp+rdi+var_110]
              vmovdqa xmmword ptr [rbp+rdi+__dst], xmm5
            }
          }
          for ( k = 1; k != 14; ++k ) /*0x1030047c6*/
          {
            _R9 = 16 * k; /*0x1030047ce*/
            __asm { vmovdqa xmm4, xmmword ptr [r15+r9] } /*0x1030047d2*/
            for ( _R9 = 0; _R9 != 112; _R9 += 16 ) /*0x1030047d8*/
            {
              __asm /*0x1030047db*/
              {
                vmovdqa xmm5, xmmword ptr [rbp+r9+__dst]
                vaesenc xmm5, xmm5, xmm4
                vmovdqa xmmword ptr [rbp+r9+__dst], xmm5
              }
            }
          }
          __asm { vmovdqa xmm4, xmmword ptr [r15+0E0h] } /*0x103004807*/
          for ( _RDI = 0; _RDI != 112; _RDI += 16 ) /*0x103004810*/
          {
            __asm /*0x103004812*/
            {
              vmovdqa xmm5, xmmword ptr [rbp+rdi+__dst]
              vaesenclast xmm5, xmm5, xmm4
              vpxor xmm5, xmm5, xmmword ptr [rsi+rdi]
              vmovdqa xmmword ptr [rbp+rdi+__dst], xmm5
            }
          }
          __asm /*0x103004838*/
          {
            vpxor xmm2, xmm3, xmm2
            vmovdqu ymm3, [rbp+__dst]
            vmovdqu ymm4, [rbp+var_80]
            vmovdqu ymm5, ymmword ptr [rbp+var_60]
            vmovdqu ymm6, ymmword ptr [rbp+var_60+10h]
            vmovdqu ymmword ptr [r13+rcx+50h], ymm6
            vmovdqu ymmword ptr [r13+rcx+40h], ymm5
            vmovdqu ymmword ptr [r13+rcx+20h], ymm4
            vmovdqu ymmword ptr [r13+rcx+0], ymm3
          }
          v236 = _RAX + 112; /*0x10300486f*/
          v240 += 112; /*0x103004873*/
          v241 += 112; /*0x103004877*/
          _RCX = _RAX; /*0x10300487b*/
        }
        while ( _RAX + 112 <= _R14 ); /*0x103004881*/
        __asm { vmovdqa [rbp+var_130], xmm2 } /*0x103004887*/
      }
      else
      {
        _RAX = _RCX; /*0x10300469c*/
      }
      v297 = _RAX + 64; /*0x10300488f*/
      if ( _RAX + 64 <= _R14 ) /*0x103004896*/
      {
        __asm { vmovdqa xmm2, [rbp+var_130] } /*0x10300489c*/
        v299 = _RAX + _RBX + 16; /*0x1030048a8*/
        __asm /*0x1030048ac*/
        {
          vmovdqa xmm0, cs:xmmword_1094BA2A0
          vpmovsxbq xmm1, cs:word_1094BA304
        }
        do /*0x1030049ff*/
        {
          _RDX = _RAX; /*0x1030048bd*/
          _RAX = v297; /*0x1030048c0*/
          for ( _RSI = 0; _RSI != 64; _RSI += 16 ) /*0x1030048c3*/
          {
            __asm /*0x1030048c5*/
            {
              vpshufb xmm3, xmm11, xmm0
              vmovdqa [rbp+rsi+var_110], xmm3
              vpaddq xmm11, xmm11, xmm1
            }
          }
          __asm /*0x1030048e5*/
          {
            vmovdqa xmm4, xmmword ptr [r15+120h]
            vmovdqu xmm3, xmmword ptr [rbx+rdx]
            vpshufb xmm3, xmm3, xmm0
            vpxor xmm5, xmm2, xmm3
            vpclmulqdq xmm2, xmm5, xmm4, 11h
            vpclmulqdq xmm3, xmm5, xmm4, 0
            vpclmulqdq xmm6, xmm5, xmm4, 1
            vpclmulqdq xmm4, xmm5, xmm4, 10h
            vpxor xmm4, xmm4, xmm6
          }
          _RDI = 272; /*0x103004918*/
          _R9 = v299; /*0x10300491d*/
          do /*0x103004967*/
          {
            __asm /*0x103004920*/
            {
              vmovdqa xmm5, xmmword ptr [r15+rdi]
              vmovdqu xmm6, xmmword ptr [r9]
              vpshufb xmm6, xmm6, xmm0
              vpclmulqdq xmm7, xmm6, xmm5, 11h
              vpxor xmm2, xmm7, xmm2
              vpclmulqdq xmm7, xmm6, xmm5, 0
              vpxor xmm3, xmm7, xmm3
              vpclmulqdq xmm7, xmm6, xmm5, 1
              vpxor xmm4, xmm7, xmm4
              vpclmulqdq xmm5, xmm6, xmm5, 10h
              vpxor xmm4, xmm4, xmm5
            }
            _RDI -= 16; /*0x103004958*/
            _R9 += 16; /*0x10300495c*/
          }
          while ( _RDI != 224 ); /*0x103004967*/
          __asm /*0x103004969*/
          {
            vpsrldq xmm5, xmm4, 8
            vpslldq xmm4, xmm4, 8
            vpxor xmm3, xmm3, xmm4
            vmovq xmm4, r12
            vpclmulqdq xmm6, xmm3, xmm4, 0
            vpshufd xmm3, xmm3, 4Eh ; 'N'
            vpxor xmm3, xmm6, xmm3
            vpclmulqdq xmm4, xmm3, xmm4, 0
            vpshufd xmm3, xmm3, 4Eh ; 'N'
            vpxor xmm3, xmm5, xmm3
            vpxor xmm3, xmm4, xmm3
          }
          _RDX = &_R13[_RDX]; /*0x10300499e*/
          for ( m = 0; m != 4; ++m ) /*0x1030049a1*/
          {
            _R10 = 16 * m; /*0x1030049a6*/
            __asm /*0x1030049aa*/
            {
              vmovdqa xmm4, xmmword ptr [r15]
              vpxor xmm4, xmm4, [rbp+r10+var_110]
            }
            for ( n = 16; n != 224; n += 16 ) /*0x1030049b9*/
              __asm { vaesenc xmm4, xmm4, xmmword ptr [r15+r9] } /*0x1030049bf*/
            __asm /*0x1030049d2*/
            {
              vaesenclast xmm4, xmm4, xmmword ptr [r15+0E0h]
              vpxor xmm4, xmm4, xmmword ptr [rsi+r10]
              vmovdqu xmmword ptr [rdx+r10], xmm4
            }
          }
          __asm { vpxor xmm2, xmm3, xmm2 } /*0x1030049f0*/
          v297 = _RAX + 64; /*0x1030049f4*/
          v299 += 64; /*0x1030049f8*/
        }
        while ( _RAX + 64 <= _R14 ); /*0x1030049ff*/
        __asm { vmovdqa [rbp+var_130], xmm2 } /*0x103004a05*/
      }
      v346 = _RAX + 32; /*0x103004a0d*/
      if ( _RAX + 32 <= _R14 ) /*0x103004a14*/
      {
        __asm /*0x103004a1a*/
        {
          vmovdqa xmm4, [rbp+var_130]
          vmovdqa xmm0, cs:xmmword_1094BA2A0
          vpmovsxbq xmm1, cs:word_1094BA304
          vmovq xmm2, r12
          vpmovsxbq xmm3, cs:word_1094BA306
        }
        do /*0x103004b6a*/
        {
          _RCX = _RAX; /*0x103004a41*/
          _RAX = v346; /*0x103004a44*/
          __asm /*0x103004a47*/
          {
            vpshufb xmm5, xmm11, xmm0
            vmovdqa [rbp+var_110], xmm5
            vpaddq xmm5, xmm11, xmm1
            vpshufb xmm5, xmm5, xmm0
            vmovdqa [rbp+var_100], xmm5
          }
          __asm
          {
            vmovdqa xmm5, xmmword ptr [r15+0F0h]
            vmovdqa xmm6, xmmword ptr [r15+100h]
            vmovdqu xmm7, xmmword ptr [rbx+rcx]
            vmovdqu xmm8, xmmword ptr [rbx+rcx+10h]
            vpshufb xmm7, xmm7, xmm0
            vpxor xmm4, xmm4, xmm7
            vpclmulqdq xmm7, xmm4, xmm6, 11h
            vpclmulqdq xmm9, xmm4, xmm6, 0
            vpclmulqdq xmm10, xmm4, xmm6, 1
            vpclmulqdq xmm4, xmm4, xmm6, 10h
            vpxor xmm4, xmm10, xmm4
            vpshufb xmm6, xmm8, xmm0
            vpclmulqdq xmm8, xmm6, xmm5, 11h
            vpxor xmm7, xmm8, xmm7
            vpclmulqdq xmm8, xmm6, xmm5, 0
            vpxor xmm8, xmm8, xmm9
            vpclmulqdq xmm9, xmm6, xmm5, 1
            vpclmulqdq xmm5, xmm6, xmm5, 10h
            vpxor xmm5, xmm9, xmm5
            vpxor xmm4, xmm4, xmm5
            vpsrldq xmm5, xmm4, 8
            vpxor xmm5, xmm7, xmm5
            vpslldq xmm4, xmm4, 8
            vpxor xmm4, xmm8, xmm4
            vpclmulqdq xmm6, xmm4, xmm2, 0
            vpshufd xmm4, xmm4, 4Eh ; 'N'
            vpxor xmm4, xmm6, xmm4
            vpclmulqdq xmm6, xmm4, xmm2, 0
            vpxor xmm5, xmm5, xmm6
          }
          _RCX = &_R13[_RCX]; /*0x103004b04*/
          v386 = 1; /*0x103004b07*/
          _RDI = 0; /*0x103004b0a*/
          do /*0x103004b54*/
          {
            __asm /*0x103004b0c*/
            {
              vmovdqa xmm6, xmmword ptr [r15]
              vpxor xmm6, xmm6, [rbp+rdi+var_110]
            }
            for ( ii = 16; ii != 224; ii += 16 ) /*0x103004b1a*/
              __asm { vaesenc xmm6, xmm6, xmmword ptr [r15+r9] } /*0x103004b20*/
            __asm /*0x103004b33*/
            {
              vaesenclast xmm6, xmm6, xmmword ptr [r15+0E0h]
              vpxor xmm6, xmm6, xmmword ptr [rdx+rdi]
              vmovdqu xmmword ptr [rcx+rdi], xmm6
            }
            _RDI = 16; /*0x103004b46*/
            v393 = (v386 & 1) == 0; /*0x103004b4b*/
            v386 = 0; /*0x103004b4f*/
          }
          while ( !v393 ); /*0x103004b54*/
          __asm /*0x103004b56*/
          {
            vpshufd xmm4, xmm4, 4Eh ; 'N'
            vpxor xmm4, xmm5, xmm4
            vpaddq xmm11, xmm11, xmm3
          }
          v346 += 32; /*0x103004b63*/
        }
        while ( _RAX + 32 <= _R14 ); /*0x103004b6a*/
        __asm { vmovdqa [rbp+var_130], xmm4 } /*0x103004b70*/
      }
      v395 = _RAX + 16; /*0x103004b78*/
      if ( _RAX + 16 >= _R14 ) /*0x103004b7f*/
      {
        v400 = _RAX; /*0x103004c62*/
      }
      else
      {
        __asm /*0x103004b85*/
        {
          vmovdqa xmm4, [rbp+var_130]
          vmovdqa xmm0, cs:xmmword_1094BA2A0
          vmovq xmm1, r12
          vpmovsxbq xmm2, cs:word_1094BA304
        }
        do /*0x103004c52*/
        {
          v400 = v395; /*0x103004ba3*/
          __asm /*0x103004ba6*/
          {
            vmovdqa xmm5, xmmword ptr [r15+0F0h]
            vmovdqu xmm3, xmmword ptr [rbx+rax]
            vpshufb xmm6, xmm3, xmm0
            vpxor xmm4, xmm4, xmm6
            vpclmulqdq xmm6, xmm4, xmm5, 11h
            vpclmulqdq xmm7, xmm4, xmm5, 0
            vpclmulqdq xmm8, xmm4, xmm5, 1
            vpclmulqdq xmm4, xmm4, xmm5, 10h
            vpxor xmm4, xmm8, xmm4
            vpsrldq xmm5, xmm4, 8
            vpxor xmm5, xmm6, xmm5
            vpslldq xmm4, xmm4, 8
            vpxor xmm4, xmm7, xmm4
            vpclmulqdq xmm6, xmm4, xmm1, 0
            vpshufd xmm4, xmm4, 4Eh ; 'N'
            vpxor xmm4, xmm6, xmm4
            vpclmulqdq xmm6, xmm4, xmm1, 0
            vpxor xmm5, xmm6, xmm5
            vpshufb xmm6, xmm11, xmm0
            vpxor xmm6, xmm6, xmmword ptr [r15]
          }
          for ( jj = 16; jj != 224; jj += 16 ) /*0x103004c0e*/
            __asm { vaesenc xmm6, xmm6, xmmword ptr [r15+rcx] } /*0x103004c13*/
          __asm /*0x103004c26*/
          {
            vaesenclast xmm6, xmm6, xmmword ptr [r15+0E0h]
            vpshufd xmm4, xmm4, 4Eh ; 'N'
            vpxor xmm4, xmm5, xmm4
            vpxor xmm3, xmm6, xmm3
            vmovdqu xmmword ptr [r13+rax+0], xmm3
            vpaddq xmm11, xmm11, xmm2
          }
          v395 = v400 + 16; /*0x103004c47*/
          _RAX = v400; /*0x103004c4c*/
        }
        while ( v400 + 16 < _R14 ); /*0x103004c52*/
        __asm { vmovdqa [rbp+var_130], xmm4 } /*0x103004c58*/
      }
      __asm /*0x103004c65*/
      {
        vmovq xmm0, r11
        vmovq xmm1, r14
        vpunpcklqdq xmm0, xmm1, xmm0
        vpblendw xmm1, xmm12, cs:xmmword_1096F8570, 0C0h
        vpsllq xmm3, xmm0, 3
        vmovdqa xmm2, xmmword ptr [r15]
        vpxor xmm0, xmm2, xmm1
      }
      for ( kk = 16; kk != 224; kk += 16 ) /*0x103004c8b*/
        __asm { vaesenc xmm0, xmm0, xmmword ptr [r15+rax] } /*0x103004c90*/
      __asm /*0x103004ca2*/
      {
        vmovdqa xmm1, xmmword ptr [r15+0E0h]
        vaesenclast xmm5, xmm0, xmm1
      }
      if ( _R14 == v400 ) /*0x103004cb6*/
      {
        __asm /*0x103004cb8*/
        {
          vmovdqa xmm0, xmmword ptr [r15+0F0h]
          vpxor xmm1, xmm3, [rbp+var_130]
          vpclmulqdq xmm2, xmm1, xmm0, 11h
          vpclmulqdq xmm3, xmm1, xmm0, 0
          vpclmulqdq xmm4, xmm1, xmm0, 1
          vpclmulqdq xmm0, xmm1, xmm0, 10h
          vpxor xmm0, xmm0, xmm4
          vpsrldq xmm1, xmm0, 8
          vpxor xmm1, xmm2, xmm1
          vpslldq xmm0, xmm0, 8
          vpxor xmm0, xmm3, xmm0
        }
        _RAX = 0xC200000000000000LL; /*0x103004cf7*/
        __asm /*0x103004d01*/
        {
          vmovq xmm2, rax
          vpclmulqdq xmm3, xmm0, xmm2, 0
          vpshufd xmm0, xmm0, 4Eh ; 'N'
          vpxor xmm0, xmm3, xmm0
          vpclmulqdq xmm2, xmm0, xmm2, 0
          vpshufd xmm0, xmm0, 4Eh ; 'N'
          vpxor xmm0, xmm1, xmm0
          vpxor xmm0, xmm2, xmm0
        }
      }
      else
      {
        __asm /*0x103004d2d*/
        {
          vmovdqa [rbp+var_180], xmm1
          vmovdqa [rbp+var_190], xmm2
          vmovdqa [rbp+var_1A0], xmm5
          vmovdqa [rbp+var_150], xmm11
          vmovdqa [rbp+var_160], xmm3
          vpshufb xmm0, xmm3, cs:xmmword_1094BA2A0
          vmovdqa [rbp+var_170], xmm0
        }
        __asm { vzeroupper }
        memcpy(&__dst, __src: (const void *)(v400 + _RBX), __n: _R14 - v400); /*0x103004d7c*/
        v456 = _R14 - v400; /*0x103004d81*/
        if ( _R14 - v400 <= 0xF ) /*0x103004d88*/
        {
          __bzero(a1: (__int64)&__dst + _R14 - v400, a2: v400 - _R14 + 16); /*0x103004d9f*/
          v456 = _R14 - v400; /*0x103004da4*/
        }
        __asm /*0x103004da7*/
        {
          vmovaps xmm0, [rbp+var_170]
          vmovaps xmmword ptr [rbp+__dst+10h], xmm0
          vmovdqa xmm1, xmmword ptr [r15+0F0h]
          vmovdqa xmm2, xmmword ptr [r15+100h]
          vmovdqa xmm0, xmmword ptr [rbp+__dst]
          vmovdqa xmm3, cs:xmmword_1094BA2A0
          vpshufb xmm4, xmm0, xmm3
          vpxor xmm4, xmm4, [rbp+var_130]
          vpclmulqdq xmm5, xmm4, xmm2, 11h
          vpclmulqdq xmm6, xmm4, xmm2, 0
          vpclmulqdq xmm7, xmm4, xmm2, 1
          vpclmulqdq xmm2, xmm4, xmm2, 10h
          vpxor xmm2, xmm2, xmm7
          vmovdqa xmm7, [rbp+var_160]
          vpclmulqdq xmm4, xmm7, xmm1, 11h
          vpxor xmm4, xmm4, xmm5
          vpclmulqdq xmm5, xmm7, xmm1, 0
          vpxor xmm5, xmm5, xmm6
          vpclmulqdq xmm6, xmm7, xmm1, 1
          vpclmulqdq xmm1, xmm7, xmm1, 10h
          vpxor xmm1, xmm6, xmm1
          vpxor xmm1, xmm2, xmm1
          vpsrldq xmm2, xmm1, 8
          vpxor xmm2, xmm4, xmm2
          vpslldq xmm1, xmm1, 8
          vpxor xmm1, xmm5, xmm1
        }
        _RAX = 0xC200000000000000LL; /*0x103004e44*/
        __asm /*0x103004e4e*/
        {
          vmovq xmm4, rax
          vpclmulqdq xmm5, xmm1, xmm4, 0
          vpshufd xmm1, xmm1, 4Eh ; 'N'
          vpxor xmm1, xmm5, xmm1
          vpclmulqdq xmm4, xmm1, xmm4, 0
          vpshufd xmm1, xmm1, 4Eh ; 'N'
          vpxor xmm1, xmm2, xmm1
          vpxor xmm1, xmm1, xmm4
          vmovdqa [rbp+var_160], xmm1
          vmovdqa xmm1, [rbp+var_150]
          vpshufb xmm1, xmm1, xmm3
          vpxor xmm1, xmm1, [rbp+var_190]
        }
        for ( mm = 16; mm != 224; mm += 16 ) /*0x103004e92*/
          __asm { vaesenc xmm1, xmm1, xmmword ptr [r15+rax] } /*0x103004e97*/
        __asm /*0x103004ea9*/
        {
          vaesenclast xmm1, xmm1, [rbp+var_180]
          vpxor xmm0, xmm1, xmm0
        }
        _RSI = &__dst; /*0x103004eb6*/
        __asm { vmovdqa xmmword ptr [rsi], xmm0 } /*0x103004ebd*/
        memcpy(__dst: &_R13[v400], __src: &__dst, __n: v456); /*0x103004ec7*/
        a6 = v507; /*0x103004ecc*/
        __asm /*0x103004ed3*/
        {
          vmovdqa xmm5, [rbp+var_1A0]
          vmovdqa xmm0, [rbp+var_160]
        }
      }
      __asm /*0x103004ee3*/
      {
        vpshufb xmm0, xmm0, cs:xmmword_1094BA2A0
        vpxor xmm0, xmm5, xmm0
      }
      _RSI = &v509; /*0x103004ef0*/
      __asm { vmovdqa xmmword ptr [rsi], xmm0 } /*0x103004ef7*/
      __asm { vzeroupper }
      if ( (unsigned int)crypto_verify_16(a1: a6, a2: &v509) != 0 ) /*0x103004f08*/
      {
        sodium_memzero(a1: &v509, a2: 16); /*0x103004f16*/
        memset(__b: _R13, __c: 208, __len: _R14); /*0x103004f26*/
        return 0xFFFFFFFFLL; /*0x103004f2b*/
      }
      else
      {
        return 0; /*0x103004f32*/
      }
    }
  }
  else if ( a5 <= 0xFFFFFFFFFFFFFF1FLL /*0x10300404c*/
         && a8 <= 0xFFFFFFFFFFFFFF1FLL
         && (a8 + 15) >> 4 <= a8
         && a5 <= 0xFFFFFFFD0LL
         && (a5 + 15) >> 4 <= a5 )
  {
    v507 = a6; /*0x103004052*/
    __asm { vxorps xmm0, xmm0, xmm0 } /*0x103004059*/
    _RSI = &__dst; /*0x10300405d*/
    __asm /*0x103004064*/
    {
      vmovaps xmmword ptr [rsi], xmm0
      vmovq xmm0, qword ptr [rdx]
      vpinsrd xmm0, xmm0, dword ptr [rdx+8], 2
      vmovdqa [rbp+var_150], xmm0
    }
    gh_ad_blocks(a1: a10, a2: &__dst, a3: a7, a4: a8 & 0xFFFFFFFFFFFFFFF0LL); /*0x103004088*/
    if ( (a8 & 0xF) != 0 ) /*0x103004098*/
    {
      _RCX = v510; /*0x10300409e*/
      __asm /*0x1030040a5*/
      {
        vpxor xmm0, xmm0, xmm0
        vmovdqa xmmword ptr [rcx], xmm0
      }
      __memcpy_chk(a1: v510, a2: a8 + a7 - (a8 & 0xF), a3: a8 & 0xF, a4: 16); /*0x1030040be*/
      _RAX = v510; /*0x1030040c3*/
      __asm /*0x1030040ca*/
      {
        vmovdqa xmm0, xmmword ptr [rax]
        vpshufb xmm0, xmm0, cs:xmmword_1094BA2A0
        vpxor xmm0, xmm0, xmmword ptr [rbp+__dst]
        vmovdqa xmm1, xmmword ptr [r15+0F0h]
        vpclmulqdq xmm2, xmm0, xmm1, 11h
        vpclmulqdq xmm3, xmm0, xmm1, 0
        vpclmulqdq xmm4, xmm0, xmm1, 1
        vpclmulqdq xmm0, xmm0, xmm1, 10h
        vpxor xmm0, xmm0, xmm4
        vpsrldq xmm1, xmm0, 8
        vpxor xmm1, xmm2, xmm1
        vpslldq xmm0, xmm0, 8
        vpxor xmm0, xmm3, xmm0
      }
      _RAX = 0xC200000000000000LL; /*0x103004116*/
      __asm /*0x103004120*/
      {
        vmovq xmm2, rax
        vpclmulqdq xmm3, xmm0, xmm2, 0
        vpshufd xmm0, xmm0, 4Eh ; 'N'
        vpxor xmm0, xmm3, xmm0
        vpclmulqdq xmm2, xmm0, xmm2, 0
        vpshufd xmm0, xmm0, 4Eh ; 'N'
        vpxor xmm0, xmm1, xmm0
        vpxor xmm0, xmm2, xmm0
        vmovdqa xmmword ptr [rbp+__dst], xmm0
      }
    }
    gh_ad_blocks(a1: a10, a2: &__dst, a3: _RBX, a4: _R14 & 0xFFFFFFFF0LL); /*0x103004166*/
    if ( (_R14 & 0xF) != 0 ) /*0x103004172*/
    {
      __asm { vpxor xmm0, xmm0, xmm0 } /*0x103004178*/
      _R12 = v510; /*0x10300417c*/
      __asm { vmovdqa xmmword ptr [r12], xmm0 } /*0x103004183*/
      __memcpy_chk(a1: v510, a2: _R14 + _RBX - (_R14 & 0xF), a3: _R14 & 0xF, a4: 16); /*0x10300419a*/
      __asm /*0x10300419f*/
      {
        vmovdqa xmm0, xmmword ptr [r12]
        vpshufb xmm0, xmm0, cs:xmmword_1094BA2A0
        vpxor xmm0, xmm0, xmmword ptr [rbp+__dst]
        vmovdqa xmm1, xmmword ptr [r15+0F0h]
        vpclmulqdq xmm2, xmm0, xmm1, 11h
        vpclmulqdq xmm3, xmm0, xmm1, 0
        vpclmulqdq xmm4, xmm0, xmm1, 1
        vpclmulqdq xmm0, xmm0, xmm1, 10h
        vpxor xmm0, xmm0, xmm4
        vpsrldq xmm1, xmm0, 8
        vpxor xmm1, xmm2, xmm1
        vpslldq xmm0, xmm0, 8
        vpxor xmm0, xmm3, xmm0
      }
      _RAX = 0xC200000000000000LL; /*0x1030041ed*/
      __asm /*0x1030041f7*/
      {
        vmovq xmm2, rax
        vpclmulqdq xmm3, xmm0, xmm2, 0
        vpshufd xmm0, xmm0, 4Eh ; 'N'
        vpxor xmm0, xmm3, xmm0
        vpclmulqdq xmm2, xmm0, xmm2, 0
        vpshufd xmm0, xmm0, 4Eh ; 'N'
        vpxor xmm0, xmm1, xmm0
        vpxor xmm0, xmm2, xmm0
        vmovdqa xmmword ptr [rbp+__dst], xmm0
      }
    }
    __asm /*0x103004226*/
    {
      vmovdqa xmm0, [rbp+var_150]
      vpblendw xmm0, xmm0, cs:xmmword_1096F8570, 0C0h
    }
    _R14 = 8 * _R14; /*0x103004238*/
    __asm { vpxor xmm0, xmm0, xmmword ptr [r15] } /*0x10300423c*/
    for ( nn = 16; nn != 224; nn += 16 ) /*0x103004241*/
      __asm { vaesenc xmm0, xmm0, xmmword ptr [r15+rax] } /*0x10300424a*/
    _RCX = 8 * a8; /*0x10300425c*/
    __asm /*0x103004260*/
    {
      vmovq xmm1, r14
      vmovq xmm2, rcx
      vpunpcklqdq xmm1, xmm1, xmm2
      vaesenclast xmm0, xmm0, xmmword ptr [r15+0E0h]
      vmovdqa xmm2, xmmword ptr [r15+0F0h]
      vpxor xmm1, xmm1, xmmword ptr [rbp+__dst]
      vpclmulqdq xmm3, xmm1, xmm2, 11h
      vpclmulqdq xmm4, xmm1, xmm2, 0
      vpclmulqdq xmm5, xmm1, xmm2, 1
      vpclmulqdq xmm1, xmm1, xmm2, 10h
      vpxor xmm1, xmm1, xmm5
      vpslldq xmm2, xmm1, 8
      vpxor xmm2, xmm4, xmm2
    }
    _RAX = 0xC200000000000000LL; /*0x1030042ad*/
    __asm /*0x1030042b7*/
    {
      vmovq xmm4, rax
      vpclmulqdq xmm5, xmm2, xmm4, 0
      vpshufd xmm2, xmm2, 4Eh ; 'N'
      vpxor xmm2, xmm5, xmm2
      vpclmulqdq xmm4, xmm2, xmm4, 0
      vpxor xmm3, xmm4, xmm3
      vpshufb xmm3, xmm3, cs:xmmword_1094BA2A0
      vpshufb xmm1, xmm1, cs:xmmword_1094BA2E0
      vpshufb xmm2, xmm2, cs:xmmword_1094BA2F0
      vpxor xmm1, xmm1, xmm2
      vpxor xmm0, xmm0, xmm1
      vpxor xmm0, xmm0, xmm3
    }
    _RBX = v510; /*0x1030042fc*/
    __asm { vmovdqa xmmword ptr [rbx], xmm0 } /*0x103004303*/
    v138 = crypto_verify_16(a1: v507, a2: v510); /*0x103004316*/
    sodium_memzero(a1: v510, a2: 16); /*0x103004321*/
    return v138; /*0x103004326*/
  }
  return result; /*0x103004f44*/
}

// Address: 0x103004f5b | Name: _crypto_aead_aes256gcm_decrypt_afternm
__int64 __fastcall crypto_aead_aes256gcm_decrypt_afternm(
        char *a1,
        unsigned __int64 *a2,
        __m128 a3,
        __int64 a4,
        __int64 a5,
        unsigned __int64 a6,
        __int64 a7,
        unsigned __int64 a8,
        __int64 a9,
        __int64 a10)
{
  __int64 result; // rax
  unsigned __int64 v13; // rbx
  unsigned __int64 v14; // rcx

  result = 0xFFFFFFFFLL; /*0x103004f68*/
  if ( a6 >= 0x10 ) /*0x103004f71*/
    result = crypto_aead_aes256gcm_decrypt_detached_afternm( /*0x103004f92*/
               __b: a1,
               _XMM0: a3,
               a3: (__int64)a2,
               a4: a5,
               a5: a6 - 16,
               a6: (__m128i *)(a6 + a5 - 16),
               a7,
               a8,
               a9,
               a10);
  if ( a2 != nullptr ) /*0x103004f9e*/
  {
    v13 = a6 - 16; /*0x103004fa0*/
    v14 = 0; /*0x103004fa4*/
    if ( (_DWORD)result == 0 ) /*0x103004fa8*/
      v14 = v13; /*0x103004fa8*/
    *a2 = v14; /*0x103004fac*/
  }
  return result; /*0x103004faf*/
}

// Address: 0x103004fb4 | Name: _crypto_aead_aes256gcm_decrypt_detached
__int64 __fastcall crypto_aead_aes256gcm_decrypt_detached(
        char *__b,
        __int64 a2,
        const char *a3,
        unsigned __int64 a4,
        __m128i *a5,
        const char *a6,
        __int128 a7,
        __int64 a8)
{
  __int64 v13; // rsi
  __int128 v15; // [rsp+0h] [rbp-250h]
  __int64 v17[64]; // [rsp+20h] [rbp-230h] BYREF

  _mm_prefetch(__b, 2); /*0x103004fed*/
  _mm_prefetch(a3, 2); /*0x103004ff0*/
  _mm_prefetch(a6, 2); /*0x103004ff3*/
  crypto_aead_aes256gcm_beforenm(_RDI: (__int64)v17, _RSI: a8); /*0x103005001*/
  __asm /*0x10300500b*/
  {
    vmovaps xmm0, [rbp+arg_0]
    vmovups [rsp+250h+var_250], xmm0
  }
  return crypto_aead_aes256gcm_decrypt_detached_afternm( /*0x10300503d*/
           __b,
           _XMM0,
           a3: v13,
           a4: (__int64)a3,
           a5: a4,
           a6: a5,
           a7: (__int64)a6,
           a8: v15,
           a9: *((__int64 *)&v15 + 1),
           a10: (__int64)v17);
}

// Address: 0x103005054 | Name: _crypto_aead_aes256gcm_decrypt
__int64 __fastcall crypto_aead_aes256gcm_decrypt(
        char *__b,
        unsigned __int64 *a2,
        __int64 a3,
        const char *a4,
        unsigned __int64 a5,
        const char *a6,
        unsigned __int64 a7,
        __int64 a8,
        __int64 a9)
{
  __int64 v13; // rsi
  __m128 v14; // xmm0
  unsigned int v15; // r15d
  unsigned __int64 v16; // rbx
  unsigned __int64 v17; // rax
  __int64 v20[64]; // [rsp+10h] [rbp-230h] BYREF

  _mm_prefetch(__b, 2); /*0x10300508d*/
  _mm_prefetch(a4, 2); /*0x103005090*/
  _mm_prefetch(a6, 2); /*0x103005093*/
  crypto_aead_aes256gcm_beforenm(_RDI: (__int64)v20, _RSI: a9); /*0x10300509e*/
  v15 = -1; /*0x1030050a3*/
  if ( a5 >= 0x10 ) /*0x1030050ad*/
    v15 = crypto_aead_aes256gcm_decrypt_detached_afternm( /*0x1030050df*/
            __b,
            _XMM0: v14,
            a3: v13,
            (__int64)a4,
            a5: a5 - 16,
            a6: (__m128i *)&a4[a5 - 16],
            a7: (__int64)a6,
            a8: a7,
            a9: a8,
            a10: (__int64)v20);
  if ( a2 != nullptr ) /*0x1030050ec*/
  {
    v16 = a5 - 16; /*0x1030050ee*/
    v17 = 0; /*0x1030050f2*/
    if ( v15 == 0 ) /*0x1030050f7*/
      v17 = v16; /*0x1030050f7*/
    *a2 = v17; /*0x1030050fb*/
  }
  sodium_memzero(a1: v20, a2: 512); /*0x10300510a*/
  return v15; /*0x103005122*/
}

// Address: 0x103005139 | Name: _crypto_aead_aes256gcm_is_available
__int64 crypto_aead_aes256gcm_is_available()
{
  int has_pclmul; // ebx
  __int64 v1; // rdi
  int v2; // r14d
  __int64 v3; // rdi

  has_pclmul = sodium_runtime_has_pclmul(); /*0x103005145*/
  v2 = has_pclmul & sodium_runtime_has_aesni(a1: v1); /*0x10300514f*/
  return v2 & (unsigned int)sodium_runtime_has_avx(a1: v3); /*0x10300515a*/
}

// Address: 0x1030240b5 | Name: __ZL14calculateScoreN3RBX10RbxStorage15StorageCategoryEyy
__int64 __fastcall calculateScore(__int64 a1, __int64 a2, __int64 a3)
{
  int v5; // eax
  __int64 v6; // rcx
  int v7; // eax

  v5 = RBX::RbxStorage::storageCategoryToPriority(a1); /*0x1030240c2*/
  v6 = 1; /*0x1030240c7*/
  if ( v5 >= 2 ) /*0x1030240cf*/
  {
    v7 = v5 - 1; /*0x1030240d8*/
    do /*0x1030240e0*/
    {
      v6 *= DFInt::RbxStoragePriorityExponentialDifference; /*0x1030240da*/
      --v7; /*0x1030240de*/
    }
    while ( v7 != 0 ); /*0x1030240e0*/
  }
  return v6 * DFInt::SQLiteCacheReplacementPolicyPriorityScalar /*0x103024109*/
       + a2 * DFInt::SQLiteCacheReplacementPolicyATimeScalar
       + a3 * DFInt::SQLiteCacheReplacementPolicyHitsScalar;
}

// Address: 0x1030294be | Name: ___cxx_global_array_dtor_3
void __fastcall __cxx_global_array_dtor_3(void *a1)
{
  __int64 i; // rbx

  for ( i = 704; i != -64; i -= 64 ) /*0x1030294c5*/
    std::recursive_mutex::~recursive_mutex(this: (std::recursive_mutex *)((char *)&`anonymous namespace'::g_mutexes + i)); /*0x1030294d5*/
}

// Address: 0x10302c272 | Name: __Z19cleanReasonToStringN3RBX10RbxStorage11CleanReasonE
__int64 __fastcall cleanReasonToString(__int64 a1, unsigned int a2, __int64 a3, int *a4)
{
  const char *v5; // rsi

  if ( a2 > 2 ) /*0x10302c27e*/
  {
    v5 = "Unknown"; /*0x10302c292*/
  }
  else
  {
    a4 = dword_1094BACFC; /*0x10302c282*/
    v5 = (char *)dword_1094BACFC + dword_1094BACFC[a2]; /*0x10302c28d*/
  }
  std::string::basic_string[abi:ne200100]<0>(a1, a2: v5, a3, a4); /*0x10302c29c*/
  return a1; /*0x10302c2a8*/
}

// Address: 0x1030393e1 | Name: _createAggContext
__int64 __fastcall createAggContext(__int64 a1, int a2)
{
  __int64 v2; // rbx
  __int64 v5; // rdi

  v2 = *(_QWORD *)(a1 + 16); /*0x1030393eb*/
  if ( a2 <= 0 ) /*0x1030393f1*/
  {
    if ( (*(_BYTE *)(v2 + 21) & 0x90) != 0 ) /*0x103039415*/
      vdbeMemClearExternAndSetNull(a1: *(_QWORD *)(a1 + 16)); /*0x10303941a*/
    else
      *(_WORD *)(v2 + 20) = 1; /*0x103039449*/
    *(_QWORD *)(v2 + 8) = 0; /*0x10303944f*/
  }
  else
  {
    if ( *(_DWORD *)(v2 + 32) >= a2 ) /*0x1030393fc*/
    {
      v5 = *(_QWORD *)(v2 + 40); /*0x103039421*/
      *(_QWORD *)(v2 + 8) = v5; /*0x103039425*/
    }
    else
    {
      sqlite3VdbeMemGrow(a1: *(_QWORD *)(a1 + 16), (unsigned int)a2, a3: 0); /*0x103039406*/
      v5 = *(_QWORD *)(v2 + 8); /*0x10303940b*/
    }
    *(_WORD *)(v2 + 20) = 0x8000; /*0x103039429*/
    *(_QWORD *)v2 = *(_QWORD *)(a1 + 8); /*0x103039433*/
    if ( v5 != 0 ) /*0x103039439*/
    {
      __bzero(a1: v5, (unsigned int)a2); /*0x10303943e*/
      return *(_QWORD *)(v2 + 8); /*0x103039447*/
    }
  }
  return 0; /*0x10303945d*/
}

// Address: 0x10303961f | Name: _columnMem
void *__fastcall columnMem(__int64 *a1, unsigned int a2)
{
  void *v2; // rbx
  __int64 v5; // rdi
  __int64 v6; // rax
  __int64 v7; // rdi

  v2 = &columnNullValue_nullMem; /*0x103039629*/
  if ( a1 != nullptr ) /*0x103039633*/
  {
    v5 = *(_QWORD *)(*a1 + 24); /*0x10303963e*/
    if ( v5 != 0 ) /*0x103039645*/
      xmmword_10CD98240(a1: v5); /*0x103039647*/
    v6 = a1[20]; /*0x10303964d*/
    if ( v6 != 0 && *((unsigned __int16 *)a1 + 92) > a2 ) /*0x103039664*/
    {
      return (void *)(56LL * a2 + v6); /*0x103039670*/
    }
    else
    {
      v7 = *a1; /*0x103039675*/
      *(_DWORD *)(v7 + 80) = 25; /*0x103039678*/
      sqlite3ErrorFinish(a1: v7, a2: 25); /*0x103039684*/
    }
  }
  return v2; /*0x103039690*/
}

// Address: 0x103039697 | Name: _columnMallocFailure
__int64 __fastcall columnMallocFailure(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  __int64 v5; // rdi
  __int64 v6; // rsi
  __int64 v7; // rdi

  if ( a1 != 0 ) /*0x1030396a0*/
  {
    v5 = *(_QWORD *)a1; /*0x1030396a5*/
    v6 = *(unsigned int *)(a1 + 52); /*0x1030396a8*/
    if ( (_DWORD)v6 != 0 || (result = 0, *(_BYTE *)(v5 + 103) != 0) ) /*0x1030396b5*/
    {
      result = apiHandleError(a1: v5, a2: v6); /*0x1030396b7*/
      v5 = *(_QWORD *)a1; /*0x1030396bc*/
    }
    *(_DWORD *)(a1 + 52) = result; /*0x1030396bf*/
    v7 = *(_QWORD *)(v5 + 24); /*0x1030396c2*/
    if ( v7 != 0 ) /*0x1030396c9*/
      return xmmword_10CD98250(a1: v7, a2: v6, a3); /*0x1030396d1*/
  }
  return result; /*0x1030396db*/
}

// Address: 0x103039841 | Name: _columnName
__int16 *__fastcall columnName(__int64 *a1, __int64 a2, __int64 a3)
{
  unsigned int v3; // r14d
  unsigned int v4; // ebx
  __int64 v6; // r12
  __int64 v7; // rdi
  int v8; // eax
  __int64 v9; // rax
  __int16 *v10; // rbx
  unsigned __int8 v11; // r13
  __int64 v12; // rax
  __int16 v14; // ax
  __int64 v15; // rdi

  if ( a1 == nullptr ) /*0x103039852*/
  {
    v10 = nullptr; /*0x1030398de*/
    sqlite3_log( /*0x1030398ec*/
      iErrCode: 21,
      zFormat: "%s at line %d of [%.10s]",
      "misuse",
      93879,
      "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
    return v10; /*0x1030398f1*/
  }
  v3 = a2; /*0x103039854*/
  if ( (int)a2 < 0 ) /*0x103039859*/
    return nullptr; /*0x1030398f8*/
  v4 = a3; /*0x10303985f*/
  v6 = *a1; /*0x103039864*/
  v7 = *(_QWORD *)(*a1 + 24); /*0x103039867*/
  if ( v7 != 0 ) /*0x10303986f*/
    xmmword_10CD98240(a1: v7); /*0x103039871*/
  v8 = (*((_DWORD *)a1 + 48) >> 2) & 3; /*0x103039881*/
  if ( v8 == 0 ) /*0x103039884*/
  {
    if ( *((unsigned __int16 *)a1 + 92) > v3 ) /*0x103039908*/
    {
      v11 = *(_BYTE *)(v6 + 103); /*0x10303990a*/
      v12 = sqlite3ValueText(a1: a1[19] + 56LL * v3, a2: ((v4 | 0x200000000uLL) - 1) >> 32); /*0x103039928*/
      if ( *(_BYTE *)(v6 + 103) <= v11 ) /*0x103039932*/
      {
        v10 = (__int16 *)v12; /*0x10303996f*/
        goto LABEL_21; /*0x103039972*/
      }
      if ( *(_DWORD *)(v6 + 220) == 0 ) /*0x10303993d*/
      {
        *(_BYTE *)(v6 + 103) = 0; /*0x10303993f*/
        *(_DWORD *)(v6 + 384) = 0; /*0x103039945*/
        if ( (*(_DWORD *)(v6 + 392))-- == 1 ) /*0x103039951*/
          v14 = *(_WORD *)(v6 + 398); /*0x103039974*/
        else
          v14 = 0; /*0x10303995b*/
        *(_WORD *)(v6 + 396) = v14; /*0x10303997d*/
      }
    }
  }
  else if ( 4 * (unsigned int)((_WORD)v8 == 1) + 4 > v3 ) /*0x103039899*/
  {
    v9 = v3 + 8 * v8 - 8; /*0x1030398a3*/
    if ( v4 != 0 ) /*0x1030398a8*/
      v10 = &azExplainColNames16data[iExplainColNames16[v9]]; /*0x1030398c0*/
    else
      v10 = (__int16 *)((char *)azExplainColNames8_rel + azExplainColNames8_rel[v9]); /*0x10303996a*/
LABEL_21:
    v15 = *(_QWORD *)(v6 + 24); /*0x103039988*/
    if ( v15 != 0 ) /*0x103039990*/
      xmmword_10CD98250(a1: v15, a2, a3); /*0x103039992*/
    return v10; /*0x10303999f*/
  }
  v10 = nullptr; /*0x103039986*/
  goto LABEL_21; /*0x103039986*/
}

// Address: 0x10303cd9c | Name: _createModule
__int64 __fastcall createModule(__int64 a1, __int64 a2, __int64 a3, __int64 a4, void (__fastcall *a5)(__int64))
{
  __int64 v10; // rdi
  __int64 v11; // rdx
  __int64 v12; // rsi
  unsigned int v13; // r12d
  __int64 v14; // rdi

  v10 = *(_QWORD *)(a1 + 24); /*0x10303cdb9*/
  if ( v10 != 0 ) /*0x10303cdc0*/
    xmmword_10CD98240(a1: v10); /*0x10303cdc2*/
  sqlite3VtabCreateModule(a1, a2, a3, a4, a5); /*0x10303cdd7*/
  if ( *(_BYTE *)(a1 + 103) != 0 ) /*0x10303cde0*/
  {
    v13 = apiHandleError(a1, a2: 0); /*0x10303cdec*/
    if ( v13 != 0 && a5 != nullptr ) /*0x10303cdf7*/
      a5(a1: a4); /*0x10303ce01*/
  }
  else
  {
    v13 = 0; /*0x10303ce06*/
  }
  v14 = *(_QWORD *)(a1 + 24); /*0x10303ce09*/
  if ( v14 != 0 ) /*0x10303ce10*/
    xmmword_10CD98250(a1: v14, a2: v12, a3: v11); /*0x10303ce12*/
  return v13; /*0x10303ce1f*/
}

// Address: 0x103040823 | Name: _createFunctionApi
__int64 __fastcall createFunctionApi(
        __int64 a1,
        int a2,
        int a3,
        int a4,
        __int64 a5,
        int a6,
        __int64 a7,
        __int64 a8,
        __int64 a9,
        __int64 a10,
        void (__fastcall *a11)(_QWORD))
{
  void (__fastcall *v16)(_QWORD); // rax
  __int64 v17; // rdi
  __int64 v18; // rax
  _DWORD *v19; // r12
  __int64 v20; // rdx
  __int64 v21; // rsi
  unsigned int Func; // r15d
  unsigned int v23; // r14d
  __int64 v24; // rdi
  int v26; // [rsp+8h] [rbp-38h]

  if ( (unsigned int)sqlite3SafetyCheckOk() == 0 ) /*0x10304084d*/
  {
    v23 = 21; /*0x1030408fe*/
    sqlite3_log( /*0x103040910*/
      iErrCode: 21,
      zFormat: "%s at line %d of [%.10s]",
      "misuse",
      186964,
      "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
    return v23; /*0x103040915*/
  }
  v16 = a11; /*0x103040853*/
  v17 = *(_QWORD *)(a1 + 24); /*0x103040857*/
  if ( v17 != 0 ) /*0x10304085e*/
  {
    xmmword_10CD98240(a1: v17); /*0x103040860*/
    v16 = a11; /*0x103040866*/
  }
  if ( v16 != nullptr ) /*0x10304086d*/
  {
    v26 = a6; /*0x103040873*/
    v18 = sqlite3Malloc(a1: 24); /*0x10304087c*/
    if ( v18 == 0 ) /*0x103040884*/
    {
      sqlite3OomFault(a1); /*0x10304095a*/
      a11(a1: a5); /*0x103040962*/
      Func = 1; /*0x103040965*/
LABEL_14:
      v23 = apiHandleError(a1, a2: Func); /*0x10304096b*/
      goto LABEL_15; /*0x103040976*/
    }
    v19 = (_DWORD *)v18; /*0x10304088a*/
    *(_DWORD *)v18 = 0; /*0x10304088d*/
    *(_QWORD *)(v18 + 8) = a11; /*0x103040897*/
    *(_QWORD *)(v18 + 16) = a5; /*0x10304089c*/
    Func = sqlite3CreateFunc(a1, a2, a3, a4, a5, a6: v26, a7, a8, a9, a10, a11: v18); /*0x1030408cf*/
    if ( *v19 == 0 ) /*0x1030408d7*/
    {
      a11(a1: a5); /*0x1030408dc*/
      sqlite3_free(a1: v19); /*0x1030408e2*/
    }
  }
  else
  {
    Func = sqlite3CreateFunc(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11: 0); /*0x103040944*/
  }
  if ( Func != 0 ) /*0x10304094a*/
    goto LABEL_14; /*0x10304094a*/
  v23 = 0; /*0x10304094c*/
  if ( *(_BYTE *)(a1 + 103) != 0 ) /*0x103040953*/
    goto LABEL_14; /*0x103040953*/
LABEL_15:
  v24 = *(_QWORD *)(a1 + 24); /*0x103040979*/
  if ( v24 != 0 ) /*0x103040980*/
    xmmword_10CD98250(a1: v24, a2: v21, a3: v20); /*0x103040982*/
  return v23; /*0x10304098b*/
}

// Address: 0x103042481 | Name: _createCollation
__int64 __fastcall createCollation(__int64 a1, __int64 a2, unsigned int a3, __int64 a4, __int64 a5, __int64 a6)
{
  char v6; // r14
  unsigned int v7; // r12d
  unsigned int v8; // r14d
  __int64 v9; // rax
  __int64 v10; // r13
  __int64 i; // rax
  __int64 v12; // r15
  __int64 v13; // rbx
  void (__fastcall *v14)(_QWORD); // rax
  __int64 CollSeq; // rax
  __int64 v18; // [rsp+8h] [rbp-48h]

  v6 = a3; /*0x103042492*/
  v7 = 2; /*0x10304249b*/
  if ( (((_BYTE)a3 - 4) & 0xFB) != 0 ) /*0x1030424a1*/
    v7 = a3; /*0x1030424a1*/
  if ( v7 - 4 <= 0xFFFFFFFC ) /*0x1030424ad*/
  {
    v8 = 21; /*0x1030424c4*/
    sqlite3_log( /*0x1030424d6*/
      iErrCode: 21,
      zFormat: "%s at line %d of [%.10s]",
      "misuse",
      187747,
      "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
    return v8; /*0x1030424db*/
  }
  v18 = a4; /*0x1030424e4*/
  if ( a2 == 0 ) /*0x1030424f7*/
  {
    v10 = *(_QWORD *)(a1 + 16); /*0x103042525*/
    goto LABEL_9; /*0x103042525*/
  }
  v9 = *(_QWORD *)(findElementWithHash(a1: a1 + 584, a2, a3: 0) + 16); /*0x103042507*/
  if ( v9 != 0 ) /*0x10304250e*/
  {
    LODWORD(a4) = 5 * v7; /*0x103042517*/
    v10 = v9 + 40LL * v7 - 40; /*0x10304251f*/
LABEL_9:
    if ( v10 != 0 && *(_QWORD *)(v10 + 24) != 0 ) /*0x103042537*/
    {
      if ( *(_DWORD *)(a1 + 208) != 0 ) /*0x103042548*/
      {
        v8 = 5; /*0x103042551*/
        sqlite3ErrorWithMsg( /*0x10304255e*/
          a1,
          a2: 5,
          a3: (unsigned int)"unable to delete/modify collation sequence due to active statements",
          a4,
          a5,
          a6,
          a7: a6);
        return v8; /*0x103042563*/
      }
      for ( i = *(_QWORD *)(a1 + 8); i != 0; i = *(_QWORD *)(i + 16) ) /*0x103042568*/
        *(_WORD *)(i + 192) = (*(_WORD *)(i + 192) & 0xFFFC) + 1; /*0x10304257c*/
      if ( v7 == (*(_BYTE *)(v10 + 8) & 0xF7) ) /*0x103042594*/
      {
        v12 = 0; /*0x1030425a1*/
        v13 = *(_QWORD *)(findElementWithHash(a1: a1 + 584, a2, a3: 0) + 16); /*0x1030425af*/
        do /*0x1030425e0*/
        {
          if ( *(_BYTE *)(v13 + v12 + 8) == *(_BYTE *)(v10 + 8) ) /*0x1030425bc*/
          {
            v14 = *(void (__fastcall **)(_QWORD))(v13 + v12 + 32); /*0x1030425be*/
            if ( v14 != nullptr ) /*0x1030425c6*/
              v14(a1: *(_QWORD *)(v13 + v12 + 16)); /*0x1030425cd*/
            *(_QWORD *)(v13 + v12 + 24) = 0; /*0x1030425cf*/
          }
          v12 += 40; /*0x1030425d8*/
        }
        while ( v12 != 120 ); /*0x1030425e0*/
      }
    }
  }
  CollSeq = sqlite3FindCollSeq(a1, a2: (unsigned __int8)v7, a3: a2, a4: 1); /*0x1030425e2*/
  if ( CollSeq != 0 ) /*0x1030425fe*/
  {
    *(_QWORD *)(CollSeq + 24) = a5; /*0x103042604*/
    *(_QWORD *)(CollSeq + 16) = v18; /*0x10304260c*/
    *(_QWORD *)(CollSeq + 32) = a6; /*0x103042614*/
    *(_BYTE *)(CollSeq + 8) = v6 & 8 | v7; /*0x10304261f*/
    *(_DWORD *)(a1 + 80) = 0; /*0x103042623*/
    if ( *(_QWORD *)(a1 + 376) != 0 ) /*0x103042632*/
    {
      v8 = 0; /*0x103042634*/
      sqlite3ErrorFinish(a1, a2: 0); /*0x10304263c*/
    }
    else
    {
      *(_DWORD *)(a1 + 84) = -1; /*0x10304264b*/
      return 0; /*0x103042652*/
    }
  }
  else
  {
    return 7; /*0x103042643*/
  }
  return v8; /*0x103042658*/
}

// Address: 0x1030469d7 | Name: _closeUnixFile
void __fastcall closeUnixFile(__int64 a1)
{
  void *v2; // rdi
  __int64 v3; // rsi

  v2 = *(void **)(a1 + 104); /*0x1030469e0*/
  if ( v2 != nullptr ) /*0x1030469e7*/
  {
    off_10CD98BC0(a1: v2, a2: *(_QWORD *)(a1 + 88)); /*0x1030469ed*/
    *(_QWORD *)(a1 + 104) = 0; /*0x1030469f3*/
    *(_OWORD *)(a1 + 80) = 0; /*0x1030469fe*/
  }
  v3 = *(unsigned int *)(a1 + 24); /*0x103046a02*/
  if ( (int)v3 >= 0 ) /*0x103046a07*/
  {
    robust_close(a1, a2: v3, a3: 41513); /*0x103046a11*/
    *(_DWORD *)(a1 + 24) = -1; /*0x103046a16*/
  }
  sqlite3_free(a1: *(void **)(a1 + 48)); /*0x103046a21*/
  *(_OWORD *)(a1 + 112) = 0; /*0x103046a29*/
  *(_OWORD *)(a1 + 96) = 0; /*0x103046a2d*/
  *(_OWORD *)(a1 + 80) = 0; /*0x103046a31*/
  *(_OWORD *)(a1 + 64) = 0; /*0x103046a35*/
  *(_OWORD *)(a1 + 48) = 0; /*0x103046a39*/
  *(_OWORD *)(a1 + 32) = 0; /*0x103046a3d*/
  *(_OWORD *)(a1 + 16) = 0; /*0x103046a41*/
  *(_OWORD *)a1 = 0; /*0x103046a45*/
}

// Address: 0x103046a4f | Name: _closePendingFds
void __fastcall closePendingFds(__int64 a1)
{
  __int64 v1; // r15
  _QWORD *v2; // r14
  _QWORD *v4; // r12

  v1 = *(_QWORD *)(a1 + 16); /*0x103046a5a*/
  v2 = *(_QWORD **)(v1 + 40); /*0x103046a5e*/
  if ( v2 != nullptr ) /*0x103046a65*/
  {
    do /*0x103046a8c*/
    {
      v4 = (_QWORD *)v2[1]; /*0x103046a6a*/
      robust_close(a1, a2: *(unsigned int *)v2, a3: 40679); /*0x103046a79*/
      sqlite3_free(a1: v2); /*0x103046a81*/
      v2 = v4; /*0x103046a86*/
    }
    while ( v4 != nullptr ); /*0x103046a8c*/
  }
  *(_QWORD *)(v1 + 40) = 0; /*0x103046a8e*/
}

// Address: 0x1030501f8 | Name: _cellSizePtrTableLeaf
__int64 __fastcall cellSizePtrTableLeaf(__int64 a1, char *a2)
{
  unsigned int v2; // eax
  char *v3; // rcx
  unsigned __int64 v4; // rcx
  unsigned __int64 v5; // r8
  char v6; // dl
  int v7; // ecx
  unsigned int v8; // r8d
  unsigned int v9; // edx
  unsigned __int16 v10; // cx
  unsigned int v11; // eax

  v2 = (unsigned __int8)*a2; /*0x1030501f8*/
  if ( (v2 & 0x80u) != 0 ) /*0x1030501fd*/
  {
    v2 &= 0x7Fu; /*0x103050204*/
    v4 = 0; /*0x103050207*/
    do /*0x10305022b*/
    {
      v5 = v4; /*0x103050209*/
      v6 = a2[++v4]; /*0x103050213*/
      v2 = (v2 << 7) | v6 & 0x7F; /*0x103050220*/
    }
    while ( v5 <= 6 && v6 < 0 ); /*0x10305022b*/
    v3 = &a2[v4]; /*0x10305022d*/
  }
  else
  {
    v3 = a2; /*0x1030501ff*/
  }
  if ( v3[1] < 0 ) /*0x103050238*/
  {
    if ( v3[2] < 0 ) /*0x103050244*/
    {
      if ( v3[3] < 0 ) /*0x103050250*/
      {
        if ( v3[4] < 0 ) /*0x10305025c*/
        {
          if ( v3[5] < 0 ) /*0x103050268*/
          {
            if ( v3[6] < 0 ) /*0x103050274*/
            {
              if ( v3[7] < 0 ) /*0x103050280*/
                v7 = ((unsigned __int8)v3[8] >> 7) + (_DWORD)v3 + 9; /*0x103050294*/
              else
                v7 = (_DWORD)v3 + 8; /*0x103050282*/
            }
            else
            {
              v7 = (_DWORD)v3 + 7; /*0x103050276*/
            }
          }
          else
          {
            v7 = (_DWORD)v3 + 6; /*0x10305026a*/
          }
        }
        else
        {
          v7 = (_DWORD)v3 + 5; /*0x10305025e*/
        }
      }
      else
      {
        v7 = (_DWORD)v3 + 4; /*0x103050252*/
      }
    }
    else
    {
      v7 = (_DWORD)v3 + 3; /*0x103050246*/
    }
  }
  else
  {
    v7 = (_DWORD)v3 + 2; /*0x10305023a*/
  }
  v8 = *(unsigned __int16 *)(a1 + 14); /*0x103050298*/
  if ( v2 <= v8 ) /*0x1030502a0*/
  {
    v11 = v7 - (_DWORD)a2 + v2; /*0x1030502cd*/
    v10 = 4; /*0x1030502d2*/
    if ( v11 >= 5 ) /*0x1030502d7*/
      return (unsigned __int16)v11; /*0x1030502d7*/
  }
  else
  {
    v9 = *(unsigned __int16 *)(a1 + 16) /*0x1030502b8*/
       + (v2 - *(unsigned __int16 *)(a1 + 16)) % (*(_DWORD *)(*(_QWORD *)(a1 + 72) + 56LL) - 4);
    if ( v9 > v8 ) /*0x1030502be*/
      LOWORD(v9) = *(_WORD *)(a1 + 16); /*0x1030502be*/
    return (unsigned __int16)(v9 + v7 - (_WORD)a2 + 4); /*0x1030502c6*/
  }
  return v10; /*0x1030502de*/
}

// Address: 0x10305045c | Name: _cellSizePtrIdxLeaf
__int64 __fastcall cellSizePtrIdxLeaf(__int64 a1, unsigned __int8 *a2)
{
  unsigned int v2; // eax
  int v3; // ecx
  unsigned __int64 v4; // rcx
  unsigned __int64 v5; // r8
  char v6; // dl
  int v7; // ecx
  unsigned int v8; // r8d
  unsigned int v9; // edx
  unsigned __int16 v10; // cx
  unsigned int v11; // eax

  v2 = *a2; /*0x10305045c*/
  if ( (v2 & 0x80u) != 0 ) /*0x103050461*/
  {
    v2 &= 0x7Fu; /*0x103050468*/
    v4 = 0; /*0x10305046b*/
    do /*0x10305048f*/
    {
      v5 = v4; /*0x10305046d*/
      v6 = a2[++v4]; /*0x103050477*/
      v2 = (v2 << 7) | v6 & 0x7F; /*0x103050484*/
    }
    while ( v5 <= 6 && v6 < 0 ); /*0x10305048f*/
    v3 = (_DWORD)a2 + v4; /*0x103050491*/
  }
  else
  {
    v3 = (int)a2; /*0x103050463*/
  }
  v7 = v3 + 1; /*0x103050494*/
  v8 = *(unsigned __int16 *)(a1 + 14); /*0x103050497*/
  if ( v2 <= v8 ) /*0x10305049f*/
  {
    v11 = v7 - (_DWORD)a2 + v2; /*0x1030504d1*/
    v10 = 4; /*0x1030504d6*/
    if ( v11 >= 5 ) /*0x1030504db*/
      return (unsigned __int16)v11; /*0x1030504db*/
  }
  else
  {
    v9 = *(unsigned __int16 *)(a1 + 16) /*0x1030504bb*/
       + (v2 - *(unsigned __int16 *)(a1 + 16)) % (*(_DWORD *)(*(_QWORD *)(a1 + 72) + 56LL) - 4);
    if ( v9 > v8 ) /*0x1030504c1*/
      LOWORD(v9) = *(_WORD *)(a1 + 16); /*0x1030504c1*/
    return (unsigned __int16)(v9 + v7 - (_WORD)a2 + 4); /*0x1030504c9*/
  }
  return v10; /*0x1030504e1*/
}

// Address: 0x103050561 | Name: _cellSizePtr
__int64 __fastcall cellSizePtr(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  __int64 v3; // rcx
  unsigned __int64 v4; // r8
  char v5; // dl
  __int16 v6; // cx
  unsigned int v7; // r8d
  unsigned int v8; // edx

  LODWORD(result) = *(unsigned __int8 *)(a2 + 4); /*0x103050561*/
  v3 = 4; /*0x103050565*/
  if ( (result & 0x80u) != 0LL ) /*0x10305056c*/
  {
    LODWORD(result) = result & 0x7F; /*0x10305056e*/
    do /*0x103050593*/
    {
      v4 = v3; /*0x103050571*/
      v5 = *(_BYTE *)(a2 + v3++ + 1); /*0x10305057b*/
      LODWORD(result) = ((_DWORD)result << 7) | v5 & 0x7F; /*0x103050588*/
    }
    while ( v4 <= 0xA && v5 < 0 ); /*0x103050593*/
  }
  v6 = a2 + v3 + 1; /*0x103050598*/
  v7 = *(unsigned __int16 *)(a1 + 14); /*0x10305059b*/
  if ( (unsigned int)result <= v7 ) /*0x1030505a3*/
  {
    LOWORD(result) = v6 - a2 + result; /*0x1030505d6*/
  }
  else
  {
    v8 = *(unsigned __int16 *)(a1 + 16) /*0x1030505bf*/
       + ((unsigned int)result - *(unsigned __int16 *)(a1 + 16)) % (*(_DWORD *)(*(_QWORD *)(a1 + 72) + 56LL) - 4);
    if ( v8 > v7 ) /*0x1030505c5*/
      LOWORD(v8) = *(_WORD *)(a1 + 16); /*0x1030505c5*/
    LOWORD(result) = v6 - a2 + v8 + 4; /*0x1030505ce*/
  }
  return (unsigned __int16)result; /*0x1030505db*/
}

// Address: 0x1030505dc | Name: _cellSizePtrNoPayload
__int64 __fastcall cellSizePtrNoPayload(__int64 a1, __int64 a2)
{
  unsigned __int64 v2; // rcx
  __int64 result; // rax

  v2 = 4; /*0x1030505e0*/
  do /*0x1030505f6*/
  {
    LOWORD(result) = v2 + 1; /*0x1030505e5*/
    if ( v2 > 0xB ) /*0x1030505ed*/
      break; /*0x1030505ed*/
  }
  while ( *(char *)(a2 + v2++) < 0 ); /*0x1030505f6*/
  return (unsigned __int16)result; /*0x1030505fb*/
}

// Address: 0x103052e41 | Name: _copyPayload
__int64 __fastcall copyPayload(void *__src, void *__dst, size_t a3, int a4, __int64 a5)
{
  int v5; // r15d
  __int64 result; // rax
  void *v9; // rdi
  const void *v10; // rsi

  v5 = a3; /*0x103052e4b*/
  if ( a4 != 0 ) /*0x103052e56*/
  {
    result = sqlite3PagerWrite(a1: a5); /*0x103052e5b*/
    if ( (_DWORD)result != 0 ) /*0x103052e62*/
      return result; /*0x103052e62*/
    a3 = v5; /*0x103052e64*/
    v9 = __src; /*0x103052e67*/
    v10 = __dst; /*0x103052e6a*/
  }
  else
  {
    a3 = (int)a3; /*0x103052e6f*/
    v9 = __dst; /*0x103052e72*/
    v10 = __src; /*0x103052e75*/
  }
  memcpy(__dst: v9, __src: v10, __n: a3); /*0x103052e78*/
  return 0; /*0x103052e83*/
}

// Address: 0x10305574f | Name: _closeCursorsInFrame
__int64 __fastcall closeCursorsInFrame(__int64 a1)
{
  __int64 result; // rax
  __int64 v3; // r14

  result = *(unsigned int *)(a1 + 40); /*0x10305574f*/
  if ( (int)result > 0 ) /*0x103055754*/
  {
    v3 = 0; /*0x103055760*/
    do /*0x103055790*/
    {
      if ( *(_QWORD *)(*(_QWORD *)(a1 + 120) + 8 * v3) != 0 ) /*0x10305576e*/
      {
        sqlite3VdbeFreeCursorNN(a1); /*0x103055773*/
        *(_QWORD *)(*(_QWORD *)(a1 + 120) + 8 * v3) = 0; /*0x10305577c*/
        result = *(unsigned int *)(a1 + 40); /*0x103055784*/
      }
      ++v3; /*0x103055787*/
    }
    while ( v3 < (int)result ); /*0x103055790*/
  }
  return result; /*0x103055796*/
}

// Address: 0x103057255 | Name: _callFinaliser
__int64 __fastcall callFinaliser(__int64 a1, unsigned int a2)
{
  __int64 result; // rax
  __int64 v3; // r14
  __int64 v5; // r12
  __int64 v6; // r13
  __int64 v7; // r15
  _QWORD *v8; // rdi
  void (__fastcall *v9)(_QWORD *); // rax

  v3 = *(_QWORD *)(a1 + 544); /*0x103057263*/
  if ( v3 != 0 ) /*0x10305726d*/
  {
    *(_QWORD *)(a1 + 544) = 0; /*0x103057272*/
    if ( *(int *)(a1 + 504) > 0 ) /*0x103057284*/
    {
      v5 = a2; /*0x103057286*/
      v6 = 0; /*0x103057289*/
      do /*0x1030572c4*/
      {
        v7 = *(_QWORD *)(v3 + 8 * v6); /*0x10305728c*/
        v8 = *(_QWORD **)(v7 + 16); /*0x103057290*/
        if ( v8 != nullptr ) /*0x103057297*/
        {
          v9 = *(void (__fastcall **)(_QWORD *))(*v8 + v5); /*0x10305729c*/
          if ( v9 != nullptr ) /*0x1030572a3*/
            v9(a1: v8); /*0x1030572a5*/
        }
        *(_DWORD *)(v7 + 32) = 0; /*0x1030572a7*/
        sqlite3VtabUnlock(a1: v7); /*0x1030572b2*/
        ++v6; /*0x1030572b7*/
      }
      while ( v6 < *(int *)(a1 + 504) ); /*0x1030572c4*/
    }
    result = sqlite3DbFreeNN(a1, a2: v3); /*0x1030572cc*/
    *(_DWORD *)(a1 + 504) = 0; /*0x1030572d1*/
  }
  return result; /*0x1030572df*/
}

// Address: 0x103068919 | Name: _computeNumericType
__int64 __fastcall computeNumericType(__int64 a1)
{
  __int64 v2; // rax
  int v3; // eax
  unsigned __int16 v4; // r14
  _QWORD v6[3]; // [rsp+8h] [rbp-18h] BYREF

  if ( (*(_BYTE *)(a1 + 21) & 4) != 0 && (unsigned int)sqlite3VdbeMemExpandBlob(a1) != 0 ) /*0x103068937*/
  {
    v2 = 0; /*0x103068939*/
LABEL_11:
    *(_QWORD *)a1 = v2; /*0x103068997*/
    return 4; /*0x10306899a*/
  }
  v3 = sqlite3AtoF(a1: *(_QWORD *)(a1 + 8), a2: a1, a3: *(unsigned int *)(a1 + 16), a4: *(unsigned __int8 *)(a1 + 22)); /*0x10306894b*/
  v4 = 8; /*0x103068950*/
  if ( v3 <= 0 ) /*0x103068957*/
  {
    if ( v3 == 0 /*0x103068991*/
      && (int)sqlite3Atoi64(
                a1: *(_QWORD *)(a1 + 8),
                a2: v6,
                a3: *(unsigned int *)(a1 + 16),
                a4: *(unsigned __int8 *)(a1 + 22)) <= 1 )
    {
      goto LABEL_10; /*0x103068991*/
    }
  }
  else if ( v3 == 1 /*0x103068974*/
         && (unsigned int)sqlite3Atoi64(
                            a1: *(_QWORD *)(a1 + 8),
                            a2: v6,
                            a3: *(unsigned int *)(a1 + 16),
                            a4: *(unsigned __int8 *)(a1 + 22)) == 0 )
  {
LABEL_10:
    v2 = v6[0]; /*0x103068993*/
    goto LABEL_11; /*0x103068993*/
  }
  return v4; /*0x1030689a3*/
}

// Address: 0x1030695b4 | Name: _clearSelect
__int64 __fastcall clearSelect(__int64 a1, _QWORD *a2, int a3)
{
  __int64 result; // rax
  _QWORD *v4; // r14
  bool v6; // r15
  _QWORD *v7; // r12
  __int64 v8; // rsi
  __int64 v9; // rsi
  __int64 v10; // r13
  _QWORD *v11; // rdx
  __int64 v12; // rcx

  if ( a2 != nullptr ) /*0x1030695b7*/
  {
    v4 = a2; /*0x1030695cb*/
    v6 = a3 == 0; /*0x1030695d3*/
    do /*0x1030696c5*/
    {
      v7 = (_QWORD *)v4[10]; /*0x1030695db*/
      if ( v4[4] != 0 ) /*0x1030695e2*/
        exprListDeleteNN(a1); /*0x1030695e7*/
      sqlite3SrcListDelete(a1, a2: v4[5]); /*0x1030695f3*/
      if ( v4[6] != 0 ) /*0x1030695ff*/
        sqlite3ExprDeleteNN(a1); /*0x103069604*/
      if ( v4[7] != 0 ) /*0x103069610*/
        exprListDeleteNN(a1); /*0x103069615*/
      if ( v4[8] != 0 ) /*0x103069621*/
        sqlite3ExprDeleteNN(a1); /*0x103069626*/
      if ( v4[9] != 0 ) /*0x103069632*/
        exprListDeleteNN(a1); /*0x103069637*/
      if ( v4[12] != 0 ) /*0x103069643*/
        sqlite3ExprDeleteNN(a1); /*0x103069648*/
      v8 = v4[13]; /*0x10306964d*/
      if ( v8 != 0 ) /*0x103069654*/
        sqlite3WithDelete(a1, a2: v8); /*0x103069659*/
      v9 = v4[15]; /*0x10306965e*/
      if ( v9 != 0 ) /*0x103069665*/
      {
        do /*0x103069679*/
        {
          v10 = *(_QWORD *)(v9 + 64); /*0x103069667*/
          sqlite3WindowDelete(a1); /*0x10306966e*/
          v9 = v10; /*0x103069673*/
        }
        while ( v10 != 0 ); /*0x103069679*/
      }
LABEL_19:
      result = v4[14]; /*0x10306967b*/
      while ( result != 0 ) /*0x103069682*/
      {
        v11 = *(_QWORD **)(result + 56); /*0x103069684*/
        if ( v11 != nullptr ) /*0x10306968b*/
        {
          v12 = *(_QWORD *)(result + 64); /*0x10306968d*/
          *v11 = v12; /*0x103069691*/
          if ( v12 != 0 ) /*0x103069697*/
            *(_QWORD *)(v12 + 56) = *(_QWORD *)(result + 56); /*0x10306969d*/
          *(_QWORD *)(result + 56) = 0; /*0x1030696a1*/
          goto LABEL_19; /*0x1030696a9*/
        }
      }
      if ( !v6 ) /*0x1030696af*/
        result = sqlite3DbNNFreeNN(a1, a2: v4); /*0x1030696b7*/
      v6 = false; /*0x1030696bc*/
      v4 = v7; /*0x1030696bf*/
    }
    while ( v7 != nullptr ); /*0x1030696c5*/
  }
  return result; /*0x1030696d9*/
}

// Address: 0x1030698a8 | Name: _cteClear
__int64 __fastcall cteClear(__int64 a1, _QWORD *a2)
{
  __int64 result; // rax
  _QWORD *v5; // rsi

  if ( a2[1] != 0 ) /*0x1030698bc*/
    result = exprListDeleteNN(a1); /*0x1030698c1*/
  v5 = (_QWORD *)a2[2]; /*0x1030698c6*/
  if ( v5 != nullptr ) /*0x1030698cd*/
    result = clearSelect(a1, a2: v5, a3: 1); /*0x1030698d7*/
  if ( *a2 != 0 ) /*0x1030698e2*/
    return sqlite3DbFreeNN(a1, a2: *a2); /*0x1030698eb*/
  return result; /*0x1030698e7*/
}

// Address: 0x103069a55 | Name: _clearDatabasePage
__int64 __fastcall clearDatabasePage(__int64 a1, __int64 a2, int a3, _QWORD *a4)
{
  unsigned int inited; // r13d
  int v7; // r14d
  __int64 v9; // rbx
  __int64 v10; // rdi
  __int64 v11; // rcx
  unsigned __int64 v12; // r14
  unsigned int *v13; // r15
  unsigned int v14; // eax
  unsigned __int64 v15; // rax
  _QWORD *v16; // r14
  __int64 v17; // r12
  __int64 v18; // r14
  _BYTE v20[16]; // [rsp+8h] [rbp-68h] BYREF
  int v21; // [rsp+18h] [rbp-58h]
  unsigned __int16 v22; // [rsp+1Ch] [rbp-54h]
  __int64 v23; // [rsp+20h] [rbp-50h] BYREF
  __int64 v24; // [rsp+28h] [rbp-48h]
  __int64 v25; // [rsp+30h] [rbp-40h]
  int v26; // [rsp+3Ch] [rbp-34h]
  _QWORD *v27; // [rsp+40h] [rbp-30h]

  if ( *(_DWORD *)(a1 + 64) >= (unsigned int)a2 ) /*0x103069a69*/
  {
    v7 = a2; /*0x103069aa2*/
    inited = getAndInitPage(a1, a2, a3: &v23, a4: 0); /*0x103069ab3*/
    if ( inited != 0 ) /*0x103069ab8*/
      return inited; /*0x103069ab8*/
    v27 = a4; /*0x103069abe*/
    v9 = v23; /*0x103069ac8*/
    v10 = a1; /*0x103069acc*/
    if ( (*(_BYTE *)(a1 + 32) & 4) == 0 && (v7 == 1) + 1 != *(_DWORD *)(*(_QWORD *)(v23 + 112) + 56LL) ) /*0x103069ae3*/
    {
      inited = 11; /*0x103069bda*/
      sqlite3_log( /*0x103069bec*/
        iErrCode: 11,
        zFormat: "%s at line %d of [%.10s]",
        "database corruption",
        82630,
        "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
LABEL_27:
      sqlite3PagerUnrefNotNull(a1: *(_QWORD *)(v9 + 112)); /*0x103069c3c*/
      return inited; /*0x103069c40*/
    }
    v11 = *(unsigned __int8 *)(v23 + 9); /*0x103069ae9*/
    if ( *(_WORD *)(v23 + 24) != 0 ) /*0x103069af2*/
    {
      v25 = a1; /*0x103069af8*/
      v24 = v11; /*0x103069afc*/
      v26 = a3; /*0x103069b00*/
      v12 = 0; /*0x103069b04*/
      while ( 1 ) /*0x103069b27*/
      {
        v13 = (unsigned int *)(*(_QWORD *)(v9 + 80) /*0x103069b27*/
                             + (unsigned __int16)(*(_WORD *)(v9 + 26)
                                                & _byteswap_ushort(*(_WORD *)(*(_QWORD *)(v9 + 96) + 2 * v12))));
        if ( *(_BYTE *)(v9 + 8) == 0 ) /*0x103069b2f*/
        {
          v14 = clearDatabasePage(a1: v25, a2: _byteswap_ulong(*v13), a3: 1, a4: v27); /*0x103069b43*/
          if ( v14 != 0 ) /*0x103069b4a*/
            goto LABEL_26; /*0x103069b78*/
        }
        (*(void (__fastcall **)(__int64, unsigned int *, _BYTE *))(v9 + 128))(a1: v9, a2: v13, a3: v20); /*0x103069b59*/
        if ( v21 != v22 ) /*0x103069b66*/
        {
          v14 = clearCellOverflow(a1: v9, a2: v13, a3: v20); /*0x103069b71*/
          if ( v14 != 0 ) /*0x103069b78*/
            goto LABEL_26; /*0x103069b78*/
        }
        ++v12; /*0x103069b7e*/
        v15 = *(unsigned __int16 *)(v9 + 24); /*0x103069b81*/
        if ( v12 >= v15 ) /*0x103069b88*/
        {
          a3 = v26; /*0x103069b8a*/
          v11 = v24; /*0x103069b8e*/
          v10 = v25; /*0x103069b92*/
          goto LABEL_15; /*0x103069b96*/
        }
      }
    }
    LOWORD(v15) = 0; /*0x103069b98*/
LABEL_15:
    if ( *(_BYTE *)(v9 + 8) != 0 ) /*0x103069b9e*/
    {
      v16 = v27; /*0x103069ba0*/
      if ( v27 == nullptr ) /*0x103069ba7*/
        goto LABEL_18; /*0x103069ba7*/
    }
    else
    {
      v16 = v27; /*0x103069c02*/
      v17 = v11; /*0x103069c06*/
      v14 = clearDatabasePage(a1: v10, a2: _byteswap_ulong(*(_DWORD *)(*(_QWORD *)(v9 + 80) + v11 + 8)), a3: 1, a4: v27); /*0x103069c0c*/
      if ( v14 != 0 ) /*0x103069c13*/
      {
LABEL_26:
        inited = v14; /*0x103069c39*/
        goto LABEL_27; /*0x103069c39*/
      }
      v11 = v17; /*0x103069c18*/
      if ( v16 == nullptr || *(_BYTE *)(v9 + 1) != 0 ) /*0x103069c21*/
      {
LABEL_18:
        if ( a3 != 0 ) /*0x103069bb2*/
        {
          v14 = freePage2(a1: *(_QWORD *)(v9 + 72), a2: v9, a3: *(unsigned int *)(v9 + 4)); /*0x103069bbe*/
        }
        else
        {
          v18 = v11; /*0x103069c29*/
          v14 = sqlite3PagerWrite(a1: *(_QWORD *)(v9 + 112)); /*0x103069c30*/
          if ( v14 == 0 ) /*0x103069c37*/
          {
            zeroPage(a1: v9, a2: *(unsigned __int8 *)(*(_QWORD *)(v9 + 80) + v18) | 8u); /*0x103069c66*/
            inited = 0; /*0x103069c6b*/
            goto LABEL_27; /*0x103069c6e*/
          }
        }
        goto LABEL_26; /*0x103069bc3*/
      }
      LOWORD(v15) = *(_WORD *)(v9 + 24); /*0x103069c23*/
    }
    *v16 += (unsigned __int16)v15; /*0x103069bac*/
    goto LABEL_18; /*0x103069bac*/
  }
  inited = 11; /*0x103069a80*/
  sqlite3_log( /*0x103069a92*/
    iErrCode: 11,
    zFormat: "%s at line %d of [%.10s]",
    "database corruption",
    82623,
    "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
  return inited; /*0x103069c48*/
}

// Address: 0x103069c70 | Name: _clearCellOverflow
__int64 __fastcall clearCellOverflow(__int64 a1, __int64 a2, __int64 a3)
{
  unsigned __int64 v3; // rcx
  unsigned int v4; // r15d
  __int64 v5; // rbx
  unsigned int v6; // esi
  unsigned int v7; // eax
  int v9; // r14d
  unsigned int v10; // r13d
  unsigned int OverflowPage; // eax
  __int64 v12; // rsi
  __int64 v13; // rdi
  __int64 v14; // [rsp+8h] [rbp-38h] BYREF
  unsigned int v15[11]; // [rsp+14h] [rbp-2Ch] BYREF

  v3 = a2 + *(unsigned __int16 *)(a3 + 22); /*0x103069c85*/
  if ( v3 <= *(_QWORD *)(a1 + 88) ) /*0x103069c8c*/
  {
    v5 = *(_QWORD *)(a1 + 72); /*0x103069cbc*/
    v6 = *(_DWORD *)(v5 + 56) - 4; /*0x103069cc3*/
    v7 = v6 + *(_DWORD *)(a3 + 16) + ~*(unsigned __int16 *)(a3 + 20); /*0x103069cd1*/
    if ( v6 > v7 ) /*0x103069cd5*/
      return 0; /*0x103069cd7*/
    v9 = v7 / v6; /*0x103069cf0*/
    v10 = _byteswap_ulong(*(_DWORD *)(v3 - 4)); /*0x103069cf7*/
    while ( 1 ) /*0x103069cfe*/
    {
      v15[0] = 0; /*0x103069cfe*/
      v14 = 0; /*0x103069d05*/
      if ( v10 < 2 || v10 > *(_DWORD *)(v5 + 64) ) /*0x103069d1b*/
      {
        v4 = 11; /*0x103069def*/
        sqlite3_log( /*0x103069dff*/
          iErrCode: 11,
          zFormat: "%s at line %d of [%.10s]",
          "database corruption",
          79410,
          "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
        return v4; /*0x103069dff*/
      }
      if ( --v9 == 0 ) /*0x103069d24*/
        goto LABEL_12; /*0x103069d24*/
      OverflowPage = getOverflowPage(a1: v5, a2: v10, a3: &v14, a4: v15); /*0x103069d33*/
      if ( OverflowPage != 0 ) /*0x103069d3a*/
        return OverflowPage; /*0x103069e07*/
      v12 = v14; /*0x103069d40*/
      if ( v14 == 0 ) /*0x103069d47*/
      {
LABEL_12:
        v12 = btreePageLookup(a1: (_QWORD *)v5, a2: v10); /*0x103069d54*/
        v14 = v12; /*0x103069d57*/
        if ( v12 == 0 ) /*0x103069d5e*/
          break; /*0x103069d5e*/
      }
      if ( *(_DWORD *)(*(_QWORD *)(v12 + 112) + 56LL) == 1 ) /*0x103069d68*/
        goto LABEL_16; /*0x103069d68*/
      v4 = 11; /*0x103069d6a*/
      sqlite3_log( /*0x103069d91*/
        iErrCode: 11,
        zFormat: "%s at line %d of [%.10s]",
        "database corruption",
        79430,
        "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
LABEL_17:
      if ( v14 != 0 ) /*0x103069daf*/
      {
        v13 = *(_QWORD *)(v14 + 112); /*0x103069db1*/
        if ( v13 != 0 ) /*0x103069db8*/
          sqlite3PagerUnrefNotNull(a1: v13); /*0x103069dba*/
      }
      if ( v4 != 0 ) /*0x103069dc2*/
        return v4; /*0x103069dc2*/
      v10 = v15[0]; /*0x103069dc8*/
      if ( v9 == 0 ) /*0x103069dcf*/
        return 0; /*0x103069dcf*/
    }
    v12 = 0; /*0x103069d98*/
LABEL_16:
    v4 = freePage2(a1: v5, a2: v12, a3: v10); /*0x103069d9a*/
    goto LABEL_17; /*0x103069da5*/
  }
  v4 = 11; /*0x103069ca3*/
  sqlite3_log( /*0x103069cb5*/
    iErrCode: 11,
    zFormat: "%s at line %d of [%.10s]",
    "database corruption",
    79393,
    "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
  return v4; /*0x103069cdd*/
}

// Address: 0x10306d820 | Name: _copyNodeContent
void __fastcall copyNodeContent(__int64 a1, __int64 a2, _DWORD *a3)
{
  __int64 v6; // rsi
  __int64 v7; // r13
  int v8; // r12d
  unsigned __int16 v9; // ax
  void *v10; // rdi
  int inited; // eax
  __int64 v12; // [rsp-40h] [rbp-40h]
  __int64 v13; // [rsp-38h] [rbp-38h]

  if ( *a3 == 0 ) /*0x10306d823*/
  {
    v6 = *(_QWORD *)(a1 + 80); /*0x10306d844*/
    v7 = *(_QWORD *)(a2 + 80); /*0x10306d848*/
    v8 = *(_DWORD *)(a2 + 4); /*0x10306d850*/
    v12 = v6 + *(unsigned __int8 *)(a1 + 9); /*0x10306d858*/
    v9 = __ROL2__(*(_WORD *)(v12 + 5), 8); /*0x10306d861*/
    v13 = *(_QWORD *)(a1 + 72); /*0x10306d86f*/
    memcpy(__dst: (void *)(v9 + v7), __src: (const void *)(v9 + v6), __n: *(_DWORD *)(v13 + 56) - (unsigned int)v9); /*0x10306d878*/
    v10 = (void *)(v7 + 100); /*0x10306d87d*/
    if ( v8 != 1 ) /*0x10306d885*/
      v10 = (void *)v7; /*0x10306d885*/
    memcpy( /*0x10306d89b*/
      __dst: v10,
      __src: (const void *)v12,
      __n: *(unsigned __int16 *)(a1 + 18) + 2LL * *(unsigned __int16 *)(a1 + 24));
    *(_BYTE *)a2 = 0; /*0x10306d8a0*/
    inited = btreeInitPage(a1: a2); /*0x10306d8a7*/
    if ( inited == 0 ) /*0x10306d8ae*/
    {
      inited = btreeComputeFreeSpace(a1: a2); /*0x10306d8b7*/
      if ( inited == 0 ) /*0x10306d8be*/
      {
        if ( *(_BYTE *)(v13 + 33) == 0 ) /*0x10306d8c5*/
          return; /*0x10306d8c5*/
        inited = setChildPtrmaps(a1: a2); /*0x10306d8ca*/
      }
    }
    *a3 = inited; /*0x10306d8cf*/
  }
}

// Address: 0x10306de00 | Name: _computeCellSize
__int64 __fastcall computeCellSize(_QWORD *a1, int a2)
{
  __int64 v3; // r14
  __int64 result; // rax

  v3 = a2; /*0x10306de12*/
  LOWORD(result) = (*(__int64 (__fastcall **)(_QWORD, _QWORD))(a1[1] + 120LL))( /*0x10306de19*/
                     a1: a1[1],
                     a2: *(_QWORD *)(a1[2] + 8LL * a2));
  *(_WORD *)(a1[3] + 2 * v3) = result; /*0x10306de20*/
  return (unsigned __int16)result; /*0x10306de28*/
}

// Address: 0x10306ff24 | Name: _corruptSchema
void __fastcall corruptSchema(__int64 *a1, _QWORD *a2, _BYTE *a3, int a4, int a5, int a6)
{
  __int64 v7; // r15
  int v8; // r12d
  const char *v10; // rdx
  __int64 v11; // rax
  int v12; // r8d
  int v13; // r9d

  v7 = *a1; /*0x10306ff32*/
  v8 = 7; /*0x10306ff35*/
  if ( *(_BYTE *)(*a1 + 103) != 0 ) /*0x10306ff40*/
  {
LABEL_2:
    *((_DWORD *)a1 + 5) = v8; /*0x10306ff42*/
    return; /*0x10306ff46*/
  }
  if ( *(_QWORD *)a1[1] == 0 )
  {
    if ( (a1[3] & 3) != 0 )
    {
      *(_QWORD *)a1[1] = sqlite3MPrintf(
                           a1: *a1,
                           a2: (unsigned int)"error in %s %s after %s: %s",
                           a3: *a2,
                           a4: a2[1],
                           a5: (unsigned int)corruptSchema_azAlterType_rel + corruptSchema_azAlterType_rel[(a1[3] & 3) - 1],
                           a6: (_DWORD)a3);
      v8 = 1; /*0x10306ff98*/
    }
    else if ( (*(_BYTE *)(v7 + 48) & 1) != 0 ) /*0x10306ffa5*/
    {
      v8 = 11; /*0x10307002f*/
      sqlite3_log( /*0x103070041*/
        iErrCode: 11,
        zFormat: "%s at line %d of [%.10s]",
        "database corruption",
        145705,
        "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
    }
    else
    {
      v10 = "?"; /*0x10306ffae*/
      if ( a2[1] != 0 ) /*0x10306ffb5*/
        v10 = (const char *)a2[1]; /*0x10306ffb5*/
      v11 = sqlite3MPrintf(a1: *a1, a2: (unsigned int)"malformed database schema (%s)", a3: (_DWORD)v10, a4, a5, a6); /*0x10306ffc5*/
      if ( a3 != nullptr && *a3 != 0 ) /*0x10306ffd3*/
        v11 = sqlite3MPrintf(a1: v7, a2: (unsigned int)"%z - %s", a3: v11, a4: (_DWORD)a3, a5: v12, a6: v13); /*0x10306ffe7*/
      *(_QWORD *)a1[1] = v11; /*0x10306fff0*/
      v8 = 11; /*0x103070008*/
      sqlite3_log( /*0x103070018*/
        iErrCode: 11,
        zFormat: "%s at line %d of [%.10s]",
        "database corruption",
        145712,
        "b270f8339eb13b504d0b2ba154ebca966b7dde08e40c3ed7d559749818cb2075");
    }
    goto LABEL_2; /*0x10306ff9e*/
  }
}

// Address: 0x103070b99 | Name: _checkList
__int64 __fastcall checkList(__int64 *a1, int a2, unsigned __int32 a3, unsigned int a4)
{
  __int64 result; // rax
  unsigned int v6; // r12d
  unsigned __int32 v7; // r13d
  int v8; // ebx
  __int64 v9; // r15
  __int64 v10; // rdx
  int v11; // edi
  int v12; // r12d
  int v13; // esi
  __int64 v14; // rax
  int v15; // edx
  int v16; // edi
  int v17; // r12d
  int v18; // ecx
  __int64 v19; // r12
  __int64 v20; // rbx
  unsigned __int32 v21; // r13d
  unsigned int v22; // r13d
  const char *v23; // rdx
  int v24; // [rsp+8h] [rbp-58h]
  __int64 v25; // [rsp+10h] [rbp-50h] BYREF
  unsigned int v26; // [rsp+1Ch] [rbp-44h]
  int v27; // [rsp+20h] [rbp-40h]
  unsigned int v28; // [rsp+24h] [rbp-3Ch]
  __int64 v29; // [rsp+28h] [rbp-38h]
  int v30; // [rsp+30h] [rbp-30h]
  unsigned int v31; // [rsp+34h] [rbp-2Ch]

  v30 = a2; /*0x103070baa*/
  result = *((unsigned int *)a1 + 8); /*0x103070bb0*/
  v28 = *((_DWORD *)a1 + 8); /*0x103070bb3*/
  v31 = a4; /*0x103070bb6*/
  v6 = a4; /*0x103070bb9*/
  if ( a3 != 0 ) /*0x103070bbe*/
  {
    v7 = a3; /*0x103070bc4*/
    result = v31; /*0x103070bc7*/
    v6 = v31; /*0x103070bca*/
    do /*0x103070bcd*/
    {
      if ( *((_DWORD *)a1 + 7) == 0 ) /*0x103070bd2*/
        break; /*0x103070bd2*/
      result = checkRef(a1, a2: v7); /*0x103070bde*/
      if ( (_DWORD)result != 0 ) /*0x103070be5*/
        break; /*0x103070be5*/
      v8 = v6--; /*0x103070beb*/
      if ( (*(unsigned int (__fastcall **)(__int64, _QWORD, __int64 *, _QWORD))(a1[1] + 272))( /*0x103070c06*/
             a1: a1[1],
             a2: v7,
             a3: &v25,
             a4: 0) != 0 )
      {
        result = checkAppendMsg(a1, a2: "failed to get page %u", v7); /*0x103070d4b*/
        break; /*0x103070d4b*/
      }
      v9 = *(_QWORD *)(v25 + 8); /*0x103070c10*/
      if ( v30 != 0 ) /*0x103070c18*/
      {
        v26 = v6; /*0x103070c1e*/
        v10 = *(unsigned __int8 *)(v9 + 4); /*0x103070c22*/
        v11 = *(unsigned __int8 *)(v9 + 5); /*0x103070c27*/
        v12 = *(unsigned __int8 *)(v9 + 6); /*0x103070c2c*/
        v13 = *(unsigned __int8 *)(v9 + 7); /*0x103070c31*/
        v14 = *a1; /*0x103070c36*/
        if ( *(_BYTE *)(*a1 + 33) != 0 ) /*0x103070c3d*/
        {
          v24 = *(unsigned __int8 *)(v9 + 5); /*0x103070c3f*/
          v27 = *(unsigned __int8 *)(v9 + 7); /*0x103070c46*/
          v29 = v10; /*0x103070c4c*/
          checkPtrmap(a1, a2: v7, a3: 2, a4: 0); /*0x103070c57*/
          v11 = v24; /*0x103070c5c*/
          v13 = v27; /*0x103070c60*/
          LODWORD(v10) = v29; /*0x103070c63*/
          v14 = *a1; /*0x103070c67*/
        }
        v15 = (_DWORD)v10 << 24; /*0x103070c6a*/
        v16 = v11 << 16; /*0x103070c6d*/
        v17 = v12 << 8; /*0x103070c73*/
        v18 = v13 | v17 | (v16 + v15); /*0x103070c7a*/
        if ( v18 <= (unsigned int)((*(_DWORD *)(v14 + 56) >> 2) - 2) ) /*0x103070c87*/
        {
          LODWORD(v29) = v13 | v17 | (v16 + v15); /*0x103070ccb*/
          if ( v18 > 0 ) /*0x103070cd0*/
          {
            v19 = (unsigned int)(v16 + v15 + v13 + v17); /*0x103070cd7*/
            v20 = 0; /*0x103070cda*/
            do /*0x103070d10*/
            {
              v21 = _byteswap_ulong(*(_DWORD *)(v9 + 4 * v20 + 8)); /*0x103070ce1*/
              if ( *(_BYTE *)(*a1 + 33) != 0 ) /*0x103070ceb*/
                checkPtrmap(a1, a2: v21, a3: 2, a4: 0); /*0x103070cfa*/
              checkRef(a1, a2: v21); /*0x103070d05*/
              ++v20; /*0x103070d0a*/
            }
            while ( v19 != v20 ); /*0x103070d10*/
          }
          result = v26 - (unsigned int)v29; /*0x103070d15*/
          v6 = v26 - v29; /*0x103070d18*/
        }
        else
        {
          result = checkAppendMsg(a1, a2: "freelist leaf count too big on page %u", v7); /*0x103070c98*/
          v6 = v8 - 2; /*0x103070ca0*/
        }
      }
      else
      {
        result = *a1; /*0x103070ca6*/
        if ( *(_BYTE *)(*a1 + 33) != 0 && v6 != 0 ) /*0x103070cb2*/
          result = checkPtrmap(a1, a2: _byteswap_ulong(*(_DWORD *)v9), a3: 4, a4: v7); /*0x103070cc4*/
      }
      v22 = *(_DWORD *)v9; /*0x103070d1b*/
      if ( v25 != 0 ) /*0x103070d25*/
        result = sqlite3PagerUnrefNotNull(a1: v25); /*0x103070d27*/
      v7 = _byteswap_ulong(v22); /*0x103070d2c*/
    }
    while ( v7 != 0 ); /*0x103070bcd*/
  }
  if ( v6 != 0 ) /*0x103070d53*/
  {
    result = v28; /*0x103070d55*/
    if ( v28 == *((_DWORD *)a1 + 8) ) /*0x103070d5c*/
    {
      v23 = "size"; /*0x103070d69*/
      if ( v30 == 0 ) /*0x103070d70*/
        v23 = "overflow list length"; /*0x103070d70*/
      return checkAppendMsg(a1, a2: "%s is %u but should be %u", v23, v31 - v6, v31); /*0x103070d8a*/
    }
  }
  return result; /*0x103070d8f*/
}

// Address: 0x103070d9e | Name: _checkAppendMsg
__int64 checkAppendMsg(__int64 a1, const char *a2, ...)
{
  int v4; // eax
  __int64 v6; // rax
  const char *v7; // rsi
  va_list va; // [rsp+B0h] [rbp-40h] BYREF

  if ( *(_DWORD *)(*(_QWORD *)(a1 + 112) + 384LL) != 0 ) /*0x103070e17*/
  {
    *(_DWORD *)(a1 + 36) = 9; /*0x103070e19*/
    ++*(_DWORD *)(a1 + 32); /*0x103070e20*/
    *(_DWORD *)(a1 + 28) = 0; /*0x103070e23*/
  }
  else
  {
    v4 = *(_DWORD *)(a1 + 28); /*0x103070e4c*/
    if ( v4 != 0 ) /*0x103070e51*/
    {
      *(_DWORD *)(a1 + 28) = v4 - 1; /*0x103070e58*/
      ++*(_DWORD *)(a1 + 32); /*0x103070e5b*/
      va_start(va, a2); /*0x103070e6d*/
      v6 = *(unsigned int *)(a1 + 96); /*0x103070e83*/
      if ( *(_DWORD *)(a1 + 96) != 0 ) /*0x103070e89*/
      {
        if ( (unsigned int)(v6 + 1) >= *(_DWORD *)(a1 + 88) ) /*0x103070e91*/
        {
          enlargeAndAppend(a1: a1 + 72, a2: "\n", a3: 1); /*0x103070eaf*/
        }
        else
        {
          *(_DWORD *)(a1 + 96) = v6 + 1; /*0x103070e93*/
          *(_BYTE *)(*(_QWORD *)(a1 + 80) + v6) = 10; /*0x103070e9a*/
        }
      }
      v7 = *(const char **)(a1 + 48); /*0x103070eb4*/
      if ( v7 != nullptr ) /*0x103070ebb*/
        sqlite3_str_appendf( /*0x103070ecc*/
          a1: (sqlite3_str *)(a1 + 72),
          zFormat: v7,
          *(unsigned int *)(a1 + 56),
          *(unsigned int *)(a1 + 60),
          *(unsigned int *)(a1 + 64));
      sqlite3_str_vappendf(a1: (sqlite3_str *)(a1 + 72), zFormat: a2, a3: va); /*0x103070edb*/
      if ( *(_BYTE *)(a1 + 100) == 7 ) /*0x103070ee4*/
      {
        *(_DWORD *)(a1 + 36) = 7; /*0x103070eea*/
        *(_DWORD *)(a1 + 28) = 0; /*0x103070ef1*/
        if ( *(_DWORD *)(a1 + 32) == 0 ) /*0x103070efc*/
          *(_DWORD *)(a1 + 32) = 1; /*0x103070f02*/
      }
    }
  }
  return __stack_chk_guard; /*0x103070e3e*/
}

// Address: 0x103070f13 | Name: _checkPtrmap
__int64 __fastcall checkPtrmap(__int64 a1, __int64 a2, unsigned __int8 a3, int a4)
{
  int v6; // ebx
  int v8; // eax
  __int64 result; // rax
  unsigned int v10; // [rsp+8h] [rbp-28h] BYREF
  _BYTE v11[33]; // [rsp+Fh] [rbp-21h] BYREF

  v6 = a2; /*0x103070f28*/
  v8 = ptrmapGet(a1: *(_QWORD *)a1, a2, a3: v11, a4: &v10); /*0x103070f38*/
  if ( v8 != 0 ) /*0x103070f3f*/
  {
    if ( v8 == 3082 || v8 == 7 ) /*0x103070f4b*/
    {
      *(_DWORD *)(a1 + 36) = 7; /*0x103070f4d*/
      *(_DWORD *)(a1 + 28) = 0; /*0x103070f55*/
      if ( *(_DWORD *)(a1 + 32) == 0 ) /*0x103070f62*/
        *(_DWORD *)(a1 + 32) = 1; /*0x103070f64*/
    }
    return checkAppendMsg(a1, a2: "Failed to read ptrmap key=%u", v6); /*0x103070f7a*/
  }
  else
  {
    result = v10; /*0x103070f97*/
    if ( v10 != a4 || v11[0] != a3 ) /*0x103070f94*/
      return checkAppendMsg(a1, a2: "Bad ptr map entry key=%u expected=(%u,%u) got=(%u,%u)", v6, a3, a4, v11[0], v10); /*0x103070fbc*/
  }
  return result; /*0x103070f7f*/
}

// Address: 0x103070fc3 | Name: _checkTreePage
__int64 __fastcall checkTreePage(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v6; // rcx
  __m128 v7; // xmm0
  int v8; // r14d
  __int64 v9; // r13
  __int64 v10; // r15
  unsigned int v11; // r13d
  _QWORD *v13; // r14
  unsigned int v14; // r12d
  int Page; // eax
  int v16; // r13d
  char v17; // r12
  unsigned int inited; // eax
  unsigned int v19; // eax
  __int64 v20; // rdx
  __int64 v21; // rsi
  int v22; // eax
  int v23; // ecx
  int v24; // edi
  unsigned int v25; // edx
  int v26; // eax
  __int64 v27; // r12
  unsigned int *v28; // r15
  int v29; // eax
  unsigned __int32 v30; // r14d
  __int64 v31; // r12
  unsigned int v32; // r9d
  __int64 v33; // rsi
  _WORD *v34; // rdx
  unsigned int v35; // r12d
  unsigned int v36; // esi
  __int64 v37; // rdx
  unsigned int v38; // r8d
  unsigned __int32 v39; // edx
  int v40; // edx
  __int64 v41; // rax
  __int64 v42; // rcx
  unsigned int v43; // edx
  unsigned int v44; // esi
  unsigned __int32 v45; // r12d
  int v46; // eax
  int v47; // r12d
  __int64 v48; // rcx
  __int64 v49; // rax
  __int64 v50; // r12
  unsigned int v51; // edx
  __int64 v52; // rax
  __int64 v53; // rcx
  unsigned int v54; // edx
  unsigned int v55; // esi
  __int64 v56; // r8
  unsigned __int16 v57; // ax
  unsigned int v58; // ecx
  __int64 v59; // rax
  int v60; // edx
  __int64 v61; // rcx
  __int64 v62; // rdx
  unsigned int v63; // esi
  unsigned int v64; // edi
  unsigned __int16 v65; // ax
  unsigned int v66; // eax
  int v67; // r12d
  unsigned __int16 v68; // r13
  unsigned int v69; // ecx
  unsigned int v70; // ecx
  __int64 v71; // rdx
  unsigned int v72; // edi
  unsigned int *v73; // r8
  unsigned int v74; // esi
  __int64 v75; // rax
  unsigned int v76; // edi
  unsigned int v77; // edx
  int v78; // edx
  int v79; // ecx
  __int64 v80; // [rsp+8h] [rbp-E8h] BYREF
  unsigned int v81; // [rsp+18h] [rbp-D8h]
  unsigned __int16 v82; // [rsp+1Ch] [rbp-D4h]
  unsigned __int16 v83; // [rsp+1Eh] [rbp-D2h]
  unsigned int *v84; // [rsp+20h] [rbp-D0h]
  __int64 v85; // [rsp+28h] [rbp-C8h]
  __int64 v86; // [rsp+30h] [rbp-C0h]
  int v87; // [rsp+38h] [rbp-B8h]
  int v88; // [rsp+3Ch] [rbp-B4h]
  unsigned int v89; // [rsp+40h] [rbp-B0h]
  unsigned __int32 v90; // [rsp+44h] [rbp-ACh]
  char *v91; // [rsp+48h] [rbp-A8h] BYREF
  __int64 v92; // [rsp+50h] [rbp-A0h]
  __int64 v93; // [rsp+58h] [rbp-98h]
  _QWORD *v94; // [rsp+60h] [rbp-90h]
  __int64 v95; // [rsp+68h] [rbp-88h]
  __int64 v96; // [rsp+70h] [rbp-80h]
  unsigned int v97; // [rsp+78h] [rbp-78h]
  int v98; // [rsp+7Ch] [rbp-74h]
  __int64 v99; // [rsp+80h] [rbp-70h] BYREF
  _WORD *v100; // [rsp+88h] [rbp-68h]
  __int64 v101; // [rsp+90h] [rbp-60h]
  int v102; // [rsp+9Ch] [rbp-54h]
  __m128 v103; // [rsp+A0h] [rbp-50h]
  __int64 v104; // [rsp+B0h] [rbp-40h]
  unsigned int v105; // [rsp+B8h] [rbp-38h]
  char v106; // [rsp+BFh] [rbp-31h]
  __int64 v107; // [rsp+C0h] [rbp-30h]

  v99 = a4; /*0x103070fdd*/
  v91 = nullptr; /*0x103070fe1*/
  v6 = *(_QWORD *)(a1 + 48); /*0x103070fec*/
  v7 = (__m128)*(unsigned __int64 *)(a1 + 60); /*0x103070ff4*/
  if ( *(_DWORD *)(*(_QWORD *)(a1 + 112) + 384LL) != 0 ) /*0x103071001*/
  {
    *(_DWORD *)(a1 + 36) = 9; /*0x103071003*/
    ++*(_DWORD *)(a1 + 32); /*0x10307100a*/
    *(_DWORD *)(a1 + 28) = 0; /*0x10307100d*/
    v8 = -1; /*0x103071014*/
    goto LABEL_3; /*0x103071014*/
  }
  v8 = -1; /*0x103071060*/
  if ( *(_DWORD *)(a1 + 28) == 0 ) /*0x10307106a*/
  {
LABEL_3:
    v9 = (__int64)v91; /*0x10307101a*/
    if ( v91 != nullptr ) /*0x103071024*/
      goto LABEL_4; /*0x103071024*/
    goto LABEL_5; /*0x103071024*/
  }
  v11 = 0; /*0x10307106c*/
  if ( (_DWORD)a2 == 0 ) /*0x103071071*/
    return v11; /*0x103071071*/
  v96 = a3; /*0x103071073*/
  v103 = v7; /*0x103071077*/
  v107 = v6; /*0x10307107b*/
  v13 = *(_QWORD **)a1; /*0x10307107f*/
  v92 = *(unsigned int *)(*(_QWORD *)a1 + 56LL); /*0x103071086*/
  v14 = a2; /*0x103071090*/
  if ( (unsigned int)checkRef(a1, a2) != 0 ) /*0x10307109a*/
    return v11; /*0x10307109a*/
  *(_QWORD *)(a1 + 48) = "Tree %u page %u: ";
  *(_DWORD *)(a1 + 60) = v14; /*0x1030710a7*/
  Page = btreeGetPage(a1: v13, a2: v14, a3: &v91); /*0x1030710ba*/
  if ( Page != 0 ) /*0x1030710c1*/
  {
    v16 = Page; /*0x1030710c3*/
    checkAppendMsg(a1, a2: "unable to get the page. error code=%d", Page); /*0x1030710d4*/
    v8 = -1; /*0x1030710e0*/
    if ( v16 == 3082 ) /*0x1030710e6*/
      *(_DWORD *)(a1 + 36) = 7; /*0x1030710e8*/
    goto LABEL_17; /*0x1030710ef*/
  }
  v94 = v13; /*0x1030710f1*/
  v105 = v14; /*0x1030710f8*/
  v9 = (__int64)v91; /*0x1030710fc*/
  v17 = *v91; /*0x103071103*/
  *v91 = 0; /*0x103071107*/
  inited = btreeInitPage(a1: v9); /*0x10307110f*/
  v8 = -1; /*0x103071116*/
  if ( inited != 0 ) /*0x10307111c*/
  {
    checkAppendMsg(a1, a2: "btreeInitPage() returns error code %d", inited); /*0x103071125*/
LABEL_17:
    v6 = v107; /*0x103071146*/
    v7 = v103; /*0x10307114a*/
    goto LABEL_3; /*0x10307114e*/
  }
  v19 = btreeComputeFreeSpace(a1: v9); /*0x10307112a*/
  if ( v19 != 0 ) /*0x103071131*/
  {
    checkAppendMsg(a1, a2: "free space corruption", v19); /*0x103071141*/
    goto LABEL_17; /*0x103071141*/
  }
  v106 = v17; /*0x103071153*/
  v20 = *(_QWORD *)(v9 + 80); /*0x103071157*/
  v21 = *(unsigned __int8 *)(v9 + 9); /*0x10307115b*/
  *(_QWORD *)(a1 + 48) = "Tree %u page %u cell %u: ";
  v22 = *(unsigned __int8 *)(v20 + v21 + 5) << 8; /*0x103071170*/
  v23 = *(unsigned __int8 *)(v20 + v21 + 6); /*0x103071173*/
  v101 = v20; /*0x103071178*/
  v24 = v22 + v23 - 1; /*0x103071188*/
  v25 = (unsigned __int16)__ROL2__(*(_WORD *)(v20 + v21 + 3), 8); /*0x10307118a*/
  v26 = *(unsigned __int8 *)(v9 + 8); /*0x10307118d*/
  if ( *(_BYTE *)(v9 + 8) != 0 || *(_BYTE *)(v9 + 1) == 0 ) /*0x1030711a3*/
    *(_QWORD *)(a1 + 120) += v25; /*0x103071198*/
  v85 = (unsigned __int16)v25; /*0x1030711a5*/
  v27 = v21 - (unsigned int)(4 * v26); /*0x1030711b6*/
  v7 = v103; /*0x1030711bb*/
  v86 = v21; /*0x1030711bf*/
  if ( v26 != 0 )
  {
    v28 = *(unsigned int **)(a1 + 104); /*0x1030711c8*/
    *v28 = 0; /*0x1030711cc*/
    v29 = 1; /*0x1030711d3*/
  }
  else
  {
    LODWORD(v93) = v24; /*0x1030711da*/
    v30 = _byteswap_ulong(*(_DWORD *)(v101 + v21 + 8)); /*0x1030711e9*/
    if ( *((_BYTE *)v94 + 33) != 0 )
    {
      *(_QWORD *)(a1 + 48) = "Tree %u page %u right child: ";
      checkPtrmap(a1, a2: v30, a3: 5u, a4: v105); /*0x103071212*/
    }
    v8 = checkTreePage(a1, a2: v30, a3: &v99, a4, a5: *(double *)v7.i64); /*0x103071229*/
    v28 = nullptr; /*0x10307122c*/
    v29 = 0; /*0x10307122f*/
    v7 = v103; /*0x103071231*/
    LOWORD(v24) = v93; /*0x103071235*/
  }
  v31 = v27 + 12; /*0x10307123b*/
  v32 = (unsigned __int16)v24; /*0x10307123f*/
  v6 = v107; /*0x10307124c*/
  v104 = (unsigned __int16)v24; /*0x103071250*/
  v95 = v31; /*0x103071254*/
  if ( (_DWORD)v85 == 0 ) /*0x10307125b*/
  {
    *(_QWORD *)v96 = v99; /*0x103071552*/
    *(_QWORD *)(a1 + 48) = 0; /*0x103071555*/
LABEL_61:
    if ( *(int *)(a1 + 28) > 0 ) /*0x103071561*/
    {
      if ( *(_BYTE *)(v9 + 8) == 0 ) /*0x10307156c*/
      {
        v28 = *(unsigned int **)(a1 + 104); /*0x103071572*/
        *v28 = 0; /*0x103071576*/
        if ( (_DWORD)v85 != 0 ) /*0x103071586*/
        {
          v48 = (unsigned int)v85; /*0x10307158c*/
          v49 = v101 + v95; /*0x103071595*/
          v95 += v101; /*0x103071599*/
          do /*0x103071615*/
          {
            v96 = v48; /*0x1030715a0*/
            v50 = (unsigned __int16)__ROL2__(*(_WORD *)(v49 + 2 * v48 - 2), 8); /*0x1030715ad*/
            v51 = ((_DWORD)v50 << 16) /*0x1030715cf*/
                | (v50
                 + (*(unsigned __int16 (__fastcall **)(__int64, __int64, double))(v9 + 120))(
                     a1: v9,
                     a2: v101 + v50,
                     a3: *(double *)v7.i64)
                 - 1);
            v52 = *v28 + 1; /*0x1030715d4*/
            *v28 = v52; /*0x1030715d6*/
            v28[v52] = v51; /*0x1030715d9*/
            if ( (unsigned int)v52 >= 2 ) /*0x1030715e0*/
            {
              do /*0x1030715fd*/
              {
                v53 = (unsigned int)v52; /*0x1030715e2*/
                v52 = (unsigned int)v52 >> 1; /*0x1030715e4*/
                v54 = v28[v52]; /*0x1030715e6*/
                v55 = v28[v53]; /*0x1030715ea*/
                if ( v54 <= v55 ) /*0x1030715f0*/
                  break; /*0x1030715f0*/
                v28[v52] = v55; /*0x1030715f2*/
                v28[v53] = v54; /*0x1030715f6*/
              }
              while ( (unsigned int)v53 > 3 ); /*0x1030715fd*/
            }
            v48 = v96 - 1; /*0x10307160b*/
            v49 = v95; /*0x10307160e*/
          }
          while ( v96 > 1 ); /*0x103071615*/
          v7 = v103; /*0x103071617*/
          LOWORD(v32) = v104; /*0x10307161b*/
        }
      }
      v56 = v101; /*0x10307161f*/
      v57 = __ROL2__(*(_WORD *)(v101 + v86 + 1), 8); /*0x103071630*/
      if ( v57 != 0 ) /*0x103071637*/
      {
        v58 = v57; /*0x103071639*/
        do /*0x103071693*/
        {
          v59 = v58; /*0x10307163c*/
          v60 = (v58 << 16) | (v58 + (unsigned __int16)__ROL2__(*(_WORD *)(v56 + v58 + 2), 8) - 1); /*0x103071654*/
          v61 = *v28 + 1; /*0x103071659*/
          *v28 = v61; /*0x10307165b*/
          v28[v61] = v60; /*0x10307165e*/
          if ( (unsigned int)v61 >= 2 ) /*0x103071665*/
          {
            do /*0x103071682*/
            {
              v62 = (unsigned int)v61; /*0x103071667*/
              v61 = (unsigned int)v61 >> 1; /*0x103071669*/
              v63 = v28[v61]; /*0x10307166b*/
              v64 = v28[v62]; /*0x10307166f*/
              if ( v63 <= v64 ) /*0x103071675*/
                break; /*0x103071675*/
              v28[v61] = v64; /*0x103071677*/
              v28[v62] = v63; /*0x10307167b*/
            }
            while ( (unsigned int)v62 > 3 ); /*0x103071682*/
          }
          v65 = __ROL2__(*(_WORD *)(v56 + v59), 8); /*0x103071689*/
          v58 = v65; /*0x10307168d*/
        }
        while ( v65 != 0 ); /*0x103071693*/
      }
      v66 = *v28; /*0x103071695*/
      v67 = 0; /*0x103071698*/
      if ( *v28 == 0 ) /*0x10307169d*/
        goto LABEL_89; /*0x10307169d*/
      v68 = v32; /*0x1030716a3*/
      while ( 1 ) /*0x1030716a6*/
      {
        v69 = v66; /*0x1030716a6*/
        v32 = v28[1]; /*0x1030716a8*/
        v28[1] = v28[v66]; /*0x1030716b2*/
        v28[v66--] = -1; /*0x1030716b6*/
        *v28 = v66; /*0x1030716c1*/
        if ( v69 >= 3 ) /*0x1030716c7*/
        {
          v70 = v28[1]; /*0x1030716c9*/
          v71 = (unsigned int)(v28[3] < v28[2]) + 2; /*0x1030716da*/
          v72 = v28[v71]; /*0x1030716dd*/
          if ( v70 >= v72 ) /*0x1030716e3*/
          {
            v73 = &v28[v71]; /*0x1030716e5*/
            v74 = 1; /*0x1030716e9*/
            do /*0x10307171e*/
            {
              v75 = v74; /*0x1030716ee*/
              v74 = v71; /*0x1030716f0*/
              v28[v75] = v72; /*0x1030716f2*/
              *v73 = v70; /*0x1030716f6*/
              v76 = 2 * v71; /*0x1030716f9*/
              v66 = *v28; /*0x1030716fc*/
              if ( 2 * (int)v71 > *v28 ) /*0x103071701*/
                break; /*0x103071701*/
              v71 = v76 | 1; /*0x10307170b*/
              if ( v28[v76] <= v28[v71] ) /*0x103071712*/
                v71 = v76; /*0x103071712*/
              v73 = &v28[v71]; /*0x103071715*/
              v72 = *v73; /*0x103071719*/
            }
            while ( v70 >= *v73 ); /*0x10307171e*/
          }
        }
        v77 = HIWORD(v32); /*0x103071727*/
        if ( v68 >= HIWORD(v32) ) /*0x10307172c*/
          break; /*0x10307172c*/
        v67 += v77 + ~v68; /*0x103071733*/
        v68 = v32; /*0x103071736*/
        if ( v66 == 0 ) /*0x10307173b*/
          goto LABEL_89; /*0x10307173b*/
      }
      checkAppendMsg(a1, a2: "Multiple uses for byte %u of page %u", v77, v105); /*0x103071752*/
      v7 = v103; /*0x103071757*/
      LOWORD(v32) = v68; /*0x10307175f*/
      if ( *v28 == 0 ) /*0x103071762*/
      {
LABEL_89:
        v78 = v67 + (~(_WORD)v32 | 0xFFFF0000) + v92; /*0x103071764*/
        v79 = *(unsigned __int8 *)(v101 + v86 + 7); /*0x103071786*/
        if ( v78 != v79 ) /*0x10307178d*/
        {
          checkAppendMsg(a1, a2: "Fragmentation of %u bytes reported as %u on page %u", v78, v79, v105); /*0x10307179f*/
          v7 = v103; /*0x1030717a4*/
        }
      }
      v6 = v107; /*0x1030717a8*/
    }
    goto LABEL_3; /*0x1030717ac*/
  }
  v102 = v29; /*0x103071261*/
  v87 = (unsigned __int16)v24 + 1; /*0x103071271*/
  v33 = (unsigned int)(v85 - 1); /*0x103071277*/
  v34 = (_WORD *)(v101 + (int)v31 + 2 * (int)v85 - 2); /*0x10307127d*/
  v97 = v92 - 4; /*0x10307128b*/
  v88 = v92 - 5; /*0x103071291*/
  v98 = 1; /*0x103071297*/
  while ( *(_DWORD *)(a1 + 28) != 0 ) /*0x1030712a2*/
  {
    v93 = v33; /*0x1030712a8*/
    *(_DWORD *)(a1 + 64) = v33; /*0x1030712af*/
    v100 = v34; /*0x1030712b2*/
    v35 = (unsigned __int16)__ROL2__(*v34, 8); /*0x1030712bd*/
    if ( v35 <= v32 || v35 > v97 ) /*0x1030712ce*/
    {
      v98 = 0; /*0x1030712d8*/
      checkAppendMsg(a1, a2: "Offset %u out of range %u..%u", v35, v87, v97); /*0x1030712f4*/
      goto LABEL_33; /*0x1030712f9*/
    }
    v84 = (unsigned int *)(v101 + v35); /*0x103071305*/
    (*(void (__fastcall **)(__int64, unsigned int *, __int64 *, double))(v9 + 128))( /*0x103071313*/
      a1: v9,
      a2: v84,
      a3: &v80,
      a4: *(double *)v7.i64);
    v36 = v35; /*0x10307131a*/
    if ( v35 + v83 > (unsigned int)v92 ) /*0x10307132c*/
    {
      v98 = 0; /*0x10307132e*/
      checkAppendMsg(a1, a2: "Extends off end of page"); /*0x103071341*/
      goto LABEL_33; /*0x103071341*/
    }
    if ( *(_BYTE *)(v9 + 1) == 0 ) /*0x103071378*/
    {
      v7 = v103; /*0x1030713c4*/
      v32 = v104; /*0x1030713c8*/
      goto LABEL_42; /*0x1030713c8*/
    }
    v37 = v80; /*0x10307137a*/
    if ( v102 == 0 ) /*0x103071389*/
    {
      if ( v80 < v99 ) /*0x1030714f7*/
        goto LABEL_40; /*0x1030714f7*/
LABEL_39:
      checkAppendMsg(a1, a2: "Rowid %lld out of order", v80); /*0x103071394*/
      v36 = v35; /*0x1030713a5*/
      v37 = v80; /*0x1030713a8*/
      goto LABEL_40; /*0x1030713a8*/
    }
    if ( v80 > v99 ) /*0x103071392*/
      goto LABEL_39; /*0x103071392*/
LABEL_40:
    v7 = v103; /*0x1030713af*/
    v32 = v104; /*0x1030713b3*/
    v99 = v37; /*0x1030713b7*/
    v102 = 0; /*0x1030713bb*/
LABEL_42:
    if ( v81 > v82 ) /*0x1030713db*/
    {
      v38 = (v88 + v81 - v82) / v97; /*0x1030713ea*/
      v39 = _byteswap_ulong(*(unsigned int *)((char *)v84 + v83 - 4)); /*0x1030713ff*/
      if ( *((_BYTE *)v94 + 33) != 0 ) /*0x10307140c*/
      {
        v90 = v39; /*0x103071413*/
        v89 = (v88 + v81 - v82) / v97; /*0x103071421*/
        checkPtrmap(a1, a2: v39, a3: 3u, a4: v105); /*0x103071428*/
        v39 = v90; /*0x10307142d*/
        v38 = v89; /*0x103071433*/
      }
      checkList((__int64 *)a1, a2: 0, a3: v39, a4: v38); /*0x103071442*/
      v7 = v103; /*0x103071447*/
      v32 = v104; /*0x10307144b*/
      v36 = v35; /*0x10307144f*/
    }
    if ( *(_BYTE *)(v9 + 8) != 0 ) /*0x103071457*/
    {
      v40 = (v36 << 16) | (v36 + v83 - 1); /*0x10307146a*/
      v41 = *v28 + 1; /*0x10307146f*/
      *v28 = v41; /*0x103071471*/
      v28[v41] = v40; /*0x103071474*/
      if ( (unsigned int)v41 >= 2 ) /*0x10307147b*/
      {
        do /*0x103071498*/
        {
          v42 = (unsigned int)v41; /*0x10307147d*/
          v41 = (unsigned int)v41 >> 1; /*0x10307147f*/
          v43 = v28[v41]; /*0x103071481*/
          v44 = v28[v42]; /*0x103071485*/
          if ( v43 <= v44 ) /*0x10307148b*/
            break; /*0x10307148b*/
          v28[v41] = v44; /*0x10307148d*/
          v28[v42] = v43; /*0x103071491*/
        }
        while ( (unsigned int)v42 > 3 ); /*0x103071498*/
      }
      v6 = v107; /*0x10307149a*/
      goto LABEL_34; /*0x10307149e*/
    }
    v45 = _byteswap_ulong(*v84); /*0x1030714ad*/
    if ( *((_BYTE *)v94 + 33) != 0 ) /*0x1030714bb*/
      checkPtrmap(a1, a2: v45, a3: 5u, a4: v105); /*0x1030714cb*/
    v46 = checkTreePage(a1, a2: v45, a3: &v99, a4: v99, a5: *(double *)v7.i64); /*0x1030714de*/
    if ( v46 == v8 ) /*0x1030714e6*/
    {
      v102 = 0; /*0x1030714e8*/
    }
    else
    {
      v47 = v46; /*0x103071502*/
      v102 = 0; /*0x103071505*/
      checkAppendMsg(a1, a2: "Child page depth differs"); /*0x103071518*/
      v8 = v47; /*0x10307151d*/
    }
LABEL_33:
    v6 = v107; /*0x103071346*/
    v7 = v103; /*0x10307134a*/
    v32 = v104; /*0x10307134e*/
LABEL_34:
    v34 = v100 - 1; /*0x103071352*/
    v33 = (unsigned int)(v93 - 1); /*0x103071366*/
    if ( (int)v93 <= 0 ) /*0x103071368*/
      break; /*0x103071368*/
  }
  *(_QWORD *)v96 = v99; /*0x103071525*/
  *(_QWORD *)(a1 + 48) = 0; /*0x103071530*/
  if ( v98 != 0 ) /*0x10307153c*/
    goto LABEL_61; /*0x10307153c*/
  *(_BYTE *)v9 = v106; /*0x103071541*/
LABEL_4:
  v103 = v7; /*0x103071026*/
  v10 = v6; /*0x10307102e*/
  sqlite3PagerUnrefNotNull(a1: *(_QWORD *)(v9 + 112)); /*0x103071031*/
  v7 = v103; /*0x103071036*/
  v6 = v10; /*0x10307103a*/
LABEL_5:
  *(_QWORD *)(a1 + 48) = v6; /*0x10307103d*/
  _mm_storel_ps((double *)(a1 + 60), v7); /*0x103071041*/
  return (unsigned int)(v8 + 1); /*0x10307104e*/
}

// Address: 0x1030717b1 | Name: _checkRef
__int64 __fastcall checkRef(__int64 a1, unsigned int a2)
{
  __int64 v3; // rax
  __int64 v4; // rsi
  int v5; // r8d
  unsigned int v6; // ebx

  if ( a2 - 1 >= *(_DWORD *)(a1 + 24) ) /*0x1030717bf*/
  {
    checkAppendMsg(a1, a2: "invalid page number %u", a2); /*0x103071806*/
    return 1; /*0x10307180b*/
  }
  else
  {
    v3 = *(_QWORD *)(a1 + 16); /*0x1030717c1*/
    v4 = a2 >> 3; /*0x1030717c7*/
    v5 = *(unsigned __int8 *)(v3 + v4); /*0x1030717ca*/
    v6 = 1; /*0x1030717dd*/
    if ( _bittest(&v5, a2 & 7) ) /*0x1030717e7*/
    {
      checkAppendMsg(a1, a2: "2nd reference to page %u", a2); /*0x1030717f6*/
    }
    else
    {
      *(_BYTE *)(v3 + v4) = v5 | (1 << (a2 & 7)); /*0x103071815*/
      return 0; /*0x103071819*/
    }
  }
  return v6; /*0x103071821*/
}

// Address: 0x10308d3ec | Name: _codeInteger
__int64 __fastcall codeInteger(__int64 a1, __int64 a2, unsigned int a3, __int64 a4)
{
  int v5; // r15d
  __int64 v6; // r14
  int v7; // r13d
  char *v8; // rbx
  int v9; // eax
  int v10; // r8d
  int v11; // r9d
  unsigned __int64 v12; // rcx
  __int64 v13; // rcx
  int v14; // esi
  unsigned __int8 v15; // di
  __int64 v16; // rdx
  const char *v18; // rdx
  unsigned __int64 v19; // [rsp+8h] [rbp-38h] BYREF
  unsigned int v20; // [rsp+14h] [rbp-2Ch]

  v5 = a2; /*0x10308d400*/
  v6 = *(_QWORD *)(a1 + 16); /*0x10308d403*/
  if ( (*(_BYTE *)(a2 + 5) & 8) != 0 )
  {
    v16 = (unsigned int)-*(_DWORD *)(a2 + 8); /*0x10308d499*/
    if ( a3 == 0 ) /*0x10308d49e*/
      v16 = *(unsigned int *)(a2 + 8); /*0x10308d49e*/
    return sqlite3VdbeAddOp3(a1: *(_QWORD *)(a1 + 16), a2: 72, a3: v16, a4, a5: 0); /*0x10308d4ba*/
  }
  else
  {
    v7 = a1; /*0x10308d411*/
    v20 = a4; /*0x10308d414*/
    v8 = *(char **)(a2 + 8); /*0x10308d417*/
    v9 = sqlite3DecOrHexToI64(__s: v8); /*0x10308d422*/
    if ( v9 == 2 || (a3 | v9 ^ 3) == 0 || (v12 = -(__int64)v19, ((a3 != 0) & __OFSUB__(-(__int64)v19, 1)) == 1) )
    {
      if ( v8 != nullptr )
      {
        v13 = 0; /*0x10308d45e*/
        while ( v8[v13] != 0 ) /*0x10308d475*/
        {
          v14 = (unsigned __int8)sqlite3UpperToLower[(unsigned __int8)v8[v13]]; /*0x10308d477*/
          v15 = sqlite3UpperToLower[(unsigned __int8)a0x_1[v13]]; /*0x10308d47f*/
          if ( (_BYTE)v14 != v15 ) /*0x10308d486*/
            goto LABEL_20; /*0x10308d486*/
          if ( ++v13 == 2 ) /*0x10308d48f*/
            goto LABEL_21; /*0x10308d48f*/
        }
        v15 = sqlite3UpperToLower[(unsigned __int8)a0x_1[v13]]; /*0x10308d4f9*/
        v14 = 0; /*0x10308d4fd*/
LABEL_20:
        if ( v14 != v15 ) /*0x10308d505*/
          return codeReal(a1: v6, a2: v8, a3, a4: v20); /*0x10308d505*/
LABEL_21:
        v18 = ""; /*0x10308d507*/
        if ( a3 != 0 ) /*0x10308d518*/
          v18 = "-"; /*0x10308d518*/
        return sqlite3ErrorMsg(
                 a1: v7,
                 a2: (unsigned int)"hex literal too big: %s%#T",
                 a3: (_DWORD)v18,
                 a4: v5,
                 a5: v10,
                 a6: v11);
      }
      else
      {
        return codeReal(a1: v6, a2: v8, a3, a4: v20); /*0x10308d532*/
      }
    }
    else
    {
      if ( a3 != 0 ) /*0x10308d4c2*/
      {
        if ( v9 == 3 ) /*0x10308d4d1*/
          v12 = 0x8000000000000000LL; /*0x10308d4d1*/
        v19 = v12; /*0x10308d4d5*/
      }
      return sqlite3VdbeAddOp4Dup8(a1: v6, a2: 73, a3: v20, a4: &v19, a5: 4294967283LL); /*0x10308d4ee*/
    }
  }
}

// Address: 0x10308d58d | Name: _codeReal
void __fastcall codeReal(__int64 a1, const char *a2, int a3, unsigned int a4)
{
  int v8; // eax
  double v9[6]; // [rsp-30h] [rbp-30h] BYREF

  if ( a2 != nullptr ) /*0x10308d590*/
  {
    v8 = strlen(__s: a2); /*0x10308d5af*/
    sqlite3AtoF(a1: a2, a2: v9, a3: v8 & 0x3FFFFFFF, a4: 1); /*0x10308d5c7*/
    if ( a3 != 0 ) /*0x10308d5cf*/
      _mm_storel_ps(v9, _mm_xor_ps((__m128)*(unsigned __int64 *)&v9[0], (__m128)xmmword_108F34F50)); /*0x10308d5dd*/
    sqlite3VdbeAddOp4Dup8(a1, a2: 154, a3: a4, a4: v9, a5: 4294967284LL); /*0x10308d5f5*/
  }
}

// Address: 0x10308d82d | Name: _codeCompare
void __fastcall codeCompare(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        unsigned int a4,
        unsigned int a5,
        unsigned int a6,
        unsigned int a7,
        char a8,
        int a9)
{
  __int64 v11; // r14
  __int64 v12; // r13
  char v14; // al
  char v15; // r14
  __int64 v16; // r13
  unsigned int v17; // eax
  __int64 v18; // rax
  __int64 v19; // rcx
  __int64 v20; // [rsp-40h] [rbp-40h]

  if ( *(_DWORD *)(a1 + 56) == 0 ) /*0x10308d831*/
  {
    v11 = a3; /*0x10308d84b*/
    v12 = a2; /*0x10308d84e*/
    if ( a9 != 0 ) /*0x10308d85c*/
    {
      a2 = a3; /*0x10308d85e*/
      a3 = v12; /*0x10308d861*/
    }
    v20 = sqlite3BinaryCompareCollSeq(a1, a2, a3); /*0x10308d871*/
    v14 = sqlite3ExprAffinity(a1: v11); /*0x10308d878*/
    v15 = sqlite3CompareAffinity(a1: v12, a2: (unsigned int)v14); /*0x10308d888*/
    v16 = *(_QWORD *)(a1 + 16); /*0x10308d88b*/
    v17 = sqlite3VdbeAddOp3(a1: v16, a2: a4, a3: a6, a4: a7, a5); /*0x10308d89f*/
    sqlite3VdbeChangeP4(a1: v16, a2: v17, a3: v20, a4: 4294967294LL); /*0x10308d8b2*/
    v18 = *(_QWORD *)(a1 + 16); /*0x10308d8b7*/
    v19 = *(int *)(v18 + 144); /*0x10308d8bb*/
    if ( v19 > 0 ) /*0x10308d8c5*/
      *(_WORD *)(*(_QWORD *)(v18 + 136) + 24 * v19 - 22) = (unsigned __int8)(a8 | v15); /*0x10308d8dc*/
  }
}

// Address: 0x1030939c3 | Name: _convertToWithoutRowidTable
__int64 __fastcall convertToWithoutRowidTable(_QWORD *a1, __int64 a2)
{
  __int64 v2; // r12
  __int64 v4; // r15
  _QWORD *v5; // rbx
  __int16 v6; // ax
  __int64 v7; // rcx
  __int64 i; // rdx
  __int64 v9; // rsi
  char v10; // di
  _DWORD *v11; // rax
  __int64 v12; // rax
  const char *v13; // rdi
  size_t v14; // rax
  __int64 v15; // r15
  unsigned __int16 v16; // r14
  int v17; // r13d
  unsigned __int64 j; // r12
  __int64 v19; // rdx
  __int64 v20; // rax
  __int64 result; // rax
  _QWORD *v22; // rcx
  __int16 v23; // ax
  __int64 v24; // r14
  _BYTE *v25; // rax
  __int64 v26; // r12
  __int64 v27; // r15
  unsigned int v28; // r14d
  int v29; // r13d
  unsigned int v30; // ebx
  int v31; // ebx
  __int64 v32; // r13
  __int64 v33; // rax
  __int64 v34; // rsi
  int v35; // edx
  _QWORD *v36; // rdi
  __int16 *v37; // r11
  int v38; // r8d
  int v39; // r9d
  __int64 v40; // r10
  __int16 v41; // dx
  __int64 k; // rax
  __int16 *v43; // rdi
  int v44; // r8d
  int v45; // r9d
  _QWORD v46[2]; // [rsp+28h] [rbp-58h] BYREF
  __int64 v47; // [rsp+38h] [rbp-48h]
  __int64 v48; // [rsp+40h] [rbp-40h]
  _QWORD *v49; // [rsp+48h] [rbp-38h]
  __int64 v50; // [rsp+50h] [rbp-30h]

  v2 = a2; /*0x1030939d4*/
  v4 = *a1; /*0x1030939da*/
  v5 = (_QWORD *)a1[2]; /*0x1030939dd*/
  if ( (*(_BYTE *)(*a1 + 198LL) & 6) == 0 ) /*0x1030939e9*/
  {
    v6 = *(_WORD *)(a2 + 54); /*0x1030939eb*/
    if ( v6 > 0 ) /*0x1030939f4*/
    {
      v7 = 8; /*0x1030939f6*/
      for ( i = 0; i < v6; ++i ) /*0x1030939fb*/
      {
        v9 = *(_QWORD *)(v2 + 8); /*0x1030939fd*/
        if ( (*(_BYTE *)(v9 + v7 + 6) & 1) != 0 ) /*0x103093a07*/
        {
          v10 = *(_BYTE *)(v9 + v7); /*0x103093a09*/
          if ( (v10 & 0xF) == 0 ) /*0x103093a11*/
          {
            *(_BYTE *)(v9 + v7) = v10 | 2; /*0x103093a17*/
            v6 = *(_WORD *)(v2 + 54); /*0x103093a1b*/
          }
        }
        v7 += 16; /*0x103093a28*/
      }
    }
    *(_BYTE *)(v2 + 49) |= 8u; /*0x103093a31*/
  }
  if ( *((_DWORD *)a1 + 60) != 0 ) /*0x103093a41*/
  {
    if ( *(_BYTE *)(*v5 + 103LL) != 0 ) /*0x103093a4a*/
      v11 = &sqlite3VdbeGetOp_dummy; /*0x103093a4c*/
    else
      v11 = (_DWORD *)(v5[17] + 24LL * *((int *)a1 + 60)); /*0x103093a5d*/
    v11[3] = 2; /*0x103093a64*/
  }
  v12 = *(__int16 *)(v2 + 52); /*0x103093a6b*/
  if ( v12 < 0 ) /*0x103093a74*/
  {
    v48 = v4; /*0x103093a9f*/
    v15 = *(_QWORD *)(v2 + 16); /*0x103093aa3*/
    v49 = a1; /*0x103093aab*/
    if ( v15 != 0 ) /*0x103093aaf*/
    {
      while ( (*(_WORD *)(v15 + 99) & 3) != 2 ) /*0x103093abd*/
      {
        v15 = *(_QWORD *)(v15 + 40); /*0x103093abf*/
        if ( v15 == 0 ) /*0x103093ac6*/
          goto LABEL_20; /*0x103093ac6*/
      }
    }
    else
    {
LABEL_20:
      v15 = 0; /*0x103093ac8*/
    }
    v16 = *(_WORD *)(v15 + 94); /*0x103093acb*/
    LOWORD(v17) = 1; /*0x103093ad0*/
    if ( v16 >= 2u ) /*0x103093ada*/
    {
      v50 = v2; /*0x103093adc*/
      v17 = 1; /*0x103093ae0*/
      for ( j = 1; j < v16; ++j ) /*0x103093ae6*/
      {
        if ( (unsigned int)isDupColumn(a1: v15, a2: (unsigned int)v17, a3: v15, a4: (unsigned int)j) != 0 ) /*0x103093aff*/
        {
          --*(_WORD *)(v15 + 96); /*0x103093b01*/
        }
        else
        {
          v19 = v17; /*0x103093b10*/
          *(_QWORD *)(*(_QWORD *)(v15 + 64) + 8LL * v17) = *(_QWORD *)(*(_QWORD *)(v15 + 64) + 8 * j); /*0x103093b13*/
          *(_BYTE *)(*(_QWORD *)(v15 + 56) + v17++) = *(_BYTE *)(*(_QWORD *)(v15 + 56) + j); /*0x103093b1f*/
          *(_WORD *)(*(_QWORD *)(v15 + 8) + 2 * v19) = *(_WORD *)(*(_QWORD *)(v15 + 8) + 2 * j); /*0x103093b2e*/
          v16 = *(_WORD *)(v15 + 94); /*0x103093b32*/
        }
      }
      v2 = v50; /*0x103093b43*/
    }
    *(_WORD *)(v15 + 94) = v17; /*0x103093b47*/
  }
  else
  {
    v13 = *(const char **)(*(_QWORD *)(v2 + 8) + 16 * v12); /*0x103093a7f*/
    v46[0] = v13; /*0x103093a83*/
    if ( v13 != nullptr ) /*0x103093a8a*/
      v14 = strlen(__s: v13) & 0x3FFFFFFF; /*0x103093a95*/
    else
      LODWORD(v14) = 0; /*0x103093b51*/
    LODWORD(v46[1]) = v14; /*0x103093b57*/
    v20 = sqlite3ExprAlloc(a1: v4, a2: 60, a3: v46, a4: 0); /*0x103093b64*/
    result = sqlite3ExprListAppendNew(a1: *a1, a2: v20); /*0x103093b70*/
    if ( result == 0 ) /*0x103093b78*/
      goto LABEL_38; /*0x103093b78*/
    if ( *((_BYTE *)a1 + 292) >= 2u ) /*0x103093b82*/
    {
      v22 = (_QWORD *)a1[50]; /*0x103093b84*/
      if ( v22 != nullptr ) /*0x103093b8e*/
      {
        while ( *v22 != v2 + 52 ) /*0x103093b9c*/
        {
          v22 = (_QWORD *)v22[3]; /*0x103093b9e*/
          if ( v22 == nullptr ) /*0x103093ba5*/
            goto LABEL_37; /*0x103093ba5*/
        }
        *v22 = *(_QWORD *)(result + 8); /*0x103093ba9*/
      }
    }
LABEL_37:
    *(_BYTE *)(result + 24) = *((_BYTE *)a1 + 290); /*0x103093bb3*/
    *(_WORD *)(v2 + 52) = -1; /*0x103093bb6*/
    result = sqlite3CreateIndex( /*0x103093bec*/
               (_DWORD)a1,
               a2: 0,
               a3: 0,
               a4: 0,
               a5: result,
               a6: *(unsigned __int8 *)(v2 + 62),
               a7: 0,
               a8: 0,
               a9: 0,
               a10: 0,
               a11: 2);
    if ( *((_DWORD *)a1 + 14) != 0 ) /*0x103093bf5*/
    {
LABEL_38:
      *(_BYTE *)(v2 + 48) &= ~0x80u; /*0x103093bf7*/
      return result; /*0x103093bfd*/
    }
    v48 = v4; /*0x103093c02*/
    v15 = *(_QWORD *)(v2 + 16); /*0x103093c06*/
    v49 = a1; /*0x103093c0e*/
    if ( v15 != 0 ) /*0x103093c12*/
    {
      while ( (*(_WORD *)(v15 + 99) & 3) != 2 ) /*0x103093c20*/
      {
        v15 = *(_QWORD *)(v15 + 40); /*0x103093c22*/
        if ( v15 == 0 ) /*0x103093c29*/
          goto LABEL_42; /*0x103093c29*/
      }
    }
    else
    {
LABEL_42:
      v15 = 0; /*0x103093c2b*/
    }
  }
  v23 = *(_WORD *)(v15 + 99); /*0x103093c2e*/
  *(_WORD *)(v15 + 99) = v23 | 0x20; /*0x103093c38*/
  if ( (*(_BYTE *)(v48 + 198) & 6) == 0 ) /*0x103093c48*/
    *(_WORD *)(v15 + 99) = v23 | 0x28; /*0x103093c4d*/
  v24 = *(unsigned __int16 *)(v15 + 94); /*0x103093c52*/
  *(_WORD *)(v15 + 96) = v24; /*0x103093c57*/
  if ( v5 != nullptr && *(_DWORD *)(v15 + 88) != 0 ) /*0x103093c68*/
  {
    if ( *(_BYTE *)(*v5 + 103LL) != 0 ) /*0x103093c71*/
      v25 = &sqlite3VdbeGetOp_dummy; /*0x103093c73*/
    else
      v25 = (_BYTE *)(v5[17] + 24LL * *(int *)(v15 + 88)); /*0x103093c84*/
    *v25 = 9; /*0x103093c8b*/
  }
  *(_DWORD *)(v15 + 88) = *(_DWORD *)(v2 + 40); /*0x103093c93*/
  v50 = v2; /*0x103093c97*/
  v26 = *(_QWORD *)(v2 + 16); /*0x103093c9b*/
  if ( v26 != 0 ) /*0x103093ca3*/
  {
    v48 = (unsigned int)v24; /*0x103093cac*/
    v47 = v15; /*0x103093cb0*/
    do /*0x103093da5*/
    {
      if ( (*(_WORD *)(v26 + 99) & 3) != 2 ) /*0x103093cc1*/
      {
        if ( (_DWORD)v24 == 0 ) /*0x103093cca*/
          goto LABEL_66; /*0x103093cca*/
        v27 = v24; /*0x103093cd0*/
        v28 = *(unsigned __int16 *)(v26 + 94); /*0x103093cd3*/
        v29 = 0; /*0x103093cd9*/
        v30 = 0; /*0x103093cdc*/
        do /*0x103093cfa*/
          v29 += isDupColumn(a1: v26, a2: v28, a3: v47, a4: v30++) ^ 1; /*0x103093cf2*/
        while ( (_DWORD)v27 != v30 ); /*0x103093cfa*/
        v24 = v27; /*0x103093cff*/
        v15 = v47; /*0x103093d02*/
        if ( v29 != 0 ) /*0x103093d06*/
        {
          result = resizeIndexObject(a1: v49, a2: v26, a3: (unsigned int)*(unsigned __int16 *)(v26 + 94) + v29); /*0x103093d1f*/
          if ( (_DWORD)result != 0 ) /*0x103093d26*/
            return result; /*0x103093d26*/
          v31 = *(unsigned __int16 *)(v26 + 94); /*0x103093d2c*/
          v32 = 0; /*0x103093d32*/
          do /*0x103093d8d*/
          {
            if ( (unsigned int)isDupColumn(a1: v26, a2: *(unsigned __int16 *)(v26 + 94), a3: v15, a4: (unsigned int)v32) == 0 ) /*0x103093d4b*/
            {
              *(_WORD *)(*(_QWORD *)(v26 + 8) + 2LL * v31) = *(_WORD *)(*(_QWORD *)(v15 + 8) + 2 * v32); /*0x103093d5e*/
              *(_QWORD *)(*(_QWORD *)(v26 + 64) + 8LL * v31) = *(_QWORD *)(*(_QWORD *)(v15 + 64) + 8 * v32); /*0x103093d6f*/
              if ( *(_BYTE *)(*(_QWORD *)(v15 + 56) + v32) != 0 ) /*0x103093d7c*/
                *(_BYTE *)(v26 + 100) |= 2u; /*0x103093d7e*/
              ++v31; /*0x103093d84*/
            }
            ++v32; /*0x103093d86*/
          }
          while ( v48 != v32 ); /*0x103093d8d*/
        }
        else
        {
LABEL_66:
          *(_WORD *)(v26 + 96) = *(_WORD *)(v26 + 94); /*0x103093d97*/
        }
      }
      v26 = *(_QWORD *)(v26 + 40); /*0x103093d9d*/
    }
    while ( v26 != 0 ); /*0x103093da5*/
  }
  v33 = *(__int16 *)(v50 + 54); /*0x103093daf*/
  if ( v33 <= 0 ) /*0x103093db7*/
  {
    v35 = 0; /*0x103093e0a*/
    v36 = v49; /*0x103093e0c*/
  }
  else
  {
    v34 = 0; /*0x103093dbd*/
    v35 = 0; /*0x103093dbf*/
    v36 = v49; /*0x103093dc1*/
    do /*0x103093e06*/
    {
      v37 = *(__int16 **)(v15 + 8); /*0x103093dc5*/
      v38 = v24; /*0x103093dc8*/
      while ( v38 > 0 ) /*0x103093dce*/
      {
        --v38; /*0x103093dd0*/
        v39 = *v37++; /*0x103093dd3*/
        if ( v34 == v39 ) /*0x103093de1*/
          goto LABEL_75; /*0x103093de1*/
      }
      v35 += (*(_BYTE *)(*(_QWORD *)(v50 + 8) + 16 * v34 + 14) & 0x20) == 0; /*0x103093dfd*/
LABEL_75:
      ++v34; /*0x103093e00*/
    }
    while ( v34 != v33 ); /*0x103093e06*/
  }
  result = resizeIndexObject(a1: v36, a2: v15, a3: (unsigned int)(v24 + v35)); /*0x103093e16*/
  if ( (_DWORD)result == 0 ) /*0x103093e1d*/
  {
    v40 = v50; /*0x103093e1f*/
    v41 = *(_WORD *)(v50 + 54); /*0x103093e23*/
    if ( v41 > 0 ) /*0x103093e2b*/
    {
      for ( k = 0; k < v41; ++k ) /*0x103093e2d*/
      {
        v43 = *(__int16 **)(v15 + 8); /*0x103093e3a*/
        v44 = v24; /*0x103093e3d*/
        while ( v44 > 0 ) /*0x103093e43*/
        {
          --v44; /*0x103093e45*/
          v45 = *v43++; /*0x103093e48*/
          if ( k == v45 ) /*0x103093e56*/
            goto LABEL_87; /*0x103093e56*/
        }
        if ( (*(_BYTE *)(*(_QWORD *)(v40 + 8) + 16 * k + 14) & 0x20) == 0 ) /*0x103093e6b*/
        {
          *(_WORD *)(*(_QWORD *)(v15 + 8) + 2LL * (int)v24) = k; /*0x103093e70*/
          *(_QWORD *)(*(_QWORD *)(v15 + 64) + 8LL * (int)v24) = "BINARY"; /*0x103093e79*/
          LODWORD(v24) = v24 + 1; /*0x103093e7d*/
          v41 = *(_WORD *)(v40 + 54); /*0x103093e80*/
        }
LABEL_87:
        ; /*0x103093e85*/
      }
    }
    return recomputeColumnsNotIndexed(a1: v15); /*0x103093e94*/
  }
  return result; /*0x103093e99*/
}

// Address: 0x103094327 | Name: _createTableStmt
_BYTE *__fastcall createTableStmt(__int64 a1, __int64 a2)
{
  int v4; // eax
  int v5; // edx
  _BYTE **v6; // rsi
  int v7; // edi
  __int64 v8; // rcx
  _BYTE *v9; // r8
  int v10; // r9d
  _BYTE *i; // rsi
  const char *v12; // r14
  const char *v13; // rbx
  _BYTE *v14; // rax
  _BYTE *v15; // r13
  int v16; // r14d
  __int64 v17; // r12
  const char *v18; // r13
  int v19; // edx
  unsigned int v20; // r15d
  unsigned int v21; // r14d
  int v22; // r15d
  const char *v24; // [rsp+8h] [rbp-58h]
  __int64 v25; // [rsp+10h] [rbp-50h]
  _BYTE *v26; // [rsp+20h] [rbp-40h]
  __int64 v27; // [rsp+28h] [rbp-38h]
  int v28; // [rsp+30h] [rbp-30h]
  _DWORD v29[11]; // [rsp+34h] [rbp-2Ch] BYREF

  v4 = *(__int16 *)(a2 + 54); /*0x10309433e*/
  v5 = 0; /*0x103094342*/
  if ( v4 <= 0 ) /*0x103094346*/
  {
    v8 = 0; /*0x103094388*/
    goto LABEL_12; /*0x103094388*/
  }
  v6 = *(_BYTE ***)(a2 + 8); /*0x103094348*/
  v7 = 0; /*0x10309434c*/
  v8 = 0; /*0x10309434e*/
  do /*0x103094384*/
  {
    v9 = *v6; /*0x103094350*/
    v10 = 0; /*0x103094353*/
    while ( *v9 == 34 ) /*0x10309435e*/
    {
      ++v10; /*0x103094367*/
LABEL_8:
      ++v10; /*0x10309436a*/
      ++v9; /*0x10309436d*/
    }
    if ( *v9 != 0 ) /*0x103094363*/
      goto LABEL_8; /*0x103094363*/
    v8 += v10 + 7LL; /*0x103094378*/
    ++v7; /*0x10309437c*/
    v6 += 2; /*0x10309437e*/
  }
  while ( v7 != v4 ); /*0x103094384*/
LABEL_12:
  for ( i = *(_BYTE **)a2; *i == 34; ++i ) /*0x10309438a*/
  {
    ++v5; /*0x10309439b*/
LABEL_17:
    ++v5; /*0x10309439d*/
  }
  if ( *i != 0 ) /*0x103094397*/
    goto LABEL_17; /*0x103094397*/
  v27 = v5 + v8 + 2; /*0x1030943af*/
  v12 = ",\n  "; /*0x1030943be*/
  if ( v27 < 50 ) /*0x1030943c5*/
    v12 = ","; /*0x1030943c5*/
  v13 = "\n)"; /*0x1030943d0*/
  if ( v27 < 50 ) /*0x1030943d7*/
    v13 = ")"; /*0x1030943d7*/
  v14 = (_BYTE *)sqlite3Malloc(a1: v5 + v8 + 6LL * v4 + 37); /*0x1030943ec*/
  v15 = v14; /*0x1030943f1*/
  if ( v14 != nullptr ) /*0x1030943f7*/
  {
    v24 = v12; /*0x1030943fd*/
    qmemcpy(v14, "CREATE TABLE ", 13); /*0x10309441d*/
    v29[0] = 13; /*0x103094425*/
    identPut(a1: v14, a2: v29, a3: *(_QWORD *)a2); /*0x103094436*/
    v16 = v29[0] + 1; /*0x10309443f*/
    v15[v29[0]] = 40; /*0x103094443*/
    v26 = v15; /*0x10309444f*/
    if ( *(__int16 *)(a2 + 54) > 0 ) /*0x103094453*/
    {
      v17 = *(_QWORD *)(a2 + 8); /*0x10309445e*/
      v18 = "\n  "; /*0x103094469*/
      if ( v27 < 50 ) /*0x103094470*/
        v18 = ""; /*0x103094470*/
      v19 = 0; /*0x103094474*/
      v25 = a2; /*0x103094476*/
      do /*0x103094529*/
      {
        v28 = v19; /*0x10309447e*/
        v20 = strlen(__s: v18) & 0x3FFFFFFF; /*0x103094491*/
        memcpy(__dst: &v26[v16], __src: v18, __n: v20); /*0x1030944a9*/
        v29[0] = v20 + v16; /*0x1030944b1*/
        identPut(a1: v26, a2: v29, a3: *(_QWORD *)v17); /*0x1030944c0*/
        v21 = strlen(__s: *((const char **)&createTableStmt_azType + *(char *)(v17 + 9) - 65)) & 0x3FFFFFFF; /*0x1030944ea*/
        v22 = v29[0]; /*0x1030944ed*/
        memcpy( /*0x103094505*/
          __dst: &v26[v29[0]],
          __src: *((const void **)&createTableStmt_azType + *(char *)(v17 + 9) - 65),
          __n: v21);
        v16 = v22 + v21; /*0x10309450d*/
        v29[0] = v16; /*0x103094514*/
        v19 = v28 + 1; /*0x103094518*/
        v17 += 16; /*0x10309451a*/
        v18 = v24; /*0x103094523*/
      }
      while ( v28 + 1 < *(__int16 *)(v25 + 54) ); /*0x103094529*/
    }
    v15 = v26; /*0x10309453c*/
    memcpy(__dst: &v26[v16], __src: v13, __n: (v27 < 50) ^ 3LL); /*0x10309454e*/
  }
  else
  {
    sqlite3OomFault(a1); /*0x103094558*/
  }
  return v15; /*0x103094560*/
}

// Address: 0x103097f52 | Name: _convertCompoundSelectToSubquery
__int64 __fastcall convertCompoundSelectToSubquery(__int64 **a1, unsigned __int8 *a2)
{
  unsigned int v2; // r14d
  unsigned int *v4; // rax
  _OWORD *v5; // r13
  unsigned __int8 *v6; // rcx
  int v7; // edx
  __int64 v9; // rdx
  int v10; // ecx
  unsigned int *v11; // rax
  __int64 v12; // rdx
  __int64 *v13; // r12
  __int64 v14; // rax
  __int64 v15; // r15
  __int64 v16; // rax
  __int128 v17; // xmm0
  __int128 v18; // xmm1
  __int128 v19; // xmm2
  __int64 v20; // rax
  _QWORD v21[4]; // [rsp+10h] [rbp-50h] BYREF
  __int64 v22; // [rsp+30h] [rbp-30h]

  v2 = 0; /*0x103097f63*/
  if ( *((_QWORD *)a2 + 10) != 0 ) /*0x103097f6b*/
  {
    v4 = *((unsigned int **)a2 + 9); /*0x103097f70*/
    if ( v4 != nullptr ) /*0x103097f77*/
    {
      v5 = a2 + 80; /*0x103097f79*/
      v6 = a2; /*0x103097f7d*/
      while ( 1 ) /*0x103097f80*/
      {
        v7 = *v6; /*0x103097f80*/
        if ( v7 != 139 && v7 != 136 ) /*0x103097f91*/
          break; /*0x103097f91*/
        v6 = *((unsigned __int8 **)v6 + 10); /*0x103097f93*/
        if ( v6 == nullptr ) /*0x103097f9a*/
          return v2; /*0x103097f9a*/
      }
      if ( *((_WORD *)v4 + 14) == 0 ) /*0x103097fa3*/
      {
        v9 = *v4; /*0x103097fb7*/
        v10 = v9 + 1; /*0x103097fb9*/
        v11 = &v4[6 * v9 - 4]; /*0x103097fc4*/
        while ( --v10 > 0 ) /*0x103097fc8*/
        {
          v12 = *(_QWORD *)v11; /*0x103097fce*/
          v11 -= 6; /*0x103097fd1*/
          if ( (*(_BYTE *)(v12 + 5) & 2) != 0 ) /*0x103097fd9*/
          {
            v13 = *a1; /*0x103097fdb*/
            v22 = **a1; /*0x103097fe7*/
            v14 = sqlite3DbMallocZero(a1: v22, a2: 128); /*0x103097feb*/
            v2 = 2; /*0x103097ff0*/
            if ( v14 != 0 ) /*0x103097ff9*/
            {
              v15 = v14; /*0x103097ffb*/
              *(_OWORD *)&v21[2] = 0; /*0x103098005*/
              v16 = sqlite3SrcListAppendFromTerm( /*0x10309801d*/
                      a1: (_DWORD)v13,
                      a2: 0,
                      a3: 0,
                      a4: 0,
                      a5: (unsigned int)&v21[2],
                      a6: v14,
                      a7: 0);
              if ( *((_DWORD *)v13 + 14) != 0 ) /*0x103098028*/
              {
                sqlite3SrcListDelete(a1: v22, a2: v16); /*0x103098031*/
              }
              else
              {
                *(_OWORD *)(v15 + 112) = *((_OWORD *)a2 + 7); /*0x10309803f*/
                *(_OWORD *)(v15 + 96) = *((_OWORD *)a2 + 6); /*0x103098048*/
                *(_OWORD *)(v15 + 80) = *((_OWORD *)a2 + 5); /*0x103098051*/
                *(_OWORD *)(v15 + 64) = *((_OWORD *)a2 + 4); /*0x10309805a*/
                v17 = *(_OWORD *)a2; /*0x10309805f*/
                v18 = *((_OWORD *)a2 + 1); /*0x103098062*/
                v19 = *((_OWORD *)a2 + 2); /*0x103098066*/
                *(_OWORD *)(v15 + 48) = *((_OWORD *)a2 + 3); /*0x10309806e*/
                *(_OWORD *)(v15 + 32) = v19; /*0x103098073*/
                *(_OWORD *)(v15 + 16) = v18; /*0x103098078*/
                *(_OWORD *)v15 = v17; /*0x10309807d*/
                *((_QWORD *)a2 + 5) = v16; /*0x103098081*/
                v21[0] = 0; /*0x10309808c*/
                LODWORD(v21[1]) = 0; /*0x10309808f*/
                v20 = sqlite3ExprAlloc(a1: v22, a2: 180, a3: v21, a4: 0); /*0x1030980a1*/
                *((_QWORD *)a2 + 4) = sqlite3ExprListAppendNew(a1: *v13, a2: v20); /*0x1030980b2*/
                *a2 = -117; /*0x1030980b6*/
                *((_QWORD *)a2 + 6) = 0; /*0x1030980b9*/
                *(_QWORD *)(v15 + 72) = 0; /*0x1030980bd*/
                *(_OWORD *)(v15 + 56) = 0; /*0x1030980c4*/
                *((_QWORD *)a2 + 13) = 0; /*0x1030980c9*/
                *((_QWORD *)a2 + 15) = 0; /*0x1030980cd*/
                *v5 = 0; /*0x1030980d1*/
                *((_DWORD *)a2 + 1) = *((_DWORD *)a2 + 1) & 0xFFFEFEFF | 0x10000; /*0x1030980e3*/
                *(_QWORD *)(*(_QWORD *)(v15 + 80) + 88LL) = v15; /*0x1030980ea*/
                *(_QWORD *)(v15 + 96) = 0; /*0x1030980ee*/
                return 0; /*0x1030980f2*/
              }
            }
            return v2; /*0x103098036*/
          }
        }
      }
    }
  }
  return v2; /*0x103097fa8*/
}

// Address: 0x10309a620 | Name: _columnTypeImpl
const char *__fastcall columnTypeImpl(_QWORD *a1, unsigned __int8 *a2)
{
  int v2; // eax
  unsigned int v3; // eax
  __int64 v4; // rcx
  int *v5; // r8
  __int64 v6; // r9
  __int64 v7; // r10
  unsigned __int64 v8; // r9
  __int64 v9; // rdx
  __int64 v10; // rax
  __int64 v11; // rsi
  _DWORD *v13; // rdx
  _QWORD v14[7]; // [rsp+8h] [rbp-38h] BYREF

  v2 = *a2; /*0x10309a628*/
  if ( v2 == 139 ) /*0x10309a630*/
  {
    v10 = *((_QWORD *)a2 + 4); /*0x10309a6a3*/
    v11 = *(_QWORD *)(*(_QWORD *)(v10 + 32) + 8LL); /*0x10309a6af*/
    v14[1] = *(_QWORD *)(v10 + 40); /*0x10309a6b7*/
LABEL_17:
    v14[3] = a1; /*0x10309a6bb*/
    v14[0] = *a1; /*0x10309a6c2*/
    return (const char *)columnTypeImpl(a1: v14, a2: v11); /*0x10309a6cd*/
  }
  if ( v2 != 168 || a1 == nullptr ) /*0x10309a640*/
    return nullptr; /*0x10309a640*/
  v3 = *((__int16 *)a2 + 22); /*0x10309a646*/
  v4 = 0; /*0x10309a64a*/
  do /*0x10309a684*/
  {
    v5 = (int *)a1[1]; /*0x10309a64c*/
    v6 = *v5; /*0x10309a650*/
    if ( v6 <= 0 ) /*0x10309a656*/
    {
LABEL_9:
      a1 = (_QWORD *)a1[3]; /*0x10309a676*/
      v9 = 0; /*0x10309a67a*/
    }
    else
    {
      v7 = 72 * v6; /*0x10309a65f*/
      v8 = 0; /*0x10309a663*/
      while ( v5[v8 / 4 + 9] != *((_DWORD *)a2 + 10) ) /*0x10309a66b*/
      {
        v8 += 72LL; /*0x10309a66d*/
        if ( v7 == v8 ) /*0x10309a674*/
          goto LABEL_9; /*0x10309a674*/
      }
      v9 = *(_QWORD *)&v5[v8 / 4 + 6]; /*0x10309a688*/
      if ( (v5[v8 / 4 + 8] & 0x400) != 0 ) /*0x10309a693*/
        v4 = **(_QWORD **)&v5[v8 / 4 + 18]; /*0x10309a69e*/
      else
        v4 = 0; /*0x10309a695*/
    }
  }
  while ( a1 != nullptr && v9 == 0 ); /*0x10309a684*/
  if ( v9 == 0 ) /*0x10309a6d2*/
    return nullptr; /*0x10309a6d2*/
  if ( v4 != 0 ) /*0x10309a6d7*/
  {
    v13 = *(_DWORD **)(v4 + 32); /*0x10309a6d9*/
    if ( *v13 > (signed int)v3 ) /*0x10309a6df*/
    {
      v11 = *(_QWORD *)&v13[6 * *((__int16 *)a2 + 22) + 2]; /*0x10309a6e7*/
      v14[1] = *(_QWORD *)(v4 + 40); /*0x10309a6f4*/
      goto LABEL_17; /*0x10309a6f8*/
    }
    return nullptr; /*0x10309a701*/
  }
  if ( (v3 & 0x8000u) != 0 ) /*0x10309a705*/
    return "INTEGER"; /*0x10309a71d*/
  else
    return (const char *)sqlite3ColumnType(a1: *(_QWORD *)(v9 + 8) + 16LL * v3, a2: 0); /*0x10309a718*/
}

// Address: 0x10309f40f | Name: _countOfViewOptimization
__int64 __fastcall countOfViewOptimization(_QWORD *a1, __int64 a2)
{
  __int64 result; // rax
  __int64 v4; // rcx
  __int64 v5; // r15
  __int64 v6; // rcx
  __int64 i; // rax
  __int64 v9; // rdi
  __int64 v10; // r8
  __int64 v11; // r13
  __int64 *v12; // rsi
  __int64 v13; // r12
  __int64 v14; // rcx
  __int64 v15; // rdx
  __int64 v16; // r13
  __int64 v17; // rsi
  __int64 v18; // rax
  __int64 v19; // r13
  __int64 v20; // [rsp-48h] [rbp-48h]
  __int64 v21; // [rsp-40h] [rbp-40h]
  __int64 v22; // [rsp-38h] [rbp-38h]

  result = 0; /*0x10309f40f*/
  if ( (*(_BYTE *)(a2 + 4) & 8) == 0 ) /*0x10309f415*/
    return result; /*0x10309f415*/
  v4 = *(_QWORD *)(a2 + 32); /*0x10309f42f*/
  if ( *(_DWORD *)v4 != 1 ) /*0x10309f436*/
    return result; /*0x10309f436*/
  if ( *(_QWORD *)(a2 + 48) != 0 ) /*0x10309f441*/
    return result; /*0x10309f441*/
  if ( *(_QWORD *)(a2 + 64) != 0 ) /*0x10309f44c*/
    return result; /*0x10309f44c*/
  if ( *(_QWORD *)(a2 + 56) != 0 ) /*0x10309f457*/
    return result; /*0x10309f457*/
  if ( *(_QWORD *)(a2 + 72) != 0 ) /*0x10309f462*/
    return result; /*0x10309f462*/
  v5 = *(_QWORD *)(v4 + 8); /*0x10309f468*/
  if ( *(_BYTE *)v5 != 0xA9 ) /*0x10309f470*/
    return result; /*0x10309f470*/
  v6 = *(_QWORD *)(v5 + 8); /*0x10309f476*/
  if ( v6 == 0 ) /*0x10309f47d*/
    return result; /*0x10309f47d*/
  for ( i = 0; ; ++i ) /*0x10309f486*/
  {
    v9 = *(unsigned __int8 *)(v6 + i); /*0x10309f496*/
    v10 = (unsigned __int8)aCount[i]; /*0x10309f49a*/
    if ( (_BYTE)v9 == (_BYTE)v10 ) /*0x10309f4a2*/
      break; /*0x10309f4a2*/
    if ( sqlite3UpperToLower[v9] != sqlite3UpperToLower[v10] ) /*0x10309f4b3*/
      return 0; /*0x10309f67f*/
LABEL_14:
    ; /*0x10309f4b9*/
  }
  if ( *(_BYTE *)(v6 + i) != 0 ) /*0x10309f4a7*/
    goto LABEL_14; /*0x10309f4a7*/
  result = 0; /*0x10309f4be*/
  if ( *(_QWORD *)(v5 + 32) == 0 ) /*0x10309f4c5*/
  {
    v11 = *(_QWORD *)(a2 + 40); /*0x10309f4cb*/
    if ( *(_DWORD *)v11 == 1 && (*(_BYTE *)(v5 + 7) & 1) == 0 && (*(_BYTE *)(v11 + 33) & 4) != 0 ) /*0x10309f4ea*/
    {
      v12 = *(__int64 **)(v11 + 72); /*0x10309f4f0*/
      v13 = *v12; /*0x10309f4f4*/
      if ( *(_QWORD *)(*v12 + 80) != 0 && (*(_BYTE *)(v13 + 7) & 4) == 0 ) /*0x10309f509*/
      {
        v14 = *v12; /*0x10309f50f*/
        while ( (*(_BYTE *)v14 == 0x88 || *(_QWORD *)(v14 + 80) == 0) /*0x10309f53c*/
             && *(_QWORD *)(v14 + 48) == 0
             && *(_QWORD *)(v14 + 96) == 0
             && (*(_BYTE *)(v14 + 4) & 9) == 0 )
        {
          v14 = *(_QWORD *)(v14 + 80); /*0x10309f542*/
          if ( v14 == 0 ) /*0x10309f549*/
          {
            v21 = *a1; /*0x10309f54e*/
            sqlite3DbFreeNN(a1: *a1, a2: v12); /*0x10309f552*/
            *(_QWORD *)(v11 + 72) = 0; /*0x10309f557*/
            *(_BYTE *)(v11 + 33) &= ~4u; /*0x10309f55f*/
            sqlite3SrcListDelete(a1: v21, a2: *(_QWORD *)(a2 + 40)); /*0x10309f56c*/
            *(_QWORD *)(a2 + 40) = sqlite3DbMallocZero(a1: *a1, a2: 80); /*0x10309f57e*/
            if ( v13 != 0 ) /*0x10309f585*/
            {
              v22 = 0; /*0x10309f58b*/
              do /*0x10309f677*/
              {
                v15 = *(_QWORD *)(v13 + 32); /*0x10309f593*/
                v16 = *(_QWORD *)(v13 + 80); /*0x10309f598*/
                *(_OWORD *)(v13 + 80) = 0; /*0x10309f5a0*/
                *(_DWORD *)(v13 + 4) = *(_DWORD *)(v13 + 4) & 0xFFFFFEF7 | 8; /*0x10309f5b5*/
                *(_WORD *)(v13 + 2) = 0; /*0x10309f5ba*/
                sqlite3ParserAddCleanup(a1, a2: sqlite3ExprListDeleteGeneric, a3: v15); /*0x10309f5cc*/
                v17 = v5; /*0x10309f5d1*/
                v20 = v16; /*0x10309f5d4*/
                if ( v16 != 0 ) /*0x10309f5db*/
                  v17 = exprDup(a1: v21, a2: v5, a3: 0, a4: 0); /*0x10309f5ed*/
                *(_QWORD *)(v13 + 32) = sqlite3ExprListAppendNew(a1: *a1, a2: v17); /*0x10309f5f8*/
                v18 = sqlite3DbMallocRawNN(a1: *a1, a2: 72); /*0x10309f605*/
                v19 = v18; /*0x10309f60a*/
                if ( v18 != 0 ) /*0x10309f610*/
                {
                  *(_OWORD *)v18 = 0; /*0x10309f615*/
                  *(_OWORD *)(v18 + 32) = 0; /*0x10309f61a*/
                  *(_OWORD *)(v18 + 48) = 0; /*0x10309f61f*/
                  *(_OWORD *)(v18 + 16) = 0; /*0x10309f624*/
                  *(_QWORD *)(v18 + 64) = 0; /*0x10309f629*/
                  *(_BYTE *)v18 = -117; /*0x10309f631*/
                  *(_WORD *)(v18 + 46) = -1; /*0x10309f636*/
                }
                sqlite3PExprAddSelect(a1, a2: v18, a3: v13); /*0x10309f646*/
                if ( v22 != 0 ) /*0x10309f650*/
                  v19 = sqlite3PExpr(a1, a2: 107, a3: v19, a4: v22); /*0x10309f666*/
                v13 = v20; /*0x10309f66d*/
                v22 = v19; /*0x10309f670*/
              }
              while ( v20 != 0 ); /*0x10309f677*/
            }
            else
            {
              v19 = 0; /*0x10309f690*/
            }
            *(_QWORD *)(*(_QWORD *)(a2 + 32) + 8LL) = v19; /*0x10309f697*/
            *(_BYTE *)(a2 + 4) &= ~8u; /*0x10309f69b*/
            return 1; /*0x10309f69f*/
          }
        }
      }
    }
  }
  return result; /*0x10309f68f*/
}

// Address: 0x10309fcad | Name: _computeLimitRegisters
char __fastcall computeLimitRegisters(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // r12
  __int16 v4; // ax
  unsigned int v7; // ebx
  __int64 Vdbe; // r13
  __int64 v9; // r12
  __int64 v10; // r13
  __int64 v11; // rsi
  unsigned int v12; // r13d
  unsigned int v13; // r12d
  __int64 v15; // [rsp+0h] [rbp-40h]
  __int64 v16; // [rsp+8h] [rbp-38h]
  unsigned int v17; // [rsp+10h] [rbp-30h] BYREF
  unsigned int v18; // [rsp+14h] [rbp-2Ch]

  v3 = *(_QWORD *)(a2 + 96); /*0x10309fcbe*/
  LOBYTE(v4) = *(_DWORD *)(a2 + 8) != 0; /*0x10309fcc6*/
  if ( ((unsigned __int8)v4 | (v3 == 0)) == 0 ) /*0x10309fcd1*/
  {
    v18 = a3; /*0x10309fcdd*/
    v7 = *(_DWORD *)(a1 + 64) + 1; /*0x10309fce3*/
    *(_DWORD *)(a1 + 64) = v7; /*0x10309fce5*/
    *(_DWORD *)(a2 + 8) = v7; /*0x10309fce8*/
    Vdbe = sqlite3GetVdbe(); /*0x10309fcf0*/
    v15 = Vdbe; /*0x10309fd06*/
    if ( (unsigned int)sqlite3ExprIsInteger(a1: *(_QWORD *)(v3 + 16), a2: &v17, a3: a1) != 0 ) /*0x10309fd0a*/
    {
      v16 = v3; /*0x10309fd0c*/
      v9 = Vdbe; /*0x10309fd10*/
      v10 = v17; /*0x10309fd13*/
      LOBYTE(v4) = sqlite3VdbeAddOp3(a1: v9, a2: 72, a3: v17, a4: v7, a5: 0); /*0x10309fd27*/
      if ( v10 != 0 ) /*0x10309fd2f*/
      {
        v3 = v16; /*0x10309fd34*/
        if ( (int)v10 >= 0 ) /*0x10309fd38*/
        {
          LOWORD(v18) = *(_WORD *)(a2 + 2); /*0x10309fd3f*/
          v4 = sqlite3LogEst(a1: v10); /*0x10309fd46*/
          if ( (__int16)v18 > v4 ) /*0x10309fd4f*/
          {
            *(_WORD *)(a2 + 2) = v4; /*0x10309fd51*/
            *(_BYTE *)(a2 + 5) |= 0x40u; /*0x10309fd56*/
          }
        }
      }
      else
      {
        LOBYTE(v4) = sqlite3VdbeAddOp3(a1: v9, a2: 9, a3: 0, a4: v18, a5: 0); /*0x10309fda7*/
        v3 = v16; /*0x10309fdac*/
      }
    }
    else
    {
      sqlite3ExprCode(a1, a2: *(_QWORD *)(v3 + 16), a3: v7); /*0x10309fd67*/
      sqlite3VdbeAddOp3(a1: Vdbe, a2: 13, a3: v7, a4: 0, a5: 0); /*0x10309fd7b*/
      LOBYTE(v4) = sqlite3VdbeAddOp3(a1: Vdbe, a2: 17, a3: v7, a4: v18, a5: 0); /*0x10309fd90*/
    }
    v11 = *(_QWORD *)(v3 + 24); /*0x10309fdb0*/
    if ( v11 != 0 ) /*0x10309fdb8*/
    {
      v12 = *(_DWORD *)(a1 + 64); /*0x10309fdba*/
      v13 = v12 + 1; /*0x10309fdbe*/
      *(_DWORD *)(a2 + 12) = v12 + 1; /*0x10309fdc2*/
      v12 += 2; /*0x10309fdc6*/
      *(_DWORD *)(a1 + 64) = v12; /*0x10309fdca*/
      sqlite3ExprCode(a1, a2: v11, a3: v13); /*0x10309fdd4*/
      sqlite3VdbeAddOp3(a1: v15, a2: 13, a3: v13, a4: 0, a5: 0); /*0x10309fded*/
      LOBYTE(v4) = sqlite3VdbeAddOp3(a1: v15, a2: 161, a3: v7, a4: v12, a5: v13); /*0x10309fe10*/
    }
  }
  return v4; /*0x10309fe02*/
}

// Address: 0x1030a5762 | Name: _compoundHasDifferentAffinities
__int64 __fastcall compoundHasDifferentAffinities(__int64 a1)
{
  int *v1; // r15
  __int64 v2; // rbx
  int *v3; // rax
  __int64 v4; // r13
  char v5; // r14

  v1 = *(int **)(a1 + 32); /*0x1030a5773*/
  if ( *v1 > 0 ) /*0x1030a577b*/
  {
    v2 = a1; /*0x1030a577d*/
    v3 = v1 + 2; /*0x1030a5780*/
    v4 = 0; /*0x1030a5784*/
    do /*0x1030a57d5*/
    {
      v5 = sqlite3ExprAffinity(a1: *(_QWORD *)&v3[6 * v4]); /*0x1030a57a3*/
      while ( 1 ) /*0x1030a57a6*/
      {
        v2 = *(_QWORD *)(v2 + 80); /*0x1030a57a6*/
        if ( v2 == 0 ) /*0x1030a57ad*/
          break; /*0x1030a57ad*/
        if ( (unsigned __int8)sqlite3ExprAffinity(a1: *(_QWORD *)(*(_QWORD *)(v2 + 32) + 24 * v4 + 8)) != v5 ) /*0x1030a57c0*/
          return 1; /*0x1030a57c2*/
      }
      ++v4; /*0x1030a57c4*/
      v2 = a1; /*0x1030a57cd*/
      v3 = v1 + 2; /*0x1030a57d1*/
    }
    while ( v4 < *v1 ); /*0x1030a57d5*/
  }
  return 0; /*0x1030a57e0*/
}

// Address: 0x1030a68a2 | Name: _constInsert
void __fastcall constInsert(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v8; // rax
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rsi
  __int64 v12; // rdi
  __int64 v13; // rdx
  __int64 v14; // rax
  __int64 v15; // rcx

  if ( (*(_BYTE *)(a2 + 4) & 0x20) == 0 && (unsigned __int8)sqlite3ExprAffinity(a1: a3) == 0 ) /*0x1030a68c9*/
  {
    v8 = sqlite3BinaryCompareCollSeq( /*0x1030a68f3*/
           a1: *(_QWORD *)a1,
           a2: *(_QWORD *)(a4 + ((*(_DWORD *)(a4 + 4) & 0x400u) >> 7) + 16),
           a3: *(_QWORD *)(a4 + 8LL * ((*(_DWORD *)(a4 + 4) & 0x400) == 0) + 16));
    if ( v8 == 0 || *(int (__fastcall **)(__int64, int, const void *, int, const void *))(v8 + 24) == binCollFunc ) /*0x1030a6908*/
    {
      v9 = *(int *)(a1 + 16); /*0x1030a690a*/
      if ( v9 <= 0 ) /*0x1030a6911*/
      {
LABEL_11:
        if ( (char)sqlite3ExprAffinity(a1: a2) <= 65 ) /*0x1030a6948*/
          *(_DWORD *)(a1 + 24) = 1; /*0x1030a694a*/
        v13 = *(int *)(a1 + 16) + 1LL; /*0x1030a6956*/
        *(_DWORD *)(a1 + 16) = v13; /*0x1030a6959*/
        v14 = sqlite3DbReallocOrFree(a1: **(_QWORD **)a1, a2: *(_QWORD *)(a1 + 32), a3: 16 * v13); /*0x1030a696b*/
        *(_QWORD *)(a1 + 32) = v14; /*0x1030a6970*/
        if ( v14 != 0 ) /*0x1030a6977*/
        {
          v15 = 16LL * *(int *)(a1 + 16); /*0x1030a697d*/
          *(_QWORD *)(v14 + v15 - 16) = a2; /*0x1030a6981*/
          *(_QWORD *)(*(_QWORD *)(a1 + 32) + v15 - 8) = a3; /*0x1030a698a*/
        }
        else
        {
          *(_DWORD *)(a1 + 16) = 0; /*0x1030a6994*/
        }
      }
      else
      {
        v10 = 16 * v9; /*0x1030a691b*/
        v11 = 0; /*0x1030a691f*/
        while ( 1 ) /*0x1030a6921*/
        {
          v12 = *(_QWORD *)(*(_QWORD *)(a1 + 32) + v11); /*0x1030a6921*/
          if ( *(_DWORD *)(v12 + 40) == *(_DWORD *)(a2 + 40) && *(_WORD *)(v12 + 44) == *(_WORD *)(a2 + 44) ) /*0x1030a6933*/
            break; /*0x1030a6933*/
          v11 += 16; /*0x1030a6935*/
          if ( v10 == v11 ) /*0x1030a693c*/
            goto LABEL_11; /*0x1030a693c*/
        }
      }
    }
  }
}

// Address: 0x1030a82d0 | Name: _constructAutomaticIndex
__int64 __fastcall constructAutomaticIndex(_QWORD *a1, __int64 a2, __int64 a3, __int64 a4)
{
  _QWORD *v6; // r12
  unsigned int v7; // r14d
  unsigned __int64 v8; // r15
  __int64 v9; // rax
  __int64 v10; // rax
  signed int v11; // r13d
  __int64 v12; // rbx
  __int64 v13; // r14
  __int64 v14; // rdx
  __int64 v15; // r14
  __int64 v16; // rcx
  __int64 v17; // r12
  __int64 v18; // rax
  __int64 result; // rax
  __int64 v20; // rax
  __int64 v21; // rbx
  __int64 v22; // r13
  int v23; // eax
  unsigned int v24; // edx
  _BYTE *v25; // rsi
  unsigned __int64 v26; // rcx
  __int64 v27; // r10
  __int64 v28; // r9
  __int64 v29; // rcx
  __int64 v30; // rsi
  __int64 v31; // rcx
  __m128i v32; // xmm1
  __m128i v33; // xmm2
  __m128i v34; // xmm0
  __m128i v35; // xmm6
  __m128i v36; // xmm7
  __m128i v37; // xmm8
  __m128i v38; // xmm11
  __m128 v39; // xmm3
  __m128i v40; // xmm5
  __m128i v41; // xmm4
  __m128i si128; // xmm6
  __m128i v43; // xmm2
  __m128i v44; // xmm4
  __m128 v45; // xmm0
  __m128i v46; // xmm5
  __m128 v47; // xmm6
  __m128i v48; // xmm1
  __m128i v49; // xmm1
  __int64 v50; // rdi
  __int64 v51; // r15
  unsigned __int64 v52; // rbx
  bool v53; // r13
  __int64 v54; // r14
  __int64 v55; // r13
  int v56; // ecx
  __int64 v57; // r12
  __int64 v58; // r12
  __int64 v59; // r14
  const char **v60; // rax
  const char *v61; // rcx
  __int64 v62; // rdi
  bool v63; // zf
  int v64; // ecx
  __int64 v65; // rax
  unsigned __int64 v66; // rcx
  __int64 v67; // rdi
  __int64 v68; // rbx
  __int64 v69; // r8
  int v70; // eax
  __int64 v71; // rdx
  __int64 v72; // rcx
  __int64 v73; // rdx
  __int64 v74; // rcx
  __int64 v75; // rax
  __int64 v76; // r14
  unsigned int v77; // ebx
  _QWORD *v78; // r13
  int v79; // r12d
  __int64 v80; // rsi
  unsigned int v81; // ebx
  char v82; // al
  unsigned __int8 v83; // al
  _QWORD *v84; // rdi
  unsigned int v85; // r12d
  __int64 v86; // r13
  unsigned int IndexKey; // r14d
  __int64 v88; // rdx
  _QWORD *v89; // r13
  __int64 v90; // rax
  __int64 v91; // r13
  unsigned int v92; // r13d
  _QWORD *v93; // r15
  _DWORD *v94; // rbx
  int v95; // r14d
  _DWORD *v96; // rax
  __int64 v97; // r14
  unsigned __int64 v98; // rcx
  _QWORD *v99; // rdx
  _DWORD *v100; // rcx
  char v101[8]; // [rsp+8h] [rbp-B8h] BYREF
  __int64 v102; // [rsp+10h] [rbp-B0h]
  __int64 v103; // [rsp+18h] [rbp-A8h]
  __int64 v104; // [rsp+20h] [rbp-A0h]
  int v105; // [rsp+2Ch] [rbp-94h]
  __int64 v106; // [rsp+30h] [rbp-90h]
  __int64 v107; // [rsp+38h] [rbp-88h]
  unsigned __int64 v108; // [rsp+40h] [rbp-80h]
  int v109; // [rsp+4Ch] [rbp-74h]
  __m128i v110; // [rsp+50h] [rbp-70h] BYREF
  __int64 v111; // [rsp+60h] [rbp-60h]
  __int64 v112; // [rsp+68h] [rbp-58h]
  _QWORD *v113; // [rsp+70h] [rbp-50h]
  __int64 v114; // [rsp+78h] [rbp-48h]
  __int64 v115; // [rsp+80h] [rbp-40h]
  __int64 v116; // [rsp+88h] [rbp-38h]
  _QWORD *v117; // [rsp+90h] [rbp-30h]

  v107 = a3; /*0x1030a82e7*/
  v6 = a1; /*0x1030a82f1*/
  v7 = 0; /*0x1030a82f8*/
  v113 = (_QWORD *)a1[2]; /*0x1030a82fb*/
  v105 = sqlite3VdbeAddOp3(a1: v113, a2: 15, a3: 0, a4: 0, a5: 0); /*0x1030a8310*/
  v8 = *(_QWORD *)(a2 + 32); /*0x1030a831a*/
  v9 = 9LL * *(unsigned __int8 *)(a4 + 64); /*0x1030a8326*/
  v110.i64[0] = *(_QWORD *)(*(_QWORD *)a2 + 8LL); /*0x1030a832a*/
  v116 = v110.i64[0] + 8 * v9 + 8; /*0x1030a8333*/
  v112 = *(_QWORD *)(v110.i64[0] + 8 * v9 + 24); /*0x1030a833b*/
  v102 = a2; /*0x1030a833f*/
  v10 = *(int *)(a2 + 20); /*0x1030a8346*/
  v108 = v8 + 56 * v10; /*0x1030a8351*/
  v111 = a4; /*0x1030a8355*/
  v106 = *(_QWORD *)(a4 + 96); /*0x1030a835d*/
  v117 = v6; /*0x1030a8367*/
  if ( v10 > 0 ) /*0x1030a836b*/
  {
    v11 = 0; /*0x1030a8371*/
    v114 = 0; /*0x1030a8374*/
    v110.i64[1] = 0; /*0x1030a837c*/
    v115 = 0; /*0x1030a8384*/
    v12 = v112; /*0x1030a838c*/
    while ( 1 ) /*0x1030a8390*/
    {
      if ( (*(_BYTE *)(v8 + 18) & 2) != 0 /*0x1030a83b2*/
        || (v13 = *(_QWORD *)v8,
            (unsigned int)sqlite3ExprIsSingleTableConstraint(
                            a1: *(_QWORD *)v8,
                            a2: v110.i64[0],
                            a3: *(unsigned __int8 *)(v111 + 64),
                            a4: 0) == 0) )
      {
        v15 = v116; /*0x1030a83ce*/
      }
      else
      {
        if ( v13 != 0 ) /*0x1030a83b7*/
          v14 = exprDup(a1: *v6, a2: v13, a3: 0, a4: 0); /*0x1030a83c9*/
        else
          v14 = 0; /*0x1030a83d4*/
        v15 = v116; /*0x1030a83d6*/
        v115 = sqlite3ExprAnd(a1: v6, a2: v115, a3: v14); /*0x1030a83e6*/
      }
      if ( (unsigned int)termCanDriveIndex(a1: v8, a2: v15, a3: v107) != 0 ) /*0x1030a83fe*/
      {
        v16 = *(int *)(v8 + 32); /*0x1030a8400*/
        v17 = 1LL << v16; /*0x1030a840a*/
        v18 = 0x8000000000000000LL; /*0x1030a8411*/
        if ( v16 >= 64 ) /*0x1030a841b*/
          v17 = 0x8000000000000000LL; /*0x1030a841b*/
        if ( v110.i8[8] == 0 ) /*0x1030a8423*/
          sqlite3_log( /*0x1030a8442*/
            iErrCode: 284,
            zFormat: "automatic index on %s(%s)",
            *(const char **)v12,
            *(const char **)(*(_QWORD *)(v12 + 8) + 16 * v16));
        LOBYTE(v18) = 1; /*0x1030a8447*/
        v110.i64[1] = v18; /*0x1030a8449*/
        if ( (v17 & v114) != 0 ) /*0x1030a8451*/
        {
          v7 = v11; /*0x1030a8453*/
          v6 = v117; /*0x1030a8456*/
        }
        else
        {
          v7 = v11 + 1; /*0x1030a8468*/
          result = whereLoopResize(a1: *v117, a2: v106, a3: (unsigned int)(v11 + 1)); /*0x1030a8479*/
          if ( (_DWORD)result != 0 ) /*0x1030a8480*/
          {
            v6 = v117; /*0x1030a8584*/
            v22 = v115; /*0x1030a8588*/
            goto LABEL_111; /*0x1030a858c*/
          }
          *(_QWORD *)(*(_QWORD *)(v106 + 64) + 8LL * v11) = v8; /*0x1030a848d*/
          v114 |= v17; /*0x1030a8491*/
          v6 = v117; /*0x1030a8495*/
          v12 = v112; /*0x1030a8499*/
        }
      }
      else
      {
        v7 = v11; /*0x1030a845c*/
      }
      v8 += 56LL; /*0x1030a849d*/
      v11 = v7; /*0x1030a84a1*/
      if ( v8 >= v108 ) /*0x1030a84a8*/
        goto LABEL_23; /*0x1030a84a8*/
    }
  }
  v115 = 0; /*0x1030a84b0*/
  v114 = 0; /*0x1030a84b8*/
  v12 = v112; /*0x1030a84c0*/
LABEL_23:
  v20 = v12; /*0x1030a84c4*/
  v21 = v106; /*0x1030a84c7*/
  *(_WORD *)(v106 + 52) = v7; /*0x1030a84ce*/
  *(_WORD *)(v21 + 24) = v7; /*0x1030a84d3*/
  *(_DWORD *)(v21 + 48) = 16961; /*0x1030a84d8*/
  if ( *(_BYTE *)(v20 + 63) == 2 ) /*0x1030a84e3*/
    v110.i64[0] = ~v114; /*0x1030a84ec*/
  else
    v110.i64[0] = *(_QWORD *)(v116 + 32) & (~v114 | 0x8000000000000000LL); /*0x1030a850e*/
  v22 = v115; /*0x1030a8512*/
  v23 = *(_DWORD *)(v112 + 48); /*0x1030a851a*/
  v24 = *(__int16 *)(v112 + 54); /*0x1030a851d*/
  if ( (v23 & 0x80u) == 0 ) /*0x1030a8523*/
  {
LABEL_39:
    v29 = 63; /*0x1030a859f*/
    if ( (__int16)v24 < 63 ) /*0x1030a85a8*/
      v29 = v24; /*0x1030a85a8*/
    v104 = v29; /*0x1030a85ae*/
    if ( (__int16)v24 <= 0 ) /*0x1030a85b5*/
    {
      v109 = 0; /*0x1030a86f1*/
    }
    else
    {
      v30 = (unsigned int)v29; /*0x1030a85bb*/
      v31 = ((_BYTE)v29 + 3) & 0x7C; /*0x1030a85c0*/
      v32 = _mm_cvtsi32_si128(v7); /*0x1030a85c6*/
      v33 = _mm_shuffle_epi32((__m128i)(unsigned __int64)(v30 - 1), 68); /*0x1030a85d0*/
      v34 = _mm_shuffle_epi32(_mm_loadl_epi64(&v110), 68); /*0x1030a85da*/
      v35 = _mm_cvtepi8_epi64(770); /*0x1030a85df*/
      v36 = _mm_cvtepi8_epi64(256); /*0x1030a85e8*/
      v37 = _mm_cvtepi8_epi64(257); /*0x1030a85f1*/
      v38 = _mm_cvtepi8_epi64(1028); /*0x1030a8605*/
      do /*0x1030a868e*/
      {
        v39 = (__m128)v32; /*0x1030a860f*/
        v40 = v35; /*0x1030a8613*/
        v41 = v36; /*0x1030a8617*/
        v32 = _mm_sub_epi32( /*0x1030a867b*/
                _mm_add_epi32(
                  _mm_packs_epi32(
                    _mm_cmpeq_epi64(
                      _mm_and_si128(
                        _mm_blend_epi16(_mm_sll_epi64(v37, _mm_shuffle_epi32(v36, 238)), _mm_sll_epi64(v37, v36), 15),
                        v34),
                      (__m128i)0LL),
                    _mm_cmpeq_epi64(
                      _mm_and_si128(
                        _mm_blend_epi16(_mm_sll_epi64(v37, _mm_shuffle_epi32(v35, 238)), _mm_sll_epi64(v37, v35), 15),
                        v34),
                      (__m128i)0LL)),
                  v32),
                (__m128i)-1LL);
        v36 = _mm_add_epi64(v36, v38); /*0x1030a8680*/
        v35 = _mm_add_epi64(v35, v38); /*0x1030a8685*/
        v31 -= 4; /*0x1030a868a*/
      }
      while ( v31 != 0 ); /*0x1030a868e*/
      si128 = _mm_load_si128((const __m128i *)&xmmword_108F246C0); /*0x1030a8694*/
      v43 = _mm_xor_si128(v33, si128); /*0x1030a869c*/
      v44 = _mm_xor_si128(v41, si128); /*0x1030a86a0*/
      v45 = (__m128)_mm_cmpgt_epi32(v44, v43); /*0x1030a86a8*/
      v46 = _mm_xor_si128(v40, si128); /*0x1030a86ac*/
      v47 = (__m128)_mm_cmpgt_epi32(v46, v43); /*0x1030a86b4*/
      v48 = (__m128i)_mm_blendv_ps( /*0x1030a86d6*/
                       (__m128)v32,
                       v39,
                       _mm_or_ps(
                         _mm_shuffle_ps(v45, v47, 221),
                         _mm_and_ps(
                           _mm_shuffle_ps((__m128)_mm_cmpeq_epi32(v44, v43), (__m128)_mm_cmpeq_epi32(v46, v43), 221),
                           _mm_shuffle_ps(v45, v47, 136))));
      v49 = _mm_hadd_epi32(v48, v48); /*0x1030a86db*/
      v7 = _mm_cvtsi128_si32(_mm_hadd_epi32(v49, v49)); /*0x1030a86e5*/
      v109 = 1; /*0x1030a86ec*/
    }
  }
  else
  {
    if ( (__int16)v24 > 0 ) /*0x1030a8528*/
    {
      v25 = (_BYTE *)(*(_QWORD *)(v112 + 8) + 14LL); /*0x1030a8534*/
      v26 = 0; /*0x1030a853b*/
      v27 = v114; /*0x1030a853d*/
      while ( 1 ) /*0x1030a8541*/
      {
        if ( (*v25 & 1) != 0 ) /*0x1030a8544*/
        {
          if ( v26 >= 0x3F ) /*0x1030a854a*/
          {
            v110.i64[0] |= 0x8000000000000000LL; /*0x1030a859b*/
            goto LABEL_39; /*0x1030a859b*/
          }
          v28 = 1LL << v26; /*0x1030a8552*/
          if ( _bittest64(&v27, v26) ) /*0x1030a8555*/
            v28 = 0; /*0x1030a8559*/
          v110.i64[0] |= v28; /*0x1030a855d*/
        }
        ++v26; /*0x1030a8561*/
        v25 += 16; /*0x1030a8564*/
        if ( v24 == v26 ) /*0x1030a856b*/
          goto LABEL_39; /*0x1030a856b*/
      }
    }
    v109 = 0; /*0x1030a856f*/
    v104 = v24; /*0x1030a8578*/
  }
  v50 = *v6; /*0x1030a870c*/
  v103 = v7 + ((v24 - 63) & (unsigned int)(*(__int64 *)(v116 + 32) >> 63)); /*0x1030a8718*/
  LODWORD(v51) = 0; /*0x1030a8721*/
  result = sqlite3AllocateIndexObject(a1: v50, a2: (unsigned int)v103 + ((v23 & 0x80u) == 0), a3: 0, a4: v101); /*0x1030a872d*/
  if ( result != 0 ) /*0x1030a8735*/
  {
    *(_QWORD *)(v21 + 32) = result; /*0x1030a873e*/
    *(_QWORD *)result = "auto-index"; /*0x1030a8749*/
    v110.i64[1] = result; /*0x1030a8750*/
    *(_QWORD *)(result + 24) = v112; /*0x1030a8754*/
    v52 = *(_QWORD *)(v102 + 32); /*0x1030a875f*/
    v53 = false; /*0x1030a8763*/
    v54 = v116; /*0x1030a876d*/
    if ( v52 < v108 ) /*0x1030a8771*/
    {
      LODWORD(v51) = 0; /*0x1030a8777*/
      v55 = 0; /*0x1030a877a*/
      LODWORD(v114) = 0; /*0x1030a877d*/
      do /*0x1030a884b*/
      {
        if ( (unsigned int)termCanDriveIndex(a1: v52, a2: v54, a3: v107) == 0 ) /*0x1030a8798*/
          goto LABEL_53; /*0x1030a8798*/
        v56 = *(_DWORD *)(v52 + 32); /*0x1030a879a*/
        v57 = 1LL << v56; /*0x1030a87a3*/
        if ( v56 >= 64 ) /*0x1030a87b3*/
          v57 = 0x8000000000000000LL; /*0x1030a87b3*/
        if ( (v55 & v57) == 0 ) /*0x1030a87ba*/
        {
          v59 = *(_QWORD *)v52; /*0x1030a87c1*/
          *(_WORD *)(*(_QWORD *)(v110.i64[1] + 8) + 2LL * (int)v51) = v56; /*0x1030a87cf*/
          v60 = (const char **)sqlite3BinaryCompareCollSeq( /*0x1030a87f5*/
                                 a1: v117,
                                 a2: *(_QWORD *)(v59 + ((*(_DWORD *)(v59 + 4) & 0x400u) >> 7) + 16),
                                 a3: *(_QWORD *)(v59 + 8LL * ((*(_DWORD *)(v59 + 4) & 0x400) == 0) + 16));
          v61 = "BINARY"; /*0x1030a87fa*/
          if ( v60 != nullptr ) /*0x1030a8804*/
            v61 = *v60; /*0x1030a8806*/
          v58 = v55 | v57; /*0x1030a8809*/
          *(_QWORD *)(*(_QWORD *)(v110.i64[1] + 64) + 8LL * (int)v51) = v61; /*0x1030a8814*/
          LODWORD(v51) = v51 + 1; /*0x1030a8818*/
          v62 = *(_QWORD *)(v59 + 16); /*0x1030a881b*/
          if ( v62 != 0 ) /*0x1030a8822*/
          {
            v63 = (unsigned __int8)sqlite3ExprAffinity(a1: v62) == 66; /*0x1030a8829*/
            v64 = (unsigned __int8)v114; /*0x1030a882e*/
            if ( !v63 ) /*0x1030a8836*/
              v64 = 1; /*0x1030a8836*/
            LODWORD(v114) = v64; /*0x1030a8839*/
          }
          v54 = v116; /*0x1030a883c*/
        }
        else
        {
LABEL_53:
          v58 = v55; /*0x1030a87bc*/
        }
        v52 += 56LL; /*0x1030a8840*/
        v55 = v58; /*0x1030a8844*/
      }
      while ( v52 < v108 ); /*0x1030a884b*/
      v53 = (_BYTE)v114 != 0; /*0x1030a8855*/
      v6 = v117; /*0x1030a8859*/
    }
    if ( (_BYTE)v109 != 0 ) /*0x1030a8861*/
    {
      v65 = (unsigned int)v104; /*0x1030a8863*/
      v66 = 0; /*0x1030a8869*/
      v67 = v112; /*0x1030a8872*/
      v68 = v110.i64[1]; /*0x1030a887a*/
      v69 = v110.i64[0]; /*0x1030a887a*/
      do /*0x1030a88a1*/
      {
        if ( _bittest64(&v69, v66) ) /*0x1030a887e*/
        {
          *(_WORD *)(*(_QWORD *)(v68 + 8) + 2LL * (int)v51) = v66; /*0x1030a888b*/
          *(_QWORD *)(*(_QWORD *)(v68 + 64) + 8LL * (int)v51) = "BINARY"; /*0x1030a8894*/
          LODWORD(v51) = v51 + 1; /*0x1030a8898*/
        }
        ++v66; /*0x1030a889b*/
      }
      while ( v65 != v66 ); /*0x1030a88a1*/
    }
    else
    {
      v67 = v112; /*0x1030a88a5*/
      v68 = v110.i64[1]; /*0x1030a88a9*/
    }
    if ( *(__int64 *)(v54 + 32) < 0 && *(__int16 *)(v67 + 54) >= 64 ) /*0x1030a88b9*/
    {
      v51 = (int)v51; /*0x1030a88bb*/
      v70 = 63; /*0x1030a88be*/
      do /*0x1030a88e6*/
      {
        *(_WORD *)(*(_QWORD *)(v68 + 8) + 2 * v51) = v70; /*0x1030a88ce*/
        *(_QWORD *)(*(_QWORD *)(v68 + 64) + 8 * v51++) = "BINARY"; /*0x1030a88d7*/
        ++v70; /*0x1030a88de*/
      }
      while ( v70 < *(__int16 *)(v67 + 54) ); /*0x1030a88e6*/
    }
    if ( *(char *)(v67 + 48) >= 0 ) /*0x1030a88ec*/
    {
      *(_WORD *)(*(_QWORD *)(v68 + 8) + 2LL * (int)v51) = -1; /*0x1030a88f5*/
      *(_QWORD *)(*(_QWORD *)(v68 + 64) + 8LL * (int)v51) = "BINARY"; /*0x1030a8906*/
    }
    v71 = *((unsigned int *)v6 + 15); /*0x1030a890a*/
    *((_DWORD *)v6 + 15) = v71 + 1; /*0x1030a8912*/
    *(_DWORD *)(v111 + 8) = v71; /*0x1030a891b*/
    sqlite3VdbeAddOp3(a1: v113, a2: 117, a3: v71, a4: (unsigned int)(v103 + 1), a5: 0); /*0x1030a8933*/
    sqlite3VdbeSetP4KeyInfo(a1: v6, a2: v68); /*0x1030a893e*/
    if ( v53 && (*(_BYTE *)(*v6 + 98LL) & 8) == 0 ) /*0x1030a894b*/
    {
      v72 = (unsigned int)(*((_DWORD *)v6 + 16) + 1); /*0x1030a895a*/
      *((_DWORD *)v6 + 16) = v72; /*0x1030a895c*/
      *(_DWORD *)(v111 + 48) = v72; /*0x1030a8965*/
      sqlite3VdbeAddOp3(a1: v113, a2: 78, a3: 10000, a4: v72, a5: 0); /*0x1030a8979*/
    }
    if ( (*(_BYTE *)(v54 + 25) & 0x40) != 0 ) /*0x1030a8983*/
    {
      v76 = *(_QWORD *)(v54 + 64); /*0x1030a89ad*/
      v77 = *(_DWORD *)(v76 + 12); /*0x1030a89b1*/
      v78 = v113; /*0x1030a89b5*/
      v79 = sqlite3VdbeAddOp3(a1: v113, a2: 72, a3: 0, a4: 0, a5: 0); /*0x1030a89cd*/
      sqlite3VdbeAddOp3(a1: v78, a2: 11, a3: v77, a4: 0, a5: *(unsigned int *)(v76 + 8)); /*0x1030a89e0*/
      v75 = sqlite3VdbeAddOp3(a1: v78, a2: 12, a3: v77, a4: 0, a5: 0); /*0x1030a89f4*/
      v107 = v79; /*0x1030a89fc*/
      v6 = v117; /*0x1030a8a03*/
    }
    else
    {
      v73 = *(unsigned int *)(v111 + 4); /*0x1030a8989*/
      v74 = *(unsigned int *)(v111 + 16); /*0x1030a898c*/
      v107 = 0; /*0x1030a898f*/
      v75 = sqlite3VdbeAddOp3(a1: v113, a2: 36, a3: v73, a4: v74, a5: 0); /*0x1030a89a6*/
    }
    v80 = v115; /*0x1030a8a07*/
    v108 = v75; /*0x1030a8a0b*/
    if ( v115 != 0 ) /*0x1030a8a12*/
    {
      v81 = *((_DWORD *)v6 + 19) - 1; /*0x1030a8a19*/
      *((_DWORD *)v6 + 19) = v81; /*0x1030a8a1b*/
      sqlite3ExprIfFalse(a1: v6, a2: v80, a3: v81, a4: 16); /*0x1030a8a2a*/
      *(_BYTE *)(v106 + 50) |= 2u; /*0x1030a8a36*/
    }
    else
    {
      v81 = 0; /*0x1030a8a3c*/
    }
    v82 = *((_BYTE *)v6 + 31); /*0x1030a8a3e*/
    if ( v82 != 0 ) /*0x1030a8a45*/
    {
      v83 = v82 - 1; /*0x1030a8a47*/
      *((_BYTE *)v6 + 31) = v83; /*0x1030a8a49*/
      LODWORD(v84) = (_DWORD)v6; /*0x1030a8a51*/
      v85 = *((_DWORD *)v6 + v83 + 44); /*0x1030a8a54*/
    }
    else
    {
      v84 = v6; /*0x1030a8a5e*/
      v85 = *((_DWORD *)v6 + 16) + 1; /*0x1030a8a66*/
      *((_DWORD *)v84 + 16) = v85; /*0x1030a8a69*/
    }
    v86 = v111; /*0x1030a8a6d*/
    IndexKey = sqlite3GenerateIndexKey( /*0x1030a8a8f*/
                 a1: (_DWORD)v84,
                 a2: v110.i32[2],
                 a3: *(_DWORD *)(v111 + 4),
                 a4: v85,
                 a5: 0,
                 a6: 0,
                 a7: 0,
                 a8: 0);
    v88 = *(unsigned int *)(v86 + 48); /*0x1030a8a92*/
    v89 = v113; /*0x1030a8a98*/
    if ( (_DWORD)v88 != 0 ) /*0x1030a8a9c*/
      sqlite3VdbeAddOp4Int(a1: v113, a2: 184, a3: v88, a4: 0, a5: IndexKey, a6: *(unsigned __int16 *)(v106 + 24)); /*0x1030a8ab7*/
    sqlite3VdbeAddOp3(a1: v89, a2: 139, a3: *(unsigned int *)(v111 + 8), a4: v85, a5: 0); /*0x1030a8ad1*/
    v90 = *((int *)v89 + 36); /*0x1030a8ad6*/
    if ( v90 > 0 ) /*0x1030a8ae0*/
      *(_WORD *)(v89[17] + 24 * v90 - 22) = 16; /*0x1030a8aed*/
    v91 = v115; /*0x1030a8af4*/
    if ( v115 != 0 ) /*0x1030a8afb*/
      sqlite3VdbeResolveLabel(a1: v113, a2: v81); /*0x1030a8b03*/
    v63 = (*(_BYTE *)(v116 + 25) & 0x40) == 0; /*0x1030a8b0c*/
    v115 = v91; /*0x1030a8b10*/
    if ( v63 ) /*0x1030a8b14*/
    {
      v92 = v108; /*0x1030a8b1d*/
      v93 = v113; /*0x1030a8b25*/
      sqlite3VdbeAddOp3(a1: v113, a2: 40, a3: *(unsigned int *)(v111 + 4), a4: (unsigned int)(v108 + 1), a5: 0); /*0x1030a8b34*/
      result = *((int *)v93 + 36); /*0x1030a8b39*/
      if ( result > 0 ) /*0x1030a8b43*/
        *(_WORD *)(v93[17] + 24 * result - 22) = 3; /*0x1030a8b50*/
      if ( (*(_BYTE *)(v116 + 24) & 8) == 0 ) /*0x1030a8b5f*/
        goto LABEL_104; /*0x1030a8b5f*/
      if ( *(_BYTE *)(*v93 + 103LL) != 0 ) /*0x1030a8b6c*/
      {
        v94 = &sqlite3VdbeGetOp_dummy; /*0x1030a8b72*/
LABEL_103:
        v94[2] = result; /*0x1030a8c14*/
LABEL_104:
        v22 = v115; /*0x1030a8c17*/
        if ( v85 != 0 ) /*0x1030a8c1e*/
        {
          v98 = *((unsigned __int8 *)v117 + 31); /*0x1030a8c24*/
          if ( v98 <= 7 ) /*0x1030a8c2c*/
          {
            v99 = v117; /*0x1030a8c31*/
            *((_BYTE *)v117 + 31) = v98 + 1; /*0x1030a8c35*/
            *((_DWORD *)v99 + v98 + 44) = v85; /*0x1030a8c38*/
            result = *((unsigned int *)v93 + 36); /*0x1030a8c40*/
          }
        }
        if ( *(_BYTE *)(*v93 + 103LL) != 0 ) /*0x1030a8c4e*/
          v100 = &sqlite3VdbeGetOp_dummy; /*0x1030a8c50*/
        else
          v100 = (_DWORD *)(v93[17] + 24LL * v105); /*0x1030a8c68*/
        v6 = v117; /*0x1030a8c6f*/
        v100[2] = result; /*0x1030a8c73*/
        goto LABEL_111; /*0x1030a8c73*/
      }
    }
    else
    {
      v95 = v51 + IndexKey; /*0x1030a8b7e*/
      v93 = v113; /*0x1030a8b81*/
      v94 = &sqlite3VdbeGetOp_dummy; /*0x1030a8b88*/
      v96 = &sqlite3VdbeGetOp_dummy; /*0x1030a8b93*/
      if ( *(_BYTE *)(*v113 + 103LL) == 0 ) /*0x1030a8b96*/
        v96 = (_DWORD *)(v113[17] + 24 * v107); /*0x1030a8ba7*/
      v96[2] = v95; /*0x1030a8bae*/
      v97 = v116; /*0x1030a8bb2*/
      v92 = v108; /*0x1030a8bcc*/
      translateColumnToCopy( /*0x1030a8bd3*/
        a1: v117,
        a2: (unsigned int)v108,
        a3: *(unsigned int *)(v111 + 4),
        a4: *(unsigned int *)(*(_QWORD *)(v116 + 64) + 16LL),
        a5: *(unsigned int *)(v111 + 8));
      sqlite3VdbeAddOp3(a1: v93, a2: 9, a3: 0, a4: v92, a5: 0); /*0x1030a8be8*/
      *(_BYTE *)(v97 + 25) &= ~0x40u; /*0x1030a8bed*/
      result = *((unsigned int *)v93 + 36); /*0x1030a8bf2*/
      if ( *(_BYTE *)(*v93 + 103LL) != 0 ) /*0x1030a8c00*/
        goto LABEL_103; /*0x1030a8c00*/
    }
    v94 = (_DWORD *)(v93[17] + 24LL * (int)v92); /*0x1030a8c0d*/
    goto LABEL_103; /*0x1030a8c0d*/
  }
LABEL_111:
  if ( v22 != 0 ) /*0x1030a8c79*/
    return sqlite3ExprDeleteNN(a1: *v6); /*0x1030a8c93*/
  return result; /*0x1030a8c82*/
}

// Address: 0x1030b148d | Name: _columnIsGoodIndexCandidate
__int64 __fastcall columnIsGoodIndexCandidate(__int64 a1, int a2)
{
  __int64 v2; // rcx
  __int64 v3; // rdx
  __int64 result; // rax

  v2 = *(_QWORD *)(a1 + 16); /*0x1030b148d*/
  if ( v2 == 0 ) /*0x1030b1494*/
    return 1; /*0x1030b14e6*/
  while ( 1 ) /*0x1030b149a*/
  {
    if ( *(_WORD *)(v2 + 94) != 0 ) /*0x1030b14a1*/
    {
      v3 = 0; /*0x1030b14a7*/
      while ( *(__int16 *)(*(_QWORD *)(v2 + 8) + 2 * v3) != a2 ) /*0x1030b14b1*/
      {
        if ( *(unsigned __int16 *)(v2 + 94) == ++v3 ) /*0x1030b14b9*/
          goto LABEL_10; /*0x1030b14b9*/
      }
      result = 0; /*0x1030b14bd*/
      if ( v3 == 0 || *(char *)(v2 + 99) < 0 && *(__int16 *)(*(_QWORD *)(v2 + 16) + 2 * v3 + 2) > 20 ) /*0x1030b14d4*/
        return result; /*0x1030b14e5*/
    }
LABEL_10:
    v2 = *(_QWORD *)(v2 + 40); /*0x1030b14d6*/
    if ( v2 == 0 ) /*0x1030b14dd*/
      return 1; /*0x1030b14df*/
  }
}

// Address: 0x1030b21dc | Name: _computeIndexAffStr
__int64 __fastcall computeIndexAffStr(__int64 a1, __int64 a2)
{
  __int64 v4; // r15
  __int64 v5; // rax
  __int64 v6; // r12
  unsigned __int64 v7; // r14
  __int64 v8; // rax
  char v9; // al

  v4 = *(_QWORD *)(a2 + 24); /*0x1030b21ed*/
  v5 = sqlite3Malloc(a1: *(unsigned __int16 *)(a2 + 96) + 1LL); /*0x1030b21f8*/
  *(_QWORD *)(a2 + 32) = v5; /*0x1030b21fd*/
  if ( v5 != 0 ) /*0x1030b2204*/
  {
    if ( *(_WORD *)(a2 + 96) != 0 ) /*0x1030b220b*/
    {
      v6 = 4; /*0x1030b220d*/
      v7 = 0; /*0x1030b2213*/
      do /*0x1030b2276*/
      {
        v8 = *(__int16 *)(*(_QWORD *)(a2 + 8) + 2 * v7); /*0x1030b221a*/
        if ( v8 < 0 ) /*0x1030b2222*/
        {
          if ( (_WORD)v8 == 0xFFFF ) /*0x1030b2236*/
            v9 = 68; /*0x1030b2247*/
          else
            v9 = sqlite3ExprAffinity(a1: *(_QWORD *)(*(_QWORD *)(a2 + 80) + 2 * v6)); /*0x1030b2240*/
        }
        else
        {
          v9 = *(_BYTE *)(*(_QWORD *)(v4 + 8) + 16 * v8 + 9); /*0x1030b222c*/
        }
        if ( v9 < 66 ) /*0x1030b224b*/
          v9 = 65; /*0x1030b224d*/
        if ( v9 >= 67 ) /*0x1030b2259*/
          v9 = 67; /*0x1030b225b*/
        *(_BYTE *)(*(_QWORD *)(a2 + 32) + v7++) = v9; /*0x1030b2264*/
        v6 += 12; /*0x1030b226f*/
      }
      while ( v7 < *(unsigned __int16 *)(a2 + 96) ); /*0x1030b2276*/
      v5 = *(_QWORD *)(a2 + 32); /*0x1030b2278*/
    }
    else
    {
      v7 = 0; /*0x1030b228a*/
    }
    *(_BYTE *)(v5 + v7) = 0; /*0x1030b228d*/
    return *(_QWORD *)(a2 + 32); /*0x1030b2292*/
  }
  else
  {
    sqlite3OomFault(a1); /*0x1030b2281*/
    return 0; /*0x1030b2286*/
  }
}

// Address: 0x1030b2334 | Name: _codeEqualityTerm
__int64 __fastcall codeEqualityTerm(__int64 a1, _BYTE *a2, __int64 a3, __int64 a4, __int64 a5, unsigned int a6)
{
  __int64 v6; // rax
  unsigned int v7; // ebx
  int v10; // edx

  v7 = a6; /*0x1030b233e*/
  v10 = **(unsigned __int8 **)a2; /*0x1030b234a*/
  if ( v10 != 54 ) /*0x1030b2350*/
  {
    if ( v10 == 51 ) /*0x1030b2355*/
    {
      sqlite3VdbeAddOp3(a1: *(_QWORD *)(a1 + 16), a2: 76, a3: 0, a4: a6, a5: 0); /*0x1030b237b*/
      goto LABEL_7; /*0x1030b2380*/
    }
    if ( v10 != 45 ) /*0x1030b235a*/
    {
      codeINTerm(a1, a2, a3, a4, a5, a6, a7: v6); /*0x1030b238b*/
      goto LABEL_7; /*0x1030b238b*/
    }
  }
  v7 = sqlite3ExprCodeTarget(a1, a2: *(_QWORD *)(*(_QWORD *)a2 + 24LL), a3: a6); /*0x1030b2367*/
LABEL_7:
  if ( (*(_BYTE *)(*(_QWORD *)(a3 + 96) + 50LL) & 0x20) == 0 || (a2[21] & 8) == 0 ) /*0x1030b239f*/
    disableTerm(a1: a3, a2); /*0x1030b23a7*/
  return v7; /*0x1030b23b2*/
}

// Address: 0x1030b23b9 | Name: _codeExprOrVector
int *__fastcall codeExprOrVector(__int64 a1, unsigned __int8 *a2, unsigned int a3, int a4)
{
  unsigned int v4; // ebx
  unsigned __int8 v7; // al
  char *v8; // rcx
  int *result; // rax
  __int64 v10; // r12
  __int64 v11; // r15
  __int64 v12; // r13
  __int64 v13; // r12
  unsigned int v14; // eax

  v4 = a3; /*0x1030b23c7*/
  if ( a2 == nullptr ) /*0x1030b23cf*/
    return (int *)sqlite3ExprCode(a1, a2, a3); /*0x1030b23cf*/
  v7 = *a2; /*0x1030b23d4*/
  if ( *a2 == 0xB0 ) /*0x1030b23d8*/
    v7 = a2[2]; /*0x1030b23da*/
  v8 = (char *)a2; /*0x1030b23dd*/
  if ( v7 != 0xB1 ) /*0x1030b23e2*/
  {
    if ( v7 != 139 ) /*0x1030b23ec*/
      return (int *)sqlite3ExprCode(a1, a2, a3); /*0x1030b240e*/
    v8 = *((char **)a2 + 4); /*0x1030b23ee*/
  }
  result = *((int **)v8 + 4); /*0x1030b23f2*/
  if ( *result < 2 ) /*0x1030b23f9*/
    return (int *)sqlite3ExprCode(a1, a2, a3); /*0x1030b23f9*/
  if ( (a2[5] & 0x10) != 0 ) /*0x1030b2417*/
  {
    v13 = *(_QWORD *)(a1 + 16); /*0x1030b2459*/
    v14 = sqlite3CodeSubselect(a1); /*0x1030b2460*/
    return (int *)sqlite3VdbeAddOp3(a1: v13, a2: 81, a3: v14, a4: v4, a5: (unsigned int)(a4 - 1)); /*0x1030b2485*/
  }
  else if ( a4 > 0 ) /*0x1030b241c*/
  {
    v10 = *((_QWORD *)a2 + 4); /*0x1030b241e*/
    v11 = 24LL * (unsigned int)a4; /*0x1030b2429*/
    v12 = 0; /*0x1030b242d*/
    do /*0x1030b2448*/
    {
      result = (int *)sqlite3ExprCode(a1, a2: *(_QWORD *)(v10 + v12 + 8), a3: v4++); /*0x1030b243a*/
      v12 += 24; /*0x1030b2441*/
    }
    while ( v11 != v12 ); /*0x1030b2448*/
  }
  return result; /*0x1030b2404*/
}

// Address: 0x1030b269d | Name: _codeAllEqualityTerms
__int64 __fastcall codeAllEqualityTerms(__int64 a1, __int64 a2, unsigned int a3, int a4, __int64 *a5)
{
  __int64 v5; // r12
  __int64 v6; // rbx
  __int64 v7; // rax
  __int64 v8; // r15
  __int64 v9; // rsi
  int v10; // r13d
  __int64 v11; // rax
  unsigned int v12; // r14d
  unsigned int v13; // r12d
  __int64 v14; // r8
  unsigned int v15; // r13d
  _DWORD *v16; // rcx
  __int64 v17; // rdi
  __int64 v18; // r12
  unsigned int v19; // eax
  unsigned __int64 v20; // rcx
  __int64 v21; // r13
  int CanBeNull; // eax
  char *v23; // r12
  char v24; // al
  int v25; // eax
  __int64 v27; // [rsp+8h] [rbp-78h]
  int v28; // [rsp+10h] [rbp-70h]
  _BOOL4 v30; // [rsp+20h] [rbp-60h]
  __int64 v31; // [rsp+28h] [rbp-58h]
  int v32; // [rsp+34h] [rbp-4Ch]
  __int64 v34; // [rsp+40h] [rbp-40h]

  v5 = *(_QWORD *)a1; /*0x1030b26b5*/
  v6 = *(_QWORD *)(a1 + 16); /*0x1030b26b8*/
  v7 = *(_QWORD *)(a2 + 96); /*0x1030b26c0*/
  LODWORD(v8) = *(unsigned __int16 *)(v7 + 54); /*0x1030b26c8*/
  v27 = v7; /*0x1030b26cd*/
  v9 = *(_QWORD *)(v7 + 32); /*0x1030b26d1*/
  v10 = *(_DWORD *)(a1 + 64); /*0x1030b26d5*/
  v31 = *(unsigned __int16 *)(v7 + 24); /*0x1030b26d9*/
  v28 = v31 + a4; /*0x1030b26df*/
  *(_DWORD *)(a1 + 64) = v31 + a4 + v10; /*0x1030b26eb*/
  v11 = *(_QWORD *)(v9 + 32); /*0x1030b26ee*/
  if ( v11 == 0 ) /*0x1030b26f5*/
    v11 = computeIndexAffStr(a1: v5, a2: v9); /*0x1030b26fa*/
  v12 = v10 + 1; /*0x1030b26ff*/
  v34 = sqlite3DbStrDup(a1: v5, a2: v11); /*0x1030b270e*/
  if ( (_DWORD)v8 != 0 ) /*0x1030b2715*/
  {
    v13 = *(_DWORD *)(a2 + 8); /*0x1030b271f*/
    v14 = (unsigned int)(v8 + v10); /*0x1030b2726*/
    v15 = 0; /*0x1030b2729*/
    sqlite3VdbeAddOp3(a1: v6, a2: 76, a3: 0, a4: v12, a5: v14); /*0x1030b2739*/
    v30 = a3 == 0; /*0x1030b2747*/
    sqlite3VdbeAddOp3(a1: v6, a2: (unsigned int)(4 * v30 + 32), a3: v13, a4: 0, a5: 0); /*0x1030b275d*/
    v32 = sqlite3VdbeAddOp3(a1: v6, a2: 9, a3: 0, a4: 0, a5: 0); /*0x1030b2776*/
    *(_DWORD *)(a2 + 24) = sqlite3VdbeAddOp4Int( /*0x1030b279a*/
                             a1: v6,
                             a2: (unsigned int)(3 * v30 + 21),
                             a3: v13,
                             a4: 0,
                             a5: v12,
                             a6: (unsigned int)v8);
    if ( *(_BYTE *)(*(_QWORD *)v6 + 103LL) != 0 ) /*0x1030b27aa*/
      v16 = &sqlite3VdbeGetOp_dummy; /*0x1030b27ac*/
    else
      v16 = (_DWORD *)(*(_QWORD *)(v6 + 136) + 24LL * v32); /*0x1030b27c1*/
    v16[2] = *(_DWORD *)(v6 + 144); /*0x1030b27c8*/
    do /*0x1030b27e8*/
    {
      sqlite3VdbeAddOp3(a1: v6, a2: 95, a3: v13, a4: v15, a5: v12 + v15); /*0x1030b27dd*/
      ++v15; /*0x1030b27e2*/
    }
    while ( (_DWORD)v8 != v15 ); /*0x1030b27e8*/
  }
  if ( (unsigned __int16)v8 < (unsigned __int16)v31 ) /*0x1030b27ef*/
  {
    v8 = (unsigned int)v8; /*0x1030b27f5*/
    v17 = a1; /*0x1030b27f8*/
    while ( 1 ) /*0x1030b2804*/
    {
      v18 = *(_QWORD *)(*(_QWORD *)(v27 + 64) + 8 * v8); /*0x1030b2804*/
      v19 = codeEqualityTerm( /*0x1030b281f*/
              a1: v17,
              a2: (_BYTE *)v18,
              a3: a2,
              a4: (unsigned int)v8,
              a5: a3,
              a6: (unsigned int)v8 + v12);
      if ( (_DWORD)v8 + v12 == v19 ) /*0x1030b2827*/
        goto LABEL_18; /*0x1030b2827*/
      if ( v28 != 1 ) /*0x1030b282d*/
        break; /*0x1030b282d*/
      v17 = a1; /*0x1030b2832*/
      if ( v12 != 0 ) /*0x1030b2836*/
      {
        v20 = *(unsigned __int8 *)(a1 + 31); /*0x1030b2838*/
        if ( v20 <= 7 ) /*0x1030b2840*/
        {
          *(_BYTE *)(a1 + 31) = v20 + 1; /*0x1030b2845*/
          *(_DWORD *)(a1 + 4 * v20 + 176) = v12; /*0x1030b2848*/
        }
      }
      v12 = v19; /*0x1030b2850*/
LABEL_19:
      if ( (*(_WORD *)(v18 + 20) & 1) != 0 ) /*0x1030b2876*/
      {
        if ( (*(_BYTE *)(*(_QWORD *)v18 + 5LL) & 0x10) == 0 || v34 == 0 ) /*0x1030b28f8*/
          goto LABEL_31; /*0x1030b28f8*/
        v23 = (char *)(v34 + v8); /*0x1030b28fe*/
      }
      else
      {
        if ( (*(_WORD *)(v18 + 20) & 0x100) != 0 ) /*0x1030b287c*/
          goto LABEL_31; /*0x1030b287c*/
        v21 = *(_QWORD *)(*(_QWORD *)v18 + 24LL); /*0x1030b2886*/
        if ( (*(_BYTE *)(v18 + 19) & 8) == 0 ) /*0x1030b2890*/
        {
          CanBeNull = sqlite3ExprCanBeNull(a1: *(_QWORD *)(*(_QWORD *)v18 + 24LL)); /*0x1030b2895*/
          v17 = a1; /*0x1030b289a*/
          if ( CanBeNull != 0 ) /*0x1030b28a0*/
          {
            sqlite3VdbeAddOp3(a1: v6, a2: 51, a3: (unsigned int)v8 + v12, a4: *(unsigned int *)(a2 + 12), a5: 0); /*0x1030b28b8*/
            v17 = a1; /*0x1030b28bd*/
          }
        }
        if ( *(_DWORD *)(v17 + 56) != 0 ) /*0x1030b28c5*/
          goto LABEL_31; /*0x1030b28c5*/
        v23 = (char *)(v34 + v8); /*0x1030b28cb*/
        if ( (unsigned __int8)sqlite3CompareAffinity(a1: v21, a2: (unsigned int)*(char *)(v34 + v8)) == 65 ) /*0x1030b28de*/
        {
          *v23 = 65; /*0x1030b28e0*/
          v24 = 65; /*0x1030b28e5*/
        }
        else
        {
          v24 = *v23; /*0x1030b2916*/
        }
        v25 = sqlite3ExprNeedsNoAffinityChange(a1: v21, a2: (unsigned int)v24); /*0x1030b2920*/
        v17 = a1; /*0x1030b2927*/
        if ( v25 == 0 ) /*0x1030b292b*/
          goto LABEL_31; /*0x1030b292b*/
      }
      *v23 = 65; /*0x1030b2902*/
LABEL_31:
      if ( v31 == ++v8 ) /*0x1030b290e*/
        goto LABEL_36; /*0x1030b290e*/
    }
    sqlite3VdbeAddOp3(a1: v6, a2: 81, a3: v19, a4: (unsigned int)v8 + v12, a5: 0); /*0x1030b2865*/
LABEL_18:
    v17 = a1; /*0x1030b286a*/
    goto LABEL_19; /*0x1030b286a*/
  }
LABEL_36:
  *a5 = v34; /*0x1030b292f*/
  return v12; /*0x1030b293d*/
}

// Address: 0x1030b29b6 | Name: _codeApplyAffinity
__int64 __fastcall codeApplyAffinity(__int64 a1, unsigned int a2, int a3, char *a4)
{
  __int64 result; // rax
  char *v5; // rbx
  __int64 v6; // rdx
  bool v7; // cc
  __int64 v8; // r14
  __int64 v9; // r15
  unsigned int v10; // eax

  if ( a4 != nullptr ) /*0x1030b29c3*/
  {
    LODWORD(result) = a3; /*0x1030b29c5*/
    if ( a3 > 0 ) /*0x1030b29c9*/
    {
      v5 = &a4[a3]; /*0x1030b29cd*/
      v6 = a3 + a2; /*0x1030b29d0*/
      while ( *a4 <= 65 ) /*0x1030b29d6*/
      {
        ++a2; /*0x1030b29dc*/
        ++a4; /*0x1030b29de*/
        v7 = (int)result <= 1; /*0x1030b29e1*/
        LODWORD(result) = result - 1; /*0x1030b29e4*/
        if ( v7 ) /*0x1030b29e7*/
        {
          LODWORD(result) = 0; /*0x1030b29e9*/
          goto LABEL_8; /*0x1030b29eb*/
        }
      }
    }
    v5 = a4; /*0x1030b29ed*/
    v6 = a2; /*0x1030b29f0*/
LABEL_8:
    v8 = *(_QWORD *)(a1 + 16); /*0x1030b29f2*/
    result = (unsigned int)result; /*0x1030b29f6*/
    while ( 1 ) /*0x1030b29f8*/
    {
      v9 = result; /*0x1030b29f8*/
      if ( (int)result < 2 ) /*0x1030b29ff*/
        break; /*0x1030b29ff*/
      --result; /*0x1030b2a01*/
      if ( v5[v9 - 1] >= 66 ) /*0x1030b2a0b*/
        goto LABEL_13; /*0x1030b2a0b*/
    }
    if ( result != 1 ) /*0x1030b2a13*/
      return result; /*0x1030b2a13*/
LABEL_13:
    v10 = sqlite3VdbeAddOp3(a1: *(_QWORD *)(a1 + 16), a2: 97, a3: v6, a4: (unsigned int)v9, a5: 0); /*0x1030b2a15*/
    return sqlite3VdbeChangeP4(a1: v8, a2: v10, a3: v5, a4: (unsigned int)v9); /*0x1030b2a3d*/
  }
  return result; /*0x1030b2a37*/
}

// Address: 0x1030b2a4d | Name: _codeDeferredSeek
__int64 __fastcall codeDeferredSeek(__int64 a1, __int64 a2, unsigned int a3, unsigned int a4)
{
  _QWORD *v6; // rbx
  __int64 v7; // r15
  __int64 result; // rax
  __int64 v9; // r14
  unsigned __int64 v10; // r13
  __int64 v11; // r13
  __int64 v12; // rbx
  __int64 v13; // r15
  int v14; // r12d
  __int16 v15; // ax
  __int64 v16; // [rsp+8h] [rbp-38h]
  __int64 v17; // [rsp+10h] [rbp-30h]

  v6 = *(_QWORD **)a1; /*0x1030b2a67*/
  v7 = *(_QWORD *)(*(_QWORD *)a1 + 16LL); /*0x1030b2a6a*/
  *(_BYTE *)(a1 + 68) |= 1u; /*0x1030b2a6e*/
  sqlite3VdbeAddOp3(a1: v7, a2: 142, a3: a4, a4: 0, a5: a3); /*0x1030b2a7e*/
  result = *(unsigned __int16 *)(a1 + 60); /*0x1030b2a83*/
  if ( (result & 0x1020) != 0 ) /*0x1030b2a8d*/
  {
    result = v6[18]; /*0x1030b2a8f*/
    if ( result == 0 ) /*0x1030b2a99*/
      result = (__int64)v6; /*0x1030b2a99*/
    if ( *(_DWORD *)(result + 120) == 0 ) /*0x1030b2aa1*/
    {
      v9 = *(_QWORD *)(a2 + 24); /*0x1030b2ab2*/
      result = sqlite3DbMallocZero(a1: *v6, a2: 4LL * *(__int16 *)(v9 + 54) + 4); /*0x1030b2ac7*/
      if ( result != 0 ) /*0x1030b2acf*/
      {
        v16 = v7; /*0x1030b2ad1*/
        v17 = result; /*0x1030b2ada*/
        *(_DWORD *)result = *(__int16 *)(v9 + 54); /*0x1030b2ade*/
        v10 = *(unsigned __int16 *)(a2 + 96); /*0x1030b2ae0*/
        if ( v10 >= 2 ) /*0x1030b2aea*/
        {
          v11 = (unsigned int)(v10 - 1); /*0x1030b2aec*/
          v12 = *(_QWORD *)(a2 + 8); /*0x1030b2aef*/
          v13 = 0; /*0x1030b2af4*/
          do /*0x1030b2b24*/
          {
            v14 = *(__int16 *)(v12 + 2 * v13); /*0x1030b2af7*/
            v15 = sqlite3TableColumnToStorage(a1: v9, a2: (unsigned int)v14); /*0x1030b2b02*/
            ++v13; /*0x1030b2b10*/
            if ( v14 >= 0 ) /*0x1030b2b0a*/
              *(_DWORD *)(v17 + 4LL * v15 + 4) = v13; /*0x1030b2b17*/
          }
          while ( v13 != v11 ); /*0x1030b2b24*/
        }
        return sqlite3VdbeChangeP4(a1: v16, a2: 0xFFFFFFFFLL, a3: v17, a4: 4294967282LL); /*0x1030b2b46*/
      }
    }
  }
  return result; /*0x1030b2aa3*/
}

// Address: 0x1030b2c1e | Name: _codeINTerm
__int64 __fastcall codeINTerm(__int64 *a1, _QWORD *a2, __int64 a3, int a4, _BOOL4 a5, unsigned int a6)
{
  int v6; // ebx
  __int64 v7; // r13
  __int64 v9; // r15
  __int64 v10; // rax
  __int64 v11; // rsi
  __int64 v12; // rdx
  _QWORD *v13; // r11
  __int64 v14; // rax
  int v15; // ecx
  __int64 v16; // r10
  bool v17; // zf
  int v18; // eax
  _BOOL4 v19; // r14d
  int v20; // eax
  int v21; // ecx
  __int64 v22; // r12
  __int64 result; // rax
  char *v24; // rbx
  __int64 v25; // rsi
  unsigned int v26; // r15d
  __int64 v27; // r12
  __int64 v28; // rdx
  char *v29; // rbx
  __int64 v30; // r13
  __int64 v31; // r14
  __int64 v32; // rdi
  __int64 v33; // rsi
  __int64 v34; // rdx
  __int64 v35; // rcx
  __int64 v36; // r8
  __int64 v37; // rax
  int v38; // eax
  __int64 v39; // r14
  __int64 v40; // rcx
  __int64 v41; // r14
  __int64 v42; // rdi
  _QWORD *v43; // rcx
  __int64 v44; // rcx
  __int64 v45; // rcx
  __int64 v46; // r14
  int *v47; // r13
  __int64 v48; // rax
  __int64 v49; // rbx
  _QWORD *v50; // r15
  __int64 v51; // rbx
  _DWORD *v52; // rdx
  int v53; // eax
  __int64 v54; // rax
  __int64 v55; // rbx
  __m128i v56; // xmm12
  __m128i si128; // xmm10
  __int64 v58; // rax
  __m128i v59; // xmm0
  __int64 v60; // rax
  __m128i v61; // xmm0
  unsigned __int64 v62; // rcx
  __m128i v63; // xmm1
  __m128i v64; // xmm2
  __m128i v65; // xmm3
  __m128i v66; // xmm4
  __m128i v67; // xmm5
  __m128i v68; // xmm7
  __m128i v69; // xmm6
  __m128i v70; // xmm5
  __m128i v71; // xmm7
  __m128i v72; // xmm8
  __m128i v73; // xmm5
  __m128i v74; // xmm5
  __m128i v75; // xmm6
  __m128i v76; // xmm7
  __m128i v77; // xmm5
  __m128i v78; // xmm6
  __m128i v79; // xmm7
  __m128i v80; // xmm8
  __m128i v81; // xmm8
  __m128i v82; // xmm5
  __m128i v83; // xmm5
  __m128i v84; // xmm7
  __m128i v85; // xmm6
  __m128i v86; // xmm5
  __m128i v87; // xmm7
  __m128i v88; // xmm8
  __m128i v89; // xmm5
  __m128i v90; // xmm5
  __m128i v91; // xmm6
  __m128i v92; // xmm7
  __m128i v93; // xmm5
  __m128i v94; // xmm6
  __m128i v95; // xmm7
  __m128i v96; // xmm8
  __m128i v97; // xmm8
  __m128i v98; // xmm5
  int v99; // r14d
  _QWORD *v100; // [rsp+0h] [rbp-C0h]
  __int64 v101; // [rsp+8h] [rbp-B8h]
  __int64 v102; // [rsp+10h] [rbp-B0h]
  __int64 v103; // [rsp+18h] [rbp-A8h]
  _BOOL4 v104; // [rsp+20h] [rbp-A0h]
  unsigned int v106; // [rsp+28h] [rbp-98h]
  __int64 v107; // [rsp+28h] [rbp-98h]
  __int64 v108; // [rsp+30h] [rbp-90h]
  __int64 v109; // [rsp+38h] [rbp-88h]
  __int64 v110; // [rsp+40h] [rbp-80h]
  char v111; // [rsp+40h] [rbp-80h]
  __int64 v112; // [rsp+48h] [rbp-78h]
  int v113; // [rsp+50h] [rbp-70h]
  __int64 v114; // [rsp+50h] [rbp-70h]
  __int64 v115; // [rsp+58h] [rbp-68h]
  unsigned int v116; // [rsp+64h] [rbp-5Ch] BYREF
  __int64 v117; // [rsp+68h] [rbp-58h]
  __int64 v118; // [rsp+70h] [rbp-50h]
  void *__src; // [rsp+78h] [rbp-48h]
  __int64 *v120; // [rsp+80h] [rbp-40h]
  __int64 v121; // [rsp+88h] [rbp-38h]
  int v122; // [rsp+94h] [rbp-2Ch]

  v6 = a4; /*0x1030b2c32*/
  v7 = a3; /*0x1030b2c34*/
  v120 = a1; /*0x1030b2c3a*/
  v9 = *(_QWORD *)(a3 + 96); /*0x1030b2c3e*/
  if ( (*(_BYTE *)(v9 + 49) & 4) == 0 ) /*0x1030b2c47*/
  {
    v10 = *(_QWORD *)(v9 + 32); /*0x1030b2c49*/
    if ( v10 != 0 && *(_BYTE *)(*(_QWORD *)(v10 + 56) + a4) != 0 ) /*0x1030b2c5d*/
      a5 = !a5; /*0x1030b2c67*/
  }
  v11 = *a2; /*0x1030b2c6a*/
  if ( a4 <= 0 ) /*0x1030b2c77*/
  {
LABEL_10:
    v100 = a2; /*0x1030b2c9b*/
    v109 = v120[2]; /*0x1030b2ca2*/
    v14 = *(unsigned __int16 *)(v9 + 52); /*0x1030b2ca9*/
    v15 = 0; /*0x1030b2cae*/
    if ( (int)v14 > v6 ) /*0x1030b2cb2*/
    {
      v16 = v6; /*0x1030b2cb8*/
      v15 = 0; /*0x1030b2cbb*/
      do /*0x1030b2cd4*/
        v15 += **(_QWORD **)(*(_QWORD *)(v9 + 64) + 8 * v16++) == v11; /*0x1030b2ccb*/
      while ( v14 != v16 ); /*0x1030b2cd4*/
    }
    v104 = a5; /*0x1030b2cd6*/
    v116 = 0; /*0x1030b2cdd*/
    v17 = (*(_BYTE *)(v11 + 5) & 0x10) == 0; /*0x1030b2ce4*/
    v103 = v15; /*0x1030b2ceb*/
    v122 = v6; /*0x1030b2cf2*/
    v108 = v7; /*0x1030b2cf5*/
    v112 = v9; /*0x1030b2d03*/
    v121 = v11; /*0x1030b2d07*/
    if ( v17 || **(_DWORD **)(*(_QWORD *)(v11 + 32) + 32LL) == 1 ) /*0x1030b2d18*/
    {
      v118 = 0; /*0x1030b2d1e*/
      v18 = sqlite3FindInIndex(a1: v120, a2: v11, a3: 4, a4: 0, a5: 0, a6: &v116); /*0x1030b2d38*/
    }
    else
    {
      v39 = *v120; /*0x1030b3019*/
      v118 = 0; /*0x1030b301c*/
      v40 = exprDup(a1: v39, a2: v11, a3: 0, a4: 0); /*0x1030b3030*/
      v18 = 5; /*0x1030b3033*/
      v115 = v39; /*0x1030b3038*/
      if ( *(_BYTE *)(v39 + 103) != 0 ) /*0x1030b3041*/
      {
        v41 = v40; /*0x1030b3043*/
      }
      else
      {
        v41 = v40; /*0x1030b3052*/
        if ( *(_QWORD *)(v40 + 32) == 0 ) /*0x1030b3055*/
          goto LABEL_103; /*0x1030b3055*/
        v102 = v6; /*0x1030b305e*/
        v42 = v121; /*0x1030b3065*/
        v43 = *(_QWORD **)(v40 + 32); /*0x1030b3069*/
        v101 = v41; /*0x1030b306c*/
        do /*0x1030b34fc*/
        {
          if ( v43 == *(_QWORD **)(v41 + 32) ) /*0x1030b3077*/
            v114 = *(_QWORD *)(*(_QWORD *)(v41 + 16) + 32LL); /*0x1030b308b*/
          else
            v114 = 0; /*0x1030b3079*/
          __src = v43; /*0x1030b308f*/
          v44 = v43[4]; /*0x1030b3093*/
          v107 = v44; /*0x1030b309e*/
          if ( *(unsigned __int16 *)(v9 + 52) <= v6 ) /*0x1030b30a5*/
          {
            v47 = nullptr; /*0x1030b316d*/
            v117 = 0; /*0x1030b3170*/
          }
          else
          {
            v45 = v44 + 8; /*0x1030b30ab*/
            v46 = v102; /*0x1030b30bb*/
            v117 = 0; /*0x1030b30c2*/
            v47 = nullptr; /*0x1030b30ca*/
            v118 = v45; /*0x1030b30cd*/
            do /*0x1030b3165*/
            {
              v48 = *(_QWORD *)(*(_QWORD *)(v9 + 64) + 8 * v46); /*0x1030b30d5*/
              if ( *(_QWORD *)v48 == v42 ) /*0x1030b30dc*/
              {
                v49 = *(int *)(v48 + 36); /*0x1030b30de*/
                if ( *(_QWORD *)(v45 + 24 * (v49 - 1)) != 0 ) /*0x1030b30f1*/
                {
                  v50 = (_QWORD *)(v45 + 24 * (v49 - 1)); /*0x1030b30f3*/
                  v47 = (int *)sqlite3ExprListAppend(a1: v120, a2: v47); /*0x1030b3103*/
                  *v50 = 0; /*0x1030b3106*/
                  if ( v47 != nullptr ) /*0x1030b3110*/
                    LOWORD(v47[6 * *v47 + 1]) = v49; /*0x1030b311a*/
                  if ( v114 != 0 ) /*0x1030b3125*/
                  {
                    v117 = sqlite3ExprListAppend(a1: v120, a2: v117); /*0x1030b313c*/
                    *(_QWORD *)(v114 + 8 + 24 * (v49 - 1)) = 0; /*0x1030b3140*/
                  }
                  v9 = v112; /*0x1030b3148*/
                  v42 = v121; /*0x1030b314c*/
                  v45 = v118; /*0x1030b3150*/
                }
                else
                {
                  v9 = v112; /*0x1030b3156*/
                }
              }
              ++v46; /*0x1030b315a*/
            }
            while ( v46 < *(unsigned __int16 *)(v9 + 52) ); /*0x1030b3165*/
          }
          v41 = v101; /*0x1030b3182*/
          if ( v107 != 0 ) /*0x1030b3189*/
          {
            exprListDeleteNN(a1: v115); /*0x1030b318f*/
            v42 = v121; /*0x1030b3194*/
          }
          v51 = v117; /*0x1030b319f*/
          if ( v114 != 0 ) /*0x1030b31a3*/
          {
            exprListDeleteNN(a1: v115); /*0x1030b31a9*/
            v42 = v121; /*0x1030b31ae*/
            *(_QWORD *)(*(_QWORD *)(v101 + 16) + 32LL) = v117; /*0x1030b31b6*/
          }
          v52 = __src; /*0x1030b31ba*/
          *((_QWORD *)__src + 4) = v47; /*0x1030b31be*/
          v53 = *((_DWORD *)v120 + 33) + 1; /*0x1030b31cc*/
          *((_DWORD *)v120 + 33) = v53; /*0x1030b31ce*/
          v52[4] = v53; /*0x1030b31d4*/
          if ( v51 != 0 ) /*0x1030b31da*/
          {
            v54 = v51; /*0x1030b31dc*/
            if ( *(_DWORD *)v51 == 1 ) /*0x1030b31e2*/
            {
              v55 = *(_QWORD *)(v51 + 8); /*0x1030b31e4*/
              *(_QWORD *)(v54 + 8) = 0; /*0x1030b31e8*/
              if ( *(_QWORD *)(v101 + 16) != 0 ) /*0x1030b31f7*/
              {
                sqlite3ExprDeleteNN(a1: v115); /*0x1030b31fd*/
                v42 = v121; /*0x1030b3202*/
              }
              *(_QWORD *)(v101 + 16) = v55; /*0x1030b3206*/
            }
          }
          if ( v47 != nullptr ) /*0x1030b320d*/
          {
            adjustOrderByCol(a1: *((int **)__src + 9), a2: v47); /*0x1030b321e*/
            adjustOrderByCol(a1: *((int **)__src + 7), a2: v47); /*0x1030b322a*/
            v56 = _mm_cvtepi8_epi64(2056); /*0x1030b322f*/
            si128 = _mm_load_si128((const __m128i *)&xmmword_108F246C0); /*0x1030b323e*/
            v42 = v121; /*0x1030b3247*/
            v58 = *v47; /*0x1030b324b*/
            if ( v58 > 0 ) /*0x1030b3252*/
            {
              v59 = _mm_shuffle_epi32((__m128i)(unsigned __int64)(v58 - 1), 68); /*0x1030b3263*/
              v60 = 192LL * ((unsigned int)(v58 + 7) >> 3); /*0x1030b326f*/
              v61 = _mm_xor_si128(v59, si128); /*0x1030b3273*/
              v62 = 0; /*0x1030b3278*/
              v63 = _mm_cvtepi8_epi64(256); /*0x1030b327a*/
              v64 = _mm_cvtepi8_epi64(770); /*0x1030b3283*/
              v65 = _mm_cvtepi8_epi64(1284); /*0x1030b328c*/
              v66 = _mm_cvtepi8_epi64(1798); /*0x1030b3295*/
              do /*0x1030b34e1*/
              {
                v67 = _mm_xor_si128(v63, si128); /*0x1030b32a2*/
                v68 = _mm_cmpgt_epi32(v67, v61); /*0x1030b32ab*/
                v69 = _mm_shuffle_epi32(v68, 160); /*0x1030b32af*/
                v70 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v67, v61), 245); /*0x1030b32be*/
                v71 = _mm_shuffle_epi32(v68, 245); /*0x1030b32ce*/
                v72 = _mm_xor_si128( /*0x1030b32de*/
                        _mm_or_si128(
                          _mm_shufflelo_epi16(v71, 232),
                          _mm_and_si128(_mm_shufflelo_epi16(v70, 232), _mm_shufflelo_epi16(v69, 232))),
                        (__m128i)-1LL);
                if ( (_mm_cvtsi128_si32(_mm_packs_epi32(v72, v72)) & 1) != 0 ) /*0x1030b32f0*/
                  LOWORD(v47[v62 / 4 + 7]) = 0; /*0x1030b32f2*/
                v73 = _mm_or_si128(_mm_and_si128(v70, v69), v71); /*0x1030b32fe*/
                v74 = _mm_xor_si128(_mm_packs_epi32(v73, v73), (__m128i)-1LL); /*0x1030b3306*/
                if ( (_mm_extract_epi8(_mm_packs_epi32(v74, v74), 2) & 1) != 0 ) /*0x1030b3318*/
                  LOWORD(v47[v62 / 4 + 13]) = 0; /*0x1030b331a*/
                v75 = _mm_xor_si128(v64, si128); /*0x1030b3326*/
                v76 = _mm_cmpgt_epi32(v75, v61); /*0x1030b332f*/
                v77 = _mm_shuffle_epi32(v76, 160); /*0x1030b3333*/
                v78 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v75, v61), 245); /*0x1030b333c*/
                v79 = _mm_shuffle_epi32(v76, 245); /*0x1030b334b*/
                v80 = _mm_or_si128(_mm_and_si128(v78, v77), v79); /*0x1030b3350*/
                v81 = _mm_xor_si128(_mm_packs_epi32(v80, v80), (__m128i)-1LL); /*0x1030b335a*/
                if ( (_mm_extract_epi8(_mm_packs_epi32(v81, v81), 4) & 1) != 0 ) /*0x1030b336e*/
                  LOWORD(v47[v62 / 4 + 19]) = 0; /*0x1030b3370*/
                v82 = _mm_xor_si128( /*0x1030b338f*/
                        _mm_or_si128(
                          _mm_shufflehi_epi16(v79, 132),
                          _mm_and_si128(_mm_shufflehi_epi16(v78, 132), _mm_shufflehi_epi16(v77, 132))),
                        (__m128i)-1LL);
                if ( (_mm_extract_epi8(_mm_packs_epi32(v82, v82), 6) & 1) != 0 ) /*0x1030b33a1*/
                  LOWORD(v47[v62 / 4 + 25]) = 0; /*0x1030b33a3*/
                v83 = _mm_xor_si128(v65, si128); /*0x1030b33af*/
                v84 = _mm_cmpgt_epi32(v83, v61); /*0x1030b33b8*/
                v85 = _mm_shuffle_epi32(v84, 160); /*0x1030b33bc*/
                v86 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v83, v61), 245); /*0x1030b33cb*/
                v87 = _mm_shuffle_epi32(v84, 245); /*0x1030b33db*/
                v88 = _mm_xor_si128( /*0x1030b33eb*/
                        _mm_or_si128(
                          _mm_shufflelo_epi16(v87, 232),
                          _mm_and_si128(_mm_shufflelo_epi16(v86, 232), _mm_shufflelo_epi16(v85, 232))),
                        (__m128i)-1LL);
                if ( (_mm_extract_epi8(_mm_packs_epi32(v88, v88), 8) & 1) != 0 ) /*0x1030b33ff*/
                  LOWORD(v47[v62 / 4 + 31]) = 0; /*0x1030b3401*/
                v89 = _mm_or_si128(_mm_and_si128(v86, v85), v87); /*0x1030b340d*/
                v90 = _mm_xor_si128(_mm_packs_epi32(v89, v89), (__m128i)-1LL); /*0x1030b3415*/
                if ( (_mm_extract_epi8(_mm_packs_epi32(v90, v90), 10) & 1) != 0 ) /*0x1030b3427*/
                  LOWORD(v47[v62 / 4 + 37]) = 0; /*0x1030b3429*/
                v91 = _mm_xor_si128(v66, si128); /*0x1030b3438*/
                v92 = _mm_cmpgt_epi32(v91, v61); /*0x1030b3441*/
                v93 = _mm_shuffle_epi32(v92, 160); /*0x1030b3445*/
                v94 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v91, v61), 245); /*0x1030b344e*/
                v95 = _mm_shuffle_epi32(v92, 245); /*0x1030b345d*/
                v96 = _mm_or_si128(_mm_and_si128(v94, v93), v95); /*0x1030b3462*/
                v97 = _mm_xor_si128(_mm_packs_epi32(v96, v96), (__m128i)-1LL); /*0x1030b346c*/
                if ( (_mm_extract_epi8(_mm_packs_epi32(v97, v97), 12) & 1) != 0 ) /*0x1030b3480*/
                  LOWORD(v47[v62 / 4 + 43]) = 0; /*0x1030b3482*/
                v98 = _mm_xor_si128( /*0x1030b34a4*/
                        _mm_or_si128(
                          _mm_shufflehi_epi16(v95, 132),
                          _mm_and_si128(_mm_shufflehi_epi16(v94, 132), _mm_shufflehi_epi16(v93, 132))),
                        (__m128i)-1LL);
                if ( (_mm_extract_epi8(_mm_packs_epi32(v98, v98), 14) & 1) != 0 ) /*0x1030b34b6*/
                  LOWORD(v47[v62 / 4 + 49]) = 0; /*0x1030b34b8*/
                v63 = _mm_add_epi64(v63, v56); /*0x1030b34c3*/
                v64 = _mm_add_epi64(v64, v56); /*0x1030b34c8*/
                v65 = _mm_add_epi64(v65, v56); /*0x1030b34cd*/
                v66 = _mm_add_epi64(v66, v56); /*0x1030b34d2*/
                v62 += 192LL; /*0x1030b34d7*/
              }
              while ( v60 != v62 ); /*0x1030b34e1*/
            }
          }
          v43 = *((_QWORD **)__src + 10); /*0x1030b34eb*/
          v6 = v122; /*0x1030b34f2*/
          v7 = v108; /*0x1030b34f5*/
        }
        while ( v43 != nullptr ); /*0x1030b34fc*/
        v18 = 5; /*0x1030b350a*/
        if ( *(_BYTE *)(v115 + 103) != 0 ) /*0x1030b350f*/
        {
          v118 = 0; /*0x1030b3511*/
        }
        else
        {
LABEL_103:
          v118 = sqlite3DbMallocZero(a1: v115, a2: 4 * v103); /*0x1030b3548*/
          v18 = sqlite3FindInIndex(a1: v120, a2: v41, a3: 4, a4: 0, a5: v118, a6: &v116); /*0x1030b354c*/
        }
      }
      if ( v41 != 0 ) /*0x1030b3554*/
      {
        v99 = v18; /*0x1030b3561*/
        sqlite3ExprDeleteNN(a1: v115); /*0x1030b3564*/
        v18 = v99; /*0x1030b3569*/
      }
    }
    v19 = !v104; /*0x1030b2d48*/
    v113 = v18; /*0x1030b2d4c*/
    if ( v18 != 4 ) /*0x1030b2d52*/
      v19 = v104; /*0x1030b2d52*/
    LODWORD(v117) = v116; /*0x1030b2d6f*/
    sqlite3VdbeAddOp3(a1: v109, a2: 4 * (unsigned int)!v19 + 32, a3: v116, a4: 0, a5: 0); /*0x1030b2d77*/
    v20 = *(_DWORD *)(v9 + 48); /*0x1030b2d7c*/
    *(_DWORD *)(v9 + 48) = v20 | 0x800; /*0x1030b2d88*/
    if ( *(_DWORD *)(v7 + 80) == 0 ) /*0x1030b2d91*/
    {
      v21 = *((_DWORD *)v120 + 19) - 1; /*0x1030b2d9a*/
      *((_DWORD *)v120 + 19) = v21; /*0x1030b2d9c*/
      *(_DWORD *)(v7 + 20) = v21; /*0x1030b2d9f*/
    }
    if ( v6 > 0 && (v20 & 0x100000) == 0 ) /*0x1030b2dbd*/
      *(_DWORD *)(v9 + 48) = v20 | 0x40800; /*0x1030b2dc4*/
    v110 = *(int *)(v7 + 80); /*0x1030b2dcc*/
    *(_DWORD *)(v7 + 80) = v110 + v103; /*0x1030b2dd3*/
    v22 = *(_QWORD *)v100[1]; /*0x1030b2ddb*/
    __src = *(void **)(v7 + 88); /*0x1030b2de2*/
    result = sqlite3DbMallocRawNN(a1: **(_QWORD **)v22, a2: 20 * (v110 + v103) + 16); /*0x1030b2dfc*/
    if ( result != 0 ) /*0x1030b2e04*/
    {
      *(_QWORD *)result = *(_QWORD *)(v22 + 88); /*0x1030b2e16*/
      *(_QWORD *)(result + 8) = 20 * (v110 + v103); /*0x1030b2e19*/
      *(_QWORD *)(v22 + 88) = result; /*0x1030b2e1d*/
      v24 = (char *)(result + 16); /*0x1030b2e22*/
      if ( __src != nullptr ) /*0x1030b2e2d*/
        memcpy(__dst: v24, __src, __n: *((_QWORD *)__src - 1)); /*0x1030b2e36*/
      *(_QWORD *)(v108 + 88) = v24; /*0x1030b2e42*/
      v25 = v112; /*0x1030b2e46*/
      result = *(unsigned __int16 *)(v112 + 52); /*0x1030b2e4a*/
      v26 = a6; /*0x1030b2e51*/
      v27 = v109; /*0x1030b2e58*/
      v28 = v121; /*0x1030b2e5f*/
      if ( (int)result > v122 ) /*0x1030b2e63*/
      {
        v29 = &v24[20 * v110]; /*0x1030b2e71*/
        v106 = a6 - v122; /*0x1030b2e7e*/
        v30 = 0; /*0x1030b2e85*/
        v111 = !v19 + 39; /*0x1030b2e96*/
        v31 = v122; /*0x1030b2e9a*/
        LODWORD(__src) = 0; /*0x1030b2e9d*/
        do /*0x1030b2f7c*/
        {
          if ( **(_QWORD **)(*(_QWORD *)(v25 + 64) + 8 * v31) == v28 ) /*0x1030b2eaf*/
          {
            if ( v113 == 1 ) /*0x1030b2eb9*/
            {
              v32 = v27; /*0x1030b2ebb*/
              v33 = 136; /*0x1030b2ebe*/
              v34 = (unsigned int)v117; /*0x1030b2ec3*/
              v35 = v26; /*0x1030b2ec6*/
              v36 = 0; /*0x1030b2ec9*/
            }
            else
            {
              if ( v118 != 0 ) /*0x1030b2ed5*/
              {
                v37 = (int)__src; /*0x1030b2eda*/
                LODWORD(__src) = (_DWORD)__src + 1; /*0x1030b2edf*/
                v35 = *(unsigned int *)(v118 + 4 * v37); /*0x1030b2ee2*/
              }
              else
              {
                v35 = 0; /*0x1030b2ee7*/
              }
              v32 = v27; /*0x1030b2ee9*/
              v33 = 95; /*0x1030b2eec*/
              v34 = (unsigned int)v117; /*0x1030b2ef1*/
              v36 = v26; /*0x1030b2ef4*/
            }
            *((_DWORD *)v29 + 1) = sqlite3VdbeAddOp3(a1: v32, a2: v33, a3: v34, a4: v35, a5: v36); /*0x1030b2efc*/
            sqlite3VdbeAddOp3(a1: v27, a2: 51, a3: v26, a4: 0, a5: 0); /*0x1030b2f0f*/
            if ( v30 != 0 ) /*0x1030b2f17*/
            {
              v29[16] = -68; /*0x1030b2f19*/
              v27 = v109; /*0x1030b2f1d*/
              v28 = v121; /*0x1030b2f24*/
              v25 = v112; /*0x1030b2f28*/
            }
            else
            {
              *(_DWORD *)v29 = v117; /*0x1030b2f31*/
              v29[16] = v111; /*0x1030b2f37*/
              v38 = v122; /*0x1030b2f3a*/
              v28 = v121; /*0x1030b2f3f*/
              v25 = v112; /*0x1030b2f43*/
              if ( v122 <= 0 ) /*0x1030b2f47*/
              {
                *((_DWORD *)v29 + 3) = 0; /*0x1030b2f57*/
              }
              else
              {
                *((_DWORD *)v29 + 2) = v106; /*0x1030b2f4f*/
                *((_DWORD *)v29 + 3) = v38; /*0x1030b2f52*/
              }
              v27 = v109; /*0x1030b2f5e*/
            }
            v29 += 20; /*0x1030b2f65*/
            result = *(unsigned __int16 *)(v25 + 52); /*0x1030b2f69*/
          }
          ++v31; /*0x1030b2f6d*/
          --v30; /*0x1030b2f73*/
          ++v26; /*0x1030b2f76*/
        }
        while ( v31 < (unsigned __int16)result ); /*0x1030b2f7c*/
      }
      if ( v122 > 0 ) /*0x1030b2f89*/
      {
        result = *(unsigned __int16 *)(v25 + 49); /*0x1030b2f8b*/
        if ( (result & 0x1004) == 0 ) /*0x1030b2f94*/
          result = sqlite3VdbeAddOp3(a1: v27, a2: 126, a3: *(unsigned int *)(v108 + 8), a4: 0, a5: (unsigned int)v122); /*0x1030b2faa*/
      }
    }
    else
    {
      *(_QWORD *)(v7 + 88) = 0; /*0x1030b2fb1*/
      *(_DWORD *)(v7 + 80) = 0; /*0x1030b2fb9*/
    }
    if ( v118 != 0 ) /*0x1030b2fc8*/
      return sqlite3DbFreeNN(a1: *v120, a2: v118); /*0x1030b2fe2*/
  }
  else
  {
    v12 = 0; /*0x1030b2c7f*/
    while ( 1 ) /*0x1030b2c81*/
    {
      v13 = *(_QWORD **)(*(_QWORD *)(v9 + 64) + 8 * v12); /*0x1030b2c81*/
      if ( v13 != nullptr && *v13 == v11 ) /*0x1030b2c8d*/
        return disableTerm(a1: v7, a2); /*0x1030b3010*/
      if ( a4 == ++v12 ) /*0x1030b2c99*/
        goto LABEL_10; /*0x1030b2c99*/
    }
  }
  return result; /*0x1030b2fd1*/
}

// Address: 0x1030b5121 | Name: _codeDistinct
__int64 __fastcall codeDistinct(__int64 a1, int a2, __int64 a3, unsigned int a4, unsigned int *a5, unsigned int a6)
{
  __int64 v8; // r9
  __int64 v9; // r12
  int v10; // ecx
  unsigned int v11; // r14d
  _QWORD *v12; // rbx
  unsigned __int64 v13; // r15
  __int64 v14; // r13
  __int64 v15; // r14
  __int64 v16; // rsi
  __int64 v17; // rcx
  __int64 v18; // rax
  unsigned __int64 v19; // r8
  char v20; // al
  unsigned __int8 v21; // al
  unsigned int v22; // r13d
  unsigned int v23; // ebx
  unsigned int v24; // r14d
  __int64 v25; // rax
  unsigned __int64 v26; // rax
  __int64 v29; // [rsp+10h] [rbp-50h]
  __int64 v30; // [rsp+18h] [rbp-48h]
  unsigned int v31; // [rsp+20h] [rbp-40h]
  unsigned int v32; // [rsp+24h] [rbp-3Ch]
  unsigned __int64 v33; // [rsp+28h] [rbp-38h]
  unsigned int v35; // [rsp+34h] [rbp-2Ch]
  unsigned int v36; // [rsp+34h] [rbp-2Ch]

  if ( a2 == 1 ) /*0x1030b5138*/
  {
    return 0; /*0x1030b5241*/
  }
  else
  {
    v8 = *a5; /*0x1030b5147*/
    v9 = *(_QWORD *)(a1 + 16); /*0x1030b514a*/
    if ( a2 == 2 ) /*0x1030b5151*/
    {
      v10 = *(_DWORD *)(a1 + 64); /*0x1030b5157*/
      v11 = v10 + 1; /*0x1030b515b*/
      *(_DWORD *)(a1 + 64) = v10 + v8; /*0x1030b5163*/
      if ( (int)v8 <= 0 ) /*0x1030b516a*/
      {
        v19 = (unsigned int)(v8 - 1); /*0x1030b5267*/
      }
      else
      {
        v35 = v10 + 1; /*0x1030b5174*/
        v31 = v8 + *(_DWORD *)(v9 + 144); /*0x1030b5183*/
        v12 = a5 + 2; /*0x1030b5186*/
        v33 = (unsigned int)(v8 - 1); /*0x1030b518e*/
        v32 = a6; /*0x1030b5192*/
        v30 = a6; /*0x1030b5199*/
        v29 = (unsigned int)(v10 + 1); /*0x1030b519f*/
        v13 = 0; /*0x1030b51a3*/
        do /*0x1030b522d*/
        {
          v14 = v8; /*0x1030b51a6*/
          v15 = sqlite3ExprCollSeq(a1, a2: *v12); /*0x1030b51b5*/
          if ( v13 >= v33 ) /*0x1030b51cc*/
          {
            v16 = 54; /*0x1030b51de*/
            v17 = a4; /*0x1030b51e3*/
          }
          else
          {
            v16 = 53; /*0x1030b51d1*/
            v17 = v31; /*0x1030b51d6*/
          }
          sqlite3VdbeAddOp3(a1: v9, a2: v16, a3: v30 + v13, a4: v17, a5: v29 + v13); /*0x1030b51e6*/
          sqlite3VdbeChangeP4(a1: v9, a2: 0xFFFFFFFFLL, a3: v15, a4: 4294967294LL); /*0x1030b51fb*/
          v18 = *(int *)(v9 + 144); /*0x1030b5200*/
          if ( v18 > 0 ) /*0x1030b520b*/
            *(_WORD *)(*(_QWORD *)(v9 + 136) + 24 * v18 - 22) = 128; /*0x1030b5219*/
          ++v13; /*0x1030b5220*/
          v12 += 3; /*0x1030b5223*/
          v8 = v14; /*0x1030b5227*/
        }
        while ( v14 != v13 ); /*0x1030b522d*/
        v11 = v35; /*0x1030b5233*/
        a6 = v32; /*0x1030b5237*/
        v19 = v33; /*0x1030b523b*/
      }
      sqlite3VdbeAddOp3(a1: v9, a2: 81, a3: a6, a4: v11, a5: v19); /*0x1030b5278*/
    }
    else
    {
      v20 = *(_BYTE *)(a1 + 31); /*0x1030b5249*/
      if ( v20 != 0 ) /*0x1030b524f*/
      {
        v21 = v20 - 1; /*0x1030b5251*/
        *(_BYTE *)(a1 + 31) = v21; /*0x1030b5253*/
        v22 = *(_DWORD *)(a1 + 4LL * v21 + 176); /*0x1030b525a*/
      }
      else
      {
        v22 = *(_DWORD *)(a1 + 64) + 1; /*0x1030b5286*/
        *(_DWORD *)(a1 + 64) = v22; /*0x1030b5289*/
      }
      v23 = v8; /*0x1030b529b*/
      v36 = a3; /*0x1030b529e*/
      v24 = a6; /*0x1030b52a1*/
      sqlite3VdbeAddOp4Int(a1: v9, a2: 29, a3, a4, a5: a6, a6: v8); /*0x1030b52a4*/
      sqlite3VdbeAddOp3(a1: v9, a2: 98, a3: v24, a4: v23, a5: v22); /*0x1030b52b9*/
      sqlite3VdbeAddOp4Int(a1: v9, a2: 139, a3: v36, a4: v22, a5: v24, a6: v23); /*0x1030b52d6*/
      v25 = *(int *)(v9 + 144); /*0x1030b52db*/
      if ( v25 > 0 ) /*0x1030b52e6*/
        *(_WORD *)(*(_QWORD *)(v9 + 136) + 24 * v25 - 22) = 16; /*0x1030b52f4*/
      if ( v22 != 0 ) /*0x1030b5300*/
      {
        v26 = *(unsigned __int8 *)(a1 + 31); /*0x1030b5302*/
        v11 = v36; /*0x1030b530b*/
        if ( v26 <= 7 ) /*0x1030b530f*/
        {
          *(_BYTE *)(a1 + 31) = v26 + 1; /*0x1030b5314*/
          *(_DWORD *)(a1 + 4 * v26 + 176) = v22; /*0x1030b5318*/
        }
      }
      else
      {
        return v36; /*0x1030b5322*/
      }
    }
  }
  return v11; /*0x1030b5329*/
}

// Address: 0x1030b6ffd | Name: _checkColumnOverlap
__int64 __fastcall checkColumnOverlap(unsigned int *a1, int *a2)
{
  __int64 result; // rax
  __int64 v3; // rcx
  int *v4; // rsi
  __int64 v5; // rdx
  __int64 i; // r8
  __int64 j; // r10
  __int64 v8; // r11
  __int64 k; // rbx
  __int64 v10; // r14
  __int64 v11; // r15

  if ( a1 == nullptr || a2 == nullptr ) /*0x1030b7006*/
    return 1; /*0x1030b7012*/
  v3 = *a2; /*0x1030b7013*/
  if ( v3 <= 0 ) /*0x1030b7019*/
    return 0; /*0x1030b7090*/
  v4 = a2 + 2; /*0x1030b7024*/
  v5 = *a1; /*0x1030b7028*/
  for ( i = 0; i != v3; ++i ) /*0x1030b702a*/
  {
    if ( (int)v5 <= 0 ) /*0x1030b7036*/
      goto LABEL_14; /*0x1030b7036*/
    for ( j = 0; j != v5; ++j ) /*0x1030b7041*/
    {
      for ( k = 0; ; ++k ) /*0x1030b7049*/
      {
        v8 = *(_QWORD *)&a1[2 * j + 2]; /*0x1030b7044*/
        v10 = *(unsigned __int8 *)(v8 + k); /*0x1030b704b*/
        v11 = *(unsigned __int8 *)(*(_QWORD *)&v4[6 * i + 2] + k); /*0x1030b7050*/
        if ( (_BYTE)v10 != (_BYTE)v11 ) /*0x1030b7058*/
          break; /*0x1030b7058*/
        if ( *(_BYTE *)(v8 + k) == 0 ) /*0x1030b705d*/
          return 1; /*0x1030b705f*/
LABEL_12:
        ; /*0x1030b706b*/
      }
      if ( sqlite3UpperToLower[v10] == sqlite3UpperToLower[v11] ) /*0x1030b7069*/
        goto LABEL_12; /*0x1030b7069*/
    }
LABEL_14:
    result = 0; /*0x1030b707b*/
  }
  return result; /*0x1030b7012*/
}

// Address: 0x1030bc9d2 | Name: _checkConstraintExprNode
__int64 __fastcall checkConstraintExprNode(__int64 a1, __int64 a2)
{
  __int64 v2; // rcx
  __int16 v3; // ax

  if ( *(_BYTE *)a2 == 0xA8 ) /*0x1030bc9d5*/
  {
    v2 = *(__int16 *)(a2 + 44); /*0x1030bc9db*/
    if ( v2 < 0 ) /*0x1030bc9e3*/
    {
      v3 = 2; /*0x1030bc9f5*/
    }
    else
    {
      v3 = 1; /*0x1030bc9e9*/
      if ( *(int *)(*(_QWORD *)(a1 + 40) + 4 * v2) < 0 ) /*0x1030bc9f1*/
        return 0; /*0x1030bc9f1*/
    }
    *(_WORD *)(a1 + 36) |= v3; /*0x1030bc9f9*/
  }
  return 0; /*0x1030bca00*/
}

// Address: 0x1030be33d | Name: _changeTempStorage
__int64 __fastcall changeTempStorage(__int64 *a1, unsigned __int8 *a2)
{
  unsigned __int8 v2; // al
  int v3; // ebx
  __int64 v4; // rdx
  unsigned __int8 i; // r9
  __int64 v6; // r10
  __int64 j; // rdx
  __int64 v8; // r9
  __int64 v9; // r14
  __int64 result; // rax

  v2 = *a2; /*0x1030be344*/
  if ( (unsigned __int8)(*a2 - 48) < 3u ) /*0x1030be34c*/
  {
    v3 = (unsigned __int8)(*a2 - 48); /*0x1030be34e*/
    goto LABEL_16; /*0x1030be351*/
  }
  v4 = 0; /*0x1030be353*/
  for ( i = *a2; ; i = a2[++v4] ) /*0x1030be363*/
  {
    v6 = (unsigned __int8)aFile_3[v4]; /*0x1030be366*/
    if ( i != (_BYTE)v6 ) /*0x1030be36e*/
      break; /*0x1030be36e*/
    if ( i == 0 ) /*0x1030be373*/
    {
      v3 = 1; /*0x1030be38f*/
      goto LABEL_16; /*0x1030be394*/
    }
LABEL_8:
    ; /*0x1030be385*/
  }
  if ( sqlite3UpperToLower[i] == sqlite3UpperToLower[v6] ) /*0x1030be383*/
    goto LABEL_8; /*0x1030be383*/
  for ( j = 0; ; ++j ) /*0x1030be396*/
  {
    v8 = (unsigned __int8)aMemory_2[j]; /*0x1030be39f*/
    if ( v2 != (_BYTE)v8 ) /*0x1030be3a7*/
      break; /*0x1030be3a7*/
    if ( v2 == 0 ) /*0x1030be3ab*/
    {
      v3 = 2; /*0x1030be3c4*/
      goto LABEL_16; /*0x1030be3c9*/
    }
LABEL_14:
    v2 = a2[j + 1]; /*0x1030be3bb*/
  }
  if ( sqlite3UpperToLower[v2] == sqlite3UpperToLower[v8] ) /*0x1030be3b9*/
    goto LABEL_14; /*0x1030be3b9*/
  v3 = 0; /*0x1030be3cb*/
LABEL_16:
  v9 = *a1; /*0x1030be3cd*/
  result = *(unsigned __int8 *)(*a1 + 102); /*0x1030be3d0*/
  if ( v3 != (_DWORD)result ) /*0x1030be3d7*/
  {
    result = invalidateTempStorage(); /*0x1030be3d9*/
    if ( (_DWORD)result == 0 ) /*0x1030be3e0*/
      *(_BYTE *)(v9 + 102) = v3; /*0x1030be3e2*/
  }
  return result; /*0x1030be3e6*/
}

// Address: 0x1030bf1cd | Name: _codeAttach
__int64 __fastcall codeAttach(__int64 *a1, unsigned int a2, __int16 *a3, __int64 a4, _BYTE *a5, _BYTE *a6, _BYTE *a7)
{
  __int64 v11; // r14
  __int64 result; // rax
  __int64 v13; // rdx
  int v14; // eax
  int v15; // eax
  unsigned int v16; // ebx
  unsigned int v17; // ebx
  int v18; // r8d
  int v19; // edx
  unsigned int v20; // ecx
  __int64 v21; // rbx
  __int64 *v22; // [rsp+8h] [rbp-78h] BYREF
  __int128 v23; // [rsp+10h] [rbp-70h]
  __int128 v24; // [rsp+20h] [rbp-60h]
  __int128 v25; // [rsp+30h] [rbp-50h]
  __int16 *v26; // [rsp+40h] [rbp-40h]
  __int64 Vdbe; // [rsp+48h] [rbp-38h]
  unsigned int v28; // [rsp+54h] [rbp-2Ch]

  v26 = a3; /*0x1030bf1e7*/
  v28 = a2; /*0x1030bf1eb*/
  v11 = *a1; /*0x1030bf1f1*/
  result = sqlite3ReadSchema(); /*0x1030bf1f4*/
  if ( (_DWORD)result != 0 || *((_DWORD *)a1 + 14) != 0 ) /*0x1030bf202*/
    goto LABEL_3; /*0x1030bf202*/
  v25 = 0; /*0x1030bf247*/
  v24 = 0; /*0x1030bf24b*/
  v23 = 0; /*0x1030bf24f*/
  v22 = a1; /*0x1030bf253*/
  if ( a5 == nullptr )
  {
LABEL_14:
    if ( a6 != nullptr ) /*0x1030bf27d*/
    {
      if ( *a6 == 60 ) /*0x1030bf283*/
      {
        *a6 = 118; /*0x1030bf285*/
      }
      else
      {
        result = sqlite3ResolveExprNames(a1: &v22, a2: a6); /*0x1030bf292*/
        if ( (_DWORD)result != 0 ) /*0x1030bf299*/
          goto LABEL_3; /*0x1030bf299*/
      }
    }
    if ( a7 != nullptr ) /*0x1030bf2a4*/
    {
      if ( *a7 == 60 ) /*0x1030bf2ad*/
      {
        *a7 = 118; /*0x1030bf2af*/
      }
      else
      {
        result = sqlite3ResolveExprNames(a1: &v22, a2: a7); /*0x1030bf2b8*/
        if ( (_DWORD)result != 0 ) /*0x1030bf2bf*/
          goto LABEL_3; /*0x1030bf2bf*/
      }
    }
    if ( a4 == 0
      || (*(_BYTE *)a4 != 118 ? (v13 = 0) : (v13 = *(_QWORD *)(a4 + 8)),
          (_DWORD)(result = sqlite3AuthCheck(a1, a2: v28, a3: v13, a4: 0, a5: 0)) == 0) )
    {
      Vdbe = sqlite3GetVdbe(a1); /*0x1030bf2f7*/
      v14 = *((_DWORD *)a1 + 12); /*0x1030bf2fb*/
      if ( v14 >= 4 ) /*0x1030bf302*/
      {
        v16 = *((_DWORD *)a1 + 13); /*0x1030bf314*/
        *((_DWORD *)a1 + 13) = v16 + 4; /*0x1030bf31b*/
        *((_DWORD *)a1 + 12) = v14 - 4; /*0x1030bf322*/
      }
      else
      {
        v15 = *((_DWORD *)a1 + 16); /*0x1030bf304*/
        v16 = v15 + 1; /*0x1030bf308*/
        *((_DWORD *)a1 + 16) = v15 + 4; /*0x1030bf30e*/
      }
      sqlite3ExprCode(a1, a2: a5, a3: v16); /*0x1030bf32e*/
      sqlite3ExprCode(a1, a2: a6, a3: v16 + 1); /*0x1030bf33c*/
      sqlite3ExprCode(a1, a2: a7, a3: v16 + 2); /*0x1030bf34b*/
      result = Vdbe; /*0x1030bf350*/
      if ( Vdbe != 0 ) /*0x1030bf357*/
      {
        v17 = v16 + 3; /*0x1030bf35d*/
        v18 = *v26; /*0x1030bf364*/
        v19 = v17 - v18; /*0x1030bf36a*/
        v20 = v17; /*0x1030bf379*/
        v21 = Vdbe; /*0x1030bf37b*/
        sqlite3VdbeAddFunctionCall((_DWORD)a1, a2: 0, a3: v19, a4: v20, a5: v18, a6: (_DWORD)v26, a7: 0); /*0x1030bf37e*/
        result = sqlite3VdbeAddOp3(a1: v21, a2: 167, a3: v28 == 24, a4: 0, a5: 0); /*0x1030bf399*/
      }
    }
LABEL_3:
    if ( a5 == nullptr ) /*0x1030bf207*/
      goto LABEL_5; /*0x1030bf207*/
    goto LABEL_4; /*0x1030bf207*/
  }
  if ( *a5 == 60 ) /*0x1030bf261*/
  {
    *a5 = 118; /*0x1030bf263*/
    goto LABEL_14; /*0x1030bf268*/
  }
  if ( (unsigned int)sqlite3ResolveExprNames(a1: &v22, a2: a5) == 0 ) /*0x1030bf278*/
    goto LABEL_14; /*0x1030bf278*/
LABEL_4:
  result = sqlite3ExprDeleteNN(a1: v11); /*0x1030bf209*/
LABEL_5:
  if ( a6 != nullptr ) /*0x1030bf217*/
    result = sqlite3ExprDeleteNN(a1: v11); /*0x1030bf21f*/
  if ( a7 != nullptr ) /*0x1030bf22b*/
    return sqlite3ExprDeleteNN(a1: v11); /*0x1030bf230*/
  return result; /*0x1030bf235*/
}

// Address: 0x1030c1219 | Name: _compileoptionusedFunc
void __fastcall compileoptionusedFunc(sqlite3_context *a1, __int64 a2, _QWORD *a3)
{
  const char *v4; // rax
  int v5; // eax

  v4 = (const char *)sqlite3ValueText(a1: *a3, a2: 1); /*0x1030c122a*/
  if ( v4 != nullptr ) /*0x1030c1232*/
  {
    v5 = sqlite3_compileoption_used(zOptName: v4); /*0x1030c1237*/
    sqlite3_result_int(a1, a2: v5); /*0x1030c1247*/
  }
}

// Address: 0x1030c1253 | Name: _compileoptiongetFunc
__int64 __fastcall compileoptiongetFunc(sqlite3_context *a1, __int64 a2, _QWORD *a3)
{
  __int64 result; // rax

  result = sqlite3VdbeIntValue(a1: *a3); /*0x1030c125f*/
  if ( (unsigned int)result <= 0x36 ) /*0x1030c1267*/
    result &= 0x3Fu; /*0x1030c1269*/
  if ( a1 != nullptr ) /*0x1030c127e*/
    return setResultStrOrError(a1); /*0x1030c1296*/
  return result; /*0x1030c1294*/
}

// Address: 0x1030c1c38 | Name: _charFunc
void __fastcall charFunc(sqlite3_context *a1, int a2, __int64 a3)
{
  __int64 v6; // rax
  _BYTE *v7; // r12
  __int64 v8; // rbx
  unsigned __int64 v9; // rax
  unsigned int v10; // ecx
  sqlite3_context *v11; // [rsp+8h] [rbp-38h]
  char *v12; // [rsp+10h] [rbp-30h]

  v6 = sqlite3Malloc(a1: 4 * a2 + 1); /*0x1030c1c5d*/
  if ( v6 != 0 ) /*0x1030c1c65*/
  {
    v11 = a1; /*0x1030c1c6b*/
    v12 = (char *)v6; /*0x1030c1c6f*/
    v7 = (_BYTE *)v6; /*0x1030c1c73*/
    if ( a2 > 0 ) /*0x1030c1c79*/
    {
      v8 = 0; /*0x1030c1c82*/
      v7 = (_BYTE *)v6; /*0x1030c1c8a*/
      do /*0x1030c1d5d*/
      {
        v9 = sqlite3VdbeIntValue(a1: *(_QWORD *)(a3 + 8 * v8)); /*0x1030c1c92*/
        v10 = v9 & 0x1FFFFF; /*0x1030c1c99*/
        if ( v9 >= 0x110000 ) /*0x1030c1ca5*/
          v10 = 65533; /*0x1030c1ca5*/
        if ( v10 > 0x7F ) /*0x1030c1cac*/
        {
          if ( v10 > 0x7FF ) /*0x1030c1cc2*/
          {
            if ( v10 > 0xFFFF ) /*0x1030c1ce4*/
            {
              *(_DWORD *)v7 = _mm_cvtsi128_si32( /*0x1030c1d4d*/
                                _mm_or_si128(
                                  _mm_insert_epi8(
                                    _mm_insert_epi8(
                                      _mm_insert_epi8(_mm_cvtsi32_si128(v10 >> 18), (v10 >> 12) & 0x3F, 1),
                                      (v10 >> 6) & 0x3F,
                                      2),
                                    v10 & 0x3F,
                                    3),
                                  (__m128i)xmmword_1097AE030));
              v7 += 4; /*0x1030c1d53*/
            }
            else
            {
              *v7 = (v10 >> 12) | 0xE0; /*0x1030c1ceb*/
              v7[1] = (v10 >> 6) & 0x3F | 0x80; /*0x1030c1cf8*/
              v7[2] = v10 & 0x3F | 0x80; /*0x1030c1d03*/
              v7 += 3; /*0x1030c1d08*/
            }
          }
          else
          {
            *v7 = (v10 >> 6) | 0xC0; /*0x1030c1cc9*/
            v7[1] = v10 & 0x3F | 0x80; /*0x1030c1cd3*/
            v7 += 2; /*0x1030c1cd8*/
          }
        }
        else
        {
          *v7++ = v10; /*0x1030c1cae*/
        }
        ++v8; /*0x1030c1d57*/
      }
      while ( a2 != v8 ); /*0x1030c1d5d*/
    }
    *v7 = 0; /*0x1030c1d63*/
    sqlite3_result_text64(a1: v11, a2: v12, a3: v7 - v12, a4: sqlite3_free, encoding: 1u); /*0x1030c1d91*/
  }
  else
  {
    sqlite3_result_error_nomem(a1); /*0x1030c1da7*/
  }
}

// Address: 0x1030c238b | Name: _concatFunc
__int64 __fastcall concatFunc(__int64 a1, __int64 a2, __int64 a3)
{
  return concatFuncCore(a1, a2, a3, a4: 0, a5: ""); /*0x1030c2398*/
}

// Address: 0x1030c239e | Name: _concatwsFunc
__int64 __fastcall concatwsFunc(__int64 a1, int a2, _QWORD *a3)
{
  unsigned int v6; // r12d
  __int64 result; // rax

  v6 = sqlite3ValueBytes(a1: *a3, a2: 1); /*0x1030c23bf*/
  result = sqlite3ValueText(a1: *a3, a2: 1); /*0x1030c23ca*/
  if ( result != 0 ) /*0x1030c23d2*/
    return concatFuncCore(a1, a2: (unsigned int)(a2 - 1), a3: a3 + 1, a4: v6, a5: result); /*0x1030c23f2*/
  return result; /*0x1030c23ea*/
}

// Address: 0x1030c2b5e | Name: _changes
__int64 __fastcall changes(__int64 *a1)
{
  __int64 result; // rax
  __int64 v3; // rdi

  if ( a1 == nullptr ) /*0x1030c2b67*/
    return sqlite3_changes64(a1: 0); /*0x1030c2b97*/
  result = sqlite3_changes64(a1: *(_QWORD *)(*a1 + 24)); /*0x1030c2b73*/
  v3 = *a1; /*0x1030c2b78*/
  if ( (*(_BYTE *)(*a1 + 21) & 0x90) != 0 ) /*0x1030c2b7f*/
    return vdbeReleaseAndSetInt64(a1: v3, a2: result); /*0x1030c2b8a*/
  *(_QWORD *)v3 = result; /*0x1030c2b9c*/
  *(_WORD *)(v3 + 20) = 4; /*0x1030c2b9f*/
  return result; /*0x1030c2b88*/
}

// Address: 0x1030c3628 | Name: _countStep
_QWORD *__fastcall countStep(__int64 a1, int a2, __int64 a3)
{
  __int64 v5; // rax
  _QWORD *result; // rax
  __int64 v7; // rdx

  v5 = *(_QWORD *)(a1 + 16); /*0x1030c3635*/
  if ( *(__int16 *)(v5 + 20) < 0 ) /*0x1030c363e*/
    result = *(_QWORD **)(v5 + 8); /*0x1030c364c*/
  else
    result = (_QWORD *)createAggContext(a1, a2: 8); /*0x1030c3645*/
  if ( a2 == 0 || (v7 = 0x5555555555555555LL, _bittest64(&v7, *(unsigned int *)(*(_QWORD *)a3 + 20LL))) ) /*0x1030c3665*/
  {
    if ( result != nullptr ) /*0x1030c366e*/
      ++*result; /*0x1030c3670*/
  }
  return result; /*0x1030c3673*/
}

// Address: 0x1030c3678 | Name: _countFinalize
__int64 *__fastcall countFinalize(_QWORD *a1)
{
  __int64 v2; // rax
  __int64 *result; // rax
  __int64 v4; // rsi
  __int64 v5; // rdi

  v2 = a1[2]; /*0x1030c3681*/
  if ( *(__int16 *)(v2 + 20) < 0 ) /*0x1030c368a*/
    result = *(__int64 **)(v2 + 8); /*0x1030c3698*/
  else
    result = (__int64 *)createAggContext((__int64)a1, a2: 0); /*0x1030c3691*/
  if ( result != nullptr ) /*0x1030c369f*/
    v4 = *result; /*0x1030c36a1*/
  else
    v4 = 0; /*0x1030c36a6*/
  v5 = *a1; /*0x1030c36a8*/
  if ( (*(_BYTE *)(*a1 + 21LL) & 0x90) != 0 ) /*0x1030c36af*/
    return (__int64 *)vdbeReleaseAndSetInt64(a1: v5, a2: v4); /*0x1030c36b7*/
  *(_QWORD *)v5 = v4; /*0x1030c36bc*/
  *(_WORD *)(v5 + 20) = 4; /*0x1030c36bf*/
  return result; /*0x1030c36b5*/
}

// Address: 0x1030c36cc | Name: _countInverse
_QWORD *__fastcall countInverse(__int64 a1, int a2, __int64 a3)
{
  __int64 v5; // rax
  _QWORD *result; // rax
  __int64 v7; // rdx

  v5 = *(_QWORD *)(a1 + 16); /*0x1030c36d9*/
  if ( *(__int16 *)(v5 + 20) < 0 ) /*0x1030c36e2*/
    result = *(_QWORD **)(v5 + 8); /*0x1030c36f0*/
  else
    result = (_QWORD *)createAggContext(a1, a2: 8); /*0x1030c36e9*/
  if ( a2 == 0 || (v7 = 0x5555555555555555LL, _bittest64(&v7, *(unsigned int *)(*(_QWORD *)a3 + 20LL))) ) /*0x1030c3709*/
  {
    if ( result != nullptr ) /*0x1030c3712*/
      --*result; /*0x1030c3714*/
  }
  return result; /*0x1030c3717*/
}

// Address: 0x1030c3cd5 | Name: _contextMalloc
__int64 __fastcall contextMalloc(sqlite3_context *a1, __int64 a2)
{
  __int64 v3; // rdi
  __int64 v4; // r14

  if ( a1 == nullptr ) /*0x1030c3ce2*/
  {
    if ( MEMORY[0x88] < a2 ) /*0x1030c3d29*/
      return 0; /*0x1030c3d29*/
    goto LABEL_5; /*0x1030c3d29*/
  }
  v3 = *(_QWORD *)a1; /*0x1030c3ce4*/
  if ( *(int *)(*(_QWORD *)(*(_QWORD *)a1 + 24LL) + 136LL) >= a2 ) /*0x1030c3cf5*/
  {
LABEL_5:
    v4 = sqlite3Malloc(a1: a2); /*0x1030c3d2b*/
    if ( v4 != 0 ) /*0x1030c3d39*/
      return v4; /*0x1030c3d39*/
    sqlite3_result_error_nomem(a1); /*0x1030c3d3e*/
    return 0; /*0x1030c3d43*/
  }
  *((_DWORD *)a1 + 9) = 18; /*0x1030c3cf7*/
  v4 = 0; /*0x1030c3d05*/
  sqlite3VdbeMemSetStr(a1: v3, a2: "string or blob too big", a3: -1, a4: 1, a5: 0); /*0x1030c3d17*/
  return v4; /*0x1030c3d49*/
}

// Address: 0x1030c3dc2 | Name: _concatFuncCore
void __fastcall concatFuncCore(sqlite3_context *a1, int a2, __int64 a3, int a4, const void *a5)
{
  __int64 v7; // r13
  __int64 v8; // r15
  __int64 v9; // rbx
  __int64 v10; // rax
  unsigned __int64 v11; // rcx
  __int64 v12; // r14
  sqlite3_uint64 v13; // r15
  __int64 v14; // rdi
  __int64 v15; // rax
  const void *v16; // rbx
  char *v17; // rax
  __int64 v18; // [rsp+8h] [rbp-68h]
  int v20; // [rsp+20h] [rbp-50h]
  int v22; // [rsp+34h] [rbp-3Ch]
  char *v23; // [rsp+38h] [rbp-38h]

  v7 = (unsigned int)a2; /*0x1030c3de4*/
  if ( a2 <= 0 ) /*0x1030c3de9*/
  {
    v9 = 0; /*0x1030c3e0d*/
  }
  else
  {
    v8 = 0; /*0x1030c3deb*/
    v9 = 0; /*0x1030c3dee*/
    do /*0x1030c3e09*/
      v9 += (int)sqlite3ValueBytes(a1: *(_QWORD *)(a3 + 8 * v8++), a2: 1); /*0x1030c3e00*/
    while ( v7 != v8 ); /*0x1030c3e09*/
  }
  v10 = sqlite3Malloc(a1: a4 * (__int64)(a2 - 1) + v9 + 1); /*0x1030c3e28*/
  if ( v10 != 0 ) /*0x1030c3e30*/
  {
    v23 = (char *)v10; /*0x1030c3e36*/
    if ( a2 <= 0 ) /*0x1030c3e3d*/
    {
      v13 = 0; /*0x1030c3f22*/
    }
    else
    {
      v20 = 0; /*0x1030c3e43*/
      v11 = 0xAAAAAAAAAAAAAAAALL; /*0x1030c3e4b*/
      v12 = 0; /*0x1030c3e55*/
      v13 = 0; /*0x1030c3e58*/
      v18 = v7; /*0x1030c3e5b*/
      do /*0x1030c3f03*/
      {
        v14 = *(_QWORD *)(a3 + 8 * v12); /*0x1030c3e5f*/
        if ( !_bittest64((const __int64 *)&v11, *(unsigned int *)(v14 + 20)) ) /*0x1030c3e6a*/
        {
          v22 = sqlite3ValueBytes(a1: v14, a2: 1); /*0x1030c3e7a*/
          v15 = sqlite3ValueText(a1: *(_QWORD *)(a3 + 8 * v12), a2: 1); /*0x1030c3e86*/
          if ( v15 != 0 ) /*0x1030c3e8e*/
          {
            v16 = (const void *)v15; /*0x1030c3e90*/
            if ( a4 <= 0 || v20 == 0 ) /*0x1030c3e9e*/
            {
              v17 = v23; /*0x1030c3ecc*/
            }
            else
            {
              memcpy(__dst: &v23[v13], __src: a5, __n: a4); /*0x1030c3ebb*/
              v17 = v23; /*0x1030c3ec0*/
              v13 += a4; /*0x1030c3ec7*/
            }
            memcpy(__dst: &v17[v13], __src: v16, __n: v22); /*0x1030c3ede*/
            v13 += v22; /*0x1030c3ee3*/
            v20 = 1; /*0x1030c3eeb*/
            v7 = v18; /*0x1030c3eef*/
          }
          v11 = 0xAAAAAAAAAAAAAAAALL; /*0x1030c3ef3*/
        }
        ++v12; /*0x1030c3efd*/
      }
      while ( v7 != v12 ); /*0x1030c3f03*/
    }
    v23[v13] = 0; /*0x1030c3f29*/
    sqlite3_result_text64(a1, a2: v23, a3: v13, a4: sqlite3_free, encoding: 1u); /*0x1030c3f50*/
  }
  else
  {
    sqlite3_result_error_nomem(a1); /*0x1030c3f1d*/
  }
}

// Address: 0x1030c66be | Name: _cume_distStepFunc
__int64 __fastcall cume_distStepFunc(__int64 a1)
{
  __int64 v1; // rax
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 16); /*0x1030c66c2*/
  if ( *(__int16 *)(v1 + 20) < 0 ) /*0x1030c66cb*/
    result = *(_QWORD *)(v1 + 8); /*0x1030c66d9*/
  else
    result = createAggContext(a1, a2: 24); /*0x1030c66d2*/
  if ( result != 0 ) /*0x1030c66e0*/
    ++*(_QWORD *)(result + 16); /*0x1030c66e2*/
  return result; /*0x1030c66e6*/
}

// Address: 0x1030c66e8 | Name: _cume_distValueFunc
__int64 __fastcall cume_distValueFunc(_QWORD *a1)
{
  __int64 v2; // rax
  __int64 result; // rax

  v2 = a1[2]; /*0x1030c66f1*/
  if ( *(__int16 *)(v2 + 20) < 0 ) /*0x1030c66fa*/
    result = *(_QWORD *)(v2 + 8); /*0x1030c6708*/
  else
    result = createAggContext((__int64)a1, a2: 0); /*0x1030c6701*/
  if ( result != 0 ) /*0x1030c670f*/
    return sqlite3VdbeMemSetDouble( /*0x1030c672a*/
             a1: *a1,
             a2: (double)(int)*(_QWORD *)(result + 8) / (double)(int)*(_QWORD *)(result + 16));
  return result; /*0x1030c6728*/
}

// Address: 0x1030c6736 | Name: _cume_distInvFunc
__int64 __fastcall cume_distInvFunc(__int64 a1)
{
  __int64 v1; // rax
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 16); /*0x1030c673a*/
  if ( *(__int16 *)(v1 + 20) < 0 ) /*0x1030c6743*/
    result = *(_QWORD *)(v1 + 8); /*0x1030c6751*/
  else
    result = createAggContext(a1, a2: 24); /*0x1030c674a*/
  ++*(_QWORD *)(result + 8); /*0x1030c6755*/
  return result; /*0x1030c6759*/
}

// Address: 0x1030c80d7 | Name: _ctimeFunc
__int64 __fastcall ctimeFunc(sqlite3_context *a1)
{
  return timeFunc(a1); /*0x1030c80df*/
}

// Address: 0x1030c80e5 | Name: _ctimestampFunc
__int64 __fastcall ctimestampFunc(sqlite3_context *a1)
{
  return datetimeFunc(a1); /*0x1030c80ed*/
}

// Address: 0x1030c80f3 | Name: _cdateFunc
__int64 __fastcall cdateFunc(sqlite3_context *a1)
{
  return dateFunc(a1); /*0x1030c80fb*/
}

// Address: 0x1030c9244 | Name: _computeJD
void __fastcall computeJD(__int64 a1)
{
  int v1; // edx
  int v2; // esi
  int v3; // ecx
  char v4; // al
  int v5; // r8d
  __int64 v6; // rcx
  __int64 v7; // rdx

  if ( *(_BYTE *)(a1 + 40) != 0 ) /*0x1030c9248*/
    return; /*0x1030c9248*/
  if ( *(_BYTE *)(a1 + 41) != 0 ) /*0x1030c924f*/
  {
    v1 = *(_DWORD *)(a1 + 8); /*0x1030c9251*/
    if ( (unsigned int)(v1 - 10000) < 0xFFFFC687 ) /*0x1030c925f*/
    {
LABEL_13:
      *(_OWORD *)(a1 + 32) = 0; /*0x1030c93a0*/
      *(_OWORD *)(a1 + 16) = 0; /*0x1030c93a7*/
      *(_OWORD *)a1 = 0; /*0x1030c93ab*/
      *(_BYTE *)(a1 + 44) |= 2u; /*0x1030c93ae*/
      return; /*0x1030c93ae*/
    }
    v2 = *(_DWORD *)(a1 + 12); /*0x1030c9265*/
    v3 = *(_DWORD *)(a1 + 16); /*0x1030c9268*/
  }
  else
  {
    v2 = 1; /*0x1030c926d*/
    v1 = 2000; /*0x1030c9272*/
    v3 = 1; /*0x1030c9277*/
  }
  v4 = *(_BYTE *)(a1 + 44); /*0x1030c927c*/
  if ( (v4 & 1) != 0 ) /*0x1030c9281*/
    goto LABEL_13; /*0x1030c9281*/
  v5 = v2 + 12; /*0x1030c928b*/
  if ( v2 >= 3 ) /*0x1030c9299*/
    v5 = v2; /*0x1030c9299*/
  v6 = (unsigned int)(int)(((double)(int)(((unsigned int)(2622 * ((unsigned __int16)(v1 - (v2 < 3) + 4800) >> 4)) >> 16) /*0x1030c9326*/
                                        + (306001 * v5 + 306001) / 10000
                                        + (36525 * (v1 - (unsigned int)(v2 < 3)) + 172251900) / 0x64
                                        + v3
                                        - ((unsigned int)(5243 * ((unsigned __int16)(v1 - (v2 < 3) + 4800) >> 2)) >> 17)
                                        + 38)
                          + -1524.5)
                         * 86400000.0);
  *(_QWORD *)a1 = v6; /*0x1030c932b*/
  *(_BYTE *)(a1 + 40) = 1; /*0x1030c932e*/
  if ( *(_BYTE *)(a1 + 42) != 0 ) /*0x1030c9336*/
  {
    v7 = v6 /*0x1030c936e*/
       + 3600000LL * *(int *)(a1 + 20)
       + 60000LL * *(int *)(a1 + 24)
       + (unsigned int)(int)(*(double *)(a1 + 32) * 1000.0 + 0.5);
    *(_QWORD *)a1 = v7; /*0x1030c9371*/
    if ( *(_DWORD *)(a1 + 28) != 0 ) /*0x1030c937b*/
    {
      *(_QWORD *)a1 = v7 - 60000LL * *(int *)(a1 + 28); /*0x1030c9387*/
      *(_WORD *)(a1 + 41) = 0; /*0x1030c938a*/
      *(_DWORD *)(a1 + 28) = 0; /*0x1030c9390*/
      *(_BYTE *)(a1 + 44) = v4 & 0xE6 | 8; /*0x1030c939b*/
    }
  }
}

// Address: 0x1030c9853 | Name: _computeFloor
char __fastcall computeFloor(__int64 a1)
{
  int v1; // eax
  unsigned int v2; // ecx
  int v3; // edx
  char result; // al
  int v5; // ecx

  v1 = *(_DWORD *)(a1 + 16); /*0x1030c9857*/
  if ( v1 < 29 || (v2 = *(_DWORD *)(a1 + 12), v3 = 5546, _bittest(&v3, v2)) ) /*0x1030c9867*/
  {
    result = 0; /*0x1030c986c*/
  }
  else if ( v2 == 2 ) /*0x1030c9876*/
  {
    v5 = *(_DWORD *)(a1 + 8); /*0x1030c9878*/
    if ( (v5 & 3) != 0 || __ROR4__(-1030792151 * v5 + 85899344, 2) <= 0x28F5C28u && v5 % 400 != 0 ) /*0x1030c98b6*/
      result = v1 - 28; /*0x1030c98b8*/
    else
      result = v1 - 29; /*0x1030c98c4*/
  }
  else
  {
    result = v1 == 31; /*0x1030c98bf*/
  }
  *(_BYTE *)(a1 + 43) = result; /*0x1030c986e*/
  return result; /*0x1030c9871*/
}

// Address: 0x1030c9b7c | Name: _computeYMD
void __fastcall computeYMD(__int64 a1)
{
  int v1; // ecx
  __int64 v2; // rax
  unsigned __int64 v3; // rdx
  int v4; // eax
  int v5; // esi
  int v6; // edx
  int v7; // eax
  int v8; // edx
  __m128d v9; // xmm0
  signed int v10; // edx

  if ( *(_BYTE *)(a1 + 41) == 0 )
  {
    if ( *(_BYTE *)(a1 + 40) != 0 )
    {
      if ( *(_QWORD *)a1 >= 0x1A6401072FE00uLL ) /*0x1030c9ba0*/
      {
        *(_OWORD *)(a1 + 32) = 0; /*0x1030c9ba6*/
        *(_OWORD *)(a1 + 16) = 0; /*0x1030c9bab*/
        *(_OWORD *)a1 = 0; /*0x1030c9bb0*/
        *(_BYTE *)(a1 + 44) |= 2u; /*0x1030c9bb4*/
        return; /*0x1030c9bb8*/
      }
      v3 = (*(_QWORD *)a1 + 43200000LL) / 0x5265C00uLL; /*0x1030c9bf1*/
      v4 = (int)(((double)(int)v3 + 32044.75) / 36524.25); /*0x1030c9c09*/
      v5 = v4 + 51; /*0x1030c9c10*/
      if ( v4 + 48 >= 0 ) /*0x1030c9c15*/
        v5 = v4 + 48; /*0x1030c9c15*/
      v6 = v4 + v3 - (v5 >> 2) + 1498; /*0x1030c9c1f*/
      v7 = (int)(((double)v6 + -122.1) / 365.25); /*0x1030c9c3c*/
      v8 = v6 - 36525 * (v7 & 0x7FFFu) / 0x64; /*0x1030c9c59*/
      v9 = 0; /*0x1030c9c5b*/
      v9.f64[0] = (double)v8 / 30.6001; /*0x1030c9c6a*/
      *(_DWORD *)(a1 + 16) = v8 - (int)(_mm_cvtepi32_pd(_mm_cvttpd_epi32(v9)).f64[0] * 30.6001); /*0x1030c9c84*/
      v10 = (int)v9.f64[0] + ((int)v9.f64[0] < 14 ? -1 : 0xFFFFFFF3);
      *(_DWORD *)(a1 + 12) = v10; /*0x1030c9c96*/
      v1 = v7 + ((v10 >= 3) ^ 0xFFFFED95); /*0x1030c9ca7*/
      v2 = 8; /*0x1030c9ca9*/
    }
    else
    {
      *(_QWORD *)(a1 + 8) = 0x1000007D0LL; /*0x1030c9bc7*/
      v1 = 1; /*0x1030c9bcb*/
      v2 = 16; /*0x1030c9bd0*/
    }
    *(_DWORD *)(a1 + v2) = v1; /*0x1030c9cae*/
    *(_BYTE *)(a1 + 41) = 1; /*0x1030c9cb1*/
  }
}

// Address: 0x1030c9cb7 | Name: _computeHMS
unsigned __int64 __fastcall computeHMS(__int64 a1)
{
  __int64 v2; // rcx
  int v3; // eax
  __int64 v4; // rsi
  unsigned __int64 result; // rax

  if ( *(_BYTE *)(a1 + 42) == 0 ) /*0x1030c9cbb*/
  {
    computeJD(a1); /*0x1030c9cc7*/
    v2 = (int)(*(_QWORD *)a1 - 86400000 * ((*(_QWORD *)a1 + 43200000LL) / 86400000) + 43200000); /*0x1030c9d04*/
    v3 = (int)v2 / 60000; /*0x1030c9d19*/
    v4 = 1250999897 * v2; /*0x1030c9d21*/
    *(double *)(a1 + 32) = (double)((int)v2 % 60000) / 1000.0; /*0x1030c9d36*/
    LODWORD(v2) = (unsigned int)(34953 * (__int16)((int)v2 / 60000)) >> 16; /*0x1030c9d49*/
    *(_DWORD *)(a1 + 24) = (__int16)(v3 - 60 * (((unsigned int)v2 >> 15) + ((__int16)v2 >> 5))); /*0x1030c9d5d*/
    *(_DWORD *)(a1 + 20) = ((unsigned __int64)v4 >> 63) + (v4 >> 52); /*0x1030c9d6d*/
    *(_BYTE *)(a1 + 44) &= ~1u; /*0x1030c9d70*/
    *(_BYTE *)(a1 + 42) = 1; /*0x1030c9d74*/
    return (unsigned __int64)v4 >> 63; /*0x1030c9d63*/
  }
  return result; /*0x1030c9cbd*/
}

// Address: 0x1030cad38 | Name: _connectionIsBusy
__int64 __fastcall connectionIsBusy(__int64 a1)
{
  __int64 result; // rax
  __int64 v2; // rcx
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // rsi
  __int64 v6; // rdi

  result = 1; /*0x1030cad38*/
  if ( *(_QWORD *)(a1 + 8) == 0 ) /*0x1030cad42*/
  {
    v2 = *(int *)(a1 + 40); /*0x1030cad45*/
    if ( v2 <= 0 ) /*0x1030cad4c*/
    {
      return 0; /*0x1030cad79*/
    }
    else
    {
      v3 = *(_QWORD *)(a1 + 32); /*0x1030cad52*/
      v4 = 32 * v2; /*0x1030cad56*/
      v5 = 0; /*0x1030cad5a*/
      while ( 1 ) /*0x1030cad5c*/
      {
        v6 = *(_QWORD *)(v3 + v5 + 8); /*0x1030cad5c*/
        if ( v6 != 0 && *(_DWORD *)(v6 + 24) != 0 ) /*0x1030cad6a*/
          break; /*0x1030cad6a*/
        v5 += 32; /*0x1030cad6c*/
        if ( v4 == v5 ) /*0x1030cad73*/
          return 0; /*0x1030cad75*/
      }
    }
  }
  return result; /*0x1030cad44*/
}

// Address: 0x1030d32be | Name: _Curl_async_shutdown
void __fastcall Curl_async_shutdown(__int64 a1)
{
  Curl_async_thrdd_shutdown(a1); /*0x1030d32c7*/
  Curl_cfree(a1: *(void **)(a1 + 2568)); /*0x1030d32da*/
  *(_QWORD *)(a1 + 2568) = 0; /*0x1030d32dc*/
}

// Address: 0x1030d32ee | Name: _Curl_async_destroy
void __fastcall Curl_async_destroy(__int64 a1)
{
  Curl_async_thrdd_destroy(a1); /*0x1030d32f7*/
  Curl_cfree(a1: *(void **)(a1 + 2568)); /*0x1030d330a*/
  *(_QWORD *)(a1 + 2568) = 0; /*0x1030d330c*/
}

// Address: 0x1030d331e | Name: _Curl_async_global_init
__int64 Curl_async_global_init()
{
  return 0; /*0x1030d3324*/
}

// Address: 0x1030d3326 | Name: _Curl_async_global_cleanup
void Curl_async_global_cleanup()
{
  ; /*0x1030d3326*/
}

// Address: 0x1030d332c | Name: _Curl_async_get_impl
__int64 __fastcall Curl_async_get_impl(__int64 a1, _QWORD *a2)
{
  *a2 = 0; /*0x1030d3330*/
  return 0; /*0x1030d3339*/
}

// Address: 0x1030d333b | Name: _Curl_async_thrdd_shutdown
int __fastcall Curl_async_thrdd_shutdown(__int64 a1)
{
  return async_thrdd_shutdown(a1); /*0x1030d333f*/
}

// Address: 0x1030d33c8 | Name: _Curl_async_thrdd_destroy
__int64 __fastcall Curl_async_thrdd_destroy(__int64 a1)
{
  _QWORD *v2; // rsi

  v2 = *(_QWORD **)(a1 + 2552); /*0x1030d33d1*/
  if ( v2 != nullptr && (*(_BYTE *)(a1 + 1843) & 0x40) == 0 ) /*0x1030d33e4*/
    asyn_thrdd_await(a1, a2: v2, a3: nullptr); /*0x1030d33eb*/
  return async_thrdd_destroy(a1); /*0x1030d33f7*/
}

// Address: 0x1030d3514 | Name: _Curl_async_await
__int64 __fastcall Curl_async_await(__int64 a1, _QWORD *a2)
{
  _QWORD *v3; // rsi

  v3 = *(_QWORD **)(a1 + 2552); /*0x1030d351b*/
  if ( v3 != nullptr ) /*0x1030d3525*/
    return asyn_thrdd_await(a1, a2: v3, a3: a2); /*0x1030d3528*/
  else
    return 2; /*0x1030d352d*/
}

// Address: 0x1030d3534 | Name: _Curl_async_is_resolved
__int64 __fastcall Curl_async_is_resolved(__int64 a1, _QWORD *a2)
{
  __int64 v4; // rdi
  __int64 v5; // rdi
  char v6; // r15
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rdx
  __int64 v10; // rax
  int v11; // esi
  unsigned int v12; // esi
  bool v13; // cl
  unsigned int v14; // r12d
  __int64 v15; // rsi
  __int64 v16; // rax
  unsigned int v17; // eax

  *a2 = 0; /*0x1030d3545*/
  if ( (*(_BYTE *)(a1 + 2584) & 1) != 0 ) /*0x1030d3553*/
  {
    *a2 = *(_QWORD *)(a1 + 2560); /*0x1030d3603*/
    return 0; /*0x1030d36c7*/
  }
  v4 = *(_QWORD *)(a1 + 2552); /*0x1030d3559*/
  if ( v4 != 0 ) /*0x1030d3563*/
  {
    pthread_mutex_lock(a1: (pthread_mutex_t *)(v4 + 16)); /*0x1030d356d*/
    v5 = *(_QWORD *)(a1 + 2552); /*0x1030d3572*/
    v6 = *(_BYTE *)(v5 + 184); /*0x1030d3579*/
    pthread_mutex_unlock(a1: (pthread_mutex_t *)(v5 + 16)); /*0x1030d3584*/
    if ( (v6 & 1) == 0 ) /*0x1030d358d*/
    {
      v7 = Curl_pgrs_now(a1); /*0x1030d3596*/
      v8 = curlx_ptimediff_ms(a1: v7, a2: a1 + 2168); /*0x1030d35a5*/
      v9 = 0; /*0x1030d35aa*/
      if ( v8 > 0 ) /*0x1030d35af*/
        v9 = v8; /*0x1030d35af*/
      v10 = *(_QWORD *)(a1 + 2552); /*0x1030d35b3*/
      v11 = *(_DWORD *)(v10 + 168); /*0x1030d35ba*/
      if ( v11 != 0 ) /*0x1030d35c2*/
      {
        v12 = v11 << (v9 >= *(_QWORD *)(v10 + 160)); /*0x1030d35d6*/
        v13 = v12 < 0xFB; /*0x1030d35de*/
        if ( v12 >= 0xFA ) /*0x1030d35ea*/
          v12 = 250; /*0x1030d35ea*/
        if ( v13 && v9 < *(_QWORD *)(v10 + 160) ) /*0x1030d35cf*/
          goto LABEL_21; /*0x1030d35f1*/
      }
      else
      {
        v12 = 1; /*0x1030d36a3*/
      }
      *(_DWORD *)(v10 + 168) = v12; /*0x1030d36a8*/
LABEL_21:
      *(_QWORD *)(v10 + 160) = v12 + v9; /*0x1030d36ae*/
      Curl_expire(a1, a2: v12, a3: 1); /*0x1030d36c2*/
      return 0; /*0x1030d36c2*/
    }
    *(_BYTE *)(a1 + 2584) |= 1u; /*0x1030d3616*/
    Curl_resolv_unlink(a1, a2: a1 + 2560); /*0x1030d362a*/
    Curl_expire_done(a1, a2: 1); /*0x1030d3637*/
    v15 = *(_QWORD *)(a1 + 2552); /*0x1030d363c*/
    if ( *(_QWORD *)(v15 + 88) == 0 ) /*0x1030d3648*/
      goto LABEL_16; /*0x1030d3648*/
    v16 = Curl_dnscache_mk_entry( /*0x1030d3664*/
            a1,
            a2: v15 + 88,
            a3: *(_QWORD *)(a1 + 2568),
            a4: 0,
            a5: *(unsigned int *)(a1 + 2576),
            a6: 0);
    *(_QWORD *)(a1 + 2560) = v16; /*0x1030d3669*/
    if ( v16 == 0 ) /*0x1030d3673*/
    {
      v14 = 27; /*0x1030d36d6*/
      goto LABEL_25; /*0x1030d36d6*/
    }
    v17 = Curl_dnscache_add(a1, a2: v16); /*0x1030d367b*/
    if ( v17 == 0 ) /*0x1030d3682*/
    {
LABEL_16:
      v14 = 0; /*0x1030d3684*/
      if ( *(_QWORD *)(a1 + 2560) != 0 ) /*0x1030d368b*/
        goto LABEL_26; /*0x1030d368b*/
      v14 = 0; /*0x1030d368d*/
      v17 = Curl_resolver_error(a1, a2: 0); /*0x1030d3695*/
      if ( v17 == 0 ) /*0x1030d369c*/
        goto LABEL_26; /*0x1030d369c*/
    }
    v14 = v17; /*0x1030d369e*/
LABEL_25:
    Curl_resolv_unlink(a1, a2: a1 + 2560); /*0x1030d36dc*/
LABEL_26:
    *a2 = *(_QWORD *)(a1 + 2560); /*0x1030d36e7*/
    async_thrdd_shutdown(a1); /*0x1030d36f4*/
    return v14; /*0x1030d36f9*/
  }
  return 2; /*0x1030d36cd*/
}

// Address: 0x1030d36fb | Name: _Curl_async_pollset
__int64 __fastcall Curl_async_pollset(__int64 a1, __int64 a2)
{
  __int64 v3; // rdi
  __int64 v5; // rdi
  char v6; // r15

  v3 = *(_QWORD *)(a1 + 2552); /*0x1030d3708*/
  if ( v3 == 0 ) /*0x1030d3712*/
    return 0; /*0x1030d3712*/
  pthread_mutex_lock(a1: (pthread_mutex_t *)(v3 + 16)); /*0x1030d371b*/
  v5 = *(_QWORD *)(a1 + 2552); /*0x1030d3720*/
  v6 = *(_BYTE *)(v5 + 184); /*0x1030d3727*/
  pthread_mutex_unlock(a1: (pthread_mutex_t *)(v5 + 16)); /*0x1030d3732*/
  if ( (v6 & 1) != 0 ) /*0x1030d373b*/
    return 0; /*0x1030d3764*/
  else
    return Curl_pollset_change(a1, a2, a3: *(unsigned int *)(*(_QWORD *)(a1 + 2552) + 80LL), a4: 1, a5: 0); /*0x1030d375f*/
}

// Address: 0x1030d3771 | Name: _Curl_async_getaddrinfo
__int64 __fastcall Curl_async_getaddrinfo(__int64 a1, const char *a2, int a3, int a4)
{
  int v7; // r14d
  int v8; // r13d
  bool v9; // r14
  char *v10; // rax
  int v11; // r12d
  char *v12; // rax
  char *v13; // r12
  char *v14; // rax
  __int64 v15; // rcx
  __int64 result; // rax
  char *v17; // [rsp+0h] [rbp-40h] BYREF
  const char *v18; // [rsp+8h] [rbp-38h]
  int v19; // [rsp+14h] [rbp-2Ch]

  v18 = a2; /*0x1030d3788*/
  v7 = 2; /*0x1030d378f*/
  if ( a4 != 1 && (unsigned __int8)Curl_ipv6works(a1) != 0 ) /*0x1030d37a4*/
  {
    v7 = 30; /*0x1030d37ac*/
    if ( a4 != 2 ) /*0x1030d37b2*/
      v7 = 0; /*0x1030d37b2*/
  }
  v19 = v7; /*0x1030d37b6*/
  v8 = 0; /*0x1030d37c6*/
  v9 = (unsigned __int8)Curl_conn_get_transport(a1, a2: *(_QWORD *)(a1 + 32)) != 3; /*0x1030d37cb*/
  if ( *(_QWORD *)(a1 + 2552) != 0 ) /*0x1030d37d7*/
    async_thrdd_destroy(a1); /*0x1030d37dc*/
  *(_QWORD *)(a1 + 2560) = 0; /*0x1030d37e1*/
  *(_BYTE *)(a1 + 2584) &= ~1u; /*0x1030d37ec*/
  *(_DWORD *)(a1 + 2576) = a3; /*0x1030d37f3*/
  *(_DWORD *)(a1 + 2580) = a4; /*0x1030d37fa*/
  Curl_cfree(a1: *(void **)(a1 + 2568)); /*0x1030d380f*/
  v10 = Curl_cstrdup(__s1: v18); /*0x1030d381c*/
  *(_QWORD *)(a1 + 2568) = v10; /*0x1030d381e*/
  v11 = 12; /*0x1030d3825*/
  if ( v10 == nullptr ) /*0x1030d382e*/
    goto LABEL_16; /*0x1030d382e*/
  v12 = (char *)Curl_ccalloc(__count: 1u, __size: 0xC0u); /*0x1030d3845*/
  v17 = v12; /*0x1030d3847*/
  if ( v12 == nullptr ) /*0x1030d384e*/
    goto LABEL_15; /*0x1030d384e*/
  v13 = v12; /*0x1030d3854*/
  LOBYTE(v8) = v9; /*0x1030d3857*/
  *(_QWORD *)v12 = 0; /*0x1030d385d*/
  *((_DWORD *)v12 + 43) = a3; /*0x1030d3864*/
  *((_DWORD *)v12 + 45) = 1; /*0x1030d386b*/
  *((_DWORD *)v12 + 24) = 0; /*0x1030d3877*/
  *((_DWORD *)v12 + 25) = v19; /*0x1030d387f*/
  *((_DWORD *)v12 + 26) = v8 + 1; /*0x1030d3884*/
  *(_OWORD *)(v12 + 108) = 0; /*0x1030d388c*/
  *(_OWORD *)(v12 + 124) = 0; /*0x1030d3892*/
  *((_DWORD *)v12 + 35) = 0; /*0x1030d3898*/
  pthread_mutex_init(a1: (pthread_mutex_t *)(v12 + 16), a2: nullptr); /*0x1030d38a7*/
  if ( (int)Curl_wakeup_init(a1: v13 + 80, a2: 0) < 0 ) /*0x1030d38bc*/
  {
    *((_QWORD *)v13 + 10) = -1; /*0x1030d3948*/
    goto LABEL_14; /*0x1030d3948*/
  }
  *((_DWORD *)v13 + 44) = 0; /*0x1030d38c2*/
  v14 = Curl_cstrdup(__s1: v18); /*0x1030d38d9*/
  *((_QWORD *)v13 + 1) = v14; /*0x1030d38db*/
  if ( v14 == nullptr ) /*0x1030d38e3*/
  {
LABEL_14:
    addr_ctx_unlink(a1: (__int64 *)&v17, a2: a1); /*0x1030d3951*/
LABEL_15:
    v11 = 12; /*0x1030d395d*/
    goto LABEL_16; /*0x1030d395d*/
  }
  *(_QWORD *)(a1 + 2552) = v13; /*0x1030d38e5*/
  *((_DWORD *)v13 + 45) = 2; /*0x1030d38ec*/
  *((_OWORD *)v13 + 9) = *(_OWORD *)Curl_pgrs_now(a1); /*0x1030d3903*/
  v15 = Curl_thread_create(a1: getaddrinfo_thread, a2: v13); /*0x1030d391b*/
  *(_QWORD *)v13 = v15; /*0x1030d391e*/
  result = 0; /*0x1030d3922*/
  if ( v15 != 0 ) /*0x1030d3927*/
    return result; /*0x1030d3927*/
  *((_DWORD *)v13 + 45) = 1; /*0x1030d3929*/
  v13[184] |= 1u; /*0x1030d3935*/
  v11 = *__error(); /*0x1030d3943*/
LABEL_16:
  async_thrdd_destroy(a1); /*0x1030d3963*/
  *__error() = v11; /*0x1030d3970*/
  Curl_failf(a1, a2: "getaddrinfo() thread failed to start"); /*0x1030d397f*/
  return 2; /*0x1030d3989*/
}

// Address: 0x1030d3b3f | Name: _Curl_bufcp_init
void __fastcall Curl_bufcp_init(__int64 a1, __int64 a2, __int64 a3)
{
  *(_OWORD *)a1 = 0; /*0x1030d3b46*/
  *(_OWORD *)(a1 + 16) = 0; /*0x1030d3b49*/
  *(_QWORD *)(a1 + 8) = a2; /*0x1030d3b4d*/
  *(_QWORD *)(a1 + 24) = a3; /*0x1030d3b51*/
}

// Address: 0x1030d3b57 | Name: _Curl_bufcp_free
void __fastcall Curl_bufcp_free(__int64 a1)
{
  _QWORD *v2; // rdi

  v2 = *(_QWORD **)a1; /*0x1030d3b61*/
  if ( v2 != nullptr ) /*0x1030d3b67*/
  {
    do /*0x1030d3b7f*/
    {
      *(_QWORD *)a1 = *v2; /*0x1030d3b73*/
      Curl_cfree(a1: v2); /*0x1030d3b76*/
      v2 = *(_QWORD **)a1; /*0x1030d3b79*/
    }
    while ( *(_QWORD *)a1 != 0 ); /*0x1030d3b7f*/
  }
  *(_QWORD *)(a1 + 16) = 0; /*0x1030d3b81*/
}

// Address: 0x1030d3b8e | Name: _Curl_bufq_init2
void __fastcall Curl_bufq_init2(__int64 a1, __int64 a2, __int64 a3, int a4)
{
  *(_OWORD *)(a1 + 48) = 0; /*0x1030d3b95*/
  *(_OWORD *)(a1 + 32) = 0; /*0x1030d3b99*/
  *(_OWORD *)(a1 + 16) = 0; /*0x1030d3b9d*/
  *(_OWORD *)a1 = 0; /*0x1030d3ba1*/
  *(_QWORD *)(a1 + 48) = a2; /*0x1030d3ba4*/
  *(_QWORD *)(a1 + 40) = a3; /*0x1030d3ba8*/
  *(_QWORD *)(a1 + 24) = 0; /*0x1030d3bac*/
  *(_DWORD *)(a1 + 56) = a4; /*0x1030d3bb4*/
}

// Address: 0x1030d3bb9 | Name: _Curl_bufq_init
void __fastcall Curl_bufq_init(__int64 a1, __int64 a2, __int64 a3)
{
  *(_OWORD *)(a1 + 48) = 0; /*0x1030d3bc0*/
  *(_OWORD *)(a1 + 32) = 0; /*0x1030d3bc4*/
  *(_OWORD *)(a1 + 16) = 0; /*0x1030d3bc8*/
  *(_OWORD *)a1 = 0; /*0x1030d3bcc*/
  *(_QWORD *)(a1 + 48) = a2; /*0x1030d3bcf*/
  *(_QWORD *)(a1 + 40) = a3; /*0x1030d3bd3*/
  *(_QWORD *)(a1 + 24) = 0; /*0x1030d3bd7*/
  *(_DWORD *)(a1 + 56) = 0; /*0x1030d3bdf*/
}

// Address: 0x1030d3be8 | Name: _Curl_bufq_initp
__int64 __fastcall Curl_bufq_initp(__int64 a1, __int64 a2, __int64 a3, int a4)
{
  __int64 result; // rax

  result = *(_QWORD *)(a2 + 8); /*0x1030d3bec*/
  *(_OWORD *)(a1 + 48) = 0; /*0x1030d3bf3*/
  *(_OWORD *)(a1 + 32) = 0; /*0x1030d3bf7*/
  *(_OWORD *)(a1 + 16) = 0; /*0x1030d3bfb*/
  *(_OWORD *)a1 = 0; /*0x1030d3bff*/
  *(_QWORD *)(a1 + 48) = result; /*0x1030d3c02*/
  *(_QWORD *)(a1 + 40) = a3; /*0x1030d3c06*/
  *(_QWORD *)(a1 + 24) = a2; /*0x1030d3c0a*/
  *(_DWORD *)(a1 + 56) = a4; /*0x1030d3c0e*/
  return result; /*0x1030d3c11*/
}

// Address: 0x1030d3c13 | Name: _Curl_bufq_free
__int64 __fastcall Curl_bufq_free(__int64 a1)
{
  _QWORD *v2; // rdi
  _QWORD *i; // rdi

  v2 = *(_QWORD **)a1; /*0x1030d3c1d*/
  if ( v2 != nullptr ) /*0x1030d3c23*/
  {
    do /*0x1030d3c3b*/
    {
      *(_QWORD *)a1 = *v2; /*0x1030d3c2f*/
      Curl_cfree(a1: v2); /*0x1030d3c32*/
      v2 = *(_QWORD **)a1; /*0x1030d3c35*/
    }
    while ( *(_QWORD *)a1 != 0 ); /*0x1030d3c3b*/
  }
  for ( i = *(_QWORD **)(a1 + 16); i != nullptr; i = *(_QWORD **)(a1 + 16) ) /*0x1030d3c44*/
  {
    *(_QWORD *)(a1 + 16) = *i; /*0x1030d3c50*/
    Curl_cfree(a1: i); /*0x1030d3c54*/
  }
  *(_QWORD *)(a1 + 8) = 0; /*0x1030d3c62*/
  *(_QWORD *)(a1 + 32) = 0; /*0x1030d3c66*/
  return 0; /*0x1030d3c6a*/
}

// Address: 0x1030d3c6f | Name: _Curl_bufq_reset
_QWORD *__fastcall Curl_bufq_reset(__int64 a1)
{
  _QWORD *result; // rax
  _QWORD *v2; // rdx
  _QWORD *v3; // rcx

  result = *(_QWORD **)a1; /*0x1030d3c6f*/
  if ( *(_QWORD *)a1 != 0 ) /*0x1030d3c75*/
  {
    v2 = *(_QWORD **)(a1 + 16); /*0x1030d3c7b*/
    do /*0x1030d3c8e*/
    {
      v3 = result; /*0x1030d3c7f*/
      result = (_QWORD *)*result; /*0x1030d3c82*/
      *v3 = v2; /*0x1030d3c85*/
      v2 = v3; /*0x1030d3c88*/
    }
    while ( result != nullptr ); /*0x1030d3c8e*/
    *(_QWORD *)a1 = 0; /*0x1030d3c90*/
    *(_QWORD *)(a1 + 16) = v3; /*0x1030d3c97*/
  }
  *(_QWORD *)(a1 + 8) = 0; /*0x1030d3c9c*/
  return result; /*0x1030d3ca4*/
}

// Address: 0x1030d3ca5 | Name: _Curl_bufq_len
__int64 __fastcall Curl_bufq_len(_QWORD *a1)
{
  _QWORD *v1; // rcx
  __int64 result; // rax

  v1 = (_QWORD *)*a1; /*0x1030d3ca5*/
  if ( *a1 == 0 ) /*0x1030d3cab*/
    return 0; /*0x1030d3cc5*/
  result = 0; /*0x1030d3cb1*/
  do /*0x1030d3cc1*/
  {
    result = v1[3] + result - v1[2]; /*0x1030d3cb7*/
    v1 = (_QWORD *)*v1; /*0x1030d3cbb*/
  }
  while ( v1 != nullptr ); /*0x1030d3cc1*/
  return result; /*0x1030d3cc4*/
}

// Address: 0x1030d3cc8 | Name: _Curl_bufq_is_empty
bool __fastcall Curl_bufq_is_empty(__int64 a1)
{
  return *(_QWORD *)a1 == 0 || *(_QWORD *)(*(_QWORD *)a1 + 16LL) >= *(_QWORD *)(*(_QWORD *)a1 + 24LL); /*0x1030d3ce0*/
}

// Address: 0x1030d3ce4 | Name: _Curl_bufq_is_full
bool __fastcall Curl_bufq_is_full(_QWORD *a1)
{
  __int64 v1; // rcx
  unsigned __int64 v2; // rax
  bool v3; // cc
  bool result; // al

  v1 = a1[1]; /*0x1030d3ce4*/
  if ( v1 == 0 ) /*0x1030d3ceb*/
    return false; /*0x1030d3ceb*/
  if ( a1[2] != 0 ) /*0x1030d3cf2*/
    return false; /*0x1030d3cf2*/
  v2 = a1[5]; /*0x1030d3cf4*/
  v3 = a1[4] <= v2; /*0x1030d3cf8*/
  if ( a1[4] < v2 ) /*0x1030d3cfc*/
    return false; /*0x1030d3cfe*/
  result = true; /*0x1030d3d01*/
  if ( v3 ) /*0x1030d3d03*/
    return *(_QWORD *)(v1 + 24) >= *(_QWORD *)(v1 + 8); /*0x1030d3d11*/
  return result; /*0x1030d3d00*/
}

// Address: 0x1030d3d16 | Name: _Curl_bufq_write
__int64 __fastcall Curl_bufq_write(__int64 a1, char *a2, size_t a3, _QWORD *a4)
{
  size_t v4; // r15
  __int64 non_full_tail; // rax
  __int64 v8; // r13
  __int64 v9; // rbx
  __int64 v10; // rax
  size_t v11; // rbx
  __int64 result; // rax
  bool v14; // [rsp+14h] [rbp-2Ch]

  *a4 = 0; /*0x1030d3d2b*/
  if ( a3 == 0 ) /*0x1030d3d35*/
  {
    v14 = false; /*0x1030d3d92*/
LABEL_10:
    result = 81; /*0x1030d3d99*/
    if ( *a4 != 0 ) /*0x1030d3dab*/
      result = 0; /*0x1030d3dab*/
    if ( !v14 ) /*0x1030d3db2*/
      return 0; /*0x1030d3db2*/
    return result; /*0x1030d3db2*/
  }
  v4 = a3; /*0x1030d3d37*/
  while ( 1 ) /*0x1030d3d43*/
  {
    non_full_tail = get_non_full_tail(a1); /*0x1030d3d43*/
    if ( non_full_tail == 0 ) /*0x1030d3d4b*/
      break; /*0x1030d3d4b*/
    v8 = non_full_tail; /*0x1030d3d4d*/
    v9 = *(_QWORD *)(non_full_tail + 8); /*0x1030d3d50*/
    v10 = *(_QWORD *)(non_full_tail + 24); /*0x1030d3d54*/
    v11 = v9 - v10; /*0x1030d3d58*/
    v14 = v11 == 0; /*0x1030d3d5e*/
    if ( v11 != 0 ) /*0x1030d3d61*/
    {
      if ( v11 >= v4 ) /*0x1030d3d6e*/
        v11 = v4; /*0x1030d3d6e*/
      memcpy(__dst: (void *)(v10 + v8 + 32), __src: a2, __n: v11); /*0x1030d3d78*/
      *(_QWORD *)(v8 + 24) += v11; /*0x1030d3d7d*/
      *a4 += v11; /*0x1030d3d85*/
      a2 += v11; /*0x1030d3d88*/
      v4 -= v11; /*0x1030d3d8b*/
      if ( v4 != 0 ) /*0x1030d3d8e*/
        continue; /*0x1030d3d8e*/
    }
    goto LABEL_10; /*0x1030d3d8e*/
  }
  result = 27; /*0x1030d3dc8*/
  if ( *(_QWORD *)(a1 + 32) >= *(_QWORD *)(a1 + 40) ) /*0x1030d3dd1*/
  {
    v14 = true; /*0x1030d3dd5*/
    if ( (*(_BYTE *)(a1 + 56) & 1) == 0 ) /*0x1030d3ddd*/
      goto LABEL_10; /*0x1030d3ddd*/
  }
  return result; /*0x1030d3db5*/
}

// Address: 0x1030d3edd | Name: _Curl_bufq_cwrite
__int64 __fastcall Curl_bufq_cwrite(__int64 a1, char *a2, size_t a3, _QWORD *a4)
{
  return Curl_bufq_write(a1, a2, a3, a4); /*0x1030d3ee1*/
}

// Address: 0x1030d3ee7 | Name: _Curl_bufq_read
__int64 __fastcall Curl_bufq_read(__int64 *a1, char *a2, size_t a3, _QWORD *a4)
{
  size_t v4; // r14
  __int64 v7; // rbx
  __int64 v8; // rax
  size_t v9; // r13
  const void *v10; // rsi
  _OWORD *v11; // rbx
  __int64 result; // rax

  *a4 = 0; /*0x1030d3ef9*/
  if ( a3 == 0 ) /*0x1030d3f03*/
    return 81; /*0x1030d3f84*/
  v4 = a3; /*0x1030d3f05*/
  do /*0x1030d3f6e*/
  {
    v7 = *a1; /*0x1030d3f0e*/
    if ( *a1 == 0 ) /*0x1030d3f15*/
      break; /*0x1030d3f15*/
    v8 = *(_QWORD *)(v7 + 16); /*0x1030d3f17*/
    v9 = *(_QWORD *)(v7 + 24) - v8; /*0x1030d3f1f*/
    if ( v9 != 0 ) /*0x1030d3f22*/
    {
      v10 = (const void *)(v7 + v8 + 32); /*0x1030d3f28*/
      v11 = (_OWORD *)(v7 + 16); /*0x1030d3f2c*/
      if ( v9 <= v4 ) /*0x1030d3f36*/
      {
        memcpy(__dst: a2, __src: v10, __n: v9); /*0x1030d3f4b*/
        *v11 = 0; /*0x1030d3f53*/
      }
      else
      {
        memcpy(__dst: a2, __src: v10, __n: v4); /*0x1030d3f3b*/
        *(_QWORD *)v11 += v4; /*0x1030d3f40*/
        v9 = v4; /*0x1030d3f43*/
      }
      *a4 += v9; /*0x1030d3f5a*/
      a2 += v9; /*0x1030d3f5d*/
      v4 -= v9; /*0x1030d3f60*/
    }
    prune_head(a1); /*0x1030d3f66*/
  }
  while ( v4 != 0 ); /*0x1030d3f6e*/
  result = 81; /*0x1030d3f7a*/
  if ( *a4 != 0 ) /*0x1030d3f7f*/
    return 0; /*0x1030d3f7f*/
  return result; /*0x1030d3f8d*/
}

// Address: 0x1030d4028 | Name: _Curl_bufq_cread
__int64 __fastcall Curl_bufq_cread(__int64 *a1, char *a2, size_t a3, _QWORD *a4)
{
  return Curl_bufq_read(a1, a2, a3, a4); /*0x1030d402c*/
}

// Address: 0x1030d4032 | Name: _Curl_bufq_peek
char __fastcall Curl_bufq_peek(__int64 *a1, _QWORD *a2, unsigned __int64 *a3)
{
  __int64 v5; // rax
  unsigned __int64 v7; // rdx
  unsigned __int64 v8; // rcx
  bool v9; // cc
  unsigned __int64 v10; // rcx
  char result; // al

  v5 = *a1; /*0x1030d4042*/
  if ( *a1 != 0 /*0x1030d406f*/
    && (*(_QWORD *)(v5 + 16) < *(_QWORD *)(v5 + 24) || (prune_head(a1), v5 = *a1, *a1 != 0))
    && (v7 = *(_QWORD *)(v5 + 16), v8 = *(_QWORD *)(v5 + 24), v9 = v8 <= v7, v10 = v8 - v7, !v9) )
  {
    *a2 = v7 + v5 + 32; /*0x1030d4078*/
    result = 1; /*0x1030d407b*/
  }
  else
  {
    *a2 = 0; /*0x1030d407f*/
    v10 = 0; /*0x1030d4086*/
    result = 0; /*0x1030d4088*/
  }
  *a3 = v10; /*0x1030d408a*/
  return result; /*0x1030d4091*/
}

// Address: 0x1030d4098 | Name: _Curl_bufq_peek_at
char __fastcall Curl_bufq_peek_at(_QWORD *a1, unsigned __int64 a2, _QWORD *a3, _QWORD *a4)
{
  _QWORD *v4; // rax
  __int64 v5; // r8
  __int64 v6; // rdi
  unsigned __int64 v7; // r10
  __int64 v8; // rdi
  char result; // al
  __int64 v10; // r8

  v4 = (_QWORD *)*a1; /*0x1030d409c*/
  while ( 1 ) /*0x1030d409f*/
  {
    if ( v4 == nullptr || (v5 = v4[2], v6 = v4[3], v7 = v6 - v5, v6 == v5) ) /*0x1030d40af*/
    {
      *a3 = 0; /*0x1030d40c4*/
      v8 = 0; /*0x1030d40cb*/
      result = 0; /*0x1030d40cd*/
      goto LABEL_8; /*0x1030d40cf*/
    }
    if ( a2 < v7 ) /*0x1030d40ba*/
      break; /*0x1030d40ba*/
    v4 = (_QWORD *)*v4; /*0x1030d40bc*/
    a2 -= v7; /*0x1030d40bf*/
  }
  v10 = a2 + v5; /*0x1030d40d1*/
  *a3 = (char *)v4 + v10 + 32; /*0x1030d40db*/
  v8 = v6 - v10; /*0x1030d40de*/
  result = 1; /*0x1030d40e1*/
LABEL_8:
  *a4 = v8; /*0x1030d40e3*/
  return result; /*0x1030d40e6*/
}

// Address: 0x1030d40e8 | Name: _Curl_bufq_skip
__int64 __fastcall Curl_bufq_skip(__int64 *a1, unsigned __int64 a2)
{
  __int64 result; // rax
  unsigned __int64 i; // rbx
  __int64 v5; // rcx
  __int64 v6; // rdx
  unsigned __int64 v7; // r15
  _QWORD *v8; // rax
  __int64 v9; // rcx

  if ( a2 != 0 ) /*0x1030d40eb*/
  {
    for ( i = a2; i != 0; i -= v7 ) /*0x1030d40f7*/
    {
      result = *a1; /*0x1030d40fd*/
      if ( *a1 == 0 ) /*0x1030d4103*/
        break; /*0x1030d4103*/
      v5 = *(_QWORD *)(result + 16); /*0x1030d4105*/
      v6 = *(_QWORD *)(result + 24); /*0x1030d4109*/
      v7 = v6 - v5; /*0x1030d4110*/
      if ( v6 == v5 ) /*0x1030d4110*/
      {
        v7 = 0; /*0x1030d4115*/
      }
      else
      {
        v8 = (_QWORD *)(result + 16); /*0x1030d411a*/
        if ( v7 >= i ) /*0x1030d4121*/
          v7 = i; /*0x1030d4121*/
        v9 = v7 + v5; /*0x1030d4125*/
        *v8 = v9; /*0x1030d4128*/
        if ( v9 == v6 ) /*0x1030d412e*/
          *(_OWORD *)v8 = 0; /*0x1030d4133*/
      }
      result = prune_head(a1); /*0x1030d4139*/
    }
  }
  return result; /*0x1030d414d*/
}

// Address: 0x1030d414e | Name: _Curl_bufq_pass
__int64 __fastcall Curl_bufq_pass(
        __int64 *a1,
        __int64 (__fastcall *a2)(__int64, __int64, unsigned __int64, unsigned __int64 *),
        __int64 a3,
        __int64 *a4)
{
  char v8; // al
  unsigned int v9; // edx
  unsigned int v10; // eax
  unsigned __int64 v11; // rsi
  __int64 v12; // rax
  unsigned __int64 v14; // [rsp+0h] [rbp-40h] BYREF
  __int64 v15; // [rsp+8h] [rbp-38h] BYREF
  unsigned __int64 v16[6]; // [rsp+10h] [rbp-30h] BYREF

  *a4 = 0; /*0x1030d416b*/
  v8 = Curl_bufq_peek(a1, a2: &v15, a3: v16); /*0x1030d417a*/
  v9 = 0; /*0x1030d417f*/
  if ( v8 != 0 ) /*0x1030d4183*/
  {
    while ( 1 ) /*0x1030d4197*/
    {
      v10 = a2(a1: a3, a2: v15, a3: v16[0], a4: &v14); /*0x1030d4197*/
      if ( v10 != 0 ) /*0x1030d419c*/
        break; /*0x1030d419c*/
      v11 = v14; /*0x1030d419e*/
      v12 = *a4; /*0x1030d41a2*/
      if ( v14 == 0 ) /*0x1030d41a8*/
      {
        v9 = 81; /*0x1030d41ee*/
        if ( v12 != 0 ) /*0x1030d41f3*/
          return 0; /*0x1030d41f3*/
        return v9; /*0x1030d41f3*/
      }
      *a4 = v14 + v12; /*0x1030d41ad*/
      Curl_bufq_skip(a1, a2: v11); /*0x1030d41b3*/
      if ( Curl_bufq_peek(a1, a2: &v15, a3: v16) == 0 ) /*0x1030d41ca*/
        return 0; /*0x1030d41ce*/
    }
    if ( v10 == 81 ) /*0x1030d41d3*/
    {
      v9 = 81; /*0x1030d41db*/
      if ( *a4 != 0 ) /*0x1030d41e0*/
        return 0; /*0x1030d41e0*/
    }
    else
    {
      return v10; /*0x1030d41e5*/
    }
  }
  return v9; /*0x1030d41f8*/
}

// Address: 0x1030d4207 | Name: _Curl_bufq_write_pass
__int64 __fastcall Curl_bufq_write_pass(
        __int64 *a1,
        char *a2,
        size_t a3,
        __int64 (__fastcall *a4)(__int64, __int64, unsigned __int64, unsigned __int64 *),
        __int64 a5,
        __int64 *a6)
{
  size_t v7; // r12
  __int64 v10; // rax
  unsigned __int64 v11; // rcx
  __int64 result; // rax
  __int64 v13; // rdx
  __int64 v14; // rax
  bool v15; // cl
  bool v16; // zf
  __int64 v17; // [rsp+0h] [rbp-40h] BYREF
  __int64 v18; // [rsp+8h] [rbp-38h]
  __int64 (__fastcall *v19)(__int64, __int64, unsigned __int64, unsigned __int64 *); // [rsp+10h] [rbp-30h]

  v18 = a5; /*0x1030d4218*/
  v19 = a4; /*0x1030d421c*/
  *a6 = 0; /*0x1030d4220*/
  if ( a3 == 0 ) /*0x1030d422a*/
    return 0; /*0x1030d42c3*/
  v7 = a3; /*0x1030d4233*/
  while ( 1 ) /*0x1030d4240*/
  {
    v10 = a1[1]; /*0x1030d4240*/
    if ( v10 != 0 && a1[2] == 0 ) /*0x1030d424e*/
    {
      v11 = a1[5]; /*0x1030d4250*/
      if ( a1[4] >= v11 && (a1[4] > v11 || *(_QWORD *)(v10 + 24) >= *(_QWORD *)(v10 + 8)) ) /*0x1030d4264*/
      {
        result = Curl_bufq_pass(a1, a2: v19, a3: v18, a4: &v17); /*0x1030d4274*/
        if ( (_DWORD)result != 0 ) /*0x1030d427b*/
        {
          if ( (_DWORD)result != 81 ) /*0x1030d42ec*/
            return result; /*0x1030d42ec*/
          v14 = *a6; /*0x1030d42ee*/
          v15 = true; /*0x1030d42f1*/
LABEL_12:
          v16 = v14 == 0; /*0x1030d42af*/
          result = 81; /*0x1030d42b4*/
          if ( !v16 ) /*0x1030d42b9*/
            result = 0; /*0x1030d42b9*/
          if ( !v15 ) /*0x1030d42be*/
            return 0; /*0x1030d42be*/
          return result; /*0x1030d42be*/
        }
      }
    }
    result = Curl_bufq_write((__int64)a1, a2, a3: v7, a4: &v17); /*0x1030d4289*/
    if ( (_DWORD)result != 0 ) /*0x1030d4290*/
      break; /*0x1030d4290*/
    v13 = v17; /*0x1030d4292*/
    v14 = *a6; /*0x1030d4296*/
    v15 = v17 == 0; /*0x1030d429c*/
    if ( v17 != 0 ) /*0x1030d429f*/
    {
      a2 += v17; /*0x1030d42a1*/
      v14 += v17; /*0x1030d42a4*/
      *a6 = v14; /*0x1030d42a7*/
      v7 -= v13; /*0x1030d42aa*/
      if ( v7 != 0 ) /*0x1030d42ad*/
        continue; /*0x1030d42ad*/
    }
    goto LABEL_12; /*0x1030d42ad*/
  }
  if ( (_DWORD)result == 81 ) /*0x1030d42ca*/
  {
    result = 81; /*0x1030d42d2*/
    if ( *a6 != 0 ) /*0x1030d42d7*/
      return 0; /*0x1030d42d7*/
  }
  return result; /*0x1030d42da*/
}

// Address: 0x1030d42f5 | Name: _Curl_bufq_sipn
__int64 __fastcall Curl_bufq_sipn(
        __int64 a1,
        unsigned __int64 a2,
        __int64 (__fastcall *a3)(__int64, __int64, unsigned __int64, _QWORD *),
        __int64 a4,
        _QWORD *a5)
{
  __int64 non_full_tail; // rax
  __int64 v10; // r14
  __int64 v11; // rcx
  __int64 v12; // rsi
  __int64 result; // rax
  unsigned __int64 v14; // rcx
  unsigned __int64 v15; // rdx
  __int64 v16; // rsi

  *a5 = 0; /*0x1030d4313*/
  non_full_tail = get_non_full_tail(a1); /*0x1030d431a*/
  if ( non_full_tail != 0 ) /*0x1030d4322*/
  {
    v10 = non_full_tail; /*0x1030d4324*/
    v11 = *(_QWORD *)(non_full_tail + 8); /*0x1030d4327*/
    v12 = *(_QWORD *)(non_full_tail + 24); /*0x1030d432b*/
    *a5 = 0; /*0x1030d432f*/
    result = 81; /*0x1030d4336*/
    v14 = v11 - v12; /*0x1030d433b*/
    if ( v14 != 0 ) /*0x1030d433e*/
    {
      v15 = a2; /*0x1030d4343*/
      if ( v14 < a2 ) /*0x1030d4346*/
        v15 = v14; /*0x1030d4346*/
      v16 = v10 + v12 + 32; /*0x1030d434d*/
      if ( a2 == 0 ) /*0x1030d4354*/
        v15 = v14; /*0x1030d4354*/
      result = a3(a1: a4, a2: v16, a3: v15, a4: a5); /*0x1030d435e*/
      if ( (_DWORD)result == 0 ) /*0x1030d4363*/
      {
        *(_QWORD *)(v10 + 24) += *a5; /*0x1030d4368*/
        return 0; /*0x1030d436c*/
      }
    }
  }
  else
  {
    result = 81; /*0x1030d437d*/
    if ( *(_QWORD *)(a1 + 32) < *(_QWORD *)(a1 + 40) ) /*0x1030d4382*/
      return 27; /*0x1030d4382*/
  }
  return result; /*0x1030d4389*/
}

// Address: 0x1030d4394 | Name: _Curl_bufq_slurp
__int64 __fastcall Curl_bufq_slurp(
        __int64 a1,
        __int64 (__fastcall *a2)(__int64, __int64, unsigned __int64, _QWORD *),
        __int64 a3,
        _QWORD *a4)
{
  __int64 v4; // rax
  __int64 result; // rax
  __int64 v10; // rax
  _QWORD v11[6]; // [rsp+0h] [rbp-30h] BYREF

  v11[0] = v4; /*0x1030d43a1*/
  *a4 = 0; /*0x1030d43ae*/
  result = Curl_bufq_sipn(a1, a2: 0, a3: a2, a4: a3, a5: v11); /*0x1030d43c1*/
  if ( (_DWORD)result == 0 ) /*0x1030d43c8*/
  {
    while ( v11[0] != 0 ) /*0x1030d43f1*/
    {
      *a4 += v11[0]; /*0x1030d43f3*/
      v10 = *(_QWORD *)(a1 + 8); /*0x1030d43f6*/
      if ( v10 != 0 && *(_QWORD *)(v10 + 24) < *(_QWORD *)(v10 + 8) ) /*0x1030d4408*/
        break; /*0x1030d4408*/
      result = Curl_bufq_sipn(a1, a2: 0, a3: a2, a4: a3, a5: v11); /*0x1030d4418*/
      if ( (_DWORD)result != 0 ) /*0x1030d441f*/
        goto LABEL_2; /*0x1030d441f*/
    }
    return 0; /*0x1030d4408*/
  }
LABEL_2:
  if ( (_DWORD)result == 81 && *a4 != 0 ) /*0x1030d43d3*/
    return 0; /*0x1030d43d5*/
  return result; /*0x1030d43db*/
}

// Address: 0x1030d4423 | Name: _Curl_bufref_init
void __fastcall Curl_bufref_init(__int64 a1)
{
  *(_OWORD *)a1 = 0; /*0x1030d442a*/
  *(_QWORD *)(a1 + 16) = 0; /*0x1030d442d*/
}

// Address: 0x1030d4437 | Name: _Curl_bufref_free
__int64 (__fastcall *__fastcall Curl_bufref_free(__int64 a1))(__int64)
{
  __int64 (__fastcall *result)(__int64); // rax
  __int64 v3; // rdi

  v3 = *(_QWORD *)(a1 + 8); /*0x1030d4440*/
  if ( v3 != 0 ) /*0x1030d4447*/
  {
    result = *(__int64 (__fastcall **)(__int64))a1; /*0x1030d4449*/
    if ( *(_QWORD *)a1 != 0 ) /*0x1030d444f*/
      result = (__int64 (__fastcall *)(__int64))result(a1: v3); /*0x1030d4451*/
  }
  *(_OWORD *)a1 = 0; /*0x1030d4456*/
  *(_QWORD *)(a1 + 16) = 0; /*0x1030d4459*/
  return result; /*0x1030d4465*/
}

// Address: 0x1030d4468 | Name: _Curl_bufref_set
void __fastcall Curl_bufref_set(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  if ( *(_QWORD *)(a1 + 8) != 0 && *(_QWORD *)a1 != 0 ) /*0x1030d448e*/
    (*(void (**)(void))a1)(); /*0x1030d4490*/
  *(_QWORD *)(a1 + 8) = a2; /*0x1030d4492*/
  *(_QWORD *)(a1 + 16) = a3; /*0x1030d4496*/
  *(_QWORD *)a1 = a4; /*0x1030d449a*/
}

// Address: 0x1030d44a6 | Name: _Curl_bufref_uptr
__int64 __fastcall Curl_bufref_uptr(__int64 a1)
{
  return *(_QWORD *)(a1 + 8); /*0x1030d44ae*/
}

// Address: 0x1030d44b0 | Name: _Curl_bufref_ptr
__int64 __fastcall Curl_bufref_ptr(__int64 a1)
{
  return *(_QWORD *)(a1 + 8); /*0x1030d44b8*/
}

// Address: 0x1030d44ba | Name: _Curl_bufref_len
__int64 __fastcall Curl_bufref_len(__int64 a1)
{
  return *(_QWORD *)(a1 + 16); /*0x1030d44c2*/
}

// Address: 0x1030d44c4 | Name: _Curl_bufref_memdup0
__int64 __fastcall Curl_bufref_memdup0(__int64 a1, void *a2, size_t a3)
{
  __int64 v5; // r15
  __int64 v7; // rdi

  if ( a2 != nullptr ) /*0x1030d44d7*/
  {
    v5 = curlx_memdup0(__src: a2, __n: a3); /*0x1030d44e4*/
    if ( v5 == 0 ) /*0x1030d44ea*/
      return 27; /*0x1030d44f1*/
  }
  else
  {
    v5 = 0; /*0x1030d44f3*/
  }
  v7 = *(_QWORD *)(a1 + 8); /*0x1030d44f6*/
  if ( v7 != 0 && *(_QWORD *)a1 != 0 ) /*0x1030d4505*/
    (*(void (__fastcall **)(__int64))a1)(a1: v7); /*0x1030d4507*/
  *(_QWORD *)(a1 + 8) = v5; /*0x1030d4509*/
  *(_QWORD *)(a1 + 16) = a3; /*0x1030d450d*/
  *(_QWORD *)a1 = curl_free; /*0x1030d4518*/
  return 0; /*0x1030d4521*/
}

// Address: 0x1030d4528 | Name: _cf_h1_proxy_destroy
__int64 cf_h1_proxy_destroy()
{
  return tunnel_free(); /*0x1030d452c*/
}

// Address: 0x1030d4532 | Name: _cf_h1_proxy_connect
__int64 __fastcall cf_h1_proxy_connect(__int64 a1, __int64 a2, bool *a3)
{
  char *v6; // r12
  unsigned int v7; // r14d
  int v8; // eax
  unsigned int v9; // r15d
  __int64 v11; // rax
  char *v12; // rax
  unsigned int v13; // eax
  char *v14; // r15
  char *v15; // r15
  unsigned __int64 v16; // r8
  unsigned __int64 v17; // rcx
  __int64 v18; // rdx
  __int64 *v19; // rdi
  __int64 v20; // rax
  unsigned int v21; // eax
  __int64 v22; // rcx
  __int64 v23; // rdx
  __int64 v24; // rcx
  unsigned int v25; // eax
  __int64 v26; // rax
  char v27; // al
  char v28; // al
  unsigned int v29; // eax
  unsigned __int8 *v30; // r15
  int v31; // eax
  unsigned int v32; // eax
  char v33; // al
  char v34; // r12
  unsigned int v35; // eax
  bool v36; // zf
  __int64 v37; // rax
  __int64 v38; // [rsp+8h] [rbp-88h] BYREF
  __int64 v39; // [rsp+10h] [rbp-80h]
  __int64 v40; // [rsp+18h] [rbp-78h]
  char *v41; // [rsp+20h] [rbp-70h]
  char *v42; // [rsp+28h] [rbp-68h]
  unsigned __int64 v43; // [rsp+30h] [rbp-60h]
  __int64 v44; // [rsp+38h] [rbp-58h]
  bool *v45; // [rsp+40h] [rbp-50h]
  _OWORD *v46; // [rsp+48h] [rbp-48h]
  __int64 v47; // [rsp+50h] [rbp-40h]
  __int64 v48; // [rsp+58h] [rbp-38h] BYREF
  char v49; // [rsp+66h] [rbp-2Ah] BYREF
  char v50[41]; // [rsp+67h] [rbp-29h] BYREF

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d454a*/
  {
    *a3 = true; /*0x1030d45ad*/
    return 0; /*0x1030d45b1*/
  }
  v6 = *(char **)(a1 + 16); /*0x1030d4552*/
  v7 = (*(__int64 (__fastcall **)(_QWORD, __int64, bool *))(**(_QWORD **)(a1 + 8) + 24LL))( /*0x1030d4563*/
         a1: *(_QWORD *)(a1 + 8),
         a2,
         a3);
  if ( v7 == 0 ) /*0x1030d4568*/
  {
    v7 = 0; /*0x1030d456a*/
    if ( *a3 ) /*0x1030d456d*/
    {
      *a3 = false; /*0x1030d4573*/
      if ( v6 != nullptr ) /*0x1030d457a*/
      {
        v45 = a3; /*0x1030d457c*/
        v8 = *((_DWORD *)v6 + 42); /*0x1030d4580*/
        if ( v8 == 4 ) /*0x1030d458b*/
          goto LABEL_98; /*0x1030d458b*/
        v9 = 56; /*0x1030d4591*/
        if ( v8 == 5 ) /*0x1030d459a*/
          goto LABEL_107; /*0x1030d459a*/
        v44 = a1 + 24; /*0x1030d45a4*/
      }
      else
      {
        v11 = *(_QWORD *)(*(_QWORD *)(a1 + 24) + 736LL); /*0x1030d45ca*/
        if ( (*(_BYTE *)(v11 + 33) & 0x40) != 0 ) /*0x1030d45d5*/
        {
          Curl_failf(a1: a2, a2: "%s cannot be done over CONNECT", *(const char **)v11); /*0x1030d4b8a*/
          return 1; /*0x1030d4b95*/
        }
        v12 = (char *)Curl_ccalloc(__count: 1u, __size: 0xB0u); /*0x1030d45ec*/
        if ( v12 == nullptr ) /*0x1030d45f1*/
          return 27; /*0x1030d4bb8*/
        v6 = v12; /*0x1030d45f7*/
        v45 = a3; /*0x1030d45fa*/
        v44 = a1 + 24; /*0x1030d4602*/
        curlx_dyn_init(a1: v12, a2: 0x4000); /*0x1030d460e*/
        curlx_dyn_init(a1: v6 + 32, a2: 0x100000); /*0x1030d4620*/
        Curl_httpchunk_init(a1: a2, a2: v6 + 80, a3: 1); /*0x1030d4634*/
        curlx_dyn_reset(a1: v6); /*0x1030d463c*/
        curlx_dyn_reset(a1: v6 + 32); /*0x1030d4644*/
        *((_DWORD *)v6 + 42) = 0; /*0x1030d4649*/
        *((_DWORD *)v6 + 38) = 1; /*0x1030d4655*/
        *((_QWORD *)v6 + 20) = 0; /*0x1030d4661*/
        v6[172] &= 0xF1u; /*0x1030d466d*/
        *(_QWORD *)(a1 + 16) = v6; /*0x1030d4676*/
      }
      v40 = *(_QWORD *)(a1 + 24); /*0x1030d467e*/
      v41 = v6 + 32; /*0x1030d4687*/
      v46 = v6 + 64; /*0x1030d4690*/
      v39 = a2 + 176; /*0x1030d46a0*/
      v42 = v6 + 80; /*0x1030d46a4*/
LABEL_14:
      if ( Curl_timeleft_ms(a1: a2) < 0 ) /*0x1030d46b3*/
      {
        Curl_failf(a1: a2, a2: "Proxy CONNECT aborted due to timeout"); /*0x1030d4c8e*/
        v9 = 28; /*0x1030d4c93*/
        goto LABEL_106; /*0x1030d4c99*/
      }
      switch ( *((_DWORD *)v6 + 42) ) /*0x1030d46d9*/
      {
        case 0: /*0x1030d46d9*/
          v48 = 0; /*0x1030d46de*/
          Curl_cfree(a1: *(void **)(a2 + 368)); /*0x1030d46f0*/
          *(_QWORD *)(a2 + 368) = 0; /*0x1030d46f2*/
          v13 = Curl_http_proxy_create_CONNECT(a1: &v48, a2: a1, a3: a2, a4: 1); /*0x1030d4708*/
          if ( v13 != 0 /*0x1030d4755*/
            || (v14 = v41,
                curlx_dyn_reset(a1: v41),
                *v46 = 0,
                (v13 = Curl_h1_req_write_head(a1: v48, a2: *(_BYTE *)(*(_QWORD *)v44 + 306LL) != 1, a3: v14)) != 0)
            || (v13 = Curl_creader_set_null(a1: a2)) != 0 )
          {
            v9 = v13; /*0x1030d475b*/
            Curl_failf(a1: a2, a2: "Failed sending CONNECT to proxy"); /*0x1030d476a*/
          }
          else
          {
            v9 = 0; /*0x1030d4b73*/
          }
          if ( v48 != 0 ) /*0x1030d4776*/
            Curl_http_req_free(); /*0x1030d4778*/
          if ( v9 != 0 ) /*0x1030d4780*/
            goto LABEL_106; /*0x1030d4780*/
          if ( *((_DWORD *)v6 + 42) != 1 ) /*0x1030d478f*/
          {
            *((_DWORD *)v6 + 42) = 1; /*0x1030d4796*/
            *((_DWORD *)v6 + 38) = 1; /*0x1030d479e*/
            curlx_dyn_reset(a1: v6); /*0x1030d47a9*/
          }
          goto LABEL_25; /*0x1030d47a9*/
        case 1: /*0x1030d46d9*/
LABEL_25:
          v15 = v41; /*0x1030d47ae*/
          v47 = curlx_dyn_uptr(a1: v41); /*0x1030d47ba*/
          v16 = curlx_dyn_len(a1: v15); /*0x1030d47c6*/
          v17 = v16 - *(_QWORD *)v46; /*0x1030d47d3*/
          if ( v16 <= *(_QWORD *)v46 ) /*0x1030d47d6*/
            goto LABEL_29; /*0x1030d47d6*/
          v18 = *(_QWORD *)v46 + v47; /*0x1030d47dc*/
          v19 = *(__int64 **)(a1 + 8); /*0x1030d47df*/
          v20 = *v19; /*0x1030d47e3*/
          v43 = v16; /*0x1030d47e9*/
          v47 = v18; /*0x1030d47ed*/
          v21 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64, unsigned __int64, _QWORD, __int64 *))(v20 + 64))( /*0x1030d47f8*/
                  a1: v19,
                  a2,
                  a3: v18,
                  a4: v17,
                  a5: 0,
                  a6: &v48);
          v16 = v43; /*0x1030d47fb*/
          if ( v21 != 81 ) /*0x1030d4802*/
          {
            v9 = v21; /*0x1030d4804*/
            v23 = v47; /*0x1030d4807*/
            if ( v21 != 0 ) /*0x1030d480d*/
            {
              Curl_failf(a1: a2, a2: "Failed sending CONNECT to proxy", v47, v22, v43); /*0x1030d4d40*/
              v50[0] = 0; /*0x1030d4d45*/
              goto LABEL_97; /*0x1030d4d49*/
            }
            v24 = v48; /*0x1030d4813*/
            *(_QWORD *)v46 += v48; /*0x1030d481b*/
            Curl_debug(a1: a2, a2: 2, a3: v23, a4: v24, a5: v16); /*0x1030d4826*/
            v16 = v43; /*0x1030d482b*/
          }
LABEL_29:
          if ( *(_QWORD *)v46 < v16 ) /*0x1030d4836*/
            goto LABEL_98; /*0x1030d4836*/
          if ( *((_DWORD *)v6 + 42) != 2 ) /*0x1030d4845*/
            *((_DWORD *)v6 + 42) = 2; /*0x1030d4847*/
LABEL_32:
          v50[0] = 0; /*0x1030d4853*/
          break; /*0x1030d4853*/
        case 2: /*0x1030d46d9*/
          goto LABEL_32;
        case 3: /*0x1030d46d9*/
          goto LABEL_84;
        default:
          goto LABEL_88;
      }
      while ( 1 ) /*0x1030d498d*/
      {
        while ( 1 ) /*0x1030d48ab*/
        {
          while ( 1 ) /*0x1030d4857*/
          {
            if ( *((_DWORD *)v6 + 38) == 0 ) /*0x1030d4860*/
              goto LABEL_72; /*0x1030d4860*/
            v25 = Curl_conn_recv(a1: a2, a2: *(unsigned int *)(a1 + 32), a3: &v49, a4: 1, a5: &v48); /*0x1030d487a*/
            if ( v25 != 0 ) /*0x1030d4881*/
            {
              v9 = 0; /*0x1030d4a39*/
              if ( v25 != 81 ) /*0x1030d4a3f*/
              {
LABEL_92:
                v9 = v25; /*0x1030d4b9a*/
                *((_DWORD *)v6 + 38) = 0; /*0x1030d4b9d*/
                v50[0] = 1; /*0x1030d4ba9*/
                goto LABEL_106; /*0x1030d4bad*/
              }
LABEL_78:
              v33 = 0; /*0x1030d4ad6*/
LABEL_79:
              if ( v9 != 0 ) /*0x1030d4adb*/
              {
LABEL_106:
                h1_tunnel_go_state(a1: v6, a2: 5, a3: a2); /*0x1030d4d15*/
                goto LABEL_107; /*0x1030d4d20*/
              }
              v47 = (__int64)v6; /*0x1030d4ae1*/
              v34 = v33; /*0x1030d4ae5*/
              v35 = Curl_pgrsUpdate(a1: a2); /*0x1030d4aeb*/
              if ( v35 != 0 ) /*0x1030d4af2*/
              {
                v9 = v35; /*0x1030d4ce0*/
                v6 = (char *)v47; /*0x1030d4ce3*/
                goto LABEL_106; /*0x1030d4ce7*/
              }
              v36 = v34 == 0; /*0x1030d4af8*/
              v6 = (char *)v47; /*0x1030d4afb*/
              if ( !v36 ) /*0x1030d4aff*/
                goto LABEL_82; /*0x1030d4aff*/
LABEL_98:
              Curl_cfree(a1: *(void **)(a2 + 4056)); /*0x1030d4c0a*/
              *(_QWORD *)(a2 + 4056) = 0; /*0x1030d4c1a*/
              v37 = *(_QWORD *)(a1 + 16); /*0x1030d4c25*/
              if ( v37 != 0 ) /*0x1030d4c2c*/
              {
                v36 = *(_DWORD *)(v37 + 168) == 4; /*0x1030d4c2e*/
                *v45 = v36; /*0x1030d4c39*/
                if ( v36 ) /*0x1030d4c3c*/
                {
                  *(_BYTE *)(a1 + 36) |= 1u; /*0x1030d4c42*/
                  Curl_req_soft_reset(a1: a2 + 176, a2); /*0x1030d4c51*/
                  Curl_client_reset(a1: a2); /*0x1030d4c59*/
                  Curl_pgrsReset(a1: a2); /*0x1030d4c61*/
                  tunnel_free(a1, a2); /*0x1030d4c6c*/
                }
              }
              else
              {
                *v45 = false; /*0x1030d4c7a*/
              }
              return v7; /*0x1030d4c71*/
            }
            v25 = Curl_pgrsUpdate(a1: a2); /*0x1030d488a*/
            if ( v25 != 0 ) /*0x1030d4891*/
              goto LABEL_92; /*0x1030d4891*/
            if ( v48 == 0 ) /*0x1030d489c*/
            {
              if ( *(_DWORD *)(a2 + 436) == 0 || *(_DWORD *)(a2 + 2528) == 0 || *(_QWORD *)(a2 + 4056) == 0 ) /*0x1030d4a6c*/
              {
                Curl_failf(a1: a2, a2: "Proxy CONNECT aborted"); /*0x1030d4cf5*/
                *((_DWORD *)v6 + 38) = 0; /*0x1030d4cfa*/
                v50[0] = 1; /*0x1030d4d06*/
                v9 = 56; /*0x1030d4d0a*/
                goto LABEL_106; /*0x1030d4d0a*/
              }
              v6[172] |= 2u; /*0x1030d4a72*/
LABEL_71:
              *((_DWORD *)v6 + 38) = 0; /*0x1030d4a7b*/
LABEL_72:
              v50[0] = 1; /*0x1030d4a87*/
              if ( (unsigned int)(*(_DWORD *)(a2 + 4100) - 200) >= 0x64 ) /*0x1030d4a9e*/
              {
                v9 = Curl_http_auth_act(a1: a2); /*0x1030d4ab3*/
                v33 = 1; /*0x1030d4ab6*/
                goto LABEL_79; /*0x1030d4ab8*/
              }
              v32 = Curl_pgrsUpdate(a1: a2); /*0x1030d4aa0*/
              if ( v32 != 0 ) /*0x1030d4aa7*/
              {
                v9 = v32; /*0x1030d4d12*/
                goto LABEL_106; /*0x1030d4aa9*/
              }
LABEL_82:
              if ( *((_DWORD *)v6 + 42) != 3 ) /*0x1030d4b0e*/
                *((_DWORD *)v6 + 42) = 3; /*0x1030d4b10*/
LABEL_84:
              if ( *(_QWORD *)(a2 + 368) == 0 ) /*0x1030d4b24*/
              {
LABEL_94:
                if ( (unsigned int)(*(_DWORD *)(a2 + 4100) - 200) < 0x64 ) /*0x1030d4bcb*/
                {
                  h1_tunnel_go_state(a1: v6, a2: 4, a3: a2); /*0x1030d4bdc*/
                  goto LABEL_98; /*0x1030d4be1*/
                }
                Curl_cfree(a1: nullptr); /*0x1030d4ca4*/
                *(_QWORD *)(a2 + 368) = 0; /*0x1030d4ca6*/
                h1_tunnel_go_state(a1: v6, a2: 5, a3: a2); /*0x1030d4cbc*/
                Curl_failf(a1: a2, a2: "CONNECT tunnel failed, response %d", *(_DWORD *)(a2 + 248)); /*0x1030d4cd3*/
                v9 = 56; /*0x1030d4cd8*/
LABEL_107:
                *v45 = false; /*0x1030d4d25*/
                return v9; /*0x1030d4d2f*/
              }
              Curl_req_soft_reset(a1: v39, a2); /*0x1030d4b31*/
              if ( (v6[172] & 2) != 0 || (*(_BYTE *)(v40 + 728) & 0x20) != 0 ) /*0x1030d4b50*/
              {
                Curl_conn_cf_close(a1, a2); /*0x1030d4be9*/
                v9 = Curl_conn_cf_connect(a1: *(_QWORD *)(a1 + 8), a2, a3: v50); /*0x1030d4bfe*/
LABEL_97:
                if ( v9 == 0 ) /*0x1030d4c04*/
                  goto LABEL_98; /*0x1030d4c04*/
                goto LABEL_106; /*0x1030d4c04*/
              }
              h1_tunnel_go_state(a1: v6, a2: 0, a3: a2); /*0x1030d4b5e*/
LABEL_88:
              if ( *(_QWORD *)(a2 + 368) == 0 ) /*0x1030d4b6b*/
                goto LABEL_94; /*0x1030d4b6b*/
              goto LABEL_14; /*0x1030d4b6b*/
            }
            if ( *((_DWORD *)v6 + 38) != 2 ) /*0x1030d48ab*/
              break; /*0x1030d48ab*/
            v26 = *((_QWORD *)v6 + 20); /*0x1030d48ad*/
            if ( v26 != 0 ) /*0x1030d48b8*/
            {
              *((_QWORD *)v6 + 20) = v26 - 1; /*0x1030d48be*/
              if ( v26 <= 1 ) /*0x1030d48ca*/
                goto LABEL_71; /*0x1030d48ca*/
            }
            else if ( (v6[172] & 1) != 0 ) /*0x1030d490c*/
            {
              v38 = 0; /*0x1030d4912*/
              v29 = Curl_httpchunk_read(a1: a2, a2: v42, a3: &v49, a4: 1, a5: &v38); /*0x1030d4934*/
              if ( v29 != 0 ) /*0x1030d493b*/
                goto LABEL_77; /*0x1030d493b*/
              if ( (unsigned __int8)Curl_httpchunk_is_done(a1: a2, a2: v42) != 0 ) /*0x1030d494f*/
                *((_DWORD *)v6 + 38) = 0; /*0x1030d4955*/
            }
          }
          v27 = v6[172]; /*0x1030d48d1*/
          if ( (v27 & 4) != 0 ) /*0x1030d48db*/
          {
            if ( v49 == 32 || v49 == 9 ) /*0x1030d48ed*/
            {
              Curl_http_to_fold(a1: v6); /*0x1030d48f2*/
              v28 = v6[172] | 8; /*0x1030d48ff*/
            }
            else
            {
              v29 = single_header(a1: a2, a2: v6); /*0x1030d496c*/
              if ( v29 != 0 ) /*0x1030d4973*/
                goto LABEL_77; /*0x1030d4973*/
              v28 = v6[172]; /*0x1030d4979*/
            }
            v27 = v28 & 0xFB; /*0x1030d4981*/
            v6[172] = v27; /*0x1030d4983*/
          }
          if ( (v27 & 8) != 0 ) /*0x1030d498d*/
            break; /*0x1030d498d*/
LABEL_57:
          if ( (unsigned int)curlx_dyn_addn(a1: v6, a2: &v49, a3: 1) != 0 ) /*0x1030d49dd*/
          {
LABEL_76:
            Curl_failf(a1: a2, a2: "CONNECT response too large"); /*0x1030d4aba*/
            v9 = 56; /*0x1030d4acb*/
            goto LABEL_78; /*0x1030d4ad1*/
          }
          if ( v49 == 10 ) /*0x1030d49e7*/
          {
            v30 = (unsigned __int8 *)curlx_dyn_ptr(a1: v6); /*0x1030d49f5*/
            if ( curlx_dyn_len(a1: v6) != 0 && ((v31 = *v30) == 13 || v31 == 10) ) /*0x1030d4a11*/
            {
              v29 = single_header(a1: a2, a2: v6); /*0x1030d4a19*/
              if ( v29 != 0 ) /*0x1030d4a20*/
              {
LABEL_77:
                v9 = v29; /*0x1030d4ad3*/
                goto LABEL_78; /*0x1030d4ad3*/
              }
            }
            else
            {
              v6[172] |= 4u; /*0x1030d4a2b*/
            }
          }
        }
        if ( v49 != 9 && v49 != 32 ) /*0x1030d499f*/
        {
          if ( (unsigned int)curlx_dyn_addn(a1: v6, a2: " ", a3: 1) != 0 ) /*0x1030d49bb*/
            goto LABEL_76; /*0x1030d49bb*/
          v6[172] &= ~8u; /*0x1030d49c1*/
          goto LABEL_57; /*0x1030d49c1*/
        }
      }
    }
  }
  return v7; /*0x1030d45b7*/
}

// Address: 0x1030d4d60 | Name: _cf_h1_proxy_close
__int64 __fastcall cf_h1_proxy_close(__int64 a1, __int64 a2)
{
  __int64 v4; // rdi
  __int64 result; // rax
  __int64 v6; // rdi

  if ( a1 != 0 ) /*0x1030d4d6a*/
  {
    *(_BYTE *)(a1 + 36) &= ~1u; /*0x1030d4d72*/
    v4 = *(_QWORD *)(a1 + 16); /*0x1030d4d76*/
    if ( v4 != 0 ) /*0x1030d4d7d*/
      result = h1_tunnel_go_state(a1: v4, a2: 0, a3: a2); /*0x1030d4d84*/
    v6 = *(_QWORD *)(a1 + 8); /*0x1030d4d89*/
    if ( v6 != 0 ) /*0x1030d4d90*/
      return (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v6 + 32LL))(a1: v6, a2); /*0x1030d4da0*/
  }
  return result; /*0x1030d4d9d*/
}

// Address: 0x1030d4da7 | Name: _cf_h1_proxy_adjust_pollset
__int64 __fastcall cf_h1_proxy_adjust_pollset(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v5; // r15
  unsigned int socket; // eax

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d4db5*/
    return 0; /*0x1030d4dea*/
  v5 = *(_QWORD *)(a1 + 16); /*0x1030d4dbd*/
  socket = Curl_conn_cf_get_socket(a1); /*0x1030d4dc1*/
  if ( v5 != 0 && *(_DWORD *)(v5 + 168) != 1 ) /*0x1030d4dd3*/
    return Curl_pollset_change(a1: a2, a2: a3, a3: socket, a4: 1, a5: 2); /*0x1030d4e14*/
  else
    return Curl_pollset_change(a1: a2, a2: a3, a3: socket, a4: 2, a5: 1); /*0x1030d4de8*/
}

// Address: 0x1030d4e19 | Name: _Curl_cf_h1_proxy_insert_after
__int64 __fastcall Curl_cf_h1_proxy_insert_after(__int64 a1)
{
  unsigned int v2; // r14d
  _QWORD v4[3]; // [rsp+8h] [rbp-18h] BYREF

  v2 = Curl_cf_create(a1: v4, a2: &Curl_cft_h1_proxy, a3: 0); /*0x1030d4e39*/
  if ( v2 == 0 ) /*0x1030d4e3e*/
    Curl_conn_cf_insert_after(a1, a2: v4[0]); /*0x1030d4e47*/
  return v2; /*0x1030d4e4f*/
}

// Address: 0x1030d531c | Name: _cf_h2_proxy_destroy
void __fastcall cf_h2_proxy_destroy(__int64 a1)
{
  void *v1; // r14

  v1 = *(void **)(a1 + 16); /*0x1030d5323*/
  if ( v1 != nullptr ) /*0x1030d532a*/
  {
    cf_h2_proxy_ctx_clear(a1: *(_QWORD *)(a1 + 16)); /*0x1030d5332*/
    Curl_cfree(a1: v1); /*0x1030d5341*/
    *(_QWORD *)(a1 + 16) = 0; /*0x1030d5343*/
  }
}

// Address: 0x1030d5350 | Name: _cf_h2_proxy_connect
__int64 __fastcall cf_h2_proxy_connect(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v4; // rbx
  __int64 v5; // r14
  __int64 v6; // rdi
  _QWORD *v7; // r13
  __int64 v8; // r13
  _BYTE *v9; // rbx
  unsigned int v10; // r12d
  __int64 v11; // rax
  const char *v12; // rsi
  const char *v13; // rcx
  char *v14; // rax
  const char *v15; // rsi
  char v16; // r13
  const char *v17; // rsi
  __int64 v18; // rax
  void (__cdecl **v19)(void *); // r13
  __int64 v20; // rsi
  void (__cdecl **v21)(void *); // rbx
  __int64 *v22; // r13
  __int64 v23; // r14
  unsigned int v24; // eax
  int v25; // eax
  int v26; // eax
  __int64 v27; // rax
  unsigned int v28; // eax
  int v29; // eax
  __int64 v30; // r12
  unsigned int v31; // eax
  __int64 v32; // rdi
  __int64 v33; // rax
  __int64 v34; // rdi
  int v35; // eax
  int v36; // r14d
  const char *v37; // rax
  int v38; // eax
  bool v40; // zf
  unsigned int v41; // eax
  unsigned int v42; // r12d
  __int64 v43; // rax
  unsigned int v44; // eax
  unsigned int v45; // r13d
  __int64 v46; // rax
  __int64 v47; // rcx
  __int64 v48; // [rsp+8h] [rbp-C8h]
  bool *v49; // [rsp+10h] [rbp-C0h]
  __int64 v50; // [rsp+18h] [rbp-B8h]
  __int64 v51; // [rsp+18h] [rbp-B8h]
  _QWORD v52[2]; // [rsp+20h] [rbp-B0h] BYREF
  __int64 v53; // [rsp+30h] [rbp-A0h] BYREF
  __int64 v54; // [rsp+38h] [rbp-98h]
  int v55; // [rsp+44h] [rbp-8Ch]
  __int64 v56; // [rsp+48h] [rbp-88h]
  int **v57; // [rsp+50h] [rbp-80h]
  int **v58; // [rsp+58h] [rbp-78h] BYREF
  __m256i v59; // [rsp+60h] [rbp-70h] BYREF
  __int64 (__fastcall *v60)(); // [rsp+80h] [rbp-50h]

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d5376*/
  {
    *a3 = 1; /*0x1030d5539*/
    return 0; /*0x1030d553f*/
  }
  v4 = a1; /*0x1030d537f*/
  v5 = *(_QWORD *)(a1 + 16); /*0x1030d5382*/
  v6 = *(_QWORD *)(a1 + 8); /*0x1030d5386*/
  v7 = (_QWORD *)v5; /*0x1030d538e*/
  if ( (*(_BYTE *)(v6 + 36) & 1) == 0 ) /*0x1030d5391*/
  {
    v8 = v4; /*0x1030d5393*/
    v9 = a3; /*0x1030d5399*/
    v10 = Curl_conn_cf_connect(a1: v6, a2, a3); /*0x1030d53a1*/
    if ( v10 != 0 ) /*0x1030d53a6*/
      return v10; /*0x1030d53a6*/
    v10 = 0; /*0x1030d53ac*/
    if ( *v9 != 1 ) /*0x1030d53b2*/
      return v10; /*0x1030d53b2*/
    v11 = v8; /*0x1030d53b8*/
    v7 = *(_QWORD **)(v8 + 16); /*0x1030d53bb*/
    a3 = v9; /*0x1030d53bf*/
    v4 = v11; /*0x1030d53c2*/
  }
  v49 = a3; /*0x1030d53c5*/
  *a3 = 0; /*0x1030d53cc*/
  v48 = v7[1]; /*0x1030d53d3*/
  v7[1] = a2; /*0x1030d53da*/
  if ( *(_QWORD *)v5 != 0 ) /*0x1030d53e2*/
    goto LABEL_23; /*0x1030d53e2*/
  v58 = nullptr; /*0x1030d53e8*/
  *((_OWORD *)v7 + 18) = 0; /*0x1030d53f3*/
  *((_OWORD *)v7 + 17) = 0; /*0x1030d53fb*/
  *((_OWORD *)v7 + 16) = 0; /*0x1030d5403*/
  *((_OWORD *)v7 + 15) = 0; /*0x1030d540b*/
  *((_OWORD *)v7 + 14) = 0; /*0x1030d5413*/
  *((_OWORD *)v7 + 13) = 0; /*0x1030d541b*/
  *((_OWORD *)v7 + 12) = 0; /*0x1030d5423*/
  *((_OWORD *)v7 + 11) = 0; /*0x1030d542b*/
  *((_OWORD *)v7 + 10) = 0; /*0x1030d5433*/
  *((_OWORD *)v7 + 9) = 0; /*0x1030d543b*/
  Curl_bufq_init(a1: (__int64)(v7 + 2), a2: 0x4000, a3: 640); /*0x1030d5451*/
  Curl_bufq_init(a1: (__int64)(v7 + 10), a2: 0x4000, a3: 1); /*0x1030d5464*/
  *((_DWORD *)v7 + 74) = 0; /*0x1030d5469*/
  *((_DWORD *)v7 + 72) = -1; /*0x1030d5474*/
  Curl_bufq_init2(a1: (__int64)(v7 + 19), a2: 0x4000, a3: 640, a4: 1); /*0x1030d5495*/
  Curl_bufq_init(a1: (__int64)(v7 + 27), a2: 0x4000, a3: 8); /*0x1030d54ab*/
  Curl_http_proxy_get_destination(a1: v4, a2: &v59, a3: v52, a4: &v53); /*0x1030d54c8*/
  v12 = "["; /*0x1030d54cd*/
  if ( (_BYTE)v53 == 0 ) /*0x1030d54e0*/
    v12 = ""; /*0x1030d54e0*/
  v13 = "]"; /*0x1030d54eb*/
  if ( (_BYTE)v53 == 0 ) /*0x1030d54f2*/
    v13 = ""; /*0x1030d54f2*/
  v14 = curl_maprintf(format: "%s%s%s:%d", v12, (const char *)v59.i64[0], v13, LODWORD(v52[0])); /*0x1030d5509*/
  v7[35] = v14; /*0x1030d550e*/
  v10 = 27; /*0x1030d5515*/
  if ( v14 == nullptr ) /*0x1030d551e*/
  {
    v16 = 0; /*0x1030d5544*/
    goto LABEL_20; /*0x1030d5547*/
  }
  if ( (unsigned int)nghttp2_session_callbacks_new(a1: &v58) != 0 ) /*0x1030d552b*/
  {
    v15 = "Could not initialize nghttp2 callbacks"; /*0x1030d552d*/
LABEL_19:
    v16 = 0; /*0x1030d5640*/
    Curl_failf(a1: a2, a2: v15); /*0x1030d5648*/
    goto LABEL_20; /*0x1030d5648*/
  }
  nghttp2_session_callbacks_set_send_callback(a1: v58, a2: on_session_send); /*0x1030d5557*/
  nghttp2_session_callbacks_set_on_frame_recv_callback(a1: v58, a2: proxy_h2_on_frame_recv); /*0x1030d5567*/
  nghttp2_session_callbacks_set_on_data_chunk_recv_callback(a1: v58, a2: tunnel_recv_callback); /*0x1030d5577*/
  nghttp2_session_callbacks_set_on_stream_close_callback(a1: v58, a2: proxy_h2_on_stream_close); /*0x1030d5587*/
  nghttp2_session_callbacks_set_on_header_callback(a1: v58, a2: proxy_h2_on_header); /*0x1030d5597*/
  v57 = v58; /*0x1030d55a0*/
  v50 = *(_QWORD *)(v4 + 16); /*0x1030d55a8*/
  v60 = off_10C8BD048; /*0x1030d55b6*/
  v59 = off_10C8BD028; /*0x1030d55c1*/
  if ( (unsigned int)nghttp2_option_new(a1: v52) != 0 /*0x1030d5633*/
    || (nghttp2_option_set_no_auto_window_update(a1: v52[0], a2: 1),
        nghttp2_option_set_no_rfc9113_leading_and_trailing_ws_validation(a1: v52[0], a2: 1),
        LODWORD(v57) = nghttp2_session_client_new3(a1: v50, a2: v57, a3: v4, a4: v52[0], a5: &v59),
        nghttp2_option_del(a1: v52[0]),
        (_DWORD)v57 != 0) )
  {
    v15 = "Could not initialize nghttp2"; /*0x1030d5639*/
    goto LABEL_19; /*0x1030d5639*/
  }
  v59.i32[0] = 3; /*0x1030d5b28*/
  v59.i32[1] = Curl_multi_max_concurrent_streams(a1: *(_QWORD *)(a2 + 104)); /*0x1030d5b39*/
  *(__int128 *)((char *)v59.i128 + 8) = xmmword_1094C0200; /*0x1030d5b45*/
  v10 = 0; /*0x1030d5b52*/
  v41 = nghttp2_submit_settings(a1: *v7, a2: 0, a3: &v59, a4: 3); /*0x1030d5b5c*/
  if ( v41 != 0 )
  {
    v42 = v41; /*0x1030d5b67*/
    v43 = nghttp2_strerror(a1: v41); /*0x1030d5b6a*/
    v16 = 0; /*0x1030d5b76*/
    Curl_failf(a1: a2, a2: "nghttp2_submit_settings() failed: %s(%d)", v43, v42);
LABEL_95:
    v10 = 16; /*0x1030d5bbe*/
    goto LABEL_20; /*0x1030d5bc4*/
  }
  v44 = nghttp2_session_set_local_window_size(a1: *v7, a2: 0, a3: 0, a4: 104857600); /*0x1030d5b91*/
  if ( v44 != 0 )
  {
    v45 = v44; /*0x1030d5b9a*/
    v46 = nghttp2_strerror(a1: v44); /*0x1030d5b9f*/
    v47 = v45; /*0x1030d5bb1*/
    v16 = 0; /*0x1030d5bb4*/
    Curl_failf(a1: a2, a2: "nghttp2_session_set_local_window_size() failed: %s(%d)", v46, v47);
    goto LABEL_95; /*0x1030d5bb9*/
  }
  v16 = 1; /*0x1030d5bc9*/
LABEL_20:
  if ( v58 != nullptr ) /*0x1030d5654*/
    nghttp2_session_callbacks_del(); /*0x1030d5656*/
  if ( v16 == 0 ) /*0x1030d565e*/
    goto LABEL_86; /*0x1030d565e*/
LABEL_23:
  if ( Curl_timeleft_ms(a1: a2) < 0 ) /*0x1030d566f*/
  {
    Curl_failf(a1: a2, a2: "Proxy CONNECT aborted due to timeout"); /*0x1030d5a0f*/
    v10 = 28; /*0x1030d5a14*/
    goto LABEL_86; /*0x1030d5a1a*/
  }
  v57 = (int **)(v5 + 144); /*0x1030d567c*/
  v51 = *(_QWORD *)(v4 + 16); /*0x1030d5684*/
  v18 = *(unsigned int *)(v5 + 296); /*0x1030d568b*/
  v19 = &Curl_cfree; /*0x1030d5692*/
  v10 = 0; /*0x1030d5699*/
  v56 = v5; /*0x1030d569c*/
  while ( 2 )
  {
    switch ( v18 )
    {
      case 0LL:
        v20 = v4; /*0x1030d56be*/
        v21 = v19; /*0x1030d56c1*/
        v22 = *(__int64 **)(v20 + 16); /*0x1030d56c4*/
        v53 = 0; /*0x1030d56c8*/
        v23 = v20; /*0x1030d56da*/
        v24 = Curl_http_proxy_create_CONNECT(a1: &v53, a2: v20, a3: a2, a4: 2); /*0x1030d56e5*/
        if ( v24 != 0 || (v24 = Curl_creader_set_null(a1: a2)) != 0 ) /*0x1030d56f8*/
        {
          v10 = v24; /*0x1030d56fe*/
          v19 = v21; /*0x1030d5701*/
          v4 = v23; /*0x1030d5704*/
          v5 = v56; /*0x1030d5707*/
          goto LABEL_29; /*0x1030d5707*/
        }
        v54 = *v22; /*0x1030d58ea*/
        v30 = v53; /*0x1030d58f1*/
        Curl_dynhds_init(a1: &v59, a2: 0, a3: 0x100000); /*0x1030d5906*/
        v31 = Curl_http_req_to_h2(a1: &v59, a2: v30, a3: a2); /*0x1030d5914*/
        v55 = -1; /*0x1030d5919*/
        if ( v31 != 0 ) /*0x1030d5925*/
        {
          v10 = v31; /*0x1030d5927*/
          v32 = 0; /*0x1030d592a*/
          v19 = v21; /*0x1030d592c*/
LABEL_65:
          v4 = v23; /*0x1030d592f*/
          v5 = v56; /*0x1030d5932*/
          goto LABEL_70; /*0x1030d5939*/
        }
        v33 = Curl_dynhds_to_nva(a1: &v59, a2: &v58); /*0x1030d5945*/
        v19 = v21; /*0x1030d594d*/
        if ( v33 == 0 ) /*0x1030d5950*/
        {
          v10 = 27; /*0x1030d59f6*/
          v32 = 0; /*0x1030d59fc*/
          goto LABEL_65; /*0x1030d59fe*/
        }
        v52[1] = tunnel_send_callback; /*0x1030d5960*/
        v4 = v23; /*0x1030d5967*/
        v52[0] = v23; /*0x1030d596a*/
        v10 = 0; /*0x1030d5975*/
        v34 = v54; /*0x1030d5978*/
        v54 = v33; /*0x1030d5981*/
        v35 = nghttp2_submit_request(a1: v34, a2: 0, a3: v33, a4: v58, a5: v52, a6: v57); /*0x1030d5993*/
        v55 = v35; /*0x1030d599a*/
        if ( v35 < 0 )
        {
          v36 = v35; /*0x1030d59a2*/
          v37 = (const char *)nghttp2_strerror(a1: (unsigned int)v35); /*0x1030d59a7*/
          Curl_failf(a1: a2, a2: "nghttp2_session_upgrade2() failed: %s(%d)", v37, v36);
          v10 = 55; /*0x1030d59c3*/
        }
        v5 = v56; /*0x1030d59c9*/
        v32 = v54; /*0x1030d59d0*/
LABEL_70:
        ((void (__fastcall *)(__int64))*v19)(a1: v32); /*0x1030d59d7*/
        Curl_dynhds_free(a1: &v59); /*0x1030d59df*/
        *(_DWORD *)(v5 + 288) = v55; /*0x1030d59ea*/
LABEL_29:
        if ( v53 != 0 ) /*0x1030d5718*/
          Curl_http_req_free(); /*0x1030d571a*/
        if ( v10 != 0 ) /*0x1030d5722*/
        {
          Curl_failf(a1: a2, a2: "Failed sending CONNECT to proxy"); /*0x1030d5a4c*/
          goto LABEL_78; /*0x1030d5a4c*/
        }
        if ( *(_DWORD *)(v5 + 296) != 1 ) /*0x1030d5730*/
          *(_DWORD *)(v5 + 296) = 1; /*0x1030d5732*/
LABEL_34:
        v10 = proxy_h2_progress_ingress(a1: v4, a2); /*0x1030d573d*/
        if ( v10 == 0 ) /*0x1030d574d*/
          v10 = proxy_h2_progress_egress(a1: v4); /*0x1030d5757*/
        if ( v10 != 0 && v10 != 81 ) /*0x1030d5763*/
        {
          v29 = *(_DWORD *)(v5 + 296); /*0x1030d5892*/
          if ( v29 == 1 ) /*0x1030d589c*/
          {
            *(_BYTE *)(a2 + 378) &= ~4u; /*0x1030d58a8*/
          }
          else if ( v29 == 4 ) /*0x1030d58a1*/
          {
            goto LABEL_78; /*0x1030d58a1*/
          }
          *(_DWORD *)(v5 + 296) = 4; /*0x1030d58b0*/
          ((void (__fastcall *)(_QWORD))*v19)(a1: *(_QWORD *)(a2 + 4056)); /*0x1030d58c2*/
          *(_QWORD *)(a2 + 4056) = 0; /*0x1030d58c6*/
          goto LABEL_61; /*0x1030d58c6*/
        }
        if ( (*(_BYTE *)(v5 + 300) & 1) == 0 ) /*0x1030d5771*/
        {
          v10 = 0; /*0x1030d5a1f*/
          goto LABEL_80; /*0x1030d5a22*/
        }
        v25 = *(_DWORD *)(v5 + 296); /*0x1030d5777*/
        if ( v25 != 2 ) /*0x1030d5781*/
        {
          if ( v25 == 1 ) /*0x1030d5786*/
            *(_BYTE *)(a2 + 378) &= ~4u; /*0x1030d5788*/
          *(_DWORD *)(v5 + 296) = 2; /*0x1030d5790*/
        }
LABEL_43:
        v26 = **v57; /*0x1030d579b*/
        if ( (unsigned int)(v26 - 200) <= 0x63 ) /*0x1030d57ad*/
        {
          *(_BYTE *)(a2 + 2532) = (*(_BYTE *)(a2 + 2532) & 0xFC) + 1; /*0x1030d57ba*/
          *(_DWORD *)(v5 + 296) = 3; /*0x1030d57c1*/
          ((void (__fastcall *)(_QWORD))*v19)(a1: *(_QWORD *)(a2 + 4056)); /*0x1030d57d3*/
          *(_QWORD *)(a2 + 4056) = 0; /*0x1030d57d7*/
LABEL_55:
          v10 = 0; /*0x1030d588d*/
LABEL_61:
          v18 = 0; /*0x1030d58d1*/
          if ( *(_DWORD *)(v5 + 296) != 0 ) /*0x1030d58db*/
            goto LABEL_78; /*0x1030d58db*/
          continue; /*0x1030d58db*/
        }
        v10 = 56; /*0x1030d57e7*/
        v17 = "WWW-Authenticate"; /*0x1030d57ed*/
        if ( v26 != 401 ) /*0x1030d57f9*/
        {
          if ( v26 != 407 ) /*0x1030d5800*/
            goto LABEL_81; /*0x1030d5800*/
          v17 = "Proxy-Authenticate"; /*0x1030d5806*/
        }
        v27 = Curl_dynhds_cget(a1: *v57 + 4, a2: v17); /*0x1030d5811*/
        if ( v27 == 0 ) /*0x1030d5819*/
          goto LABEL_81; /*0x1030d5819*/
        v28 = Curl_http_input_auth(a1: a2, a2: **v57 == 407, a3: *(_QWORD *)(v27 + 8)); /*0x1030d5839*/
        if ( v28 == 0 ) /*0x1030d5840*/
        {
          if ( *(_QWORD *)(a2 + 368) == 0 ) /*0x1030d5850*/
            goto LABEL_81; /*0x1030d5850*/
          ((void (*)(void))*v19)(); /*0x1030d5856*/
          *(_QWORD *)(a2 + 368) = 0; /*0x1030d585a*/
          v18 = *(unsigned int *)(v5 + 296); /*0x1030d5865*/
          v10 = v18; /*0x1030d586c*/
          if ( (_DWORD)v18 != 0 ) /*0x1030d5871*/
          {
            if ( (_DWORD)v18 == 1 ) /*0x1030d587a*/
              *(_BYTE *)(a2 + 378) &= ~4u; /*0x1030d587c*/
            tunnel_stream_clear(a1: v57); /*0x1030d5888*/
            goto LABEL_55; /*0x1030d5888*/
          }
          continue; /*0x1030d5871*/
        }
        v10 = v28; /*0x1030d5a24*/
LABEL_78:
        if ( v10 != 81 && v10 != 0 ) /*0x1030d5a5a*/
        {
LABEL_81:
          v38 = *(_DWORD *)(v5 + 296); /*0x1030d5a6c*/
          if ( v38 != 4 ) /*0x1030d5a76*/
          {
            if ( v38 == 1 ) /*0x1030d5a7b*/
              *(_BYTE *)(a2 + 378) &= ~4u; /*0x1030d5a7d*/
            *(_DWORD *)(v5 + 296) = 4; /*0x1030d5a85*/
            ((void (__fastcall *)(_QWORD, const char *))*v19)(a1: *(_QWORD *)(a2 + 4056), a2: v17); /*0x1030d5a97*/
            *(_QWORD *)(a2 + 4056) = 0; /*0x1030d5a9b*/
          }
        }
        else
        {
LABEL_80:
          if ( (*(_BYTE *)(v51 + 300) & 2) != 0 ) /*0x1030d5a6a*/
            goto LABEL_81; /*0x1030d5a6a*/
        }
        if ( v10 != 0 ) /*0x1030d5aa9*/
        {
LABEL_86:
          *v49 = false; /*0x1030d5aab*/
        }
        else
        {
          v10 = 0; /*0x1030d5aed*/
          v40 = *(_DWORD *)(v5 + 296) == 3; /*0x1030d5af0*/
          *v49 = v40; /*0x1030d5aff*/
          if ( v40 ) /*0x1030d5b02*/
          {
LABEL_90:
            *(_BYTE *)(v4 + 36) |= 1u; /*0x1030d5b04*/
            Curl_req_soft_reset(a1: a2 + 176, a2); /*0x1030d5b12*/
            Curl_client_reset(a1: a2); /*0x1030d5b1a*/
            v10 = 0; /*0x1030d5b1f*/
          }
        }
        *(_QWORD *)(*(_QWORD *)(v4 + 16) + 8LL) = v48; /*0x1030d5ac0*/
        return v10; /*0x1030d5adb*/
      case 1LL:
        goto LABEL_34;
      case 2LL:
        goto LABEL_43;
      case 3LL:
        *v49 = true; /*0x1030d5a30*/
        goto LABEL_90; /*0x1030d5a33*/
      case 4LL:
        v10 = 56; /*0x1030d5a38*/
        goto LABEL_86; /*0x1030d5a3e*/
      default:
        goto LABEL_78;
    }
  }
}

// Address: 0x1030d5bec | Name: _cf_h2_proxy_close
__int64 __fastcall cf_h2_proxy_close(__int64 a1, __int64 a2)
{
  __int64 v4; // rdi
  __int64 v5; // r15
  __int64 result; // rax
  __int64 v7; // rdi

  v4 = *(_QWORD *)(a1 + 16); /*0x1030d5bfc*/
  if ( v4 != 0 ) /*0x1030d5c03*/
  {
    v5 = *(_QWORD *)(v4 + 8); /*0x1030d5c05*/
    *(_QWORD *)(v4 + 8) = a2; /*0x1030d5c09*/
    cf_h2_proxy_ctx_clear(a1: v4); /*0x1030d5c0d*/
    result = *(_QWORD *)(a1 + 16); /*0x1030d5c12*/
    *(_QWORD *)(result + 8) = v5; /*0x1030d5c16*/
  }
  v7 = *(_QWORD *)(a1 + 8); /*0x1030d5c1a*/
  if ( v7 != 0 ) /*0x1030d5c21*/
    return (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v7 + 32LL))(a1: v7, a2); /*0x1030d5c37*/
  return result; /*0x1030d5c32*/
}

// Address: 0x1030d5c44 | Name: _cf_h2_proxy_shutdown
__int64 __fastcall cf_h2_proxy_shutdown(__int64 a1, __int64 a2, _BYTE *a3)
{
  char v4; // al
  _QWORD *v6; // r13
  __int64 v7; // rdi
  char v8; // al
  __int64 v10; // r12
  unsigned int v11; // eax
  int v12; // r12d
  const char *v13; // rax
  char v14; // cl
  __int64 result; // rax
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // rsi
  __int64 v19; // [rsp+0h] [rbp-30h]

  v4 = *(_BYTE *)(a1 + 36); /*0x1030d5c55*/
  if ( (v4 & 1) == 0 /*0x1030d5c82*/
    || (v6 = *(_QWORD **)(a1 + 16), v7 = *v6, *v6 == 0 || (v4 & 2) != 0)
    || ((v8 = *((_BYTE *)v6 + 312)) & 1) != 0 )
  {
    *a3 = 1; /*0x1030d5cec*/
    return 0; /*0x1030d5d00*/
  }
  v10 = v6[1]; /*0x1030d5c87*/
  v6[1] = a2; /*0x1030d5c8b*/
  if ( (v8 & 4) != 0 ) /*0x1030d5c91*/
  {
LABEL_9:
    if ( (unsigned int)((__int64 (*)(void))nghttp2_session_want_write)() == 0 /*0x1030d5d24*/
      || (_DWORD)(result = proxy_h2_progress_egress(a1)) == 0 )
    {
      if ( (unsigned int)nghttp2_session_want_read(a1: *v6) == 0 ) /*0x1030d5d31*/
      {
        LOBYTE(v17) = 1; /*0x1030d5d70*/
        if ( (v6[39] & 1) != 0 ) /*0x1030d5d7a*/
        {
LABEL_22:
          *a3 = v17; /*0x1030d5d9b*/
          *(_QWORD *)(*(_QWORD *)(a1 + 16) + 8LL) = v10; /*0x1030d5da2*/
          v14 = 2 * v17; /*0x1030d5da6*/
          goto LABEL_23; /*0x1030d5da6*/
        }
LABEL_19:
        LOBYTE(v17) = (unsigned int)nghttp2_session_want_write(a1: *v6, a2: v18, a3: v16, a4: v17) == 0 /*0x1030d5d89*/
                   && (unsigned int)nghttp2_session_want_read(a1: *v6) == 0;
        goto LABEL_22; /*0x1030d5d8b*/
      }
      result = proxy_h2_progress_ingress(a1, a2); /*0x1030d5d39*/
    }
    if ( (v6[39] & 1) != 0 ) /*0x1030d5d46*/
    {
      *a3 = 1; /*0x1030d5d5c*/
      *(_QWORD *)(*(_QWORD *)(a1 + 16) + 8LL) = v10; /*0x1030d5d64*/
      v14 = 2; /*0x1030d5d68*/
      if ( (_DWORD)result != 0 ) /*0x1030d5d6c*/
        goto LABEL_24; /*0x1030d5d6c*/
LABEL_23:
      result = 0; /*0x1030d5da8*/
      goto LABEL_24; /*0x1030d5da8*/
    }
    if ( (_DWORD)result != 0 ) /*0x1030d5d4a*/
    {
      *a3 = 0; /*0x1030d5d4c*/
      *(_QWORD *)(*(_QWORD *)(a1 + 16) + 8LL) = v10; /*0x1030d5d54*/
      v14 = 2; /*0x1030d5d58*/
      goto LABEL_24; /*0x1030d5d5a*/
    }
    goto LABEL_19; /*0x1030d5d4a*/
  }
  v19 = v10; /*0x1030d5c93*/
  v11 = nghttp2_submit_goaway(a1: v7, a2: 0, a3: 0, a4: 0, a5: "shutdown", a6: 9); /*0x1030d5caa*/
  if ( v11 == 0 ) /*0x1030d5cb1*/
  {
    *((_BYTE *)v6 + 312) |= 4u; /*0x1030d5d01*/
    goto LABEL_9; /*0x1030d5d01*/
  }
  v12 = v11; /*0x1030d5cb3*/
  v13 = (const char *)nghttp2_strerror(a1: v11); /*0x1030d5cb8*/
  Curl_failf(a1: a2, a2: "nghttp2_submit_goaway() failed: %s(%d)", v13, v12);
  *(_QWORD *)(*(_QWORD *)(a1 + 16) + 8LL) = v19; /*0x1030d5cdc*/
  v14 = 2; /*0x1030d5ce0*/
  result = 55; /*0x1030d5ce2*/
LABEL_24:
  *(_BYTE *)(a1 + 36) = v14 | *(_BYTE *)(a1 + 36) & 0xFD; /*0x1030d5daa*/
  return result; /*0x1030d5cf6*/
}

// Address: 0x1030d5dba | Name: _cf_h2_proxy_adjust_pollset
__int64 __fastcall cf_h2_proxy_adjust_pollset(__int64 a1, __int64 a2, __int64 a3)
{
  _QWORD *v6; // r13
  unsigned int socket; // eax
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // rsi
  bool v11; // r14
  __int64 v12; // rdx
  __int64 v13; // rsi
  __int64 v14; // rdi
  __int64 v15; // rax
  int remote_window_size; // eax
  __int64 v17; // rdx
  __int64 v18; // rcx
  int v19; // r14d
  __int64 v20; // rsi
  __int64 v21; // r15
  bool v22; // r12
  int stream_remote_window_size; // eax
  __int64 result; // rax
  __int64 v25; // rax
  __int64 v26; // rcx
  bool v27; // r14
  int v28; // eax
  __int64 v29; // rcx
  _BOOL8 v30; // r8
  bool v31; // al
  int v32; // ecx
  bool is_empty; // cl
  __int64 v34; // [rsp+0h] [rbp-40h]
  __int64 v35; // [rsp+8h] [rbp-38h]
  unsigned int v36; // [rsp+10h] [rbp-30h]
  unsigned __int8 v37; // [rsp+16h] [rbp-2Ah] BYREF
  bool v38[41]; // [rsp+17h] [rbp-29h] BYREF

  v6 = *(_QWORD **)(a1 + 16); /*0x1030d5dd4*/
  socket = Curl_conn_cf_get_socket(a1); /*0x1030d5dd8*/
  v36 = socket; /*0x1030d5de1*/
  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 || *v6 == 0 ) /*0x1030d5ded*/
  {
    Curl_pollset_check(a1: a2, a2: a3, a3: socket, a4: &v37, a5: v38); /*0x1030d5e40*/
  }
  else
  {
    v11 = true; /*0x1030d5df4*/
    if ( (unsigned int)nghttp2_session_want_write(a1: *v6, a2: v10, a3: v8, a4: v9) == 0 /*0x1030d5dff*/
      && Curl_bufq_is_empty(a1: (__int64)(v6 + 10)) )
    {
      v11 = !Curl_bufq_is_empty(a1: (__int64)(v6 + 27)); /*0x1030d5e17*/
    }
    v38[0] = v11; /*0x1030d5e1b*/
    v37 = (unsigned int)nghttp2_session_want_read(a1: *v6) != 0; /*0x1030d5e2a*/
  }
  v14 = *v6; /*0x1030d5e45*/
  if ( *v6 != 0 && (v37 != 0 || v38[0]) ) /*0x1030d5e58*/
  {
    v15 = *(_QWORD *)(a1 + 16); /*0x1030d5e5a*/
    v35 = *(_QWORD *)(v15 + 8); /*0x1030d5e62*/
    *(_QWORD *)(v15 + 8) = a2; /*0x1030d5e66*/
    remote_window_size = nghttp2_session_get_remote_window_size(); /*0x1030d5e6a*/
    v19 = remote_window_size; /*0x1030d5e6f*/
    v20 = *((unsigned int *)v6 + 72); /*0x1030d5e72*/
    if ( (int)v20 < 0 ) /*0x1030d5e7b*/
    {
      v37 |= remote_window_size == 0; /*0x1030d5f32*/
    }
    else
    {
      v34 = a2; /*0x1030d5e84*/
      v21 = a3; /*0x1030d5e88*/
      v22 = remote_window_size == 0; /*0x1030d5e8b*/
      stream_remote_window_size = nghttp2_session_get_stream_remote_window_size(a1: *v6); /*0x1030d5e93*/
      LOBYTE(v18) = v22 || stream_remote_window_size == 0; /*0x1030d5e9d*/
      a3 = v21; /*0x1030d5ea0*/
      a2 = v34; /*0x1030d5ea3*/
      v37 |= v18; /*0x1030d5ea7*/
      if ( stream_remote_window_size == 0 ) /*0x1030d5eac*/
        goto LABEL_22; /*0x1030d5eac*/
    }
    v31 = true; /*0x1030d5f35*/
    if ( v38[0] ) /*0x1030d5f3b*/
    {
LABEL_26:
      v38[0] = v31; /*0x1030d5f75*/
      v29 = v37; /*0x1030d5f78*/
      v30 = v31; /*0x1030d5f7c*/
LABEL_27:
      result = Curl_pollset_set(a1: a2, a2: a3, a3: v36, a4: v29, a5: v30); /*0x1030d5f80*/
      *(_QWORD *)(*(_QWORD *)(a1 + 16) + 8LL) = v35; /*0x1030d5f96*/
      return result; /*0x1030d5f96*/
    }
LABEL_22:
    if ( v19 == 0 || (v32 = nghttp2_session_want_write(a1: *v6, a2: v20, a3: v17, a4: v18), v31 = true, v32 == 0) ) /*0x1030d5f51*/
    {
      is_empty = Curl_bufq_is_empty(a1: (__int64)(v6 + 10)); /*0x1030d5f5c*/
      v31 = true; /*0x1030d5f5e*/
      if ( is_empty ) /*0x1030d5f62*/
        v31 = !Curl_bufq_is_empty(a1: (__int64)(v6 + 27)); /*0x1030d5f73*/
    }
    goto LABEL_26; /*0x1030d5f73*/
  }
  result = 0; /*0x1030d5eb7*/
  if ( (v6[39] & 4) != 0 && (*(_BYTE *)(a1 + 36) & 2) == 0 ) /*0x1030d5ecb*/
  {
    v25 = *(_QWORD *)(a1 + 16); /*0x1030d5ed1*/
    v26 = *(_QWORD *)(v25 + 8); /*0x1030d5ed5*/
    v35 = v26; /*0x1030d5ed9*/
    *(_QWORD *)(v25 + 8) = a2; /*0x1030d5edd*/
    v27 = true; /*0x1030d5ee6*/
    if ( (unsigned int)nghttp2_session_want_write(a1: v14, a2: v13, a3: v12, a4: v26) == 0 /*0x1030d5ef1*/
      && Curl_bufq_is_empty(a1: (__int64)(v6 + 10)) )
    {
      v27 = !Curl_bufq_is_empty(a1: (__int64)(v6 + 27)); /*0x1030d5f09*/
    }
    v38[0] = v27; /*0x1030d5f0d*/
    v28 = nghttp2_session_want_read(a1: *v6); /*0x1030d5f15*/
    v29 = v28 != 0; /*0x1030d5f1e*/
    v37 = v28 != 0; /*0x1030d5f21*/
    v30 = v38[0]; /*0x1030d5f25*/
    goto LABEL_27; /*0x1030d5f2a*/
  }
  return result; /*0x1030d5f9a*/
}

// Address: 0x1030d5fa9 | Name: _cf_h2_proxy_data_pending
__int64 __fastcall cf_h2_proxy_data_pending(__int64 a1, __int64 a2)
{
  unsigned int v2; // r15d
  __int64 v5; // r12
  __int64 v6; // rdi

  v5 = *(_QWORD *)(a1 + 16); /*0x1030d5fba*/
  if ( v5 == 0 /*0x1030d5fe9*/
    || (LOBYTE(v2) = 1, Curl_bufq_is_empty(a1: v5 + 16))
    && (*(_DWORD *)(v5 + 296) != 3 || Curl_bufq_is_empty(a1: v5 + 152)) )
  {
    v6 = *(_QWORD *)(a1 + 8); /*0x1030d5ff2*/
    if ( v6 != 0 ) /*0x1030d5ff9*/
      return (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v6 + 56LL))(a1: v6, a2); /*0x1030d600d*/
    return 0; /*0x1030d600f*/
  }
  return v2; /*0x1030d6006*/
}

// Address: 0x1030d601e | Name: _cf_h2_proxy_send
__int64 __fastcall cf_h2_proxy_send(__int64 a1, __int64 a2, char *a3, size_t a4, __int64 a5, _QWORD *a6)
{
  __int64 v8; // r15
  __int64 v9; // r13
  unsigned int v10; // r12d
  unsigned int v11; // eax
  unsigned int v12; // eax
  unsigned int v13; // eax
  unsigned int v14; // r12d
  unsigned int v15; // eax
  unsigned int v17; // [rsp+14h] [rbp-2Ch]

  v8 = *(_QWORD *)(a1 + 16); /*0x1030d6035*/
  *a6 = 0; /*0x1030d6039*/
  v9 = *(_QWORD *)(v8 + 8); /*0x1030d6040*/
  *(_QWORD *)(v8 + 8) = a2; /*0x1030d6044*/
  v10 = 55; /*0x1030d6048*/
  if ( *(_DWORD *)(v8 + 296) == 3 && (*(_BYTE *)(v8 + 300) & 2) == 0 ) /*0x1030d6064*/
  {
    v11 = Curl_bufq_write(a1: v8 + 216, a2: a3, a3: a4, a4: a6); /*0x1030d6081*/
    if ( v11 != 81 && v11 != 0 ) /*0x1030d608d*/
    {
      v10 = v11; /*0x1030d6116*/
    }
    else
    {
      v17 = v11; /*0x1030d6093*/
      if ( Curl_bufq_is_empty(a1: v8 + 216) /*0x1030d60be*/
        || (v12 = nghttp2_session_resume_data(a1: *(_QWORD *)v8, a2: *(unsigned int *)(v8 + 288)),
            (unsigned int)nghttp2_is_fatal(a1: v12) == 0) )
      {
        v13 = proxy_h2_progress_ingress(a1, a2); /*0x1030d60c6*/
        v14 = Curl_1st_fatal(a1: v17, a2: v13); /*0x1030d60d5*/
        v15 = proxy_h2_progress_egress(a1); /*0x1030d60db*/
        v10 = Curl_1st_fatal(a1: v14, a2: v15); /*0x1030d60ea*/
        if ( v10 == 0 ) /*0x1030d60ef*/
        {
          if ( (unsigned int)proxy_h2_should_close_session(a1: v8) != 0 ) /*0x1030d60fb*/
          {
            v10 = 55; /*0x1030d610a*/
            if ( (*(_BYTE *)(v8 + 300) & 2) == 0 ) /*0x1030d6110*/
              v10 = 16; /*0x1030d6110*/
          }
          else
          {
            v10 = 0; /*0x1030d6167*/
          }
        }
      }
    }
  }
  if ( !Curl_bufq_is_empty(a1: v8 + 152) && (v10 == 81 || v10 == 0) ) /*0x1030d6136*/
    drain_tunnel(a1, a2, a3: v8 + 144); /*0x1030d6148*/
  *(_QWORD *)(*(_QWORD *)(a1 + 16) + 8LL) = v9; /*0x1030d6151*/
  return v10; /*0x1030d6158*/
}

// Address: 0x1030d616c | Name: _cf_h2_proxy_recv
__int64 __fastcall cf_h2_proxy_recv(__int64 a1, __int64 a2, char *a3, size_t a4, __int64 *a5)
{
  __int64 v6; // r15
  unsigned int v7; // r13d
  __int64 v10; // r14
  char v11; // al
  unsigned int v12; // r13d
  char v13; // al
  __int64 v14; // rdx
  __int64 v15; // rax
  unsigned int v16; // r14d
  int v17; // r12d
  const char *v18; // r13
  const char *v19; // rax
  unsigned int v20; // eax
  __int64 v22; // [rsp+8h] [rbp-48h]
  char *v24; // [rsp+18h] [rbp-38h]

  v6 = *(_QWORD *)(a1 + 16); /*0x1030d6184*/
  *a5 = 0; /*0x1030d6188*/
  v22 = *(_QWORD *)(v6 + 8); /*0x1030d6193*/
  *(_QWORD *)(v6 + 8) = a2; /*0x1030d619b*/
  v7 = 56; /*0x1030d619f*/
  if ( *(_DWORD *)(v6 + 296) == 3 /*0x1030d61da*/
    && (!Curl_bufq_is_empty(a1: v6 + 152) || (v7 = proxy_h2_progress_ingress(a1, a2)) == 0) )
  {
    v24 = a3; /*0x1030d61e0*/
    v10 = *(_QWORD *)(a1 + 16); /*0x1030d61e4*/
    *a5 = 0; /*0x1030d61e8*/
    if ( Curl_bufq_is_empty(a1: v10 + 152) ) /*0x1030d61fa*/
    {
      v11 = *(_BYTE *)(v10 + 300); /*0x1030d6203*/
      if ( (v11 & 2) == 0 ) /*0x1030d620c*/
      {
        v12 = 56; /*0x1030d620e*/
        if ( (v11 & 4) == 0 ) /*0x1030d6216*/
        {
          v13 = *(_BYTE *)(v10 + 312); /*0x1030d621c*/
          if ( (v13 & 1) == 0 ) /*0x1030d6225*/
          {
LABEL_10:
            if ( (v13 & 2) == 0 || *(_DWORD *)(v10 + 308) >= *(_DWORD *)(v10 + 288) ) /*0x1030d6251*/
              v12 = 81; /*0x1030d6257*/
            goto LABEL_21; /*0x1030d625d*/
          }
          if ( !Curl_bufq_is_empty(a1: v10 + 16) ) /*0x1030d622b*/
          {
            v13 = *(_BYTE *)(v10 + 312); /*0x1030d6238*/
            goto LABEL_10; /*0x1030d6238*/
          }
        }
LABEL_21:
        v20 = proxy_h2_progress_egress(a1); /*0x1030d6300*/
        v7 = Curl_1st_fatal(a1: v12, a2: v20); /*0x1030d6312*/
        goto LABEL_22; /*0x1030d6312*/
      }
      v15 = *(_QWORD *)(a1 + 16); /*0x1030d6286*/
      *a5 = 0; /*0x1030d628a*/
      v16 = *(_DWORD *)(v15 + 292); /*0x1030d6292*/
      if ( v16 != 0 ) /*0x1030d629c*/
      {
        v17 = *(_DWORD *)(v15 + 288); /*0x1030d629e*/
        v18 = "server"; /*0x1030d62b3*/
        if ( (*(_BYTE *)(v15 + 300) & 4) == 0 ) /*0x1030d62ba*/
          v18 = "curl"; /*0x1030d62ba*/
        v19 = (const char *)nghttp2_http2_strerror(a1: v16); /*0x1030d62c1*/
        Curl_failf(a1: a2, a2: "HTTP/2 stream %u reset by %s (error 0x%x %s)", v17, v18, v16, v19); /*0x1030d62df*/
        v12 = 56; /*0x1030d62e4*/
        goto LABEL_21; /*0x1030d62ea*/
      }
      v14 = 0; /*0x1030d62ec*/
    }
    else
    {
      v12 = Curl_bufq_cread(a1: (__int64 *)(v10 + 152), a2: v24, a3: a4, a4: a5); /*0x1030d6275*/
      if ( v12 != 0 ) /*0x1030d627a*/
        goto LABEL_21; /*0x1030d627a*/
      v14 = *a5; /*0x1030d6280*/
    }
    nghttp2_session_consume(a1: *(_QWORD *)v6, a2: *(unsigned int *)(v6 + 288), a3: v14); /*0x1030d62f8*/
    v12 = 0; /*0x1030d62fd*/
    goto LABEL_21; /*0x1030d62fd*/
  }
LABEL_22:
  if ( !Curl_bufq_is_empty(a1: v6 + 152) && (v7 == 81 || v7 == 0) ) /*0x1030d632e*/
    drain_tunnel(a1, a2, a3: v6 + 144); /*0x1030d6341*/
  *(_QWORD *)(*(_QWORD *)(a1 + 16) + 8LL) = v22; /*0x1030d634e*/
  return v7; /*0x1030d6355*/
}

// Address: 0x1030d6364 | Name: _cf_h2_proxy_cntrl
__int64 __fastcall cf_h2_proxy_cntrl(__int64 a1, __int64 a2, int a3)
{
  __int64 result; // rax
  __int64 v6; // r12
  __int64 v7; // r15
  unsigned int v8; // eax
  int is_fatal; // ecx

  result = 0; /*0x1030d6364*/
  if ( a3 == 258 ) /*0x1030d636c*/
  {
    v6 = *(_QWORD *)(a1 + 16); /*0x1030d637f*/
    v7 = *(_QWORD *)(v6 + 8); /*0x1030d6383*/
    *(_QWORD *)(v6 + 8) = a2; /*0x1030d6388*/
    if ( Curl_bufq_is_empty(a1: v6 + 216) /*0x1030d63bf*/
      || (v8 = nghttp2_session_resume_data(a1: *(_QWORD *)v6, a2: *(unsigned int *)(v6 + 288)),
          is_fatal = nghttp2_is_fatal(a1: v8),
          result = 55,
          is_fatal == 0) )
    {
      result = proxy_h2_progress_egress(a1); /*0x1030d63c4*/
    }
    *(_QWORD *)(*(_QWORD *)(a1 + 16) + 8LL) = a2; /*0x1030d63cd*/
    *(_QWORD *)(*(_QWORD *)(a1 + 16) + 8LL) = v7; /*0x1030d63d5*/
  }
  return result; /*0x1030d63e1*/
}

// Address: 0x1030d63e2 | Name: _cf_h2_proxy_is_alive
char __fastcall cf_h2_proxy_is_alive(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v3; // rax
  _QWORD *v5; // r14
  __int64 v6; // r13
  __int64 v7; // rdi
  char v10; // al
  int v11; // eax
  _QWORD v13[6]; // [rsp+0h] [rbp-30h] BYREF

  v13[0] = v3; /*0x1030d63ef*/
  v5 = *(_QWORD **)(a1 + 16); /*0x1030d63f3*/
  *a3 = 0; /*0x1030d63f7*/
  v6 = v5[1]; /*0x1030d63fa*/
  v5[1] = a2; /*0x1030d63fe*/
  if ( *v5 == 0 /*0x1030d641f*/
    || (v7 = *(_QWORD *)(a1 + 8)) == 0
    || (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v7 + 88LL))(a1: v7) == 0 )
  {
LABEL_8:
    v10 = 0; /*0x1030d645d*/
    goto LABEL_9; /*0x1030d645d*/
  }
  v10 = 1; /*0x1030d6421*/
  if ( *a3 == 1 ) /*0x1030d6428*/
  {
    *a3 = 0; /*0x1030d642a*/
    v11 = Curl_cf_recv_bufq(a1: *(_QWORD *)(a1 + 8), a2, a3: v5 + 2, a4: 0, a5: v13); /*0x1030d6440*/
    if ( v11 == 81 ) /*0x1030d6448*/
    {
      v10 = 1; /*0x1030d6478*/
      goto LABEL_9; /*0x1030d647a*/
    }
    if ( v11 == 0 && (unsigned int)proxy_h2_process_pending_input(a1, a2) == 0 ) /*0x1030d645b*/
    {
      v10 = proxy_h2_should_close_session(a1: v5) ^ 1; /*0x1030d6484*/
      goto LABEL_9; /*0x1030d6486*/
    }
    goto LABEL_8; /*0x1030d645b*/
  }
LABEL_9:
  *(_QWORD *)(*(_QWORD *)(a1 + 16) + 8LL) = v6; /*0x1030d645f*/
  return v10 & 1; /*0x1030d646d*/
}

// Address: 0x1030d6488 | Name: _cf_h2_proxy_query
__int64 __fastcall cf_h2_proxy_query(_QWORD *a1, __int64 a2, unsigned int a3, _DWORD *a4, _QWORD *a5)
{
  __int64 v9; // rax
  __int64 v10; // r12
  bool is_empty; // al
  __int64 v12; // rdi
  __int64 v14; // [rsp+0h] [rbp-30h]

  switch ( a3 ) /*0x1030d64a5*/
  {
    case 7u: /*0x1030d64a5*/
      v10 = a1[2]; /*0x1030d64d6*/
      v14 = a2; /*0x1030d64df*/
      if ( !Curl_bufq_is_empty(a1: v10 + 80) || (is_empty = Curl_bufq_is_empty(a1: v10 + 216), a2 = v14, !is_empty) ) /*0x1030d6501*/
      {
        *a4 = 1; /*0x1030d652c*/
        return 0; /*0x1030d652c*/
      }
      break;
    case 0xFu: /*0x1030d64a5*/
      *a5 = 0; /*0x1030d64cd*/
      return 0; /*0x1030d64d4*/
    case 0xBu: /*0x1030d64a5*/
      v9 = a1[3]; /*0x1030d64b3*/
      *a4 = *(unsigned __int16 *)(v9 + 304); /*0x1030d64be*/
      *a5 = *(_QWORD *)(v9 + 288); /*0x1030d64c8*/
      return 0; /*0x1030d6533*/
    default:
      break; /*0x1030d6503*/
  }
  v12 = a1[1]; /*0x1030d6503*/
  if ( v12 != 0 ) /*0x1030d650a*/
    return (*(__int64 (__fastcall **)(__int64, __int64, _QWORD, _DWORD *, _QWORD *))(*(_QWORD *)v12 + 104LL))( /*0x1030d652a*/
             a1: v12,
             a2,
             a3,
             a4,
             a5);
  else
    return 48; /*0x1030d6544*/
}

// Address: 0x1030d654b | Name: _Curl_cf_h2_proxy_insert_after
__int64 __fastcall Curl_cf_h2_proxy_insert_after(__int64 a1)
{
  void *v2; // rax
  void *v3; // r14
  unsigned int v4; // eax
  unsigned int v5; // r15d
  _QWORD v7[4]; // [rsp+0h] [rbp-20h] BYREF

  v7[0] = 0; /*0x1030d6558*/
  v2 = Curl_ccalloc(__count: 1u, __size: 0x140u); /*0x1030d6571*/
  if ( v2 != nullptr ) /*0x1030d6576*/
  {
    v3 = v2; /*0x1030d6578*/
    v4 = Curl_cf_create(a1: v7, a2: &Curl_cft_h2_proxy, a3: v2); /*0x1030d6589*/
    if ( v4 != 0 ) /*0x1030d6590*/
    {
      v5 = v4; /*0x1030d6592*/
      cf_h2_proxy_ctx_clear(a1: v3); /*0x1030d6598*/
      Curl_cfree(a1: v3); /*0x1030d65a7*/
    }
    else
    {
      Curl_conn_cf_insert_after(a1, a2: v7[0]); /*0x1030d65ba*/
      return 0; /*0x1030d65bf*/
    }
  }
  else
  {
    return 27; /*0x1030d65ab*/
  }
  return v5; /*0x1030d65c9*/
}

// Address: 0x1030d6c5a | Name: _cf_h2_proxy_ctx_clear
__int64 __fastcall cf_h2_proxy_ctx_clear(_QWORD *a1)
{
  __int64 v2; // r14
  __int64 result; // rax

  v2 = a1[1]; /*0x1030d6c67*/
  if ( *a1 != 0 ) /*0x1030d6c6e*/
    nghttp2_session_del(); /*0x1030d6c70*/
  Curl_bufq_free(a1: (__int64)(a1 + 2)); /*0x1030d6c79*/
  Curl_bufq_free(a1: (__int64)(a1 + 10)); /*0x1030d6c82*/
  tunnel_stream_clear(a1: a1 + 18); /*0x1030d6c8e*/
  result = __bzero((__int64)a1, a2: 320); /*0x1030d6c9b*/
  a1[1] = v2; /*0x1030d6ca0*/
  return result; /*0x1030d6ca4*/
}

// Address: 0x1030d6cda | Name: _cf_haproxy_destroy
void __fastcall cf_haproxy_destroy(__int64 a1)
{
  char *v1; // rbx

  v1 = *(char **)(a1 + 16); /*0x1030d6ce0*/
  if ( v1 != nullptr ) /*0x1030d6ce7*/
  {
    curlx_dyn_free(a1: v1 + 8); /*0x1030d6ced*/
    Curl_cfree(a1: v1); /*0x1030d6d02*/
  }
}

// Address: 0x1030d6d0b | Name: _cf_haproxy_connect
__int64 __fastcall cf_haproxy_connect(__int64 a1, __int64 a2, bool *a3)
{
  _DWORD *v6; // r12
  __int64 result; // rax
  __int64 v8; // r13
  __int64 v9; // rax
  __int64 v10; // r13
  __int64 v11; // rax
  __int64 v12; // rax
  bool v13; // cl
  _WORD *v14; // rcx
  int v15; // r13d
  const char *v16; // rdx
  __int64 v17; // [rsp+10h] [rbp-B0h]
  _DWORD *v18; // [rsp+18h] [rbp-A8h]
  char v19; // [rsp+27h] [rbp-99h] BYREF
  _QWORD v20[5]; // [rsp+28h] [rbp-98h] BYREF
  _WORD v21[29]; // [rsp+56h] [rbp-6Ah] BYREF

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d6d34*/
  {
    *a3 = true; /*0x1030d6e18*/
    return 0; /*0x1030d6e1c*/
  }
  else
  {
    v6 = *(_DWORD **)(a1 + 16); /*0x1030d6d40*/
    result = (*(__int64 (__fastcall **)(_QWORD, __int64, bool *))(**(_QWORD **)(a1 + 8) + 24LL))( /*0x1030d6d4e*/
               a1: *(_QWORD *)(a1 + 8),
               a2,
               a3);
    if ( (_DWORD)result == 0 ) /*0x1030d6d53*/
    {
      result = 0; /*0x1030d6d59*/
      if ( *a3 ) /*0x1030d6d5b*/
      {
        if ( *v6 != 1 ) /*0x1030d6d6c*/
        {
          if ( *v6 != 0 ) /*0x1030d6d70*/
          {
LABEL_21:
            curlx_dyn_free(a1: v6 + 2); /*0x1030d6e9d*/
            goto LABEL_22; /*0x1030d6ea2*/
          }
          v8 = *(_QWORD *)(a1 + 16); /*0x1030d6d76*/
          if ( *(_QWORD *)(*(_QWORD *)(a1 + 24) + 776LL) != 0 ) /*0x1030d6d86*/
          {
            result = curlx_dyn_addn(a1: v8 + 8, a2: "PROXY UNKNOWN\r\n", a3: 15); /*0x1030d6d9f*/
          }
          else
          {
            result = Curl_conn_cf_get_ip_info(a1: *(_QWORD *)(a1 + 8), a2, a3: &v19, a4: v20); /*0x1030d6e59*/
            if ( (_DWORD)result != 0 ) /*0x1030d6e60*/
              goto LABEL_17; /*0x1030d6e60*/
            v14 = *(_WORD **)(a2 + 1560); /*0x1030d6ec4*/
            if ( v14 == nullptr ) /*0x1030d6ed2*/
              v14 = v21; /*0x1030d6ed2*/
            v15 = v8 + 8; /*0x1030d6ed6*/
            v16 = "TCP4"; /*0x1030d6ee1*/
            if ( v19 != 0 ) /*0x1030d6eef*/
              v16 = "TCP6"; /*0x1030d6eef*/
            result = curlx_dyn_addf( /*0x1030d6f12*/
                       a1: v15,
                       a2: (unsigned int)"PROXY %s %s %s %i %i\r\n",
                       a3: (_DWORD)v16,
                       a4: (_DWORD)v14,
                       a5: (unsigned int)v20,
                       a6: v21[24],
                       a7: v21[23]);
          }
          if ( (_DWORD)result != 0 ) /*0x1030d6da6*/
          {
LABEL_17:
            v13 = false; /*0x1030d6e62*/
LABEL_23:
            *a3 = v13; /*0x1030d6eb1*/
            *(_BYTE *)(a1 + 36) = v13 | *(_BYTE *)(a1 + 36) & 0xFE; /*0x1030d6ebc*/
            return result; /*0x1030d6ebf*/
          }
          *v6 = 1; /*0x1030d6dac*/
        }
        v9 = curlx_dyn_len(a1: v6 + 2); /*0x1030d6dbc*/
        if ( v9 == 0 ) /*0x1030d6dc4*/
        {
LABEL_20:
          *v6 = 2; /*0x1030d6e95*/
          goto LABEL_21; /*0x1030d6e95*/
        }
        v17 = *(_QWORD *)(a1 + 8); /*0x1030d6dce*/
        v18 = v6 + 2; /*0x1030d6dd5*/
        v10 = v9; /*0x1030d6ddf*/
        v11 = curlx_dyn_uptr(a1: v6 + 2); /*0x1030d6de2*/
        result = Curl_conn_cf_send(a1: v17, a2, a3: v11, a4: v10, a5: 0, a6: v20); /*0x1030d6e01*/
        if ( (_DWORD)result == 81 ) /*0x1030d6e09*/
        {
          v20[0] = 0; /*0x1030d6e66*/
          v12 = 0; /*0x1030d6e71*/
LABEL_19:
          curlx_dyn_tail(a1: v18, a2: v10 - v12); /*0x1030d6e73*/
          if ( curlx_dyn_len(a1: v18) != 0 ) /*0x1030d6e93*/
          {
LABEL_22:
            v13 = *v6 == 2; /*0x1030d6ea7*/
            result = 0; /*0x1030d6eaf*/
            goto LABEL_23; /*0x1030d6eaf*/
          }
          goto LABEL_20; /*0x1030d6e93*/
        }
        if ( (_DWORD)result == 0 ) /*0x1030d6e0d*/
        {
          v12 = v20[0]; /*0x1030d6e0f*/
          goto LABEL_19; /*0x1030d6e16*/
        }
        goto LABEL_17; /*0x1030d6e0d*/
      }
    }
  }
  return result; /*0x1030d6e32*/
}

// Address: 0x1030d6f21 | Name: _cf_haproxy_close
__int64 __fastcall cf_haproxy_close(__int64 a1, __int64 a2)
{
  _DWORD *v4; // rdi
  __int64 result; // rax
  __int64 v6; // rdi

  *(_BYTE *)(a1 + 36) &= ~1u; /*0x1030d6f2b*/
  v4 = *(_DWORD **)(a1 + 16); /*0x1030d6f32*/
  *v4 = 0; /*0x1030d6f36*/
  result = curlx_dyn_reset(a1: v4 + 2); /*0x1030d6f40*/
  v6 = *(_QWORD *)(a1 + 8); /*0x1030d6f45*/
  if ( v6 != 0 ) /*0x1030d6f4c*/
    return (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v6 + 32LL))(a1: v6, a2); /*0x1030d6f5c*/
  return result; /*0x1030d6f59*/
}

// Address: 0x1030d6f63 | Name: _cf_haproxy_adjust_pollset
__int64 __fastcall cf_haproxy_adjust_pollset(__int64 a1, __int64 a2, __int64 a3)
{
  unsigned int socket; // eax

  if ( (*(_BYTE *)(*(_QWORD *)(a1 + 8) + 36LL) & 1) == 0 || (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d6f71*/
    return 0; /*0x1030d6fa1*/
  socket = Curl_conn_cf_get_socket(a1); /*0x1030d6f80*/
  return Curl_pollset_change(a1: a2, a2: a3, a3: socket, a4: 2, a5: 1); /*0x1030d6fa3*/
}

// Address: 0x1030d6fa4 | Name: _Curl_cf_haproxy_insert_after
__int64 __fastcall Curl_cf_haproxy_insert_after(__int64 a1)
{
  _DWORD *v2; // rax
  void *v3; // r14
  _DWORD *v4; // r12
  unsigned int v5; // eax
  unsigned int v6; // r15d
  _QWORD v8[5]; // [rsp+8h] [rbp-28h] BYREF

  v8[0] = 0; /*0x1030d6fb6*/
  v2 = Curl_ccalloc(__count: 1u, __size: 0x28u); /*0x1030d6fcf*/
  if ( v2 != nullptr ) /*0x1030d6fd4*/
  {
    v3 = v2; /*0x1030d6fd6*/
    *v2 = 0; /*0x1030d6fd9*/
    v4 = v2 + 2; /*0x1030d6fe2*/
    curlx_dyn_init(a1: v2 + 2, a2: 2048); /*0x1030d6fee*/
    v5 = Curl_cf_create(a1: v8, a2: &Curl_cft_haproxy, a3: v3); /*0x1030d7001*/
    if ( v5 != 0 ) /*0x1030d7008*/
    {
      v6 = v5; /*0x1030d700a*/
      curlx_dyn_free(a1: v4); /*0x1030d7010*/
      Curl_cfree(a1: v3); /*0x1030d701f*/
    }
    else
    {
      Curl_conn_cf_insert_after(a1, a2: v8[0]); /*0x1030d7032*/
      return 0; /*0x1030d7037*/
    }
  }
  else
  {
    return 27; /*0x1030d7023*/
  }
  return v6; /*0x1030d703d*/
}

// Address: 0x1030d704c | Name: _cf_hc_destroy
void __fastcall cf_hc_destroy(__int64 a1)
{
  void *v1; // rbx

  v1 = *(void **)(a1 + 16); /*0x1030d7052*/
  cf_hc_reset(a1); /*0x1030d7056*/
  Curl_cfree(a1: v1); /*0x1030d706b*/
}

// Address: 0x1030d706d | Name: _cf_hc_connect
__int64 __fastcall cf_hc_connect(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v5; // rbx
  __int64 result; // rax
  __int64 v8; // rdi
  unsigned int v9; // eax
  __int64 v10; // r13
  __int64 v11; // rax
  __int64 v12; // rcx
  __int64 v13; // r13
  __int64 v14; // rax
  __int64 v15; // rdi
  unsigned __int64 v16; // rcx
  __int64 v17; // rdi
  __int64 v18; // r13
  unsigned int v19; // eax
  _DWORD *v20; // rdx
  __int64 v21; // rax
  unsigned __int64 i; // rsi
  unsigned int *v23; // rdx
  __int64 v24; // [rsp+8h] [rbp-48h] BYREF
  int v25; // [rsp+10h] [rbp-40h]
  __int64 v26; // [rsp+18h] [rbp-38h]
  unsigned int v27; // [rsp+24h] [rbp-2Ch]

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d7085*/
  {
    *a3 = 1; /*0x1030d715f*/
  }
  else
  {
    v5 = *(_QWORD *)(a1 + 16); /*0x1030d708e*/
    *a3 = 0; /*0x1030d7092*/
    result = 0; /*0x1030d7098*/
    switch ( *(_DWORD *)v5 ) /*0x1030d70b5*/
    {
      case 0: /*0x1030d70b5*/
        *(_OWORD *)(v5 + 8) = *(_OWORD *)Curl_pgrs_now(a1: a2); /*0x1030d70c2*/
        cf_hc_baller_init(a1: v5 + 32, a2: a1, a3: a2, a4: *(unsigned __int8 *)(v5 + 76)); /*0x1030d70d4*/
        if ( *(_QWORD *)(v5 + 144) >= 2u ) /*0x1030d70e1*/
          Curl_expire(a1: a2, a2: *(_QWORD *)(v5 + 152), a3: 13); /*0x1030d70f2*/
        *(_DWORD *)v5 = 1; /*0x1030d70f7*/
        goto LABEL_6; /*0x1030d70f7*/
      case 1: /*0x1030d70b5*/
LABEL_6:
        v8 = *(_QWORD *)(v5 + 40); /*0x1030d70fd*/
        v9 = 0; /*0x1030d7101*/
        if ( v8 != 0 && *(_DWORD *)(v5 + 48) == 0 ) /*0x1030d710c*/
        {
          v10 = *(_QWORD *)(a1 + 8); /*0x1030d710e*/
          *(_QWORD *)(a1 + 8) = v8; /*0x1030d7112*/
          v9 = Curl_conn_cf_connect(a1: v8, a2, a3); /*0x1030d711c*/
          *(_DWORD *)(v5 + 48) = v9; /*0x1030d7121*/
          *(_QWORD *)(v5 + 40) = *(_QWORD *)(a1 + 8); /*0x1030d7128*/
          *(_QWORD *)(a1 + 8) = v10; /*0x1030d712c*/
          if ( v9 == 0 ) /*0x1030d7132*/
          {
            v9 = 0; /*0x1030d7138*/
            if ( *a3 == 1 ) /*0x1030d713d*/
              return baller_connected(a1, a2, a3: v5 + 32); /*0x1030d715a*/
          }
        }
        v27 = v9; /*0x1030d7174*/
        v11 = Curl_pgrs_now(a1: a2); /*0x1030d717a*/
        v12 = *(_QWORD *)v11; /*0x1030d717f*/
        LODWORD(v11) = *(_DWORD *)(v11 + 8); /*0x1030d7182*/
        v24 = v12; /*0x1030d7185*/
        v25 = v11; /*0x1030d7189*/
        v13 = *(_QWORD *)(a1 + 16); /*0x1030d718c*/
        if ( *(_QWORD *)(v13 + 144) >= 2u && *(_QWORD *)(v13 + 96) == 0 ) /*0x1030d71a3*/
        {
          if ( *(_DWORD *)(v13 + 48) != 0 ) /*0x1030d71ae*/
            goto LABEL_26; /*0x1030d71ae*/
          v14 = curlx_ptimediff_ms(a1: &v24, a2: v13 + 8); /*0x1030d71bc*/
          if ( v14 >= *(_QWORD *)(v13 + 160) ) /*0x1030d71c8*/
            goto LABEL_26; /*0x1030d71c8*/
          if ( v14 >= *(_QWORD *)(v13 + 152) ) /*0x1030d71d1*/
          {
            v15 = *(_QWORD *)(v13 + 40); /*0x1030d71d7*/
            if ( v15 != 0 && *(int *)(v13 + 72) < 0 ) /*0x1030d71e5*/
            {
              v26 = v14; /*0x1030d71eb*/
              (*(void (__fastcall **)(__int64, __int64, __int64, __int64, _QWORD))(*(_QWORD *)v15 + 104LL))( /*0x1030d71fd*/
                a1: v15,
                a2,
                a3: 2,
                a4: v13 + 72,
                a5: 0);
              v14 = v26; /*0x1030d7200*/
            }
            if ( *(int *)(v13 + 72) < 0 ) /*0x1030d7209*/
LABEL_26:
              cf_hc_baller_init(a1: v5 + 88, a2: a1, a3: a2, a4: *(unsigned __int8 *)(v5 + 132)); /*0x1030d7243*/
            else
              Curl_expire(a1: a2, a2: *(_QWORD *)(v13 + 160) - v14, a3: 13); /*0x1030d721d*/
          }
        }
        v16 = *(_QWORD *)(v5 + 144); /*0x1030d7259*/
        if ( v16 < 2 ) /*0x1030d7264*/
          goto LABEL_34; /*0x1030d7264*/
        v17 = *(_QWORD *)(v5 + 96); /*0x1030d7266*/
        if ( v17 != 0 && *(_DWORD *)(v5 + 104) == 0 ) /*0x1030d7273*/
        {
          v18 = *(_QWORD *)(a1 + 8); /*0x1030d7275*/
          *(_QWORD *)(a1 + 8) = v17; /*0x1030d7279*/
          v19 = Curl_conn_cf_connect(a1: v17, a2, a3); /*0x1030d7283*/
          *(_DWORD *)(v5 + 104) = v19; /*0x1030d7288*/
          *(_QWORD *)(v5 + 96) = *(_QWORD *)(a1 + 8); /*0x1030d728f*/
          *(_QWORD *)(a1 + 8) = v18; /*0x1030d7293*/
          v27 = v19; /*0x1030d7297*/
          if ( v19 == 0 ) /*0x1030d729c*/
          {
            v27 = 0; /*0x1030d729e*/
            if ( *a3 == 1 ) /*0x1030d72a9*/
              return baller_connected(a1, a2, a3: v5 + 88); /*0x1030d72bd*/
          }
        }
        v16 = *(_QWORD *)(v5 + 144); /*0x1030d72c2*/
LABEL_34:
        if ( v16 == 0 ) /*0x1030d72cc*/
          goto LABEL_41; /*0x1030d72cc*/
        v20 = (_DWORD *)(v5 + 48); /*0x1030d72ce*/
        v21 = 0; /*0x1030d72d2*/
        for ( i = v16; i != 0; --i ) /*0x1030d72d4*/
        {
          v21 -= (*v20 == 0) - 1LL; /*0x1030d72da*/
          v20 += 14; /*0x1030d72de*/
        }
        if ( v21 == v16 ) /*0x1030d72ea*/
        {
          v23 = (unsigned int *)(v5 + 48); /*0x1030d72ec*/
          do /*0x1030d72fd*/
          {
            result = *v23; /*0x1030d72f0*/
            if ( (_DWORD)result != 0 ) /*0x1030d72f4*/
              goto LABEL_42; /*0x1030d72f4*/
            v23 += 14; /*0x1030d72f6*/
            --v16; /*0x1030d72fa*/
          }
          while ( v16 != 0 ); /*0x1030d72fd*/
LABEL_41:
          result = v27; /*0x1030d72ff*/
LABEL_42:
          *(_DWORD *)v5 = 3; /*0x1030d7302*/
          return result; /*0x1030d7308*/
        }
        *a3 = 0; /*0x1030d730d*/
        break; /*0x1030d7311*/
      case 2: /*0x1030d70b5*/
        *(_BYTE *)(a1 + 36) |= 1u; /*0x1030d7224*/
        *a3 = 1; /*0x1030d7229*/
        return result; /*0x1030d722d*/
      case 3: /*0x1030d70b5*/
        result = *(unsigned int *)(v5 + 24); /*0x1030d7232*/
        *(_BYTE *)(a1 + 36) &= ~1u; /*0x1030d7235*/
        *a3 = 0; /*0x1030d723a*/
        return result; /*0x1030d723e*/
      default:
        return result;
    }
  }
  return 0; /*0x1030d714c*/
}

// Address: 0x1030d7328 | Name: _cf_hc_close
__int64 __fastcall cf_hc_close(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  __int64 v5; // rdi

  result = cf_hc_reset(a1); /*0x1030d7335*/
  *(_BYTE *)(a1 + 36) &= ~1u; /*0x1030d733a*/
  v5 = *(_QWORD *)(a1 + 8); /*0x1030d733f*/
  if ( v5 != 0 ) /*0x1030d7346*/
  {
    (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v5 + 32LL))(a1: v5, a2); /*0x1030d7352*/
    return Curl_conn_cf_discard_chain(a1: a1 + 8, a2); /*0x1030d735f*/
  }
  return result; /*0x1030d735b*/
}

// Address: 0x1030d7369 | Name: _cf_hc_shutdown
__int64 __fastcall cf_hc_shutdown(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v3; // rax
  __int64 v5; // r12
  _BYTE *v7; // r13
  unsigned __int64 v8; // r15
  __int64 v9; // rdi
  int v10; // eax
  unsigned __int64 v11; // rcx
  __int64 result; // rax
  _BYTE *v13; // rdx
  char v14; // si
  unsigned __int64 i; // rdi
  _DWORD *v16; // r12
  _BYTE v17[41]; // [rsp+1h] [rbp-29h] BYREF

  v17[0] = HIBYTE(v3); /*0x1030d7376*/
  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 || *(_QWORD *)((v5 = *(_QWORD *)(a1 + 16)) + 144) == 0 ) /*0x1030d7391*/
  {
    *a3 = 1; /*0x1030d7439*/
    return 0; /*0x1030d743c*/
  }
  else
  {
    v7 = (_BYTE *)(v5 + 84); /*0x1030d739a*/
    v8 = 0; /*0x1030d739f*/
    do /*0x1030d73ef*/
    {
      v17[0] = 0; /*0x1030d73a2*/
      v9 = *(_QWORD *)(v7 - 44); /*0x1030d73a6*/
      if ( v9 != 0 && *((_DWORD *)v7 - 9) == 0 && (*v7 & 1) == 0 ) /*0x1030d73bb*/
      {
        v10 = (*(__int64 (__fastcall **)(__int64, __int64, _BYTE *))(*(_QWORD *)v9 + 40LL))(a1: v9, a2, a3: v17); /*0x1030d73c7*/
        *((_DWORD *)v7 - 9) = v10; /*0x1030d73ca*/
        if ( v10 != 0 || v17[0] == 1 ) /*0x1030d73d6*/
          *v7 |= 1u; /*0x1030d73d8*/
      }
      ++v8; /*0x1030d73dd*/
      v11 = *(_QWORD *)(v5 + 144); /*0x1030d73e0*/
      v7 += 56; /*0x1030d73e8*/
    }
    while ( v8 < v11 ); /*0x1030d73ef*/
    *a3 = 1; /*0x1030d73f1*/
    result = 0; /*0x1030d73f4*/
    if ( v11 != 0 ) /*0x1030d73f9*/
    {
      v13 = (_BYTE *)(v5 + 84); /*0x1030d73fb*/
      v14 = 1; /*0x1030d7400*/
      for ( i = v11; i != 0; --i ) /*0x1030d7403*/
      {
        if ( (*v13 & 1) == 0 ) /*0x1030d7409*/
        {
          *a3 = 0; /*0x1030d740b*/
          v14 = 0; /*0x1030d740e*/
        }
        v13 += 56; /*0x1030d7410*/
      }
      if ( (v14 & 1) != 0 ) /*0x1030d741d*/
      {
        v16 = (_DWORD *)(v5 + 48); /*0x1030d741f*/
        result = 0; /*0x1030d7423*/
        do /*0x1030d7435*/
        {
          if ( *v16 != 0 ) /*0x1030d742b*/
            result = (unsigned int)*v16; /*0x1030d742b*/
          v16 += 14; /*0x1030d742e*/
          --v11; /*0x1030d7432*/
        }
        while ( v11 != 0 ); /*0x1030d7435*/
      }
    }
  }
  return result; /*0x1030d7442*/
}

// Address: 0x1030d744d | Name: _cf_hc_adjust_pollset
__int64 __fastcall cf_hc_adjust_pollset(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  __int64 v4; // r15
  unsigned __int64 v5; // rcx
  _DWORD *v8; // r12
  unsigned __int64 v9; // r13
  __int64 v10; // rdi

  result = 0; /*0x1030d744d*/
  if ( (*(_BYTE *)(a1 + 36) & 1) == 0 ) /*0x1030d7453*/
  {
    v4 = *(_QWORD *)(a1 + 16); /*0x1030d7463*/
    v5 = *(_QWORD *)(v4 + 144); /*0x1030d7467*/
    if ( v5 != 0 ) /*0x1030d7471*/
    {
      v8 = (_DWORD *)(v4 + 48); /*0x1030d7479*/
      v9 = 1; /*0x1030d747d*/
      do /*0x1030d74b6*/
      {
        v10 = *((_QWORD *)v8 - 1); /*0x1030d7483*/
        result = 0; /*0x1030d7488*/
        if ( v10 != 0 && *v8 == 0 ) /*0x1030d7494*/
        {
          result = Curl_conn_cf_adjust_pollset(a1: v10, a2, a3); /*0x1030d749c*/
          v5 = *(_QWORD *)(v4 + 144); /*0x1030d74a1*/
        }
        if ( v9 >= v5 ) /*0x1030d74ab*/
          break; /*0x1030d74ab*/
        ++v9; /*0x1030d74ad*/
        v8 += 14; /*0x1030d74b0*/
      }
      while ( (_DWORD)result == 0 ); /*0x1030d74b6*/
    }
  }
  return result; /*0x1030d74c6*/
}

// Address: 0x1030d74c7 | Name: _cf_hc_data_pending
char __fastcall cf_hc_data_pending(__int64 a1, __int64 a2)
{
  __int64 v3; // r14
  unsigned __int64 v4; // rax
  _DWORD *v5; // r15
  unsigned __int64 v6; // r12
  __int64 v7; // rdi

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d74d9*/
    return (*(__int64 (__fastcall **)(_QWORD, __int64))(**(_QWORD **)(a1 + 8) + 56LL))(a1: *(_QWORD *)(a1 + 8), a2); /*0x1030d7542*/
  v3 = *(_QWORD *)(a1 + 16); /*0x1030d74db*/
  v4 = *(_QWORD *)(v3 + 144); /*0x1030d74df*/
  if ( v4 == 0 ) /*0x1030d74e9*/
    return 0; /*0x1030d752b*/
  v5 = (_DWORD *)(v3 + 48); /*0x1030d74eb*/
  v6 = 0; /*0x1030d74ef*/
  while ( 1 ) /*0x1030d74f2*/
  {
    v7 = *((_QWORD *)v5 - 1); /*0x1030d74f2*/
    if ( v7 != 0 && *v5 == 0 ) /*0x1030d74ff*/
    {
      if ( (*(unsigned __int8 (__fastcall **)(__int64, __int64))(*(_QWORD *)v7 + 56LL))(a1: v7, a2) != 0 ) /*0x1030d750c*/
        break; /*0x1030d750c*/
      v4 = *(_QWORD *)(v3 + 144); /*0x1030d750e*/
    }
    ++v6; /*0x1030d7515*/
    v5 += 14; /*0x1030d7518*/
    if ( v6 >= v4 ) /*0x1030d751f*/
      return 0; /*0x1030d751f*/
  }
  return 1; /*0x1030d7523*/
}

// Address: 0x1030d7548 | Name: _cf_hc_cntrl
__int64 __fastcall cf_hc_cntrl(__int64 a1, __int64 a2, unsigned int a3, unsigned int a4, __int64 a5)
{
  __int64 result; // rax
  __int64 v6; // r13
  _DWORD *v9; // rbx
  unsigned __int64 v10; // r14
  __int64 v11; // rdi

  result = 0; /*0x1030d7560*/
  if ( (*(_BYTE *)(a1 + 36) & 1) == 0 ) /*0x1030d7566*/
  {
    v6 = *(_QWORD *)(a1 + 16); /*0x1030d7568*/
    if ( *(_QWORD *)(v6 + 144) != 0 ) /*0x1030d7574*/
    {
      v9 = (_DWORD *)(v6 + 48); /*0x1030d757c*/
      v10 = 0; /*0x1030d7580*/
      while ( 1 ) /*0x1030d7583*/
      {
        v11 = *((_QWORD *)v9 - 1); /*0x1030d7583*/
        if ( v11 != 0 && *v9 == 0 ) /*0x1030d758f*/
        {
          result = Curl_conn_cf_cntrl(a1: v11, a2, a3: 0, a4: a3, a5: a4, a6: a5); /*0x1030d75a1*/
          if ( (_DWORD)result != 81 && (_DWORD)result != 0 ) /*0x1030d75ad*/
            break; /*0x1030d75ad*/
        }
        ++v10; /*0x1030d75af*/
        v9 += 14; /*0x1030d75b2*/
        if ( v10 >= *(_QWORD *)(v6 + 144) ) /*0x1030d75bd*/
          return 0; /*0x1030d75bf*/
      }
    }
  }
  return result; /*0x1030d75c1*/
}

// Address: 0x1030d75d0 | Name: _cf_hc_query
__int64 __fastcall cf_hc_query(__int64 a1, __int64 a2, int a3, _DWORD *a4, _QWORD *a5)
{
  __int64 v5; // r9
  unsigned __int64 v6; // rax
  _DWORD *v7; // r15
  unsigned __int64 v8; // rbx
  int v9; // r13d
  _QWORD *v10; // r14
  __int64 v11; // r12
  __int64 v12; // rdi
  __int64 v14; // rdx
  _QWORD *v15; // rbx
  int v16; // edx
  __int64 v18; // [rsp+8h] [rbp-38h]

  v5 = a1; /*0x1030d75e1*/
  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d75e8*/
    goto LABEL_12; /*0x1030d75e8*/
  if ( a3 == 4 ) /*0x1030d75f1*/
  {
    v14 = 4; /*0x1030d76ac*/
    goto LABEL_17; /*0x1030d76ac*/
  }
  if ( a3 == 5 ) /*0x1030d75fa*/
  {
    v14 = 5; /*0x1030d76a2*/
LABEL_17:
    v15 = a5; /*0x1030d76b1*/
    *a5 = cf_get_max_baller_time(a1, a2, a3: v14, a4, a5, a6: a1); /*0x1030d76b9*/
    *((_DWORD *)v15 + 2) = v16; /*0x1030d76bc*/
    return 0; /*0x1030d76bc*/
  }
  if ( a3 != 7 || (v18 = *(_QWORD *)(a1 + 16), (v6 = *(_QWORD *)(v18 + 144)) == 0) ) /*0x1030d7617*/
  {
LABEL_12:
    v12 = *(_QWORD *)(v5 + 8); /*0x1030d7678*/
    if ( v12 != 0 ) /*0x1030d767f*/
      return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v12 + 104LL))(a1: v12); /*0x1030d7696*/
    else
      return 48; /*0x1030d7698*/
  }
  v7 = (_DWORD *)(v18 + 48); /*0x1030d761d*/
  v8 = 0; /*0x1030d7621*/
  while ( 1 ) /*0x1030d762b*/
  {
    if ( *((_QWORD *)v7 - 1) != 0 && *v7 == 0 ) /*0x1030d7638*/
    {
      v9 = a3; /*0x1030d763a*/
      v10 = a5; /*0x1030d763d*/
      v11 = a2; /*0x1030d7640*/
      if ( (unsigned __int8)Curl_conn_cf_needs_flush() != 0 ) /*0x1030d764a*/
        break; /*0x1030d764a*/
      v6 = *(_QWORD *)(v18 + 144); /*0x1030d7654*/
      a5 = v10; /*0x1030d765b*/
      a2 = v11; /*0x1030d765e*/
      a3 = v9; /*0x1030d7665*/
      v5 = a1; /*0x1030d7668*/
    }
    ++v8; /*0x1030d766c*/
    v7 += 14; /*0x1030d766f*/
    if ( v8 >= v6 ) /*0x1030d7676*/
      goto LABEL_12; /*0x1030d7676*/
  }
  *a4 = 1; /*0x1030d76d4*/
  return 0; /*0x1030d7688*/
}

// Address: 0x1030d76dc | Name: _Curl_cf_https_setup
__int64 __fastcall Curl_cf_https_setup(_BYTE *a1, __int64 a2, unsigned int a3, char a4)
{
  unsigned int v4; // r12d
  int v7; // eax
  char v8; // r13
  int *v9; // rdi
  unsigned __int64 v10; // rbx
  int v11; // eax
  char v12; // al
  unsigned __int64 v13; // rsi
  unsigned int may_http3; // eax
  unsigned __int64 v15; // rsi
  unsigned __int64 v16; // rcx
  int v17; // eax
  char v18; // r12
  char *v19; // rax
  char *v20; // r13
  char *v21; // rax
  __int64 v22; // rcx
  int v23; // r8d
  __int64 v24; // r13
  int *v26; // [rsp+0h] [rbp-50h]
  __int64 v28; // [rsp+10h] [rbp-40h] BYREF
  int v29; // [rsp+18h] [rbp-38h] BYREF
  char v30; // [rsp+1Ch] [rbp-34h] BYREF

  v4 = 0; /*0x1030d76fb*/
  if ( (*(_BYTE *)(a2 + 730) & 8) == 0 ) /*0x1030d7705*/
    return v4; /*0x1030d7705*/
  v7 = (unsigned __int8)a1[4083]; /*0x1030d7711*/
  v4 = 0; /*0x1030d7718*/
  v8 = 1; /*0x1030d771b*/
  v9 = &v29; /*0x1030d771e*/
  if ( v7 != 0 ) /*0x1030d7727*/
  {
    if ( ((unsigned __int8)v7 & a1[4082]) == 0 ) /*0x1030d7730*/
    {
      v10 = 0; /*0x1030d774e*/
      goto LABEL_16; /*0x1030d774e*/
    }
    if ( v7 == 4 ) /*0x1030d7735*/
    {
      v8 = 1; /*0x1030d7781*/
      if ( (unsigned int)Curl_conn_may_http3(a1, a2, a3: *(unsigned __int8 *)(a2 + 816)) != 0 ) /*0x1030d7786*/
      {
        v10 = 0; /*0x1030d778c*/
        v9 = &v29; /*0x1030d778e*/
        goto LABEL_16; /*0x1030d778e*/
      }
      v11 = 32; /*0x1030d7983*/
    }
    else
    {
      v10 = 0; /*0x1030d7737*/
      if ( v7 == 2 ) /*0x1030d773c*/
      {
        v11 = 16; /*0x1030d7752*/
      }
      else
      {
        if ( v7 != 1 ) /*0x1030d7741*/
          goto LABEL_16; /*0x1030d7741*/
        v11 = 8; /*0x1030d7743*/
      }
      v8 = 0; /*0x1030d7757*/
    }
    v9 = (int *)&v30; /*0x1030d775a*/
    v29 = v11; /*0x1030d775e*/
    v10 = 1; /*0x1030d7761*/
    a4 = v8; /*0x1030d7766*/
    v8 = 0; /*0x1030d7769*/
  }
  else
  {
    v10 = 0; /*0x1030d774a*/
  }
LABEL_16:
  v12 = a1[4081]; /*0x1030d7792*/
  if ( (v12 & 4) == 0 ) /*0x1030d779b*/
    goto LABEL_23; /*0x1030d779b*/
  v13 = 0; /*0x1030d779d*/
  while ( v13 < v10 ) /*0x1030d77a2*/
  {
    v13 = 1; /*0x1030d77a4*/
    if ( (a4 & 1) != 0 ) /*0x1030d77ac*/
      goto LABEL_20; /*0x1030d77ac*/
  }
  v26 = v9; /*0x1030d77b3*/
  may_http3 = Curl_conn_may_http3(a1, a2, a3: *(unsigned __int8 *)(a2 + 816)); /*0x1030d77c5*/
  if ( may_http3 == 0 ) /*0x1030d77cc*/
  {
    *v26 = 32; /*0x1030d795e*/
    v10 = 2; /*0x1030d7964*/
    if ( v8 != 0 ) /*0x1030d796c*/
    {
      v12 = a1[4081]; /*0x1030d7972*/
      v10 = 1; /*0x1030d7979*/
LABEL_20:
      v4 = 0; /*0x1030d77ae*/
      goto LABEL_23; /*0x1030d77b1*/
    }
    goto LABEL_37; /*0x1030d796c*/
  }
  v4 = may_http3; /*0x1030d77d2*/
  v12 = a1[4081]; /*0x1030d77d5*/
  if ( v12 != 4 ) /*0x1030d77de*/
  {
LABEL_23:
    if ( (v12 & 2) != 0 ) /*0x1030d77e6*/
    {
      v15 = 0; /*0x1030d77eb*/
      while ( v15 < v10 ) /*0x1030d77f0*/
      {
        v15 = 1; /*0x1030d77f2*/
        if ( v29 == 16 ) /*0x1030d77fa*/
          goto LABEL_27; /*0x1030d77fa*/
      }
      v17 = 16; /*0x1030d7820*/
      goto LABEL_36; /*0x1030d7825*/
    }
LABEL_27:
    if ( (v12 & 1) != 0 ) /*0x1030d77fe*/
    {
      v16 = 0; /*0x1030d780d*/
      while ( v16 < v10 ) /*0x1030d7812*/
      {
        v16 = 1; /*0x1030d7814*/
        if ( v29 == 8 ) /*0x1030d781c*/
          goto LABEL_37; /*0x1030d781c*/
      }
      v17 = 8; /*0x1030d7827*/
LABEL_36:
      *(&v29 + v10++) = v17; /*0x1030d782c*/
      goto LABEL_37; /*0x1030d7830*/
    }
    if ( v10 == 0 ) /*0x1030d7803*/
      return v4; /*0x1030d7803*/
LABEL_37:
    v18 = *(_BYTE *)(a2 + 816); /*0x1030d7833*/
    v28 = 0; /*0x1030d783a*/
    v19 = (char *)Curl_ccalloc(__count: 1u, __size: 0xA8u); /*0x1030d7853*/
    v20 = v19; /*0x1030d7855*/
    if ( v19 != nullptr ) /*0x1030d785b*/
    {
      v21 = v19 + 32; /*0x1030d7864*/
      v22 = 0; /*0x1030d7868*/
      do /*0x1030d78c2*/
      {
        v23 = *(&v29 + v22); /*0x1030d787f*/
        *((_DWORD *)v21 + 12) = v23; /*0x1030d7884*/
        v21[44] = v18; /*0x1030d7888*/
        switch ( v23 ) /*0x1030d7890*/
        {
          case 8: /*0x1030d7890*/
            *(_QWORD *)v21 = "h1"; /*0x1030d78ac*/
            break;
          case 16: /*0x1030d7890*/
            *(_QWORD *)v21 = "h2"; /*0x1030d78a7*/
            break;
          case 32: /*0x1030d7890*/
            *(_QWORD *)v21 = "h3"; /*0x1030d789e*/
            v21[44] = 5; /*0x1030d78a1*/
            break;
          default:
            *((_DWORD *)v21 + 4) = 2; /*0x1030d78b1*/
            break;
        }
        ++v22; /*0x1030d78b8*/
        v21 += 56; /*0x1030d78bb*/
      }
      while ( v10 != v22 ); /*0x1030d78c2*/
      if ( (_DWORD)v10 == 1 ) /*0x1030d78c7*/
        *((_DWORD *)v20 + 34) = 0; /*0x1030d78c9*/
      *((_QWORD *)v20 + 18) = v10; /*0x1030d78d4*/
      v4 = Curl_cf_create(a1: &v28, a2: &Curl_cft_http_connect, a3: v20); /*0x1030d78ee*/
      if ( v4 == 0 ) /*0x1030d78f3*/
      {
        cf_hc_reset(a1: v28); /*0x1030d78fc*/
        v24 = v28; /*0x1030d7901*/
        v4 = 0; /*0x1030d790c*/
        Curl_cfree(a1: nullptr); /*0x1030d7911*/
        Curl_conn_cf_add(a1, a2, a3, a4: v24); /*0x1030d791f*/
        return v4; /*0x1030d7924*/
      }
    }
    else
    {
      v4 = 27; /*0x1030d7926*/
    }
    Curl_cfree(a1: v20); /*0x1030d7936*/
  }
  return v4; /*0x1030d794b*/
}

// Address: 0x1030d7992 | Name: _cf_hc_reset
void __fastcall cf_hc_reset(__int64 a1, __int64 a2)
{
  __int64 v2; // r15
  __int64 v4; // r14
  unsigned __int64 v5; // r12
  __int64 v6; // rax

  v2 = *(_QWORD *)(a1 + 16); /*0x1030d799d*/
  if ( v2 != 0 ) /*0x1030d79a4*/
  {
    if ( *(_QWORD *)(v2 + 144) != 0 ) /*0x1030d79b1*/
    {
      v4 = v2 + 32; /*0x1030d79b3*/
      v5 = 0; /*0x1030d79b7*/
      do /*0x1030d79d3*/
      {
        cf_hc_baller_reset(a1: v4, a2); /*0x1030d79c0*/
        ++v5; /*0x1030d79c5*/
        v4 += 56; /*0x1030d79c8*/
      }
      while ( v5 < *(_QWORD *)(v2 + 144) ); /*0x1030d79d3*/
    }
    *(_DWORD *)v2 = 0; /*0x1030d79d7*/
    *(_DWORD *)(v2 + 24) = 0; /*0x1030d79da*/
    v6 = *(_QWORD *)(a2 + 1712); /*0x1030d79de*/
    *(_QWORD *)(v2 + 160) = v6; /*0x1030d79e5*/
    *(_QWORD *)(v2 + 152) = v6 / 4; /*0x1030d79fb*/
  }
}

// Address: 0x1030d7a0b | Name: _cf_hc_baller_reset
__int64 __fastcall cf_hc_baller_reset(__int64 a1, __int64 a2)
{
  __int64 v3; // rdi
  __int64 result; // rax

  v3 = *(_QWORD *)(a1 + 8); /*0x1030d7a18*/
  if ( v3 != 0 ) /*0x1030d7a1f*/
  {
    Curl_conn_cf_close(a1: v3, a2); /*0x1030d7a28*/
    result = Curl_conn_cf_discard_chain(a1: a1 + 8, a2); /*0x1030d7a33*/
    *(_QWORD *)(a1 + 8) = 0; /*0x1030d7a38*/
  }
  *(_DWORD *)(a1 + 16) = 0; /*0x1030d7a3f*/
  *(_DWORD *)(a1 + 40) = -1; /*0x1030d7a46*/
  return result; /*0x1030d7a51*/
}

// Address: 0x1030d7a58 | Name: _cf_hc_baller_init
__int64 __fastcall cf_hc_baller_init(__int64 a1, __int64 a2, __int64 a3, unsigned __int8 a4)
{
  __int64 v8; // r13
  unsigned __int8 v9; // cl
  __int64 result; // rax

  v8 = *(_QWORD *)(a2 + 8); /*0x1030d7a72*/
  *(_QWORD *)(a2 + 8) = 0; /*0x1030d7a76*/
  *(_OWORD *)(a1 + 24) = *(_OWORD *)Curl_pgrs_now(a1: a3); /*0x1030d7a89*/
  if ( *(_DWORD *)(a1 + 16) == 0 ) /*0x1030d7a93*/
  {
    v9 = 5; /*0x1030d7a9e*/
    if ( *(_DWORD *)(a1 + 48) != 32 ) /*0x1030d7aa3*/
      v9 = a4; /*0x1030d7aa3*/
    *(_DWORD *)(a1 + 16) = Curl_cf_setup_insert_after(a1: a2, a2: a3, a3: v9, a4: 1); /*0x1030d7ab9*/
  }
  result = *(_QWORD *)(a2 + 8); /*0x1030d7abd*/
  *(_QWORD *)(a1 + 8) = result; /*0x1030d7ac1*/
  *(_QWORD *)(a2 + 8) = v8; /*0x1030d7ac5*/
  return result; /*0x1030d7acd*/
}

// Address: 0x1030d7bd4 | Name: _cf_get_max_baller_time
__int64 __fastcall cf_get_max_baller_time(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // r13
  __int64 *v6; // r12
  unsigned __int64 v7; // r15
  __int64 v8; // rdi
  __int128 v10; // [rsp+0h] [rbp-50h] BYREF
  _QWORD v11[8]; // [rsp+10h] [rbp-40h] BYREF

  v3 = *(_QWORD *)(a1 + 16); /*0x1030d7be5*/
  v10 = 0; /*0x1030d7bec*/
  if ( *(_QWORD *)(v3 + 144) == 0 ) /*0x1030d7bf8*/
    return 0; /*0x1030d7c6d*/
  v6 = (__int64 *)(v3 + 40); /*0x1030d7bff*/
  v7 = 0; /*0x1030d7c03*/
  do /*0x1030d7c60*/
  {
    v8 = *v6; /*0x1030d7c06*/
    *(_OWORD *)v11 = 0; /*0x1030d7c0d*/
    if ( v8 != 0 /*0x1030d7c48*/
      && (*(unsigned int (__fastcall **)(__int64, __int64, _QWORD, _QWORD, _QWORD *))(*(_QWORD *)v8 + 104LL))(
           a1: v8,
           a2,
           a3,
           a4: 0,
           a5: v11) == 0
      && (v11[0] != 0 || LODWORD(v11[1]) != 0)
      && curlx_ptimediff_us(a1: v11, a2: &v10) > 0 )
    {
      v10 = *(_OWORD *)v11; /*0x1030d7c4e*/
    }
    ++v7; /*0x1030d7c52*/
    v6 += 7; /*0x1030d7c55*/
  }
  while ( v7 < *(_QWORD *)(v3 + 144) ); /*0x1030d7c60*/
  return v10; /*0x1030d7c6f*/
}

// Address: 0x1030d7c7e | Name: _cf_ip_happy_destroy
void __fastcall cf_ip_happy_destroy(__int64 a1)
{
  void *v1; // rbx

  v1 = *(void **)(a1 + 16); /*0x1030d7c84*/
  if ( v1 != nullptr ) /*0x1030d7c8b*/
    cf_ip_happy_ctx_clear(a1); /*0x1030d7c8d*/
  Curl_cfree(a1: v1); /*0x1030d7ca2*/
}

// Address: 0x1030d7ca4 | Name: _cf_ip_happy_connect
__int64 __fastcall cf_ip_happy_connect(__int64 a1, __int64 a2, _BYTE *a3)
{
  _BYTE *v3; // r12
  char *v5; // r13
  int v6; // eax
  unsigned int v7; // ebx
  __int64 v8; // r14
  char *v9; // rcx
  __int64 *v10; // rbx
  char v11; // cl
  __int64 v12; // rax
  __int64 v13; // rdx
  char v14; // si
  __int64 v15; // rdi
  __int64 v16; // rcx
  __int64 v17; // rdx
  int v18; // esi
  __int64 v19; // rdi
  __int64 v20; // r8
  __int64 v22; // rax
  _QWORD *v23; // rbx
  _QWORD *v24; // r15
  char v25; // r13
  bool v26; // r14
  _QWORD *v27; // r14
  int v28; // r13d
  int v29; // ebx
  int v30; // eax
  char *v31; // r15
  __int64 v32; // rax
  __int64 *v33; // rax
  __int64 v34; // rax
  _QWORD *v35; // rax
  __int64 v36; // rax
  __int64 v37; // rax
  __int64 v38; // rax
  __int64 *v39; // rax
  __int64 v40; // rax
  __int64 v41; // rax
  __int64 v42; // rbx
  unsigned __int8 v43; // r13
  __int64 (__fastcall *v44)(_QWORD *, __int64, _QWORD, __int64, _QWORD); // r12
  _QWORD *v45; // rax
  _QWORD *v46; // r14
  char *v47; // r15
  CURLcode i; // r13d
  __int64 v49; // rax
  _QWORD *v50; // rcx
  __int64 v51; // rcx
  int v52; // edx
  _QWORD *v53; // rax
  __int64 *v54; // rax
  __int64 v55; // rax
  __int64 v56; // rax
  __int64 v57; // rsi
  bool v58; // cc
  __int64 v59; // rsi
  __int64 v60; // rax
  __int64 v61; // r13
  __int64 v62; // rax
  __int64 *v63; // rax
  __int64 v64; // rax
  _QWORD *v65; // rax
  __int64 v66; // rax
  __int64 v67; // rax
  __int64 v68; // rsi
  _QWORD *v69; // rdi
  CURLcode v70; // eax
  _QWORD *v71; // r15
  __int64 v72; // rax
  __int64 v73; // rax
  int v74; // eax
  __int64 v75; // rcx
  const char *v76; // rbx
  const char **v77; // rcx
  const char *v78; // rdx
  const char *v79; // rcx
  int v80; // ecx
  bool v81; // zf
  const char *v82; // r14
  const char *v83; // rbx
  __int64 v84; // rax
  __int64 v85; // r12
  const char *v86; // rax
  char *v87; // [rsp+0h] [rbp-130h]
  char *v88; // [rsp+8h] [rbp-128h]
  _BYTE *v89; // [rsp+10h] [rbp-120h]
  __int64 v90; // [rsp+18h] [rbp-118h]
  _OWORD *v91; // [rsp+20h] [rbp-110h]
  __int64 *v92; // [rsp+28h] [rbp-108h]
  char *v93; // [rsp+30h] [rbp-100h]
  _OWORD *v94; // [rsp+38h] [rbp-F8h]
  int v95; // [rsp+44h] [rbp-ECh]
  __int64 v96; // [rsp+48h] [rbp-E8h]
  const char *v97; // [rsp+48h] [rbp-E8h]
  _QWORD *v98; // [rsp+50h] [rbp-E0h]
  const char *v99; // [rsp+50h] [rbp-E0h]
  __int64 v100; // [rsp+58h] [rbp-D8h]
  char buffer[160]; // [rsp+60h] [rbp-D0h] BYREF

  v3 = a3; /*0x1030d7cb8*/
  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d7ccd*/
  {
    *a3 = 1; /*0x1030d7dcd*/
    return 0; /*0x1030d7dcd*/
  }
  v5 = *(char **)(a1 + 16); /*0x1030d7cd6*/
  *a3 = 0; /*0x1030d7cda*/
  v6 = *((_DWORD *)v5 + 4); /*0x1030d7cdf*/
  v7 = 0; /*0x1030d7ce3*/
  if ( v6 == 2 ) /*0x1030d7ce8*/
  {
    *a3 = 1; /*0x1030d7dfc*/
    return v7; /*0x1030d7e01*/
  }
  v8 = a2; /*0x1030d7cee*/
  v9 = v5; /*0x1030d7cf1*/
  if ( v6 == 1 ) /*0x1030d7cf7*/
    goto LABEL_21; /*0x1030d7cf7*/
  if ( v6 != 0 ) /*0x1030d7cff*/
    return v7; /*0x1030d7cff*/
  v10 = *(__int64 **)(a2 + 8LL * *(int *)(a1 + 32) + 2536); /*0x1030d7d09*/
  if ( v10 == nullptr ) /*0x1030d7d14*/
    return 2; /*0x1030d7e08*/
  if ( Curl_timeleft_ms(a1: a2) < 0 ) /*0x1030d7d25*/
  {
    Curl_failf(a1: v8, a2: "Connection time-out"); /*0x1030d7e16*/
    return 28; /*0x1030d7e20*/
  }
  *((_OWORD *)v5 + 9) = *(_OWORD *)Curl_pgrs_now(a1: v8); /*0x1030d7d36*/
  v11 = *(_BYTE *)(*(_QWORD *)(a1 + 24) + 817LL); /*0x1030d7d42*/
  v12 = *v10; /*0x1030d7d48*/
  v13 = *((_QWORD *)v5 + 1); /*0x1030d7d4b*/
  v14 = *v5; /*0x1030d7d4f*/
  v15 = *(_QWORD *)(v8 + 1712); /*0x1030d7d53*/
  *(_OWORD *)(v5 + 88) = 0; /*0x1030d7d5d*/
  *(_OWORD *)(v5 + 120) = 0; /*0x1030d7d62*/
  *(_OWORD *)(v5 + 24) = 0; /*0x1030d7d67*/
  *(_OWORD *)(v5 + 40) = 0; /*0x1030d7d6c*/
  *(_OWORD *)(v5 + 56) = 0; /*0x1030d7d71*/
  *(_OWORD *)(v5 + 72) = 0; /*0x1030d7d76*/
  *(_OWORD *)(v5 + 104) = 0; /*0x1030d7d7b*/
  *((_QWORD *)v5 + 17) = 0; /*0x1030d7d80*/
  *((_QWORD *)v5 + 11) = v13; /*0x1030d7d8b*/
  v5[140] = v14; /*0x1030d7d8f*/
  *((_QWORD *)v5 + 16) = v15; /*0x1030d7d96*/
  *((_DWORD *)v5 + 34) = 2; /*0x1030d7d9d*/
  if ( v14 != 6 ) /*0x1030d7dac*/
  {
    if ( v11 == 2 ) /*0x1030d7e2f*/
    {
      *(_OWORD *)(v5 + 40) = 0; /*0x1030d7e31*/
      *((_QWORD *)v5 + 7) = 0xFFFFFFFF00000002LL; /*0x1030d7e36*/
    }
    else
    {
      *((_QWORD *)v5 + 5) = v12; /*0x1030d7e3c*/
      *((_QWORD *)v5 + 7) = 0xFFFFFFFF00000002LL; /*0x1030d7e40*/
      *((_QWORD *)v5 + 6) = 0; /*0x1030d7e44*/
      if ( v11 == 1 ) /*0x1030d7e4f*/
      {
        v16 = 60; /*0x1030d7e51*/
        v17 = 48; /*0x1030d7e56*/
        v18 = 30; /*0x1030d7e5b*/
        v19 = 56; /*0x1030d7e60*/
        v20 = 40; /*0x1030d7e65*/
        v12 = 0; /*0x1030d7e6b*/
        goto LABEL_20; /*0x1030d7e6d*/
      }
    }
    v16 = 60; /*0x1030d7e6f*/
    v17 = 48; /*0x1030d7e74*/
    v18 = 30; /*0x1030d7e79*/
    v19 = 56; /*0x1030d7e7e*/
    v20 = 40; /*0x1030d7e83*/
    goto LABEL_20; /*0x1030d7e83*/
  }
  v16 = 36; /*0x1030d7dae*/
  v17 = 24; /*0x1030d7db3*/
  v18 = 1; /*0x1030d7db8*/
  v19 = 32; /*0x1030d7dbd*/
  v20 = 16; /*0x1030d7dc2*/
LABEL_20:
  *(_QWORD *)&v5[v20 + 24] = v12; /*0x1030d7e89*/
  *(_DWORD *)&v5[v19 + 24] = v18; /*0x1030d7e8e*/
  *(_QWORD *)&v5[v17 + 24] = 0; /*0x1030d7e93*/
  *(_DWORD *)&v5[v16 + 24] = -1; /*0x1030d7e9c*/
  *((_DWORD *)v5 + 4) = 1; /*0x1030d7ea5*/
  v9 = *(char **)(a1 + 16); /*0x1030d7ead*/
LABEL_21:
  v87 = v5; /*0x1030d7eb1*/
  v96 = a1; /*0x1030d7eb8*/
  if ( *((_QWORD *)v9 + 4) != 0 ) /*0x1030d7ec4*/
  {
LABEL_22:
    if ( *v3 == 1 ) /*0x1030d7ecf*/
    {
      *((_DWORD *)v87 + 4) = 2; /*0x1030d7edc*/
      *(_BYTE *)(v96 + 36) |= 1u; /*0x1030d7eea*/
      v22 = *((_QWORD *)v87 + 4); /*0x1030d7eee*/
      *(_QWORD *)(v96 + 8) = *(_QWORD *)(v22 + 16); /*0x1030d7ef6*/
      *(_QWORD *)(v22 + 16) = 0; /*0x1030d7efa*/
      cf_ip_happy_ctx_clear(a1: v96); /*0x1030d7f08*/
      Curl_expire_done(a1: v8, a2: 6); /*0x1030d7f15*/
      Curl_reset_fail(a1: v8); /*0x1030d7f1d*/
      v7 = 0; /*0x1030d7f31*/
      if ( (*(_BYTE *)(*(_QWORD *)(*(_QWORD *)(v96 + 24) + 736LL) + 16LL) & 0x30) != 0 ) /*0x1030d7f36*/
        Curl_pgrsTime(a1: v8, a2: 6); /*0x1030d7f40*/
      ++*(_QWORD *)(v8 + 4128); /*0x1030d7f45*/
      return v7; /*0x1030d7f4c*/
    }
    return 0; /*0x1030d7dd2*/
  }
  v90 = *(_QWORD *)(a1 + 24); /*0x1030d7f5c*/
  v23 = v9 + 24; /*0x1030d7f63*/
  v92 = (__int64 *)(v9 + 40); /*0x1030d7f6b*/
  v94 = v9 + 112; /*0x1030d7f76*/
  v91 = v9 + 96; /*0x1030d7f81*/
  v88 = v9 + 64; /*0x1030d7f8c*/
  v98 = v9 + 24; /*0x1030d7f93*/
  v100 = v8; /*0x1030d7f9a*/
  v93 = v9; /*0x1030d7fa1*/
  v89 = v3; /*0x1030d7fa8*/
  while ( 1 ) /*0x1030d818e*/
  {
    while ( 1 ) /*0x1030d7faf*/
    {
LABEL_27:
      v24 = (_QWORD *)*v23; /*0x1030d7faf*/
      v25 = 1; /*0x1030d7fb2*/
      v26 = true; /*0x1030d7fb5*/
      if ( *v23 == 0 ) /*0x1030d7fbb*/
      {
LABEL_42:
        if ( *(_QWORD *)v91 != 0 ) /*0x1030d8054*/
        {
          v31 = v93; /*0x1030d8056*/
        }
        else
        {
          v31 = v93; /*0x1030d8062*/
          if ( *((_DWORD *)v93 + 26) == 0 ) /*0x1030d806e*/
            *v91 = *(_OWORD *)Curl_pgrs_now(a1: v100); /*0x1030d808a*/
        }
        goto LABEL_54; /*0x1030d805d*/
      }
      v27 = v23; /*0x1030d7fc1*/
      v28 = 0; /*0x1030d7fc4*/
      v29 = 0; /*0x1030d7fc7*/
      do /*0x1030d8005*/
      {
        v30 = cf_ip_attempt_connect(a1: v24, a2: v100, a3: v3); /*0x1030d7fd6*/
        *((_DWORD *)v24 + 12) = v30; /*0x1030d7fdb*/
        if ( v30 != 0 ) /*0x1030d7fe1*/
        {
          v29 += _bittest((const signed __int32 *)v24 + 16, 2u); /*0x1030d7fe9*/
        }
        else
        {
          if ( *v3 == 1 ) /*0x1030d7ff3*/
          {
            *((_QWORD *)v93 + 4) = v24; /*0x1030d8452*/
            *v27 = *v24; /*0x1030d8459*/
            *v24 = 0; /*0x1030d845c*/
            v71 = *((_QWORD **)v93 + 3); /*0x1030d8463*/
            v8 = v100; /*0x1030d846a*/
            if ( v71 != nullptr ) /*0x1030d8471*/
            {
              do /*0x1030d84ab*/
              {
                *v98 = *v71; /*0x1030d8488*/
                if ( v71[2] != 0 ) /*0x1030d8491*/
                  Curl_conn_cf_discard_chain(a1: v71 + 2, a2: v100); /*0x1030d849a*/
                Curl_cfree(a1: v71); /*0x1030d84a2*/
                v71 = (_QWORD *)*v98; /*0x1030d84a4*/
              }
              while ( *v98 != 0 ); /*0x1030d84ab*/
            }
            goto LABEL_22; /*0x1030d84ab*/
          }
          ++v28; /*0x1030d7ff9*/
        }
        v27 = (_QWORD *)*v27; /*0x1030d7ffc*/
        v24 = (_QWORD *)*v27; /*0x1030d7fff*/
      }
      while ( *v27 != 0 ); /*0x1030d8005*/
      v26 = v29 == 0; /*0x1030d8009*/
      if ( v28 == 0 ) /*0x1030d8010*/
      {
        v25 = 1; /*0x1030d8046*/
        goto LABEL_42; /*0x1030d8046*/
      }
      v31 = v93; /*0x1030d8012*/
      v32 = *((_QWORD *)v93 + 6); /*0x1030d8019*/
      if ( v32 != 0 ) /*0x1030d8020*/
      {
        v33 = (__int64 *)(v32 + 40); /*0x1030d8022*/
      }
      else
      {
        v33 = v92; /*0x1030d8094*/
        if ( *((int *)v93 + 15) >= 0 ) /*0x1030d809b*/
        {
LABEL_47:
          v35 = *((_QWORD **)v93 + 9); /*0x1030d809d*/
          if ( v35 == nullptr ) /*0x1030d80a4*/
          {
            v35 = v98; /*0x1030d82d0*/
            if ( *((int *)v93 + 21) >= 0 ) /*0x1030d82d7*/
              goto LABEL_84; /*0x1030d82d7*/
          }
          v36 = v35[5]; /*0x1030d80aa*/
          if ( v36 == 0 ) /*0x1030d80b1*/
            goto LABEL_84; /*0x1030d80b1*/
          while ( *(_DWORD *)(v36 + 4) != *((_DWORD *)v93 + 20) ) /*0x1030d80be*/
          {
            v36 = *(_QWORD *)(v36 + 40); /*0x1030d80c0*/
            if ( v36 == 0 ) /*0x1030d80c7*/
              goto LABEL_84; /*0x1030d80c7*/
          }
          goto LABEL_52; /*0x1030d80be*/
        }
      }
      v34 = *v33; /*0x1030d8026*/
      if ( v34 == 0 ) /*0x1030d802c*/
        goto LABEL_47; /*0x1030d802c*/
      while ( *(_DWORD *)(v34 + 4) != *((_DWORD *)v93 + 14) ) /*0x1030d8035*/
      {
        v34 = *(_QWORD *)(v34 + 40); /*0x1030d803b*/
        if ( v34 == 0 ) /*0x1030d8042*/
          goto LABEL_47; /*0x1030d8042*/
      }
LABEL_52:
      v37 = Curl_pgrs_now(a1: v100); /*0x1030d80ce*/
      if ( curlx_ptimediff_ms(a1: v37, a2: v94) < *((_QWORD *)v93 + 16) ) /*0x1030d80f0*/
        goto LABEL_84; /*0x1030d80f0*/
      v25 = 0; /*0x1030d80f6*/
LABEL_54:
      if ( *((_DWORD *)v31 + 34) == 2 ) /*0x1030d8101*/
        goto LABEL_62; /*0x1030d8101*/
      v38 = *((_QWORD *)v31 + 6); /*0x1030d8103*/
      if ( v38 != 0 ) /*0x1030d810a*/
      {
        v39 = (__int64 *)(v38 + 40); /*0x1030d810c*/
      }
      else
      {
        v39 = v92; /*0x1030d8131*/
        if ( *((int *)v31 + 15) >= 0 ) /*0x1030d8138*/
          goto LABEL_62; /*0x1030d8138*/
      }
      v40 = *v39; /*0x1030d8110*/
      if ( v40 != 0 ) /*0x1030d8116*/
      {
        while ( *(_DWORD *)(v40 + 4) != *((_DWORD *)v31 + 14) ) /*0x1030d811f*/
        {
          v40 = *(_QWORD *)(v40 + 40); /*0x1030d8121*/
          if ( v40 == 0 ) /*0x1030d8128*/
            goto LABEL_62; /*0x1030d8128*/
        }
        goto LABEL_64; /*0x1030d811f*/
      }
LABEL_62:
      v41 = cf_ai_iter_next(a1: v88); /*0x1030d813a*/
      if ( v41 != 0 ) /*0x1030d8149*/
      {
        v42 = v41; /*0x1030d814b*/
        v95 = *((_DWORD *)v31 + 20); /*0x1030d8152*/
        Curl_reset_fail(a1: v100); /*0x1030d815f*/
        goto LABEL_65; /*0x1030d8164*/
      }
LABEL_64:
      v42 = cf_ai_iter_next(a1: v92); /*0x1030d8172*/
      v95 = *((_DWORD *)v31 + 14); /*0x1030d8179*/
      Curl_reset_fail(a1: v100); /*0x1030d8186*/
      if ( v42 == 0 ) /*0x1030d818e*/
        break; /*0x1030d818e*/
LABEL_65:
      v43 = v31[140]; /*0x1030d8194*/
      v44 = *((__int64 (__fastcall **)(_QWORD *, __int64, _QWORD, __int64, _QWORD))v31 + 11); /*0x1030d819b*/
      v45 = Curl_ccalloc(__count: 1u, __size: 0x48u); /*0x1030d81b0*/
      if ( v45 == nullptr ) /*0x1030d81b5*/
      {
        i = CURLE_OUT_OF_MEMORY; /*0x1030d84b2*/
        goto LABEL_119; /*0x1030d84b8*/
      }
      v46 = v45; /*0x1030d81bb*/
      v45[1] = v42; /*0x1030d81be*/
      *((_DWORD *)v45 + 13) = v95; /*0x1030d81c8*/
      *((_BYTE *)v45 + 56) = v43; /*0x1030d81cc*/
      *((_DWORD *)v45 + 12) = 0; /*0x1030d81d0*/
      v45[3] = v44; /*0x1030d81d8*/
      v47 = (char *)(v45 + 2); /*0x1030d81df*/
      i = (unsigned int)v44(a1: v45 + 2, a2: v100, a3: *(_QWORD *)(v96 + 24), a4: v42, a5: v43); /*0x1030d8202*/
      v49 = v46[2]; /*0x1030d8205*/
      if ( i != CURLE_OK ) /*0x1030d820c*/
      {
        if ( v49 != 0 ) /*0x1030d84bd*/
          Curl_conn_cf_discard_chain(a1: v47, a2: v100); /*0x1030d84c9*/
        Curl_cfree(a1: v46); /*0x1030d84d8*/
        goto LABEL_119; /*0x1030d84da*/
      }
      v23 = v98; /*0x1030d8212*/
      v50 = v98; /*0x1030d8219*/
      v3 = v89; /*0x1030d822d*/
      if ( v49 != 0 ) /*0x1030d8234*/
      {
        v51 = *(_QWORD *)(v96 + 24); /*0x1030d8236*/
        v52 = *(_DWORD *)(v96 + 32); /*0x1030d823a*/
        do /*0x1030d824b*/
        {
          *(_QWORD *)(v49 + 24) = v51; /*0x1030d823d*/
          *(_DWORD *)(v49 + 32) = v52; /*0x1030d8241*/
          v49 = *(_QWORD *)(v49 + 8); /*0x1030d8244*/
        }
        while ( v49 != 0 ); /*0x1030d824b*/
        v50 = v98; /*0x1030d824d*/
      }
      do /*0x1030d8259*/
      {
        v53 = v50; /*0x1030d8250*/
        v50 = (_QWORD *)*v50; /*0x1030d8253*/
      }
      while ( v50 != nullptr ); /*0x1030d8259*/
      *v53 = v46; /*0x1030d825b*/
      *v94 = *(_OWORD *)Curl_pgrs_now(a1: v100); /*0x1030d8274*/
      *((_DWORD *)v93 + 34) = v95; /*0x1030d827d*/
    }
    if ( v26 ) /*0x1030d828c*/
      break; /*0x1030d828c*/
    v55 = Curl_pgrs_now(a1: v100); /*0x1030d82e8*/
    v56 = curlx_ptimediff_ms(a1: v55, a2: v94); /*0x1030d82f7*/
    v57 = *((_QWORD *)v31 + 16); /*0x1030d82fc*/
    v58 = v57 <= v56; /*0x1030d8303*/
    v59 = v57 - v56; /*0x1030d8303*/
    if ( v58 ) /*0x1030d8306*/
    {
      v69 = v98; /*0x1030d83f3*/
      while ( 1 ) /*0x1030d83fa*/
      {
        v69 = (_QWORD *)*v69; /*0x1030d83fa*/
        if ( v69 == nullptr ) /*0x1030d8400*/
          break; /*0x1030d8400*/
        if ( (v69[8] & 4) != 0 ) /*0x1030d840a*/
        {
          v70 = (unsigned int)cf_ip_attempt_restart(a1: v69, a2: v96, a3: v100); /*0x1030d841d*/
          if ( v70 == CURLE_OK ) /*0x1030d8424*/
          {
            *v94 = *(_OWORD *)Curl_pgrs_now(a1: v100); /*0x1030d843c*/
            v23 = v98; /*0x1030d843f*/
            goto LABEL_27; /*0x1030d8446*/
          }
          i = v70; /*0x1030d867c*/
          goto LABEL_119; /*0x1030d867f*/
        }
      }
    }
    else
    {
      Curl_expire(a1: v100, a2: v59, a3: 6); /*0x1030d8314*/
    }
LABEL_84:
    v8 = v100; /*0x1030d8319*/
    v60 = Curl_timeleft_ms(a1: v100); /*0x1030d8323*/
    if ( v60 < 0 ) /*0x1030d832b*/
    {
      v72 = Curl_pgrs_now(a1: v100); /*0x1030d84df*/
      v73 = curlx_ptimediff_ms(a1: v72, a2: v100 + 2168); /*0x1030d84ee*/
      Curl_failf(a1: v100, a2: "Connection timeout after %ld ms", v73); /*0x1030d8502*/
      i = CURLE_OPERATION_TIMEDOUT; /*0x1030d8507*/
      goto LABEL_119; /*0x1030d8507*/
    }
    v61 = v60; /*0x1030d8331*/
    v62 = *((_QWORD *)v31 + 6); /*0x1030d8334*/
    if ( v62 != 0 ) /*0x1030d833b*/
    {
      v63 = (__int64 *)(v62 + 40); /*0x1030d833d*/
    }
    else
    {
      v63 = v92; /*0x1030d8362*/
      if ( *((int *)v31 + 15) >= 0 ) /*0x1030d8369*/
      {
LABEL_92:
        v65 = *((_QWORD **)v31 + 9); /*0x1030d836b*/
        if ( v65 == nullptr ) /*0x1030d8372*/
        {
          v65 = v98; /*0x1030d8379*/
          if ( *((int *)v31 + 21) >= 0 ) /*0x1030d8380*/
            goto LABEL_22; /*0x1030d8380*/
        }
        v66 = v65[5]; /*0x1030d8386*/
        if ( v66 == 0 ) /*0x1030d838d*/
          goto LABEL_22; /*0x1030d838d*/
        while ( *(_DWORD *)(v66 + 4) != *((_DWORD *)v31 + 20) ) /*0x1030d839a*/
        {
          v66 = *(_QWORD *)(v66 + 40); /*0x1030d839c*/
          if ( v66 == 0 ) /*0x1030d83a3*/
            goto LABEL_22; /*0x1030d83a3*/
        }
        goto LABEL_98; /*0x1030d839a*/
      }
    }
    v64 = *v63; /*0x1030d8341*/
    if ( v64 == 0 ) /*0x1030d8347*/
      goto LABEL_92; /*0x1030d8347*/
    while ( *(_DWORD *)(v64 + 4) != *((_DWORD *)v31 + 14) ) /*0x1030d8350*/
    {
      v64 = *(_QWORD *)(v64 + 40); /*0x1030d8352*/
      if ( v64 == 0 ) /*0x1030d8359*/
        goto LABEL_92; /*0x1030d8359*/
    }
LABEL_98:
    v67 = Curl_pgrs_now(a1: v100); /*0x1030d83aa*/
    v68 = *((_QWORD *)v31 + 16) - curlx_ptimediff_ms(a1: v67, a2: v94); /*0x1030d83c8*/
    if ( v68 <= 0 ) /*0x1030d83d3*/
      v68 = 0; /*0x1030d83d3*/
    if ( v61 < v68 ) /*0x1030d83da*/
      v68 = v61; /*0x1030d83da*/
    v23 = v98; /*0x1030d83e1*/
    if ( v68 > 0 ) /*0x1030d83e8*/
    {
      Curl_expire(a1: v100, a2: v68, a3: 6); /*0x1030d85af*/
      goto LABEL_22; /*0x1030d85b4*/
    }
  }
  if ( v25 == 0 ) /*0x1030d8291*/
    goto LABEL_84; /*0x1030d8291*/
  v54 = (__int64 *)*v98; /*0x1030d829e*/
  for ( i = CURLE_COULDNT_CONNECT; v54 != nullptr; v54 = (__int64 *)*v54 ) /*0x1030d82aa*/
  {
    if ( *((_DWORD *)v54 + 12) != 0 ) /*0x1030d82b5*/
      i = *((_DWORD *)v54 + 12); /*0x1030d82b5*/
  }
LABEL_119:
  v74 = *(_DWORD *)(v90 + 728); /*0x1030d850d*/
  v75 = 232; /*0x1030d851a*/
  if ( (v74 & 2) != 0 || (v75 = 288, (v74 & 1) != 0) ) /*0x1030d852a*/
    v76 = *(const char **)(v90 + v75); /*0x1030d8530*/
  else
    v76 = nullptr; /*0x1030d852c*/
  v77 = (const char **)(v90 + 200); /*0x1030d8534*/
  if ( (v74 & 0x100) == 0 ) /*0x1030d8546*/
    v77 = (const char **)(v90 + 160); /*0x1030d8546*/
  v78 = *v77; /*0x1030d854a*/
  v79 = *(const char **)(v90 + 776); /*0x1030d854d*/
  v99 = v78; /*0x1030d8557*/
  if ( v79 != nullptr ) /*0x1030d855e*/
  {
    curl_msnprintf(buffer, maxlength: 0xA0u, format: "over %s", v79); /*0x1030d8575*/
  }
  else
  {
    if ( *(_DWORD *)(v96 + 32) == 1 ) /*0x1030d8587*/
    {
      v80 = *(unsigned __int16 *)(v90 + 814); /*0x1030d8589*/
    }
    else if ( (*(_BYTE *)(*(_QWORD *)(v96 + 24) + 729LL) & 2) != 0 ) /*0x1030d859d*/
    {
      v80 = *(_DWORD *)(v90 + 800); /*0x1030d85b9*/
    }
    else
    {
      v80 = *(_DWORD *)(v90 + 796); /*0x1030d859f*/
    }
    curl_msnprintf(buffer, maxlength: 0xA0u, format: "port %u", v80); /*0x1030d85d4*/
  }
  v81 = v76 == nullptr; /*0x1030d85d9*/
  v82 = "via "; /*0x1030d85e3*/
  if ( v76 == nullptr ) /*0x1030d85ea*/
  {
    v82 = ""; /*0x1030d85ea*/
    v76 = ""; /*0x1030d85ee*/
  }
  v97 = v76; /*0x1030d85f2*/
  v83 = " "; /*0x1030d85f9*/
  if ( v81 ) /*0x1030d8600*/
    v83 = ""; /*0x1030d8600*/
  v84 = Curl_pgrs_now(a1: v100); /*0x1030d860e*/
  v85 = curlx_ptimediff_ms(a1: v84, a2: v100 + 2168); /*0x1030d8622*/
  v86 = curl_easy_strerror(a1: i); /*0x1030d8628*/
  Curl_failf(a1: v100, a2: "Failed to connect to %s %s %s%s%safter %ld ms: %s", v99, buffer, v82, v97, v83, v85, v86);
  v7 = 28; /*0x1030d866e*/
  if ( *(_DWORD *)(v100 + 2488) != 60 ) /*0x1030d8673*/
    return i; /*0x1030d8673*/
  return v7; /*0x1030d7dea*/
}

// Address: 0x1030d8689 | Name: _cf_ip_happy_close
__int64 __fastcall cf_ip_happy_close(__int64 a1, __int64 a2)
{
  __int64 v4; // r15
  __int64 result; // rax
  __int64 v6; // rdi

  v4 = *(_QWORD *)(a1 + 16); /*0x1030d8699*/
  result = cf_ip_happy_ctx_clear(a1); /*0x1030d869d*/
  *(_BYTE *)(a1 + 36) &= ~1u; /*0x1030d86a2*/
  *(_DWORD *)(v4 + 16) = 0; /*0x1030d86a7*/
  v6 = *(_QWORD *)(a1 + 8); /*0x1030d86af*/
  if ( v6 != 0 ) /*0x1030d86b6*/
  {
    (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v6 + 32LL))(a1: v6, a2); /*0x1030d86c2*/
    return Curl_conn_cf_discard_chain(a1: a1 + 8, a2); /*0x1030d86d5*/
  }
  return result; /*0x1030d86cf*/
}

// Address: 0x1030d86e5 | Name: _cf_ip_happy_shutdown
__int64 __fastcall cf_ip_happy_shutdown(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v4; // rax
  __int64 *i; // r12
  int v7; // eax
  _BYTE v9[33]; // [rsp+Fh] [rbp-21h] BYREF

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d86fb*/
  {
    *a3 = 1; /*0x1030d8756*/
  }
  else
  {
    v4 = *(_QWORD *)(a1 + 16); /*0x1030d86fd*/
    *a3 = 1; /*0x1030d8701*/
    for ( i = *(__int64 **)(v4 + 24); i != nullptr; i = (__int64 *)*i ) /*0x1030d870b*/
    {
      v9[0] = 0; /*0x1030d8714*/
      if ( (i[8] & 2) == 0 ) /*0x1030d871e*/
      {
        v7 = (*(__int64 (__fastcall **)(__int64, __int64, _BYTE *))(*(_QWORD *)i[2] + 40LL))(a1: i[2], a2, a3: v9); /*0x1030d872e*/
        *((_DWORD *)i + 12) = v7; /*0x1030d8731*/
        if ( v7 != 0 || v9[0] == 1 ) /*0x1030d873e*/
          *((_BYTE *)i + 64) |= 2u; /*0x1030d8740*/
        else
          *a3 = 0; /*0x1030d8751*/
      }
    }
  }
  return 0; /*0x1030d875b*/
}

// Address: 0x1030d8768 | Name: _cf_ip_happy_adjust_pollset
__int64 __fastcall cf_ip_happy_adjust_pollset(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  __int64 *v4; // r15

  result = 0; /*0x1030d8768*/
  if ( (*(_BYTE *)(a1 + 36) & 1) == 0 ) /*0x1030d876e*/
  {
    v4 = *(__int64 **)(*(_QWORD *)(a1 + 16) + 24LL); /*0x1030d877e*/
    if ( v4 != nullptr ) /*0x1030d8785*/
    {
      do /*0x1030d87af*/
      {
        result = 0; /*0x1030d878d*/
        if ( *((_DWORD *)v4 + 12) == 0 ) /*0x1030d8794*/
          result = Curl_conn_cf_adjust_pollset(a1: v4[2], a2, a3); /*0x1030d87a0*/
        v4 = (__int64 *)*v4; /*0x1030d87a5*/
      }
      while ( v4 != nullptr && (_DWORD)result == 0 ); /*0x1030d87af*/
    }
  }
  return result; /*0x1030d87bb*/
}

// Address: 0x1030d87bc | Name: _cf_ip_happy_data_pending
char __fastcall cf_ip_happy_data_pending(__int64 a1, __int64 a2)
{
  __int64 *i; // r14

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d87ca*/
    return (*(__int64 (__fastcall **)(_QWORD, __int64))(**(_QWORD **)(a1 + 8) + 56LL))(a1: *(_QWORD *)(a1 + 8), a2); /*0x1030d8808*/
  for ( i = *(__int64 **)(*(_QWORD *)(a1 + 16) + 24LL); ; i = (__int64 *)*i ) /*0x1030d87d0*/
  {
    if ( i == nullptr ) /*0x1030d87d7*/
      return 0; /*0x1030d8810*/
    if ( *((_DWORD *)i + 12) == 0 /*0x1030d87ef*/
      && (*(unsigned __int8 (__fastcall **)(__int64, __int64))(*(_QWORD *)i[2] + 56LL))(a1: i[2], a2) != 0 )
    {
      break; /*0x1030d87ef*/
    }
  }
  return 1; /*0x1030d8805*/
}

// Address: 0x1030d8815 | Name: _cf_ip_happy_query
__int64 __fastcall cf_ip_happy_query(__int64 a1, __int64 a2, __int64 a3, int *a4, __int64 a5)
{
  __int64 v5; // rax
  __int64 v10; // rdi
  __int64 **v11; // r13
  int i; // r12d
  int v13; // eax
  int v14; // edx
  __int64 v15; // rdi
  __int64 v17; // rdi
  __int64 v18; // rdx
  int v19; // edx
  int v20[11]; // [rsp+0h] [rbp-2Ch] BYREF

  v20[0] = HIDWORD(v5); /*0x1030d8822*/
  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d8833*/
    goto LABEL_16; /*0x1030d8833*/
  v10 = *(_QWORD *)(a1 + 16); /*0x1030d8835*/
  switch ( (_DWORD)a3 ) /*0x1030d883c*/
  {
    case 5: /*0x1030d883c*/
      v17 = v10 + 24; /*0x1030d88e5*/
      v18 = 5; /*0x1030d88ec*/
      goto LABEL_21; /*0x1030d88ec*/
    case 4: /*0x1030d883c*/
      v17 = v10 + 24; /*0x1030d88d7*/
      v18 = 4; /*0x1030d88de*/
LABEL_21:
      *(_QWORD *)a5 = cf_ip_ballers_max_time(a1: v17, a2, a3: v18); /*0x1030d88f1*/
      *(_DWORD *)(a5 + 8) = v19; /*0x1030d88f9*/
      return 0; /*0x1030d88fd*/
    case 2: /*0x1030d883c*/
      v11 = *(__int64 ***)(v10 + 24); /*0x1030d8850*/
      for ( i = -1; v11 != nullptr; v11 = (__int64 **)*v11 ) /*0x1030d885d*/
      {
        v13 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64, int *, _QWORD))(*v11[2] + 104))( /*0x1030d8878*/
                a1: v11[2],
                a2,
                a3: 2,
                a4: v20,
                a5: 0);
        v14 = i; /*0x1030d8881*/
        if ( v20[0] < i ) /*0x1030d8884*/
          v14 = v20[0]; /*0x1030d8884*/
        if ( i < 0 ) /*0x1030d888a*/
          v14 = v20[0]; /*0x1030d888a*/
        if ( v20[0] < 0 ) /*0x1030d888f*/
          v14 = i; /*0x1030d888f*/
        if ( v13 == 0 ) /*0x1030d8895*/
          i = v14; /*0x1030d8895*/
      }
      *a4 = i; /*0x1030d88a2*/
      return 0; /*0x1030d88a5*/
    default:
      break; /*0x1030d88a7*/
  }
LABEL_16:
  v15 = *(_QWORD *)(a1 + 8); /*0x1030d88a7*/
  if ( v15 != 0 ) /*0x1030d88ae*/
    return (*(__int64 (__fastcall **)(__int64, __int64, __int64, int *, __int64))(*(_QWORD *)v15 + 104LL))( /*0x1030d88ce*/
             a1: v15,
             a2,
             a3,
             a4,
             a5);
  else
    return 48; /*0x1030d88d0*/
}

// Address: 0x1030d890e | Name: _cf_ip_happy_insert_after
__int64 __fastcall cf_ip_happy_insert_after(__int64 a1, __int64 a2, char a3)
{
  __int64 v5; // rax
  __int64 v6; // r12
  _BYTE *v7; // rax
  void *v8; // r14
  unsigned int v9; // eax
  void *v10; // rsi
  unsigned int v11; // r15d
  void *v13; // [rsp+8h] [rbp-28h] BYREF

  v5 = 8; /*0x1030d8923*/
  while ( transport_providers[v5 - 8] != a3 ) /*0x1030d8934*/
  {
    v5 += 16; /*0x1030d8936*/
    if ( v5 == 56 ) /*0x1030d893e*/
      return 1; /*0x1030d893e*/
  }
  v6 = *(_QWORD *)&transport_providers[v5]; /*0x1030d8942*/
  if ( v6 == 0 ) /*0x1030d8949*/
    return 1; /*0x1030d899e*/
  v13 = nullptr; /*0x1030d894b*/
  v7 = Curl_ccalloc(__count: 1u, __size: 0xA0u); /*0x1030d8964*/
  v8 = v7; /*0x1030d8966*/
  if ( v7 != nullptr ) /*0x1030d896c*/
  {
    *v7 = a3; /*0x1030d896e*/
    *((_QWORD *)v7 + 1) = v6; /*0x1030d8971*/
    v9 = Curl_cf_create(a1: &v13, a2: &Curl_cft_ip_happy, a3: v7); /*0x1030d8986*/
    v10 = v13; /*0x1030d898b*/
    if ( v9 == 0 ) /*0x1030d8991*/
    {
      Curl_conn_cf_insert_after(a1, a2: v13); /*0x1030d89c6*/
      return 0; /*0x1030d89cb*/
    }
    v11 = v9; /*0x1030d8993*/
  }
  else
  {
    v11 = 27; /*0x1030d89a0*/
    v10 = nullptr; /*0x1030d89a6*/
  }
  Curl_cfree(a1: v10); /*0x1030d89b2*/
  v13 = nullptr; /*0x1030d89b4*/
  Curl_cfree(a1: v8); /*0x1030d89bf*/
  return v11; /*0x1030d89d1*/
}

// Address: 0x1030d89de | Name: _cf_ip_happy_ctx_clear
void __fastcall cf_ip_happy_ctx_clear(__int64 a1, __int64 a2)
{
  __int64 v3; // r15
  _QWORD *i; // r14
  _QWORD *v5; // r14

  v3 = *(_QWORD *)(a1 + 16); /*0x1030d89ec*/
  for ( i = *(_QWORD **)(v3 + 24); i != nullptr; i = *(_QWORD **)(v3 + 24) ) /*0x1030d89f7*/
  {
    *(_QWORD *)(v3 + 24) = *i; /*0x1030d8a03*/
    if ( i[2] != 0 ) /*0x1030d8a0c*/
      Curl_conn_cf_discard_chain(a1: i + 2, a2); /*0x1030d8a15*/
    Curl_cfree(a1: i); /*0x1030d8a1d*/
  }
  v5 = *(_QWORD **)(v3 + 32); /*0x1030d8a2a*/
  if ( v5 != nullptr ) /*0x1030d8a31*/
  {
    if ( v5[2] != 0 ) /*0x1030d8a38*/
      Curl_conn_cf_discard_chain(a1: v5 + 2, a2); /*0x1030d8a41*/
    Curl_cfree(a1: v5); /*0x1030d8a50*/
  }
  *(_QWORD *)(v3 + 32) = 0; /*0x1030d8a52*/
}

// Address: 0x1030d8a63 | Name: _cf_ip_attempt_connect
__int64 __fastcall cf_ip_attempt_connect(__int64 a1, __int64 a2, _BYTE *a3)
{
  bool v4; // zf
  unsigned int v5; // ecx
  unsigned int v7; // eax
  char v8; // dl

  v4 = (*(_BYTE *)(a1 + 64) & 1) == 0; /*0x1030d8a70*/
  *a3 = *(_BYTE *)(a1 + 64) & 1; /*0x1030d8a72*/
  v5 = *(_DWORD *)(a1 + 48); /*0x1030d8a74*/
  if ( v4 && v5 == 0 ) /*0x1030d8a7c*/
  {
    v7 = Curl_conn_cf_connect(a1: *(_QWORD *)(a1 + 16), a2, a3); /*0x1030d8a90*/
    *(_DWORD *)(a1 + 48) = v7; /*0x1030d8a95*/
    if ( v7 == 8 ) /*0x1030d8a9b*/
    {
      v8 = 4; /*0x1030d8aad*/
    }
    else
    {
      if ( v7 != 0 ) /*0x1030d8a9f*/
        return v7; /*0x1030d8ab2*/
      v5 = 0; /*0x1030d8aa1*/
      v8 = 1; /*0x1030d8aa3*/
      if ( *a3 != 1 ) /*0x1030d8aa9*/
        return v5; /*0x1030d8aa9*/
    }
    *(_BYTE *)(a1 + 64) |= v8; /*0x1030d8aaf*/
    return v7; /*0x1030d8aaf*/
  }
  return v5; /*0x1030d8ab6*/
}

// Address: 0x1030d8abb | Name: _cf_ai_iter_next
__int64 __fastcall cf_ai_iter_next(__int64 *a1)
{
  int v1; // ecx
  __int64 result; // rax

  v1 = *((_DWORD *)a1 + 5); /*0x1030d8abf*/
  if ( v1 < 0 ) /*0x1030d8ac4*/
  {
    *((_DWORD *)a1 + 5) = v1 + 1; /*0x1030d8ae9*/
    result = *a1; /*0x1030d8aec*/
    if ( *a1 != 0 ) /*0x1030d8af2*/
    {
      while ( *(_DWORD *)(result + 4) != *((_DWORD *)a1 + 4) ) /*0x1030d8afa*/
      {
        result = *(_QWORD *)(result + 40); /*0x1030d8afc*/
        if ( result == 0 ) /*0x1030d8b03*/
          goto LABEL_10; /*0x1030d8b03*/
      }
    }
    else
    {
LABEL_10:
      result = 0; /*0x1030d8b05*/
    }
    goto LABEL_11; /*0x1030d8afa*/
  }
  result = a1[1]; /*0x1030d8ac6*/
  if ( result != 0 ) /*0x1030d8acd*/
  {
    *((_DWORD *)a1 + 5) = v1 + 1; /*0x1030d8ad1*/
    do /*0x1030d8ae3*/
      result = *(_QWORD *)(result + 40); /*0x1030d8ad4*/
    while ( result != 0 && *(_DWORD *)(result + 4) != *((_DWORD *)a1 + 4) ); /*0x1030d8ae3*/
LABEL_11:
    a1[1] = result; /*0x1030d8b07*/
    return result; /*0x1030d8b0b*/
  }
  return 0; /*0x1030d8b0f*/
}

// Address: 0x1030d8b11 | Name: _cf_ip_attempt_restart
__int64 __fastcall cf_ip_attempt_restart(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 *v6; // r13
  __int64 v7; // rbx
  __int64 v8; // rdx
  __int64 v9; // rcx
  __int64 v10; // r8
  unsigned int v11; // r15d
  __int64 v12; // rax
  __int64 v13; // rcx
  int v14; // edx
  __int64 v16; // [rsp+0h] [rbp-40h] BYREF
  __int64 v17; // [rsp+8h] [rbp-38h]
  _BYTE v18[41]; // [rsp+17h] [rbp-29h] BYREF

  v6 = (__int64 *)(a1 + 16); /*0x1030d8b2b*/
  v7 = *(_QWORD *)(a1 + 16); /*0x1030d8b2f*/
  v16 = v7; /*0x1030d8b33*/
  *(_DWORD *)(a1 + 48) = 0; /*0x1030d8b37*/
  *(_BYTE *)(a1 + 64) &= 0xFAu; /*0x1030d8b3e*/
  *(_QWORD *)(a1 + 16) = 0; /*0x1030d8b42*/
  v8 = *(_QWORD *)(a2 + 24); /*0x1030d8b4a*/
  v9 = *(_QWORD *)(a1 + 8); /*0x1030d8b4e*/
  v10 = *(unsigned __int8 *)(a1 + 56); /*0x1030d8b52*/
  v17 = a3; /*0x1030d8b5a*/
  v11 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, __int64, __int64))(a1 + 24))( /*0x1030d8b65*/
          a1: a1 + 16,
          a2: a3,
          a3: v8,
          a4: v9,
          a5: v10);
  if ( v11 == 0 ) /*0x1030d8b6a*/
  {
    v12 = *v6; /*0x1030d8b6c*/
    if ( *v6 != 0 ) /*0x1030d8b73*/
    {
      v13 = *(_QWORD *)(a2 + 24); /*0x1030d8b75*/
      v14 = *(_DWORD *)(a2 + 32); /*0x1030d8b7a*/
      do /*0x1030d8b8d*/
      {
        *(_QWORD *)(v12 + 24) = v13; /*0x1030d8b7f*/
        *(_DWORD *)(v12 + 32) = v14; /*0x1030d8b83*/
        v12 = *(_QWORD *)(v12 + 8); /*0x1030d8b86*/
      }
      while ( v12 != 0 ); /*0x1030d8b8d*/
    }
    *(_DWORD *)(a1 + 48) = cf_ip_attempt_connect(a1, a2: v17, a3: v18); /*0x1030d8b9f*/
  }
  if ( v7 != 0 ) /*0x1030d8ba6*/
    Curl_conn_cf_discard_chain(a1: &v16, a2: v17); /*0x1030d8bb0*/
  return v11; /*0x1030d8bb8*/
}

// Address: 0x1030d8bc7 | Name: _cf_ip_ballers_max_time
__int64 __fastcall cf_ip_ballers_max_time(__int64 ***a1, __int64 a2, unsigned int a3)
{
  __int64 **v3; // r13
  __int128 v7; // [rsp+0h] [rbp-50h] BYREF
  _QWORD v8[8]; // [rsp+10h] [rbp-40h] BYREF

  v7 = 0; /*0x1030d8bdb*/
  v3 = *a1; /*0x1030d8bdf*/
  if ( *a1 == nullptr ) /*0x1030d8be5*/
    return 0; /*0x1030d8c4c*/
  do /*0x1030d8c3f*/
  {
    *(_OWORD *)v8 = 0; /*0x1030d8bf7*/
    if ( (*(unsigned int (__fastcall **)(__int64 *, __int64, _QWORD, _QWORD, _QWORD *))(*v3[2] + 104))( /*0x1030d8c2e*/
           a1: v3[2],
           a2,
           a3,
           a4: 0,
           a5: v8) == 0
      && (v8[0] != 0 || LODWORD(v8[1]) != 0)
      && curlx_ptimediff_us(a1: v8, a2: &v7) > 0 )
    {
      v7 = *(_OWORD *)v8; /*0x1030d8c34*/
    }
    v3 = (__int64 **)*v3; /*0x1030d8c38*/
  }
  while ( v3 != nullptr ); /*0x1030d8c3f*/
  return v7; /*0x1030d8c4e*/
}

// Address: 0x1030d8c60 | Name: _Curl_sock_nosigpipe
int __fastcall Curl_sock_nosigpipe(int a1)
{
  int v2; // [rsp+Ch] [rbp-4h] BYREF

  v2 = 1; /*0x1030d8c6c*/
  return setsockopt(a1, a2: 0xFFFF, a3: 4130, a4: &v2, a5: 4u); /*0x1030d8c87*/
}

// Address: 0x1030d8c8d | Name: _Curl_socket_open
__int64 __fastcall Curl_socket_open(__int64 a1, __int64 a2, char *a3, unsigned int a4, __int64 a5)
{
  char *v7; // r15
  __int64 result; // rax
  char v9; // [rsp+0h] [rbp-B0h] BYREF

  v7 = &v9; /*0x1030d8cb4*/
  if ( a3 != nullptr ) /*0x1030d8cbb*/
    v7 = a3; /*0x1030d8cbb*/
  result = sock_assign_addr(a1: v7, a2, a3: a4); /*0x1030d8cc4*/
  if ( (_DWORD)result == 0 ) /*0x1030d8ccb*/
    return socket_open(a1, a2: v7, a3: a5); /*0x1030d8cd6*/
  return result; /*0x1030d8ceb*/
}

// Address: 0x1030d8f02 | Name: _Curl_socket_close
__int64 __fastcall Curl_socket_close(__int64 a1, __int64 a2, unsigned int a3)
{
  if ( a3 != -1 ) /*0x1030d8f05*/
  {
    if ( a2 != 0 ) /*0x1030d8f12*/
      Curl_multi_will_close(a1, a2: a3); /*0x1030d8f16*/
    close(a1: a3); /*0x1030d8f1d*/
  }
  return 0; /*0x1030d8f2a*/
}

// Address: 0x1030d8fb8 | Name: _Curl_parse_interface
__int64 __fastcall Curl_parse_interface(char *__src, __int64 *a2, void **a3, __int64 *a4)
{
  size_t v7; // rax
  unsigned int v8; // r13d
  size_t v9; // r14
  char v10; // r12
  int v11; // eax
  int v12; // eax
  __int64 v13; // rax
  _QWORD *v14; // rcx
  char *v16; // r15
  size_t v17; // r14
  _BYTE *v18; // rax
  _BYTE *v19; // rbx
  __int64 v20; // rax
  __int64 v21; // rax
  void **v23; // [rsp+10h] [rbp-30h]

  v7 = strlen(__s: __src); /*0x1030d8fd6*/
  v8 = 43; /*0x1030d8fdb*/
  if ( v7 > 0x200 ) /*0x1030d8fe7*/
    return v8; /*0x1030d8fe7*/
  v9 = v7; /*0x1030d8fed*/
  v23 = a3; /*0x1030d8ff0*/
  v10 = *__src; /*0x1030d8ff4*/
  v11 = (unsigned __int8)*__src - 105; /*0x1030d8ffb*/
  if ( *__src == 105 && (v11 = (unsigned __int8)__src[1] - 102, __src[1] == 102) ) /*0x1030d9008*/
    v12 = 33 - (unsigned __int8)__src[2]; /*0x1030d9014*/
  else
    v12 = -v11; /*0x1030d9018*/
  if ( v12 == 0 ) /*0x1030d901c*/
  {
    if ( __src[3] == 0 ) /*0x1030d9068*/
      return v8; /*0x1030d9068*/
    v13 = curlx_memdup0(__src: __src + 3, __n: v9 - 3); /*0x1030d9078*/
    v14 = v23; /*0x1030d907d*/
    goto LABEL_15; /*0x1030d9081*/
  }
  if ( strncmp(__s1: "host!", __s2: __src, __n: 5u) == 0 ) /*0x1030d9034*/
  {
    if ( __src[5] == 0 ) /*0x1030d9088*/
      return v8; /*0x1030d9088*/
    v13 = curlx_memdup0(__src: __src + 5, __n: v9 - 5); /*0x1030d9098*/
    v14 = a4; /*0x1030d909d*/
LABEL_15:
    *v14 = v13; /*0x1030d90a1*/
LABEL_16:
    v8 = 27; /*0x1030d90a4*/
    if ( v13 != 0 ) /*0x1030d90af*/
      return 0; /*0x1030d90af*/
    return v8; /*0x1030d90af*/
  }
  if ( strncmp(__s1: "ifhost!", __s2: __src, __n: 7u) != 0 ) /*0x1030d904c*/
  {
    if ( v10 == 0 ) /*0x1030d9051*/
      return v8; /*0x1030d9051*/
    v13 = curlx_memdup0(__src, __n: v9); /*0x1030d9059*/
    *a2 = v13; /*0x1030d905e*/
    goto LABEL_16; /*0x1030d9061*/
  }
  v16 = __src + 7; /*0x1030d90c5*/
  v17 = v9 - 7; /*0x1030d90c9*/
  v18 = memchr(__s: v16, __c: 33, __n: v17); /*0x1030d90d8*/
  if ( v18 != nullptr ) /*0x1030d90e0*/
  {
    v19 = v18; /*0x1030d90e2*/
    if ( v18[1] != 0 ) /*0x1030d90e9*/
    {
      v20 = curlx_memdup0(__src: v16, __n: v18 - v16); /*0x1030d90f4*/
      *v23 = (void *)v20; /*0x1030d90fd*/
      v8 = 27; /*0x1030d9100*/
      if ( v20 != 0 ) /*0x1030d9109*/
      {
        v21 = curlx_memdup0(__src: v19 + 1, __n: &v16[v17] - (v19 + 1)); /*0x1030d911a*/
        *a4 = v21; /*0x1030d9123*/
        v8 = 0; /*0x1030d9126*/
        if ( v21 == 0 ) /*0x1030d912c*/
        {
          Curl_cfree(a1: *v23); /*0x1030d913c*/
          *v23 = nullptr; /*0x1030d913e*/
          return 27; /*0x1030d9145*/
        }
      }
    }
  }
  return v8; /*0x1030d90b6*/
}

// Address: 0x1030d9150 | Name: _cf_socket_destroy
void __fastcall cf_socket_destroy(__int64 a1)
{
  void *v2; // r14

  v2 = *(void **)(a1 + 16); /*0x1030d915a*/
  cf_socket_close(); /*0x1030d915e*/
  Curl_cfree(a1: v2); /*0x1030d916d*/
  *(_QWORD *)(a1 + 16) = 0; /*0x1030d916f*/
}

// Address: 0x1030d917c | Name: _cf_tcp_connect
__int64 __fastcall cf_tcp_connect(__int64 a1, __int64 a2, _BYTE *a3)
{
  _BYTE *v3; // rbx
  __int64 v5; // r13
  unsigned int v6; // r15d
  unsigned int v7; // r12d
  __int64 v8; // rdx
  int v9; // eax
  __int64 v10; // rsi
  int v11; // eax
  __int64 v12; // r15
  __int64 v13; // rbx
  int v14; // r15d
  int v16; // r12d
  sa_endpoints_t v17; // [rsp+10h] [rbp-60h] BYREF
  unsigned __int64 v18; // [rsp+38h] [rbp-38h]
  __int64 v19; // [rsp+40h] [rbp-30h]

  v3 = a3; /*0x1030d918d*/
  if ( (*(_BYTE *)(a1 + 36) & 1) == 0 ) /*0x1030d9194*/
  {
    v5 = *(_QWORD *)(a1 + 16); /*0x1030d919d*/
    *a3 = 0; /*0x1030d91a1*/
    v6 = *(_DWORD *)(v5 + 152); /*0x1030d91a4*/
    v7 = 7; /*0x1030d91ab*/
    v8 = v6; /*0x1030d91b1*/
    v19 = a2; /*0x1030d91b8*/
    if ( v6 != -1 ) /*0x1030d91bc*/
      goto LABEL_3; /*0x1030d91bc*/
    v7 = cf_socket_open(a1, a2, a3: 0xFFFFFFFFLL); /*0x1030d921b*/
    if ( v7 != 0 ) /*0x1030d9220*/
      goto LABEL_19; /*0x1030d9220*/
    if ( (*(_BYTE *)(a1 + 36) & 1) == 0 ) /*0x1030d922b*/
    {
      v10 = *(_QWORD *)(a1 + 16); /*0x1030d922d*/
      if ( (*(_BYTE *)(*(_QWORD *)(a1 + 24) + 730LL) & 4) != 0 ) /*0x1030d923c*/
      {
        v17.sae_srcif = 0; /*0x1030d932d*/
        v17.sae_srcaddr = nullptr; /*0x1030d932f*/
        v17.sae_srcaddrlen = 0; /*0x1030d9337*/
        v17.sae_dstaddr = (const sockaddr *)(v10 + 24); /*0x1030d933e*/
        v17.sae_dstaddrlen = *(_DWORD *)(v10 + 20); /*0x1030d9345*/
        v11 = connectx( /*0x1030d9365*/
                a1: *(_DWORD *)(v10 + 152),
                a2: &v17,
                a3: 0,
                a4: 3u,
                a5: nullptr,
                a6: 0,
                a7: nullptr,
                a8: nullptr);
      }
      else
      {
        v11 = connect(a1: *(_DWORD *)(v10 + 152), a2: (const sockaddr *)(v10 + 24), a3: *(_DWORD *)(v10 + 20)); /*0x1030d924f*/
      }
      v16 = v11; /*0x1030d936a*/
      v18 = (unsigned int)*__error(); /*0x1030d9374*/
      set_local_ip(a1, a2: v19); /*0x1030d937f*/
      if ( v16 == -1 ) /*0x1030d9388*/
      {
        if ( (unsigned int)(v18 - 35) >= 2 ) /*0x1030d93a3*/
        {
          *(_DWORD *)(v19 + 2488) = v18; /*0x1030d93ad*/
          goto LABEL_8; /*0x1030d93b3*/
        }
        return 0; /*0x1030d925f*/
      }
      v8 = *(unsigned int *)(v5 + 152); /*0x1030d938a*/
      v7 = 0; /*0x1030d9391*/
LABEL_3:
      v9 = Curl_socket_check(a1: 0xFFFFFFFFLL, a2: 0xFFFFFFFFLL, a3: v8, a4: 0); /*0x1030d91be*/
      if ( v9 == 0 ) /*0x1030d91d1*/
        return 0; /*0x1030d92aa*/
      if ( v9 == 2 || (*(_BYTE *)(*(_QWORD *)(a1 + 24) + 730LL) & 4) != 0 ) /*0x1030d91eb*/
      {
        if ( (unsigned __int8)verifyconnect(a1: *(unsigned int *)(v5 + 152), a2: v5 + 304) != 0 ) /*0x1030d9279*/
        {
          v12 = v19; /*0x1030d927b*/
          *(_OWORD *)(v5 + 272) = *(_OWORD *)Curl_pgrs_now(a1: v19); /*0x1030d928a*/
          set_local_ip(a1, a2: v12); /*0x1030d9298*/
          *v3 = 1; /*0x1030d929d*/
          *(_BYTE *)(a1 + 36) |= 1u; /*0x1030d92a0*/
          return 0; /*0x1030d92a5*/
        }
      }
      else if ( (v9 & 4) != 0 ) /*0x1030d91ef*/
      {
        verifyconnect(a1: *(unsigned int *)(v5 + 152), a2: v5 + 304); /*0x1030d9203*/
LABEL_8:
        v7 = 7; /*0x1030d9208*/
LABEL_19:
        if ( *(_DWORD *)(v5 + 304) != 0 ) /*0x1030d92ba*/
        {
          v18 = (unsigned __int64)v3; /*0x1030d92bf*/
          v13 = v19; /*0x1030d92c3*/
          set_local_ip(a1, a2: v19); /*0x1030d92ca*/
          v14 = *(_DWORD *)(v5 + 304); /*0x1030d92cf*/
          *(_DWORD *)(v13 + 2488) = v14; /*0x1030d92d6*/
          v3 = (_BYTE *)v18; /*0x1030d92dd*/
          *__error() = v14; /*0x1030d92e6*/
        }
        if ( *(_DWORD *)(v5 + 152) != -1 ) /*0x1030d92f3*/
        {
          socket_close(a1: v19, a2: *(_QWORD *)(a1 + 24), a3: 1); /*0x1030d9302*/
          *(_DWORD *)(v5 + 152) = -1; /*0x1030d9307*/
        }
        *v3 = 0; /*0x1030d9312*/
        return v7; /*0x1030d9318*/
      }
      if ( v6 != -1 ) /*0x1030d92b0*/
        goto LABEL_19; /*0x1030d92b0*/
      return 0; /*0x1030d92b0*/
    }
  }
  *v3 = 1; /*0x1030d9259*/
  return 0; /*0x1030d9259*/
}

// Address: 0x1030d93b8 | Name: _cf_socket_close
void __fastcall cf_socket_close(__int64 a1, __int64 a2)
{
  __int64 v3; // r14
  int v4; // ecx
  __int64 v5; // rax
  __int64 v6; // rdx

  v3 = *(_QWORD *)(a1 + 16); /*0x1030d93c2*/
  if ( v3 != 0 ) /*0x1030d93c9*/
  {
    v4 = *(_DWORD *)(v3 + 152); /*0x1030d93cb*/
    if ( v4 != -1 ) /*0x1030d93d5*/
    {
      v5 = *(_QWORD *)(a1 + 24); /*0x1030d93d7*/
      v6 = *(int *)(a1 + 32); /*0x1030d93db*/
      if ( v4 == *(_DWORD *)(v5 + 4 * v6 + 400) ) /*0x1030d93e6*/
        *(_DWORD *)(v5 + 4 * v6 + 400) = -1; /*0x1030d93e8*/
      socket_close(a1: a2, a2: v5, a3: (*(_BYTE *)(v3 + 308) & 4) == 0); /*0x1030d940d*/
      *(_DWORD *)(v3 + 152) = -1; /*0x1030d9412*/
      *(_BYTE *)(v3 + 308) &= ~0x10u; /*0x1030d941d*/
      *(_OWORD *)(v3 + 256) = 0; /*0x1030d9428*/
      *(_OWORD *)(v3 + 272) = 0; /*0x1030d9430*/
    }
  }
  *(_BYTE *)(a1 + 36) &= ~1u; /*0x1030d9438*/
}

// Address: 0x1030d9441 | Name: _cf_socket_shutdown
__int64 __fastcall cf_socket_shutdown(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v4; // r14
  int v5; // edi
  _BYTE v7[1032]; // [rsp+0h] [rbp-420h] BYREF

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d9464*/
  {
    v4 = *(_QWORD *)(a1 + 16); /*0x1030d9466*/
    v5 = *(_DWORD *)(v4 + 152); /*0x1030d946a*/
    if ( v5 != -1 && *(_BYTE *)v4 == 3 && (int)curlx_nonblock(a1: v5) >= 0 ) /*0x1030d9488*/
      recv(a1: *(_DWORD *)(v4 + 152), a2: v7, a3: 0x400u, a4: 0); /*0x1030d949f*/
  }
  *a3 = 1; /*0x1030d94a4*/
  return 0; /*0x1030d94b9*/
}

// Address: 0x1030d94ca | Name: _cf_socket_adjust_pollset
__int64 __fastcall cf_socket_adjust_pollset(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v3; // rcx
  unsigned int v4; // eax
  char v5; // cl

  v3 = *(_QWORD *)(a1 + 16); /*0x1030d94ce*/
  v4 = *(_DWORD *)(v3 + 152); /*0x1030d94d2*/
  if ( v4 == -1 ) /*0x1030d94db*/
    return 0; /*0x1030d9533*/
  v5 = *(_BYTE *)(v3 + 308); /*0x1030d94dd*/
  if ( (v5 & 2) == 0 ) /*0x1030d94e6*/
  {
    if ( (*(_BYTE *)(a1 + 36) & 1) == 0 ) /*0x1030d94ec*/
      return Curl_pollset_change(a1: a2, a2: a3, a3: v4, a4: 2, a5: 1); /*0x1030d9501*/
    if ( (v5 & 0x10) == 0 ) /*0x1030d951f*/
      return Curl_pollset_change(a1: a2, a2: a3, a3: v4, a4: 1, a5: 0); /*0x1030d9531*/
    return 0; /*0x1030d951f*/
  }
  return Curl_pollset_change(a1: a2, a2: a3, a3: v4, a4: 1, a5: 2); /*0x1030d9516*/
}

// Address: 0x1030d9537 | Name: _cf_socket_send
__int64 __fastcall cf_socket_send(__int64 a1, __int64 a2, const void *a3, size_t a4, __int64 a5, _QWORD *a6)
{
  __int64 v8; // rax
  __int64 v9; // rsi
  __int64 v10; // r8
  int v11; // r14d
  int v12; // edi
  ssize_t v13; // rax
  unsigned int v14; // r12d
  unsigned __int64 v15; // r13
  __int64 v16; // rax
  const char *v17; // rax
  char __s[256]; // [rsp+10h] [rbp-130h] BYREF

  v8 = *(_QWORD *)(a1 + 16); /*0x1030d9566*/
  *a6 = 0; /*0x1030d956a*/
  v9 = *(_QWORD *)(a1 + 24); /*0x1030d9571*/
  v10 = *(int *)(a1 + 32); /*0x1030d9575*/
  v11 = *(_DWORD *)(v9 + 4 * v10 + 400); /*0x1030d9579*/
  v12 = *(_DWORD *)(v8 + 152); /*0x1030d9581*/
  *(_DWORD *)(v9 + 4 * v10 + 400) = v12; /*0x1030d9587*/
  v13 = send(a1: v12, a2: a3, a3: a4, a4: 0x80000); /*0x1030d959a*/
  v14 = 0; /*0x1030d95aa*/
  if ( (unsigned __int8)curlx_sztouz(a1: v13, a2: a6) == 0 )
  {
    v15 = (unsigned int)*__error(); /*0x1030d95b6*/
    if ( v15 > 0x24 || (v14 = 81, v16 = 0x1800000010LL, !_bittest64(&v16, v15)) )
    {
      v17 = (const char *)curlx_strerror(__errnum: v15, __s, __buflen: 0x100u); /*0x1030d95e4*/
      Curl_failf(a1: a2, a2: "Send failure: %s", v17);
      *(_DWORD *)(a2 + 2488) = v15; /*0x1030d9604*/
      v14 = 55; /*0x1030d960c*/
    }
  }
  if ( *a6 != 0 ) /*0x1030d9618*/
  {
    *(_QWORD *)(*(_QWORD *)(a1 + 24) + 824LL) += *a6; /*0x1030d961e*/
    Curl_multi_connxfer_set_bytes_pending(a1: a2); /*0x1030d962c*/
  }
  *(_DWORD *)(*(_QWORD *)(a1 + 24) + 4LL * *(int *)(a1 + 32) + 400) = v11; /*0x1030d9639*/
  return v14; /*0x1030d9654*/
}

// Address: 0x1030d966b | Name: _cf_socket_recv
__int64 __fastcall cf_socket_recv(__int64 a1, __int64 a2, void *a3, size_t a4, _QWORD *a5)
{
  __int64 v7; // rax
  unsigned int v8; // r12d
  ssize_t v9; // rax
  char v10; // r13
  int v11; // ebx
  const char *v12; // rax
  __int64 v14; // [rsp+0h] [rbp-140h]
  char __s[256]; // [rsp+10h] [rbp-130h] BYREF

  v7 = *(_QWORD *)(a1 + 16); /*0x1030d969a*/
  *a5 = 0; /*0x1030d969e*/
  v14 = v7; /*0x1030d96a5*/
  v8 = 0; /*0x1030d96b2*/
  v9 = recv(a1: *(_DWORD *)(v7 + 152), a2: a3, a3: a4, a4: 0); /*0x1030d96bd*/
  v10 = curlx_sztouz(a1: v9, a2: a5); /*0x1030d96cd*/
  if ( v10 == 0 )
  {
    v11 = *__error(); /*0x1030d96d9*/
    v8 = 81; /*0x1030d96db*/
    if ( v11 != 4 && v11 != 35 )
    {
      v12 = (const char *)curlx_strerror(__errnum: v11, __s, __buflen: 0x100u); /*0x1030d96f9*/
      Curl_failf(a1: a2, a2: "Recv failure: %s", v12);
      *(_DWORD *)(a2 + 2488) = v11; /*0x1030d9719*/
      v8 = 56; /*0x1030d9721*/
    }
  }
  if ( *a5 != 0 ) /*0x1030d972d*/
  {
    *(_QWORD *)(*(_QWORD *)(a1 + 24) + 832LL) += *a5; /*0x1030d9733*/
    Curl_multi_connxfer_set_bytes_pending(a1: a2); /*0x1030d9741*/
  }
  if ( v10 != 0 && (*(_BYTE *)(v14 + 308) & 1) == 0 ) /*0x1030d9759*/
  {
    *(_OWORD *)(v14 + 288) = *(_OWORD *)Curl_pgrs_now(a1: a2); /*0x1030d9771*/
    *(_BYTE *)(v14 + 308) |= 1u; /*0x1030d9778*/
  }
  return v8; /*0x1030d9792*/
}

// Address: 0x1030d97a9 | Name: _cf_socket_cntrl
__int64 __fastcall cf_socket_cntrl(__int64 a1, __int64 a2, int a3)
{
  __int64 v5; // r15
  __int64 v6; // rax
  __int128 v7; // xmm0
  __int128 v8; // xmm1
  __int128 v9; // xmm2

  switch ( a3 ) /*0x1030d97bc*/
  {
    case 4: /*0x1030d97bc*/
LABEL_7:
      if ( (*(_BYTE *)(a1 + 36) & 1) != 0 && *(_DWORD *)(a1 + 32) == 0 ) /*0x1030d983e*/
      {
        v6 = *(_QWORD *)(a1 + 16); /*0x1030d9844*/
        *(_WORD *)(a2 + 4276) = *(_WORD *)(v6 + 252); /*0x1030d984f*/
        *(_OWORD *)(a2 + 4260) = *(_OWORD *)(v6 + 236); /*0x1030d985d*/
        *(_OWORD *)(a2 + 4244) = *(_OWORD *)(v6 + 220); /*0x1030d986b*/
        v7 = *(_OWORD *)(v6 + 156); /*0x1030d9872*/
        v8 = *(_OWORD *)(v6 + 172); /*0x1030d9879*/
        v9 = *(_OWORD *)(v6 + 188); /*0x1030d9880*/
        *(_OWORD *)(a2 + 4228) = *(_OWORD *)(v6 + 204); /*0x1030d988e*/
        *(_OWORD *)(a2 + 4212) = v9; /*0x1030d9895*/
        *(_OWORD *)(a2 + 4196) = v8; /*0x1030d989c*/
        *(_OWORD *)(a2 + 4180) = v7; /*0x1030d98a3*/
        *(_DWORD *)(a2 + 4280) = *(_DWORD *)(*(_QWORD *)(a1 + 24) + 796LL); /*0x1030d98b4*/
      }
      return 0; /*0x1030d98ba*/
    case 257: /*0x1030d97bc*/
      *(_DWORD *)(*(_QWORD *)(a1 + 16) + 152LL) = -1; /*0x1030d98c0*/
      return 0; /*0x1030d98c0*/
    case 256: /*0x1030d97bc*/
      v5 = *(_QWORD *)(a1 + 16); /*0x1030d97d6*/
      *(_DWORD *)(*(_QWORD *)(a1 + 24) + 4LL * *(int *)(a1 + 32) + 400) = *(_DWORD *)(v5 + 152); /*0x1030d97e9*/
      set_local_ip(a1, a2); /*0x1030d97f6*/
      if ( *(_DWORD *)(a1 + 32) == 0 ) /*0x1030d9800*/
        *(_DWORD *)(*(_QWORD *)(a1 + 24) + 728LL) = ((*(_DWORD *)(v5 + 8) == 30) << 11) /*0x1030d9820*/
                                                  | *(_DWORD *)(*(_QWORD *)(a1 + 24) + 728LL) & 0xFFFFF7FF;
      *(_BYTE *)(v5 + 308) |= 0x10u; /*0x1030d9826*/
      goto LABEL_7; /*0x1030d9826*/
    default:
      break; /*0x1030d98d0*/
  }
  return 0; /*0x1030d98d0*/
}

// Address: 0x1030d98d7 | Name: _cf_socket_conn_is_alive
__int64 __fastcall cf_socket_conn_is_alive(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v3; // rax
  int v4; // eax
  unsigned int v6; // ebx
  int v7; // eax
  pollfd v9; // [rsp+0h] [rbp-20h] BYREF

  v3 = *(_QWORD *)(a1 + 16); /*0x1030d98f0*/
  *a3 = 0; /*0x1030d98f4*/
  if ( v3 == 0 ) /*0x1030d98fa*/
    return 0; /*0x1030d98fa*/
  v4 = *(_DWORD *)(v3 + 152); /*0x1030d98fc*/
  if ( v4 == -1 ) /*0x1030d9905*/
    return 0; /*0x1030d9933*/
  v9.fd = v4; /*0x1030d990e*/
  *(_DWORD *)&v9.events = 195; /*0x1030d9910*/
  v6 = 0; /*0x1030d9917*/
  v7 = Curl_poll(a1: &v9); /*0x1030d9920*/
  if ( v7 >= 0 ) /*0x1030d9927*/
  {
    LOBYTE(v6) = 1; /*0x1030d9929*/
    if ( v7 != 0 ) /*0x1030d992b*/
    {
      if ( (v9.revents & 0x3A) == 0 ) /*0x1030d9931*/
      {
        *a3 = 1; /*0x1030d9950*/
        return v6; /*0x1030d9954*/
      }
      return 0; /*0x1030d9931*/
    }
  }
  return v6; /*0x1030d9947*/
}

// Address: 0x1030d995b | Name: _cf_socket_query
__int64 __fastcall cf_socket_query(__int64 a1, __int64 a2, __int64 a3, int *a4, __int64 a5)
{
  unsigned __int8 *v7; // rsi
  int v8; // ecx
  __int64 v9; // rax
  __int128 v10; // xmm0
  __int64 v11; // rdi
  __int64 result; // rax
  __int128 v13; // xmm1
  __int128 v14; // xmm2
  unsigned __int8 *v15; // rsi
  unsigned __int8 *v16; // rcx

  v7 = *(unsigned __int8 **)(a1 + 16); /*0x1030d996f*/
  switch ( (int)a3 ) /*0x1030d9981*/
  {
    case 2: /*0x1030d9981*/
      v8 = -1; /*0x1030d9983*/
      if ( (v7[308] & 1) != 0 ) /*0x1030d998f*/
      {
        v9 = curlx_ptimediff_ms(a1: v7 + 288, a2: v7 + 256); /*0x1030d999f*/
        v8 = 0x7FFFFFFF; /*0x1030d99a4*/
        if ( v9 < 0x7FFFFFFF ) /*0x1030d99ac*/
          v8 = v9; /*0x1030d99ac*/
      }
      *a4 = v8; /*0x1030d99b0*/
      goto LABEL_20; /*0x1030d99b2*/
    case 3: /*0x1030d9981*/
      *(_DWORD *)a5 = *((_DWORD *)v7 + 38); /*0x1030d9a0b*/
      goto LABEL_20; /*0x1030d9a0e*/
    case 4: /*0x1030d9981*/
      if ( (*v7 & 0xFE) == 4 && (v7[308] & 1) != 0 ) /*0x1030d99c6*/
        v10 = *((_OWORD *)v7 + 18); /*0x1030d9a8e*/
      else
        v10 = *((_OWORD *)v7 + 17); /*0x1030d99cc*/
      goto LABEL_19; /*0x1030d99d3*/
    case 8: /*0x1030d9981*/
      *a4 = *((_DWORD *)v7 + 2) == 30; /*0x1030d9a1c*/
      *(_WORD *)(a5 + 96) = *((_WORD *)v7 + 126); /*0x1030d9a25*/
      *(_OWORD *)(a5 + 80) = *(_OWORD *)(v7 + 236); /*0x1030d9a31*/
      *(_OWORD *)(a5 + 64) = *(_OWORD *)(v7 + 220); /*0x1030d9a3d*/
      v10 = *(_OWORD *)(v7 + 156); /*0x1030d9a42*/
      v13 = *(_OWORD *)(v7 + 172); /*0x1030d9a49*/
      v14 = *(_OWORD *)(v7 + 188); /*0x1030d9a50*/
      *(_OWORD *)(a5 + 48) = *(_OWORD *)(v7 + 204); /*0x1030d9a5e*/
      *(_OWORD *)(a5 + 32) = v14; /*0x1030d9a63*/
      *(_OWORD *)(a5 + 16) = v13; /*0x1030d9a68*/
LABEL_19:
      *(_OWORD *)a5 = v10; /*0x1030d9a95*/
      goto LABEL_20; /*0x1030d9a95*/
    case 10: /*0x1030d9981*/
      v15 = v7 + 8; /*0x1030d9a6f*/
      result = 0; /*0x1030d9a73*/
      v16 = nullptr; /*0x1030d9a79*/
      if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d9a7e*/
        v16 = v15; /*0x1030d9a7e*/
      *(_QWORD *)a5 = v16; /*0x1030d9a82*/
      return result; /*0x1030d9a85*/
    case 14: /*0x1030d9981*/
      *a4 = *v7; /*0x1030d99db*/
LABEL_20:
      result = 0; /*0x1030d9a99*/
      break; /*0x1030d9a99*/
    default:
      v11 = *(_QWORD *)(a1 + 8); /*0x1030d99e2*/
      if ( v11 != 0 ) /*0x1030d99e9*/
        result = (*(__int64 (__fastcall **)(__int64, __int64, __int64, int *))(*(_QWORD *)v11 + 104LL))( /*0x1030d9a02*/
                   a1: v11,
                   a2,
                   a3,
                   a4);
      else
        result = 48; /*0x1030d9a87*/
      break; /*0x1030d9a02*/
  }
  return result; /*0x1030d9a01*/
}

// Address: 0x1030d9ad8 | Name: _Curl_cf_tcp_create
__int64 __fastcall Curl_cf_tcp_create(_QWORD *a1, __int64 a2, __int64 a3, __int64 a4, unsigned __int8 a5)
{
  _DWORD *v8; // rax
  _DWORD *v9; // rbx
  unsigned int v10; // eax
  unsigned int v11; // r15d
  void *v12; // rdi
  __int64 result; // rax
  void *v14; // rcx
  void *v15; // [rsp+8h] [rbp-28h] BYREF

  v15 = nullptr; /*0x1030d9aea*/
  if ( a4 == 0 ) /*0x1030d9af5*/
  {
    v11 = 43; /*0x1030d9b4e*/
LABEL_7:
    v9 = nullptr; /*0x1030d9b5c*/
    goto LABEL_8; /*0x1030d9b5c*/
  }
  v8 = Curl_ccalloc(__count: 1u, __size: 0x138u); /*0x1030d9b0e*/
  if ( v8 == nullptr ) /*0x1030d9b13*/
  {
    v11 = 27; /*0x1030d9b56*/
    goto LABEL_7; /*0x1030d9b56*/
  }
  v9 = v8; /*0x1030d9b15*/
  __bzero(a1: (__int64)v8, a2: 312); /*0x1030d9b20*/
  v9[38] = -1; /*0x1030d9b25*/
  *(_BYTE *)v9 = a5; /*0x1030d9b2f*/
  v10 = sock_assign_addr(a1: v9 + 2, a2: a4, a3: a5); /*0x1030d9b40*/
  if ( v10 != 0 ) /*0x1030d9b47*/
  {
    v11 = v10; /*0x1030d9b49*/
LABEL_8:
    *a1 = 0; /*0x1030d9b5e*/
    v12 = nullptr; /*0x1030d9b65*/
LABEL_9:
    Curl_cfree(a1: v12); /*0x1030d9b67*/
    v15 = nullptr; /*0x1030d9b71*/
    Curl_cfree(a1: v9); /*0x1030d9b7c*/
    return v11; /*0x1030d9b8e*/
  }
  v11 = Curl_cf_create(a1: &v15, a2: &Curl_cft_tcp, a3: v9); /*0x1030d9ba5*/
  result = 0; /*0x1030d9ba8*/
  v12 = v15; /*0x1030d9baa*/
  v14 = nullptr; /*0x1030d9bae*/
  if ( v11 == 0 ) /*0x1030d9bb6*/
    v14 = v15; /*0x1030d9bb6*/
  *a1 = v14; /*0x1030d9bba*/
  if ( v11 != 0 ) /*0x1030d9bbd*/
    goto LABEL_9; /*0x1030d9bbd*/
  return result; /*0x1030d9b82*/
}

// Address: 0x1030d9bc1 | Name: _cf_udp_connect
__int64 __fastcall cf_udp_connect(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v5; // r12
  __int64 result; // rax
  __int64 v8; // r12
  int v9; // eax

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d9bd3*/
  {
    *a3 = 1; /*0x1030d9c3b*/
    return 0; /*0x1030d9c3e*/
  }
  v5 = *(_QWORD *)(a1 + 16); /*0x1030d9bd8*/
  *a3 = 0; /*0x1030d9bdc*/
  result = 7; /*0x1030d9bdf*/
  if ( *(_DWORD *)(v5 + 152) == -1 ) /*0x1030d9bed*/
  {
    result = cf_socket_open(a1, a2, a3); /*0x1030d9bf5*/
    if ( (_DWORD)result == 0 ) /*0x1030d9bfc*/
    {
      if ( *(_BYTE *)v5 == 5 ) /*0x1030d9c03*/
      {
        v8 = *(_QWORD *)(a1 + 16); /*0x1030d9c05*/
        if ( connect(a1: *(_DWORD *)(v8 + 152), a2: (const sockaddr *)(v8 + 24), a3: *(_DWORD *)(v8 + 20)) == -1 ) /*0x1030d9c23*/
        {
          v9 = *__error(); /*0x1030d9c4e*/
          if ( (unsigned int)(v9 - 35) >= 2 ) /*0x1030d9c56*/
          {
            *(_DWORD *)(a2 + 2488) = v9; /*0x1030d9c62*/
            return 7; /*0x1030d9c69*/
          }
        }
        else
        {
          *(_BYTE *)(v8 + 308) |= 8u; /*0x1030d9c25*/
          set_local_ip(a1, a2); /*0x1030d9c34*/
        }
      }
      *a3 = 1; /*0x1030d9c58*/
      *(_BYTE *)(a1 + 36) |= 1u; /*0x1030d9c5b*/
      return 0; /*0x1030d9c60*/
    }
  }
  return result; /*0x1030d9c40*/
}

// Address: 0x1030d9c70 | Name: _Curl_cf_udp_create
__int64 __fastcall Curl_cf_udp_create(_QWORD *a1, __int64 a2, __int64 a3, __int64 a4, unsigned __int8 a5)
{
  _DWORD *v8; // rax
  _DWORD *v9; // rbx
  unsigned int v10; // r15d
  __int64 result; // rax
  void *v12; // rdi
  void *v13; // rcx
  void *v14; // [rsp+8h] [rbp-28h] BYREF

  v14 = nullptr; /*0x1030d9c88*/
  v8 = Curl_ccalloc(__count: 1u, __size: 0x138u); /*0x1030d9ca1*/
  v9 = v8; /*0x1030d9ca3*/
  if ( v8 == nullptr ) /*0x1030d9ca9*/
  {
    v10 = 27; /*0x1030d9d11*/
    goto LABEL_8; /*0x1030d9d11*/
  }
  __bzero(a1: (__int64)v8, a2: 312); /*0x1030d9cb3*/
  v9[38] = -1; /*0x1030d9cb8*/
  *(_BYTE *)v9 = a5; /*0x1030d9cc2*/
  v10 = sock_assign_addr(a1: v9 + 2, a2: a4, a3: a5); /*0x1030d9cd8*/
  if ( v10 != 0 ) /*0x1030d9cdd*/
  {
LABEL_8:
    *a1 = 0; /*0x1030d9d17*/
    v12 = nullptr; /*0x1030d9d1e*/
LABEL_9:
    Curl_cfree(a1: v12); /*0x1030d9d20*/
    v14 = nullptr; /*0x1030d9d2a*/
    Curl_cfree(a1: v9); /*0x1030d9d35*/
    return v10; /*0x1030d9d38*/
  }
  v10 = Curl_cf_create(a1: &v14, a2: &Curl_cft_udp, a3: v9); /*0x1030d9cf5*/
  result = 0; /*0x1030d9cf8*/
  v12 = v14; /*0x1030d9cfa*/
  v13 = nullptr; /*0x1030d9cfe*/
  if ( v10 == 0 ) /*0x1030d9d06*/
    v13 = v14; /*0x1030d9d06*/
  *a1 = v13; /*0x1030d9d0a*/
  if ( v10 != 0 ) /*0x1030d9d0d*/
    goto LABEL_9; /*0x1030d9d0d*/
  return result; /*0x1030d9d3b*/
}

// Address: 0x1030d9d48 | Name: _Curl_cf_unix_create
__int64 __fastcall Curl_cf_unix_create(_QWORD *a1, __int64 a2, __int64 a3, __int64 a4, unsigned __int8 a5)
{
  _DWORD *v8; // rax
  _DWORD *v9; // rbx
  unsigned int v10; // r15d
  __int64 result; // rax
  void *v12; // rdi
  void *v13; // rcx
  void *v14; // [rsp+8h] [rbp-28h] BYREF

  v14 = nullptr; /*0x1030d9d60*/
  v8 = Curl_ccalloc(__count: 1u, __size: 0x138u); /*0x1030d9d79*/
  v9 = v8; /*0x1030d9d7b*/
  if ( v8 == nullptr ) /*0x1030d9d81*/
  {
    v10 = 27; /*0x1030d9de9*/
    goto LABEL_8; /*0x1030d9de9*/
  }
  __bzero(a1: (__int64)v8, a2: 312); /*0x1030d9d8b*/
  v9[38] = -1; /*0x1030d9d90*/
  *(_BYTE *)v9 = a5; /*0x1030d9d9a*/
  v10 = sock_assign_addr(a1: v9 + 2, a2: a4, a3: a5); /*0x1030d9db0*/
  if ( v10 != 0 ) /*0x1030d9db5*/
  {
LABEL_8:
    *a1 = 0; /*0x1030d9def*/
    v12 = nullptr; /*0x1030d9df6*/
LABEL_9:
    Curl_cfree(a1: v12); /*0x1030d9df8*/
    v14 = nullptr; /*0x1030d9e02*/
    Curl_cfree(a1: v9); /*0x1030d9e0d*/
    return v10; /*0x1030d9e10*/
  }
  v10 = Curl_cf_create(a1: &v14, a2: &Curl_cft_unix, a3: v9); /*0x1030d9dcd*/
  result = 0; /*0x1030d9dd0*/
  v12 = v14; /*0x1030d9dd2*/
  v13 = nullptr; /*0x1030d9dd6*/
  if ( v10 == 0 ) /*0x1030d9dde*/
    v13 = v14; /*0x1030d9dde*/
  *a1 = v13; /*0x1030d9de2*/
  if ( v10 != 0 ) /*0x1030d9de5*/
    goto LABEL_9; /*0x1030d9de5*/
  return result; /*0x1030d9e13*/
}

// Address: 0x1030d9e20 | Name: _cf_tcp_accept_connect
__int64 __fastcall cf_tcp_accept_connect(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v6; // r13
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rax
  unsigned int v10; // r12d
  int v11; // eax
  int v12; // eax
  unsigned int v13; // r12d
  __int64 v14; // r12
  unsigned int v15; // r12d
  __int64 v16; // rax
  int *v17; // rax
  const char *v18; // rax
  int *v19; // rax
  __int64 v20; // rax
  int *v21; // rax
  __int64 v22; // rax
  unsigned int v23; // r12d
  int *v24; // rax
  __int64 v25; // rax
  int v26; // r14d
  socklen_t v28; // [rsp+8h] [rbp-238h] BYREF
  socklen_t v29; // [rsp+Ch] [rbp-234h] BYREF
  sockaddr v30; // [rsp+10h] [rbp-230h] BYREF
  sockaddr v31; // [rsp+90h] [rbp-1B0h] BYREF
  __int128 v32; // [rsp+A0h] [rbp-1A0h]
  __int128 v33; // [rsp+B0h] [rbp-190h]
  __int128 v34; // [rsp+C0h] [rbp-180h]
  __int128 v35; // [rsp+D0h] [rbp-170h]
  __int128 v36; // [rsp+E0h] [rbp-160h]
  __int128 v37; // [rsp+F0h] [rbp-150h]
  __int128 v38; // [rsp+100h] [rbp-140h]
  char __s[256]; // [rsp+110h] [rbp-130h] BYREF

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030d9e49*/
  {
LABEL_24:
    *a3 = 1; /*0x1030da194*/
    return 0; /*0x1030da198*/
  }
  v6 = *(_QWORD *)(a1 + 16); /*0x1030d9e55*/
  *a3 = 0; /*0x1030d9e59*/
  v7 = Curl_timeleft_ms(a1: a2); /*0x1030d9e60*/
  if ( v7 >= 60000 || v7 == 0 ) /*0x1030d9e68*/
  {
    v8 = Curl_pgrs_now(a1: a2); /*0x1030d9e7b*/
    v9 = curlx_ptimediff_ms(a1: v8, a2: v6 + 256) - 60000; /*0x1030d9e8f*/
    if ( v9 == 0 ) /*0x1030d9e95*/
    {
LABEL_13:
      Curl_failf(a1: a2, a2: "Accept timeout occurred while waiting server connect"); /*0x1030d9ffb*/
      return 12; /*0x1030da012*/
    }
    v7 = -v9; /*0x1030d9e9b*/
  }
  if ( v7 < 0 ) /*0x1030d9ea1*/
    goto LABEL_13; /*0x1030d9ea1*/
  v10 = 0; /*0x1030d9eae*/
  v11 = Curl_socket_check(a1: *(unsigned int *)(v6 + 152), a2: 0xFFFFFFFFLL, a3: 0xFFFFFFFFLL, a4: 0); /*0x1030d9ebd*/
  if ( v11 == -1 ) /*0x1030d9ec5*/
  {
    Curl_failf(a1: a2, a2: "Error while waiting for server connect"); /*0x1030da023*/
    return 10; /*0x1030da0bd*/
  }
  if ( (v11 & 1) == 0 ) /*0x1030d9ecd*/
    return v10; /*0x1030d9ecd*/
  v28 = 128; /*0x1030d9eda*/
  v12 = accept(a1: *(_DWORD *)(v6 + 152), a2: &v30, a3: &v28); /*0x1030d9eee*/
  if ( v12 == -1 )
  {
    v17 = __error(); /*0x1030da02d*/
    v18 = (const char *)curlx_strerror(__errnum: *v17, __s, __buflen: 0x100u); /*0x1030da040*/
    Curl_failf(a1: a2, a2: "Error accept()ing server connect: %s", v18);
    return 10; /*0x1030da059*/
  }
  v13 = v12; /*0x1030d9efc*/
  if ( fcntl(a1: v12, a2: 2, 1) < 0 )
  {
    v19 = __error(); /*0x1030da05b*/
    v20 = curlx_strerror(__errnum: *v19, __s, __buflen: 0x100u); /*0x1030da06e*/
    Curl_failf(a1: a2, a2: "fcntl set CLOEXEC: %s", v20);
LABEL_18:
    Curl_socket_close(a1: a2, a2: *(_QWORD *)(a1 + 24), a3: v13); /*0x1030da0a8*/
    return 10; /*0x1030da0b2*/
  }
  if ( (int)curlx_nonblock(a1: v13) < 0 )
  {
    v21 = __error(); /*0x1030da07c*/
    v22 = curlx_strerror(__errnum: *v21, __s, __buflen: 0x100u); /*0x1030da08f*/
    Curl_failf(a1: a2, a2: "set socket NONBLOCK: %s", v22);
    goto LABEL_18; /*0x1030da0a3*/
  }
  *(_BYTE *)(v6 + 308) = *(_BYTE *)(v6 + 308) & 0xF9 | 4; /*0x1030d9f3a*/
  socket_close(a1: a2, a2: *(_QWORD *)(a1 + 24), a3: 1); /*0x1030d9f54*/
  *(_DWORD *)(v6 + 152) = v13; /*0x1030d9f59*/
  *(_DWORD *)(*(_QWORD *)(a1 + 24) + 4LL * *(int *)(a1 + 32) + 400) = v13; /*0x1030d9f68*/
  v14 = *(_QWORD *)(a1 + 16); /*0x1030d9f70*/
  *(_BYTE *)(v14 + 156) = 0; /*0x1030d9f74*/
  *(_WORD *)(v14 + 248) = 0; /*0x1030d9f7d*/
  v29 = 128; /*0x1030d9f8f*/
  v31 = 0; /*0x1030d9f9f*/
  v32 = 0; /*0x1030d9fa2*/
  v33 = 0; /*0x1030d9fa6*/
  v34 = 0; /*0x1030d9faa*/
  v35 = 0; /*0x1030d9fae*/
  v36 = 0; /*0x1030d9fb2*/
  v37 = 0; /*0x1030d9fb6*/
  v38 = 0; /*0x1030d9fba*/
  if ( getpeername(a1: *(_DWORD *)(v14 + 152), a2: &v31, a3: &v29) != 0 )
  {
    v15 = *__error(); /*0x1030d9fd8*/
    v16 = curlx_strerror(__errnum: v15, __s, __buflen: 0x100u); /*0x1030d9fea*/
    Curl_failf(a1: a2, a2: "getpeername() failed with errno %d: %s", v15, v16);
  }
  else if ( (unsigned __int8)Curl_addr2string(a1: &v31, a2: v29, a3: v14 + 156, a4: v14 + 248) == 0 )
  {
    v23 = *__error(); /*0x1030da0ef*/
    v24 = __error(); /*0x1030da0f2*/
    v25 = curlx_strerror(__errnum: *v24, __s, __buflen: 0x100u); /*0x1030da105*/
    Curl_failf(a1: a2, a2: "ssrem inet_ntop() failed with errno %d: %s", v23, v25);
  }
  set_local_ip(a1, a2); /*0x1030da127*/
  *(_BYTE *)(v6 + 308) |= 0x10u; /*0x1030da12c*/
  *(_OWORD *)(v6 + 272) = *(_OWORD *)Curl_pgrs_now(a1: a2); /*0x1030da13f*/
  *(_BYTE *)(a1 + 36) |= 1u; /*0x1030da147*/
  if ( *(_QWORD *)(a2 + 528) == 0 ) /*0x1030da154*/
    goto LABEL_24; /*0x1030da154*/
  Curl_set_in_callback(a1: a2, a2: 1); /*0x1030da15e*/
  v26 = (*(__int64 (__fastcall **)(_QWORD, _QWORD, __int64))(a2 + 528))( /*0x1030da17c*/
          a1: *(_QWORD *)(a2 + 536),
          a2: *(unsigned int *)(v6 + 152),
          a3: 1);
  Curl_set_in_callback(a1: a2, a2: 0); /*0x1030da184*/
  v10 = 42; /*0x1030da189*/
  if ( v26 == 0 ) /*0x1030da192*/
    goto LABEL_24; /*0x1030da192*/
  return v10; /*0x1030da1ae*/
}

// Address: 0x1030da1c5 | Name: _Curl_conn_tcp_listen_set
__int64 __fastcall Curl_conn_tcp_listen_set(__int64 a1, __int64 a2, unsigned int a3, _DWORD *a4)
{
  _DWORD *v8; // rax
  void *v9; // rbx
  unsigned int v10; // r13d
  void *v11; // rcx
  void *v13; // [rsp+0h] [rbp-30h] BYREF

  v13 = nullptr; /*0x1030da1df*/
  Curl_conn_cf_discard_all(); /*0x1030da1e7*/
  v8 = Curl_ccalloc(__count: 1u, __size: 0x138u); /*0x1030da1fd*/
  v9 = v8; /*0x1030da1ff*/
  if ( v8 == nullptr ) /*0x1030da205*/
  {
    v10 = 27; /*0x1030da28c*/
    v11 = nullptr; /*0x1030da292*/
    goto LABEL_5; /*0x1030da292*/
  }
  *(_BYTE *)v8 = 3; /*0x1030da20b*/
  v8[38] = *a4; /*0x1030da212*/
  *((_BYTE *)v8 + 308) = v8[77] & 0xF9 | 2; /*0x1030da222*/
  v10 = Curl_cf_create(a1: &v13, a2: &Curl_cft_tcp_accept, a3: v8); /*0x1030da23b*/
  v11 = v13; /*0x1030da242*/
  if ( v10 != 0 ) /*0x1030da248*/
  {
LABEL_5:
    Curl_cfree(a1: v11); /*0x1030da294*/
    v13 = nullptr; /*0x1030da2a1*/
    Curl_cfree(a1: v9); /*0x1030da2ac*/
    return v10; /*0x1030da2ac*/
  }
  Curl_conn_cf_add(a1, a2, a3, a4: v13); /*0x1030da253*/
  *((_OWORD *)v9 + 16) = *(_OWORD *)Curl_pgrs_now(a1); /*0x1030da263*/
  *(_DWORD *)(a2 + 4LL * (int)a3 + 400) = *((_DWORD *)v9 + 38); /*0x1030da273*/
  set_local_ip(a1: v13, a2: a1); /*0x1030da282*/
  return 0; /*0x1030da2b6*/
}

// Address: 0x1030da38c | Name: _Curl_conn_is_tcp_listen
bool __fastcall Curl_conn_is_tcp_listen(__int64 a1, int a2)
{
  char ***v2; // rcx
  bool result; // al

  v2 = *(char ****)(*(_QWORD *)(a1 + 32) + 8LL * a2 + 408); /*0x1030da397*/
  if ( v2 == nullptr ) /*0x1030da3a2*/
    return false; /*0x1030da3be*/
  do /*0x1030da3ba*/
  {
    result = *v2 == &Curl_cft_tcp_accept; /*0x1030da3ae*/
    if ( *v2 == &Curl_cft_tcp_accept ) /*0x1030da3b1*/
      break; /*0x1030da3b1*/
    v2 = (char ***)v2[1]; /*0x1030da3b3*/
  }
  while ( v2 != nullptr ); /*0x1030da3ba*/
  return result; /*0x1030da3c0*/
}

// Address: 0x1030da3c2 | Name: _Curl_cf_socket_peek
__int64 __fastcall Curl_cf_socket_peek(__int64 a1, __int64 a2, _DWORD *a3, _QWORD *a4, __int64 a5)
{
  __int64 result; // rax
  char **v6; // rsi
  __int64 v7; // rsi
  __int128 v8; // xmm0
  __int128 v9; // xmm1
  __int128 v10; // xmm2

  result = 2; /*0x1030da3c2*/
  if ( a1 != 0 ) /*0x1030da3ca*/
  {
    v6 = *(char ***)a1; /*0x1030da3cc*/
    if ( *(char ***)a1 == &Curl_cft_tcp_accept || v6 == &Curl_cft_unix || v6 == &Curl_cft_tcp || v6 == &Curl_cft_udp ) /*0x1030da3fd*/
    {
      v7 = *(_QWORD *)(a1 + 16); /*0x1030da400*/
      if ( v7 != 0 ) /*0x1030da407*/
      {
        if ( a3 != nullptr ) /*0x1030da410*/
          *a3 = *(_DWORD *)(v7 + 152); /*0x1030da418*/
        if ( a4 != nullptr ) /*0x1030da41d*/
          *a4 = v7 + 8; /*0x1030da423*/
        result = 0; /*0x1030da426*/
        if ( a5 != 0 ) /*0x1030da42b*/
        {
          *(_WORD *)(a5 + 96) = *(_WORD *)(v7 + 252); /*0x1030da434*/
          *(_OWORD *)(a5 + 80) = *(_OWORD *)(v7 + 236); /*0x1030da440*/
          *(_OWORD *)(a5 + 64) = *(_OWORD *)(v7 + 220); /*0x1030da44c*/
          v8 = *(_OWORD *)(v7 + 156); /*0x1030da451*/
          v9 = *(_OWORD *)(v7 + 172); /*0x1030da458*/
          v10 = *(_OWORD *)(v7 + 188); /*0x1030da45f*/
          *(_OWORD *)(a5 + 48) = *(_OWORD *)(v7 + 204); /*0x1030da46d*/
          *(_OWORD *)(a5 + 32) = v10; /*0x1030da472*/
          *(_OWORD *)(a5 + 16) = v9; /*0x1030da477*/
          *(_OWORD *)a5 = v8; /*0x1030da47c*/
        }
      }
    }
  }
  return result; /*0x1030da3ff*/
}

// Address: 0x1030da482 | Name: _cf_socket_open
__int64 __fastcall cf_socket_open(__int64 a1, __int64 a2)
{
  __int64 v3; // rbx
  _DWORD *v4; // r13
  int *v5; // r15
  unsigned int v6; // r12d
  __int64 v7; // r12
  __int64 v8; // rax
  int v9; // edi
  int v10; // r13d
  char v11; // r13
  int v12; // r12d
  int *v13; // rax
  const char *v14; // rax
  char __s[256]; // [rsp+10h] [rbp-130h] BYREF

  v3 = *(_QWORD *)(a1 + 16); /*0x1030da4ae*/
  *(_OWORD *)(v3 + 256) = *(_OWORD *)Curl_pgrs_now(a1: a2); /*0x1030da4bd*/
  v4 = (_DWORD *)(v3 + 8); /*0x1030da4c4*/
  v5 = (int *)(v3 + 152); /*0x1030da4c8*/
  v6 = socket_open(a1: a2, a2: v3 + 8, a3: v3 + 152); /*0x1030da4dd*/
  if ( v6 != 0 ) /*0x1030da4e2*/
    goto LABEL_20; /*0x1030da4e2*/
  v7 = *(_QWORD *)(a1 + 16); /*0x1030da4ef*/
  *(_BYTE *)(v7 + 252) = *(_BYTE *)v7; /*0x1030da4ff*/
  if ( (unsigned __int8)Curl_addr2string(a1: v7 + 24, a2: *(unsigned int *)(v7 + 20), a3: v7 + 156, a4: v7 + 248) == 0 )
  {
    *(_DWORD *)(v7 + 304) = *__error(); /*0x1030da5dc*/
    v12 = *__error(); /*0x1030da5e9*/
    v13 = __error(); /*0x1030da5ec*/
    v14 = (const char *)curlx_strerror(__errnum: *v13, __s, __buflen: 0x100u); /*0x1030da5ff*/
    Curl_failf(a1: a2, a2: "curl_sa_addr inet_ntop() failed with errno %d: %s", v12, v14);
    v6 = 2; /*0x1030da61b*/
    goto LABEL_20; /*0x1030da621*/
  }
  if ( (*v4 == 30 || *v4 == 2) && *(_DWORD *)(v3 + 12) == 1 ) /*0x1030da538*/
  {
    v8 = *(_QWORD *)(a2 + 1843); /*0x1030da53a*/
    if ( (v8 & 0x800000) != 0 ) /*0x1030da545*/
    {
      v9 = *v5; /*0x1030da547*/
      *(_DWORD *)__s = 1; /*0x1030da551*/
      setsockopt(a1: v9, a2: 6, a3: 1, a4: __s, a5: 4u); /*0x1030da567*/
      v8 = *(_QWORD *)(a2 + 1843); /*0x1030da56c*/
    }
    if ( (v8 & 0x20000000) != 0 ) /*0x1030da577*/
      tcpkeepalive(a1: a2, a2: (unsigned int)*v5); /*0x1030da57f*/
  }
  if ( *(_QWORD *)(a2 + 528) != 0 ) /*0x1030da58c*/
  {
    Curl_set_in_callback(a1: a2, a2: 1); /*0x1030da596*/
    v10 = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(a2 + 528))( /*0x1030da5ae*/
            a1: *(_QWORD *)(a2 + 536),
            a2: (unsigned int)*v5,
            a3: 0);
    Curl_set_in_callback(a1: a2, a2: 0); /*0x1030da5b6*/
    if ( v10 == 2 ) /*0x1030da5bf*/
    {
      v11 = 1; /*0x1030da623*/
      goto LABEL_16; /*0x1030da623*/
    }
    v6 = 42; /*0x1030da5c1*/
    if ( v10 != 0 ) /*0x1030da5ca*/
      goto LABEL_20; /*0x1030da5ca*/
  }
  v11 = 0; /*0x1030da5d0*/
LABEL_16:
  v6 = 1; /*0x1030da626*/
  if ( (int)curlx_nonblock(a1: *v5) >= 0 ) /*0x1030da63b*/
  {
    *(_BYTE *)(v3 + 308) = (8 * (*(_DWORD *)(v3 + 12) != 2)) | *(_BYTE *)(v3 + 308) & 0xF7; /*0x1030da652*/
    v6 = 0; /*0x1030da658*/
    if ( v11 != 0 ) /*0x1030da65e*/
    {
      set_local_ip(a1, a2); /*0x1030da66d*/
      *(_OWORD *)(v3 + 272) = *(_OWORD *)Curl_pgrs_now(a1: a2); /*0x1030da67d*/
      *(_BYTE *)(a1 + 36) |= 1u; /*0x1030da684*/
    }
    return v6; /*0x1030da689*/
  }
  *(_DWORD *)(v3 + 304) = *__error(); /*0x1030da692*/
LABEL_20:
  if ( *v5 != -1 ) /*0x1030da69e*/
  {
    socket_close(a1: a2, a2: *(_QWORD *)(a1 + 24), a3: 1); /*0x1030da6b3*/
    *v5 = -1; /*0x1030da6b8*/
  }
  return v6; /*0x1030da6d2*/
}

// Address: 0x1030da811 | Name: _Curl_cf_def_shutdown
__int64 __fastcall Curl_cf_def_shutdown(__int64 a1, __int64 a2, _BYTE *a3)
{
  *a3 = 1; /*0x1030da815*/
  return 0; /*0x1030da81a*/
}

// Address: 0x1030da81c | Name: _Curl_cf_def_adjust_pollset
__int64 Curl_cf_def_adjust_pollset()
{
  return 0; /*0x1030da822*/
}

// Address: 0x1030da824 | Name: _Curl_cf_def_data_pending
__int64 __fastcall Curl_cf_def_data_pending(__int64 a1)
{
  __int64 v1; // rdi

  v1 = *(_QWORD *)(a1 + 8); /*0x1030da828*/
  if ( v1 != 0 ) /*0x1030da82f*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 56LL))(a1: v1); /*0x1030da839*/
  else
    return 0; /*0x1030da83b*/
}

// Address: 0x1030da83f | Name: _Curl_cf_def_send
__int64 __fastcall Curl_cf_def_send(__int64 a1, __int64 a2, __int64 a3, __int64 a4, unsigned __int8 a5, _QWORD *a6)
{
  __int64 v6; // rdi

  v6 = *(_QWORD *)(a1 + 8); /*0x1030da843*/
  if ( v6 != 0 ) /*0x1030da84a*/
    return (*(__int64 (__fastcall **)(__int64, __int64, __int64, __int64, _QWORD))(*(_QWORD *)v6 + 64LL))( /*0x1030da858*/
             a1: v6,
             a2,
             a3,
             a4,
             a5);
  *a6 = 0; /*0x1030da85a*/
  return 56; /*0x1030da866*/
}

// Address: 0x1030da868 | Name: _Curl_cf_def_recv
__int64 __fastcall Curl_cf_def_recv(__int64 a1, __int64 a2, __int64 a3, __int64 a4, _QWORD *a5)
{
  __int64 v5; // rdi

  v5 = *(_QWORD *)(a1 + 8); /*0x1030da86c*/
  if ( v5 != 0 ) /*0x1030da873*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v5 + 72LL))(a1: v5); /*0x1030da87d*/
  *a5 = 0; /*0x1030da87f*/
  return 55; /*0x1030da88b*/
}

// Address: 0x1030da88d | Name: _Curl_cf_def_conn_is_alive
__int64 __fastcall Curl_cf_def_conn_is_alive(__int64 a1)
{
  __int64 v1; // rdi

  v1 = *(_QWORD *)(a1 + 8); /*0x1030da891*/
  if ( v1 != 0 ) /*0x1030da898*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 88LL))(a1: v1); /*0x1030da8a2*/
  else
    return 0; /*0x1030da8a4*/
}

// Address: 0x1030da8a8 | Name: _Curl_cf_def_conn_keep_alive
__int64 __fastcall Curl_cf_def_conn_keep_alive(__int64 a1)
{
  __int64 v1; // rdi

  v1 = *(_QWORD *)(a1 + 8); /*0x1030da8ac*/
  if ( v1 != 0 ) /*0x1030da8b3*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 96LL))(a1: v1); /*0x1030da8bd*/
  else
    return 0; /*0x1030da8bf*/
}

// Address: 0x1030da8c3 | Name: _Curl_cf_def_query
__int64 __fastcall Curl_cf_def_query(__int64 a1)
{
  __int64 v1; // rdi

  v1 = *(_QWORD *)(a1 + 8); /*0x1030da8c7*/
  if ( v1 != 0 ) /*0x1030da8ce*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 104LL))(a1: v1); /*0x1030da8d8*/
  else
    return 48; /*0x1030da8da*/
}

// Address: 0x1030da8e1 | Name: _Curl_conn_cf_discard_chain
void __fastcall Curl_conn_cf_discard_chain(__int64 **a1, __int64 a2)
{
  __int64 *v2; // r14
  __int64 v4; // rax
  __int64 *v5; // r12

  v2 = *a1; /*0x1030da8ec*/
  if ( *a1 != nullptr ) /*0x1030da8f2*/
  {
    *a1 = nullptr; /*0x1030da8f7*/
    do /*0x1030da929*/
    {
      v4 = *v2; /*0x1030da905*/
      v5 = (__int64 *)v2[1]; /*0x1030da908*/
      v2[1] = 0; /*0x1030da90c*/
      (*(void (__fastcall **)(__int64 *, __int64))(v4 + 16))(a1: v2, a2); /*0x1030da91a*/
      Curl_cfree(a1: v2); /*0x1030da920*/
      v2 = v5; /*0x1030da923*/
    }
    while ( v5 != nullptr ); /*0x1030da929*/
  }
}

// Address: 0x1030da934 | Name: _Curl_conn_cf_discard_all
void __fastcall Curl_conn_cf_discard_all(__int64 a1, __int64 a2, int a3)
{
  __int64 *v3; // r14
  __int64 v5; // rax
  __int64 *v6; // r12

  v3 = *(__int64 **)(a2 + 8LL * a3 + 408); /*0x1030da942*/
  if ( v3 != nullptr ) /*0x1030da94d*/
  {
    *(_QWORD *)(a2 + 8LL * a3 + 408) = 0; /*0x1030da952*/
    do /*0x1030da989*/
    {
      v5 = *v3; /*0x1030da965*/
      v6 = (__int64 *)v3[1]; /*0x1030da968*/
      v3[1] = 0; /*0x1030da96c*/
      (*(void (__fastcall **)(__int64 *, __int64))(v5 + 16))(a1: v3, a2: a1); /*0x1030da97a*/
      Curl_cfree(a1: v3); /*0x1030da980*/
      v3 = v6; /*0x1030da983*/
    }
    while ( v6 != nullptr ); /*0x1030da989*/
  }
}

// Address: 0x1030da994 | Name: _Curl_conn_close
__int64 __fastcall Curl_conn_close(__int64 a1, unsigned int a2)
{
  __int64 v4; // rdi

  v4 = *(_QWORD *)(*(_QWORD *)(a1 + 32) + 8LL * (int)a2 + 408); /*0x1030da9a7*/
  if ( v4 != 0 ) /*0x1030da9b2*/
    (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v4 + 32LL))(a1: v4, a2: a1); /*0x1030da9ba*/
  return Curl_shutdown_clear(a1, a2); /*0x1030da9c2*/
}

// Address: 0x1030da9cb | Name: _Curl_conn_shutdown
__int64 __fastcall Curl_conn_shutdown(__int64 a1, unsigned int a2, _BYTE *a3)
{
  __int64 result; // rax
  __int64 i; // r15
  char v8; // [rsp-29h] [rbp-29h] BYREF

  result = 43; /*0x1030da9cb*/
  if ( a2 <= 1 ) /*0x1030da9d3*/
  {
    for ( i = *(_QWORD *)(*(_QWORD *)(a1 + 32) + 8LL * a2 + 408); ; i = *(_QWORD *)(i + 8) ) /*0x1030da9f7*/
    {
      if ( i == 0 ) /*0x1030daa02*/
      {
LABEL_15:
        *a3 = 1; /*0x1030daa88*/
        return 0; /*0x1030daa8b*/
      }
      if ( (*(_BYTE *)(i + 36) & 3) == 1 ) /*0x1030daa10*/
        break; /*0x1030daa10*/
    }
    *a3 = 0; /*0x1030daa18*/
    if ( (unsigned __int8)Curl_shutdown_started(a1, a2) == 0 ) /*0x1030daa28*/
    {
      Curl_shutdown_start(a1, a2, a3: 0); /*0x1030daa4d*/
      while ( 1 ) /*0x1030daa56*/
      {
LABEL_10:
        if ( (*(_BYTE *)(i + 36) & 2) == 0 ) /*0x1030daa5b*/
        {
          v8 = 0; /*0x1030daa5d*/
          result = (*(__int64 (__fastcall **)(__int64, __int64, char *))(*(_QWORD *)i + 40LL))(a1: i, a2: a1, a3: &v8); /*0x1030daa6d*/
          if ( (_DWORD)result != 0 || v8 == 0 ) /*0x1030daa78*/
            return result; /*0x1030daa78*/
          *(_BYTE *)(i + 36) |= 2u; /*0x1030daa7a*/
        }
        i = *(_QWORD *)(i + 8); /*0x1030daa7f*/
        if ( i == 0 ) /*0x1030daa86*/
          goto LABEL_15; /*0x1030daa86*/
      }
    }
    if ( Curl_shutdown_timeleft(a1, a2: *(_QWORD *)(a1 + 32), a3: a2) >= 0 ) /*0x1030daa3c*/
      goto LABEL_10; /*0x1030daa3c*/
    return 28; /*0x1030daa3e*/
  }
  return result; /*0x1030daa99*/
}

// Address: 0x1030daa9a | Name: _Curl_cf_recv
__int64 __fastcall Curl_cf_recv(__int64 a1, int a2, __int64 a3, __int64 a4, _QWORD *a5)
{
  __int64 i; // rdi

  for ( i = *(_QWORD *)(*(_QWORD *)(a1 + 32) + 8LL * a2 + 408); ; i = *(_QWORD *)(i + 8) )
  {
    if ( i == 0 )
    {
      Curl_failf(a1, a2: "recv: no filter connected");
      *a5 = 0; /*0x1030daad7*/
      return 2; /*0x1030daae9*/
    }
    if ( (*(_BYTE *)(i + 36) & 1) != 0 ) /*0x1030daabe*/
      break; /*0x1030daabe*/
  }
  return (*(__int64 (__fastcall **)(__int64, __int64, __int64, __int64, _QWORD *))(*(_QWORD *)i + 72LL))( /*0x1030daae7*/
           a1: i,
           a2: a1,
           a3,
           a4,
           a5);
}

// Address: 0x1030dab00 | Name: _Curl_cf_send
__int64 __fastcall Curl_cf_send(__int64 a1, int a2, __int64 a3, __int64 a4, unsigned __int8 a5, _QWORD *a6)
{
  __int64 i; // rdi

  for ( i = *(_QWORD *)(*(_QWORD *)(a1 + 32) + 8LL * a2 + 408); ; i = *(_QWORD *)(i + 8) )
  {
    if ( i == 0 )
    {
      Curl_failf(a1, a2: "send: no filter connected");
      *a6 = 0; /*0x1030dab3d*/
      return 2; /*0x1030dab4f*/
    }
    if ( (*(_BYTE *)(i + 36) & 1) != 0 ) /*0x1030dab24*/
      break; /*0x1030dab24*/
  }
  return (*(__int64 (__fastcall **)(__int64, __int64, __int64, __int64, _QWORD, _QWORD *))(*(_QWORD *)i + 64LL))( /*0x1030dab4d*/
           a1: i,
           a2: a1,
           a3,
           a4,
           a5,
           a6);
}

// Address: 0x1030dab6a | Name: _Curl_cf_recv_bufq
__int64 __fastcall Curl_cf_recv_bufq(__int64 a1, __int64 a2, __int64 a3, unsigned __int64 a4, _QWORD *a5)
{
  _QWORD v6[3]; // [rsp-18h] [rbp-18h] BYREF

  if ( a2 != 0 && a1 != 0 ) /*0x1030dab6d*/
  {
    v6[0] = a2; /*0x1030dab88*/
    v6[1] = a1; /*0x1030dab8b*/
    return Curl_bufq_sipn( /*0x1030daba2*/
             a1: a3,
             a2: a4,
             a3: (__int64 (__fastcall *)(__int64, __int64, unsigned __int64, _QWORD *))cf_bufq_reader,
             a4: (__int64)v6,
             a5);
  }
  else
  {
    *a5 = 0; /*0x1030dabad*/
    return 43; /*0x1030dabb4*/
  }
}

// Address: 0x1030dabba | Name: _cf_bufq_reader
__int64 __fastcall cf_bufq_reader(_QWORD *a1, __int64 a2, __int64 a3, _QWORD *a4)
{
  __int64 v5; // rdi

  v5 = a1[1]; /*0x1030dabc4*/
  if ( v5 != 0 ) /*0x1030dabcb*/
    return (*(__int64 (__fastcall **)(__int64, _QWORD, __int64, __int64, _QWORD *))(*(_QWORD *)v5 + 72LL))( /*0x1030dabde*/
             a1: v5,
             a2: *a1,
             a3: a2,
             a4: a3,
             a5: a4);
  *a4 = 0; /*0x1030dabe0*/
  return 56; /*0x1030dabec*/
}

// Address: 0x1030dabee | Name: _Curl_cf_send_bufq
__int64 __fastcall Curl_cf_send_bufq(__int64 a1, __int64 a2, __int64 *a3, char *a4, size_t a5, __int64 *a6)
{
  _QWORD v7[3]; // [rsp-18h] [rbp-18h] BYREF

  if ( a2 != 0 && a1 != 0 ) /*0x1030dabf1*/
  {
    v7[0] = a2; /*0x1030dac08*/
    v7[1] = a1; /*0x1030dac0c*/
    if ( a4 == nullptr || a5 == 0 ) /*0x1030dac19*/
      return Curl_bufq_pass( /*0x1030dac64*/
               a1: a3,
               a2: (__int64 (__fastcall *)(__int64, __int64, unsigned __int64, unsigned __int64 *))cf_bufq_writer,
               a3: (__int64)v7,
               a4: a6);
    else
      return Curl_bufq_write_pass( /*0x1030dac3c*/
               a1: a3,
               a2: a4,
               a3: a5,
               a4: (__int64 (__fastcall *)(__int64, __int64, unsigned __int64, unsigned __int64 *))cf_bufq_writer,
               a5: (__int64)v7,
               a6);
  }
  else
  {
    *a6 = 0; /*0x1030dac43*/
    return 43; /*0x1030dac4a*/
  }
}

// Address: 0x1030dac6f | Name: _cf_bufq_writer
__int64 __fastcall cf_bufq_writer(_QWORD *a1, __int64 a2, __int64 a3, _QWORD *a4)
{
  __int64 v5; // rdi

  v5 = a1[1]; /*0x1030dac79*/
  if ( v5 != 0 ) /*0x1030dac80*/
    return (*(__int64 (__fastcall **)(__int64, _QWORD, __int64, __int64, _QWORD, _QWORD *))(*(_QWORD *)v5 + 64LL))( /*0x1030dac96*/
             a1: v5,
             a2: *a1,
             a3: a2,
             a4: a3,
             a5: 0,
             a6: a4);
  *a4 = 0; /*0x1030dac98*/
  return 55; /*0x1030daca4*/
}

// Address: 0x1030daca6 | Name: _Curl_cf_create
__int64 __fastcall Curl_cf_create(_QWORD *a1, __int64 a2, __int64 a3)
{
  _QWORD *v6; // rax
  unsigned int v7; // ecx

  v6 = Curl_ccalloc(__count: 1u, __size: 0x28u); /*0x1030dacca*/
  if ( v6 != nullptr ) /*0x1030daccf*/
  {
    *v6 = a2; /*0x1030dacd1*/
    v6[2] = a3; /*0x1030dacd4*/
    v7 = 0; /*0x1030dacd8*/
  }
  else
  {
    v7 = 27; /*0x1030dacdc*/
  }
  *a1 = v6; /*0x1030dace1*/
  return v7; /*0x1030dacea*/
}

// Address: 0x1030dacf1 | Name: _Curl_conn_cf_add
__int64 __fastcall Curl_conn_cf_add(__int64 a1, __int64 a2, int a3, __int64 a4)
{
  *(_QWORD *)(a4 + 8) = *(_QWORD *)(a2 + 8LL * a3 + 408); /*0x1030dad00*/
  *(_QWORD *)(a4 + 24) = a2; /*0x1030dad04*/
  *(_DWORD *)(a4 + 32) = a3; /*0x1030dad08*/
  *(_QWORD *)(a2 + 8LL * a3 + 408) = a4; /*0x1030dad0b*/
  return a3; /*0x1030dad13*/
}

// Address: 0x1030dad15 | Name: _Curl_conn_cf_insert_after
__int64 __fastcall Curl_conn_cf_insert_after(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  __int64 v3; // rcx
  int v4; // edx
  __int64 v5; // rdi

  result = *(_QWORD *)(a1 + 8); /*0x1030dad19*/
  v3 = *(_QWORD *)(a1 + 24); /*0x1030dad1d*/
  *(_QWORD *)(a1 + 8) = a2; /*0x1030dad21*/
  v4 = *(_DWORD *)(a1 + 32); /*0x1030dad25*/
  do /*0x1030dad39*/
  {
    v5 = a2; /*0x1030dad28*/
    *(_QWORD *)(a2 + 24) = v3; /*0x1030dad2b*/
    *(_DWORD *)(a2 + 32) = v4; /*0x1030dad2f*/
    a2 = *(_QWORD *)(a2 + 8); /*0x1030dad32*/
  }
  while ( a2 != 0 ); /*0x1030dad39*/
  *(_QWORD *)(v5 + 8) = result; /*0x1030dad3b*/
  return result; /*0x1030dad3f*/
}

// Address: 0x1030dad41 | Name: _Curl_conn_cf_discard
__int64 __fastcall Curl_conn_cf_discard(__int64 **a1, __int64 a2)
{
  unsigned int v2; // r14d
  __int64 *v3; // r15
  __int64 v5; // rax
  __int64 v6; // rdx
  __int64 *v7; // rcx
  __int64 *v8; // rax
  _QWORD *v9; // rax
  __int64 v10; // rax
  __int64 *v11; // r13

  if ( a1 == nullptr || (v3 = *a1, *a1 == nullptr) ) /*0x1030dad5a*/
  {
    v2 = 0; /*0x1030dad9d*/
    goto LABEL_16; /*0x1030dada0*/
  }
  v5 = v3[3]; /*0x1030dad5f*/
  if ( v5 == 0 || (v6 = *((int *)v3 + 8), (v7 = *(__int64 **)(v5 + 8 * v6 + 408)) == nullptr) ) /*0x1030dad77*/
  {
    v2 = 0; /*0x1030dada2*/
LABEL_14:
    *a1 = nullptr; /*0x1030dadc8*/
    do /*0x1030dadfb*/
    {
      v10 = *v3; /*0x1030dadd6*/
      v11 = (__int64 *)v3[1]; /*0x1030dadd9*/
      v3[1] = 0; /*0x1030daddd*/
      (*(void (__fastcall **)(__int64 *, __int64))(v10 + 16))(a1: v3, a2); /*0x1030dadeb*/
      Curl_cfree(a1: v3); /*0x1030dadf1*/
      v3 = v11; /*0x1030dadf5*/
    }
    while ( v11 != nullptr ); /*0x1030dadfb*/
    goto LABEL_16; /*0x1030dadfb*/
  }
  LOBYTE(v2) = v7 == v3; /*0x1030dad7c*/
  if ( v7 == v3 ) /*0x1030dad80*/
  {
    v9 = (_QWORD *)(v5 + 8 * v6 + 408); /*0x1030dadab*/
LABEL_12:
    *v9 = v3[1]; /*0x1030dadb1*/
    v3[1] = 0; /*0x1030dadb8*/
    v3 = *a1; /*0x1030dadc0*/
  }
  else
  {
    while ( 1 ) /*0x1030dad82*/
    {
      v8 = v7; /*0x1030dad82*/
      v7 = (__int64 *)v7[1]; /*0x1030dad85*/
      if ( v7 == nullptr ) /*0x1030dad8c*/
        break; /*0x1030dad8c*/
      LOBYTE(v2) = v7 == v3; /*0x1030dad91*/
      if ( v7 == v3 ) /*0x1030dad95*/
      {
        v9 = v8 + 1; /*0x1030dad97*/
        goto LABEL_12; /*0x1030dad9b*/
      }
    }
  }
  if ( v3 != nullptr ) /*0x1030dadc6*/
    goto LABEL_14; /*0x1030dadc6*/
LABEL_16:
  LOBYTE(v2) = v2 & 1; /*0x1030dadfd*/
  return v2; /*0x1030dae08*/
}

// Address: 0x1030dae13 | Name: _Curl_conn_cf_connect
__int64 __fastcall Curl_conn_cf_connect(__int64 a1)
{
  if ( a1 != 0 ) /*0x1030dae1a*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 24LL))(a1); /*0x1030dae24*/
  else
    return 2; /*0x1030dae26*/
}

// Address: 0x1030dae2d | Name: _Curl_conn_cf_close
__int64 __fastcall Curl_conn_cf_close(__int64 a1)
{
  __int64 result; // rax

  if ( a1 != 0 ) /*0x1030dae34*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 32LL))(a1); /*0x1030dae3e*/
  return result; /*0x1030dae40*/
}

// Address: 0x1030dae42 | Name: _Curl_conn_cf_send
__int64 __fastcall Curl_conn_cf_send(__int64 a1, __int64 a2, __int64 a3, __int64 a4, unsigned __int8 a5, _QWORD *a6)
{
  if ( a1 != 0 ) /*0x1030dae49*/
    return (*(__int64 (__fastcall **)(__int64, __int64, __int64, __int64, _QWORD))(*(_QWORD *)a1 + 64LL))( /*0x1030dae57*/
             a1,
             a2,
             a3,
             a4,
             a5);
  *a6 = 0; /*0x1030dae59*/
  return 55; /*0x1030dae65*/
}

// Address: 0x1030dae67 | Name: _Curl_conn_cf_recv
__int64 __fastcall Curl_conn_cf_recv(__int64 a1, __int64 a2, __int64 a3, __int64 a4, _QWORD *a5)
{
  if ( a1 != 0 ) /*0x1030dae6e*/
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 72LL))(a1); /*0x1030dae78*/
  *a5 = 0; /*0x1030dae7a*/
  return 56; /*0x1030dae86*/
}

// Address: 0x1030dae88 | Name: _Curl_conn_connect
__int64 __fastcall Curl_conn_connect(__int64 a1, unsigned int a2, int a3, _BYTE *a4)
{
  unsigned int v4; // r14d
  _BYTE *v5; // r13
  unsigned int v6; // r12d
  _BYTE *v8; // r15
  bool v9; // zf
  unsigned int v10; // eax
  unsigned int v11; // eax
  __int64 v12; // r12
  int v13; // r13d
  unsigned int v14; // r13d
  unsigned int v15; // eax
  __int64 v16; // r13
  char v17; // r15
  __int64 v18; // rcx
  __int64 v19; // rdx
  int v20; // eax
  unsigned int v21; // r12d
  char v22; // r13
  __int64 v23; // rax
  _QWORD *i; // r14
  __int64 (__fastcall *v25)(); // rax
  __int64 v26; // r14
  _BYTE v28[40]; // [rsp+0h] [rbp-C0h] BYREF
  pollfd *v29; // [rsp+28h] [rbp-98h] BYREF
  _BYTE *v30; // [rsp+40h] [rbp-80h]
  _BYTE *v31; // [rsp+48h] [rbp-78h]
  int v32; // [rsp+50h] [rbp-70h] BYREF
  unsigned int v33; // [rsp+54h] [rbp-6Ch]
  __int64 v34; // [rsp+58h] [rbp-68h]
  char v35[48]; // [rsp+60h] [rbp-60h] BYREF

  v4 = 43; /*0x1030daeaa*/
  if ( a2 <= 1 ) /*0x1030daeb3*/
  {
    v5 = a4; /*0x1030daeb9*/
    v6 = a2; /*0x1030daebc*/
    v8 = *(_BYTE **)(*(_QWORD *)(a1 + 32) + 8LL * a2 + 408); /*0x1030daec8*/
    if ( v8 != nullptr ) /*0x1030daed3*/
    {
      v4 = 0; /*0x1030daedd*/
      v9 = (v8[36] & 1) == 0; /*0x1030daee0*/
      *a4 = v8[36] & 1; /*0x1030daee2*/
      if ( v9 ) /*0x1030daee6*/
      {
        LODWORD(v34) = a3; /*0x1030daeec*/
        Curl_pollset_init(a1: v28); /*0x1030daef9*/
        Curl_pollfds_init(a1: &v29, a2: v35, a3: 5); /*0x1030daf0e*/
        v30 = v8; /*0x1030daf13*/
        v31 = v5; /*0x1030daf17*/
        v33 = v6; /*0x1030daf1b*/
        while ( 1 ) /*0x1030daf1f*/
        {
          if ( *v5 != 0 ) /*0x1030daf24*/
            goto LABEL_33; /*0x1030daf24*/
          if ( (unsigned __int8)Curl_conn_needs_flush(a1, a2: v6) != 0 ) /*0x1030daf37*/
          {
            v10 = Curl_conn_flush(a1, a2: v6); /*0x1030daf3f*/
            if ( v10 != 81 && v10 != 0 ) /*0x1030daf4b*/
              return v10; /*0x1030db182*/
          }
          v11 = (*(__int64 (__fastcall **)(_BYTE *, __int64, _BYTE *))(*(_QWORD *)v8 + 24LL))(a1: v8, a2: a1, a3: v5); /*0x1030daf5d*/
          if ( v11 != 0 ) /*0x1030daf62*/
          {
            v21 = v11; /*0x1030db097*/
            conn_report_connect_stats(a1: v8, a2: a1); /*0x1030db0a0*/
            v4 = v21; /*0x1030db0a5*/
            goto LABEL_35; /*0x1030db0a8*/
          }
          if ( *v5 == 1 ) /*0x1030daf6d*/
          {
            v34 = *(_QWORD *)(a1 + 32); /*0x1030db0b1*/
            v22 = 1; /*0x1030db0b5*/
            v23 = 0; /*0x1030db0b8*/
            do /*0x1030db105*/
            {
              for ( i = *(_QWORD **)(v34 + 8 * v23 + 408); i != nullptr; i = (_QWORD *)i[1] ) /*0x1030db0c5*/
              {
                v25 = *(__int64 (__fastcall **)())(*i + 80LL); /*0x1030db0d5*/
                if ( v25 != Curl_cf_def_cntrl ) /*0x1030db0dc*/
                  ((void (__fastcall *)(_QWORD *, __int64, __int64, _QWORD, _QWORD))v25)( /*0x1030db0ee*/
                    a1: i,
                    a2: a1,
                    a3: 256,
                    a4: 0,
                    a5: 0);
              }
              v23 = 1; /*0x1030db0f6*/
              v9 = (v22 & 1) == 0; /*0x1030db0fb*/
              v22 = 0; /*0x1030db0ff*/
            }
            while ( !v9 ); /*0x1030db105*/
            conn_report_connect_stats(a1: v8, a2: a1); /*0x1030db10d*/
            v26 = *(_QWORD *)(a1 + 32); /*0x1030db112*/
            *(_OWORD *)(v26 + 752) = *(_OWORD *)Curl_pgrs_now(a1); /*0x1030db121*/
LABEL_33:
            v4 = 0; /*0x1030db129*/
LABEL_35:
            Curl_pollset_cleanup(a1: v28); /*0x1030db145*/
            Curl_pollfds_cleanup(a1: &v29); /*0x1030db158*/
            return v4; /*0x1030db158*/
          }
          if ( (_BYTE)v34 == 0 ) /*0x1030daf77*/
            goto LABEL_33; /*0x1030daf77*/
          v12 = Curl_timeleft_ms(a1); /*0x1030daf85*/
          v13 = -((*(unsigned int (__fastcall **)(_BYTE *, __int64, __int64, _QWORD, int *))(*(_QWORD *)v8 + 104LL))( /*0x1030dafa7*/
                    a1: v8,
                    a2: a1,
                    a3: 3,
                    a4: 0,
                    a5: &v32) != 0);
          if ( v12 < 0 ) /*0x1030dafad*/
          {
            Curl_failf(a1, a2: "connect timeout"); /*0x1030db13a*/
            v4 = 28; /*0x1030db13f*/
            goto LABEL_35; /*0x1030db13f*/
          }
          v14 = v32 | v13; /*0x1030dafb3*/
          Curl_pollset_reset(a1: v28); /*0x1030dafba*/
          Curl_pollfds_reset(a1: &v29); /*0x1030dafc6*/
          if ( v14 != -1 ) /*0x1030dafcf*/
          {
            v15 = Curl_pollset_change(a1, a2: v28, a3: v14, a4: 2, a5: 1); /*0x1030dafe5*/
            if ( v15 != 0 ) /*0x1030dafec*/
              goto LABEL_23; /*0x1030dafec*/
          }
          v16 = *(_QWORD *)(a1 + 32); /*0x1030daff2*/
          v17 = 1; /*0x1030daff6*/
          v18 = 0; /*0x1030daff9*/
          do /*0x1030db01e*/
          {
            v15 = Curl_conn_cf_adjust_pollset(a1: *(_QWORD *)(v16 + 8 * v18 + 408), a2: a1, a3: v28); /*0x1030db009*/
            if ( (v17 & 1) == 0 ) /*0x1030db012*/
              break; /*0x1030db012*/
            v18 = 1; /*0x1030db014*/
            v17 = 0; /*0x1030db019*/
          }
          while ( v15 == 0 ); /*0x1030db01e*/
          if ( v15 != 0 || (v15 = Curl_pollfds_add_ps(a1: &v29, a2: v28, a3: v19, a4: v18)) != 0 ) /*0x1030db035*/
          {
LABEL_23:
            v4 = v15; /*0x1030db08f*/
            goto LABEL_35; /*0x1030db092*/
          }
          v20 = Curl_poll(a1: v29); /*0x1030db05b*/
          v8 = v30; /*0x1030db062*/
          v5 = v31; /*0x1030db066*/
          v6 = v33; /*0x1030db06a*/
          if ( v20 < 0 ) /*0x1030db06e*/
          {
            v4 = 7; /*0x1030db074*/
            goto LABEL_35; /*0x1030db07a*/
          }
        }
      }
    }
    else
    {
      *a4 = 0; /*0x1030db07f*/
      return 2; /*0x1030db084*/
    }
  }
  return v4; /*0x1030db170*/
}

// Address: 0x1030db18c | Name: _Curl_conn_needs_flush
bool __fastcall Curl_conn_needs_flush(__int64 a1, unsigned int a2)
{
  __int64 v2; // rax
  __int64 v4; // rdi
  int v6; // [rsp-14h] [rbp-14h] BYREF

  if ( a2 > 1 ) /*0x1030db18f*/
    return false; /*0x1030db1dc*/
  v6 = HIDWORD(v2); /*0x1030db196*/
  v4 = *(_QWORD *)(*(_QWORD *)(a1 + 32) + 8LL * a2 + 408); /*0x1030db1a0*/
  v6 = 0; /*0x1030db1a8*/
  return v4 != 0 /*0x1030db1d8*/
      && (*(unsigned int (__fastcall **)(__int64, __int64, __int64, int *, _QWORD))(*(_QWORD *)v4 + 104LL))(
           a1: v4,
           a2: a1,
           a3: 7,
           a4: &v6,
           a5: 0) == 0
      && v6 != 0;
}

// Address: 0x1030db1e8 | Name: _Curl_conn_flush
__int64 __fastcall Curl_conn_flush(__int64 a1, unsigned int a2)
{
  __int64 result; // rax
  _QWORD *v4; // r14
  __int64 (__fastcall *v5)(); // rax

  result = 43; /*0x1030db1e8*/
  if ( a2 <= 1 ) /*0x1030db1f0*/
  {
    v4 = *(_QWORD **)(*(_QWORD *)(a1 + 32) + 8LL * a2 + 408); /*0x1030db205*/
    if ( v4 != nullptr ) /*0x1030db210*/
    {
      while ( 1 ) /*0x1030db21c*/
      {
        v5 = *(__int64 (__fastcall **)())(*v4 + 80LL); /*0x1030db21c*/
        if ( v5 != Curl_cf_def_cntrl ) /*0x1030db223*/
        {
          result = ((__int64 (__fastcall *)(_QWORD *, __int64, __int64, _QWORD, _QWORD))v5)( /*0x1030db235*/
                     a1: v4,
                     a2: a1,
                     a3: 258,
                     a4: 0,
                     a5: 0);
          if ( (_DWORD)result != 0 ) /*0x1030db239*/
            break; /*0x1030db239*/
        }
        v4 = (_QWORD *)v4[1]; /*0x1030db23b*/
        if ( v4 == nullptr ) /*0x1030db242*/
          return 0; /*0x1030db242*/
      }
    }
    else
    {
      return 0; /*0x1030db244*/
    }
  }
  return result; /*0x1030db250*/
}

// Address: 0x1030db251 | Name: _conn_report_connect_stats
char __fastcall conn_report_connect_stats(__int64 a1, __int64 a2)
{
  char result; // al
  __int128 v5; // [rsp+0h] [rbp-40h] BYREF
  __int128 v6; // [rsp+10h] [rbp-30h] BYREF

  v5 = 0; /*0x1030db26b*/
  (*(void (__fastcall **)(__int64, __int64, __int64, _QWORD, __int128 *))(*(_QWORD *)a1 + 104LL))( /*0x1030db27c*/
    a1,
    a2,
    a3: 4,
    a4: 0,
    a5: &v5);
  if ( (_QWORD)v5 != 0 || DWORD2(v5) != 0 ) /*0x1030db28e*/
    Curl_pgrsTimeWas(a1: a2, a2: 5); /*0x1030db2a3*/
  v6 = 0; /*0x1030db2af*/
  (*(void (__fastcall **)(__int64, __int64, __int64, _QWORD, __int128 *))(*(_QWORD *)a1 + 104LL))( /*0x1030db2c6*/
    a1,
    a2,
    a3: 5,
    a4: 0,
    a5: &v6);
  result = (_QWORD)v6 != 0; /*0x1030db2cf*/
  if ( (_QWORD)v6 != 0 || DWORD2(v6) != 0 ) /*0x1030db2d8*/
    return Curl_pgrsTimeWas(a1: a2, a2: 6); /*0x1030db2ed*/
  return result; /*0x1030db2f2*/
}

// Address: 0x1030db2fd | Name: _Curl_conn_cf_get_socket
__int64 __fastcall Curl_conn_cf_get_socket(__int64 a1, __int64 a2)
{
  int v2; // eax
  unsigned int v5[5]; // [rsp+Ch] [rbp-14h] BYREF

  if ( a1 != 0 )
  {
    v2 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, _QWORD, unsigned int *))(*(_QWORD *)a1 + 104LL))( /*0x1030db320*/
           a1,
           a2,
           a3: 3,
           a4: 0,
           a5: v5);
    return v2 != 0 ? -1u : v5[0];
  }
  else
  {
    return (unsigned int)-1; /*0x1030db32c*/
  }
}

// Address: 0x1030db33c | Name: _Curl_conn_adjust_pollset
__int64 __fastcall Curl_conn_adjust_pollset(__int64 a1, __int64 a2, __int64 a3)
{
  char v6; // r12
  __int64 v7; // rcx
  __int64 result; // rax

  v6 = 1; /*0x1030db350*/
  v7 = 0; /*0x1030db353*/
  do /*0x1030db378*/
  {
    result = Curl_conn_cf_adjust_pollset(a1: *(_QWORD *)(a2 + 8 * v7 + 408), a2: a1, a3); /*0x1030db363*/
    if ( (v6 & 1) == 0 ) /*0x1030db36c*/
      break; /*0x1030db36c*/
    v7 = 1; /*0x1030db36e*/
    v6 = 0; /*0x1030db373*/
  }
  while ( (_DWORD)result == 0 ); /*0x1030db378*/
  return result; /*0x1030db37a*/
}

// Address: 0x1030db383 | Name: _Curl_conn_is_setup
bool __fastcall Curl_conn_is_setup(__int64 a1, unsigned int a2)
{
  return a2 <= 1 && *(_QWORD *)(a1 + 8LL * a2 + 408) != 0; /*0x1030db39e*/
}

// Address: 0x1030db3a0 | Name: _Curl_conn_is_connected
bool __fastcall Curl_conn_is_connected(__int64 a1, unsigned int a2)
{
  __int64 v2; // rax

  if ( a2 > 1 ) /*0x1030db3a3*/
  {
    LOBYTE(v2) = 0; /*0x1030db3bf*/
  }
  else
  {
    v2 = *(_QWORD *)(a1 + 8LL * a2 + 408); /*0x1030db3ab*/
    if ( v2 != 0 ) /*0x1030db3b6*/
      LOBYTE(v2) = *(_BYTE *)(v2 + 36) & 1; /*0x1030db3bb*/
    else
      return (*(_BYTE *)(*(_QWORD *)(a1 + 736) + 32LL) & 0x10) != 0; /*0x1030db3ce*/
  }
  return v2; /*0x1030db3c1*/
}

// Address: 0x1030db3d3 | Name: _Curl_conn_is_ip_connected
char __fastcall Curl_conn_is_ip_connected(__int64 a1, unsigned int a2)
{
  __int64 v2; // rcx
  char v3; // al

  if ( a2 > 1 ) /*0x1030db3d6*/
  {
    v3 = 0; /*0x1030db40a*/
  }
  else
  {
    v2 = *(_QWORD *)(*(_QWORD *)(a1 + 32) + 8LL * a2 + 408); /*0x1030db3e2*/
    if ( v2 != 0 ) /*0x1030db3ed*/
    {
      do /*0x1030db406*/
      {
        v3 = *(_BYTE *)(v2 + 36); /*0x1030db3ef*/
        if ( (v3 & 1) != 0 ) /*0x1030db3f4*/
          break; /*0x1030db3f4*/
        if ( (*(_BYTE *)(*(_QWORD *)v2 + 8LL) & 1) != 0 ) /*0x1030db3fd*/
          break; /*0x1030db3fd*/
        v2 = *(_QWORD *)(v2 + 8); /*0x1030db3ff*/
      }
      while ( v2 != 0 ); /*0x1030db406*/
    }
    else
    {
      v3 = 0; /*0x1030db40e*/
    }
  }
  return v3 & 1; /*0x1030db413*/
}

// Address: 0x1030db414 | Name: _Curl_conn_is_ssl
_BOOL8 __fastcall Curl_conn_is_ssl(__int64 a1, unsigned int a2)
{
  _QWORD *v2; // rcx
  int v3; // eax

  if ( a2 >= 2 || a1 == 0 ) /*0x1030db41d*/
    return false; /*0x1030db422*/
  v2 = *(_QWORD **)(a1 + 8LL * a2 + 408); /*0x1030db426*/
  if ( v2 == nullptr ) /*0x1030db431*/
    return false; /*0x1030db451*/
  do /*0x1030db448*/
  {
    v3 = *(_DWORD *)(*v2 + 8LL); /*0x1030db43a*/
    if ( (v3 & 3) != 0 ) /*0x1030db43f*/
      break; /*0x1030db43f*/
    v2 = (_QWORD *)v2[1]; /*0x1030db441*/
  }
  while ( v2 != nullptr ); /*0x1030db448*/
  return (v3 & 2) != 0; /*0x1030db450*/
}

// Address: 0x1030db454 | Name: _Curl_conn_get_ssl_info
bool __fastcall Curl_conn_get_ssl_info(__int64 a1, __int64 a2, unsigned int a3, __int64 a4)
{
  __int64 v8; // rdi

  if ( a3 > 1 ) /*0x1030db457*/
    return false; /*0x1030db4a8*/
  if ( Curl_conn_is_ssl(a1: a2, a2: a3) ) /*0x1030db475*/
  {
    v8 = *(_QWORD *)(a2 + 8LL * a3 + 408); /*0x1030db481*/
    if ( v8 != 0 ) /*0x1030db48c*/
      return (*(unsigned int (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64))(*(_QWORD *)v8 + 104LL))( /*0x1030db4a3*/
               a1: v8,
               a2: a1,
               a3: 12,
               a4: 0,
               a5: a4) == 0;
  }
  return false; /*0x1030db4aa*/
}

// Address: 0x1030db4b6 | Name: _Curl_conn_get_ip_info
__int64 __fastcall Curl_conn_get_ip_info(__int64 a1, __int64 a2, unsigned int a3, bool *a4)
{
  __int64 result; // rax
  __int64 v7; // rdi
  int v8; // [rsp-1Ch] [rbp-1Ch] BYREF

  result = 43; /*0x1030db4b6*/
  if ( a3 <= 1 ) /*0x1030db4be*/
  {
    result = 48; /*0x1030db4c0*/
    if ( a2 != 0 ) /*0x1030db4c8*/
    {
      v7 = *(_QWORD *)(a2 + 8LL * a3 + 408); /*0x1030db4dd*/
      if ( v7 != 0 ) /*0x1030db4e8*/
      {
        v8 = 0; /*0x1030db4ee*/
        result = (*(__int64 (__fastcall **)(__int64, __int64, __int64, int *))(*(_QWORD *)v7 + 104LL))( /*0x1030db503*/
                   a1: v7,
                   a2: a1,
                   a3: 8,
                   a4: &v8);
        *a4 = v8 != 0; /*0x1030db50a*/
      }
    }
  }
  return result; /*0x1030db515*/
}

// Address: 0x1030db516 | Name: _Curl_conn_cf_get_ip_info
__int64 __fastcall Curl_conn_cf_get_ip_info(__int64 a1, __int64 a2, bool *a3, __int64 a4)
{
  __int64 result; // rax
  int v6; // [rsp-1Ch] [rbp-1Ch] BYREF

  if ( a1 == 0 ) /*0x1030db519*/
    return 48; /*0x1030db555*/
  v6 = 0; /*0x1030db530*/
  result = (*(__int64 (__fastcall **)(__int64, __int64, __int64, int *, __int64))(*(_QWORD *)a1 + 104LL))( /*0x1030db542*/
             a1,
             a2,
             a3: 8,
             a4: &v6,
             a5: a4);
  *a3 = v6 != 0; /*0x1030db549*/
  return result; /*0x1030db554*/
}

// Address: 0x1030db55b | Name: _Curl_conn_is_multiplex
_BOOL8 __fastcall Curl_conn_is_multiplex(__int64 a1, unsigned int a2)
{
  _QWORD *v2; // rcx
  int v3; // eax

  if ( a2 >= 2 || a1 == 0 ) /*0x1030db564*/
    return false; /*0x1030db569*/
  v2 = *(_QWORD **)(a1 + 8LL * a2 + 408); /*0x1030db56d*/
  if ( v2 == nullptr ) /*0x1030db578*/
    return false; /*0x1030db599*/
  do /*0x1030db58f*/
  {
    v3 = *(_DWORD *)(*v2 + 8LL); /*0x1030db581*/
    if ( (v3 & 7) != 0 ) /*0x1030db586*/
      break; /*0x1030db586*/
    v2 = (_QWORD *)v2[1]; /*0x1030db588*/
  }
  while ( v2 != nullptr ); /*0x1030db58f*/
  return (v3 & 4) != 0; /*0x1030db598*/
}

// Address: 0x1030db59c | Name: _Curl_conn_get_transport
__int64 __fastcall Curl_conn_get_transport(__int64 a1, __int64 a2)
{
  return Curl_conn_cf_get_transport(a1: *(_QWORD *)(a2 + 408), a2: a1); /*0x1030db5ad*/
}

// Address: 0x1030db5b3 | Name: _Curl_conn_cf_get_transport
__int64 __fastcall Curl_conn_cf_get_transport(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  _DWORD v4[3]; // [rsp+0h] [rbp-Ch] BYREF

  v4[0] = 0; /*0x1030db5bc*/
  if ( a1 != 0 /*0x1030db5df*/
    && (*(unsigned int (__fastcall **)(__int64, __int64, __int64, _DWORD *, _QWORD))(*(_QWORD *)a1 + 104LL))(
         a1,
         a2,
         a3: 14,
         a4: v4,
         a5: 0) == 0 )
  {
    LOBYTE(result) = v4[0]; /*0x1030db5f6*/
  }
  else
  {
    result = *(_QWORD *)(a2 + 32); /*0x1030db5e1*/
    if ( result != 0 ) /*0x1030db5e8*/
      LOBYTE(result) = *(_BYTE *)(result + 816); /*0x1030db5ea*/
    else
      LOBYTE(result) = 0; /*0x1030db5f2*/
  }
  return (unsigned __int8)result; /*0x1030db600*/
}

// Address: 0x1030db603 | Name: _Curl_conn_get_alpn_negotiated
__int64 __fastcall Curl_conn_get_alpn_negotiated(__int64 a1, __int64 a2)
{
  __int64 v2; // rax
  __int64 v4; // rdi
  __int64 v5; // rbx
  __int64 v7; // [rsp+0h] [rbp-10h] BYREF

  v7 = v2; /*0x1030db608*/
  v4 = *(_QWORD *)(a2 + 408); /*0x1030db60c*/
  v7 = 0; /*0x1030db613*/
  if ( v4 == 0 ) /*0x1030db61e*/
    return 0; /*0x1030db641*/
  v5 = 0; /*0x1030db623*/
  if ( (*(unsigned int (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64 *))(*(_QWORD *)v4 + 104LL))( /*0x1030db639*/
         a1: v4,
         a2: a1,
         a3: 15,
         a4: 0,
         a5: &v7) == 0 )
    return v7; /*0x1030db63b*/
  return v5; /*0x1030db64a*/
}

// Address: 0x1030db64d | Name: _Curl_conn_cf_get_alpn_negotiated
__int64 __fastcall Curl_conn_cf_get_alpn_negotiated(__int64 a1, __int64 a2)
{
  __int64 v2; // rbx
  __int64 v4; // [rsp+0h] [rbp-10h] BYREF

  v4 = 0; /*0x1030db653*/
  if ( a1 == 0 ) /*0x1030db65e*/
    return 0; /*0x1030db67d*/
  v2 = 0; /*0x1030db663*/
  if ( (*(unsigned int (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64 *))(*(_QWORD *)a1 + 104LL))( /*0x1030db675*/
         a1,
         a2,
         a3: 15,
         a4: 0,
         a5: &v4) == 0 )
    return v4; /*0x1030db677*/
  return v2; /*0x1030db686*/
}

// Address: 0x1030db689 | Name: _Curl_conn_http_version
__int64 __fastcall Curl_conn_http_version(__int64 a1, __int64 a2)
{
  _QWORD *v3; // rdi
  __int64 v4; // r9
  int v5; // ecx
  unsigned __int8 v6; // cl
  int v7; // eax
  unsigned int v9; // [rsp-1Ch] [rbp-1Ch] BYREF

  v3 = *(_QWORD **)(a2 + 408); /*0x1030db68c*/
  if ( v3 != nullptr ) /*0x1030db696*/
  {
    while ( 1 ) /*0x1030db6a3*/
    {
      v4 = *v3; /*0x1030db6a3*/
      v5 = *(_DWORD *)(*v3 + 8LL); /*0x1030db6a6*/
      if ( (v5 & 0x10) != 0 ) /*0x1030db6ad*/
        break; /*0x1030db6ad*/
      if ( (v5 & 3) == 0 ) /*0x1030db6b2*/
      {
        v3 = (_QWORD *)v3[1]; /*0x1030db6b4*/
        if ( v3 != nullptr ) /*0x1030db6bb*/
          continue; /*0x1030db6bb*/
      }
      return 0; /*0x1030db6bf*/
    }
    v9 = 0; /*0x1030db6cc*/
    v7 = (*(__int64 (__fastcall **)(_QWORD *, __int64, __int64, unsigned int *, _QWORD))(v4 + 104))( /*0x1030db6dd*/
           a1: v3,
           a2: a1,
           a3: 9,
           a4: &v9,
           a5: 0);
    v6 = v9; /*0x1030db6e1*/
    if ( v9 >= 0x100 ) /*0x1030db6e9*/
      v6 = 0; /*0x1030db6e9*/
    if ( v7 != 0 ) /*0x1030db6ef*/
      return 0; /*0x1030db6ef*/
  }
  else
  {
    return 0; /*0x1030db6c1*/
  }
  return v6; /*0x1030db6fe*/
}

// Address: 0x1030db6ff | Name: _Curl_conn_data_pending
__int64 __fastcall Curl_conn_data_pending(__int64 a1, unsigned int a2)
{
  __int64 i; // rdi

  if ( a2 <= 1 ) /*0x1030db706*/
  {
    for ( i = *(_QWORD *)(*(_QWORD *)(a1 + 32) + 8LL * a2 + 408); i != 0; i = *(_QWORD *)(i + 8) ) /*0x1030db711*/
    {
      if ( (*(_BYTE *)(i + 36) & 1) != 0 ) /*0x1030db722*/
        return (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)i + 56LL))(a1: i, a2: a1); /*0x1030db739*/
    }
  }
  return 0; /*0x1030db72c*/
}

// Address: 0x1030db73b | Name: _Curl_conn_cf_needs_flush
bool __fastcall Curl_conn_cf_needs_flush(__int64 a1, __int64 a2)
{
  int v2; // eax
  _DWORD v4[3]; // [rsp+0h] [rbp-Ch] BYREF

  v4[0] = 0; /*0x1030db741*/
  if ( a1 == 0 ) /*0x1030db74b*/
    return false; /*0x1030db771*/
  v2 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, _DWORD *, _QWORD))(*(_QWORD *)a1 + 104LL))( /*0x1030db75f*/
         a1,
         a2,
         a3: 7,
         a4: v4,
         a5: 0);
  return v2 == 0 && v4[0] != 0; /*0x1030db777*/
}

// Address: 0x1030db77a | Name: _Curl_conn_cf_adjust_pollset
__int64 __fastcall Curl_conn_cf_adjust_pollset(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax
  __int64 v6; // r15

  result = 0; /*0x1030db78a*/
  while ( a1 != 0 ) /*0x1030db78f*/
  {
    v6 = a1; /*0x1030db791*/
    if ( (*(_BYTE *)(a1 + 36) & 1) == 0 ) /*0x1030db798*/
    {
      a1 = *(_QWORD *)(a1 + 8); /*0x1030db79a*/
      if ( a1 != 0 && (*(_BYTE *)(a1 + 36) & 1) == 0 ) /*0x1030db7a7*/
        continue; /*0x1030db7a7*/
    }
    while ( (*(_BYTE *)(v6 + 36) & 2) != 0 ) /*0x1030db7b9*/
    {
      v6 = *(_QWORD *)(v6 + 8); /*0x1030db7ab*/
      if ( v6 == 0 ) /*0x1030db7b2*/
        return result; /*0x1030db7b2*/
    }
    do /*0x1030db7bf*/
    {
      result = (*(__int64 (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 48LL))(a1: v6, a2, a3); /*0x1030db7cd*/
      v6 = *(_QWORD *)(v6 + 8); /*0x1030db7d0*/
    }
    while ( v6 != 0 && (_DWORD)result == 0 ); /*0x1030db7bf*/
    return result; /*0x1030db7bf*/
  }
  return result; /*0x1030db7dd*/
}

// Address: 0x1030db7e4 | Name: _Curl_conn_cf_poll
__int64 __fastcall Curl_conn_cf_poll(__int64 a1, __int64 a2, __int64 a3)
{
  unsigned int v6; // r15d
  _BYTE v8[72]; // [rsp+8h] [rbp-48h] BYREF

  Curl_pollset_init(a1: v8); /*0x1030db803*/
  v6 = Curl_conn_cf_adjust_pollset(a1, a2, a3: (__int64)v8); /*0x1030db816*/
  if ( v6 == 0 ) /*0x1030db81b*/
    v6 = Curl_pollset_poll(a1: a2, a2: v8, a3); /*0x1030db82c*/
  Curl_pollset_cleanup(a1: v8); /*0x1030db833*/
  return v6; /*0x1030db83b*/
}

// Address: 0x1030db848 | Name: _Curl_conn_get_current_host
__int64 __fastcall Curl_conn_get_current_host(__int64 a1, unsigned int a2, _QWORD *a3, _DWORD *a4)
{
  __int64 v6; // rax
  __int64 v8; // rcx
  __int64 v9; // rdi
  __int64 result; // rax

  v6 = *(_QWORD *)(a1 + 32); /*0x1030db858*/
  if ( v6 != 0 ) /*0x1030db85f*/
  {
    if ( a2 <= 1 ) /*0x1030db867*/
    {
      v8 = *(_QWORD *)(v6 + 8LL * a2 + 408); /*0x1030db86b*/
      if ( v8 != 0 ) /*0x1030db876*/
      {
        v9 = 0; /*0x1030db878*/
        do /*0x1030db899*/
        {
          if ( (*(_BYTE *)(v8 + 36) & 1) != 0 ) /*0x1030db87e*/
            break; /*0x1030db87e*/
          if ( (~*(_BYTE *)(*(_QWORD *)v8 + 8LL) & 9) == 0 ) /*0x1030db88b*/
            v9 = v8; /*0x1030db88b*/
          v8 = *(_QWORD *)(v8 + 8); /*0x1030db893*/
        }
        while ( v8 != 0 ); /*0x1030db899*/
        if ( v9 != 0 ) /*0x1030db89e*/
        {
          result = (*(__int64 (__fastcall **)(__int64, __int64, __int64, _DWORD *, _QWORD *))(*(_QWORD *)v9 + 104LL))( /*0x1030db8b1*/
                     a1: v9,
                     a2: a1,
                     a3: 11,
                     a4,
                     a5: a3);
          if ( (_DWORD)result == 0 ) /*0x1030db8b6*/
            return result; /*0x1030db8b6*/
          v6 = *(_QWORD *)(a1 + 32); /*0x1030db8b8*/
        }
      }
    }
    *a3 = *(_QWORD *)(v6 + 160); /*0x1030db8c3*/
    result = *(unsigned int *)(*(_QWORD *)(a1 + 32) + 796LL); /*0x1030db8ca*/
  }
  else
  {
    *a3 = ""; /*0x1030db8d9*/
    result = 0xFFFFFFFFLL; /*0x1030db8dc*/
  }
  *a4 = result; /*0x1030db8e1*/
  return result; /*0x1030db8e7*/
}

// Address: 0x1030db8ee | Name: _Curl_cf_def_cntrl
__int64 Curl_cf_def_cntrl()
{
  return 0; /*0x1030db8f4*/
}

// Address: 0x1030db8f6 | Name: _Curl_conn_cf_cntrl
__int64 __fastcall Curl_conn_cf_cntrl(_QWORD *a1, __int64 a2, char a3, unsigned int a4, unsigned int a5, __int64 a6)
{
  _QWORD *v10; // rbx
  __int64 result; // rax
  __int64 (*v12)(); // r9

  if ( a1 == nullptr ) /*0x1030db90b*/
    return 0; /*0x1030db958*/
  v10 = a1; /*0x1030db919*/
  result = 0; /*0x1030db91c*/
  do /*0x1030db954*/
  {
    v12 = *(__int64 (**)())(*v10 + 80LL); /*0x1030db921*/
    if ( v12 != Curl_cf_def_cntrl ) /*0x1030db92f*/
    {
      result = ((__int64 (__fastcall *)(_QWORD *, __int64, _QWORD, _QWORD, __int64))v12)( /*0x1030db941*/
                 a1: v10,
                 a2,
                 a3: a4,
                 a4: a5,
                 a5: a6);
      if ( a3 == 0 && (_DWORD)result != 0 ) /*0x1030db94b*/
        break; /*0x1030db94b*/
    }
    v10 = (_QWORD *)v10[1]; /*0x1030db94d*/
  }
  while ( v10 != nullptr ); /*0x1030db954*/
  return result; /*0x1030db95e*/
}

// Address: 0x1030db969 | Name: _Curl_conn_get_first_socket
__int64 __fastcall Curl_conn_get_first_socket(__int64 a1)
{
  __int64 v1; // rax
  _BYTE *v3; // rdi
  int v4; // eax
  unsigned int v7[5]; // [rsp+Ch] [rbp-14h] BYREF

  v1 = *(_QWORD *)(a1 + 32); /*0x1030db974*/
  if ( v1 != 0 )
  {
    v3 = *(_BYTE **)(v1 + 408); /*0x1030db980*/
    if ( v3 == nullptr || (v3[36] & 1) != 0 )
    {
      return *(unsigned int *)(v1 + 400); /*0x1030db9b1*/
    }
    else
    {
      v4 = (*(__int64 (__fastcall **)(_BYTE *, __int64, __int64, _QWORD, unsigned int *))(*(_QWORD *)v3 + 104LL))( /*0x1030db9a5*/
             a1: v3,
             a2: a1,
             a3: 3,
             a4: 0,
             a5: v7);
      return v4 != 0 ? -1u : v7[0];
    }
  }
  else
  {
    return (unsigned int)-1; /*0x1030db9b9*/
  }
}

// Address: 0x1030db9c9 | Name: _Curl_conn_get_remote_addr
__int64 __fastcall Curl_conn_get_remote_addr(__int64 a1, unsigned int a2)
{
  __int64 v2; // rax
  __int64 v4; // rcx
  __int64 v5; // rdi
  __int64 v6; // rbx
  __int64 v8; // [rsp+0h] [rbp-10h] BYREF

  v8 = v2; /*0x1030db9ce*/
  v4 = *(_QWORD *)(a1 + 32); /*0x1030db9d2*/
  if ( v4 == 0 || a2 >= 2 ) /*0x1030db9df*/
    return 0; /*0x1030db9e6*/
  v5 = *(_QWORD *)(v4 + 8LL * a2 + 408); /*0x1030db9ea*/
  if ( v5 == 0 ) /*0x1030db9f5*/
    return 0; /*0x1030dba1b*/
  v6 = 0; /*0x1030db9f7*/
  v8 = 0; /*0x1030db9fd*/
  if ( (*(unsigned int (__fastcall **)(__int64, __int64, __int64, _QWORD, __int64 *))(*(_QWORD *)v5 + 104LL))( /*0x1030dba13*/
         a1: v5,
         a2: a1,
         a3: 10,
         a4: 0,
         a5: &v8) == 0 )
    return v8; /*0x1030dba15*/
  return v6; /*0x1030dba24*/
}

// Address: 0x1030dba27 | Name: _Curl_conn_ev_data_setup
__int64 __fastcall Curl_conn_ev_data_setup(__int64 a1)
{
  __int64 v2; // r15
  char v3; // r12
  __int64 v4; // rcx
  _QWORD *i; // r14
  __int64 (*v6)(); // rax
  __int64 result; // rax
  bool v8; // zf

  v2 = *(_QWORD *)(a1 + 32); /*0x1030dba38*/
  v3 = 1; /*0x1030dba3c*/
  v4 = 0; /*0x1030dba3f*/
  do /*0x1030dba8e*/
  {
    for ( i = *(_QWORD **)(v2 + 8 * v4 + 408); i != nullptr; i = (_QWORD *)i[1] ) /*0x1030dba48*/
    {
      v6 = *(__int64 (**)())(*i + 80LL); /*0x1030dba58*/
      if ( v6 != Curl_cf_def_cntrl ) /*0x1030dba5f*/
      {
        result = ((__int64 (__fastcall *)(_QWORD *, __int64, __int64, _QWORD, _QWORD))v6)( /*0x1030dba71*/
                   a1: i,
                   a2: a1,
                   a3: 4,
                   a4: 0,
                   a5: 0);
        if ( (_DWORD)result != 0 ) /*0x1030dba75*/
          return result; /*0x1030dba75*/
      }
    }
    result = 0; /*0x1030dba7d*/
    v4 = 1; /*0x1030dba7f*/
    v8 = (v3 & 1) == 0; /*0x1030dba84*/
    v3 = 0; /*0x1030dba88*/
  }
  while ( !v8 ); /*0x1030dba8e*/
  return result; /*0x1030dba94*/
}

// Address: 0x1030dba9f | Name: _Curl_conn_ev_data_done_send
__int64 __fastcall Curl_conn_ev_data_done_send(__int64 a1)
{
  __int64 v2; // r15
  char v3; // r12
  __int64 result; // rax
  _QWORD *i; // r14
  __int64 (*v6)(); // rax
  bool v7; // zf

  v2 = *(_QWORD *)(a1 + 32); /*0x1030dbab0*/
  v3 = 1; /*0x1030dbab4*/
  result = 0; /*0x1030dbab7*/
  do /*0x1030dbb00*/
  {
    for ( i = *(_QWORD **)(v2 + 8 * result + 408); i != nullptr; i = (_QWORD *)i[1] ) /*0x1030dbac0*/
    {
      v6 = *(__int64 (**)())(*i + 80LL); /*0x1030dbad0*/
      if ( v6 != Curl_cf_def_cntrl ) /*0x1030dbad7*/
        ((void (__fastcall *)(_QWORD *, __int64, __int64, _QWORD, _QWORD))v6)(a1: i, a2: a1, a3: 8, a4: 0, a5: 0); /*0x1030dbae9*/
    }
    result = 1; /*0x1030dbaf1*/
    v7 = (v3 & 1) == 0; /*0x1030dbaf6*/
    v3 = 0; /*0x1030dbafa*/
  }
  while ( !v7 ); /*0x1030dbb00*/
  return result; /*0x1030dbb06*/
}

// Address: 0x1030dbb11 | Name: _Curl_conn_ev_data_done
__int64 __fastcall Curl_conn_ev_data_done(__int64 a1, unsigned int a2)
{
  char v4; // r13
  __int64 result; // rax
  _QWORD *i; // r15
  __int64 (*v7)(); // rax
  bool v8; // zf
  __int64 v9; // [rsp+0h] [rbp-30h]

  v9 = *(_QWORD *)(a1 + 32); /*0x1030dbb28*/
  v4 = 1; /*0x1030dbb2c*/
  result = 0; /*0x1030dbb2f*/
  do /*0x1030dbb7c*/
  {
    for ( i = *(_QWORD **)(v9 + 8 * result + 408); i != nullptr; i = (_QWORD *)i[1] ) /*0x1030dbb3c*/
    {
      v7 = *(__int64 (**)())(*i + 80LL); /*0x1030dbb4c*/
      if ( v7 != Curl_cf_def_cntrl ) /*0x1030dbb53*/
        ((void (__fastcall *)(_QWORD *, __int64, __int64, _QWORD, _QWORD))v7)(a1: i, a2: a1, a3: 7, a4: a2, a5: 0); /*0x1030dbb65*/
    }
    result = 1; /*0x1030dbb6d*/
    v8 = (v4 & 1) == 0; /*0x1030dbb72*/
    v4 = 0; /*0x1030dbb76*/
  }
  while ( !v8 ); /*0x1030dbb7c*/
  return result; /*0x1030dbb82*/
}

// Address: 0x1030dbb8d | Name: _Curl_conn_ev_data_pause
__int64 __fastcall Curl_conn_ev_data_pause(__int64 a1, unsigned int a2)
{
  char v4; // r13
  __int64 v5; // rcx
  _QWORD *i; // r15
  __int64 (*v7)(); // rax
  __int64 result; // rax
  bool v9; // zf
  __int64 v10; // [rsp+0h] [rbp-30h]

  v10 = *(_QWORD *)(a1 + 32); /*0x1030dbba4*/
  v4 = 1; /*0x1030dbba8*/
  v5 = 0; /*0x1030dbbab*/
  do /*0x1030dbbfe*/
  {
    for ( i = *(_QWORD **)(v10 + 8 * v5 + 408); i != nullptr; i = (_QWORD *)i[1] ) /*0x1030dbbb8*/
    {
      v7 = *(__int64 (**)())(*i + 80LL); /*0x1030dbbc8*/
      if ( v7 != Curl_cf_def_cntrl ) /*0x1030dbbcf*/
      {
        result = ((__int64 (__fastcall *)(_QWORD *, __int64, __int64, _QWORD, _QWORD))v7)( /*0x1030dbbe1*/
                   a1: i,
                   a2: a1,
                   a3: 6,
                   a4: a2,
                   a5: 0);
        if ( (_DWORD)result != 0 ) /*0x1030dbbe5*/
          return result; /*0x1030dbbe5*/
      }
    }
    result = 0; /*0x1030dbbed*/
    v5 = 1; /*0x1030dbbef*/
    v9 = (v4 & 1) == 0; /*0x1030dbbf4*/
    v4 = 0; /*0x1030dbbf8*/
  }
  while ( !v9 ); /*0x1030dbbfe*/
  return result; /*0x1030dbc04*/
}

// Address: 0x1030dbc0f | Name: _Curl_conn_is_alive
__int64 __fastcall Curl_conn_is_alive(__int64 a1, __int64 a2)
{
  _QWORD *v3; // rdi

  v3 = *(_QWORD **)(a2 + 408); /*0x1030dbc16*/
  if ( v3 == nullptr || (*(_BYTE *)(v3[3] + 728LL) & 0x20) != 0 ) /*0x1030dbc2d*/
    return 0; /*0x1030dbc3c*/
  else
    return (*(__int64 (__fastcall **)(_QWORD *, __int64))(*v3 + 88LL))(a1: v3, a2: a1); /*0x1030dbc3a*/
}

// Address: 0x1030dbc40 | Name: _Curl_conn_keep_alive
__int64 __fastcall Curl_conn_keep_alive(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 result; // rax
  __int64 v5; // rdi

  result = 43; /*0x1030dbc44*/
  if ( a3 <= 1 ) /*0x1030dbc4c*/
  {
    v5 = *(_QWORD *)(a2 + 8LL * a3 + 408); /*0x1030dbc53*/
    if ( v5 != 0 ) /*0x1030dbc5e*/
      return (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v5 + 96LL))(a1: v5, a2: a1); /*0x1030dbc6b*/
    else
      return 0; /*0x1030dbc6d*/
  }
  return result; /*0x1030dbc6f*/
}

// Address: 0x1030dbc71 | Name: _Curl_conn_get_max_concurrent
__int64 __fastcall Curl_conn_get_max_concurrent(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v4; // rdi
  bool v5; // cl
  __int64 result; // rax
  int v7[3]; // [rsp+0h] [rbp-Ch] BYREF

  v7[0] = -1; /*0x1030dbc77*/
  if ( a3 > 1 ) /*0x1030dbc81*/
    return 0; /*0x1030dbcb7*/
  v4 = *(_QWORD *)(a2 + 8LL * a3 + 408); /*0x1030dbc88*/
  if ( v4 != 0 ) /*0x1030dbc93*/
  {
    v5 = (*(unsigned int (__fastcall **)(__int64, __int64, __int64, int *, _QWORD))(*(_QWORD *)v4 + 104LL))( /*0x1030dbcb0*/
           a1: v4,
           a2: a1,
           a3: 1,
           a4: v7,
           a5: 0) != 0;
    LODWORD(result) = v7[0]; /*0x1030dbcb3*/
  }
  else
  {
    v5 = true; /*0x1030dbcbb*/
    LODWORD(result) = -1; /*0x1030dbcbd*/
  }
  result = (int)result; /*0x1030dbcc4*/
  if ( (int)result < 0 ) /*0x1030dbccb*/
    result = 1; /*0x1030dbccb*/
  if ( v5 ) /*0x1030dbcd1*/
    return 1; /*0x1030dbcd1*/
  return result; /*0x1030dbcd9*/
}

// Address: 0x1030dbcdc | Name: _Curl_conn_get_stream_error
__int64 __fastcall Curl_conn_get_stream_error(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned int v3; // ebx
  __int64 v5; // rdi
  int v6; // eax
  int v8[5]; // [rsp+Ch] [rbp-14h] BYREF

  v8[0] = 0; /*0x1030dbce7*/
  v3 = 0; /*0x1030dbcee*/
  if ( a3 <= 1 ) /*0x1030dbcf3*/
  {
    v5 = *(_QWORD *)(a2 + 8LL * a3 + 408); /*0x1030dbcfa*/
    if ( v5 == 0 ) /*0x1030dbd05*/
      return 0; /*0x1030dbd05*/
    v3 = 0; /*0x1030dbd0a*/
    v6 = (*(__int64 (__fastcall **)(__int64, __int64, __int64, int *, _QWORD))(*(_QWORD *)v5 + 104LL))( /*0x1030dbd1e*/
           a1: v5,
           a2: a1,
           a3: 6,
           a4: v8,
           a5: 0);
    if ( v8[0] > 0 ) /*0x1030dbd27*/
      v3 = v8[0]; /*0x1030dbd27*/
    if ( v6 != 0 ) /*0x1030dbd2c*/
      return 0; /*0x1030dbd2e*/
  }
  return v3; /*0x1030dbd32*/
}

// Address: 0x1030dbd3b | Name: _Curl_conn_sockindex
__int64 __fastcall Curl_conn_sockindex(__int64 a1, int a2)
{
  __int64 v2; // rcx
  __int64 result; // rax

  if ( a1 == 0 ) /*0x1030dbd42*/
    return 0; /*0x1030dbd42*/
  v2 = *(_QWORD *)(a1 + 32); /*0x1030dbd44*/
  if ( v2 == 0 || a2 == -1 ) /*0x1030dbd51*/
    return 0; /*0x1030dbd56*/
  result = 1; /*0x1030dbd58*/
  if ( *(_DWORD *)(v2 + 404) != a2 ) /*0x1030dbd63*/
    return 0; /*0x1030dbd65*/
  return result; /*0x1030dbd67*/
}

// Address: 0x1030dbd69 | Name: _Curl_conn_recv
__int64 __fastcall Curl_conn_recv(__int64 a1, unsigned int a2, __int64 a3, __int64 a4, _QWORD *a5)
{
  __int64 result; // rax
  __int64 v6; // rax
  __int64 (*v7)(void); // rax

  result = 43; /*0x1030dbd6d*/
  if ( a2 <= 1 ) /*0x1030dbd75*/
  {
    if ( a1 != 0 && (v6 = *(_QWORD *)(a1 + 32)) != 0 && (v7 = *(__int64 (**)(void))(v6 + 8LL * a2 + 424)) != nullptr ) /*0x1030dbd93*/
    {
      return v7(); /*0x1030dbd96*/
    }
    else
    {
      *a5 = 0; /*0x1030dbd98*/
      return 2; /*0x1030dbd9f*/
    }
  }
  return result; /*0x1030dbda4*/
}

// Address: 0x1030dbda6 | Name: _Curl_conn_send
__int64 __fastcall Curl_conn_send(__int64 a1, __int64 a2, __int64 a3, __int64 a4, unsigned __int8 a5, _QWORD *a6)
{
  __int64 result; // rax
  __int64 v7; // rax
  __int64 (__fastcall *v8)(__int64, __int64, __int64, __int64, _QWORD); // rax

  result = 43; /*0x1030dbdaa*/
  if ( (unsigned int)a2 <= 1 ) /*0x1030dbdb2*/
  {
    if ( a1 != 0 /*0x1030dbdd0*/
      && (v7 = *(_QWORD *)(a1 + 32)) != 0
      && (v8 = *(__int64 (__fastcall **)(__int64, __int64, __int64, __int64, _QWORD))(v7 + 8LL * (unsigned int)a2 + 440)) != nullptr )
    {
      return v8(a1, a2, a3, a4, a5); /*0x1030dbdd7*/
    }
    else
    {
      *a6 = 0; /*0x1030dbdd9*/
      return 2; /*0x1030dbde0*/
    }
  }
  return result; /*0x1030dbde5*/
}

// Address: 0x1030dbde7 | Name: _Curl_cpool_init
__int64 __fastcall Curl_cpool_init(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 result; // rax

  result = Curl_hash_init(a1, a2: a4, a3: Curl_hash_str, a4: &curlx_str_key_compare, a5: cpool_bundle_free_entry); /*0x1030dbe15*/
  *(_QWORD *)(a1 + 88) = a2; /*0x1030dbe1a*/
  *(_QWORD *)(a1 + 96) = a3; /*0x1030dbe1e*/
  *(_BYTE *)(a1 + 104) |= 2u; /*0x1030dbe22*/
  return result; /*0x1030dbe2b*/
}

// Address: 0x1030dbe32 | Name: _cpool_bundle_free_entry
void __fastcall cpool_bundle_free_entry(void *a1)
{
  Curl_cfree(a1); /*0x1030dbe3e*/
}

// Address: 0x1030dbe40 | Name: _Curl_cpool_destroy
void __fastcall Curl_cpool_destroy(__int64 a1)
{
  char v2; // al
  __int64 v3; // rdi
  __int64 v4; // rcx
  __int64 first; // rax
  __int64 i; // r14
  __int64 v7; // rax

  if ( a1 != 0 ) /*0x1030dbe4a*/
  {
    v2 = *(_BYTE *)(a1 + 104); /*0x1030dbe53*/
    if ( (v2 & 2) != 0 ) /*0x1030dbe58*/
    {
      v3 = *(_QWORD *)(a1 + 88); /*0x1030dbe5e*/
      if ( v3 != 0 ) /*0x1030dbe65*/
      {
        v4 = *(_QWORD *)(a1 + 96); /*0x1030dbe6b*/
        if ( v4 != 0 && (*(_BYTE *)(v4 + 4) & 0x20) != 0 ) /*0x1030dbe78*/
        {
          Curl_share_lock(a1: v3, a2: 5, a3: 2); /*0x1030dbe84*/
          v2 = *(_BYTE *)(a1 + 104); /*0x1030dbe89*/
        }
        *(_BYTE *)(a1 + 104) = v2 | 1; /*0x1030dbe8e*/
        first = cpool_get_first(a1); /*0x1030dbe94*/
        if ( first != 0 ) /*0x1030dbe9c*/
        {
          for ( i = first; i != 0; i = cpool_get_first(a1) ) /*0x1030dbe9e*/
          {
            cpool_remove_conn(a1, a2: i); /*0x1030dbea7*/
            cpool_discard_conn(a1, a2: *(_QWORD *)(a1 + 88), a3: i, a4: 0); /*0x1030dbeb8*/
          }
        }
        *(_BYTE *)(a1 + 104) &= ~1u; /*0x1030dbecd*/
        v7 = *(_QWORD *)(a1 + 96); /*0x1030dbed1*/
        if ( v7 != 0 && (*(_BYTE *)(v7 + 4) & 0x20) != 0 ) /*0x1030dbede*/
          Curl_share_unlock(a1: *(_QWORD *)(a1 + 88), a2: 5); /*0x1030dbee9*/
        Curl_hash_destroy(a1); /*0x1030dbef5*/
      }
    }
  }
}

// Address: 0x1030dbeff | Name: _cpool_get_first
__int64 __fastcall cpool_get_first(__int64 a1)
{
  __int64 element; // rax
  __int64 v2; // rbx
  __int64 v3; // rax
  _BYTE v5[40]; // [rsp+8h] [rbp-28h] BYREF

  Curl_hash_start_iterate(a1, a2: v5); /*0x1030dbf11*/
  element = Curl_hash_next_element(a1: v5); /*0x1030dbf19*/
  if ( element == 0 ) /*0x1030dbf21*/
    return 0; /*0x1030dbf46*/
  v2 = 0; /*0x1030dbf27*/
  while ( 1 ) /*0x1030dbf2d*/
  {
    v3 = Curl_llist_head(a1: *(_QWORD *)(element + 8)); /*0x1030dbf2d*/
    if ( v3 != 0 ) /*0x1030dbf35*/
      break; /*0x1030dbf35*/
    element = Curl_hash_next_element(a1: v5); /*0x1030dbf3a*/
    if ( element == 0 ) /*0x1030dbf42*/
      return v2; /*0x1030dbf42*/
  }
  return Curl_node_elem(a1: v3); /*0x1030dbf58*/
}

// Address: 0x1030dbf61 | Name: _cpool_remove_conn
__int64 __fastcall cpool_remove_conn(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  __int64 v5; // r12
  size_t v6; // rax
  __int64 v7; // r15

  result = Curl_node_llist(a1: a2); /*0x1030dbf75*/
  if ( result != 0 ) /*0x1030dbf7d*/
  {
    v5 = result; /*0x1030dbf7f*/
    v6 = strlen(__s: *(const char **)(a2 + 88)); /*0x1030dbf89*/
    result = Curl_hash_pick(a1, a2: *(_QWORD *)(a2 + 88), a3: v6 + 1); /*0x1030dbf98*/
    if ( v5 == result ) /*0x1030dbfa0*/
    {
      v7 = result; /*0x1030dbfa2*/
      Curl_node_remove(a1: a2); /*0x1030dbfa8*/
      *(_BYTE *)(a2 + 731) &= ~8u; /*0x1030dbfad*/
      result = Curl_llist_count(a1: v7); /*0x1030dbfb8*/
      if ( result == 0 ) /*0x1030dbfc0*/
        result = Curl_hash_delete(a1, a2: v7 + 40, a3: *(_QWORD *)(v7 + 32)); /*0x1030dbfd0*/
      *(_BYTE *)(a2 + 731) &= ~8u; /*0x1030dbfd5*/
      --*(_QWORD *)(a1 + 48); /*0x1030dbfdd*/
    }
  }
  return result; /*0x1030dbfe1*/
}

// Address: 0x1030dbfea | Name: _cpool_discard_conn
char __fastcall cpool_discard_conn(__int64 a1, __int64 a2, __int64 a3, unsigned __int8 a4)
{
  char result; // al
  char v7; // al
  __int64 v9; // rdi
  char v10[33]; // [rsp+Fh] [rbp-21h] BYREF

  result = a4 ^ 1; /*0x1030dbffe*/
  v10[0] = 0; /*0x1030dc000*/
  if ( ((a4 ^ 1) & (*(_DWORD *)(a3 + 804) != 0)) == 0 ) /*0x1030dc010*/
  {
    v7 = *(_BYTE *)(a3 + 820) | a4; /*0x1030dc01b*/
    *(_DWORD *)(a3 + 728) = ((v7 & 1) << 23) | *(_DWORD *)(a3 + 728) & 0xFF7FFFFF; /*0x1030dc033*/
    if ( (v7 & 1) != 0 ) /*0x1030dc03b*/
    {
      v10[0] = 1; /*0x1030dc03d*/
    }
    else
    {
      Curl_cshutdn_run_once(a1: *(_QWORD *)(a1 + 88), a2: a3, a3: v10); /*0x1030dc054*/
      if ( (v10[0] & 1) == 0 ) /*0x1030dc05e*/
      {
        v9 = *(_QWORD *)(a2 + 104); /*0x1030dc060*/
        if ( v9 != 0 ) /*0x1030dc067*/
          return Curl_cshutdn_add(a1: v9 + 496, a2: a3, a3: *(_QWORD *)(a1 + 48)); /*0x1030dc07c*/
      }
    }
    return Curl_cshutdn_terminate(a1: *(_QWORD *)(a1 + 88), a2: a3, a3: 0); /*0x1030dc087*/
  }
  return result; /*0x1030dc08c*/
}

// Address: 0x1030dc099 | Name: _Curl_cpool_xfer_init
void __fastcall Curl_cpool_xfer_init(_QWORD *a1)
{
  __int64 v2; // r14
  __int64 v3; // r14
  __int64 v4; // r14
  __int64 v5; // rax
  __int64 v6; // rax
  __int64 v7; // rax

  if ( a1 == nullptr ) /*0x1030dc0a6*/
    goto LABEL_7; /*0x1030dc0a6*/
  v2 = a1[15]; /*0x1030dc0a8*/
  if ( v2 == 0 || (*(_BYTE *)(v2 + 4) & 0x20) == 0 ) /*0x1030dc0b6*/
  {
    v3 = a1[14]; /*0x1030dc0b8*/
    if ( v3 != 0 || (v3 = a1[13]) != 0 ) /*0x1030dc0c8*/
    {
      v4 = v3 + 544; /*0x1030dc0ca*/
      goto LABEL_9; /*0x1030dc0d1*/
    }
LABEL_7:
    a1[1] = 0; /*0x1030dc0d3*/
    a1[300] = -1; /*0x1030dc0db*/
    return; /*0x1030dc0e6*/
  }
  v4 = v2 + 48; /*0x1030dc0e8*/
LABEL_9:
  v5 = *(_QWORD *)(v4 + 96); /*0x1030dc0ec*/
  if ( v5 != 0 && (*(_BYTE *)(v5 + 4) & 0x20) != 0 ) /*0x1030dc0f9*/
    Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dc108*/
  *(_BYTE *)(v4 + 104) |= 1u; /*0x1030dc10d*/
  v6 = *(_QWORD *)(v4 + 64); /*0x1030dc112*/
  *(_QWORD *)(v4 + 64) = v6 + 1; /*0x1030dc11a*/
  a1[1] = v6; /*0x1030dc11e*/
  if ( v6 < 0 ) /*0x1030dc125*/
    *(_QWORD *)(v4 + 64) = 0; /*0x1030dc127*/
  a1[300] = -1; /*0x1030dc12f*/
  *(_BYTE *)(v4 + 104) &= ~1u; /*0x1030dc13a*/
  v7 = *(_QWORD *)(v4 + 96); /*0x1030dc13f*/
  if ( v7 != 0 && (*(_BYTE *)(v7 + 4) & 0x20) != 0 ) /*0x1030dc14c*/
    Curl_share_unlock(a1, a2: 5); /*0x1030dc15f*/
}

// Address: 0x1030dc164 | Name: _Curl_cpool_check_limits
__int64 __fastcall Curl_cpool_check_limits(_QWORD *a1, __int64 a2)
{
  unsigned int v2; // r12d
  _QWORD *v3; // r14
  __int64 v4; // rbx
  __int64 v5; // rbx
  __int64 v6; // rbx
  __int64 v7; // rdi
  __int64 v8; // rax
  unsigned __int64 v9; // r15
  unsigned __int64 v10; // r13
  __int64 v11; // rax
  __int64 v12; // r12
  size_t v13; // rax
  __int64 v14; // rax
  __int64 v15; // r13
  __int64 v16; // r15
  __int64 v17; // rax
  unsigned __int64 v18; // r15
  __int64 v19; // r15
  __int64 v20; // r12
  __int64 v21; // rax
  __int64 v22; // r13
  __int64 v23; // rbx
  __int64 v24; // r15
  __int64 v25; // rax
  __int64 v26; // r14
  __int64 v27; // rax
  size_t v28; // rax
  __int64 v29; // rax
  __int64 v30; // rax
  unsigned __int64 v31; // r15
  __int64 v32; // r15
  __int64 v33; // rax
  __int64 oldest_idle; // rax
  __int64 v35; // rax
  unsigned __int64 v37; // [rsp+8h] [rbp-58h]
  __int64 v39; // [rsp+18h] [rbp-48h]
  unsigned __int64 v40; // [rsp+20h] [rbp-40h]
  __int64 v41; // [rsp+28h] [rbp-38h]
  _QWORD *v42; // [rsp+30h] [rbp-30h]

  v2 = 0; /*0x1030dc179*/
  if ( a1 != nullptr ) /*0x1030dc17f*/
  {
    v3 = a1; /*0x1030dc185*/
    v4 = a1[15]; /*0x1030dc188*/
    if ( v4 != 0 && (*(_BYTE *)(v4 + 4) & 0x20) != 0 ) /*0x1030dc195*/
    {
      v6 = v4 + 48; /*0x1030dc1b6*/
    }
    else
    {
      v5 = a1[14]; /*0x1030dc197*/
      if ( v5 == 0 ) /*0x1030dc19e*/
      {
        v5 = a1[13]; /*0x1030dc1a0*/
        if ( v5 == 0 ) /*0x1030dc1a7*/
          return v2; /*0x1030dc1a7*/
      }
      v6 = v5 + 544; /*0x1030dc1ad*/
    }
    v7 = *(_QWORD *)(v6 + 88); /*0x1030dc1ba*/
    v8 = *(_QWORD *)(v7 + 104); /*0x1030dc1be*/
    v2 = 0; /*0x1030dc1c2*/
    if ( v8 != 0 ) /*0x1030dc1c8*/
    {
      v9 = *(_QWORD *)(v8 + 656); /*0x1030dc1ca*/
      v10 = *(_QWORD *)(v8 + 664); /*0x1030dc1d1*/
    }
    else
    {
      v9 = 0; /*0x1030dc1da*/
      v10 = 0; /*0x1030dc1dd*/
    }
    if ( (v10 | v9) != 0 ) /*0x1030dc1e6*/
    {
      v11 = *(_QWORD *)(v6 + 96); /*0x1030dc1ec*/
      if ( v11 != 0 && (*(_BYTE *)(v11 + 4) & 0x20) != 0 ) /*0x1030dc1f9*/
        Curl_share_lock(a1: v7, a2: 5, a3: 2); /*0x1030dc205*/
      *(_BYTE *)(v6 + 104) |= 1u; /*0x1030dc20a*/
      v12 = a2; /*0x1030dc211*/
      if ( v9 != 0 ) /*0x1030dc215*/
      {
        v37 = v10; /*0x1030dc217*/
        v42 = v3; /*0x1030dc21b*/
        v13 = strlen(__s: *(const char **)(a2 + 88)); /*0x1030dc227*/
        v14 = Curl_hash_pick(a1: v6, a2: *(_QWORD *)(a2 + 88), a3: v13 + 1); /*0x1030dc236*/
        v15 = v14; /*0x1030dc23b*/
        v40 = v9; /*0x1030dc241*/
        if ( v14 != 0 ) /*0x1030dc245*/
          v16 = Curl_llist_count(a1: v14); /*0x1030dc24f*/
        else
          v16 = 0; /*0x1030dc265*/
        v17 = Curl_cshutdn_dest_count(a1: v3, a2: *(_QWORD *)(a2 + 88)); /*0x1030dc274*/
        v41 = v16; /*0x1030dc279*/
        v18 = v17 + v16; /*0x1030dc27d*/
        if ( v18 < v40 ) /*0x1030dc284*/
          goto LABEL_43; /*0x1030dc284*/
        v19 = v17; /*0x1030dc28a*/
        v39 = v6; /*0x1030dc28d*/
        while ( 1 ) /*0x1030dc291*/
        {
          if ( v19 != 0 ) /*0x1030dc294*/
          {
            if ( (unsigned __int8)Curl_cshutdn_close_oldest(a1: v3, a2: *(_QWORD *)(v12 + 88)) == 0 ) /*0x1030dc2a5*/
              goto LABEL_42; /*0x1030dc2a5*/
          }
          else
          {
            if ( v15 == 0 || (v20 = Curl_pgrs_now(a1: v3), (v21 = Curl_llist_head(a1: v15)) == 0) ) /*0x1030dc2cf*/
            {
              v19 = 0; /*0x1030dc39d*/
              goto LABEL_42; /*0x1030dc3a0*/
            }
            v22 = v21; /*0x1030dc2d5*/
            v23 = -1; /*0x1030dc2d8*/
            v24 = 0; /*0x1030dc2df*/
            do /*0x1030dc31e*/
            {
              v25 = Curl_node_elem(a1: v22); /*0x1030dc2e5*/
              if ( *(_DWORD *)(v25 + 804) == 0 ) /*0x1030dc2f1*/
              {
                v26 = v25; /*0x1030dc2f3*/
                v27 = curlx_ptimediff_ms(a1: v20, a2: v25 + 384); /*0x1030dc300*/
                if ( v27 > v23 ) /*0x1030dc308*/
                {
                  v23 = v27; /*0x1030dc308*/
                  v24 = v26; /*0x1030dc30c*/
                }
              }
              v22 = Curl_node_next(a1: v22); /*0x1030dc318*/
            }
            while ( v22 != 0 ); /*0x1030dc31e*/
            if ( v24 == 0 ) /*0x1030dc323*/
            {
              v19 = 0; /*0x1030dc3a2*/
              v6 = v39; /*0x1030dc3a5*/
              v3 = v42; /*0x1030dc3a9*/
LABEL_42:
              v18 = v41 + v19; /*0x1030dc3ad*/
LABEL_43:
              v2 = v18 >= v40; /*0x1030dc3b1*/
              if ( v18 >= v40 ) /*0x1030dc3bc*/
                goto LABEL_57; /*0x1030dc3bc*/
              v10 = v37; /*0x1030dc3c2*/
              if ( v37 == 0 ) /*0x1030dc3c9*/
                goto LABEL_57; /*0x1030dc3c9*/
LABEL_45:
              v30 = Curl_cshutdn_count(a1: *(_QWORD *)(v6 + 88)); /*0x1030dc3cb*/
              v31 = v30 + *(_QWORD *)(v6 + 48); /*0x1030dc3d8*/
              if ( v31 < v10 ) /*0x1030dc3de*/
                goto LABEL_56; /*0x1030dc3de*/
              v32 = v30; /*0x1030dc3e0*/
              while ( 1 ) /*0x1030dc3e3*/
              {
                if ( v32 != 0 ) /*0x1030dc3e9*/
                {
                  if ( (unsigned __int8)Curl_cshutdn_close_oldest(a1: v3, a2: 0) == 0 ) /*0x1030dc3f4*/
                    goto LABEL_55; /*0x1030dc3f4*/
                }
                else
                {
                  v33 = Curl_pgrs_now(a1: v3); /*0x1030dc3f8*/
                  oldest_idle = cpool_get_oldest_idle(a1: v6, a2: v33); /*0x1030dc403*/
                  if ( oldest_idle == 0 ) /*0x1030dc40b*/
                  {
                    v32 = 0; /*0x1030dc432*/
LABEL_55:
                    v31 = *(_QWORD *)(v6 + 48) + v32; /*0x1030dc435*/
LABEL_56:
                    v2 = 2 * (v31 >= v10); /*0x1030dc439*/
LABEL_57:
                    *(_BYTE *)(v6 + 104) &= ~1u; /*0x1030dc446*/
                    v35 = *(_QWORD *)(v6 + 96); /*0x1030dc44a*/
                    if ( v35 != 0 && (*(_BYTE *)(v35 + 4) & 0x20) != 0 ) /*0x1030dc457*/
                      Curl_share_unlock(a1: *(_QWORD *)(v6 + 88), a2: 5); /*0x1030dc462*/
                    return v2; /*0x1030dc462*/
                  }
                  Curl_conn_terminate(a1: *(_QWORD *)(v6 + 88), a2: oldest_idle, a3: 0); /*0x1030dc416*/
                }
                v32 = Curl_cshutdn_count(a1: *(_QWORD *)(v6 + 88)); /*0x1030dc424*/
                if ( *(_QWORD *)(v6 + 48) + v32 < v10 ) /*0x1030dc42e*/
                  goto LABEL_55; /*0x1030dc42e*/
              }
            }
            v6 = v39; /*0x1030dc325*/
            Curl_conn_terminate(a1: *(_QWORD *)(v39 + 88), a2: v24, a3: 0); /*0x1030dc332*/
            v12 = a2; /*0x1030dc337*/
            v28 = strlen(__s: *(const char **)(a2 + 88)); /*0x1030dc343*/
            v29 = Curl_hash_pick(a1: v39, a2: *(_QWORD *)(a2 + 88), a3: v28 + 1); /*0x1030dc352*/
            if ( v29 != 0 ) /*0x1030dc35a*/
            {
              v15 = v29; /*0x1030dc35c*/
              v41 = Curl_llist_count(a1: v29); /*0x1030dc367*/
            }
            else
            {
              v15 = 0; /*0x1030dc36d*/
              v41 = 0; /*0x1030dc370*/
            }
            v3 = v42; /*0x1030dc378*/
          }
          v19 = Curl_cshutdn_dest_count(a1: *(_QWORD *)(v6 + 88), a2: *(_QWORD *)(v12 + 88)); /*0x1030dc38a*/
          if ( v41 + v19 < v40 ) /*0x1030dc395*/
            goto LABEL_42; /*0x1030dc395*/
        }
      }
      if ( v10 == 0 ) /*0x1030dc257*/
      {
        v2 = 0; /*0x1030dc25d*/
        goto LABEL_57; /*0x1030dc260*/
      }
      goto LABEL_45; /*0x1030dc257*/
    }
  }
  return v2; /*0x1030dc46a*/
}

// Address: 0x1030dc479 | Name: _Curl_conn_terminate
char __fastcall Curl_conn_terminate(_QWORD *a1, __int64 a2, unsigned __int8 a3)
{
  __int64 v3; // rax
  __int64 v7; // r14
  __int64 v8; // r14
  __int64 v9; // r14
  char v10; // r13
  __int64 v11; // rcx
  char v12; // al
  char v13; // r12
  __int64 v14; // rdi

  if ( a1 != nullptr ) /*0x1030dc48a*/
  {
    v7 = a1[15]; /*0x1030dc499*/
    if ( v7 != 0 && (*(_BYTE *)(v7 + 4) & 0x20) != 0 ) /*0x1030dc4a7*/
    {
      v9 = v7 + 48; /*0x1030dc4c8*/
    }
    else
    {
      v8 = a1[14]; /*0x1030dc4a9*/
      if ( v8 == 0 ) /*0x1030dc4b0*/
      {
        v8 = a1[13]; /*0x1030dc4b2*/
        if ( v8 == 0 ) /*0x1030dc4b9*/
          return v3; /*0x1030dc4b9*/
      }
      v9 = v8 + 544; /*0x1030dc4bf*/
    }
    LOBYTE(v3) = *(_DWORD *)(a2 + 804) != 0; /*0x1030dc4d4*/
    if ( ((a3 ^ 1) & (unsigned __int8)v3) == 0 ) /*0x1030dc4df*/
    {
      v10 = *(_BYTE *)(v9 + 104); /*0x1030dc4e5*/
      if ( (v10 & 1) == 0 ) /*0x1030dc4ed*/
      {
        v11 = *(_QWORD *)(v9 + 96); /*0x1030dc4ef*/
        v12 = *(_BYTE *)(v9 + 104); /*0x1030dc4f3*/
        if ( v11 != 0 ) /*0x1030dc4f9*/
        {
          v12 = *(_BYTE *)(v9 + 104); /*0x1030dc4ff*/
          if ( (*(_BYTE *)(v11 + 4) & 0x20) != 0 ) /*0x1030dc502*/
          {
            Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dc511*/
            v12 = *(_BYTE *)(v9 + 104); /*0x1030dc516*/
          }
        }
        *(_BYTE *)(v9 + 104) = v12 | 1; /*0x1030dc51c*/
      }
      if ( (*(_BYTE *)(a2 + 731) & 8) != 0 ) /*0x1030dc528*/
        cpool_remove_conn(a1: v9, a2); /*0x1030dc530*/
      v13 = *(_BYTE *)(a2 + 820) | a3; /*0x1030dc535*/
      v14 = a1[13]; /*0x1030dc53c*/
      if ( v14 != 0 ) /*0x1030dc543*/
        LOBYTE(v3) = cpool_discard_conn(a1: v14 + 544, a2: (__int64)a1, a3: a2, a4: v13 & 1); /*0x1030dc559*/
      else
        LOBYTE(v3) = Curl_cshutdn_terminate(a1: *(_QWORD *)(v9 + 88), a2, a3: (v13 & 1) == 0); /*0x1030dc571*/
      if ( (v10 & 1) == 0 ) /*0x1030dc57a*/
      {
        *(_BYTE *)(v9 + 104) &= ~1u; /*0x1030dc57c*/
        v3 = *(_QWORD *)(v9 + 96); /*0x1030dc581*/
        if ( v3 != 0 && (*(_BYTE *)(v3 + 4) & 0x20) != 0 ) /*0x1030dc58e*/
          LOBYTE(v3) = Curl_share_unlock(a1, a2: 5); /*0x1030dc5b5*/
      }
    }
  }
  return v3; /*0x1030dc594*/
}

// Address: 0x1030dc5ba | Name: _cpool_get_oldest_idle
__int64 __fastcall cpool_get_oldest_idle(__int64 a1, __int64 a2)
{
  __int64 element; // rax
  __int64 v4; // r15
  __int64 v5; // r14
  __int64 v6; // rax
  __int64 i; // r12
  __int64 v8; // rax
  __int64 v9; // r13
  __int64 v10; // rax
  _BYTE v12[64]; // [rsp+0h] [rbp-40h] BYREF

  Curl_hash_start_iterate(a1, a2: v12); /*0x1030dc5d5*/
  element = Curl_hash_next_element(a1: v12); /*0x1030dc5dd*/
  if ( element == 0 ) /*0x1030dc5e5*/
    return 0; /*0x1030dc663*/
  v4 = -1; /*0x1030dc5e7*/
  v5 = 0; /*0x1030dc5ee*/
  do /*0x1030dc65f*/
  {
    v6 = Curl_llist_head(a1: *(_QWORD *)(element + 8)); /*0x1030dc5f5*/
    if ( v6 != 0 ) /*0x1030dc5fd*/
    {
      for ( i = v6; i != 0; i = Curl_node_next(a1: i) ) /*0x1030dc5ff*/
      {
        v8 = Curl_node_elem(a1: i); /*0x1030dc605*/
        if ( *(_DWORD *)(v8 + 804) == 0 ) /*0x1030dc611*/
        {
          v9 = v8; /*0x1030dc613*/
          if ( (*(_BYTE *)(v8 + 728) & 0x20) == 0 && (*(_BYTE *)(v8 + 820) & 1) == 0 ) /*0x1030dc627*/
          {
            v10 = curlx_ptimediff_ms(a1: a2, a2: v8 + 384); /*0x1030dc633*/
            if ( v10 > v4 ) /*0x1030dc63b*/
            {
              v5 = v9; /*0x1030dc63b*/
              v4 = v10; /*0x1030dc63f*/
            }
          }
        }
      }
    }
    element = Curl_hash_next_element(a1: v12); /*0x1030dc657*/
  }
  while ( element != 0 ); /*0x1030dc65f*/
  return v5; /*0x1030dc669*/
}

// Address: 0x1030dc678 | Name: _Curl_cpool_add
__int64 __fastcall Curl_cpool_add(_QWORD *a1, __int64 a2)
{
  unsigned int v2; // r12d
  const __m128i *v5; // r14
  const __m128i *v6; // r14
  const __m128i *v7; // r14
  __int64 v8; // rax
  size_t v9; // rax
  _QWORD *v10; // r13
  __m128i v11; // xmm0
  __int64 v12; // rax
  _QWORD *v14; // rax
  const char *__src; // [rsp+0h] [rbp-40h]
  size_t v16; // [rsp+10h] [rbp-30h]
  size_t v17; // [rsp+10h] [rbp-30h]

  v2 = 2; /*0x1030dc689*/
  if ( a1 == nullptr ) /*0x1030dc692*/
    return v2; /*0x1030dc692*/
  v5 = (const __m128i *)a1[15]; /*0x1030dc69e*/
  if ( v5 != nullptr && (v5->i8[4] & 0x20) != 0 ) /*0x1030dc6ac*/
  {
    v7 = v5 + 3; /*0x1030dc6cd*/
  }
  else
  {
    v6 = (const __m128i *)a1[14]; /*0x1030dc6ae*/
    if ( v6 == nullptr ) /*0x1030dc6b5*/
    {
      v6 = (const __m128i *)a1[13]; /*0x1030dc6b7*/
      if ( v6 == nullptr ) /*0x1030dc6be*/
        return v2; /*0x1030dc6be*/
    }
    v7 = v6 + 34; /*0x1030dc6c4*/
  }
  v8 = v7[6].i64[0]; /*0x1030dc6d1*/
  if ( v8 != 0 && (*(_BYTE *)(v8 + 4) & 0x20) != 0 ) /*0x1030dc6de*/
    Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dc6ed*/
  v7[6].i8[8] |= 1u; /*0x1030dc6f2*/
  v9 = strlen(__s: *(const char **)(a2 + 88)); /*0x1030dc6fe*/
  v10 = (_QWORD *)Curl_hash_pick(a1: v7, a2: *(_QWORD *)(a2 + 88), a3: v9 + 1); /*0x1030dc712*/
  if ( v10 == nullptr ) /*0x1030dc718*/
  {
    __src = *(const char **)(a2 + 88); /*0x1030dc786*/
    v16 = strlen(__s: __src); /*0x1030dc796*/
    v14 = Curl_ccalloc(__count: 1u, __size: v16 + 48); /*0x1030dc7a3*/
    v2 = 27; /*0x1030dc7a5*/
    if ( v14 == nullptr ) /*0x1030dc7ae*/
      goto LABEL_13; /*0x1030dc7ae*/
    v10 = v14; /*0x1030dc7b0*/
    Curl_llist_init(a1: v14, a2: 0); /*0x1030dc7c3*/
    v17 = v16 + 1; /*0x1030dc7cb*/
    v10[4] = v17; /*0x1030dc7cf*/
    memcpy(__dst: v10 + 5, __src, __n: v17); /*0x1030dc7e1*/
    if ( Curl_hash_add(a1: v7, a2: v10 + 5, a3: v17, a4: v10) == 0 ) /*0x1030dc7fb*/
    {
      Curl_cfree(a1: v10); /*0x1030dc810*/
      goto LABEL_13; /*0x1030dc816*/
    }
  }
  Curl_llist_append(a1: v10, a2, a3: a2); /*0x1030dc723*/
  *(_BYTE *)(a2 + 731) |= 8u; /*0x1030dc728*/
  v11 = _mm_loadu_si128(v7 + 3); /*0x1030dc730*/
  *(_QWORD *)(a2 + 80) = _mm_extract_epi64(v11, 1); /*0x1030dc736*/
  v7[3] = _mm_sub_epi64(v11, (__m128i)-1LL); /*0x1030dc746*/
  v2 = 0; /*0x1030dc74c*/
LABEL_13:
  v7[6].i8[8] &= ~1u; /*0x1030dc74f*/
  v12 = v7[6].i64[0]; /*0x1030dc754*/
  if ( v12 != 0 && (*(_BYTE *)(v12 + 4) & 0x20) != 0 ) /*0x1030dc761*/
    Curl_share_unlock(a1, a2: 5); /*0x1030dc76b*/
  return v2; /*0x1030dc773*/
}

// Address: 0x1030dc81b | Name: _Curl_cpool_conn_now_idle
__int64 __fastcall Curl_cpool_conn_now_idle(_QWORD *a1, __int64 a2)
{
  unsigned int v2; // r15d
  __int64 v5; // r14
  __int64 v6; // r14
  __int64 v7; // r14
  __int64 v8; // rax
  __int64 v9; // rdi
  unsigned int v10; // r12d
  unsigned int v11; // eax
  char v12; // r13
  __int64 v13; // rcx
  char v14; // al
  __int64 v15; // rax
  __int64 oldest_idle; // rax
  __int64 v17; // rax
  __int64 v19; // [rsp+0h] [rbp-30h]

  LOBYTE(v2) = 1; /*0x1030dc829*/
  if ( a1 != nullptr ) /*0x1030dc82f*/
  {
    v5 = a1[15]; /*0x1030dc83b*/
    if ( v5 != 0 && (*(_BYTE *)(v5 + 4) & 0x20) != 0 ) /*0x1030dc849*/
    {
      v7 = v5 + 48; /*0x1030dc85d*/
    }
    else
    {
      v6 = a1[14]; /*0x1030dc84b*/
      if ( v6 != 0 ) /*0x1030dc852*/
      {
        v7 = v6 + 544; /*0x1030dc854*/
      }
      else
      {
        v8 = a1[13]; /*0x1030dc863*/
        v7 = v8 + 544; /*0x1030dc867*/
        if ( v8 == 0 ) /*0x1030dc871*/
          v7 = 0; /*0x1030dc871*/
      }
    }
    v9 = a1[13]; /*0x1030dc875*/
    v10 = *(_DWORD *)(v9 + 724); /*0x1030dc879*/
    if ( v10 == 0 ) /*0x1030dc883*/
    {
      v11 = Curl_multi_xfers_running(a1: v9); /*0x1030dc885*/
      v10 = -1; /*0x1030dc896*/
      if ( v11 < 0x40000000 ) /*0x1030dc89c*/
        v10 = 4 * v11; /*0x1030dc89c*/
    }
    *(_OWORD *)(a2 + 384) = *(_OWORD *)Curl_pgrs_now(a1); /*0x1030dc8ab*/
    if ( v7 != 0 && v10 != 0 ) /*0x1030dc8bf*/
    {
      v19 = a2; /*0x1030dc8c5*/
      v12 = *(_BYTE *)(v7 + 104); /*0x1030dc8c9*/
      if ( (v12 & 1) == 0 ) /*0x1030dc8d1*/
      {
        v13 = *(_QWORD *)(v7 + 96); /*0x1030dc8d3*/
        v14 = *(_BYTE *)(v7 + 104); /*0x1030dc8d7*/
        if ( v13 != 0 ) /*0x1030dc8dd*/
        {
          v14 = *(_BYTE *)(v7 + 104); /*0x1030dc8e3*/
          if ( (*(_BYTE *)(v13 + 4) & 0x20) != 0 ) /*0x1030dc8e6*/
          {
            Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dc8f5*/
            v14 = *(_BYTE *)(v7 + 104); /*0x1030dc8fa*/
          }
        }
        *(_BYTE *)(v7 + 104) = v14 | 1; /*0x1030dc900*/
      }
      if ( *(_QWORD *)(v7 + 48) > (unsigned __int64)v10 ) /*0x1030dc90b*/
      {
        v15 = Curl_pgrs_now(a1); /*0x1030dc910*/
        oldest_idle = cpool_get_oldest_idle(a1: v7, a2: v15); /*0x1030dc91b*/
        LOBYTE(v2) = oldest_idle != v19; /*0x1030dc924*/
        if ( oldest_idle != 0 ) /*0x1030dc92b*/
          Curl_conn_terminate(a1, a2: oldest_idle, a3: 0); /*0x1030dc935*/
      }
      if ( (v12 & 1) == 0 ) /*0x1030dc93e*/
      {
        *(_BYTE *)(v7 + 104) &= ~1u; /*0x1030dc940*/
        v17 = *(_QWORD *)(v7 + 96); /*0x1030dc945*/
        if ( v17 != 0 && (*(_BYTE *)(v17 + 4) & 0x20) != 0 ) /*0x1030dc952*/
          Curl_share_unlock(a1, a2: 5); /*0x1030dc95c*/
      }
    }
  }
  return v2; /*0x1030dc968*/
}

// Address: 0x1030dc973 | Name: _Curl_cpool_find
__int64 __fastcall Curl_cpool_find(
        _QWORD *a1,
        const char *a2,
        unsigned __int8 (__fastcall *a3)(__int64, __int64),
        __int64 (__fastcall *a4)(_QWORD, __int64),
        __int64 a5)
{
  _QWORD *v8; // rbx
  __int64 v9; // r14
  __int64 v10; // r14
  __int64 v11; // r14
  __int64 v12; // r15
  __int64 v13; // rax
  size_t v14; // rax
  __int64 v15; // rax
  __int64 v16; // rbx
  __int64 v17; // rax
  _QWORD *v20; // [rsp+10h] [rbp-30h]

  if ( a1 == nullptr ) /*0x1030dc987*/
    goto LABEL_7; /*0x1030dc987*/
  v8 = a1; /*0x1030dc992*/
  v9 = a1[15]; /*0x1030dc995*/
  if ( v9 == 0 || (*(_BYTE *)(v9 + 4) & 0x20) == 0 ) /*0x1030dc9a3*/
  {
    v10 = a1[14]; /*0x1030dc9a5*/
    if ( v10 != 0 || (v10 = a1[13]) != 0 ) /*0x1030dc9b5*/
    {
      v11 = v10 + 544; /*0x1030dc9b7*/
      goto LABEL_9; /*0x1030dc9be*/
    }
LABEL_7:
    LODWORD(v12) = 0; /*0x1030dc9c0*/
    return (unsigned int)v12; /*0x1030dc9c3*/
  }
  v11 = v9 + 48; /*0x1030dc9c8*/
LABEL_9:
  v13 = *(_QWORD *)(v11 + 96); /*0x1030dc9cc*/
  if ( v13 != 0 && (*(_BYTE *)(v13 + 4) & 0x20) != 0 ) /*0x1030dc9dd*/
    Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dc9ec*/
  *(_BYTE *)(v11 + 104) |= 1u; /*0x1030dc9f1*/
  v14 = strlen(__s: a2); /*0x1030dc9f9*/
  v15 = Curl_hash_pick(a1: v11, a2, a3: v14 + 1); /*0x1030dca08*/
  if ( v15 != 0 ) /*0x1030dca10*/
  {
    v20 = v8; /*0x1030dca12*/
    v12 = Curl_llist_head(a1: v15); /*0x1030dca1e*/
    while ( v12 != 0 ) /*0x1030dca24*/
    {
      v16 = Curl_node_elem(a1: v12); /*0x1030dca2e*/
      v12 = Curl_node_next(a1: v12); /*0x1030dca39*/
      if ( a3(a1: v16, a2: a5) != 0 ) /*0x1030dca47*/
      {
        LOBYTE(v12) = 1; /*0x1030dca49*/
        goto LABEL_19; /*0x1030dca4c*/
      }
    }
    LODWORD(v12) = 0; /*0x1030dca53*/
LABEL_19:
    v8 = v20; /*0x1030dca56*/
  }
  else
  {
    LODWORD(v12) = 0; /*0x1030dca4e*/
  }
  if ( a4 != nullptr ) /*0x1030dca61*/
    LODWORD(v12) = a4(a1: (unsigned __int8)v12, a2: a5); /*0x1030dca6c*/
  *(_BYTE *)(v11 + 104) &= ~1u; /*0x1030dca6f*/
  v17 = *(_QWORD *)(v11 + 96); /*0x1030dca74*/
  if ( v17 != 0 && (*(_BYTE *)(v17 + 4) & 0x20) != 0 ) /*0x1030dca81*/
    Curl_share_unlock(a1: v8, a2: 5); /*0x1030dca8b*/
  return (unsigned int)v12; /*0x1030dca93*/
}

// Address: 0x1030dcaa2 | Name: _Curl_cpool_prune_dead
void __fastcall Curl_cpool_prune_dead(_QWORD *a1)
{
  __int64 v2; // r14
  __int64 v3; // r14
  __int64 v4; // r14
  __int64 v5; // rax
  __int64 v6; // rax
  __int64 v7; // rax
  _OWORD v8[4]; // [rsp+0h] [rbp-40h] BYREF

  if ( a1 != nullptr ) /*0x1030dcab6*/
  {
    v2 = a1[15]; /*0x1030dcabf*/
    if ( v2 != 0 && (*(_BYTE *)(v2 + 4) & 0x20) != 0 ) /*0x1030dcacd*/
    {
      v4 = v2 + 48; /*0x1030dcaee*/
    }
    else
    {
      v3 = a1[14]; /*0x1030dcacf*/
      if ( v3 == 0 ) /*0x1030dcad6*/
      {
        v3 = a1[13]; /*0x1030dcad8*/
        if ( v3 == 0 ) /*0x1030dcadf*/
          return; /*0x1030dcadf*/
      }
      v4 = v3 + 544; /*0x1030dcae5*/
    }
    v8[0] = 0; /*0x1030dcaf5*/
    v5 = *(_QWORD *)(v4 + 96); /*0x1030dcaf9*/
    if ( v5 != 0 && (*(_BYTE *)(v5 + 4) & 0x20) != 0 ) /*0x1030dcb06*/
      Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dcb15*/
    *(_BYTE *)(v4 + 104) |= 1u; /*0x1030dcb1a*/
    v6 = Curl_pgrs_now(a1); /*0x1030dcb22*/
    if ( curlx_ptimediff_ms(a1: v6, a2: v4 + 72) >= 1000 ) /*0x1030dcb3c*/
    {
      while ( (unsigned __int8)cpool_foreach(a1, a2: v4, a3: v8, a4: cpool_reap_dead_cb) != 0 ) /*0x1030dcb5c*/
        ; /*0x1030dcb49*/
      *(_OWORD *)(v4 + 72) = *(_OWORD *)Curl_pgrs_now(a1); /*0x1030dcb69*/
    }
    *(_BYTE *)(v4 + 104) &= ~1u; /*0x1030dcb6d*/
    v7 = *(_QWORD *)(v4 + 96); /*0x1030dcb72*/
    if ( v7 != 0 && (*(_BYTE *)(v7 + 4) & 0x20) != 0 ) /*0x1030dcb7f*/
      Curl_share_unlock(a1, a2: 5); /*0x1030dcb89*/
  }
}

// Address: 0x1030dcb9d | Name: _cpool_foreach
char __fastcall cpool_foreach(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        unsigned int (__fastcall *a4)(__int64, __int64, __int64))
{
  __int64 element; // rax
  __int64 v8; // r12
  __int64 v9; // r12
  __int64 v10; // r13
  _BYTE v12[24]; // [rsp+8h] [rbp-48h] BYREF
  __int64 v13; // [rsp+20h] [rbp-30h]

  Curl_hash_start_iterate(a1: a2, a2: v12); /*0x1030dcbc1*/
  element = Curl_hash_next_element(a1: v12); /*0x1030dcbc9*/
  if ( element != 0 ) /*0x1030dcbd1*/
  {
    do /*0x1030dcc27*/
    {
      v8 = *(_QWORD *)(element + 8); /*0x1030dcbd7*/
      v13 = Curl_hash_next_element(a1: v12); /*0x1030dcbe0*/
      v9 = Curl_llist_head(a1: v8); /*0x1030dcbec*/
      while ( v9 != 0 ) /*0x1030dcbf2*/
      {
        v10 = Curl_node_elem(a1: v9); /*0x1030dcbfc*/
        v9 = Curl_node_next(a1: v9); /*0x1030dcc07*/
        if ( a4(a1, a2: v10, a3) == 1 ) /*0x1030dcc18*/
          return 1; /*0x1030dcc1a*/
      }
      element = v13; /*0x1030dcc1c*/
    }
    while ( v13 != 0 ); /*0x1030dcc27*/
  }
  return 0; /*0x1030dcc2f*/
}

// Address: 0x1030dcc3e | Name: _cpool_reap_dead_cb
__int64 __fastcall cpool_reap_dead_cb(_QWORD *a1, __int64 a2, _QWORD *a3)
{
  char v6; // cl
  __int64 result; // rax

  if ( *(_DWORD *)(a2 + 804) == 0 && (*(_BYTE *)(a2 + 731) & 1) != 0 /*0x1030dcc77*/
    || (++*a3, v6 = Curl_conn_seems_dead(a1: a2, a2: a1), result = 0, v6 != 0) )
  {
    ++a3[1]; /*0x1030dcc79*/
    Curl_conn_terminate(a1, a2, a3: 0); /*0x1030dcc85*/
    return 1; /*0x1030dcc8a*/
  }
  return result; /*0x1030dcc93*/
}

// Address: 0x1030dcc9a | Name: _Curl_cpool_upkeep
__int64 __fastcall Curl_cpool_upkeep(_QWORD *a1)
{
  __int64 v2; // r14
  __int64 v3; // r14
  __int64 v4; // r14
  __int64 v5; // rax
  __int64 v6; // rax

  if ( a1 != nullptr ) /*0x1030dcc9d*/
  {
    v2 = a1[15]; /*0x1030dccad*/
    if ( v2 != 0 && (*(_BYTE *)(v2 + 4) & 0x20) != 0 ) /*0x1030dccbb*/
    {
      v4 = v2 + 48; /*0x1030dccd8*/
    }
    else
    {
      v3 = a1[14]; /*0x1030dccbd*/
      if ( v3 == 0 ) /*0x1030dccc4*/
      {
        v3 = a1[13]; /*0x1030dccc6*/
        if ( v3 == 0 ) /*0x1030dcccd*/
          return 0; /*0x1030dcccd*/
      }
      v4 = v3 + 544; /*0x1030dcccf*/
    }
    v5 = *(_QWORD *)(v4 + 96); /*0x1030dccdc*/
    if ( v5 != 0 && (*(_BYTE *)(v5 + 4) & 0x20) != 0 ) /*0x1030dcce9*/
      Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dccf8*/
    *(_BYTE *)(v4 + 104) |= 1u; /*0x1030dccfd*/
    cpool_foreach((__int64)a1, a2: v4, a3: 0, a4: (unsigned int (__fastcall *)(__int64, __int64, __int64))conn_upkeep); /*0x1030dcd11*/
    *(_BYTE *)(v4 + 104) &= ~1u; /*0x1030dcd16*/
    v6 = *(_QWORD *)(v4 + 96); /*0x1030dcd1b*/
    if ( v6 != 0 && (*(_BYTE *)(v6 + 4) & 0x20) != 0 ) /*0x1030dcd28*/
      Curl_share_unlock(a1, a2: 5); /*0x1030dcd32*/
  }
  return 0; /*0x1030dcd3d*/
}

// Address: 0x1030dcd3e | Name: _conn_upkeep
__int64 conn_upkeep()
{
  Curl_conn_upkeep(); /*0x1030dcd42*/
  return 0; /*0x1030dcd49*/
}

// Address: 0x1030dcd4b | Name: _Curl_cpool_get_conn
__int64 __fastcall Curl_cpool_get_conn(_QWORD *a1, __int64 a2)
{
  __int64 v3; // r14
  __int64 v4; // r14
  __int64 v5; // r14
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // [rsp+0h] [rbp-20h] BYREF
  __int64 v10; // [rsp+8h] [rbp-18h]

  if ( a1 == nullptr ) /*0x1030dcd59*/
    return 0; /*0x1030dcd59*/
  v3 = a1[15]; /*0x1030dcd5e*/
  if ( v3 == 0 || (*(_BYTE *)(v3 + 4) & 0x20) == 0 ) /*0x1030dcd6c*/
  {
    v4 = a1[14]; /*0x1030dcd6e*/
    if ( v4 != 0 || (v4 = a1[13]) != 0 ) /*0x1030dcd7e*/
    {
      v5 = v4 + 544; /*0x1030dcd80*/
      goto LABEL_9; /*0x1030dcd87*/
    }
    return 0; /*0x1030dcd8b*/
  }
  v5 = v3 + 48; /*0x1030dcd8d*/
LABEL_9:
  v9 = a2; /*0x1030dcd91*/
  v10 = 0; /*0x1030dcd95*/
  v7 = *(_QWORD *)(v5 + 96); /*0x1030dcd9d*/
  if ( v7 != 0 && (*(_BYTE *)(v7 + 4) & 0x20) != 0 ) /*0x1030dcdaa*/
    Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dcdb9*/
  *(_BYTE *)(v5 + 104) |= 1u; /*0x1030dcdbe*/
  cpool_foreach( /*0x1030dcdd4*/
    (__int64)a1,
    a2: v5,
    a3: (__int64)&v9,
    a4: (unsigned int (__fastcall *)(__int64, __int64, __int64))cpool_find_conn);
  *(_BYTE *)(v5 + 104) &= ~1u; /*0x1030dcdd9*/
  v8 = *(_QWORD *)(v5 + 96); /*0x1030dcdde*/
  if ( v8 != 0 && (*(_BYTE *)(v8 + 4) & 0x20) != 0 ) /*0x1030dcdeb*/
    Curl_share_unlock(a1, a2: 5); /*0x1030dcdf5*/
  return v10; /*0x1030dcdfe*/
}

// Address: 0x1030dce07 | Name: _cpool_find_conn
__int64 __fastcall cpool_find_conn(__int64 a1, __int64 a2, _QWORD *a3)
{
  __int64 result; // rax

  result = 0; /*0x1030dce0f*/
  if ( *(_QWORD *)(a2 + 80) == *a3 ) /*0x1030dce14*/
  {
    a3[1] = a2; /*0x1030dce16*/
    return 1; /*0x1030dce1a*/
  }
  return result; /*0x1030dce1f*/
}

// Address: 0x1030dce21 | Name: _Curl_cpool_do_by_id
void __fastcall Curl_cpool_do_by_id(_QWORD *a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v5; // r14
  __int64 v6; // r14
  __int64 v7; // r14
  __int64 v8; // rax
  __int64 v9; // rax
  _QWORD v10[5]; // [rsp+8h] [rbp-28h] BYREF

  if ( a1 != nullptr ) /*0x1030dce2f*/
  {
    v5 = a1[15]; /*0x1030dce38*/
    if ( v5 != 0 && (*(_BYTE *)(v5 + 4) & 0x20) != 0 ) /*0x1030dce46*/
    {
      v7 = v5 + 48; /*0x1030dce63*/
    }
    else
    {
      v6 = a1[14]; /*0x1030dce48*/
      if ( v6 == 0 ) /*0x1030dce4f*/
      {
        v6 = a1[13]; /*0x1030dce51*/
        if ( v6 == 0 ) /*0x1030dce58*/
          return; /*0x1030dce58*/
      }
      v7 = v6 + 544; /*0x1030dce5a*/
    }
    v10[0] = a2; /*0x1030dce67*/
    v10[1] = a3; /*0x1030dce6b*/
    v10[2] = a4; /*0x1030dce6f*/
    v8 = *(_QWORD *)(v7 + 96); /*0x1030dce73*/
    if ( v8 != 0 && (*(_BYTE *)(v8 + 4) & 0x20) != 0 ) /*0x1030dce80*/
      Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dce8f*/
    *(_BYTE *)(v7 + 104) |= 1u; /*0x1030dce94*/
    cpool_foreach( /*0x1030dceaa*/
      (__int64)a1,
      a2: v7,
      a3: (__int64)v10,
      a4: (unsigned int (__fastcall *)(__int64, __int64, __int64))cpool_do_conn);
    *(_BYTE *)(v7 + 104) &= ~1u; /*0x1030dceaf*/
    v9 = *(_QWORD *)(v7 + 96); /*0x1030dceb4*/
    if ( v9 != 0 && (*(_BYTE *)(v9 + 4) & 0x20) != 0 ) /*0x1030dcec1*/
      Curl_share_unlock(a1, a2: 5); /*0x1030dcecb*/
  }
}

// Address: 0x1030dced9 | Name: _cpool_do_conn
__int64 __fastcall cpool_do_conn(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 result; // rax

  result = 0; /*0x1030dcee0*/
  if ( *(_QWORD *)(a2 + 80) == *(_QWORD *)a3 ) /*0x1030dcee5*/
  {
    (*(void (__fastcall **)(__int64, __int64, _QWORD))(a3 + 8))(a1: a2, a2: a1, a3: *(_QWORD *)(a3 + 16)); /*0x1030dcef8*/
    return 1; /*0x1030dcefc*/
  }
  return result; /*0x1030dcf02*/
}

// Address: 0x1030dcf03 | Name: _Curl_cpool_do_locked
__int64 __fastcall Curl_cpool_do_locked(
        _QWORD *a1,
        __int64 a2,
        void (__fastcall *a3)(__int64, _QWORD *, __int64),
        __int64 a4)
{
  void (__fastcall *v5)(__int64, _QWORD *, __int64); // rcx
  __int64 v8; // r12
  __int64 v9; // r12
  __int64 v10; // r12
  __int64 result; // rax
  __int64 v12; // rax

  v5 = a3; /*0x1030dcf14*/
  if ( a1 == nullptr ) /*0x1030dcf20*/
    return ((__int64 (__fastcall *)(__int64, _QWORD *, __int64))a3)(a1: a2, a2: a1, a3: a4); /*0x1030dcf20*/
  v8 = a1[15]; /*0x1030dcf22*/
  if ( v8 == 0 || (*(_BYTE *)(v8 + 4) & 0x20) == 0 ) /*0x1030dcf31*/
  {
    v9 = a1[14]; /*0x1030dcf33*/
    if ( v9 != 0 || (v9 = a1[13]) != 0 ) /*0x1030dcf43*/
    {
      v10 = v9 + 544; /*0x1030dcf45*/
      goto LABEL_9; /*0x1030dcf4c*/
    }
    return ((__int64 (__fastcall *)(__int64, _QWORD *, __int64))a3)(a1: a2, a2: a1, a3: a4); /*0x1030dcf65*/
  }
  v10 = v8 + 48; /*0x1030dcf67*/
LABEL_9:
  v12 = *(_QWORD *)(v10 + 96); /*0x1030dcf6b*/
  if ( v12 != 0 && (*(_BYTE *)(v12 + 4) & 0x20) != 0 ) /*0x1030dcf79*/
  {
    Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dcf8b*/
    v5 = a3; /*0x1030dcf90*/
  }
  *(_BYTE *)(v10 + 104) |= 1u; /*0x1030dcf93*/
  v5(a1: a2, a2: a1, a3: a4); /*0x1030dcfa2*/
  *(_BYTE *)(v10 + 104) &= ~1u; /*0x1030dcfa4*/
  result = *(_QWORD *)(v10 + 96); /*0x1030dcfaa*/
  if ( result != 0 && (*(_BYTE *)(result + 4) & 0x20) != 0 ) /*0x1030dcfb8*/
    return Curl_share_unlock(a1, a2: 5); /*0x1030dcfdf*/
  return result; /*0x1030dcf5c*/
}

// Address: 0x1030dcfe4 | Name: _Curl_cpool_nw_changed
__int64 __fastcall Curl_cpool_nw_changed(_QWORD *a1)
{
  __int64 result; // rax
  __int64 v3; // r14
  __int64 v4; // r14
  __int64 v5; // r14
  __int64 v6; // rax

  if ( a1 != nullptr ) /*0x1030dcff1*/
  {
    v3 = a1[15]; /*0x1030dcffa*/
    if ( v3 != 0 && (*(_BYTE *)(v3 + 4) & 0x20) != 0 ) /*0x1030dd008*/
    {
      v5 = v3 + 48; /*0x1030dd025*/
    }
    else
    {
      v4 = a1[14]; /*0x1030dd00a*/
      if ( v4 == 0 ) /*0x1030dd011*/
      {
        v4 = a1[13]; /*0x1030dd013*/
        if ( v4 == 0 ) /*0x1030dd01a*/
          return result; /*0x1030dd01a*/
      }
      v5 = v4 + 544; /*0x1030dd01c*/
    }
    v6 = *(_QWORD *)(v5 + 96); /*0x1030dd029*/
    if ( v6 != 0 && (*(_BYTE *)(v6 + 4) & 0x20) != 0 ) /*0x1030dd036*/
      Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dd045*/
    *(_BYTE *)(v5 + 104) |= 1u; /*0x1030dd04a*/
    cpool_foreach( /*0x1030dd05e*/
      (__int64)a1,
      a2: v5,
      a3: 0,
      a4: (unsigned int (__fastcall *)(__int64, __int64, __int64))cpool_mark_stale);
    while ( cpool_foreach( /*0x1030dd07c*/
              (__int64)a1,
              a2: v5,
              a3: 0,
              a4: (unsigned int (__fastcall *)(__int64, __int64, __int64))cpool_reap_no_reuse) != 0 )
      ; /*0x1030dd06a*/
    *(_BYTE *)(v5 + 104) &= ~1u; /*0x1030dd07e*/
    result = *(_QWORD *)(v5 + 96); /*0x1030dd083*/
    if ( result != 0 && (*(_BYTE *)(result + 4) & 0x20) != 0 ) /*0x1030dd090*/
      return Curl_share_unlock(a1, a2: 5); /*0x1030dd0af*/
  }
  return result; /*0x1030dd096*/
}

// Address: 0x1030dd0b4 | Name: _cpool_mark_stale
__int64 __fastcall cpool_mark_stale(__int64 a1, __int64 a2)
{
  *(_BYTE *)(a2 + 731) |= 1u; /*0x1030dd0b8*/
  return 0; /*0x1030dd0c1*/
}

// Address: 0x1030dd0c3 | Name: _cpool_reap_no_reuse
__int64 __fastcall cpool_reap_no_reuse(_QWORD *a1, __int64 a2)
{
  __int64 result; // rax

  result = 0; /*0x1030dd0c3*/
  if ( *(_DWORD *)(a2 + 804) == 0 && (*(_BYTE *)(a2 + 731) & 1) != 0 ) /*0x1030dd0d6*/
  {
    Curl_conn_terminate(a1, a2, a3: 0); /*0x1030dd0de*/
    return 1; /*0x1030dd0e3*/
  }
  return result; /*0x1030dd0ce*/
}

// Address: 0x1030dd0ea | Name: _Curl_cpool_do_all
void __fastcall Curl_cpool_do_all(_QWORD *a1, unsigned int (__fastcall *a2)(__int64, __int64, __int64), __int64 a3)
{
  __int64 v6; // r12
  __int64 v7; // r12
  __int64 v8; // r12
  __int64 v9; // rax
  __int64 v10; // rax

  if ( a1 != nullptr ) /*0x1030dd0f8*/
  {
    v6 = a1[15]; /*0x1030dd107*/
    if ( v6 != 0 && (*(_BYTE *)(v6 + 4) & 0x20) != 0 ) /*0x1030dd116*/
    {
      v8 = v6 + 48; /*0x1030dd133*/
    }
    else
    {
      v7 = a1[14]; /*0x1030dd118*/
      if ( v7 == 0 ) /*0x1030dd11f*/
      {
        v7 = a1[13]; /*0x1030dd121*/
        if ( v7 == 0 ) /*0x1030dd128*/
          return; /*0x1030dd128*/
      }
      v8 = v7 + 544; /*0x1030dd12a*/
    }
    v9 = *(_QWORD *)(v8 + 96); /*0x1030dd137*/
    if ( v9 != 0 && (*(_BYTE *)(v9 + 4) & 0x20) != 0 ) /*0x1030dd145*/
      Curl_share_lock(a1, a2: 5, a3: 2); /*0x1030dd154*/
    *(_BYTE *)(v8 + 104) |= 1u; /*0x1030dd159*/
    cpool_foreach((__int64)a1, a2: v8, a3, a4: a2); /*0x1030dd16b*/
    *(_BYTE *)(v8 + 104) &= ~1u; /*0x1030dd170*/
    v10 = *(_QWORD *)(v8 + 96); /*0x1030dd176*/
    if ( v10 != 0 && (*(_BYTE *)(v10 + 4) & 0x20) != 0 ) /*0x1030dd184*/
      Curl_share_unlock(a1, a2: 5); /*0x1030dd19f*/
  }
}

// Address: 0x1030dd1a4 | Name: _Curl_timeleft_now_ms
__int64 __fastcall Curl_timeleft_now_ms(__int64 a1, __int64 a2)
{
  __int64 v4; // rsi
  __int64 result; // rax
  __int64 v6; // r12
  __int64 v7; // r12
  __int64 v8; // r15
  __int64 v9; // r12
  __int64 v10; // r12

  v4 = *(_QWORD *)(a1 + 32); /*0x1030dd1b5*/
  if ( v4 != 0 && (*(__int64 *)(v4 + 464) > 0 || *(int *)(v4 + 472) > 0) ) /*0x1030dd1cf*/
    return Curl_shutdown_timeleft(a1, a2: v4, a3: 0); /*0x1030dd1de*/
  if ( (unsigned __int8)Curl_is_connecting(a1) == 0 ) /*0x1030dd1ed*/
  {
    v9 = *(_QWORD *)(a1 + 1696); /*0x1030dd231*/
    if ( v9 == 0 ) /*0x1030dd23b*/
      return 0; /*0x1030dd281*/
    v8 = 0; /*0x1030dd23d*/
    result = 0; /*0x1030dd247*/
    if ( (*(_BYTE *)(a1 + 1843) & 1) != 0 ) /*0x1030dd24c*/
      return result; /*0x1030dd24c*/
    goto LABEL_14; /*0x1030dd24c*/
  }
  v6 = 300000; /*0x1030dd1f9*/
  if ( *(__int64 *)(a1 + 1704) > 0 ) /*0x1030dd1ff*/
    v6 = *(_QWORD *)(a1 + 1704); /*0x1030dd1ff*/
  v7 = v6 - curlx_ptimediff_ms(a1: a2, a2: a1 + 2168); /*0x1030dd212*/
  v8 = -1; /*0x1030dd215*/
  if ( v7 != 0 ) /*0x1030dd21c*/
    v8 = v7; /*0x1030dd21c*/
  v9 = *(_QWORD *)(a1 + 1696); /*0x1030dd220*/
  result = v8; /*0x1030dd227*/
  if ( v9 != 0 ) /*0x1030dd22d*/
  {
LABEL_14:
    v10 = v9 - curlx_ptimediff_ms(a1: a2, a2: a1 + 2184); /*0x1030dd24e*/
    result = -1; /*0x1030dd263*/
    if ( v10 != 0 ) /*0x1030dd26a*/
      result = v10; /*0x1030dd26a*/
    if ( v8 != 0 && v8 < result ) /*0x1030dd27b*/
      return v8; /*0x1030dd27b*/
  }
  return result; /*0x1030dd1d6*/
}

// Address: 0x1030dd291 | Name: _Curl_shutdown_started
bool __fastcall Curl_shutdown_started(__int64 a1, int a2)
{
  __int64 v2; // rcx
  __int64 v3; // rdx
  bool result; // al

  v2 = *(_QWORD *)(a1 + 32); /*0x1030dd291*/
  if ( v2 == 0 ) /*0x1030dd298*/
    return false; /*0x1030dd2c5*/
  v3 = 16LL * a2; /*0x1030dd2a1*/
  result = true; /*0x1030dd2a5*/
  if ( *(__int64 *)(v2 + v3 + 464) <= 0 ) /*0x1030dd2b0*/
    return *(_DWORD *)(v2 + v3 + 472) > 0; /*0x1030dd2c0*/
  return result; /*0x1030dd2c4*/
}

// Address: 0x1030dd2c8 | Name: _Curl_shutdown_timeleft
__int64 __fastcall Curl_shutdown_timeleft(__int64 a1, __int64 a2, int a3)
{
  __int64 v3; // rax
  __int64 v4; // r14
  __int64 v5; // rbx
  __int64 v6; // rax
  __int64 v7; // r14
  __int64 result; // rax

  v3 = 16LL * a3; /*0x1030dd2cb*/
  if ( *(_QWORD *)(a2 + v3 + 464) == 0 ) /*0x1030dd2d8*/
    return 0; /*0x1030dd318*/
  v4 = *(_QWORD *)(a2 + 496); /*0x1030dd2e1*/
  if ( v4 <= 0 ) /*0x1030dd2eb*/
    return 0; /*0x1030dd31b*/
  v5 = a2 + v3 + 464; /*0x1030dd2f1*/
  v6 = Curl_pgrs_now(a1); /*0x1030dd2f8*/
  v7 = v4 - curlx_ptimediff_ms(a1: v6, a2: v5); /*0x1030dd308*/
  result = -1; /*0x1030dd30b*/
  if ( v7 != 0 ) /*0x1030dd312*/
    return v7; /*0x1030dd312*/
  return result; /*0x1030dd31a*/
}

// Address: 0x1030dd322 | Name: _Curl_timeleft_ms
__int64 __fastcall Curl_timeleft_ms(__int64 a1)
{
  __int64 v2; // rax

  v2 = Curl_pgrs_now(a1); /*0x1030dd32b*/
  return Curl_timeleft_now_ms(a1, a2: v2); /*0x1030dd33a*/
}

// Address: 0x1030dd341 | Name: _Curl_shutdown_start
_OWORD *__fastcall Curl_shutdown_start(__int64 a1, int a2, int a3)
{
  __int64 v5; // r15
  __int64 v6; // r12
  _OWORD *result; // rax
  __int64 v8; // rsi

  v5 = *(_QWORD *)(a1 + 32); /*0x1030dd352*/
  v6 = 16LL * a2; /*0x1030dd359*/
  result = (_OWORD *)Curl_pgrs_now(a1); /*0x1030dd35d*/
  *(_OWORD *)(v5 + v6 + 464) = *result; /*0x1030dd365*/
  if ( a3 <= 0 ) /*0x1030dd371*/
  {
    result = *(_OWORD **)(a1 + 1728); /*0x1030dd378*/
    v8 = 2000; /*0x1030dd382*/
    if ( (__int64)result > 0 ) /*0x1030dd387*/
      v8 = *(_QWORD *)(a1 + 1728); /*0x1030dd387*/
  }
  else
  {
    v8 = (unsigned int)a3; /*0x1030dd373*/
  }
  *(_QWORD *)(v5 + 496) = v8; /*0x1030dd38b*/
  if ( *(_DWORD *)(a1 + 16) != 0 ) /*0x1030dd396*/
    return (_OWORD *)Curl_expire_ex(a1, a2: v8, a3: 14); /*0x1030dd3a8*/
  return result; /*0x1030dd3a0*/
}

// Address: 0x1030dd3b6 | Name: _Curl_conn_shutdown_timeleft
__int64 __fastcall Curl_conn_shutdown_timeleft(__int64 a1, __int64 a2)
{
  __int64 v4; // r12
  char v5; // r13
  __int64 v6; // rdx
  __int64 v7; // r15
  __int64 v8; // rax
  __int64 v9; // rcx
  bool v10; // zf

  if ( *(_QWORD *)(a2 + 496) == 0 ) /*0x1030dd3cc*/
    return 0; /*0x1030dd432*/
  v4 = a2 + 464; /*0x1030dd3d4*/
  v5 = 1; /*0x1030dd3db*/
  v6 = 0; /*0x1030dd3de*/
  v7 = 0; /*0x1030dd3e0*/
  do /*0x1030dd42e*/
  {
    if ( *(_QWORD *)(v4 + 16 * v6) != 0 ) /*0x1030dd3ef*/
    {
      v8 = Curl_shutdown_timeleft(a1, a2, a3: v6); /*0x1030dd3f7*/
      if ( v8 != 0 ) /*0x1030dd3ff*/
      {
        v9 = v7; /*0x1030dd404*/
        if ( v8 < v7 ) /*0x1030dd407*/
          v9 = v8; /*0x1030dd407*/
        if ( v7 == 0 ) /*0x1030dd40e*/
          v9 = v8; /*0x1030dd40e*/
        v7 = v9; /*0x1030dd412*/
      }
    }
    v6 = 1; /*0x1030dd420*/
    v10 = ((unsigned __int8)v5 & (*(_QWORD *)(a2 + 496) != 0)) == 0; /*0x1030dd425*/
    v5 = 0; /*0x1030dd428*/
  }
  while ( !v10 ); /*0x1030dd42e*/
  return v7; /*0x1030dd43c*/
}

// Address: 0x1030dd447 | Name: _Curl_shutdown_clear
__int64 __fastcall Curl_shutdown_clear(__int64 a1, int a2)
{
  __int64 result; // rax

  result = *(_QWORD *)(a1 + 32); /*0x1030dd44b*/
  *(_OWORD *)(result + 16LL * a2 + 464) = 0; /*0x1030dd459*/
  return result; /*0x1030dd461*/
}

// Address: 0x1030dd463 | Name: _Curl_addr2string
char __fastcall Curl_addr2string(__int64 a1, unsigned int a2, char *a3, _WORD *a4)
{
  int v7; // eax
  const void *v8; // rsi
  int v9; // edi

  v7 = *(unsigned __int8 *)(a1 + 1); /*0x1030dd476*/
  switch ( v7 ) /*0x1030dd47d*/
  {
    case 1: /*0x1030dd47d*/
      if ( a2 < 2 ) /*0x1030dd4d8*/
        *a3 = 0; /*0x1030dd4f9*/
      else
        curl_msnprintf(buffer: a3, maxlength: 0x2Eu, format: "%s", (const char *)(a1 + 2)); /*0x1030dd4f2*/
      *a4 = 0; /*0x1030dd4fd*/
      return 1; /*0x1030dd4fd*/
    case 30: /*0x1030dd47d*/
      v8 = (const void *)(a1 + 8); /*0x1030dd494*/
      v9 = 30; /*0x1030dd498*/
      break;
    case 2: /*0x1030dd47d*/
      v8 = (const void *)(a1 + 4); /*0x1030dd489*/
      v9 = 2; /*0x1030dd48d*/
      break;
    default:
LABEL_8:
      *a3 = 0; /*0x1030dd4bd*/
      *a4 = 0; /*0x1030dd4c1*/
      *__error() = 47; /*0x1030dd4cb*/
      return 0; /*0x1030dd4d3*/
  }
  if ( inet_ntop(a1: v9, a2: v8, a3, a4: 0x2Eu) == nullptr ) /*0x1030dd4ad*/
    goto LABEL_8; /*0x1030dd4ad*/
  *a4 = __ROL2__(*(_WORD *)(a1 + 2), 8); /*0x1030dd4b8*/
  return 1; /*0x1030dd508*/
}

// Address: 0x1030dd50f | Name: _Curl_getconnectinfo
__int64 __fastcall Curl_getconnectinfo(_QWORD *a1, __int64 *a2)
{
  __int64 v3; // rsi
  unsigned int v4; // ebx
  __int64 conn; // rax

  v3 = a1[300]; /*0x1030dd51c*/
  v4 = -1; /*0x1030dd523*/
  if ( v3 != -1 ) /*0x1030dd52c*/
  {
    conn = Curl_cpool_get_conn(a1, a2: v3); /*0x1030dd531*/
    if ( conn != 0 ) /*0x1030dd539*/
    {
      if ( a2 != nullptr ) /*0x1030dd53e*/
        *a2 = conn; /*0x1030dd540*/
      return *(unsigned int *)(conn + 400); /*0x1030dd543*/
    }
    else
    {
      a1[300] = -1; /*0x1030dd54b*/
    }
  }
  return v4; /*0x1030dd55c*/
}

// Address: 0x1030dd563 | Name: _Curl_conncontrol
__int64 __fastcall Curl_conncontrol(__int64 a1, int a2)
{
  __int64 result; // rax
  unsigned __int8 v5; // cl

  result = Curl_conn_is_multiplex(a1, a2: 0); /*0x1030dd572*/
  if ( ((unsigned __int8)result & (a2 == 2)) == 0 ) /*0x1030dd587*/
  {
    v5 = (result ^ 1) & (a2 == 2) | (a2 == 1); /*0x1030dd58d*/
    result = *(unsigned int *)(a1 + 728); /*0x1030dd58f*/
    if ( v5 == ((result & 0x20) == 0) ) /*0x1030dd59a*/
    {
      result = (32 * v5) | (unsigned int)result & 0xFFFFFFDF; /*0x1030dd5a7*/
      *(_DWORD *)(a1 + 728) = result; /*0x1030dd5a9*/
    }
  }
  return result; /*0x1030dd5af*/
}

// Address: 0x1030dd5b4 | Name: _cf_setup_destroy
void __fastcall cf_setup_destroy(__int64 a1)
{
  Curl_cfree(a1: *(void **)(a1 + 16)); /*0x1030dd5c4*/
}

// Address: 0x1030dd5c6 | Name: _cf_setup_connect
__int64 __fastcall cf_setup_connect(__int64 a1, __int64 a2, _BYTE *a3)
{
  __int64 v6; // r12
  __int64 v7; // rdi
  __int64 result; // rax
  unsigned int v9; // eax
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rdi
  __int64 v13; // rax
  __int64 v14; // rax
  int v15; // eax
  __int64 v16; // rdi
  __int64 v17; // rax

  if ( (*(_BYTE *)(a1 + 36) & 1) != 0 ) /*0x1030dd5d8*/
  {
LABEL_45:
    *a3 = 1; /*0x1030dd81d*/
    return 0; /*0x1030dd820*/
  }
  else
  {
    if ( *(_QWORD *)(a2 + 8LL * *(int *)(a1 + 32) + 2536) != 0 ) /*0x1030dd5f1*/
    {
      v6 = *(_QWORD *)(a1 + 16); /*0x1030dd5f7*/
      v7 = *(_QWORD *)(a1 + 8); /*0x1030dd5fb*/
      while ( 1 ) /*0x1030dd5ff*/
      {
        if ( v7 != 0 && (*(_BYTE *)(v7 + 36) & 1) == 0 ) /*0x1030dd608*/
        {
          result = Curl_conn_cf_connect(a1: v7); /*0x1030dd610*/
          if ( (_DWORD)result != 0 ) /*0x1030dd617*/
            return result; /*0x1030dd617*/
          if ( *a3 != 1 ) /*0x1030dd620*/
            return 0; /*0x1030dd620*/
        }
        v9 = *(_DWORD *)v6; /*0x1030dd626*/
        if ( *(_DWORD *)v6 == 1 ) /*0x1030dd62d*/
          goto LABEL_13; /*0x1030dd62d*/
        if ( v9 != 0 ) /*0x1030dd631*/
        {
          if ( v9 <= 2 ) /*0x1030dd6bb*/
            goto LABEL_19; /*0x1030dd6bb*/
          if ( v9 != 3 ) /*0x1030dd746*/
          {
            if ( v9 > 4 ) /*0x1030dd7a6*/
              goto LABEL_44; /*0x1030dd7a6*/
            goto LABEL_36; /*0x1030dd7a6*/
          }
LABEL_29:
          if ( (*(_BYTE *)(a2 + 1847) & 0x10) != 0 ) /*0x1030dd750*/
          {
            if ( Curl_conn_is_ssl(a1: *(_QWORD *)(a1 + 24), a2: *(_DWORD *)(a1 + 32)) ) /*0x1030dd75a*/
            {
              Curl_failf(a1: a2, a2: "haproxy protocol not support with SSL encryption in place (QUIC?)"); /*0x1030dd83e*/
              return 1; /*0x1030dd843*/
            }
            result = Curl_cf_haproxy_insert_after(a1); /*0x1030dd76d*/
            if ( (_DWORD)result != 0 ) /*0x1030dd774*/
              return result; /*0x1030dd774*/
          }
          *(_DWORD *)v6 = 4; /*0x1030dd77a*/
          v14 = *(_QWORD *)(a1 + 8); /*0x1030dd782*/
          v7 = 0; /*0x1030dd786*/
          if ( v14 != 0 ) /*0x1030dd78e*/
          {
            v7 = *(_QWORD *)(a1 + 8); /*0x1030dd798*/
            if ( (*(_BYTE *)(v14 + 36) & 1) != 0 ) /*0x1030dd79b*/
            {
LABEL_36:
              v15 = *(_DWORD *)(v6 + 4); /*0x1030dd7a8*/
              if ( v15 != 0 ) /*0x1030dd7af*/
              {
                if ( v15 == 1 ) /*0x1030dd7b4*/
                {
                  v16 = *(_QWORD *)(a1 + 24); /*0x1030dd7b6*/
LABEL_40:
                  if ( !Curl_conn_is_ssl(a1: v16, a2: *(_DWORD *)(a1 + 32)) ) /*0x1030dd7d1*/
                  {
                    result = Curl_cf_ssl_insert_after(a1, a2); /*0x1030dd7e0*/
                    if ( (_DWORD)result != 0 ) /*0x1030dd7e7*/
                      return result; /*0x1030dd7e7*/
                  }
                  goto LABEL_42; /*0x1030dd7e7*/
                }
                v16 = *(_QWORD *)(a1 + 24); /*0x1030dd7bc*/
                if ( (*(_BYTE *)(*(_QWORD *)(v16 + 736) + 32LL) & 1) != 0 ) /*0x1030dd7cb*/
                  goto LABEL_40; /*0x1030dd7cb*/
              }
LABEL_42:
              *(_DWORD *)v6 = 5; /*0x1030dd7e9*/
              v17 = *(_QWORD *)(a1 + 8); /*0x1030dd7f1*/
              v7 = 0; /*0x1030dd7f5*/
              if ( v17 != 0 ) /*0x1030dd7fd*/
              {
                v7 = *(_QWORD *)(a1 + 8); /*0x1030dd807*/
                if ( (*(_BYTE *)(v17 + 36) & 1) != 0 ) /*0x1030dd80a*/
                {
LABEL_44:
                  *(_DWORD *)v6 = 6; /*0x1030dd810*/
                  *(_BYTE *)(a1 + 36) |= 1u; /*0x1030dd818*/
                  goto LABEL_45; /*0x1030dd818*/
                }
              }
            }
          }
        }
        else
        {
          result = cf_ip_happy_insert_after(a1, a2, a3: *(_BYTE *)(v6 + 8)); /*0x1030dd643*/
          if ( (_DWORD)result != 0 ) /*0x1030dd64a*/
            return result; /*0x1030dd64a*/
          *(_DWORD *)v6 = 1; /*0x1030dd650*/
          v10 = *(_QWORD *)(a1 + 8); /*0x1030dd658*/
          v7 = 0; /*0x1030dd65c*/
          if ( v10 != 0 ) /*0x1030dd664*/
          {
            v7 = *(_QWORD *)(a1 + 8); /*0x1030dd66a*/
            if ( (*(_BYTE *)(v10 + 36) & 1) != 0 ) /*0x1030dd66d*/
            {
LABEL_13:
              if ( (*(_BYTE *)(*(_QWORD *)(a1 + 24) + 728LL) & 2) == 0 ) /*0x1030dd67a*/
                goto LABEL_19; /*0x1030dd67a*/
              result = Curl_cf_socks_proxy_insert_after(a1, a2); /*0x1030dd682*/
              if ( (_DWORD)result != 0 ) /*0x1030dd689*/
                return result; /*0x1030dd689*/
              *(_DWORD *)v6 = 2; /*0x1030dd68f*/
              v11 = *(_QWORD *)(a1 + 8); /*0x1030dd697*/
              v7 = 0; /*0x1030dd69b*/
              if ( v11 != 0 ) /*0x1030dd6a3*/
              {
                v7 = *(_QWORD *)(a1 + 8); /*0x1030dd6ad*/
                if ( (*(_BYTE *)(v11 + 36) & 1) != 0 ) /*0x1030dd6b0*/
                {
LABEL_19:
                  v12 = *(_QWORD *)(a1 + 24); /*0x1030dd6c1*/
                  if ( (*(_BYTE *)(v12 + 728) & 1) == 0 ) /*0x1030dd6cc*/
                    goto LABEL_29; /*0x1030dd6cc*/
                  if ( (*(_BYTE *)(v12 + 306) & 0xFE) == 2 && !Curl_conn_is_ssl(a1: v12, a2: *(_DWORD *)(a1 + 32)) ) /*0x1030dd6de*/
                  {
                    result = Curl_cf_ssl_proxy_insert_after(a1, a2); /*0x1030dd6ed*/
                    if ( (_DWORD)result != 0 ) /*0x1030dd6f4*/
                      return result; /*0x1030dd6f4*/
                  }
                  if ( (*(_BYTE *)(*(_QWORD *)(a1 + 24) + 728LL) & 8) != 0 ) /*0x1030dd705*/
                  {
                    result = Curl_cf_http_proxy_insert_after(a1, a2); /*0x1030dd70d*/
                    if ( (_DWORD)result != 0 ) /*0x1030dd714*/
                      return result; /*0x1030dd714*/
                  }
                  *(_DWORD *)v6 = 3; /*0x1030dd71a*/
                  v13 = *(_QWORD *)(a1 + 8); /*0x1030dd722*/
                  v7 = 0; /*0x1030dd726*/
                  if ( v13 != 0 ) /*0x1030dd72e*/
                  {
                    v7 = *(_QWORD *)(a1 + 8); /*0x1030dd738*/
                    if ( (*(_BYTE *)(v13 + 36) & 1) != 0 ) /*0x1030dd73b*/
                      goto LABEL_29; /*0x1030dd73b*/
                  }
                }
              }
            }
          }
        }
      }
    }
    return 2; /*0x1030dd824*/
  }
}

// Address: 0x1030dd84a | Name: _cf_setup_close
void __fastcall cf_setup_close(__int64 a1, __int64 a2)
{
  _DWORD *v3; // rax
  __int64 v4; // rdi

  v3 = *(_DWORD **)(a1 + 16); /*0x1030dd854*/
  *(_BYTE *)(a1 + 36) &= ~1u; /*0x1030dd858*/
  *v3 = 0; /*0x1030dd85c*/
  v4 = *(_QWORD *)(a1 + 8); /*0x1030dd862*/
  if ( v4 != 0 ) /*0x1030dd869*/
  {
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 32LL))(a1: v4); /*0x1030dd875*/
    Curl_conn_cf_discard_chain(a1: (__int64 **)(a1 + 8), a2); /*0x1030dd882*/
  }
}

// Address: 0x1030dd88c | Name: _Curl_cf_setup_insert_after
__int64 __fastcall Curl_cf_setup_insert_after(__int64 a1, __int64 a2, unsigned int a3, unsigned int a4)
{
  unsigned int v5; // r14d
  __int64 v7[3]; // [rsp+8h] [rbp-18h] BYREF

  v5 = cf_setup_create(a1: v7, a2: a3, a3: a4); /*0x1030dd8a7*/
  if ( v5 == 0 ) /*0x1030dd8ac*/
    Curl_conn_cf_insert_after(a1, a2: v7[0]); /*0x1030dd8b5*/
  return v5; /*0x1030dd8bd*/
}

// Address: 0x1030dd8c6 | Name: _cf_setup_create
__int64 __fastcall cf_setup_create(_QWORD *a1, char a2, int a3)
{
  _DWORD *v6; // rax
  void *v7; // r14
  unsigned int v8; // r15d
  __int64 result; // rax
  __int64 v10; // rcx
  _QWORD v11[5]; // [rsp+8h] [rbp-28h] BYREF

  v11[0] = 0; /*0x1030dd8de*/
  v6 = Curl_ccalloc(__count: 1u, __size: 0xCu); /*0x1030dd8f7*/
  if ( v6 != nullptr ) /*0x1030dd8fc*/
  {
    v7 = v6; /*0x1030dd8fe*/
    *v6 = 0; /*0x1030dd901*/
    v6[1] = a3; /*0x1030dd907*/
    *((_BYTE *)v6 + 8) = a2; /*0x1030dd90b*/
    v8 = Curl_cf_create(a1: v11, a2: (__int64)&Curl_cft_setup, a3: (__int64)v6); /*0x1030dd922*/
    result = 0; /*0x1030dd925*/
    if ( v8 != 0 ) /*0x1030dd92a*/
      v10 = 0; /*0x1030dd940*/
    else
      v10 = v11[0]; /*0x1030dd92c*/
    *a1 = v10; /*0x1030dd945*/
    if ( v8 != 0 ) /*0x1030dd948*/
    {
      Curl_cfree(a1: v7); /*0x1030dd954*/
      return v8; /*0x1030dd956*/
    }
  }
  else
  {
    *a1 = 0; /*0x1030dd932*/
    return 27; /*0x1030dd939*/
  }
  return result; /*0x1030dd959*/
}

// Address: 0x1030dd966 | Name: _Curl_conn_setup
__int64 __fastcall Curl_conn_setup(_BYTE *a1, __int64 a2, int a3, __int64 a4, int a5)
{
  __int64 v8; // rbx
  _QWORD *v9; // r12
  __int64 v10; // rcx
  unsigned int v11; // ebx
  unsigned int v12; // eax
  __int64 v14; // [rsp+8h] [rbp-48h] BYREF
  __int64 v15; // [rsp+10h] [rbp-40h]
  int v16; // [rsp+1Ch] [rbp-34h]
  __int64 v17; // [rsp+20h] [rbp-30h]

  v16 = a5; /*0x1030dd977*/
  v17 = a4; /*0x1030dd97b*/
  v8 = a3; /*0x1030dd988*/
  v9 = &a1[8 * a3 + 2536]; /*0x1030dd98f*/
  Curl_resolv_unlink(a1, a2: v9); /*0x1030dd999*/
  v10 = v8; /*0x1030dd99e*/
  *v9 = v17; /*0x1030dd9a5*/
  v11 = 0; /*0x1030dd9a9*/
  if ( *(_QWORD *)(a2 + 8 * v10 + 408) == 0 ) /*0x1030dd9b4*/
  {
    LODWORD(v17) = a3; /*0x1030dd9b9*/
    if ( *(_QWORD *)(*(_QWORD *)(a2 + 736) + 16LL) != 2 ) /*0x1030dd9d0*/
      goto LABEL_5; /*0x1030dd9d0*/
    v15 = v10; /*0x1030dd9d2*/
    v12 = Curl_cf_https_setup(a1, a2, a3: v17, a4: v10); /*0x1030dd9df*/
    if ( v12 != 0 ) /*0x1030dd9e6*/
    {
LABEL_6:
      v11 = v12; /*0x1030dda0f*/
      Curl_resolv_unlink(a1, a2: v9); /*0x1030dda17*/
      return v11; /*0x1030dda1c*/
    }
    if ( *(_QWORD *)(a2 + 8 * v15 + 408) == 0 ) /*0x1030dd9f5*/
    {
LABEL_5:
      v12 = cf_setup_create(a1: &v14, a2: *(_BYTE *)(a2 + 816), a3: v16); /*0x1030dda06*/
      if ( v12 == 0 ) /*0x1030dda0d*/
      {
        Curl_conn_cf_add((__int64)a1, a2, a3: v17, a4: v14); /*0x1030dda2b*/
        return v11; /*0x1030dda2b*/
      }
      goto LABEL_6; /*0x1030dda0d*/
    }
  }
  return v11; /*0x1030dda32*/
}

// Address: 0x1030dda41 | Name: _Curl_conn_set_multiplex
__int64 __fastcall Curl_conn_set_multiplex(__int64 a1)
{
  __int64 result; // rax

  result = *(unsigned int *)(a1 + 728); /*0x1030dda45*/
  if ( (result & 0x20000) == 0 ) /*0x1030dda4f*/
  {
    result = (unsigned int)result | 0x20000; /*0x1030dda51*/
    *(_DWORD *)(a1 + 728) = result; /*0x1030dda56*/
    if ( *(_QWORD *)(a1 + 768) != 0 ) /*0x1030dda66*/
      return Curl_multi_connchanged(); /*0x1030dda69*/
  }
  return result; /*0x1030dda68*/
}

// Address: 0x1030dda70 | Name: _Curl_get_content_encodings
__int64 Curl_get_content_encodings()
{
  const char **v0; // rbx
  const char ***v1; // r13
  int v2; // eax
  bool v3; // cl
  _BYTE v5[72]; // [rsp+8h] [rbp-48h] BYREF

  curlx_dyn_init(a1: v5, a2: 255); /*0x1030dda8d*/
  v0 = (const char **)identity_encoding; /*0x1030dda92*/
  v1 = (const char ***)off_10C8BD088; /*0x1030dda99*/
  do /*0x1030ddaff*/
  {
    v2 = curl_strequal(s1: *v0, s2: "identity"); /*0x1030ddab4*/
    v3 = true; /*0x1030ddab9*/
    if ( v2 == 0 ) /*0x1030ddabd*/
    {
      if ( curlx_dyn_len(a1: v5) != 0 && (unsigned int)curlx_dyn_addn(a1: v5, a2: ", ", a3: 2) != 0 ) /*0x1030ddade*/
        return 0; /*0x1030ddade*/
      v3 = (unsigned int)curlx_dyn_add(a1: v5, a2: *v0) == 0; /*0x1030ddaed*/
    }
    v0 = *v1; /*0x1030ddaf0*/
    if ( *v1 == nullptr ) /*0x1030ddaf7*/
      break; /*0x1030ddaf7*/
    ++v1; /*0x1030ddaf9*/
  }
  while ( v3 ); /*0x1030ddaff*/
  if ( v3 && (curlx_dyn_len(a1: v5) != 0 || (unsigned int)curlx_dyn_add(a1: v5, a2: "identity") == 0) ) /*0x1030ddb30*/
    return curlx_dyn_ptr(a1: v5); /*0x1030ddb1c*/
  return 0; /*0x1030ddb34*/
}

// Address: 0x1030ddb43 | Name: _Curl_build_unencoding_stack
__int64 __fastcall Curl_build_unencoding_stack(__int64 a1, const char *a2, __int64 a3)
{
  int v3; // r14d
  __int64 v6; // rsi
  __int64 v7; // rdi
  const char *i; // r15
  unsigned __int64 v9; // rax
  __int64 v10; // rcx
  size_t v11; // r12
  __int64 v12; // rcx
  __int64 v13; // rax
  int v14; // eax
  char **v15; // r14
  char ***v16; // rbx
  const char *v17; // rsi
  int v18; // ecx
  unsigned int v19; // r15d
  unsigned int v20; // eax
  unsigned int v21; // eax
  unsigned int v22; // eax
  char *s2; // [rsp+8h] [rbp-68h]
  _BOOL4 v25; // [rsp+10h] [rbp-60h]
  char *v26; // [rsp+18h] [rbp-58h]
  __int64 v27; // [rsp+20h] [rbp-50h] BYREF
  __int64 v28; // [rsp+28h] [rbp-48h]
  unsigned int v29; // [rsp+30h] [rbp-40h]
  int v30; // [rsp+34h] [rbp-3Ch]
  __int64 v31; // [rsp+38h] [rbp-38h]
  int v32; // [rsp+44h] [rbp-2Ch]

  v3 = a3; /*0x1030ddb54*/
  v25 = a3 == 0; /*0x1030ddb64*/
  v29 = 2 * v25 + 1; /*0x1030ddb6c*/
  s2 = Curl_httpchunk_unencoder; /*0x1030ddb79*/
  v26 = *(char **)algn_10C8BD5E8; /*0x1030ddb81*/
  v6 = 0; /*0x1030ddb85*/
  v7 = 0x100100000200LL; /*0x1030ddb87*/
  v30 = a3; /*0x1030ddb91*/
  v31 = a1; /*0x1030ddb94*/
  while ( 1 ) /*0x1030ddb98*/
  {
    for ( i = a2; ; ++i ) /*0x1030ddb98*/
    {
      v9 = *(unsigned __int8 *)i; /*0x1030ddb9b*/
      if ( v9 > 0x2C || !_bittest64(&v7, v9) ) /*0x1030ddba5*/
        break; /*0x1030ddba5*/
    }
    v10 = 1; /*0x1030ddbb0*/
    a2 = i; /*0x1030ddbb5*/
    v11 = 0; /*0x1030ddbb8*/
    while ( (_BYTE)v9 != 0 ) /*0x1030ddbbd*/
    {
      a3 = (unsigned __int8)v9; /*0x1030ddbbf*/
      if ( (unsigned __int8)v9 == 44 ) /*0x1030ddbc5*/
        break; /*0x1030ddbc5*/
      if ( (char)v9 >= 33 ) /*0x1030ddbc9*/
        v11 = v10; /*0x1030ddbc9*/
      LOBYTE(v9) = *++a2; /*0x1030ddbcd*/
      ++v10; /*0x1030ddbd4*/
    }
    if ( v11 == 0 ) /*0x1030ddbdc*/
      goto LABEL_54; /*0x1030ddbdc*/
    v28 = v6; /*0x1030ddbe5*/
    if ( v3 != 0 && v11 == 7 ) /*0x1030ddbef*/
    {
      LOBYTE(v12) = curl_strnequal(s1: i, s2: "chunked", n: 7u) != 0; /*0x1030ddc07*/
      v13 = *(_QWORD *)(a1 + 1843); /*0x1030ddc0a*/
    }
    else
    {
      v13 = *(_QWORD *)(a1 + 1843); /*0x1030ddc13*/
      if ( v3 == 0 ) /*0x1030ddc1d*/
      {
        if ( (v13 & 0x4000000) != 0 ) /*0x1030ddcda*/
        {
          curl_strnequal(s1: i, s2: "identity", n: 8u); /*0x1030dde94*/
          return 0; /*0x1030dde0a*/
        }
        if ( (unsigned __int64)(Curl_cwriter_count(a1, a2: 3, a3, a4: v10) - 4) <= 0xFFFFFFFFFFFFFFFALL ) /*0x1030ddcf5*/
        {
LABEL_56:
          Curl_failf(a1, a2: "Reject response due to more than %u content encodings", 5); /*0x1030dde0c*/
          return 61; /*0x1030dde22*/
        }
        v32 = 0; /*0x1030ddcfb*/
LABEL_34:
        v16 = off_10C8BD088; /*0x1030ddd02*/
        v15 = identity_encoding; /*0x1030ddd09*/
        while ( curl_strnequal(s1: i, s2: *v15, n: v11) == 0 || (*v15)[v11] != 0 ) /*0x1030ddd19*/
        {
          v17 = v15[1]; /*0x1030ddd2c*/
          if ( v17 != nullptr && curl_strnequal(s1: i, s2: v17, n: v11) != 0 && v15[1][v11] == 0 ) /*0x1030ddd4d*/
            break; /*0x1030ddd4d*/
          v15 = *v16++; /*0x1030ddd4f*/
          if ( v15 == nullptr ) /*0x1030ddd59*/
          {
            v15 = &error_writer; /*0x1030ddd5b*/
            a1 = v31; /*0x1030ddd62*/
            v18 = v32; /*0x1030ddd66*/
            goto LABEL_48; /*0x1030ddd69*/
          }
        }
        a1 = v31; /*0x1030ddd6b*/
        goto LABEL_44; /*0x1030ddd6f*/
      }
      v12 = 0; /*0x1030ddc23*/
    }
    if ( (v13 & 0x2000) == 0 && (_BYTE)v12 == 0 ) /*0x1030ddc2d*/
    {
      v14 = curl_strnequal(s1: i, s2: "identity", n: 8u); /*0x1030ddc3e*/
      if ( (*(_BYTE *)(a1 + 1846) & 2) != 0 ) /*0x1030ddc4a*/
        return 0; /*0x1030ddc4a*/
      if ( (v28 & 1) != 0 ) /*0x1030ddc54*/
      {
        Curl_failf(a1, a2: "A Transfer-Encoding (%.*s) was listed after chunked", (unsigned int)v11, i); /*0x1030dde41*/
        return 61; /*0x1030dde41*/
      }
      if ( v14 == 0 ) /*0x1030ddc5c*/
      {
        Curl_failf(a1, a2: "Unsolicited Transfer-Encoding (%.*s) found", (unsigned int)v11, i); /*0x1030dde55*/
        return 61; /*0x1030dde55*/
      }
      v6 = 0; /*0x1030ddc62*/
      goto LABEL_53; /*0x1030ddc64*/
    }
    v32 = v12; /*0x1030ddc69*/
    if ( (unsigned __int64)(Curl_cwriter_count(a1, a2: 1, a3, a4: v12) - 4) < 0xFFFFFFFFFFFFFFFBLL ) /*0x1030ddc81*/
      goto LABEL_56; /*0x1030ddc81*/
    if ( curl_strnequal(s1: i, s2, n: v11) != 0 && s2[v11] == 0 ) /*0x1030ddca2*/
    {
      v15 = &Curl_httpchunk_unencoder; /*0x1030ddd71*/
      goto LABEL_44; /*0x1030ddd71*/
    }
    if ( v26 == nullptr ) /*0x1030ddcaf*/
      goto LABEL_34; /*0x1030ddcaf*/
    if ( curl_strnequal(s1: i, s2: v26, n: v11) == 0 ) /*0x1030ddcc1*/
      goto LABEL_34; /*0x1030ddcc1*/
    v15 = &Curl_httpchunk_unencoder; /*0x1030ddcc8*/
    if ( v26[v11] != 0 ) /*0x1030ddccf*/
      goto LABEL_34; /*0x1030ddccf*/
LABEL_44:
    v19 = 0; /*0x1030ddd78*/
    if ( (_BYTE)v32 != 0 ) /*0x1030ddd7f*/
    {
      LOBYTE(v11) = 1; /*0x1030ddd8c*/
      if ( Curl_cwriter_get_by_type(a1, a2: v15) != 0 ) /*0x1030ddd92*/
        return v19; /*0x1030ddd92*/
      goto LABEL_50; /*0x1030ddd92*/
    }
    v18 = 0; /*0x1030ddd99*/
LABEL_48:
    LODWORD(v11) = v18; /*0x1030ddd9f*/
    if ( (((unsigned __int8)v18 | v25) & 1) == 0 && Curl_cwriter_get_by_name(a1, a2: "chunked") != 0 ) /*0x1030dddba*/
      break; /*0x1030dddba*/
LABEL_50:
    v20 = Curl_cwriter_create(a1: &v27, a2: a1, a3: v15, a4: v29); /*0x1030dddc0*/
    if ( v20 != 0 ) /*0x1030dddd4*/
      return v20; /*0x1030dde27*/
    v21 = Curl_cwriter_add(a1, a2: v27); /*0x1030ddddd*/
    if ( v21 != 0 ) /*0x1030ddde4*/
    {
      v19 = v21; /*0x1030dde29*/
      Curl_cwriter_free(a1, a2: v27); /*0x1030dde33*/
      return v19; /*0x1030dde38*/
    }
    v22 = v11; /*0x1030ddde6*/
    LOBYTE(v22) = v28 | v11; /*0x1030ddde9*/
    v6 = v22; /*0x1030dddec*/
    v3 = v30; /*0x1030dddee*/
LABEL_53:
    v7 = 0x100100000200LL; /*0x1030dddf2*/
LABEL_54:
    if ( *a2 == 0 ) /*0x1030dde01*/
      return 0; /*0x1030dde01*/
  }
  Curl_failf(a1, a2: "Reject response due to 'chunked' not being the last Transfer-Encoding"); /*0x1030dde68*/
  return 61; /*0x1030dde76*/
}

// Address: 0x1030de511 | Name: _Curl_zstd_alloc
void *__fastcall Curl_zstd_alloc(__int64 a1, size_t a2)
{
  return Curl_cmalloc(__size: a2);
}

// Address: 0x1030de522 | Name: _Curl_zstd_free
void __fastcall Curl_zstd_free(__int64 a1, void *a2)
{
  Curl_cfree(a1: a2); /*0x1030de531*/
}

// Address: 0x1030de570 | Name: _Curl_cookie_add
__int64 __fastcall Curl_cookie_add(
        __int64 a1,
        __int64 a2,
        int a3,
        int a4,
        const char *a5,
        const char *a6,
        char *a7,
        unsigned __int8 a8)
{
  unsigned int v8; // ebx
  char *v9; // r14
  int v10; // r12d
  __int64 v12; // r15
  size_t v13; // rax
  __int64 v14; // rcx
  char *v15; // r14
  size_t v16; // rbx
  __int64 v17; // rcx
  __int64 v18; // rax
  int v19; // ecx
  __int64 v20; // rax
  int v21; // ecx
  int v22; // eax
  size_t v23; // r12
  char *v24; // r14
  _BYTE *v25; // rax
  const char *v26; // rcx
  char *v27; // rdi
  char *v28; // r12
  char is_ipnum; // al
  size_t v30; // rax
  int v31; // r14d
  time_t v32; // rdi
  signed __int64 v33; // rax
  bool v34; // zf
  int v35; // eax
  size_t v36; // r14
  __int64 v37; // rax
  time_t v38; // rsi
  __int64 v39; // rdx
  __int64 v40; // rdx
  int v41; // r12d
  size_t v42; // r15
  char v43; // r13
  const char *v44; // rdi
  char *v45; // rdi
  size_t v46; // rsi
  int v47; // eax
  char *v48; // rax
  int v49; // eax
  char v50; // al
  char *v51; // rax
  char *v52; // rdi
  char *v53; // r14
  char *v54; // rdi
  size_t v55; // rsi
  char *v56; // rax
  size_t v57; // rax
  char *v58; // rax
  char v59; // cl
  int v60; // eax
  __int64 v61; // rax
  __int64 v62; // rbx
  __int64 v63; // rax
  __int64 v64; // rax
  char *__s2; // [rsp+8h] [rbp-198h] BYREF
  unsigned __int64 v67; // [rsp+10h] [rbp-190h]
  const char *v68; // [rsp+18h] [rbp-188h] BYREF
  char *v69; // [rsp+20h] [rbp-180h]
  size_t v70; // [rsp+28h] [rbp-178h]
  _QWORD __src[8]; // [rsp+30h] [rbp-170h] BYREF
  char *s2[2]; // [rsp+70h] [rbp-130h]
  __int128 v73; // [rsp+80h] [rbp-120h]
  _QWORD v74[2]; // [rsp+90h] [rbp-110h] BYREF
  int v75; // [rsp+A4h] [rbp-FCh]
  __int64 v76; // [rsp+A8h] [rbp-F8h] BYREF
  void *__s; // [rsp+B0h] [rbp-F0h]
  void *v78; // [rsp+B8h] [rbp-E8h]
  const char *v79; // [rsp+C0h] [rbp-E0h]
  size_t v80; // [rsp+C8h] [rbp-D8h]
  time_t v81; // [rsp+D0h] [rbp-D0h]
  size_t __n; // [rsp+D8h] [rbp-C8h]
  char *v83; // [rsp+E0h] [rbp-C0h]
  char *s1; // [rsp+E8h] [rbp-B8h] BYREF
  size_t n; // [rsp+F0h] [rbp-B0h]
  __int64 v86; // [rsp+F8h] [rbp-A8h]
  __int64 v87; // [rsp+100h] [rbp-A0h]
  char v88; // [rsp+10Bh] [rbp-95h] BYREF
  int v89; // [rsp+10Ch] [rbp-94h]
  char *v90[12]; // [rsp+110h] [rbp-90h] BYREF

  v79 = a6; /*0x1030de584*/
  v88 = 0; /*0x1030de599*/
  v8 = 0; /*0x1030de5a0*/
  if ( *(_BYTE *)(a1 + 376) > 0x31u ) /*0x1030de5a9*/
    return v8; /*0x1030de5a9*/
  v9 = (char *)a5; /*0x1030de5af*/
  v10 = a3; /*0x1030de5b2*/
  v12 = a1; /*0x1030de5b8*/
  v75 = a4; /*0x1030de5bb*/
  *(_OWORD *)v74 = 0; /*0x1030de5c4*/
  v73 = 0; /*0x1030de5cb*/
  *(_OWORD *)s2 = 0; /*0x1030de5d2*/
  memset(__src, 0, sizeof(__src)); /*0x1030de5ee*/
  if ( (_BYTE)a3 == 0 ) /*0x1030de5f8*/
  {
    if ( strncmp(__s1: a5, __s2: "#HttpOnly_", __n: 0xAu) == 0 ) /*0x1030ded49*/
    {
      v9 += 10; /*0x1030ded4b*/
      BYTE4(v74[1]) = 8; /*0x1030ded4f*/
    }
    LOBYTE(v14) = 0; /*0x1030ded56*/
    v8 = 0; /*0x1030ded5c*/
    if ( *v9 == 35 ) /*0x1030ded61*/
      goto LABEL_162; /*0x1030ded61*/
    v87 = a2; /*0x1030ded67*/
    v89 = v10; /*0x1030ded6e*/
    v86 = v12; /*0x1030ded75*/
    v41 = 0; /*0x1030ded7c*/
    while ( 1 ) /*0x1030dedba*/
    {
      v90[0] = v9; /*0x1030ded86*/
      v42 = strcspn(__s: v9, __charset: "\t\r\n"); /*0x1030ded9c*/
      v43 = v9[v42]; /*0x1030ded9f*/
      v44 = v9; /*0x1030dedb7*/
      switch ( v41 ) /*0x1030dedba*/
      {
        case 0: /*0x1030dedba*/
          v45 = v9; /*0x1030dedc0*/
          v46 = v42; /*0x1030dedc3*/
          if ( *v9 == 46 ) /*0x1030dedc6*/
          {
            v45 = v9 + 1; /*0x1030dedc8*/
            v90[0] = v9 + 1; /*0x1030dedcc*/
            v46 = v42 - 1; /*0x1030dedd3*/
          }
          *((_QWORD *)&v73 + 1) = curlx_memdup0(__src: v45, __n: v46); /*0x1030deddc*/
          LODWORD(v14) = 0; /*0x1030dede3*/
          if ( *((_QWORD *)&v73 + 1) != 0 ) /*0x1030dede8*/
            goto LABEL_130; /*0x1030dede8*/
          v8 = 27; /*0x1030df0be*/
          goto LABEL_147; /*0x1030dedee*/
        case 1: /*0x1030dedba*/
          v49 = curl_strnequal(s1: v9, s2: "TRUE", n: v42); /*0x1030dee87*/
          v50 = (v49 != 0) | BYTE4(v74[1]) & 0xFE; /*0x1030dee99*/
          LODWORD(v14) = 1; /*0x1030dee9b*/
          goto LABEL_129; /*0x1030deea0*/
        case 2: /*0x1030dedba*/
          if ( strncmp(__s1: "TRUE", __s2: v9, __n: v42) == 0 || strncmp(__s1: "FALSE", __s2: v9, __n: v42) == 0 ) /*0x1030dee50*/
          {
            *(_QWORD *)&v73 = Curl_cstrdup(__s1: "/"); /*0x1030def1e*/
            if ( (_QWORD)v73 == 0 ) /*0x1030def28*/
              goto LABEL_146; /*0x1030def28*/
            v44 = v90[0]; /*0x1030def2e*/
LABEL_121:
            BYTE4(v74[1]) &= ~2u; /*0x1030def35*/
            if ( curl_strnequal(s1: v44, s2: "TRUE", n: v42) != 0 ) /*0x1030def4d*/
            {
              if ( a8 == 0 && (*(_BYTE *)(v87 + 2032) & 1) == 0 ) /*0x1030def63*/
                goto LABEL_145; /*0x1030def63*/
              v50 = BYTE4(v74[1]) | 2; /*0x1030def6f*/
              LODWORD(v14) = 3; /*0x1030def71*/
LABEL_129:
              BYTE4(v74[1]) = v50; /*0x1030defa8*/
            }
            else
            {
              LODWORD(v14) = 3; /*0x1030def78*/
            }
          }
          else
          {
            v48 = (char *)sanitize_cookie_path(a1: v9, a2: v42); /*0x1030dee5c*/
            *(_QWORD *)&v73 = v48; /*0x1030dee61*/
            LODWORD(v14) = 2; /*0x1030dee68*/
LABEL_117:
            if ( v48 == nullptr ) /*0x1030def03*/
            {
LABEL_146:
              v8 = 27; /*0x1030df0b5*/
              LOBYTE(v14) = 0; /*0x1030df0ba*/
              goto LABEL_147; /*0x1030df0ba*/
            }
          }
          goto LABEL_130; /*0x1030def03*/
        case 3: /*0x1030dedba*/
          goto LABEL_121;
        case 4: /*0x1030dedba*/
          v47 = curlx_str_number(a1: v90, a2: v74, a3: 0x7FFFFFFFFFFFFFFFLL); /*0x1030dee0b*/
          LODWORD(v14) = 4; /*0x1030dee10*/
          if ( v47 != 0 ) /*0x1030dee17*/
            goto LABEL_145; /*0x1030dee17*/
          goto LABEL_130; /*0x1030dee17*/
        case 5: /*0x1030dedba*/
          v51 = (char *)curlx_memdup0(__src: v9, __n: v42); /*0x1030deeab*/
          s2[0] = v51; /*0x1030deeb0*/
          if ( v51 == nullptr ) /*0x1030deeba*/
            goto LABEL_146; /*0x1030deeba*/
          if ( curl_strnequal(s1: "__Secure-", s2: v51, n: 9u) != 0 ) /*0x1030deed6*/
          {
            v50 = BYTE4(v74[1]) | 0x10; /*0x1030deee2*/
LABEL_128:
            LODWORD(v14) = 5; /*0x1030defa3*/
            goto LABEL_129; /*0x1030defa3*/
          }
          if ( curl_strnequal(s1: "__Host-", s2: s2[0], n: 7u) != 0 ) /*0x1030def99*/
          {
            v50 = BYTE4(v74[1]) | 0x20; /*0x1030defa1*/
            goto LABEL_128; /*0x1030defa1*/
          }
          LODWORD(v14) = 5; /*0x1030defc4*/
LABEL_130:
          v9 += v42 + 1; /*0x1030defae*/
          v41 = v14 + 1; /*0x1030defb4*/
          if ( v43 != 9 ) /*0x1030defbc*/
          {
            v8 = 0; /*0x1030defcb*/
            v12 = v86; /*0x1030defd0*/
            LOBYTE(v10) = v89; /*0x1030defd7*/
            a2 = v87; /*0x1030defde*/
            if ( (_DWORD)v14 != 6 ) /*0x1030defe5*/
            {
              if ( (_DWORD)v14 != 5 ) /*0x1030defee*/
              {
LABEL_161:
                LOBYTE(v14) = 0; /*0x1030df160*/
                goto LABEL_162; /*0x1030df160*/
              }
              s2[1] = Curl_cstrdup(__s1: ""); /*0x1030df004*/
              if ( s2[1] == nullptr ) /*0x1030df00e*/
              {
                v8 = 27; /*0x1030df014*/
                goto LABEL_161; /*0x1030df019*/
              }
            }
LABEL_160:
            LOBYTE(v14) = 1; /*0x1030df15c*/
            goto LABEL_162; /*0x1030df15e*/
          }
          break; /*0x1030df15e*/
        case 6: /*0x1030dedba*/
          v48 = (char *)curlx_memdup0(__src: v9, __n: v42); /*0x1030deeef*/
          s2[1] = v48; /*0x1030deef4*/
          LODWORD(v14) = 6; /*0x1030deefb*/
          goto LABEL_117; /*0x1030deefb*/
        default:
          LODWORD(v14) = v41; /*0x1030dee72*/
          goto LABEL_130; /*0x1030dee75*/
      }
    }
  }
  v68 = a5; /*0x1030de5fe*/
  v13 = strlen(__s: a5); /*0x1030de608*/
  v14 = 0; /*0x1030de60d*/
  v8 = 0; /*0x1030de60f*/
  if ( v13 > 0x1388 ) /*0x1030de61a*/
    goto LABEL_162; /*0x1030de61a*/
  v87 = a2; /*0x1030de620*/
  v89 = v10; /*0x1030de627*/
  v86 = v12; /*0x1030de62e*/
  v15 = nullptr; /*0x1030de635*/
  v16 = 0; /*0x1030de646*/
  __s = nullptr; /*0x1030de648*/
  __n = 0; /*0x1030de653*/
  v78 = nullptr; /*0x1030de65e*/
  v80 = 0; /*0x1030de669*/
  v69 = nullptr; /*0x1030de674*/
  v70 = 0; /*0x1030de67f*/
  v81 = 0; /*0x1030de68a*/
  while ( 1 ) /*0x1030de695*/
  {
    if ( (unsigned int)curlx_str_cspn(a1: &v68, a2: &__s2, a3: ";\t\r\n=", a4: v14) != 0 ) /*0x1030de6a9*/
      goto LABEL_6; /*0x1030de6a9*/
    curlx_str_trimblanks(a1: &__s2); /*0x1030de6c4*/
    if ( (unsigned int)curlx_str_single(a1: &v68, a2: 61) != 0 ) /*0x1030de6d8*/
    {
      curlx_str_init(a1: &s1); /*0x1030de6e1*/
      if ( v16 == 0 ) /*0x1030de6e9*/
        goto LABEL_145; /*0x1030de6e9*/
      if ( (unsigned int)curlx_str_casecompare(a1: &__s2, a2: "secure") != 0 ) /*0x1030de700*/
      {
        if ( a8 == 0 && (*(_BYTE *)(v87 + 2032) & 1) != 0 ) /*0x1030de71a*/
          goto LABEL_145; /*0x1030de71a*/
        BYTE4(v74[1]) |= 2u; /*0x1030de720*/
      }
      else if ( (unsigned int)curlx_str_casecompare(a1: &__s2, a2: "httponly") != 0 ) /*0x1030de79d*/
      {
        BYTE4(v74[1]) |= 8u; /*0x1030de7a3*/
      }
      goto LABEL_6; /*0x1030de727*/
    }
    if ( (unsigned int)curlx_str_cspn(a1: &v68, a2: &s1, a3: ";\r\n", a4: v17) == 0 ) /*0x1030de741*/
      curlx_str_trimblanks(a1: &s1); /*0x1030de74a*/
    if ( v16 == 0 ) /*0x1030de752*/
      break; /*0x1030de752*/
    if ( (unsigned int)curlx_str_casecompare(a1: &__s2, a2: "path") != 0 ) /*0x1030de765*/
    {
      v69 = s1; /*0x1030de772*/
      v70 = n; /*0x1030de780*/
    }
    else
    {
      v22 = curlx_str_casecompare(a1: &__s2, a2: "domain"); /*0x1030de8f7*/
      v23 = n; /*0x1030de901*/
      v83 = v15; /*0x1030de913*/
      if ( v22 == 0 || n == 0 ) /*0x1030de90b*/
      {
        if ( (unsigned int)curlx_str_casecompare(a1: &__s2, a2: "max-age") != 0 && n != 0 ) /*0x1030dea3e*/
        {
          v90[0] = s1; /*0x1030dea4b*/
          if ( *s1 == 34 ) /*0x1030dea55*/
            v90[0] = s1 + 1; /*0x1030dea5a*/
          v31 = curlx_str_number(a1: v90, a2: v74, a3: 0x7FFFFFFFFFFFFFFFLL); /*0x1030dea7e*/
          v32 = v81; /*0x1030dea81*/
          if ( v81 == 0 ) /*0x1030dea8b*/
            v32 = time(a1: nullptr); /*0x1030dea94*/
          if ( v31 != 0 ) /*0x1030dea9a*/
          {
            v33 = 0x7FFFFFFFFFFFFFFFLL; /*0x1030deaaa*/
            v34 = v31 == 7; /*0x1030deaad*/
            v15 = v83; /*0x1030deab1*/
            if ( !v34 ) /*0x1030deab8*/
              v33 = 1; /*0x1030deabe*/
          }
          else if ( v74[0] != 0 ) /*0x1030debe6*/
          {
            v33 = v74[0] + v32; /*0x1030debf8*/
            if ( 0x7FFFFFFFFFFFFFFFLL - v32 < v74[0] ) /*0x1030debff*/
              v33 = 0x7FFFFFFFFFFFFFFFLL; /*0x1030debff*/
            v15 = v83; /*0x1030dec03*/
          }
          else
          {
            v33 = 1; /*0x1030dec0c*/
            v15 = v83; /*0x1030dec11*/
          }
          if ( v32 < 0x7FFFFFFFFDF0A7E1LL && v33 != 0 && v33 > v32 + 34560000 ) /*0x1030dec3d*/
          {
            v39 = (unsigned __int128)((__int64)0x8888888888888889LL * (__int128)(v32 + 34560030)) >> 64; /*0x1030dec50*/
            v33 = 60 * (((unsigned __int64)(v39 + v32 + 34560030) >> 63) + ((v39 + v32 + 34560030) >> 5)); /*0x1030dec6b*/
          }
          v81 = v32; /*0x1030dec6f*/
          v74[0] = v33; /*0x1030dec76*/
        }
        else
        {
          v35 = curlx_str_casecompare(a1: &__s2, a2: "expires"); /*0x1030deade*/
          v36 = n; /*0x1030deae8*/
          if ( v35 != 0 && n != 0 && v74[0] == 0 && n < 0x50 ) /*0x1030deb0b*/
          {
            v76 = 0; /*0x1030deb15*/
            __memcpy_chk(a1: v90, a2: s1, a3: n, a4: 81); /*0x1030deb39*/
            *((_BYTE *)v90 + v36) = 0; /*0x1030deb3e*/
            if ( (unsigned int)Curl_getdate_capped(a1: v90, a2: &v76) != 0 ) /*0x1030deb58*/
            {
              v37 = 0; /*0x1030deb5e*/
              v38 = v81; /*0x1030deb60*/
            }
            else
            {
              v37 = v76; /*0x1030dec82*/
              v38 = v81; /*0x1030dec8c*/
              if ( v76 == 0 ) /*0x1030dec93*/
              {
                v76 = 1; /*0x1030dec95*/
                v37 = 1; /*0x1030deca0*/
              }
            }
            v74[0] = v37; /*0x1030deca5*/
            v15 = v83; /*0x1030decaf*/
            if ( v38 == 0 ) /*0x1030decb6*/
            {
              v38 = time(a1: nullptr); /*0x1030decbf*/
              v37 = v74[0]; /*0x1030decc2*/
            }
            if ( v37 != 0 && v38 < 0x7FFFFFFFFDF0A7E1LL && v37 > v38 + 34560000 ) /*0x1030decee*/
            {
              v40 = (unsigned __int128)((__int64)0x8888888888888889LL * (__int128)(v38 + 34560030)) >> 64; /*0x1030ded01*/
              v74[0] = 60 * (((unsigned __int64)(v40 + v38 + 34560030) >> 63) + ((v40 + v38 + 34560030) >> 5)); /*0x1030ded20*/
            }
            v81 = v38; /*0x1030ded27*/
          }
          else
          {
            v15 = v83; /*0x1030deb6c*/
          }
        }
        goto LABEL_6; /*0x1030dec7d*/
      }
      v24 = s1; /*0x1030de920*/
      if ( *s1 == 46 ) /*0x1030de92b*/
      {
        curlx_str_nudge(a1: &s1, a2: 1); /*0x1030de939*/
        v24 = s1; /*0x1030de93e*/
        v23 = n; /*0x1030de945*/
      }
      if ( v23 == 9 && curl_strnequal(s1: v24, s2: "localhost", n: 9u) != 0 /*0x1030de997*/
        || (v25 = memchr(__s: v24, __c: 46, __n: v23), v26 = ":", v25 != nullptr)
        && (v26 = ":", (unsigned __int64)(&v24[v23] - v25) >= 2) )
      {
        v26 = v79; /*0x1030de999*/
      }
      v27 = (char *)v26; /*0x1030de9a0*/
      v28 = (char *)v26; /*0x1030de9a3*/
      if ( v26 == nullptr ) /*0x1030de9a9*/
        v27 = s1; /*0x1030de9ab*/
      is_ipnum = Curl_host_is_ipnum(a1: v27); /*0x1030de9b2*/
      v15 = v83; /*0x1030de9c8*/
      if ( v28 != nullptr ) /*0x1030de9cf*/
      {
        if ( is_ipnum != 0 ) /*0x1030de9d7*/
        {
          v78 = s1; /*0x1030de9dd*/
          v80 = n; /*0x1030de9e7*/
          if ( strncmp(__s1: s1, __s2: v28, __n: n) != 0 ) /*0x1030de9f8*/
            goto LABEL_145; /*0x1030de9f8*/
          v30 = strlen(__s: v28); /*0x1030dea01*/
          v79 = v28; /*0x1030dea06*/
          if ( v80 != v30 ) /*0x1030dea14*/
            goto LABEL_145; /*0x1030dea14*/
          goto LABEL_6; /*0x1030dea14*/
        }
        if ( (unsigned __int8)cookie_tailmatch(s1, n, __s: v28) == 0 ) /*0x1030deba7*/
          goto LABEL_145; /*0x1030deba7*/
        v78 = s1; /*0x1030debb4*/
        v80 = n; /*0x1030debc2*/
LABEL_78:
        BYTE4(v74[1]) |= 1u; /*0x1030debc9*/
        v79 = v28; /*0x1030debd0*/
        goto LABEL_6; /*0x1030debd7*/
      }
      v78 = s1; /*0x1030deb7a*/
      v80 = n; /*0x1030deb81*/
      if ( is_ipnum == 0 ) /*0x1030deb88*/
        goto LABEL_78; /*0x1030deb88*/
      v79 = nullptr; /*0x1030deb8a*/
    }
LABEL_6:
    if ( (unsigned int)curlx_str_single(a1: &v68, a2: 59) != 0 ) /*0x1030de6ba*/
    {
      if ( v16 == 0 ) /*0x1030df021*/
        goto LABEL_145; /*0x1030df021*/
      v52 = v15; /*0x1030df027*/
      v53 = v69; /*0x1030df02a*/
      s2[0] = (char *)curlx_memdup0(__src: v52, __n: v16); /*0x1030df039*/
      v8 = 27; /*0x1030df040*/
      v12 = v86; /*0x1030df048*/
      LOBYTE(v10) = v89; /*0x1030df04f*/
      a2 = v87; /*0x1030df056*/
      if ( s2[0] == nullptr ) /*0x1030df05d*/
        goto LABEL_161; /*0x1030df05d*/
      v54 = (char *)__s; /*0x1030df074*/
      if ( __n == 0 ) /*0x1030df07b*/
        v54 = ""; /*0x1030df07b*/
      s2[1] = (char *)curlx_memdup0(__src: v54, __n: (__n == 0) + __n); /*0x1030df08c*/
      if ( s2[1] == nullptr ) /*0x1030df096*/
        goto LABEL_161; /*0x1030df096*/
      v55 = v70; /*0x1030df09c*/
      if ( v70 != 0 ) /*0x1030df0a6*/
      {
        if ( v53 == nullptr ) /*0x1030df0ab*/
          goto LABEL_154; /*0x1030df0ab*/
      }
      else
      {
        v53 = a7; /*0x1030df0dd*/
        if ( a7 == nullptr ) /*0x1030df0e4*/
          goto LABEL_154; /*0x1030df0e4*/
        v56 = strrchr(__s: a7, __c: 47); /*0x1030df0ee*/
        if ( v56 != nullptr ) /*0x1030df0f6*/
          v57 = v56 - a7 + 1; /*0x1030df0fb*/
        else
          v57 = strlen(__s: a7); /*0x1030df103*/
        v55 = v57; /*0x1030df108*/
      }
      *(_QWORD *)&v73 = sanitize_cookie_path(a1: v53, a2: v55); /*0x1030df113*/
      if ( (_QWORD)v73 == 0 ) /*0x1030df11d*/
        goto LABEL_161; /*0x1030df11d*/
LABEL_154:
      if ( v80 != 0 ) /*0x1030df129*/
      {
        v58 = (char *)curlx_memdup0(__src: v78, __n: v80); /*0x1030df132*/
      }
      else
      {
        if ( v79 == nullptr ) /*0x1030df143*/
        {
LABEL_159:
          v8 = 0; /*0x1030df15a*/
          goto LABEL_160; /*0x1030df15a*/
        }
        v58 = Curl_cstrdup(__s1: v79); /*0x1030df14c*/
      }
      *((_QWORD *)&v73 + 1) = v58; /*0x1030df14e*/
      if ( v58 == nullptr ) /*0x1030df158*/
        goto LABEL_161; /*0x1030df158*/
      goto LABEL_159; /*0x1030df158*/
    }
  }
  v15 = __s2; /*0x1030de7af*/
  v16 = v67; /*0x1030de7b6*/
  if ( v67 == 0 ) /*0x1030de7c0*/
  {
LABEL_28:
    __s = s1; /*0x1030de7ec*/
    __n = n; /*0x1030de801*/
    if ( n != 0 ) /*0x1030de80b*/
    {
      v20 = 0; /*0x1030de80d*/
      do /*0x1030de816*/
      {
        v21 = *((unsigned __int8 *)__s + v20); /*0x1030de816*/
        if ( v21 != 9 ) /*0x1030de81d*/
        {
          if ( *((_BYTE *)__s + v20) == 0 ) /*0x1030de821*/
            break; /*0x1030de821*/
          if ( (unsigned __int8)v21 < 0x20u || (_BYTE)v21 == 127 ) /*0x1030de82f*/
            goto LABEL_145; /*0x1030de82f*/
        }
      }
      while ( __n != ++v20 ); /*0x1030de816*/
    }
    if ( v67 == 0 || v67 > 0xFFE || __n > 0xFFE || v67 + __n > 0x1000 || __n != 0 && memchr(__s, __c: 9, __n) != nullptr ) /*0x1030de8a3*/
      goto LABEL_145; /*0x1030de8a3*/
    if ( strncmp(__s1: "__Secure-", __s2: v15, __n: 9u) == 0 ) /*0x1030de8bf*/
    {
      BYTE4(v74[1]) |= 0x10u; /*0x1030deac8*/
    }
    else if ( strncmp(__s1: "__Host-", __s2: v15, __n: 7u) == 0 ) /*0x1030de8db*/
    {
      BYTE4(v74[1]) |= 0x20u; /*0x1030de8e1*/
    }
    goto LABEL_6; /*0x1030de8e8*/
  }
  v18 = 0; /*0x1030de7c2*/
  while ( 1 ) /*0x1030de7c4*/
  {
    v19 = (unsigned __int8)__s2[v18]; /*0x1030de7c4*/
    if ( v19 != 9 ) /*0x1030de7cc*/
    {
      if ( __s2[v18] == 0 ) /*0x1030de7d0*/
        goto LABEL_28; /*0x1030de7d0*/
      if ( (unsigned __int8)v19 < 0x20u || (_BYTE)v19 == 127 ) /*0x1030de7de*/
        break; /*0x1030de7de*/
    }
    if ( v67 == ++v18 ) /*0x1030de7ea*/
      goto LABEL_28; /*0x1030de7ea*/
  }
LABEL_145:
  LOBYTE(v14) = 0; /*0x1030df0af*/
  v8 = 0; /*0x1030df0b1*/
LABEL_147:
  v12 = v86; /*0x1030df0c3*/
  LOBYTE(v10) = v89; /*0x1030df0ca*/
  a2 = v87; /*0x1030df0d1*/
LABEL_162:
  if ( ((v8 != 0) | (unsigned __int8)v14 ^ 1) != 0 ) /*0x1030df16c*/
    goto LABEL_184; /*0x1030df16c*/
  v8 = 0; /*0x1030df17d*/
  if ( (BYTE4(v74[1]) & 0x12) == 0x10 /*0x1030df293*/
    || (v74[1] & 0x2000000000LL) != 0
    && ((v74[1] & 0x200000000LL) == 0
     || (_QWORD)v73 == 0
     || *(_BYTE *)v73 != 47
     || (*(_BYTE *)(v73 + 1) | BYTE4(v74[1]) & 1) != 0) )
  {
    goto LABEL_184; /*0x1030df293*/
  }
  v59 = *(_BYTE *)(a2 + 2032); /*0x1030df190*/
  if ( (v59 & 3) == 2 && v74[0] == 0 ) /*0x1030df1a9*/
    goto LABEL_184; /*0x1030df1a9*/
  BYTE4(v74[1]) = (4 * v59) & 4 | BYTE4(v74[1]) & 0xFB; /*0x1030df1b9*/
  v60 = *(_DWORD *)(a2 + 2028) + 1; /*0x1030df1c6*/
  *(_DWORD *)(a2 + 2028) = v60; /*0x1030df1c8*/
  LODWORD(v74[1]) = v60; /*0x1030df1cf*/
  if ( (_BYTE)v75 == 0 ) /*0x1030df1dc*/
    remove_expired(a1: a2); /*0x1030df1e1*/
  if ( (unsigned __int8)replace_existing(a1: __src, a2, a3: a8, a4: &v88) == 0 ) /*0x1030df202*/
  {
LABEL_184:
    Curl_cfree(a1: *((void **)&v73 + 1)); /*0x1030df29f*/
    Curl_cfree(a1: (void *)v73); /*0x1030df2b7*/
    Curl_cfree(a1: s2[0]); /*0x1030df2c1*/
    Curl_cfree(a1: s2[1]); /*0x1030df2cb*/
    return v8; /*0x1030df2cb*/
  }
  v61 = curlx_memdup(__src, __n: 0x70u); /*0x1030df214*/
  if ( v61 == 0 ) /*0x1030df21c*/
  {
    v8 = 27; /*0x1030df29a*/
    goto LABEL_184; /*0x1030df29a*/
  }
  v62 = v61; /*0x1030df21e*/
  v63 = cookiehash(__s: *(char **)(v61 + 88)); /*0x1030df225*/
  Curl_llist_append(a1: 32 * v63 + a2, a2: v62, a3: v62); /*0x1030df238*/
  if ( v88 == 0 ) /*0x1030df244*/
    ++*(_DWORD *)(a2 + 2024); /*0x1030df246*/
  v64 = *(_QWORD *)(v62 + 96); /*0x1030df24d*/
  if ( v64 != 0 && v64 < *(_QWORD *)(a2 + 2016) ) /*0x1030df25d*/
    *(_QWORD *)(a2 + 2016) = v64; /*0x1030df25f*/
  v8 = 0; /*0x1030df266*/
  if ( (_BYTE)v10 != 0 ) /*0x1030df26b*/
    ++*(_BYTE *)(v12 + 376); /*0x1030df26d*/
  return v8; /*0x1030df2e0*/
}

// Address: 0x1030df68b | Name: _cookiehash
unsigned __int64 __fastcall cookiehash(char *__s)
{
  const char *v1; // rbx
  signed __int64 v3; // r14
  __int64 v4; // rax
  __int64 v5; // rax
  const char *v6; // rax
  const char *v7; // r14
  unsigned __int64 v8; // r15
  __int64 v9; // rdi

  if ( __s == nullptr ) /*0x1030df68e*/
    return 0; /*0x1030df6ad*/
  v1 = __s; /*0x1030df69a*/
  if ( (unsigned __int8)Curl_host_is_ipnum(a1: __s) != 0 ) /*0x1030df6a4*/
    return 0; /*0x1030df6a6*/
  v3 = strlen(__s: v1); /*0x1030df6b8*/
  v4 = Curl_memrchr(a1: v1, a2: 46, a3: v3); /*0x1030df6c6*/
  if ( v4 != 0 && (v5 = Curl_memrchr(a1: v1, a2: 46, a3: v4 - (_QWORD)v1)) != 0 ) /*0x1030df6e6*/
  {
    v6 = (const char *)(v5 + 1); /*0x1030df6e8*/
    v3 = &v1[v3] - v6; /*0x1030df6ee*/
  }
  else
  {
    v6 = nullptr; /*0x1030df6f3*/
  }
  if ( v6 != nullptr ) /*0x1030df6f8*/
    v1 = v6; /*0x1030df6f8*/
  if ( v3 <= 0 ) /*0x1030df6ff*/
    return 26; /*0x1030df75a*/
  v7 = &v1[v3]; /*0x1030df701*/
  v8 = 5381; /*0x1030df704*/
  do /*0x1030df729*/
  {
    v9 = (unsigned int)*v1++; /*0x1030df70a*/
    v8 = (char)Curl_raw_toupper(a1: v9) ^ (33 * v8); /*0x1030df723*/
  }
  while ( v1 < v7 ); /*0x1030df729*/
  return v8 % 0x3F; /*0x1030df6af*/
}

// Address: 0x1030df76a | Name: _Curl_cookie_init
_QWORD *Curl_cookie_init()
{
  _QWORD *v0; // rbx
  __int64 i; // r14

  v0 = Curl_ccalloc(__count: 1u, __size: 0x7F8u); /*0x1030df784*/
  if ( v0 != nullptr ) /*0x1030df78a*/
  {
    for ( i = 0; i != 252; i += 4 ) /*0x1030df78c*/
      Curl_llist_init(a1: &v0[i], a2: 0); /*0x1030df795*/
    v0[252] = 0x7FFFFFFFFFFFFFFFLL; /*0x1030df7b1*/
  }
  return v0; /*0x1030df7bb*/
}

// Address: 0x1030df7c0 | Name: _Curl_cookie_loadfiles
__int64 __fastcall Curl_cookie_loadfiles(__int64 a1)
{
  const char **v1; // r14
  _QWORD *v3; // rax
  const char *v4; // rdi
  __int64 v5; // r13
  unsigned int v6; // r15d
  FILE *v7; // rax
  FILE *v8; // r12
  unsigned int line; // eax
  int v10; // r15d
  _BYTE v12[32]; // [rsp+8h] [rbp-68h] BYREF
  const char **v13; // [rsp+28h] [rbp-48h]
  FILE *v14; // [rsp+30h] [rbp-40h]
  const char *v15; // [rsp+38h] [rbp-38h] BYREF
  char v16[41]; // [rsp+47h] [rbp-29h] BYREF

  v1 = *(const char ***)(a1 + 3976); /*0x1030df7d1*/
  if ( v1 != nullptr ) /*0x1030df7db*/
  {
    Curl_share_lock(a1, a2: 2, a3: 2); /*0x1030df7ee*/
    if ( *(_QWORD *)(a1 + 1856) != 0 || (v3 = Curl_cookie_init(), *(_QWORD *)(a1 + 1856) = v3, v3 != nullptr) ) /*0x1030df80c*/
    {
      *(_BYTE *)(a1 + 4093) |= 0x20u; /*0x1030df812*/
      while ( 1 ) /*0x1030df819*/
      {
        v4 = *v1; /*0x1030df819*/
        v5 = *(_QWORD *)(a1 + 1856); /*0x1030df81c*/
        *(_BYTE *)(v5 + 2032) = (*(_BYTE *)(a1 + 1843) >> 3) & 2 | *(_BYTE *)(v5 + 2032) & 0xFC; /*0x1030df83a*/
        v6 = 0; /*0x1030df841*/
        if ( v4 != nullptr ) /*0x1030df84a*/
        {
          v6 = *(unsigned __int8 *)v4; /*0x1030df850*/
          if ( *v4 != 0 ) /*0x1030df857*/
          {
            if ( v6 == 45 && v4[1] == 0 ) /*0x1030df867*/
            {
              v8 = __stdinp; /*0x1030df939*/
              v7 = nullptr; /*0x1030df93c*/
            }
            else
            {
              v7 = fopen(__filename: v4, __mode: "rb"); /*0x1030df874*/
              v8 = v7; /*0x1030df879*/
            }
            v6 = 0; /*0x1030df87c*/
            if ( v8 != nullptr ) /*0x1030df885*/
            {
              v14 = v7; /*0x1030df88b*/
              v13 = v1; /*0x1030df88f*/
              v16[0] = 0; /*0x1030df896*/
              curlx_dyn_init(a1: v12, a2: 5000); /*0x1030df8a6*/
              while ( 1 ) /*0x1030df8b5*/
              {
                line = Curl_get_line(a1: v12, a2: v8, a3: v16); /*0x1030df8b5*/
                if ( line != 0 ) /*0x1030df8bc*/
                  break; /*0x1030df8bc*/
                v15 = (const char *)curlx_dyn_ptr(a1: v12); /*0x1030df8c6*/
                v10 = curl_strnequal(s1: v15, s2: "Set-Cookie:", n: 0xBu); /*0x1030df8de*/
                if ( v10 != 0 ) /*0x1030df8e3*/
                {
                  v15 += 11; /*0x1030df8e5*/
                  curlx_str_passblanks(a1: &v15); /*0x1030df8ee*/
                }
                v6 = Curl_cookie_add(a1, a2: v5, a3: v10 != 0, a4: 1, a5: v15, a6: nullptr, a7: nullptr, a8: 1u); /*0x1030df91a*/
                if ( v6 != 0 || (v16[0] & 1) != 0 ) /*0x1030df929*/
                  goto LABEL_20; /*0x1030df929*/
              }
              v6 = line; /*0x1030df92d*/
LABEL_20:
              curlx_dyn_free(a1: v12); /*0x1030df947*/
              remove_expired(a1: v5); /*0x1030df952*/
              if ( v14 != nullptr ) /*0x1030df95e*/
                fclose(a1: v14); /*0x1030df960*/
              v1 = v13; /*0x1030df968*/
            }
          }
        }
        *(_BYTE *)(a1 + 4093) |= 0x20u; /*0x1030df96c*/
        *(_BYTE *)(v5 + 2032) |= 1u; /*0x1030df973*/
        if ( v6 != 0 ) /*0x1030df97e*/
          break; /*0x1030df97e*/
        v1 = (const char **)v1[1]; /*0x1030df980*/
        if ( v1 == nullptr ) /*0x1030df987*/
        {
          v6 = 0; /*0x1030df98d*/
          break; /*0x1030df990*/
        }
      }
    }
    else
    {
      v6 = 27; /*0x1030df997*/
    }
    Curl_share_unlock(a1, a2: 2); /*0x1030df99d*/
  }
  else
  {
    return 0; /*0x1030df992*/
  }
  return v6; /*0x1030df9ad*/
}

// Address: 0x1030df9bc | Name: _Curl_secure_context
__int64 __fastcall Curl_secure_context(__int64 a1, const char *a2)
{
  unsigned int v2; // ebx

  LOBYTE(v2) = 1; /*0x1030df9ca*/
  if ( (*(_DWORD *)(*(_QWORD *)(a1 + 736) + 16LL) & 0x80000002) == 0 /*0x1030df9f9*/
    && curl_strequal(s1: "localhost", s2: a2) == 0
    && strcmp(__s1: a2, __s2: "127.0.0.1") != 0 )
  {
    LOBYTE(v2) = strcmp(__s1: a2, __s2: "::1") == 0; /*0x1030dfa0c*/
  }
  return v2; /*0x1030dfa11*/
}

// Address: 0x1030dfa16 | Name: _Curl_cookie_getlist
__int64 __fastcall Curl_cookie_getlist(__int64 a1, __int64 a2, _BYTE *a3, char *a4, __int64 a5)
{
  unsigned __int64 v9; // r14
  __int64 v10; // rbx
  __int64 v11; // r14
  __int64 v12; // rax
  char v13; // r13
  __int64 v14; // r15
  size_t v15; // r12
  __int64 v16; // r14
  char v17; // al
  char *v18; // rbx
  char v19; // al
  size_t v20; // rax
  const char *v21; // rbx
  size_t v22; // rax
  size_t v23; // r13
  const char *v24; // r12
  size_t v25; // rax
  _QWORD *v26; // rax
  _QWORD *v27; // rbx
  __int64 v28; // rax
  __int64 v29; // r14
  _QWORD *v30; // r15
  __int64 v31; // r14
  size_t v32; // r12
  char *__s; // [rsp+0h] [rbp-60h]
  _BYTE *v35; // [rsp+8h] [rbp-58h]
  size_t v36; // [rsp+10h] [rbp-50h]
  char *s1; // [rsp+18h] [rbp-48h]
  size_t v39; // [rsp+28h] [rbp-38h]
  char v40; // [rsp+36h] [rbp-2Ah]
  char is_ipnum; // [rsp+37h] [rbp-29h]

  is_ipnum = Curl_host_is_ipnum(a1: a4); /*0x1030dfa3f*/
  v9 = cookiehash(__s: a4); /*0x1030dfa4a*/
  s1 = a4; /*0x1030dfa50*/
  v40 = Curl_secure_context(a1: a2, a2: a4); /*0x1030dfa5c*/
  v10 = *(_QWORD *)(a1 + 1856); /*0x1030dfa5f*/
  __s = *(char **)(a1 + 3712); /*0x1030dfa6d*/
  v35 = a3; /*0x1030dfa75*/
  *a3 = 0; /*0x1030dfa79*/
  Curl_llist_init(a1: a5, a2: 0); /*0x1030dfa80*/
  if ( v10 == 0 ) /*0x1030dfa88*/
    return 0; /*0x1030dfa88*/
  v11 = v10 + 32 * v9; /*0x1030dfa92*/
  if ( Curl_llist_count(a1: v11) == 0 ) /*0x1030dfaa0*/
    return 0; /*0x1030dfaa0*/
  remove_expired(a1: v10); /*0x1030dfaa9*/
  v12 = Curl_llist_head(a1: v11); /*0x1030dfab1*/
  v13 = is_ipnum; /*0x1030dfab9*/
  if ( v12 == 0 ) /*0x1030dfabd*/
    goto LABEL_35; /*0x1030dfabd*/
  v14 = v12; /*0x1030dfac3*/
  v15 = 0; /*0x1030dfac6*/
  do /*0x1030dfbd4*/
  {
    v16 = Curl_node_elem(a1: v14); /*0x1030dfad1*/
    v17 = *(_BYTE *)(v16 + 108); /*0x1030dfad4*/
    if ( (v40 & 1 | ((v17 & 2) == 0)) == 0 ) /*0x1030dfae2*/
      goto LABEL_22; /*0x1030dfae2*/
    v39 = v15; /*0x1030dfae8*/
    v18 = *(char **)(v16 + 88); /*0x1030dfaec*/
    if ( v18 != nullptr ) /*0x1030dfaf3*/
    {
      v19 = v17 & 1; /*0x1030dfaf5*/
      if ( (v13 & 1 | (v19 == 0)) != 0 ) /*0x1030dfb00*/
        goto LABEL_10; /*0x1030dfb00*/
      v20 = strlen(__s: *(const char **)(v16 + 88)); /*0x1030dfb05*/
      if ( (unsigned __int8)cookie_tailmatch(s1: v18, n: v20, __s: s1) == 0 ) /*0x1030dfb1b*/
      {
        v19 = *(_BYTE *)(v16 + 108) & 1; /*0x1030dfb21*/
LABEL_10:
        if ( (v13 & 1 | (v19 == 0)) == 0 || curl_strequal(s1, s2: *(const char **)(v16 + 88)) == 0 ) /*0x1030dfb3e*/
          goto LABEL_22; /*0x1030dfb3e*/
      }
    }
    v21 = *(const char **)(v16 + 80); /*0x1030dfb40*/
    if ( v21 == nullptr ) /*0x1030dfb47*/
      goto LABEL_14; /*0x1030dfb47*/
    v22 = strlen(__s: *(const char **)(v16 + 80)); /*0x1030dfb4c*/
    if ( v22 == 1 ) /*0x1030dfb55*/
      goto LABEL_14; /*0x1030dfb55*/
    v23 = v22; /*0x1030dfb86*/
    v24 = "/"; /*0x1030dfb90*/
    if ( *__s == 47 ) /*0x1030dfb97*/
      v24 = __s; /*0x1030dfb97*/
    v25 = strlen(__s: v24); /*0x1030dfb9e*/
    if ( v25 >= v23 && (v36 = v25, strncmp(__s1: v21, __s2: v24, __n: v23) == 0) && (v23 == v36 || v24[v23] == 47) ) /*0x1030dfbeb*/
    {
LABEL_14:
      Curl_llist_append(a1: a5, a2: v16, a3: v16 + 32); /*0x1030dfb65*/
      v15 = v39 + 1; /*0x1030dfb6e*/
      v13 = is_ipnum; /*0x1030dfb78*/
      if ( v39 + 1 > 0x95 ) /*0x1030dfb7c*/
        goto LABEL_28; /*0x1030dfb7c*/
    }
    else
    {
      v15 = v39; /*0x1030dfbbe*/
      v13 = is_ipnum; /*0x1030dfbc2*/
    }
LABEL_22:
    v14 = Curl_node_next(a1: v14); /*0x1030dfbc6*/
  }
  while ( v14 != 0 ); /*0x1030dfbd4*/
  if ( v15 == 0 ) /*0x1030dfbf6*/
    goto LABEL_35; /*0x1030dfbf6*/
LABEL_28:
  v26 = Curl_cmalloc(__size: 8 * v15); /*0x1030dfbfc*/
  if ( v26 != nullptr ) /*0x1030dfc10*/
  {
    v27 = v26; /*0x1030dfc16*/
    v28 = Curl_llist_head(a1: a5); /*0x1030dfc1d*/
    if ( v28 != 0 ) /*0x1030dfc25*/
    {
      v29 = v28; /*0x1030dfc27*/
      v30 = v27; /*0x1030dfc2a*/
      do /*0x1030dfc4a*/
      {
        *v30 = Curl_node_elem(a1: v29); /*0x1030dfc35*/
        v29 = Curl_node_next(a1: v29); /*0x1030dfc40*/
        ++v30; /*0x1030dfc43*/
      }
      while ( v29 != 0 ); /*0x1030dfc4a*/
    }
    qsort(__base: v27, __nel: v15, __width: 8u, __compar: cookie_sort); /*0x1030dfc5e*/
    v31 = 0; /*0x1030dfc63*/
    Curl_llist_destroy(a1: a5, a2: 0); /*0x1030dfc6f*/
    v32 = (v15 == 0) + v15; /*0x1030dfc78*/
    do /*0x1030dfc92*/
    {
      Curl_llist_append(a1: a5, a2: v27[v31], a3: v27[v31] + 32LL); /*0x1030dfc87*/
      ++v31; /*0x1030dfc8c*/
    }
    while ( v32 != v31 ); /*0x1030dfc92*/
    Curl_cfree(a1: v27); /*0x1030dfc9e*/
LABEL_35:
    *v35 = 1; /*0x1030dfca0*/
    return 0; /*0x1030dfca7*/
  }
  else
  {
    Curl_llist_destroy(a1: a5, a2: 0); /*0x1030dfcbe*/
    return 27; /*0x1030dfcc3*/
  }
}

// Address: 0x1030dfcca | Name: _cookie_tailmatch
bool __fastcall cookie_tailmatch(char *s1, size_t n, char *__s)
{
  size_t v6; // rax
  size_t v7; // r15
  const char *v8; // rbx
  bool result; // al

  v6 = strlen(__s); /*0x1030dfce1*/
  if ( v6 < n ) /*0x1030dfce9*/
    return false; /*0x1030dfce9*/
  v7 = v6; /*0x1030dfceb*/
  v8 = &__s[v6 - n]; /*0x1030dfcf1*/
  if ( curl_strnequal(s1, s2: v8, n) == 0 ) /*0x1030dfd04*/
    return false; /*0x1030dfd16*/
  result = true; /*0x1030dfd06*/
  if ( v7 != n ) /*0x1030dfd0b*/
    return *(v8 - 1) == 46; /*0x1030dfd11*/
  return result; /*0x1030dfd18*/
}

// Address: 0x1030dfd21 | Name: _cookie_sort
__int64 __fastcall cookie_sort(__int64 *a1, __int64 *a2)
{
  __int64 v2; // r14
  __int64 v3; // r15
  const char *v4; // rdi
  size_t v5; // rbx
  const char *v6; // rdi
  size_t v7; // rax
  bool v8; // cf
  const char *v9; // rdi
  size_t v10; // rbx
  const char *v11; // rdi
  size_t v12; // rax
  const char *v13; // rdi
  size_t v14; // rbx
  const char *v15; // rdi
  size_t v16; // rax
  bool v17; // al

  v2 = *a1; /*0x1030dfd2b*/
  v3 = *a2; /*0x1030dfd2e*/
  v4 = *(const char **)(*a1 + 80); /*0x1030dfd31*/
  if ( v4 != nullptr ) /*0x1030dfd38*/
    v5 = strlen(__s: v4); /*0x1030dfd3f*/
  else
    v5 = 0; /*0x1030dfd44*/
  v6 = *(const char **)(v3 + 80); /*0x1030dfd46*/
  if ( v6 != nullptr ) /*0x1030dfd4d*/
    v7 = strlen(__s: v6); /*0x1030dfd4f*/
  else
    v7 = 0; /*0x1030dfd56*/
  v8 = v5 < v7; /*0x1030dfd58*/
  if ( v5 != v7 ) /*0x1030dfd5b*/
    goto LABEL_23; /*0x1030dfd5b*/
  v9 = *(const char **)(v2 + 88); /*0x1030dfd5d*/
  v10 = v9 != nullptr ? strlen(__s: v9) : 0LL;
  v11 = *(const char **)(v3 + 88); /*0x1030dfd72*/
  v12 = v11 != nullptr ? strlen(__s: v11) : 0LL;
  v8 = v10 < v12; /*0x1030dfd84*/
  if ( v10 == v12
    && ((v13 = *(const char **)(v2 + 64)) == nullptr ? (v14 = 0) : (v14 = strlen(__s: v13)),
        (v15 = *(const char **)(v3 + 64)) == nullptr ? (v16 = 0) : (v16 = strlen(__s: v15)),
        v8 = v14 < v16,
        v14 == v16) )
  {
    v17 = *(_DWORD *)(v3 + 104) > *(_DWORD *)(v2 + 104); /*0x1030dfdbd*/
  }
  else
  {
LABEL_23:
    v17 = v8; /*0x1030dfdc2*/
  }
  return v17 ? 1 : -1;
}

// END _free_c part 76/166, 400 functions
