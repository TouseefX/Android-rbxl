// FeatureTimeout -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 11 functions


// Address: 0x104accd1e | Name: __ZN3RBX14FeatureTimeoutC2ENS_5Enums29FeatureRestrictionAbuseVectorEbbxx
void __fastcall RBX::FeatureTimeout::FeatureTimeout(__int64 a1, int a2, char a3, char a4, __int64 a5, __int64 a6)
{
  *(_DWORD *)a1 = a2; /*0x104accd22*/
  *(_BYTE *)(a1 + 4) = a3; /*0x104accd24*/
  *(_BYTE *)(a1 + 5) = a4; /*0x104accd27*/
  *(_QWORD *)(a1 + 8) = a5; /*0x104accd2a*/
  *(_QWORD *)(a1 + 16) = a6; /*0x104accd2e*/
}

// Address: 0x104accd34 | Name: __ZN3RBX14FeatureTimeoutC1ENS_5Enums29FeatureRestrictionAbuseVectorEbbxx
void __fastcall RBX::FeatureTimeout::FeatureTimeout(__int64 a1, int a2, char a3, char a4, __int64 a5, __int64 a6)
{
  *(_DWORD *)a1 = a2; /*0x104accd38*/
  *(_BYTE *)(a1 + 4) = a3; /*0x104accd3a*/
  *(_BYTE *)(a1 + 5) = a4; /*0x104accd3d*/
  *(_QWORD *)(a1 + 8) = a5; /*0x104accd40*/
  *(_QWORD *)(a1 + 16) = a6; /*0x104accd44*/
}

// Address: 0x104accd4a | Name: __ZNK3RBX14FeatureTimeout26shouldUpdateFeatureTimeoutEbxx
bool __fastcall RBX::FeatureTimeout::shouldUpdateFeatureTimeout(
        RBX::FeatureTimeout *this,
        unsigned __int8 a2,
        __int64 a3,
        __int64 a4)
{
  bool v7; // zf
  bool result; // al
  __int64 v9; // rax

  v7 = (a2 | (unsigned __int8)RBX::FeatureTimeout::isActive(this) ^ 1) == 0; /*0x104accd68*/
  result = true; /*0x104accd6b*/
  if ( v7 ) /*0x104accd6d*/
  {
    v9 = -1; /*0x104accd6f*/
    if ( *((_BYTE *)this + 5) == 0 ) /*0x104accd7b*/
      v9 = *((_QWORD *)this + 1) + *((_QWORD *)this + 2); /*0x104accd81*/
    return v9 < a3 + a4; /*0x104accd8b*/
  }
  return result; /*0x104accd8e*/
}

// Address: 0x104accd98 | Name: __ZNK3RBX14FeatureTimeout8isActiveEv
bool __fastcall RBX::FeatureTimeout::isActive(RBX::FeatureTimeout *this)
{
  bool result; // al
  __int64 v2; // rbx
  __int64 v3; // rdx
  _QWORD v4[4]; // [rsp-20h] [rbp-20h] BYREF

  result = true; /*0x104accd9c*/
  if ( *((_BYTE *)this + 5) == 0 ) /*0x104accd9e*/
  {
    v2 = *((_QWORD *)this + 1) + *((_QWORD *)this + 2); /*0x104accdad*/
    v4[0] = RBX::DateTime::now(this); /*0x104accdba*/
    v4[1] = v3; /*0x104accdbd*/
    return v2 > RBX::DateTime::getUnixTimestamp(this: (RBX::DateTime *)v4); /*0x104accdc9*/
  }
  return result; /*0x104accdd2*/
}

// Address: 0x104accdd4 | Name: __ZNK3RBX14FeatureTimeout10getEndTimeEv
__int64 __fastcall RBX::FeatureTimeout::getEndTime(RBX::FeatureTimeout *this)
{
  __int64 result; // rax

  result = -1; /*0x104accdd8*/
  if ( *((_BYTE *)this + 5) == 0 ) /*0x104accde3*/
    return *((_QWORD *)this + 1) + *((_QWORD *)this + 2); /*0x104accde9*/
  return result; /*0x104accded*/
}

// Address: 0x104accdf0 | Name: __ZN3RBX14FeatureTimeout20updateFeatureTimeoutEbbxx
void __fastcall RBX::FeatureTimeout::updateFeatureTimeout(
        RBX::FeatureTimeout *this,
        char a2,
        char a3,
        __int64 a4,
        __int64 a5)
{
  *((_BYTE *)this + 4) = a2; /*0x104accdf4*/
  *((_BYTE *)this + 5) = a3; /*0x104accdf8*/
  *((_QWORD *)this + 1) = a4; /*0x104accdfb*/
  *((_QWORD *)this + 2) = a5; /*0x104accdff*/
}

// Address: 0x104acce06 | Name: __ZNK3RBX14FeatureTimeout17isAcknowledgeableEv
char __fastcall RBX::FeatureTimeout::isAcknowledgeable(RBX::FeatureTimeout *this)
{
  return *((_BYTE *)this + 4); /*0x104acce0d*/
}

// Address: 0x104acce10 | Name: __ZNK3RBX14FeatureTimeout11isPermanentEv
char __fastcall RBX::FeatureTimeout::isPermanent(RBX::FeatureTimeout *this)
{
  return *((_BYTE *)this + 5); /*0x104acce17*/
}

// Address: 0x104acce1a | Name: __ZNK3RBX14FeatureTimeout12getStartTimeEv
__int64 __fastcall RBX::FeatureTimeout::getStartTime(RBX::FeatureTimeout *this)
{
  return *((_QWORD *)this + 1); /*0x104acce22*/
}

// Address: 0x104acce24 | Name: __ZNK3RBX14FeatureTimeout11getDurationEv
__int64 __fastcall RBX::FeatureTimeout::getDuration(RBX::FeatureTimeout *this)
{
  return *((_QWORD *)this + 2); /*0x104acce2c*/
}

// Address: 0x104acce2e | Name: __ZNK3RBX14FeatureTimeout14getAbuseVectorEv
__int64 __fastcall RBX::FeatureTimeout::getAbuseVector(RBX::FeatureTimeout *this)
{
  return *(unsigned int *)this; /*0x104acce34*/
}

// END FeatureTimeout part 1/1, 11 functions
