// ProfileFrameTime -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 14 functions


// Address: 0x102b7c106 | Name: __ZN3RBX8Profiler16ProfileFrameTimeC2Ev
const char *__fastcall RBX::Profiler::ProfileFrameTime::ProfileFrameTime(RBX::Profiler::ProfileFrameTime *this)
{
  *(_QWORD *)this = "ProfileFrameTime"; /*0x102b7c111*/
  *((_QWORD *)this + 1) = 16; /*0x102b7c114*/
  *((_QWORD *)this + 9) = 0; /*0x102b7c11c*/
  *((_OWORD *)this + 2) = 0; /*0x102b7c127*/
  *((_OWORD *)this + 3) = 0; /*0x102b7c12b*/
  *(_DWORD *)((char *)this + 63) = 0; /*0x102b7c12f*/
  return "ProfileFrameTime"; /*0x102b7c136*/
}

// Address: 0x102b7c138 | Name: __ZN3RBX8Profiler16ProfileFrameTimeC1Ev
const char *__fastcall RBX::Profiler::ProfileFrameTime::ProfileFrameTime(RBX::Profiler::ProfileFrameTime *this)
{
  *(_QWORD *)this = "ProfileFrameTime"; /*0x102b7c143*/
  *((_QWORD *)this + 1) = 16; /*0x102b7c146*/
  *((_QWORD *)this + 9) = 0; /*0x102b7c14e*/
  *((_OWORD *)this + 2) = 0; /*0x102b7c159*/
  *((_OWORD *)this + 3) = 0; /*0x102b7c15d*/
  *(_DWORD *)((char *)this + 63) = 0; /*0x102b7c161*/
  return "ProfileFrameTime"; /*0x102b7c168*/
}

// Address: 0x102b7c16a | Name: __ZN3RBX8Profiler16ProfileFrameTime10initializeEv
void __fastcall RBX::Profiler::ProfileFrameTime::initialize(
        RBX::Profiler::ProfileFrameTime *this,
        __int64 a2,
        __int64 a3)
{
  double v4; // xmm0_8
  __int64 v5; // rcx
  __int64 v6; // r13
  __int64 v7; // rax
  unsigned int v8; // esi
  unsigned int v9; // r15d
  unsigned int v10; // r12d
  rbx::signals::slots_holder **v11; // r13
  unsigned __int64 v12; // rsi
  volatile signed __int32 *v13; // rbx
  rbx::signals::slots_holder *v14; // rax
  unsigned __int64 v15; // rax
  unsigned int v16; // esi
  unsigned int v17; // esi
  __int64 v18; // r12
  unsigned int v19; // r15d
  rbx::signals::slots_holder **v20; // r12
  unsigned __int64 v21; // rsi
  volatile signed __int32 *v22; // rbx
  rbx::signals::slots_holder *v23; // rax
  unsigned __int64 v24; // rax
  unsigned int v25; // esi
  _QWORD *v26; // [rsp+8h] [rbp-38h]

  if ( DFFlag::DebugOverrideProfileFrameTimeNow == 1 ) /*0x102b7c185*/
    v4 = *((double *)this + 9); /*0x102b7c187*/
  else
    v4 = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: this); /*0x102b7c18f*/
  *((double *)this + 4) = v4; /*0x102b7c194*/
  v5 = _InterlockedExchange64((volatile __int64 *)this + 2, *(__int64 *)&v4); /*0x102b7c1a2*/
  _InterlockedExchange64((volatile __int64 *)this + 3, *(__int64 *)&v4); /*0x102b7c1a6*/
  v6 = 0; /*0x102b7c1aa*/
  *((_BYTE *)this + 65) = 0; /*0x102b7c1af*/
  v7 = RBX::Subsystem<RBX::SessionTransitionFSM,false>::startup<RBX::SubsystemDefaultFactory<RBX::SessionTransitionFSM>>( /*0x102b7c1b3*/
         a1: this,
         a2,
         a3,
         a4: v5);
  v26 = (_QWORD *)v7; /*0x102b7c1bb*/
  if ( v7 != 0 ) /*0x102b7c1bf*/
    v6 = *(_QWORD *)(v7 + 24); /*0x102b7c1c1*/
  v9 = (unsigned int)RBX::Memory::InstanceSignal; /*0x102b7c1cc*/
  v10 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v8); /*0x102b7c1d7*/
  v11 = (rbx::signals::slots_holder **)(v6 + 24); /*0x102b7c1da*/
  rbx::lazyInitSlotsHolder(a1: v11); /*0x102b7c1e1*/
  v13 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v12); /*0x102b7c1f0*/
  *(_QWORD *)v13 = &_mh_execute_header; /*0x102b7c1fd*/
  *((_QWORD *)v13 + 1) = rbx::signals::slot_with_functor<RBX::Profiler::ProfileFrameTime::initialize(void)::$_0>::do_call; /*0x102b7c207*/
  *((_OWORD *)v13 + 1) = 0; /*0x102b7c20f*/
  v14 = *v11; /*0x102b7c214*/
  *((_QWORD *)v13 + 4) = *v11; /*0x102b7c218*/
  if ( v14 != nullptr ) /*0x102b7c21f*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v14 + 1); /*0x102b7c221*/
    v15 = *((_QWORD *)v13 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x102b7c229*/
  }
  else
  {
    v15 = 0; /*0x102b7c22f*/
  }
  *((_QWORD *)v13 + 3) = v15; /*0x102b7c231*/
  *((_QWORD *)v13 + 5) = this; /*0x102b7c235*/
  rbx::signals::slots_holder::insert(this: *v11, a2: (unsigned __int64)v13); /*0x102b7c240*/
  _InterlockedIncrement(v13 + 1); /*0x102b7c249*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v10, a2: v16); /*0x102b7c250*/
  rbx::signals::scoped_connection::operator=(this: (RBX::Profiler::ProfileFrameTime *)((char *)this + 48)); /*0x102b7c25d*/
  if ( v13 != nullptr && _InterlockedDecrement(v13 + 1) == 0 ) /*0x102b7c26f*/
    rbx::signals::slot_base::operator delete(a1: (void *)v13); /*0x102b7c271*/
  if ( v26 != nullptr ) /*0x102b7c27d*/
    v18 = v26[3]; /*0x102b7c27f*/
  else
    v18 = 0; /*0x102b7c285*/
  v19 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v9, a2: v17); /*0x102b7c290*/
  v20 = (rbx::signals::slots_holder **)(v18 + 16); /*0x102b7c293*/
  rbx::lazyInitSlotsHolder(a1: v20); /*0x102b7c29a*/
  v22 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v21); /*0x102b7c2a9*/
  *(_QWORD *)v22 = &_mh_execute_header; /*0x102b7c2b6*/
  *((_QWORD *)v22 + 1) = rbx::signals::slot_with_functor<RBX::Profiler::ProfileFrameTime::initialize(void)::$_1>::do_call; /*0x102b7c2c0*/
  *((_OWORD *)v22 + 1) = 0; /*0x102b7c2c8*/
  v23 = *v20; /*0x102b7c2cd*/
  *((_QWORD *)v22 + 4) = *v20; /*0x102b7c2d1*/
  if ( v23 != nullptr ) /*0x102b7c2d8*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v23 + 1); /*0x102b7c2da*/
    v24 = *((_QWORD *)v22 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x102b7c2e2*/
  }
  else
  {
    v24 = 0; /*0x102b7c2e8*/
  }
  *((_QWORD *)v22 + 3) = v24; /*0x102b7c2ea*/
  *((_QWORD *)v22 + 5) = this; /*0x102b7c2ee*/
  rbx::signals::slots_holder::insert(this: *v20, a2: (unsigned __int64)v22); /*0x102b7c2f9*/
  _InterlockedIncrement(v22 + 1); /*0x102b7c302*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v19, a2: v25); /*0x102b7c309*/
  rbx::signals::scoped_connection::operator=(this: (RBX::Profiler::ProfileFrameTime *)((char *)this + 56)); /*0x102b7c31a*/
  if ( v22 != nullptr && _InterlockedDecrement(v22 + 1) == 0 ) /*0x102b7c32c*/
    rbx::signals::slot_base::operator delete(a1: (void *)v22); /*0x102b7c32e*/
  *((_BYTE *)this + 64) = 1; /*0x102b7c333*/
  if ( v26 != nullptr ) /*0x102b7c33b*/
    (*(void (__fastcall **)(_QWORD *))(*v26 + 16LL))(a1: v26); /*0x102b7c343*/
}

// Address: 0x102b7c3be | Name: __ZN3RBX8Profiler16ProfileFrameTime10getTimeNowEv
double __fastcall RBX::Profiler::ProfileFrameTime::getTimeNow(RBX::Profiler::ProfileFrameTime *this)
{
  if ( DFFlag::DebugOverrideProfileFrameTimeNow == 1 ) /*0x102b7c3c9*/
    return *((double *)this + 9); /*0x102b7c3cb*/
  else
    return RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: this); /*0x102b7c3d3*/
}

// Address: 0x102b7c3d8 | Name: __ZN3RBX8Profiler16ProfileFrameTime4tickEv
void __fastcall RBX::Profiler::ProfileFrameTime::tick(RBX::Profiler::ProfileFrameTime *this)
{
  double v2; // xmm2_8
  double v3; // xmm0_8
  double v4; // xmm3_8
  __int64 v5; // rax
  __int64 v6; // r14
  __int64 v7; // rdi
  double v8; // [rsp+18h] [rbp-18h]
  double v9; // [rsp+18h] [rbp-18h]

  if ( *((_BYTE *)this + 64) == 1 ) /*0x102b7c3e7*/
  {
    v2 = *((double *)this + 4); /*0x102b7c3f0*/
    if ( DFFlag::DebugOverrideProfileFrameTimeNow == 1 ) /*0x102b7c3fc*/
    {
      v3 = *((double *)this + 9); /*0x102b7c3fe*/
    }
    else
    {
      v8 = *((double *)this + 4); /*0x102b7c405*/
      v3 = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: this); /*0x102b7c40a*/
      v2 = v8; /*0x102b7c40f*/
    }
    *((double *)this + 5) = v3 - v2; /*0x102b7c41c*/
    *((_BYTE *)this + 66) = 0; /*0x102b7c423*/
    if ( _InterlockedCompareExchange8((volatile signed __int8 *)this + 65, 0, 1) == 1 ) /*0x102b7c42d*/
    {
      v4 = fmin(v3, *((double *)this + 3)) - fmax(v2, *((double *)this + 2)); /*0x102b7c449*/
      if ( v4 >= 0.0 ) /*0x102b7c455*/
      {
        *((double *)this + 5) = *((double *)this + 5) - v4; /*0x102b7c4af*/
      }
      else
      {
        v9 = v3; /*0x102b7c45c*/
        v5 = RBX::Subsystem<RBX::UpwardFunctions,false>::startup<RBX::SubsystemDefaultFactory<RBX::UpwardFunctions>>(); /*0x102b7c461*/
        v3 = v9; /*0x102b7c466*/
        if ( v5 != 0 ) /*0x102b7c46e*/
        {
          v6 = v5; /*0x102b7c470*/
          v7 = *(_QWORD *)(*(_QWORD *)(v5 + 24) + 288LL); /*0x102b7c477*/
          if ( v7 != 0 ) /*0x102b7c481*/
            (*(void (__fastcall **)(__int64))(*(_QWORD *)v7 + 48LL))(a1: v7); /*0x102b7c493*/
          (*(void (__fastcall **)(__int64, double))(*(_QWORD *)v6 + 16LL))(a1: v6, a2: v3); /*0x102b7c49c*/
          v3 = v9; /*0x102b7c49f*/
        }
      }
      *((_BYTE *)this + 66) = 1; /*0x102b7c4b4*/
    }
    *((double *)this + 4) = v3; /*0x102b7c4b8*/
  }
}

// Address: 0x102b7c4e4 | Name: __ZN3RBX8Profiler16ProfileFrameTime12getFrameTimeEv
double __fastcall RBX::Profiler::ProfileFrameTime::getFrameTime(RBX::Profiler::ProfileFrameTime *this)
{
  return *((double *)this + 5); /*0x102b7c4ed*/
}

// Address: 0x102b7c4f0 | Name: __ZN3RBX8Profiler16ProfileFrameTime17getFrameTimestampEv
double __fastcall RBX::Profiler::ProfileFrameTime::getFrameTimestamp(RBX::Profiler::ProfileFrameTime *this)
{
  return *((double *)this + 4); /*0x102b7c4f9*/
}

// Address: 0x102b7c4fc | Name: __ZN3RBX8Profiler16ProfileFrameTime12getFrameTimeERb
double __fastcall RBX::Profiler::ProfileFrameTime::getFrameTime(RBX::Profiler::ProfileFrameTime *this, bool *a2)
{
  *a2 = *((_BYTE *)this + 66); /*0x102b7c503*/
  return *((double *)this + 5); /*0x102b7c50a*/
}

// Address: 0x102b7c50c | Name: __ZN3RBX8Profiler16ProfileFrameTime17getFrameTimestampERb
double __fastcall RBX::Profiler::ProfileFrameTime::getFrameTimestamp(RBX::Profiler::ProfileFrameTime *this, bool *a2)
{
  *a2 = *((_BYTE *)this + 66); /*0x102b7c513*/
  return *((double *)this + 4); /*0x102b7c51a*/
}

// Address: 0x102b7c51c | Name: __ZN3RBX8Profiler16ProfileFrameTime18setTimeNowOverrideERKNS_4TimeE
__int64 __fastcall RBX::Profiler::ProfileFrameTime::setTimeNowOverride(
        RBX::Profiler::ProfileFrameTime *this,
        const RBX::Time *a2)
{
  __int64 result; // rax

  result = *(_QWORD *)a2; /*0x102b7c520*/
  *((_QWORD *)this + 9) = *(_QWORD *)a2; /*0x102b7c523*/
  return result; /*0x102b7c527*/
}

// Address: 0x102b7c52a | Name: __ZN3RBX8Profiler16ProfileFrameTime14onBackgroundedEv
void __fastcall RBX::Profiler::ProfileFrameTime::onBackgrounded(RBX::Profiler::ProfileFrameTime *this)
{
  double v2; // xmm0_8

  if ( DFFlag::DebugOverrideProfileFrameTimeNow == 1 ) /*0x102b7c53a*/
    v2 = *((double *)this + 9); /*0x102b7c53c*/
  else
    v2 = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: this); /*0x102b7c543*/
  *((double *)this + 2) = v2; /*0x102b7c548*/
  *((double *)this + 3) = v2; /*0x102b7c54d*/
}

// Address: 0x102b7c55a | Name: __ZN3RBX8Profiler16ProfileFrameTime14onForegroundedEv
void __fastcall RBX::Profiler::ProfileFrameTime::onForegrounded(RBX::Profiler::ProfileFrameTime *this)
{
  double v2; // xmm0_8

  if ( DFFlag::DebugOverrideProfileFrameTimeNow == 1 ) /*0x102b7c56a*/
    v2 = *((double *)this + 9); /*0x102b7c56c*/
  else
    v2 = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: this); /*0x102b7c573*/
  *((double *)this + 3) = v2; /*0x102b7c578*/
  *((_BYTE *)this + 65) = 1; /*0x102b7c57d*/
}

// Address: 0x102b7c588 | Name: __ZN3RBX8Profiler16ProfileFrameTime22onBackgroundedUnitTestEv
void __fastcall RBX::Profiler::ProfileFrameTime::onBackgroundedUnitTest(RBX::Profiler::ProfileFrameTime *this)
{
  double v2; // xmm0_8

  if ( DFFlag::DebugOverrideProfileFrameTimeNow == 1 ) /*0x102b7c598*/
    v2 = *((double *)this + 9); /*0x102b7c59a*/
  else
    v2 = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: this); /*0x102b7c5a1*/
  *((double *)this + 2) = v2; /*0x102b7c5a6*/
  *((double *)this + 3) = v2; /*0x102b7c5ab*/
}

// Address: 0x102b7c5b8 | Name: __ZN3RBX8Profiler16ProfileFrameTime22onForegroundedUnitTestEv
void __fastcall RBX::Profiler::ProfileFrameTime::onForegroundedUnitTest(RBX::Profiler::ProfileFrameTime *this)
{
  double v2; // xmm0_8

  if ( DFFlag::DebugOverrideProfileFrameTimeNow == 1 ) /*0x102b7c5c8*/
    v2 = *((double *)this + 9); /*0x102b7c5ca*/
  else
    v2 = RBX::Time::now<(RBX::Time::SampleMethod)1>(a1: this); /*0x102b7c5d1*/
  *((double *)this + 3) = v2; /*0x102b7c5d6*/
  *((_BYTE *)this + 65) = 1; /*0x102b7c5db*/
}

// END ProfileFrameTime part 1/1, 14 functions
