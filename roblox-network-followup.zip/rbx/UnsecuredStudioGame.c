// UnsecuredStudioGame -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 4 functions

// Field names below come from the 2022 PDB, which is the only
// build that has them. Each is marked: bare `this->x` was
// corroborated by a store of matching width in that same
// function; UNVERIFIED means the 2022 layout says so and
// nothing target-era has confirmed it.


// Address: 0x1074e639c | Name: __ZN3RBX19UnsecuredStudioGameC2EPKcbbNS_7Network16GameLaunchIntentERKNS_29DataModelInitializationParamsE
void (__fastcall **__fastcall RBX::UnsecuredStudioGame::UnsecuredStudioGame(
        _QWORD *a1,
        __int64 a2,
        int a3,
        unsigned int a4,
        unsigned int a5,
        __int64 a6))(RBX::UnsecuredStudioGame *__hidden this)
{
  void (__fastcall **result)(RBX::UnsecuredStudioGame *__hidden); // rax
  __int64 (__fastcall **v9)(RBX::Network *__hidden); // [rsp+8h] [rbp-28h] BYREF
  __int64 (__fastcall ***v10)(RBX::Network *__hidden); // [rsp+10h] [rbp-20h] BYREF
  __int64 (__fastcall *v11)(RBX::Network *__hidden); // [rsp+18h] [rbp-18h] BYREF

  RBX::Game::Game(a1, a2, a3: a4, a4: a5, a5: a6); /*0x1074e63b5*/
  result = off_10CB49820; /*0x1074e63ba*/
  *a1 = off_10CB49820; /*0x1074e63c1*/
  if ( a3 != 0 ) /*0x1074e63c7*/
  {
    v11 = RBX::Network::initWithoutSecurity; /*0x1074e63d0*/
    result = (void (__fastcall **)(RBX::UnsecuredStudioGame *__hidden))RBX::UnsecuredStudioGame::UnsecuredStudioGame(char const*,bool,bool,RBX::Network::GameLaunchIntent,RBX::DataModelInitializationParams const&)::flag; /*0x1074e63d4*/
    if ( RBX::UnsecuredStudioGame::UnsecuredStudioGame(char const*,bool,bool,RBX::Network::GameLaunchIntent,RBX::DataModelInitializationParams const&)::flag != -1 ) /*0x1074e63df*/
    {
      v9 = &v11; /*0x1074e63e9*/
      v10 = &v9; /*0x1074e63f0*/
      return (void (__fastcall **)(RBX::UnsecuredStudioGame *__hidden))std::__call_once( /*0x1074e6401*/
                                                                         a1: &RBX::UnsecuredStudioGame::UnsecuredStudioGame(char const*,bool,bool,RBX::Network::GameLaunchIntent,RBX::DataModelInitializationParams const&)::flag,
                                                                         a2: &v10,
                                                                         a3: std::__call_once_proxy[abi:ne200100]<std::tuple<void (*&&)(void)>>);
    }
  }
  return result; /*0x1074e6406*/
}

// Address: 0x1074e68b2 | Name: __ZN3RBX19UnsecuredStudioGameC1EPKcbbNS_7Network16GameLaunchIntentERKNS_29DataModelInitializationParamsE
void (__fastcall **__fastcall RBX::UnsecuredStudioGame::UnsecuredStudioGame(
        _QWORD *a1,
        __int64 a2,
        int a3,
        unsigned int a4,
        unsigned int a5,
        __int64 a6))(RBX::UnsecuredStudioGame *__hidden this)
{
  return RBX::UnsecuredStudioGame::UnsecuredStudioGame(a1, a2, a3, a4, a5, a6); /*0x1074e68b6*/
}

// Address: 0x1074e6d96 | Name: __ZN3RBX19UnsecuredStudioGameD1Ev
void __fastcall RBX::UnsecuredStudioGame::~UnsecuredStudioGame(RBX::UnsecuredStudioGame *this)
{
  RBX::Game::~Game(this); /*0x1074e6d9b*/
}

// Address: 0x1074e6da0 | Name: __ZN3RBX19UnsecuredStudioGameD0Ev
void __fastcall RBX::UnsecuredStudioGame::~UnsecuredStudioGame(RBX::UnsecuredStudioGame *this)
{
  RBX::Game::~Game(this); /*0x1074e6da9*/
  operator delete(a1: this); /*0x1074e6db7*/
}

// END UnsecuredStudioGame part 1/1, 4 functions
