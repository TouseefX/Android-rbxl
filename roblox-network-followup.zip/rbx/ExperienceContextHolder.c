// ExperienceContextHolder -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 24 functions


// Address: 0x1074dc7ea | Name: __ZN3RBX23ExperienceContextHolderC2ENS_14ExperienceTypeEPKc
__int64 __fastcall RBX::ExperienceContextHolder::ExperienceContextHolder(__int64 a1, __int64 *a2, int a3, __int64 a4)
{
  __int64 v4; // rax
  __int64 result; // rax

  v4 = *a2; /*0x1074dc7ee*/
  *(_QWORD *)a1 = *a2; /*0x1074dc7f1*/
  result = *(_QWORD *)(v4 - 96); /*0x1074dc7f8*/
  *(_QWORD *)(a1 + result) = a2[1]; /*0x1074dc7fc*/
  *(_DWORD *)(a1 + 8) = a3; /*0x1074dc800*/
  *(_QWORD *)(a1 + 16) = a4; /*0x1074dc803*/
  *(_DWORD *)(a1 + 24) = 0; /*0x1074dc807*/
  *(_OWORD *)(a1 + 32) = 0; /*0x1074dc811*/
  *(_QWORD *)(a1 + 48) = 0; /*0x1074dc815*/
  return result; /*0x1074dc81d*/
}

// Address: 0x1074dc820 | Name: __ZN3RBX23ExperienceContextHolderC1ENS_14ExperienceTypeEPKc
void (__fastcall **__fastcall RBX::ExperienceContextHolder::ExperienceContextHolder(
        __int64 a1,
        int a2,
        __int64 a3))(RBX::ExperienceContextHolder *__hidden this)
{
  *(_QWORD *)a1 = off_10CB48A88; /*0x1074dc82b*/
  *(_DWORD *)(a1 + 8) = a2; /*0x1074dc82e*/
  *(_QWORD *)(a1 + 16) = a3; /*0x1074dc831*/
  *(_DWORD *)(a1 + 24) = 0; /*0x1074dc835*/
  *(_OWORD *)(a1 + 32) = 0; /*0x1074dc83f*/
  *(_QWORD *)(a1 + 48) = 0; /*0x1074dc843*/
  return off_10CB48A88; /*0x1074dc84b*/
}

// Address: 0x1074dc84e | Name: __ZN3RBX23ExperienceContextHolderD2Ev
void __fastcall RBX::ExperienceContextHolder::~ExperienceContextHolder(RBX::ExperienceContextHolder *this, __int64 *a2)
{
  __int64 v3; // rax
  _BYTE v4[24]; // [rsp+10h] [rbp-30h] BYREF
  __int64 v5; // [rsp+28h] [rbp-18h]
  _BYTE *v6; // [rsp+30h] [rbp-10h]

  v3 = *a2; /*0x1074dc85a*/
  *(_QWORD *)this = *a2; /*0x1074dc85d*/
  *(_QWORD *)((char *)this + *(_QWORD *)(v3 - 96)) = a2[1]; /*0x1074dc868*/
  if ( (unsigned __int8)FLog::ExperienceContextHolder >= 6u && (FLog::ExperienceContextHolder & 0xFC00) != 0 ) /*0x1074dc880*/
  {
    v5 = 0; /*0x1074dc88e*/
    v6 = v4; /*0x1074dc89a*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x1074dc8be*/
      a1: FLog::ExperienceContextHolder,
      a2: qword_10D824900,
      a3: 4,
      a4: (unsigned int)"[FLog::ExperienceContextHolder] ExperienceContextHolder::~ExperienceContextHolder()",
      a5: 83,
      a6: 1,
      0,
      v4);
  }
  std::shared_ptr<RBX::EventBroadcast::Relay>::~shared_ptr[abi:ne200100](a1: (char *)this + 40); /*0x1074dc8c7*/
  std::unique_ptr<RBX::EngineContext,RBX::EngineContextDeleter>::reset[abi:ne200100](a1: (__int64 *)this + 4, a2: 0); /*0x1074dc8d5*/
}

// Address: 0x1074dc8ea | Name: __ZN3RBX23ExperienceContextHolderD1Ev
void __fastcall RBX::ExperienceContextHolder::~ExperienceContextHolder(RBX::ExperienceContextHolder *this)
{
  RBX::ExperienceContextHolder::~ExperienceContextHolder(this, a2: (__int64 *)`VTT for'RBX::ExperienceContextHolder); /*0x1074dc8f6*/
}

// Address: 0x1074dc8fc | Name: __ZTv0_n24_N3RBX23ExperienceContextHolderD1Ev
void __fastcall `virtual thunk to'RBX::ExperienceContextHolder::~ExperienceContextHolder(
        RBX::ExperienceContextHolder *this)
{
  RBX::ExperienceContextHolder::~ExperienceContextHolder( /*0x1074dc90f*/
    this: (RBX::ExperienceContextHolder *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL)),
    a2: (__int64 *)`VTT for'RBX::ExperienceContextHolder);
}

// Address: 0x1074dc914 | Name: __ZN3RBX23ExperienceContextHolderD0Ev
void __fastcall RBX::ExperienceContextHolder::~ExperienceContextHolder(RBX::ExperienceContextHolder *this)
{
  RBX::ExperienceContextHolder::~ExperienceContextHolder(this, a2: (__int64 *)`VTT for'RBX::ExperienceContextHolder); /*0x1074dc924*/
  operator delete(a1: this); /*0x1074dc932*/
}

// Address: 0x1074dc938 | Name: __ZTv0_n24_N3RBX23ExperienceContextHolderD0Ev
void __fastcall `virtual thunk to'RBX::ExperienceContextHolder::~ExperienceContextHolder(
        RBX::ExperienceContextHolder *this)
{
  RBX::ExperienceContextHolder *v1; // rbx

  v1 = (RBX::ExperienceContextHolder *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL)); /*0x1074dc944*/
  RBX::ExperienceContextHolder::~ExperienceContextHolder(this: v1, a2: (__int64 *)`VTT for'RBX::ExperienceContextHolder); /*0x1074dc952*/
  operator delete(a1: v1); /*0x1074dc960*/
}

// Address: 0x1074dc966 | Name: __ZNK3RBX23ExperienceContextHolder7getTypeEv
__int64 __fastcall RBX::ExperienceContextHolder::getType(RBX::ExperienceContextHolder *this)
{
  return *((unsigned int *)this + 2); /*0x1074dc96d*/
}

// Address: 0x1074dc970 | Name: __ZTv0_n32_NK3RBX23ExperienceContextHolder7getTypeEv
__int64 __fastcall `virtual thunk to'RBX::ExperienceContextHolder::getType(RBX::ExperienceContextHolder *this)
{
  return *(unsigned int *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL) + 8); /*0x1074dc97f*/
}

// Address: 0x1074dc982 | Name: __ZNK3RBX23ExperienceContextHolder10getContextEv
RBX::ExperienceContextHolder *__fastcall RBX::ExperienceContextHolder::getContext(
        RBX::ExperienceContextHolder *this,
        __int64 a2)
{
  __int64 v3; // rsi
  _BYTE v5[24]; // [rsp+10h] [rbp-30h] BYREF
  __int64 v6; // [rsp+28h] [rbp-18h]
  _BYTE *v7; // [rsp+30h] [rbp-10h]

  v3 = *(_QWORD *)(a2 + 32); /*0x1074dc98e*/
  if ( v3 != 0 ) /*0x1074dc995*/
  {
    RBX::EngineContext::getDataModel(this, a2: v3); /*0x1074dc99a*/
  }
  else
  {
    if ( (unsigned __int8)FLog::ExperienceContextHolder >= 6u && (FLog::ExperienceContextHolder & 0xFE00) != 0 ) /*0x1074dc9b5*/
    {
      v6 = 0; /*0x1074dc9c3*/
      v7 = v5; /*0x1074dc9cf*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x1074dc9f3*/
        a1: FLog::ExperienceContextHolder,
        a2: qword_10D824900,
        a3: 2,
        a4: (unsigned int)"[FLog::ExperienceContextHolder] Unsafe call with no engine context.",
        a5: 67,
        a6: 1,
        0,
        v5);
    }
    *(_OWORD *)this = 0; /*0x1074dc9fb*/
  }
  return this; /*0x1074dca01*/
}

// Address: 0x1074dca08 | Name: __ZTv0_n40_NK3RBX23ExperienceContextHolder10getContextEv
RBX::ExperienceContextHolder *__fastcall `virtual thunk to'RBX::ExperienceContextHolder::getContext(
        RBX::ExperienceContextHolder *this,
        _QWORD *a2)
{
  RBX::ExperienceContextHolder::getContext(this, a2: (__int64)a2 + *(_QWORD *)(*a2 - 40LL)); /*0x1074dca18*/
  return this; /*0x1074dca24*/
}

// Address: 0x1074dca28 | Name: __ZNK3RBX23ExperienceContextHolder15getContextStateEv
__int64 __fastcall RBX::ExperienceContextHolder::getContextState(RBX::ExperienceContextHolder *this)
{
  return *((unsigned int *)this + 6); /*0x1074dca2f*/
}

// Address: 0x1074dca32 | Name: __ZTv0_n48_NK3RBX23ExperienceContextHolder15getContextStateEv
__int64 __fastcall `virtual thunk to'RBX::ExperienceContextHolder::getContextState(RBX::ExperienceContextHolder *this)
{
  return *(unsigned int *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 48LL) + 24); /*0x1074dca41*/
}

// Address: 0x1074dca44 | Name: __ZNK3RBX23ExperienceContextHolder7getInfoEv
RBX::ExperienceContextHolder *__fastcall RBX::ExperienceContextHolder::getInfo(
        RBX::ExperienceContextHolder *this,
        __int64 a2)
{
  __int64 v3; // r14
  double v4; // xmm0_8
  __int64 v5; // rsi
  const RBX::DataModel *v6; // rsi
  std::__shared_weak_count *v7; // r15
  __int64 v8; // rax
  RBX::WorldStats *v10; // [rsp+0h] [rbp-30h] BYREF
  std::__shared_weak_count *v11; // [rsp+8h] [rbp-28h]
  double v12; // [rsp+10h] [rbp-20h]

  v3 = -1; /*0x1074dca54*/
  v4 = -1.0; /*0x1074dca5b*/
  if ( *(_DWORD *)(a2 + 24) != 0 ) /*0x1074dca67*/
  {
    v5 = *(_QWORD *)(a2 + 32); /*0x1074dca69*/
    if ( v5 != 0 ) /*0x1074dca70*/
    {
      RBX::EngineContext::getDataModel(this: (RBX::EngineContext *)&v10, a2: v5); /*0x1074dca79*/
      if ( v10 != nullptr ) /*0x1074dca84*/
      {
        v3 = *((_QWORD *)v10 + 105); /*0x1074dca86*/
        RBX::WorldStats::getGameTime(this: v10, a2: v6); /*0x1074dca8d*/
      }
      else
      {
        v3 = -1; /*0x1074dca94*/
        v4 = -1.0; /*0x1074dca9b*/
      }
      v7 = v11; /*0x1074dcaa3*/
      if ( v11 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v11 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1074dcabc*/
      {
        v8 = *(_QWORD *)v7; /*0x1074dcabe*/
        v12 = v4; /*0x1074dcac4*/
        (*(void (__fastcall **)(std::__shared_weak_count *))(v8 + 16))(a1: v7); /*0x1074dcac9*/
        std::__shared_weak_count::__release_weak(this: v7); /*0x1074dcacf*/
        v4 = v12; /*0x1074dcad4*/
      }
    }
  }
  ExperienceSnapshotInfo::ExperienceSnapshotInfo(this, a2: v3, a3: v4); /*0x1074dcadf*/
  return this; /*0x1074dcae7*/
}

// Address: 0x1074dcb06 | Name: __ZTv0_n56_NK3RBX23ExperienceContextHolder7getInfoEv
RBX::ExperienceContextHolder *__fastcall `virtual thunk to'RBX::ExperienceContextHolder::getInfo(
        RBX::ExperienceContextHolder *this,
        _QWORD *a2)
{
  RBX::ExperienceContextHolder::getInfo(this, a2: (__int64)a2 + *(_QWORD *)(*a2 - 56LL)); /*0x1074dcb16*/
  return this; /*0x1074dcb22*/
}

// Address: 0x1074dcb26 | Name: __ZN3RBX23ExperienceContextHolder17initializeContextERKNS_29DataModelInitializationParamsERKNS_24IExperienceContextHolder8SettingsE
__int64 __fastcall RBX::ExperienceContextHolder::initializeContext(__int64 a1, __int64 a2, unsigned __int8 *a3)
{
  std::__shared_weak_count *v5; // r14
  std::__shared_weak_count *v6; // r14
  std::__shared_weak_count *v7; // r14
  __int64 v8; // rsi
  __int64 v9; // r14
  __int64 v10; // rdx
  __int64 v11; // rcx
  __int64 v12; // r14
  __int64 v13; // rax
  __int64 v14; // rdi
  __int64 v15; // rdi
  rbx::signals::slots_holder **v16; // r14
  unsigned int v17; // r15d
  unsigned int v18; // esi
  unsigned int v19; // r12d
  unsigned __int64 v20; // rsi
  volatile signed __int32 *v21; // r13
  rbx::signals::slots_holder *v22; // rax
  unsigned __int64 v23; // rax
  rbx::signals::slots_holder *v24; // rdi
  unsigned int v25; // esi
  unsigned int v26; // esi
  rbx::signals::slots_holder **v27; // r14
  unsigned int v28; // r15d
  unsigned __int64 v29; // rsi
  volatile signed __int32 *v30; // r12
  rbx::signals::slots_holder *v31; // rax
  unsigned __int64 v32; // rax
  rbx::signals::slots_holder *v33; // rdi
  unsigned int v34; // esi
  __int64 v35; // rbx
  RBX::Profiler *v36; // rdi
  __int64 v37; // rax
  std::__shared_weak_count *v38; // r14
  std::__shared_weak_count *v39; // rbx
  __int64 (__fastcall ***v41)(RBX::Network *__hidden); // [rsp+0h] [rbp-B0h] BYREF
  __int64 (__fastcall *v42)(RBX::Network *__hidden); // [rsp+8h] [rbp-A8h] BYREF
  __int64 v43; // [rsp+10h] [rbp-A0h]
  __int64 (__fastcall **v44)(RBX::Network *__hidden); // [rsp+18h] [rbp-98h] BYREF
  std::__shared_weak_count *v45; // [rsp+20h] [rbp-90h]
  unsigned __int8 *v46; // [rsp+28h] [rbp-88h]
  __int64 v47; // [rsp+30h] [rbp-80h] BYREF
  __int64 v48; // [rsp+38h] [rbp-78h] BYREF
  std::__shared_weak_count *v49; // [rsp+40h] [rbp-70h]
  void *v50; // [rsp+48h] [rbp-68h]
  _QWORD v51[4]; // [rsp+50h] [rbp-60h] BYREF
  RBX::Profiler *v52; // [rsp+70h] [rbp-40h]

  v46 = a3; /*0x1074dcb3a*/
  RBX::LoggingProtocolCore::sharedInstance(this: (RBX::LoggingProtocolCore *)&v48); /*0x1074dcb59*/
  RBX::LoggingProtocolCore::logEvent(a1: v48, a2: "datamodel_init_begin", a3: 20); /*0x1074dcb70*/
  v5 = v49; /*0x1074dcb75*/
  if ( v49 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v49 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1074dcb8e*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x1074dcb96*/
    std::__shared_weak_count::__release_weak(this: v5); /*0x1074dcb9c*/
  }
  if ( DFInt::Dev_TTIPreTestPauseMs > 0 ) /*0x1074dcba8*/
  {
    RBX::LoggingProtocolCore::sharedInstance(this: (RBX::LoggingProtocolCore *)&v48); /*0x1074dcbb2*/
    RBX::LoggingProtocolCore::logEvent(a1: v48, a2: "tti_pretest_pause_begin", a3: 23); /*0x1074dcbc9*/
    v6 = v49; /*0x1074dcbce*/
    if ( v49 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v49 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1074dcbe7*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(a1: v6); /*0x1074dcbef*/
      std::__shared_weak_count::__release_weak(this: v6); /*0x1074dcbf5*/
    }
    if ( DFInt::Dev_TTIPreTestPauseMs > 0 ) /*0x1074dcc04*/
    {
      v48 = 1000000LL * DFInt::Dev_TTIPreTestPauseMs; /*0x1074dcc11*/
      std::this_thread::sleep_for(a1: &v48); /*0x1074dcc14*/
    }
    RBX::LoggingProtocolCore::sharedInstance(this: (RBX::LoggingProtocolCore *)&v48); /*0x1074dcc1d*/
    RBX::LoggingProtocolCore::logEvent(a1: v48, a2: "tti_pretest_pause_end", a3: 21); /*0x1074dcc34*/
    v7 = v49; /*0x1074dcc39*/
    if ( v49 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v49 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1074dcc52*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(a1: v7); /*0x1074dcc5a*/
      std::__shared_weak_count::__release_weak(this: v7); /*0x1074dcc60*/
    }
  }
  RBX::EngineIntegration::createFullEngineContext(a1: &v48, a2: 1u); /*0x1074dcc6e*/
  v8 = v48; /*0x1074dcc7b*/
  v48 = 0; /*0x1074dcc7e*/
  std::unique_ptr<RBX::EngineContext,RBX::EngineContextDeleter>::reset[abi:ne200100](a1: (__int64 *)(a1 + 32), a2: v8); /*0x1074dcc88*/
  std::unique_ptr<RBX::EngineContext,RBX::EngineContextDeleter>::reset[abi:ne200100](a1: &v48, a2: 0); /*0x1074dcc92*/
  v9 = *(_QWORD *)(a1 + 32); /*0x1074dcc97*/
  std::string::basic_string[abi:ne200100]<0>(a1: &v48, a2: *(_QWORD *)(a1 + 16), a3: v10, a4: v11); /*0x1074dcca3*/
  RBX::EngineContext::setAttribute(a1: v9, a2: 0, a3: (__int64)&v48); /*0x1074dccb1*/
  if ( (v48 & 1) != 0 ) /*0x1074dccba*/
    operator delete(a1: v50); /*0x1074dccc0*/
  v12 = *(_QWORD *)(a1 + 32); /*0x1074dccc5*/
  RBX::DataModelManager::create( /*0x1074dcce6*/
    a1: &v48,
    a2: 1,
    a3: *v46,
    a4: *((unsigned int *)v46 + 1),
    a5: a2,
    a6: *(_QWORD *)(a1 + 16));
  v13 = v48; /*0x1074dcceb*/
  v48 = 0; /*0x1074dccef*/
  v47 = v13; /*0x1074dccfb*/
  RBX::EngineContext::startUpOrCrash(a1: v12, a2: &v47); /*0x1074dcd01*/
  v14 = v47; /*0x1074dcd06*/
  v47 = 0; /*0x1074dcd0a*/
  if ( v14 != 0 ) /*0x1074dcd15*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v14 + 8LL))(a1: v14); /*0x1074dcd1a*/
  v15 = v48; /*0x1074dcd1d*/
  v48 = 0; /*0x1074dcd21*/
  if ( v15 != 0 ) /*0x1074dcd2c*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 8LL))(a1: v15); /*0x1074dcd31*/
  RBX::EngineContext::getDataModel(this: (RBX::EngineContext *)&v48, a2: *(_QWORD *)(a1 + 32)); /*0x1074dcd3c*/
  v16 = (rbx::signals::slots_holder **)(v48 + 1128); /*0x1074dcd47*/
  v17 = (unsigned int)RBX::Memory::InstanceSignal; /*0x1074dcd52*/
  v19 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)(unsigned int)RBX::Memory::InstanceSignal, a2: v18); /*0x1074dcd5d*/
  v43 = a1; /*0x1074dcd60*/
  rbx::lazyInitSlotsHolder(a1: v16); /*0x1074dcd6a*/
  v21 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v20); /*0x1074dcd79*/
  *(_QWORD *)v21 = &_mh_execute_header; /*0x1074dcd86*/
  *((_QWORD *)v21 + 1) = rbx::signals::slot_with_functor<RBX::ExperienceContextHolder::initializeContext(RBX::DataModelInitializationParams const&,RBX::IExperienceContextHolder::Settings const&)::$_1>::do_call; /*0x1074dcd90*/
  *((_OWORD *)v21 + 1) = 0; /*0x1074dcd97*/
  v22 = *v16; /*0x1074dcd9c*/
  *((_QWORD *)v21 + 4) = *v16; /*0x1074dcd9f*/
  if ( v22 != nullptr ) /*0x1074dcda6*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v22 + 1); /*0x1074dcda8*/
    v23 = *((_QWORD *)v21 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x1074dcdb0*/
    v24 = *v16; /*0x1074dcdb4*/
  }
  else
  {
    v24 = nullptr; /*0x1074dcdb9*/
    v23 = 0; /*0x1074dcdbb*/
  }
  *((_QWORD *)v21 + 3) = v23; /*0x1074dcdbd*/
  rbx::signals::slots_holder::insert(this: v24, a2: (unsigned __int64)v21); /*0x1074dcdc4*/
  _InterlockedIncrement(v21 + 1); /*0x1074dcdd0*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v19, a2: v25); /*0x1074dcdd7*/
  if ( _InterlockedDecrement(v21 + 1) == 0 ) /*0x1074dcde0*/
    rbx::signals::slot_base::operator delete(a1: (void *)v21); /*0x1074dcde5*/
  v27 = (rbx::signals::slots_holder **)(v48 + 1112); /*0x1074dcdf0*/
  v28 = RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v17, a2: v26); /*0x1074dcdfc*/
  rbx::lazyInitSlotsHolder(a1: v27); /*0x1074dce02*/
  v30 = (volatile signed __int32 *)rbx::signals::slot_base::operator new(this: (rbx::signals::slot_base *)0x30, a2: v29); /*0x1074dce11*/
  *(_QWORD *)v30 = &_mh_execute_header; /*0x1074dce14*/
  *((_QWORD *)v30 + 1) = rbx::signals::slot_with_functor<RBX::ExperienceContextHolder::initializeContext(RBX::DataModelInitializationParams const&,RBX::IExperienceContextHolder::Settings const&)::$_2>::do_call; /*0x1074dce1e*/
  *((_OWORD *)v30 + 1) = 0; /*0x1074dce26*/
  v31 = *v27; /*0x1074dce2c*/
  *((_QWORD *)v30 + 4) = *v27; /*0x1074dce2f*/
  if ( v31 != nullptr ) /*0x1074dce37*/
  {
    _InterlockedIncrement((volatile signed __int32 *)v31 + 1); /*0x1074dce39*/
    v32 = *((_QWORD *)v30 + 3) & 0xFFFFFFFFFFFFFFFBLL; /*0x1074dce42*/
    v33 = *v27; /*0x1074dce46*/
  }
  else
  {
    v33 = nullptr; /*0x1074dce4b*/
    v32 = 0; /*0x1074dce4d*/
  }
  *((_QWORD *)v30 + 3) = v32; /*0x1074dce4f*/
  rbx::signals::slots_holder::insert(this: v33, a2: (unsigned __int64)v30); /*0x1074dce57*/
  _InterlockedIncrement(v30 + 1); /*0x1074dce63*/
  RBX::Memory::setCurrentCategory(this: (RBX::Memory *)v28, a2: v34); /*0x1074dce69*/
  if ( _InterlockedDecrement(v30 + 1) == 0 ) /*0x1074dce71*/
    rbx::signals::slot_base::operator delete(a1: (void *)v30); /*0x1074dce76*/
  *(_OWORD *)&v51[1] = *(_OWORD *)v46; /*0x1074dce8d*/
  LODWORD(v51[3]) = *((_DWORD *)v46 + 4); /*0x1074dce95*/
  v51[0] = off_10CB48B30; /*0x1074dcea0*/
  v52 = (RBX::Profiler *)v51; /*0x1074dcea3*/
  RBX::DataModel::submitTask(a1: v48, a2: v51, a3: 1); /*0x1074dceaf*/
  v35 = v43; /*0x1074dceb4*/
  v36 = v52; /*0x1074dcebb*/
  if ( v52 == (RBX::Profiler *)v51 ) /*0x1074dcec2*/
  {
    v37 = 32; /*0x1074dced0*/
  }
  else
  {
    v37 = 40; /*0x1074dcec4*/
    if ( v52 == nullptr ) /*0x1074dcecc*/
      goto LABEL_34; /*0x1074dcecc*/
  }
  (*(void (**)(void))(*(_QWORD *)v52 + v37))(); /*0x1074dced8*/
LABEL_34:
  if ( *((_DWORD *)v46 + 1) != 3 ) /*0x1074dcee6*/
  {
    v42 = RBX::Network::initWithPlayerSecurity; /*0x1074dceef*/
    if ( RBX::ExperienceContextHolder::initializeContext(RBX::DataModelInitializationParams const&,RBX::IExperienceContextHolder::Settings const&)::flag != -1 ) /*0x1074dcf01*/
    {
      v44 = &v42; /*0x1074dcf11*/
      v41 = &v44; /*0x1074dcf1b*/
      std::__call_once( /*0x1074dcf2c*/
        a1: (volatile unsigned __int64 *)&RBX::ExperienceContextHolder::initializeContext(RBX::DataModelInitializationParams const&,RBX::IExperienceContextHolder::Settings const&)::flag,
        a2: &v41,
        a3: std::__call_once_proxy[abi:ne200100]<std::tuple<void (*&&)(void)>>);
    }
  }
  if ( FFlag::DebugStartMicroProfilerWebServer == 1 ) /*0x1074dcf3b*/
    RBX::Profiler::startWebServer(this: v36); /*0x1074dcf3d*/
  RBX::LoggingProtocolCore::sharedInstance(this: (RBX::LoggingProtocolCore *)&v44); /*0x1074dcf49*/
  RBX::LoggingProtocolCore::logEvent(a1: v44, a2: "datamodel_init_end", a3: 18); /*0x1074dcf63*/
  v38 = v45; /*0x1074dcf68*/
  if ( v45 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v45 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1074dcf84*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v38 + 16LL))(a1: v38); /*0x1074dcf8c*/
    std::__shared_weak_count::__release_weak(this: v38); /*0x1074dcf92*/
  }
  *(_DWORD *)(v35 + 24) = 1; /*0x1074dcf97*/
  v39 = v49; /*0x1074dcf9e*/
  if ( v49 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v49 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1074dcfb7*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v39 + 16LL))(a1: v39); /*0x1074dcfbf*/
    std::__shared_weak_count::__release_weak(this: v39); /*0x1074dcfc5*/
  }
  return __stack_chk_guard; /*0x1074dcfda*/
}

// Address: 0x1074dd0ce | Name: __ZTv0_n64_N3RBX23ExperienceContextHolder17initializeContextERKNS_29DataModelInitializationParamsERKNS_24IExperienceContextHolder8SettingsE
__int64 __fastcall `virtual thunk to'RBX::ExperienceContextHolder::initializeContext(
        _QWORD *a1,
        __int64 a2,
        unsigned __int8 *a3)
{
  return RBX::ExperienceContextHolder::initializeContext(a1: (__int64)a1 + *(_QWORD *)(*a1 - 64LL), a2, a3); /*0x1074dd0d9*/
}

// Address: 0x1074dd0e0 | Name: __ZN3RBX23ExperienceContextHolder10runContextEb
__int64 __fastcall RBX::ExperienceContextHolder::runContext(RBX::ExperienceContextHolder *this, char a2)
{
  unsigned int StudioGameStateType; // eax
  RobloxInput *RobloxInputForGameStateType; // rax
  DataModelServices *v6; // rdi
  DataModelServices *DataModelServices; // rax
  std::__shared_weak_count *v8; // r14
  __int64 v9; // rax
  std::__shared_weak_count *v10; // r15
  std::__shared_weak_count *v11; // rbx
  _BYTE v13[16]; // [rsp+10h] [rbp-90h] BYREF
  std::__shared_weak_count *v14[2]; // [rsp+20h] [rbp-80h] BYREF
  __int64 v15; // [rsp+30h] [rbp-70h] BYREF
  volatile signed __int64 *v16; // [rsp+38h] [rbp-68h]
  RBX::DataModel *v17[2]; // [rsp+40h] [rbp-60h] BYREF
  _QWORD v18[4]; // [rsp+50h] [rbp-50h] BYREF
  _QWORD *v19; // [rsp+70h] [rbp-30h]

  (*(void (__fastcall **)(RBX::DataModel **, RBX::ExperienceContextHolder *))(*(_QWORD *)this + 24LL))( /*0x1074dd10e*/
    a1: v17,
    a2: this);
  if ( ((unsigned __int8)FFlag::CEVNullDataModelGuard & (v17[0] == nullptr)) == 1 ) /*0x1074dd127*/
  {
    if ( (unsigned __int8)FLog::ExperienceContextHolder >= 6u && (FLog::ExperienceContextHolder & 0xFE00) != 0 ) /*0x1074dd13d*/
    {
      v15 = 0; /*0x1074dd14f*/
      v16 = (volatile signed __int64 *)v13; /*0x1074dd15e*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x1074dd182*/
        a1: FLog::ExperienceContextHolder,
        a2: qword_10D824900,
        a3: 2,
        a4: (unsigned int)"[FLog::ExperienceContextHolder] DM is null and cannot run.",
        a5: 58,
        a6: 1,
        0,
        v13);
    }
    goto LABEL_22; /*0x1074dd187*/
  }
  if ( a2 != 0 && DFFlag::PauseSurfaceControllerBeforeSwappingDataModel == 0 ) /*0x1074dd198*/
  {
    StudioGameStateType = RBX::DataModel::getStudioGameStateType(this: v17[0]); /*0x1074dd19a*/
    RobloxInputForGameStateType = (RobloxInput *)RobloxInput::getRobloxInputForGameStateType(a1: StudioGameStateType); /*0x1074dd1a1*/
    RobloxInput::setDataModelToCurrent(this: RobloxInputForGameStateType, a2: v17[0]); /*0x1074dd1ad*/
    DataModelServices = (DataModelServices *)DataModelServices::getDataModelServices(this: v6); /*0x1074dd1b2*/
    *(_OWORD *)v14 = *(_OWORD *)v17; /*0x1074dd1bf*/
    if ( v17[1] != nullptr ) /*0x1074dd1c6*/
      _InterlockedIncrement64((volatile signed __int64 *)v17[1] + 1); /*0x1074dd1c8*/
    DataModelServices::setDataModelToCurrent(this: DataModelServices, a2: (__int64 *)v14); /*0x1074dd1d4*/
    v8 = v14[1]; /*0x1074dd1d9*/
    if ( v14[1] != nullptr /*0x1074dd1f2*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(a1: v8); /*0x1074dd1fa*/
      std::__shared_weak_count::__release_weak(this: v8); /*0x1074dd200*/
    }
  }
  v18[0] = off_10CB48BB0; /*0x1074dd214*/
  v19 = v18; /*0x1074dd217*/
  RBX::DataModel::submitTask(a1: v17[0], a2: v18, a3: 1); /*0x1074dd223*/
  if ( v19 == v18 ) /*0x1074dd22f*/
  {
    v9 = 32; /*0x1074dd23d*/
  }
  else
  {
    v9 = 40; /*0x1074dd231*/
    if ( v19 == nullptr ) /*0x1074dd239*/
      goto LABEL_16; /*0x1074dd239*/
  }
  (*(void (**)(void))(*v19 + v9))(); /*0x1074dd245*/
LABEL_16:
  if ( *((_QWORD *)this + 5) == 0 ) /*0x1074dd24d*/
  {
    _ZNSt3__115allocate_sharedB8ne200100IN3RBX14EventBroadcast5RelayENS_9allocatorIS3_EEJELi0EEENS_10shared_ptrIT_EERKT0_DpOT1_( /*0x1074dd25a*/
      a1: &v15,
      a2: v13);
    std::shared_ptr<RBX::EventBroadcast::Relay>::operator=[abi:ne200100](a1: (char *)this + 40, a2: &v15); /*0x1074dd26d*/
    v10 = (std::__shared_weak_count *)v16; /*0x1074dd272*/
    if ( v16 != nullptr && _InterlockedExchangeAdd64(v16 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1074dd28b*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(a1: v10); /*0x1074dd293*/
      std::__shared_weak_count::__release_weak(this: v10); /*0x1074dd299*/
    }
    RBX::EventBroadcast::Relay::attachToDm(a1: *((_QWORD *)this + 5), a2: v17); /*0x1074dd2a5*/
  }
  *((_DWORD *)this + 6) = 2; /*0x1074dd2aa*/
LABEL_22:
  v11 = v17[1]; /*0x1074dd2b1*/
  if ( v17[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v17[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1074dd2ca*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(a1: v11); /*0x1074dd2d2*/
    std::__shared_weak_count::__release_weak(this: v11); /*0x1074dd2d8*/
  }
  return __stack_chk_guard; /*0x1074dd2ed*/
}

// Address: 0x1074dd398 | Name: __ZTv0_n72_N3RBX23ExperienceContextHolder10runContextEb
__int64 __fastcall `virtual thunk to'RBX::ExperienceContextHolder::runContext(
        RBX::ExperienceContextHolder *this,
        char a2)
{
  return RBX::ExperienceContextHolder::runContext( /*0x1074dd3a3*/
           this: (RBX::ExperienceContextHolder *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 72LL)),
           a2);
}

// Address: 0x1074dd3aa | Name: __ZN3RBX23ExperienceContextHolder12pauseContextEv
__int64 __fastcall RBX::ExperienceContextHolder::pauseContext(RBX::ExperienceContextHolder *this)
{
  __int64 v2; // rax
  std::__shared_weak_count *v3; // rbx
  _BYTE v5[16]; // [rsp+10h] [rbp-80h] BYREF
  __int64 v6; // [rsp+20h] [rbp-70h]
  _BYTE *v7; // [rsp+28h] [rbp-68h]
  __int64 v8; // [rsp+30h] [rbp-60h] BYREF
  std::__shared_weak_count *v9; // [rsp+38h] [rbp-58h]
  _QWORD v10[4]; // [rsp+40h] [rbp-50h] BYREF
  _QWORD *v11; // [rsp+60h] [rbp-30h]

  (*(void (__fastcall **)(__int64 *, RBX::ExperienceContextHolder *))(*(_QWORD *)this + 24LL))(a1: &v8, a2: this); /*0x1074dd3d3*/
  if ( v8 != 0 ) /*0x1074dd3dd*/
  {
    v10[0] = off_10CB48C80; /*0x1074dd3ea*/
    v11 = v10; /*0x1074dd3ed*/
    RBX::DataModel::submitTask(a1: v8, a2: v10, a3: 1); /*0x1074dd3f9*/
    if ( v11 == v10 ) /*0x1074dd405*/
    {
      v2 = 32; /*0x1074dd46c*/
    }
    else
    {
      v2 = 40; /*0x1074dd407*/
      if ( v11 == nullptr ) /*0x1074dd40f*/
        goto LABEL_9; /*0x1074dd40f*/
    }
    (*(void (**)(void))(*v11 + v2))(); /*0x1074dd474*/
LABEL_9:
    *((_DWORD *)this + 6) = 3; /*0x1074dd477*/
    goto LABEL_10; /*0x1074dd477*/
  }
  if ( (unsigned __int8)FLog::ExperienceContextHolder >= 6u && (FLog::ExperienceContextHolder & 0xFE00) != 0 ) /*0x1074dd427*/
  {
    v6 = 0; /*0x1074dd435*/
    v7 = v5; /*0x1074dd441*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x1074dd465*/
      a1: FLog::ExperienceContextHolder,
      a2: qword_10D824900,
      a3: 2,
      a4: (unsigned int)"[FLog::ExperienceContextHolder] DM is null and cannot pause.",
      a5: 60,
      a6: 1,
      0,
      v5);
  }
LABEL_10:
  v3 = v9; /*0x1074dd47e*/
  if ( v9 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v9 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1074dd497*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(a1: v3); /*0x1074dd49f*/
    std::__shared_weak_count::__release_weak(this: v3); /*0x1074dd4a5*/
  }
  return __stack_chk_guard; /*0x1074dd4ba*/
}

// Address: 0x1074dd508 | Name: __ZTv0_n80_N3RBX23ExperienceContextHolder12pauseContextEv
__int64 __fastcall `virtual thunk to'RBX::ExperienceContextHolder::pauseContext(RBX::ExperienceContextHolder *this)
{
  return RBX::ExperienceContextHolder::pauseContext(this: (RBX::ExperienceContextHolder *)((char *)this /*0x1074dd513*/
                                                                                         + *(_QWORD *)(*(_QWORD *)this - 80LL)));
}

// Address: 0x1074dd51a | Name: __ZN3RBX23ExperienceContextHolder15finalizeContextEbNSt3__18functionIFvvEEE
__int64 __fastcall RBX::ExperienceContextHolder::finalizeContext(__int64 a1, char a2, __int64 a3)
{
  int v6; // edx
  RBX *v7; // rdi
  volatile signed __int64 *v8; // r15
  __int64 v9; // rdi
  __int64 v10; // rdi
  std::__shared_weak_count *v11; // r12
  __int64 v12; // rax
  _QWORD *v13; // r13
  __int64 v14; // rax
  __int64 v15; // rax
  std::__shared_weak_count *v16; // rbx
  _BYTE v18[16]; // [rsp+10h] [rbp-D0h] BYREF
  __int64 v19; // [rsp+20h] [rbp-C0h]
  _BYTE *v20; // [rsp+28h] [rbp-B8h]
  std::__shared_weak_count *v21[2]; // [rsp+30h] [rbp-B0h] BYREF
  __int64 v22; // [rsp+40h] [rbp-A0h]
  _BYTE v23[32]; // [rsp+50h] [rbp-90h] BYREF
  _BYTE *v24; // [rsp+70h] [rbp-70h]
  _BYTE v25[32]; // [rsp+80h] [rbp-60h] BYREF
  _BYTE *v26; // [rsp+A0h] [rbp-40h]

  (*(void (__fastcall **)(std::__shared_weak_count **, __int64))(*(_QWORD *)a1 + 24LL))(a1: v21, a2: a1); /*0x1074dd552*/
  v7 = v21[0]; /*0x1074dd555*/
  if ( v21[0] != nullptr ) /*0x1074dd55f*/
  {
    if ( *(_DWORD *)(a1 + 24) != 0 ) /*0x1074dd569*/
    {
      if ( *(_QWORD *)(a1 + 40) != 0 ) /*0x1074dd576*/
      {
        RBX::EventBroadcast::Relay::detachFromDm(this: *(RBX::EventBroadcast::Relay **)(a1 + 40)); /*0x1074dd57b*/
        std::shared_ptr<RBX::EventBroadcast::Relay>::reset[abi:ne200100](a1: a1 + 40); /*0x1074dd584*/
        v7 = v21[0]; /*0x1074dd589*/
      }
      RBX::setScriptShutdownTimeout( /*0x1074dd599*/
        this: v7,
        a2: (RBX::DataModel *)(unsigned int)DFInt::ScriptContextShutdownTimeoutSeconds,
        a3: v6);
      if ( a2 != 0 ) /*0x1074dd5a1*/
      {
        v8 = (volatile signed __int64 *)v21[1]; /*0x1074dd5aa*/
        *(_OWORD *)v21 = 0; /*0x1074dd5b1*/
        if ( v8 != nullptr && _InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1074dd5cd*/
        {
          (*(void (__fastcall **)(volatile signed __int64 *))(*v8 + 16))(a1: v8); /*0x1074dd5d5*/
          std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v8); /*0x1074dd5db*/
        }
        (*(void (__fastcall **)(_QWORD, _QWORD))(**(_QWORD **)(a1 + 32) + 16LL))(a1: *(_QWORD *)(a1 + 32), a2: 0); /*0x1074dd5e9*/
        std::unique_ptr<RBX::EngineContext,RBX::EngineContextDeleter>::reset[abi:ne200100]( /*0x1074dd5f2*/
          a1: (__int64 *)(a1 + 32),
          a2: 0);
        if ( FFlag::FixNotCallingCallbackAfterBlockingDMDestroy == 1 ) /*0x1074dd5fe*/
        {
          v9 = *(_QWORD *)(a3 + 32); /*0x1074dd604*/
          if ( v9 != 0 ) /*0x1074dd60b*/
            (*(void (__fastcall **)(__int64))(*(_QWORD *)v9 + 48LL))(a1: v9); /*0x1074dd614*/
        }
        goto LABEL_28; /*0x1074dd617*/
      }
      v11 = v21[0]; /*0x1074dd700*/
      v12 = *(_QWORD *)(a1 + 32); /*0x1074dd707*/
      *(_QWORD *)(a1 + 32) = 0; /*0x1074dd70e*/
      v22 = v12; /*0x1074dd719*/
      std::__function::__value_func<void ()(void)>::__value_func[abi:ne200100](a1: v23, a2: a3); /*0x1074dd723*/
      v26 = nullptr; /*0x1074dd728*/
      v13 = (_QWORD *)operator new(a1: 0x50u); /*0x1074dd736*/
      *v13 = &off_10CB48D00; /*0x1074dd740*/
      v13[2] = v22; /*0x1074dd74b*/
      std::__function::__value_func<void ()(void)>::__value_func[abi:ne200100](a1: v13 + 4, a2: v23); /*0x1074dd759*/
      v26 = v13; /*0x1074dd762*/
      RBX::DataModel::submitTask(a1: v11, a2: v25, a3: 1); /*0x1074dd771*/
      if ( v26 == v25 ) /*0x1074dd77d*/
      {
        v14 = 32; /*0x1074dd78b*/
      }
      else
      {
        v14 = 40; /*0x1074dd77f*/
        if ( v26 == nullptr ) /*0x1074dd787*/
        {
LABEL_23:
          if ( v24 == v23 ) /*0x1074dd79d*/
          {
            v15 = 32; /*0x1074dd7ab*/
          }
          else
          {
            v15 = 40; /*0x1074dd79f*/
            if ( v24 == nullptr ) /*0x1074dd7a7*/
              goto LABEL_28; /*0x1074dd7a7*/
          }
          (*(void (**)(void))(*(_QWORD *)v24 + v15))(); /*0x1074dd7b3*/
LABEL_28:
          *(_DWORD *)(a1 + 24) = 0; /*0x1074dd7b6*/
          goto LABEL_29; /*0x1074dd7b6*/
        }
      }
      (*(void (**)(void))(*(_QWORD *)v26 + v14))(); /*0x1074dd793*/
      goto LABEL_23; /*0x1074dd793*/
    }
    if ( (unsigned __int8)FLog::ExperienceContextHolder >= 6u && (FLog::ExperienceContextHolder & 0xFE00) != 0 ) /*0x1074dd699*/
    {
      v19 = 0; /*0x1074dd6a7*/
      v20 = v18; /*0x1074dd6b9*/
      FLog::detail::FastLogSafeFormattedInternal( /*0x1074dd6e3*/
        a1: FLog::ExperienceContextHolder,
        a2: qword_10D824900,
        a3: 2,
        a4: (unsigned int)"[FLog::ExperienceContextHolder] DM has not been initialized and cannot be destroyed.",
        a5: 84,
        a6: 1,
        0,
        v18);
    }
  }
  else if ( (unsigned __int8)FLog::ExperienceContextHolder >= 6u && (FLog::ExperienceContextHolder & 0xFE00) != 0 ) /*0x1074dd630*/
  {
    v19 = 0; /*0x1074dd642*/
    v20 = v18; /*0x1074dd654*/
    FLog::detail::FastLogSafeFormattedInternal( /*0x1074dd67e*/
      a1: FLog::ExperienceContextHolder,
      a2: qword_10D824900,
      a3: 2,
      a4: (unsigned int)"[FLog::ExperienceContextHolder] DM is null and cannot be destroyed.",
      a5: 67,
      a6: 1,
      0,
      v18);
  }
  v10 = *(_QWORD *)(a3 + 32); /*0x1074dd6e8*/
  if ( v10 != 0 ) /*0x1074dd6ef*/
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v10 + 48LL))(a1: v10); /*0x1074dd6f8*/
LABEL_29:
  v16 = v21[1]; /*0x1074dd7bd*/
  if ( v21[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v21[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x1074dd7d9*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v16 + 16LL))(a1: v16); /*0x1074dd7e1*/
    std::__shared_weak_count::__release_weak(this: v16); /*0x1074dd7e7*/
  }
  return __stack_chk_guard; /*0x1074dd7fc*/
}

// Address: 0x1074dd8bc | Name: __ZTv0_n88_N3RBX23ExperienceContextHolder15finalizeContextEbNSt3__18functionIFvvEEE
__int64 __fastcall `virtual thunk to'RBX::ExperienceContextHolder::finalizeContext(_QWORD *a1, char a2, __int64 a3)
{
  return RBX::ExperienceContextHolder::finalizeContext(a1: (__int64)a1 + *(_QWORD *)(*a1 - 88LL), a2, a3); /*0x1074dd8c7*/
}

// Address: 0x1087b52f2 | Name: __ZN3RBX23ExperienceContextHolder17initializeContextERKNS_29DataModelInitializationParamsERKNS_24IExperienceContextHolder8SettingsE.cold.1
_QWORD *__fastcall RBX::ExperienceContextHolder::initializeContext(_QWORD *a1)
{
  _QWORD *result; // rax
  __int64 v2; // rdi

  result = a1; /*0x1087b52f2*/
  v2 = *a1; /*0x1087b52f5*/
  *result = 0; /*0x1087b52f8*/
  if ( v2 != 0 ) /*0x1087b52ff*/
    return (_QWORD *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v2 + 8LL))(a1: v2); /*0x1087b5308*/
  return result; /*0x1087b530c*/
}

// END ExperienceContextHolder part 1/1, 24 functions
