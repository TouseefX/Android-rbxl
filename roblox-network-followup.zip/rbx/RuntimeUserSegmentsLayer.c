// RuntimeUserSegmentsLayer -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 17 functions


// Address: 0x104ac11e0 | Name: __ZN3RBX24RuntimeUserSegmentsLayer34activePayerStatusToAnalyticsStringENS_24RuntimeActivePayerStatusE
const char *__fastcall RBX::RuntimeUserSegmentsLayer::activePayerStatusToAnalyticsString(char a1)
{
  unsigned __int8 v1; // di

  v1 = a1 - 1; /*0x104ac11e4*/
  if ( v1 > 4u ) /*0x104ac11eb*/
    return "Unknown"; /*0x104ac120c*/
  else
    return off_10C998D98[v1]; /*0x104ac1206*/
}

// Address: 0x104ac121a | Name: __ZN3RBX24RuntimeUserSegmentsLayer36whenUserFirstPlayedToAnalyticsStringENS_26RuntimeWhenUserFirstPlayedE
const char *__fastcall RBX::RuntimeUserSegmentsLayer::whenUserFirstPlayedToAnalyticsString(char a1)
{
  unsigned __int8 v1; // di

  v1 = a1 - 1; /*0x104ac121e*/
  if ( v1 > 4u ) /*0x104ac1225*/
    return "AccountAge0Day"; /*0x104ac1246*/
  else
    return off_10C998DC0[v1]; /*0x104ac1240*/
}

// Address: 0x104ac1254 | Name: __ZN3RBX24RuntimeUserSegmentsLayer44playerPlatformSpenderStatusToAnalyticsStringENS_34RuntimePlayerPlatformSpenderStatusE
const char *__fastcall RBX::RuntimeUserSegmentsLayer::playerPlatformSpenderStatusToAnalyticsString(int a1)
{
  if ( a1 == 1 ) /*0x104ac125b*/
    return "ActiveSpender"; /*0x104ac1270*/
  if ( a1 == 2 ) /*0x104ac1260*/
    return "OtherSpender"; /*0x104ac1262*/
  return "Unknown"; /*0x104ac128a*/
}

// Address: 0x104ac128c | Name: __ZN3RBX24RuntimeUserSegmentsLayer43experienceActivationStatusToAnalyticsStringENS_33RuntimeExperienceActivationStatusE
const char *__fastcall RBX::RuntimeUserSegmentsLayer::experienceActivationStatusToAnalyticsString(char a1)
{
  unsigned __int8 v1; // di

  v1 = a1 - 1; /*0x104ac1290*/
  if ( v1 > 3u ) /*0x104ac1297*/
    return "Unknown"; /*0x104ac12b8*/
  else
    return off_10C998D38[v1]; /*0x104ac12b2*/
}

// Address: 0x104ac12c6 | Name: __ZN3RBX24RuntimeUserSegmentsLayer32engagementLevelToAnalyticsStringENS_22RuntimeEngagementLevelE
const char *__fastcall RBX::RuntimeUserSegmentsLayer::engagementLevelToAnalyticsString(char a1)
{
  unsigned __int8 v1; // di

  v1 = a1 - 1; /*0x104ac12ca*/
  if ( v1 > 3u ) /*0x104ac12d1*/
    return "Unknown"; /*0x104ac12f2*/
  else
    return off_10C998D58[v1]; /*0x104ac12ec*/
}

// Address: 0x104ac1300 | Name: __ZN3RBX24RuntimeUserSegmentsLayer47playerPlatformActivationStatusToAnalyticsStringENS_37RuntimePlayerPlatformActivationStatusE
const char *__fastcall RBX::RuntimeUserSegmentsLayer::playerPlatformActivationStatusToAnalyticsString(char a1)
{
  unsigned __int8 v1; // di

  v1 = a1 - 1; /*0x104ac1304*/
  if ( v1 > 3u ) /*0x104ac130b*/
    return "Unknown"; /*0x104ac132c*/
  else
    return off_10C998D78[v1]; /*0x104ac1326*/
}

// Address: 0x104ac133a | Name: __ZN3RBX24RuntimeUserSegmentsLayer33userReturnStatusToAnalyticsStringENS_23RuntimeUserReturnStatusE
const char *__fastcall RBX::RuntimeUserSegmentsLayer::userReturnStatusToAnalyticsString(int a1)
{
  if ( a1 == 1 ) /*0x104ac1341*/
    return "New"; /*0x104ac1356*/
  if ( a1 == 2 ) /*0x104ac1346*/
    return "Returning"; /*0x104ac1348*/
  return "Unknown"; /*0x104ac1370*/
}

// Address: 0x104ac1372 | Name: __ZN3RBX24RuntimeUserSegmentsLayer38userAcquisitionSourceToAnalyticsStringENS_28RuntimeUserAcquisitionSourceE
const char *__fastcall RBX::RuntimeUserSegmentsLayer::userAcquisitionSourceToAnalyticsString(char a1)
{
  unsigned __int8 v1; // di

  v1 = a1 - 1; /*0x104ac1376*/
  if ( v1 > 9u ) /*0x104ac137d*/
    return "Unknown"; /*0x104ac139e*/
  else
    return (char *)dword_109712598 + dword_109712598[v1]; /*0x104ac1399*/
}

// Address: 0x104ac1ade | Name: __ZN3RBX24RuntimeUserSegmentsLayer15requestSegmentsExxNSt3__18weak_ptrINS_9DataModelEEENS1_8functionIFvRKNS0_6ResultEEEE
void __fastcall RBX::RuntimeUserSegmentsLayer::requestSegments(
        RBX::RuntimeUserSegmentsLayer *a1,
        __int64 a2,
        __int64 a3,
        __int128 *a4,
        __int64 a5)
{
  __int64 v9; // rax
  __int64 v10; // rdi
  __int64 v11; // rdi
  __int64 v12; // r15
  __int128 v13; // xmm0
  std::__shared_weak_count *v14; // rdi
  __int64 v15; // r8
  __int64 v16; // rsi
  __int64 v17; // rax
  _QWORD v18[2]; // [rsp+0h] [rbp-60h] BYREF
  std::__shared_weak_count *v19[2]; // [rsp+10h] [rbp-50h]
  __int64 v20; // [rsp+28h] [rbp-38h] BYREF
  _BYTE v21[41]; // [rsp+37h] [rbp-29h] BYREF

  v20 = a2; /*0x104ac1af2*/
  if ( a2 <= 0 ) /*0x104ac1af9*/
  {
    v11 = *(_QWORD *)(a5 + 32); /*0x104ac1b38*/
    if ( v11 != 0 ) /*0x104ac1b3f*/
    {
      v18[0] = 0; /*0x104ac1b49*/
      LOBYTE(v18[1]) = 0; /*0x104ac1b50*/
      (*(void (__fastcall **)(__int64, _QWORD *))(*(_QWORD *)v11 + 48LL))(a1: v11, a2: v18); /*0x104ac1b57*/
    }
  }
  else
  {
    v9 = std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>>>::find<long long>( /*0x104ac1b0f*/
           a1: (char *)a1 + 16,
           a2: &v20);
    if ( v9 != 0 ) /*0x104ac1b17*/
    {
      v10 = *(_QWORD *)(a5 + 32); /*0x104ac1b19*/
      if ( v10 != 0 ) /*0x104ac1b20*/
        (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v10 + 48LL))(a1: v10, a2: v9 + 24); /*0x104ac1b30*/
    }
    else
    {
      v18[0] = &v20; /*0x104ac1b67*/
      v12 = std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>>>::__emplace_unique_key_args<long long,std::piecewise_construct_t const&,std::tuple<long long const&>,std::tuple<>>( /*0x104ac1b7d*/
              a1: (char *)a1 + 56,
              a2: &v20,
              a3: std::piecewise_construct,
              a4: v18,
              a5: v21);
      *(_QWORD *)(v12 + 40) = a3; /*0x104ac1b80*/
      v13 = *a4; /*0x104ac1b84*/
      *a4 = 0; /*0x104ac1b8c*/
      v14 = *(std::__shared_weak_count **)(v12 + 56); /*0x104ac1b91*/
      *(_OWORD *)(v12 + 48) = v13; /*0x104ac1b95*/
      if ( v14 != nullptr ) /*0x104ac1b9c*/
        std::__shared_weak_count::__release_weak(this: v14); /*0x104ac1b9e*/
      if ( *(_QWORD *)(a5 + 32) != 0 ) /*0x104ac1ba8*/
        std::vector<std::function<void ()(RBX::RuntimeUserSegmentsLayer::Result const&)>>::push_back[abi:ne200100]( /*0x104ac1bb4*/
          a1: v12 + 64,
          a2: a5);
      if ( *(_BYTE *)(v12 + 24) == 0 ) /*0x104ac1bbe*/
      {
        *(_BYTE *)(v12 + 24) = 1; /*0x104ac1bc0*/
        v15 = *((_QWORD *)a1 + 12); /*0x104ac1bc5*/
        *((_QWORD *)a1 + 12) = v15 + 1; /*0x104ac1bcd*/
        *(_QWORD *)(v12 + 32) = v15; /*0x104ac1bd1*/
        v16 = v20; /*0x104ac1bd5*/
        v17 = *(_QWORD *)(v12 + 56); /*0x104ac1bdd*/
        *(_OWORD *)v19 = *(_OWORD *)(v12 + 48); /*0x104ac1be6*/
        if ( v17 != 0 ) /*0x104ac1bed*/
          _InterlockedIncrement64((volatile signed __int64 *)(v17 + 16)); /*0x104ac1bef*/
        RBX::RuntimeUserSegmentsLayer::beginFetch(this: a1, a2: v16); /*0x104ac1bff*/
        if ( v19[1] != nullptr ) /*0x104ac1c0b*/
          std::__shared_weak_count::__release_weak(this: v19[1]); /*0x104ac1c0d*/
      }
    }
  }
}

// Address: 0x104ac1c3a | Name: __ZN3RBX24RuntimeUserSegmentsLayer18buildUnknownResultEv
__int64 __fastcall RBX::RuntimeUserSegmentsLayer::buildUnknownResult(RBX::RuntimeUserSegmentsLayer *this)
{
  return 0; /*0x104ac1c42*/
}

// Address: 0x104ac1c7a | Name: __ZN3RBX24RuntimeUserSegmentsLayer10beginFetchExxNSt3__18weak_ptrINS_9DataModelEEEy
__int64 __fastcall RBX::RuntimeUserSegmentsLayer::beginFetch(
        RBX::RuntimeUserSegmentsLayer *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        unsigned __int64 a5,
        int a6)
{
  std::__shared_weak_count *v10; // rdi
  volatile signed __int64 *v11; // rax
  volatile signed __int64 *v12; // r12
  RBX::DataModel *v13; // rdi
  unsigned int HttpContext; // eax
  RBX::HttpRequest *v15; // rdi
  __int64 v16; // r15
  unsigned __int8 *v17; // r12
  __int64 v18; // rdx
  char *v19; // rcx
  __int64 v20; // r8
  RBX::HttpRequest *v21; // r15
  char *v22; // r14
  char *v23; // rdx
  __int64 v24; // rax
  RBX::RuntimeUserSegmentsLayer *v25; // r12
  char *v26; // rsi
  __int64 v27; // rdx
  int v28; // r9d
  RBX::HttpRequest *v29; // rcx
  __int64 v30; // rbx
  RBX::RuntimeUserSegmentsLayer *v31; // r15
  __int64 v32; // r12
  RBX::DataModel *v33; // r14
  __int64 v34; // r13
  __int64 v35; // rax
  __int64 v36; // rax
  std::__shared_weak_count *v37; // rbx
  __int128 v39; // [rsp+60h] [rbp-190h]
  unsigned int v40; // [rsp+90h] [rbp-160h]
  unsigned __int64 v41; // [rsp+98h] [rbp-158h]
  char v42[16]; // [rsp+A0h] [rbp-150h] BYREF
  __int128 v43; // [rsp+B0h] [rbp-140h]
  unsigned __int8 v44; // [rsp+C0h] [rbp-130h] BYREF
  char v45; // [rsp+C1h] [rbp-12Fh] BYREF
  __int64 v46; // [rsp+C8h] [rbp-128h]
  void *v47; // [rsp+D0h] [rbp-120h]
  unsigned __int8 v48; // [rsp+D8h] [rbp-118h] BYREF
  char v49; // [rsp+D9h] [rbp-117h] BYREF
  __int64 v50; // [rsp+E0h] [rbp-110h]
  void *v51; // [rsp+E8h] [rbp-108h]
  __int64 v52; // [rsp+F0h] [rbp-100h]
  RBX::HttpRequest *v53; // [rsp+F8h] [rbp-F8h]
  RBX::RuntimeUserSegmentsLayer *v54; // [rsp+100h] [rbp-F0h]
  RBX::HttpRequest *v55; // [rsp+108h] [rbp-E8h] BYREF
  std::__shared_weak_count *v56; // [rsp+110h] [rbp-E0h]
  RBX::HttpRequest *v57; // [rsp+118h] [rbp-D8h]
  __int128 v58; // [rsp+120h] [rbp-D0h] BYREF
  void *v59; // [rsp+130h] [rbp-C0h]
  __int64 v60; // [rsp+140h] [rbp-B0h] BYREF
  __int64 v61; // [rsp+148h] [rbp-A8h]
  void *v62; // [rsp+150h] [rbp-A0h]
  char v63; // [rsp+158h] [rbp-98h]
  __int64 *v64; // [rsp+160h] [rbp-90h]
  void *v65; // [rsp+168h] [rbp-88h]
  char v66; // [rsp+170h] [rbp-80h]
  void *v67; // [rsp+180h] [rbp-70h]
  char v68; // [rsp+188h] [rbp-68h]
  void *v69; // [rsp+198h] [rbp-58h]
  char v70; // [rsp+1A0h] [rbp-50h]
  void *v71; // [rsp+1B0h] [rbp-40h]

  if ( DFFlag::RuntimeUserSegmentsLayerFetch == 0 ) /*0x104ac1cac*/
  {
    v60 = 0; /*0x104ac1e20*/
    LOBYTE(v61) = 0; /*0x104ac1e27*/
    RBX::RuntimeUserSegmentsLayer::completeFetchSuccess( /*0x104ac1e37*/
      this,
      a2,
      a3: a5,
      a4: (const RBX::RuntimeUserSegmentsLayer::Result *)&v60,
      a5: false);
    return __stack_chk_guard; /*0x104ac1e3c*/
  }
  if ( DFInt::DebugRuntimeUserSegmentsUniverseIdOverride > 0 ) /*0x104ac1cbf*/
    a3 = DFInt::DebugRuntimeUserSegmentsUniverseIdOverride; /*0x104ac1cbf*/
  if ( a3 > 0 ) /*0x104ac1cc6*/
  {
    v43 = 0; /*0x104ac1ccf*/
    v10 = *(std::__shared_weak_count **)(a4 + 8); /*0x104ac1cd6*/
    if ( v10 != nullptr /*0x104ac1cf9*/
      && (v52 = a4,
          v11 = (volatile signed __int64 *)std::__shared_weak_count::lock(this: v10),
          *((_QWORD *)&v43 + 1) = v11,
          v11 != nullptr) )
    {
      v12 = v11; /*0x104ac1cff*/
      v13 = *(RBX::DataModel **)v52; /*0x104ac1d09*/
      *(_QWORD *)&v43 = v13; /*0x104ac1d0c*/
      if ( v13 != nullptr ) /*0x104ac1d16*/
      {
        HttpContext = RBX::DataModel::getHttpContext(this: v13); /*0x104ac1d1c*/
        RBX::HttpRequest::create(a1: &v55, a2: HttpContext); /*0x104ac1d2a*/
        v57 = (RBX::HttpRequest *)a2; /*0x104ac1d2f*/
        v41 = a5; /*0x104ac1d36*/
        v15 = v55; /*0x104ac1d3d*/
        *((_DWORD *)v55 + 129) = 26; /*0x104ac1d44*/
        RBX::HttpRequest::setMethodGet(this: v15); /*0x104ac1d4e*/
        RBX::HttpRequest::setNativeRetryEnabled(this: v55, a2: true); /*0x104ac1d5f*/
        RBX::HttpRequest::setHeader(a1: v55, a2: "robloxctx-rcc", a3: 13, a4: "true", a5: 4); /*0x104ac1d84*/
        v53 = v55; /*0x104ac1d90*/
        v40 = RBX::Http::kUniverseIdHeaderKey[0]; /*0x104ac1da2*/
        v16 = *(_QWORD *)&RBX::Http::kUniverseIdHeaderKey[8]; /*0x104ac1da9*/
        v17 = *(unsigned __int8 **)&RBX::Http::kUniverseIdHeaderKey[16]; /*0x104ac1dad*/
        *(_QWORD *)&v58 = a3; /*0x104ac1db8*/
        fmt::v8::vformat(a1: &v60, a2: "{}", a3: 2, a4: 3, a5: &v58); /*0x104ac1dd3*/
        if ( (v40 & 1) == 0 ) /*0x104ac1de9*/
        {
          v16 = v40 >> 1; /*0x104ac1de9*/
          v17 = &RBX::Http::kUniverseIdHeaderKey[1]; /*0x104ac1ded*/
        }
        v18 = v16; /*0x104ac1dfd*/
        if ( (v60 & 1) != 0 ) /*0x104ac1e00*/
        {
          v19 = (char *)v62; /*0x104ac1e06*/
          v20 = v61; /*0x104ac1e0d*/
        }
        else
        {
          v20 = (unsigned __int8)v60 >> 1; /*0x104ac1eb6*/
          v19 = (char *)&v60 + 1; /*0x104ac1eb9*/
        }
        v21 = v57; /*0x104ac1ec7*/
        RBX::HttpRequest::setHeader(a1: v53, a2: v17, a3: v18, a4: v19, a5: v20); /*0x104ac1ed1*/
        if ( (v60 & 1) != 0 ) /*0x104ac1edd*/
          operator delete(a1: v62); /*0x104ac1ee6*/
        v54 = this; /*0x104ac1ef3*/
        if ( (DFString::DebugRuntimeUserSegmentsHostOverride & 1) != 0 ) /*0x104ac1efa*/
        {
          if ( *((_QWORD *)&DFString::DebugRuntimeUserSegmentsHostOverride + 1) != 0 ) /*0x104ac1f28*/
          {
            std::string::__init_copy_ctor_external( /*0x104ac1f38*/
              a1: &v58,
              a2: qword_10D7CC658,
              a3: *((_QWORD *)&DFString::DebugRuntimeUserSegmentsHostOverride + 1));
            goto LABEL_27; /*0x104ac1f3d*/
          }
        }
        else if ( (_BYTE)DFString::DebugRuntimeUserSegmentsHostOverride != 0 ) /*0x104ac1efe*/
        {
          v59 = (void *)qword_10D7CC658; /*0x104ac1f07*/
          v58 = DFString::DebugRuntimeUserSegmentsHostOverride; /*0x104ac1f15*/
          goto LABEL_27; /*0x104ac1f1c*/
        }
        getRobloxApisHost(); /*0x104ac1f46*/
LABEL_27:
        *(_QWORD *)v42 = v21; /*0x104ac1f4b*/
        fmt::v8::vformat(a1: &v48, a2: "/user-segmentation-api/v1/players/{}/segments", a3: 45, a4: 3, a5: v42); /*0x104ac1f83*/
        v22 = (char *)&v58 + 1; /*0x104ac1f98*/
        if ( (v48 & 1) != 0 ) /*0x104ac1faf*/
        {
          v23 = (char *)v51; /*0x104ac1fb1*/
          v24 = v50; /*0x104ac1fb8*/
        }
        else
        {
          v24 = v48 >> 1; /*0x104ac1fc1*/
          v23 = &v49; /*0x104ac1fc3*/
        }
        v25 = v54; /*0x104ac1fca*/
        *(_QWORD *)v42 = v23; /*0x104ac1fd1*/
        *(_QWORD *)&v42[8] = v24; /*0x104ac1fd8*/
        RBX::Url::fromComponents(this: (RBX::Url *)&v60, a2: (char)v23, a3: v24, a4: (char)"", a5: 0, a6: (char)""); /*0x104ac203d*/
        RBX::Url::asString(this: (RBX::Url *)&v44); /*0x104ac2050*/
        if ( (v70 & 1) != 0 ) /*0x104ac2059*/
          operator delete(a1: v71); /*0x104ac205f*/
        if ( (v68 & 1) != 0 ) /*0x104ac2068*/
          operator delete(a1: v69); /*0x104ac206e*/
        if ( (v66 & 1) != 0 ) /*0x104ac2077*/
          operator delete(a1: v67); /*0x104ac207d*/
        if ( (v63 & 1) != 0 ) /*0x104ac2089*/
          operator delete(a1: v65); /*0x104ac2092*/
        if ( (v60 & 1) != 0 ) /*0x104ac209e*/
          operator delete(a1: v62); /*0x104ac20a7*/
        if ( (v48 & 1) != 0 ) /*0x104ac20b3*/
          operator delete(a1: v51); /*0x104ac20bc*/
        if ( (v44 & 1) != 0 ) /*0x104ac20d2*/
        {
          v26 = (char *)v47; /*0x104ac20d4*/
          v27 = v46; /*0x104ac20db*/
        }
        else
        {
          v27 = v44 >> 1; /*0x104ac20e4*/
          v26 = &v45; /*0x104ac20e6*/
        }
        RBX::HttpRequest::setUrl(a1: v55, a2: v26, a3: v27); /*0x104ac20ed*/
        if ( DFFlag::DebugRuntimeUserSegmentsVerbose == 1 ) /*0x104ac20f9*/
        {
          if ( (v58 & 1) != 0 ) /*0x104ac2102*/
            LODWORD(v22) = (_DWORD)v59; /*0x104ac2104*/
          RBX::CreatorLog::printf( /*0x104ac2122*/
            a1: 1,
            a2: (unsigned int)"AnalyticsService:GetPlayerSegmentsAsync request userId=%lld universeId=%lld host=%s",
            a3: (_DWORD)v21,
            a4: a3,
            a5: (_DWORD)v22,
            a6: v28);
        }
        v29 = v21; /*0x104ac2127*/
        v30 = *(_QWORD *)v25; /*0x104ac212a*/
        v31 = v25; /*0x104ac212e*/
        v32 = *((_QWORD *)v25 + 1); /*0x104ac2131*/
        if ( v32 != 0 ) /*0x104ac2139*/
          _InterlockedIncrement64((volatile signed __int64 *)(v32 + 16)); /*0x104ac213b*/
        v57 = v55; /*0x104ac2148*/
        v33 = *(RBX::DataModel **)v52; /*0x104ac216b*/
        v34 = *(_QWORD *)(v52 + 8); /*0x104ac2175*/
        *(_OWORD *)v52 = 0; /*0x104ac2183*/
        *(_QWORD *)&v39 = v29; /*0x104ac2186*/
        *((_QWORD *)&v39 + 1) = v41; /*0x104ac2194*/
        v64 = nullptr; /*0x104ac219b*/
        v35 = operator new(a1: 0x40u); /*0x104ac21ab*/
        *(_QWORD *)v35 = &off_10C998C48; /*0x104ac21be*/
        *(_QWORD *)(v35 + 8) = v31; /*0x104ac21c1*/
        *(_QWORD *)(v35 + 16) = v30; /*0x104ac21c5*/
        *(_QWORD *)(v35 + 24) = v32; /*0x104ac21c9*/
        *(_QWORD *)(v35 + 32) = v33; /*0x104ac21d3*/
        *(_QWORD *)(v35 + 40) = v34; /*0x104ac21d7*/
        *(_OWORD *)(v35 + 48) = v39; /*0x104ac21e3*/
        v64 = (__int64 *)v35; /*0x104ac21ee*/
        (**(void (__fastcall ***)(RBX::HttpRequest *, __int64 *))v57)(a1: v57, a2: &v60); /*0x104ac21ff*/
        if ( v64 == &v60 ) /*0x104ac220b*/
        {
          v36 = 32; /*0x104ac2219*/
        }
        else
        {
          v36 = 40; /*0x104ac220d*/
          if ( v64 == nullptr ) /*0x104ac2215*/
            goto LABEL_56; /*0x104ac2215*/
        }
        (*(void (**)(void))(*v64 + v36))(); /*0x104ac2221*/
LABEL_56:
        if ( (v44 & 1) != 0 ) /*0x104ac222b*/
          operator delete(a1: v47); /*0x104ac2234*/
        if ( (v58 & 1) != 0 ) /*0x104ac2240*/
          operator delete(a1: v59); /*0x104ac2249*/
        v37 = v56; /*0x104ac224e*/
        if ( v56 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v56 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104ac226a*/
        {
          (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v37 + 16LL))(a1: v37); /*0x104ac2272*/
          std::__shared_weak_count::__release_weak(this: v37); /*0x104ac2278*/
        }
        v12 = *((volatile signed __int64 **)&v43 + 1); /*0x104ac227d*/
        goto LABEL_64; /*0x104ac227d*/
      }
    }
    else
    {
      v12 = nullptr; /*0x104ac1e41*/
    }
    v60 = 0; /*0x104ac1e4b*/
    LOBYTE(v61) = 0; /*0x104ac1e52*/
    RBX::RuntimeUserSegmentsLayer::completeFetchSuccess( /*0x104ac1e62*/
      this,
      a2,
      a3: a5,
      a4: (const RBX::RuntimeUserSegmentsLayer::Result *)&v60,
      a5: false);
LABEL_64:
    if ( v12 != nullptr && _InterlockedExchangeAdd64(v12 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104ac229a*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v12 + 16))(a1: v12); /*0x104ac22a3*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v12); /*0x104ac22a9*/
    }
    return __stack_chk_guard; /*0x104ac22a9*/
  }
  if ( DFFlag::DebugRuntimeUserSegmentsVerbose == 1 ) /*0x104ac1e73*/
    RBX::CreatorLog::printf( /*0x104ac1e89*/
      a1: 2,
      a2: (unsigned int)"AnalyticsService:GetPlayerSegmentsAsync skipped fetch because universeId is not available. userId=%l"
                    "ld universeId=%lld",
      a3: a2,
      a4: a3,
      a5,
      a6);
  v60 = 0; /*0x104ac1e95*/
  LOBYTE(v61) = 0; /*0x104ac1e9c*/
  RBX::RuntimeUserSegmentsLayer::completeFetchSuccess( /*0x104ac1eac*/
    this,
    a2,
    a3: a5,
    a4: (const RBX::RuntimeUserSegmentsLayer::Result *)&v60,
    a5: false);
  return __stack_chk_guard; /*0x104ac22be*/
}

// Address: 0x104ac23b2 | Name: __ZN3RBX24RuntimeUserSegmentsLayer13evictSegmentsEx
__int64 __fastcall RBX::RuntimeUserSegmentsLayer::evictSegments(RBX::RuntimeUserSegmentsLayer *this, __int64 a2)
{
  __int64 result; // rax
  unsigned __int64 v4; // rdx
  _QWORD v5[2]; // [rsp+8h] [rbp-28h] BYREF
  __int64 v6[3]; // [rsp+18h] [rbp-18h] BYREF

  v6[0] = a2; /*0x104ac23c4*/
  std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>>>::__erase_unique<long long>( /*0x104ac23ce*/
    a1: (char *)this + 16,
    a2: v6);
  result = std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>>>::find<long long>( /*0x104ac23da*/
             a1: (char *)this + 56,
             a2: v6);
  if ( result != 0 ) /*0x104ac23e2*/
  {
    v4 = *(_QWORD *)(result + 32); /*0x104ac23e8*/
    v5[0] = 0; /*0x104ac23f0*/
    LOBYTE(v5[1]) = 0; /*0x104ac23f7*/
    return RBX::RuntimeUserSegmentsLayer::completeFetchSuccess( /*0x104ac2401*/
             this,
             a2: v6[0],
             a3: v4,
             a4: (const RBX::RuntimeUserSegmentsLayer::Result *)v5,
             a5: false);
  }
  return result; /*0x104ac2406*/
}

// Address: 0x104ac2410 | Name: __ZN3RBX24RuntimeUserSegmentsLayer20completeFetchSuccessExyRKNS0_6ResultEb
__int64 __fastcall RBX::RuntimeUserSegmentsLayer::completeFetchSuccess(
        RBX::RuntimeUserSegmentsLayer *this,
        __int64 a2,
        __int64 a3,
        const RBX::RuntimeUserSegmentsLayer::Result *a4,
        int a5)
{
  char *v8; // r13
  __int64 result; // rax
  __int64 v10; // r12
  __int64 v11; // rax
  unsigned __int64 v12; // r14
  __int64 v13; // rdi
  __int64 *v14; // [rsp+0h] [rbp-70h] BYREF
  __int64 v15; // [rsp+8h] [rbp-68h] BYREF
  __m128i v16; // [rsp+10h] [rbp-60h] BYREF
  __int64 *v17; // [rsp+20h] [rbp-50h]
  __int64 v18; // [rsp+28h] [rbp-48h] BYREF
  __m128i v19; // [rsp+30h] [rbp-40h]
  int v20; // [rsp+40h] [rbp-30h]
  _BYTE v21[41]; // [rsp+47h] [rbp-29h] BYREF

  v20 = a5; /*0x104ac2421*/
  v15 = a2; /*0x104ac2432*/
  v8 = (char *)this + 56; /*0x104ac2435*/
  result = std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>>>::find<long long>( /*0x104ac243f*/
             a1: (char *)this + 56,
             a2: &v15);
  if ( result != 0 && *(_QWORD *)(result + 32) == a3 ) /*0x104ac2451*/
  {
    v10 = *(_QWORD *)(result + 64); /*0x104ac2457*/
    v18 = v10; /*0x104ac245b*/
    v16 = _mm_loadu_si128((const __m128i *)(result + 72)); /*0x104ac2464*/
    v19 = v16; /*0x104ac2469*/
    *(_OWORD *)(result + 64) = 0; /*0x104ac2472*/
    *(_QWORD *)(result + 80) = 0; /*0x104ac2477*/
    std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>>>::erase( /*0x104ac2485*/
      a1: v8,
      a2: result);
    if ( (_BYTE)v20 != 0 ) /*0x104ac248e*/
    {
      v14 = &v15; /*0x104ac2498*/
      v11 = std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>>>::__emplace_unique_key_args<long long,std::piecewise_construct_t const&,std::tuple<long long const&>,std::tuple<>>( /*0x104ac24ac*/
              a1: (char *)this + 16,
              a2: &v15,
              a3: std::piecewise_construct,
              a4: &v14,
              a5: v21);
      *(_BYTE *)(v11 + 32) = *((_BYTE *)a4 + 8); /*0x104ac24b4*/
      *(_QWORD *)(v11 + 24) = *(_QWORD *)a4; /*0x104ac24ba*/
      v10 = v18; /*0x104ac24be*/
      v12 = v19.i64[0]; /*0x104ac24c2*/
    }
    else
    {
      v12 = _mm_load_si128(&v16).u64[0]; /*0x104ac24cd*/
    }
    while ( v10 != v12 ) /*0x104ac24ee*/
    {
      v13 = *(_QWORD *)(v10 + 32); /*0x104ac24d4*/
      if ( v13 != 0 ) /*0x104ac24dc*/
        (*(void (__fastcall **)(__int64, const RBX::RuntimeUserSegmentsLayer::Result *))(*(_QWORD *)v13 + 48LL))( /*0x104ac24e4*/
          a1: v13,
          a2: a4);
      v10 += 48; /*0x104ac24e7*/
    }
    v17 = &v18; /*0x104ac24f8*/
    return std::vector<std::function<void ()(RBX::RuntimeUserSegmentsLayer::Result const&)>>::__destroy_vector::operator()[abi:ne200100](); /*0x104ac24fb*/
  }
  return result; /*0x104ac2500*/
}

// Address: 0x104ac252c | Name: __ZN3RBX24RuntimeUserSegmentsLayer5resetEv
__int64 __fastcall RBX::RuntimeUserSegmentsLayer::reset(RBX::RuntimeUserSegmentsLayer *this)
{
  __int64 v2; // rax
  std::__shared_weak_count *v3; // r14
  __int64 v5; // [rsp+0h] [rbp-20h] BYREF
  volatile signed __int64 *v6; // [rsp+8h] [rbp-18h]

  v2 = operator new(a1: 0x20u); /*0x104ac253f*/
  *(_OWORD *)(v2 + 8) = 0; /*0x104ac2547*/
  *(_QWORD *)v2 = &off_10C9FBD70; /*0x104ac2556*/
  *(_DWORD *)(v2 + 24) = 0; /*0x104ac255d*/
  v5 = v2 + 24; /*0x104ac2568*/
  v6 = (volatile signed __int64 *)v2; /*0x104ac256b*/
  std::shared_ptr<int>::operator=[abi:ne200100](a1: this, a2: &v5); /*0x104ac2575*/
  v3 = (std::__shared_weak_count *)v6; /*0x104ac257a*/
  if ( v6 != nullptr && _InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x104ac2593*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(a1: v3); /*0x104ac259b*/
    std::__shared_weak_count::__release_weak(this: v3); /*0x104ac25a1*/
  }
  std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>>>::clear(a1: (char *)this + 16); /*0x104ac25aa*/
  return std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>>>::clear(a1: (char *)this + 56); /*0x104ac25bb*/
}

// Address: 0x104ac260e | Name: __ZNK3RBX24RuntimeUserSegmentsLayer15getCachedResultEx
__int64 __fastcall RBX::RuntimeUserSegmentsLayer::getCachedResult(RBX::RuntimeUserSegmentsLayer *this, __int64 a2)
{
  __int64 v2; // rax
  __int64 v4; // [rsp+8h] [rbp-8h] BYREF

  v4 = a2; /*0x104ac261a*/
  v2 = std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>>>::find<long long>( /*0x104ac2624*/
         a1: (char *)this + 16,
         a2: &v4);
  if ( v2 != 0 ) /*0x104ac262c*/
    return *(_QWORD *)(v2 + 24); /*0x104ac2631*/
  else
    return 0; /*0x104ac2643*/
}

// Address: 0x104ac264c | Name: __ZZN3RBX24RuntimeUserSegmentsLayer10beginFetchExxNSt3__18weak_ptrINS_9DataModelEEEyEN3$_0D1Ev
__int64 __fastcall RBX::RuntimeUserSegmentsLayer::beginFetch(long long,long long,std::weak_ptr<RBX::DataModel>,unsigned long long)::$_0::~$_0(
        __int64 a1)
{
  std::__shared_weak_count *v2; // rdi
  __int64 result; // rax
  std::__shared_weak_count *v4; // rdi

  v2 = *(std::__shared_weak_count **)(a1 + 32); /*0x104ac2655*/
  if ( v2 != nullptr ) /*0x104ac265c*/
    result = std::__shared_weak_count::__release_weak(this: v2); /*0x104ac265e*/
  v4 = *(std::__shared_weak_count **)(a1 + 16); /*0x104ac2663*/
  if ( v4 != nullptr ) /*0x104ac266e*/
    return std::__shared_weak_count::__release_weak(this: v4); /*0x104ac2672*/
  return result; /*0x104ac2670*/
}

// Address: 0x10554b75a | Name: __ZN3RBX24RuntimeUserSegmentsLayerD1Ev
void __fastcall RBX::RuntimeUserSegmentsLayer::~RuntimeUserSegmentsLayer(RBX::RuntimeUserSegmentsLayer *this)
{
  std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::RequestRecord>>>::~__hash_table(a1: (char *)this + 56); /*0x10554b767*/
  std::__hash_table<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::__unordered_map_hasher<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::hash<long long>,std::equal_to<long long>,true>,std::__unordered_map_equal<long long,std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>,std::equal_to<long long>,std::hash<long long>,true>,std::allocator<std::__hash_value_type<long long,RBX::RuntimeUserSegmentsLayer::Result>>>::~__hash_table(a1: (char *)this + 16); /*0x10554b770*/
  std::shared_ptr<int>::~shared_ptr[abi:ne200100](a1: this); /*0x10554b77e*/
}

// END RuntimeUserSegmentsLayer part 1/1, 17 functions
