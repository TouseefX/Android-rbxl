// AtlasAllocator -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 26 functions


// Address: 0x105015a9a | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator16buildSimdBitmaskEjPNS2_11SimdBitmaskE
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::buildSimdBitmask(unsigned int a1, __int64 a2)
{
  __int64 v3; // rax
  unsigned __int64 v4; // rdx
  __m128i v5; // xmm0
  __int64 result; // rax
  __int128 v7; // rt0
  _QWORD v8[3]; // [rsp+8h] [rbp-18h] BYREF

  v8[0] = 0; /*0x105015aaa*/
  v8[1] = 1; /*0x105015ab1*/
  v3 = RBX::Graphics::Shadows::AtlasAllocator::uint128_t::operator<<(a1: v8, a2: a1); /*0x105015abe*/
  v5 = _mm_unpacklo_epi64((__m128i)((__PAIR128__(v3, v4) - 1) >> 64), (__m128i)(v4 - 1)); /*0x105015ad5*/
  for ( result = 0; result != 2048; result += 16 ) /*0x105015ad9*/
  {
    *(__m128i *)(a2 + result) = v5; /*0x105015adb*/
    *((_QWORD *)&v7 + 1) = v5.i64[0]; /*0x105015aec*/
    *(_QWORD *)&v7 = _mm_extract_epi64(v5, 1); /*0x105015aec*/
    v5 = _mm_unpacklo_epi64((__m128i)(unsigned __int64)(v7 >> 63), (__m128i)(unsigned __int64)(2 * v7)); /*0x105015afe*/
  }
  return result; /*0x105015b0e*/
}

// Address: 0x105015b16 | Name: __ZNK3RBX8Graphics7Shadows14AtlasAllocator9uint128_tlsEy
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::uint128_t::operator<<(_QWORD *a1, unsigned __int64 a2)
{
  if ( a2 > 0x7F ) /*0x105015b1e*/
    return 0; /*0x105015b22*/
  if ( a2 == 0 ) /*0x105015b29*/
    return *a1; /*0x105015b37*/
  if ( a2 == 64 ) /*0x105015b2f*/
    return a1[1]; /*0x105015b31*/
  if ( a2 >= 0x40 ) /*0x105015b40*/
    return a1[1] << a2; /*0x105015b66*/
  return (*a1 << a2) + (a1[1] >> -(char)a2); /*0x105015b6b*/
}

// Address: 0x105015b6e | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator14invalidChartIdEv
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::invalidChartId(RBX::Graphics::Shadows::AtlasAllocator *this)
{
  return 0xFFFFFFFFLL; /*0x105015b77*/
}

// Address: 0x105015b7a | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocatorC2Ev
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::AtlasAllocator(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        __int64 a2,
        unsigned __int64 a3)
{
  _QWORD *v4; // r14
  __int64 Aligned; // r15
  unsigned __int64 v6; // rdx
  __int64 v7; // r15
  __int64 v8; // r12
  __int64 i; // r15
  __int64 result; // rax

  *(_QWORD *)this = 0; /*0x105015b8d*/
  *(_OWORD *)((char *)this + 1048584) = 0; /*0x105015b93*/
  *((_QWORD *)this + 131075) = 0; /*0x105015b9a*/
  v4 = (_QWORD *)((char *)this + 1048672); /*0x105015ba1*/
  *(_OWORD *)((char *)this + 1048616) = 0; /*0x105015ba8*/
  *(_OWORD *)((char *)this + 1048648) = 0; /*0x105015baf*/
  *(_OWORD *)((char *)this + 1048664) = 0; /*0x105015bb6*/
  *((_QWORD *)this + 131076) = 1; /*0x105015bbd*/
  *((_WORD *)this + 524316) = 1; /*0x105015bc8*/
  *((_DWORD *)this + 262159) = 0; /*0x105015bd1*/
  *((_BYTE *)this + 1048640) = 0; /*0x105015bdb*/
  Aligned = RBX::Memory::allocateAligned(this: (RBX::Memory *)0x1000, a2: 0x10u, a3); /*0x105015bf1*/
  __bzero(a1: Aligned, a2: 4096); /*0x105015bfc*/
  std::unique_ptr<RBX::Graphics::Shadows::AtlasAllocator::Bitmap,RBX::Graphics::Shadows::AtlasAllocator::SimdAlignedDeleter>::reset[abi:ne200100]( /*0x105015c07*/
    a1: this,
    a2: Aligned);
  v7 = RBX::Memory::allocateAligned(this: (RBX::Memory *)0x40000, a2: 0x10u, a3: v6); /*0x105015c1b*/
  __bzero(a1: v7, a2: 0x40000); /*0x105015c26*/
  std::unique_ptr<RBX::Graphics::Shadows::AtlasAllocator::SimdBitmasks,RBX::Graphics::Shadows::AtlasAllocator::SimdAlignedDeleter>::reset[abi:ne200100]( /*0x105015c31*/
    a1: v4,
    a2: v7);
  v8 = 0; /*0x105015c36*/
  for ( i = 0; i != 128; ++i ) /*0x105015c39*/
  {
    result = RBX::Graphics::Shadows::AtlasAllocator::buildSimdBitmask(a1: i, a2: v8 + *v4); /*0x105015c45*/
    v8 += 2048; /*0x105015c4d*/
  }
  return result; /*0x105015c61*/
}

// Address: 0x105015d0c | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocatorC1Ev
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::AtlasAllocator(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        __int64 a2,
        unsigned __int64 a3)
{
  return RBX::Graphics::Shadows::AtlasAllocator::AtlasAllocator(this, a2, a3); /*0x105015d10*/
}

// Address: 0x105015d16 | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocatorD2Ev
void __fastcall RBX::Graphics::Shadows::AtlasAllocator::~AtlasAllocator(RBX::Graphics::Shadows::AtlasAllocator *this)
{
  void *v2; // rdi
  void *v3; // rdi

  std::unique_ptr<RBX::Graphics::Shadows::AtlasAllocator::SimdBitmasks,RBX::Graphics::Shadows::AtlasAllocator::SimdAlignedDeleter>::reset[abi:ne200100]( /*0x105015d28*/
    a1: (char *)this + 1048672,
    a2: 0);
  v2 = *((void **)this + 131081); /*0x105015d2d*/
  if ( v2 != nullptr ) /*0x105015d37*/
  {
    *((_QWORD *)this + 131082) = v2; /*0x105015d39*/
    operator delete(a1: v2); /*0x105015d40*/
  }
  v3 = *((void **)this + 131073); /*0x105015d45*/
  if ( v3 != nullptr ) /*0x105015d4f*/
  {
    *((_QWORD *)this + 131074) = v3; /*0x105015d51*/
    operator delete(a1: v3); /*0x105015d58*/
  }
  std::unique_ptr<RBX::Graphics::Shadows::AtlasAllocator::Bitmap,RBX::Graphics::Shadows::AtlasAllocator::SimdAlignedDeleter>::reset[abi:ne200100]( /*0x105015d68*/
    a1: this,
    a2: 0);
}

// Address: 0x105015d6e | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocatorD1Ev
void __fastcall RBX::Graphics::Shadows::AtlasAllocator::~AtlasAllocator(RBX::Graphics::Shadows::AtlasAllocator *this)
{
  RBX::Graphics::Shadows::AtlasAllocator::~AtlasAllocator(this); /*0x105015d73*/
}

// Address: 0x105015d78 | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator10initializeEjj
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::initialize(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        unsigned int a2,
        unsigned int a3)
{
  *((_DWORD *)this + 262154) = a2; /*0x105015d7c*/
  *((_DWORD *)this + 262155) = a3; /*0x105015d82*/
  *((_DWORD *)this + 262156) = a2 >> 5; /*0x105015d8b*/
  *((_DWORD *)this + 262157) = a3 >> 5; /*0x105015d94*/
  *((_QWORD *)this + 131076) = 1; /*0x105015d9a*/
  *((_WORD *)this + 524316) = 1; /*0x105015da5*/
  return RBX::Graphics::Shadows::AtlasAllocator::clear(this); /*0x105015dae*/
}

// Address: 0x105015db4 | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator5clearEv
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::clear(RBX::Graphics::Shadows::AtlasAllocator *this)
{
  __int64 v2; // rdi
  __int16 v3; // cx
  int v4; // r12d
  __int64 result; // rax
  __int64 i; // rcx
  _WORD v7[17]; // [rsp+Eh] [rbp-22h] BYREF

  v2 = *(_QWORD *)this; /*0x105015dc6*/
  v3 = 1; /*0x105015dd5*/
  if ( (__int16)(*((_WORD *)this + 524316) + 1) >= 0 ) /*0x105015dda*/
    v3 = *((_WORD *)this + 524316) + 1; /*0x105015dda*/
  *((_WORD *)this + 524316) = v3; /*0x105015ddd*/
  __bzero(a1: v2, a2: 4096); /*0x105015de9*/
  std::vector<unsigned short>::reserve(a1: (char *)this + 1048584, a2: 0x8000); /*0x105015dfd*/
  *((_QWORD *)this + 131074) = *((_QWORD *)this + 131073); /*0x105015e09*/
  v4 = 0x8000; /*0x105015e10*/
  do /*0x105015e30*/
  {
    v7[0] = --v4; /*0x105015e1d*/
    std::vector<unsigned short>::push_back[abi:ne200100](a1: (char *)this + 1048584, a2: v7); /*0x105015e28*/
  }
  while ( v4 != 0 ); /*0x105015e30*/
  result = (__int64)this + 8; /*0x105015e32*/
  for ( i = 0; i != 0x100000; i += 32 ) /*0x105015e36*/
  {
    *(_OWORD *)(result + i + 11) = 0; /*0x105015e3b*/
    *(_OWORD *)(result + i) = 0; /*0x105015e40*/
  }
  *((_BYTE *)this + 1048640) = 0; /*0x105015e51*/
  return result; /*0x105015e58*/
}

// Address: 0x105015e66 | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator9clearFastEv
unsigned __int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::clearFast(
        RBX::Graphics::Shadows::AtlasAllocator *this)
{
  __int16 v2; // cx
  _OWORD *v3; // rax
  unsigned __int64 v4; // rcx
  char *v5; // rdi
  __int64 v6; // r13
  unsigned __int64 result; // rax
  __int64 v8; // r12
  _OWORD *v9; // rax
  __int64 v10; // r14
  __int64 v11; // rcx
  __int64 v12; // rcx
  __int16 v13; // r15
  __m128i v14; // xmm1
  __m128i v15; // xmm2
  __m128i v16; // xmm3
  __m128i v17; // xmm4
  __int64 v18; // rdx
  __m128i si128; // xmm5
  __m128i v20; // xmm0
  __m128i v21; // xmm7
  __m128i v22; // xmm8
  __m128i v23; // xmm10
  __m128i v24; // xmm9
  __m128i v25; // xmm8
  __m128i v26; // xmm10
  __m128i v27; // xmm11
  __m128i v28; // xmm8
  __m128i v29; // xmm8
  __m128i v30; // xmm9
  __m128i v31; // xmm10
  __m128i v32; // xmm8
  __m128i v33; // xmm9
  __m128i v34; // xmm10
  __m128i v35; // xmm11
  __m128i v36; // xmm11
  __m128i v37; // xmm8
  __m128i v38; // xmm8
  __m128i v39; // xmm10
  __m128i v40; // xmm9
  __m128i v41; // xmm8
  __m128i v42; // xmm10
  __m128i v43; // xmm11
  __m128i v44; // xmm8
  __m128i v45; // xmm8
  __m128i v46; // xmm9
  __m128i v47; // xmm10
  __m128i v48; // xmm8
  __m128i v49; // xmm9
  __m128i v50; // xmm10
  __m128i v51; // xmm11
  __m128i v52; // xmm11
  __m128i v53; // xmm8

  v2 = 1; /*0x105015e83*/
  if ( (__int16)(*((_WORD *)this + 524316) + 1) >= 0 ) /*0x105015e88*/
    v2 = *((_WORD *)this + 524316) + 1; /*0x105015e88*/
  *((_WORD *)this + 524316) = v2; /*0x105015e8b*/
  if ( *((_DWORD *)this + 262157) != 0 ) /*0x105015e99*/
  {
    v3 = *(_OWORD **)this; /*0x105015e9b*/
    v4 = 0; /*0x105015e9e*/
    do /*0x105015eb8*/
    {
      *v3 = 0; /*0x105015ea4*/
      ++v4; /*0x105015ea8*/
      ++v3; /*0x105015eb1*/
    }
    while ( v4 < *((unsigned int *)this + 262157) ); /*0x105015eb8*/
  }
  v5 = (char *)this + 1048584; /*0x105015eba*/
  v6 = *((_QWORD *)this + 131074) - *((_QWORD *)this + 131073); /*0x105015ec8*/
  if ( v6 == 0x10000 ) /*0x105015ed6*/
  {
    result = std::vector<unsigned short>::resize(a1: v5, a2: 0x8000); /*0x105015edd*/
  }
  else
  {
    v8 = 0x8000 - (v6 >> 1); /*0x105015ef3*/
    v9 = (_OWORD *)((char *)this + 8); /*0x105015ef6*/
    v10 = (v6 >> 1 == 0x8000) + v8; /*0x105015f01*/
    v11 = v10; /*0x105015f09*/
    do /*0x105015f1c*/
    {
      *(_OWORD *)((char *)v9 + 11) = 0; /*0x105015f0c*/
      *v9 = 0; /*0x105015f11*/
      v9 += 2; /*0x105015f15*/
      --v11; /*0x105015f19*/
    }
    while ( v11 != 0 ); /*0x105015f1c*/
    std::vector<unsigned short>::resize(a1: v5, a2: 0x8000); /*0x105015f27*/
    result = (v10 + 7) & 0xFFFFFFFFFFFFFFF8LL; /*0x105015f37*/
    v12 = v6 + *((_QWORD *)this + 131073) + 14; /*0x105015f4b*/
    v13 = (v6 >> 1) ^ 0x7FFF; /*0x105015f4f*/
    v14 = _mm_cvtepi8_epi64(1798); /*0x105015f56*/
    v15 = _mm_cvtepi8_epi64(1284); /*0x105015f5f*/
    v16 = _mm_cvtepi8_epi64(770); /*0x105015f68*/
    v17 = _mm_cvtepi8_epi64(256); /*0x105015f71*/
    v18 = 0; /*0x105015f7a*/
    si128 = _mm_load_si128((const __m128i *)&xmmword_108F246C0); /*0x105015f7c*/
    v20 = _mm_xor_si128(_mm_shuffle_epi32((__m128i)(unsigned __int64)(v10 - 1), 68), si128); /*0x105015f84*/
    v21 = _mm_cvtepi8_epi64(2056); /*0x105015f8c*/
    do /*0x10501623d*/
    {
      v22 = _mm_xor_si128(v17, si128); /*0x105015f9a*/
      v23 = _mm_cmpgt_epi32(v22, v20); /*0x105015fa4*/
      v24 = _mm_shuffle_epi32(v23, 160); /*0x105015fa9*/
      v25 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v22, v20), 245); /*0x105015fba*/
      v26 = _mm_shuffle_epi32(v23, 245); /*0x105015fcb*/
      v27 = _mm_xor_si128( /*0x105015fdc*/
              _mm_or_si128(
                _mm_shufflelo_epi16(v26, 232),
                _mm_and_si128(_mm_shufflelo_epi16(v25, 232), _mm_shufflelo_epi16(v24, 232))),
              (__m128i)-1LL);
      if ( (_mm_cvtsi128_si32(_mm_packs_epi32(v27, v27)) & 1) != 0 ) /*0x105015fef*/
        *(_WORD *)(v12 + 2 * v18 - 14) = v13; /*0x105015ff1*/
      v28 = _mm_or_si128(_mm_and_si128(v25, v24), v26); /*0x105015ffc*/
      v29 = _mm_xor_si128(_mm_packs_epi32(v28, v28), (__m128i)-1LL); /*0x105016006*/
      if ( (_mm_extract_epi8(_mm_packs_epi32(v29, v29), 2) & 1) != 0 ) /*0x10501601b*/
        *(_WORD *)(v12 + 2 * v18 - 12) = v8 + (v18 ^ 0xFFFE); /*0x105016028*/
      v30 = _mm_xor_si128(v16, si128); /*0x105016032*/
      v31 = _mm_cmpgt_epi32(v30, v20); /*0x10501603c*/
      v32 = _mm_shuffle_epi32(v31, 160); /*0x105016041*/
      v33 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v30, v20), 245); /*0x10501604c*/
      v34 = _mm_shuffle_epi32(v31, 245); /*0x10501605c*/
      v35 = _mm_or_si128(_mm_and_si128(v33, v32), v34); /*0x105016062*/
      v36 = _mm_xor_si128(_mm_packs_epi32(v35, v35), (__m128i)-1LL); /*0x10501606c*/
      if ( (_mm_extract_epi8(_mm_packs_epi32(v36, v36), 4) & 1) != 0 ) /*0x105016081*/
        *(_WORD *)(v12 + 2 * v18 - 10) = v8 + (v18 ^ 0xFFFD); /*0x10501608e*/
      v37 = _mm_xor_si128( /*0x1050160af*/
              _mm_or_si128(
                _mm_shufflehi_epi16(v34, 132),
                _mm_and_si128(_mm_shufflehi_epi16(v33, 132), _mm_shufflehi_epi16(v32, 132))),
              (__m128i)-1LL);
      if ( (_mm_extract_epi8(_mm_packs_epi32(v37, v37), 6) & 1) != 0 ) /*0x1050160c4*/
        *(_WORD *)(v12 + 2 * v18 - 8) = v8 + (v18 ^ 0xFFFC); /*0x1050160d1*/
      v38 = _mm_xor_si128(v15, si128); /*0x1050160db*/
      v39 = _mm_cmpgt_epi32(v38, v20); /*0x1050160e5*/
      v40 = _mm_shuffle_epi32(v39, 160); /*0x1050160ea*/
      v41 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v38, v20), 245); /*0x1050160fb*/
      v42 = _mm_shuffle_epi32(v39, 245); /*0x10501610c*/
      v43 = _mm_xor_si128( /*0x10501611d*/
              _mm_or_si128(
                _mm_shufflelo_epi16(v42, 232),
                _mm_and_si128(_mm_shufflelo_epi16(v41, 232), _mm_shufflelo_epi16(v40, 232))),
              (__m128i)-1LL);
      if ( (_mm_extract_epi8(_mm_packs_epi32(v43, v43), 8) & 1) != 0 ) /*0x105016132*/
        *(_WORD *)(v12 + 2 * v18 - 6) = v8 + (v18 ^ 0xFFFB); /*0x10501613f*/
      v44 = _mm_or_si128(_mm_and_si128(v41, v40), v42); /*0x105016149*/
      v45 = _mm_xor_si128(_mm_packs_epi32(v44, v44), (__m128i)-1LL); /*0x105016153*/
      if ( (_mm_extract_epi8(_mm_packs_epi32(v45, v45), 10) & 1) != 0 ) /*0x105016168*/
        *(_WORD *)(v12 + 2 * v18 - 4) = v8 + (v18 ^ 0xFFFA); /*0x105016175*/
      v46 = _mm_xor_si128(v14, si128); /*0x10501617f*/
      v47 = _mm_cmpgt_epi32(v46, v20); /*0x105016189*/
      v48 = _mm_shuffle_epi32(v47, 160); /*0x10501618e*/
      v49 = _mm_shuffle_epi32(_mm_cmpeq_epi32(v46, v20), 245); /*0x105016199*/
      v50 = _mm_shuffle_epi32(v47, 245); /*0x1050161a9*/
      v51 = _mm_or_si128(_mm_and_si128(v49, v48), v50); /*0x1050161af*/
      v52 = _mm_xor_si128(_mm_packs_epi32(v51, v51), (__m128i)-1LL); /*0x1050161b9*/
      if ( (_mm_extract_epi8(_mm_packs_epi32(v52, v52), 12) & 1) != 0 ) /*0x1050161ce*/
        *(_WORD *)(v12 + 2 * v18 - 2) = v8 + (v18 ^ 0xFFF9); /*0x1050161db*/
      v53 = _mm_xor_si128( /*0x1050161fc*/
              _mm_or_si128(
                _mm_shufflehi_epi16(v50, 132),
                _mm_and_si128(_mm_shufflehi_epi16(v49, 132), _mm_shufflehi_epi16(v48, 132))),
              (__m128i)-1LL);
      if ( (_mm_extract_epi8(_mm_packs_epi32(v53, v53), 14) & 1) != 0 ) /*0x105016211*/
        *(_WORD *)(v12 + 2 * v18) = v8 + (v18 ^ 0xFFF8); /*0x10501621e*/
      v18 += 8; /*0x105016222*/
      v17 = _mm_add_epi64(v17, v21); /*0x105016226*/
      v16 = _mm_add_epi64(v16, v21); /*0x10501622a*/
      v15 = _mm_add_epi64(v15, v21); /*0x10501622e*/
      v14 = _mm_add_epi64(v14, v21); /*0x105016232*/
      v13 -= 8; /*0x105016236*/
    }
    while ( result != v18 ); /*0x10501623d*/
  }
  *((_BYTE *)this + 1048640) = 0; /*0x105016243*/
  return result; /*0x10501624e*/
}

// Address: 0x10501625c | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator14alignChartSizeEj
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::alignChartSize(RBX::Graphics::Shadows::AtlasAllocator *this)
{
  return ((_DWORD)this + 31) & 0xFFFFFFE0; /*0x105016266*/
}

// Address: 0x105016268 | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator12allocateImplEjj
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::allocateImpl(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        int a2,
        __int64 a3)
{
  unsigned int v3; // r8d
  unsigned int v4; // ebx
  __int64 v5; // r11
  int v6; // r15d
  unsigned int v7; // ecx
  __int64 v8; // r10
  unsigned int v9; // r13d
  __int64 v10; // r11
  __int64 v11; // rax
  __int64 v12; // rdx
  __m128i si128; // xmm0
  unsigned int v14; // eax
  unsigned int v15; // edx
  int v16; // r9d
  unsigned int v17; // ecx
  __int64 v18; // rdx
  bool v19; // zf
  __int64 v20; // r11
  __int64 v21; // rbx
  __int64 v22; // r8
  __int64 v23; // r9
  __int64 v24; // rdx
  __int64 v25; // r8
  int v26; // r9d
  __int64 v27; // r10
  int v28; // r8d
  __int16 v29; // cx
  __int64 v31; // [rsp-8h] [rbp-8h]

  v3 = -1; /*0x105016272*/
  if ( ((a2 + 31) & 0xFFFFFFE0) > *((_DWORD *)this + 262154) ) /*0x10501627e*/
    return v3; /*0x10501627e*/
  v4 = a3 + 31; /*0x105016291*/
  if ( (((_DWORD)a3 + 31) & 0xFFFFFFE0) > *((_DWORD *)this + 262155) ) /*0x10501629f*/
    return v3; /*0x10501629f*/
  v5 = (unsigned int)(a2 + 31) >> 5; /*0x1050162a5*/
  v6 = *((_DWORD *)this + 262156) - v5; /*0x1050162b0*/
  v7 = v6 + 1; /*0x1050162b6*/
  if ( v6 == -1 ) /*0x1050162b8*/
    return v3; /*0x1050162b8*/
  *(&v31 - 8) = a3; /*0x1050162be*/
  v8 = *(_QWORD *)this; /*0x1050162c2*/
  v9 = *((_DWORD *)this + 262157) - (v4 >> 5) + 1; /*0x1050162d6*/
  v10 = *((_QWORD *)this + 131084) + (v5 << 11); /*0x1050162dd*/
  *(&v31 - 7) = (__int64)this + 8; /*0x1050162e8*/
  v11 = *((unsigned int *)this + 262159); /*0x1050162ec*/
  *((_DWORD *)&v31 - 11) = v4 >> 5; /*0x1050162f2*/
  v12 = 0; /*0x1050162f9*/
  *(&v31 - 10) = v11; /*0x1050162fb*/
  while ( 1 ) /*0x1050162ff*/
  {
    *(&v31 - 11) = v12; /*0x1050162ff*/
    *(&v31 - 9) = ((int)v12 + (int)v11) % v7; /*0x105016309*/
    if ( v9 != 0 ) /*0x105016310*/
      break; /*0x105016310*/
LABEL_13:
    v18 = *(&v31 - 11); /*0x10501635a*/
    v19 = (_DWORD)v18 == v6; /*0x105016361*/
    v12 = (unsigned int)(v18 + 1); /*0x105016364*/
    v11 = *(&v31 - 10); /*0x105016366*/
    if ( v19 ) /*0x10501636a*/
      return v3; /*0x10501636a*/
  }
  si128 = _mm_load_si128((const __m128i *)(v10 + 16 * *(&v31 - 9))); /*0x10501631a*/
  v14 = 0; /*0x105016320*/
  while ( 2 ) /*0x105016325*/
  {
    if ( v4 >= 0x20 ) /*0x105016325*/
    {
      v15 = v7; /*0x10501632b*/
      v16 = 0; /*0x10501632d*/
      v17 = v14; /*0x105016330*/
      while ( _mm_testz_si128(si128, *(__m128i *)(v8 + 16LL * v17)) ) /*0x105016340*/
      {
        ++v17; /*0x105016342*/
        if ( -(v4 >> 5) == --v16 ) /*0x10501634a*/
        {
          v20 = *(&v31 - 8); /*0x105016376*/
          v22 = *((unsigned int *)&v31 - 11); /*0x105016382*/
          v23 = 0; /*0x105016386*/
          v21 = *(&v31 - 7); /*0x105016389*/
          do /*0x1050163ab*/
          {
            *(__m128i *)(v8 + 16LL * (v14 + (unsigned int)v23)) = _mm_or_si128( /*0x10501639f*/
                                                                    _mm_load_si128((const __m128i *)(v8 + 16LL * (v14 + (unsigned int)v23))),
                                                                    si128);
            ++v23; /*0x1050163a5*/
          }
          while ( v22 != v23 ); /*0x1050163ab*/
          goto LABEL_19; /*0x1050163ab*/
        }
      }
      v14 = v14 - v16 + 1; /*0x105016351*/
      v7 = v15; /*0x105016356*/
      if ( v14 < v9 ) /*0x105016358*/
        continue; /*0x105016358*/
      goto LABEL_13; /*0x105016358*/
    }
    break;
  }
  v14 -= *((_DWORD *)&v31 - 11); /*0x10501643b*/
  v20 = *(&v31 - 8); /*0x10501643e*/
  v21 = *(&v31 - 7); /*0x10501637c*/
LABEL_19:
  v24 = *(&v31 - 9); /*0x1050163ad*/
  v25 = *((_QWORD *)this + 131074); /*0x1050163b6*/
  v26 = *(unsigned __int16 *)(v25 - 2); /*0x1050163bd*/
  *((_QWORD *)this + 131074) = v25 - 2; /*0x1050163c6*/
  v27 = (unsigned int)(32 * v26); /*0x1050163d3*/
  *(_DWORD *)(v21 + v27) = 32 * v24; /*0x1050163d7*/
  *(_DWORD *)(v21 + v27 + 4) = 32 * v14; /*0x1050163db*/
  *(_DWORD *)(v21 + v27 + 8) = a2; /*0x1050163e0*/
  *(_DWORD *)(v21 + v27 + 12) = v20; /*0x1050163e5*/
  v28 = *((unsigned __int16 *)this + 524316); /*0x1050163ea*/
  v29 = 1; /*0x1050163f9*/
  if ( (__int16)(v28 + 1) >= 0 ) /*0x1050163fe*/
    v29 = v28 + 1; /*0x1050163fe*/
  *((_WORD *)this + 524316) = v29; /*0x105016401*/
  *(_WORD *)(v21 + v27 + 24) = v28; /*0x105016408*/
  *(_QWORD *)(v21 + v27 + 16) = *((_QWORD *)this + 131076); /*0x105016415*/
  *(_BYTE *)(v21 + v27 + 26) = 1; /*0x10501641a*/
  *((_DWORD *)this + 262159) = v24; /*0x105016420*/
  return v26 | (unsigned int)(v28 << 16); /*0x10501643a*/
}

// Address: 0x105016448 | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator13allocateBatchERKNSt3__16vectorINS2_9ChartSizeENS3_9allocatorIS5_EEEERNS4_IiNS6_IiEEEE
unsigned __int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::allocateBatch(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        _QWORD *a2,
        _QWORD *a3)
{
  _QWORD *v3; // rbx
  RBX::Graphics::Shadows::AtlasAllocator *v4; // r13
  __int64 v5; // rsi
  __int64 v6; // r14
  char *v7; // r15
  _QWORD *v8; // rdi
  unsigned __int64 v9; // r12
  __int64 v10; // rdx
  __int64 v11; // r15
  unsigned __int64 v12; // rcx
  __int64 v13; // rax
  __int64 v14; // rsi
  __int64 v15; // rax
  __int64 v16; // rdx
  __int64 v17; // rbx
  _QWORD *v18; // r13
  __int64 v19; // rbx
  const void *v20; // rsi
  size_t v21; // rdx
  char *v22; // r13
  void *v23; // rdi
  char *v24; // rdi
  unsigned __int64 v25; // rax
  __int64 v26; // rax
  __int64 v27; // rdx
  unsigned __int64 result; // rax
  __int64 v29; // rbx
  unsigned __int64 v30; // r14
  int v31; // eax
  __int64 v32; // rsi
  RBX::Graphics::Shadows::AtlasAllocator *v33; // [rsp+8h] [rbp-48h]
  _QWORD *v35; // [rsp+18h] [rbp-38h]
  _QWORD *v36; // [rsp+20h] [rbp-30h]

  v3 = a2; /*0x105016459*/
  v4 = this; /*0x10501645c*/
  *((_QWORD *)this + 131082) = *((_QWORD *)this + 131081); /*0x105016466*/
  a3[1] = *a3; /*0x105016470*/
  std::vector<int>::resize(a1: a3, a2: (__int64)(a2[1] - *a2) >> 3); /*0x105016486*/
  v6 = *v3; /*0x10501648b*/
  v7 = *((char **)v4 + 131082); /*0x10501648e*/
  if ( v3[1] != *v3 ) /*0x105016499*/
  {
    v8 = (_QWORD *)((char *)v4 + 1048664); /*0x1050164a9*/
    v9 = 0; /*0x1050164b0*/
    v33 = v4; /*0x1050164b3*/
    v36 = (_QWORD *)((char *)v4 + 1048664); /*0x1050164b7*/
    v35 = v3; /*0x1050164bb*/
    do /*0x1050165c4*/
    {
      if ( (unsigned __int64)v7 >= *v8 ) /*0x1050164c5*/
      {
        v10 = *((_QWORD *)v4 + 131081); /*0x1050164db*/
        v11 = (__int64)&v7[-v10] >> 4; /*0x1050164e5*/
        v12 = v11 + 1; /*0x1050164e9*/
        if ( (unsigned __int64)(v11 + 1) > 0xFFFFFFFFFFFFFFFLL ) /*0x1050164f0*/
          std::vector<RBX::Graphics::Shadows::AtlasAllocator::SortedChartSize>::__throw_length_error[abi:ne200100]( /*0x10501665d*/
            a1: v8,
            a2: v5,
            a3: v10,
            a4: v12,
            a5: 0xFFFFFFFFFFFFFFFLL);
        v13 = *v8 - v10; /*0x1050164f6*/
        v14 = v13 >> 3; /*0x1050164fc*/
        if ( v13 >> 3 <= v12 ) /*0x105016503*/
          v14 = v11 + 1; /*0x105016505*/
        if ( (unsigned __int64)v13 >= 0x7FFFFFFFFFFFFFF0LL ) /*0x105016515*/
          v14 = 0xFFFFFFFFFFFFFFFLL; /*0x105016515*/
        if ( v14 != 0 ) /*0x10501651c*/
        {
          v15 = std::__allocate_at_least[abi:ne200100]<std::allocator<RBX::Graphics::Shadows::AtlasAllocator::SortedChartSize>>( /*0x10501651e*/
                  a1: v8,
                  a2: v14,
                  a3: v10,
                  a4: 0x7FFFFFFFFFFFFFF0LL,
                  a5: 0xFFFFFFFFFFFFFFFLL);
          v17 = v16; /*0x105016523*/
        }
        else
        {
          v15 = 0; /*0x105016528*/
          v17 = 0; /*0x10501652a*/
        }
        v18 = (_QWORD *)(v15 + 16 * v11); /*0x105016530*/
        v19 = v15 + 16 * v17; /*0x105016538*/
        v7 = (char *)(v18 + 2); /*0x105016542*/
        *v18 = *(_QWORD *)(v6 + 8 * v9); /*0x105016546*/
        v18[1] = v9; /*0x10501654a*/
        v20 = *((const void **)v33 + 131081); /*0x105016552*/
        v21 = *((_QWORD *)v33 + 131082) - (_QWORD)v20; /*0x105016560*/
        v22 = (char *)v18 - v21; /*0x105016563*/
        memcpy(__dst: v22, __src: v20, __n: v21); /*0x105016569*/
        v23 = *((void **)v33 + 131081); /*0x10501656e*/
        *((_QWORD *)v33 + 131081) = v22; /*0x105016575*/
        v4 = v33; /*0x10501657c*/
        *((_QWORD *)v33 + 131082) = v7; /*0x10501657f*/
        *((_QWORD *)v33 + 131083) = v19; /*0x105016586*/
        if ( v23 != nullptr ) /*0x105016590*/
          operator delete(a1: v23); /*0x105016592*/
        v3 = v35; /*0x105016597*/
        v8 = v36; /*0x1050165a5*/
      }
      else
      {
        *(_QWORD *)v7 = *(_QWORD *)(v6 + 8 * v9); /*0x1050164cb*/
        *((_QWORD *)v7 + 1) = v9; /*0x1050164ce*/
        v7 += 16; /*0x1050164d2*/
      }
      *((_QWORD *)v4 + 131082) = v7; /*0x1050165a9*/
      ++v9; /*0x1050165b0*/
      v6 = *v3; /*0x1050165b3*/
    }
    while ( v9 < (__int64)(v3[1] - *v3) >> 3 ); /*0x1050165c4*/
  }
  v24 = *((char **)v4 + 131081); /*0x1050165ca*/
  _BitScanReverse64(&v25, (v7 - v24) >> 4); /*0x1050165db*/
  v26 = (2 * ((unsigned int)v25 ^ 0x3F)) ^ 0x7ELL; /*0x1050165e4*/
  v27 = 0; /*0x1050165e8*/
  if ( v7 != v24 ) /*0x1050165ed*/
    v27 = v26; /*0x1050165ed*/
  result = std::__introsort<std::_ClassicAlgPolicy,RBX::Graphics::Shadows::AtlasAllocator::allocateBatch(std::vector<RBX::Graphics::Shadows::AtlasAllocator::ChartSize> const&,std::vector<int> &)::$_0 &,RBX::Graphics::Shadows::AtlasAllocator::SortedChartSize *,false>( /*0x1050165f9*/
             a1: v24,
             a2: v7,
             a3: v27,
             a4: 1);
  if ( *((_QWORD *)v4 + 131082) != *((_QWORD *)v4 + 131081) ) /*0x105016610*/
  {
    v29 = 0; /*0x105016612*/
    v30 = 0; /*0x105016614*/
    do /*0x10501664c*/
    {
      v31 = RBX::Graphics::Shadows::AtlasAllocator::allocate(this: v4); /*0x10501661d*/
      v32 = *((_QWORD *)v4 + 131081); /*0x105016622*/
      *(_DWORD *)(*a3 + 4LL * *(_QWORD *)(v32 + v29 + 8)) = v31; /*0x105016631*/
      ++v30; /*0x105016634*/
      result = (*((_QWORD *)v4 + 131082) - v32) >> 4; /*0x105016641*/
      v29 += 16; /*0x105016645*/
    }
    while ( v30 < result ); /*0x10501664c*/
  }
  return result; /*0x10501664e*/
}

// Address: 0x105016662 | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator8allocateERKNS2_9ChartSizeE
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::allocate(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        int *a2)
{
  int v3; // ebx
  unsigned int v4; // r14d
  __int64 result; // rax
  __int64 v6; // rcx
  char *v7; // r13
  __int64 v8; // r12
  int v9; // ebx
  __int64 v10; // rcx
  unsigned int v11; // r14d
  __int64 v12; // rcx
  char *v13; // [rsp+8h] [rbp-38h]
  unsigned int v14; // [rsp+14h] [rbp-2Ch]

  v3 = *a2; /*0x105016676*/
  v4 = a2[1]; /*0x105016678*/
  result = RBX::Graphics::Shadows::AtlasAllocator::allocateImpl(this, a2: *a2, a3: v4); /*0x105016681*/
  if ( (int)result < 0 /*0x1050166a3*/
    || (v6 = 32 * (unsigned int)(unsigned __int16)result, *(_WORD *)((char *)this + v6 + 32) != WORD1(result))
    || (*((_BYTE *)this + v6 + 34) & 1) == 0 )
  {
    v14 = v3; /*0x1050166a9*/
    v7 = (char *)this + 24; /*0x1050166b4*/
    v8 = 0; /*0x1050166b8*/
    v9 = 0; /*0x1050166bb*/
    do /*0x1050166f5*/
    {
      if ( v7[10] == 1 && *((_QWORD *)this + 131076) - *(_QWORD *)v7 >= 2u ) /*0x1050166d3*/
      {
        RBX::Graphics::Shadows::AtlasAllocator::freeImpl(a1: this, a2: (unsigned __int16)v8, a3: v7 - 16); /*0x1050166e0*/
        ++v9; /*0x1050166e5*/
      }
      ++v8; /*0x1050166e7*/
      v7 += 32; /*0x1050166ea*/
    }
    while ( v8 != 0x8000 ); /*0x1050166f5*/
    v13 = (char *)this + 8; /*0x1050166b0*/
    if ( v9 <= 0 /*0x10501672c*/
      || (int)(result = RBX::Graphics::Shadows::AtlasAllocator::allocateImpl(this, a2: v14, a3: v4)) < 0
      || (v10 = 32 * (unsigned int)(unsigned __int16)result, *(_WORD *)&v13[v10 + 24] != WORD1(result))
      || (v13[v10 + 26] & 1) == 0 )
    {
      v11 = v4 + 31; /*0x105016731*/
      result = 0xFFFFFFFFLL; /*0x105016744*/
      if ( v14 + 31 >= 0x40 && v11 >= 0x40 ) /*0x10501673f*/
      {
        result = RBX::Graphics::Shadows::AtlasAllocator::allocateImpl( /*0x10501675f*/
                   this,
                   a2: ((v14 + 31) >> 1) & 0x7FFFFFF0,
                   a3: (v11 >> 1) & 0x7FFFFFF0);
        if ( (int)result < 0 ) /*0x105016766*/
          return 0xFFFFFFFFLL; /*0x105016766*/
        v12 = 32 * (unsigned int)(unsigned __int16)result; /*0x105016770*/
        if ( *(_WORD *)&v13[v12 + 24] != WORD1(result) || (v13[v12 + 26] & 1) == 0 ) /*0x105016781*/
          return 0xFFFFFFFFLL; /*0x105016783*/
      }
    }
  }
  return result; /*0x105016788*/
}

// Address: 0x105016798 | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator19allocateBatchStrictERKNSt3__16vectorINS2_9ChartSizeENS3_9allocatorIS5_EEEERNS4_IiNS6_IiEEEE
unsigned __int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::allocateBatchStrict(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        _QWORD *a2,
        _QWORD *a3)
{
  _QWORD *v3; // rbx
  __int64 v5; // rsi
  __int64 v6; // r9
  char *v7; // r15
  _QWORD *v8; // rdi
  unsigned __int64 v9; // r12
  __int64 v10; // rdx
  __int64 v11; // r15
  unsigned __int64 v12; // rcx
  __int64 v13; // rax
  __int64 v14; // rsi
  __int64 v15; // rbx
  __int64 v16; // rax
  __int64 v17; // rdx
  __int64 v18; // rbx
  _QWORD *v19; // r13
  __int64 v20; // rbx
  const void *v21; // rsi
  size_t v22; // rdx
  char *v23; // r13
  void *v24; // rdi
  char *v25; // rdi
  unsigned __int64 v26; // rax
  __int64 v27; // rax
  __int64 v28; // rdx
  unsigned __int64 result; // rax
  __int64 v30; // rcx
  char v31; // r13
  unsigned __int64 v32; // r15
  int Impl; // eax
  char *v34; // r13
  __int64 i; // rbx
  _QWORD *v37; // [rsp+10h] [rbp-30h]

  v3 = a2; /*0x1050167a9*/
  *((_QWORD *)this + 131082) = *((_QWORD *)this + 131081); /*0x1050167b6*/
  a3[1] = *a3; /*0x1050167c0*/
  std::vector<int>::resize(a1: a3, a2: (__int64)(a2[1] - *a2) >> 3); /*0x1050167d6*/
  v6 = *v3; /*0x1050167db*/
  v7 = *((char **)this + 131082); /*0x1050167de*/
  if ( v3[1] != *v3 ) /*0x1050167e9*/
  {
    v8 = (_QWORD *)((char *)this + 1048664); /*0x1050167f9*/
    v9 = 0; /*0x105016800*/
    v37 = v3; /*0x105016807*/
    do /*0x10501690f*/
    {
      if ( (unsigned __int64)v7 >= *v8 ) /*0x105016811*/
      {
        v10 = *((_QWORD *)this + 131081); /*0x105016827*/
        v11 = (__int64)&v7[-v10] >> 4; /*0x105016831*/
        v12 = v11 + 1; /*0x105016835*/
        if ( (unsigned __int64)(v11 + 1) > 0xFFFFFFFFFFFFFFFLL ) /*0x10501683c*/
          std::vector<RBX::Graphics::Shadows::AtlasAllocator::SortedChartSize>::__throw_length_error[abi:ne200100]( /*0x105016a28*/
            a1: v8,
            a2: v5,
            a3: v10,
            a4: v12,
            a5: 0xFFFFFFFFFFFFFFFLL);
        v13 = *v8 - v10; /*0x105016842*/
        v14 = v13 >> 3; /*0x105016848*/
        if ( v13 >> 3 <= v12 ) /*0x10501684f*/
          v14 = v11 + 1; /*0x105016851*/
        if ( (unsigned __int64)v13 >= 0x7FFFFFFFFFFFFFF0LL ) /*0x105016861*/
          v14 = 0xFFFFFFFFFFFFFFFLL; /*0x105016861*/
        if ( v14 != 0 ) /*0x105016868*/
        {
          v15 = v6; /*0x10501686a*/
          v16 = std::__allocate_at_least[abi:ne200100]<std::allocator<RBX::Graphics::Shadows::AtlasAllocator::SortedChartSize>>( /*0x10501686d*/
                  a1: v8,
                  a2: v14,
                  a3: v10,
                  a4: 0x7FFFFFFFFFFFFFF0LL,
                  a5: 0xFFFFFFFFFFFFFFFLL);
          v6 = v15; /*0x105016872*/
          v18 = v17; /*0x105016875*/
        }
        else
        {
          v16 = 0; /*0x10501687a*/
          v18 = 0; /*0x10501687c*/
        }
        v19 = (_QWORD *)(v16 + 16 * v11); /*0x105016882*/
        v20 = v16 + 16 * v18; /*0x10501688a*/
        v7 = (char *)(v19 + 2); /*0x105016894*/
        *v19 = *(_QWORD *)(v6 + 8 * v9); /*0x105016898*/
        v19[1] = v9; /*0x10501689c*/
        v21 = *((const void **)this + 131081); /*0x1050168a0*/
        v22 = *((_QWORD *)this + 131082) - (_QWORD)v21; /*0x1050168ae*/
        v23 = (char *)v19 - v22; /*0x1050168b1*/
        memcpy(__dst: v23, __src: v21, __n: v22); /*0x1050168b7*/
        v24 = *((void **)this + 131081); /*0x1050168bc*/
        *((_QWORD *)this + 131081) = v23; /*0x1050168c3*/
        *((_QWORD *)this + 131082) = v7; /*0x1050168ca*/
        *((_QWORD *)this + 131083) = v20; /*0x1050168d1*/
        if ( v24 != nullptr ) /*0x1050168db*/
          operator delete(a1: v24); /*0x1050168dd*/
        v3 = v37; /*0x1050168e2*/
        v8 = (_QWORD *)((char *)this + 1048664); /*0x1050168f0*/
      }
      else
      {
        *(_QWORD *)v7 = *(_QWORD *)(v6 + 8 * v9); /*0x105016817*/
        *((_QWORD *)v7 + 1) = v9; /*0x10501681a*/
        v7 += 16; /*0x10501681e*/
      }
      *((_QWORD *)this + 131082) = v7; /*0x1050168f4*/
      ++v9; /*0x1050168fb*/
      v6 = *v3; /*0x1050168fe*/
    }
    while ( v9 < (__int64)(v3[1] - *v3) >> 3 ); /*0x10501690f*/
  }
  v25 = *((char **)this + 131081); /*0x105016915*/
  _BitScanReverse64(&v26, (v7 - v25) >> 4); /*0x105016926*/
  v27 = (2 * ((unsigned int)v26 ^ 0x3F)) ^ 0x7ELL; /*0x10501692f*/
  v28 = 0; /*0x105016933*/
  if ( v7 != v25 ) /*0x105016938*/
    v28 = v27; /*0x105016938*/
  result = std::__introsort<std::_ClassicAlgPolicy,RBX::Graphics::Shadows::AtlasAllocator::allocateBatchStrict(std::vector<RBX::Graphics::Shadows::AtlasAllocator::ChartSize> const&,std::vector<int> &)::$_0 &,RBX::Graphics::Shadows::AtlasAllocator::SortedChartSize *,false>( /*0x105016944*/
             a1: v25,
             a2: v7,
             a3: v28,
             a4: 1);
  v30 = *((_QWORD *)this + 131081); /*0x105016949*/
  if ( *((_QWORD *)this + 131082) != v30 ) /*0x105016957*/
  {
    v31 = 0; /*0x105016965*/
    v32 = 0; /*0x105016968*/
    do /*0x105016a13*/
    {
      Impl = RBX::Graphics::Shadows::AtlasAllocator::allocateImpl( /*0x10501697e*/
               this,
               a2: *(_DWORD *)(v30 + 16 * v32),
               a3: *(unsigned int *)(v30 + 16 * v32 + 4));
      if ( (v31 & 1 | (Impl != -1)) == 0 ) /*0x10501698f*/
      {
        v34 = (char *)this + 24; /*0x105016991*/
        for ( i = 0; i != 0x8000; ++i ) /*0x105016995*/
        {
          if ( v34[10] == 1 && *((_QWORD *)this + 131076) - *(_QWORD *)v34 >= 2u ) /*0x1050169ad*/
            RBX::Graphics::Shadows::AtlasAllocator::freeImpl(a1: this, a2: (unsigned __int16)i, a3: v34 - 16); /*0x1050169b9*/
          v34 += 32; /*0x1050169c1*/
        }
        Impl = RBX::Graphics::Shadows::AtlasAllocator::allocateImpl( /*0x1050169e1*/
                 this,
                 a2: *(_DWORD *)(*((_QWORD *)this + 131081) + 16 * v32),
                 a3: *(unsigned int *)(*((_QWORD *)this + 131081) + 16 * v32 + 4));
        v31 = 1; /*0x1050169e6*/
      }
      v30 = *((_QWORD *)this + 131081); /*0x1050169e9*/
      *(_DWORD *)(*a3 + 4LL * *(_QWORD *)(v30 + 16 * v32++ + 8)) = Impl; /*0x1050169fc*/
      result = (*((_QWORD *)this + 131082) - v30) >> 4; /*0x105016a0c*/
    }
    while ( v32 < result ); /*0x105016a13*/
  }
  return result; /*0x105016a19*/
}

// Address: 0x105016a2e | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator14allocateStrictERKNS2_9ChartSizeE
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::allocateStrict(
        RBX::Graphics::Shadows::AtlasAllocator *a1,
        __int64 a2)
{
  return RBX::Graphics::Shadows::AtlasAllocator::allocateImpl( /*0x105016a39*/
           this: a1,
           a2: *(_DWORD *)a2,
           a3: *(unsigned int *)(a2 + 4));
}

// Address: 0x105016a40 | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator8freeImplEtRNS2_5ChartE
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::freeImpl(_QWORD *a1, __int16 a2, __int64 a3)
{
  unsigned int v3; // eax
  __m128i v4; // xmm0
  unsigned __int64 v5; // rcx
  unsigned __int64 v6; // rax
  __m128i *v7; // r8
  __int16 v9; // [rsp+Eh] [rbp-2h] BYREF

  v3 = *(_DWORD *)(a3 + 12) + 31; /*0x105016a4b*/
  if ( v3 >= 0x20 ) /*0x105016a51*/
  {
    v4 = _mm_xor_si128( /*0x105016a75*/
           (__m128i)-1LL,
           *(__m128i *)(((*(_DWORD *)a3 >> 1) & 0x7FFFFFF0)
                      + a1[131084]
                      + ((unsigned __int64)((unsigned int)(*(_DWORD *)(a3 + 8) + 31) >> 5) << 11)));
    v5 = *(_DWORD *)(a3 + 4) >> 5; /*0x105016a7e*/
    v6 = (unsigned int)v5 + (v3 >> 5); /*0x105016a84*/
    v7 = (__m128i *)(*a1 + (unsigned int)(16 * (*(_DWORD *)(a3 + 4) >> 5))); /*0x105016a8d*/
    do /*0x105016aa8*/
    {
      *v7 = _mm_and_si128(_mm_load_si128(v7), v4); /*0x105016a99*/
      ++v5; /*0x105016a9e*/
      ++v7; /*0x105016aa1*/
    }
    while ( v5 < v6 ); /*0x105016aa8*/
  }
  *(_OWORD *)(a3 + 11) = 0; /*0x105016ab5*/
  *(_OWORD *)a3 = 0; /*0x105016aba*/
  v9 = a2; /*0x105016ac2*/
  return std::vector<unsigned short>::push_back[abi:ne200100](a1: a1 + 131073, a2: &v9); /*0x105016acd*/
}

// Address: 0x105016ad4 | Name: __ZNK3RBX8Graphics7Shadows14AtlasAllocator7isValidEi
char __fastcall RBX::Graphics::Shadows::AtlasAllocator::isValid(RBX::Graphics::Shadows::AtlasAllocator *this, int a2)
{
  if ( a2 < 0 ) /*0x105016ada*/
    return 0; /*0x105016af5*/
  else
    return *((_BYTE *)this + 32 * (unsigned int)(unsigned __int16)a2 + 34) /*0x105016aef*/
         & (*((_WORD *)this + 16 * (unsigned int)(unsigned __int16)a2 + 16) == HIWORD(a2));
}

// Address: 0x105016afa | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator4freeEi
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::free(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        unsigned __int16 a2)
{
  __int64 result; // rax

  result = RBX::Graphics::Shadows::AtlasAllocator::freeImpl(a1: this, a2, a3: (__int64)this + 32 * (unsigned int)a2 + 8); /*0x105016b13*/
  *((_BYTE *)this + 1048640) = 1; /*0x105016b18*/
  return result; /*0x105016b23*/
}

// Address: 0x105016b26 | Name: __ZNK3RBX8Graphics7Shadows14AtlasAllocator11isSizeValidEii
bool __fastcall RBX::Graphics::Shadows::AtlasAllocator::isSizeValid(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        int a2,
        int a3)
{
  __int64 v3; // rax
  char *v4; // rcx
  bool result; // al

  if ( a2 < 0 ) /*0x105016b2c*/
    return false; /*0x105016b2c*/
  v3 = 32 * (unsigned int)(unsigned __int16)a2; /*0x105016b36*/
  if ( *(_WORD *)((char *)this + v3 + 32) != HIWORD(a2) ) /*0x105016b3e*/
    return false; /*0x105016b5d*/
  v4 = (char *)this + v3 + 8; /*0x105016b44*/
  result = false; /*0x105016b48*/
  if ( v4[26] == 1 && *((_DWORD *)v4 + 2) == a3 ) /*0x105016b53*/
    return *((_DWORD *)v4 + 3) == a3; /*0x105016b58*/
  return result; /*0x105016b5f*/
}

// Address: 0x105016b62 | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator9nextFrameEv
void __fastcall RBX::Graphics::Shadows::AtlasAllocator::nextFrame(RBX::Graphics::Shadows::AtlasAllocator *this)
{
  ++*((_QWORD *)this + 131076); /*0x105016b66*/
}

// Address: 0x105016b70 | Name: __ZN3RBX8Graphics7Shadows14AtlasAllocator5touchEi
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::touch(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        unsigned __int16 a2)
{
  __int64 result; // rax

  result = 32 * (unsigned int)a2; /*0x105016b7e*/
  *(_QWORD *)((char *)this + result + 24) = *((_QWORD *)this + 131076); /*0x105016b81*/
  return result; /*0x105016b86*/
}

// Address: 0x105016b88 | Name: __ZNK3RBX8Graphics7Shadows14AtlasAllocator20debugSaveBitmapToPngEPKc
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::debugSaveBitmapToPng(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        const char *a2)
{
  __int64 v3; // rdx
  int v4; // r14d
  __int64 v5; // rcx
  __int64 v6; // rax
  int v7; // ecx
  int v8; // edx
  int v9; // ecx
  unsigned int v10; // r12d
  int i; // r15d
  unsigned int v12; // r13d
  int j; // ebx
  boost::filesystem::path *v14; // rax
  const char *v15; // r15
  _BYTE v17[48]; // [rsp+8h] [rbp-358h] BYREF
  __int64 v18; // [rsp+38h] [rbp-328h]
  int v19; // [rsp+40h] [rbp-320h]
  int v20; // [rsp+50h] [rbp-310h]
  __m128i v21; // [rsp+60h] [rbp-300h] BYREF
  _BYTE v22[16]; // [rsp+70h] [rbp-2F0h] BYREF
  void *v23; // [rsp+80h] [rbp-2E0h]
  __int64 v24; // [rsp+88h] [rbp-2D8h]
  __int64 v25; // [rsp+90h] [rbp-2D0h]
  __int64 v26; // [rsp+98h] [rbp-2C8h]
  __int64 v27; // [rsp+A0h] [rbp-2C0h]
  RBX::Graphics::Shadows::AtlasAllocator *v28; // [rsp+A8h] [rbp-2B8h]
  const char *v29; // [rsp+B0h] [rbp-2B0h]
  __m128i v30; // [rsp+B8h] [rbp-2A8h] BYREF
  void *v31; // [rsp+C8h] [rbp-298h]
  __m128i v32; // [rsp+D0h] [rbp-290h] BYREF
  void *v33; // [rsp+E0h] [rbp-280h]
  RSL::Arena *v34; // [rsp+E8h] [rbp-278h]
  __m128i v35; // [rsp+F0h] [rbp-270h] BYREF
  void *v36; // [rsp+100h] [rbp-260h]
  _BYTE v37[384]; // [rsp+110h] [rbp-250h]
  _QWORD v38[18]; // [rsp+290h] [rbp-D0h] BYREF
  int v39; // [rsp+320h] [rbp-40h]

  v29 = a2; /*0x105016b9c*/
  v34 = (RSL::Arena *)operator new(a1: 0x20u); /*0x105016bbe*/
  RBX::GImage::GImage(this: v34, a2: 4096, a3: 0x2000, a4: 3, a5: 1); /*0x105016bdd*/
  v27 = *((_QWORD *)this + 131084) + 2048LL; /*0x105016bee*/
  v3 = 0; /*0x105016bf5*/
  v28 = this; /*0x105016bf7*/
  do /*0x105016ce2*/
  {
    v21 = *(__m128i *)(*(_QWORD *)this + 16 * v3); /*0x105016c0c*/
    v24 = (unsigned int)(32 * v3); /*0x105016c18*/
    v4 = 0; /*0x105016c1f*/
    v5 = 0; /*0x105016c22*/
    v26 = v3; /*0x105016c24*/
    do /*0x105016ccb*/
    {
      v6 = 16 * v5; /*0x105016c2e*/
      v25 = v5; /*0x105016c32*/
      v7 = 16 * (((_BYTE)v3 + (_BYTE)v5) & 1); /*0x105016c3e*/
      v8 = v7 + 239; /*0x105016c41*/
      v9 = v7 ^ 0x10; /*0x105016c47*/
      if ( !_mm_testz_si128(_mm_load_si128(&v21), *(__m128i *)(v27 + v6)) ) /*0x105016c5f*/
        v9 = v8; /*0x105016c5f*/
      v10 = v9 + ((v9 << 16) | (v9 << 8)) - 0x1000000; /*0x105016c72*/
      for ( i = 0; i != 32; ++i ) /*0x105016c79*/
      {
        v12 = i + v24; /*0x105016c83*/
        for ( j = 0; j != 32; ++j ) /*0x105016c87*/
          RBX::GImage::setPixel(a1: v34, a2: (unsigned int)(v4 + j), a3: v12, a4: v10); /*0x105016c9a*/
      }
      v5 = v25 + 1; /*0x105016cb6*/
      v4 += 32; /*0x105016cb9*/
      LOBYTE(v3) = v26; /*0x105016cc4*/
    }
    while ( v25 != 127 ); /*0x105016ccb*/
    v3 = v26 + 1; /*0x105016cd1*/
    this = v28; /*0x105016cdb*/
  }
  while ( v26 != 255 ); /*0x105016ce2*/
  RBX::BinaryOutput::BinaryOutput(this: (RBX::BinaryOutput *)v17); /*0x105016cef*/
  RBX::GImage::encode(this: v34); /*0x105016d07*/
  RBX::FileSystem::getUserDirectory(a1: &v30, a2: 1, a3: 1, a4: 0); /*0x105016d1f*/
  std::string::basic_string[abi:ne200100]<0>(a1: v22, a2: v29); /*0x105016d32*/
  if ( (v30.i8[0] & 1) != 0 ) /*0x105016d3e*/
  {
    std::string::__init_copy_ctor_external(a1: &v35, a2: v31, a3: v30.i64[1]); /*0x105016d75*/
  }
  else
  {
    v36 = v31; /*0x105016d47*/
    v35 = _mm_loadu_si128(&v30); /*0x105016d56*/
  }
  v14 = boost::filesystem::path::operator/=(this: (boost::filesystem::path *)&v35, a2: (boost::filesystem::path *)v22); /*0x105016d88*/
  if ( (*(_BYTE *)v14 & 1) != 0 ) /*0x105016d90*/
  {
    std::string::__init_copy_ctor_external(a1: &v32, a2: *((_QWORD *)v14 + 2), a3: *((_QWORD *)v14 + 1)); /*0x105016dba*/
  }
  else
  {
    v33 = *((void **)v14 + 2); /*0x105016d96*/
    v32 = _mm_loadu_si128((const __m128i *)v14); /*0x105016da1*/
  }
  if ( (v35.i8[0] & 1) != 0 ) /*0x105016dc6*/
    operator delete(a1: v36); /*0x105016dcf*/
  if ( (v22[0] & 1) != 0 ) /*0x105016ddb*/
    operator delete(a1: v23); /*0x105016de4*/
  if ( (v30.i8[0] & 1) != 0 ) /*0x105016df0*/
    operator delete(a1: v31); /*0x105016df9*/
  if ( (v32.i8[0] & 1) != 0 ) /*0x105016e05*/
    v15 = (const char *)v33; /*0x105016e07*/
  else
    v15 = &v32.i8[1]; /*0x105016e10*/
  v38[6] = 0; /*0x105016e1e*/
  v35.i64[0] = (__int64)&off_10C447CA8; /*0x105016e38*/
  v38[0] = &off_10C447CD0; /*0x105016e41*/
  std::ios_base::init(this: (std::ios_base *)v38, a2: &v35.u64[1]); /*0x105016e4a*/
  v38[17] = 0; /*0x105016e4f*/
  v39 = -1; /*0x105016e57*/
  v35.i64[0] = (__int64)&off_10C447C38; /*0x105016e69*/
  v38[0] = off_10C447C60; /*0x105016e74*/
  std::filebuf::basic_filebuf(a1: &v35.u64[1]); /*0x105016e7e*/
  if ( std::filebuf::open(a1: (__int64)&v35.i64[1], a2: v15, a3: 0x14u) == 0 ) /*0x105016e96*/
    std::ios_base::clear( /*0x105016eb4*/
      this: (std::ios_base *)&v35.i8[*(_QWORD *)(v35.i64[0] - 24)],
      a2: *(_DWORD *)&v37[*(_QWORD *)(v35.i64[0] - 24)] | 4);
  std::ostream::write(a1: &v35, a2: v18, a3: v19 + (__int64)v20); /*0x105016ed8*/
  if ( std::filebuf::close(a1: &v35.i64[1]) == nullptr ) /*0x105016ee8*/
    std::ios_base::clear( /*0x105016f06*/
      this: (std::ios_base *)&v35.i8[*(_QWORD *)(v35.i64[0] - 24)],
      a2: *(_DWORD *)&v37[*(_QWORD *)(v35.i64[0] - 24)] | 4);
  v35.i64[0] = (__int64)&off_10C447C38; /*0x105016f12*/
  v38[0] = off_10C447C60; /*0x105016f15*/
  std::filebuf::~filebuf(a1: (__int64)&v35.i64[1]); /*0x105016f1f*/
  std::ostream::~ostream(a1: &v35, a2: off_10C447C78); /*0x105016f32*/
  std::ios::~ios(a1: v38); /*0x105016f3a*/
  if ( (v32.i8[0] & 1) != 0 ) /*0x105016f46*/
    operator delete(a1: v33); /*0x105016f4f*/
  RBX::BinaryOutput::~BinaryOutput(this: (RBX::BinaryOutput *)v17); /*0x105016f5b*/
  (*(void (__fastcall **)(RSL::Arena *))(*(_QWORD *)v34 + 8LL))(a1: v34); /*0x105016f6a*/
  return __stack_chk_guard; /*0x105016f7d*/
}

// Address: 0x105017080 | Name: __ZNK3RBX8Graphics7Shadows14AtlasAllocator15debugGetTimeNowEv
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::debugGetTimeNow(
        RBX::Graphics::Shadows::AtlasAllocator *this)
{
  return *((_QWORD *)this + 131076); /*0x10501708b*/
}

// Address: 0x10501708e | Name: __ZNK3RBX8Graphics7Shadows14AtlasAllocator22debugGetAllValidChartsERNSt3__16vectorIiNS3_9allocatorIiEEEE
void __fastcall RBX::Graphics::Shadows::AtlasAllocator::debugGetAllValidCharts(__int64 a1, __int64 a2)
{
  __int64 v2; // r12
  _BYTE *v3; // r14
  __int64 i; // r15
  int v5; // r13d
  _DWORD *v6; // rdx
  unsigned __int64 v7; // rcx
  _DWORD *v8; // rbx
  const void *v9; // rsi
  signed __int64 v10; // rdx
  __int64 v11; // rbx
  unsigned __int64 v12; // rdi
  __int64 v13; // rcx
  __int64 v14; // rax
  __int64 v15; // rax
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // rdi
  _DWORD *v19; // r12
  _DWORD *v20; // r12
  void *v21; // rdi
  __int64 v22; // [rsp+0h] [rbp-40h]
  __int64 v24; // [rsp+10h] [rbp-30h]

  v2 = a2; /*0x10501709f*/
  v24 = a2 + 16; /*0x1050170b3*/
  v3 = (_BYTE *)(a1 + 34); /*0x1050170b7*/
  for ( i = 0; i != 0x8000; ++i ) /*0x1050170bb*/
  {
    if ( *v3 == 1 ) /*0x1050170c6*/
    {
      v5 = i + (*(_DWORD *)(v3 - 2) << 16); /*0x1050170d4*/
      v6 = *(_DWORD **)(v2 + 8); /*0x1050170d7*/
      v7 = *(_QWORD *)(v2 + 16); /*0x1050170dc*/
      if ( (unsigned __int64)v6 >= v7 ) /*0x1050170e4*/
      {
        v9 = *(const void **)v2; /*0x1050170f5*/
        v10 = (signed __int64)v6 - *(_QWORD *)v2; /*0x1050170f9*/
        v11 = v10 >> 2; /*0x1050170ff*/
        v12 = (v10 >> 2) + 1; /*0x105017103*/
        if ( v12 > 0x3FFFFFFFFFFFFFFFLL ) /*0x10501710a*/
          std::vector<int>::__throw_length_error[abi:ne200100](a1: v12); /*0x1050171dd*/
        v13 = v7 - (_QWORD)v9; /*0x105017110*/
        v14 = v13 >> 1; /*0x105017116*/
        if ( v13 >> 1 <= v12 ) /*0x10501711c*/
          v14 = (v10 >> 2) + 1; /*0x10501711c*/
        if ( (unsigned __int64)v13 >= 0x7FFFFFFFFFFFFFFCLL ) /*0x10501712d*/
          v14 = 0x3FFFFFFFFFFFFFFFLL; /*0x10501712d*/
        if ( v14 != 0 ) /*0x105017134*/
        {
          v15 = std::__allocate_at_least[abi:ne200100]<std::allocator<int>>(a1: v24); /*0x10501713d*/
          v17 = v16; /*0x105017142*/
          v9 = *(const void **)v2; /*0x105017145*/
          v10 = *(_QWORD *)(v2 + 8) - *(_QWORD *)v2; /*0x10501714e*/
          v18 = v10 >> 2; /*0x105017154*/
        }
        else
        {
          v18 = v10 >> 2; /*0x10501715a*/
          v15 = 0; /*0x10501715d*/
          v17 = 0; /*0x10501715f*/
        }
        v19 = (_DWORD *)(v15 + 4 * v11); /*0x105017161*/
        v22 = v15 + 4 * v17; /*0x105017169*/
        *v19 = v5; /*0x10501716d*/
        v8 = v19 + 1; /*0x105017175*/
        v20 = &v19[-v18]; /*0x10501717d*/
        memcpy(__dst: v20, __src: v9, __n: v10); /*0x105017183*/
        v21 = *(void **)a2; /*0x10501718c*/
        *(_QWORD *)a2 = v20; /*0x10501718f*/
        *(_QWORD *)(a2 + 8) = v8; /*0x105017192*/
        *(_QWORD *)(a2 + 16) = v22; /*0x10501719a*/
        v2 = a2; /*0x1050171a1*/
        if ( v21 != nullptr ) /*0x1050171a4*/
          operator delete(a1: v21); /*0x1050171a6*/
      }
      else
      {
        *v6 = v5; /*0x1050170e6*/
        v8 = v6 + 1; /*0x1050170ed*/
      }
      *(_QWORD *)(v2 + 8) = v8; /*0x1050171b5*/
    }
    v3 += 32; /*0x1050171bd*/
  }
}

// Address: 0x1050171e2 | Name: __ZNK3RBX8Graphics7Shadows14AtlasAllocator8getChartEi
__int64 __fastcall RBX::Graphics::Shadows::AtlasAllocator::getChart(
        RBX::Graphics::Shadows::AtlasAllocator *this,
        unsigned __int16 a2)
{
  return (__int64)this + 32 * (unsigned int)a2 + 8; /*0x1050171f3*/
}

// END AtlasAllocator part 1/1, 26 functions
