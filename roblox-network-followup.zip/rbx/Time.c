// Time -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 21 functions

// Field names below come from the 2022 PDB, which is the only
// build that has them. Each is marked: bare `this->x` was
// corroborated by a store of matching width in that same
// function; UNVERIFIED means the 2022 layout says so and
// nothing target-era has confirmed it.


// Address: 0x1041b6718 | Name: __ZN3RBX4Time12getTickCountEv
uint64_t __fastcall RBX::Time::getTickCount(RBX::Time *this)
{
  return mach_absolute_time(); /*0x1041b671c*/
}

// Address: 0x1041b6722 | Name: __ZN3RBX4Time9epochTimeEv
unsigned __int64 __fastcall RBX::Time::epochTime(RBX::Time *this)
{
  __int64 v1; // rax

  v1 = std::chrono::system_clock::now(this); /*0x1041b6726*/
  return v1 / 0xF4240uLL + ((unsigned __int64)((unsigned __int128)(0x431BDE82D7B634DBLL * (__int128)v1) >> 64) >> 63); /*0x1041b6746*/
}

// Address: 0x1041b6748 | Name: __ZN3RBX4Time11epochTimeMsEv
unsigned __int64 __fastcall RBX::Time::epochTimeMs(RBX::Time *this)
{
  __int64 v1; // rax

  v1 = std::chrono::system_clock::now(this); /*0x1041b674c*/
  return v1 / 1000 + ((unsigned __int64)((unsigned __int128)(0x20C49BA5E353F7CFLL * (__int128)v1) >> 64) >> 63); /*0x1041b676c*/
}

// Address: 0x1041b676e | Name: __ZN3RBX4Time11epochTimeNsEv
__int64 __fastcall RBX::Time::epochTimeNs(RBX::Time *this)
{
  return 1000LL * std::chrono::system_clock::now(this); /*0x1041b677e*/
}

// Address: 0x1041b6780 | Name: __ZN3RBX4Time3nowILNS0_12SampleMethodE2EEES0_v
__int64 __fastcall RBX::Time::now<(RBX::Time::SampleMethod)2>(RBX *a1)
{
  return RBX::nowPrecise(this: a1); /*0x1041b6784*/
}

// Address: 0x1041b685e | Name: __ZN3RBX4Time3nowILNS0_12SampleMethodE3EEES0_v
__int64 __fastcall RBX::Time::now<(RBX::Time::SampleMethod)3>(RBX *a1)
{
  return RBX::nowPrecise(this: a1); /*0x1041b6862*/
}

// Address: 0x1041b6868 | Name: __ZN3RBX4Time14isSpeedCheaterEv
__int64 __fastcall RBX::Time::isSpeedCheater(RBX::Time *this)
{
  return 0; /*0x1041b686e*/
}

// Address: 0x1041b6870 | Name: __ZN3RBX4Time10isDebuggedEv
__int64 __fastcall RBX::Time::isDebugged(RBX::Time *this)
{
  return 0; /*0x1041b6876*/
}

// Address: 0x1041b6878 | Name: __ZN3RBX4Time3nowILNS0_12SampleMethodE0EEES0_v
__int64 __fastcall RBX::Time::now<(RBX::Time::SampleMethod)0>(RBX *a1)
{
  return RBX::nowPrecise(this: a1); /*0x1041b687c*/
}

// Address: 0x1041b6882 | Name: __ZN3RBX4Time7nowFastEv
__int64 __fastcall RBX::Time::nowFast(RBX::Time *this)
{
  return RBX::nowPrecise(this); /*0x1041b6886*/
}

// Address: 0x1041b688c | Name: __ZN3RBX4Time10nowFastSecEv
__int64 __fastcall RBX::Time::nowFastSec(RBX::Time *this)
{
  return RBX::nowPrecise(this); /*0x1041b6890*/
}

// Address: 0x1041b6896 | Name: __ZN3RBX4Time3nowILNS0_12SampleMethodE1EEES0_v
__int64 __fastcall RBX::Time::now<(RBX::Time::SampleMethod)1>(RBX *a1)
{
  return RBX::nowPrecise(this: a1); /*0x1041b689a*/
}

// Address: 0x1041b68a0 | Name: __ZN3RBX4Time3nowENS0_12SampleMethodE
__int64 __fastcall RBX::Time::now(RBX *a1)
{
  return RBX::nowPrecise(this: a1); /*0x1041b68a4*/
}

// Address: 0x1041b68aa | Name: __ZN3RBX4Time12getTickStatsEPdS1_Pb
__int64 __fastcall RBX::Time::getTickStats(RBX::Time *this, double *a2, double *a3, bool *a4)
{
  __int64 result; // rax
  double v8; // xmm0_8

  result = RBX::tick_resolution(this); /*0x1041b68bd*/
  this->sec /* +0 */= 0.000001 / v8; /*0x1041b68ce*/
  *a2 = 0.0; /*0x1041b68d3*/
  *(_BYTE *)a3 = 1; /*0x1041b68da*/
  return result; /*0x1041b68e1*/
}

// Address: 0x1041b695a | Name: __ZN3RBX4Time5sleepEd
__int64 __fastcall RBX::Time::sleep(RBX::Time *this, double a2)
{
  unsigned __int64 v2; // rbx
  double v4; // [rsp+0h] [rbp-180h]
  char v5; // [rsp+1Fh] [rbp-161h] BYREF
  _BYTE v6[160]; // [rsp+20h] [rbp-160h] BYREF
  _BYTE v7[160]; // [rsp+C0h] [rbp-C0h] BYREF

  if ( (_BYTE)`guard variable for'RBX::Time::sleep(double)::cv == 0 ) /*0x1041b6980*/
  {
    v4 = a2; /*0x1041b6a25*/
    RBX::Time::sleep(this, a2); /*0x1041b6a2d*/
    a2 = v4; /*0x1041b6a32*/
  }
  v2 = (unsigned int)(int)(a2 * 1000000.0); /*0x1041b69aa*/
  RSL::Arena::getDefaultArena(this); /*0x1041b69ad*/
  RSL::Closure::Closure(this: (RSL::Closure *)v7, a2: &v5, a3: RSL_CLOSURE<RBX::Time::sleep(double)::$_0>); /*0x1041b69ca*/
  RSL::Closure::Closure(a1: v6, a2: v7); /*0x1041b69dc*/
  RSL::Closure::~Closure(this: (RSL::Closure *)v7); /*0x1041b69e4*/
  RSL::Condition::awaitAtomicFor( /*0x1041b69f6*/
    this: (RSL::Condition *)&RBX::Time::sleep(double)::cv,
    a2: v2,
    a3: (const RSL::Closure *)v6);
  RSL::Closure::~Closure(this: (RSL::Closure *)v6); /*0x1041b6a02*/
  return __stack_chk_guard; /*0x1041b6a17*/
}

// Address: 0x1041b6a60 | Name: __ZN3RBX4Time8getStartEv
uint64_t __fastcall RBX::Time::getStart(RBX::Time *this)
{
  uint64_t result; // rax

  if ( FFlag::g_flagsLoaded == 1 && FFlag::FasterPreciseTime == 1 ) /*0x1041b6a77*/
  {
    if ( RBX::startTimeInited == 0 ) /*0x1041b6a80*/
      RBX::Time::getStart(this); /*0x1041b6ab9*/
    return RBX::startTime; /*0x1041b6a82*/
  }
  else
  {
    result = RBX::startTime; /*0x1041b6a8b*/
    if ( RBX::startTime == 0 ) /*0x1041b6a95*/
    {
      if ( RBX::startTimeInited != 0 ) /*0x1041b6a9e*/
      {
        return 0; /*0x1041b6aa0*/
      }
      else
      {
        result = mach_absolute_time(); /*0x1041b6aa4*/
        RBX::startTime = result; /*0x1041b6aa9*/
        RBX::startTimeInited = 1; /*0x1041b6ab0*/
      }
    }
  }
  return result; /*0x1041b6ab7*/
}

// Address: 0x1041b6ac0 | Name: __ZN3RBX4Time22createISO8601TimestampEx
RBX::Time *__fastcall RBX::Time::createISO8601Timestamp(RBX::Time *this, __int64 a2)
{
  __int64 v2; // r14
  __int64 v4; // rdx
  __int64 v5; // rcx
  unsigned __int64 v6; // r14
  int v7; // r8d
  int v8; // edx
  int v9; // edx
  int v10; // ecx
  int v11; // ecx
  int v12; // esi
  int v13; // r8d
  int v14; // r9d
  int v15; // r10d
  int v16; // r11d
  unsigned __int64 v18; // [rsp+0h] [rbp-50h] BYREF
  int v19; // [rsp+Ch] [rbp-44h] BYREF
  int v20; // [rsp+10h] [rbp-40h]
  int v21; // [rsp+14h] [rbp-3Ch]
  int v22; // [rsp+18h] [rbp-38h]
  int v23; // [rsp+1Ch] [rbp-34h]
  int v24; // [rsp+20h] [rbp-30h]

  v2 = a2; /*0x1041b6acf*/
  if ( a2 <= 0 ) /*0x1041b6adb*/
    v2 = 0; /*0x1041b6adb*/
  v18 = (unsigned __int64)((0x20C49BA5E353F7CFLL * (unsigned __int128)(unsigned __int64)v2) >> 64) >> 7; /*0x1041b6afa*/
  if ( rsl_gmtime_r(a1: &v18, a2: &v19) != 0 ) /*0x1041b6b09*/
  {
    v6 = v2 - 1000 * ((unsigned __int64)((0x20C49BA5E353F7CFLL * (unsigned __int128)(unsigned __int64)v2) >> 64) >> 7); /*0x1041b6b16*/
    v7 = 8099; /*0x1041b6b25*/
    if ( v24 < 8099 ) /*0x1041b6b2e*/
      v7 = v24; /*0x1041b6b2e*/
    v8 = -1900; /*0x1041b6b39*/
    if ( v7 >= -1899 ) /*0x1041b6b3e*/
      v8 = v7; /*0x1041b6b3e*/
    v9 = v8 + 1900; /*0x1041b6b42*/
    v10 = 11; /*0x1041b6b4b*/
    if ( v23 < 11 ) /*0x1041b6b50*/
      v10 = v23; /*0x1041b6b50*/
    if ( v10 <= 0 ) /*0x1041b6b55*/
      v10 = 0; /*0x1041b6b55*/
    v11 = v10 + 1; /*0x1041b6b59*/
    v12 = 31; /*0x1041b6b5e*/
    if ( v22 < 31 ) /*0x1041b6b63*/
      v12 = v22; /*0x1041b6b63*/
    v13 = 1; /*0x1041b6b69*/
    if ( v12 >= 2 ) /*0x1041b6b6f*/
      v13 = v12; /*0x1041b6b6f*/
    v14 = 24; /*0x1041b6b76*/
    if ( v21 < 24 ) /*0x1041b6b7c*/
      v14 = v21; /*0x1041b6b7c*/
    if ( v14 <= 0 ) /*0x1041b6b86*/
      v14 = 0; /*0x1041b6b86*/
    v15 = 59; /*0x1041b6b8d*/
    if ( v20 < 59 ) /*0x1041b6b93*/
      v15 = v20; /*0x1041b6b93*/
    if ( v15 <= 0 ) /*0x1041b6b9d*/
      v15 = 0; /*0x1041b6b9d*/
    v16 = 60; /*0x1041b6ba4*/
    if ( v19 < 60 ) /*0x1041b6baa*/
      v16 = v19; /*0x1041b6baa*/
    if ( v16 <= 0 ) /*0x1041b6bb1*/
      v16 = 0; /*0x1041b6bb1*/
    RBX::format(this, a2: "%04d-%02d-%02dT%02d:%02d:%02d.%03dZ", v9, v11, v13, v14, v15, v16, v6); /*0x1041b6bcb*/
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: this, a2: "0000-00-00T00:00:00.000Z", a3: v4, a4: v5); /*0x1041b6be0*/
  }
  return this; /*0x1041b6be8*/
}

// Address: 0x1041b6bf6 | Name: __ZN3RBX4Time18createUTCTimestampEv
RBX::Time *__fastcall RBX::Time::createUTCTimestamp(RBX::Time *this)
{
  __int64 v2; // rax
  __int64 v3; // rdx
  __int64 v4; // rcx
  __int64 v5; // rdi
  int v6; // r8d
  int v7; // ecx
  __int64 v8; // r8
  int v9; // r10d
  int v10; // r9d
  int v11; // r9d
  int v12; // r10d
  int v13; // r11d
  int v14; // r15d
  const char *v15; // r8
  unsigned __int64 v17; // [rsp+8h] [rbp-48h] BYREF
  int v18; // [rsp+14h] [rbp-3Ch] BYREF
  int v19; // [rsp+18h] [rbp-38h]
  int v20; // [rsp+1Ch] [rbp-34h]
  int v21; // [rsp+20h] [rbp-30h]
  int v22; // [rsp+24h] [rbp-2Ch]
  int v23; // [rsp+28h] [rbp-28h]
  int v24; // [rsp+2Ch] [rbp-24h]

  v2 = std::chrono::system_clock::now(this) / 1000LL; /*0x1041b6c23*/
  if ( v2 <= 0 ) /*0x1041b6c2c*/
    v2 = 0; /*0x1041b6c2c*/
  v17 = (unsigned __int64)((0x20C49BA5E353F7CFLL * (unsigned __int128)(unsigned __int64)v2) >> 64) >> 7; /*0x1041b6c3b*/
  if ( rsl_gmtime_r(a1: &v17, a2: &v18) != 0 ) /*0x1041b6c4a*/
  {
    v5 = 6; /*0x1041b6c6c*/
    if ( v24 < 6 ) /*0x1041b6c71*/
      v5 = (unsigned int)v24; /*0x1041b6c71*/
    if ( (int)v5 <= 0 ) /*0x1041b6c77*/
      v5 = 0; /*0x1041b6c77*/
    v6 = 31; /*0x1041b6c7e*/
    if ( v21 < 31 ) /*0x1041b6c84*/
      v6 = v21; /*0x1041b6c84*/
    v7 = 1; /*0x1041b6c8c*/
    if ( v6 >= 2 ) /*0x1041b6c91*/
      v7 = v6; /*0x1041b6c91*/
    v8 = 11; /*0x1041b6c99*/
    if ( v22 < 11 ) /*0x1041b6c9f*/
      v8 = (unsigned int)v22; /*0x1041b6c9f*/
    if ( (int)v8 <= 0 ) /*0x1041b6ca6*/
      v8 = 0; /*0x1041b6ca6*/
    v9 = 8099; /*0x1041b6caa*/
    if ( v23 < 8099 ) /*0x1041b6cb3*/
      v9 = v23; /*0x1041b6cb3*/
    v10 = -1900; /*0x1041b6cbe*/
    if ( v9 >= -1899 ) /*0x1041b6cc4*/
      v10 = v9; /*0x1041b6cc4*/
    v11 = v10 + 1900; /*0x1041b6cc8*/
    v12 = 24; /*0x1041b6cd2*/
    if ( v20 < 24 ) /*0x1041b6cd8*/
      v12 = v20; /*0x1041b6cd8*/
    if ( v12 <= 0 ) /*0x1041b6cea*/
      v12 = 0; /*0x1041b6cea*/
    v13 = 59; /*0x1041b6cf1*/
    if ( v19 < 59 ) /*0x1041b6cf7*/
      v13 = v19; /*0x1041b6cf7*/
    if ( v13 <= 0 ) /*0x1041b6cfe*/
      v13 = 0; /*0x1041b6cfe*/
    v14 = 60; /*0x1041b6d05*/
    if ( v18 < 60 ) /*0x1041b6d0b*/
      v14 = v18; /*0x1041b6d0b*/
    v15 = RBX::monthText[v8]; /*0x1041b6d16*/
    if ( v14 <= 0 ) /*0x1041b6d1d*/
      v14 = 0; /*0x1041b6d1d*/
    RBX::format(this, a2: "%s, %02d %s %04d %02d:%02d:%02d GMT", RBX::dayOfWeekText[v5], v7, v15, v11, v12, v13, v14); /*0x1041b6d37*/
  }
  else
  {
    std::string::basic_string[abi:ne200100]<0>(a1: this, a2: "Thu, 1 Jan 1970 00:00:00 GMT", a3: v3, a4: v4); /*0x1041b6d4c*/
  }
  return this; /*0x1041b6d54*/
}

// Address: 0x1041b6d60 | Name: __ZN3RBX4Time17systemTimeSecondsEv
double __fastcall RBX::Time::systemTimeSeconds(RBX::Time *this)
{
  double v1; // xmm0_8
  __int64 v3; // xmm0_8

  if ( (_BYTE)`guard variable for'RBX::Time::systemTimeSeconds(void)::initEpochSeconds == 0 /*0x1041b6d92*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::Time::systemTimeSeconds(void)::initEpochSeconds) != 0 )
  {
    RBX::initSystemTime(this); /*0x1041b6d94*/
    RBX::Time::systemTimeSeconds(void)::initEpochSeconds = v3; /*0x1041b6d99*/
    __cxa_guard_release(a1: &`guard variable for'RBX::Time::systemTimeSeconds(void)::initEpochSeconds); /*0x1041b6da8*/
  }
  RBX::nowPrecise(this); /*0x1041b6d70*/
  return v1 + *(double *)&RBX::Time::systemTimeSeconds(void)::initEpochSeconds; /*0x1041b6d81*/
}

// Address: 0x10866ea78 | Name: __ZN3RBX4Time5sleepEd.cold.1
void __fastcall RBX::Time::sleep(RBX::Time *this, double a2)
{
  if ( __cxa_guard_acquire(a1: &`guard variable for'RBX::Time::sleep(double)::cv) != 0 ) /*0x10866ea8c*/
  {
    RSL::Condition::Condition(this: (RSL::Condition *)&RBX::Time::sleep(double)::cv, a2: "RBX::Time::sleep"); /*0x10866ea9f*/
    __cxa_atexit( /*0x10866eab5*/
      lpfunc: RSL::Condition::~Condition,
      obj: &RBX::Time::sleep(double)::cv,
      lpdso_handle: (void *)&_mh_execute_header);
    __cxa_guard_release(a1: &`guard variable for'RBX::Time::sleep(double)::cv); /*0x10866eac7*/
  }
}

// Address: 0x10866ead3 | Name: __ZN3RBX4Time8getStartEv.cold.1
uint64_t __fastcall RBX::Time::getStart(RBX::Time *this)
{
  uint64_t result; // rax

  result = mach_absolute_time(); /*0x10866ead7*/
  RBX::startTime = result; /*0x10866eadc*/
  RBX::startTimeInited = 1; /*0x10866eae3*/
  return result; /*0x10866eaea*/
}

// END Time part 1/1, 21 functions
