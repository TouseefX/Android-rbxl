// TimerManager -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 17 functions

// Field names below come from the 2022 PDB, which is the only
// build that has them. Each is marked: bare `this->x` was
// corroborated by a store of matching width in that same
// function; UNVERIFIED means the 2022 layout says so and
// nothing target-era has confirmed it.


// Address: 0x102bb0fd4 | Name: __ZN3RBX12TimerManager11getInstanceEv
__int64 __fastcall RBX::TimerManager::getInstance(RBX::TimerManager *this)
{
  RBX::TimerManager *v2; // r14

  if ( (_BYTE)`guard variable for'RBX::TimerManager::getInstance(void)::timerManager == 0 /*0x102bb0fff*/
    && __cxa_guard_acquire(a1: &`guard variable for'RBX::TimerManager::getInstance(void)::timerManager) != 0 )
  {
    v2 = (RBX::TimerManager *)operator new(a1: 0x30u); /*0x102bb100b*/
    RBX::TimerManager::TimerManager(this: v2); /*0x102bb1011*/
    RBX::TimerManager::getInstance(void)::timerManager = (__int64)v2; /*0x102bb1016*/
    __cxa_guard_release(a1: &`guard variable for'RBX::TimerManager::getInstance(void)::timerManager); /*0x102bb1024*/
  }
  return RBX::TimerManager::getInstance(void)::timerManager; /*0x102bb0fec*/
}

// Address: 0x102bb1050 | Name: __ZN3RBX12TimerManager6onTickEv
__int64 __fastcall RBX::TimerManager::onTick(RBX::TimerManager *this)
{
  RBX *v2; // rdi
  double v3; // xmm0_8
  _QWORD *v4; // r12
  __int64 v5; // rax
  volatile signed __int64 *v6; // r15
  __int64 v7; // r15
  _QWORD *v8; // rax
  __int64 v9; // rbx
  volatile signed __int64 *v10; // r12
  _QWORD *v11; // rcx
  int BackOffMs; // eax
  double v13; // xmm0_8
  double v14; // xmm1_8
  double v15; // xmm2_8
  _QWORD *v16; // rax
  _QWORD *v17; // rcx
  _QWORD *v18; // rbx
  RSL::Mutex *i; // r15
  _QWORD *j; // r15
  __int64 v21; // rax
  volatile signed __int64 *v22; // rcx
  __int64 v23; // rdi
  std::__shared_weak_count *v24; // r14
  char *v26; // [rsp+8h] [rbp-88h]
  _QWORD *v27; // [rsp+10h] [rbp-80h] BYREF
  _QWORD *v28; // [rsp+18h] [rbp-78h]
  __int64 v29; // [rsp+20h] [rbp-70h]
  _QWORD *v30; // [rsp+28h] [rbp-68h] BYREF
  _QWORD *v31; // [rsp+30h] [rbp-60h]
  __int64 v32; // [rsp+38h] [rbp-58h]
  char *v33; // [rsp+40h] [rbp-50h]
  RSL::Mutex *v34; // [rsp+48h] [rbp-48h]
  double v35; // [rsp+50h] [rbp-40h]
  __int64 v36; // [rsp+58h] [rbp-38h] BYREF
  std::__shared_weak_count *v37; // [rsp+60h] [rbp-30h]

  v30 = &v30; /*0x102bb1068*/
  v31 = &v30; /*0x102bb106b*/
  v32 = 0; /*0x102bb1071*/
  v27 = &v27; /*0x102bb1079*/
  v28 = &v27; /*0x102bb107d*/
  v29 = 0; /*0x102bb1081*/
  RSL::Mutex::lock(this); /*0x102bb1085*/
  v34 = this; /*0x102bb108a*/
  RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v2); /*0x102bb108e*/
  v35 = v3; /*0x102bb1093*/
  v33 = (char *)this + 8 /* +8: NO 2022 FIELD */; /*0x102bb109c*/
  v4 = *((_QWORD **)this + 1); /*0x102bb10a0*/
  v26 = (char *)this + 16 /* +16: NO 2022 FIELD */; /*0x102bb10a8*/
  if ( v4 == (_QWORD *)((char *)this + 16 /* +16: NO 2022 FIELD */) ) /*0x102bb10b2*/
    goto LABEL_29; /*0x102bb10b2*/
  while ( 1 ) /*0x102bb10b8*/
  {
    v5 = v4[4]; /*0x102bb10b8*/
    v36 = v5; /*0x102bb10bd*/
    v6 = (volatile signed __int64 *)v4[5]; /*0x102bb10c1*/
    v37 = (std::__shared_weak_count *)v6; /*0x102bb10c6*/
    if ( v6 == nullptr ) /*0x102bb10cd*/
    {
      if ( v35 < *(double *)(v5 + 72) ) /*0x102bb10ef*/
        goto LABEL_29; /*0x102bb10ef*/
      goto LABEL_6; /*0x102bb10ef*/
    }
    _InterlockedIncrement64(v6 + 1); /*0x102bb10cf*/
    if ( v35 < *(double *)(v5 + 72) ) /*0x102bb10de*/
      break; /*0x102bb10de*/
LABEL_6:
    v7 = std::__tree<std::shared_ptr<RBX::TimerData>,RBX::TimerDataComparator,std::allocator<std::shared_ptr<RBX::TimerData>>>::__remove_node_pointer( /*0x102bb10f5*/
           a1: v33,
           a2: v4);
    std::shared_ptr<RBX::TimerData>::~shared_ptr[abi:ne200100](a1: v4 + 4); /*0x102bb1112*/
    operator delete(a1: v4); /*0x102bb111a*/
    v8 = (_QWORD *)operator new(a1: 0x20u); /*0x102bb1124*/
    v9 = v36; /*0x102bb1129*/
    v8[2] = v36; /*0x102bb112d*/
    v10 = (volatile signed __int64 *)v37; /*0x102bb1131*/
    v8[3] = v37; /*0x102bb1135*/
    if ( v10 != nullptr ) /*0x102bb113c*/
      _InterlockedIncrement64(v10 + 1); /*0x102bb113e*/
    v8[1] = &v30; /*0x102bb1148*/
    v11 = v30; /*0x102bb114c*/
    *v8 = v30; /*0x102bb1150*/
    v11[1] = v8; /*0x102bb1153*/
    v30 = v8; /*0x102bb1157*/
    ++v32; /*0x102bb115b*/
    *(_BYTE *)(v9 + 1) = 1; /*0x102bb115f*/
    if ( *(_BYTE *)v9 == 1 ) /*0x102bb1166*/
    {
      if ( *(_BYTE *)(v9 + 80) == 1 ) /*0x102bb1170*/
      {
        BackOffMs = RBX::ExponentialBackoff::nextBackOffMs(this: (RBX::ExponentialBackoff *)(v9 + 88)); /*0x102bb1179*/
        if ( BackOffMs == 0 ) /*0x102bb1180*/
        {
          *(_DWORD *)(v9 + 112) = 0; /*0x102bb1184*/
          *(_DWORD *)(v9 + 120) = 0; /*0x102bb1187*/
          if ( FFlag::EnableFloatingPointBaseMultiplier == 1 ) /*0x102bb1194*/
            *(_QWORD *)(v9 + 136) = 0x3FF0000000000000LL; /*0x102bb11a0*/
          else
            *(_DWORD *)(v9 + 116) = 1; /*0x102bb11f0*/
          BackOffMs = RBX::ExponentialBackoff::nextBackOffMs(this: (RBX::ExponentialBackoff *)(v9 + 88)); /*0x102bb11fa*/
        }
        *(double *)(v9 + 72) = (double)BackOffMs / 1000.0 + *(double *)(v9 + 72); /*0x102bb1216*/
      }
      else
      {
        v13 = *(double *)(v9 + 64); /*0x102bb11a9*/
        v14 = *(double *)(v9 + 72); /*0x102bb11ae*/
        v15 = 1.0; /*0x102bb11bb*/
        if ( v13 != 0.0 ) /*0x102bb11c3*/
          v15 = (double)((int)((v35 - v14) / v13) + 1); /*0x102bb11dd*/
        *(double *)(v9 + 72) = v14 + v13 * v15; /*0x102bb11e9*/
      }
      v16 = (_QWORD *)operator new(a1: 0x20u); /*0x102bb1223*/
      v16[2] = v9; /*0x102bb1228*/
      v16[3] = v10; /*0x102bb122c*/
      if ( v10 != nullptr ) /*0x102bb1233*/
        _InterlockedIncrement64(v10 + 1); /*0x102bb1235*/
      v16[1] = &v27; /*0x102bb123b*/
      v17 = v27; /*0x102bb123f*/
      *v16 = v27; /*0x102bb1243*/
      v17[1] = v16; /*0x102bb1246*/
      v27 = v16; /*0x102bb124a*/
      ++v29; /*0x102bb124e*/
    }
    if ( v10 != nullptr && _InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x102bb1268*/
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v10 + 16))(a1: v10); /*0x102bb1271*/
      std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v10); /*0x102bb1277*/
    }
    v4 = (_QWORD *)v7; /*0x102bb127c*/
    if ( (char *)v7 == v26 ) /*0x102bb1286*/
      goto LABEL_29; /*0x102bb1286*/
  }
  if ( _InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x102bb129e*/
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(a1: v6); /*0x102bb12a6*/
    std::__shared_weak_count::__release_weak(this: (std::__shared_weak_count *)v6); /*0x102bb12ac*/
  }
LABEL_29:
  v18 = v28; /*0x102bb12b1*/
  for ( i = v34; v18 != &v27; v18 = (_QWORD *)v18[1] ) /*0x102bb12c0*/
    std::__tree<std::shared_ptr<RBX::TimerData>,RBX::TimerDataComparator,std::allocator<std::shared_ptr<RBX::TimerData>>>::__emplace_unique_key_args<std::shared_ptr<RBX::TimerData>,std::shared_ptr<RBX::TimerData> const&>( /*0x102bb12cd*/
      a1: v33,
      a2: v18 + 2);
  RSL::Mutex::unlock(this: i); /*0x102bb12de*/
  for ( j = v31; j != &v30; j = (_QWORD *)j[1] ) /*0x102bb12ea*/
  {
    v21 = j[2]; /*0x102bb12f0*/
    v36 = v21; /*0x102bb12f4*/
    v22 = (volatile signed __int64 *)j[3]; /*0x102bb12f8*/
    v37 = (std::__shared_weak_count *)v22; /*0x102bb12fc*/
    if ( v22 != nullptr ) /*0x102bb1303*/
    {
      _InterlockedIncrement64(v22 + 1); /*0x102bb1305*/
      v21 = j[2]; /*0x102bb130a*/
    }
    v23 = *(_QWORD *)(v21 + 48); /*0x102bb130e*/
    if ( v23 == 0 ) /*0x102bb1315*/
      std::__throw_bad_function_call[abi:ne200100](a1: 0); /*0x102bb1376*/
    (*(void (__fastcall **)(__int64, __int64 *))(*(_QWORD *)v23 + 48LL))(a1: v23, a2: &v36); /*0x102bb131d*/
    v24 = v37; /*0x102bb1320*/
    if ( v37 != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v37 + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x102bb1339*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v24 + 16LL))(a1: v24); /*0x102bb1341*/
      std::__shared_weak_count::__release_weak(this: v24); /*0x102bb1347*/
    }
  }
  std::__list_imp<std::shared_ptr<RBX::TimerData>>::clear(a1: &v27); /*0x102bb1359*/
  return std::__list_imp<std::shared_ptr<RBX::TimerData>>::clear(a1: &v30); /*0x102bb1367*/
}

// Address: 0x102bb13d4 | Name: __ZN3RBX12TimerManagerC2Ev
__int64 __fastcall RBX::TimerManager::TimerManager(RBX::TimerManager *this)
{
  std::__shared_weak_count *v2; // r15
  __int64 v3; // rax
  __int64 result; // rax
  std::__shared_weak_count *v5; // rbx
  std::__shared_weak_count *v6[2]; // [rsp+0h] [rbp-30h] BYREF

  RSL::Mutex::Mutex(this, a2: "SimpleTimerMutex"); /*0x102bb13ed*/
  *((_OWORD *)this + 1) = 0; /*0x102bb13f9*/
  *((_QWORD *)this + 1) /* +8: NO 2022 FIELD */ = (char *)this + 16 /* +16: NO 2022 FIELD */; /*0x102bb13fd*/
  *((_OWORD *)this + 2) = 0; /*0x102bb1405*/
  RBX::make_shared<RBX::TimerTickerJob>(a1: v6); /*0x102bb140d*/
  std::shared_ptr<RBX::TimerTickerJob>::operator=[abi:ne200100](a1: (char *)this + 32 /* +32: NO 2022 FIELD */, a2: v6); /*0x102bb141c*/
  v2 = v6[1]; /*0x102bb1421*/
  if ( v6[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v6[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x102bb143a*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v2 + 16LL))(a1: v2); /*0x102bb1442*/
    std::__shared_weak_count::__release_weak(this: v2); /*0x102bb1448*/
  }
  v3 = *((_QWORD *)this + 5) /* +40: NO 2022 FIELD */; /*0x102bb144d*/
  *(_OWORD *)v6 = *((_OWORD *)this + 2); /*0x102bb1455*/
  if ( v3 != 0 ) /*0x102bb145c*/
    _InterlockedIncrement64((volatile signed __int64 *)(v3 + 8)); /*0x102bb145e*/
  result = RBX::TaskScheduler::add(a1: v6); /*0x102bb1467*/
  v5 = v6[1]; /*0x102bb146c*/
  if ( v6[1] != nullptr ) /*0x102bb1473*/
  {
    result = _InterlockedExchangeAdd64((volatile signed __int64 *)v6[1] + 1, 0xFFFFFFFFFFFFFFFFLL); /*0x102bb147c*/
    if ( result == 0 ) /*0x102bb1485*/
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(a1: v5); /*0x102bb148d*/
      return std::__shared_weak_count::__release_weak(this: v5); /*0x102bb1493*/
    }
  }
  return result; /*0x102bb1498*/
}

// Address: 0x102bb156c | Name: __ZN3RBX12TimerManagerC1Ev
__int64 __fastcall RBX::TimerManager::TimerManager(RBX::TimerManager *this)
{
  return RBX::TimerManager::TimerManager(this); /*0x102bb1570*/
}

// Address: 0x102bb1576 | Name: __ZN3RBX12TimerManagerD2Ev
void __fastcall RBX::TimerManager::~TimerManager(RBX::TimerManager *this)
{
  __int64 v2; // rax
  std::__shared_weak_count *v3; // r15
  std::__shared_weak_count *v4[2]; // [rsp+0h] [rbp-30h] BYREF

  v2 = *((_QWORD *)this + 5) /* +40: NO 2022 FIELD */; /*0x102bb1586*/
  *(_OWORD *)v4 = *((_OWORD *)this + 2); /*0x102bb158e*/
  if ( v2 != 0 ) /*0x102bb1595*/
    _InterlockedIncrement64((volatile signed __int64 *)(v2 + 8)); /*0x102bb1597*/
  RBX::TaskScheduler::removeBlocking(a1: v4); /*0x102bb15a0*/
  v3 = v4[1]; /*0x102bb15a9*/
  if ( v4[1] != nullptr && _InterlockedExchangeAdd64((volatile signed __int64 *)v4[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 ) /*0x102bb15c2*/
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(a1: v3); /*0x102bb15ca*/
    std::__shared_weak_count::__release_weak(this: v3); /*0x102bb15d0*/
  }
  std::shared_ptr<RBX::TimerTickerJob>::~shared_ptr[abi:ne200100](a1: (char *)this + 32 /* +32: NO 2022 FIELD */); /*0x102bb15d8*/
  std::__tree<std::shared_ptr<RBX::TimerData>,RBX::TimerDataComparator,std::allocator<std::shared_ptr<RBX::TimerData>>>::destroy( /*0x102bb15e5*/
    a1: (char *)this + 8 /* +8: NO 2022 FIELD */,
    a2: *((_QWORD *)this + 2) /* +16: NO 2022 FIELD */);
  RSL::Mutex::~Mutex(a1: this); /*0x102bb15ed*/
}

// Address: 0x102bb1606 | Name: __ZN3RBX12TimerManagerD1Ev
void __fastcall RBX::TimerManager::~TimerManager(RBX::TimerManager *this)
{
  RBX::TimerManager::~TimerManager(this); /*0x102bb160b*/
}

// Address: 0x102bb1610 | Name: __ZNK3RBX12TimerManager6getNowEv
__int64 __fastcall RBX::TimerManager::getNow(RBX *this)
{
  return RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: this); /*0x102bb1614*/
}

// Address: 0x102bb161a | Name: __ZN3RBX12TimerManager8isSortedEv
bool __fastcall RBX::TimerManager::isSorted(RBX::TimerManager *this)
{
  _QWORD *v1; // rcx
  char *v2; // rdi
  double v3; // xmm0_8
  double v4; // xmm1_8
  bool result; // al
  _QWORD *v6; // rsi
  _QWORD *v7; // rdx
  bool v8; // zf

  v1 = *((_QWORD **)this + 1); /*0x102bb161a*/
  v2 = (char *)this + 16 /* +16: NO 2022 FIELD */; /*0x102bb161e*/
  if ( v1 == (_QWORD *)v2 ) /*0x102bb1625*/
    return true; /*0x102bb1671*/
  v3 = 0.0; /*0x102bb162b*/
  do /*0x102bb166d*/
  {
    v4 = v3; /*0x102bb162f*/
    v3 = *(double *)(v1[4] + 72LL); /*0x102bb1637*/
    result = v4 <= v3; /*0x102bb1640*/
    if ( v4 > v3 ) /*0x102bb1643*/
      break; /*0x102bb1643*/
    v6 = (_QWORD *)v1[1]; /*0x102bb1645*/
    if ( v6 != nullptr ) /*0x102bb164c*/
    {
      do /*0x102bb1657*/
      {
        v7 = v6; /*0x102bb164e*/
        v6 = (_QWORD *)*v6; /*0x102bb1651*/
      }
      while ( v6 != nullptr ); /*0x102bb1657*/
    }
    else
    {
      do /*0x102bb1665*/
      {
        v7 = (_QWORD *)v1[2]; /*0x102bb165b*/
        v8 = *v7 == (_QWORD)v1; /*0x102bb165f*/
        v1 = v7; /*0x102bb1662*/
      }
      while ( !v8 ); /*0x102bb1665*/
    }
    v1 = v7; /*0x102bb1667*/
  }
  while ( v7 != (_QWORD *)v2 ); /*0x102bb166d*/
  return result; /*0x102bb1670*/
}

// Address: 0x102bb168e | Name: __ZN3RBX12TimerManager4stopERNSt3__110shared_ptrINS_9TimerDataEEE
__int64 __fastcall RBX::TimerManager::stop(RSL::Mutex *this, __int64 a2)
{
  unsigned int v2; // r14d

  RSL::Mutex::lock(this); /*0x102bb169e*/
  LOBYTE(v2) = *(_BYTE *)(*(_QWORD *)a2 + 1LL); /*0x102bb16a6*/
  std::__tree<std::shared_ptr<RBX::TimerData>,RBX::TimerDataComparator,std::allocator<std::shared_ptr<RBX::TimerData>>>::__erase_unique<std::shared_ptr<RBX::TimerData>>( /*0x102bb16b1*/
    a1: (char *)this + 8 /* +8: NO 2022 FIELD */,
    a2);
  RSL::Mutex::unlock(this); /*0x102bb16b9*/
  LOBYTE(v2) = v2 ^ 1; /*0x102bb16be*/
  return v2; /*0x102bb16c9*/
}

// Address: 0x102bb16ee | Name: __ZNK3RBX12TimerManager7invokedERKNSt3__110shared_ptrINS_9TimerDataEEE
__int64 __fastcall RBX::TimerManager::invoked(RSL::Mutex *this, __int64 a2)
{
  RSL::Mutex::lock(this); /*0x102bb16fb*/
  LOBYTE(a2) = *(_BYTE *)(*(_QWORD *)a2 + 1LL); /*0x102bb1703*/
  RSL::Mutex::unlock(this); /*0x102bb1709*/
  return (unsigned int)a2; /*0x102bb1710*/
}

// Address: 0x102bb171e | Name: __ZNK3RBX12TimerManager9isStoppedERKNSt3__110shared_ptrINS_9TimerDataEEE
bool __fastcall RBX::TimerManager::isStopped(RSL::Mutex *this, __int64 a2)
{
  __int64 v4; // rbx

  RSL::Mutex::lock(this); /*0x102bb172b*/
  v4 = std::__tree<std::shared_ptr<RBX::TimerData>,RBX::TimerDataComparator,std::allocator<std::shared_ptr<RBX::TimerData>>>::__count_unique<std::shared_ptr<RBX::TimerData>>( /*0x102bb173c*/
         a1: (char *)this + 8 /* +8: NO 2022 FIELD */,
         a2);
  RSL::Mutex::unlock(this); /*0x102bb1742*/
  return v4 == 0; /*0x102bb174d*/
}

// Address: 0x102bb175a | Name: __ZN3RBX12TimerManager5startERNSt3__110shared_ptrINS_9TimerDataEEEbb
__int64 __fastcall RBX::TimerManager::start(RSL::Mutex *this, __int64 *a2, char a3, char a4)
{
  RBX *v8; // rdi
  double v9; // xmm0_8
  __int64 v10; // rax

  RSL::Mutex::lock(this); /*0x102bb1774*/
  std::__tree<std::shared_ptr<RBX::TimerData>,RBX::TimerDataComparator,std::allocator<std::shared_ptr<RBX::TimerData>>>::__erase_unique<std::shared_ptr<RBX::TimerData>>( /*0x102bb1783*/
    a1: (char *)this + 8 /* +8: NO 2022 FIELD */,
    a2);
  RBX::Time::now<(RBX::Time::SampleMethod)2>(a1: v8); /*0x102bb1788*/
  v10 = *a2; /*0x102bb178d*/
  if ( a4 == 0 ) /*0x102bb1793*/
    v9 = v9 + *(double *)(v10 + 64); /*0x102bb1795*/
  *(double *)(v10 + 72) = v9; /*0x102bb179a*/
  *(_BYTE *)(v10 + 1) = 0; /*0x102bb179f*/
  *(_BYTE *)v10 = a3; /*0x102bb17a3*/
  std::__tree<std::shared_ptr<RBX::TimerData>,RBX::TimerDataComparator,std::allocator<std::shared_ptr<RBX::TimerData>>>::__emplace_unique_key_args<std::shared_ptr<RBX::TimerData>,std::shared_ptr<RBX::TimerData> const&>( /*0x102bb17af*/
    a1: (char *)this + 8 /* +8: NO 2022 FIELD */,
    a2);
  return RSL::Mutex::unlock(this); /*0x102bb17c0*/
}

// Address: 0x103733088 | Name: __ZN3RBX12RbxTransport2Io4Impl12TimerManagerIPNS2_17PollEventReceiverEED1Ev
__int64 __fastcall RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::~TimerManager(
        __int64 a1)
{
  _QWORD v3[3]; // [rsp+8h] [rbp-18h] BYREF

  v3[0] = a1 + 1168; /*0x1037330a1*/
  std::vector<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext,RSL::Detail::Allocator<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext>>::__destroy_vector::operator()[abi:ne200100](a1: v3); /*0x1037330a7*/
  v3[0] = a1 + 584; /*0x1037330b3*/
  std::vector<RBX::RbxTransport::Io::Impl::IdPool::Item,RSL::Detail::Allocator<RBX::RbxTransport::Io::Impl::IdPool::Item>>::__destroy_vector::operator()[abi:ne200100](a1: v3); /*0x1037330b9*/
  v3[0] = a1 + 528; /*0x1037330c5*/
  return std::vector<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext,RSL::Detail::Allocator<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext>>::__destroy_vector::operator()[abi:ne200100](a1: v3); /*0x1037330d1*/
}

// Address: 0x103733d7c | Name: __ZN3RBX12RbxTransport2Io4Impl12TimerManagerIPNS2_17PollEventReceiverEE16takeNextDueTimerEv
__int64 __fastcall RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::takeNextDueTimer(
        __int64 a1)
{
  __int128 *v2; // rdi
  char v3; // al
  __int64 v4; // rax
  __int64 v5; // rcx
  __int128 *v6; // rsi
  __int64 v7; // r8
  _OWORD *v8; // r9
  __int64 v9; // r10
  __int128 v10; // xmm0
  __int128 *v11; // rax
  __int128 v12; // xmm0
  __int128 *v13; // rax
  __int64 v14; // r14
  __int128 *v16; // rdi
  __int64 v17; // rax
  __int64 v18; // rcx
  __int64 v19; // r8
  __int128 *v20; // rsi
  _OWORD *v21; // r9
  __int64 v22; // r10
  __int128 v23; // xmm0
  __int128 *v24; // rax
  __int128 v25; // xmm0
  __int128 v26; // [rsp+0h] [rbp-40h]
  __int128 v27; // [rsp+0h] [rbp-40h]
  __int128 v28; // [rsp+10h] [rbp-30h]
  __int128 v29; // [rsp+10h] [rbp-30h]
  _BYTE v30[25]; // [rsp+27h] [rbp-19h] BYREF

  v2 = *(__int128 **)(a1 + 528); /*0x103733d8c*/
  if ( v2 == *(__int128 **)(a1 + 536) ) /*0x103733d9a*/
    return 0; /*0x103733d9a*/
  while ( 1 ) /*0x103733db6*/
  {
    v3 = RBX::RbxTransport::Io::Impl::IdPool::contains(a1: a1 + 568, a2: *((_QWORD *)v2 + 1), a3: *((_QWORD *)v2 + 2)); /*0x103733db6*/
    v2 = *(__int128 **)(a1 + 528); /*0x103733dbb*/
    if ( v3 != 0 ) /*0x103733dc4*/
      break; /*0x103733dc4*/
    v4 = *(_QWORD *)(a1 + 536); /*0x103733dca*/
    v5 = (v4 - (__int64)v2) >> 5; /*0x103733dd7*/
    if ( v5 >= 2 ) /*0x103733ddf*/
    {
      v28 = v2[1]; /*0x103733ded*/
      v26 = *v2; /*0x103733df1*/
      v6 = *(__int128 **)(a1 + 528); /*0x103733dfd*/
      v7 = 0; /*0x103733e00*/
      do /*0x103733e52*/
      {
        v8 = v6; /*0x103733e03*/
        v6 += 2 * v7 + 2; /*0x103733e10*/
        v9 = 2 * v7 + 1; /*0x103733e14*/
        v7 = 2 * v7 + 2; /*0x103733e1c*/
        if ( v7 >= v5 || *(double *)v6 <= *((double *)v6 + 4) ) /*0x103733e32*/
          v7 = v9; /*0x103733e3a*/
        else
          v6 += 2; /*0x103733e34*/
        v10 = *v6; /*0x103733e3d*/
        v8[1] = v6[1]; /*0x103733e45*/
        *v8 = v10; /*0x103733e4a*/
      }
      while ( v7 <= (__int64)((unsigned __int64)(v5 - 2) >> 1) ); /*0x103733e52*/
      v11 = (__int128 *)(v4 - 32); /*0x103733e54*/
      if ( v6 == v11 ) /*0x103733e5b*/
      {
        v6[1] = v28; /*0x103733e9d*/
        *v6 = v26; /*0x103733ea1*/
      }
      else
      {
        v12 = *v11; /*0x103733e5d*/
        v6[1] = v11[1]; /*0x103733e64*/
        *v6 = v12; /*0x103733e68*/
        *v11 = v26; /*0x103733e78*/
        v11[1] = v28; /*0x103733e7c*/
        std::__sift_up[abi:ne200100]<std::_ClassicAlgPolicy,std::greater<void> &,std::__wrap_iter<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext *>>( /*0x103733e8d*/
          a1: v2,
          a2: v6 + 2,
          a3: v30,
          a4: ((char *)(v6 + 2) - (char *)v2) >> 5);
      }
      v2 = *(__int128 **)(a1 + 528); /*0x103733ea5*/
      v4 = *(_QWORD *)(a1 + 536); /*0x103733eac*/
    }
    v13 = (__int128 *)(v4 - 32); /*0x103733eb3*/
    *(_QWORD *)(a1 + 536) = v13; /*0x103733eb7*/
    if ( v2 == v13 ) /*0x103733ec1*/
      return 0; /*0x103733ec1*/
  }
  if ( *(double *)v2 > *(double *)(a1 + 624) ) /*0x103733ed5*/
    return 0; /*0x103733ed7*/
  RBX::RbxTransport::Io::Impl::IdPool::erase(a1: a1 + 568, a2: *((_QWORD *)v2 + 1), a3: *((_QWORD *)v2 + 2)); /*0x103733ef5*/
  v16 = *(__int128 **)(a1 + 528); /*0x103733efa*/
  v17 = *(_QWORD *)(a1 + 536); /*0x103733f01*/
  v14 = *((_QWORD *)v16 + 3); /*0x103733f08*/
  v18 = (v17 - (__int64)v16) >> 5; /*0x103733f12*/
  if ( v18 >= 2 ) /*0x103733f1a*/
  {
    v29 = v16[1]; /*0x103733f28*/
    v27 = *v16; /*0x103733f2c*/
    v19 = 0; /*0x103733f38*/
    v20 = *(__int128 **)(a1 + 528); /*0x103733f3b*/
    do /*0x103733f8d*/
    {
      v21 = v20; /*0x103733f3e*/
      v20 += 2 * v19 + 2; /*0x103733f4b*/
      v22 = 2 * v19 + 1; /*0x103733f4f*/
      v19 = 2 * v19 + 2; /*0x103733f57*/
      if ( v19 >= v18 || *(double *)v20 <= *((double *)v20 + 4) ) /*0x103733f6d*/
        v19 = v22; /*0x103733f75*/
      else
        v20 += 2; /*0x103733f6f*/
      v23 = *v20; /*0x103733f78*/
      v21[1] = v20[1]; /*0x103733f80*/
      *v21 = v23; /*0x103733f85*/
    }
    while ( v19 <= (__int64)((unsigned __int64)(v18 - 2) >> 1) ); /*0x103733f8d*/
    v24 = (__int128 *)(v17 - 32); /*0x103733f8f*/
    if ( v20 == v24 ) /*0x103733f96*/
    {
      v20[1] = v29; /*0x103733fd9*/
      *v20 = v27; /*0x103733fdd*/
    }
    else
    {
      v25 = *v24; /*0x103733f98*/
      v20[1] = v24[1]; /*0x103733f9f*/
      *v20 = v25; /*0x103733fa3*/
      *v24 = v27; /*0x103733fb3*/
      v24[1] = v29; /*0x103733fb7*/
      std::__sift_up[abi:ne200100]<std::_ClassicAlgPolicy,std::greater<void> &,std::__wrap_iter<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext *>>( /*0x103733fc9*/
        a1: v16,
        a2: v20 + 2,
        a3: v30,
        a4: ((char *)(v20 + 2) - (char *)v16) >> 5);
    }
    v17 = *(_QWORD *)(a1 + 536); /*0x103733fe1*/
  }
  *(_QWORD *)(a1 + 536) = v17 - 32; /*0x103733fec*/
  return v14; /*0x103733edf*/
}

// Address: 0x1037345aa | Name: __ZN3RBX12RbxTransport2Io4Impl12TimerManagerIPNS2_17PollEventReceiverEEC2ENS_4TimeE
__int64 __fastcall RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerManager(
        RSL::Arena *this,
        double a2)
{
  __int64 DefaultArena; // rax
  RSL::Arena *v4; // rdi
  __int64 v5; // rax
  RSL::Arena *v6; // rdi
  __int64 v7; // rax

  DefaultArena = RSL::Arena::getDefaultArena(this); /*0x1037345b8*/
  RSL::SmallVector<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext,16ul>::SmallVector( /*0x1037345c3*/
    a1: this,
    a2: DefaultArena);
  *((_QWORD *)this + 71) /* +568: NO 2022 FIELD */ = 1; /*0x1037345c8*/
  *((_QWORD *)this + 72) /* +576: NO 2022 FIELD */ = -1; /*0x1037345d3*/
  v5 = RSL::Arena::getDefaultArena(this: v4); /*0x1037345de*/
  *(_OWORD *)((char *)this + 584 /* +584: NO 2022 FIELD */) = 0; /*0x1037345e6*/
  *((_QWORD *)this + 75) /* +600: NO 2022 FIELD */ = 0; /*0x1037345ef*/
  *((_QWORD *)this + 76) /* +608: NO 2022 FIELD */ = v5; /*0x1037345f6*/
  *((_QWORD *)this + 77) /* +616: NO 2022 FIELD */ = 0; /*0x1037345fd*/
  *((double *)this + 78) /* +624: NO 2022 FIELD */ = a2; /*0x103734609*/
  *((_BYTE *)this + 632) /* +632: NO 2022 FIELD */ = 0; /*0x103734611*/
  v7 = RSL::Arena::getDefaultArena(this: v6); /*0x10373461f*/
  return RSL::SmallVector<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext,16ul>::SmallVector( /*0x10373462e*/
           a1: (char *)this + 640 /* +640: NO 2022 FIELD */,
           a2: v7);
}

// Address: 0x103734a6a | Name: __ZN3RBX12RbxTransport2Io4Impl12TimerManagerIPNS2_17PollEventReceiverEE23schedulePostponedTimersEv
__int64 __fastcall RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::schedulePostponedTimers(
        _QWORD *a1)
{
  __int64 result; // rax
  __int64 v2; // rsi
  _QWORD *v4; // r14
  char v5; // [rsp-21h] [rbp-21h] BYREF

  v2 = a1[147]; /*0x103734a6a*/
  if ( a1[146] != v2 ) /*0x103734a78*/
  {
    v5 = HIBYTE(result); /*0x103734a83*/
    v4 = a1 + 66; /*0x103734a87*/
    do /*0x103734ada*/
    {
      std::vector<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext,RSL::Detail::Allocator<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext>>::push_back[abi:ne200100]( /*0x103734a99*/
        a1: v4,
        a2: v2 - 32);
      std::__sift_up[abi:ne200100]<std::_ClassicAlgPolicy,std::greater<void> &,std::__wrap_iter<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext *>>( /*0x103734ab9*/
        a1: a1[66],
        a2: a1[67],
        a3: &v5,
        a4: (__int64)(a1[67] - a1[66]) >> 5);
      result = a1[146]; /*0x103734abe*/
      v2 = a1[147] - 32LL; /*0x103734acc*/
      a1[147] = v2; /*0x103734ad0*/
    }
    while ( result != v2 ); /*0x103734ada*/
  }
  return result; /*0x103734ae6*/
}

// Address: 0x10373b0e6 | Name: __ZN3RBX12RbxTransport2Io4Impl12TimerManagerIPNS2_17PollEventReceiverEE8addTimerENSt3__16chrono8durationIxNS7_5ratioILl1ELl1000000000EEEEES5_
__int64 __fastcall RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::addTimer(
        __int64 a1,
        __int64 a2,
        __int64 a3)
{
  __int64 v6; // rbx
  double v7; // rdx
  double v9[4]; // [rsp+0h] [rbp-50h] BYREF
  _BYTE v10[41]; // [rsp+27h] [rbp-29h] BYREF

  v6 = RBX::RbxTransport::Io::Impl::IdPool::add(this: (RBX::RbxTransport::Io::Impl::IdPool *)(a1 + 568)); /*0x10373b10c*/
  v9[0] = (double)(int)(a2 / 1000 - (1000 * (a2 / 1000) > a2)) * 0.000001 + *(double *)(a1 + 624); /*0x10373b158*/
  *(_QWORD *)&v9[1] = v6; /*0x10373b15d*/
  v9[2] = v7; /*0x10373b161*/
  *(_QWORD *)&v9[3] = a3; /*0x10373b165*/
  if ( *(_BYTE *)(a1 + 632) == 1 ) /*0x10373b171*/
  {
    std::vector<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext,RSL::Detail::Allocator<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext>>::push_back[abi:ne200100]( /*0x10373b181*/
      a1: a1 + 1168,
      a2: v9);
  }
  else
  {
    std::vector<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext,RSL::Detail::Allocator<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext>>::push_back[abi:ne200100]( /*0x10373b193*/
      a1: a1 + 528,
      a2: v9);
    std::__sift_up[abi:ne200100]<std::_ClassicAlgPolicy,std::greater<void> &,std::__wrap_iter<RBX::RbxTransport::Io::Impl::TimerManager<RBX::RbxTransport::Io::Impl::PollEventReceiver *>::TimerContext *>>( /*0x10373b1b4*/
      a1: *(_QWORD *)(a1 + 528),
      a2: *(_QWORD *)(a1 + 536),
      a3: v10,
      a4: (__int64)(*(_QWORD *)(a1 + 536) - *(_QWORD *)(a1 + 528)) >> 5);
  }
  return v6; /*0x10373b1bf*/
}

// END TimerManager part 1/1, 17 functions
