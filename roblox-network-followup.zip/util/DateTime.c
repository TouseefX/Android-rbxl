// DateTime -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 10 functions

// Field names below come from the 2022 PDB, which is the only
// build that has them. Each is marked: bare `this->x` was
// corroborated by a store of matching width in that same
// function; UNVERIFIED means the 2022 layout says so and
// nothing target-era has confirmed it.


// Address: 0x10042fff4 | Name: __ZNK3RBX8DateTime22getUnixTimestampMillisEv
__int64 __fastcall RBX::DateTime::getUnixTimestampMillis(RBX::DateTime *this)
{
  const char *v2; // rsi
  __int64 v4; // [rsp+0h] [rbp-30h] BYREF
  unsigned int v5; // [rsp+8h] [rbp-28h] BYREF
  unsigned int v6; // [rsp+Ch] [rbp-24h] BYREF
  unsigned __int64 v7[4]; // [rsp+10h] [rbp-20h] BYREF

  if ( *(_QWORD *)this  /* +0 likely utcTime..time_.time_count_ -- UNVERIFIED */== boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::get_time_rep(a1: 0) ) /*0x10043000e*/
    RBX::throw_runtime_error(this: (RBX *)"Invalid Datetime.\n", a2: v2); /*0x10043008c*/
  boost::gregorian::date::date(a1: &v6, a2: 1970, a3: 1u, a4: 1u); /*0x100430026*/
  v5 = v6; /*0x100430032*/
  v7[0] = 0; /*0x100430038*/
  boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::counted_time_rep( /*0x100430046*/
    a1: (unsigned __int64 *)&v4,
    a2: &v5,
    a3: v7);
  boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::subtract_times( /*0x100430058*/
    a1: v7,
    a2: (__int64 *)this,
    a3: &v4);
  return (signed __int64)v7[0] / 1000; /*0x100430078*/
}

// Address: 0x102a73e0c | Name: __ZN3RBX8DateTime23fromUnixTimestampMillisEx
__int64 __fastcall RBX::DateTime::fromUnixTimestampMillis(__int64 this, __int64 a2)
{
  int v2; // ebx
  __int64 v3; // r14
  int v4; // eax
  __int64 v5; // rdx
  __int64 v6; // r12
  __int64 v7; // r14
  __int64 v9; // [rsp+8h] [rbp-38h] BYREF
  __int64 v10; // [rsp+10h] [rbp-30h] BYREF
  __int64 v11[5]; // [rsp+18h] [rbp-28h] BYREF

  if ( (unsigned __int64)(this - 253402300800000LL) <= 0xFFFF092C26B693FFLL ) /*0x102a73e35*/
    RBX::throw_runtime_error( /*0x102a73ee5*/
      this: (RBX *)"Error interpreting timestampMillis as a precise point in time. Fields out of range. UnixTimestampMillis sho"
             "uld be between %lld and %lld.",
      a2: (const char *)0xFFFFEFA3F8D67000LL,
      0xE677D21FDBFFLL);
  v2 = this; /*0x102a73e3b*/
  v3 = this / 1000; /*0x102a73e5c*/
  v9 = RBX::DateTime::fromUnixTimestamp(this: (RBX::DateTime *)(this / 1000), a2); /*0x102a73e6b*/
  v4 = (int)((double)(v2 - 1000 * (int)v3) * 1000.0); /*0x102a73e86*/
  v10 = v5; /*0x102a73e8a*/
  v6 = v4; /*0x102a73e8d*/
  v11[0] = v4; /*0x102a73e94*/
  v7 = boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::add_time_duration( /*0x102a73ea3*/
         a1: &v9,
         a2: v11);
  v11[0] = v6; /*0x102a73ea6*/
  boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::add_time_duration( /*0x102a73eb0*/
    a1: &v10,
    a2: v11);
  return v7; /*0x102a73ebb*/
}

// Address: 0x102a73eea | Name: __ZN3RBX8DateTime3nowEv
__int64 __fastcall RBX::DateTime::now(RBX::DateTime *this)
{
  __int64 v1; // r14
  _QWORD v3[3]; // [rsp+8h] [rbp-18h] BYREF

  v3[0] = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(a1: (__int64 (__fastcall *)(__darwin_time_t *, _BYTE *))rsl_gmtime_r); /*0x102a73f05*/
  v1 = RBX::roundPtimeToMillis(a1: v3); /*0x102a73f10*/
  v3[0] = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(a1: (__int64 (__fastcall *)(__darwin_time_t *, _BYTE *))rsl_localtime_r); /*0x102a73f1f*/
  RBX::roundPtimeToMillis(a1: v3); /*0x102a73f26*/
  return v1; /*0x102a73f31*/
}

// Address: 0x102a7414a | Name: __ZN3RBX8DateTime17fromUnixTimestampEx
unsigned __int64 __fastcall RBX::DateTime::fromUnixTimestamp(RBX::DateTime *this, __int64 a2)
{
  unsigned __int64 PtimeFromTimestamp; // rbx
  unsigned int v4[9]; // [rsp+8h] [rbp-58h] BYREF
  unsigned int v5[13]; // [rsp+2Ch] [rbp-34h] BYREF

  if ( (unsigned __int64)this - 0x3AFFF44180LL <= 0xFFFFFFC0CFE9247FLL ) /*0x102a7416f*/
    RBX::throw_runtime_error( /*0x102a741ea*/
      this: (RBX *)"Error interpreting timestamp as a precise point in time. Fields out of range. UnixTimestamp should be betwe"
             "en %lld and %lld.",
      a2: (const char *)0xFFFFFFFBCFDD6600LL,
      0x3AFFF4417FLL);
  if ( (unsigned __int64)this >> 7 > 0xF267FFE ) /*0x102a74181*/
  {
    PtimeFromTimestamp = RBX::getPtimeFromTimestamp(this, a2); /*0x102a741b3*/
    RBX::utcToLocal(a1: PtimeFromTimestamp); /*0x102a741b9*/
  }
  else
  {
    RBX::getTmFromTimestamp(a1: v4, a2: v5, a3: this); /*0x102a74191*/
    PtimeFromTimestamp = boost::posix_time::ptime_from_tm(a1: v4); /*0x102a7419e*/
    boost::posix_time::ptime_from_tm(a1: v5); /*0x102a741a4*/
  }
  return PtimeFromTimestamp; /*0x102a741c4*/
}

// Address: 0x102a74648 | Name: __ZNK3RBX8DateTime9toIsoDateEv
RBX::DateTime *__fastcall RBX::DateTime::toIsoDate(RBX::DateTime *this, __int64 a2)
{
  std::locale::facet *v3; // r15
  const std::locale *v4; // r12
  std::locale *v5; // rdi
  const std::locale *v6; // r13
  __int64 v7; // rax
  __int64 v8; // r15
  const std::locale *v9; // r15
  RBX::DateTime *v10; // rbx
  _QWORD v12[2]; // [rsp+8h] [rbp-1E8h] BYREF
  __int64 (__fastcall **v13)(); // [rsp+18h] [rbp-1D8h] BYREF
  __int64 (__fastcall **v14)(); // [rsp+20h] [rbp-1D0h] BYREF
  _BYTE v15[72]; // [rsp+28h] [rbp-1C8h] BYREF
  void *v16; // [rsp+70h] [rbp-180h]
  __int64 (__fastcall **v17)(); // [rsp+88h] [rbp-168h] BYREF
  _QWORD v18[3]; // [rsp+120h] [rbp-D0h] BYREF
  int v19; // [rsp+138h] [rbp-B8h] BYREF
  char v20; // [rsp+140h] [rbp-B0h]
  void *v21; // [rsp+150h] [rbp-A0h]
  char v22; // [rsp+158h] [rbp-98h]
  void *v23; // [rsp+168h] [rbp-88h]
  char v24; // [rsp+170h] [rbp-80h]
  void *v25; // [rsp+180h] [rbp-70h]
  char v26; // [rsp+188h] [rbp-68h]
  void *v27; // [rsp+198h] [rbp-58h]
  char v28[8]; // [rsp+1A0h] [rbp-50h] BYREF
  RBX::DateTime *v29; // [rsp+1A8h] [rbp-48h]
  char v30[8]; // [rsp+1B0h] [rbp-40h] BYREF
  _QWORD *v31; // [rsp+1B8h] [rbp-38h] BYREF
  _BYTE v32[48]; // [rsp+1C0h] [rbp-30h] BYREF

  v29 = this; /*0x102a7465f*/
  RBX::detail::validateDateTimePtime(a1: a2); /*0x102a74666*/
  v3 = (std::locale::facet *)operator new(a1: 0x168u); /*0x102a74675*/
  boost::date_time::period_formatter<char,std::ostreambuf_iterator<char>>::period_formatter( /*0x102a746a0*/
    a1: &v19,
    a2: 1,
    a3: "/",
    a4: "[",
    a5: ")",
    a6: "]");
  boost::date_time::special_values_formatter<char,std::ostreambuf_iterator<char>>::special_values_formatter(a1: (__int64)v12); /*0x102a746af*/
  boost::date_time::date_generator_formatter<boost::gregorian::date,char,std::ostreambuf_iterator<char>>::date_generator_formatter(a1: (__int64)v18); /*0x102a746bb*/
  boost::date_time::time_facet<boost::posix_time::ptime,char,std::ostreambuf_iterator<char>>::time_facet( /*0x102a746e8*/
    a1: (__int64)v3,
    a2: "%Y-%m-%dT%TZ",
    a3: (__int64)&v19,
    a4: v12,
    a5: v18,
    a6: 0);
  v31 = v18; /*0x102a746f1*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: &v31); /*0x102a746f8*/
  v31 = v12; /*0x102a746fd*/
  std::vector<std::string>::__destroy_vector::operator()[abi:ne200100](a1: &v31); /*0x102a74705*/
  if ( (v26 & 1) != 0 ) /*0x102a7470e*/
    operator delete(a1: v27); /*0x102a74714*/
  if ( (v24 & 1) != 0 ) /*0x102a7471d*/
    operator delete(a1: v25); /*0x102a74723*/
  if ( (v22 & 1) != 0 ) /*0x102a7472f*/
    operator delete(a1: v23); /*0x102a74738*/
  if ( (v20 & 1) != 0 ) /*0x102a74744*/
    operator delete(a1: v21); /*0x102a7474d*/
  std::basic_stringstream<char,std::char_traits<char>,std::allocator<char>>::basic_stringstream[abi:ne200100](a1: v12); /*0x102a74755*/
  v4 = (const std::locale *)((char *)v12 + *(_QWORD *)(v12[0] - 24LL)); /*0x102a74761*/
  v6 = (const std::locale *)std::locale::classic(this: v5); /*0x102a7476a*/
  v7 = std::locale::id::__get(this: (std::locale::id *)boost::date_time::time_facet<boost::posix_time::ptime,char,std::ostreambuf_iterator<char>>::id); /*0x102a74774*/
  std::locale::__install_ctor(this: (std::locale *)v32, a2: v6, a3: v3, a4: v7); /*0x102a74786*/
  std::ios_base::getloc(this: (std::ios_base *)v30); /*0x102a74792*/
  std::ios_base::imbue(this: (std::ios_base *)&v31, a2: v4); /*0x102a747a2*/
  std::locale::~locale(this: (std::locale *)&v31); /*0x102a747ab*/
  v8 = *((_QWORD *)v4 + 5); /*0x102a747b0*/
  if ( v8 != 0 ) /*0x102a747b8*/
  {
    (*(void (__fastcall **)(_QWORD, _BYTE *))(*(_QWORD *)v8 + 16LL))(a1: *((_QWORD *)v4 + 5), a2: v32); /*0x102a747c4*/
    v9 = (const std::locale *)(v8 + 8); /*0x102a747c7*/
    std::locale::locale(this: (std::locale *)v28, a2: v9); /*0x102a747d5*/
    std::locale::operator=(a1: v9, a2: v32); /*0x102a747e1*/
    std::locale::~locale(this: (std::locale *)v28); /*0x102a747e9*/
  }
  std::locale::~locale(this: (std::locale *)v30); /*0x102a747f2*/
  std::locale::~locale(this: (std::locale *)v32); /*0x102a747fb*/
  boost::posix_time::operator<<<char,std::char_traits<char>>(a1: &v13, a2); /*0x102a7480a*/
  v10 = v29; /*0x102a7480f*/
  std::stringbuf::str(a1: v29, a2: &v14); /*0x102a7481d*/
  v12[0] = &off_10C798D68; /*0x102a74834*/
  v17 = off_10C798DB8; /*0x102a7483c*/
  v13 = off_10C798D90; /*0x102a74843*/
  v14 = &off_10C799250; /*0x102a74852*/
  if ( (v15[56] & 1) != 0 ) /*0x102a7485b*/
    operator delete(a1: v16); /*0x102a74864*/
  v14 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x102a7487b*/
  std::locale::~locale(this: (std::locale *)v15); /*0x102a7487f*/
  std::iostream::~iostream(a1: v12, a2: off_10C799178); /*0x102a74896*/
  std::ios::~ios(a1: &v17); /*0x102a7489e*/
  return v10; /*0x102a748a6*/
}

// Address: 0x102a7492e | Name: __ZN3RBX8DateTime14fromComponentsEiiiiiiiNS0_4KindE
__int64 __fastcall RBX::DateTime::fromComponents(
        unsigned __int16 a1,
        unsigned __int16 a2,
        unsigned __int16 a3,
        int a4,
        int a5,
        int a6,
        int a7,
        int a8)
{
  signed __int64 v13; // rbx
  __int64 v14; // rcx
  int v15; // esi
  unsigned int v16; // edi
  __int64 v17; // r14
  __int64 v18; // rax
  signed __int64 v19; // rdi
  __int64 *v20; // rsi
  unsigned __int64 *v21; // rdi
  __int64 v23[5]; // [rsp+0h] [rbp-F0h] BYREF
  unsigned int v24[10]; // [rsp+28h] [rbp-C8h] BYREF
  __int128 v25; // [rsp+50h] [rbp-A0h] BYREF
  int v26; // [rsp+60h] [rbp-90h]
  int v27; // [rsp+64h] [rbp-8Ch]
  __int64 v28; // [rsp+68h] [rbp-88h]
  int v29; // [rsp+70h] [rbp-80h]
  __int64 v30; // [rsp+80h] [rbp-70h] BYREF
  __int64 time_rep; // [rsp+88h] [rbp-68h] BYREF
  unsigned __int64 v32; // [rsp+90h] [rbp-60h] BYREF
  __int128 v33; // [rsp+98h] [rbp-58h] BYREF
  int v34; // [rsp+A8h] [rbp-48h]
  int v35; // [rsp+ACh] [rbp-44h]
  __int64 v36; // [rsp+B0h] [rbp-40h]
  int v37; // [rsp+B8h] [rbp-38h]
  int v38; // [rsp+BCh] [rbp-34h]
  unsigned __int64 v39[6]; // [rsp+C0h] [rbp-30h] BYREF

  v38 = a6; /*0x102a74942*/
  time_rep = boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::get_time_rep(a1: 0); /*0x102a7495b*/
  LOWORD(v33) = 1400; /*0x102a74963*/
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1400,(unsigned short)10000,boost::gregorian::bad_year>>::assign( /*0x102a7496b*/
    a1: &v33,
    a2: a1);
  LOWORD(v25) = 1; /*0x102a74977*/
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1,(unsigned short)12,boost::gregorian::bad_month>>::assign( /*0x102a74980*/
    a1: &v25,
    a2);
  LOWORD(v24[0]) = 1; /*0x102a7498c*/
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1,(unsigned short)31,boost::gregorian::bad_day_of_month>>::assign( /*0x102a74995*/
    a1: v24,
    a2: a3);
  boost::gregorian::date::date(a1: v23, a2: v33, a3: v25, a4: v24[0]); /*0x102a749b3*/
  *(_QWORD *)&v25 = boost::date_time::time_resolution_traits<boost::date_time::time_resolution_traits_adapted64_impl,(boost::date_time::time_resolutions)5,1000000ll,(unsigned short)6,int>::to_tick_count( /*0x102a749d7*/
                      a1: a4,
                      a2: a5,
                      a3: v38,
                      a4: 1000 * a7);
  v24[0] = v23[0]; /*0x102a749e7*/
  boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::counted_time_rep( /*0x102a749ed*/
    a1: (unsigned __int64 *)&v33,
    a2: v24,
    a3: (unsigned __int64 *)&v25);
  v13 = v33; /*0x102a749f6*/
  time_rep = v33; /*0x102a749fe*/
  RBX::detail::validateDateTimePtime(a1: &time_rep); /*0x102a74a01*/
  if ( a8 != 0 ) /*0x102a74a09*/
  {
    if ( a8 == 1 ) /*0x102a74a0f*/
    {
      v39[0] = v13; /*0x102a74a1b*/
      if ( (unsigned __int64)(v13 - 0x7FFFFFFFFFFFFFFELL) > 2 ) /*0x102a74a35*/
      {
        v14 = v13 % 86400000000LL; /*0x102a74ab6*/
        v15 = v13 % 86400000000LL / 1000000 % 60; /*0x102a74afa*/
        v16 = v13 % 86400000000LL / 60000000 % 60; /*0x102a74b2d*/
      }
      else
      {
        v14 = 0x7FFFFFFFFFFFFFFELL; /*0x102a74a3b*/
        v15 = 54; /*0x102a74a47*/
        if ( v13 == 0x8000000000000000LL ) /*0x102a74a4c*/
        {
          v15 = -54; /*0x102a74a4c*/
          v14 = 0x8000000000000000LL; /*0x102a74a4f*/
        }
        if ( v13 == 0x7FFFFFFFFFFFFFFFLL ) /*0x102a74a56*/
          v14 = 0x7FFFFFFFFFFFFFFFLL; /*0x102a74a56*/
        v16 = 0; /*0x102a74a5a*/
      }
      *(_QWORD *)&v33 = __PAIR64__(v16, v15); /*0x102a74b30*/
      DWORD2(v33) = v14 / 3600000000LL; /*0x102a74b56*/
      LODWORD(v25) = boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::date(a1: v39); /*0x102a74b6c*/
      HIDWORD(v33) = (unsigned __int16)boost::date_time::date<boost::gregorian::date,boost::gregorian::gregorian_calendar,boost::gregorian::date_duration>::day(a1: &v25); /*0x102a74b7a*/
      v24[0] = boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::date(a1: v39); /*0x102a74b8c*/
      v34 = (unsigned __int16)boost::date_time::date<boost::gregorian::date,boost::gregorian::gregorian_calendar,boost::gregorian::date_duration>::month(a1: v24) /*0x102a74b98*/
          - 1;
      LODWORD(v23[0]) = boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::date(a1: v39); /*0x102a74baa*/
      v35 = (unsigned __int16)boost::date_time::date<boost::gregorian::date,boost::gregorian::gregorian_calendar,boost::gregorian::date_duration>::year(a1: v23) /*0x102a74bb9*/
          - 1900;
      v36 = 0; /*0x102a74bbc*/
      v37 = 0; /*0x102a74bc6*/
      v29 = 0; /*0x102a74bc9*/
      v26 = v34; /*0x102a74bd0*/
      v27 = v35; /*0x102a74bd7*/
      v28 = 0; /*0x102a74bdf*/
      v25 = v33; /*0x102a74be7*/
      if ( rsl_mktime(a1: &v25) <= 0 ) /*0x102a74bfa*/
      {
        v23[0] = boost::date_time::second_clock<boost::posix_time::ptime>::universal_time(); /*0x102a74c66*/
        v30 = boost::date_time::second_clock<boost::posix_time::ptime>::local_time(); /*0x102a74c72*/
        boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::subtract_times( /*0x102a74c7f*/
          a1: &v32,
          a2: v23,
          a3: &v30);
        v20 = (__int64 *)v24; /*0x102a74c87*/
        *(_QWORD *)v24 = v32; /*0x102a74c8e*/
        v21 = v39; /*0x102a74c91*/
      }
      else
      {
        v37 = v29; /*0x102a74c03*/
        v18 = rsl_mktime(a1: &v33); /*0x102a74c06*/
        RBX::getTmFromTimestamp(a1: v24, a2: v23, a3: v18); /*0x102a74c1f*/
        v32 = boost::posix_time::ptime_from_tm(a1: v24); /*0x102a74c2c*/
        if ( v39[0] - 0x7FFFFFFFFFFFFFFELL > 2 ) /*0x102a74c40*/
        {
          v19 = (signed __int64)v39[0] % 86400000000LL; /*0x102a74cc6*/
        }
        else
        {
          v19 = 0x7FFFFFFFFFFFFFFELL; /*0x102a74c46*/
          if ( v39[0] == 0x8000000000000000LL ) /*0x102a74c4d*/
            v19 = 0x8000000000000000LL; /*0x102a74c4d*/
          if ( v39[0] == 0x7FFFFFFFFFFFFFFFLL ) /*0x102a74c54*/
            v19 = 0x7FFFFFFFFFFFFFFFLL; /*0x102a74c54*/
        }
        v20 = &v30; /*0x102a74ce7*/
        v30 = v19 % 1000000; /*0x102a74ceb*/
        v21 = &v32; /*0x102a74cee*/
      }
      return boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::add_time_duration( /*0x102a74cf7*/
               a1: (__int64 *)v21,
               a2: v20);
    }
    else
    {
      v17 = boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::get_time_rep(a1: 0); /*0x102a74a75*/
      boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::get_time_rep(a1: 0); /*0x102a74a7a*/
    }
  }
  else
  {
    RBX::utcToLocal(a1: v13); /*0x102a74a64*/
    return v13; /*0x102a74a69*/
  }
  return v17; /*0x102a74d00*/
}

// Address: 0x102a74d4a | Name: __ZN3RBX8DateTime11fromIsoDateERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall RBX::DateTime::fromIsoDate(__int64 a1)
{
  std::locale::facet *v1; // r14
  std::locale *v2; // rdi
  const std::locale *v3; // rbx
  const std::locale *v4; // r15
  __int64 v5; // rax
  __int64 v6; // rbx
  const std::locale *v7; // rbx
  _QWORD *v8; // rax
  const char *v9; // rsi
  __int64 v10; // r14
  _QWORD v12[2]; // [rsp+8h] [rbp-178h] BYREF
  __int64 (__fastcall **v13)(); // [rsp+18h] [rbp-168h]
  _BYTE v14[72]; // [rsp+20h] [rbp-160h] BYREF
  void *v15; // [rsp+68h] [rbp-118h]
  __int64 (__fastcall **v16)(); // [rsp+80h] [rbp-100h] BYREF
  __int64 v17; // [rsp+118h] [rbp-68h] BYREF
  __int128 v18; // [rsp+120h] [rbp-60h] BYREF
  unsigned int v19; // [rsp+134h] [rbp-4Ch] BYREF
  unsigned __int64 v20; // [rsp+138h] [rbp-48h] BYREF
  _BYTE v21[8]; // [rsp+140h] [rbp-40h] BYREF
  char v22[8]; // [rsp+148h] [rbp-38h] BYREF
  __int128 v23; // [rsp+150h] [rbp-30h] BYREF
  unsigned __int64 v24[4]; // [rsp+160h] [rbp-20h] BYREF

  std::istringstream::basic_istringstream[abi:ne200100](a1: v12, a2: a1, a3: 8); /*0x102a74d6c*/
  v1 = (std::locale::facet *)operator new(a1: 0x180u); /*0x102a74d7b*/
  std::string::basic_string[abi:ne200100]<0>(a1: v22, a2: "%Y-%m-%d %H:%M:%S%F %ZP"); /*0x102a74d89*/
  boost::date_time::time_input_facet<boost::posix_time::ptime,char,std::istreambuf_iterator<char>>::time_input_facet(a1: v1); /*0x102a74d97*/
  if ( (v22[0] & 1) != 0 ) /*0x102a74da0*/
    operator delete(a1: *((void **)&v23 + 1)); /*0x102a74da6*/
  v3 = (const std::locale *)((char *)v12 + *(_QWORD *)(v12[0] - 24LL)); /*0x102a74db2*/
  v4 = (const std::locale *)std::locale::classic(this: v2); /*0x102a74dbb*/
  v5 = std::locale::id::__get(this: (std::locale::id *)boost::date_time::time_input_facet<boost::posix_time::ptime,char,std::istreambuf_iterator<char>>::id); /*0x102a74dc5*/
  std::locale::__install_ctor(this: (std::locale *)v24, a2: v4, a3: v1, a4: v5); /*0x102a74dd7*/
  std::ios_base::getloc(this: (std::ios_base *)v21); /*0x102a74de3*/
  std::ios_base::imbue(this: (std::ios_base *)v22, a2: v3); /*0x102a74df3*/
  std::locale::~locale(this: (std::locale *)v22); /*0x102a74dfc*/
  v6 = *((_QWORD *)v3 + 5); /*0x102a74e01*/
  if ( v6 != 0 ) /*0x102a74e08*/
  {
    (*(void (__fastcall **)(__int64, unsigned __int64 *))(*(_QWORD *)v6 + 16LL))(a1: v6, a2: v24); /*0x102a74e14*/
    v7 = (const std::locale *)(v6 + 8); /*0x102a74e17*/
    std::locale::locale(this: (std::locale *)&v20, a2: v7); /*0x102a74e25*/
    std::locale::operator=(a1: v7, a2: v24); /*0x102a74e31*/
    std::locale::~locale(this: (std::locale *)&v20); /*0x102a74e39*/
  }
  std::locale::~locale(this: (std::locale *)v21); /*0x102a74e42*/
  std::locale::~locale(this: (std::locale *)v24); /*0x102a74e4b*/
  v18 = 0; /*0x102a74e53*/
  *(_QWORD *)v22 = boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::get_time_rep(a1: 0); /*0x102a74e62*/
  v23 = 0; /*0x102a74e6d*/
  boost::detail::shared_count::~shared_count(this: (volatile signed __int32 **)&v18 + 1); /*0x102a74e71*/
  v19 = -2; /*0x102a74e7a*/
  v24[0] = 0x7FFFFFFFFFFFFFFELL; /*0x102a74e8e*/
  boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::counted_time_rep( /*0x102a74e95*/
    a1: &v20,
    a2: &v19,
    a3: v24);
  v8 = boost::local_time::operator>><char,std::char_traits<char>>(a1: v12, a2: (__int64)v22); /*0x102a74ea5*/
  if ( (*((_BYTE *)v8 + *(_QWORD *)(*v8 - 24LL) + 32) & 5) != 0 ) /*0x102a74eb6*/
    RBX::throw_runtime_error(this: (RBX *)"Invalid ISO 8601 date.\n", a2: v9); /*0x102a74f74*/
  v10 = *(_QWORD *)v22; /*0x102a74ebc*/
  v17 = *(_QWORD *)v22; /*0x102a74ec4*/
  RBX::detail::validateDateTimePtime(a1: &v17); /*0x102a74ec7*/
  RBX::utcToLocal(a1: v10); /*0x102a74ecf*/
  boost::detail::shared_count::~shared_count(this: (volatile signed __int32 **)&v23 + 1); /*0x102a74eda*/
  v12[0] = &off_10C8B6848; /*0x102a74ef1*/
  v16 = off_10C8B6870; /*0x102a74ef9*/
  v13 = &off_10C799250; /*0x102a74f07*/
  if ( (v14[56] & 1) != 0 ) /*0x102a74f0f*/
    operator delete(a1: v15); /*0x102a74f18*/
  v13 = (__int64 (__fastcall **)())((char *)&`vtable for'std::streambuf + 16); /*0x102a74f2f*/
  std::locale::~locale(this: (std::locale *)v14); /*0x102a74f33*/
  std::istream::~istream(a1: v12, a2: off_10C8B6888); /*0x102a74f4a*/
  std::ios::~ios(a1: &v16); /*0x102a74f52*/
  return v10; /*0x102a74f5d*/
}

// Address: 0x102a7555c | Name: __ZNK3RBX8DateTime16getUnixTimestampEv
__int64 __fastcall RBX::DateTime::getUnixTimestamp(RBX::DateTime *this)
{
  const char *v2; // rsi
  unsigned __int64 v4[3]; // [rsp+8h] [rbp-18h] BYREF

  if ( *(_QWORD *)this  /* +0 likely utcTime..time_.time_count_ -- UNVERIFIED */== boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::get_time_rep(a1: 0) ) /*0x102a75574*/
    RBX::throw_runtime_error(this: (RBX *)"Invalid Datetime.\n", a2: v2); /*0x102a755b9*/
  boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::subtract_times( /*0x102a75587*/
    a1: v4,
    a2: (__int64 *)this,
    a3: &RBX::START_PTIME);
  return (signed __int64)v4[0] / 1000000; /*0x102a755a7*/
}

// Address: 0x102a755be | Name: __ZNK3RBX8DateTime21getDateTimeValueTableENS0_4KindE
_OWORD *__fastcall RBX::DateTime::getDateTimeValueTable(_OWORD *a1, __int64 a2, int a3)
{
  _BOOL8 v5; // rbx
  __int64 *v6; // r14
  unsigned __int8 *v7; // r14
  __int64 v8; // rdi
  __int64 *v9; // r14
  unsigned __int8 *v10; // r14
  __int64 v11; // rdi
  __int64 *v12; // r14
  unsigned __int8 *v13; // r14
  __int64 v14; // rdi
  __int64 v15; // rsi
  __int64 *v16; // r14
  unsigned __int8 *v17; // r14
  __int64 v18; // rdi
  __int64 v19; // rsi
  __int64 *v20; // r14
  unsigned __int8 *v21; // r14
  __int64 v22; // rdi
  __int64 v23; // rax
  __int64 *v24; // r14
  unsigned __int8 *v25; // r14
  __int64 v26; // rdi
  __int64 v27; // rsi
  __int64 v28; // rsi
  int v29; // ecx
  __int64 *v30; // r14
  unsigned __int8 *v31; // r14
  __int64 v32; // rdi
  std::__shared_weak_count *v33; // rax
  std::__shared_weak_count *v34; // r14
  std::__shared_weak_count *v36[2]; // [rsp+10h] [rbp-70h] BYREF
  unsigned __int8 *v37; // [rsp+20h] [rbp-60h] BYREF
  __int64 v38; // [rsp+28h] [rbp-58h] BYREF
  unsigned __int8 v39[16]; // [rsp+30h] [rbp-50h] BYREF
  void *v40; // [rsp+40h] [rbp-40h]
  int v41; // [rsp+4Ch] [rbp-34h] BYREF
  char v42; // [rsp+53h] [rbp-2Dh] BYREF
  _DWORD v43[11]; // [rsp+54h] [rbp-2Ch] BYREF

  v5 = a3 != 0; /*0x102a755d9*/
  RBX::make_shared<RBX::Reflection::ValueTable>(a1: (RSL::Arena *)v36); /*0x102a755e0*/
  v38 = *(_QWORD *)(a2 + 8 * v5); /*0x102a755ed*/
  RBX::detail::validateDateTimePtime(a1: &v38); /*0x102a755f0*/
  v41 = boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::date(a1: (unsigned __int64 *)&v38); /*0x102a75602*/
  v43[0] = (unsigned __int16)boost::date_time::date<boost::gregorian::date,boost::gregorian::gregorian_calendar,boost::gregorian::date_duration>::year(a1: &v41); /*0x102a7560c*/
  v6 = (__int64 *)v36[0]; /*0x102a7560f*/
  std::string::basic_string[abi:ne200100]<0>(a1: v39, a2: "Year"); /*0x102a75621*/
  v37 = v39; /*0x102a7562a*/
  v7 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x102a75643*/
         a1: v6,
         a2: v39,
         a3: (__int64)std::piecewise_construct,
         a4: (__int64)&v37,
         a5: (__int64)&v42);
  *((_QWORD *)v7 + 5) = RBX::Reflection::Type::getSingleton<int>(a1: v8); /*0x102a7564b*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int,(int *)0>(a1: v7 + 48, a2: v43); /*0x102a7565a*/
  if ( (v39[0] & 1) != 0 ) /*0x102a75663*/
    operator delete(a1: v40); /*0x102a75669*/
  v41 = boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::date(a1: (unsigned __int64 *)&v38); /*0x102a7567b*/
  v43[0] = (unsigned __int16)boost::date_time::date<boost::gregorian::date,boost::gregorian::gregorian_calendar,boost::gregorian::date_duration>::month(a1: &v41); /*0x102a75685*/
  v9 = (__int64 *)v36[0]; /*0x102a75688*/
  std::string::basic_string[abi:ne200100]<0>(a1: v39, a2: "Month"); /*0x102a75696*/
  v37 = v39; /*0x102a7569f*/
  v10 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x102a756b8*/
          a1: v9,
          a2: v39,
          a3: (__int64)std::piecewise_construct,
          a4: (__int64)&v37,
          a5: (__int64)&v42);
  *((_QWORD *)v10 + 5) = RBX::Reflection::Type::getSingleton<int>(a1: v11); /*0x102a756c0*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int,(int *)0>(a1: v10 + 48, a2: v43); /*0x102a756cf*/
  if ( (v39[0] & 1) != 0 ) /*0x102a756d8*/
    operator delete(a1: v40); /*0x102a756de*/
  v41 = boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>::date(a1: (unsigned __int64 *)&v38); /*0x102a756f0*/
  v43[0] = (unsigned __int16)boost::date_time::date<boost::gregorian::date,boost::gregorian::gregorian_calendar,boost::gregorian::date_duration>::day(a1: &v41); /*0x102a756fa*/
  v12 = (__int64 *)v36[0]; /*0x102a756fd*/
  std::string::basic_string[abi:ne200100]<0>(a1: v39, a2: "Day"); /*0x102a7570b*/
  v37 = v39; /*0x102a75714*/
  v13 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x102a7572d*/
          a1: v12,
          a2: v39,
          a3: (__int64)std::piecewise_construct,
          a4: (__int64)&v37,
          a5: (__int64)&v42);
  *((_QWORD *)v13 + 5) = RBX::Reflection::Type::getSingleton<int>(a1: v14); /*0x102a75735*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int,(int *)0>(a1: v13 + 48, a2: v43); /*0x102a75744*/
  if ( (v39[0] & 1) != 0 ) /*0x102a7574d*/
    operator delete(a1: v40); /*0x102a75753*/
  if ( (unsigned __int64)(v38 - 0x7FFFFFFFFFFFFFFELL) > 2 ) /*0x102a75772*/
  {
    v15 = v38 % 86400000000LL; /*0x102a757bd*/
  }
  else
  {
    v15 = 0x7FFFFFFFFFFFFFFELL; /*0x102a75779*/
    if ( v38 == 0x8000000000000000LL ) /*0x102a75781*/
      v15 = 0x8000000000000000LL; /*0x102a75781*/
    if ( v38 == 0x7FFFFFFFFFFFFFFFLL ) /*0x102a75788*/
      v15 = 0x7FFFFFFFFFFFFFFFLL; /*0x102a75788*/
  }
  v43[0] = v15 / 3600000000LL; /*0x102a757e0*/
  v16 = (__int64 *)v36[0]; /*0x102a757e3*/
  std::string::basic_string[abi:ne200100]<0>(a1: v39, a2: "Hour"); /*0x102a757f1*/
  v37 = v39; /*0x102a757fa*/
  v17 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x102a75813*/
          a1: v16,
          a2: v39,
          a3: (__int64)std::piecewise_construct,
          a4: (__int64)&v37,
          a5: (__int64)&v41);
  *((_QWORD *)v17 + 5) = RBX::Reflection::Type::getSingleton<int>(a1: v18); /*0x102a7581b*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int,(int *)0>(a1: v17 + 48, a2: v43); /*0x102a7582a*/
  if ( (v39[0] & 1) != 0 ) /*0x102a75833*/
    operator delete(a1: v40); /*0x102a75839*/
  if ( (unsigned __int64)(v38 - 0x7FFFFFFFFFFFFFFELL) > 2 ) /*0x102a75852*/
  {
    v19 = v38 % 86400000000LL; /*0x102a7589d*/
  }
  else
  {
    v19 = 0x7FFFFFFFFFFFFFFELL; /*0x102a75859*/
    if ( v38 == 0x8000000000000000LL ) /*0x102a75861*/
      v19 = 0x8000000000000000LL; /*0x102a75861*/
    if ( v38 == 0x7FFFFFFFFFFFFFFFLL ) /*0x102a75868*/
      v19 = 0x7FFFFFFFFFFFFFFFLL; /*0x102a75868*/
  }
  v43[0] = v19 / 60000000 % 60; /*0x102a758e9*/
  v20 = (__int64 *)v36[0]; /*0x102a758ec*/
  std::string::basic_string[abi:ne200100]<0>(a1: v39, a2: "Minute"); /*0x102a758fa*/
  v37 = v39; /*0x102a75903*/
  v21 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x102a7591c*/
          a1: v20,
          a2: v39,
          a3: (__int64)std::piecewise_construct,
          a4: (__int64)&v37,
          a5: (__int64)&v41);
  *((_QWORD *)v21 + 5) = RBX::Reflection::Type::getSingleton<int>(a1: v22); /*0x102a75924*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int,(int *)0>(a1: v21 + 48, a2: v43); /*0x102a75933*/
  if ( (v39[0] & 1) != 0 ) /*0x102a7593c*/
    operator delete(a1: v40); /*0x102a75942*/
  if ( (unsigned __int64)(v38 - 0x7FFFFFFFFFFFFFFELL) > 2 ) /*0x102a75957*/
  {
    v23 = v38 % 86400000000LL; /*0x102a759a2*/
  }
  else
  {
    v23 = 0x7FFFFFFFFFFFFFFELL; /*0x102a7595e*/
    if ( v38 == 0x8000000000000000LL ) /*0x102a75966*/
      v23 = 0x8000000000000000LL; /*0x102a75966*/
    if ( v38 == 0x7FFFFFFFFFFFFFFFLL ) /*0x102a7596d*/
      v23 = 0x7FFFFFFFFFFFFFFFLL; /*0x102a7596d*/
  }
  v43[0] = (__int64)(((unsigned __int64)((unsigned __int128)(0x431BDE82D7B634DBLL * (__int128)v23) >> 64) >> 63) /*0x102a759de*/
                   + v23 / 0xF4240uLL)
         % 60;
  v24 = (__int64 *)v36[0]; /*0x102a759e1*/
  std::string::basic_string[abi:ne200100]<0>(a1: v39, a2: "Second"); /*0x102a759ef*/
  v37 = v39; /*0x102a759f8*/
  v25 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x102a75a15*/
          a1: v24,
          a2: v39,
          a3: (__int64)std::piecewise_construct,
          a4: (__int64)&v37,
          a5: (__int64)&v41);
  *((_QWORD *)v25 + 5) = RBX::Reflection::Type::getSingleton<int>(a1: v26); /*0x102a75a1d*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int,(int *)0>(a1: v25 + 48, a2: v43); /*0x102a75a2c*/
  if ( (v39[0] & 1) != 0 ) /*0x102a75a35*/
    operator delete(a1: v40); /*0x102a75a3b*/
  if ( (unsigned __int64)(v38 - 0x7FFFFFFFFFFFFFFELL) > 2 ) /*0x102a75a50*/
  {
    v27 = v38 % 86400000000LL; /*0x102a75a9b*/
  }
  else
  {
    v27 = 0x7FFFFFFFFFFFFFFELL; /*0x102a75a57*/
    if ( v38 == 0x8000000000000000LL ) /*0x102a75a5f*/
      v27 = 0x8000000000000000LL; /*0x102a75a5f*/
    if ( v38 == 0x7FFFFFFFFFFFFFFFLL ) /*0x102a75a66*/
      v27 = 0x7FFFFFFFFFFFFFFFLL; /*0x102a75a66*/
  }
  v28 = v27 % 1000000; /*0x102a75ab9*/
  v29 = (int)((double)(int)v28 / 1000.0); /*0x102a75acd*/
  if ( v28 <= 0 ) /*0x102a75ad1*/
    v29 = 0; /*0x102a75ad1*/
  v43[0] = v29; /*0x102a75ad4*/
  v30 = (__int64 *)v36[0]; /*0x102a75ad7*/
  std::string::basic_string[abi:ne200100]<0>(a1: v39, a2: "Millisecond"); /*0x102a75ae5*/
  v37 = v39; /*0x102a75aee*/
  v31 = std::__hash_table<std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::hash<std::string>,std::equal_to<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,RBX::Reflection::Variant>,std::equal_to<std::string>,std::hash<std::string>,true>,std::allocator<std::__hash_value_type<std::string,RBX::Reflection::Variant>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string&&>,std::tuple<>>( /*0x102a75b07*/
          a1: v30,
          a2: v39,
          a3: (__int64)std::piecewise_construct,
          a4: (__int64)&v37,
          a5: (__int64)&v41);
  *((_QWORD *)v31 + 5) = RBX::Reflection::Type::getSingleton<int>(a1: v32); /*0x102a75b0f*/
  RBX::Reflection::detail::placement_any<64ul,8ul>::operator=<int>(a1: (__int64 *)v31 + 6, a2: v43); /*0x102a75b1e*/
  if ( (v39[0] & 1) != 0 ) /*0x102a75b27*/
    operator delete(a1: v40); /*0x102a75b2d*/
  v33 = v36[1]; /*0x102a75b32*/
  *a1 = *(_OWORD *)v36; /*0x102a75b3a*/
  if ( v33 != nullptr ) /*0x102a75b42*/
  {
    _InterlockedIncrement64((volatile signed __int64 *)v33 + 1); /*0x102a75b44*/
    v34 = v36[1]; /*0x102a75b49*/
    if ( v36[1] != nullptr /*0x102a75b62*/
      && _InterlockedExchangeAdd64((volatile signed __int64 *)v36[1] + 1, 0xFFFFFFFFFFFFFFFFLL) == 0 )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v34 + 16LL))(a1: v34); /*0x102a75b6a*/
      std::__shared_weak_count::__release_weak(this: v34); /*0x102a75b70*/
    }
  }
  return a1; /*0x102a75b78*/
}

// Address: 0x102a75f14 | Name: __ZNK3RBX8DateTime13validDateTimeEv
__int64 __fastcall RBX::DateTime::validDateTime(RBX::DateTime *this)
{
  unsigned int v2; // r14d

  v2 = 0; /*0x102a75f1e*/
  if ( *(_QWORD *)this  /* +0 likely utcTime..time_.time_count_ -- UNVERIFIED */!= boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::get_time_rep(a1: 0) ) /*0x102a75f2b*/
    LOBYTE(v2) = *((_QWORD *)this + 1) /* +8 likely localTime..time_.time_count_ -- UNVERIFIED */ != boost::date_time::counted_time_system<boost::date_time::counted_time_rep<boost::posix_time::millisec_posix_time_system_config>>::get_time_rep(a1: 0); /*0x102a75f38*/
  return v2; /*0x102a75f3f*/
}

// END DateTime part 1/1, 10 functions
