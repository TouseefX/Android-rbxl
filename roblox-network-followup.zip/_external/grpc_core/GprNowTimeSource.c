// GprNowTimeSource -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 1 functions


// Address: 0x106b3909a | Name: __ZN9grpc_core12_GLOBAL__N_116GprNowTimeSource3NowEv
__int64 __fastcall grpc_core::`anonymous namespace'::GprNowTimeSource::Now(
        grpc_core::_anonymous_namespace_::GprNowTimeSource *this)
{
  __int64 v1; // rax
  __int64 v2; // rdx

  v1 = gpr_now(a1: 0); /*0x106b390a0*/
  return grpc_core::Timestamp::FromTimespecRoundDown(a1: v1, a2: v2); /*0x106b390ab*/
}

// END GprNowTimeSource part 1/1, 1 functions
