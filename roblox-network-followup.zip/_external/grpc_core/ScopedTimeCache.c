// ScopedTimeCache -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 2 functions


// Address: 0x106b387b6 | Name: __ZN9grpc_core15ScopedTimeCache3NowEv
__int64 __fastcall grpc_core::ScopedTimeCache::Now(grpc_core::ScopedTimeCache *this)
{
  __int64 v2; // rax

  if ( *((_BYTE *)this + 24) == 0 ) /*0x106b387c4*/
  {
    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)this + 1) + 8LL))(a1: *((_QWORD *)this + 1)); /*0x106b387cd*/
    v2 = (***((__int64 (__fastcall ****)(_QWORD))this + 1))(a1: *((_QWORD *)this + 1)); /*0x106b387d7*/
    if ( *((_BYTE *)this + 24) == 0 ) /*0x106b387de*/
      *((_BYTE *)this + 24) = 1; /*0x106b387e0*/
    *((_QWORD *)this + 2) = v2; /*0x106b387e6*/
  }
  return *((_QWORD *)this + 2); /*0x106b387f6*/
}

// Address: 0x106b38e64 | Name: __ZN9grpc_core15ScopedTimeCache15InvalidateCacheEv
__int64 __fastcall grpc_core::ScopedTimeCache::InvalidateCache(grpc_core::ScopedTimeCache *this)
{
  if ( *((_BYTE *)this + 24) == 1 ) /*0x106b38e6c*/
    *((_BYTE *)this + 24) = 0; /*0x106b38e6e*/
  return (*(__int64 (__fastcall **)(_QWORD))(**((_QWORD **)this + 1) + 8LL))(a1: *((_QWORD *)this + 1));
}

// END ScopedTimeCache part 1/1, 2 functions
