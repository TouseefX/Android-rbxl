// KernelTimeout -- 0.735 Studio, Mac symbols, 2026-08
// tier 1, 14 functions


// Address: 0x10338d266 | Name: __ZN4absl12lts_2024011624synchronization_internal13KernelTimeout14SteadyClockNowEv
__int64 __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::SteadyClockNow(
        absl::lts_20240116::synchronization_internal::KernelTimeout *this)
{
  return std::chrono::steady_clock::now(this); /*0x10338d26a*/
}

// Address: 0x10338d270 | Name: __ZN4absl12lts_2024011624synchronization_internal13KernelTimeoutC2ENS0_4TimeE
__int64 __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::KernelTimeout(
        __int64 *a1,
        __int64 a2,
        unsigned int a3)
{
  __int64 result; // rax
  __int64 v5; // rax
  __int64 v6; // rcx
  __int64 v7; // rcx
  bool v8; // zf

  result = -1; /*0x10338d291*/
  if ( a3 != -1 || a2 != 0x7FFFFFFFFFFFFFFFLL ) /*0x10338d287*/
  {
    v5 = absl::lts_20240116::ToUnixNanos(a1: a2, a2: a3); /*0x10338d2a2*/
    v6 = 0; /*0x10338d2a7*/
    if ( v5 > 0 ) /*0x10338d2ac*/
      v6 = v5; /*0x10338d2ac*/
    v7 = 2 * v6; /*0x10338d2b0*/
    v8 = v5 == 0x7FFFFFFFFFFFFFFFLL; /*0x10338d2b3*/
    result = -1; /*0x10338d2b6*/
    if ( !v8 ) /*0x10338d2bd*/
      result = v7; /*0x10338d2bd*/
  }
  *a1 = result; /*0x10338d2c1*/
  return result; /*0x10338d2c4*/
}

// Address: 0x10338d2ca | Name: __ZN4absl12lts_2024011624synchronization_internal13KernelTimeoutC1ENS0_4TimeE
__int64 __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::KernelTimeout(
        __int64 *a1,
        __int64 a2,
        unsigned int a3)
{
  __int64 result; // rax
  __int64 v5; // rax
  __int64 v6; // rcx
  __int64 v7; // rcx
  bool v8; // zf

  result = -1; /*0x10338d2eb*/
  if ( a3 != -1 || a2 != 0x7FFFFFFFFFFFFFFFLL ) /*0x10338d2e1*/
  {
    v5 = absl::lts_20240116::ToUnixNanos(a1: a2, a2: a3); /*0x10338d2fc*/
    v6 = 0; /*0x10338d301*/
    if ( v5 > 0 ) /*0x10338d306*/
      v6 = v5; /*0x10338d306*/
    v7 = 2 * v6; /*0x10338d30a*/
    v8 = v5 == 0x7FFFFFFFFFFFFFFFLL; /*0x10338d30d*/
    result = -1; /*0x10338d310*/
    if ( !v8 ) /*0x10338d317*/
      result = v7; /*0x10338d317*/
  }
  *a1 = result; /*0x10338d31b*/
  return result; /*0x10338d31e*/
}

// Address: 0x10338d324 | Name: __ZN4absl12lts_2024011624synchronization_internal13KernelTimeoutC2ENS0_8DurationE
char __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::KernelTimeout(
        absl::lts_20240116::synchronization_internal::KernelTimeout *this,
        __int64 a2,
        unsigned int a3)
{
  __int64 v4; // rax
  __int64 v5; // r15
  __int64 v6; // r14
  std::chrono::steady_clock *v7; // rdi
  __int64 v8; // rcx

  LOBYTE(v4) = a2 == 0x7FFFFFFFFFFFFFFFLL; /*0x10338d33f*/
  v5 = -1; /*0x10338d348*/
  if ( a3 != -1 || a2 != 0x7FFFFFFFFFFFFFFFLL ) /*0x10338d33f*/
  {
    v6 = absl::lts_20240116::ToInt64Nanoseconds(this: a2, a2: a3); /*0x10338d35d*/
    v4 = std::chrono::steady_clock::now(this: v7); /*0x10338d360*/
    if ( v6 <= 0x7FFFFFFFFFFFFFFFLL - v4 ) /*0x10338d36b*/
    {
      v8 = 0; /*0x10338d36d*/
      if ( v6 > 0 ) /*0x10338d372*/
        v8 = v6; /*0x10338d372*/
      v5 = 2 * (v4 + v8) + 1; /*0x10338d379*/
    }
  }
  *(_QWORD *)this = v5; /*0x10338d381*/
  return v4; /*0x10338d384*/
}

// Address: 0x10338d38e | Name: __ZN4absl12lts_2024011624synchronization_internal13KernelTimeoutC1ENS0_8DurationE
char __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::KernelTimeout(
        absl::lts_20240116::synchronization_internal::KernelTimeout *this,
        __int64 a2,
        unsigned int a3)
{
  return absl::lts_20240116::synchronization_internal::KernelTimeout::KernelTimeout(this, a2, a3); /*0x10338d392*/
}

// Address: 0x10338d398 | Name: __ZNK4absl12lts_2024011624synchronization_internal13KernelTimeout12MakeAbsNanosEv
__int64 __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::MakeAbsNanos(
        absl::lts_20240116::synchronization_internal::KernelTimeout *this)
{
  __int64 v1; // rbx
  unsigned __int64 v2; // rax
  unsigned __int64 v3; // r14
  absl::lts_20240116 *v5; // rdi
  __int64 v6; // r14
  __int64 v7; // r15
  __int64 CurrentTimeNanos; // rax
  __int64 v9; // r15

  v1 = 0x7FFFFFFFFFFFFFFFLL; /*0x10338d3a2*/
  v2 = *(_QWORD *)this; /*0x10338d3ac*/
  if ( *(_QWORD *)this != -1 ) /*0x10338d3b3*/
  {
    v3 = v2 >> 1; /*0x10338d3b8*/
    if ( (v2 & 1) == 0 ) /*0x10338d3bd*/
      return (v3 == 0) + v3; /*0x10338d3ca*/
    v6 = v3 - std::chrono::steady_clock::now(this); /*0x10338d3d1*/
    v7 = 0; /*0x10338d3d4*/
    if ( v6 > 0 ) /*0x10338d3da*/
      v7 = v6; /*0x10338d3da*/
    CurrentTimeNanos = absl::lts_20240116::GetCurrentTimeNanos(this: v5); /*0x10338d3de*/
    v9 = CurrentTimeNanos + v7; /*0x10338d3e9*/
    if ( v6 <= 0x7FFFFFFFFFFFFFFFLL - CurrentTimeNanos ) /*0x10338d3ef*/
      return v9; /*0x10338d3ef*/
  }
  return v1; /*0x10338d3fa*/
}

// Address: 0x10338d402 | Name: __ZNK4absl12lts_2024011624synchronization_internal13KernelTimeout20InNanosecondsFromNowEv
__int64 __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::InNanosecondsFromNow(
        absl::lts_20240116::synchronization_internal::KernelTimeout *this)
{
  unsigned __int64 v1; // rax
  unsigned __int64 v2; // rbx
  __int64 CurrentTimeNanos; // rax
  __int64 result; // rax
  __int64 v5; // rbx

  v1 = *(_QWORD *)this; /*0x10338d408*/
  if ( *(_QWORD *)this == -1 ) /*0x10338d40f*/
    return 0x7FFFFFFFFFFFFFFFLL; /*0x10338d422*/
  v2 = v1 >> 1; /*0x10338d414*/
  if ( (v1 & 1) != 0 ) /*0x10338d419*/
    CurrentTimeNanos = std::chrono::steady_clock::now(this); /*0x10338d42e*/
  else
    CurrentTimeNanos = absl::lts_20240116::GetCurrentTimeNanos(this); /*0x10338d41b*/
  v5 = v2 - CurrentTimeNanos; /*0x10338d433*/
  result = 0; /*0x10338d436*/
  if ( v5 > 0 ) /*0x10338d43b*/
    return v5; /*0x10338d43b*/
  return result; /*0x10338d443*/
}

// Address: 0x10338d446 | Name: __ZNK4absl12lts_2024011624synchronization_internal13KernelTimeout15MakeAbsTimespecEv
__int64 __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::MakeAbsTimespec(
        absl::lts_20240116::synchronization_internal::KernelTimeout *this)
{
  __int64 AbsNanos; // rcx
  unsigned __int64 v2; // rax
  __int64 v3; // rcx
  int v4; // esi

  AbsNanos = absl::lts_20240116::synchronization_internal::KernelTimeout::MakeAbsNanos(this); /*0x10338d44f*/
  v2 = AbsNanos / 1000000000 /*0x10338d46a*/
     + ((unsigned __int64)((unsigned __int128)(0x112E0BE826D694B3LL * (__int128)AbsNanos) >> 64) >> 63);
  v3 = AbsNanos - 1000000000 * v2; /*0x10338d474*/
  v4 = 4 * v3 - 294967296; /*0x10338d48b*/
  if ( v3 >= 0 ) /*0x10338d492*/
    v4 = 4 * v3; /*0x10338d492*/
  return absl::lts_20240116::ToTimespec(this: (absl::lts_20240116 *)(v2 + (v3 >> 61)), a2: v4); /*0x10338d495*/
}

// Address: 0x10338d49c | Name: __ZNK4absl12lts_2024011624synchronization_internal13KernelTimeout20MakeRelativeTimespecEv
__int64 __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::MakeRelativeTimespec(
        absl::lts_20240116::synchronization_internal::KernelTimeout *this)
{
  __int64 v1; // rcx
  unsigned __int64 v2; // rax
  __int64 v3; // rcx
  int v4; // esi

  v1 = absl::lts_20240116::synchronization_internal::KernelTimeout::InNanosecondsFromNow(this); /*0x10338d4a5*/
  v2 = v1 / 1000000000 + ((unsigned __int64)((unsigned __int128)(0x112E0BE826D694B3LL * (__int128)v1) >> 64) >> 63); /*0x10338d4c0*/
  v3 = v1 - 1000000000 * v2; /*0x10338d4ca*/
  v4 = 4 * v3 - 294967296; /*0x10338d4e1*/
  if ( v3 >= 0 ) /*0x10338d4e8*/
    v4 = 4 * v3; /*0x10338d4e8*/
  return absl::lts_20240116::ToTimespec(this: (absl::lts_20240116 *)(v2 + (v3 >> 61)), a2: v4); /*0x10338d4eb*/
}

// Address: 0x10338d4f2 | Name: __ZNK4absl12lts_2024011624synchronization_internal13KernelTimeout25MakeClockAbsoluteTimespecE9clockid_t
__int64 __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::MakeClockAbsoluteTimespec(
        absl::lts_20240116::synchronization_internal::KernelTimeout *this,
        clockid_t a2)
{
  unsigned __int64 v2; // rbx
  __int64 CurrentTimeNanos; // rax
  __int64 v6; // r15
  unsigned __int64 v7; // rdx
  __int64 v8; // rbx
  absl::lts_20240116 *v9; // rcx
  int v10; // edx
  int v11; // r8d
  __int64 v12; // rax
  __int64 v13; // rbx
  unsigned int v14; // edx
  __int64 *v15; // rax
  absl::lts_20240116 *v16; // rdi
  int v17; // esi
  bool v18; // cl
  __int64 v19[2]; // [rsp+8h] [rbp-38h] BYREF
  timespec __tp; // [rsp+18h] [rbp-28h] BYREF

  v2 = *(_QWORD *)this; /*0x10338d4ff*/
  if ( *(_QWORD *)this == -1 ) /*0x10338d506*/
    return absl::lts_20240116::ToTimespec(this: (absl::lts_20240116 *)0x225C17D04LL, a2: -875864068); /*0x10338d530*/
  if ( (v2 & 1) != 0 ) /*0x10338d50e*/
    CurrentTimeNanos = std::chrono::steady_clock::now(this); /*0x10338d535*/
  else
    CurrentTimeNanos = absl::lts_20240116::GetCurrentTimeNanos(this); /*0x10338d510*/
  v6 = CurrentTimeNanos; /*0x10338d53a*/
  if ( clock_gettime(__clock_id: a2, &__tp) != 0 ) /*0x10338d54b*/
    absl::lts_20240116::synchronization_internal::KernelTimeout::MakeClockAbsoluteTimespec(); /*0x10338d5f4*/
  v8 = (v2 >> 1) - v6; /*0x10338d554*/
  v9 = absl::lts_20240116::DurationFromTimespec( /*0x10338d564*/
         this: (absl::lts_20240116 *)__tp.tv_sec,
         a2: (timespec)__PAIR128__(v7, __tp.tv_nsec));
  v11 = v10; /*0x10338d567*/
  v12 = v8 / 1000000000; /*0x10338d585*/
  v13 = v8 % 1000000000; /*0x10338d58f*/
  v14 = 4 * v13 - 294967296; /*0x10338d5a6*/
  if ( v13 >= 0 ) /*0x10338d5ad*/
    v14 = 4 * v13; /*0x10338d5ad*/
  v19[0] = (__int64)v9; /*0x10338d5b4*/
  LODWORD(v19[1]) = v11; /*0x10338d5b7*/
  v15 = absl::lts_20240116::Duration::operator+=(a1: v19, a2: v12 + (v13 >> 61), a3: v14); /*0x10338d5bb*/
  v16 = (absl::lts_20240116 *)*v15; /*0x10338d5c0*/
  v17 = *((_DWORD *)v15 + 2); /*0x10338d5c3*/
  v18 = *v15 <= 0; /*0x10338d5d2*/
  if ( *v15 == 0 ) /*0x10338d5d5*/
    v18 = v17 == 0; /*0x10338d5d5*/
  if ( v18 ) /*0x10338d5db*/
  {
    v16 = nullptr; /*0x10338d5dd*/
    v17 = 4; /*0x10338d5df*/
  }
  return absl::lts_20240116::ToTimespec(this: v16, a2: v17); /*0x10338d526*/
}

// Address: 0x10338d5fa | Name: __ZNK4absl12lts_2024011624synchronization_internal13KernelTimeout21InMillisecondsFromNowEv
unsigned __int64 __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::InMillisecondsFromNow(
        absl::lts_20240116::synchronization_internal::KernelTimeout *this)
{
  __int64 v1; // rbx
  unsigned __int64 v2; // rax

  v1 = -1; /*0x10338d600*/
  if ( *(_QWORD *)this != -1 ) /*0x10338d60b*/
  {
    v2 = absl::lts_20240116::synchronization_internal::KernelTimeout::InNanosecondsFromNow(this); /*0x10338d60d*/
    if ( v2 <= 0x7FFFFFFFFFF0BDBFLL ) /*0x10338d61f*/
      return (v2 + 999999) / 0xF4240; /*0x10338d637*/
  }
  return v1; /*0x10338d642*/
}

// Address: 0x10338d646 | Name: __ZNK4absl12lts_2024011624synchronization_internal13KernelTimeout17ToChronoTimePointEv
unsigned __int64 __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::ToChronoTimePoint(
        absl::lts_20240116::synchronization_internal::KernelTimeout *this)
{
  __int64 AbsNanos; // rax
  __int64 v2; // rsi

  if ( *(_QWORD *)this == -1 ) /*0x10338d64a*/
    return 0x7FFFFFFFFFFFFFFFLL; /*0x10338d686*/
  AbsNanos = absl::lts_20240116::synchronization_internal::KernelTimeout::MakeAbsNanos(this); /*0x10338d652*/
  return ((unsigned __int64)((unsigned __int128)(0x20C49BA5E353F7CFLL * (__int128)AbsNanos) >> 64) >> 63) /*0x10338d685*/
       + AbsNanos / 1000
       + std::chrono::system_clock::from_time_t(this: nullptr, a2: v2);
}

// Address: 0x10338d692 | Name: __ZNK4absl12lts_2024011624synchronization_internal13KernelTimeout16ToChronoDurationEv
__int64 __fastcall absl::lts_20240116::synchronization_internal::KernelTimeout::ToChronoDuration(
        absl::lts_20240116::synchronization_internal::KernelTimeout *this)
{
  if ( *(_QWORD *)this == -1 ) /*0x10338d69a*/
    return 0x7FFFFFFFFFFFFFFFLL; /*0x10338d6a2*/
  else
    return absl::lts_20240116::synchronization_internal::KernelTimeout::InNanosecondsFromNow(this); /*0x10338d69d*/
}

// Address: 0x10863413c | Name: __ZNK4absl12lts_2024011624synchronization_internal13KernelTimeout25MakeClockAbsoluteTimespecE9clockid_t.cold.1
void __fastcall __noreturn absl::lts_20240116::synchronization_internal::KernelTimeout::MakeClockAbsoluteTimespec(
        __m128i a1,
        __m128i a2,
        __m128i a3,
        __m128i a4,
        __m128i a5,
        __m128i a6,
        __m128i a7,
        __m128i a8)
{
  char savedregs; // [rsp+0h] [rbp+0h]

  absl::lts_20240116::raw_log_internal::RawLog(
    a1: 3,
    a2: "kernel_timeout.cc",
    a3: 165,
    a4: "Check %s failed: %s",
    a5: (__int64)"clock_gettime(c, &now) == 0",
    a6: (__int64)"clock_gettime() failed",
    a7: a1,
    a8: a2,
    a9: a3,
    a10: a4,
    a11: a5,
    a12: a6,
    a13: a7,
    a14: a8,
    a15: savedregs);
  BUG(); /*0x10863416b*/
}

// END KernelTimeout part 1/1, 14 functions
